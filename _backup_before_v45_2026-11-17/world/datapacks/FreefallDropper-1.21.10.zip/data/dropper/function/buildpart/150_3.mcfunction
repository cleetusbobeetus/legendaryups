setblock 301 258 607 minecraft:light[level=13]
setblock 301 258 615 minecraft:light[level=13]
setblock 301 258 639 minecraft:light[level=13]
fill 304 258 614 304 264 614 minecraft:black_concrete
fill 304 258 646 304 307 646 minecraft:white_concrete
fill 305 258 615 305 264 615 minecraft:black_concrete
setblock 306 258 613 minecraft:black_concrete
setblock 306 258 637 minecraft:black_concrete
setblock 309 258 607 minecraft:light[level=13]
fill 309 258 611 309 258 612 minecraft:black_concrete
setblock 309 258 615 minecraft:light[level=13]
fill 309 258 618 309 258 619 minecraft:blackstone
fill 309 258 631 309 258 632 minecraft:blackstone
fill 309 258 638 309 258 639 minecraft:black_concrete
fill 310 258 618 310 260 618 minecraft:blackstone
fill 310 258 632 310 260 632 minecraft:blackstone
setblock 317 258 607 minecraft:light[level=13]
setblock 317 258 615 minecraft:light[level=13]
setblock 317 258 623 minecraft:light[level=13]
setblock 317 258 631 minecraft:light[level=13]
setblock 317 258 639 minecraft:light[level=13]
fill 304 259 615 304 264 615 minecraft:black_concrete
fill 306 259 612 306 260 612 minecraft:black_concrete
fill 306 259 614 306 264 615 minecraft:black_concrete
fill 306 259 638 306 260 638 minecraft:black_concrete
setblock 309 259 611 minecraft:black_concrete
setblock 309 259 619 minecraft:blackstone
setblock 309 259 631 minecraft:blackstone
setblock 309 259 639 minecraft:black_concrete
fill 311 259 618 311 260 619 minecraft:blackstone
fill 311 259 631 311 260 632 minecraft:blackstone
setblock 282 260 632 minecraft:pearlescent_froglight
fill 282 260 633 282 307 633 minecraft:white_concrete
fill 303 260 614 303 264 615 minecraft:black_concrete
fill 304 260 613 305 264 613 minecraft:black_concrete
fill 304 260 616 305 264 616 minecraft:black_concrete
fill 311 260 617 312 261 617 minecraft:blackstone
fill 311 260 633 312 261 633 minecraft:blackstone
fill 312 260 618 312 261 618 minecraft:blackstone
fill 312 260 632 312 261 632 minecraft:blackstone
fill 282 261 612 282 263 612 minecraft:gold_block
fill 282 261 628 282 263 628 minecraft:gold_block
fill 282 261 632 282 307 632 minecraft:white_concrete
fill 282 261 644 282 263 644 minecraft:gold_block
fill 286 261 604 286 263 604 minecraft:gold_block
fill 296 261 646 296 263 646 minecraft:gold_block
fill 302 261 604 302 263 604 minecraft:gold_block
fill 303 261 613 303 264 613 minecraft:black_concrete
fill 306 261 613 306 264 613 minecraft:black_concrete
fill 306 261 616 306 264 616 minecraft:black_concrete
fill 307 261 614 307 264 615 minecraft:black_concrete
setblock 311 261 618 minecraft:blackstone
setblock 311 261 632 minecraft:blackstone
fill 312 261 646 312 263 646 minecraft:gold_block
fill 318 261 604 318 263 604 minecraft:gold_block
fill 324 261 614 324 263 614 minecraft:gold_block
fill 324 261 630 324 263 630 minecraft:gold_block
fill 303 262 616 303 264 616 minecraft:black_concrete
fill 304 262 612 306 264 612 minecraft:black_concrete
fill 304 262 617 305 264 617 minecraft:black_concrete
fill 307 262 613 307 264 613 minecraft:black_concrete
fill 307 262 616 307 264 616 minecraft:black_concrete
setblock 312 262 617 minecraft:blackstone
setblock 312 262 633 minecraft:blackstone
setblock 324 262 628 minecraft:pearlescent_froglight
fill 302 263 613 302 264 616 minecraft:black_concrete
fill 303 263 604 303 307 604 minecraft:white_concrete
fill 303 263 612 303 264 612 minecraft:black_concrete
fill 303 263 617 303 264 617 minecraft:black_concrete
setblock 304 263 604 minecraft:amethyst_block
fill 306 263 617 306 264 617 minecraft:black_concrete
fill 324 263 628 324 307 628 minecraft:white_concrete
fill 282 264 612 282 269 612 minecraft:white_concrete
fill 282 264 628 282 269 628 minecraft:white_concrete
fill 282 264 644 282 269 644 minecraft:white_concrete
fill 286 264 604 286 269 604 minecraft:white_concrete
fill 296 264 646 296 269 646 minecraft:white_concrete
fill 302 264 604 302 269 604 minecraft:white_concrete
setblock 302 264 612 minecraft:black_concrete
setblock 302 264 646 minecraft:pearlescent_froglight
fill 304 264 604 304 294 604 minecraft:white_concrete
fill 304 264 611 306 264 611 minecraft:black_concrete
fill 304 264 618 305 264 618 minecraft:black_concrete
setblock 307 264 612 minecraft:black_concrete
setblock 307 264 617 minecraft:black_concrete
fill 308 264 613 308 264 616 minecraft:black_concrete
fill 312 264 646 312 269 646 minecraft:white_concrete
fill 318 264 604 318 269 604 minecraft:white_concrete
fill 324 264 614 324 269 614 minecraft:white_concrete
fill 324 264 630 324 269 630 minecraft:white_concrete
fill 302 265 646 302 307 646 minecraft:white_concrete
fill 304 265 614 305 266 615 minecraft:amethyst_block
fill 282 266 646 282 307 646 minecraft:white_concrete
setblock 283 266 646 minecraft:amethyst_block
fill 284 266 646 284 307 646 minecraft:white_concrete
setblock 285 266 607 minecraft:light[level=13]
setblock 285 266 615 minecraft:light[level=13]
setblock 285 266 623 minecraft:light[level=13]
setblock 285 266 631 minecraft:light[level=13]
setblock 285 266 639 minecraft:light[level=13]
setblock 293 266 607 minecraft:light[level=13]
setblock 293 266 615 minecraft:light[level=13]
setblock 293 266 623 minecraft:light[level=13]
setblock 293 266 631 minecraft:light[level=13]
setblock 293 266 639 minecraft:light[level=13]
setblock 301 266 607 minecraft:light[level=13]
setblock 301 266 615 minecraft:light[level=13]
setblock 301 266 623 minecraft:light[level=13]
setblock 301 266 631 minecraft:light[level=13]
setblock 301 266 639 minecraft:light[level=13]
setblock 309 266 607 minecraft:light[level=13]
setblock 309 266 615 minecraft:light[level=13]
setblock 309 266 623 minecraft:light[level=13]
setblock 309 266 631 minecraft:light[level=13]
setblock 309 266 639 minecraft:light[level=13]
setblock 317 266 607 minecraft:light[level=13]
setblock 317 266 615 minecraft:light[level=13]
setblock 317 266 623 minecraft:light[level=13]
setblock 317 266 631 minecraft:light[level=13]
setblock 317 266 639 minecraft:light[level=13]
fill 319 266 604 322 275 604 minecraft:white_concrete
setblock 323 266 604 minecraft:amethyst_block
fill 324 266 604 324 307 604 minecraft:white_concrete
fill 324 266 610 324 302 610 minecraft:white_concrete
setblock 324 266 611 minecraft:pearlescent_froglight
fill 324 266 612 324 269 612 minecraft:white_concrete
fill 283 267 646 283 307 646 minecraft:white_concrete
fill 295 267 626 295 268 626 minecraft:gold_block
fill 305 267 614 305 267 615 minecraft:amethyst_block
fill 323 267 604 323 307 604 minecraft:white_concrete
fill 324 267 611 324 307 611 minecraft:white_concrete
setblock 294 268 604 minecraft:amethyst_block
setblock 305 268 614 minecraft:amethyst_block
fill 282 269 604 283 294 604 minecraft:white_concrete
setblock 282 269 635 minecraft:amethyst_block
fill 282 269 636 282 307 636 minecraft:white_concrete
setblock 284 269 604 minecraft:pearlescent_froglight
fill 285 269 604 285 307 604 minecraft:white_concrete
fill 294 269 604 294 307 604 minecraft:white_concrete
fill 324 269 631 324 307 633 minecraft:white_concrete
setblock 324 269 634 minecraft:amethyst_block
fill 324 269 635 324 307 635 minecraft:white_concrete
fill 282 270 612 282 272 612 minecraft:gold_block
fill 282 270 628 282 272 628 minecraft:gold_block
fill 282 270 635 282 290 635 minecraft:white_concrete
fill 282 270 644 282 272 644 minecraft:gold_block
fill 284 270 604 284 290 604 minecraft:white_concrete
fill 286 270 604 286 272 604 minecraft:gold_block
fill 296 270 646 296 272 646 minecraft:gold_block
fill 302 270 604 302 272 604 minecraft:gold_block
fill 312 270 646 312 272 646 minecraft:gold_block
fill 318 270 604 318 272 604 minecraft:gold_block
fill 324 270 606 324 307 607 minecraft:white_concrete
setblock 324 270 608 minecraft:amethyst_block
fill 324 270 609 324 284 609 minecraft:white_concrete
setblock 324 270 612 minecraft:amethyst_block
fill 324 270 614 324 272 614 minecraft:gold_block
fill 324 270 630 324 272 630 minecraft:gold_block
fill 324 270 634 324 288 634 minecraft:white_concrete
fill 324 271 608 324 279 608 minecraft:white_concrete
fill 324 271 612 324 307 612 minecraft:white_concrete
fill 282 272 639 282 307 641 minecraft:white_concrete
setblock 282 272 642 minecraft:amethyst_block
fill 282 273 612 282 287 612 minecraft:white_concrete
fill 282 273 628 282 287 628 minecraft:white_concrete
fill 282 273 642 282 307 642 minecraft:white_concrete
fill 282 273 644 282 287 644 minecraft:white_concrete
fill 286 273 604 286 287 604 minecraft:white_concrete
fill 296 273 646 296 287 646 minecraft:white_concrete
fill 302 273 604 302 287 604 minecraft:white_concrete
fill 312 273 646 312 287 646 minecraft:white_concrete
fill 318 273 604 318 276 604 minecraft:white_concrete
fill 324 273 614 324 287 614 minecraft:white_concrete
fill 324 273 630 324 287 630 minecraft:white_concrete
setblock 285 274 607 minecraft:light[level=13]
setblock 285 274 615 minecraft:light[level=13]
setblock 285 274 623 minecraft:light[level=13]
setblock 285 274 631 minecraft:light[level=13]
setblock 285 274 639 minecraft:light[level=13]
setblock 293 274 607 minecraft:light[level=13]
setblock 293 274 615 minecraft:light[level=13]
setblock 293 274 623 minecraft:light[level=13]
setblock 293 274 631 minecraft:light[level=13]
setblock 293 274 639 minecraft:light[level=13]
setblock 301 274 607 minecraft:light[level=13]
setblock 301 274 615 minecraft:light[level=13]
setblock 301 274 623 minecraft:light[level=13]
setblock 301 274 631 minecraft:light[level=13]
setblock 301 274 639 minecraft:light[level=13]
setblock 309 274 607 minecraft:light[level=13]
setblock 309 274 615 minecraft:light[level=13]
setblock 309 274 623 minecraft:light[level=13]
setblock 309 274 631 minecraft:light[level=13]
setblock 309 274 639 minecraft:light[level=13]
fill 314 274 646 315 307 646 minecraft:white_concrete
setblock 316 274 646 minecraft:amethyst_block
setblock 317 274 607 minecraft:light[level=13]
setblock 317 274 615 minecraft:light[level=13]
setblock 317 274 623 minecraft:light[level=13]
setblock 317 274 631 minecraft:light[level=13]
setblock 317 274 639 minecraft:light[level=13]
fill 322 274 646 322 307 646 minecraft:white_concrete
setblock 323 274 646 minecraft:amethyst_block
fill 316 275 646 316 304 646 minecraft:white_concrete
fill 323 275 646 323 307 646 minecraft:white_concrete
setblock 319 276 604 minecraft:pearlescent_froglight
fill 320 276 604 322 303 604 minecraft:white_concrete
setblock 324 276 627 minecraft:amethyst_block
setblock 318 277 604 minecraft:amethyst_block
fill 319 277 604 319 307 604 minecraft:white_concrete
fill 324 277 627 324 307 627 minecraft:white_concrete
setblock 324 277 641 minecraft:amethyst_block
fill 318 278 604 318 279 604 minecraft:white_concrete
fill 324 278 616 324 283 619 minecraft:white_concrete
setblock 324 278 620 minecraft:amethyst_block
fill 324 278 621 324 307 624 minecraft:white_concrete
fill 324 278 641 324 307 641 minecraft:white_concrete
fill 289 279 627 302 279 627 minecraft:gold_block
fill 292 279 620 295 280 620 minecraft:gold_block
fill 292 279 626 303 279 626 minecraft:gold_block
fill 292 279 628 303 279 628 minecraft:gold_block
fill 292 279 634 295 280 634 minecraft:gold_block
fill 293 279 621 298 280 621 minecraft:gold_block
fill 293 279 633 298 280 633 minecraft:gold_block
fill 294 279 622 316 279 622 minecraft:gold_block
fill 294 279 632 316 279 632 minecraft:gold_block
fill 295 279 623 315 279 623 minecraft:gold_block
fill 295 279 631 315 279 631 minecraft:gold_block
fill 297 279 624 313 279 624 minecraft:gold_block
fill 297 279 630 313 279 630 minecraft:gold_block
fill 298 279 614 298 280 617 minecraft:gold_block
fill 298 279 625 304 279 625 minecraft:gold_block
fill 298 279 629 304 279 629 minecraft:gold_block
fill 298 279 637 298 280 640 minecraft:gold_block
fill 299 279 615 299 280 620 minecraft:gold_block
fill 299 279 634 299 280 639 minecraft:gold_block
fill 300 279 616 300 279 621 minecraft:gold_block
fill 300 279 633 300 279 638 minecraft:gold_block
fill 301 279 617 301 279 621 minecraft:gold_block
fill 301 279 633 301 279 637 minecraft:gold_block
fill 302 279 619 302 279 621 minecraft:gold_block
fill 302 279 633 302 279 635 minecraft:gold_block
fill 303 279 620 310 279 621 minecraft:gold_block
fill 303 279 633 310 279 634 minecraft:gold_block
fill 304 279 614 306 279 619 minecraft:gold_block
fill 304 279 635 306 279 640 minecraft:gold_block
fill 305 279 611 305 280 613 minecraft:gold_block
fill 305 279 641 305 280 643 minecraft:gold_block
fill 306 279 625 312 279 625 minecraft:gold_block
fill 306 279 629 312 279 629 minecraft:gold_block
fill 307 279 626 318 279 626 minecraft:gold_block
fill 307 279 628 318 279 628 minecraft:gold_block
fill 308 279 619 311 279 619 minecraft:gold_block
fill 308 279 627 321 279 627 minecraft:gold_block
fill 308 279 635 311 279 635 minecraft:gold_block
fill 309 279 617 311 279 618 minecraft:gold_block
fill 309 279 636 311 279 637 minecraft:gold_block
fill 310 279 616 312 280 616 minecraft:gold_block
fill 310 279 638 312 280 638 minecraft:gold_block
fill 311 279 615 312 280 615 minecraft:gold_block
fill 311 279 620 311 280 620 minecraft:gold_block
fill 311 279 634 311 280 634 minecraft:gold_block
fill 311 279 639 312 280 639 minecraft:gold_block
fill 312 279 614 312 280 614 minecraft:gold_block
fill 312 279 617 312 280 617 minecraft:gold_block
fill 312 279 621 317 280 621 minecraft:gold_block
fill 312 279 633 317 280 633 minecraft:gold_block
fill 312 279 637 312 280 637 minecraft:gold_block
fill 312 279 640 312 280 640 minecraft:gold_block
fill 315 279 620 318 280 620 minecraft:gold_block
fill 315 279 634 318 280 634 minecraft:gold_block
fill 324 279 620 324 299 620 minecraft:white_concrete
setblock 324 279 629 minecraft:pearlescent_froglight
setblock 283 280 605 minecraft:white_concrete
fill 283 280 606 283 280 609 minecraft:light_blue_concrete
setblock 283 280 610 minecraft:white_concrete
fill 283 280 611 283 280 614 minecraft:light_blue_concrete
setblock 283 280 615 minecraft:white_concrete
fill 283 280 616 283 280 619 minecraft:light_blue_concrete
setblock 283 280 620 minecraft:white_concrete
fill 283 280 621 283 280 624 minecraft:light_blue_concrete
setblock 283 280 625 minecraft:white_concrete
fill 283 280 626 283 280 629 minecraft:light_blue_concrete
setblock 283 280 630 minecraft:white_concrete
fill 283 280 631 283 280 634 minecraft:light_blue_concrete
setblock 283 280 635 minecraft:white_concrete
fill 283 280 636 283 280 639 minecraft:light_blue_concrete
setblock 283 280 640 minecraft:white_concrete
fill 283 280 641 283 280 644 minecraft:light_blue_concrete
setblock 283 280 645 minecraft:white_concrete
fill 284 280 605 287 280 605 minecraft:light_blue_concrete
setblock 284 280 606 minecraft:white_concrete
fill 284 280 607 284 280 610 minecraft:light_blue_concrete
setblock 284 280 611 minecraft:white_concrete
fill 284 280 612 284 280 615 minecraft:light_blue_concrete
setblock 284 280 616 minecraft:white_concrete
fill 284 280 617 284 280 620 minecraft:light_blue_concrete
setblock 284 280 621 minecraft:white_concrete
fill 284 280 622 284 280 625 minecraft:light_blue_concrete
setblock 284 280 626 minecraft:white_concrete
fill 284 280 627 284 280 630 minecraft:light_blue_concrete
setblock 284 280 631 minecraft:white_concrete
fill 284 280 632 284 280 635 minecraft:light_blue_concrete
setblock 284 280 636 minecraft:white_concrete
fill 284 280 637 284 280 640 minecraft:light_blue_concrete
setblock 284 280 641 minecraft:white_concrete
fill 284 280 642 284 280 645 minecraft:light_blue_concrete
fill 285 280 606 288 280 606 minecraft:light_blue_concrete
setblock 285 280 607 minecraft:white_concrete
fill 285 280 608 285 280 611 minecraft:light_blue_concrete
setblock 285 280 612 minecraft:white_concrete
fill 285 280 613 285 280 616 minecraft:light_blue_concrete
setblock 285 280 617 minecraft:white_concrete
fill 285 280 618 285 280 621 minecraft:light_blue_concrete
setblock 285 280 622 minecraft:white_concrete
fill 285 280 623 285 280 626 minecraft:light_blue_concrete
setblock 285 280 627 minecraft:white_concrete
fill 285 280 628 285 280 631 minecraft:light_blue_concrete
setblock 285 280 632 minecraft:white_concrete
fill 285 280 633 285 280 636 minecraft:light_blue_concrete
setblock 285 280 637 minecraft:white_concrete
fill 285 280 638 285 280 641 minecraft:light_blue_concrete
setblock 285 280 642 minecraft:white_concrete
fill 285 280 643 285 280 645 minecraft:light_blue_concrete
fill 286 280 607 289 280 607 minecraft:light_blue_concrete
setblock 286 280 608 minecraft:white_concrete
fill 286 280 609 286 280 612 minecraft:light_blue_concrete
setblock 286 280 613 minecraft:white_concrete
fill 286 280 614 286 280 617 minecraft:light_blue_concrete
setblock 286 280 618 minecraft:white_concrete
fill 286 280 619 286 280 622 minecraft:light_blue_concrete
setblock 286 280 623 minecraft:white_concrete
fill 286 280 624 286 280 627 minecraft:light_blue_concrete
setblock 286 280 628 minecraft:white_concrete
fill 286 280 629 286 280 632 minecraft:light_blue_concrete
setblock 286 280 633 minecraft:white_concrete
fill 286 280 634 286 280 637 minecraft:light_blue_concrete
setblock 286 280 638 minecraft:white_concrete
fill 286 280 639 286 280 642 minecraft:light_blue_concrete
setblock 286 280 643 minecraft:white_concrete
fill 286 280 644 286 280 645 minecraft:light_blue_concrete
fill 287 280 608 290 280 608 minecraft:light_blue_concrete
setblock 287 280 609 minecraft:white_concrete
fill 287 280 610 287 280 613 minecraft:light_blue_concrete
setblock 287 280 614 minecraft:white_concrete
fill 287 280 615 287 280 618 minecraft:light_blue_concrete
setblock 287 280 619 minecraft:white_concrete
fill 287 280 620 287 280 623 minecraft:light_blue_concrete
setblock 287 280 624 minecraft:white_concrete
fill 287 280 625 287 280 628 minecraft:light_blue_concrete
setblock 287 280 629 minecraft:white_concrete
fill 287 280 630 287 280 633 minecraft:light_blue_concrete
setblock 287 280 634 minecraft:white_concrete
fill 287 280 635 287 280 638 minecraft:light_blue_concrete
setblock 287 280 639 minecraft:white_concrete
fill 287 280 640 287 280 643 minecraft:light_blue_concrete
setblock 287 280 644 minecraft:white_concrete
setblock 287 280 645 minecraft:light_blue_concrete
setblock 288 280 605 minecraft:white_concrete
fill 288 280 609 291 280 609 minecraft:light_blue_concrete
setblock 288 280 610 minecraft:white_concrete
fill 288 280 611 288 280 614 minecraft:light_blue_concrete
setblock 288 280 615 minecraft:white_concrete
fill 288 280 616 288 280 619 minecraft:light_blue_concrete
setblock 288 280 620 minecraft:white_concrete
fill 288 280 621 288 280 624 minecraft:light_blue_concrete
setblock 288 280 625 minecraft:white_concrete
fill 288 280 626 288 280 629 minecraft:light_blue_concrete
setblock 288 280 630 minecraft:white_concrete
fill 288 280 631 288 280 634 minecraft:light_blue_concrete
setblock 288 280 635 minecraft:white_concrete
fill 288 280 636 288 280 639 minecraft:light_blue_concrete
setblock 288 280 640 minecraft:white_concrete
fill 288 280 641 288 280 644 minecraft:light_blue_concrete
setblock 288 280 645 minecraft:white_concrete
fill 289 280 605 292 280 605 minecraft:light_blue_concrete
setblock 289 280 606 minecraft:white_concrete
fill 289 280 610 292 280 610 minecraft:light_blue_concrete
setblock 289 280 611 minecraft:white_concrete
fill 289 280 612 289 280 615 minecraft:light_blue_concrete
setblock 289 280 616 minecraft:white_concrete
fill 289 280 617 289 280 620 minecraft:light_blue_concrete
setblock 289 280 621 minecraft:white_concrete
fill 289 280 622 289 280 625 minecraft:light_blue_concrete
setblock 289 280 626 minecraft:white_concrete
fill 289 280 627 293 280 627 minecraft:gold_block
fill 289 280 628 290 280 630 minecraft:light_blue_concrete
setblock 289 280 631 minecraft:white_concrete
fill 289 280 632 289 280 635 minecraft:light_blue_concrete
setblock 289 280 636 minecraft:white_concrete
fill 289 280 637 289 280 640 minecraft:light_blue_concrete
setblock 289 280 641 minecraft:white_concrete
fill 289 280 642 289 280 645 minecraft:light_blue_concrete
fill 290 280 606 293 280 606 minecraft:light_blue_concrete
setblock 290 280 607 minecraft:white_concrete
fill 290 280 611 293 280 611 minecraft:light_blue_concrete
setblock 290 280 612 minecraft:white_concrete
fill 290 280 613 290 280 616 minecraft:light_blue_concrete
setblock 290 280 617 minecraft:white_concrete
fill 290 280 618 290 280 621 minecraft:light_blue_concrete
setblock 290 280 622 minecraft:white_concrete
fill 290 280 623 290 280 626 minecraft:light_blue_concrete
fill 290 280 631 293 280 631 minecraft:light_blue_concrete
setblock 290 280 632 minecraft:white_concrete
fill 290 280 633 290 280 636 minecraft:light_blue_concrete
setblock 290 280 637 minecraft:white_concrete
fill 290 280 638 290 280 641 minecraft:light_blue_concrete
setblock 290 280 642 minecraft:white_concrete
fill 290 280 643 290 280 645 minecraft:light_blue_concrete
fill 291 280 607 294 280 607 minecraft:light_blue_concrete
setblock 291 280 608 minecraft:white_concrete
fill 291 280 612 294 280 612 minecraft:light_blue_concrete
setblock 291 280 613 minecraft:white_concrete
fill 291 280 614 291 280 617 minecraft:light_blue_concrete
setblock 291 280 618 minecraft:white_concrete
fill 291 280 619 291 280 622 minecraft:light_blue_concrete
setblock 291 280 623 minecraft:white_concrete
fill 291 280 624 291 280 626 minecraft:light_blue_concrete
setblock 291 280 628 minecraft:white_concrete
fill 291 280 629 291 280 630 minecraft:light_blue_concrete
fill 291 280 632 293 280 632 minecraft:light_blue_concrete
setblock 291 280 633 minecraft:white_concrete
fill 291 280 634 291 280 637 minecraft:light_blue_concrete
setblock 291 280 638 minecraft:white_concrete
fill 291 280 639 291 280 642 minecraft:light_blue_concrete
setblock 291 280 643 minecraft:white_concrete
fill 291 280 644 291 280 645 minecraft:light_blue_concrete
fill 292 280 608 295 280 608 minecraft:light_blue_concrete
setblock 292 280 609 minecraft:white_concrete
fill 292 280 613 295 280 613 minecraft:light_blue_concrete
setblock 292 280 614 minecraft:white_concrete
fill 292 280 615 292 280 618 minecraft:light_blue_concrete
setblock 292 280 619 minecraft:white_concrete
fill 292 280 621 292 280 623 minecraft:light_blue_concrete
setblock 292 280 624 minecraft:white_concrete
setblock 292 280 625 minecraft:light_blue_concrete
fill 292 280 626 296 280 626 minecraft:gold_block
fill 292 280 628 296 280 628 minecraft:gold_block
setblock 292 280 629 minecraft:white_concrete
setblock 292 280 630 minecraft:light_blue_concrete
setblock 292 280 633 minecraft:light_blue_concrete
fill 292 280 635 292 280 638 minecraft:light_blue_concrete
setblock 292 280 639 minecraft:white_concrete
fill 292 280 640 292 280 643 minecraft:light_blue_concrete
setblock 292 280 644 minecraft:white_concrete
setblock 292 280 645 minecraft:light_blue_concrete
setblock 293 280 605 minecraft:white_concrete
fill 293 280 609 296 280 609 minecraft:light_blue_concrete
setblock 293 280 610 minecraft:white_concrete
fill 293 280 614 296 280 614 minecraft:light_blue_concrete
setblock 293 280 615 minecraft:white_concrete
fill 293 280 616 293 280 619 minecraft:light_blue_concrete
fill 293 280 622 293 280 624 minecraft:light_blue_concrete
setblock 293 280 625 minecraft:white_concrete
fill 293 280 629 296 280 629 minecraft:light_blue_concrete
setblock 293 280 630 minecraft:white_concrete
setblock 293 280 635 minecraft:white_concrete
fill 293 280 636 293 280 639 minecraft:light_blue_concrete
setblock 293 280 640 minecraft:white_concrete
fill 293 280 641 293 280 644 minecraft:light_blue_concrete
setblock 293 280 645 minecraft:white_concrete
fill 294 280 605 297 280 605 minecraft:light_blue_concrete
setblock 294 280 606 minecraft:white_concrete
fill 294 280 610 297 280 610 minecraft:light_blue_concrete
setblock 294 280 611 minecraft:white_concrete
fill 294 280 615 297 280 615 minecraft:light_blue_concrete
setblock 294 280 616 minecraft:white_concrete
fill 294 280 617 294 280 619 minecraft:light_blue_concrete
fill 294 280 622 295 280 622 minecraft:gold_block
fill 294 280 623 294 280 625 minecraft:light_blue_concrete
fill 294 280 627 300 280 627 minecraft:white_concrete
fill 294 280 630 296 280 630 minecraft:light_blue_concrete
setblock 294 280 631 minecraft:white_concrete
fill 294 280 632 295 280 632 minecraft:gold_block
fill 294 280 635 297 280 635 minecraft:light_blue_concrete
setblock 294 280 636 minecraft:white_concrete
fill 294 280 637 294 280 640 minecraft:light_blue_concrete
setblock 294 280 641 minecraft:white_concrete
fill 294 280 642 294 280 645 minecraft:light_blue_concrete
fill 295 280 606 298 280 606 minecraft:light_blue_concrete
setblock 295 280 607 minecraft:white_concrete
fill 295 280 611 298 280 611 minecraft:light_blue_concrete
setblock 295 280 612 minecraft:white_concrete
fill 295 280 616 297 280 616 minecraft:light_blue_concrete
setblock 295 280 617 minecraft:white_concrete
fill 295 280 618 295 280 619 minecraft:light_blue_concrete
fill 295 280 623 296 280 623 minecraft:gold_block
fill 295 280 624 296 280 625 minecraft:light_blue_concrete
fill 295 280 631 296 280 631 minecraft:gold_block
fill 295 280 636 298 280 636 minecraft:light_blue_concrete
setblock 295 280 637 minecraft:white_concrete
fill 295 280 638 295 280 641 minecraft:light_blue_concrete
setblock 295 280 642 minecraft:white_concrete
fill 295 280 643 295 280 645 minecraft:light_blue_concrete
fill 296 280 607 299 280 607 minecraft:light_blue_concrete
setblock 296 280 608 minecraft:white_concrete
fill 296 280 612 299 280 612 minecraft:light_blue_concrete
setblock 296 280 613 minecraft:white_concrete
fill 296 280 617 297 280 617 minecraft:light_blue_concrete
setblock 296 280 618 minecraft:white_concrete
fill 296 280 619 296 280 620 minecraft:light_blue_concrete
fill 296 280 622 298 280 622 minecraft:white_concrete
fill 296 280 632 298 280 632 minecraft:white_concrete
setblock 296 280 634 minecraft:light_blue_concrete
fill 296 280 637 297 280 637 minecraft:light_blue_concrete
setblock 296 280 638 minecraft:white_concrete
fill 296 280 639 296 280 642 minecraft:light_blue_concrete
setblock 296 280 643 minecraft:white_concrete
fill 296 280 644 296 280 645 minecraft:light_blue_concrete
fill 297 280 608 300 280 608 minecraft:light_blue_concrete
setblock 297 280 609 minecraft:white_concrete
fill 297 280 613 300 280 613 minecraft:light_blue_concrete
setblock 297 280 614 minecraft:white_concrete
fill 297 280 618 298 280 618 minecraft:light_blue_concrete
setblock 297 280 619 minecraft:white_concrete
setblock 297 280 620 minecraft:light_blue_concrete
fill 297 280 623 300 280 623 minecraft:white_concrete
setblock 297 280 624 minecraft:gold_block
setblock 297 280 625 minecraft:light_blue_concrete
fill 297 280 626 301 280 626 minecraft:white_concrete
fill 297 280 628 297 280 629 minecraft:white_concrete
setblock 297 280 630 minecraft:gold_block
fill 297 280 631 300 280 631 minecraft:white_concrete
setblock 297 280 634 minecraft:white_concrete
setblock 297 280 638 minecraft:light_blue_concrete
setblock 297 280 639 minecraft:white_concrete
fill 297 280 640 297 280 643 minecraft:light_blue_concrete
setblock 297 280 644 minecraft:white_concrete
setblock 297 280 645 minecraft:light_blue_concrete
setblock 298 280 605 minecraft:white_concrete
fill 298 280 609 301 280 609 minecraft:light_blue_concrete
setblock 298 280 610 minecraft:white_concrete
setblock 298 280 619 minecraft:light_blue_concrete
setblock 298 280 620 minecraft:white_concrete
fill 298 280 624 302 280 624 minecraft:white_concrete
setblock 298 280 625 minecraft:gold_block
fill 298 280 628 301 280 628 minecraft:white_concrete
setblock 298 280 629 minecraft:gold_block
fill 298 280 630 302 280 630 minecraft:white_concrete
setblock 298 280 634 minecraft:light_blue_concrete
setblock 298 280 635 minecraft:white_concrete
fill 298 280 641 298 280 644 minecraft:light_blue_concrete
setblock 298 280 645 minecraft:white_concrete
fill 299 280 605 302 280 605 minecraft:light_blue_concrete
setblock 299 280 606 minecraft:white_concrete
fill 299 280 610 302 280 610 minecraft:light_blue_concrete
setblock 299 280 611 minecraft:white_concrete
fill 299 280 614 301 280 614 minecraft:light_blue_concrete
setblock 299 280 621 minecraft:white_concrete
fill 299 280 622 300 280 622 minecraft:gold_block
fill 299 280 625 301 280 625 minecraft:white_concrete
fill 299 280 629 301 280 629 minecraft:white_concrete
fill 299 280 632 300 280 632 minecraft:gold_block
setblock 299 280 633 minecraft:light_blue_concrete
fill 299 280 640 302 280 640 minecraft:light_blue_concrete
setblock 299 280 641 minecraft:white_concrete
fill 299 280 642 299 280 645 minecraft:light_blue_concrete
fill 300 280 606 303 280 606 minecraft:light_blue_concrete
setblock 300 280 607 minecraft:white_concrete
fill 300 280 611 303 280 611 minecraft:light_blue_concrete
setblock 300 280 612 minecraft:white_concrete
fill 300 280 615 302 280 615 minecraft:light_blue_concrete
fill 300 280 616 300 280 617 minecraft:gold_block
fill 300 280 618 300 280 620 minecraft:white_concrete
setblock 300 280 621 minecraft:gold_block
setblock 300 280 633 minecraft:gold_block
fill 300 280 634 300 280 636 minecraft:white_concrete
fill 300 280 637 300 280 638 minecraft:gold_block
fill 300 280 639 301 280 639 minecraft:light_blue_concrete
fill 300 280 641 303 280 641 minecraft:light_blue_concrete
setblock 300 280 642 minecraft:white_concrete
fill 300 280 643 300 280 645 minecraft:light_blue_concrete
fill 301 280 607 304 280 607 minecraft:light_blue_concrete
setblock 301 280 608 minecraft:white_concrete
fill 301 280 612 304 280 612 minecraft:light_blue_concrete
setblock 301 280 613 minecraft:white_concrete
fill 301 280 616 303 280 616 minecraft:light_blue_concrete
fill 301 280 617 301 280 618 minecraft:gold_block
fill 301 280 619 301 280 622 minecraft:white_concrete
setblock 301 280 623 minecraft:gold_block
fill 301 280 627 302 280 627 minecraft:pearlescent_froglight
setblock 301 280 631 minecraft:gold_block
fill 301 280 632 301 280 635 minecraft:white_concrete
fill 301 280 636 301 280 637 minecraft:gold_block
setblock 301 280 638 minecraft:white_concrete
fill 301 280 642 304 280 642 minecraft:light_blue_concrete
setblock 301 280 643 minecraft:white_concrete
fill 301 280 644 301 280 645 minecraft:light_blue_concrete
fill 302 280 608 305 280 608 minecraft:light_blue_concrete
setblock 302 280 609 minecraft:white_concrete
fill 302 280 613 304 280 613 minecraft:light_blue_concrete
setblock 302 280 614 minecraft:white_concrete
fill 302 280 617 303 280 618 minecraft:light_blue_concrete
setblock 302 280 619 minecraft:gold_block
fill 302 280 620 302 280 623 minecraft:white_concrete
fill 302 280 625 303 280 626 minecraft:pearlescent_froglight
fill 302 280 628 303 280 629 minecraft:pearlescent_froglight
fill 302 280 631 302 280 634 minecraft:white_concrete
setblock 302 280 635 minecraft:gold_block
fill 302 280 636 303 280 638 minecraft:light_blue_concrete
setblock 302 280 639 minecraft:white_concrete
fill 302 280 643 304 280 643 minecraft:light_blue_concrete
setblock 302 280 644 minecraft:white_concrete
setblock 302 280 645 minecraft:light_blue_concrete
setblock 303 280 605 minecraft:white_concrete
fill 303 280 609 306 280 609 minecraft:light_blue_concrete
setblock 303 280 610 minecraft:white_concrete
setblock 303 280 614 minecraft:light_blue_concrete
setblock 303 280 615 minecraft:white_concrete
setblock 303 280 619 minecraft:light_blue_concrete
setblock 303 280 620 minecraft:gold_block
fill 303 280 621 304 280 623 minecraft:white_concrete
fill 303 280 624 307 280 624 minecraft:pearlescent_froglight
fill 303 280 630 307 280 630 minecraft:pearlescent_froglight
fill 303 280 631 304 280 633 minecraft:white_concrete
setblock 303 280 634 minecraft:gold_block
fill 303 280 635 306 280 635 minecraft:white_concrete
setblock 303 280 639 minecraft:light_blue_concrete
setblock 303 280 640 minecraft:white_concrete
fill 303 280 644 306 280 644 minecraft:light_blue_concrete
setblock 303 280 645 minecraft:white_concrete
fill 304 280 605 307 280 605 minecraft:light_blue_concrete
setblock 304 280 606 minecraft:white_concrete
fill 304 280 610 307 280 610 minecraft:light_blue_concrete
setblock 304 280 611 minecraft:white_concrete
fill 304 280 614 304 280 618 minecraft:gold_block
fill 304 280 619 306 280 620 minecraft:white_concrete
setblock 304 280 625 minecraft:pearlescent_froglight
setblock 304 280 629 minecraft:pearlescent_froglight
fill 304 280 634 306 280 634 minecraft:white_concrete
fill 304 280 636 304 280 640 minecraft:gold_block
setblock 304 280 641 minecraft:white_concrete
fill 304 280 645 307 280 645 minecraft:light_blue_concrete
fill 305 280 606 308 280 606 minecraft:light_blue_concrete
setblock 305 280 607 minecraft:white_concrete
fill 305 280 614 306 280 615 minecraft:gold_block
fill 305 280 616 305 280 618 minecraft:white_concrete
fill 305 280 621 309 280 622 minecraft:white_concrete
setblock 305 280 623 minecraft:pearlescent_froglight
setblock 305 280 631 minecraft:pearlescent_froglight
fill 305 280 632 309 280 633 minecraft:white_concrete
fill 305 280 636 305 280 638 minecraft:white_concrete
fill 305 280 639 306 280 640 minecraft:gold_block
fill 306 280 607 309 280 607 minecraft:light_blue_concrete
setblock 306 280 608 minecraft:white_concrete
fill 306 280 611 308 280 612 minecraft:light_blue_concrete
setblock 306 280 613 minecraft:white_concrete
fill 306 280 616 306 280 618 minecraft:gold_block
fill 306 280 623 308 280 623 minecraft:white_concrete
fill 306 280 625 308 280 625 minecraft:pearlescent_froglight
fill 306 280 629 308 280 629 minecraft:pearlescent_froglight
fill 306 280 631 308 280 631 minecraft:white_concrete
fill 306 280 636 306 280 638 minecraft:gold_block
fill 306 280 641 308 280 642 minecraft:light_blue_concrete
setblock 306 280 643 minecraft:white_concrete
fill 307 280 608 310 280 608 minecraft:light_blue_concrete
setblock 307 280 609 minecraft:white_concrete
fill 307 280 613 310 280 613 minecraft:light_blue_concrete
setblock 307 280 614 minecraft:white_concrete
fill 307 280 615 307 280 618 minecraft:light_blue_concrete
setblock 307 280 619 minecraft:white_concrete
setblock 307 280 620 minecraft:gold_block
fill 307 280 626 308 280 626 minecraft:pearlescent_froglight
fill 307 280 628 308 280 628 minecraft:pearlescent_froglight
setblock 307 280 634 minecraft:gold_block
fill 307 280 635 307 280 638 minecraft:light_blue_concrete
setblock 307 280 639 minecraft:white_concrete
setblock 307 280 640 minecraft:light_blue_concrete
fill 307 280 643 310 280 643 minecraft:light_blue_concrete
setblock 307 280 644 minecraft:white_concrete
setblock 308 280 605 minecraft:white_concrete
fill 308 280 609 311 280 609 minecraft:light_blue_concrete
setblock 308 280 610 minecraft:white_concrete
fill 308 280 614 311 280 614 minecraft:light_blue_concrete
setblock 308 280 615 minecraft:white_concrete
fill 308 280 616 308 280 618 minecraft:light_blue_concrete
setblock 308 280 619 minecraft:gold_block
fill 308 280 620 310 280 620 minecraft:white_concrete
fill 308 280 624 312 280 624 minecraft:white_concrete
fill 308 280 627 309 280 627 minecraft:pearlescent_froglight
fill 308 280 630 312 280 630 minecraft:white_concrete
fill 308 280 634 310 280 634 minecraft:white_concrete
setblock 308 280 635 minecraft:gold_block
fill 308 280 636 308 280 639 minecraft:light_blue_concrete
setblock 308 280 640 minecraft:white_concrete
fill 308 280 644 311 280 644 minecraft:light_blue_concrete
setblock 308 280 645 minecraft:white_concrete
fill 309 280 605 312 280 605 minecraft:light_blue_concrete
setblock 309 280 606 minecraft:white_concrete
fill 309 280 610 312 280 610 minecraft:light_blue_concrete
setblock 309 280 611 minecraft:white_concrete
setblock 309 280 612 minecraft:light_blue_concrete
fill 309 280 615 310 280 615 minecraft:light_blue_concrete
setblock 309 280 616 minecraft:white_concrete
fill 309 280 617 309 280 618 minecraft:gold_block
fill 309 280 619 310 280 619 minecraft:white_concrete
setblock 309 280 623 minecraft:gold_block
fill 309 280 625 311 280 626 minecraft:white_concrete
fill 309 280 628 311 280 629 minecraft:white_concrete
setblock 309 280 631 minecraft:gold_block
fill 309 280 635 310 280 635 minecraft:white_concrete
fill 309 280 636 309 280 637 minecraft:gold_block
fill 309 280 638 309 280 640 minecraft:light_blue_concrete
setblock 309 280 641 minecraft:white_concrete
setblock 309 280 642 minecraft:light_blue_concrete
fill 309 280 645 312 280 645 minecraft:light_blue_concrete
fill 310 280 606 313 280 606 minecraft:light_blue_concrete
setblock 310 280 607 minecraft:white_concrete
fill 310 280 611 313 280 611 minecraft:light_blue_concrete
setblock 310 280 612 minecraft:white_concrete
fill 310 280 617 311 280 617 minecraft:gold_block
setblock 310 280 618 minecraft:white_concrete
fill 310 280 621 310 280 622 minecraft:gold_block
fill 310 280 623 313 280 623 minecraft:white_concrete
fill 310 280 627 316 280 627 minecraft:white_concrete
fill 310 280 631 313 280 631 minecraft:white_concrete
fill 310 280 632 310 280 633 minecraft:gold_block
setblock 310 280 636 minecraft:white_concrete
fill 310 280 637 311 280 637 minecraft:gold_block
fill 310 280 639 310 280 641 minecraft:light_blue_concrete
setblock 310 280 642 minecraft:white_concrete
fill 311 280 607 314 280 607 minecraft:light_blue_concrete
setblock 311 280 608 minecraft:white_concrete
fill 311 280 612 314 280 612 minecraft:light_blue_concrete
setblock 311 280 613 minecraft:white_concrete
fill 311 280 618 311 280 619 minecraft:gold_block
setblock 311 280 621 minecraft:light_blue_concrete
setblock 311 280 622 minecraft:gold_block
setblock 311 280 632 minecraft:gold_block
setblock 311 280 633 minecraft:white_concrete
fill 311 280 635 311 280 636 minecraft:gold_block
fill 311 280 640 311 280 642 minecraft:light_blue_concrete
setblock 311 280 643 minecraft:white_concrete
fill 312 280 608 315 280 608 minecraft:light_blue_concrete
setblock 312 280 609 minecraft:white_concrete
fill 312 280 613 315 280 613 minecraft:light_blue_concrete
fill 312 280 618 315 280 618 minecraft:light_blue_concrete
setblock 312 280 619 minecraft:white_concrete
setblock 312 280 620 minecraft:light_blue_concrete
fill 312 280 622 314 280 622 minecraft:white_concrete
setblock 312 280 625 minecraft:gold_block
fill 312 280 626 313 280 626 minecraft:white_concrete
fill 312 280 628 313 280 628 minecraft:white_concrete
setblock 312 280 629 minecraft:gold_block
fill 312 280 632 314 280 632 minecraft:white_concrete
setblock 312 280 634 minecraft:white_concrete
fill 312 280 635 312 280 636 minecraft:light_blue_concrete
fill 312 280 641 313 280 643 minecraft:light_blue_concrete
setblock 312 280 644 minecraft:white_concrete
setblock 313 280 605 minecraft:white_concrete
fill 313 280 609 316 280 609 minecraft:light_blue_concrete
setblock 313 280 610 minecraft:white_concrete
fill 313 280 614 316 280 614 minecraft:light_blue_concrete
setblock 313 280 615 minecraft:white_concrete
fill 313 280 616 313 280 617 minecraft:light_blue_concrete
fill 313 280 619 316 280 619 minecraft:light_blue_concrete
setblock 313 280 620 minecraft:white_concrete
setblock 313 280 624 minecraft:gold_block
setblock 313 280 625 minecraft:white_concrete
fill 313 280 629 316 280 629 minecraft:light_blue_concrete
setblock 313 280 630 minecraft:gold_block
fill 313 280 634 314 280 634 minecraft:light_blue_concrete
setblock 313 280 635 minecraft:white_concrete
fill 313 280 636 313 280 639 minecraft:light_blue_concrete
setblock 313 280 640 minecraft:white_concrete
fill 313 280 644 316 280 644 minecraft:light_blue_concrete
setblock 313 280 645 minecraft:white_concrete
fill 314 280 605 317 280 605 minecraft:light_blue_concrete
setblock 314 280 606 minecraft:white_concrete
fill 314 280 610 317 280 610 minecraft:light_blue_concrete
setblock 314 280 611 minecraft:white_concrete
fill 314 280 615 317 280 615 minecraft:light_blue_concrete
setblock 314 280 616 minecraft:white_concrete
setblock 314 280 617 minecraft:light_blue_concrete
setblock 314 280 620 minecraft:light_blue_concrete
fill 314 280 623 315 280 623 minecraft:gold_block
fill 314 280 624 316 280 625 minecraft:light_blue_concrete
fill 314 280 626 318 280 626 minecraft:gold_block
fill 314 280 628 318 280 628 minecraft:gold_block
fill 314 280 630 317 280 630 minecraft:light_blue_concrete
fill 314 280 631 315 280 631 minecraft:gold_block
fill 314 280 635 317 280 635 minecraft:light_blue_concrete
setblock 314 280 636 minecraft:white_concrete
fill 314 280 637 314 280 640 minecraft:light_blue_concrete
setblock 314 280 641 minecraft:white_concrete
fill 314 280 642 314 280 643 minecraft:light_blue_concrete
fill 314 280 645 317 280 645 minecraft:light_blue_concrete
fill 315 280 606 318 280 606 minecraft:light_blue_concrete
setblock 315 280 607 minecraft:white_concrete
fill 315 280 611 318 280 611 minecraft:light_blue_concrete
setblock 315 280 612 minecraft:white_concrete
fill 315 280 616 318 280 616 minecraft:light_blue_concrete
setblock 315 280 617 minecraft:white_concrete
fill 315 280 622 316 280 622 minecraft:gold_block
fill 315 280 632 316 280 632 minecraft:gold_block
fill 315 280 636 318 280 636 minecraft:light_blue_concrete
setblock 315 280 637 minecraft:white_concrete
fill 315 280 638 315 280 641 minecraft:light_blue_concrete
setblock 315 280 642 minecraft:white_concrete
setblock 315 280 643 minecraft:light_blue_concrete
fill 316 280 607 319 280 607 minecraft:light_blue_concrete
setblock 316 280 608 minecraft:white_concrete
fill 316 280 612 319 280 612 minecraft:light_blue_concrete
setblock 316 280 613 minecraft:white_concrete
fill 316 280 617 319 280 617 minecraft:light_blue_concrete
setblock 316 280 618 minecraft:white_concrete
setblock 316 280 623 minecraft:white_concrete
fill 316 280 631 318 280 631 minecraft:light_blue_concrete
fill 316 280 637 319 280 637 minecraft:light_blue_concrete
setblock 316 280 638 minecraft:white_concrete
fill 316 280 639 316 280 642 minecraft:light_blue_concrete
setblock 316 280 643 minecraft:white_concrete
fill 317 280 608 320 280 608 minecraft:light_blue_concrete
setblock 317 280 609 minecraft:white_concrete
fill 317 280 613 320 280 613 minecraft:light_blue_concrete
setblock 317 280 614 minecraft:white_concrete
fill 317 280 618 320 280 618 minecraft:light_blue_concrete
setblock 317 280 619 minecraft:white_concrete
fill 317 280 622 319 280 623 minecraft:light_blue_concrete
setblock 317 280 624 minecraft:white_concrete
setblock 317 280 625 minecraft:light_blue_concrete
fill 317 280 627 321 280 627 minecraft:gold_block
setblock 317 280 629 minecraft:white_concrete
fill 317 280 632 319 280 632 minecraft:light_blue_concrete
fill 317 280 638 320 280 638 minecraft:light_blue_concrete
setblock 317 280 639 minecraft:white_concrete
fill 317 280 640 317 280 643 minecraft:light_blue_concrete
setblock 317 280 644 minecraft:white_concrete
setblock 318 280 604 minecraft:pearlescent_froglight
setblock 318 280 605 minecraft:white_concrete
fill 318 280 609 321 280 609 minecraft:light_blue_concrete
setblock 318 280 610 minecraft:white_concrete
fill 318 280 614 321 280 614 minecraft:light_blue_concrete
setblock 318 280 615 minecraft:white_concrete
fill 318 280 619 321 280 619 minecraft:light_blue_concrete
setblock 318 280 621 minecraft:light_blue_concrete
fill 318 280 624 321 280 624 minecraft:light_blue_concrete
setblock 318 280 625 minecraft:white_concrete
fill 318 280 629 321 280 629 minecraft:light_blue_concrete
setblock 318 280 630 minecraft:white_concrete
fill 318 280 633 320 280 633 minecraft:light_blue_concrete
setblock 318 280 635 minecraft:white_concrete
fill 318 280 639 321 280 639 minecraft:light_blue_concrete
setblock 318 280 640 minecraft:white_concrete
fill 318 280 641 318 280 644 minecraft:light_blue_concrete
setblock 318 280 645 minecraft:white_concrete
fill 319 280 605 322 280 605 minecraft:light_blue_concrete
setblock 319 280 606 minecraft:white_concrete
fill 319 280 610 322 280 610 minecraft:light_blue_concrete
setblock 319 280 611 minecraft:white_concrete
fill 319 280 615 322 280 615 minecraft:light_blue_concrete
setblock 319 280 616 minecraft:white_concrete
fill 319 280 620 322 280 620 minecraft:light_blue_concrete
setblock 319 280 621 minecraft:white_concrete
fill 319 280 625 322 280 625 minecraft:light_blue_concrete
setblock 319 280 626 minecraft:white_concrete
fill 319 280 628 320 280 628 minecraft:light_blue_concrete
fill 319 280 630 322 280 630 minecraft:light_blue_concrete
setblock 319 280 631 minecraft:white_concrete
fill 319 280 634 321 280 635 minecraft:light_blue_concrete
setblock 319 280 636 minecraft:white_concrete
fill 319 280 640 322 280 640 minecraft:light_blue_concrete
setblock 319 280 641 minecraft:white_concrete
fill 319 280 642 319 280 645 minecraft:light_blue_concrete
fill 320 280 606 323 280 606 minecraft:light_blue_concrete
setblock 320 280 607 minecraft:white_concrete
fill 320 280 611 323 280 611 minecraft:light_blue_concrete
setblock 320 280 612 minecraft:white_concrete
fill 320 280 616 323 280 616 minecraft:light_blue_concrete
setblock 320 280 617 minecraft:white_concrete
fill 320 280 621 323 280 621 minecraft:light_blue_concrete
setblock 320 280 622 minecraft:white_concrete
setblock 320 280 623 minecraft:light_blue_concrete
fill 320 280 626 323 280 626 minecraft:light_blue_concrete
fill 320 280 631 323 280 631 minecraft:light_blue_concrete
setblock 320 280 632 minecraft:white_concrete
fill 320 280 636 323 280 636 minecraft:light_blue_concrete
setblock 320 280 637 minecraft:white_concrete
fill 320 280 641 323 280 641 minecraft:light_blue_concrete
setblock 320 280 642 minecraft:white_concrete
fill 320 280 643 320 280 645 minecraft:light_blue_concrete
fill 321 280 607 323 280 607 minecraft:light_blue_concrete
setblock 321 280 608 minecraft:white_concrete
fill 321 280 612 323 280 612 minecraft:light_blue_concrete
setblock 321 280 613 minecraft:white_concrete
fill 321 280 617 323 280 617 minecraft:light_blue_concrete
setblock 321 280 618 minecraft:white_concrete
fill 321 280 622 323 280 622 minecraft:light_blue_concrete
setblock 321 280 623 minecraft:white_concrete
setblock 321 280 628 minecraft:white_concrete
fill 321 280 632 323 280 632 minecraft:light_blue_concrete
setblock 321 280 633 minecraft:white_concrete
fill 321 280 637 323 280 637 minecraft:light_blue_concrete
setblock 321 280 638 minecraft:white_concrete
fill 321 280 642 323 280 642 minecraft:light_blue_concrete
setblock 321 280 643 minecraft:white_concrete
fill 321 280 644 321 280 645 minecraft:light_blue_concrete
fill 322 280 608 323 280 608 minecraft:light_blue_concrete
setblock 322 280 609 minecraft:white_concrete
fill 322 280 613 323 280 613 minecraft:light_blue_concrete
setblock 322 280 614 minecraft:white_concrete
fill 322 280 618 323 280 618 minecraft:light_blue_concrete
setblock 322 280 619 minecraft:white_concrete
fill 322 280 623 323 280 623 minecraft:light_blue_concrete
setblock 322 280 624 minecraft:white_concrete
fill 322 280 627 323 280 628 minecraft:light_blue_concrete
setblock 322 280 629 minecraft:white_concrete
fill 322 280 633 323 280 633 minecraft:light_blue_concrete
setblock 322 280 634 minecraft:white_concrete
setblock 322 280 635 minecraft:light_blue_concrete
fill 322 280 638 323 280 638 minecraft:light_blue_concrete
setblock 322 280 639 minecraft:white_concrete
fill 322 280 643 323 280 643 minecraft:light_blue_concrete
setblock 322 280 644 minecraft:white_concrete
setblock 322 280 645 minecraft:light_blue_concrete
setblock 323 280 605 minecraft:white_concrete
setblock 323 280 609 minecraft:light_blue_concrete
setblock 323 280 610 minecraft:white_concrete
setblock 323 280 614 minecraft:light_blue_concrete
setblock 323 280 615 minecraft:white_concrete
setblock 323 280 619 minecraft:light_blue_concrete
setblock 323 280 620 minecraft:white_concrete
setblock 323 280 624 minecraft:light_blue_concrete
setblock 323 280 625 minecraft:white_concrete
setblock 323 280 629 minecraft:light_blue_concrete
setblock 323 280 630 minecraft:white_concrete
setblock 323 280 634 minecraft:light_blue_concrete
setblock 323 280 635 minecraft:white_concrete
setblock 323 280 639 minecraft:light_blue_concrete
setblock 323 280 640 minecraft:white_concrete
setblock 323 280 644 minecraft:light_blue_concrete
setblock 323 280 645 minecraft:white_concrete
setblock 324 280 608 minecraft:pearlescent_froglight
fill 324 280 629 324 307 629 minecraft:white_concrete
fill 318 281 604 318 287 604 minecraft:white_concrete
fill 324 281 608 324 307 608 minecraft:white_concrete
setblock 282 282 623 minecraft:pearlescent_froglight
fill 282 282 624 282 307 625 minecraft:white_concrete
setblock 285 282 607 minecraft:light[level=13]
setblock 285 282 615 minecraft:light[level=13]
setblock 285 282 623 minecraft:light[level=13]
setblock 285 282 631 minecraft:light[level=13]
setblock 285 282 639 minecraft:light[level=13]
setblock 293 282 607 minecraft:light[level=13]
setblock 293 282 615 minecraft:light[level=13]
setblock 293 282 623 minecraft:light[level=13]
setblock 293 282 631 minecraft:light[level=13]
setblock 293 282 639 minecraft:light[level=13]
setblock 301 282 607 minecraft:light[level=13]
setblock 301 282 615 minecraft:light[level=13]
setblock 301 282 623 minecraft:light[level=13]
setblock 301 282 631 minecraft:light[level=13]
setblock 301 282 639 minecraft:light[level=13]
fill 307 282 646 310 285 646 minecraft:white_concrete
setblock 309 282 607 minecraft:light[level=13]
setblock 309 282 615 minecraft:light[level=13]
setblock 309 282 623 minecraft:light[level=13]
setblock 309 282 631 minecraft:light[level=13]
setblock 309 282 639 minecraft:light[level=13]
setblock 311 282 646 minecraft:pearlescent_froglight
setblock 317 282 607 minecraft:light[level=13]
setblock 317 282 615 minecraft:light[level=13]
setblock 317 282 623 minecraft:light[level=13]
setblock 317 282 631 minecraft:light[level=13]
setblock 317 282 639 minecraft:light[level=13]
setblock 324 282 613 minecraft:amethyst_block
setblock 324 282 640 minecraft:amethyst_block
fill 282 283 613 282 284 617 minecraft:white_concrete
setblock 282 283 618 minecraft:amethyst_block
fill 282 283 619 282 307 619 minecraft:white_concrete
fill 282 283 623 282 285 623 minecraft:white_concrete
fill 311 283 646 311 307 646 minecraft:white_concrete
fill 324 283 613 324 307 613 minecraft:white_concrete
fill 324 283 640 324 307 640 minecraft:white_concrete
fill 282 284 618 282 307 618 minecraft:white_concrete
setblock 282 284 620 minecraft:amethyst_block
fill 307 284 643 308 285 644 minecraft:white_concrete
fill 309 284 643 309 285 643 minecraft:white_concrete
fill 324 284 616 324 285 618 minecraft:white_concrete
setblock 324 284 619 minecraft:amethyst_block
fill 282 285 613 282 307 615 minecraft:white_concrete
setblock 282 285 616 minecraft:amethyst_block
fill 282 285 617 282 307 617 minecraft:white_concrete
fill 282 285 620 282 307 620 minecraft:white_concrete
fill 288 285 620 288 286 620 minecraft:obsidian
setblock 324 285 609 minecraft:amethyst_block
fill 324 285 619 324 307 619 minecraft:white_concrete
fill 282 286 616 282 301 616 minecraft:white_concrete
setblock 282 286 623 minecraft:pearlescent_froglight
fill 307 286 646 309 296 646 minecraft:white_concrete
setblock 310 286 646 minecraft:pearlescent_froglight
fill 324 286 609 324 307 609 minecraft:white_concrete
fill 324 286 616 324 294 617 minecraft:white_concrete
setblock 324 286 618 minecraft:pearlescent_froglight
fill 282 287 623 282 307 623 minecraft:white_concrete
fill 287 287 604 287 307 604 minecraft:white_concrete
setblock 288 287 604 minecraft:pearlescent_froglight
fill 289 287 604 289 307 604 minecraft:white_concrete
fill 310 287 646 310 307 646 minecraft:white_concrete
fill 324 287 618 324 307 618 minecraft:white_concrete
setblock 324 287 644 minecraft:pearlescent_froglight
fill 282 288 612 282 290 612 minecraft:gold_block
fill 282 288 628 282 290 628 minecraft:gold_block
fill 282 288 644 282 290 644 minecraft:gold_block
fill 286 288 604 286 290 604 minecraft:gold_block
fill 288 288 604 288 307 604 minecraft:white_concrete
fill 296 288 646 296 290 646 minecraft:gold_block
setblock 301 288 604 minecraft:pearlescent_froglight
fill 302 288 604 302 290 604 minecraft:gold_block
fill 312 288 646 312 290 646 minecraft:gold_block
fill 318 288 604 318 290 604 minecraft:gold_block
fill 324 288 614 324 290 614 minecraft:gold_block
fill 324 288 630 324 290 630 minecraft:gold_block
fill 324 288 644 324 307 644 minecraft:white_concrete
fill 286 289 646 286 299 646 minecraft:white_concrete
setblock 287 289 646 minecraft:amethyst_block
fill 288 289 646 292 300 646 minecraft:white_concrete
fill 301 289 604 301 307 604 minecraft:white_concrete
fill 311 289 616 311 290 616 minecraft:gold_block
fill 314 289 636 316 290 636 minecraft:amethyst_block
fill 315 289 635 315 290 635 minecraft:amethyst_block
fill 315 289 637 315 290 637 minecraft:amethyst_block
setblock 324 289 634 minecraft:amethyst_block
setblock 285 290 607 minecraft:light[level=13]
setblock 285 290 615 minecraft:light[level=13]
setblock 285 290 623 minecraft:light[level=13]
setblock 285 290 631 minecraft:light[level=13]
setblock 285 290 639 minecraft:light[level=13]
fill 287 290 646 287 307 646 minecraft:white_concrete
setblock 293 290 607 minecraft:light[level=13]
setblock 293 290 615 minecraft:light[level=13]
setblock 293 290 623 minecraft:light[level=13]
setblock 293 290 631 minecraft:light[level=13]
setblock 293 290 639 minecraft:light[level=13]
setblock 301 290 607 minecraft:light[level=13]
setblock 301 290 615 minecraft:light[level=13]
setblock 301 290 623 minecraft:light[level=13]
setblock 301 290 631 minecraft:light[level=13]
setblock 301 290 639 minecraft:light[level=13]
setblock 309 290 607 minecraft:light[level=13]
setblock 309 290 615 minecraft:light[level=13]
setblock 309 290 623 minecraft:light[level=13]
setblock 309 290 631 minecraft:light[level=13]
setblock 309 290 639 minecraft:light[level=13]
setblock 317 290 607 minecraft:light[level=13]
setblock 317 290 615 minecraft:light[level=13]
setblock 317 290 623 minecraft:light[level=13]
setblock 317 290 631 minecraft:light[level=13]
setblock 317 290 639 minecraft:light[level=13]
fill 324 290 634 324 307 634 minecraft:white_concrete
fill 282 291 612 282 296 612 minecraft:white_concrete
fill 282 291 628 282 296 628 minecraft:white_concrete
setblock 282 291 635 minecraft:amethyst_block
fill 282 291 644 282 296 644 minecraft:white_concrete
setblock 284 291 604 minecraft:pearlescent_froglight
fill 286 291 604 286 292 604 minecraft:white_concrete
setblock 296 291 646 minecraft:pearlescent_froglight
fill 302 291 604 302 296 604 minecraft:white_concrete
fill 302 291 605 304 293 607 minecraft:amethyst_block
fill 303 291 608 303 292 610 minecraft:amethyst_block
fill 312 291 646 312 296 646 minecraft:white_concrete
fill 318 291 604 318 296 604 minecraft:white_concrete
fill 324 291 614 324 296 614 minecraft:white_concrete
setblock 324 291 615 minecraft:amethyst_block
fill 324 291 630 324 296 630 minecraft:white_concrete
fill 282 292 635 282 307 635 minecraft:white_concrete
fill 284 292 604 284 307 604 minecraft:white_concrete
fill 296 292 646 296 296 646 minecraft:white_concrete
fill 301 292 605 301 293 606 minecraft:amethyst_block
fill 302 292 608 302 292 609 minecraft:amethyst_block
fill 304 292 608 304 292 609 minecraft:amethyst_block
fill 304 292 633 305 293 634 minecraft:gold_block
fill 305 292 605 305 293 606 minecraft:amethyst_block
fill 324 292 615 324 307 615 minecraft:white_concrete
setblock 286 293 604 minecraft:pearlescent_froglight
fill 302 293 608 304 293 608 minecraft:amethyst_block
setblock 319 293 646 minecraft:pearlescent_froglight
fill 324 293 636 324 307 636 minecraft:white_concrete
setblock 324 293 637 minecraft:amethyst_block
fill 286 294 604 286 296 604 minecraft:white_concrete
fill 302 294 605 304 294 606 minecraft:amethyst_block
setblock 303 294 607 minecraft:amethyst_block
setblock 305 294 646 minecraft:amethyst_block
fill 319 294 646 319 307 646 minecraft:white_concrete
fill 324 294 637 324 307 637 minecraft:white_concrete
fill 282 295 604 282 307 604 minecraft:white_concrete
setblock 283 295 604 minecraft:amethyst_block
setblock 304 295 604 minecraft:pearlescent_froglight
fill 305 295 646 305 302 646 minecraft:white_concrete
setblock 324 295 616 minecraft:pearlescent_froglight
fill 324 295 617 324 307 617 minecraft:white_concrete
fill 283 296 604 283 307 604 minecraft:white_concrete
fill 304 296 604 304 307 604 minecraft:white_concrete
fill 324 296 616 324 304 616 minecraft:white_concrete
fill 282 297 612 282 299 612 minecraft:gold_block
fill 282 297 628 282 299 628 minecraft:gold_block
setblock 282 297 638 minecraft:pearlescent_froglight
fill 282 297 644 282 299 644 minecraft:gold_block
fill 286 297 604 286 299 604 minecraft:gold_block
fill 296 297 646 296 299 646 minecraft:gold_block
fill 302 297 604 302 299 604 minecraft:gold_block
fill 307 297 646 307 307 646 minecraft:white_concrete
setblock 308 297 646 minecraft:amethyst_block
fill 309 297 646 309 307 646 minecraft:white_concrete
fill 312 297 646 312 299 646 minecraft:gold_block
fill 318 297 604 318 299 604 minecraft:gold_block
fill 324 297 614 324 299 614 minecraft:gold_block
fill 324 297 630 324 299 630 minecraft:gold_block
fill 282 298 638 282 307 638 minecraft:white_concrete
setblock 285 298 607 minecraft:light[level=13]
setblock 285 298 615 minecraft:light[level=13]
setblock 285 298 623 minecraft:light[level=13]
setblock 285 298 631 minecraft:light[level=13]
setblock 285 298 639 minecraft:light[level=13]
setblock 293 298 607 minecraft:light[level=13]
setblock 293 298 615 minecraft:light[level=13]
setblock 293 298 623 minecraft:light[level=13]
setblock 293 298 631 minecraft:light[level=13]
setblock 293 298 639 minecraft:light[level=13]
setblock 301 298 607 minecraft:light[level=13]
setblock 301 298 615 minecraft:light[level=13]
setblock 301 298 623 minecraft:light[level=13]
setblock 301 298 631 minecraft:light[level=13]
setblock 301 298 639 minecraft:light[level=13]
fill 308 298 646 308 307 646 minecraft:white_concrete
setblock 309 298 607 minecraft:light[level=13]
setblock 309 298 615 minecraft:light[level=13]
setblock 309 298 623 minecraft:light[level=13]
setblock 309 298 631 minecraft:light[level=13]
setblock 309 298 639 minecraft:light[level=13]
setblock 317 298 607 minecraft:light[level=13]
setblock 317 298 615 minecraft:light[level=13]
setblock 317 298 623 minecraft:light[level=13]
setblock 317 298 631 minecraft:light[level=13]
setblock 317 298 639 minecraft:light[level=13]
fill 313 299 621 313 300 622 minecraft:amethyst_block
fill 282 300 612 282 303 612 minecraft:white_concrete
fill 282 300 628 282 307 628 minecraft:white_concrete
fill 282 300 644 282 307 644 minecraft:white_concrete
fill 286 300 604 286 307 604 minecraft:white_concrete
setblock 286 300 646 minecraft:amethyst_block
fill 296 300 646 296 307 646 minecraft:white_concrete
setblock 302 300 604 minecraft:white_concrete
fill 312 300 646 312 306 646 minecraft:white_concrete
fill 318 300 604 318 307 604 minecraft:white_concrete
fill 324 300 614 324 307 614 minecraft:white_concrete
setblock 324 300 620 minecraft:pearlescent_froglight
fill 324 300 630 324 307 630 minecraft:white_concrete
fill 286 301 646 286 302 646 minecraft:white_concrete
fill 288 301 646 289 307 646 minecraft:white_concrete
setblock 290 301 646 minecraft:pearlescent_froglight
fill 291 301 604 291 307 604 minecraft:white_concrete
fill 291 301 646 292 307 646 minecraft:white_concrete
setblock 292 301 604 minecraft:amethyst_block
fill 293 301 604 293 303 604 minecraft:white_concrete
setblock 302 301 604 minecraft:amethyst_block
setblock 308 301 604 minecraft:amethyst_block
fill 309 301 604 309 307 604 minecraft:white_concrete
fill 324 301 620 324 307 620 minecraft:white_concrete
setblock 282 302 616 minecraft:pearlescent_froglight
fill 290 302 646 290 307 646 minecraft:white_concrete
fill 292 302 604 292 307 604 minecraft:white_concrete
fill 302 302 604 302 307 604 minecraft:white_concrete
fill 308 302 604 308 307 604 minecraft:white_concrete
setblock 282 303 611 minecraft:amethyst_block
fill 282 303 616 282 307 616 minecraft:white_concrete
setblock 286 303 646 minecraft:amethyst_block
setblock 305 303 646 minecraft:amethyst_block
setblock 324 303 610 minecraft:pearlescent_froglight
setblock 282 304 611 minecraft:white_concrete
setblock 282 304 612 minecraft:pearlescent_froglight
fill 286 304 646 286 307 646 minecraft:white_concrete
setblock 293 304 604 minecraft:pearlescent_froglight
fill 305 304 646 305 307 646 minecraft:white_concrete
fill 320 304 604 321 307 604 minecraft:white_concrete
setblock 322 304 604 minecraft:amethyst_block
fill 324 304 610 324 307 610 minecraft:white_concrete
setblock 282 305 611 minecraft:amethyst_block
fill 282 305 612 282 306 612 minecraft:white_concrete
fill 293 305 604 293 307 604 minecraft:white_concrete
setblock 316 305 646 minecraft:pearlescent_froglight
fill 322 305 604 322 307 604 minecraft:white_concrete
setblock 324 305 616 minecraft:pearlescent_froglight
fill 282 306 611 282 307 611 minecraft:white_concrete
fill 316 306 646 316 307 646 minecraft:white_concrete
fill 324 306 616 324 307 616 minecraft:white_concrete
setblock 282 307 612 minecraft:amethyst_block
setblock 312 307 646 minecraft:pearlescent_froglight
setblock 313 307 646 minecraft:amethyst_block
