setblock 417 290 313 minecraft:stripped_oak_log
fill 417 290 314 417 293 314 minecraft:red_terracotta
setblock 377 291 276 minecraft:red_terracotta
setblock 377 291 292 minecraft:stripped_oak_log
fill 377 291 293 377 291 296 minecraft:red_terracotta
setblock 377 291 297 minecraft:stripped_oak_log
fill 377 291 298 377 291 301 minecraft:red_terracotta
setblock 377 291 302 minecraft:stripped_oak_log
setblock 377 291 307 minecraft:stripped_oak_log
setblock 377 291 308 minecraft:red_terracotta
setblock 377 291 312 minecraft:stripped_oak_log
fill 377 291 313 377 294 313 minecraft:red_terracotta
fill 378 291 298 378 292 299 minecraft:stripped_oak_log
setblock 378 291 312 minecraft:red_terracotta
setblock 378 291 316 minecraft:stripped_oak_log
fill 379 291 299 386 292 299 minecraft:stripped_oak_log
setblock 379 291 315 minecraft:stripped_oak_log
fill 379 291 316 379 294 316 minecraft:red_terracotta
setblock 383 291 316 minecraft:stripped_oak_log
setblock 384 291 315 minecraft:stripped_oak_log
fill 384 291 316 384 294 316 minecraft:red_terracotta
fill 386 291 276 387 291 276 minecraft:red_terracotta
setblock 388 291 276 minecraft:stripped_oak_log
setblock 388 291 316 minecraft:stripped_oak_log
fill 389 291 276 389 294 276 minecraft:red_terracotta
setblock 389 291 315 minecraft:stripped_oak_log
fill 389 291 316 392 291 316 minecraft:red_terracotta
fill 390 291 314 390 296 314 minecraft:stripped_oak_log
setblock 390 291 315 minecraft:red_terracotta
setblock 391 291 277 minecraft:red_terracotta
setblock 392 291 277 minecraft:stripped_oak_log
setblock 393 291 276 minecraft:stripped_oak_log
fill 393 291 277 393 294 277 minecraft:red_terracotta
fill 393 291 307 393 297 307 minecraft:brown_terracotta
fill 393 291 310 393 297 310 minecraft:brown_terracotta
setblock 393 291 316 minecraft:stripped_oak_log
fill 394 291 276 394 294 276 minecraft:red_terracotta
fill 394 291 309 394 297 309 minecraft:brown_terracotta
setblock 394 291 315 minecraft:stripped_oak_log
fill 394 291 316 394 293 316 minecraft:red_terracotta
setblock 398 291 276 minecraft:stripped_oak_log
fill 399 291 276 399 294 276 minecraft:red_terracotta
setblock 403 291 276 minecraft:stripped_oak_log
setblock 403 291 316 minecraft:stripped_oak_log
fill 404 291 276 404 294 276 minecraft:red_terracotta
fill 404 291 316 407 291 316 minecraft:red_terracotta
fill 406 291 315 408 291 315 minecraft:red_terracotta
setblock 407 291 277 minecraft:stripped_oak_log
setblock 408 291 276 minecraft:stripped_oak_log
setblock 408 291 277 minecraft:red_terracotta
setblock 408 291 316 minecraft:stripped_oak_log
setblock 409 291 276 minecraft:red_terracotta
setblock 409 291 314 minecraft:red_terracotta
setblock 409 291 315 minecraft:stripped_oak_log
fill 409 291 316 409 294 316 minecraft:red_terracotta
setblock 410 291 314 minecraft:stripped_oak_log
fill 410 291 315 410 294 315 minecraft:red_terracotta
setblock 411 291 278 minecraft:stripped_oak_log
fill 411 291 314 411 294 314 minecraft:red_terracotta
setblock 412 291 277 minecraft:stripped_oak_log
fill 412 291 278 412 294 278 minecraft:red_terracotta
setblock 412 291 279 minecraft:stripped_oak_log
setblock 413 291 276 minecraft:stripped_oak_log
fill 413 291 277 413 294 277 minecraft:red_terracotta
setblock 413 291 316 minecraft:stripped_oak_log
fill 414 291 276 414 294 276 minecraft:red_terracotta
setblock 414 291 315 minecraft:stripped_oak_log
fill 414 291 316 414 294 316 minecraft:red_terracotta
fill 415 291 304 415 297 304 minecraft:green_concrete
fill 415 291 312 415 300 312 minecraft:stripped_oak_log
setblock 415 291 314 minecraft:stripped_oak_log
fill 415 291 315 415 294 315 minecraft:red_terracotta
fill 416 291 278 416 295 278 minecraft:stripped_oak_log
fill 416 291 310 416 300 310 minecraft:stripped_oak_log
setblock 416 291 313 minecraft:stripped_oak_log
fill 416 291 314 416 293 314 minecraft:red_terracotta
setblock 417 291 277 minecraft:stripped_oak_log
fill 417 291 278 417 291 279 minecraft:red_terracotta
setblock 417 291 280 minecraft:stripped_oak_log
setblock 417 291 293 minecraft:red_terracotta
setblock 417 291 297 minecraft:stripped_oak_log
setblock 417 291 312 minecraft:stripped_oak_log
fill 417 291 313 417 294 313 minecraft:red_terracotta
fill 376 292 275 376 295 317 minecraft:white_terracotta
fill 377 292 275 418 295 275 minecraft:white_terracotta
fill 377 292 293 377 292 295 minecraft:red_terracotta
setblock 377 292 296 minecraft:stripped_oak_log
fill 377 292 297 377 292 300 minecraft:red_terracotta
setblock 377 292 301 minecraft:stripped_oak_log
setblock 377 292 311 minecraft:stripped_oak_log
fill 377 292 312 377 293 312 minecraft:red_terracotta
setblock 377 292 316 minecraft:stripped_oak_log
fill 377 292 317 418 295 317 minecraft:white_terracotta
fill 378 292 316 378 294 316 minecraft:red_terracotta
fill 379 292 298 382 292 298 minecraft:stripped_oak_log
setblock 382 292 316 minecraft:stripped_oak_log
fill 383 292 316 383 295 316 minecraft:red_terracotta
fill 384 292 300 392 292 300 minecraft:stripped_oak_log
setblock 384 292 307 minecraft:shroomlight
setblock 384 292 309 minecraft:shroomlight
setblock 384 292 311 minecraft:shroomlight
setblock 384 292 313 minecraft:shroomlight
setblock 384 292 315 minecraft:shroomlight
setblock 385 292 308 minecraft:shroomlight
setblock 385 292 310 minecraft:shroomlight
setblock 385 292 312 minecraft:shroomlight
setblock 385 292 314 minecraft:shroomlight
fill 385 292 315 385 296 315 minecraft:stripped_oak_log
setblock 385 292 316 minecraft:shroomlight
setblock 386 292 276 minecraft:red_terracotta
setblock 386 292 307 minecraft:shroomlight
setblock 386 292 309 minecraft:shroomlight
setblock 386 292 311 minecraft:shroomlight
setblock 386 292 313 minecraft:shroomlight
setblock 386 292 315 minecraft:shroomlight
setblock 387 292 276 minecraft:stripped_oak_log
fill 387 292 299 392 293 299 minecraft:stripped_oak_log
setblock 387 292 308 minecraft:shroomlight
setblock 387 292 310 minecraft:shroomlight
setblock 387 292 312 minecraft:shroomlight
setblock 387 292 314 minecraft:shroomlight
setblock 387 292 316 minecraft:shroomlight
fill 388 292 276 388 295 276 minecraft:red_terracotta
setblock 388 292 307 minecraft:shroomlight
setblock 388 292 309 minecraft:shroomlight
setblock 388 292 311 minecraft:shroomlight
setblock 388 292 313 minecraft:shroomlight
fill 388 292 314 388 296 314 minecraft:stripped_oak_log
setblock 388 292 315 minecraft:shroomlight
fill 388 292 316 388 295 316 minecraft:red_terracotta
setblock 389 292 308 minecraft:shroomlight
setblock 389 292 310 minecraft:shroomlight
setblock 389 292 312 minecraft:shroomlight
setblock 389 292 314 minecraft:shroomlight
fill 389 292 315 389 293 315 minecraft:red_terracotta
setblock 389 292 316 minecraft:shroomlight
setblock 390 292 277 minecraft:red_terracotta
setblock 390 292 307 minecraft:shroomlight
setblock 390 292 309 minecraft:shroomlight
setblock 390 292 311 minecraft:shroomlight
setblock 390 292 313 minecraft:shroomlight
setblock 390 292 315 minecraft:shroomlight
fill 390 292 316 390 293 316 minecraft:red_terracotta
setblock 391 292 277 minecraft:stripped_oak_log
setblock 391 292 308 minecraft:shroomlight
setblock 391 292 310 minecraft:shroomlight
setblock 391 292 312 minecraft:shroomlight
setblock 391 292 314 minecraft:shroomlight
setblock 391 292 315 minecraft:red_terracotta
setblock 391 292 316 minecraft:shroomlight
setblock 392 292 276 minecraft:stripped_oak_log
fill 392 292 277 392 295 277 minecraft:red_terracotta
setblock 392 292 307 minecraft:shroomlight
setblock 392 292 309 minecraft:shroomlight
setblock 392 292 311 minecraft:shroomlight
setblock 392 292 313 minecraft:shroomlight
setblock 392 292 315 minecraft:shroomlight
setblock 392 292 316 minecraft:stripped_oak_log
fill 393 292 276 393 295 276 minecraft:red_terracotta
fill 393 292 316 393 294 316 minecraft:red_terracotta
fill 394 292 307 394 297 307 minecraft:brown_terracotta
fill 394 292 310 394 297 310 minecraft:brown_terracotta
fill 395 292 308 395 297 308 minecraft:brown_terracotta
setblock 397 292 276 minecraft:stripped_oak_log
fill 398 292 276 398 295 276 minecraft:red_terracotta
fill 399 292 299 399 293 300 minecraft:stripped_oak_log
setblock 402 292 276 minecraft:stripped_oak_log
fill 403 292 276 403 295 276 minecraft:red_terracotta
fill 403 292 316 406 292 316 minecraft:red_terracotta
fill 404 292 277 404 293 277 minecraft:red_terracotta
fill 405 292 300 406 293 300 minecraft:stripped_oak_log
setblock 406 292 277 minecraft:shroomlight
setblock 406 292 279 minecraft:shroomlight
setblock 406 292 281 minecraft:shroomlight
fill 406 292 315 407 292 315 minecraft:red_terracotta
setblock 407 292 276 minecraft:shroomlight
fill 407 292 277 407 295 277 minecraft:red_terracotta
setblock 407 292 278 minecraft:shroomlight
setblock 407 292 280 minecraft:shroomlight
setblock 407 292 316 minecraft:stripped_oak_log
fill 408 292 276 408 295 276 minecraft:red_terracotta
setblock 408 292 277 minecraft:shroomlight
fill 408 292 278 408 293 278 minecraft:red_terracotta
setblock 408 292 279 minecraft:shroomlight
setblock 408 292 281 minecraft:shroomlight
setblock 408 292 283 minecraft:shroomlight
setblock 408 292 285 minecraft:shroomlight
setblock 408 292 287 minecraft:shroomlight
setblock 408 292 315 minecraft:stripped_oak_log
fill 408 292 316 408 295 316 minecraft:red_terracotta
setblock 409 292 276 minecraft:shroomlight
fill 409 292 277 409 293 277 minecraft:red_terracotta
setblock 409 292 278 minecraft:shroomlight
setblock 409 292 280 minecraft:shroomlight
setblock 409 292 282 minecraft:shroomlight
setblock 409 292 284 minecraft:shroomlight
setblock 409 292 286 minecraft:shroomlight
setblock 409 292 314 minecraft:stripped_oak_log
fill 409 292 315 409 295 315 minecraft:red_terracotta
fill 410 292 276 410 293 276 minecraft:red_terracotta
setblock 410 292 277 minecraft:shroomlight
setblock 410 292 278 minecraft:stripped_oak_log
setblock 410 292 279 minecraft:shroomlight
setblock 410 292 281 minecraft:shroomlight
setblock 410 292 283 minecraft:shroomlight
setblock 410 292 285 minecraft:shroomlight
setblock 410 292 287 minecraft:shroomlight
fill 410 292 314 410 293 314 minecraft:red_terracotta
setblock 411 292 276 minecraft:shroomlight
setblock 411 292 277 minecraft:stripped_oak_log
setblock 411 292 278 minecraft:shroomlight
setblock 411 292 280 minecraft:shroomlight
setblock 411 292 282 minecraft:shroomlight
setblock 411 292 284 minecraft:shroomlight
setblock 411 292 286 minecraft:shroomlight
setblock 412 292 276 minecraft:stripped_oak_log
setblock 412 292 277 minecraft:shroomlight
setblock 412 292 279 minecraft:shroomlight
setblock 412 292 281 minecraft:shroomlight
setblock 412 292 283 minecraft:shroomlight
setblock 412 292 285 minecraft:shroomlight
setblock 412 292 287 minecraft:shroomlight
setblock 412 292 316 minecraft:stripped_oak_log
fill 413 292 276 413 295 276 minecraft:red_terracotta
setblock 413 292 278 minecraft:shroomlight
setblock 413 292 280 minecraft:shroomlight
setblock 413 292 282 minecraft:shroomlight
setblock 413 292 284 minecraft:shroomlight
setblock 413 292 286 minecraft:shroomlight
setblock 413 292 315 minecraft:stripped_oak_log
fill 413 292 316 413 295 316 minecraft:red_terracotta
setblock 414 292 277 minecraft:shroomlight
fill 414 292 278 414 295 278 minecraft:stripped_oak_log
setblock 414 292 279 minecraft:shroomlight
setblock 414 292 281 minecraft:shroomlight
setblock 414 292 283 minecraft:shroomlight
setblock 414 292 285 minecraft:shroomlight
setblock 414 292 287 minecraft:shroomlight
fill 414 292 314 414 300 314 minecraft:stripped_oak_log
fill 414 292 315 414 295 315 minecraft:red_terracotta
setblock 415 292 278 minecraft:shroomlight
setblock 415 292 280 minecraft:shroomlight
setblock 415 292 282 minecraft:shroomlight
setblock 415 292 284 minecraft:shroomlight
setblock 415 292 286 minecraft:shroomlight
fill 415 292 313 415 300 313 minecraft:stripped_oak_log
setblock 415 292 314 minecraft:red_terracotta
setblock 416 292 277 minecraft:shroomlight
setblock 416 292 279 minecraft:shroomlight
setblock 416 292 281 minecraft:shroomlight
setblock 416 292 283 minecraft:shroomlight
setblock 416 292 285 minecraft:shroomlight
setblock 416 292 287 minecraft:shroomlight
fill 416 292 311 416 300 312 minecraft:stripped_oak_log
fill 416 292 313 416 293 313 minecraft:red_terracotta
setblock 417 292 276 minecraft:stripped_oak_log
fill 417 292 277 417 295 277 minecraft:red_terracotta
setblock 417 292 278 minecraft:shroomlight
setblock 417 292 279 minecraft:red_terracotta
setblock 417 292 280 minecraft:shroomlight
fill 417 292 281 417 295 281 minecraft:stripped_oak_log
setblock 417 292 282 minecraft:shroomlight
setblock 417 292 284 minecraft:shroomlight
setblock 417 292 286 minecraft:shroomlight
fill 417 292 287 417 295 287 minecraft:stripped_oak_log
fill 417 292 309 417 299 309 minecraft:stripped_oak_log
setblock 417 292 311 minecraft:stripped_oak_log
fill 417 292 312 417 294 312 minecraft:red_terracotta
setblock 417 292 316 minecraft:stripped_oak_log
fill 418 292 276 418 295 316 minecraft:white_terracotta
setblock 377 293 294 minecraft:red_terracotta
setblock 377 293 295 minecraft:stripped_oak_log
fill 377 293 296 377 293 299 minecraft:red_terracotta
setblock 377 293 300 minecraft:stripped_oak_log
fill 377 293 301 377 296 301 minecraft:red_terracotta
setblock 377 293 311 minecraft:red_terracotta
setblock 377 293 315 minecraft:stripped_oak_log
fill 377 293 316 377 295 316 minecraft:red_terracotta
fill 378 293 299 386 293 299 minecraft:orange_terracotta
setblock 381 293 316 minecraft:stripped_oak_log
fill 382 293 316 382 294 316 minecraft:red_terracotta
fill 384 293 307 384 294 307 minecraft:stripped_oak_log
fill 384 293 309 384 294 309 minecraft:stripped_oak_log
fill 384 293 311 384 294 311 minecraft:stripped_oak_log
fill 384 293 313 384 294 313 minecraft:stripped_oak_log
fill 384 293 315 384 294 315 minecraft:stripped_oak_log
setblock 385 293 276 minecraft:red_terracotta
fill 385 293 308 385 294 308 minecraft:stripped_oak_log
fill 385 293 310 385 294 310 minecraft:stripped_oak_log
fill 385 293 312 385 294 312 minecraft:stripped_oak_log
fill 385 293 314 385 294 314 minecraft:stripped_oak_log
setblock 385 293 316 minecraft:red_terracotta
setblock 386 293 276 minecraft:stripped_oak_log
fill 386 293 307 386 294 307 minecraft:stripped_oak_log
fill 386 293 309 386 294 309 minecraft:stripped_oak_log
fill 386 293 311 386 294 311 minecraft:stripped_oak_log
fill 386 293 313 386 294 313 minecraft:stripped_oak_log
fill 386 293 315 386 293 316 minecraft:stripped_oak_log
fill 387 293 276 387 296 276 minecraft:red_terracotta
fill 387 293 308 387 294 308 minecraft:stripped_oak_log
fill 387 293 310 387 294 310 minecraft:stripped_oak_log
fill 387 293 312 387 294 312 minecraft:stripped_oak_log
fill 387 293 314 387 294 315 minecraft:stripped_oak_log
fill 387 293 316 387 294 316 minecraft:red_terracotta
fill 388 293 307 388 294 307 minecraft:stripped_oak_log
fill 388 293 309 388 294 309 minecraft:stripped_oak_log
fill 388 293 311 388 294 311 minecraft:stripped_oak_log
fill 388 293 313 388 294 313 minecraft:stripped_oak_log
setblock 388 293 315 minecraft:red_terracotta
setblock 389 293 277 minecraft:red_terracotta
fill 389 293 308 389 294 308 minecraft:stripped_oak_log
fill 389 293 310 389 294 310 minecraft:stripped_oak_log
fill 389 293 312 389 294 312 minecraft:stripped_oak_log
fill 389 293 314 389 294 314 minecraft:stripped_oak_log
fill 389 293 316 389 294 316 minecraft:red_terracotta
setblock 390 293 277 minecraft:stripped_oak_log
fill 390 293 307 390 294 307 minecraft:stripped_oak_log
fill 390 293 309 390 294 309 minecraft:stripped_oak_log
fill 390 293 311 390 294 311 minecraft:stripped_oak_log
fill 390 293 313 390 294 313 minecraft:stripped_oak_log
setblock 390 293 315 minecraft:red_terracotta
setblock 391 293 276 minecraft:stripped_oak_log
fill 391 293 277 391 296 277 minecraft:red_terracotta
fill 391 293 308 391 294 308 minecraft:stripped_oak_log
fill 391 293 310 391 294 310 minecraft:stripped_oak_log
fill 391 293 312 391 294 312 minecraft:stripped_oak_log
fill 391 293 314 391 293 316 minecraft:stripped_oak_log
fill 392 293 276 392 296 276 minecraft:red_terracotta
setblock 392 293 300 minecraft:stripped_oak_log
fill 392 293 306 394 297 306 minecraft:brown_terracotta
fill 392 293 307 392 294 307 minecraft:stripped_oak_log
fill 392 293 309 392 294 309 minecraft:stripped_oak_log
fill 392 293 311 392 294 311 minecraft:stripped_oak_log
fill 392 293 313 392 294 313 minecraft:stripped_oak_log
fill 392 293 315 392 294 315 minecraft:stripped_oak_log
fill 392 293 316 392 296 316 minecraft:red_terracotta
fill 393 293 311 393 297 311 minecraft:brown_terracotta
fill 395 293 307 395 297 307 minecraft:brown_terracotta
fill 395 293 309 395 297 309 minecraft:brown_terracotta
setblock 396 293 276 minecraft:stripped_oak_log
fill 397 293 276 397 296 276 minecraft:red_terracotta
setblock 401 293 276 minecraft:stripped_oak_log
fill 402 293 276 402 296 276 minecraft:red_terracotta
fill 403 293 277 403 294 277 minecraft:red_terracotta
fill 403 293 316 405 293 316 minecraft:red_terracotta
setblock 405 293 276 minecraft:red_terracotta
setblock 405 293 277 minecraft:stripped_oak_log
fill 405 293 299 409 293 299 minecraft:stripped_oak_log
setblock 406 293 276 minecraft:stripped_oak_log
fill 406 293 277 406 295 278 minecraft:red_terracotta
setblock 406 293 279 minecraft:stripped_oak_log
setblock 406 293 281 minecraft:stripped_oak_log
setblock 406 293 315 minecraft:red_terracotta
setblock 406 293 316 minecraft:stripped_oak_log
fill 407 293 276 407 296 276 minecraft:red_terracotta
fill 407 293 278 407 294 278 minecraft:red_terracotta
setblock 407 293 280 minecraft:stripped_oak_log
fill 407 293 300 417 294 300 minecraft:stripped_oak_log
setblock 407 293 315 minecraft:stripped_oak_log
fill 407 293 316 407 296 316 minecraft:red_terracotta
fill 408 293 277 408 294 277 minecraft:red_terracotta
fill 408 293 279 408 295 279 minecraft:stripped_oak_log
fill 408 293 281 408 295 281 minecraft:stripped_oak_log
fill 408 293 283 408 295 283 minecraft:stripped_oak_log
fill 408 293 285 408 295 285 minecraft:stripped_oak_log
fill 408 293 287 408 295 287 minecraft:stripped_oak_log
fill 408 293 315 408 296 315 minecraft:red_terracotta
fill 409 293 276 409 294 276 minecraft:red_terracotta
setblock 409 293 278 minecraft:stripped_oak_log
fill 409 293 280 409 295 280 minecraft:stripped_oak_log
fill 409 293 282 409 295 282 minecraft:stripped_oak_log
fill 409 293 284 409 295 284 minecraft:stripped_oak_log
fill 409 293 286 409 295 286 minecraft:stripped_oak_log
setblock 410 293 277 minecraft:stripped_oak_log
fill 410 293 278 411 295 278 minecraft:red_terracotta
fill 410 293 279 410 295 279 minecraft:stripped_oak_log
fill 410 293 281 410 295 281 minecraft:stripped_oak_log
fill 410 293 283 410 295 283 minecraft:stripped_oak_log
fill 410 293 285 410 295 285 minecraft:stripped_oak_log
fill 410 293 287 410 295 287 minecraft:stripped_oak_log
fill 410 293 301 416 293 301 minecraft:stripped_oak_log
setblock 411 293 276 minecraft:stripped_oak_log
fill 411 293 277 412 295 277 minecraft:red_terracotta
fill 411 293 280 411 295 280 minecraft:stripped_oak_log
fill 411 293 282 411 295 282 minecraft:stripped_oak_log
fill 411 293 284 411 295 284 minecraft:stripped_oak_log
fill 411 293 286 411 295 286 minecraft:stripped_oak_log
setblock 411 293 316 minecraft:stripped_oak_log
fill 412 293 276 412 296 276 minecraft:red_terracotta
fill 412 293 279 412 295 279 minecraft:stripped_oak_log
fill 412 293 281 412 295 281 minecraft:stripped_oak_log
fill 412 293 283 412 295 283 minecraft:stripped_oak_log
fill 412 293 285 412 295 285 minecraft:stripped_oak_log
fill 412 293 287 412 295 287 minecraft:stripped_oak_log
setblock 412 293 315 minecraft:stripped_oak_log
fill 412 293 316 412 296 316 minecraft:red_terracotta
setblock 413 293 278 minecraft:red_terracotta
fill 413 293 280 413 295 280 minecraft:stripped_oak_log
fill 413 293 282 413 295 282 minecraft:stripped_oak_log
fill 413 293 284 413 295 284 minecraft:stripped_oak_log
fill 413 293 286 413 295 286 minecraft:stripped_oak_log
fill 413 293 314 413 300 314 minecraft:stripped_oak_log
fill 413 293 315 413 296 315 minecraft:red_terracotta
setblock 414 293 277 minecraft:red_terracotta
fill 414 293 279 414 295 279 minecraft:stripped_oak_log
fill 414 293 281 414 295 281 minecraft:stripped_oak_log
fill 414 293 283 414 295 283 minecraft:stripped_oak_log
fill 414 293 285 414 295 285 minecraft:stripped_oak_log
fill 414 293 287 414 295 287 minecraft:stripped_oak_log
fill 415 293 277 415 293 278 minecraft:stripped_oak_log
fill 415 293 280 415 295 280 minecraft:stripped_oak_log
fill 415 293 282 415 295 282 minecraft:stripped_oak_log
fill 415 293 284 415 295 284 minecraft:stripped_oak_log
fill 415 293 286 415 295 286 minecraft:stripped_oak_log
fill 415 293 314 415 300 314 minecraft:stripped_oak_log
setblock 416 293 276 minecraft:stripped_oak_log
setblock 416 293 277 minecraft:red_terracotta
fill 416 293 279 417 295 279 minecraft:stripped_oak_log
fill 416 293 281 416 295 281 minecraft:stripped_oak_log
fill 416 293 283 416 295 283 minecraft:stripped_oak_log
fill 416 293 285 416 295 285 minecraft:stripped_oak_log
fill 416 293 287 416 295 287 minecraft:stripped_oak_log
setblock 416 293 316 minecraft:stripped_oak_log
fill 417 293 276 417 296 276 minecraft:red_terracotta
fill 417 293 278 417 294 278 minecraft:red_terracotta
fill 417 293 280 417 295 280 minecraft:stripped_oak_log
fill 417 293 282 417 295 282 minecraft:stripped_oak_log
fill 417 293 284 417 295 284 minecraft:stripped_oak_log
fill 417 293 286 417 295 286 minecraft:stripped_oak_log
fill 417 293 310 417 299 310 minecraft:stripped_oak_log
setblock 417 293 311 minecraft:red_terracotta
setblock 417 293 315 minecraft:stripped_oak_log
fill 417 293 316 417 296 316 minecraft:red_terracotta
fill 377 294 292 379 295 292 minecraft:iron_bars
fill 377 294 295 377 294 298 minecraft:red_terracotta
setblock 377 294 299 minecraft:stripped_oak_log
fill 377 294 300 377 297 300 minecraft:red_terracotta
fill 377 294 302 377 295 302 minecraft:red_terracotta
setblock 377 294 314 minecraft:stripped_oak_log
fill 377 294 315 377 295 315 minecraft:red_terracotta
setblock 379 294 278 minecraft:light[level=12]
setblock 379 294 285 minecraft:light[level=12]
setblock 379 294 299 minecraft:light[level=12]
setblock 379 294 306 minecraft:light[level=12]
setblock 379 294 313 minecraft:light[level=12]
setblock 385 294 276 minecraft:stripped_oak_log
setblock 385 294 316 minecraft:stripped_oak_log
fill 386 294 276 386 297 276 minecraft:red_terracotta
setblock 386 294 278 minecraft:light[level=12]
setblock 386 294 285 minecraft:light[level=12]
setblock 386 294 292 minecraft:light[level=12]
setblock 386 294 299 minecraft:light[level=12]
setblock 386 294 306 minecraft:light[level=12]
setblock 386 294 315 minecraft:stripped_oak_log
fill 386 294 316 386 297 316 minecraft:red_terracotta
setblock 388 294 277 minecraft:red_terracotta
fill 388 294 315 391 294 315 minecraft:stripped_oak_log
setblock 389 294 277 minecraft:stripped_oak_log
fill 389 294 299 392 294 299 minecraft:orange_terracotta
setblock 390 294 276 minecraft:stripped_oak_log
fill 390 294 277 390 297 277 minecraft:red_terracotta
setblock 390 294 316 minecraft:stripped_oak_log
fill 391 294 276 391 297 276 minecraft:red_terracotta
fill 391 294 306 391 297 306 minecraft:brown_terracotta
setblock 391 294 314 minecraft:stripped_oak_log
setblock 391 294 316 minecraft:red_terracotta
setblock 393 294 278 minecraft:light[level=12]
setblock 393 294 285 minecraft:light[level=12]
setblock 393 294 292 minecraft:light[level=12]
setblock 393 294 299 minecraft:light[level=12]
setblock 393 294 313 minecraft:light[level=12]
fill 394 294 311 394 297 311 minecraft:brown_terracotta
setblock 395 294 276 minecraft:stripped_oak_log
fill 395 294 306 395 297 306 minecraft:brown_terracotta
fill 395 294 310 395 297 310 minecraft:brown_terracotta
fill 396 294 276 396 297 276 minecraft:red_terracotta
setblock 399 294 300 minecraft:orange_terracotta
setblock 400 294 276 minecraft:stripped_oak_log
setblock 400 294 278 minecraft:light[level=12]
setblock 400 294 285 minecraft:light[level=12]
setblock 400 294 292 minecraft:light[level=12]
setblock 400 294 306 minecraft:light[level=12]
setblock 400 294 313 minecraft:light[level=12]
fill 401 294 276 401 297 276 minecraft:red_terracotta
fill 402 294 277 402 295 277 minecraft:red_terracotta
fill 403 294 316 404 294 316 minecraft:red_terracotta
setblock 404 294 277 minecraft:stripped_oak_log
setblock 405 294 276 minecraft:stripped_oak_log
fill 405 294 277 405 296 278 minecraft:red_terracotta
fill 405 294 300 406 294 300 minecraft:orange_terracotta
setblock 405 294 316 minecraft:stripped_oak_log
fill 406 294 276 406 297 276 minecraft:red_terracotta
setblock 406 294 315 minecraft:stripped_oak_log
fill 406 294 316 406 297 316 minecraft:red_terracotta
setblock 407 294 285 minecraft:light[level=12]
setblock 407 294 292 minecraft:light[level=12]
setblock 407 294 299 minecraft:light[level=12]
setblock 407 294 313 minecraft:light[level=12]
fill 407 294 315 407 297 315 minecraft:red_terracotta
setblock 408 294 278 minecraft:stripped_oak_log
setblock 409 294 277 minecraft:stripped_oak_log
fill 409 294 278 409 297 278 minecraft:red_terracotta
setblock 410 294 276 minecraft:stripped_oak_log
fill 410 294 277 410 297 277 minecraft:red_terracotta
setblock 410 294 316 minecraft:stripped_oak_log
fill 411 294 276 411 297 276 minecraft:red_terracotta
fill 411 294 293 411 297 293 minecraft:iron_bars
setblock 411 294 315 minecraft:stripped_oak_log
fill 411 294 316 411 297 316 minecraft:red_terracotta
fill 412 294 315 412 297 315 minecraft:red_terracotta
fill 413 294 278 413 295 278 minecraft:stripped_oak_log
setblock 414 294 277 minecraft:stripped_oak_log
setblock 414 294 292 minecraft:light[level=12]
setblock 414 294 299 minecraft:light[level=12]
setblock 414 294 306 minecraft:light[level=12]
setblock 415 294 276 minecraft:stripped_oak_log
fill 415 294 277 415 297 277 minecraft:red_terracotta
fill 415 294 278 415 295 278 minecraft:stripped_oak_log
fill 415 294 301 416 294 301 minecraft:stripped_oak_log
fill 415 294 305 415 296 305 minecraft:green_concrete
setblock 415 294 316 minecraft:stripped_oak_log
fill 416 294 276 416 297 276 minecraft:red_terracotta
fill 416 294 277 416 295 277 minecraft:stripped_oak_log
fill 416 294 313 416 294 315 minecraft:stripped_oak_log
fill 416 294 316 416 297 316 minecraft:red_terracotta
fill 417 294 311 417 299 311 minecraft:stripped_oak_log
setblock 417 294 314 minecraft:stripped_oak_log
fill 417 294 315 417 297 315 minecraft:red_terracotta
fill 377 295 295 377 295 297 minecraft:red_terracotta
setblock 377 295 298 minecraft:stripped_oak_log
fill 377 295 299 377 298 299 minecraft:red_terracotta
setblock 377 295 303 minecraft:stripped_oak_log
setblock 384 295 276 minecraft:stripped_oak_log
setblock 384 295 307 minecraft:shroomlight
setblock 384 295 309 minecraft:shroomlight
setblock 384 295 311 minecraft:shroomlight
setblock 384 295 313 minecraft:shroomlight
setblock 384 295 315 minecraft:shroomlight
setblock 384 295 316 minecraft:stripped_oak_log
fill 385 295 276 385 298 276 minecraft:red_terracotta
setblock 385 295 308 minecraft:shroomlight
setblock 385 295 310 minecraft:shroomlight
setblock 385 295 312 minecraft:shroomlight
setblock 385 295 314 minecraft:shroomlight
setblock 385 295 316 minecraft:shroomlight
setblock 386 295 307 minecraft:shroomlight
setblock 386 295 309 minecraft:shroomlight
setblock 386 295 311 minecraft:shroomlight
setblock 386 295 313 minecraft:shroomlight
setblock 386 295 315 minecraft:shroomlight
setblock 387 295 277 minecraft:red_terracotta
setblock 387 295 308 minecraft:shroomlight
setblock 387 295 310 minecraft:shroomlight
setblock 387 295 312 minecraft:shroomlight
setblock 387 295 314 minecraft:shroomlight
fill 387 295 315 387 296 315 minecraft:stripped_oak_log
setblock 387 295 316 minecraft:shroomlight
setblock 388 295 277 minecraft:stripped_oak_log
setblock 388 295 307 minecraft:shroomlight
setblock 388 295 309 minecraft:shroomlight
setblock 388 295 311 minecraft:shroomlight
setblock 388 295 313 minecraft:shroomlight
setblock 388 295 315 minecraft:shroomlight
setblock 389 295 276 minecraft:stripped_oak_log
fill 389 295 277 389 298 277 minecraft:red_terracotta
setblock 389 295 308 minecraft:shroomlight
setblock 389 295 310 minecraft:shroomlight
setblock 389 295 312 minecraft:shroomlight
setblock 389 295 314 minecraft:shroomlight
fill 389 295 315 389 296 315 minecraft:stripped_oak_log
setblock 389 295 316 minecraft:shroomlight
fill 390 295 276 390 298 276 minecraft:red_terracotta
fill 390 295 306 390 297 306 minecraft:brown_terracotta
setblock 390 295 307 minecraft:shroomlight
setblock 390 295 309 minecraft:shroomlight
setblock 390 295 311 minecraft:shroomlight
setblock 390 295 313 minecraft:shroomlight
setblock 390 295 315 minecraft:shroomlight
fill 390 295 316 390 298 316 minecraft:red_terracotta
setblock 391 295 308 minecraft:shroomlight
setblock 391 295 310 minecraft:shroomlight
setblock 391 295 312 minecraft:shroomlight
setblock 391 295 314 minecraft:shroomlight
fill 391 295 315 391 296 315 minecraft:stripped_oak_log
setblock 391 295 316 minecraft:shroomlight
fill 392 295 305 394 297 305 minecraft:brown_terracotta
setblock 392 295 307 minecraft:shroomlight
setblock 392 295 309 minecraft:shroomlight
setblock 392 295 311 minecraft:shroomlight
setblock 392 295 313 minecraft:shroomlight
setblock 392 295 315 minecraft:shroomlight
setblock 393 295 277 minecraft:stripped_oak_log
fill 393 295 312 393 297 312 minecraft:brown_terracotta
setblock 394 295 276 minecraft:stripped_oak_log
fill 395 295 276 395 298 276 minecraft:red_terracotta
fill 395 295 311 395 297 311 minecraft:brown_terracotta
fill 396 295 307 396 297 310 minecraft:brown_terracotta
setblock 399 295 276 minecraft:stripped_oak_log
fill 400 295 276 400 298 276 minecraft:red_terracotta
fill 401 295 277 401 296 277 minecraft:red_terracotta
setblock 403 295 277 minecraft:stripped_oak_log
setblock 403 295 316 minecraft:red_terracotta
setblock 404 295 276 minecraft:stripped_oak_log
fill 404 295 277 404 297 278 minecraft:red_terracotta
setblock 404 295 316 minecraft:stripped_oak_log
fill 405 295 276 405 298 276 minecraft:red_terracotta
fill 405 295 316 405 298 316 minecraft:red_terracotta
fill 406 295 315 406 298 315 minecraft:red_terracotta
setblock 407 295 278 minecraft:stripped_oak_log
setblock 408 295 277 minecraft:stripped_oak_log
fill 408 295 278 408 298 278 minecraft:red_terracotta
fill 408 295 300 416 295 300 minecraft:orange_terracotta
setblock 409 295 276 minecraft:stripped_oak_log
fill 409 295 277 409 298 277 minecraft:red_terracotta
setblock 409 295 316 minecraft:stripped_oak_log
fill 410 295 276 410 298 276 minecraft:red_terracotta
setblock 410 295 315 minecraft:stripped_oak_log
fill 410 295 316 410 298 316 minecraft:red_terracotta
fill 411 295 315 411 298 315 minecraft:red_terracotta
setblock 412 295 278 minecraft:stripped_oak_log
setblock 413 295 277 minecraft:stripped_oak_log
setblock 414 295 276 minecraft:stripped_oak_log
fill 414 295 277 414 298 277 minecraft:red_terracotta
setblock 414 295 316 minecraft:stripped_oak_log
fill 415 295 276 415 298 276 minecraft:red_terracotta
setblock 415 295 315 minecraft:stripped_oak_log
fill 415 295 316 415 298 316 minecraft:red_terracotta
fill 416 295 313 416 300 314 minecraft:stripped_oak_log
setblock 416 295 315 minecraft:red_terracotta
setblock 417 295 278 minecraft:stripped_oak_log
fill 417 295 312 417 300 313 minecraft:stripped_oak_log
fill 417 295 314 417 298 314 minecraft:red_terracotta
fill 376 296 275 376 299 317 minecraft:terracotta
fill 377 296 275 418 299 275 minecraft:terracotta
fill 377 296 295 377 296 296 minecraft:red_terracotta
setblock 377 296 297 minecraft:stripped_oak_log
fill 377 296 298 377 299 298 minecraft:red_terracotta
setblock 377 296 302 minecraft:stripped_oak_log
fill 377 296 303 377 298 304 minecraft:red_terracotta
fill 377 296 317 418 299 317 minecraft:terracotta
setblock 379 296 278 minecraft:light[level=15]
setblock 379 296 286 minecraft:light[level=15]
setblock 379 296 294 minecraft:light[level=15]
setblock 379 296 302 minecraft:light[level=15]
setblock 379 296 310 minecraft:light[level=15]
setblock 383 296 276 minecraft:stripped_oak_log
setblock 383 296 316 minecraft:stripped_oak_log
fill 384 296 276 384 299 276 minecraft:red_terracotta
setblock 384 296 307 minecraft:stripped_oak_log
setblock 384 296 309 minecraft:stripped_oak_log
setblock 384 296 311 minecraft:stripped_oak_log
setblock 384 296 313 minecraft:stripped_oak_log
setblock 384 296 315 minecraft:stripped_oak_log
fill 384 296 316 385 298 316 minecraft:red_terracotta
setblock 385 296 308 minecraft:stripped_oak_log
setblock 385 296 310 minecraft:stripped_oak_log
setblock 385 296 312 minecraft:stripped_oak_log
setblock 385 296 314 minecraft:stripped_oak_log
setblock 386 296 277 minecraft:red_terracotta
setblock 386 296 307 minecraft:stripped_oak_log
setblock 386 296 309 minecraft:stripped_oak_log
setblock 386 296 311 minecraft:stripped_oak_log
setblock 386 296 313 minecraft:stripped_oak_log
setblock 386 296 315 minecraft:stripped_oak_log
setblock 387 296 277 minecraft:stripped_oak_log
setblock 387 296 278 minecraft:light[level=15]
setblock 387 296 286 minecraft:light[level=15]
setblock 387 296 294 minecraft:light[level=15]
setblock 387 296 302 minecraft:light[level=15]
setblock 387 296 308 minecraft:stripped_oak_log
setblock 387 296 310 minecraft:stripped_oak_log
setblock 387 296 312 minecraft:stripped_oak_log
setblock 387 296 314 minecraft:stripped_oak_log
setblock 387 296 316 minecraft:red_terracotta
setblock 388 296 276 minecraft:stripped_oak_log
fill 388 296 277 388 299 277 minecraft:red_terracotta
setblock 388 296 307 minecraft:stripped_oak_log
setblock 388 296 309 minecraft:stripped_oak_log
setblock 388 296 311 minecraft:stripped_oak_log
setblock 388 296 313 minecraft:stripped_oak_log
fill 388 296 315 388 296 316 minecraft:stripped_oak_log
fill 389 296 276 389 299 276 minecraft:red_terracotta
setblock 389 296 308 minecraft:stripped_oak_log
setblock 389 296 310 minecraft:stripped_oak_log
setblock 389 296 312 minecraft:stripped_oak_log
setblock 389 296 314 minecraft:stripped_oak_log
fill 389 296 316 389 299 316 minecraft:red_terracotta
setblock 390 296 307 minecraft:stripped_oak_log
setblock 390 296 309 minecraft:stripped_oak_log
setblock 390 296 311 minecraft:stripped_oak_log
setblock 390 296 313 minecraft:stripped_oak_log
setblock 390 296 315 minecraft:stripped_oak_log
fill 391 296 305 391 297 305 minecraft:brown_terracotta
setblock 391 296 308 minecraft:stripped_oak_log
setblock 391 296 310 minecraft:stripped_oak_log
setblock 391 296 312 minecraft:stripped_oak_log
setblock 391 296 314 minecraft:stripped_oak_log
fill 391 296 316 391 297 316 minecraft:red_terracotta
setblock 392 296 277 minecraft:stripped_oak_log
setblock 392 296 307 minecraft:stripped_oak_log
setblock 392 296 309 minecraft:stripped_oak_log
setblock 392 296 311 minecraft:stripped_oak_log
setblock 392 296 313 minecraft:stripped_oak_log
setblock 392 296 315 minecraft:stripped_oak_log
setblock 393 296 276 minecraft:stripped_oak_log
fill 393 296 277 394 298 277 minecraft:red_terracotta
fill 394 296 276 394 299 276 minecraft:red_terracotta
fill 394 296 312 394 297 312 minecraft:brown_terracotta
setblock 395 296 278 minecraft:light[level=15]
setblock 395 296 286 minecraft:light[level=15]
setblock 395 296 294 minecraft:light[level=15]
setblock 395 296 302 minecraft:light[level=15]
fill 395 296 305 395 297 305 minecraft:brown_terracotta
fill 396 296 306 396 297 306 minecraft:brown_terracotta
setblock 398 296 276 minecraft:stripped_oak_log
fill 399 296 276 399 299 276 minecraft:red_terracotta
fill 400 296 277 400 297 277 minecraft:red_terracotta
setblock 402 296 277 minecraft:stripped_oak_log
setblock 402 296 316 minecraft:red_terracotta
setblock 403 296 276 minecraft:stripped_oak_log
fill 403 296 277 403 298 278 minecraft:red_terracotta
setblock 403 296 286 minecraft:light[level=15]
setblock 403 296 294 minecraft:light[level=15]
setblock 403 296 302 minecraft:light[level=15]
setblock 403 296 310 minecraft:light[level=15]
setblock 403 296 316 minecraft:stripped_oak_log
fill 404 296 276 404 299 276 minecraft:red_terracotta
fill 404 296 316 404 299 316 minecraft:red_terracotta
fill 405 296 315 405 299 315 minecraft:red_terracotta
setblock 406 296 277 minecraft:red_terracotta
setblock 406 296 278 minecraft:stripped_oak_log
setblock 407 296 277 minecraft:stripped_oak_log
fill 407 296 278 407 298 279 minecraft:red_terracotta
setblock 408 296 276 minecraft:stripped_oak_log
fill 408 296 277 408 299 277 minecraft:red_terracotta
fill 408 296 279 408 297 279 minecraft:red_terracotta
setblock 408 296 316 minecraft:stripped_oak_log
fill 409 296 276 409 299 276 minecraft:red_terracotta
setblock 409 296 315 minecraft:stripped_oak_log
fill 409 296 316 409 299 316 minecraft:red_terracotta
setblock 410 296 278 minecraft:red_terracotta
fill 410 296 315 410 299 315 minecraft:red_terracotta
setblock 411 296 277 minecraft:red_terracotta
setblock 411 296 278 minecraft:stripped_oak_log
setblock 411 296 286 minecraft:light[level=15]
setblock 411 296 294 minecraft:light[level=15]
setblock 411 296 302 minecraft:light[level=15]
setblock 411 296 310 minecraft:light[level=15]
setblock 412 296 277 minecraft:stripped_oak_log
fill 412 296 278 412 299 278 minecraft:red_terracotta
setblock 413 296 276 minecraft:stripped_oak_log
fill 413 296 277 413 299 277 minecraft:red_terracotta
setblock 413 296 316 minecraft:stripped_oak_log
fill 414 296 276 414 299 276 minecraft:red_terracotta
setblock 414 296 315 minecraft:stripped_oak_log
fill 414 296 316 414 299 316 minecraft:red_terracotta
setblock 415 296 315 minecraft:red_terracotta
fill 416 296 315 416 300 315 minecraft:stripped_oak_log
setblock 417 296 277 minecraft:stripped_oak_log
fill 417 296 278 417 299 278 minecraft:red_terracotta
fill 418 296 276 418 299 316 minecraft:terracotta
setblock 377 297 295 minecraft:red_terracotta
setblock 377 297 296 minecraft:stripped_oak_log
fill 377 297 297 377 300 297 minecraft:red_terracotta
setblock 377 297 301 minecraft:stripped_oak_log
fill 377 297 302 378 299 302 minecraft:red_terracotta
setblock 377 297 305 minecraft:red_terracotta
fill 378 297 298 378 297 299 minecraft:red_terracotta
setblock 378 297 300 minecraft:stripped_oak_log
fill 378 297 301 378 300 301 minecraft:red_terracotta
setblock 382 297 276 minecraft:stripped_oak_log
setblock 382 297 316 minecraft:stripped_oak_log
fill 383 297 276 383 300 276 minecraft:red_terracotta
fill 383 297 316 383 300 316 minecraft:red_terracotta
setblock 385 297 277 minecraft:red_terracotta
setblock 386 297 277 minecraft:stripped_oak_log
setblock 387 297 276 minecraft:stripped_oak_log
fill 387 297 277 387 300 277 minecraft:red_terracotta
setblock 387 297 316 minecraft:stripped_oak_log
fill 388 297 276 388 300 276 minecraft:red_terracotta
fill 388 297 278 389 297 278 minecraft:red_terracotta
fill 388 297 316 388 300 316 minecraft:red_terracotta
fill 389 297 306 389 297 311 minecraft:brown_terracotta
setblock 390 297 278 minecraft:stripped_oak_log
setblock 390 297 305 minecraft:brown_terracotta
fill 390 297 307 392 297 312 minecraft:brown_terracotta
setblock 391 297 277 minecraft:stripped_oak_log
fill 391 297 304 394 297 304 minecraft:brown_terracotta
setblock 392 297 276 minecraft:stripped_oak_log
fill 392 297 277 392 300 277 minecraft:red_terracotta
fill 393 297 276 393 300 276 minecraft:red_terracotta
setblock 395 297 277 minecraft:red_terracotta
setblock 395 297 312 minecraft:brown_terracotta
setblock 396 297 305 minecraft:brown_terracotta
setblock 396 297 311 minecraft:brown_terracotta
setblock 397 297 276 minecraft:stripped_oak_log
fill 397 297 307 397 297 310 minecraft:brown_terracotta
fill 398 297 276 398 299 277 minecraft:red_terracotta
fill 398 297 301 399 297 302 minecraft:orange_terracotta
fill 399 297 277 399 298 277 minecraft:red_terracotta
fill 399 297 295 405 297 295 minecraft:orange_terracotta
fill 399 297 299 399 298 300 minecraft:orange_terracotta
fill 399 297 303 405 297 303 minecraft:orange_terracotta
fill 400 297 296 400 298 297 minecraft:orange_terracotta
fill 400 297 302 406 297 302 minecraft:orange_terracotta
fill 400 297 304 404 297 304 minecraft:orange_terracotta
setblock 401 297 277 minecraft:stripped_oak_log
fill 401 297 296 406 297 296 minecraft:orange_terracotta
setblock 402 297 276 minecraft:stripped_oak_log
fill 402 297 277 402 299 278 minecraft:red_terracotta
setblock 402 297 316 minecraft:stripped_oak_log
fill 403 297 276 403 300 276 minecraft:red_terracotta
fill 403 297 316 403 300 316 minecraft:red_terracotta
fill 404 297 297 406 297 297 minecraft:orange_terracotta
fill 404 297 307 405 297 308 minecraft:orange_terracotta
setblock 405 297 277 minecraft:red_terracotta
setblock 405 297 278 minecraft:stripped_oak_log
fill 405 297 279 406 299 279 minecraft:red_terracotta
fill 405 297 298 406 298 301 minecraft:orange_terracotta
fill 405 297 305 406 297 306 minecraft:orange_terracotta
fill 405 297 309 406 297 310 minecraft:orange_terracotta
setblock 406 297 277 minecraft:stripped_oak_log
fill 406 297 278 406 300 278 minecraft:red_terracotta
fill 406 297 304 410 297 304 minecraft:orange_terracotta
fill 406 297 311 410 297 311 minecraft:orange_terracotta
setblock 407 297 276 minecraft:stripped_oak_log
fill 407 297 277 407 300 277 minecraft:red_terracotta
fill 407 297 298 407 297 300 minecraft:orange_terracotta
fill 407 297 305 411 297 305 minecraft:orange_terracotta
fill 407 297 310 411 297 310 minecraft:orange_terracotta
setblock 407 297 316 minecraft:stripped_oak_log
fill 408 297 276 408 300 276 minecraft:red_terracotta
setblock 408 297 315 minecraft:stripped_oak_log
fill 408 297 316 408 300 316 minecraft:red_terracotta
setblock 409 297 279 minecraft:stripped_oak_log
fill 409 297 315 409 300 315 minecraft:red_terracotta
setblock 410 297 278 minecraft:stripped_oak_log
fill 410 297 306 412 297 306 minecraft:orange_terracotta
fill 410 297 309 412 297 309 minecraft:orange_terracotta
setblock 411 297 277 minecraft:stripped_oak_log
fill 411 297 278 411 300 278 minecraft:red_terracotta
fill 411 297 307 412 297 308 minecraft:orange_terracotta
setblock 412 297 276 minecraft:stripped_oak_log
fill 412 297 277 412 300 277 minecraft:red_terracotta
setblock 412 297 316 minecraft:stripped_oak_log
fill 413 297 276 413 300 276 minecraft:red_terracotta
setblock 413 297 315 minecraft:stripped_oak_log
fill 413 297 316 413 300 316 minecraft:red_terracotta
fill 414 297 315 414 298 315 minecraft:red_terracotta
fill 415 297 315 415 300 315 minecraft:stripped_oak_log
setblock 417 297 276 minecraft:stripped_oak_log
fill 417 297 277 417 300 277 minecraft:red_terracotta
fill 417 297 279 417 298 279 minecraft:red_terracotta
fill 417 297 299 417 297 300 minecraft:red_terracotta
setblock 417 297 301 minecraft:stripped_oak_log
fill 417 297 302 417 300 302 minecraft:red_terracotta
setblock 417 297 316 minecraft:stripped_oak_log
setblock 377 298 295 minecraft:stripped_oak_log
fill 377 298 296 377 300 296 minecraft:red_terracotta
setblock 377 298 300 minecraft:stripped_oak_log
fill 377 298 301 377 300 301 minecraft:red_terracotta
setblock 377 298 305 minecraft:stripped_oak_log
fill 377 298 306 377 300 306 minecraft:red_terracotta
fill 378 298 297 378 298 298 minecraft:red_terracotta
setblock 378 298 299 minecraft:stripped_oak_log
fill 378 298 300 378 300 300 minecraft:red_terracotta
setblock 378 298 303 minecraft:red_terracotta
setblock 378 298 304 minecraft:stripped_oak_log
setblock 381 298 276 minecraft:stripped_oak_log
fill 382 298 276 382 300 276 minecraft:red_terracotta
fill 382 298 316 382 300 316 minecraft:red_terracotta
fill 383 298 277 384 298 277 minecraft:red_terracotta
setblock 385 298 277 minecraft:stripped_oak_log
setblock 386 298 276 minecraft:stripped_oak_log
fill 386 298 277 386 300 278 minecraft:red_terracotta
setblock 386 298 316 minecraft:stripped_oak_log
fill 387 298 276 387 300 276 minecraft:red_terracotta
fill 387 298 278 388 298 278 minecraft:red_terracotta
fill 387 298 316 387 300 316 minecraft:red_terracotta
setblock 389 298 278 minecraft:stripped_oak_log
setblock 390 298 277 minecraft:stripped_oak_log
fill 390 298 278 391 300 278 minecraft:red_terracotta
setblock 391 298 276 minecraft:stripped_oak_log
fill 391 298 277 391 300 277 minecraft:red_terracotta
setblock 391 298 316 minecraft:stripped_oak_log
fill 392 298 276 392 300 276 minecraft:red_terracotta
fill 392 298 307 392 300 307 minecraft:stripped_oak_log
fill 392 298 310 392 300 310 minecraft:stripped_oak_log
fill 394 298 308 394 300 308 minecraft:stripped_oak_log
setblock 395 298 277 minecraft:stripped_oak_log
setblock 396 298 276 minecraft:stripped_oak_log
fill 396 298 277 397 300 277 minecraft:red_terracotta
fill 397 298 276 397 300 276 minecraft:red_terracotta
fill 398 298 300 398 298 301 minecraft:orange_terracotta
fill 399 298 301 399 298 302 minecraft:orange_terracotta
setblock 400 298 277 minecraft:stripped_oak_log
fill 400 298 278 401 300 278 minecraft:red_terracotta
fill 400 298 302 404 298 303 minecraft:orange_terracotta
setblock 401 298 276 minecraft:stripped_oak_log
fill 401 298 277 401 300 277 minecraft:red_terracotta
fill 401 298 295 403 298 296 minecraft:orange_terracotta
setblock 401 298 316 minecraft:stripped_oak_log
fill 402 298 276 402 300 276 minecraft:red_terracotta
fill 402 298 316 402 300 316 minecraft:red_terracotta
setblock 403 298 279 minecraft:stripped_oak_log
setblock 404 298 277 minecraft:red_terracotta
setblock 404 298 278 minecraft:stripped_oak_log
fill 404 298 279 404 300 279 minecraft:red_terracotta
fill 404 298 296 405 298 297 minecraft:orange_terracotta
fill 404 298 315 404 300 315 minecraft:red_terracotta
setblock 405 298 277 minecraft:stripped_oak_log
fill 405 298 278 405 300 278 minecraft:red_terracotta
setblock 405 298 302 minecraft:orange_terracotta
fill 405 298 306 405 298 309 minecraft:orange_terracotta
setblock 406 298 276 minecraft:stripped_oak_log
fill 406 298 277 406 300 277 minecraft:red_terracotta
fill 406 298 305 406 298 306 minecraft:orange_terracotta
fill 406 298 309 406 298 310 minecraft:orange_terracotta
setblock 406 298 316 minecraft:stripped_oak_log
fill 407 298 276 407 300 276 minecraft:red_terracotta
fill 407 298 305 410 298 305 minecraft:orange_terracotta
fill 407 298 310 410 298 310 minecraft:orange_terracotta
setblock 407 298 315 minecraft:stripped_oak_log
fill 407 298 316 407 300 316 minecraft:red_terracotta
setblock 408 298 279 minecraft:stripped_oak_log
setblock 408 298 304 minecraft:orange_terracotta
setblock 408 298 311 minecraft:orange_terracotta
fill 408 298 315 408 300 315 minecraft:red_terracotta
setblock 409 298 278 minecraft:stripped_oak_log
fill 409 298 279 410 300 279 minecraft:red_terracotta
setblock 410 298 277 minecraft:stripped_oak_log
fill 410 298 278 410 300 278 minecraft:red_terracotta
fill 410 298 306 411 298 306 minecraft:orange_terracotta
fill 410 298 309 411 298 309 minecraft:orange_terracotta
setblock 411 298 276 minecraft:stripped_oak_log
fill 411 298 277 411 300 277 minecraft:red_terracotta
fill 411 298 288 416 298 298 minecraft:brown_terracotta
fill 411 298 307 411 298 308 minecraft:orange_terracotta
setblock 411 298 316 minecraft:stripped_oak_log
fill 412 298 276 412 300 276 minecraft:red_terracotta
setblock 412 298 315 minecraft:stripped_oak_log
fill 412 298 316 412 300 316 minecraft:red_terracotta
fill 413 298 315 413 299 315 minecraft:red_terracotta
setblock 415 298 277 minecraft:stripped_oak_log
setblock 416 298 276 minecraft:stripped_oak_log
setblock 416 298 316 minecraft:stripped_oak_log
fill 417 298 276 417 300 276 minecraft:red_terracotta
setblock 417 298 280 minecraft:stripped_oak_log
fill 417 298 298 417 298 299 minecraft:red_terracotta
setblock 417 298 300 minecraft:stripped_oak_log
fill 417 298 301 417 300 301 minecraft:red_terracotta
fill 417 298 303 417 298 304 minecraft:red_terracotta
setblock 417 298 305 minecraft:stripped_oak_log
setblock 417 298 315 minecraft:stripped_oak_log
fill 417 298 316 417 300 316 minecraft:red_terracotta
fill 377 299 295 377 300 295 minecraft:red_terracotta
setblock 377 299 299 minecraft:stripped_oak_log
fill 377 299 300 377 300 300 minecraft:red_terracotta
setblock 377 299 303 minecraft:red_terracotta
setblock 377 299 304 minecraft:stripped_oak_log
fill 377 299 305 378 300 305 minecraft:red_terracotta
fill 377 299 307 377 299 308 minecraft:red_terracotta
setblock 378 299 297 minecraft:red_terracotta
setblock 378 299 298 minecraft:stripped_oak_log
fill 378 299 299 379 300 299 minecraft:red_terracotta
setblock 378 299 303 minecraft:stripped_oak_log
fill 378 299 304 378 300 304 minecraft:red_terracotta
fill 379 299 300 379 299 301 minecraft:red_terracotta
setblock 379 299 302 minecraft:stripped_oak_log
setblock 380 299 276 minecraft:stripped_oak_log
fill 381 299 276 381 300 276 minecraft:red_terracotta
fill 381 299 316 381 300 316 minecraft:red_terracotta
fill 382 299 277 383 299 277 minecraft:red_terracotta
setblock 384 299 277 minecraft:stripped_oak_log
setblock 384 299 316 minecraft:red_terracotta
setblock 385 299 276 minecraft:stripped_oak_log
fill 385 299 277 385 300 278 minecraft:red_terracotta
setblock 385 299 316 minecraft:stripped_oak_log
fill 386 299 276 386 300 276 minecraft:red_terracotta
fill 386 299 316 386 300 316 minecraft:red_terracotta
setblock 387 299 278 minecraft:red_terracotta
setblock 388 299 278 minecraft:stripped_oak_log
setblock 389 299 277 minecraft:stripped_oak_log
fill 389 299 278 389 300 278 minecraft:red_terracotta
setblock 390 299 276 minecraft:stripped_oak_log
fill 390 299 277 390 300 277 minecraft:red_terracotta
setblock 390 299 316 minecraft:stripped_oak_log
fill 391 299 276 391 300 276 minecraft:red_terracotta
setblock 392 299 278 minecraft:red_terracotta
setblock 393 299 277 minecraft:red_terracotta
setblock 394 299 277 minecraft:stripped_oak_log
setblock 395 299 276 minecraft:stripped_oak_log
fill 395 299 277 395 300 277 minecraft:red_terracotta
fill 396 299 276 396 300 276 minecraft:red_terracotta
setblock 399 299 277 minecraft:stripped_oak_log
fill 399 299 278 399 300 278 minecraft:red_terracotta
fill 399 299 300 399 299 301 minecraft:orange_terracotta
setblock 400 299 276 minecraft:stripped_oak_log
fill 400 299 277 400 300 277 minecraft:red_terracotta
setblock 400 299 297 minecraft:orange_terracotta
fill 400 299 302 404 299 302 minecraft:orange_terracotta
setblock 400 299 316 minecraft:stripped_oak_log
fill 401 299 276 401 300 276 minecraft:red_terracotta
fill 401 299 296 403 299 296 minecraft:orange_terracotta
fill 401 299 316 401 300 316 minecraft:red_terracotta
setblock 402 299 279 minecraft:stripped_oak_log
setblock 403 299 277 minecraft:red_terracotta
setblock 403 299 278 minecraft:stripped_oak_log
fill 403 299 279 403 300 279 minecraft:red_terracotta
setblock 404 299 277 minecraft:stripped_oak_log
fill 404 299 278 404 300 278 minecraft:red_terracotta
setblock 404 299 297 minecraft:orange_terracotta
setblock 405 299 276 minecraft:stripped_oak_log
fill 405 299 277 405 300 277 minecraft:red_terracotta
fill 405 299 298 405 299 301 minecraft:orange_terracotta
setblock 405 299 316 minecraft:stripped_oak_log
fill 406 299 276 406 300 276 minecraft:red_terracotta
setblock 406 299 306 minecraft:orange_terracotta
setblock 406 299 309 minecraft:orange_terracotta
setblock 406 299 315 minecraft:stripped_oak_log
fill 406 299 316 406 300 316 minecraft:red_terracotta
setblock 407 299 278 minecraft:red_terracotta
setblock 407 299 279 minecraft:stripped_oak_log
fill 407 299 305 409 299 305 minecraft:orange_terracotta
fill 407 299 310 409 299 310 minecraft:orange_terracotta
fill 407 299 315 407 300 315 minecraft:red_terracotta
setblock 408 299 278 minecraft:stripped_oak_log
fill 408 299 279 408 300 279 minecraft:red_terracotta
setblock 409 299 277 minecraft:stripped_oak_log
fill 409 299 278 409 300 278 minecraft:red_terracotta
setblock 410 299 276 minecraft:stripped_oak_log
fill 410 299 277 410 300 277 minecraft:red_terracotta
setblock 410 299 306 minecraft:orange_terracotta
setblock 410 299 309 minecraft:orange_terracotta
setblock 410 299 316 minecraft:stripped_oak_log
fill 411 299 276 411 300 276 minecraft:red_terracotta
fill 411 299 288 416 299 298 minecraft:stripped_oak_log
setblock 411 299 315 minecraft:stripped_oak_log
fill 411 299 316 411 300 316 minecraft:red_terracotta
fill 412 299 315 412 300 315 minecraft:red_terracotta
setblock 414 299 277 minecraft:stripped_oak_log
fill 414 299 315 414 300 315 minecraft:stripped_oak_log
setblock 415 299 276 minecraft:stripped_oak_log
setblock 415 299 277 minecraft:red_terracotta
setblock 415 299 316 minecraft:stripped_oak_log
fill 416 299 276 416 300 276 minecraft:red_terracotta
fill 416 299 316 416 300 316 minecraft:red_terracotta
setblock 417 299 279 minecraft:stripped_oak_log
fill 417 299 280 417 300 280 minecraft:red_terracotta
fill 417 299 297 417 299 298 minecraft:red_terracotta
setblock 417 299 299 minecraft:stripped_oak_log
fill 417 299 300 417 300 300 minecraft:red_terracotta
setblock 417 299 303 minecraft:red_terracotta
setblock 417 299 304 minecraft:stripped_oak_log
fill 417 299 305 417 299 308 minecraft:red_terracotta
setblock 417 299 314 minecraft:stripped_oak_log
fill 417 299 315 417 300 315 minecraft:red_terracotta
fill 376 300 275 376 303 317 minecraft:brown_terracotta
fill 377 300 275 418 303 275 minecraft:brown_terracotta
fill 377 300 279 377 300 280 minecraft:red_terracotta
setblock 377 300 298 minecraft:stripped_oak_log
setblock 377 300 299 minecraft:red_terracotta
setblock 377 300 302 minecraft:red_terracotta
setblock 377 300 303 minecraft:stripped_oak_log
setblock 377 300 304 minecraft:red_terracotta
setblock 377 300 307 minecraft:red_terracotta
setblock 377 300 308 minecraft:stripped_oak_log
setblock 377 300 309 minecraft:red_terracotta
fill 377 300 317 418 303 317 minecraft:brown_terracotta
setblock 378 300 296 minecraft:red_terracotta
setblock 378 300 297 minecraft:stripped_oak_log
fill 378 300 298 379 300 298 minecraft:red_terracotta
setblock 378 300 302 minecraft:stripped_oak_log
fill 378 300 303 379 300 303 minecraft:red_terracotta
setblock 378 300 306 minecraft:red_terracotta
setblock 379 300 276 minecraft:stripped_oak_log
setblock 379 300 278 minecraft:light[level=12]
setblock 379 300 285 minecraft:light[level=12]
setblock 379 300 292 minecraft:light[level=12]
setblock 379 300 300 minecraft:red_terracotta
setblock 379 300 301 minecraft:stripped_oak_log
setblock 379 300 302 minecraft:red_terracotta
setblock 379 300 304 minecraft:red_terracotta
setblock 379 300 306 minecraft:light[level=12]
setblock 379 300 313 minecraft:light[level=12]
setblock 380 300 276 minecraft:red_terracotta
setblock 382 300 277 minecraft:red_terracotta
setblock 383 300 277 minecraft:stripped_oak_log
setblock 384 300 276 minecraft:stripped_oak_log
fill 384 300 277 384 300 278 minecraft:red_terracotta
setblock 384 300 316 minecraft:stripped_oak_log
setblock 385 300 276 minecraft:red_terracotta
setblock 385 300 316 minecraft:red_terracotta
setblock 386 300 285 minecraft:light[level=12]
setblock 386 300 292 minecraft:light[level=12]
setblock 386 300 299 minecraft:light[level=12]
setblock 386 300 306 minecraft:light[level=12]
setblock 386 300 313 minecraft:light[level=12]
setblock 387 300 278 minecraft:stripped_oak_log
setblock 388 300 277 minecraft:stripped_oak_log
setblock 388 300 278 minecraft:red_terracotta
setblock 389 300 276 minecraft:stripped_oak_log
setblock 389 300 277 minecraft:red_terracotta
setblock 389 300 316 minecraft:stripped_oak_log
setblock 390 300 276 minecraft:red_terracotta
setblock 392 300 278 minecraft:stripped_oak_log
setblock 393 300 277 minecraft:stripped_oak_log
setblock 393 300 278 minecraft:light[level=12]
setblock 393 300 285 minecraft:light[level=12]
setblock 393 300 292 minecraft:light[level=12]
setblock 393 300 299 minecraft:light[level=12]
setblock 393 300 306 minecraft:light[level=12]
setblock 393 300 313 minecraft:light[level=12]
setblock 394 300 276 minecraft:stripped_oak_log
setblock 394 300 277 minecraft:red_terracotta
setblock 395 300 276 minecraft:red_terracotta
setblock 398 300 276 minecraft:red_terracotta
setblock 398 300 277 minecraft:stripped_oak_log
setblock 398 300 278 minecraft:red_terracotta
setblock 399 300 276 minecraft:stripped_oak_log
setblock 399 300 277 minecraft:red_terracotta
setblock 400 300 276 minecraft:red_terracotta
setblock 400 300 285 minecraft:light[level=12]
setblock 400 300 292 minecraft:light[level=12]
setblock 400 300 306 minecraft:light[level=12]
setblock 400 300 313 minecraft:light[level=12]
setblock 400 300 316 minecraft:red_terracotta
setblock 401 300 279 minecraft:stripped_oak_log
setblock 402 300 277 minecraft:red_terracotta
setblock 402 300 278 minecraft:stripped_oak_log
setblock 402 300 279 minecraft:red_terracotta
setblock 403 300 277 minecraft:stripped_oak_log
setblock 403 300 278 minecraft:red_terracotta
setblock 403 300 315 minecraft:red_terracotta
setblock 404 300 276 minecraft:stripped_oak_log
setblock 404 300 277 minecraft:red_terracotta
setblock 404 300 316 minecraft:stripped_oak_log
setblock 405 300 276 minecraft:red_terracotta
setblock 405 300 279 minecraft:red_terracotta
setblock 405 300 280 minecraft:stripped_oak_log
setblock 405 300 315 minecraft:stripped_oak_log
setblock 405 300 316 minecraft:red_terracotta
setblock 406 300 279 minecraft:stripped_oak_log
setblock 406 300 280 minecraft:red_terracotta
setblock 406 300 315 minecraft:red_terracotta
setblock 407 300 278 minecraft:stripped_oak_log
setblock 407 300 279 minecraft:red_terracotta
setblock 407 300 285 minecraft:light[level=12]
setblock 407 300 292 minecraft:light[level=12]
setblock 407 300 299 minecraft:light[level=12]
setblock 407 300 313 minecraft:light[level=12]
setblock 408 300 277 minecraft:stripped_oak_log
setblock 408 300 278 minecraft:red_terracotta
setblock 409 300 276 minecraft:stripped_oak_log
setblock 409 300 277 minecraft:red_terracotta
setblock 409 300 316 minecraft:stripped_oak_log
setblock 410 300 276 minecraft:red_terracotta
setblock 410 300 315 minecraft:stripped_oak_log
setblock 410 300 316 minecraft:red_terracotta
fill 411 300 288 411 300 298 minecraft:orange_terracotta
setblock 411 300 315 minecraft:red_terracotta
setblock 412 300 278 minecraft:stripped_oak_log
setblock 413 300 277 minecraft:stripped_oak_log
setblock 413 300 315 minecraft:stripped_oak_log
setblock 414 300 276 minecraft:stripped_oak_log
setblock 414 300 277 minecraft:red_terracotta
setblock 414 300 278 minecraft:light[level=12]
setblock 414 300 285 minecraft:light[level=12]
setblock 414 300 292 minecraft:light[level=12]
setblock 414 300 299 minecraft:light[level=12]
setblock 414 300 306 minecraft:light[level=12]
setblock 414 300 316 minecraft:stripped_oak_log
setblock 415 300 276 minecraft:red_terracotta
setblock 415 300 316 minecraft:red_terracotta
fill 416 300 301 416 300 303 minecraft:red_terracotta
setblock 416 300 304 minecraft:stripped_oak_log
fill 416 300 305 417 300 305 minecraft:red_terracotta
setblock 417 300 278 minecraft:stripped_oak_log
setblock 417 300 279 minecraft:red_terracotta
setblock 417 300 281 minecraft:red_terracotta
fill 417 300 292 417 303 294 minecraft:shroomlight
setblock 417 300 297 minecraft:red_terracotta
setblock 417 300 298 minecraft:stripped_oak_log
setblock 417 300 299 minecraft:red_terracotta
setblock 417 300 303 minecraft:stripped_oak_log
setblock 417 300 304 minecraft:red_terracotta
fill 417 300 306 417 300 307 minecraft:red_terracotta
setblock 417 300 308 minecraft:stripped_oak_log
fill 417 300 309 417 300 311 minecraft:red_terracotta
setblock 417 300 314 minecraft:red_terracotta
fill 418 300 276 418 303 316 minecraft:brown_terracotta
fill 376 304 275 376 307 317 minecraft:light_gray_terracotta
fill 377 304 275 418 307 275 minecraft:light_gray_terracotta
fill 377 304 317 418 307 317 minecraft:light_gray_terracotta
fill 418 304 276 418 307 316 minecraft:light_gray_terracotta
fill 376 308 275 376 308 317 minecraft:orange_terracotta
fill 377 308 275 418 308 275 minecraft:orange_terracotta
fill 377 308 317 418 308 317 minecraft:orange_terracotta
fill 418 308 276 418 308 316 minecraft:orange_terracotta
