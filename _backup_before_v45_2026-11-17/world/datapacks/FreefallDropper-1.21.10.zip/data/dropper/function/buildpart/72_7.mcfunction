setblock 23 185 363 minecraft:yellow_terracotta
fill 24 185 363 24 186 363 minecraft:honeycomb_block
setblock 29 185 363 minecraft:honey_block
setblock 31 185 364 minecraft:yellow_concrete
setblock 32 185 323 minecraft:honey_block
setblock 33 185 363 minecraft:yellow_terracotta
fill 34 185 363 34 188 363 minecraft:honeycomb_block
setblock 38 185 323 minecraft:honey_block
setblock 38 185 333 minecraft:yellow_terracotta
fill 38 185 334 38 186 334 minecraft:honeycomb_block
setblock 38 185 337 minecraft:honeycomb_block
setblock 38 185 353 minecraft:yellow_terracotta
setblock 38 185 354 minecraft:honeycomb_block
setblock 38 185 363 minecraft:yellow_terracotta
setblock 39 185 332 minecraft:yellow_terracotta
fill 39 185 333 39 188 333 minecraft:honeycomb_block
setblock 39 185 337 minecraft:yellow_terracotta
fill 39 185 338 39 188 338 minecraft:honeycomb_block
setblock 39 185 347 minecraft:yellow_terracotta
setblock 39 185 348 minecraft:honeycomb_block
setblock 39 185 352 minecraft:yellow_terracotta
fill 39 185 353 39 186 353 minecraft:honeycomb_block
setblock 39 185 357 minecraft:yellow_terracotta
setblock 39 185 358 minecraft:honeycomb_block
setblock 39 185 363 minecraft:honeycomb_block
setblock 40 185 331 minecraft:yellow_terracotta
fill 40 185 332 40 188 332 minecraft:honeycomb_block
setblock 40 185 336 minecraft:yellow_terracotta
fill 40 185 337 40 188 337 minecraft:honeycomb_block
setblock 40 185 341 minecraft:yellow_terracotta
fill 40 185 342 40 188 342 minecraft:honeycomb_block
setblock 40 185 346 minecraft:yellow_terracotta
fill 40 185 347 40 186 347 minecraft:honeycomb_block
setblock 40 185 351 minecraft:yellow_terracotta
fill 40 185 352 40 187 352 minecraft:honeycomb_block
setblock 40 185 356 minecraft:yellow_terracotta
fill 40 185 357 40 187 357 minecraft:honeycomb_block
fill 40 185 364 40 227 364 minecraft:honeycomb_block
setblock 41 185 326 minecraft:honeycomb_block
setblock 41 185 330 minecraft:yellow_terracotta
fill 41 185 331 41 188 331 minecraft:honeycomb_block
setblock 41 185 335 minecraft:yellow_terracotta
fill 41 185 336 41 188 336 minecraft:honeycomb_block
setblock 41 185 340 minecraft:yellow_terracotta
fill 41 185 341 41 188 341 minecraft:honeycomb_block
setblock 41 185 345 minecraft:yellow_terracotta
fill 41 185 346 41 187 346 minecraft:honeycomb_block
setblock 41 185 350 minecraft:yellow_terracotta
fill 41 185 351 41 187 351 minecraft:honeycomb_block
setblock 41 185 355 minecraft:yellow_terracotta
fill 41 185 356 41 188 356 minecraft:honeycomb_block
setblock 41 185 360 minecraft:yellow_terracotta
setblock 41 185 361 minecraft:honeycomb_block
setblock 0 186 343 minecraft:yellow_concrete
setblock 1 186 324 minecraft:yellow_terracotta
fill 1 186 325 1 187 325 minecraft:honeycomb_block
setblock 1 186 329 minecraft:yellow_terracotta
fill 1 186 330 1 189 330 minecraft:honeycomb_block
setblock 1 186 334 minecraft:yellow_terracotta
fill 1 186 335 1 189 335 minecraft:honeycomb_block
setblock 1 186 339 minecraft:yellow_terracotta
fill 1 186 340 1 189 340 minecraft:honeycomb_block
setblock 1 186 354 minecraft:yellow_terracotta
fill 1 186 355 1 187 355 minecraft:honeycomb_block
setblock 1 186 359 minecraft:yellow_terracotta
setblock 1 186 360 minecraft:honeycomb_block
setblock 2 186 328 minecraft:yellow_terracotta
fill 2 186 329 2 187 329 minecraft:honeycomb_block
setblock 2 186 333 minecraft:yellow_terracotta
fill 2 186 334 2 189 334 minecraft:honeycomb_block
setblock 2 186 338 minecraft:yellow_terracotta
setblock 2 186 339 minecraft:honeycomb_block
setblock 3 186 332 minecraft:yellow_terracotta
setblock 3 186 333 minecraft:honeycomb_block
setblock 7 186 323 minecraft:honey_block
fill 10 186 363 10 187 363 minecraft:honeycomb_block
fill 11 186 322 11 308 322 minecraft:honeycomb_block
setblock 12 186 323 minecraft:yellow_terracotta
setblock 12 186 362 minecraft:honeycomb_block
setblock 12 186 363 minecraft:yellow_terracotta
fill 13 186 323 13 189 323 minecraft:honeycomb_block
setblock 13 186 362 minecraft:yellow_terracotta
fill 13 186 363 13 189 363 minecraft:honeycomb_block
setblock 14 186 361 minecraft:yellow_terracotta
fill 14 186 362 14 189 362 minecraft:honeycomb_block
fill 15 186 361 15 189 361 minecraft:honeycomb_block
setblock 16 186 324 minecraft:yellow_terracotta
setblock 17 186 323 minecraft:yellow_terracotta
setblock 17 186 324 minecraft:honeycomb_block
setblock 17 186 363 minecraft:yellow_terracotta
fill 18 186 323 18 189 323 minecraft:honeycomb_block
setblock 18 186 362 minecraft:yellow_terracotta
fill 18 186 363 18 189 363 minecraft:honeycomb_block
setblock 19 186 361 minecraft:yellow_terracotta
fill 19 186 362 19 189 362 minecraft:honeycomb_block
fill 20 186 361 20 187 361 minecraft:honeycomb_block
fill 21 186 361 21 202 361 minecraft:yellow_terracotta
setblock 22 186 363 minecraft:yellow_terracotta
fill 23 186 363 23 187 363 minecraft:honeycomb_block
setblock 26 186 323 minecraft:honey_block
fill 31 186 364 31 200 364 minecraft:honeycomb_block
fill 33 186 363 33 189 363 minecraft:honeycomb_block
setblock 37 186 363 minecraft:yellow_terracotta
setblock 38 186 337 minecraft:yellow_terracotta
setblock 38 186 363 minecraft:honeycomb_block
setblock 39 186 331 minecraft:yellow_terracotta
fill 39 186 332 39 187 332 minecraft:honeycomb_block
setblock 39 186 336 minecraft:yellow_terracotta
fill 39 186 337 39 189 337 minecraft:honeycomb_block
setblock 39 186 341 minecraft:yellow_terracotta
setblock 39 186 351 minecraft:yellow_terracotta
setblock 39 186 352 minecraft:honeycomb_block
setblock 39 186 356 minecraft:yellow_terracotta
setblock 39 186 357 minecraft:honeycomb_block
setblock 40 186 330 minecraft:yellow_terracotta
fill 40 186 331 40 188 331 minecraft:honeycomb_block
setblock 40 186 335 minecraft:yellow_terracotta
fill 40 186 336 40 189 336 minecraft:honeycomb_block
setblock 40 186 340 minecraft:yellow_terracotta
fill 40 186 341 40 189 341 minecraft:honeycomb_block
setblock 40 186 345 minecraft:yellow_terracotta
setblock 40 186 346 minecraft:honeycomb_block
setblock 40 186 350 minecraft:yellow_terracotta
fill 40 186 351 40 187 351 minecraft:honeycomb_block
setblock 40 186 355 minecraft:yellow_terracotta
fill 40 186 356 40 187 356 minecraft:honeycomb_block
setblock 41 186 329 minecraft:yellow_terracotta
fill 41 186 330 41 189 330 minecraft:honeycomb_block
setblock 41 186 334 minecraft:yellow_terracotta
fill 41 186 335 41 189 335 minecraft:honeycomb_block
setblock 41 186 339 minecraft:yellow_terracotta
fill 41 186 340 41 189 340 minecraft:honeycomb_block
setblock 41 186 344 minecraft:yellow_terracotta
fill 41 186 345 41 187 345 minecraft:honeycomb_block
setblock 41 186 349 minecraft:yellow_terracotta
fill 41 186 350 41 187 350 minecraft:honeycomb_block
setblock 41 186 354 minecraft:yellow_terracotta
fill 41 186 355 41 188 355 minecraft:honeycomb_block
setblock 41 186 359 minecraft:yellow_terracotta
fill 41 186 360 41 187 360 minecraft:honeycomb_block
setblock 42 186 360 minecraft:yellow_concrete
fill 0 187 343 0 226 343 minecraft:honeycomb_block
setblock 1 187 328 minecraft:yellow_terracotta
fill 1 187 329 1 189 329 minecraft:honeycomb_block
setblock 1 187 333 minecraft:yellow_terracotta
fill 1 187 334 1 190 334 minecraft:honeycomb_block
setblock 1 187 338 minecraft:yellow_terracotta
fill 1 187 339 1 190 339 minecraft:honeycomb_block
setblock 1 187 354 minecraft:honeycomb_block
setblock 1 187 358 minecraft:yellow_terracotta
setblock 1 187 359 minecraft:honeycomb_block
setblock 2 187 332 minecraft:yellow_terracotta
fill 2 187 333 2 189 333 minecraft:honeycomb_block
setblock 2 187 337 minecraft:yellow_terracotta
setblock 2 187 338 minecraft:honeycomb_block
fill 4 187 332 4 195 332 minecraft:brown_terracotta
fill 10 187 332 12 188 333 minecraft:yellow_concrete
setblock 11 187 323 minecraft:yellow_terracotta
setblock 11 187 363 minecraft:yellow_terracotta
fill 12 187 323 12 190 323 minecraft:honeycomb_block
setblock 12 187 362 minecraft:yellow_terracotta
fill 12 187 363 12 190 363 minecraft:honeycomb_block
setblock 13 187 361 minecraft:yellow_terracotta
fill 13 187 362 13 190 362 minecraft:honeycomb_block
fill 14 187 361 14 190 361 minecraft:honeycomb_block
setblock 15 187 324 minecraft:yellow_terracotta
setblock 16 187 323 minecraft:yellow_terracotta
setblock 16 187 324 minecraft:honeycomb_block
setblock 16 187 363 minecraft:yellow_terracotta
fill 17 187 323 17 190 323 minecraft:honeycomb_block
setblock 17 187 362 minecraft:yellow_terracotta
fill 17 187 363 17 190 363 minecraft:honeycomb_block
setblock 18 187 361 minecraft:yellow_terracotta
fill 18 187 362 18 190 362 minecraft:honeycomb_block
fill 19 187 361 19 190 361 minecraft:honeycomb_block
setblock 20 187 323 minecraft:honey_block
setblock 21 187 363 minecraft:yellow_terracotta
fill 22 187 363 22 190 363 minecraft:honeycomb_block
fill 32 187 363 32 190 363 minecraft:honeycomb_block
setblock 36 187 363 minecraft:yellow_terracotta
fill 37 187 363 37 190 363 minecraft:honeycomb_block
setblock 38 187 335 minecraft:honeycomb_block
setblock 38 187 336 minecraft:yellow_terracotta
setblock 39 187 335 minecraft:yellow_terracotta
fill 39 187 336 39 190 336 minecraft:honeycomb_block
setblock 39 187 340 minecraft:yellow_terracotta
setblock 39 187 355 minecraft:yellow_terracotta
setblock 40 187 330 minecraft:honeycomb_block
setblock 40 187 334 minecraft:yellow_terracotta
fill 40 187 335 40 190 335 minecraft:honeycomb_block
setblock 40 187 339 minecraft:yellow_terracotta
fill 40 187 340 40 190 340 minecraft:honeycomb_block
setblock 40 187 354 minecraft:yellow_terracotta
setblock 40 187 355 minecraft:honeycomb_block
setblock 41 187 327 minecraft:honey_block
setblock 41 187 328 minecraft:yellow_terracotta
fill 41 187 329 41 188 329 minecraft:honeycomb_block
setblock 41 187 333 minecraft:yellow_terracotta
fill 41 187 334 41 190 334 minecraft:honeycomb_block
setblock 41 187 338 minecraft:yellow_terracotta
fill 41 187 339 41 190 339 minecraft:honeycomb_block
setblock 41 187 343 minecraft:yellow_terracotta
fill 41 187 344 41 188 344 minecraft:honeycomb_block
setblock 41 187 348 minecraft:yellow_terracotta
setblock 41 187 349 minecraft:honeycomb_block
setblock 41 187 353 minecraft:yellow_terracotta
fill 41 187 354 41 188 354 minecraft:honeycomb_block
setblock 41 187 358 minecraft:yellow_terracotta
fill 41 187 359 41 188 359 minecraft:honeycomb_block
setblock 41 187 363 minecraft:honey_block
fill 42 187 360 42 199 360 minecraft:honeycomb_block
setblock 1 188 327 minecraft:yellow_terracotta
setblock 1 188 328 minecraft:honeycomb_block
setblock 1 188 332 minecraft:yellow_terracotta
fill 1 188 333 1 191 333 minecraft:honeycomb_block
setblock 1 188 337 minecraft:yellow_terracotta
fill 1 188 338 1 191 338 minecraft:honeycomb_block
setblock 1 188 346 minecraft:honey_block
setblock 2 188 331 minecraft:yellow_terracotta
setblock 2 188 332 minecraft:honeycomb_block
setblock 2 188 336 minecraft:yellow_terracotta
setblock 2 188 337 minecraft:honeycomb_block
setblock 3 188 325 minecraft:light[level=12]
setblock 3 188 332 minecraft:light[level=12]
setblock 3 188 339 minecraft:light[level=12]
setblock 3 188 346 minecraft:light[level=12]
setblock 3 188 353 minecraft:light[level=12]
setblock 3 188 360 minecraft:light[level=12]
setblock 3 188 363 minecraft:honey_block
setblock 9 188 363 minecraft:honeycomb_block
setblock 10 188 323 minecraft:yellow_terracotta
setblock 10 188 325 minecraft:light[level=12]
setblock 10 188 339 minecraft:light[level=12]
setblock 10 188 346 minecraft:light[level=12]
setblock 10 188 353 minecraft:light[level=12]
setblock 10 188 360 minecraft:light[level=12]
setblock 10 188 363 minecraft:yellow_terracotta
fill 11 188 323 11 191 323 minecraft:honeycomb_block
setblock 11 188 362 minecraft:yellow_terracotta
fill 11 188 363 11 191 363 minecraft:honeycomb_block
fill 12 188 362 12 191 362 minecraft:honeycomb_block
fill 13 188 361 13 191 361 minecraft:honeycomb_block
setblock 15 188 323 minecraft:yellow_terracotta
setblock 15 188 363 minecraft:yellow_terracotta
fill 16 188 323 16 191 323 minecraft:honeycomb_block
setblock 16 188 362 minecraft:yellow_terracotta
fill 16 188 363 16 191 363 minecraft:honeycomb_block
setblock 17 188 325 minecraft:light[level=12]
setblock 17 188 332 minecraft:light[level=12]
setblock 17 188 339 minecraft:light[level=12]
setblock 17 188 346 minecraft:light[level=12]
setblock 17 188 353 minecraft:light[level=12]
setblock 17 188 360 minecraft:light[level=12]
setblock 17 188 361 minecraft:yellow_terracotta
fill 17 188 362 17 191 362 minecraft:honeycomb_block
fill 18 188 361 18 191 361 minecraft:honeycomb_block
fill 20 188 361 20 202 361 minecraft:yellow_terracotta
setblock 20 188 363 minecraft:yellow_terracotta
setblock 21 188 362 minecraft:yellow_terracotta
fill 21 188 363 21 191 363 minecraft:honeycomb_block
setblock 24 188 325 minecraft:light[level=12]
setblock 24 188 332 minecraft:light[level=12]
setblock 24 188 339 minecraft:light[level=12]
setblock 24 188 346 minecraft:light[level=12]
setblock 24 188 353 minecraft:light[level=12]
setblock 24 188 360 minecraft:light[level=12]
setblock 28 188 363 minecraft:honey_block
setblock 31 188 325 minecraft:light[level=12]
setblock 31 188 332 minecraft:light[level=12]
setblock 31 188 339 minecraft:light[level=12]
setblock 31 188 346 minecraft:light[level=12]
setblock 31 188 353 minecraft:light[level=12]
setblock 31 188 360 minecraft:light[level=12]
setblock 35 188 363 minecraft:yellow_terracotta
fill 36 188 363 36 191 363 minecraft:honeycomb_block
setblock 38 188 325 minecraft:light[level=12]
setblock 38 188 332 minecraft:light[level=12]
setblock 38 188 339 minecraft:light[level=12]
setblock 38 188 346 minecraft:light[level=12]
setblock 38 188 353 minecraft:light[level=12]
setblock 38 188 360 minecraft:light[level=12]
setblock 39 188 323 minecraft:honey_block
setblock 39 188 334 minecraft:yellow_terracotta
fill 39 188 335 39 190 335 minecraft:honeycomb_block
setblock 39 188 339 minecraft:yellow_terracotta
setblock 39 188 340 minecraft:honeycomb_block
setblock 40 188 333 minecraft:yellow_terracotta
fill 40 188 334 40 191 334 minecraft:honeycomb_block
setblock 40 188 338 minecraft:yellow_terracotta
fill 40 188 339 40 191 339 minecraft:honeycomb_block
setblock 41 188 332 minecraft:yellow_terracotta
fill 41 188 333 41 191 333 minecraft:honeycomb_block
setblock 41 188 337 minecraft:yellow_terracotta
fill 41 188 338 41 191 338 minecraft:honeycomb_block
setblock 41 188 342 minecraft:yellow_terracotta
fill 41 188 343 41 191 343 minecraft:honeycomb_block
setblock 41 188 352 minecraft:yellow_terracotta
setblock 41 188 353 minecraft:honeycomb_block
setblock 41 188 357 minecraft:yellow_terracotta
setblock 41 188 358 minecraft:honeycomb_block
setblock 1 189 327 minecraft:honey_block
setblock 1 189 331 minecraft:yellow_terracotta
fill 1 189 332 1 192 332 minecraft:honeycomb_block
setblock 1 189 336 minecraft:yellow_terracotta
fill 1 189 337 1 192 337 minecraft:honeycomb_block
setblock 1 189 352 minecraft:honey_block
setblock 2 189 335 minecraft:yellow_terracotta
setblock 2 189 336 minecraft:honeycomb_block
setblock 8 189 323 minecraft:honey_block
setblock 8 189 363 minecraft:honeycomb_block
setblock 9 189 323 minecraft:yellow_terracotta
setblock 9 189 363 minecraft:yellow_terracotta
fill 10 189 323 10 192 323 minecraft:honeycomb_block
setblock 10 189 362 minecraft:yellow_terracotta
fill 10 189 363 10 192 363 minecraft:honeycomb_block
fill 11 189 362 11 192 362 minecraft:honeycomb_block
fill 12 189 361 12 192 361 minecraft:honeycomb_block
setblock 14 189 323 minecraft:yellow_terracotta
setblock 14 189 363 minecraft:yellow_terracotta
fill 15 189 323 15 192 323 minecraft:honeycomb_block
setblock 15 189 362 minecraft:yellow_terracotta
fill 15 189 363 15 192 363 minecraft:honeycomb_block
setblock 16 189 361 minecraft:yellow_terracotta
fill 16 189 362 16 192 362 minecraft:honeycomb_block
fill 17 189 361 17 192 361 minecraft:honeycomb_block
setblock 19 189 363 minecraft:yellow_terracotta
setblock 20 189 362 minecraft:yellow_terracotta
fill 20 189 363 20 192 363 minecraft:honeycomb_block
fill 31 189 363 31 191 363 minecraft:honeycomb_block
setblock 33 189 323 minecraft:honey_block
fill 33 189 327 33 201 327 minecraft:iron_block
setblock 34 189 363 minecraft:yellow_terracotta
fill 35 189 363 35 192 363 minecraft:honeycomb_block
setblock 39 189 334 minecraft:honeycomb_block
setblock 39 189 338 minecraft:yellow_terracotta
fill 39 189 339 39 192 339 minecraft:honeycomb_block
setblock 40 189 332 minecraft:yellow_terracotta
fill 40 189 333 40 190 333 minecraft:honeycomb_block
setblock 40 189 337 minecraft:yellow_terracotta
fill 40 189 338 40 192 338 minecraft:honeycomb_block
setblock 41 189 331 minecraft:yellow_terracotta
fill 41 189 332 41 192 332 minecraft:honeycomb_block
setblock 41 189 336 minecraft:yellow_terracotta
fill 41 189 337 41 192 337 minecraft:honeycomb_block
setblock 41 189 341 minecraft:yellow_terracotta
fill 41 189 342 41 192 342 minecraft:honeycomb_block
setblock 41 189 356 minecraft:yellow_terracotta
setblock 41 189 357 minecraft:honeycomb_block
setblock 41 189 359 minecraft:honey_block
setblock 0 190 326 minecraft:yellow_terracotta
setblock 1 190 330 minecraft:yellow_terracotta
fill 1 190 331 1 191 331 minecraft:honeycomb_block
setblock 1 190 335 minecraft:yellow_terracotta
fill 1 190 336 1 193 336 minecraft:honeycomb_block
setblock 1 190 340 minecraft:yellow_terracotta
setblock 1 190 358 minecraft:honey_block
setblock 2 190 323 minecraft:honey_block
setblock 4 190 364 minecraft:yellow_terracotta
setblock 7 190 363 minecraft:honeycomb_block
setblock 8 190 323 minecraft:yellow_terracotta
setblock 8 190 363 minecraft:yellow_terracotta
fill 9 190 323 9 193 323 minecraft:honeycomb_block
setblock 9 190 362 minecraft:yellow_terracotta
fill 9 190 363 9 193 363 minecraft:honeycomb_block
fill 10 190 362 10 193 362 minecraft:honeycomb_block
fill 11 190 361 11 193 361 minecraft:honeycomb_block
setblock 13 190 323 minecraft:yellow_terracotta
setblock 13 190 363 minecraft:yellow_terracotta
fill 14 190 323 14 193 323 minecraft:honeycomb_block
fill 14 190 360 15 190 360 minecraft:honeycomb_block
setblock 14 190 362 minecraft:yellow_terracotta
fill 14 190 363 14 193 363 minecraft:honeycomb_block
setblock 15 190 361 minecraft:yellow_terracotta
fill 15 190 362 15 193 362 minecraft:honeycomb_block
fill 16 190 361 16 193 361 minecraft:honeycomb_block
setblock 18 190 363 minecraft:yellow_terracotta
setblock 19 190 362 minecraft:yellow_terracotta
fill 19 190 363 19 193 363 minecraft:honeycomb_block
fill 20 190 362 20 193 362 minecraft:honeycomb_block
setblock 27 190 323 minecraft:honey_block
setblock 29 190 322 minecraft:yellow_concrete
fill 30 190 363 30 192 363 minecraft:honeycomb_block
setblock 33 190 362 minecraft:honeycomb_block
setblock 33 190 363 minecraft:yellow_terracotta
fill 34 190 363 34 193 363 minecraft:honeycomb_block
setblock 38 190 364 minecraft:yellow_concrete
setblock 39 190 337 minecraft:yellow_terracotta
fill 39 190 338 39 193 338 minecraft:honeycomb_block
setblock 40 190 336 minecraft:yellow_terracotta
fill 40 190 337 40 193 337 minecraft:honeycomb_block
setblock 40 190 341 minecraft:yellow_terracotta
setblock 40 190 363 minecraft:honey_block
setblock 41 190 328 minecraft:honey_block
setblock 41 190 331 minecraft:honeycomb_block
setblock 41 190 335 minecraft:yellow_terracotta
fill 41 190 336 41 193 336 minecraft:honeycomb_block
setblock 41 190 340 minecraft:yellow_terracotta
fill 41 190 341 41 193 341 minecraft:honeycomb_block
setblock 41 190 353 minecraft:honey_block
fill 0 191 326 0 273 326 minecraft:honeycomb_block
setblock 1 191 334 minecraft:yellow_terracotta
fill 1 191 335 1 194 335 minecraft:honeycomb_block
setblock 1 191 339 minecraft:yellow_terracotta
fill 1 191 340 1 194 340 minecraft:honeycomb_block
setblock 2 191 363 minecraft:honey_block
fill 3 191 332 3 195 332 minecraft:brown_terracotta
fill 4 191 331 4 195 331 minecraft:brown_terracotta
fill 4 191 333 4 195 333 minecraft:brown_terracotta
fill 4 191 364 4 308 364 minecraft:honeycomb_block
fill 5 191 332 5 195 332 minecraft:brown_terracotta
setblock 6 191 363 minecraft:honeycomb_block
setblock 7 191 323 minecraft:yellow_terracotta
setblock 7 191 363 minecraft:yellow_terracotta
fill 8 191 323 8 194 323 minecraft:honeycomb_block
setblock 8 191 362 minecraft:yellow_terracotta
fill 8 191 363 8 194 363 minecraft:honeycomb_block
fill 9 191 362 9 194 362 minecraft:honeycomb_block
fill 10 191 361 10 194 361 minecraft:honeycomb_block
fill 12 191 322 12 191 323 minecraft:yellow_terracotta
fill 12 191 324 13 193 324 minecraft:honeycomb_block
setblock 12 191 363 minecraft:yellow_terracotta
fill 13 191 323 13 194 323 minecraft:honeycomb_block
fill 13 191 360 14 191 360 minecraft:honeycomb_block
setblock 13 191 362 minecraft:yellow_terracotta
fill 13 191 363 13 194 363 minecraft:honeycomb_block
setblock 14 191 361 minecraft:yellow_terracotta
fill 14 191 362 14 194 362 minecraft:honeycomb_block
setblock 15 191 360 minecraft:yellow_terracotta
fill 15 191 361 15 194 361 minecraft:honeycomb_block
fill 16 191 360 16 194 360 minecraft:honeycomb_block
setblock 17 191 323 minecraft:yellow_terracotta
setblock 17 191 363 minecraft:yellow_terracotta
setblock 18 191 362 minecraft:yellow_terracotta
fill 18 191 363 18 194 363 minecraft:honeycomb_block
fill 19 191 362 19 194 362 minecraft:honeycomb_block
setblock 21 191 323 minecraft:honey_block
setblock 22 191 363 minecraft:yellow_terracotta
fill 23 191 333 23 192 335 minecraft:yellow_concrete
fill 23 191 363 23 194 363 minecraft:honeycomb_block
fill 24 191 334 24 192 334 minecraft:yellow_concrete
fill 28 191 363 29 193 363 minecraft:honeycomb_block
fill 29 191 322 29 257 322 minecraft:honeycomb_block
fill 31 191 362 32 191 362 minecraft:honeycomb_block
setblock 32 191 363 minecraft:yellow_terracotta
setblock 33 191 362 minecraft:yellow_terracotta
fill 33 191 363 33 194 363 minecraft:honeycomb_block
fill 34 191 362 35 193 362 minecraft:honeycomb_block
setblock 37 191 363 minecraft:yellow_terracotta
fill 38 191 364 38 193 364 minecraft:honeycomb_block
setblock 39 191 336 minecraft:yellow_terracotta
fill 39 191 337 39 194 337 minecraft:honeycomb_block
setblock 40 191 323 minecraft:honey_block
setblock 40 191 335 minecraft:yellow_terracotta
fill 40 191 336 40 194 336 minecraft:honeycomb_block
setblock 40 191 340 minecraft:yellow_terracotta
fill 40 191 341 40 194 341 minecraft:honeycomb_block
setblock 41 191 334 minecraft:yellow_terracotta
fill 41 191 335 41 194 335 minecraft:honeycomb_block
setblock 41 191 339 minecraft:yellow_terracotta
fill 41 191 340 41 194 340 minecraft:honeycomb_block
setblock 41 191 347 minecraft:honey_block
setblock 1 192 326 minecraft:honey_block
setblock 1 192 333 minecraft:yellow_terracotta
fill 1 192 334 1 195 334 minecraft:honeycomb_block
setblock 1 192 338 minecraft:yellow_terracotta
fill 1 192 339 1 195 339 minecraft:honeycomb_block
setblock 1 192 345 minecraft:honey_block
fill 2 192 353 2 198 353 minecraft:brown_terracotta
setblock 3 192 325 minecraft:light[level=15]
setblock 3 192 333 minecraft:light[level=15]
setblock 3 192 341 minecraft:light[level=15]
setblock 3 192 349 minecraft:light[level=15]
setblock 3 192 357 minecraft:light[level=15]
fill 4 192 363 5 192 363 minecraft:honeycomb_block
setblock 5 192 323 minecraft:honeycomb_block
setblock 6 192 323 minecraft:yellow_terracotta
setblock 6 192 363 minecraft:yellow_terracotta
fill 7 192 323 7 195 323 minecraft:honeycomb_block
setblock 7 192 362 minecraft:yellow_terracotta
fill 7 192 363 7 195 363 minecraft:honeycomb_block
fill 8 192 362 8 195 362 minecraft:honeycomb_block
fill 9 192 361 9 195 361 minecraft:honeycomb_block
setblock 10 192 324 minecraft:yellow_terracotta
setblock 11 192 323 minecraft:yellow_terracotta
fill 11 192 324 11 195 324 minecraft:honeycomb_block
setblock 11 192 325 minecraft:light[level=15]
setblock 11 192 333 minecraft:light[level=15]
setblock 11 192 341 minecraft:light[level=15]
setblock 11 192 349 minecraft:light[level=15]
setblock 11 192 357 minecraft:light[level=15]
setblock 11 192 363 minecraft:yellow_terracotta
fill 12 192 322 12 195 323 minecraft:honeycomb_block
fill 12 192 360 13 192 360 minecraft:honeycomb_block
setblock 12 192 362 minecraft:yellow_terracotta
fill 12 192 363 12 195 363 minecraft:honeycomb_block
setblock 13 192 361 minecraft:yellow_terracotta
fill 13 192 362 13 195 362 minecraft:honeycomb_block
setblock 14 192 324 minecraft:honeycomb_block
setblock 14 192 360 minecraft:yellow_terracotta
fill 14 192 361 14 195 361 minecraft:honeycomb_block
fill 15 192 360 15 195 360 minecraft:honeycomb_block
setblock 16 192 323 minecraft:yellow_terracotta
setblock 16 192 363 minecraft:yellow_terracotta
fill 17 192 323 17 195 323 minecraft:honeycomb_block
setblock 17 192 362 minecraft:yellow_terracotta
fill 17 192 363 17 195 363 minecraft:honeycomb_block
setblock 18 192 361 minecraft:yellow_terracotta
fill 18 192 362 18 195 362 minecraft:honeycomb_block
setblock 19 192 325 minecraft:light[level=15]
setblock 19 192 333 minecraft:light[level=15]
setblock 19 192 341 minecraft:light[level=15]
setblock 19 192 349 minecraft:light[level=15]
setblock 19 192 357 minecraft:light[level=15]
fill 19 192 361 19 195 361 minecraft:honeycomb_block
setblock 21 192 362 minecraft:honeycomb_block
setblock 21 192 363 minecraft:yellow_terracotta
fill 22 192 363 22 195 363 minecraft:honeycomb_block
fill 24 192 363 25 192 363 minecraft:honeycomb_block
setblock 26 192 363 minecraft:yellow_terracotta
setblock 27 192 325 minecraft:light[level=15]
setblock 27 192 333 minecraft:light[level=15]
setblock 27 192 341 minecraft:light[level=15]
setblock 27 192 349 minecraft:light[level=15]
setblock 27 192 357 minecraft:light[level=15]
fill 27 192 363 27 195 363 minecraft:honeycomb_block
fill 29 192 362 31 192 362 minecraft:honeycomb_block
setblock 31 192 363 minecraft:yellow_terracotta
setblock 32 192 362 minecraft:yellow_terracotta
fill 32 192 363 32 195 363 minecraft:honeycomb_block
fill 33 192 362 33 195 362 minecraft:honeycomb_block
setblock 34 192 323 minecraft:honey_block
setblock 35 192 325 minecraft:light[level=15]
setblock 35 192 333 minecraft:light[level=15]
setblock 35 192 341 minecraft:light[level=15]
setblock 35 192 349 minecraft:light[level=15]
setblock 35 192 357 minecraft:light[level=15]
setblock 36 192 363 minecraft:yellow_terracotta
setblock 36 192 364 minecraft:yellow_concrete
fill 37 192 363 37 195 363 minecraft:honeycomb_block
setblock 39 192 340 minecraft:yellow_terracotta
setblock 40 192 334 minecraft:yellow_terracotta
fill 40 192 335 40 195 335 minecraft:honeycomb_block
setblock 40 192 339 minecraft:yellow_terracotta
fill 40 192 340 40 195 340 minecraft:honeycomb_block
fill 40 192 342 40 193 342 minecraft:honeycomb_block
setblock 41 192 333 minecraft:yellow_terracotta
fill 41 192 334 41 195 334 minecraft:honeycomb_block
setblock 41 192 338 minecraft:yellow_terracotta
fill 41 192 339 41 195 339 minecraft:honeycomb_block
setblock 41 192 343 minecraft:yellow_terracotta
setblock 41 192 360 minecraft:honey_block
setblock 42 192 352 minecraft:yellow_concrete
fill 1 193 323 1 195 324 minecraft:honeycomb_block
setblock 1 193 332 minecraft:honey_block
fill 1 193 333 1 194 333 minecraft:honeycomb_block
setblock 1 193 337 minecraft:yellow_terracotta
fill 1 193 338 1 196 338 minecraft:honeycomb_block
setblock 1 193 341 minecraft:honeycomb_block
setblock 1 193 351 minecraft:honey_block
fill 1 193 360 1 193 361 minecraft:honeycomb_block
setblock 1 193 362 minecraft:yellow_terracotta
fill 1 193 363 4 193 363 minecraft:honeycomb_block
fill 2 193 323 4 193 323 minecraft:honeycomb_block
fill 3 193 331 3 195 331 minecraft:brown_terracotta
fill 3 193 333 3 195 333 minecraft:brown_terracotta
setblock 5 193 323 minecraft:yellow_terracotta
fill 5 193 331 5 195 331 minecraft:brown_terracotta
fill 5 193 333 5 195 333 minecraft:brown_terracotta
setblock 5 193 362 minecraft:honeycomb_block
setblock 5 193 363 minecraft:yellow_terracotta
fill 6 193 323 6 196 323 minecraft:honeycomb_block
setblock 6 193 362 minecraft:yellow_terracotta
fill 6 193 363 6 196 363 minecraft:honeycomb_block
fill 7 193 362 7 196 362 minecraft:honeycomb_block
setblock 8 193 324 minecraft:honeycomb_block
fill 8 193 361 8 196 361 minecraft:honeycomb_block
setblock 9 193 324 minecraft:yellow_terracotta
setblock 10 193 323 minecraft:yellow_terracotta
fill 10 193 324 10 196 324 minecraft:honeycomb_block
fill 10 193 360 12 193 360 minecraft:honeycomb_block
setblock 10 193 363 minecraft:yellow_terracotta
fill 11 193 323 11 196 323 minecraft:honeycomb_block
setblock 11 193 362 minecraft:yellow_terracotta
fill 11 193 363 11 196 363 minecraft:honeycomb_block
setblock 12 193 361 minecraft:yellow_terracotta
fill 12 193 362 12 196 362 minecraft:honeycomb_block
setblock 13 193 360 minecraft:yellow_terracotta
fill 13 193 361 13 196 361 minecraft:honeycomb_block
setblock 14 193 324 minecraft:yellow_terracotta
fill 14 193 360 14 196 360 minecraft:honeycomb_block
setblock 15 193 323 minecraft:yellow_terracotta
fill 15 193 324 15 196 324 minecraft:honeycomb_block
setblock 15 193 363 minecraft:yellow_terracotta
fill 16 193 323 16 196 323 minecraft:honeycomb_block
setblock 16 193 362 minecraft:yellow_terracotta
fill 16 193 363 16 196 363 minecraft:honeycomb_block
setblock 17 193 361 minecraft:yellow_terracotta
fill 17 193 362 17 196 362 minecraft:honeycomb_block
fill 18 193 323 18 194 323 minecraft:honeycomb_block
fill 18 193 361 18 196 361 minecraft:honeycomb_block
setblock 20 193 363 minecraft:yellow_terracotta
setblock 21 193 362 minecraft:yellow_terracotta
fill 21 193 363 21 196 363 minecraft:honeycomb_block
fill 22 193 362 22 196 362 minecraft:honeycomb_block
setblock 24 193 363 minecraft:honeycomb_block
setblock 25 193 363 minecraft:yellow_terracotta
setblock 26 193 362 minecraft:yellow_terracotta
fill 26 193 363 26 196 363 minecraft:honeycomb_block
fill 27 193 362 30 193 362 minecraft:honeycomb_block
setblock 28 193 323 minecraft:honey_block
setblock 29 193 364 minecraft:yellow_concrete
setblock 30 193 363 minecraft:yellow_terracotta
fill 31 193 323 34 193 323 minecraft:honeycomb_block
setblock 31 193 361 minecraft:honeycomb_block
setblock 31 193 362 minecraft:yellow_terracotta
fill 31 193 363 31 196 363 minecraft:honeycomb_block
setblock 32 193 361 minecraft:yellow_terracotta
fill 32 193 362 32 196 362 minecraft:honeycomb_block
setblock 35 193 323 minecraft:yellow_terracotta
setblock 35 193 363 minecraft:yellow_terracotta
fill 36 193 323 36 196 323 minecraft:honeycomb_block
setblock 36 193 362 minecraft:yellow_terracotta
fill 36 193 363 36 196 364 minecraft:honeycomb_block
fill 38 193 363 38 194 363 minecraft:honeycomb_block
setblock 39 193 339 minecraft:yellow_terracotta
fill 39 193 340 39 196 340 minecraft:honeycomb_block
setblock 40 193 338 minecraft:yellow_terracotta
fill 40 193 339 40 196 339 minecraft:honeycomb_block
setblock 41 193 332 minecraft:yellow_terracotta
fill 41 193 333 41 196 333 minecraft:honeycomb_block
setblock 41 193 337 minecraft:yellow_terracotta
fill 41 193 338 41 196 338 minecraft:honeycomb_block
setblock 41 193 342 minecraft:yellow_terracotta
fill 41 193 343 41 195 344 minecraft:honeycomb_block
setblock 41 193 354 minecraft:honey_block
fill 42 193 352 42 208 352 minecraft:honeycomb_block
setblock 42 193 361 minecraft:orange_terracotta
setblock 0 194 355 minecraft:yellow_concrete
setblock 1 194 325 minecraft:honeycomb_block
setblock 1 194 336 minecraft:yellow_terracotta
fill 1 194 337 1 197 337 minecraft:honeycomb_block
setblock 1 194 341 minecraft:yellow_terracotta
fill 1 194 342 1 197 342 minecraft:honeycomb_block
setblock 1 194 357 minecraft:honey_block
setblock 1 194 360 minecraft:honeycomb_block
setblock 1 194 361 minecraft:yellow_terracotta
fill 1 194 362 1 196 363 minecraft:honeycomb_block
fill 2 194 323 3 194 323 minecraft:honeycomb_block
fill 2 194 363 3 194 363 minecraft:honeycomb_block
setblock 3 194 325 minecraft:light[level=12]
setblock 3 194 339 minecraft:light[level=12]
setblock 3 194 346 minecraft:light[level=12]
setblock 3 194 353 minecraft:light[level=12]
setblock 3 194 360 minecraft:light[level=12]
setblock 4 194 323 minecraft:yellow_terracotta
setblock 4 194 362 minecraft:honeycomb_block
setblock 4 194 363 minecraft:yellow_terracotta
fill 5 194 323 5 197 323 minecraft:honeycomb_block
setblock 5 194 362 minecraft:yellow_terracotta
fill 5 194 363 5 197 363 minecraft:honeycomb_block
fill 6 194 324 7 194 324 minecraft:honeycomb_block
fill 6 194 362 6 197 362 minecraft:honeycomb_block
fill 7 194 361 7 197 361 minecraft:honeycomb_block
setblock 8 194 324 minecraft:yellow_terracotta
setblock 9 194 323 minecraft:yellow_terracotta
fill 9 194 324 9 197 324 minecraft:honeycomb_block
fill 9 194 360 11 194 360 minecraft:honeycomb_block
setblock 9 194 363 minecraft:yellow_terracotta
fill 10 194 323 10 197 323 minecraft:honeycomb_block
setblock 10 194 325 minecraft:light[level=12]
setblock 10 194 332 minecraft:light[level=12]
setblock 10 194 339 minecraft:light[level=12]
setblock 10 194 346 minecraft:light[level=12]
setblock 10 194 353 minecraft:light[level=12]
setblock 10 194 362 minecraft:yellow_terracotta
fill 10 194 363 10 197 363 minecraft:honeycomb_block
setblock 11 194 361 minecraft:yellow_terracotta
fill 11 194 362 11 197 362 minecraft:honeycomb_block
setblock 12 194 324 minecraft:honeycomb_block
setblock 12 194 360 minecraft:yellow_terracotta
fill 12 194 361 12 197 361 minecraft:honeycomb_block
setblock 13 194 324 minecraft:yellow_terracotta
fill 13 194 331 14 195 331 minecraft:yellow_concrete
fill 13 194 360 13 197 360 minecraft:honeycomb_block
setblock 14 194 323 minecraft:yellow_terracotta
fill 14 194 324 14 197 324 minecraft:honeycomb_block
setblock 14 194 363 minecraft:yellow_terracotta
fill 15 194 323 15 197 323 minecraft:honeycomb_block
setblock 15 194 362 minecraft:yellow_terracotta
fill 15 194 363 15 197 363 minecraft:honeycomb_block
setblock 16 194 361 minecraft:yellow_terracotta
fill 16 194 362 16 197 362 minecraft:honeycomb_block
setblock 17 194 325 minecraft:light[level=12]
setblock 17 194 332 minecraft:light[level=12]
setblock 17 194 339 minecraft:light[level=12]
setblock 17 194 346 minecraft:light[level=12]
setblock 17 194 353 minecraft:light[level=12]
setblock 17 194 360 minecraft:light[level=12]
fill 17 194 361 17 197 361 minecraft:honeycomb_block
setblock 19 194 363 minecraft:yellow_terracotta
setblock 20 194 362 minecraft:yellow_terracotta
fill 20 194 363 20 197 363 minecraft:honeycomb_block
fill 21 194 362 21 197 362 minecraft:honeycomb_block
setblock 22 194 323 minecraft:honey_block
setblock 23 194 322 minecraft:yellow_concrete
fill 23 194 362 24 194 362 minecraft:honeycomb_block
setblock 24 194 325 minecraft:light[level=12]
setblock 24 194 332 minecraft:light[level=12]
setblock 24 194 339 minecraft:light[level=12]
setblock 24 194 346 minecraft:light[level=12]
setblock 24 194 353 minecraft:light[level=12]
setblock 24 194 360 minecraft:light[level=12]
setblock 24 194 363 minecraft:yellow_terracotta
setblock 25 194 362 minecraft:yellow_terracotta
fill 25 194 363 25 197 363 minecraft:honeycomb_block
fill 26 194 362 29 194 362 minecraft:honeycomb_block
setblock 28 194 363 minecraft:honeycomb_block
setblock 29 194 323 minecraft:yellow_terracotta
fill 29 194 361 30 194 361 minecraft:honeycomb_block
setblock 29 194 363 minecraft:yellow_terracotta
fill 29 194 364 29 203 364 minecraft:honeycomb_block
fill 30 194 323 33 194 323 minecraft:honeycomb_block
setblock 30 194 362 minecraft:yellow_terracotta
fill 30 194 363 30 197 363 minecraft:honeycomb_block
setblock 31 194 325 minecraft:light[level=12]
setblock 31 194 332 minecraft:light[level=12]
setblock 31 194 339 minecraft:light[level=12]
setblock 31 194 346 minecraft:light[level=12]
setblock 31 194 353 minecraft:light[level=12]
setblock 31 194 360 minecraft:light[level=12]
setblock 31 194 361 minecraft:yellow_terracotta
fill 31 194 362 31 197 362 minecraft:honeycomb_block
fill 32 194 361 33 196 361 minecraft:honeycomb_block
setblock 34 194 323 minecraft:yellow_terracotta
setblock 34 194 362 minecraft:honeycomb_block
setblock 34 194 363 minecraft:yellow_terracotta
fill 35 194 323 35 197 323 minecraft:honeycomb_block
setblock 35 194 362 minecraft:yellow_terracotta
fill 35 194 363 35 197 363 minecraft:honeycomb_block
fill 36 194 362 36 196 362 minecraft:honeycomb_block
fill 37 194 323 38 194 323 minecraft:honeycomb_block
setblock 38 194 325 minecraft:light[level=12]
setblock 38 194 332 minecraft:light[level=12]
setblock 38 194 339 minecraft:light[level=12]
setblock 38 194 346 minecraft:light[level=12]
setblock 38 194 353 minecraft:light[level=12]
setblock 38 194 360 minecraft:light[level=12]
setblock 38 194 364 minecraft:yellow_concrete
setblock 39 194 338 minecraft:yellow_terracotta
fill 39 194 339 39 196 339 minecraft:honeycomb_block
fill 39 194 341 39 195 341 minecraft:honeycomb_block
setblock 39 194 363 minecraft:yellow_terracotta
setblock 40 194 337 minecraft:yellow_terracotta
fill 40 194 338 40 197 338 minecraft:honeycomb_block
setblock 40 194 342 minecraft:yellow_terracotta
fill 40 194 343 40 197 343 minecraft:honeycomb_block
setblock 41 194 323 minecraft:honey_block
setblock 41 194 329 minecraft:honey_block
fill 41 194 332 41 197 332 minecraft:honeycomb_block
setblock 41 194 336 minecraft:yellow_terracotta
fill 41 194 337 41 197 337 minecraft:honeycomb_block
setblock 41 194 341 minecraft:yellow_terracotta
fill 41 194 342 41 197 342 minecraft:honeycomb_block
setblock 41 194 348 minecraft:honey_block
fill 42 194 361 42 279 361 minecraft:honeycomb_block
fill 0 195 355 0 308 355 minecraft:honeycomb_block
setblock 1 195 325 minecraft:yellow_terracotta
fill 1 195 326 1 197 327 minecraft:honeycomb_block
setblock 1 195 335 minecraft:yellow_terracotta
fill 1 195 336 1 197 336 minecraft:honeycomb_block
setblock 1 195 340 minecraft:yellow_terracotta
fill 1 195 341 1 198 341 minecraft:honeycomb_block
setblock 1 195 344 minecraft:honey_block
setblock 1 195 359 minecraft:honeycomb_block
setblock 1 195 360 minecraft:yellow_terracotta
fill 1 195 361 1 198 361 minecraft:honeycomb_block
setblock 2 195 323 minecraft:honeycomb_block
fill 2 195 362 2 195 363 minecraft:honeycomb_block
setblock 3 195 323 minecraft:yellow_terracotta
fill 3 195 324 6 195 324 minecraft:honeycomb_block
setblock 3 195 362 minecraft:honeycomb_block
setblock 3 195 363 minecraft:yellow_terracotta
fill 4 195 323 4 198 323 minecraft:honeycomb_block
setblock 4 195 362 minecraft:yellow_terracotta
fill 4 195 363 4 198 363 minecraft:honeycomb_block
fill 5 195 362 5 198 362 minecraft:honeycomb_block
fill 6 195 361 6 198 361 minecraft:honeycomb_block
setblock 7 195 324 minecraft:yellow_terracotta
setblock 8 195 323 minecraft:yellow_terracotta
fill 8 195 324 8 198 324 minecraft:honeycomb_block
fill 8 195 360 10 195 360 minecraft:honeycomb_block
setblock 8 195 363 minecraft:yellow_terracotta
fill 9 195 323 9 198 323 minecraft:honeycomb_block
fill 9 195 325 10 195 325 minecraft:honeycomb_block
setblock 9 195 362 minecraft:yellow_terracotta
fill 9 195 363 9 198 363 minecraft:honeycomb_block
setblock 10 195 361 minecraft:yellow_terracotta
fill 10 195 362 10 198 362 minecraft:honeycomb_block
setblock 11 195 325 minecraft:yellow_terracotta
setblock 11 195 360 minecraft:yellow_terracotta
fill 11 195 361 11 198 361 minecraft:honeycomb_block
setblock 12 195 324 minecraft:yellow_terracotta
fill 12 195 360 12 198 360 minecraft:honeycomb_block
setblock 13 195 323 minecraft:yellow_terracotta
fill 13 195 324 13 198 324 minecraft:honeycomb_block
setblock 13 195 363 minecraft:yellow_terracotta
fill 14 195 323 14 198 323 minecraft:honeycomb_block
setblock 14 195 362 minecraft:yellow_terracotta
fill 14 195 363 14 198 363 minecraft:honeycomb_block
setblock 15 195 361 minecraft:yellow_terracotta
fill 15 195 362 15 198 362 minecraft:honeycomb_block
setblock 16 195 360 minecraft:yellow_terracotta
fill 16 195 361 16 198 361 minecraft:honeycomb_block
setblock 18 195 323 minecraft:yellow_terracotta
fill 18 195 355 18 196 355 minecraft:black_concrete
setblock 18 195 363 minecraft:yellow_terracotta
fill 19 195 323 19 198 323 minecraft:honeycomb_block
fill 19 195 355 19 196 355 minecraft:yellow_concrete
setblock 19 195 362 minecraft:yellow_terracotta
fill 19 195 363 19 198 363 minecraft:honeycomb_block
fill 20 195 362 20 198 362 minecraft:honeycomb_block
fill 23 195 322 23 308 322 minecraft:honeycomb_block
setblock 23 195 362 minecraft:honeycomb_block
setblock 23 195 363 minecraft:yellow_terracotta
setblock 24 195 362 minecraft:yellow_terracotta
fill 24 195 363 24 198 363 minecraft:honeycomb_block
fill 25 195 362 28 195 362 minecraft:honeycomb_block
setblock 27 195 323 minecraft:honeycomb_block
fill 27 195 361 29 195 361 minecraft:honeycomb_block
setblock 28 195 323 minecraft:yellow_terracotta
setblock 28 195 363 minecraft:yellow_terracotta
fill 29 195 323 32 195 323 minecraft:honeycomb_block
setblock 29 195 362 minecraft:yellow_terracotta
fill 29 195 363 29 198 363 minecraft:honeycomb_block
setblock 30 195 361 minecraft:yellow_terracotta
fill 30 195 362 30 198 362 minecraft:honeycomb_block
setblock 31 195 324 minecraft:honeycomb_block
fill 31 195 361 31 198 361 minecraft:honeycomb_block
setblock 32 195 324 minecraft:yellow_terracotta
setblock 33 195 323 minecraft:yellow_terracotta
fill 33 195 324 34 197 324 minecraft:honeycomb_block
setblock 33 195 363 minecraft:yellow_terracotta
fill 34 195 323 34 198 323 minecraft:honeycomb_block
setblock 34 195 362 minecraft:yellow_terracotta
fill 34 195 363 34 198 363 minecraft:honeycomb_block
setblock 34 195 364 minecraft:orange_terracotta
fill 35 195 362 35 197 362 minecraft:honeycomb_block
setblock 37 195 323 minecraft:honeycomb_block
setblock 38 195 323 minecraft:yellow_terracotta
setblock 38 195 363 minecraft:yellow_terracotta
fill 38 195 364 38 302 364 minecraft:honeycomb_block
fill 39 195 323 41 196 323 minecraft:honeycomb_block
fill 39 195 337 39 200 337 minecraft:yellow_terracotta
setblock 39 195 338 minecraft:honeycomb_block
fill 39 195 363 40 197 363 minecraft:honeycomb_block
setblock 40 195 336 minecraft:yellow_terracotta
fill 40 195 337 40 197 337 minecraft:honeycomb_block
setblock 40 195 341 minecraft:yellow_terracotta
fill 40 195 342 40 198 342 minecraft:honeycomb_block
setblock 41 195 324 minecraft:honeycomb_block
setblock 41 195 335 minecraft:yellow_terracotta
fill 41 195 336 41 198 336 minecraft:honeycomb_block
setblock 41 195 340 minecraft:yellow_terracotta
fill 41 195 341 41 198 341 minecraft:honeycomb_block
setblock 41 195 345 minecraft:yellow_terracotta
fill 41 195 361 41 196 361 minecraft:honey_block
setblock 0 196 348 minecraft:yellow_terracotta
setblock 0 196 360 minecraft:yellow_concrete
setblock 1 196 323 minecraft:honeycomb_block
setblock 1 196 324 minecraft:yellow_terracotta
fill 1 196 325 2 198 325 minecraft:honeycomb_block
setblock 1 196 328 minecraft:honeycomb_block
setblock 1 196 335 minecraft:honeycomb_block
setblock 1 196 339 minecraft:yellow_terracotta
fill 1 196 340 1 199 340 minecraft:honeycomb_block
setblock 1 196 343 minecraft:honeycomb_block
setblock 1 196 350 minecraft:honey_block
fill 1 196 353 1 198 353 minecraft:brown_terracotta
setblock 1 196 359 minecraft:yellow_terracotta
fill 1 196 360 1 199 360 minecraft:honeycomb_block
setblock 2 196 323 minecraft:yellow_terracotta
fill 2 196 324 5 196 324 minecraft:honeycomb_block
fill 2 196 352 2 198 352 minecraft:brown_terracotta
fill 2 196 354 2 198 354 minecraft:brown_terracotta
fill 2 196 361 2 196 362 minecraft:honeycomb_block
setblock 2 196 363 minecraft:yellow_terracotta
fill 3 196 323 3 199 323 minecraft:honeycomb_block
fill 3 196 353 3 198 353 minecraft:brown_terracotta
setblock 3 196 362 minecraft:yellow_terracotta
fill 3 196 363 3 199 363 minecraft:honeycomb_block
fill 4 196 362 4 199 362 minecraft:honeycomb_block
fill 5 196 361 5 199 361 minecraft:honeycomb_block
setblock 6 196 324 minecraft:yellow_terracotta
setblock 7 196 323 minecraft:yellow_terracotta
fill 7 196 324 7 198 325 minecraft:honeycomb_block
setblock 7 196 363 minecraft:yellow_terracotta
fill 8 196 323 8 199 323 minecraft:honeycomb_block
fill 8 196 325 9 196 325 minecraft:honeycomb_block
fill 8 196 360 9 196 360 minecraft:honeycomb_block
setblock 8 196 362 minecraft:yellow_terracotta
fill 8 196 363 8 199 363 minecraft:honeycomb_block
setblock 9 196 361 minecraft:yellow_terracotta
fill 9 196 362 9 199 362 minecraft:honeycomb_block
setblock 10 196 325 minecraft:yellow_terracotta
setblock 10 196 360 minecraft:yellow_terracotta
fill 10 196 361 10 199 361 minecraft:honeycomb_block
setblock 11 196 324 minecraft:yellow_terracotta
fill 11 196 325 12 198 325 minecraft:honeycomb_block
fill 11 196 360 11 199 360 minecraft:honeycomb_block
fill 12 196 322 12 284 322 minecraft:honeycomb_block
setblock 12 196 323 minecraft:yellow_terracotta
fill 12 196 324 12 199 324 minecraft:honeycomb_block
setblock 12 196 363 minecraft:yellow_terracotta
fill 13 196 323 13 199 323 minecraft:honeycomb_block
setblock 13 196 362 minecraft:yellow_terracotta
fill 13 196 363 13 199 363 minecraft:honeycomb_block
setblock 14 196 361 minecraft:yellow_terracotta
fill 14 196 362 14 199 362 minecraft:honeycomb_block
setblock 15 196 360 minecraft:yellow_terracotta
fill 15 196 361 15 199 361 minecraft:honeycomb_block
setblock 16 196 324 minecraft:yellow_terracotta
setblock 17 196 323 minecraft:yellow_terracotta
fill 17 196 328 17 197 328 minecraft:yellow_concrete
setblock 17 196 363 minecraft:yellow_terracotta
fill 18 196 323 18 199 323 minecraft:honeycomb_block
setblock 18 196 362 minecraft:yellow_terracotta
fill 18 196 363 18 199 363 minecraft:honeycomb_block
fill 19 196 362 19 199 362 minecraft:honeycomb_block
setblock 22 196 363 minecraft:yellow_terracotta
setblock 23 196 362 minecraft:yellow_terracotta
fill 23 196 363 23 199 363 minecraft:honeycomb_block
fill 24 196 362 27 196 362 minecraft:honeycomb_block
fill 25 196 323 26 196 323 minecraft:honeycomb_block
setblock 27 196 323 minecraft:yellow_terracotta
fill 27 196 361 28 196 361 minecraft:honeycomb_block
setblock 27 196 363 minecraft:yellow_terracotta
fill 28 196 323 31 196 323 minecraft:honeycomb_block
setblock 28 196 362 minecraft:yellow_terracotta
fill 28 196 363 28 199 363 minecraft:honeycomb_block
fill 29 196 324 30 196 324 minecraft:honeycomb_block
setblock 29 196 361 minecraft:yellow_terracotta
fill 29 196 362 29 199 362 minecraft:honeycomb_block
fill 30 196 361 30 198 361 minecraft:honeycomb_block
setblock 31 196 324 minecraft:yellow_terracotta
setblock 32 196 323 minecraft:yellow_terracotta
fill 32 196 324 32 199 324 minecraft:honeycomb_block
setblock 32 196 363 minecraft:yellow_terracotta
fill 33 196 323 33 199 323 minecraft:honeycomb_block
setblock 33 196 362 minecraft:yellow_terracotta
fill 33 196 363 33 199 363 minecraft:honeycomb_block
fill 34 196 362 34 198 362 minecraft:honeycomb_block
fill 34 196 364 34 308 364 minecraft:honeycomb_block
setblock 35 196 324 minecraft:honeycomb_block
setblock 36 196 324 minecraft:yellow_terracotta
setblock 37 196 323 minecraft:yellow_terracotta
setblock 37 196 363 minecraft:yellow_terracotta
fill 38 196 323 38 199 323 minecraft:honeycomb_block
fill 38 196 363 38 199 363 minecraft:honeycomb_block
setblock 39 196 341 minecraft:yellow_terracotta
setblock 39 196 342 minecraft:honeycomb_block
fill 40 196 336 40 197 336 minecraft:honeycomb_block
setblock 40 196 340 minecraft:yellow_terracotta
fill 40 196 341 40 199 341 minecraft:honeycomb_block
setblock 40 196 344 minecraft:honeycomb_block
setblock 41 196 324 minecraft:yellow_terracotta
fill 41 196 325 41 197 327 minecraft:honeycomb_block
setblock 41 196 334 minecraft:yellow_terracotta
fill 41 196 335 41 199 335 minecraft:honeycomb_block
setblock 41 196 339 minecraft:yellow_terracotta
fill 41 196 340 41 199 340 minecraft:honeycomb_block
setblock 41 196 343 minecraft:honeycomb_block
setblock 41 196 344 minecraft:yellow_terracotta
fill 41 196 345 41 198 346 minecraft:honeycomb_block
setblock 41 196 355 minecraft:honey_block
fill 41 196 362 41 196 363 minecraft:honeycomb_block
fill 0 197 348 0 223 348 minecraft:honeycomb_block
fill 0 197 360 0 308 360 minecraft:honeycomb_block
setblock 1 197 323 minecraft:yellow_terracotta
fill 1 197 324 4 197 324 minecraft:honeycomb_block
setblock 1 197 328 minecraft:yellow_terracotta
fill 1 197 329 1 200 329 minecraft:honeycomb_block
setblock 1 197 331 minecraft:honey_block
setblock 1 197 338 minecraft:yellow_terracotta
fill 1 197 339 1 198 339 minecraft:honeycomb_block
setblock 1 197 343 minecraft:yellow_terracotta
fill 1 197 344 1 200 344 minecraft:honeycomb_block
setblock 1 197 356 minecraft:honey_block
fill 1 197 359 1 198 359 minecraft:honeycomb_block
setblock 1 197 362 minecraft:honeycomb_block
setblock 1 197 363 minecraft:yellow_terracotta
fill 2 197 323 2 200 323 minecraft:honeycomb_block
setblock 2 197 326 minecraft:honeycomb_block
setblock 2 197 361 minecraft:honeycomb_block
setblock 2 197 362 minecraft:yellow_terracotta
fill 2 197 363 2 200 363 minecraft:honeycomb_block
fill 3 197 362 3 200 362 minecraft:honeycomb_block
fill 4 197 361 4 199 361 minecraft:honeycomb_block
setblock 5 197 324 minecraft:yellow_terracotta
fill 5 197 325 6 199 325 minecraft:honeycomb_block
setblock 6 197 323 minecraft:yellow_terracotta
fill 6 197 324 6 200 324 minecraft:honeycomb_block
setblock 6 197 363 minecraft:yellow_terracotta
fill 7 197 323 7 200 323 minecraft:honeycomb_block
fill 7 197 360 8 197 360 minecraft:honeycomb_block
setblock 7 197 362 minecraft:yellow_terracotta
fill 7 197 363 7 200 363 minecraft:honeycomb_block
setblock 8 197 325 minecraft:honeycomb_block
setblock 8 197 361 minecraft:yellow_terracotta
fill 8 197 362 8 200 362 minecraft:honeycomb_block
setblock 9 197 325 minecraft:yellow_terracotta
setblock 9 197 360 minecraft:yellow_terracotta
fill 9 197 361 9 200 361 minecraft:honeycomb_block
setblock 10 197 324 minecraft:yellow_terracotta
fill 10 197 325 10 200 325 minecraft:honeycomb_block
fill 10 197 360 10 199 360 minecraft:honeycomb_block
setblock 11 197 323 minecraft:yellow_terracotta
fill 11 197 324 11 200 324 minecraft:honeycomb_block
setblock 11 197 363 minecraft:yellow_terracotta
fill 12 197 323 12 200 323 minecraft:honeycomb_block
setblock 12 197 362 minecraft:yellow_terracotta
fill 12 197 363 12 200 363 minecraft:honeycomb_block
setblock 13 197 361 minecraft:yellow_terracotta
fill 13 197 362 13 200 362 minecraft:honeycomb_block
setblock 14 197 360 minecraft:yellow_terracotta
fill 14 197 361 14 200 361 minecraft:honeycomb_block
setblock 15 197 324 minecraft:yellow_terracotta
setblock 16 197 323 minecraft:yellow_terracotta
setblock 16 197 324 minecraft:honeycomb_block
setblock 16 197 363 minecraft:yellow_terracotta
fill 17 197 323 17 200 323 minecraft:honeycomb_block
setblock 17 197 362 minecraft:yellow_terracotta
fill 17 197 363 17 200 363 minecraft:honeycomb_block
setblock 18 197 361 minecraft:yellow_terracotta
fill 18 197 362 18 199 362 minecraft:honeycomb_block
fill 19 197 358 20 198 358 minecraft:yellow_concrete
fill 19 197 359 22 202 360 minecraft:yellow_terracotta
setblock 20 197 323 minecraft:honeycomb_block
fill 21 197 358 22 202 358 minecraft:yellow_terracotta
setblock 21 197 363 minecraft:yellow_terracotta
setblock 22 197 362 minecraft:yellow_terracotta
fill 22 197 363 22 200 363 minecraft:honeycomb_block
fill 23 197 323 25 197 323 minecraft:honeycomb_block
fill 23 197 362 26 197 362 minecraft:honeycomb_block
setblock 26 197 323 minecraft:yellow_terracotta
fill 26 197 361 27 197 361 minecraft:honeycomb_block
setblock 26 197 363 minecraft:yellow_terracotta
fill 27 197 323 29 197 324 minecraft:honeycomb_block
setblock 27 197 362 minecraft:yellow_terracotta
fill 27 197 363 27 200 363 minecraft:honeycomb_block
setblock 28 197 361 minecraft:yellow_terracotta
fill 28 197 362 28 200 362 minecraft:honeycomb_block
fill 29 197 361 29 198 361 minecraft:honeycomb_block
setblock 30 197 323 minecraft:honeycomb_block
setblock 30 197 324 minecraft:yellow_terracotta
setblock 31 197 323 minecraft:yellow_terracotta
fill 31 197 324 31 200 324 minecraft:honeycomb_block
setblock 31 197 363 minecraft:yellow_terracotta
fill 32 197 323 32 200 323 minecraft:honeycomb_block
setblock 32 197 361 minecraft:honeycomb_block
setblock 32 197 362 minecraft:yellow_terracotta
fill 32 197 363 32 200 363 minecraft:honeycomb_block
fill 33 197 362 33 199 362 minecraft:honeycomb_block
setblock 35 197 324 minecraft:yellow_terracotta
setblock 36 197 323 minecraft:yellow_terracotta
fill 36 197 324 37 199 324 minecraft:honeycomb_block
setblock 36 197 363 minecraft:yellow_terracotta
fill 36 197 364 36 248 364 minecraft:honeycomb_block
fill 37 197 323 37 200 323 minecraft:honeycomb_block
fill 37 197 363 37 199 363 minecraft:honeycomb_block
fill 39 197 323 40 197 323 minecraft:honeycomb_block
setblock 39 197 340 minecraft:yellow_terracotta
setblock 39 197 341 minecraft:honeycomb_block
setblock 40 197 339 minecraft:yellow_terracotta
fill 40 197 340 40 199 340 minecraft:honeycomb_block
setblock 40 197 344 minecraft:yellow_terracotta
setblock 41 197 323 minecraft:yellow_terracotta
fill 41 197 324 41 200 324 minecraft:honeycomb_block
setblock 41 197 328 minecraft:yellow_terracotta
fill 41 197 329 41 198 331 minecraft:honeycomb_block
setblock 41 197 333 minecraft:yellow_terracotta
fill 41 197 334 41 199 334 minecraft:honeycomb_block
setblock 41 197 338 minecraft:yellow_terracotta
fill 41 197 339 41 200 339 minecraft:honeycomb_block
setblock 41 197 343 minecraft:yellow_terracotta
fill 41 197 344 41 200 344 minecraft:honeycomb_block
setblock 41 197 349 minecraft:honey_block
setblock 41 197 362 minecraft:honeycomb_block
fill 41 197 363 42 197 363 minecraft:yellow_terracotta
fill 1 198 323 1 200 324 minecraft:honeycomb_block
setblock 1 198 326 minecraft:honeycomb_block
setblock 1 198 327 minecraft:yellow_terracotta
fill 1 198 328 1 201 328 minecraft:honeycomb_block
setblock 1 198 337 minecraft:honey_block
setblock 1 198 338 minecraft:honeycomb_block
setblock 1 198 342 minecraft:yellow_terracotta
fill 1 198 343 1 200 343 minecraft:honeycomb_block
setblock 1 198 352 minecraft:brown_terracotta
setblock 1 198 354 minecraft:brown_terracotta
setblock 1 198 362 minecraft:yellow_terracotta
fill 1 198 363 1 201 363 minecraft:honeycomb_block
fill 2 198 324 3 198 324 minecraft:honeycomb_block
setblock 2 198 326 minecraft:yellow_terracotta
setblock 2 198 361 minecraft:yellow_terracotta
fill 2 198 362 2 201 362 minecraft:honeycomb_block
setblock 3 198 352 minecraft:brown_terracotta
setblock 3 198 354 minecraft:brown_terracotta
setblock 4 198 324 minecraft:yellow_terracotta
fill 4 198 325 4 201 325 minecraft:honeycomb_block
setblock 5 198 323 minecraft:yellow_terracotta
fill 5 198 324 5 201 324 minecraft:honeycomb_block
setblock 5 198 363 minecraft:yellow_terracotta
fill 6 198 323 6 201 323 minecraft:honeycomb_block
setblock 6 198 362 minecraft:yellow_terracotta
fill 6 198 363 6 201 363 minecraft:honeycomb_block
setblock 7 198 360 minecraft:honeycomb_block
setblock 7 198 361 minecraft:yellow_terracotta
fill 7 198 362 7 201 362 minecraft:honeycomb_block
setblock 7 198 364 minecraft:orange_terracotta
setblock 8 198 325 minecraft:yellow_terracotta
setblock 8 198 360 minecraft:yellow_terracotta
fill 8 198 361 8 201 361 minecraft:honeycomb_block
setblock 9 198 324 minecraft:yellow_terracotta
fill 9 198 325 9 201 325 minecraft:honeycomb_block
fill 9 198 360 9 199 360 minecraft:honeycomb_block
setblock 10 198 323 minecraft:yellow_terracotta
fill 10 198 324 10 201 324 minecraft:honeycomb_block
setblock 10 198 363 minecraft:yellow_terracotta
fill 11 198 323 11 201 323 minecraft:honeycomb_block
setblock 11 198 362 minecraft:yellow_terracotta
fill 11 198 363 11 201 363 minecraft:honeycomb_block
setblock 12 198 361 minecraft:yellow_terracotta
fill 12 198 362 12 201 362 minecraft:honeycomb_block
setblock 13 198 360 minecraft:yellow_terracotta
fill 13 198 361 13 200 361 minecraft:honeycomb_block
setblock 14 198 324 minecraft:yellow_terracotta
setblock 15 198 323 minecraft:yellow_terracotta
fill 15 198 324 15 199 324 minecraft:honeycomb_block
setblock 15 198 363 minecraft:yellow_terracotta
fill 16 198 323 16 201 323 minecraft:honeycomb_block
setblock 16 198 362 minecraft:yellow_terracotta
fill 16 198 363 16 201 363 minecraft:honeycomb_block
setblock 17 198 361 minecraft:yellow_terracotta
fill 17 198 362 17 200 362 minecraft:honeycomb_block
setblock 20 198 323 minecraft:yellow_terracotta
setblock 20 198 363 minecraft:yellow_terracotta
fill 21 198 323 24 198 323 minecraft:honeycomb_block
setblock 21 198 362 minecraft:yellow_terracotta
fill 21 198 363 21 201 363 minecraft:honeycomb_block
fill 22 198 362 25 198 362 minecraft:honeycomb_block
fill 22 198 364 22 245 364 minecraft:honeycomb_block
setblock 23 198 364 minecraft:orange_terracotta
setblock 25 198 323 minecraft:yellow_terracotta
setblock 25 198 363 minecraft:yellow_terracotta
fill 26 198 323 28 198 324 minecraft:honeycomb_block
setblock 26 198 362 minecraft:yellow_terracotta
fill 26 198 363 26 201 363 minecraft:honeycomb_block
setblock 27 198 361 minecraft:yellow_terracotta
fill 27 198 362 27 201 362 minecraft:honeycomb_block
setblock 28 198 361 minecraft:honeycomb_block
setblock 29 198 323 minecraft:honeycomb_block
setblock 29 198 324 minecraft:yellow_terracotta
setblock 30 198 323 minecraft:yellow_terracotta
fill 30 198 324 30 201 324 minecraft:honeycomb_block
setblock 30 198 363 minecraft:yellow_terracotta
fill 31 198 323 31 201 323 minecraft:honeycomb_block
setblock 31 198 362 minecraft:yellow_terracotta
fill 31 198 363 31 201 363 minecraft:honeycomb_block
fill 32 198 362 32 199 362 minecraft:honeycomb_block
setblock 33 198 324 minecraft:honeycomb_block
setblock 34 198 322 minecraft:yellow_concrete
setblock 34 198 324 minecraft:yellow_terracotta
setblock 35 198 323 minecraft:yellow_terracotta
fill 35 198 324 35 201 324 minecraft:honeycomb_block
setblock 35 198 363 minecraft:yellow_terracotta
fill 36 198 323 36 201 323 minecraft:honeycomb_block
fill 36 198 363 36 199 363 minecraft:honeycomb_block
setblock 38 198 324 minecraft:honeycomb_block
fill 38 198 337 38 200 337 minecraft:yellow_terracotta
setblock 39 198 323 minecraft:honeycomb_block
setblock 39 198 324 minecraft:yellow_terracotta
fill 39 198 336 39 200 336 minecraft:yellow_terracotta
fill 39 198 338 40 198 338 minecraft:yellow_terracotta
setblock 39 198 363 minecraft:honeycomb_block
setblock 40 198 323 minecraft:yellow_terracotta
fill 40 198 324 40 201 324 minecraft:honeycomb_block
fill 40 198 337 41 198 337 minecraft:yellow_terracotta
fill 40 198 339 40 199 339 minecraft:honeycomb_block
setblock 40 198 343 minecraft:yellow_terracotta
fill 40 198 344 40 199 344 minecraft:honeycomb_block
setblock 40 198 363 minecraft:yellow_terracotta
fill 41 198 323 41 201 323 minecraft:honeycomb_block
fill 41 198 325 41 198 326 minecraft:honeycomb_block
setblock 41 198 327 minecraft:yellow_terracotta
fill 41 198 328 41 201 328 minecraft:honeycomb_block
setblock 41 198 332 minecraft:yellow_terracotta
fill 41 198 333 41 199 333 minecraft:honeycomb_block
fill 41 198 338 41 200 338 minecraft:honeycomb_block
setblock 41 198 342 minecraft:yellow_terracotta
fill 41 198 343 41 201 343 minecraft:honeycomb_block
setblock 41 198 362 minecraft:yellow_terracotta
fill 41 198 363 42 200 363 minecraft:honeycomb_block
setblock 0 199 351 minecraft:yellow_concrete
setblock 1 199 325 minecraft:honeycomb_block
setblock 1 199 326 minecraft:yellow_terracotta
fill 1 199 327 2 201 327 minecraft:honeycomb_block
setblock 1 199 341 minecraft:yellow_terracotta
fill 1 199 342 1 200 342 minecraft:honeycomb_block
setblock 1 199 349 minecraft:honey_block
setblock 1 199 361 minecraft:yellow_terracotta
fill 1 199 362 1 202 362 minecraft:honeycomb_block
setblock 2 199 324 minecraft:honeycomb_block
setblock 2 199 325 minecraft:yellow_terracotta
fill 2 199 326 2 202 326 minecraft:honeycomb_block
setblock 2 199 361 minecraft:honeycomb_block
setblock 3 199 324 minecraft:yellow_terracotta
fill 3 199 325 3 202 325 minecraft:honeycomb_block
setblock 4 199 323 minecraft:yellow_terracotta
fill 4 199 324 4 202 324 minecraft:honeycomb_block
setblock 4 199 363 minecraft:yellow_terracotta
fill 5 199 323 5 202 323 minecraft:honeycomb_block
setblock 5 199 362 minecraft:yellow_terracotta
fill 5 199 363 5 202 363 minecraft:honeycomb_block
setblock 6 199 361 minecraft:yellow_terracotta
fill 6 199 362 6 202 362 minecraft:honeycomb_block
setblock 7 199 324 minecraft:honeycomb_block
setblock 7 199 325 minecraft:yellow_terracotta
fill 7 199 361 7 202 361 minecraft:honeycomb_block
fill 7 199 364 7 308 364 minecraft:honeycomb_block
setblock 8 199 324 minecraft:yellow_terracotta
fill 8 199 325 8 202 325 minecraft:honeycomb_block
setblock 8 199 360 minecraft:honeycomb_block
setblock 9 199 323 minecraft:yellow_terracotta
fill 9 199 324 9 202 324 minecraft:honeycomb_block
setblock 9 199 363 minecraft:yellow_terracotta
fill 10 199 323 10 202 323 minecraft:honeycomb_block
setblock 10 199 362 minecraft:yellow_terracotta
fill 10 199 363 10 202 363 minecraft:honeycomb_block
setblock 11 199 325 minecraft:honeycomb_block
setblock 11 199 361 minecraft:yellow_terracotta
fill 11 199 362 11 202 362 minecraft:honeycomb_block
setblock 12 199 325 minecraft:yellow_terracotta
setblock 12 199 360 minecraft:yellow_terracotta
fill 12 199 361 12 201 361 minecraft:honeycomb_block
setblock 13 199 324 minecraft:yellow_terracotta
setblock 14 199 323 minecraft:yellow_terracotta
fill 14 199 324 14 200 324 minecraft:honeycomb_block
setblock 14 199 363 minecraft:yellow_terracotta
fill 15 199 323 15 202 323 minecraft:honeycomb_block
setblock 15 199 362 minecraft:yellow_terracotta
fill 15 199 363 15 202 363 minecraft:honeycomb_block
fill 16 199 362 16 200 362 minecraft:honeycomb_block
fill 17 199 357 18 199 361 minecraft:honey_block
fill 18 199 356 23 199 356 minecraft:honey_block
setblock 19 199 323 minecraft:yellow_terracotta
fill 19 199 357 20 201 357 minecraft:honey_block
fill 19 199 358 20 202 358 minecraft:yellow_terracotta
fill 19 199 361 19 201 361 minecraft:honey_block
setblock 19 199 363 minecraft:yellow_terracotta
fill 20 199 323 23 199 323 minecraft:honeycomb_block
fill 20 199 355 21 199 355 minecraft:honey_block
setblock 20 199 362 minecraft:yellow_terracotta
fill 20 199 363 20 201 363 minecraft:honeycomb_block
fill 21 199 362 24 199 362 minecraft:honeycomb_block
fill 22 199 357 24 199 357 minecraft:honey_block
fill 23 199 358 24 199 361 minecraft:honey_block
fill 23 199 364 23 231 364 minecraft:honeycomb_block
setblock 24 199 323 minecraft:yellow_terracotta
setblock 24 199 363 minecraft:yellow_terracotta
fill 25 199 323 28 199 323 minecraft:honeycomb_block
fill 25 199 359 25 199 360 minecraft:honey_block
setblock 25 199 362 minecraft:yellow_terracotta
fill 25 199 363 25 202 363 minecraft:honeycomb_block
fill 26 199 324 27 199 324 minecraft:honeycomb_block
fill 26 199 362 26 201 362 minecraft:honeycomb_block
setblock 28 199 324 minecraft:yellow_terracotta
setblock 29 199 323 minecraft:yellow_terracotta
fill 29 199 324 29 202 324 minecraft:honeycomb_block
setblock 29 199 363 minecraft:yellow_terracotta
fill 30 199 323 30 202 323 minecraft:honeycomb_block
setblock 30 199 362 minecraft:yellow_terracotta
fill 30 199 363 30 202 363 minecraft:honeycomb_block
fill 31 199 362 31 200 362 minecraft:honeycomb_block
setblock 33 199 324 minecraft:yellow_terracotta
fill 33 199 349 33 199 352 minecraft:honey_block
fill 34 199 322 34 228 322 minecraft:honeycomb_block
setblock 34 199 323 minecraft:yellow_terracotta
fill 34 199 324 34 202 324 minecraft:honeycomb_block
fill 34 199 349 37 199 349 minecraft:honey_block
fill 34 199 352 34 199 353 minecraft:honey_block
setblock 34 199 363 minecraft:yellow_terracotta
fill 35 199 323 35 202 323 minecraft:honeycomb_block
fill 35 199 353 36 200 353 minecraft:honey_block
fill 35 199 363 35 200 363 minecraft:honeycomb_block
fill 36 199 352 37 200 352 minecraft:honey_block
fill 37 199 350 37 200 351 minecraft:honey_block
setblock 38 199 324 minecraft:yellow_terracotta
setblock 39 199 323 minecraft:yellow_terracotta
fill 39 199 324 39 202 324 minecraft:honeycomb_block
fill 39 199 338 39 200 338 minecraft:yellow_terracotta
setblock 39 199 363 minecraft:yellow_terracotta
fill 40 199 323 40 202 323 minecraft:honeycomb_block
fill 40 199 325 41 199 325 minecraft:honeycomb_block
fill 40 199 337 40 200 337 minecraft:yellow_terracotta
setblock 40 199 342 minecraft:yellow_terracotta
setblock 40 199 343 minecraft:honeycomb_block
setblock 40 199 363 minecraft:honeycomb_block
setblock 41 199 326 minecraft:yellow_terracotta
fill 41 199 327 41 202 327 minecraft:honeycomb_block
fill 41 199 329 41 199 330 minecraft:honeycomb_block
setblock 41 199 331 minecraft:yellow_terracotta
setblock 41 199 332 minecraft:honeycomb_block
setblock 41 199 336 minecraft:yellow_terracotta
fill 41 199 337 41 200 337 minecraft:honeycomb_block
setblock 41 199 341 minecraft:yellow_terracotta
fill 41 199 342 41 202 342 minecraft:honeycomb_block
setblock 41 199 345 minecraft:honeycomb_block
setblock 41 199 346 minecraft:yellow_terracotta
fill 41 199 347 41 200 347 minecraft:honeycomb_block
setblock 41 199 362 minecraft:honey_block
fill 0 200 351 0 299 351 minecraft:honeycomb_block
setblock 1 200 325 minecraft:yellow_terracotta
fill 1 200 326 1 202 326 minecraft:honeycomb_block
setblock 1 200 330 minecraft:honey_block
setblock 1 200 355 minecraft:honey_block
setblock 1 200 360 minecraft:yellow_terracotta
fill 1 200 361 1 202 361 minecraft:honeycomb_block
setblock 2 200 324 minecraft:yellow_terracotta
fill 2 200 325 2 202 325 minecraft:honeycomb_block
setblock 3 200 323 minecraft:yellow_terracotta
fill 3 200 324 3 202 324 minecraft:honeycomb_block
setblock 3 200 332 minecraft:light[level=12]
setblock 3 200 333 minecraft:light[level=15]
setblock 3 200 339 minecraft:light[level=12]
setblock 3 200 341 minecraft:light[level=15]
setblock 3 200 346 minecraft:light[level=12]
setblock 3 200 349 minecraft:light[level=15]
setblock 3 200 353 minecraft:light[level=12]
setblock 3 200 357 minecraft:light[level=15]
setblock 3 200 360 minecraft:light[level=12]
setblock 3 200 363 minecraft:yellow_terracotta
fill 4 200 323 4 202 323 minecraft:honeycomb_block
setblock 4 200 362 minecraft:yellow_terracotta
fill 4 200 363 4 202 363 minecraft:honeycomb_block
setblock 5 200 325 minecraft:honeycomb_block
setblock 5 200 361 minecraft:yellow_terracotta
fill 5 200 362 5 202 362 minecraft:honeycomb_block
setblock 6 200 325 minecraft:yellow_terracotta
fill 6 200 361 6 202 361 minecraft:honeycomb_block
setblock 7 200 324 minecraft:yellow_terracotta
fill 7 200 325 7 202 325 minecraft:honeycomb_block
setblock 8 200 323 minecraft:yellow_terracotta
fill 8 200 324 8 202 324 minecraft:honeycomb_block
setblock 8 200 363 minecraft:yellow_terracotta
fill 9 200 323 9 202 323 minecraft:honeycomb_block
setblock 9 200 362 minecraft:yellow_terracotta
fill 9 200 363 9 202 363 minecraft:honeycomb_block
setblock 10 200 332 minecraft:light[level=12]
setblock 10 200 339 minecraft:light[level=12]
setblock 10 200 346 minecraft:light[level=12]
setblock 10 200 353 minecraft:light[level=12]
setblock 10 200 360 minecraft:light[level=12]
setblock 10 200 361 minecraft:yellow_terracotta
fill 10 200 362 10 202 362 minecraft:honeycomb_block
setblock 11 200 325 minecraft:yellow_terracotta
setblock 11 200 333 minecraft:light[level=15]
setblock 11 200 341 minecraft:light[level=15]
setblock 11 200 349 minecraft:light[level=15]
setblock 11 200 357 minecraft:light[level=15]
fill 11 200 361 11 201 361 minecraft:honeycomb_block
setblock 12 200 324 minecraft:yellow_terracotta
setblock 13 200 323 minecraft:yellow_terracotta
fill 13 200 324 13 201 324 minecraft:honeycomb_block
setblock 13 200 363 minecraft:yellow_terracotta
fill 14 200 323 14 202 323 minecraft:honeycomb_block
setblock 14 200 362 minecraft:yellow_terracotta
fill 14 200 363 14 202 363 minecraft:honeycomb_block
fill 15 200 362 15 201 362 minecraft:honeycomb_block
setblock 17 200 325 minecraft:light[level=12]
setblock 17 200 332 minecraft:light[level=12]
setblock 17 200 339 minecraft:light[level=12]
setblock 17 200 346 minecraft:light[level=12]
setblock 17 200 353 minecraft:light[level=12]
fill 17 200 359 18 200 359 minecraft:honey_block
setblock 17 200 360 minecraft:light[level=12]
setblock 18 200 323 minecraft:yellow_terracotta
fill 18 200 357 18 200 358 minecraft:honey_block
fill 18 200 360 18 200 361 minecraft:honey_block
setblock 18 200 363 minecraft:yellow_terracotta
setblock 19 200 325 minecraft:light[level=15]
setblock 19 200 333 minecraft:light[level=15]
setblock 19 200 341 minecraft:light[level=15]
setblock 19 200 349 minecraft:light[level=15]
fill 19 200 356 22 200 356 minecraft:honey_block
fill 19 200 362 23 200 362 minecraft:honey_block
fill 19 200 363 19 201 363 minecraft:honeycomb_block
fill 21 200 323 22 200 323 minecraft:honeycomb_block
fill 22 200 357 23 200 357 minecraft:honey_block
setblock 23 200 323 minecraft:yellow_terracotta
fill 23 200 358 23 201 361 minecraft:honey_block
setblock 23 200 363 minecraft:yellow_terracotta
fill 24 200 323 27 200 323 minecraft:honeycomb_block
setblock 24 200 325 minecraft:light[level=12]
setblock 24 200 332 minecraft:light[level=12]
setblock 24 200 339 minecraft:light[level=12]
setblock 24 200 346 minecraft:light[level=12]
setblock 24 200 353 minecraft:light[level=12]
fill 24 200 358 24 200 360 minecraft:honey_block
setblock 24 200 362 minecraft:yellow_terracotta
fill 24 200 363 24 202 363 minecraft:honeycomb_block
setblock 24 200 364 minecraft:yellow_terracotta
fill 25 200 324 26 200 324 minecraft:honeycomb_block
setblock 25 200 362 minecraft:honeycomb_block
setblock 27 200 324 minecraft:yellow_terracotta
setblock 27 200 325 minecraft:light[level=15]
setblock 27 200 333 minecraft:light[level=15]
setblock 27 200 341 minecraft:light[level=15]
setblock 27 200 349 minecraft:light[level=15]
setblock 27 200 357 minecraft:light[level=15]
setblock 28 200 323 minecraft:yellow_terracotta
fill 28 200 324 28 202 324 minecraft:honeycomb_block
setblock 28 200 363 minecraft:yellow_terracotta
fill 29 200 323 29 202 323 minecraft:honeycomb_block
setblock 29 200 362 minecraft:yellow_terracotta
fill 29 200 363 29 202 363 minecraft:honeycomb_block
setblock 30 200 362 minecraft:honeycomb_block
setblock 31 200 325 minecraft:light[level=12]
setblock 31 200 332 minecraft:light[level=12]
setblock 31 200 339 minecraft:light[level=12]
setblock 31 200 346 minecraft:light[level=12]
setblock 31 200 353 minecraft:light[level=12]
setblock 31 200 360 minecraft:light[level=12]
setblock 32 200 324 minecraft:yellow_terracotta
setblock 33 200 323 minecraft:yellow_terracotta
fill 33 200 324 33 202 324 minecraft:honeycomb_block
fill 33 200 350 33 200 352 minecraft:honey_block
setblock 33 200 363 minecraft:yellow_terracotta
fill 34 200 323 34 202 323 minecraft:honeycomb_block
fill 34 200 349 36 200 349 minecraft:honey_block
fill 34 200 352 34 201 352 minecraft:honey_block
setblock 34 200 363 minecraft:honeycomb_block
setblock 35 200 325 minecraft:light[level=15]
setblock 35 200 333 minecraft:light[level=15]
setblock 35 200 341 minecraft:light[level=15]
setblock 35 200 357 minecraft:light[level=15]
setblock 36 200 324 minecraft:honeycomb_block
setblock 37 200 324 minecraft:yellow_terracotta
setblock 37 200 363 minecraft:honey_block
setblock 38 200 323 minecraft:yellow_terracotta
setblock 38 200 324 minecraft:honeycomb_block
setblock 38 200 325 minecraft:light[level=12]
setblock 38 200 332 minecraft:light[level=12]
setblock 38 200 339 minecraft:light[level=12]
setblock 38 200 346 minecraft:light[level=12]
setblock 38 200 353 minecraft:light[level=12]
setblock 38 200 360 minecraft:light[level=12]
fill 39 200 323 39 202 323 minecraft:honeycomb_block
setblock 40 200 325 minecraft:honeycomb_block
setblock 40 200 326 minecraft:yellow_terracotta
setblock 41 200 325 minecraft:yellow_terracotta
fill 41 200 326 41 202 326 minecraft:honeycomb_block
setblock 41 200 329 minecraft:honeycomb_block
setblock 41 200 330 minecraft:yellow_terracotta
fill 41 200 331 41 202 331 minecraft:honeycomb_block
setblock 41 200 336 minecraft:honeycomb_block
setblock 41 200 340 minecraft:yellow_terracotta
fill 41 200 341 41 202 341 minecraft:honeycomb_block
setblock 41 200 345 minecraft:yellow_terracotta
fill 41 200 346 41 202 346 minecraft:honeycomb_block
setblock 41 200 356 minecraft:honey_block
setblock 42 200 360 minecraft:yellow_concrete
setblock 1 201 323 minecraft:honeycomb_block
setblock 1 201 324 minecraft:yellow_terracotta
fill 1 201 325 1 202 325 minecraft:honeycomb_block
setblock 1 201 329 minecraft:yellow_terracotta
setblock 1 201 336 minecraft:honey_block
setblock 2 201 323 minecraft:yellow_terracotta
fill 2 201 324 2 202 324 minecraft:honeycomb_block
setblock 2 201 363 minecraft:yellow_terracotta
fill 3 201 323 3 202 323 minecraft:honeycomb_block
setblock 3 201 326 minecraft:honeycomb_block
setblock 3 201 362 minecraft:yellow_terracotta
fill 3 201 363 3 202 363 minecraft:honeycomb_block
fill 4 201 362 4 202 362 minecraft:honeycomb_block
setblock 5 201 325 minecraft:yellow_terracotta
setblock 5 201 361 minecraft:honeycomb_block
setblock 6 201 324 minecraft:yellow_terracotta
fill 6 201 325 6 202 325 minecraft:honeycomb_block
setblock 7 201 323 minecraft:yellow_terracotta
fill 7 201 324 7 202 324 minecraft:honeycomb_block
setblock 7 201 363 minecraft:yellow_terracotta
fill 8 201 323 8 202 323 minecraft:honeycomb_block
setblock 8 201 362 minecraft:yellow_terracotta
fill 8 201 363 8 202 363 minecraft:honeycomb_block
setblock 9 201 361 minecraft:yellow_terracotta
fill 9 201 362 9 202 362 minecraft:honeycomb_block
setblock 10 201 325 minecraft:yellow_terracotta
fill 10 201 361 10 202 361 minecraft:honeycomb_block
setblock 11 201 324 minecraft:yellow_terracotta
setblock 11 201 325 minecraft:honeycomb_block
setblock 12 201 323 minecraft:yellow_terracotta
fill 12 201 324 12 202 324 minecraft:honeycomb_block
setblock 12 201 363 minecraft:yellow_terracotta
fill 13 201 323 13 202 323 minecraft:honeycomb_block
setblock 13 201 362 minecraft:yellow_terracotta
fill 13 201 363 13 202 363 minecraft:honeycomb_block
setblock 14 201 362 minecraft:honeycomb_block
setblock 17 201 363 minecraft:yellow_terracotta
fill 18 201 358 18 201 360 minecraft:honey_block
setblock 18 201 363 minecraft:honeycomb_block
fill 20 201 362 21 201 362 minecraft:honey_block
setblock 22 201 323 minecraft:yellow_terracotta
setblock 22 201 357 minecraft:honey_block
setblock 22 201 363 minecraft:yellow_terracotta
fill 23 201 323 26 201 323 minecraft:honeycomb_block
fill 23 201 363 23 202 363 minecraft:honeycomb_block
fill 24 201 364 24 224 364 minecraft:honeycomb_block
setblock 25 201 324 minecraft:honeycomb_block
setblock 26 201 324 minecraft:yellow_terracotta
setblock 27 201 323 minecraft:yellow_terracotta
fill 27 201 324 27 202 324 minecraft:honeycomb_block
setblock 27 201 363 minecraft:yellow_terracotta
fill 28 201 323 28 202 323 minecraft:honeycomb_block
setblock 28 201 362 minecraft:yellow_terracotta
fill 28 201 363 28 202 363 minecraft:honeycomb_block
setblock 29 201 362 minecraft:honeycomb_block
setblock 31 201 324 minecraft:yellow_terracotta
setblock 31 201 364 minecraft:orange_terracotta
setblock 32 201 323 minecraft:yellow_terracotta
fill 32 201 324 32 202 324 minecraft:honeycomb_block
setblock 32 201 363 minecraft:yellow_terracotta
fill 33 201 323 33 202 323 minecraft:honeycomb_block
setblock 33 201 363 minecraft:honeycomb_block
setblock 35 201 349 minecraft:honey_block
setblock 36 201 352 minecraft:honey_block
setblock 37 201 323 minecraft:yellow_terracotta
fill 38 201 323 38 202 323 minecraft:honeycomb_block
setblock 40 201 325 minecraft:yellow_terracotta
fill 40 201 326 40 202 326 minecraft:honeycomb_block
setblock 41 201 324 minecraft:yellow_terracotta
fill 41 201 325 41 202 325 minecraft:honeycomb_block
setblock 41 201 329 minecraft:yellow_terracotta
fill 41 201 330 41 202 330 minecraft:honeycomb_block
setblock 41 201 339 minecraft:yellow_terracotta
setblock 41 201 340 minecraft:honeycomb_block
setblock 41 201 344 minecraft:yellow_terracotta
fill 41 201 345 41 202 345 minecraft:honeycomb_block
setblock 41 201 350 minecraft:honey_block
setblock 42 201 323 minecraft:orange_terracotta
fill 42 201 360 42 202 360 minecraft:honeycomb_block
fill 42 201 363 42 229 363 minecraft:honeycomb_block
setblock 1 202 323 minecraft:yellow_terracotta
setblock 1 202 324 minecraft:honeycomb_block
setblock 1 202 327 minecraft:honeycomb_block
setblock 1 202 328 minecraft:yellow_terracotta
fill 1 202 329 1 202 330 minecraft:honeycomb_block
setblock 1 202 342 minecraft:honey_block
setblock 1 202 363 minecraft:yellow_terracotta
setblock 2 202 323 minecraft:honeycomb_block
setblock 2 202 327 minecraft:yellow_terracotta
setblock 2 202 328 minecraft:honeycomb_block
setblock 2 202 362 minecraft:yellow_terracotta
setblock 2 202 363 minecraft:honeycomb_block
setblock 3 202 326 minecraft:yellow_terracotta
setblock 3 202 362 minecraft:honeycomb_block
setblock 4 202 325 minecraft:yellow_terracotta
setblock 5 202 324 minecraft:yellow_terracotta
setblock 5 202 325 minecraft:honeycomb_block
setblock 6 202 323 minecraft:yellow_terracotta
setblock 6 202 324 minecraft:honeycomb_block
setblock 6 202 363 minecraft:yellow_terracotta
setblock 7 202 323 minecraft:honeycomb_block
setblock 7 202 362 minecraft:yellow_terracotta
setblock 7 202 363 minecraft:honeycomb_block
setblock 8 202 361 minecraft:yellow_terracotta
setblock 8 202 362 minecraft:honeycomb_block
setblock 9 202 322 minecraft:yellow_terracotta
setblock 9 202 325 minecraft:yellow_terracotta
setblock 9 202 361 minecraft:honeycomb_block
setblock 10 202 324 minecraft:yellow_terracotta
setblock 10 202 325 minecraft:honeycomb_block
setblock 11 202 323 minecraft:yellow_terracotta
setblock 11 202 324 minecraft:honeycomb_block
setblock 11 202 363 minecraft:yellow_terracotta
setblock 12 202 323 minecraft:honeycomb_block
setblock 12 202 362 minecraft:yellow_terracotta
setblock 12 202 363 minecraft:honeycomb_block
setblock 13 202 362 minecraft:honeycomb_block
setblock 16 202 363 minecraft:yellow_terracotta
setblock 17 202 363 minecraft:honeycomb_block
setblock 18 202 323 minecraft:honey_block
setblock 20 202 327 minecraft:flowering_azalea_leaves[persistent=true]
setblock 21 202 363 minecraft:yellow_terracotta
fill 22 202 323 25 202 323 minecraft:honeycomb_block
setblock 22 202 363 minecraft:honeycomb_block
setblock 25 202 324 minecraft:yellow_terracotta
setblock 26 202 323 minecraft:yellow_terracotta
setblock 26 202 324 minecraft:honeycomb_block
setblock 26 202 363 minecraft:yellow_terracotta
setblock 27 202 323 minecraft:honeycomb_block
setblock 27 202 363 minecraft:honeycomb_block
setblock 30 202 324 minecraft:yellow_terracotta
setblock 31 202 323 minecraft:yellow_terracotta
setblock 31 202 324 minecraft:honeycomb_block
setblock 31 202 363 minecraft:yellow_terracotta
fill 31 202 364 31 308 364 minecraft:honeycomb_block
setblock 32 202 323 minecraft:honeycomb_block
setblock 36 202 323 minecraft:yellow_terracotta
setblock 37 202 323 minecraft:honeycomb_block
setblock 37 202 328 minecraft:flowering_azalea_leaves[persistent=true]
setblock 40 202 324 minecraft:yellow_terracotta
setblock 40 202 325 minecraft:honeycomb_block
setblock 40 202 327 minecraft:honeycomb_block
setblock 41 202 323 minecraft:yellow_terracotta
setblock 41 202 324 minecraft:honeycomb_block
setblock 41 202 328 minecraft:yellow_terracotta
setblock 41 202 329 minecraft:honeycomb_block
setblock 41 202 343 minecraft:yellow_terracotta
setblock 41 202 344 minecraft:honeycomb_block
fill 42 202 323 42 308 323 minecraft:honeycomb_block
setblock 0 203 359 minecraft:yellow_terracotta
fill 9 203 322 9 308 322 minecraft:honeycomb_block
setblock 20 203 322 minecraft:yellow_terracotta
setblock 42 203 360 minecraft:orange_terracotta
setblock 0 204 330 minecraft:yellow_concrete
fill 0 204 359 0 216 359 minecraft:honeycomb_block
setblock 13 204 322 minecraft:yellow_concrete
setblock 20 204 322 minecraft:honeycomb_block
setblock 29 204 364 minecraft:yellow_terracotta
setblock 41 204 364 minecraft:yellow_terracotta
fill 42 204 360 42 219 360 minecraft:honeycomb_block
fill 0 205 330 0 308 330 minecraft:honeycomb_block
fill 0 205 335 0 220 335 minecraft:honeycomb_block
setblock 0 205 336 minecraft:orange_terracotta
setblock 1 205 322 minecraft:yellow_concrete
fill 13 205 322 13 308 322 minecraft:honeycomb_block
setblock 15 205 364 minecraft:yellow_concrete
setblock 20 205 322 minecraft:yellow_terracotta
fill 29 205 364 29 308 364 minecraft:honeycomb_block
setblock 40 205 322 minecraft:yellow_concrete
fill 41 205 364 41 308 364 minecraft:honeycomb_block
setblock 0 206 324 minecraft:orange_terracotta
fill 0 206 336 0 209 336 minecraft:honeycomb_block
setblock 0 206 358 minecraft:yellow_terracotta
fill 1 206 322 1 277 322 minecraft:honeycomb_block
setblock 2 206 322 minecraft:orange_terracotta
setblock 3 206 325 minecraft:light[level=12]
setblock 3 206 332 minecraft:light[level=12]
setblock 3 206 339 minecraft:light[level=12]
setblock 3 206 346 minecraft:light[level=12]
setblock 3 206 353 minecraft:light[level=12]
setblock 3 206 360 minecraft:light[level=12]
setblock 10 206 325 minecraft:light[level=12]
setblock 10 206 332 minecraft:light[level=12]
setblock 10 206 339 minecraft:light[level=12]
setblock 10 206 346 minecraft:light[level=12]
setblock 10 206 353 minecraft:light[level=12]
setblock 10 206 360 minecraft:light[level=12]
fill 15 206 364 15 210 364 minecraft:honeycomb_block
setblock 17 206 325 minecraft:light[level=12]
setblock 17 206 332 minecraft:light[level=12]
setblock 17 206 339 minecraft:light[level=12]
setblock 17 206 346 minecraft:light[level=12]
setblock 17 206 353 minecraft:light[level=12]
setblock 17 206 360 minecraft:light[level=12]
setblock 19 206 322 minecraft:orange_terracotta
fill 20 206 322 20 222 322 minecraft:honeycomb_block
setblock 24 206 325 minecraft:light[level=12]
setblock 24 206 332 minecraft:light[level=12]
setblock 24 206 339 minecraft:light[level=12]
setblock 24 206 346 minecraft:light[level=12]
setblock 24 206 353 minecraft:light[level=12]
setblock 24 206 360 minecraft:light[level=12]
setblock 31 206 325 minecraft:light[level=12]
setblock 31 206 332 minecraft:light[level=12]
setblock 31 206 339 minecraft:light[level=12]
setblock 31 206 346 minecraft:light[level=12]
setblock 31 206 353 minecraft:light[level=12]
setblock 31 206 360 minecraft:light[level=12]
setblock 38 206 325 minecraft:light[level=12]
setblock 38 206 332 minecraft:light[level=12]
setblock 38 206 339 minecraft:light[level=12]
setblock 38 206 346 minecraft:light[level=12]
setblock 38 206 353 minecraft:light[level=12]
setblock 38 206 360 minecraft:light[level=12]
fill 40 206 322 40 213 322 minecraft:honeycomb_block
setblock 42 206 348 minecraft:yellow_concrete
setblock 42 206 349 minecraft:orange_terracotta
fill 0 207 324 0 308 324 minecraft:honeycomb_block
fill 0 207 358 0 224 358 minecraft:honeycomb_block
fill 2 207 322 2 262 322 minecraft:honeycomb_block
fill 19 207 322 19 308 322 minecraft:honeycomb_block
fill 42 207 348 42 232 349 minecraft:honeycomb_block
setblock 42 207 362 minecraft:yellow_terracotta
setblock 3 208 325 minecraft:light[level=15]
setblock 3 208 333 minecraft:light[level=15]
setblock 3 208 341 minecraft:light[level=15]
setblock 3 208 349 minecraft:light[level=15]
setblock 3 208 357 minecraft:light[level=15]
fill 10 208 340 10 208 346 minecraft:yellow_terracotta
setblock 11 208 325 minecraft:light[level=15]
setblock 11 208 333 minecraft:light[level=15]
fill 11 208 338 11 208 342 minecraft:yellow_terracotta
setblock 11 208 343 minecraft:orange_stained_glass
fill 11 208 344 11 208 348 minecraft:yellow_terracotta
setblock 11 208 349 minecraft:light[level=15]
setblock 11 208 357 minecraft:light[level=15]
fill 12 208 337 12 208 339 minecraft:yellow_terracotta
setblock 12 208 340 minecraft:yellow_stained_glass
fill 12 208 341 12 208 342 minecraft:orange_stained_glass
setblock 12 208 343 minecraft:yellow_stained_glass
fill 12 208 344 12 208 345 minecraft:orange_stained_glass
setblock 12 208 346 minecraft:yellow_stained_glass
fill 12 208 347 12 208 349 minecraft:yellow_terracotta
fill 13 208 336 13 208 337 minecraft:yellow_terracotta
setblock 13 208 338 minecraft:orange_stained_glass
setblock 13 208 339 minecraft:yellow_stained_glass
fill 13 208 340 13 208 341 minecraft:orange_stained_glass
setblock 13 208 342 minecraft:yellow_stained_glass
fill 13 208 343 13 208 344 minecraft:orange_stained_glass
setblock 13 208 345 minecraft:yellow_stained_glass
fill 13 208 346 13 208 347 minecraft:orange_stained_glass
setblock 13 208 348 minecraft:yellow_stained_glass
fill 13 208 349 13 208 350 minecraft:yellow_terracotta
fill 14 208 335 15 208 336 minecraft:yellow_terracotta
setblock 14 208 337 minecraft:orange_stained_glass
setblock 14 208 338 minecraft:yellow_stained_glass
fill 14 208 339 14 208 340 minecraft:orange_stained_glass
setblock 14 208 341 minecraft:yellow_stained_glass
fill 14 208 342 14 208 343 minecraft:orange_stained_glass
setblock 14 208 344 minecraft:yellow_stained_glass
fill 14 208 345 14 208 346 minecraft:orange_stained_glass
setblock 14 208 347 minecraft:yellow_stained_glass
fill 14 208 348 14 208 349 minecraft:orange_stained_glass
fill 14 208 350 15 208 351 minecraft:yellow_terracotta
setblock 15 208 337 minecraft:yellow_stained_glass
fill 15 208 338 15 208 339 minecraft:orange_stained_glass
setblock 15 208 340 minecraft:yellow_stained_glass
fill 15 208 341 15 208 342 minecraft:orange_stained_glass
setblock 15 208 343 minecraft:yellow_stained_glass
fill 15 208 344 15 208 345 minecraft:orange_stained_glass
setblock 15 208 346 minecraft:yellow_stained_glass
fill 15 208 347 15 208 348 minecraft:orange_stained_glass
setblock 15 208 349 minecraft:yellow_stained_glass
fill 16 208 334 18 208 335 minecraft:yellow_terracotta
setblock 16 208 336 minecraft:yellow_stained_glass
fill 16 208 337 16 208 338 minecraft:orange_stained_glass
setblock 16 208 339 minecraft:yellow_stained_glass
fill 16 208 340 16 208 341 minecraft:orange_stained_glass
setblock 16 208 342 minecraft:yellow_stained_glass
fill 16 208 343 16 208 344 minecraft:orange_stained_glass
setblock 16 208 345 minecraft:yellow_stained_glass
fill 16 208 346 16 208 347 minecraft:orange_stained_glass
setblock 16 208 348 minecraft:yellow_stained_glass
fill 16 208 349 16 208 350 minecraft:orange_stained_glass
fill 16 208 351 18 208 352 minecraft:yellow_terracotta
fill 17 208 336 17 208 337 minecraft:orange_stained_glass
setblock 17 208 338 minecraft:yellow_stained_glass
fill 17 208 339 17 208 340 minecraft:orange_stained_glass
setblock 17 208 341 minecraft:yellow_stained_glass
fill 17 208 345 17 208 346 minecraft:orange_stained_glass
setblock 17 208 347 minecraft:yellow_stained_glass
fill 17 208 348 17 208 349 minecraft:orange_stained_glass
setblock 17 208 350 minecraft:yellow_stained_glass
setblock 18 208 336 minecraft:orange_stained_glass
setblock 18 208 337 minecraft:yellow_stained_glass
fill 18 208 338 18 208 339 minecraft:orange_stained_glass
setblock 18 208 340 minecraft:yellow_stained_glass
setblock 18 208 346 minecraft:yellow_stained_glass
fill 18 208 347 18 208 348 minecraft:orange_stained_glass
setblock 18 208 349 minecraft:yellow_stained_glass
fill 18 208 350 19 208 350 minecraft:orange_stained_glass
setblock 19 208 325 minecraft:light[level=15]
setblock 19 208 333 minecraft:light[level=15]
fill 19 208 334 22 208 334 minecraft:yellow_terracotta
setblock 19 208 335 minecraft:orange_stained_glass
setblock 19 208 336 minecraft:yellow_stained_glass
fill 19 208 337 19 208 338 minecraft:orange_stained_glass
setblock 19 208 339 minecraft:yellow_stained_glass
fill 19 208 340 20 208 340 minecraft:orange_stained_glass
fill 19 208 346 19 208 347 minecraft:orange_stained_glass
setblock 19 208 348 minecraft:yellow_stained_glass
fill 19 208 349 20 208 349 minecraft:orange_stained_glass
setblock 19 208 351 minecraft:yellow_stained_glass
fill 19 208 352 22 208 352 minecraft:yellow_terracotta
setblock 19 208 357 minecraft:light[level=15]
fill 20 208 335 24 208 335 minecraft:yellow_terracotta
fill 20 208 336 20 208 337 minecraft:orange_stained_glass
setblock 20 208 338 minecraft:yellow_stained_glass
fill 20 208 339 21 208 339 minecraft:orange_stained_glass
setblock 20 208 346 minecraft:orange_stained_glass
setblock 20 208 347 minecraft:yellow_stained_glass
fill 20 208 348 21 208 348 minecraft:orange_stained_glass
setblock 20 208 350 minecraft:yellow_stained_glass
fill 20 208 351 24 208 351 minecraft:yellow_terracotta
setblock 21 208 336 minecraft:orange_stained_glass
setblock 21 208 337 minecraft:yellow_stained_glass
fill 21 208 338 22 208 338 minecraft:orange_stained_glass
setblock 21 208 340 minecraft:yellow_stained_glass
fill 21 208 341 22 208 341 minecraft:orange_stained_glass
setblock 21 208 345 minecraft:orange_stained_glass
setblock 21 208 346 minecraft:yellow_stained_glass
fill 21 208 347 22 208 347 minecraft:orange_stained_glass
setblock 21 208 349 minecraft:yellow_stained_glass
fill 21 208 350 22 208 350 minecraft:orange_stained_glass
setblock 22 208 336 minecraft:yellow_stained_glass
fill 22 208 337 23 208 337 minecraft:orange_stained_glass
setblock 22 208 339 minecraft:yellow_stained_glass
fill 22 208 340 23 208 340 minecraft:orange_stained_glass
setblock 22 208 342 minecraft:yellow_stained_glass
fill 22 208 343 22 208 344 minecraft:orange_stained_glass
setblock 22 208 345 minecraft:yellow_stained_glass
fill 22 208 346 23 208 346 minecraft:orange_stained_glass
setblock 22 208 348 minecraft:yellow_stained_glass
fill 22 208 349 23 208 349 minecraft:orange_stained_glass
fill 23 208 336 25 208 336 minecraft:yellow_terracotta
setblock 23 208 338 minecraft:yellow_stained_glass
fill 23 208 339 24 208 339 minecraft:orange_stained_glass
setblock 23 208 341 minecraft:yellow_stained_glass
fill 23 208 342 23 208 343 minecraft:orange_stained_glass
setblock 23 208 344 minecraft:yellow_stained_glass
fill 23 208 345 24 208 345 minecraft:orange_stained_glass
setblock 23 208 347 minecraft:yellow_stained_glass
fill 23 208 348 24 208 348 minecraft:orange_stained_glass
fill 23 208 350 25 208 350 minecraft:yellow_terracotta
setblock 24 208 337 minecraft:yellow_stained_glass
fill 24 208 338 25 208 338 minecraft:orange_stained_glass
setblock 24 208 340 minecraft:yellow_stained_glass
fill 24 208 341 24 208 342 minecraft:orange_stained_glass
setblock 24 208 343 minecraft:yellow_stained_glass
fill 24 208 344 25 208 344 minecraft:orange_stained_glass
setblock 24 208 346 minecraft:yellow_stained_glass
fill 24 208 347 25 208 347 minecraft:orange_stained_glass
setblock 24 208 349 minecraft:yellow_stained_glass
fill 25 208 337 26 208 337 minecraft:yellow_terracotta
setblock 25 208 339 minecraft:yellow_stained_glass
fill 25 208 340 25 208 341 minecraft:orange_stained_glass
setblock 25 208 342 minecraft:yellow_stained_glass
fill 25 208 343 26 208 343 minecraft:orange_stained_glass
setblock 25 208 345 minecraft:yellow_stained_glass
fill 25 208 346 26 208 346 minecraft:orange_stained_glass
setblock 25 208 348 minecraft:yellow_stained_glass
fill 25 208 349 26 208 349 minecraft:yellow_terracotta
fill 26 208 338 27 208 339 minecraft:yellow_terracotta
setblock 26 208 340 minecraft:orange_stained_glass
setblock 26 208 341 minecraft:yellow_stained_glass
setblock 26 208 342 minecraft:orange_stained_glass
setblock 26 208 344 minecraft:yellow_stained_glass
setblock 26 208 345 minecraft:orange_stained_glass
fill 26 208 347 27 208 348 minecraft:yellow_terracotta
setblock 27 208 325 minecraft:light[level=15]
setblock 27 208 333 minecraft:light[level=15]
fill 27 208 340 28 208 342 minecraft:yellow_terracotta
setblock 27 208 343 minecraft:yellow_stained_glass
fill 27 208 344 28 208 346 minecraft:yellow_terracotta
setblock 27 208 349 minecraft:light[level=15]
setblock 27 208 357 minecraft:light[level=15]
setblock 28 208 343 minecraft:yellow_terracotta
setblock 35 208 325 minecraft:light[level=15]
setblock 35 208 333 minecraft:light[level=15]
setblock 35 208 341 minecraft:light[level=15]
setblock 35 208 349 minecraft:light[level=15]
setblock 35 208 357 minecraft:light[level=15]
fill 42 208 362 42 218 362 minecraft:honeycomb_block
setblock 0 209 323 minecraft:yellow_concrete
setblock 0 209 356 minecraft:yellow_concrete
fill 1 209 323 1 209 327 minecraft:orange_terracotta
setblock 1 209 328 minecraft:white_concrete
fill 1 209 329 1 209 335 minecraft:orange_terracotta
setblock 1 209 336 minecraft:white_concrete
fill 1 209 337 1 209 343 minecraft:orange_terracotta
setblock 1 209 344 minecraft:white_concrete
fill 1 209 345 1 209 351 minecraft:orange_terracotta
setblock 1 209 352 minecraft:white_concrete
fill 1 209 353 1 209 359 minecraft:orange_terracotta
setblock 1 209 360 minecraft:white_concrete
fill 1 209 361 5 209 363 minecraft:orange_terracotta
fill 2 209 323 2 209 326 minecraft:orange_terracotta
setblock 2 209 327 minecraft:white_concrete
fill 2 209 328 2 209 334 minecraft:orange_terracotta
setblock 2 209 335 minecraft:white_concrete
fill 2 209 336 2 209 342 minecraft:orange_terracotta
setblock 2 209 343 minecraft:white_concrete
fill 2 209 344 2 209 350 minecraft:orange_terracotta
setblock 2 209 351 minecraft:white_concrete
fill 2 209 352 2 209 358 minecraft:orange_terracotta
setblock 2 209 359 minecraft:white_concrete
fill 2 209 360 8 209 360 minecraft:orange_terracotta
fill 3 209 323 3 209 325 minecraft:orange_terracotta
setblock 3 209 326 minecraft:white_concrete
fill 3 209 327 3 209 333 minecraft:orange_terracotta
setblock 3 209 334 minecraft:white_concrete
fill 3 209 335 3 209 341 minecraft:orange_terracotta
setblock 3 209 342 minecraft:white_concrete
fill 3 209 343 3 209 349 minecraft:orange_terracotta
setblock 3 209 350 minecraft:white_concrete
fill 3 209 351 3 209 357 minecraft:orange_terracotta
setblock 3 209 358 minecraft:white_concrete
fill 3 209 359 9 209 359 minecraft:orange_terracotta
fill 4 209 323 4 209 324 minecraft:orange_terracotta
setblock 4 209 325 minecraft:white_concrete
fill 4 209 326 4 209 332 minecraft:orange_terracotta
setblock 4 209 333 minecraft:white_concrete
fill 4 209 334 4 209 340 minecraft:orange_terracotta
setblock 4 209 341 minecraft:white_concrete
fill 4 209 342 4 209 348 minecraft:orange_terracotta
setblock 4 209 349 minecraft:white_concrete
fill 4 209 350 4 209 356 minecraft:orange_terracotta
setblock 4 209 357 minecraft:white_concrete
fill 4 209 358 10 209 358 minecraft:orange_terracotta
setblock 5 209 323 minecraft:orange_terracotta
setblock 5 209 324 minecraft:white_concrete
fill 5 209 325 5 209 331 minecraft:orange_terracotta
setblock 5 209 332 minecraft:white_concrete
fill 5 209 333 5 209 339 minecraft:orange_terracotta
setblock 5 209 340 minecraft:white_concrete
fill 5 209 341 5 209 347 minecraft:orange_terracotta
setblock 5 209 348 minecraft:white_concrete
fill 5 209 349 5 209 355 minecraft:orange_terracotta
setblock 5 209 356 minecraft:white_concrete
fill 5 209 357 11 209 357 minecraft:orange_terracotta
setblock 6 209 322 minecraft:yellow_concrete
setblock 6 209 323 minecraft:white_concrete
fill 6 209 324 6 209 330 minecraft:orange_terracotta
setblock 6 209 331 minecraft:white_concrete
fill 6 209 332 6 209 338 minecraft:orange_terracotta
setblock 6 209 339 minecraft:white_concrete
fill 6 209 340 6 209 346 minecraft:orange_terracotta
setblock 6 209 347 minecraft:white_concrete
fill 6 209 348 6 209 354 minecraft:orange_terracotta
setblock 6 209 355 minecraft:white_concrete
fill 6 209 356 12 209 356 minecraft:orange_terracotta
fill 6 209 361 6 209 362 minecraft:orange_terracotta
setblock 6 209 363 minecraft:white_concrete
fill 7 209 323 7 209 329 minecraft:orange_terracotta
setblock 7 209 330 minecraft:white_concrete
fill 7 209 331 7 209 337 minecraft:orange_terracotta
setblock 7 209 338 minecraft:white_concrete
fill 7 209 339 7 209 345 minecraft:orange_terracotta
setblock 7 209 346 minecraft:white_concrete
fill 7 209 347 7 209 353 minecraft:orange_terracotta
setblock 7 209 354 minecraft:white_concrete
fill 7 209 355 13 209 355 minecraft:orange_terracotta
setblock 7 209 361 minecraft:orange_terracotta
setblock 7 209 362 minecraft:white_concrete
fill 7 209 363 13 209 363 minecraft:orange_terracotta
fill 8 209 323 8 209 328 minecraft:orange_terracotta
setblock 8 209 329 minecraft:white_concrete
fill 8 209 330 8 209 336 minecraft:orange_terracotta
setblock 8 209 337 minecraft:white_concrete
fill 8 209 338 8 209 344 minecraft:orange_terracotta
setblock 8 209 345 minecraft:white_concrete
fill 8 209 346 8 209 352 minecraft:orange_terracotta
setblock 8 209 353 minecraft:white_concrete
fill 8 209 354 14 209 354 minecraft:orange_terracotta
setblock 8 209 361 minecraft:white_concrete
fill 8 209 362 14 209 362 minecraft:orange_terracotta
fill 9 209 323 9 209 327 minecraft:orange_terracotta
setblock 9 209 328 minecraft:white_concrete
fill 9 209 329 9 209 335 minecraft:orange_terracotta
setblock 9 209 336 minecraft:white_concrete
fill 9 209 337 9 209 343 minecraft:orange_terracotta
setblock 9 209 344 minecraft:white_concrete
fill 9 209 345 9 209 351 minecraft:orange_terracotta
setblock 9 209 352 minecraft:white_concrete
fill 9 209 353 15 209 353 minecraft:orange_terracotta
setblock 9 209 360 minecraft:white_concrete
fill 9 209 361 15 209 361 minecraft:orange_terracotta
fill 10 209 323 10 209 326 minecraft:orange_terracotta
setblock 10 209 327 minecraft:white_concrete
fill 10 209 328 10 209 334 minecraft:orange_terracotta
setblock 10 209 335 minecraft:white_concrete
fill 10 209 336 10 209 342 minecraft:orange_terracotta
setblock 10 209 343 minecraft:white_concrete
fill 10 209 344 10 209 350 minecraft:orange_terracotta
setblock 10 209 351 minecraft:white_concrete
fill 10 209 352 16 209 352 minecraft:orange_terracotta
setblock 10 209 359 minecraft:white_concrete
fill 10 209 360 16 209 360 minecraft:orange_terracotta
fill 11 209 323 11 209 325 minecraft:orange_terracotta
setblock 11 209 326 minecraft:white_concrete
fill 11 209 327 11 209 333 minecraft:orange_terracotta
setblock 11 209 334 minecraft:white_concrete
fill 11 209 335 11 209 341 minecraft:orange_terracotta
setblock 11 209 342 minecraft:white_concrete
fill 11 209 343 11 209 349 minecraft:orange_terracotta
setblock 11 209 350 minecraft:white_concrete
fill 11 209 351 17 209 351 minecraft:orange_terracotta
setblock 11 209 358 minecraft:white_concrete
fill 11 209 359 17 209 359 minecraft:orange_terracotta
fill 12 209 323 12 209 324 minecraft:orange_terracotta
setblock 12 209 325 minecraft:white_concrete
fill 12 209 326 12 209 332 minecraft:orange_terracotta
setblock 12 209 333 minecraft:white_concrete
fill 12 209 334 12 209 340 minecraft:orange_terracotta
setblock 12 209 341 minecraft:white_concrete
fill 12 209 342 12 209 348 minecraft:orange_terracotta
setblock 12 209 349 minecraft:white_concrete
fill 12 209 350 18 209 350 minecraft:orange_terracotta
setblock 12 209 357 minecraft:white_concrete
fill 12 209 358 18 209 358 minecraft:orange_terracotta
setblock 13 209 323 minecraft:orange_terracotta
setblock 13 209 324 minecraft:white_concrete
fill 13 209 325 13 209 331 minecraft:orange_terracotta
setblock 13 209 332 minecraft:white_concrete
fill 13 209 333 13 209 339 minecraft:orange_terracotta
setblock 13 209 340 minecraft:white_concrete
fill 13 209 341 13 209 347 minecraft:orange_terracotta
setblock 13 209 348 minecraft:white_concrete
fill 13 209 349 19 209 349 minecraft:orange_terracotta
setblock 13 209 356 minecraft:white_concrete
fill 13 209 357 19 209 357 minecraft:orange_terracotta
setblock 14 209 323 minecraft:white_concrete
fill 14 209 324 14 209 330 minecraft:orange_terracotta
setblock 14 209 331 minecraft:white_concrete
fill 14 209 332 14 209 338 minecraft:orange_terracotta
setblock 14 209 339 minecraft:white_concrete
fill 14 209 340 14 209 346 minecraft:orange_terracotta
setblock 14 209 347 minecraft:white_concrete
fill 14 209 348 20 209 348 minecraft:orange_terracotta
setblock 14 209 355 minecraft:white_concrete
fill 14 209 356 20 209 356 minecraft:orange_terracotta
setblock 14 209 363 minecraft:white_concrete
fill 15 209 323 15 209 329 minecraft:orange_terracotta
setblock 15 209 330 minecraft:white_concrete
fill 15 209 331 15 209 337 minecraft:orange_terracotta
setblock 15 209 338 minecraft:white_concrete
fill 15 209 339 15 209 345 minecraft:orange_terracotta
setblock 15 209 346 minecraft:white_concrete
fill 15 209 347 21 209 347 minecraft:orange_terracotta
setblock 15 209 354 minecraft:white_concrete
fill 15 209 355 21 209 355 minecraft:orange_terracotta
setblock 15 209 362 minecraft:white_concrete
fill 15 209 363 21 209 363 minecraft:orange_terracotta
fill 16 209 323 16 209 328 minecraft:orange_terracotta
setblock 16 209 329 minecraft:white_concrete
fill 16 209 330 16 209 336 minecraft:orange_terracotta
setblock 16 209 337 minecraft:white_concrete
fill 16 209 338 16 209 341 minecraft:orange_terracotta
fill 16 209 342 16 210 344 minecraft:orange_concrete
setblock 16 209 345 minecraft:white_concrete
fill 16 209 346 17 209 346 minecraft:orange_terracotta
setblock 16 209 353 minecraft:white_concrete
fill 16 209 354 22 209 354 minecraft:orange_terracotta
setblock 16 209 361 minecraft:white_concrete
fill 16 209 362 22 209 362 minecraft:orange_terracotta
fill 17 209 323 17 209 327 minecraft:orange_terracotta
setblock 17 209 328 minecraft:white_concrete
fill 17 209 329 17 209 335 minecraft:orange_terracotta
setblock 17 209 336 minecraft:white_concrete
fill 17 209 337 17 209 340 minecraft:orange_terracotta
fill 17 209 341 17 210 341 minecraft:orange_concrete
fill 17 209 345 17 210 345 minecraft:orange_concrete
setblock 17 209 352 minecraft:white_concrete
fill 17 209 353 23 209 353 minecraft:orange_terracotta
setblock 17 209 360 minecraft:white_concrete
fill 17 209 361 23 209 361 minecraft:orange_terracotta
fill 18 209 323 18 209 326 minecraft:orange_terracotta
setblock 18 209 327 minecraft:white_concrete
fill 18 209 328 18 209 334 minecraft:orange_terracotta
setblock 18 209 335 minecraft:white_concrete
fill 18 209 336 21 209 339 minecraft:orange_terracotta
fill 18 209 340 20 210 340 minecraft:orange_concrete
fill 18 209 346 20 210 346 minecraft:orange_concrete
setblock 18 209 351 minecraft:white_concrete
fill 18 209 352 24 209 352 minecraft:orange_terracotta
setblock 18 209 359 minecraft:white_concrete
fill 18 209 360 24 209 360 minecraft:orange_terracotta
fill 19 209 323 19 209 325 minecraft:orange_terracotta
setblock 19 209 326 minecraft:white_concrete
fill 19 209 327 19 209 333 minecraft:orange_terracotta
setblock 19 209 334 minecraft:white_concrete
fill 19 209 335 25 209 335 minecraft:orange_terracotta
setblock 19 209 350 minecraft:white_concrete
fill 19 209 351 25 209 351 minecraft:orange_terracotta
setblock 19 209 358 minecraft:white_concrete
fill 19 209 359 25 209 359 minecraft:orange_terracotta
fill 20 209 323 20 209 324 minecraft:orange_terracotta
setblock 20 209 325 minecraft:white_concrete
fill 20 209 326 20 209 332 minecraft:orange_terracotta
setblock 20 209 333 minecraft:white_concrete
fill 20 209 334 26 209 334 minecraft:orange_terracotta
setblock 20 209 349 minecraft:white_concrete
fill 20 209 350 26 209 350 minecraft:orange_terracotta
setblock 20 209 357 minecraft:white_concrete
fill 20 209 358 26 209 358 minecraft:orange_terracotta
setblock 21 209 323 minecraft:orange_terracotta
setblock 21 209 324 minecraft:white_concrete
fill 21 209 325 21 209 331 minecraft:orange_terracotta
setblock 21 209 332 minecraft:white_concrete
fill 21 209 333 27 209 333 minecraft:orange_terracotta
setblock 21 209 340 minecraft:white_concrete
fill 21 209 341 21 210 341 minecraft:orange_concrete
fill 21 209 345 21 210 345 minecraft:orange_concrete
fill 21 209 346 22 209 346 minecraft:orange_terracotta
setblock 21 209 348 minecraft:white_concrete
fill 21 209 349 27 209 349 minecraft:orange_terracotta
setblock 21 209 356 minecraft:white_concrete
fill 21 209 357 27 209 357 minecraft:orange_terracotta
setblock 22 209 323 minecraft:white_concrete
fill 22 209 324 22 209 330 minecraft:orange_terracotta
setblock 22 209 331 minecraft:white_concrete
fill 22 209 332 28 209 332 minecraft:orange_terracotta
fill 22 209 336 22 209 338 minecraft:orange_terracotta
setblock 22 209 339 minecraft:white_concrete
fill 22 209 340 27 209 341 minecraft:orange_terracotta
fill 22 209 342 22 210 344 minecraft:orange_concrete
fill 22 209 345 23 209 345 minecraft:orange_terracotta
setblock 22 209 347 minecraft:white_concrete
fill 22 209 348 28 209 348 minecraft:orange_terracotta
setblock 22 209 355 minecraft:white_concrete
fill 22 209 356 28 209 356 minecraft:orange_terracotta
setblock 22 209 363 minecraft:white_concrete
fill 23 209 323 23 209 329 minecraft:orange_terracotta
setblock 23 209 330 minecraft:white_concrete
fill 23 209 331 29 209 331 minecraft:orange_terracotta
fill 23 209 336 23 209 337 minecraft:orange_terracotta
setblock 23 209 338 minecraft:white_concrete
fill 23 209 339 29 209 339 minecraft:orange_terracotta
fill 23 209 342 24 209 344 minecraft:orange_terracotta
setblock 23 209 346 minecraft:white_concrete
fill 23 209 347 29 209 347 minecraft:orange_terracotta
setblock 23 209 354 minecraft:white_concrete
fill 23 209 355 29 209 355 minecraft:orange_terracotta
setblock 23 209 362 minecraft:white_concrete
fill 23 209 363 29 209 363 minecraft:orange_terracotta
fill 24 209 323 24 209 328 minecraft:orange_terracotta
setblock 24 209 329 minecraft:white_concrete
fill 24 209 330 30 209 330 minecraft:orange_terracotta
setblock 24 209 336 minecraft:orange_terracotta
setblock 24 209 337 minecraft:white_concrete
fill 24 209 338 30 209 338 minecraft:orange_terracotta
fill 24 209 345 24 210 345 minecraft:white_concrete
fill 24 209 346 30 209 346 minecraft:orange_terracotta
setblock 24 209 353 minecraft:white_concrete
fill 24 209 354 30 209 354 minecraft:orange_terracotta
setblock 24 209 361 minecraft:white_concrete
fill 24 209 362 30 209 362 minecraft:orange_terracotta
fill 25 209 323 25 209 327 minecraft:orange_terracotta
setblock 25 209 328 minecraft:white_concrete
fill 25 209 329 31 209 329 minecraft:orange_terracotta
setblock 25 209 336 minecraft:white_concrete
fill 25 209 337 31 209 337 minecraft:orange_terracotta
fill 25 209 342 25 209 343 minecraft:orange_terracotta
setblock 25 209 344 minecraft:white_concrete
fill 25 209 345 31 209 345 minecraft:orange_terracotta
setblock 25 209 352 minecraft:white_concrete
fill 25 209 353 31 209 353 minecraft:orange_terracotta
setblock 25 209 360 minecraft:white_concrete
fill 25 209 361 31 209 361 minecraft:orange_terracotta
fill 26 209 323 26 209 326 minecraft:orange_terracotta
setblock 26 209 327 minecraft:white_concrete
fill 26 209 328 32 209 328 minecraft:orange_terracotta
setblock 26 209 335 minecraft:white_concrete
fill 26 209 336 32 209 336 minecraft:orange_terracotta
setblock 26 209 342 minecraft:orange_terracotta
setblock 26 209 343 minecraft:white_concrete
fill 26 209 344 32 209 344 minecraft:orange_terracotta
setblock 26 209 351 minecraft:white_concrete
fill 26 209 352 32 209 352 minecraft:orange_terracotta
setblock 26 209 359 minecraft:white_concrete
fill 26 209 360 32 209 360 minecraft:orange_terracotta
fill 27 209 323 27 209 325 minecraft:orange_terracotta
setblock 27 209 326 minecraft:white_concrete
fill 27 209 327 33 209 327 minecraft:orange_terracotta
setblock 27 209 334 minecraft:white_concrete
fill 27 209 335 33 209 335 minecraft:orange_terracotta
setblock 27 209 342 minecraft:white_concrete
fill 27 209 343 33 209 343 minecraft:orange_terracotta
setblock 27 209 350 minecraft:white_concrete
fill 27 209 351 33 209 351 minecraft:orange_terracotta
setblock 27 209 358 minecraft:white_concrete
fill 27 209 359 33 209 359 minecraft:orange_terracotta
fill 28 209 323 28 209 324 minecraft:orange_terracotta
setblock 28 209 325 minecraft:white_concrete
fill 28 209 326 34 209 326 minecraft:orange_terracotta
setblock 28 209 333 minecraft:white_concrete
fill 28 209 334 34 209 334 minecraft:orange_terracotta
setblock 28 209 340 minecraft:orange_terracotta
setblock 28 209 341 minecraft:white_concrete
fill 28 209 342 34 209 342 minecraft:orange_terracotta
setblock 28 209 349 minecraft:white_concrete
fill 28 209 350 34 209 350 minecraft:orange_terracotta
setblock 28 209 357 minecraft:white_concrete
fill 28 209 358 34 209 358 minecraft:orange_terracotta
setblock 28 209 364 minecraft:orange_terracotta
setblock 29 209 323 minecraft:orange_terracotta
setblock 29 209 324 minecraft:white_concrete
fill 29 209 325 35 209 325 minecraft:orange_terracotta
setblock 29 209 332 minecraft:white_concrete
fill 29 209 333 35 209 333 minecraft:orange_terracotta
setblock 29 209 340 minecraft:white_concrete
fill 29 209 341 35 209 341 minecraft:orange_terracotta
setblock 29 209 348 minecraft:white_concrete
fill 29 209 349 35 209 349 minecraft:orange_terracotta
setblock 29 209 356 minecraft:white_concrete
fill 29 209 357 35 209 357 minecraft:orange_terracotta
setblock 30 209 323 minecraft:white_concrete
fill 30 209 324 36 209 324 minecraft:orange_terracotta
setblock 30 209 331 minecraft:white_concrete
fill 30 209 332 36 209 332 minecraft:orange_terracotta
setblock 30 209 339 minecraft:white_concrete
fill 30 209 340 36 209 340 minecraft:orange_terracotta
setblock 30 209 347 minecraft:white_concrete
fill 30 209 348 36 209 348 minecraft:orange_terracotta
setblock 30 209 355 minecraft:white_concrete
fill 30 209 356 36 209 356 minecraft:orange_terracotta
setblock 30 209 363 minecraft:white_concrete
fill 31 209 323 37 209 323 minecraft:orange_terracotta
setblock 31 209 330 minecraft:white_concrete
fill 31 209 331 37 209 331 minecraft:orange_terracotta
setblock 31 209 338 minecraft:white_concrete
fill 31 209 339 37 209 339 minecraft:orange_terracotta
setblock 31 209 346 minecraft:white_concrete
fill 31 209 347 37 209 347 minecraft:orange_terracotta
setblock 31 209 354 minecraft:white_concrete
fill 31 209 355 37 209 355 minecraft:orange_terracotta
setblock 31 209 362 minecraft:white_concrete
fill 31 209 363 37 209 363 minecraft:orange_terracotta
setblock 32 209 329 minecraft:white_concrete
fill 32 209 330 38 209 330 minecraft:orange_terracotta
setblock 32 209 337 minecraft:white_concrete
fill 32 209 338 38 209 338 minecraft:orange_terracotta
setblock 32 209 345 minecraft:white_concrete
fill 32 209 346 38 209 346 minecraft:orange_terracotta
setblock 32 209 353 minecraft:white_concrete
fill 32 209 354 38 209 354 minecraft:orange_terracotta
setblock 32 209 361 minecraft:white_concrete
fill 32 209 362 38 209 362 minecraft:orange_terracotta
setblock 33 209 328 minecraft:white_concrete
fill 33 209 329 39 209 329 minecraft:orange_terracotta
setblock 33 209 336 minecraft:white_concrete
fill 33 209 337 39 209 337 minecraft:orange_terracotta
setblock 33 209 344 minecraft:white_concrete
fill 33 209 345 39 209 345 minecraft:orange_terracotta
setblock 33 209 352 minecraft:white_concrete
fill 33 209 353 39 209 353 minecraft:orange_terracotta
setblock 33 209 360 minecraft:white_concrete
fill 33 209 361 39 209 361 minecraft:orange_terracotta
setblock 34 209 327 minecraft:white_concrete
fill 34 209 328 40 209 328 minecraft:orange_terracotta
setblock 34 209 335 minecraft:white_concrete
fill 34 209 336 40 209 336 minecraft:orange_terracotta
setblock 34 209 343 minecraft:white_concrete
fill 34 209 344 40 209 344 minecraft:orange_terracotta
setblock 34 209 351 minecraft:white_concrete
fill 34 209 352 40 209 352 minecraft:orange_terracotta
setblock 34 209 359 minecraft:white_concrete
fill 34 209 360 40 209 360 minecraft:orange_terracotta
setblock 35 209 326 minecraft:white_concrete
fill 35 209 327 41 209 327 minecraft:orange_terracotta
setblock 35 209 334 minecraft:white_concrete
fill 35 209 335 41 209 335 minecraft:orange_terracotta
setblock 35 209 342 minecraft:white_concrete
fill 35 209 343 41 209 343 minecraft:orange_terracotta
setblock 35 209 350 minecraft:white_concrete
fill 35 209 351 41 209 351 minecraft:orange_terracotta
setblock 35 209 358 minecraft:white_concrete
fill 35 209 359 41 209 359 minecraft:orange_terracotta
setblock 36 209 325 minecraft:white_concrete
fill 36 209 326 41 209 326 minecraft:orange_terracotta
setblock 36 209 333 minecraft:white_concrete
fill 36 209 334 41 209 334 minecraft:orange_terracotta
setblock 36 209 341 minecraft:white_concrete
fill 36 209 342 41 209 342 minecraft:orange_terracotta
setblock 36 209 349 minecraft:white_concrete
fill 36 209 350 41 209 350 minecraft:orange_terracotta
setblock 36 209 357 minecraft:white_concrete
fill 36 209 358 41 209 358 minecraft:orange_terracotta
setblock 37 209 324 minecraft:white_concrete
fill 37 209 325 41 209 325 minecraft:orange_terracotta
setblock 37 209 332 minecraft:white_concrete
fill 37 209 333 41 209 333 minecraft:orange_terracotta
setblock 37 209 340 minecraft:white_concrete
fill 37 209 341 41 209 341 minecraft:orange_terracotta
setblock 37 209 348 minecraft:white_concrete
fill 37 209 349 41 209 349 minecraft:orange_terracotta
setblock 37 209 356 minecraft:white_concrete
fill 37 209 357 41 209 357 minecraft:orange_terracotta
setblock 38 209 323 minecraft:white_concrete
fill 38 209 324 41 209 324 minecraft:orange_terracotta
setblock 38 209 331 minecraft:white_concrete
fill 38 209 332 41 209 332 minecraft:orange_terracotta
setblock 38 209 339 minecraft:white_concrete
fill 38 209 340 41 209 340 minecraft:orange_terracotta
setblock 38 209 347 minecraft:white_concrete
fill 38 209 348 41 209 348 minecraft:orange_terracotta
setblock 38 209 355 minecraft:white_concrete
fill 38 209 356 41 209 356 minecraft:orange_terracotta
setblock 38 209 363 minecraft:white_concrete
fill 39 209 323 41 209 323 minecraft:orange_terracotta
setblock 39 209 330 minecraft:white_concrete
fill 39 209 331 41 209 331 minecraft:orange_terracotta
setblock 39 209 338 minecraft:white_concrete
fill 39 209 339 41 209 339 minecraft:orange_terracotta
setblock 39 209 346 minecraft:white_concrete
fill 39 209 347 41 209 347 minecraft:orange_terracotta
setblock 39 209 354 minecraft:white_concrete
fill 39 209 355 41 209 355 minecraft:orange_terracotta
setblock 39 209 362 minecraft:white_concrete
fill 39 209 363 41 209 363 minecraft:orange_terracotta
setblock 40 209 329 minecraft:white_concrete
fill 40 209 330 41 209 330 minecraft:orange_terracotta
setblock 40 209 337 minecraft:white_concrete
fill 40 209 338 41 209 338 minecraft:orange_terracotta
setblock 40 209 345 minecraft:white_concrete
fill 40 209 346 41 209 346 minecraft:orange_terracotta
setblock 40 209 353 minecraft:white_concrete
fill 40 209 354 41 209 354 minecraft:orange_terracotta
setblock 40 209 361 minecraft:white_concrete
fill 40 209 362 41 209 362 minecraft:orange_terracotta
setblock 41 209 328 minecraft:white_concrete
setblock 41 209 329 minecraft:orange_terracotta
setblock 41 209 336 minecraft:white_concrete
setblock 41 209 337 minecraft:orange_terracotta
setblock 41 209 344 minecraft:white_concrete
setblock 41 209 345 minecraft:orange_terracotta
setblock 41 209 352 minecraft:white_concrete
setblock 41 209 353 minecraft:orange_terracotta
setblock 41 209 360 minecraft:white_concrete
setblock 41 209 361 minecraft:orange_terracotta
setblock 42 209 352 minecraft:yellow_concrete
fill 0 210 323 0 216 323 minecraft:honeycomb_block
setblock 0 210 336 minecraft:yellow_concrete
fill 0 210 356 0 285 356 minecraft:honeycomb_block
fill 6 210 322 6 229 322 minecraft:honeycomb_block
fill 10 210 340 12 210 346 minecraft:yellow_terracotta
fill 11 210 338 13 210 339 minecraft:yellow_terracotta
fill 11 210 347 13 210 348 minecraft:yellow_terracotta
fill 12 210 337 16 210 337 minecraft:yellow_terracotta
fill 12 210 349 16 210 349 minecraft:yellow_terracotta
fill 13 210 336 25 210 336 minecraft:yellow_terracotta
setblock 13 210 340 minecraft:yellow_terracotta
setblock 13 210 346 minecraft:yellow_terracotta
fill 13 210 350 25 210 350 minecraft:yellow_terracotta
fill 14 210 335 24 210 335 minecraft:yellow_terracotta
setblock 14 210 338 minecraft:yellow_terracotta
setblock 14 210 348 minecraft:yellow_terracotta
fill 14 210 351 24 210 351 minecraft:yellow_terracotta
fill 16 210 334 22 210 334 minecraft:yellow_terracotta
fill 16 210 352 22 210 352 minecraft:yellow_terracotta
fill 22 210 337 26 210 337 minecraft:yellow_terracotta
fill 22 210 349 26 210 349 minecraft:yellow_terracotta
fill 24 210 338 24 210 344 minecraft:white_concrete
fill 24 210 346 24 216 348 minecraft:white_concrete
fill 25 210 338 27 210 340 minecraft:yellow_terracotta
fill 25 210 346 27 210 348 minecraft:yellow_terracotta
fill 26 210 341 28 210 345 minecraft:yellow_terracotta
setblock 28 210 340 minecraft:yellow_terracotta
setblock 28 210 346 minecraft:yellow_terracotta
fill 28 210 364 28 258 364 minecraft:honeycomb_block
setblock 42 210 346 minecraft:orange_terracotta
fill 42 210 352 42 214 352 minecraft:honeycomb_block
fill 0 211 336 0 212 336 minecraft:honeycomb_block
setblock 15 211 364 minecraft:yellow_terracotta
fill 24 211 338 24 216 340 minecraft:white_concrete
fill 24 211 341 24 214 345 minecraft:red_concrete
fill 42 211 346 42 229 346 minecraft:honeycomb_block
setblock 3 212 325 minecraft:light[level=12]
setblock 3 212 332 minecraft:light[level=12]
setblock 3 212 339 minecraft:light[level=12]
setblock 3 212 346 minecraft:light[level=12]
setblock 3 212 353 minecraft:light[level=12]
setblock 3 212 360 minecraft:light[level=12]
setblock 10 212 325 minecraft:light[level=12]
setblock 10 212 332 minecraft:light[level=12]
setblock 10 212 339 minecraft:light[level=12]
setblock 10 212 346 minecraft:light[level=12]
setblock 10 212 353 minecraft:light[level=12]
setblock 10 212 360 minecraft:light[level=12]
fill 15 212 364 15 308 364 minecraft:honeycomb_block
setblock 17 212 325 minecraft:light[level=12]
setblock 17 212 332 minecraft:light[level=12]
setblock 17 212 339 minecraft:light[level=12]
setblock 17 212 346 minecraft:light[level=12]
setblock 17 212 353 minecraft:light[level=12]
setblock 17 212 360 minecraft:light[level=12]
setblock 24 212 325 minecraft:light[level=12]
setblock 24 212 332 minecraft:light[level=12]
setblock 24 212 353 minecraft:light[level=12]
setblock 24 212 360 minecraft:light[level=12]
setblock 31 212 325 minecraft:light[level=12]
setblock 31 212 332 minecraft:light[level=12]
setblock 31 212 339 minecraft:light[level=12]
setblock 31 212 346 minecraft:light[level=12]
setblock 31 212 353 minecraft:light[level=12]
setblock 31 212 360 minecraft:light[level=12]
setblock 38 212 325 minecraft:light[level=12]
setblock 38 212 332 minecraft:light[level=12]
setblock 38 212 339 minecraft:light[level=12]
setblock 38 212 346 minecraft:light[level=12]
setblock 38 212 353 minecraft:light[level=12]
setblock 38 212 360 minecraft:light[level=12]
setblock 0 213 332 minecraft:orange_terracotta
setblock 0 213 336 minecraft:yellow_concrete
fill 1 213 323 1 213 326 minecraft:honeycomb_block
setblock 1 213 327 minecraft:yellow_terracotta
fill 1 213 328 1 213 331 minecraft:honeycomb_block
setblock 1 213 332 minecraft:yellow_terracotta
fill 1 213 333 1 213 336 minecraft:honeycomb_block
setblock 1 213 337 minecraft:yellow_terracotta
fill 1 213 338 1 213 341 minecraft:honeycomb_block
setblock 1 213 342 minecraft:yellow_terracotta
fill 1 213 343 1 213 346 minecraft:honeycomb_block
setblock 1 213 347 minecraft:yellow_terracotta
fill 1 213 348 1 213 351 minecraft:honeycomb_block
setblock 1 213 352 minecraft:yellow_terracotta
fill 1 213 353 1 213 356 minecraft:honeycomb_block
setblock 1 213 357 minecraft:yellow_terracotta
fill 1 213 358 1 213 361 minecraft:honeycomb_block
setblock 1 213 362 minecraft:yellow_terracotta
fill 1 213 363 4 213 363 minecraft:honeycomb_block
fill 2 213 323 2 213 325 minecraft:honeycomb_block
setblock 2 213 326 minecraft:yellow_terracotta
fill 2 213 327 2 213 330 minecraft:honeycomb_block
setblock 2 213 331 minecraft:yellow_terracotta
fill 2 213 332 2 213 335 minecraft:honeycomb_block
setblock 2 213 336 minecraft:yellow_terracotta
fill 2 213 337 2 215 337 minecraft:honeycomb_block
setblock 2 213 346 minecraft:yellow_terracotta
fill 2 213 347 2 213 350 minecraft:honeycomb_block
setblock 2 213 351 minecraft:yellow_terracotta
fill 2 213 352 2 213 355 minecraft:honeycomb_block
setblock 2 213 356 minecraft:yellow_terracotta
fill 2 213 357 2 213 360 minecraft:honeycomb_block
setblock 2 213 361 minecraft:yellow_terracotta
fill 2 213 362 5 213 362 minecraft:honeycomb_block
fill 3 213 323 3 213 324 minecraft:honeycomb_block
fill 3 213 328 3 213 329 minecraft:honeycomb_block
setblock 3 213 330 minecraft:yellow_terracotta
fill 3 213 331 3 213 333 minecraft:honeycomb_block
fill 3 213 348 3 213 349 minecraft:honeycomb_block
setblock 3 213 350 minecraft:yellow_terracotta
fill 3 213 351 3 213 354 minecraft:honeycomb_block
setblock 3 213 355 minecraft:yellow_terracotta
fill 3 213 356 3 213 359 minecraft:honeycomb_block
setblock 3 213 360 minecraft:yellow_terracotta
fill 3 213 361 4 214 361 minecraft:honeycomb_block
setblock 4 213 323 minecraft:honeycomb_block
setblock 4 213 324 minecraft:yellow_terracotta
fill 4 213 351 4 213 353 minecraft:honeycomb_block
setblock 4 213 354 minecraft:yellow_terracotta
fill 4 213 355 4 213 358 minecraft:honeycomb_block
setblock 5 213 323 minecraft:yellow_terracotta
setblock 5 213 363 minecraft:yellow_terracotta
setblock 6 213 323 minecraft:honeycomb_block
setblock 6 213 362 minecraft:yellow_terracotta
fill 6 213 363 8 213 363 minecraft:honeycomb_block
fill 9 213 323 9 214 323 minecraft:honey_block
setblock 15 213 323 minecraft:honey_block
setblock 20 213 323 minecraft:yellow_terracotta
fill 20 213 327 20 215 327 minecraft:flowering_azalea_leaves[persistent=true]
setblock 20 213 363 minecraft:yellow_terracotta
fill 21 213 323 24 213 323 minecraft:honeycomb_block
fill 21 213 363 22 213 363 minecraft:honeycomb_block
setblock 25 213 323 minecraft:yellow_terracotta
fill 25 213 343 30 213 344 minecraft:gray_concrete
fill 26 213 323 27 213 323 minecraft:honeycomb_block
setblock 27 213 363 minecraft:honey_block
setblock 28 213 322 minecraft:orange_terracotta
fill 28 213 331 34 217 333 minecraft:brown_terracotta
fill 29 213 330 33 217 330 minecraft:brown_terracotta
fill 29 213 334 33 217 335 minecraft:brown_terracotta
fill 30 213 329 32 217 329 minecraft:brown_terracotta
setblock 34 213 323 minecraft:honeycomb_block
fill 34 213 334 34 217 334 minecraft:brown_terracotta
setblock 35 213 323 minecraft:yellow_terracotta
fill 36 213 323 38 213 324 minecraft:honeycomb_block
fill 37 213 328 37 214 328 minecraft:flowering_azalea_leaves[persistent=true]
fill 37 213 345 38 221 345 minecraft:brown_terracotta
fill 37 213 363 39 213 363 minecraft:honeycomb_block
setblock 38 213 325 minecraft:yellow_terracotta
setblock 38 213 329 minecraft:honeycomb_block
setblock 38 213 330 minecraft:yellow_terracotta
fill 38 213 331 40 213 332 minecraft:honeycomb_block
setblock 39 213 323 minecraft:honeycomb_block
setblock 39 213 324 minecraft:yellow_terracotta
fill 39 213 325 39 213 328 minecraft:honeycomb_block
setblock 39 213 329 minecraft:yellow_terracotta
fill 39 213 330 41 214 330 minecraft:honeycomb_block
setblock 39 213 333 minecraft:honeycomb_block
setblock 39 213 334 minecraft:yellow_terracotta
fill 39 213 335 41 213 336 minecraft:honeycomb_block
setblock 39 213 354 minecraft:yellow_terracotta
fill 39 213 355 41 214 355 minecraft:honeycomb_block
fill 39 213 362 40 213 362 minecraft:honeycomb_block
setblock 40 213 323 minecraft:yellow_terracotta
fill 40 213 324 40 213 327 minecraft:honeycomb_block
setblock 40 213 328 minecraft:yellow_terracotta
fill 40 213 329 41 215 329 minecraft:honeycomb_block
setblock 40 213 333 minecraft:yellow_terracotta
fill 40 213 334 41 215 334 minecraft:honeycomb_block
setblock 40 213 337 minecraft:honeycomb_block
setblock 40 213 338 minecraft:yellow_terracotta
fill 40 213 349 40 213 352 minecraft:honeycomb_block
setblock 40 213 353 minecraft:yellow_terracotta
fill 40 213 354 41 215 354 minecraft:honeycomb_block
fill 40 213 356 40 213 357 minecraft:honeycomb_block
setblock 40 213 358 minecraft:yellow_terracotta
fill 40 213 359 41 213 361 minecraft:honeycomb_block
setblock 40 213 363 minecraft:yellow_terracotta
schedule function dropper:buildpart/72_8 1t
