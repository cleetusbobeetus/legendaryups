setblock 363 137 502 minecraft:pink_terracotta
setblock 364 137 465 minecraft:red_nether_bricks
setblock 365 137 464 minecraft:red_nether_bricks
fill 365 137 465 365 140 465 minecraft:pink_terracotta
setblock 365 137 504 minecraft:red_nether_bricks
fill 366 137 464 366 140 464 minecraft:pink_terracotta
fill 366 137 481 366 137 482 minecraft:pink_terracotta
setblock 366 137 483 minecraft:red_nether_bricks
fill 366 137 484 366 138 485 minecraft:pink_terracotta
setblock 366 137 503 minecraft:red_nether_bricks
fill 366 137 504 366 140 504 minecraft:pink_terracotta
setblock 367 137 478 minecraft:pink_terracotta
setblock 367 137 482 minecraft:red_nether_bricks
fill 367 137 483 367 140 483 minecraft:pink_terracotta
setblock 367 137 487 minecraft:red_nether_bricks
setblock 367 137 502 minecraft:red_nether_bricks
fill 367 137 503 367 139 503 minecraft:pink_terracotta
setblock 368 137 476 minecraft:red_nether_bricks
fill 368 137 477 368 138 477 minecraft:pink_terracotta
setblock 368 137 481 minecraft:red_nether_bricks
fill 368 137 482 368 140 482 minecraft:pink_terracotta
setblock 368 137 486 minecraft:red_nether_bricks
fill 368 137 487 368 140 487 minecraft:pink_terracotta
setblock 369 137 464 minecraft:pink_terracotta
setblock 369 137 465 minecraft:red_nether_bricks
fill 369 137 466 369 137 469 minecraft:pink_terracotta
setblock 369 137 470 minecraft:red_nether_bricks
setblock 369 137 471 minecraft:pink_terracotta
setblock 369 137 475 minecraft:red_nether_bricks
fill 369 137 476 369 139 476 minecraft:pink_terracotta
setblock 369 137 480 minecraft:red_nether_bricks
fill 369 137 481 369 140 481 minecraft:pink_terracotta
setblock 369 137 485 minecraft:red_nether_bricks
fill 369 137 486 369 140 486 minecraft:pink_terracotta
setblock 369 137 490 minecraft:red_nether_bricks
setblock 369 137 491 minecraft:pink_terracotta
setblock 369 137 500 minecraft:red_nether_bricks
setblock 369 137 501 minecraft:pink_terracotta
setblock 370 137 464 minecraft:red_nether_bricks
fill 370 137 465 370 140 465 minecraft:pink_terracotta
setblock 370 137 469 minecraft:red_nether_bricks
fill 370 137 470 370 140 470 minecraft:pink_terracotta
setblock 370 137 474 minecraft:red_nether_bricks
fill 370 137 475 370 140 475 minecraft:pink_terracotta
setblock 370 137 479 minecraft:red_nether_bricks
fill 370 137 480 370 140 480 minecraft:pink_terracotta
setblock 370 137 484 minecraft:red_nether_bricks
fill 370 137 485 370 140 485 minecraft:pink_terracotta
setblock 370 137 489 minecraft:red_nether_bricks
fill 370 137 490 370 140 490 minecraft:pink_terracotta
setblock 370 137 494 minecraft:red_nether_bricks
setblock 370 137 495 minecraft:pink_terracotta
setblock 370 137 499 minecraft:red_nether_bricks
fill 370 137 500 370 138 500 minecraft:pink_terracotta
setblock 370 137 504 minecraft:red_nether_bricks
fill 330 138 464 333 138 464 minecraft:pink_terracotta
setblock 330 138 468 minecraft:red_nether_bricks
fill 330 138 469 330 141 469 minecraft:pink_terracotta
setblock 330 138 473 minecraft:red_nether_bricks
fill 330 138 474 330 139 474 minecraft:pink_terracotta
setblock 330 138 478 minecraft:red_nether_bricks
fill 330 138 479 330 140 479 minecraft:pink_terracotta
setblock 330 138 483 minecraft:red_nether_bricks
fill 330 138 484 330 141 484 minecraft:pink_terracotta
setblock 330 138 488 minecraft:red_nether_bricks
setblock 330 138 489 minecraft:pink_terracotta
setblock 330 138 503 minecraft:red_nether_bricks
fill 330 138 504 333 138 504 minecraft:pink_terracotta
setblock 331 138 467 minecraft:red_nether_bricks
fill 331 138 468 331 140 468 minecraft:pink_terracotta
setblock 331 138 478 minecraft:pink_terracotta
setblock 331 138 482 minecraft:red_nether_bricks
fill 331 138 483 331 139 483 minecraft:pink_terracotta
setblock 331 138 503 minecraft:pink_terracotta
setblock 333 138 465 minecraft:red_nether_bricks
setblock 334 138 464 minecraft:red_nether_bricks
fill 334 138 465 337 138 465 minecraft:pink_terracotta
setblock 334 138 504 minecraft:red_nether_bricks
fill 335 138 464 335 141 464 minecraft:pink_terracotta
fill 335 138 504 335 141 504 minecraft:pink_terracotta
setblock 336 138 503 minecraft:pink_terracotta
setblock 338 138 465 minecraft:red_nether_bricks
setblock 339 138 464 minecraft:red_nether_bricks
fill 339 138 465 339 141 465 minecraft:pink_terracotta
setblock 339 138 504 minecraft:red_nether_bricks
fill 340 138 464 340 141 464 minecraft:pink_terracotta
setblock 340 138 503 minecraft:red_nether_bricks
fill 340 138 504 340 141 504 minecraft:pink_terracotta
setblock 341 138 466 minecraft:pink_terracotta
setblock 341 138 502 minecraft:red_nether_bricks
fill 341 138 503 341 141 503 minecraft:pink_terracotta
setblock 342 138 466 minecraft:red_nether_bricks
fill 342 138 502 342 141 502 minecraft:pink_terracotta
setblock 343 138 465 minecraft:red_nether_bricks
fill 343 138 466 343 141 466 minecraft:pink_terracotta
setblock 343 138 501 minecraft:pink_terracotta
setblock 344 138 464 minecraft:red_nether_bricks
fill 344 138 465 344 141 465 minecraft:pink_terracotta
setblock 344 138 504 minecraft:red_nether_bricks
fill 345 138 464 345 141 464 minecraft:pink_terracotta
setblock 345 138 503 minecraft:red_nether_bricks
fill 345 138 504 345 141 504 minecraft:pink_terracotta
setblock 346 138 466 minecraft:pink_terracotta
setblock 346 138 502 minecraft:red_nether_bricks
fill 346 138 503 346 141 503 minecraft:pink_terracotta
setblock 347 138 466 minecraft:red_nether_bricks
setblock 347 138 501 minecraft:red_nether_bricks
fill 347 138 502 347 140 502 minecraft:pink_terracotta
setblock 348 138 465 minecraft:red_nether_bricks
setblock 348 138 501 minecraft:pink_terracotta
setblock 349 138 464 minecraft:red_nether_bricks
fill 349 138 465 349 140 465 minecraft:pink_terracotta
setblock 349 138 504 minecraft:red_nether_bricks
fill 350 138 464 350 141 464 minecraft:pink_terracotta
setblock 350 138 503 minecraft:red_nether_bricks
fill 350 138 504 350 141 504 minecraft:pink_terracotta
setblock 351 138 502 minecraft:red_nether_bricks
fill 351 138 503 351 140 503 minecraft:pink_terracotta
setblock 352 138 502 minecraft:pink_terracotta
setblock 354 138 464 minecraft:red_nether_bricks
setblock 354 138 504 minecraft:red_nether_bricks
setblock 355 138 503 minecraft:red_nether_bricks
fill 355 138 504 358 138 504 minecraft:pink_terracotta
fill 356 138 503 359 138 503 minecraft:pink_terracotta
setblock 359 138 464 minecraft:red_nether_bricks
setblock 359 138 504 minecraft:red_nether_bricks
fill 360 138 464 363 138 464 minecraft:pink_terracotta
setblock 360 138 503 minecraft:red_nether_bricks
fill 360 138 504 360 141 504 minecraft:pink_terracotta
fill 361 138 503 361 139 503 minecraft:pink_terracotta
setblock 363 138 465 minecraft:red_nether_bricks
setblock 364 138 464 minecraft:red_nether_bricks
fill 364 138 465 364 141 465 minecraft:pink_terracotta
setblock 364 138 504 minecraft:red_nether_bricks
fill 365 138 464 365 141 464 minecraft:pink_terracotta
setblock 365 138 503 minecraft:red_nether_bricks
fill 365 138 504 365 141 504 minecraft:pink_terracotta
setblock 366 138 482 minecraft:red_nether_bricks
setblock 366 138 483 minecraft:pink_terracotta
fill 366 138 503 366 140 503 minecraft:pink_terracotta
setblock 367 138 465 minecraft:pink_terracotta
setblock 367 138 481 minecraft:red_nether_bricks
fill 367 138 482 367 140 482 minecraft:pink_terracotta
setblock 367 138 486 minecraft:red_nether_bricks
fill 367 138 487 367 139 487 minecraft:pink_terracotta
setblock 368 138 465 minecraft:red_nether_bricks
setblock 368 138 476 minecraft:pink_terracotta
setblock 368 138 480 minecraft:red_nether_bricks
fill 368 138 481 368 140 481 minecraft:pink_terracotta
setblock 368 138 485 minecraft:red_nether_bricks
fill 368 138 486 368 141 486 minecraft:pink_terracotta
setblock 369 138 464 minecraft:red_nether_bricks
fill 369 138 465 369 138 468 minecraft:pink_terracotta
setblock 369 138 469 minecraft:red_nether_bricks
setblock 369 138 474 minecraft:red_nether_bricks
fill 369 138 475 369 139 475 minecraft:pink_terracotta
setblock 369 138 479 minecraft:red_nether_bricks
fill 369 138 480 369 141 480 minecraft:pink_terracotta
setblock 369 138 484 minecraft:red_nether_bricks
fill 369 138 485 369 141 485 minecraft:pink_terracotta
setblock 369 138 489 minecraft:red_nether_bricks
fill 369 138 490 369 139 490 minecraft:pink_terracotta
setblock 369 138 504 minecraft:red_nether_bricks
fill 370 138 464 370 141 464 minecraft:pink_terracotta
setblock 370 138 468 minecraft:red_nether_bricks
fill 370 138 469 370 141 469 minecraft:pink_terracotta
setblock 370 138 473 minecraft:red_nether_bricks
fill 370 138 474 370 140 474 minecraft:pink_terracotta
setblock 370 138 478 minecraft:red_nether_bricks
fill 370 138 479 370 141 479 minecraft:pink_terracotta
setblock 370 138 483 minecraft:red_nether_bricks
fill 370 138 484 370 141 484 minecraft:pink_terracotta
setblock 370 138 488 minecraft:red_nether_bricks
fill 370 138 489 370 141 489 minecraft:pink_terracotta
setblock 370 138 499 minecraft:pink_terracotta
setblock 370 138 503 minecraft:red_nether_bricks
fill 370 138 504 370 140 504 minecraft:pink_terracotta
fill 330 139 464 332 139 464 minecraft:pink_terracotta
setblock 330 139 467 minecraft:red_nether_bricks
fill 330 139 468 330 142 468 minecraft:pink_terracotta
setblock 330 139 472 minecraft:red_nether_bricks
fill 330 139 473 330 140 473 minecraft:pink_terracotta
setblock 330 139 477 minecraft:red_nether_bricks
fill 330 139 478 330 140 478 minecraft:pink_terracotta
setblock 330 139 482 minecraft:red_nether_bricks
fill 330 139 483 330 141 483 minecraft:pink_terracotta
setblock 330 139 487 minecraft:red_nether_bricks
setblock 330 139 488 minecraft:pink_terracotta
setblock 330 139 502 minecraft:red_nether_bricks
fill 330 139 503 330 140 504 minecraft:pink_terracotta
setblock 331 139 466 minecraft:red_nether_bricks
fill 331 139 467 331 142 467 minecraft:pink_terracotta
setblock 331 139 482 minecraft:pink_terracotta
fill 331 139 504 332 139 504 minecraft:pink_terracotta
setblock 332 139 465 minecraft:red_nether_bricks
setblock 333 139 464 minecraft:red_nether_bricks
fill 333 139 465 336 139 465 minecraft:pink_terracotta
setblock 333 139 504 minecraft:red_nether_bricks
fill 334 139 464 334 142 464 minecraft:pink_terracotta
fill 334 139 504 334 142 504 minecraft:pink_terracotta
setblock 337 139 465 minecraft:red_nether_bricks
setblock 338 139 464 minecraft:red_nether_bricks
fill 338 139 465 338 142 465 minecraft:pink_terracotta
setblock 338 139 504 minecraft:red_nether_bricks
fill 339 139 464 339 142 464 minecraft:pink_terracotta
setblock 339 139 503 minecraft:red_nether_bricks
fill 339 139 504 339 142 504 minecraft:pink_terracotta
setblock 340 139 466 minecraft:pink_terracotta
setblock 340 139 502 minecraft:red_nether_bricks
fill 340 139 503 340 142 503 minecraft:pink_terracotta
setblock 341 139 466 minecraft:red_nether_bricks
fill 341 139 502 341 141 502 minecraft:pink_terracotta
setblock 342 139 465 minecraft:red_nether_bricks
fill 342 139 466 342 142 466 minecraft:pink_terracotta
setblock 343 139 464 minecraft:red_nether_bricks
fill 343 139 465 343 142 465 minecraft:pink_terracotta
setblock 343 139 504 minecraft:red_nether_bricks
fill 344 139 464 344 142 464 minecraft:pink_terracotta
setblock 344 139 503 minecraft:red_nether_bricks
fill 344 139 504 344 142 504 minecraft:pink_terracotta
setblock 345 139 502 minecraft:red_nether_bricks
fill 345 139 503 345 142 503 minecraft:pink_terracotta
setblock 346 139 466 minecraft:red_nether_bricks
setblock 346 139 501 minecraft:red_nether_bricks
fill 346 139 502 346 141 502 minecraft:pink_terracotta
setblock 347 139 465 minecraft:red_nether_bricks
setblock 348 139 464 minecraft:red_nether_bricks
fill 348 139 465 348 141 465 minecraft:pink_terracotta
setblock 348 139 504 minecraft:red_nether_bricks
fill 349 139 464 349 142 464 minecraft:pink_terracotta
setblock 349 139 503 minecraft:red_nether_bricks
fill 349 139 504 349 142 504 minecraft:pink_terracotta
setblock 350 139 502 minecraft:red_nether_bricks
fill 350 139 503 350 141 503 minecraft:pink_terracotta
setblock 353 139 464 minecraft:red_nether_bricks
setblock 353 139 504 minecraft:red_nether_bricks
fill 354 139 504 357 139 504 minecraft:pink_terracotta
setblock 358 139 504 minecraft:red_nether_bricks
fill 359 139 464 362 139 464 minecraft:pink_terracotta
fill 359 139 504 359 142 504 minecraft:pink_terracotta
setblock 360 139 503 minecraft:pink_terracotta
setblock 362 139 465 minecraft:red_nether_bricks
setblock 363 139 464 minecraft:red_nether_bricks
fill 363 139 465 363 142 465 minecraft:pink_terracotta
setblock 363 139 504 minecraft:red_nether_bricks
fill 364 139 464 364 142 464 minecraft:pink_terracotta
setblock 364 139 503 minecraft:red_nether_bricks
fill 364 139 504 364 142 504 minecraft:pink_terracotta
fill 365 139 503 365 140 503 minecraft:pink_terracotta
setblock 367 139 465 minecraft:red_nether_bricks
setblock 367 139 480 minecraft:red_nether_bricks
setblock 367 139 481 minecraft:pink_terracotta
setblock 367 139 485 minecraft:red_nether_bricks
fill 367 139 486 367 140 486 minecraft:pink_terracotta
setblock 368 139 464 minecraft:red_nether_bricks
fill 368 139 465 369 141 465 minecraft:pink_terracotta
setblock 368 139 479 minecraft:red_nether_bricks
fill 368 139 480 368 140 480 minecraft:pink_terracotta
setblock 368 139 484 minecraft:red_nether_bricks
fill 368 139 485 368 142 485 minecraft:pink_terracotta
setblock 368 139 504 minecraft:red_nether_bricks
fill 369 139 464 369 142 464 minecraft:pink_terracotta
fill 369 139 466 369 139 467 minecraft:pink_terracotta
setblock 369 139 468 minecraft:red_nether_bricks
setblock 369 139 469 minecraft:pink_terracotta
setblock 369 139 478 minecraft:red_nether_bricks
fill 369 139 479 369 141 479 minecraft:pink_terracotta
setblock 369 139 483 minecraft:red_nether_bricks
fill 369 139 484 369 142 484 minecraft:pink_terracotta
setblock 369 139 488 minecraft:red_nether_bricks
fill 369 139 489 369 140 489 minecraft:pink_terracotta
fill 369 139 504 369 140 504 minecraft:pink_terracotta
setblock 370 139 467 minecraft:red_nether_bricks
fill 370 139 468 370 142 468 minecraft:pink_terracotta
setblock 370 139 472 minecraft:red_nether_bricks
fill 370 139 473 370 140 473 minecraft:pink_terracotta
setblock 370 139 477 minecraft:red_nether_bricks
fill 370 139 478 370 141 478 minecraft:pink_terracotta
setblock 370 139 482 minecraft:red_nether_bricks
fill 370 139 483 370 142 483 minecraft:pink_terracotta
setblock 370 139 487 minecraft:red_nether_bricks
fill 370 139 488 370 142 488 minecraft:pink_terracotta
setblock 370 139 502 minecraft:red_nether_bricks
setblock 370 139 503 minecraft:pink_terracotta
fill 330 140 464 331 140 464 minecraft:pink_terracotta
setblock 330 140 466 minecraft:red_nether_bricks
fill 330 140 467 330 143 467 minecraft:pink_terracotta
setblock 330 140 471 minecraft:red_nether_bricks
setblock 330 140 472 minecraft:pink_terracotta
setblock 330 140 477 minecraft:pink_terracotta
setblock 330 140 481 minecraft:red_nether_bricks
fill 330 140 482 330 141 482 minecraft:pink_terracotta
setblock 330 140 486 minecraft:red_nether_bricks
setblock 330 140 487 minecraft:pink_terracotta
setblock 330 140 489 minecraft:white_concrete
setblock 330 140 502 minecraft:pink_terracotta
setblock 331 140 465 minecraft:red_nether_bricks
fill 331 140 466 331 143 466 minecraft:pink_terracotta
setblock 331 140 504 minecraft:pink_terracotta
setblock 332 140 464 minecraft:red_nether_bricks
fill 332 140 465 335 140 465 minecraft:pink_terracotta
setblock 332 140 504 minecraft:red_nether_bricks
fill 333 140 464 333 143 464 minecraft:pink_terracotta
fill 333 140 504 333 141 504 minecraft:pink_terracotta
setblock 336 140 465 minecraft:red_nether_bricks
setblock 337 140 464 minecraft:red_nether_bricks
fill 337 140 465 337 143 465 minecraft:pink_terracotta
setblock 337 140 504 minecraft:red_nether_bricks
fill 338 140 464 338 143 464 minecraft:pink_terracotta
setblock 338 140 503 minecraft:red_nether_bricks
fill 338 140 504 338 143 504 minecraft:pink_terracotta
fill 339 140 503 339 143 503 minecraft:pink_terracotta
setblock 340 140 466 minecraft:red_nether_bricks
setblock 341 140 465 minecraft:red_nether_bricks
fill 341 140 466 341 143 466 minecraft:pink_terracotta
setblock 342 140 464 minecraft:red_nether_bricks
fill 342 140 465 342 143 465 minecraft:pink_terracotta
setblock 342 140 504 minecraft:red_nether_bricks
fill 343 140 464 343 143 464 minecraft:pink_terracotta
setblock 343 140 503 minecraft:red_nether_bricks
fill 343 140 504 343 143 504 minecraft:pink_terracotta
setblock 344 140 502 minecraft:red_nether_bricks
fill 344 140 503 344 143 503 minecraft:pink_terracotta
setblock 345 140 466 minecraft:red_nether_bricks
fill 345 140 502 345 141 502 minecraft:pink_terracotta
setblock 346 140 465 minecraft:red_nether_bricks
setblock 346 140 466 minecraft:pink_terracotta
setblock 347 140 464 minecraft:red_nether_bricks
fill 347 140 465 347 142 465 minecraft:pink_terracotta
setblock 347 140 504 minecraft:red_nether_bricks
fill 348 140 464 348 143 464 minecraft:pink_terracotta
setblock 348 140 503 minecraft:red_nether_bricks
fill 348 140 504 348 143 504 minecraft:pink_terracotta
fill 349 140 503 349 141 503 minecraft:pink_terracotta
setblock 352 140 464 minecraft:red_nether_bricks
setblock 352 140 504 minecraft:red_nether_bricks
fill 353 140 504 356 140 504 minecraft:pink_terracotta
setblock 357 140 504 minecraft:red_nether_bricks
fill 358 140 504 358 141 504 minecraft:pink_terracotta
fill 359 140 464 361 140 464 minecraft:pink_terracotta
setblock 362 140 464 minecraft:red_nether_bricks
fill 362 140 465 362 143 465 minecraft:pink_terracotta
setblock 362 140 504 minecraft:red_nether_bricks
fill 363 140 464 363 143 464 minecraft:pink_terracotta
setblock 363 140 503 minecraft:red_nether_bricks
fill 363 140 504 363 143 504 minecraft:pink_terracotta
setblock 364 140 503 minecraft:pink_terracotta
setblock 366 140 465 minecraft:red_nether_bricks
setblock 367 140 464 minecraft:red_nether_bricks
fill 367 140 465 367 143 465 minecraft:pink_terracotta
setblock 367 140 484 minecraft:red_nether_bricks
setblock 367 140 485 minecraft:pink_terracotta
setblock 367 140 504 minecraft:red_nether_bricks
fill 368 140 464 368 143 464 minecraft:pink_terracotta
setblock 368 140 479 minecraft:pink_terracotta
setblock 368 140 483 minecraft:red_nether_bricks
fill 368 140 484 368 141 484 minecraft:pink_terracotta
setblock 368 140 488 minecraft:red_nether_bricks
fill 368 140 504 368 141 504 minecraft:pink_terracotta
setblock 369 140 466 minecraft:pink_terracotta
setblock 369 140 467 minecraft:red_nether_bricks
fill 369 140 468 369 141 468 minecraft:pink_terracotta
setblock 369 140 477 minecraft:red_nether_bricks
setblock 369 140 478 minecraft:pink_terracotta
setblock 369 140 482 minecraft:red_nether_bricks
fill 369 140 483 369 142 483 minecraft:pink_terracotta
setblock 369 140 487 minecraft:red_nether_bricks
fill 369 140 488 369 142 488 minecraft:pink_terracotta
setblock 370 140 466 minecraft:red_nether_bricks
fill 370 140 467 370 143 467 minecraft:pink_terracotta
setblock 370 140 471 minecraft:red_nether_bricks
fill 370 140 472 370 141 472 minecraft:pink_terracotta
setblock 370 140 476 minecraft:red_nether_bricks
fill 370 140 477 370 141 477 minecraft:pink_terracotta
setblock 370 140 481 minecraft:red_nether_bricks
fill 370 140 482 370 143 482 minecraft:pink_terracotta
setblock 370 140 486 minecraft:red_nether_bricks
fill 370 140 487 370 143 487 minecraft:pink_terracotta
setblock 370 140 498 minecraft:white_concrete
setblock 330 141 464 minecraft:pink_terracotta
setblock 330 141 465 minecraft:red_nether_bricks
fill 330 141 466 330 144 466 minecraft:pink_terracotta
setblock 330 141 470 minecraft:red_nether_bricks
fill 330 141 471 330 144 471 minecraft:pink_terracotta
setblock 330 141 476 minecraft:white_concrete
setblock 330 141 481 minecraft:pink_terracotta
setblock 330 141 485 minecraft:red_nether_bricks
setblock 330 141 486 minecraft:pink_terracotta
setblock 330 141 495 minecraft:white_concrete
setblock 330 141 504 minecraft:pink_terracotta
setblock 331 141 464 minecraft:red_nether_bricks
fill 331 141 465 334 141 465 minecraft:pink_terracotta
setblock 331 141 504 minecraft:red_nether_bricks
fill 332 141 464 332 144 464 minecraft:pink_terracotta
setblock 332 141 504 minecraft:pink_terracotta
setblock 335 141 465 minecraft:red_nether_bricks
setblock 336 141 464 minecraft:red_nether_bricks
fill 336 141 465 336 144 465 minecraft:pink_terracotta
setblock 336 141 504 minecraft:red_nether_bricks
fill 337 141 464 337 144 464 minecraft:pink_terracotta
fill 337 141 504 337 144 504 minecraft:pink_terracotta
fill 338 141 503 338 144 503 minecraft:pink_terracotta
setblock 340 141 465 minecraft:red_nether_bricks
fill 340 141 466 340 144 466 minecraft:pink_terracotta
setblock 341 141 464 minecraft:red_nether_bricks
fill 341 141 465 341 144 465 minecraft:pink_terracotta
setblock 341 141 504 minecraft:red_nether_bricks
fill 342 141 464 342 144 464 minecraft:pink_terracotta
setblock 342 141 503 minecraft:red_nether_bricks
fill 342 141 504 342 144 504 minecraft:pink_terracotta
setblock 343 141 502 minecraft:red_nether_bricks
fill 343 141 503 343 144 503 minecraft:pink_terracotta
setblock 344 141 466 minecraft:red_nether_bricks
fill 344 141 502 344 142 502 minecraft:pink_terracotta
setblock 345 141 465 minecraft:red_nether_bricks
setblock 345 141 466 minecraft:pink_terracotta
setblock 346 141 464 minecraft:red_nether_bricks
fill 346 141 465 346 144 465 minecraft:pink_terracotta
setblock 346 141 504 minecraft:red_nether_bricks
fill 347 141 464 347 144 464 minecraft:pink_terracotta
setblock 347 141 503 minecraft:red_nether_bricks
fill 347 141 504 347 144 504 minecraft:pink_terracotta
fill 348 141 503 348 142 503 minecraft:pink_terracotta
setblock 351 141 464 minecraft:red_nether_bricks
setblock 351 141 504 minecraft:red_nether_bricks
fill 352 141 504 353 141 504 minecraft:pink_terracotta
setblock 354 141 464 minecraft:white_concrete
setblock 357 141 504 minecraft:pink_terracotta
fill 359 141 464 360 141 464 minecraft:pink_terracotta
setblock 361 141 464 minecraft:red_nether_bricks
setblock 361 141 504 minecraft:red_nether_bricks
fill 362 141 464 362 144 464 minecraft:pink_terracotta
fill 362 141 504 362 144 504 minecraft:pink_terracotta
setblock 365 141 465 minecraft:red_nether_bricks
setblock 366 141 464 minecraft:red_nether_bricks
fill 366 141 465 366 144 465 minecraft:pink_terracotta
setblock 366 141 504 minecraft:red_nether_bricks
fill 367 141 464 367 144 464 minecraft:pink_terracotta
fill 367 141 504 367 142 504 minecraft:pink_terracotta
setblock 368 141 482 minecraft:red_nether_bricks
setblock 368 141 483 minecraft:pink_terracotta
setblock 368 141 487 minecraft:red_nether_bricks
setblock 369 141 466 minecraft:red_nether_bricks
fill 369 141 467 369 144 467 minecraft:pink_terracotta
setblock 369 141 481 minecraft:red_nether_bricks
fill 369 141 482 369 142 482 minecraft:pink_terracotta
setblock 369 141 486 minecraft:red_nether_bricks
fill 369 141 487 369 143 487 minecraft:pink_terracotta
setblock 370 141 465 minecraft:red_nether_bricks
fill 370 141 466 370 144 466 minecraft:pink_terracotta
setblock 370 141 470 minecraft:red_nether_bricks
fill 370 141 471 370 144 471 minecraft:pink_terracotta
setblock 370 141 473 minecraft:white_concrete
setblock 370 141 476 minecraft:pink_terracotta
setblock 370 141 480 minecraft:red_nether_bricks
fill 370 141 481 370 143 481 minecraft:pink_terracotta
setblock 370 141 485 minecraft:red_nether_bricks
fill 370 141 486 370 144 486 minecraft:pink_terracotta
setblock 370 141 490 minecraft:red_nether_bricks
setblock 370 141 492 minecraft:white_concrete
setblock 330 142 464 minecraft:red_nether_bricks
fill 330 142 465 333 142 465 minecraft:pink_terracotta
setblock 330 142 469 minecraft:red_nether_bricks
fill 330 142 470 330 145 470 minecraft:pink_terracotta
setblock 330 142 482 minecraft:white_concrete
setblock 330 142 501 minecraft:white_concrete
fill 331 142 464 331 145 464 minecraft:pink_terracotta
setblock 334 142 465 minecraft:red_nether_bricks
setblock 335 142 464 minecraft:red_nether_bricks
fill 335 142 465 335 145 465 minecraft:pink_terracotta
setblock 335 142 504 minecraft:red_nether_bricks
fill 336 142 464 336 145 464 minecraft:pink_terracotta
fill 336 142 504 336 145 504 minecraft:pink_terracotta
setblock 339 142 465 minecraft:red_nether_bricks
fill 339 142 466 339 145 466 minecraft:pink_terracotta
setblock 340 142 464 minecraft:red_nether_bricks
fill 340 142 465 340 145 465 minecraft:pink_terracotta
setblock 340 142 504 minecraft:red_nether_bricks
fill 341 142 464 341 145 464 minecraft:pink_terracotta
setblock 341 142 503 minecraft:red_nether_bricks
fill 341 142 504 341 145 504 minecraft:pink_terracotta
setblock 342 142 502 minecraft:red_nether_bricks
fill 342 142 503 342 145 503 minecraft:pink_terracotta
setblock 343 142 466 minecraft:red_nether_bricks
setblock 343 142 502 minecraft:pink_terracotta
setblock 344 142 465 minecraft:red_nether_bricks
fill 344 142 466 344 143 466 minecraft:pink_terracotta
setblock 345 142 464 minecraft:red_nether_bricks
fill 345 142 465 345 145 465 minecraft:pink_terracotta
setblock 345 142 504 minecraft:red_nether_bricks
fill 346 142 464 346 145 464 minecraft:pink_terracotta
setblock 346 142 503 minecraft:red_nether_bricks
fill 346 142 504 346 145 504 minecraft:pink_terracotta
fill 347 142 503 347 143 503 minecraft:pink_terracotta
setblock 350 142 464 minecraft:red_nether_bricks
setblock 350 142 504 minecraft:red_nether_bricks
setblock 351 142 504 minecraft:pink_terracotta
setblock 352 142 504 minecraft:white_concrete
setblock 359 142 464 minecraft:pink_terracotta
setblock 360 142 464 minecraft:red_nether_bricks
setblock 360 142 504 minecraft:red_nether_bricks
fill 361 142 464 361 144 465 minecraft:pink_terracotta
fill 361 142 504 361 145 504 minecraft:pink_terracotta
setblock 364 142 465 minecraft:red_nether_bricks
setblock 365 142 464 minecraft:red_nether_bricks
fill 365 142 465 365 145 465 minecraft:pink_terracotta
setblock 365 142 504 minecraft:red_nether_bricks
fill 366 142 464 366 145 464 minecraft:pink_terracotta
setblock 366 142 504 minecraft:pink_terracotta
setblock 368 142 465 minecraft:pink_terracotta
setblock 369 142 465 minecraft:red_nether_bricks
fill 369 142 466 369 145 466 minecraft:pink_terracotta
setblock 369 142 485 minecraft:red_nether_bricks
fill 369 142 486 369 143 486 minecraft:pink_terracotta
setblock 370 142 464 minecraft:red_nether_bricks
fill 370 142 465 370 145 465 minecraft:pink_terracotta
setblock 370 142 469 minecraft:red_nether_bricks
fill 370 142 470 370 145 470 minecraft:pink_terracotta
setblock 370 142 479 minecraft:red_nether_bricks
setblock 370 142 480 minecraft:pink_terracotta
setblock 370 142 484 minecraft:red_nether_bricks
fill 370 142 485 370 145 485 minecraft:pink_terracotta
setblock 370 142 489 minecraft:red_nether_bricks
fill 330 143 464 330 145 465 minecraft:pink_terracotta
setblock 330 143 468 minecraft:red_nether_bricks
fill 330 143 469 330 146 469 minecraft:pink_terracotta
setblock 330 143 488 minecraft:white_concrete
fill 331 143 465 332 143 465 minecraft:pink_terracotta
setblock 331 143 467 minecraft:red_nether_bricks
setblock 332 143 466 minecraft:light[level=12]
setblock 332 143 474 minecraft:light[level=12]
setblock 332 143 482 minecraft:light[level=12]
setblock 332 143 490 minecraft:light[level=12]
setblock 332 143 498 minecraft:light[level=12]
setblock 333 143 465 minecraft:red_nether_bricks
setblock 333 143 504 minecraft:white_concrete
setblock 334 143 464 minecraft:red_nether_bricks
fill 334 143 465 334 146 465 minecraft:pink_terracotta
fill 335 143 464 335 146 464 minecraft:pink_terracotta
fill 335 143 504 335 146 504 minecraft:pink_terracotta
setblock 338 143 465 minecraft:red_nether_bricks
setblock 339 143 464 minecraft:red_nether_bricks
fill 339 143 465 339 146 465 minecraft:pink_terracotta
setblock 339 143 504 minecraft:red_nether_bricks
fill 340 143 464 340 146 464 minecraft:pink_terracotta
setblock 340 143 474 minecraft:light[level=12]
setblock 340 143 482 minecraft:light[level=12]
setblock 340 143 490 minecraft:light[level=12]
setblock 340 143 498 minecraft:light[level=12]
setblock 340 143 503 minecraft:red_nether_bricks
fill 340 143 504 340 146 504 minecraft:pink_terracotta
fill 341 143 502 343 146 502 minecraft:white_concrete
fill 341 143 503 341 146 503 minecraft:pink_terracotta
setblock 342 143 466 minecraft:red_nether_bricks
fill 342 143 501 342 146 501 minecraft:white_concrete
setblock 343 143 465 minecraft:red_nether_bricks
fill 343 143 466 343 146 466 minecraft:pink_terracotta
setblock 344 143 464 minecraft:red_nether_bricks
fill 344 143 465 344 146 465 minecraft:pink_terracotta
setblock 344 143 504 minecraft:red_nether_bricks
fill 345 143 464 345 146 464 minecraft:pink_terracotta
setblock 345 143 503 minecraft:red_nether_bricks
fill 345 143 504 345 146 504 minecraft:pink_terracotta
fill 346 143 503 346 144 503 minecraft:pink_terracotta
setblock 348 143 466 minecraft:light[level=12]
setblock 348 143 474 minecraft:light[level=12]
setblock 348 143 482 minecraft:light[level=12]
setblock 348 143 490 minecraft:light[level=12]
setblock 348 143 498 minecraft:light[level=12]
setblock 349 143 464 minecraft:red_nether_bricks
setblock 349 143 504 minecraft:red_nether_bricks
setblock 350 143 504 minecraft:pink_terracotta
setblock 356 143 466 minecraft:light[level=12]
setblock 356 143 474 minecraft:light[level=12]
setblock 356 143 482 minecraft:light[level=12]
setblock 356 143 490 minecraft:light[level=12]
setblock 356 143 498 minecraft:light[level=12]
setblock 358 143 464 minecraft:pink_terracotta
setblock 358 143 504 minecraft:white_concrete
setblock 359 143 464 minecraft:red_nether_bricks
fill 360 143 464 360 146 464 minecraft:pink_terracotta
fill 360 143 504 360 146 504 minecraft:pink_terracotta
setblock 363 143 465 minecraft:red_nether_bricks
setblock 364 143 464 minecraft:red_nether_bricks
fill 364 143 465 364 146 465 minecraft:pink_terracotta
setblock 364 143 466 minecraft:light[level=12]
setblock 364 143 474 minecraft:light[level=12]
setblock 364 143 482 minecraft:light[level=12]
setblock 364 143 490 minecraft:light[level=12]
setblock 364 143 498 minecraft:light[level=12]
setblock 364 143 504 minecraft:red_nether_bricks
fill 365 143 464 365 146 464 minecraft:pink_terracotta
setblock 365 143 504 minecraft:pink_terracotta
setblock 368 143 465 minecraft:red_nether_bricks
setblock 369 143 464 minecraft:red_nether_bricks
setblock 369 143 484 minecraft:red_nether_bricks
setblock 369 143 485 minecraft:pink_terracotta
fill 370 143 464 370 146 464 minecraft:pink_terracotta
setblock 370 143 468 minecraft:red_nether_bricks
fill 370 143 469 370 146 469 minecraft:pink_terracotta
setblock 370 143 480 minecraft:white_concrete
setblock 370 143 483 minecraft:red_nether_bricks
fill 370 143 484 370 144 484 minecraft:pink_terracotta
setblock 370 143 488 minecraft:red_nether_bricks
fill 370 143 489 370 144 489 minecraft:pink_terracotta
setblock 330 144 467 minecraft:red_nether_bricks
fill 330 144 468 330 147 468 minecraft:pink_terracotta
setblock 330 144 494 minecraft:white_concrete
setblock 331 144 465 minecraft:pink_terracotta
setblock 331 144 466 minecraft:red_nether_bricks
fill 331 144 467 331 147 467 minecraft:pink_terracotta
setblock 332 144 465 minecraft:red_nether_bricks
setblock 333 144 464 minecraft:red_nether_bricks
fill 333 144 465 333 147 465 minecraft:pink_terracotta
fill 334 144 464 334 147 464 minecraft:pink_terracotta
setblock 337 144 465 minecraft:red_nether_bricks
setblock 338 144 464 minecraft:red_nether_bricks
fill 338 144 465 338 146 466 minecraft:pink_terracotta
setblock 338 144 504 minecraft:red_nether_bricks
fill 339 144 464 339 147 464 minecraft:pink_terracotta
setblock 339 144 503 minecraft:red_nether_bricks
fill 339 144 504 339 147 504 minecraft:pink_terracotta
fill 340 144 502 340 145 502 minecraft:white_concrete
fill 340 144 503 340 147 503 minecraft:pink_terracotta
setblock 341 144 466 minecraft:red_nether_bricks
fill 341 144 501 341 145 501 minecraft:white_concrete
setblock 342 144 465 minecraft:red_nether_bricks
fill 342 144 466 342 147 466 minecraft:pink_terracotta
setblock 343 144 464 minecraft:red_nether_bricks
fill 343 144 465 343 147 465 minecraft:pink_terracotta
fill 343 144 501 343 145 501 minecraft:white_concrete
setblock 343 144 504 minecraft:red_nether_bricks
fill 344 144 464 344 147 464 minecraft:pink_terracotta
fill 344 144 502 344 145 502 minecraft:white_concrete
setblock 344 144 503 minecraft:red_nether_bricks
fill 344 144 504 344 147 504 minecraft:pink_terracotta
fill 345 144 503 345 145 503 minecraft:pink_terracotta
setblock 348 144 464 minecraft:red_nether_bricks
setblock 348 144 504 minecraft:red_nether_bricks
setblock 349 144 504 minecraft:pink_terracotta
fill 355 144 464 355 145 464 minecraft:white_concrete
setblock 358 144 464 minecraft:red_nether_bricks
fill 359 144 464 359 147 464 minecraft:pink_terracotta
fill 360 144 465 360 145 465 minecraft:pink_terracotta
setblock 362 144 465 minecraft:red_nether_bricks
setblock 363 144 464 minecraft:red_nether_bricks
fill 363 144 465 363 147 465 minecraft:pink_terracotta
setblock 363 144 504 minecraft:red_nether_bricks
fill 364 144 464 364 147 464 minecraft:pink_terracotta
setblock 364 144 504 minecraft:white_concrete
setblock 367 144 465 minecraft:red_nether_bricks
setblock 368 144 464 minecraft:red_nether_bricks
setblock 368 144 465 minecraft:pink_terracotta
fill 369 144 464 369 147 464 minecraft:pink_terracotta
setblock 369 144 468 minecraft:red_nether_bricks
setblock 370 144 467 minecraft:red_nether_bricks
fill 370 144 468 370 147 468 minecraft:pink_terracotta
setblock 370 144 472 minecraft:red_nether_bricks
setblock 370 144 474 minecraft:white_concrete
setblock 370 144 483 minecraft:pink_terracotta
setblock 370 144 487 minecraft:red_nether_bricks
fill 370 144 488 370 147 488 minecraft:pink_terracotta
setblock 370 144 499 minecraft:white_concrete
setblock 330 145 466 minecraft:red_nether_bricks
fill 330 145 467 330 148 467 minecraft:pink_terracotta
setblock 330 145 471 minecraft:red_nether_bricks
fill 330 145 472 330 148 472 minecraft:pink_terracotta
setblock 330 145 475 minecraft:white_concrete
setblock 330 145 500 minecraft:white_concrete
setblock 331 145 465 minecraft:red_nether_bricks
fill 331 145 466 331 148 466 minecraft:pink_terracotta
fill 331 145 468 331 146 468 minecraft:pink_terracotta
setblock 332 145 464 minecraft:red_nether_bricks
fill 332 145 465 332 148 465 minecraft:pink_terracotta
fill 333 145 464 333 148 464 minecraft:pink_terracotta
fill 334 145 504 334 147 504 minecraft:pink_terracotta
setblock 336 145 465 minecraft:red_nether_bricks
setblock 337 145 464 minecraft:red_nether_bricks
fill 337 145 465 337 147 466 minecraft:pink_terracotta
setblock 337 145 504 minecraft:red_nether_bricks
fill 338 145 464 338 148 464 minecraft:pink_terracotta
setblock 338 145 503 minecraft:red_nether_bricks
fill 338 145 504 338 148 504 minecraft:pink_terracotta
fill 339 145 503 339 148 503 minecraft:pink_terracotta
setblock 340 145 466 minecraft:red_nether_bricks
setblock 341 145 465 minecraft:red_nether_bricks
fill 341 145 466 341 148 466 minecraft:pink_terracotta
fill 341 145 467 341 146 467 minecraft:red_concrete
setblock 342 145 464 minecraft:red_nether_bricks
fill 342 145 465 342 148 465 minecraft:pink_terracotta
setblock 342 145 500 minecraft:black_concrete
setblock 342 145 504 minecraft:red_nether_bricks
fill 343 145 464 343 148 464 minecraft:pink_terracotta
setblock 343 145 503 minecraft:red_nether_bricks
fill 343 145 504 343 148 504 minecraft:pink_terracotta
fill 344 145 503 344 148 503 minecraft:pink_terracotta
setblock 347 145 464 minecraft:red_nether_bricks
setblock 347 145 504 minecraft:red_nether_bricks
setblock 348 145 504 minecraft:pink_terracotta
setblock 349 145 464 minecraft:white_concrete
fill 358 145 464 358 148 464 minecraft:pink_terracotta
setblock 361 145 464 minecraft:pink_terracotta
setblock 361 145 465 minecraft:red_nether_bricks
setblock 362 145 464 minecraft:red_nether_bricks
fill 362 145 465 362 148 465 minecraft:pink_terracotta
setblock 362 145 504 minecraft:red_nether_bricks
fill 363 145 464 363 148 464 minecraft:pink_terracotta
setblock 366 145 465 minecraft:red_nether_bricks
setblock 367 145 464 minecraft:red_nether_bricks
fill 367 145 465 367 148 465 minecraft:pink_terracotta
fill 368 145 464 368 148 464 minecraft:pink_terracotta
setblock 369 145 467 minecraft:red_nether_bricks
fill 369 145 468 369 146 470 minecraft:pink_terracotta
setblock 370 145 466 minecraft:red_nether_bricks
fill 370 145 467 370 148 467 minecraft:pink_terracotta
setblock 370 145 471 minecraft:red_nether_bricks
fill 370 145 472 370 147 473 minecraft:pink_terracotta
setblock 370 145 486 minecraft:red_nether_bricks
fill 370 145 487 370 147 487 minecraft:pink_terracotta
setblock 370 145 493 minecraft:white_concrete
setblock 370 145 504 minecraft:white_concrete
setblock 330 146 464 minecraft:pink_terracotta
setblock 330 146 465 minecraft:red_nether_bricks
fill 330 146 466 330 149 466 minecraft:pink_terracotta
setblock 330 146 470 minecraft:red_nether_bricks
fill 330 146 471 330 149 471 minecraft:pink_terracotta
setblock 330 146 481 minecraft:white_concrete
setblock 331 146 464 minecraft:red_nether_bricks
fill 331 146 465 331 149 465 minecraft:pink_terracotta
setblock 331 146 469 minecraft:red_nether_bricks
fill 332 146 464 332 149 464 minecraft:pink_terracotta
setblock 332 146 504 minecraft:white_concrete
setblock 335 146 465 minecraft:red_nether_bricks
setblock 336 146 464 minecraft:red_nether_bricks
fill 336 146 465 336 148 466 minecraft:pink_terracotta
setblock 336 146 504 minecraft:red_nether_bricks
fill 337 146 464 337 149 464 minecraft:pink_terracotta
setblock 337 146 503 minecraft:red_nether_bricks
fill 337 146 504 337 149 504 minecraft:pink_terracotta
fill 338 146 503 338 149 503 minecraft:pink_terracotta
setblock 339 146 466 minecraft:red_nether_bricks
setblock 340 146 465 minecraft:red_nether_bricks
fill 340 146 466 340 149 466 minecraft:pink_terracotta
setblock 341 146 464 minecraft:red_nether_bricks
fill 341 146 465 341 149 465 minecraft:pink_terracotta
setblock 341 146 504 minecraft:red_nether_bricks
fill 342 146 464 342 149 464 minecraft:pink_terracotta
setblock 342 146 503 minecraft:red_nether_bricks
fill 342 146 504 342 149 504 minecraft:pink_terracotta
fill 343 146 503 343 149 503 minecraft:pink_terracotta
setblock 345 146 465 minecraft:red_nether_bricks
setblock 346 146 464 minecraft:red_nether_bricks
setblock 346 146 504 minecraft:red_nether_bricks
setblock 347 146 464 minecraft:pink_terracotta
fill 347 146 504 347 147 504 minecraft:pink_terracotta
setblock 351 146 504 minecraft:white_concrete
fill 357 146 464 357 149 464 minecraft:pink_terracotta
fill 357 146 504 357 147 504 minecraft:white_concrete
setblock 359 146 465 minecraft:pink_terracotta
setblock 360 146 465 minecraft:red_nether_bricks
setblock 361 146 464 minecraft:red_nether_bricks
fill 361 146 465 361 149 465 minecraft:pink_terracotta
setblock 361 146 504 minecraft:red_nether_bricks
fill 362 146 464 362 149 464 minecraft:pink_terracotta
fill 362 146 466 363 146 466 minecraft:pink_terracotta
setblock 365 146 465 minecraft:red_nether_bricks
setblock 366 146 464 minecraft:red_nether_bricks
fill 366 146 465 366 149 465 minecraft:pink_terracotta
fill 367 146 464 367 149 464 minecraft:pink_terracotta
setblock 369 146 466 minecraft:red_nether_bricks
fill 369 146 467 369 149 467 minecraft:pink_terracotta
setblock 369 146 471 minecraft:red_nether_bricks
setblock 370 146 465 minecraft:red_nether_bricks
fill 370 146 466 370 149 466 minecraft:pink_terracotta
setblock 370 146 470 minecraft:red_nether_bricks
fill 370 146 471 370 149 471 minecraft:pink_terracotta
setblock 370 146 474 minecraft:pink_terracotta
setblock 370 146 481 minecraft:white_concrete
setblock 370 146 486 minecraft:pink_terracotta
setblock 370 146 489 minecraft:pink_terracotta
setblock 330 147 464 minecraft:red_nether_bricks
fill 330 147 465 330 150 465 minecraft:pink_terracotta
setblock 330 147 469 minecraft:red_nether_bricks
fill 330 147 470 331 149 470 minecraft:pink_terracotta
setblock 330 147 473 minecraft:pink_terracotta
setblock 330 147 487 minecraft:white_concrete
fill 330 147 493 330 148 493 minecraft:white_concrete
fill 331 147 464 331 150 464 minecraft:pink_terracotta
setblock 331 147 468 minecraft:red_nether_bricks
fill 331 147 469 331 150 469 minecraft:pink_terracotta
fill 333 147 504 333 148 504 minecraft:pink_terracotta
setblock 334 147 465 minecraft:red_nether_bricks
setblock 335 147 464 minecraft:red_nether_bricks
fill 335 147 465 335 149 466 minecraft:pink_terracotta
setblock 335 147 504 minecraft:red_nether_bricks
fill 336 147 464 336 150 464 minecraft:pink_terracotta
fill 336 147 504 336 150 504 minecraft:pink_terracotta
fill 337 147 503 337 150 503 minecraft:pink_terracotta
setblock 338 147 465 minecraft:pink_terracotta
setblock 338 147 466 minecraft:red_nether_bricks
setblock 339 147 465 minecraft:red_nether_bricks
fill 339 147 466 339 150 466 minecraft:pink_terracotta
setblock 340 147 464 minecraft:red_nether_bricks
fill 340 147 465 340 150 465 minecraft:pink_terracotta
setblock 340 147 504 minecraft:red_nether_bricks
fill 341 147 464 341 150 464 minecraft:pink_terracotta
setblock 341 147 503 minecraft:red_nether_bricks
fill 341 147 504 341 150 504 minecraft:pink_terracotta
fill 342 147 503 342 150 503 minecraft:pink_terracotta
setblock 344 147 465 minecraft:red_nether_bricks
setblock 345 147 464 minecraft:red_nether_bricks
setblock 345 147 504 minecraft:red_nether_bricks
fill 346 147 464 346 148 464 minecraft:pink_terracotta
fill 346 147 504 346 149 504 minecraft:pink_terracotta
fill 356 147 464 356 150 464 minecraft:pink_terracotta
setblock 358 147 465 minecraft:pink_terracotta
setblock 359 147 465 minecraft:red_nether_bricks
setblock 360 147 464 minecraft:red_nether_bricks
fill 360 147 465 360 150 465 minecraft:pink_terracotta
setblock 360 147 504 minecraft:red_nether_bricks
fill 361 147 464 361 150 464 minecraft:pink_terracotta
fill 361 147 466 362 147 466 minecraft:pink_terracotta
fill 361 147 504 361 149 504 minecraft:pink_terracotta
setblock 363 147 466 minecraft:red_nether_bricks
setblock 363 147 504 minecraft:white_concrete
setblock 364 147 465 minecraft:red_nether_bricks
fill 364 147 466 364 148 466 minecraft:pink_terracotta
setblock 365 147 464 minecraft:red_nether_bricks
fill 365 147 465 365 150 465 minecraft:pink_terracotta
fill 366 147 464 366 150 464 minecraft:pink_terracotta
fill 369 147 466 369 150 466 minecraft:pink_terracotta
fill 369 147 468 369 147 469 minecraft:pink_terracotta
setblock 369 147 470 minecraft:red_nether_bricks
fill 369 147 471 369 149 472 minecraft:pink_terracotta
setblock 370 147 464 minecraft:red_nether_bricks
fill 370 147 465 370 150 465 minecraft:pink_terracotta
setblock 370 147 469 minecraft:red_nether_bricks
fill 370 147 470 370 150 470 minecraft:pink_terracotta
setblock 370 147 474 minecraft:red_nether_bricks
fill 370 147 475 370 150 475 minecraft:pink_terracotta
setblock 370 147 489 minecraft:red_nether_bricks
setblock 370 147 500 minecraft:white_concrete
fill 330 148 464 330 151 464 minecraft:pink_terracotta
setblock 330 148 468 minecraft:red_nether_bricks
fill 330 148 469 330 151 469 minecraft:pink_terracotta
setblock 330 148 473 minecraft:red_nether_bricks
fill 330 148 474 330 151 474 minecraft:pink_terracotta
setblock 330 148 499 minecraft:white_concrete
setblock 331 148 467 minecraft:red_nether_bricks
fill 331 148 468 331 151 468 minecraft:pink_terracotta
setblock 331 148 471 minecraft:pink_terracotta
fill 332 148 504 332 149 504 minecraft:pink_terracotta
setblock 333 148 465 minecraft:red_nether_bricks
setblock 334 148 464 minecraft:red_nether_bricks
fill 334 148 465 334 150 466 minecraft:pink_terracotta
setblock 334 148 504 minecraft:red_nether_bricks
fill 335 148 464 335 151 464 minecraft:pink_terracotta
fill 335 148 504 335 151 504 minecraft:pink_terracotta
fill 336 148 503 336 151 503 minecraft:pink_terracotta
setblock 337 148 465 minecraft:pink_terracotta
setblock 337 148 466 minecraft:red_nether_bricks
setblock 338 148 465 minecraft:red_nether_bricks
fill 338 148 466 338 151 466 minecraft:pink_terracotta
setblock 339 148 464 minecraft:red_nether_bricks
fill 339 148 465 339 151 465 minecraft:pink_terracotta
setblock 339 148 504 minecraft:red_nether_bricks
fill 340 148 464 340 151 464 minecraft:pink_terracotta
setblock 340 148 503 minecraft:red_nether_bricks
fill 340 148 504 340 151 504 minecraft:pink_terracotta
fill 341 148 503 341 151 503 minecraft:pink_terracotta
setblock 342 148 466 minecraft:red_nether_bricks
setblock 343 148 465 minecraft:red_nether_bricks
setblock 344 148 464 minecraft:red_nether_bricks
setblock 344 148 465 minecraft:pink_terracotta
setblock 344 148 504 minecraft:red_nether_bricks
fill 345 148 464 345 149 464 minecraft:pink_terracotta
fill 345 148 504 345 150 504 minecraft:pink_terracotta
setblock 357 148 465 minecraft:pink_terracotta
setblock 358 148 465 minecraft:red_nether_bricks
setblock 359 148 464 minecraft:red_nether_bricks
fill 359 148 465 359 151 465 minecraft:pink_terracotta
setblock 359 148 504 minecraft:red_nether_bricks
fill 360 148 464 360 151 464 minecraft:pink_terracotta
fill 360 148 466 361 148 466 minecraft:pink_terracotta
fill 360 148 504 360 150 504 minecraft:pink_terracotta
setblock 362 148 466 minecraft:red_nether_bricks
setblock 363 148 465 minecraft:red_nether_bricks
fill 363 148 466 363 149 466 minecraft:pink_terracotta
setblock 364 148 464 minecraft:red_nether_bricks
fill 364 148 465 364 150 465 minecraft:pink_terracotta
fill 365 148 464 365 151 464 minecraft:pink_terracotta
setblock 368 148 469 minecraft:pink_terracotta
setblock 368 148 470 minecraft:red_nether_bricks
setblock 369 148 464 minecraft:red_nether_bricks
setblock 369 148 468 minecraft:pink_terracotta
setblock 369 148 469 minecraft:red_nether_bricks
fill 369 148 470 369 151 470 minecraft:pink_terracotta
setblock 369 148 473 minecraft:pink_terracotta
setblock 369 148 474 minecraft:red_nether_bricks
setblock 369 148 504 minecraft:white_concrete
fill 370 148 464 370 151 464 minecraft:pink_terracotta
setblock 370 148 468 minecraft:red_nether_bricks
fill 370 148 469 370 151 469 minecraft:pink_terracotta
setblock 370 148 472 minecraft:pink_terracotta
setblock 370 148 473 minecraft:red_nether_bricks
fill 370 148 474 370 151 474 minecraft:pink_terracotta
fill 370 148 476 370 149 476 minecraft:pink_terracotta
setblock 370 148 488 minecraft:red_nether_bricks
fill 370 148 489 370 149 490 minecraft:pink_terracotta
setblock 370 148 494 minecraft:white_concrete
setblock 330 149 467 minecraft:red_nether_bricks
fill 330 149 468 330 152 468 minecraft:pink_terracotta
setblock 330 149 472 minecraft:red_nether_bricks
fill 330 149 473 330 152 473 minecraft:pink_terracotta
setblock 330 149 480 minecraft:white_concrete
setblock 330 149 491 minecraft:pink_terracotta
setblock 330 149 492 minecraft:red_nether_bricks
fill 330 149 493 330 151 494 minecraft:pink_terracotta
setblock 331 149 466 minecraft:red_nether_bricks
fill 331 149 467 331 152 467 minecraft:pink_terracotta
setblock 331 149 471 minecraft:red_nether_bricks
fill 331 149 472 331 152 472 minecraft:pink_terracotta
setblock 331 149 504 minecraft:white_concrete
setblock 332 149 465 minecraft:red_nether_bricks
setblock 333 149 464 minecraft:red_nether_bricks
fill 333 149 465 333 152 465 minecraft:pink_terracotta
setblock 333 149 504 minecraft:red_nether_bricks
fill 334 149 464 334 152 464 minecraft:pink_terracotta
fill 334 149 504 334 152 504 minecraft:pink_terracotta
fill 335 149 503 335 152 503 minecraft:pink_terracotta
setblock 336 149 465 minecraft:pink_terracotta
setblock 336 149 466 minecraft:red_nether_bricks
setblock 337 149 465 minecraft:red_nether_bricks
fill 337 149 466 337 151 466 minecraft:pink_terracotta
setblock 338 149 464 minecraft:red_nether_bricks
fill 338 149 465 338 152 465 minecraft:pink_terracotta
fill 338 149 502 339 149 502 minecraft:pink_terracotta
setblock 338 149 504 minecraft:red_nether_bricks
fill 339 149 464 339 152 464 minecraft:pink_terracotta
setblock 339 149 503 minecraft:red_nether_bricks
fill 339 149 504 339 152 504 minecraft:pink_terracotta
setblock 340 149 502 minecraft:red_nether_bricks
fill 340 149 503 340 152 503 minecraft:pink_terracotta
setblock 341 149 466 minecraft:red_nether_bricks
setblock 342 149 465 minecraft:red_nether_bricks
setblock 343 149 464 minecraft:red_nether_bricks
setblock 343 149 465 minecraft:pink_terracotta
setblock 343 149 504 minecraft:red_nether_bricks
fill 344 149 464 344 150 464 minecraft:pink_terracotta
fill 344 149 504 344 151 504 minecraft:pink_terracotta
setblock 350 149 464 minecraft:white_concrete
setblock 350 149 504 minecraft:white_concrete
fill 355 149 464 355 151 464 minecraft:pink_terracotta
setblock 357 149 465 minecraft:red_nether_bricks
setblock 358 149 464 minecraft:red_nether_bricks
fill 358 149 465 358 152 465 minecraft:pink_terracotta
setblock 358 149 504 minecraft:red_nether_bricks
fill 359 149 464 359 152 464 minecraft:pink_terracotta
fill 359 149 466 360 149 466 minecraft:pink_terracotta
fill 359 149 504 359 151 504 minecraft:pink_terracotta
setblock 361 149 466 minecraft:red_nether_bricks
setblock 362 149 465 minecraft:red_nether_bricks
fill 362 149 466 362 150 466 minecraft:pink_terracotta
setblock 363 149 464 minecraft:red_nether_bricks
fill 363 149 465 363 151 465 minecraft:pink_terracotta
fill 364 149 464 364 152 464 minecraft:pink_terracotta
setblock 368 149 464 minecraft:red_nether_bricks
setblock 368 149 469 minecraft:red_nether_bricks
fill 368 149 470 368 150 472 minecraft:pink_terracotta
fill 369 149 464 369 152 464 minecraft:pink_terracotta
setblock 369 149 468 minecraft:red_nether_bricks
fill 369 149 469 369 152 469 minecraft:pink_terracotta
setblock 369 149 473 minecraft:red_nether_bricks
fill 369 149 474 369 151 475 minecraft:pink_terracotta
setblock 370 149 467 minecraft:red_nether_bricks
fill 370 149 468 370 152 468 minecraft:pink_terracotta
setblock 370 149 472 minecraft:red_nether_bricks
fill 370 149 473 370 152 473 minecraft:pink_terracotta
setblock 370 149 477 minecraft:red_nether_bricks
setblock 370 149 488 minecraft:white_concrete
setblock 370 149 491 minecraft:pink_terracotta
setblock 370 149 492 minecraft:red_nether_bricks
setblock 330 150 466 minecraft:red_nether_bricks
fill 330 150 467 330 153 467 minecraft:pink_terracotta
setblock 330 150 470 minecraft:pink_terracotta
setblock 330 150 471 minecraft:red_nether_bricks
fill 330 150 472 330 153 472 minecraft:pink_terracotta
setblock 330 150 475 minecraft:pink_terracotta
setblock 330 150 486 minecraft:white_concrete
setblock 330 150 490 minecraft:pink_terracotta
setblock 330 150 491 minecraft:red_nether_bricks
fill 330 150 492 330 153 492 minecraft:pink_terracotta
setblock 330 150 495 minecraft:pink_terracotta
setblock 330 150 496 minecraft:red_nether_bricks
fill 330 150 497 330 153 497 minecraft:pink_terracotta
setblock 331 150 465 minecraft:red_nether_bricks
fill 331 150 466 331 152 466 minecraft:pink_terracotta
setblock 331 150 470 minecraft:red_nether_bricks
fill 331 150 471 331 153 471 minecraft:pink_terracotta
fill 331 150 473 331 151 473 minecraft:pink_terracotta
setblock 331 150 504 minecraft:pink_terracotta
setblock 332 150 464 minecraft:red_nether_bricks
fill 332 150 465 332 152 465 minecraft:pink_terracotta
setblock 332 150 468 minecraft:pink_terracotta
setblock 332 150 469 minecraft:red_nether_bricks
setblock 332 150 504 minecraft:red_nether_bricks
fill 333 150 464 333 153 464 minecraft:pink_terracotta
fill 333 150 504 333 153 504 minecraft:pink_terracotta
fill 334 150 503 334 153 503 minecraft:pink_terracotta
setblock 335 150 465 minecraft:pink_terracotta
setblock 335 150 466 minecraft:red_nether_bricks
setblock 336 150 465 minecraft:red_nether_bricks
fill 336 150 466 336 151 466 minecraft:pink_terracotta
setblock 337 150 464 minecraft:red_nether_bricks
fill 337 150 465 337 153 465 minecraft:pink_terracotta
fill 337 150 502 338 150 502 minecraft:pink_terracotta
setblock 337 150 504 minecraft:red_nether_bricks
fill 338 150 464 338 153 464 minecraft:pink_terracotta
setblock 338 150 503 minecraft:red_nether_bricks
fill 338 150 504 338 153 504 minecraft:pink_terracotta
setblock 339 150 502 minecraft:red_nether_bricks
fill 339 150 503 339 153 503 minecraft:pink_terracotta
setblock 340 150 466 minecraft:red_nether_bricks
fill 340 150 502 340 152 502 minecraft:pink_terracotta
setblock 341 150 465 minecraft:red_nether_bricks
setblock 342 150 464 minecraft:red_nether_bricks
setblock 342 150 465 minecraft:pink_terracotta
setblock 342 150 504 minecraft:red_nether_bricks
fill 343 150 464 343 151 464 minecraft:pink_terracotta
setblock 343 150 503 minecraft:red_nether_bricks
fill 343 150 504 343 153 504 minecraft:pink_terracotta
setblock 356 150 504 minecraft:white_concrete
setblock 357 150 464 minecraft:red_nether_bricks
fill 357 150 465 357 151 465 minecraft:pink_terracotta
setblock 357 150 504 minecraft:red_nether_bricks
fill 358 150 464 358 153 464 minecraft:pink_terracotta
fill 358 150 504 358 151 504 minecraft:pink_terracotta
setblock 359 150 466 minecraft:pink_terracotta
setblock 360 150 466 minecraft:red_nether_bricks
setblock 361 150 465 minecraft:red_nether_bricks
setblock 361 150 466 minecraft:pink_terracotta
setblock 362 150 464 minecraft:red_nether_bricks
fill 362 150 465 362 151 465 minecraft:pink_terracotta
fill 363 150 464 363 152 464 minecraft:pink_terracotta
setblock 367 150 464 minecraft:red_nether_bricks
fill 368 150 464 368 151 464 minecraft:pink_terracotta
setblock 368 150 469 minecraft:pink_terracotta
setblock 369 150 467 minecraft:red_nether_bricks
fill 369 150 468 369 153 468 minecraft:pink_terracotta
setblock 369 150 471 minecraft:pink_terracotta
setblock 369 150 472 minecraft:red_nether_bricks
fill 369 150 473 369 153 473 minecraft:pink_terracotta
setblock 370 150 466 minecraft:red_nether_bricks
fill 370 150 467 370 153 467 minecraft:pink_terracotta
setblock 370 150 471 minecraft:red_nether_bricks
fill 370 150 472 370 153 472 minecraft:pink_terracotta
setblock 370 150 476 minecraft:red_nether_bricks
fill 370 150 477 370 152 478 minecraft:pink_terracotta
setblock 370 150 482 minecraft:white_concrete
setblock 370 150 490 minecraft:pink_terracotta
setblock 370 150 491 minecraft:red_nether_bricks
fill 370 150 492 370 152 493 minecraft:pink_terracotta
setblock 370 150 501 minecraft:white_concrete
setblock 330 151 465 minecraft:red_nether_bricks
fill 330 151 466 330 154 466 minecraft:pink_terracotta
setblock 330 151 470 minecraft:red_nether_bricks
fill 330 151 471 330 154 471 minecraft:pink_terracotta
setblock 330 151 475 minecraft:red_nether_bricks
fill 330 151 476 330 154 476 minecraft:pink_terracotta
setblock 330 151 490 minecraft:red_nether_bricks
fill 330 151 491 330 153 491 minecraft:pink_terracotta
setblock 330 151 495 minecraft:red_nether_bricks
fill 330 151 496 330 154 496 minecraft:pink_terracotta
fill 330 151 498 330 151 499 minecraft:pink_terracotta
setblock 331 151 464 minecraft:red_nether_bricks
setblock 331 151 465 minecraft:pink_terracotta
setblock 331 151 469 minecraft:red_nether_bricks
fill 331 151 470 332 151 470 minecraft:pink_terracotta
setblock 331 151 493 minecraft:pink_terracotta
setblock 331 151 494 minecraft:red_nether_bricks
fill 331 151 495 331 154 495 minecraft:pink_terracotta
setblock 331 151 504 minecraft:red_nether_bricks
fill 332 151 464 332 154 464 minecraft:pink_terracotta
setblock 332 151 466 minecraft:light[level=12]
setblock 332 151 469 minecraft:pink_terracotta
setblock 332 151 474 minecraft:light[level=12]
setblock 332 151 482 minecraft:light[level=12]
setblock 332 151 490 minecraft:light[level=12]
setblock 332 151 498 minecraft:light[level=12]
fill 332 151 504 332 154 504 minecraft:pink_terracotta
setblock 334 151 465 minecraft:pink_terracotta
setblock 334 151 466 minecraft:red_nether_bricks
setblock 335 151 465 minecraft:red_nether_bricks
setblock 335 151 466 minecraft:pink_terracotta
setblock 336 151 464 minecraft:red_nether_bricks
fill 336 151 465 336 153 465 minecraft:pink_terracotta
fill 336 151 502 337 151 502 minecraft:pink_terracotta
setblock 336 151 504 minecraft:red_nether_bricks
fill 337 151 464 337 154 464 minecraft:pink_terracotta
setblock 337 151 503 minecraft:red_nether_bricks
fill 337 151 504 337 154 504 minecraft:pink_terracotta
setblock 338 151 502 minecraft:red_nether_bricks
fill 338 151 503 338 154 503 minecraft:pink_terracotta
setblock 339 151 466 minecraft:red_nether_bricks
fill 339 151 502 339 153 502 minecraft:pink_terracotta
setblock 340 151 465 minecraft:red_nether_bricks
setblock 340 151 466 minecraft:light[level=12]
setblock 340 151 474 minecraft:light[level=12]
setblock 340 151 482 minecraft:light[level=12]
setblock 340 151 490 minecraft:light[level=12]
setblock 340 151 498 minecraft:light[level=12]
setblock 341 151 464 minecraft:red_nether_bricks
setblock 341 151 465 minecraft:pink_terracotta
setblock 341 151 504 minecraft:red_nether_bricks
fill 342 151 464 342 152 464 minecraft:pink_terracotta
setblock 342 151 503 minecraft:red_nether_bricks
fill 342 151 504 342 154 504 minecraft:pink_terracotta
setblock 348 151 466 minecraft:light[level=12]
setblock 348 151 474 minecraft:light[level=12]
setblock 348 151 482 minecraft:light[level=12]
setblock 348 151 490 minecraft:light[level=12]
setblock 348 151 498 minecraft:light[level=12]
setblock 356 151 464 minecraft:red_nether_bricks
setblock 356 151 466 minecraft:light[level=12]
setblock 356 151 474 minecraft:light[level=12]
setblock 356 151 482 minecraft:light[level=12]
setblock 356 151 490 minecraft:light[level=12]
setblock 356 151 498 minecraft:light[level=12]
fill 357 151 464 357 154 464 minecraft:pink_terracotta
setblock 357 151 504 minecraft:pink_terracotta
setblock 360 151 465 minecraft:red_nether_bricks
setblock 361 151 464 minecraft:red_nether_bricks
fill 361 151 465 361 152 465 minecraft:pink_terracotta
fill 362 151 464 362 153 464 minecraft:pink_terracotta
setblock 362 151 504 minecraft:white_concrete
setblock 364 151 466 minecraft:light[level=12]
setblock 364 151 474 minecraft:light[level=12]
setblock 364 151 482 minecraft:light[level=12]
setblock 364 151 490 minecraft:light[level=12]
setblock 364 151 498 minecraft:light[level=12]
setblock 366 151 464 minecraft:red_nether_bricks
setblock 367 151 464 minecraft:pink_terracotta
fill 368 151 470 368 151 471 minecraft:pink_terracotta
setblock 368 151 472 minecraft:red_nether_bricks
fill 368 151 473 368 152 473 minecraft:pink_terracotta
setblock 369 151 466 minecraft:red_nether_bricks
fill 369 151 467 369 152 467 minecraft:pink_terracotta
setblock 369 151 471 minecraft:red_nether_bricks
fill 369 151 472 369 154 472 minecraft:pink_terracotta
setblock 369 151 476 minecraft:red_nether_bricks
setblock 370 151 465 minecraft:red_nether_bricks
fill 370 151 466 370 154 466 minecraft:pink_terracotta
setblock 370 151 470 minecraft:red_nether_bricks
fill 370 151 471 370 154 471 minecraft:pink_terracotta
setblock 370 151 475 minecraft:red_nether_bricks
fill 370 151 476 370 154 476 minecraft:pink_terracotta
setblock 370 151 491 minecraft:pink_terracotta
setblock 370 151 494 minecraft:pink_terracotta
setblock 370 151 495 minecraft:white_concrete
setblock 330 152 464 minecraft:red_nether_bricks
fill 330 152 465 330 154 465 minecraft:pink_terracotta
setblock 330 152 469 minecraft:red_nether_bricks
fill 330 152 470 331 154 470 minecraft:pink_terracotta
setblock 330 152 474 minecraft:red_nether_bricks
fill 330 152 475 330 155 475 minecraft:pink_terracotta
setblock 330 152 479 minecraft:white_concrete
setblock 330 152 493 minecraft:pink_terracotta
setblock 330 152 494 minecraft:red_nether_bricks
fill 330 152 495 330 155 495 minecraft:pink_terracotta
setblock 330 152 498 minecraft:pink_terracotta
setblock 330 152 499 minecraft:red_nether_bricks
fill 330 152 500 330 153 502 minecraft:pink_terracotta
fill 331 152 464 331 155 464 minecraft:pink_terracotta
setblock 331 152 468 minecraft:red_nether_bricks
fill 331 152 469 331 154 469 minecraft:pink_terracotta
setblock 331 152 473 minecraft:red_nether_bricks
fill 331 152 474 331 154 474 minecraft:pink_terracotta
setblock 331 152 493 minecraft:red_nether_bricks
fill 331 152 494 331 155 494 minecraft:pink_terracotta
fill 331 152 496 331 152 497 minecraft:pink_terracotta
setblock 331 152 498 minecraft:red_nether_bricks
fill 331 152 504 331 155 504 minecraft:pink_terracotta
fill 333 152 503 333 154 503 minecraft:pink_terracotta
setblock 334 152 465 minecraft:red_nether_bricks
setblock 335 152 464 minecraft:red_nether_bricks
fill 335 152 465 335 154 465 minecraft:pink_terracotta
setblock 335 152 504 minecraft:red_nether_bricks
fill 336 152 464 336 155 464 minecraft:pink_terracotta
setblock 336 152 502 minecraft:pink_terracotta
setblock 336 152 503 minecraft:red_nether_bricks
fill 336 152 504 336 155 504 minecraft:pink_terracotta
setblock 337 152 502 minecraft:red_nether_bricks
fill 337 152 503 337 155 503 minecraft:pink_terracotta
fill 338 152 502 338 155 502 minecraft:pink_terracotta
setblock 339 152 465 minecraft:red_nether_bricks
setblock 340 152 464 minecraft:red_nether_bricks
setblock 340 152 465 minecraft:pink_terracotta
setblock 340 152 504 minecraft:red_nether_bricks
fill 341 152 464 341 153 464 minecraft:pink_terracotta
setblock 341 152 503 minecraft:red_nether_bricks
fill 341 152 504 341 155 504 minecraft:pink_terracotta
setblock 342 152 503 minecraft:pink_terracotta
setblock 349 152 504 minecraft:white_concrete
setblock 351 152 464 minecraft:white_concrete
setblock 355 152 464 minecraft:red_nether_bricks
fill 356 152 464 356 153 464 minecraft:pink_terracotta
setblock 359 152 465 minecraft:red_nether_bricks
setblock 360 152 464 minecraft:red_nether_bricks
setblock 360 152 465 minecraft:pink_terracotta
fill 361 152 464 361 153 464 minecraft:pink_terracotta
setblock 368 152 471 minecraft:red_nether_bricks
setblock 368 152 472 minecraft:pink_terracotta
setblock 368 152 504 minecraft:white_concrete
setblock 369 152 470 minecraft:red_nether_bricks
fill 369 152 471 369 155 471 minecraft:pink_terracotta
setblock 369 152 474 minecraft:pink_terracotta
setblock 369 152 475 minecraft:red_nether_bricks
fill 369 152 476 369 155 476 minecraft:pink_terracotta
setblock 370 152 464 minecraft:red_nether_bricks
fill 370 152 465 370 155 465 minecraft:pink_terracotta
setblock 370 152 469 minecraft:red_nether_bricks
fill 370 152 470 370 155 470 minecraft:pink_terracotta
setblock 370 152 474 minecraft:red_nether_bricks
fill 370 152 475 370 155 475 minecraft:pink_terracotta
setblock 370 152 489 minecraft:white_concrete
setblock 370 152 494 minecraft:red_nether_bricks
fill 370 152 495 370 155 495 minecraft:pink_terracotta
fill 330 153 464 330 154 464 minecraft:pink_terracotta
setblock 330 153 468 minecraft:red_nether_bricks
fill 330 153 469 330 156 469 minecraft:pink_terracotta
setblock 330 153 473 minecraft:red_nether_bricks
fill 330 153 474 330 156 474 minecraft:pink_terracotta
setblock 330 153 485 minecraft:white_concrete
setblock 330 153 493 minecraft:red_nether_bricks
fill 330 153 494 330 156 494 minecraft:pink_terracotta
setblock 330 153 498 minecraft:red_nether_bricks
fill 330 153 499 331 155 499 minecraft:pink_terracotta
setblock 330 153 503 minecraft:red_nether_bricks
fill 330 153 504 330 156 504 minecraft:pink_terracotta
setblock 331 153 467 minecraft:red_nether_bricks
setblock 331 153 468 minecraft:pink_terracotta
setblock 331 153 472 minecraft:red_nether_bricks
fill 331 153 473 331 155 473 minecraft:pink_terracotta
fill 331 153 493 331 155 493 minecraft:pink_terracotta
setblock 331 153 496 minecraft:pink_terracotta
setblock 331 153 497 minecraft:red_nether_bricks
fill 331 153 498 331 156 498 minecraft:pink_terracotta
setblock 333 153 465 minecraft:red_nether_bricks
setblock 334 153 464 minecraft:red_nether_bricks
setblock 334 153 465 minecraft:pink_terracotta
setblock 334 153 504 minecraft:red_nether_bricks
fill 335 153 464 335 156 464 minecraft:pink_terracotta
setblock 335 153 502 minecraft:pink_terracotta
setblock 335 153 503 minecraft:red_nether_bricks
fill 335 153 504 335 156 504 minecraft:pink_terracotta
setblock 336 153 502 minecraft:red_nether_bricks
fill 336 153 503 336 156 503 minecraft:pink_terracotta
fill 337 153 502 337 156 502 minecraft:pink_terracotta
setblock 338 153 465 minecraft:red_nether_bricks
setblock 339 153 464 minecraft:red_nether_bricks
setblock 339 153 504 minecraft:red_nether_bricks
setblock 340 153 464 minecraft:pink_terracotta
setblock 340 153 503 minecraft:red_nether_bricks
fill 340 153 504 340 156 504 minecraft:pink_terracotta
setblock 341 153 503 minecraft:pink_terracotta
setblock 345 153 464 minecraft:white_concrete
setblock 355 153 504 minecraft:white_concrete
setblock 359 153 464 minecraft:red_nether_bricks
fill 360 153 464 360 154 464 minecraft:pink_terracotta
setblock 369 153 469 minecraft:red_nether_bricks
fill 369 153 470 369 155 470 minecraft:pink_terracotta
setblock 369 153 474 minecraft:red_nether_bricks
fill 369 153 475 369 156 475 minecraft:pink_terracotta
setblock 370 153 464 minecraft:pink_terracotta
setblock 370 153 468 minecraft:red_nether_bricks
fill 370 153 469 370 156 469 minecraft:pink_terracotta
setblock 370 153 473 minecraft:red_nether_bricks
fill 370 153 474 370 156 474 minecraft:pink_terracotta
setblock 370 153 477 minecraft:pink_terracotta
setblock 370 153 478 minecraft:red_nether_bricks
setblock 370 153 483 minecraft:white_concrete
setblock 370 153 494 minecraft:pink_terracotta
fill 370 153 496 370 154 496 minecraft:pink_terracotta
setblock 330 154 467 minecraft:red_nether_bricks
fill 330 154 468 330 155 468 minecraft:pink_terracotta
setblock 330 154 472 minecraft:red_nether_bricks
fill 330 154 473 330 157 473 minecraft:pink_terracotta
setblock 330 154 491 minecraft:white_concrete
setblock 330 154 492 minecraft:red_nether_bricks
fill 330 154 493 330 157 493 minecraft:pink_terracotta
setblock 330 154 497 minecraft:red_nether_bricks
fill 330 154 498 330 157 498 minecraft:pink_terracotta
fill 330 154 500 330 154 501 minecraft:pink_terracotta
setblock 330 154 502 minecraft:red_nether_bricks
fill 330 154 503 330 157 503 minecraft:pink_terracotta
setblock 331 154 471 minecraft:red_nether_bricks
fill 331 154 472 331 155 472 minecraft:pink_terracotta
setblock 331 154 496 minecraft:red_nether_bricks
fill 331 154 497 332 156 497 minecraft:pink_terracotta
setblock 331 154 500 minecraft:pink_terracotta
setblock 331 154 501 minecraft:red_nether_bricks
setblock 332 154 495 minecraft:red_nether_bricks
fill 332 154 496 332 157 496 minecraft:pink_terracotta
fill 332 154 498 332 155 498 minecraft:pink_terracotta
fill 332 154 503 332 155 503 minecraft:pink_terracotta
setblock 333 154 464 minecraft:red_nether_bricks
setblock 333 154 504 minecraft:red_nether_bricks
fill 334 154 464 334 157 464 minecraft:pink_terracotta
setblock 334 154 503 minecraft:red_nether_bricks
fill 334 154 504 334 157 504 minecraft:pink_terracotta
setblock 335 154 502 minecraft:red_nether_bricks
fill 335 154 503 335 157 503 minecraft:pink_terracotta
fill 336 154 502 336 157 502 minecraft:pink_terracotta
setblock 338 154 464 minecraft:red_nether_bricks
setblock 338 154 504 minecraft:red_nether_bricks
setblock 339 154 464 minecraft:pink_terracotta
setblock 339 154 503 minecraft:red_nether_bricks
fill 339 154 504 339 157 504 minecraft:pink_terracotta
setblock 340 154 503 minecraft:pink_terracotta
fill 342 154 487 342 155 489 minecraft:white_concrete
fill 343 154 486 345 154 486 minecraft:white_concrete
fill 343 154 490 345 154 490 minecraft:white_concrete
fill 345 154 487 346 154 487 minecraft:white_concrete
fill 345 154 489 346 154 489 minecraft:white_concrete
setblock 346 154 488 minecraft:white_concrete
setblock 358 154 464 minecraft:red_nether_bricks
setblock 359 154 464 minecraft:pink_terracotta
setblock 361 154 504 minecraft:white_concrete
setblock 364 154 464 minecraft:white_concrete
setblock 369 154 469 minecraft:pink_terracotta
setblock 369 154 473 minecraft:red_nether_bricks
fill 369 154 474 369 157 474 minecraft:pink_terracotta
setblock 370 154 467 minecraft:red_nether_bricks
fill 370 154 468 370 157 468 minecraft:pink_terracotta
setblock 370 154 472 minecraft:red_nether_bricks
fill 370 154 473 370 157 473 minecraft:pink_terracotta
setblock 370 154 477 minecraft:red_nether_bricks
fill 370 154 478 370 157 478 minecraft:pink_terracotta
setblock 370 154 502 minecraft:white_concrete
setblock 330 155 467 minecraft:pink_terracotta
setblock 330 155 470 minecraft:pink_terracotta
setblock 330 155 471 minecraft:red_nether_bricks
fill 330 155 472 330 157 472 minecraft:pink_terracotta
setblock 330 155 476 minecraft:red_nether_bricks
fill 330 155 492 330 156 492 minecraft:pink_terracotta
setblock 330 155 496 minecraft:red_nether_bricks
fill 330 155 497 330 157 497 minecraft:pink_terracotta
setblock 330 155 500 minecraft:pink_terracotta
setblock 330 155 501 minecraft:red_nether_bricks
fill 330 155 502 331 157 502 minecraft:pink_terracotta
setblock 331 155 495 minecraft:red_nether_bricks
fill 331 155 496 331 157 496 minecraft:pink_terracotta
setblock 331 155 500 minecraft:red_nether_bricks
fill 331 155 501 331 157 501 minecraft:pink_terracotta
setblock 332 155 464 minecraft:red_nether_bricks
fill 332 155 495 332 157 495 minecraft:pink_terracotta
setblock 332 155 499 minecraft:red_nether_bricks
setblock 332 155 504 minecraft:red_nether_bricks
fill 333 155 464 333 157 464 minecraft:pink_terracotta
setblock 333 155 503 minecraft:red_nether_bricks
fill 333 155 504 333 157 504 minecraft:pink_terracotta
setblock 334 155 502 minecraft:red_nether_bricks
fill 334 155 503 334 157 503 minecraft:pink_terracotta
fill 335 155 502 335 157 502 minecraft:pink_terracotta
setblock 337 155 464 minecraft:red_nether_bricks
setblock 337 155 504 minecraft:red_nether_bricks
setblock 338 155 464 minecraft:pink_terracotta
setblock 338 155 503 minecraft:red_nether_bricks
fill 338 155 504 338 157 504 minecraft:pink_terracotta
fill 339 155 503 339 157 503 minecraft:pink_terracotta
setblock 342 155 504 minecraft:white_concrete
fill 343 155 486 344 155 486 minecraft:white_concrete
fill 343 155 490 344 155 490 minecraft:white_concrete
fill 345 155 487 345 156 487 minecraft:white_concrete
fill 345 155 489 345 156 489 minecraft:white_concrete
setblock 352 155 464 minecraft:white_concrete
setblock 358 155 464 minecraft:white_concrete
setblock 367 155 504 minecraft:white_concrete
setblock 369 155 472 minecraft:red_nether_bricks
fill 369 155 473 369 157 473 minecraft:pink_terracotta
setblock 370 155 466 minecraft:red_nether_bricks
fill 370 155 467 370 157 467 minecraft:pink_terracotta
setblock 370 155 471 minecraft:red_nether_bricks
fill 370 155 472 370 157 472 minecraft:pink_terracotta
setblock 370 155 476 minecraft:red_nether_bricks
fill 370 155 477 370 157 477 minecraft:pink_terracotta
fill 370 155 479 370 156 479 minecraft:pink_terracotta
fill 370 155 490 370 156 490 minecraft:white_concrete
setblock 370 155 496 minecraft:red_nether_bricks
fill 370 155 497 370 157 498 minecraft:pink_terracotta
setblock 330 156 470 minecraft:red_nether_bricks
fill 330 156 471 330 157 471 minecraft:pink_terracotta
setblock 330 156 475 minecraft:red_nether_bricks
fill 330 156 476 330 157 477 minecraft:pink_terracotta
setblock 330 156 478 minecraft:white_concrete
setblock 330 156 495 minecraft:red_nether_bricks
fill 330 156 496 330 157 496 minecraft:pink_terracotta
setblock 330 156 499 minecraft:pink_terracotta
setblock 330 156 500 minecraft:red_nether_bricks
fill 330 156 501 330 157 501 minecraft:pink_terracotta
setblock 331 156 494 minecraft:red_nether_bricks
fill 331 156 495 331 157 495 minecraft:pink_terracotta
setblock 331 156 499 minecraft:red_nether_bricks
fill 331 156 500 332 157 500 minecraft:pink_terracotta
setblock 331 156 503 minecraft:pink_terracotta
setblock 331 156 504 minecraft:red_nether_bricks
fill 332 156 464 332 157 464 minecraft:pink_terracotta
setblock 332 156 498 minecraft:red_nether_bricks
fill 332 156 499 332 157 499 minecraft:pink_terracotta
setblock 332 156 503 minecraft:red_nether_bricks
fill 332 156 504 332 157 504 minecraft:pink_terracotta
fill 333 156 503 333 157 503 minecraft:pink_terracotta
fill 334 156 502 334 157 502 minecraft:pink_terracotta
setblock 336 156 464 minecraft:red_nether_bricks
setblock 336 156 504 minecraft:red_nether_bricks
setblock 337 156 503 minecraft:red_nether_bricks
fill 337 156 504 337 157 504 minecraft:pink_terracotta
fill 338 156 503 338 157 503 minecraft:pink_terracotta
setblock 342 156 488 minecraft:white_concrete
setblock 346 156 464 minecraft:white_concrete
setblock 348 156 504 minecraft:white_concrete
fill 350 156 502 351 157 502 minecraft:red_concrete
fill 351 156 501 351 157 501 minecraft:red_concrete
fill 351 156 503 351 157 503 minecraft:red_concrete
fill 354 156 504 354 157 504 minecraft:white_concrete
setblock 369 156 471 minecraft:red_nether_bricks
fill 369 156 472 369 157 472 minecraft:pink_terracotta
setblock 369 156 476 minecraft:red_nether_bricks
setblock 370 156 465 minecraft:white_concrete
fill 370 156 466 370 157 466 minecraft:pink_terracotta
setblock 370 156 470 minecraft:red_nether_bricks
fill 370 156 471 370 157 471 minecraft:pink_terracotta
setblock 370 156 475 minecraft:red_nether_bricks
fill 370 156 476 370 157 476 minecraft:pink_terracotta
setblock 370 156 484 minecraft:white_concrete
fill 370 156 496 370 157 496 minecraft:pink_terracotta
setblock 370 156 499 minecraft:pink_terracotta
setblock 370 156 500 minecraft:red_nether_bricks
setblock 330 157 465 minecraft:white_concrete
setblock 330 157 470 minecraft:pink_terracotta
setblock 330 157 474 minecraft:red_nether_bricks
setblock 330 157 475 minecraft:pink_terracotta
setblock 330 157 484 minecraft:white_concrete
setblock 330 157 490 minecraft:white_concrete
setblock 330 157 494 minecraft:red_nether_bricks
setblock 330 157 495 minecraft:pink_terracotta
setblock 330 157 499 minecraft:red_nether_bricks
setblock 330 157 500 minecraft:pink_terracotta
setblock 330 157 504 minecraft:red_nether_bricks
setblock 331 157 494 minecraft:pink_terracotta
setblock 331 157 497 minecraft:pink_terracotta
setblock 331 157 498 minecraft:red_nether_bricks
setblock 331 157 499 minecraft:pink_terracotta
setblock 331 157 503 minecraft:red_nether_bricks
setblock 331 157 504 minecraft:pink_terracotta
setblock 332 157 497 minecraft:red_nether_bricks
setblock 332 157 498 minecraft:pink_terracotta
setblock 332 157 501 minecraft:pink_terracotta
setblock 332 157 503 minecraft:pink_terracotta
setblock 333 157 502 minecraft:pink_terracotta
setblock 335 157 464 minecraft:red_nether_bricks
setblock 335 157 504 minecraft:red_nether_bricks
setblock 336 157 503 minecraft:red_nether_bricks
setblock 336 157 504 minecraft:pink_terracotta
setblock 337 157 502 minecraft:red_nether_bricks
setblock 337 157 503 minecraft:pink_terracotta
setblock 340 157 464 minecraft:white_concrete
setblock 340 157 504 minecraft:red_nether_bricks
setblock 360 157 504 minecraft:white_concrete
setblock 365 157 464 minecraft:white_concrete
setblock 369 157 475 minecraft:red_nether_bricks
setblock 369 157 476 minecraft:pink_terracotta
setblock 370 157 469 minecraft:red_nether_bricks
setblock 370 157 470 minecraft:pink_terracotta
setblock 370 157 474 minecraft:red_nether_bricks
setblock 370 157 475 minecraft:pink_terracotta
setblock 370 157 479 minecraft:red_nether_bricks
setblock 370 157 499 minecraft:red_nether_bricks
fill 370 157 500 370 157 502 minecraft:pink_terracotta
setblock 370 157 503 minecraft:white_concrete
setblock 332 159 466 minecraft:light[level=12]
setblock 332 159 474 minecraft:light[level=12]
setblock 332 159 482 minecraft:light[level=12]
setblock 332 159 490 minecraft:light[level=12]
setblock 332 159 498 minecraft:light[level=12]
setblock 340 159 466 minecraft:light[level=12]
setblock 340 159 474 minecraft:light[level=12]
setblock 340 159 482 minecraft:light[level=12]
setblock 340 159 490 minecraft:light[level=12]
setblock 340 159 498 minecraft:light[level=12]
setblock 348 159 466 minecraft:light[level=12]
setblock 348 159 474 minecraft:light[level=12]
setblock 348 159 482 minecraft:light[level=12]
setblock 348 159 490 minecraft:light[level=12]
setblock 348 159 498 minecraft:light[level=12]
setblock 356 159 466 minecraft:light[level=12]
setblock 356 159 474 minecraft:light[level=12]
setblock 356 159 482 minecraft:light[level=12]
setblock 356 159 490 minecraft:light[level=12]
setblock 356 159 498 minecraft:light[level=12]
setblock 364 159 466 minecraft:light[level=12]
setblock 364 159 474 minecraft:light[level=12]
setblock 364 159 482 minecraft:light[level=12]
setblock 364 159 490 minecraft:light[level=12]
setblock 364 159 498 minecraft:light[level=12]
fill 346 162 481 346 162 487 minecraft:pink_concrete
fill 347 162 480 347 162 483 minecraft:pink_concrete
fill 347 162 485 347 162 488 minecraft:pink_concrete
fill 348 162 479 350 162 481 minecraft:redstone_block
fill 348 162 487 350 162 489 minecraft:redstone_block
fill 349 162 478 355 162 478 minecraft:pink_concrete
fill 349 162 490 355 162 490 minecraft:pink_concrete
setblock 351 162 479 minecraft:pink_concrete
setblock 351 162 489 minecraft:pink_concrete
fill 353 162 479 356 162 479 minecraft:pink_concrete
fill 353 162 489 356 162 489 minecraft:pink_concrete
fill 356 162 480 357 162 480 minecraft:pink_concrete
fill 356 162 483 358 162 485 minecraft:redstone_block
fill 356 162 488 357 162 488 minecraft:pink_concrete
fill 357 162 481 358 162 482 minecraft:pink_concrete
fill 357 162 486 358 162 487 minecraft:pink_concrete
fill 345 163 481 345 165 487 minecraft:pink_concrete
fill 346 163 479 346 165 483 minecraft:pink_concrete
fill 346 163 484 350 163 484 minecraft:red_terracotta
fill 346 163 485 346 165 489 minecraft:pink_concrete
fill 347 163 478 347 163 480 minecraft:pink_concrete
fill 347 163 481 347 163 483 minecraft:red_terracotta
fill 347 163 485 347 163 487 minecraft:red_terracotta
fill 347 163 488 347 163 490 minecraft:pink_concrete
fill 348 163 478 351 163 478 minecraft:pink_concrete
fill 348 163 482 350 163 483 minecraft:red_terracotta
fill 348 163 485 350 163 486 minecraft:red_terracotta
fill 348 163 490 351 163 490 minecraft:pink_concrete
fill 349 163 477 355 165 477 minecraft:pink_concrete
fill 349 163 491 355 165 491 minecraft:pink_concrete
fill 351 163 479 355 163 482 minecraft:red_terracotta
fill 351 163 486 355 163 489 minecraft:red_terracotta
fill 352 163 478 352 164 478 minecraft:red_terracotta
fill 352 163 490 352 164 490 minecraft:red_terracotta
fill 353 163 478 357 165 478 minecraft:pink_concrete
fill 353 163 490 357 165 490 minecraft:pink_concrete
fill 354 163 483 355 163 485 minecraft:red_terracotta
fill 356 163 479 358 165 479 minecraft:pink_concrete
fill 356 163 480 356 163 482 minecraft:red_terracotta
fill 356 163 486 356 163 488 minecraft:red_terracotta
fill 356 163 489 358 165 489 minecraft:pink_concrete
fill 357 163 480 358 165 480 minecraft:pink_concrete
fill 357 163 481 357 163 482 minecraft:red_terracotta
fill 357 163 486 357 163 487 minecraft:red_terracotta
fill 357 163 488 358 165 488 minecraft:pink_concrete
fill 358 163 481 359 163 482 minecraft:pink_concrete
fill 358 163 486 359 163 487 minecraft:pink_concrete
fill 359 163 483 359 163 485 minecraft:pink_concrete
fill 330 164 464 343 164 504 minecraft:red_terracotta
fill 344 164 464 344 164 482 minecraft:red_terracotta
fill 344 164 483 344 164 485 minecraft:pink_concrete
fill 344 164 486 344 164 504 minecraft:red_terracotta
fill 345 164 464 345 164 479 minecraft:red_terracotta
setblock 345 164 480 minecraft:pink_concrete
setblock 345 164 488 minecraft:pink_concrete
fill 345 164 489 345 164 504 minecraft:red_terracotta
fill 346 164 464 346 164 478 minecraft:red_terracotta
fill 346 164 484 349 164 484 minecraft:red_terracotta
fill 346 164 490 346 164 504 minecraft:red_terracotta
fill 347 164 464 347 164 477 minecraft:red_terracotta
fill 347 164 478 347 164 482 minecraft:shroomlight
fill 347 164 483 349 164 483 minecraft:red_terracotta
fill 347 164 485 349 164 485 minecraft:red_terracotta
fill 347 164 486 347 164 490 minecraft:shroomlight
fill 347 164 491 347 164 504 minecraft:red_terracotta
fill 348 164 464 350 164 476 minecraft:red_terracotta
setblock 348 164 477 minecraft:pink_concrete
fill 348 164 478 351 164 478 minecraft:shroomlight
fill 348 164 479 350 164 481 minecraft:red_terracotta
fill 348 164 482 350 164 482 minecraft:shroomlight
fill 348 164 486 350 164 486 minecraft:shroomlight
fill 348 164 487 350 164 489 minecraft:red_terracotta
fill 348 164 490 351 164 490 minecraft:shroomlight
setblock 348 164 491 minecraft:pink_concrete
fill 348 164 492 350 164 504 minecraft:red_terracotta
fill 350 164 483 350 164 485 minecraft:ochre_froglight
fill 351 164 464 370 164 475 minecraft:red_terracotta
fill 351 164 476 353 164 476 minecraft:pink_concrete
fill 351 164 479 351 164 481 minecraft:shroomlight
fill 351 164 482 353 164 482 minecraft:ochre_froglight
fill 351 164 486 353 164 486 minecraft:ochre_froglight
fill 351 164 487 351 164 489 minecraft:shroomlight
fill 351 164 492 353 164 492 minecraft:pink_concrete
fill 351 164 493 370 164 504 minecraft:red_terracotta
fill 352 164 479 355 164 481 minecraft:red_terracotta
fill 352 164 487 355 164 489 minecraft:red_terracotta
fill 354 164 476 370 164 476 minecraft:red_terracotta
fill 354 164 482 359 164 482 minecraft:shroomlight
fill 354 164 483 354 164 485 minecraft:ochre_froglight
fill 354 164 486 359 164 486 minecraft:shroomlight
fill 354 164 492 370 164 492 minecraft:red_terracotta
fill 355 164 483 355 164 485 minecraft:shroomlight
setblock 356 164 477 minecraft:pink_concrete
fill 356 164 480 356 164 481 minecraft:red_terracotta
fill 356 164 483 358 164 485 minecraft:red_terracotta
fill 356 164 487 356 164 488 minecraft:red_terracotta
setblock 356 164 491 minecraft:pink_concrete
fill 357 164 477 370 164 477 minecraft:red_terracotta
setblock 357 164 481 minecraft:red_terracotta
setblock 357 164 487 minecraft:red_terracotta
fill 357 164 491 370 164 491 minecraft:red_terracotta
fill 358 164 478 370 164 478 minecraft:red_terracotta
fill 358 164 481 359 165 481 minecraft:pink_concrete
fill 358 164 487 359 165 487 minecraft:pink_concrete
fill 358 164 490 370 164 490 minecraft:red_terracotta
fill 359 164 479 370 164 479 minecraft:red_terracotta
setblock 359 164 480 minecraft:pink_concrete
fill 359 164 483 359 164 485 minecraft:shroomlight
setblock 359 164 488 minecraft:pink_concrete
fill 359 164 489 370 164 489 minecraft:red_terracotta
fill 360 164 480 370 164 482 minecraft:red_terracotta
fill 360 164 483 360 164 485 minecraft:pink_concrete
fill 360 164 486 370 164 488 minecraft:red_terracotta
fill 361 164 483 370 164 485 minecraft:red_terracotta
fill 343 165 475 343 166 475 minecraft:bone_block
fill 343 165 484 343 175 484 minecraft:bone_block
fill 343 165 493 343 166 493 minecraft:bone_block
fill 346 165 475 346 166 475 minecraft:bone_block
fill 346 165 484 346 171 484 minecraft:bone_block
fill 346 165 493 346 166 493 minecraft:bone_block
fill 347 165 478 347 165 490 minecraft:pink_concrete
fill 348 165 478 348 165 483 minecraft:pink_concrete
fill 348 165 485 348 165 490 minecraft:pink_concrete
fill 349 165 475 349 166 475 minecraft:bone_block
fill 349 165 478 349 165 481 minecraft:pink_concrete
fill 349 165 484 349 171 484 minecraft:bone_block
fill 349 165 487 349 165 490 minecraft:pink_concrete
fill 349 165 493 349 166 493 minecraft:bone_block
fill 350 165 478 351 165 480 minecraft:pink_concrete
fill 350 165 488 351 165 490 minecraft:pink_concrete
fill 352 165 475 352 166 475 minecraft:bone_block
fill 352 165 478 352 165 479 minecraft:pink_concrete
fill 352 165 489 352 165 490 minecraft:pink_concrete
fill 352 165 493 352 166 493 minecraft:bone_block
fill 353 165 479 355 165 480 minecraft:pink_concrete
fill 353 165 488 355 165 489 minecraft:pink_concrete
fill 355 165 475 355 166 475 minecraft:bone_block
fill 355 165 481 357 165 481 minecraft:pink_concrete
fill 355 165 484 355 171 484 minecraft:bone_block
fill 355 165 487 357 165 487 minecraft:pink_concrete
fill 355 165 493 355 166 493 minecraft:bone_block
fill 356 165 480 356 166 480 minecraft:pink_concrete
fill 356 165 482 359 165 483 minecraft:pink_concrete
fill 356 165 485 359 165 486 minecraft:pink_concrete
fill 356 165 488 356 166 488 minecraft:pink_concrete
setblock 357 165 484 minecraft:pink_concrete
fill 358 165 475 358 166 475 minecraft:bone_block
fill 358 165 484 358 171 484 minecraft:bone_block
fill 358 165 493 358 166 493 minecraft:bone_block
setblock 359 165 484 minecraft:pink_concrete
fill 361 165 475 361 166 475 minecraft:bone_block
fill 361 165 484 361 171 484 minecraft:bone_block
fill 361 165 493 361 166 493 minecraft:bone_block
fill 346 166 481 347 166 483 minecraft:pink_concrete
fill 346 166 485 347 166 487 minecraft:pink_concrete
fill 347 166 480 348 166 480 minecraft:pink_concrete
fill 347 166 488 348 166 488 minecraft:pink_concrete
fill 348 166 479 351 166 479 minecraft:pink_concrete
fill 348 166 489 351 166 489 minecraft:pink_concrete
fill 349 166 478 355 166 478 minecraft:pink_concrete
fill 349 166 490 355 166 490 minecraft:pink_concrete
fill 353 166 479 356 166 479 minecraft:pink_concrete
fill 353 166 489 356 166 489 minecraft:pink_concrete
fill 357 166 480 357 166 483 minecraft:pink_concrete
fill 357 166 485 357 166 488 minecraft:pink_concrete
fill 358 166 481 358 166 483 minecraft:pink_concrete
fill 358 166 485 358 166 487 minecraft:pink_concrete
setblock 332 167 466 minecraft:light[level=12]
setblock 332 167 474 minecraft:light[level=12]
setblock 332 167 482 minecraft:light[level=12]
setblock 332 167 490 minecraft:light[level=12]
setblock 332 167 498 minecraft:light[level=12]
setblock 340 167 466 minecraft:light[level=12]
setblock 340 167 474 minecraft:light[level=12]
setblock 340 167 482 minecraft:light[level=12]
setblock 340 167 490 minecraft:light[level=12]
setblock 340 167 498 minecraft:light[level=12]
fill 343 167 476 343 168 476 minecraft:bone_block
fill 343 167 492 343 168 492 minecraft:bone_block
fill 346 167 476 346 168 476 minecraft:bone_block
fill 346 167 492 346 168 492 minecraft:bone_block
setblock 348 167 466 minecraft:light[level=12]
setblock 348 167 474 minecraft:light[level=12]
setblock 348 167 482 minecraft:light[level=12]
setblock 348 167 490 minecraft:light[level=12]
setblock 348 167 498 minecraft:light[level=12]
fill 349 167 476 349 168 476 minecraft:bone_block
fill 349 167 492 349 168 492 minecraft:bone_block
fill 352 167 476 352 168 476 minecraft:bone_block
fill 352 167 492 352 168 492 minecraft:bone_block
fill 355 167 476 355 168 476 minecraft:bone_block
fill 355 167 492 355 168 492 minecraft:bone_block
setblock 356 167 466 minecraft:light[level=12]
setblock 356 167 474 minecraft:light[level=12]
setblock 356 167 482 minecraft:light[level=12]
setblock 356 167 490 minecraft:light[level=12]
setblock 356 167 498 minecraft:light[level=12]
fill 358 167 476 358 168 476 minecraft:bone_block
fill 358 167 492 358 168 492 minecraft:bone_block
fill 361 167 476 361 168 476 minecraft:bone_block
fill 361 167 492 361 168 492 minecraft:bone_block
setblock 364 167 466 minecraft:light[level=12]
setblock 364 167 474 minecraft:light[level=12]
setblock 364 167 482 minecraft:light[level=12]
setblock 364 167 490 minecraft:light[level=12]
setblock 364 167 498 minecraft:light[level=12]
fill 330 168 464 330 168 467 minecraft:pink_terracotta
setblock 330 168 468 minecraft:red_nether_bricks
fill 330 168 469 330 168 470 minecraft:pink_terracotta
fill 330 168 476 330 168 477 minecraft:pink_terracotta
setblock 330 168 478 minecraft:red_nether_bricks
fill 330 168 479 330 168 482 minecraft:pink_terracotta
setblock 330 168 483 minecraft:red_nether_bricks
fill 330 168 484 330 168 487 minecraft:pink_terracotta
setblock 330 168 488 minecraft:red_nether_bricks
fill 330 168 489 330 168 492 minecraft:pink_terracotta
setblock 330 168 493 minecraft:red_nether_bricks
fill 330 168 494 330 168 497 minecraft:pink_terracotta
setblock 330 168 498 minecraft:red_nether_bricks
fill 330 168 499 330 168 502 minecraft:pink_terracotta
setblock 330 168 503 minecraft:red_nether_bricks
fill 330 168 504 333 168 504 minecraft:pink_terracotta
fill 331 168 464 331 168 466 minecraft:pink_terracotta
fill 331 168 479 331 168 481 minecraft:pink_terracotta
setblock 331 168 482 minecraft:red_nether_bricks
fill 331 168 483 331 168 486 minecraft:pink_terracotta
setblock 331 168 487 minecraft:red_nether_bricks
fill 331 168 488 331 168 491 minecraft:pink_terracotta
setblock 331 168 492 minecraft:red_nether_bricks
fill 331 168 493 331 168 496 minecraft:pink_terracotta
setblock 331 168 497 minecraft:red_nether_bricks
fill 331 168 498 331 168 501 minecraft:pink_terracotta
setblock 331 168 502 minecraft:red_nether_bricks
fill 331 168 503 334 168 503 minecraft:pink_terracotta
fill 332 168 464 332 168 465 minecraft:pink_terracotta
fill 332 168 482 332 168 485 minecraft:pink_terracotta
setblock 332 168 486 minecraft:red_nether_bricks
fill 332 168 487 332 168 489 minecraft:pink_terracotta
fill 332 168 499 332 168 500 minecraft:pink_terracotta
setblock 332 168 501 minecraft:red_nether_bricks
fill 332 168 502 334 168 502 minecraft:pink_terracotta
setblock 333 168 464 minecraft:pink_terracotta
setblock 334 168 464 minecraft:red_nether_bricks
setblock 334 168 504 minecraft:red_nether_bricks
fill 335 168 464 336 168 464 minecraft:pink_terracotta
setblock 335 168 503 minecraft:red_nether_bricks
fill 335 168 504 338 168 504 minecraft:pink_terracotta
setblock 336 168 503 minecraft:pink_terracotta
setblock 337 168 464 minecraft:white_concrete
setblock 339 168 504 minecraft:red_nether_bricks
fill 340 168 504 343 168 504 minecraft:pink_terracotta
setblock 343 168 464 minecraft:pink_terracotta
setblock 344 168 464 minecraft:red_nether_bricks
setblock 344 168 504 minecraft:red_nether_bricks
fill 345 168 464 348 168 464 minecraft:pink_terracotta
setblock 345 168 503 minecraft:red_nether_bricks
fill 345 168 504 348 168 504 minecraft:pink_terracotta
fill 346 168 465 347 168 465 minecraft:pink_terracotta
fill 346 168 503 349 168 503 minecraft:pink_terracotta
setblock 348 168 465 minecraft:red_nether_bricks
setblock 349 168 464 minecraft:red_nether_bricks
fill 349 168 465 351 168 466 minecraft:pink_terracotta
setblock 349 168 504 minecraft:red_nether_bricks
fill 350 168 464 353 168 464 minecraft:pink_terracotta
setblock 350 168 503 minecraft:red_nether_bricks
fill 350 168 504 353 168 504 minecraft:pink_terracotta
fill 351 168 503 353 168 503 minecraft:pink_terracotta
setblock 352 168 465 minecraft:pink_terracotta
setblock 352 168 466 minecraft:red_nether_bricks
setblock 353 168 465 minecraft:red_nether_bricks
setblock 354 168 464 minecraft:red_nether_bricks
fill 354 168 465 357 168 465 minecraft:pink_terracotta
setblock 354 168 504 minecraft:red_nether_bricks
fill 355 168 464 358 168 464 minecraft:pink_terracotta
fill 355 168 504 358 168 504 minecraft:pink_terracotta
setblock 358 168 465 minecraft:red_nether_bricks
setblock 359 168 464 minecraft:red_nether_bricks
fill 359 168 465 362 168 465 minecraft:pink_terracotta
setblock 359 168 504 minecraft:red_nether_bricks
fill 360 168 464 363 168 464 minecraft:pink_terracotta
fill 360 168 468 360 180 468 minecraft:iron_block
fill 360 168 504 363 168 504 minecraft:pink_terracotta
fill 362 168 503 364 168 503 minecraft:pink_terracotta
setblock 363 168 465 minecraft:red_nether_bricks
setblock 364 168 464 minecraft:red_nether_bricks
fill 364 168 465 366 168 466 minecraft:pink_terracotta
setblock 364 168 504 minecraft:red_nether_bricks
fill 365 168 464 368 168 464 minecraft:pink_terracotta
setblock 365 168 502 minecraft:pink_terracotta
setblock 365 168 503 minecraft:red_nether_bricks
fill 365 168 504 368 168 504 minecraft:pink_terracotta
setblock 366 168 502 minecraft:red_nether_bricks
fill 366 168 503 369 168 503 minecraft:pink_terracotta
setblock 367 168 465 minecraft:pink_terracotta
setblock 367 168 466 minecraft:red_nether_bricks
fill 367 168 502 370 168 502 minecraft:pink_terracotta
setblock 368 168 465 minecraft:red_nether_bricks
fill 368 168 466 369 168 468 minecraft:pink_terracotta
setblock 368 168 500 minecraft:red_nether_bricks
fill 368 168 501 370 169 501 minecraft:pink_terracotta
setblock 369 168 464 minecraft:red_nether_bricks
fill 369 168 465 370 170 465 minecraft:pink_terracotta
setblock 369 168 469 minecraft:red_nether_bricks
fill 369 168 470 370 169 470 minecraft:pink_terracotta
setblock 369 168 478 minecraft:pink_terracotta
setblock 369 168 479 minecraft:red_nether_bricks
fill 369 168 480 369 168 483 minecraft:pink_terracotta
setblock 369 168 484 minecraft:red_nether_bricks
fill 369 168 485 369 168 488 minecraft:pink_terracotta
fill 369 168 496 369 168 498 minecraft:pink_terracotta
setblock 369 168 499 minecraft:red_nether_bricks
fill 369 168 500 370 170 500 minecraft:pink_terracotta
setblock 369 168 504 minecraft:red_nether_bricks
fill 370 168 464 370 171 464 minecraft:pink_terracotta
fill 370 168 466 370 168 467 minecraft:pink_terracotta
setblock 370 168 468 minecraft:red_nether_bricks
fill 370 168 469 370 171 469 minecraft:pink_terracotta
fill 370 168 471 370 168 472 minecraft:pink_terracotta
setblock 370 168 473 minecraft:red_nether_bricks
fill 370 168 474 370 168 477 minecraft:pink_terracotta
setblock 370 168 478 minecraft:red_nether_bricks
fill 370 168 479 370 168 482 minecraft:pink_terracotta
setblock 370 168 483 minecraft:red_nether_bricks
fill 370 168 484 370 168 487 minecraft:pink_terracotta
setblock 370 168 488 minecraft:red_nether_bricks
fill 370 168 489 370 168 492 minecraft:pink_terracotta
setblock 370 168 493 minecraft:red_nether_bricks
fill 370 168 494 370 168 497 minecraft:pink_terracotta
setblock 370 168 498 minecraft:red_nether_bricks
fill 370 168 499 370 171 499 minecraft:pink_terracotta
setblock 370 168 503 minecraft:red_nether_bricks
fill 370 168 504 370 171 504 minecraft:pink_terracotta
fill 330 169 464 330 169 466 minecraft:pink_terracotta
setblock 330 169 467 minecraft:red_nether_bricks
fill 330 169 468 330 170 469 minecraft:pink_terracotta
setblock 330 169 474 minecraft:white_concrete
setblock 330 169 477 minecraft:red_nether_bricks
fill 330 169 478 330 169 481 minecraft:pink_terracotta
setblock 330 169 482 minecraft:red_nether_bricks
fill 330 169 483 330 169 486 minecraft:pink_terracotta
setblock 330 169 487 minecraft:red_nether_bricks
fill 330 169 488 330 169 491 minecraft:pink_terracotta
setblock 330 169 492 minecraft:red_nether_bricks
fill 330 169 493 330 169 496 minecraft:pink_terracotta
setblock 330 169 497 minecraft:red_nether_bricks
fill 330 169 498 330 169 501 minecraft:pink_terracotta
setblock 330 169 502 minecraft:red_nether_bricks
fill 330 169 503 332 169 504 minecraft:pink_terracotta
fill 331 169 464 331 169 465 minecraft:pink_terracotta
setblock 331 169 466 minecraft:red_nether_bricks
setblock 331 169 480 minecraft:pink_terracotta
setblock 331 169 481 minecraft:red_nether_bricks
fill 331 169 482 331 169 485 minecraft:pink_terracotta
setblock 331 169 486 minecraft:red_nether_bricks
fill 331 169 487 331 169 490 minecraft:pink_terracotta
setblock 331 169 491 minecraft:red_nether_bricks
fill 331 169 492 331 169 495 minecraft:pink_terracotta
setblock 331 169 496 minecraft:red_nether_bricks
fill 331 169 497 331 169 500 minecraft:pink_terracotta
setblock 331 169 501 minecraft:red_nether_bricks
fill 331 169 502 332 169 502 minecraft:pink_terracotta
setblock 332 169 464 minecraft:pink_terracotta
setblock 332 169 465 minecraft:red_nether_bricks
fill 332 169 483 332 169 484 minecraft:pink_terracotta
setblock 332 169 485 minecraft:red_nether_bricks
fill 332 169 486 332 169 488 minecraft:pink_terracotta
setblock 332 169 501 minecraft:pink_terracotta
setblock 333 169 464 minecraft:red_nether_bricks
setblock 333 169 503 minecraft:pink_terracotta
setblock 333 169 504 minecraft:red_nether_bricks
fill 334 169 464 335 169 464 minecraft:pink_terracotta
setblock 334 169 503 minecraft:red_nether_bricks
fill 334 169 504 337 169 504 minecraft:pink_terracotta
setblock 335 169 503 minecraft:pink_terracotta
fill 338 169 482 339 175 486 minecraft:bone_block
setblock 338 169 504 minecraft:red_nether_bricks
fill 340 169 483 340 176 484 minecraft:bone_block
fill 341 169 484 341 175 484 minecraft:bone_block
setblock 342 169 504 minecraft:pink_terracotta
setblock 343 169 464 minecraft:red_nether_bricks
fill 343 169 477 343 170 477 minecraft:bone_block
fill 343 169 491 343 170 491 minecraft:bone_block
setblock 343 169 504 minecraft:red_nether_bricks
fill 344 169 464 347 169 464 minecraft:pink_terracotta
fill 344 169 504 347 169 504 minecraft:pink_terracotta
fill 345 169 465 346 169 465 minecraft:pink_terracotta
fill 346 169 477 346 170 477 minecraft:bone_block
fill 346 169 491 346 170 491 minecraft:bone_block
fill 346 169 503 348 169 503 minecraft:pink_terracotta
setblock 347 169 465 minecraft:red_nether_bricks
setblock 348 169 464 minecraft:red_nether_bricks
fill 348 169 465 351 169 465 minecraft:pink_terracotta
setblock 348 169 504 minecraft:red_nether_bricks
fill 349 169 464 352 169 464 minecraft:pink_terracotta
fill 349 169 466 350 169 466 minecraft:pink_terracotta
fill 349 169 477 349 170 477 minecraft:bone_block
fill 349 169 491 349 170 491 minecraft:bone_block
setblock 349 169 503 minecraft:red_nether_bricks
fill 349 169 504 352 169 504 minecraft:pink_terracotta
fill 350 169 503 351 169 503 minecraft:pink_terracotta
setblock 351 169 466 minecraft:red_nether_bricks
setblock 352 169 465 minecraft:red_nether_bricks
setblock 352 169 466 minecraft:pink_terracotta
fill 352 169 477 352 170 477 minecraft:bone_block
fill 352 169 491 352 170 491 minecraft:bone_block
setblock 353 169 464 minecraft:red_nether_bricks
fill 353 169 465 356 169 465 minecraft:pink_terracotta
setblock 353 169 504 minecraft:red_nether_bricks
fill 354 169 464 357 169 464 minecraft:pink_terracotta
fill 354 169 504 357 169 504 minecraft:pink_terracotta
fill 355 169 477 355 170 477 minecraft:bone_block
fill 355 169 491 355 170 491 minecraft:bone_block
setblock 357 169 465 minecraft:red_nether_bricks
setblock 358 169 464 minecraft:red_nether_bricks
fill 358 169 465 361 169 465 minecraft:pink_terracotta
fill 358 169 477 358 170 477 minecraft:bone_block
fill 358 169 491 358 170 491 minecraft:bone_block
setblock 358 169 504 minecraft:red_nether_bricks
fill 359 169 464 362 169 464 minecraft:pink_terracotta
fill 359 169 504 362 169 504 minecraft:pink_terracotta
fill 361 169 477 361 170 477 minecraft:bone_block
fill 361 169 491 361 170 491 minecraft:bone_block
setblock 362 169 465 minecraft:red_nether_bricks
setblock 363 169 464 minecraft:red_nether_bricks
fill 363 169 465 366 169 465 minecraft:pink_terracotta
setblock 363 169 503 minecraft:pink_terracotta
setblock 363 169 504 minecraft:red_nether_bricks
fill 364 169 464 367 169 464 minecraft:pink_terracotta
fill 364 169 466 365 169 466 minecraft:pink_terracotta
setblock 364 169 503 minecraft:red_nether_bricks
fill 364 169 504 367 169 504 minecraft:pink_terracotta
fill 365 169 503 368 169 503 minecraft:pink_terracotta
setblock 366 169 466 minecraft:red_nether_bricks
fill 366 169 502 369 169 502 minecraft:pink_terracotta
setblock 367 169 465 minecraft:red_nether_bricks
fill 367 169 466 370 169 466 minecraft:pink_terracotta
setblock 368 169 464 minecraft:red_nether_bricks
fill 368 169 465 368 172 465 minecraft:pink_terracotta
fill 368 169 467 368 169 468 minecraft:pink_terracotta
setblock 368 169 500 minecraft:pink_terracotta
setblock 368 169 504 minecraft:red_nether_bricks
fill 369 169 464 369 172 464 minecraft:pink_terracotta
setblock 369 169 467 minecraft:pink_terracotta
setblock 369 169 468 minecraft:red_nether_bricks
fill 369 169 469 369 172 469 minecraft:pink_terracotta
fill 369 169 480 369 169 482 minecraft:pink_terracotta
setblock 369 169 483 minecraft:red_nether_bricks
fill 369 169 484 369 169 487 minecraft:pink_terracotta
setblock 369 169 488 minecraft:red_nether_bricks
fill 369 169 489 370 171 489 minecraft:pink_terracotta
setblock 369 169 497 minecraft:pink_terracotta
setblock 369 169 498 minecraft:red_nether_bricks
fill 369 169 499 369 171 499 minecraft:pink_terracotta
setblock 369 169 503 minecraft:red_nether_bricks
fill 369 169 504 369 172 504 minecraft:pink_terracotta
setblock 370 169 467 minecraft:red_nether_bricks
fill 370 169 468 370 172 468 minecraft:pink_terracotta
setblock 370 169 471 minecraft:pink_terracotta
setblock 370 169 472 minecraft:red_nether_bricks
setblock 370 169 477 minecraft:red_nether_bricks
fill 370 169 478 370 169 481 minecraft:pink_terracotta
setblock 370 169 482 minecraft:red_nether_bricks
fill 370 169 483 370 169 486 minecraft:pink_terracotta
setblock 370 169 487 minecraft:red_nether_bricks
fill 370 169 488 370 172 488 minecraft:pink_terracotta
fill 370 169 490 370 169 491 minecraft:pink_terracotta
setblock 370 169 492 minecraft:red_nether_bricks
fill 370 169 493 370 169 496 minecraft:pink_terracotta
setblock 370 169 497 minecraft:red_nether_bricks
fill 370 169 498 370 172 498 minecraft:pink_terracotta
setblock 370 169 502 minecraft:red_nether_bricks
fill 370 169 503 370 172 503 minecraft:pink_terracotta
fill 330 170 464 330 170 465 minecraft:pink_terracotta
setblock 330 170 466 minecraft:red_nether_bricks
fill 330 170 467 330 173 467 minecraft:pink_terracotta
fill 330 170 479 330 170 480 minecraft:pink_terracotta
setblock 330 170 481 minecraft:red_nether_bricks
fill 330 170 482 330 170 485 minecraft:pink_terracotta
setblock 330 170 486 minecraft:red_nether_bricks
fill 330 170 487 330 170 490 minecraft:pink_terracotta
setblock 330 170 491 minecraft:red_nether_bricks
fill 330 170 492 330 170 495 minecraft:pink_terracotta
setblock 330 170 496 minecraft:red_nether_bricks
fill 330 170 497 330 170 500 minecraft:pink_terracotta
setblock 330 170 501 minecraft:red_nether_bricks
fill 330 170 502 331 170 504 minecraft:pink_terracotta
setblock 331 170 464 minecraft:pink_terracotta
setblock 331 170 465 minecraft:red_nether_bricks
fill 331 170 481 331 170 484 minecraft:pink_terracotta
setblock 331 170 485 minecraft:red_nether_bricks
fill 331 170 486 331 170 489 minecraft:pink_terracotta
setblock 331 170 490 minecraft:red_nether_bricks
fill 331 170 491 331 170 494 minecraft:pink_terracotta
fill 331 170 498 331 170 499 minecraft:pink_terracotta
setblock 331 170 500 minecraft:red_nether_bricks
fill 331 170 501 331 171 501 minecraft:pink_terracotta
setblock 332 170 464 minecraft:red_nether_bricks
fill 332 170 485 332 170 487 minecraft:pink_terracotta
setblock 332 170 503 minecraft:pink_terracotta
setblock 332 170 504 minecraft:red_nether_bricks
fill 333 170 464 334 170 464 minecraft:pink_terracotta
setblock 333 170 503 minecraft:red_nether_bricks
fill 333 170 504 336 170 504 minecraft:pink_terracotta
fill 337 170 482 337 174 486 minecraft:bone_block
fill 338 170 481 339 174 481 minecraft:bone_block
fill 338 170 487 339 174 487 minecraft:bone_block
fill 340 170 482 341 175 482 minecraft:bone_block
fill 340 170 485 340 176 486 minecraft:bone_block
fill 341 170 483 342 174 483 minecraft:bone_block
fill 341 170 485 341 176 485 minecraft:bone_block
setblock 342 170 464 minecraft:red_nether_bricks
fill 342 170 484 342 175 484 minecraft:bone_block
fill 343 170 464 346 170 464 minecraft:pink_terracotta
fill 343 170 478 343 172 478 minecraft:bone_block
fill 343 170 490 343 172 490 minecraft:bone_block
fill 343 170 504 346 170 504 minecraft:pink_terracotta
setblock 345 170 465 minecraft:pink_terracotta
setblock 346 170 465 minecraft:red_nether_bricks
fill 346 170 478 346 172 478 minecraft:bone_block
fill 346 170 490 346 172 490 minecraft:bone_block
setblock 347 170 464 minecraft:red_nether_bricks
fill 347 170 465 350 170 465 minecraft:pink_terracotta
setblock 347 170 504 minecraft:red_nether_bricks
fill 348 170 464 351 170 464 minecraft:pink_terracotta
fill 348 170 466 349 170 466 minecraft:pink_terracotta
fill 348 170 504 351 170 504 minecraft:pink_terracotta
fill 349 170 478 349 172 478 minecraft:bone_block
fill 349 170 490 349 172 490 minecraft:bone_block
setblock 350 170 466 minecraft:red_nether_bricks
setblock 351 170 465 minecraft:red_nether_bricks
fill 351 170 466 351 171 466 minecraft:pink_terracotta
setblock 352 170 464 minecraft:red_nether_bricks
fill 352 170 465 355 170 465 minecraft:pink_terracotta
fill 352 170 478 352 172 478 minecraft:bone_block
fill 352 170 490 352 172 490 minecraft:bone_block
setblock 352 170 504 minecraft:red_nether_bricks
fill 353 170 464 356 170 464 minecraft:pink_terracotta
fill 353 170 504 355 170 504 minecraft:pink_terracotta
fill 355 170 478 355 172 478 minecraft:bone_block
fill 355 170 490 355 172 490 minecraft:bone_block
setblock 356 170 465 minecraft:red_nether_bricks
setblock 357 170 464 minecraft:red_nether_bricks
fill 357 170 465 360 170 465 minecraft:pink_terracotta
fill 358 170 464 361 170 464 minecraft:pink_terracotta
fill 358 170 478 358 172 478 minecraft:bone_block
fill 358 170 490 358 172 490 minecraft:bone_block
fill 359 170 504 361 170 504 minecraft:pink_terracotta
setblock 361 170 465 minecraft:red_nether_bricks
fill 361 170 478 361 172 478 minecraft:bone_block
fill 361 170 490 361 172 490 minecraft:bone_block
setblock 362 170 464 minecraft:red_nether_bricks
fill 362 170 465 365 170 465 minecraft:pink_terracotta
setblock 362 170 504 minecraft:red_nether_bricks
fill 363 170 464 366 170 464 minecraft:pink_terracotta
fill 363 170 466 364 170 466 minecraft:pink_terracotta
setblock 363 170 503 minecraft:red_nether_bricks
fill 363 170 504 366 170 504 minecraft:pink_terracotta
fill 364 170 503 367 170 503 minecraft:pink_terracotta
setblock 365 170 466 minecraft:red_nether_bricks
setblock 366 170 465 minecraft:red_nether_bricks
fill 366 170 466 369 170 466 minecraft:pink_terracotta
fill 366 170 502 368 170 502 minecraft:pink_terracotta
setblock 367 170 464 minecraft:red_nether_bricks
fill 367 170 465 367 173 465 minecraft:pink_terracotta
setblock 367 170 504 minecraft:red_nether_bricks
fill 368 170 464 368 173 464 minecraft:pink_terracotta
setblock 368 170 467 minecraft:pink_terracotta
fill 368 170 501 369 170 501 minecraft:pink_terracotta
setblock 368 170 503 minecraft:red_nether_bricks
fill 368 170 504 368 173 504 minecraft:pink_terracotta
setblock 369 170 467 minecraft:red_nether_bricks
fill 369 170 468 369 173 468 minecraft:pink_terracotta
setblock 369 170 482 minecraft:red_nether_bricks
fill 369 170 483 369 170 486 minecraft:pink_terracotta
setblock 369 170 487 minecraft:red_nether_bricks
fill 369 170 488 369 173 488 minecraft:pink_terracotta
setblock 369 170 498 minecraft:pink_terracotta
setblock 369 170 502 minecraft:red_nether_bricks
fill 369 170 503 369 173 503 minecraft:pink_terracotta
setblock 370 170 466 minecraft:red_nether_bricks
fill 370 170 467 370 173 467 minecraft:pink_terracotta
setblock 370 170 470 minecraft:pink_terracotta
setblock 370 170 471 minecraft:red_nether_bricks
fill 370 170 479 370 170 480 minecraft:pink_terracotta
setblock 370 170 481 minecraft:red_nether_bricks
fill 370 170 482 370 170 485 minecraft:pink_terracotta
setblock 370 170 486 minecraft:red_nether_bricks
fill 370 170 487 370 173 487 minecraft:pink_terracotta
setblock 370 170 490 minecraft:pink_terracotta
setblock 370 170 491 minecraft:red_nether_bricks
fill 370 170 492 370 170 495 minecraft:pink_terracotta
setblock 370 170 496 minecraft:red_nether_bricks
fill 370 170 497 370 173 497 minecraft:pink_terracotta
setblock 370 170 501 minecraft:red_nether_bricks
fill 370 170 502 370 173 502 minecraft:pink_terracotta
setblock 330 171 464 minecraft:pink_terracotta
setblock 330 171 465 minecraft:red_nether_bricks
fill 330 171 466 330 174 466 minecraft:pink_terracotta
fill 330 171 468 330 172 468 minecraft:pink_terracotta
setblock 330 171 480 minecraft:red_nether_bricks
fill 330 171 481 330 171 484 minecraft:pink_terracotta
setblock 330 171 485 minecraft:red_nether_bricks
fill 330 171 486 330 171 489 minecraft:pink_terracotta
setblock 330 171 490 minecraft:red_nether_bricks
fill 330 171 491 330 171 494 minecraft:pink_terracotta
setblock 330 171 495 minecraft:red_nether_bricks
fill 330 171 496 330 171 499 minecraft:pink_terracotta
setblock 330 171 500 minecraft:red_nether_bricks
fill 330 171 501 330 171 504 minecraft:pink_terracotta
setblock 331 171 464 minecraft:red_nether_bricks
fill 331 171 482 331 171 483 minecraft:pink_terracotta
setblock 331 171 484 minecraft:red_nether_bricks
fill 331 171 485 331 171 488 minecraft:pink_terracotta
setblock 331 171 489 minecraft:red_nether_bricks
fill 331 171 490 331 171 493 minecraft:pink_terracotta
fill 331 171 502 331 171 503 minecraft:pink_terracotta
setblock 331 171 504 minecraft:red_nether_bricks
fill 332 171 464 333 171 464 minecraft:pink_terracotta
setblock 332 171 503 minecraft:red_nether_bricks
fill 332 171 504 334 171 504 minecraft:pink_terracotta
fill 336 171 482 336 174 485 minecraft:bone_block
fill 337 171 481 337 173 481 minecraft:bone_block
fill 337 171 487 337 173 487 minecraft:bone_block
setblock 337 171 504 minecraft:white_concrete
fill 340 171 481 341 174 481 minecraft:bone_block
fill 340 171 487 340 175 487 minecraft:bone_block
fill 341 171 486 341 175 486 minecraft:bone_block
fill 342 171 464 345 171 464 minecraft:pink_terracotta
fill 342 171 482 342 174 482 minecraft:bone_block
fill 342 171 485 343 174 485 minecraft:bone_block
fill 343 171 483 343 174 483 minecraft:bone_block
setblock 344 171 465 minecraft:pink_terracotta
fill 344 171 504 345 171 504 minecraft:pink_terracotta
setblock 345 171 465 minecraft:red_nether_bricks
setblock 346 171 464 minecraft:red_nether_bricks
fill 346 171 465 349 171 465 minecraft:pink_terracotta
fill 346 171 483 346 174 483 minecraft:bone_block
fill 346 171 485 346 174 485 minecraft:bone_block
setblock 346 171 504 minecraft:red_nether_bricks
fill 347 171 464 350 171 464 minecraft:pink_terracotta
fill 347 171 504 350 171 504 minecraft:pink_terracotta
setblock 348 171 466 minecraft:pink_terracotta
setblock 349 171 466 minecraft:red_nether_bricks
fill 349 171 483 349 174 483 minecraft:bone_block
fill 349 171 485 349 174 485 minecraft:bone_block
setblock 350 171 465 minecraft:red_nether_bricks
fill 350 171 466 350 174 466 minecraft:pink_terracotta
setblock 351 171 464 minecraft:red_nether_bricks
fill 351 171 465 354 171 465 minecraft:pink_terracotta
setblock 351 171 504 minecraft:red_nether_bricks
fill 352 171 464 355 171 464 minecraft:pink_terracotta
fill 352 171 483 352 174 483 minecraft:bone_block
fill 352 171 485 352 174 485 minecraft:bone_block
setblock 352 171 504 minecraft:pink_terracotta
setblock 355 171 465 minecraft:red_nether_bricks
fill 355 171 483 355 174 483 minecraft:bone_block
fill 355 171 485 355 174 485 minecraft:bone_block
setblock 356 171 464 minecraft:red_nether_bricks
fill 356 171 465 359 171 465 minecraft:pink_terracotta
setblock 356 171 504 minecraft:white_concrete
fill 357 171 464 360 171 464 minecraft:pink_terracotta
fill 358 171 483 358 174 483 minecraft:bone_block
fill 358 171 485 358 174 485 minecraft:bone_block
setblock 360 171 465 minecraft:red_nether_bricks
setblock 360 171 504 minecraft:pink_terracotta
setblock 361 171 464 minecraft:red_nether_bricks
fill 361 171 465 364 171 465 minecraft:pink_terracotta
fill 361 171 483 361 174 483 minecraft:bone_block
fill 361 171 485 361 174 485 minecraft:bone_block
setblock 361 171 504 minecraft:red_nether_bricks
fill 362 171 464 365 171 464 minecraft:pink_terracotta
fill 362 171 504 365 171 504 minecraft:pink_terracotta
setblock 363 171 466 minecraft:pink_terracotta
fill 363 171 503 366 171 503 minecraft:pink_terracotta
setblock 364 171 466 minecraft:red_nether_bricks
setblock 365 171 465 minecraft:red_nether_bricks
fill 365 171 466 368 171 466 minecraft:pink_terracotta
setblock 366 171 464 minecraft:red_nether_bricks
fill 366 171 465 366 174 465 minecraft:pink_terracotta
setblock 366 171 504 minecraft:red_nether_bricks
fill 367 171 464 367 174 464 minecraft:pink_terracotta
setblock 367 171 502 minecraft:pink_terracotta
setblock 367 171 503 minecraft:red_nether_bricks
fill 367 171 504 367 174 504 minecraft:pink_terracotta
setblock 368 171 467 minecraft:red_nether_bricks
setblock 368 171 502 minecraft:red_nether_bricks
fill 368 171 503 368 174 503 minecraft:pink_terracotta
setblock 369 171 465 minecraft:pink_terracotta
setblock 369 171 466 minecraft:red_nether_bricks
fill 369 171 467 369 174 467 minecraft:pink_terracotta
fill 369 171 484 369 171 485 minecraft:pink_terracotta
setblock 369 171 486 minecraft:red_nether_bricks
fill 369 171 487 369 174 487 minecraft:pink_terracotta
setblock 369 171 490 minecraft:pink_terracotta
setblock 369 171 500 minecraft:pink_terracotta
setblock 369 171 501 minecraft:red_nether_bricks
fill 369 171 502 369 174 502 minecraft:pink_terracotta
setblock 370 171 465 minecraft:red_nether_bricks
fill 370 171 466 370 174 466 minecraft:pink_terracotta
setblock 370 171 470 minecraft:red_nether_bricks
setblock 370 171 471 minecraft:pink_terracotta
fill 370 171 481 370 171 484 minecraft:pink_terracotta
setblock 370 171 485 minecraft:red_nether_bricks
fill 370 171 486 370 174 486 minecraft:pink_terracotta
setblock 370 171 490 minecraft:red_nether_bricks
fill 370 171 491 370 171 494 minecraft:pink_terracotta
setblock 370 171 495 minecraft:red_nether_bricks
fill 370 171 496 370 174 496 minecraft:pink_terracotta
setblock 370 171 500 minecraft:red_nether_bricks
fill 370 171 501 370 174 501 minecraft:pink_terracotta
setblock 330 172 464 minecraft:red_nether_bricks
fill 330 172 465 330 175 465 minecraft:pink_terracotta
setblock 330 172 473 minecraft:white_concrete
fill 330 172 481 330 172 483 minecraft:pink_terracotta
setblock 330 172 484 minecraft:red_nether_bricks
fill 330 172 485 330 172 488 minecraft:pink_terracotta
setblock 330 172 489 minecraft:red_nether_bricks
fill 330 172 490 330 172 493 minecraft:pink_terracotta
setblock 330 172 494 minecraft:red_nether_bricks
fill 330 172 495 330 172 498 minecraft:pink_terracotta
setblock 330 172 499 minecraft:red_nether_bricks
fill 330 172 500 330 172 503 minecraft:pink_terracotta
setblock 330 172 504 minecraft:red_nether_bricks
fill 331 172 464 332 172 464 minecraft:pink_terracotta
setblock 331 172 483 minecraft:red_nether_bricks
fill 331 172 484 331 172 487 minecraft:pink_terracotta
setblock 331 172 488 minecraft:red_nether_bricks
fill 331 172 489 331 172 492 minecraft:pink_terracotta
setblock 331 172 493 minecraft:red_nether_bricks
fill 331 172 504 333 172 504 minecraft:pink_terracotta
fill 335 172 484 335 173 484 minecraft:bone_block
fill 336 172 486 336 173 486 minecraft:bone_block
setblock 338 172 464 minecraft:white_concrete
setblock 339 172 488 minecraft:bone_block
fill 341 172 487 341 174 487 minecraft:bone_block
fill 342 172 464 344 172 464 minecraft:pink_terracotta
fill 342 172 486 342 174 486 minecraft:bone_block
fill 343 172 479 343 173 479 minecraft:bone_block
fill 343 172 489 343 173 489 minecraft:bone_block
setblock 343 172 504 minecraft:white_concrete
setblock 344 172 465 minecraft:red_nether_bricks
setblock 344 172 504 minecraft:pink_terracotta
setblock 345 172 464 minecraft:red_nether_bricks
fill 345 172 465 348 172 465 minecraft:pink_terracotta
setblock 345 172 504 minecraft:red_nether_bricks
fill 346 172 464 349 172 464 minecraft:pink_terracotta
fill 346 172 479 346 173 479 minecraft:bone_block
fill 346 172 489 346 173 489 minecraft:bone_block
fill 346 172 504 349 172 504 minecraft:pink_terracotta
setblock 347 172 466 minecraft:pink_terracotta
setblock 348 172 466 minecraft:red_nether_bricks
setblock 349 172 465 minecraft:red_nether_bricks
fill 349 172 466 349 175 466 minecraft:pink_terracotta
fill 349 172 479 349 173 479 minecraft:bone_block
fill 349 172 489 349 173 489 minecraft:bone_block
setblock 350 172 464 minecraft:red_nether_bricks
fill 350 172 465 353 172 465 minecraft:pink_terracotta
setblock 350 172 504 minecraft:red_nether_bricks
fill 351 172 464 354 172 464 minecraft:pink_terracotta
setblock 351 172 504 minecraft:pink_terracotta
fill 352 172 479 352 173 479 minecraft:bone_block
fill 352 172 489 352 173 489 minecraft:bone_block
setblock 354 172 465 minecraft:red_nether_bricks
setblock 355 172 464 minecraft:red_nether_bricks
fill 355 172 465 358 172 465 minecraft:pink_terracotta
fill 355 172 479 355 173 479 minecraft:bone_block
fill 355 172 489 355 173 489 minecraft:bone_block
fill 356 172 464 359 172 464 minecraft:pink_terracotta
fill 358 172 479 358 173 479 minecraft:bone_block
fill 358 172 489 358 173 489 minecraft:bone_block
setblock 359 172 465 minecraft:red_nether_bricks
setblock 360 172 464 minecraft:red_nether_bricks
fill 360 172 465 363 172 465 minecraft:pink_terracotta
setblock 360 172 504 minecraft:red_nether_bricks
fill 361 172 464 364 172 464 minecraft:pink_terracotta
fill 361 172 479 361 173 479 minecraft:bone_block
fill 361 172 489 361 173 489 minecraft:bone_block
fill 361 172 504 364 172 504 minecraft:pink_terracotta
setblock 362 172 466 minecraft:pink_terracotta
setblock 363 172 466 minecraft:red_nether_bricks
fill 363 172 503 365 172 503 minecraft:pink_terracotta
setblock 364 172 465 minecraft:red_nether_bricks
fill 364 172 466 367 172 466 minecraft:pink_terracotta
setblock 365 172 464 minecraft:red_nether_bricks
fill 365 172 465 365 175 465 minecraft:pink_terracotta
setblock 365 172 504 minecraft:red_nether_bricks
fill 366 172 464 366 175 464 minecraft:pink_terracotta
setblock 366 172 503 minecraft:red_nether_bricks
fill 366 172 504 366 175 504 minecraft:pink_terracotta
fill 367 172 503 367 175 503 minecraft:pink_terracotta
setblock 368 172 466 minecraft:red_nether_bricks
fill 368 172 467 368 175 467 minecraft:pink_terracotta
setblock 369 172 465 minecraft:red_nether_bricks
fill 369 172 466 369 175 466 minecraft:pink_terracotta
setblock 369 172 485 minecraft:red_nether_bricks
fill 369 172 486 369 175 486 minecraft:pink_terracotta
setblock 369 172 489 minecraft:pink_terracotta
setblock 369 172 490 minecraft:red_nether_bricks
setblock 369 172 500 minecraft:red_nether_bricks
fill 369 172 501 369 175 501 minecraft:pink_terracotta
setblock 370 172 464 minecraft:red_nether_bricks
fill 370 172 465 370 175 465 minecraft:pink_terracotta
setblock 370 172 469 minecraft:red_nether_bricks
fill 370 172 470 370 175 470 minecraft:pink_terracotta
setblock 370 172 476 minecraft:white_concrete
fill 370 172 482 370 172 483 minecraft:pink_terracotta
setblock 370 172 484 minecraft:red_nether_bricks
fill 370 172 485 370 175 485 minecraft:pink_terracotta
setblock 370 172 489 minecraft:red_nether_bricks
fill 370 172 490 370 172 493 minecraft:pink_terracotta
setblock 370 172 494 minecraft:red_nether_bricks
fill 370 172 495 370 175 495 minecraft:pink_terracotta
setblock 370 172 499 minecraft:red_nether_bricks
fill 370 172 500 370 175 500 minecraft:pink_terracotta
setblock 370 172 504 minecraft:red_nether_bricks
fill 330 173 464 331 174 464 minecraft:pink_terracotta
setblock 330 173 468 minecraft:red_nether_bricks
setblock 330 173 479 minecraft:white_concrete
fill 330 173 481 330 173 482 minecraft:pink_terracotta
setblock 330 173 483 minecraft:red_nether_bricks
fill 330 173 484 330 173 487 minecraft:pink_terracotta
setblock 330 173 488 minecraft:red_nether_bricks
fill 330 173 489 330 173 492 minecraft:pink_terracotta
setblock 330 173 493 minecraft:red_nether_bricks
fill 330 173 494 330 173 497 minecraft:pink_terracotta
setblock 330 173 498 minecraft:red_nether_bricks
fill 330 173 499 330 173 502 minecraft:pink_terracotta
setblock 330 173 503 minecraft:red_nether_bricks
fill 330 173 504 332 173 504 minecraft:pink_terracotta
fill 331 173 484 331 173 486 minecraft:pink_terracotta
setblock 331 173 487 minecraft:red_nether_bricks
fill 331 173 488 331 173 491 minecraft:pink_terracotta
setblock 331 173 492 minecraft:red_nether_bricks
fill 331 173 493 331 176 493 minecraft:pink_terracotta
setblock 332 173 464 minecraft:white_concrete
fill 341 173 464 343 173 464 minecraft:pink_terracotta
setblock 343 173 465 minecraft:red_nether_bricks
fill 343 173 480 343 174 480 minecraft:bone_block
fill 343 173 488 343 174 488 minecraft:bone_block
setblock 344 173 464 minecraft:red_nether_bricks
fill 344 173 465 347 173 465 minecraft:pink_terracotta
setblock 344 173 504 minecraft:red_nether_bricks
fill 345 173 464 348 173 464 minecraft:pink_terracotta
fill 345 173 504 348 173 504 minecraft:pink_terracotta
setblock 346 173 466 minecraft:pink_terracotta
fill 346 173 480 346 174 480 minecraft:bone_block
fill 346 173 488 346 174 488 minecraft:bone_block
setblock 347 173 466 minecraft:red_nether_bricks
setblock 348 173 465 minecraft:red_nether_bricks
fill 348 173 466 348 176 466 minecraft:pink_terracotta
setblock 349 173 464 minecraft:red_nether_bricks
fill 349 173 465 352 173 465 minecraft:pink_terracotta
fill 349 173 480 349 174 480 minecraft:bone_block
fill 349 173 488 349 174 488 minecraft:bone_block
setblock 349 173 504 minecraft:red_nether_bricks
fill 350 173 464 353 173 464 minecraft:pink_terracotta
fill 352 173 480 352 174 480 minecraft:bone_block
fill 352 173 488 352 174 488 minecraft:bone_block
setblock 353 173 465 minecraft:red_nether_bricks
setblock 354 173 464 minecraft:red_nether_bricks
fill 354 173 465 357 173 465 minecraft:pink_terracotta
fill 355 173 464 358 173 464 minecraft:pink_terracotta
fill 355 173 480 355 174 480 minecraft:bone_block
fill 355 173 488 355 174 488 minecraft:bone_block
setblock 358 173 465 minecraft:red_nether_bricks
fill 358 173 480 358 174 480 minecraft:bone_block
fill 358 173 488 358 174 488 minecraft:bone_block
setblock 359 173 464 minecraft:red_nether_bricks
fill 359 173 465 362 173 465 minecraft:pink_terracotta
fill 360 173 464 363 173 464 minecraft:pink_terracotta
fill 360 173 504 363 173 504 minecraft:pink_terracotta
fill 361 173 480 361 174 480 minecraft:bone_block
fill 361 173 488 361 174 488 minecraft:bone_block
setblock 362 173 466 minecraft:red_nether_bricks
setblock 363 173 465 minecraft:red_nether_bricks
fill 363 173 466 366 173 466 minecraft:pink_terracotta
fill 363 173 503 364 173 503 minecraft:pink_terracotta
setblock 364 173 464 minecraft:red_nether_bricks
fill 364 173 465 364 176 465 minecraft:pink_terracotta
setblock 364 173 504 minecraft:red_nether_bricks
fill 365 173 464 365 176 464 minecraft:pink_terracotta
setblock 365 173 503 minecraft:red_nether_bricks
fill 365 173 504 365 176 504 minecraft:pink_terracotta
fill 366 173 503 366 176 503 minecraft:pink_terracotta
setblock 367 173 466 minecraft:red_nether_bricks
setblock 368 173 465 minecraft:red_nether_bricks
fill 368 173 466 368 176 466 minecraft:pink_terracotta
setblock 369 173 464 minecraft:red_nether_bricks
fill 369 173 465 369 176 465 minecraft:pink_terracotta
setblock 369 173 469 minecraft:red_nether_bricks
setblock 369 173 489 minecraft:red_nether_bricks
fill 369 173 490 370 173 492 minecraft:pink_terracotta
setblock 369 173 504 minecraft:red_nether_bricks
fill 370 173 464 370 176 464 minecraft:pink_terracotta
setblock 370 173 468 minecraft:red_nether_bricks
fill 370 173 469 370 176 469 minecraft:pink_terracotta
setblock 370 173 483 minecraft:red_nether_bricks
fill 370 173 484 370 176 484 minecraft:pink_terracotta
setblock 370 173 488 minecraft:red_nether_bricks
fill 370 173 489 370 176 489 minecraft:pink_terracotta
setblock 370 173 493 minecraft:red_nether_bricks
fill 370 173 494 370 176 494 minecraft:pink_terracotta
setblock 370 173 498 minecraft:red_nether_bricks
fill 370 173 499 370 176 499 minecraft:pink_terracotta
setblock 370 173 503 minecraft:red_nether_bricks
fill 370 173 504 370 176 504 minecraft:pink_terracotta
setblock 330 174 467 minecraft:red_nether_bricks
fill 330 174 468 330 176 469 minecraft:pink_terracotta
setblock 330 174 482 minecraft:red_nether_bricks
fill 330 174 483 330 174 486 minecraft:pink_terracotta
setblock 330 174 487 minecraft:red_nether_bricks
fill 330 174 488 330 174 491 minecraft:pink_terracotta
setblock 330 174 492 minecraft:red_nether_bricks
fill 330 174 493 330 174 496 minecraft:pink_terracotta
setblock 330 174 497 minecraft:red_nether_bricks
fill 330 174 498 330 174 501 minecraft:pink_terracotta
setblock 330 174 502 minecraft:red_nether_bricks
fill 330 174 503 330 175 504 minecraft:pink_terracotta
fill 331 174 484 331 174 485 minecraft:pink_terracotta
setblock 331 174 486 minecraft:red_nether_bricks
fill 331 174 487 331 174 490 minecraft:pink_terracotta
setblock 331 174 491 minecraft:red_nether_bricks
fill 331 174 492 331 177 492 minecraft:pink_terracotta
setblock 331 174 504 minecraft:pink_terracotta
fill 341 174 464 342 174 464 minecraft:pink_terracotta
setblock 343 174 464 minecraft:red_nether_bricks
fill 343 174 465 346 174 465 minecraft:pink_terracotta
fill 343 174 481 343 174 482 minecraft:bone_block
fill 343 174 486 343 174 487 minecraft:bone_block
fill 344 174 464 347 174 464 minecraft:pink_terracotta
fill 344 174 484 349 175 484 minecraft:bone_block
fill 344 174 504 347 174 504 minecraft:pink_terracotta
setblock 345 174 466 minecraft:pink_terracotta
setblock 346 174 466 minecraft:red_nether_bricks
fill 346 174 481 346 174 482 minecraft:bone_block
fill 346 174 486 346 174 487 minecraft:bone_block
setblock 347 174 465 minecraft:red_nether_bricks
fill 347 174 466 347 177 466 minecraft:pink_terracotta
setblock 348 174 464 minecraft:red_nether_bricks
fill 348 174 465 351 174 465 minecraft:pink_terracotta
setblock 348 174 504 minecraft:red_nether_bricks
fill 349 174 464 352 174 464 minecraft:pink_terracotta
fill 349 174 481 349 174 482 minecraft:bone_block
fill 349 174 486 349 174 487 minecraft:bone_block
setblock 352 174 465 minecraft:red_nether_bricks
fill 352 174 481 352 174 482 minecraft:bone_block
fill 352 174 486 352 174 487 minecraft:bone_block
setblock 353 174 464 minecraft:red_nether_bricks
fill 353 174 465 356 174 465 minecraft:pink_terracotta
fill 353 174 484 363 175 484 minecraft:bone_block
fill 354 174 464 357 174 464 minecraft:pink_terracotta
fill 355 174 481 355 174 482 minecraft:bone_block
fill 355 174 486 355 174 487 minecraft:bone_block
setblock 355 174 504 minecraft:white_concrete
setblock 357 174 465 minecraft:red_nether_bricks
setblock 358 174 464 minecraft:red_nether_bricks
fill 358 174 465 361 174 465 minecraft:pink_terracotta
fill 358 174 481 358 174 482 minecraft:bone_block
fill 358 174 486 358 174 487 minecraft:bone_block
fill 359 174 464 362 174 464 minecraft:pink_terracotta
fill 360 174 504 362 174 504 minecraft:pink_terracotta
setblock 361 174 466 minecraft:red_nether_bricks
fill 361 174 481 361 174 482 minecraft:bone_block
fill 361 174 486 361 174 487 minecraft:bone_block
setblock 362 174 465 minecraft:red_nether_bricks
fill 362 174 466 365 174 466 minecraft:pink_terracotta
setblock 363 174 464 minecraft:red_nether_bricks
fill 363 174 465 363 177 465 minecraft:pink_terracotta
setblock 363 174 503 minecraft:pink_terracotta
setblock 363 174 504 minecraft:red_nether_bricks
fill 364 174 464 364 177 464 minecraft:pink_terracotta
setblock 364 174 503 minecraft:red_nether_bricks
fill 364 174 504 364 177 504 minecraft:pink_terracotta
fill 365 174 503 365 177 503 minecraft:pink_terracotta
setblock 366 174 466 minecraft:red_nether_bricks
setblock 367 174 465 minecraft:red_nether_bricks
fill 367 174 466 367 177 466 minecraft:pink_terracotta
setblock 368 174 464 minecraft:red_nether_bricks
fill 368 174 465 368 177 465 minecraft:pink_terracotta
setblock 368 174 468 minecraft:pink_terracotta
setblock 368 174 504 minecraft:red_nether_bricks
fill 369 174 464 369 177 464 minecraft:pink_terracotta
setblock 369 174 468 minecraft:red_nether_bricks
fill 369 174 469 369 177 469 minecraft:pink_terracotta
setblock 369 174 488 minecraft:red_nether_bricks
fill 369 174 489 369 174 492 minecraft:pink_terracotta
setblock 369 174 493 minecraft:red_nether_bricks
fill 369 174 494 369 177 494 minecraft:pink_terracotta
setblock 369 174 503 minecraft:red_nether_bricks
fill 369 174 504 369 177 504 minecraft:pink_terracotta
setblock 370 174 467 minecraft:red_nether_bricks
fill 370 174 468 370 177 468 minecraft:pink_terracotta
setblock 370 174 471 minecraft:pink_terracotta
setblock 370 174 483 minecraft:white_concrete
setblock 370 174 487 minecraft:red_nether_bricks
schedule function dropper:buildpart/115_6 1t
