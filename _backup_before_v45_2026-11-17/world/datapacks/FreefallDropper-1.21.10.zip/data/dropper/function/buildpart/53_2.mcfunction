setblock 241 110 243 minecraft:pearlescent_froglight
setblock 241 110 245 minecraft:black_stained_glass
setblock 241 110 247 minecraft:sea_lantern
setblock 241 110 249 minecraft:black_stained_glass
setblock 241 110 251 minecraft:ochre_froglight
setblock 241 110 253 minecraft:pearlescent_froglight
setblock 241 110 261 minecraft:magenta_stained_glass
setblock 241 110 269 minecraft:black_stained_glass
setblock 243 110 229 minecraft:black_stained_glass
setblock 243 110 237 minecraft:black_stained_glass
setblock 243 110 261 minecraft:black_stained_glass
setblock 243 110 269 minecraft:black_stained_glass
setblock 244 110 230 minecraft:magenta_stained_glass
setblock 244 110 232 minecraft:light_blue_stained_glass
setblock 244 110 234 minecraft:black_stained_glass
setblock 244 110 236 minecraft:magenta_stained_glass
setblock 244 110 262 minecraft:sea_lantern
setblock 244 110 264 minecraft:black_stained_glass
setblock 244 110 266 minecraft:light_blue_stained_glass
setblock 244 110 268 minecraft:black_stained_glass
setblock 249 110 230 minecraft:ochre_froglight
setblock 249 110 232 minecraft:sea_lantern
setblock 249 110 265 minecraft:pearlescent_froglight
setblock 249 110 267 minecraft:sea_lantern
setblock 250 110 229 minecraft:cyan_stained_glass
setblock 250 110 234 minecraft:black_stained_glass
setblock 250 110 264 minecraft:light_blue_stained_glass
setblock 250 110 269 minecraft:light_blue_stained_glass
setblock 252 110 229 minecraft:magenta_stained_glass
setblock 252 110 234 minecraft:cyan_stained_glass
setblock 252 110 264 minecraft:black_stained_glass
setblock 252 110 269 minecraft:black_stained_glass
setblock 254 110 229 minecraft:black_stained_glass
setblock 254 110 234 minecraft:cyan_stained_glass
setblock 254 110 264 minecraft:cyan_stained_glass
setblock 254 110 269 minecraft:black_stained_glass
setblock 256 110 229 minecraft:cyan_stained_glass
setblock 256 110 234 minecraft:light_blue_stained_glass
setblock 256 110 264 minecraft:black_stained_glass
setblock 256 110 269 minecraft:black_stained_glass
setblock 258 110 229 minecraft:black_stained_glass
setblock 258 110 234 minecraft:black_stained_glass
setblock 258 110 264 minecraft:cyan_stained_glass
setblock 258 110 269 minecraft:black_stained_glass
setblock 260 110 229 minecraft:black_stained_glass
setblock 260 110 234 minecraft:black_stained_glass
setblock 260 110 264 minecraft:black_stained_glass
setblock 260 110 269 minecraft:magenta_stained_glass
setblock 262 110 230 minecraft:black_stained_glass
setblock 262 110 232 minecraft:magenta_stained_glass
setblock 262 110 265 minecraft:black_stained_glass
setblock 262 110 267 minecraft:ochre_froglight
fill 262 110 270 262 166 270 minecraft:black_concrete
setblock 268 110 230 minecraft:black_stained_glass
setblock 268 110 232 minecraft:pearlescent_froglight
setblock 268 110 234 minecraft:light_blue_stained_glass
setblock 268 110 236 minecraft:cyan_stained_glass
setblock 268 110 262 minecraft:black_stained_glass
setblock 268 110 264 minecraft:black_stained_glass
setblock 268 110 266 minecraft:cyan_stained_glass
setblock 268 110 268 minecraft:black_stained_glass
setblock 269 110 229 minecraft:cyan_stained_glass
setblock 269 110 237 minecraft:black_stained_glass
setblock 269 110 261 minecraft:pearlescent_froglight
setblock 269 110 269 minecraft:cyan_stained_glass
setblock 271 110 229 minecraft:black_stained_glass
setblock 271 110 237 minecraft:pearlescent_froglight
setblock 271 110 243 minecraft:sea_lantern
setblock 271 110 245 minecraft:cyan_stained_glass
setblock 271 110 247 minecraft:magenta_stained_glass
setblock 271 110 249 minecraft:black_stained_glass
setblock 271 110 251 minecraft:black_stained_glass
setblock 271 110 253 minecraft:black_stained_glass
setblock 271 110 261 minecraft:black_stained_glass
setblock 271 110 269 minecraft:sea_lantern
setblock 272 110 242 minecraft:sea_lantern
setblock 272 110 255 minecraft:pearlescent_froglight
setblock 273 110 229 minecraft:pearlescent_froglight
setblock 273 110 237 minecraft:sea_lantern
setblock 273 110 261 minecraft:magenta_stained_glass
setblock 273 110 269 minecraft:black_stained_glass
setblock 274 110 242 minecraft:black_stained_glass
setblock 274 110 255 minecraft:cyan_stained_glass
setblock 275 110 229 minecraft:ochre_froglight
setblock 275 110 237 minecraft:black_stained_glass
setblock 275 110 261 minecraft:magenta_stained_glass
setblock 275 110 269 minecraft:black_stained_glass
setblock 276 110 230 minecraft:pearlescent_froglight
setblock 276 110 232 minecraft:cyan_stained_glass
setblock 276 110 234 minecraft:black_stained_glass
setblock 276 110 236 minecraft:magenta_stained_glass
setblock 276 110 243 minecraft:pearlescent_froglight
setblock 276 110 245 minecraft:black_stained_glass
setblock 276 110 247 minecraft:sea_lantern
setblock 276 110 249 minecraft:ochre_froglight
setblock 276 110 251 minecraft:light_blue_stained_glass
setblock 276 110 253 minecraft:black_stained_glass
setblock 276 110 262 minecraft:black_stained_glass
setblock 276 110 264 minecraft:pearlescent_froglight
setblock 276 110 266 minecraft:black_stained_glass
setblock 276 110 268 minecraft:black_stained_glass
fill 236 111 230 236 112 230 minecraft:gray_concrete
fill 236 111 232 236 112 232 minecraft:gray_concrete
fill 236 111 234 236 112 234 minecraft:gray_concrete
fill 236 111 236 236 112 236 minecraft:gray_concrete
fill 236 111 243 236 112 243 minecraft:black_concrete
fill 236 111 245 236 112 245 minecraft:black_concrete
fill 236 111 247 236 112 247 minecraft:black_concrete
fill 236 111 249 236 112 249 minecraft:black_concrete
fill 236 111 251 236 112 251 minecraft:black_concrete
fill 236 111 253 236 112 253 minecraft:black_concrete
fill 236 111 262 236 112 262 minecraft:blue_terracotta
fill 236 111 264 236 112 264 minecraft:blue_terracotta
fill 236 111 266 236 112 266 minecraft:blue_terracotta
fill 236 111 268 236 112 268 minecraft:blue_terracotta
fill 237 111 229 237 112 229 minecraft:gray_concrete
fill 237 111 237 237 112 237 minecraft:gray_concrete
fill 237 111 242 237 112 242 minecraft:black_concrete
fill 237 111 255 237 112 255 minecraft:black_concrete
fill 237 111 261 237 112 261 minecraft:blue_terracotta
fill 237 111 269 237 112 269 minecraft:blue_terracotta
fill 239 111 229 239 112 229 minecraft:gray_concrete
fill 239 111 237 239 112 237 minecraft:gray_concrete
fill 239 111 242 239 112 242 minecraft:black_concrete
fill 239 111 255 239 112 255 minecraft:black_concrete
fill 239 111 261 239 112 261 minecraft:blue_terracotta
fill 239 111 269 239 112 269 minecraft:blue_terracotta
fill 241 111 229 241 112 229 minecraft:gray_concrete
fill 241 111 237 241 112 237 minecraft:gray_concrete
fill 241 111 243 241 112 243 minecraft:black_concrete
fill 241 111 245 241 112 245 minecraft:black_concrete
fill 241 111 247 241 112 247 minecraft:black_concrete
fill 241 111 249 241 112 249 minecraft:black_concrete
fill 241 111 251 241 112 251 minecraft:black_concrete
fill 241 111 253 241 112 253 minecraft:black_concrete
fill 241 111 261 241 112 261 minecraft:blue_terracotta
fill 241 111 269 241 112 269 minecraft:blue_terracotta
setblock 243 111 228 minecraft:purple_concrete
fill 243 111 229 243 112 229 minecraft:gray_concrete
fill 243 111 237 243 112 237 minecraft:gray_concrete
fill 243 111 261 243 112 261 minecraft:blue_terracotta
fill 243 111 269 243 112 269 minecraft:blue_terracotta
fill 244 111 230 244 112 230 minecraft:gray_concrete
fill 244 111 232 244 112 232 minecraft:gray_concrete
fill 244 111 234 244 112 234 minecraft:gray_concrete
fill 244 111 236 244 112 236 minecraft:gray_concrete
fill 244 111 262 244 112 262 minecraft:blue_terracotta
fill 244 111 264 244 112 264 minecraft:blue_terracotta
fill 244 111 266 244 112 266 minecraft:blue_terracotta
fill 244 111 268 244 112 268 minecraft:blue_terracotta
fill 249 111 230 249 112 230 minecraft:gray_concrete
fill 249 111 232 249 112 232 minecraft:gray_concrete
fill 249 111 265 249 112 265 minecraft:gray_concrete
fill 249 111 267 249 112 267 minecraft:gray_concrete
fill 250 111 229 250 112 229 minecraft:gray_concrete
fill 250 111 234 250 112 234 minecraft:gray_concrete
fill 250 111 264 250 112 264 minecraft:gray_concrete
fill 250 111 269 250 112 269 minecraft:gray_concrete
fill 252 111 229 252 112 229 minecraft:gray_concrete
fill 252 111 234 252 112 234 minecraft:gray_concrete
fill 252 111 264 252 112 264 minecraft:gray_concrete
fill 252 111 269 252 112 269 minecraft:gray_concrete
fill 254 111 229 254 112 229 minecraft:gray_concrete
fill 254 111 234 254 112 234 minecraft:gray_concrete
fill 254 111 264 254 112 264 minecraft:gray_concrete
fill 254 111 269 254 112 269 minecraft:gray_concrete
fill 256 111 229 256 112 229 minecraft:gray_concrete
fill 256 111 234 256 112 234 minecraft:gray_concrete
fill 256 111 264 256 112 264 minecraft:gray_concrete
fill 256 111 269 256 112 269 minecraft:gray_concrete
fill 258 111 229 258 112 229 minecraft:gray_concrete
fill 258 111 234 258 112 234 minecraft:gray_concrete
fill 258 111 264 258 112 264 minecraft:gray_concrete
fill 258 111 269 258 112 269 minecraft:gray_concrete
fill 260 111 229 260 112 229 minecraft:gray_concrete
fill 260 111 234 260 112 234 minecraft:gray_concrete
fill 260 111 264 260 112 264 minecraft:gray_concrete
fill 260 111 269 260 112 269 minecraft:gray_concrete
fill 262 111 230 262 112 230 minecraft:gray_concrete
fill 262 111 232 262 112 232 minecraft:gray_concrete
fill 262 111 265 262 112 265 minecraft:gray_concrete
fill 262 111 267 262 112 267 minecraft:gray_concrete
fill 268 111 230 268 112 230 minecraft:blue_terracotta
fill 268 111 232 268 112 232 minecraft:blue_terracotta
fill 268 111 234 268 112 234 minecraft:blue_terracotta
fill 268 111 236 268 112 236 minecraft:blue_terracotta
fill 268 111 262 268 112 262 minecraft:gray_concrete
fill 268 111 264 268 112 264 minecraft:gray_concrete
fill 268 111 266 268 112 266 minecraft:gray_concrete
fill 268 111 268 268 112 268 minecraft:gray_concrete
fill 269 111 229 269 112 229 minecraft:blue_terracotta
fill 269 111 237 269 112 237 minecraft:blue_terracotta
fill 269 111 261 269 112 261 minecraft:gray_concrete
fill 269 111 269 269 112 269 minecraft:gray_concrete
fill 271 111 229 271 112 229 minecraft:blue_terracotta
fill 271 111 237 271 112 237 minecraft:blue_terracotta
fill 271 111 243 271 112 243 minecraft:gray_concrete
fill 271 111 245 271 112 245 minecraft:gray_concrete
fill 271 111 247 271 112 247 minecraft:gray_concrete
fill 271 111 249 271 112 249 minecraft:gray_concrete
fill 271 111 251 271 112 251 minecraft:gray_concrete
fill 271 111 253 271 112 253 minecraft:gray_concrete
fill 271 111 261 271 112 261 minecraft:gray_concrete
fill 271 111 269 271 112 269 minecraft:gray_concrete
fill 272 111 242 272 112 242 minecraft:gray_concrete
fill 272 111 255 272 112 255 minecraft:gray_concrete
fill 273 111 228 274 168 228 minecraft:black_concrete
fill 273 111 229 273 112 229 minecraft:blue_terracotta
fill 273 111 237 273 112 237 minecraft:blue_terracotta
fill 273 111 261 273 112 261 minecraft:gray_concrete
fill 273 111 269 273 112 269 minecraft:gray_concrete
fill 274 111 242 274 112 242 minecraft:gray_concrete
fill 274 111 255 274 112 255 minecraft:gray_concrete
setblock 275 111 228 minecraft:purple_concrete
fill 275 111 229 275 112 229 minecraft:blue_terracotta
fill 275 111 237 275 112 237 minecraft:blue_terracotta
fill 275 111 261 275 112 261 minecraft:gray_concrete
fill 275 111 269 275 112 269 minecraft:gray_concrete
fill 276 111 228 277 137 228 minecraft:black_concrete
fill 276 111 230 276 112 230 minecraft:blue_terracotta
fill 276 111 232 276 112 232 minecraft:blue_terracotta
fill 276 111 234 276 112 234 minecraft:blue_terracotta
fill 276 111 236 276 112 236 minecraft:blue_terracotta
fill 276 111 243 276 112 243 minecraft:gray_concrete
fill 276 111 245 276 112 245 minecraft:gray_concrete
fill 276 111 247 276 112 247 minecraft:gray_concrete
fill 276 111 249 276 112 249 minecraft:gray_concrete
fill 276 111 251 276 112 251 minecraft:gray_concrete
fill 276 111 253 276 112 253 minecraft:gray_concrete
fill 276 111 262 276 112 262 minecraft:gray_concrete
fill 276 111 264 276 112 264 minecraft:gray_concrete
fill 276 111 266 276 112 266 minecraft:gray_concrete
fill 276 111 268 276 112 268 minecraft:gray_concrete
fill 277 111 238 277 184 238 minecraft:black_concrete
setblock 277 111 239 minecraft:pearlescent_froglight
setblock 277 111 258 minecraft:verdant_froglight
setblock 235 112 229 minecraft:ochre_froglight
fill 243 112 228 243 113 228 minecraft:black_concrete
setblock 267 112 270 minecraft:sea_lantern
fill 275 112 228 275 169 228 minecraft:black_concrete
fill 277 112 239 277 227 239 minecraft:black_concrete
fill 277 112 258 277 275 258 minecraft:black_concrete
fill 235 113 229 235 148 229 minecraft:black_concrete
setblock 236 113 230 minecraft:sea_lantern
setblock 236 113 232 minecraft:black_stained_glass
setblock 236 113 234 minecraft:cyan_stained_glass
setblock 236 113 236 minecraft:light_blue_stained_glass
setblock 236 113 243 minecraft:cyan_stained_glass
setblock 236 113 245 minecraft:pearlescent_froglight
setblock 236 113 247 minecraft:cyan_stained_glass
setblock 236 113 249 minecraft:black_stained_glass
setblock 236 113 251 minecraft:black_stained_glass
setblock 236 113 253 minecraft:sea_lantern
setblock 236 113 262 minecraft:black_stained_glass
setblock 236 113 264 minecraft:magenta_stained_glass
setblock 236 113 266 minecraft:light_blue_stained_glass
setblock 236 113 268 minecraft:light_blue_stained_glass
setblock 237 113 229 minecraft:black_stained_glass
setblock 237 113 237 minecraft:pearlescent_froglight
setblock 237 113 242 minecraft:black_stained_glass
setblock 237 113 255 minecraft:magenta_stained_glass
setblock 237 113 261 minecraft:black_stained_glass
setblock 237 113 269 minecraft:black_stained_glass
setblock 239 113 229 minecraft:sea_lantern
setblock 239 113 237 minecraft:black_stained_glass
setblock 239 113 242 minecraft:black_stained_glass
setblock 239 113 255 minecraft:light_blue_stained_glass
setblock 239 113 261 minecraft:light_blue_stained_glass
setblock 239 113 269 minecraft:sea_lantern
setblock 241 113 229 minecraft:black_stained_glass
setblock 241 113 237 minecraft:sea_lantern
setblock 241 113 243 minecraft:light_blue_stained_glass
setblock 241 113 245 minecraft:magenta_stained_glass
setblock 241 113 247 minecraft:cyan_stained_glass
setblock 241 113 249 minecraft:ochre_froglight
setblock 241 113 251 minecraft:cyan_stained_glass
setblock 241 113 253 minecraft:black_stained_glass
setblock 241 113 261 minecraft:magenta_stained_glass
setblock 241 113 269 minecraft:black_stained_glass
setblock 243 113 229 minecraft:black_stained_glass
setblock 243 113 237 minecraft:light_blue_stained_glass
setblock 243 113 261 minecraft:black_stained_glass
setblock 243 113 269 minecraft:light_blue_stained_glass
setblock 244 113 230 minecraft:light_blue_stained_glass
setblock 244 113 232 minecraft:sea_lantern
setblock 244 113 234 minecraft:black_stained_glass
setblock 244 113 236 minecraft:ochre_froglight
setblock 244 113 262 minecraft:cyan_stained_glass
setblock 244 113 264 minecraft:black_stained_glass
setblock 244 113 266 minecraft:ochre_froglight
setblock 244 113 268 minecraft:black_stained_glass
setblock 249 113 230 minecraft:black_stained_glass
setblock 249 113 232 minecraft:pearlescent_froglight
setblock 249 113 265 minecraft:sea_lantern
setblock 249 113 267 minecraft:pearlescent_froglight
setblock 250 113 229 minecraft:black_stained_glass
setblock 250 113 234 minecraft:light_blue_stained_glass
setblock 250 113 264 minecraft:sea_lantern
fill 250 113 269 250 113 270 minecraft:pearlescent_froglight
setblock 252 113 229 minecraft:cyan_stained_glass
setblock 252 113 234 minecraft:magenta_stained_glass
setblock 252 113 264 minecraft:light_blue_stained_glass
setblock 252 113 269 minecraft:magenta_stained_glass
setblock 254 113 229 minecraft:light_blue_stained_glass
setblock 254 113 234 minecraft:black_stained_glass
setblock 254 113 264 minecraft:ochre_froglight
setblock 254 113 269 minecraft:black_stained_glass
setblock 256 113 229 minecraft:ochre_froglight
setblock 256 113 234 minecraft:magenta_stained_glass
setblock 256 113 264 minecraft:pearlescent_froglight
setblock 256 113 269 minecraft:sea_lantern
setblock 258 113 229 minecraft:ochre_froglight
setblock 258 113 234 minecraft:cyan_stained_glass
setblock 258 113 264 minecraft:black_stained_glass
setblock 258 113 269 minecraft:magenta_stained_glass
setblock 260 113 229 minecraft:black_stained_glass
setblock 260 113 234 minecraft:light_blue_stained_glass
setblock 260 113 264 minecraft:pearlescent_froglight
setblock 260 113 269 minecraft:black_stained_glass
setblock 262 113 230 minecraft:cyan_stained_glass
setblock 262 113 232 minecraft:cyan_stained_glass
setblock 262 113 265 minecraft:black_stained_glass
setblock 262 113 267 minecraft:black_stained_glass
fill 267 113 270 267 135 270 minecraft:black_concrete
setblock 268 113 230 minecraft:magenta_stained_glass
setblock 268 113 232 minecraft:ochre_froglight
setblock 268 113 234 minecraft:black_stained_glass
setblock 268 113 236 minecraft:pearlescent_froglight
setblock 268 113 262 minecraft:black_stained_glass
setblock 268 113 264 minecraft:pearlescent_froglight
setblock 268 113 266 minecraft:ochre_froglight
setblock 268 113 268 minecraft:black_stained_glass
setblock 269 113 229 minecraft:magenta_stained_glass
setblock 269 113 237 minecraft:sea_lantern
setblock 269 113 261 minecraft:cyan_stained_glass
setblock 269 113 269 minecraft:light_blue_stained_glass
setblock 271 113 229 minecraft:sea_lantern
setblock 271 113 237 minecraft:magenta_stained_glass
setblock 271 113 243 minecraft:light_blue_stained_glass
setblock 271 113 245 minecraft:magenta_stained_glass
setblock 271 113 247 minecraft:black_stained_glass
setblock 271 113 249 minecraft:light_blue_stained_glass
setblock 271 113 251 minecraft:magenta_stained_glass
setblock 271 113 253 minecraft:light_blue_stained_glass
setblock 271 113 261 minecraft:light_blue_stained_glass
setblock 271 113 269 minecraft:pearlescent_froglight
setblock 272 113 242 minecraft:ochre_froglight
setblock 272 113 255 minecraft:black_stained_glass
setblock 273 113 229 minecraft:magenta_stained_glass
setblock 273 113 237 minecraft:sea_lantern
setblock 273 113 261 minecraft:magenta_stained_glass
setblock 273 113 269 minecraft:magenta_stained_glass
setblock 274 113 242 minecraft:light_blue_stained_glass
setblock 274 113 255 minecraft:light_blue_stained_glass
setblock 275 113 229 minecraft:black_stained_glass
setblock 275 113 237 minecraft:black_stained_glass
setblock 275 113 261 minecraft:pearlescent_froglight
setblock 275 113 269 minecraft:light_blue_stained_glass
setblock 276 113 230 minecraft:pearlescent_froglight
setblock 276 113 232 minecraft:pearlescent_froglight
setblock 276 113 234 minecraft:magenta_stained_glass
setblock 276 113 236 minecraft:ochre_froglight
setblock 276 113 243 minecraft:black_stained_glass
setblock 276 113 245 minecraft:sea_lantern
setblock 276 113 247 minecraft:sea_lantern
setblock 276 113 249 minecraft:light_blue_stained_glass
setblock 276 113 251 minecraft:pearlescent_froglight
setblock 276 113 253 minecraft:magenta_stained_glass
setblock 276 113 262 minecraft:pearlescent_froglight
setblock 276 113 264 minecraft:black_stained_glass
setblock 276 113 266 minecraft:sea_lantern
setblock 276 113 268 minecraft:pearlescent_froglight
fill 235 114 243 235 120 245 minecraft:black_concrete
setblock 235 114 246 minecraft:purple_concrete
fill 235 114 247 236 115 247 minecraft:black_concrete
setblock 235 114 249 minecraft:purple_concrete
fill 236 114 230 236 115 230 minecraft:gray_concrete
fill 236 114 232 236 115 232 minecraft:gray_concrete
fill 236 114 234 236 115 234 minecraft:gray_concrete
fill 236 114 236 236 115 236 minecraft:gray_concrete
fill 236 114 243 236 115 243 minecraft:black_concrete
fill 236 114 245 236 115 245 minecraft:black_concrete
fill 236 114 249 236 115 249 minecraft:black_concrete
fill 236 114 251 236 115 251 minecraft:black_concrete
fill 236 114 253 236 115 253 minecraft:black_concrete
fill 236 114 262 236 115 262 minecraft:blue_terracotta
fill 236 114 264 236 115 264 minecraft:blue_terracotta
fill 236 114 266 236 115 266 minecraft:blue_terracotta
fill 236 114 268 236 115 268 minecraft:blue_terracotta
fill 237 114 229 237 115 229 minecraft:gray_concrete
fill 237 114 237 237 115 237 minecraft:gray_concrete
fill 237 114 242 237 115 242 minecraft:black_concrete
fill 237 114 255 237 115 255 minecraft:black_concrete
fill 237 114 261 237 115 261 minecraft:blue_terracotta
fill 237 114 269 237 115 269 minecraft:blue_terracotta
fill 239 114 229 239 115 229 minecraft:gray_concrete
fill 239 114 237 239 115 237 minecraft:gray_concrete
fill 239 114 242 239 115 242 minecraft:black_concrete
fill 239 114 255 239 115 255 minecraft:black_concrete
fill 239 114 261 239 115 261 minecraft:blue_terracotta
fill 239 114 269 239 115 269 minecraft:blue_terracotta
fill 241 114 229 241 115 229 minecraft:gray_concrete
fill 241 114 237 241 115 237 minecraft:gray_concrete
fill 241 114 243 241 115 243 minecraft:black_concrete
fill 241 114 245 241 115 245 minecraft:black_concrete
fill 241 114 247 241 115 247 minecraft:black_concrete
fill 241 114 249 241 115 249 minecraft:black_concrete
fill 241 114 251 241 115 251 minecraft:black_concrete
fill 241 114 253 241 115 253 minecraft:black_concrete
fill 241 114 261 241 115 261 minecraft:blue_terracotta
fill 241 114 269 241 115 269 minecraft:blue_terracotta
setblock 243 114 228 minecraft:purple_concrete
fill 243 114 229 243 115 229 minecraft:gray_concrete
fill 243 114 237 243 115 237 minecraft:gray_concrete
fill 243 114 261 243 115 261 minecraft:blue_terracotta
fill 243 114 269 243 115 269 minecraft:blue_terracotta
fill 244 114 230 244 115 230 minecraft:gray_concrete
fill 244 114 232 244 115 232 minecraft:gray_concrete
fill 244 114 234 244 115 234 minecraft:gray_concrete
fill 244 114 236 244 115 236 minecraft:gray_concrete
fill 244 114 262 244 115 262 minecraft:blue_terracotta
fill 244 114 264 244 115 264 minecraft:blue_terracotta
fill 244 114 266 244 115 266 minecraft:blue_terracotta
fill 244 114 268 244 115 268 minecraft:blue_terracotta
setblock 247 114 228 minecraft:magenta_concrete
fill 249 114 230 249 115 230 minecraft:gray_concrete
fill 249 114 232 249 115 232 minecraft:gray_concrete
fill 249 114 265 249 115 265 minecraft:gray_concrete
fill 249 114 267 249 115 267 minecraft:gray_concrete
fill 250 114 229 250 115 229 minecraft:gray_concrete
fill 250 114 234 250 115 234 minecraft:gray_concrete
fill 250 114 264 250 115 264 minecraft:gray_concrete
fill 250 114 269 250 115 269 minecraft:gray_concrete
fill 250 114 270 250 132 270 minecraft:black_concrete
fill 252 114 229 252 115 229 minecraft:gray_concrete
fill 252 114 234 252 115 234 minecraft:gray_concrete
fill 252 114 264 252 115 264 minecraft:gray_concrete
fill 252 114 269 252 115 269 minecraft:gray_concrete
fill 254 114 229 254 115 229 minecraft:gray_concrete
fill 254 114 234 254 115 234 minecraft:gray_concrete
fill 254 114 264 254 115 264 minecraft:gray_concrete
fill 254 114 269 254 115 269 minecraft:gray_concrete
fill 254 114 270 254 139 270 minecraft:black_concrete
setblock 255 114 270 minecraft:magenta_concrete
fill 256 114 229 256 115 229 minecraft:gray_concrete
fill 256 114 234 256 115 234 minecraft:gray_concrete
fill 256 114 264 256 115 264 minecraft:gray_concrete
fill 256 114 269 256 115 269 minecraft:gray_concrete
fill 256 114 270 256 302 270 minecraft:black_concrete
fill 258 114 229 258 115 229 minecraft:gray_concrete
fill 258 114 234 258 115 234 minecraft:gray_concrete
fill 258 114 264 258 115 264 minecraft:gray_concrete
fill 258 114 269 258 115 269 minecraft:gray_concrete
fill 260 114 229 260 115 229 minecraft:gray_concrete
fill 260 114 234 260 115 234 minecraft:gray_concrete
fill 260 114 264 260 115 264 minecraft:gray_concrete
fill 260 114 269 260 115 269 minecraft:gray_concrete
fill 262 114 230 262 115 230 minecraft:gray_concrete
fill 262 114 232 262 115 232 minecraft:gray_concrete
fill 262 114 265 262 115 265 minecraft:gray_concrete
fill 262 114 267 262 115 267 minecraft:gray_concrete
fill 268 114 230 268 115 230 minecraft:blue_terracotta
fill 268 114 232 268 115 232 minecraft:blue_terracotta
fill 268 114 234 268 115 234 minecraft:blue_terracotta
fill 268 114 236 268 115 236 minecraft:blue_terracotta
fill 268 114 262 268 115 262 minecraft:gray_concrete
fill 268 114 264 268 115 264 minecraft:gray_concrete
fill 268 114 266 268 115 266 minecraft:gray_concrete
fill 268 114 268 268 115 268 minecraft:gray_concrete
fill 269 114 229 269 115 229 minecraft:blue_terracotta
fill 269 114 237 269 115 237 minecraft:blue_terracotta
fill 269 114 261 269 115 261 minecraft:gray_concrete
fill 269 114 269 269 115 269 minecraft:gray_concrete
fill 271 114 229 271 115 229 minecraft:blue_terracotta
fill 271 114 237 271 115 237 minecraft:blue_terracotta
fill 271 114 243 271 115 243 minecraft:gray_concrete
fill 271 114 245 271 115 245 minecraft:gray_concrete
fill 271 114 247 271 115 247 minecraft:gray_concrete
fill 271 114 249 271 115 249 minecraft:gray_concrete
fill 271 114 251 271 115 251 minecraft:gray_concrete
fill 271 114 253 271 115 253 minecraft:gray_concrete
fill 271 114 261 271 115 261 minecraft:gray_concrete
fill 271 114 269 271 115 269 minecraft:gray_concrete
fill 272 114 242 272 115 242 minecraft:gray_concrete
fill 272 114 255 272 115 255 minecraft:gray_concrete
fill 273 114 229 273 115 229 minecraft:blue_terracotta
fill 273 114 237 273 115 237 minecraft:blue_terracotta
fill 273 114 261 273 115 261 minecraft:gray_concrete
fill 273 114 269 273 115 269 minecraft:gray_concrete
fill 274 114 242 274 115 242 minecraft:gray_concrete
fill 274 114 255 274 115 255 minecraft:gray_concrete
fill 275 114 229 275 115 229 minecraft:blue_terracotta
fill 275 114 237 275 115 237 minecraft:blue_terracotta
fill 275 114 261 275 115 261 minecraft:gray_concrete
fill 275 114 269 275 115 269 minecraft:gray_concrete
fill 276 114 230 276 115 230 minecraft:blue_terracotta
fill 276 114 232 276 115 232 minecraft:blue_terracotta
fill 276 114 234 276 115 234 minecraft:blue_terracotta
fill 276 114 236 276 115 236 minecraft:blue_terracotta
fill 276 114 243 276 115 243 minecraft:gray_concrete
fill 276 114 245 276 115 245 minecraft:gray_concrete
fill 276 114 247 276 115 247 minecraft:gray_concrete
fill 276 114 249 276 115 249 minecraft:gray_concrete
fill 276 114 251 276 115 251 minecraft:gray_concrete
fill 276 114 253 276 115 253 minecraft:gray_concrete
fill 276 114 262 276 115 262 minecraft:gray_concrete
fill 276 114 264 276 115 264 minecraft:gray_concrete
fill 276 114 266 276 115 266 minecraft:gray_concrete
fill 276 114 268 276 115 268 minecraft:gray_concrete
fill 277 114 265 277 166 265 minecraft:black_concrete
setblock 277 114 266 minecraft:blue_concrete
fill 235 115 246 235 211 246 minecraft:black_concrete
fill 235 115 249 235 161 249 minecraft:black_concrete
setblock 238 115 238 minecraft:light[level=12]
setblock 238 115 239 minecraft:light[level=15]
setblock 238 115 259 minecraft:light[level=12]
fill 243 115 228 243 139 228 minecraft:black_concrete
setblock 245 115 231 minecraft:light[level=12]
setblock 245 115 238 minecraft:light[level=12]
setblock 245 115 245 minecraft:light[level=12]
setblock 245 115 252 minecraft:light[level=12]
setblock 245 115 259 minecraft:light[level=12]
setblock 245 115 266 minecraft:light[level=12]
setblock 246 115 231 minecraft:light[level=15]
setblock 246 115 239 minecraft:light[level=15]
setblock 246 115 247 minecraft:light[level=15]
setblock 246 115 255 minecraft:light[level=15]
setblock 246 115 263 minecraft:light[level=15]
fill 247 115 228 247 248 228 minecraft:black_concrete
fill 251 115 270 252 116 270 minecraft:black_concrete
setblock 252 115 238 minecraft:light[level=12]
setblock 252 115 245 minecraft:light[level=12]
setblock 252 115 252 minecraft:light[level=12]
setblock 252 115 259 minecraft:light[level=12]
setblock 253 115 270 minecraft:ochre_froglight
setblock 254 115 239 minecraft:light[level=15]
setblock 254 115 247 minecraft:light[level=15]
setblock 254 115 255 minecraft:light[level=15]
setblock 254 115 263 minecraft:light[level=15]
fill 255 115 270 255 176 270 minecraft:black_concrete
setblock 259 115 238 minecraft:light[level=12]
setblock 259 115 245 minecraft:light[level=12]
setblock 259 115 252 minecraft:light[level=12]
setblock 259 115 259 minecraft:light[level=12]
setblock 262 115 239 minecraft:light[level=15]
setblock 262 115 247 minecraft:light[level=15]
setblock 262 115 255 minecraft:light[level=15]
setblock 262 115 263 minecraft:light[level=15]
setblock 266 115 231 minecraft:light[level=12]
setblock 266 115 238 minecraft:light[level=12]
setblock 266 115 245 minecraft:light[level=12]
setblock 266 115 252 minecraft:light[level=12]
setblock 266 115 259 minecraft:light[level=12]
setblock 266 115 266 minecraft:light[level=12]
setblock 270 115 239 minecraft:light[level=15]
setblock 270 115 247 minecraft:light[level=15]
setblock 270 115 255 minecraft:light[level=15]
setblock 273 115 238 minecraft:light[level=12]
setblock 273 115 259 minecraft:light[level=12]
fill 274 115 270 274 144 270 minecraft:black_concrete
setblock 275 115 270 minecraft:ochre_froglight
fill 276 115 270 277 163 270 minecraft:black_concrete
setblock 277 115 266 minecraft:pearlescent_froglight
setblock 277 115 269 minecraft:blue_concrete
setblock 235 116 230 minecraft:blue_concrete
setblock 235 116 238 minecraft:cyan_concrete
fill 235 116 247 235 203 247 minecraft:black_concrete
setblock 236 116 230 minecraft:black_stained_glass
setblock 236 116 232 minecraft:sea_lantern
setblock 236 116 234 minecraft:black_stained_glass
setblock 236 116 236 minecraft:pearlescent_froglight
setblock 236 116 243 minecraft:light_blue_stained_glass
setblock 236 116 245 minecraft:black_stained_glass
setblock 236 116 247 minecraft:magenta_stained_glass
setblock 236 116 249 minecraft:black_stained_glass
setblock 236 116 251 minecraft:sea_lantern
setblock 236 116 253 minecraft:light_blue_stained_glass
setblock 236 116 262 minecraft:black_stained_glass
setblock 236 116 264 minecraft:black_stained_glass
setblock 236 116 266 minecraft:pearlescent_froglight
setblock 236 116 268 minecraft:black_stained_glass
setblock 237 116 229 minecraft:black_stained_glass
setblock 237 116 237 minecraft:magenta_stained_glass
setblock 237 116 242 minecraft:ochre_froglight
setblock 237 116 255 minecraft:sea_lantern
setblock 237 116 261 minecraft:magenta_stained_glass
setblock 237 116 269 minecraft:ochre_froglight
setblock 239 116 229 minecraft:pearlescent_froglight
setblock 239 116 237 minecraft:pearlescent_froglight
setblock 239 116 242 minecraft:black_stained_glass
setblock 239 116 255 minecraft:pearlescent_froglight
setblock 239 116 261 minecraft:sea_lantern
setblock 239 116 269 minecraft:black_stained_glass
setblock 241 116 229 minecraft:sea_lantern
setblock 241 116 237 minecraft:sea_lantern
setblock 241 116 243 minecraft:ochre_froglight
setblock 241 116 245 minecraft:ochre_froglight
setblock 241 116 247 minecraft:black_stained_glass
setblock 241 116 249 minecraft:cyan_stained_glass
setblock 241 116 251 minecraft:cyan_stained_glass
setblock 241 116 253 minecraft:black_stained_glass
setblock 241 116 261 minecraft:black_stained_glass
setblock 241 116 269 minecraft:light_blue_stained_glass
setblock 243 116 229 minecraft:magenta_stained_glass
setblock 243 116 237 minecraft:black_stained_glass
setblock 243 116 261 minecraft:pearlescent_froglight
setblock 243 116 269 minecraft:black_stained_glass
setblock 244 116 230 minecraft:black_stained_glass
setblock 244 116 232 minecraft:cyan_stained_glass
setblock 244 116 234 minecraft:cyan_stained_glass
setblock 244 116 236 minecraft:black_stained_glass
setblock 244 116 262 minecraft:black_stained_glass
setblock 244 116 264 minecraft:black_stained_glass
setblock 244 116 266 minecraft:black_stained_glass
setblock 244 116 268 minecraft:black_stained_glass
setblock 249 116 230 minecraft:sea_lantern
setblock 249 116 232 minecraft:magenta_stained_glass
setblock 249 116 265 minecraft:black_stained_glass
setblock 249 116 267 minecraft:black_stained_glass
setblock 250 116 229 minecraft:magenta_stained_glass
setblock 250 116 234 minecraft:black_stained_glass
setblock 250 116 264 minecraft:sea_lantern
setblock 250 116 269 minecraft:cyan_stained_glass
setblock 252 116 229 minecraft:black_stained_glass
setblock 252 116 234 minecraft:light_blue_stained_glass
setblock 252 116 264 minecraft:sea_lantern
setblock 252 116 269 minecraft:black_stained_glass
fill 253 116 270 253 272 270 minecraft:black_concrete
setblock 254 116 229 minecraft:black_stained_glass
setblock 254 116 234 minecraft:black_stained_glass
setblock 254 116 264 minecraft:cyan_stained_glass
setblock 254 116 269 minecraft:pearlescent_froglight
setblock 256 116 229 minecraft:magenta_stained_glass
setblock 256 116 234 minecraft:black_stained_glass
setblock 256 116 264 minecraft:black_stained_glass
setblock 256 116 269 minecraft:pearlescent_froglight
setblock 258 116 229 minecraft:magenta_stained_glass
setblock 258 116 234 minecraft:sea_lantern
setblock 258 116 264 minecraft:light_blue_stained_glass
setblock 258 116 269 minecraft:magenta_stained_glass
setblock 260 116 229 minecraft:black_stained_glass
setblock 260 116 234 minecraft:black_stained_glass
setblock 260 116 264 minecraft:black_stained_glass
setblock 260 116 269 minecraft:black_stained_glass
setblock 262 116 230 minecraft:light_blue_stained_glass
setblock 262 116 232 minecraft:pearlescent_froglight
setblock 262 116 265 minecraft:black_stained_glass
setblock 262 116 267 minecraft:black_stained_glass
setblock 268 116 230 minecraft:ochre_froglight
setblock 268 116 232 minecraft:black_stained_glass
setblock 268 116 234 minecraft:light_blue_stained_glass
setblock 268 116 236 minecraft:pearlescent_froglight
setblock 268 116 262 minecraft:black_stained_glass
setblock 268 116 264 minecraft:magenta_stained_glass
setblock 268 116 266 minecraft:black_stained_glass
setblock 268 116 268 minecraft:black_stained_glass
setblock 269 116 229 minecraft:black_stained_glass
setblock 269 116 237 minecraft:magenta_stained_glass
setblock 269 116 261 minecraft:ochre_froglight
setblock 269 116 269 minecraft:sea_lantern
setblock 271 116 229 minecraft:ochre_froglight
setblock 271 116 237 minecraft:light_blue_stained_glass
setblock 271 116 243 minecraft:cyan_stained_glass
setblock 271 116 245 minecraft:black_stained_glass
setblock 271 116 247 minecraft:light_blue_stained_glass
setblock 271 116 249 minecraft:black_stained_glass
setblock 271 116 251 minecraft:black_stained_glass
setblock 271 116 253 minecraft:black_stained_glass
setblock 271 116 261 minecraft:black_stained_glass
setblock 271 116 269 minecraft:ochre_froglight
setblock 272 116 242 minecraft:black_stained_glass
setblock 272 116 255 minecraft:black_stained_glass
setblock 273 116 229 minecraft:sea_lantern
setblock 273 116 237 minecraft:sea_lantern
setblock 273 116 261 minecraft:sea_lantern
setblock 273 116 269 minecraft:ochre_froglight
setblock 274 116 242 minecraft:black_stained_glass
setblock 274 116 255 minecraft:cyan_stained_glass
setblock 275 116 229 minecraft:cyan_stained_glass
setblock 275 116 237 minecraft:light_blue_stained_glass
setblock 275 116 261 minecraft:light_blue_stained_glass
setblock 275 116 269 minecraft:sea_lantern
fill 275 116 270 275 134 270 minecraft:black_concrete
setblock 276 116 230 minecraft:black_stained_glass
setblock 276 116 232 minecraft:light_blue_stained_glass
setblock 276 116 234 minecraft:light_blue_stained_glass
setblock 276 116 236 minecraft:pearlescent_froglight
setblock 276 116 243 minecraft:sea_lantern
setblock 276 116 245 minecraft:magenta_stained_glass
setblock 276 116 247 minecraft:magenta_stained_glass
setblock 276 116 249 minecraft:light_blue_stained_glass
setblock 276 116 251 minecraft:pearlescent_froglight
setblock 276 116 253 minecraft:pearlescent_froglight
setblock 276 116 262 minecraft:black_stained_glass
setblock 276 116 264 minecraft:sea_lantern
setblock 276 116 266 minecraft:pearlescent_froglight
setblock 276 116 268 minecraft:cyan_stained_glass
setblock 277 116 252 minecraft:blue_concrete
fill 277 116 266 277 138 266 minecraft:black_concrete
fill 277 116 269 277 202 269 minecraft:black_concrete
fill 235 117 230 235 134 230 minecraft:black_concrete
fill 235 117 238 235 142 238 minecraft:black_concrete
setblock 235 117 264 minecraft:sea_lantern
fill 236 117 230 236 118 230 minecraft:gray_concrete
fill 236 117 232 236 118 232 minecraft:gray_concrete
fill 236 117 234 236 118 234 minecraft:gray_concrete
fill 236 117 236 236 118 236 minecraft:gray_concrete
fill 236 117 243 236 118 243 minecraft:black_concrete
fill 236 117 245 236 118 245 minecraft:black_concrete
fill 236 117 247 236 118 247 minecraft:black_concrete
fill 236 117 249 236 118 249 minecraft:black_concrete
fill 236 117 251 236 118 251 minecraft:black_concrete
fill 236 117 253 236 118 253 minecraft:black_concrete
fill 236 117 262 236 118 262 minecraft:blue_terracotta
fill 236 117 264 236 118 264 minecraft:blue_terracotta
fill 236 117 266 236 118 266 minecraft:blue_terracotta
fill 236 117 268 236 118 268 minecraft:blue_terracotta
fill 237 117 229 237 118 229 minecraft:gray_concrete
fill 237 117 237 237 118 237 minecraft:gray_concrete
fill 237 117 242 237 118 242 minecraft:black_concrete
fill 237 117 255 237 118 255 minecraft:black_concrete
fill 237 117 261 237 118 261 minecraft:blue_terracotta
fill 237 117 269 237 118 269 minecraft:blue_terracotta
fill 239 117 229 239 118 229 minecraft:gray_concrete
fill 239 117 237 239 118 237 minecraft:gray_concrete
fill 239 117 242 239 118 242 minecraft:black_concrete
fill 239 117 255 239 118 255 minecraft:black_concrete
fill 239 117 261 239 118 261 minecraft:blue_terracotta
fill 239 117 269 239 118 269 minecraft:blue_terracotta
fill 241 117 229 241 118 229 minecraft:gray_concrete
fill 241 117 237 241 118 237 minecraft:gray_concrete
fill 241 117 243 241 118 243 minecraft:black_concrete
fill 241 117 245 241 118 245 minecraft:black_concrete
fill 241 117 247 241 118 247 minecraft:black_concrete
fill 241 117 249 241 118 249 minecraft:black_concrete
fill 241 117 251 241 118 251 minecraft:black_concrete
fill 241 117 253 241 118 253 minecraft:black_concrete
fill 241 117 261 241 118 261 minecraft:blue_terracotta
fill 241 117 269 241 118 269 minecraft:blue_terracotta
fill 243 117 229 243 118 229 minecraft:gray_concrete
fill 243 117 237 243 118 237 minecraft:gray_concrete
fill 243 117 261 243 118 261 minecraft:blue_terracotta
fill 243 117 269 243 118 269 minecraft:blue_terracotta
fill 244 117 230 244 118 230 minecraft:gray_concrete
fill 244 117 232 244 118 232 minecraft:gray_concrete
fill 244 117 234 244 118 234 minecraft:gray_concrete
fill 244 117 236 244 118 236 minecraft:gray_concrete
fill 244 117 262 244 118 262 minecraft:blue_terracotta
fill 244 117 264 244 118 264 minecraft:blue_terracotta
fill 244 117 266 244 118 266 minecraft:blue_terracotta
fill 244 117 268 244 118 268 minecraft:blue_terracotta
fill 249 117 230 249 118 230 minecraft:gray_concrete
fill 249 117 232 249 118 232 minecraft:gray_concrete
fill 249 117 265 249 118 265 minecraft:gray_concrete
fill 249 117 267 249 118 267 minecraft:gray_concrete
fill 250 117 229 250 118 229 minecraft:gray_concrete
fill 250 117 234 250 118 234 minecraft:gray_concrete
fill 250 117 264 250 118 264 minecraft:gray_concrete
fill 250 117 269 250 118 269 minecraft:gray_concrete
fill 251 117 270 251 123 270 minecraft:black_concrete
fill 252 117 229 252 118 229 minecraft:gray_concrete
fill 252 117 234 252 118 234 minecraft:gray_concrete
fill 252 117 264 252 118 264 minecraft:gray_concrete
fill 252 117 269 252 118 269 minecraft:gray_concrete
setblock 252 117 270 minecraft:sea_lantern
fill 254 117 229 254 118 229 minecraft:gray_concrete
fill 254 117 234 254 118 234 minecraft:gray_concrete
fill 254 117 264 254 118 264 minecraft:gray_concrete
fill 254 117 269 254 118 269 minecraft:gray_concrete
fill 256 117 229 256 118 229 minecraft:gray_concrete
fill 256 117 234 256 118 234 minecraft:gray_concrete
fill 256 117 264 256 118 264 minecraft:gray_concrete
fill 256 117 269 256 118 269 minecraft:gray_concrete
fill 258 117 229 258 118 229 minecraft:gray_concrete
fill 258 117 234 258 118 234 minecraft:gray_concrete
fill 258 117 264 258 118 264 minecraft:gray_concrete
fill 258 117 269 258 118 269 minecraft:gray_concrete
fill 260 117 229 260 118 229 minecraft:gray_concrete
fill 260 117 234 260 118 234 minecraft:gray_concrete
fill 260 117 264 260 118 264 minecraft:gray_concrete
fill 260 117 269 260 118 269 minecraft:gray_concrete
fill 262 117 230 262 118 230 minecraft:gray_concrete
fill 262 117 232 262 118 232 minecraft:gray_concrete
fill 262 117 265 262 118 265 minecraft:gray_concrete
fill 262 117 267 262 118 267 minecraft:gray_concrete
fill 268 117 230 268 118 230 minecraft:blue_terracotta
fill 268 117 232 268 118 232 minecraft:blue_terracotta
fill 268 117 234 268 118 234 minecraft:blue_terracotta
fill 268 117 236 268 118 236 minecraft:blue_terracotta
fill 268 117 262 268 118 262 minecraft:gray_concrete
fill 268 117 264 268 118 264 minecraft:gray_concrete
fill 268 117 266 268 118 266 minecraft:gray_concrete
fill 268 117 268 268 118 268 minecraft:gray_concrete
fill 269 117 229 269 118 229 minecraft:blue_terracotta
fill 269 117 237 269 118 237 minecraft:blue_terracotta
fill 269 117 261 269 118 261 minecraft:gray_concrete
fill 269 117 269 269 118 269 minecraft:gray_concrete
fill 271 117 229 271 118 229 minecraft:blue_terracotta
fill 271 117 237 271 118 237 minecraft:blue_terracotta
fill 271 117 243 271 118 243 minecraft:gray_concrete
fill 271 117 245 271 118 245 minecraft:gray_concrete
fill 271 117 247 271 118 247 minecraft:gray_concrete
fill 271 117 249 271 118 249 minecraft:gray_concrete
fill 271 117 251 271 118 251 minecraft:gray_concrete
fill 271 117 253 271 118 253 minecraft:gray_concrete
fill 271 117 261 271 118 261 minecraft:gray_concrete
fill 271 117 269 271 118 269 minecraft:gray_concrete
fill 272 117 242 272 118 242 minecraft:gray_concrete
fill 272 117 255 272 118 255 minecraft:gray_concrete
fill 273 117 229 273 118 229 minecraft:blue_terracotta
fill 273 117 237 273 118 237 minecraft:blue_terracotta
fill 273 117 261 273 118 261 minecraft:gray_concrete
fill 273 117 269 273 118 269 minecraft:gray_concrete
fill 274 117 242 274 118 242 minecraft:gray_concrete
fill 274 117 255 274 118 255 minecraft:gray_concrete
fill 275 117 229 275 118 229 minecraft:blue_terracotta
fill 275 117 237 275 118 237 minecraft:blue_terracotta
fill 275 117 261 275 118 261 minecraft:gray_concrete
fill 275 117 269 275 118 269 minecraft:gray_concrete
fill 276 117 230 276 118 230 minecraft:blue_terracotta
fill 276 117 232 276 118 232 minecraft:blue_terracotta
fill 276 117 234 276 118 234 minecraft:blue_terracotta
fill 276 117 236 276 118 236 minecraft:blue_terracotta
fill 276 117 243 276 118 243 minecraft:gray_concrete
fill 276 117 245 276 118 245 minecraft:gray_concrete
fill 276 117 247 276 118 247 minecraft:gray_concrete
fill 276 117 249 276 118 249 minecraft:gray_concrete
fill 276 117 251 276 118 251 minecraft:gray_concrete
fill 276 117 253 276 118 253 minecraft:gray_concrete
fill 276 117 262 276 118 262 minecraft:gray_concrete
fill 276 117 264 276 118 264 minecraft:gray_concrete
fill 276 117 266 276 118 266 minecraft:gray_concrete
fill 276 117 268 276 118 268 minecraft:gray_concrete
fill 277 117 252 277 191 252 minecraft:black_concrete
fill 235 118 264 235 120 264 minecraft:black_concrete
fill 252 118 270 252 182 270 minecraft:black_concrete
setblock 266 118 270 minecraft:ochre_froglight
setblock 269 118 228 minecraft:purple_concrete
setblock 270 118 249 minecraft:sea_lantern
setblock 236 119 230 minecraft:pearlescent_froglight
setblock 236 119 232 minecraft:ochre_froglight
setblock 236 119 234 minecraft:pearlescent_froglight
setblock 236 119 236 minecraft:light_blue_stained_glass
setblock 236 119 243 minecraft:light_blue_stained_glass
setblock 236 119 245 minecraft:black_stained_glass
setblock 236 119 247 minecraft:cyan_stained_glass
setblock 236 119 249 minecraft:sea_lantern
setblock 236 119 251 minecraft:black_stained_glass
setblock 236 119 253 minecraft:cyan_stained_glass
setblock 236 119 262 minecraft:sea_lantern
setblock 236 119 264 minecraft:pearlescent_froglight
setblock 236 119 266 minecraft:black_stained_glass
setblock 236 119 268 minecraft:magenta_stained_glass
setblock 237 119 229 minecraft:black_stained_glass
setblock 237 119 237 minecraft:magenta_stained_glass
fill 237 119 238 237 129 238 minecraft:cyan_wool
setblock 237 119 242 minecraft:pearlescent_froglight
setblock 237 119 255 minecraft:black_stained_glass
setblock 237 119 261 minecraft:black_stained_glass
setblock 237 119 269 minecraft:black_stained_glass
setblock 239 119 228 minecraft:cyan_concrete
setblock 239 119 229 minecraft:sea_lantern
setblock 239 119 237 minecraft:pearlescent_froglight
setblock 239 119 242 minecraft:black_stained_glass
setblock 239 119 255 minecraft:black_stained_glass
setblock 239 119 261 minecraft:magenta_stained_glass
setblock 239 119 269 minecraft:light_blue_stained_glass
setblock 241 119 229 minecraft:light_blue_stained_glass
setblock 241 119 237 minecraft:black_stained_glass
setblock 241 119 243 minecraft:black_stained_glass
setblock 241 119 245 minecraft:black_stained_glass
setblock 241 119 247 minecraft:black_stained_glass
setblock 241 119 249 minecraft:black_stained_glass
setblock 241 119 251 minecraft:black_stained_glass
setblock 241 119 253 minecraft:ochre_froglight
setblock 241 119 261 minecraft:sea_lantern
setblock 241 119 269 minecraft:magenta_stained_glass
setblock 243 119 229 minecraft:cyan_stained_glass
setblock 243 119 237 minecraft:light_blue_stained_glass
setblock 243 119 261 minecraft:ochre_froglight
setblock 243 119 269 minecraft:cyan_stained_glass
setblock 244 119 230 minecraft:black_stained_glass
setblock 244 119 232 minecraft:sea_lantern
setblock 244 119 234 minecraft:magenta_stained_glass
setblock 244 119 236 minecraft:light_blue_stained_glass
setblock 244 119 262 minecraft:magenta_stained_glass
setblock 244 119 264 minecraft:ochre_froglight
setblock 244 119 266 minecraft:black_stained_glass
setblock 244 119 268 minecraft:cyan_stained_glass
setblock 249 119 230 minecraft:black_stained_glass
setblock 249 119 232 minecraft:black_stained_glass
setblock 249 119 265 minecraft:magenta_stained_glass
setblock 249 119 267 minecraft:sea_lantern
setblock 250 119 229 minecraft:black_stained_glass
setblock 250 119 234 minecraft:light_blue_stained_glass
setblock 250 119 264 minecraft:black_stained_glass
setblock 250 119 269 minecraft:ochre_froglight
setblock 252 119 229 minecraft:black_stained_glass
setblock 252 119 234 minecraft:black_stained_glass
setblock 252 119 264 minecraft:sea_lantern
setblock 252 119 269 minecraft:magenta_stained_glass
setblock 254 119 229 minecraft:black_stained_glass
setblock 254 119 234 minecraft:ochre_froglight
setblock 254 119 264 minecraft:pearlescent_froglight
setblock 254 119 269 minecraft:sea_lantern
setblock 256 119 229 minecraft:cyan_stained_glass
setblock 256 119 234 minecraft:sea_lantern
setblock 256 119 264 minecraft:pearlescent_froglight
setblock 256 119 269 minecraft:black_stained_glass
setblock 258 119 229 minecraft:light_blue_stained_glass
setblock 258 119 234 minecraft:black_stained_glass
setblock 258 119 264 minecraft:sea_lantern
setblock 258 119 269 minecraft:cyan_stained_glass
setblock 260 119 229 minecraft:ochre_froglight
setblock 260 119 234 minecraft:black_stained_glass
setblock 260 119 264 minecraft:light_blue_stained_glass
setblock 260 119 269 minecraft:light_blue_stained_glass
setblock 262 119 230 minecraft:light_blue_stained_glass
setblock 262 119 232 minecraft:black_stained_glass
setblock 262 119 265 minecraft:magenta_stained_glass
setblock 262 119 267 minecraft:black_stained_glass
fill 266 119 270 266 158 270 minecraft:black_concrete
setblock 268 119 230 minecraft:black_stained_glass
setblock 268 119 232 minecraft:sea_lantern
setblock 268 119 234 minecraft:black_stained_glass
setblock 268 119 236 minecraft:light_blue_stained_glass
setblock 268 119 262 minecraft:cyan_stained_glass
setblock 268 119 264 minecraft:sea_lantern
setblock 268 119 266 minecraft:black_stained_glass
setblock 268 119 268 minecraft:magenta_stained_glass
fill 269 119 228 269 232 228 minecraft:black_concrete
setblock 269 119 229 minecraft:black_stained_glass
setblock 269 119 237 minecraft:light_blue_stained_glass
fill 269 119 248 271 119 250 minecraft:white_concrete
setblock 269 119 261 minecraft:ochre_froglight
setblock 269 119 269 minecraft:black_stained_glass
setblock 270 119 247 minecraft:white_concrete
setblock 270 119 251 minecraft:white_concrete
setblock 271 119 229 minecraft:light_blue_stained_glass
setblock 271 119 237 minecraft:light_blue_stained_glass
setblock 271 119 243 minecraft:pearlescent_froglight
setblock 271 119 245 minecraft:black_stained_glass
setblock 271 119 247 minecraft:magenta_stained_glass
setblock 271 119 251 minecraft:black_stained_glass
setblock 271 119 253 minecraft:ochre_froglight
setblock 271 119 261 minecraft:black_stained_glass
setblock 271 119 269 minecraft:cyan_stained_glass
setblock 272 119 242 minecraft:sea_lantern
setblock 272 119 255 minecraft:black_stained_glass
setblock 273 119 229 minecraft:cyan_stained_glass
setblock 273 119 237 minecraft:light_blue_stained_glass
setblock 273 119 261 minecraft:light_blue_stained_glass
setblock 273 119 269 minecraft:black_stained_glass
setblock 274 119 242 minecraft:black_stained_glass
setblock 274 119 255 minecraft:cyan_stained_glass
setblock 275 119 229 minecraft:sea_lantern
setblock 275 119 237 minecraft:magenta_stained_glass
setblock 275 119 261 minecraft:light_blue_stained_glass
setblock 275 119 269 minecraft:black_stained_glass
setblock 276 119 230 minecraft:ochre_froglight
setblock 276 119 232 minecraft:ochre_froglight
setblock 276 119 234 minecraft:black_stained_glass
setblock 276 119 236 minecraft:ochre_froglight
setblock 276 119 243 minecraft:magenta_stained_glass
setblock 276 119 245 minecraft:black_stained_glass
setblock 276 119 247 minecraft:black_stained_glass
setblock 276 119 249 minecraft:black_stained_glass
setblock 276 119 251 minecraft:light_blue_stained_glass
setblock 276 119 253 minecraft:black_stained_glass
setblock 276 119 262 minecraft:black_stained_glass
setblock 276 119 264 minecraft:cyan_stained_glass
setblock 276 119 266 minecraft:black_stained_glass
setblock 276 119 268 minecraft:magenta_stained_glass
setblock 277 119 233 minecraft:cyan_concrete
setblock 277 119 247 minecraft:purple_concrete
fill 236 120 230 236 121 230 minecraft:gray_concrete
fill 236 120 232 236 121 232 minecraft:gray_concrete
fill 236 120 234 236 121 234 minecraft:gray_concrete
fill 236 120 236 236 121 236 minecraft:gray_concrete
fill 236 120 243 236 121 243 minecraft:black_concrete
fill 236 120 245 236 121 245 minecraft:black_concrete
fill 236 120 247 236 121 247 minecraft:black_concrete
fill 236 120 249 236 121 249 minecraft:black_concrete
fill 236 120 251 236 121 251 minecraft:black_concrete
fill 236 120 253 236 121 253 minecraft:black_concrete
fill 236 120 262 236 121 262 minecraft:blue_terracotta
fill 236 120 264 236 121 264 minecraft:blue_terracotta
fill 236 120 266 236 121 266 minecraft:blue_terracotta
fill 236 120 268 236 121 268 minecraft:blue_terracotta
fill 237 120 229 237 121 229 minecraft:gray_concrete
fill 237 120 237 237 121 237 minecraft:gray_concrete
fill 237 120 239 237 129 240 minecraft:cyan_wool
fill 237 120 242 237 121 242 minecraft:black_concrete
fill 237 120 255 237 121 255 minecraft:black_concrete
fill 237 120 261 237 121 261 minecraft:blue_terracotta
fill 237 120 269 237 121 269 minecraft:blue_terracotta
fill 239 120 228 239 308 228 minecraft:black_concrete
fill 239 120 229 239 121 229 minecraft:gray_concrete
fill 239 120 237 239 121 237 minecraft:gray_concrete
fill 239 120 242 239 121 242 minecraft:black_concrete
fill 239 120 255 239 121 255 minecraft:black_concrete
fill 239 120 261 239 121 261 minecraft:blue_terracotta
fill 239 120 269 239 121 269 minecraft:blue_terracotta
fill 241 120 229 241 121 229 minecraft:gray_concrete
fill 241 120 237 241 121 237 minecraft:gray_concrete
fill 241 120 243 241 121 243 minecraft:black_concrete
fill 241 120 245 241 121 245 minecraft:black_concrete
fill 241 120 247 241 121 247 minecraft:black_concrete
fill 241 120 249 241 121 249 minecraft:black_concrete
fill 241 120 251 241 121 251 minecraft:black_concrete
fill 241 120 253 241 121 253 minecraft:black_concrete
fill 241 120 261 241 121 261 minecraft:blue_terracotta
fill 241 120 269 241 121 269 minecraft:blue_terracotta
fill 243 120 229 243 121 229 minecraft:gray_concrete
fill 243 120 237 243 121 237 minecraft:gray_concrete
fill 243 120 261 243 121 261 minecraft:blue_terracotta
fill 243 120 269 243 121 269 minecraft:blue_terracotta
fill 244 120 230 244 121 230 minecraft:gray_concrete
fill 244 120 232 244 121 232 minecraft:gray_concrete
fill 244 120 234 244 121 234 minecraft:gray_concrete
fill 244 120 236 244 121 236 minecraft:gray_concrete
fill 244 120 262 244 121 262 minecraft:blue_terracotta
fill 244 120 264 244 121 264 minecraft:blue_terracotta
fill 244 120 266 244 121 266 minecraft:blue_terracotta
fill 244 120 268 244 121 268 minecraft:blue_terracotta
fill 249 120 230 249 121 230 minecraft:gray_concrete
fill 249 120 232 249 121 232 minecraft:gray_concrete
fill 249 120 265 249 121 265 minecraft:gray_concrete
fill 249 120 267 249 121 267 minecraft:gray_concrete
fill 250 120 229 250 121 229 minecraft:gray_concrete
fill 250 120 234 250 121 234 minecraft:gray_concrete
fill 250 120 264 250 121 264 minecraft:gray_concrete
fill 250 120 269 250 121 269 minecraft:gray_concrete
fill 252 120 229 252 121 229 minecraft:gray_concrete
fill 252 120 234 252 121 234 minecraft:gray_concrete
fill 252 120 264 252 121 264 minecraft:gray_concrete
fill 252 120 269 252 121 269 minecraft:gray_concrete
fill 254 120 229 254 121 229 minecraft:gray_concrete
fill 254 120 234 254 121 234 minecraft:gray_concrete
fill 254 120 264 254 121 264 minecraft:gray_concrete
fill 254 120 269 254 121 269 minecraft:gray_concrete
fill 256 120 229 256 121 229 minecraft:gray_concrete
fill 256 120 234 256 121 234 minecraft:gray_concrete
fill 256 120 264 256 121 264 minecraft:gray_concrete
fill 256 120 269 256 121 269 minecraft:gray_concrete
fill 258 120 229 258 121 229 minecraft:gray_concrete
fill 258 120 234 258 121 234 minecraft:gray_concrete
fill 258 120 264 258 121 264 minecraft:gray_concrete
fill 258 120 269 258 121 269 minecraft:gray_concrete
fill 260 120 229 260 121 229 minecraft:gray_concrete
fill 260 120 234 260 121 234 minecraft:gray_concrete
fill 260 120 264 260 121 264 minecraft:gray_concrete
fill 260 120 269 260 121 269 minecraft:gray_concrete
fill 262 120 230 262 121 230 minecraft:gray_concrete
fill 262 120 232 262 121 232 minecraft:gray_concrete
fill 262 120 265 262 121 265 minecraft:gray_concrete
fill 262 120 267 262 121 267 minecraft:gray_concrete
fill 268 120 230 268 121 230 minecraft:blue_terracotta
fill 268 120 232 268 121 232 minecraft:blue_terracotta
fill 268 120 234 268 121 234 minecraft:blue_terracotta
fill 268 120 236 268 121 236 minecraft:blue_terracotta
fill 268 120 262 268 121 262 minecraft:gray_concrete
fill 268 120 264 268 121 264 minecraft:gray_concrete
fill 268 120 266 268 121 266 minecraft:gray_concrete
fill 268 120 268 268 121 268 minecraft:gray_concrete
fill 269 120 229 269 121 229 minecraft:blue_terracotta
fill 269 120 237 269 121 237 minecraft:blue_terracotta
fill 269 120 261 269 121 261 minecraft:gray_concrete
fill 269 120 269 269 121 269 minecraft:gray_concrete
fill 270 120 248 270 120 250 minecraft:light_blue_stained_glass
fill 271 120 229 271 121 229 minecraft:blue_terracotta
fill 271 120 237 271 121 237 minecraft:blue_terracotta
fill 271 120 243 271 121 243 minecraft:gray_concrete
fill 271 120 245 271 121 245 minecraft:gray_concrete
fill 271 120 247 271 121 251 minecraft:gray_concrete
fill 271 120 253 271 121 253 minecraft:gray_concrete
fill 271 120 261 271 121 261 minecraft:gray_concrete
fill 271 120 269 271 121 269 minecraft:gray_concrete
fill 272 120 242 272 121 242 minecraft:gray_concrete
fill 272 120 255 272 121 255 minecraft:gray_concrete
fill 273 120 229 273 121 229 minecraft:blue_terracotta
fill 273 120 237 273 121 237 minecraft:blue_terracotta
fill 273 120 261 273 121 261 minecraft:gray_concrete
fill 273 120 269 273 121 269 minecraft:gray_concrete
fill 274 120 242 274 121 242 minecraft:gray_concrete
fill 274 120 255 274 121 255 minecraft:gray_concrete
fill 275 120 229 275 121 229 minecraft:blue_terracotta
fill 275 120 237 275 121 237 minecraft:blue_terracotta
fill 275 120 261 275 121 261 minecraft:gray_concrete
fill 275 120 269 275 121 269 minecraft:gray_concrete
fill 276 120 230 276 121 230 minecraft:blue_terracotta
fill 276 120 232 276 121 232 minecraft:blue_terracotta
fill 276 120 234 276 121 234 minecraft:blue_terracotta
fill 276 120 236 276 121 236 minecraft:blue_terracotta
fill 276 120 243 276 121 243 minecraft:gray_concrete
fill 276 120 245 276 121 245 minecraft:gray_concrete
fill 276 120 247 276 121 247 minecraft:gray_concrete
fill 276 120 249 276 121 249 minecraft:gray_concrete
fill 276 120 251 276 121 251 minecraft:gray_concrete
fill 276 120 253 276 121 253 minecraft:gray_concrete
fill 276 120 262 276 121 262 minecraft:gray_concrete
fill 276 120 264 276 121 264 minecraft:gray_concrete
fill 276 120 266 276 121 266 minecraft:gray_concrete
fill 276 120 268 276 121 268 minecraft:gray_concrete
fill 277 120 233 277 258 233 minecraft:black_concrete
setblock 277 120 247 minecraft:black_concrete
setblock 277 120 251 minecraft:cyan_concrete
setblock 235 121 243 minecraft:purple_concrete
fill 235 121 244 235 130 245 minecraft:black_concrete
setblock 235 121 250 minecraft:ochre_froglight
setblock 235 121 264 minecraft:verdant_froglight
fill 235 121 266 235 209 266 minecraft:black_concrete
setblock 235 121 267 minecraft:ochre_froglight
fill 235 121 268 235 159 268 minecraft:black_concrete
setblock 238 121 238 minecraft:light[level=12]
setblock 238 121 259 minecraft:light[level=12]
setblock 243 121 270 minecraft:pearlescent_froglight
setblock 245 121 231 minecraft:light[level=12]
setblock 245 121 238 minecraft:light[level=12]
setblock 245 121 245 minecraft:light[level=12]
setblock 245 121 252 minecraft:light[level=12]
setblock 245 121 259 minecraft:light[level=12]
setblock 245 121 266 minecraft:light[level=12]
setblock 252 121 238 minecraft:light[level=12]
setblock 252 121 245 minecraft:light[level=12]
setblock 252 121 252 minecraft:light[level=12]
setblock 252 121 259 minecraft:light[level=12]
setblock 259 121 238 minecraft:light[level=12]
setblock 259 121 245 minecraft:light[level=12]
setblock 259 121 252 minecraft:light[level=12]
setblock 259 121 259 minecraft:light[level=12]
setblock 266 121 231 minecraft:light[level=12]
setblock 266 121 238 minecraft:light[level=12]
setblock 266 121 245 minecraft:light[level=12]
setblock 266 121 252 minecraft:light[level=12]
setblock 266 121 259 minecraft:light[level=12]
setblock 266 121 266 minecraft:light[level=12]
setblock 273 121 238 minecraft:light[level=12]
setblock 273 121 259 minecraft:light[level=12]
setblock 277 121 247 minecraft:verdant_froglight
fill 277 121 251 277 235 251 minecraft:black_concrete
fill 235 122 243 235 196 243 minecraft:black_concrete
fill 235 122 250 235 190 250 minecraft:black_concrete
fill 235 122 264 235 177 264 minecraft:black_concrete
fill 235 122 267 235 144 267 minecraft:black_concrete
setblock 236 122 230 minecraft:black_stained_glass
setblock 236 122 232 minecraft:cyan_stained_glass
setblock 236 122 234 minecraft:cyan_stained_glass
setblock 236 122 236 minecraft:black_stained_glass
setblock 236 122 243 minecraft:cyan_stained_glass
setblock 236 122 245 minecraft:ochre_froglight
setblock 236 122 247 minecraft:magenta_stained_glass
setblock 236 122 249 minecraft:ochre_froglight
setblock 236 122 251 minecraft:cyan_stained_glass
setblock 236 122 253 minecraft:black_stained_glass
setblock 236 122 262 minecraft:sea_lantern
setblock 236 122 264 minecraft:black_stained_glass
setblock 236 122 266 minecraft:light_blue_stained_glass
setblock 236 122 268 minecraft:light_blue_stained_glass
setblock 237 122 229 minecraft:light_blue_stained_glass
setblock 237 122 237 minecraft:black_stained_glass
setblock 237 122 242 minecraft:light_blue_stained_glass
setblock 237 122 255 minecraft:black_stained_glass
setblock 237 122 261 minecraft:black_stained_glass
setblock 237 122 269 minecraft:black_stained_glass
setblock 238 122 239 minecraft:light[level=15]
setblock 239 122 229 minecraft:cyan_stained_glass
setblock 239 122 237 minecraft:sea_lantern
setblock 239 122 242 minecraft:black_stained_glass
setblock 239 122 255 minecraft:black_stained_glass
setblock 239 122 261 minecraft:sea_lantern
setblock 239 122 269 minecraft:pearlescent_froglight
setblock 241 122 229 minecraft:light_blue_stained_glass
setblock 241 122 237 minecraft:sea_lantern
setblock 241 122 243 minecraft:black_stained_glass
setblock 241 122 245 minecraft:cyan_stained_glass
setblock 241 122 247 minecraft:magenta_stained_glass
setblock 241 122 249 minecraft:black_stained_glass
setblock 241 122 251 minecraft:light_blue_stained_glass
setblock 241 122 253 minecraft:black_stained_glass
setblock 241 122 261 minecraft:pearlescent_froglight
setblock 241 122 269 minecraft:black_stained_glass
setblock 243 122 229 minecraft:black_stained_glass
setblock 243 122 237 minecraft:black_stained_glass
setblock 243 122 261 minecraft:sea_lantern
setblock 243 122 269 minecraft:ochre_froglight
fill 243 122 270 243 225 270 minecraft:black_concrete
setblock 244 122 230 minecraft:black_stained_glass
setblock 244 122 232 minecraft:magenta_stained_glass
setblock 244 122 234 minecraft:ochre_froglight
setblock 244 122 236 minecraft:black_stained_glass
setblock 244 122 262 minecraft:black_stained_glass
setblock 244 122 264 minecraft:ochre_froglight
setblock 244 122 266 minecraft:magenta_stained_glass
setblock 244 122 268 minecraft:magenta_stained_glass
setblock 246 122 231 minecraft:light[level=15]
setblock 246 122 239 minecraft:light[level=15]
setblock 246 122 247 minecraft:light[level=15]
setblock 246 122 255 minecraft:light[level=15]
setblock 246 122 263 minecraft:light[level=15]
setblock 249 122 230 minecraft:magenta_stained_glass
setblock 249 122 232 minecraft:black_stained_glass
setblock 249 122 265 minecraft:black_stained_glass
setblock 249 122 267 minecraft:black_stained_glass
setblock 250 122 229 minecraft:light_blue_stained_glass
setblock 250 122 234 minecraft:pearlescent_froglight
setblock 250 122 264 minecraft:cyan_stained_glass
setblock 250 122 269 minecraft:black_stained_glass
setblock 252 122 228 minecraft:pearlescent_froglight
setblock 252 122 229 minecraft:ochre_froglight
setblock 252 122 234 minecraft:cyan_stained_glass
setblock 252 122 264 minecraft:black_stained_glass
setblock 252 122 269 minecraft:black_stained_glass
fill 253 122 228 254 145 228 minecraft:black_concrete
setblock 254 122 229 minecraft:light_blue_stained_glass
setblock 254 122 234 minecraft:light_blue_stained_glass
setblock 254 122 239 minecraft:light[level=15]
setblock 254 122 247 minecraft:light[level=15]
setblock 254 122 255 minecraft:light[level=15]
setblock 254 122 263 minecraft:light[level=15]
setblock 254 122 264 minecraft:sea_lantern
setblock 254 122 269 minecraft:sea_lantern
setblock 256 122 229 minecraft:black_stained_glass
setblock 256 122 234 minecraft:pearlescent_froglight
setblock 256 122 264 minecraft:light_blue_stained_glass
setblock 256 122 269 minecraft:ochre_froglight
setblock 258 122 229 minecraft:magenta_stained_glass
setblock 258 122 234 minecraft:black_stained_glass
setblock 258 122 264 minecraft:pearlescent_froglight
setblock 258 122 269 minecraft:magenta_stained_glass
setblock 258 122 270 minecraft:purple_concrete
setblock 260 122 229 minecraft:black_stained_glass
setblock 260 122 234 minecraft:black_stained_glass
setblock 260 122 264 minecraft:pearlescent_froglight
setblock 260 122 269 minecraft:black_stained_glass
setblock 262 122 230 minecraft:black_stained_glass
setblock 262 122 232 minecraft:ochre_froglight
setblock 262 122 239 minecraft:light[level=15]
setblock 262 122 247 minecraft:light[level=15]
setblock 262 122 255 minecraft:light[level=15]
setblock 262 122 263 minecraft:light[level=15]
setblock 262 122 265 minecraft:ochre_froglight
setblock 262 122 267 minecraft:cyan_stained_glass
setblock 268 122 230 minecraft:cyan_stained_glass
setblock 268 122 232 minecraft:cyan_stained_glass
setblock 268 122 234 minecraft:black_stained_glass
setblock 268 122 236 minecraft:pearlescent_froglight
setblock 268 122 262 minecraft:black_stained_glass
setblock 268 122 264 minecraft:black_stained_glass
setblock 268 122 266 minecraft:cyan_stained_glass
setblock 268 122 268 minecraft:cyan_stained_glass
setblock 269 122 229 minecraft:black_stained_glass
setblock 269 122 237 minecraft:black_stained_glass
setblock 269 122 261 minecraft:ochre_froglight
setblock 269 122 269 minecraft:black_stained_glass
setblock 270 122 239 minecraft:light[level=15]
setblock 270 122 247 minecraft:light[level=15]
setblock 270 122 255 minecraft:light[level=15]
setblock 271 122 229 minecraft:cyan_stained_glass
setblock 271 122 237 minecraft:sea_lantern
setblock 271 122 243 minecraft:black_stained_glass
setblock 271 122 245 minecraft:sea_lantern
setblock 271 122 247 minecraft:magenta_stained_glass
fill 271 122 248 271 186 248 minecraft:gray_concrete
setblock 271 122 249 minecraft:black_stained_glass
fill 271 122 250 271 186 250 minecraft:gray_concrete
setblock 271 122 251 minecraft:black_stained_glass
setblock 271 122 253 minecraft:sea_lantern
setblock 271 122 261 minecraft:magenta_stained_glass
setblock 271 122 269 minecraft:light_blue_stained_glass
setblock 272 122 242 minecraft:magenta_stained_glass
setblock 272 122 255 minecraft:black_stained_glass
setblock 273 122 229 minecraft:pearlescent_froglight
setblock 273 122 237 minecraft:ochre_froglight
setblock 273 122 261 minecraft:pearlescent_froglight
setblock 273 122 269 minecraft:light_blue_stained_glass
setblock 274 122 242 minecraft:sea_lantern
setblock 274 122 255 minecraft:black_stained_glass
setblock 275 122 229 minecraft:black_stained_glass
setblock 275 122 237 minecraft:ochre_froglight
setblock 275 122 261 minecraft:black_stained_glass
setblock 275 122 269 minecraft:black_stained_glass
setblock 276 122 230 minecraft:pearlescent_froglight
setblock 276 122 232 minecraft:sea_lantern
setblock 276 122 234 minecraft:black_stained_glass
setblock 276 122 236 minecraft:black_stained_glass
setblock 276 122 243 minecraft:black_stained_glass
setblock 276 122 245 minecraft:black_stained_glass
setblock 276 122 247 minecraft:black_stained_glass
setblock 276 122 249 minecraft:magenta_stained_glass
setblock 276 122 251 minecraft:pearlescent_froglight
setblock 276 122 253 minecraft:black_stained_glass
setblock 276 122 262 minecraft:light_blue_stained_glass
setblock 276 122 264 minecraft:cyan_stained_glass
setblock 276 122 266 minecraft:magenta_stained_glass
setblock 276 122 268 minecraft:black_stained_glass
fill 277 122 247 277 254 247 minecraft:black_concrete
fill 236 123 230 236 124 230 minecraft:gray_concrete
fill 236 123 232 236 124 232 minecraft:gray_concrete
fill 236 123 234 236 124 234 minecraft:gray_concrete
fill 236 123 236 236 124 236 minecraft:gray_concrete
fill 236 123 243 236 124 243 minecraft:black_concrete
fill 236 123 245 236 124 245 minecraft:black_concrete
fill 236 123 247 236 124 247 minecraft:black_concrete
fill 236 123 249 236 124 249 minecraft:black_concrete
fill 236 123 251 236 124 251 minecraft:black_concrete
fill 236 123 253 236 124 253 minecraft:black_concrete
fill 236 123 262 236 124 262 minecraft:blue_terracotta
fill 236 123 264 236 124 264 minecraft:blue_terracotta
fill 236 123 266 236 124 266 minecraft:blue_terracotta
fill 236 123 268 236 124 268 minecraft:blue_terracotta
fill 237 123 229 237 124 229 minecraft:gray_concrete
fill 237 123 237 237 124 237 minecraft:gray_concrete
fill 237 123 242 237 124 242 minecraft:black_concrete
fill 237 123 255 237 124 255 minecraft:black_concrete
fill 237 123 261 237 124 261 minecraft:blue_terracotta
fill 237 123 269 237 124 269 minecraft:blue_terracotta
fill 239 123 229 239 124 229 minecraft:gray_concrete
fill 239 123 237 239 124 237 minecraft:gray_concrete
fill 239 123 242 239 124 242 minecraft:black_concrete
fill 239 123 255 239 124 255 minecraft:black_concrete
fill 239 123 261 239 124 261 minecraft:blue_terracotta
fill 239 123 269 239 124 269 minecraft:blue_terracotta
fill 241 123 229 241 124 229 minecraft:gray_concrete
fill 241 123 237 241 124 237 minecraft:gray_concrete
fill 241 123 243 241 124 243 minecraft:black_concrete
fill 241 123 245 241 124 245 minecraft:black_concrete
fill 241 123 247 241 124 247 minecraft:black_concrete
fill 241 123 249 241 124 249 minecraft:black_concrete
fill 241 123 251 241 124 251 minecraft:black_concrete
fill 241 123 253 241 124 253 minecraft:black_concrete
fill 241 123 261 241 124 261 minecraft:blue_terracotta
fill 241 123 269 241 124 269 minecraft:blue_terracotta
fill 243 123 229 243 124 229 minecraft:gray_concrete
fill 243 123 237 243 124 237 minecraft:gray_concrete
fill 243 123 261 243 124 261 minecraft:blue_terracotta
fill 243 123 269 243 124 269 minecraft:blue_terracotta
fill 244 123 230 244 124 230 minecraft:gray_concrete
fill 244 123 232 244 124 232 minecraft:gray_concrete
fill 244 123 234 244 124 234 minecraft:gray_concrete
fill 244 123 236 244 124 236 minecraft:gray_concrete
fill 244 123 262 244 124 262 minecraft:blue_terracotta
fill 244 123 264 244 124 264 minecraft:blue_terracotta
fill 244 123 266 244 124 266 minecraft:blue_terracotta
fill 244 123 268 244 124 268 minecraft:blue_terracotta
fill 249 123 230 249 124 230 minecraft:gray_concrete
fill 249 123 232 249 124 232 minecraft:gray_concrete
fill 249 123 265 249 124 265 minecraft:gray_concrete
fill 249 123 267 249 124 267 minecraft:gray_concrete
fill 250 123 229 250 124 229 minecraft:gray_concrete
fill 250 123 234 250 124 234 minecraft:gray_concrete
fill 250 123 264 250 124 264 minecraft:gray_concrete
fill 250 123 269 250 124 269 minecraft:gray_concrete
fill 252 123 228 252 127 228 minecraft:black_concrete
fill 252 123 229 252 124 229 minecraft:gray_concrete
fill 252 123 234 252 124 234 minecraft:gray_concrete
fill 252 123 264 252 124 264 minecraft:gray_concrete
fill 252 123 269 252 124 269 minecraft:gray_concrete
fill 254 123 229 254 124 229 minecraft:gray_concrete
fill 254 123 234 254 124 234 minecraft:gray_concrete
fill 254 123 264 254 124 264 minecraft:gray_concrete
fill 254 123 269 254 124 269 minecraft:gray_concrete
fill 256 123 229 256 124 229 minecraft:gray_concrete
fill 256 123 234 256 124 234 minecraft:gray_concrete
fill 256 123 264 256 124 264 minecraft:gray_concrete
fill 256 123 269 256 124 269 minecraft:gray_concrete
fill 258 123 229 258 124 229 minecraft:gray_concrete
fill 258 123 234 258 124 234 minecraft:gray_concrete
fill 258 123 264 258 124 264 minecraft:gray_concrete
fill 258 123 269 258 124 269 minecraft:gray_concrete
fill 258 123 270 258 191 270 minecraft:black_concrete
fill 260 123 229 260 124 229 minecraft:gray_concrete
fill 260 123 234 260 124 234 minecraft:gray_concrete
fill 260 123 264 260 124 264 minecraft:gray_concrete
fill 260 123 269 260 124 269 minecraft:gray_concrete
fill 262 123 230 262 124 230 minecraft:gray_concrete
fill 262 123 232 262 124 232 minecraft:gray_concrete
fill 262 123 265 262 124 265 minecraft:gray_concrete
fill 262 123 267 262 124 267 minecraft:gray_concrete
fill 268 123 230 268 124 230 minecraft:blue_terracotta
fill 268 123 232 268 124 232 minecraft:blue_terracotta
fill 268 123 234 268 124 234 minecraft:blue_terracotta
fill 268 123 236 268 124 236 minecraft:blue_terracotta
fill 268 123 262 268 124 262 minecraft:gray_concrete
fill 268 123 264 268 124 264 minecraft:gray_concrete
fill 268 123 266 268 124 266 minecraft:gray_concrete
fill 268 123 268 268 124 268 minecraft:gray_concrete
fill 269 123 229 269 124 229 minecraft:blue_terracotta
fill 269 123 237 269 124 237 minecraft:blue_terracotta
fill 269 123 261 269 124 261 minecraft:gray_concrete
fill 269 123 269 269 124 269 minecraft:gray_concrete
fill 271 123 229 271 124 229 minecraft:blue_terracotta
fill 271 123 237 271 124 237 minecraft:blue_terracotta
fill 271 123 243 271 124 243 minecraft:gray_concrete
fill 271 123 245 271 124 245 minecraft:gray_concrete
fill 271 123 247 271 124 247 minecraft:gray_concrete
fill 271 123 249 271 124 249 minecraft:gray_concrete
fill 271 123 251 271 124 251 minecraft:gray_concrete
fill 271 123 253 271 124 253 minecraft:gray_concrete
fill 271 123 261 271 124 261 minecraft:gray_concrete
fill 271 123 269 271 124 269 minecraft:gray_concrete
fill 272 123 242 272 124 242 minecraft:gray_concrete
fill 272 123 255 272 124 255 minecraft:gray_concrete
fill 273 123 229 273 124 229 minecraft:blue_terracotta
fill 273 123 237 273 124 237 minecraft:blue_terracotta
fill 273 123 261 273 124 261 minecraft:gray_concrete
fill 273 123 269 273 124 269 minecraft:gray_concrete
fill 274 123 242 274 124 242 minecraft:gray_concrete
fill 274 123 255 274 124 255 minecraft:gray_concrete
fill 275 123 229 275 124 229 minecraft:blue_terracotta
fill 275 123 237 275 124 237 minecraft:blue_terracotta
fill 275 123 261 275 124 261 minecraft:gray_concrete
fill 275 123 269 275 124 269 minecraft:gray_concrete
fill 276 123 230 276 124 230 minecraft:blue_terracotta
fill 276 123 232 276 124 232 minecraft:blue_terracotta
fill 276 123 234 276 124 234 minecraft:blue_terracotta
fill 276 123 236 276 124 236 minecraft:blue_terracotta
fill 276 123 243 276 124 243 minecraft:gray_concrete
fill 276 123 245 276 124 245 minecraft:gray_concrete
fill 276 123 247 276 124 247 minecraft:gray_concrete
fill 276 123 249 276 124 249 minecraft:gray_concrete
fill 276 123 251 276 124 251 minecraft:gray_concrete
fill 276 123 253 276 124 253 minecraft:gray_concrete
fill 276 123 262 276 124 262 minecraft:gray_concrete
fill 276 123 264 276 124 264 minecraft:gray_concrete
fill 276 123 266 276 124 266 minecraft:gray_concrete
fill 276 123 268 276 124 268 minecraft:gray_concrete
setblock 235 124 253 minecraft:cyan_concrete
setblock 251 124 270 minecraft:pearlescent_froglight
setblock 273 124 270 minecraft:blue_concrete
fill 235 125 253 235 131 253 minecraft:black_concrete
setblock 235 125 265 minecraft:blue_concrete
setblock 236 125 230 minecraft:magenta_stained_glass
setblock 236 125 232 minecraft:pearlescent_froglight
setblock 236 125 234 minecraft:black_stained_glass
setblock 236 125 236 minecraft:cyan_stained_glass
setblock 236 125 243 minecraft:sea_lantern
setblock 236 125 245 minecraft:sea_lantern
setblock 236 125 247 minecraft:black_stained_glass
setblock 236 125 249 minecraft:black_stained_glass
setblock 236 125 251 minecraft:black_stained_glass
setblock 236 125 253 minecraft:light_blue_stained_glass
setblock 236 125 262 minecraft:black_stained_glass
setblock 236 125 264 minecraft:black_stained_glass
setblock 236 125 266 minecraft:black_stained_glass
setblock 236 125 268 minecraft:magenta_stained_glass
setblock 237 125 229 minecraft:black_stained_glass
setblock 237 125 237 minecraft:sea_lantern
setblock 237 125 242 minecraft:black_stained_glass
setblock 237 125 255 minecraft:pearlescent_froglight
setblock 237 125 261 minecraft:black_stained_glass
setblock 237 125 269 minecraft:black_stained_glass
setblock 239 125 229 minecraft:cyan_stained_glass
setblock 239 125 237 minecraft:black_stained_glass
setblock 239 125 242 minecraft:pearlescent_froglight
setblock 239 125 255 minecraft:black_stained_glass
setblock 239 125 261 minecraft:cyan_stained_glass
setblock 239 125 269 minecraft:light_blue_stained_glass
setblock 241 125 229 minecraft:magenta_stained_glass
setblock 241 125 237 minecraft:magenta_stained_glass
setblock 241 125 243 minecraft:pearlescent_froglight
setblock 241 125 245 minecraft:sea_lantern
setblock 241 125 247 minecraft:cyan_stained_glass
setblock 241 125 249 minecraft:black_stained_glass
setblock 241 125 251 minecraft:black_stained_glass
setblock 241 125 253 minecraft:sea_lantern
setblock 241 125 261 minecraft:cyan_stained_glass
setblock 241 125 269 minecraft:magenta_stained_glass
setblock 243 125 229 minecraft:light_blue_stained_glass
setblock 243 125 237 minecraft:sea_lantern
setblock 243 125 261 minecraft:black_stained_glass
setblock 243 125 269 minecraft:sea_lantern
setblock 244 125 230 minecraft:black_stained_glass
setblock 244 125 232 minecraft:ochre_froglight
setblock 244 125 234 minecraft:light_blue_stained_glass
setblock 244 125 236 minecraft:pearlescent_froglight
setblock 244 125 262 minecraft:magenta_stained_glass
setblock 244 125 264 minecraft:black_stained_glass
setblock 244 125 266 minecraft:pearlescent_froglight
setblock 244 125 268 minecraft:magenta_stained_glass
setblock 249 125 230 minecraft:magenta_stained_glass
setblock 249 125 232 minecraft:pearlescent_froglight
setblock 249 125 265 minecraft:black_stained_glass
setblock 249 125 267 minecraft:light_blue_stained_glass
setblock 250 125 229 minecraft:pearlescent_froglight
setblock 250 125 234 minecraft:black_stained_glass
setblock 250 125 264 minecraft:ochre_froglight
setblock 250 125 269 minecraft:black_stained_glass
fill 251 125 270 251 130 270 minecraft:black_concrete
setblock 252 125 229 minecraft:black_stained_glass
setblock 252 125 234 minecraft:ochre_froglight
setblock 252 125 264 minecraft:pearlescent_froglight
setblock 252 125 269 minecraft:black_stained_glass
setblock 254 125 229 minecraft:pearlescent_froglight
setblock 254 125 234 minecraft:ochre_froglight
setblock 254 125 264 minecraft:sea_lantern
setblock 254 125 269 minecraft:black_stained_glass
setblock 256 125 229 minecraft:cyan_stained_glass
setblock 256 125 234 minecraft:black_stained_glass
setblock 256 125 264 minecraft:cyan_stained_glass
setblock 256 125 269 minecraft:ochre_froglight
setblock 258 125 229 minecraft:cyan_stained_glass
setblock 258 125 234 minecraft:pearlescent_froglight
setblock 258 125 264 minecraft:ochre_froglight
setblock 258 125 269 minecraft:magenta_stained_glass
setblock 260 125 229 minecraft:black_stained_glass
setblock 260 125 234 minecraft:pearlescent_froglight
setblock 260 125 264 minecraft:light_blue_stained_glass
setblock 260 125 269 minecraft:sea_lantern
setblock 262 125 230 minecraft:cyan_stained_glass
setblock 262 125 232 minecraft:pearlescent_froglight
setblock 262 125 265 minecraft:magenta_stained_glass
setblock 262 125 267 minecraft:black_stained_glass
setblock 268 125 230 minecraft:black_stained_glass
setblock 268 125 232 minecraft:sea_lantern
setblock 268 125 234 minecraft:light_blue_stained_glass
setblock 268 125 236 minecraft:sea_lantern
setblock 268 125 262 minecraft:black_stained_glass
setblock 268 125 264 minecraft:sea_lantern
setblock 268 125 266 minecraft:light_blue_stained_glass
setblock 268 125 268 minecraft:black_stained_glass
setblock 269 125 229 minecraft:pearlescent_froglight
setblock 269 125 237 minecraft:magenta_stained_glass
setblock 269 125 261 minecraft:magenta_stained_glass
setblock 269 125 269 minecraft:black_stained_glass
setblock 271 125 229 minecraft:light_blue_stained_glass
setblock 271 125 237 minecraft:light_blue_stained_glass
setblock 271 125 243 minecraft:black_stained_glass
setblock 271 125 245 minecraft:black_stained_glass
setblock 271 125 247 minecraft:light_blue_stained_glass
setblock 271 125 249 minecraft:black_stained_glass
setblock 271 125 251 minecraft:black_stained_glass
setblock 271 125 253 minecraft:black_stained_glass
setblock 271 125 261 minecraft:light_blue_stained_glass
setblock 271 125 269 minecraft:cyan_stained_glass
setblock 272 125 242 minecraft:black_stained_glass
setblock 272 125 255 minecraft:black_stained_glass
setblock 273 125 229 minecraft:black_stained_glass
setblock 273 125 237 minecraft:ochre_froglight
setblock 273 125 261 minecraft:pearlescent_froglight
setblock 273 125 269 minecraft:black_stained_glass
fill 273 125 270 273 194 270 minecraft:black_concrete
setblock 274 125 242 minecraft:black_stained_glass
setblock 274 125 255 minecraft:light_blue_stained_glass
setblock 275 125 229 minecraft:pearlescent_froglight
setblock 275 125 237 minecraft:black_stained_glass
setblock 275 125 261 minecraft:pearlescent_froglight
setblock 275 125 269 minecraft:sea_lantern
setblock 276 125 230 minecraft:pearlescent_froglight
setblock 276 125 232 minecraft:pearlescent_froglight
setblock 276 125 234 minecraft:black_stained_glass
setblock 276 125 236 minecraft:magenta_stained_glass
setblock 276 125 243 minecraft:black_stained_glass
setblock 276 125 245 minecraft:magenta_stained_glass
setblock 276 125 247 minecraft:magenta_stained_glass
setblock 276 125 249 minecraft:light_blue_stained_glass
setblock 276 125 251 minecraft:black_stained_glass
setblock 276 125 253 minecraft:cyan_stained_glass
setblock 276 125 262 minecraft:light_blue_stained_glass
setblock 276 125 264 minecraft:pearlescent_froglight
setblock 276 125 266 minecraft:black_stained_glass
setblock 276 125 268 minecraft:pearlescent_froglight
fill 235 126 265 235 149 265 minecraft:black_concrete
fill 236 126 230 236 127 230 minecraft:gray_concrete
fill 236 126 232 236 127 232 minecraft:gray_concrete
fill 236 126 234 236 127 234 minecraft:gray_concrete
fill 236 126 236 236 127 236 minecraft:gray_concrete
fill 236 126 243 236 127 243 minecraft:black_concrete
fill 236 126 245 236 127 245 minecraft:black_concrete
fill 236 126 247 236 127 247 minecraft:black_concrete
fill 236 126 249 236 127 249 minecraft:black_concrete
fill 236 126 251 236 127 251 minecraft:black_concrete
fill 236 126 253 236 127 253 minecraft:black_concrete
fill 236 126 262 236 127 262 minecraft:blue_terracotta
fill 236 126 264 236 127 264 minecraft:blue_terracotta
fill 236 126 266 236 127 266 minecraft:blue_terracotta
fill 236 126 268 236 127 268 minecraft:blue_terracotta
fill 237 126 229 237 127 229 minecraft:gray_concrete
fill 237 126 237 237 127 237 minecraft:gray_concrete
fill 237 126 242 237 127 242 minecraft:black_concrete
fill 237 126 255 237 127 255 minecraft:black_concrete
fill 237 126 261 237 127 261 minecraft:blue_terracotta
fill 237 126 269 237 127 269 minecraft:blue_terracotta
fill 239 126 229 239 127 229 minecraft:gray_concrete
fill 239 126 237 239 127 237 minecraft:gray_concrete
fill 239 126 242 239 127 242 minecraft:black_concrete
fill 239 126 255 239 127 255 minecraft:black_concrete
fill 239 126 261 239 127 261 minecraft:blue_terracotta
fill 239 126 269 239 127 269 minecraft:blue_terracotta
fill 241 126 229 241 127 229 minecraft:gray_concrete
fill 241 126 237 241 127 237 minecraft:gray_concrete
fill 241 126 243 241 127 243 minecraft:black_concrete
fill 241 126 245 241 127 245 minecraft:black_concrete
fill 241 126 247 241 127 247 minecraft:black_concrete
fill 241 126 249 241 127 249 minecraft:black_concrete
fill 241 126 251 241 127 251 minecraft:black_concrete
fill 241 126 253 241 127 253 minecraft:black_concrete
fill 241 126 261 241 127 261 minecraft:blue_terracotta
fill 241 126 269 241 127 269 minecraft:blue_terracotta
fill 243 126 229 243 127 229 minecraft:gray_concrete
fill 243 126 237 243 127 237 minecraft:gray_concrete
fill 243 126 261 243 127 261 minecraft:blue_terracotta
fill 243 126 269 243 127 269 minecraft:blue_terracotta
fill 244 126 230 244 127 230 minecraft:gray_concrete
fill 244 126 232 244 127 232 minecraft:gray_concrete
fill 244 126 234 244 127 234 minecraft:gray_concrete
fill 244 126 236 244 127 236 minecraft:gray_concrete
fill 244 126 262 244 127 262 minecraft:blue_terracotta
fill 244 126 264 244 127 264 minecraft:blue_terracotta
fill 244 126 266 244 127 266 minecraft:blue_terracotta
fill 244 126 268 244 127 268 minecraft:blue_terracotta
fill 249 126 230 249 127 230 minecraft:gray_concrete
fill 249 126 232 249 127 232 minecraft:gray_concrete
fill 249 126 265 249 127 265 minecraft:gray_concrete
fill 249 126 267 249 127 267 minecraft:gray_concrete
fill 250 126 229 250 127 229 minecraft:gray_concrete
fill 250 126 234 250 127 234 minecraft:gray_concrete
fill 250 126 264 250 127 264 minecraft:gray_concrete
fill 250 126 269 250 127 269 minecraft:gray_concrete
fill 252 126 229 252 127 229 minecraft:gray_concrete
fill 252 126 234 252 127 234 minecraft:gray_concrete
fill 252 126 264 252 127 264 minecraft:gray_concrete
fill 252 126 269 252 127 269 minecraft:gray_concrete
fill 254 126 229 254 127 229 minecraft:gray_concrete
fill 254 126 234 254 127 234 minecraft:gray_concrete
fill 254 126 264 254 127 264 minecraft:gray_concrete
fill 254 126 269 254 127 269 minecraft:gray_concrete
fill 256 126 229 256 127 229 minecraft:gray_concrete
fill 256 126 234 256 127 234 minecraft:gray_concrete
fill 256 126 264 256 127 264 minecraft:gray_concrete
fill 256 126 269 256 127 269 minecraft:gray_concrete
fill 258 126 229 258 127 229 minecraft:gray_concrete
fill 258 126 234 258 127 234 minecraft:gray_concrete
fill 258 126 264 258 127 264 minecraft:gray_concrete
fill 258 126 269 258 127 269 minecraft:gray_concrete
fill 260 126 229 260 127 229 minecraft:gray_concrete
fill 260 126 234 260 127 234 minecraft:gray_concrete
fill 260 126 264 260 127 264 minecraft:gray_concrete
fill 260 126 269 260 127 269 minecraft:gray_concrete
setblock 261 126 270 minecraft:sea_lantern
fill 262 126 230 262 127 230 minecraft:gray_concrete
fill 262 126 232 262 127 232 minecraft:gray_concrete
fill 262 126 265 262 127 265 minecraft:gray_concrete
fill 262 126 267 262 127 267 minecraft:gray_concrete
fill 268 126 230 268 127 230 minecraft:blue_terracotta
fill 268 126 232 268 127 232 minecraft:blue_terracotta
fill 268 126 234 268 127 234 minecraft:blue_terracotta
fill 268 126 236 268 127 236 minecraft:blue_terracotta
fill 268 126 262 268 127 262 minecraft:gray_concrete
fill 268 126 264 268 127 264 minecraft:gray_concrete
fill 268 126 266 268 127 266 minecraft:gray_concrete
fill 268 126 268 268 127 268 minecraft:gray_concrete
fill 269 126 229 269 127 229 minecraft:blue_terracotta
fill 269 126 237 269 127 237 minecraft:blue_terracotta
fill 269 126 261 269 127 261 minecraft:gray_concrete
fill 269 126 269 269 127 269 minecraft:gray_concrete
fill 271 126 229 271 127 229 minecraft:blue_terracotta
fill 271 126 237 271 127 237 minecraft:blue_terracotta
fill 271 126 243 271 127 243 minecraft:gray_concrete
fill 271 126 245 271 127 245 minecraft:gray_concrete
fill 271 126 247 271 127 247 minecraft:gray_concrete
fill 271 126 249 271 127 249 minecraft:gray_concrete
fill 271 126 251 271 127 251 minecraft:gray_concrete
fill 271 126 253 271 127 253 minecraft:gray_concrete
fill 271 126 261 271 127 261 minecraft:gray_concrete
fill 271 126 269 271 127 269 minecraft:gray_concrete
fill 272 126 242 272 127 242 minecraft:gray_concrete
fill 272 126 255 272 127 255 minecraft:gray_concrete
fill 273 126 229 273 127 229 minecraft:blue_terracotta
fill 273 126 237 273 127 237 minecraft:blue_terracotta
fill 273 126 261 273 127 261 minecraft:gray_concrete
fill 273 126 269 273 127 269 minecraft:gray_concrete
fill 274 126 242 274 127 242 minecraft:gray_concrete
fill 274 126 255 274 127 255 minecraft:gray_concrete
fill 275 126 229 275 127 229 minecraft:blue_terracotta
fill 275 126 237 275 127 237 minecraft:blue_terracotta
fill 275 126 261 275 127 261 minecraft:gray_concrete
fill 275 126 269 275 127 269 minecraft:gray_concrete
fill 276 126 230 276 127 230 minecraft:blue_terracotta
fill 276 126 232 276 127 232 minecraft:blue_terracotta
fill 276 126 234 276 127 234 minecraft:blue_terracotta
fill 276 126 236 276 127 236 minecraft:blue_terracotta
fill 276 126 243 276 127 243 minecraft:gray_concrete
fill 276 126 245 276 127 245 minecraft:gray_concrete
fill 276 126 247 276 127 247 minecraft:gray_concrete
fill 276 126 249 276 127 249 minecraft:gray_concrete
fill 276 126 251 276 127 251 minecraft:gray_concrete
fill 276 126 253 276 127 253 minecraft:gray_concrete
fill 276 126 262 276 127 262 minecraft:gray_concrete
fill 276 126 264 276 127 264 minecraft:gray_concrete
fill 276 126 266 276 127 266 minecraft:gray_concrete
fill 276 126 268 276 127 268 minecraft:gray_concrete
setblock 277 126 236 minecraft:verdant_froglight
setblock 238 127 238 minecraft:light[level=12]
setblock 238 127 259 minecraft:light[level=12]
setblock 245 127 231 minecraft:light[level=12]
setblock 245 127 238 minecraft:light[level=12]
setblock 245 127 245 minecraft:light[level=12]
setblock 245 127 252 minecraft:light[level=12]
setblock 245 127 259 minecraft:light[level=12]
setblock 245 127 266 minecraft:light[level=12]
setblock 252 127 238 minecraft:light[level=12]
setblock 252 127 245 minecraft:light[level=12]
setblock 252 127 252 minecraft:light[level=12]
setblock 252 127 259 minecraft:light[level=12]
setblock 259 127 238 minecraft:light[level=12]
setblock 259 127 245 minecraft:light[level=12]
setblock 259 127 252 minecraft:light[level=12]
setblock 259 127 259 minecraft:light[level=12]
fill 261 127 270 261 159 270 minecraft:black_concrete
setblock 266 127 231 minecraft:light[level=12]
setblock 266 127 238 minecraft:light[level=12]
setblock 266 127 245 minecraft:light[level=12]
setblock 266 127 252 minecraft:light[level=12]
setblock 266 127 259 minecraft:light[level=12]
setblock 266 127 266 minecraft:light[level=12]
setblock 273 127 238 minecraft:light[level=12]
setblock 273 127 259 minecraft:light[level=12]
fill 277 127 236 277 308 236 minecraft:black_concrete
setblock 235 128 269 minecraft:cyan_concrete
setblock 236 128 230 minecraft:sea_lantern
setblock 236 128 232 minecraft:sea_lantern
setblock 236 128 234 minecraft:black_stained_glass
setblock 236 128 236 minecraft:sea_lantern
setblock 236 128 243 minecraft:black_stained_glass
setblock 236 128 245 minecraft:magenta_stained_glass
setblock 236 128 247 minecraft:light_blue_stained_glass
setblock 236 128 249 minecraft:sea_lantern
setblock 236 128 251 minecraft:cyan_stained_glass
setblock 236 128 253 minecraft:light_blue_stained_glass
setblock 236 128 262 minecraft:ochre_froglight
setblock 236 128 264 minecraft:black_stained_glass
setblock 236 128 266 minecraft:light_blue_stained_glass
setblock 236 128 268 minecraft:black_stained_glass
setblock 237 128 229 minecraft:black_stained_glass
setblock 237 128 237 minecraft:ochre_froglight
setblock 237 128 242 minecraft:black_stained_glass
setblock 237 128 255 minecraft:magenta_stained_glass
setblock 237 128 261 minecraft:sea_lantern
setblock 237 128 269 minecraft:magenta_stained_glass
setblock 239 128 229 minecraft:light_blue_stained_glass
setblock 239 128 237 minecraft:pearlescent_froglight
setblock 239 128 242 minecraft:black_stained_glass
setblock 239 128 255 minecraft:sea_lantern
setblock 239 128 261 minecraft:sea_lantern
setblock 239 128 269 minecraft:magenta_stained_glass
setblock 241 128 229 minecraft:black_stained_glass
setblock 241 128 237 minecraft:magenta_stained_glass
setblock 241 128 243 minecraft:black_stained_glass
setblock 241 128 245 minecraft:black_stained_glass
setblock 241 128 247 minecraft:ochre_froglight
setblock 241 128 249 minecraft:ochre_froglight
setblock 241 128 251 minecraft:pearlescent_froglight
setblock 241 128 253 minecraft:ochre_froglight
setblock 241 128 261 minecraft:black_stained_glass
setblock 241 128 269 minecraft:light_blue_stained_glass
setblock 243 128 229 minecraft:pearlescent_froglight
setblock 243 128 237 minecraft:black_stained_glass
setblock 243 128 261 minecraft:black_stained_glass
setblock 243 128 269 minecraft:sea_lantern
setblock 244 128 230 minecraft:ochre_froglight
setblock 244 128 232 minecraft:pearlescent_froglight
setblock 244 128 234 minecraft:black_stained_glass
setblock 244 128 236 minecraft:pearlescent_froglight
setblock 244 128 262 minecraft:black_stained_glass
setblock 244 128 264 minecraft:black_stained_glass
setblock 244 128 266 minecraft:black_stained_glass
setblock 244 128 268 minecraft:light_blue_stained_glass
setblock 249 128 230 minecraft:light_blue_stained_glass
setblock 249 128 232 minecraft:sea_lantern
setblock 249 128 265 minecraft:black_stained_glass
setblock 249 128 267 minecraft:black_stained_glass
setblock 250 128 229 minecraft:black_stained_glass
setblock 250 128 234 minecraft:black_stained_glass
setblock 250 128 264 minecraft:sea_lantern
setblock 250 128 269 minecraft:cyan_stained_glass
setblock 252 128 228 minecraft:verdant_froglight
setblock 252 128 229 minecraft:light_blue_stained_glass
setblock 252 128 234 minecraft:black_stained_glass
setblock 252 128 264 minecraft:black_stained_glass
setblock 252 128 269 minecraft:black_stained_glass
setblock 254 128 229 minecraft:black_stained_glass
setblock 254 128 234 minecraft:cyan_stained_glass
setblock 254 128 264 minecraft:black_stained_glass
setblock 254 128 269 minecraft:ochre_froglight
setblock 256 128 229 minecraft:light_blue_stained_glass
setblock 256 128 234 minecraft:black_stained_glass
setblock 256 128 264 minecraft:magenta_stained_glass
setblock 256 128 269 minecraft:cyan_stained_glass
setblock 257 128 270 minecraft:ochre_froglight
setblock 258 128 229 minecraft:ochre_froglight
setblock 258 128 234 minecraft:magenta_stained_glass
setblock 258 128 264 minecraft:black_stained_glass
setblock 258 128 269 minecraft:black_stained_glass
setblock 260 128 229 minecraft:black_stained_glass
setblock 260 128 234 minecraft:black_stained_glass
setblock 260 128 264 minecraft:ochre_froglight
setblock 260 128 269 minecraft:pearlescent_froglight
setblock 262 128 230 minecraft:black_stained_glass
setblock 262 128 232 minecraft:black_stained_glass
setblock 262 128 265 minecraft:pearlescent_froglight
setblock 262 128 267 minecraft:pearlescent_froglight
setblock 268 128 230 minecraft:black_stained_glass
setblock 268 128 232 minecraft:black_stained_glass
setblock 268 128 234 minecraft:magenta_stained_glass
setblock 268 128 236 minecraft:pearlescent_froglight
setblock 268 128 262 minecraft:magenta_stained_glass
setblock 268 128 264 minecraft:black_stained_glass
setblock 268 128 266 minecraft:black_stained_glass
setblock 268 128 268 minecraft:light_blue_stained_glass
setblock 269 128 229 minecraft:pearlescent_froglight
setblock 269 128 237 minecraft:black_stained_glass
setblock 269 128 261 minecraft:cyan_stained_glass
setblock 269 128 269 minecraft:black_stained_glass
setblock 271 128 229 minecraft:light_blue_stained_glass
setblock 271 128 237 minecraft:cyan_stained_glass
setblock 271 128 243 minecraft:black_stained_glass
setblock 271 128 245 minecraft:black_stained_glass
setblock 271 128 247 minecraft:black_stained_glass
setblock 271 128 249 minecraft:black_stained_glass
setblock 271 128 251 minecraft:pearlescent_froglight
setblock 271 128 253 minecraft:cyan_stained_glass
setblock 271 128 261 minecraft:cyan_stained_glass
setblock 271 128 269 minecraft:magenta_stained_glass
setblock 272 128 242 minecraft:magenta_stained_glass
setblock 272 128 255 minecraft:light_blue_stained_glass
setblock 273 128 229 minecraft:black_stained_glass
setblock 273 128 237 minecraft:black_stained_glass
setblock 273 128 261 minecraft:black_stained_glass
setblock 273 128 269 minecraft:sea_lantern
setblock 274 128 242 minecraft:cyan_stained_glass
setblock 274 128 255 minecraft:ochre_froglight
setblock 275 128 229 minecraft:black_stained_glass
setblock 275 128 237 minecraft:black_stained_glass
setblock 275 128 261 minecraft:magenta_stained_glass
setblock 275 128 269 minecraft:magenta_stained_glass
setblock 276 128 230 minecraft:black_stained_glass
setblock 276 128 232 minecraft:black_stained_glass
setblock 276 128 234 minecraft:black_stained_glass
setblock 276 128 236 minecraft:light_blue_stained_glass
setblock 276 128 243 minecraft:cyan_stained_glass
setblock 276 128 245 minecraft:sea_lantern
setblock 276 128 247 minecraft:black_stained_glass
setblock 276 128 249 minecraft:pearlescent_froglight
setblock 276 128 251 minecraft:magenta_stained_glass
setblock 276 128 253 minecraft:magenta_stained_glass
setblock 276 128 262 minecraft:magenta_stained_glass
setblock 276 128 264 minecraft:light_blue_stained_glass
setblock 276 128 266 minecraft:light_blue_stained_glass
setblock 276 128 268 minecraft:black_stained_glass
fill 235 129 269 235 308 269 minecraft:black_concrete
fill 236 129 230 236 130 230 minecraft:gray_concrete
fill 236 129 232 236 130 232 minecraft:gray_concrete
fill 236 129 234 236 130 234 minecraft:gray_concrete
fill 236 129 236 236 130 236 minecraft:gray_concrete
fill 236 129 243 236 130 243 minecraft:black_concrete
fill 236 129 245 236 130 245 minecraft:black_concrete
fill 236 129 247 236 130 247 minecraft:black_concrete
fill 236 129 249 236 130 249 minecraft:black_concrete
fill 236 129 251 236 130 251 minecraft:black_concrete
fill 236 129 253 236 130 253 minecraft:black_concrete
fill 236 129 262 236 130 262 minecraft:blue_terracotta
fill 236 129 264 236 130 264 minecraft:blue_terracotta
fill 236 129 266 236 130 266 minecraft:blue_terracotta
fill 236 129 268 236 130 268 minecraft:blue_terracotta
fill 237 129 229 237 130 229 minecraft:gray_concrete
fill 237 129 237 237 130 237 minecraft:gray_concrete
fill 237 129 242 237 130 242 minecraft:black_concrete
fill 237 129 255 237 130 255 minecraft:black_concrete
fill 237 129 261 237 130 261 minecraft:blue_terracotta
fill 237 129 269 237 130 269 minecraft:blue_terracotta
setblock 238 129 239 minecraft:light[level=15]
fill 239 129 229 239 130 229 minecraft:gray_concrete
fill 239 129 237 239 130 237 minecraft:gray_concrete
fill 239 129 242 239 130 242 minecraft:black_concrete
fill 239 129 255 239 130 255 minecraft:black_concrete
fill 239 129 261 239 130 261 minecraft:blue_terracotta
fill 239 129 269 239 130 269 minecraft:blue_terracotta
fill 241 129 229 241 130 229 minecraft:gray_concrete
fill 241 129 237 241 130 237 minecraft:gray_concrete
fill 241 129 243 241 130 243 minecraft:black_concrete
fill 241 129 245 241 130 245 minecraft:black_concrete
fill 241 129 247 241 130 247 minecraft:black_concrete
fill 241 129 249 241 130 249 minecraft:black_concrete
fill 241 129 251 241 130 251 minecraft:black_concrete
fill 241 129 253 241 130 253 minecraft:black_concrete
fill 241 129 261 241 130 261 minecraft:blue_terracotta
fill 241 129 269 241 130 269 minecraft:blue_terracotta
fill 243 129 229 243 130 229 minecraft:gray_concrete
fill 243 129 237 243 130 237 minecraft:gray_concrete
fill 243 129 261 243 130 261 minecraft:blue_terracotta
fill 243 129 269 243 130 269 minecraft:blue_terracotta
fill 244 129 230 244 130 230 minecraft:gray_concrete
fill 244 129 232 244 130 232 minecraft:gray_concrete
fill 244 129 234 244 130 234 minecraft:gray_concrete
fill 244 129 236 244 130 236 minecraft:gray_concrete
fill 244 129 262 244 130 262 minecraft:blue_terracotta
fill 244 129 264 244 130 264 minecraft:blue_terracotta
fill 244 129 266 244 130 266 minecraft:blue_terracotta
fill 244 129 268 244 130 268 minecraft:blue_terracotta
setblock 246 129 228 minecraft:magenta_concrete
setblock 246 129 231 minecraft:light[level=15]
setblock 246 129 239 minecraft:light[level=15]
setblock 246 129 247 minecraft:light[level=15]
setblock 246 129 255 minecraft:light[level=15]
setblock 246 129 263 minecraft:light[level=15]
fill 249 129 230 249 130 230 minecraft:gray_concrete
fill 249 129 232 249 130 232 minecraft:gray_concrete
fill 249 129 265 249 130 265 minecraft:gray_concrete
fill 249 129 267 249 130 267 minecraft:gray_concrete
fill 250 129 229 250 130 229 minecraft:gray_concrete
fill 250 129 234 250 130 234 minecraft:gray_concrete
fill 250 129 264 250 130 264 minecraft:gray_concrete
fill 250 129 269 250 130 269 minecraft:gray_concrete
fill 252 129 228 252 151 228 minecraft:black_concrete
fill 252 129 229 252 130 229 minecraft:gray_concrete
fill 252 129 234 252 130 234 minecraft:gray_concrete
fill 252 129 264 252 130 264 minecraft:gray_concrete
fill 252 129 269 252 130 269 minecraft:gray_concrete
fill 254 129 229 254 130 229 minecraft:gray_concrete
fill 254 129 234 254 130 234 minecraft:gray_concrete
setblock 254 129 239 minecraft:light[level=15]
setblock 254 129 247 minecraft:light[level=15]
setblock 254 129 255 minecraft:light[level=15]
setblock 254 129 263 minecraft:light[level=15]
fill 254 129 264 254 130 264 minecraft:gray_concrete
fill 254 129 269 254 130 269 minecraft:gray_concrete
fill 256 129 229 256 130 229 minecraft:gray_concrete
fill 256 129 234 256 130 234 minecraft:gray_concrete
fill 256 129 264 256 130 264 minecraft:gray_concrete
fill 256 129 269 256 130 269 minecraft:gray_concrete
fill 257 129 270 257 202 270 minecraft:black_concrete
fill 258 129 229 258 130 229 minecraft:gray_concrete
fill 258 129 234 258 130 234 minecraft:gray_concrete
fill 258 129 264 258 130 264 minecraft:gray_concrete
fill 258 129 269 258 130 269 minecraft:gray_concrete
fill 260 129 229 260 130 229 minecraft:gray_concrete
fill 260 129 234 260 130 234 minecraft:gray_concrete
fill 260 129 264 260 130 264 minecraft:gray_concrete
fill 260 129 269 260 130 269 minecraft:gray_concrete
fill 262 129 230 262 130 230 minecraft:gray_concrete
fill 262 129 232 262 130 232 minecraft:gray_concrete
setblock 262 129 239 minecraft:light[level=15]
setblock 262 129 247 minecraft:light[level=15]
setblock 262 129 255 minecraft:light[level=15]
setblock 262 129 263 minecraft:light[level=15]
fill 262 129 265 262 130 265 minecraft:gray_concrete
fill 262 129 267 262 130 267 minecraft:gray_concrete
fill 268 129 230 268 130 230 minecraft:blue_terracotta
fill 268 129 232 268 130 232 minecraft:blue_terracotta
fill 268 129 234 268 130 234 minecraft:blue_terracotta
fill 268 129 236 268 130 236 minecraft:blue_terracotta
fill 268 129 262 268 130 262 minecraft:gray_concrete
fill 268 129 264 268 130 264 minecraft:gray_concrete
fill 268 129 266 268 130 266 minecraft:gray_concrete
fill 268 129 268 268 130 268 minecraft:gray_concrete
fill 269 129 229 269 130 229 minecraft:blue_terracotta
fill 269 129 237 269 130 237 minecraft:blue_terracotta
fill 269 129 261 269 130 261 minecraft:gray_concrete
fill 269 129 269 269 130 269 minecraft:gray_concrete
setblock 270 129 239 minecraft:light[level=15]
setblock 270 129 247 minecraft:light[level=15]
setblock 270 129 255 minecraft:light[level=15]
fill 271 129 229 271 130 229 minecraft:blue_terracotta
fill 271 129 237 271 130 237 minecraft:blue_terracotta
fill 271 129 243 271 130 243 minecraft:gray_concrete
fill 271 129 245 271 130 245 minecraft:gray_concrete
fill 271 129 247 271 130 247 minecraft:gray_concrete
fill 271 129 249 271 130 249 minecraft:gray_concrete
fill 271 129 251 271 130 251 minecraft:gray_concrete
fill 271 129 253 271 130 253 minecraft:gray_concrete
fill 271 129 261 271 130 261 minecraft:gray_concrete
fill 271 129 269 271 130 269 minecraft:gray_concrete
fill 272 129 242 272 130 242 minecraft:gray_concrete
fill 272 129 255 272 130 255 minecraft:gray_concrete
fill 273 129 229 273 130 229 minecraft:blue_terracotta
fill 273 129 237 273 130 237 minecraft:blue_terracotta
fill 273 129 261 273 130 261 minecraft:gray_concrete
fill 273 129 269 273 130 269 minecraft:gray_concrete
fill 274 129 242 274 130 242 minecraft:gray_concrete
fill 274 129 255 274 130 255 minecraft:gray_concrete
fill 275 129 229 275 130 229 minecraft:blue_terracotta
fill 275 129 237 275 130 237 minecraft:blue_terracotta
fill 275 129 261 275 130 261 minecraft:gray_concrete
fill 275 129 269 275 130 269 minecraft:gray_concrete
fill 276 129 230 276 130 230 minecraft:blue_terracotta
fill 276 129 232 276 130 232 minecraft:blue_terracotta
fill 276 129 234 276 130 234 minecraft:blue_terracotta
fill 276 129 236 276 130 236 minecraft:blue_terracotta
fill 276 129 243 276 130 243 minecraft:gray_concrete
fill 276 129 245 276 130 245 minecraft:gray_concrete
fill 276 129 247 276 130 247 minecraft:gray_concrete
fill 276 129 249 276 130 249 minecraft:gray_concrete
fill 276 129 251 276 130 251 minecraft:gray_concrete
fill 276 129 253 276 130 253 minecraft:gray_concrete
fill 276 129 262 276 130 262 minecraft:gray_concrete
fill 276 129 264 276 130 264 minecraft:gray_concrete
fill 276 129 266 276 130 266 minecraft:gray_concrete
fill 276 129 268 276 130 268 minecraft:gray_concrete
setblock 277 129 237 minecraft:cyan_concrete
setblock 235 130 248 minecraft:sea_lantern
fill 237 130 238 237 131 241 minecraft:iron_block
fill 244 130 228 244 141 228 minecraft:black_concrete
setblock 245 130 228 minecraft:ochre_froglight
fill 246 130 228 246 133 228 minecraft:black_concrete
setblock 248 130 228 minecraft:pearlescent_froglight
fill 256 130 228 257 139 228 minecraft:black_concrete
setblock 258 130 228 minecraft:purple_concrete
setblock 264 130 228 minecraft:cyan_concrete
fill 265 130 228 267 171 228 minecraft:black_concrete
fill 277 130 237 277 134 237 minecraft:black_concrete
setblock 235 131 244 minecraft:cyan_concrete
fill 235 131 245 235 164 245 minecraft:black_concrete
fill 235 131 248 235 174 248 minecraft:black_concrete
setblock 236 131 230 minecraft:black_stained_glass
setblock 236 131 232 minecraft:ochre_froglight
setblock 236 131 234 minecraft:black_stained_glass
setblock 236 131 236 minecraft:black_stained_glass
setblock 236 131 243 minecraft:magenta_stained_glass
setblock 236 131 245 minecraft:black_stained_glass
setblock 236 131 247 minecraft:light_blue_stained_glass
setblock 236 131 249 minecraft:black_stained_glass
setblock 236 131 251 minecraft:cyan_stained_glass
setblock 236 131 253 minecraft:ochre_froglight
setblock 236 131 262 minecraft:black_stained_glass
setblock 236 131 264 minecraft:cyan_stained_glass
setblock 236 131 266 minecraft:black_stained_glass
setblock 236 131 268 minecraft:black_stained_glass
setblock 237 131 229 minecraft:black_stained_glass
setblock 237 131 237 minecraft:magenta_stained_glass
setblock 237 131 242 minecraft:cyan_stained_glass
setblock 237 131 255 minecraft:black_stained_glass
setblock 237 131 261 minecraft:light_blue_stained_glass
setblock 237 131 269 minecraft:light_blue_stained_glass
setblock 239 131 229 minecraft:pearlescent_froglight
setblock 239 131 237 minecraft:cyan_stained_glass
setblock 239 131 242 minecraft:black_stained_glass
setblock 239 131 255 minecraft:ochre_froglight
setblock 239 131 261 minecraft:black_stained_glass
setblock 239 131 269 minecraft:light_blue_stained_glass
setblock 241 131 229 minecraft:cyan_stained_glass
setblock 241 131 237 minecraft:ochre_froglight
setblock 241 131 243 minecraft:black_stained_glass
setblock 241 131 245 minecraft:pearlescent_froglight
setblock 241 131 247 minecraft:pearlescent_froglight
setblock 241 131 249 minecraft:cyan_stained_glass
setblock 241 131 251 minecraft:black_stained_glass
setblock 241 131 253 minecraft:ochre_froglight
setblock 241 131 261 minecraft:black_stained_glass
setblock 241 131 269 minecraft:magenta_stained_glass
setblock 243 131 229 minecraft:sea_lantern
setblock 243 131 237 minecraft:ochre_froglight
setblock 243 131 261 minecraft:pearlescent_froglight
setblock 243 131 269 minecraft:black_stained_glass
setblock 244 131 230 minecraft:sea_lantern
setblock 244 131 232 minecraft:pearlescent_froglight
setblock 244 131 234 minecraft:pearlescent_froglight
setblock 244 131 236 minecraft:light_blue_stained_glass
setblock 244 131 262 minecraft:black_stained_glass
setblock 244 131 264 minecraft:black_stained_glass
setblock 244 131 266 minecraft:sea_lantern
setblock 244 131 268 minecraft:black_stained_glass
fill 245 131 228 245 163 228 minecraft:black_concrete
fill 248 131 228 248 146 228 minecraft:black_concrete
setblock 249 131 230 minecraft:ochre_froglight
setblock 249 131 232 minecraft:pearlescent_froglight
setblock 249 131 265 minecraft:black_stained_glass
setblock 249 131 267 minecraft:ochre_froglight
setblock 250 131 229 minecraft:black_stained_glass
setblock 250 131 234 minecraft:magenta_stained_glass
setblock 250 131 264 minecraft:sea_lantern
setblock 250 131 269 minecraft:ochre_froglight
setblock 251 131 270 minecraft:magenta_concrete
setblock 252 131 229 minecraft:pearlescent_froglight
setblock 252 131 234 minecraft:pearlescent_froglight
setblock 252 131 264 minecraft:black_stained_glass
setblock 252 131 269 minecraft:black_stained_glass
setblock 254 131 229 minecraft:ochre_froglight
setblock 254 131 234 minecraft:black_stained_glass
setblock 254 131 264 minecraft:pearlescent_froglight
setblock 254 131 269 minecraft:black_stained_glass
setblock 256 131 229 minecraft:black_stained_glass
setblock 256 131 234 minecraft:pearlescent_froglight
setblock 256 131 264 minecraft:black_stained_glass
setblock 256 131 269 minecraft:black_stained_glass
fill 258 131 228 258 167 228 minecraft:black_concrete
setblock 258 131 229 minecraft:black_stained_glass
setblock 258 131 234 minecraft:black_stained_glass
setblock 258 131 264 minecraft:pearlescent_froglight
setblock 258 131 269 minecraft:magenta_stained_glass
setblock 260 131 229 minecraft:black_stained_glass
setblock 260 131 234 minecraft:pearlescent_froglight
setblock 260 131 264 minecraft:black_stained_glass
setblock 260 131 269 minecraft:cyan_stained_glass
setblock 262 131 230 minecraft:black_stained_glass
setblock 262 131 232 minecraft:sea_lantern
setblock 262 131 265 minecraft:pearlescent_froglight
setblock 262 131 267 minecraft:sea_lantern
fill 264 131 228 264 136 228 minecraft:black_concrete
setblock 268 131 230 minecraft:sea_lantern
setblock 268 131 232 minecraft:cyan_stained_glass
setblock 268 131 234 minecraft:magenta_stained_glass
setblock 268 131 236 minecraft:light_blue_stained_glass
setblock 268 131 262 minecraft:black_stained_glass
setblock 268 131 264 minecraft:light_blue_stained_glass
setblock 268 131 266 minecraft:black_stained_glass
setblock 268 131 268 minecraft:black_stained_glass
setblock 269 131 229 minecraft:black_stained_glass
setblock 269 131 237 minecraft:light_blue_stained_glass
setblock 269 131 261 minecraft:sea_lantern
setblock 269 131 269 minecraft:black_stained_glass
setblock 271 131 229 minecraft:pearlescent_froglight
setblock 271 131 237 minecraft:magenta_stained_glass
setblock 271 131 243 minecraft:pearlescent_froglight
setblock 271 131 245 minecraft:cyan_stained_glass
setblock 271 131 247 minecraft:black_stained_glass
setblock 271 131 249 minecraft:cyan_stained_glass
setblock 271 131 251 minecraft:cyan_stained_glass
setblock 271 131 253 minecraft:black_stained_glass
setblock 271 131 261 minecraft:pearlescent_froglight
setblock 271 131 269 minecraft:black_stained_glass
setblock 272 131 242 minecraft:sea_lantern
setblock 272 131 255 minecraft:magenta_stained_glass
setblock 273 131 229 minecraft:cyan_stained_glass
setblock 273 131 237 minecraft:sea_lantern
setblock 273 131 261 minecraft:black_stained_glass
setblock 273 131 269 minecraft:sea_lantern
setblock 274 131 242 minecraft:pearlescent_froglight
setblock 274 131 255 minecraft:ochre_froglight
setblock 275 131 229 minecraft:black_stained_glass
setblock 275 131 237 minecraft:ochre_froglight
setblock 275 131 261 minecraft:cyan_stained_glass
setblock 275 131 269 minecraft:ochre_froglight
setblock 276 131 230 minecraft:ochre_froglight
setblock 276 131 232 minecraft:black_stained_glass
setblock 276 131 234 minecraft:sea_lantern
setblock 276 131 236 minecraft:magenta_stained_glass
setblock 276 131 243 minecraft:black_stained_glass
setblock 276 131 245 minecraft:light_blue_stained_glass
setblock 276 131 247 minecraft:pearlescent_froglight
setblock 276 131 249 minecraft:cyan_stained_glass
setblock 276 131 251 minecraft:light_blue_stained_glass
setblock 276 131 253 minecraft:sea_lantern
setblock 276 131 262 minecraft:ochre_froglight
setblock 276 131 264 minecraft:black_stained_glass
setblock 276 131 266 minecraft:black_stained_glass
setblock 276 131 268 minecraft:black_stained_glass
setblock 277 131 255 minecraft:verdant_froglight
fill 235 132 244 235 176 244 minecraft:black_concrete
setblock 235 132 253 minecraft:pearlescent_froglight
fill 236 132 230 236 133 230 minecraft:gray_concrete
fill 236 132 232 236 133 232 minecraft:gray_concrete
fill 236 132 234 236 133 234 minecraft:gray_concrete
fill 236 132 236 236 133 236 minecraft:gray_concrete
fill 236 132 243 236 133 243 minecraft:black_concrete
fill 236 132 245 236 133 245 minecraft:black_concrete
fill 236 132 247 236 133 247 minecraft:black_concrete
fill 236 132 249 236 133 249 minecraft:black_concrete
fill 236 132 251 236 133 251 minecraft:black_concrete
fill 236 132 253 236 133 253 minecraft:black_concrete
fill 236 132 262 236 133 262 minecraft:blue_terracotta
fill 236 132 264 236 133 264 minecraft:blue_terracotta
fill 236 132 266 236 133 266 minecraft:blue_terracotta
fill 236 132 268 236 133 268 minecraft:blue_terracotta
fill 237 132 229 237 133 229 minecraft:gray_concrete
fill 237 132 237 237 133 237 minecraft:gray_concrete
fill 237 132 242 237 133 242 minecraft:black_concrete
fill 237 132 255 237 133 255 minecraft:black_concrete
fill 237 132 261 237 133 261 minecraft:blue_terracotta
fill 237 132 269 237 133 269 minecraft:blue_terracotta
fill 239 132 229 239 133 229 minecraft:gray_concrete
fill 239 132 237 239 133 237 minecraft:gray_concrete
fill 239 132 242 239 133 242 minecraft:black_concrete
fill 239 132 255 239 133 255 minecraft:black_concrete
fill 239 132 261 239 133 261 minecraft:blue_terracotta
fill 239 132 269 239 133 269 minecraft:blue_terracotta
fill 241 132 229 241 133 229 minecraft:gray_concrete
fill 241 132 237 241 133 237 minecraft:gray_concrete
fill 241 132 243 241 133 243 minecraft:black_concrete
fill 241 132 245 241 133 245 minecraft:black_concrete
fill 241 132 247 241 133 247 minecraft:black_concrete
fill 241 132 249 241 133 249 minecraft:black_concrete
fill 241 132 251 241 133 251 minecraft:black_concrete
fill 241 132 253 241 133 253 minecraft:black_concrete
fill 241 132 261 241 133 261 minecraft:blue_terracotta
fill 241 132 269 241 133 269 minecraft:blue_terracotta
fill 243 132 229 243 133 229 minecraft:gray_concrete
fill 243 132 237 243 133 237 minecraft:gray_concrete
fill 243 132 261 243 133 261 minecraft:blue_terracotta
fill 243 132 269 243 133 269 minecraft:blue_terracotta
fill 244 132 230 244 133 230 minecraft:gray_concrete
fill 244 132 232 244 133 232 minecraft:gray_concrete
fill 244 132 234 244 133 234 minecraft:gray_concrete
fill 244 132 236 244 133 236 minecraft:gray_concrete
fill 244 132 262 244 133 262 minecraft:blue_terracotta
fill 244 132 264 244 133 264 minecraft:blue_terracotta
fill 244 132 266 244 133 266 minecraft:blue_terracotta
fill 244 132 268 244 133 268 minecraft:blue_terracotta
fill 249 132 230 249 133 230 minecraft:gray_concrete
fill 249 132 232 249 133 232 minecraft:gray_concrete
fill 249 132 265 249 133 265 minecraft:gray_concrete
fill 249 132 267 249 133 267 minecraft:gray_concrete
fill 250 132 229 250 133 229 minecraft:gray_concrete
fill 250 132 234 250 133 234 minecraft:gray_concrete
fill 250 132 264 250 133 264 minecraft:gray_concrete
fill 250 132 269 250 133 269 minecraft:gray_concrete
fill 251 132 270 251 140 270 minecraft:black_concrete
fill 252 132 229 252 133 229 minecraft:gray_concrete
fill 252 132 234 252 133 234 minecraft:gray_concrete
fill 252 132 264 252 133 264 minecraft:gray_concrete
fill 252 132 269 252 133 269 minecraft:gray_concrete
fill 254 132 229 254 133 229 minecraft:gray_concrete
fill 254 132 234 254 133 234 minecraft:gray_concrete
fill 254 132 264 254 133 264 minecraft:gray_concrete
fill 254 132 269 254 133 269 minecraft:gray_concrete
fill 256 132 229 256 133 229 minecraft:gray_concrete
fill 256 132 234 256 133 234 minecraft:gray_concrete
fill 256 132 264 256 133 264 minecraft:gray_concrete
fill 256 132 269 256 133 269 minecraft:gray_concrete
fill 258 132 229 258 133 229 minecraft:gray_concrete
fill 258 132 234 258 133 234 minecraft:gray_concrete
fill 258 132 264 258 133 264 minecraft:gray_concrete
fill 258 132 269 258 133 269 minecraft:gray_concrete
fill 260 132 229 260 133 229 minecraft:gray_concrete
fill 260 132 234 260 133 234 minecraft:gray_concrete
fill 260 132 264 260 133 264 minecraft:gray_concrete
fill 260 132 269 260 133 269 minecraft:gray_concrete
fill 262 132 230 262 133 230 minecraft:gray_concrete
fill 262 132 232 262 133 232 minecraft:gray_concrete
fill 262 132 265 262 133 265 minecraft:gray_concrete
fill 262 132 267 262 133 267 minecraft:gray_concrete
fill 268 132 230 268 133 230 minecraft:blue_terracotta
fill 268 132 232 268 133 232 minecraft:blue_terracotta
fill 268 132 234 268 133 234 minecraft:blue_terracotta
fill 268 132 236 268 133 236 minecraft:blue_terracotta
fill 268 132 262 268 133 262 minecraft:gray_concrete
fill 268 132 264 268 133 264 minecraft:gray_concrete
fill 268 132 266 268 133 266 minecraft:gray_concrete
fill 268 132 268 268 133 268 minecraft:gray_concrete
fill 269 132 229 269 133 229 minecraft:blue_terracotta
fill 269 132 237 269 133 237 minecraft:blue_terracotta
fill 269 132 261 269 133 261 minecraft:gray_concrete
fill 269 132 269 269 133 269 minecraft:gray_concrete
fill 271 132 229 271 133 229 minecraft:blue_terracotta
fill 271 132 237 271 133 237 minecraft:blue_terracotta
fill 271 132 243 271 133 243 minecraft:gray_concrete
fill 271 132 245 271 133 245 minecraft:gray_concrete
fill 271 132 247 271 133 247 minecraft:gray_concrete
fill 271 132 249 271 133 249 minecraft:gray_concrete
fill 271 132 251 271 133 251 minecraft:gray_concrete
fill 271 132 253 271 133 253 minecraft:gray_concrete
fill 271 132 261 271 133 261 minecraft:gray_concrete
fill 271 132 269 271 133 269 minecraft:gray_concrete
fill 272 132 242 272 133 242 minecraft:gray_concrete
fill 272 132 255 272 133 255 minecraft:gray_concrete
fill 273 132 229 273 133 229 minecraft:blue_terracotta
fill 273 132 237 273 133 237 minecraft:blue_terracotta
fill 273 132 261 273 133 261 minecraft:gray_concrete
fill 273 132 269 273 133 269 minecraft:gray_concrete
fill 274 132 242 274 133 242 minecraft:gray_concrete
fill 274 132 255 274 133 255 minecraft:gray_concrete
fill 275 132 229 275 133 229 minecraft:blue_terracotta
fill 275 132 237 275 133 237 minecraft:blue_terracotta
fill 275 132 261 275 133 261 minecraft:gray_concrete
fill 275 132 269 275 133 269 minecraft:gray_concrete
fill 276 132 230 276 133 230 minecraft:blue_terracotta
fill 276 132 232 276 133 232 minecraft:blue_terracotta
fill 276 132 234 276 133 234 minecraft:blue_terracotta
fill 276 132 236 276 133 236 minecraft:blue_terracotta
fill 276 132 243 276 133 243 minecraft:gray_concrete
fill 276 132 245 276 133 245 minecraft:gray_concrete
fill 276 132 247 276 133 247 minecraft:gray_concrete
fill 276 132 249 276 133 249 minecraft:gray_concrete
fill 276 132 251 276 133 251 minecraft:gray_concrete
fill 276 132 253 276 133 253 minecraft:gray_concrete
fill 276 132 262 276 133 262 minecraft:gray_concrete
fill 276 132 264 276 133 264 minecraft:gray_concrete
fill 276 132 266 276 133 266 minecraft:gray_concrete
fill 276 132 268 276 133 268 minecraft:gray_concrete
setblock 277 132 240 minecraft:blue_concrete
fill 277 132 255 277 135 255 minecraft:black_concrete
fill 235 133 253 235 153 253 minecraft:black_concrete
setblock 238 133 238 minecraft:light[level=12]
setblock 238 133 259 minecraft:light[level=12]
setblock 245 133 231 minecraft:light[level=12]
setblock 245 133 238 minecraft:light[level=12]
setblock 245 133 245 minecraft:light[level=12]
setblock 245 133 252 minecraft:light[level=12]
setblock 245 133 259 minecraft:light[level=12]
setblock 245 133 266 minecraft:light[level=12]
setblock 250 133 270 minecraft:verdant_froglight
setblock 252 133 238 minecraft:light[level=12]
setblock 252 133 245 minecraft:light[level=12]
setblock 252 133 252 minecraft:light[level=12]
setblock 252 133 259 minecraft:light[level=12]
setblock 259 133 238 minecraft:light[level=12]
setblock 259 133 245 minecraft:light[level=12]
setblock 259 133 252 minecraft:light[level=12]
setblock 259 133 259 minecraft:light[level=12]
setblock 266 133 231 minecraft:light[level=12]
setblock 266 133 238 minecraft:light[level=12]
setblock 266 133 245 minecraft:light[level=12]
setblock 266 133 252 minecraft:light[level=12]
setblock 266 133 259 minecraft:light[level=12]
setblock 266 133 266 minecraft:light[level=12]
setblock 272 133 228 minecraft:pearlescent_froglight
setblock 273 133 238 minecraft:light[level=12]
setblock 273 133 259 minecraft:light[level=12]
fill 277 133 240 277 135 240 minecraft:black_concrete
setblock 235 134 261 minecraft:verdant_froglight
setblock 236 134 230 minecraft:magenta_stained_glass
setblock 236 134 232 minecraft:sea_lantern
setblock 236 134 234 minecraft:black_stained_glass
setblock 236 134 236 minecraft:ochre_froglight
setblock 236 134 243 minecraft:black_stained_glass
setblock 236 134 245 minecraft:cyan_stained_glass
setblock 236 134 247 minecraft:sea_lantern
setblock 236 134 249 minecraft:ochre_froglight
setblock 236 134 251 minecraft:cyan_stained_glass
setblock 236 134 253 minecraft:black_stained_glass
setblock 236 134 262 minecraft:magenta_stained_glass
setblock 236 134 264 minecraft:magenta_stained_glass
setblock 236 134 266 minecraft:cyan_stained_glass
setblock 236 134 268 minecraft:ochre_froglight
setblock 237 134 229 minecraft:black_stained_glass
setblock 237 134 237 minecraft:light_blue_stained_glass
setblock 237 134 242 minecraft:ochre_froglight
setblock 237 134 255 minecraft:black_stained_glass
setblock 237 134 261 minecraft:sea_lantern
setblock 237 134 269 minecraft:cyan_stained_glass
setblock 239 134 229 minecraft:black_stained_glass
setblock 239 134 237 minecraft:cyan_stained_glass
setblock 239 134 242 minecraft:black_stained_glass
setblock 239 134 255 minecraft:magenta_stained_glass
setblock 239 134 261 minecraft:ochre_froglight
setblock 239 134 269 minecraft:black_stained_glass
setblock 241 134 229 minecraft:cyan_stained_glass
setblock 241 134 237 minecraft:ochre_froglight
setblock 241 134 243 minecraft:black_stained_glass
setblock 241 134 245 minecraft:magenta_stained_glass
setblock 241 134 247 minecraft:black_stained_glass
setblock 241 134 249 minecraft:cyan_stained_glass
setblock 241 134 251 minecraft:black_stained_glass
setblock 241 134 253 minecraft:light_blue_stained_glass
setblock 241 134 261 minecraft:sea_lantern
setblock 241 134 269 minecraft:sea_lantern
setblock 243 134 229 minecraft:magenta_stained_glass
setblock 243 134 237 minecraft:black_stained_glass
setblock 243 134 261 minecraft:ochre_froglight
setblock 243 134 269 minecraft:black_stained_glass
setblock 244 134 230 minecraft:light_blue_stained_glass
setblock 244 134 232 minecraft:sea_lantern
setblock 244 134 234 minecraft:black_stained_glass
setblock 244 134 236 minecraft:black_stained_glass
setblock 244 134 262 minecraft:light_blue_stained_glass
setblock 244 134 264 minecraft:light_blue_stained_glass
setblock 244 134 266 minecraft:light_blue_stained_glass
setblock 244 134 268 minecraft:cyan_stained_glass
setblock 246 134 228 minecraft:pearlescent_froglight
setblock 249 134 230 minecraft:black_stained_glass
setblock 249 134 232 minecraft:light_blue_stained_glass
setblock 249 134 265 minecraft:ochre_froglight
setblock 249 134 267 minecraft:pearlescent_froglight
setblock 250 134 229 minecraft:cyan_stained_glass
setblock 250 134 234 minecraft:black_stained_glass
setblock 250 134 264 minecraft:black_stained_glass
setblock 250 134 269 minecraft:sea_lantern
fill 250 134 270 250 195 270 minecraft:black_concrete
setblock 251 134 228 minecraft:pearlescent_froglight
setblock 252 134 229 minecraft:light_blue_stained_glass
setblock 252 134 234 minecraft:black_stained_glass
setblock 252 134 264 minecraft:black_stained_glass
setblock 252 134 269 minecraft:pearlescent_froglight
setblock 254 134 229 minecraft:black_stained_glass
setblock 254 134 234 minecraft:black_stained_glass
setblock 254 134 264 minecraft:cyan_stained_glass
setblock 254 134 269 minecraft:magenta_stained_glass
setblock 256 134 229 minecraft:black_stained_glass
setblock 256 134 234 minecraft:black_stained_glass
setblock 256 134 264 minecraft:magenta_stained_glass
setblock 256 134 269 minecraft:black_stained_glass
setblock 258 134 229 minecraft:black_stained_glass
setblock 258 134 234 minecraft:black_stained_glass
setblock 258 134 264 minecraft:magenta_stained_glass
setblock 258 134 269 minecraft:black_stained_glass
setblock 260 134 229 minecraft:magenta_stained_glass
setblock 260 134 234 minecraft:ochre_froglight
setblock 260 134 264 minecraft:black_stained_glass
setblock 260 134 269 minecraft:sea_lantern
setblock 262 134 230 minecraft:black_stained_glass
setblock 262 134 232 minecraft:ochre_froglight
setblock 262 134 265 minecraft:black_stained_glass
setblock 262 134 267 minecraft:black_stained_glass
setblock 268 134 230 minecraft:black_stained_glass
setblock 268 134 232 minecraft:black_stained_glass
setblock 268 134 234 minecraft:pearlescent_froglight
setblock 268 134 236 minecraft:black_stained_glass
setblock 268 134 262 minecraft:cyan_stained_glass
setblock 268 134 264 minecraft:black_stained_glass
setblock 268 134 266 minecraft:black_stained_glass
setblock 268 134 268 minecraft:cyan_stained_glass
setblock 269 134 229 minecraft:light_blue_stained_glass
setblock 269 134 237 minecraft:black_stained_glass
setblock 269 134 261 minecraft:cyan_stained_glass
setblock 269 134 269 minecraft:black_stained_glass
setblock 271 134 229 minecraft:black_stained_glass
setblock 271 134 237 minecraft:ochre_froglight
setblock 271 134 243 minecraft:black_stained_glass
setblock 271 134 245 minecraft:black_stained_glass
setblock 271 134 247 minecraft:black_stained_glass
setblock 271 134 249 minecraft:cyan_stained_glass
setblock 271 134 251 minecraft:light_blue_stained_glass
setblock 271 134 253 minecraft:light_blue_stained_glass
setblock 271 134 261 minecraft:light_blue_stained_glass
setblock 271 134 269 minecraft:black_stained_glass
fill 272 134 228 272 265 228 minecraft:black_concrete
setblock 272 134 242 minecraft:magenta_stained_glass
setblock 272 134 255 minecraft:ochre_froglight
setblock 273 134 229 minecraft:black_stained_glass
setblock 273 134 237 minecraft:sea_lantern
setblock 273 134 261 minecraft:sea_lantern
setblock 273 134 269 minecraft:cyan_stained_glass
setblock 274 134 242 minecraft:light_blue_stained_glass
setblock 274 134 255 minecraft:ochre_froglight
setblock 275 134 229 minecraft:light_blue_stained_glass
setblock 275 134 237 minecraft:black_stained_glass
setblock 275 134 261 minecraft:black_stained_glass
setblock 275 134 269 minecraft:ochre_froglight
setblock 276 134 230 minecraft:ochre_froglight
setblock 276 134 232 minecraft:black_stained_glass
setblock 276 134 234 minecraft:pearlescent_froglight
setblock 276 134 236 minecraft:black_stained_glass
setblock 276 134 243 minecraft:black_stained_glass
setblock 276 134 245 minecraft:magenta_stained_glass
setblock 276 134 247 minecraft:black_stained_glass
setblock 276 134 249 minecraft:black_stained_glass
setblock 276 134 251 minecraft:cyan_stained_glass
setblock 276 134 253 minecraft:black_stained_glass
setblock 276 134 262 minecraft:sea_lantern
setblock 276 134 264 minecraft:black_stained_glass
setblock 276 134 266 minecraft:magenta_stained_glass
setblock 276 134 268 minecraft:ochre_froglight
setblock 277 134 268 minecraft:cyan_concrete
setblock 235 135 230 minecraft:cyan_concrete
setblock 235 135 241 minecraft:purple_concrete
fill 235 135 261 235 174 261 minecraft:black_concrete
fill 236 135 230 236 136 230 minecraft:gray_concrete
fill 236 135 232 236 136 232 minecraft:gray_concrete
fill 236 135 234 236 136 234 minecraft:gray_concrete
fill 236 135 236 236 136 236 minecraft:gray_concrete
fill 236 135 243 236 136 243 minecraft:black_concrete
fill 236 135 245 236 136 245 minecraft:black_concrete
fill 236 135 247 236 136 247 minecraft:black_concrete
fill 236 135 249 236 136 249 minecraft:black_concrete
fill 236 135 251 236 136 251 minecraft:black_concrete
fill 236 135 253 236 136 253 minecraft:black_concrete
fill 236 135 262 236 136 262 minecraft:blue_terracotta
fill 236 135 264 236 136 264 minecraft:blue_terracotta
fill 236 135 266 236 136 266 minecraft:blue_terracotta
fill 236 135 268 236 136 268 minecraft:blue_terracotta
fill 237 135 229 237 136 229 minecraft:gray_concrete
fill 237 135 237 237 136 237 minecraft:gray_concrete
fill 237 135 242 237 136 242 minecraft:black_concrete
fill 237 135 255 237 136 255 minecraft:black_concrete
fill 237 135 261 237 136 261 minecraft:blue_terracotta
fill 237 135 269 237 136 269 minecraft:blue_terracotta
fill 239 135 229 239 136 229 minecraft:gray_concrete
fill 239 135 237 239 136 237 minecraft:gray_concrete
fill 239 135 242 239 136 242 minecraft:black_concrete
fill 239 135 255 239 136 255 minecraft:black_concrete
fill 239 135 261 239 136 261 minecraft:blue_terracotta
fill 239 135 269 239 136 269 minecraft:blue_terracotta
fill 241 135 229 241 136 229 minecraft:gray_concrete
fill 241 135 237 241 136 237 minecraft:gray_concrete
fill 241 135 243 241 136 243 minecraft:black_concrete
fill 241 135 245 241 136 245 minecraft:black_concrete
fill 241 135 247 241 136 247 minecraft:black_concrete
fill 241 135 249 241 136 249 minecraft:black_concrete
fill 241 135 251 241 136 251 minecraft:black_concrete
fill 241 135 253 241 136 253 minecraft:black_concrete
fill 241 135 261 241 136 261 minecraft:blue_terracotta
fill 241 135 269 241 136 269 minecraft:blue_terracotta
fill 243 135 229 243 136 229 minecraft:gray_concrete
fill 243 135 237 243 136 237 minecraft:gray_concrete
fill 243 135 261 243 136 261 minecraft:blue_terracotta
fill 243 135 269 243 136 269 minecraft:blue_terracotta
fill 244 135 230 244 136 230 minecraft:gray_concrete
fill 244 135 232 244 136 232 minecraft:gray_concrete
fill 244 135 234 244 136 234 minecraft:gray_concrete
fill 244 135 236 244 136 236 minecraft:gray_concrete
fill 244 135 262 244 136 262 minecraft:blue_terracotta
fill 244 135 264 244 136 264 minecraft:blue_terracotta
fill 244 135 266 244 136 266 minecraft:blue_terracotta
fill 244 135 268 244 136 268 minecraft:blue_terracotta
fill 245 135 270 245 183 270 minecraft:black_concrete
fill 246 135 228 246 193 228 minecraft:black_concrete
setblock 246 135 270 minecraft:verdant_froglight
fill 249 135 230 249 136 230 minecraft:gray_concrete
fill 249 135 232 249 136 232 minecraft:gray_concrete
fill 249 135 265 249 136 265 minecraft:gray_concrete
schedule function dropper:buildpart/53_3 1t
