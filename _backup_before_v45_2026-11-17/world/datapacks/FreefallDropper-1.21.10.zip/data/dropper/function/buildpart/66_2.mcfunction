fill 320 130 275 320 133 275 minecraft:iron_block
fill 321 130 275 322 130 275 minecraft:gray_concrete
fill 323 130 275 323 133 275 minecraft:iron_block
setblock 324 130 275 minecraft:gray_concrete
fill 324 130 276 324 131 277 minecraft:iron_block
setblock 324 130 278 minecraft:gray_concrete
fill 324 130 279 324 133 279 minecraft:iron_block
setblock 324 130 292 minecraft:gray_concrete
fill 324 130 293 324 133 294 minecraft:iron_block
fill 324 130 295 324 130 296 minecraft:gray_concrete
fill 324 130 297 324 133 299 minecraft:iron_block
setblock 324 130 302 minecraft:gray_concrete
setblock 324 130 315 minecraft:gray_concrete
fill 282 131 275 282 132 275 minecraft:gray_concrete
fill 282 131 276 282 133 280 minecraft:iron_block
fill 282 131 285 282 133 286 minecraft:iron_block
setblock 282 131 287 minecraft:gray_concrete
fill 282 131 288 282 133 289 minecraft:iron_block
fill 282 131 293 282 133 293 minecraft:iron_block
fill 282 131 312 282 134 312 minecraft:iron_block
fill 285 131 275 286 133 275 minecraft:iron_block
setblock 287 131 275 minecraft:sea_lantern
setblock 288 131 275 minecraft:gray_concrete
fill 292 131 275 293 133 275 minecraft:iron_block
fill 292 131 317 294 131 317 minecraft:iron_block
setblock 294 131 275 minecraft:gray_concrete
fill 295 131 275 296 131 275 minecraft:iron_block
setblock 295 131 317 minecraft:gray_concrete
fill 296 131 317 297 133 317 minecraft:iron_block
fill 297 131 275 298 131 275 minecraft:gray_concrete
setblock 298 131 317 minecraft:gray_concrete
setblock 299 131 317 minecraft:iron_block
fill 301 131 275 302 133 275 minecraft:iron_block
setblock 303 131 275 minecraft:gray_concrete
fill 304 131 275 305 133 275 minecraft:iron_block
fill 309 131 275 310 131 275 minecraft:iron_block
setblock 311 131 275 minecraft:gray_concrete
fill 312 131 275 314 133 275 minecraft:iron_block
fill 316 131 275 316 133 275 minecraft:iron_block
fill 316 131 317 316 133 317 minecraft:iron_block
setblock 317 131 317 minecraft:gray_concrete
fill 318 131 317 319 131 317 minecraft:iron_block
setblock 321 131 275 minecraft:gray_concrete
fill 322 131 275 322 133 275 minecraft:iron_block
fill 324 131 275 324 133 275 minecraft:iron_block
fill 324 131 278 324 133 278 minecraft:iron_block
fill 324 131 280 324 131 281 minecraft:iron_block
fill 324 131 282 324 132 282 minecraft:gray_concrete
fill 324 131 283 324 133 283 minecraft:iron_block
fill 324 131 284 324 132 284 minecraft:gray_concrete
fill 324 131 285 324 133 285 minecraft:iron_block
fill 324 131 292 324 133 292 minecraft:iron_block
setblock 324 131 295 minecraft:gray_concrete
fill 324 131 296 324 133 296 minecraft:iron_block
fill 324 131 302 324 133 302 minecraft:iron_block
setblock 324 131 305 minecraft:gray_concrete
setblock 324 131 315 minecraft:iron_block
fill 282 132 281 282 132 283 minecraft:gray_concrete
fill 282 132 284 282 133 284 minecraft:iron_block
fill 282 132 287 282 135 287 minecraft:iron_block
fill 282 132 295 282 133 295 minecraft:iron_block
setblock 282 132 296 minecraft:gray_concrete
fill 282 132 301 282 133 302 minecraft:iron_block
setblock 282 132 303 minecraft:gray_concrete
setblock 282 132 313 minecraft:gray_concrete
fill 282 132 314 282 133 314 minecraft:iron_block
fill 283 132 275 284 132 275 minecraft:gray_concrete
setblock 285 132 278 minecraft:light[level=12]
setblock 285 132 285 minecraft:light[level=12]
setblock 285 132 292 minecraft:light[level=12]
setblock 285 132 299 minecraft:light[level=12]
setblock 285 132 306 minecraft:light[level=12]
setblock 285 132 313 minecraft:light[level=12]
fill 286 132 317 286 133 317 minecraft:iron_block
fill 287 132 275 288 133 275 minecraft:iron_block
setblock 287 132 317 minecraft:gray_concrete
fill 288 132 317 289 133 317 minecraft:iron_block
setblock 292 132 278 minecraft:light[level=12]
setblock 292 132 285 minecraft:light[level=12]
setblock 292 132 292 minecraft:light[level=12]
setblock 292 132 299 minecraft:light[level=12]
setblock 292 132 306 minecraft:light[level=12]
setblock 292 132 313 minecraft:light[level=12]
setblock 292 132 317 minecraft:gray_concrete
fill 293 132 317 295 133 317 minecraft:iron_block
fill 294 132 275 294 134 275 minecraft:iron_block
setblock 295 132 275 minecraft:gray_concrete
setblock 296 132 275 minecraft:sea_lantern
fill 297 132 275 298 133 275 minecraft:iron_block
fill 298 132 317 298 133 317 minecraft:iron_block
setblock 299 132 275 minecraft:gray_concrete
setblock 299 132 278 minecraft:light[level=12]
setblock 299 132 285 minecraft:light[level=12]
setblock 299 132 292 minecraft:light[level=12]
setblock 299 132 299 minecraft:light[level=12]
setblock 299 132 306 minecraft:light[level=12]
setblock 299 132 313 minecraft:light[level=12]
setblock 299 132 317 minecraft:gray_concrete
fill 300 132 275 300 133 275 minecraft:iron_block
fill 303 132 275 303 133 275 minecraft:iron_block
setblock 304 132 317 minecraft:gray_concrete
fill 305 132 317 305 133 317 minecraft:iron_block
setblock 306 132 278 minecraft:light[level=12]
setblock 306 132 285 minecraft:light[level=12]
setblock 306 132 292 minecraft:light[level=12]
setblock 306 132 306 minecraft:light[level=12]
setblock 306 132 313 minecraft:light[level=12]
setblock 306 132 317 minecraft:gray_concrete
fill 307 132 317 309 133 317 minecraft:iron_block
fill 309 132 275 309 134 275 minecraft:iron_block
setblock 310 132 275 minecraft:gray_concrete
fill 311 132 275 311 133 275 minecraft:iron_block
setblock 313 132 278 minecraft:light[level=12]
setblock 313 132 285 minecraft:light[level=12]
setblock 313 132 292 minecraft:light[level=12]
setblock 313 132 299 minecraft:light[level=12]
setblock 313 132 306 minecraft:light[level=12]
setblock 313 132 313 minecraft:light[level=12]
fill 314 132 317 314 133 317 minecraft:iron_block
setblock 315 132 317 minecraft:gray_concrete
fill 317 132 317 317 133 317 minecraft:iron_block
fill 318 132 317 319 132 317 minecraft:gray_concrete
setblock 320 132 278 minecraft:light[level=12]
setblock 320 132 285 minecraft:light[level=12]
setblock 320 132 292 minecraft:light[level=12]
setblock 320 132 299 minecraft:light[level=12]
setblock 320 132 306 minecraft:light[level=12]
setblock 320 132 313 minecraft:light[level=12]
fill 321 132 275 321 133 275 minecraft:iron_block
setblock 324 132 276 minecraft:gray_concrete
fill 324 132 277 324 133 277 minecraft:iron_block
fill 324 132 280 324 133 280 minecraft:iron_block
setblock 324 132 281 minecraft:gray_concrete
fill 324 132 295 324 133 295 minecraft:iron_block
setblock 324 132 300 minecraft:gray_concrete
fill 324 132 301 324 133 301 minecraft:iron_block
setblock 324 132 305 minecraft:iron_block
setblock 324 132 315 minecraft:gray_concrete
fill 282 133 275 284 133 275 minecraft:iron_block
fill 282 133 281 282 133 283 minecraft:iron_block
setblock 282 133 296 minecraft:iron_block
setblock 282 133 298 minecraft:sea_lantern
fill 282 133 299 282 133 300 minecraft:iron_block
setblock 282 133 303 minecraft:iron_block
setblock 282 133 313 minecraft:iron_block
fill 283 133 276 283 134 276 minecraft:red_stained_glass
fill 283 133 277 286 134 278 minecraft:black_stained_glass
fill 283 133 279 283 134 279 minecraft:red_stained_glass
fill 283 133 280 283 134 281 minecraft:black_stained_glass
fill 283 133 282 283 134 282 minecraft:red_stained_glass
fill 283 133 283 286 134 284 minecraft:black_stained_glass
fill 283 133 285 283 134 285 minecraft:red_stained_glass
fill 283 133 286 283 134 287 minecraft:black_stained_glass
fill 283 133 288 283 134 288 minecraft:red_stained_glass
fill 283 133 289 286 134 290 minecraft:black_stained_glass
fill 283 133 291 283 134 291 minecraft:red_stained_glass
fill 283 133 292 283 134 293 minecraft:black_stained_glass
fill 283 133 294 283 134 294 minecraft:red_stained_glass
fill 283 133 295 286 134 296 minecraft:black_stained_glass
fill 283 133 297 283 134 297 minecraft:red_stained_glass
fill 283 133 298 283 134 299 minecraft:black_stained_glass
fill 283 133 300 283 134 300 minecraft:red_stained_glass
fill 283 133 301 286 134 302 minecraft:black_stained_glass
fill 283 133 303 283 134 303 minecraft:red_stained_glass
fill 283 133 304 283 134 305 minecraft:black_stained_glass
fill 283 133 306 283 134 306 minecraft:red_stained_glass
fill 283 133 307 286 134 308 minecraft:black_stained_glass
fill 283 133 309 283 134 309 minecraft:red_stained_glass
fill 283 133 310 283 134 311 minecraft:black_stained_glass
fill 283 133 312 283 134 312 minecraft:red_stained_glass
fill 283 133 313 286 134 314 minecraft:black_stained_glass
fill 283 133 315 283 134 315 minecraft:red_stained_glass
fill 283 133 316 283 134 316 minecraft:black_stained_glass
fill 284 133 276 285 134 276 minecraft:black_stained_glass
fill 284 133 279 285 134 279 minecraft:black_stained_glass
fill 284 133 280 285 134 281 minecraft:red_stained_glass
fill 284 133 282 285 134 282 minecraft:black_stained_glass
fill 284 133 285 285 134 285 minecraft:black_stained_glass
fill 284 133 286 285 134 287 minecraft:red_stained_glass
fill 284 133 288 285 134 288 minecraft:black_stained_glass
fill 284 133 291 285 134 291 minecraft:black_stained_glass
fill 284 133 292 285 134 293 minecraft:red_stained_glass
fill 284 133 294 285 134 294 minecraft:black_stained_glass
fill 284 133 297 285 134 297 minecraft:black_stained_glass
fill 284 133 298 285 134 299 minecraft:red_stained_glass
fill 284 133 300 285 134 300 minecraft:black_stained_glass
fill 284 133 303 285 134 303 minecraft:black_stained_glass
fill 284 133 304 285 134 305 minecraft:red_stained_glass
fill 284 133 306 285 134 306 minecraft:black_stained_glass
fill 284 133 309 285 134 309 minecraft:black_stained_glass
fill 284 133 310 285 134 311 minecraft:red_stained_glass
fill 284 133 312 285 134 312 minecraft:black_stained_glass
fill 284 133 315 285 134 315 minecraft:black_stained_glass
fill 284 133 316 285 134 316 minecraft:red_stained_glass
fill 286 133 276 286 134 276 minecraft:red_stained_glass
fill 286 133 279 286 134 279 minecraft:red_stained_glass
fill 286 133 280 289 134 281 minecraft:black_stained_glass
fill 286 133 282 286 134 282 minecraft:red_stained_glass
fill 286 133 285 286 134 285 minecraft:red_stained_glass
fill 286 133 286 289 134 287 minecraft:black_stained_glass
fill 286 133 288 286 134 288 minecraft:red_stained_glass
fill 286 133 291 286 134 291 minecraft:red_stained_glass
fill 286 133 292 289 134 293 minecraft:black_stained_glass
fill 286 133 294 286 134 294 minecraft:red_stained_glass
fill 286 133 297 286 134 297 minecraft:red_stained_glass
fill 286 133 298 289 134 299 minecraft:black_stained_glass
fill 286 133 300 286 134 300 minecraft:red_stained_glass
fill 286 133 303 286 134 303 minecraft:red_stained_glass
fill 286 133 304 289 134 305 minecraft:black_stained_glass
fill 286 133 306 286 134 306 minecraft:red_stained_glass
fill 286 133 309 286 134 309 minecraft:red_stained_glass
fill 286 133 310 289 134 311 minecraft:black_stained_glass
fill 286 133 312 286 134 312 minecraft:red_stained_glass
fill 286 133 315 286 134 315 minecraft:red_stained_glass
fill 286 133 316 289 134 316 minecraft:black_stained_glass
fill 287 133 276 288 134 276 minecraft:black_stained_glass
fill 287 133 277 288 134 278 minecraft:red_stained_glass
fill 287 133 279 288 134 279 minecraft:black_stained_glass
fill 287 133 282 288 134 282 minecraft:black_stained_glass
fill 287 133 283 288 134 284 minecraft:red_stained_glass
fill 287 133 285 288 134 285 minecraft:black_stained_glass
fill 287 133 288 288 134 288 minecraft:black_stained_glass
fill 287 133 289 288 134 290 minecraft:red_stained_glass
fill 287 133 291 288 134 291 minecraft:black_stained_glass
fill 287 133 294 288 134 294 minecraft:black_stained_glass
fill 287 133 295 288 134 296 minecraft:red_stained_glass
fill 287 133 297 288 134 297 minecraft:black_stained_glass
fill 287 133 300 288 134 300 minecraft:black_stained_glass
fill 287 133 301 288 134 302 minecraft:red_stained_glass
fill 287 133 303 288 134 303 minecraft:black_stained_glass
fill 287 133 306 288 134 306 minecraft:black_stained_glass
fill 287 133 307 288 134 308 minecraft:red_stained_glass
fill 287 133 309 288 134 309 minecraft:black_stained_glass
fill 287 133 312 288 134 312 minecraft:black_stained_glass
fill 287 133 313 288 134 314 minecraft:red_stained_glass
fill 287 133 315 288 134 315 minecraft:black_stained_glass
setblock 287 133 317 minecraft:iron_block
fill 289 133 276 289 134 276 minecraft:red_stained_glass
fill 289 133 277 292 134 278 minecraft:black_stained_glass
fill 289 133 279 289 134 279 minecraft:red_stained_glass
fill 289 133 282 289 134 282 minecraft:red_stained_glass
fill 289 133 283 292 134 284 minecraft:black_stained_glass
fill 289 133 285 289 134 285 minecraft:red_stained_glass
fill 289 133 288 289 134 288 minecraft:red_stained_glass
fill 289 133 289 292 134 290 minecraft:black_stained_glass
fill 289 133 291 289 134 291 minecraft:red_stained_glass
fill 289 133 294 289 134 294 minecraft:red_stained_glass
fill 289 133 295 292 134 296 minecraft:black_stained_glass
fill 289 133 297 289 134 297 minecraft:red_stained_glass
fill 289 133 300 289 134 300 minecraft:red_stained_glass
fill 289 133 301 292 134 302 minecraft:black_stained_glass
fill 289 133 303 289 134 303 minecraft:red_stained_glass
fill 289 133 306 289 134 306 minecraft:red_stained_glass
fill 289 133 307 292 134 308 minecraft:black_stained_glass
fill 289 133 309 289 134 309 minecraft:red_stained_glass
fill 289 133 312 289 134 312 minecraft:red_stained_glass
fill 289 133 313 292 134 314 minecraft:black_stained_glass
fill 289 133 315 289 134 315 minecraft:red_stained_glass
fill 290 133 276 291 134 276 minecraft:black_stained_glass
fill 290 133 279 291 134 279 minecraft:black_stained_glass
fill 290 133 280 291 134 281 minecraft:red_stained_glass
fill 290 133 282 291 134 282 minecraft:black_stained_glass
fill 290 133 285 291 134 285 minecraft:black_stained_glass
fill 290 133 286 291 134 287 minecraft:red_stained_glass
fill 290 133 288 291 134 288 minecraft:black_stained_glass
fill 290 133 291 291 134 291 minecraft:black_stained_glass
fill 290 133 292 291 134 293 minecraft:red_stained_glass
fill 290 133 294 291 134 294 minecraft:black_stained_glass
fill 290 133 297 291 134 297 minecraft:black_stained_glass
fill 290 133 298 291 134 299 minecraft:red_stained_glass
fill 290 133 300 291 134 300 minecraft:black_stained_glass
fill 290 133 303 291 134 303 minecraft:black_stained_glass
fill 290 133 304 291 134 305 minecraft:red_stained_glass
fill 290 133 306 291 134 306 minecraft:black_stained_glass
fill 290 133 309 291 134 309 minecraft:black_stained_glass
fill 290 133 310 291 134 311 minecraft:red_stained_glass
fill 290 133 312 291 134 312 minecraft:black_stained_glass
fill 290 133 315 291 134 315 minecraft:black_stained_glass
fill 290 133 316 291 134 316 minecraft:red_stained_glass
fill 292 133 276 292 134 276 minecraft:red_stained_glass
fill 292 133 279 292 134 279 minecraft:red_stained_glass
fill 292 133 280 295 134 281 minecraft:black_stained_glass
fill 292 133 282 292 134 282 minecraft:red_stained_glass
fill 292 133 285 292 134 285 minecraft:red_stained_glass
fill 292 133 286 295 134 287 minecraft:black_stained_glass
fill 292 133 288 292 134 288 minecraft:red_stained_glass
fill 292 133 291 292 134 291 minecraft:red_stained_glass
fill 292 133 292 295 134 293 minecraft:black_stained_glass
fill 292 133 294 292 134 294 minecraft:red_stained_glass
fill 292 133 297 292 134 297 minecraft:red_stained_glass
fill 292 133 298 295 134 299 minecraft:black_stained_glass
fill 292 133 300 292 134 300 minecraft:red_stained_glass
fill 292 133 303 292 134 303 minecraft:red_stained_glass
fill 292 133 304 295 134 305 minecraft:black_stained_glass
fill 292 133 306 292 134 306 minecraft:red_stained_glass
fill 292 133 309 292 134 309 minecraft:red_stained_glass
fill 292 133 310 295 134 311 minecraft:black_stained_glass
fill 292 133 312 292 134 312 minecraft:red_stained_glass
fill 292 133 315 292 134 315 minecraft:red_stained_glass
fill 292 133 316 295 134 316 minecraft:black_stained_glass
setblock 292 133 317 minecraft:iron_block
fill 293 133 276 294 134 276 minecraft:black_stained_glass
fill 293 133 277 294 134 278 minecraft:red_stained_glass
fill 293 133 279 294 134 279 minecraft:black_stained_glass
fill 293 133 282 294 134 282 minecraft:black_stained_glass
fill 293 133 283 294 134 284 minecraft:red_stained_glass
fill 293 133 285 294 134 285 minecraft:black_stained_glass
fill 293 133 288 294 134 288 minecraft:black_stained_glass
fill 293 133 289 294 134 290 minecraft:red_stained_glass
fill 293 133 291 294 134 291 minecraft:black_stained_glass
fill 293 133 294 294 134 294 minecraft:black_stained_glass
fill 293 133 295 294 134 296 minecraft:red_stained_glass
fill 293 133 297 294 134 297 minecraft:black_stained_glass
fill 293 133 300 294 134 300 minecraft:black_stained_glass
fill 293 133 301 294 134 302 minecraft:red_stained_glass
fill 293 133 303 294 134 303 minecraft:black_stained_glass
fill 293 133 306 294 134 306 minecraft:black_stained_glass
fill 293 133 307 294 134 308 minecraft:red_stained_glass
fill 293 133 309 294 134 309 minecraft:black_stained_glass
fill 293 133 312 294 134 312 minecraft:black_stained_glass
fill 293 133 313 294 134 314 minecraft:red_stained_glass
fill 293 133 315 294 134 315 minecraft:black_stained_glass
fill 295 133 275 296 133 275 minecraft:iron_block
fill 295 133 276 295 134 276 minecraft:red_stained_glass
fill 295 133 277 298 134 278 minecraft:black_stained_glass
fill 295 133 279 295 134 279 minecraft:red_stained_glass
fill 295 133 282 295 134 282 minecraft:red_stained_glass
fill 295 133 283 298 134 284 minecraft:black_stained_glass
fill 295 133 285 295 134 285 minecraft:red_stained_glass
fill 295 133 288 295 134 288 minecraft:red_stained_glass
fill 295 133 289 298 134 290 minecraft:black_stained_glass
fill 295 133 291 295 134 291 minecraft:red_stained_glass
fill 295 133 294 295 134 294 minecraft:red_stained_glass
fill 295 133 295 298 134 296 minecraft:black_stained_glass
fill 295 133 297 295 134 297 minecraft:red_stained_glass
fill 295 133 300 295 134 300 minecraft:red_stained_glass
fill 295 133 301 298 134 302 minecraft:black_stained_glass
fill 295 133 303 295 134 303 minecraft:red_stained_glass
fill 295 133 306 295 134 306 minecraft:red_stained_glass
fill 295 133 307 298 134 308 minecraft:black_stained_glass
fill 295 133 309 295 134 309 minecraft:red_stained_glass
fill 295 133 312 295 134 312 minecraft:red_stained_glass
fill 295 133 313 298 134 314 minecraft:black_stained_glass
fill 295 133 315 295 134 315 minecraft:red_stained_glass
fill 296 133 276 297 134 276 minecraft:black_stained_glass
fill 296 133 279 297 134 279 minecraft:black_stained_glass
fill 296 133 280 297 134 281 minecraft:red_stained_glass
fill 296 133 282 297 134 282 minecraft:black_stained_glass
fill 296 133 285 297 134 285 minecraft:black_stained_glass
fill 296 133 286 297 134 287 minecraft:red_stained_glass
fill 296 133 288 297 134 288 minecraft:black_stained_glass
fill 296 133 291 297 134 291 minecraft:black_stained_glass
fill 296 133 292 297 134 293 minecraft:red_stained_glass
fill 296 133 294 297 134 294 minecraft:black_stained_glass
fill 296 133 297 297 134 297 minecraft:black_stained_glass
fill 296 133 298 297 134 299 minecraft:red_stained_glass
fill 296 133 300 297 134 300 minecraft:black_stained_glass
fill 296 133 303 297 134 303 minecraft:black_stained_glass
fill 296 133 304 297 134 305 minecraft:red_stained_glass
fill 296 133 306 297 134 306 minecraft:black_stained_glass
fill 296 133 309 297 134 309 minecraft:black_stained_glass
fill 296 133 310 297 134 311 minecraft:red_stained_glass
fill 296 133 312 297 134 312 minecraft:black_stained_glass
fill 296 133 315 297 134 315 minecraft:black_stained_glass
fill 296 133 316 297 134 316 minecraft:red_stained_glass
fill 298 133 276 298 134 276 minecraft:red_stained_glass
fill 298 133 279 298 134 279 minecraft:red_stained_glass
fill 298 133 280 301 134 281 minecraft:black_stained_glass
fill 298 133 282 298 134 282 minecraft:red_stained_glass
fill 298 133 285 298 134 285 minecraft:red_stained_glass
fill 298 133 286 301 134 287 minecraft:black_stained_glass
fill 298 133 288 298 134 288 minecraft:red_stained_glass
fill 298 133 291 298 134 291 minecraft:red_stained_glass
fill 298 133 292 301 134 293 minecraft:black_stained_glass
fill 298 133 294 298 134 294 minecraft:red_stained_glass
fill 298 133 297 298 134 297 minecraft:red_stained_glass
fill 298 133 298 301 133 299 minecraft:black_stained_glass
fill 298 133 300 298 134 300 minecraft:red_stained_glass
fill 298 133 303 298 134 303 minecraft:red_stained_glass
fill 298 133 304 301 134 305 minecraft:black_stained_glass
fill 298 133 306 298 134 306 minecraft:red_stained_glass
fill 298 133 309 298 134 309 minecraft:red_stained_glass
fill 298 133 310 301 134 311 minecraft:black_stained_glass
fill 298 133 312 298 134 312 minecraft:red_stained_glass
fill 298 133 315 298 134 315 minecraft:red_stained_glass
fill 298 133 316 301 134 316 minecraft:black_stained_glass
setblock 299 133 275 minecraft:iron_block
fill 299 133 276 300 134 276 minecraft:black_stained_glass
fill 299 133 277 300 134 278 minecraft:red_stained_glass
fill 299 133 279 300 134 279 minecraft:black_stained_glass
fill 299 133 282 300 134 282 minecraft:black_stained_glass
fill 299 133 283 300 134 284 minecraft:red_stained_glass
fill 299 133 285 300 134 285 minecraft:black_stained_glass
fill 299 133 288 300 134 288 minecraft:black_stained_glass
fill 299 133 289 300 134 290 minecraft:red_stained_glass
fill 299 133 291 300 134 291 minecraft:black_stained_glass
fill 299 133 294 300 134 294 minecraft:black_stained_glass
fill 299 133 295 300 134 296 minecraft:red_stained_glass
fill 299 133 297 300 134 297 minecraft:black_stained_glass
fill 299 133 300 300 134 300 minecraft:black_stained_glass
fill 299 133 301 300 134 302 minecraft:red_stained_glass
fill 299 133 303 300 134 303 minecraft:black_stained_glass
fill 299 133 306 300 134 306 minecraft:black_stained_glass
fill 299 133 307 300 134 308 minecraft:red_stained_glass
fill 299 133 309 300 134 309 minecraft:black_stained_glass
fill 299 133 312 300 134 312 minecraft:black_stained_glass
fill 299 133 313 300 134 314 minecraft:red_stained_glass
fill 299 133 315 300 134 315 minecraft:black_stained_glass
setblock 299 133 317 minecraft:iron_block
fill 301 133 276 301 134 276 minecraft:red_stained_glass
fill 301 133 277 304 134 278 minecraft:black_stained_glass
fill 301 133 279 301 134 279 minecraft:red_stained_glass
fill 301 133 282 301 134 282 minecraft:red_stained_glass
fill 301 133 283 304 134 284 minecraft:black_stained_glass
fill 301 133 285 301 134 285 minecraft:red_stained_glass
fill 301 133 288 301 134 288 minecraft:red_stained_glass
fill 301 133 289 304 134 290 minecraft:black_stained_glass
fill 301 133 291 301 134 291 minecraft:red_stained_glass
fill 301 133 294 301 134 294 minecraft:red_stained_glass
fill 301 133 295 302 133 296 minecraft:black_stained_glass
setblock 301 133 297 minecraft:red_stained_glass
fill 301 133 300 301 134 300 minecraft:red_stained_glass
fill 301 133 301 304 133 302 minecraft:black_stained_glass
fill 301 133 303 301 134 303 minecraft:red_stained_glass
fill 301 133 306 301 134 306 minecraft:red_stained_glass
fill 301 133 307 304 134 308 minecraft:black_stained_glass
fill 301 133 309 301 134 309 minecraft:red_stained_glass
fill 301 133 312 301 134 312 minecraft:red_stained_glass
fill 301 133 313 304 134 314 minecraft:black_stained_glass
fill 301 133 315 301 134 315 minecraft:red_stained_glass
fill 302 133 276 303 134 276 minecraft:black_stained_glass
fill 302 133 279 303 134 279 minecraft:black_stained_glass
fill 302 133 280 303 134 281 minecraft:red_stained_glass
fill 302 133 282 303 134 282 minecraft:black_stained_glass
fill 302 133 285 303 134 285 minecraft:black_stained_glass
fill 302 133 286 303 134 287 minecraft:red_stained_glass
fill 302 133 288 303 134 288 minecraft:black_stained_glass
fill 302 133 291 303 134 291 minecraft:black_stained_glass
fill 302 133 292 303 134 293 minecraft:red_stained_glass
fill 302 133 294 303 133 294 minecraft:black_stained_glass
fill 302 133 298 302 133 299 minecraft:red_stained_glass
fill 302 133 300 303 133 300 minecraft:black_stained_glass
fill 302 133 303 303 134 303 minecraft:black_stained_glass
fill 302 133 304 303 134 305 minecraft:red_stained_glass
fill 302 133 306 303 134 306 minecraft:black_stained_glass
fill 302 133 309 303 134 309 minecraft:black_stained_glass
fill 302 133 310 303 134 311 minecraft:red_stained_glass
fill 302 133 312 303 134 312 minecraft:black_stained_glass
fill 302 133 315 303 134 315 minecraft:black_stained_glass
fill 302 133 316 303 134 316 minecraft:red_stained_glass
fill 304 133 276 304 134 276 minecraft:red_stained_glass
fill 304 133 279 304 134 279 minecraft:red_stained_glass
fill 304 133 280 307 134 281 minecraft:black_stained_glass
fill 304 133 282 304 134 282 minecraft:red_stained_glass
fill 304 133 285 304 134 285 minecraft:red_stained_glass
fill 304 133 286 307 134 287 minecraft:black_stained_glass
fill 304 133 288 304 134 288 minecraft:red_stained_glass
fill 304 133 291 304 134 291 minecraft:red_stained_glass
fill 304 133 292 307 133 293 minecraft:black_stained_glass
setblock 304 133 294 minecraft:red_stained_glass
setblock 304 133 300 minecraft:red_stained_glass
fill 304 133 303 304 134 303 minecraft:red_stained_glass
fill 304 133 304 307 134 305 minecraft:black_stained_glass
fill 304 133 306 304 134 306 minecraft:red_stained_glass
fill 304 133 309 304 134 309 minecraft:red_stained_glass
fill 304 133 310 307 134 311 minecraft:black_stained_glass
fill 304 133 312 304 134 312 minecraft:red_stained_glass
fill 304 133 315 304 134 315 minecraft:red_stained_glass
fill 304 133 316 307 134 316 minecraft:black_stained_glass
setblock 304 133 317 minecraft:iron_block
fill 305 133 276 306 134 276 minecraft:black_stained_glass
fill 305 133 277 306 134 278 minecraft:red_stained_glass
fill 305 133 279 306 134 279 minecraft:black_stained_glass
fill 305 133 282 306 134 282 minecraft:black_stained_glass
fill 305 133 283 306 134 284 minecraft:red_stained_glass
fill 305 133 285 306 134 285 minecraft:black_stained_glass
fill 305 133 288 306 134 288 minecraft:black_stained_glass
fill 305 133 289 306 134 290 minecraft:red_stained_glass
fill 305 133 291 306 134 291 minecraft:black_stained_glass
fill 305 133 301 306 133 302 minecraft:red_stained_glass
fill 305 133 303 306 134 303 minecraft:black_stained_glass
fill 305 133 306 306 134 306 minecraft:black_stained_glass
fill 305 133 307 306 134 308 minecraft:red_stained_glass
fill 305 133 309 306 134 309 minecraft:black_stained_glass
fill 305 133 312 306 134 312 minecraft:black_stained_glass
fill 305 133 313 306 134 314 minecraft:red_stained_glass
fill 305 133 315 306 134 315 minecraft:black_stained_glass
setblock 306 133 294 minecraft:black_stained_glass
setblock 306 133 300 minecraft:black_stained_glass
setblock 306 133 317 minecraft:iron_block
fill 307 133 276 307 134 276 minecraft:red_stained_glass
fill 307 133 277 310 134 278 minecraft:black_stained_glass
fill 307 133 279 307 134 279 minecraft:red_stained_glass
fill 307 133 282 307 134 282 minecraft:red_stained_glass
fill 307 133 283 310 134 284 minecraft:black_stained_glass
fill 307 133 285 307 134 285 minecraft:red_stained_glass
fill 307 133 288 307 134 288 minecraft:red_stained_glass
fill 307 133 289 310 134 290 minecraft:black_stained_glass
fill 307 133 291 307 134 291 minecraft:red_stained_glass
setblock 307 133 294 minecraft:red_stained_glass
setblock 307 133 300 minecraft:red_stained_glass
fill 307 133 301 310 134 302 minecraft:black_stained_glass
fill 307 133 303 307 134 303 minecraft:red_stained_glass
fill 307 133 306 307 134 306 minecraft:red_stained_glass
fill 307 133 307 310 134 308 minecraft:black_stained_glass
fill 307 133 309 307 134 309 minecraft:red_stained_glass
fill 307 133 312 307 134 312 minecraft:red_stained_glass
fill 307 133 313 310 134 314 minecraft:black_stained_glass
fill 307 133 315 307 134 315 minecraft:red_stained_glass
fill 308 133 276 309 134 276 minecraft:black_stained_glass
fill 308 133 279 309 134 279 minecraft:black_stained_glass
fill 308 133 280 309 134 281 minecraft:red_stained_glass
fill 308 133 282 309 134 282 minecraft:black_stained_glass
fill 308 133 285 309 134 285 minecraft:black_stained_glass
fill 308 133 286 309 134 287 minecraft:red_stained_glass
fill 308 133 288 309 134 288 minecraft:black_stained_glass
fill 308 133 291 309 134 291 minecraft:black_stained_glass
fill 308 133 292 309 134 293 minecraft:red_stained_glass
fill 308 133 294 309 133 296 minecraft:black_stained_glass
fill 308 133 298 309 133 299 minecraft:red_stained_glass
fill 308 133 300 309 133 300 minecraft:black_stained_glass
fill 308 133 303 309 134 303 minecraft:black_stained_glass
fill 308 133 304 309 134 305 minecraft:red_stained_glass
fill 308 133 306 309 134 306 minecraft:black_stained_glass
fill 308 133 309 309 134 309 minecraft:black_stained_glass
fill 308 133 310 309 134 311 minecraft:red_stained_glass
fill 308 133 312 309 134 312 minecraft:black_stained_glass
fill 308 133 315 309 134 315 minecraft:black_stained_glass
fill 308 133 316 309 134 316 minecraft:red_stained_glass
setblock 309 133 297 minecraft:black_stained_glass
setblock 310 133 275 minecraft:iron_block
fill 310 133 276 310 134 276 minecraft:red_stained_glass
fill 310 133 279 310 134 279 minecraft:red_stained_glass
fill 310 133 280 313 134 281 minecraft:black_stained_glass
fill 310 133 282 310 134 282 minecraft:red_stained_glass
fill 310 133 285 310 134 285 minecraft:red_stained_glass
fill 310 133 286 313 134 287 minecraft:black_stained_glass
fill 310 133 288 310 134 288 minecraft:red_stained_glass
fill 310 133 291 310 134 291 minecraft:red_stained_glass
fill 310 133 292 313 134 293 minecraft:black_stained_glass
fill 310 133 294 310 134 294 minecraft:red_stained_glass
fill 310 133 295 310 134 296 minecraft:black_stained_glass
fill 310 133 297 310 134 297 minecraft:red_stained_glass
fill 310 133 298 313 134 299 minecraft:black_stained_glass
fill 310 133 300 310 134 300 minecraft:red_stained_glass
fill 310 133 303 310 134 303 minecraft:red_stained_glass
fill 310 133 304 313 134 305 minecraft:black_stained_glass
fill 310 133 306 310 134 306 minecraft:red_stained_glass
fill 310 133 309 310 134 309 minecraft:red_stained_glass
fill 310 133 310 313 134 311 minecraft:black_stained_glass
fill 310 133 312 310 134 312 minecraft:red_stained_glass
fill 310 133 315 310 134 315 minecraft:red_stained_glass
fill 310 133 316 313 134 316 minecraft:black_stained_glass
fill 311 133 276 312 134 276 minecraft:black_stained_glass
fill 311 133 277 312 134 278 minecraft:red_stained_glass
fill 311 133 279 312 134 279 minecraft:black_stained_glass
fill 311 133 282 312 134 282 minecraft:black_stained_glass
fill 311 133 283 312 134 284 minecraft:red_stained_glass
fill 311 133 285 312 134 285 minecraft:black_stained_glass
fill 311 133 288 312 134 288 minecraft:black_stained_glass
fill 311 133 289 312 134 290 minecraft:red_stained_glass
fill 311 133 291 312 134 291 minecraft:black_stained_glass
fill 311 133 294 312 134 294 minecraft:black_stained_glass
fill 311 133 295 312 134 296 minecraft:red_stained_glass
fill 311 133 297 312 134 297 minecraft:black_stained_glass
fill 311 133 300 312 134 300 minecraft:black_stained_glass
fill 311 133 301 312 134 302 minecraft:red_stained_glass
fill 311 133 303 312 134 303 minecraft:black_stained_glass
fill 311 133 306 312 134 306 minecraft:black_stained_glass
fill 311 133 307 312 134 308 minecraft:red_stained_glass
fill 311 133 309 312 134 309 minecraft:black_stained_glass
fill 311 133 312 312 134 312 minecraft:black_stained_glass
fill 311 133 313 312 134 314 minecraft:red_stained_glass
fill 311 133 315 312 134 315 minecraft:black_stained_glass
fill 313 133 276 313 134 276 minecraft:red_stained_glass
fill 313 133 277 316 134 278 minecraft:black_stained_glass
fill 313 133 279 313 134 279 minecraft:red_stained_glass
fill 313 133 282 313 134 282 minecraft:red_stained_glass
fill 313 133 283 316 134 284 minecraft:black_stained_glass
fill 313 133 285 313 134 285 minecraft:red_stained_glass
fill 313 133 288 313 134 288 minecraft:red_stained_glass
fill 313 133 289 316 134 290 minecraft:black_stained_glass
fill 313 133 291 313 134 291 minecraft:red_stained_glass
fill 313 133 294 313 134 294 minecraft:red_stained_glass
fill 313 133 295 316 134 296 minecraft:black_stained_glass
fill 313 133 297 313 134 297 minecraft:red_stained_glass
fill 313 133 300 313 134 300 minecraft:red_stained_glass
fill 313 133 301 316 134 302 minecraft:black_stained_glass
fill 313 133 303 313 134 303 minecraft:red_stained_glass
fill 313 133 306 313 134 306 minecraft:red_stained_glass
fill 313 133 307 316 134 308 minecraft:black_stained_glass
fill 313 133 309 313 134 309 minecraft:red_stained_glass
fill 313 133 312 313 134 312 minecraft:red_stained_glass
fill 313 133 313 316 134 314 minecraft:black_stained_glass
fill 313 133 315 313 134 315 minecraft:red_stained_glass
fill 314 133 276 315 134 276 minecraft:black_stained_glass
fill 314 133 279 315 134 279 minecraft:black_stained_glass
fill 314 133 280 315 134 281 minecraft:red_stained_glass
fill 314 133 282 315 134 282 minecraft:black_stained_glass
fill 314 133 285 315 134 285 minecraft:black_stained_glass
fill 314 133 286 315 134 287 minecraft:red_stained_glass
fill 314 133 288 315 134 288 minecraft:black_stained_glass
fill 314 133 291 315 134 291 minecraft:black_stained_glass
fill 314 133 292 315 134 293 minecraft:red_stained_glass
fill 314 133 294 315 134 294 minecraft:black_stained_glass
fill 314 133 297 315 134 297 minecraft:black_stained_glass
fill 314 133 298 315 134 299 minecraft:red_stained_glass
fill 314 133 300 315 134 300 minecraft:black_stained_glass
fill 314 133 303 315 134 303 minecraft:black_stained_glass
fill 314 133 304 315 134 305 minecraft:red_stained_glass
fill 314 133 306 315 134 306 minecraft:black_stained_glass
fill 314 133 309 315 134 309 minecraft:black_stained_glass
fill 314 133 310 315 134 311 minecraft:red_stained_glass
fill 314 133 312 315 134 312 minecraft:black_stained_glass
fill 314 133 315 315 134 315 minecraft:black_stained_glass
fill 314 133 316 315 134 316 minecraft:red_stained_glass
setblock 315 133 317 minecraft:iron_block
fill 316 133 276 316 134 276 minecraft:red_stained_glass
fill 316 133 279 316 134 279 minecraft:red_stained_glass
fill 316 133 280 319 134 281 minecraft:black_stained_glass
fill 316 133 282 316 134 282 minecraft:red_stained_glass
fill 316 133 285 316 134 285 minecraft:red_stained_glass
fill 316 133 286 319 134 287 minecraft:black_stained_glass
fill 316 133 288 316 134 288 minecraft:red_stained_glass
fill 316 133 291 316 134 291 minecraft:red_stained_glass
fill 316 133 292 319 134 293 minecraft:black_stained_glass
fill 316 133 294 316 134 294 minecraft:red_stained_glass
fill 316 133 297 316 134 297 minecraft:red_stained_glass
fill 316 133 298 319 134 299 minecraft:black_stained_glass
fill 316 133 300 316 134 300 minecraft:red_stained_glass
fill 316 133 303 316 134 303 minecraft:red_stained_glass
fill 316 133 304 319 134 305 minecraft:black_stained_glass
fill 316 133 306 316 134 306 minecraft:red_stained_glass
fill 316 133 309 316 134 309 minecraft:red_stained_glass
fill 316 133 310 319 134 311 minecraft:black_stained_glass
fill 316 133 312 316 134 312 minecraft:red_stained_glass
fill 316 133 315 316 134 315 minecraft:red_stained_glass
fill 316 133 316 319 134 316 minecraft:black_stained_glass
fill 317 133 276 318 134 276 minecraft:black_stained_glass
fill 317 133 277 318 134 278 minecraft:red_stained_glass
fill 317 133 279 318 134 279 minecraft:black_stained_glass
fill 317 133 282 318 134 282 minecraft:black_stained_glass
fill 317 133 283 318 134 284 minecraft:red_stained_glass
fill 317 133 285 318 134 285 minecraft:black_stained_glass
fill 317 133 288 318 134 288 minecraft:black_stained_glass
fill 317 133 289 318 134 290 minecraft:red_stained_glass
fill 317 133 291 318 134 291 minecraft:black_stained_glass
fill 317 133 294 318 134 294 minecraft:black_stained_glass
fill 317 133 295 318 134 296 minecraft:red_stained_glass
fill 317 133 297 318 134 297 minecraft:black_stained_glass
fill 317 133 300 318 134 300 minecraft:black_stained_glass
fill 317 133 301 318 134 302 minecraft:red_stained_glass
fill 317 133 303 318 134 303 minecraft:black_stained_glass
fill 317 133 306 318 134 306 minecraft:black_stained_glass
fill 317 133 307 318 134 308 minecraft:red_stained_glass
fill 317 133 309 318 134 309 minecraft:black_stained_glass
fill 317 133 312 318 134 312 minecraft:black_stained_glass
fill 317 133 313 318 134 314 minecraft:red_stained_glass
fill 317 133 315 318 134 315 minecraft:black_stained_glass
fill 318 133 317 319 133 317 minecraft:iron_block
fill 319 133 276 319 134 276 minecraft:red_stained_glass
fill 319 133 277 322 134 278 minecraft:black_stained_glass
fill 319 133 279 319 134 279 minecraft:red_stained_glass
fill 319 133 282 319 134 282 minecraft:red_stained_glass
fill 319 133 283 322 134 284 minecraft:black_stained_glass
fill 319 133 285 319 134 285 minecraft:red_stained_glass
fill 319 133 288 319 134 288 minecraft:red_stained_glass
fill 319 133 289 322 134 290 minecraft:black_stained_glass
fill 319 133 291 319 134 291 minecraft:red_stained_glass
fill 319 133 294 319 134 294 minecraft:red_stained_glass
fill 319 133 295 322 134 296 minecraft:black_stained_glass
fill 319 133 297 319 134 297 minecraft:red_stained_glass
fill 319 133 300 319 134 300 minecraft:red_stained_glass
fill 319 133 301 322 134 302 minecraft:black_stained_glass
fill 319 133 303 319 134 303 minecraft:red_stained_glass
fill 319 133 306 319 134 306 minecraft:red_stained_glass
fill 319 133 307 322 134 308 minecraft:black_stained_glass
fill 319 133 309 319 134 309 minecraft:red_stained_glass
fill 319 133 312 319 134 312 minecraft:red_stained_glass
fill 319 133 313 322 134 314 minecraft:black_stained_glass
fill 319 133 315 319 134 315 minecraft:red_stained_glass
fill 320 133 276 321 134 276 minecraft:black_stained_glass
fill 320 133 279 321 134 279 minecraft:black_stained_glass
fill 320 133 280 321 134 281 minecraft:red_stained_glass
fill 320 133 282 321 134 282 minecraft:black_stained_glass
fill 320 133 285 321 134 285 minecraft:black_stained_glass
fill 320 133 286 321 134 287 minecraft:red_stained_glass
fill 320 133 288 321 134 288 minecraft:black_stained_glass
fill 320 133 291 321 134 291 minecraft:black_stained_glass
fill 320 133 292 321 134 293 minecraft:red_stained_glass
fill 320 133 294 321 134 294 minecraft:black_stained_glass
fill 320 133 297 321 134 297 minecraft:black_stained_glass
fill 320 133 298 321 134 299 minecraft:red_stained_glass
fill 320 133 300 321 134 300 minecraft:black_stained_glass
fill 320 133 303 321 134 303 minecraft:black_stained_glass
fill 320 133 304 321 134 305 minecraft:red_stained_glass
fill 320 133 306 321 134 306 minecraft:black_stained_glass
fill 320 133 309 321 134 309 minecraft:black_stained_glass
fill 320 133 310 321 134 311 minecraft:red_stained_glass
fill 320 133 312 321 134 312 minecraft:black_stained_glass
fill 320 133 315 321 134 315 minecraft:black_stained_glass
fill 320 133 316 321 134 316 minecraft:red_stained_glass
fill 322 133 276 322 134 276 minecraft:red_stained_glass
fill 322 133 279 322 134 279 minecraft:red_stained_glass
fill 322 133 280 323 134 281 minecraft:black_stained_glass
fill 322 133 282 322 134 282 minecraft:red_stained_glass
fill 322 133 285 322 134 285 minecraft:red_stained_glass
fill 322 133 286 323 134 287 minecraft:black_stained_glass
fill 322 133 288 322 134 288 minecraft:red_stained_glass
fill 322 133 291 322 134 291 minecraft:red_stained_glass
fill 322 133 292 323 134 293 minecraft:black_stained_glass
fill 322 133 294 322 134 294 minecraft:red_stained_glass
fill 322 133 297 322 134 297 minecraft:red_stained_glass
fill 322 133 298 323 134 299 minecraft:black_stained_glass
fill 322 133 300 322 134 300 minecraft:red_stained_glass
fill 322 133 303 322 134 303 minecraft:red_stained_glass
fill 322 133 304 323 134 305 minecraft:black_stained_glass
fill 322 133 306 322 134 306 minecraft:red_stained_glass
fill 322 133 309 322 134 309 minecraft:red_stained_glass
fill 322 133 310 323 134 311 minecraft:black_stained_glass
fill 322 133 312 322 134 312 minecraft:red_stained_glass
fill 322 133 315 322 134 315 minecraft:red_stained_glass
fill 322 133 316 323 134 316 minecraft:black_stained_glass
fill 323 133 276 323 134 276 minecraft:black_stained_glass
fill 323 133 277 323 134 278 minecraft:red_stained_glass
fill 323 133 279 323 134 279 minecraft:black_stained_glass
fill 323 133 282 323 134 282 minecraft:black_stained_glass
fill 323 133 283 323 134 284 minecraft:red_stained_glass
fill 323 133 285 323 134 285 minecraft:black_stained_glass
fill 323 133 288 323 134 288 minecraft:black_stained_glass
fill 323 133 289 323 134 290 minecraft:red_stained_glass
fill 323 133 291 323 134 291 minecraft:black_stained_glass
fill 323 133 294 323 134 294 minecraft:black_stained_glass
fill 323 133 295 323 134 296 minecraft:red_stained_glass
fill 323 133 297 323 134 297 minecraft:black_stained_glass
fill 323 133 300 323 134 300 minecraft:black_stained_glass
fill 323 133 301 323 134 302 minecraft:red_stained_glass
fill 323 133 303 323 134 303 minecraft:black_stained_glass
fill 323 133 306 323 134 306 minecraft:black_stained_glass
fill 323 133 307 323 134 308 minecraft:red_stained_glass
fill 323 133 309 323 134 309 minecraft:black_stained_glass
fill 323 133 312 323 134 312 minecraft:black_stained_glass
fill 323 133 313 323 134 314 minecraft:red_stained_glass
fill 323 133 315 323 134 315 minecraft:black_stained_glass
setblock 324 133 276 minecraft:iron_block
fill 324 133 281 324 133 282 minecraft:iron_block
setblock 324 133 284 minecraft:iron_block
setblock 324 133 300 minecraft:iron_block
setblock 324 133 305 minecraft:sea_lantern
setblock 324 133 315 minecraft:iron_block
fill 282 134 275 282 135 280 minecraft:gray_concrete
setblock 282 134 281 minecraft:iron_block
fill 282 134 282 282 134 286 minecraft:gray_concrete
fill 282 134 288 282 134 311 minecraft:gray_concrete
fill 282 134 313 282 136 315 minecraft:gray_concrete
setblock 282 134 316 minecraft:iron_block
fill 282 134 317 283 135 317 minecraft:gray_concrete
fill 283 134 275 293 135 275 minecraft:gray_concrete
setblock 284 134 317 minecraft:iron_block
fill 285 134 317 292 134 317 minecraft:gray_concrete
fill 293 134 317 294 134 317 minecraft:iron_block
fill 295 134 275 300 135 275 minecraft:gray_concrete
fill 295 134 317 302 134 317 minecraft:gray_concrete
fill 298 134 298 300 134 299 minecraft:black_stained_glass
setblock 301 134 275 minecraft:iron_block
setblock 301 134 295 minecraft:black_stained_glass
fill 301 134 296 301 134 298 minecraft:redstone_block
setblock 301 134 299 minecraft:black_stained_glass
fill 301 134 301 303 134 302 minecraft:black_stained_glass
fill 302 134 275 308 136 275 minecraft:gray_concrete
fill 302 134 294 302 134 296 minecraft:redstone_block
fill 302 134 298 302 134 300 minecraft:redstone_block
fill 303 134 294 304 134 294 minecraft:redstone_block
fill 303 134 300 304 134 300 minecraft:redstone_block
fill 304 134 292 307 134 292 minecraft:black_stained_glass
fill 304 134 293 306 134 293 minecraft:redstone_block
fill 304 134 301 306 134 301 minecraft:redstone_block
setblock 304 134 302 minecraft:black_stained_glass
fill 304 134 317 306 135 317 minecraft:gray_concrete
fill 305 134 302 306 134 302 minecraft:red_stained_glass
fill 306 134 294 308 134 294 minecraft:redstone_block
fill 306 134 300 308 134 300 minecraft:redstone_block
setblock 307 134 293 minecraft:black_stained_glass
setblock 307 134 317 minecraft:iron_block
fill 308 134 295 308 134 296 minecraft:redstone_block
fill 308 134 298 308 134 299 minecraft:redstone_block
fill 308 134 317 309 136 317 minecraft:gray_concrete
fill 309 134 294 309 134 295 minecraft:black_stained_glass
fill 309 134 296 309 134 298 minecraft:redstone_block
setblock 309 134 299 minecraft:red_stained_glass
setblock 309 134 300 minecraft:black_stained_glass
fill 310 134 275 313 134 275 minecraft:gray_concrete
fill 311 134 317 322 134 317 minecraft:gray_concrete
fill 314 134 275 314 136 275 minecraft:iron_block
fill 315 134 275 324 135 275 minecraft:gray_concrete
fill 323 134 317 324 134 317 minecraft:iron_block
fill 324 134 276 324 134 288 minecraft:gray_concrete
setblock 324 134 289 minecraft:redstone_block
fill 324 134 290 324 134 293 minecraft:gray_concrete
setblock 324 134 294 minecraft:iron_block
fill 324 134 295 324 135 297 minecraft:gray_concrete
setblock 324 134 298 minecraft:iron_block
fill 324 134 299 324 135 303 minecraft:gray_concrete
fill 324 134 305 324 134 309 minecraft:gray_concrete
setblock 324 134 310 minecraft:iron_block
fill 324 134 311 324 136 313 minecraft:gray_concrete
setblock 324 134 314 minecraft:iron_block
fill 324 134 315 324 136 316 minecraft:gray_concrete
fill 282 135 281 282 136 284 minecraft:gray_concrete
setblock 282 135 285 minecraft:iron_block
setblock 282 135 286 minecraft:gray_concrete
fill 282 135 288 282 135 309 minecraft:gray_concrete
setblock 282 135 310 minecraft:iron_block
fill 282 135 311 282 136 312 minecraft:gray_concrete
fill 282 135 316 282 136 316 minecraft:gray_concrete
fill 284 135 317 285 136 317 minecraft:gray_concrete
setblock 286 135 317 minecraft:iron_block
fill 287 135 317 287 136 317 minecraft:gray_concrete
setblock 288 135 317 minecraft:iron_block
fill 289 135 317 300 135 317 minecraft:gray_concrete
fill 294 135 275 294 136 275 minecraft:gray_concrete
fill 301 135 275 301 136 275 minecraft:gray_concrete
setblock 301 135 317 minecraft:iron_block
fill 302 135 317 302 136 317 minecraft:gray_concrete
fill 307 135 317 307 136 317 minecraft:gray_concrete
fill 309 135 275 309 136 275 minecraft:gray_concrete
setblock 310 135 275 minecraft:iron_block
fill 310 135 317 311 136 317 minecraft:gray_concrete
fill 311 135 275 313 136 275 minecraft:gray_concrete
setblock 312 135 317 minecraft:iron_block
fill 313 135 317 315 136 317 minecraft:gray_concrete
fill 316 135 317 317 135 317 minecraft:iron_block
fill 318 135 317 324 136 317 minecraft:gray_concrete
setblock 324 135 276 minecraft:iron_block
fill 324 135 277 324 136 277 minecraft:gray_concrete
setblock 324 135 278 minecraft:iron_block
fill 324 135 279 324 136 282 minecraft:gray_concrete
setblock 324 135 283 minecraft:iron_block
fill 324 135 284 324 135 286 minecraft:gray_concrete
setblock 324 135 287 minecraft:iron_block
fill 324 135 288 324 136 291 minecraft:gray_concrete
setblock 324 135 292 minecraft:iron_block
fill 324 135 293 324 136 294 minecraft:gray_concrete
setblock 324 135 298 minecraft:gray_concrete
fill 324 135 304 324 136 307 minecraft:gray_concrete
setblock 324 135 308 minecraft:iron_block
fill 324 135 309 324 136 310 minecraft:gray_concrete
fill 324 135 314 324 136 314 minecraft:gray_concrete
fill 282 136 275 282 136 278 minecraft:gray_concrete
setblock 282 136 279 minecraft:iron_block
setblock 282 136 280 minecraft:gray_concrete
setblock 282 136 285 minecraft:gray_concrete
setblock 282 136 286 minecraft:iron_block
fill 282 136 287 282 136 291 minecraft:gray_concrete
setblock 282 136 292 minecraft:iron_block
fill 282 136 293 282 136 298 minecraft:gray_concrete
setblock 282 136 299 minecraft:iron_block
fill 282 136 300 282 136 302 minecraft:gray_concrete
setblock 282 136 303 minecraft:iron_block
fill 282 136 304 282 136 307 minecraft:gray_concrete
setblock 282 136 308 minecraft:iron_block
fill 282 136 309 282 136 310 minecraft:gray_concrete
setblock 282 136 317 minecraft:iron_block
setblock 283 136 275 minecraft:iron_block
setblock 283 136 317 minecraft:gray_concrete
setblock 284 136 275 minecraft:gray_concrete
setblock 285 136 275 minecraft:iron_block
setblock 285 136 278 minecraft:light[level=15]
setblock 285 136 286 minecraft:light[level=15]
setblock 285 136 294 minecraft:light[level=15]
setblock 285 136 302 minecraft:light[level=15]
setblock 285 136 310 minecraft:light[level=15]
fill 286 136 275 293 136 275 minecraft:gray_concrete
setblock 286 136 317 minecraft:gray_concrete
fill 288 136 317 296 136 317 minecraft:gray_concrete
setblock 293 136 278 minecraft:light[level=15]
setblock 293 136 286 minecraft:light[level=15]
setblock 293 136 294 minecraft:light[level=15]
setblock 293 136 302 minecraft:light[level=15]
setblock 293 136 310 minecraft:light[level=15]
setblock 295 136 275 minecraft:gray_concrete
setblock 296 136 275 minecraft:iron_block
fill 297 136 275 300 136 275 minecraft:gray_concrete
setblock 297 136 317 minecraft:iron_block
fill 298 136 317 301 136 317 minecraft:gray_concrete
setblock 301 136 278 minecraft:light[level=15]
setblock 301 136 286 minecraft:light[level=15]
setblock 301 136 294 minecraft:light[level=15]
setblock 301 136 302 minecraft:light[level=15]
setblock 301 136 310 minecraft:light[level=15]
fill 303 136 317 305 136 317 minecraft:gray_concrete
setblock 306 136 317 minecraft:iron_block
setblock 309 136 278 minecraft:light[level=15]
setblock 309 136 286 minecraft:light[level=15]
setblock 309 136 294 minecraft:light[level=15]
setblock 309 136 302 minecraft:light[level=15]
setblock 309 136 310 minecraft:light[level=15]
setblock 310 136 275 minecraft:gray_concrete
setblock 312 136 317 minecraft:gray_concrete
fill 315 136 275 321 136 275 minecraft:gray_concrete
fill 316 136 317 317 136 317 minecraft:gray_concrete
setblock 317 136 278 minecraft:light[level=15]
setblock 317 136 286 minecraft:light[level=15]
setblock 317 136 294 minecraft:light[level=15]
setblock 317 136 302 minecraft:light[level=15]
setblock 317 136 310 minecraft:light[level=15]
setblock 322 136 275 minecraft:iron_block
fill 323 136 275 324 136 275 minecraft:gray_concrete
setblock 324 136 276 minecraft:gray_concrete
setblock 324 136 278 minecraft:gray_concrete
fill 324 136 283 324 136 285 minecraft:gray_concrete
setblock 324 136 286 minecraft:iron_block
setblock 324 136 287 minecraft:gray_concrete
setblock 324 136 292 minecraft:gray_concrete
setblock 324 136 295 minecraft:sea_lantern
fill 324 136 296 324 136 297 minecraft:gray_concrete
setblock 324 136 298 minecraft:iron_block
fill 324 136 299 324 136 301 minecraft:gray_concrete
setblock 324 136 302 minecraft:iron_block
setblock 324 136 303 minecraft:gray_concrete
setblock 324 136 308 minecraft:gray_concrete
fill 282 137 275 282 138 276 minecraft:yellow_concrete
fill 282 137 277 282 138 278 minecraft:black_concrete
fill 282 137 279 282 138 280 minecraft:yellow_concrete
fill 282 137 281 282 138 282 minecraft:black_concrete
fill 282 137 283 282 138 284 minecraft:yellow_concrete
fill 282 137 285 282 138 286 minecraft:black_concrete
fill 282 137 287 282 138 288 minecraft:yellow_concrete
fill 282 137 289 282 138 290 minecraft:black_concrete
fill 282 137 291 282 138 292 minecraft:yellow_concrete
fill 282 137 293 282 138 294 minecraft:black_concrete
fill 282 137 295 282 138 296 minecraft:yellow_concrete
fill 282 137 297 282 138 298 minecraft:black_concrete
fill 282 137 299 282 138 300 minecraft:yellow_concrete
fill 282 137 301 282 138 302 minecraft:black_concrete
fill 282 137 303 282 138 304 minecraft:yellow_concrete
fill 282 137 305 282 138 306 minecraft:black_concrete
fill 282 137 307 282 138 308 minecraft:yellow_concrete
fill 282 137 309 282 138 310 minecraft:black_concrete
fill 282 137 311 282 138 312 minecraft:yellow_concrete
fill 282 137 313 282 138 314 minecraft:black_concrete
fill 282 137 315 282 138 316 minecraft:yellow_concrete
fill 282 137 317 282 138 317 minecraft:black_concrete
fill 283 137 275 283 138 275 minecraft:yellow_concrete
fill 283 137 317 283 138 317 minecraft:yellow_concrete
fill 284 137 275 285 138 275 minecraft:black_concrete
fill 284 137 317 285 138 317 minecraft:black_concrete
fill 286 137 275 287 138 275 minecraft:yellow_concrete
fill 286 137 317 287 138 317 minecraft:yellow_concrete
fill 288 137 275 289 138 275 minecraft:black_concrete
fill 288 137 317 289 138 317 minecraft:black_concrete
fill 290 137 275 291 138 275 minecraft:yellow_concrete
fill 290 137 317 291 138 317 minecraft:yellow_concrete
fill 292 137 275 293 138 275 minecraft:black_concrete
fill 292 137 317 293 138 317 minecraft:black_concrete
fill 294 137 275 295 138 275 minecraft:yellow_concrete
fill 294 137 317 295 138 317 minecraft:yellow_concrete
fill 296 137 275 297 138 275 minecraft:black_concrete
fill 296 137 317 297 138 317 minecraft:black_concrete
fill 298 137 275 299 138 275 minecraft:yellow_concrete
fill 298 137 317 299 138 317 minecraft:yellow_concrete
fill 300 137 275 301 138 275 minecraft:black_concrete
fill 300 137 317 301 138 317 minecraft:black_concrete
fill 302 137 275 303 138 275 minecraft:yellow_concrete
fill 302 137 317 303 138 317 minecraft:yellow_concrete
fill 304 137 275 305 138 275 minecraft:black_concrete
fill 304 137 317 305 138 317 minecraft:black_concrete
fill 306 137 275 307 138 275 minecraft:yellow_concrete
fill 306 137 317 307 138 317 minecraft:yellow_concrete
fill 308 137 275 309 138 275 minecraft:black_concrete
fill 308 137 317 309 138 317 minecraft:black_concrete
fill 310 137 275 311 138 275 minecraft:yellow_concrete
fill 310 137 317 311 138 317 minecraft:yellow_concrete
fill 312 137 275 313 138 275 minecraft:black_concrete
fill 312 137 317 313 138 317 minecraft:black_concrete
fill 314 137 275 315 138 275 minecraft:yellow_concrete
fill 314 137 317 315 138 317 minecraft:yellow_concrete
fill 316 137 275 317 138 275 minecraft:black_concrete
fill 316 137 317 317 138 317 minecraft:black_concrete
fill 318 137 275 319 138 275 minecraft:yellow_concrete
fill 318 137 317 319 138 317 minecraft:yellow_concrete
fill 320 137 275 321 138 275 minecraft:black_concrete
fill 320 137 317 321 138 317 minecraft:black_concrete
fill 322 137 275 323 138 275 minecraft:yellow_concrete
fill 322 137 317 323 138 317 minecraft:yellow_concrete
fill 324 137 275 324 138 275 minecraft:black_concrete
fill 324 137 276 324 138 276 minecraft:yellow_concrete
fill 324 137 277 324 138 278 minecraft:black_concrete
fill 324 137 279 324 138 280 minecraft:yellow_concrete
fill 324 137 281 324 138 282 minecraft:black_concrete
fill 324 137 283 324 138 284 minecraft:yellow_concrete
fill 324 137 285 324 138 286 minecraft:black_concrete
fill 324 137 287 324 138 288 minecraft:yellow_concrete
fill 324 137 289 324 138 290 minecraft:black_concrete
fill 324 137 291 324 138 292 minecraft:yellow_concrete
fill 324 137 293 324 138 294 minecraft:black_concrete
fill 324 137 295 324 138 296 minecraft:yellow_concrete
fill 324 137 297 324 138 298 minecraft:black_concrete
fill 324 137 299 324 138 300 minecraft:yellow_concrete
fill 324 137 301 324 138 302 minecraft:black_concrete
fill 324 137 303 324 138 304 minecraft:yellow_concrete
fill 324 137 305 324 138 306 minecraft:black_concrete
fill 324 137 307 324 138 308 minecraft:yellow_concrete
fill 324 137 309 324 138 310 minecraft:black_concrete
fill 324 137 311 324 138 312 minecraft:yellow_concrete
fill 324 137 313 324 138 314 minecraft:black_concrete
fill 324 137 315 324 138 316 minecraft:yellow_concrete
fill 324 137 317 324 138 317 minecraft:black_concrete
fill 283 138 277 283 138 278 minecraft:iron_block
fill 283 138 287 283 138 288 minecraft:iron_block
fill 283 138 297 283 138 298 minecraft:iron_block
fill 283 138 307 283 138 308 minecraft:iron_block
fill 284 138 312 284 138 313 minecraft:gray_concrete
fill 284 138 316 285 138 316 minecraft:iron_block
setblock 285 138 278 minecraft:light[level=12]
setblock 285 138 285 minecraft:light[level=12]
setblock 285 138 292 minecraft:light[level=12]
setblock 285 138 299 minecraft:light[level=12]
setblock 285 138 306 minecraft:light[level=12]
setblock 285 138 311 minecraft:gray_concrete
fill 285 138 312 288 186 313 minecraft:iron_block
setblock 285 138 314 minecraft:gray_concrete
fill 286 138 310 287 138 310 minecraft:gray_concrete
fill 286 138 311 287 208 311 minecraft:iron_block
fill 286 138 314 287 208 314 minecraft:iron_block
setblock 288 138 311 minecraft:gray_concrete
setblock 288 138 314 minecraft:gray_concrete
fill 289 138 276 290 138 276 minecraft:iron_block
setblock 292 138 278 minecraft:light[level=12]
setblock 292 138 285 minecraft:light[level=12]
setblock 292 138 292 minecraft:light[level=12]
setblock 292 138 299 minecraft:light[level=12]
setblock 292 138 306 minecraft:light[level=12]
setblock 292 138 313 minecraft:light[level=12]
fill 294 138 316 295 138 316 minecraft:iron_block
fill 299 138 276 300 138 276 minecraft:iron_block
setblock 299 138 278 minecraft:light[level=12]
setblock 299 138 285 minecraft:light[level=12]
setblock 299 138 292 minecraft:light[level=12]
setblock 299 138 299 minecraft:light[level=12]
setblock 299 138 306 minecraft:light[level=12]
setblock 299 138 313 minecraft:light[level=12]
fill 304 138 316 305 138 316 minecraft:iron_block
setblock 306 138 278 minecraft:light[level=12]
setblock 306 138 285 minecraft:light[level=12]
setblock 306 138 292 minecraft:light[level=12]
setblock 306 138 299 minecraft:light[level=12]
setblock 306 138 306 minecraft:light[level=12]
setblock 306 138 313 minecraft:light[level=12]
fill 309 138 276 310 138 276 minecraft:iron_block
setblock 313 138 278 minecraft:light[level=12]
setblock 313 138 285 minecraft:light[level=12]
setblock 313 138 292 minecraft:light[level=12]
setblock 313 138 299 minecraft:light[level=12]
setblock 313 138 306 minecraft:light[level=12]
setblock 313 138 313 minecraft:light[level=12]
fill 314 138 316 315 138 316 minecraft:iron_block
fill 316 138 313 316 208 313 minecraft:iron_block
fill 317 138 278 319 184 280 minecraft:iron_block
fill 319 138 276 320 138 276 minecraft:iron_block
setblock 320 138 278 minecraft:light[level=12]
setblock 320 138 285 minecraft:light[level=12]
setblock 320 138 292 minecraft:light[level=12]
setblock 320 138 299 minecraft:light[level=12]
setblock 320 138 306 minecraft:light[level=12]
setblock 320 138 313 minecraft:light[level=12]
fill 323 138 282 323 138 283 minecraft:iron_block
fill 323 138 292 323 138 293 minecraft:iron_block
fill 323 138 302 323 138 303 minecraft:iron_block
fill 323 138 312 323 138 313 minecraft:iron_block
fill 282 139 275 282 164 280 minecraft:gray_concrete
fill 282 139 281 282 139 284 minecraft:pearlescent_froglight
fill 282 139 285 282 153 290 minecraft:gray_concrete
fill 282 139 291 282 139 294 minecraft:pearlescent_froglight
fill 282 139 295 282 141 300 minecraft:gray_concrete
fill 282 139 301 282 139 304 minecraft:pearlescent_froglight
fill 282 139 305 282 151 310 minecraft:gray_concrete
fill 282 139 311 282 139 314 minecraft:pearlescent_froglight
fill 282 139 315 282 147 317 minecraft:gray_concrete
fill 283 139 275 284 164 275 minecraft:gray_concrete
fill 283 139 277 283 208 277 minecraft:iron_block
fill 283 139 287 283 208 287 minecraft:iron_block
fill 283 139 297 283 208 297 minecraft:iron_block
fill 283 139 307 283 208 307 minecraft:iron_block
fill 283 139 317 285 164 317 minecraft:gray_concrete
fill 284 139 316 284 208 316 minecraft:iron_block
fill 285 139 275 288 139 275 minecraft:pearlescent_froglight
fill 286 139 317 289 139 317 minecraft:pearlescent_froglight
fill 289 139 275 294 141 275 minecraft:gray_concrete
fill 290 139 276 290 208 276 minecraft:iron_block
fill 290 139 317 295 164 317 minecraft:gray_concrete
fill 294 139 316 294 208 316 minecraft:iron_block
fill 295 139 275 298 139 275 minecraft:pearlescent_froglight
fill 296 139 317 299 139 317 minecraft:pearlescent_froglight
fill 299 139 275 304 160 275 minecraft:gray_concrete
fill 300 139 276 300 208 276 minecraft:iron_block
fill 300 139 317 305 143 317 minecraft:gray_concrete
fill 304 139 316 304 208 316 minecraft:iron_block
fill 305 139 275 308 139 275 minecraft:pearlescent_froglight
fill 306 139 317 309 139 317 minecraft:pearlescent_froglight
fill 309 139 275 311 148 275 minecraft:gray_concrete
fill 310 139 276 310 208 276 minecraft:iron_block
fill 310 139 317 315 164 317 minecraft:gray_concrete
setblock 312 139 275 minecraft:redstone_block
fill 313 139 275 314 164 275 minecraft:gray_concrete
fill 314 139 316 314 208 316 minecraft:iron_block
fill 315 139 275 318 139 275 minecraft:pearlescent_froglight
fill 316 139 317 319 139 317 minecraft:pearlescent_froglight
fill 319 139 275 324 142 275 minecraft:gray_concrete
fill 320 139 276 320 208 276 minecraft:iron_block
fill 320 139 317 324 164 317 minecraft:gray_concrete
fill 323 139 283 323 208 283 minecraft:iron_block
fill 323 139 293 323 208 293 minecraft:iron_block
fill 323 139 303 323 208 303 minecraft:iron_block
fill 323 139 313 323 208 313 minecraft:iron_block
fill 324 139 276 324 139 279 minecraft:pearlescent_froglight
fill 324 139 280 324 164 285 minecraft:gray_concrete
fill 324 139 286 324 139 289 minecraft:pearlescent_froglight
fill 324 139 290 324 164 295 minecraft:gray_concrete
fill 324 139 296 324 139 299 minecraft:pearlescent_froglight
fill 324 139 300 324 153 305 minecraft:gray_concrete
fill 324 139 306 324 139 309 minecraft:pearlescent_froglight
fill 324 139 310 324 164 315 minecraft:gray_concrete
setblock 324 139 316 minecraft:pearlescent_froglight
fill 282 140 281 282 147 284 minecraft:gray_concrete
fill 282 140 291 282 147 294 minecraft:gray_concrete
fill 282 140 301 282 147 304 minecraft:gray_concrete
fill 282 140 311 282 147 314 minecraft:gray_concrete
fill 285 140 275 288 147 275 minecraft:gray_concrete
fill 286 140 317 289 147 317 minecraft:gray_concrete
fill 295 140 275 298 145 275 minecraft:gray_concrete
fill 296 140 317 299 147 317 minecraft:gray_concrete
fill 305 140 275 308 147 275 minecraft:gray_concrete
fill 306 140 317 309 147 317 minecraft:gray_concrete
fill 312 140 275 312 164 275 minecraft:gray_concrete
fill 315 140 275 318 145 275 minecraft:gray_concrete
fill 315 140 312 315 140 314 minecraft:iron_block
fill 316 140 278 316 140 280 minecraft:iron_block
fill 316 140 312 317 140 312 minecraft:iron_block
fill 316 140 314 317 140 314 minecraft:iron_block
fill 316 140 317 319 147 317 minecraft:gray_concrete
fill 317 140 277 319 140 277 minecraft:iron_block
fill 317 140 281 319 140 281 minecraft:iron_block
setblock 317 140 313 minecraft:iron_block
fill 320 140 278 320 140 280 minecraft:iron_block
fill 324 140 276 324 147 279 minecraft:gray_concrete
fill 324 140 286 324 147 289 minecraft:gray_concrete
fill 324 140 296 324 147 299 minecraft:gray_concrete
fill 324 140 306 324 147 309 minecraft:gray_concrete
fill 324 140 316 324 147 316 minecraft:gray_concrete
fill 282 142 295 282 153 299 minecraft:gray_concrete
setblock 282 142 300 minecraft:sea_lantern
fill 289 142 275 292 151 275 minecraft:gray_concrete
setblock 293 142 275 minecraft:redstone_block
fill 294 142 275 294 150 275 minecraft:gray_concrete
fill 282 143 300 282 164 300 minecraft:gray_concrete
fill 293 143 275 293 164 275 minecraft:gray_concrete
fill 319 143 275 322 164 275 minecraft:gray_concrete
setblock 323 143 275 minecraft:sea_lantern
fill 324 143 275 324 164 275 minecraft:gray_concrete
setblock 283 144 278 minecraft:iron_block
fill 283 144 280 283 144 283 minecraft:iron_block
setblock 283 144 288 minecraft:iron_block
fill 283 144 290 283 144 293 minecraft:iron_block
setblock 283 144 298 minecraft:iron_block
fill 283 144 300 283 144 303 minecraft:iron_block
setblock 283 144 308 minecraft:iron_block
fill 283 144 310 283 144 313 minecraft:iron_block
fill 284 144 276 287 144 276 minecraft:iron_block
setblock 285 144 278 minecraft:light[level=15]
setblock 285 144 285 minecraft:light[level=12]
setblock 285 144 286 minecraft:light[level=15]
setblock 285 144 292 minecraft:light[level=12]
setblock 285 144 294 minecraft:light[level=15]
setblock 285 144 299 minecraft:light[level=12]
setblock 285 144 302 minecraft:light[level=15]
setblock 285 144 306 minecraft:light[level=12]
setblock 285 144 310 minecraft:light[level=15]
setblock 285 144 316 minecraft:iron_block
fill 287 144 316 290 144 316 minecraft:iron_block
setblock 289 144 276 minecraft:iron_block
setblock 292 144 278 minecraft:light[level=12]
setblock 292 144 285 minecraft:light[level=12]
setblock 292 144 292 minecraft:light[level=12]
setblock 292 144 299 minecraft:light[level=12]
setblock 292 144 306 minecraft:light[level=12]
setblock 292 144 313 minecraft:light[level=12]
setblock 293 144 278 minecraft:light[level=15]
setblock 293 144 286 minecraft:light[level=15]
setblock 293 144 294 minecraft:light[level=15]
setblock 293 144 302 minecraft:light[level=15]
setblock 293 144 310 minecraft:light[level=15]
fill 294 144 276 297 144 276 minecraft:iron_block
setblock 295 144 316 minecraft:iron_block
fill 297 144 316 300 144 316 minecraft:iron_block
setblock 299 144 276 minecraft:iron_block
setblock 299 144 278 minecraft:light[level=12]
setblock 299 144 285 minecraft:light[level=12]
setblock 299 144 292 minecraft:light[level=12]
setblock 299 144 299 minecraft:light[level=12]
setblock 299 144 306 minecraft:light[level=12]
setblock 299 144 313 minecraft:light[level=12]
fill 300 144 317 303 152 317 minecraft:gray_concrete
setblock 301 144 278 minecraft:light[level=15]
setblock 301 144 286 minecraft:light[level=15]
setblock 301 144 294 minecraft:light[level=15]
setblock 301 144 302 minecraft:light[level=15]
setblock 301 144 310 minecraft:light[level=15]
fill 304 144 276 307 144 276 minecraft:iron_block
setblock 304 144 317 minecraft:redstone_block
setblock 305 144 316 minecraft:iron_block
fill 305 144 317 305 164 317 minecraft:gray_concrete
setblock 306 144 278 minecraft:light[level=12]
setblock 306 144 285 minecraft:light[level=12]
setblock 306 144 292 minecraft:light[level=12]
setblock 306 144 299 minecraft:light[level=12]
setblock 306 144 306 minecraft:light[level=12]
setblock 306 144 313 minecraft:light[level=12]
fill 307 144 316 310 144 316 minecraft:iron_block
setblock 309 144 276 minecraft:iron_block
setblock 309 144 278 minecraft:light[level=15]
setblock 309 144 286 minecraft:light[level=15]
setblock 309 144 294 minecraft:light[level=15]
setblock 309 144 302 minecraft:light[level=15]
setblock 309 144 310 minecraft:light[level=15]
setblock 313 144 278 minecraft:light[level=12]
setblock 313 144 285 minecraft:light[level=12]
setblock 313 144 292 minecraft:light[level=12]
setblock 313 144 299 minecraft:light[level=12]
setblock 313 144 306 minecraft:light[level=12]
setblock 313 144 313 minecraft:light[level=12]
fill 314 144 276 317 144 276 minecraft:iron_block
setblock 315 144 316 minecraft:iron_block
setblock 317 144 286 minecraft:light[level=15]
setblock 317 144 294 minecraft:light[level=15]
setblock 317 144 302 minecraft:light[level=15]
setblock 317 144 310 minecraft:light[level=15]
fill 317 144 316 320 144 316 minecraft:iron_block
setblock 319 144 276 minecraft:iron_block
setblock 320 144 278 minecraft:light[level=12]
setblock 320 144 285 minecraft:light[level=12]
setblock 320 144 292 minecraft:light[level=12]
setblock 320 144 299 minecraft:light[level=12]
setblock 320 144 306 minecraft:light[level=12]
setblock 320 144 313 minecraft:light[level=12]
fill 323 144 275 323 164 275 minecraft:gray_concrete
fill 323 144 277 323 144 280 minecraft:iron_block
setblock 323 144 282 minecraft:iron_block
fill 323 144 287 323 144 290 minecraft:iron_block
setblock 323 144 292 minecraft:iron_block
fill 323 144 297 323 144 300 minecraft:iron_block
setblock 323 144 302 minecraft:iron_block
fill 323 144 307 323 144 310 minecraft:iron_block
setblock 323 144 312 minecraft:iron_block
fill 304 145 317 304 164 317 minecraft:gray_concrete
fill 316 145 278 316 145 280 minecraft:iron_block
fill 317 145 277 319 145 277 minecraft:iron_block
fill 317 145 281 319 145 281 minecraft:iron_block
fill 320 145 278 320 145 280 minecraft:iron_block
fill 284 146 312 284 146 313 minecraft:gray_concrete
setblock 285 146 311 minecraft:gray_concrete
setblock 285 146 314 minecraft:gray_concrete
fill 286 146 310 287 146 310 minecraft:gray_concrete
setblock 288 146 311 minecraft:gray_concrete
setblock 288 146 314 minecraft:gray_concrete
fill 295 146 275 297 147 275 minecraft:gray_concrete
setblock 298 146 275 minecraft:sea_lantern
fill 315 146 275 317 147 275 minecraft:gray_concrete
setblock 318 146 275 minecraft:sea_lantern
fill 293 147 306 293 154 306 minecraft:iron_block
setblock 298 147 275 minecraft:gray_concrete
fill 315 147 312 315 147 314 minecraft:iron_block
fill 316 147 312 317 147 312 minecraft:iron_block
fill 316 147 314 316 148 316 minecraft:iron_block
fill 317 147 313 317 147 314 minecraft:iron_block
setblock 318 147 275 minecraft:gray_concrete
fill 282 148 281 282 148 284 minecraft:pearlescent_froglight
fill 282 148 291 282 148 294 minecraft:pearlescent_froglight
fill 282 148 301 282 148 304 minecraft:pearlescent_froglight
fill 282 148 311 282 148 314 minecraft:pearlescent_froglight
fill 282 148 315 282 164 315 minecraft:gray_concrete
setblock 282 148 316 minecraft:redstone_block
fill 282 148 317 282 164 317 minecraft:gray_concrete
fill 285 148 275 288 148 275 minecraft:pearlescent_froglight
fill 286 148 317 289 148 317 minecraft:pearlescent_froglight
fill 295 148 275 298 148 275 minecraft:pearlescent_froglight
fill 296 148 317 299 148 317 minecraft:pearlescent_froglight
fill 305 148 275 308 148 275 minecraft:pearlescent_froglight
fill 306 148 317 309 148 317 minecraft:pearlescent_froglight
fill 315 148 275 318 148 275 minecraft:pearlescent_froglight
setblock 316 148 312 minecraft:pearlescent_froglight
fill 316 148 317 319 148 317 minecraft:pearlescent_froglight
fill 324 148 276 324 148 279 minecraft:pearlescent_froglight
fill 324 148 286 324 148 289 minecraft:pearlescent_froglight
fill 324 148 296 324 148 299 minecraft:pearlescent_froglight
fill 324 148 306 324 148 309 minecraft:pearlescent_froglight
setblock 324 148 316 minecraft:pearlescent_froglight
fill 282 149 281 282 156 284 minecraft:gray_concrete
fill 282 149 291 282 156 294 minecraft:gray_concrete
fill 282 149 301 282 156 304 minecraft:gray_concrete
fill 282 149 311 282 156 314 minecraft:gray_concrete
fill 282 149 316 282 164 316 minecraft:gray_concrete
fill 285 149 275 288 156 275 minecraft:gray_concrete
fill 286 149 317 289 150 317 minecraft:gray_concrete
fill 295 149 275 298 156 275 minecraft:gray_concrete
fill 296 149 317 296 156 317 minecraft:gray_concrete
setblock 297 149 317 minecraft:sea_lantern
fill 298 149 317 299 156 317 minecraft:gray_concrete
fill 305 149 275 310 156 275 minecraft:gray_concrete
fill 306 149 317 309 156 317 minecraft:gray_concrete
setblock 311 149 275 minecraft:sea_lantern
fill 315 149 275 318 156 275 minecraft:gray_concrete
fill 316 149 317 319 156 317 minecraft:gray_concrete
fill 324 149 276 324 156 279 minecraft:gray_concrete
fill 324 149 286 324 150 289 minecraft:gray_concrete
fill 324 149 296 324 156 299 minecraft:gray_concrete
fill 324 149 306 324 156 309 minecraft:gray_concrete
fill 324 149 316 324 156 316 minecraft:gray_concrete
setblock 283 150 278 minecraft:iron_block
setblock 283 150 288 minecraft:iron_block
setblock 283 150 298 minecraft:iron_block
setblock 283 150 308 minecraft:iron_block
setblock 285 150 278 minecraft:light[level=12]
setblock 285 150 285 minecraft:light[level=12]
setblock 285 150 292 minecraft:light[level=12]
setblock 285 150 299 minecraft:light[level=12]
setblock 285 150 306 minecraft:light[level=12]
setblock 285 150 316 minecraft:iron_block
setblock 289 150 276 minecraft:iron_block
setblock 292 150 278 minecraft:light[level=12]
setblock 292 150 285 minecraft:light[level=12]
setblock 292 150 292 minecraft:light[level=12]
setblock 292 150 299 minecraft:light[level=12]
setblock 292 150 306 minecraft:light[level=12]
setblock 292 150 313 minecraft:light[level=12]
setblock 295 150 316 minecraft:iron_block
fill 297 150 317 297 152 317 minecraft:gray_concrete
setblock 299 150 276 minecraft:iron_block
setblock 299 150 278 minecraft:light[level=12]
setblock 299 150 285 minecraft:light[level=12]
setblock 299 150 292 minecraft:light[level=12]
setblock 299 150 299 minecraft:light[level=12]
setblock 299 150 306 minecraft:light[level=12]
setblock 299 150 313 minecraft:light[level=12]
setblock 305 150 316 minecraft:iron_block
setblock 306 150 278 minecraft:light[level=12]
setblock 306 150 285 minecraft:light[level=12]
setblock 306 150 292 minecraft:light[level=12]
setblock 306 150 299 minecraft:light[level=12]
setblock 306 150 306 minecraft:light[level=12]
setblock 306 150 313 minecraft:light[level=12]
setblock 309 150 276 minecraft:iron_block
fill 311 150 275 311 164 275 minecraft:gray_concrete
setblock 313 150 278 minecraft:light[level=12]
setblock 313 150 285 minecraft:light[level=12]
setblock 313 150 292 minecraft:light[level=12]
setblock 313 150 299 minecraft:light[level=12]
setblock 313 150 306 minecraft:light[level=12]
setblock 313 150 313 minecraft:light[level=12]
setblock 315 150 316 minecraft:iron_block
fill 316 150 278 316 150 280 minecraft:iron_block
fill 317 150 277 319 150 277 minecraft:iron_block
fill 317 150 281 319 150 281 minecraft:iron_block
setblock 319 150 276 minecraft:iron_block
fill 320 150 278 320 150 280 minecraft:iron_block
setblock 320 150 285 minecraft:light[level=12]
setblock 320 150 292 minecraft:light[level=12]
setblock 320 150 299 minecraft:light[level=12]
setblock 320 150 306 minecraft:light[level=12]
setblock 320 150 313 minecraft:light[level=12]
setblock 323 150 282 minecraft:iron_block
setblock 323 150 292 minecraft:iron_block
setblock 323 150 302 minecraft:iron_block
setblock 323 150 312 minecraft:iron_block
setblock 286 151 317 minecraft:sea_lantern
fill 287 151 317 289 156 317 minecraft:gray_concrete
setblock 294 151 275 minecraft:redstone_block
fill 324 151 286 324 152 288 minecraft:gray_concrete
setblock 324 151 289 minecraft:sea_lantern
fill 282 152 305 282 164 305 minecraft:gray_concrete
setblock 282 152 306 minecraft:sea_lantern
fill 282 152 307 282 164 310 minecraft:gray_concrete
setblock 285 152 278 minecraft:light[level=15]
setblock 285 152 286 minecraft:light[level=15]
setblock 285 152 294 minecraft:light[level=15]
setblock 285 152 302 minecraft:light[level=15]
setblock 285 152 310 minecraft:light[level=15]
fill 286 152 317 286 156 317 minecraft:gray_concrete
setblock 289 152 275 minecraft:sea_lantern
fill 290 152 275 292 164 275 minecraft:gray_concrete
setblock 293 152 278 minecraft:light[level=15]
setblock 293 152 286 minecraft:light[level=15]
setblock 293 152 294 minecraft:light[level=15]
setblock 293 152 302 minecraft:light[level=15]
setblock 293 152 310 minecraft:light[level=15]
fill 294 152 275 294 164 275 minecraft:gray_concrete
setblock 301 152 278 minecraft:light[level=15]
setblock 301 152 286 minecraft:light[level=15]
setblock 301 152 294 minecraft:light[level=15]
setblock 301 152 302 minecraft:light[level=15]
setblock 301 152 310 minecraft:light[level=15]
setblock 309 152 278 minecraft:light[level=15]
setblock 309 152 286 minecraft:light[level=15]
setblock 309 152 294 minecraft:light[level=15]
setblock 309 152 302 minecraft:light[level=15]
setblock 309 152 310 minecraft:light[level=15]
setblock 317 152 286 minecraft:light[level=15]
setblock 317 152 294 minecraft:light[level=15]
setblock 317 152 302 minecraft:light[level=15]
setblock 317 152 310 minecraft:light[level=15]
fill 324 152 289 324 156 289 minecraft:gray_concrete
fill 282 153 306 282 164 306 minecraft:gray_concrete
fill 283 153 280 283 153 283 minecraft:iron_block
fill 283 153 290 283 153 293 minecraft:iron_block
fill 283 153 300 283 153 303 minecraft:iron_block
fill 283 153 310 283 153 313 minecraft:iron_block
fill 284 153 276 287 153 276 minecraft:iron_block
fill 287 153 316 290 153 316 minecraft:iron_block
fill 289 153 275 289 164 275 minecraft:gray_concrete
fill 294 153 276 297 153 276 minecraft:iron_block
fill 297 153 316 300 153 316 minecraft:iron_block
setblock 297 153 317 minecraft:redstone_block
fill 300 153 317 301 159 317 minecraft:gray_concrete
setblock 302 153 317 minecraft:sea_lantern
fill 303 153 317 303 164 317 minecraft:gray_concrete
fill 304 153 276 307 153 276 minecraft:iron_block
fill 307 153 316 310 153 316 minecraft:iron_block
fill 314 153 276 317 153 276 minecraft:iron_block
fill 317 153 316 320 153 316 minecraft:iron_block
fill 323 153 277 323 153 280 minecraft:iron_block
fill 323 153 287 323 153 290 minecraft:iron_block
fill 323 153 297 323 153 300 minecraft:iron_block
fill 323 153 307 323 153 310 minecraft:iron_block
setblock 324 153 286 minecraft:sea_lantern
fill 324 153 287 324 156 288 minecraft:gray_concrete
fill 282 154 285 282 164 287 minecraft:gray_concrete
setblock 282 154 288 minecraft:sea_lantern
fill 282 154 289 282 164 290 minecraft:gray_concrete
fill 282 154 295 282 164 296 minecraft:gray_concrete
setblock 282 154 297 minecraft:sea_lantern
fill 282 154 298 282 164 299 minecraft:gray_concrete
fill 284 154 312 284 154 313 minecraft:gray_concrete
setblock 285 154 311 minecraft:gray_concrete
setblock 285 154 314 minecraft:gray_concrete
fill 286 154 310 287 154 310 minecraft:gray_concrete
setblock 288 154 311 minecraft:gray_concrete
setblock 288 154 314 minecraft:gray_concrete
fill 297 154 317 297 156 317 minecraft:gray_concrete
fill 302 154 317 302 164 317 minecraft:gray_concrete
fill 315 154 312 315 154 314 minecraft:iron_block
fill 316 154 312 317 154 312 minecraft:iron_block
fill 316 154 314 317 154 314 minecraft:iron_block
setblock 317 154 313 minecraft:iron_block
fill 324 154 286 324 156 286 minecraft:gray_concrete
fill 324 154 300 324 164 304 minecraft:gray_concrete
setblock 324 154 305 minecraft:sea_lantern
fill 282 155 288 282 164 288 minecraft:gray_concrete
fill 282 155 297 282 164 297 minecraft:gray_concrete
fill 316 155 278 316 155 280 minecraft:iron_block
fill 317 155 277 319 155 277 minecraft:iron_block
fill 317 155 281 319 155 281 minecraft:iron_block
fill 320 155 278 320 155 280 minecraft:iron_block
fill 324 155 305 324 160 305 minecraft:gray_concrete
setblock 283 156 278 minecraft:iron_block
setblock 283 156 288 minecraft:iron_block
setblock 283 156 298 minecraft:iron_block
setblock 283 156 308 minecraft:iron_block
setblock 285 156 278 minecraft:light[level=12]
setblock 285 156 285 minecraft:light[level=12]
setblock 285 156 292 minecraft:light[level=12]
setblock 285 156 299 minecraft:light[level=12]
setblock 285 156 306 minecraft:light[level=12]
setblock 285 156 316 minecraft:iron_block
setblock 289 156 276 minecraft:iron_block
setblock 292 156 278 minecraft:light[level=12]
setblock 292 156 285 minecraft:light[level=12]
setblock 292 156 292 minecraft:light[level=12]
setblock 292 156 299 minecraft:light[level=12]
setblock 292 156 306 minecraft:light[level=12]
setblock 292 156 313 minecraft:light[level=12]
setblock 295 156 316 minecraft:iron_block
setblock 299 156 276 minecraft:iron_block
setblock 299 156 278 minecraft:light[level=12]
setblock 299 156 285 minecraft:light[level=12]
setblock 299 156 292 minecraft:light[level=12]
setblock 299 156 299 minecraft:light[level=12]
setblock 299 156 306 minecraft:light[level=12]
setblock 299 156 313 minecraft:light[level=12]
setblock 305 156 316 minecraft:iron_block
setblock 306 156 278 minecraft:light[level=12]
setblock 306 156 285 minecraft:light[level=12]
setblock 306 156 292 minecraft:light[level=12]
setblock 306 156 299 minecraft:light[level=12]
setblock 306 156 306 minecraft:light[level=12]
setblock 306 156 313 minecraft:light[level=12]
setblock 309 156 276 minecraft:iron_block
setblock 313 156 278 minecraft:light[level=12]
setblock 313 156 285 minecraft:light[level=12]
setblock 313 156 292 minecraft:light[level=12]
setblock 313 156 299 minecraft:light[level=12]
setblock 313 156 306 minecraft:light[level=12]
setblock 313 156 313 minecraft:light[level=12]
setblock 315 156 316 minecraft:iron_block
fill 316 156 300 320 157 304 minecraft:gray_concrete
setblock 319 156 276 minecraft:iron_block
setblock 320 156 278 minecraft:light[level=12]
setblock 320 156 285 minecraft:light[level=12]
setblock 320 156 292 minecraft:light[level=12]
setblock 320 156 299 minecraft:light[level=12]
setblock 320 156 306 minecraft:light[level=12]
setblock 320 156 313 minecraft:light[level=12]
fill 321 156 302 322 156 302 minecraft:gray_concrete
setblock 323 156 282 minecraft:iron_block
setblock 323 156 292 minecraft:iron_block
setblock 323 156 302 minecraft:iron_block
setblock 323 156 312 minecraft:iron_block
fill 282 157 281 282 157 284 minecraft:pearlescent_froglight
fill 282 157 291 282 157 294 minecraft:pearlescent_froglight
fill 282 157 301 282 157 304 minecraft:pearlescent_froglight
fill 282 157 311 282 157 314 minecraft:pearlescent_froglight
fill 285 157 275 288 157 275 minecraft:pearlescent_froglight
fill 286 157 317 289 157 317 minecraft:pearlescent_froglight
fill 295 157 275 298 157 275 minecraft:pearlescent_froglight
fill 296 157 317 299 157 317 minecraft:pearlescent_froglight
fill 299 157 310 299 164 310 minecraft:iron_block
fill 305 157 275 308 157 275 minecraft:pearlescent_froglight
fill 306 157 317 309 157 317 minecraft:pearlescent_froglight
fill 309 157 275 310 164 275 minecraft:gray_concrete
fill 315 157 275 318 157 275 minecraft:pearlescent_froglight
fill 316 157 317 319 157 317 minecraft:pearlescent_froglight
fill 324 157 276 324 157 279 minecraft:pearlescent_froglight
fill 324 157 286 324 157 289 minecraft:pearlescent_froglight
fill 324 157 296 324 157 299 minecraft:pearlescent_froglight
fill 324 157 306 324 157 309 minecraft:pearlescent_froglight
setblock 324 157 316 minecraft:pearlescent_froglight
fill 282 158 281 282 164 284 minecraft:gray_concrete
fill 282 158 291 282 164 294 minecraft:gray_concrete
fill 282 158 301 282 164 304 minecraft:gray_concrete
fill 282 158 311 282 164 314 minecraft:gray_concrete
fill 285 158 275 288 164 275 minecraft:gray_concrete
fill 286 158 317 289 164 317 minecraft:gray_concrete
fill 295 158 275 298 164 275 minecraft:gray_concrete
fill 296 158 317 299 158 317 minecraft:gray_concrete
fill 300 158 310 300 163 310 minecraft:iron_block
fill 305 158 275 308 159 275 minecraft:gray_concrete
fill 306 158 317 309 164 317 minecraft:gray_concrete
fill 315 158 275 318 164 275 minecraft:gray_concrete
fill 316 158 317 319 159 317 minecraft:gray_concrete
fill 324 158 276 324 164 279 minecraft:gray_concrete
fill 324 158 286 324 164 289 minecraft:gray_concrete
fill 324 158 296 324 164 299 minecraft:gray_concrete
fill 324 158 306 324 164 309 minecraft:gray_concrete
fill 324 158 316 324 164 316 minecraft:gray_concrete
fill 296 159 317 298 164 317 minecraft:gray_concrete
setblock 299 159 317 minecraft:redstone_block
setblock 285 160 278 minecraft:light[level=15]
setblock 285 160 286 minecraft:light[level=15]
setblock 285 160 294 minecraft:light[level=15]
setblock 285 160 302 minecraft:light[level=15]
setblock 285 160 310 minecraft:light[level=15]
setblock 293 160 278 minecraft:light[level=15]
setblock 293 160 286 minecraft:light[level=15]
setblock 293 160 294 minecraft:light[level=15]
setblock 293 160 302 minecraft:light[level=15]
setblock 293 160 310 minecraft:light[level=15]
fill 299 160 317 299 164 317 minecraft:gray_concrete
setblock 300 160 317 minecraft:sea_lantern
setblock 301 160 278 minecraft:light[level=15]
setblock 301 160 286 minecraft:light[level=15]
setblock 301 160 294 minecraft:light[level=15]
setblock 301 160 302 minecraft:light[level=15]
setblock 301 160 310 minecraft:light[level=15]
fill 301 160 317 301 164 317 minecraft:gray_concrete
fill 305 160 275 306 164 275 minecraft:gray_concrete
setblock 307 160 275 minecraft:redstone_block
fill 308 160 275 308 164 275 minecraft:gray_concrete
setblock 309 160 278 minecraft:light[level=15]
setblock 309 160 286 minecraft:light[level=15]
setblock 309 160 294 minecraft:light[level=15]
setblock 309 160 302 minecraft:light[level=15]
setblock 309 160 310 minecraft:light[level=15]
fill 316 160 278 316 160 280 minecraft:iron_block
setblock 316 160 317 minecraft:sea_lantern
fill 317 160 277 319 160 277 minecraft:iron_block
fill 317 160 281 319 160 281 minecraft:iron_block
setblock 317 160 286 minecraft:light[level=15]
setblock 317 160 294 minecraft:light[level=15]
setblock 317 160 302 minecraft:light[level=15]
setblock 317 160 310 minecraft:light[level=15]
fill 317 160 317 319 164 317 minecraft:gray_concrete
fill 320 160 278 320 160 280 minecraft:iron_block
fill 299 161 275 300 164 275 minecraft:gray_concrete
fill 300 161 317 300 164 317 minecraft:gray_concrete
setblock 301 161 275 minecraft:sea_lantern
fill 302 161 275 304 164 275 minecraft:gray_concrete
fill 307 161 275 307 164 275 minecraft:gray_concrete
fill 315 161 300 315 162 304 minecraft:iron_block
fill 315 161 312 315 161 314 minecraft:iron_block
fill 316 161 299 316 162 300 minecraft:iron_block
fill 316 161 302 321 162 302 minecraft:iron_block
fill 316 161 304 316 162 305 minecraft:iron_block
fill 316 161 312 317 161 312 minecraft:iron_block
fill 316 161 314 317 161 314 minecraft:iron_block
fill 316 161 317 316 164 317 minecraft:gray_concrete
fill 317 161 299 320 162 299 minecraft:iron_block
fill 317 161 305 320 162 305 minecraft:iron_block
setblock 317 161 313 minecraft:iron_block
fill 318 161 300 318 162 301 minecraft:iron_block
fill 318 161 303 318 162 304 minecraft:iron_block
fill 319 161 282 319 171 282 minecraft:iron_block
fill 320 161 300 321 162 300 minecraft:iron_block
fill 320 161 304 321 162 304 minecraft:iron_block
fill 321 161 301 321 162 301 minecraft:iron_block
fill 321 161 303 321 162 303 minecraft:iron_block
setblock 324 161 305 minecraft:redstone_block
setblock 283 162 278 minecraft:iron_block
fill 283 162 280 283 162 283 minecraft:iron_block
setblock 283 162 288 minecraft:iron_block
fill 283 162 290 283 162 293 minecraft:iron_block
setblock 283 162 298 minecraft:iron_block
fill 283 162 300 283 162 303 minecraft:iron_block
setblock 283 162 308 minecraft:iron_block
fill 283 162 310 283 162 313 minecraft:iron_block
fill 284 162 276 287 162 276 minecraft:iron_block
fill 284 162 312 284 162 313 minecraft:gray_concrete
setblock 285 162 278 minecraft:light[level=12]
setblock 285 162 285 minecraft:light[level=12]
setblock 285 162 292 minecraft:light[level=12]
setblock 285 162 299 minecraft:light[level=12]
setblock 285 162 306 minecraft:light[level=12]
setblock 285 162 311 minecraft:gray_concrete
setblock 285 162 314 minecraft:gray_concrete
setblock 285 162 316 minecraft:iron_block
fill 286 162 310 287 162 310 minecraft:gray_concrete
fill 287 162 316 290 162 316 minecraft:iron_block
setblock 288 162 311 minecraft:gray_concrete
setblock 288 162 314 minecraft:gray_concrete
setblock 289 162 276 minecraft:iron_block
setblock 292 162 278 minecraft:light[level=12]
setblock 292 162 285 minecraft:light[level=12]
setblock 292 162 292 minecraft:light[level=12]
setblock 292 162 299 minecraft:light[level=12]
setblock 292 162 306 minecraft:light[level=12]
setblock 292 162 313 minecraft:light[level=12]
fill 294 162 276 297 162 276 minecraft:iron_block
setblock 295 162 316 minecraft:iron_block
fill 297 162 316 300 162 316 minecraft:iron_block
setblock 299 162 276 minecraft:iron_block
setblock 299 162 278 minecraft:light[level=12]
setblock 299 162 285 minecraft:light[level=12]
setblock 299 162 292 minecraft:light[level=12]
setblock 299 162 299 minecraft:light[level=12]
setblock 299 162 306 minecraft:light[level=12]
setblock 299 162 313 minecraft:light[level=12]
fill 300 162 280 300 175 280 minecraft:iron_block
fill 301 162 275 301 164 275 minecraft:gray_concrete
fill 304 162 276 307 162 276 minecraft:iron_block
setblock 305 162 316 minecraft:iron_block
setblock 306 162 278 minecraft:light[level=12]
setblock 306 162 285 minecraft:light[level=12]
setblock 306 162 292 minecraft:light[level=12]
setblock 306 162 299 minecraft:light[level=12]
setblock 306 162 306 minecraft:light[level=12]
setblock 306 162 313 minecraft:light[level=12]
fill 307 162 316 310 162 316 minecraft:iron_block
setblock 309 162 276 minecraft:iron_block
setblock 313 162 278 minecraft:light[level=12]
setblock 313 162 285 minecraft:light[level=12]
setblock 313 162 292 minecraft:light[level=12]
setblock 313 162 299 minecraft:light[level=12]
setblock 313 162 306 minecraft:light[level=12]
setblock 313 162 313 minecraft:light[level=12]
fill 314 162 276 317 162 276 minecraft:iron_block
setblock 315 162 316 minecraft:iron_block
fill 317 162 316 320 162 316 minecraft:iron_block
setblock 319 162 276 minecraft:iron_block
setblock 320 162 278 minecraft:light[level=12]
setblock 320 162 285 minecraft:light[level=12]
setblock 320 162 292 minecraft:light[level=12]
setblock 320 162 306 minecraft:light[level=12]
setblock 320 162 313 minecraft:light[level=12]
fill 323 162 277 323 162 280 minecraft:iron_block
setblock 323 162 282 minecraft:iron_block
fill 323 162 287 323 162 290 minecraft:iron_block
setblock 323 162 292 minecraft:iron_block
fill 323 162 297 323 162 300 minecraft:iron_block
setblock 323 162 302 minecraft:iron_block
fill 323 162 307 323 162 310 minecraft:iron_block
setblock 323 162 312 minecraft:iron_block
fill 324 162 305 324 164 305 minecraft:gray_concrete
fill 317 164 276 319 165 277 minecraft:iron_block
fill 282 165 275 282 166 276 minecraft:yellow_concrete
fill 282 165 277 282 166 278 minecraft:black_concrete
fill 282 165 279 282 166 280 minecraft:yellow_concrete
fill 282 165 281 282 165 282 minecraft:black_concrete
fill 282 165 283 282 165 284 minecraft:yellow_concrete
fill 282 165 285 282 166 286 minecraft:black_concrete
fill 282 165 287 282 166 288 minecraft:yellow_concrete
fill 282 165 289 282 166 290 minecraft:black_concrete
fill 282 165 291 282 165 292 minecraft:yellow_concrete
fill 282 165 293 282 165 294 minecraft:black_concrete
fill 282 165 295 282 166 296 minecraft:yellow_concrete
fill 282 165 297 282 166 298 minecraft:black_concrete
fill 282 165 299 282 166 300 minecraft:yellow_concrete
fill 282 165 301 282 165 302 minecraft:black_concrete
fill 282 165 303 282 165 304 minecraft:yellow_concrete
fill 282 165 305 282 166 306 minecraft:black_concrete
fill 282 165 307 282 166 308 minecraft:yellow_concrete
fill 282 165 309 282 166 310 minecraft:black_concrete
fill 282 165 311 282 165 312 minecraft:yellow_concrete
fill 282 165 313 282 165 314 minecraft:black_concrete
fill 282 165 315 282 166 316 minecraft:yellow_concrete
fill 282 165 317 282 166 317 minecraft:black_concrete
fill 283 165 275 283 166 275 minecraft:yellow_concrete
fill 283 165 317 283 166 317 minecraft:yellow_concrete
fill 284 165 275 285 165 275 minecraft:black_concrete
fill 284 165 317 285 166 317 minecraft:black_concrete
fill 286 165 275 287 165 275 minecraft:yellow_concrete
fill 286 165 317 287 165 317 minecraft:yellow_concrete
fill 288 165 275 289 165 275 minecraft:black_concrete
fill 288 165 317 289 165 317 minecraft:black_concrete
fill 290 165 275 291 166 275 minecraft:yellow_concrete
fill 290 165 317 291 166 317 minecraft:yellow_concrete
fill 292 165 275 293 166 275 minecraft:black_concrete
fill 292 165 317 293 166 317 minecraft:black_concrete
fill 294 165 275 295 165 275 minecraft:yellow_concrete
fill 294 165 317 295 166 317 minecraft:yellow_concrete
fill 296 165 275 297 165 275 minecraft:black_concrete
fill 296 165 317 297 165 317 minecraft:black_concrete
fill 298 165 275 299 165 275 minecraft:yellow_concrete
fill 298 165 317 299 165 317 minecraft:yellow_concrete
fill 300 165 275 301 166 275 minecraft:black_concrete
fill 300 165 317 301 166 317 minecraft:black_concrete
fill 302 165 275 303 166 275 minecraft:yellow_concrete
fill 302 165 317 303 166 317 minecraft:yellow_concrete
fill 304 165 275 305 165 275 minecraft:black_concrete
fill 304 165 317 305 166 317 minecraft:black_concrete
fill 306 165 275 307 165 275 minecraft:yellow_concrete
fill 306 165 317 307 165 317 minecraft:yellow_concrete
fill 308 165 275 309 165 275 minecraft:black_concrete
fill 308 165 317 309 165 317 minecraft:black_concrete
fill 310 165 275 311 166 275 minecraft:yellow_concrete
fill 310 165 313 310 166 315 minecraft:iron_block
fill 310 165 317 311 166 317 minecraft:yellow_concrete
fill 312 165 275 313 166 275 minecraft:black_concrete
fill 312 165 317 313 166 317 minecraft:black_concrete
fill 314 165 275 315 165 275 minecraft:yellow_concrete
fill 314 165 317 315 166 317 minecraft:yellow_concrete
fill 316 165 275 317 165 275 minecraft:black_concrete
fill 316 165 278 316 165 280 minecraft:iron_block
fill 316 165 317 317 165 317 minecraft:black_concrete
fill 317 165 281 319 165 281 minecraft:iron_block
fill 318 165 275 319 165 275 minecraft:yellow_concrete
fill 318 165 317 319 165 317 minecraft:yellow_concrete
fill 320 165 275 321 166 275 minecraft:black_concrete
fill 320 165 278 320 165 280 minecraft:iron_block
fill 320 165 317 321 166 317 minecraft:black_concrete
fill 322 165 275 323 166 275 minecraft:yellow_concrete
fill 322 165 317 323 166 317 minecraft:yellow_concrete
fill 324 165 275 324 166 275 minecraft:black_concrete
setblock 324 165 276 minecraft:yellow_concrete
fill 324 165 277 324 165 278 minecraft:black_concrete
fill 324 165 279 324 165 280 minecraft:yellow_concrete
fill 324 165 281 324 166 282 minecraft:black_concrete
fill 324 165 283 324 166 284 minecraft:yellow_concrete
fill 324 165 285 324 165 286 minecraft:black_concrete
fill 324 165 287 324 165 288 minecraft:yellow_concrete
fill 324 165 289 324 165 290 minecraft:black_concrete
fill 324 165 291 324 166 292 minecraft:yellow_concrete
fill 324 165 293 324 166 294 minecraft:black_concrete
fill 324 165 295 324 165 296 minecraft:yellow_concrete
fill 324 165 297 324 165 298 minecraft:black_concrete
fill 324 165 299 324 165 300 minecraft:yellow_concrete
fill 324 165 301 324 166 302 minecraft:black_concrete
fill 324 165 303 324 166 304 minecraft:yellow_concrete
fill 324 165 305 324 165 306 minecraft:black_concrete
fill 324 165 307 324 165 308 minecraft:yellow_concrete
fill 324 165 309 324 165 310 minecraft:black_concrete
fill 324 165 311 324 166 312 minecraft:yellow_concrete
fill 324 165 313 324 166 314 minecraft:black_concrete
fill 324 165 315 324 165 316 minecraft:yellow_concrete
fill 324 165 317 324 166 317 minecraft:black_concrete
fill 282 166 281 282 166 284 minecraft:pearlescent_froglight
fill 282 166 291 282 166 294 minecraft:pearlescent_froglight
fill 282 166 301 282 166 304 minecraft:pearlescent_froglight
fill 282 166 311 282 166 314 minecraft:pearlescent_froglight
setblock 284 166 275 minecraft:black_concrete
fill 285 166 275 288 166 275 minecraft:pearlescent_froglight
fill 286 166 317 289 166 317 minecraft:pearlescent_froglight
setblock 289 166 275 minecraft:black_concrete
setblock 294 166 275 minecraft:yellow_concrete
fill 295 166 275 298 166 275 minecraft:pearlescent_froglight
fill 296 166 317 299 166 317 minecraft:pearlescent_froglight
setblock 299 166 275 minecraft:yellow_concrete
setblock 304 166 275 minecraft:black_concrete
fill 305 166 275 308 166 275 minecraft:pearlescent_froglight
fill 306 166 317 309 166 317 minecraft:pearlescent_froglight
setblock 309 166 275 minecraft:black_concrete
setblock 314 166 275 minecraft:yellow_concrete
fill 315 166 275 318 166 275 minecraft:pearlescent_froglight
fill 316 166 317 319 166 317 minecraft:pearlescent_froglight
setblock 319 166 275 minecraft:yellow_concrete
fill 324 166 276 324 166 279 minecraft:pearlescent_froglight
setblock 324 166 280 minecraft:yellow_concrete
setblock 324 166 285 minecraft:black_concrete
fill 324 166 286 324 166 289 minecraft:pearlescent_froglight
setblock 324 166 290 minecraft:black_concrete
setblock 324 166 295 minecraft:yellow_concrete
fill 324 166 296 324 166 299 minecraft:pearlescent_froglight
setblock 324 166 300 minecraft:yellow_concrete
setblock 324 166 305 minecraft:black_concrete
fill 324 166 306 324 166 309 minecraft:pearlescent_froglight
setblock 324 166 310 minecraft:black_concrete
setblock 324 166 315 minecraft:yellow_concrete
setblock 324 166 316 minecraft:pearlescent_froglight
fill 282 167 275 282 167 317 minecraft:gray_concrete
fill 283 167 275 324 169 275 minecraft:gray_concrete
fill 283 167 317 310 167 317 minecraft:gray_concrete
setblock 311 167 317 minecraft:redstone_block
fill 312 167 317 324 168 317 minecraft:gray_concrete
setblock 324 167 276 minecraft:redstone_block
fill 324 167 277 324 174 316 minecraft:gray_concrete
fill 282 168 275 282 170 297 minecraft:gray_concrete
setblock 282 168 298 minecraft:sea_lantern
fill 282 168 299 282 174 317 minecraft:gray_concrete
setblock 283 168 278 minecraft:iron_block
setblock 283 168 288 minecraft:iron_block
setblock 283 168 298 minecraft:iron_block
setblock 283 168 308 minecraft:iron_block
fill 283 168 317 300 174 317 minecraft:gray_concrete
setblock 285 168 278 minecraft:light[level=15]
setblock 285 168 285 minecraft:light[level=12]
setblock 285 168 286 minecraft:light[level=15]
setblock 285 168 292 minecraft:light[level=12]
setblock 285 168 294 minecraft:light[level=15]
setblock 285 168 299 minecraft:light[level=12]
setblock 285 168 302 minecraft:light[level=15]
setblock 285 168 306 minecraft:light[level=12]
setblock 285 168 310 minecraft:light[level=15]
setblock 285 168 316 minecraft:iron_block
setblock 289 168 276 minecraft:iron_block
setblock 292 168 278 minecraft:light[level=12]
setblock 292 168 285 minecraft:light[level=12]
setblock 292 168 292 minecraft:light[level=12]
setblock 292 168 299 minecraft:light[level=12]
setblock 292 168 306 minecraft:light[level=12]
setblock 292 168 313 minecraft:light[level=12]
setblock 293 168 278 minecraft:light[level=15]
setblock 293 168 286 minecraft:light[level=15]
setblock 293 168 294 minecraft:light[level=15]
setblock 293 168 302 minecraft:light[level=15]
setblock 293 168 310 minecraft:light[level=15]
setblock 295 168 316 minecraft:iron_block
setblock 299 168 276 minecraft:iron_block
setblock 299 168 278 minecraft:light[level=12]
setblock 299 168 285 minecraft:light[level=12]
setblock 299 168 292 minecraft:light[level=12]
setblock 299 168 299 minecraft:light[level=12]
setblock 299 168 306 minecraft:light[level=12]
setblock 299 168 313 minecraft:light[level=12]
setblock 301 168 278 minecraft:light[level=15]
setblock 301 168 286 minecraft:light[level=15]
setblock 301 168 294 minecraft:light[level=15]
setblock 301 168 302 minecraft:light[level=15]
setblock 301 168 310 minecraft:light[level=15]
setblock 301 168 317 minecraft:sea_lantern
fill 302 168 317 311 169 317 minecraft:gray_concrete
setblock 305 168 316 minecraft:iron_block
setblock 306 168 278 minecraft:light[level=12]
setblock 306 168 285 minecraft:light[level=12]
setblock 306 168 292 minecraft:light[level=12]
setblock 306 168 299 minecraft:light[level=12]
setblock 306 168 306 minecraft:light[level=12]
setblock 306 168 313 minecraft:light[level=12]
setblock 309 168 276 minecraft:iron_block
setblock 309 168 278 minecraft:light[level=15]
setblock 309 168 286 minecraft:light[level=15]
setblock 309 168 294 minecraft:light[level=15]
setblock 309 168 302 minecraft:light[level=15]
setblock 309 168 310 minecraft:light[level=15]
setblock 313 168 278 minecraft:light[level=12]
setblock 313 168 285 minecraft:light[level=12]
setblock 313 168 292 minecraft:light[level=12]
setblock 313 168 299 minecraft:light[level=12]
setblock 313 168 306 minecraft:light[level=12]
setblock 313 168 313 minecraft:light[level=12]
fill 315 168 312 315 168 314 minecraft:iron_block
setblock 315 168 316 minecraft:iron_block
fill 316 168 312 317 168 312 minecraft:iron_block
fill 316 168 314 317 168 314 minecraft:iron_block
setblock 317 168 286 minecraft:light[level=15]
setblock 317 168 294 minecraft:light[level=15]
setblock 317 168 302 minecraft:light[level=15]
setblock 317 168 310 minecraft:light[level=15]
setblock 317 168 313 minecraft:iron_block
setblock 319 168 276 minecraft:iron_block
setblock 320 168 278 minecraft:light[level=12]
setblock 320 168 285 minecraft:light[level=12]
setblock 320 168 292 minecraft:light[level=12]
setblock 320 168 299 minecraft:light[level=12]
setblock 320 168 306 minecraft:light[level=12]
setblock 320 168 313 minecraft:light[level=12]
setblock 323 168 282 minecraft:iron_block
setblock 323 168 292 minecraft:iron_block
setblock 323 168 302 minecraft:iron_block
setblock 323 168 312 minecraft:iron_block
fill 324 168 276 324 174 276 minecraft:gray_concrete
fill 282 169 298 282 192 298 minecraft:gray_concrete
fill 301 169 317 301 192 317 minecraft:gray_concrete
fill 312 169 317 316 174 317 minecraft:gray_concrete
setblock 317 169 317 minecraft:redstone_block
fill 318 169 317 324 174 317 minecraft:gray_concrete
fill 283 170 275 286 174 275 minecraft:gray_concrete
fill 284 170 312 284 170 313 minecraft:gray_concrete
setblock 285 170 311 minecraft:gray_concrete
setblock 285 170 314 minecraft:gray_concrete
fill 286 170 310 287 170 310 minecraft:gray_concrete
setblock 287 170 275 minecraft:redstone_block
fill 288 170 275 324 170 275 minecraft:gray_concrete
setblock 288 170 311 minecraft:gray_concrete
setblock 288 170 314 minecraft:gray_concrete
fill 302 170 317 306 174 317 minecraft:gray_concrete
setblock 307 170 317 minecraft:redstone_block
fill 308 170 317 311 174 317 minecraft:gray_concrete
fill 316 170 278 316 170 280 minecraft:iron_block
fill 317 170 277 319 170 277 minecraft:iron_block
fill 317 170 281 319 170 281 minecraft:iron_block
fill 317 170 317 317 174 317 minecraft:gray_concrete
fill 320 170 278 320 170 280 minecraft:iron_block
fill 282 171 275 282 174 287 minecraft:gray_concrete
setblock 282 171 288 minecraft:sea_lantern
fill 282 171 289 282 174 297 minecraft:gray_concrete
fill 283 171 280 283 171 283 minecraft:iron_block
fill 283 171 290 283 171 293 minecraft:iron_block
fill 283 171 300 283 171 303 minecraft:iron_block
fill 283 171 310 283 171 313 minecraft:iron_block
fill 284 171 276 287 171 276 minecraft:iron_block
fill 287 171 275 299 174 275 minecraft:gray_concrete
fill 287 171 316 290 171 316 minecraft:iron_block
fill 294 171 276 297 171 276 minecraft:iron_block
fill 297 171 316 300 171 316 minecraft:iron_block
setblock 300 171 275 minecraft:sea_lantern
fill 301 171 275 324 172 275 minecraft:gray_concrete
fill 304 171 276 307 171 276 minecraft:iron_block
fill 307 171 316 310 171 316 minecraft:iron_block
fill 307 171 317 307 174 317 minecraft:gray_concrete
fill 314 171 276 317 171 276 minecraft:iron_block
fill 317 171 316 320 171 316 minecraft:iron_block
fill 323 171 277 323 171 280 minecraft:iron_block
fill 323 171 287 323 171 290 minecraft:iron_block
fill 323 171 297 323 171 300 minecraft:iron_block
fill 323 171 307 323 171 310 minecraft:iron_block
fill 282 172 288 282 185 288 minecraft:gray_concrete
fill 300 172 275 300 192 275 minecraft:gray_concrete
fill 301 173 275 312 174 275 minecraft:gray_concrete
fill 301 173 310 301 174 310 minecraft:gray_concrete
fill 302 173 281 302 174 281 minecraft:gray_concrete
fill 307 173 289 323 173 289 minecraft:iron_block
fill 310 173 279 316 173 279 minecraft:iron_block
fill 310 173 304 323 173 304 minecraft:iron_block
fill 311 173 281 311 174 281 minecraft:gray_concrete
setblock 313 173 275 minecraft:redstone_block
fill 313 173 284 323 173 284 minecraft:iron_block
fill 314 173 275 324 174 275 minecraft:gray_concrete
fill 315 173 310 315 174 310 minecraft:gray_concrete
fill 320 173 279 323 173 279 minecraft:iron_block
fill 283 174 278 283 174 279 minecraft:iron_block
fill 283 174 284 318 174 284 minecraft:iron_block
fill 283 174 288 283 174 289 minecraft:iron_block
fill 283 174 294 288 175 294 minecraft:iron_block
fill 283 174 298 283 174 299 minecraft:iron_block
fill 283 174 304 315 174 304 minecraft:iron_block
fill 283 174 308 283 174 309 minecraft:iron_block
fill 283 174 314 285 175 314 minecraft:iron_block
fill 284 174 279 315 174 279 minecraft:iron_block
fill 284 174 289 312 174 289 minecraft:iron_block
fill 284 174 299 290 175 299 minecraft:iron_block
fill 284 174 309 285 175 309 minecraft:iron_block
setblock 285 174 278 minecraft:light[level=12]
setblock 285 174 285 minecraft:light[level=12]
setblock 285 174 292 minecraft:light[level=12]
setblock 285 174 306 minecraft:light[level=12]
setblock 285 174 316 minecraft:iron_block
fill 288 174 314 323 174 314 minecraft:iron_block
setblock 289 174 276 minecraft:iron_block
setblock 292 174 278 minecraft:light[level=12]
setblock 292 174 285 minecraft:light[level=12]
setblock 292 174 292 minecraft:light[level=12]
setblock 292 174 299 minecraft:light[level=12]
setblock 292 174 306 minecraft:light[level=12]
setblock 292 174 313 minecraft:light[level=12]
setblock 295 174 316 minecraft:iron_block
setblock 299 174 276 minecraft:iron_block
setblock 299 174 278 minecraft:light[level=12]
setblock 299 174 285 minecraft:light[level=12]
setblock 299 174 292 minecraft:light[level=12]
setblock 299 174 299 minecraft:light[level=12]
setblock 299 174 306 minecraft:light[level=12]
setblock 299 174 313 minecraft:light[level=12]
setblock 301 174 311 minecraft:gray_concrete
fill 302 174 280 302 175 280 minecraft:gray_concrete
setblock 305 174 316 minecraft:iron_block
setblock 306 174 278 minecraft:light[level=12]
setblock 306 174 285 minecraft:light[level=12]
setblock 306 174 292 minecraft:light[level=12]
setblock 306 174 299 minecraft:light[level=12]
setblock 306 174 306 minecraft:light[level=12]
setblock 306 174 313 minecraft:light[level=12]
setblock 309 174 276 minecraft:iron_block
fill 311 174 280 311 175 280 minecraft:gray_concrete
fill 313 174 275 313 183 275 minecraft:gray_concrete
setblock 313 174 278 minecraft:light[level=12]
setblock 313 174 285 minecraft:light[level=12]
setblock 313 174 292 minecraft:light[level=12]
setblock 313 174 299 minecraft:light[level=12]
setblock 313 174 306 minecraft:light[level=12]
setblock 313 174 313 minecraft:light[level=12]
fill 315 174 311 315 175 311 minecraft:gray_concrete
setblock 315 174 316 minecraft:iron_block
setblock 319 174 276 minecraft:iron_block
setblock 320 174 278 minecraft:light[level=12]
setblock 320 174 285 minecraft:light[level=12]
setblock 320 174 292 minecraft:light[level=12]
setblock 320 174 299 minecraft:light[level=12]
setblock 320 174 306 minecraft:light[level=12]
setblock 320 174 313 minecraft:light[level=12]
setblock 323 174 282 minecraft:iron_block
setblock 323 174 292 minecraft:iron_block
setblock 323 174 302 minecraft:iron_block
setblock 323 174 312 minecraft:iron_block
fill 282 175 275 282 192 280 minecraft:gray_concrete
fill 282 175 281 282 175 284 minecraft:pearlescent_froglight
fill 282 175 285 282 182 287 minecraft:gray_concrete
fill 282 175 289 282 192 290 minecraft:gray_concrete
fill 282 175 291 282 175 294 minecraft:pearlescent_froglight
fill 282 175 295 282 178 297 minecraft:gray_concrete
fill 282 175 299 282 192 300 minecraft:gray_concrete
fill 282 175 301 282 175 304 minecraft:pearlescent_froglight
fill 282 175 305 282 191 310 minecraft:gray_concrete
fill 282 175 311 282 175 314 minecraft:pearlescent_froglight
fill 282 175 315 282 192 317 minecraft:gray_concrete
fill 283 175 275 284 192 275 minecraft:gray_concrete
fill 283 175 279 285 175 279 minecraft:iron_block
fill 283 175 284 285 175 284 minecraft:iron_block
fill 283 175 289 285 175 289 minecraft:iron_block
setblock 283 175 299 minecraft:iron_block
fill 283 175 304 285 175 304 minecraft:iron_block
setblock 283 175 309 minecraft:iron_block
fill 283 175 317 285 192 317 minecraft:gray_concrete
fill 285 175 275 288 175 275 minecraft:pearlescent_froglight
fill 286 175 309 318 175 309 minecraft:iron_block
fill 286 175 317 289 175 317 minecraft:pearlescent_froglight
fill 288 175 314 292 175 314 minecraft:iron_block
fill 289 175 275 294 183 275 minecraft:gray_concrete
fill 289 175 294 298 175 294 minecraft:iron_block
fill 290 175 317 295 187 317 minecraft:gray_concrete
fill 291 175 299 323 175 299 minecraft:iron_block
fill 295 175 275 298 175 275 minecraft:pearlescent_froglight
fill 296 175 317 299 175 317 minecraft:pearlescent_froglight
fill 299 175 275 299 192 275 minecraft:gray_concrete
fill 300 175 317 300 192 317 minecraft:gray_concrete
fill 301 175 275 304 192 275 minecraft:gray_concrete
fill 301 175 306 301 176 308 minecraft:iron_block
fill 301 175 310 301 175 316 minecraft:iron_block
fill 302 175 279 302 176 279 minecraft:gray_concrete
fill 302 175 317 305 175 317 minecraft:gray_concrete
fill 305 175 275 308 175 275 minecraft:pearlescent_froglight
fill 306 175 294 323 175 294 minecraft:iron_block
fill 306 175 317 309 175 317 minecraft:pearlescent_froglight
fill 309 175 275 312 181 275 minecraft:gray_concrete
fill 310 175 317 315 192 317 minecraft:gray_concrete
setblock 311 175 279 minecraft:gray_concrete
fill 311 175 306 311 176 308 minecraft:iron_block
fill 311 175 310 311 175 316 minecraft:iron_block
fill 314 175 275 314 192 275 minecraft:gray_concrete
fill 315 175 275 318 175 275 minecraft:pearlescent_froglight
fill 315 175 312 315 176 312 minecraft:gray_concrete
fill 315 175 313 315 175 314 minecraft:iron_block
fill 316 175 278 316 177 280 minecraft:iron_block
fill 316 175 312 317 175 312 minecraft:iron_block
fill 316 175 314 317 175 314 minecraft:iron_block
fill 316 175 317 319 175 317 minecraft:pearlescent_froglight
fill 317 175 277 319 175 277 minecraft:iron_block
fill 317 175 281 319 175 281 minecraft:iron_block
setblock 317 175 313 minecraft:iron_block
fill 319 175 275 324 178 275 minecraft:gray_concrete
fill 320 175 278 320 175 280 minecraft:iron_block
fill 320 175 317 324 192 317 minecraft:gray_concrete
fill 324 175 276 324 175 279 minecraft:pearlescent_froglight
fill 324 175 280 324 176 285 minecraft:gray_concrete
fill 324 175 286 324 175 289 minecraft:pearlescent_froglight
fill 324 175 290 324 192 295 minecraft:gray_concrete
fill 324 175 296 324 175 299 minecraft:pearlescent_froglight
fill 324 175 300 324 185 305 minecraft:gray_concrete
fill 324 175 306 324 175 309 minecraft:pearlescent_froglight
fill 324 175 310 324 192 315 minecraft:gray_concrete
setblock 324 175 316 minecraft:pearlescent_froglight
fill 282 176 281 282 183 284 minecraft:gray_concrete
fill 282 176 291 282 183 294 minecraft:gray_concrete
fill 282 176 301 282 183 304 minecraft:gray_concrete
fill 282 176 311 282 183 314 minecraft:gray_concrete
fill 285 176 275 288 183 275 minecraft:gray_concrete
setblock 285 176 278 minecraft:light[level=15]
setblock 285 176 286 minecraft:light[level=15]
setblock 285 176 294 minecraft:light[level=15]
setblock 285 176 302 minecraft:light[level=15]
setblock 285 176 310 minecraft:light[level=15]
fill 286 176 276 286 176 310 minecraft:iron_block
setblock 286 176 315 minecraft:iron_block
fill 286 176 317 289 183 317 minecraft:gray_concrete
fill 291 176 276 291 177 293 minecraft:iron_block
setblock 293 176 278 minecraft:light[level=15]
setblock 293 176 286 minecraft:light[level=15]
setblock 293 176 294 minecraft:light[level=15]
setblock 293 176 302 minecraft:light[level=15]
setblock 293 176 310 minecraft:light[level=15]
fill 295 176 275 298 183 275 minecraft:gray_concrete
fill 296 176 276 296 177 280 minecraft:iron_block
fill 296 176 317 299 183 317 minecraft:gray_concrete
fill 301 176 276 301 176 291 minecraft:iron_block
fill 301 176 299 301 176 305 minecraft:iron_block
fill 301 176 309 301 176 312 minecraft:iron_block
fill 301 176 313 301 177 313 minecraft:gray_concrete
fill 302 176 278 302 177 278 minecraft:gray_concrete
setblock 302 176 317 minecraft:sea_lantern
fill 303 176 317 309 183 317 minecraft:gray_concrete
fill 305 176 275 308 183 275 minecraft:gray_concrete
fill 306 176 276 306 177 279 minecraft:iron_block
setblock 309 176 278 minecraft:light[level=15]
setblock 309 176 286 minecraft:light[level=15]
setblock 309 176 294 minecraft:light[level=15]
setblock 309 176 302 minecraft:light[level=15]
setblock 309 176 310 minecraft:light[level=15]
fill 311 176 276 311 176 305 minecraft:iron_block
fill 311 176 309 311 176 312 minecraft:iron_block
fill 313 176 309 323 176 309 minecraft:iron_block
fill 315 176 275 318 183 275 minecraft:gray_concrete
fill 315 176 313 315 177 313 minecraft:gray_concrete
fill 316 176 276 316 177 277 minecraft:iron_block
fill 316 176 281 316 176 308 minecraft:iron_block
fill 316 176 310 316 176 312 minecraft:iron_block
fill 316 176 314 316 176 316 minecraft:iron_block
fill 316 176 317 319 183 317 minecraft:gray_concrete
setblock 317 176 286 minecraft:light[level=15]
setblock 317 176 294 minecraft:light[level=15]
setblock 317 176 302 minecraft:light[level=15]
setblock 317 176 310 minecraft:light[level=15]
fill 321 176 276 321 177 287 minecraft:iron_block
fill 324 176 276 324 183 279 minecraft:gray_concrete
fill 324 176 286 324 183 289 minecraft:gray_concrete
fill 324 176 296 324 183 299 minecraft:gray_concrete
fill 324 176 306 324 183 308 minecraft:gray_concrete
setblock 324 176 309 minecraft:sea_lantern
fill 324 176 316 324 183 316 minecraft:gray_concrete
fill 286 177 276 286 177 305 minecraft:iron_block
fill 291 177 294 291 177 316 minecraft:iron_block
fill 296 177 281 296 177 315 minecraft:iron_block
fill 301 177 276 301 177 278 minecraft:iron_block
fill 301 177 314 301 178 314 minecraft:gray_concrete
fill 302 177 277 302 178 277 minecraft:gray_concrete
fill 302 177 317 302 180 317 minecraft:gray_concrete
fill 306 177 280 306 177 315 minecraft:iron_block
fill 311 177 276 311 177 278 minecraft:iron_block
fill 315 177 314 315 178 314 minecraft:gray_concrete
fill 316 177 281 316 177 282 minecraft:iron_block
fill 321 177 288 321 177 316 minecraft:iron_block
setblock 324 177 280 minecraft:redstone_block
fill 324 177 281 324 192 285 minecraft:gray_concrete
fill 324 177 309 324 183 309 minecraft:gray_concrete
fill 284 178 312 284 178 313 minecraft:gray_concrete
setblock 285 178 311 minecraft:gray_concrete
setblock 285 178 314 minecraft:gray_concrete
fill 286 178 310 287 178 310 minecraft:gray_concrete
setblock 288 178 311 minecraft:gray_concrete
setblock 288 178 314 minecraft:gray_concrete
fill 301 178 315 301 179 315 minecraft:gray_concrete
fill 302 178 276 302 179 276 minecraft:gray_concrete
fill 306 178 314 306 178 315 minecraft:iron_block
fill 311 178 276 311 178 277 minecraft:gray_concrete
fill 315 178 315 315 179 315 minecraft:gray_concrete
fill 324 178 280 324 192 280 minecraft:gray_concrete
fill 282 179 295 282 180 296 minecraft:gray_concrete
setblock 282 179 297 minecraft:redstone_block
setblock 288 179 281 minecraft:pearlescent_froglight
setblock 288 179 287 minecraft:pearlescent_froglight
setblock 288 179 293 minecraft:pearlescent_froglight
setblock 288 179 299 minecraft:pearlescent_froglight
setblock 288 179 305 minecraft:pearlescent_froglight
setblock 288 179 311 minecraft:pearlescent_froglight
setblock 294 179 281 minecraft:pearlescent_froglight
setblock 294 179 311 minecraft:pearlescent_froglight
setblock 300 179 281 minecraft:pearlescent_froglight
setblock 300 179 311 minecraft:pearlescent_froglight
setblock 306 179 281 minecraft:pearlescent_froglight
setblock 306 179 311 minecraft:pearlescent_froglight
setblock 311 179 276 minecraft:gray_concrete
setblock 312 179 281 minecraft:pearlescent_froglight
setblock 312 179 311 minecraft:pearlescent_froglight
setblock 318 179 281 minecraft:pearlescent_froglight
setblock 318 179 287 minecraft:pearlescent_froglight
setblock 318 179 293 minecraft:pearlescent_froglight
setblock 318 179 299 minecraft:pearlescent_froglight
setblock 318 179 305 minecraft:pearlescent_froglight
setblock 318 179 311 minecraft:pearlescent_froglight
fill 319 179 275 322 184 275 minecraft:gray_concrete
setblock 323 179 275 minecraft:redstone_block
fill 324 179 275 324 192 275 minecraft:gray_concrete
fill 282 180 297 282 192 297 minecraft:gray_concrete
fill 283 180 276 289 180 276 minecraft:iron_block
fill 283 180 278 283 180 285 minecraft:iron_block
setblock 283 180 288 minecraft:iron_block
fill 283 180 290 283 180 294 minecraft:iron_block
fill 283 180 296 284 180 296 minecraft:iron_block
fill 283 180 298 283 180 303 minecraft:iron_block
fill 283 180 305 283 180 306 minecraft:iron_block
fill 283 180 308 283 180 315 minecraft:iron_block
fill 284 180 277 284 180 278 minecraft:iron_block
fill 284 180 280 284 180 281 minecraft:iron_block
fill 284 180 283 284 180 284 minecraft:iron_block
fill 284 180 286 284 180 287 minecraft:iron_block
fill 284 180 289 284 180 290 minecraft:iron_block
fill 284 180 292 284 180 293 minecraft:iron_block
fill 284 180 295 285 180 295 minecraft:iron_block
fill 284 180 298 284 180 299 minecraft:iron_block
fill 284 180 301 284 180 302 minecraft:iron_block
fill 284 180 304 284 180 305 minecraft:iron_block
fill 284 180 307 284 180 308 minecraft:iron_block
fill 284 180 310 284 180 311 minecraft:iron_block
fill 284 180 313 284 180 314 minecraft:iron_block
setblock 285 180 277 minecraft:iron_block
setblock 285 180 278 minecraft:light[level=12]
fill 285 180 279 285 180 280 minecraft:iron_block
fill 285 180 282 285 180 283 minecraft:iron_block
fill 285 180 285 285 180 286 minecraft:iron_block
fill 285 180 288 285 180 289 minecraft:iron_block
fill 285 180 291 285 180 292 minecraft:iron_block
fill 285 180 294 286 180 294 minecraft:iron_block
fill 285 180 297 285 180 298 minecraft:iron_block
setblock 285 180 299 minecraft:light[level=12]
fill 285 180 300 285 180 301 minecraft:iron_block
fill 285 180 303 285 180 304 minecraft:iron_block
fill 285 180 306 285 180 307 minecraft:iron_block
fill 285 180 309 285 180 310 minecraft:iron_block
fill 285 180 315 285 180 316 minecraft:iron_block
fill 286 180 278 286 180 279 minecraft:iron_block
fill 286 180 281 286 180 282 minecraft:iron_block
fill 286 180 284 286 180 285 minecraft:iron_block
fill 286 180 287 286 180 288 minecraft:iron_block
fill 286 180 290 286 180 291 minecraft:iron_block
fill 286 180 293 287 180 293 minecraft:iron_block
fill 286 180 296 286 180 297 minecraft:iron_block
fill 286 180 299 286 180 300 minecraft:iron_block
fill 286 180 302 286 180 303 minecraft:iron_block
fill 286 180 305 286 180 306 minecraft:iron_block
fill 286 180 308 286 180 309 minecraft:iron_block
setblock 286 180 315 minecraft:iron_block
fill 287 180 277 287 180 278 minecraft:iron_block
fill 287 180 280 287 180 281 minecraft:iron_block
fill 287 180 283 287 180 284 minecraft:iron_block
fill 287 180 286 287 180 287 minecraft:iron_block
fill 287 180 289 287 180 290 minecraft:iron_block
fill 287 180 292 288 180 292 minecraft:iron_block
fill 287 180 295 287 180 296 minecraft:iron_block
fill 287 180 298 287 180 299 minecraft:iron_block
fill 287 180 301 287 180 302 minecraft:iron_block
fill 287 180 304 287 180 305 minecraft:iron_block
fill 287 180 307 287 180 308 minecraft:iron_block
fill 287 180 310 288 180 310 minecraft:iron_block
fill 287 180 316 291 180 316 minecraft:iron_block
setblock 288 180 277 minecraft:iron_block
fill 288 180 279 288 180 280 minecraft:iron_block
fill 288 180 282 288 180 283 minecraft:iron_block
fill 288 180 285 288 180 286 minecraft:iron_block
fill 288 180 288 288 180 289 minecraft:iron_block
setblock 288 180 291 minecraft:iron_block
fill 288 180 294 288 180 295 minecraft:iron_block
fill 288 180 297 288 180 298 minecraft:iron_block
fill 288 180 300 288 180 301 minecraft:iron_block
fill 288 180 303 288 180 304 minecraft:iron_block
fill 288 180 306 288 180 307 minecraft:iron_block
setblock 288 180 309 minecraft:iron_block
fill 288 180 315 289 180 315 minecraft:iron_block
fill 289 180 278 289 180 279 minecraft:iron_block
fill 289 180 281 290 180 281 minecraft:iron_block
fill 289 180 311 289 180 312 minecraft:iron_block
fill 289 180 314 290 180 314 minecraft:iron_block
fill 290 180 277 290 180 278 minecraft:iron_block
fill 290 180 280 291 180 280 minecraft:iron_block
setblock 290 180 311 minecraft:iron_block
fill 290 180 313 291 180 313 minecraft:iron_block
fill 291 180 276 291 180 277 minecraft:iron_block
fill 291 180 279 292 180 279 minecraft:iron_block
fill 291 180 312 292 180 312 minecraft:iron_block
fill 291 180 315 292 180 315 minecraft:iron_block
setblock 292 180 276 minecraft:iron_block
fill 292 180 278 293 180 278 minecraft:iron_block
fill 292 180 281 293 180 281 minecraft:iron_block
setblock 292 180 285 minecraft:light[level=12]
setblock 292 180 292 minecraft:light[level=12]
setblock 292 180 299 minecraft:light[level=12]
setblock 292 180 306 minecraft:light[level=12]
fill 292 180 311 293 180 311 minecraft:iron_block
setblock 292 180 313 minecraft:light[level=12]
fill 292 180 314 293 180 314 minecraft:iron_block
fill 293 180 277 294 180 277 minecraft:iron_block
fill 293 180 280 294 180 280 minecraft:iron_block
fill 293 180 313 294 180 313 minecraft:iron_block
setblock 293 180 316 minecraft:iron_block
fill 294 180 276 299 180 276 minecraft:iron_block
fill 294 180 279 295 180 279 minecraft:iron_block
fill 294 180 312 295 180 312 minecraft:iron_block
fill 294 180 315 295 180 315 minecraft:iron_block
fill 295 180 278 296 180 278 minecraft:iron_block
fill 295 180 281 296 180 281 minecraft:iron_block
fill 295 180 311 296 180 311 minecraft:iron_block
fill 295 180 314 296 180 314 minecraft:iron_block
fill 295 180 316 300 180 316 minecraft:iron_block
fill 296 180 277 297 180 277 minecraft:iron_block
fill 296 180 280 297 180 280 minecraft:iron_block
fill 296 180 313 297 180 313 minecraft:iron_block
fill 297 180 279 298 180 279 minecraft:iron_block
fill 297 180 312 298 180 312 minecraft:iron_block
fill 297 180 315 298 180 315 minecraft:iron_block
fill 298 180 278 299 180 278 minecraft:iron_block
fill 298 180 281 299 180 281 minecraft:iron_block
fill 298 180 311 299 180 311 minecraft:iron_block
fill 298 180 314 299 180 314 minecraft:iron_block
fill 299 180 277 300 180 277 minecraft:iron_block
fill 299 180 280 300 180 280 minecraft:iron_block
setblock 299 180 285 minecraft:light[level=12]
setblock 299 180 292 minecraft:light[level=12]
setblock 299 180 299 minecraft:light[level=12]
setblock 299 180 306 minecraft:light[level=12]
fill 299 180 313 300 180 313 minecraft:iron_block
fill 300 180 279 301 180 279 minecraft:iron_block
fill 300 180 312 301 180 312 minecraft:iron_block
fill 300 180 315 301 180 315 minecraft:iron_block
setblock 301 180 276 minecraft:iron_block
fill 301 180 278 302 180 278 minecraft:iron_block
fill 301 180 281 302 180 281 minecraft:iron_block
fill 301 180 311 302 180 311 minecraft:iron_block
fill 301 180 314 302 180 314 minecraft:iron_block
fill 302 180 277 303 180 277 minecraft:iron_block
fill 302 180 280 303 180 280 minecraft:iron_block
fill 302 180 313 303 180 313 minecraft:iron_block
fill 302 180 316 303 180 316 minecraft:iron_block
fill 303 180 276 307 180 276 minecraft:iron_block
fill 303 180 279 304 180 279 minecraft:iron_block
fill 303 180 312 304 180 312 minecraft:iron_block
fill 303 180 315 304 180 315 minecraft:iron_block
fill 304 180 278 305 180 278 minecraft:iron_block
fill 304 180 281 305 180 281 minecraft:iron_block
fill 304 180 311 305 180 311 minecraft:iron_block
fill 304 180 314 305 180 314 minecraft:iron_block
fill 305 180 277 306 180 277 minecraft:iron_block
fill 305 180 280 306 180 280 minecraft:iron_block
fill 305 180 313 306 180 313 minecraft:iron_block
fill 305 180 316 312 180 316 minecraft:iron_block
setblock 306 180 278 minecraft:light[level=12]
fill 306 180 279 307 180 279 minecraft:iron_block
setblock 306 180 285 minecraft:light[level=12]
setblock 306 180 292 minecraft:light[level=12]
setblock 306 180 299 minecraft:light[level=12]
setblock 306 180 306 minecraft:light[level=12]
fill 306 180 312 307 180 312 minecraft:iron_block
fill 306 180 315 307 180 315 minecraft:iron_block
fill 307 180 278 308 180 278 minecraft:iron_block
fill 307 180 281 308 180 281 minecraft:iron_block
fill 307 180 311 308 180 311 minecraft:iron_block
fill 307 180 314 308 180 314 minecraft:iron_block
fill 308 180 277 309 180 277 minecraft:iron_block
fill 308 180 280 309 180 280 minecraft:iron_block
fill 308 180 313 309 180 313 minecraft:iron_block
setblock 309 180 276 minecraft:iron_block
fill 309 180 279 310 180 279 minecraft:iron_block
fill 309 180 312 310 180 312 minecraft:iron_block
fill 309 180 315 310 180 315 minecraft:iron_block
fill 310 180 278 311 180 278 minecraft:iron_block
fill 310 180 281 311 180 281 minecraft:iron_block
fill 310 180 311 311 180 311 minecraft:iron_block
fill 310 180 314 311 180 314 minecraft:iron_block
fill 311 180 277 312 180 277 minecraft:iron_block
fill 311 180 280 312 180 280 minecraft:iron_block
fill 311 180 313 312 180 313 minecraft:iron_block
fill 312 180 276 319 180 276 minecraft:iron_block
fill 312 180 279 313 180 279 minecraft:iron_block
fill 312 180 312 313 182 312 minecraft:iron_block
fill 312 180 315 313 180 315 minecraft:iron_block
fill 313 180 278 314 180 278 minecraft:iron_block
fill 313 180 281 314 180 281 minecraft:iron_block
setblock 313 180 285 minecraft:light[level=12]
setblock 313 180 292 minecraft:light[level=12]
setblock 313 180 299 minecraft:light[level=12]
setblock 313 180 306 minecraft:light[level=12]
fill 313 180 311 314 180 311 minecraft:iron_block
setblock 313 180 313 minecraft:light[level=12]
fill 313 180 314 314 180 314 minecraft:iron_block
fill 314 180 277 315 180 277 minecraft:iron_block
fill 314 180 280 316 180 280 minecraft:iron_block
fill 314 180 313 315 180 313 minecraft:iron_block
fill 315 180 279 316 180 279 minecraft:iron_block
fill 315 180 312 316 180 312 minecraft:iron_block
fill 315 180 315 315 180 316 minecraft:iron_block
setblock 316 180 278 minecraft:iron_block
fill 316 180 281 320 180 281 minecraft:iron_block
fill 316 180 311 317 180 311 minecraft:iron_block
fill 316 180 314 316 180 315 minecraft:iron_block
fill 317 180 277 321 180 277 minecraft:iron_block
fill 317 180 313 317 180 314 minecraft:iron_block
fill 317 180 316 321 180 316 minecraft:iron_block
fill 318 180 282 318 180 283 minecraft:iron_block
fill 318 180 285 318 180 286 minecraft:iron_block
fill 318 180 288 318 180 289 minecraft:iron_block
fill 318 180 291 318 180 292 minecraft:iron_block
fill 318 180 294 318 180 295 minecraft:iron_block
fill 318 180 297 318 180 298 minecraft:iron_block
fill 318 180 300 318 180 301 minecraft:iron_block
fill 318 180 303 318 180 304 minecraft:iron_block
fill 318 180 306 318 180 307 minecraft:iron_block
fill 318 180 309 318 180 310 minecraft:iron_block
fill 318 180 312 318 180 313 minecraft:iron_block
fill 318 180 315 319 180 315 minecraft:iron_block
setblock 319 180 282 minecraft:iron_block
fill 319 180 284 319 180 285 minecraft:iron_block
fill 319 180 287 319 180 288 minecraft:iron_block
fill 319 180 290 319 180 291 minecraft:iron_block
fill 319 180 293 319 180 294 minecraft:iron_block
fill 319 180 296 319 180 297 minecraft:iron_block
fill 319 180 299 319 180 300 minecraft:iron_block
fill 319 180 302 319 180 303 minecraft:iron_block
fill 319 180 305 319 180 306 minecraft:iron_block
fill 319 180 308 319 180 309 minecraft:iron_block
fill 319 180 311 319 180 312 minecraft:iron_block
fill 319 180 314 320 180 314 minecraft:iron_block
fill 320 180 278 320 180 280 minecraft:iron_block
fill 320 180 283 320 180 284 minecraft:iron_block
setblock 320 180 285 minecraft:light[level=12]
fill 320 180 286 320 180 287 minecraft:iron_block
fill 320 180 289 320 180 290 minecraft:iron_block
fill 320 180 292 320 180 293 minecraft:iron_block
fill 320 180 295 320 180 296 minecraft:iron_block
fill 320 180 298 320 180 299 minecraft:iron_block
fill 320 180 301 320 180 302 minecraft:iron_block
fill 320 180 304 320 180 305 minecraft:iron_block
setblock 320 180 306 minecraft:light[level=12]
fill 320 180 307 320 180 308 minecraft:iron_block
fill 320 180 310 320 180 311 minecraft:iron_block
fill 320 180 313 321 180 313 minecraft:iron_block
fill 321 180 276 322 180 276 minecraft:iron_block
fill 321 180 279 321 180 280 minecraft:iron_block
fill 321 180 282 321 180 283 minecraft:iron_block
fill 321 180 285 321 180 286 minecraft:iron_block
fill 321 180 288 321 180 289 minecraft:iron_block
fill 321 180 291 321 180 292 minecraft:iron_block
fill 321 180 294 321 180 295 minecraft:iron_block
fill 321 180 297 321 180 298 minecraft:iron_block
fill 321 180 300 321 180 301 minecraft:iron_block
fill 321 180 303 321 180 304 minecraft:iron_block
fill 321 180 306 321 180 307 minecraft:iron_block
fill 321 180 309 321 180 310 minecraft:iron_block
fill 321 180 312 323 180 312 minecraft:iron_block
fill 321 180 315 322 180 315 minecraft:iron_block
fill 322 180 278 323 180 279 minecraft:iron_block
fill 322 180 281 323 180 282 minecraft:iron_block
fill 322 180 284 322 180 285 minecraft:iron_block
fill 322 180 287 323 180 288 minecraft:iron_block
fill 322 180 290 322 180 291 minecraft:iron_block
fill 322 180 293 322 180 294 minecraft:iron_block
fill 322 180 296 323 180 297 minecraft:iron_block
fill 322 180 299 323 180 300 minecraft:iron_block
fill 322 180 302 322 180 303 minecraft:iron_block
fill 322 180 305 322 180 306 minecraft:iron_block
fill 322 180 308 323 180 309 minecraft:iron_block
fill 322 180 311 323 180 311 minecraft:iron_block
fill 322 180 314 323 180 314 minecraft:iron_block
fill 323 180 275 323 192 275 minecraft:gray_concrete
setblock 323 180 277 minecraft:iron_block
setblock 323 180 280 minecraft:iron_block
setblock 323 180 284 minecraft:iron_block
setblock 323 180 286 minecraft:iron_block
fill 323 180 289 323 180 290 minecraft:iron_block
setblock 323 180 292 minecraft:iron_block
setblock 323 180 295 minecraft:iron_block
setblock 323 180 298 minecraft:iron_block
fill 323 180 301 323 180 302 minecraft:iron_block
fill 323 180 304 323 180 305 minecraft:iron_block
setblock 323 180 307 minecraft:iron_block
setblock 323 180 310 minecraft:iron_block
setblock 323 180 316 minecraft:iron_block
setblock 282 181 295 minecraft:sea_lantern
fill 282 181 296 282 192 296 minecraft:gray_concrete
fill 288 181 281 288 181 311 minecraft:light_gray_concrete
fill 289 181 281 318 181 281 minecraft:light_gray_concrete
fill 289 181 311 311 181 311 minecraft:light_gray_concrete
setblock 302 181 317 minecraft:sea_lantern
fill 310 181 296 310 182 296 minecraft:iron_block
fill 311 181 300 311 182 306 minecraft:iron_block
fill 312 181 305 312 182 311 minecraft:iron_block
fill 312 181 313 313 182 314 minecraft:iron_block
fill 313 181 311 313 182 311 minecraft:iron_block
schedule function dropper:buildpart/66_3 1t
