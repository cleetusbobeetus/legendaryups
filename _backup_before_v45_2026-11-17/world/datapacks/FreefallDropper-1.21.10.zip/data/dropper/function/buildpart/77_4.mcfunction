fill 269 154 328 270 155 329 minecraft:moss_block
fill 269 154 330 269 155 330 minecraft:green_wool
fill 269 154 333 272 155 333 minecraft:moss_block
fill 269 154 335 269 155 335 minecraft:green_wool
fill 269 154 338 270 155 339 minecraft:moss_block
fill 269 154 340 269 155 340 minecraft:green_wool
fill 269 154 343 270 155 344 minecraft:moss_block
fill 269 154 345 269 155 345 minecraft:green_wool
fill 269 154 348 272 155 348 minecraft:moss_block
fill 269 154 350 269 155 350 minecraft:green_wool
fill 269 154 353 272 155 353 minecraft:moss_block
fill 269 154 355 269 155 355 minecraft:green_wool
fill 269 154 358 272 155 358 minecraft:moss_block
fill 269 154 360 269 155 360 minecraft:green_wool
fill 269 154 363 272 155 363 minecraft:moss_block
fill 270 154 325 271 155 326 minecraft:moss_block
fill 270 154 327 270 155 327 minecraft:green_wool
fill 270 154 330 271 155 331 minecraft:moss_block
fill 270 154 332 270 155 332 minecraft:green_wool
fill 270 154 335 273 155 335 minecraft:moss_block
fill 270 154 337 270 155 337 minecraft:green_wool
fill 270 154 340 271 155 341 minecraft:moss_block
fill 270 154 342 270 155 342 minecraft:green_wool
fill 270 154 345 271 155 346 minecraft:moss_block
fill 270 154 347 270 155 347 minecraft:green_wool
fill 270 154 350 273 155 350 minecraft:moss_block
fill 270 154 352 270 155 352 minecraft:green_wool
fill 270 154 355 273 155 355 minecraft:moss_block
fill 270 154 357 270 155 357 minecraft:green_wool
fill 270 154 360 273 155 360 minecraft:moss_block
fill 270 154 362 270 155 362 minecraft:green_wool
fill 271 154 323 272 155 323 minecraft:moss_block
fill 271 154 324 271 155 324 minecraft:green_wool
fill 271 154 327 272 155 328 minecraft:moss_block
fill 271 154 329 271 155 329 minecraft:green_wool
fill 271 154 332 274 155 332 minecraft:moss_block
fill 271 154 334 271 155 334 minecraft:green_wool
fill 271 154 337 272 155 338 minecraft:moss_block
fill 271 154 339 271 155 339 minecraft:green_wool
fill 271 154 342 272 155 343 minecraft:moss_block
fill 271 154 344 271 155 344 minecraft:green_wool
fill 271 154 347 274 155 347 minecraft:moss_block
fill 271 154 349 271 155 349 minecraft:green_wool
fill 271 154 352 274 155 352 minecraft:moss_block
fill 271 154 354 271 155 354 minecraft:green_wool
fill 271 154 357 274 155 357 minecraft:moss_block
fill 271 154 359 271 155 359 minecraft:green_wool
fill 271 154 362 274 155 362 minecraft:moss_block
fill 272 154 324 273 155 325 minecraft:moss_block
fill 272 154 326 272 155 326 minecraft:green_wool
fill 272 154 329 273 155 330 minecraft:moss_block
fill 272 154 331 272 155 331 minecraft:green_wool
fill 272 154 334 275 155 334 minecraft:moss_block
fill 272 154 336 272 155 336 minecraft:green_wool
fill 272 154 339 273 155 340 minecraft:moss_block
fill 272 154 341 272 155 341 minecraft:green_wool
fill 272 154 344 273 155 345 minecraft:moss_block
fill 272 154 346 272 155 346 minecraft:green_wool
fill 272 154 349 275 155 349 minecraft:moss_block
fill 272 154 351 272 155 351 minecraft:green_wool
fill 272 154 354 275 155 354 minecraft:moss_block
fill 272 154 356 272 155 356 minecraft:green_wool
fill 272 154 359 275 155 359 minecraft:moss_block
fill 272 154 361 272 155 361 minecraft:green_wool
fill 273 154 323 273 155 323 minecraft:green_wool
fill 273 154 326 274 155 327 minecraft:moss_block
fill 273 154 328 273 155 328 minecraft:green_wool
fill 273 154 331 276 155 331 minecraft:moss_block
fill 273 154 333 273 155 333 minecraft:green_wool
fill 273 154 336 274 155 337 minecraft:moss_block
fill 273 154 338 273 155 338 minecraft:green_wool
fill 273 154 341 274 155 342 minecraft:moss_block
fill 273 154 343 273 155 343 minecraft:green_wool
fill 273 154 346 276 155 346 minecraft:moss_block
fill 273 154 348 273 155 348 minecraft:green_wool
fill 273 154 351 276 155 351 minecraft:moss_block
fill 273 154 353 273 155 353 minecraft:green_wool
fill 273 154 356 276 155 356 minecraft:moss_block
fill 273 154 358 273 155 358 minecraft:green_wool
fill 273 154 361 276 155 361 minecraft:moss_block
fill 273 154 363 273 155 363 minecraft:green_wool
fill 274 154 323 275 155 324 minecraft:moss_block
fill 274 154 325 274 155 325 minecraft:green_wool
fill 274 154 328 275 155 329 minecraft:moss_block
fill 274 154 330 274 155 330 minecraft:green_wool
fill 274 154 333 276 155 333 minecraft:moss_block
fill 274 154 335 274 155 335 minecraft:green_wool
fill 274 154 338 275 155 339 minecraft:moss_block
fill 274 154 340 274 155 340 minecraft:green_wool
fill 274 154 343 275 155 344 minecraft:moss_block
fill 274 154 345 274 155 345 minecraft:green_wool
fill 274 154 348 276 155 348 minecraft:moss_block
fill 274 154 350 274 155 350 minecraft:green_wool
fill 274 154 353 276 155 353 minecraft:moss_block
fill 274 154 355 274 155 355 minecraft:green_wool
fill 274 154 358 276 155 358 minecraft:moss_block
fill 274 154 360 274 155 360 minecraft:green_wool
fill 274 154 363 276 155 363 minecraft:moss_block
fill 275 154 325 276 155 326 minecraft:moss_block
fill 275 154 327 275 155 327 minecraft:green_wool
fill 275 154 330 276 155 330 minecraft:moss_block
fill 275 154 332 275 155 332 minecraft:green_wool
fill 275 154 335 276 155 336 minecraft:moss_block
fill 275 154 337 275 155 337 minecraft:green_wool
fill 275 154 340 276 155 341 minecraft:moss_block
fill 275 154 342 275 155 342 minecraft:green_wool
fill 275 154 345 276 155 345 minecraft:moss_block
fill 275 154 347 275 155 347 minecraft:green_wool
fill 275 154 350 276 155 350 minecraft:moss_block
fill 275 154 352 275 155 352 minecraft:green_wool
fill 275 154 355 276 155 355 minecraft:moss_block
fill 275 154 357 275 155 357 minecraft:green_wool
fill 275 154 360 276 155 360 minecraft:moss_block
fill 275 154 362 275 155 362 minecraft:green_wool
fill 276 154 323 276 155 323 minecraft:moss_block
fill 276 154 324 276 155 324 minecraft:green_wool
fill 276 154 327 276 155 328 minecraft:moss_block
fill 276 154 329 276 155 329 minecraft:green_wool
fill 276 154 332 276 155 332 minecraft:moss_block
fill 276 154 334 276 155 334 minecraft:green_wool
fill 276 154 337 276 155 338 minecraft:moss_block
fill 276 154 339 276 155 339 minecraft:green_wool
fill 276 154 342 276 155 343 minecraft:moss_block
fill 276 154 344 276 155 344 minecraft:green_wool
fill 276 154 347 276 155 347 minecraft:moss_block
fill 276 154 349 276 155 349 minecraft:green_wool
fill 276 154 352 276 155 352 minecraft:moss_block
fill 276 154 354 276 155 354 minecraft:green_wool
fill 276 154 357 276 155 357 minecraft:moss_block
fill 276 154 359 276 155 359 minecraft:green_wool
fill 276 154 362 276 155 362 minecraft:moss_block
setblock 240 155 364 minecraft:shroomlight
fill 245 155 343 245 155 344 minecraft:moss_block
fill 245 155 345 245 155 349 minecraft:pearlescent_froglight
fill 245 155 350 245 155 351 minecraft:moss_block
fill 246 155 344 246 155 345 minecraft:pearlescent_froglight
fill 246 155 349 246 155 350 minecraft:pearlescent_froglight
fill 246 155 351 246 155 353 minecraft:moss_block
fill 247 155 344 250 155 344 minecraft:pearlescent_froglight
fill 247 155 350 250 155 350 minecraft:pearlescent_froglight
fill 250 155 345 251 155 345 minecraft:pearlescent_froglight
fill 250 155 349 251 155 349 minecraft:pearlescent_froglight
setblock 250 155 351 minecraft:moss_block
fill 251 155 346 251 155 348 minecraft:pearlescent_froglight
fill 252 155 345 253 155 345 minecraft:moss_block
setblock 252 155 364 minecraft:shroomlight
fill 277 155 354 277 189 354 minecraft:green_terracotta
setblock 277 155 355 minecraft:red_mushroom_block
fill 277 155 356 277 160 358 minecraft:green_terracotta
setblock 235 156 362 minecraft:red_mushroom_block
fill 238 156 364 238 169 364 minecraft:green_terracotta
setblock 239 156 364 minecraft:red_mushroom_block
fill 240 156 364 240 213 364 minecraft:green_terracotta
setblock 241 156 347 minecraft:mushroom_stem
setblock 242 156 343 minecraft:mushroom_stem
setblock 242 156 351 minecraft:mushroom_stem
setblock 246 156 340 minecraft:mushroom_stem
setblock 246 156 354 minecraft:mushroom_stem
fill 249 156 326 253 156 328 minecraft:red_mushroom_block
fill 250 156 325 252 156 325 minecraft:red_mushroom_block
fill 250 156 329 252 156 329 minecraft:red_mushroom_block
setblock 250 156 340 minecraft:mushroom_stem
setblock 250 156 354 minecraft:mushroom_stem
fill 252 156 364 252 228 364 minecraft:green_terracotta
setblock 253 156 364 minecraft:shroomlight
setblock 254 156 343 minecraft:mushroom_stem
setblock 254 156 351 minecraft:mushroom_stem
fill 254 156 364 255 197 364 minecraft:green_terracotta
setblock 255 156 347 minecraft:mushroom_stem
fill 277 156 355 277 224 355 minecraft:green_terracotta
fill 235 157 337 235 171 341 minecraft:green_terracotta
setblock 235 157 342 minecraft:shroomlight
fill 235 157 343 235 228 343 minecraft:green_terracotta
fill 235 157 362 235 209 362 minecraft:green_terracotta
setblock 238 157 325 minecraft:light[level=15]
setblock 238 157 333 minecraft:light[level=15]
setblock 238 157 341 minecraft:light[level=15]
setblock 238 157 349 minecraft:light[level=15]
setblock 238 157 357 minecraft:light[level=15]
fill 239 157 364 239 224 364 minecraft:green_terracotta
fill 241 157 347 241 158 347 minecraft:red_mushroom_block
fill 242 157 343 243 158 343 minecraft:red_mushroom_block
fill 242 157 351 243 158 351 minecraft:red_mushroom_block
fill 244 157 364 244 188 364 minecraft:green_terracotta
fill 245 157 340 246 158 340 minecraft:red_mushroom_block
fill 245 157 354 246 158 354 minecraft:red_mushroom_block
setblock 245 157 364 minecraft:red_mushroom_block
setblock 246 157 325 minecraft:light[level=15]
setblock 246 157 333 minecraft:light[level=15]
fill 246 157 341 246 158 341 minecraft:red_mushroom_block
setblock 246 157 349 minecraft:light[level=15]
fill 246 157 353 246 158 353 minecraft:red_mushroom_block
setblock 246 157 357 minecraft:light[level=15]
fill 246 157 364 248 219 364 minecraft:green_terracotta
fill 250 157 340 250 158 341 minecraft:red_mushroom_block
fill 250 157 353 250 158 354 minecraft:red_mushroom_block
fill 251 157 340 251 158 340 minecraft:red_mushroom_block
fill 251 157 354 251 158 354 minecraft:red_mushroom_block
fill 253 157 343 254 158 343 minecraft:red_mushroom_block
fill 253 157 351 254 158 351 minecraft:red_mushroom_block
fill 253 157 364 253 228 364 minecraft:green_terracotta
setblock 254 157 325 minecraft:light[level=15]
setblock 254 157 333 minecraft:light[level=15]
setblock 254 157 341 minecraft:light[level=15]
setblock 254 157 349 minecraft:light[level=15]
setblock 254 157 357 minecraft:light[level=15]
fill 255 157 347 255 158 347 minecraft:red_mushroom_block
setblock 262 157 325 minecraft:light[level=15]
setblock 262 157 333 minecraft:light[level=15]
setblock 262 157 341 minecraft:light[level=15]
setblock 262 157 349 minecraft:light[level=15]
setblock 262 157 357 minecraft:light[level=15]
setblock 270 157 325 minecraft:light[level=15]
setblock 270 157 333 minecraft:light[level=15]
setblock 270 157 341 minecraft:light[level=15]
setblock 270 157 349 minecraft:light[level=15]
setblock 270 157 357 minecraft:light[level=15]
setblock 277 157 326 minecraft:red_mushroom_block
fill 235 158 342 235 181 342 minecraft:green_terracotta
fill 245 158 364 245 228 364 minecraft:green_terracotta
fill 277 158 326 277 228 326 minecraft:green_terracotta
fill 235 159 330 235 183 330 minecraft:green_terracotta
setblock 235 159 331 minecraft:red_mushroom_block
fill 235 159 332 235 204 335 minecraft:green_terracotta
setblock 235 159 336 minecraft:shroomlight
fill 236 159 327 236 159 330 minecraft:moss_block
setblock 236 159 331 minecraft:mushroom_stem
fill 236 159 332 236 159 335 minecraft:moss_block
setblock 236 159 336 minecraft:mushroom_stem
fill 236 159 337 236 159 340 minecraft:moss_block
setblock 236 159 341 minecraft:mushroom_stem
fill 236 159 342 236 159 345 minecraft:moss_block
setblock 236 159 346 minecraft:mushroom_stem
fill 236 159 347 236 159 350 minecraft:moss_block
setblock 236 159 351 minecraft:mushroom_stem
fill 236 159 352 236 159 355 minecraft:moss_block
setblock 236 159 356 minecraft:mushroom_stem
fill 236 159 357 236 159 360 minecraft:moss_block
setblock 236 159 361 minecraft:red_mushroom_block
setblock 237 159 329 minecraft:moss_block
setblock 237 159 330 minecraft:mushroom_stem
fill 237 159 331 237 159 334 minecraft:moss_block
setblock 237 159 335 minecraft:mushroom_stem
fill 237 159 336 237 159 339 minecraft:moss_block
setblock 237 159 340 minecraft:mushroom_stem
fill 237 159 341 237 161 342 minecraft:moss_block
fill 237 159 353 237 159 354 minecraft:moss_block
setblock 237 159 355 minecraft:mushroom_stem
fill 237 159 356 237 160 357 minecraft:moss_block
setblock 238 159 325 minecraft:light[level=12]
fill 238 159 330 238 159 333 minecraft:moss_block
setblock 238 159 334 minecraft:mushroom_stem
fill 238 159 335 238 159 338 minecraft:moss_block
setblock 238 159 339 minecraft:mushroom_stem
fill 238 159 340 238 162 340 minecraft:moss_block
setblock 238 159 346 minecraft:light[level=12]
setblock 238 159 353 minecraft:light[level=12]
setblock 238 159 360 minecraft:light[level=12]
setblock 239 159 323 minecraft:mushroom_stem
fill 239 159 331 239 159 332 minecraft:moss_block
setblock 239 159 333 minecraft:mushroom_stem
fill 239 159 334 239 159 337 minecraft:moss_block
setblock 239 159 338 minecraft:mushroom_stem
setblock 239 159 363 minecraft:mushroom_stem
fill 240 159 323 243 159 323 minecraft:moss_block
fill 240 159 334 240 159 335 minecraft:moss_block
fill 240 159 363 243 159 363 minecraft:moss_block
fill 241 159 324 242 159 324 minecraft:moss_block
fill 241 159 362 244 159 362 minecraft:moss_block
setblock 243 159 324 minecraft:mushroom_stem
setblock 244 159 323 minecraft:mushroom_stem
fill 244 159 324 247 159 324 minecraft:moss_block
setblock 244 159 363 minecraft:mushroom_stem
fill 245 159 323 248 159 323 minecraft:moss_block
setblock 245 159 325 minecraft:light[level=12]
setblock 245 159 332 minecraft:light[level=12]
setblock 245 159 339 minecraft:light[level=12]
setblock 245 159 346 minecraft:light[level=12]
setblock 245 159 353 minecraft:light[level=12]
setblock 245 159 360 minecraft:light[level=12]
setblock 245 159 362 minecraft:mushroom_stem
fill 245 159 363 248 159 363 minecraft:moss_block
fill 246 159 362 247 161 362 minecraft:moss_block
setblock 247 159 322 minecraft:shroomlight
setblock 248 159 324 minecraft:mushroom_stem
setblock 249 159 323 minecraft:mushroom_stem
setblock 249 159 363 minecraft:mushroom_stem
fill 250 159 323 253 159 323 minecraft:moss_block
fill 250 159 363 253 159 363 minecraft:moss_block
setblock 252 159 325 minecraft:light[level=12]
setblock 252 159 332 minecraft:light[level=12]
setblock 252 159 339 minecraft:light[level=12]
setblock 252 159 346 minecraft:light[level=12]
setblock 252 159 353 minecraft:light[level=12]
setblock 252 159 360 minecraft:light[level=12]
setblock 254 159 323 minecraft:mushroom_stem
setblock 254 159 363 minecraft:mushroom_stem
fill 255 159 323 258 159 323 minecraft:moss_block
fill 255 159 363 258 159 363 minecraft:moss_block
fill 256 159 362 259 159 362 minecraft:moss_block
fill 258 159 361 260 159 361 minecraft:moss_block
setblock 259 159 323 minecraft:mushroom_stem
setblock 259 159 325 minecraft:light[level=12]
setblock 259 159 332 minecraft:light[level=12]
setblock 259 159 339 minecraft:light[level=12]
setblock 259 159 346 minecraft:light[level=12]
setblock 259 159 353 minecraft:light[level=12]
setblock 259 159 360 minecraft:light[level=12]
setblock 259 159 363 minecraft:mushroom_stem
fill 260 159 323 262 159 324 minecraft:moss_block
fill 260 159 360 261 159 360 minecraft:moss_block
setblock 260 159 362 minecraft:mushroom_stem
fill 260 159 363 263 159 363 minecraft:moss_block
setblock 261 159 361 minecraft:mushroom_stem
fill 261 159 362 264 159 362 minecraft:moss_block
setblock 262 159 359 minecraft:moss_block
setblock 262 159 360 minecraft:mushroom_stem
fill 262 159 361 265 159 361 minecraft:moss_block
setblock 263 159 323 minecraft:moss_block
setblock 263 159 324 minecraft:mushroom_stem
setblock 263 159 359 minecraft:mushroom_stem
fill 263 159 360 266 159 360 minecraft:moss_block
setblock 264 159 323 minecraft:mushroom_stem
setblock 264 159 359 minecraft:moss_block
setblock 264 159 363 minecraft:mushroom_stem
fill 265 159 323 266 160 323 minecraft:moss_block
setblock 265 159 362 minecraft:mushroom_stem
fill 265 159 363 268 159 363 minecraft:moss_block
setblock 266 159 325 minecraft:light[level=12]
setblock 266 159 332 minecraft:light[level=12]
setblock 266 159 339 minecraft:light[level=12]
setblock 266 159 346 minecraft:light[level=12]
setblock 266 159 353 minecraft:light[level=12]
setblock 266 159 361 minecraft:mushroom_stem
fill 266 159 362 269 159 362 minecraft:moss_block
fill 267 159 361 268 159 361 minecraft:moss_block
setblock 269 159 363 minecraft:mushroom_stem
fill 270 159 363 270 161 363 minecraft:moss_block
fill 271 159 343 271 163 343 minecraft:red_mushroom_block
fill 272 159 334 272 163 334 minecraft:dirt
setblock 273 159 325 minecraft:light[level=12]
setblock 273 159 332 minecraft:light[level=12]
setblock 273 159 339 minecraft:light[level=12]
setblock 273 159 346 minecraft:light[level=12]
setblock 273 159 353 minecraft:light[level=12]
setblock 273 159 360 minecraft:light[level=12]
fill 275 159 334 275 159 336 minecraft:moss_block
setblock 275 159 337 minecraft:mushroom_stem
fill 275 159 338 276 160 339 minecraft:moss_block
setblock 275 159 351 minecraft:moss_block
setblock 275 159 352 minecraft:mushroom_stem
fill 275 159 353 275 159 356 minecraft:moss_block
setblock 275 159 357 minecraft:mushroom_stem
fill 275 159 358 276 160 359 minecraft:moss_block
setblock 276 159 325 minecraft:red_mushroom_block
setblock 276 159 330 minecraft:moss_block
setblock 276 159 331 minecraft:mushroom_stem
fill 276 159 332 276 159 335 minecraft:moss_block
setblock 276 159 336 minecraft:mushroom_stem
fill 276 159 337 276 162 337 minecraft:moss_block
setblock 276 159 340 minecraft:moss_block
setblock 276 159 341 minecraft:mushroom_stem
fill 276 159 342 276 159 345 minecraft:moss_block
setblock 276 159 346 minecraft:mushroom_stem
fill 276 159 347 276 159 350 minecraft:moss_block
setblock 276 159 351 minecraft:mushroom_stem
fill 276 159 352 276 159 355 minecraft:moss_block
setblock 276 159 356 minecraft:mushroom_stem
fill 276 159 357 276 162 357 minecraft:moss_block
setblock 276 159 360 minecraft:moss_block
setblock 276 159 361 minecraft:mushroom_stem
fill 235 160 331 235 199 331 minecraft:green_terracotta
fill 235 160 336 235 188 336 minecraft:green_terracotta
setblock 236 160 323 minecraft:red_mushroom_block
fill 236 160 328 236 160 329 minecraft:moss_block
setblock 236 160 330 minecraft:mushroom_stem
fill 236 160 331 236 160 334 minecraft:moss_block
setblock 236 160 335 minecraft:mushroom_stem
fill 236 160 336 236 160 339 minecraft:moss_block
setblock 236 160 340 minecraft:mushroom_stem
fill 236 160 341 236 160 344 minecraft:moss_block
setblock 236 160 345 minecraft:mushroom_stem
setblock 236 160 346 minecraft:moss_block
setblock 236 160 350 minecraft:mushroom_stem
fill 236 160 351 236 160 354 minecraft:moss_block
setblock 236 160 355 minecraft:mushroom_stem
fill 236 160 356 236 160 359 minecraft:moss_block
setblock 236 160 360 minecraft:mushroom_stem
setblock 237 160 329 minecraft:mushroom_stem
fill 237 160 330 237 160 333 minecraft:moss_block
setblock 237 160 334 minecraft:mushroom_stem
fill 237 160 335 237 160 338 minecraft:moss_block
setblock 237 160 339 minecraft:mushroom_stem
fill 237 160 340 237 163 340 minecraft:moss_block
setblock 237 160 343 minecraft:moss_block
setblock 237 160 355 minecraft:moss_block
setblock 238 160 323 minecraft:mushroom_stem
fill 238 160 330 238 160 332 minecraft:moss_block
setblock 238 160 333 minecraft:mushroom_stem
fill 238 160 334 238 160 337 minecraft:moss_block
setblock 238 160 338 minecraft:mushroom_stem
fill 238 160 339 239 162 339 minecraft:moss_block
fill 238 160 341 238 161 341 minecraft:moss_block
setblock 238 160 363 minecraft:mushroom_stem
fill 239 160 323 242 160 323 minecraft:moss_block
setblock 239 160 332 minecraft:mushroom_stem
fill 239 160 333 239 160 336 minecraft:moss_block
setblock 239 160 337 minecraft:mushroom_stem
fill 239 160 338 239 163 338 minecraft:moss_block
fill 239 160 363 242 160 363 minecraft:moss_block
fill 240 160 324 241 160 324 minecraft:moss_block
setblock 240 160 335 minecraft:moss_block
fill 240 160 362 243 160 362 minecraft:moss_block
setblock 242 160 324 minecraft:mushroom_stem
setblock 243 160 323 minecraft:mushroom_stem
fill 243 160 324 246 160 324 minecraft:moss_block
setblock 243 160 363 minecraft:mushroom_stem
fill 244 160 323 247 160 323 minecraft:moss_block
setblock 244 160 362 minecraft:mushroom_stem
fill 244 160 363 247 160 363 minecraft:moss_block
fill 245 160 362 245 163 362 minecraft:moss_block
fill 246 160 327 246 173 327 minecraft:iron_block
fill 247 160 322 247 212 322 minecraft:green_terracotta
setblock 247 160 324 minecraft:mushroom_stem
setblock 248 160 323 minecraft:mushroom_stem
setblock 248 160 363 minecraft:mushroom_stem
fill 249 160 323 251 160 323 minecraft:moss_block
fill 249 160 363 252 160 363 minecraft:moss_block
setblock 253 160 323 minecraft:red_mushroom_block
setblock 253 160 363 minecraft:mushroom_stem
fill 254 160 323 257 160 323 minecraft:moss_block
fill 254 160 363 257 160 363 minecraft:moss_block
fill 255 160 362 258 160 362 minecraft:moss_block
fill 257 160 361 259 160 361 minecraft:moss_block
setblock 258 160 323 minecraft:mushroom_stem
setblock 258 160 363 minecraft:mushroom_stem
fill 259 160 323 262 160 323 minecraft:moss_block
fill 259 160 360 260 160 360 minecraft:moss_block
setblock 259 160 362 minecraft:mushroom_stem
fill 259 160 363 262 160 363 minecraft:moss_block
setblock 260 160 361 minecraft:mushroom_stem
fill 260 160 362 263 160 362 minecraft:moss_block
setblock 261 160 360 minecraft:mushroom_stem
fill 261 160 361 264 160 361 minecraft:moss_block
setblock 262 160 359 minecraft:mushroom_stem
fill 262 160 360 265 160 360 minecraft:moss_block
setblock 263 160 323 minecraft:mushroom_stem
setblock 263 160 359 minecraft:moss_block
setblock 263 160 363 minecraft:mushroom_stem
fill 264 160 323 264 162 323 minecraft:moss_block
setblock 264 160 362 minecraft:mushroom_stem
fill 264 160 363 267 160 363 minecraft:moss_block
setblock 265 160 361 minecraft:mushroom_stem
fill 265 160 362 268 160 362 minecraft:moss_block
setblock 266 160 360 minecraft:mushroom_stem
fill 266 160 361 267 161 361 minecraft:moss_block
setblock 268 160 363 minecraft:mushroom_stem
setblock 269 160 362 minecraft:mushroom_stem
fill 269 160 363 269 162 363 minecraft:moss_block
setblock 272 160 323 minecraft:red_mushroom_block
fill 272 160 364 272 228 364 minecraft:green_terracotta
setblock 273 160 364 minecraft:shroomlight
fill 274 160 364 277 200 364 minecraft:green_terracotta
fill 275 160 334 275 160 335 minecraft:moss_block
setblock 275 160 336 minecraft:mushroom_stem
fill 275 160 337 275 163 337 minecraft:moss_block
setblock 275 160 340 minecraft:moss_block
fill 275 160 352 275 160 355 minecraft:moss_block
setblock 275 160 356 minecraft:mushroom_stem
fill 275 160 357 275 162 357 minecraft:moss_block
fill 276 160 331 276 160 334 minecraft:moss_block
setblock 276 160 335 minecraft:mushroom_stem
fill 276 160 336 276 163 336 minecraft:moss_block
setblock 276 160 340 minecraft:mushroom_stem
fill 276 160 341 276 160 344 minecraft:moss_block
setblock 276 160 345 minecraft:mushroom_stem
fill 276 160 346 276 160 349 minecraft:moss_block
setblock 276 160 350 minecraft:mushroom_stem
fill 276 160 351 276 160 354 minecraft:moss_block
setblock 276 160 355 minecraft:mushroom_stem
fill 276 160 356 276 163 356 minecraft:moss_block
setblock 276 160 360 minecraft:mushroom_stem
fill 276 160 361 276 162 362 minecraft:moss_block
setblock 236 161 328 minecraft:moss_block
setblock 236 161 329 minecraft:mushroom_stem
fill 236 161 330 236 161 333 minecraft:moss_block
setblock 236 161 334 minecraft:mushroom_stem
fill 236 161 335 236 161 338 minecraft:moss_block
setblock 236 161 339 minecraft:mushroom_stem
fill 236 161 340 236 161 343 minecraft:moss_block
setblock 236 161 344 minecraft:mushroom_stem
fill 236 161 345 236 164 345 minecraft:moss_block
setblock 236 161 348 minecraft:red_mushroom_block
fill 236 161 352 236 161 353 minecraft:moss_block
setblock 236 161 354 minecraft:mushroom_stem
fill 236 161 355 236 161 358 minecraft:moss_block
setblock 236 161 359 minecraft:mushroom_stem
fill 236 161 360 236 163 361 minecraft:moss_block
fill 237 161 329 237 161 332 minecraft:moss_block
setblock 237 161 333 minecraft:mushroom_stem
fill 237 161 334 237 161 337 minecraft:moss_block
setblock 237 161 338 minecraft:mushroom_stem
fill 237 161 339 237 164 339 minecraft:moss_block
setblock 237 161 343 minecraft:mushroom_stem
fill 238 161 323 241 161 323 minecraft:moss_block
setblock 238 161 331 minecraft:moss_block
setblock 238 161 332 minecraft:mushroom_stem
fill 238 161 333 238 161 336 minecraft:moss_block
setblock 238 161 337 minecraft:mushroom_stem
fill 238 161 338 238 164 338 minecraft:moss_block
fill 238 161 363 241 161 363 minecraft:moss_block
fill 239 161 332 239 161 335 minecraft:moss_block
setblock 239 161 336 minecraft:mushroom_stem
fill 239 161 337 239 164 337 minecraft:moss_block
setblock 240 161 324 minecraft:moss_block
fill 240 161 362 242 161 362 minecraft:moss_block
setblock 241 161 324 minecraft:mushroom_stem
setblock 242 161 323 minecraft:mushroom_stem
fill 242 161 324 245 161 324 minecraft:moss_block
setblock 242 161 363 minecraft:mushroom_stem
fill 243 161 323 246 161 323 minecraft:moss_block
setblock 243 161 362 minecraft:mushroom_stem
fill 243 161 363 246 161 363 minecraft:moss_block
fill 244 161 362 244 164 362 minecraft:moss_block
setblock 246 161 324 minecraft:mushroom_stem
setblock 247 161 323 minecraft:mushroom_stem
setblock 247 161 363 minecraft:mushroom_stem
fill 248 161 323 250 161 323 minecraft:moss_block
fill 248 161 363 251 161 363 minecraft:moss_block
setblock 252 161 363 minecraft:mushroom_stem
fill 253 161 363 256 161 363 minecraft:moss_block
fill 254 161 323 256 161 323 minecraft:moss_block
fill 254 161 362 257 161 362 minecraft:moss_block
fill 256 161 361 258 161 361 minecraft:moss_block
setblock 257 161 323 minecraft:mushroom_stem
setblock 257 161 363 minecraft:mushroom_stem
fill 258 161 323 261 161 323 minecraft:moss_block
fill 258 161 360 259 161 360 minecraft:moss_block
setblock 258 161 362 minecraft:mushroom_stem
fill 258 161 363 261 161 363 minecraft:moss_block
setblock 259 161 361 minecraft:mushroom_stem
fill 259 161 362 262 161 362 minecraft:moss_block
setblock 260 161 360 minecraft:mushroom_stem
fill 260 161 361 263 161 361 minecraft:moss_block
fill 261 161 360 264 161 360 minecraft:moss_block
setblock 262 161 323 minecraft:mushroom_stem
setblock 262 161 359 minecraft:moss_block
setblock 262 161 363 minecraft:mushroom_stem
fill 263 161 323 263 164 323 minecraft:moss_block
setblock 263 161 362 minecraft:mushroom_stem
fill 263 161 363 266 161 363 minecraft:moss_block
setblock 264 161 361 minecraft:mushroom_stem
fill 264 161 362 267 161 362 minecraft:moss_block
setblock 265 161 323 minecraft:moss_block
setblock 265 161 360 minecraft:mushroom_stem
fill 265 161 361 265 164 361 minecraft:moss_block
setblock 266 161 323 minecraft:red_mushroom_block
setblock 267 161 363 minecraft:mushroom_stem
setblock 268 161 362 minecraft:mushroom_stem
fill 268 161 363 268 164 363 minecraft:moss_block
fill 269 161 334 271 162 338 minecraft:dirt
fill 272 161 333 272 163 333 minecraft:dirt
fill 272 161 335 273 162 338 minecraft:dirt
fill 273 161 334 273 163 334 minecraft:dirt
fill 273 161 364 273 178 364 minecraft:green_terracotta
setblock 274 161 336 minecraft:dirt
setblock 275 161 334 minecraft:moss_block
setblock 275 161 335 minecraft:mushroom_stem
fill 275 161 336 275 164 336 minecraft:moss_block
fill 275 161 338 275 161 339 minecraft:moss_block
setblock 275 161 340 minecraft:mushroom_stem
fill 275 161 341 276 163 341 minecraft:moss_block
fill 275 161 353 275 161 354 minecraft:moss_block
setblock 275 161 355 minecraft:mushroom_stem
fill 275 161 356 275 162 356 minecraft:moss_block
fill 275 161 358 275 161 359 minecraft:moss_block
fill 276 161 331 276 161 333 minecraft:moss_block
setblock 276 161 334 minecraft:mushroom_stem
fill 276 161 335 276 164 335 minecraft:moss_block
setblock 276 161 338 minecraft:moss_block
setblock 276 161 339 minecraft:mushroom_stem
fill 276 161 340 276 164 340 minecraft:moss_block
fill 276 161 342 276 161 343 minecraft:moss_block
setblock 276 161 344 minecraft:mushroom_stem
fill 276 161 345 276 161 348 minecraft:moss_block
setblock 276 161 349 minecraft:mushroom_stem
fill 276 161 350 276 161 353 minecraft:moss_block
setblock 276 161 354 minecraft:mushroom_stem
fill 276 161 355 276 164 355 minecraft:moss_block
setblock 276 161 358 minecraft:moss_block
setblock 276 161 359 minecraft:mushroom_stem
fill 276 161 360 276 164 360 minecraft:moss_block
fill 277 161 356 277 228 357 minecraft:green_terracotta
setblock 277 161 358 minecraft:shroomlight
setblock 236 162 328 minecraft:mushroom_stem
fill 236 162 329 236 162 332 minecraft:moss_block
setblock 236 162 333 minecraft:mushroom_stem
fill 236 162 334 236 162 337 minecraft:moss_block
setblock 236 162 338 minecraft:mushroom_stem
fill 236 162 339 236 162 342 minecraft:moss_block
setblock 236 162 343 minecraft:mushroom_stem
fill 236 162 344 236 165 344 minecraft:moss_block
fill 236 162 354 236 162 357 minecraft:moss_block
setblock 236 162 358 minecraft:mushroom_stem
fill 236 162 359 236 165 359 minecraft:moss_block
setblock 236 162 362 minecraft:moss_block
fill 237 162 323 240 162 323 minecraft:moss_block
fill 237 162 330 237 162 331 minecraft:moss_block
setblock 237 162 332 minecraft:mushroom_stem
fill 237 162 333 237 162 336 minecraft:moss_block
setblock 237 162 337 minecraft:mushroom_stem
fill 237 162 338 237 165 338 minecraft:moss_block
setblock 237 162 341 minecraft:moss_block
setblock 237 162 342 minecraft:mushroom_stem
fill 237 162 343 237 165 343 minecraft:moss_block
fill 237 162 363 240 162 363 minecraft:moss_block
setblock 238 162 331 minecraft:mushroom_stem
fill 238 162 332 238 162 335 minecraft:moss_block
setblock 238 162 336 minecraft:mushroom_stem
fill 238 162 337 238 165 337 minecraft:moss_block
setblock 238 162 341 minecraft:mushroom_stem
fill 239 162 333 239 162 334 minecraft:moss_block
setblock 239 162 335 minecraft:mushroom_stem
fill 239 162 336 239 164 336 minecraft:moss_block
fill 239 162 362 241 162 362 minecraft:moss_block
setblock 240 162 324 minecraft:mushroom_stem
setblock 241 162 323 minecraft:mushroom_stem
fill 241 162 324 244 162 324 minecraft:moss_block
setblock 241 162 363 minecraft:mushroom_stem
fill 242 162 323 245 162 323 minecraft:moss_block
fill 242 162 346 242 175 346 minecraft:iron_block
setblock 242 162 362 minecraft:mushroom_stem
fill 242 162 363 245 162 363 minecraft:moss_block
fill 243 162 362 243 165 362 minecraft:moss_block
setblock 245 162 324 minecraft:mushroom_stem
setblock 246 162 323 minecraft:mushroom_stem
setblock 246 162 362 minecraft:moss_block
setblock 246 162 363 minecraft:mushroom_stem
fill 247 162 323 249 162 323 minecraft:moss_block
fill 247 162 363 250 162 363 minecraft:moss_block
setblock 251 162 363 minecraft:mushroom_stem
fill 252 162 363 255 162 363 minecraft:moss_block
fill 253 162 362 256 162 362 minecraft:moss_block
fill 254 162 323 255 162 323 minecraft:moss_block
setblock 256 162 323 minecraft:mushroom_stem
fill 256 162 361 257 162 361 minecraft:moss_block
setblock 256 162 363 minecraft:mushroom_stem
fill 257 162 323 260 162 323 minecraft:moss_block
setblock 257 162 362 minecraft:mushroom_stem
fill 257 162 363 260 162 363 minecraft:moss_block
setblock 258 162 360 minecraft:moss_block
setblock 258 162 361 minecraft:mushroom_stem
fill 258 162 362 261 162 362 minecraft:moss_block
setblock 259 162 360 minecraft:mushroom_stem
fill 259 162 361 262 162 361 minecraft:moss_block
fill 260 162 360 263 162 360 minecraft:moss_block
setblock 261 162 323 minecraft:mushroom_stem
setblock 261 162 363 minecraft:mushroom_stem
fill 261 162 364 261 213 364 minecraft:green_terracotta
fill 262 162 323 262 165 323 minecraft:moss_block
setblock 262 162 362 minecraft:mushroom_stem
fill 262 162 363 265 162 363 minecraft:moss_block
setblock 262 162 364 minecraft:shroomlight
setblock 263 162 361 minecraft:mushroom_stem
fill 263 162 362 266 162 362 minecraft:moss_block
fill 263 162 364 266 225 364 minecraft:green_terracotta
setblock 264 162 360 minecraft:mushroom_stem
fill 264 162 361 264 165 361 minecraft:moss_block
setblock 266 162 361 minecraft:moss_block
setblock 266 162 363 minecraft:mushroom_stem
setblock 267 162 362 minecraft:mushroom_stem
fill 267 162 363 267 165 363 minecraft:moss_block
setblock 271 162 363 minecraft:red_mushroom_block
fill 275 162 335 275 165 335 minecraft:moss_block
setblock 275 162 338 minecraft:moss_block
setblock 275 162 339 minecraft:mushroom_stem
fill 275 162 340 275 165 340 minecraft:moss_block
fill 275 162 342 276 162 342 minecraft:moss_block
setblock 275 162 358 minecraft:moss_block
fill 276 162 331 276 162 332 minecraft:moss_block
setblock 276 162 333 minecraft:mushroom_stem
fill 276 162 334 276 165 334 minecraft:moss_block
setblock 276 162 338 minecraft:mushroom_stem
fill 276 162 339 276 165 339 minecraft:moss_block
setblock 276 162 343 minecraft:mushroom_stem
fill 276 162 344 276 162 347 minecraft:moss_block
setblock 276 162 348 minecraft:mushroom_stem
fill 276 162 349 276 162 352 minecraft:moss_block
setblock 276 162 353 minecraft:mushroom_stem
fill 276 162 354 276 165 354 minecraft:moss_block
setblock 276 162 358 minecraft:mushroom_stem
fill 276 162 359 276 165 359 minecraft:moss_block
fill 277 162 342 277 226 344 minecraft:green_terracotta
setblock 277 162 345 minecraft:red_mushroom_block
fill 277 162 346 277 210 348 minecraft:green_terracotta
fill 277 162 358 277 228 358 minecraft:green_terracotta
fill 236 163 328 236 163 331 minecraft:moss_block
setblock 236 163 332 minecraft:mushroom_stem
fill 236 163 333 236 163 336 minecraft:moss_block
setblock 236 163 337 minecraft:mushroom_stem
fill 236 163 338 236 163 341 minecraft:moss_block
setblock 236 163 342 minecraft:mushroom_stem
fill 236 163 343 236 166 343 minecraft:moss_block
setblock 236 163 356 minecraft:moss_block
setblock 236 163 357 minecraft:mushroom_stem
fill 236 163 358 236 166 358 minecraft:moss_block
setblock 236 163 362 minecraft:mushroom_stem
fill 236 163 363 239 163 363 minecraft:moss_block
fill 237 163 323 239 163 323 minecraft:moss_block
setblock 237 163 330 minecraft:moss_block
setblock 237 163 331 minecraft:mushroom_stem
fill 237 163 332 237 163 335 minecraft:moss_block
setblock 237 163 336 minecraft:mushroom_stem
fill 237 163 337 237 166 337 minecraft:moss_block
setblock 237 163 341 minecraft:mushroom_stem
fill 237 163 342 237 166 342 minecraft:moss_block
fill 238 163 332 238 163 334 minecraft:moss_block
setblock 238 163 335 minecraft:mushroom_stem
fill 238 163 336 238 166 336 minecraft:moss_block
setblock 238 163 339 minecraft:moss_block
setblock 238 163 340 minecraft:mushroom_stem
fill 238 163 341 238 166 341 minecraft:moss_block
setblock 239 163 324 minecraft:mushroom_stem
setblock 239 163 335 minecraft:moss_block
setblock 239 163 339 minecraft:mushroom_stem
fill 239 163 362 240 163 362 minecraft:moss_block
setblock 240 163 323 minecraft:mushroom_stem
fill 240 163 324 243 163 324 minecraft:moss_block
setblock 240 163 363 minecraft:mushroom_stem
fill 241 163 323 244 163 323 minecraft:moss_block
setblock 241 163 362 minecraft:mushroom_stem
fill 241 163 363 244 163 363 minecraft:moss_block
fill 242 163 362 242 166 362 minecraft:moss_block
setblock 244 163 324 minecraft:mushroom_stem
setblock 245 163 323 minecraft:mushroom_stem
setblock 245 163 363 minecraft:mushroom_stem
fill 246 163 323 248 164 323 minecraft:moss_block
fill 246 163 363 249 163 363 minecraft:moss_block
setblock 250 163 363 minecraft:mushroom_stem
fill 251 163 363 254 163 363 minecraft:moss_block
fill 253 163 362 255 163 362 minecraft:moss_block
setblock 254 163 323 minecraft:moss_block
setblock 255 163 323 minecraft:mushroom_stem
fill 255 163 361 256 163 361 minecraft:moss_block
setblock 255 163 363 minecraft:mushroom_stem
fill 256 163 323 259 163 323 minecraft:moss_block
setblock 256 163 362 minecraft:mushroom_stem
fill 256 163 363 259 163 363 minecraft:moss_block
setblock 257 163 361 minecraft:mushroom_stem
fill 257 163 362 260 163 362 minecraft:moss_block
setblock 258 163 360 minecraft:mushroom_stem
fill 258 163 361 261 163 361 minecraft:moss_block
fill 259 163 360 262 163 360 minecraft:moss_block
setblock 260 163 323 minecraft:mushroom_stem
setblock 260 163 363 minecraft:mushroom_stem
setblock 260 163 364 minecraft:shroomlight
fill 261 163 323 261 166 323 minecraft:moss_block
setblock 261 163 362 minecraft:mushroom_stem
fill 261 163 363 264 163 363 minecraft:moss_block
setblock 262 163 361 minecraft:mushroom_stem
fill 262 163 362 265 163 362 minecraft:moss_block
fill 262 163 364 262 228 364 minecraft:green_terracotta
setblock 263 163 360 minecraft:mushroom_stem
fill 263 163 361 263 166 361 minecraft:moss_block
setblock 265 163 363 minecraft:mushroom_stem
setblock 266 163 362 minecraft:mushroom_stem
fill 266 163 363 266 166 363 minecraft:moss_block
setblock 267 163 362 minecraft:moss_block
fill 270 163 336 272 169 336 minecraft:mushroom_stem
fill 271 163 333 271 163 335 minecraft:dirt
fill 271 163 337 271 169 337 minecraft:mushroom_stem
fill 272 163 335 273 163 335 minecraft:dirt
setblock 273 163 333 minecraft:dirt
setblock 275 163 338 minecraft:mushroom_stem
fill 275 163 339 275 166 339 minecraft:moss_block
setblock 275 163 342 minecraft:moss_block
setblock 275 163 343 minecraft:mushroom_stem
setblock 276 163 326 minecraft:red_mushroom_block
setblock 276 163 332 minecraft:mushroom_stem
fill 276 163 333 276 166 333 minecraft:moss_block
setblock 276 163 337 minecraft:mushroom_stem
fill 276 163 338 276 166 338 minecraft:moss_block
setblock 276 163 342 minecraft:mushroom_stem
fill 276 163 343 276 163 346 minecraft:moss_block
setblock 276 163 347 minecraft:mushroom_stem
fill 276 163 348 276 163 351 minecraft:moss_block
setblock 276 163 352 minecraft:mushroom_stem
fill 276 163 353 276 164 353 minecraft:moss_block
setblock 276 163 357 minecraft:mushroom_stem
fill 276 163 358 276 166 358 minecraft:moss_block
setblock 276 163 361 minecraft:moss_block
setblock 276 163 362 minecraft:mushroom_stem
fill 277 163 345 277 225 345 minecraft:green_terracotta
fill 236 164 323 236 165 324 minecraft:moss_block
fill 236 164 327 236 164 330 minecraft:moss_block
setblock 236 164 331 minecraft:mushroom_stem
fill 236 164 332 236 164 335 minecraft:moss_block
setblock 236 164 336 minecraft:mushroom_stem
fill 236 164 337 236 164 340 minecraft:moss_block
setblock 236 164 341 minecraft:mushroom_stem
fill 236 164 342 236 167 342 minecraft:moss_block
setblock 236 164 347 minecraft:red_mushroom_block
fill 236 164 357 236 165 357 minecraft:moss_block
setblock 236 164 360 minecraft:moss_block
setblock 236 164 361 minecraft:mushroom_stem
fill 236 164 362 236 166 363 minecraft:moss_block
fill 237 164 323 238 164 323 minecraft:moss_block
fill 237 164 331 237 164 334 minecraft:moss_block
setblock 237 164 335 minecraft:mushroom_stem
fill 237 164 336 237 167 336 minecraft:moss_block
setblock 237 164 340 minecraft:mushroom_stem
fill 237 164 341 237 167 341 minecraft:moss_block
fill 237 164 363 238 164 363 minecraft:moss_block
setblock 238 164 322 minecraft:shroomlight
setblock 238 164 333 minecraft:moss_block
setblock 238 164 334 minecraft:mushroom_stem
fill 238 164 335 238 167 335 minecraft:moss_block
setblock 238 164 339 minecraft:mushroom_stem
fill 238 164 340 238 167 340 minecraft:moss_block
fill 238 164 362 239 164 362 minecraft:moss_block
fill 239 164 322 242 180 322 minecraft:green_terracotta
setblock 239 164 323 minecraft:mushroom_stem
fill 239 164 324 242 164 324 minecraft:moss_block
setblock 239 164 338 minecraft:mushroom_stem
setblock 239 164 363 minecraft:mushroom_stem
fill 240 164 323 243 164 323 minecraft:moss_block
setblock 240 164 362 minecraft:mushroom_stem
fill 240 164 363 243 164 363 minecraft:moss_block
setblock 241 164 361 minecraft:shroomlight
fill 241 164 362 241 167 362 minecraft:moss_block
setblock 243 164 324 minecraft:mushroom_stem
setblock 244 164 323 minecraft:mushroom_stem
setblock 244 164 363 minecraft:mushroom_stem
fill 245 164 323 245 167 323 minecraft:moss_block
setblock 245 164 362 minecraft:mushroom_stem
fill 245 164 363 248 164 363 minecraft:moss_block
setblock 249 164 363 minecraft:mushroom_stem
fill 250 164 363 253 164 363 minecraft:moss_block
fill 252 164 362 254 164 362 minecraft:moss_block
setblock 253 164 323 minecraft:moss_block
setblock 254 164 323 minecraft:mushroom_stem
setblock 254 164 363 minecraft:mushroom_stem
fill 255 164 323 258 164 323 minecraft:moss_block
setblock 255 164 361 minecraft:moss_block
setblock 255 164 362 minecraft:mushroom_stem
fill 255 164 363 258 164 363 minecraft:moss_block
setblock 256 164 361 minecraft:mushroom_stem
fill 256 164 362 259 164 362 minecraft:moss_block
fill 257 164 361 260 164 361 minecraft:moss_block
fill 258 164 360 261 164 360 minecraft:moss_block
setblock 259 164 323 minecraft:mushroom_stem
setblock 259 164 363 minecraft:mushroom_stem
fill 260 164 323 260 167 323 minecraft:moss_block
setblock 260 164 362 minecraft:mushroom_stem
fill 260 164 363 263 164 363 minecraft:moss_block
fill 260 164 364 260 228 364 minecraft:green_terracotta
setblock 261 164 361 minecraft:mushroom_stem
fill 261 164 362 264 164 362 minecraft:moss_block
setblock 262 164 360 minecraft:mushroom_stem
fill 262 164 361 262 167 361 minecraft:moss_block
setblock 264 164 363 minecraft:mushroom_stem
setblock 265 164 362 minecraft:mushroom_stem
fill 265 164 363 265 167 363 minecraft:moss_block
fill 266 164 362 266 165 362 minecraft:moss_block
fill 267 164 322 268 165 322 minecraft:green_terracotta
fill 267 164 323 267 165 323 minecraft:red_mushroom_block
setblock 269 164 322 minecraft:shroomlight
fill 270 164 322 271 178 322 minecraft:green_terracotta
fill 271 164 335 271 169 335 minecraft:mushroom_stem
setblock 273 164 323 minecraft:red_mushroom_block
setblock 275 164 337 minecraft:mushroom_stem
fill 275 164 338 275 167 338 minecraft:moss_block
setblock 275 164 341 minecraft:moss_block
setblock 275 164 342 minecraft:mushroom_stem
fill 275 164 343 276 166 343 minecraft:moss_block
fill 276 164 332 276 167 332 minecraft:moss_block
setblock 276 164 336 minecraft:mushroom_stem
fill 276 164 337 276 167 337 minecraft:moss_block
setblock 276 164 341 minecraft:mushroom_stem
fill 276 164 342 276 167 342 minecraft:moss_block
fill 276 164 344 276 164 345 minecraft:moss_block
setblock 276 164 346 minecraft:mushroom_stem
fill 276 164 347 276 165 349 minecraft:moss_block
setblock 276 164 352 minecraft:moss_block
setblock 276 164 356 minecraft:mushroom_stem
fill 276 164 357 276 167 357 minecraft:moss_block
setblock 276 164 361 minecraft:mushroom_stem
fill 276 164 362 276 166 363 minecraft:moss_block
fill 235 165 345 235 175 348 minecraft:green_terracotta
setblock 235 165 349 minecraft:shroomlight
fill 235 165 350 235 189 360 minecraft:green_terracotta
setblock 236 165 325 minecraft:mushroom_stem
fill 236 165 326 236 165 329 minecraft:moss_block
setblock 236 165 330 minecraft:mushroom_stem
fill 236 165 331 236 165 334 minecraft:moss_block
setblock 236 165 335 minecraft:mushroom_stem
fill 236 165 336 236 165 339 minecraft:moss_block
setblock 236 165 340 minecraft:mushroom_stem
fill 236 165 341 236 168 341 minecraft:moss_block
setblock 236 165 345 minecraft:mushroom_stem
fill 236 165 346 236 168 346 minecraft:moss_block
setblock 236 165 353 minecraft:red_mushroom_block
setblock 236 165 360 minecraft:mushroom_stem
fill 236 165 361 236 168 361 minecraft:moss_block
setblock 237 165 323 minecraft:moss_block
fill 237 165 331 237 165 333 minecraft:moss_block
setblock 237 165 334 minecraft:mushroom_stem
fill 237 165 335 237 168 335 minecraft:moss_block
setblock 237 165 339 minecraft:mushroom_stem
fill 237 165 340 237 168 340 minecraft:moss_block
setblock 237 165 344 minecraft:mushroom_stem
setblock 237 165 363 minecraft:moss_block
fill 238 165 322 238 228 322 minecraft:green_terracotta
setblock 238 165 323 minecraft:mushroom_stem
fill 238 165 324 241 165 324 minecraft:moss_block
setblock 238 165 325 minecraft:light[level=15]
setblock 238 165 332 minecraft:light[level=12]
setblock 238 165 333 minecraft:light[level=15]
fill 238 165 334 238 166 334 minecraft:moss_block
setblock 238 165 338 minecraft:mushroom_stem
fill 238 165 339 238 168 339 minecraft:moss_block
setblock 238 165 342 minecraft:moss_block
setblock 238 165 346 minecraft:light[level=12]
setblock 238 165 349 minecraft:light[level=15]
setblock 238 165 353 minecraft:light[level=12]
setblock 238 165 357 minecraft:light[level=15]
setblock 238 165 360 minecraft:light[level=12]
setblock 238 165 362 minecraft:moss_block
setblock 238 165 363 minecraft:mushroom_stem
fill 239 165 323 242 165 323 minecraft:moss_block
setblock 239 165 362 minecraft:mushroom_stem
fill 239 165 363 242 165 363 minecraft:moss_block
fill 240 165 362 240 168 362 minecraft:moss_block
fill 241 165 361 241 169 361 minecraft:mushroom_stem
setblock 242 165 324 minecraft:mushroom_stem
setblock 243 165 323 minecraft:mushroom_stem
fill 243 165 324 243 168 324 minecraft:moss_block
setblock 243 165 363 minecraft:mushroom_stem
fill 244 165 323 244 168 323 minecraft:moss_block
setblock 244 165 362 minecraft:mushroom_stem
fill 244 165 363 247 165 363 minecraft:moss_block
setblock 245 165 325 minecraft:light[level=12]
setblock 245 165 332 minecraft:light[level=12]
setblock 245 165 339 minecraft:light[level=12]
setblock 245 165 346 minecraft:light[level=12]
setblock 245 165 353 minecraft:light[level=12]
setblock 245 165 360 minecraft:light[level=12]
setblock 245 165 362 minecraft:moss_block
fill 246 165 323 247 165 323 minecraft:moss_block
setblock 246 165 325 minecraft:light[level=15]
setblock 246 165 333 minecraft:light[level=15]
setblock 246 165 341 minecraft:light[level=15]
setblock 246 165 349 minecraft:light[level=15]
setblock 246 165 357 minecraft:light[level=15]
setblock 248 165 323 minecraft:mushroom_stem
setblock 248 165 363 minecraft:mushroom_stem
fill 249 165 363 252 165 363 minecraft:moss_block
setblock 252 165 323 minecraft:moss_block
setblock 252 165 325 minecraft:light[level=12]
setblock 252 165 332 minecraft:light[level=12]
setblock 252 165 339 minecraft:light[level=12]
setblock 252 165 346 minecraft:light[level=12]
setblock 252 165 353 minecraft:light[level=12]
setblock 252 165 360 minecraft:light[level=12]
fill 252 165 362 253 165 362 minecraft:moss_block
setblock 253 165 323 minecraft:mushroom_stem
setblock 253 165 363 minecraft:mushroom_stem
fill 254 165 323 257 165 323 minecraft:moss_block
setblock 254 165 325 minecraft:light[level=15]
setblock 254 165 333 minecraft:light[level=15]
setblock 254 165 341 minecraft:light[level=15]
setblock 254 165 349 minecraft:light[level=15]
setblock 254 165 357 minecraft:light[level=15]
setblock 254 165 362 minecraft:mushroom_stem
fill 254 165 363 257 165 363 minecraft:moss_block
setblock 255 165 361 minecraft:mushroom_stem
fill 255 165 362 258 165 362 minecraft:moss_block
fill 256 165 361 259 165 361 minecraft:moss_block
setblock 258 165 323 minecraft:mushroom_stem
fill 258 165 360 260 165 360 minecraft:moss_block
setblock 258 165 363 minecraft:mushroom_stem
fill 259 165 323 259 168 323 minecraft:moss_block
setblock 259 165 325 minecraft:light[level=12]
setblock 259 165 332 minecraft:light[level=12]
setblock 259 165 339 minecraft:light[level=12]
setblock 259 165 346 minecraft:light[level=12]
setblock 259 165 353 minecraft:light[level=12]
setblock 259 165 362 minecraft:mushroom_stem
fill 259 165 363 262 165 363 minecraft:moss_block
setblock 260 165 361 minecraft:mushroom_stem
fill 260 165 362 263 165 362 minecraft:moss_block
setblock 261 165 360 minecraft:mushroom_stem
fill 261 165 361 261 168 361 minecraft:moss_block
setblock 262 165 325 minecraft:light[level=15]
setblock 262 165 333 minecraft:light[level=15]
setblock 262 165 341 minecraft:light[level=15]
setblock 262 165 349 minecraft:light[level=15]
setblock 262 165 357 minecraft:light[level=15]
setblock 263 165 323 minecraft:mushroom_stem
setblock 263 165 363 minecraft:mushroom_stem
setblock 264 165 362 minecraft:mushroom_stem
fill 264 165 363 264 168 363 minecraft:moss_block
fill 265 165 362 265 168 362 minecraft:moss_block
setblock 266 165 325 minecraft:light[level=12]
setblock 266 165 332 minecraft:light[level=12]
setblock 266 165 339 minecraft:light[level=12]
setblock 266 165 346 minecraft:light[level=12]
setblock 266 165 353 minecraft:light[level=12]
setblock 266 165 360 minecraft:light[level=12]
fill 269 165 322 269 228 322 minecraft:green_terracotta
setblock 270 165 325 minecraft:light[level=15]
setblock 270 165 333 minecraft:light[level=15]
setblock 270 165 341 minecraft:light[level=15]
setblock 270 165 349 minecraft:light[level=15]
setblock 270 165 357 minecraft:light[level=15]
setblock 270 165 363 minecraft:red_mushroom_block
setblock 273 165 325 minecraft:light[level=12]
setblock 273 165 332 minecraft:light[level=12]
setblock 273 165 339 minecraft:light[level=12]
setblock 273 165 346 minecraft:light[level=12]
setblock 273 165 353 minecraft:light[level=12]
setblock 273 165 360 minecraft:light[level=12]
setblock 275 165 336 minecraft:mushroom_stem
fill 275 165 337 275 168 337 minecraft:moss_block
setblock 275 165 341 minecraft:mushroom_stem
fill 275 165 342 275 168 342 minecraft:moss_block
fill 275 165 344 276 165 344 minecraft:moss_block
fill 275 165 363 275 167 363 minecraft:moss_block
setblock 276 165 335 minecraft:mushroom_stem
fill 276 165 336 276 168 336 minecraft:moss_block
setblock 276 165 340 minecraft:mushroom_stem
fill 276 165 341 276 168 341 minecraft:moss_block
setblock 276 165 345 minecraft:mushroom_stem
fill 276 165 346 276 168 346 minecraft:moss_block
fill 276 165 352 276 166 352 minecraft:red_mushroom_block
setblock 276 165 355 minecraft:mushroom_stem
fill 276 165 356 276 168 356 minecraft:moss_block
setblock 276 165 360 minecraft:mushroom_stem
fill 276 165 361 276 168 361 minecraft:moss_block
fill 235 166 349 235 206 349 minecraft:green_terracotta
setblock 236 166 323 minecraft:moss_block
setblock 236 166 324 minecraft:mushroom_stem
fill 236 166 325 236 166 328 minecraft:moss_block
setblock 236 166 329 minecraft:mushroom_stem
fill 236 166 330 236 166 333 minecraft:moss_block
setblock 236 166 334 minecraft:mushroom_stem
fill 236 166 335 236 166 338 minecraft:moss_block
setblock 236 166 339 minecraft:mushroom_stem
fill 236 166 340 236 169 340 minecraft:moss_block
setblock 236 166 344 minecraft:mushroom_stem
fill 236 166 345 236 169 345 minecraft:moss_block
setblock 236 166 359 minecraft:mushroom_stem
fill 236 166 360 236 169 360 minecraft:moss_block
setblock 237 166 323 minecraft:mushroom_stem
fill 237 166 324 237 168 325 minecraft:moss_block
fill 237 166 331 237 166 332 minecraft:moss_block
setblock 237 166 333 minecraft:mushroom_stem
fill 237 166 334 237 169 334 minecraft:moss_block
setblock 237 166 338 minecraft:mushroom_stem
fill 237 166 339 237 169 339 minecraft:moss_block
setblock 237 166 343 minecraft:mushroom_stem
fill 237 166 344 237 169 344 minecraft:moss_block
fill 237 166 361 237 166 362 minecraft:moss_block
setblock 237 166 363 minecraft:mushroom_stem
fill 238 166 323 240 166 324 minecraft:moss_block
setblock 238 166 337 minecraft:mushroom_stem
fill 238 166 338 238 169 338 minecraft:moss_block
setblock 238 166 342 minecraft:mushroom_stem
setblock 238 166 362 minecraft:mushroom_stem
fill 238 166 363 241 166 363 minecraft:moss_block
fill 239 166 362 239 169 362 minecraft:moss_block
setblock 241 166 323 minecraft:moss_block
setblock 241 166 324 minecraft:mushroom_stem
setblock 242 166 323 minecraft:mushroom_stem
fill 242 166 324 242 169 324 minecraft:moss_block
setblock 242 166 363 minecraft:mushroom_stem
fill 243 166 323 243 169 323 minecraft:moss_block
setblock 243 166 362 minecraft:mushroom_stem
fill 243 166 363 246 166 363 minecraft:moss_block
fill 244 166 362 244 169 362 minecraft:moss_block
setblock 246 166 323 minecraft:moss_block
setblock 247 166 323 minecraft:mushroom_stem
setblock 247 166 363 minecraft:mushroom_stem
fill 248 166 323 251 166 323 minecraft:moss_block
fill 248 166 363 251 166 363 minecraft:moss_block
fill 251 166 362 252 166 362 minecraft:moss_block
setblock 252 166 323 minecraft:mushroom_stem
setblock 252 166 363 minecraft:mushroom_stem
fill 253 166 323 256 166 323 minecraft:moss_block
setblock 253 166 362 minecraft:mushroom_stem
fill 253 166 363 256 166 363 minecraft:moss_block
setblock 254 166 361 minecraft:mushroom_stem
fill 254 166 362 257 166 362 minecraft:moss_block
fill 255 166 361 258 166 361 minecraft:moss_block
setblock 257 166 323 minecraft:mushroom_stem
fill 257 166 360 259 166 360 minecraft:moss_block
setblock 257 166 363 minecraft:mushroom_stem
fill 258 166 323 258 169 323 minecraft:moss_block
setblock 258 166 362 minecraft:mushroom_stem
fill 258 166 363 261 166 363 minecraft:moss_block
setblock 259 166 361 minecraft:mushroom_stem
fill 259 166 362 262 166 362 minecraft:moss_block
setblock 260 166 360 minecraft:mushroom_stem
fill 260 166 361 260 169 361 minecraft:moss_block
setblock 261 166 360 minecraft:moss_block
setblock 262 166 323 minecraft:mushroom_stem
setblock 262 166 363 minecraft:mushroom_stem
fill 263 166 323 263 169 323 minecraft:moss_block
setblock 263 166 362 minecraft:mushroom_stem
fill 263 166 363 263 169 363 minecraft:moss_block
fill 264 166 362 264 169 362 minecraft:moss_block
setblock 267 166 322 minecraft:shroomlight
setblock 267 166 363 minecraft:mushroom_stem
fill 268 166 322 268 226 322 minecraft:green_terracotta
setblock 274 166 340 minecraft:moss_block
fill 274 166 363 274 168 363 minecraft:moss_block
setblock 275 166 335 minecraft:mushroom_stem
fill 275 166 336 275 169 336 minecraft:moss_block
setblock 275 166 340 minecraft:mushroom_stem
fill 275 166 341 275 169 341 minecraft:moss_block
setblock 275 166 344 minecraft:moss_block
setblock 275 166 345 minecraft:mushroom_stem
fill 275 166 346 275 169 346 minecraft:moss_block
setblock 276 166 327 minecraft:red_mushroom_block
setblock 276 166 334 minecraft:mushroom_stem
fill 276 166 335 276 169 335 minecraft:moss_block
setblock 276 166 339 minecraft:mushroom_stem
fill 276 166 340 276 169 340 minecraft:moss_block
setblock 276 166 344 minecraft:mushroom_stem
fill 276 166 345 276 169 345 minecraft:moss_block
fill 276 166 347 276 166 348 minecraft:moss_block
setblock 276 166 349 minecraft:mushroom_stem
fill 276 166 350 276 169 350 minecraft:moss_block
fill 276 166 355 276 169 355 minecraft:moss_block
setblock 276 166 359 minecraft:mushroom_stem
fill 276 166 360 276 169 360 minecraft:moss_block
setblock 236 167 323 minecraft:mushroom_stem
fill 236 167 324 236 167 327 minecraft:moss_block
setblock 236 167 328 minecraft:mushroom_stem
fill 236 167 329 236 167 332 minecraft:moss_block
setblock 236 167 333 minecraft:mushroom_stem
fill 236 167 334 236 167 337 minecraft:moss_block
setblock 236 167 338 minecraft:mushroom_stem
fill 236 167 339 236 170 339 minecraft:moss_block
setblock 236 167 343 minecraft:mushroom_stem
fill 236 167 344 236 170 344 minecraft:moss_block
setblock 236 167 347 minecraft:moss_block
setblock 236 167 358 minecraft:mushroom_stem
fill 236 167 359 236 170 359 minecraft:moss_block
setblock 236 167 362 minecraft:moss_block
setblock 236 167 363 minecraft:mushroom_stem
fill 237 167 323 240 167 323 minecraft:moss_block
setblock 237 167 326 minecraft:moss_block
setblock 237 167 327 minecraft:mushroom_stem
fill 237 167 328 237 167 331 minecraft:moss_block
setblock 237 167 332 minecraft:mushroom_stem
fill 237 167 333 237 170 333 minecraft:moss_block
setblock 237 167 337 minecraft:mushroom_stem
fill 237 167 338 237 170 338 minecraft:moss_block
setblock 237 167 342 minecraft:mushroom_stem
fill 237 167 343 238 169 343 minecraft:moss_block
fill 237 167 345 237 168 345 minecraft:moss_block
fill 237 167 360 237 167 361 minecraft:moss_block
setblock 237 167 362 minecraft:mushroom_stem
fill 237 167 363 240 167 363 minecraft:moss_block
fill 238 167 324 239 167 324 minecraft:moss_block
setblock 238 167 336 minecraft:mushroom_stem
fill 238 167 337 238 170 337 minecraft:moss_block
setblock 238 167 341 minecraft:mushroom_stem
fill 238 167 342 238 170 342 minecraft:moss_block
setblock 238 167 356 minecraft:shroomlight
fill 238 167 362 238 170 362 minecraft:moss_block
setblock 240 167 324 minecraft:mushroom_stem
setblock 241 167 323 minecraft:mushroom_stem
fill 241 167 324 241 170 324 minecraft:moss_block
setblock 241 167 363 minecraft:mushroom_stem
fill 242 167 323 242 170 323 minecraft:moss_block
setblock 242 167 362 minecraft:mushroom_stem
fill 242 167 363 245 167 363 minecraft:moss_block
fill 243 167 362 243 169 362 minecraft:moss_block
setblock 244 167 324 minecraft:moss_block
fill 245 167 362 245 168 362 minecraft:moss_block
setblock 246 167 323 minecraft:mushroom_stem
setblock 246 167 363 minecraft:mushroom_stem
fill 247 167 323 250 167 323 minecraft:moss_block
fill 247 167 363 250 167 363 minecraft:moss_block
fill 250 167 362 251 167 362 minecraft:moss_block
setblock 251 167 323 minecraft:mushroom_stem
setblock 251 167 363 minecraft:mushroom_stem
fill 252 167 323 255 167 323 minecraft:moss_block
setblock 252 167 362 minecraft:mushroom_stem
fill 252 167 363 255 167 363 minecraft:moss_block
setblock 253 167 361 minecraft:mushroom_stem
fill 253 167 362 256 167 362 minecraft:moss_block
fill 254 167 361 257 167 361 minecraft:moss_block
setblock 256 167 323 minecraft:mushroom_stem
fill 256 167 324 259 167 324 minecraft:moss_block
setblock 256 167 363 minecraft:mushroom_stem
fill 257 167 323 257 170 323 minecraft:moss_block
fill 257 167 360 258 167 360 minecraft:moss_block
setblock 257 167 362 minecraft:mushroom_stem
fill 257 167 363 260 167 363 minecraft:moss_block
setblock 258 167 361 minecraft:mushroom_stem
fill 258 167 362 261 167 362 minecraft:moss_block
setblock 259 167 360 minecraft:mushroom_stem
fill 259 167 361 259 170 361 minecraft:moss_block
setblock 260 167 360 minecraft:moss_block
setblock 261 167 323 minecraft:mushroom_stem
setblock 261 167 363 minecraft:mushroom_stem
fill 262 167 323 262 170 323 minecraft:moss_block
setblock 262 167 362 minecraft:mushroom_stem
fill 262 167 363 262 170 363 minecraft:moss_block
setblock 263 167 361 minecraft:mushroom_stem
fill 263 167 362 263 170 362 minecraft:moss_block
setblock 266 167 363 minecraft:mushroom_stem
fill 267 167 322 267 228 322 minecraft:green_terracotta
fill 267 167 363 267 170 363 minecraft:moss_block
fill 273 167 363 273 169 363 minecraft:moss_block
setblock 274 167 323 minecraft:red_mushroom_block
setblock 274 167 339 minecraft:moss_block
setblock 274 167 340 minecraft:mushroom_stem
fill 274 167 341 274 168 343 minecraft:moss_block
setblock 275 167 323 minecraft:moss_block
fill 275 167 335 275 170 335 minecraft:moss_block
setblock 275 167 339 minecraft:mushroom_stem
fill 275 167 340 275 170 340 minecraft:moss_block
setblock 275 167 343 minecraft:moss_block
setblock 275 167 344 minecraft:mushroom_stem
fill 275 167 345 275 170 345 minecraft:moss_block
fill 275 167 347 276 167 347 minecraft:moss_block
setblock 276 167 323 minecraft:mushroom_stem
fill 276 167 324 276 169 325 minecraft:moss_block
fill 276 167 331 276 168 331 minecraft:moss_block
setblock 276 167 333 minecraft:mushroom_stem
fill 276 167 334 276 170 334 minecraft:moss_block
setblock 276 167 338 minecraft:mushroom_stem
fill 276 167 339 276 170 339 minecraft:moss_block
setblock 276 167 343 minecraft:mushroom_stem
fill 276 167 344 276 170 344 minecraft:moss_block
setblock 276 167 348 minecraft:mushroom_stem
fill 276 167 349 276 170 349 minecraft:moss_block
fill 276 167 351 276 168 351 minecraft:moss_block
setblock 276 167 358 minecraft:mushroom_stem
fill 276 167 359 276 170 359 minecraft:moss_block
setblock 276 167 362 minecraft:moss_block
setblock 276 167 363 minecraft:mushroom_stem
fill 236 168 323 236 168 326 minecraft:moss_block
setblock 236 168 327 minecraft:mushroom_stem
fill 236 168 328 236 168 331 minecraft:moss_block
setblock 236 168 332 minecraft:mushroom_stem
fill 236 168 333 236 168 336 minecraft:moss_block
setblock 236 168 337 minecraft:mushroom_stem
fill 236 168 338 236 171 338 minecraft:moss_block
setblock 236 168 342 minecraft:mushroom_stem
fill 236 168 343 236 171 343 minecraft:moss_block
setblock 236 168 347 minecraft:mushroom_stem
fill 236 168 348 236 171 348 minecraft:moss_block
setblock 236 168 352 minecraft:red_mushroom_block
setblock 236 168 357 minecraft:mushroom_stem
fill 236 168 358 236 171 358 minecraft:moss_block
setblock 236 168 362 minecraft:mushroom_stem
fill 236 168 363 239 168 363 minecraft:moss_block
fill 237 168 323 239 168 323 minecraft:moss_block
setblock 237 168 326 minecraft:mushroom_stem
fill 237 168 327 237 168 330 minecraft:moss_block
setblock 237 168 331 minecraft:mushroom_stem
fill 237 168 332 237 171 332 minecraft:moss_block
setblock 237 168 336 minecraft:mushroom_stem
fill 237 168 337 237 171 337 minecraft:moss_block
setblock 237 168 341 minecraft:mushroom_stem
fill 237 168 342 237 171 342 minecraft:moss_block
setblock 237 168 346 minecraft:mushroom_stem
setblock 237 168 360 minecraft:moss_block
setblock 237 168 361 minecraft:mushroom_stem
fill 237 168 362 237 171 362 minecraft:moss_block
setblock 238 168 324 minecraft:moss_block
setblock 238 168 325 minecraft:mushroom_stem
fill 238 168 326 238 171 326 minecraft:moss_block
setblock 238 168 335 minecraft:mushroom_stem
fill 238 168 336 238 170 336 minecraft:moss_block
setblock 238 168 340 minecraft:mushroom_stem
fill 238 168 341 238 171 341 minecraft:moss_block
fill 238 168 356 238 172 356 minecraft:mushroom_stem
setblock 239 168 324 minecraft:mushroom_stem
fill 239 168 325 240 170 325 minecraft:moss_block
setblock 240 168 323 minecraft:mushroom_stem
fill 240 168 324 240 171 324 minecraft:moss_block
setblock 240 168 363 minecraft:mushroom_stem
fill 241 168 323 241 171 323 minecraft:moss_block
setblock 241 168 362 minecraft:mushroom_stem
fill 241 168 363 244 168 363 minecraft:moss_block
fill 242 168 362 242 169 362 minecraft:moss_block
setblock 244 168 324 minecraft:mushroom_stem
fill 244 168 350 244 169 350 minecraft:shroomlight
setblock 245 168 323 minecraft:mushroom_stem
fill 245 168 324 245 171 324 minecraft:moss_block
setblock 245 168 363 minecraft:mushroom_stem
fill 246 168 323 249 168 323 minecraft:moss_block
setblock 246 168 362 minecraft:mushroom_stem
fill 246 168 363 249 168 363 minecraft:moss_block
fill 248 168 362 250 168 362 minecraft:moss_block
setblock 250 168 323 minecraft:mushroom_stem
setblock 250 168 363 minecraft:mushroom_stem
fill 251 168 323 254 168 323 minecraft:moss_block
setblock 251 168 362 minecraft:mushroom_stem
fill 251 168 363 254 168 363 minecraft:moss_block
fill 252 168 362 255 168 362 minecraft:moss_block
setblock 253 168 324 minecraft:moss_block
fill 253 168 361 256 168 361 minecraft:moss_block
setblock 254 168 324 minecraft:mushroom_stem
setblock 255 168 323 minecraft:mushroom_stem
fill 255 168 324 258 168 324 minecraft:moss_block
setblock 255 168 363 minecraft:mushroom_stem
fill 256 168 323 256 171 323 minecraft:moss_block
fill 256 168 360 257 168 360 minecraft:moss_block
setblock 256 168 362 minecraft:mushroom_stem
fill 256 168 363 259 168 363 minecraft:moss_block
setblock 257 168 361 minecraft:mushroom_stem
fill 257 168 362 260 168 362 minecraft:moss_block
setblock 258 168 360 minecraft:mushroom_stem
fill 258 168 361 258 171 361 minecraft:moss_block
setblock 259 168 324 minecraft:mushroom_stem
fill 259 168 360 259 170 360 minecraft:moss_block
setblock 260 168 322 minecraft:red_mushroom_block
setblock 260 168 323 minecraft:mushroom_stem
fill 260 168 324 260 171 324 minecraft:moss_block
setblock 260 168 363 minecraft:mushroom_stem
fill 261 168 323 261 171 323 minecraft:moss_block
setblock 261 168 362 minecraft:mushroom_stem
fill 261 168 363 261 171 363 minecraft:moss_block
setblock 262 168 361 minecraft:mushroom_stem
fill 262 168 362 262 171 362 minecraft:moss_block
setblock 265 168 363 minecraft:mushroom_stem
fill 266 168 363 266 171 363 minecraft:moss_block
setblock 268 168 323 minecraft:red_mushroom_block
setblock 269 168 363 minecraft:red_mushroom_block
fill 271 168 363 272 170 363 minecraft:moss_block
setblock 274 168 323 minecraft:moss_block
setblock 274 168 338 minecraft:moss_block
setblock 274 168 339 minecraft:mushroom_stem
fill 274 168 340 274 171 340 minecraft:moss_block
setblock 274 168 344 minecraft:mushroom_stem
fill 274 168 345 274 171 345 minecraft:moss_block
setblock 275 168 323 minecraft:mushroom_stem
fill 275 168 334 275 171 334 minecraft:moss_block
setblock 275 168 338 minecraft:mushroom_stem
fill 275 168 339 275 171 339 minecraft:moss_block
setblock 275 168 343 minecraft:mushroom_stem
fill 275 168 344 275 171 344 minecraft:moss_block
setblock 275 168 347 minecraft:moss_block
setblock 275 168 348 minecraft:mushroom_stem
setblock 275 168 363 minecraft:mushroom_stem
fill 276 168 323 276 171 323 minecraft:moss_block
setblock 276 168 326 minecraft:moss_block
setblock 276 168 327 minecraft:mushroom_stem
fill 276 168 328 276 169 330 minecraft:moss_block
setblock 276 168 332 minecraft:mushroom_stem
fill 276 168 333 276 171 333 minecraft:moss_block
setblock 276 168 337 minecraft:mushroom_stem
fill 276 168 338 276 171 338 minecraft:moss_block
setblock 276 168 342 minecraft:mushroom_stem
fill 276 168 343 276 171 343 minecraft:moss_block
setblock 276 168 347 minecraft:mushroom_stem
fill 276 168 348 276 171 348 minecraft:moss_block
setblock 276 168 352 minecraft:mushroom_stem
fill 276 168 353 276 170 354 minecraft:moss_block
setblock 276 168 357 minecraft:mushroom_stem
fill 276 168 358 276 171 358 minecraft:moss_block
setblock 276 168 362 minecraft:mushroom_stem
fill 276 168 363 276 171 363 minecraft:moss_block
fill 236 169 323 236 169 325 minecraft:moss_block
setblock 236 169 326 minecraft:mushroom_stem
fill 236 169 327 236 169 330 minecraft:moss_block
setblock 236 169 331 minecraft:mushroom_stem
fill 236 169 332 236 169 335 minecraft:moss_block
setblock 236 169 336 minecraft:mushroom_stem
fill 236 169 337 236 172 337 minecraft:moss_block
setblock 236 169 341 minecraft:mushroom_stem
fill 236 169 342 236 172 342 minecraft:moss_block
setblock 236 169 346 minecraft:mushroom_stem
fill 236 169 347 237 171 347 minecraft:moss_block
fill 236 169 349 236 170 349 minecraft:moss_block
fill 236 169 357 236 172 357 minecraft:moss_block
setblock 236 169 361 minecraft:mushroom_stem
fill 236 169 362 236 171 363 minecraft:moss_block
fill 237 169 323 237 169 324 minecraft:moss_block
setblock 237 169 325 minecraft:mushroom_stem
fill 237 169 326 237 169 329 minecraft:moss_block
setblock 237 169 330 minecraft:mushroom_stem
fill 237 169 331 237 172 331 minecraft:moss_block
setblock 237 169 335 minecraft:mushroom_stem
fill 237 169 336 237 172 336 minecraft:moss_block
setblock 237 169 340 minecraft:mushroom_stem
fill 237 169 341 237 172 341 minecraft:moss_block
setblock 237 169 345 minecraft:mushroom_stem
fill 237 169 346 237 172 346 minecraft:moss_block
setblock 237 169 359 minecraft:moss_block
setblock 237 169 360 minecraft:mushroom_stem
fill 237 169 361 237 172 361 minecraft:moss_block
fill 237 169 363 238 169 363 minecraft:moss_block
setblock 238 169 323 minecraft:moss_block
setblock 238 169 324 minecraft:mushroom_stem
fill 238 169 325 238 172 325 minecraft:moss_block
fill 238 169 327 238 169 328 minecraft:moss_block
setblock 238 169 335 minecraft:moss_block
setblock 238 169 339 minecraft:mushroom_stem
fill 238 169 340 238 172 340 minecraft:moss_block
setblock 238 169 344 minecraft:mushroom_stem
setblock 239 169 323 minecraft:mushroom_stem
fill 239 169 324 239 172 324 minecraft:moss_block
setblock 239 169 363 minecraft:mushroom_stem
fill 240 169 323 240 172 323 minecraft:moss_block
setblock 240 169 362 minecraft:mushroom_stem
fill 240 169 363 243 169 363 minecraft:moss_block
setblock 241 169 325 minecraft:moss_block
setblock 241 169 362 minecraft:moss_block
setblock 243 169 324 minecraft:mushroom_stem
setblock 244 169 323 minecraft:mushroom_stem
fill 244 169 324 244 172 324 minecraft:moss_block
setblock 244 169 363 minecraft:mushroom_stem
fill 245 169 323 248 169 323 minecraft:moss_block
setblock 245 169 362 minecraft:mushroom_stem
fill 245 169 363 248 169 363 minecraft:moss_block
fill 246 169 324 246 170 324 minecraft:moss_block
fill 246 169 362 249 169 362 minecraft:moss_block
fill 247 169 336 251 171 338 minecraft:mushroom_stem
fill 248 169 335 250 215 335 minecraft:mushroom_stem
fill 248 169 339 250 171 339 minecraft:mushroom_stem
setblock 249 169 323 minecraft:mushroom_stem
setblock 249 169 363 minecraft:mushroom_stem
fill 250 169 323 252 169 324 minecraft:moss_block
setblock 250 169 362 minecraft:mushroom_stem
fill 250 169 363 253 169 363 minecraft:moss_block
fill 251 169 362 254 169 362 minecraft:moss_block
fill 252 169 361 255 169 361 minecraft:moss_block
setblock 253 169 323 minecraft:moss_block
setblock 253 169 324 minecraft:mushroom_stem
setblock 254 169 323 minecraft:mushroom_stem
fill 254 169 324 257 169 324 minecraft:moss_block
setblock 254 169 363 minecraft:mushroom_stem
fill 255 169 323 255 172 323 minecraft:moss_block
fill 255 169 360 256 169 360 minecraft:moss_block
setblock 255 169 362 minecraft:mushroom_stem
fill 255 169 363 258 169 363 minecraft:moss_block
fill 256 169 322 257 169 322 minecraft:green_terracotta
setblock 256 169 361 minecraft:mushroom_stem
fill 256 169 362 259 169 362 minecraft:moss_block
setblock 257 169 360 minecraft:mushroom_stem
fill 257 169 361 257 172 361 minecraft:moss_block
setblock 258 169 322 minecraft:red_mushroom_block
setblock 258 169 324 minecraft:mushroom_stem
fill 258 169 360 258 171 360 minecraft:moss_block
fill 259 169 322 260 176 322 minecraft:green_terracotta
setblock 259 169 323 minecraft:mushroom_stem
fill 259 169 324 259 172 324 minecraft:moss_block
setblock 259 169 363 minecraft:mushroom_stem
fill 260 169 323 260 172 323 minecraft:moss_block
setblock 260 169 362 minecraft:mushroom_stem
fill 260 169 363 260 172 363 minecraft:moss_block
setblock 261 169 361 minecraft:mushroom_stem
fill 261 169 362 261 172 362 minecraft:moss_block
fill 262 169 361 262 170 361 minecraft:moss_block
setblock 264 169 322 minecraft:shroomlight
setblock 264 169 363 minecraft:mushroom_stem
fill 265 169 363 265 172 363 minecraft:moss_block
setblock 268 169 363 minecraft:moss_block
setblock 269 169 363 minecraft:mushroom_stem
fill 270 169 363 270 172 363 minecraft:moss_block
fill 272 169 323 273 169 323 minecraft:moss_block
setblock 274 169 323 minecraft:mushroom_stem
setblock 274 169 337 minecraft:moss_block
setblock 274 169 338 minecraft:mushroom_stem
fill 274 169 339 274 172 339 minecraft:moss_block
fill 274 169 341 274 169 342 minecraft:moss_block
setblock 274 169 343 minecraft:mushroom_stem
fill 274 169 344 274 172 344 minecraft:moss_block
fill 274 169 346 274 170 346 minecraft:moss_block
setblock 274 169 362 minecraft:moss_block
setblock 274 169 363 minecraft:mushroom_stem
fill 275 169 323 275 171 324 minecraft:moss_block
setblock 275 169 337 minecraft:mushroom_stem
fill 275 169 338 275 172 338 minecraft:moss_block
setblock 275 169 342 minecraft:mushroom_stem
fill 275 169 343 275 172 343 minecraft:moss_block
setblock 275 169 347 minecraft:mushroom_stem
fill 275 169 348 275 171 349 minecraft:moss_block
setblock 275 169 361 minecraft:moss_block
setblock 275 169 362 minecraft:mushroom_stem
fill 275 169 363 275 172 363 minecraft:moss_block
setblock 276 169 326 minecraft:mushroom_stem
fill 276 169 327 276 172 327 minecraft:moss_block
setblock 276 169 331 minecraft:mushroom_stem
fill 276 169 332 276 172 332 minecraft:moss_block
setblock 276 169 336 minecraft:mushroom_stem
fill 276 169 337 276 172 337 minecraft:moss_block
setblock 276 169 341 minecraft:mushroom_stem
fill 276 169 342 276 172 342 minecraft:moss_block
setblock 276 169 346 minecraft:mushroom_stem
fill 276 169 347 276 172 347 minecraft:moss_block
setblock 276 169 351 minecraft:mushroom_stem
fill 276 169 352 276 172 352 minecraft:moss_block
setblock 276 169 356 minecraft:mushroom_stem
fill 276 169 357 276 172 357 minecraft:moss_block
setblock 276 169 361 minecraft:mushroom_stem
fill 276 169 362 276 172 362 minecraft:moss_block
fill 236 170 323 236 170 324 minecraft:moss_block
setblock 236 170 325 minecraft:mushroom_stem
fill 236 170 326 236 170 329 minecraft:moss_block
setblock 236 170 330 minecraft:mushroom_stem
fill 236 170 331 236 170 334 minecraft:moss_block
setblock 236 170 335 minecraft:mushroom_stem
fill 236 170 336 236 173 336 minecraft:moss_block
setblock 236 170 340 minecraft:mushroom_stem
fill 236 170 341 236 173 341 minecraft:moss_block
setblock 236 170 345 minecraft:mushroom_stem
fill 236 170 346 236 173 346 minecraft:moss_block
setblock 236 170 350 minecraft:mushroom_stem
fill 236 170 351 236 173 351 minecraft:moss_block
setblock 236 170 360 minecraft:mushroom_stem
fill 236 170 361 236 173 361 minecraft:moss_block
setblock 237 170 323 minecraft:moss_block
setblock 237 170 324 minecraft:mushroom_stem
fill 237 170 325 237 170 328 minecraft:moss_block
setblock 237 170 329 minecraft:mushroom_stem
fill 237 170 330 237 173 330 minecraft:moss_block
setblock 237 170 334 minecraft:mushroom_stem
fill 237 170 335 237 173 335 minecraft:moss_block
setblock 237 170 339 minecraft:mushroom_stem
fill 237 170 340 237 173 340 minecraft:moss_block
setblock 237 170 343 minecraft:moss_block
setblock 237 170 344 minecraft:mushroom_stem
fill 237 170 345 238 172 345 minecraft:moss_block
setblock 237 170 348 minecraft:moss_block
setblock 237 170 359 minecraft:mushroom_stem
fill 237 170 360 237 173 360 minecraft:moss_block
setblock 237 170 363 minecraft:moss_block
setblock 238 170 323 minecraft:mushroom_stem
fill 238 170 324 238 173 324 minecraft:moss_block
setblock 238 170 327 minecraft:moss_block
setblock 238 170 328 minecraft:mushroom_stem
fill 238 170 329 238 173 329 minecraft:moss_block
setblock 238 170 338 minecraft:mushroom_stem
fill 238 170 339 238 172 339 minecraft:moss_block
setblock 238 170 343 minecraft:mushroom_stem
fill 238 170 344 238 173 344 minecraft:moss_block
setblock 238 170 363 minecraft:mushroom_stem
setblock 238 170 364 minecraft:shroomlight
fill 239 170 323 239 173 323 minecraft:moss_block
fill 239 170 342 239 175 342 minecraft:dirt
fill 239 170 360 243 170 362 minecraft:red_mushroom_block
fill 239 170 363 239 173 363 minecraft:moss_block
fill 240 170 359 242 170 359 minecraft:red_mushroom_block
fill 240 170 363 242 170 363 minecraft:red_mushroom_block
setblock 241 170 325 minecraft:mushroom_stem
setblock 242 170 324 minecraft:mushroom_stem
fill 242 170 325 242 173 325 minecraft:moss_block
setblock 243 170 323 minecraft:mushroom_stem
fill 243 170 324 243 173 324 minecraft:moss_block
setblock 243 170 363 minecraft:mushroom_stem
fill 244 170 323 247 170 323 minecraft:moss_block
fill 244 170 350 244 180 350 minecraft:dirt
setblock 244 170 362 minecraft:mushroom_stem
fill 244 170 363 247 170 363 minecraft:moss_block
fill 245 170 362 248 170 362 minecraft:moss_block
fill 246 170 336 246 171 338 minecraft:dirt
setblock 247 170 324 minecraft:mushroom_stem
fill 247 170 335 247 171 335 minecraft:dirt
fill 247 170 339 247 171 339 minecraft:dirt
setblock 248 170 323 minecraft:mushroom_stem
fill 248 170 324 251 170 324 minecraft:moss_block
fill 248 170 334 250 171 334 minecraft:dirt
fill 248 170 340 250 170 340 minecraft:dirt
setblock 248 170 363 minecraft:mushroom_stem
fill 249 170 323 252 170 323 minecraft:moss_block
setblock 249 170 362 minecraft:mushroom_stem
fill 249 170 363 252 170 363 minecraft:moss_block
fill 250 170 362 253 170 362 minecraft:moss_block
fill 251 170 335 251 171 335 minecraft:dirt
setblock 251 170 339 minecraft:dirt
fill 251 170 361 254 170 361 minecraft:moss_block
setblock 252 170 324 minecraft:mushroom_stem
fill 252 170 336 252 171 338 minecraft:dirt
setblock 253 170 323 minecraft:mushroom_stem
fill 253 170 324 256 170 324 minecraft:moss_block
setblock 253 170 363 minecraft:mushroom_stem
fill 254 170 323 254 173 323 minecraft:moss_block
setblock 254 170 362 minecraft:mushroom_stem
fill 254 170 363 257 170 363 minecraft:moss_block
setblock 255 170 360 minecraft:moss_block
setblock 255 170 361 minecraft:mushroom_stem
fill 255 170 362 258 170 362 minecraft:moss_block
setblock 256 170 322 minecraft:shroomlight
setblock 256 170 360 minecraft:mushroom_stem
fill 256 170 361 256 173 361 minecraft:moss_block
fill 256 170 364 258 226 364 minecraft:green_terracotta
fill 257 170 322 258 228 322 minecraft:green_terracotta
setblock 257 170 324 minecraft:mushroom_stem
fill 257 170 360 257 172 360 minecraft:moss_block
setblock 258 170 323 minecraft:mushroom_stem
fill 258 170 324 258 173 324 minecraft:moss_block
setblock 258 170 363 minecraft:mushroom_stem
fill 259 170 323 259 173 323 minecraft:moss_block
setblock 259 170 362 minecraft:mushroom_stem
fill 259 170 363 259 173 363 minecraft:moss_block
setblock 259 170 364 minecraft:shroomlight
setblock 260 170 361 minecraft:mushroom_stem
fill 260 170 362 260 173 362 minecraft:moss_block
setblock 261 170 324 minecraft:moss_block
fill 261 170 361 261 171 361 minecraft:moss_block
setblock 263 170 323 minecraft:mushroom_stem
setblock 263 170 363 minecraft:mushroom_stem
fill 264 170 322 264 173 322 minecraft:green_terracotta
fill 264 170 323 264 173 323 minecraft:moss_block
setblock 264 170 362 minecraft:mushroom_stem
fill 264 170 363 264 173 363 minecraft:moss_block
setblock 268 170 363 minecraft:mushroom_stem
fill 269 170 334 270 173 338 minecraft:red_mushroom_block
fill 269 170 363 269 173 363 minecraft:moss_block
fill 271 170 323 272 170 323 minecraft:moss_block
fill 271 170 334 273 173 335 minecraft:red_mushroom_block
setblock 271 170 336 minecraft:mushroom_stem
fill 271 170 337 273 173 338 minecraft:red_mushroom_block
fill 272 170 336 273 173 336 minecraft:red_mushroom_block
setblock 273 170 323 minecraft:mushroom_stem
fill 273 170 324 274 172 324 minecraft:moss_block
fill 273 170 341 273 170 342 minecraft:moss_block
setblock 273 170 343 minecraft:mushroom_stem
fill 273 170 344 273 173 344 minecraft:moss_block
setblock 273 170 362 minecraft:moss_block
setblock 273 170 363 minecraft:mushroom_stem
fill 274 170 323 274 173 323 minecraft:moss_block
setblock 274 170 337 minecraft:mushroom_stem
fill 274 170 338 274 173 338 minecraft:moss_block
setblock 274 170 341 minecraft:moss_block
setblock 274 170 342 minecraft:mushroom_stem
fill 274 170 343 274 173 343 minecraft:moss_block
setblock 274 170 347 minecraft:mushroom_stem
fill 274 170 348 274 173 348 minecraft:moss_block
setblock 274 170 362 minecraft:mushroom_stem
fill 274 170 363 274 173 363 minecraft:moss_block
setblock 275 170 325 minecraft:moss_block
setblock 275 170 326 minecraft:mushroom_stem
fill 275 170 327 275 171 329 minecraft:moss_block
setblock 275 170 331 minecraft:mushroom_stem
fill 275 170 332 275 172 333 minecraft:moss_block
setblock 275 170 336 minecraft:mushroom_stem
fill 275 170 337 275 173 337 minecraft:moss_block
setblock 275 170 341 minecraft:mushroom_stem
fill 275 170 342 275 173 342 minecraft:moss_block
setblock 275 170 346 minecraft:mushroom_stem
fill 275 170 347 275 173 347 minecraft:moss_block
setblock 275 170 350 minecraft:moss_block
setblock 275 170 360 minecraft:moss_block
setblock 275 170 361 minecraft:mushroom_stem
fill 275 170 362 275 173 362 minecraft:moss_block
setblock 276 170 324 minecraft:moss_block
setblock 276 170 325 minecraft:mushroom_stem
fill 276 170 326 276 173 326 minecraft:moss_block
fill 276 170 328 276 170 329 minecraft:moss_block
setblock 276 170 330 minecraft:mushroom_stem
fill 276 170 331 276 173 331 minecraft:moss_block
setblock 276 170 335 minecraft:mushroom_stem
fill 276 170 336 276 173 336 minecraft:moss_block
setblock 276 170 340 minecraft:mushroom_stem
fill 276 170 341 276 173 341 minecraft:moss_block
setblock 276 170 345 minecraft:mushroom_stem
fill 276 170 346 276 173 346 minecraft:moss_block
setblock 276 170 350 minecraft:mushroom_stem
fill 276 170 351 276 173 351 minecraft:moss_block
setblock 276 170 355 minecraft:mushroom_stem
fill 276 170 356 276 173 356 minecraft:moss_block
setblock 276 170 360 minecraft:mushroom_stem
fill 276 170 361 276 173 361 minecraft:moss_block
setblock 236 171 323 minecraft:moss_block
setblock 236 171 324 minecraft:mushroom_stem
fill 236 171 325 236 171 328 minecraft:moss_block
setblock 236 171 329 minecraft:mushroom_stem
fill 236 171 330 236 171 333 minecraft:moss_block
setblock 236 171 334 minecraft:mushroom_stem
fill 236 171 335 236 174 335 minecraft:moss_block
setblock 236 171 339 minecraft:mushroom_stem
fill 236 171 340 236 174 340 minecraft:moss_block
setblock 236 171 344 minecraft:mushroom_stem
fill 236 171 345 236 174 345 minecraft:moss_block
setblock 236 171 349 minecraft:mushroom_stem
fill 236 171 350 236 174 350 minecraft:moss_block
fill 236 171 352 236 172 352 minecraft:moss_block
fill 236 171 356 236 172 356 minecraft:moss_block
setblock 236 171 359 minecraft:mushroom_stem
fill 236 171 360 236 174 360 minecraft:moss_block
setblock 237 171 323 minecraft:mushroom_stem
fill 237 171 324 237 171 327 minecraft:moss_block
setblock 237 171 328 minecraft:mushroom_stem
fill 237 171 329 237 174 329 minecraft:moss_block
setblock 237 171 333 minecraft:mushroom_stem
fill 237 171 334 237 174 334 minecraft:moss_block
setblock 237 171 338 minecraft:mushroom_stem
fill 237 171 339 237 174 339 minecraft:moss_block
setblock 237 171 343 minecraft:mushroom_stem
fill 237 171 344 237 174 344 minecraft:moss_block
setblock 237 171 348 minecraft:mushroom_stem
fill 237 171 349 237 174 349 minecraft:moss_block
setblock 237 171 359 minecraft:moss_block
setblock 237 171 363 minecraft:mushroom_stem
fill 238 171 323 238 174 323 minecraft:moss_block
setblock 238 171 327 minecraft:mushroom_stem
fill 238 171 328 238 174 328 minecraft:moss_block
fill 238 171 330 238 172 330 minecraft:moss_block
setblock 238 171 332 minecraft:light[level=12]
setblock 238 171 337 minecraft:mushroom_stem
setblock 238 171 338 minecraft:moss_block
setblock 238 171 342 minecraft:mushroom_stem
fill 238 171 343 238 173 343 minecraft:moss_block
setblock 238 171 346 minecraft:light[level=12]
setblock 238 171 353 minecraft:light[level=12]
setblock 238 171 360 minecraft:light[level=12]
setblock 238 171 362 minecraft:mushroom_stem
fill 238 171 363 238 174 363 minecraft:moss_block
fill 238 171 364 238 177 364 minecraft:green_terracotta
setblock 239 171 325 minecraft:moss_block
setblock 239 171 326 minecraft:mushroom_stem
fill 239 171 362 242 171 362 minecraft:moss_block
setblock 240 171 325 minecraft:mushroom_stem
fill 240 171 363 241 171 363 minecraft:moss_block
setblock 241 171 324 minecraft:mushroom_stem
fill 241 171 325 241 174 325 minecraft:moss_block
setblock 242 171 323 minecraft:mushroom_stem
fill 242 171 324 242 174 324 minecraft:moss_block
setblock 242 171 363 minecraft:mushroom_stem
fill 243 171 323 246 171 323 minecraft:moss_block
fill 243 171 325 243 172 325 minecraft:moss_block
setblock 243 171 362 minecraft:mushroom_stem
fill 243 171 363 246 171 363 minecraft:moss_block
fill 244 171 362 247 171 362 minecraft:moss_block
setblock 245 171 325 minecraft:light[level=12]
setblock 245 171 332 minecraft:light[level=12]
fill 245 171 335 245 171 339 minecraft:dirt
setblock 245 171 346 minecraft:light[level=12]
setblock 245 171 353 minecraft:light[level=12]
setblock 245 171 360 minecraft:light[level=12]
setblock 246 171 324 minecraft:mushroom_stem
fill 246 171 334 246 171 335 minecraft:dirt
fill 246 171 339 246 171 340 minecraft:dirt
setblock 247 171 323 minecraft:mushroom_stem
fill 247 171 324 250 171 324 minecraft:moss_block
fill 247 171 333 247 171 334 minecraft:dirt
fill 247 171 340 248 171 341 minecraft:dirt
setblock 247 171 363 minecraft:mushroom_stem
fill 248 171 323 251 171 323 minecraft:moss_block
fill 248 171 333 250 171 333 minecraft:dirt
setblock 248 171 362 minecraft:mushroom_stem
fill 248 171 363 251 171 363 minecraft:moss_block
fill 249 171 340 253 215 341 minecraft:mushroom_stem
fill 249 171 362 252 171 362 minecraft:moss_block
fill 250 171 342 253 215 342 minecraft:mushroom_stem
setblock 251 171 324 minecraft:mushroom_stem
fill 251 171 334 252 171 334 minecraft:dirt
fill 251 171 339 252 215 339 minecraft:mushroom_stem
fill 251 171 343 252 215 343 minecraft:mushroom_stem
fill 251 171 361 253 171 361 minecraft:moss_block
setblock 252 171 323 minecraft:mushroom_stem
fill 252 171 324 255 171 324 minecraft:moss_block
setblock 252 171 325 minecraft:light[level=12]
setblock 252 171 332 minecraft:light[level=12]
setblock 252 171 335 minecraft:dirt
setblock 252 171 346 minecraft:light[level=12]
setblock 252 171 353 minecraft:light[level=12]
setblock 252 171 360 minecraft:light[level=12]
setblock 252 171 363 minecraft:mushroom_stem
fill 253 171 323 253 174 323 minecraft:moss_block
fill 253 171 325 254 171 325 minecraft:moss_block
fill 253 171 336 253 171 338 minecraft:dirt
setblock 253 171 362 minecraft:mushroom_stem
fill 253 171 363 256 171 363 minecraft:moss_block
setblock 254 171 360 minecraft:moss_block
setblock 254 171 361 minecraft:mushroom_stem
fill 254 171 362 257 171 362 minecraft:moss_block
setblock 255 171 325 minecraft:mushroom_stem
setblock 255 171 360 minecraft:mushroom_stem
fill 255 171 361 255 174 361 minecraft:moss_block
fill 256 171 322 256 228 322 minecraft:green_terracotta
setblock 256 171 324 minecraft:mushroom_stem
fill 256 171 325 257 173 325 minecraft:moss_block
fill 256 171 360 256 172 360 minecraft:moss_block
setblock 257 171 323 minecraft:mushroom_stem
fill 257 171 324 257 174 324 minecraft:moss_block
setblock 257 171 363 minecraft:mushroom_stem
fill 258 171 323 258 174 323 minecraft:moss_block
setblock 258 171 362 minecraft:mushroom_stem
fill 258 171 363 258 174 363 minecraft:moss_block
setblock 259 171 325 minecraft:light[level=12]
setblock 259 171 332 minecraft:light[level=12]
setblock 259 171 339 minecraft:light[level=12]
setblock 259 171 346 minecraft:light[level=12]
setblock 259 171 353 minecraft:light[level=12]
setblock 259 171 360 minecraft:light[level=12]
setblock 259 171 361 minecraft:mushroom_stem
fill 259 171 362 259 174 362 minecraft:moss_block
fill 259 171 364 259 226 364 minecraft:green_terracotta
fill 260 171 361 260 172 361 minecraft:moss_block
setblock 261 171 324 minecraft:mushroom_stem
setblock 262 171 323 minecraft:mushroom_stem
setblock 262 171 363 minecraft:mushroom_stem
fill 263 171 323 263 174 323 minecraft:moss_block
setblock 263 171 362 minecraft:mushroom_stem
fill 263 171 363 263 174 363 minecraft:moss_block
setblock 266 171 325 minecraft:light[level=12]
setblock 266 171 332 minecraft:light[level=12]
setblock 266 171 339 minecraft:light[level=12]
setblock 266 171 346 minecraft:light[level=12]
setblock 266 171 353 minecraft:light[level=12]
setblock 266 171 360 minecraft:light[level=12]
setblock 267 171 363 minecraft:mushroom_stem
fill 268 171 335 268 172 337 minecraft:red_mushroom_block
fill 268 171 363 268 173 363 minecraft:moss_block
fill 269 171 323 271 171 323 minecraft:moss_block
fill 270 171 333 272 172 333 minecraft:red_mushroom_block
fill 270 171 339 272 172 339 minecraft:red_mushroom_block
fill 271 171 336 271 174 336 minecraft:red_mushroom_block
setblock 271 171 363 minecraft:moss_block
setblock 272 171 323 minecraft:mushroom_stem
fill 272 171 324 272 174 324 minecraft:moss_block
setblock 272 171 363 minecraft:mushroom_stem
fill 273 171 323 273 174 323 minecraft:moss_block
setblock 273 171 325 minecraft:light[level=12]
setblock 273 171 332 minecraft:light[level=12]
setblock 273 171 339 minecraft:light[level=12]
fill 273 171 340 273 171 341 minecraft:moss_block
setblock 273 171 342 minecraft:mushroom_stem
fill 273 171 343 273 174 343 minecraft:moss_block
fill 273 171 345 273 171 346 minecraft:moss_block
setblock 273 171 353 minecraft:light[level=12]
setblock 273 171 360 minecraft:light[level=12]
setblock 273 171 362 minecraft:mushroom_stem
fill 273 171 363 273 174 363 minecraft:moss_block
fill 274 171 335 274 172 335 minecraft:red_mushroom_block
setblock 274 171 336 minecraft:mushroom_stem
fill 274 171 337 274 174 337 minecraft:moss_block
setblock 274 171 341 minecraft:mushroom_stem
fill 274 171 342 274 174 342 minecraft:moss_block
setblock 274 171 346 minecraft:mushroom_stem
fill 274 171 347 274 174 347 minecraft:moss_block
fill 274 171 349 274 172 349 minecraft:moss_block
fill 274 171 362 274 174 362 minecraft:moss_block
setblock 275 171 325 minecraft:mushroom_stem
fill 275 171 326 275 174 326 minecraft:moss_block
setblock 275 171 330 minecraft:mushroom_stem
fill 275 171 331 275 174 331 minecraft:moss_block
setblock 275 171 335 minecraft:mushroom_stem
fill 275 171 336 275 174 336 minecraft:moss_block
setblock 275 171 340 minecraft:mushroom_stem
fill 275 171 341 275 174 341 minecraft:moss_block
setblock 275 171 345 minecraft:mushroom_stem
fill 275 171 346 275 174 346 minecraft:moss_block
setblock 275 171 350 minecraft:mushroom_stem
fill 275 171 351 275 174 351 minecraft:moss_block
setblock 275 171 360 minecraft:mushroom_stem
fill 275 171 361 275 173 361 minecraft:moss_block
setblock 276 171 324 minecraft:mushroom_stem
fill 276 171 325 276 174 325 minecraft:moss_block
setblock 276 171 328 minecraft:moss_block
setblock 276 171 329 minecraft:mushroom_stem
fill 276 171 330 276 174 330 minecraft:moss_block
setblock 276 171 334 minecraft:mushroom_stem
fill 276 171 335 276 174 335 minecraft:moss_block
setblock 276 171 339 minecraft:mushroom_stem
fill 276 171 340 276 174 340 minecraft:moss_block
setblock 276 171 344 minecraft:mushroom_stem
fill 276 171 345 276 174 345 minecraft:moss_block
setblock 276 171 349 minecraft:mushroom_stem
fill 276 171 350 276 174 350 minecraft:moss_block
setblock 276 171 353 minecraft:moss_block
setblock 276 171 354 minecraft:mushroom_stem
fill 276 171 355 276 174 355 minecraft:moss_block
setblock 276 171 359 minecraft:mushroom_stem
fill 276 171 360 276 174 360 minecraft:moss_block
fill 235 172 337 235 229 337 minecraft:green_terracotta
setblock 235 172 338 minecraft:shroomlight
fill 235 172 339 235 196 341 minecraft:green_terracotta
setblock 236 172 323 minecraft:mushroom_stem
fill 236 172 324 236 172 327 minecraft:moss_block
setblock 236 172 328 minecraft:mushroom_stem
fill 236 172 329 236 172 332 minecraft:moss_block
setblock 236 172 333 minecraft:mushroom_stem
fill 236 172 334 236 175 334 minecraft:moss_block
setblock 236 172 338 minecraft:mushroom_stem
fill 236 172 339 236 175 339 minecraft:moss_block
setblock 236 172 343 minecraft:mushroom_stem
fill 236 172 344 236 175 344 minecraft:moss_block
setblock 236 172 347 minecraft:moss_block
setblock 236 172 348 minecraft:mushroom_stem
fill 236 172 349 236 175 349 minecraft:moss_block
setblock 236 172 353 minecraft:mushroom_stem
fill 236 172 354 236 172 355 minecraft:moss_block
setblock 236 172 358 minecraft:mushroom_stem
fill 236 172 359 236 175 359 minecraft:moss_block
setblock 236 172 362 minecraft:moss_block
setblock 236 172 363 minecraft:mushroom_stem
fill 237 172 323 237 172 326 minecraft:moss_block
setblock 237 172 327 minecraft:mushroom_stem
fill 237 172 328 237 175 328 minecraft:moss_block
setblock 237 172 332 minecraft:mushroom_stem
fill 237 172 333 237 175 333 minecraft:moss_block
setblock 237 172 337 minecraft:mushroom_stem
fill 237 172 338 237 174 338 minecraft:moss_block
setblock 237 172 342 minecraft:mushroom_stem
fill 237 172 343 237 175 343 minecraft:moss_block
setblock 237 172 347 minecraft:mushroom_stem
fill 237 172 348 237 175 348 minecraft:moss_block
setblock 237 172 362 minecraft:mushroom_stem
fill 237 172 363 237 175 363 minecraft:moss_block
setblock 238 172 326 minecraft:mushroom_stem
fill 238 172 327 239 174 327 minecraft:moss_block
setblock 238 172 331 minecraft:mushroom_stem
setblock 238 172 341 minecraft:mushroom_stem
fill 238 172 342 238 173 342 minecraft:moss_block
setblock 238 172 346 minecraft:mushroom_stem
fill 238 172 362 241 172 362 minecraft:moss_block
setblock 239 172 325 minecraft:mushroom_stem
fill 239 172 326 239 175 326 minecraft:moss_block
setblock 240 172 324 minecraft:mushroom_stem
fill 240 172 325 240 175 325 minecraft:moss_block
setblock 240 172 363 minecraft:moss_block
setblock 241 172 323 minecraft:mushroom_stem
fill 241 172 324 241 175 324 minecraft:moss_block
setblock 241 172 363 minecraft:mushroom_stem
fill 242 172 323 245 172 323 minecraft:moss_block
setblock 242 172 362 minecraft:mushroom_stem
fill 242 172 363 245 172 363 minecraft:moss_block
fill 243 172 350 243 180 350 minecraft:dirt
fill 243 172 362 246 172 362 minecraft:moss_block
fill 244 172 351 245 180 351 minecraft:dirt
setblock 245 172 324 minecraft:mushroom_stem
fill 245 172 350 245 180 350 minecraft:dirt
setblock 246 172 323 minecraft:mushroom_stem
fill 246 172 324 249 172 324 minecraft:moss_block
setblock 246 172 363 minecraft:mushroom_stem
fill 247 172 323 250 172 323 minecraft:moss_block
fill 247 172 336 249 172 338 minecraft:mushroom_stem
setblock 247 172 362 minecraft:mushroom_stem
fill 247 172 363 250 172 363 minecraft:moss_block
setblock 248 172 339 minecraft:mushroom_stem
fill 248 172 340 248 173 341 minecraft:dirt
fill 248 172 362 251 172 362 minecraft:moss_block
fill 249 172 339 249 173 339 minecraft:dirt
fill 249 172 342 249 173 343 minecraft:dirt
setblock 250 172 324 minecraft:mushroom_stem
fill 250 172 336 251 172 337 minecraft:mushroom_stem
fill 250 172 338 253 173 338 minecraft:dirt
fill 250 172 339 250 215 339 minecraft:mushroom_stem
fill 250 172 343 250 173 343 minecraft:dirt
fill 250 172 361 252 172 361 minecraft:moss_block
setblock 251 172 323 minecraft:mushroom_stem
fill 251 172 324 253 172 325 minecraft:moss_block
setblock 251 172 363 minecraft:mushroom_stem
fill 252 172 323 252 175 323 minecraft:moss_block
fill 252 172 344 252 173 344 minecraft:dirt
setblock 252 172 362 minecraft:mushroom_stem
fill 252 172 363 255 172 363 minecraft:moss_block
fill 253 172 339 254 173 339 minecraft:dirt
fill 253 172 343 253 173 343 minecraft:dirt
setblock 253 172 361 minecraft:mushroom_stem
fill 253 172 362 256 172 362 minecraft:moss_block
setblock 254 172 324 minecraft:moss_block
setblock 254 172 325 minecraft:mushroom_stem
fill 254 172 340 254 173 342 minecraft:dirt
setblock 254 172 360 minecraft:mushroom_stem
fill 254 172 361 254 175 361 minecraft:moss_block
setblock 255 172 324 minecraft:mushroom_stem
fill 255 172 325 255 175 325 minecraft:moss_block
setblock 255 172 360 minecraft:moss_block
setblock 256 172 323 minecraft:mushroom_stem
fill 256 172 324 256 175 324 minecraft:moss_block
setblock 256 172 363 minecraft:mushroom_stem
fill 257 172 323 257 175 323 minecraft:moss_block
setblock 257 172 362 minecraft:mushroom_stem
fill 257 172 363 257 175 363 minecraft:moss_block
setblock 258 172 325 minecraft:moss_block
setblock 258 172 361 minecraft:mushroom_stem
fill 258 172 362 258 175 362 minecraft:moss_block
fill 259 172 361 259 173 361 minecraft:moss_block
setblock 260 172 324 minecraft:mushroom_stem
setblock 261 172 323 minecraft:mushroom_stem
fill 261 172 324 261 173 324 minecraft:moss_block
setblock 261 172 363 minecraft:mushroom_stem
fill 262 172 323 262 175 323 minecraft:moss_block
setblock 262 172 362 minecraft:mushroom_stem
fill 262 172 363 262 175 363 minecraft:moss_block
setblock 263 172 362 minecraft:moss_block
setblock 265 172 323 minecraft:moss_block
setblock 266 172 323 minecraft:mushroom_stem
setblock 266 172 363 minecraft:mushroom_stem
fill 267 172 323 270 172 323 minecraft:moss_block
fill 267 172 363 267 173 363 minecraft:moss_block
setblock 271 172 323 minecraft:mushroom_stem
fill 271 172 324 271 175 324 minecraft:moss_block
setblock 271 172 363 minecraft:mushroom_stem
fill 272 172 323 272 175 323 minecraft:moss_block
fill 272 172 363 272 175 363 minecraft:moss_block
setblock 273 172 325 minecraft:moss_block
setblock 273 172 340 minecraft:moss_block
setblock 273 172 341 minecraft:mushroom_stem
fill 273 172 342 273 175 342 minecraft:moss_block
setblock 273 172 345 minecraft:moss_block
setblock 273 172 346 minecraft:mushroom_stem
fill 273 172 347 273 175 347 minecraft:moss_block
fill 273 172 362 273 173 362 minecraft:moss_block
setblock 274 172 325 minecraft:mushroom_stem
fill 274 172 326 274 174 327 minecraft:moss_block
fill 274 172 336 274 175 336 minecraft:moss_block
setblock 274 172 340 minecraft:mushroom_stem
fill 274 172 341 274 175 341 minecraft:moss_block
setblock 274 172 345 minecraft:mushroom_stem
fill 274 172 346 274 175 346 minecraft:moss_block
setblock 274 172 350 minecraft:mushroom_stem
setblock 275 172 323 minecraft:moss_block
setblock 275 172 324 minecraft:mushroom_stem
fill 275 172 325 275 175 325 minecraft:moss_block
fill 275 172 327 275 172 328 minecraft:moss_block
setblock 275 172 329 minecraft:mushroom_stem
fill 275 172 330 275 175 330 minecraft:moss_block
setblock 275 172 334 minecraft:mushroom_stem
fill 275 172 335 275 175 335 minecraft:moss_block
setblock 275 172 339 minecraft:mushroom_stem
fill 275 172 340 275 175 340 minecraft:moss_block
setblock 275 172 344 minecraft:mushroom_stem
fill 275 172 345 275 175 345 minecraft:moss_block
setblock 275 172 348 minecraft:moss_block
setblock 275 172 349 minecraft:mushroom_stem
fill 275 172 350 275 175 350 minecraft:moss_block
fill 275 172 352 275 173 352 minecraft:moss_block
setblock 275 172 360 minecraft:moss_block
setblock 276 172 323 minecraft:mushroom_stem
fill 276 172 324 276 175 324 minecraft:moss_block
setblock 276 172 328 minecraft:mushroom_stem
fill 276 172 329 276 175 329 minecraft:moss_block
setblock 276 172 333 minecraft:mushroom_stem
fill 276 172 334 276 175 334 minecraft:moss_block
setblock 276 172 338 minecraft:mushroom_stem
fill 276 172 339 276 175 339 minecraft:moss_block
setblock 276 172 343 minecraft:mushroom_stem
fill 276 172 344 276 175 344 minecraft:moss_block
setblock 276 172 348 minecraft:mushroom_stem
fill 276 172 349 276 175 349 minecraft:moss_block
setblock 276 172 353 minecraft:mushroom_stem
fill 276 172 354 276 175 354 minecraft:moss_block
setblock 276 172 358 minecraft:mushroom_stem
fill 276 172 359 276 174 359 minecraft:moss_block
setblock 276 172 363 minecraft:mushroom_stem
fill 235 173 338 235 228 338 minecraft:green_terracotta
fill 236 173 323 236 173 326 minecraft:moss_block
setblock 236 173 327 minecraft:mushroom_stem
fill 236 173 328 236 173 331 minecraft:moss_block
setblock 236 173 332 minecraft:mushroom_stem
fill 236 173 333 236 176 333 minecraft:moss_block
setblock 236 173 337 minecraft:mushroom_stem
fill 236 173 338 236 176 338 minecraft:moss_block
setblock 236 173 342 minecraft:mushroom_stem
fill 236 173 343 236 176 343 minecraft:moss_block
setblock 236 173 347 minecraft:mushroom_stem
fill 236 173 348 236 176 348 minecraft:moss_block
setblock 236 173 352 minecraft:mushroom_stem
fill 236 173 353 236 175 354 minecraft:moss_block
fill 236 173 355 240 173 357 minecraft:red_mushroom_block
fill 236 173 358 236 175 358 minecraft:moss_block
setblock 236 173 362 minecraft:mushroom_stem
fill 236 173 363 236 176 363 minecraft:moss_block
fill 237 173 323 237 173 325 minecraft:moss_block
setblock 237 173 326 minecraft:mushroom_stem
fill 237 173 327 237 176 327 minecraft:moss_block
setblock 237 173 331 minecraft:mushroom_stem
fill 237 173 332 237 176 332 minecraft:moss_block
setblock 237 173 336 minecraft:mushroom_stem
fill 237 173 337 237 174 337 minecraft:moss_block
setblock 237 173 341 minecraft:mushroom_stem
fill 237 173 342 237 175 342 minecraft:moss_block
setblock 237 173 345 minecraft:moss_block
setblock 237 173 346 minecraft:mushroom_stem
fill 237 173 347 237 176 347 minecraft:moss_block
setblock 237 173 350 minecraft:moss_block
fill 237 173 354 239 173 354 minecraft:red_mushroom_block
fill 237 173 358 239 173 358 minecraft:red_mushroom_block
setblock 237 173 361 minecraft:mushroom_stem
fill 237 173 362 240 173 362 minecraft:moss_block
setblock 238 173 325 minecraft:mushroom_stem
fill 238 173 326 238 176 326 minecraft:moss_block
setblock 238 173 330 minecraft:mushroom_stem
setblock 238 173 331 minecraft:moss_block
setblock 238 173 333 minecraft:light[level=15]
setblock 238 173 341 minecraft:light[level=15]
setblock 238 173 345 minecraft:mushroom_stem
setblock 238 173 349 minecraft:light[level=15]
setblock 239 173 324 minecraft:mushroom_stem
fill 239 173 325 239 176 325 minecraft:moss_block
setblock 240 173 323 minecraft:mushroom_stem
fill 240 173 324 240 176 324 minecraft:moss_block
setblock 240 173 326 minecraft:moss_block
setblock 240 173 363 minecraft:mushroom_stem
fill 241 173 323 244 173 323 minecraft:moss_block
setblock 241 173 362 minecraft:mushroom_stem
fill 241 173 363 244 173 363 minecraft:moss_block
fill 242 173 362 245 173 362 minecraft:moss_block
setblock 243 173 325 minecraft:mushroom_stem
fill 243 173 351 243 180 351 minecraft:dirt
setblock 244 173 324 minecraft:mushroom_stem
fill 244 173 349 245 180 349 minecraft:dirt
setblock 245 173 323 minecraft:mushroom_stem
fill 245 173 324 248 173 324 minecraft:moss_block
setblock 245 173 363 minecraft:mushroom_stem
fill 246 173 323 249 173 323 minecraft:moss_block
setblock 246 173 325 minecraft:light[level=15]
setblock 246 173 333 minecraft:light[level=15]
setblock 246 173 341 minecraft:light[level=15]
setblock 246 173 349 minecraft:light[level=15]
setblock 246 173 357 minecraft:light[level=15]
setblock 246 173 362 minecraft:mushroom_stem
fill 246 173 363 249 173 363 minecraft:moss_block
fill 247 173 336 247 215 338 minecraft:mushroom_stem
fill 247 173 340 247 173 341 minecraft:dirt
fill 247 173 362 250 173 362 minecraft:moss_block
fill 248 173 336 249 211 337 minecraft:mushroom_stem
fill 248 173 338 248 173 339 minecraft:dirt
fill 248 173 342 248 173 343 minecraft:dirt
setblock 249 173 324 minecraft:mushroom_stem
fill 249 173 325 252 173 325 minecraft:moss_block
setblock 249 173 338 minecraft:dirt
setblock 250 173 323 minecraft:mushroom_stem
fill 250 173 324 253 173 324 minecraft:moss_block
fill 250 173 336 251 215 336 minecraft:mushroom_stem
fill 250 173 337 253 173 337 minecraft:dirt
fill 250 173 361 251 173 361 minecraft:moss_block
setblock 250 173 363 minecraft:mushroom_stem
fill 251 173 323 251 176 323 minecraft:moss_block
setblock 251 173 362 minecraft:mushroom_stem
fill 251 173 363 254 173 363 minecraft:moss_block
setblock 252 173 361 minecraft:mushroom_stem
fill 252 173 362 255 173 362 minecraft:moss_block
fill 253 173 322 253 174 322 minecraft:red_mushroom_block
setblock 253 173 325 minecraft:mushroom_stem
fill 253 173 344 254 173 344 minecraft:dirt
fill 253 173 361 253 176 361 minecraft:moss_block
setblock 254 173 324 minecraft:mushroom_stem
fill 254 173 325 254 176 325 minecraft:moss_block
setblock 254 173 333 minecraft:light[level=15]
setblock 254 173 338 minecraft:dirt
setblock 254 173 343 minecraft:dirt
setblock 254 173 349 minecraft:light[level=15]
setblock 254 173 357 minecraft:light[level=15]
setblock 255 173 323 minecraft:mushroom_stem
fill 255 173 324 255 176 324 minecraft:moss_block
fill 255 173 339 255 173 342 minecraft:dirt
setblock 255 173 363 minecraft:mushroom_stem
fill 256 173 323 256 176 323 minecraft:moss_block
setblock 256 173 362 minecraft:mushroom_stem
fill 256 173 363 256 176 363 minecraft:moss_block
setblock 257 173 361 minecraft:mushroom_stem
fill 257 173 362 257 176 362 minecraft:moss_block
setblock 258 173 325 minecraft:mushroom_stem
fill 258 173 361 258 174 361 minecraft:moss_block
setblock 259 173 324 minecraft:mushroom_stem
setblock 260 173 323 minecraft:mushroom_stem
fill 260 173 324 260 174 324 minecraft:moss_block
setblock 260 173 363 minecraft:mushroom_stem
fill 261 173 323 261 175 323 minecraft:moss_block
setblock 261 173 362 minecraft:mushroom_stem
fill 261 173 363 261 175 363 minecraft:moss_block
setblock 262 173 325 minecraft:light[level=15]
setblock 262 173 333 minecraft:light[level=15]
setblock 262 173 341 minecraft:light[level=15]
setblock 262 173 349 minecraft:light[level=15]
setblock 262 173 357 minecraft:light[level=15]
setblock 262 173 362 minecraft:moss_block
setblock 265 173 323 minecraft:mushroom_stem
setblock 265 173 363 minecraft:mushroom_stem
fill 266 173 323 269 173 323 minecraft:moss_block
setblock 266 173 363 minecraft:moss_block
setblock 270 173 323 minecraft:mushroom_stem
fill 270 173 324 270 176 324 minecraft:moss_block
setblock 270 173 325 minecraft:light[level=15]
setblock 270 173 333 minecraft:light[level=15]
setblock 270 173 341 minecraft:light[level=15]
setblock 270 173 349 minecraft:light[level=15]
setblock 270 173 357 minecraft:light[level=15]
setblock 270 173 363 minecraft:mushroom_stem
fill 271 173 323 271 176 323 minecraft:moss_block
fill 271 173 363 271 176 363 minecraft:moss_block
setblock 272 173 325 minecraft:moss_block
setblock 273 173 324 minecraft:moss_block
setblock 273 173 325 minecraft:mushroom_stem
setblock 273 173 340 minecraft:mushroom_stem
fill 273 173 341 273 175 341 minecraft:moss_block
setblock 273 173 345 minecraft:mushroom_stem
fill 273 173 346 273 176 346 minecraft:moss_block
fill 273 173 348 273 174 348 minecraft:moss_block
setblock 274 173 324 minecraft:mushroom_stem
fill 274 173 325 274 176 325 minecraft:moss_block
setblock 274 173 328 minecraft:moss_block
setblock 274 173 329 minecraft:mushroom_stem
fill 274 173 330 274 176 330 minecraft:moss_block
fill 274 173 335 274 174 335 minecraft:moss_block
setblock 274 173 339 minecraft:mushroom_stem
fill 274 173 340 274 176 340 minecraft:moss_block
setblock 274 173 344 minecraft:mushroom_stem
fill 274 173 345 274 176 345 minecraft:moss_block
setblock 274 173 349 minecraft:mushroom_stem
fill 274 173 350 274 176 350 minecraft:moss_block
setblock 275 173 323 minecraft:mushroom_stem
fill 275 173 324 275 176 324 minecraft:moss_block
setblock 275 173 327 minecraft:moss_block
setblock 275 173 328 minecraft:mushroom_stem
fill 275 173 329 275 176 329 minecraft:moss_block
setblock 275 173 332 minecraft:moss_block
setblock 275 173 333 minecraft:mushroom_stem
fill 275 173 334 275 176 334 minecraft:moss_block
setblock 275 173 338 minecraft:mushroom_stem
fill 275 173 339 275 176 339 minecraft:moss_block
setblock 275 173 343 minecraft:mushroom_stem
fill 275 173 344 275 176 344 minecraft:moss_block
setblock 275 173 348 minecraft:mushroom_stem
fill 275 173 349 275 176 349 minecraft:moss_block
setblock 275 173 353 minecraft:mushroom_stem
setblock 275 173 363 minecraft:mushroom_stem
fill 276 173 323 276 176 323 minecraft:moss_block
setblock 276 173 327 minecraft:mushroom_stem
fill 276 173 328 276 176 328 minecraft:moss_block
setblock 276 173 332 minecraft:mushroom_stem
fill 276 173 333 276 176 333 minecraft:moss_block
setblock 276 173 337 minecraft:mushroom_stem
fill 276 173 338 276 176 338 minecraft:moss_block
setblock 276 173 342 minecraft:mushroom_stem
fill 276 173 343 276 176 343 minecraft:moss_block
setblock 276 173 347 minecraft:mushroom_stem
fill 276 173 348 276 176 348 minecraft:moss_block
setblock 276 173 352 minecraft:mushroom_stem
fill 276 173 353 276 176 353 minecraft:moss_block
setblock 276 173 357 minecraft:mushroom_stem
fill 276 173 358 276 174 358 minecraft:moss_block
setblock 276 173 362 minecraft:mushroom_stem
fill 276 173 363 276 176 363 minecraft:moss_block
fill 236 174 323 236 174 325 minecraft:moss_block
setblock 236 174 326 minecraft:mushroom_stem
fill 236 174 327 236 174 330 minecraft:moss_block
setblock 236 174 331 minecraft:mushroom_stem
fill 236 174 332 236 177 332 minecraft:moss_block
setblock 236 174 336 minecraft:mushroom_stem
fill 236 174 337 236 177 337 minecraft:moss_block
setblock 236 174 341 minecraft:mushroom_stem
fill 236 174 342 236 177 342 minecraft:moss_block
setblock 236 174 346 minecraft:mushroom_stem
fill 236 174 347 236 177 347 minecraft:moss_block
setblock 236 174 351 minecraft:mushroom_stem
fill 236 174 352 236 177 352 minecraft:moss_block
setblock 236 174 355 minecraft:moss_block
setblock 236 174 356 minecraft:mushroom_stem
setblock 236 174 357 minecraft:moss_block
setblock 236 174 361 minecraft:mushroom_stem
fill 236 174 362 239 174 362 minecraft:moss_block
fill 237 174 323 237 174 324 minecraft:moss_block
setblock 237 174 325 minecraft:mushroom_stem
fill 237 174 326 237 177 326 minecraft:moss_block
setblock 237 174 330 minecraft:mushroom_stem
fill 237 174 331 237 177 331 minecraft:moss_block
setblock 237 174 335 minecraft:mushroom_stem
setblock 237 174 336 minecraft:moss_block
setblock 237 174 340 minecraft:mushroom_stem
fill 237 174 341 237 175 341 minecraft:moss_block
setblock 237 174 345 minecraft:mushroom_stem
fill 237 174 346 237 176 346 minecraft:moss_block
setblock 237 174 350 minecraft:mushroom_stem
setblock 237 174 361 minecraft:moss_block
setblock 238 174 324 minecraft:mushroom_stem
fill 238 174 325 238 177 325 minecraft:moss_block
setblock 238 174 329 minecraft:mushroom_stem
fill 238 174 330 238 175 330 minecraft:moss_block
fill 238 174 342 238 175 342 minecraft:dirt
setblock 239 174 323 minecraft:mushroom_stem
fill 239 174 324 239 177 324 minecraft:moss_block
fill 239 174 341 239 175 341 minecraft:dirt
fill 239 174 343 239 175 343 minecraft:dirt
setblock 239 174 363 minecraft:mushroom_stem
fill 240 174 323 243 174 323 minecraft:moss_block
fill 240 174 342 240 175 342 minecraft:dirt
setblock 240 174 362 minecraft:mushroom_stem
fill 240 174 363 243 174 363 minecraft:moss_block
setblock 241 174 362 minecraft:moss_block
setblock 242 174 325 minecraft:mushroom_stem
fill 242 174 350 242 180 350 minecraft:dirt
setblock 243 174 324 minecraft:mushroom_stem
setblock 243 174 325 minecraft:moss_block
fill 243 174 349 243 180 349 minecraft:dirt
fill 243 174 352 245 180 352 minecraft:dirt
setblock 244 174 323 minecraft:mushroom_stem
fill 244 174 324 247 174 324 minecraft:moss_block
setblock 244 174 363 minecraft:mushroom_stem
fill 245 174 323 248 174 323 minecraft:moss_block
fill 245 174 363 248 174 363 minecraft:moss_block
fill 246 174 349 246 180 351 minecraft:dirt
fill 246 174 362 249 174 362 minecraft:moss_block
setblock 248 174 324 minecraft:mushroom_stem
fill 248 174 338 249 211 339 minecraft:mushroom_stem
setblock 249 174 323 minecraft:mushroom_stem
fill 249 174 324 251 174 325 minecraft:moss_block
setblock 249 174 363 minecraft:mushroom_stem
fill 250 174 323 250 177 323 minecraft:moss_block
fill 250 174 337 251 211 338 minecraft:mushroom_stem
setblock 250 174 361 minecraft:moss_block
setblock 250 174 362 minecraft:mushroom_stem
fill 250 174 363 253 174 363 minecraft:moss_block
setblock 251 174 361 minecraft:mushroom_stem
fill 251 174 362 254 174 362 minecraft:moss_block
setblock 252 174 324 minecraft:moss_block
setblock 252 174 325 minecraft:mushroom_stem
fill 252 174 361 252 176 361 minecraft:moss_block
setblock 253 174 324 minecraft:mushroom_stem
fill 253 174 325 253 177 325 minecraft:moss_block
setblock 254 174 323 minecraft:mushroom_stem
fill 254 174 324 254 177 324 minecraft:moss_block
setblock 254 174 363 minecraft:mushroom_stem
fill 255 174 323 255 177 323 minecraft:moss_block
setblock 255 174 362 minecraft:mushroom_stem
fill 255 174 363 255 177 363 minecraft:moss_block
setblock 256 174 325 minecraft:moss_block
setblock 256 174 361 minecraft:mushroom_stem
fill 256 174 362 256 177 362 minecraft:moss_block
setblock 257 174 325 minecraft:mushroom_stem
setblock 257 174 361 minecraft:moss_block
setblock 258 174 324 minecraft:mushroom_stem
setblock 259 174 323 minecraft:mushroom_stem
fill 259 174 324 259 175 324 minecraft:moss_block
setblock 259 174 363 minecraft:mushroom_stem
fill 260 174 323 260 176 323 minecraft:moss_block
setblock 260 174 362 minecraft:mushroom_stem
fill 260 174 363 260 176 363 minecraft:moss_block
setblock 264 174 322 minecraft:shroomlight
setblock 264 174 363 minecraft:mushroom_stem
fill 266 174 323 268 174 323 minecraft:moss_block
setblock 269 174 323 minecraft:mushroom_stem
setblock 269 174 363 minecraft:mushroom_stem
fill 270 174 323 270 177 323 minecraft:moss_block
fill 270 174 363 270 175 363 minecraft:moss_block
setblock 272 174 325 minecraft:mushroom_stem
setblock 273 174 324 minecraft:mushroom_stem
fill 273 174 325 273 177 325 minecraft:moss_block
setblock 273 174 340 minecraft:moss_block
setblock 273 174 344 minecraft:mushroom_stem
fill 273 174 345 273 176 345 minecraft:moss_block
setblock 274 174 323 minecraft:mushroom_stem
fill 274 174 324 274 177 324 minecraft:moss_block
setblock 274 174 328 minecraft:mushroom_stem
fill 274 174 329 274 177 329 minecraft:moss_block
fill 274 174 331 274 174 332 minecraft:moss_block
setblock 274 174 333 minecraft:mushroom_stem
setblock 274 174 338 minecraft:mushroom_stem
fill 274 174 339 274 176 339 minecraft:moss_block
setblock 274 174 343 minecraft:mushroom_stem
fill 274 174 344 274 177 344 minecraft:moss_block
setblock 274 174 348 minecraft:mushroom_stem
fill 274 174 349 274 177 349 minecraft:moss_block
setblock 274 174 363 minecraft:mushroom_stem
fill 275 174 323 275 177 323 minecraft:moss_block
setblock 275 174 327 minecraft:mushroom_stem
fill 275 174 328 275 177 328 minecraft:moss_block
setblock 275 174 332 minecraft:mushroom_stem
fill 275 174 333 275 177 333 minecraft:moss_block
setblock 275 174 337 minecraft:mushroom_stem
fill 275 174 338 275 177 338 minecraft:moss_block
setblock 275 174 342 minecraft:mushroom_stem
fill 275 174 343 275 177 343 minecraft:moss_block
setblock 275 174 347 minecraft:mushroom_stem
fill 275 174 348 275 177 348 minecraft:moss_block
setblock 275 174 352 minecraft:mushroom_stem
setblock 275 174 353 minecraft:moss_block
setblock 275 174 362 minecraft:mushroom_stem
fill 275 174 363 275 177 363 minecraft:moss_block
setblock 276 174 326 minecraft:mushroom_stem
fill 276 174 327 276 177 327 minecraft:moss_block
setblock 276 174 331 minecraft:mushroom_stem
fill 276 174 332 276 177 332 minecraft:moss_block
setblock 276 174 336 minecraft:mushroom_stem
fill 276 174 337 276 177 337 minecraft:moss_block
setblock 276 174 341 minecraft:mushroom_stem
fill 276 174 342 276 177 342 minecraft:moss_block
setblock 276 174 346 minecraft:mushroom_stem
fill 276 174 347 276 177 347 minecraft:moss_block
setblock 276 174 351 minecraft:mushroom_stem
fill 276 174 352 276 177 352 minecraft:moss_block
setblock 276 174 356 minecraft:mushroom_stem
setblock 276 174 357 minecraft:moss_block
setblock 276 174 361 minecraft:mushroom_stem
fill 276 174 362 276 176 362 minecraft:moss_block
fill 236 175 323 236 175 324 minecraft:moss_block
setblock 236 175 325 minecraft:mushroom_stem
fill 236 175 326 236 175 329 minecraft:moss_block
setblock 236 175 330 minecraft:mushroom_stem
fill 236 175 331 236 178 331 minecraft:moss_block
setblock 236 175 335 minecraft:mushroom_stem
fill 236 175 336 236 177 336 minecraft:moss_block
setblock 236 175 340 minecraft:mushroom_stem
fill 236 175 341 236 177 341 minecraft:moss_block
setblock 236 175 345 minecraft:mushroom_stem
fill 236 175 346 236 178 346 minecraft:moss_block
setblock 236 175 350 minecraft:mushroom_stem
fill 236 175 351 236 178 351 minecraft:moss_block
setblock 236 175 360 minecraft:mushroom_stem
fill 236 175 361 236 177 362 minecraft:moss_block
setblock 237 175 323 minecraft:moss_block
setblock 237 175 324 minecraft:mushroom_stem
fill 237 175 325 237 178 325 minecraft:moss_block
setblock 237 175 329 minecraft:mushroom_stem
fill 237 175 330 237 178 330 minecraft:moss_block
setblock 237 175 334 minecraft:mushroom_stem
setblock 237 175 340 minecraft:moss_block
setblock 237 175 344 minecraft:mushroom_stem
fill 237 175 345 237 176 345 minecraft:moss_block
setblock 237 175 349 minecraft:mushroom_stem
fill 237 175 362 238 175 362 minecraft:moss_block
setblock 238 175 323 minecraft:mushroom_stem
fill 238 175 324 238 178 324 minecraft:moss_block
setblock 238 175 327 minecraft:moss_block
setblock 238 175 328 minecraft:mushroom_stem
fill 238 175 329 238 177 329 minecraft:moss_block
setblock 238 175 363 minecraft:mushroom_stem
fill 239 175 323 242 175 323 minecraft:moss_block
fill 239 175 363 242 175 363 minecraft:moss_block
setblock 241 175 325 minecraft:mushroom_stem
setblock 242 175 324 minecraft:mushroom_stem
setblock 242 175 325 minecraft:moss_block
fill 242 175 349 242 180 349 minecraft:dirt
fill 242 175 351 242 180 351 minecraft:dirt
setblock 243 175 323 minecraft:mushroom_stem
fill 243 175 324 246 175 324 minecraft:moss_block
fill 243 175 348 245 180 348 minecraft:dirt
setblock 243 175 363 minecraft:mushroom_stem
fill 244 175 323 247 175 323 minecraft:moss_block
fill 244 175 363 247 175 363 minecraft:moss_block
fill 246 175 352 246 180 352 minecraft:dirt
setblock 247 175 324 minecraft:mushroom_stem
fill 247 175 362 248 175 362 minecraft:moss_block
setblock 248 175 323 minecraft:mushroom_stem
fill 248 175 324 251 175 324 minecraft:moss_block
setblock 248 175 363 minecraft:mushroom_stem
fill 249 175 323 249 178 323 minecraft:moss_block
fill 249 175 325 250 175 325 minecraft:moss_block
setblock 249 175 362 minecraft:mushroom_stem
fill 249 175 363 252 175 363 minecraft:moss_block
fill 250 175 362 253 175 362 minecraft:moss_block
setblock 251 175 325 minecraft:mushroom_stem
setblock 251 175 361 minecraft:moss_block
setblock 252 175 324 minecraft:mushroom_stem
fill 252 175 325 252 177 325 minecraft:moss_block
fill 253 175 322 253 185 322 minecraft:green_terracotta
setblock 253 175 323 minecraft:mushroom_stem
fill 253 175 324 253 178 324 minecraft:moss_block
setblock 253 175 363 minecraft:mushroom_stem
fill 254 175 323 254 178 323 minecraft:moss_block
setblock 254 175 362 minecraft:mushroom_stem
fill 254 175 363 254 178 363 minecraft:moss_block
setblock 255 175 361 minecraft:mushroom_stem
fill 255 175 362 255 177 362 minecraft:moss_block
setblock 256 175 325 minecraft:mushroom_stem
setblock 256 175 361 minecraft:moss_block
setblock 257 175 324 minecraft:mushroom_stem
setblock 258 175 323 minecraft:mushroom_stem
fill 258 175 324 258 176 324 minecraft:moss_block
setblock 258 175 363 minecraft:mushroom_stem
fill 259 175 323 259 176 323 minecraft:moss_block
setblock 259 175 362 minecraft:mushroom_stem
fill 259 175 363 259 176 363 minecraft:moss_block
fill 264 175 322 264 225 322 minecraft:green_terracotta
setblock 264 175 323 minecraft:red_mushroom_block
setblock 267 175 323 minecraft:moss_block
setblock 267 175 363 minecraft:red_mushroom_block
setblock 268 175 323 minecraft:mushroom_stem
fill 269 175 323 269 176 324 minecraft:moss_block
setblock 271 175 325 minecraft:mushroom_stem
setblock 272 175 324 minecraft:mushroom_stem
fill 272 175 325 272 178 325 minecraft:moss_block
setblock 273 175 323 minecraft:mushroom_stem
fill 273 175 324 273 178 324 minecraft:moss_block
setblock 273 175 343 minecraft:mushroom_stem
fill 273 175 344 273 176 344 minecraft:moss_block
setblock 273 175 348 minecraft:mushroom_stem
setblock 273 175 363 minecraft:mushroom_stem
fill 274 175 323 274 178 323 minecraft:moss_block
setblock 274 175 326 minecraft:moss_block
setblock 274 175 327 minecraft:mushroom_stem
fill 274 175 328 274 178 328 minecraft:moss_block
setblock 274 175 331 minecraft:moss_block
setblock 274 175 332 minecraft:mushroom_stem
fill 274 175 333 274 178 333 minecraft:moss_block
setblock 274 175 337 minecraft:mushroom_stem
setblock 274 175 338 minecraft:moss_block
setblock 274 175 342 minecraft:mushroom_stem
fill 274 175 343 274 177 343 minecraft:moss_block
setblock 274 175 347 minecraft:mushroom_stem
fill 274 175 348 274 178 348 minecraft:moss_block
setblock 274 175 351 minecraft:moss_block
fill 274 175 363 274 177 363 minecraft:moss_block
setblock 275 175 326 minecraft:mushroom_stem
fill 275 175 327 275 178 327 minecraft:moss_block
schedule function dropper:buildpart/77_5 1t
