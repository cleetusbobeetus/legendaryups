setblock 87 142 626 minecraft:sea_lantern
fill 87 142 627 87 149 627 minecraft:light_gray_concrete
setblock 87 142 628 minecraft:sea_lantern
fill 87 142 629 87 149 629 minecraft:light_gray_concrete
setblock 87 142 630 minecraft:sea_lantern
fill 88 142 618 88 149 618 minecraft:light_gray_concrete
setblock 88 142 619 minecraft:sea_lantern
fill 88 142 620 88 149 620 minecraft:light_gray_concrete
setblock 88 142 621 minecraft:sea_lantern
fill 88 142 622 88 184 622 minecraft:light_gray_concrete
setblock 88 142 623 minecraft:sea_lantern
fill 88 142 624 88 149 624 minecraft:light_gray_concrete
setblock 88 142 625 minecraft:sea_lantern
fill 88 142 626 88 149 626 minecraft:light_gray_concrete
setblock 88 142 627 minecraft:sea_lantern
fill 88 142 628 88 149 628 minecraft:light_gray_concrete
setblock 88 142 629 minecraft:sea_lantern
fill 88 142 630 88 184 630 minecraft:light_gray_concrete
fill 70 143 639 70 144 639 minecraft:light_gray_concrete
fill 70 143 641 70 144 641 minecraft:light_gray_concrete
fill 70 143 643 70 144 643 minecraft:light_gray_concrete
fill 70 143 645 70 144 645 minecraft:light_gray_concrete
fill 71 143 638 71 144 638 minecraft:light_gray_concrete
fill 71 143 640 71 144 640 minecraft:light_gray_concrete
fill 71 143 642 71 144 642 minecraft:light_gray_concrete
fill 71 143 644 71 144 644 minecraft:light_gray_concrete
fill 72 143 639 72 144 639 minecraft:light_gray_concrete
fill 72 143 641 72 144 641 minecraft:light_gray_concrete
fill 72 143 643 72 144 643 minecraft:light_gray_concrete
fill 72 143 645 72 144 645 minecraft:light_gray_concrete
fill 73 143 638 73 144 638 minecraft:light_gray_concrete
fill 73 143 640 73 144 640 minecraft:light_gray_concrete
fill 73 143 642 73 144 642 minecraft:light_gray_concrete
fill 73 143 644 73 144 644 minecraft:light_gray_concrete
fill 74 143 639 74 144 639 minecraft:light_gray_concrete
fill 74 143 641 74 144 641 minecraft:light_gray_concrete
fill 74 143 643 74 144 643 minecraft:light_gray_concrete
fill 74 143 645 74 144 645 minecraft:light_gray_concrete
fill 75 143 638 75 144 638 minecraft:light_gray_concrete
fill 75 143 640 75 144 640 minecraft:light_gray_concrete
fill 75 143 642 75 144 642 minecraft:light_gray_concrete
fill 75 143 644 75 144 644 minecraft:light_gray_concrete
fill 76 143 639 76 144 639 minecraft:light_gray_concrete
fill 76 143 641 76 144 641 minecraft:light_gray_concrete
fill 76 143 643 76 144 643 minecraft:light_gray_concrete
fill 76 143 645 76 144 645 minecraft:light_gray_concrete
fill 77 143 638 77 144 638 minecraft:light_gray_concrete
fill 77 143 640 77 144 640 minecraft:light_gray_concrete
fill 77 143 642 77 144 642 minecraft:light_gray_concrete
fill 77 143 644 77 144 644 minecraft:light_gray_concrete
fill 78 143 639 78 144 639 minecraft:light_gray_concrete
fill 78 143 641 78 144 641 minecraft:light_gray_concrete
fill 78 143 643 78 144 643 minecraft:light_gray_concrete
fill 78 143 645 78 144 645 minecraft:light_gray_concrete
fill 79 143 618 79 144 618 minecraft:light_gray_concrete
fill 79 143 620 79 144 620 minecraft:light_gray_concrete
fill 79 143 622 79 144 622 minecraft:light_gray_concrete
fill 79 143 624 79 144 624 minecraft:light_gray_concrete
fill 79 143 626 79 144 626 minecraft:light_gray_concrete
fill 79 143 628 79 144 628 minecraft:light_gray_concrete
fill 79 143 630 79 144 630 minecraft:light_gray_concrete
fill 80 143 619 80 144 619 minecraft:light_gray_concrete
fill 80 143 621 80 144 621 minecraft:light_gray_concrete
fill 80 143 623 80 144 623 minecraft:light_gray_concrete
fill 80 143 625 80 144 625 minecraft:light_gray_concrete
fill 80 143 627 80 144 627 minecraft:light_gray_concrete
fill 80 143 629 80 144 629 minecraft:light_gray_concrete
fill 81 143 618 81 144 618 minecraft:light_gray_concrete
fill 81 143 620 81 144 620 minecraft:light_gray_concrete
fill 81 143 622 81 144 622 minecraft:light_gray_concrete
fill 81 143 624 81 144 624 minecraft:light_gray_concrete
fill 81 143 626 81 144 626 minecraft:light_gray_concrete
fill 81 143 628 81 144 628 minecraft:light_gray_concrete
fill 81 143 630 81 144 630 minecraft:light_gray_concrete
fill 82 143 619 82 144 619 minecraft:light_gray_concrete
fill 82 143 621 82 144 621 minecraft:light_gray_concrete
fill 82 143 623 82 144 623 minecraft:light_gray_concrete
fill 82 143 625 82 144 625 minecraft:light_gray_concrete
fill 82 143 627 82 144 627 minecraft:light_gray_concrete
fill 82 143 629 82 144 629 minecraft:light_gray_concrete
fill 83 143 618 83 144 618 minecraft:light_gray_concrete
fill 83 143 620 83 144 620 minecraft:light_gray_concrete
fill 83 143 622 83 144 622 minecraft:light_gray_concrete
fill 83 143 624 83 144 624 minecraft:light_gray_concrete
fill 83 143 626 83 144 626 minecraft:light_gray_concrete
fill 83 143 628 83 144 628 minecraft:light_gray_concrete
fill 83 143 630 83 144 630 minecraft:light_gray_concrete
fill 84 143 619 84 144 619 minecraft:light_gray_concrete
fill 84 143 621 84 144 621 minecraft:light_gray_concrete
fill 84 143 623 84 144 623 minecraft:light_gray_concrete
fill 84 143 625 84 144 625 minecraft:light_gray_concrete
fill 84 143 627 84 144 627 minecraft:light_gray_concrete
fill 84 143 629 84 144 629 minecraft:light_gray_concrete
fill 85 143 618 85 144 618 minecraft:light_gray_concrete
fill 85 143 620 85 144 620 minecraft:light_gray_concrete
fill 85 143 622 85 144 622 minecraft:light_gray_concrete
fill 85 143 624 85 144 624 minecraft:light_gray_concrete
fill 85 143 626 85 144 626 minecraft:light_gray_concrete
fill 85 143 628 85 144 628 minecraft:light_gray_concrete
fill 85 143 630 85 144 630 minecraft:light_gray_concrete
fill 86 143 619 86 144 619 minecraft:light_gray_concrete
fill 86 143 621 86 144 621 minecraft:light_gray_concrete
fill 86 143 623 86 144 623 minecraft:light_gray_concrete
fill 86 143 625 86 144 625 minecraft:light_gray_concrete
fill 86 143 627 86 144 627 minecraft:light_gray_concrete
fill 86 143 629 86 144 629 minecraft:light_gray_concrete
fill 87 143 618 87 144 618 minecraft:light_gray_concrete
fill 87 143 620 87 144 620 minecraft:light_gray_concrete
fill 87 143 622 87 144 622 minecraft:light_gray_concrete
fill 87 143 624 87 144 624 minecraft:light_gray_concrete
fill 87 143 626 87 144 626 minecraft:light_gray_concrete
fill 87 143 628 87 144 628 minecraft:light_gray_concrete
fill 87 143 630 87 144 630 minecraft:light_gray_concrete
fill 88 143 619 88 144 619 minecraft:light_gray_concrete
fill 88 143 621 88 144 621 minecraft:light_gray_concrete
fill 88 143 623 88 144 623 minecraft:light_gray_concrete
fill 88 143 625 88 144 625 minecraft:light_gray_concrete
fill 88 143 627 88 144 627 minecraft:light_gray_concrete
fill 88 143 629 88 144 629 minecraft:light_gray_concrete
fill 47 144 609 47 149 609 minecraft:sea_lantern
fill 47 144 617 47 149 617 minecraft:sea_lantern
fill 47 144 619 47 218 624 minecraft:black_concrete
fill 47 144 625 47 149 625 minecraft:sea_lantern
fill 47 144 626 47 218 626 minecraft:black_concrete
fill 47 144 628 47 218 632 minecraft:black_concrete
fill 47 144 633 47 149 633 minecraft:sea_lantern
fill 47 144 634 47 218 640 minecraft:black_concrete
fill 47 144 641 47 149 641 minecraft:sea_lantern
fill 47 144 642 47 215 643 minecraft:black_concrete
fill 48 144 646 49 218 646 minecraft:black_concrete
fill 50 144 646 50 149 646 minecraft:sea_lantern
fill 51 144 646 51 219 646 minecraft:black_concrete
fill 54 144 604 54 149 604 minecraft:sea_lantern
fill 55 144 604 61 215 604 minecraft:black_concrete
fill 57 144 646 57 218 646 minecraft:black_concrete
fill 58 144 646 58 149 646 minecraft:sea_lantern
fill 59 144 646 60 215 646 minecraft:black_concrete
fill 62 144 604 62 149 604 minecraft:sea_lantern
fill 64 144 646 65 218 646 minecraft:black_concrete
fill 66 144 646 66 149 646 minecraft:sea_lantern
fill 69 144 604 69 216 604 minecraft:black_concrete
fill 70 144 604 70 149 604 minecraft:sea_lantern
fill 73 144 604 77 214 604 minecraft:black_concrete
fill 74 144 646 74 149 646 minecraft:sea_lantern
fill 78 144 604 78 149 604 minecraft:sea_lantern
fill 79 144 604 84 218 604 minecraft:black_concrete
fill 81 144 646 81 219 646 minecraft:black_concrete
fill 82 144 646 82 149 646 minecraft:sea_lantern
fill 86 144 604 86 149 604 minecraft:sea_lantern
fill 89 144 604 89 214 608 minecraft:black_concrete
fill 89 144 609 89 149 609 minecraft:sea_lantern
fill 89 144 616 89 216 616 minecraft:black_concrete
fill 89 144 617 89 149 617 minecraft:sea_lantern
fill 89 144 618 89 214 622 minecraft:black_concrete
fill 89 144 625 89 149 625 minecraft:sea_lantern
fill 89 144 626 89 216 632 minecraft:black_concrete
fill 89 144 633 89 149 633 minecraft:sea_lantern
fill 89 144 634 89 218 635 minecraft:black_concrete
fill 89 144 637 89 218 640 minecraft:black_concrete
fill 89 144 641 89 149 641 minecraft:sea_lantern
fill 89 144 642 89 218 642 minecraft:black_concrete
setblock 70 145 639 minecraft:sea_lantern
setblock 70 145 641 minecraft:sea_lantern
setblock 70 145 643 minecraft:sea_lantern
setblock 70 145 645 minecraft:sea_lantern
setblock 71 145 638 minecraft:sea_lantern
setblock 71 145 640 minecraft:sea_lantern
setblock 71 145 642 minecraft:sea_lantern
setblock 71 145 644 minecraft:sea_lantern
setblock 72 145 639 minecraft:sea_lantern
setblock 72 145 641 minecraft:sea_lantern
setblock 72 145 643 minecraft:sea_lantern
setblock 72 145 645 minecraft:sea_lantern
setblock 73 145 638 minecraft:sea_lantern
setblock 73 145 640 minecraft:sea_lantern
setblock 73 145 642 minecraft:sea_lantern
setblock 73 145 644 minecraft:sea_lantern
setblock 74 145 639 minecraft:sea_lantern
setblock 74 145 641 minecraft:sea_lantern
setblock 74 145 643 minecraft:sea_lantern
setblock 74 145 645 minecraft:sea_lantern
setblock 75 145 638 minecraft:sea_lantern
setblock 75 145 640 minecraft:sea_lantern
setblock 75 145 642 minecraft:sea_lantern
setblock 75 145 644 minecraft:sea_lantern
setblock 76 145 639 minecraft:sea_lantern
setblock 76 145 641 minecraft:sea_lantern
setblock 76 145 643 minecraft:sea_lantern
setblock 76 145 645 minecraft:sea_lantern
setblock 77 145 638 minecraft:sea_lantern
setblock 77 145 640 minecraft:sea_lantern
setblock 77 145 642 minecraft:sea_lantern
setblock 77 145 644 minecraft:sea_lantern
setblock 78 145 639 minecraft:sea_lantern
setblock 78 145 641 minecraft:sea_lantern
setblock 78 145 643 minecraft:sea_lantern
setblock 78 145 645 minecraft:sea_lantern
setblock 79 145 618 minecraft:sea_lantern
setblock 79 145 620 minecraft:sea_lantern
setblock 79 145 622 minecraft:sea_lantern
setblock 79 145 624 minecraft:sea_lantern
setblock 79 145 626 minecraft:sea_lantern
setblock 79 145 628 minecraft:sea_lantern
setblock 79 145 630 minecraft:sea_lantern
setblock 80 145 619 minecraft:sea_lantern
setblock 80 145 621 minecraft:sea_lantern
setblock 80 145 623 minecraft:sea_lantern
setblock 80 145 625 minecraft:sea_lantern
setblock 80 145 627 minecraft:sea_lantern
setblock 80 145 629 minecraft:sea_lantern
setblock 81 145 618 minecraft:sea_lantern
setblock 81 145 620 minecraft:sea_lantern
setblock 81 145 622 minecraft:sea_lantern
setblock 81 145 624 minecraft:sea_lantern
setblock 81 145 626 minecraft:sea_lantern
setblock 81 145 628 minecraft:sea_lantern
setblock 81 145 630 minecraft:sea_lantern
setblock 82 145 619 minecraft:sea_lantern
setblock 82 145 621 minecraft:sea_lantern
setblock 82 145 623 minecraft:sea_lantern
setblock 82 145 625 minecraft:sea_lantern
setblock 82 145 627 minecraft:sea_lantern
setblock 82 145 629 minecraft:sea_lantern
setblock 83 145 618 minecraft:sea_lantern
setblock 83 145 620 minecraft:sea_lantern
setblock 83 145 622 minecraft:sea_lantern
setblock 83 145 624 minecraft:sea_lantern
setblock 83 145 626 minecraft:sea_lantern
setblock 83 145 628 minecraft:sea_lantern
setblock 83 145 630 minecraft:sea_lantern
setblock 84 145 619 minecraft:sea_lantern
setblock 84 145 621 minecraft:sea_lantern
setblock 84 145 623 minecraft:sea_lantern
setblock 84 145 625 minecraft:sea_lantern
setblock 84 145 627 minecraft:sea_lantern
setblock 84 145 629 minecraft:sea_lantern
setblock 85 145 618 minecraft:sea_lantern
setblock 85 145 620 minecraft:sea_lantern
setblock 85 145 622 minecraft:sea_lantern
setblock 85 145 624 minecraft:sea_lantern
setblock 85 145 626 minecraft:sea_lantern
setblock 85 145 628 minecraft:sea_lantern
setblock 85 145 630 minecraft:sea_lantern
setblock 86 145 619 minecraft:sea_lantern
setblock 86 145 621 minecraft:sea_lantern
setblock 86 145 623 minecraft:sea_lantern
setblock 86 145 625 minecraft:sea_lantern
setblock 86 145 627 minecraft:sea_lantern
setblock 86 145 629 minecraft:sea_lantern
setblock 87 145 618 minecraft:sea_lantern
setblock 87 145 620 minecraft:sea_lantern
setblock 87 145 622 minecraft:sea_lantern
setblock 87 145 624 minecraft:sea_lantern
setblock 87 145 626 minecraft:sea_lantern
setblock 87 145 628 minecraft:sea_lantern
setblock 87 145 630 minecraft:sea_lantern
setblock 88 145 619 minecraft:sea_lantern
setblock 88 145 621 minecraft:sea_lantern
setblock 88 145 623 minecraft:sea_lantern
setblock 88 145 625 minecraft:sea_lantern
setblock 88 145 627 minecraft:sea_lantern
setblock 88 145 629 minecraft:sea_lantern
fill 56 146 620 56 147 620 minecraft:magenta_concrete
fill 70 146 639 70 147 639 minecraft:light_gray_concrete
fill 70 146 641 70 147 641 minecraft:light_gray_concrete
fill 70 146 643 70 147 643 minecraft:light_gray_concrete
fill 70 146 645 70 147 645 minecraft:light_gray_concrete
fill 71 146 638 71 147 638 minecraft:light_gray_concrete
fill 71 146 640 71 147 640 minecraft:light_gray_concrete
fill 71 146 642 71 147 642 minecraft:light_gray_concrete
fill 71 146 644 71 147 644 minecraft:light_gray_concrete
fill 72 146 639 72 147 639 minecraft:light_gray_concrete
fill 72 146 641 72 147 641 minecraft:light_gray_concrete
fill 72 146 643 72 147 643 minecraft:light_gray_concrete
fill 72 146 645 72 147 645 minecraft:light_gray_concrete
fill 73 146 638 73 147 638 minecraft:light_gray_concrete
fill 73 146 640 73 147 640 minecraft:light_gray_concrete
fill 73 146 642 73 147 642 minecraft:light_gray_concrete
fill 73 146 644 73 147 644 minecraft:light_gray_concrete
fill 74 146 639 74 147 639 minecraft:light_gray_concrete
fill 74 146 641 74 147 641 minecraft:light_gray_concrete
fill 74 146 643 74 147 643 minecraft:light_gray_concrete
fill 74 146 645 74 147 645 minecraft:light_gray_concrete
fill 75 146 638 75 147 638 minecraft:light_gray_concrete
fill 75 146 640 75 147 640 minecraft:light_gray_concrete
fill 75 146 642 75 147 642 minecraft:light_gray_concrete
fill 75 146 644 75 147 644 minecraft:light_gray_concrete
fill 76 146 639 76 147 639 minecraft:light_gray_concrete
fill 76 146 641 76 147 641 minecraft:light_gray_concrete
fill 76 146 643 76 147 643 minecraft:light_gray_concrete
fill 76 146 645 76 147 645 minecraft:light_gray_concrete
fill 77 146 638 77 147 638 minecraft:light_gray_concrete
fill 77 146 640 77 147 640 minecraft:light_gray_concrete
fill 77 146 642 77 147 642 minecraft:light_gray_concrete
fill 77 146 644 77 147 644 minecraft:light_gray_concrete
fill 78 146 639 78 147 639 minecraft:light_gray_concrete
fill 78 146 641 78 147 641 minecraft:light_gray_concrete
fill 78 146 643 78 147 643 minecraft:light_gray_concrete
fill 78 146 645 78 147 645 minecraft:light_gray_concrete
fill 79 146 618 79 147 618 minecraft:light_gray_concrete
fill 79 146 620 79 147 620 minecraft:light_gray_concrete
fill 79 146 622 79 147 622 minecraft:light_gray_concrete
fill 79 146 624 79 147 624 minecraft:light_gray_concrete
fill 79 146 626 79 147 626 minecraft:light_gray_concrete
fill 79 146 628 79 147 628 minecraft:light_gray_concrete
fill 79 146 630 79 147 630 minecraft:light_gray_concrete
fill 80 146 619 80 147 619 minecraft:light_gray_concrete
fill 80 146 621 80 147 621 minecraft:light_gray_concrete
fill 80 146 623 80 147 623 minecraft:light_gray_concrete
fill 80 146 625 80 147 625 minecraft:light_gray_concrete
fill 80 146 627 80 147 627 minecraft:light_gray_concrete
fill 80 146 629 80 147 629 minecraft:light_gray_concrete
fill 81 146 618 81 147 618 minecraft:light_gray_concrete
fill 81 146 620 81 147 620 minecraft:light_gray_concrete
fill 81 146 622 81 147 622 minecraft:light_gray_concrete
fill 81 146 624 81 147 624 minecraft:light_gray_concrete
fill 81 146 626 81 147 626 minecraft:light_gray_concrete
fill 81 146 628 81 147 628 minecraft:light_gray_concrete
fill 81 146 630 81 147 630 minecraft:light_gray_concrete
fill 82 146 619 82 147 619 minecraft:light_gray_concrete
fill 82 146 621 82 147 621 minecraft:light_gray_concrete
fill 82 146 623 82 147 623 minecraft:light_gray_concrete
fill 82 146 625 82 147 625 minecraft:light_gray_concrete
fill 82 146 627 82 147 627 minecraft:light_gray_concrete
fill 82 146 629 82 147 629 minecraft:light_gray_concrete
fill 83 146 618 83 147 618 minecraft:light_gray_concrete
fill 83 146 620 83 147 620 minecraft:light_gray_concrete
fill 83 146 622 83 147 622 minecraft:light_gray_concrete
fill 83 146 624 83 147 624 minecraft:light_gray_concrete
fill 83 146 626 83 147 626 minecraft:light_gray_concrete
fill 83 146 628 83 147 628 minecraft:light_gray_concrete
fill 83 146 630 83 147 630 minecraft:light_gray_concrete
fill 84 146 619 84 147 619 minecraft:light_gray_concrete
fill 84 146 621 84 147 621 minecraft:light_gray_concrete
fill 84 146 623 84 147 623 minecraft:light_gray_concrete
fill 84 146 625 84 147 625 minecraft:light_gray_concrete
fill 84 146 627 84 147 627 minecraft:light_gray_concrete
fill 84 146 629 84 147 629 minecraft:light_gray_concrete
fill 85 146 618 85 147 618 minecraft:light_gray_concrete
fill 85 146 620 85 147 620 minecraft:light_gray_concrete
fill 85 146 622 85 147 622 minecraft:light_gray_concrete
fill 85 146 624 85 147 624 minecraft:light_gray_concrete
fill 85 146 626 85 147 626 minecraft:light_gray_concrete
fill 85 146 628 85 147 628 minecraft:light_gray_concrete
fill 85 146 630 85 147 630 minecraft:light_gray_concrete
fill 86 146 619 86 147 619 minecraft:light_gray_concrete
fill 86 146 621 86 147 621 minecraft:light_gray_concrete
fill 86 146 623 86 147 623 minecraft:light_gray_concrete
fill 86 146 625 86 147 625 minecraft:light_gray_concrete
fill 86 146 627 86 147 627 minecraft:light_gray_concrete
fill 86 146 629 86 147 629 minecraft:light_gray_concrete
fill 87 146 618 87 147 618 minecraft:light_gray_concrete
fill 87 146 620 87 147 620 minecraft:light_gray_concrete
fill 87 146 622 87 147 622 minecraft:light_gray_concrete
fill 87 146 624 87 147 624 minecraft:light_gray_concrete
fill 87 146 626 87 147 626 minecraft:light_gray_concrete
fill 87 146 628 87 147 628 minecraft:light_gray_concrete
fill 87 146 630 87 147 630 minecraft:light_gray_concrete
fill 88 146 619 88 147 619 minecraft:light_gray_concrete
fill 88 146 621 88 147 621 minecraft:light_gray_concrete
fill 88 146 623 88 147 623 minecraft:light_gray_concrete
fill 88 146 625 88 147 625 minecraft:light_gray_concrete
fill 88 146 627 88 147 627 minecraft:light_gray_concrete
fill 88 146 629 88 147 629 minecraft:light_gray_concrete
setblock 50 147 607 minecraft:light[level=14]
setblock 50 147 615 minecraft:light[level=14]
setblock 50 147 623 minecraft:light[level=14]
setblock 50 147 631 minecraft:light[level=14]
setblock 50 147 639 minecraft:light[level=14]
setblock 58 147 607 minecraft:light[level=14]
setblock 58 147 615 minecraft:light[level=14]
setblock 58 147 623 minecraft:light[level=14]
setblock 58 147 631 minecraft:light[level=14]
setblock 58 147 639 minecraft:light[level=14]
setblock 66 147 607 minecraft:light[level=14]
setblock 66 147 615 minecraft:light[level=14]
setblock 66 147 623 minecraft:light[level=14]
setblock 66 147 631 minecraft:light[level=14]
setblock 66 147 639 minecraft:light[level=14]
setblock 74 147 607 minecraft:light[level=14]
setblock 74 147 615 minecraft:light[level=14]
setblock 74 147 623 minecraft:light[level=14]
setblock 74 147 631 minecraft:light[level=14]
setblock 82 147 607 minecraft:light[level=14]
setblock 82 147 615 minecraft:light[level=14]
setblock 82 147 631 minecraft:light[level=14]
setblock 82 147 639 minecraft:light[level=14]
setblock 70 148 639 minecraft:sea_lantern
setblock 70 148 641 minecraft:sea_lantern
setblock 70 148 643 minecraft:sea_lantern
setblock 70 148 645 minecraft:sea_lantern
setblock 71 148 638 minecraft:sea_lantern
setblock 71 148 640 minecraft:sea_lantern
setblock 71 148 642 minecraft:sea_lantern
setblock 71 148 644 minecraft:sea_lantern
setblock 72 148 639 minecraft:sea_lantern
setblock 72 148 641 minecraft:sea_lantern
setblock 72 148 643 minecraft:sea_lantern
setblock 72 148 645 minecraft:sea_lantern
setblock 73 148 638 minecraft:sea_lantern
setblock 73 148 640 minecraft:sea_lantern
setblock 73 148 642 minecraft:sea_lantern
setblock 73 148 644 minecraft:sea_lantern
setblock 74 148 639 minecraft:sea_lantern
setblock 74 148 641 minecraft:sea_lantern
setblock 74 148 643 minecraft:sea_lantern
setblock 74 148 645 minecraft:sea_lantern
setblock 75 148 638 minecraft:sea_lantern
setblock 75 148 640 minecraft:sea_lantern
setblock 75 148 642 minecraft:sea_lantern
setblock 75 148 644 minecraft:sea_lantern
setblock 76 148 639 minecraft:sea_lantern
setblock 76 148 641 minecraft:sea_lantern
setblock 76 148 643 minecraft:sea_lantern
setblock 76 148 645 minecraft:sea_lantern
setblock 77 148 638 minecraft:sea_lantern
setblock 77 148 640 minecraft:sea_lantern
setblock 77 148 642 minecraft:sea_lantern
setblock 77 148 644 minecraft:sea_lantern
setblock 78 148 639 minecraft:sea_lantern
setblock 78 148 641 minecraft:sea_lantern
setblock 78 148 643 minecraft:sea_lantern
setblock 78 148 645 minecraft:sea_lantern
setblock 79 148 618 minecraft:sea_lantern
setblock 79 148 620 minecraft:sea_lantern
setblock 79 148 622 minecraft:sea_lantern
setblock 79 148 624 minecraft:sea_lantern
setblock 79 148 626 minecraft:sea_lantern
setblock 79 148 628 minecraft:sea_lantern
setblock 79 148 630 minecraft:sea_lantern
setblock 80 148 619 minecraft:sea_lantern
setblock 80 148 621 minecraft:sea_lantern
setblock 80 148 623 minecraft:sea_lantern
setblock 80 148 625 minecraft:sea_lantern
setblock 80 148 627 minecraft:sea_lantern
setblock 80 148 629 minecraft:sea_lantern
setblock 81 148 618 minecraft:sea_lantern
setblock 81 148 620 minecraft:sea_lantern
setblock 81 148 622 minecraft:sea_lantern
setblock 81 148 624 minecraft:sea_lantern
setblock 81 148 626 minecraft:sea_lantern
setblock 81 148 628 minecraft:sea_lantern
setblock 81 148 630 minecraft:sea_lantern
setblock 82 148 619 minecraft:sea_lantern
setblock 82 148 621 minecraft:sea_lantern
setblock 82 148 623 minecraft:sea_lantern
setblock 82 148 625 minecraft:sea_lantern
setblock 82 148 627 minecraft:sea_lantern
setblock 82 148 629 minecraft:sea_lantern
setblock 83 148 618 minecraft:sea_lantern
setblock 83 148 620 minecraft:sea_lantern
setblock 83 148 622 minecraft:sea_lantern
setblock 83 148 624 minecraft:sea_lantern
setblock 83 148 626 minecraft:sea_lantern
setblock 83 148 628 minecraft:sea_lantern
setblock 83 148 630 minecraft:sea_lantern
setblock 84 148 619 minecraft:sea_lantern
setblock 84 148 621 minecraft:sea_lantern
setblock 84 148 623 minecraft:sea_lantern
setblock 84 148 625 minecraft:sea_lantern
setblock 84 148 627 minecraft:sea_lantern
setblock 84 148 629 minecraft:sea_lantern
setblock 85 148 618 minecraft:sea_lantern
setblock 85 148 620 minecraft:sea_lantern
setblock 85 148 622 minecraft:sea_lantern
setblock 85 148 624 minecraft:sea_lantern
setblock 85 148 626 minecraft:sea_lantern
setblock 85 148 628 minecraft:sea_lantern
setblock 85 148 630 minecraft:sea_lantern
setblock 86 148 619 minecraft:sea_lantern
setblock 86 148 621 minecraft:sea_lantern
setblock 86 148 623 minecraft:sea_lantern
setblock 86 148 625 minecraft:sea_lantern
setblock 86 148 627 minecraft:sea_lantern
setblock 86 148 629 minecraft:sea_lantern
setblock 87 148 618 minecraft:sea_lantern
setblock 87 148 620 minecraft:sea_lantern
setblock 87 148 622 minecraft:sea_lantern
setblock 87 148 624 minecraft:sea_lantern
setblock 87 148 626 minecraft:sea_lantern
setblock 87 148 628 minecraft:sea_lantern
setblock 87 148 630 minecraft:sea_lantern
setblock 88 148 619 minecraft:sea_lantern
setblock 88 148 621 minecraft:sea_lantern
setblock 88 148 623 minecraft:sea_lantern
setblock 88 148 625 minecraft:sea_lantern
setblock 88 148 627 minecraft:sea_lantern
setblock 88 148 629 minecraft:sea_lantern
fill 70 149 639 70 150 639 minecraft:light_gray_concrete
fill 70 149 641 70 150 641 minecraft:light_gray_concrete
fill 70 149 643 70 150 643 minecraft:light_gray_concrete
fill 70 149 645 70 150 645 minecraft:light_gray_concrete
fill 71 149 638 71 150 638 minecraft:light_gray_concrete
fill 71 149 640 71 150 640 minecraft:light_gray_concrete
fill 71 149 642 71 150 642 minecraft:light_gray_concrete
fill 71 149 644 71 150 644 minecraft:light_gray_concrete
fill 72 149 639 72 150 639 minecraft:light_gray_concrete
fill 72 149 641 72 150 641 minecraft:light_gray_concrete
fill 72 149 643 72 150 643 minecraft:light_gray_concrete
fill 72 149 645 72 150 645 minecraft:light_gray_concrete
fill 73 149 638 73 150 638 minecraft:light_gray_concrete
fill 73 149 640 73 150 640 minecraft:light_gray_concrete
fill 73 149 642 73 150 642 minecraft:light_gray_concrete
fill 73 149 644 73 150 644 minecraft:light_gray_concrete
fill 74 149 639 74 150 639 minecraft:light_gray_concrete
fill 74 149 641 74 150 641 minecraft:light_gray_concrete
fill 74 149 643 74 150 643 minecraft:light_gray_concrete
fill 74 149 645 74 150 645 minecraft:light_gray_concrete
fill 75 149 638 75 150 638 minecraft:light_gray_concrete
fill 75 149 640 75 150 640 minecraft:light_gray_concrete
fill 75 149 642 75 150 642 minecraft:light_gray_concrete
fill 75 149 644 75 150 644 minecraft:light_gray_concrete
fill 76 149 639 76 150 639 minecraft:light_gray_concrete
fill 76 149 641 76 150 641 minecraft:light_gray_concrete
fill 76 149 643 76 150 643 minecraft:light_gray_concrete
fill 76 149 645 76 150 645 minecraft:light_gray_concrete
fill 77 149 638 77 150 638 minecraft:light_gray_concrete
fill 77 149 640 77 150 640 minecraft:light_gray_concrete
fill 77 149 642 77 150 642 minecraft:light_gray_concrete
fill 77 149 644 77 150 644 minecraft:light_gray_concrete
fill 78 149 639 78 150 639 minecraft:light_gray_concrete
fill 78 149 641 78 150 641 minecraft:light_gray_concrete
fill 78 149 643 78 150 643 minecraft:light_gray_concrete
fill 78 149 645 78 150 645 minecraft:light_gray_concrete
setblock 79 149 618 minecraft:light_gray_concrete
setblock 79 149 620 minecraft:light_gray_concrete
setblock 79 149 622 minecraft:light_gray_concrete
setblock 79 149 624 minecraft:light_gray_concrete
setblock 79 149 626 minecraft:light_gray_concrete
setblock 79 149 628 minecraft:light_gray_concrete
setblock 79 149 630 minecraft:light_gray_concrete
setblock 80 149 619 minecraft:light_gray_concrete
setblock 80 149 621 minecraft:light_gray_concrete
setblock 80 149 623 minecraft:light_gray_concrete
setblock 80 149 625 minecraft:light_gray_concrete
setblock 80 149 627 minecraft:light_gray_concrete
setblock 80 149 629 minecraft:light_gray_concrete
setblock 81 149 618 minecraft:light_gray_concrete
setblock 81 149 620 minecraft:light_gray_concrete
setblock 81 149 622 minecraft:light_gray_concrete
setblock 81 149 624 minecraft:light_gray_concrete
setblock 81 149 626 minecraft:light_gray_concrete
setblock 81 149 628 minecraft:light_gray_concrete
setblock 81 149 630 minecraft:light_gray_concrete
setblock 82 149 619 minecraft:light_gray_concrete
setblock 82 149 621 minecraft:light_gray_concrete
setblock 82 149 623 minecraft:light_gray_concrete
setblock 82 149 625 minecraft:light_gray_concrete
setblock 82 149 627 minecraft:light_gray_concrete
setblock 82 149 629 minecraft:light_gray_concrete
setblock 83 149 618 minecraft:light_gray_concrete
setblock 83 149 620 minecraft:light_gray_concrete
setblock 83 149 622 minecraft:light_gray_concrete
setblock 83 149 624 minecraft:light_gray_concrete
setblock 83 149 626 minecraft:light_gray_concrete
setblock 83 149 628 minecraft:light_gray_concrete
setblock 83 149 630 minecraft:light_gray_concrete
setblock 84 149 619 minecraft:light_gray_concrete
setblock 84 149 621 minecraft:light_gray_concrete
setblock 84 149 623 minecraft:light_gray_concrete
setblock 84 149 625 minecraft:light_gray_concrete
setblock 84 149 627 minecraft:light_gray_concrete
setblock 84 149 629 minecraft:light_gray_concrete
setblock 85 149 618 minecraft:light_gray_concrete
setblock 85 149 620 minecraft:light_gray_concrete
setblock 85 149 622 minecraft:light_gray_concrete
setblock 85 149 624 minecraft:light_gray_concrete
setblock 85 149 626 minecraft:light_gray_concrete
setblock 85 149 628 minecraft:light_gray_concrete
setblock 85 149 630 minecraft:light_gray_concrete
setblock 86 149 619 minecraft:light_gray_concrete
setblock 86 149 621 minecraft:light_gray_concrete
setblock 86 149 623 minecraft:light_gray_concrete
setblock 86 149 625 minecraft:light_gray_concrete
setblock 86 149 627 minecraft:light_gray_concrete
setblock 86 149 629 minecraft:light_gray_concrete
setblock 87 149 618 minecraft:light_gray_concrete
setblock 87 149 620 minecraft:light_gray_concrete
setblock 87 149 622 minecraft:light_gray_concrete
setblock 87 149 624 minecraft:light_gray_concrete
setblock 87 149 626 minecraft:light_gray_concrete
setblock 87 149 628 minecraft:light_gray_concrete
setblock 87 149 630 minecraft:light_gray_concrete
setblock 88 149 619 minecraft:light_gray_concrete
setblock 88 149 621 minecraft:light_gray_concrete
fill 88 149 623 88 184 623 minecraft:light_gray_concrete
setblock 88 149 625 minecraft:light_gray_concrete
setblock 88 149 627 minecraft:light_gray_concrete
setblock 88 149 629 minecraft:light_gray_concrete
fill 47 150 609 47 157 609 minecraft:black_concrete
fill 47 150 617 47 157 617 minecraft:black_concrete
fill 47 150 625 47 157 625 minecraft:black_concrete
fill 47 150 633 47 157 633 minecraft:black_concrete
fill 47 150 641 47 157 641 minecraft:black_concrete
fill 50 150 646 50 157 646 minecraft:black_concrete
fill 54 150 604 54 157 604 minecraft:black_concrete
fill 58 150 646 58 157 646 minecraft:black_concrete
fill 62 150 604 62 157 604 minecraft:black_concrete
fill 66 150 646 66 157 646 minecraft:black_concrete
fill 70 150 604 70 157 604 minecraft:black_concrete
fill 74 150 646 74 157 646 minecraft:black_concrete
fill 78 150 604 78 157 604 minecraft:black_concrete
fill 82 150 646 82 157 646 minecraft:black_concrete
fill 86 150 604 86 157 604 minecraft:black_concrete
fill 89 150 609 89 157 609 minecraft:black_concrete
fill 89 150 617 89 157 617 minecraft:black_concrete
fill 89 150 625 89 157 625 minecraft:black_concrete
fill 89 150 633 89 157 633 minecraft:black_concrete
fill 89 150 641 89 157 641 minecraft:black_concrete
setblock 70 151 639 minecraft:sea_lantern
setblock 70 151 641 minecraft:sea_lantern
setblock 70 151 643 minecraft:sea_lantern
setblock 70 151 645 minecraft:sea_lantern
setblock 71 151 638 minecraft:sea_lantern
setblock 71 151 640 minecraft:sea_lantern
setblock 71 151 642 minecraft:sea_lantern
setblock 71 151 644 minecraft:sea_lantern
setblock 72 151 639 minecraft:sea_lantern
setblock 72 151 641 minecraft:sea_lantern
setblock 72 151 643 minecraft:sea_lantern
setblock 72 151 645 minecraft:sea_lantern
setblock 73 151 638 minecraft:sea_lantern
setblock 73 151 640 minecraft:sea_lantern
setblock 73 151 642 minecraft:sea_lantern
setblock 73 151 644 minecraft:sea_lantern
setblock 74 151 639 minecraft:sea_lantern
setblock 74 151 641 minecraft:sea_lantern
setblock 74 151 643 minecraft:sea_lantern
setblock 74 151 645 minecraft:sea_lantern
setblock 75 151 638 minecraft:sea_lantern
setblock 75 151 640 minecraft:sea_lantern
setblock 75 151 642 minecraft:sea_lantern
setblock 75 151 644 minecraft:sea_lantern
setblock 76 151 639 minecraft:sea_lantern
setblock 76 151 641 minecraft:sea_lantern
setblock 76 151 643 minecraft:sea_lantern
setblock 76 151 645 minecraft:sea_lantern
setblock 77 151 638 minecraft:sea_lantern
setblock 77 151 640 minecraft:sea_lantern
setblock 77 151 642 minecraft:sea_lantern
setblock 77 151 644 minecraft:sea_lantern
setblock 78 151 639 minecraft:sea_lantern
setblock 78 151 641 minecraft:sea_lantern
setblock 78 151 643 minecraft:sea_lantern
setblock 78 151 645 minecraft:sea_lantern
fill 51 152 629 52 153 629 minecraft:gray_concrete
fill 70 152 639 70 154 639 minecraft:light_gray_concrete
fill 70 152 641 70 154 641 minecraft:light_gray_concrete
fill 70 152 643 70 154 643 minecraft:light_gray_concrete
fill 70 152 645 70 184 645 minecraft:light_gray_concrete
fill 71 152 638 71 154 638 minecraft:light_gray_concrete
fill 71 152 640 71 154 640 minecraft:light_gray_concrete
fill 71 152 642 71 154 642 minecraft:light_gray_concrete
fill 71 152 644 71 154 644 minecraft:light_gray_concrete
fill 72 152 639 72 154 639 minecraft:light_gray_concrete
fill 72 152 641 72 154 641 minecraft:light_gray_concrete
fill 72 152 643 72 154 643 minecraft:light_gray_concrete
fill 72 152 645 72 155 645 minecraft:light_gray_concrete
fill 73 152 638 73 154 638 minecraft:light_gray_concrete
fill 73 152 640 73 154 640 minecraft:light_gray_concrete
fill 73 152 642 73 154 642 minecraft:light_gray_concrete
fill 73 152 644 73 154 644 minecraft:light_gray_concrete
fill 74 152 639 74 154 639 minecraft:light_gray_concrete
fill 74 152 641 74 154 641 minecraft:light_gray_concrete
fill 74 152 643 74 154 643 minecraft:light_gray_concrete
fill 74 152 645 74 155 645 minecraft:light_gray_concrete
fill 75 152 638 75 154 638 minecraft:light_gray_concrete
fill 75 152 640 75 154 640 minecraft:light_gray_concrete
fill 75 152 642 75 154 642 minecraft:light_gray_concrete
fill 75 152 644 75 154 644 minecraft:light_gray_concrete
fill 76 152 639 76 154 639 minecraft:light_gray_concrete
fill 76 152 641 76 154 641 minecraft:light_gray_concrete
fill 76 152 643 76 154 643 minecraft:light_gray_concrete
fill 76 152 645 76 155 645 minecraft:light_gray_concrete
fill 77 152 638 77 154 638 minecraft:light_gray_concrete
fill 77 152 640 77 154 640 minecraft:light_gray_concrete
fill 77 152 642 77 154 642 minecraft:light_gray_concrete
fill 77 152 644 77 154 644 minecraft:light_gray_concrete
fill 78 152 639 78 154 639 minecraft:light_gray_concrete
fill 78 152 641 78 154 641 minecraft:light_gray_concrete
fill 78 152 643 78 154 643 minecraft:light_gray_concrete
fill 78 152 645 78 184 645 minecraft:light_gray_concrete
fill 48 154 605 48 155 610 minecraft:light_gray_concrete
fill 48 154 613 49 154 618 minecraft:light_gray_concrete
fill 48 154 621 49 154 626 minecraft:light_gray_concrete
fill 48 154 629 49 154 634 minecraft:light_gray_concrete
fill 48 154 637 49 154 642 minecraft:light_gray_concrete
fill 48 154 645 53 155 645 minecraft:light_gray_concrete
fill 49 154 606 49 154 612 minecraft:light_gray_concrete
fill 49 154 619 49 154 620 minecraft:light_gray_concrete
fill 49 154 627 49 154 628 minecraft:light_gray_concrete
fill 49 154 635 49 154 636 minecraft:light_gray_concrete
fill 49 154 643 49 154 644 minecraft:light_gray_concrete
fill 50 154 606 87 154 606 minecraft:light_gray_concrete
fill 50 154 644 69 154 644 minecraft:light_gray_concrete
fill 51 154 605 56 155 605 minecraft:light_gray_concrete
fill 56 154 645 61 155 645 minecraft:light_gray_concrete
fill 59 154 605 64 155 605 minecraft:light_gray_concrete
fill 64 154 645 69 155 645 minecraft:light_gray_concrete
fill 67 154 605 72 155 605 minecraft:light_gray_concrete
fill 75 154 605 80 155 605 minecraft:light_gray_concrete
fill 79 154 644 88 154 644 minecraft:light_gray_concrete
fill 80 154 645 85 155 645 minecraft:light_gray_concrete
fill 83 154 605 88 155 605 minecraft:light_gray_concrete
fill 87 154 607 87 154 643 minecraft:light_gray_concrete
fill 88 154 608 88 155 613 minecraft:light_gray_concrete
fill 88 154 616 88 155 621 minecraft:light_gray_concrete
fill 88 154 624 88 155 629 minecraft:light_gray_concrete
fill 88 154 632 88 155 637 minecraft:light_gray_concrete
fill 88 154 640 88 155 643 minecraft:light_gray_concrete
fill 88 154 645 88 155 645 minecraft:light_gray_concrete
fill 48 155 613 48 155 618 minecraft:light_gray_concrete
fill 48 155 621 48 155 626 minecraft:light_gray_concrete
fill 48 155 629 48 155 634 minecraft:light_gray_concrete
fill 48 155 637 48 155 642 minecraft:light_gray_concrete
setblock 50 155 607 minecraft:light[level=14]
setblock 50 155 615 minecraft:light[level=14]
setblock 50 155 623 minecraft:light[level=14]
setblock 50 155 631 minecraft:light[level=14]
setblock 50 155 639 minecraft:light[level=14]
fill 51 155 617 51 156 618 minecraft:magenta_concrete
setblock 58 155 607 minecraft:light[level=14]
setblock 58 155 615 minecraft:light[level=14]
setblock 58 155 623 minecraft:light[level=14]
setblock 58 155 631 minecraft:light[level=14]
setblock 58 155 639 minecraft:light[level=14]
setblock 66 155 607 minecraft:light[level=14]
setblock 66 155 615 minecraft:light[level=14]
setblock 66 155 623 minecraft:light[level=14]
setblock 66 155 631 minecraft:light[level=14]
setblock 66 155 639 minecraft:light[level=14]
setblock 74 155 607 minecraft:light[level=14]
setblock 74 155 615 minecraft:light[level=14]
setblock 74 155 623 minecraft:light[level=14]
setblock 74 155 631 minecraft:light[level=14]
setblock 74 155 639 minecraft:light[level=14]
setblock 82 155 607 minecraft:light[level=14]
setblock 82 155 615 minecraft:light[level=14]
setblock 82 155 623 minecraft:light[level=14]
setblock 82 155 631 minecraft:light[level=14]
setblock 82 155 639 minecraft:light[level=14]
setblock 88 155 644 minecraft:light_gray_concrete
fill 47 158 609 47 163 609 minecraft:sea_lantern
fill 47 158 617 47 163 617 minecraft:sea_lantern
fill 47 158 625 47 163 625 minecraft:sea_lantern
fill 47 158 633 47 163 633 minecraft:sea_lantern
fill 47 158 641 47 163 641 minecraft:sea_lantern
fill 50 158 646 50 163 646 minecraft:sea_lantern
fill 54 158 604 54 163 604 minecraft:sea_lantern
fill 58 158 646 58 163 646 minecraft:sea_lantern
fill 62 158 604 62 163 604 minecraft:sea_lantern
fill 66 158 646 66 163 646 minecraft:sea_lantern
fill 70 158 604 70 163 604 minecraft:sea_lantern
fill 74 158 646 74 163 646 minecraft:sea_lantern
fill 78 158 604 78 163 604 minecraft:sea_lantern
fill 82 158 646 82 163 646 minecraft:sea_lantern
fill 86 158 604 86 163 604 minecraft:sea_lantern
fill 89 158 609 89 163 609 minecraft:sea_lantern
fill 89 158 617 89 163 617 minecraft:sea_lantern
fill 89 158 625 89 163 625 minecraft:sea_lantern
fill 89 158 633 89 163 633 minecraft:sea_lantern
fill 89 158 641 89 163 641 minecraft:sea_lantern
fill 61 159 612 61 160 612 minecraft:glass
fill 52 162 614 52 167 614 minecraft:magenta_concrete
fill 64 162 641 65 163 642 minecraft:glass
setblock 50 163 607 minecraft:light[level=14]
setblock 50 163 615 minecraft:light[level=14]
setblock 50 163 623 minecraft:light[level=14]
setblock 50 163 631 minecraft:light[level=14]
setblock 50 163 639 minecraft:light[level=14]
fill 51 163 614 51 167 614 minecraft:magenta_concrete
setblock 58 163 607 minecraft:light[level=14]
setblock 58 163 615 minecraft:light[level=14]
setblock 58 163 623 minecraft:light[level=14]
setblock 58 163 631 minecraft:light[level=14]
setblock 58 163 639 minecraft:light[level=14]
setblock 66 163 607 minecraft:light[level=14]
setblock 66 163 615 minecraft:light[level=14]
setblock 66 163 623 minecraft:light[level=14]
setblock 66 163 631 minecraft:light[level=14]
setblock 66 163 639 minecraft:light[level=14]
setblock 74 163 607 minecraft:light[level=14]
setblock 74 163 615 minecraft:light[level=14]
setblock 74 163 623 minecraft:light[level=14]
setblock 74 163 631 minecraft:light[level=14]
setblock 74 163 639 minecraft:light[level=14]
setblock 82 163 607 minecraft:light[level=14]
setblock 82 163 615 minecraft:light[level=14]
setblock 82 163 623 minecraft:light[level=14]
setblock 82 163 631 minecraft:light[level=14]
setblock 82 163 639 minecraft:light[level=14]
fill 47 164 609 47 171 609 minecraft:black_concrete
fill 47 164 617 47 171 617 minecraft:black_concrete
fill 47 164 625 47 171 625 minecraft:black_concrete
fill 47 164 633 47 171 633 minecraft:black_concrete
fill 47 164 641 47 171 641 minecraft:black_concrete
fill 50 164 646 50 171 646 minecraft:black_concrete
fill 51 164 613 52 167 613 minecraft:magenta_concrete
fill 51 164 615 52 167 615 minecraft:magenta_concrete
fill 53 164 614 53 167 614 minecraft:magenta_concrete
fill 54 164 604 54 171 604 minecraft:black_concrete
fill 58 164 646 58 171 646 minecraft:black_concrete
fill 62 164 604 62 171 604 minecraft:black_concrete
fill 66 164 646 66 171 646 minecraft:black_concrete
fill 70 164 604 70 171 604 minecraft:black_concrete
fill 74 164 646 74 171 646 minecraft:black_concrete
fill 78 164 604 78 171 604 minecraft:black_concrete
fill 82 164 646 82 171 646 minecraft:black_concrete
fill 86 164 604 86 171 604 minecraft:black_concrete
fill 89 164 609 89 171 609 minecraft:black_concrete
fill 89 164 617 89 171 617 minecraft:black_concrete
fill 89 164 625 89 171 625 minecraft:black_concrete
fill 89 164 633 89 171 633 minecraft:black_concrete
fill 89 164 641 89 171 641 minecraft:black_concrete
fill 50 165 613 50 167 615 minecraft:magenta_concrete
fill 51 165 612 52 167 612 minecraft:magenta_concrete
fill 51 165 616 52 167 616 minecraft:magenta_concrete
fill 53 165 613 53 167 613 minecraft:magenta_concrete
fill 53 165 615 53 167 615 minecraft:magenta_concrete
fill 74 165 608 74 170 608 minecraft:magenta_concrete
fill 49 166 614 49 167 614 minecraft:magenta_concrete
fill 50 166 612 50 167 612 minecraft:magenta_concrete
fill 50 166 616 50 167 616 minecraft:magenta_concrete
fill 53 166 612 53 167 612 minecraft:magenta_concrete
fill 53 166 616 53 167 616 minecraft:magenta_concrete
fill 54 166 613 54 167 615 minecraft:magenta_concrete
fill 74 166 609 74 170 609 minecraft:magenta_concrete
setblock 49 167 613 minecraft:magenta_concrete
setblock 49 167 615 minecraft:magenta_concrete
fill 51 167 611 53 167 611 minecraft:magenta_concrete
fill 51 167 617 53 167 617 minecraft:magenta_concrete
setblock 54 167 612 minecraft:magenta_concrete
setblock 54 167 616 minecraft:magenta_concrete
setblock 55 167 614 minecraft:magenta_concrete
fill 73 167 608 73 170 609 minecraft:magenta_concrete
fill 74 167 607 74 170 607 minecraft:magenta_concrete
fill 75 167 608 75 170 609 minecraft:magenta_concrete
fill 48 168 605 48 169 610 minecraft:light_gray_concrete
fill 48 168 613 56 168 618 minecraft:light_gray_concrete
fill 48 168 621 49 168 626 minecraft:light_gray_concrete
fill 48 168 629 49 168 634 minecraft:light_gray_concrete
fill 48 168 637 49 168 642 minecraft:light_gray_concrete
fill 48 168 645 53 169 645 minecraft:light_gray_concrete
fill 49 168 606 49 168 612 minecraft:light_gray_concrete
fill 49 168 619 49 168 620 minecraft:light_gray_concrete
fill 49 168 627 49 168 628 minecraft:light_gray_concrete
fill 49 168 635 49 168 636 minecraft:light_gray_concrete
fill 49 168 643 49 168 644 minecraft:light_gray_concrete
fill 50 168 606 87 168 606 minecraft:light_gray_concrete
fill 50 168 610 56 168 612 minecraft:light_gray_concrete
fill 50 168 644 88 168 644 minecraft:light_gray_concrete
fill 51 168 605 56 169 605 minecraft:light_gray_concrete
fill 56 168 645 61 169 645 minecraft:light_gray_concrete
fill 59 168 605 64 169 605 minecraft:light_gray_concrete
fill 64 168 645 69 169 645 minecraft:light_gray_concrete
fill 67 168 605 72 169 605 minecraft:light_gray_concrete
fill 67 168 615 68 169 617 minecraft:magenta_concrete
fill 72 168 608 72 170 608 minecraft:magenta_concrete
fill 72 168 645 77 169 645 minecraft:light_gray_concrete
fill 73 168 607 73 170 607 minecraft:magenta_concrete
fill 73 168 610 75 170 610 minecraft:magenta_concrete
fill 75 168 605 80 169 605 minecraft:light_gray_concrete
fill 75 168 607 75 170 607 minecraft:magenta_concrete
fill 76 168 608 76 170 608 minecraft:magenta_concrete
fill 80 168 645 85 169 645 minecraft:light_gray_concrete
fill 83 168 605 88 169 605 minecraft:light_gray_concrete
fill 87 168 607 87 168 643 minecraft:light_gray_concrete
fill 88 168 608 88 169 613 minecraft:light_gray_concrete
fill 88 168 616 88 169 621 minecraft:light_gray_concrete
fill 88 168 624 88 169 629 minecraft:light_gray_concrete
fill 88 168 632 88 169 637 minecraft:light_gray_concrete
fill 88 168 640 88 169 643 minecraft:light_gray_concrete
fill 88 168 645 88 169 645 minecraft:light_gray_concrete
setblock 48 169 611 minecraft:sea_lantern
fill 48 169 612 48 184 612 minecraft:light_gray_concrete
setblock 48 169 613 minecraft:sea_lantern
fill 48 169 614 48 184 614 minecraft:light_gray_concrete
setblock 48 169 615 minecraft:sea_lantern
fill 48 169 616 48 184 616 minecraft:light_gray_concrete
setblock 48 169 617 minecraft:sea_lantern
fill 48 169 618 48 184 618 minecraft:light_gray_concrete
fill 48 169 621 48 169 626 minecraft:light_gray_concrete
fill 48 169 629 48 169 634 minecraft:light_gray_concrete
fill 48 169 637 48 169 642 minecraft:light_gray_concrete
setblock 49 169 610 minecraft:sea_lantern
fill 49 169 611 49 184 611 minecraft:light_gray_concrete
setblock 49 169 612 minecraft:sea_lantern
fill 49 169 613 49 184 613 minecraft:light_gray_concrete
setblock 49 169 614 minecraft:sea_lantern
fill 49 169 615 49 184 615 minecraft:light_gray_concrete
setblock 49 169 616 minecraft:sea_lantern
fill 49 169 617 49 184 617 minecraft:light_gray_concrete
setblock 49 169 618 minecraft:sea_lantern
fill 50 169 610 50 184 610 minecraft:light_gray_concrete
setblock 50 169 611 minecraft:sea_lantern
fill 50 169 612 50 184 612 minecraft:light_gray_concrete
setblock 50 169 613 minecraft:sea_lantern
fill 50 169 614 50 184 614 minecraft:light_gray_concrete
setblock 50 169 615 minecraft:sea_lantern
fill 50 169 616 50 184 616 minecraft:light_gray_concrete
setblock 50 169 617 minecraft:sea_lantern
fill 50 169 618 50 184 618 minecraft:light_gray_concrete
setblock 51 169 610 minecraft:sea_lantern
fill 51 169 611 51 184 611 minecraft:light_gray_concrete
setblock 51 169 612 minecraft:sea_lantern
fill 51 169 613 51 184 613 minecraft:light_gray_concrete
setblock 51 169 614 minecraft:sea_lantern
fill 51 169 615 51 184 615 minecraft:light_gray_concrete
setblock 51 169 616 minecraft:sea_lantern
fill 51 169 617 51 184 617 minecraft:light_gray_concrete
setblock 51 169 618 minecraft:sea_lantern
fill 52 169 610 52 184 610 minecraft:light_gray_concrete
setblock 52 169 611 minecraft:sea_lantern
fill 52 169 612 52 184 612 minecraft:light_gray_concrete
setblock 52 169 613 minecraft:sea_lantern
fill 52 169 614 52 184 614 minecraft:light_gray_concrete
setblock 52 169 615 minecraft:sea_lantern
fill 52 169 616 52 184 616 minecraft:light_gray_concrete
setblock 52 169 617 minecraft:sea_lantern
fill 52 169 618 52 184 618 minecraft:light_gray_concrete
setblock 53 169 610 minecraft:sea_lantern
fill 53 169 611 53 184 611 minecraft:light_gray_concrete
setblock 53 169 612 minecraft:sea_lantern
fill 53 169 613 53 184 613 minecraft:light_gray_concrete
setblock 53 169 614 minecraft:sea_lantern
fill 53 169 615 53 184 615 minecraft:light_gray_concrete
setblock 53 169 616 minecraft:sea_lantern
fill 53 169 617 53 184 617 minecraft:light_gray_concrete
setblock 53 169 618 minecraft:sea_lantern
fill 54 169 610 54 184 610 minecraft:light_gray_concrete
setblock 54 169 611 minecraft:sea_lantern
fill 54 169 612 54 184 612 minecraft:light_gray_concrete
setblock 54 169 613 minecraft:sea_lantern
fill 54 169 614 54 184 614 minecraft:light_gray_concrete
setblock 54 169 615 minecraft:sea_lantern
fill 54 169 616 54 184 616 minecraft:light_gray_concrete
setblock 54 169 617 minecraft:sea_lantern
fill 54 169 618 54 184 618 minecraft:light_gray_concrete
setblock 55 169 610 minecraft:sea_lantern
fill 55 169 611 55 184 611 minecraft:light_gray_concrete
setblock 55 169 612 minecraft:sea_lantern
fill 55 169 613 55 184 613 minecraft:light_gray_concrete
setblock 55 169 614 minecraft:sea_lantern
fill 55 169 615 55 184 615 minecraft:light_gray_concrete
setblock 55 169 616 minecraft:sea_lantern
fill 55 169 617 55 184 617 minecraft:light_gray_concrete
setblock 55 169 618 minecraft:sea_lantern
fill 56 169 610 56 184 610 minecraft:light_gray_concrete
setblock 56 169 611 minecraft:sea_lantern
fill 56 169 612 56 184 612 minecraft:light_gray_concrete
setblock 56 169 613 minecraft:sea_lantern
fill 56 169 614 56 184 614 minecraft:light_gray_concrete
setblock 56 169 615 minecraft:sea_lantern
fill 56 169 616 56 184 616 minecraft:light_gray_concrete
setblock 56 169 617 minecraft:sea_lantern
fill 56 169 618 56 184 618 minecraft:light_gray_concrete
fill 72 169 607 72 170 607 minecraft:magenta_concrete
fill 72 169 609 72 170 609 minecraft:magenta_concrete
fill 73 169 606 75 170 606 minecraft:magenta_concrete
fill 76 169 607 76 170 607 minecraft:magenta_concrete
fill 76 169 609 76 170 609 minecraft:magenta_concrete
setblock 88 169 644 minecraft:light_gray_concrete
fill 48 170 610 48 171 611 minecraft:light_gray_concrete
fill 48 170 613 48 171 613 minecraft:light_gray_concrete
fill 48 170 615 48 171 615 minecraft:light_gray_concrete
fill 48 170 617 48 171 617 minecraft:light_gray_concrete
fill 49 170 610 49 171 610 minecraft:light_gray_concrete
fill 49 170 612 49 171 612 minecraft:light_gray_concrete
fill 49 170 614 49 171 614 minecraft:light_gray_concrete
fill 49 170 616 49 171 616 minecraft:light_gray_concrete
fill 49 170 618 49 171 618 minecraft:light_gray_concrete
fill 50 170 611 50 171 611 minecraft:light_gray_concrete
fill 50 170 613 50 171 613 minecraft:light_gray_concrete
fill 50 170 615 50 171 615 minecraft:light_gray_concrete
fill 50 170 617 50 171 617 minecraft:light_gray_concrete
fill 51 170 610 51 171 610 minecraft:light_gray_concrete
fill 51 170 612 51 171 612 minecraft:light_gray_concrete
fill 51 170 614 51 171 614 minecraft:light_gray_concrete
fill 51 170 616 51 171 616 minecraft:light_gray_concrete
fill 51 170 618 51 171 618 minecraft:light_gray_concrete
fill 52 170 611 52 171 611 minecraft:light_gray_concrete
fill 52 170 613 52 171 613 minecraft:light_gray_concrete
fill 52 170 615 52 171 615 minecraft:light_gray_concrete
fill 52 170 617 52 171 617 minecraft:light_gray_concrete
fill 53 170 610 53 171 610 minecraft:light_gray_concrete
fill 53 170 612 53 171 612 minecraft:light_gray_concrete
fill 53 170 614 53 171 614 minecraft:light_gray_concrete
fill 53 170 616 53 171 616 minecraft:light_gray_concrete
fill 53 170 618 53 171 618 minecraft:light_gray_concrete
fill 54 170 611 54 171 611 minecraft:light_gray_concrete
fill 54 170 613 54 171 613 minecraft:light_gray_concrete
fill 54 170 615 54 171 615 minecraft:light_gray_concrete
fill 54 170 617 54 171 617 minecraft:light_gray_concrete
fill 55 170 610 55 171 610 minecraft:light_gray_concrete
fill 55 170 612 55 171 612 minecraft:light_gray_concrete
fill 55 170 614 55 171 614 minecraft:light_gray_concrete
fill 55 170 616 55 171 616 minecraft:light_gray_concrete
fill 55 170 618 55 171 618 minecraft:light_gray_concrete
fill 56 170 611 56 171 611 minecraft:light_gray_concrete
fill 56 170 613 56 171 613 minecraft:light_gray_concrete
fill 56 170 615 56 171 615 minecraft:light_gray_concrete
fill 56 170 617 56 171 617 minecraft:light_gray_concrete
fill 71 170 608 71 170 609 minecraft:magenta_concrete
setblock 72 170 606 minecraft:magenta_concrete
setblock 72 170 610 minecraft:magenta_concrete
fill 73 170 611 75 170 611 minecraft:magenta_concrete
setblock 76 170 606 minecraft:magenta_concrete
setblock 76 170 610 minecraft:magenta_concrete
fill 77 170 608 77 170 609 minecraft:magenta_concrete
setblock 50 171 607 minecraft:light[level=14]
setblock 50 171 623 minecraft:light[level=14]
setblock 50 171 631 minecraft:light[level=14]
setblock 50 171 639 minecraft:light[level=14]
setblock 58 171 607 minecraft:light[level=14]
setblock 58 171 615 minecraft:light[level=14]
setblock 58 171 623 minecraft:light[level=14]
setblock 58 171 631 minecraft:light[level=14]
fill 58 171 637 58 172 637 minecraft:gray_concrete
setblock 58 171 639 minecraft:light[level=14]
setblock 66 171 607 minecraft:light[level=14]
setblock 66 171 615 minecraft:light[level=14]
setblock 66 171 623 minecraft:light[level=14]
setblock 66 171 631 minecraft:light[level=14]
setblock 66 171 639 minecraft:light[level=14]
fill 70 171 605 72 171 612 minecraft:light_gray_concrete
fill 73 171 606 78 171 612 minecraft:light_gray_concrete
setblock 74 171 615 minecraft:light[level=14]
setblock 74 171 623 minecraft:light[level=14]
setblock 74 171 631 minecraft:light[level=14]
setblock 74 171 639 minecraft:light[level=14]
fill 75 171 605 78 171 605 minecraft:light_gray_concrete
setblock 82 171 607 minecraft:light[level=14]
setblock 82 171 615 minecraft:light[level=14]
setblock 82 171 623 minecraft:light[level=14]
setblock 82 171 631 minecraft:light[level=14]
setblock 82 171 639 minecraft:light[level=14]
fill 47 172 609 47 177 609 minecraft:sea_lantern
fill 47 172 617 48 172 617 minecraft:sea_lantern
fill 47 172 625 47 177 625 minecraft:sea_lantern
fill 47 172 633 47 177 633 minecraft:sea_lantern
fill 47 172 641 47 177 641 minecraft:sea_lantern
fill 48 172 610 48 184 610 minecraft:light_gray_concrete
setblock 48 172 611 minecraft:sea_lantern
setblock 48 172 613 minecraft:sea_lantern
setblock 48 172 615 minecraft:sea_lantern
setblock 49 172 610 minecraft:sea_lantern
setblock 49 172 612 minecraft:sea_lantern
setblock 49 172 614 minecraft:sea_lantern
setblock 49 172 616 minecraft:sea_lantern
setblock 49 172 618 minecraft:sea_lantern
setblock 50 172 611 minecraft:sea_lantern
setblock 50 172 613 minecraft:sea_lantern
setblock 50 172 615 minecraft:sea_lantern
setblock 50 172 617 minecraft:sea_lantern
fill 50 172 646 50 177 646 minecraft:sea_lantern
setblock 51 172 610 minecraft:sea_lantern
setblock 51 172 612 minecraft:sea_lantern
setblock 51 172 614 minecraft:sea_lantern
setblock 51 172 616 minecraft:sea_lantern
setblock 51 172 618 minecraft:sea_lantern
setblock 52 172 611 minecraft:sea_lantern
setblock 52 172 613 minecraft:sea_lantern
setblock 52 172 615 minecraft:sea_lantern
setblock 52 172 617 minecraft:sea_lantern
setblock 53 172 610 minecraft:sea_lantern
setblock 53 172 612 minecraft:sea_lantern
setblock 53 172 614 minecraft:sea_lantern
setblock 53 172 616 minecraft:sea_lantern
setblock 53 172 618 minecraft:sea_lantern
fill 54 172 604 54 177 604 minecraft:sea_lantern
setblock 54 172 611 minecraft:sea_lantern
setblock 54 172 613 minecraft:sea_lantern
setblock 54 172 615 minecraft:sea_lantern
setblock 54 172 617 minecraft:sea_lantern
setblock 55 172 610 minecraft:sea_lantern
setblock 55 172 612 minecraft:sea_lantern
setblock 55 172 614 minecraft:sea_lantern
setblock 55 172 616 minecraft:sea_lantern
setblock 55 172 618 minecraft:sea_lantern
setblock 56 172 611 minecraft:sea_lantern
setblock 56 172 613 minecraft:sea_lantern
setblock 56 172 615 minecraft:sea_lantern
setblock 56 172 617 minecraft:sea_lantern
fill 58 172 646 58 177 646 minecraft:sea_lantern
fill 62 172 604 62 177 604 minecraft:sea_lantern
fill 66 172 646 66 177 646 minecraft:sea_lantern
fill 70 172 604 70 172 605 minecraft:sea_lantern
fill 70 172 606 70 184 606 minecraft:light_gray_concrete
setblock 70 172 607 minecraft:sea_lantern
fill 70 172 608 70 184 608 minecraft:light_gray_concrete
setblock 70 172 609 minecraft:sea_lantern
fill 70 172 610 70 184 610 minecraft:light_gray_concrete
setblock 70 172 611 minecraft:sea_lantern
fill 70 172 612 70 184 612 minecraft:light_gray_concrete
fill 71 172 605 71 184 605 minecraft:light_gray_concrete
setblock 71 172 606 minecraft:sea_lantern
fill 71 172 607 71 184 607 minecraft:light_gray_concrete
setblock 71 172 608 minecraft:sea_lantern
fill 71 172 609 71 184 609 minecraft:light_gray_concrete
setblock 71 172 610 minecraft:sea_lantern
fill 71 172 611 71 184 611 minecraft:light_gray_concrete
setblock 71 172 612 minecraft:sea_lantern
setblock 72 172 605 minecraft:sea_lantern
fill 72 172 606 72 184 606 minecraft:light_gray_concrete
setblock 72 172 607 minecraft:sea_lantern
fill 72 172 608 72 184 608 minecraft:light_gray_concrete
setblock 72 172 609 minecraft:sea_lantern
fill 72 172 610 72 184 610 minecraft:light_gray_concrete
setblock 72 172 611 minecraft:sea_lantern
fill 72 172 612 72 184 612 minecraft:light_gray_concrete
fill 73 172 605 73 184 605 minecraft:light_gray_concrete
setblock 73 172 606 minecraft:sea_lantern
fill 73 172 607 73 184 607 minecraft:light_gray_concrete
setblock 73 172 608 minecraft:sea_lantern
fill 73 172 609 73 184 609 minecraft:light_gray_concrete
setblock 73 172 610 minecraft:sea_lantern
fill 73 172 611 73 184 611 minecraft:light_gray_concrete
setblock 73 172 612 minecraft:sea_lantern
setblock 74 172 605 minecraft:sea_lantern
fill 74 172 606 74 184 606 minecraft:light_gray_concrete
setblock 74 172 607 minecraft:sea_lantern
fill 74 172 608 74 184 608 minecraft:light_gray_concrete
setblock 74 172 609 minecraft:sea_lantern
fill 74 172 610 74 184 610 minecraft:light_gray_concrete
setblock 74 172 611 minecraft:sea_lantern
fill 74 172 612 74 184 612 minecraft:light_gray_concrete
fill 74 172 646 74 177 646 minecraft:sea_lantern
fill 75 172 605 75 184 605 minecraft:light_gray_concrete
setblock 75 172 606 minecraft:sea_lantern
fill 75 172 607 75 184 607 minecraft:light_gray_concrete
setblock 75 172 608 minecraft:sea_lantern
fill 75 172 609 75 184 609 minecraft:light_gray_concrete
setblock 75 172 610 minecraft:sea_lantern
fill 75 172 611 75 184 611 minecraft:light_gray_concrete
setblock 75 172 612 minecraft:sea_lantern
setblock 76 172 605 minecraft:sea_lantern
fill 76 172 606 76 184 606 minecraft:light_gray_concrete
setblock 76 172 607 minecraft:sea_lantern
fill 76 172 608 76 184 608 minecraft:light_gray_concrete
setblock 76 172 609 minecraft:sea_lantern
fill 76 172 610 76 184 610 minecraft:light_gray_concrete
setblock 76 172 611 minecraft:sea_lantern
fill 76 172 612 76 184 612 minecraft:light_gray_concrete
fill 77 172 605 77 184 605 minecraft:light_gray_concrete
setblock 77 172 606 minecraft:sea_lantern
fill 77 172 607 77 184 607 minecraft:light_gray_concrete
setblock 77 172 608 minecraft:sea_lantern
fill 77 172 609 77 184 609 minecraft:light_gray_concrete
setblock 77 172 610 minecraft:sea_lantern
fill 77 172 611 77 184 611 minecraft:light_gray_concrete
setblock 77 172 612 minecraft:sea_lantern
fill 78 172 604 78 172 605 minecraft:sea_lantern
fill 78 172 606 78 184 606 minecraft:light_gray_concrete
setblock 78 172 607 minecraft:sea_lantern
fill 78 172 608 78 184 608 minecraft:light_gray_concrete
setblock 78 172 609 minecraft:sea_lantern
fill 78 172 610 78 184 610 minecraft:light_gray_concrete
setblock 78 172 611 minecraft:sea_lantern
fill 78 172 612 78 184 612 minecraft:light_gray_concrete
fill 82 172 646 82 177 646 minecraft:sea_lantern
fill 86 172 604 86 177 604 minecraft:sea_lantern
fill 89 172 609 89 177 609 minecraft:sea_lantern
fill 89 172 617 89 177 617 minecraft:sea_lantern
fill 89 172 625 89 177 625 minecraft:sea_lantern
fill 89 172 633 89 177 633 minecraft:sea_lantern
fill 89 172 641 89 177 641 minecraft:sea_lantern
fill 47 173 617 47 177 617 minecraft:sea_lantern
fill 48 173 611 48 174 611 minecraft:light_gray_concrete
fill 48 173 613 48 174 613 minecraft:light_gray_concrete
fill 48 173 615 48 174 615 minecraft:light_gray_concrete
fill 48 173 617 48 174 617 minecraft:light_gray_concrete
fill 49 173 610 49 174 610 minecraft:light_gray_concrete
fill 49 173 612 49 174 612 minecraft:light_gray_concrete
fill 49 173 614 49 174 614 minecraft:light_gray_concrete
fill 49 173 616 49 174 616 minecraft:light_gray_concrete
fill 49 173 618 49 174 618 minecraft:light_gray_concrete
fill 50 173 611 50 174 611 minecraft:light_gray_concrete
fill 50 173 613 50 174 613 minecraft:light_gray_concrete
fill 50 173 615 50 174 615 minecraft:light_gray_concrete
fill 50 173 617 50 174 617 minecraft:light_gray_concrete
fill 51 173 610 51 174 610 minecraft:light_gray_concrete
fill 51 173 612 51 174 612 minecraft:light_gray_concrete
fill 51 173 614 51 174 614 minecraft:light_gray_concrete
fill 51 173 616 51 174 616 minecraft:light_gray_concrete
fill 51 173 618 51 174 618 minecraft:light_gray_concrete
fill 52 173 611 52 174 611 minecraft:light_gray_concrete
fill 52 173 613 52 174 613 minecraft:light_gray_concrete
fill 52 173 615 52 174 615 minecraft:light_gray_concrete
fill 52 173 617 52 174 617 minecraft:light_gray_concrete
fill 53 173 610 53 174 610 minecraft:light_gray_concrete
fill 53 173 612 53 174 612 minecraft:light_gray_concrete
fill 53 173 614 53 174 614 minecraft:light_gray_concrete
fill 53 173 616 53 174 616 minecraft:light_gray_concrete
fill 53 173 618 53 174 618 minecraft:light_gray_concrete
fill 54 173 611 54 174 611 minecraft:light_gray_concrete
fill 54 173 613 54 174 613 minecraft:light_gray_concrete
fill 54 173 615 54 174 615 minecraft:light_gray_concrete
fill 54 173 617 54 174 617 minecraft:light_gray_concrete
fill 55 173 610 55 174 610 minecraft:light_gray_concrete
fill 55 173 612 55 174 612 minecraft:light_gray_concrete
fill 55 173 614 55 174 614 minecraft:light_gray_concrete
fill 55 173 616 55 174 616 minecraft:light_gray_concrete
fill 55 173 618 55 174 618 minecraft:light_gray_concrete
fill 56 173 611 56 174 611 minecraft:light_gray_concrete
fill 56 173 613 56 174 613 minecraft:light_gray_concrete
fill 56 173 615 56 174 615 minecraft:light_gray_concrete
fill 56 173 617 56 174 617 minecraft:light_gray_concrete
fill 70 173 604 70 177 604 minecraft:sea_lantern
fill 70 173 605 70 174 605 minecraft:light_gray_concrete
fill 70 173 607 70 174 607 minecraft:light_gray_concrete
fill 70 173 609 70 174 609 minecraft:light_gray_concrete
fill 70 173 611 70 174 611 minecraft:light_gray_concrete
fill 71 173 606 71 174 606 minecraft:light_gray_concrete
fill 71 173 608 71 174 608 minecraft:light_gray_concrete
fill 71 173 610 71 174 610 minecraft:light_gray_concrete
fill 71 173 612 71 174 612 minecraft:light_gray_concrete
fill 72 173 605 72 174 605 minecraft:light_gray_concrete
fill 72 173 607 72 174 607 minecraft:light_gray_concrete
fill 72 173 609 72 174 609 minecraft:light_gray_concrete
fill 72 173 611 72 174 611 minecraft:light_gray_concrete
fill 73 173 606 73 174 606 minecraft:light_gray_concrete
fill 73 173 608 73 174 608 minecraft:light_gray_concrete
fill 73 173 610 73 174 610 minecraft:light_gray_concrete
fill 73 173 612 73 174 612 minecraft:light_gray_concrete
fill 74 173 605 74 174 605 minecraft:light_gray_concrete
fill 74 173 607 74 174 607 minecraft:light_gray_concrete
fill 74 173 609 74 174 609 minecraft:light_gray_concrete
fill 74 173 611 74 174 611 minecraft:light_gray_concrete
fill 75 173 606 75 174 606 minecraft:light_gray_concrete
fill 75 173 608 75 174 608 minecraft:light_gray_concrete
fill 75 173 610 75 174 610 minecraft:light_gray_concrete
fill 75 173 612 75 174 612 minecraft:light_gray_concrete
fill 76 173 605 76 174 605 minecraft:light_gray_concrete
fill 76 173 607 76 174 607 minecraft:light_gray_concrete
fill 76 173 609 76 174 609 minecraft:light_gray_concrete
fill 76 173 611 76 174 611 minecraft:light_gray_concrete
fill 77 173 606 77 174 606 minecraft:light_gray_concrete
fill 77 173 608 77 174 608 minecraft:light_gray_concrete
fill 77 173 610 77 174 610 minecraft:light_gray_concrete
fill 77 173 612 77 174 612 minecraft:light_gray_concrete
fill 78 173 604 78 177 604 minecraft:sea_lantern
fill 78 173 605 78 174 605 minecraft:light_gray_concrete
fill 78 173 607 78 174 607 minecraft:light_gray_concrete
fill 78 173 609 78 174 609 minecraft:light_gray_concrete
fill 78 173 611 78 174 611 minecraft:light_gray_concrete
setblock 48 175 611 minecraft:sea_lantern
setblock 48 175 613 minecraft:sea_lantern
setblock 48 175 615 minecraft:sea_lantern
setblock 48 175 617 minecraft:sea_lantern
setblock 49 175 610 minecraft:sea_lantern
setblock 49 175 612 minecraft:sea_lantern
setblock 49 175 614 minecraft:sea_lantern
setblock 49 175 616 minecraft:sea_lantern
setblock 49 175 618 minecraft:sea_lantern
setblock 50 175 611 minecraft:sea_lantern
setblock 50 175 613 minecraft:sea_lantern
setblock 50 175 615 minecraft:sea_lantern
setblock 50 175 617 minecraft:sea_lantern
setblock 51 175 610 minecraft:sea_lantern
setblock 51 175 612 minecraft:sea_lantern
setblock 51 175 614 minecraft:sea_lantern
setblock 51 175 616 minecraft:sea_lantern
setblock 51 175 618 minecraft:sea_lantern
setblock 52 175 611 minecraft:sea_lantern
setblock 52 175 613 minecraft:sea_lantern
setblock 52 175 615 minecraft:sea_lantern
setblock 52 175 617 minecraft:sea_lantern
setblock 53 175 610 minecraft:sea_lantern
setblock 53 175 612 minecraft:sea_lantern
setblock 53 175 614 minecraft:sea_lantern
setblock 53 175 616 minecraft:sea_lantern
setblock 53 175 618 minecraft:sea_lantern
setblock 54 175 611 minecraft:sea_lantern
setblock 54 175 613 minecraft:sea_lantern
setblock 54 175 615 minecraft:sea_lantern
setblock 54 175 617 minecraft:sea_lantern
setblock 55 175 610 minecraft:sea_lantern
setblock 55 175 612 minecraft:sea_lantern
setblock 55 175 614 minecraft:sea_lantern
setblock 55 175 616 minecraft:sea_lantern
setblock 55 175 618 minecraft:sea_lantern
setblock 56 175 611 minecraft:sea_lantern
setblock 56 175 613 minecraft:sea_lantern
setblock 56 175 615 minecraft:sea_lantern
setblock 56 175 617 minecraft:sea_lantern
setblock 70 175 605 minecraft:sea_lantern
setblock 70 175 607 minecraft:sea_lantern
setblock 70 175 609 minecraft:sea_lantern
setblock 70 175 611 minecraft:sea_lantern
setblock 71 175 606 minecraft:sea_lantern
setblock 71 175 608 minecraft:sea_lantern
setblock 71 175 610 minecraft:sea_lantern
setblock 71 175 612 minecraft:sea_lantern
setblock 72 175 605 minecraft:sea_lantern
setblock 72 175 607 minecraft:sea_lantern
setblock 72 175 609 minecraft:sea_lantern
setblock 72 175 611 minecraft:sea_lantern
setblock 73 175 606 minecraft:sea_lantern
setblock 73 175 608 minecraft:sea_lantern
setblock 73 175 610 minecraft:sea_lantern
setblock 73 175 612 minecraft:sea_lantern
setblock 74 175 605 minecraft:sea_lantern
setblock 74 175 607 minecraft:sea_lantern
setblock 74 175 609 minecraft:sea_lantern
setblock 74 175 611 minecraft:sea_lantern
setblock 75 175 606 minecraft:sea_lantern
setblock 75 175 608 minecraft:sea_lantern
setblock 75 175 610 minecraft:sea_lantern
setblock 75 175 612 minecraft:sea_lantern
setblock 76 175 605 minecraft:sea_lantern
setblock 76 175 607 minecraft:sea_lantern
setblock 76 175 609 minecraft:sea_lantern
setblock 76 175 611 minecraft:sea_lantern
setblock 77 175 606 minecraft:sea_lantern
setblock 77 175 608 minecraft:sea_lantern
setblock 77 175 610 minecraft:sea_lantern
setblock 77 175 612 minecraft:sea_lantern
setblock 78 175 605 minecraft:sea_lantern
setblock 78 175 607 minecraft:sea_lantern
setblock 78 175 609 minecraft:sea_lantern
setblock 78 175 611 minecraft:sea_lantern
fill 48 176 611 48 177 611 minecraft:light_gray_concrete
fill 48 176 613 48 177 613 minecraft:light_gray_concrete
fill 48 176 615 48 177 615 minecraft:light_gray_concrete
fill 48 176 617 48 177 617 minecraft:light_gray_concrete
fill 49 176 610 49 177 610 minecraft:light_gray_concrete
fill 49 176 612 49 177 612 minecraft:light_gray_concrete
fill 49 176 614 49 177 614 minecraft:light_gray_concrete
fill 49 176 616 49 177 616 minecraft:light_gray_concrete
fill 49 176 618 49 177 618 minecraft:light_gray_concrete
fill 50 176 611 50 177 611 minecraft:light_gray_concrete
fill 50 176 613 50 177 613 minecraft:light_gray_concrete
fill 50 176 615 50 177 615 minecraft:light_gray_concrete
fill 50 176 617 50 177 617 minecraft:light_gray_concrete
fill 51 176 610 51 177 610 minecraft:light_gray_concrete
fill 51 176 612 51 177 612 minecraft:light_gray_concrete
fill 51 176 614 51 177 614 minecraft:light_gray_concrete
fill 51 176 616 51 177 616 minecraft:light_gray_concrete
fill 51 176 618 51 177 618 minecraft:light_gray_concrete
fill 52 176 611 52 177 611 minecraft:light_gray_concrete
fill 52 176 613 52 177 613 minecraft:light_gray_concrete
fill 52 176 615 52 177 615 minecraft:light_gray_concrete
fill 52 176 617 52 177 617 minecraft:light_gray_concrete
fill 53 176 610 53 177 610 minecraft:light_gray_concrete
fill 53 176 612 53 177 612 minecraft:light_gray_concrete
fill 53 176 614 53 177 614 minecraft:light_gray_concrete
fill 53 176 616 53 177 616 minecraft:light_gray_concrete
fill 53 176 618 53 177 618 minecraft:light_gray_concrete
fill 54 176 611 54 177 611 minecraft:light_gray_concrete
fill 54 176 613 54 177 613 minecraft:light_gray_concrete
fill 54 176 615 54 177 615 minecraft:light_gray_concrete
fill 54 176 617 54 177 617 minecraft:light_gray_concrete
fill 55 176 610 55 177 610 minecraft:light_gray_concrete
fill 55 176 612 55 177 612 minecraft:light_gray_concrete
fill 55 176 614 55 177 614 minecraft:light_gray_concrete
fill 55 176 616 55 177 616 minecraft:light_gray_concrete
fill 55 176 618 55 177 618 minecraft:light_gray_concrete
fill 56 176 611 56 177 611 minecraft:light_gray_concrete
fill 56 176 613 56 177 613 minecraft:light_gray_concrete
fill 56 176 615 56 177 615 minecraft:light_gray_concrete
fill 56 176 617 56 177 617 minecraft:light_gray_concrete
fill 70 176 605 70 177 605 minecraft:light_gray_concrete
fill 70 176 607 70 177 607 minecraft:light_gray_concrete
fill 70 176 609 70 177 609 minecraft:light_gray_concrete
fill 70 176 611 70 177 611 minecraft:light_gray_concrete
fill 71 176 606 71 177 606 minecraft:light_gray_concrete
fill 71 176 608 71 177 608 minecraft:light_gray_concrete
fill 71 176 610 71 177 610 minecraft:light_gray_concrete
fill 71 176 612 71 177 612 minecraft:light_gray_concrete
fill 72 176 605 72 177 605 minecraft:light_gray_concrete
fill 72 176 607 72 177 607 minecraft:light_gray_concrete
fill 72 176 609 72 177 609 minecraft:light_gray_concrete
fill 72 176 611 72 177 611 minecraft:light_gray_concrete
fill 73 176 606 73 177 606 minecraft:light_gray_concrete
fill 73 176 608 73 177 608 minecraft:light_gray_concrete
fill 73 176 610 73 177 610 minecraft:light_gray_concrete
fill 73 176 612 73 177 612 minecraft:light_gray_concrete
fill 74 176 605 74 177 605 minecraft:light_gray_concrete
fill 74 176 607 74 177 607 minecraft:light_gray_concrete
fill 74 176 609 74 177 609 minecraft:light_gray_concrete
fill 74 176 611 74 177 611 minecraft:light_gray_concrete
fill 75 176 606 75 177 606 minecraft:light_gray_concrete
fill 75 176 608 75 177 608 minecraft:light_gray_concrete
fill 75 176 610 75 177 610 minecraft:light_gray_concrete
fill 75 176 612 75 177 612 minecraft:light_gray_concrete
fill 76 176 605 76 177 605 minecraft:light_gray_concrete
fill 76 176 607 76 177 607 minecraft:light_gray_concrete
fill 76 176 609 76 177 609 minecraft:light_gray_concrete
fill 76 176 611 76 177 611 minecraft:light_gray_concrete
fill 77 176 606 77 177 606 minecraft:light_gray_concrete
fill 77 176 608 77 177 608 minecraft:light_gray_concrete
fill 77 176 610 77 177 610 minecraft:light_gray_concrete
fill 77 176 612 77 177 612 minecraft:light_gray_concrete
fill 78 176 605 78 177 605 minecraft:light_gray_concrete
fill 78 176 607 78 177 607 minecraft:light_gray_concrete
fill 78 176 609 78 177 609 minecraft:light_gray_concrete
fill 78 176 611 78 177 611 minecraft:light_gray_concrete
fill 78 176 636 79 177 637 minecraft:magenta_concrete
fill 64 177 635 65 178 636 minecraft:glass
fill 47 178 609 47 199 609 minecraft:black_concrete
fill 47 178 617 47 199 617 minecraft:black_concrete
fill 47 178 625 47 199 625 minecraft:black_concrete
fill 47 178 633 47 199 633 minecraft:black_concrete
fill 47 178 641 47 199 641 minecraft:black_concrete
setblock 48 178 611 minecraft:sea_lantern
setblock 48 178 613 minecraft:sea_lantern
setblock 48 178 615 minecraft:sea_lantern
setblock 48 178 617 minecraft:sea_lantern
setblock 49 178 610 minecraft:sea_lantern
setblock 49 178 612 minecraft:sea_lantern
setblock 49 178 614 minecraft:sea_lantern
setblock 49 178 616 minecraft:sea_lantern
setblock 49 178 618 minecraft:sea_lantern
setblock 50 178 611 minecraft:sea_lantern
setblock 50 178 613 minecraft:sea_lantern
setblock 50 178 615 minecraft:sea_lantern
setblock 50 178 617 minecraft:sea_lantern
fill 50 178 646 50 199 646 minecraft:black_concrete
setblock 51 178 610 minecraft:sea_lantern
setblock 51 178 612 minecraft:sea_lantern
setblock 51 178 614 minecraft:sea_lantern
setblock 51 178 616 minecraft:sea_lantern
setblock 51 178 618 minecraft:sea_lantern
setblock 52 178 611 minecraft:sea_lantern
setblock 52 178 613 minecraft:sea_lantern
setblock 52 178 615 minecraft:sea_lantern
setblock 52 178 617 minecraft:sea_lantern
setblock 53 178 610 minecraft:sea_lantern
setblock 53 178 612 minecraft:sea_lantern
setblock 53 178 614 minecraft:sea_lantern
setblock 53 178 616 minecraft:sea_lantern
setblock 53 178 618 minecraft:sea_lantern
fill 54 178 604 54 199 604 minecraft:black_concrete
setblock 54 178 611 minecraft:sea_lantern
setblock 54 178 613 minecraft:sea_lantern
setblock 54 178 615 minecraft:sea_lantern
setblock 54 178 617 minecraft:sea_lantern
setblock 55 178 610 minecraft:sea_lantern
setblock 55 178 612 minecraft:sea_lantern
setblock 55 178 614 minecraft:sea_lantern
setblock 55 178 616 minecraft:sea_lantern
setblock 55 178 618 minecraft:sea_lantern
setblock 56 178 611 minecraft:sea_lantern
setblock 56 178 613 minecraft:sea_lantern
setblock 56 178 615 minecraft:sea_lantern
setblock 56 178 617 minecraft:sea_lantern
fill 58 178 646 58 199 646 minecraft:black_concrete
fill 62 178 604 62 199 604 minecraft:black_concrete
fill 66 178 646 66 199 646 minecraft:black_concrete
fill 70 178 604 70 199 604 minecraft:black_concrete
setblock 70 178 605 minecraft:sea_lantern
setblock 70 178 607 minecraft:sea_lantern
setblock 70 178 609 minecraft:sea_lantern
setblock 70 178 611 minecraft:sea_lantern
setblock 71 178 606 minecraft:sea_lantern
setblock 71 178 608 minecraft:sea_lantern
setblock 71 178 610 minecraft:sea_lantern
setblock 71 178 612 minecraft:sea_lantern
setblock 72 178 605 minecraft:sea_lantern
setblock 72 178 607 minecraft:sea_lantern
setblock 72 178 609 minecraft:sea_lantern
setblock 72 178 611 minecraft:sea_lantern
setblock 73 178 606 minecraft:sea_lantern
setblock 73 178 608 minecraft:sea_lantern
setblock 73 178 610 minecraft:sea_lantern
setblock 73 178 612 minecraft:sea_lantern
setblock 74 178 605 minecraft:sea_lantern
setblock 74 178 607 minecraft:sea_lantern
setblock 74 178 609 minecraft:sea_lantern
setblock 74 178 611 minecraft:sea_lantern
fill 74 178 646 74 199 646 minecraft:black_concrete
setblock 75 178 606 minecraft:sea_lantern
setblock 75 178 608 minecraft:sea_lantern
setblock 75 178 610 minecraft:sea_lantern
setblock 75 178 612 minecraft:sea_lantern
setblock 76 178 605 minecraft:sea_lantern
setblock 76 178 607 minecraft:sea_lantern
setblock 76 178 609 minecraft:sea_lantern
setblock 76 178 611 minecraft:sea_lantern
setblock 77 178 606 minecraft:sea_lantern
setblock 77 178 608 minecraft:sea_lantern
setblock 77 178 610 minecraft:sea_lantern
setblock 77 178 612 minecraft:sea_lantern
fill 78 178 604 78 199 604 minecraft:black_concrete
setblock 78 178 605 minecraft:sea_lantern
setblock 78 178 607 minecraft:sea_lantern
setblock 78 178 609 minecraft:sea_lantern
setblock 78 178 611 minecraft:sea_lantern
fill 82 178 646 82 199 646 minecraft:black_concrete
fill 86 178 604 86 199 604 minecraft:black_concrete
fill 89 178 609 89 199 609 minecraft:black_concrete
fill 89 178 617 89 199 617 minecraft:black_concrete
fill 89 178 625 89 199 625 minecraft:black_concrete
fill 89 178 633 89 199 633 minecraft:black_concrete
fill 89 178 641 89 199 641 minecraft:black_concrete
fill 48 179 611 48 180 611 minecraft:light_gray_concrete
fill 48 179 613 48 180 613 minecraft:light_gray_concrete
fill 48 179 615 48 180 615 minecraft:light_gray_concrete
fill 48 179 617 48 180 617 minecraft:light_gray_concrete
fill 49 179 610 49 180 610 minecraft:light_gray_concrete
fill 49 179 612 49 180 612 minecraft:light_gray_concrete
fill 49 179 614 49 180 614 minecraft:light_gray_concrete
fill 49 179 616 49 180 616 minecraft:light_gray_concrete
fill 49 179 618 49 180 618 minecraft:light_gray_concrete
setblock 50 179 607 minecraft:light[level=14]
fill 50 179 611 50 180 611 minecraft:light_gray_concrete
fill 50 179 613 50 180 613 minecraft:light_gray_concrete
fill 50 179 615 50 180 615 minecraft:light_gray_concrete
fill 50 179 617 50 180 617 minecraft:light_gray_concrete
setblock 50 179 623 minecraft:light[level=14]
setblock 50 179 631 minecraft:light[level=14]
setblock 50 179 639 minecraft:light[level=14]
fill 51 179 610 51 180 610 minecraft:light_gray_concrete
fill 51 179 612 51 180 612 minecraft:light_gray_concrete
fill 51 179 614 51 180 614 minecraft:light_gray_concrete
fill 51 179 616 51 180 616 minecraft:light_gray_concrete
fill 51 179 618 51 180 618 minecraft:light_gray_concrete
fill 52 179 611 52 180 611 minecraft:light_gray_concrete
fill 52 179 613 52 180 613 minecraft:light_gray_concrete
fill 52 179 615 52 180 615 minecraft:light_gray_concrete
fill 52 179 617 52 180 617 minecraft:light_gray_concrete
fill 52 179 627 52 180 628 minecraft:gray_concrete
fill 53 179 610 53 180 610 minecraft:light_gray_concrete
fill 53 179 612 53 180 612 minecraft:light_gray_concrete
fill 53 179 614 53 180 614 minecraft:light_gray_concrete
fill 53 179 616 53 180 616 minecraft:light_gray_concrete
fill 53 179 618 53 180 618 minecraft:light_gray_concrete
fill 54 179 611 54 180 611 minecraft:light_gray_concrete
fill 54 179 613 54 180 613 minecraft:light_gray_concrete
fill 54 179 615 54 180 615 minecraft:light_gray_concrete
fill 54 179 617 54 180 617 minecraft:light_gray_concrete
fill 55 179 610 55 180 610 minecraft:light_gray_concrete
fill 55 179 612 55 180 612 minecraft:light_gray_concrete
fill 55 179 614 55 180 614 minecraft:light_gray_concrete
fill 55 179 616 55 180 616 minecraft:light_gray_concrete
fill 55 179 618 55 180 618 minecraft:light_gray_concrete
fill 56 179 611 56 180 611 minecraft:light_gray_concrete
fill 56 179 613 56 180 613 minecraft:light_gray_concrete
fill 56 179 615 56 180 615 minecraft:light_gray_concrete
fill 56 179 617 56 180 617 minecraft:light_gray_concrete
setblock 58 179 607 minecraft:light[level=14]
setblock 58 179 615 minecraft:light[level=14]
setblock 58 179 623 minecraft:light[level=14]
setblock 58 179 631 minecraft:light[level=14]
setblock 58 179 639 minecraft:light[level=14]
setblock 66 179 607 minecraft:light[level=14]
setblock 66 179 615 minecraft:light[level=14]
setblock 66 179 623 minecraft:light[level=14]
setblock 66 179 631 minecraft:light[level=14]
setblock 66 179 639 minecraft:light[level=14]
fill 70 179 605 70 180 605 minecraft:light_gray_concrete
fill 70 179 607 70 180 607 minecraft:light_gray_concrete
fill 70 179 609 70 180 609 minecraft:light_gray_concrete
fill 70 179 611 70 180 611 minecraft:light_gray_concrete
fill 71 179 606 71 180 606 minecraft:light_gray_concrete
fill 71 179 608 71 180 608 minecraft:light_gray_concrete
fill 71 179 610 71 180 610 minecraft:light_gray_concrete
fill 71 179 612 71 180 612 minecraft:light_gray_concrete
fill 72 179 605 72 180 605 minecraft:light_gray_concrete
fill 72 179 607 72 180 607 minecraft:light_gray_concrete
fill 72 179 609 72 180 609 minecraft:light_gray_concrete
fill 72 179 611 72 180 611 minecraft:light_gray_concrete
fill 73 179 606 73 180 606 minecraft:light_gray_concrete
fill 73 179 608 73 180 608 minecraft:light_gray_concrete
fill 73 179 610 73 180 610 minecraft:light_gray_concrete
fill 73 179 612 73 180 612 minecraft:light_gray_concrete
fill 74 179 605 74 180 605 minecraft:light_gray_concrete
fill 74 179 607 74 180 607 minecraft:light_gray_concrete
fill 74 179 609 74 180 609 minecraft:light_gray_concrete
fill 74 179 611 74 180 611 minecraft:light_gray_concrete
setblock 74 179 615 minecraft:light[level=14]
setblock 74 179 623 minecraft:light[level=14]
setblock 74 179 631 minecraft:light[level=14]
setblock 74 179 639 minecraft:light[level=14]
fill 75 179 606 75 180 606 minecraft:light_gray_concrete
fill 75 179 608 75 180 608 minecraft:light_gray_concrete
fill 75 179 610 75 180 610 minecraft:light_gray_concrete
fill 75 179 612 75 180 612 minecraft:light_gray_concrete
fill 76 179 605 76 180 605 minecraft:light_gray_concrete
fill 76 179 607 76 180 607 minecraft:light_gray_concrete
fill 76 179 609 76 180 609 minecraft:light_gray_concrete
fill 76 179 611 76 180 611 minecraft:light_gray_concrete
fill 77 179 606 77 180 606 minecraft:light_gray_concrete
fill 77 179 608 77 180 608 minecraft:light_gray_concrete
fill 77 179 610 77 180 610 minecraft:light_gray_concrete
fill 77 179 612 77 180 612 minecraft:light_gray_concrete
fill 78 179 605 78 180 605 minecraft:light_gray_concrete
fill 78 179 607 78 180 607 minecraft:light_gray_concrete
fill 78 179 609 78 180 609 minecraft:light_gray_concrete
fill 78 179 611 78 180 611 minecraft:light_gray_concrete
setblock 82 179 607 minecraft:light[level=14]
setblock 82 179 615 minecraft:light[level=14]
setblock 82 179 623 minecraft:light[level=14]
setblock 82 179 631 minecraft:light[level=14]
setblock 82 179 639 minecraft:light[level=14]
fill 76 180 614 78 181 614 minecraft:glass
fill 77 180 613 77 181 613 minecraft:glass
fill 77 180 615 77 181 615 minecraft:glass
setblock 48 181 611 minecraft:sea_lantern
setblock 48 181 613 minecraft:sea_lantern
setblock 48 181 615 minecraft:sea_lantern
setblock 48 181 617 minecraft:sea_lantern
setblock 49 181 610 minecraft:sea_lantern
setblock 49 181 612 minecraft:sea_lantern
setblock 49 181 614 minecraft:sea_lantern
setblock 49 181 616 minecraft:sea_lantern
setblock 49 181 618 minecraft:sea_lantern
setblock 50 181 611 minecraft:sea_lantern
setblock 50 181 613 minecraft:sea_lantern
setblock 50 181 615 minecraft:sea_lantern
setblock 50 181 617 minecraft:sea_lantern
setblock 51 181 610 minecraft:sea_lantern
setblock 51 181 612 minecraft:sea_lantern
setblock 51 181 614 minecraft:sea_lantern
setblock 51 181 616 minecraft:sea_lantern
setblock 51 181 618 minecraft:sea_lantern
setblock 52 181 611 minecraft:sea_lantern
setblock 52 181 613 minecraft:sea_lantern
setblock 52 181 615 minecraft:sea_lantern
setblock 52 181 617 minecraft:sea_lantern
setblock 53 181 610 minecraft:sea_lantern
setblock 53 181 612 minecraft:sea_lantern
setblock 53 181 614 minecraft:sea_lantern
setblock 53 181 616 minecraft:sea_lantern
setblock 53 181 618 minecraft:sea_lantern
setblock 54 181 611 minecraft:sea_lantern
setblock 54 181 613 minecraft:sea_lantern
setblock 54 181 615 minecraft:sea_lantern
setblock 54 181 617 minecraft:sea_lantern
setblock 55 181 610 minecraft:sea_lantern
setblock 55 181 612 minecraft:sea_lantern
setblock 55 181 614 minecraft:sea_lantern
setblock 55 181 616 minecraft:sea_lantern
setblock 55 181 618 minecraft:sea_lantern
setblock 56 181 611 minecraft:sea_lantern
setblock 56 181 613 minecraft:sea_lantern
setblock 56 181 615 minecraft:sea_lantern
setblock 56 181 617 minecraft:sea_lantern
setblock 70 181 605 minecraft:sea_lantern
setblock 70 181 607 minecraft:sea_lantern
setblock 70 181 609 minecraft:sea_lantern
setblock 70 181 611 minecraft:sea_lantern
setblock 71 181 606 minecraft:sea_lantern
setblock 71 181 608 minecraft:sea_lantern
setblock 71 181 610 minecraft:sea_lantern
setblock 71 181 612 minecraft:sea_lantern
setblock 72 181 605 minecraft:sea_lantern
setblock 72 181 607 minecraft:sea_lantern
setblock 72 181 609 minecraft:sea_lantern
setblock 72 181 611 minecraft:sea_lantern
setblock 73 181 606 minecraft:sea_lantern
setblock 73 181 608 minecraft:sea_lantern
setblock 73 181 610 minecraft:sea_lantern
setblock 73 181 612 minecraft:sea_lantern
setblock 74 181 605 minecraft:sea_lantern
setblock 74 181 607 minecraft:sea_lantern
setblock 74 181 609 minecraft:sea_lantern
setblock 74 181 611 minecraft:sea_lantern
setblock 75 181 606 minecraft:sea_lantern
setblock 75 181 608 minecraft:sea_lantern
setblock 75 181 610 minecraft:sea_lantern
setblock 75 181 612 minecraft:sea_lantern
setblock 76 181 605 minecraft:sea_lantern
setblock 76 181 607 minecraft:sea_lantern
setblock 76 181 609 minecraft:sea_lantern
setblock 76 181 611 minecraft:sea_lantern
setblock 77 181 606 minecraft:sea_lantern
setblock 77 181 608 minecraft:sea_lantern
setblock 77 181 610 minecraft:sea_lantern
setblock 77 181 612 minecraft:sea_lantern
setblock 78 181 605 minecraft:sea_lantern
setblock 78 181 607 minecraft:sea_lantern
setblock 78 181 609 minecraft:sea_lantern
setblock 78 181 611 minecraft:sea_lantern
fill 48 182 605 48 183 609 minecraft:light_gray_concrete
fill 48 182 611 48 184 611 minecraft:light_gray_concrete
fill 48 182 613 48 184 613 minecraft:light_gray_concrete
fill 48 182 615 48 184 615 minecraft:light_gray_concrete
fill 48 182 617 48 184 617 minecraft:light_gray_concrete
fill 48 182 621 49 182 626 minecraft:light_gray_concrete
fill 48 182 629 49 182 634 minecraft:light_gray_concrete
fill 48 182 637 49 182 642 minecraft:light_gray_concrete
fill 48 182 645 53 183 645 minecraft:light_gray_concrete
fill 49 182 606 49 182 610 minecraft:light_gray_concrete
fill 49 182 612 49 184 612 minecraft:light_gray_concrete
fill 49 182 614 49 184 614 minecraft:light_gray_concrete
fill 49 182 616 49 184 616 minecraft:light_gray_concrete
fill 49 182 618 49 182 620 minecraft:light_gray_concrete
fill 49 182 627 49 182 628 minecraft:light_gray_concrete
fill 49 182 635 49 182 636 minecraft:light_gray_concrete
fill 49 182 643 49 182 644 minecraft:light_gray_concrete
fill 50 182 606 69 182 606 minecraft:light_gray_concrete
fill 50 182 611 50 184 611 minecraft:light_gray_concrete
fill 50 182 613 50 184 613 minecraft:light_gray_concrete
fill 50 182 615 50 184 615 minecraft:light_gray_concrete
fill 50 182 617 50 184 617 minecraft:light_gray_concrete
fill 50 182 644 88 182 644 minecraft:light_gray_concrete
fill 51 182 605 56 183 605 minecraft:light_gray_concrete
fill 51 182 610 51 184 610 minecraft:light_gray_concrete
fill 51 182 612 51 184 612 minecraft:light_gray_concrete
fill 51 182 614 51 184 614 minecraft:light_gray_concrete
fill 51 182 616 51 184 616 minecraft:light_gray_concrete
fill 51 182 618 51 184 618 minecraft:light_gray_concrete
fill 52 182 611 52 184 611 minecraft:light_gray_concrete
fill 52 182 613 52 184 613 minecraft:light_gray_concrete
fill 52 182 615 52 184 615 minecraft:light_gray_concrete
fill 52 182 617 52 184 617 minecraft:light_gray_concrete
fill 53 182 610 53 184 610 minecraft:light_gray_concrete
fill 53 182 612 53 184 612 minecraft:light_gray_concrete
fill 53 182 614 53 184 614 minecraft:light_gray_concrete
fill 53 182 616 53 184 616 minecraft:light_gray_concrete
fill 53 182 618 53 184 618 minecraft:light_gray_concrete
fill 54 182 611 54 184 611 minecraft:light_gray_concrete
fill 54 182 613 54 184 613 minecraft:light_gray_concrete
fill 54 182 615 54 184 615 minecraft:light_gray_concrete
fill 54 182 617 54 184 617 minecraft:light_gray_concrete
fill 55 182 610 55 184 610 minecraft:light_gray_concrete
fill 55 182 612 55 184 612 minecraft:light_gray_concrete
fill 55 182 614 55 184 614 minecraft:light_gray_concrete
fill 55 182 616 55 184 616 minecraft:light_gray_concrete
fill 55 182 618 55 184 618 minecraft:light_gray_concrete
fill 56 182 611 56 184 611 minecraft:light_gray_concrete
fill 56 182 613 56 184 613 minecraft:light_gray_concrete
fill 56 182 615 56 184 615 minecraft:light_gray_concrete
fill 56 182 617 56 184 617 minecraft:light_gray_concrete
fill 56 182 645 61 183 645 minecraft:light_gray_concrete
fill 59 182 605 64 183 605 minecraft:light_gray_concrete
fill 64 182 645 69 183 645 minecraft:light_gray_concrete
fill 67 182 605 70 183 605 minecraft:light_gray_concrete
fill 70 182 607 70 184 607 minecraft:light_gray_concrete
fill 70 182 609 70 184 609 minecraft:light_gray_concrete
fill 70 182 611 70 184 611 minecraft:light_gray_concrete
fill 71 182 606 71 184 606 minecraft:light_gray_concrete
fill 71 182 608 71 184 608 minecraft:light_gray_concrete
fill 71 182 610 71 184 610 minecraft:light_gray_concrete
fill 71 182 612 71 184 612 minecraft:light_gray_concrete
fill 72 182 605 72 184 605 minecraft:light_gray_concrete
fill 72 182 607 72 184 607 minecraft:light_gray_concrete
fill 72 182 609 72 184 609 minecraft:light_gray_concrete
fill 72 182 611 72 184 611 minecraft:light_gray_concrete
fill 72 182 645 77 183 645 minecraft:light_gray_concrete
fill 73 182 606 73 184 606 minecraft:light_gray_concrete
fill 73 182 608 73 184 608 minecraft:light_gray_concrete
fill 73 182 610 73 184 610 minecraft:light_gray_concrete
fill 73 182 612 73 184 612 minecraft:light_gray_concrete
fill 74 182 605 74 184 605 minecraft:light_gray_concrete
fill 74 182 607 74 184 607 minecraft:light_gray_concrete
fill 74 182 609 74 184 609 minecraft:light_gray_concrete
fill 74 182 611 74 184 611 minecraft:light_gray_concrete
fill 75 182 606 75 184 606 minecraft:light_gray_concrete
fill 75 182 608 75 184 608 minecraft:light_gray_concrete
fill 75 182 610 75 184 610 minecraft:light_gray_concrete
fill 75 182 612 75 184 612 minecraft:light_gray_concrete
fill 76 182 605 76 184 605 minecraft:light_gray_concrete
fill 76 182 607 76 184 607 minecraft:light_gray_concrete
fill 76 182 609 76 184 609 minecraft:light_gray_concrete
fill 76 182 611 76 184 611 minecraft:light_gray_concrete
fill 77 182 606 77 184 606 minecraft:light_gray_concrete
fill 77 182 608 77 184 608 minecraft:light_gray_concrete
fill 77 182 610 77 184 610 minecraft:light_gray_concrete
fill 77 182 612 77 184 612 minecraft:light_gray_concrete
fill 78 182 605 80 183 605 minecraft:light_gray_concrete
fill 78 182 607 78 184 607 minecraft:light_gray_concrete
fill 78 182 609 78 184 609 minecraft:light_gray_concrete
fill 78 182 611 78 184 611 minecraft:light_gray_concrete
fill 79 182 606 87 182 606 minecraft:light_gray_concrete
fill 80 182 645 85 183 645 minecraft:light_gray_concrete
fill 83 182 605 88 183 605 minecraft:light_gray_concrete
fill 87 182 607 87 182 643 minecraft:light_gray_concrete
fill 88 182 608 88 183 613 minecraft:light_gray_concrete
fill 88 182 616 88 183 621 minecraft:light_gray_concrete
fill 88 182 624 88 183 629 minecraft:light_gray_concrete
fill 88 182 632 88 183 637 minecraft:light_gray_concrete
fill 88 182 640 88 183 643 minecraft:light_gray_concrete
fill 88 182 645 88 183 645 minecraft:light_gray_concrete
fill 48 183 621 48 183 626 minecraft:light_gray_concrete
fill 48 183 629 48 183 634 minecraft:light_gray_concrete
fill 48 183 637 48 183 642 minecraft:light_gray_concrete
fill 49 183 610 49 184 610 minecraft:light_gray_concrete
fill 49 183 618 49 184 618 minecraft:light_gray_concrete
setblock 88 183 644 minecraft:light_gray_concrete
setblock 70 184 605 minecraft:light_gray_concrete
setblock 78 184 605 minecraft:light_gray_concrete
setblock 50 187 607 minecraft:light[level=14]
setblock 50 187 615 minecraft:light[level=14]
setblock 50 187 623 minecraft:light[level=14]
setblock 50 187 631 minecraft:light[level=14]
setblock 50 187 639 minecraft:light[level=14]
setblock 58 187 607 minecraft:light[level=14]
setblock 58 187 615 minecraft:light[level=14]
setblock 58 187 623 minecraft:light[level=14]
setblock 58 187 631 minecraft:light[level=14]
setblock 58 187 639 minecraft:light[level=14]
setblock 66 187 607 minecraft:light[level=14]
setblock 66 187 615 minecraft:light[level=14]
setblock 66 187 623 minecraft:light[level=14]
setblock 66 187 631 minecraft:light[level=14]
setblock 66 187 639 minecraft:light[level=14]
setblock 74 187 607 minecraft:light[level=14]
setblock 74 187 615 minecraft:light[level=14]
setblock 74 187 623 minecraft:light[level=14]
setblock 74 187 631 minecraft:light[level=14]
setblock 74 187 639 minecraft:light[level=14]
setblock 82 187 607 minecraft:light[level=14]
setblock 82 187 615 minecraft:light[level=14]
setblock 82 187 623 minecraft:light[level=14]
setblock 82 187 631 minecraft:light[level=14]
setblock 82 187 639 minecraft:light[level=14]
fill 65 189 621 67 189 623 minecraft:redstone_block
fill 65 189 629 67 189 631 minecraft:redstone_block
fill 71 189 621 73 189 623 minecraft:redstone_block
fill 71 189 629 73 189 631 minecraft:redstone_block
fill 48 190 605 50 191 615 minecraft:black_concrete
fill 48 190 616 88 191 616 minecraft:magenta_concrete
fill 48 190 617 50 191 627 minecraft:black_concrete
fill 48 190 628 88 190 628 minecraft:magenta_concrete
fill 48 190 629 50 191 639 minecraft:black_concrete
fill 48 190 640 88 191 640 minecraft:magenta_concrete
fill 48 190 641 50 191 645 minecraft:black_concrete
fill 51 190 605 51 191 615 minecraft:light_gray_concrete
fill 51 190 617 51 191 627 minecraft:light_gray_concrete
fill 51 190 629 51 191 639 minecraft:light_gray_concrete
fill 51 190 641 51 191 645 minecraft:light_gray_concrete
fill 52 190 605 54 191 615 minecraft:black_concrete
fill 52 190 617 54 191 627 minecraft:black_concrete
fill 52 190 629 54 191 639 minecraft:black_concrete
fill 52 190 641 54 191 645 minecraft:black_concrete
fill 55 190 605 55 191 615 minecraft:light_gray_concrete
fill 55 190 617 55 191 627 minecraft:light_gray_concrete
fill 55 190 629 55 191 639 minecraft:light_gray_concrete
fill 55 190 641 55 191 645 minecraft:light_gray_concrete
fill 56 190 605 58 191 615 minecraft:black_concrete
fill 56 190 617 58 191 627 minecraft:black_concrete
fill 56 190 629 58 191 639 minecraft:black_concrete
fill 56 190 641 58 191 645 minecraft:black_concrete
fill 59 190 605 59 191 615 minecraft:light_gray_concrete
fill 59 190 617 59 191 627 minecraft:light_gray_concrete
fill 59 190 629 59 191 639 minecraft:light_gray_concrete
fill 59 190 641 59 191 645 minecraft:light_gray_concrete
fill 60 190 605 62 191 615 minecraft:black_concrete
fill 60 190 617 62 191 627 minecraft:black_concrete
fill 60 190 629 62 191 639 minecraft:black_concrete
fill 60 190 641 62 191 645 minecraft:black_concrete
fill 63 190 605 63 191 615 minecraft:light_gray_concrete
fill 63 190 617 63 191 627 minecraft:light_gray_concrete
fill 63 190 629 63 191 639 minecraft:light_gray_concrete
fill 63 190 641 63 191 645 minecraft:light_gray_concrete
fill 64 190 605 66 191 615 minecraft:black_concrete
fill 64 190 617 64 190 627 minecraft:black_concrete
fill 64 190 629 64 190 639 minecraft:black_concrete
fill 64 190 641 66 191 645 minecraft:black_concrete
fill 65 190 617 66 190 620 minecraft:black_concrete
fill 65 190 624 66 190 627 minecraft:black_concrete
fill 65 190 632 66 190 639 minecraft:black_concrete
fill 67 190 605 67 191 615 minecraft:light_gray_concrete
fill 67 190 617 67 190 620 minecraft:light_gray_concrete
fill 67 190 624 67 190 627 minecraft:light_gray_concrete
fill 67 190 632 67 190 639 minecraft:light_gray_concrete
fill 67 190 641 67 191 645 minecraft:light_gray_concrete
fill 68 190 605 70 191 615 minecraft:black_concrete
fill 68 190 617 70 190 624 minecraft:black_concrete
fill 68 190 629 70 190 639 minecraft:black_concrete
fill 68 190 641 70 191 645 minecraft:black_concrete
fill 71 190 605 71 191 615 minecraft:light_gray_concrete
fill 71 190 617 71 190 620 minecraft:light_gray_concrete
fill 71 190 624 71 190 627 minecraft:light_gray_concrete
fill 71 190 632 71 190 639 minecraft:light_gray_concrete
fill 71 190 641 71 191 645 minecraft:light_gray_concrete
fill 72 190 605 74 191 615 minecraft:black_concrete
fill 72 190 617 74 190 620 minecraft:black_concrete
fill 72 190 624 74 190 627 minecraft:black_concrete
fill 72 190 632 74 190 639 minecraft:black_concrete
fill 72 190 641 74 191 645 minecraft:black_concrete
fill 74 190 621 74 190 623 minecraft:black_concrete
fill 74 190 629 74 190 631 minecraft:black_concrete
fill 75 190 605 75 191 615 minecraft:light_gray_concrete
fill 75 190 617 75 191 627 minecraft:light_gray_concrete
fill 75 190 629 75 191 639 minecraft:light_gray_concrete
fill 75 190 641 75 191 645 minecraft:light_gray_concrete
fill 76 190 605 78 191 615 minecraft:black_concrete
fill 76 190 617 78 191 627 minecraft:black_concrete
fill 76 190 629 78 191 639 minecraft:black_concrete
fill 76 190 641 78 191 645 minecraft:black_concrete
fill 79 190 605 79 191 615 minecraft:light_gray_concrete
fill 79 190 617 79 191 627 minecraft:light_gray_concrete
fill 79 190 629 79 191 639 minecraft:light_gray_concrete
fill 79 190 641 79 191 645 minecraft:light_gray_concrete
fill 80 190 605 82 191 615 minecraft:black_concrete
fill 80 190 617 82 191 627 minecraft:black_concrete
fill 80 190 629 82 191 639 minecraft:black_concrete
fill 80 190 641 82 191 645 minecraft:black_concrete
fill 83 190 605 83 191 615 minecraft:light_gray_concrete
fill 83 190 617 83 191 627 minecraft:light_gray_concrete
fill 83 190 629 83 191 639 minecraft:light_gray_concrete
fill 83 190 641 83 191 645 minecraft:light_gray_concrete
fill 84 190 605 86 191 615 minecraft:black_concrete
fill 84 190 617 86 191 627 minecraft:black_concrete
fill 84 190 629 86 191 639 minecraft:black_concrete
fill 84 190 641 86 191 645 minecraft:black_concrete
fill 87 190 605 87 191 615 minecraft:light_gray_concrete
fill 87 190 617 87 191 627 minecraft:light_gray_concrete
fill 87 190 629 87 191 639 minecraft:light_gray_concrete
fill 87 190 641 87 191 645 minecraft:light_gray_concrete
fill 88 190 605 88 191 615 minecraft:black_concrete
fill 88 190 617 88 191 627 minecraft:black_concrete
fill 88 190 629 88 191 639 minecraft:black_concrete
fill 88 190 641 88 191 645 minecraft:black_concrete
fill 48 191 628 63 191 628 minecraft:magenta_concrete
fill 64 191 617 66 191 619 minecraft:black_concrete
fill 64 191 620 64 191 624 minecraft:sea_lantern
fill 64 191 625 66 191 627 minecraft:black_concrete
fill 64 191 628 64 191 632 minecraft:sea_lantern
fill 64 191 633 66 191 639 minecraft:black_concrete
fill 65 191 620 68 191 620 minecraft:sea_lantern
fill 65 191 621 67 191 623 minecraft:black_concrete
fill 65 191 624 74 191 624 minecraft:sea_lantern
fill 65 191 628 74 191 628 minecraft:sea_lantern
fill 65 191 629 67 191 631 minecraft:black_concrete
fill 65 191 632 68 191 632 minecraft:sea_lantern
fill 67 191 617 67 191 619 minecraft:light_gray_concrete
fill 67 191 625 67 191 627 minecraft:sea_lantern
fill 67 191 633 67 191 639 minecraft:light_gray_concrete
fill 68 191 617 70 191 619 minecraft:black_concrete
fill 68 191 621 68 191 623 minecraft:sea_lantern
fill 68 191 629 68 191 631 minecraft:sea_lantern
fill 68 191 633 70 191 639 minecraft:black_concrete
fill 69 191 620 69 191 623 minecraft:black_concrete
fill 69 191 629 69 191 632 minecraft:black_concrete
fill 70 191 620 70 191 623 minecraft:sea_lantern
fill 70 191 629 70 191 632 minecraft:sea_lantern
fill 71 191 617 71 191 619 minecraft:light_gray_concrete
fill 71 191 620 74 191 620 minecraft:sea_lantern
fill 71 191 621 73 191 623 minecraft:black_concrete
fill 71 191 625 71 191 627 minecraft:sea_lantern
fill 71 191 629 73 191 631 minecraft:black_concrete
fill 71 191 632 74 191 632 minecraft:sea_lantern
fill 71 191 633 71 191 639 minecraft:light_gray_concrete
fill 72 191 617 74 191 619 minecraft:black_concrete
fill 72 191 625 74 191 627 minecraft:black_concrete
fill 72 191 633 74 191 639 minecraft:black_concrete
fill 74 191 621 74 191 623 minecraft:sea_lantern
fill 74 191 629 74 191 631 minecraft:sea_lantern
fill 75 191 628 88 191 628 minecraft:magenta_concrete
fill 67 192 625 67 192 627 minecraft:lime_stained_glass
fill 68 192 624 70 192 624 minecraft:lime_stained_glass
fill 68 192 628 70 192 628 minecraft:lime_stained_glass
fill 71 192 625 71 192 627 minecraft:lime_stained_glass
fill 58 193 624 66 193 628 minecraft:light_gray_concrete
fill 59 193 621 79 193 623 minecraft:light_gray_concrete
fill 59 193 629 79 193 631 minecraft:light_gray_concrete
fill 60 193 620 78 196 620 minecraft:light_gray_concrete
fill 60 193 632 78 196 632 minecraft:light_gray_concrete
fill 61 193 619 77 196 619 minecraft:light_gray_concrete
fill 61 193 633 77 196 633 minecraft:light_gray_concrete
fill 62 193 618 76 196 618 minecraft:light_gray_concrete
fill 62 193 634 76 196 634 minecraft:light_gray_concrete
fill 63 193 617 75 196 617 minecraft:light_gray_concrete
fill 63 193 635 75 196 635 minecraft:light_gray_concrete
fill 64 193 616 74 196 616 minecraft:light_gray_concrete
fill 64 193 636 74 196 636 minecraft:light_gray_concrete
fill 67 193 615 71 196 615 minecraft:light_gray_concrete
fill 67 193 624 67 193 625 minecraft:light_gray_concrete
fill 67 193 627 67 193 628 minecraft:light_gray_concrete
fill 67 193 637 71 196 637 minecraft:light_gray_concrete
setblock 68 193 624 minecraft:light_gray_concrete
setblock 68 193 628 minecraft:light_gray_concrete
fill 70 193 624 80 193 624 minecraft:light_gray_concrete
fill 70 193 628 80 193 628 minecraft:light_gray_concrete
fill 71 193 625 80 193 625 minecraft:light_gray_concrete
fill 71 193 627 80 193 627 minecraft:light_gray_concrete
fill 72 193 626 80 193 626 minecraft:light_gray_concrete
fill 56 194 622 56 195 630 minecraft:sea_lantern
fill 57 194 620 57 195 623 minecraft:sea_lantern
fill 57 194 624 65 194 628 minecraft:light_gray_concrete
fill 57 194 629 57 195 632 minecraft:sea_lantern
fill 58 194 618 58 195 620 minecraft:sea_lantern
fill 58 194 621 68 194 623 minecraft:light_gray_concrete
fill 58 194 629 68 194 631 minecraft:light_gray_concrete
fill 58 194 632 58 195 634 minecraft:sea_lantern
fill 59 194 617 59 195 618 minecraft:sea_lantern
fill 59 194 619 59 195 620 minecraft:light_gray_concrete
fill 59 194 632 59 195 633 minecraft:light_gray_concrete
fill 59 194 634 59 195 635 minecraft:sea_lantern
fill 60 194 616 60 195 617 minecraft:sea_lantern
fill 60 194 618 60 195 619 minecraft:light_gray_concrete
fill 60 194 633 60 195 634 minecraft:light_gray_concrete
fill 60 194 635 60 195 636 minecraft:sea_lantern
fill 61 194 615 61 195 616 minecraft:sea_lantern
fill 61 194 617 61 195 618 minecraft:light_gray_concrete
fill 61 194 634 61 195 635 minecraft:light_gray_concrete
fill 61 194 636 61 195 637 minecraft:sea_lantern
fill 62 194 615 63 195 615 minecraft:sea_lantern
fill 62 194 616 62 195 617 minecraft:light_gray_concrete
fill 62 194 635 62 195 636 minecraft:light_gray_concrete
fill 62 194 637 63 195 637 minecraft:sea_lantern
fill 63 194 614 66 195 614 minecraft:sea_lantern
fill 63 194 616 63 195 616 minecraft:light_gray_concrete
fill 63 194 636 63 195 636 minecraft:light_gray_concrete
fill 63 194 638 66 195 638 minecraft:sea_lantern
fill 64 194 615 66 195 615 minecraft:light_gray_concrete
fill 64 194 637 66 195 637 minecraft:light_gray_concrete
fill 65 194 613 73 195 613 minecraft:sea_lantern
fill 65 194 639 73 195 639 minecraft:sea_lantern
fill 66 194 624 66 194 625 minecraft:light_gray_concrete
fill 66 194 626 66 197 626 minecraft:light_blue_stained_glass
fill 66 194 627 66 194 628 minecraft:light_gray_concrete
fill 67 194 614 71 195 614 minecraft:light_gray_concrete
fill 67 194 624 67 196 624 minecraft:light_blue_stained_glass
fill 67 194 628 67 196 628 minecraft:light_blue_stained_glass
fill 67 194 638 71 195 638 minecraft:light_gray_concrete
fill 69 194 621 80 194 622 minecraft:light_gray_concrete
fill 69 194 623 69 197 623 minecraft:light_blue_stained_glass
fill 69 194 629 69 197 629 minecraft:light_blue_stained_glass
fill 69 194 630 80 194 631 minecraft:light_gray_concrete
fill 70 194 623 80 194 623 minecraft:light_gray_concrete
fill 70 194 629 80 194 629 minecraft:light_gray_concrete
fill 71 194 624 71 196 624 minecraft:light_blue_stained_glass
fill 71 194 628 71 196 628 minecraft:light_blue_stained_glass
fill 72 194 614 75 195 614 minecraft:sea_lantern
fill 72 194 615 74 195 615 minecraft:light_gray_concrete
fill 72 194 624 81 194 625 minecraft:light_gray_concrete
fill 72 194 626 72 197 626 minecraft:light_blue_stained_glass
fill 72 194 627 81 194 628 minecraft:light_gray_concrete
fill 72 194 637 74 195 637 minecraft:light_gray_concrete
fill 72 194 638 75 195 638 minecraft:sea_lantern
fill 73 194 626 81 194 626 minecraft:light_gray_concrete
fill 75 194 615 77 195 615 minecraft:sea_lantern
fill 75 194 616 76 195 616 minecraft:light_gray_concrete
fill 75 194 636 76 195 636 minecraft:light_gray_concrete
fill 75 194 637 77 195 637 minecraft:sea_lantern
fill 76 194 617 77 195 617 minecraft:light_gray_concrete
fill 76 194 635 77 195 635 minecraft:light_gray_concrete
fill 77 194 616 78 195 616 minecraft:sea_lantern
fill 77 194 618 78 195 618 minecraft:light_gray_concrete
fill 77 194 634 78 195 634 minecraft:light_gray_concrete
fill 77 194 636 78 195 636 minecraft:sea_lantern
fill 78 194 617 79 195 617 minecraft:sea_lantern
fill 78 194 619 79 195 619 minecraft:light_gray_concrete
fill 78 194 633 79 195 633 minecraft:light_gray_concrete
fill 78 194 635 79 195 635 minecraft:sea_lantern
fill 79 194 618 80 195 618 minecraft:sea_lantern
fill 79 194 620 79 195 620 minecraft:light_gray_concrete
fill 79 194 632 79 195 632 minecraft:light_gray_concrete
fill 79 194 634 80 195 634 minecraft:sea_lantern
fill 80 194 619 80 195 620 minecraft:sea_lantern
fill 80 194 632 80 195 633 minecraft:sea_lantern
fill 81 194 620 81 195 623 minecraft:sea_lantern
fill 81 194 629 81 195 632 minecraft:sea_lantern
fill 82 194 622 82 195 630 minecraft:sea_lantern
fill 48 195 611 48 235 612 minecraft:light_gray_concrete
fill 48 195 619 48 213 620 minecraft:light_gray_concrete
fill 48 195 627 48 235 628 minecraft:light_gray_concrete
fill 48 195 635 48 235 636 minecraft:light_gray_concrete
fill 48 195 643 48 235 644 minecraft:light_gray_concrete
fill 49 195 605 50 235 605 minecraft:light_gray_concrete
setblock 50 195 607 minecraft:light[level=14]
setblock 50 195 615 minecraft:light[level=14]
setblock 50 195 623 minecraft:light[level=14]
setblock 50 195 631 minecraft:light[level=14]
setblock 50 195 639 minecraft:light[level=14]
fill 54 195 645 55 210 645 minecraft:light_gray_concrete
fill 57 195 605 58 222 605 minecraft:light_gray_concrete
fill 57 195 624 64 195 628 minecraft:light_gray_concrete
setblock 58 195 607 minecraft:light[level=14]
setblock 58 195 615 minecraft:light[level=14]
fill 58 195 621 65 195 623 minecraft:light_gray_concrete
fill 58 195 629 65 195 631 minecraft:light_gray_concrete
setblock 58 195 639 minecraft:light[level=14]
fill 62 195 605 64 220 613 minecraft:light_gray_concrete
fill 62 195 645 63 210 645 minecraft:light_gray_concrete
fill 65 195 605 74 220 612 minecraft:light_gray_concrete
fill 65 195 624 65 199 628 minecraft:light_blue_stained_glass
fill 66 195 621 66 195 622 minecraft:light_gray_concrete
fill 66 195 623 66 198 625 minecraft:light_blue_stained_glass
fill 66 195 627 66 198 629 minecraft:light_blue_stained_glass
fill 66 195 630 66 195 631 minecraft:light_gray_concrete
fill 67 195 621 80 195 621 minecraft:light_gray_concrete
fill 67 195 622 68 198 623 minecraft:light_blue_stained_glass
fill 67 195 629 68 198 630 minecraft:light_blue_stained_glass
fill 67 195 631 80 195 631 minecraft:light_gray_concrete
fill 69 195 622 71 199 622 minecraft:light_blue_stained_glass
fill 69 195 630 71 199 630 minecraft:light_blue_stained_glass
fill 70 195 623 72 198 623 minecraft:light_blue_stained_glass
fill 70 195 629 72 198 629 minecraft:light_blue_stained_glass
fill 70 195 645 71 235 645 minecraft:light_gray_concrete
fill 72 195 622 80 195 622 minecraft:light_gray_concrete
fill 72 195 624 73 198 625 minecraft:light_blue_stained_glass
fill 72 195 627 73 198 628 minecraft:light_blue_stained_glass
fill 72 195 630 80 195 630 minecraft:light_gray_concrete
fill 73 195 623 80 195 623 minecraft:light_gray_concrete
fill 73 195 626 73 199 626 minecraft:light_blue_stained_glass
fill 73 195 629 80 195 629 minecraft:light_gray_concrete
fill 74 195 613 74 220 613 minecraft:light_gray_concrete
fill 74 195 624 81 195 628 minecraft:light_gray_concrete
fill 74 195 639 84 195 645 minecraft:light_gray_concrete
fill 76 195 638 84 195 638 minecraft:light_gray_concrete
fill 78 195 637 84 195 637 minecraft:light_gray_concrete
fill 81 195 605 82 235 605 minecraft:light_gray_concrete
setblock 82 195 607 minecraft:light[level=14]
setblock 82 195 615 minecraft:light[level=14]
setblock 82 195 631 minecraft:light[level=14]
fill 83 195 606 88 195 618 minecraft:light_gray_concrete
fill 86 195 645 87 235 645 minecraft:light_gray_concrete
fill 88 195 622 88 235 623 minecraft:light_gray_concrete
fill 88 195 630 88 235 631 minecraft:light_gray_concrete
fill 88 195 638 88 235 639 minecraft:light_gray_concrete
fill 48 196 605 48 197 610 minecraft:light_gray_concrete
fill 48 196 613 49 196 618 minecraft:light_gray_concrete
fill 48 196 621 49 196 626 minecraft:light_gray_concrete
fill 48 196 629 49 196 634 minecraft:light_gray_concrete
fill 48 196 637 49 196 642 minecraft:light_gray_concrete
fill 48 196 645 53 197 645 minecraft:light_gray_concrete
fill 49 196 606 49 196 612 minecraft:light_gray_concrete
fill 49 196 619 49 196 620 minecraft:light_gray_concrete
fill 49 196 627 49 196 628 minecraft:light_gray_concrete
fill 49 196 635 49 196 636 minecraft:light_gray_concrete
fill 49 196 643 49 196 644 minecraft:light_gray_concrete
fill 50 196 606 61 196 606 minecraft:light_gray_concrete
fill 50 196 644 74 196 644 minecraft:light_gray_concrete
fill 51 196 605 56 197 605 minecraft:light_gray_concrete
fill 56 196 645 61 197 645 minecraft:light_gray_concrete
fill 58 196 624 63 196 628 minecraft:light_gray_concrete
fill 59 196 605 61 197 605 minecraft:light_gray_concrete
fill 59 196 621 64 196 623 minecraft:light_gray_concrete
fill 59 196 629 64 196 631 minecraft:light_gray_concrete
fill 62 196 637 64 197 637 minecraft:gray_concrete
fill 63 196 636 63 197 636 minecraft:gray_concrete
fill 63 196 638 63 197 638 minecraft:gray_concrete
fill 64 196 624 64 198 628 minecraft:light_blue_stained_glass
fill 64 196 645 69 197 645 minecraft:light_gray_concrete
fill 65 196 613 73 220 613 minecraft:light_gray_concrete
fill 65 196 621 66 196 621 minecraft:light_gray_concrete
fill 65 196 622 65 198 623 minecraft:light_blue_stained_glass
fill 65 196 629 65 198 630 minecraft:light_blue_stained_glass
fill 65 196 631 66 196 631 minecraft:light_gray_concrete
fill 66 196 622 66 198 622 minecraft:light_blue_stained_glass
fill 66 196 630 66 198 630 minecraft:light_blue_stained_glass
fill 67 196 621 71 198 621 minecraft:light_blue_stained_glass
fill 67 196 631 71 198 631 minecraft:light_blue_stained_glass
fill 72 196 621 79 196 621 minecraft:light_gray_concrete
fill 72 196 622 73 198 622 minecraft:light_blue_stained_glass
fill 72 196 630 73 198 630 minecraft:light_blue_stained_glass
fill 72 196 631 79 196 631 minecraft:light_gray_concrete
fill 72 196 645 73 197 645 minecraft:light_gray_concrete
fill 73 196 623 73 198 623 minecraft:light_blue_stained_glass
fill 73 196 629 73 198 629 minecraft:light_blue_stained_glass
fill 74 196 622 79 196 623 minecraft:light_gray_concrete
fill 74 196 624 74 198 628 minecraft:light_blue_stained_glass
fill 74 196 629 79 196 630 minecraft:light_gray_concrete
setblock 74 196 637 minecraft:sea_lantern
fill 74 196 638 74 218 638 minecraft:light_gray_concrete
setblock 74 196 639 minecraft:sea_lantern
fill 74 196 640 74 218 640 minecraft:light_gray_concrete
setblock 74 196 641 minecraft:sea_lantern
fill 74 196 642 74 218 642 minecraft:light_gray_concrete
setblock 74 196 643 minecraft:sea_lantern
setblock 74 196 645 minecraft:sea_lantern
fill 75 196 605 80 196 606 minecraft:light_gray_concrete
fill 75 196 624 80 196 628 minecraft:light_gray_concrete
fill 75 196 637 75 218 637 minecraft:light_gray_concrete
setblock 75 196 638 minecraft:sea_lantern
fill 75 196 639 75 218 639 minecraft:light_gray_concrete
setblock 75 196 640 minecraft:sea_lantern
fill 75 196 641 75 218 641 minecraft:light_gray_concrete
setblock 75 196 642 minecraft:sea_lantern
fill 75 196 643 75 218 643 minecraft:light_gray_concrete
setblock 75 196 644 minecraft:sea_lantern
fill 75 196 645 75 218 645 minecraft:light_gray_concrete
setblock 76 196 637 minecraft:sea_lantern
fill 76 196 638 76 218 638 minecraft:light_gray_concrete
setblock 76 196 639 minecraft:sea_lantern
fill 76 196 640 76 218 640 minecraft:light_gray_concrete
setblock 76 196 641 minecraft:sea_lantern
fill 76 196 642 76 218 642 minecraft:light_gray_concrete
setblock 76 196 643 minecraft:sea_lantern
fill 76 196 644 76 218 644 minecraft:light_gray_concrete
setblock 76 196 645 minecraft:sea_lantern
fill 77 196 637 77 218 637 minecraft:light_gray_concrete
setblock 77 196 638 minecraft:sea_lantern
fill 77 196 639 77 218 639 minecraft:light_gray_concrete
setblock 77 196 640 minecraft:sea_lantern
fill 77 196 641 77 218 641 minecraft:light_gray_concrete
setblock 77 196 642 minecraft:sea_lantern
fill 77 196 643 77 218 643 minecraft:light_gray_concrete
setblock 77 196 644 minecraft:sea_lantern
fill 77 196 645 77 218 645 minecraft:light_gray_concrete
setblock 78 196 637 minecraft:sea_lantern
fill 78 196 638 78 218 638 minecraft:light_gray_concrete
setblock 78 196 639 minecraft:sea_lantern
fill 78 196 640 78 218 640 minecraft:light_gray_concrete
setblock 78 196 641 minecraft:sea_lantern
fill 78 196 642 78 218 642 minecraft:light_gray_concrete
setblock 78 196 643 minecraft:sea_lantern
fill 78 196 644 78 218 644 minecraft:light_gray_concrete
setblock 78 196 645 minecraft:sea_lantern
fill 79 196 637 79 218 637 minecraft:light_gray_concrete
setblock 79 196 638 minecraft:sea_lantern
fill 79 196 639 79 218 639 minecraft:light_gray_concrete
setblock 79 196 640 minecraft:sea_lantern
fill 79 196 641 79 218 641 minecraft:light_gray_concrete
setblock 79 196 642 minecraft:sea_lantern
fill 79 196 643 79 218 643 minecraft:light_gray_concrete
setblock 79 196 644 minecraft:sea_lantern
fill 79 196 645 79 235 645 minecraft:light_gray_concrete
setblock 80 196 637 minecraft:sea_lantern
fill 80 196 638 80 218 638 minecraft:light_gray_concrete
setblock 80 196 639 minecraft:sea_lantern
fill 80 196 640 80 218 640 minecraft:light_gray_concrete
setblock 80 196 641 minecraft:sea_lantern
fill 80 196 642 80 218 642 minecraft:light_gray_concrete
setblock 80 196 643 minecraft:sea_lantern
fill 80 196 644 80 218 644 minecraft:light_gray_concrete
setblock 80 196 645 minecraft:sea_lantern
fill 81 196 606 82 196 606 minecraft:light_gray_concrete
fill 81 196 637 81 218 637 minecraft:light_gray_concrete
setblock 81 196 638 minecraft:sea_lantern
fill 81 196 639 81 218 639 minecraft:light_gray_concrete
setblock 81 196 640 minecraft:sea_lantern
fill 81 196 641 81 218 641 minecraft:light_gray_concrete
setblock 81 196 642 minecraft:sea_lantern
fill 81 196 643 81 218 643 minecraft:light_gray_concrete
setblock 81 196 644 minecraft:sea_lantern
fill 81 196 645 81 218 645 minecraft:light_gray_concrete
setblock 82 196 637 minecraft:sea_lantern
fill 82 196 638 82 218 638 minecraft:light_gray_concrete
setblock 82 196 639 minecraft:sea_lantern
fill 82 196 640 82 218 640 minecraft:light_gray_concrete
setblock 82 196 641 minecraft:sea_lantern
fill 82 196 642 82 218 642 minecraft:light_gray_concrete
setblock 82 196 643 minecraft:sea_lantern
fill 82 196 644 82 218 644 minecraft:light_gray_concrete
setblock 82 196 645 minecraft:sea_lantern
fill 83 196 605 88 197 605 minecraft:light_gray_concrete
setblock 83 196 606 minecraft:sea_lantern
fill 83 196 607 83 208 607 minecraft:light_gray_concrete
setblock 83 196 608 minecraft:sea_lantern
fill 83 196 609 83 208 609 minecraft:light_gray_concrete
setblock 83 196 610 minecraft:sea_lantern
fill 83 196 611 83 208 611 minecraft:light_gray_concrete
setblock 83 196 612 minecraft:sea_lantern
fill 83 196 613 83 208 613 minecraft:light_gray_concrete
setblock 83 196 614 minecraft:sea_lantern
fill 83 196 615 83 208 615 minecraft:light_gray_concrete
setblock 83 196 616 minecraft:sea_lantern
fill 83 196 617 83 208 617 minecraft:light_gray_concrete
setblock 83 196 618 minecraft:sea_lantern
fill 83 196 637 83 218 637 minecraft:light_gray_concrete
setblock 83 196 638 minecraft:sea_lantern
fill 83 196 639 83 218 639 minecraft:light_gray_concrete
setblock 83 196 640 minecraft:sea_lantern
fill 83 196 641 83 218 641 minecraft:light_gray_concrete
setblock 83 196 642 minecraft:sea_lantern
fill 83 196 643 83 218 643 minecraft:light_gray_concrete
setblock 83 196 644 minecraft:sea_lantern
fill 83 196 645 83 218 645 minecraft:light_gray_concrete
fill 84 196 606 84 208 606 minecraft:light_gray_concrete
setblock 84 196 607 minecraft:sea_lantern
fill 84 196 608 84 208 608 minecraft:light_gray_concrete
setblock 84 196 609 minecraft:sea_lantern
fill 84 196 610 84 208 610 minecraft:light_gray_concrete
setblock 84 196 611 minecraft:sea_lantern
fill 84 196 612 84 208 612 minecraft:light_gray_concrete
setblock 84 196 613 minecraft:sea_lantern
fill 84 196 614 84 208 614 minecraft:light_gray_concrete
setblock 84 196 615 minecraft:sea_lantern
fill 84 196 616 84 208 616 minecraft:light_gray_concrete
setblock 84 196 617 minecraft:sea_lantern
fill 84 196 618 84 208 618 minecraft:light_gray_concrete
setblock 84 196 637 minecraft:sea_lantern
fill 84 196 638 84 218 638 minecraft:light_gray_concrete
setblock 84 196 639 minecraft:sea_lantern
fill 84 196 640 84 218 640 minecraft:light_gray_concrete
setblock 84 196 641 minecraft:sea_lantern
fill 84 196 642 84 218 642 minecraft:light_gray_concrete
setblock 84 196 643 minecraft:sea_lantern
fill 84 196 644 88 196 644 minecraft:light_gray_concrete
setblock 84 196 645 minecraft:sea_lantern
setblock 85 196 606 minecraft:sea_lantern
fill 85 196 607 85 208 607 minecraft:light_gray_concrete
setblock 85 196 608 minecraft:sea_lantern
fill 85 196 609 85 208 609 minecraft:light_gray_concrete
setblock 85 196 610 minecraft:sea_lantern
fill 85 196 611 85 208 611 minecraft:light_gray_concrete
setblock 85 196 612 minecraft:sea_lantern
fill 85 196 613 85 208 613 minecraft:light_gray_concrete
setblock 85 196 614 minecraft:sea_lantern
fill 85 196 615 85 208 615 minecraft:light_gray_concrete
setblock 85 196 616 minecraft:sea_lantern
fill 85 196 617 85 208 617 minecraft:light_gray_concrete
setblock 85 196 618 minecraft:sea_lantern
fill 85 196 645 85 197 645 minecraft:light_gray_concrete
fill 86 196 606 86 208 606 minecraft:light_gray_concrete
setblock 86 196 607 minecraft:sea_lantern
fill 86 196 608 86 208 608 minecraft:light_gray_concrete
setblock 86 196 609 minecraft:sea_lantern
fill 86 196 610 86 208 610 minecraft:light_gray_concrete
setblock 86 196 611 minecraft:sea_lantern
fill 86 196 612 86 208 612 minecraft:light_gray_concrete
setblock 86 196 613 minecraft:sea_lantern
fill 86 196 614 86 208 614 minecraft:light_gray_concrete
setblock 86 196 615 minecraft:sea_lantern
fill 86 196 616 86 208 616 minecraft:light_gray_concrete
setblock 86 196 617 minecraft:sea_lantern
fill 86 196 618 86 208 618 minecraft:light_gray_concrete
setblock 87 196 606 minecraft:sea_lantern
fill 87 196 607 87 208 607 minecraft:light_gray_concrete
setblock 87 196 608 minecraft:sea_lantern
fill 87 196 609 87 208 609 minecraft:light_gray_concrete
setblock 87 196 610 minecraft:sea_lantern
fill 87 196 611 87 208 611 minecraft:light_gray_concrete
setblock 87 196 612 minecraft:sea_lantern
fill 87 196 613 87 208 613 minecraft:light_gray_concrete
setblock 87 196 614 minecraft:sea_lantern
fill 87 196 615 87 208 615 minecraft:light_gray_concrete
setblock 87 196 616 minecraft:sea_lantern
fill 87 196 617 87 208 617 minecraft:light_gray_concrete
setblock 87 196 618 minecraft:sea_lantern
fill 87 196 619 87 196 643 minecraft:light_gray_concrete
fill 88 196 606 88 235 606 minecraft:light_gray_concrete
setblock 88 196 607 minecraft:sea_lantern
fill 88 196 608 88 208 608 minecraft:light_gray_concrete
setblock 88 196 609 minecraft:sea_lantern
fill 88 196 610 88 208 610 minecraft:light_gray_concrete
setblock 88 196 611 minecraft:sea_lantern
fill 88 196 612 88 208 612 minecraft:light_gray_concrete
setblock 88 196 613 minecraft:sea_lantern
fill 88 196 614 88 235 614 minecraft:light_gray_concrete
setblock 88 196 615 minecraft:sea_lantern
fill 88 196 616 88 208 616 minecraft:light_gray_concrete
setblock 88 196 617 minecraft:sea_lantern
fill 88 196 618 88 197 621 minecraft:light_gray_concrete
fill 88 196 624 88 197 629 minecraft:light_gray_concrete
fill 88 196 632 88 197 637 minecraft:light_gray_concrete
fill 88 196 640 88 197 643 minecraft:light_gray_concrete
fill 88 196 645 88 197 645 minecraft:light_gray_concrete
fill 48 197 613 48 197 618 minecraft:light_gray_concrete
fill 48 197 621 48 197 626 minecraft:light_gray_concrete
fill 48 197 629 48 197 634 minecraft:light_gray_concrete
fill 48 197 637 48 197 642 minecraft:light_gray_concrete
setblock 63 197 626 minecraft:light_blue_stained_glass
setblock 64 197 623 minecraft:light_blue_stained_glass
setblock 64 197 629 minecraft:light_blue_stained_glass
setblock 66 197 621 minecraft:light_blue_stained_glass
setblock 66 197 631 minecraft:light_blue_stained_glass
setblock 69 197 620 minecraft:light_blue_stained_glass
setblock 69 197 632 minecraft:light_blue_stained_glass
setblock 72 197 621 minecraft:light_blue_stained_glass
setblock 72 197 631 minecraft:light_blue_stained_glass
setblock 74 197 623 minecraft:light_blue_stained_glass
setblock 74 197 629 minecraft:light_blue_stained_glass
fill 74 197 637 74 198 637 minecraft:light_gray_concrete
fill 74 197 639 74 198 639 minecraft:light_gray_concrete
fill 74 197 641 74 198 641 minecraft:light_gray_concrete
fill 74 197 643 74 198 645 minecraft:light_gray_concrete
fill 75 197 605 80 197 605 minecraft:light_gray_concrete
setblock 75 197 626 minecraft:light_blue_stained_glass
fill 75 197 638 75 198 638 minecraft:light_gray_concrete
fill 75 197 640 75 198 640 minecraft:light_gray_concrete
fill 75 197 642 75 198 642 minecraft:light_gray_concrete
fill 75 197 644 75 198 644 minecraft:light_gray_concrete
fill 76 197 637 76 198 637 minecraft:light_gray_concrete
fill 76 197 639 76 198 639 minecraft:light_gray_concrete
fill 76 197 641 76 198 641 minecraft:light_gray_concrete
fill 76 197 643 76 198 643 minecraft:light_gray_concrete
fill 76 197 645 76 198 645 minecraft:light_gray_concrete
fill 77 197 638 77 198 638 minecraft:light_gray_concrete
fill 77 197 640 77 198 640 minecraft:light_gray_concrete
fill 77 197 642 77 198 642 minecraft:light_gray_concrete
fill 77 197 644 77 198 644 minecraft:light_gray_concrete
fill 78 197 637 78 198 637 minecraft:light_gray_concrete
fill 78 197 639 78 198 639 minecraft:light_gray_concrete
fill 78 197 641 78 198 641 minecraft:light_gray_concrete
fill 78 197 643 78 198 643 minecraft:light_gray_concrete
fill 78 197 645 78 198 645 minecraft:light_gray_concrete
fill 79 197 638 79 198 638 minecraft:light_gray_concrete
fill 79 197 640 79 198 640 minecraft:light_gray_concrete
fill 79 197 642 79 198 642 minecraft:light_gray_concrete
fill 79 197 644 79 198 644 minecraft:light_gray_concrete
fill 80 197 637 80 198 637 minecraft:light_gray_concrete
fill 80 197 639 80 198 639 minecraft:light_gray_concrete
fill 80 197 641 80 198 641 minecraft:light_gray_concrete
fill 80 197 643 80 198 643 minecraft:light_gray_concrete
fill 80 197 645 80 198 645 minecraft:light_gray_concrete
fill 81 197 638 81 198 638 minecraft:light_gray_concrete
fill 81 197 640 81 198 640 minecraft:light_gray_concrete
fill 81 197 642 81 198 642 minecraft:light_gray_concrete
fill 81 197 644 81 198 644 minecraft:light_gray_concrete
fill 82 197 637 82 198 637 minecraft:light_gray_concrete
fill 82 197 639 82 198 639 minecraft:light_gray_concrete
fill 82 197 641 82 198 641 minecraft:light_gray_concrete
fill 82 197 643 82 198 643 minecraft:light_gray_concrete
fill 82 197 645 82 198 645 minecraft:light_gray_concrete
fill 83 197 606 83 198 606 minecraft:light_gray_concrete
fill 83 197 608 83 198 608 minecraft:light_gray_concrete
fill 83 197 610 83 198 610 minecraft:light_gray_concrete
fill 83 197 612 83 198 612 minecraft:light_gray_concrete
fill 83 197 614 83 198 614 minecraft:light_gray_concrete
fill 83 197 616 83 198 616 minecraft:light_gray_concrete
fill 83 197 618 83 198 618 minecraft:light_gray_concrete
fill 83 197 638 83 198 638 minecraft:light_gray_concrete
fill 83 197 640 83 198 640 minecraft:light_gray_concrete
fill 83 197 642 83 198 642 minecraft:light_gray_concrete
fill 83 197 644 84 198 644 minecraft:light_gray_concrete
fill 84 197 607 84 198 607 minecraft:light_gray_concrete
fill 84 197 609 84 198 609 minecraft:light_gray_concrete
fill 84 197 611 84 198 611 minecraft:light_gray_concrete
fill 84 197 613 84 198 613 minecraft:light_gray_concrete
fill 84 197 615 84 198 615 minecraft:light_gray_concrete
fill 84 197 617 84 198 617 minecraft:light_gray_concrete
fill 84 197 637 84 198 637 minecraft:light_gray_concrete
fill 84 197 639 84 198 639 minecraft:light_gray_concrete
fill 84 197 641 84 198 641 minecraft:light_gray_concrete
fill 84 197 643 84 198 643 minecraft:light_gray_concrete
fill 84 197 645 84 198 645 minecraft:light_gray_concrete
fill 85 197 606 85 198 606 minecraft:light_gray_concrete
fill 85 197 608 85 198 608 minecraft:light_gray_concrete
fill 85 197 610 85 198 610 minecraft:light_gray_concrete
fill 85 197 612 85 198 612 minecraft:light_gray_concrete
fill 85 197 614 85 198 614 minecraft:light_gray_concrete
fill 85 197 616 85 198 616 minecraft:light_gray_concrete
fill 85 197 618 85 198 618 minecraft:light_gray_concrete
fill 86 197 607 86 198 607 minecraft:light_gray_concrete
fill 86 197 609 86 198 609 minecraft:light_gray_concrete
fill 86 197 611 86 198 611 minecraft:light_gray_concrete
fill 86 197 613 86 198 613 minecraft:light_gray_concrete
fill 86 197 615 86 198 615 minecraft:light_gray_concrete
fill 86 197 617 86 198 617 minecraft:light_gray_concrete
fill 87 197 606 87 198 606 minecraft:light_gray_concrete
fill 87 197 608 87 198 608 minecraft:light_gray_concrete
fill 87 197 610 87 198 610 minecraft:light_gray_concrete
fill 87 197 612 87 198 612 minecraft:light_gray_concrete
fill 87 197 614 87 198 614 minecraft:light_gray_concrete
fill 87 197 616 87 198 616 minecraft:light_gray_concrete
fill 87 197 618 87 198 618 minecraft:light_gray_concrete
fill 88 197 607 88 198 607 minecraft:light_gray_concrete
fill 88 197 609 88 198 609 minecraft:light_gray_concrete
fill 88 197 611 88 198 611 minecraft:light_gray_concrete
fill 88 197 613 88 198 613 minecraft:light_gray_concrete
fill 88 197 615 88 198 615 minecraft:light_gray_concrete
fill 88 197 617 88 198 617 minecraft:light_gray_concrete
setblock 88 197 644 minecraft:light_gray_concrete
fill 88 198 618 88 208 618 minecraft:light_gray_concrete
fill 66 199 623 66 199 624 minecraft:light_blue_stained_glass
fill 66 199 628 66 199 629 minecraft:light_blue_stained_glass
fill 67 199 622 67 199 623 minecraft:light_blue_stained_glass
fill 67 199 629 67 199 630 minecraft:light_blue_stained_glass
setblock 68 199 622 minecraft:light_blue_stained_glass
setblock 68 199 630 minecraft:light_blue_stained_glass
fill 71 199 623 72 199 623 minecraft:light_blue_stained_glass
fill 71 199 629 72 199 629 minecraft:light_blue_stained_glass
fill 72 199 624 73 199 624 minecraft:light_blue_stained_glass
fill 72 199 628 73 199 628 minecraft:light_blue_stained_glass
setblock 73 199 625 minecraft:light_blue_stained_glass
setblock 73 199 627 minecraft:light_blue_stained_glass
setblock 74 199 637 minecraft:sea_lantern
setblock 74 199 639 minecraft:sea_lantern
setblock 74 199 641 minecraft:sea_lantern
setblock 74 199 643 minecraft:sea_lantern
fill 74 199 644 74 218 644 minecraft:light_gray_concrete
setblock 74 199 645 minecraft:sea_lantern
setblock 75 199 638 minecraft:sea_lantern
setblock 75 199 640 minecraft:sea_lantern
setblock 75 199 642 minecraft:sea_lantern
setblock 75 199 644 minecraft:sea_lantern
setblock 76 199 637 minecraft:sea_lantern
setblock 76 199 639 minecraft:sea_lantern
setblock 76 199 641 minecraft:sea_lantern
setblock 76 199 643 minecraft:sea_lantern
setblock 76 199 645 minecraft:sea_lantern
setblock 77 199 638 minecraft:sea_lantern
setblock 77 199 640 minecraft:sea_lantern
setblock 77 199 642 minecraft:sea_lantern
setblock 77 199 644 minecraft:sea_lantern
setblock 78 199 637 minecraft:sea_lantern
setblock 78 199 639 minecraft:sea_lantern
setblock 78 199 641 minecraft:sea_lantern
setblock 78 199 643 minecraft:sea_lantern
setblock 78 199 645 minecraft:sea_lantern
setblock 79 199 638 minecraft:sea_lantern
setblock 79 199 640 minecraft:sea_lantern
setblock 79 199 642 minecraft:sea_lantern
setblock 79 199 644 minecraft:sea_lantern
setblock 80 199 637 minecraft:sea_lantern
setblock 80 199 639 minecraft:sea_lantern
setblock 80 199 641 minecraft:sea_lantern
setblock 80 199 643 minecraft:sea_lantern
setblock 80 199 645 minecraft:sea_lantern
setblock 81 199 638 minecraft:sea_lantern
setblock 81 199 640 minecraft:sea_lantern
setblock 81 199 642 minecraft:sea_lantern
setblock 81 199 644 minecraft:sea_lantern
setblock 82 199 637 minecraft:sea_lantern
setblock 82 199 639 minecraft:sea_lantern
setblock 82 199 641 minecraft:sea_lantern
setblock 82 199 643 minecraft:sea_lantern
setblock 82 199 645 minecraft:sea_lantern
setblock 83 199 606 minecraft:sea_lantern
setblock 83 199 608 minecraft:sea_lantern
setblock 83 199 610 minecraft:sea_lantern
setblock 83 199 612 minecraft:sea_lantern
schedule function dropper:buildpart/145_2 1t
