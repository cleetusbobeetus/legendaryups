setblock 285 289 341 minecraft:shroomlight
setblock 285 289 347 minecraft:shroomlight
setblock 285 289 349 minecraft:shroomlight
setblock 285 289 351 minecraft:shroomlight
setblock 285 289 353 minecraft:shroomlight
setblock 285 289 355 minecraft:shroomlight
setblock 285 289 357 minecraft:shroomlight
setblock 286 289 326 minecraft:shroomlight
setblock 286 289 328 minecraft:shroomlight
setblock 286 289 330 minecraft:shroomlight
setblock 286 289 332 minecraft:shroomlight
setblock 286 289 334 minecraft:shroomlight
setblock 286 289 336 minecraft:shroomlight
setblock 286 289 338 minecraft:shroomlight
setblock 286 289 340 minecraft:shroomlight
setblock 286 289 342 minecraft:shroomlight
setblock 286 289 348 minecraft:shroomlight
setblock 286 289 350 minecraft:shroomlight
setblock 286 289 352 minecraft:shroomlight
setblock 286 289 354 minecraft:shroomlight
setblock 286 289 356 minecraft:shroomlight
setblock 287 289 325 minecraft:shroomlight
setblock 287 289 327 minecraft:shroomlight
setblock 287 289 329 minecraft:shroomlight
setblock 287 289 331 minecraft:shroomlight
setblock 287 289 333 minecraft:shroomlight
setblock 287 289 335 minecraft:shroomlight
setblock 287 289 337 minecraft:shroomlight
setblock 287 289 339 minecraft:shroomlight
setblock 287 289 341 minecraft:shroomlight
setblock 288 289 326 minecraft:shroomlight
setblock 288 289 328 minecraft:shroomlight
setblock 288 289 330 minecraft:shroomlight
setblock 288 289 332 minecraft:shroomlight
setblock 288 289 334 minecraft:shroomlight
setblock 288 289 336 minecraft:shroomlight
setblock 288 289 338 minecraft:shroomlight
setblock 288 289 340 minecraft:shroomlight
setblock 288 289 342 minecraft:shroomlight
setblock 289 289 325 minecraft:shroomlight
setblock 289 289 327 minecraft:shroomlight
setblock 289 289 329 minecraft:shroomlight
setblock 289 289 331 minecraft:shroomlight
setblock 289 289 333 minecraft:shroomlight
setblock 289 289 335 minecraft:shroomlight
setblock 289 289 337 minecraft:shroomlight
setblock 289 289 339 minecraft:shroomlight
setblock 289 289 341 minecraft:shroomlight
setblock 313 289 341 minecraft:shroomlight
setblock 313 289 343 minecraft:shroomlight
setblock 313 289 345 minecraft:shroomlight
setblock 314 289 340 minecraft:shroomlight
setblock 314 289 342 minecraft:shroomlight
setblock 314 289 344 minecraft:shroomlight
setblock 314 289 346 minecraft:shroomlight
setblock 314 289 352 minecraft:shroomlight
setblock 314 289 354 minecraft:shroomlight
setblock 314 289 356 minecraft:shroomlight
setblock 314 289 358 minecraft:shroomlight
setblock 314 289 360 minecraft:shroomlight
setblock 314 289 362 minecraft:shroomlight
setblock 314 289 364 minecraft:shroomlight
setblock 315 289 341 minecraft:shroomlight
setblock 315 289 343 minecraft:shroomlight
setblock 315 289 345 minecraft:shroomlight
setblock 315 289 353 minecraft:shroomlight
setblock 315 289 355 minecraft:shroomlight
setblock 315 289 357 minecraft:shroomlight
setblock 315 289 359 minecraft:shroomlight
setblock 315 289 361 minecraft:shroomlight
setblock 315 289 363 minecraft:shroomlight
setblock 316 289 340 minecraft:shroomlight
setblock 316 289 342 minecraft:shroomlight
setblock 316 289 344 minecraft:shroomlight
setblock 316 289 346 minecraft:shroomlight
setblock 316 289 352 minecraft:shroomlight
setblock 316 289 354 minecraft:shroomlight
setblock 316 289 356 minecraft:shroomlight
setblock 316 289 358 minecraft:shroomlight
setblock 316 289 360 minecraft:shroomlight
setblock 316 289 362 minecraft:shroomlight
setblock 316 289 364 minecraft:shroomlight
setblock 317 289 341 minecraft:shroomlight
setblock 317 289 343 minecraft:shroomlight
setblock 317 289 345 minecraft:shroomlight
setblock 317 289 353 minecraft:shroomlight
setblock 317 289 355 minecraft:shroomlight
setblock 317 289 357 minecraft:shroomlight
setblock 317 289 359 minecraft:shroomlight
setblock 317 289 361 minecraft:shroomlight
setblock 317 289 363 minecraft:shroomlight
setblock 318 289 340 minecraft:shroomlight
setblock 318 289 342 minecraft:shroomlight
setblock 318 289 344 minecraft:shroomlight
setblock 318 289 346 minecraft:shroomlight
setblock 318 289 352 minecraft:shroomlight
setblock 318 289 354 minecraft:shroomlight
setblock 318 289 356 minecraft:shroomlight
setblock 318 289 358 minecraft:shroomlight
setblock 318 289 360 minecraft:shroomlight
setblock 318 289 362 minecraft:shroomlight
setblock 319 289 341 minecraft:shroomlight
setblock 319 289 343 minecraft:shroomlight
setblock 319 289 345 minecraft:shroomlight
setblock 319 289 353 minecraft:shroomlight
setblock 319 289 355 minecraft:shroomlight
setblock 319 289 357 minecraft:shroomlight
setblock 319 289 359 minecraft:shroomlight
setblock 319 289 361 minecraft:shroomlight
setblock 319 289 363 minecraft:shroomlight
setblock 320 289 340 minecraft:shroomlight
setblock 320 289 342 minecraft:shroomlight
setblock 320 289 344 minecraft:shroomlight
setblock 320 289 346 minecraft:shroomlight
setblock 320 289 352 minecraft:shroomlight
setblock 320 289 354 minecraft:shroomlight
setblock 320 289 356 minecraft:shroomlight
setblock 320 289 358 minecraft:shroomlight
setblock 320 289 360 minecraft:shroomlight
setblock 320 289 362 minecraft:shroomlight
setblock 321 289 341 minecraft:shroomlight
setblock 321 289 343 minecraft:shroomlight
setblock 321 289 345 minecraft:shroomlight
setblock 321 289 353 minecraft:shroomlight
setblock 321 289 355 minecraft:shroomlight
setblock 321 289 357 minecraft:shroomlight
setblock 321 289 359 minecraft:shroomlight
setblock 321 289 361 minecraft:shroomlight
setblock 321 289 363 minecraft:shroomlight
setblock 322 289 340 minecraft:shroomlight
setblock 322 289 342 minecraft:shroomlight
setblock 322 289 344 minecraft:shroomlight
setblock 322 289 346 minecraft:shroomlight
setblock 322 289 352 minecraft:shroomlight
setblock 322 289 354 minecraft:shroomlight
setblock 322 289 356 minecraft:shroomlight
setblock 322 289 358 minecraft:shroomlight
setblock 322 289 360 minecraft:shroomlight
setblock 322 289 362 minecraft:shroomlight
setblock 322 289 364 minecraft:shroomlight
setblock 323 289 341 minecraft:shroomlight
setblock 323 289 343 minecraft:shroomlight
setblock 323 289 345 minecraft:shroomlight
setblock 323 289 353 minecraft:shroomlight
setblock 323 289 355 minecraft:shroomlight
setblock 323 289 357 minecraft:shroomlight
setblock 323 289 359 minecraft:shroomlight
setblock 323 289 361 minecraft:shroomlight
setblock 323 289 363 minecraft:shroomlight
fill 283 290 325 283 291 325 minecraft:polished_andesite
fill 283 290 327 283 291 327 minecraft:polished_andesite
fill 283 290 329 283 291 329 minecraft:polished_andesite
fill 283 290 331 283 291 331 minecraft:polished_andesite
fill 283 290 333 283 291 333 minecraft:polished_andesite
fill 283 290 335 283 291 335 minecraft:polished_andesite
fill 283 290 337 283 291 337 minecraft:polished_andesite
fill 283 290 339 283 291 339 minecraft:polished_andesite
fill 283 290 341 283 291 341 minecraft:polished_andesite
fill 283 290 347 283 291 347 minecraft:polished_andesite
fill 283 290 349 283 291 349 minecraft:polished_andesite
fill 283 290 351 283 291 351 minecraft:polished_andesite
fill 283 290 353 283 291 353 minecraft:polished_andesite
fill 283 290 355 283 291 355 minecraft:polished_andesite
fill 283 290 357 283 291 357 minecraft:polished_andesite
fill 284 290 326 284 291 326 minecraft:polished_andesite
fill 284 290 328 284 291 328 minecraft:polished_andesite
fill 284 290 330 284 291 330 minecraft:polished_andesite
fill 284 290 332 284 291 332 minecraft:polished_andesite
fill 284 290 334 284 291 334 minecraft:polished_andesite
fill 284 290 336 284 291 336 minecraft:polished_andesite
fill 284 290 338 284 291 338 minecraft:polished_andesite
fill 284 290 340 284 291 340 minecraft:polished_andesite
fill 284 290 342 284 291 342 minecraft:polished_andesite
fill 284 290 348 284 291 348 minecraft:polished_andesite
fill 284 290 350 284 291 350 minecraft:polished_andesite
fill 284 290 352 284 291 352 minecraft:polished_andesite
fill 284 290 354 284 291 354 minecraft:polished_andesite
fill 284 290 356 284 291 356 minecraft:polished_andesite
fill 285 290 325 285 291 325 minecraft:polished_andesite
fill 285 290 327 285 291 327 minecraft:polished_andesite
fill 285 290 329 285 291 329 minecraft:polished_andesite
fill 285 290 331 285 291 331 minecraft:polished_andesite
fill 285 290 333 285 291 333 minecraft:polished_andesite
fill 285 290 335 285 291 335 minecraft:polished_andesite
fill 285 290 337 285 291 337 minecraft:polished_andesite
fill 285 290 339 285 291 339 minecraft:polished_andesite
fill 285 290 341 285 291 341 minecraft:polished_andesite
fill 285 290 347 285 291 347 minecraft:polished_andesite
fill 285 290 349 285 291 349 minecraft:polished_andesite
fill 285 290 351 285 291 351 minecraft:polished_andesite
fill 285 290 353 285 291 353 minecraft:polished_andesite
fill 285 290 355 285 291 355 minecraft:polished_andesite
fill 285 290 357 285 291 357 minecraft:polished_andesite
fill 286 290 326 286 291 326 minecraft:polished_andesite
fill 286 290 328 286 291 328 minecraft:polished_andesite
fill 286 290 330 286 291 330 minecraft:polished_andesite
fill 286 290 332 286 291 332 minecraft:polished_andesite
fill 286 290 334 286 291 334 minecraft:polished_andesite
fill 286 290 336 286 291 336 minecraft:polished_andesite
fill 286 290 338 286 291 338 minecraft:polished_andesite
fill 286 290 340 286 291 340 minecraft:polished_andesite
fill 286 290 342 286 291 342 minecraft:polished_andesite
fill 286 290 348 286 291 348 minecraft:polished_andesite
fill 286 290 350 286 291 350 minecraft:polished_andesite
fill 286 290 352 286 291 352 minecraft:polished_andesite
fill 286 290 354 286 291 354 minecraft:polished_andesite
fill 286 290 356 286 291 356 minecraft:polished_andesite
fill 287 290 325 287 291 325 minecraft:polished_andesite
fill 287 290 327 287 291 327 minecraft:polished_andesite
fill 287 290 329 287 291 329 minecraft:polished_andesite
fill 287 290 331 287 291 331 minecraft:polished_andesite
fill 287 290 333 287 291 333 minecraft:polished_andesite
fill 287 290 335 287 291 335 minecraft:polished_andesite
fill 287 290 337 287 291 337 minecraft:polished_andesite
fill 287 290 339 287 291 339 minecraft:polished_andesite
fill 287 290 341 287 291 341 minecraft:polished_andesite
fill 288 290 326 288 291 326 minecraft:polished_andesite
fill 288 290 328 288 291 328 minecraft:polished_andesite
fill 288 290 330 288 291 330 minecraft:polished_andesite
fill 288 290 332 288 291 332 minecraft:polished_andesite
fill 288 290 334 288 291 334 minecraft:polished_andesite
fill 288 290 336 288 291 336 minecraft:polished_andesite
fill 288 290 338 288 291 338 minecraft:polished_andesite
fill 288 290 340 288 291 340 minecraft:polished_andesite
fill 288 290 342 288 291 342 minecraft:polished_andesite
fill 289 290 325 289 291 325 minecraft:polished_andesite
fill 289 290 327 289 291 327 minecraft:polished_andesite
fill 289 290 329 289 291 329 minecraft:polished_andesite
fill 289 290 331 289 291 331 minecraft:polished_andesite
fill 289 290 333 289 291 333 minecraft:polished_andesite
fill 289 290 335 289 291 335 minecraft:polished_andesite
fill 289 290 337 289 291 337 minecraft:polished_andesite
fill 289 290 339 289 291 339 minecraft:polished_andesite
fill 289 290 341 289 291 341 minecraft:polished_andesite
fill 313 290 341 313 291 341 minecraft:polished_andesite
fill 313 290 343 313 291 343 minecraft:polished_andesite
fill 313 290 345 313 291 345 minecraft:polished_andesite
fill 314 290 340 314 291 340 minecraft:polished_andesite
fill 314 290 342 314 291 342 minecraft:polished_andesite
fill 314 290 344 314 291 344 minecraft:polished_andesite
fill 314 290 346 314 291 346 minecraft:polished_andesite
fill 314 290 352 314 291 352 minecraft:polished_andesite
fill 314 290 354 314 291 354 minecraft:polished_andesite
fill 314 290 356 314 291 356 minecraft:polished_andesite
fill 314 290 358 314 291 358 minecraft:polished_andesite
fill 314 290 360 314 291 360 minecraft:polished_andesite
fill 314 290 362 314 291 362 minecraft:polished_andesite
fill 314 290 364 314 291 364 minecraft:stone_bricks
fill 315 290 341 315 291 341 minecraft:polished_andesite
fill 315 290 343 315 291 343 minecraft:polished_andesite
fill 315 290 345 315 291 345 minecraft:polished_andesite
fill 315 290 353 315 291 353 minecraft:polished_andesite
fill 315 290 355 315 291 355 minecraft:polished_andesite
fill 315 290 357 315 291 357 minecraft:polished_andesite
fill 315 290 359 315 291 359 minecraft:polished_andesite
fill 315 290 361 315 291 361 minecraft:polished_andesite
fill 315 290 363 315 291 363 minecraft:polished_andesite
fill 316 290 340 316 291 340 minecraft:polished_andesite
fill 316 290 342 316 291 342 minecraft:polished_andesite
fill 316 290 344 316 291 344 minecraft:polished_andesite
fill 316 290 346 316 291 346 minecraft:polished_andesite
fill 316 290 352 316 291 352 minecraft:polished_andesite
fill 316 290 354 316 291 354 minecraft:polished_andesite
fill 316 290 356 316 291 356 minecraft:polished_andesite
fill 316 290 358 316 291 358 minecraft:polished_andesite
fill 316 290 360 316 291 360 minecraft:polished_andesite
fill 316 290 362 316 291 362 minecraft:polished_andesite
fill 316 290 364 316 291 364 minecraft:stone_bricks
fill 317 290 341 317 291 341 minecraft:polished_andesite
fill 317 290 343 317 291 343 minecraft:polished_andesite
fill 317 290 345 317 291 345 minecraft:polished_andesite
fill 317 290 353 317 291 353 minecraft:polished_andesite
fill 317 290 355 317 291 355 minecraft:polished_andesite
fill 317 290 357 317 291 357 minecraft:polished_andesite
fill 317 290 359 317 291 359 minecraft:polished_andesite
fill 317 290 361 317 291 361 minecraft:polished_andesite
fill 317 290 363 317 291 363 minecraft:polished_andesite
fill 318 290 323 318 291 325 minecraft:iron_bars
fill 318 290 340 318 291 340 minecraft:polished_andesite
fill 318 290 342 318 291 342 minecraft:polished_andesite
fill 318 290 344 318 291 344 minecraft:polished_andesite
fill 318 290 346 318 291 346 minecraft:polished_andesite
fill 318 290 352 318 291 352 minecraft:polished_andesite
fill 318 290 354 318 291 354 minecraft:polished_andesite
fill 318 290 356 318 291 356 minecraft:polished_andesite
fill 318 290 358 318 291 358 minecraft:polished_andesite
fill 318 290 360 318 291 360 minecraft:polished_andesite
fill 318 290 362 318 291 362 minecraft:polished_andesite
fill 319 290 341 319 291 341 minecraft:polished_andesite
fill 319 290 343 319 291 343 minecraft:polished_andesite
fill 319 290 345 319 291 345 minecraft:polished_andesite
fill 319 290 353 319 291 353 minecraft:polished_andesite
fill 319 290 355 319 291 355 minecraft:polished_andesite
fill 319 290 357 319 291 357 minecraft:polished_andesite
fill 319 290 359 319 291 359 minecraft:polished_andesite
fill 319 290 361 319 291 361 minecraft:polished_andesite
fill 319 290 363 319 291 363 minecraft:polished_andesite
fill 320 290 340 320 291 340 minecraft:polished_andesite
fill 320 290 342 320 291 342 minecraft:polished_andesite
fill 320 290 344 320 291 344 minecraft:polished_andesite
fill 320 290 346 320 291 346 minecraft:polished_andesite
fill 320 290 352 320 291 352 minecraft:polished_andesite
fill 320 290 354 320 291 354 minecraft:polished_andesite
fill 320 290 356 320 291 356 minecraft:polished_andesite
fill 320 290 358 320 291 358 minecraft:polished_andesite
fill 320 290 360 320 291 360 minecraft:polished_andesite
fill 320 290 362 320 291 362 minecraft:polished_andesite
fill 321 290 341 321 291 341 minecraft:polished_andesite
fill 321 290 343 321 291 343 minecraft:polished_andesite
fill 321 290 345 321 291 345 minecraft:polished_andesite
fill 321 290 353 321 291 353 minecraft:polished_andesite
fill 321 290 355 321 291 355 minecraft:polished_andesite
fill 321 290 357 321 291 357 minecraft:polished_andesite
fill 321 290 359 321 291 359 minecraft:polished_andesite
fill 321 290 361 321 291 361 minecraft:polished_andesite
fill 321 290 363 321 291 363 minecraft:polished_andesite
fill 322 290 340 322 291 340 minecraft:polished_andesite
fill 322 290 342 322 291 342 minecraft:polished_andesite
fill 322 290 344 322 291 344 minecraft:polished_andesite
fill 322 290 346 322 291 346 minecraft:polished_andesite
fill 322 290 352 322 291 352 minecraft:polished_andesite
fill 322 290 354 322 291 354 minecraft:polished_andesite
fill 322 290 356 322 291 356 minecraft:polished_andesite
fill 322 290 358 322 291 358 minecraft:polished_andesite
fill 322 290 360 322 291 360 minecraft:polished_andesite
fill 322 290 362 322 291 362 minecraft:polished_andesite
fill 322 290 364 322 291 364 minecraft:stone_bricks
fill 323 290 341 323 291 341 minecraft:polished_andesite
fill 323 290 343 323 291 343 minecraft:polished_andesite
fill 323 290 345 323 291 345 minecraft:polished_andesite
fill 323 290 353 323 291 353 minecraft:polished_andesite
fill 323 290 355 323 291 355 minecraft:polished_andesite
fill 323 290 357 323 291 357 minecraft:polished_andesite
fill 323 290 359 323 291 359 minecraft:polished_andesite
fill 323 290 361 323 291 361 minecraft:polished_andesite
fill 323 290 363 323 291 363 minecraft:polished_andesite
setblock 285 291 346 minecraft:light[level=12]
setblock 285 291 360 minecraft:light[level=12]
setblock 292 291 325 minecraft:light[level=12]
setblock 292 291 332 minecraft:light[level=12]
setblock 292 291 339 minecraft:light[level=12]
setblock 292 291 346 minecraft:light[level=12]
setblock 292 291 353 minecraft:light[level=12]
setblock 292 291 360 minecraft:light[level=12]
setblock 299 291 325 minecraft:light[level=12]
setblock 299 291 332 minecraft:light[level=12]
setblock 299 291 339 minecraft:light[level=12]
setblock 299 291 346 minecraft:light[level=12]
setblock 299 291 353 minecraft:light[level=12]
setblock 299 291 360 minecraft:light[level=12]
setblock 306 291 325 minecraft:light[level=12]
setblock 306 291 332 minecraft:light[level=12]
setblock 306 291 339 minecraft:light[level=12]
setblock 306 291 346 minecraft:light[level=12]
setblock 306 291 353 minecraft:light[level=12]
setblock 306 291 360 minecraft:light[level=12]
setblock 313 291 325 minecraft:light[level=12]
setblock 313 291 332 minecraft:light[level=12]
setblock 313 291 339 minecraft:light[level=12]
setblock 313 291 360 minecraft:light[level=12]
setblock 320 291 325 minecraft:light[level=12]
setblock 320 291 332 minecraft:light[level=12]
setblock 320 291 339 minecraft:light[level=12]
fill 282 292 328 282 308 328 minecraft:stone_bricks
fill 282 292 329 282 292 330 minecraft:shroomlight
fill 282 292 331 282 308 331 minecraft:stone_bricks
fill 282 292 340 282 308 340 minecraft:stone_bricks
fill 282 292 341 282 292 342 minecraft:shroomlight
fill 282 292 343 282 308 343 minecraft:stone_bricks
fill 282 292 352 282 308 352 minecraft:stone_bricks
fill 282 292 353 282 292 354 minecraft:shroomlight
fill 282 292 355 282 308 355 minecraft:stone_bricks
fill 282 292 364 282 308 364 minecraft:stone_bricks
setblock 283 292 325 minecraft:shroomlight
setblock 283 292 327 minecraft:shroomlight
setblock 283 292 329 minecraft:shroomlight
setblock 283 292 331 minecraft:shroomlight
setblock 283 292 333 minecraft:shroomlight
setblock 283 292 335 minecraft:shroomlight
setblock 283 292 337 minecraft:shroomlight
setblock 283 292 339 minecraft:shroomlight
setblock 283 292 341 minecraft:shroomlight
setblock 283 292 347 minecraft:shroomlight
setblock 283 292 349 minecraft:shroomlight
setblock 283 292 351 minecraft:shroomlight
setblock 283 292 353 minecraft:shroomlight
setblock 283 292 355 minecraft:shroomlight
setblock 283 292 357 minecraft:shroomlight
fill 283 292 364 284 292 364 minecraft:shroomlight
setblock 284 292 326 minecraft:shroomlight
setblock 284 292 328 minecraft:shroomlight
setblock 284 292 330 minecraft:shroomlight
setblock 284 292 332 minecraft:shroomlight
setblock 284 292 334 minecraft:shroomlight
setblock 284 292 336 minecraft:shroomlight
setblock 284 292 338 minecraft:shroomlight
setblock 284 292 340 minecraft:shroomlight
setblock 284 292 342 minecraft:shroomlight
setblock 284 292 348 minecraft:shroomlight
setblock 284 292 350 minecraft:shroomlight
setblock 284 292 352 minecraft:shroomlight
setblock 284 292 354 minecraft:shroomlight
setblock 284 292 356 minecraft:shroomlight
setblock 285 292 325 minecraft:shroomlight
setblock 285 292 327 minecraft:shroomlight
setblock 285 292 329 minecraft:shroomlight
setblock 285 292 331 minecraft:shroomlight
setblock 285 292 333 minecraft:shroomlight
setblock 285 292 335 minecraft:shroomlight
setblock 285 292 337 minecraft:shroomlight
setblock 285 292 339 minecraft:shroomlight
setblock 285 292 341 minecraft:shroomlight
setblock 285 292 347 minecraft:shroomlight
setblock 285 292 349 minecraft:shroomlight
setblock 285 292 351 minecraft:shroomlight
setblock 285 292 353 minecraft:shroomlight
setblock 285 292 355 minecraft:shroomlight
setblock 285 292 357 minecraft:shroomlight
fill 285 292 364 285 308 364 minecraft:stone_bricks
setblock 286 292 326 minecraft:shroomlight
setblock 286 292 328 minecraft:shroomlight
setblock 286 292 330 minecraft:shroomlight
setblock 286 292 332 minecraft:shroomlight
setblock 286 292 334 minecraft:shroomlight
setblock 286 292 336 minecraft:shroomlight
setblock 286 292 338 minecraft:shroomlight
setblock 286 292 340 minecraft:shroomlight
setblock 286 292 342 minecraft:shroomlight
setblock 286 292 348 minecraft:shroomlight
setblock 286 292 350 minecraft:shroomlight
setblock 286 292 352 minecraft:shroomlight
setblock 286 292 354 minecraft:shroomlight
setblock 286 292 356 minecraft:shroomlight
setblock 287 292 325 minecraft:shroomlight
setblock 287 292 327 minecraft:shroomlight
setblock 287 292 329 minecraft:shroomlight
setblock 287 292 331 minecraft:shroomlight
setblock 287 292 333 minecraft:shroomlight
setblock 287 292 335 minecraft:shroomlight
setblock 287 292 337 minecraft:shroomlight
setblock 287 292 339 minecraft:shroomlight
setblock 287 292 341 minecraft:shroomlight
setblock 288 292 326 minecraft:shroomlight
setblock 288 292 328 minecraft:shroomlight
setblock 288 292 330 minecraft:shroomlight
setblock 288 292 332 minecraft:shroomlight
setblock 288 292 334 minecraft:shroomlight
setblock 288 292 336 minecraft:shroomlight
setblock 288 292 338 minecraft:shroomlight
setblock 288 292 340 minecraft:shroomlight
setblock 288 292 342 minecraft:shroomlight
fill 289 292 322 289 308 322 minecraft:stone_bricks
setblock 289 292 325 minecraft:shroomlight
setblock 289 292 327 minecraft:shroomlight
setblock 289 292 329 minecraft:shroomlight
setblock 289 292 331 minecraft:shroomlight
setblock 289 292 333 minecraft:shroomlight
setblock 289 292 335 minecraft:shroomlight
setblock 289 292 337 minecraft:shroomlight
setblock 289 292 339 minecraft:shroomlight
setblock 289 292 341 minecraft:shroomlight
fill 290 292 322 291 292 322 minecraft:shroomlight
fill 292 292 322 292 308 322 minecraft:stone_bricks
fill 294 292 364 294 308 364 minecraft:stone_bricks
fill 295 292 364 296 292 364 minecraft:shroomlight
fill 297 292 364 297 308 364 minecraft:stone_bricks
fill 301 292 322 301 308 322 minecraft:stone_bricks
fill 302 292 322 303 292 322 minecraft:shroomlight
fill 304 292 322 304 308 322 minecraft:stone_bricks
fill 306 292 364 306 308 364 minecraft:stone_bricks
fill 307 292 364 308 292 364 minecraft:shroomlight
fill 309 292 364 309 308 364 minecraft:stone_bricks
fill 313 292 322 313 308 322 minecraft:stone_bricks
setblock 313 292 341 minecraft:shroomlight
setblock 313 292 343 minecraft:shroomlight
setblock 313 292 345 minecraft:shroomlight
fill 314 292 322 315 292 322 minecraft:shroomlight
setblock 314 292 340 minecraft:shroomlight
setblock 314 292 342 minecraft:shroomlight
setblock 314 292 344 minecraft:shroomlight
setblock 314 292 346 minecraft:shroomlight
setblock 314 292 352 minecraft:shroomlight
setblock 314 292 354 minecraft:shroomlight
setblock 314 292 356 minecraft:shroomlight
setblock 314 292 358 minecraft:shroomlight
setblock 314 292 360 minecraft:shroomlight
setblock 314 292 362 minecraft:shroomlight
setblock 314 292 364 minecraft:shroomlight
setblock 315 292 341 minecraft:shroomlight
setblock 315 292 343 minecraft:shroomlight
setblock 315 292 345 minecraft:shroomlight
setblock 315 292 353 minecraft:shroomlight
setblock 315 292 355 minecraft:shroomlight
setblock 315 292 357 minecraft:shroomlight
setblock 315 292 359 minecraft:shroomlight
setblock 315 292 361 minecraft:shroomlight
setblock 315 292 363 minecraft:shroomlight
fill 316 292 322 316 308 322 minecraft:stone_bricks
setblock 316 292 340 minecraft:shroomlight
setblock 316 292 342 minecraft:shroomlight
setblock 316 292 344 minecraft:shroomlight
setblock 316 292 346 minecraft:shroomlight
setblock 316 292 352 minecraft:shroomlight
setblock 316 292 354 minecraft:shroomlight
setblock 316 292 356 minecraft:shroomlight
setblock 316 292 358 minecraft:shroomlight
setblock 316 292 360 minecraft:shroomlight
setblock 316 292 362 minecraft:shroomlight
setblock 316 292 364 minecraft:shroomlight
setblock 317 292 341 minecraft:shroomlight
setblock 317 292 343 minecraft:shroomlight
setblock 317 292 345 minecraft:shroomlight
setblock 317 292 353 minecraft:shroomlight
setblock 317 292 355 minecraft:shroomlight
setblock 317 292 357 minecraft:shroomlight
setblock 317 292 359 minecraft:shroomlight
setblock 317 292 361 minecraft:shroomlight
setblock 317 292 363 minecraft:shroomlight
setblock 318 292 340 minecraft:shroomlight
setblock 318 292 342 minecraft:shroomlight
setblock 318 292 344 minecraft:shroomlight
setblock 318 292 346 minecraft:shroomlight
setblock 318 292 352 minecraft:shroomlight
setblock 318 292 354 minecraft:shroomlight
setblock 318 292 356 minecraft:shroomlight
setblock 318 292 358 minecraft:shroomlight
setblock 318 292 360 minecraft:shroomlight
setblock 318 292 362 minecraft:shroomlight
fill 318 292 364 320 292 364 minecraft:shroomlight
setblock 319 292 341 minecraft:shroomlight
setblock 319 292 343 minecraft:shroomlight
setblock 319 292 345 minecraft:shroomlight
setblock 319 292 353 minecraft:shroomlight
setblock 319 292 355 minecraft:shroomlight
setblock 319 292 357 minecraft:shroomlight
setblock 319 292 359 minecraft:shroomlight
setblock 319 292 361 minecraft:shroomlight
setblock 319 292 363 minecraft:shroomlight
setblock 320 292 340 minecraft:shroomlight
setblock 320 292 342 minecraft:shroomlight
setblock 320 292 344 minecraft:shroomlight
setblock 320 292 346 minecraft:shroomlight
setblock 320 292 352 minecraft:shroomlight
setblock 320 292 354 minecraft:shroomlight
setblock 320 292 356 minecraft:shroomlight
setblock 320 292 358 minecraft:shroomlight
setblock 320 292 360 minecraft:shroomlight
setblock 320 292 362 minecraft:shroomlight
setblock 321 292 341 minecraft:shroomlight
setblock 321 292 343 minecraft:shroomlight
setblock 321 292 345 minecraft:shroomlight
setblock 321 292 353 minecraft:shroomlight
setblock 321 292 355 minecraft:shroomlight
setblock 321 292 357 minecraft:shroomlight
setblock 321 292 359 minecraft:shroomlight
setblock 321 292 361 minecraft:shroomlight
setblock 321 292 363 minecraft:shroomlight
fill 321 292 364 321 308 364 minecraft:stone_bricks
setblock 322 292 340 minecraft:shroomlight
setblock 322 292 342 minecraft:shroomlight
setblock 322 292 344 minecraft:shroomlight
setblock 322 292 346 minecraft:shroomlight
setblock 322 292 352 minecraft:shroomlight
setblock 322 292 354 minecraft:shroomlight
setblock 322 292 356 minecraft:shroomlight
setblock 322 292 358 minecraft:shroomlight
setblock 322 292 360 minecraft:shroomlight
setblock 322 292 362 minecraft:shroomlight
setblock 322 292 364 minecraft:shroomlight
setblock 323 292 341 minecraft:shroomlight
setblock 323 292 343 minecraft:shroomlight
setblock 323 292 345 minecraft:shroomlight
setblock 323 292 353 minecraft:shroomlight
setblock 323 292 355 minecraft:shroomlight
setblock 323 292 357 minecraft:shroomlight
setblock 323 292 359 minecraft:shroomlight
setblock 323 292 361 minecraft:shroomlight
setblock 323 292 363 minecraft:shroomlight
fill 324 292 323 324 308 323 minecraft:stone_bricks
fill 324 292 324 324 292 325 minecraft:shroomlight
fill 324 292 326 324 308 326 minecraft:stone_bricks
fill 324 292 335 324 308 335 minecraft:stone_bricks
fill 324 292 336 324 292 337 minecraft:shroomlight
fill 324 292 338 324 308 338 minecraft:stone_bricks
fill 324 292 347 324 308 347 minecraft:stone_bricks
fill 324 292 348 324 292 349 minecraft:shroomlight
fill 324 292 350 324 308 350 minecraft:stone_bricks
fill 324 292 359 324 308 359 minecraft:stone_bricks
fill 324 292 362 324 308 362 minecraft:stone_bricks
fill 282 293 329 282 308 330 minecraft:stone_bricks
fill 282 293 341 282 308 342 minecraft:stone_bricks
fill 282 293 353 282 308 354 minecraft:stone_bricks
fill 283 293 325 283 294 325 minecraft:polished_andesite
fill 283 293 327 283 294 327 minecraft:polished_andesite
fill 283 293 329 283 294 329 minecraft:polished_andesite
fill 283 293 331 283 294 331 minecraft:polished_andesite
fill 283 293 333 283 294 333 minecraft:polished_andesite
fill 283 293 335 283 294 335 minecraft:polished_andesite
fill 283 293 337 283 294 337 minecraft:polished_andesite
fill 283 293 339 283 294 339 minecraft:polished_andesite
fill 283 293 341 283 294 341 minecraft:polished_andesite
fill 283 293 347 283 294 347 minecraft:polished_andesite
fill 283 293 349 283 294 349 minecraft:polished_andesite
fill 283 293 351 283 294 351 minecraft:polished_andesite
fill 283 293 353 283 294 353 minecraft:polished_andesite
fill 283 293 355 283 294 355 minecraft:polished_andesite
fill 283 293 357 283 294 357 minecraft:polished_andesite
fill 283 293 364 284 308 364 minecraft:stone_bricks
fill 284 293 326 284 294 326 minecraft:polished_andesite
fill 284 293 328 284 294 328 minecraft:polished_andesite
fill 284 293 330 284 294 330 minecraft:polished_andesite
fill 284 293 332 284 294 332 minecraft:polished_andesite
fill 284 293 334 284 294 334 minecraft:polished_andesite
fill 284 293 336 284 294 336 minecraft:polished_andesite
fill 284 293 338 284 294 338 minecraft:polished_andesite
fill 284 293 340 284 294 340 minecraft:polished_andesite
fill 284 293 342 284 294 342 minecraft:polished_andesite
fill 284 293 348 284 294 348 minecraft:polished_andesite
fill 284 293 350 284 294 350 minecraft:polished_andesite
fill 284 293 352 284 294 352 minecraft:polished_andesite
fill 284 293 354 284 294 354 minecraft:polished_andesite
fill 284 293 356 284 294 356 minecraft:polished_andesite
fill 285 293 325 285 294 325 minecraft:polished_andesite
fill 285 293 327 285 294 327 minecraft:polished_andesite
fill 285 293 329 285 294 329 minecraft:polished_andesite
fill 285 293 331 285 294 331 minecraft:polished_andesite
fill 285 293 333 285 294 333 minecraft:polished_andesite
fill 285 293 335 285 294 335 minecraft:polished_andesite
fill 285 293 337 285 294 337 minecraft:polished_andesite
fill 285 293 339 285 294 339 minecraft:polished_andesite
fill 285 293 341 285 294 341 minecraft:polished_andesite
fill 285 293 347 285 294 347 minecraft:polished_andesite
fill 285 293 349 285 294 349 minecraft:polished_andesite
fill 285 293 351 285 294 351 minecraft:polished_andesite
fill 285 293 353 285 294 353 minecraft:polished_andesite
fill 285 293 355 285 294 355 minecraft:polished_andesite
fill 285 293 357 285 294 357 minecraft:polished_andesite
fill 286 293 326 286 294 326 minecraft:polished_andesite
fill 286 293 328 286 294 328 minecraft:polished_andesite
fill 286 293 330 286 294 330 minecraft:polished_andesite
fill 286 293 332 286 294 332 minecraft:polished_andesite
fill 286 293 334 286 294 334 minecraft:polished_andesite
fill 286 293 336 286 294 336 minecraft:polished_andesite
fill 286 293 338 286 294 338 minecraft:polished_andesite
fill 286 293 340 286 294 340 minecraft:polished_andesite
fill 286 293 342 286 294 342 minecraft:polished_andesite
fill 286 293 348 286 294 348 minecraft:polished_andesite
fill 286 293 350 286 294 350 minecraft:polished_andesite
fill 286 293 352 286 294 352 minecraft:polished_andesite
fill 286 293 354 286 294 354 minecraft:polished_andesite
fill 286 293 356 286 294 356 minecraft:polished_andesite
fill 287 293 325 287 294 325 minecraft:polished_andesite
fill 287 293 327 287 294 327 minecraft:polished_andesite
fill 287 293 329 287 294 329 minecraft:polished_andesite
fill 287 293 331 287 294 331 minecraft:polished_andesite
fill 287 293 333 287 294 333 minecraft:polished_andesite
fill 287 293 335 287 294 335 minecraft:polished_andesite
fill 287 293 337 287 294 337 minecraft:polished_andesite
fill 287 293 339 287 294 339 minecraft:polished_andesite
fill 287 293 341 287 294 341 minecraft:polished_andesite
fill 288 293 326 288 294 326 minecraft:polished_andesite
fill 288 293 328 288 294 328 minecraft:polished_andesite
fill 288 293 330 288 294 330 minecraft:polished_andesite
fill 288 293 332 288 294 332 minecraft:polished_andesite
fill 288 293 334 288 294 334 minecraft:polished_andesite
fill 288 293 336 288 294 336 minecraft:polished_andesite
fill 288 293 338 288 294 338 minecraft:polished_andesite
fill 288 293 340 288 294 340 minecraft:polished_andesite
fill 288 293 342 288 294 342 minecraft:polished_andesite
fill 289 293 325 289 294 325 minecraft:polished_andesite
fill 289 293 327 289 294 327 minecraft:polished_andesite
fill 289 293 329 289 294 329 minecraft:polished_andesite
fill 289 293 331 289 294 331 minecraft:polished_andesite
fill 289 293 333 289 294 333 minecraft:polished_andesite
fill 289 293 335 289 294 335 minecraft:polished_andesite
fill 289 293 337 289 294 337 minecraft:polished_andesite
fill 289 293 339 289 294 339 minecraft:polished_andesite
fill 289 293 341 289 294 341 minecraft:polished_andesite
fill 290 293 322 291 308 322 minecraft:stone_bricks
fill 295 293 364 296 308 364 minecraft:stone_bricks
fill 302 293 322 303 308 322 minecraft:stone_bricks
fill 307 293 364 308 308 364 minecraft:stone_bricks
fill 313 293 341 313 294 341 minecraft:polished_andesite
fill 313 293 343 313 294 343 minecraft:polished_andesite
fill 313 293 345 313 294 345 minecraft:polished_andesite
fill 314 293 322 315 308 322 minecraft:stone_bricks
fill 314 293 340 314 294 340 minecraft:polished_andesite
fill 314 293 342 314 294 342 minecraft:polished_andesite
fill 314 293 344 314 294 344 minecraft:polished_andesite
fill 314 293 346 314 294 346 minecraft:polished_andesite
fill 314 293 352 314 294 352 minecraft:polished_andesite
fill 314 293 354 314 294 354 minecraft:polished_andesite
fill 314 293 356 314 294 356 minecraft:polished_andesite
fill 314 293 358 314 294 358 minecraft:polished_andesite
fill 314 293 360 314 294 360 minecraft:polished_andesite
fill 314 293 362 314 294 362 minecraft:polished_andesite
fill 314 293 364 314 294 364 minecraft:stone_bricks
fill 315 293 341 315 294 341 minecraft:polished_andesite
fill 315 293 343 315 294 343 minecraft:polished_andesite
fill 315 293 345 315 294 345 minecraft:polished_andesite
fill 315 293 353 315 294 353 minecraft:polished_andesite
fill 315 293 355 315 294 355 minecraft:polished_andesite
fill 315 293 357 315 294 357 minecraft:polished_andesite
fill 315 293 359 315 294 359 minecraft:polished_andesite
fill 315 293 361 315 294 361 minecraft:polished_andesite
fill 315 293 363 315 294 363 minecraft:polished_andesite
fill 316 293 340 316 294 340 minecraft:polished_andesite
fill 316 293 342 316 294 342 minecraft:polished_andesite
fill 316 293 344 316 294 344 minecraft:polished_andesite
fill 316 293 346 316 294 346 minecraft:polished_andesite
fill 316 293 352 316 294 352 minecraft:polished_andesite
fill 316 293 354 316 294 354 minecraft:polished_andesite
fill 316 293 356 316 294 356 minecraft:polished_andesite
fill 316 293 358 316 294 358 minecraft:polished_andesite
fill 316 293 360 316 294 360 minecraft:polished_andesite
fill 316 293 362 316 294 362 minecraft:polished_andesite
fill 316 293 364 316 294 364 minecraft:stone_bricks
fill 317 293 341 317 294 341 minecraft:polished_andesite
fill 317 293 343 317 294 343 minecraft:polished_andesite
fill 317 293 345 317 294 345 minecraft:polished_andesite
fill 317 293 353 317 294 353 minecraft:polished_andesite
fill 317 293 355 317 294 355 minecraft:polished_andesite
fill 317 293 357 317 294 357 minecraft:polished_andesite
fill 317 293 359 317 294 359 minecraft:polished_andesite
fill 317 293 361 317 294 361 minecraft:polished_andesite
fill 317 293 363 317 294 363 minecraft:polished_andesite
fill 318 293 340 318 294 340 minecraft:polished_andesite
fill 318 293 342 318 294 342 minecraft:polished_andesite
fill 318 293 344 318 294 344 minecraft:polished_andesite
fill 318 293 346 318 294 346 minecraft:polished_andesite
fill 318 293 352 318 294 352 minecraft:polished_andesite
fill 318 293 354 318 294 354 minecraft:polished_andesite
fill 318 293 356 318 294 356 minecraft:polished_andesite
fill 318 293 358 318 294 358 minecraft:polished_andesite
fill 318 293 360 318 294 360 minecraft:polished_andesite
fill 318 293 362 318 294 362 minecraft:polished_andesite
fill 318 293 364 320 294 364 minecraft:stone_bricks
fill 319 293 341 319 294 341 minecraft:polished_andesite
fill 319 293 343 319 294 343 minecraft:polished_andesite
fill 319 293 345 319 294 345 minecraft:polished_andesite
fill 319 293 353 319 294 353 minecraft:polished_andesite
fill 319 293 355 319 294 355 minecraft:polished_andesite
fill 319 293 357 319 294 357 minecraft:polished_andesite
fill 319 293 359 319 294 359 minecraft:polished_andesite
fill 319 293 361 319 294 361 minecraft:polished_andesite
fill 319 293 363 319 294 363 minecraft:polished_andesite
fill 320 293 340 320 294 340 minecraft:polished_andesite
fill 320 293 342 320 294 342 minecraft:polished_andesite
fill 320 293 344 320 294 344 minecraft:polished_andesite
fill 320 293 346 320 294 346 minecraft:polished_andesite
fill 320 293 352 320 294 352 minecraft:polished_andesite
fill 320 293 354 320 294 354 minecraft:polished_andesite
fill 320 293 356 320 294 356 minecraft:polished_andesite
fill 320 293 358 320 294 358 minecraft:polished_andesite
fill 320 293 360 320 294 360 minecraft:polished_andesite
fill 320 293 362 320 294 362 minecraft:polished_andesite
fill 321 293 341 321 294 341 minecraft:polished_andesite
fill 321 293 343 321 294 343 minecraft:polished_andesite
fill 321 293 345 321 294 345 minecraft:polished_andesite
fill 321 293 353 321 294 353 minecraft:polished_andesite
fill 321 293 355 321 294 355 minecraft:polished_andesite
fill 321 293 357 321 294 357 minecraft:polished_andesite
fill 321 293 359 321 294 359 minecraft:polished_andesite
fill 321 293 361 321 294 361 minecraft:polished_andesite
fill 321 293 363 321 294 363 minecraft:polished_andesite
fill 322 293 340 322 294 340 minecraft:polished_andesite
fill 322 293 342 322 294 342 minecraft:polished_andesite
fill 322 293 344 322 294 344 minecraft:polished_andesite
fill 322 293 346 322 294 346 minecraft:polished_andesite
fill 322 293 352 322 294 352 minecraft:polished_andesite
fill 322 293 354 322 294 354 minecraft:polished_andesite
fill 322 293 356 322 294 356 minecraft:polished_andesite
fill 322 293 358 322 294 358 minecraft:polished_andesite
fill 322 293 360 322 294 360 minecraft:polished_andesite
fill 322 293 362 322 294 362 minecraft:polished_andesite
fill 322 293 364 322 294 364 minecraft:stone_bricks
fill 323 293 341 323 294 341 minecraft:polished_andesite
fill 323 293 343 323 294 343 minecraft:polished_andesite
fill 323 293 345 323 294 345 minecraft:polished_andesite
fill 323 293 353 323 294 353 minecraft:polished_andesite
fill 323 293 355 323 294 355 minecraft:polished_andesite
fill 323 293 357 323 294 357 minecraft:polished_andesite
fill 323 293 359 323 294 359 minecraft:polished_andesite
fill 323 293 361 323 294 361 minecraft:polished_andesite
fill 323 293 363 323 294 363 minecraft:polished_andesite
fill 324 293 324 324 308 325 minecraft:stone_bricks
fill 324 293 336 324 308 337 minecraft:stone_bricks
fill 324 293 348 324 308 349 minecraft:stone_bricks
fill 324 293 360 324 308 361 minecraft:stone_bricks
setblock 283 295 325 minecraft:shroomlight
setblock 283 295 327 minecraft:shroomlight
setblock 283 295 329 minecraft:shroomlight
setblock 283 295 331 minecraft:shroomlight
setblock 283 295 333 minecraft:shroomlight
setblock 283 295 335 minecraft:shroomlight
setblock 283 295 337 minecraft:shroomlight
setblock 283 295 339 minecraft:shroomlight
setblock 283 295 341 minecraft:shroomlight
setblock 283 295 347 minecraft:shroomlight
setblock 283 295 349 minecraft:shroomlight
setblock 283 295 351 minecraft:shroomlight
setblock 283 295 353 minecraft:shroomlight
setblock 283 295 355 minecraft:shroomlight
setblock 283 295 357 minecraft:shroomlight
setblock 284 295 326 minecraft:shroomlight
setblock 284 295 328 minecraft:shroomlight
setblock 284 295 330 minecraft:shroomlight
setblock 284 295 332 minecraft:shroomlight
setblock 284 295 334 minecraft:shroomlight
setblock 284 295 336 minecraft:shroomlight
setblock 284 295 338 minecraft:shroomlight
setblock 284 295 340 minecraft:shroomlight
setblock 284 295 342 minecraft:shroomlight
setblock 284 295 348 minecraft:shroomlight
setblock 284 295 350 minecraft:shroomlight
setblock 284 295 352 minecraft:shroomlight
setblock 284 295 354 minecraft:shroomlight
setblock 284 295 356 minecraft:shroomlight
setblock 285 295 325 minecraft:shroomlight
setblock 285 295 327 minecraft:shroomlight
setblock 285 295 329 minecraft:shroomlight
setblock 285 295 331 minecraft:shroomlight
setblock 285 295 333 minecraft:shroomlight
setblock 285 295 335 minecraft:shroomlight
setblock 285 295 337 minecraft:shroomlight
setblock 285 295 339 minecraft:shroomlight
setblock 285 295 341 minecraft:shroomlight
setblock 285 295 347 minecraft:shroomlight
setblock 285 295 349 minecraft:shroomlight
setblock 285 295 351 minecraft:shroomlight
setblock 285 295 353 minecraft:shroomlight
setblock 285 295 355 minecraft:shroomlight
setblock 285 295 357 minecraft:shroomlight
setblock 286 295 326 minecraft:shroomlight
setblock 286 295 328 minecraft:shroomlight
setblock 286 295 330 minecraft:shroomlight
setblock 286 295 332 minecraft:shroomlight
setblock 286 295 334 minecraft:shroomlight
setblock 286 295 336 minecraft:shroomlight
setblock 286 295 338 minecraft:shroomlight
setblock 286 295 340 minecraft:shroomlight
setblock 286 295 342 minecraft:shroomlight
setblock 286 295 348 minecraft:shroomlight
setblock 286 295 350 minecraft:shroomlight
setblock 286 295 352 minecraft:shroomlight
setblock 286 295 354 minecraft:shroomlight
setblock 286 295 356 minecraft:shroomlight
setblock 287 295 325 minecraft:shroomlight
setblock 287 295 327 minecraft:shroomlight
setblock 287 295 329 minecraft:shroomlight
setblock 287 295 331 minecraft:shroomlight
setblock 287 295 333 minecraft:shroomlight
setblock 287 295 335 minecraft:shroomlight
setblock 287 295 337 minecraft:shroomlight
setblock 287 295 339 minecraft:shroomlight
setblock 287 295 341 minecraft:shroomlight
setblock 288 295 326 minecraft:shroomlight
setblock 288 295 328 minecraft:shroomlight
setblock 288 295 330 minecraft:shroomlight
setblock 288 295 332 minecraft:shroomlight
setblock 288 295 334 minecraft:shroomlight
setblock 288 295 336 minecraft:shroomlight
setblock 288 295 338 minecraft:shroomlight
setblock 288 295 340 minecraft:shroomlight
setblock 288 295 342 minecraft:shroomlight
setblock 289 295 325 minecraft:shroomlight
setblock 289 295 327 minecraft:shroomlight
setblock 289 295 329 minecraft:shroomlight
setblock 289 295 331 minecraft:shroomlight
setblock 289 295 333 minecraft:shroomlight
setblock 289 295 335 minecraft:shroomlight
setblock 289 295 337 minecraft:shroomlight
setblock 289 295 339 minecraft:shroomlight
setblock 289 295 341 minecraft:shroomlight
setblock 293 295 325 minecraft:light[level=15]
setblock 293 295 333 minecraft:light[level=15]
setblock 293 295 341 minecraft:light[level=15]
setblock 293 295 349 minecraft:light[level=15]
setblock 293 295 357 minecraft:light[level=15]
setblock 301 295 325 minecraft:light[level=15]
setblock 301 295 333 minecraft:light[level=15]
setblock 301 295 341 minecraft:light[level=15]
setblock 301 295 349 minecraft:light[level=15]
setblock 301 295 357 minecraft:light[level=15]
setblock 309 295 325 minecraft:light[level=15]
setblock 309 295 333 minecraft:light[level=15]
setblock 309 295 341 minecraft:light[level=15]
setblock 309 295 349 minecraft:light[level=15]
setblock 309 295 357 minecraft:light[level=15]
setblock 313 295 341 minecraft:shroomlight
setblock 313 295 343 minecraft:shroomlight
setblock 313 295 345 minecraft:shroomlight
setblock 314 295 340 minecraft:shroomlight
setblock 314 295 342 minecraft:shroomlight
setblock 314 295 344 minecraft:shroomlight
setblock 314 295 346 minecraft:shroomlight
setblock 314 295 352 minecraft:shroomlight
setblock 314 295 354 minecraft:shroomlight
setblock 314 295 356 minecraft:shroomlight
setblock 314 295 358 minecraft:shroomlight
setblock 314 295 360 minecraft:shroomlight
setblock 314 295 362 minecraft:shroomlight
setblock 314 295 364 minecraft:shroomlight
setblock 315 295 341 minecraft:shroomlight
setblock 315 295 343 minecraft:shroomlight
setblock 315 295 345 minecraft:shroomlight
setblock 315 295 353 minecraft:shroomlight
setblock 315 295 355 minecraft:shroomlight
setblock 315 295 357 minecraft:shroomlight
setblock 315 295 359 minecraft:shroomlight
setblock 315 295 361 minecraft:shroomlight
setblock 315 295 363 minecraft:shroomlight
setblock 316 295 340 minecraft:shroomlight
setblock 316 295 342 minecraft:shroomlight
setblock 316 295 344 minecraft:shroomlight
setblock 316 295 346 minecraft:shroomlight
setblock 316 295 352 minecraft:shroomlight
setblock 316 295 354 minecraft:shroomlight
setblock 316 295 356 minecraft:shroomlight
setblock 316 295 358 minecraft:shroomlight
setblock 316 295 360 minecraft:shroomlight
setblock 316 295 362 minecraft:shroomlight
setblock 316 295 364 minecraft:shroomlight
setblock 317 295 325 minecraft:light[level=15]
setblock 317 295 333 minecraft:light[level=15]
setblock 317 295 341 minecraft:shroomlight
setblock 317 295 343 minecraft:shroomlight
setblock 317 295 345 minecraft:shroomlight
setblock 317 295 349 minecraft:light[level=15]
setblock 317 295 353 minecraft:shroomlight
setblock 317 295 355 minecraft:shroomlight
setblock 317 295 357 minecraft:shroomlight
setblock 317 295 359 minecraft:shroomlight
setblock 317 295 361 minecraft:shroomlight
setblock 317 295 363 minecraft:shroomlight
setblock 318 295 340 minecraft:shroomlight
setblock 318 295 342 minecraft:shroomlight
setblock 318 295 344 minecraft:shroomlight
setblock 318 295 346 minecraft:shroomlight
setblock 318 295 352 minecraft:shroomlight
setblock 318 295 354 minecraft:shroomlight
setblock 318 295 356 minecraft:shroomlight
setblock 318 295 358 minecraft:shroomlight
setblock 318 295 360 minecraft:shroomlight
setblock 318 295 362 minecraft:shroomlight
setblock 318 295 364 minecraft:shroomlight
setblock 319 295 341 minecraft:shroomlight
setblock 319 295 343 minecraft:shroomlight
setblock 319 295 345 minecraft:shroomlight
setblock 319 295 353 minecraft:shroomlight
setblock 319 295 355 minecraft:shroomlight
setblock 319 295 357 minecraft:shroomlight
setblock 319 295 359 minecraft:shroomlight
setblock 319 295 361 minecraft:shroomlight
setblock 319 295 363 minecraft:shroomlight
fill 319 295 364 319 308 364 minecraft:stone_bricks
setblock 320 295 340 minecraft:shroomlight
setblock 320 295 342 minecraft:shroomlight
setblock 320 295 344 minecraft:shroomlight
setblock 320 295 346 minecraft:shroomlight
setblock 320 295 352 minecraft:shroomlight
setblock 320 295 354 minecraft:shroomlight
setblock 320 295 356 minecraft:shroomlight
setblock 320 295 358 minecraft:shroomlight
setblock 320 295 360 minecraft:shroomlight
setblock 320 295 362 minecraft:shroomlight
setblock 320 295 364 minecraft:shroomlight
setblock 321 295 341 minecraft:shroomlight
setblock 321 295 343 minecraft:shroomlight
setblock 321 295 345 minecraft:shroomlight
setblock 321 295 353 minecraft:shroomlight
setblock 321 295 355 minecraft:shroomlight
setblock 321 295 357 minecraft:shroomlight
setblock 321 295 359 minecraft:shroomlight
setblock 321 295 361 minecraft:shroomlight
setblock 321 295 363 minecraft:shroomlight
setblock 322 295 340 minecraft:shroomlight
setblock 322 295 342 minecraft:shroomlight
setblock 322 295 344 minecraft:shroomlight
setblock 322 295 346 minecraft:shroomlight
setblock 322 295 352 minecraft:shroomlight
setblock 322 295 354 minecraft:shroomlight
setblock 322 295 356 minecraft:shroomlight
setblock 322 295 358 minecraft:shroomlight
setblock 322 295 360 minecraft:shroomlight
setblock 322 295 362 minecraft:shroomlight
setblock 322 295 364 minecraft:shroomlight
setblock 323 295 341 minecraft:shroomlight
setblock 323 295 343 minecraft:shroomlight
setblock 323 295 345 minecraft:shroomlight
setblock 323 295 353 minecraft:shroomlight
setblock 323 295 355 minecraft:shroomlight
setblock 323 295 357 minecraft:shroomlight
setblock 323 295 359 minecraft:shroomlight
setblock 323 295 361 minecraft:shroomlight
setblock 323 295 363 minecraft:shroomlight
fill 283 296 325 283 297 325 minecraft:polished_andesite
fill 283 296 327 283 297 327 minecraft:polished_andesite
fill 283 296 329 283 297 329 minecraft:polished_andesite
fill 283 296 331 283 297 331 minecraft:polished_andesite
fill 283 296 333 283 297 333 minecraft:polished_andesite
fill 283 296 335 283 297 335 minecraft:polished_andesite
fill 283 296 337 283 297 337 minecraft:polished_andesite
fill 283 296 339 283 297 339 minecraft:polished_andesite
fill 283 296 341 283 297 341 minecraft:polished_andesite
fill 283 296 347 283 297 347 minecraft:polished_andesite
fill 283 296 349 283 297 349 minecraft:polished_andesite
fill 283 296 351 283 297 351 minecraft:polished_andesite
fill 283 296 353 283 297 353 minecraft:polished_andesite
fill 283 296 355 283 297 355 minecraft:polished_andesite
fill 283 296 357 283 297 357 minecraft:polished_andesite
fill 284 296 326 284 297 326 minecraft:polished_andesite
fill 284 296 328 284 297 328 minecraft:polished_andesite
fill 284 296 330 284 297 330 minecraft:polished_andesite
fill 284 296 332 284 297 332 minecraft:polished_andesite
fill 284 296 334 284 297 334 minecraft:polished_andesite
fill 284 296 336 284 297 336 minecraft:polished_andesite
fill 284 296 338 284 297 338 minecraft:polished_andesite
fill 284 296 340 284 297 340 minecraft:polished_andesite
fill 284 296 342 284 297 342 minecraft:polished_andesite
fill 284 296 348 284 297 348 minecraft:polished_andesite
fill 284 296 350 284 297 350 minecraft:polished_andesite
fill 284 296 352 284 297 352 minecraft:polished_andesite
fill 284 296 354 284 297 354 minecraft:polished_andesite
fill 284 296 356 284 297 356 minecraft:polished_andesite
fill 285 296 325 285 297 325 minecraft:polished_andesite
fill 285 296 327 285 297 327 minecraft:polished_andesite
fill 285 296 329 285 297 329 minecraft:polished_andesite
fill 285 296 331 285 297 331 minecraft:polished_andesite
fill 285 296 333 285 297 333 minecraft:polished_andesite
fill 285 296 335 285 297 335 minecraft:polished_andesite
fill 285 296 337 285 297 337 minecraft:polished_andesite
fill 285 296 339 285 297 339 minecraft:polished_andesite
fill 285 296 341 285 297 341 minecraft:polished_andesite
fill 285 296 347 285 297 347 minecraft:polished_andesite
fill 285 296 349 285 297 349 minecraft:polished_andesite
fill 285 296 351 285 297 351 minecraft:polished_andesite
fill 285 296 353 285 297 353 minecraft:polished_andesite
fill 285 296 355 285 297 355 minecraft:polished_andesite
fill 285 296 357 285 297 357 minecraft:polished_andesite
fill 286 296 326 286 297 326 minecraft:polished_andesite
fill 286 296 328 286 297 328 minecraft:polished_andesite
fill 286 296 330 286 297 330 minecraft:polished_andesite
fill 286 296 332 286 297 332 minecraft:polished_andesite
fill 286 296 334 286 297 334 minecraft:polished_andesite
fill 286 296 336 286 297 336 minecraft:polished_andesite
fill 286 296 338 286 297 338 minecraft:polished_andesite
fill 286 296 340 286 297 340 minecraft:polished_andesite
fill 286 296 342 286 297 342 minecraft:polished_andesite
fill 286 296 348 286 297 348 minecraft:polished_andesite
fill 286 296 350 286 297 350 minecraft:polished_andesite
fill 286 296 352 286 297 352 minecraft:polished_andesite
fill 286 296 354 286 297 354 minecraft:polished_andesite
fill 286 296 356 286 297 356 minecraft:polished_andesite
fill 287 296 325 287 297 325 minecraft:polished_andesite
fill 287 296 327 287 297 327 minecraft:polished_andesite
fill 287 296 329 287 297 329 minecraft:polished_andesite
fill 287 296 331 287 297 331 minecraft:polished_andesite
fill 287 296 333 287 297 333 minecraft:polished_andesite
fill 287 296 335 287 297 335 minecraft:polished_andesite
fill 287 296 337 287 297 337 minecraft:polished_andesite
fill 287 296 339 287 297 339 minecraft:polished_andesite
fill 287 296 341 287 297 341 minecraft:polished_andesite
fill 287 296 361 293 297 361 minecraft:iron_bars
fill 288 296 326 288 297 326 minecraft:polished_andesite
fill 288 296 328 288 297 328 minecraft:polished_andesite
fill 288 296 330 288 297 330 minecraft:polished_andesite
fill 288 296 332 288 297 332 minecraft:polished_andesite
fill 288 296 334 288 297 334 minecraft:polished_andesite
fill 288 296 336 288 297 336 minecraft:polished_andesite
fill 288 296 338 288 297 338 minecraft:polished_andesite
fill 288 296 340 288 297 340 minecraft:polished_andesite
fill 288 296 342 288 297 342 minecraft:polished_andesite
fill 289 296 325 289 297 325 minecraft:polished_andesite
fill 289 296 327 289 297 327 minecraft:polished_andesite
fill 289 296 329 289 297 329 minecraft:polished_andesite
fill 289 296 331 289 297 331 minecraft:polished_andesite
fill 289 296 333 289 297 333 minecraft:polished_andesite
fill 289 296 335 289 297 335 minecraft:polished_andesite
fill 289 296 337 289 297 337 minecraft:polished_andesite
fill 289 296 339 289 297 339 minecraft:polished_andesite
fill 289 296 341 289 297 341 minecraft:polished_andesite
fill 313 296 341 313 297 341 minecraft:polished_andesite
fill 313 296 343 313 297 343 minecraft:polished_andesite
fill 313 296 345 313 297 345 minecraft:polished_andesite
fill 314 296 340 314 297 340 minecraft:polished_andesite
fill 314 296 342 314 297 342 minecraft:polished_andesite
fill 314 296 344 314 297 344 minecraft:polished_andesite
fill 314 296 346 314 297 346 minecraft:polished_andesite
fill 314 296 352 314 297 352 minecraft:polished_andesite
fill 314 296 354 314 297 354 minecraft:polished_andesite
fill 314 296 356 314 297 356 minecraft:polished_andesite
fill 314 296 358 314 297 358 minecraft:polished_andesite
fill 314 296 360 314 297 360 minecraft:polished_andesite
fill 314 296 362 314 297 362 minecraft:polished_andesite
fill 314 296 364 314 297 364 minecraft:stone_bricks
fill 315 296 341 315 297 341 minecraft:polished_andesite
fill 315 296 343 315 297 343 minecraft:polished_andesite
fill 315 296 345 315 297 345 minecraft:polished_andesite
fill 315 296 353 315 297 353 minecraft:polished_andesite
fill 315 296 355 315 297 355 minecraft:polished_andesite
fill 315 296 357 315 297 357 minecraft:polished_andesite
fill 315 296 359 315 297 359 minecraft:polished_andesite
fill 315 296 361 315 297 361 minecraft:polished_andesite
fill 315 296 363 315 297 363 minecraft:polished_andesite
fill 316 296 340 316 297 340 minecraft:polished_andesite
fill 316 296 342 316 297 342 minecraft:polished_andesite
fill 316 296 344 316 297 344 minecraft:polished_andesite
fill 316 296 346 316 297 346 minecraft:polished_andesite
fill 316 296 352 316 297 352 minecraft:polished_andesite
fill 316 296 354 316 297 354 minecraft:polished_andesite
fill 316 296 356 316 297 356 minecraft:polished_andesite
fill 316 296 358 316 297 358 minecraft:polished_andesite
fill 316 296 360 316 297 360 minecraft:polished_andesite
fill 316 296 362 316 297 362 minecraft:polished_andesite
fill 316 296 364 316 297 364 minecraft:stone_bricks
fill 317 296 341 317 297 341 minecraft:polished_andesite
fill 317 296 343 317 297 343 minecraft:polished_andesite
fill 317 296 345 317 297 345 minecraft:polished_andesite
fill 317 296 353 317 297 353 minecraft:polished_andesite
fill 317 296 355 317 297 355 minecraft:polished_andesite
fill 317 296 357 317 297 357 minecraft:polished_andesite
fill 317 296 359 317 297 359 minecraft:polished_andesite
fill 317 296 361 317 297 361 minecraft:polished_andesite
fill 317 296 363 317 297 363 minecraft:polished_andesite
fill 318 296 340 318 297 340 minecraft:polished_andesite
fill 318 296 342 318 297 342 minecraft:polished_andesite
fill 318 296 344 318 297 344 minecraft:polished_andesite
fill 318 296 346 318 297 346 minecraft:polished_andesite
fill 318 296 352 318 297 352 minecraft:polished_andesite
fill 318 296 354 318 297 354 minecraft:polished_andesite
fill 318 296 356 318 297 356 minecraft:polished_andesite
fill 318 296 358 318 297 358 minecraft:polished_andesite
fill 318 296 360 318 297 360 minecraft:polished_andesite
fill 318 296 362 318 297 362 minecraft:polished_andesite
fill 318 296 364 318 297 364 minecraft:stone_bricks
fill 319 296 341 319 297 341 minecraft:polished_andesite
fill 319 296 343 319 297 343 minecraft:polished_andesite
fill 319 296 345 319 297 345 minecraft:polished_andesite
fill 319 296 353 319 297 353 minecraft:polished_andesite
fill 319 296 355 319 297 355 minecraft:polished_andesite
fill 319 296 357 319 297 357 minecraft:polished_andesite
fill 319 296 359 319 297 359 minecraft:polished_andesite
fill 319 296 361 319 297 361 minecraft:polished_andesite
fill 319 296 363 319 297 363 minecraft:polished_andesite
fill 320 296 340 320 297 340 minecraft:polished_andesite
fill 320 296 342 320 297 342 minecraft:polished_andesite
fill 320 296 344 320 297 344 minecraft:polished_andesite
fill 320 296 346 320 297 346 minecraft:polished_andesite
fill 320 296 352 320 297 352 minecraft:polished_andesite
fill 320 296 354 320 297 354 minecraft:polished_andesite
fill 320 296 356 320 297 356 minecraft:polished_andesite
fill 320 296 358 320 297 358 minecraft:polished_andesite
fill 320 296 360 320 297 360 minecraft:polished_andesite
fill 320 296 362 320 297 362 minecraft:polished_andesite
fill 320 296 364 320 297 364 minecraft:stone_bricks
fill 321 296 341 321 297 341 minecraft:polished_andesite
fill 321 296 343 321 297 343 minecraft:polished_andesite
fill 321 296 345 321 297 345 minecraft:polished_andesite
fill 321 296 353 321 297 353 minecraft:polished_andesite
fill 321 296 355 321 297 355 minecraft:polished_andesite
fill 321 296 357 321 297 357 minecraft:polished_andesite
fill 321 296 359 321 297 359 minecraft:polished_andesite
fill 321 296 361 321 297 361 minecraft:polished_andesite
fill 321 296 363 321 297 363 minecraft:polished_andesite
fill 322 296 340 322 297 340 minecraft:polished_andesite
fill 322 296 342 322 297 342 minecraft:polished_andesite
fill 322 296 344 322 297 344 minecraft:polished_andesite
fill 322 296 346 322 297 346 minecraft:polished_andesite
fill 322 296 352 322 297 352 minecraft:polished_andesite
fill 322 296 354 322 297 354 minecraft:polished_andesite
fill 322 296 356 322 297 356 minecraft:polished_andesite
fill 322 296 358 322 297 358 minecraft:polished_andesite
fill 322 296 360 322 297 360 minecraft:polished_andesite
fill 322 296 362 322 297 362 minecraft:polished_andesite
fill 322 296 364 322 297 364 minecraft:stone_bricks
fill 323 296 341 323 297 341 minecraft:polished_andesite
fill 323 296 343 323 297 343 minecraft:polished_andesite
fill 323 296 345 323 297 345 minecraft:polished_andesite
fill 323 296 353 323 297 353 minecraft:polished_andesite
fill 323 296 355 323 297 355 minecraft:polished_andesite
fill 323 296 357 323 297 357 minecraft:polished_andesite
fill 323 296 359 323 297 359 minecraft:polished_andesite
fill 323 296 361 323 297 361 minecraft:polished_andesite
fill 323 296 363 323 297 363 minecraft:polished_andesite
setblock 285 297 346 minecraft:light[level=12]
setblock 285 297 360 minecraft:light[level=12]
setblock 292 297 325 minecraft:light[level=12]
setblock 292 297 332 minecraft:light[level=12]
setblock 292 297 339 minecraft:light[level=12]
setblock 292 297 346 minecraft:light[level=12]
setblock 292 297 353 minecraft:light[level=12]
setblock 292 297 360 minecraft:light[level=12]
setblock 299 297 325 minecraft:light[level=12]
setblock 299 297 332 minecraft:light[level=12]
setblock 299 297 339 minecraft:light[level=12]
setblock 299 297 346 minecraft:light[level=12]
setblock 299 297 353 minecraft:light[level=12]
setblock 299 297 360 minecraft:light[level=12]
setblock 306 297 325 minecraft:light[level=12]
setblock 306 297 332 minecraft:light[level=12]
setblock 306 297 339 minecraft:light[level=12]
setblock 306 297 346 minecraft:light[level=12]
setblock 306 297 353 minecraft:light[level=12]
setblock 306 297 360 minecraft:light[level=12]
setblock 313 297 325 minecraft:light[level=12]
setblock 313 297 332 minecraft:light[level=12]
setblock 313 297 339 minecraft:light[level=12]
setblock 313 297 360 minecraft:light[level=12]
setblock 320 297 325 minecraft:light[level=12]
setblock 320 297 332 minecraft:light[level=12]
setblock 320 297 339 minecraft:light[level=12]
setblock 283 298 325 minecraft:shroomlight
setblock 283 298 327 minecraft:shroomlight
setblock 283 298 329 minecraft:shroomlight
setblock 283 298 331 minecraft:shroomlight
setblock 283 298 333 minecraft:shroomlight
setblock 283 298 335 minecraft:shroomlight
setblock 283 298 337 minecraft:shroomlight
setblock 283 298 339 minecraft:shroomlight
setblock 283 298 341 minecraft:shroomlight
setblock 283 298 347 minecraft:shroomlight
setblock 283 298 349 minecraft:shroomlight
setblock 283 298 351 minecraft:shroomlight
setblock 283 298 353 minecraft:shroomlight
setblock 283 298 355 minecraft:shroomlight
setblock 283 298 357 minecraft:shroomlight
setblock 284 298 326 minecraft:shroomlight
setblock 284 298 328 minecraft:shroomlight
setblock 284 298 330 minecraft:shroomlight
setblock 284 298 332 minecraft:shroomlight
setblock 284 298 334 minecraft:shroomlight
setblock 284 298 336 minecraft:shroomlight
setblock 284 298 338 minecraft:shroomlight
setblock 284 298 340 minecraft:shroomlight
setblock 284 298 342 minecraft:shroomlight
setblock 284 298 348 minecraft:shroomlight
setblock 284 298 350 minecraft:shroomlight
setblock 284 298 352 minecraft:shroomlight
setblock 284 298 354 minecraft:shroomlight
setblock 284 298 356 minecraft:shroomlight
setblock 285 298 325 minecraft:shroomlight
setblock 285 298 327 minecraft:shroomlight
setblock 285 298 329 minecraft:shroomlight
setblock 285 298 331 minecraft:shroomlight
setblock 285 298 333 minecraft:shroomlight
setblock 285 298 335 minecraft:shroomlight
setblock 285 298 337 minecraft:shroomlight
setblock 285 298 339 minecraft:shroomlight
setblock 285 298 341 minecraft:shroomlight
setblock 285 298 347 minecraft:shroomlight
setblock 285 298 349 minecraft:shroomlight
setblock 285 298 351 minecraft:shroomlight
setblock 285 298 353 minecraft:shroomlight
setblock 285 298 355 minecraft:shroomlight
setblock 285 298 357 minecraft:shroomlight
setblock 286 298 326 minecraft:shroomlight
setblock 286 298 328 minecraft:shroomlight
setblock 286 298 330 minecraft:shroomlight
setblock 286 298 332 minecraft:shroomlight
setblock 286 298 334 minecraft:shroomlight
setblock 286 298 336 minecraft:shroomlight
setblock 286 298 338 minecraft:shroomlight
setblock 286 298 340 minecraft:shroomlight
setblock 286 298 342 minecraft:shroomlight
setblock 286 298 348 minecraft:shroomlight
setblock 286 298 350 minecraft:shroomlight
setblock 286 298 352 minecraft:shroomlight
setblock 286 298 354 minecraft:shroomlight
setblock 286 298 356 minecraft:shroomlight
setblock 287 298 325 minecraft:shroomlight
setblock 287 298 327 minecraft:shroomlight
setblock 287 298 329 minecraft:shroomlight
setblock 287 298 331 minecraft:shroomlight
setblock 287 298 333 minecraft:shroomlight
setblock 287 298 335 minecraft:shroomlight
setblock 287 298 337 minecraft:shroomlight
setblock 287 298 339 minecraft:shroomlight
setblock 287 298 341 minecraft:shroomlight
setblock 288 298 326 minecraft:shroomlight
setblock 288 298 328 minecraft:shroomlight
setblock 288 298 330 minecraft:shroomlight
setblock 288 298 332 minecraft:shroomlight
setblock 288 298 334 minecraft:shroomlight
setblock 288 298 336 minecraft:shroomlight
setblock 288 298 338 minecraft:shroomlight
setblock 288 298 340 minecraft:shroomlight
setblock 288 298 342 minecraft:shroomlight
setblock 289 298 325 minecraft:shroomlight
setblock 289 298 327 minecraft:shroomlight
setblock 289 298 329 minecraft:shroomlight
setblock 289 298 331 minecraft:shroomlight
setblock 289 298 333 minecraft:shroomlight
setblock 289 298 335 minecraft:shroomlight
setblock 289 298 337 minecraft:shroomlight
setblock 289 298 339 minecraft:shroomlight
setblock 289 298 341 minecraft:shroomlight
setblock 313 298 341 minecraft:shroomlight
setblock 313 298 343 minecraft:shroomlight
setblock 313 298 345 minecraft:shroomlight
setblock 314 298 340 minecraft:shroomlight
setblock 314 298 342 minecraft:shroomlight
setblock 314 298 344 minecraft:shroomlight
setblock 314 298 346 minecraft:shroomlight
setblock 314 298 352 minecraft:shroomlight
setblock 314 298 354 minecraft:shroomlight
setblock 314 298 356 minecraft:shroomlight
setblock 314 298 358 minecraft:shroomlight
setblock 314 298 360 minecraft:shroomlight
setblock 314 298 362 minecraft:shroomlight
setblock 314 298 364 minecraft:shroomlight
setblock 315 298 341 minecraft:shroomlight
setblock 315 298 343 minecraft:shroomlight
setblock 315 298 345 minecraft:shroomlight
setblock 315 298 353 minecraft:shroomlight
setblock 315 298 355 minecraft:shroomlight
setblock 315 298 357 minecraft:shroomlight
setblock 315 298 359 minecraft:shroomlight
setblock 315 298 361 minecraft:shroomlight
setblock 315 298 363 minecraft:shroomlight
setblock 316 298 340 minecraft:shroomlight
setblock 316 298 342 minecraft:shroomlight
setblock 316 298 344 minecraft:shroomlight
setblock 316 298 346 minecraft:shroomlight
setblock 316 298 352 minecraft:shroomlight
setblock 316 298 354 minecraft:shroomlight
setblock 316 298 356 minecraft:shroomlight
setblock 316 298 358 minecraft:shroomlight
setblock 316 298 360 minecraft:shroomlight
setblock 316 298 362 minecraft:shroomlight
setblock 316 298 364 minecraft:shroomlight
setblock 317 298 341 minecraft:shroomlight
setblock 317 298 343 minecraft:shroomlight
setblock 317 298 345 minecraft:shroomlight
setblock 317 298 353 minecraft:shroomlight
setblock 317 298 355 minecraft:shroomlight
setblock 317 298 357 minecraft:shroomlight
setblock 317 298 359 minecraft:shroomlight
setblock 317 298 361 minecraft:shroomlight
setblock 317 298 363 minecraft:shroomlight
setblock 318 298 340 minecraft:shroomlight
setblock 318 298 342 minecraft:shroomlight
setblock 318 298 344 minecraft:shroomlight
setblock 318 298 346 minecraft:shroomlight
setblock 318 298 352 minecraft:shroomlight
setblock 318 298 354 minecraft:shroomlight
setblock 318 298 356 minecraft:shroomlight
setblock 318 298 358 minecraft:shroomlight
setblock 318 298 360 minecraft:shroomlight
setblock 318 298 362 minecraft:shroomlight
setblock 318 298 364 minecraft:shroomlight
setblock 319 298 341 minecraft:shroomlight
setblock 319 298 343 minecraft:shroomlight
setblock 319 298 345 minecraft:shroomlight
setblock 319 298 353 minecraft:shroomlight
setblock 319 298 355 minecraft:shroomlight
setblock 319 298 357 minecraft:shroomlight
setblock 319 298 359 minecraft:shroomlight
setblock 319 298 361 minecraft:shroomlight
setblock 319 298 363 minecraft:shroomlight
setblock 320 298 340 minecraft:shroomlight
setblock 320 298 342 minecraft:shroomlight
setblock 320 298 344 minecraft:shroomlight
setblock 320 298 346 minecraft:shroomlight
setblock 320 298 352 minecraft:shroomlight
setblock 320 298 354 minecraft:shroomlight
setblock 320 298 356 minecraft:shroomlight
setblock 320 298 358 minecraft:shroomlight
setblock 320 298 360 minecraft:shroomlight
setblock 320 298 362 minecraft:shroomlight
setblock 320 298 364 minecraft:shroomlight
setblock 321 298 341 minecraft:shroomlight
setblock 321 298 343 minecraft:shroomlight
setblock 321 298 345 minecraft:shroomlight
setblock 321 298 353 minecraft:shroomlight
setblock 321 298 355 minecraft:shroomlight
setblock 321 298 357 minecraft:shroomlight
setblock 321 298 359 minecraft:shroomlight
setblock 321 298 361 minecraft:shroomlight
setblock 321 298 363 minecraft:shroomlight
setblock 322 298 340 minecraft:shroomlight
setblock 322 298 342 minecraft:shroomlight
setblock 322 298 344 minecraft:shroomlight
setblock 322 298 346 minecraft:shroomlight
setblock 322 298 352 minecraft:shroomlight
setblock 322 298 354 minecraft:shroomlight
setblock 322 298 356 minecraft:shroomlight
setblock 322 298 358 minecraft:shroomlight
setblock 322 298 360 minecraft:shroomlight
setblock 322 298 362 minecraft:shroomlight
setblock 322 298 364 minecraft:shroomlight
setblock 323 298 341 minecraft:shroomlight
setblock 323 298 343 minecraft:shroomlight
setblock 323 298 345 minecraft:shroomlight
setblock 323 298 353 minecraft:shroomlight
setblock 323 298 355 minecraft:shroomlight
setblock 323 298 357 minecraft:shroomlight
setblock 323 298 359 minecraft:shroomlight
setblock 323 298 361 minecraft:shroomlight
setblock 323 298 363 minecraft:shroomlight
fill 283 299 325 283 300 325 minecraft:polished_andesite
fill 283 299 327 283 300 327 minecraft:polished_andesite
fill 283 299 329 283 300 329 minecraft:polished_andesite
fill 283 299 331 283 300 331 minecraft:polished_andesite
fill 283 299 333 283 300 333 minecraft:polished_andesite
fill 283 299 335 283 300 335 minecraft:polished_andesite
fill 283 299 337 283 300 337 minecraft:polished_andesite
fill 283 299 339 283 300 339 minecraft:polished_andesite
fill 283 299 341 283 300 341 minecraft:polished_andesite
fill 283 299 347 283 300 347 minecraft:polished_andesite
fill 283 299 349 283 300 349 minecraft:polished_andesite
fill 283 299 351 283 300 351 minecraft:polished_andesite
fill 283 299 353 283 300 353 minecraft:polished_andesite
fill 283 299 355 283 300 355 minecraft:polished_andesite
fill 283 299 357 283 300 357 minecraft:polished_andesite
fill 284 299 326 284 300 326 minecraft:polished_andesite
fill 284 299 328 284 300 328 minecraft:polished_andesite
fill 284 299 330 284 300 330 minecraft:polished_andesite
fill 284 299 332 284 300 332 minecraft:polished_andesite
fill 284 299 334 284 300 334 minecraft:polished_andesite
fill 284 299 336 284 300 336 minecraft:polished_andesite
fill 284 299 338 284 300 338 minecraft:polished_andesite
fill 284 299 340 284 300 340 minecraft:polished_andesite
fill 284 299 342 284 300 342 minecraft:polished_andesite
fill 284 299 348 284 300 348 minecraft:polished_andesite
fill 284 299 350 284 300 350 minecraft:polished_andesite
fill 284 299 352 284 300 352 minecraft:polished_andesite
fill 284 299 354 284 300 354 minecraft:polished_andesite
fill 284 299 356 284 300 356 minecraft:polished_andesite
fill 285 299 325 285 300 325 minecraft:polished_andesite
fill 285 299 327 285 300 327 minecraft:polished_andesite
fill 285 299 329 285 300 329 minecraft:polished_andesite
fill 285 299 331 285 300 331 minecraft:polished_andesite
fill 285 299 333 285 300 333 minecraft:polished_andesite
fill 285 299 335 285 300 335 minecraft:polished_andesite
fill 285 299 337 285 300 337 minecraft:polished_andesite
fill 285 299 339 285 300 339 minecraft:polished_andesite
fill 285 299 341 285 300 341 minecraft:polished_andesite
fill 285 299 347 285 300 347 minecraft:polished_andesite
fill 285 299 349 285 300 349 minecraft:polished_andesite
fill 285 299 351 285 300 351 minecraft:polished_andesite
fill 285 299 353 285 300 353 minecraft:polished_andesite
fill 285 299 355 285 300 355 minecraft:polished_andesite
fill 285 299 357 285 300 357 minecraft:polished_andesite
fill 286 299 326 286 300 326 minecraft:polished_andesite
fill 286 299 328 286 300 328 minecraft:polished_andesite
fill 286 299 330 286 300 330 minecraft:polished_andesite
fill 286 299 332 286 300 332 minecraft:polished_andesite
fill 286 299 334 286 300 334 minecraft:polished_andesite
fill 286 299 336 286 300 336 minecraft:polished_andesite
fill 286 299 338 286 300 338 minecraft:polished_andesite
fill 286 299 340 286 300 340 minecraft:polished_andesite
fill 286 299 342 286 300 342 minecraft:polished_andesite
fill 286 299 348 286 300 348 minecraft:polished_andesite
fill 286 299 350 286 300 350 minecraft:polished_andesite
fill 286 299 352 286 300 352 minecraft:polished_andesite
fill 286 299 354 286 300 354 minecraft:polished_andesite
fill 286 299 356 286 300 356 minecraft:polished_andesite
fill 287 299 325 287 300 325 minecraft:polished_andesite
fill 287 299 327 287 300 327 minecraft:polished_andesite
fill 287 299 329 287 300 329 minecraft:polished_andesite
fill 287 299 331 287 300 331 minecraft:polished_andesite
fill 287 299 333 287 300 333 minecraft:polished_andesite
fill 287 299 335 287 300 335 minecraft:polished_andesite
fill 287 299 337 287 300 337 minecraft:polished_andesite
fill 287 299 339 287 300 339 minecraft:polished_andesite
fill 287 299 341 287 300 341 minecraft:polished_andesite
fill 288 299 326 288 300 326 minecraft:polished_andesite
fill 288 299 328 288 300 328 minecraft:polished_andesite
fill 288 299 330 288 300 330 minecraft:polished_andesite
fill 288 299 332 288 300 332 minecraft:polished_andesite
fill 288 299 334 288 300 334 minecraft:polished_andesite
fill 288 299 336 288 300 336 minecraft:polished_andesite
fill 288 299 338 288 300 338 minecraft:polished_andesite
fill 288 299 340 288 300 340 minecraft:polished_andesite
fill 288 299 342 288 300 342 minecraft:polished_andesite
fill 289 299 325 289 300 325 minecraft:polished_andesite
fill 289 299 327 289 300 327 minecraft:polished_andesite
fill 289 299 329 289 300 329 minecraft:polished_andesite
fill 289 299 331 289 300 331 minecraft:polished_andesite
fill 289 299 333 289 300 333 minecraft:polished_andesite
fill 289 299 335 289 300 335 minecraft:polished_andesite
fill 289 299 337 289 300 337 minecraft:polished_andesite
fill 289 299 339 289 300 339 minecraft:polished_andesite
fill 289 299 341 289 300 341 minecraft:polished_andesite
fill 313 299 341 313 300 341 minecraft:polished_andesite
fill 313 299 343 313 300 343 minecraft:polished_andesite
fill 313 299 345 313 300 345 minecraft:polished_andesite
fill 314 299 340 314 300 340 minecraft:polished_andesite
fill 314 299 342 314 300 342 minecraft:polished_andesite
fill 314 299 344 314 300 344 minecraft:polished_andesite
fill 314 299 346 314 300 346 minecraft:polished_andesite
fill 314 299 352 314 300 352 minecraft:polished_andesite
fill 314 299 354 314 300 354 minecraft:polished_andesite
fill 314 299 356 314 300 356 minecraft:polished_andesite
fill 314 299 358 314 300 358 minecraft:polished_andesite
fill 314 299 360 314 300 360 minecraft:polished_andesite
fill 314 299 362 314 300 362 minecraft:polished_andesite
fill 314 299 364 314 308 364 minecraft:stone_bricks
fill 315 299 341 315 300 341 minecraft:polished_andesite
fill 315 299 343 315 300 343 minecraft:polished_andesite
fill 315 299 345 315 300 345 minecraft:polished_andesite
fill 315 299 353 315 300 353 minecraft:polished_andesite
fill 315 299 355 315 300 355 minecraft:polished_andesite
fill 315 299 357 315 300 357 minecraft:polished_andesite
fill 315 299 359 315 300 359 minecraft:polished_andesite
fill 315 299 361 315 300 361 minecraft:polished_andesite
fill 315 299 363 315 300 363 minecraft:polished_andesite
fill 316 299 340 316 300 340 minecraft:polished_andesite
fill 316 299 342 316 300 342 minecraft:polished_andesite
fill 316 299 344 316 300 344 minecraft:polished_andesite
fill 316 299 346 316 300 346 minecraft:polished_andesite
fill 316 299 352 316 300 352 minecraft:polished_andesite
fill 316 299 354 316 300 354 minecraft:polished_andesite
fill 316 299 356 316 300 356 minecraft:polished_andesite
fill 316 299 358 316 300 358 minecraft:polished_andesite
fill 316 299 360 316 300 360 minecraft:polished_andesite
fill 316 299 362 316 300 362 minecraft:polished_andesite
fill 316 299 364 316 308 364 minecraft:stone_bricks
fill 317 299 341 317 300 341 minecraft:polished_andesite
fill 317 299 343 317 300 343 minecraft:polished_andesite
fill 317 299 345 317 300 345 minecraft:polished_andesite
fill 317 299 353 317 300 353 minecraft:polished_andesite
fill 317 299 355 317 300 355 minecraft:polished_andesite
fill 317 299 357 317 300 357 minecraft:polished_andesite
fill 317 299 359 317 300 359 minecraft:polished_andesite
fill 317 299 361 317 300 361 minecraft:polished_andesite
fill 317 299 363 317 300 363 minecraft:polished_andesite
fill 318 299 340 318 300 340 minecraft:polished_andesite
fill 318 299 342 318 300 342 minecraft:polished_andesite
fill 318 299 344 318 300 344 minecraft:polished_andesite
fill 318 299 346 318 300 346 minecraft:polished_andesite
fill 318 299 352 318 300 352 minecraft:polished_andesite
fill 318 299 354 318 300 354 minecraft:polished_andesite
fill 318 299 356 318 300 356 minecraft:polished_andesite
fill 318 299 358 318 300 358 minecraft:polished_andesite
fill 318 299 360 318 300 360 minecraft:polished_andesite
fill 318 299 362 318 300 362 minecraft:polished_andesite
fill 318 299 364 318 308 364 minecraft:stone_bricks
fill 319 299 324 319 299 325 minecraft:iron_bars
fill 319 299 341 319 300 341 minecraft:polished_andesite
fill 319 299 343 319 300 343 minecraft:polished_andesite
fill 319 299 345 319 300 345 minecraft:polished_andesite
fill 319 299 353 319 300 353 minecraft:polished_andesite
fill 319 299 355 319 300 355 minecraft:polished_andesite
fill 319 299 357 319 300 357 minecraft:polished_andesite
fill 319 299 359 319 300 359 minecraft:polished_andesite
fill 319 299 361 319 300 361 minecraft:polished_andesite
fill 319 299 363 319 300 363 minecraft:polished_andesite
fill 320 299 340 320 300 340 minecraft:polished_andesite
fill 320 299 342 320 300 342 minecraft:polished_andesite
fill 320 299 344 320 300 344 minecraft:polished_andesite
fill 320 299 346 320 300 346 minecraft:polished_andesite
fill 320 299 352 320 300 352 minecraft:polished_andesite
fill 320 299 354 320 300 354 minecraft:polished_andesite
fill 320 299 356 320 300 356 minecraft:polished_andesite
fill 320 299 358 320 300 358 minecraft:polished_andesite
fill 320 299 360 320 300 360 minecraft:polished_andesite
fill 320 299 362 320 300 362 minecraft:polished_andesite
fill 320 299 364 320 308 364 minecraft:stone_bricks
fill 321 299 341 321 300 341 minecraft:polished_andesite
fill 321 299 343 321 300 343 minecraft:polished_andesite
fill 321 299 345 321 300 345 minecraft:polished_andesite
fill 321 299 353 321 300 353 minecraft:polished_andesite
fill 321 299 355 321 300 355 minecraft:polished_andesite
fill 321 299 357 321 300 357 minecraft:polished_andesite
fill 321 299 359 321 300 359 minecraft:polished_andesite
fill 321 299 361 321 300 361 minecraft:polished_andesite
fill 321 299 363 321 300 363 minecraft:polished_andesite
fill 322 299 340 322 300 340 minecraft:polished_andesite
fill 322 299 342 322 300 342 minecraft:polished_andesite
fill 322 299 344 322 300 344 minecraft:polished_andesite
fill 322 299 346 322 300 346 minecraft:polished_andesite
fill 322 299 352 322 300 352 minecraft:polished_andesite
fill 322 299 354 322 300 354 minecraft:polished_andesite
fill 322 299 356 322 300 356 minecraft:polished_andesite
fill 322 299 358 322 300 358 minecraft:polished_andesite
fill 322 299 360 322 300 360 minecraft:polished_andesite
fill 322 299 362 322 300 362 minecraft:polished_andesite
fill 322 299 364 322 308 364 minecraft:stone_bricks
fill 323 299 341 323 300 341 minecraft:polished_andesite
fill 323 299 343 323 300 343 minecraft:polished_andesite
fill 323 299 345 323 300 345 minecraft:polished_andesite
fill 323 299 353 323 300 353 minecraft:polished_andesite
fill 323 299 355 323 300 355 minecraft:polished_andesite
fill 323 299 357 323 300 357 minecraft:polished_andesite
fill 323 299 359 323 300 359 minecraft:polished_andesite
fill 323 299 361 323 300 361 minecraft:polished_andesite
fill 323 299 363 323 300 363 minecraft:polished_andesite
fill 284 300 344 284 300 346 minecraft:polished_andesite
setblock 284 300 358 minecraft:polished_andesite
fill 290 300 362 292 300 362 minecraft:polished_andesite
fill 294 300 324 296 300 324 minecraft:polished_andesite
fill 302 300 362 304 300 362 minecraft:polished_andesite
fill 306 300 324 308 300 324 minecraft:polished_andesite
fill 318 300 324 320 300 324 minecraft:polished_andesite
setblock 319 300 325 minecraft:iron_bars
fill 322 300 332 322 300 334 minecraft:polished_andesite
setblock 285 303 325 minecraft:light[level=15]
setblock 285 303 332 minecraft:light[level=12]
setblock 285 303 333 minecraft:light[level=15]
setblock 285 303 339 minecraft:light[level=12]
setblock 285 303 341 minecraft:light[level=15]
setblock 285 303 346 minecraft:light[level=12]
setblock 285 303 349 minecraft:light[level=15]
setblock 285 303 353 minecraft:light[level=12]
setblock 285 303 357 minecraft:light[level=15]
setblock 285 303 360 minecraft:light[level=12]
setblock 292 303 325 minecraft:light[level=12]
setblock 292 303 332 minecraft:light[level=12]
setblock 292 303 339 minecraft:light[level=12]
setblock 292 303 346 minecraft:light[level=12]
setblock 292 303 353 minecraft:light[level=12]
setblock 292 303 360 minecraft:light[level=12]
setblock 293 303 325 minecraft:light[level=15]
setblock 293 303 333 minecraft:light[level=15]
setblock 293 303 341 minecraft:light[level=15]
setblock 293 303 349 minecraft:light[level=15]
setblock 293 303 357 minecraft:light[level=15]
setblock 299 303 325 minecraft:light[level=12]
setblock 299 303 332 minecraft:light[level=12]
setblock 299 303 339 minecraft:light[level=12]
setblock 299 303 346 minecraft:light[level=12]
setblock 299 303 353 minecraft:light[level=12]
setblock 299 303 360 minecraft:light[level=12]
setblock 301 303 325 minecraft:light[level=15]
setblock 301 303 333 minecraft:light[level=15]
setblock 301 303 341 minecraft:light[level=15]
setblock 301 303 349 minecraft:light[level=15]
setblock 301 303 357 minecraft:light[level=15]
setblock 306 303 325 minecraft:light[level=12]
setblock 306 303 332 minecraft:light[level=12]
setblock 306 303 339 minecraft:light[level=12]
setblock 306 303 346 minecraft:light[level=12]
setblock 306 303 353 minecraft:light[level=12]
setblock 306 303 360 minecraft:light[level=12]
setblock 309 303 325 minecraft:light[level=15]
setblock 309 303 333 minecraft:light[level=15]
setblock 309 303 341 minecraft:light[level=15]
setblock 309 303 349 minecraft:light[level=15]
setblock 309 303 357 minecraft:light[level=15]
setblock 313 303 325 minecraft:light[level=12]
setblock 313 303 332 minecraft:light[level=12]
setblock 313 303 339 minecraft:light[level=12]
setblock 313 303 346 minecraft:light[level=12]
setblock 313 303 353 minecraft:light[level=12]
setblock 313 303 360 minecraft:light[level=12]
setblock 317 303 325 minecraft:light[level=15]
setblock 317 303 333 minecraft:light[level=15]
setblock 317 303 341 minecraft:light[level=15]
setblock 317 303 349 minecraft:light[level=15]
setblock 317 303 357 minecraft:light[level=15]
setblock 320 303 325 minecraft:light[level=12]
setblock 320 303 332 minecraft:light[level=12]
setblock 320 303 339 minecraft:light[level=12]
setblock 320 303 346 minecraft:light[level=12]
setblock 320 303 353 minecraft:light[level=12]
setblock 320 303 360 minecraft:light[level=12]
