setblock 418 288 599 minecraft:purple_concrete
setblock 376 289 557 minecraft:purple_concrete
fill 376 289 558 376 292 558 minecraft:black_concrete
setblock 376 289 574 minecraft:purple_concrete
setblock 376 289 577 minecraft:purple_concrete
fill 376 289 578 376 292 578 minecraft:black_concrete
setblock 376 289 585 minecraft:purple_concrete
fill 376 289 589 376 292 589 minecraft:black_concrete
fill 379 289 557 380 291 557 minecraft:black_concrete
fill 382 289 599 383 289 599 minecraft:purple_concrete
setblock 384 289 557 minecraft:purple_concrete
setblock 386 289 599 minecraft:purple_concrete
fill 387 289 599 387 292 599 minecraft:black_concrete
setblock 395 289 557 minecraft:purple_concrete
fill 398 289 599 398 292 599 minecraft:black_concrete
fill 400 289 557 400 292 557 minecraft:black_concrete
setblock 403 289 599 minecraft:purple_concrete
fill 411 289 557 411 292 557 minecraft:black_concrete
setblock 412 289 557 minecraft:purple_concrete
setblock 414 289 599 minecraft:purple_concrete
fill 415 289 557 416 289 557 minecraft:purple_concrete
fill 418 289 571 418 292 571 minecraft:black_concrete
setblock 418 289 575 minecraft:purple_concrete
fill 418 289 582 418 292 582 minecraft:black_concrete
setblock 418 289 583 minecraft:purple_concrete
setblock 418 289 586 minecraft:purple_concrete
fill 418 289 599 418 292 599 minecraft:black_concrete
fill 376 290 557 376 292 557 minecraft:black_concrete
fill 376 290 563 376 291 564 minecraft:purple_concrete
fill 376 290 565 376 295 566 minecraft:black_concrete
fill 376 290 572 376 291 572 minecraft:purple_concrete
fill 376 290 573 376 291 574 minecraft:black_concrete
fill 376 290 575 376 290 576 minecraft:purple_concrete
fill 376 290 577 376 295 577 minecraft:black_concrete
fill 376 290 583 376 291 584 minecraft:purple_concrete
fill 376 290 585 376 295 586 minecraft:black_concrete
fill 376 290 595 376 290 596 minecraft:purple_concrete
fill 376 290 597 376 295 598 minecraft:black_concrete
fill 381 290 557 381 293 557 minecraft:black_concrete
fill 381 290 599 381 291 599 minecraft:purple_concrete
setblock 382 290 557 minecraft:purple_concrete
fill 382 290 599 383 295 599 minecraft:black_concrete
fill 383 290 557 384 295 557 minecraft:black_concrete
setblock 384 290 599 minecraft:purple_concrete
fill 385 290 557 386 291 557 minecraft:purple_concrete
fill 386 290 599 386 295 599 minecraft:black_concrete
fill 391 290 557 392 292 557 minecraft:black_concrete
fill 392 290 599 393 291 599 minecraft:purple_concrete
fill 393 290 557 394 290 557 minecraft:purple_concrete
fill 394 290 599 395 295 599 minecraft:black_concrete
fill 395 290 557 395 295 557 minecraft:black_concrete
fill 403 290 557 404 295 557 minecraft:black_concrete
fill 403 290 599 403 295 599 minecraft:black_concrete
fill 404 290 599 405 290 599 minecraft:purple_concrete
fill 405 290 557 406 291 557 minecraft:purple_concrete
fill 406 290 599 407 295 599 minecraft:black_concrete
fill 412 290 557 412 295 557 minecraft:black_concrete
fill 412 290 599 413 291 599 minecraft:purple_concrete
setblock 414 290 557 minecraft:purple_concrete
fill 414 290 599 415 295 599 minecraft:black_concrete
fill 415 290 557 416 295 557 minecraft:black_concrete
setblock 416 290 599 minecraft:purple_concrete
fill 417 290 557 417 291 557 minecraft:purple_concrete
fill 418 290 562 418 295 563 minecraft:black_concrete
fill 418 290 564 418 290 565 minecraft:purple_concrete
fill 418 290 574 418 295 575 minecraft:black_concrete
fill 418 290 576 418 291 577 minecraft:purple_concrete
fill 418 290 583 418 295 583 minecraft:black_concrete
fill 418 290 584 418 290 585 minecraft:purple_concrete
fill 418 290 586 418 291 587 minecraft:black_concrete
fill 418 290 588 418 291 588 minecraft:purple_concrete
fill 418 290 594 418 295 595 minecraft:black_concrete
fill 418 290 596 418 291 597 minecraft:purple_concrete
fill 376 291 559 376 293 559 minecraft:black_concrete
setblock 376 291 560 minecraft:purple_concrete
setblock 376 291 571 minecraft:purple_concrete
fill 376 291 575 376 294 576 minecraft:black_concrete
setblock 376 291 592 minecraft:purple_concrete
setblock 376 291 595 minecraft:purple_concrete
fill 376 291 596 376 294 596 minecraft:black_concrete
setblock 377 291 557 minecraft:purple_concrete
setblock 380 291 599 minecraft:purple_concrete
fill 382 291 557 382 293 557 minecraft:black_concrete
fill 384 291 599 384 294 599 minecraft:black_concrete
fill 393 291 557 393 294 557 minecraft:black_concrete
setblock 394 291 557 minecraft:purple_concrete
fill 397 291 557 398 291 557 minecraft:purple_concrete
fill 400 291 599 401 291 599 minecraft:purple_concrete
setblock 404 291 599 minecraft:purple_concrete
fill 405 291 599 405 294 599 minecraft:black_concrete
fill 414 291 557 414 294 557 minecraft:black_concrete
fill 416 291 599 416 294 599 minecraft:black_concrete
setblock 418 291 557 minecraft:purple_concrete
fill 418 291 564 418 294 564 minecraft:black_concrete
setblock 418 291 565 minecraft:purple_concrete
setblock 418 291 568 minecraft:purple_concrete
fill 418 291 584 418 294 585 minecraft:black_concrete
setblock 418 291 589 minecraft:purple_concrete
fill 376 292 560 376 297 560 minecraft:black_concrete
fill 376 292 561 376 292 562 minecraft:purple_concrete
fill 376 292 563 376 297 564 minecraft:black_concrete
fill 376 292 569 376 293 570 minecraft:purple_concrete
fill 376 292 571 376 297 572 minecraft:black_concrete
setblock 376 292 573 minecraft:purple_concrete
fill 376 292 574 376 295 574 minecraft:black_concrete
fill 376 292 581 376 293 582 minecraft:purple_concrete
fill 376 292 583 376 297 584 minecraft:black_concrete
fill 376 292 590 376 293 590 minecraft:purple_concrete
fill 376 292 592 376 297 592 minecraft:black_concrete
fill 376 292 593 376 292 594 minecraft:purple_concrete
fill 376 292 595 376 297 595 minecraft:black_concrete
fill 377 292 557 377 297 557 minecraft:black_concrete
fill 378 292 599 379 293 599 minecraft:purple_concrete
fill 379 292 557 379 293 557 minecraft:purple_concrete
setblock 379 292 560 minecraft:light[level=12]
setblock 379 292 568 minecraft:light[level=12]
setblock 379 292 576 minecraft:light[level=12]
setblock 379 292 584 minecraft:light[level=12]
setblock 379 292 592 minecraft:light[level=12]
setblock 380 292 557 minecraft:black_concrete
fill 380 292 599 381 297 599 minecraft:black_concrete
fill 385 292 557 386 297 557 minecraft:black_concrete
fill 387 292 557 388 293 557 minecraft:purple_concrete
setblock 387 292 560 minecraft:light[level=12]
setblock 387 292 568 minecraft:light[level=12]
setblock 387 292 576 minecraft:light[level=12]
setblock 387 292 584 minecraft:light[level=12]
setblock 387 292 592 minecraft:light[level=12]
fill 390 292 599 391 292 599 minecraft:purple_concrete
fill 392 292 599 393 297 599 minecraft:black_concrete
fill 394 292 557 394 294 557 minecraft:black_concrete
setblock 395 292 560 minecraft:light[level=12]
setblock 395 292 568 minecraft:light[level=12]
setblock 395 292 584 minecraft:light[level=12]
setblock 395 292 592 minecraft:light[level=12]
setblock 396 292 557 minecraft:purple_concrete
fill 397 292 557 398 297 557 minecraft:black_concrete
fill 399 292 557 399 293 557 minecraft:purple_concrete
fill 399 292 599 399 293 599 minecraft:purple_concrete
fill 400 292 599 401 297 599 minecraft:black_concrete
setblock 402 292 599 minecraft:purple_concrete
setblock 403 292 560 minecraft:light[level=12]
setblock 403 292 568 minecraft:light[level=12]
setblock 403 292 576 minecraft:light[level=12]
setblock 403 292 584 minecraft:light[level=12]
setblock 403 292 592 minecraft:light[level=12]
fill 404 292 599 404 297 599 minecraft:black_concrete
fill 405 292 557 406 297 557 minecraft:black_concrete
fill 407 292 557 408 292 557 minecraft:purple_concrete
fill 410 292 599 411 293 599 minecraft:purple_concrete
setblock 411 292 560 minecraft:light[level=12]
setblock 411 292 568 minecraft:light[level=12]
setblock 411 292 576 minecraft:light[level=12]
setblock 411 292 584 minecraft:light[level=12]
setblock 411 292 592 minecraft:light[level=12]
fill 412 292 599 413 297 599 minecraft:black_concrete
fill 417 292 557 418 297 557 minecraft:black_concrete
fill 418 292 558 418 293 559 minecraft:purple_concrete
fill 418 292 565 418 297 565 minecraft:black_concrete
fill 418 292 566 418 292 567 minecraft:purple_concrete
fill 418 292 568 418 297 568 minecraft:black_concrete
fill 418 292 570 418 293 570 minecraft:purple_concrete
fill 418 292 576 418 297 577 minecraft:black_concrete
fill 418 292 578 418 293 579 minecraft:purple_concrete
fill 418 292 586 418 295 586 minecraft:black_concrete
setblock 418 292 587 minecraft:purple_concrete
fill 418 292 588 418 297 589 minecraft:black_concrete
fill 418 292 590 418 293 591 minecraft:purple_concrete
fill 418 292 596 418 297 597 minecraft:black_concrete
setblock 418 292 598 minecraft:purple_concrete
fill 376 293 557 376 293 558 minecraft:purple_concrete
setblock 376 293 561 minecraft:purple_concrete
fill 376 293 562 376 296 562 minecraft:black_concrete
fill 376 293 573 376 296 573 minecraft:black_concrete
setblock 376 293 578 minecraft:purple_concrete
setblock 376 293 589 minecraft:purple_concrete
fill 376 293 593 376 296 594 minecraft:black_concrete
setblock 380 293 557 minecraft:purple_concrete
setblock 387 293 599 minecraft:purple_concrete
setblock 390 293 599 minecraft:purple_concrete
setblock 391 293 557 minecraft:purple_concrete
fill 391 293 599 391 296 599 minecraft:black_concrete
fill 392 293 557 392 295 557 minecraft:black_concrete
fill 396 293 557 396 296 557 minecraft:black_concrete
setblock 398 293 599 minecraft:purple_concrete
setblock 400 293 557 minecraft:purple_concrete
fill 402 293 599 402 296 599 minecraft:black_concrete
fill 407 293 557 407 296 557 minecraft:black_concrete
setblock 408 293 557 minecraft:purple_concrete
setblock 411 293 557 minecraft:purple_concrete
fill 418 293 566 418 296 567 minecraft:black_concrete
setblock 418 293 571 minecraft:purple_concrete
setblock 418 293 582 minecraft:purple_concrete
fill 418 293 587 418 296 587 minecraft:black_concrete
fill 418 293 598 418 296 598 minecraft:black_concrete
setblock 418 293 599 minecraft:purple_concrete
fill 376 294 557 376 299 558 minecraft:black_concrete
setblock 376 294 559 minecraft:purple_concrete
fill 376 294 561 376 299 561 minecraft:black_concrete
fill 376 294 567 376 295 568 minecraft:purple_concrete
fill 376 294 569 376 299 570 minecraft:black_concrete
fill 376 294 578 376 299 578 minecraft:black_concrete
fill 376 294 579 376 294 580 minecraft:purple_concrete
fill 376 294 581 376 299 582 minecraft:black_concrete
fill 376 294 587 376 295 588 minecraft:purple_concrete
fill 376 294 589 376 299 590 minecraft:black_concrete
setblock 376 294 591 minecraft:purple_concrete
fill 376 294 599 377 295 599 minecraft:purple_concrete
fill 377 294 558 379 294 558 minecraft:obsidian
fill 377 294 560 377 294 562 minecraft:obsidian
fill 377 294 564 377 294 566 minecraft:obsidian
fill 377 294 568 377 294 570 minecraft:obsidian
fill 377 294 572 377 294 574 minecraft:obsidian
fill 377 294 576 377 294 578 minecraft:obsidian
fill 377 294 580 377 294 582 minecraft:obsidian
fill 377 294 584 377 294 586 minecraft:obsidian
fill 377 294 588 377 294 590 minecraft:obsidian
fill 377 294 592 377 294 594 minecraft:obsidian
fill 377 294 596 377 294 598 minecraft:obsidian
setblock 378 294 557 minecraft:purple_concrete
fill 378 294 599 379 299 599 minecraft:black_concrete
fill 379 294 557 380 299 557 minecraft:black_concrete
fill 379 294 598 381 294 598 minecraft:obsidian
fill 381 294 557 382 295 557 minecraft:purple_concrete
fill 381 294 558 383 294 558 minecraft:obsidian
fill 383 294 598 385 294 598 minecraft:obsidian
fill 385 294 558 387 294 558 minecraft:obsidian
fill 385 294 599 385 295 599 minecraft:purple_concrete
fill 387 294 557 388 299 557 minecraft:black_concrete
fill 387 294 598 389 294 598 minecraft:obsidian
fill 387 294 599 387 299 599 minecraft:black_concrete
fill 388 294 599 389 294 599 minecraft:purple_concrete
fill 389 294 557 390 294 557 minecraft:purple_concrete
fill 389 294 558 391 294 558 minecraft:obsidian
fill 390 294 599 390 299 599 minecraft:black_concrete
fill 391 294 557 391 295 557 minecraft:black_concrete
fill 391 294 598 393 294 598 minecraft:obsidian
fill 393 294 558 395 294 558 minecraft:obsidian
fill 395 294 598 397 294 598 minecraft:obsidian
fill 396 294 599 397 295 599 minecraft:purple_concrete
fill 397 294 558 399 294 558 minecraft:obsidian
fill 398 294 599 399 299 599 minecraft:black_concrete
fill 399 294 557 400 299 557 minecraft:black_concrete
fill 399 294 598 401 294 598 minecraft:obsidian
fill 401 294 557 402 295 557 minecraft:purple_concrete
fill 401 294 558 403 294 558 minecraft:obsidian
fill 403 294 598 405 294 598 minecraft:obsidian
fill 405 294 558 407 294 558 minecraft:obsidian
fill 407 294 598 409 294 598 minecraft:obsidian
fill 408 294 557 408 299 557 minecraft:black_concrete
fill 408 294 599 409 294 599 minecraft:purple_concrete
fill 409 294 557 410 294 557 minecraft:purple_concrete
fill 409 294 558 411 294 558 minecraft:obsidian
fill 410 294 599 411 299 599 minecraft:black_concrete
fill 411 294 557 411 299 557 minecraft:black_concrete
fill 411 294 598 413 294 598 minecraft:obsidian
fill 413 294 557 413 295 557 minecraft:purple_concrete
fill 413 294 558 415 294 558 minecraft:obsidian
fill 415 294 598 417 294 598 minecraft:obsidian
fill 417 294 558 417 294 560 minecraft:obsidian
fill 417 294 562 417 294 564 minecraft:obsidian
fill 417 294 566 417 294 568 minecraft:obsidian
fill 417 294 570 417 294 572 minecraft:obsidian
fill 417 294 574 417 294 576 minecraft:obsidian
fill 417 294 578 417 294 580 minecraft:obsidian
fill 417 294 582 417 294 584 minecraft:obsidian
fill 417 294 586 417 294 588 minecraft:obsidian
fill 417 294 590 417 294 592 minecraft:obsidian
fill 417 294 594 417 294 596 minecraft:obsidian
fill 417 294 599 417 295 599 minecraft:purple_concrete
fill 418 294 558 418 299 559 minecraft:black_concrete
fill 418 294 560 418 295 561 minecraft:purple_concrete
setblock 418 294 569 minecraft:purple_concrete
fill 418 294 570 418 299 571 minecraft:black_concrete
fill 418 294 572 418 295 573 minecraft:purple_concrete
fill 418 294 578 418 299 579 minecraft:black_concrete
fill 418 294 580 418 294 581 minecraft:purple_concrete
fill 418 294 582 418 299 582 minecraft:black_concrete
fill 418 294 590 418 299 591 minecraft:black_concrete
fill 418 294 592 418 295 593 minecraft:purple_concrete
fill 418 294 599 418 299 599 minecraft:black_concrete
fill 376 295 559 376 298 559 minecraft:black_concrete
fill 376 295 575 376 295 576 minecraft:purple_concrete
setblock 376 295 579 minecraft:purple_concrete
fill 376 295 580 376 298 580 minecraft:black_concrete
fill 376 295 591 376 298 591 minecraft:black_concrete
setblock 376 295 596 minecraft:purple_concrete
fill 378 295 557 378 298 557 minecraft:black_concrete
setblock 384 295 599 minecraft:purple_concrete
fill 388 295 599 389 298 599 minecraft:black_concrete
fill 389 295 557 389 298 557 minecraft:black_concrete
setblock 390 295 557 minecraft:purple_concrete
fill 393 295 557 394 295 557 minecraft:purple_concrete
setblock 405 295 599 minecraft:purple_concrete
setblock 408 295 599 minecraft:purple_concrete
fill 409 295 557 410 298 557 minecraft:black_concrete
fill 409 295 599 409 298 599 minecraft:black_concrete
setblock 414 295 557 minecraft:purple_concrete
setblock 416 295 599 minecraft:purple_concrete
setblock 418 295 564 minecraft:purple_concrete
fill 418 295 569 418 298 569 minecraft:black_concrete
fill 418 295 580 418 298 580 minecraft:black_concrete
setblock 418 295 581 minecraft:purple_concrete
fill 418 295 584 418 295 585 minecraft:purple_concrete
fill 376 296 565 376 296 566 minecraft:purple_concrete
fill 376 296 567 376 307 568 minecraft:black_concrete
fill 376 296 574 376 297 574 minecraft:purple_concrete
fill 376 296 575 376 307 576 minecraft:black_concrete
setblock 376 296 577 minecraft:purple_concrete
fill 376 296 579 376 307 579 minecraft:black_concrete
fill 376 296 585 376 297 586 minecraft:purple_concrete
fill 376 296 587 376 307 588 minecraft:black_concrete
fill 376 296 596 376 307 596 minecraft:black_concrete
fill 376 296 597 376 296 598 minecraft:purple_concrete
fill 376 296 599 377 307 599 minecraft:black_concrete
fill 381 296 557 382 307 557 minecraft:black_concrete
fill 382 296 599 383 297 599 minecraft:purple_concrete
fill 383 296 557 384 297 557 minecraft:purple_concrete
fill 384 296 599 385 307 599 minecraft:black_concrete
setblock 386 296 599 minecraft:purple_concrete
fill 390 296 557 390 307 557 minecraft:black_concrete
fill 391 296 557 392 296 557 minecraft:purple_concrete
fill 393 296 557 394 297 557 minecraft:black_concrete
fill 394 296 599 395 297 599 minecraft:purple_concrete
fill 395 296 557 395 297 557 minecraft:purple_concrete
fill 396 296 599 397 307 599 minecraft:black_concrete
fill 401 296 557 402 307 557 minecraft:black_concrete
fill 403 296 557 404 297 557 minecraft:purple_concrete
fill 403 296 599 403 297 599 minecraft:purple_concrete
fill 405 296 599 405 307 599 minecraft:black_concrete
fill 406 296 599 407 296 599 minecraft:purple_concrete
fill 408 296 599 408 307 599 minecraft:black_concrete
setblock 412 296 557 minecraft:purple_concrete
fill 413 296 557 414 307 557 minecraft:black_concrete
fill 414 296 599 415 297 599 minecraft:purple_concrete
fill 415 296 557 416 297 557 minecraft:purple_concrete
fill 416 296 599 417 307 599 minecraft:black_concrete
fill 418 296 560 418 307 561 minecraft:black_concrete
fill 418 296 562 418 296 563 minecraft:purple_concrete
fill 418 296 564 418 307 564 minecraft:black_concrete
fill 418 296 572 418 307 573 minecraft:black_concrete
fill 418 296 574 418 297 575 minecraft:purple_concrete
fill 418 296 581 418 307 581 minecraft:black_concrete
setblock 418 296 583 minecraft:purple_concrete
fill 418 296 584 418 307 585 minecraft:black_concrete
fill 418 296 586 418 297 586 minecraft:purple_concrete
fill 418 296 592 418 307 593 minecraft:black_concrete
fill 418 296 594 418 296 595 minecraft:purple_concrete
setblock 376 297 562 minecraft:purple_concrete
setblock 376 297 565 minecraft:purple_concrete
fill 376 297 566 376 307 566 minecraft:black_concrete
setblock 376 297 573 minecraft:purple_concrete
fill 376 297 577 376 307 577 minecraft:black_concrete
fill 376 297 593 376 297 594 minecraft:purple_concrete
setblock 376 297 597 minecraft:purple_concrete
fill 376 297 598 376 307 598 minecraft:black_concrete
fill 386 297 599 386 307 599 minecraft:black_concrete
fill 391 297 557 392 299 557 minecraft:black_concrete
setblock 391 297 599 minecraft:purple_concrete
setblock 396 297 557 minecraft:purple_concrete
setblock 402 297 599 minecraft:purple_concrete
fill 406 297 599 407 307 599 minecraft:black_concrete
setblock 407 297 557 minecraft:purple_concrete
fill 412 297 557 412 307 557 minecraft:black_concrete
fill 413 297 581 415 298 581 minecraft:amethyst_block
fill 414 297 582 414 298 582 minecraft:amethyst_block
fill 418 297 562 418 307 562 minecraft:black_concrete
setblock 418 297 563 minecraft:purple_concrete
fill 418 297 566 418 297 567 minecraft:purple_concrete
fill 418 297 583 418 307 583 minecraft:black_concrete
setblock 418 297 587 minecraft:purple_concrete
fill 418 297 594 418 307 594 minecraft:black_concrete
setblock 418 297 595 minecraft:purple_concrete
setblock 418 297 598 minecraft:purple_concrete
fill 376 298 560 376 299 560 minecraft:purple_concrete
fill 376 298 562 376 307 562 minecraft:black_concrete
fill 376 298 563 376 298 564 minecraft:purple_concrete
fill 376 298 565 376 307 565 minecraft:black_concrete
fill 376 298 571 376 299 572 minecraft:purple_concrete
fill 376 298 573 376 307 574 minecraft:black_concrete
fill 376 298 583 376 298 584 minecraft:purple_concrete
fill 376 298 585 376 307 586 minecraft:black_concrete
fill 376 298 592 376 299 592 minecraft:purple_concrete
fill 376 298 593 376 307 594 minecraft:black_concrete
setblock 376 298 595 minecraft:purple_concrete
fill 376 298 597 376 307 597 minecraft:black_concrete
fill 377 298 557 377 299 557 minecraft:purple_concrete
fill 380 298 599 381 299 599 minecraft:purple_concrete
fill 382 298 599 383 307 599 minecraft:black_concrete
fill 383 298 557 384 307 557 minecraft:black_concrete
fill 385 298 557 386 299 557 minecraft:purple_concrete
fill 391 298 599 391 307 599 minecraft:black_concrete
fill 392 298 599 393 298 599 minecraft:purple_concrete
fill 393 298 557 393 307 557 minecraft:black_concrete
setblock 394 298 557 minecraft:purple_concrete
fill 394 298 599 395 307 599 minecraft:black_concrete
fill 395 298 557 396 307 557 minecraft:black_concrete
fill 397 298 557 398 299 557 minecraft:purple_concrete
fill 400 298 599 401 299 599 minecraft:purple_concrete
fill 402 298 599 403 307 599 minecraft:black_concrete
fill 403 298 557 404 307 557 minecraft:black_concrete
setblock 404 298 599 minecraft:purple_concrete
fill 405 298 557 406 298 557 minecraft:purple_concrete
fill 407 298 557 407 307 557 minecraft:black_concrete
fill 412 298 599 413 299 599 minecraft:purple_concrete
fill 414 298 599 415 307 599 minecraft:black_concrete
fill 415 298 557 416 307 557 minecraft:black_concrete
fill 417 298 557 418 299 557 minecraft:purple_concrete
fill 418 298 563 418 307 563 minecraft:black_concrete
setblock 418 298 565 minecraft:purple_concrete
fill 418 298 566 418 307 567 minecraft:black_concrete
fill 418 298 568 418 299 568 minecraft:purple_concrete
fill 418 298 574 418 307 575 minecraft:black_concrete
fill 418 298 576 418 298 577 minecraft:purple_concrete
fill 418 298 586 418 307 587 minecraft:black_concrete
fill 418 298 588 418 299 589 minecraft:purple_concrete
fill 418 298 595 418 307 595 minecraft:black_concrete
fill 418 298 596 418 298 597 minecraft:purple_concrete
fill 418 298 598 418 307 598 minecraft:black_concrete
setblock 376 299 559 minecraft:purple_concrete
fill 376 299 563 376 307 564 minecraft:black_concrete
setblock 376 299 580 minecraft:purple_concrete
setblock 376 299 583 minecraft:purple_concrete
fill 376 299 584 376 307 584 minecraft:black_concrete
setblock 376 299 591 minecraft:purple_concrete
fill 376 299 595 376 307 595 minecraft:black_concrete
setblock 378 299 557 minecraft:purple_concrete
fill 388 299 599 389 299 599 minecraft:purple_concrete
setblock 389 299 557 minecraft:purple_concrete
setblock 392 299 599 minecraft:purple_concrete
fill 393 299 599 393 307 599 minecraft:black_concrete
fill 394 299 557 394 307 557 minecraft:black_concrete
fill 404 299 599 404 307 599 minecraft:black_concrete
fill 405 299 557 405 307 557 minecraft:black_concrete
setblock 406 299 557 minecraft:purple_concrete
fill 409 299 557 410 299 557 minecraft:purple_concrete
setblock 409 299 599 minecraft:purple_concrete
fill 418 299 565 418 307 565 minecraft:black_concrete
setblock 418 299 569 minecraft:purple_concrete
fill 418 299 576 418 307 576 minecraft:black_concrete
setblock 418 299 577 minecraft:purple_concrete
setblock 418 299 580 minecraft:purple_concrete
fill 418 299 596 418 307 597 minecraft:black_concrete
fill 376 300 557 376 300 558 minecraft:purple_concrete
fill 376 300 559 376 307 560 minecraft:black_concrete
setblock 376 300 561 minecraft:purple_concrete
fill 376 300 569 376 300 570 minecraft:purple_concrete
fill 376 300 571 376 307 572 minecraft:black_concrete
setblock 376 300 578 minecraft:purple_concrete
fill 376 300 580 376 307 580 minecraft:black_concrete
fill 376 300 581 376 300 582 minecraft:purple_concrete
fill 376 300 583 376 307 583 minecraft:black_concrete
fill 376 300 589 376 300 590 minecraft:purple_concrete
fill 376 300 591 376 307 592 minecraft:black_concrete
fill 377 300 557 378 307 557 minecraft:black_concrete
fill 377 300 558 379 300 558 minecraft:obsidian
fill 377 300 560 377 300 562 minecraft:obsidian
fill 377 300 564 377 300 566 minecraft:obsidian
fill 377 300 568 377 300 570 minecraft:obsidian
fill 377 300 572 377 300 574 minecraft:obsidian
fill 377 300 576 377 300 578 minecraft:obsidian
fill 377 300 580 377 300 582 minecraft:obsidian
fill 377 300 584 377 300 586 minecraft:obsidian
fill 377 300 588 377 300 590 minecraft:obsidian
fill 377 300 592 377 300 594 minecraft:obsidian
fill 377 300 596 377 300 598 minecraft:obsidian
fill 378 300 599 379 300 599 minecraft:purple_concrete
fill 379 300 557 380 300 557 minecraft:purple_concrete
setblock 379 300 560 minecraft:light[level=12]
setblock 379 300 568 minecraft:light[level=12]
setblock 379 300 576 minecraft:light[level=12]
setblock 379 300 584 minecraft:light[level=12]
setblock 379 300 592 minecraft:light[level=12]
fill 379 300 598 381 300 598 minecraft:obsidian
fill 380 300 599 381 307 599 minecraft:black_concrete
fill 381 300 558 383 300 558 minecraft:obsidian
fill 383 300 598 385 300 598 minecraft:obsidian
fill 385 300 557 386 307 557 minecraft:black_concrete
fill 385 300 558 387 300 558 minecraft:obsidian
fill 387 300 557 388 300 557 minecraft:purple_concrete
setblock 387 300 560 minecraft:light[level=12]
setblock 387 300 568 minecraft:light[level=12]
setblock 387 300 576 minecraft:light[level=12]
setblock 387 300 584 minecraft:light[level=12]
setblock 387 300 592 minecraft:light[level=12]
fill 387 300 598 389 300 598 minecraft:obsidian
setblock 387 300 599 minecraft:purple_concrete
fill 388 300 599 389 307 599 minecraft:black_concrete
fill 389 300 557 389 307 557 minecraft:black_concrete
fill 389 300 558 391 300 558 minecraft:obsidian
setblock 390 300 599 minecraft:purple_concrete
setblock 391 300 557 minecraft:purple_concrete
fill 391 300 598 393 300 598 minecraft:obsidian
fill 392 300 557 392 307 557 minecraft:black_concrete
fill 392 300 599 392 307 599 minecraft:black_concrete
fill 393 300 558 395 300 558 minecraft:obsidian
setblock 395 300 560 minecraft:light[level=12]
setblock 395 300 568 minecraft:light[level=12]
setblock 395 300 576 minecraft:light[level=12]
setblock 395 300 584 minecraft:light[level=12]
setblock 395 300 592 minecraft:light[level=12]
fill 395 300 598 397 300 598 minecraft:obsidian
fill 397 300 557 398 307 557 minecraft:black_concrete
fill 397 300 558 399 300 558 minecraft:obsidian
fill 398 300 599 399 300 599 minecraft:purple_concrete
fill 399 300 557 400 300 557 minecraft:purple_concrete
fill 399 300 598 401 300 598 minecraft:obsidian
fill 400 300 599 401 307 599 minecraft:black_concrete
fill 401 300 558 403 300 558 minecraft:obsidian
setblock 403 300 560 minecraft:light[level=12]
setblock 403 300 568 minecraft:light[level=12]
setblock 403 300 576 minecraft:light[level=12]
setblock 403 300 584 minecraft:light[level=12]
setblock 403 300 592 minecraft:light[level=12]
fill 403 300 598 405 300 598 minecraft:obsidian
fill 405 300 558 407 300 558 minecraft:obsidian
fill 406 300 557 406 307 557 minecraft:black_concrete
fill 407 300 598 409 300 598 minecraft:obsidian
setblock 408 300 557 minecraft:purple_concrete
fill 409 300 557 410 307 557 minecraft:black_concrete
fill 409 300 558 411 300 558 minecraft:obsidian
fill 409 300 599 409 307 599 minecraft:black_concrete
fill 410 300 599 411 300 599 minecraft:purple_concrete
setblock 411 300 557 minecraft:purple_concrete
setblock 411 300 560 minecraft:light[level=12]
setblock 411 300 568 minecraft:light[level=12]
setblock 411 300 576 minecraft:light[level=12]
setblock 411 300 584 minecraft:light[level=12]
setblock 411 300 592 minecraft:light[level=12]
fill 411 300 598 413 300 598 minecraft:obsidian
fill 412 300 599 413 307 599 minecraft:black_concrete
fill 413 300 558 415 300 558 minecraft:obsidian
fill 415 300 598 417 300 598 minecraft:obsidian
fill 417 300 557 418 307 557 minecraft:black_concrete
fill 417 300 558 417 300 560 minecraft:obsidian
fill 417 300 562 417 300 564 minecraft:obsidian
fill 417 300 566 417 300 568 minecraft:obsidian
fill 417 300 570 417 300 572 minecraft:obsidian
fill 417 300 574 417 300 576 minecraft:obsidian
fill 417 300 578 417 300 580 minecraft:obsidian
fill 417 300 582 417 300 584 minecraft:obsidian
fill 417 300 586 417 300 588 minecraft:obsidian
fill 417 300 590 417 300 592 minecraft:obsidian
fill 417 300 594 417 300 596 minecraft:obsidian
fill 418 300 558 418 300 559 minecraft:purple_concrete
fill 418 300 568 418 307 569 minecraft:black_concrete
fill 418 300 570 418 300 571 minecraft:purple_concrete
fill 418 300 577 418 307 577 minecraft:black_concrete
fill 418 300 578 418 300 579 minecraft:purple_concrete
fill 418 300 580 418 307 580 minecraft:black_concrete
setblock 418 300 582 minecraft:purple_concrete
fill 418 300 588 418 307 589 minecraft:black_concrete
fill 418 300 590 418 300 591 minecraft:purple_concrete
setblock 418 300 599 minecraft:purple_concrete
fill 376 301 557 376 307 558 minecraft:black_concrete
fill 376 301 561 376 307 561 minecraft:black_concrete
fill 376 301 569 376 307 570 minecraft:black_concrete
fill 376 301 578 376 307 578 minecraft:black_concrete
fill 376 301 581 376 307 582 minecraft:black_concrete
fill 376 301 589 376 307 590 minecraft:black_concrete
fill 378 301 599 379 307 599 minecraft:black_concrete
fill 379 301 557 380 307 557 minecraft:black_concrete
fill 387 301 557 388 307 557 minecraft:black_concrete
fill 387 301 599 387 307 599 minecraft:black_concrete
fill 390 301 599 390 307 599 minecraft:black_concrete
fill 391 301 557 391 307 557 minecraft:black_concrete
fill 398 301 599 399 307 599 minecraft:black_concrete
fill 399 301 557 400 307 557 minecraft:black_concrete
fill 408 301 557 408 307 557 minecraft:black_concrete
fill 410 301 599 411 307 599 minecraft:black_concrete
fill 411 301 557 411 307 557 minecraft:black_concrete
fill 418 301 558 418 307 559 minecraft:black_concrete
fill 418 301 570 418 307 571 minecraft:black_concrete
fill 418 301 578 418 307 579 minecraft:black_concrete
fill 418 301 582 418 307 582 minecraft:black_concrete
fill 418 301 590 418 307 591 minecraft:black_concrete
fill 418 301 599 418 307 599 minecraft:black_concrete
