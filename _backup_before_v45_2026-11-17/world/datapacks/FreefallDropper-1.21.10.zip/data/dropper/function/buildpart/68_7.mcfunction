setblock 410 235 303 minecraft:shroomlight
setblock 410 235 305 minecraft:shroomlight
setblock 410 235 307 minecraft:shroomlight
fill 410 235 316 410 238 316 minecraft:red_terracotta
setblock 411 235 294 minecraft:shroomlight
setblock 411 235 296 minecraft:shroomlight
setblock 411 235 298 minecraft:shroomlight
setblock 411 235 300 minecraft:shroomlight
setblock 411 235 302 minecraft:shroomlight
setblock 411 235 304 minecraft:shroomlight
setblock 411 235 306 minecraft:shroomlight
setblock 411 235 308 minecraft:shroomlight
setblock 412 235 295 minecraft:shroomlight
setblock 412 235 297 minecraft:shroomlight
setblock 412 235 299 minecraft:shroomlight
setblock 412 235 301 minecraft:shroomlight
setblock 412 235 303 minecraft:shroomlight
setblock 412 235 305 minecraft:shroomlight
setblock 412 235 307 minecraft:shroomlight
setblock 413 235 294 minecraft:shroomlight
setblock 413 235 296 minecraft:shroomlight
setblock 413 235 298 minecraft:shroomlight
setblock 413 235 300 minecraft:shroomlight
setblock 413 235 302 minecraft:shroomlight
setblock 413 235 304 minecraft:shroomlight
setblock 413 235 306 minecraft:shroomlight
setblock 413 235 308 minecraft:shroomlight
setblock 414 235 276 minecraft:stripped_oak_log
setblock 414 235 295 minecraft:shroomlight
setblock 414 235 297 minecraft:shroomlight
setblock 414 235 299 minecraft:shroomlight
setblock 414 235 301 minecraft:shroomlight
setblock 414 235 303 minecraft:shroomlight
setblock 414 235 305 minecraft:shroomlight
setblock 414 235 307 minecraft:shroomlight
setblock 414 235 316 minecraft:stripped_oak_log
fill 415 235 276 415 238 276 minecraft:red_terracotta
setblock 415 235 294 minecraft:shroomlight
setblock 415 235 296 minecraft:shroomlight
setblock 415 235 298 minecraft:shroomlight
setblock 415 235 300 minecraft:shroomlight
setblock 415 235 302 minecraft:shroomlight
setblock 415 235 304 minecraft:shroomlight
setblock 415 235 306 minecraft:shroomlight
setblock 415 235 308 minecraft:shroomlight
fill 415 235 316 415 238 316 minecraft:red_terracotta
setblock 416 235 295 minecraft:shroomlight
setblock 416 235 297 minecraft:shroomlight
setblock 416 235 298 minecraft:red_terracotta
setblock 416 235 299 minecraft:shroomlight
fill 416 235 300 416 238 300 minecraft:red_terracotta
setblock 416 235 301 minecraft:shroomlight
setblock 416 235 303 minecraft:shroomlight
setblock 416 235 305 minecraft:shroomlight
setblock 416 235 307 minecraft:shroomlight
fill 416 235 315 416 238 315 minecraft:red_terracotta
setblock 417 235 278 minecraft:stripped_oak_log
setblock 417 235 293 minecraft:stripped_oak_log
setblock 417 235 294 minecraft:shroomlight
setblock 417 235 296 minecraft:shroomlight
setblock 417 235 298 minecraft:shroomlight
fill 417 235 299 417 237 299 minecraft:red_terracotta
setblock 417 235 300 minecraft:shroomlight
fill 417 235 301 417 236 301 minecraft:red_terracotta
setblock 417 235 302 minecraft:shroomlight
setblock 417 235 303 minecraft:stripped_oak_log
setblock 417 235 304 minecraft:shroomlight
setblock 417 235 306 minecraft:shroomlight
setblock 417 235 308 minecraft:shroomlight
fill 417 235 309 417 238 309 minecraft:red_terracotta
setblock 417 235 313 minecraft:stripped_oak_log
fill 417 235 314 417 238 314 minecraft:red_terracotta
fill 376 236 275 376 239 317 minecraft:white_terracotta
fill 377 236 275 399 239 275 minecraft:white_terracotta
setblock 377 236 276 minecraft:red_terracotta
setblock 377 236 277 minecraft:stripped_oak_log
fill 377 236 278 377 237 280 minecraft:red_terracotta
fill 377 236 290 377 236 291 minecraft:red_terracotta
setblock 377 236 292 minecraft:stripped_oak_log
fill 377 236 293 377 236 296 minecraft:red_terracotta
setblock 377 236 297 minecraft:stripped_oak_log
fill 377 236 298 377 236 301 minecraft:red_terracotta
setblock 377 236 302 minecraft:stripped_oak_log
fill 377 236 303 377 239 303 minecraft:red_terracotta
setblock 377 236 307 minecraft:stripped_oak_log
fill 377 236 317 418 239 317 minecraft:white_terracotta
setblock 378 236 276 minecraft:stripped_oak_log
setblock 378 236 291 minecraft:stripped_oak_log
fill 378 236 292 378 239 292 minecraft:red_terracotta
setblock 378 236 296 minecraft:stripped_oak_log
fill 378 236 297 378 239 297 minecraft:red_terracotta
setblock 378 236 301 minecraft:stripped_oak_log
fill 378 236 302 378 239 302 minecraft:red_terracotta
setblock 378 236 316 minecraft:stripped_oak_log
fill 379 236 276 379 238 277 minecraft:red_terracotta
setblock 379 236 295 minecraft:stripped_oak_log
fill 379 236 296 379 239 296 minecraft:red_terracotta
setblock 379 236 300 minecraft:stripped_oak_log
fill 379 236 301 379 239 301 minecraft:red_terracotta
fill 379 236 316 382 236 316 minecraft:red_terracotta
fill 380 236 276 382 236 276 minecraft:red_terracotta
setblock 380 236 299 minecraft:stripped_oak_log
fill 380 236 300 380 239 300 minecraft:red_terracotta
setblock 382 236 277 minecraft:stripped_oak_log
setblock 382 236 292 minecraft:bone_block
setblock 382 236 296 minecraft:bone_block
setblock 383 236 276 minecraft:stripped_oak_log
fill 383 236 277 383 239 277 minecraft:red_terracotta
setblock 383 236 316 minecraft:stripped_oak_log
fill 384 236 276 384 239 276 minecraft:red_terracotta
setblock 384 236 316 minecraft:red_terracotta
setblock 387 236 276 minecraft:red_terracotta
fill 387 236 278 387 237 278 minecraft:stripped_oak_log
fill 387 236 293 387 236 295 minecraft:bone_block
fill 388 236 276 388 236 277 minecraft:stripped_oak_log
fill 388 236 279 388 237 279 minecraft:stripped_oak_log
fill 389 236 276 389 237 276 minecraft:red_terracotta
fill 389 236 278 389 237 278 minecraft:stripped_oak_log
fill 389 236 298 389 236 303 minecraft:brown_terracotta
fill 390 236 277 390 237 277 minecraft:stripped_oak_log
fill 390 236 279 390 237 279 minecraft:stripped_oak_log
fill 390 236 297 391 236 298 minecraft:brown_terracotta
fill 390 236 303 390 236 304 minecraft:brown_terracotta
fill 391 236 276 391 237 276 minecraft:red_terracotta
fill 391 236 278 391 237 278 minecraft:stripped_oak_log
fill 391 236 296 392 236 296 minecraft:brown_terracotta
fill 391 236 304 391 236 305 minecraft:brown_terracotta
setblock 392 236 277 minecraft:stripped_oak_log
fill 392 236 279 392 237 279 minecraft:stripped_oak_log
fill 392 236 305 396 236 305 minecraft:brown_terracotta
setblock 393 236 276 minecraft:stripped_oak_log
fill 393 236 277 394 237 277 minecraft:red_terracotta
fill 393 236 278 393 237 278 minecraft:stripped_oak_log
fill 394 236 276 395 237 276 minecraft:red_terracotta
fill 394 236 279 394 237 279 minecraft:stripped_oak_log
fill 395 236 278 395 237 278 minecraft:stripped_oak_log
fill 395 236 316 397 236 316 minecraft:red_terracotta
setblock 396 236 277 minecraft:red_terracotta
fill 396 236 279 396 236 280 minecraft:stripped_oak_log
fill 396 236 304 397 236 304 minecraft:brown_terracotta
setblock 397 236 276 minecraft:red_terracotta
setblock 397 236 277 minecraft:stripped_oak_log
fill 397 236 278 397 237 278 minecraft:red_terracotta
fill 397 236 280 397 237 280 minecraft:stripped_oak_log
fill 397 236 282 397 237 282 minecraft:stripped_oak_log
setblock 397 236 303 minecraft:brown_terracotta
setblock 398 236 276 minecraft:stripped_oak_log
fill 398 236 277 398 237 277 minecraft:red_terracotta
fill 398 236 279 398 237 279 minecraft:stripped_oak_log
fill 398 236 281 398 237 281 minecraft:stripped_oak_log
fill 398 236 300 398 236 302 minecraft:brown_terracotta
setblock 398 236 315 minecraft:red_terracotta
setblock 398 236 316 minecraft:stripped_oak_log
fill 399 236 276 399 237 276 minecraft:red_terracotta
fill 399 236 278 399 237 278 minecraft:red_terracotta
fill 399 236 280 399 237 280 minecraft:stripped_oak_log
fill 399 236 282 399 237 282 minecraft:stripped_oak_log
setblock 399 236 315 minecraft:stripped_oak_log
fill 399 236 316 402 236 316 minecraft:red_terracotta
fill 400 236 277 400 237 277 minecraft:red_terracotta
setblock 400 236 279 minecraft:stripped_oak_log
fill 400 236 281 400 237 281 minecraft:stripped_oak_log
fill 400 236 315 403 236 315 minecraft:red_terracotta
fill 401 236 276 401 237 276 minecraft:red_terracotta
setblock 401 236 278 minecraft:stripped_oak_log
fill 401 236 280 401 237 280 minecraft:stripped_oak_log
fill 401 236 282 401 237 282 minecraft:stripped_oak_log
setblock 402 236 277 minecraft:stripped_oak_log
fill 402 236 278 403 237 278 minecraft:red_terracotta
fill 402 236 279 402 237 279 minecraft:stripped_oak_log
fill 402 236 281 402 237 281 minecraft:stripped_oak_log
fill 403 236 275 418 239 275 minecraft:white_terracotta
setblock 403 236 276 minecraft:stripped_oak_log
fill 403 236 277 403 239 277 minecraft:red_terracotta
fill 403 236 280 403 237 280 minecraft:stripped_oak_log
fill 403 236 282 403 237 282 minecraft:stripped_oak_log
setblock 403 236 316 minecraft:stripped_oak_log
fill 404 236 276 407 236 276 minecraft:red_terracotta
setblock 404 236 315 minecraft:stripped_oak_log
fill 404 236 316 407 236 316 minecraft:red_terracotta
fill 405 236 315 406 236 315 minecraft:red_terracotta
setblock 407 236 277 minecraft:stripped_oak_log
setblock 408 236 276 minecraft:stripped_oak_log
setblock 408 236 316 minecraft:stripped_oak_log
fill 409 236 276 409 239 276 minecraft:red_terracotta
fill 409 236 294 409 237 294 minecraft:stripped_oak_log
fill 409 236 296 409 237 296 minecraft:stripped_oak_log
fill 409 236 298 409 237 298 minecraft:stripped_oak_log
fill 409 236 300 409 237 300 minecraft:stripped_oak_log
fill 409 236 302 409 237 302 minecraft:stripped_oak_log
fill 409 236 304 409 237 304 minecraft:stripped_oak_log
fill 409 236 306 409 237 306 minecraft:stripped_oak_log
fill 409 236 308 409 237 308 minecraft:stripped_oak_log
fill 409 236 316 409 239 316 minecraft:red_terracotta
fill 410 236 295 410 237 295 minecraft:stripped_oak_log
fill 410 236 297 410 237 297 minecraft:stripped_oak_log
fill 410 236 299 410 237 299 minecraft:stripped_oak_log
fill 410 236 301 410 237 301 minecraft:stripped_oak_log
fill 410 236 303 410 237 303 minecraft:stripped_oak_log
fill 410 236 305 410 237 305 minecraft:stripped_oak_log
fill 410 236 307 410 237 307 minecraft:stripped_oak_log
fill 411 236 294 411 237 294 minecraft:stripped_oak_log
fill 411 236 296 411 237 296 minecraft:stripped_oak_log
fill 411 236 298 411 237 298 minecraft:stripped_oak_log
fill 411 236 300 411 237 300 minecraft:stripped_oak_log
fill 411 236 302 411 237 302 minecraft:stripped_oak_log
fill 411 236 304 411 237 304 minecraft:stripped_oak_log
fill 411 236 306 411 237 306 minecraft:stripped_oak_log
fill 411 236 308 411 237 308 minecraft:stripped_oak_log
fill 412 236 295 412 237 295 minecraft:stripped_oak_log
fill 412 236 297 412 237 297 minecraft:stripped_oak_log
fill 412 236 299 412 237 299 minecraft:stripped_oak_log
fill 412 236 301 412 237 301 minecraft:stripped_oak_log
fill 412 236 303 412 237 303 minecraft:stripped_oak_log
fill 412 236 305 412 237 305 minecraft:stripped_oak_log
fill 412 236 307 412 237 307 minecraft:stripped_oak_log
setblock 413 236 276 minecraft:stripped_oak_log
fill 413 236 294 413 237 294 minecraft:stripped_oak_log
fill 413 236 296 413 237 296 minecraft:stripped_oak_log
fill 413 236 298 413 237 298 minecraft:stripped_oak_log
fill 413 236 300 413 237 300 minecraft:stripped_oak_log
fill 413 236 302 413 237 302 minecraft:stripped_oak_log
fill 413 236 304 413 237 304 minecraft:stripped_oak_log
fill 413 236 306 413 237 306 minecraft:stripped_oak_log
fill 413 236 308 413 237 308 minecraft:stripped_oak_log
setblock 413 236 316 minecraft:stripped_oak_log
fill 414 236 276 414 239 276 minecraft:red_terracotta
fill 414 236 295 414 237 295 minecraft:stripped_oak_log
fill 414 236 297 414 237 297 minecraft:stripped_oak_log
fill 414 236 299 414 237 299 minecraft:stripped_oak_log
fill 414 236 301 414 237 301 minecraft:stripped_oak_log
fill 414 236 303 414 237 303 minecraft:stripped_oak_log
fill 414 236 305 414 237 305 minecraft:stripped_oak_log
fill 414 236 307 414 237 307 minecraft:stripped_oak_log
fill 414 236 316 414 239 316 minecraft:red_terracotta
fill 415 236 294 415 237 294 minecraft:stripped_oak_log
fill 415 236 296 415 237 296 minecraft:stripped_oak_log
fill 415 236 298 416 236 298 minecraft:stripped_oak_log
fill 415 236 300 415 237 300 minecraft:stripped_oak_log
fill 415 236 302 415 237 302 minecraft:stripped_oak_log
fill 415 236 304 415 237 304 minecraft:stripped_oak_log
fill 415 236 306 415 237 306 minecraft:stripped_oak_log
fill 415 236 308 415 237 308 minecraft:stripped_oak_log
fill 416 236 295 416 237 295 minecraft:stripped_oak_log
setblock 416 236 297 minecraft:red_terracotta
fill 416 236 299 416 237 299 minecraft:red_terracotta
fill 416 236 301 416 236 302 minecraft:red_terracotta
setblock 416 236 303 minecraft:stripped_oak_log
setblock 416 236 305 minecraft:stripped_oak_log
fill 416 236 307 417 236 307 minecraft:stripped_oak_log
setblock 417 236 277 minecraft:stripped_oak_log
fill 417 236 278 417 238 279 minecraft:red_terracotta
fill 417 236 293 417 237 294 minecraft:red_terracotta
setblock 417 236 296 minecraft:red_terracotta
setblock 417 236 297 minecraft:stripped_oak_log
fill 417 236 298 417 237 298 minecraft:red_terracotta
fill 417 236 300 417 237 300 minecraft:red_terracotta
setblock 417 236 302 minecraft:stripped_oak_log
fill 417 236 303 417 237 304 minecraft:red_terracotta
setblock 417 236 306 minecraft:red_terracotta
fill 417 236 308 417 237 308 minecraft:red_terracotta
setblock 417 236 312 minecraft:stripped_oak_log
fill 417 236 313 417 239 313 minecraft:red_terracotta
fill 418 236 276 418 239 316 minecraft:white_terracotta
setblock 377 237 276 minecraft:stripped_oak_log
fill 377 237 277 378 239 277 minecraft:red_terracotta
setblock 377 237 281 minecraft:stripped_oak_log
fill 377 237 282 377 239 283 minecraft:red_terracotta
fill 377 237 289 377 237 290 minecraft:red_terracotta
setblock 377 237 291 minecraft:stripped_oak_log
fill 377 237 292 377 237 295 minecraft:red_terracotta
setblock 377 237 296 minecraft:stripped_oak_log
fill 377 237 297 377 237 300 minecraft:red_terracotta
setblock 377 237 301 minecraft:stripped_oak_log
fill 377 237 302 377 240 302 minecraft:red_terracotta
setblock 377 237 305 minecraft:red_terracotta
setblock 377 237 306 minecraft:stripped_oak_log
fill 377 237 307 377 239 308 minecraft:red_terracotta
setblock 377 237 315 minecraft:red_terracotta
setblock 377 237 316 minecraft:stripped_oak_log
fill 378 237 276 378 240 276 minecraft:red_terracotta
fill 378 237 278 378 237 279 minecraft:red_terracotta
setblock 378 237 280 minecraft:stripped_oak_log
fill 378 237 291 378 240 291 minecraft:red_terracotta
setblock 378 237 295 minecraft:stripped_oak_log
fill 378 237 296 378 240 296 minecraft:red_terracotta
setblock 378 237 300 minecraft:stripped_oak_log
fill 378 237 301 378 240 301 minecraft:red_terracotta
fill 378 237 316 381 237 316 minecraft:red_terracotta
setblock 379 237 294 minecraft:stripped_oak_log
fill 379 237 295 379 240 295 minecraft:red_terracotta
setblock 379 237 299 minecraft:stripped_oak_log
fill 379 237 300 379 240 300 minecraft:red_terracotta
setblock 379 237 303 minecraft:red_terracotta
fill 380 237 276 381 237 276 minecraft:red_terracotta
setblock 380 237 298 minecraft:stripped_oak_log
fill 380 237 299 380 240 299 minecraft:red_terracotta
setblock 381 237 277 minecraft:stripped_oak_log
setblock 382 237 276 minecraft:stripped_oak_log
fill 382 237 277 382 240 277 minecraft:red_terracotta
setblock 382 237 316 minecraft:stripped_oak_log
fill 383 237 276 383 240 276 minecraft:red_terracotta
setblock 383 237 293 minecraft:bone_block
fill 383 237 295 384 237 295 minecraft:bone_block
setblock 383 237 316 minecraft:red_terracotta
setblock 386 237 294 minecraft:bone_block
setblock 387 237 276 minecraft:stripped_oak_log
fill 388 237 276 388 240 276 minecraft:red_terracotta
setblock 388 237 277 minecraft:stripped_oak_log
setblock 392 237 276 minecraft:stripped_oak_log
setblock 392 237 277 minecraft:red_terracotta
setblock 393 237 276 minecraft:red_terracotta
fill 395 237 316 396 237 316 minecraft:red_terracotta
setblock 396 237 277 minecraft:stripped_oak_log
fill 396 237 278 396 240 278 minecraft:red_terracotta
setblock 396 237 279 minecraft:stripped_oak_log
setblock 397 237 276 minecraft:stripped_oak_log
fill 397 237 277 397 240 277 minecraft:red_terracotta
setblock 397 237 316 minecraft:stripped_oak_log
fill 398 237 276 398 240 276 minecraft:red_terracotta
setblock 398 237 315 minecraft:stripped_oak_log
fill 398 237 316 401 237 316 minecraft:red_terracotta
fill 399 237 315 402 237 315 minecraft:red_terracotta
setblock 400 237 278 minecraft:stripped_oak_log
fill 400 237 279 401 237 279 minecraft:red_terracotta
setblock 401 237 277 minecraft:stripped_oak_log
setblock 401 237 278 minecraft:red_terracotta
setblock 402 237 276 minecraft:stripped_oak_log
setblock 402 237 277 minecraft:red_terracotta
setblock 402 237 316 minecraft:stripped_oak_log
fill 403 237 276 406 237 276 minecraft:red_terracotta
setblock 403 237 315 minecraft:stripped_oak_log
fill 403 237 316 406 237 316 minecraft:red_terracotta
fill 404 237 315 405 238 315 minecraft:red_terracotta
fill 405 237 278 405 242 278 minecraft:stripped_oak_log
setblock 406 237 277 minecraft:stripped_oak_log
setblock 407 237 276 minecraft:stripped_oak_log
fill 407 237 277 407 239 277 minecraft:red_terracotta
setblock 407 237 316 minecraft:stripped_oak_log
fill 408 237 276 408 240 276 minecraft:red_terracotta
fill 408 237 316 408 240 316 minecraft:red_terracotta
setblock 412 237 276 minecraft:stripped_oak_log
setblock 412 237 316 minecraft:stripped_oak_log
fill 413 237 276 413 240 276 minecraft:red_terracotta
fill 413 237 316 413 240 316 minecraft:red_terracotta
setblock 415 237 298 minecraft:stripped_oak_log
setblock 416 237 296 minecraft:red_terracotta
setblock 416 237 297 minecraft:stripped_oak_log
fill 416 237 298 416 240 298 minecraft:red_terracotta
setblock 416 237 301 minecraft:red_terracotta
setblock 416 237 302 minecraft:stripped_oak_log
fill 416 237 303 416 237 305 minecraft:red_terracotta
setblock 416 237 307 minecraft:stripped_oak_log
setblock 417 237 276 minecraft:stripped_oak_log
fill 417 237 277 417 240 277 minecraft:red_terracotta
setblock 417 237 280 minecraft:red_terracotta
setblock 417 237 281 minecraft:stripped_oak_log
setblock 417 237 296 minecraft:stripped_oak_log
fill 417 237 297 417 240 297 minecraft:red_terracotta
setblock 417 237 301 minecraft:stripped_oak_log
setblock 417 237 302 minecraft:red_terracotta
setblock 417 237 306 minecraft:stripped_oak_log
fill 417 237 307 417 240 307 minecraft:red_terracotta
setblock 417 237 311 minecraft:stripped_oak_log
fill 417 237 312 417 240 312 minecraft:red_terracotta
setblock 417 237 316 minecraft:stripped_oak_log
fill 377 238 276 377 241 276 minecraft:red_terracotta
fill 377 238 278 377 238 279 minecraft:red_terracotta
setblock 377 238 280 minecraft:stripped_oak_log
fill 377 238 281 378 240 281 minecraft:red_terracotta
setblock 377 238 284 minecraft:red_terracotta
setblock 377 238 285 minecraft:stripped_oak_log
fill 377 238 286 377 238 289 minecraft:red_terracotta
setblock 377 238 290 minecraft:stripped_oak_log
fill 377 238 291 377 238 294 minecraft:red_terracotta
setblock 377 238 295 minecraft:stripped_oak_log
fill 377 238 296 377 238 299 minecraft:red_terracotta
setblock 377 238 300 minecraft:stripped_oak_log
fill 377 238 301 377 241 301 minecraft:red_terracotta
setblock 377 238 304 minecraft:red_terracotta
setblock 377 238 305 minecraft:stripped_oak_log
fill 377 238 306 378 240 306 minecraft:red_terracotta
setblock 377 238 309 minecraft:red_terracotta
setblock 377 238 310 minecraft:stripped_oak_log
setblock 377 238 315 minecraft:stripped_oak_log
fill 377 238 316 380 238 316 minecraft:red_terracotta
setblock 378 238 278 minecraft:red_terracotta
setblock 378 238 279 minecraft:stripped_oak_log
fill 378 238 280 378 241 280 minecraft:red_terracotta
fill 378 238 282 378 238 283 minecraft:red_terracotta
fill 378 238 290 378 241 290 minecraft:red_terracotta
setblock 378 238 294 minecraft:stripped_oak_log
fill 378 238 295 378 241 295 minecraft:red_terracotta
setblock 378 238 299 minecraft:stripped_oak_log
fill 378 238 300 378 241 300 minecraft:red_terracotta
setblock 378 238 304 minecraft:stripped_oak_log
fill 378 238 305 378 241 305 minecraft:red_terracotta
setblock 379 238 293 minecraft:stripped_oak_log
fill 379 238 294 379 241 294 minecraft:red_terracotta
setblock 379 238 298 minecraft:stripped_oak_log
fill 379 238 299 379 241 299 minecraft:red_terracotta
setblock 379 238 303 minecraft:stripped_oak_log
fill 379 238 304 379 241 304 minecraft:red_terracotta
setblock 380 238 276 minecraft:red_terracotta
setblock 380 238 277 minecraft:stripped_oak_log
setblock 380 238 297 minecraft:stripped_oak_log
fill 380 238 298 380 241 298 minecraft:red_terracotta
setblock 380 238 301 minecraft:red_terracotta
setblock 381 238 276 minecraft:stripped_oak_log
fill 381 238 277 381 241 277 minecraft:red_terracotta
setblock 381 238 316 minecraft:stripped_oak_log
fill 382 238 276 382 241 276 minecraft:red_terracotta
setblock 382 238 316 minecraft:red_terracotta
setblock 385 238 277 minecraft:stripped_oak_log
setblock 386 238 276 minecraft:stripped_oak_log
setblock 387 238 276 minecraft:shroomlight
setblock 387 238 278 minecraft:shroomlight
setblock 388 238 277 minecraft:shroomlight
setblock 388 238 279 minecraft:shroomlight
setblock 389 238 276 minecraft:shroomlight
setblock 389 238 278 minecraft:shroomlight
setblock 390 238 277 minecraft:shroomlight
setblock 390 238 279 minecraft:shroomlight
setblock 391 238 276 minecraft:shroomlight
fill 391 238 277 391 241 277 minecraft:red_terracotta
setblock 391 238 278 minecraft:shroomlight
fill 392 238 276 392 241 276 minecraft:red_terracotta
setblock 392 238 277 minecraft:shroomlight
setblock 392 238 279 minecraft:shroomlight
setblock 393 238 276 minecraft:shroomlight
fill 393 238 277 393 239 277 minecraft:red_terracotta
setblock 393 238 278 minecraft:shroomlight
fill 394 238 276 394 239 276 minecraft:red_terracotta
setblock 394 238 277 minecraft:shroomlight
setblock 394 238 279 minecraft:shroomlight
fill 394 238 316 395 238 316 minecraft:red_terracotta
setblock 395 238 276 minecraft:shroomlight
setblock 395 238 277 minecraft:stripped_oak_log
setblock 395 238 278 minecraft:shroomlight
setblock 396 238 276 minecraft:stripped_oak_log
setblock 396 238 277 minecraft:shroomlight
setblock 396 238 279 minecraft:shroomlight
fill 396 238 301 396 256 301 minecraft:stripped_oak_log
setblock 396 238 316 minecraft:stripped_oak_log
setblock 397 238 276 minecraft:shroomlight
setblock 397 238 278 minecraft:shroomlight
setblock 397 238 279 minecraft:red_terracotta
setblock 397 238 280 minecraft:shroomlight
setblock 397 238 282 minecraft:shroomlight
setblock 397 238 315 minecraft:stripped_oak_log
fill 397 238 316 400 238 316 minecraft:red_terracotta
setblock 398 238 277 minecraft:shroomlight
setblock 398 238 279 minecraft:shroomlight
setblock 398 238 281 minecraft:shroomlight
fill 398 238 315 401 238 315 minecraft:red_terracotta
setblock 399 238 276 minecraft:shroomlight
setblock 399 238 278 minecraft:shroomlight
fill 399 238 279 399 241 279 minecraft:red_terracotta
setblock 399 238 280 minecraft:shroomlight
setblock 399 238 282 minecraft:shroomlight
setblock 400 238 277 minecraft:shroomlight
fill 400 238 278 400 241 278 minecraft:red_terracotta
setblock 400 238 279 minecraft:shroomlight
setblock 400 238 281 minecraft:shroomlight
setblock 401 238 276 minecraft:shroomlight
fill 401 238 277 401 241 277 minecraft:red_terracotta
setblock 401 238 278 minecraft:shroomlight
fill 401 238 279 401 239 279 minecraft:red_terracotta
setblock 401 238 280 minecraft:shroomlight
setblock 401 238 282 minecraft:shroomlight
setblock 401 238 316 minecraft:stripped_oak_log
fill 402 238 276 402 241 276 minecraft:red_terracotta
setblock 402 238 277 minecraft:shroomlight
fill 402 238 278 402 239 278 minecraft:red_terracotta
setblock 402 238 279 minecraft:shroomlight
setblock 402 238 281 minecraft:shroomlight
setblock 402 238 315 minecraft:stripped_oak_log
fill 402 238 316 405 238 316 minecraft:red_terracotta
setblock 403 238 276 minecraft:shroomlight
setblock 403 238 278 minecraft:shroomlight
setblock 403 238 280 minecraft:shroomlight
setblock 403 238 282 minecraft:shroomlight
fill 403 238 315 403 241 315 minecraft:red_terracotta
fill 404 238 276 405 238 276 minecraft:red_terracotta
setblock 404 238 278 minecraft:stripped_oak_log
setblock 405 238 277 minecraft:stripped_oak_log
setblock 406 238 276 minecraft:stripped_oak_log
fill 406 238 277 406 241 277 minecraft:red_terracotta
setblock 406 238 316 minecraft:stripped_oak_log
fill 407 238 276 407 241 276 minecraft:red_terracotta
fill 407 238 316 407 241 316 minecraft:red_terracotta
setblock 409 238 294 minecraft:shroomlight
setblock 409 238 296 minecraft:shroomlight
setblock 409 238 298 minecraft:shroomlight
setblock 409 238 300 minecraft:shroomlight
setblock 409 238 302 minecraft:shroomlight
setblock 409 238 304 minecraft:shroomlight
setblock 409 238 306 minecraft:shroomlight
setblock 409 238 308 minecraft:shroomlight
setblock 410 238 295 minecraft:shroomlight
setblock 410 238 297 minecraft:shroomlight
setblock 410 238 299 minecraft:shroomlight
setblock 410 238 301 minecraft:shroomlight
setblock 410 238 303 minecraft:shroomlight
setblock 410 238 305 minecraft:shroomlight
setblock 410 238 307 minecraft:shroomlight
setblock 411 238 276 minecraft:stripped_oak_log
setblock 411 238 294 minecraft:shroomlight
setblock 411 238 296 minecraft:shroomlight
setblock 411 238 298 minecraft:shroomlight
setblock 411 238 300 minecraft:shroomlight
setblock 411 238 302 minecraft:shroomlight
setblock 411 238 304 minecraft:shroomlight
setblock 411 238 306 minecraft:shroomlight
setblock 411 238 308 minecraft:shroomlight
setblock 411 238 316 minecraft:stripped_oak_log
fill 412 238 276 412 241 276 minecraft:red_terracotta
setblock 412 238 295 minecraft:shroomlight
setblock 412 238 297 minecraft:shroomlight
setblock 412 238 299 minecraft:shroomlight
setblock 412 238 301 minecraft:shroomlight
setblock 412 238 303 minecraft:shroomlight
setblock 412 238 305 minecraft:shroomlight
setblock 412 238 307 minecraft:shroomlight
fill 412 238 316 412 241 316 minecraft:red_terracotta
setblock 413 238 294 minecraft:shroomlight
setblock 413 238 296 minecraft:shroomlight
setblock 413 238 298 minecraft:shroomlight
setblock 413 238 300 minecraft:shroomlight
setblock 413 238 302 minecraft:shroomlight
setblock 413 238 304 minecraft:shroomlight
setblock 413 238 306 minecraft:shroomlight
setblock 413 238 308 minecraft:shroomlight
setblock 414 238 295 minecraft:shroomlight
setblock 414 238 297 minecraft:shroomlight
setblock 414 238 299 minecraft:shroomlight
setblock 414 238 301 minecraft:shroomlight
setblock 414 238 303 minecraft:shroomlight
setblock 414 238 305 minecraft:shroomlight
setblock 414 238 307 minecraft:shroomlight
setblock 415 238 294 minecraft:shroomlight
setblock 415 238 296 minecraft:shroomlight
setblock 415 238 298 minecraft:shroomlight
setblock 415 238 300 minecraft:shroomlight
setblock 415 238 301 minecraft:red_terracotta
setblock 415 238 302 minecraft:shroomlight
setblock 415 238 304 minecraft:shroomlight
setblock 415 238 306 minecraft:shroomlight
setblock 415 238 308 minecraft:shroomlight
setblock 416 238 276 minecraft:stripped_oak_log
setblock 416 238 295 minecraft:shroomlight
setblock 416 238 296 minecraft:stripped_oak_log
setblock 416 238 297 minecraft:shroomlight
fill 416 238 299 417 238 299 minecraft:shroomlight
setblock 416 238 301 minecraft:shroomlight
fill 416 238 302 416 241 302 minecraft:red_terracotta
setblock 416 238 303 minecraft:shroomlight
fill 416 238 304 416 239 304 minecraft:red_terracotta
setblock 416 238 305 minecraft:shroomlight
setblock 416 238 307 minecraft:shroomlight
setblock 416 238 316 minecraft:stripped_oak_log
fill 417 238 276 417 241 276 minecraft:red_terracotta
setblock 417 238 280 minecraft:stripped_oak_log
fill 417 238 281 417 240 282 minecraft:red_terracotta
fill 417 238 292 417 239 293 minecraft:red_terracotta
setblock 417 238 294 minecraft:shroomlight
setblock 417 238 295 minecraft:stripped_oak_log
setblock 417 238 296 minecraft:shroomlight
fill 417 238 298 417 241 298 minecraft:shroomlight
fill 417 238 300 417 241 300 minecraft:shroomlight
fill 417 238 301 417 241 301 minecraft:red_terracotta
setblock 417 238 302 minecraft:shroomlight
fill 417 238 303 417 239 303 minecraft:red_terracotta
setblock 417 238 304 minecraft:shroomlight
setblock 417 238 305 minecraft:stripped_oak_log
setblock 417 238 306 minecraft:shroomlight
setblock 417 238 308 minecraft:shroomlight
setblock 417 238 310 minecraft:stripped_oak_log
fill 417 238 311 417 241 311 minecraft:red_terracotta
setblock 417 238 315 minecraft:stripped_oak_log
fill 417 238 316 417 241 316 minecraft:red_terracotta
setblock 377 239 278 minecraft:red_terracotta
setblock 377 239 279 minecraft:stripped_oak_log
fill 377 239 280 377 242 280 minecraft:red_terracotta
setblock 377 239 284 minecraft:stripped_oak_log
fill 377 239 285 377 239 288 minecraft:red_terracotta
setblock 377 239 289 minecraft:stripped_oak_log
fill 377 239 290 377 239 293 minecraft:red_terracotta
setblock 377 239 294 minecraft:stripped_oak_log
fill 377 239 295 377 239 298 minecraft:red_terracotta
setblock 377 239 299 minecraft:stripped_oak_log
fill 377 239 300 377 242 300 minecraft:red_terracotta
setblock 377 239 304 minecraft:stripped_oak_log
fill 377 239 305 377 242 305 minecraft:red_terracotta
setblock 377 239 309 minecraft:stripped_oak_log
fill 377 239 310 377 239 313 minecraft:red_terracotta
setblock 377 239 314 minecraft:stripped_oak_log
fill 377 239 315 377 241 316 minecraft:red_terracotta
setblock 378 239 278 minecraft:stripped_oak_log
fill 378 239 279 379 241 279 minecraft:red_terracotta
setblock 378 239 282 minecraft:red_terracotta
setblock 378 239 283 minecraft:stripped_oak_log
fill 378 239 284 378 239 287 minecraft:red_terracotta
setblock 378 239 288 minecraft:stripped_oak_log
fill 378 239 289 378 242 289 minecraft:red_terracotta
setblock 378 239 293 minecraft:stripped_oak_log
fill 378 239 294 378 242 294 minecraft:red_terracotta
setblock 378 239 298 minecraft:stripped_oak_log
fill 378 239 299 378 242 299 minecraft:red_terracotta
setblock 378 239 303 minecraft:stripped_oak_log
fill 378 239 304 378 242 304 minecraft:red_terracotta
setblock 378 239 307 minecraft:red_terracotta
fill 378 239 316 379 239 316 minecraft:red_terracotta
setblock 379 239 276 minecraft:red_terracotta
setblock 379 239 277 minecraft:stripped_oak_log
fill 379 239 278 381 240 278 minecraft:red_terracotta
fill 379 239 280 379 239 281 minecraft:red_terracotta
setblock 379 239 282 minecraft:stripped_oak_log
fill 379 239 293 379 242 293 minecraft:red_terracotta
setblock 379 239 297 minecraft:stripped_oak_log
fill 379 239 298 379 242 298 minecraft:red_terracotta
setblock 379 239 302 minecraft:stripped_oak_log
fill 379 239 303 379 242 303 minecraft:red_terracotta
fill 379 239 305 379 240 305 minecraft:red_terracotta
setblock 380 239 276 minecraft:stripped_oak_log
fill 380 239 277 380 242 277 minecraft:red_terracotta
setblock 380 239 296 minecraft:stripped_oak_log
fill 380 239 297 380 241 297 minecraft:red_terracotta
setblock 380 239 301 minecraft:stripped_oak_log
fill 380 239 302 380 242 302 minecraft:red_terracotta
setblock 380 239 316 minecraft:stripped_oak_log
fill 381 239 276 381 242 276 minecraft:red_terracotta
fill 381 239 316 381 240 316 minecraft:red_terracotta
setblock 384 239 277 minecraft:stripped_oak_log
setblock 385 239 276 minecraft:stripped_oak_log
fill 385 239 277 386 241 277 minecraft:red_terracotta
fill 386 239 276 387 240 276 minecraft:red_terracotta
fill 387 239 278 387 240 278 minecraft:stripped_oak_log
fill 388 239 277 388 240 277 minecraft:stripped_oak_log
fill 388 239 279 388 240 279 minecraft:stripped_oak_log
setblock 389 239 276 minecraft:red_terracotta
fill 389 239 278 389 240 278 minecraft:stripped_oak_log
setblock 390 239 276 minecraft:stripped_oak_log
fill 390 239 277 390 240 277 minecraft:red_terracotta
fill 390 239 279 390 240 279 minecraft:stripped_oak_log
fill 391 239 276 391 240 276 minecraft:red_terracotta
fill 391 239 278 391 240 278 minecraft:stripped_oak_log
fill 392 239 277 392 240 277 minecraft:red_terracotta
fill 392 239 279 392 240 279 minecraft:stripped_oak_log
fill 393 239 276 393 240 276 minecraft:red_terracotta
setblock 393 239 278 minecraft:stripped_oak_log
setblock 394 239 277 minecraft:stripped_oak_log
fill 394 239 278 395 240 278 minecraft:red_terracotta
setblock 394 239 279 minecraft:stripped_oak_log
setblock 394 239 316 minecraft:red_terracotta
setblock 395 239 276 minecraft:stripped_oak_log
fill 395 239 277 396 240 277 minecraft:red_terracotta
fill 395 239 279 396 239 279 minecraft:red_terracotta
setblock 395 239 316 minecraft:stripped_oak_log
fill 396 239 276 397 240 276 minecraft:red_terracotta
fill 396 239 316 399 239 316 minecraft:red_terracotta
setblock 397 239 278 minecraft:red_terracotta
fill 397 239 279 397 239 280 minecraft:stripped_oak_log
fill 397 239 282 397 240 282 minecraft:stripped_oak_log
fill 397 239 315 400 239 315 minecraft:red_terracotta
setblock 398 239 277 minecraft:red_terracotta
setblock 398 239 278 minecraft:stripped_oak_log
fill 398 239 279 398 240 279 minecraft:red_terracotta
fill 398 239 281 398 240 281 minecraft:stripped_oak_log
setblock 399 239 276 minecraft:red_terracotta
setblock 399 239 277 minecraft:stripped_oak_log
fill 399 239 278 399 240 278 minecraft:red_terracotta
fill 399 239 280 399 240 280 minecraft:stripped_oak_log
fill 399 239 282 399 240 282 minecraft:stripped_oak_log
fill 400 239 275 402 239 275 minecraft:white_terracotta
setblock 400 239 276 minecraft:stripped_oak_log
fill 400 239 277 400 240 277 minecraft:red_terracotta
fill 400 239 279 400 240 279 minecraft:red_terracotta
fill 400 239 281 400 240 281 minecraft:stripped_oak_log
setblock 400 239 316 minecraft:stripped_oak_log
fill 401 239 276 401 240 276 minecraft:red_terracotta
fill 401 239 278 401 240 278 minecraft:red_terracotta
fill 401 239 280 401 240 280 minecraft:stripped_oak_log
fill 401 239 282 401 240 282 minecraft:stripped_oak_log
setblock 401 239 315 minecraft:stripped_oak_log
fill 401 239 316 404 239 316 minecraft:red_terracotta
fill 402 239 277 402 240 277 minecraft:red_terracotta
setblock 402 239 279 minecraft:stripped_oak_log
fill 402 239 281 402 240 281 minecraft:stripped_oak_log
fill 402 239 315 402 242 315 minecraft:red_terracotta
fill 403 239 276 404 239 276 minecraft:red_terracotta
setblock 403 239 278 minecraft:stripped_oak_log
fill 403 239 280 403 240 280 minecraft:stripped_oak_log
fill 403 239 282 403 240 282 minecraft:stripped_oak_log
setblock 404 239 277 minecraft:stripped_oak_log
fill 404 239 278 404 241 278 minecraft:red_terracotta
fill 404 239 315 404 240 315 minecraft:red_terracotta
setblock 405 239 276 minecraft:stripped_oak_log
fill 405 239 277 405 242 277 minecraft:red_terracotta
setblock 405 239 316 minecraft:stripped_oak_log
fill 406 239 276 406 242 276 minecraft:red_terracotta
fill 406 239 316 406 242 316 minecraft:red_terracotta
fill 409 239 294 409 240 294 minecraft:stripped_oak_log
fill 409 239 296 409 240 296 minecraft:stripped_oak_log
fill 409 239 298 409 240 298 minecraft:stripped_oak_log
fill 409 239 300 409 240 300 minecraft:stripped_oak_log
fill 409 239 302 409 240 302 minecraft:stripped_oak_log
fill 409 239 304 409 240 304 minecraft:stripped_oak_log
fill 409 239 306 409 240 306 minecraft:stripped_oak_log
fill 409 239 308 409 240 308 minecraft:stripped_oak_log
setblock 410 239 276 minecraft:stripped_oak_log
fill 410 239 295 410 240 295 minecraft:stripped_oak_log
fill 410 239 297 410 240 297 minecraft:stripped_oak_log
fill 410 239 299 410 240 299 minecraft:stripped_oak_log
fill 410 239 301 410 240 301 minecraft:stripped_oak_log
fill 410 239 303 410 240 303 minecraft:stripped_oak_log
fill 410 239 305 410 240 305 minecraft:stripped_oak_log
fill 410 239 307 410 240 307 minecraft:stripped_oak_log
setblock 410 239 316 minecraft:stripped_oak_log
fill 411 239 276 411 242 276 minecraft:red_terracotta
fill 411 239 294 411 240 294 minecraft:stripped_oak_log
fill 411 239 296 411 240 296 minecraft:stripped_oak_log
fill 411 239 298 411 240 298 minecraft:stripped_oak_log
fill 411 239 300 411 240 300 minecraft:stripped_oak_log
fill 411 239 302 411 240 302 minecraft:stripped_oak_log
fill 411 239 304 411 240 304 minecraft:stripped_oak_log
fill 411 239 306 411 240 306 minecraft:stripped_oak_log
fill 411 239 308 411 240 308 minecraft:stripped_oak_log
fill 411 239 316 411 242 316 minecraft:red_terracotta
fill 412 239 277 414 239 277 minecraft:stripped_oak_log
fill 412 239 295 412 240 295 minecraft:stripped_oak_log
fill 412 239 297 412 240 297 minecraft:stripped_oak_log
fill 412 239 299 412 240 299 minecraft:stripped_oak_log
fill 412 239 301 412 240 301 minecraft:stripped_oak_log
fill 412 239 303 412 240 303 minecraft:stripped_oak_log
fill 412 239 305 412 240 305 minecraft:stripped_oak_log
fill 412 239 307 412 240 307 minecraft:stripped_oak_log
fill 413 239 294 413 240 294 minecraft:stripped_oak_log
fill 413 239 296 413 240 296 minecraft:stripped_oak_log
fill 413 239 298 413 240 298 minecraft:stripped_oak_log
fill 413 239 300 413 240 300 minecraft:stripped_oak_log
fill 413 239 302 413 240 302 minecraft:stripped_oak_log
fill 413 239 304 413 240 304 minecraft:stripped_oak_log
fill 413 239 306 413 240 306 minecraft:stripped_oak_log
fill 413 239 308 413 240 308 minecraft:stripped_oak_log
fill 414 239 295 414 240 295 minecraft:stripped_oak_log
fill 414 239 297 414 240 297 minecraft:stripped_oak_log
fill 414 239 299 414 240 299 minecraft:stripped_oak_log
fill 414 239 301 415 239 301 minecraft:stripped_oak_log
fill 414 239 303 414 240 303 minecraft:stripped_oak_log
fill 414 239 305 414 240 305 minecraft:stripped_oak_log
fill 414 239 307 414 240 307 minecraft:stripped_oak_log
setblock 415 239 276 minecraft:stripped_oak_log
fill 415 239 277 416 241 277 minecraft:red_terracotta
fill 415 239 294 415 240 294 minecraft:stripped_oak_log
fill 415 239 296 415 240 296 minecraft:stripped_oak_log
fill 415 239 298 415 239 300 minecraft:red_terracotta
fill 415 239 302 415 240 304 minecraft:red_terracotta
setblock 415 239 306 minecraft:stripped_oak_log
fill 415 239 308 415 240 308 minecraft:stripped_oak_log
setblock 415 239 316 minecraft:stripped_oak_log
fill 416 239 276 416 242 276 minecraft:red_terracotta
fill 416 239 278 416 239 279 minecraft:red_terracotta
setblock 416 239 280 minecraft:stripped_oak_log
setblock 416 239 295 minecraft:stripped_oak_log
fill 416 239 296 416 240 297 minecraft:red_terracotta
setblock 416 239 299 minecraft:red_terracotta
setblock 416 239 300 minecraft:stripped_oak_log
fill 416 239 301 416 240 301 minecraft:red_terracotta
fill 416 239 303 416 240 303 minecraft:red_terracotta
setblock 416 239 305 minecraft:stripped_oak_log
fill 416 239 306 416 239 309 minecraft:red_terracotta
setblock 416 239 310 minecraft:stripped_oak_log
setblock 416 239 315 minecraft:stripped_oak_log
fill 416 239 316 416 242 316 minecraft:red_terracotta
setblock 417 239 278 minecraft:red_terracotta
setblock 417 239 279 minecraft:stripped_oak_log
fill 417 239 280 417 242 280 minecraft:red_terracotta
setblock 417 239 283 minecraft:red_terracotta
setblock 417 239 284 minecraft:stripped_oak_log
fill 417 239 285 417 242 285 minecraft:red_terracotta
fill 417 239 291 417 241 291 minecraft:red_terracotta
setblock 417 239 294 minecraft:stripped_oak_log
fill 417 239 295 417 240 296 minecraft:red_terracotta
fill 417 239 299 417 241 299 minecraft:shroomlight
fill 417 239 302 417 240 302 minecraft:red_terracotta
setblock 417 239 304 minecraft:stripped_oak_log
fill 417 239 305 417 240 306 minecraft:red_terracotta
setblock 417 239 308 minecraft:red_terracotta
setblock 417 239 309 minecraft:stripped_oak_log
fill 417 239 310 417 242 310 minecraft:red_terracotta
setblock 417 239 314 minecraft:stripped_oak_log
fill 417 239 315 417 242 315 minecraft:red_terracotta
fill 376 240 275 376 243 317 minecraft:terracotta
fill 377 240 275 418 242 275 minecraft:terracotta
setblock 377 240 277 minecraft:red_terracotta
setblock 377 240 278 minecraft:stripped_oak_log
fill 377 240 279 377 243 279 minecraft:red_terracotta
setblock 377 240 282 minecraft:red_terracotta
setblock 377 240 283 minecraft:stripped_oak_log
fill 377 240 284 377 240 287 minecraft:red_terracotta
setblock 377 240 288 minecraft:stripped_oak_log
fill 377 240 289 377 240 292 minecraft:red_terracotta
setblock 377 240 293 minecraft:stripped_oak_log
fill 377 240 294 377 240 297 minecraft:red_terracotta
setblock 377 240 298 minecraft:stripped_oak_log
fill 377 240 299 377 243 299 minecraft:red_terracotta
setblock 377 240 303 minecraft:stripped_oak_log
fill 377 240 304 377 243 304 minecraft:red_terracotta
setblock 377 240 307 minecraft:red_terracotta
setblock 377 240 308 minecraft:stripped_oak_log
fill 377 240 309 377 240 312 minecraft:red_terracotta
setblock 377 240 313 minecraft:stripped_oak_log
fill 377 240 314 377 243 314 minecraft:red_terracotta
fill 377 240 317 418 243 317 minecraft:terracotta
setblock 378 240 277 minecraft:stripped_oak_log
fill 378 240 278 378 243 278 minecraft:red_terracotta
setblock 378 240 282 minecraft:stripped_oak_log
fill 378 240 283 378 240 286 minecraft:red_terracotta
setblock 378 240 287 minecraft:stripped_oak_log
fill 378 240 288 378 243 288 minecraft:red_terracotta
setblock 378 240 292 minecraft:stripped_oak_log
fill 378 240 293 378 243 293 minecraft:red_terracotta
setblock 378 240 297 minecraft:stripped_oak_log
fill 378 240 298 378 243 298 minecraft:red_terracotta
setblock 378 240 302 minecraft:stripped_oak_log
fill 378 240 303 378 243 303 minecraft:red_terracotta
setblock 378 240 307 minecraft:stripped_oak_log
fill 378 240 308 378 243 308 minecraft:red_terracotta
setblock 378 240 316 minecraft:red_terracotta
setblock 379 240 276 minecraft:stripped_oak_log
fill 379 240 277 379 243 277 minecraft:red_terracotta
setblock 379 240 280 minecraft:red_terracotta
setblock 379 240 281 minecraft:stripped_oak_log
fill 379 240 282 379 240 285 minecraft:red_terracotta
setblock 379 240 286 minecraft:light[level=15]
setblock 379 240 292 minecraft:light[level=12]
setblock 379 240 296 minecraft:stripped_oak_log
fill 379 240 297 379 243 297 minecraft:red_terracotta
setblock 379 240 301 minecraft:stripped_oak_log
fill 379 240 302 379 243 302 minecraft:red_terracotta
setblock 379 240 306 minecraft:light[level=12]
setblock 379 240 310 minecraft:light[level=15]
setblock 379 240 313 minecraft:light[level=12]
setblock 379 240 316 minecraft:stripped_oak_log
fill 380 240 276 380 243 276 minecraft:red_terracotta
setblock 380 240 300 minecraft:stripped_oak_log
fill 380 240 301 380 242 301 minecraft:red_terracotta
fill 380 240 316 380 241 316 minecraft:red_terracotta
setblock 382 240 278 minecraft:stripped_oak_log
setblock 383 240 277 minecraft:stripped_oak_log
setblock 384 240 276 minecraft:stripped_oak_log
fill 384 240 277 384 243 277 minecraft:red_terracotta
fill 385 240 276 385 243 276 minecraft:red_terracotta
setblock 386 240 278 minecraft:light[level=12]
setblock 386 240 285 minecraft:light[level=12]
setblock 386 240 292 minecraft:light[level=12]
setblock 386 240 299 minecraft:light[level=12]
setblock 386 240 306 minecraft:light[level=12]
setblock 386 240 313 minecraft:light[level=12]
setblock 387 240 277 minecraft:red_terracotta
setblock 387 240 286 minecraft:light[level=15]
setblock 387 240 294 minecraft:light[level=15]
setblock 387 240 302 minecraft:light[level=15]
setblock 387 240 310 minecraft:light[level=15]
setblock 389 240 276 minecraft:stripped_oak_log
fill 389 240 277 389 243 277 minecraft:red_terracotta
fill 390 240 276 390 243 276 minecraft:red_terracotta
fill 391 240 300 394 245 302 minecraft:stripped_oak_log
setblock 393 240 277 minecraft:stripped_oak_log
setblock 393 240 278 minecraft:red_terracotta
setblock 393 240 285 minecraft:light[level=12]
setblock 393 240 292 minecraft:light[level=12]
setblock 393 240 306 minecraft:light[level=12]
setblock 393 240 313 minecraft:light[level=12]
setblock 393 240 316 minecraft:red_terracotta
setblock 394 240 276 minecraft:stripped_oak_log
setblock 394 240 277 minecraft:red_terracotta
fill 394 240 279 395 240 279 minecraft:red_terracotta
setblock 394 240 316 minecraft:stripped_oak_log
setblock 395 240 276 minecraft:red_terracotta
setblock 395 240 286 minecraft:light[level=15]
setblock 395 240 294 minecraft:light[level=15]
fill 395 240 301 395 256 302 minecraft:stripped_oak_log
setblock 395 240 310 minecraft:light[level=15]
fill 395 240 316 398 240 316 minecraft:red_terracotta
setblock 396 240 279 minecraft:stripped_oak_log
fill 396 240 315 399 240 315 minecraft:red_terracotta
setblock 397 240 278 minecraft:stripped_oak_log
fill 397 240 279 397 243 279 minecraft:red_terracotta
setblock 397 240 280 minecraft:stripped_oak_log
setblock 398 240 277 minecraft:stripped_oak_log
fill 398 240 278 398 243 278 minecraft:red_terracotta
setblock 399 240 276 minecraft:stripped_oak_log
fill 399 240 277 399 243 277 minecraft:red_terracotta
setblock 399 240 316 minecraft:stripped_oak_log
fill 400 240 276 400 243 276 minecraft:red_terracotta
setblock 400 240 285 minecraft:light[level=12]
setblock 400 240 292 minecraft:light[level=12]
setblock 400 240 299 minecraft:light[level=12]
setblock 400 240 306 minecraft:light[level=12]
setblock 400 240 313 minecraft:light[level=12]
setblock 400 240 315 minecraft:stripped_oak_log
fill 400 240 316 403 240 316 minecraft:red_terracotta
setblock 401 240 279 minecraft:stripped_oak_log
fill 401 240 315 401 243 315 minecraft:red_terracotta
setblock 402 240 278 minecraft:stripped_oak_log
setblock 402 240 279 minecraft:red_terracotta
setblock 403 240 276 minecraft:red_terracotta
setblock 403 240 277 minecraft:stripped_oak_log
setblock 403 240 278 minecraft:red_terracotta
setblock 403 240 286 minecraft:light[level=15]
setblock 403 240 294 minecraft:light[level=15]
setblock 403 240 302 minecraft:light[level=15]
setblock 403 240 310 minecraft:light[level=15]
setblock 404 240 276 minecraft:stripped_oak_log
fill 404 240 277 404 243 277 minecraft:red_terracotta
setblock 404 240 316 minecraft:stripped_oak_log
fill 405 240 276 405 243 276 minecraft:red_terracotta
fill 405 240 316 405 243 316 minecraft:red_terracotta
fill 407 240 277 407 242 277 minecraft:stripped_oak_log
setblock 407 240 285 minecraft:light[level=12]
setblock 407 240 292 minecraft:light[level=12]
setblock 407 240 299 minecraft:light[level=12]
setblock 407 240 306 minecraft:light[level=12]
setblock 407 240 313 minecraft:light[level=12]
setblock 409 240 276 minecraft:stripped_oak_log
setblock 409 240 316 minecraft:stripped_oak_log
fill 410 240 276 410 243 276 minecraft:red_terracotta
fill 410 240 316 410 243 316 minecraft:red_terracotta
setblock 411 240 286 minecraft:light[level=15]
setblock 411 240 310 minecraft:light[level=15]
fill 412 240 277 413 241 277 minecraft:stripped_oak_log
setblock 414 240 276 minecraft:stripped_oak_log
fill 414 240 277 414 243 277 minecraft:red_terracotta
setblock 414 240 285 minecraft:light[level=12]
setblock 414 240 292 minecraft:light[level=12]
setblock 414 240 301 minecraft:stripped_oak_log
setblock 414 240 313 minecraft:light[level=12]
setblock 414 240 316 minecraft:stripped_oak_log
fill 415 240 276 415 243 276 minecraft:red_terracotta
fill 415 240 297 415 240 299 minecraft:red_terracotta
setblock 415 240 300 minecraft:stripped_oak_log
fill 415 240 301 415 243 301 minecraft:red_terracotta
fill 415 240 306 416 240 307 minecraft:red_terracotta
setblock 415 240 315 minecraft:stripped_oak_log
fill 415 240 316 415 243 316 minecraft:red_terracotta
setblock 416 240 278 minecraft:red_terracotta
setblock 416 240 279 minecraft:stripped_oak_log
fill 416 240 280 416 241 282 minecraft:red_terracotta
setblock 416 240 295 minecraft:red_terracotta
setblock 416 240 299 minecraft:stripped_oak_log
fill 416 240 300 416 243 300 minecraft:red_terracotta
setblock 416 240 304 minecraft:stripped_oak_log
setblock 416 240 305 minecraft:red_terracotta
setblock 416 240 308 minecraft:red_terracotta
setblock 416 240 309 minecraft:stripped_oak_log
fill 416 240 310 416 240 313 minecraft:red_terracotta
setblock 416 240 314 minecraft:stripped_oak_log
fill 416 240 315 416 243 315 minecraft:red_terracotta
setblock 417 240 278 minecraft:stripped_oak_log
fill 417 240 279 417 243 279 minecraft:red_terracotta
setblock 417 240 283 minecraft:stripped_oak_log
fill 417 240 284 417 243 284 minecraft:red_terracotta
fill 417 240 286 417 240 287 minecraft:red_terracotta
setblock 417 240 288 minecraft:stripped_oak_log
fill 417 240 289 417 242 290 minecraft:red_terracotta
setblock 417 240 292 minecraft:red_terracotta
setblock 417 240 293 minecraft:stripped_oak_log
setblock 417 240 294 minecraft:red_terracotta
setblock 417 240 303 minecraft:stripped_oak_log
setblock 417 240 304 minecraft:red_terracotta
setblock 417 240 308 minecraft:stripped_oak_log
fill 417 240 309 417 243 309 minecraft:red_terracotta
setblock 417 240 313 minecraft:stripped_oak_log
fill 417 240 314 417 243 314 minecraft:red_terracotta
fill 418 240 276 418 243 316 minecraft:terracotta
setblock 377 241 277 minecraft:stripped_oak_log
fill 377 241 278 377 244 278 minecraft:red_terracotta
setblock 377 241 281 minecraft:red_terracotta
setblock 377 241 282 minecraft:stripped_oak_log
fill 377 241 283 377 241 286 minecraft:red_terracotta
setblock 377 241 287 minecraft:stripped_oak_log
fill 377 241 288 377 241 291 minecraft:red_terracotta
setblock 377 241 292 minecraft:stripped_oak_log
fill 377 241 293 377 241 296 minecraft:red_terracotta
setblock 377 241 297 minecraft:stripped_oak_log
fill 377 241 298 377 244 298 minecraft:red_terracotta
setblock 377 241 302 minecraft:stripped_oak_log
fill 377 241 303 377 244 303 minecraft:red_terracotta
setblock 377 241 306 minecraft:red_terracotta
setblock 377 241 307 minecraft:stripped_oak_log
fill 377 241 308 377 241 311 minecraft:red_terracotta
setblock 377 241 312 minecraft:stripped_oak_log
fill 377 241 313 377 244 313 minecraft:red_terracotta
setblock 378 241 276 minecraft:stripped_oak_log
fill 378 241 277 378 244 277 minecraft:red_terracotta
setblock 378 241 281 minecraft:stripped_oak_log
fill 378 241 282 378 241 285 minecraft:red_terracotta
setblock 378 241 286 minecraft:stripped_oak_log
fill 378 241 287 379 243 287 minecraft:red_terracotta
setblock 378 241 291 minecraft:stripped_oak_log
fill 378 241 292 379 242 292 minecraft:red_terracotta
setblock 378 241 296 minecraft:stripped_oak_log
fill 378 241 297 378 244 297 minecraft:red_terracotta
setblock 378 241 301 minecraft:stripped_oak_log
fill 378 241 302 378 244 302 minecraft:red_terracotta
setblock 378 241 306 minecraft:stripped_oak_log
fill 378 241 307 378 244 307 minecraft:red_terracotta
fill 378 241 309 378 242 309 minecraft:red_terracotta
setblock 378 241 316 minecraft:stripped_oak_log
fill 379 241 276 379 244 276 minecraft:red_terracotta
fill 379 241 278 380 241 278 minecraft:red_terracotta
setblock 379 241 280 minecraft:stripped_oak_log
fill 379 241 281 379 241 284 minecraft:red_terracotta
setblock 379 241 285 minecraft:stripped_oak_log
fill 379 241 286 379 244 286 minecraft:red_terracotta
fill 379 241 288 379 242 288 minecraft:red_terracotta
setblock 379 241 295 minecraft:stripped_oak_log
fill 379 241 296 379 244 296 minecraft:red_terracotta
setblock 379 241 300 minecraft:stripped_oak_log
fill 379 241 301 379 244 301 minecraft:red_terracotta
setblock 379 241 305 minecraft:stripped_oak_log
fill 379 241 306 379 244 306 minecraft:red_terracotta
fill 379 241 316 379 242 316 minecraft:red_terracotta
setblock 380 241 299 minecraft:stripped_oak_log
fill 380 241 300 380 242 300 minecraft:red_terracotta
setblock 380 241 303 minecraft:red_terracotta
setblock 381 241 278 minecraft:stripped_oak_log
setblock 382 241 277 minecraft:stripped_oak_log
fill 382 241 278 382 242 278 minecraft:red_terracotta
setblock 383 241 276 minecraft:stripped_oak_log
fill 383 241 277 383 243 277 minecraft:red_terracotta
fill 384 241 276 384 244 276 minecraft:red_terracotta
fill 386 241 276 386 242 276 minecraft:red_terracotta
setblock 387 241 276 minecraft:shroomlight
setblock 387 241 277 minecraft:stripped_oak_log
setblock 387 241 278 minecraft:shroomlight
setblock 388 241 276 minecraft:stripped_oak_log
setblock 388 241 277 minecraft:shroomlight
setblock 388 241 279 minecraft:shroomlight
setblock 389 241 276 minecraft:shroomlight
setblock 389 241 278 minecraft:shroomlight
setblock 390 241 277 minecraft:shroomlight
setblock 390 241 279 minecraft:shroomlight
setblock 391 241 276 minecraft:shroomlight
setblock 391 241 278 minecraft:shroomlight
setblock 392 241 277 minecraft:shroomlight
fill 392 241 278 392 244 278 minecraft:red_terracotta
setblock 392 241 279 minecraft:shroomlight
setblock 393 241 276 minecraft:shroomlight
fill 393 241 277 393 244 277 minecraft:red_terracotta
setblock 393 241 278 minecraft:shroomlight
fill 393 241 279 393 242 279 minecraft:red_terracotta
setblock 393 241 316 minecraft:stripped_oak_log
fill 394 241 276 394 244 276 minecraft:red_terracotta
setblock 394 241 277 minecraft:shroomlight
fill 394 241 278 394 242 278 minecraft:red_terracotta
setblock 394 241 279 minecraft:shroomlight
fill 394 241 316 397 241 316 minecraft:red_terracotta
setblock 395 241 276 minecraft:shroomlight
fill 395 241 277 395 242 277 minecraft:red_terracotta
setblock 395 241 278 minecraft:shroomlight
setblock 395 241 279 minecraft:stripped_oak_log
fill 396 241 276 396 242 276 minecraft:red_terracotta
setblock 396 241 277 minecraft:shroomlight
setblock 396 241 278 minecraft:stripped_oak_log
setblock 396 241 279 minecraft:shroomlight
fill 396 241 315 398 241 315 minecraft:red_terracotta
setblock 397 241 276 minecraft:shroomlight
setblock 397 241 277 minecraft:stripped_oak_log
setblock 397 241 278 minecraft:shroomlight
setblock 397 241 280 minecraft:shroomlight
setblock 397 241 282 minecraft:shroomlight
setblock 398 241 276 minecraft:stripped_oak_log
setblock 398 241 277 minecraft:shroomlight
setblock 398 241 279 minecraft:shroomlight
setblock 398 241 280 minecraft:red_terracotta
setblock 398 241 281 minecraft:shroomlight
setblock 398 241 316 minecraft:stripped_oak_log
setblock 399 241 276 minecraft:shroomlight
setblock 399 241 278 minecraft:shroomlight
setblock 399 241 280 minecraft:shroomlight
setblock 399 241 282 minecraft:shroomlight
setblock 399 241 315 minecraft:stripped_oak_log
fill 399 241 316 402 241 316 minecraft:red_terracotta
setblock 400 241 277 minecraft:shroomlight
setblock 400 241 279 minecraft:shroomlight
setblock 400 241 281 minecraft:shroomlight
fill 400 241 315 400 244 315 minecraft:red_terracotta
setblock 401 241 276 minecraft:shroomlight
setblock 401 241 278 minecraft:shroomlight
fill 401 241 279 401 242 279 minecraft:red_terracotta
setblock 401 241 280 minecraft:shroomlight
setblock 401 241 282 minecraft:shroomlight
setblock 402 241 277 minecraft:shroomlight
fill 402 241 278 402 243 278 minecraft:red_terracotta
setblock 402 241 279 minecraft:shroomlight
setblock 402 241 281 minecraft:shroomlight
setblock 403 241 276 minecraft:shroomlight
fill 403 241 277 403 244 277 minecraft:red_terracotta
setblock 403 241 278 minecraft:shroomlight
setblock 403 241 280 minecraft:shroomlight
setblock 403 241 282 minecraft:shroomlight
setblock 403 241 316 minecraft:stripped_oak_log
fill 404 241 276 404 244 276 minecraft:red_terracotta
fill 404 241 316 404 244 316 minecraft:red_terracotta
setblock 408 241 276 minecraft:stripped_oak_log
setblock 408 241 316 minecraft:stripped_oak_log
fill 409 241 276 409 243 276 minecraft:red_terracotta
setblock 409 241 294 minecraft:shroomlight
setblock 409 241 296 minecraft:shroomlight
setblock 409 241 298 minecraft:shroomlight
setblock 409 241 300 minecraft:shroomlight
setblock 409 241 302 minecraft:shroomlight
setblock 409 241 304 minecraft:shroomlight
setblock 409 241 306 minecraft:shroomlight
setblock 409 241 308 minecraft:shroomlight
fill 409 241 316 409 244 316 minecraft:red_terracotta
setblock 410 241 295 minecraft:shroomlight
setblock 410 241 297 minecraft:shroomlight
setblock 410 241 299 minecraft:shroomlight
setblock 410 241 301 minecraft:shroomlight
setblock 410 241 303 minecraft:shroomlight
setblock 410 241 305 minecraft:shroomlight
setblock 410 241 307 minecraft:shroomlight
setblock 411 241 294 minecraft:shroomlight
setblock 411 241 296 minecraft:shroomlight
setblock 411 241 298 minecraft:shroomlight
setblock 411 241 300 minecraft:shroomlight
setblock 411 241 302 minecraft:shroomlight
setblock 411 241 304 minecraft:shroomlight
setblock 411 241 306 minecraft:shroomlight
setblock 411 241 308 minecraft:shroomlight
setblock 412 241 295 minecraft:shroomlight
setblock 412 241 297 minecraft:shroomlight
setblock 412 241 299 minecraft:shroomlight
setblock 412 241 301 minecraft:shroomlight
setblock 412 241 303 minecraft:shroomlight
setblock 412 241 305 minecraft:shroomlight
setblock 412 241 307 minecraft:shroomlight
setblock 413 241 276 minecraft:stripped_oak_log
setblock 413 241 294 minecraft:shroomlight
setblock 413 241 296 minecraft:shroomlight
setblock 413 241 298 minecraft:shroomlight
setblock 413 241 300 minecraft:shroomlight
setblock 413 241 302 minecraft:shroomlight
setblock 413 241 304 minecraft:shroomlight
setblock 413 241 306 minecraft:shroomlight
setblock 413 241 308 minecraft:shroomlight
setblock 413 241 316 minecraft:stripped_oak_log
fill 414 241 276 414 244 276 minecraft:red_terracotta
setblock 414 241 295 minecraft:shroomlight
setblock 414 241 297 minecraft:shroomlight
setblock 414 241 299 minecraft:shroomlight
setblock 414 241 301 minecraft:shroomlight
fill 414 241 302 414 243 302 minecraft:red_terracotta
setblock 414 241 303 minecraft:shroomlight
setblock 414 241 304 minecraft:red_terracotta
setblock 414 241 305 minecraft:shroomlight
setblock 414 241 307 minecraft:shroomlight
fill 414 241 316 414 244 316 minecraft:red_terracotta
setblock 415 241 294 minecraft:shroomlight
setblock 415 241 296 minecraft:shroomlight
fill 415 241 297 415 242 297 minecraft:red_terracotta
setblock 415 241 298 minecraft:shroomlight
setblock 415 241 299 minecraft:stripped_oak_log
setblock 415 241 300 minecraft:shroomlight
setblock 415 241 302 minecraft:shroomlight
setblock 415 241 303 minecraft:red_terracotta
setblock 415 241 304 minecraft:shroomlight
fill 415 241 305 415 244 305 minecraft:red_terracotta
setblock 415 241 306 minecraft:shroomlight
fill 415 241 307 415 242 307 minecraft:red_terracotta
setblock 415 241 308 minecraft:shroomlight
fill 415 241 315 415 244 315 minecraft:red_terracotta
setblock 416 241 278 minecraft:stripped_oak_log
fill 416 241 279 416 244 279 minecraft:red_terracotta
setblock 416 241 283 minecraft:stripped_oak_log
fill 416 241 284 416 244 284 minecraft:red_terracotta
fill 416 241 294 416 244 294 minecraft:red_terracotta
setblock 416 241 295 minecraft:shroomlight
fill 416 241 296 416 242 296 minecraft:red_terracotta
setblock 416 241 297 minecraft:shroomlight
setblock 416 241 298 minecraft:stripped_oak_log
setblock 416 241 299 minecraft:shroomlight
setblock 416 241 301 minecraft:shroomlight
setblock 416 241 303 minecraft:shroomlight
fill 416 241 304 416 244 304 minecraft:red_terracotta
setblock 416 241 305 minecraft:shroomlight
fill 416 241 306 416 242 306 minecraft:red_terracotta
setblock 416 241 307 minecraft:shroomlight
setblock 416 241 308 minecraft:stripped_oak_log
fill 416 241 309 416 241 312 minecraft:red_terracotta
setblock 416 241 313 minecraft:stripped_oak_log
fill 416 241 314 416 244 314 minecraft:red_terracotta
setblock 417 241 277 minecraft:stripped_oak_log
fill 417 241 278 417 244 278 minecraft:red_terracotta
setblock 417 241 281 minecraft:red_terracotta
setblock 417 241 282 minecraft:stripped_oak_log
fill 417 241 283 417 244 283 minecraft:red_terracotta
setblock 417 241 286 minecraft:red_terracotta
setblock 417 241 287 minecraft:stripped_oak_log
fill 417 241 288 417 244 288 minecraft:red_terracotta
setblock 417 241 292 minecraft:stripped_oak_log
fill 417 241 293 417 244 293 minecraft:red_terracotta
setblock 417 241 294 minecraft:shroomlight
fill 417 241 295 417 242 295 minecraft:red_terracotta
setblock 417 241 296 minecraft:shroomlight
setblock 417 241 297 minecraft:stripped_oak_log
setblock 417 241 302 minecraft:shroomlight
fill 417 241 303 417 244 303 minecraft:red_terracotta
setblock 417 241 304 minecraft:shroomlight
fill 417 241 305 417 242 305 minecraft:red_terracotta
setblock 417 241 306 minecraft:shroomlight
setblock 417 241 307 minecraft:stripped_oak_log
setblock 417 241 308 minecraft:shroomlight
setblock 417 241 312 minecraft:stripped_oak_log
fill 417 241 313 417 244 313 minecraft:red_terracotta
setblock 377 242 276 minecraft:stripped_oak_log
fill 377 242 277 377 245 277 minecraft:red_terracotta
setblock 377 242 281 minecraft:stripped_oak_log
fill 377 242 282 377 242 285 minecraft:red_terracotta
setblock 377 242 286 minecraft:stripped_oak_log
fill 377 242 287 377 242 290 minecraft:red_terracotta
setblock 377 242 291 minecraft:stripped_oak_log
fill 377 242 292 377 242 295 minecraft:red_terracotta
setblock 377 242 296 minecraft:stripped_oak_log
fill 377 242 297 377 245 297 minecraft:red_terracotta
setblock 377 242 301 minecraft:stripped_oak_log
fill 377 242 302 377 245 302 minecraft:red_terracotta
setblock 377 242 306 minecraft:stripped_oak_log
fill 377 242 307 377 242 310 minecraft:red_terracotta
setblock 377 242 311 minecraft:stripped_oak_log
fill 377 242 312 377 245 312 minecraft:red_terracotta
setblock 377 242 315 minecraft:red_terracotta
setblock 377 242 316 minecraft:stripped_oak_log
fill 378 242 276 378 245 276 minecraft:red_terracotta
setblock 378 242 279 minecraft:red_terracotta
setblock 378 242 280 minecraft:stripped_oak_log
fill 378 242 281 378 242 284 minecraft:red_terracotta
setblock 378 242 285 minecraft:stripped_oak_log
fill 378 242 286 378 245 286 minecraft:red_terracotta
setblock 378 242 290 minecraft:stripped_oak_log
fill 378 242 291 379 243 291 minecraft:red_terracotta
setblock 378 242 295 minecraft:stripped_oak_log
fill 378 242 296 378 245 296 minecraft:red_terracotta
setblock 378 242 300 minecraft:stripped_oak_log
fill 378 242 301 378 245 301 minecraft:red_terracotta
setblock 378 242 305 minecraft:stripped_oak_log
fill 378 242 306 378 245 306 minecraft:red_terracotta
fill 378 242 316 378 243 316 minecraft:red_terracotta
setblock 379 242 278 minecraft:red_terracotta
setblock 379 242 279 minecraft:stripped_oak_log
fill 379 242 280 379 242 283 minecraft:red_terracotta
setblock 379 242 284 minecraft:stripped_oak_log
fill 379 242 285 379 245 285 minecraft:red_terracotta
setblock 379 242 289 minecraft:stripped_oak_log
fill 379 242 290 379 245 290 minecraft:red_terracotta
setblock 379 242 294 minecraft:stripped_oak_log
fill 379 242 295 379 243 295 minecraft:red_terracotta
setblock 379 242 299 minecraft:stripped_oak_log
fill 379 242 300 379 245 300 minecraft:red_terracotta
setblock 379 242 304 minecraft:stripped_oak_log
fill 379 242 305 379 245 305 minecraft:red_terracotta
setblock 380 242 278 minecraft:stripped_oak_log
fill 380 242 281 380 242 282 minecraft:red_terracotta
setblock 380 242 283 minecraft:stripped_oak_log
setblock 380 242 299 minecraft:red_terracotta
setblock 380 242 303 minecraft:stripped_oak_log
setblock 381 242 277 minecraft:stripped_oak_log
fill 381 242 278 381 243 278 minecraft:red_terracotta
setblock 382 242 276 minecraft:stripped_oak_log
fill 382 242 277 382 244 277 minecraft:red_terracotta
fill 383 242 276 383 244 276 minecraft:red_terracotta
setblock 385 242 277 minecraft:red_terracotta
setblock 386 242 277 minecraft:stripped_oak_log
setblock 387 242 276 minecraft:stripped_oak_log
fill 387 242 277 388 243 277 minecraft:red_terracotta
fill 387 242 278 387 243 278 minecraft:stripped_oak_log
fill 388 242 276 389 243 276 minecraft:red_terracotta
fill 388 242 279 388 243 279 minecraft:stripped_oak_log
fill 389 242 278 389 243 278 minecraft:stripped_oak_log
setblock 390 242 277 minecraft:red_terracotta
fill 390 242 279 390 243 279 minecraft:stripped_oak_log
setblock 391 242 276 minecraft:red_terracotta
setblock 391 242 277 minecraft:stripped_oak_log
fill 391 242 278 391 243 278 minecraft:red_terracotta
setblock 392 242 276 minecraft:stripped_oak_log
fill 392 242 277 392 243 277 minecraft:red_terracotta
fill 392 242 279 392 243 279 minecraft:red_terracotta
setblock 392 242 316 minecraft:stripped_oak_log
fill 393 242 276 393 243 276 minecraft:red_terracotta
fill 393 242 278 393 243 278 minecraft:red_terracotta
fill 393 242 316 396 242 316 minecraft:red_terracotta
fill 394 242 277 394 243 277 minecraft:red_terracotta
setblock 394 242 279 minecraft:stripped_oak_log
fill 395 242 276 395 243 276 minecraft:red_terracotta
setblock 395 242 278 minecraft:stripped_oak_log
fill 395 242 279 396 243 279 minecraft:red_terracotta
fill 395 242 315 397 242 315 minecraft:red_terracotta
setblock 396 242 277 minecraft:stripped_oak_log
fill 396 242 278 397 243 278 minecraft:red_terracotta
fill 396 242 280 397 242 280 minecraft:red_terracotta
setblock 397 242 276 minecraft:stripped_oak_log
fill 397 242 277 398 243 277 minecraft:red_terracotta
fill 397 242 282 397 243 282 minecraft:stripped_oak_log
setblock 397 242 316 minecraft:stripped_oak_log
fill 398 242 276 399 243 276 minecraft:red_terracotta
setblock 398 242 279 minecraft:red_terracotta
fill 398 242 280 398 243 281 minecraft:stripped_oak_log
setblock 398 242 315 minecraft:stripped_oak_log
fill 398 242 316 401 242 316 minecraft:red_terracotta
setblock 399 242 278 minecraft:red_terracotta
fill 399 242 279 399 242 280 minecraft:stripped_oak_log
fill 399 242 282 399 243 282 minecraft:stripped_oak_log
fill 399 242 315 399 245 315 minecraft:red_terracotta
setblock 400 242 277 minecraft:red_terracotta
setblock 400 242 278 minecraft:stripped_oak_log
fill 400 242 279 400 243 279 minecraft:red_terracotta
fill 400 242 281 400 243 281 minecraft:stripped_oak_log
setblock 401 242 276 minecraft:red_terracotta
setblock 401 242 277 minecraft:stripped_oak_log
fill 401 242 278 401 243 278 minecraft:red_terracotta
fill 401 242 280 401 243 280 minecraft:stripped_oak_log
fill 401 242 282 401 243 282 minecraft:stripped_oak_log
setblock 402 242 276 minecraft:stripped_oak_log
fill 402 242 277 402 243 277 minecraft:red_terracotta
fill 402 242 279 408 242 279 minecraft:stripped_oak_log
fill 402 242 281 408 242 281 minecraft:stripped_oak_log
setblock 402 242 316 minecraft:stripped_oak_log
fill 403 242 276 403 243 276 minecraft:red_terracotta
setblock 403 242 278 minecraft:red_terracotta
fill 403 242 280 408 242 280 minecraft:stripped_oak_log
fill 403 242 282 403 243 282 minecraft:stripped_oak_log
setblock 403 242 315 minecraft:stripped_oak_log
fill 403 242 316 403 245 316 minecraft:red_terracotta
setblock 404 242 278 minecraft:stripped_oak_log
setblock 406 242 277 minecraft:stripped_oak_log
setblock 407 242 276 minecraft:stripped_oak_log
setblock 407 242 316 minecraft:stripped_oak_log
fill 408 242 276 408 243 276 minecraft:red_terracotta
setblock 408 242 278 minecraft:stripped_oak_log
fill 408 242 316 408 243 316 minecraft:red_terracotta
fill 409 242 294 409 243 294 minecraft:stripped_oak_log
fill 409 242 296 409 243 296 minecraft:stripped_oak_log
fill 409 242 298 409 243 298 minecraft:stripped_oak_log
fill 409 242 300 409 243 300 minecraft:stripped_oak_log
fill 409 242 302 409 243 302 minecraft:stripped_oak_log
fill 409 242 304 409 243 304 minecraft:stripped_oak_log
fill 409 242 306 409 243 306 minecraft:stripped_oak_log
fill 409 242 308 409 243 308 minecraft:stripped_oak_log
fill 410 242 295 410 243 295 minecraft:stripped_oak_log
fill 410 242 297 410 243 297 minecraft:stripped_oak_log
fill 410 242 299 410 243 299 minecraft:stripped_oak_log
fill 410 242 301 410 243 301 minecraft:stripped_oak_log
fill 410 242 303 410 243 303 minecraft:stripped_oak_log
fill 410 242 305 410 243 305 minecraft:stripped_oak_log
fill 410 242 307 410 243 307 minecraft:stripped_oak_log
fill 411 242 294 411 243 294 minecraft:stripped_oak_log
fill 411 242 296 411 243 296 minecraft:stripped_oak_log
fill 411 242 298 411 243 298 minecraft:stripped_oak_log
fill 411 242 300 411 243 300 minecraft:stripped_oak_log
fill 411 242 302 411 243 302 minecraft:stripped_oak_log
fill 411 242 304 411 243 304 minecraft:stripped_oak_log
fill 411 242 306 411 243 306 minecraft:stripped_oak_log
fill 411 242 308 411 243 308 minecraft:stripped_oak_log
setblock 412 242 276 minecraft:stripped_oak_log
fill 412 242 295 412 243 295 minecraft:stripped_oak_log
fill 412 242 297 412 243 297 minecraft:stripped_oak_log
fill 412 242 299 412 243 299 minecraft:stripped_oak_log
fill 412 242 301 412 243 301 minecraft:stripped_oak_log
fill 412 242 303 412 243 303 minecraft:stripped_oak_log
fill 412 242 305 412 243 305 minecraft:stripped_oak_log
fill 412 242 307 412 243 307 minecraft:stripped_oak_log
setblock 412 242 316 minecraft:stripped_oak_log
fill 413 242 276 413 245 276 minecraft:red_terracotta
fill 413 242 294 413 243 294 minecraft:stripped_oak_log
fill 413 242 296 413 243 296 minecraft:stripped_oak_log
fill 413 242 298 413 243 298 minecraft:stripped_oak_log
fill 413 242 300 413 243 300 minecraft:stripped_oak_log
fill 413 242 302 413 243 302 minecraft:stripped_oak_log
fill 413 242 304 414 242 304 minecraft:stripped_oak_log
fill 413 242 306 413 243 306 minecraft:stripped_oak_log
fill 413 242 308 413 243 308 minecraft:stripped_oak_log
fill 413 242 316 413 245 316 minecraft:red_terracotta
fill 414 242 295 414 243 295 minecraft:stripped_oak_log
fill 414 242 297 414 243 297 minecraft:stripped_oak_log
fill 414 242 299 414 243 299 minecraft:stripped_oak_log
fill 414 242 300 414 243 301 minecraft:red_terracotta
setblock 414 242 303 minecraft:red_terracotta
fill 414 242 305 414 243 306 minecraft:red_terracotta
setblock 414 242 307 minecraft:stripped_oak_log
fill 414 242 315 414 244 315 minecraft:red_terracotta
setblock 415 242 277 minecraft:red_terracotta
fill 415 242 294 415 243 294 minecraft:stripped_oak_log
fill 415 242 296 415 243 296 minecraft:stripped_oak_log
setblock 415 242 298 minecraft:stripped_oak_log
fill 415 242 299 415 243 300 minecraft:red_terracotta
setblock 415 242 302 minecraft:red_terracotta
setblock 415 242 303 minecraft:stripped_oak_log
fill 415 242 304 415 243 304 minecraft:red_terracotta
fill 415 242 306 415 243 306 minecraft:red_terracotta
setblock 415 242 308 minecraft:stripped_oak_log
fill 415 242 309 416 243 310 minecraft:red_terracotta
setblock 416 242 277 minecraft:stripped_oak_log
fill 416 242 278 416 245 278 minecraft:red_terracotta
fill 416 242 280 416 242 281 minecraft:red_terracotta
setblock 416 242 282 minecraft:stripped_oak_log
fill 416 242 283 416 245 283 minecraft:red_terracotta
fill 416 242 285 416 242 286 minecraft:red_terracotta
setblock 416 242 287 minecraft:stripped_oak_log
fill 416 242 293 416 245 293 minecraft:red_terracotta
fill 416 242 295 416 243 295 minecraft:red_terracotta
setblock 416 242 297 minecraft:stripped_oak_log
fill 416 242 298 417 243 299 minecraft:red_terracotta
setblock 416 242 301 minecraft:red_terracotta
setblock 416 242 302 minecraft:stripped_oak_log
fill 416 242 303 416 243 303 minecraft:red_terracotta
fill 416 242 305 416 243 305 minecraft:red_terracotta
setblock 416 242 307 minecraft:stripped_oak_log
fill 416 242 308 417 243 308 minecraft:red_terracotta
setblock 416 242 311 minecraft:red_terracotta
setblock 416 242 312 minecraft:stripped_oak_log
fill 416 242 313 416 245 313 minecraft:red_terracotta
setblock 417 242 276 minecraft:stripped_oak_log
fill 417 242 277 417 245 277 minecraft:red_terracotta
setblock 417 242 281 minecraft:stripped_oak_log
fill 417 242 282 417 245 282 minecraft:red_terracotta
setblock 417 242 286 minecraft:stripped_oak_log
fill 417 242 287 417 245 287 minecraft:red_terracotta
setblock 417 242 291 minecraft:stripped_oak_log
fill 417 242 292 417 245 292 minecraft:red_terracotta
fill 417 242 294 417 243 294 minecraft:red_terracotta
setblock 417 242 296 minecraft:stripped_oak_log
fill 417 242 297 417 245 297 minecraft:red_terracotta
setblock 417 242 300 minecraft:red_terracotta
setblock 417 242 301 minecraft:stripped_oak_log
fill 417 242 302 417 243 302 minecraft:red_terracotta
fill 417 242 304 417 243 304 minecraft:red_terracotta
setblock 417 242 306 minecraft:stripped_oak_log
fill 417 242 307 417 245 307 minecraft:red_terracotta
setblock 417 242 311 minecraft:stripped_oak_log
fill 417 242 312 417 245 312 minecraft:red_terracotta
setblock 417 242 316 minecraft:stripped_oak_log
fill 377 243 275 403 243 275 minecraft:terracotta
fill 377 243 276 377 246 276 minecraft:red_terracotta
setblock 377 243 280 minecraft:stripped_oak_log
fill 377 243 281 377 243 284 minecraft:red_terracotta
setblock 377 243 285 minecraft:stripped_oak_log
fill 377 243 286 377 243 289 minecraft:red_terracotta
setblock 377 243 290 minecraft:stripped_oak_log
fill 377 243 291 377 243 294 minecraft:red_terracotta
setblock 377 243 295 minecraft:stripped_oak_log
fill 377 243 296 377 246 296 minecraft:red_terracotta
setblock 377 243 300 minecraft:stripped_oak_log
fill 377 243 301 377 246 301 minecraft:red_terracotta
setblock 377 243 305 minecraft:stripped_oak_log
fill 377 243 306 377 243 309 minecraft:red_terracotta
setblock 377 243 310 minecraft:stripped_oak_log
fill 377 243 311 377 246 311 minecraft:red_terracotta
setblock 377 243 315 minecraft:stripped_oak_log
fill 377 243 316 377 244 316 minecraft:red_terracotta
setblock 378 243 279 minecraft:stripped_oak_log
fill 378 243 280 378 243 283 minecraft:red_terracotta
setblock 378 243 284 minecraft:stripped_oak_log
fill 378 243 285 378 246 285 minecraft:red_terracotta
setblock 378 243 289 minecraft:stripped_oak_log
fill 378 243 290 378 246 290 minecraft:red_terracotta
fill 378 243 292 378 244 292 minecraft:red_terracotta
setblock 378 243 294 minecraft:stripped_oak_log
fill 378 243 295 378 246 295 minecraft:red_terracotta
setblock 378 243 299 minecraft:stripped_oak_log
fill 378 243 300 378 246 300 minecraft:red_terracotta
setblock 378 243 304 minecraft:stripped_oak_log
fill 378 243 305 378 246 305 minecraft:red_terracotta
setblock 378 243 309 minecraft:stripped_oak_log
fill 378 243 310 378 244 310 minecraft:red_terracotta
setblock 379 243 278 minecraft:stripped_oak_log
fill 379 243 279 379 243 282 minecraft:red_terracotta
setblock 379 243 283 minecraft:stripped_oak_log
fill 379 243 284 380 244 284 minecraft:red_terracotta
setblock 379 243 288 minecraft:stripped_oak_log
fill 379 243 289 379 246 289 minecraft:red_terracotta
setblock 379 243 293 minecraft:stripped_oak_log
setblock 379 243 294 minecraft:red_terracotta
setblock 379 243 298 minecraft:stripped_oak_log
fill 379 243 299 379 245 299 minecraft:red_terracotta
setblock 379 243 303 minecraft:stripped_oak_log
fill 379 243 304 379 245 304 minecraft:red_terracotta
setblock 379 243 307 minecraft:red_terracotta
setblock 380 243 277 minecraft:stripped_oak_log
setblock 380 243 278 minecraft:red_terracotta
setblock 380 243 281 minecraft:red_terracotta
setblock 380 243 282 minecraft:stripped_oak_log
fill 380 243 283 380 244 283 minecraft:red_terracotta
fill 380 243 285 380 244 285 minecraft:red_terracotta
setblock 381 243 276 minecraft:stripped_oak_log
fill 381 243 277 381 244 277 minecraft:red_terracotta
fill 382 243 276 382 245 276 minecraft:red_terracotta
setblock 386 243 276 minecraft:stripped_oak_log
setblock 387 243 276 minecraft:red_terracotta
setblock 390 243 277 minecraft:stripped_oak_log
fill 390 243 278 390 244 278 minecraft:red_terracotta
setblock 391 243 276 minecraft:stripped_oak_log
fill 391 243 277 391 246 277 minecraft:red_terracotta
fill 392 243 276 392 246 276 minecraft:red_terracotta
fill 392 243 316 395 243 316 minecraft:red_terracotta
setblock 393 243 279 minecraft:stripped_oak_log
setblock 394 243 278 minecraft:stripped_oak_log
setblock 394 243 279 minecraft:red_terracotta
setblock 395 243 277 minecraft:stripped_oak_log
setblock 395 243 278 minecraft:red_terracotta
fill 395 243 280 396 243 280 minecraft:red_terracotta
fill 395 243 315 396 243 315 minecraft:red_terracotta
setblock 396 243 276 minecraft:stripped_oak_log
setblock 396 243 277 minecraft:red_terracotta
setblock 396 243 316 minecraft:stripped_oak_log
setblock 397 243 276 minecraft:red_terracotta
setblock 397 243 280 minecraft:stripped_oak_log
setblock 397 243 315 minecraft:stripped_oak_log
fill 397 243 316 400 243 316 minecraft:red_terracotta
setblock 398 243 279 minecraft:stripped_oak_log
fill 398 243 315 398 246 315 minecraft:red_terracotta
setblock 399 243 278 minecraft:stripped_oak_log
fill 399 243 279 399 244 279 minecraft:red_terracotta
setblock 399 243 280 minecraft:stripped_oak_log
setblock 400 243 277 minecraft:stripped_oak_log
fill 400 243 278 400 244 278 minecraft:red_terracotta
setblock 401 243 276 minecraft:stripped_oak_log
fill 401 243 277 401 245 277 minecraft:red_terracotta
fill 401 243 279 403 243 279 minecraft:stripped_oak_log
setblock 401 243 316 minecraft:stripped_oak_log
fill 402 243 276 402 246 276 minecraft:red_terracotta
fill 402 243 281 403 243 281 minecraft:stripped_oak_log
setblock 402 243 315 minecraft:stripped_oak_log
fill 402 243 316 402 246 316 minecraft:red_terracotta
setblock 403 243 278 minecraft:stripped_oak_log
setblock 403 243 280 minecraft:stripped_oak_log
fill 404 243 275 406 246 275 minecraft:shroomlight
fill 404 243 281 408 243 281 minecraft:orange_terracotta
setblock 406 243 276 minecraft:stripped_oak_log
setblock 406 243 316 minecraft:stripped_oak_log
fill 407 243 275 418 243 275 minecraft:terracotta
setblock 407 243 276 minecraft:red_terracotta
setblock 407 243 316 minecraft:red_terracotta
setblock 411 243 276 minecraft:stripped_oak_log
setblock 411 243 316 minecraft:stripped_oak_log
fill 412 243 276 412 245 276 minecraft:red_terracotta
fill 412 243 316 412 246 316 minecraft:red_terracotta
setblock 413 243 304 minecraft:stripped_oak_log
setblock 414 243 303 minecraft:stripped_oak_log
fill 414 243 304 414 246 304 minecraft:red_terracotta
setblock 414 243 307 minecraft:red_terracotta
setblock 415 243 277 minecraft:stripped_oak_log
setblock 415 243 297 minecraft:stripped_oak_log
setblock 415 243 298 minecraft:red_terracotta
setblock 415 243 302 minecraft:stripped_oak_log
fill 415 243 303 415 246 303 minecraft:red_terracotta
setblock 415 243 307 minecraft:stripped_oak_log
setblock 415 243 308 minecraft:red_terracotta
setblock 416 243 276 minecraft:stripped_oak_log
fill 416 243 277 416 244 277 minecraft:red_terracotta
setblock 416 243 280 minecraft:red_terracotta
setblock 416 243 281 minecraft:stripped_oak_log
fill 416 243 282 416 246 282 minecraft:red_terracotta
setblock 416 243 285 minecraft:red_terracotta
setblock 416 243 286 minecraft:stripped_oak_log
fill 416 243 287 416 243 290 minecraft:red_terracotta
setblock 416 243 291 minecraft:stripped_oak_log
fill 416 243 292 416 246 292 minecraft:red_terracotta
setblock 416 243 296 minecraft:stripped_oak_log
setblock 416 243 297 minecraft:red_terracotta
setblock 416 243 301 minecraft:stripped_oak_log
fill 416 243 302 416 246 302 minecraft:red_terracotta
setblock 416 243 306 minecraft:stripped_oak_log
setblock 416 243 307 minecraft:red_terracotta
setblock 416 243 311 minecraft:stripped_oak_log
fill 416 243 312 416 246 312 minecraft:red_terracotta
setblock 416 243 316 minecraft:stripped_oak_log
fill 417 243 276 417 245 276 minecraft:red_terracotta
setblock 417 243 280 minecraft:stripped_oak_log
fill 417 243 281 417 246 281 minecraft:red_terracotta
setblock 417 243 285 minecraft:stripped_oak_log
fill 417 243 286 417 246 286 minecraft:red_terracotta
setblock 417 243 289 minecraft:red_terracotta
setblock 417 243 290 minecraft:stripped_oak_log
fill 417 243 291 417 246 291 minecraft:red_terracotta
setblock 417 243 295 minecraft:stripped_oak_log
setblock 417 243 296 minecraft:red_terracotta
setblock 417 243 300 minecraft:stripped_oak_log
fill 417 243 301 417 246 301 minecraft:red_terracotta
setblock 417 243 305 minecraft:stripped_oak_log
setblock 417 243 306 minecraft:red_terracotta
setblock 417 243 310 minecraft:stripped_oak_log
fill 417 243 311 417 246 311 minecraft:red_terracotta
setblock 417 243 315 minecraft:stripped_oak_log
fill 417 243 316 417 246 316 minecraft:red_terracotta
fill 376 244 275 376 247 317 minecraft:brown_terracotta
fill 377 244 275 403 247 275 minecraft:brown_terracotta
setblock 377 244 279 minecraft:stripped_oak_log
fill 377 244 280 377 244 283 minecraft:red_terracotta
setblock 377 244 284 minecraft:stripped_oak_log
fill 377 244 285 377 244 288 minecraft:red_terracotta
setblock 377 244 289 minecraft:stripped_oak_log
fill 377 244 290 377 244 293 minecraft:red_terracotta
setblock 377 244 294 minecraft:stripped_oak_log
fill 377 244 295 377 247 295 minecraft:red_terracotta
setblock 377 244 299 minecraft:stripped_oak_log
fill 377 244 300 377 247 300 minecraft:red_terracotta
setblock 377 244 304 minecraft:stripped_oak_log
fill 377 244 305 377 244 308 minecraft:red_terracotta
setblock 377 244 309 minecraft:stripped_oak_log
fill 377 244 310 377 247 310 minecraft:red_terracotta
setblock 377 244 314 minecraft:stripped_oak_log
setblock 377 244 315 minecraft:red_terracotta
fill 377 244 317 418 247 317 minecraft:brown_terracotta
setblock 378 244 278 minecraft:stripped_oak_log
fill 378 244 279 378 244 282 minecraft:red_terracotta
setblock 378 244 283 minecraft:stripped_oak_log
fill 378 244 284 378 247 284 minecraft:red_terracotta
setblock 378 244 287 minecraft:red_terracotta
setblock 378 244 288 minecraft:stripped_oak_log
fill 378 244 289 378 247 289 minecraft:red_terracotta
fill 378 244 291 378 245 291 minecraft:red_terracotta
setblock 378 244 293 minecraft:stripped_oak_log
fill 378 244 294 378 246 294 minecraft:red_terracotta
setblock 378 244 298 minecraft:stripped_oak_log
fill 378 244 299 378 247 299 minecraft:red_terracotta
setblock 378 244 303 minecraft:stripped_oak_log
fill 378 244 304 378 247 304 minecraft:red_terracotta
setblock 378 244 308 minecraft:stripped_oak_log
fill 378 244 309 378 246 309 minecraft:red_terracotta
setblock 379 244 277 minecraft:stripped_oak_log
fill 379 244 279 379 244 281 minecraft:red_terracotta
setblock 379 244 282 minecraft:stripped_oak_log
fill 379 244 283 379 247 283 minecraft:red_terracotta
setblock 379 244 287 minecraft:stripped_oak_log
fill 379 244 288 379 247 288 minecraft:red_terracotta
setblock 379 244 297 minecraft:stripped_oak_log
setblock 379 244 298 minecraft:red_terracotta
setblock 379 244 302 minecraft:stripped_oak_log
fill 379 244 303 379 245 303 minecraft:red_terracotta
setblock 380 244 276 minecraft:stripped_oak_log
setblock 380 244 277 minecraft:red_terracotta
setblock 380 244 282 minecraft:red_terracotta
fill 381 244 276 381 245 276 minecraft:red_terracotta
setblock 385 244 276 minecraft:stripped_oak_log
setblock 386 244 276 minecraft:red_terracotta
setblock 387 244 276 minecraft:shroomlight
fill 387 244 277 387 248 277 minecraft:stripped_oak_log
setblock 387 244 278 minecraft:shroomlight
fill 388 244 276 388 245 276 minecraft:red_terracotta
setblock 388 244 277 minecraft:shroomlight
setblock 388 244 279 minecraft:shroomlight
setblock 389 244 276 minecraft:shroomlight
setblock 389 244 277 minecraft:stripped_oak_log
setblock 389 244 278 minecraft:shroomlight
setblock 390 244 276 minecraft:stripped_oak_log
setblock 390 244 277 minecraft:shroomlight
setblock 390 244 279 minecraft:shroomlight
setblock 391 244 276 minecraft:shroomlight
setblock 391 244 278 minecraft:shroomlight
setblock 392 244 277 minecraft:shroomlight
setblock 392 244 279 minecraft:shroomlight
fill 392 244 316 394 244 316 minecraft:red_terracotta
setblock 393 244 276 minecraft:shroomlight
setblock 393 244 278 minecraft:shroomlight
fill 393 244 279 393 245 279 minecraft:red_terracotta
setblock 394 244 277 minecraft:shroomlight
fill 394 244 278 394 247 278 minecraft:red_terracotta
setblock 394 244 279 minecraft:shroomlight
fill 394 244 315 395 244 315 minecraft:red_terracotta
setblock 395 244 276 minecraft:shroomlight
fill 395 244 277 395 247 277 minecraft:red_terracotta
setblock 395 244 278 minecraft:shroomlight
fill 395 244 279 395 245 279 minecraft:red_terracotta
setblock 395 244 316 minecraft:stripped_oak_log
fill 396 244 276 396 247 276 minecraft:red_terracotta
setblock 396 244 277 minecraft:shroomlight
fill 396 244 278 396 245 278 minecraft:red_terracotta
setblock 396 244 279 minecraft:shroomlight
setblock 396 244 315 minecraft:stripped_oak_log
fill 396 244 316 399 244 316 minecraft:red_terracotta
setblock 397 244 276 minecraft:shroomlight
fill 397 244 277 397 245 277 minecraft:red_terracotta
setblock 397 244 278 minecraft:shroomlight
setblock 397 244 279 minecraft:stripped_oak_log
setblock 397 244 280 minecraft:shroomlight
setblock 397 244 282 minecraft:shroomlight
fill 397 244 315 397 247 315 minecraft:red_terracotta
fill 398 244 276 398 245 276 minecraft:red_terracotta
setblock 398 244 277 minecraft:shroomlight
setblock 398 244 278 minecraft:stripped_oak_log
setblock 398 244 279 minecraft:shroomlight
fill 398 244 280 398 249 280 minecraft:stripped_oak_log
setblock 398 244 281 minecraft:shroomlight
setblock 399 244 276 minecraft:shroomlight
setblock 399 244 277 minecraft:stripped_oak_log
setblock 399 244 278 minecraft:shroomlight
setblock 399 244 280 minecraft:shroomlight
setblock 399 244 282 minecraft:shroomlight
setblock 400 244 276 minecraft:stripped_oak_log
setblock 400 244 277 minecraft:shroomlight
setblock 400 244 279 minecraft:shroomlight
setblock 400 244 281 minecraft:shroomlight
setblock 400 244 316 minecraft:stripped_oak_log
setblock 401 244 276 minecraft:shroomlight
setblock 401 244 278 minecraft:shroomlight
fill 401 244 279 401 249 279 minecraft:stripped_oak_log
setblock 401 244 280 minecraft:shroomlight
setblock 401 244 282 minecraft:shroomlight
setblock 401 244 315 minecraft:stripped_oak_log
fill 401 244 316 401 247 316 minecraft:red_terracotta
setblock 402 244 277 minecraft:shroomlight
fill 402 244 278 402 249 278 minecraft:stripped_oak_log
setblock 402 244 279 minecraft:shroomlight
setblock 402 244 281 minecraft:shroomlight
setblock 403 244 276 minecraft:shroomlight
setblock 403 244 278 minecraft:shroomlight
fill 403 244 279 403 249 279 minecraft:stripped_oak_log
setblock 403 244 280 minecraft:shroomlight
fill 403 244 281 403 249 281 minecraft:stripped_oak_log
setblock 403 244 282 minecraft:shroomlight
setblock 405 244 276 minecraft:stripped_oak_log
setblock 405 244 281 minecraft:stripped_oak_log
setblock 405 244 316 minecraft:stripped_oak_log
setblock 406 244 316 minecraft:red_terracotta
fill 407 244 275 418 247 275 minecraft:brown_terracotta
setblock 408 244 281 minecraft:stripped_oak_log
setblock 409 244 294 minecraft:shroomlight
setblock 409 244 296 minecraft:shroomlight
setblock 409 244 298 minecraft:shroomlight
setblock 409 244 300 minecraft:shroomlight
setblock 409 244 302 minecraft:shroomlight
setblock 409 244 304 minecraft:shroomlight
setblock 409 244 306 minecraft:shroomlight
setblock 409 244 308 minecraft:shroomlight
setblock 410 244 295 minecraft:shroomlight
setblock 410 244 297 minecraft:shroomlight
setblock 410 244 299 minecraft:shroomlight
setblock 410 244 301 minecraft:shroomlight
setblock 410 244 303 minecraft:shroomlight
setblock 410 244 305 minecraft:shroomlight
setblock 410 244 307 minecraft:shroomlight
setblock 410 244 316 minecraft:stripped_oak_log
setblock 411 244 276 minecraft:red_terracotta
setblock 411 244 294 minecraft:shroomlight
setblock 411 244 296 minecraft:shroomlight
setblock 411 244 298 minecraft:shroomlight
setblock 411 244 300 minecraft:shroomlight
setblock 411 244 302 minecraft:shroomlight
setblock 411 244 304 minecraft:shroomlight
setblock 411 244 306 minecraft:shroomlight
setblock 411 244 308 minecraft:shroomlight
fill 411 244 316 411 247 316 minecraft:red_terracotta
setblock 412 244 295 minecraft:shroomlight
setblock 412 244 297 minecraft:shroomlight
setblock 412 244 299 minecraft:shroomlight
setblock 412 244 301 minecraft:shroomlight
setblock 412 244 303 minecraft:shroomlight
setblock 412 244 305 minecraft:shroomlight
setblock 412 244 307 minecraft:shroomlight
setblock 413 244 294 minecraft:shroomlight
setblock 413 244 296 minecraft:shroomlight
setblock 413 244 298 minecraft:shroomlight
setblock 413 244 300 minecraft:shroomlight
setblock 413 244 302 minecraft:shroomlight
setblock 413 244 304 minecraft:shroomlight
setblock 413 244 306 minecraft:shroomlight
setblock 413 244 308 minecraft:shroomlight
setblock 414 244 295 minecraft:shroomlight
setblock 414 244 297 minecraft:shroomlight
setblock 414 244 299 minecraft:shroomlight
fill 414 244 300 414 245 300 minecraft:red_terracotta
setblock 414 244 301 minecraft:shroomlight
setblock 414 244 302 minecraft:stripped_oak_log
setblock 414 244 303 minecraft:shroomlight
setblock 414 244 305 minecraft:shroomlight
setblock 414 244 306 minecraft:red_terracotta
setblock 414 244 307 minecraft:shroomlight
fill 414 244 308 414 247 308 minecraft:red_terracotta
setblock 415 244 276 minecraft:stripped_oak_log
setblock 415 244 277 minecraft:red_terracotta
setblock 415 244 281 minecraft:stripped_oak_log
fill 415 244 282 415 245 284 minecraft:red_terracotta
setblock 415 244 294 minecraft:shroomlight
setblock 415 244 296 minecraft:shroomlight
fill 415 244 297 415 245 297 minecraft:red_terracotta
setblock 415 244 298 minecraft:shroomlight
fill 415 244 299 415 245 299 minecraft:red_terracotta
setblock 415 244 300 minecraft:shroomlight
setblock 415 244 301 minecraft:stripped_oak_log
setblock 415 244 302 minecraft:shroomlight
setblock 415 244 304 minecraft:shroomlight
setblock 415 244 306 minecraft:shroomlight
fill 415 244 307 415 247 307 minecraft:red_terracotta
setblock 415 244 308 minecraft:shroomlight
fill 415 244 309 415 244 310 minecraft:red_terracotta
setblock 415 244 311 minecraft:stripped_oak_log
setblock 415 244 316 minecraft:stripped_oak_log
fill 416 244 276 416 246 276 minecraft:red_terracotta
setblock 416 244 280 minecraft:stripped_oak_log
fill 416 244 281 416 247 281 minecraft:red_terracotta
setblock 416 244 285 minecraft:stripped_oak_log
fill 416 244 286 416 244 289 minecraft:red_terracotta
setblock 416 244 290 minecraft:stripped_oak_log
fill 416 244 291 416 247 291 minecraft:red_terracotta
setblock 416 244 295 minecraft:shroomlight
fill 416 244 296 416 247 296 minecraft:red_terracotta
setblock 416 244 297 minecraft:shroomlight
fill 416 244 298 416 245 298 minecraft:red_terracotta
setblock 416 244 299 minecraft:shroomlight
setblock 416 244 300 minecraft:stripped_oak_log
setblock 416 244 301 minecraft:shroomlight
setblock 416 244 303 minecraft:shroomlight
setblock 416 244 305 minecraft:shroomlight
fill 416 244 306 416 247 306 minecraft:red_terracotta
setblock 416 244 307 minecraft:shroomlight
fill 416 244 308 416 244 309 minecraft:red_terracotta
setblock 416 244 310 minecraft:stripped_oak_log
fill 416 244 311 416 247 311 minecraft:red_terracotta
setblock 416 244 315 minecraft:stripped_oak_log
fill 416 244 316 416 247 316 minecraft:red_terracotta
setblock 417 244 279 minecraft:stripped_oak_log
fill 417 244 280 417 247 280 minecraft:red_terracotta
setblock 417 244 284 minecraft:stripped_oak_log
fill 417 244 285 417 247 285 minecraft:red_terracotta
setblock 417 244 289 minecraft:stripped_oak_log
fill 417 244 290 417 247 290 minecraft:red_terracotta
setblock 417 244 294 minecraft:shroomlight
fill 417 244 295 417 247 295 minecraft:red_terracotta
setblock 417 244 296 minecraft:shroomlight
setblock 417 244 298 minecraft:shroomlight
setblock 417 244 299 minecraft:stripped_oak_log
setblock 417 244 300 minecraft:shroomlight
setblock 417 244 302 minecraft:shroomlight
setblock 417 244 304 minecraft:shroomlight
fill 417 244 305 417 247 305 minecraft:red_terracotta
setblock 417 244 306 minecraft:shroomlight
setblock 417 244 308 minecraft:shroomlight
setblock 417 244 309 minecraft:stripped_oak_log
fill 417 244 310 417 247 310 minecraft:red_terracotta
setblock 417 244 314 minecraft:stripped_oak_log
fill 417 244 315 417 247 315 minecraft:red_terracotta
fill 418 244 276 418 247 316 minecraft:brown_terracotta
setblock 377 245 278 minecraft:stripped_oak_log
fill 377 245 279 377 245 282 minecraft:red_terracotta
setblock 377 245 283 minecraft:stripped_oak_log
fill 377 245 284 377 245 287 minecraft:red_terracotta
setblock 377 245 288 minecraft:stripped_oak_log
fill 377 245 289 377 245 292 minecraft:red_terracotta
setblock 377 245 293 minecraft:stripped_oak_log
fill 377 245 294 377 248 294 minecraft:red_terracotta
setblock 377 245 298 minecraft:stripped_oak_log
fill 377 245 299 377 248 299 minecraft:red_terracotta
setblock 377 245 303 minecraft:stripped_oak_log
fill 377 245 304 377 245 307 minecraft:red_terracotta
setblock 377 245 308 minecraft:stripped_oak_log
fill 377 245 309 377 248 309 minecraft:red_terracotta
setblock 377 245 313 minecraft:stripped_oak_log
setblock 378 245 277 minecraft:stripped_oak_log
fill 378 245 278 378 245 281 minecraft:red_terracotta
setblock 378 245 282 minecraft:stripped_oak_log
fill 378 245 283 378 248 283 minecraft:red_terracotta
setblock 378 245 287 minecraft:stripped_oak_log
fill 378 245 288 378 248 288 minecraft:red_terracotta
setblock 378 245 292 minecraft:stripped_oak_log
fill 378 245 293 378 247 293 minecraft:red_terracotta
setblock 378 245 297 minecraft:stripped_oak_log
fill 378 245 298 378 246 298 minecraft:red_terracotta
setblock 378 245 302 minecraft:stripped_oak_log
fill 378 245 303 378 248 303 minecraft:red_terracotta
setblock 378 245 307 minecraft:stripped_oak_log
fill 378 245 308 378 247 308 minecraft:red_terracotta
setblock 379 245 276 minecraft:stripped_oak_log
setblock 379 245 277 minecraft:red_terracotta
fill 379 245 279 379 245 280 minecraft:red_terracotta
setblock 379 245 281 minecraft:stripped_oak_log
fill 379 245 282 379 247 282 minecraft:red_terracotta
fill 379 245 284 379 246 284 minecraft:red_terracotta
setblock 379 245 286 minecraft:stripped_oak_log
fill 379 245 287 379 248 287 minecraft:red_terracotta
setblock 379 245 301 minecraft:stripped_oak_log
setblock 379 245 302 minecraft:red_terracotta
setblock 379 245 306 minecraft:stripped_oak_log
setblock 380 245 276 minecraft:red_terracotta
setblock 387 245 276 minecraft:red_terracotta
fill 387 245 278 387 246 278 minecraft:stripped_oak_log
fill 388 245 277 388 246 277 minecraft:stripped_oak_log
fill 388 245 279 388 246 279 minecraft:stripped_oak_log
setblock 389 245 276 minecraft:stripped_oak_log
fill 389 245 277 390 245 277 minecraft:red_terracotta
fill 389 245 278 390 246 278 minecraft:stripped_oak_log
fill 390 245 276 391 246 276 minecraft:red_terracotta
fill 390 245 279 390 246 279 minecraft:stripped_oak_log
setblock 391 245 278 minecraft:red_terracotta
fill 391 245 316 393 245 316 minecraft:red_terracotta
setblock 392 245 277 minecraft:red_terracotta
fill 392 245 278 392 245 279 minecraft:stripped_oak_log
setblock 393 245 276 minecraft:red_terracotta
setblock 393 245 277 minecraft:stripped_oak_log
fill 393 245 278 393 246 278 minecraft:red_terracotta
setblock 394 245 276 minecraft:stripped_oak_log
fill 394 245 277 394 246 277 minecraft:red_terracotta
setblock 394 245 279 minecraft:red_terracotta
setblock 394 245 315 minecraft:red_terracotta
setblock 394 245 316 minecraft:stripped_oak_log
fill 395 245 276 395 246 276 minecraft:red_terracotta
fill 395 245 278 395 246 278 minecraft:red_terracotta
setblock 395 245 315 minecraft:stripped_oak_log
fill 395 245 316 398 245 316 minecraft:red_terracotta
fill 396 245 277 396 246 277 minecraft:red_terracotta
fill 396 245 279 396 246 279 minecraft:stripped_oak_log
fill 396 245 315 396 248 315 minecraft:red_terracotta
fill 397 245 276 397 246 276 minecraft:red_terracotta
setblock 397 245 278 minecraft:stripped_oak_log
setblock 397 245 279 minecraft:red_terracotta
fill 397 245 280 397 246 280 minecraft:stripped_oak_log
fill 397 245 282 397 246 282 minecraft:stripped_oak_log
setblock 398 245 277 minecraft:stripped_oak_log
fill 398 245 278 399 245 278 minecraft:red_terracotta
fill 398 245 279 400 246 279 minecraft:stripped_oak_log
fill 398 245 281 398 246 281 minecraft:stripped_oak_log
setblock 399 245 276 minecraft:stripped_oak_log
fill 399 245 277 400 246 277 minecraft:red_terracotta
fill 399 245 280 399 246 280 minecraft:stripped_oak_log
fill 399 245 282 399 246 282 minecraft:stripped_oak_log
setblock 399 245 316 minecraft:stripped_oak_log
fill 400 245 276 401 246 276 minecraft:red_terracotta
fill 400 245 278 401 246 278 minecraft:stripped_oak_log
fill 400 245 281 400 246 281 minecraft:stripped_oak_log
setblock 400 245 315 minecraft:stripped_oak_log
fill 400 245 316 400 248 316 minecraft:red_terracotta
fill 401 245 280 401 246 280 minecraft:stripped_oak_log
fill 401 245 282 401 246 282 minecraft:stripped_oak_log
fill 402 245 277 403 246 277 minecraft:stripped_oak_log
fill 402 245 279 402 246 279 minecraft:stripped_oak_log
fill 402 245 281 402 246 281 minecraft:stripped_oak_log
setblock 403 245 276 minecraft:red_terracotta
fill 403 245 278 403 246 278 minecraft:stripped_oak_log
fill 403 245 280 403 246 280 minecraft:stripped_oak_log
fill 403 245 282 403 246 282 minecraft:stripped_oak_log
setblock 404 245 316 minecraft:stripped_oak_log
fill 409 245 294 409 246 294 minecraft:stripped_oak_log
fill 409 245 296 409 246 296 minecraft:stripped_oak_log
fill 409 245 298 409 246 298 minecraft:stripped_oak_log
fill 409 245 300 409 246 300 minecraft:stripped_oak_log
fill 409 245 302 409 246 302 minecraft:stripped_oak_log
fill 409 245 304 409 246 304 minecraft:stripped_oak_log
fill 409 245 306 409 246 306 minecraft:stripped_oak_log
fill 409 245 308 409 246 308 minecraft:stripped_oak_log
fill 410 245 295 410 246 295 minecraft:stripped_oak_log
fill 410 245 297 410 246 297 minecraft:stripped_oak_log
fill 410 245 299 410 246 299 minecraft:stripped_oak_log
fill 410 245 301 410 246 301 minecraft:stripped_oak_log
fill 410 245 303 410 246 303 minecraft:stripped_oak_log
fill 410 245 305 410 246 305 minecraft:stripped_oak_log
fill 410 245 307 410 246 307 minecraft:stripped_oak_log
setblock 410 245 316 minecraft:red_terracotta
fill 411 245 294 411 246 294 minecraft:stripped_oak_log
fill 411 245 296 411 246 296 minecraft:stripped_oak_log
fill 411 245 298 411 246 298 minecraft:stripped_oak_log
fill 411 245 300 411 246 300 minecraft:stripped_oak_log
fill 411 245 302 411 246 302 minecraft:stripped_oak_log
fill 411 245 304 411 246 304 minecraft:stripped_oak_log
fill 411 245 306 411 246 306 minecraft:stripped_oak_log
fill 411 245 308 411 246 308 minecraft:stripped_oak_log
fill 412 245 295 412 246 295 minecraft:stripped_oak_log
fill 412 245 297 412 246 297 minecraft:stripped_oak_log
fill 412 245 299 412 246 299 minecraft:stripped_oak_log
fill 412 245 301 412 246 301 minecraft:stripped_oak_log
fill 412 245 303 412 246 303 minecraft:stripped_oak_log
fill 412 245 305 412 246 305 minecraft:stripped_oak_log
fill 412 245 307 412 246 307 minecraft:stripped_oak_log
fill 413 245 294 413 246 294 minecraft:stripped_oak_log
fill 413 245 296 413 246 296 minecraft:stripped_oak_log
fill 413 245 298 413 246 298 minecraft:stripped_oak_log
fill 413 245 300 413 246 300 minecraft:stripped_oak_log
fill 413 245 302 413 246 302 minecraft:stripped_oak_log
fill 413 245 304 413 246 304 minecraft:stripped_oak_log
fill 413 245 306 414 245 306 minecraft:stripped_oak_log
fill 413 245 308 413 246 308 minecraft:stripped_oak_log
setblock 414 245 276 minecraft:stripped_oak_log
fill 414 245 295 414 246 295 minecraft:stripped_oak_log
fill 414 245 297 414 246 297 minecraft:stripped_oak_log
fill 414 245 299 414 246 299 minecraft:stripped_oak_log
setblock 414 245 301 minecraft:stripped_oak_log
fill 414 245 302 414 246 303 minecraft:red_terracotta
setblock 414 245 305 minecraft:red_terracotta
fill 414 245 307 414 246 307 minecraft:red_terracotta
setblock 414 245 316 minecraft:stripped_oak_log
fill 415 245 276 415 246 276 minecraft:red_terracotta
setblock 415 245 285 minecraft:stripped_oak_log
fill 415 245 294 416 245 294 minecraft:stripped_oak_log
fill 415 245 296 415 246 296 minecraft:stripped_oak_log
fill 415 245 298 415 246 298 minecraft:red_terracotta
setblock 415 245 300 minecraft:stripped_oak_log
fill 415 245 301 415 246 302 minecraft:red_terracotta
setblock 415 245 304 minecraft:red_terracotta
setblock 415 245 305 minecraft:stripped_oak_log
fill 415 245 306 415 246 306 minecraft:red_terracotta
fill 415 245 308 415 245 309 minecraft:red_terracotta
setblock 415 245 310 minecraft:stripped_oak_log
fill 415 245 311 415 248 311 minecraft:red_terracotta
fill 415 245 316 415 247 316 minecraft:red_terracotta
setblock 416 245 279 minecraft:stripped_oak_log
fill 416 245 280 416 246 280 minecraft:red_terracotta
setblock 416 245 284 minecraft:stripped_oak_log
fill 416 245 285 416 245 288 minecraft:red_terracotta
setblock 416 245 289 minecraft:stripped_oak_log
fill 416 245 290 416 248 290 minecraft:red_terracotta
fill 416 245 295 416 246 295 minecraft:red_terracotta
fill 416 245 297 416 246 297 minecraft:red_terracotta
setblock 416 245 299 minecraft:stripped_oak_log
fill 416 245 300 416 246 301 minecraft:red_terracotta
setblock 416 245 303 minecraft:red_terracotta
setblock 416 245 304 minecraft:stripped_oak_log
fill 416 245 305 416 246 305 minecraft:red_terracotta
fill 416 245 307 416 245 308 minecraft:red_terracotta
setblock 416 245 309 minecraft:stripped_oak_log
fill 416 245 310 416 248 310 minecraft:red_terracotta
setblock 416 245 314 minecraft:stripped_oak_log
setblock 417 245 278 minecraft:stripped_oak_log
fill 417 245 279 417 247 279 minecraft:red_terracotta
setblock 417 245 283 minecraft:stripped_oak_log
fill 417 245 284 417 248 284 minecraft:red_terracotta
setblock 417 245 288 minecraft:stripped_oak_log
fill 417 245 289 417 248 289 minecraft:red_terracotta
setblock 417 245 293 minecraft:stripped_oak_log
fill 417 245 294 417 246 294 minecraft:red_terracotta
fill 417 245 296 417 246 296 minecraft:red_terracotta
setblock 417 245 298 minecraft:stripped_oak_log
fill 417 245 299 417 246 300 minecraft:red_terracotta
setblock 417 245 302 minecraft:red_terracotta
setblock 417 245 303 minecraft:stripped_oak_log
fill 417 245 304 417 246 304 minecraft:red_terracotta
fill 417 245 306 417 246 306 minecraft:red_terracotta
setblock 417 245 308 minecraft:stripped_oak_log
fill 417 245 309 417 248 309 minecraft:red_terracotta
setblock 417 245 313 minecraft:stripped_oak_log
fill 417 245 314 417 248 314 minecraft:red_terracotta
setblock 377 246 277 minecraft:stripped_oak_log
fill 377 246 278 377 246 281 minecraft:red_terracotta
setblock 377 246 282 minecraft:stripped_oak_log
fill 377 246 283 377 246 286 minecraft:red_terracotta
setblock 377 246 287 minecraft:stripped_oak_log
fill 377 246 288 377 246 291 minecraft:red_terracotta
setblock 377 246 292 minecraft:stripped_oak_log
fill 377 246 293 377 249 293 minecraft:red_terracotta
setblock 377 246 297 minecraft:stripped_oak_log
fill 377 246 298 377 249 298 minecraft:red_terracotta
setblock 377 246 302 minecraft:stripped_oak_log
fill 377 246 303 377 246 306 minecraft:red_terracotta
setblock 377 246 307 minecraft:stripped_oak_log
fill 377 246 308 377 249 308 minecraft:red_terracotta
setblock 377 246 312 minecraft:stripped_oak_log
setblock 378 246 276 minecraft:stripped_oak_log
fill 378 246 278 378 246 280 minecraft:red_terracotta
setblock 378 246 281 minecraft:stripped_oak_log
fill 378 246 282 378 249 282 minecraft:red_terracotta
setblock 378 246 286 minecraft:stripped_oak_log
fill 378 246 287 378 249 287 minecraft:red_terracotta
setblock 378 246 291 minecraft:stripped_oak_log
fill 378 246 292 378 249 292 minecraft:red_terracotta
setblock 378 246 296 minecraft:stripped_oak_log
setblock 378 246 297 minecraft:red_terracotta
setblock 378 246 301 minecraft:stripped_oak_log
fill 378 246 302 378 247 302 minecraft:red_terracotta
setblock 378 246 306 minecraft:stripped_oak_log
fill 378 246 307 378 248 307 minecraft:red_terracotta
setblock 379 246 276 minecraft:red_terracotta
setblock 379 246 278 minecraft:light[level=12]
setblock 379 246 281 minecraft:red_terracotta
setblock 379 246 285 minecraft:stripped_oak_log
fill 379 246 286 379 249 286 minecraft:red_terracotta
setblock 379 246 292 minecraft:light[level=12]
setblock 379 246 299 minecraft:light[level=12]
setblock 379 246 306 minecraft:light[level=12]
setblock 379 246 313 minecraft:light[level=12]
setblock 386 246 278 minecraft:light[level=12]
setblock 386 246 285 minecraft:light[level=12]
setblock 386 246 292 minecraft:light[level=12]
setblock 386 246 299 minecraft:light[level=12]
setblock 386 246 306 minecraft:light[level=12]
setblock 386 246 313 minecraft:light[level=12]
fill 387 246 276 388 246 276 minecraft:stripped_oak_log
setblock 389 246 276 minecraft:red_terracotta
fill 389 246 277 389 252 277 minecraft:stripped_oak_log
setblock 390 246 277 minecraft:red_terracotta
setblock 391 246 278 minecraft:stripped_oak_log
fill 391 246 300 393 255 302 minecraft:stripped_oak_log
fill 391 246 316 392 246 316 minecraft:red_terracotta
setblock 392 246 277 minecraft:stripped_oak_log
fill 392 246 278 392 247 278 minecraft:red_terracotta
fill 392 246 279 395 246 279 minecraft:stripped_oak_log
setblock 393 246 276 minecraft:stripped_oak_log
fill 393 246 277 393 249 277 minecraft:red_terracotta
setblock 393 246 285 minecraft:light[level=12]
setblock 393 246 292 minecraft:light[level=12]
setblock 393 246 299 minecraft:light[level=12]
setblock 393 246 306 minecraft:light[level=12]
setblock 393 246 313 minecraft:light[level=12]
setblock 393 246 316 minecraft:stripped_oak_log
fill 394 246 276 394 249 276 minecraft:red_terracotta
fill 394 246 301 394 260 302 minecraft:stripped_oak_log
setblock 394 246 315 minecraft:stripped_oak_log
fill 394 246 316 397 246 316 minecraft:red_terracotta
fill 395 246 315 395 249 315 minecraft:red_terracotta
setblock 396 246 278 minecraft:stripped_oak_log
setblock 397 246 277 minecraft:stripped_oak_log
fill 397 246 278 398 246 278 minecraft:red_terracotta
fill 397 246 279 397 255 279 minecraft:stripped_oak_log
setblock 398 246 276 minecraft:stripped_oak_log
setblock 398 246 277 minecraft:red_terracotta
setblock 398 246 316 minecraft:stripped_oak_log
setblock 399 246 276 minecraft:red_terracotta
setblock 399 246 278 minecraft:stripped_oak_log
setblock 399 246 315 minecraft:stripped_oak_log
fill 399 246 316 399 249 316 minecraft:red_terracotta
setblock 400 246 285 minecraft:light[level=12]
setblock 400 246 292 minecraft:light[level=12]
setblock 400 246 299 minecraft:light[level=12]
setblock 400 246 306 minecraft:light[level=12]
setblock 400 246 313 minecraft:light[level=12]
fill 401 246 277 401 249 277 minecraft:stripped_oak_log
setblock 403 246 276 minecraft:stripped_oak_log
setblock 407 246 278 minecraft:light[level=12]
setblock 407 246 285 minecraft:light[level=12]
setblock 407 246 292 minecraft:light[level=12]
setblock 407 246 299 minecraft:light[level=12]
setblock 407 246 306 minecraft:light[level=12]
setblock 407 246 313 minecraft:light[level=12]
setblock 413 246 306 minecraft:stripped_oak_log
setblock 413 246 316 minecraft:stripped_oak_log
setblock 414 246 276 minecraft:red_terracotta
setblock 414 246 278 minecraft:light[level=12]
setblock 414 246 285 minecraft:light[level=12]
setblock 414 246 292 minecraft:light[level=12]
fill 414 246 300 414 251 300 minecraft:stripped_oak_log
setblock 414 246 301 minecraft:red_terracotta
setblock 414 246 305 minecraft:stripped_oak_log
fill 414 246 306 414 249 306 minecraft:red_terracotta
setblock 414 246 309 minecraft:red_terracotta
setblock 414 246 313 minecraft:light[level=12]
fill 414 246 316 414 248 316 minecraft:red_terracotta
setblock 415 246 284 minecraft:stripped_oak_log
fill 415 246 285 416 247 286 minecraft:red_terracotta
setblock 415 246 294 minecraft:stripped_oak_log
fill 415 246 297 415 251 297 minecraft:stripped_oak_log
setblock 415 246 299 minecraft:stripped_oak_log
setblock 415 246 300 minecraft:red_terracotta
setblock 415 246 304 minecraft:stripped_oak_log
fill 415 246 305 415 249 305 minecraft:red_terracotta
setblock 415 246 308 minecraft:red_terracotta
setblock 415 246 309 minecraft:stripped_oak_log
fill 415 246 310 415 249 310 minecraft:red_terracotta
setblock 416 246 279 minecraft:red_terracotta
setblock 416 246 283 minecraft:stripped_oak_log
fill 416 246 284 416 249 284 minecraft:red_terracotta
setblock 416 246 287 minecraft:red_terracotta
setblock 416 246 288 minecraft:stripped_oak_log
fill 416 246 289 416 249 289 minecraft:red_terracotta
setblock 416 246 293 minecraft:stripped_oak_log
fill 416 246 294 416 249 294 minecraft:red_terracotta
setblock 416 246 298 minecraft:stripped_oak_log
setblock 416 246 299 minecraft:red_terracotta
setblock 416 246 303 minecraft:stripped_oak_log
fill 416 246 304 416 249 304 minecraft:red_terracotta
setblock 416 246 307 minecraft:red_terracotta
setblock 416 246 308 minecraft:stripped_oak_log
fill 416 246 309 416 249 309 minecraft:red_terracotta
setblock 416 246 313 minecraft:stripped_oak_log
setblock 417 246 277 minecraft:stripped_oak_log
fill 417 246 278 417 247 278 minecraft:red_terracotta
setblock 417 246 282 minecraft:stripped_oak_log
fill 417 246 283 417 249 283 minecraft:red_terracotta
setblock 417 246 287 minecraft:stripped_oak_log
fill 417 246 288 417 249 288 minecraft:red_terracotta
setblock 417 246 292 minecraft:stripped_oak_log
fill 417 246 293 417 249 293 minecraft:red_terracotta
setblock 417 246 297 minecraft:stripped_oak_log
setblock 417 246 298 minecraft:red_terracotta
setblock 417 246 302 minecraft:stripped_oak_log
fill 417 246 303 417 249 303 minecraft:red_terracotta
setblock 417 246 307 minecraft:stripped_oak_log
setblock 417 246 308 minecraft:red_terracotta
setblock 417 246 312 minecraft:stripped_oak_log
fill 417 246 313 417 249 313 minecraft:red_terracotta
setblock 377 247 276 minecraft:stripped_oak_log
fill 377 247 277 377 247 280 minecraft:red_terracotta
setblock 377 247 281 minecraft:stripped_oak_log
fill 377 247 282 377 247 285 minecraft:red_terracotta
setblock 377 247 286 minecraft:stripped_oak_log
fill 377 247 287 377 247 290 minecraft:red_terracotta
setblock 377 247 291 minecraft:stripped_oak_log
fill 377 247 292 377 250 292 minecraft:red_terracotta
setblock 377 247 296 minecraft:stripped_oak_log
fill 377 247 297 377 249 297 minecraft:red_terracotta
setblock 377 247 301 minecraft:stripped_oak_log
fill 377 247 302 377 247 305 minecraft:red_terracotta
setblock 377 247 306 minecraft:stripped_oak_log
fill 377 247 307 377 250 307 minecraft:red_terracotta
setblock 377 247 311 minecraft:stripped_oak_log
setblock 377 247 312 minecraft:red_terracotta
setblock 378 247 279 minecraft:red_terracotta
setblock 378 247 280 minecraft:stripped_oak_log
fill 378 247 281 378 249 281 minecraft:red_terracotta
setblock 378 247 285 minecraft:stripped_oak_log
fill 378 247 286 378 250 286 minecraft:red_terracotta
setblock 378 247 290 minecraft:stripped_oak_log
fill 378 247 291 378 250 291 minecraft:red_terracotta
setblock 378 247 300 minecraft:stripped_oak_log
setblock 378 247 301 minecraft:red_terracotta
setblock 378 247 305 minecraft:stripped_oak_log
fill 378 247 306 378 248 306 minecraft:red_terracotta
setblock 379 247 284 minecraft:stripped_oak_log
fill 379 247 285 379 249 285 minecraft:red_terracotta
setblock 387 247 276 minecraft:shroomlight
setblock 387 247 278 minecraft:shroomlight
setblock 388 247 276 minecraft:red_terracotta
setblock 388 247 277 minecraft:shroomlight
setblock 388 247 279 minecraft:shroomlight
setblock 389 247 276 minecraft:shroomlight
setblock 389 247 278 minecraft:shroomlight
fill 390 247 276 390 248 276 minecraft:red_terracotta
setblock 390 247 277 minecraft:shroomlight
fill 390 247 278 390 255 278 minecraft:stripped_oak_log
setblock 390 247 279 minecraft:shroomlight
setblock 391 247 276 minecraft:shroomlight
setblock 391 247 277 minecraft:stripped_oak_log
setblock 391 247 278 minecraft:shroomlight
setblock 391 247 316 minecraft:red_terracotta
setblock 392 247 276 minecraft:stripped_oak_log
setblock 392 247 277 minecraft:shroomlight
setblock 392 247 279 minecraft:shroomlight
setblock 392 247 316 minecraft:stripped_oak_log
setblock 393 247 276 minecraft:shroomlight
setblock 393 247 278 minecraft:shroomlight
fill 393 247 279 393 255 279 minecraft:stripped_oak_log
fill 393 247 316 396 247 316 minecraft:red_terracotta
setblock 394 247 277 minecraft:shroomlight
setblock 394 247 279 minecraft:shroomlight
fill 394 247 315 394 250 315 minecraft:red_terracotta
setblock 395 247 276 minecraft:shroomlight
setblock 395 247 278 minecraft:shroomlight
fill 395 247 279 395 255 279 minecraft:stripped_oak_log
setblock 396 247 277 minecraft:shroomlight
setblock 396 247 278 minecraft:red_terracotta
setblock 396 247 279 minecraft:shroomlight
setblock 397 247 276 minecraft:shroomlight
fill 397 247 277 397 248 277 minecraft:red_terracotta
setblock 397 247 278 minecraft:shroomlight
setblock 397 247 280 minecraft:shroomlight
setblock 397 247 282 minecraft:shroomlight
setblock 397 247 316 minecraft:stripped_oak_log
fill 398 247 276 398 249 276 minecraft:red_terracotta
setblock 398 247 277 minecraft:shroomlight
fill 398 247 278 398 255 278 minecraft:stripped_oak_log
setblock 398 247 279 minecraft:shroomlight
setblock 398 247 281 minecraft:shroomlight
setblock 398 247 315 minecraft:stripped_oak_log
fill 398 247 316 398 250 316 minecraft:red_terracotta
setblock 399 247 276 minecraft:shroomlight
fill 399 247 277 399 255 277 minecraft:stripped_oak_log
setblock 399 247 278 minecraft:shroomlight
fill 399 247 279 399 255 279 minecraft:stripped_oak_log
setblock 399 247 280 minecraft:shroomlight
setblock 399 247 282 minecraft:shroomlight
setblock 400 247 276 minecraft:red_terracotta
setblock 400 247 277 minecraft:shroomlight
fill 400 247 278 400 249 278 minecraft:stripped_oak_log
setblock 400 247 279 minecraft:shroomlight
setblock 400 247 281 minecraft:shroomlight
setblock 401 247 276 minecraft:shroomlight
setblock 401 247 278 minecraft:shroomlight
setblock 401 247 280 minecraft:shroomlight
setblock 401 247 282 minecraft:shroomlight
fill 402 247 276 402 249 276 minecraft:stripped_oak_log
setblock 402 247 277 minecraft:shroomlight
setblock 402 247 279 minecraft:shroomlight
setblock 402 247 281 minecraft:shroomlight
setblock 403 247 276 minecraft:shroomlight
fill 403 247 277 403 249 277 minecraft:stripped_oak_log
setblock 403 247 278 minecraft:shroomlight
setblock 403 247 280 minecraft:shroomlight
setblock 403 247 282 minecraft:shroomlight
fill 404 247 275 406 247 275 minecraft:brown_terracotta
setblock 409 247 294 minecraft:shroomlight
setblock 409 247 296 minecraft:shroomlight
setblock 409 247 298 minecraft:shroomlight
setblock 409 247 300 minecraft:shroomlight
setblock 409 247 302 minecraft:shroomlight
setblock 409 247 304 minecraft:shroomlight
setblock 409 247 306 minecraft:shroomlight
setblock 409 247 308 minecraft:shroomlight
setblock 410 247 295 minecraft:shroomlight
setblock 410 247 297 minecraft:shroomlight
setblock 410 247 299 minecraft:shroomlight
setblock 410 247 301 minecraft:shroomlight
setblock 410 247 303 minecraft:shroomlight
setblock 410 247 305 minecraft:shroomlight
setblock 410 247 307 minecraft:shroomlight
setblock 411 247 294 minecraft:shroomlight
setblock 411 247 296 minecraft:shroomlight
setblock 411 247 298 minecraft:shroomlight
setblock 411 247 300 minecraft:shroomlight
setblock 411 247 302 minecraft:shroomlight
setblock 411 247 304 minecraft:shroomlight
setblock 411 247 306 minecraft:shroomlight
setblock 411 247 308 minecraft:shroomlight
setblock 412 247 295 minecraft:shroomlight
setblock 412 247 297 minecraft:shroomlight
setblock 412 247 299 minecraft:shroomlight
setblock 412 247 301 minecraft:shroomlight
setblock 412 247 303 minecraft:shroomlight
setblock 412 247 305 minecraft:shroomlight
setblock 412 247 307 minecraft:shroomlight
setblock 412 247 316 minecraft:stripped_oak_log
setblock 413 247 294 minecraft:shroomlight
setblock 413 247 296 minecraft:shroomlight
setblock 413 247 298 minecraft:shroomlight
setblock 413 247 300 minecraft:shroomlight
setblock 413 247 302 minecraft:shroomlight
setblock 413 247 304 minecraft:shroomlight
setblock 413 247 306 minecraft:shroomlight
setblock 413 247 308 minecraft:shroomlight
fill 413 247 316 413 250 316 minecraft:red_terracotta
setblock 414 247 295 minecraft:shroomlight
setblock 414 247 297 minecraft:shroomlight
setblock 414 247 299 minecraft:shroomlight
setblock 414 247 301 minecraft:shroomlight
setblock 414 247 302 minecraft:red_terracotta
setblock 414 247 303 minecraft:shroomlight
setblock 414 247 304 minecraft:stripped_oak_log
setblock 414 247 305 minecraft:shroomlight
setblock 414 247 307 minecraft:shroomlight
setblock 415 247 294 minecraft:shroomlight
setblock 415 247 296 minecraft:shroomlight
setblock 415 247 298 minecraft:shroomlight
setblock 415 247 299 minecraft:red_terracotta
setblock 415 247 300 minecraft:shroomlight
fill 415 247 301 415 248 301 minecraft:red_terracotta
setblock 415 247 302 minecraft:shroomlight
setblock 415 247 303 minecraft:stripped_oak_log
setblock 415 247 304 minecraft:shroomlight
setblock 415 247 306 minecraft:shroomlight
setblock 415 247 308 minecraft:shroomlight
fill 415 247 309 415 250 309 minecraft:red_terracotta
setblock 416 247 282 minecraft:stripped_oak_log
fill 416 247 283 416 249 283 minecraft:red_terracotta
setblock 416 247 287 minecraft:stripped_oak_log
fill 416 247 288 416 250 288 minecraft:red_terracotta
setblock 416 247 292 minecraft:stripped_oak_log
fill 416 247 293 416 250 293 minecraft:red_terracotta
setblock 416 247 295 minecraft:shroomlight
setblock 416 247 297 minecraft:shroomlight
fill 416 247 298 416 249 298 minecraft:red_terracotta
setblock 416 247 299 minecraft:shroomlight
fill 416 247 300 416 248 300 minecraft:red_terracotta
setblock 416 247 301 minecraft:shroomlight
setblock 416 247 302 minecraft:stripped_oak_log
setblock 416 247 303 minecraft:shroomlight
setblock 416 247 305 minecraft:shroomlight
setblock 416 247 307 minecraft:shroomlight
fill 416 247 308 416 250 308 minecraft:red_terracotta
setblock 416 247 312 minecraft:stripped_oak_log
setblock 416 247 313 minecraft:red_terracotta
setblock 417 247 281 minecraft:stripped_oak_log
fill 417 247 282 417 250 282 minecraft:red_terracotta
setblock 417 247 286 minecraft:stripped_oak_log
fill 417 247 287 417 250 287 minecraft:red_terracotta
setblock 417 247 291 minecraft:stripped_oak_log
fill 417 247 292 417 250 292 minecraft:red_terracotta
setblock 417 247 294 minecraft:shroomlight
setblock 417 247 296 minecraft:shroomlight
fill 417 247 297 417 250 297 minecraft:red_terracotta
setblock 417 247 298 minecraft:shroomlight
fill 417 247 299 417 248 299 minecraft:red_terracotta
setblock 417 247 300 minecraft:shroomlight
setblock 417 247 301 minecraft:stripped_oak_log
setblock 417 247 302 minecraft:shroomlight
setblock 417 247 304 minecraft:shroomlight
setblock 417 247 306 minecraft:shroomlight
fill 417 247 307 417 250 307 minecraft:red_terracotta
setblock 417 247 308 minecraft:shroomlight
setblock 417 247 311 minecraft:stripped_oak_log
fill 417 247 312 417 250 312 minecraft:red_terracotta
fill 376 248 275 376 251 317 minecraft:light_gray_terracotta
fill 377 248 275 418 251 275 minecraft:light_gray_terracotta
fill 377 248 278 377 248 279 minecraft:red_terracotta
setblock 377 248 280 minecraft:stripped_oak_log
fill 377 248 281 377 248 284 minecraft:red_terracotta
setblock 377 248 285 minecraft:stripped_oak_log
fill 377 248 286 377 248 289 minecraft:red_terracotta
setblock 377 248 290 minecraft:stripped_oak_log
fill 377 248 291 377 251 291 minecraft:red_terracotta
setblock 377 248 295 minecraft:stripped_oak_log
fill 377 248 296 377 250 296 minecraft:red_terracotta
setblock 377 248 300 minecraft:stripped_oak_log
fill 377 248 301 377 248 304 minecraft:red_terracotta
setblock 377 248 305 minecraft:stripped_oak_log
fill 377 248 306 377 251 306 minecraft:red_terracotta
setblock 377 248 310 minecraft:stripped_oak_log
fill 377 248 311 377 251 311 minecraft:red_terracotta
fill 377 248 317 418 251 317 minecraft:light_gray_terracotta
setblock 378 248 280 minecraft:red_terracotta
setblock 378 248 284 minecraft:stripped_oak_log
fill 378 248 285 378 249 285 minecraft:red_terracotta
setblock 378 248 289 minecraft:stripped_oak_log
fill 378 248 290 378 251 290 minecraft:red_terracotta
setblock 378 248 304 minecraft:stripped_oak_log
setblock 378 248 305 minecraft:red_terracotta
setblock 379 248 278 minecraft:light[level=15]
setblock 379 248 283 minecraft:stripped_oak_log
setblock 379 248 284 minecraft:red_terracotta
setblock 379 248 288 minecraft:stripped_oak_log
setblock 379 248 294 minecraft:light[level=15]
setblock 379 248 302 minecraft:light[level=15]
setblock 379 248 310 minecraft:light[level=15]
fill 387 248 276 388 249 276 minecraft:stripped_oak_log
setblock 387 248 278 minecraft:stripped_oak_log
setblock 387 248 286 minecraft:light[level=15]
setblock 387 248 294 minecraft:light[level=15]
setblock 387 248 302 minecraft:light[level=15]
setblock 387 248 310 minecraft:light[level=15]
fill 388 248 277 388 249 277 minecraft:stripped_oak_log
fill 388 248 279 388 249 279 minecraft:stripped_oak_log
fill 389 248 276 389 249 276 minecraft:red_terracotta
fill 389 248 278 389 249 278 minecraft:stripped_oak_log
fill 390 248 277 390 249 277 minecraft:stripped_oak_log
fill 390 248 279 390 249 279 minecraft:stripped_oak_log
setblock 391 248 276 minecraft:stripped_oak_log
fill 391 248 277 392 249 277 minecraft:red_terracotta
fill 391 248 278 397 249 278 minecraft:stripped_oak_log
setblock 391 248 316 minecraft:stripped_oak_log
fill 392 248 276 393 249 276 minecraft:red_terracotta
fill 392 248 279 392 249 279 minecraft:stripped_oak_log
fill 392 248 316 395 248 316 minecraft:red_terracotta
fill 393 248 315 393 251 315 minecraft:red_terracotta
setblock 394 248 277 minecraft:red_terracotta
fill 394 248 279 394 249 279 minecraft:stripped_oak_log
setblock 395 248 276 minecraft:red_terracotta
setblock 395 248 277 minecraft:stripped_oak_log
setblock 395 248 286 minecraft:light[level=15]
setblock 395 248 294 minecraft:light[level=15]
setblock 395 248 310 minecraft:light[level=15]
setblock 396 248 276 minecraft:stripped_oak_log
setblock 396 248 277 minecraft:red_terracotta
fill 396 248 279 396 249 279 minecraft:stripped_oak_log
setblock 396 248 316 minecraft:stripped_oak_log
fill 397 248 276 397 249 276 minecraft:red_terracotta
fill 397 248 280 397 249 280 minecraft:stripped_oak_log
fill 397 248 282 397 249 282 minecraft:stripped_oak_log
setblock 397 248 315 minecraft:stripped_oak_log
fill 397 248 316 397 251 316 minecraft:red_terracotta
fill 398 248 277 398 249 277 minecraft:stripped_oak_log
fill 398 248 279 398 249 279 minecraft:stripped_oak_log
fill 398 248 281 398 249 281 minecraft:stripped_oak_log
setblock 399 248 276 minecraft:red_terracotta
fill 399 248 278 399 249 278 minecraft:stripped_oak_log
fill 399 248 280 399 249 280 minecraft:stripped_oak_log
fill 399 248 282 399 249 282 minecraft:stripped_oak_log
fill 400 248 276 400 249 277 minecraft:stripped_oak_log
fill 400 248 279 400 249 279 minecraft:stripped_oak_log
fill 400 248 281 400 249 281 minecraft:stripped_oak_log
fill 401 248 276 401 249 276 minecraft:stripped_oak_log
fill 401 248 278 401 249 278 minecraft:stripped_oak_log
fill 401 248 280 401 249 280 minecraft:stripped_oak_log
fill 401 248 282 401 249 282 minecraft:stripped_oak_log
fill 402 248 277 402 249 277 minecraft:stripped_oak_log
fill 402 248 279 402 249 279 minecraft:stripped_oak_log
fill 402 248 281 402 249 281 minecraft:stripped_oak_log
fill 403 248 276 403 249 276 minecraft:stripped_oak_log
fill 403 248 278 403 249 278 minecraft:stripped_oak_log
fill 403 248 280 403 249 280 minecraft:stripped_oak_log
fill 403 248 282 403 249 282 minecraft:stripped_oak_log
setblock 403 248 286 minecraft:light[level=15]
setblock 403 248 294 minecraft:light[level=15]
setblock 403 248 302 minecraft:light[level=15]
setblock 403 248 310 minecraft:light[level=15]
setblock 409 248 294 minecraft:stripped_oak_log
fill 409 248 296 409 249 296 minecraft:stripped_oak_log
fill 409 248 298 409 249 298 minecraft:stripped_oak_log
fill 409 248 300 409 249 300 minecraft:stripped_oak_log
fill 409 248 302 409 249 302 minecraft:stripped_oak_log
fill 409 248 304 409 249 304 minecraft:stripped_oak_log
fill 409 248 306 409 249 306 minecraft:stripped_oak_log
fill 409 248 308 409 249 308 minecraft:stripped_oak_log
setblock 410 248 295 minecraft:stripped_oak_log
fill 410 248 297 410 249 297 minecraft:stripped_oak_log
fill 410 248 299 410 249 299 minecraft:stripped_oak_log
fill 410 248 301 410 249 301 minecraft:stripped_oak_log
fill 410 248 303 410 249 303 minecraft:stripped_oak_log
fill 410 248 305 410 249 305 minecraft:stripped_oak_log
fill 410 248 307 410 249 307 minecraft:stripped_oak_log
setblock 411 248 278 minecraft:light[level=15]
setblock 411 248 286 minecraft:light[level=15]
setblock 411 248 294 minecraft:stripped_oak_log
fill 411 248 296 411 249 296 minecraft:stripped_oak_log
schedule function dropper:buildpart/68_8 1t
