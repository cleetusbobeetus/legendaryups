fill 177 231 290 177 232 290 minecraft:packed_ice
setblock 178 231 276 minecraft:snow_block
fill 178 231 277 178 234 277 minecraft:packed_ice
setblock 178 231 316 minecraft:snow_block
fill 179 231 276 179 234 276 minecraft:packed_ice
fill 179 231 288 179 232 288 minecraft:packed_ice
fill 179 231 290 179 232 290 minecraft:packed_ice
setblock 179 231 295 minecraft:snow_block
fill 179 231 296 179 234 296 minecraft:packed_ice
setblock 179 231 300 minecraft:snow_block
fill 179 231 301 179 232 303 minecraft:packed_ice
setblock 179 231 315 minecraft:snow_block
fill 179 231 316 179 234 316 minecraft:packed_ice
fill 180 231 292 180 231 293 minecraft:packed_ice
setblock 180 231 294 minecraft:snow_block
fill 180 231 295 180 234 295 minecraft:packed_ice
setblock 180 231 299 minecraft:snow_block
fill 180 231 300 180 234 300 minecraft:packed_ice
setblock 180 231 304 minecraft:snow_block
fill 180 231 305 180 233 306 minecraft:packed_ice
fill 180 231 315 180 233 315 minecraft:packed_ice
setblock 181 231 278 minecraft:snow_block
fill 181 231 279 181 234 279 minecraft:packed_ice
setblock 181 231 283 minecraft:snow_block
fill 181 231 284 181 231 287 minecraft:packed_ice
setblock 181 231 288 minecraft:snow_block
fill 181 231 289 181 234 289 minecraft:packed_ice
setblock 181 231 293 minecraft:snow_block
fill 181 231 294 181 234 294 minecraft:packed_ice
setblock 181 231 298 minecraft:snow_block
fill 181 231 299 181 234 299 minecraft:packed_ice
setblock 181 231 303 minecraft:snow_block
fill 181 231 304 181 234 304 minecraft:packed_ice
fill 181 231 306 181 231 307 minecraft:packed_ice
setblock 181 231 308 minecraft:snow_block
fill 181 231 309 181 234 309 minecraft:packed_ice
setblock 181 231 313 minecraft:snow_block
fill 181 231 314 181 232 314 minecraft:packed_ice
setblock 182 231 277 minecraft:snow_block
fill 182 231 278 182 234 278 minecraft:packed_ice
setblock 182 231 281 minecraft:packed_ice
setblock 182 231 282 minecraft:snow_block
fill 182 231 283 182 234 283 minecraft:packed_ice
setblock 182 231 286 minecraft:packed_ice
setblock 182 231 287 minecraft:snow_block
fill 182 231 288 182 234 288 minecraft:packed_ice
setblock 182 231 292 minecraft:snow_block
fill 182 231 293 182 234 293 minecraft:packed_ice
setblock 182 231 297 minecraft:snow_block
fill 182 231 298 182 234 298 minecraft:packed_ice
setblock 182 231 302 minecraft:snow_block
fill 182 231 303 182 234 303 minecraft:packed_ice
setblock 182 231 307 minecraft:snow_block
fill 182 231 308 182 234 308 minecraft:packed_ice
setblock 182 231 312 minecraft:snow_block
fill 182 231 313 182 234 313 minecraft:packed_ice
fill 183 231 300 183 233 302 minecraft:packed_ice
setblock 183 231 303 minecraft:light_blue_concrete
fill 183 231 304 183 238 305 minecraft:packed_ice
fill 141 232 286 141 241 286 minecraft:packed_ice
setblock 142 232 276 minecraft:snow_block
fill 142 232 277 142 235 277 minecraft:packed_ice
setblock 142 232 280 minecraft:packed_ice
setblock 142 232 281 minecraft:snow_block
fill 142 232 282 142 235 282 minecraft:packed_ice
setblock 142 232 286 minecraft:snow_block
fill 142 232 287 142 232 290 minecraft:packed_ice
setblock 142 232 291 minecraft:snow_block
fill 142 232 292 142 235 292 minecraft:packed_ice
setblock 142 232 296 minecraft:snow_block
fill 142 232 297 142 235 297 minecraft:packed_ice
setblock 142 232 301 minecraft:snow_block
fill 142 232 302 142 235 302 minecraft:packed_ice
setblock 142 232 306 minecraft:snow_block
fill 142 232 307 142 235 307 minecraft:packed_ice
setblock 142 232 311 minecraft:snow_block
setblock 142 232 312 minecraft:packed_ice
setblock 142 232 315 minecraft:packed_ice
setblock 142 232 316 minecraft:snow_block
fill 143 232 276 146 232 276 minecraft:packed_ice
setblock 143 232 280 minecraft:snow_block
fill 143 232 281 143 235 281 minecraft:packed_ice
setblock 143 232 285 minecraft:snow_block
fill 143 232 286 143 232 289 minecraft:packed_ice
setblock 143 232 290 minecraft:snow_block
fill 143 232 291 143 234 291 minecraft:packed_ice
setblock 143 232 295 minecraft:snow_block
fill 143 232 296 143 235 296 minecraft:packed_ice
setblock 143 232 300 minecraft:snow_block
fill 143 232 301 143 235 301 minecraft:packed_ice
setblock 143 232 305 minecraft:snow_block
fill 143 232 316 143 234 316 minecraft:packed_ice
setblock 144 232 279 minecraft:snow_block
fill 144 232 280 144 235 280 minecraft:packed_ice
setblock 144 232 284 minecraft:snow_block
fill 144 232 285 144 235 285 minecraft:packed_ice
setblock 144 232 294 minecraft:snow_block
fill 144 232 295 144 233 295 minecraft:packed_ice
setblock 144 232 299 minecraft:snow_block
fill 144 232 300 144 234 300 minecraft:packed_ice
setblock 144 232 306 minecraft:light[level=12]
setblock 144 232 313 minecraft:light[level=12]
setblock 145 232 278 minecraft:snow_block
fill 145 232 279 145 233 279 minecraft:packed_ice
fill 145 232 281 145 233 281 minecraft:packed_ice
fill 145 232 308 145 233 310 minecraft:blue_ice
setblock 146 232 277 minecraft:snow_block
fill 146 232 278 146 237 278 minecraft:packed_ice
setblock 147 232 276 minecraft:snow_block
fill 147 232 277 147 235 277 minecraft:packed_ice
fill 147 232 279 147 237 279 minecraft:packed_ice
setblock 147 232 316 minecraft:snow_block
fill 148 232 276 151 232 276 minecraft:packed_ice
fill 148 232 316 151 232 316 minecraft:packed_ice
setblock 148 232 317 minecraft:light_blue_concrete
setblock 150 232 278 minecraft:snow_block
setblock 151 232 277 minecraft:snow_block
fill 151 232 278 154 232 278 minecraft:packed_ice
setblock 151 232 285 minecraft:light[level=12]
setblock 151 232 292 minecraft:light[level=12]
setblock 151 232 299 minecraft:light[level=12]
setblock 151 232 306 minecraft:light[level=12]
setblock 151 232 313 minecraft:light[level=12]
setblock 152 232 276 minecraft:snow_block
fill 152 232 277 155 232 277 minecraft:packed_ice
setblock 152 232 316 minecraft:snow_block
fill 153 232 276 156 232 276 minecraft:packed_ice
fill 153 232 316 156 232 316 minecraft:packed_ice
setblock 155 232 278 minecraft:snow_block
setblock 156 232 277 minecraft:snow_block
fill 156 232 278 158 232 279 minecraft:packed_ice
fill 156 232 315 157 232 315 minecraft:packed_ice
setblock 157 232 276 minecraft:snow_block
fill 157 232 277 160 232 277 minecraft:packed_ice
setblock 157 232 316 minecraft:snow_block
fill 158 232 276 161 232 276 minecraft:packed_ice
setblock 158 232 306 minecraft:light[level=12]
setblock 158 232 313 minecraft:light[level=12]
setblock 158 232 315 minecraft:snow_block
fill 158 232 316 161 232 316 minecraft:packed_ice
setblock 159 232 278 minecraft:packed_ice
setblock 159 232 279 minecraft:snow_block
setblock 159 232 314 minecraft:snow_block
fill 159 232 315 162 232 315 minecraft:packed_ice
setblock 159 232 317 minecraft:white_concrete
setblock 160 232 278 minecraft:snow_block
fill 160 232 279 160 235 279 minecraft:packed_ice
fill 160 232 314 163 232 314 minecraft:packed_ice
setblock 161 232 277 minecraft:snow_block
fill 161 232 278 161 235 278 minecraft:packed_ice
setblock 162 232 276 minecraft:snow_block
fill 162 232 277 162 235 277 minecraft:packed_ice
setblock 162 232 316 minecraft:snow_block
fill 163 232 276 163 235 276 minecraft:packed_ice
setblock 163 232 315 minecraft:snow_block
fill 163 232 316 166 232 316 minecraft:packed_ice
setblock 164 232 314 minecraft:snow_block
fill 164 232 315 164 235 315 minecraft:packed_ice
fill 164 232 317 164 240 317 minecraft:packed_ice
setblock 165 232 278 minecraft:snow_block
setblock 165 232 306 minecraft:light[level=12]
setblock 165 232 313 minecraft:light[level=12]
setblock 165 232 314 minecraft:packed_ice
setblock 166 232 277 minecraft:snow_block
setblock 166 232 278 minecraft:packed_ice
setblock 167 232 276 minecraft:snow_block
fill 167 232 277 167 233 277 minecraft:packed_ice
setblock 167 232 316 minecraft:snow_block
fill 168 232 276 168 234 276 minecraft:packed_ice
setblock 168 232 315 minecraft:snow_block
fill 168 232 316 168 234 316 minecraft:packed_ice
setblock 169 232 315 minecraft:packed_ice
setblock 172 232 276 minecraft:snow_block
setblock 172 232 278 minecraft:light[level=12]
setblock 172 232 306 minecraft:light[level=12]
setblock 172 232 313 minecraft:light[level=12]
setblock 172 232 316 minecraft:snow_block
fill 173 232 276 173 233 276 minecraft:packed_ice
fill 173 232 316 173 233 316 minecraft:packed_ice
setblock 177 232 276 minecraft:snow_block
fill 177 232 277 177 234 277 minecraft:packed_ice
setblock 177 232 316 minecraft:snow_block
fill 178 232 276 178 235 276 minecraft:packed_ice
setblock 178 232 315 minecraft:snow_block
fill 178 232 316 178 235 316 minecraft:packed_ice
setblock 179 232 278 minecraft:light[level=12]
setblock 179 232 285 minecraft:light[level=12]
setblock 179 232 292 minecraft:light[level=12]
setblock 179 232 295 minecraft:packed_ice
setblock 179 232 298 minecraft:packed_ice
setblock 179 232 299 minecraft:snow_block
fill 179 232 300 179 235 300 minecraft:packed_ice
setblock 179 232 304 minecraft:snow_block
setblock 179 232 306 minecraft:light[level=12]
setblock 179 232 313 minecraft:light[level=12]
fill 179 232 315 179 233 315 minecraft:packed_ice
setblock 180 232 278 minecraft:snow_block
fill 180 232 279 180 233 281 minecraft:packed_ice
setblock 180 232 292 minecraft:packed_ice
setblock 180 232 293 minecraft:snow_block
fill 180 232 294 180 235 294 minecraft:packed_ice
setblock 180 232 298 minecraft:snow_block
fill 180 232 299 180 235 299 minecraft:packed_ice
setblock 180 232 302 minecraft:packed_ice
setblock 180 232 303 minecraft:snow_block
fill 180 232 304 180 235 304 minecraft:packed_ice
setblock 180 232 307 minecraft:packed_ice
setblock 181 232 277 minecraft:snow_block
fill 181 232 278 181 235 278 minecraft:packed_ice
fill 181 232 280 181 232 281 minecraft:packed_ice
setblock 181 232 282 minecraft:snow_block
fill 181 232 283 181 232 286 minecraft:packed_ice
setblock 181 232 287 minecraft:snow_block
fill 181 232 288 181 235 288 minecraft:packed_ice
setblock 181 232 292 minecraft:snow_block
fill 181 232 293 181 235 293 minecraft:packed_ice
setblock 181 232 297 minecraft:snow_block
fill 181 232 298 181 235 298 minecraft:packed_ice
setblock 181 232 302 minecraft:snow_block
fill 181 232 303 181 235 303 minecraft:packed_ice
setblock 181 232 306 minecraft:packed_ice
setblock 181 232 307 minecraft:snow_block
fill 181 232 308 181 235 308 minecraft:packed_ice
setblock 181 232 313 minecraft:packed_ice
setblock 182 232 276 minecraft:snow_block
fill 182 232 277 182 235 277 minecraft:packed_ice
setblock 182 232 281 minecraft:snow_block
fill 182 232 282 182 235 282 minecraft:packed_ice
setblock 182 232 286 minecraft:snow_block
fill 182 232 287 182 235 287 minecraft:packed_ice
setblock 182 232 291 minecraft:snow_block
fill 182 232 292 182 235 292 minecraft:packed_ice
setblock 182 232 296 minecraft:snow_block
fill 182 232 297 182 235 297 minecraft:packed_ice
setblock 182 232 301 minecraft:snow_block
fill 182 232 302 182 235 302 minecraft:packed_ice
setblock 182 232 306 minecraft:snow_block
fill 182 232 307 182 235 307 minecraft:packed_ice
setblock 182 232 311 minecraft:snow_block
fill 182 232 312 182 234 312 minecraft:packed_ice
setblock 182 232 316 minecraft:snow_block
fill 183 232 303 183 244 303 minecraft:packed_ice
setblock 141 233 301 minecraft:white_concrete
fill 142 233 276 145 233 276 minecraft:packed_ice
setblock 142 233 280 minecraft:snow_block
fill 142 233 281 142 236 281 minecraft:packed_ice
setblock 142 233 285 minecraft:snow_block
fill 142 233 286 142 233 289 minecraft:packed_ice
setblock 142 233 290 minecraft:snow_block
fill 142 233 291 142 236 291 minecraft:packed_ice
setblock 142 233 295 minecraft:snow_block
fill 142 233 296 142 236 296 minecraft:packed_ice
setblock 142 233 300 minecraft:snow_block
fill 142 233 301 142 236 301 minecraft:packed_ice
setblock 142 233 305 minecraft:snow_block
fill 142 233 306 142 236 306 minecraft:packed_ice
setblock 142 233 310 minecraft:blue_ice
setblock 142 233 315 minecraft:snow_block
fill 142 233 316 142 235 316 minecraft:packed_ice
setblock 143 233 279 minecraft:snow_block
fill 143 233 280 143 236 280 minecraft:packed_ice
setblock 143 233 284 minecraft:snow_block
fill 143 233 285 143 233 288 minecraft:packed_ice
setblock 143 233 289 minecraft:snow_block
fill 143 233 290 143 235 290 minecraft:packed_ice
setblock 143 233 294 minecraft:snow_block
fill 143 233 295 143 235 295 minecraft:packed_ice
setblock 143 233 299 minecraft:snow_block
fill 143 233 300 143 236 300 minecraft:packed_ice
setblock 143 233 304 minecraft:snow_block
fill 143 233 305 143 234 305 minecraft:packed_ice
setblock 144 233 278 minecraft:snow_block
fill 144 233 279 144 236 279 minecraft:packed_ice
setblock 144 233 283 minecraft:snow_block
fill 144 233 284 144 236 284 minecraft:packed_ice
setblock 144 233 298 minecraft:snow_block
fill 144 233 299 144 234 299 minecraft:packed_ice
setblock 145 233 277 minecraft:snow_block
fill 145 233 278 145 235 278 minecraft:packed_ice
setblock 146 233 276 minecraft:snow_block
fill 146 233 277 146 236 277 minecraft:packed_ice
fill 146 233 309 147 233 309 minecraft:blue_ice
setblock 146 233 316 minecraft:snow_block
fill 147 233 276 150 233 276 minecraft:packed_ice
setblock 147 233 316 minecraft:packed_ice
fill 148 233 317 148 244 317 minecraft:packed_ice
setblock 149 233 278 minecraft:snow_block
setblock 150 233 277 minecraft:snow_block
fill 150 233 278 153 233 278 minecraft:packed_ice
setblock 151 233 276 minecraft:snow_block
fill 151 233 277 154 233 277 minecraft:packed_ice
fill 152 233 276 155 233 276 minecraft:packed_ice
fill 152 233 316 155 233 316 minecraft:packed_ice
setblock 154 233 278 minecraft:snow_block
setblock 155 233 277 minecraft:snow_block
fill 155 233 278 158 233 278 minecraft:packed_ice
setblock 156 233 276 minecraft:snow_block
fill 156 233 277 159 233 277 minecraft:packed_ice
fill 156 233 279 157 233 279 minecraft:packed_ice
setblock 156 233 315 minecraft:packed_ice
setblock 156 233 316 minecraft:snow_block
fill 157 233 276 160 233 276 minecraft:packed_ice
setblock 157 233 315 minecraft:snow_block
fill 157 233 316 160 233 316 minecraft:packed_ice
setblock 158 233 279 minecraft:snow_block
fill 158 233 315 161 233 315 minecraft:packed_ice
setblock 159 233 278 minecraft:snow_block
fill 159 233 279 159 235 279 minecraft:packed_ice
fill 159 233 314 162 233 314 minecraft:packed_ice
fill 159 233 317 159 244 317 minecraft:packed_ice
setblock 160 233 277 minecraft:snow_block
fill 160 233 278 160 236 278 minecraft:packed_ice
setblock 161 233 276 minecraft:snow_block
fill 161 233 277 161 236 277 minecraft:packed_ice
setblock 161 233 316 minecraft:snow_block
fill 162 233 275 162 236 276 minecraft:packed_ice
setblock 162 233 279 minecraft:packed_ice
setblock 162 233 315 minecraft:snow_block
fill 162 233 316 165 233 316 minecraft:packed_ice
fill 163 233 275 163 244 275 minecraft:packed_ice
setblock 163 233 279 minecraft:snow_block
setblock 163 233 314 minecraft:snow_block
fill 163 233 315 163 236 315 minecraft:packed_ice
setblock 164 233 275 minecraft:light_blue_concrete
setblock 164 233 278 minecraft:snow_block
setblock 164 233 314 minecraft:packed_ice
setblock 165 233 277 minecraft:snow_block
setblock 165 233 278 minecraft:packed_ice
fill 165 233 317 165 240 317 minecraft:packed_ice
setblock 166 233 276 minecraft:snow_block
fill 166 233 277 166 234 277 minecraft:packed_ice
setblock 166 233 316 minecraft:snow_block
setblock 166 233 317 minecraft:light_blue_concrete
fill 167 233 276 167 235 276 minecraft:packed_ice
setblock 167 233 315 minecraft:snow_block
fill 167 233 316 167 235 317 minecraft:packed_ice
setblock 171 233 276 minecraft:snow_block
setblock 171 233 316 minecraft:snow_block
setblock 172 233 276 minecraft:packed_ice
setblock 172 233 316 minecraft:packed_ice
setblock 176 233 276 minecraft:snow_block
setblock 176 233 316 minecraft:snow_block
fill 176 233 317 176 244 317 minecraft:packed_ice
fill 177 233 276 177 236 276 minecraft:packed_ice
fill 177 233 311 177 235 311 minecraft:snow_block
fill 177 233 316 177 235 316 minecraft:packed_ice
fill 178 233 310 178 235 310 minecraft:snow_block
fill 178 233 312 178 235 312 minecraft:snow_block
setblock 179 233 278 minecraft:snow_block
setblock 179 233 298 minecraft:snow_block
fill 179 233 299 179 236 299 minecraft:packed_ice
fill 179 233 301 179 233 302 minecraft:packed_ice
setblock 179 233 303 minecraft:snow_block
fill 179 233 304 179 236 304 minecraft:packed_ice
fill 179 233 311 179 235 311 minecraft:snow_block
setblock 180 233 277 minecraft:snow_block
fill 180 233 278 180 234 278 minecraft:packed_ice
setblock 180 233 282 minecraft:snow_block
setblock 180 233 292 minecraft:snow_block
fill 180 233 293 180 234 293 minecraft:packed_ice
setblock 180 233 297 minecraft:snow_block
fill 180 233 298 180 236 298 minecraft:packed_ice
setblock 180 233 302 minecraft:snow_block
fill 180 233 303 180 236 303 minecraft:packed_ice
setblock 180 233 307 minecraft:snow_block
setblock 181 233 276 minecraft:snow_block
fill 181 233 277 181 236 277 minecraft:packed_ice
setblock 181 233 280 minecraft:packed_ice
setblock 181 233 281 minecraft:snow_block
fill 181 233 282 181 233 285 minecraft:packed_ice
setblock 181 233 286 minecraft:snow_block
fill 181 233 287 181 236 287 minecraft:packed_ice
setblock 181 233 291 minecraft:snow_block
fill 181 233 292 181 236 292 minecraft:packed_ice
setblock 181 233 296 minecraft:snow_block
fill 181 233 297 181 236 297 minecraft:packed_ice
setblock 181 233 301 minecraft:snow_block
fill 181 233 302 181 236 302 minecraft:packed_ice
setblock 181 233 306 minecraft:snow_block
fill 181 233 307 181 236 307 minecraft:packed_ice
setblock 181 233 316 minecraft:snow_block
fill 182 233 276 182 236 276 minecraft:packed_ice
setblock 182 233 280 minecraft:snow_block
fill 182 233 281 183 236 281 minecraft:packed_ice
setblock 182 233 285 minecraft:snow_block
fill 182 233 286 182 236 286 minecraft:packed_ice
setblock 182 233 290 minecraft:snow_block
fill 182 233 291 182 236 291 minecraft:packed_ice
setblock 182 233 295 minecraft:snow_block
fill 182 233 296 182 236 296 minecraft:packed_ice
setblock 182 233 300 minecraft:snow_block
fill 182 233 301 182 236 301 minecraft:packed_ice
setblock 182 233 305 minecraft:snow_block
fill 182 233 306 182 236 306 minecraft:packed_ice
setblock 182 233 310 minecraft:snow_block
fill 182 233 311 182 235 311 minecraft:packed_ice
setblock 182 233 315 minecraft:snow_block
fill 182 233 316 182 235 316 minecraft:packed_ice
setblock 183 233 280 minecraft:white_concrete
fill 141 234 301 141 244 301 minecraft:packed_ice
fill 142 234 276 144 234 276 minecraft:packed_ice
setblock 142 234 279 minecraft:snow_block
fill 142 234 280 142 237 280 minecraft:packed_ice
setblock 142 234 284 minecraft:snow_block
fill 142 234 285 142 234 288 minecraft:packed_ice
setblock 142 234 289 minecraft:snow_block
fill 142 234 290 142 237 290 minecraft:packed_ice
setblock 142 234 294 minecraft:snow_block
fill 142 234 295 142 237 295 minecraft:packed_ice
setblock 142 234 299 minecraft:snow_block
fill 142 234 300 142 237 300 minecraft:packed_ice
setblock 142 234 304 minecraft:snow_block
fill 142 234 305 142 237 305 minecraft:packed_ice
setblock 142 234 309 minecraft:snow_block
setblock 142 234 315 minecraft:packed_ice
setblock 143 234 278 minecraft:snow_block
fill 143 234 279 143 237 279 minecraft:packed_ice
setblock 143 234 283 minecraft:snow_block
fill 143 234 284 143 234 287 minecraft:packed_ice
setblock 143 234 288 minecraft:snow_block
fill 143 234 289 143 235 289 minecraft:packed_ice
setblock 143 234 293 minecraft:snow_block
fill 143 234 294 143 235 294 minecraft:packed_ice
setblock 143 234 298 minecraft:snow_block
fill 143 234 299 143 236 299 minecraft:packed_ice
setblock 143 234 303 minecraft:snow_block
fill 143 234 304 143 235 304 minecraft:packed_ice
setblock 144 234 277 minecraft:snow_block
fill 144 234 278 144 236 278 minecraft:packed_ice
setblock 144 234 282 minecraft:snow_block
fill 144 234 283 144 237 283 minecraft:packed_ice
setblock 145 234 276 minecraft:snow_block
fill 145 234 277 145 236 277 minecraft:packed_ice
fill 146 234 276 149 234 276 minecraft:packed_ice
setblock 148 234 278 minecraft:snow_block
setblock 149 234 277 minecraft:snow_block
setblock 150 234 276 minecraft:snow_block
fill 150 234 277 153 234 277 minecraft:packed_ice
setblock 150 234 317 minecraft:light_blue_concrete
fill 151 234 276 154 234 276 minecraft:packed_ice
setblock 152 234 278 minecraft:packed_ice
setblock 153 234 278 minecraft:snow_block
fill 153 234 316 154 234 316 minecraft:packed_ice
setblock 154 234 277 minecraft:snow_block
fill 154 234 278 157 234 278 minecraft:packed_ice
setblock 155 234 276 minecraft:snow_block
fill 155 234 277 158 234 277 minecraft:packed_ice
setblock 155 234 316 minecraft:snow_block
fill 156 234 276 159 234 276 minecraft:packed_ice
setblock 156 234 279 minecraft:packed_ice
setblock 156 234 315 minecraft:snow_block
fill 156 234 316 159 234 316 minecraft:packed_ice
setblock 157 234 279 minecraft:snow_block
fill 157 234 285 172 234 285 minecraft:yellow_concrete
fill 157 234 315 160 234 315 minecraft:packed_ice
setblock 158 234 278 minecraft:snow_block
fill 158 234 279 158 235 279 minecraft:packed_ice
setblock 159 234 277 minecraft:snow_block
fill 159 234 278 159 237 278 minecraft:packed_ice
setblock 160 234 276 minecraft:snow_block
fill 160 234 277 160 237 277 minecraft:packed_ice
fill 160 234 314 161 234 314 minecraft:packed_ice
setblock 160 234 316 minecraft:snow_block
fill 161 234 276 161 237 276 minecraft:packed_ice
setblock 161 234 315 minecraft:snow_block
fill 161 234 316 164 234 316 minecraft:packed_ice
setblock 162 234 279 minecraft:snow_block
setblock 162 234 314 minecraft:snow_block
fill 162 234 315 162 236 315 minecraft:packed_ice
setblock 163 234 278 minecraft:snow_block
fill 164 234 275 164 244 275 minecraft:packed_ice
setblock 164 234 277 minecraft:snow_block
setblock 164 234 278 minecraft:packed_ice
setblock 165 234 276 minecraft:snow_block
fill 165 234 277 165 235 277 minecraft:packed_ice
setblock 165 234 316 minecraft:snow_block
fill 166 234 276 166 235 276 minecraft:packed_ice
setblock 166 234 315 minecraft:snow_block
fill 166 234 316 166 235 317 minecraft:packed_ice
setblock 175 234 276 minecraft:snow_block
setblock 175 234 316 minecraft:snow_block
fill 176 234 276 176 236 276 minecraft:packed_ice
fill 176 234 316 176 235 316 minecraft:packed_ice
setblock 179 234 277 minecraft:snow_block
setblock 179 234 297 minecraft:snow_block
fill 179 234 298 179 235 298 minecraft:packed_ice
setblock 179 234 301 minecraft:packed_ice
setblock 179 234 302 minecraft:snow_block
fill 179 234 303 179 237 303 minecraft:packed_ice
fill 179 234 305 180 234 305 minecraft:packed_ice
setblock 180 234 276 minecraft:snow_block
fill 180 234 277 180 236 277 minecraft:packed_ice
fill 180 234 279 180 234 280 minecraft:packed_ice
setblock 180 234 281 minecraft:snow_block
fill 180 234 282 181 234 284 minecraft:packed_ice
setblock 180 234 296 minecraft:snow_block
fill 180 234 297 180 237 297 minecraft:packed_ice
setblock 180 234 301 minecraft:snow_block
fill 180 234 302 180 237 302 minecraft:packed_ice
setblock 180 234 306 minecraft:snow_block
fill 180 234 307 180 236 307 minecraft:packed_ice
setblock 180 234 316 minecraft:snow_block
fill 181 234 276 181 237 276 minecraft:packed_ice
setblock 181 234 280 minecraft:snow_block
fill 181 234 281 181 237 281 minecraft:packed_ice
setblock 181 234 285 minecraft:snow_block
fill 181 234 286 181 237 286 minecraft:packed_ice
setblock 181 234 290 minecraft:snow_block
fill 181 234 291 181 237 291 minecraft:packed_ice
setblock 181 234 295 minecraft:snow_block
fill 181 234 296 181 237 296 minecraft:packed_ice
setblock 181 234 300 minecraft:snow_block
fill 181 234 301 181 237 301 minecraft:packed_ice
setblock 181 234 305 minecraft:snow_block
fill 181 234 306 181 237 306 minecraft:packed_ice
fill 181 234 316 181 235 316 minecraft:packed_ice
setblock 182 234 279 minecraft:snow_block
fill 182 234 280 183 237 280 minecraft:packed_ice
setblock 182 234 284 minecraft:snow_block
fill 182 234 285 182 237 285 minecraft:packed_ice
setblock 182 234 289 minecraft:snow_block
fill 182 234 290 182 237 290 minecraft:packed_ice
setblock 182 234 294 minecraft:snow_block
fill 182 234 295 182 237 295 minecraft:packed_ice
setblock 182 234 299 minecraft:snow_block
fill 182 234 300 182 237 300 minecraft:packed_ice
setblock 182 234 304 minecraft:snow_block
fill 182 234 305 182 237 305 minecraft:packed_ice
setblock 182 234 309 minecraft:snow_block
fill 182 234 310 182 236 310 minecraft:packed_ice
setblock 182 234 314 minecraft:snow_block
setblock 182 234 315 minecraft:packed_ice
setblock 183 234 300 minecraft:light_blue_concrete
fill 183 234 301 183 240 302 minecraft:packed_ice
setblock 141 235 298 minecraft:white_concrete
fill 142 235 276 143 235 276 minecraft:packed_ice
setblock 142 235 278 minecraft:snow_block
fill 142 235 279 142 238 279 minecraft:packed_ice
setblock 142 235 283 minecraft:snow_block
fill 142 235 284 142 235 287 minecraft:packed_ice
setblock 142 235 288 minecraft:snow_block
fill 142 235 289 142 238 289 minecraft:packed_ice
setblock 142 235 293 minecraft:snow_block
fill 142 235 294 142 237 294 minecraft:packed_ice
setblock 142 235 298 minecraft:snow_block
fill 142 235 299 142 238 299 minecraft:packed_ice
setblock 142 235 303 minecraft:snow_block
fill 142 235 304 142 238 304 minecraft:packed_ice
setblock 142 235 308 minecraft:snow_block
setblock 143 235 277 minecraft:snow_block
fill 143 235 278 143 238 278 minecraft:packed_ice
setblock 143 235 282 minecraft:snow_block
fill 143 235 283 143 235 286 minecraft:packed_ice
setblock 143 235 287 minecraft:snow_block
fill 143 235 288 143 237 288 minecraft:packed_ice
setblock 143 235 297 minecraft:snow_block
fill 143 235 298 143 236 298 minecraft:packed_ice
setblock 143 235 302 minecraft:snow_block
fill 143 235 303 143 236 303 minecraft:packed_ice
setblock 144 235 276 minecraft:snow_block
fill 144 235 277 144 237 277 minecraft:packed_ice
setblock 144 235 281 minecraft:snow_block
fill 144 235 282 144 237 282 minecraft:packed_ice
fill 145 235 276 148 235 276 minecraft:packed_ice
fill 146 235 279 146 237 279 minecraft:packed_ice
fill 147 235 280 147 237 280 minecraft:packed_ice
setblock 148 235 277 minecraft:snow_block
fill 148 235 279 148 237 279 minecraft:packed_ice
setblock 149 235 276 minecraft:snow_block
fill 149 235 277 152 235 277 minecraft:packed_ice
fill 150 235 276 153 235 276 minecraft:packed_ice
fill 150 235 317 150 244 317 minecraft:packed_ice
setblock 153 235 277 minecraft:snow_block
fill 153 235 278 156 235 278 minecraft:packed_ice
setblock 153 235 316 minecraft:packed_ice
setblock 154 235 276 minecraft:snow_block
fill 154 235 277 157 235 277 minecraft:packed_ice
setblock 154 235 316 minecraft:snow_block
fill 155 235 276 158 235 276 minecraft:packed_ice
fill 155 235 316 158 235 316 minecraft:packed_ice
fill 156 235 315 159 235 315 minecraft:packed_ice
setblock 157 235 278 minecraft:snow_block
setblock 157 235 279 minecraft:packed_ice
setblock 158 235 277 minecraft:snow_block
fill 158 235 278 158 237 278 minecraft:packed_ice
setblock 159 235 276 minecraft:snow_block
fill 159 235 277 159 238 277 minecraft:packed_ice
setblock 159 235 316 minecraft:snow_block
fill 160 235 276 160 238 276 minecraft:packed_ice
setblock 160 235 315 minecraft:snow_block
fill 160 235 316 163 235 316 minecraft:packed_ice
fill 161 235 315 161 237 315 minecraft:packed_ice
setblock 162 235 278 minecraft:snow_block
setblock 163 235 277 minecraft:snow_block
setblock 163 235 278 minecraft:packed_ice
setblock 164 235 276 minecraft:snow_block
setblock 164 235 277 minecraft:packed_ice
setblock 164 235 316 minecraft:snow_block
fill 165 235 276 165 236 276 minecraft:packed_ice
fill 165 235 316 165 236 316 minecraft:packed_ice
setblock 175 235 276 minecraft:packed_ice
setblock 177 235 310 minecraft:snow_block
setblock 177 235 312 minecraft:snow_block
setblock 178 235 277 minecraft:snow_block
setblock 179 235 276 minecraft:snow_block
fill 179 235 277 179 236 277 minecraft:packed_ice
setblock 179 235 297 minecraft:packed_ice
setblock 179 235 301 minecraft:snow_block
fill 179 235 302 179 237 302 minecraft:packed_ice
setblock 179 235 305 minecraft:packed_ice
setblock 179 235 310 minecraft:snow_block
setblock 179 235 312 minecraft:snow_block
setblock 179 235 316 minecraft:snow_block
fill 180 235 276 180 237 276 minecraft:packed_ice
setblock 180 235 279 minecraft:packed_ice
setblock 180 235 280 minecraft:snow_block
fill 180 235 281 180 235 284 minecraft:packed_ice
setblock 180 235 295 minecraft:snow_block
fill 180 235 296 180 236 296 minecraft:packed_ice
setblock 180 235 300 minecraft:snow_block
fill 180 235 301 180 238 301 minecraft:packed_ice
setblock 180 235 305 minecraft:snow_block
fill 180 235 306 180 238 306 minecraft:packed_ice
setblock 180 235 316 minecraft:packed_ice
setblock 181 235 279 minecraft:snow_block
fill 181 235 280 181 238 280 minecraft:packed_ice
fill 181 235 282 181 235 283 minecraft:packed_ice
setblock 181 235 284 minecraft:snow_block
fill 181 235 285 181 238 285 minecraft:packed_ice
setblock 181 235 289 minecraft:snow_block
fill 181 235 290 181 238 290 minecraft:packed_ice
setblock 181 235 294 minecraft:snow_block
fill 181 235 295 181 238 295 minecraft:packed_ice
setblock 181 235 299 minecraft:snow_block
fill 181 235 300 181 238 300 minecraft:packed_ice
setblock 181 235 304 minecraft:snow_block
fill 181 235 305 181 238 305 minecraft:packed_ice
setblock 181 235 309 minecraft:snow_block
setblock 182 235 278 minecraft:snow_block
fill 182 235 279 182 238 279 minecraft:packed_ice
setblock 182 235 283 minecraft:snow_block
fill 182 235 284 182 238 284 minecraft:packed_ice
setblock 182 235 288 minecraft:snow_block
fill 182 235 289 182 238 289 minecraft:packed_ice
setblock 182 235 293 minecraft:snow_block
fill 182 235 294 182 238 294 minecraft:packed_ice
setblock 182 235 298 minecraft:snow_block
fill 182 235 299 182 238 299 minecraft:packed_ice
setblock 182 235 303 minecraft:snow_block
fill 182 235 304 182 238 304 minecraft:packed_ice
setblock 182 235 308 minecraft:snow_block
fill 182 235 309 182 238 309 minecraft:packed_ice
fill 183 235 300 183 242 300 minecraft:packed_ice
fill 141 236 298 142 238 298 minecraft:packed_ice
setblock 141 236 299 minecraft:light_blue_concrete
setblock 142 236 276 minecraft:packed_ice
setblock 142 236 277 minecraft:snow_block
fill 142 236 278 142 239 278 minecraft:packed_ice
setblock 142 236 282 minecraft:snow_block
fill 142 236 283 142 236 286 minecraft:packed_ice
setblock 142 236 287 minecraft:snow_block
fill 142 236 288 142 239 288 minecraft:packed_ice
setblock 142 236 292 minecraft:snow_block
fill 142 236 293 142 237 293 minecraft:packed_ice
setblock 142 236 297 minecraft:snow_block
setblock 142 236 302 minecraft:snow_block
fill 142 236 303 142 239 303 minecraft:packed_ice
setblock 142 236 307 minecraft:snow_block
setblock 142 236 308 minecraft:packed_ice
setblock 143 236 276 minecraft:snow_block
fill 143 236 277 143 237 277 minecraft:packed_ice
setblock 143 236 281 minecraft:snow_block
fill 143 236 282 143 236 285 minecraft:packed_ice
setblock 143 236 286 minecraft:snow_block
fill 143 236 287 143 239 287 minecraft:packed_ice
setblock 143 236 301 minecraft:snow_block
setblock 143 236 302 minecraft:packed_ice
fill 144 236 276 147 236 276 minecraft:packed_ice
setblock 144 236 280 minecraft:snow_block
fill 144 236 281 144 237 281 minecraft:packed_ice
setblock 144 236 286 minecraft:light[level=15]
setblock 144 236 294 minecraft:light[level=15]
setblock 144 236 302 minecraft:light[level=15]
setblock 144 236 310 minecraft:light[level=15]
fill 146 236 280 146 237 280 minecraft:packed_ice
setblock 147 236 277 minecraft:snow_block
setblock 148 236 276 minecraft:snow_block
fill 148 236 278 148 237 278 minecraft:packed_ice
fill 148 236 280 148 237 280 minecraft:packed_ice
fill 149 236 276 152 236 276 minecraft:packed_ice
fill 150 236 277 151 236 277 minecraft:packed_ice
setblock 152 236 277 minecraft:snow_block
setblock 152 236 278 minecraft:light[level=15]
setblock 152 236 286 minecraft:light[level=15]
setblock 152 236 294 minecraft:light[level=15]
setblock 152 236 302 minecraft:light[level=15]
setblock 152 236 310 minecraft:light[level=15]
setblock 153 236 276 minecraft:snow_block
fill 153 236 277 156 236 277 minecraft:packed_ice
fill 154 236 276 157 236 276 minecraft:packed_ice
fill 154 236 278 155 236 278 minecraft:packed_ice
fill 154 236 316 157 236 316 minecraft:packed_ice
setblock 156 236 278 minecraft:snow_block
setblock 157 236 277 minecraft:snow_block
fill 157 236 278 157 238 278 minecraft:packed_ice
fill 157 236 315 158 236 315 minecraft:packed_ice
setblock 158 236 276 minecraft:snow_block
fill 158 236 277 158 239 277 minecraft:packed_ice
setblock 158 236 316 minecraft:snow_block
fill 159 236 276 159 239 276 minecraft:packed_ice
setblock 159 236 315 minecraft:snow_block
fill 159 236 316 162 236 316 minecraft:packed_ice
setblock 160 236 286 minecraft:light[level=15]
setblock 160 236 294 minecraft:light[level=15]
setblock 160 236 302 minecraft:light[level=15]
setblock 160 236 310 minecraft:light[level=15]
fill 160 236 315 160 238 315 minecraft:packed_ice
setblock 161 236 278 minecraft:snow_block
setblock 162 236 277 minecraft:snow_block
setblock 163 236 276 minecraft:snow_block
setblock 163 236 277 minecraft:packed_ice
setblock 163 236 316 minecraft:snow_block
fill 164 236 276 164 237 276 minecraft:packed_ice
fill 164 236 316 164 237 316 minecraft:packed_ice
fill 166 236 317 167 244 317 minecraft:packed_ice
setblock 168 236 278 minecraft:light[level=15]
setblock 168 236 286 minecraft:light[level=15]
setblock 168 236 294 minecraft:light[level=15]
setblock 168 236 302 minecraft:light[level=15]
setblock 168 236 310 minecraft:light[level=15]
setblock 176 236 278 minecraft:light[level=15]
setblock 176 236 286 minecraft:light[level=15]
setblock 176 236 294 minecraft:light[level=15]
setblock 176 236 302 minecraft:light[level=15]
setblock 176 236 310 minecraft:light[level=15]
setblock 178 236 276 minecraft:snow_block
fill 179 236 276 179 238 276 minecraft:packed_ice
setblock 179 236 300 minecraft:snow_block
fill 179 236 301 179 237 301 minecraft:packed_ice
fill 180 236 280 180 236 283 minecraft:packed_ice
setblock 180 236 284 minecraft:snow_block
fill 180 236 285 180 239 285 minecraft:packed_ice
setblock 180 236 295 minecraft:packed_ice
setblock 180 236 299 minecraft:snow_block
fill 180 236 300 180 238 300 minecraft:packed_ice
setblock 180 236 304 minecraft:snow_block
fill 180 236 305 180 239 305 minecraft:packed_ice
setblock 181 236 278 minecraft:snow_block
fill 181 236 279 181 238 279 minecraft:packed_ice
setblock 181 236 282 minecraft:packed_ice
setblock 181 236 283 minecraft:snow_block
fill 181 236 284 181 239 284 minecraft:packed_ice
setblock 181 236 288 minecraft:snow_block
fill 181 236 289 181 239 289 minecraft:packed_ice
setblock 181 236 293 minecraft:snow_block
fill 181 236 294 181 237 294 minecraft:packed_ice
setblock 181 236 298 minecraft:snow_block
fill 181 236 299 181 239 299 minecraft:packed_ice
setblock 181 236 303 minecraft:snow_block
fill 181 236 304 181 239 304 minecraft:packed_ice
setblock 181 236 308 minecraft:snow_block
setblock 182 236 277 minecraft:snow_block
fill 182 236 278 182 239 278 minecraft:packed_ice
setblock 182 236 282 minecraft:snow_block
fill 182 236 283 182 239 283 minecraft:packed_ice
setblock 182 236 287 minecraft:snow_block
fill 182 236 288 182 239 288 minecraft:packed_ice
setblock 182 236 292 minecraft:snow_block
fill 182 236 293 182 239 293 minecraft:packed_ice
setblock 182 236 297 minecraft:snow_block
fill 182 236 298 182 239 298 minecraft:packed_ice
setblock 182 236 302 minecraft:snow_block
fill 182 236 303 182 239 303 minecraft:packed_ice
setblock 182 236 307 minecraft:snow_block
fill 182 236 308 182 239 308 minecraft:packed_ice
fill 141 237 299 141 245 299 minecraft:packed_ice
setblock 142 237 276 minecraft:snow_block
fill 142 237 277 142 240 277 minecraft:packed_ice
setblock 142 237 281 minecraft:snow_block
fill 142 237 282 142 237 285 minecraft:packed_ice
setblock 142 237 286 minecraft:snow_block
fill 142 237 287 142 240 287 minecraft:packed_ice
setblock 142 237 291 minecraft:snow_block
fill 142 237 292 142 238 292 minecraft:packed_ice
setblock 142 237 296 minecraft:snow_block
setblock 142 237 297 minecraft:packed_ice
setblock 142 237 301 minecraft:snow_block
fill 142 237 302 142 239 302 minecraft:packed_ice
setblock 142 237 306 minecraft:snow_block
fill 142 237 307 142 238 307 minecraft:packed_ice
fill 143 237 276 146 237 276 minecraft:packed_ice
setblock 143 237 280 minecraft:snow_block
fill 143 237 281 143 237 284 minecraft:packed_ice
setblock 143 237 285 minecraft:snow_block
fill 143 237 286 143 240 286 minecraft:packed_ice
setblock 144 237 280 minecraft:packed_ice
setblock 144 237 284 minecraft:snow_block
fill 145 237 317 145 241 317 minecraft:packed_ice
setblock 146 237 317 minecraft:white_concrete
setblock 147 237 276 minecraft:snow_block
fill 148 237 276 151 237 276 minecraft:packed_ice
setblock 152 237 276 minecraft:snow_block
fill 152 237 277 155 237 277 minecraft:packed_ice
fill 153 237 276 156 237 276 minecraft:packed_ice
fill 154 237 316 156 237 316 minecraft:packed_ice
setblock 155 237 278 minecraft:snow_block
setblock 156 237 277 minecraft:snow_block
fill 156 237 278 156 238 278 minecraft:packed_ice
setblock 157 237 276 minecraft:snow_block
fill 157 237 277 157 240 277 minecraft:packed_ice
setblock 157 237 315 minecraft:packed_ice
setblock 157 237 316 minecraft:snow_block
fill 158 237 276 158 240 276 minecraft:packed_ice
setblock 158 237 315 minecraft:snow_block
fill 158 237 316 161 237 316 minecraft:packed_ice
fill 159 237 315 159 240 315 minecraft:packed_ice
setblock 160 237 278 minecraft:snow_block
setblock 161 237 277 minecraft:snow_block
fill 162 237 275 162 244 275 minecraft:packed_ice
setblock 162 237 276 minecraft:snow_block
setblock 162 237 277 minecraft:packed_ice
setblock 162 237 316 minecraft:snow_block
setblock 163 237 276 minecraft:packed_ice
fill 163 237 316 163 238 316 minecraft:packed_ice
setblock 177 237 276 minecraft:snow_block
setblock 178 237 276 minecraft:packed_ice
setblock 179 237 300 minecraft:packed_ice
setblock 179 237 304 minecraft:snow_block
fill 180 237 281 180 237 282 minecraft:packed_ice
setblock 180 237 283 minecraft:snow_block
fill 180 237 284 180 240 284 minecraft:packed_ice
setblock 180 237 298 minecraft:snow_block
fill 180 237 299 180 238 299 minecraft:packed_ice
setblock 180 237 303 minecraft:snow_block
fill 180 237 304 180 240 304 minecraft:packed_ice
setblock 181 237 278 minecraft:packed_ice
setblock 181 237 282 minecraft:snow_block
fill 181 237 283 181 240 283 minecraft:packed_ice
setblock 181 237 287 minecraft:snow_block
fill 181 237 288 181 240 288 minecraft:packed_ice
setblock 181 237 292 minecraft:snow_block
setblock 181 237 293 minecraft:packed_ice
setblock 181 237 297 minecraft:snow_block
fill 181 237 298 181 239 298 minecraft:packed_ice
setblock 181 237 302 minecraft:snow_block
fill 181 237 303 181 240 303 minecraft:packed_ice
setblock 181 237 307 minecraft:snow_block
fill 181 237 308 181 238 308 minecraft:packed_ice
setblock 182 237 276 minecraft:snow_block
fill 182 237 277 182 238 277 minecraft:packed_ice
setblock 182 237 281 minecraft:snow_block
fill 182 237 282 182 240 282 minecraft:packed_ice
setblock 182 237 286 minecraft:snow_block
fill 182 237 287 182 240 287 minecraft:packed_ice
setblock 182 237 291 minecraft:snow_block
fill 182 237 292 182 240 292 minecraft:packed_ice
setblock 182 237 296 minecraft:snow_block
fill 182 237 297 182 240 297 minecraft:packed_ice
setblock 182 237 301 minecraft:snow_block
fill 182 237 302 182 240 302 minecraft:packed_ice
setblock 182 237 306 minecraft:snow_block
fill 182 237 307 182 240 307 minecraft:packed_ice
fill 183 237 281 183 244 281 minecraft:packed_ice
fill 142 238 276 145 238 276 minecraft:packed_ice
setblock 142 238 280 minecraft:snow_block
fill 142 238 281 142 238 284 minecraft:packed_ice
setblock 142 238 285 minecraft:snow_block
fill 142 238 286 142 241 286 minecraft:packed_ice
setblock 142 238 290 minecraft:snow_block
fill 142 238 291 142 241 291 minecraft:packed_ice
setblock 142 238 300 minecraft:snow_block
fill 142 238 301 142 239 301 minecraft:packed_ice
setblock 142 238 305 minecraft:snow_block
fill 142 238 306 142 240 306 minecraft:packed_ice
setblock 143 238 279 minecraft:snow_block
fill 143 238 280 143 238 283 minecraft:packed_ice
setblock 143 238 284 minecraft:snow_block
fill 143 238 285 143 241 285 minecraft:packed_ice
setblock 144 238 278 minecraft:light[level=12]
setblock 144 238 285 minecraft:light[level=12]
setblock 144 238 292 minecraft:light[level=12]
setblock 144 238 299 minecraft:light[level=12]
setblock 144 238 306 minecraft:light[level=12]
setblock 144 238 313 minecraft:light[level=12]
fill 146 238 317 146 244 317 minecraft:packed_ice
setblock 150 238 276 minecraft:packed_ice
setblock 151 238 276 minecraft:snow_block
setblock 151 238 278 minecraft:light[level=12]
setblock 151 238 285 minecraft:light[level=12]
setblock 151 238 292 minecraft:light[level=12]
setblock 151 238 299 minecraft:light[level=12]
setblock 151 238 306 minecraft:light[level=12]
setblock 151 238 313 minecraft:light[level=12]
fill 152 238 276 155 238 276 minecraft:packed_ice
fill 152 238 317 154 242 317 minecraft:packed_ice
fill 153 238 277 154 238 277 minecraft:packed_ice
fill 154 238 316 155 238 316 minecraft:packed_ice
setblock 155 238 277 minecraft:snow_block
setblock 155 238 317 minecraft:white_concrete
setblock 156 238 276 minecraft:snow_block
fill 156 238 277 156 241 277 minecraft:packed_ice
setblock 156 238 316 minecraft:snow_block
fill 157 238 276 157 241 276 minecraft:packed_ice
setblock 157 238 315 minecraft:snow_block
fill 157 238 316 160 238 316 minecraft:packed_ice
setblock 158 238 278 minecraft:light[level=12]
setblock 158 238 285 minecraft:light[level=12]
setblock 158 238 292 minecraft:light[level=12]
setblock 158 238 299 minecraft:light[level=12]
setblock 158 238 306 minecraft:light[level=12]
setblock 158 238 313 minecraft:light[level=12]
fill 158 238 315 158 241 315 minecraft:packed_ice
setblock 160 238 277 minecraft:snow_block
setblock 161 238 276 minecraft:snow_block
setblock 161 238 316 minecraft:snow_block
setblock 162 238 276 minecraft:packed_ice
fill 162 238 316 162 239 316 minecraft:packed_ice
fill 163 238 314 164 239 315 minecraft:white_concrete
setblock 165 238 278 minecraft:light[level=12]
setblock 165 238 285 minecraft:light[level=12]
setblock 165 238 292 minecraft:light[level=12]
setblock 165 238 299 minecraft:light[level=12]
setblock 165 238 306 minecraft:light[level=12]
setblock 165 238 313 minecraft:light[level=12]
setblock 172 238 275 minecraft:light_blue_concrete
setblock 172 238 278 minecraft:light[level=12]
setblock 172 238 285 minecraft:light[level=12]
setblock 172 238 292 minecraft:light[level=12]
setblock 172 238 299 minecraft:light[level=12]
setblock 172 238 306 minecraft:light[level=12]
setblock 172 238 313 minecraft:light[level=12]
setblock 179 238 278 minecraft:light[level=12]
setblock 179 238 285 minecraft:light[level=12]
setblock 179 238 292 minecraft:light[level=12]
setblock 179 238 299 minecraft:light[level=12]
setblock 179 238 306 minecraft:light[level=12]
setblock 179 238 313 minecraft:light[level=12]
setblock 180 238 282 minecraft:snow_block
fill 180 238 283 180 241 283 minecraft:packed_ice
setblock 180 238 286 minecraft:packed_ice
setblock 180 238 302 minecraft:snow_block
fill 180 238 303 180 240 303 minecraft:packed_ice
setblock 181 238 281 minecraft:snow_block
fill 181 238 282 181 241 282 minecraft:packed_ice
setblock 181 238 286 minecraft:snow_block
fill 181 238 287 181 241 287 minecraft:packed_ice
setblock 181 238 296 minecraft:snow_block
setblock 181 238 297 minecraft:packed_ice
setblock 181 238 301 minecraft:snow_block
fill 181 238 302 181 241 302 minecraft:packed_ice
setblock 181 238 306 minecraft:snow_block
fill 181 238 307 181 241 307 minecraft:packed_ice
setblock 182 238 280 minecraft:snow_block
fill 182 238 281 182 241 281 minecraft:packed_ice
setblock 182 238 285 minecraft:snow_block
fill 182 238 286 182 241 286 minecraft:packed_ice
setblock 182 238 290 minecraft:snow_block
fill 182 238 291 182 241 291 minecraft:packed_ice
setblock 182 238 295 minecraft:snow_block
fill 182 238 296 182 240 296 minecraft:packed_ice
setblock 182 238 300 minecraft:snow_block
fill 182 238 301 182 241 301 minecraft:packed_ice
setblock 182 238 305 minecraft:snow_block
fill 182 238 306 182 241 306 minecraft:packed_ice
fill 183 238 280 183 244 280 minecraft:packed_ice
fill 141 239 298 141 244 298 minecraft:packed_ice
fill 142 239 276 143 239 276 minecraft:packed_ice
setblock 142 239 279 minecraft:snow_block
fill 142 239 280 142 239 283 minecraft:packed_ice
setblock 142 239 284 minecraft:snow_block
fill 142 239 285 142 242 285 minecraft:packed_ice
setblock 142 239 289 minecraft:snow_block
fill 142 239 290 142 242 290 minecraft:packed_ice
setblock 142 239 304 minecraft:snow_block
fill 142 239 305 142 240 305 minecraft:packed_ice
fill 143 239 279 143 239 282 minecraft:packed_ice
setblock 143 239 283 minecraft:snow_block
fill 143 239 284 143 242 284 minecraft:packed_ice
fill 151 239 276 154 239 276 minecraft:packed_ice
setblock 153 239 277 minecraft:packed_ice
setblock 154 239 277 minecraft:snow_block
setblock 154 239 316 minecraft:packed_ice
setblock 155 239 276 minecraft:snow_block
fill 155 239 277 155 242 277 minecraft:packed_ice
setblock 155 239 316 minecraft:snow_block
fill 155 239 317 155 244 317 minecraft:packed_ice
fill 156 239 276 156 242 276 minecraft:packed_ice
fill 156 239 316 159 239 316 minecraft:packed_ice
fill 157 239 315 157 242 315 minecraft:packed_ice
setblock 159 239 277 minecraft:snow_block
setblock 160 239 276 minecraft:snow_block
setblock 160 239 316 minecraft:snow_block
setblock 161 239 276 minecraft:packed_ice
fill 161 239 316 161 242 316 minecraft:packed_ice
fill 172 239 275 172 244 275 minecraft:packed_ice
setblock 180 239 286 minecraft:snow_block
setblock 180 239 301 minecraft:snow_block
setblock 180 239 302 minecraft:packed_ice
setblock 181 239 280 minecraft:snow_block
fill 181 239 281 181 242 281 minecraft:packed_ice
setblock 181 239 285 minecraft:snow_block
fill 181 239 286 181 242 286 minecraft:packed_ice
setblock 181 239 290 minecraft:snow_block
setblock 181 239 300 minecraft:snow_block
fill 181 239 301 181 241 301 minecraft:packed_ice
setblock 181 239 305 minecraft:snow_block
fill 181 239 306 181 242 306 minecraft:packed_ice
setblock 182 239 279 minecraft:snow_block
fill 182 239 280 182 242 280 minecraft:packed_ice
setblock 182 239 284 minecraft:snow_block
fill 182 239 285 182 242 285 minecraft:packed_ice
setblock 182 239 289 minecraft:snow_block
fill 182 239 290 182 242 290 minecraft:packed_ice
setblock 182 239 294 minecraft:snow_block
fill 182 239 295 182 240 295 minecraft:packed_ice
setblock 182 239 299 minecraft:snow_block
fill 182 239 300 182 242 300 minecraft:packed_ice
setblock 182 239 304 minecraft:snow_block
fill 182 239 305 183 241 305 minecraft:packed_ice
setblock 182 239 309 minecraft:snow_block
setblock 183 239 294 minecraft:white_concrete
setblock 183 239 304 minecraft:white_concrete
setblock 142 240 276 minecraft:packed_ice
setblock 142 240 278 minecraft:snow_block
fill 142 240 279 142 240 282 minecraft:packed_ice
setblock 142 240 283 minecraft:snow_block
fill 142 240 284 142 243 284 minecraft:packed_ice
setblock 142 240 288 minecraft:snow_block
fill 142 240 289 142 243 289 minecraft:packed_ice
setblock 142 240 304 minecraft:packed_ice
fill 143 240 280 143 240 281 minecraft:packed_ice
setblock 143 240 282 minecraft:snow_block
fill 143 240 283 143 243 283 minecraft:packed_ice
setblock 143 240 287 minecraft:snow_block
fill 151 240 276 153 240 276 minecraft:packed_ice
setblock 153 240 316 minecraft:packed_ice
setblock 154 240 276 minecraft:snow_block
fill 154 240 277 154 243 277 minecraft:packed_ice
setblock 154 240 316 minecraft:snow_block
fill 155 240 276 155 243 276 minecraft:packed_ice
fill 155 240 316 158 240 316 minecraft:packed_ice
fill 156 240 315 156 243 315 minecraft:packed_ice
setblock 158 240 277 minecraft:snow_block
setblock 159 240 276 minecraft:snow_block
setblock 159 240 316 minecraft:snow_block
setblock 160 240 276 minecraft:packed_ice
fill 160 240 316 160 243 316 minecraft:packed_ice
fill 173 240 317 173 244 317 minecraft:packed_ice
setblock 174 240 317 minecraft:white_concrete
fill 175 240 317 175 244 317 minecraft:packed_ice
setblock 180 240 285 minecraft:snow_block
fill 180 240 286 180 242 287 minecraft:packed_ice
setblock 181 240 284 minecraft:snow_block
fill 181 240 285 181 243 285 minecraft:packed_ice
setblock 181 240 289 minecraft:snow_block
fill 181 240 290 181 242 291 minecraft:packed_ice
setblock 181 240 300 minecraft:packed_ice
setblock 181 240 304 minecraft:snow_block
fill 181 240 305 181 243 305 minecraft:packed_ice
fill 182 240 279 182 242 279 minecraft:packed_ice
setblock 182 240 283 minecraft:snow_block
fill 182 240 284 182 243 284 minecraft:packed_ice
setblock 182 240 288 minecraft:snow_block
fill 182 240 289 182 243 289 minecraft:packed_ice
setblock 182 240 293 minecraft:snow_block
fill 182 240 294 183 243 294 minecraft:packed_ice
setblock 182 240 298 minecraft:snow_block
fill 182 240 299 182 241 299 minecraft:packed_ice
setblock 182 240 303 minecraft:snow_block
fill 182 240 304 183 243 304 minecraft:packed_ice
setblock 182 240 308 minecraft:snow_block
fill 182 240 309 182 243 309 minecraft:packed_ice
fill 141 241 281 141 241 282 minecraft:snow_block
fill 141 241 283 141 241 284 minecraft:packed_ice
setblock 141 241 285 minecraft:snow_block
setblock 141 241 290 minecraft:snow_block
fill 141 241 291 141 244 293 minecraft:packed_ice
fill 141 241 311 141 241 312 minecraft:snow_block
fill 141 241 315 141 244 315 minecraft:packed_ice
setblock 141 241 316 minecraft:snow_block
fill 142 241 275 142 242 275 minecraft:snow_block
setblock 142 241 277 minecraft:snow_block
fill 142 241 278 142 241 281 minecraft:packed_ice
setblock 142 241 282 minecraft:snow_block
fill 142 241 283 142 244 283 minecraft:packed_ice
setblock 142 241 287 minecraft:snow_block
fill 142 241 288 142 244 288 minecraft:packed_ice
setblock 143 241 280 minecraft:packed_ice
setblock 143 241 281 minecraft:snow_block
fill 143 241 282 143 244 282 minecraft:packed_ice
setblock 143 241 286 minecraft:snow_block
fill 143 241 287 143 244 287 minecraft:packed_ice
setblock 144 241 275 minecraft:white_concrete
fill 144 241 317 144 242 317 minecraft:snow_block
fill 145 241 275 146 244 275 minecraft:packed_ice
fill 151 241 276 152 241 276 minecraft:packed_ice
setblock 151 241 317 minecraft:snow_block
setblock 152 241 316 minecraft:packed_ice
setblock 153 241 276 minecraft:snow_block
setblock 153 241 316 minecraft:snow_block
fill 154 241 276 154 244 276 minecraft:packed_ice
setblock 154 241 315 minecraft:snow_block
fill 154 241 316 157 241 316 minecraft:packed_ice
fill 155 241 315 155 244 315 minecraft:packed_ice
setblock 157 241 277 minecraft:snow_block
setblock 158 241 276 minecraft:snow_block
setblock 158 241 316 minecraft:snow_block
fill 159 241 276 159 243 276 minecraft:packed_ice
setblock 159 241 315 minecraft:snow_block
fill 159 241 316 159 244 316 minecraft:packed_ice
fill 164 241 317 165 241 317 minecraft:snow_block
fill 174 241 317 174 244 317 minecraft:packed_ice
setblock 180 241 284 minecraft:snow_block
fill 180 241 285 180 244 285 minecraft:packed_ice
setblock 180 241 288 minecraft:packed_ice
setblock 180 241 289 minecraft:snow_block
setblock 181 241 283 minecraft:snow_block
fill 181 241 284 181 244 284 minecraft:packed_ice
setblock 181 241 288 minecraft:snow_block
fill 181 241 289 181 244 289 minecraft:packed_ice
setblock 181 241 303 minecraft:snow_block
fill 181 241 304 181 242 304 minecraft:packed_ice
setblock 182 241 282 minecraft:snow_block
fill 182 241 283 182 244 283 minecraft:packed_ice
setblock 182 241 287 minecraft:snow_block
fill 182 241 288 182 244 288 minecraft:packed_ice
setblock 182 241 292 minecraft:snow_block
fill 182 241 293 182 244 293 minecraft:packed_ice
setblock 182 241 298 minecraft:packed_ice
setblock 182 241 302 minecraft:snow_block
fill 182 241 303 182 244 303 minecraft:packed_ice
setblock 182 241 307 minecraft:snow_block
fill 182 241 308 182 244 308 minecraft:packed_ice
setblock 183 241 283 minecraft:snow_block
setblock 183 241 291 minecraft:snow_block
fill 183 241 301 183 244 301 minecraft:packed_ice
setblock 183 241 302 minecraft:white_concrete
setblock 183 241 310 minecraft:snow_block
fill 183 241 312 183 244 312 minecraft:packed_ice
setblock 183 241 313 minecraft:snow_block
fill 183 241 314 183 244 314 minecraft:packed_ice
fill 141 242 281 141 244 282 minecraft:packed_ice
setblock 141 242 283 minecraft:snow_block
fill 141 242 284 141 244 285 minecraft:packed_ice
fill 141 242 286 142 242 286 minecraft:snow_block
setblock 141 242 288 minecraft:light_blue_concrete
fill 141 242 290 141 243 290 minecraft:packed_ice
setblock 141 242 294 minecraft:snow_block
fill 141 242 295 141 245 295 minecraft:packed_ice
setblock 141 242 296 minecraft:snow_block
fill 141 242 297 141 244 297 minecraft:packed_ice
setblock 141 242 302 minecraft:snow_block
fill 141 242 307 141 244 307 minecraft:packed_ice
setblock 141 242 308 minecraft:snow_block
setblock 141 242 311 minecraft:snow_block
fill 141 242 312 141 244 312 minecraft:packed_ice
setblock 141 242 316 minecraft:packed_ice
fill 142 242 277 142 242 280 minecraft:packed_ice
setblock 142 242 281 minecraft:snow_block
fill 142 242 282 142 245 282 minecraft:packed_ice
fill 142 242 287 142 245 287 minecraft:packed_ice
setblock 142 242 291 minecraft:snow_block
fill 143 242 281 143 243 281 minecraft:packed_ice
setblock 143 242 285 minecraft:snow_block
fill 143 242 286 143 245 286 minecraft:packed_ice
fill 143 242 288 143 243 288 minecraft:packed_ice
fill 144 242 275 144 244 275 minecraft:packed_ice
setblock 145 242 317 minecraft:snow_block
fill 150 242 276 151 242 276 minecraft:packed_ice
fill 151 242 316 151 242 317 minecraft:packed_ice
setblock 152 242 276 minecraft:snow_block
setblock 152 242 316 minecraft:snow_block
fill 153 242 276 153 244 277 minecraft:packed_ice
setblock 153 242 315 minecraft:snow_block
fill 153 242 316 156 242 316 minecraft:packed_ice
fill 154 242 315 154 245 315 minecraft:packed_ice
setblock 156 242 277 minecraft:snow_block
fill 156 242 314 156 244 314 minecraft:packed_ice
setblock 157 242 276 minecraft:snow_block
fill 157 242 316 157 242 317 minecraft:snow_block
fill 158 242 276 158 245 276 minecraft:packed_ice
setblock 158 242 315 minecraft:snow_block
fill 158 242 316 158 245 316 minecraft:packed_ice
fill 159 242 315 159 245 315 minecraft:packed_ice
fill 160 242 317 160 245 317 minecraft:packed_ice
setblock 161 242 275 minecraft:snow_block
setblock 161 242 317 minecraft:snow_block
fill 162 242 317 162 244 317 minecraft:packed_ice
setblock 164 242 317 minecraft:snow_block
fill 165 242 317 165 244 317 minecraft:packed_ice
setblock 167 242 275 minecraft:snow_block
fill 177 242 308 177 246 308 minecraft:packed_ice
setblock 180 242 283 minecraft:snow_block
fill 180 242 284 180 245 284 minecraft:packed_ice
setblock 180 242 288 minecraft:snow_block
fill 180 242 289 180 244 290 minecraft:packed_ice
setblock 181 242 282 minecraft:snow_block
fill 181 242 283 181 245 283 minecraft:packed_ice
setblock 181 242 287 minecraft:snow_block
fill 181 242 288 181 245 288 minecraft:packed_ice
setblock 181 242 292 minecraft:snow_block
setblock 181 242 303 minecraft:packed_ice
setblock 181 242 307 minecraft:snow_block
setblock 182 242 281 minecraft:snow_block
fill 182 242 282 182 245 282 minecraft:packed_ice
setblock 182 242 286 minecraft:snow_block
fill 182 242 287 182 245 287 minecraft:packed_ice
setblock 182 242 291 minecraft:snow_block
fill 182 242 292 182 245 292 minecraft:packed_ice
setblock 182 242 301 minecraft:snow_block
fill 182 242 302 182 243 302 minecraft:packed_ice
setblock 182 242 305 minecraft:packed_ice
setblock 182 242 306 minecraft:snow_block
fill 182 242 307 182 245 307 minecraft:packed_ice
setblock 183 242 276 minecraft:snow_block
fill 183 242 283 183 244 283 minecraft:packed_ice
setblock 183 242 291 minecraft:packed_ice
fill 183 242 302 183 243 302 minecraft:snow_block
setblock 183 242 305 minecraft:snow_block
setblock 183 242 308 minecraft:light_blue_concrete
fill 183 242 310 183 244 310 minecraft:packed_ice
fill 183 242 313 183 244 313 minecraft:packed_ice
fill 141 243 283 141 244 283 minecraft:light_blue_concrete
fill 141 243 286 142 243 286 minecraft:packed_ice
setblock 141 243 287 minecraft:light_blue_concrete
fill 141 243 288 141 244 288 minecraft:packed_ice
fill 141 243 294 141 244 294 minecraft:packed_ice
fill 141 243 296 141 246 296 minecraft:packed_ice
fill 141 243 302 141 244 302 minecraft:packed_ice
fill 141 243 308 142 244 308 minecraft:packed_ice
fill 141 243 311 141 244 311 minecraft:packed_ice
setblock 141 243 313 minecraft:snow_block
setblock 141 243 316 minecraft:snow_block
fill 142 243 275 142 245 275 minecraft:packed_ice
fill 142 243 277 142 243 279 minecraft:packed_ice
setblock 142 243 280 minecraft:snow_block
fill 142 243 281 142 246 281 minecraft:packed_ice
setblock 142 243 285 minecraft:snow_block
setblock 142 243 290 minecraft:snow_block
fill 142 243 291 142 246 291 minecraft:packed_ice
fill 142 243 307 142 245 307 minecraft:packed_ice
setblock 142 243 309 minecraft:packed_ice
setblock 143 243 284 minecraft:snow_block
fill 143 243 285 143 246 285 minecraft:packed_ice
setblock 143 243 317 minecraft:snow_block
fill 144 243 317 145 244 317 minecraft:packed_ice
fill 149 243 276 150 243 276 minecraft:packed_ice
fill 149 243 316 150 243 316 minecraft:packed_ice
setblock 151 243 276 minecraft:snow_block
setblock 151 243 315 minecraft:packed_ice
setblock 151 243 316 minecraft:snow_block
fill 151 243 317 153 244 317 minecraft:packed_ice
fill 152 243 276 152 245 277 minecraft:packed_ice
setblock 152 243 315 minecraft:snow_block
fill 152 243 316 155 243 316 minecraft:packed_ice
setblock 153 243 314 minecraft:snow_block
fill 153 243 315 153 246 315 minecraft:packed_ice
fill 154 243 314 155 245 314 minecraft:packed_ice
setblock 154 243 317 minecraft:snow_block
setblock 155 243 277 minecraft:snow_block
setblock 156 243 276 minecraft:snow_block
fill 156 243 277 156 245 277 minecraft:packed_ice
setblock 156 243 316 minecraft:snow_block
fill 157 243 276 157 246 276 minecraft:packed_ice
setblock 157 243 314 minecraft:packed_ice
setblock 157 243 315 minecraft:snow_block
fill 157 243 316 157 244 317 minecraft:packed_ice
setblock 158 243 314 minecraft:snow_block
fill 158 243 315 158 246 315 minecraft:packed_ice
fill 160 243 315 160 244 315 minecraft:packed_ice
fill 161 243 275 161 244 275 minecraft:packed_ice
setblock 161 243 316 minecraft:snow_block
fill 161 243 317 161 244 317 minecraft:packed_ice
setblock 163 243 317 minecraft:snow_block
fill 164 243 317 164 244 317 minecraft:packed_ice
fill 167 243 275 167 244 275 minecraft:packed_ice
setblock 171 243 317 minecraft:snow_block
fill 179 243 286 179 243 287 minecraft:packed_ice
fill 180 243 283 180 244 283 minecraft:packed_ice
setblock 180 243 286 minecraft:packed_ice
setblock 180 243 287 minecraft:snow_block
fill 180 243 288 180 246 288 minecraft:packed_ice
setblock 180 243 291 minecraft:packed_ice
setblock 181 243 281 minecraft:snow_block
fill 181 243 282 181 246 282 minecraft:packed_ice
setblock 181 243 286 minecraft:snow_block
fill 181 243 287 181 246 287 minecraft:packed_ice
setblock 181 243 290 minecraft:packed_ice
setblock 181 243 291 minecraft:snow_block
fill 181 243 292 181 245 293 minecraft:packed_ice
setblock 181 243 306 minecraft:snow_block
setblock 181 243 307 minecraft:packed_ice
setblock 182 243 280 minecraft:snow_block
fill 182 243 281 182 246 281 minecraft:packed_ice
setblock 182 243 285 minecraft:snow_block
fill 182 243 286 183 244 286 minecraft:packed_ice
setblock 182 243 290 minecraft:snow_block
fill 182 243 291 182 246 291 minecraft:packed_ice
setblock 182 243 295 minecraft:snow_block
setblock 182 243 305 minecraft:snow_block
fill 182 243 306 182 245 306 minecraft:packed_ice
setblock 182 243 310 minecraft:snow_block
setblock 183 243 275 minecraft:snow_block
fill 183 243 276 183 244 276 minecraft:packed_ice
setblock 183 243 282 minecraft:snow_block
fill 183 243 287 183 244 287 minecraft:packed_ice
setblock 183 243 288 minecraft:snow_block
setblock 183 243 291 minecraft:snow_block
setblock 183 243 299 minecraft:snow_block
setblock 183 243 300 minecraft:white_concrete
fill 183 243 305 183 245 305 minecraft:packed_ice
setblock 183 243 308 minecraft:snow_block
setblock 141 244 286 minecraft:white_concrete
setblock 141 244 287 minecraft:packed_ice
setblock 141 244 290 minecraft:light_blue_concrete
setblock 141 244 313 minecraft:packed_ice
setblock 141 244 316 minecraft:packed_ice
fill 142 244 277 142 244 278 minecraft:packed_ice
setblock 142 244 279 minecraft:snow_block
fill 142 244 280 142 247 280 minecraft:packed_ice
setblock 142 244 284 minecraft:snow_block
fill 142 244 285 142 246 286 minecraft:packed_ice
setblock 142 244 289 minecraft:snow_block
fill 142 244 290 142 247 290 minecraft:packed_ice
fill 142 244 292 142 245 292 minecraft:packed_ice
setblock 142 244 309 minecraft:snow_block
fill 142 244 310 142 246 311 minecraft:packed_ice
setblock 143 244 283 minecraft:snow_block
fill 143 244 284 143 246 284 minecraft:packed_ice
setblock 143 244 288 minecraft:snow_block
fill 143 244 289 143 247 289 minecraft:packed_ice
setblock 143 244 317 minecraft:white_concrete
setblock 144 244 278 minecraft:light[level=15]
setblock 144 244 285 minecraft:light[level=12]
setblock 144 244 286 minecraft:light[level=15]
setblock 144 244 292 minecraft:light[level=12]
setblock 144 244 294 minecraft:light[level=15]
setblock 144 244 299 minecraft:light[level=12]
setblock 144 244 302 minecraft:light[level=15]
setblock 144 244 306 minecraft:light[level=12]
setblock 144 244 310 minecraft:light[level=15]
setblock 144 244 313 minecraft:light[level=12]
fill 147 244 276 149 244 276 minecraft:packed_ice
fill 148 244 316 149 244 316 minecraft:packed_ice
setblock 150 244 276 minecraft:snow_block
setblock 150 244 315 minecraft:packed_ice
setblock 150 244 316 minecraft:snow_block
fill 151 244 276 151 246 277 minecraft:packed_ice
setblock 151 244 278 minecraft:light[level=12]
setblock 151 244 285 minecraft:light[level=12]
setblock 151 244 292 minecraft:light[level=12]
setblock 151 244 299 minecraft:light[level=12]
setblock 151 244 306 minecraft:light[level=12]
setblock 151 244 313 minecraft:light[level=12]
setblock 151 244 315 minecraft:snow_block
fill 151 244 316 154 244 316 minecraft:packed_ice
setblock 152 244 278 minecraft:light[level=15]
setblock 152 244 286 minecraft:light[level=15]
setblock 152 244 294 minecraft:light[level=15]
setblock 152 244 302 minecraft:light[level=15]
setblock 152 244 310 minecraft:light[level=15]
setblock 152 244 314 minecraft:snow_block
fill 152 244 315 152 247 315 minecraft:packed_ice
fill 153 244 314 153 247 314 minecraft:packed_ice
setblock 154 244 277 minecraft:snow_block
fill 154 244 313 157 244 313 minecraft:packed_ice
setblock 154 244 317 minecraft:packed_ice
setblock 155 244 276 minecraft:snow_block
fill 155 244 277 155 247 277 minecraft:packed_ice
setblock 155 244 316 minecraft:snow_block
fill 156 244 276 156 247 276 minecraft:packed_ice
setblock 156 244 315 minecraft:snow_block
fill 156 244 316 156 247 316 minecraft:packed_ice
setblock 157 244 314 minecraft:snow_block
fill 157 244 315 157 247 315 minecraft:packed_ice
setblock 158 244 278 minecraft:light[level=12]
setblock 158 244 285 minecraft:light[level=12]
setblock 158 244 292 minecraft:light[level=12]
setblock 158 244 299 minecraft:light[level=12]
setblock 158 244 306 minecraft:light[level=12]
setblock 158 244 313 minecraft:light[level=12]
fill 158 244 314 159 246 314 minecraft:packed_ice
setblock 160 244 278 minecraft:light[level=15]
setblock 160 244 286 minecraft:light[level=15]
setblock 160 244 294 minecraft:light[level=15]
setblock 160 244 302 minecraft:light[level=15]
setblock 160 244 310 minecraft:light[level=15]
setblock 160 244 316 minecraft:snow_block
fill 161 244 316 162 246 316 minecraft:packed_ice
fill 163 244 317 163 245 317 minecraft:packed_ice
setblock 165 244 278 minecraft:light[level=12]
setblock 165 244 285 minecraft:light[level=12]
setblock 165 244 292 minecraft:light[level=12]
setblock 165 244 299 minecraft:light[level=12]
setblock 165 244 306 minecraft:light[level=12]
setblock 165 244 313 minecraft:light[level=12]
setblock 168 244 278 minecraft:light[level=15]
setblock 168 244 286 minecraft:light[level=15]
setblock 168 244 294 minecraft:light[level=15]
setblock 168 244 302 minecraft:light[level=15]
setblock 168 244 310 minecraft:light[level=15]
setblock 171 244 317 minecraft:packed_ice
setblock 172 244 278 minecraft:light[level=12]
setblock 172 244 285 minecraft:light[level=12]
setblock 172 244 292 minecraft:light[level=12]
setblock 172 244 299 minecraft:light[level=12]
setblock 172 244 306 minecraft:light[level=12]
setblock 172 244 313 minecraft:light[level=12]
fill 172 244 316 174 244 316 minecraft:packed_ice
setblock 174 244 275 minecraft:white_concrete
setblock 175 244 316 minecraft:snow_block
setblock 176 244 278 minecraft:light[level=15]
setblock 176 244 286 minecraft:light[level=15]
setblock 176 244 294 minecraft:light[level=15]
setblock 176 244 302 minecraft:light[level=15]
fill 176 244 308 176 246 308 minecraft:packed_ice
setblock 176 244 310 minecraft:light[level=15]
fill 176 244 316 177 246 316 minecraft:packed_ice
fill 177 244 307 177 246 307 minecraft:packed_ice
fill 177 244 309 177 246 309 minecraft:packed_ice
fill 178 244 308 178 246 308 minecraft:packed_ice
setblock 179 244 278 minecraft:light[level=12]
setblock 179 244 285 minecraft:light[level=12]
setblock 179 244 286 minecraft:packed_ice
setblock 179 244 287 minecraft:snow_block
fill 179 244 288 179 246 289 minecraft:packed_ice
setblock 179 244 292 minecraft:light[level=12]
setblock 179 244 299 minecraft:light[level=12]
setblock 179 244 306 minecraft:light[level=12]
setblock 179 244 313 minecraft:light[level=12]
setblock 180 244 286 minecraft:snow_block
fill 180 244 287 180 247 287 minecraft:packed_ice
setblock 180 244 291 minecraft:snow_block
setblock 181 244 285 minecraft:snow_block
fill 181 244 286 181 247 286 minecraft:packed_ice
setblock 181 244 290 minecraft:snow_block
fill 181 244 291 181 247 291 minecraft:packed_ice
fill 182 244 280 182 246 280 minecraft:packed_ice
setblock 182 244 284 minecraft:snow_block
fill 182 244 285 182 247 285 minecraft:packed_ice
setblock 182 244 289 minecraft:snow_block
fill 182 244 290 182 247 290 minecraft:packed_ice
setblock 182 244 294 minecraft:snow_block
fill 182 244 295 182 247 295 minecraft:packed_ice
setblock 182 244 304 minecraft:snow_block
fill 182 244 305 182 245 305 minecraft:packed_ice
setblock 182 244 309 minecraft:snow_block
fill 182 244 310 182 247 310 minecraft:packed_ice
setblock 183 244 275 minecraft:packed_ice
setblock 183 244 282 minecraft:packed_ice
setblock 183 244 288 minecraft:packed_ice
setblock 183 244 291 minecraft:packed_ice
setblock 183 244 294 minecraft:packed_ice
fill 183 244 299 183 244 300 minecraft:packed_ice
setblock 183 244 302 minecraft:packed_ice
setblock 183 244 304 minecraft:packed_ice
setblock 183 244 308 minecraft:packed_ice
fill 141 245 275 141 253 276 minecraft:snow_block
fill 141 245 278 141 259 279 minecraft:snow_block
setblock 141 245 281 minecraft:packed_ice
fill 141 245 282 141 247 294 minecraft:snow_block
fill 141 245 297 141 245 298 minecraft:snow_block
fill 141 245 300 141 245 303 minecraft:snow_block
fill 141 245 305 141 245 316 minecraft:snow_block
fill 142 245 276 142 245 277 minecraft:packed_ice
setblock 142 245 278 minecraft:snow_block
fill 142 245 279 142 247 279 minecraft:packed_ice
setblock 142 245 283 minecraft:snow_block
fill 142 245 284 142 248 284 minecraft:packed_ice
setblock 142 245 288 minecraft:snow_block
fill 142 245 289 142 248 289 minecraft:packed_ice
setblock 142 245 308 minecraft:snow_block
fill 142 245 309 142 248 309 minecraft:packed_ice
setblock 142 245 312 minecraft:packed_ice
setblock 142 245 313 minecraft:snow_block
fill 142 245 314 142 248 314 minecraft:packed_ice
fill 142 245 317 151 245 317 minecraft:snow_block
setblock 143 245 282 minecraft:snow_block
fill 143 245 283 143 246 283 minecraft:packed_ice
setblock 143 245 287 minecraft:snow_block
fill 143 245 288 143 248 288 minecraft:packed_ice
fill 144 245 275 144 297 275 minecraft:snow_block
setblock 145 245 275 minecraft:packed_ice
fill 146 245 275 151 246 275 minecraft:snow_block
fill 146 245 276 148 245 276 minecraft:packed_ice
fill 146 245 316 148 245 316 minecraft:packed_ice
fill 148 245 315 149 245 315 minecraft:packed_ice
setblock 149 245 276 minecraft:snow_block
setblock 149 245 316 minecraft:snow_block
fill 150 245 276 150 247 277 minecraft:packed_ice
setblock 150 245 314 minecraft:packed_ice
setblock 150 245 315 minecraft:snow_block
fill 150 245 316 153 245 316 minecraft:packed_ice
setblock 151 245 314 minecraft:snow_block
fill 151 245 315 151 248 315 minecraft:packed_ice
setblock 152 245 313 minecraft:snow_block
fill 152 245 314 152 248 314 minecraft:packed_ice
setblock 152 245 317 minecraft:packed_ice
fill 153 245 275 157 246 275 minecraft:snow_block
setblock 153 245 276 minecraft:packed_ice
setblock 153 245 277 minecraft:snow_block
fill 153 245 313 156 245 313 minecraft:packed_ice
fill 153 245 317 159 246 317 minecraft:snow_block
setblock 154 245 276 minecraft:snow_block
fill 154 245 277 154 248 277 minecraft:packed_ice
setblock 154 245 316 minecraft:snow_block
fill 155 245 276 155 248 276 minecraft:packed_ice
setblock 155 245 315 minecraft:snow_block
fill 155 245 316 155 248 316 minecraft:packed_ice
setblock 156 245 314 minecraft:snow_block
fill 156 245 315 156 248 315 minecraft:packed_ice
setblock 157 245 313 minecraft:snow_block
fill 157 245 314 157 248 314 minecraft:packed_ice
fill 157 245 316 157 246 316 minecraft:packed_ice
fill 159 245 275 176 245 275 minecraft:snow_block
setblock 159 245 316 minecraft:snow_block
setblock 160 245 315 minecraft:snow_block
fill 160 245 316 160 248 316 minecraft:packed_ice
fill 161 245 315 161 248 315 minecraft:packed_ice
fill 161 245 317 162 246 317 minecraft:snow_block
fill 164 245 278 164 251 278 minecraft:packed_ice
fill 164 245 317 177 245 317 minecraft:snow_block
fill 170 245 316 173 245 316 minecraft:packed_ice
fill 173 245 315 174 245 315 minecraft:packed_ice
setblock 174 245 276 minecraft:snow_block
setblock 174 245 316 minecraft:snow_block
fill 175 245 276 177 246 276 minecraft:packed_ice
fill 175 245 316 175 248 316 minecraft:packed_ice
fill 176 245 307 176 246 307 minecraft:packed_ice
fill 176 245 309 176 246 309 minecraft:packed_ice
setblock 177 245 275 minecraft:light_blue_concrete
fill 178 245 275 183 245 275 minecraft:snow_block
fill 178 245 307 178 246 307 minecraft:packed_ice
fill 178 245 309 178 246 309 minecraft:packed_ice
setblock 178 245 317 minecraft:packed_ice
setblock 179 245 286 minecraft:snow_block
fill 179 245 287 179 246 287 minecraft:packed_ice
setblock 179 245 290 minecraft:packed_ice
setblock 180 245 285 minecraft:snow_block
fill 180 245 286 180 248 286 minecraft:packed_ice
setblock 180 245 289 minecraft:packed_ice
setblock 180 245 290 minecraft:snow_block
fill 180 245 291 180 247 292 minecraft:packed_ice
fill 180 245 317 180 308 317 minecraft:snow_block
setblock 181 245 284 minecraft:snow_block
fill 181 245 285 181 248 285 minecraft:packed_ice
setblock 181 245 289 minecraft:snow_block
fill 181 245 290 181 248 290 minecraft:packed_ice
setblock 181 245 294 minecraft:snow_block
setblock 181 245 317 minecraft:light_blue_concrete
fill 182 245 283 183 245 283 minecraft:snow_block
fill 182 245 284 182 248 284 minecraft:packed_ice
fill 182 245 286 182 246 286 minecraft:packed_ice
fill 182 245 288 183 245 288 minecraft:snow_block
fill 182 245 289 182 248 289 minecraft:packed_ice
fill 182 245 293 183 245 293 minecraft:snow_block
fill 182 245 294 182 248 294 minecraft:packed_ice
fill 182 245 308 183 245 308 minecraft:snow_block
fill 182 245 309 182 247 309 minecraft:packed_ice
fill 182 245 311 182 246 311 minecraft:packed_ice
fill 182 245 317 183 308 317 minecraft:snow_block
fill 183 245 276 183 245 282 minecraft:snow_block
fill 183 245 284 183 245 287 minecraft:snow_block
fill 183 245 291 183 245 292 minecraft:snow_block
fill 183 245 294 183 276 294 minecraft:snow_block
fill 183 245 296 183 251 298 minecraft:snow_block
setblock 183 245 299 minecraft:packed_ice
fill 183 245 300 183 258 304 minecraft:snow_block
fill 183 245 306 183 257 307 minecraft:snow_block
fill 183 245 309 183 260 316 minecraft:snow_block
fill 141 246 277 142 246 277 minecraft:snow_block
fill 141 246 280 141 246 281 minecraft:snow_block
fill 141 246 295 141 247 295 minecraft:snow_block
setblock 141 246 297 minecraft:packed_ice
fill 141 246 298 141 246 299 minecraft:snow_block
setblock 141 246 300 minecraft:packed_ice
fill 141 246 301 141 246 313 minecraft:snow_block
setblock 141 246 314 minecraft:packed_ice
fill 141 246 315 141 308 316 minecraft:snow_block
fill 142 246 275 143 246 275 minecraft:snow_block
setblock 142 246 276 minecraft:packed_ice
fill 142 246 278 142 247 278 minecraft:packed_ice
setblock 142 246 282 minecraft:snow_block
fill 142 246 283 142 249 283 minecraft:packed_ice
setblock 142 246 287 minecraft:snow_block
fill 142 246 288 142 249 288 minecraft:packed_ice
setblock 142 246 292 minecraft:snow_block
fill 142 246 293 142 248 293 minecraft:packed_ice
fill 142 246 308 142 247 308 minecraft:packed_ice
setblock 142 246 312 minecraft:snow_block
fill 142 246 313 142 249 313 minecraft:packed_ice
fill 142 246 315 142 247 315 minecraft:packed_ice
fill 142 246 317 150 252 317 minecraft:snow_block
setblock 143 246 276 minecraft:snow_block
setblock 143 246 286 minecraft:snow_block
fill 143 246 287 143 248 287 minecraft:packed_ice
setblock 143 246 316 minecraft:snow_block
fill 144 246 276 147 246 276 minecraft:packed_ice
fill 144 246 281 144 253 281 minecraft:snow_block
fill 144 246 316 147 246 316 minecraft:packed_ice
fill 145 246 275 145 308 275 minecraft:snow_block
fill 147 246 315 148 246 315 minecraft:packed_ice
setblock 148 246 276 minecraft:snow_block
setblock 148 246 316 minecraft:snow_block
fill 149 246 276 149 248 277 minecraft:packed_ice
setblock 149 246 314 minecraft:packed_ice
setblock 149 246 315 minecraft:snow_block
fill 149 246 316 152 246 316 minecraft:packed_ice
setblock 150 246 314 minecraft:snow_block
fill 150 246 315 150 249 315 minecraft:packed_ice
setblock 151 246 313 minecraft:snow_block
fill 151 246 314 151 249 314 minecraft:packed_ice
setblock 151 246 317 minecraft:packed_ice
fill 152 246 275 152 262 275 minecraft:snow_block
setblock 152 246 276 minecraft:packed_ice
setblock 152 246 277 minecraft:snow_block
fill 152 246 313 155 246 313 minecraft:packed_ice
fill 152 246 317 152 274 317 minecraft:snow_block
setblock 153 246 276 minecraft:snow_block
fill 153 246 277 153 249 277 minecraft:packed_ice
setblock 153 246 316 minecraft:snow_block
fill 154 246 276 154 249 276 minecraft:packed_ice
fill 154 246 312 155 247 312 minecraft:packed_ice
setblock 154 246 314 minecraft:packed_ice
setblock 154 246 315 minecraft:snow_block
fill 154 246 316 154 249 316 minecraft:packed_ice
setblock 155 246 314 minecraft:snow_block
fill 155 246 315 155 249 315 minecraft:packed_ice
setblock 156 246 313 minecraft:snow_block
fill 156 246 314 156 249 314 minecraft:packed_ice
fill 157 246 313 158 247 313 minecraft:packed_ice
fill 158 246 275 158 246 276 minecraft:snow_block
setblock 158 246 316 minecraft:snow_block
fill 159 246 275 164 246 275 minecraft:snow_block
setblock 159 246 315 minecraft:snow_block
fill 159 246 316 159 249 316 minecraft:packed_ice
fill 160 246 315 160 249 315 minecraft:packed_ice
fill 160 246 317 160 308 317 minecraft:snow_block
fill 163 246 316 163 246 317 minecraft:snow_block
fill 164 246 317 165 298 317 minecraft:snow_block
setblock 165 246 275 minecraft:packed_ice
fill 166 246 275 177 246 275 minecraft:snow_block
setblock 166 246 317 minecraft:white_concrete
setblock 167 246 316 minecraft:packed_ice
fill 167 246 317 168 254 317 minecraft:snow_block
setblock 168 246 316 minecraft:snow_block
fill 169 246 316 169 246 317 minecraft:packed_ice
fill 170 246 315 172 246 316 minecraft:packed_ice
fill 170 246 317 172 253 317 minecraft:snow_block
setblock 173 246 276 minecraft:snow_block
setblock 173 246 315 minecraft:packed_ice
setblock 173 246 316 minecraft:snow_block
setblock 173 246 317 minecraft:packed_ice
fill 174 246 276 174 249 276 minecraft:packed_ice
setblock 174 246 315 minecraft:snow_block
fill 174 246 316 174 249 316 minecraft:packed_ice
fill 174 246 317 176 246 317 minecraft:snow_block
fill 175 246 315 176 248 315 minecraft:packed_ice
setblock 177 246 317 minecraft:packed_ice
setblock 178 246 275 minecraft:packed_ice
fill 178 246 316 178 246 317 minecraft:snow_block
fill 179 246 275 183 269 275 minecraft:snow_block
setblock 179 246 286 minecraft:packed_ice
setblock 179 246 290 minecraft:snow_block
fill 179 246 317 179 308 317 minecraft:snow_block
setblock 180 246 284 minecraft:snow_block
fill 180 246 285 180 247 285 minecraft:packed_ice
setblock 180 246 289 minecraft:snow_block
fill 180 246 290 180 249 290 minecraft:packed_ice
setblock 181 246 283 minecraft:snow_block
fill 181 246 284 181 248 284 minecraft:packed_ice
setblock 181 246 288 minecraft:snow_block
fill 181 246 289 181 249 289 minecraft:packed_ice
setblock 181 246 292 minecraft:packed_ice
setblock 181 246 293 minecraft:snow_block
fill 181 246 294 181 248 294 minecraft:packed_ice
setblock 181 246 317 minecraft:snow_block
fill 182 246 282 183 246 282 minecraft:snow_block
fill 182 246 283 182 249 283 minecraft:packed_ice
fill 182 246 287 183 246 287 minecraft:snow_block
fill 182 246 288 182 249 288 minecraft:packed_ice
setblock 182 246 292 minecraft:snow_block
fill 182 246 293 182 249 293 minecraft:packed_ice
setblock 182 246 307 minecraft:snow_block
setblock 182 246 308 minecraft:packed_ice
setblock 182 246 312 minecraft:snow_block
fill 183 246 276 183 246 277 minecraft:packed_ice
fill 183 246 278 183 246 281 minecraft:snow_block
fill 183 246 283 183 308 283 minecraft:snow_block
setblock 183 246 284 minecraft:packed_ice
fill 183 246 285 183 246 286 minecraft:snow_block
fill 183 246 288 183 303 291 minecraft:snow_block
setblock 183 246 292 minecraft:packed_ice
fill 183 246 293 183 308 293 minecraft:snow_block
setblock 183 246 299 minecraft:snow_block
fill 183 246 305 183 254 305 minecraft:snow_block
fill 183 246 308 183 269 308 minecraft:snow_block
fill 141 247 277 141 294 277 minecraft:snow_block
setblock 141 247 280 minecraft:packed_ice
fill 141 247 281 142 247 281 minecraft:snow_block
fill 141 247 296 141 274 298 minecraft:snow_block
setblock 141 247 299 minecraft:packed_ice
fill 141 247 300 141 308 300 minecraft:snow_block
setblock 141 247 301 minecraft:packed_ice
fill 141 247 302 141 308 303 minecraft:snow_block
setblock 141 247 304 minecraft:packed_ice
fill 141 247 305 141 308 305 minecraft:snow_block
setblock 141 247 306 minecraft:packed_ice
fill 141 247 307 141 308 307 minecraft:snow_block
setblock 141 247 308 minecraft:packed_ice
fill 141 247 309 141 291 314 minecraft:snow_block
fill 141 247 317 141 308 317 minecraft:snow_block
fill 142 247 275 142 247 276 minecraft:snow_block
fill 142 247 277 142 249 277 minecraft:packed_ice
fill 142 247 282 142 248 282 minecraft:packed_ice
setblock 142 247 285 minecraft:packed_ice
setblock 142 247 286 minecraft:snow_block
fill 142 247 287 142 250 287 minecraft:packed_ice
setblock 142 247 291 minecraft:snow_block
fill 142 247 292 142 250 292 minecraft:packed_ice
setblock 142 247 310 minecraft:packed_ice
setblock 142 247 311 minecraft:snow_block
fill 142 247 312 142 250 312 minecraft:packed_ice
setblock 142 247 316 minecraft:snow_block
fill 143 247 275 143 247 276 minecraft:packed_ice
setblock 143 247 285 minecraft:snow_block
setblock 143 247 286 minecraft:packed_ice
fill 143 247 316 146 247 316 minecraft:packed_ice
fill 144 247 276 146 247 276 minecraft:packed_ice
fill 146 247 275 149 281 275 minecraft:snow_block
fill 146 247 315 147 247 315 minecraft:packed_ice
setblock 147 247 276 minecraft:snow_block
setblock 147 247 316 minecraft:snow_block
fill 148 247 276 148 250 276 minecraft:packed_ice
setblock 148 247 314 minecraft:packed_ice
setblock 148 247 315 minecraft:snow_block
fill 148 247 316 151 247 316 minecraft:packed_ice
setblock 149 247 314 minecraft:snow_block
fill 149 247 315 149 250 315 minecraft:packed_ice
setblock 150 247 275 minecraft:packed_ice
setblock 150 247 313 minecraft:snow_block
fill 150 247 314 150 250 314 minecraft:packed_ice
fill 151 247 275 151 308 275 minecraft:snow_block
setblock 151 247 276 minecraft:packed_ice
setblock 151 247 277 minecraft:snow_block
fill 151 247 313 154 247 313 minecraft:packed_ice
fill 151 247 317 151 254 317 minecraft:snow_block
setblock 152 247 276 minecraft:snow_block
fill 152 247 277 152 250 277 minecraft:packed_ice
fill 152 247 312 153 249 312 minecraft:packed_ice
setblock 152 247 316 minecraft:snow_block
fill 153 247 275 154 250 275 minecraft:snow_block
fill 153 247 276 153 250 276 minecraft:packed_ice
setblock 153 247 315 minecraft:snow_block
fill 153 247 316 153 250 316 minecraft:packed_ice
fill 153 247 317 154 281 317 minecraft:snow_block
setblock 154 247 314 minecraft:snow_block
fill 154 247 315 154 250 315 minecraft:packed_ice
fill 155 247 275 156 247 275 minecraft:packed_ice
setblock 155 247 313 minecraft:snow_block
fill 155 247 314 155 250 314 minecraft:packed_ice
setblock 155 247 317 minecraft:packed_ice
fill 156 247 313 156 249 313 minecraft:packed_ice
fill 156 247 317 159 271 317 minecraft:snow_block
fill 157 247 275 157 247 276 minecraft:snow_block
setblock 157 247 316 minecraft:snow_block
fill 158 247 275 162 253 275 minecraft:snow_block
setblock 158 247 276 minecraft:packed_ice
setblock 158 247 314 minecraft:packed_ice
setblock 158 247 315 minecraft:snow_block
fill 158 247 316 158 250 316 minecraft:packed_ice
setblock 159 247 314 minecraft:snow_block
fill 159 247 315 159 250 315 minecraft:packed_ice
setblock 161 247 316 minecraft:packed_ice
fill 161 247 317 161 256 317 minecraft:snow_block
setblock 162 247 316 minecraft:snow_block
setblock 162 247 317 minecraft:packed_ice
setblock 163 247 275 minecraft:packed_ice
fill 163 247 316 166 247 316 minecraft:packed_ice
fill 163 247 317 163 308 317 minecraft:snow_block
fill 164 247 275 172 251 275 minecraft:snow_block
fill 166 247 317 166 308 317 minecraft:snow_block
setblock 167 247 316 minecraft:snow_block
fill 168 247 316 171 247 316 minecraft:packed_ice
fill 169 247 315 172 247 315 minecraft:packed_ice
fill 169 247 317 169 308 317 minecraft:snow_block
setblock 172 247 276 minecraft:snow_block
setblock 172 247 316 minecraft:snow_block
fill 173 247 275 173 247 276 minecraft:packed_ice
fill 173 247 277 173 247 283 minecraft:blue_ice
setblock 173 247 315 minecraft:snow_block
fill 173 247 316 173 250 316 minecraft:packed_ice
fill 173 247 317 174 308 317 minecraft:snow_block
fill 174 247 275 178 251 275 minecraft:snow_block
fill 174 247 315 174 250 315 minecraft:packed_ice
fill 175 247 276 176 247 276 minecraft:packed_ice
setblock 175 247 317 minecraft:packed_ice
setblock 176 247 316 minecraft:packed_ice
fill 176 247 317 178 255 317 minecraft:snow_block
setblock 177 247 276 minecraft:snow_block
setblock 177 247 316 minecraft:snow_block
setblock 178 247 276 minecraft:packed_ice
fill 178 247 316 178 249 316 minecraft:packed_ice
setblock 179 247 288 minecraft:packed_ice
setblock 179 247 289 minecraft:snow_block
setblock 179 247 290 minecraft:packed_ice
setblock 180 247 288 minecraft:snow_block
fill 180 247 289 180 249 289 minecraft:packed_ice
setblock 181 247 283 minecraft:packed_ice
setblock 181 247 287 minecraft:snow_block
fill 181 247 288 181 250 288 minecraft:packed_ice
setblock 181 247 292 minecraft:snow_block
fill 181 247 293 181 250 293 minecraft:packed_ice
setblock 181 247 317 minecraft:packed_ice
fill 182 247 281 183 247 281 minecraft:snow_block
fill 182 247 282 182 248 282 minecraft:packed_ice
fill 182 247 286 183 247 286 minecraft:snow_block
fill 182 247 287 182 250 287 minecraft:packed_ice
setblock 182 247 291 minecraft:snow_block
fill 182 247 292 182 250 292 minecraft:packed_ice
setblock 182 247 311 minecraft:snow_block
setblock 182 247 312 minecraft:packed_ice
fill 183 247 276 183 276 277 minecraft:snow_block
setblock 183 247 278 minecraft:packed_ice
fill 183 247 279 183 293 280 minecraft:snow_block
fill 183 247 282 183 308 282 minecraft:snow_block
fill 183 247 284 183 308 284 minecraft:snow_block
setblock 183 247 285 minecraft:packed_ice
fill 183 247 287 183 308 287 minecraft:snow_block
fill 183 247 292 183 253 292 minecraft:snow_block
fill 183 247 295 183 308 295 minecraft:snow_block
setblock 183 247 299 minecraft:packed_ice
fill 141 248 280 141 252 288 minecraft:snow_block
setblock 141 248 289 minecraft:white_concrete
fill 141 248 290 141 308 294 minecraft:snow_block
setblock 141 248 295 minecraft:white_concrete
fill 141 248 299 141 308 299 minecraft:snow_block
fill 141 248 301 141 308 301 minecraft:snow_block
fill 141 248 304 141 308 304 minecraft:snow_block
fill 141 248 306 141 308 306 minecraft:snow_block
fill 141 248 308 141 308 308 minecraft:snow_block
fill 142 248 275 143 283 275 minecraft:snow_block
fill 142 248 276 145 248 276 minecraft:packed_ice
setblock 142 248 281 minecraft:packed_ice
setblock 142 248 285 minecraft:snow_block
fill 142 248 286 142 250 286 minecraft:packed_ice
setblock 142 248 290 minecraft:snow_block
fill 142 248 291 142 250 291 minecraft:packed_ice
setblock 142 248 310 minecraft:snow_block
fill 142 248 311 142 251 311 minecraft:packed_ice
setblock 142 248 315 minecraft:snow_block
fill 142 248 316 145 248 316 minecraft:packed_ice
setblock 143 248 289 minecraft:snow_block
fill 145 248 315 146 248 315 minecraft:packed_ice
setblock 146 248 276 minecraft:snow_block
setblock 146 248 316 minecraft:snow_block
fill 147 248 276 147 251 276 minecraft:packed_ice
setblock 147 248 314 minecraft:packed_ice
setblock 147 248 315 minecraft:snow_block
fill 147 248 316 150 248 316 minecraft:packed_ice
fill 148 248 277 148 249 277 minecraft:packed_ice
setblock 148 248 314 minecraft:snow_block
fill 148 248 315 148 251 315 minecraft:packed_ice
setblock 149 248 313 minecraft:snow_block
fill 149 248 314 149 251 314 minecraft:packed_ice
fill 150 248 275 150 308 275 minecraft:snow_block
setblock 150 248 276 minecraft:packed_ice
setblock 150 248 277 minecraft:snow_block
fill 150 248 313 153 248 313 minecraft:packed_ice
setblock 151 248 276 minecraft:snow_block
fill 151 248 277 151 251 277 minecraft:packed_ice
setblock 151 248 316 minecraft:snow_block
fill 152 248 276 152 251 276 minecraft:packed_ice
fill 152 248 301 154 249 301 minecraft:snow_block
setblock 152 248 315 minecraft:snow_block
fill 152 248 316 152 251 316 minecraft:packed_ice
fill 153 248 300 153 249 300 minecraft:snow_block
fill 153 248 302 153 249 302 minecraft:snow_block
setblock 153 248 314 minecraft:snow_block
fill 153 248 315 153 251 315 minecraft:packed_ice
setblock 154 248 312 minecraft:packed_ice
setblock 154 248 313 minecraft:snow_block
fill 154 248 314 154 251 314 minecraft:packed_ice
fill 155 248 275 157 308 275 minecraft:snow_block
setblock 155 248 312 minecraft:snow_block
fill 155 248 313 155 250 313 minecraft:packed_ice
fill 155 248 317 155 284 317 minecraft:snow_block
setblock 156 248 276 minecraft:snow_block
setblock 156 248 316 minecraft:snow_block
fill 157 248 276 157 249 276 minecraft:packed_ice
setblock 157 248 313 minecraft:packed_ice
setblock 157 248 315 minecraft:snow_block
fill 157 248 316 157 251 316 minecraft:packed_ice
setblock 158 248 314 minecraft:snow_block
fill 158 248 315 158 251 315 minecraft:packed_ice
setblock 159 248 314 minecraft:packed_ice
setblock 161 248 316 minecraft:snow_block
fill 162 248 316 165 248 316 minecraft:packed_ice
fill 162 248 317 162 256 317 minecraft:snow_block
fill 163 248 275 163 258 275 minecraft:snow_block
setblock 166 248 316 minecraft:snow_block
fill 167 248 316 170 248 316 minecraft:packed_ice
fill 168 248 315 171 248 315 minecraft:packed_ice
setblock 171 248 276 minecraft:snow_block
fill 171 248 314 172 248 314 minecraft:packed_ice
setblock 171 248 316 minecraft:snow_block
fill 172 248 276 173 250 276 minecraft:packed_ice
fill 172 248 277 174 248 279 minecraft:blue_ice
fill 172 248 288 174 249 288 minecraft:white_concrete
setblock 172 248 315 minecraft:snow_block
fill 172 248 316 172 251 316 minecraft:packed_ice
fill 173 248 275 173 275 275 minecraft:snow_block
setblock 173 248 280 minecraft:blue_ice
fill 173 248 287 173 249 287 minecraft:white_concrete
fill 173 248 289 173 249 289 minecraft:white_concrete
setblock 173 248 314 minecraft:snow_block
fill 173 248 315 173 251 315 minecraft:packed_ice
setblock 175 248 276 minecraft:packed_ice
fill 175 248 317 175 276 317 minecraft:snow_block
setblock 176 248 276 minecraft:snow_block
setblock 176 248 316 minecraft:snow_block
fill 177 248 276 177 249 276 minecraft:packed_ice
fill 177 248 316 177 250 316 minecraft:packed_ice
setblock 180 248 287 minecraft:snow_block
fill 180 248 288 180 249 288 minecraft:packed_ice
setblock 180 248 291 minecraft:packed_ice
setblock 180 248 292 minecraft:snow_block
setblock 181 248 286 minecraft:snow_block
fill 181 248 287 181 250 287 minecraft:packed_ice
setblock 181 248 291 minecraft:snow_block
fill 181 248 292 181 251 292 minecraft:packed_ice
fill 181 248 317 181 308 317 minecraft:snow_block
setblock 182 248 281 minecraft:packed_ice
fill 182 248 285 183 248 285 minecraft:snow_block
fill 182 248 286 182 251 286 minecraft:packed_ice
setblock 182 248 290 minecraft:snow_block
fill 182 248 291 182 251 291 minecraft:packed_ice
setblock 182 248 295 minecraft:snow_block
setblock 182 248 311 minecraft:packed_ice
fill 183 248 278 183 264 278 minecraft:snow_block
fill 183 248 281 183 274 281 minecraft:snow_block
fill 183 248 286 183 308 286 minecraft:snow_block
fill 183 248 299 183 281 299 minecraft:snow_block
fill 141 249 289 142 249 289 minecraft:snow_block
fill 141 249 295 141 277 295 minecraft:snow_block
fill 142 249 276 144 249 276 minecraft:packed_ice
setblock 142 249 284 minecraft:snow_block
setblock 142 249 285 minecraft:packed_ice
fill 142 249 290 142 251 290 minecraft:packed_ice
fill 142 249 310 142 250 310 minecraft:packed_ice
setblock 142 249 314 minecraft:snow_block
fill 142 249 315 142 251 316 minecraft:packed_ice
fill 143 249 316 144 249 316 minecraft:packed_ice
fill 144 249 315 145 249 315 minecraft:packed_ice
setblock 145 249 276 minecraft:snow_block
setblock 145 249 316 minecraft:snow_block
fill 146 249 276 146 252 276 minecraft:packed_ice
setblock 146 249 314 minecraft:packed_ice
setblock 146 249 315 minecraft:snow_block
fill 146 249 316 149 249 316 minecraft:packed_ice
setblock 147 249 314 minecraft:snow_block
fill 147 249 315 147 252 315 minecraft:packed_ice
fill 148 249 314 148 252 314 minecraft:packed_ice
setblock 149 249 276 minecraft:packed_ice
setblock 149 249 277 minecraft:snow_block
fill 149 249 313 152 249 313 minecraft:packed_ice
setblock 150 249 276 minecraft:snow_block
fill 150 249 277 150 252 277 minecraft:packed_ice
setblock 150 249 316 minecraft:snow_block
fill 151 249 276 151 252 276 minecraft:packed_ice
setblock 151 249 315 minecraft:snow_block
fill 151 249 316 151 252 316 minecraft:packed_ice
setblock 152 249 314 minecraft:snow_block
fill 152 249 315 152 252 315 minecraft:packed_ice
setblock 153 249 313 minecraft:snow_block
fill 153 249 314 153 252 314 minecraft:packed_ice
fill 154 249 313 154 251 313 minecraft:packed_ice
setblock 155 249 276 minecraft:snow_block
setblock 155 249 316 minecraft:snow_block
fill 156 249 276 156 250 276 minecraft:packed_ice
setblock 156 249 315 minecraft:snow_block
fill 156 249 316 156 252 316 minecraft:packed_ice
setblock 157 249 314 minecraft:snow_block
fill 157 249 315 157 252 315 minecraft:packed_ice
fill 158 249 314 158 250 314 minecraft:packed_ice
setblock 160 249 316 minecraft:snow_block
fill 161 249 316 164 249 316 minecraft:packed_ice
setblock 165 249 316 minecraft:snow_block
fill 166 249 316 169 249 316 minecraft:packed_ice
fill 167 249 315 170 249 315 minecraft:packed_ice
setblock 170 249 276 minecraft:snow_block
setblock 170 249 316 minecraft:snow_block
fill 171 249 276 171 252 276 minecraft:packed_ice
setblock 171 249 314 minecraft:packed_ice
setblock 171 249 315 minecraft:snow_block
fill 171 249 316 171 252 316 minecraft:packed_ice
fill 172 249 277 174 249 278 minecraft:blue_ice
setblock 172 249 314 minecraft:snow_block
fill 172 249 315 172 252 315 minecraft:packed_ice
setblock 173 249 279 minecraft:blue_ice
setblock 175 249 276 minecraft:snow_block
setblock 175 249 315 minecraft:packed_ice
setblock 175 249 316 minecraft:snow_block
fill 176 249 276 176 251 276 minecraft:packed_ice
fill 176 249 316 176 252 316 minecraft:packed_ice
setblock 180 249 291 minecraft:snow_block
setblock 181 249 285 minecraft:snow_block
setblock 181 249 286 minecraft:packed_ice
setblock 181 249 290 minecraft:snow_block
fill 181 249 291 181 251 291 minecraft:packed_ice
setblock 182 249 284 minecraft:snow_block
fill 182 249 285 182 251 285 minecraft:packed_ice
setblock 182 249 289 minecraft:snow_block
fill 182 249 290 182 252 290 minecraft:packed_ice
setblock 182 249 294 minecraft:snow_block
fill 182 249 295 182 252 295 minecraft:packed_ice
fill 183 249 285 183 308 285 minecraft:snow_block
fill 141 250 289 141 308 289 minecraft:snow_block
fill 142 250 276 143 250 276 minecraft:packed_ice
setblock 142 250 288 minecraft:snow_block
setblock 142 250 289 minecraft:packed_ice
setblock 142 250 313 minecraft:snow_block
fill 142 250 314 143 252 314 minecraft:packed_ice
setblock 143 250 316 minecraft:packed_ice
setblock 144 250 276 minecraft:snow_block
setblock 144 250 278 minecraft:light[level=12]
setblock 144 250 285 minecraft:light[level=12]
setblock 144 250 292 minecraft:light[level=12]
setblock 144 250 299 minecraft:light[level=12]
setblock 144 250 306 minecraft:light[level=12]
setblock 144 250 313 minecraft:light[level=12]
setblock 144 250 315 minecraft:packed_ice
setblock 144 250 316 minecraft:snow_block
fill 145 250 276 145 253 276 minecraft:packed_ice
fill 145 250 303 145 255 303 minecraft:packed_ice
setblock 145 250 315 minecraft:snow_block
fill 145 250 316 148 250 316 minecraft:packed_ice
setblock 146 250 314 minecraft:snow_block
fill 146 250 315 146 253 315 minecraft:packed_ice
fill 147 250 314 147 253 314 minecraft:packed_ice
setblock 148 250 277 minecraft:snow_block
fill 148 250 313 151 250 313 minecraft:packed_ice
setblock 149 250 276 minecraft:snow_block
fill 149 250 277 149 253 277 minecraft:packed_ice
setblock 149 250 316 minecraft:snow_block
fill 150 250 276 150 253 276 minecraft:packed_ice
setblock 150 250 315 minecraft:snow_block
fill 150 250 316 150 253 316 minecraft:packed_ice
setblock 151 250 278 minecraft:light[level=12]
setblock 151 250 285 minecraft:light[level=12]
setblock 151 250 292 minecraft:light[level=12]
setblock 151 250 299 minecraft:light[level=12]
setblock 151 250 306 minecraft:light[level=12]
setblock 151 250 314 minecraft:snow_block
fill 151 250 315 151 253 315 minecraft:packed_ice
setblock 152 250 313 minecraft:snow_block
fill 152 250 314 152 253 314 minecraft:packed_ice
fill 153 250 313 153 252 313 minecraft:packed_ice
setblock 154 250 276 minecraft:snow_block
setblock 154 250 316 minecraft:snow_block
fill 155 250 276 155 252 276 minecraft:packed_ice
setblock 155 250 315 minecraft:snow_block
fill 155 250 316 155 253 316 minecraft:packed_ice
setblock 156 250 314 minecraft:snow_block
fill 156 250 315 156 253 315 minecraft:packed_ice
fill 157 250 314 157 251 314 minecraft:packed_ice
setblock 158 250 278 minecraft:light[level=12]
setblock 158 250 285 minecraft:light[level=12]
setblock 158 250 292 minecraft:light[level=12]
setblock 158 250 299 minecraft:light[level=12]
setblock 158 250 306 minecraft:light[level=12]
setblock 158 250 313 minecraft:light[level=12]
setblock 159 250 316 minecraft:snow_block
setblock 160 250 315 minecraft:snow_block
fill 160 250 316 163 250 316 minecraft:packed_ice
fill 163 250 278 163 251 278 minecraft:packed_ice
fill 164 250 277 164 251 277 minecraft:packed_ice
fill 164 250 279 164 251 279 minecraft:packed_ice
setblock 164 250 316 minecraft:snow_block
fill 165 250 278 165 251 278 minecraft:packed_ice
setblock 165 250 285 minecraft:light[level=12]
setblock 165 250 292 minecraft:light[level=12]
setblock 165 250 299 minecraft:light[level=12]
setblock 165 250 306 minecraft:light[level=12]
setblock 165 250 313 minecraft:light[level=12]
fill 165 250 316 168 250 316 minecraft:packed_ice
fill 167 250 315 169 250 315 minecraft:packed_ice
setblock 169 250 316 minecraft:snow_block
fill 170 250 276 170 253 276 minecraft:packed_ice
setblock 170 250 315 minecraft:snow_block
fill 170 250 316 170 253 316 minecraft:packed_ice
fill 171 250 315 171 253 315 minecraft:packed_ice
setblock 172 250 278 minecraft:light[level=12]
setblock 172 250 285 minecraft:light[level=12]
setblock 172 250 292 minecraft:light[level=12]
setblock 172 250 299 minecraft:light[level=12]
setblock 172 250 306 minecraft:light[level=12]
setblock 172 250 313 minecraft:light[level=12]
setblock 174 250 276 minecraft:snow_block
setblock 174 250 316 minecraft:snow_block
fill 175 250 276 175 253 276 minecraft:packed_ice
fill 175 250 316 175 253 316 minecraft:packed_ice
setblock 179 250 278 minecraft:light[level=12]
setblock 179 250 285 minecraft:light[level=12]
setblock 179 250 292 minecraft:light[level=12]
setblock 179 250 299 minecraft:light[level=12]
setblock 179 250 306 minecraft:light[level=12]
setblock 179 250 313 minecraft:light[level=12]
setblock 181 250 289 minecraft:snow_block
fill 181 250 290 181 251 290 minecraft:packed_ice
setblock 182 250 284 minecraft:packed_ice
setblock 182 250 288 minecraft:snow_block
fill 182 250 289 182 253 289 minecraft:packed_ice
setblock 182 250 293 minecraft:snow_block
fill 182 250 294 182 253 294 minecraft:packed_ice
setblock 142 251 276 minecraft:packed_ice
setblock 142 251 312 minecraft:snow_block
fill 142 251 313 142 254 313 minecraft:packed_ice
setblock 143 251 276 minecraft:snow_block
fill 143 251 281 143 253 281 minecraft:snow_block
setblock 143 251 315 minecraft:packed_ice
setblock 143 251 316 minecraft:snow_block
fill 144 251 276 144 254 276 minecraft:packed_ice
fill 144 251 280 144 253 280 minecraft:snow_block
fill 144 251 282 144 253 282 minecraft:snow_block
setblock 144 251 315 minecraft:snow_block
fill 144 251 316 147 251 316 minecraft:packed_ice
fill 145 251 281 145 253 281 minecraft:snow_block
fill 145 251 315 145 254 315 minecraft:packed_ice
fill 146 251 314 146 254 314 minecraft:packed_ice
setblock 147 251 277 minecraft:snow_block
setblock 148 251 276 minecraft:snow_block
fill 148 251 277 148 254 277 minecraft:packed_ice
fill 148 251 313 150 251 313 minecraft:packed_ice
setblock 148 251 316 minecraft:snow_block
fill 149 251 276 149 254 276 minecraft:packed_ice
setblock 149 251 315 minecraft:snow_block
fill 149 251 316 149 254 316 minecraft:packed_ice
setblock 150 251 314 minecraft:snow_block
fill 150 251 315 150 254 315 minecraft:packed_ice
setblock 151 251 313 minecraft:snow_block
fill 151 251 314 151 254 314 minecraft:packed_ice
setblock 152 251 277 minecraft:snow_block
fill 152 251 313 152 253 313 minecraft:packed_ice
setblock 153 251 275 minecraft:white_concrete
setblock 153 251 276 minecraft:snow_block
setblock 153 251 316 minecraft:snow_block
fill 154 251 275 154 308 275 minecraft:snow_block
fill 154 251 276 154 254 276 minecraft:packed_ice
setblock 154 251 315 minecraft:snow_block
fill 154 251 316 154 254 316 minecraft:packed_ice
setblock 155 251 314 minecraft:snow_block
fill 155 251 315 155 254 315 minecraft:packed_ice
fill 156 251 314 156 252 314 minecraft:packed_ice
setblock 158 251 316 minecraft:snow_block
setblock 159 251 315 minecraft:snow_block
fill 159 251 316 162 251 316 minecraft:packed_ice
setblock 163 251 316 minecraft:snow_block
fill 164 251 316 167 251 316 minecraft:packed_ice
fill 167 251 315 168 251 315 minecraft:packed_ice
setblock 168 251 316 minecraft:snow_block
fill 169 251 276 169 254 276 minecraft:packed_ice
setblock 169 251 315 minecraft:snow_block
fill 169 251 316 169 254 316 minecraft:packed_ice
fill 170 251 315 170 254 315 minecraft:packed_ice
setblock 172 251 276 minecraft:packed_ice
setblock 173 251 276 minecraft:snow_block
setblock 173 251 316 minecraft:snow_block
fill 174 251 276 174 254 276 minecraft:packed_ice
setblock 174 251 315 minecraft:snow_block
fill 174 251 316 174 254 316 minecraft:packed_ice
setblock 181 251 289 minecraft:packed_ice
setblock 182 251 287 minecraft:snow_block
fill 182 251 288 182 253 288 minecraft:packed_ice
setblock 182 251 292 minecraft:snow_block
fill 182 251 293 182 254 293 minecraft:packed_ice
setblock 142 252 276 minecraft:snow_block
fill 142 252 277 142 255 277 minecraft:packed_ice
fill 142 252 312 142 255 312 minecraft:packed_ice
setblock 142 252 315 minecraft:packed_ice
setblock 142 252 316 minecraft:snow_block
fill 143 252 276 143 255 276 minecraft:packed_ice
setblock 143 252 315 minecraft:snow_block
fill 143 252 316 146 252 316 minecraft:packed_ice
setblock 144 252 278 minecraft:light[level=15]
setblock 144 252 286 minecraft:light[level=15]
setblock 144 252 294 minecraft:light[level=15]
setblock 144 252 302 minecraft:light[level=15]
setblock 144 252 310 minecraft:light[level=15]
fill 144 252 315 144 255 315 minecraft:packed_ice
setblock 147 252 276 minecraft:snow_block
fill 147 252 277 147 255 277 minecraft:packed_ice
setblock 147 252 316 minecraft:snow_block
fill 148 252 276 148 255 276 minecraft:packed_ice
fill 148 252 313 149 252 313 minecraft:packed_ice
setblock 148 252 315 minecraft:snow_block
fill 148 252 316 148 255 316 minecraft:packed_ice
setblock 149 252 314 minecraft:snow_block
fill 149 252 315 149 255 315 minecraft:packed_ice
setblock 150 252 313 minecraft:snow_block
fill 150 252 314 150 255 314 minecraft:packed_ice
setblock 151 252 277 minecraft:snow_block
fill 151 252 313 151 253 313 minecraft:packed_ice
setblock 152 252 276 minecraft:snow_block
setblock 152 252 278 minecraft:light[level=15]
setblock 152 252 286 minecraft:light[level=15]
setblock 152 252 294 minecraft:light[level=15]
setblock 152 252 302 minecraft:light[level=15]
setblock 152 252 310 minecraft:light[level=15]
setblock 152 252 316 minecraft:snow_block
fill 153 252 275 153 288 275 minecraft:snow_block
fill 153 252 276 153 255 276 minecraft:packed_ice
setblock 153 252 315 minecraft:snow_block
fill 153 252 316 153 255 316 minecraft:packed_ice
setblock 154 252 314 minecraft:snow_block
fill 154 252 315 154 255 315 minecraft:packed_ice
fill 155 252 314 155 253 314 minecraft:packed_ice
setblock 157 252 316 minecraft:snow_block
setblock 158 252 315 minecraft:snow_block
fill 158 252 316 161 252 316 minecraft:packed_ice
setblock 160 252 278 minecraft:light[level=15]
setblock 160 252 286 minecraft:light[level=15]
setblock 160 252 302 minecraft:light[level=15]
setblock 160 252 310 minecraft:light[level=15]
setblock 162 252 316 minecraft:snow_block
fill 163 252 316 166 252 316 minecraft:packed_ice
fill 164 252 275 171 254 275 minecraft:snow_block
setblock 167 252 315 minecraft:packed_ice
setblock 167 252 316 minecraft:snow_block
setblock 168 252 278 minecraft:light[level=15]
setblock 168 252 286 minecraft:light[level=15]
setblock 168 252 294 minecraft:light[level=15]
setblock 168 252 302 minecraft:light[level=15]
setblock 168 252 310 minecraft:light[level=15]
setblock 168 252 315 minecraft:snow_block
fill 168 252 316 168 255 316 minecraft:packed_ice
fill 169 252 315 169 255 315 minecraft:packed_ice
setblock 172 252 275 minecraft:light_blue_concrete
setblock 172 252 276 minecraft:snow_block
setblock 172 252 316 minecraft:snow_block
fill 173 252 276 173 255 276 minecraft:packed_ice
setblock 173 252 315 minecraft:snow_block
fill 173 252 316 173 255 316 minecraft:packed_ice
setblock 174 252 275 minecraft:light_blue_concrete
fill 175 252 275 178 252 275 minecraft:snow_block
setblock 176 252 278 minecraft:light[level=15]
setblock 176 252 286 minecraft:light[level=15]
setblock 176 252 294 minecraft:light[level=15]
setblock 176 252 302 minecraft:light[level=15]
setblock 176 252 310 minecraft:light[level=15]
setblock 182 252 287 minecraft:packed_ice
setblock 182 252 291 minecraft:snow_block
fill 182 252 292 182 255 292 minecraft:packed_ice
fill 183 252 296 183 257 297 minecraft:snow_block
setblock 183 252 298 minecraft:white_concrete
fill 141 253 280 141 258 285 minecraft:snow_block
setblock 141 253 286 minecraft:light_blue_concrete
fill 141 253 287 141 266 288 minecraft:snow_block
fill 142 253 276 142 256 276 minecraft:packed_ice
setblock 142 253 314 minecraft:packed_ice
setblock 142 253 315 minecraft:snow_block
fill 142 253 316 145 253 316 minecraft:packed_ice
setblock 142 253 317 minecraft:light_blue_concrete
setblock 143 253 314 minecraft:snow_block
fill 143 253 315 143 256 315 minecraft:packed_ice
fill 143 253 317 150 254 317 minecraft:snow_block
fill 145 253 314 145 255 314 minecraft:packed_ice
setblock 146 253 276 minecraft:snow_block
fill 146 253 277 146 256 277 minecraft:packed_ice
setblock 146 253 316 minecraft:snow_block
fill 147 253 276 147 256 276 minecraft:packed_ice
setblock 147 253 315 minecraft:snow_block
fill 147 253 316 147 256 316 minecraft:packed_ice
setblock 148 253 314 minecraft:snow_block
fill 148 253 315 148 256 315 minecraft:packed_ice
setblock 149 253 313 minecraft:snow_block
fill 149 253 314 149 256 314 minecraft:packed_ice
setblock 150 253 277 minecraft:snow_block
fill 150 253 313 150 254 313 minecraft:packed_ice
setblock 151 253 276 minecraft:snow_block
fill 151 253 277 151 256 277 minecraft:packed_ice
setblock 151 253 316 minecraft:snow_block
fill 152 253 276 152 256 276 minecraft:packed_ice
setblock 152 253 315 minecraft:snow_block
fill 152 253 316 152 256 316 minecraft:packed_ice
setblock 153 253 314 minecraft:snow_block
fill 153 253 315 153 256 315 minecraft:packed_ice
fill 154 253 314 154 254 314 minecraft:packed_ice
setblock 156 253 316 minecraft:snow_block
setblock 157 253 315 minecraft:snow_block
fill 157 253 316 160 253 316 minecraft:packed_ice
setblock 161 253 316 minecraft:snow_block
fill 162 253 316 165 253 316 minecraft:packed_ice
setblock 166 253 316 minecraft:snow_block
setblock 167 253 315 minecraft:snow_block
fill 167 253 316 167 256 316 minecraft:packed_ice
fill 168 253 276 168 255 276 minecraft:packed_ice
fill 168 253 315 168 256 315 minecraft:packed_ice
setblock 171 253 276 minecraft:snow_block
setblock 171 253 316 minecraft:snow_block
fill 172 253 275 172 308 275 minecraft:snow_block
fill 172 253 276 172 256 276 minecraft:packed_ice
setblock 172 253 315 minecraft:snow_block
fill 172 253 316 172 256 316 minecraft:packed_ice
fill 174 253 275 177 254 275 minecraft:snow_block
setblock 176 253 276 minecraft:snow_block
setblock 178 253 275 minecraft:light_blue_concrete
fill 182 253 276 182 256 276 minecraft:packed_ice
setblock 182 253 290 minecraft:snow_block
fill 182 253 291 182 256 291 minecraft:packed_ice
setblock 182 253 295 minecraft:snow_block
fill 183 253 298 183 296 298 minecraft:snow_block
fill 141 254 275 141 308 275 minecraft:snow_block
setblock 141 254 276 minecraft:white_concrete
fill 141 254 286 141 276 286 minecraft:snow_block
setblock 142 254 278 minecraft:packed_ice
setblock 142 254 279 minecraft:blue_ice
setblock 142 254 314 minecraft:snow_block
fill 142 254 315 142 256 316 minecraft:packed_ice
fill 142 254 317 142 308 317 minecraft:snow_block
setblock 143 254 313 minecraft:snow_block
fill 143 254 314 143 257 314 minecraft:packed_ice
fill 143 254 316 144 254 316 minecraft:packed_ice
fill 144 254 303 144 255 303 minecraft:packed_ice
setblock 145 254 276 minecraft:snow_block
fill 145 254 277 145 257 277 minecraft:packed_ice
fill 145 254 302 145 255 302 minecraft:packed_ice
fill 145 254 304 145 255 304 minecraft:packed_ice
setblock 145 254 316 minecraft:snow_block
fill 146 254 276 146 257 276 minecraft:packed_ice
fill 146 254 303 146 255 303 minecraft:packed_ice
setblock 146 254 315 minecraft:snow_block
fill 146 254 316 146 257 316 minecraft:packed_ice
setblock 147 254 314 minecraft:snow_block
fill 147 254 315 147 257 315 minecraft:packed_ice
fill 148 254 314 148 257 314 minecraft:packed_ice
setblock 149 254 277 minecraft:snow_block
setblock 149 254 313 minecraft:packed_ice
setblock 150 254 276 minecraft:snow_block
fill 150 254 277 150 257 277 minecraft:packed_ice
setblock 150 254 316 minecraft:snow_block
fill 151 254 276 151 257 276 minecraft:packed_ice
setblock 151 254 315 minecraft:snow_block
fill 151 254 316 151 257 316 minecraft:packed_ice
setblock 152 254 314 minecraft:snow_block
fill 152 254 315 152 257 315 minecraft:packed_ice
fill 153 254 314 153 256 314 minecraft:packed_ice
setblock 155 254 316 minecraft:snow_block
setblock 156 254 315 minecraft:snow_block
fill 156 254 316 159 254 316 minecraft:packed_ice
fill 158 254 275 161 265 275 minecraft:snow_block
setblock 160 254 316 minecraft:snow_block
fill 161 254 316 164 254 316 minecraft:packed_ice
setblock 162 254 275 minecraft:light_blue_concrete
setblock 165 254 316 minecraft:snow_block
fill 166 254 316 166 257 316 minecraft:packed_ice
fill 167 254 276 167 256 276 minecraft:packed_ice
fill 167 254 315 167 257 315 minecraft:packed_ice
setblock 170 254 276 minecraft:snow_block
setblock 170 254 316 minecraft:snow_block
setblock 170 254 317 minecraft:white_concrete
fill 171 254 276 171 257 276 minecraft:packed_ice
setblock 171 254 315 minecraft:snow_block
fill 171 254 316 171 257 316 minecraft:packed_ice
fill 171 254 317 172 308 317 minecraft:snow_block
fill 173 254 284 174 255 285 minecraft:snow_block
setblock 175 254 276 minecraft:snow_block
setblock 175 254 316 minecraft:snow_block
fill 176 254 276 176 257 276 minecraft:packed_ice
fill 178 254 275 178 308 275 minecraft:snow_block
setblock 180 254 276 minecraft:snow_block
fill 181 254 276 181 257 276 minecraft:packed_ice
fill 182 254 277 182 254 278 minecraft:packed_ice
setblock 182 254 289 minecraft:snow_block
fill 182 254 290 182 257 290 minecraft:packed_ice
setblock 182 254 294 minecraft:snow_block
fill 182 254 295 182 257 295 minecraft:packed_ice
fill 182 254 316 182 256 316 minecraft:packed_ice
setblock 183 254 292 minecraft:light_blue_concrete
fill 141 255 276 141 308 276 minecraft:snow_block
setblock 142 255 278 minecraft:snow_block
fill 142 255 279 142 258 279 minecraft:packed_ice
fill 142 255 280 143 255 280 minecraft:blue_ice
setblock 142 255 313 minecraft:snow_block
fill 142 255 314 142 258 314 minecraft:packed_ice
setblock 143 255 277 minecraft:snow_block
fill 143 255 278 143 255 279 minecraft:blue_ice
fill 143 255 313 143 258 313 minecraft:packed_ice
setblock 143 255 316 minecraft:packed_ice
setblock 143 255 317 minecraft:white_concrete
setblock 144 255 276 minecraft:snow_block
fill 144 255 277 144 258 277 minecraft:packed_ice
fill 144 255 279 145 256 279 minecraft:blue_ice
fill 144 255 316 144 255 317 minecraft:snow_block
fill 145 255 276 145 258 276 minecraft:packed_ice
setblock 145 255 315 minecraft:snow_block
fill 145 255 316 145 258 316 minecraft:packed_ice
fill 145 255 317 150 291 317 minecraft:snow_block
setblock 146 255 314 minecraft:snow_block
fill 146 255 315 146 258 315 minecraft:packed_ice
fill 147 255 314 147 258 314 minecraft:packed_ice
setblock 148 255 277 minecraft:snow_block
setblock 149 255 276 minecraft:snow_block
fill 149 255 277 149 258 277 minecraft:packed_ice
setblock 149 255 316 minecraft:snow_block
fill 150 255 276 150 258 276 minecraft:packed_ice
setblock 150 255 315 minecraft:snow_block
fill 150 255 316 150 258 316 minecraft:packed_ice
setblock 151 255 314 minecraft:snow_block
fill 151 255 315 151 258 315 minecraft:packed_ice
setblock 151 255 317 minecraft:light_blue_concrete
fill 152 255 314 152 258 314 minecraft:packed_ice
setblock 154 255 276 minecraft:snow_block
setblock 154 255 316 minecraft:snow_block
setblock 155 255 315 minecraft:snow_block
fill 155 255 316 158 255 316 minecraft:packed_ice
setblock 156 255 315 minecraft:packed_ice
setblock 159 255 316 minecraft:snow_block
fill 160 255 316 163 255 316 minecraft:packed_ice
fill 162 255 275 162 308 275 minecraft:snow_block
fill 164 255 275 164 308 275 minecraft:snow_block
setblock 164 255 316 minecraft:snow_block
setblock 165 255 275 minecraft:white_concrete
fill 165 255 276 166 257 276 minecraft:packed_ice
fill 165 255 316 165 258 316 minecraft:packed_ice
fill 166 255 275 170 293 275 minecraft:snow_block
fill 166 255 315 166 258 315 minecraft:packed_ice
fill 167 255 317 167 283 317 minecraft:snow_block
setblock 168 255 317 minecraft:white_concrete
setblock 169 255 276 minecraft:snow_block
setblock 169 255 316 minecraft:snow_block
fill 170 255 276 170 257 277 minecraft:packed_ice
setblock 170 255 315 minecraft:snow_block
fill 170 255 316 170 258 316 minecraft:packed_ice
fill 170 255 317 170 263 317 minecraft:snow_block
setblock 171 255 275 minecraft:light_blue_concrete
fill 174 255 275 174 255 276 minecraft:snow_block
setblock 174 255 316 minecraft:snow_block
fill 175 255 275 175 284 275 minecraft:snow_block
fill 175 255 276 175 258 276 minecraft:packed_ice
setblock 176 255 275 minecraft:white_concrete
fill 177 255 275 177 308 275 minecraft:snow_block
fill 177 255 276 178 255 276 minecraft:packed_ice
setblock 179 255 276 minecraft:snow_block
fill 180 255 276 180 258 276 minecraft:packed_ice
setblock 182 255 277 minecraft:packed_ice
setblock 182 255 278 minecraft:snow_block
fill 182 255 279 182 258 279 minecraft:packed_ice
setblock 182 255 293 minecraft:snow_block
fill 182 255 294 182 258 294 minecraft:packed_ice
fill 182 255 296 182 256 296 minecraft:packed_ice
fill 182 255 315 182 257 315 minecraft:packed_ice
fill 183 255 292 183 308 292 minecraft:snow_block
setblock 183 255 305 minecraft:light_blue_concrete
setblock 142 256 277 minecraft:snow_block
fill 142 256 278 143 258 278 minecraft:packed_ice
fill 142 256 280 142 257 280 minecraft:packed_ice
setblock 142 256 311 minecraft:packed_ice
setblock 142 256 312 minecraft:snow_block
fill 142 256 313 142 259 313 minecraft:packed_ice
setblock 143 256 276 minecraft:snow_block
fill 143 256 277 143 259 277 minecraft:packed_ice
fill 143 256 279 143 256 280 minecraft:blue_ice
fill 143 256 316 143 256 317 minecraft:snow_block
fill 144 256 276 144 259 276 minecraft:packed_ice
fill 144 256 278 144 257 278 minecraft:blue_ice
fill 144 256 280 144 258 280 minecraft:blue_ice
setblock 144 256 285 minecraft:light[level=12]
setblock 144 256 292 minecraft:light[level=12]
setblock 144 256 299 minecraft:light[level=12]
setblock 144 256 306 minecraft:light[level=12]
setblock 144 256 313 minecraft:light[level=12]
setblock 144 256 314 minecraft:packed_ice
setblock 144 256 315 minecraft:snow_block
fill 144 256 316 144 259 316 minecraft:packed_ice
fill 144 256 317 144 290 317 minecraft:snow_block
setblock 145 256 314 minecraft:snow_block
fill 145 256 315 145 259 315 minecraft:packed_ice
fill 146 256 279 147 256 279 minecraft:blue_ice
fill 146 256 314 146 259 314 minecraft:packed_ice
setblock 147 256 277 minecraft:snow_block
setblock 148 256 276 minecraft:snow_block
fill 148 256 277 148 259 277 minecraft:packed_ice
setblock 148 256 316 minecraft:snow_block
fill 149 256 276 149 259 276 minecraft:packed_ice
setblock 149 256 315 minecraft:snow_block
fill 149 256 316 149 259 316 minecraft:packed_ice
setblock 150 256 314 minecraft:snow_block
fill 150 256 315 150 259 315 minecraft:packed_ice
setblock 151 256 278 minecraft:light[level=12]
setblock 151 256 285 minecraft:light[level=12]
setblock 151 256 292 minecraft:light[level=12]
setblock 151 256 299 minecraft:light[level=12]
setblock 151 256 306 minecraft:light[level=12]
setblock 151 256 313 minecraft:light[level=12]
fill 151 256 314 151 259 314 minecraft:packed_ice
fill 151 256 317 151 272 317 minecraft:snow_block
setblock 153 256 276 minecraft:snow_block
setblock 153 256 316 minecraft:snow_block
fill 154 256 276 154 259 276 minecraft:packed_ice
schedule function dropper:buildpart/63_9 1t
