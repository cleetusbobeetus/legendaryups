setblock 144 235 390 minecraft:jack_o_lantern
setblock 144 235 392 minecraft:jack_o_lantern
setblock 144 235 394 minecraft:jack_o_lantern
setblock 144 235 396 minecraft:jack_o_lantern
setblock 144 235 404 minecraft:light[level=14]
fill 145 235 370 146 235 370 minecraft:red_concrete
setblock 145 235 387 minecraft:jack_o_lantern
setblock 145 235 389 minecraft:jack_o_lantern
setblock 145 235 391 minecraft:jack_o_lantern
setblock 145 235 393 minecraft:jack_o_lantern
setblock 145 235 395 minecraft:jack_o_lantern
setblock 146 235 386 minecraft:jack_o_lantern
setblock 146 235 388 minecraft:jack_o_lantern
setblock 146 235 390 minecraft:jack_o_lantern
setblock 146 235 392 minecraft:jack_o_lantern
setblock 146 235 394 minecraft:jack_o_lantern
setblock 146 235 396 minecraft:jack_o_lantern
setblock 146 235 410 minecraft:white_concrete
setblock 147 235 387 minecraft:jack_o_lantern
setblock 147 235 389 minecraft:jack_o_lantern
setblock 147 235 391 minecraft:jack_o_lantern
setblock 147 235 393 minecraft:jack_o_lantern
setblock 147 235 395 minecraft:jack_o_lantern
setblock 148 235 370 minecraft:red_concrete
setblock 148 235 386 minecraft:jack_o_lantern
setblock 148 235 388 minecraft:jack_o_lantern
setblock 148 235 390 minecraft:jack_o_lantern
setblock 148 235 392 minecraft:jack_o_lantern
setblock 148 235 394 minecraft:jack_o_lantern
setblock 148 235 396 minecraft:jack_o_lantern
setblock 149 235 387 minecraft:jack_o_lantern
setblock 149 235 389 minecraft:jack_o_lantern
setblock 149 235 391 minecraft:jack_o_lantern
setblock 149 235 393 minecraft:jack_o_lantern
setblock 149 235 395 minecraft:jack_o_lantern
setblock 150 235 386 minecraft:jack_o_lantern
setblock 150 235 388 minecraft:jack_o_lantern
setblock 150 235 390 minecraft:jack_o_lantern
setblock 150 235 392 minecraft:jack_o_lantern
setblock 150 235 394 minecraft:jack_o_lantern
setblock 150 235 396 minecraft:jack_o_lantern
setblock 151 235 387 minecraft:jack_o_lantern
setblock 151 235 389 minecraft:jack_o_lantern
setblock 151 235 391 minecraft:jack_o_lantern
setblock 151 235 393 minecraft:jack_o_lantern
setblock 151 235 395 minecraft:jack_o_lantern
setblock 152 235 372 minecraft:light[level=14]
setblock 152 235 380 minecraft:light[level=14]
setblock 152 235 388 minecraft:light[level=14]
setblock 152 235 396 minecraft:light[level=14]
setblock 152 235 404 minecraft:light[level=14]
setblock 153 235 410 minecraft:white_concrete
setblock 154 235 370 minecraft:white_concrete
setblock 160 235 372 minecraft:light[level=14]
setblock 160 235 380 minecraft:light[level=14]
setblock 160 235 388 minecraft:light[level=14]
setblock 160 235 396 minecraft:light[level=14]
setblock 160 235 404 minecraft:light[level=14]
setblock 160 235 410 minecraft:white_concrete
setblock 161 235 370 minecraft:white_concrete
setblock 167 235 410 minecraft:white_concrete
setblock 168 235 370 minecraft:white_concrete
setblock 168 235 372 minecraft:light[level=14]
setblock 168 235 380 minecraft:light[level=14]
setblock 168 235 388 minecraft:light[level=14]
setblock 168 235 396 minecraft:light[level=14]
setblock 168 235 404 minecraft:light[level=14]
setblock 169 235 403 minecraft:jack_o_lantern
setblock 169 235 405 minecraft:jack_o_lantern
setblock 169 235 407 minecraft:jack_o_lantern
setblock 169 235 409 minecraft:jack_o_lantern
setblock 170 235 404 minecraft:jack_o_lantern
setblock 170 235 406 minecraft:jack_o_lantern
setblock 170 235 408 minecraft:jack_o_lantern
setblock 170 235 410 minecraft:jack_o_lantern
setblock 171 235 403 minecraft:jack_o_lantern
setblock 171 235 405 minecraft:jack_o_lantern
setblock 171 235 407 minecraft:jack_o_lantern
setblock 171 235 409 minecraft:jack_o_lantern
setblock 172 235 404 minecraft:jack_o_lantern
setblock 172 235 406 minecraft:jack_o_lantern
setblock 172 235 408 minecraft:jack_o_lantern
setblock 172 235 410 minecraft:jack_o_lantern
setblock 173 235 403 minecraft:jack_o_lantern
setblock 173 235 405 minecraft:jack_o_lantern
setblock 173 235 407 minecraft:jack_o_lantern
setblock 173 235 409 minecraft:jack_o_lantern
setblock 174 235 404 minecraft:jack_o_lantern
setblock 174 235 406 minecraft:jack_o_lantern
setblock 174 235 408 minecraft:jack_o_lantern
setblock 174 235 410 minecraft:jack_o_lantern
setblock 175 235 370 minecraft:white_concrete
setblock 175 235 403 minecraft:jack_o_lantern
setblock 175 235 405 minecraft:jack_o_lantern
setblock 175 235 407 minecraft:jack_o_lantern
setblock 175 235 409 minecraft:jack_o_lantern
setblock 176 235 372 minecraft:light[level=14]
setblock 176 235 388 minecraft:light[level=14]
setblock 176 235 396 minecraft:light[level=14]
setblock 176 235 404 minecraft:jack_o_lantern
setblock 176 235 406 minecraft:jack_o_lantern
setblock 176 235 408 minecraft:jack_o_lantern
setblock 176 235 410 minecraft:jack_o_lantern
setblock 177 235 403 minecraft:jack_o_lantern
setblock 177 235 405 minecraft:jack_o_lantern
setblock 177 235 407 minecraft:jack_o_lantern
setblock 177 235 409 minecraft:jack_o_lantern
setblock 178 235 404 minecraft:jack_o_lantern
setblock 178 235 406 minecraft:jack_o_lantern
setblock 178 235 408 minecraft:jack_o_lantern
setblock 178 235 410 minecraft:jack_o_lantern
setblock 179 235 403 minecraft:jack_o_lantern
setblock 179 235 405 minecraft:jack_o_lantern
setblock 179 235 407 minecraft:jack_o_lantern
setblock 179 235 409 minecraft:jack_o_lantern
setblock 180 235 404 minecraft:jack_o_lantern
setblock 180 235 406 minecraft:jack_o_lantern
setblock 180 235 408 minecraft:jack_o_lantern
setblock 180 235 410 minecraft:jack_o_lantern
setblock 181 235 403 minecraft:jack_o_lantern
setblock 181 235 405 minecraft:jack_o_lantern
setblock 181 235 407 minecraft:jack_o_lantern
setblock 181 235 409 minecraft:jack_o_lantern
setblock 182 235 370 minecraft:white_concrete
setblock 182 235 384 minecraft:white_concrete
setblock 182 235 391 minecraft:white_concrete
setblock 182 235 398 minecraft:white_concrete
setblock 182 235 405 minecraft:white_concrete
setblock 142 236 373 minecraft:white_concrete
setblock 142 236 380 minecraft:white_concrete
fill 142 236 386 142 237 386 minecraft:white_concrete
fill 142 236 388 142 237 388 minecraft:white_concrete
fill 142 236 390 142 237 390 minecraft:white_concrete
fill 142 236 392 142 237 392 minecraft:white_concrete
fill 142 236 394 142 237 394 minecraft:white_concrete
fill 142 236 396 142 237 396 minecraft:white_concrete
setblock 142 236 401 minecraft:white_concrete
setblock 142 236 408 minecraft:white_concrete
fill 143 236 387 143 237 387 minecraft:white_concrete
fill 143 236 389 143 237 389 minecraft:white_concrete
fill 143 236 391 143 237 391 minecraft:white_concrete
fill 143 236 393 143 237 393 minecraft:white_concrete
fill 143 236 395 143 237 395 minecraft:white_concrete
fill 144 236 371 147 236 375 minecraft:red_concrete
fill 144 236 386 144 237 386 minecraft:white_concrete
fill 144 236 388 144 237 388 minecraft:white_concrete
fill 144 236 390 144 237 390 minecraft:white_concrete
fill 144 236 392 144 237 392 minecraft:white_concrete
fill 144 236 394 144 237 394 minecraft:white_concrete
fill 144 236 396 144 237 396 minecraft:white_concrete
setblock 145 236 370 minecraft:red_concrete
fill 145 236 387 145 237 387 minecraft:white_concrete
fill 145 236 389 145 237 389 minecraft:white_concrete
fill 145 236 391 145 237 391 minecraft:white_concrete
fill 145 236 393 145 237 393 minecraft:white_concrete
fill 145 236 395 145 237 395 minecraft:white_concrete
setblock 146 236 370 minecraft:white_concrete
fill 146 236 386 146 237 386 minecraft:white_concrete
fill 146 236 388 146 237 388 minecraft:white_concrete
fill 146 236 390 146 237 390 minecraft:white_concrete
fill 146 236 392 146 237 392 minecraft:white_concrete
fill 146 236 394 146 237 394 minecraft:white_concrete
fill 146 236 396 146 237 396 minecraft:white_concrete
setblock 147 236 370 minecraft:red_concrete
fill 147 236 387 147 237 387 minecraft:white_concrete
fill 147 236 389 147 237 389 minecraft:white_concrete
fill 147 236 391 147 237 391 minecraft:white_concrete
fill 147 236 393 147 237 393 minecraft:white_concrete
fill 147 236 395 147 237 395 minecraft:white_concrete
setblock 147 236 410 minecraft:white_concrete
fill 148 236 386 148 237 386 minecraft:white_concrete
fill 148 236 388 148 237 388 minecraft:white_concrete
fill 148 236 390 148 237 390 minecraft:white_concrete
fill 148 236 392 148 237 392 minecraft:white_concrete
fill 148 236 394 148 237 394 minecraft:white_concrete
fill 148 236 396 148 237 396 minecraft:white_concrete
fill 149 236 387 149 237 387 minecraft:white_concrete
fill 149 236 389 149 237 389 minecraft:white_concrete
fill 149 236 391 149 237 391 minecraft:white_concrete
fill 149 236 393 149 237 393 minecraft:white_concrete
fill 149 236 395 149 237 395 minecraft:white_concrete
fill 150 236 386 150 237 386 minecraft:white_concrete
fill 150 236 388 150 237 388 minecraft:white_concrete
fill 150 236 390 150 237 390 minecraft:white_concrete
fill 150 236 392 150 237 392 minecraft:white_concrete
fill 150 236 394 150 237 394 minecraft:white_concrete
fill 150 236 396 150 237 396 minecraft:white_concrete
fill 151 236 387 151 237 387 minecraft:white_concrete
fill 151 236 389 151 237 389 minecraft:white_concrete
fill 151 236 391 151 237 391 minecraft:white_concrete
fill 151 236 393 151 237 393 minecraft:white_concrete
fill 151 236 395 151 237 395 minecraft:white_concrete
setblock 153 236 370 minecraft:white_concrete
setblock 154 236 410 minecraft:white_concrete
setblock 160 236 370 minecraft:white_concrete
setblock 161 236 410 minecraft:white_concrete
setblock 167 236 370 minecraft:white_concrete
setblock 168 236 410 minecraft:white_concrete
fill 169 236 403 169 237 403 minecraft:white_concrete
fill 169 236 405 169 237 405 minecraft:white_concrete
fill 169 236 407 169 237 407 minecraft:white_concrete
fill 169 236 409 169 237 409 minecraft:white_concrete
fill 170 236 404 170 237 404 minecraft:white_concrete
fill 170 236 406 170 237 406 minecraft:white_concrete
fill 170 236 408 170 237 408 minecraft:white_concrete
fill 170 236 410 170 237 410 minecraft:white_concrete
fill 171 236 403 171 237 403 minecraft:white_concrete
fill 171 236 405 171 237 405 minecraft:white_concrete
fill 171 236 407 171 237 407 minecraft:white_concrete
fill 171 236 409 171 237 409 minecraft:white_concrete
fill 172 236 404 172 237 404 minecraft:white_concrete
fill 172 236 406 172 237 406 minecraft:white_concrete
fill 172 236 408 172 237 408 minecraft:white_concrete
fill 172 236 410 172 237 410 minecraft:white_concrete
fill 173 236 403 173 237 403 minecraft:white_concrete
fill 173 236 405 173 237 405 minecraft:white_concrete
fill 173 236 407 173 237 407 minecraft:white_concrete
fill 173 236 409 173 237 409 minecraft:white_concrete
setblock 174 236 370 minecraft:white_concrete
fill 174 236 404 174 237 404 minecraft:white_concrete
fill 174 236 406 174 237 406 minecraft:white_concrete
fill 174 236 408 174 237 408 minecraft:white_concrete
fill 174 236 410 174 237 410 minecraft:white_concrete
fill 175 236 403 175 237 403 minecraft:white_concrete
fill 175 236 405 175 237 405 minecraft:white_concrete
fill 175 236 407 175 237 407 minecraft:white_concrete
fill 175 236 409 175 237 409 minecraft:white_concrete
fill 176 236 404 176 237 404 minecraft:white_concrete
fill 176 236 406 176 237 406 minecraft:white_concrete
fill 176 236 408 176 237 408 minecraft:white_concrete
fill 176 236 410 176 237 410 minecraft:white_concrete
fill 177 236 403 177 237 403 minecraft:white_concrete
fill 177 236 405 177 237 405 minecraft:white_concrete
fill 177 236 407 177 237 407 minecraft:white_concrete
fill 177 236 409 177 237 409 minecraft:white_concrete
fill 178 236 404 178 237 404 minecraft:white_concrete
fill 178 236 406 178 237 406 minecraft:white_concrete
fill 178 236 408 178 237 408 minecraft:white_concrete
fill 178 236 410 178 237 410 minecraft:white_concrete
fill 179 236 403 179 237 403 minecraft:white_concrete
fill 179 236 405 179 237 405 minecraft:white_concrete
fill 179 236 407 179 237 407 minecraft:white_concrete
fill 179 236 409 179 237 409 minecraft:white_concrete
fill 180 236 404 180 237 404 minecraft:white_concrete
fill 180 236 406 180 237 406 minecraft:white_concrete
fill 180 236 408 180 237 408 minecraft:white_concrete
fill 180 236 410 180 237 410 minecraft:white_concrete
setblock 181 236 370 minecraft:white_concrete
fill 181 236 403 181 237 403 minecraft:white_concrete
fill 181 236 405 181 237 405 minecraft:white_concrete
fill 181 236 407 181 237 407 minecraft:white_concrete
fill 181 236 409 181 237 409 minecraft:white_concrete
setblock 182 236 390 minecraft:white_concrete
setblock 182 236 397 minecraft:white_concrete
setblock 182 236 404 minecraft:white_concrete
setblock 182 236 410 minecraft:white_concrete
setblock 142 237 374 minecraft:white_concrete
setblock 142 237 381 minecraft:white_concrete
setblock 142 237 402 minecraft:white_concrete
setblock 142 237 409 minecraft:white_concrete
setblock 145 237 370 minecraft:white_concrete
fill 145 237 371 146 237 374 minecraft:red_concrete
setblock 146 237 370 minecraft:red_concrete
setblock 148 237 410 minecraft:white_concrete
setblock 152 237 370 minecraft:white_concrete
setblock 155 237 410 minecraft:white_concrete
setblock 159 237 370 minecraft:white_concrete
setblock 162 237 410 minecraft:white_concrete
setblock 166 237 370 minecraft:white_concrete
setblock 173 237 370 minecraft:white_concrete
setblock 180 237 370 minecraft:white_concrete
setblock 182 237 389 minecraft:white_concrete
setblock 182 237 396 minecraft:white_concrete
setblock 182 237 403 minecraft:white_concrete
setblock 142 238 386 minecraft:jack_o_lantern
setblock 142 238 388 minecraft:jack_o_lantern
setblock 142 238 390 minecraft:jack_o_lantern
setblock 142 238 392 minecraft:jack_o_lantern
setblock 142 238 394 minecraft:jack_o_lantern
setblock 142 238 396 minecraft:jack_o_lantern
setblock 143 238 387 minecraft:jack_o_lantern
setblock 143 238 389 minecraft:jack_o_lantern
setblock 143 238 391 minecraft:jack_o_lantern
setblock 143 238 393 minecraft:jack_o_lantern
setblock 143 238 395 minecraft:jack_o_lantern
setblock 144 238 386 minecraft:jack_o_lantern
setblock 144 238 388 minecraft:jack_o_lantern
setblock 144 238 390 minecraft:jack_o_lantern
setblock 144 238 392 minecraft:jack_o_lantern
setblock 144 238 394 minecraft:jack_o_lantern
setblock 144 238 396 minecraft:jack_o_lantern
fill 145 238 371 146 238 373 minecraft:red_concrete
setblock 145 238 387 minecraft:jack_o_lantern
setblock 145 238 389 minecraft:jack_o_lantern
setblock 145 238 391 minecraft:jack_o_lantern
setblock 145 238 393 minecraft:jack_o_lantern
setblock 145 238 395 minecraft:jack_o_lantern
setblock 146 238 386 minecraft:jack_o_lantern
setblock 146 238 388 minecraft:jack_o_lantern
setblock 146 238 390 minecraft:jack_o_lantern
setblock 146 238 392 minecraft:jack_o_lantern
setblock 146 238 394 minecraft:jack_o_lantern
setblock 146 238 396 minecraft:jack_o_lantern
setblock 147 238 387 minecraft:jack_o_lantern
setblock 147 238 389 minecraft:jack_o_lantern
setblock 147 238 391 minecraft:jack_o_lantern
setblock 147 238 393 minecraft:jack_o_lantern
setblock 147 238 395 minecraft:jack_o_lantern
setblock 148 238 386 minecraft:jack_o_lantern
setblock 148 238 388 minecraft:jack_o_lantern
setblock 148 238 390 minecraft:jack_o_lantern
setblock 148 238 392 minecraft:jack_o_lantern
setblock 148 238 394 minecraft:jack_o_lantern
setblock 148 238 396 minecraft:jack_o_lantern
setblock 149 238 387 minecraft:jack_o_lantern
setblock 149 238 389 minecraft:jack_o_lantern
setblock 149 238 391 minecraft:jack_o_lantern
setblock 149 238 393 minecraft:jack_o_lantern
setblock 149 238 395 minecraft:jack_o_lantern
setblock 150 238 386 minecraft:jack_o_lantern
setblock 150 238 388 minecraft:jack_o_lantern
setblock 150 238 390 minecraft:jack_o_lantern
setblock 150 238 392 minecraft:jack_o_lantern
setblock 150 238 394 minecraft:jack_o_lantern
setblock 150 238 396 minecraft:jack_o_lantern
setblock 151 238 387 minecraft:jack_o_lantern
setblock 151 238 389 minecraft:jack_o_lantern
setblock 151 238 391 minecraft:jack_o_lantern
setblock 151 238 393 minecraft:jack_o_lantern
setblock 151 238 395 minecraft:jack_o_lantern
setblock 169 238 403 minecraft:jack_o_lantern
setblock 169 238 405 minecraft:jack_o_lantern
setblock 169 238 407 minecraft:jack_o_lantern
setblock 169 238 409 minecraft:jack_o_lantern
setblock 170 238 404 minecraft:jack_o_lantern
setblock 170 238 406 minecraft:jack_o_lantern
setblock 170 238 408 minecraft:jack_o_lantern
setblock 170 238 410 minecraft:jack_o_lantern
setblock 171 238 403 minecraft:jack_o_lantern
setblock 171 238 405 minecraft:jack_o_lantern
setblock 171 238 407 minecraft:jack_o_lantern
setblock 171 238 409 minecraft:jack_o_lantern
setblock 172 238 404 minecraft:jack_o_lantern
setblock 172 238 406 minecraft:jack_o_lantern
setblock 172 238 408 minecraft:jack_o_lantern
setblock 172 238 410 minecraft:jack_o_lantern
setblock 173 238 403 minecraft:jack_o_lantern
setblock 173 238 405 minecraft:jack_o_lantern
setblock 173 238 407 minecraft:jack_o_lantern
setblock 173 238 409 minecraft:jack_o_lantern
setblock 174 238 404 minecraft:jack_o_lantern
setblock 174 238 406 minecraft:jack_o_lantern
setblock 174 238 408 minecraft:jack_o_lantern
setblock 174 238 410 minecraft:jack_o_lantern
setblock 175 238 403 minecraft:jack_o_lantern
setblock 175 238 405 minecraft:jack_o_lantern
setblock 175 238 407 minecraft:jack_o_lantern
setblock 175 238 409 minecraft:jack_o_lantern
setblock 176 238 404 minecraft:jack_o_lantern
setblock 176 238 406 minecraft:jack_o_lantern
setblock 176 238 408 minecraft:jack_o_lantern
setblock 176 238 410 minecraft:jack_o_lantern
setblock 177 238 403 minecraft:jack_o_lantern
setblock 177 238 405 minecraft:jack_o_lantern
setblock 177 238 407 minecraft:jack_o_lantern
setblock 177 238 409 minecraft:jack_o_lantern
setblock 178 238 404 minecraft:jack_o_lantern
setblock 178 238 406 minecraft:jack_o_lantern
setblock 178 238 408 minecraft:jack_o_lantern
setblock 178 238 410 minecraft:jack_o_lantern
setblock 179 238 403 minecraft:jack_o_lantern
setblock 179 238 405 minecraft:jack_o_lantern
setblock 179 238 407 minecraft:jack_o_lantern
setblock 179 238 409 minecraft:jack_o_lantern
setblock 180 238 404 minecraft:jack_o_lantern
setblock 180 238 406 minecraft:jack_o_lantern
setblock 180 238 408 minecraft:jack_o_lantern
setblock 180 238 410 minecraft:jack_o_lantern
setblock 181 238 403 minecraft:jack_o_lantern
setblock 181 238 405 minecraft:jack_o_lantern
setblock 181 238 407 minecraft:jack_o_lantern
setblock 181 238 409 minecraft:jack_o_lantern
fill 142 239 376 142 240 376 minecraft:white_concrete
fill 142 239 383 142 240 383 minecraft:white_concrete
fill 142 239 386 142 240 386 minecraft:white_concrete
fill 142 239 388 142 240 388 minecraft:white_concrete
fill 142 239 390 142 240 390 minecraft:white_concrete
fill 142 239 392 142 241 392 minecraft:white_concrete
fill 142 239 394 142 240 394 minecraft:white_concrete
fill 142 239 396 142 240 397 minecraft:white_concrete
fill 142 239 404 142 240 404 minecraft:white_concrete
fill 143 239 370 143 240 370 minecraft:white_concrete
fill 143 239 387 143 240 387 minecraft:white_concrete
fill 143 239 389 143 240 389 minecraft:white_concrete
fill 143 239 391 143 240 391 minecraft:white_concrete
fill 143 239 393 143 240 393 minecraft:white_concrete
fill 143 239 395 143 240 395 minecraft:white_concrete
fill 143 239 410 143 240 410 minecraft:white_concrete
fill 144 239 386 144 240 386 minecraft:white_concrete
fill 144 239 388 144 240 388 minecraft:white_concrete
fill 144 239 390 144 240 390 minecraft:white_concrete
fill 144 239 392 144 240 392 minecraft:white_concrete
fill 144 239 394 144 240 394 minecraft:white_concrete
fill 144 239 396 144 240 396 minecraft:white_concrete
fill 145 239 387 145 240 387 minecraft:white_concrete
fill 145 239 389 145 240 389 minecraft:white_concrete
fill 145 239 391 145 240 391 minecraft:white_concrete
fill 145 239 393 145 240 393 minecraft:white_concrete
fill 145 239 395 145 240 395 minecraft:white_concrete
fill 146 239 386 146 240 386 minecraft:white_concrete
fill 146 239 388 146 240 388 minecraft:white_concrete
fill 146 239 390 146 240 390 minecraft:white_concrete
fill 146 239 392 146 240 392 minecraft:white_concrete
fill 146 239 394 146 240 394 minecraft:white_concrete
fill 146 239 396 146 240 396 minecraft:white_concrete
fill 147 239 387 147 240 387 minecraft:white_concrete
fill 147 239 389 147 240 389 minecraft:white_concrete
fill 147 239 391 147 240 391 minecraft:white_concrete
fill 147 239 393 147 240 393 minecraft:white_concrete
fill 147 239 395 147 240 395 minecraft:white_concrete
fill 148 239 386 148 240 386 minecraft:white_concrete
fill 148 239 388 148 240 388 minecraft:white_concrete
fill 148 239 390 148 240 390 minecraft:white_concrete
fill 148 239 392 148 240 392 minecraft:white_concrete
fill 148 239 394 148 240 394 minecraft:white_concrete
fill 148 239 396 148 240 396 minecraft:white_concrete
fill 149 239 387 149 240 387 minecraft:white_concrete
fill 149 239 389 149 240 389 minecraft:white_concrete
fill 149 239 391 149 240 391 minecraft:white_concrete
fill 149 239 393 149 240 393 minecraft:white_concrete
fill 149 239 395 149 240 395 minecraft:white_concrete
fill 150 239 370 150 240 370 minecraft:white_concrete
fill 150 239 386 150 240 386 minecraft:white_concrete
fill 150 239 388 150 240 388 minecraft:white_concrete
fill 150 239 390 150 240 390 minecraft:white_concrete
fill 150 239 392 150 240 392 minecraft:white_concrete
fill 150 239 394 150 240 394 minecraft:white_concrete
fill 150 239 396 150 240 396 minecraft:white_concrete
fill 150 239 410 150 240 410 minecraft:white_concrete
fill 151 239 387 151 240 387 minecraft:white_concrete
fill 151 239 389 151 240 389 minecraft:white_concrete
fill 151 239 391 151 240 391 minecraft:white_concrete
fill 151 239 393 151 240 393 minecraft:white_concrete
fill 151 239 395 151 240 395 minecraft:white_concrete
fill 157 239 370 157 240 370 minecraft:white_concrete
fill 157 239 410 157 240 410 minecraft:white_concrete
fill 164 239 370 164 240 370 minecraft:white_concrete
fill 164 239 410 164 240 410 minecraft:white_concrete
setblock 169 239 403 minecraft:white_concrete
setblock 169 239 405 minecraft:white_concrete
setblock 169 239 407 minecraft:white_concrete
setblock 169 239 409 minecraft:white_concrete
setblock 170 239 404 minecraft:white_concrete
setblock 170 239 406 minecraft:white_concrete
setblock 170 239 408 minecraft:white_concrete
fill 170 239 410 170 267 410 minecraft:white_concrete
fill 171 239 370 171 240 370 minecraft:white_concrete
setblock 171 239 403 minecraft:white_concrete
setblock 171 239 405 minecraft:white_concrete
setblock 171 239 407 minecraft:white_concrete
setblock 171 239 409 minecraft:white_concrete
setblock 172 239 404 minecraft:white_concrete
setblock 172 239 406 minecraft:white_concrete
setblock 172 239 408 minecraft:white_concrete
fill 172 239 410 172 240 410 minecraft:white_concrete
setblock 173 239 403 minecraft:white_concrete
setblock 173 239 405 minecraft:white_concrete
setblock 173 239 407 minecraft:white_concrete
setblock 173 239 409 minecraft:white_concrete
setblock 174 239 404 minecraft:white_concrete
setblock 174 239 406 minecraft:white_concrete
setblock 174 239 408 minecraft:white_concrete
fill 174 239 410 174 240 410 minecraft:white_concrete
setblock 175 239 403 minecraft:white_concrete
setblock 175 239 405 minecraft:white_concrete
setblock 175 239 407 minecraft:white_concrete
setblock 175 239 409 minecraft:white_concrete
setblock 176 239 404 minecraft:white_concrete
setblock 176 239 406 minecraft:white_concrete
setblock 176 239 408 minecraft:white_concrete
fill 176 239 410 176 240 410 minecraft:white_concrete
setblock 177 239 403 minecraft:white_concrete
setblock 177 239 405 minecraft:white_concrete
setblock 177 239 407 minecraft:white_concrete
setblock 177 239 409 minecraft:white_concrete
fill 178 239 370 178 240 370 minecraft:white_concrete
setblock 178 239 404 minecraft:white_concrete
setblock 178 239 406 minecraft:white_concrete
setblock 178 239 408 minecraft:white_concrete
fill 178 239 410 178 240 410 minecraft:white_concrete
setblock 179 239 403 minecraft:white_concrete
setblock 179 239 405 minecraft:white_concrete
setblock 179 239 407 minecraft:white_concrete
setblock 179 239 409 minecraft:white_concrete
setblock 180 239 404 minecraft:white_concrete
setblock 180 239 406 minecraft:white_concrete
setblock 180 239 408 minecraft:white_concrete
fill 180 239 410 180 241 410 minecraft:white_concrete
setblock 181 239 403 minecraft:white_concrete
setblock 181 239 405 minecraft:white_concrete
setblock 181 239 407 minecraft:white_concrete
setblock 181 239 409 minecraft:white_concrete
fill 182 239 387 182 240 387 minecraft:white_concrete
fill 182 239 394 182 240 394 minecraft:white_concrete
fill 182 239 401 182 240 401 minecraft:white_concrete
fill 182 239 408 182 240 408 minecraft:white_concrete
fill 142 240 370 142 240 374 minecraft:white_concrete
fill 142 240 377 142 240 381 minecraft:white_concrete
fill 142 240 384 142 240 385 minecraft:white_concrete
fill 142 240 398 142 240 402 minecraft:white_concrete
fill 142 240 405 142 240 409 minecraft:white_concrete
fill 144 240 410 148 240 410 minecraft:white_concrete
fill 145 240 370 149 240 370 minecraft:white_concrete
fill 151 240 410 155 240 410 minecraft:white_concrete
fill 152 240 370 156 240 370 minecraft:white_concrete
fill 158 240 410 162 240 410 minecraft:white_concrete
fill 159 240 370 163 240 370 minecraft:white_concrete
fill 165 240 410 168 240 410 minecraft:white_concrete
fill 166 240 370 170 240 370 minecraft:white_concrete
fill 170 240 404 180 240 409 minecraft:red_concrete
fill 173 240 370 177 240 370 minecraft:white_concrete
fill 174 240 374 181 240 382 minecraft:red_concrete
fill 180 240 370 182 240 370 minecraft:white_concrete
fill 182 240 371 182 240 386 minecraft:white_concrete
fill 182 240 389 182 240 393 minecraft:white_concrete
fill 182 240 396 182 240 400 minecraft:white_concrete
fill 182 240 403 182 240 407 minecraft:white_concrete
setblock 182 240 410 minecraft:white_concrete
setblock 142 241 371 minecraft:white_concrete
setblock 142 241 378 minecraft:white_concrete
setblock 142 241 385 minecraft:white_concrete
fill 142 241 396 142 267 396 minecraft:white_concrete
setblock 142 241 399 minecraft:white_concrete
setblock 142 241 406 minecraft:white_concrete
fill 143 241 387 150 241 395 minecraft:red_concrete
setblock 145 241 410 minecraft:white_concrete
setblock 148 241 370 minecraft:white_concrete
setblock 152 241 410 minecraft:white_concrete
setblock 155 241 370 minecraft:white_concrete
setblock 159 241 410 minecraft:white_concrete
setblock 162 241 370 minecraft:white_concrete
setblock 166 241 410 minecraft:white_concrete
setblock 169 241 370 minecraft:white_concrete
fill 171 241 405 179 241 408 minecraft:red_concrete
fill 175 241 375 180 241 381 minecraft:red_concrete
setblock 176 241 370 minecraft:white_concrete
setblock 182 241 371 minecraft:white_concrete
fill 182 241 374 182 267 374 minecraft:white_concrete
setblock 182 241 378 minecraft:white_concrete
fill 182 241 381 182 267 381 minecraft:white_concrete
setblock 182 241 385 minecraft:white_concrete
setblock 182 241 392 minecraft:white_concrete
setblock 182 241 399 minecraft:white_concrete
setblock 182 241 406 minecraft:white_concrete
setblock 142 242 372 minecraft:white_concrete
setblock 142 242 379 minecraft:white_concrete
setblock 142 242 386 minecraft:white_concrete
setblock 142 242 393 minecraft:white_concrete
setblock 142 242 400 minecraft:white_concrete
setblock 142 242 407 minecraft:white_concrete
fill 144 242 388 149 242 394 minecraft:red_concrete
setblock 146 242 410 minecraft:white_concrete
setblock 147 242 370 minecraft:white_concrete
setblock 153 242 410 minecraft:white_concrete
setblock 154 242 370 minecraft:white_concrete
setblock 160 242 410 minecraft:white_concrete
setblock 161 242 370 minecraft:white_concrete
setblock 167 242 410 minecraft:white_concrete
setblock 168 242 370 minecraft:white_concrete
fill 172 242 406 178 242 407 minecraft:red_concrete
setblock 174 242 410 minecraft:white_concrete
setblock 175 242 370 minecraft:white_concrete
fill 176 242 376 179 242 380 minecraft:red_concrete
setblock 181 242 410 minecraft:white_concrete
setblock 182 242 370 minecraft:white_concrete
setblock 182 242 377 minecraft:white_concrete
setblock 182 242 384 minecraft:white_concrete
setblock 182 242 391 minecraft:white_concrete
setblock 182 242 398 minecraft:white_concrete
setblock 182 242 405 minecraft:white_concrete
setblock 142 243 373 minecraft:white_concrete
setblock 142 243 380 minecraft:white_concrete
setblock 142 243 387 minecraft:white_concrete
setblock 142 243 394 minecraft:white_concrete
setblock 142 243 401 minecraft:white_concrete
setblock 142 243 408 minecraft:white_concrete
setblock 144 243 372 minecraft:light[level=14]
setblock 144 243 380 minecraft:light[level=14]
setblock 144 243 388 minecraft:light[level=14]
setblock 144 243 396 minecraft:light[level=14]
setblock 144 243 404 minecraft:light[level=14]
fill 145 243 389 148 243 393 minecraft:red_concrete
setblock 146 243 370 minecraft:white_concrete
setblock 147 243 410 minecraft:white_concrete
setblock 152 243 372 minecraft:light[level=14]
setblock 152 243 380 minecraft:light[level=14]
setblock 152 243 388 minecraft:light[level=14]
setblock 152 243 396 minecraft:light[level=14]
setblock 152 243 404 minecraft:light[level=14]
setblock 153 243 370 minecraft:white_concrete
setblock 154 243 410 minecraft:white_concrete
setblock 160 243 370 minecraft:white_concrete
setblock 160 243 372 minecraft:light[level=14]
setblock 160 243 380 minecraft:light[level=14]
setblock 160 243 388 minecraft:light[level=14]
setblock 160 243 396 minecraft:light[level=14]
setblock 160 243 404 minecraft:light[level=14]
setblock 161 243 410 minecraft:white_concrete
setblock 167 243 370 minecraft:white_concrete
setblock 168 243 372 minecraft:light[level=14]
setblock 168 243 380 minecraft:light[level=14]
setblock 168 243 388 minecraft:light[level=14]
setblock 168 243 396 minecraft:light[level=14]
setblock 168 243 404 minecraft:light[level=14]
setblock 168 243 410 minecraft:white_concrete
fill 173 243 406 177 243 407 minecraft:red_concrete
setblock 174 243 370 minecraft:white_concrete
setblock 175 243 410 minecraft:white_concrete
setblock 176 243 372 minecraft:light[level=14]
setblock 176 243 380 minecraft:light[level=14]
setblock 176 243 388 minecraft:light[level=14]
setblock 176 243 396 minecraft:light[level=14]
setblock 176 243 404 minecraft:light[level=14]
fill 177 243 377 178 243 379 minecraft:red_concrete
setblock 181 243 370 minecraft:white_concrete
setblock 182 243 376 minecraft:white_concrete
setblock 182 243 383 minecraft:white_concrete
setblock 182 243 390 minecraft:white_concrete
setblock 182 243 397 minecraft:white_concrete
setblock 182 243 404 minecraft:white_concrete
setblock 182 243 410 minecraft:white_concrete
setblock 142 244 374 minecraft:white_concrete
setblock 142 244 381 minecraft:white_concrete
setblock 142 244 388 minecraft:white_concrete
setblock 142 244 395 minecraft:white_concrete
setblock 142 244 402 minecraft:white_concrete
setblock 142 244 409 minecraft:white_concrete
setblock 145 244 370 minecraft:white_concrete
fill 146 244 390 147 244 392 minecraft:red_concrete
setblock 148 244 410 minecraft:white_concrete
setblock 152 244 370 minecraft:white_concrete
setblock 155 244 410 minecraft:white_concrete
setblock 159 244 370 minecraft:white_concrete
setblock 162 244 410 minecraft:white_concrete
setblock 166 244 370 minecraft:white_concrete
setblock 169 244 410 minecraft:white_concrete
setblock 173 244 370 minecraft:white_concrete
setblock 176 244 410 minecraft:white_concrete
setblock 180 244 370 minecraft:white_concrete
setblock 182 244 375 minecraft:white_concrete
setblock 182 244 382 minecraft:white_concrete
setblock 182 244 389 minecraft:white_concrete
setblock 182 244 396 minecraft:white_concrete
setblock 182 244 403 minecraft:white_concrete
fill 154 245 406 155 246 407 minecraft:purple_wool
setblock 142 246 376 minecraft:white_concrete
setblock 142 246 383 minecraft:white_concrete
setblock 142 246 390 minecraft:white_concrete
setblock 142 246 397 minecraft:white_concrete
setblock 142 246 404 minecraft:white_concrete
setblock 143 246 370 minecraft:white_concrete
setblock 143 246 410 minecraft:white_concrete
setblock 150 246 370 minecraft:white_concrete
setblock 150 246 410 minecraft:white_concrete
setblock 157 246 370 minecraft:white_concrete
setblock 157 246 410 minecraft:white_concrete
setblock 164 246 370 minecraft:white_concrete
setblock 164 246 410 minecraft:white_concrete
setblock 171 246 370 minecraft:white_concrete
setblock 171 246 410 minecraft:white_concrete
setblock 178 246 370 minecraft:white_concrete
setblock 178 246 410 minecraft:white_concrete
setblock 182 246 373 minecraft:white_concrete
setblock 182 246 380 minecraft:white_concrete
setblock 182 246 387 minecraft:white_concrete
setblock 182 246 394 minecraft:white_concrete
setblock 182 246 401 minecraft:white_concrete
setblock 182 246 408 minecraft:white_concrete
setblock 142 247 370 minecraft:white_concrete
setblock 142 247 377 minecraft:white_concrete
setblock 142 247 384 minecraft:white_concrete
setblock 142 247 391 minecraft:white_concrete
setblock 142 247 398 minecraft:white_concrete
setblock 142 247 405 minecraft:white_concrete
setblock 144 247 410 minecraft:white_concrete
setblock 149 247 370 minecraft:white_concrete
setblock 151 247 410 minecraft:white_concrete
setblock 156 247 370 minecraft:white_concrete
setblock 158 247 410 minecraft:white_concrete
setblock 163 247 370 minecraft:white_concrete
setblock 165 247 410 minecraft:white_concrete
setblock 170 247 370 minecraft:white_concrete
setblock 172 247 410 minecraft:white_concrete
setblock 177 247 370 minecraft:white_concrete
setblock 179 247 410 minecraft:white_concrete
setblock 182 247 372 minecraft:white_concrete
setblock 182 247 379 minecraft:white_concrete
setblock 182 247 386 minecraft:white_concrete
setblock 182 247 393 minecraft:white_concrete
setblock 182 247 400 minecraft:white_concrete
setblock 182 247 407 minecraft:white_concrete
setblock 142 248 371 minecraft:white_concrete
setblock 142 248 378 minecraft:white_concrete
setblock 142 248 385 minecraft:white_concrete
setblock 142 248 392 minecraft:white_concrete
setblock 142 248 399 minecraft:white_concrete
setblock 142 248 406 minecraft:white_concrete
setblock 145 248 410 minecraft:white_concrete
setblock 148 248 370 minecraft:white_concrete
setblock 152 248 410 minecraft:white_concrete
setblock 155 248 370 minecraft:white_concrete
setblock 159 248 410 minecraft:white_concrete
setblock 162 248 370 minecraft:white_concrete
setblock 166 248 410 minecraft:white_concrete
setblock 169 248 370 minecraft:white_concrete
setblock 173 248 410 minecraft:white_concrete
setblock 176 248 370 minecraft:white_concrete
setblock 180 248 410 minecraft:white_concrete
setblock 182 248 371 minecraft:white_concrete
setblock 182 248 378 minecraft:white_concrete
setblock 182 248 385 minecraft:white_concrete
setblock 182 248 392 minecraft:white_concrete
setblock 182 248 399 minecraft:white_concrete
setblock 182 248 406 minecraft:white_concrete
fill 142 249 372 142 250 372 minecraft:white_concrete
fill 142 249 379 142 250 379 minecraft:white_concrete
fill 142 249 386 142 250 386 minecraft:white_concrete
fill 142 249 393 142 250 393 minecraft:white_concrete
fill 142 249 400 142 250 400 minecraft:white_concrete
fill 142 249 407 142 250 407 minecraft:white_concrete
fill 146 249 410 146 250 410 minecraft:white_concrete
fill 147 249 370 147 250 370 minecraft:white_concrete
fill 153 249 410 153 250 410 minecraft:white_concrete
fill 154 249 370 154 250 370 minecraft:white_concrete
fill 160 249 410 160 250 410 minecraft:white_concrete
fill 161 249 370 161 250 370 minecraft:white_concrete
fill 167 249 410 167 250 410 minecraft:white_concrete
fill 168 249 370 168 250 370 minecraft:white_concrete
fill 174 249 410 174 250 410 minecraft:white_concrete
fill 175 249 370 175 250 370 minecraft:white_concrete
fill 181 249 410 181 250 410 minecraft:white_concrete
fill 182 249 370 182 250 370 minecraft:white_concrete
fill 182 249 377 182 250 377 minecraft:white_concrete
fill 182 249 384 182 250 384 minecraft:white_concrete
fill 182 249 391 182 250 391 minecraft:white_concrete
fill 182 249 398 182 250 398 minecraft:white_concrete
fill 182 249 405 182 250 405 minecraft:white_concrete
fill 142 250 370 142 250 371 minecraft:white_concrete
fill 142 250 373 142 250 374 minecraft:white_concrete
fill 142 250 376 142 250 378 minecraft:white_concrete
fill 142 250 380 142 250 381 minecraft:white_concrete
fill 142 250 383 142 250 385 minecraft:white_concrete
fill 142 250 387 142 250 388 minecraft:white_concrete
fill 142 250 390 142 250 392 minecraft:white_concrete
fill 142 250 394 142 250 395 minecraft:white_concrete
fill 142 250 397 142 250 399 minecraft:white_concrete
fill 142 250 401 142 250 402 minecraft:white_concrete
fill 142 250 404 142 250 406 minecraft:white_concrete
fill 142 250 408 142 250 409 minecraft:white_concrete
setblock 143 250 370 minecraft:white_concrete
fill 143 250 410 145 250 410 minecraft:white_concrete
fill 145 250 370 146 250 370 minecraft:white_concrete
fill 147 250 410 148 250 410 minecraft:white_concrete
fill 148 250 370 150 250 370 minecraft:white_concrete
fill 150 250 410 152 250 410 minecraft:white_concrete
fill 152 250 370 153 250 370 minecraft:white_concrete
fill 154 250 410 155 250 410 minecraft:white_concrete
fill 155 250 370 157 250 370 minecraft:white_concrete
fill 157 250 410 159 250 410 minecraft:white_concrete
fill 159 250 370 160 250 370 minecraft:white_concrete
fill 161 250 410 162 250 410 minecraft:white_concrete
fill 162 250 370 164 250 370 minecraft:white_concrete
fill 164 250 410 166 250 410 minecraft:white_concrete
fill 166 250 370 167 250 370 minecraft:white_concrete
fill 168 250 410 169 250 410 minecraft:white_concrete
fill 169 250 370 171 250 370 minecraft:white_concrete
fill 171 250 410 173 250 410 minecraft:white_concrete
fill 173 250 370 174 250 370 minecraft:white_concrete
fill 175 250 371 175 251 372 minecraft:gray_concrete
fill 175 250 410 176 250 410 minecraft:white_concrete
fill 176 250 370 178 250 370 minecraft:white_concrete
fill 178 250 410 180 250 410 minecraft:white_concrete
fill 180 250 370 181 250 370 minecraft:white_concrete
fill 182 250 371 182 250 373 minecraft:white_concrete
fill 182 250 375 182 250 376 minecraft:white_concrete
fill 182 250 378 182 250 380 minecraft:white_concrete
fill 182 250 382 182 250 383 minecraft:white_concrete
fill 182 250 385 182 250 387 minecraft:white_concrete
fill 182 250 389 182 250 390 minecraft:white_concrete
fill 182 250 392 182 250 394 minecraft:white_concrete
fill 182 250 396 182 250 397 minecraft:white_concrete
fill 182 250 399 182 250 401 minecraft:white_concrete
fill 182 250 403 182 250 404 minecraft:white_concrete
fill 182 250 406 182 250 408 minecraft:white_concrete
setblock 182 250 410 minecraft:white_concrete
setblock 142 251 374 minecraft:white_concrete
setblock 142 251 381 minecraft:white_concrete
setblock 142 251 388 minecraft:white_concrete
setblock 142 251 395 minecraft:white_concrete
setblock 142 251 402 minecraft:white_concrete
setblock 142 251 409 minecraft:white_concrete
setblock 144 251 372 minecraft:light[level=14]
setblock 144 251 380 minecraft:light[level=14]
setblock 144 251 388 minecraft:light[level=14]
setblock 144 251 396 minecraft:light[level=14]
setblock 144 251 404 minecraft:light[level=14]
setblock 145 251 370 minecraft:white_concrete
setblock 148 251 410 minecraft:white_concrete
fill 149 251 408 149 264 408 minecraft:purple_wool
setblock 152 251 370 minecraft:white_concrete
setblock 152 251 372 minecraft:light[level=14]
setblock 152 251 380 minecraft:light[level=14]
setblock 152 251 388 minecraft:light[level=14]
setblock 152 251 396 minecraft:light[level=14]
setblock 152 251 404 minecraft:light[level=14]
setblock 155 251 410 minecraft:white_concrete
setblock 159 251 370 minecraft:white_concrete
setblock 160 251 372 minecraft:light[level=14]
setblock 160 251 380 minecraft:light[level=14]
setblock 160 251 388 minecraft:light[level=14]
setblock 160 251 396 minecraft:light[level=14]
setblock 160 251 404 minecraft:light[level=14]
setblock 162 251 410 minecraft:white_concrete
setblock 166 251 370 minecraft:white_concrete
setblock 168 251 372 minecraft:light[level=14]
setblock 168 251 380 minecraft:light[level=14]
setblock 168 251 388 minecraft:light[level=14]
setblock 168 251 396 minecraft:light[level=14]
setblock 168 251 404 minecraft:light[level=14]
setblock 169 251 410 minecraft:white_concrete
setblock 173 251 370 minecraft:white_concrete
setblock 175 251 370 minecraft:gray_concrete
setblock 176 251 372 minecraft:light[level=14]
setblock 176 251 380 minecraft:light[level=14]
setblock 176 251 388 minecraft:light[level=14]
setblock 176 251 396 minecraft:light[level=14]
setblock 176 251 404 minecraft:light[level=14]
setblock 176 251 410 minecraft:white_concrete
setblock 180 251 370 minecraft:white_concrete
setblock 182 251 375 minecraft:white_concrete
setblock 182 251 382 minecraft:white_concrete
setblock 182 251 389 minecraft:white_concrete
setblock 182 251 396 minecraft:white_concrete
setblock 182 251 403 minecraft:white_concrete
fill 147 252 408 148 264 408 minecraft:purple_wool
fill 150 252 408 151 264 408 minecraft:purple_wool
setblock 142 253 376 minecraft:white_concrete
setblock 142 253 383 minecraft:white_concrete
setblock 142 253 390 minecraft:white_concrete
setblock 142 253 397 minecraft:white_concrete
setblock 142 253 404 minecraft:white_concrete
setblock 143 253 370 minecraft:white_concrete
setblock 143 253 410 minecraft:white_concrete
setblock 150 253 370 minecraft:white_concrete
setblock 150 253 410 minecraft:white_concrete
setblock 157 253 370 minecraft:white_concrete
setblock 157 253 410 minecraft:white_concrete
setblock 164 253 370 minecraft:white_concrete
setblock 164 253 410 minecraft:white_concrete
setblock 171 253 370 minecraft:white_concrete
setblock 171 253 410 minecraft:white_concrete
setblock 178 253 370 minecraft:white_concrete
setblock 178 253 410 minecraft:white_concrete
setblock 182 253 373 minecraft:white_concrete
setblock 182 253 380 minecraft:white_concrete
setblock 182 253 387 minecraft:white_concrete
setblock 182 253 394 minecraft:white_concrete
setblock 182 253 401 minecraft:white_concrete
setblock 182 253 408 minecraft:white_concrete
setblock 142 254 370 minecraft:white_concrete
setblock 142 254 377 minecraft:white_concrete
setblock 142 254 384 minecraft:white_concrete
setblock 142 254 391 minecraft:white_concrete
setblock 142 254 398 minecraft:white_concrete
setblock 142 254 405 minecraft:white_concrete
setblock 144 254 410 minecraft:white_concrete
setblock 149 254 370 minecraft:white_concrete
setblock 151 254 410 minecraft:white_concrete
setblock 156 254 370 minecraft:white_concrete
setblock 158 254 410 minecraft:white_concrete
setblock 163 254 370 minecraft:white_concrete
setblock 165 254 410 minecraft:white_concrete
setblock 170 254 370 minecraft:white_concrete
setblock 172 254 410 minecraft:white_concrete
setblock 177 254 370 minecraft:white_concrete
setblock 179 254 410 minecraft:white_concrete
setblock 182 254 372 minecraft:white_concrete
setblock 182 254 379 minecraft:white_concrete
setblock 182 254 386 minecraft:white_concrete
setblock 182 254 393 minecraft:white_concrete
setblock 182 254 400 minecraft:white_concrete
setblock 182 254 407 minecraft:white_concrete
setblock 142 255 371 minecraft:white_concrete
fill 142 255 373 144 256 373 minecraft:gray_concrete
setblock 142 255 378 minecraft:white_concrete
setblock 142 255 385 minecraft:white_concrete
setblock 142 255 392 minecraft:white_concrete
setblock 142 255 399 minecraft:white_concrete
setblock 142 255 406 minecraft:white_concrete
setblock 145 255 410 minecraft:white_concrete
setblock 148 255 370 minecraft:white_concrete
setblock 152 255 410 minecraft:white_concrete
setblock 155 255 370 minecraft:white_concrete
setblock 159 255 410 minecraft:white_concrete
setblock 162 255 370 minecraft:white_concrete
setblock 166 255 410 minecraft:white_concrete
setblock 169 255 370 minecraft:white_concrete
setblock 173 255 410 minecraft:white_concrete
setblock 176 255 370 minecraft:white_concrete
setblock 180 255 410 minecraft:white_concrete
setblock 182 255 371 minecraft:white_concrete
setblock 182 255 378 minecraft:white_concrete
setblock 182 255 385 minecraft:white_concrete
setblock 182 255 392 minecraft:white_concrete
setblock 182 255 399 minecraft:white_concrete
setblock 182 255 406 minecraft:white_concrete
setblock 142 256 372 minecraft:white_concrete
setblock 142 256 379 minecraft:white_concrete
setblock 142 256 386 minecraft:white_concrete
setblock 142 256 393 minecraft:white_concrete
setblock 142 256 400 minecraft:white_concrete
setblock 142 256 407 minecraft:white_concrete
setblock 146 256 410 minecraft:white_concrete
setblock 147 256 370 minecraft:white_concrete
setblock 153 256 410 minecraft:white_concrete
setblock 154 256 370 minecraft:white_concrete
setblock 160 256 410 minecraft:white_concrete
setblock 161 256 370 minecraft:white_concrete
setblock 167 256 410 minecraft:white_concrete
setblock 168 256 370 minecraft:white_concrete
setblock 174 256 410 minecraft:white_concrete
setblock 175 256 370 minecraft:white_concrete
fill 175 256 383 179 257 387 minecraft:black_concrete
fill 180 256 385 181 256 385 minecraft:black_concrete
setblock 181 256 410 minecraft:white_concrete
setblock 182 256 370 minecraft:white_concrete
setblock 182 256 377 minecraft:white_concrete
setblock 182 256 384 minecraft:white_concrete
setblock 182 256 391 minecraft:white_concrete
setblock 182 256 398 minecraft:white_concrete
setblock 182 256 405 minecraft:white_concrete
setblock 142 257 373 minecraft:white_concrete
setblock 142 257 380 minecraft:white_concrete
setblock 142 257 387 minecraft:white_concrete
setblock 142 257 394 minecraft:white_concrete
setblock 142 257 401 minecraft:white_concrete
setblock 142 257 408 minecraft:white_concrete
setblock 146 257 370 minecraft:white_concrete
setblock 147 257 410 minecraft:white_concrete
setblock 153 257 370 minecraft:white_concrete
setblock 154 257 410 minecraft:white_concrete
setblock 160 257 370 minecraft:white_concrete
setblock 161 257 410 minecraft:white_concrete
setblock 167 257 370 minecraft:white_concrete
setblock 168 257 410 minecraft:white_concrete
setblock 174 257 370 minecraft:white_concrete
setblock 175 257 410 minecraft:white_concrete
setblock 181 257 370 minecraft:white_concrete
setblock 182 257 376 minecraft:white_concrete
setblock 182 257 383 minecraft:white_concrete
setblock 182 257 390 minecraft:white_concrete
setblock 182 257 397 minecraft:white_concrete
setblock 182 257 404 minecraft:white_concrete
setblock 182 257 410 minecraft:white_concrete
setblock 142 258 374 minecraft:white_concrete
setblock 142 258 381 minecraft:white_concrete
setblock 142 258 388 minecraft:white_concrete
setblock 142 258 395 minecraft:white_concrete
setblock 142 258 402 minecraft:white_concrete
setblock 142 258 409 minecraft:white_concrete
setblock 145 258 370 minecraft:white_concrete
setblock 148 258 410 minecraft:white_concrete
setblock 152 258 370 minecraft:white_concrete
setblock 155 258 410 minecraft:white_concrete
setblock 159 258 370 minecraft:white_concrete
setblock 162 258 410 minecraft:white_concrete
setblock 166 258 370 minecraft:white_concrete
setblock 169 258 410 minecraft:white_concrete
setblock 173 258 370 minecraft:white_concrete
setblock 176 258 410 minecraft:white_concrete
fill 177 258 385 177 263 385 minecraft:bone_block
setblock 180 258 370 minecraft:white_concrete
setblock 182 258 375 minecraft:white_concrete
setblock 182 258 382 minecraft:white_concrete
setblock 182 258 389 minecraft:white_concrete
setblock 182 258 396 minecraft:white_concrete
setblock 182 258 403 minecraft:white_concrete
setblock 144 259 372 minecraft:light[level=14]
setblock 144 259 380 minecraft:light[level=14]
setblock 144 259 388 minecraft:light[level=14]
setblock 144 259 396 minecraft:light[level=14]
setblock 144 259 404 minecraft:light[level=14]
setblock 152 259 372 minecraft:light[level=14]
setblock 152 259 380 minecraft:light[level=14]
setblock 152 259 388 minecraft:light[level=14]
setblock 152 259 396 minecraft:light[level=14]
setblock 152 259 404 minecraft:light[level=14]
setblock 160 259 372 minecraft:light[level=14]
setblock 160 259 380 minecraft:light[level=14]
setblock 160 259 388 minecraft:light[level=14]
setblock 160 259 396 minecraft:light[level=14]
setblock 160 259 404 minecraft:light[level=14]
setblock 168 259 372 minecraft:light[level=14]
setblock 168 259 380 minecraft:light[level=14]
setblock 168 259 388 minecraft:light[level=14]
setblock 168 259 396 minecraft:light[level=14]
setblock 168 259 404 minecraft:light[level=14]
fill 175 259 384 176 262 386 minecraft:bone_block
setblock 176 259 372 minecraft:light[level=14]
setblock 176 259 380 minecraft:light[level=14]
fill 176 259 383 178 262 383 minecraft:bone_block
fill 176 259 387 178 262 387 minecraft:bone_block
setblock 176 259 388 minecraft:light[level=14]
setblock 176 259 396 minecraft:light[level=14]
setblock 176 259 404 minecraft:light[level=14]
fill 177 259 384 179 262 384 minecraft:bone_block
fill 177 259 386 179 262 386 minecraft:bone_block
fill 178 259 385 179 262 385 minecraft:bone_block
fill 142 260 370 142 260 374 minecraft:white_concrete
fill 142 260 376 142 260 381 minecraft:white_concrete
fill 142 260 383 142 260 388 minecraft:white_concrete
fill 142 260 390 142 260 395 minecraft:white_concrete
fill 142 260 397 142 260 402 minecraft:white_concrete
fill 142 260 404 142 260 409 minecraft:white_concrete
setblock 143 260 370 minecraft:white_concrete
fill 143 260 410 148 260 410 minecraft:white_concrete
fill 145 260 370 150 260 370 minecraft:white_concrete
fill 150 260 410 155 260 410 minecraft:white_concrete
fill 152 260 370 157 260 370 minecraft:white_concrete
fill 157 260 410 162 260 410 minecraft:white_concrete
fill 159 260 370 164 260 370 minecraft:white_concrete
fill 164 260 410 169 260 410 minecraft:white_concrete
fill 166 260 370 171 260 370 minecraft:white_concrete
fill 171 260 410 176 260 410 minecraft:white_concrete
fill 173 260 370 178 260 370 minecraft:white_concrete
fill 178 260 410 182 260 410 minecraft:white_concrete
fill 180 260 370 182 260 370 minecraft:white_concrete
fill 182 260 371 182 260 373 minecraft:white_concrete
fill 182 260 375 182 260 380 minecraft:white_concrete
fill 182 260 382 182 260 387 minecraft:white_concrete
fill 182 260 389 182 260 394 minecraft:white_concrete
fill 182 260 396 182 260 401 minecraft:white_concrete
fill 182 260 403 182 260 408 minecraft:white_concrete
setblock 142 261 370 minecraft:white_concrete
setblock 142 261 377 minecraft:white_concrete
setblock 142 261 384 minecraft:white_concrete
setblock 142 261 391 minecraft:white_concrete
setblock 142 261 398 minecraft:white_concrete
setblock 142 261 405 minecraft:white_concrete
setblock 144 261 410 minecraft:white_concrete
setblock 149 261 370 minecraft:white_concrete
setblock 151 261 410 minecraft:white_concrete
setblock 156 261 370 minecraft:white_concrete
setblock 158 261 410 minecraft:white_concrete
setblock 163 261 370 minecraft:white_concrete
setblock 165 261 410 minecraft:white_concrete
setblock 170 261 370 minecraft:white_concrete
setblock 172 261 410 minecraft:white_concrete
setblock 177 261 370 minecraft:white_concrete
setblock 179 261 410 minecraft:white_concrete
setblock 182 261 372 minecraft:white_concrete
setblock 182 261 379 minecraft:white_concrete
setblock 182 261 386 minecraft:white_concrete
setblock 182 261 393 minecraft:white_concrete
setblock 182 261 400 minecraft:white_concrete
setblock 182 261 407 minecraft:white_concrete
setblock 142 262 371 minecraft:white_concrete
setblock 142 262 378 minecraft:white_concrete
setblock 142 262 385 minecraft:white_concrete
setblock 142 262 392 minecraft:white_concrete
setblock 142 262 399 minecraft:white_concrete
setblock 142 262 406 minecraft:white_concrete
setblock 145 262 410 minecraft:white_concrete
setblock 148 262 370 minecraft:white_concrete
setblock 152 262 410 minecraft:white_concrete
setblock 155 262 370 minecraft:white_concrete
setblock 159 262 410 minecraft:white_concrete
setblock 162 262 370 minecraft:white_concrete
setblock 166 262 410 minecraft:white_concrete
setblock 169 262 370 minecraft:white_concrete
setblock 173 262 410 minecraft:white_concrete
setblock 176 262 370 minecraft:white_concrete
setblock 180 262 410 minecraft:white_concrete
setblock 182 262 371 minecraft:white_concrete
setblock 182 262 378 minecraft:white_concrete
setblock 182 262 385 minecraft:white_concrete
setblock 182 262 392 minecraft:white_concrete
setblock 182 262 399 minecraft:white_concrete
setblock 182 262 406 minecraft:white_concrete
setblock 142 263 372 minecraft:white_concrete
setblock 142 263 379 minecraft:white_concrete
setblock 142 263 386 minecraft:white_concrete
setblock 142 263 393 minecraft:white_concrete
setblock 142 263 400 minecraft:white_concrete
setblock 142 263 407 minecraft:white_concrete
setblock 146 263 410 minecraft:white_concrete
setblock 147 263 370 minecraft:white_concrete
setblock 153 263 410 minecraft:white_concrete
setblock 154 263 370 minecraft:white_concrete
setblock 160 263 410 minecraft:white_concrete
setblock 161 263 370 minecraft:white_concrete
setblock 167 263 410 minecraft:white_concrete
setblock 168 263 370 minecraft:white_concrete
setblock 174 263 410 minecraft:white_concrete
setblock 175 263 370 minecraft:white_concrete
setblock 181 263 410 minecraft:white_concrete
setblock 182 263 370 minecraft:white_concrete
setblock 182 263 377 minecraft:white_concrete
setblock 182 263 384 minecraft:white_concrete
setblock 182 263 391 minecraft:white_concrete
setblock 182 263 398 minecraft:white_concrete
setblock 182 263 405 minecraft:white_concrete
setblock 142 264 373 minecraft:white_concrete
setblock 142 264 380 minecraft:white_concrete
setblock 142 264 387 minecraft:white_concrete
setblock 142 264 394 minecraft:white_concrete
setblock 142 264 401 minecraft:white_concrete
setblock 142 264 408 minecraft:white_concrete
setblock 146 264 370 minecraft:white_concrete
setblock 147 264 410 minecraft:white_concrete
setblock 153 264 370 minecraft:white_concrete
setblock 154 264 410 minecraft:white_concrete
setblock 160 264 370 minecraft:white_concrete
setblock 161 264 410 minecraft:white_concrete
setblock 167 264 370 minecraft:white_concrete
setblock 168 264 410 minecraft:white_concrete
setblock 174 264 370 minecraft:white_concrete
setblock 175 264 410 minecraft:white_concrete
setblock 181 264 370 minecraft:white_concrete
setblock 182 264 376 minecraft:white_concrete
setblock 182 264 383 minecraft:white_concrete
setblock 182 264 390 minecraft:white_concrete
setblock 182 264 397 minecraft:white_concrete
setblock 182 264 404 minecraft:white_concrete
setblock 182 264 410 minecraft:white_concrete
setblock 142 265 374 minecraft:white_concrete
setblock 142 265 381 minecraft:white_concrete
setblock 142 265 388 minecraft:white_concrete
setblock 142 265 395 minecraft:white_concrete
setblock 142 265 402 minecraft:white_concrete
setblock 142 265 409 minecraft:white_concrete
setblock 145 265 370 minecraft:white_concrete
fill 146 265 408 152 266 408 minecraft:gray_concrete
setblock 148 265 410 minecraft:white_concrete
setblock 152 265 370 minecraft:white_concrete
setblock 155 265 410 minecraft:white_concrete
setblock 159 265 370 minecraft:white_concrete
setblock 162 265 410 minecraft:white_concrete
setblock 166 265 370 minecraft:white_concrete
setblock 169 265 410 minecraft:white_concrete
setblock 173 265 370 minecraft:white_concrete
setblock 176 265 410 minecraft:white_concrete
setblock 180 265 370 minecraft:white_concrete
setblock 182 265 375 minecraft:white_concrete
setblock 182 265 382 minecraft:white_concrete
setblock 182 265 389 minecraft:white_concrete
setblock 182 265 396 minecraft:white_concrete
setblock 182 265 403 minecraft:white_concrete
setblock 142 267 376 minecraft:white_concrete
setblock 142 267 383 minecraft:white_concrete
setblock 142 267 390 minecraft:white_concrete
setblock 142 267 397 minecraft:white_concrete
setblock 142 267 404 minecraft:white_concrete
setblock 143 267 370 minecraft:white_concrete
setblock 143 267 410 minecraft:white_concrete
setblock 144 267 372 minecraft:light[level=14]
setblock 144 267 380 minecraft:light[level=14]
setblock 144 267 388 minecraft:light[level=14]
setblock 144 267 396 minecraft:light[level=14]
setblock 144 267 404 minecraft:light[level=14]
setblock 150 267 370 minecraft:white_concrete
setblock 150 267 410 minecraft:white_concrete
setblock 152 267 372 minecraft:light[level=14]
setblock 152 267 380 minecraft:light[level=14]
setblock 152 267 388 minecraft:light[level=14]
setblock 152 267 396 minecraft:light[level=14]
setblock 152 267 404 minecraft:light[level=14]
setblock 157 267 370 minecraft:white_concrete
setblock 157 267 410 minecraft:white_concrete
setblock 160 267 372 minecraft:light[level=14]
setblock 160 267 380 minecraft:light[level=14]
setblock 160 267 388 minecraft:light[level=14]
setblock 160 267 396 minecraft:light[level=14]
setblock 160 267 404 minecraft:light[level=14]
setblock 164 267 370 minecraft:white_concrete
setblock 164 267 410 minecraft:white_concrete
setblock 168 267 372 minecraft:light[level=14]
setblock 168 267 380 minecraft:light[level=14]
setblock 168 267 388 minecraft:light[level=14]
setblock 168 267 396 minecraft:light[level=14]
setblock 168 267 404 minecraft:light[level=14]
setblock 171 267 370 minecraft:white_concrete
setblock 171 267 410 minecraft:white_concrete
setblock 176 267 372 minecraft:light[level=14]
setblock 176 267 380 minecraft:light[level=14]
setblock 176 267 388 minecraft:light[level=14]
setblock 176 267 396 minecraft:light[level=14]
setblock 176 267 404 minecraft:light[level=14]
setblock 178 267 370 minecraft:white_concrete
setblock 178 267 410 minecraft:white_concrete
setblock 182 267 373 minecraft:white_concrete
setblock 182 267 380 minecraft:white_concrete
setblock 182 267 387 minecraft:white_concrete
setblock 182 267 394 minecraft:white_concrete
setblock 182 267 401 minecraft:white_concrete
setblock 182 267 408 minecraft:white_concrete
fill 142 273 374 159 274 406 minecraft:red_wool
fill 143 273 373 181 274 373 minecraft:red_wool
fill 143 273 407 181 274 407 minecraft:red_wool
fill 144 273 372 180 274 372 minecraft:red_wool
fill 144 273 408 180 274 408 minecraft:red_wool
fill 145 273 371 179 274 371 minecraft:red_wool
fill 145 273 409 179 274 409 minecraft:red_wool
fill 146 273 370 178 274 370 minecraft:red_wool
fill 146 273 410 178 274 410 minecraft:red_wool
fill 160 273 374 160 277 391 minecraft:red_wool
fill 160 273 393 160 277 406 minecraft:red_wool
fill 161 273 374 162 277 389 minecraft:red_wool
fill 161 273 395 162 277 406 minecraft:red_wool
fill 163 273 374 182 274 388 minecraft:red_wool
fill 163 273 396 182 274 406 minecraft:red_wool
fill 164 273 389 182 277 389 minecraft:red_wool
fill 164 273 395 182 277 395 minecraft:red_wool
fill 166 273 390 182 277 391 minecraft:red_wool
fill 166 273 393 182 277 394 minecraft:red_wool
fill 167 273 392 182 278 392 minecraft:red_wool
fill 142 275 375 159 275 405 minecraft:red_wool
fill 143 275 374 159 275 374 minecraft:red_wool
fill 143 275 406 159 275 406 minecraft:red_wool
setblock 144 275 372 minecraft:light[level=14]
fill 144 275 373 180 275 373 minecraft:red_wool
fill 144 275 407 180 275 407 minecraft:red_wool
fill 145 275 372 179 275 372 minecraft:red_wool
fill 145 275 408 179 275 408 minecraft:red_wool
fill 146 275 371 178 275 371 minecraft:red_wool
fill 146 275 409 178 275 409 minecraft:red_wool
fill 147 275 370 177 275 370 minecraft:red_wool
fill 147 275 410 177 275 410 minecraft:red_wool
fill 163 275 374 181 275 388 minecraft:red_wool
fill 163 275 396 181 275 406 minecraft:red_wool
fill 182 275 375 182 275 388 minecraft:red_wool
fill 182 275 396 182 275 405 minecraft:red_wool
fill 142 276 376 159 276 404 minecraft:red_wool
fill 143 276 375 159 276 375 minecraft:red_wool
fill 143 276 405 159 276 405 minecraft:red_wool
fill 144 276 374 159 277 374 minecraft:red_wool
fill 144 276 406 159 277 406 minecraft:red_wool
fill 145 276 373 179 277 373 minecraft:red_wool
fill 145 276 407 179 277 407 minecraft:red_wool
fill 146 276 372 178 277 372 minecraft:red_wool
fill 146 276 408 178 277 408 minecraft:red_wool
fill 147 276 371 177 276 371 minecraft:red_wool
fill 147 276 409 177 276 409 minecraft:red_wool
fill 148 276 370 176 276 370 minecraft:red_wool
fill 148 276 410 176 276 410 minecraft:red_wool
fill 163 276 374 180 277 388 minecraft:red_wool
fill 163 276 396 180 277 406 minecraft:red_wool
fill 181 276 375 181 276 388 minecraft:red_wool
fill 181 276 396 181 276 405 minecraft:red_wool
fill 182 276 376 182 276 388 minecraft:red_wool
fill 182 276 396 182 276 404 minecraft:red_wool
fill 142 277 377 159 277 403 minecraft:red_wool
fill 143 277 376 159 277 376 minecraft:red_wool
fill 143 277 404 159 277 404 minecraft:red_wool
fill 144 277 375 159 278 375 minecraft:red_wool
fill 144 277 405 159 278 405 minecraft:red_wool
fill 148 277 371 176 277 371 minecraft:red_wool
fill 148 277 409 176 277 409 minecraft:red_wool
fill 149 277 370 175 277 370 minecraft:red_wool
fill 149 277 410 175 277 410 minecraft:red_wool
fill 181 277 376 181 277 388 minecraft:red_wool
fill 181 277 396 181 277 404 minecraft:red_wool
fill 182 277 377 182 277 388 minecraft:red_wool
fill 182 277 396 182 277 403 minecraft:red_wool
fill 142 278 378 158 278 402 minecraft:red_wool
fill 143 278 377 181 278 377 minecraft:red_wool
fill 143 278 403 181 278 403 minecraft:red_wool
fill 144 278 376 180 279 376 minecraft:red_wool
fill 144 278 404 180 279 404 minecraft:red_wool
fill 145 278 374 179 278 374 minecraft:red_wool
fill 145 278 406 179 278 406 minecraft:red_wool
fill 146 278 373 178 278 373 minecraft:red_wool
fill 146 278 407 178 278 407 minecraft:red_wool
fill 147 278 372 177 278 372 minecraft:red_wool
fill 147 278 408 177 278 408 minecraft:red_wool
fill 149 278 371 175 278 371 minecraft:red_wool
fill 149 278 409 175 278 409 minecraft:red_wool
fill 150 278 370 174 278 370 minecraft:red_wool
fill 150 278 410 174 278 410 minecraft:red_wool
fill 159 278 378 159 278 391 minecraft:red_wool
setblock 159 278 392 minecraft:white_wool
fill 159 278 393 159 278 402 minecraft:red_wool
fill 160 278 375 180 278 375 minecraft:red_wool
fill 160 278 378 160 278 389 minecraft:red_wool
fill 160 278 390 160 278 391 minecraft:white_wool
fill 160 278 393 160 278 394 minecraft:white_wool
fill 160 278 395 160 278 402 minecraft:red_wool
fill 160 278 405 180 278 405 minecraft:red_wool
fill 161 278 378 161 279 388 minecraft:red_wool
fill 161 278 389 162 278 389 minecraft:white_wool
fill 161 278 395 162 278 395 minecraft:white_wool
fill 161 278 396 182 278 402 minecraft:red_wool
fill 162 278 378 182 278 387 minecraft:red_wool
fill 162 278 388 163 278 388 minecraft:white_wool
fill 164 278 388 182 278 388 minecraft:red_wool
fill 164 278 389 165 278 389 minecraft:white_wool
fill 164 278 395 165 278 395 minecraft:white_wool
fill 166 278 389 182 278 389 minecraft:red_wool
fill 166 278 390 166 278 391 minecraft:white_wool
fill 166 278 393 166 278 394 minecraft:white_wool
fill 166 278 395 182 278 395 minecraft:red_wool
fill 167 278 390 182 278 391 minecraft:red_wool
fill 167 278 393 182 278 394 minecraft:red_wool
fill 142 279 370 142 279 378 minecraft:purple_wool
fill 142 279 379 158 279 401 minecraft:red_wool
fill 142 279 402 142 279 410 minecraft:purple_wool
fill 143 279 370 143 279 377 minecraft:purple_wool
fill 143 279 378 160 279 378 minecraft:red_wool
fill 143 279 402 181 279 402 minecraft:red_wool
fill 143 279 403 143 279 410 minecraft:purple_wool
fill 144 279 370 144 279 375 minecraft:purple_wool
fill 144 279 377 180 280 377 minecraft:red_wool
fill 144 279 403 180 280 403 minecraft:red_wool
fill 144 279 405 144 279 410 minecraft:purple_wool
fill 145 279 370 145 279 374 minecraft:purple_wool
fill 145 279 375 179 279 375 minecraft:red_wool
fill 145 279 405 179 279 405 minecraft:red_wool
fill 145 279 406 145 279 410 minecraft:purple_wool
fill 146 279 370 146 279 373 minecraft:purple_wool
fill 146 279 374 178 279 374 minecraft:red_wool
fill 146 279 406 178 279 406 minecraft:red_wool
fill 146 279 407 146 279 410 minecraft:purple_wool
fill 147 279 370 147 279 372 minecraft:purple_wool
fill 147 279 373 177 279 373 minecraft:red_wool
fill 147 279 407 177 279 407 minecraft:red_wool
fill 147 279 408 147 279 410 minecraft:purple_wool
fill 148 279 370 149 279 371 minecraft:purple_wool
fill 148 279 372 176 279 372 minecraft:red_wool
fill 148 279 408 176 279 408 minecraft:red_wool
fill 148 279 409 149 279 410 minecraft:purple_wool
setblock 150 279 370 minecraft:purple_wool
fill 150 279 371 174 279 371 minecraft:red_wool
fill 150 279 409 174 279 409 minecraft:red_wool
setblock 150 279 410 minecraft:purple_wool
fill 151 279 370 173 279 370 minecraft:red_wool
fill 151 279 410 173 279 410 minecraft:red_wool
fill 159 279 379 159 279 390 minecraft:red_wool
fill 159 279 391 159 279 393 minecraft:jack_o_lantern
fill 159 279 394 159 279 401 minecraft:red_wool
fill 160 279 379 160 279 388 minecraft:red_wool
fill 160 279 389 160 279 391 minecraft:jack_o_lantern
fill 160 279 393 160 279 395 minecraft:jack_o_lantern
fill 160 279 396 161 279 401 minecraft:red_wool
fill 161 279 389 162 279 389 minecraft:jack_o_lantern
fill 161 279 395 162 279 395 minecraft:jack_o_lantern
fill 162 279 378 181 279 387 minecraft:red_wool
fill 162 279 388 164 279 388 minecraft:jack_o_lantern
fill 162 279 396 164 279 396 minecraft:jack_o_lantern
fill 162 279 397 182 279 401 minecraft:red_wool
fill 164 279 389 166 279 389 minecraft:jack_o_lantern
fill 164 279 395 166 279 395 minecraft:jack_o_lantern
fill 165 279 388 182 279 388 minecraft:red_wool
fill 165 279 396 182 279 396 minecraft:red_wool
fill 166 279 390 166 279 391 minecraft:jack_o_lantern
fill 166 279 393 166 279 394 minecraft:jack_o_lantern
fill 167 279 389 182 279 390 minecraft:red_wool
fill 167 279 391 167 279 393 minecraft:jack_o_lantern
fill 167 279 394 182 279 395 minecraft:red_wool
fill 168 279 391 182 279 393 minecraft:red_wool
fill 174 279 370 182 279 370 minecraft:purple_wool
fill 174 279 410 182 279 410 minecraft:purple_wool
fill 175 279 371 182 279 371 minecraft:purple_wool
fill 175 279 409 182 279 409 minecraft:purple_wool
fill 177 279 372 182 279 372 minecraft:purple_wool
fill 177 279 408 182 279 408 minecraft:purple_wool
fill 178 279 373 182 279 373 minecraft:purple_wool
fill 178 279 407 182 279 407 minecraft:purple_wool
fill 179 279 374 182 279 374 minecraft:purple_wool
fill 179 279 406 182 279 406 minecraft:purple_wool
fill 180 279 375 182 279 375 minecraft:purple_wool
fill 180 279 405 182 279 405 minecraft:purple_wool
fill 181 279 376 182 279 377 minecraft:purple_wool
fill 181 279 403 182 279 404 minecraft:purple_wool
setblock 182 279 378 minecraft:purple_wool
fill 182 279 379 182 279 387 minecraft:red_wool
setblock 182 279 402 minecraft:purple_wool
fill 142 280 381 155 280 399 minecraft:red_wool
fill 143 280 379 181 280 380 minecraft:red_wool
fill 143 280 400 181 280 401 minecraft:red_wool
fill 144 280 378 180 281 378 minecraft:red_wool
fill 144 280 402 180 281 402 minecraft:red_wool
fill 145 280 376 179 280 376 minecraft:red_wool
fill 145 280 404 179 280 404 minecraft:red_wool
fill 146 280 375 178 280 375 minecraft:red_wool
fill 146 280 405 178 280 405 minecraft:red_wool
fill 147 280 374 177 280 374 minecraft:red_wool
fill 147 280 406 177 280 406 minecraft:red_wool
fill 148 280 373 176 280 373 minecraft:red_wool
fill 148 280 407 176 280 407 minecraft:red_wool
fill 149 280 372 175 280 372 minecraft:red_wool
fill 149 280 408 175 280 408 minecraft:red_wool
fill 151 280 371 173 280 371 minecraft:red_wool
fill 151 280 409 173 280 409 minecraft:red_wool
fill 153 280 370 171 280 370 minecraft:red_wool
fill 153 280 410 171 280 410 minecraft:red_wool
fill 156 280 381 156 280 388 minecraft:red_wool
fill 156 280 389 157 280 393 minecraft:white_wool
fill 156 280 394 156 280 399 minecraft:red_wool
fill 157 280 381 157 280 387 minecraft:red_wool
fill 157 280 388 158 280 388 minecraft:white_wool
fill 157 280 394 157 280 395 minecraft:white_wool
fill 157 280 396 157 280 399 minecraft:red_wool
fill 158 280 381 159 280 385 minecraft:red_wool
fill 158 280 386 159 280 387 minecraft:white_wool
fill 158 280 395 158 280 396 minecraft:white_wool
fill 158 280 397 158 280 399 minecraft:red_wool
fill 159 280 396 159 280 397 minecraft:white_wool
fill 159 280 398 160 280 399 minecraft:red_wool
fill 160 280 381 182 280 384 minecraft:red_wool
fill 160 280 385 165 280 386 minecraft:white_wool
fill 160 280 397 161 280 397 minecraft:white_wool
fill 161 280 398 164 280 398 minecraft:white_wool
fill 161 280 399 182 280 399 minecraft:red_wool
fill 164 280 397 166 280 397 minecraft:white_wool
fill 165 280 398 182 280 398 minecraft:red_wool
fill 166 280 385 182 280 385 minecraft:red_wool
fill 166 280 386 167 280 387 minecraft:white_wool
fill 167 280 388 168 280 388 minecraft:white_wool
setblock 167 280 396 minecraft:white_wool
fill 167 280 397 182 280 397 minecraft:red_wool
fill 168 280 386 182 280 386 minecraft:red_wool
setblock 168 280 387 minecraft:white_wool
fill 168 280 389 169 280 389 minecraft:white_wool
fill 168 280 394 168 280 395 minecraft:white_wool
fill 168 280 396 182 280 396 minecraft:red_wool
fill 169 280 387 182 280 388 minecraft:red_wool
fill 169 280 390 169 280 394 minecraft:white_wool
fill 169 280 395 182 280 395 minecraft:red_wool
fill 170 280 389 182 280 394 minecraft:red_wool
fill 142 281 382 153 281 398 minecraft:red_wool
fill 143 281 380 181 281 381 minecraft:red_wool
fill 143 281 399 159 281 400 minecraft:red_wool
fill 144 281 379 180 281 379 minecraft:red_wool
fill 144 281 401 180 281 401 minecraft:red_wool
fill 145 281 377 179 281 377 minecraft:red_wool
fill 145 281 403 179 281 403 minecraft:red_wool
fill 146 281 376 178 281 376 minecraft:red_wool
fill 146 281 404 178 281 404 minecraft:red_wool
fill 147 281 375 177 281 375 minecraft:red_wool
fill 147 281 405 177 281 405 minecraft:red_wool
fill 148 281 374 176 281 374 minecraft:red_wool
fill 148 281 406 176 281 406 minecraft:red_wool
fill 149 281 373 175 281 373 minecraft:red_wool
fill 149 281 407 175 281 407 minecraft:red_wool
fill 150 281 372 174 281 372 minecraft:red_wool
fill 150 281 408 174 281 408 minecraft:red_wool
fill 152 281 371 172 281 371 minecraft:red_wool
fill 152 281 409 172 281 409 minecraft:red_wool
fill 154 281 370 170 281 370 minecraft:red_wool
fill 154 281 382 154 282 389 minecraft:red_wool
fill 154 281 390 155 281 392 minecraft:white_wool
fill 154 281 393 154 282 398 minecraft:red_wool
fill 154 281 410 170 281 410 minecraft:red_wool
fill 155 281 382 155 282 386 minecraft:red_wool
fill 155 281 387 155 281 389 minecraft:white_wool
fill 155 281 393 155 281 395 minecraft:white_wool
fill 155 281 396 155 282 398 minecraft:red_wool
fill 156 281 382 156 282 385 minecraft:red_wool
fill 156 281 386 156 281 388 minecraft:white_wool
fill 156 281 394 156 281 396 minecraft:white_wool
fill 156 281 397 156 282 398 minecraft:red_wool
fill 157 281 382 157 282 384 minecraft:red_wool
fill 157 281 385 157 281 387 minecraft:white_wool
fill 157 281 396 157 281 397 minecraft:white_wool
fill 157 281 398 157 282 398 minecraft:red_wool
fill 158 281 382 159 282 383 minecraft:red_wool
fill 158 281 384 159 281 385 minecraft:white_wool
fill 158 281 397 158 281 398 minecraft:white_wool
fill 159 281 398 160 281 398 minecraft:white_wool
fill 160 281 382 182 281 382 minecraft:red_wool
fill 160 281 383 165 281 384 minecraft:white_wool
fill 160 281 399 165 281 399 minecraft:white_wool
fill 160 281 400 181 281 400 minecraft:red_wool
fill 165 281 398 167 281 398 minecraft:white_wool
fill 166 281 383 182 281 383 minecraft:red_wool
fill 166 281 384 167 281 385 minecraft:white_wool
fill 166 281 399 181 281 399 minecraft:red_wool
fill 167 281 397 168 281 397 minecraft:white_wool
fill 168 281 384 182 281 384 minecraft:red_wool
fill 168 281 385 168 281 386 minecraft:white_wool
fill 168 281 396 169 281 396 minecraft:white_wool
fill 168 281 398 182 281 398 minecraft:red_wool
fill 169 281 385 182 282 385 minecraft:red_wool
fill 169 281 386 169 281 388 minecraft:white_wool
fill 169 281 395 170 281 395 minecraft:white_wool
fill 169 281 397 182 281 397 minecraft:red_wool
fill 170 281 386 182 282 386 minecraft:red_wool
fill 170 281 387 170 281 394 minecraft:white_wool
fill 170 281 396 182 281 396 minecraft:red_wool
fill 171 281 387 182 282 389 minecraft:red_wool
fill 171 281 390 171 281 392 minecraft:white_wool
fill 171 281 393 182 282 395 minecraft:red_wool
fill 172 281 390 182 282 392 minecraft:red_wool
fill 142 282 385 153 282 395 minecraft:red_wool
fill 143 282 382 153 282 384 minecraft:red_wool
fill 143 282 396 153 282 398 minecraft:red_wool
fill 144 282 380 180 282 381 minecraft:red_wool
fill 144 282 399 159 282 400 minecraft:red_wool
fill 145 282 378 179 282 379 minecraft:red_wool
fill 145 282 401 179 282 402 minecraft:red_wool
fill 146 282 377 178 282 377 minecraft:red_wool
fill 146 282 403 178 282 403 minecraft:red_wool
fill 147 282 376 177 282 376 minecraft:red_wool
fill 147 282 404 177 282 404 minecraft:red_wool
fill 148 282 375 176 282 375 minecraft:red_wool
fill 148 282 405 176 282 405 minecraft:red_wool
fill 149 282 374 175 282 374 minecraft:red_wool
fill 149 282 406 175 282 406 minecraft:red_wool
fill 150 282 373 174 282 373 minecraft:red_wool
fill 150 282 407 174 282 407 minecraft:red_wool
fill 152 282 372 172 282 372 minecraft:red_wool
fill 152 282 408 172 282 408 minecraft:red_wool
fill 154 282 371 170 282 371 minecraft:red_wool
fill 154 282 409 170 282 409 minecraft:red_wool
fill 157 282 370 167 282 370 minecraft:red_wool
fill 157 282 410 167 282 410 minecraft:red_wool
fill 160 282 382 181 282 382 minecraft:red_wool
fill 160 282 400 180 282 400 minecraft:red_wool
fill 166 282 383 181 282 383 minecraft:red_wool
fill 166 282 399 180 282 399 minecraft:red_wool
fill 168 282 384 181 282 384 minecraft:red_wool
fill 168 282 398 181 282 398 minecraft:red_wool
fill 169 282 397 181 282 397 minecraft:red_wool
fill 170 282 396 181 282 396 minecraft:red_wool
setblock 142 283 371 minecraft:white_concrete
fill 142 283 375 142 300 375 minecraft:white_concrete
setblock 142 283 378 minecraft:white_concrete
fill 142 283 382 142 300 382 minecraft:white_concrete
setblock 142 283 385 minecraft:white_concrete
fill 142 283 389 142 300 389 minecraft:white_concrete
setblock 142 283 392 minecraft:white_concrete
fill 142 283 396 142 300 396 minecraft:white_concrete
fill 142 283 399 144 285 410 minecraft:white_concrete
fill 143 283 384 150 283 396 minecraft:red_wool
fill 144 283 370 144 300 370 minecraft:white_concrete
setblock 144 283 372 minecraft:light[level=14]
setblock 144 283 380 minecraft:light[level=14]
fill 144 283 382 153 283 383 minecraft:red_wool
fill 144 283 397 152 283 398 minecraft:red_wool
fill 145 283 380 155 283 381 minecraft:red_wool
fill 145 283 399 154 283 400 minecraft:red_wool
fill 145 283 401 145 285 410 minecraft:white_concrete
fill 146 283 379 159 283 379 minecraft:red_wool
fill 146 283 401 157 283 401 minecraft:red_wool
fill 146 283 402 146 285 410 minecraft:white_concrete
fill 147 283 377 177 283 378 minecraft:red_wool
fill 147 283 402 160 283 403 minecraft:red_wool
fill 147 283 404 147 285 410 minecraft:white_concrete
setblock 148 283 370 minecraft:white_concrete
fill 148 283 376 176 283 376 minecraft:red_wool
fill 148 283 404 176 283 404 minecraft:red_wool
fill 148 283 405 148 285 410 minecraft:white_concrete
fill 149 283 375 175 283 375 minecraft:red_wool
fill 149 283 405 175 283 405 minecraft:red_wool
fill 149 283 410 149 300 410 minecraft:white_concrete
fill 151 283 370 151 300 370 minecraft:white_concrete
fill 151 283 374 173 283 374 minecraft:red_wool
fill 151 283 384 151 283 387 minecraft:red_wool
fill 151 283 388 152 283 393 minecraft:white_wool
fill 151 283 394 151 283 396 minecraft:red_wool
fill 151 283 406 173 283 406 minecraft:red_wool
setblock 152 283 372 minecraft:light[level=14]
fill 152 283 373 172 283 373 minecraft:red_wool
setblock 152 283 384 minecraft:red_wool
fill 152 283 385 152 283 387 minecraft:white_wool
fill 152 283 394 152 283 396 minecraft:white_wool
fill 152 283 407 172 283 407 minecraft:red_wool
setblock 152 283 410 minecraft:white_concrete
fill 153 283 384 153 283 386 minecraft:white_wool
fill 153 283 395 153 283 397 minecraft:white_wool
setblock 153 283 398 minecraft:red_wool
fill 154 283 372 170 283 372 minecraft:red_wool
setblock 154 283 382 minecraft:red_wool
fill 154 283 383 154 283 384 minecraft:white_wool
fill 154 283 397 154 283 398 minecraft:white_wool
fill 154 283 408 170 283 408 minecraft:red_wool
setblock 155 283 370 minecraft:white_concrete
fill 155 283 382 155 283 383 minecraft:white_wool
fill 155 283 398 155 283 399 minecraft:white_wool
setblock 155 283 400 minecraft:red_wool
fill 156 283 371 168 283 371 minecraft:red_wool
setblock 156 283 380 minecraft:red_wool
fill 156 283 381 157 283 382 minecraft:white_wool
fill 156 283 399 156 283 400 minecraft:white_wool
fill 156 283 409 168 283 409 minecraft:red_wool
fill 156 283 410 156 300 410 minecraft:white_concrete
fill 157 283 380 167 283 380 minecraft:white_wool
fill 157 283 400 158 283 400 minecraft:white_wool
fill 158 283 370 158 300 370 minecraft:white_concrete
fill 158 283 381 159 283 381 minecraft:white_wool
fill 158 283 401 167 283 401 minecraft:white_wool
setblock 159 283 410 minecraft:white_concrete
fill 160 283 379 164 283 379 minecraft:white_wool
setblock 160 283 388 minecraft:light[level=14]
setblock 160 283 396 minecraft:light[level=14]
fill 161 283 402 163 283 402 minecraft:white_wool
fill 161 283 403 177 283 403 minecraft:red_wool
setblock 162 283 370 minecraft:white_concrete
fill 163 283 410 163 300 410 minecraft:white_concrete
fill 164 283 402 177 283 402 minecraft:red_wool
fill 165 283 370 165 300 370 minecraft:white_concrete
fill 165 283 379 178 283 379 minecraft:red_wool
fill 166 283 381 169 283 381 minecraft:white_wool
setblock 166 283 410 minecraft:white_concrete
fill 167 283 400 168 283 400 minecraft:white_wool
fill 168 283 380 179 283 380 minecraft:red_wool
fill 168 283 382 170 283 382 minecraft:white_wool
setblock 168 283 388 minecraft:light[level=14]
setblock 168 283 396 minecraft:light[level=14]
fill 168 283 401 178 283 401 minecraft:red_wool
setblock 169 283 370 minecraft:white_concrete
fill 169 283 383 171 283 383 minecraft:white_wool
fill 169 283 399 170 283 399 minecraft:white_wool
fill 169 283 400 179 283 400 minecraft:red_wool
fill 170 283 381 179 283 381 minecraft:red_wool
fill 170 283 384 171 283 384 minecraft:white_wool
fill 170 283 398 171 283 398 minecraft:white_wool
fill 170 283 409 178 285 410 minecraft:white_concrete
fill 171 283 382 180 283 382 minecraft:red_wool
fill 171 283 385 172 283 385 minecraft:white_wool
setblock 171 283 397 minecraft:white_wool
fill 171 283 399 179 283 399 minecraft:red_wool
fill 171 283 408 178 285 408 minecraft:white_concrete
fill 172 283 370 172 300 370 minecraft:white_concrete
fill 172 283 383 180 283 384 minecraft:red_wool
fill 172 283 386 173 283 387 minecraft:white_wool
fill 172 283 394 172 283 396 minecraft:white_wool
fill 172 283 397 180 283 398 minecraft:red_wool
fill 173 283 385 181 283 385 minecraft:red_wool
fill 173 283 388 173 283 394 minecraft:white_wool
fill 173 283 395 181 283 396 minecraft:red_wool
fill 173 283 407 178 285 407 minecraft:white_concrete
fill 174 283 386 181 283 394 minecraft:red_wool
fill 174 283 406 178 285 406 minecraft:white_concrete
setblock 176 283 370 minecraft:white_concrete
setblock 176 283 372 minecraft:light[level=14]
fill 176 283 405 178 285 405 minecraft:white_concrete
fill 177 283 404 178 285 404 minecraft:white_concrete
fill 178 283 402 178 285 403 minecraft:white_concrete
fill 179 283 370 179 300 370 minecraft:white_concrete
fill 180 283 370 180 283 372 minecraft:gray_concrete
setblock 180 283 410 minecraft:white_concrete
setblock 181 283 384 minecraft:red_wool
setblock 182 283 371 minecraft:white_concrete
fill 182 283 374 182 300 374 minecraft:white_concrete
setblock 182 283 378 minecraft:white_concrete
fill 182 283 381 182 300 381 minecraft:white_concrete
setblock 182 283 385 minecraft:white_concrete
fill 182 283 388 182 300 388 minecraft:white_concrete
setblock 182 283 392 minecraft:white_concrete
fill 182 283 395 182 300 395 minecraft:white_concrete
setblock 182 283 399 minecraft:white_concrete
fill 182 283 402 182 300 402 minecraft:white_concrete
setblock 182 283 406 minecraft:white_concrete
fill 182 283 409 182 300 409 minecraft:white_concrete
setblock 142 284 372 minecraft:white_concrete
setblock 142 284 379 minecraft:white_concrete
setblock 142 284 386 minecraft:white_concrete
setblock 142 284 393 minecraft:white_concrete
fill 144 284 385 148 284 395 minecraft:red_wool
fill 145 284 382 150 284 384 minecraft:red_wool
fill 145 284 396 150 284 398 minecraft:red_wool
fill 145 284 399 145 285 400 minecraft:white_concrete
fill 146 284 381 152 284 381 minecraft:red_wool
fill 146 284 399 152 284 399 minecraft:red_wool
fill 146 284 400 146 285 401 minecraft:white_concrete
setblock 147 284 370 minecraft:white_concrete
fill 147 284 379 153 284 380 minecraft:red_wool
fill 147 284 400 153 284 401 minecraft:red_wool
fill 147 284 402 147 285 403 minecraft:white_concrete
fill 148 284 378 156 284 378 minecraft:red_wool
fill 148 284 402 156 284 402 minecraft:red_wool
fill 148 284 403 148 285 404 minecraft:white_concrete
fill 149 284 377 160 284 377 minecraft:red_wool
fill 149 284 385 149 285 388 minecraft:red_wool
fill 149 284 389 150 284 392 minecraft:white_wool
fill 149 284 393 149 285 395 minecraft:red_wool
fill 149 284 403 158 284 403 minecraft:red_wool
fill 150 284 376 174 284 376 minecraft:red_wool
fill 150 284 385 150 284 388 minecraft:white_wool
fill 150 284 393 150 284 395 minecraft:white_wool
fill 150 284 404 174 284 404 minecraft:red_wool
fill 151 284 375 173 284 375 minecraft:red_wool
fill 151 284 382 151 285 382 minecraft:red_wool
fill 151 284 383 151 284 387 minecraft:white_wool
fill 151 284 394 151 284 397 minecraft:white_wool
fill 151 284 398 151 285 398 minecraft:red_wool
fill 151 284 405 173 284 405 minecraft:red_wool
fill 152 284 382 152 284 384 minecraft:white_wool
fill 152 284 397 152 284 398 minecraft:white_wool
fill 153 284 374 171 284 374 minecraft:red_wool
fill 153 284 381 153 284 383 minecraft:white_wool
fill 153 284 398 153 284 399 minecraft:white_wool
fill 153 284 406 171 284 406 minecraft:red_wool
setblock 153 284 410 minecraft:white_concrete
setblock 154 284 370 minecraft:white_concrete
fill 154 284 373 170 284 373 minecraft:red_wool
fill 154 284 379 154 285 379 minecraft:red_wool
fill 154 284 380 154 284 382 minecraft:white_wool
fill 154 284 399 154 284 400 minecraft:white_wool
fill 154 284 401 154 285 401 minecraft:red_wool
fill 154 284 407 170 284 407 minecraft:red_wool
fill 155 284 379 155 284 381 minecraft:white_wool
fill 155 284 400 155 284 401 minecraft:white_wool
fill 156 284 379 156 284 380 minecraft:white_wool
fill 156 284 401 157 284 401 minecraft:white_wool
fill 157 284 372 167 284 372 minecraft:red_wool
fill 157 284 378 159 284 379 minecraft:white_wool
fill 157 284 402 160 284 402 minecraft:white_wool
fill 157 284 408 167 284 408 minecraft:red_wool
fill 159 284 403 165 284 403 minecraft:white_wool
fill 160 284 378 167 284 378 minecraft:white_wool
setblock 160 284 410 minecraft:white_concrete
setblock 161 284 370 minecraft:white_concrete
fill 161 284 377 163 284 377 minecraft:white_wool
fill 164 284 377 175 284 377 minecraft:red_wool
fill 164 284 402 167 284 402 minecraft:white_wool
fill 165 284 379 169 284 379 minecraft:white_wool
fill 166 284 403 175 284 403 minecraft:red_wool
setblock 167 284 410 minecraft:white_concrete
setblock 168 284 370 minecraft:white_concrete
fill 168 284 378 176 284 378 minecraft:red_wool
fill 168 284 380 170 284 380 minecraft:white_wool
fill 168 284 401 169 284 401 minecraft:white_wool
fill 168 284 402 176 284 402 minecraft:red_wool
fill 169 284 400 170 284 400 minecraft:white_wool
fill 170 284 379 177 284 379 minecraft:red_wool
fill 170 284 381 171 284 381 minecraft:white_wool
fill 170 284 401 177 284 401 minecraft:red_wool
fill 170 284 408 170 285 408 minecraft:white_concrete
fill 171 284 380 177 284 380 minecraft:red_wool
fill 171 284 382 172 284 382 minecraft:white_wool
setblock 171 284 399 minecraft:white_wool
fill 171 284 400 177 284 400 minecraft:red_wool
fill 171 284 407 172 285 407 minecraft:white_concrete
fill 172 284 381 178 284 381 minecraft:red_wool
fill 172 284 383 173 284 384 minecraft:white_wool
fill 172 284 397 172 284 398 minecraft:white_wool
fill 172 284 399 178 284 399 minecraft:red_wool
fill 172 284 406 173 285 406 minecraft:white_concrete
fill 173 284 382 179 284 382 minecraft:red_wool
fill 173 284 385 174 284 385 minecraft:white_wool
fill 173 284 395 173 284 397 minecraft:white_wool
fill 173 284 398 179 284 398 minecraft:red_wool
fill 174 284 383 179 284 384 minecraft:red_wool
fill 174 284 386 174 284 395 minecraft:white_wool
fill 174 284 396 179 284 397 minecraft:red_wool
fill 174 284 405 175 285 405 minecraft:white_concrete
setblock 175 284 370 minecraft:white_concrete
fill 175 284 385 180 284 387 minecraft:red_wool
fill 175 284 388 175 284 392 minecraft:white_wool
fill 175 284 393 180 284 395 minecraft:red_wool
fill 175 284 404 176 285 404 minecraft:white_concrete
fill 176 284 388 180 284 392 minecraft:red_wool
fill 176 284 403 177 285 403 minecraft:white_concrete
fill 177 284 402 177 300 402 minecraft:white_concrete
fill 178 284 400 178 285 401 minecraft:white_concrete
setblock 181 284 410 minecraft:white_concrete
setblock 182 284 370 minecraft:white_concrete
setblock 182 284 377 minecraft:white_concrete
setblock 182 284 384 minecraft:white_concrete
setblock 182 284 391 minecraft:white_concrete
setblock 182 284 398 minecraft:white_concrete
setblock 182 284 405 minecraft:white_concrete
setblock 142 285 373 minecraft:white_concrete
setblock 142 285 380 minecraft:white_concrete
setblock 142 285 387 minecraft:white_concrete
setblock 142 285 394 minecraft:white_concrete
fill 145 285 388 148 285 392 minecraft:red_wool
setblock 146 285 370 minecraft:white_concrete
fill 146 285 384 148 285 387 minecraft:red_wool
fill 146 285 393 148 285 396 minecraft:red_wool
fill 146 285 399 147 285 399 minecraft:white_concrete
fill 147 285 382 150 285 383 minecraft:red_wool
fill 147 285 397 150 285 398 minecraft:red_wool
fill 147 285 400 147 285 401 minecraft:white_concrete
fill 148 285 380 152 285 381 minecraft:red_wool
fill 148 285 399 152 285 400 minecraft:red_wool
fill 148 285 401 148 285 402 minecraft:white_concrete
fill 149 285 379 153 285 379 minecraft:red_wool
fill 149 285 384 150 285 384 minecraft:red_wool
fill 149 285 396 150 285 396 minecraft:red_wool
fill 149 285 401 153 285 401 minecraft:red_wool
fill 150 285 378 156 285 378 minecraft:red_wool
fill 150 285 402 156 285 402 minecraft:red_wool
fill 151 285 377 160 285 377 minecraft:red_wool
fill 151 285 403 158 285 403 minecraft:red_wool
fill 152 285 376 172 285 376 minecraft:red_wool
fill 152 285 404 172 285 404 minecraft:red_wool
setblock 153 285 370 minecraft:white_concrete
setblock 153 285 380 minecraft:red_wool
setblock 153 285 400 minecraft:red_wool
fill 154 285 375 170 285 375 minecraft:red_wool
fill 154 285 405 170 285 405 minecraft:red_wool
setblock 154 285 410 minecraft:white_concrete
fill 156 285 374 168 285 374 minecraft:red_wool
fill 156 285 406 168 285 406 minecraft:red_wool
setblock 160 285 370 minecraft:white_concrete
fill 160 285 373 164 285 373 minecraft:red_wool
fill 160 285 407 164 285 407 minecraft:red_wool
setblock 161 285 410 minecraft:white_concrete
fill 164 285 377 173 285 377 minecraft:red_wool
fill 166 285 403 173 285 403 minecraft:red_wool
setblock 167 285 370 minecraft:white_concrete
fill 168 285 378 174 285 378 minecraft:red_wool
fill 168 285 402 174 285 402 minecraft:red_wool
setblock 168 285 410 minecraft:white_concrete
fill 170 285 379 175 285 379 minecraft:red_wool
setblock 170 285 400 minecraft:white_concrete
fill 170 285 401 175 285 401 minecraft:red_wool
fill 170 285 406 170 285 407 minecraft:white_concrete
fill 171 285 380 176 285 380 minecraft:red_wool
fill 171 285 400 176 285 400 minecraft:red_wool
fill 171 285 405 171 285 406 minecraft:white_concrete
fill 172 285 381 176 285 381 minecraft:red_wool
fill 172 285 399 176 285 399 minecraft:red_wool
fill 172 285 405 173 285 405 minecraft:white_concrete
fill 173 285 382 177 285 382 minecraft:red_wool
fill 173 285 398 177 285 398 minecraft:red_wool
fill 173 285 404 174 285 404 minecraft:white_concrete
setblock 174 285 370 minecraft:white_concrete
fill 174 285 383 177 285 384 minecraft:red_wool
fill 174 285 396 177 285 397 minecraft:red_wool
fill 174 285 403 175 285 403 minecraft:white_concrete
fill 175 285 385 178 285 387 minecraft:red_wool
fill 175 285 393 178 285 395 minecraft:red_wool
fill 175 285 402 176 285 402 minecraft:white_concrete
fill 176 285 388 179 285 392 minecraft:red_wool
fill 176 285 401 177 285 401 minecraft:white_concrete
fill 177 285 400 177 300 400 minecraft:white_concrete
setblock 178 285 384 minecraft:red_wool
setblock 178 285 396 minecraft:red_wool
setblock 181 285 370 minecraft:white_concrete
setblock 182 285 376 minecraft:white_concrete
setblock 182 285 383 minecraft:white_concrete
setblock 182 285 390 minecraft:white_concrete
setblock 182 285 397 minecraft:white_concrete
setblock 182 285 404 minecraft:white_concrete
setblock 182 285 410 minecraft:white_concrete
setblock 142 286 374 minecraft:white_concrete
setblock 142 286 381 minecraft:white_concrete
setblock 142 286 388 minecraft:white_concrete
setblock 142 286 395 minecraft:white_concrete
fill 142 286 399 142 300 399 minecraft:white_concrete
setblock 142 286 400 minecraft:jack_o_lantern
fill 142 286 401 142 300 401 minecraft:white_concrete
setblock 142 286 402 minecraft:jack_o_lantern
fill 142 286 403 142 300 403 minecraft:white_concrete
setblock 142 286 404 minecraft:jack_o_lantern
fill 142 286 405 142 300 405 minecraft:white_concrete
setblock 142 286 406 minecraft:jack_o_lantern
fill 142 286 407 142 300 407 minecraft:white_concrete
setblock 142 286 408 minecraft:jack_o_lantern
fill 142 286 409 142 300 409 minecraft:white_concrete
setblock 142 286 410 minecraft:jack_o_lantern
setblock 143 286 399 minecraft:jack_o_lantern
fill 143 286 400 143 300 400 minecraft:white_concrete
setblock 143 286 401 minecraft:jack_o_lantern
fill 143 286 402 143 300 402 minecraft:white_concrete
setblock 143 286 403 minecraft:jack_o_lantern
fill 143 286 404 143 300 404 minecraft:white_concrete
setblock 143 286 405 minecraft:jack_o_lantern
fill 143 286 406 143 300 406 minecraft:white_concrete
setblock 143 286 407 minecraft:jack_o_lantern
fill 143 286 408 143 300 408 minecraft:white_concrete
setblock 143 286 409 minecraft:jack_o_lantern
fill 143 286 410 143 300 410 minecraft:white_concrete
setblock 143 286 411 minecraft:jack_o_lantern
fill 144 286 399 144 300 399 minecraft:white_concrete
setblock 144 286 400 minecraft:jack_o_lantern
fill 144 286 401 144 300 401 minecraft:white_concrete
setblock 144 286 402 minecraft:jack_o_lantern
fill 144 286 403 144 300 403 minecraft:white_concrete
setblock 144 286 404 minecraft:jack_o_lantern
fill 144 286 405 144 300 405 minecraft:white_concrete
setblock 144 286 406 minecraft:jack_o_lantern
fill 144 286 407 144 300 407 minecraft:white_concrete
setblock 144 286 408 minecraft:jack_o_lantern
fill 144 286 409 144 300 409 minecraft:white_concrete
setblock 144 286 410 minecraft:jack_o_lantern
fill 144 286 411 144 307 411 minecraft:purple_terracotta
setblock 145 286 370 minecraft:white_concrete
setblock 145 286 399 minecraft:jack_o_lantern
fill 145 286 400 145 300 400 minecraft:white_concrete
setblock 145 286 401 minecraft:jack_o_lantern
fill 145 286 402 145 300 402 minecraft:white_concrete
setblock 145 286 403 minecraft:jack_o_lantern
fill 145 286 404 145 300 404 minecraft:white_concrete
setblock 145 286 405 minecraft:jack_o_lantern
fill 145 286 406 145 300 406 minecraft:white_concrete
setblock 145 286 407 minecraft:jack_o_lantern
fill 145 286 408 145 300 408 minecraft:white_concrete
setblock 145 286 409 minecraft:jack_o_lantern
fill 145 286 410 145 300 410 minecraft:white_concrete
setblock 145 286 411 minecraft:jack_o_lantern
fill 146 286 399 146 300 399 minecraft:white_concrete
setblock 146 286 400 minecraft:jack_o_lantern
fill 146 286 401 146 300 401 minecraft:white_concrete
setblock 146 286 402 minecraft:jack_o_lantern
fill 146 286 403 146 300 403 minecraft:white_concrete
setblock 146 286 404 minecraft:jack_o_lantern
fill 146 286 405 146 300 405 minecraft:white_concrete
setblock 146 286 406 minecraft:jack_o_lantern
fill 146 286 407 146 300 407 minecraft:white_concrete
setblock 146 286 408 minecraft:jack_o_lantern
fill 146 286 409 146 300 409 minecraft:white_concrete
setblock 146 286 410 minecraft:jack_o_lantern
fill 146 286 411 146 307 411 minecraft:purple_terracotta
setblock 147 286 399 minecraft:jack_o_lantern
fill 147 286 400 147 300 400 minecraft:white_concrete
setblock 147 286 401 minecraft:jack_o_lantern
fill 147 286 402 147 300 402 minecraft:white_concrete
setblock 147 286 403 minecraft:jack_o_lantern
fill 147 286 404 147 300 404 minecraft:white_concrete
setblock 147 286 405 minecraft:jack_o_lantern
fill 147 286 406 147 300 406 minecraft:white_concrete
setblock 147 286 407 minecraft:jack_o_lantern
fill 147 286 408 147 300 408 minecraft:white_concrete
setblock 147 286 409 minecraft:jack_o_lantern
fill 147 286 410 147 300 410 minecraft:white_concrete
setblock 147 286 411 minecraft:jack_o_lantern
fill 148 286 399 148 300 399 minecraft:white_concrete
setblock 148 286 400 minecraft:jack_o_lantern
fill 148 286 401 148 300 401 minecraft:white_concrete
setblock 148 286 402 minecraft:jack_o_lantern
fill 148 286 403 148 300 403 minecraft:white_concrete
setblock 148 286 404 minecraft:jack_o_lantern
fill 148 286 405 148 300 405 minecraft:white_concrete
setblock 148 286 406 minecraft:jack_o_lantern
fill 148 286 407 148 300 407 minecraft:white_concrete
setblock 148 286 408 minecraft:jack_o_lantern
fill 148 286 409 148 300 409 minecraft:white_concrete
setblock 148 286 410 minecraft:jack_o_lantern
fill 148 286 411 148 307 411 minecraft:purple_terracotta
setblock 152 286 370 minecraft:white_concrete
setblock 155 286 410 minecraft:white_concrete
setblock 159 286 370 minecraft:white_concrete
setblock 162 286 410 minecraft:white_concrete
setblock 166 286 370 minecraft:white_concrete
setblock 169 286 410 minecraft:white_concrete
setblock 170 286 400 minecraft:jack_o_lantern
fill 170 286 401 170 300 401 minecraft:white_concrete
setblock 170 286 402 minecraft:jack_o_lantern
fill 170 286 403 170 300 403 minecraft:white_concrete
setblock 170 286 404 minecraft:jack_o_lantern
fill 170 286 405 170 300 405 minecraft:white_concrete
setblock 170 286 406 minecraft:jack_o_lantern
fill 170 286 407 170 300 407 minecraft:white_concrete
setblock 170 286 408 minecraft:jack_o_lantern
fill 170 286 409 170 300 409 minecraft:white_concrete
setblock 170 286 410 minecraft:jack_o_lantern
fill 171 286 400 171 300 400 minecraft:white_concrete
setblock 171 286 401 minecraft:jack_o_lantern
fill 171 286 402 171 300 402 minecraft:white_concrete
setblock 171 286 403 minecraft:jack_o_lantern
fill 171 286 404 171 300 404 minecraft:white_concrete
setblock 171 286 405 minecraft:jack_o_lantern
fill 171 286 406 171 300 406 minecraft:white_concrete
setblock 171 286 407 minecraft:jack_o_lantern
fill 171 286 408 171 300 408 minecraft:white_concrete
setblock 171 286 409 minecraft:jack_o_lantern
fill 171 286 410 171 300 410 minecraft:white_concrete
setblock 172 286 400 minecraft:jack_o_lantern
fill 172 286 401 172 300 401 minecraft:white_concrete
setblock 172 286 402 minecraft:jack_o_lantern
fill 172 286 403 172 300 403 minecraft:white_concrete
setblock 172 286 404 minecraft:jack_o_lantern
fill 172 286 405 172 300 405 minecraft:white_concrete
setblock 172 286 406 minecraft:jack_o_lantern
fill 172 286 407 172 300 407 minecraft:white_concrete
setblock 172 286 408 minecraft:jack_o_lantern
fill 172 286 409 172 300 409 minecraft:white_concrete
setblock 172 286 410 minecraft:jack_o_lantern
setblock 173 286 370 minecraft:white_concrete
fill 173 286 400 173 300 400 minecraft:white_concrete
setblock 173 286 401 minecraft:jack_o_lantern
fill 173 286 402 173 300 402 minecraft:white_concrete
setblock 173 286 403 minecraft:jack_o_lantern
fill 173 286 404 173 300 404 minecraft:white_concrete
setblock 173 286 405 minecraft:jack_o_lantern
fill 173 286 406 173 300 406 minecraft:white_concrete
setblock 173 286 407 minecraft:jack_o_lantern
fill 173 286 408 173 300 408 minecraft:white_concrete
setblock 173 286 409 minecraft:jack_o_lantern
fill 173 286 410 173 300 410 minecraft:white_concrete
setblock 174 286 400 minecraft:jack_o_lantern
fill 174 286 401 174 300 401 minecraft:white_concrete
setblock 174 286 402 minecraft:jack_o_lantern
fill 174 286 403 174 300 403 minecraft:white_concrete
setblock 174 286 404 minecraft:jack_o_lantern
fill 174 286 405 174 300 405 minecraft:white_concrete
setblock 174 286 406 minecraft:jack_o_lantern
fill 174 286 407 174 300 407 minecraft:white_concrete
setblock 174 286 408 minecraft:jack_o_lantern
fill 174 286 409 174 300 409 minecraft:white_concrete
setblock 174 286 410 minecraft:jack_o_lantern
fill 175 286 400 175 300 400 minecraft:white_concrete
setblock 175 286 401 minecraft:jack_o_lantern
fill 175 286 402 175 300 402 minecraft:white_concrete
setblock 175 286 403 minecraft:jack_o_lantern
fill 175 286 404 175 300 404 minecraft:white_concrete
setblock 175 286 405 minecraft:jack_o_lantern
fill 175 286 406 175 300 406 minecraft:white_concrete
setblock 175 286 407 minecraft:jack_o_lantern
fill 175 286 408 175 300 408 minecraft:white_concrete
setblock 175 286 409 minecraft:jack_o_lantern
fill 175 286 410 175 300 410 minecraft:white_concrete
setblock 176 286 400 minecraft:jack_o_lantern
fill 176 286 401 176 300 401 minecraft:white_concrete
setblock 176 286 402 minecraft:jack_o_lantern
fill 176 286 403 176 300 403 minecraft:white_concrete
setblock 176 286 404 minecraft:jack_o_lantern
fill 176 286 405 176 300 405 minecraft:white_concrete
setblock 176 286 406 minecraft:jack_o_lantern
fill 176 286 407 176 300 407 minecraft:white_concrete
setblock 176 286 408 minecraft:jack_o_lantern
fill 176 286 409 176 300 409 minecraft:white_concrete
setblock 176 286 410 minecraft:jack_o_lantern
setblock 177 286 401 minecraft:jack_o_lantern
setblock 177 286 403 minecraft:jack_o_lantern
fill 177 286 404 177 300 404 minecraft:white_concrete
setblock 177 286 405 minecraft:jack_o_lantern
fill 177 286 406 177 300 406 minecraft:white_concrete
setblock 177 286 407 minecraft:jack_o_lantern
fill 177 286 408 177 300 408 minecraft:white_concrete
setblock 177 286 409 minecraft:jack_o_lantern
fill 177 286 410 177 300 410 minecraft:white_concrete
setblock 178 286 400 minecraft:jack_o_lantern
fill 178 286 401 178 300 401 minecraft:white_concrete
setblock 178 286 402 minecraft:jack_o_lantern
fill 178 286 403 178 300 403 minecraft:white_concrete
setblock 178 286 404 minecraft:jack_o_lantern
fill 178 286 405 178 300 405 minecraft:white_concrete
setblock 178 286 406 minecraft:jack_o_lantern
fill 178 286 407 178 300 407 minecraft:white_concrete
setblock 178 286 408 minecraft:jack_o_lantern
fill 178 286 409 178 300 409 minecraft:white_concrete
setblock 178 286 410 minecraft:jack_o_lantern
setblock 180 286 370 minecraft:white_concrete
setblock 182 286 375 minecraft:white_concrete
setblock 182 286 382 minecraft:white_concrete
setblock 182 286 389 minecraft:white_concrete
setblock 182 286 396 minecraft:white_concrete
setblock 182 286 403 minecraft:white_concrete
fill 142 287 400 142 288 400 minecraft:white_concrete
fill 142 287 402 142 288 402 minecraft:white_concrete
fill 142 287 404 142 288 404 minecraft:white_concrete
fill 142 287 406 142 288 406 minecraft:white_concrete
fill 142 287 408 142 288 408 minecraft:white_concrete
fill 142 287 410 142 288 410 minecraft:white_concrete
fill 143 287 399 143 288 399 minecraft:white_concrete
fill 143 287 401 143 288 401 minecraft:white_concrete
fill 143 287 403 143 288 403 minecraft:white_concrete
fill 143 287 405 143 288 405 minecraft:white_concrete
fill 143 287 407 143 288 407 minecraft:white_concrete
fill 143 287 409 143 288 409 minecraft:white_concrete
fill 143 287 411 143 288 411 minecraft:purple_terracotta
fill 144 287 400 144 288 400 minecraft:white_concrete
fill 144 287 402 144 288 402 minecraft:white_concrete
fill 144 287 404 144 288 404 minecraft:white_concrete
fill 144 287 406 144 288 406 minecraft:white_concrete
fill 144 287 408 144 288 408 minecraft:white_concrete
fill 144 287 410 144 288 410 minecraft:white_concrete
fill 145 287 399 145 288 399 minecraft:white_concrete
fill 145 287 401 145 288 401 minecraft:white_concrete
fill 145 287 403 145 288 403 minecraft:white_concrete
fill 145 287 405 145 288 405 minecraft:white_concrete
fill 145 287 407 145 288 407 minecraft:white_concrete
fill 145 287 409 145 288 409 minecraft:white_concrete
fill 145 287 411 145 288 411 minecraft:purple_terracotta
fill 146 287 400 146 288 400 minecraft:white_concrete
fill 146 287 402 146 288 402 minecraft:white_concrete
fill 146 287 404 146 288 404 minecraft:white_concrete
fill 146 287 406 146 288 406 minecraft:white_concrete
fill 146 287 408 146 288 408 minecraft:white_concrete
fill 146 287 410 146 288 410 minecraft:white_concrete
fill 147 287 399 147 288 399 minecraft:white_concrete
fill 147 287 401 147 288 401 minecraft:white_concrete
fill 147 287 403 147 288 403 minecraft:white_concrete
fill 147 287 405 147 288 405 minecraft:white_concrete
fill 147 287 407 147 288 407 minecraft:white_concrete
fill 147 287 409 147 288 409 minecraft:white_concrete
fill 147 287 411 147 288 411 minecraft:purple_terracotta
fill 148 287 400 148 288 400 minecraft:white_concrete
fill 148 287 402 148 288 402 minecraft:white_concrete
fill 148 287 404 148 288 404 minecraft:white_concrete
fill 148 287 406 148 288 406 minecraft:white_concrete
fill 148 287 408 148 288 408 minecraft:white_concrete
fill 148 287 410 148 288 410 minecraft:white_concrete
fill 170 287 400 170 288 400 minecraft:white_concrete
fill 170 287 402 170 288 402 minecraft:white_concrete
fill 170 287 404 170 288 404 minecraft:white_concrete
fill 170 287 406 170 288 406 minecraft:white_concrete
fill 170 287 408 170 288 408 minecraft:white_concrete
fill 170 287 410 170 288 410 minecraft:white_concrete
fill 171 287 401 171 288 401 minecraft:white_concrete
fill 171 287 403 171 288 403 minecraft:white_concrete
fill 171 287 405 171 288 405 minecraft:white_concrete
fill 171 287 407 171 288 407 minecraft:white_concrete
fill 171 287 409 171 288 409 minecraft:white_concrete
fill 172 287 400 172 288 400 minecraft:white_concrete
fill 172 287 402 172 288 402 minecraft:white_concrete
fill 172 287 404 172 288 404 minecraft:white_concrete
fill 172 287 406 172 288 406 minecraft:white_concrete
fill 172 287 408 172 288 408 minecraft:white_concrete
fill 172 287 410 172 288 410 minecraft:white_concrete
fill 173 287 401 173 288 401 minecraft:white_concrete
fill 173 287 403 173 288 403 minecraft:white_concrete
fill 173 287 405 173 288 405 minecraft:white_concrete
fill 173 287 407 173 288 407 minecraft:white_concrete
fill 173 287 409 173 288 409 minecraft:white_concrete
fill 174 287 400 174 288 400 minecraft:white_concrete
fill 174 287 402 174 288 402 minecraft:white_concrete
fill 174 287 404 174 288 404 minecraft:white_concrete
fill 174 287 406 174 288 406 minecraft:white_concrete
fill 174 287 408 174 288 408 minecraft:white_concrete
fill 174 287 410 174 288 410 minecraft:white_concrete
fill 175 287 401 175 288 401 minecraft:white_concrete
fill 175 287 403 175 288 403 minecraft:white_concrete
fill 175 287 405 175 288 405 minecraft:white_concrete
fill 175 287 407 175 288 407 minecraft:white_concrete
fill 175 287 409 175 288 409 minecraft:white_concrete
fill 176 287 400 176 288 400 minecraft:white_concrete
fill 176 287 402 176 288 402 minecraft:white_concrete
fill 176 287 404 176 288 404 minecraft:white_concrete
fill 176 287 406 176 288 406 minecraft:white_concrete
fill 176 287 408 176 288 408 minecraft:white_concrete
fill 176 287 410 176 288 410 minecraft:white_concrete
fill 177 287 401 177 288 401 minecraft:white_concrete
fill 177 287 403 177 288 403 minecraft:white_concrete
fill 177 287 405 177 288 405 minecraft:white_concrete
fill 177 287 407 177 288 407 minecraft:white_concrete
fill 177 287 409 177 288 409 minecraft:white_concrete
fill 178 287 400 178 288 400 minecraft:white_concrete
fill 178 287 402 178 288 402 minecraft:white_concrete
fill 178 287 404 178 288 404 minecraft:white_concrete
fill 178 287 406 178 288 406 minecraft:white_concrete
fill 178 287 408 178 288 408 minecraft:white_concrete
fill 178 287 410 178 288 410 minecraft:white_concrete
setblock 142 288 376 minecraft:white_concrete
setblock 142 288 383 minecraft:white_concrete
setblock 142 288 390 minecraft:white_concrete
setblock 142 288 397 minecraft:white_concrete
setblock 143 288 370 minecraft:white_concrete
setblock 150 288 370 minecraft:white_concrete
setblock 150 288 410 minecraft:white_concrete
setblock 157 288 370 minecraft:white_concrete
setblock 157 288 410 minecraft:white_concrete
setblock 164 288 370 minecraft:white_concrete
setblock 164 288 410 minecraft:white_concrete
setblock 171 288 370 minecraft:white_concrete
setblock 178 288 370 minecraft:white_concrete
setblock 182 288 373 minecraft:white_concrete
setblock 182 288 380 minecraft:white_concrete
setblock 182 288 387 minecraft:white_concrete
setblock 182 288 394 minecraft:white_concrete
setblock 182 288 401 minecraft:white_concrete
setblock 182 288 408 minecraft:white_concrete
fill 142 289 370 142 290 370 minecraft:white_concrete
fill 142 289 377 142 290 377 minecraft:white_concrete
fill 142 289 384 142 290 384 minecraft:white_concrete
fill 142 289 391 142 290 391 minecraft:white_concrete
fill 142 289 398 142 290 398 minecraft:white_concrete
setblock 142 289 400 minecraft:jack_o_lantern
setblock 142 289 402 minecraft:jack_o_lantern
setblock 142 289 404 minecraft:jack_o_lantern
setblock 142 289 406 minecraft:jack_o_lantern
setblock 142 289 408 minecraft:jack_o_lantern
setblock 142 289 410 minecraft:jack_o_lantern
setblock 143 289 399 minecraft:jack_o_lantern
setblock 143 289 401 minecraft:jack_o_lantern
setblock 143 289 403 minecraft:jack_o_lantern
setblock 143 289 405 minecraft:jack_o_lantern
setblock 143 289 407 minecraft:jack_o_lantern
setblock 143 289 409 minecraft:jack_o_lantern
setblock 143 289 411 minecraft:jack_o_lantern
setblock 144 289 400 minecraft:jack_o_lantern
setblock 144 289 402 minecraft:jack_o_lantern
setblock 144 289 404 minecraft:jack_o_lantern
setblock 144 289 406 minecraft:jack_o_lantern
setblock 144 289 408 minecraft:jack_o_lantern
setblock 144 289 410 minecraft:jack_o_lantern
setblock 145 289 399 minecraft:jack_o_lantern
setblock 145 289 401 minecraft:jack_o_lantern
setblock 145 289 403 minecraft:jack_o_lantern
setblock 145 289 405 minecraft:jack_o_lantern
setblock 145 289 407 minecraft:jack_o_lantern
setblock 145 289 409 minecraft:jack_o_lantern
setblock 145 289 411 minecraft:jack_o_lantern
setblock 146 289 400 minecraft:jack_o_lantern
setblock 146 289 402 minecraft:jack_o_lantern
setblock 146 289 404 minecraft:jack_o_lantern
setblock 146 289 406 minecraft:jack_o_lantern
setblock 146 289 408 minecraft:jack_o_lantern
setblock 146 289 410 minecraft:jack_o_lantern
setblock 147 289 399 minecraft:jack_o_lantern
setblock 147 289 401 minecraft:jack_o_lantern
setblock 147 289 403 minecraft:jack_o_lantern
setblock 147 289 405 minecraft:jack_o_lantern
setblock 147 289 407 minecraft:jack_o_lantern
setblock 147 289 409 minecraft:jack_o_lantern
setblock 147 289 411 minecraft:jack_o_lantern
setblock 148 289 400 minecraft:jack_o_lantern
setblock 148 289 402 minecraft:jack_o_lantern
setblock 148 289 404 minecraft:jack_o_lantern
setblock 148 289 406 minecraft:jack_o_lantern
setblock 148 289 408 minecraft:jack_o_lantern
setblock 148 289 410 minecraft:jack_o_lantern
fill 149 289 370 149 290 370 minecraft:white_concrete
fill 151 289 410 151 290 410 minecraft:white_concrete
fill 156 289 370 156 290 370 minecraft:white_concrete
fill 158 289 410 158 290 410 minecraft:white_concrete
fill 163 289 370 163 290 370 minecraft:white_concrete
fill 165 289 410 165 290 410 minecraft:white_concrete
fill 170 289 370 170 290 370 minecraft:white_concrete
setblock 170 289 400 minecraft:jack_o_lantern
setblock 170 289 402 minecraft:jack_o_lantern
setblock 170 289 404 minecraft:jack_o_lantern
setblock 170 289 406 minecraft:jack_o_lantern
setblock 170 289 408 minecraft:jack_o_lantern
setblock 170 289 410 minecraft:jack_o_lantern
setblock 171 289 401 minecraft:jack_o_lantern
setblock 171 289 403 minecraft:jack_o_lantern
setblock 171 289 405 minecraft:jack_o_lantern
setblock 171 289 407 minecraft:jack_o_lantern
setblock 171 289 409 minecraft:jack_o_lantern
setblock 172 289 400 minecraft:jack_o_lantern
setblock 172 289 402 minecraft:jack_o_lantern
setblock 172 289 404 minecraft:jack_o_lantern
setblock 172 289 406 minecraft:jack_o_lantern
setblock 172 289 408 minecraft:jack_o_lantern
setblock 172 289 410 minecraft:jack_o_lantern
setblock 173 289 401 minecraft:jack_o_lantern
setblock 173 289 403 minecraft:jack_o_lantern
setblock 173 289 405 minecraft:jack_o_lantern
setblock 173 289 407 minecraft:jack_o_lantern
setblock 173 289 409 minecraft:jack_o_lantern
setblock 174 289 400 minecraft:jack_o_lantern
setblock 174 289 402 minecraft:jack_o_lantern
setblock 174 289 404 minecraft:jack_o_lantern
setblock 174 289 406 minecraft:jack_o_lantern
setblock 174 289 408 minecraft:jack_o_lantern
setblock 174 289 410 minecraft:jack_o_lantern
setblock 175 289 401 minecraft:jack_o_lantern
setblock 175 289 403 minecraft:jack_o_lantern
setblock 175 289 405 minecraft:jack_o_lantern
setblock 175 289 407 minecraft:jack_o_lantern
setblock 175 289 409 minecraft:jack_o_lantern
setblock 176 289 400 minecraft:jack_o_lantern
setblock 176 289 402 minecraft:jack_o_lantern
setblock 176 289 404 minecraft:jack_o_lantern
setblock 176 289 406 minecraft:jack_o_lantern
setblock 176 289 408 minecraft:jack_o_lantern
setblock 176 289 410 minecraft:jack_o_lantern
fill 177 289 370 177 290 370 minecraft:white_concrete
setblock 177 289 401 minecraft:jack_o_lantern
setblock 177 289 403 minecraft:jack_o_lantern
setblock 177 289 405 minecraft:jack_o_lantern
setblock 177 289 407 minecraft:jack_o_lantern
setblock 177 289 409 minecraft:jack_o_lantern
setblock 178 289 400 minecraft:jack_o_lantern
setblock 178 289 402 minecraft:jack_o_lantern
setblock 178 289 404 minecraft:jack_o_lantern
setblock 178 289 406 minecraft:jack_o_lantern
setblock 178 289 408 minecraft:jack_o_lantern
setblock 178 289 410 minecraft:jack_o_lantern
fill 179 289 410 179 290 410 minecraft:white_concrete
fill 182 289 372 182 290 372 minecraft:white_concrete
fill 182 289 379 182 290 379 minecraft:white_concrete
fill 182 289 386 182 290 386 minecraft:white_concrete
fill 182 289 393 182 290 393 minecraft:white_concrete
fill 182 289 400 182 290 400 minecraft:white_concrete
fill 182 289 407 182 290 407 minecraft:white_concrete
fill 142 290 371 142 290 374 minecraft:white_concrete
setblock 142 290 376 minecraft:white_concrete
fill 142 290 378 142 290 381 minecraft:white_concrete
setblock 142 290 383 minecraft:white_concrete
fill 142 290 385 142 290 388 minecraft:white_concrete
setblock 142 290 390 minecraft:white_concrete
fill 142 290 392 142 290 395 minecraft:white_concrete
setblock 142 290 397 minecraft:white_concrete
fill 142 290 400 142 291 400 minecraft:white_concrete
fill 142 290 402 142 291 402 minecraft:white_concrete
fill 142 290 404 142 291 404 minecraft:white_concrete
fill 142 290 406 142 291 406 minecraft:white_concrete
fill 142 290 408 142 291 408 minecraft:white_concrete
fill 142 290 410 142 291 410 minecraft:white_concrete
setblock 143 290 370 minecraft:white_concrete
fill 143 290 399 143 291 399 minecraft:white_concrete
fill 143 290 401 143 291 401 minecraft:white_concrete
fill 143 290 403 143 291 403 minecraft:white_concrete
fill 143 290 405 143 291 405 minecraft:white_concrete
fill 143 290 407 143 291 407 minecraft:white_concrete
fill 143 290 409 143 291 409 minecraft:white_concrete
fill 143 290 411 143 291 411 minecraft:purple_terracotta
fill 144 290 400 144 291 400 minecraft:white_concrete
fill 144 290 402 144 291 402 minecraft:white_concrete
fill 144 290 404 144 291 404 minecraft:white_concrete
fill 144 290 406 144 291 406 minecraft:white_concrete
fill 144 290 408 144 291 408 minecraft:white_concrete
fill 144 290 410 144 291 410 minecraft:white_concrete
fill 145 290 370 148 290 370 minecraft:white_concrete
fill 145 290 399 145 291 399 minecraft:white_concrete
fill 145 290 401 145 291 401 minecraft:white_concrete
fill 145 290 403 145 291 403 minecraft:white_concrete
fill 145 290 405 145 291 405 minecraft:white_concrete
fill 145 290 407 145 291 407 minecraft:white_concrete
fill 145 290 409 145 291 409 minecraft:white_concrete
fill 145 290 411 145 291 411 minecraft:purple_terracotta
fill 146 290 400 146 291 400 minecraft:white_concrete
fill 146 290 402 146 291 402 minecraft:white_concrete
fill 146 290 404 146 291 404 minecraft:white_concrete
fill 146 290 406 146 291 406 minecraft:white_concrete
fill 146 290 408 146 291 408 minecraft:white_concrete
fill 146 290 410 146 291 410 minecraft:white_concrete
fill 147 290 399 147 291 399 minecraft:white_concrete
fill 147 290 401 147 291 401 minecraft:white_concrete
fill 147 290 403 147 291 403 minecraft:white_concrete
fill 147 290 405 147 291 405 minecraft:white_concrete
fill 147 290 407 147 291 407 minecraft:white_concrete
fill 147 290 409 147 291 409 minecraft:white_concrete
fill 147 290 411 147 291 411 minecraft:purple_terracotta
fill 148 290 400 148 291 400 minecraft:white_concrete
fill 148 290 402 148 291 402 minecraft:white_concrete
fill 148 290 404 148 291 404 minecraft:white_concrete
fill 148 290 406 148 291 406 minecraft:white_concrete
fill 148 290 408 148 291 408 minecraft:white_concrete
fill 148 290 410 148 291 410 minecraft:white_concrete
setblock 150 290 370 minecraft:white_concrete
setblock 150 290 410 minecraft:white_concrete
fill 152 290 370 155 290 370 minecraft:white_concrete
fill 152 290 410 155 290 410 minecraft:white_concrete
setblock 157 290 370 minecraft:white_concrete
setblock 157 290 410 minecraft:white_concrete
fill 159 290 370 162 290 370 minecraft:white_concrete
fill 159 290 410 162 290 410 minecraft:white_concrete
setblock 164 290 370 minecraft:white_concrete
setblock 164 290 410 minecraft:white_concrete
fill 166 290 370 169 290 370 minecraft:white_concrete
fill 166 290 410 170 290 410 minecraft:white_concrete
fill 170 290 400 170 291 400 minecraft:white_concrete
fill 170 290 402 170 291 402 minecraft:white_concrete
fill 170 290 404 170 291 404 minecraft:white_concrete
fill 170 290 406 170 291 406 minecraft:white_concrete
fill 170 290 408 170 291 408 minecraft:white_concrete
setblock 171 290 370 minecraft:white_concrete
fill 171 290 401 171 291 401 minecraft:white_concrete
fill 171 290 403 171 291 403 minecraft:white_concrete
fill 171 290 405 171 291 405 minecraft:white_concrete
fill 171 290 407 171 291 407 minecraft:white_concrete
fill 171 290 409 171 291 409 minecraft:white_concrete
fill 172 290 400 172 291 400 minecraft:white_concrete
fill 172 290 402 172 291 402 minecraft:white_concrete
fill 172 290 404 172 291 404 minecraft:white_concrete
fill 172 290 406 172 291 406 minecraft:white_concrete
fill 172 290 408 172 291 408 minecraft:white_concrete
fill 172 290 410 172 291 410 minecraft:white_concrete
fill 173 290 370 176 290 370 minecraft:white_concrete
fill 173 290 401 173 291 401 minecraft:white_concrete
fill 173 290 403 173 291 403 minecraft:white_concrete
fill 173 290 405 173 291 405 minecraft:white_concrete
fill 173 290 407 173 291 407 minecraft:white_concrete
fill 173 290 409 173 291 409 minecraft:white_concrete
fill 174 290 400 174 291 400 minecraft:white_concrete
fill 174 290 402 174 291 402 minecraft:white_concrete
fill 174 290 404 174 291 404 minecraft:white_concrete
fill 174 290 406 174 291 406 minecraft:white_concrete
fill 174 290 408 174 291 408 minecraft:white_concrete
fill 174 290 410 174 291 410 minecraft:white_concrete
fill 175 290 401 175 291 401 minecraft:white_concrete
fill 175 290 403 175 291 403 minecraft:white_concrete
fill 175 290 405 175 291 405 minecraft:white_concrete
fill 175 290 407 175 291 407 minecraft:white_concrete
fill 175 290 409 175 291 409 minecraft:white_concrete
fill 176 290 400 176 291 400 minecraft:white_concrete
fill 176 290 402 176 291 402 minecraft:white_concrete
fill 176 290 404 176 291 404 minecraft:white_concrete
fill 176 290 406 176 291 406 minecraft:white_concrete
fill 176 290 408 176 291 408 minecraft:white_concrete
fill 176 290 410 176 291 410 minecraft:white_concrete
fill 177 290 401 177 291 401 minecraft:white_concrete
fill 177 290 403 177 291 403 minecraft:white_concrete
fill 177 290 405 177 291 405 minecraft:white_concrete
fill 177 290 407 177 291 407 minecraft:white_concrete
fill 177 290 409 177 291 409 minecraft:white_concrete
setblock 178 290 370 minecraft:white_concrete
fill 178 290 400 178 291 400 minecraft:white_concrete
fill 178 290 402 178 291 402 minecraft:white_concrete
fill 178 290 404 178 291 404 minecraft:white_concrete
fill 178 290 406 178 291 406 minecraft:white_concrete
fill 178 290 408 178 291 408 minecraft:white_concrete
fill 178 290 410 178 291 410 minecraft:white_concrete
fill 180 290 370 182 290 370 minecraft:white_concrete
fill 180 290 410 182 290 410 minecraft:white_concrete
setblock 182 290 371 minecraft:white_concrete
setblock 182 290 373 minecraft:white_concrete
fill 182 290 375 182 290 378 minecraft:white_concrete
setblock 182 290 380 minecraft:white_concrete
fill 182 290 382 182 290 385 minecraft:white_concrete
setblock 182 290 387 minecraft:white_concrete
fill 182 290 389 182 290 392 minecraft:white_concrete
setblock 182 290 394 minecraft:white_concrete
fill 182 290 396 182 290 399 minecraft:white_concrete
setblock 182 290 401 minecraft:white_concrete
fill 182 290 403 182 290 406 minecraft:white_concrete
setblock 182 290 408 minecraft:white_concrete
setblock 142 291 372 minecraft:white_concrete
fill 142 291 373 144 291 373 minecraft:gray_concrete
setblock 142 291 379 minecraft:white_concrete
setblock 142 291 386 minecraft:white_concrete
setblock 142 291 393 minecraft:white_concrete
setblock 144 291 372 minecraft:light[level=14]
setblock 144 291 380 minecraft:light[level=14]
setblock 144 291 388 minecraft:light[level=14]
setblock 144 291 396 minecraft:light[level=14]
setblock 147 291 370 minecraft:white_concrete
setblock 152 291 372 minecraft:light[level=14]
setblock 152 291 380 minecraft:light[level=14]
setblock 152 291 388 minecraft:light[level=14]
setblock 152 291 396 minecraft:light[level=14]
setblock 152 291 404 minecraft:light[level=14]
setblock 153 291 410 minecraft:white_concrete
setblock 154 291 370 minecraft:white_concrete
setblock 160 291 372 minecraft:light[level=14]
setblock 160 291 380 minecraft:light[level=14]
setblock 160 291 388 minecraft:light[level=14]
setblock 160 291 396 minecraft:light[level=14]
setblock 160 291 404 minecraft:light[level=14]
setblock 160 291 410 minecraft:white_concrete
setblock 161 291 370 minecraft:white_concrete
setblock 167 291 410 minecraft:white_concrete
setblock 168 291 370 minecraft:white_concrete
setblock 168 291 372 minecraft:light[level=14]
setblock 168 291 380 minecraft:light[level=14]
setblock 168 291 388 minecraft:light[level=14]
setblock 168 291 396 minecraft:light[level=14]
setblock 168 291 404 minecraft:light[level=14]
setblock 170 291 410 minecraft:white_concrete
setblock 175 291 370 minecraft:white_concrete
setblock 176 291 372 minecraft:light[level=14]
setblock 176 291 380 minecraft:light[level=14]
setblock 176 291 388 minecraft:light[level=14]
setblock 176 291 396 minecraft:light[level=14]
setblock 181 291 410 minecraft:white_concrete
setblock 182 291 370 minecraft:white_concrete
setblock 182 291 377 minecraft:white_concrete
setblock 182 291 384 minecraft:white_concrete
setblock 182 291 391 minecraft:white_concrete
setblock 182 291 398 minecraft:white_concrete
setblock 182 291 405 minecraft:white_concrete
setblock 142 292 373 minecraft:white_concrete
setblock 142 292 380 minecraft:white_concrete
setblock 142 292 387 minecraft:white_concrete
setblock 142 292 394 minecraft:white_concrete
setblock 142 292 400 minecraft:jack_o_lantern
setblock 142 292 402 minecraft:jack_o_lantern
setblock 142 292 404 minecraft:jack_o_lantern
setblock 142 292 406 minecraft:jack_o_lantern
setblock 142 292 408 minecraft:jack_o_lantern
setblock 142 292 410 minecraft:jack_o_lantern
fill 143 292 373 144 292 373 minecraft:gray_concrete
setblock 143 292 399 minecraft:jack_o_lantern
setblock 143 292 401 minecraft:jack_o_lantern
setblock 143 292 403 minecraft:jack_o_lantern
setblock 143 292 405 minecraft:jack_o_lantern
setblock 143 292 407 minecraft:jack_o_lantern
setblock 143 292 409 minecraft:jack_o_lantern
setblock 143 292 411 minecraft:jack_o_lantern
setblock 144 292 400 minecraft:jack_o_lantern
setblock 144 292 402 minecraft:jack_o_lantern
setblock 144 292 404 minecraft:jack_o_lantern
setblock 144 292 406 minecraft:jack_o_lantern
setblock 144 292 408 minecraft:jack_o_lantern
setblock 144 292 410 minecraft:jack_o_lantern
setblock 145 292 399 minecraft:jack_o_lantern
setblock 145 292 401 minecraft:jack_o_lantern
setblock 145 292 403 minecraft:jack_o_lantern
setblock 145 292 405 minecraft:jack_o_lantern
setblock 145 292 407 minecraft:jack_o_lantern
setblock 145 292 409 minecraft:jack_o_lantern
setblock 145 292 411 minecraft:jack_o_lantern
setblock 146 292 370 minecraft:white_concrete
setblock 146 292 400 minecraft:jack_o_lantern
setblock 146 292 402 minecraft:jack_o_lantern
setblock 146 292 404 minecraft:jack_o_lantern
setblock 146 292 406 minecraft:jack_o_lantern
setblock 146 292 408 minecraft:jack_o_lantern
setblock 146 292 410 minecraft:jack_o_lantern
setblock 147 292 399 minecraft:jack_o_lantern
setblock 147 292 401 minecraft:jack_o_lantern
schedule function dropper:buildpart/87_5 1t
