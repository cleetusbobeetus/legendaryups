setblock 493 85 464 minecraft:terracotta
fill 493 85 473 493 86 473 minecraft:orange_concrete
setblock 493 85 475 minecraft:orange_concrete
fill 493 85 491 499 85 491 minecraft:orange_concrete
fill 493 85 500 499 85 500 minecraft:orange_concrete
setblock 493 85 504 minecraft:terracotta
fill 494 85 464 494 88 464 minecraft:red_terracotta
setblock 494 85 503 minecraft:terracotta
fill 494 85 504 494 88 504 minecraft:red_terracotta
fill 495 85 492 500 85 492 minecraft:orange_concrete
fill 495 85 499 500 85 499 minecraft:orange_concrete
setblock 495 85 502 minecraft:terracotta
fill 495 85 503 495 88 503 minecraft:red_terracotta
fill 496 85 490 497 85 490 minecraft:orange_concrete
setblock 496 85 501 minecraft:orange_concrete
fill 496 85 502 496 88 502 minecraft:red_terracotta
setblock 497 85 466 minecraft:light[level=14]
setblock 497 85 474 minecraft:light[level=14]
setblock 497 85 482 minecraft:light[level=14]
setblock 497 85 501 minecraft:red_terracotta
setblock 498 85 464 minecraft:terracotta
fill 498 85 493 501 85 493 minecraft:orange_concrete
fill 498 85 498 501 85 498 minecraft:orange_concrete
setblock 498 85 504 minecraft:terracotta
fill 499 85 464 499 88 464 minecraft:red_terracotta
fill 499 85 494 501 85 497 minecraft:orange_concrete
setblock 499 85 503 minecraft:terracotta
fill 499 85 504 499 88 504 minecraft:red_terracotta
setblock 500 85 502 minecraft:terracotta
fill 500 85 503 500 88 503 minecraft:red_terracotta
setblock 501 85 501 minecraft:terracotta
fill 501 85 502 501 88 502 minecraft:red_terracotta
setblock 502 85 501 minecraft:red_terracotta
setblock 503 85 464 minecraft:terracotta
setblock 503 85 504 minecraft:terracotta
setblock 504 85 464 minecraft:red_terracotta
setblock 504 85 503 minecraft:terracotta
fill 504 85 504 504 88 504 minecraft:red_terracotta
setblock 505 85 466 minecraft:light[level=14]
setblock 505 85 474 minecraft:light[level=14]
setblock 505 85 482 minecraft:light[level=14]
setblock 505 85 490 minecraft:light[level=14]
setblock 505 85 498 minecraft:light[level=14]
setblock 505 85 502 minecraft:terracotta
fill 505 85 503 505 87 503 minecraft:red_terracotta
setblock 508 85 504 minecraft:terracotta
setblock 509 85 504 minecraft:red_terracotta
setblock 511 85 481 minecraft:terracotta
fill 511 85 482 511 88 482 minecraft:red_terracotta
setblock 511 85 486 minecraft:terracotta
setblock 511 85 501 minecraft:terracotta
setblock 511 85 502 minecraft:red_terracotta
fill 471 86 476 471 88 476 minecraft:red_terracotta
setblock 471 86 480 minecraft:terracotta
fill 471 86 481 471 88 481 minecraft:red_terracotta
setblock 471 86 485 minecraft:terracotta
fill 471 86 486 471 88 486 minecraft:red_terracotta
setblock 472 86 479 minecraft:terracotta
fill 472 86 480 472 88 480 minecraft:red_terracotta
setblock 472 86 484 minecraft:terracotta
fill 474 86 464 474 88 464 minecraft:red_terracotta
fill 474 86 504 476 86 504 minecraft:red_terracotta
fill 476 86 497 477 86 500 minecraft:orange_concrete
setblock 477 86 464 minecraft:terracotta
fill 477 86 465 477 88 465 minecraft:red_terracotta
fill 477 86 496 478 86 496 minecraft:orange_concrete
fill 477 86 501 482 86 501 minecraft:orange_concrete
setblock 477 86 503 minecraft:red_terracotta
setblock 477 86 504 minecraft:terracotta
fill 478 86 464 478 88 464 minecraft:red_terracotta
fill 478 86 495 482 86 495 minecraft:orange_concrete
fill 478 86 502 481 86 502 minecraft:orange_concrete
setblock 478 86 503 minecraft:terracotta
fill 478 86 504 478 88 504 minecraft:red_terracotta
fill 479 86 503 479 88 503 minecraft:red_terracotta
setblock 481 86 465 minecraft:terracotta
fill 481 86 496 483 86 496 minecraft:orange_concrete
setblock 482 86 464 minecraft:terracotta
fill 482 86 465 482 88 465 minecraft:red_terracotta
fill 482 86 497 483 86 497 minecraft:orange_concrete
fill 482 86 500 483 86 500 minecraft:orange_concrete
setblock 482 86 504 minecraft:terracotta
fill 483 86 464 483 88 464 minecraft:red_terracotta
fill 483 86 498 483 86 499 minecraft:orange_concrete
setblock 483 86 503 minecraft:terracotta
fill 483 86 504 483 88 504 minecraft:red_terracotta
fill 484 86 503 484 88 503 minecraft:red_terracotta
fill 485 86 479 485 86 480 minecraft:orange_concrete
fill 486 86 478 486 87 479 minecraft:orange_concrete
setblock 487 86 464 minecraft:terracotta
fill 487 86 472 487 86 474 minecraft:orange_concrete
fill 487 86 477 488 86 477 minecraft:orange_concrete
setblock 487 86 504 minecraft:terracotta
fill 488 86 464 488 88 464 minecraft:red_terracotta
fill 488 86 471 488 87 472 minecraft:orange_concrete
fill 488 86 474 488 86 475 minecraft:orange_concrete
fill 488 86 504 488 88 504 minecraft:red_terracotta
fill 489 86 470 491 86 470 minecraft:orange_concrete
fill 490 86 476 491 86 476 minecraft:orange_concrete
fill 490 86 478 490 86 480 minecraft:orange_concrete
fill 491 86 471 492 86 471 minecraft:orange_concrete
fill 491 86 475 492 86 475 minecraft:orange_concrete
fill 491 86 503 492 86 503 minecraft:red_terracotta
setblock 492 86 464 minecraft:terracotta
fill 492 86 494 493 86 497 minecraft:orange_concrete
setblock 492 86 504 minecraft:terracotta
fill 493 86 464 493 88 464 minecraft:red_terracotta
fill 493 86 492 494 86 493 minecraft:orange_concrete
fill 493 86 498 494 86 499 minecraft:orange_concrete
setblock 493 86 503 minecraft:terracotta
fill 493 86 504 493 88 504 minecraft:red_terracotta
setblock 494 86 502 minecraft:terracotta
fill 494 86 503 494 88 503 minecraft:red_terracotta
fill 495 86 491 497 86 492 minecraft:orange_concrete
fill 495 86 499 497 86 500 minecraft:orange_concrete
fill 495 86 502 495 88 502 minecraft:red_terracotta
setblock 497 86 464 minecraft:terracotta
setblock 497 86 504 minecraft:terracotta
fill 498 86 464 498 88 465 minecraft:red_terracotta
fill 498 86 492 499 86 493 minecraft:orange_concrete
fill 498 86 498 499 86 499 minecraft:orange_concrete
setblock 498 86 503 minecraft:terracotta
fill 498 86 504 498 88 504 minecraft:red_terracotta
fill 499 86 494 500 86 497 minecraft:orange_concrete
setblock 499 86 502 minecraft:terracotta
fill 499 86 503 499 88 503 minecraft:red_terracotta
setblock 500 86 493 minecraft:orange_concrete
setblock 500 86 498 minecraft:orange_concrete
setblock 500 86 501 minecraft:terracotta
fill 500 86 502 500 88 502 minecraft:red_terracotta
setblock 501 86 501 minecraft:red_terracotta
setblock 502 86 464 minecraft:terracotta
setblock 502 86 504 minecraft:terracotta
fill 503 86 464 503 88 464 minecraft:red_terracotta
setblock 503 86 503 minecraft:terracotta
fill 503 86 504 503 88 504 minecraft:red_terracotta
setblock 504 86 502 minecraft:terracotta
fill 504 86 503 504 88 503 minecraft:red_terracotta
setblock 507 86 504 minecraft:terracotta
setblock 508 86 504 minecraft:red_terracotta
setblock 511 86 480 minecraft:terracotta
fill 511 86 481 511 88 481 minecraft:red_terracotta
setblock 511 86 485 minecraft:terracotta
fill 511 86 486 511 88 487 minecraft:red_terracotta
setblock 471 87 479 minecraft:terracotta
fill 471 87 480 471 88 480 minecraft:red_terracotta
setblock 471 87 484 minecraft:terracotta
fill 471 87 485 471 88 485 minecraft:red_terracotta
setblock 472 87 478 minecraft:terracotta
fill 472 87 479 472 88 479 minecraft:red_terracotta
setblock 472 87 483 minecraft:terracotta
fill 472 87 484 472 88 484 minecraft:red_terracotta
fill 473 87 464 473 88 464 minecraft:red_terracotta
fill 474 87 504 475 87 504 minecraft:red_terracotta
setblock 476 87 464 minecraft:terracotta
fill 476 87 465 476 88 465 minecraft:red_terracotta
setblock 476 87 504 minecraft:terracotta
fill 477 87 464 477 88 464 minecraft:red_terracotta
fill 477 87 497 477 87 500 minecraft:orange_concrete
setblock 477 87 503 minecraft:terracotta
fill 477 87 504 477 88 504 minecraft:red_terracotta
setblock 478 87 496 minecraft:orange_concrete
fill 478 87 501 481 87 501 minecraft:orange_concrete
fill 478 87 503 478 88 503 minecraft:red_terracotta
setblock 480 87 465 minecraft:terracotta
setblock 480 87 495 minecraft:orange_concrete
setblock 481 87 464 minecraft:terracotta
fill 481 87 465 481 88 465 minecraft:red_terracotta
fill 481 87 496 482 87 496 minecraft:orange_concrete
setblock 481 87 504 minecraft:terracotta
fill 482 87 464 482 88 464 minecraft:red_terracotta
setblock 482 87 497 minecraft:orange_concrete
setblock 482 87 500 minecraft:orange_concrete
setblock 482 87 503 minecraft:terracotta
fill 482 87 504 482 88 504 minecraft:red_terracotta
setblock 483 87 498 minecraft:orange_concrete
fill 483 87 503 483 88 503 minecraft:red_terracotta
setblock 486 87 464 minecraft:terracotta
setblock 486 87 504 minecraft:terracotta
fill 487 87 464 487 88 464 minecraft:red_terracotta
fill 487 87 504 487 88 504 minecraft:red_terracotta
setblock 488 87 474 minecraft:orange_concrete
setblock 488 87 477 minecraft:orange_concrete
setblock 489 87 475 minecraft:orange_concrete
fill 490 87 479 490 87 480 minecraft:orange_concrete
setblock 491 87 464 minecraft:terracotta
setblock 491 87 471 minecraft:orange_concrete
setblock 491 87 475 minecraft:orange_concrete
setblock 491 87 503 minecraft:red_terracotta
setblock 491 87 504 minecraft:terracotta
fill 492 87 464 492 88 464 minecraft:red_terracotta
setblock 492 87 472 minecraft:orange_concrete
setblock 492 87 474 minecraft:orange_concrete
setblock 492 87 503 minecraft:terracotta
fill 492 87 504 492 88 504 minecraft:red_terracotta
fill 493 87 494 493 87 497 minecraft:orange_concrete
fill 493 87 503 493 88 503 minecraft:red_terracotta
setblock 494 87 493 minecraft:orange_concrete
setblock 494 87 498 minecraft:orange_concrete
fill 494 87 502 494 88 502 minecraft:red_terracotta
fill 495 87 492 497 87 492 minecraft:orange_concrete
fill 495 87 499 497 87 499 minecraft:orange_concrete
setblock 496 87 464 minecraft:terracotta
fill 496 87 465 497 88 465 minecraft:red_terracotta
setblock 496 87 504 minecraft:terracotta
fill 497 87 464 497 88 464 minecraft:red_terracotta
setblock 497 87 503 minecraft:terracotta
fill 497 87 504 497 88 504 minecraft:red_terracotta
setblock 498 87 493 minecraft:orange_concrete
setblock 498 87 498 minecraft:orange_concrete
setblock 498 87 502 minecraft:terracotta
fill 498 87 503 498 88 503 minecraft:red_terracotta
setblock 499 87 465 minecraft:red_terracotta
fill 499 87 494 499 87 497 minecraft:orange_concrete
setblock 499 87 501 minecraft:terracotta
fill 499 87 502 499 88 502 minecraft:red_terracotta
setblock 501 87 464 minecraft:terracotta
setblock 501 87 504 minecraft:terracotta
fill 502 87 464 502 88 464 minecraft:red_terracotta
setblock 502 87 503 minecraft:terracotta
fill 502 87 504 502 88 504 minecraft:red_terracotta
setblock 503 87 502 minecraft:terracotta
fill 503 87 503 503 88 503 minecraft:red_terracotta
setblock 506 87 504 minecraft:terracotta
fill 507 87 504 507 88 504 minecraft:red_terracotta
setblock 511 87 479 minecraft:terracotta
fill 511 87 480 511 88 480 minecraft:red_terracotta
setblock 511 87 484 minecraft:terracotta
fill 511 87 485 511 88 485 minecraft:red_terracotta
setblock 471 88 478 minecraft:terracotta
setblock 471 88 479 minecraft:red_terracotta
setblock 471 88 483 minecraft:terracotta
setblock 471 88 484 minecraft:red_terracotta
setblock 471 88 487 minecraft:red_terracotta
setblock 472 88 464 minecraft:red_terracotta
setblock 472 88 478 minecraft:red_terracotta
setblock 472 88 482 minecraft:terracotta
setblock 472 88 483 minecraft:red_terracotta
setblock 472 88 485 minecraft:red_terracotta
fill 473 88 504 474 88 504 minecraft:red_terracotta
setblock 474 88 465 minecraft:terracotta
setblock 475 88 464 minecraft:terracotta
setblock 475 88 465 minecraft:red_terracotta
setblock 475 88 504 minecraft:terracotta
setblock 476 88 464 minecraft:red_terracotta
setblock 476 88 503 minecraft:terracotta
setblock 476 88 504 minecraft:red_terracotta
setblock 477 88 503 minecraft:red_terracotta
setblock 478 88 466 minecraft:terracotta
setblock 479 88 465 minecraft:terracotta
fill 479 88 466 480 88 466 minecraft:red_terracotta
setblock 480 88 464 minecraft:terracotta
setblock 480 88 465 minecraft:red_terracotta
setblock 480 88 504 minecraft:terracotta
setblock 481 88 464 minecraft:red_terracotta
setblock 481 88 503 minecraft:terracotta
setblock 481 88 504 minecraft:red_terracotta
setblock 482 88 503 minecraft:red_terracotta
setblock 484 88 465 minecraft:terracotta
setblock 485 88 464 minecraft:terracotta
setblock 485 88 504 minecraft:terracotta
setblock 486 88 464 minecraft:red_terracotta
setblock 486 88 504 minecraft:red_terracotta
setblock 490 88 464 minecraft:terracotta
setblock 490 88 503 minecraft:red_terracotta
setblock 490 88 504 minecraft:terracotta
setblock 491 88 464 minecraft:red_terracotta
setblock 491 88 503 minecraft:terracotta
setblock 491 88 504 minecraft:red_terracotta
setblock 492 88 503 minecraft:red_terracotta
setblock 494 88 465 minecraft:terracotta
setblock 495 88 464 minecraft:terracotta
setblock 495 88 465 minecraft:red_terracotta
setblock 495 88 504 minecraft:terracotta
setblock 496 88 464 minecraft:red_terracotta
setblock 496 88 503 minecraft:terracotta
setblock 496 88 504 minecraft:red_terracotta
setblock 497 88 502 minecraft:terracotta
setblock 497 88 503 minecraft:red_terracotta
setblock 498 88 502 minecraft:red_terracotta
setblock 499 88 465 minecraft:terracotta
setblock 500 88 464 minecraft:terracotta
setblock 500 88 504 minecraft:terracotta
setblock 501 88 464 minecraft:red_terracotta
setblock 501 88 503 minecraft:terracotta
setblock 501 88 504 minecraft:red_terracotta
setblock 502 88 502 minecraft:terracotta
setblock 502 88 503 minecraft:red_terracotta
setblock 505 88 504 minecraft:terracotta
setblock 506 88 504 minecraft:red_terracotta
setblock 510 88 483 minecraft:red_terracotta
setblock 510 88 484 minecraft:terracotta
setblock 511 88 478 minecraft:terracotta
setblock 511 88 479 minecraft:red_terracotta
setblock 511 88 483 minecraft:terracotta
setblock 511 88 484 minecraft:red_terracotta
setblock 511 88 488 minecraft:terracotta
setblock 473 93 466 minecraft:light[level=14]
setblock 473 93 474 minecraft:light[level=14]
setblock 473 93 482 minecraft:light[level=14]
setblock 473 93 490 minecraft:light[level=14]
setblock 473 93 498 minecraft:light[level=14]
setblock 481 93 466 minecraft:light[level=14]
setblock 481 93 474 minecraft:light[level=14]
setblock 481 93 482 minecraft:light[level=14]
setblock 481 93 490 minecraft:light[level=14]
setblock 481 93 498 minecraft:light[level=14]
fill 483 93 478 485 93 480 minecraft:redstone_block
fill 488 93 486 490 93 488 minecraft:redstone_block
setblock 489 93 466 minecraft:light[level=14]
setblock 489 93 474 minecraft:light[level=14]
setblock 489 93 490 minecraft:light[level=14]
setblock 489 93 498 minecraft:light[level=14]
fill 490 93 477 492 93 479 minecraft:redstone_block
setblock 497 93 466 minecraft:light[level=14]
setblock 497 93 474 minecraft:light[level=14]
setblock 497 93 482 minecraft:light[level=14]
setblock 497 93 490 minecraft:light[level=14]
setblock 497 93 498 minecraft:light[level=14]
setblock 505 93 466 minecraft:light[level=14]
setblock 505 93 474 minecraft:light[level=14]
setblock 505 93 482 minecraft:light[level=14]
setblock 505 93 490 minecraft:light[level=14]
setblock 505 93 498 minecraft:light[level=14]
fill 471 94 464 471 95 471 minecraft:basalt
fill 471 94 472 471 95 472 minecraft:magma_block
fill 471 94 473 471 95 476 minecraft:basalt
fill 471 94 477 471 95 477 minecraft:magma_block
fill 471 94 478 474 95 481 minecraft:basalt
fill 471 94 482 471 95 482 minecraft:magma_block
fill 471 94 483 471 95 497 minecraft:basalt
fill 471 94 498 471 95 498 minecraft:magma_block
fill 471 94 499 474 95 502 minecraft:basalt
fill 471 94 503 471 95 503 minecraft:magma_block
fill 471 94 504 475 95 504 minecraft:basalt
fill 472 94 464 472 95 470 minecraft:basalt
fill 472 94 471 472 95 471 minecraft:magma_block
fill 472 94 472 472 95 475 minecraft:basalt
fill 472 94 476 472 95 476 minecraft:magma_block
fill 472 94 477 476 95 477 minecraft:basalt
fill 472 94 482 472 95 491 minecraft:basalt
fill 472 94 492 472 95 492 minecraft:magma_block
fill 472 94 493 472 95 496 minecraft:basalt
fill 472 94 497 472 95 497 minecraft:magma_block
fill 472 94 498 476 95 498 minecraft:basalt
fill 472 94 503 483 95 503 minecraft:basalt
fill 473 94 464 473 95 464 minecraft:basalt
fill 473 94 465 473 95 465 minecraft:magma_block
fill 473 94 466 473 95 469 minecraft:basalt
fill 473 94 470 473 95 470 minecraft:magma_block
fill 473 94 471 475 95 474 minecraft:basalt
fill 473 94 475 473 95 475 minecraft:magma_block
fill 473 94 476 484 95 476 minecraft:basalt
fill 473 94 482 473 95 485 minecraft:basalt
fill 473 94 486 473 95 486 minecraft:magma_block
fill 473 94 487 473 95 490 minecraft:basalt
fill 473 94 491 473 95 491 minecraft:magma_block
fill 473 94 492 475 95 495 minecraft:basalt
fill 473 94 496 473 95 496 minecraft:magma_block
fill 473 94 497 484 95 497 minecraft:basalt
fill 474 94 464 474 95 464 minecraft:magma_block
fill 474 94 465 476 95 468 minecraft:basalt
fill 474 94 469 474 95 469 minecraft:magma_block
fill 474 94 470 478 95 470 minecraft:basalt
fill 474 94 475 485 95 475 minecraft:basalt
fill 474 94 482 474 95 484 minecraft:basalt
fill 474 94 485 474 95 485 minecraft:magma_block
fill 474 94 486 477 95 489 minecraft:basalt
fill 474 94 490 474 95 490 minecraft:magma_block
fill 474 94 491 478 95 491 minecraft:basalt
fill 474 94 496 485 95 496 minecraft:basalt
fill 475 94 464 479 95 464 minecraft:basalt
fill 475 94 469 486 95 469 minecraft:basalt
fill 475 94 478 475 95 478 minecraft:basalt
fill 475 94 479 475 95 479 minecraft:magma_block
fill 475 94 480 475 95 483 minecraft:basalt
fill 475 94 484 475 95 484 minecraft:magma_block
fill 475 94 485 479 95 485 minecraft:basalt
fill 475 94 490 486 95 490 minecraft:basalt
fill 475 94 499 475 95 499 minecraft:basalt
fill 475 94 500 475 95 500 minecraft:magma_block
fill 475 94 501 478 95 502 minecraft:basalt
fill 476 94 471 476 95 472 minecraft:basalt
fill 476 94 473 476 95 473 minecraft:magma_block
fill 476 94 474 480 95 474 minecraft:basalt
fill 476 94 478 476 95 478 minecraft:magma_block
fill 476 94 479 478 95 482 minecraft:basalt
fill 476 94 483 476 95 483 minecraft:magma_block
fill 476 94 484 487 94 484 minecraft:basalt
fill 476 94 492 476 95 493 minecraft:basalt
fill 476 94 494 476 95 494 minecraft:magma_block
fill 476 94 495 480 95 495 minecraft:basalt
fill 476 94 499 476 95 499 minecraft:magma_block
fill 476 94 500 480 95 500 minecraft:basalt
fill 476 94 504 476 95 504 minecraft:magma_block
fill 477 94 465 477 95 466 minecraft:basalt
fill 477 94 467 477 95 467 minecraft:magma_block
fill 477 94 468 481 95 468 minecraft:basalt
fill 477 94 471 477 95 471 minecraft:basalt
fill 477 94 472 477 95 472 minecraft:magma_block
fill 477 94 473 481 95 473 minecraft:basalt
fill 477 94 477 477 95 477 minecraft:magma_block
fill 477 94 478 481 95 478 minecraft:basalt
fill 477 94 483 486 94 483 minecraft:basalt
fill 477 94 492 477 95 492 minecraft:basalt
fill 477 94 493 477 95 493 minecraft:magma_block
fill 477 94 494 481 95 494 minecraft:basalt
fill 477 94 498 477 95 498 minecraft:magma_block
fill 477 94 499 481 95 499 minecraft:basalt
fill 477 94 504 488 95 504 minecraft:basalt
fill 478 94 465 478 95 465 minecraft:basalt
fill 478 94 466 478 95 466 minecraft:magma_block
fill 478 94 467 482 95 467 minecraft:basalt
fill 478 94 471 478 95 471 minecraft:magma_block
fill 478 94 472 482 95 472 minecraft:basalt
fill 478 94 477 489 94 477 minecraft:basalt
fill 478 94 486 478 95 486 minecraft:basalt
fill 478 94 487 478 95 487 minecraft:magma_block
fill 478 94 488 481 95 489 minecraft:basalt
fill 478 94 492 478 95 492 minecraft:magma_block
fill 478 94 493 482 95 493 minecraft:basalt
fill 478 94 498 489 95 498 minecraft:basalt
fill 479 94 465 479 95 465 minecraft:magma_block
fill 479 94 466 483 95 466 minecraft:basalt
fill 479 94 470 479 95 470 minecraft:magma_block
fill 479 94 471 490 95 471 minecraft:basalt
fill 479 94 479 479 95 480 minecraft:basalt
fill 479 94 481 479 95 481 minecraft:magma_block
fill 479 94 482 483 95 482 minecraft:basalt
fill 479 94 486 479 95 486 minecraft:magma_block
fill 479 94 487 483 95 487 minecraft:basalt
fill 479 94 491 479 95 491 minecraft:magma_block
fill 479 94 492 490 95 492 minecraft:basalt
fill 479 94 501 479 95 501 minecraft:basalt
fill 479 94 502 479 95 502 minecraft:magma_block
fill 480 94 464 480 95 464 minecraft:magma_block
fill 480 94 465 484 95 465 minecraft:basalt
fill 480 94 470 491 95 470 minecraft:basalt
fill 480 94 479 480 95 479 minecraft:basalt
fill 480 94 480 480 95 480 minecraft:magma_block
fill 480 94 481 484 94 481 minecraft:basalt
fill 480 94 485 480 95 485 minecraft:magma_block
fill 480 94 486 484 95 486 minecraft:basalt
fill 480 94 491 491 95 491 minecraft:basalt
fill 480 94 501 480 95 501 minecraft:magma_block
fill 480 94 502 484 95 502 minecraft:basalt
fill 481 94 464 492 95 464 minecraft:basalt
fill 481 94 474 481 95 474 minecraft:magma_block
fill 481 94 479 481 95 479 minecraft:magma_block
fill 481 94 480 482 94 480 minecraft:basalt
fill 481 94 485 492 94 485 minecraft:basalt
fill 481 94 495 481 95 495 minecraft:magma_block
fill 481 94 500 481 95 500 minecraft:magma_block
fill 481 94 501 485 95 501 minecraft:basalt
fill 482 94 468 482 95 468 minecraft:magma_block
fill 482 94 473 482 95 473 minecraft:magma_block
fill 482 94 474 486 95 474 minecraft:basalt
setblock 482 94 478 minecraft:magma_block
setblock 482 94 479 minecraft:basalt
fill 482 94 488 482 95 488 minecraft:basalt
fill 482 94 489 482 95 489 minecraft:magma_block
fill 482 94 494 482 95 494 minecraft:magma_block
fill 482 94 495 486 95 495 minecraft:basalt
fill 482 94 499 482 95 499 minecraft:magma_block
fill 482 94 500 486 95 500 minecraft:basalt
fill 483 94 467 483 95 467 minecraft:magma_block
fill 483 94 468 487 95 468 minecraft:basalt
fill 483 94 472 483 95 472 minecraft:magma_block
fill 483 94 473 487 95 473 minecraft:basalt
fill 483 94 488 483 95 488 minecraft:magma_block
fill 483 94 489 487 94 489 minecraft:basalt
fill 483 94 493 483 95 493 minecraft:magma_block
fill 483 94 494 487 95 494 minecraft:basalt
fill 483 94 499 494 95 499 minecraft:basalt
fill 484 94 466 484 95 466 minecraft:magma_block
fill 484 94 467 488 95 467 minecraft:basalt
fill 484 94 472 495 95 472 minecraft:basalt
fill 484 94 482 484 95 482 minecraft:magma_block
fill 484 94 487 484 95 487 minecraft:magma_block
fill 484 94 488 487 94 488 minecraft:basalt
fill 484 94 493 495 95 493 minecraft:basalt
fill 484 94 503 484 95 503 minecraft:magma_block
fill 485 94 465 485 95 465 minecraft:magma_block
fill 485 94 466 496 95 466 minecraft:basalt
fill 485 94 476 485 95 476 minecraft:magma_block
setblock 485 94 481 minecraft:magma_block
fill 485 94 482 486 94 482 minecraft:basalt
fill 485 94 486 485 95 486 minecraft:magma_block
fill 485 94 487 487 94 487 minecraft:basalt
fill 485 94 497 485 95 497 minecraft:magma_block
fill 485 94 502 485 95 502 minecraft:magma_block
fill 485 94 503 489 95 503 minecraft:basalt
fill 486 94 465 497 95 465 minecraft:basalt
fill 486 94 475 486 95 475 minecraft:magma_block
fill 486 94 476 490 94 476 minecraft:basalt
fill 486 94 478 489 94 479 minecraft:basalt
setblock 486 94 480 minecraft:magma_block
setblock 486 94 481 minecraft:basalt
fill 486 94 486 487 94 486 minecraft:basalt
fill 486 94 496 486 95 496 minecraft:magma_block
fill 486 94 497 490 95 497 minecraft:basalt
fill 486 94 501 486 95 501 minecraft:magma_block
fill 486 94 502 490 95 502 minecraft:basalt
fill 487 94 469 487 95 469 minecraft:magma_block
fill 487 94 474 487 95 474 minecraft:magma_block
fill 487 94 475 491 95 475 minecraft:basalt
fill 487 94 480 498 94 480 minecraft:basalt
fill 487 94 490 487 95 490 minecraft:magma_block
fill 487 94 495 487 95 495 minecraft:magma_block
fill 487 94 496 491 95 496 minecraft:basalt
fill 487 94 500 487 95 500 minecraft:magma_block
fill 487 94 501 498 95 501 minecraft:basalt
fill 488 94 468 488 95 468 minecraft:magma_block
fill 488 94 469 492 95 469 minecraft:basalt
fill 488 94 473 488 95 473 minecraft:magma_block
fill 488 94 474 499 95 474 minecraft:basalt
setblock 488 94 484 minecraft:magma_block
setblock 488 94 489 minecraft:magma_block
fill 488 94 490 492 95 490 minecraft:basalt
fill 488 94 494 488 95 494 minecraft:magma_block
fill 488 94 495 492 95 495 minecraft:basalt
fill 488 94 500 499 95 500 minecraft:basalt
fill 489 94 467 489 95 467 minecraft:magma_block
fill 489 94 468 493 95 468 minecraft:basalt
fill 489 94 473 500 95 473 minecraft:basalt
fill 489 94 484 493 94 484 minecraft:basalt
fill 489 94 489 493 94 489 minecraft:basalt
fill 489 94 494 500 95 494 minecraft:basalt
fill 489 94 504 489 95 504 minecraft:magma_block
fill 490 94 467 501 95 467 minecraft:basalt
setblock 490 94 481 minecraft:basalt
setblock 490 94 482 minecraft:magma_block
fill 490 94 483 494 94 483 minecraft:basalt
fill 490 94 498 490 95 498 minecraft:magma_block
fill 490 94 503 490 95 503 minecraft:magma_block
fill 490 94 504 494 95 504 minecraft:basalt
fill 491 94 471 491 95 471 minecraft:magma_block
setblock 491 94 476 minecraft:magma_block
fill 491 94 481 491 95 481 minecraft:magma_block
fill 491 94 482 502 95 482 minecraft:basalt
fill 491 94 486 496 94 488 minecraft:basalt
fill 491 94 492 491 95 492 minecraft:magma_block
fill 491 94 497 491 95 497 minecraft:magma_block
fill 491 94 498 495 95 498 minecraft:basalt
fill 491 94 502 491 95 502 minecraft:magma_block
fill 491 94 503 495 95 503 minecraft:basalt
fill 492 94 470 492 95 470 minecraft:magma_block
fill 492 94 471 496 95 471 minecraft:basalt
fill 492 94 475 492 95 475 minecraft:magma_block
fill 492 94 476 496 94 476 minecraft:basalt
fill 492 94 481 503 95 481 minecraft:basalt
fill 492 94 491 492 95 491 minecraft:magma_block
fill 492 94 492 496 95 492 minecraft:basalt
fill 492 94 496 492 95 496 minecraft:magma_block
fill 492 94 497 496 95 497 minecraft:basalt
fill 492 94 502 503 95 502 minecraft:basalt
fill 493 94 464 493 95 464 minecraft:magma_block
fill 493 94 469 493 95 469 minecraft:magma_block
fill 493 94 470 497 95 470 minecraft:basalt
fill 493 94 475 504 95 475 minecraft:basalt
fill 493 94 477 493 94 479 minecraft:basalt
fill 493 94 485 493 95 485 minecraft:magma_block
fill 493 94 490 493 95 490 minecraft:magma_block
fill 493 94 491 497 95 491 minecraft:basalt
fill 493 94 495 493 95 495 minecraft:magma_block
fill 493 94 496 504 95 496 minecraft:basalt
fill 494 94 464 498 95 464 minecraft:basalt
fill 494 94 468 494 95 468 minecraft:magma_block
fill 494 94 469 505 95 469 minecraft:basalt
fill 494 94 477 494 95 478 minecraft:basalt
fill 494 94 479 494 95 479 minecraft:magma_block
fill 494 94 484 494 95 484 minecraft:magma_block
fill 494 94 485 498 95 485 minecraft:basalt
fill 494 94 489 494 95 489 minecraft:magma_block
fill 494 94 490 498 95 490 minecraft:basalt
fill 494 94 495 505 95 495 minecraft:basalt
fill 495 94 468 506 95 468 minecraft:basalt
fill 495 94 477 495 95 477 minecraft:basalt
fill 495 94 478 495 95 478 minecraft:magma_block
fill 495 94 479 499 95 479 minecraft:basalt
fill 495 94 483 495 95 483 minecraft:magma_block
fill 495 94 484 499 95 484 minecraft:basalt
fill 495 94 489 506 95 489 minecraft:basalt
fill 495 94 499 495 95 499 minecraft:magma_block
fill 495 94 504 495 95 504 minecraft:magma_block
fill 496 94 472 496 95 472 minecraft:magma_block
fill 496 94 477 496 95 477 minecraft:magma_block
fill 496 94 478 500 95 478 minecraft:basalt
fill 496 94 483 507 95 483 minecraft:basalt
fill 496 94 493 496 95 493 minecraft:magma_block
fill 496 94 498 496 95 498 minecraft:magma_block
fill 496 94 499 500 95 499 minecraft:basalt
fill 496 94 503 496 95 503 minecraft:magma_block
fill 496 94 504 507 95 504 minecraft:basalt
fill 497 94 466 497 95 466 minecraft:magma_block
fill 497 94 471 497 95 471 minecraft:magma_block
fill 497 94 472 501 95 472 minecraft:basalt
fill 497 94 476 497 95 476 minecraft:magma_block
fill 497 94 477 508 95 477 minecraft:basalt
fill 497 94 486 497 95 486 minecraft:basalt
fill 497 94 487 497 95 487 minecraft:magma_block
fill 497 94 488 501 95 488 minecraft:basalt
fill 497 94 492 497 95 492 minecraft:magma_block
fill 497 94 493 501 95 493 minecraft:basalt
fill 497 94 497 497 95 497 minecraft:magma_block
fill 497 94 498 501 95 498 minecraft:basalt
fill 497 94 503 508 95 503 minecraft:basalt
fill 498 94 465 498 95 465 minecraft:magma_block
fill 498 94 466 502 95 466 minecraft:basalt
fill 498 94 470 498 95 470 minecraft:magma_block
fill 498 94 471 502 95 471 minecraft:basalt
fill 498 94 476 509 95 476 minecraft:basalt
fill 498 94 486 498 95 486 minecraft:magma_block
fill 498 94 487 502 95 487 minecraft:basalt
fill 498 94 491 498 95 491 minecraft:magma_block
fill 498 94 492 502 95 492 minecraft:basalt
fill 498 94 497 509 95 497 minecraft:basalt
fill 499 94 464 499 95 464 minecraft:magma_block
fill 499 94 465 503 95 465 minecraft:basalt
fill 499 94 470 510 95 470 minecraft:basalt
fill 499 94 480 499 95 480 minecraft:magma_block
fill 499 94 485 499 95 485 minecraft:magma_block
fill 499 94 486 503 95 486 minecraft:basalt
fill 499 94 490 499 95 490 minecraft:magma_block
fill 499 94 491 510 95 491 minecraft:basalt
fill 499 94 501 499 95 501 minecraft:magma_block
fill 500 94 464 511 95 464 minecraft:basalt
fill 500 94 474 500 95 474 minecraft:magma_block
fill 500 94 479 500 95 479 minecraft:magma_block
fill 500 94 480 504 95 480 minecraft:basalt
fill 500 94 484 500 95 484 minecraft:magma_block
fill 500 94 485 504 95 485 minecraft:basalt
fill 500 94 490 511 95 490 minecraft:basalt
fill 500 94 500 500 95 500 minecraft:magma_block
fill 500 94 501 504 95 501 minecraft:basalt
fill 501 94 473 501 95 473 minecraft:magma_block
fill 501 94 474 505 95 474 minecraft:basalt
fill 501 94 478 501 95 478 minecraft:magma_block
fill 501 94 479 505 95 479 minecraft:basalt
fill 501 94 484 511 95 484 minecraft:basalt
fill 501 94 494 501 95 494 minecraft:magma_block
fill 501 94 499 501 95 499 minecraft:magma_block
fill 501 94 500 505 95 500 minecraft:basalt
fill 502 94 467 502 95 467 minecraft:magma_block
fill 502 94 472 502 95 472 minecraft:magma_block
fill 502 94 473 506 95 473 minecraft:basalt
fill 502 94 478 511 95 478 minecraft:basalt
fill 502 94 488 502 95 488 minecraft:magma_block
fill 502 94 493 502 95 493 minecraft:magma_block
fill 502 94 494 506 95 494 minecraft:basalt
fill 502 94 498 502 95 498 minecraft:magma_block
fill 502 94 499 511 95 499 minecraft:basalt
fill 503 94 466 503 95 466 minecraft:magma_block
fill 503 94 467 507 95 467 minecraft:basalt
fill 503 94 471 503 95 471 minecraft:magma_block
fill 503 94 472 511 95 472 minecraft:basalt
fill 503 94 482 503 95 482 minecraft:magma_block
fill 503 94 487 503 95 487 minecraft:magma_block
fill 503 94 488 507 95 488 minecraft:basalt
fill 503 94 492 503 95 492 minecraft:magma_block
fill 503 94 493 507 95 493 minecraft:basalt
fill 503 94 498 511 95 498 minecraft:basalt
fill 504 94 465 504 95 465 minecraft:magma_block
fill 504 94 466 508 95 466 minecraft:basalt
fill 504 94 471 511 95 471 minecraft:basalt
fill 504 94 481 504 95 481 minecraft:magma_block
fill 504 94 482 508 95 482 minecraft:basalt
fill 504 94 486 504 95 486 minecraft:magma_block
fill 504 94 487 508 95 487 minecraft:basalt
fill 504 94 492 511 95 492 minecraft:basalt
fill 504 94 502 504 95 502 minecraft:magma_block
fill 505 94 465 511 95 465 minecraft:basalt
fill 505 94 475 505 95 475 minecraft:magma_block
fill 505 94 480 505 95 480 minecraft:magma_block
fill 505 94 481 509 95 481 minecraft:basalt
fill 505 94 485 505 95 485 minecraft:magma_block
fill 505 94 486 511 95 486 minecraft:basalt
fill 505 94 496 505 95 496 minecraft:magma_block
fill 505 94 501 505 95 501 minecraft:magma_block
fill 505 94 502 509 95 502 minecraft:basalt
fill 506 94 469 506 95 469 minecraft:magma_block
fill 506 94 474 506 95 474 minecraft:magma_block
fill 506 94 475 510 95 475 minecraft:basalt
fill 506 94 479 506 95 479 minecraft:magma_block
fill 506 94 480 510 95 480 minecraft:basalt
fill 506 94 485 511 95 485 minecraft:basalt
fill 506 94 495 506 95 495 minecraft:magma_block
fill 506 94 496 510 95 496 minecraft:basalt
fill 506 94 500 506 95 500 minecraft:magma_block
fill 506 94 501 510 95 501 minecraft:basalt
fill 507 94 468 507 95 468 minecraft:magma_block
fill 507 94 469 511 95 469 minecraft:basalt
fill 507 94 473 507 95 473 minecraft:magma_block
fill 507 94 474 511 95 474 minecraft:basalt
fill 507 94 479 511 95 479 minecraft:basalt
fill 507 94 489 507 95 489 minecraft:magma_block
fill 507 94 494 507 95 494 minecraft:magma_block
fill 507 94 495 511 95 495 minecraft:basalt
fill 507 94 500 511 95 500 minecraft:basalt
fill 508 94 467 508 95 467 minecraft:magma_block
fill 508 94 468 511 95 468 minecraft:basalt
fill 508 94 473 511 95 473 minecraft:basalt
fill 508 94 483 508 95 483 minecraft:magma_block
fill 508 94 488 508 95 488 minecraft:magma_block
fill 508 94 489 511 95 489 minecraft:basalt
fill 508 94 493 508 95 493 minecraft:magma_block
fill 508 94 494 511 95 494 minecraft:basalt
fill 508 94 504 508 95 504 minecraft:magma_block
fill 509 94 466 509 95 466 minecraft:magma_block
fill 509 94 467 511 95 467 minecraft:basalt
fill 509 94 477 509 95 477 minecraft:magma_block
fill 509 94 482 509 95 482 minecraft:magma_block
fill 509 94 483 511 95 483 minecraft:basalt
fill 509 94 487 509 95 487 minecraft:magma_block
fill 509 94 488 511 95 488 minecraft:basalt
fill 509 94 493 511 95 493 minecraft:basalt
fill 509 94 503 509 95 503 minecraft:magma_block
fill 509 94 504 511 95 504 minecraft:basalt
fill 510 94 466 511 95 466 minecraft:basalt
fill 510 94 476 510 95 476 minecraft:magma_block
fill 510 94 477 511 95 477 minecraft:basalt
fill 510 94 481 510 95 481 minecraft:magma_block
fill 510 94 482 511 95 482 minecraft:basalt
fill 510 94 487 511 95 487 minecraft:basalt
fill 510 94 497 510 95 497 minecraft:magma_block
fill 510 94 502 510 95 502 minecraft:magma_block
fill 510 94 503 511 95 503 minecraft:basalt
fill 511 94 470 511 95 470 minecraft:magma_block
fill 511 94 475 511 95 475 minecraft:magma_block
fill 511 94 476 511 95 476 minecraft:basalt
fill 511 94 480 511 95 480 minecraft:magma_block
fill 511 94 481 511 95 481 minecraft:basalt
fill 511 94 491 511 95 491 minecraft:magma_block
fill 511 94 496 511 95 496 minecraft:magma_block
fill 511 94 497 511 95 497 minecraft:basalt
fill 511 94 501 511 95 501 minecraft:magma_block
fill 511 94 502 511 95 502 minecraft:basalt
fill 476 95 484 485 95 484 minecraft:basalt
fill 477 95 483 485 95 483 minecraft:basalt
fill 478 95 477 481 95 477 minecraft:basalt
fill 480 95 481 481 95 481 minecraft:basalt
setblock 481 95 480 minecraft:basalt
fill 481 95 485 486 95 485 minecraft:basalt
fill 482 95 477 482 95 481 minecraft:shroomlight
fill 483 95 477 486 95 477 minecraft:shroomlight
fill 483 95 478 485 95 480 minecraft:basalt
fill 483 95 481 486 95 481 minecraft:shroomlight
fill 483 95 489 486 95 489 minecraft:basalt
fill 484 95 488 486 95 488 minecraft:basalt
setblock 485 95 482 minecraft:basalt
fill 485 95 487 486 95 487 minecraft:basalt
fill 486 95 476 488 95 476 minecraft:basalt
fill 486 95 478 486 95 480 minecraft:shroomlight
fill 486 95 482 486 95 484 minecraft:shroomlight
setblock 486 95 486 minecraft:basalt
fill 487 95 477 488 95 479 minecraft:basalt
fill 487 95 480 493 95 480 minecraft:shroomlight
fill 487 95 484 487 95 489 minecraft:shroomlight
fill 488 95 484 490 95 485 minecraft:shroomlight
fill 488 95 486 490 95 488 minecraft:basalt
fill 488 95 489 491 95 489 minecraft:shroomlight
fill 489 95 476 489 95 479 minecraft:shroomlight
fill 490 95 476 493 95 476 minecraft:shroomlight
fill 490 95 477 492 95 479 minecraft:basalt
fill 490 95 481 490 95 483 minecraft:shroomlight
fill 491 95 483 493 95 484 minecraft:basalt
fill 491 95 485 491 95 488 minecraft:shroomlight
fill 492 95 485 492 95 489 minecraft:basalt
fill 493 95 477 493 95 479 minecraft:shroomlight
fill 493 95 486 493 95 489 minecraft:basalt
fill 494 95 476 496 95 476 minecraft:basalt
fill 494 95 480 498 95 480 minecraft:basalt
setblock 494 95 483 minecraft:basalt
fill 494 95 486 496 95 488 minecraft:basalt
fill 471 99 464 471 99 466 minecraft:red_terracotta
setblock 471 99 467 minecraft:terracotta
fill 471 99 468 471 99 471 minecraft:red_terracotta
setblock 471 99 472 minecraft:terracotta
fill 471 99 473 471 99 476 minecraft:red_terracotta
setblock 471 99 477 minecraft:terracotta
fill 471 99 478 471 99 481 minecraft:red_terracotta
setblock 471 99 482 minecraft:terracotta
fill 471 99 483 471 99 486 minecraft:red_terracotta
setblock 471 99 487 minecraft:terracotta
fill 471 99 488 471 99 491 minecraft:red_terracotta
setblock 471 99 492 minecraft:terracotta
fill 471 99 493 471 99 496 minecraft:red_terracotta
setblock 471 99 497 minecraft:terracotta
fill 471 99 504 473 99 504 minecraft:red_terracotta
fill 472 99 464 472 99 465 minecraft:red_terracotta
setblock 472 99 466 minecraft:terracotta
fill 472 99 467 472 99 470 minecraft:red_terracotta
setblock 472 99 471 minecraft:terracotta
fill 472 99 472 472 99 475 minecraft:red_terracotta
setblock 472 99 476 minecraft:terracotta
fill 472 99 477 472 99 478 minecraft:red_terracotta
setblock 472 99 485 minecraft:red_terracotta
setblock 472 99 486 minecraft:terracotta
fill 472 99 487 472 99 490 minecraft:red_terracotta
setblock 472 99 491 minecraft:terracotta
fill 472 99 492 472 101 493 minecraft:red_terracotta
setblock 473 99 464 minecraft:red_terracotta
setblock 473 99 465 minecraft:terracotta
fill 473 99 466 473 99 469 minecraft:red_terracotta
setblock 473 99 470 minecraft:terracotta
fill 473 99 471 473 99 474 minecraft:red_terracotta
setblock 474 99 464 minecraft:terracotta
fill 474 99 465 474 99 468 minecraft:red_terracotta
setblock 474 99 469 minecraft:terracotta
fill 474 99 470 474 99 471 minecraft:red_terracotta
setblock 474 99 504 minecraft:terracotta
fill 475 99 464 475 99 467 minecraft:red_terracotta
fill 475 99 504 477 99 504 minecraft:red_terracotta
fill 476 99 464 476 99 466 minecraft:red_terracotta
fill 477 99 464 477 99 465 minecraft:red_terracotta
setblock 477 99 466 minecraft:terracotta
setblock 478 99 464 minecraft:red_terracotta
setblock 478 99 465 minecraft:terracotta
setblock 479 99 464 minecraft:terracotta
fill 479 99 465 480 99 465 minecraft:red_terracotta
fill 480 99 464 483 99 464 minecraft:red_terracotta
setblock 484 99 464 minecraft:terracotta
fill 485 99 464 488 99 464 minecraft:red_terracotta
fill 486 99 504 488 99 504 minecraft:red_terracotta
setblock 487 99 465 minecraft:red_terracotta
setblock 488 99 465 minecraft:terracotta
setblock 489 99 464 minecraft:terracotta
fill 489 99 465 492 99 465 minecraft:red_terracotta
setblock 489 99 503 minecraft:red_terracotta
setblock 489 99 504 minecraft:terracotta
fill 490 99 464 493 99 464 minecraft:red_terracotta
setblock 490 99 503 minecraft:terracotta
fill 490 99 504 493 99 504 minecraft:red_terracotta
fill 491 99 503 494 99 503 minecraft:red_terracotta
setblock 493 99 465 minecraft:terracotta
setblock 494 99 464 minecraft:terracotta
setblock 494 99 465 minecraft:red_terracotta
setblock 494 99 504 minecraft:terracotta
fill 495 99 464 496 99 464 minecraft:red_terracotta
fill 495 99 504 496 99 504 minecraft:red_terracotta
setblock 509 99 464 minecraft:terracotta
fill 509 99 470 511 100 470 minecraft:red_terracotta
fill 509 99 486 509 99 488 minecraft:red_terracotta
setblock 509 99 489 minecraft:terracotta
fill 509 99 490 510 99 492 minecraft:red_terracotta
fill 510 99 464 510 99 467 minecraft:red_terracotta
setblock 510 99 468 minecraft:terracotta
fill 510 99 469 511 101 469 minecraft:red_terracotta
fill 510 99 471 510 99 472 minecraft:red_terracotta
setblock 510 99 473 minecraft:terracotta
fill 510 99 474 510 99 477 minecraft:red_terracotta
setblock 510 99 478 minecraft:terracotta
fill 510 99 479 510 99 482 minecraft:red_terracotta
setblock 510 99 483 minecraft:terracotta
fill 510 99 484 510 99 487 minecraft:red_terracotta
setblock 510 99 488 minecraft:terracotta
fill 510 99 489 511 101 489 minecraft:red_terracotta
setblock 510 99 493 minecraft:terracotta
fill 510 99 494 511 100 495 minecraft:red_terracotta
fill 511 99 464 511 99 466 minecraft:red_terracotta
setblock 511 99 467 minecraft:terracotta
fill 511 99 468 511 102 468 minecraft:red_terracotta
setblock 511 99 471 minecraft:red_terracotta
setblock 511 99 472 minecraft:terracotta
fill 511 99 473 511 99 476 minecraft:red_terracotta
setblock 511 99 477 minecraft:terracotta
fill 511 99 478 511 99 481 minecraft:red_terracotta
setblock 511 99 482 minecraft:terracotta
fill 511 99 483 511 99 486 minecraft:red_terracotta
setblock 511 99 487 minecraft:terracotta
fill 511 99 488 511 102 488 minecraft:red_terracotta
fill 511 99 490 511 99 491 minecraft:red_terracotta
setblock 511 99 492 minecraft:terracotta
fill 511 99 493 511 102 493 minecraft:red_terracotta
setblock 511 99 496 minecraft:red_terracotta
setblock 511 99 497 minecraft:terracotta
fill 471 100 464 471 100 465 minecraft:red_terracotta
setblock 471 100 466 minecraft:terracotta
fill 471 100 467 471 100 470 minecraft:red_terracotta
setblock 471 100 471 minecraft:terracotta
fill 471 100 472 471 100 475 minecraft:red_terracotta
setblock 471 100 476 minecraft:terracotta
fill 471 100 477 471 100 480 minecraft:red_terracotta
setblock 471 100 481 minecraft:terracotta
fill 471 100 482 471 100 485 minecraft:red_terracotta
setblock 471 100 486 minecraft:terracotta
fill 471 100 487 471 100 490 minecraft:red_terracotta
setblock 471 100 491 minecraft:terracotta
fill 471 100 492 471 100 495 minecraft:red_terracotta
setblock 471 100 496 minecraft:terracotta
fill 471 100 497 471 103 497 minecraft:red_terracotta
fill 471 100 504 472 100 504 minecraft:red_terracotta
setblock 472 100 464 minecraft:red_terracotta
setblock 472 100 465 minecraft:terracotta
fill 472 100 466 472 100 469 minecraft:red_terracotta
setblock 472 100 470 minecraft:terracotta
fill 472 100 471 472 100 474 minecraft:red_terracotta
setblock 472 100 475 minecraft:terracotta
fill 472 100 476 472 102 477 minecraft:red_terracotta
fill 472 100 488 472 100 489 minecraft:red_terracotta
setblock 472 100 490 minecraft:terracotta
fill 472 100 491 472 101 491 minecraft:red_terracotta
setblock 473 100 464 minecraft:terracotta
fill 473 100 465 473 100 468 minecraft:red_terracotta
setblock 473 100 469 minecraft:terracotta
fill 473 100 470 473 100 473 minecraft:red_terracotta
setblock 473 100 474 minecraft:terracotta
setblock 473 100 504 minecraft:terracotta
fill 474 100 464 475 100 466 minecraft:red_terracotta
setblock 474 100 468 minecraft:terracotta
fill 474 100 469 474 100 470 minecraft:red_terracotta
fill 474 100 504 475 100 504 minecraft:red_terracotta
fill 476 100 464 476 100 465 minecraft:red_terracotta
setblock 476 100 466 minecraft:terracotta
setblock 477 100 464 minecraft:red_terracotta
setblock 477 100 465 minecraft:terracotta
setblock 478 100 464 minecraft:terracotta
setblock 478 100 465 minecraft:red_terracotta
fill 479 100 464 481 100 464 minecraft:red_terracotta
fill 484 100 464 487 100 464 minecraft:red_terracotta
fill 486 100 504 487 100 504 minecraft:red_terracotta
setblock 488 100 464 minecraft:terracotta
setblock 488 100 504 minecraft:terracotta
fill 489 100 464 491 100 465 minecraft:red_terracotta
fill 489 100 504 492 100 504 minecraft:red_terracotta
fill 490 100 503 492 100 503 minecraft:red_terracotta
setblock 492 100 464 minecraft:red_terracotta
setblock 492 100 465 minecraft:terracotta
setblock 493 100 464 minecraft:terracotta
setblock 493 100 504 minecraft:terracotta
fill 494 100 464 495 100 464 minecraft:red_terracotta
fill 494 100 504 495 100 504 minecraft:red_terracotta
fill 505 100 484 507 101 484 minecraft:orange_concrete
fill 506 100 483 506 101 483 minecraft:orange_concrete
fill 506 100 485 506 101 485 minecraft:orange_concrete
fill 509 100 464 511 101 464 minecraft:red_terracotta
fill 509 100 471 509 100 472 minecraft:red_terracotta
setblock 509 100 473 minecraft:terracotta
setblock 509 100 488 minecraft:terracotta
fill 509 100 489 509 100 491 minecraft:red_terracotta
fill 510 100 465 510 100 466 minecraft:red_terracotta
setblock 510 100 467 minecraft:terracotta
fill 510 100 468 510 103 468 minecraft:red_terracotta
setblock 510 100 471 minecraft:red_terracotta
setblock 510 100 472 minecraft:terracotta
fill 510 100 473 510 100 476 minecraft:red_terracotta
setblock 510 100 477 minecraft:terracotta
fill 510 100 478 510 100 481 minecraft:red_terracotta
setblock 510 100 482 minecraft:terracotta
fill 510 100 483 510 100 486 minecraft:red_terracotta
setblock 510 100 487 minecraft:terracotta
fill 510 100 488 510 103 488 minecraft:red_terracotta
fill 510 100 490 510 100 491 minecraft:red_terracotta
setblock 510 100 492 minecraft:terracotta
fill 510 100 493 510 103 493 minecraft:red_terracotta
setblock 511 100 465 minecraft:red_terracotta
setblock 511 100 466 minecraft:terracotta
fill 511 100 467 511 103 467 minecraft:red_terracotta
setblock 511 100 471 minecraft:terracotta
fill 511 100 472 511 100 475 minecraft:red_terracotta
setblock 511 100 476 minecraft:terracotta
fill 511 100 477 511 100 480 minecraft:red_terracotta
setblock 511 100 481 minecraft:terracotta
fill 511 100 482 511 100 485 minecraft:red_terracotta
setblock 511 100 486 minecraft:terracotta
fill 511 100 487 511 103 487 minecraft:red_terracotta
setblock 511 100 490 minecraft:red_terracotta
setblock 511 100 491 minecraft:terracotta
fill 511 100 492 511 103 492 minecraft:red_terracotta
setblock 511 100 496 minecraft:terracotta
fill 511 100 497 511 103 497 minecraft:red_terracotta
setblock 471 101 464 minecraft:red_terracotta
setblock 471 101 465 minecraft:terracotta
fill 471 101 466 471 101 469 minecraft:red_terracotta
setblock 471 101 470 minecraft:terracotta
fill 471 101 471 471 101 474 minecraft:red_terracotta
setblock 471 101 475 minecraft:terracotta
fill 471 101 476 471 101 479 minecraft:red_terracotta
setblock 471 101 480 minecraft:terracotta
fill 471 101 481 471 101 484 minecraft:red_terracotta
setblock 471 101 485 minecraft:terracotta
fill 471 101 486 471 101 489 minecraft:red_terracotta
setblock 471 101 490 minecraft:terracotta
fill 471 101 491 471 101 494 minecraft:red_terracotta
setblock 471 101 495 minecraft:terracotta
fill 471 101 496 471 104 496 minecraft:red_terracotta
fill 471 101 498 471 102 498 minecraft:red_terracotta
setblock 472 101 464 minecraft:terracotta
fill 472 101 465 472 101 468 minecraft:red_terracotta
setblock 472 101 469 minecraft:terracotta
fill 472 101 470 472 101 473 minecraft:red_terracotta
setblock 472 101 474 minecraft:terracotta
fill 472 101 475 472 104 475 minecraft:red_terracotta
setblock 472 101 490 minecraft:red_terracotta
fill 473 101 464 473 101 467 minecraft:red_terracotta
setblock 473 101 468 minecraft:terracotta
fill 473 101 469 473 101 472 minecraft:red_terracotta
setblock 473 101 473 minecraft:terracotta
fill 473 101 474 473 104 474 minecraft:red_terracotta
setblock 473 101 482 minecraft:light[level=14]
setblock 473 101 490 minecraft:light[level=14]
setblock 473 101 498 minecraft:light[level=14]
fill 474 101 464 474 101 466 minecraft:red_terracotta
fill 475 101 464 475 101 465 minecraft:red_terracotta
setblock 476 101 464 minecraft:red_terracotta
setblock 476 101 465 minecraft:terracotta
setblock 477 101 464 minecraft:terracotta
fill 478 101 464 479 101 464 minecraft:red_terracotta
setblock 481 101 466 minecraft:light[level=14]
setblock 481 101 474 minecraft:light[level=14]
setblock 481 101 482 minecraft:light[level=14]
setblock 481 101 490 minecraft:light[level=14]
setblock 481 101 498 minecraft:light[level=14]
setblock 486 101 464 minecraft:red_terracotta
setblock 486 101 504 minecraft:red_terracotta
setblock 487 101 464 minecraft:terracotta
setblock 487 101 504 minecraft:terracotta
fill 488 101 464 491 101 464 minecraft:red_terracotta
fill 488 101 504 491 101 504 minecraft:red_terracotta
setblock 489 101 466 minecraft:light[level=14]
setblock 489 101 474 minecraft:light[level=14]
setblock 489 101 482 minecraft:light[level=14]
setblock 489 101 490 minecraft:light[level=14]
setblock 489 101 498 minecraft:light[level=14]
setblock 492 101 464 minecraft:terracotta
setblock 492 101 504 minecraft:terracotta
setblock 493 101 464 minecraft:red_terracotta
fill 493 101 504 494 101 504 minecraft:red_terracotta
setblock 497 101 466 minecraft:light[level=14]
setblock 497 101 474 minecraft:light[level=14]
setblock 497 101 482 minecraft:light[level=14]
setblock 497 101 490 minecraft:light[level=14]
setblock 497 101 498 minecraft:light[level=14]
setblock 505 101 466 minecraft:light[level=14]
setblock 505 101 474 minecraft:light[level=14]
setblock 505 101 482 minecraft:light[level=14]
setblock 505 101 490 minecraft:light[level=14]
setblock 505 101 498 minecraft:light[level=14]
fill 509 101 469 509 101 471 minecraft:red_terracotta
setblock 509 101 472 minecraft:terracotta
fill 509 101 473 511 101 474 minecraft:red_terracotta
fill 509 101 490 509 101 491 minecraft:red_terracotta
setblock 510 101 466 minecraft:terracotta
fill 510 101 467 510 104 467 minecraft:red_terracotta
setblock 510 101 470 minecraft:red_terracotta
setblock 510 101 471 minecraft:terracotta
fill 510 101 472 511 103 472 minecraft:red_terracotta
setblock 510 101 475 minecraft:red_terracotta
setblock 510 101 476 minecraft:terracotta
fill 510 101 477 510 101 480 minecraft:red_terracotta
setblock 510 101 481 minecraft:terracotta
fill 510 101 482 510 101 485 minecraft:red_terracotta
setblock 510 101 486 minecraft:terracotta
fill 510 101 487 510 104 487 minecraft:red_terracotta
setblock 510 101 490 minecraft:red_terracotta
setblock 510 101 491 minecraft:terracotta
fill 510 101 492 510 104 492 minecraft:red_terracotta
fill 510 101 494 510 101 495 minecraft:red_terracotta
setblock 511 101 465 minecraft:terracotta
fill 511 101 466 511 104 466 minecraft:red_terracotta
setblock 511 101 470 minecraft:terracotta
fill 511 101 471 511 104 471 minecraft:red_terracotta
setblock 511 101 475 minecraft:terracotta
fill 511 101 476 511 101 479 minecraft:red_terracotta
setblock 511 101 480 minecraft:terracotta
fill 511 101 481 511 101 484 minecraft:red_terracotta
setblock 511 101 485 minecraft:terracotta
fill 511 101 486 511 104 486 minecraft:red_terracotta
setblock 511 101 490 minecraft:terracotta
fill 511 101 491 511 104 491 minecraft:red_terracotta
setblock 511 101 494 minecraft:red_terracotta
setblock 511 101 495 minecraft:terracotta
fill 511 101 496 511 104 496 minecraft:red_terracotta
setblock 471 102 464 minecraft:terracotta
fill 471 102 465 471 102 468 minecraft:red_terracotta
setblock 471 102 469 minecraft:terracotta
fill 471 102 470 471 102 473 minecraft:red_terracotta
setblock 471 102 474 minecraft:terracotta
fill 471 102 475 471 102 478 minecraft:red_terracotta
setblock 471 102 479 minecraft:terracotta
fill 471 102 480 471 104 481 minecraft:red_terracotta
fill 471 102 486 471 102 488 minecraft:red_terracotta
setblock 471 102 489 minecraft:terracotta
fill 471 102 490 471 102 493 minecraft:red_terracotta
setblock 471 102 494 minecraft:terracotta
fill 471 102 495 471 105 495 minecraft:red_terracotta
setblock 471 102 499 minecraft:terracotta
fill 472 102 464 472 102 467 minecraft:red_terracotta
setblock 472 102 468 minecraft:terracotta
fill 472 102 469 472 102 472 minecraft:red_terracotta
setblock 472 102 473 minecraft:terracotta
fill 472 102 474 472 105 474 minecraft:red_terracotta
setblock 472 102 492 minecraft:red_terracotta
setblock 472 102 493 minecraft:terracotta
fill 473 102 464 473 102 466 minecraft:red_terracotta
setblock 473 102 467 minecraft:terracotta
fill 473 102 468 473 102 471 minecraft:red_terracotta
setblock 473 102 472 minecraft:terracotta
fill 473 102 473 473 105 473 minecraft:red_terracotta
fill 474 102 464 474 102 465 minecraft:red_terracotta
setblock 475 102 464 minecraft:red_terracotta
setblock 475 102 465 minecraft:terracotta
setblock 476 102 464 minecraft:terracotta
setblock 477 102 464 minecraft:red_terracotta
setblock 486 102 504 minecraft:terracotta
fill 487 102 464 490 102 464 minecraft:red_terracotta
fill 487 102 504 490 102 504 minecraft:red_terracotta
setblock 491 102 464 minecraft:terracotta
setblock 491 102 504 minecraft:terracotta
setblock 492 102 464 minecraft:red_terracotta
fill 492 102 504 493 104 504 minecraft:red_terracotta
fill 509 102 464 510 102 464 minecraft:red_terracotta
fill 509 102 469 509 102 470 minecraft:red_terracotta
setblock 509 102 471 minecraft:terracotta
fill 509 102 472 509 102 475 minecraft:red_terracotta
setblock 509 102 476 minecraft:terracotta
fill 510 102 466 510 105 466 minecraft:red_terracotta
setblock 510 102 469 minecraft:red_terracotta
setblock 510 102 470 minecraft:terracotta
fill 510 102 471 510 105 471 minecraft:red_terracotta
fill 510 102 473 510 102 474 minecraft:red_terracotta
setblock 510 102 475 minecraft:terracotta
fill 510 102 476 510 102 479 minecraft:red_terracotta
setblock 510 102 480 minecraft:terracotta
fill 510 102 481 511 104 481 minecraft:red_terracotta
setblock 510 102 484 minecraft:red_terracotta
setblock 510 102 485 minecraft:terracotta
fill 510 102 486 510 104 486 minecraft:red_terracotta
setblock 510 102 489 minecraft:red_terracotta
setblock 510 102 490 minecraft:terracotta
fill 510 102 491 510 105 491 minecraft:red_terracotta
setblock 510 102 494 minecraft:red_terracotta
setblock 510 102 495 minecraft:terracotta
setblock 511 102 464 minecraft:terracotta
fill 511 102 465 511 105 465 minecraft:red_terracotta
setblock 511 102 469 minecraft:terracotta
fill 511 102 470 511 105 470 minecraft:red_terracotta
setblock 511 102 473 minecraft:red_terracotta
setblock 511 102 474 minecraft:terracotta
fill 511 102 475 511 102 478 minecraft:red_terracotta
setblock 511 102 479 minecraft:terracotta
fill 511 102 480 511 105 480 minecraft:red_terracotta
fill 511 102 482 511 102 483 minecraft:red_terracotta
setblock 511 102 484 minecraft:terracotta
fill 511 102 485 511 105 485 minecraft:red_terracotta
setblock 511 102 489 minecraft:terracotta
fill 511 102 490 511 105 490 minecraft:red_terracotta
setblock 511 102 494 minecraft:terracotta
fill 511 102 495 511 105 495 minecraft:red_terracotta
setblock 511 102 498 minecraft:red_terracotta
fill 471 103 464 471 103 467 minecraft:red_terracotta
setblock 471 103 468 minecraft:terracotta
fill 471 103 469 471 103 472 minecraft:red_terracotta
setblock 471 103 473 minecraft:terracotta
fill 471 103 474 471 103 477 minecraft:red_terracotta
setblock 471 103 478 minecraft:terracotta
fill 471 103 479 471 106 479 minecraft:red_terracotta
setblock 471 103 487 minecraft:red_terracotta
setblock 471 103 488 minecraft:terracotta
fill 471 103 489 471 103 492 minecraft:red_terracotta
setblock 471 103 493 minecraft:terracotta
fill 471 103 494 472 105 494 minecraft:red_terracotta
setblock 471 103 498 minecraft:terracotta
fill 471 103 499 471 104 501 minecraft:red_terracotta
fill 471 103 504 472 105 504 minecraft:red_terracotta
fill 472 103 464 472 103 466 minecraft:red_terracotta
setblock 472 103 467 minecraft:terracotta
fill 472 103 468 472 103 471 minecraft:red_terracotta
setblock 472 103 472 minecraft:terracotta
fill 472 103 473 472 106 473 minecraft:red_terracotta
setblock 472 103 476 minecraft:red_terracotta
setblock 472 103 477 minecraft:terracotta
fill 472 103 493 472 106 493 minecraft:red_terracotta
fill 472 103 495 472 104 495 minecraft:red_terracotta
fill 473 103 464 473 103 465 minecraft:red_terracotta
fill 473 103 467 473 103 470 minecraft:red_terracotta
setblock 473 103 471 minecraft:terracotta
fill 473 103 472 473 106 472 minecraft:red_terracotta
setblock 474 103 464 minecraft:red_terracotta
setblock 474 103 465 minecraft:terracotta
setblock 475 103 464 minecraft:terracotta
fill 476 103 464 476 104 464 minecraft:red_terracotta
setblock 485 103 504 minecraft:terracotta
fill 486 103 504 489 103 504 minecraft:red_terracotta
fill 487 103 464 489 103 464 minecraft:red_terracotta
fill 489 103 503 490 103 503 minecraft:red_terracotta
setblock 490 103 464 minecraft:terracotta
setblock 490 103 504 minecraft:terracotta
setblock 491 103 464 minecraft:red_terracotta
fill 491 103 504 491 106 504 minecraft:red_terracotta
fill 496 103 492 500 160 493 minecraft:terracotta
fill 497 103 491 500 160 491 minecraft:terracotta
fill 497 103 494 500 160 494 minecraft:terracotta
fill 498 103 495 499 160 495 minecraft:terracotta
setblock 509 103 464 minecraft:red_terracotta
setblock 509 103 469 minecraft:red_terracotta
setblock 509 103 470 minecraft:terracotta
fill 509 103 471 509 103 474 minecraft:red_terracotta
setblock 509 103 475 minecraft:terracotta
fill 509 103 476 511 103 477 minecraft:red_terracotta
setblock 510 103 464 minecraft:terracotta
setblock 510 103 469 minecraft:terracotta
fill 510 103 470 510 106 470 minecraft:red_terracotta
setblock 510 103 473 minecraft:red_terracotta
setblock 510 103 474 minecraft:terracotta
fill 510 103 475 511 105 475 minecraft:red_terracotta
setblock 510 103 478 minecraft:red_terracotta
setblock 510 103 479 minecraft:terracotta
fill 510 103 480 510 106 480 minecraft:red_terracotta
fill 510 103 482 511 103 482 minecraft:red_terracotta
setblock 510 103 485 minecraft:red_terracotta
setblock 510 103 489 minecraft:terracotta
fill 510 103 490 510 106 490 minecraft:red_terracotta
setblock 510 103 494 minecraft:terracotta
fill 510 103 495 510 105 496 minecraft:red_terracotta
fill 511 103 464 511 106 464 minecraft:red_terracotta
setblock 511 103 468 minecraft:terracotta
fill 511 103 469 511 106 469 minecraft:red_terracotta
setblock 511 103 473 minecraft:terracotta
fill 511 103 474 511 106 474 minecraft:red_terracotta
setblock 511 103 478 minecraft:terracotta
fill 511 103 479 511 106 479 minecraft:red_terracotta
setblock 511 103 483 minecraft:terracotta
fill 511 103 484 511 106 484 minecraft:red_terracotta
setblock 511 103 488 minecraft:terracotta
fill 511 103 489 511 106 489 minecraft:red_terracotta
setblock 511 103 493 minecraft:terracotta
fill 511 103 494 511 106 494 minecraft:red_terracotta
setblock 511 103 498 minecraft:terracotta
fill 511 103 499 511 106 499 minecraft:red_terracotta
fill 471 104 464 471 104 466 minecraft:red_terracotta
setblock 471 104 467 minecraft:terracotta
fill 471 104 468 471 104 471 minecraft:red_terracotta
setblock 471 104 472 minecraft:terracotta
fill 471 104 473 471 104 476 minecraft:red_terracotta
setblock 471 104 477 minecraft:terracotta
fill 471 104 478 472 106 478 minecraft:red_terracotta
fill 471 104 488 471 104 491 minecraft:red_terracotta
setblock 471 104 492 minecraft:terracotta
fill 471 104 493 471 107 493 minecraft:red_terracotta
setblock 471 104 497 minecraft:terracotta
fill 471 104 498 471 107 498 minecraft:red_terracotta
setblock 471 104 502 minecraft:terracotta
fill 471 104 503 471 107 503 minecraft:red_terracotta
fill 472 104 464 472 104 465 minecraft:red_terracotta
setblock 472 104 466 minecraft:terracotta
fill 472 104 467 472 104 470 minecraft:red_terracotta
setblock 472 104 471 minecraft:terracotta
fill 472 104 472 472 107 472 minecraft:red_terracotta
setblock 472 104 476 minecraft:terracotta
fill 472 104 477 472 107 477 minecraft:red_terracotta
setblock 472 104 496 minecraft:terracotta
fill 472 104 497 472 107 497 minecraft:red_terracotta
setblock 473 104 464 minecraft:red_terracotta
setblock 473 104 465 minecraft:terracotta
fill 473 104 468 473 104 469 minecraft:red_terracotta
setblock 473 104 470 minecraft:terracotta
fill 473 104 471 473 107 471 minecraft:red_terracotta
setblock 473 104 504 minecraft:red_terracotta
setblock 474 104 464 minecraft:terracotta
fill 475 104 464 475 107 464 minecraft:red_terracotta
setblock 484 104 504 minecraft:terracotta
fill 485 104 504 488 104 504 minecraft:red_terracotta
fill 487 104 464 488 104 464 minecraft:red_terracotta
fill 487 104 503 489 104 503 minecraft:red_terracotta
setblock 489 104 464 minecraft:terracotta
setblock 489 104 504 minecraft:terracotta
fill 490 104 464 490 107 464 minecraft:red_terracotta
setblock 490 104 503 minecraft:terracotta
fill 490 104 504 490 107 504 minecraft:red_terracotta
fill 491 104 503 491 107 503 minecraft:red_terracotta
fill 495 104 492 495 105 494 minecraft:brown_terracotta
fill 496 104 490 496 105 491 minecraft:brown_terracotta
fill 496 104 494 496 105 495 minecraft:brown_terracotta
fill 497 104 490 500 105 490 minecraft:brown_terracotta
fill 497 104 495 497 105 496 minecraft:brown_terracotta
fill 498 104 496 499 105 496 minecraft:brown_terracotta
fill 500 104 495 500 105 495 minecraft:brown_terracotta
fill 501 104 491 501 105 494 minecraft:brown_terracotta
fill 508 104 473 508 104 474 minecraft:red_terracotta
setblock 509 104 464 minecraft:terracotta
setblock 509 104 469 minecraft:terracotta
fill 509 104 470 509 104 473 minecraft:red_terracotta
setblock 509 104 474 minecraft:terracotta
fill 509 104 475 509 104 478 minecraft:red_terracotta
setblock 509 104 479 minecraft:terracotta
fill 510 104 464 510 107 464 minecraft:red_terracotta
setblock 510 104 468 minecraft:terracotta
fill 510 104 469 510 107 469 minecraft:red_terracotta
setblock 510 104 472 minecraft:red_terracotta
setblock 510 104 473 minecraft:terracotta
fill 510 104 474 510 107 474 minecraft:red_terracotta
fill 510 104 476 510 104 477 minecraft:red_terracotta
setblock 510 104 478 minecraft:terracotta
fill 510 104 479 510 107 479 minecraft:red_terracotta
setblock 510 104 482 minecraft:red_terracotta
setblock 510 104 483 minecraft:terracotta
setblock 510 104 488 minecraft:terracotta
fill 510 104 489 510 107 489 minecraft:red_terracotta
setblock 510 104 493 minecraft:terracotta
fill 510 104 494 510 107 494 minecraft:red_terracotta
setblock 510 104 497 minecraft:red_terracotta
setblock 511 104 467 minecraft:terracotta
fill 511 104 468 511 107 468 minecraft:red_terracotta
setblock 511 104 472 minecraft:terracotta
fill 511 104 473 511 107 473 minecraft:red_terracotta
setblock 511 104 476 minecraft:red_terracotta
setblock 511 104 477 minecraft:terracotta
fill 511 104 478 511 107 478 minecraft:red_terracotta
setblock 511 104 482 minecraft:terracotta
fill 511 104 483 511 107 483 minecraft:red_terracotta
setblock 511 104 487 minecraft:terracotta
fill 511 104 488 511 107 488 minecraft:red_terracotta
setblock 511 104 492 minecraft:terracotta
fill 511 104 493 511 107 493 minecraft:red_terracotta
setblock 511 104 497 minecraft:terracotta
fill 511 104 498 511 107 498 minecraft:red_terracotta
fill 511 104 500 511 105 500 minecraft:red_terracotta
fill 471 105 464 471 105 465 minecraft:red_terracotta
setblock 471 105 466 minecraft:terracotta
fill 471 105 467 471 105 470 minecraft:red_terracotta
setblock 471 105 471 minecraft:terracotta
fill 471 105 472 471 105 475 minecraft:red_terracotta
setblock 471 105 476 minecraft:terracotta
fill 471 105 477 471 108 477 minecraft:red_terracotta
setblock 471 105 480 minecraft:red_terracotta
setblock 471 105 481 minecraft:terracotta
fill 471 105 489 471 105 490 minecraft:red_terracotta
setblock 471 105 491 minecraft:terracotta
fill 471 105 492 471 108 492 minecraft:red_terracotta
setblock 471 105 496 minecraft:terracotta
fill 471 105 497 471 108 497 minecraft:red_terracotta
fill 471 105 499 471 105 500 minecraft:red_terracotta
setblock 471 105 501 minecraft:terracotta
fill 471 105 502 471 108 502 minecraft:red_terracotta
setblock 472 105 464 minecraft:red_terracotta
setblock 472 105 465 minecraft:terracotta
fill 472 105 466 472 105 469 minecraft:red_terracotta
setblock 472 105 470 minecraft:terracotta
fill 472 105 471 472 108 471 minecraft:red_terracotta
setblock 472 105 475 minecraft:terracotta
fill 472 105 476 472 108 476 minecraft:red_terracotta
setblock 472 105 495 minecraft:terracotta
fill 472 105 496 472 108 496 minecraft:red_terracotta
fill 472 105 498 472 105 499 minecraft:red_terracotta
setblock 473 105 464 minecraft:terracotta
fill 473 105 465 473 106 465 minecraft:red_terracotta
setblock 473 105 469 minecraft:terracotta
fill 473 105 470 473 106 470 minecraft:red_terracotta
setblock 473 105 474 minecraft:terracotta
fill 473 105 475 473 107 475 minecraft:red_terracotta
setblock 473 105 504 minecraft:terracotta
fill 474 105 464 474 108 464 minecraft:red_terracotta
fill 474 105 504 474 108 504 minecraft:red_terracotta
setblock 483 105 504 minecraft:terracotta
fill 484 105 504 487 105 504 minecraft:red_terracotta
fill 485 105 503 488 105 503 minecraft:red_terracotta
fill 486 105 464 487 105 464 minecraft:red_terracotta
setblock 488 105 464 minecraft:terracotta
setblock 488 105 504 minecraft:terracotta
fill 489 105 464 489 108 464 minecraft:red_terracotta
setblock 489 105 503 minecraft:terracotta
fill 489 105 504 489 108 504 minecraft:red_terracotta
fill 490 105 503 490 108 503 minecraft:red_terracotta
setblock 492 105 504 minecraft:red_terracotta
setblock 493 105 504 minecraft:terracotta
fill 494 105 491 494 105 494 minecraft:brown_terracotta
fill 495 105 490 495 105 491 minecraft:brown_terracotta
setblock 495 105 495 minecraft:brown_terracotta
fill 496 105 489 501 105 489 minecraft:brown_terracotta
setblock 496 105 496 minecraft:brown_terracotta
fill 497 105 497 499 105 497 minecraft:brown_terracotta
setblock 498 105 488 minecraft:brown_terracotta
fill 500 105 496 501 105 496 minecraft:brown_terracotta
fill 501 105 490 502 105 490 minecraft:brown_terracotta
fill 501 105 495 502 105 495 minecraft:brown_terracotta
fill 502 105 491 502 105 494 minecraft:brown_terracotta
setblock 508 105 464 minecraft:terracotta
fill 508 105 471 508 105 473 minecraft:red_terracotta
setblock 508 105 474 minecraft:terracotta
fill 508 105 475 509 105 477 minecraft:red_terracotta
fill 509 105 464 509 108 464 minecraft:red_terracotta
setblock 509 105 468 minecraft:terracotta
fill 509 105 469 509 105 472 minecraft:red_terracotta
setblock 509 105 473 minecraft:terracotta
fill 509 105 474 509 108 474 minecraft:red_terracotta
setblock 509 105 478 minecraft:terracotta
fill 509 105 479 509 107 480 minecraft:red_terracotta
setblock 509 105 493 minecraft:terracotta
fill 509 105 494 509 107 494 minecraft:red_terracotta
setblock 510 105 467 minecraft:terracotta
fill 510 105 468 510 108 468 minecraft:red_terracotta
setblock 510 105 472 minecraft:terracotta
fill 510 105 473 510 108 473 minecraft:red_terracotta
setblock 510 105 476 minecraft:red_terracotta
setblock 510 105 477 minecraft:terracotta
fill 510 105 478 510 108 478 minecraft:red_terracotta
setblock 510 105 481 minecraft:red_terracotta
setblock 510 105 482 minecraft:terracotta
fill 510 105 483 510 107 484 minecraft:red_terracotta
setblock 510 105 487 minecraft:terracotta
fill 510 105 488 510 106 488 minecraft:red_terracotta
setblock 510 105 492 minecraft:terracotta
fill 510 105 493 510 108 493 minecraft:red_terracotta
setblock 510 105 497 minecraft:terracotta
fill 510 105 498 510 108 498 minecraft:red_terracotta
setblock 511 105 466 minecraft:terracotta
fill 511 105 467 511 108 467 minecraft:red_terracotta
setblock 511 105 471 minecraft:terracotta
fill 511 105 472 511 108 472 minecraft:red_terracotta
setblock 511 105 476 minecraft:terracotta
fill 511 105 477 511 108 477 minecraft:red_terracotta
setblock 511 105 481 minecraft:terracotta
fill 511 105 482 511 108 482 minecraft:red_terracotta
setblock 511 105 486 minecraft:terracotta
fill 511 105 487 511 108 487 minecraft:red_terracotta
setblock 511 105 491 minecraft:terracotta
fill 511 105 492 511 108 492 minecraft:red_terracotta
setblock 511 105 496 minecraft:terracotta
fill 511 105 497 511 108 497 minecraft:red_terracotta
setblock 511 105 501 minecraft:terracotta
setblock 471 106 464 minecraft:red_terracotta
setblock 471 106 465 minecraft:terracotta
fill 471 106 466 471 106 469 minecraft:red_terracotta
setblock 471 106 470 minecraft:terracotta
fill 471 106 471 471 106 474 minecraft:red_terracotta
setblock 471 106 475 minecraft:terracotta
fill 471 106 476 471 109 476 minecraft:red_terracotta
setblock 471 106 480 minecraft:terracotta
fill 471 106 481 471 108 482 minecraft:red_terracotta
setblock 471 106 489 minecraft:red_terracotta
setblock 471 106 490 minecraft:terracotta
fill 471 106 491 471 108 491 minecraft:red_terracotta
setblock 471 106 494 minecraft:red_terracotta
setblock 471 106 495 minecraft:terracotta
fill 471 106 496 471 109 496 minecraft:red_terracotta
setblock 471 106 499 minecraft:red_terracotta
setblock 471 106 500 minecraft:terracotta
fill 471 106 501 472 108 501 minecraft:red_terracotta
setblock 471 106 504 minecraft:red_terracotta
setblock 472 106 464 minecraft:terracotta
fill 472 106 465 472 106 468 minecraft:red_terracotta
setblock 472 106 469 minecraft:terracotta
fill 472 106 470 472 109 470 minecraft:red_terracotta
setblock 472 106 474 minecraft:terracotta
fill 472 106 475 472 109 475 minecraft:red_terracotta
setblock 472 106 479 minecraft:terracotta
setblock 472 106 494 minecraft:terracotta
fill 472 106 495 472 109 495 minecraft:red_terracotta
setblock 472 106 498 minecraft:red_terracotta
setblock 472 106 499 minecraft:terracotta
fill 472 106 500 472 109 500 minecraft:red_terracotta
setblock 472 106 504 minecraft:terracotta
fill 473 106 464 473 109 464 minecraft:red_terracotta
setblock 473 106 473 minecraft:terracotta
fill 473 106 474 473 107 474 minecraft:red_terracotta
fill 473 106 504 473 109 504 minecraft:red_terracotta
fill 475 106 504 475 107 504 minecraft:red_terracotta
setblock 481 106 504 minecraft:red_terracotta
setblock 482 106 504 minecraft:terracotta
setblock 483 106 503 minecraft:terracotta
fill 483 106 504 486 106 504 minecraft:red_terracotta
fill 484 106 464 486 106 464 minecraft:red_terracotta
fill 484 106 503 487 106 503 minecraft:red_terracotta
fill 486 106 502 488 106 502 minecraft:red_terracotta
setblock 487 106 464 minecraft:terracotta
setblock 487 106 504 minecraft:terracotta
fill 488 106 464 488 109 464 minecraft:red_terracotta
setblock 488 106 503 minecraft:terracotta
fill 488 106 504 488 109 504 minecraft:red_terracotta
setblock 489 106 502 minecraft:terracotta
fill 489 106 503 489 109 503 minecraft:red_terracotta
fill 490 106 502 490 109 502 minecraft:red_terracotta
setblock 492 106 504 minecraft:terracotta
fill 493 106 504 493 109 504 minecraft:red_terracotta
setblock 507 106 464 minecraft:terracotta
fill 508 106 464 508 109 464 minecraft:red_terracotta
fill 508 106 471 508 106 472 minecraft:red_terracotta
setblock 508 106 473 minecraft:terracotta
fill 508 106 474 508 106 477 minecraft:red_terracotta
setblock 508 106 478 minecraft:terracotta
fill 509 106 465 510 106 465 minecraft:red_terracotta
fill 509 106 468 509 106 471 minecraft:red_terracotta
setblock 509 106 472 minecraft:terracotta
fill 509 106 473 509 109 473 minecraft:red_terracotta
fill 509 106 475 509 106 476 minecraft:red_terracotta
setblock 509 106 477 minecraft:terracotta
fill 509 106 478 509 109 478 minecraft:red_terracotta
setblock 509 106 481 minecraft:red_terracotta
setblock 509 106 493 minecraft:red_terracotta
fill 509 106 495 509 106 496 minecraft:red_terracotta
setblock 510 106 466 minecraft:terracotta
fill 510 106 467 510 109 467 minecraft:red_terracotta
setblock 510 106 471 minecraft:terracotta
fill 510 106 472 510 109 472 minecraft:red_terracotta
setblock 510 106 475 minecraft:red_terracotta
setblock 510 106 476 minecraft:terracotta
fill 510 106 477 510 109 477 minecraft:red_terracotta
setblock 510 106 481 minecraft:terracotta
fill 510 106 482 510 109 482 minecraft:red_terracotta
setblock 510 106 485 minecraft:red_terracotta
setblock 510 106 491 minecraft:terracotta
fill 510 106 492 510 108 492 minecraft:red_terracotta
setblock 510 106 495 minecraft:red_terracotta
setblock 510 106 496 minecraft:terracotta
fill 510 106 497 510 109 497 minecraft:red_terracotta
fill 510 106 499 510 107 499 minecraft:red_terracotta
setblock 511 106 465 minecraft:terracotta
fill 511 106 466 511 109 466 minecraft:red_terracotta
setblock 511 106 470 minecraft:terracotta
fill 511 106 471 511 109 471 minecraft:red_terracotta
setblock 511 106 475 minecraft:terracotta
fill 511 106 476 511 109 476 minecraft:red_terracotta
setblock 511 106 480 minecraft:terracotta
fill 511 106 481 511 109 481 minecraft:red_terracotta
setblock 511 106 485 minecraft:terracotta
fill 511 106 486 511 109 486 minecraft:red_terracotta
setblock 511 106 490 minecraft:terracotta
fill 511 106 491 511 109 491 minecraft:red_terracotta
setblock 511 106 495 minecraft:terracotta
fill 511 106 496 511 109 496 minecraft:red_terracotta
setblock 511 106 500 minecraft:terracotta
fill 511 106 501 511 107 503 minecraft:red_terracotta
setblock 471 107 464 minecraft:terracotta
fill 471 107 465 471 107 468 minecraft:red_terracotta
setblock 471 107 469 minecraft:terracotta
fill 471 107 470 471 107 473 minecraft:red_terracotta
setblock 471 107 474 minecraft:terracotta
fill 471 107 475 471 110 475 minecraft:red_terracotta
setblock 471 107 478 minecraft:red_terracotta
setblock 471 107 479 minecraft:terracotta
fill 471 107 480 471 110 480 minecraft:red_terracotta
setblock 471 107 490 minecraft:red_terracotta
setblock 471 107 494 minecraft:terracotta
fill 471 107 495 471 110 495 minecraft:red_terracotta
setblock 471 107 499 minecraft:terracotta
fill 471 107 500 471 110 500 minecraft:red_terracotta
setblock 471 107 504 minecraft:terracotta
fill 472 107 464 472 107 467 minecraft:red_terracotta
setblock 472 107 468 minecraft:terracotta
fill 472 107 469 472 109 469 minecraft:red_terracotta
setblock 472 107 473 minecraft:terracotta
fill 472 107 474 472 110 474 minecraft:red_terracotta
setblock 472 107 478 minecraft:terracotta
fill 472 107 479 472 110 479 minecraft:red_terracotta
fill 472 107 494 472 108 494 minecraft:red_terracotta
setblock 472 107 498 minecraft:terracotta
fill 472 107 499 472 110 499 minecraft:red_terracotta
setblock 472 107 502 minecraft:red_terracotta
setblock 472 107 503 minecraft:terracotta
fill 472 107 504 472 110 504 minecraft:red_terracotta
setblock 473 107 472 minecraft:terracotta
setblock 473 107 473 minecraft:red_terracotta
setblock 476 107 504 minecraft:terracotta
fill 477 107 504 480 107 504 minecraft:red_terracotta
setblock 481 107 503 minecraft:red_terracotta
setblock 481 107 504 minecraft:terracotta
setblock 482 107 503 minecraft:terracotta
fill 482 107 504 485 107 504 minecraft:red_terracotta
fill 483 107 464 485 107 464 minecraft:red_terracotta
fill 483 107 503 486 107 503 minecraft:red_terracotta
fill 484 107 502 487 107 502 minecraft:red_terracotta
setblock 486 107 464 minecraft:terracotta
fill 486 107 501 488 107 501 minecraft:red_terracotta
setblock 486 107 504 minecraft:terracotta
fill 487 107 464 487 110 464 minecraft:red_terracotta
setblock 487 107 503 minecraft:terracotta
fill 487 107 504 487 110 504 minecraft:red_terracotta
setblock 488 107 502 minecraft:terracotta
fill 488 107 503 488 110 503 minecraft:red_terracotta
setblock 489 107 501 minecraft:terracotta
fill 489 107 502 489 110 502 minecraft:red_terracotta
fill 491 107 502 491 108 502 minecraft:red_terracotta
setblock 491 107 504 minecraft:terracotta
setblock 492 107 503 minecraft:terracotta
fill 492 107 504 492 110 504 minecraft:red_terracotta
setblock 506 107 464 minecraft:terracotta
setblock 506 107 504 minecraft:terracotta
fill 507 107 464 507 110 464 minecraft:red_terracotta
fill 507 107 474 508 107 476 minecraft:red_terracotta
fill 507 107 504 510 107 504 minecraft:red_terracotta
fill 508 107 465 509 107 465 minecraft:red_terracotta
fill 508 107 470 508 107 471 minecraft:red_terracotta
setblock 508 107 472 minecraft:terracotta
fill 508 107 473 508 110 473 minecraft:red_terracotta
setblock 508 107 477 minecraft:terracotta
fill 508 107 478 508 108 480 minecraft:red_terracotta
fill 509 107 468 509 107 470 minecraft:red_terracotta
setblock 509 107 471 minecraft:terracotta
fill 509 107 472 509 110 472 minecraft:red_terracotta
setblock 509 107 475 minecraft:red_terracotta
setblock 509 107 476 minecraft:terracotta
fill 509 107 477 509 110 477 minecraft:red_terracotta
setblock 509 107 481 minecraft:terracotta
fill 509 107 482 509 110 482 minecraft:red_terracotta
setblock 509 107 495 minecraft:red_terracotta
setblock 509 107 496 minecraft:terracotta
fill 509 107 497 509 109 497 minecraft:red_terracotta
setblock 510 107 465 minecraft:terracotta
fill 510 107 466 510 110 466 minecraft:red_terracotta
setblock 510 107 470 minecraft:terracotta
fill 510 107 471 510 110 471 minecraft:red_terracotta
setblock 510 107 475 minecraft:terracotta
fill 510 107 476 510 110 476 minecraft:red_terracotta
setblock 510 107 480 minecraft:terracotta
fill 510 107 481 510 110 481 minecraft:red_terracotta
setblock 510 107 485 minecraft:terracotta
setblock 510 107 490 minecraft:terracotta
fill 510 107 491 510 108 491 minecraft:red_terracotta
setblock 510 107 495 minecraft:terracotta
fill 510 107 496 510 110 496 minecraft:red_terracotta
setblock 510 107 500 minecraft:terracotta
fill 510 107 501 510 110 501 minecraft:red_terracotta
setblock 511 107 464 minecraft:terracotta
fill 511 107 465 511 110 465 minecraft:red_terracotta
setblock 511 107 469 minecraft:terracotta
fill 511 107 470 511 110 470 minecraft:red_terracotta
setblock 511 107 474 minecraft:terracotta
fill 511 107 475 511 110 475 minecraft:red_terracotta
setblock 511 107 479 minecraft:terracotta
fill 511 107 480 511 110 480 minecraft:red_terracotta
setblock 511 107 484 minecraft:terracotta
fill 511 107 485 511 110 485 minecraft:red_terracotta
setblock 511 107 489 minecraft:terracotta
fill 511 107 490 511 109 490 minecraft:red_terracotta
setblock 511 107 494 minecraft:terracotta
fill 511 107 495 511 110 495 minecraft:red_terracotta
setblock 511 107 499 minecraft:terracotta
fill 511 107 500 511 110 500 minecraft:red_terracotta
setblock 511 107 504 minecraft:terracotta
fill 471 108 464 471 108 467 minecraft:red_terracotta
setblock 471 108 468 minecraft:terracotta
fill 471 108 469 471 108 472 minecraft:red_terracotta
setblock 471 108 473 minecraft:terracotta
fill 471 108 474 471 111 474 minecraft:red_terracotta
setblock 471 108 478 minecraft:terracotta
fill 471 108 479 471 111 479 minecraft:red_terracotta
setblock 471 108 483 minecraft:terracotta
setblock 471 108 493 minecraft:terracotta
fill 471 108 494 471 111 494 minecraft:red_terracotta
setblock 471 108 498 minecraft:terracotta
fill 471 108 499 471 111 499 minecraft:red_terracotta
setblock 471 108 503 minecraft:terracotta
fill 471 108 504 471 111 504 minecraft:red_terracotta
fill 472 108 464 472 108 466 minecraft:red_terracotta
setblock 472 108 467 minecraft:terracotta
fill 472 108 468 472 109 468 minecraft:red_terracotta
setblock 472 108 472 minecraft:terracotta
fill 472 108 473 472 110 473 minecraft:red_terracotta
setblock 472 108 477 minecraft:terracotta
fill 472 108 478 472 111 478 minecraft:red_terracotta
setblock 472 108 497 minecraft:terracotta
fill 472 108 498 472 111 498 minecraft:red_terracotta
setblock 472 108 502 minecraft:terracotta
fill 472 108 503 474 109 503 minecraft:red_terracotta
setblock 475 108 464 minecraft:terracotta
setblock 475 108 504 minecraft:terracotta
fill 476 108 504 479 108 504 minecraft:red_terracotta
fill 479 108 503 480 108 503 minecraft:red_terracotta
setblock 480 108 504 minecraft:terracotta
setblock 481 108 503 minecraft:terracotta
fill 481 108 504 484 108 504 minecraft:red_terracotta
fill 482 108 464 484 108 464 minecraft:red_terracotta
setblock 482 108 502 minecraft:terracotta
fill 482 108 503 485 108 503 minecraft:red_terracotta
fill 483 108 502 486 108 502 minecraft:red_terracotta
fill 484 108 501 487 108 501 minecraft:red_terracotta
setblock 485 108 464 minecraft:terracotta
setblock 485 108 504 minecraft:terracotta
fill 486 108 464 486 111 464 minecraft:red_terracotta
setblock 486 108 503 minecraft:terracotta
fill 486 108 504 486 111 504 minecraft:red_terracotta
setblock 487 108 502 minecraft:terracotta
fill 487 108 503 487 111 503 minecraft:red_terracotta
setblock 488 108 501 minecraft:terracotta
fill 488 108 502 488 111 502 minecraft:red_terracotta
fill 489 108 501 489 111 501 minecraft:red_terracotta
setblock 490 108 504 minecraft:terracotta
setblock 491 108 503 minecraft:terracotta
fill 491 108 504 491 111 504 minecraft:red_terracotta
fill 492 108 503 492 110 503 minecraft:red_terracotta
setblock 505 108 464 minecraft:terracotta
setblock 505 108 504 minecraft:terracotta
fill 506 108 464 506 111 464 minecraft:red_terracotta
fill 506 108 504 509 108 504 minecraft:red_terracotta
fill 507 108 465 508 108 465 minecraft:red_terracotta
fill 507 108 474 507 108 476 minecraft:red_terracotta
setblock 507 108 477 minecraft:terracotta
fill 507 108 478 507 111 478 minecraft:red_terracotta
setblock 508 108 470 minecraft:red_terracotta
setblock 508 108 471 minecraft:terracotta
fill 508 108 472 508 110 472 minecraft:red_terracotta
fill 508 108 474 508 108 475 minecraft:red_terracotta
setblock 508 108 476 minecraft:terracotta
fill 508 108 477 508 111 477 minecraft:red_terracotta
setblock 509 108 465 minecraft:terracotta
fill 509 108 468 509 108 469 minecraft:red_terracotta
setblock 509 108 470 minecraft:terracotta
fill 509 108 471 509 111 471 minecraft:red_terracotta
setblock 509 108 475 minecraft:terracotta
fill 509 108 476 509 111 476 minecraft:red_terracotta
setblock 509 108 479 minecraft:red_terracotta
setblock 509 108 480 minecraft:terracotta
fill 509 108 481 509 111 481 minecraft:red_terracotta
setblock 509 108 495 minecraft:terracotta
fill 509 108 496 509 109 496 minecraft:red_terracotta
fill 509 108 498 509 109 498 minecraft:red_terracotta
setblock 510 108 464 minecraft:terracotta
fill 510 108 465 510 111 465 minecraft:red_terracotta
setblock 510 108 469 minecraft:terracotta
fill 510 108 470 510 111 470 minecraft:red_terracotta
setblock 510 108 474 minecraft:terracotta
fill 510 108 475 510 111 475 minecraft:red_terracotta
setblock 510 108 479 minecraft:terracotta
fill 510 108 480 510 111 480 minecraft:red_terracotta
setblock 510 108 483 minecraft:red_terracotta
setblock 510 108 484 minecraft:terracotta
setblock 510 108 485 minecraft:red_terracotta
setblock 510 108 494 minecraft:terracotta
fill 510 108 495 510 110 495 minecraft:red_terracotta
setblock 510 108 499 minecraft:terracotta
fill 510 108 500 510 111 500 minecraft:red_terracotta
fill 510 108 502 511 108 502 minecraft:red_terracotta
setblock 510 108 504 minecraft:terracotta
fill 511 108 464 511 111 464 minecraft:red_terracotta
setblock 511 108 468 minecraft:terracotta
fill 511 108 469 511 111 469 minecraft:red_terracotta
setblock 511 108 473 minecraft:terracotta
fill 511 108 474 511 111 474 minecraft:red_terracotta
setblock 511 108 478 minecraft:terracotta
fill 511 108 479 511 111 479 minecraft:red_terracotta
setblock 511 108 483 minecraft:terracotta
fill 511 108 484 511 111 484 minecraft:red_terracotta
setblock 511 108 488 minecraft:terracotta
fill 511 108 489 511 109 489 minecraft:red_terracotta
setblock 511 108 493 minecraft:terracotta
fill 511 108 494 511 111 494 minecraft:red_terracotta
setblock 511 108 498 minecraft:terracotta
fill 511 108 499 511 111 499 minecraft:red_terracotta
fill 511 108 501 511 109 501 minecraft:red_terracotta
setblock 511 108 503 minecraft:terracotta
fill 511 108 504 511 111 504 minecraft:red_terracotta
fill 471 109 464 471 109 466 minecraft:red_terracotta
setblock 471 109 467 minecraft:terracotta
fill 471 109 468 471 109 471 minecraft:red_terracotta
setblock 471 109 472 minecraft:terracotta
fill 471 109 473 471 112 473 minecraft:red_terracotta
setblock 471 109 477 minecraft:terracotta
fill 471 109 478 471 112 478 minecraft:red_terracotta
setblock 471 109 481 minecraft:red_terracotta
setblock 471 109 482 minecraft:terracotta
setblock 471 109 483 minecraft:red_terracotta
setblock 471 109 492 minecraft:terracotta
fill 471 109 493 471 110 493 minecraft:red_terracotta
setblock 471 109 497 minecraft:terracotta
fill 471 109 498 471 112 498 minecraft:red_terracotta
setblock 471 109 501 minecraft:red_terracotta
setblock 471 109 502 minecraft:terracotta
fill 471 109 503 471 112 503 minecraft:red_terracotta
fill 472 109 464 472 109 465 minecraft:red_terracotta
setblock 472 109 467 minecraft:red_terracotta
setblock 472 109 471 minecraft:terracotta
fill 472 109 472 472 110 472 minecraft:red_terracotta
setblock 472 109 476 minecraft:terracotta
fill 472 109 477 472 111 477 minecraft:red_terracotta
setblock 472 109 496 minecraft:terracotta
fill 472 109 497 472 111 497 minecraft:red_terracotta
setblock 472 109 501 minecraft:terracotta
fill 472 109 502 472 112 502 minecraft:red_terracotta
setblock 473 109 466 minecraft:light[level=14]
setblock 473 109 474 minecraft:light[level=14]
setblock 473 109 482 minecraft:light[level=14]
setblock 473 109 490 minecraft:light[level=14]
setblock 473 109 498 minecraft:light[level=14]
setblock 474 109 464 minecraft:terracotta
setblock 474 109 504 minecraft:terracotta
fill 475 109 464 475 110 464 minecraft:red_terracotta
setblock 475 109 503 minecraft:terracotta
fill 475 109 504 478 109 504 minecraft:red_terracotta
fill 476 109 503 479 109 503 minecraft:red_terracotta
setblock 479 109 504 minecraft:terracotta
setblock 480 109 503 minecraft:terracotta
fill 480 109 504 483 109 504 minecraft:red_terracotta
fill 481 109 464 483 109 464 minecraft:red_terracotta
setblock 481 109 466 minecraft:light[level=14]
setblock 481 109 474 minecraft:light[level=14]
setblock 481 109 482 minecraft:light[level=14]
setblock 481 109 490 minecraft:light[level=14]
setblock 481 109 498 minecraft:light[level=14]
setblock 481 109 502 minecraft:terracotta
fill 481 109 503 484 109 503 minecraft:red_terracotta
fill 482 109 502 485 109 502 minecraft:red_terracotta
fill 483 109 501 486 109 501 minecraft:red_terracotta
setblock 484 109 464 minecraft:terracotta
setblock 484 109 504 minecraft:terracotta
fill 485 109 464 485 112 464 minecraft:red_terracotta
setblock 485 109 503 minecraft:terracotta
fill 485 109 504 485 112 504 minecraft:red_terracotta
fill 486 109 500 487 109 500 minecraft:red_terracotta
setblock 486 109 502 minecraft:terracotta
fill 486 109 503 486 112 503 minecraft:red_terracotta
setblock 487 109 501 minecraft:terracotta
fill 487 109 502 487 112 502 minecraft:red_terracotta
fill 488 109 501 488 112 501 minecraft:red_terracotta
setblock 489 109 464 minecraft:terracotta
setblock 489 109 466 minecraft:light[level=14]
setblock 489 109 474 minecraft:light[level=14]
setblock 489 109 482 minecraft:light[level=14]
setblock 489 109 490 minecraft:light[level=14]
setblock 489 109 498 minecraft:light[level=14]
setblock 489 109 504 minecraft:terracotta
setblock 490 109 501 minecraft:red_terracotta
setblock 490 109 503 minecraft:terracotta
fill 490 109 504 490 112 504 minecraft:red_terracotta
setblock 491 109 502 minecraft:terracotta
fill 491 109 503 491 112 503 minecraft:red_terracotta
setblock 497 109 466 minecraft:light[level=14]
setblock 497 109 474 minecraft:light[level=14]
setblock 497 109 482 minecraft:light[level=14]
setblock 497 109 490 minecraft:light[level=14]
setblock 497 109 498 minecraft:light[level=14]
setblock 503 109 504 minecraft:red_terracotta
setblock 504 109 464 minecraft:terracotta
setblock 504 109 504 minecraft:terracotta
fill 505 109 464 505 112 464 minecraft:red_terracotta
setblock 505 109 466 minecraft:light[level=14]
setblock 505 109 474 minecraft:light[level=14]
setblock 505 109 482 minecraft:light[level=14]
setblock 505 109 490 minecraft:light[level=14]
setblock 505 109 498 minecraft:light[level=14]
fill 505 109 504 508 109 504 minecraft:red_terracotta
fill 506 109 465 507 109 465 minecraft:red_terracotta
fill 506 109 503 509 109 503 minecraft:red_terracotta
fill 507 109 474 507 109 475 minecraft:red_terracotta
setblock 507 109 476 minecraft:terracotta
fill 507 109 477 507 111 477 minecraft:red_terracotta
setblock 508 109 465 minecraft:terracotta
setblock 508 109 471 minecraft:red_terracotta
setblock 508 109 474 minecraft:red_terracotta
setblock 508 109 475 minecraft:terracotta
fill 508 109 476 508 112 476 minecraft:red_terracotta
fill 508 109 478 508 109 479 minecraft:red_terracotta
setblock 508 109 480 minecraft:terracotta
fill 508 109 481 508 111 481 minecraft:red_terracotta
setblock 509 109 464 minecraft:terracotta
fill 509 109 465 509 112 465 minecraft:red_terracotta
setblock 509 109 468 minecraft:red_terracotta
setblock 509 109 469 minecraft:terracotta
fill 509 109 470 509 111 470 minecraft:red_terracotta
setblock 509 109 474 minecraft:terracotta
fill 509 109 475 509 112 475 minecraft:red_terracotta
setblock 509 109 479 minecraft:terracotta
fill 509 109 480 509 112 480 minecraft:red_terracotta
setblock 509 109 483 minecraft:red_terracotta
setblock 509 109 499 minecraft:terracotta
setblock 509 109 504 minecraft:terracotta
fill 510 109 464 510 112 464 minecraft:red_terracotta
setblock 510 109 468 minecraft:terracotta
fill 510 109 469 510 112 469 minecraft:red_terracotta
setblock 510 109 473 minecraft:terracotta
fill 510 109 474 510 112 474 minecraft:red_terracotta
setblock 510 109 478 minecraft:terracotta
fill 510 109 479 510 112 479 minecraft:red_terracotta
setblock 510 109 483 minecraft:terracotta
fill 510 109 484 510 111 484 minecraft:red_terracotta
setblock 510 109 493 minecraft:terracotta
setblock 510 109 494 minecraft:red_terracotta
setblock 510 109 498 minecraft:terracotta
fill 510 109 499 510 112 499 minecraft:red_terracotta
setblock 510 109 502 minecraft:red_terracotta
setblock 510 109 503 minecraft:terracotta
fill 510 109 504 510 112 504 minecraft:red_terracotta
setblock 511 109 467 minecraft:terracotta
fill 511 109 468 511 112 468 minecraft:red_terracotta
setblock 511 109 472 minecraft:terracotta
fill 511 109 473 511 112 473 minecraft:red_terracotta
setblock 511 109 477 minecraft:terracotta
fill 511 109 478 511 112 478 minecraft:red_terracotta
setblock 511 109 482 minecraft:terracotta
fill 511 109 483 511 112 483 minecraft:red_terracotta
setblock 511 109 487 minecraft:terracotta
setblock 511 109 488 minecraft:red_terracotta
setblock 511 109 492 minecraft:terracotta
fill 511 109 493 511 110 493 minecraft:red_terracotta
setblock 511 109 497 minecraft:terracotta
fill 511 109 498 511 112 498 minecraft:red_terracotta
setblock 511 109 502 minecraft:terracotta
fill 511 109 503 511 112 503 minecraft:red_terracotta
fill 471 110 464 471 110 465 minecraft:red_terracotta
setblock 471 110 466 minecraft:terracotta
fill 471 110 467 471 110 470 minecraft:red_terracotta
setblock 471 110 471 minecraft:terracotta
fill 471 110 472 471 112 472 minecraft:red_terracotta
setblock 471 110 476 minecraft:terracotta
fill 471 110 477 471 113 477 minecraft:red_terracotta
setblock 471 110 481 minecraft:terracotta
fill 471 110 482 471 111 482 minecraft:red_terracotta
setblock 471 110 496 minecraft:terracotta
fill 471 110 497 471 113 497 minecraft:red_terracotta
setblock 471 110 501 minecraft:terracotta
fill 471 110 502 471 113 502 minecraft:red_terracotta
setblock 472 110 464 minecraft:red_terracotta
setblock 472 110 470 minecraft:terracotta
setblock 472 110 471 minecraft:red_terracotta
setblock 472 110 475 minecraft:terracotta
fill 472 110 476 472 111 476 minecraft:red_terracotta
setblock 472 110 496 minecraft:red_terracotta
setblock 472 110 500 minecraft:terracotta
fill 472 110 501 472 113 501 minecraft:red_terracotta
fill 472 110 503 473 110 503 minecraft:red_terracotta
setblock 473 110 464 minecraft:terracotta
setblock 473 110 504 minecraft:terracotta
fill 474 110 464 474 111 464 minecraft:red_terracotta
setblock 474 110 503 minecraft:terracotta
fill 474 110 504 477 110 504 minecraft:red_terracotta
fill 475 110 503 478 110 503 minecraft:red_terracotta
setblock 478 110 504 minecraft:terracotta
setblock 479 110 502 minecraft:red_terracotta
setblock 479 110 503 minecraft:terracotta
fill 479 110 504 482 110 504 minecraft:red_terracotta
fill 480 110 464 482 110 464 minecraft:red_terracotta
setblock 480 110 502 minecraft:terracotta
fill 480 110 503 483 110 503 minecraft:red_terracotta
fill 481 110 502 484 110 502 minecraft:red_terracotta
fill 482 110 501 485 110 501 minecraft:red_terracotta
setblock 483 110 464 minecraft:terracotta
setblock 483 110 504 minecraft:terracotta
fill 484 110 464 484 113 464 minecraft:red_terracotta
setblock 484 110 503 minecraft:terracotta
fill 484 110 504 484 113 504 minecraft:red_terracotta
fill 485 110 500 486 110 500 minecraft:red_terracotta
setblock 485 110 502 minecraft:terracotta
fill 485 110 503 485 113 503 minecraft:red_terracotta
setblock 486 110 501 minecraft:terracotta
fill 486 110 502 486 113 502 minecraft:red_terracotta
setblock 487 110 500 minecraft:terracotta
fill 487 110 501 487 113 501 minecraft:red_terracotta
setblock 488 110 464 minecraft:terracotta
setblock 488 110 504 minecraft:terracotta
setblock 489 110 464 minecraft:red_terracotta
setblock 489 110 503 minecraft:terracotta
fill 489 110 504 489 113 504 minecraft:red_terracotta
setblock 490 110 502 minecraft:terracotta
fill 490 110 503 490 113 503 minecraft:red_terracotta
setblock 491 110 502 minecraft:red_terracotta
setblock 493 110 504 minecraft:terracotta
setblock 502 110 504 minecraft:red_terracotta
setblock 503 110 464 minecraft:terracotta
setblock 503 110 504 minecraft:terracotta
fill 504 110 464 504 113 464 minecraft:red_terracotta
setblock 504 110 503 minecraft:terracotta
fill 504 110 504 507 110 504 minecraft:red_terracotta
fill 505 110 503 508 110 503 minecraft:red_terracotta
setblock 506 110 465 minecraft:red_terracotta
setblock 507 110 465 minecraft:terracotta
setblock 507 110 474 minecraft:red_terracotta
setblock 507 110 475 minecraft:terracotta
fill 507 110 476 507 111 476 minecraft:red_terracotta
setblock 507 110 479 minecraft:red_terracotta
setblock 508 110 464 minecraft:terracotta
fill 508 110 465 508 113 465 minecraft:red_terracotta
setblock 508 110 474 minecraft:terracotta
fill 508 110 475 508 112 475 minecraft:red_terracotta
setblock 508 110 478 minecraft:red_terracotta
setblock 508 110 479 minecraft:terracotta
fill 508 110 480 508 112 480 minecraft:red_terracotta
setblock 508 110 504 minecraft:terracotta
fill 509 110 464 509 113 464 minecraft:red_terracotta
setblock 509 110 469 minecraft:red_terracotta
setblock 509 110 473 minecraft:terracotta
fill 509 110 474 509 113 474 minecraft:red_terracotta
setblock 509 110 478 minecraft:terracotta
fill 509 110 479 509 113 479 minecraft:red_terracotta
setblock 509 110 483 minecraft:terracotta
setblock 509 110 503 minecraft:terracotta
fill 509 110 504 509 113 504 minecraft:red_terracotta
setblock 510 110 467 minecraft:terracotta
fill 510 110 468 510 111 468 minecraft:red_terracotta
setblock 510 110 472 minecraft:terracotta
fill 510 110 473 510 113 473 minecraft:red_terracotta
setblock 510 110 477 minecraft:terracotta
fill 510 110 478 510 113 478 minecraft:red_terracotta
setblock 510 110 482 minecraft:terracotta
fill 510 110 483 510 112 483 minecraft:red_terracotta
setblock 510 110 497 minecraft:terracotta
fill 510 110 498 510 111 498 minecraft:red_terracotta
setblock 510 110 502 minecraft:terracotta
fill 510 110 503 510 112 503 minecraft:red_terracotta
setblock 511 110 466 minecraft:terracotta
fill 511 110 467 511 113 467 minecraft:red_terracotta
setblock 511 110 471 minecraft:terracotta
fill 511 110 472 511 113 472 minecraft:red_terracotta
setblock 511 110 476 minecraft:terracotta
fill 511 110 477 511 113 477 minecraft:red_terracotta
setblock 511 110 481 minecraft:terracotta
fill 511 110 482 511 113 482 minecraft:red_terracotta
setblock 511 110 486 minecraft:terracotta
setblock 511 110 492 minecraft:red_terracotta
setblock 511 110 496 minecraft:terracotta
fill 511 110 497 511 112 497 minecraft:red_terracotta
setblock 511 110 501 minecraft:terracotta
fill 511 110 502 511 113 502 minecraft:red_terracotta
setblock 471 111 464 minecraft:red_terracotta
setblock 471 111 465 minecraft:terracotta
fill 471 111 466 471 111 469 minecraft:red_terracotta
setblock 471 111 470 minecraft:terracotta
fill 471 111 471 471 112 471 minecraft:red_terracotta
setblock 471 111 475 minecraft:terracotta
fill 471 111 476 471 113 476 minecraft:red_terracotta
setblock 471 111 480 minecraft:terracotta
fill 471 111 481 471 113 481 minecraft:red_terracotta
setblock 471 111 495 minecraft:terracotta
fill 471 111 496 471 113 496 minecraft:red_terracotta
setblock 471 111 500 minecraft:terracotta
fill 471 111 501 471 114 501 minecraft:red_terracotta
setblock 472 111 464 minecraft:terracotta
setblock 472 111 474 minecraft:terracotta
setblock 472 111 475 minecraft:red_terracotta
setblock 472 111 499 minecraft:terracotta
fill 472 111 500 472 114 500 minecraft:red_terracotta
setblock 472 111 503 minecraft:red_terracotta
setblock 472 111 504 minecraft:terracotta
fill 473 111 464 473 113 464 minecraft:red_terracotta
setblock 473 111 503 minecraft:terracotta
fill 473 111 504 476 111 504 minecraft:red_terracotta
fill 474 111 503 477 111 503 minecraft:red_terracotta
setblock 477 111 504 minecraft:terracotta
setblock 478 111 503 minecraft:terracotta
fill 478 111 504 481 111 504 minecraft:red_terracotta
setblock 479 111 502 minecraft:terracotta
fill 479 111 503 482 111 503 minecraft:red_terracotta
fill 480 111 464 481 111 464 minecraft:red_terracotta
fill 480 111 502 483 111 502 minecraft:red_terracotta
fill 481 111 501 484 111 501 minecraft:red_terracotta
setblock 482 111 464 minecraft:terracotta
setblock 482 111 504 minecraft:terracotta
fill 483 111 464 483 114 464 minecraft:red_terracotta
setblock 483 111 503 minecraft:terracotta
fill 483 111 504 483 114 504 minecraft:red_terracotta
fill 484 111 500 485 111 500 minecraft:red_terracotta
setblock 484 111 502 minecraft:terracotta
fill 484 111 503 484 114 503 minecraft:red_terracotta
setblock 485 111 501 minecraft:terracotta
fill 485 111 502 485 114 502 minecraft:red_terracotta
setblock 486 111 500 minecraft:terracotta
fill 486 111 501 486 113 501 minecraft:red_terracotta
setblock 487 111 464 minecraft:terracotta
setblock 487 111 504 minecraft:terracotta
fill 488 111 464 488 112 464 minecraft:red_terracotta
setblock 488 111 503 minecraft:terracotta
fill 488 111 504 488 114 504 minecraft:red_terracotta
setblock 489 111 502 minecraft:terracotta
fill 489 111 503 489 114 503 minecraft:red_terracotta
setblock 490 111 502 minecraft:red_terracotta
setblock 492 111 504 minecraft:terracotta
setblock 493 111 504 minecraft:red_terracotta
setblock 501 111 504 minecraft:red_terracotta
setblock 502 111 504 minecraft:terracotta
fill 503 111 464 503 114 464 minecraft:red_terracotta
fill 503 111 504 506 111 504 minecraft:red_terracotta
fill 504 111 503 507 111 503 minecraft:red_terracotta
setblock 505 111 465 minecraft:red_terracotta
setblock 506 111 465 minecraft:terracotta
setblock 507 111 464 minecraft:terracotta
fill 507 111 465 507 114 465 minecraft:red_terracotta
setblock 507 111 504 minecraft:terracotta
fill 508 111 464 508 114 464 minecraft:red_terracotta
setblock 508 111 473 minecraft:terracotta
fill 508 111 474 508 112 474 minecraft:red_terracotta
setblock 508 111 478 minecraft:terracotta
fill 508 111 479 508 113 479 minecraft:red_terracotta
setblock 508 111 503 minecraft:terracotta
fill 508 111 504 508 114 504 minecraft:red_terracotta
setblock 509 111 472 minecraft:terracotta
fill 509 111 473 509 112 473 minecraft:red_terracotta
setblock 509 111 477 minecraft:terracotta
fill 509 111 478 509 114 478 minecraft:red_terracotta
setblock 509 111 482 minecraft:terracotta
fill 509 111 503 509 113 503 minecraft:red_terracotta
setblock 510 111 466 minecraft:terracotta
setblock 510 111 467 minecraft:red_terracotta
setblock 510 111 471 minecraft:terracotta
fill 510 111 472 510 113 472 minecraft:red_terracotta
setblock 510 111 476 minecraft:terracotta
fill 510 111 477 510 114 477 minecraft:red_terracotta
setblock 510 111 481 minecraft:terracotta
fill 510 111 482 510 113 482 minecraft:red_terracotta
setblock 510 111 497 minecraft:red_terracotta
setblock 510 111 501 minecraft:terracotta
fill 510 111 502 510 112 502 minecraft:red_terracotta
setblock 511 111 465 minecraft:terracotta
fill 511 111 466 511 114 466 minecraft:red_terracotta
setblock 511 111 470 minecraft:terracotta
fill 511 111 471 511 113 471 minecraft:red_terracotta
setblock 511 111 475 minecraft:terracotta
fill 511 111 476 511 114 476 minecraft:red_terracotta
setblock 511 111 480 minecraft:terracotta
fill 511 111 481 511 114 481 minecraft:red_terracotta
setblock 511 111 485 minecraft:terracotta
setblock 511 111 495 minecraft:terracotta
fill 511 111 496 511 112 496 minecraft:red_terracotta
setblock 511 111 500 minecraft:terracotta
fill 511 111 501 511 114 501 minecraft:red_terracotta
setblock 471 112 464 minecraft:terracotta
fill 471 112 465 471 112 468 minecraft:red_terracotta
setblock 471 112 469 minecraft:terracotta
setblock 471 112 470 minecraft:red_terracotta
setblock 471 112 474 minecraft:terracotta
fill 471 112 475 471 113 475 minecraft:red_terracotta
setblock 471 112 479 minecraft:terracotta
fill 471 112 480 471 113 480 minecraft:red_terracotta
setblock 471 112 495 minecraft:red_terracotta
setblock 471 112 499 minecraft:terracotta
fill 471 112 500 471 115 500 minecraft:red_terracotta
setblock 471 112 504 minecraft:terracotta
fill 472 112 464 472 115 464 minecraft:red_terracotta
setblock 472 112 498 minecraft:terracotta
fill 472 112 499 472 113 499 minecraft:red_terracotta
setblock 472 112 503 minecraft:terracotta
fill 472 112 504 475 112 504 minecraft:red_terracotta
fill 473 112 503 476 112 503 minecraft:red_terracotta
setblock 476 112 504 minecraft:terracotta
setblock 477 112 503 minecraft:terracotta
fill 477 112 504 480 112 504 minecraft:red_terracotta
setblock 478 112 502 minecraft:terracotta
fill 478 112 503 481 112 503 minecraft:red_terracotta
fill 479 112 464 480 112 464 minecraft:red_terracotta
fill 479 112 502 482 112 502 minecraft:red_terracotta
setblock 481 112 464 minecraft:terracotta
fill 481 112 501 483 112 501 minecraft:red_terracotta
setblock 481 112 504 minecraft:terracotta
fill 482 112 464 482 115 464 minecraft:red_terracotta
setblock 482 112 503 minecraft:terracotta
fill 482 112 504 482 115 504 minecraft:red_terracotta
setblock 483 112 502 minecraft:terracotta
fill 483 112 503 483 115 503 minecraft:red_terracotta
setblock 484 112 501 minecraft:terracotta
fill 484 112 502 484 115 502 minecraft:red_terracotta
fill 485 112 501 485 114 501 minecraft:red_terracotta
setblock 486 112 464 minecraft:terracotta
setblock 486 112 504 minecraft:terracotta
fill 487 112 464 487 113 464 minecraft:red_terracotta
setblock 487 112 503 minecraft:terracotta
fill 487 112 504 487 115 504 minecraft:red_terracotta
setblock 488 112 502 minecraft:terracotta
fill 488 112 503 488 115 503 minecraft:red_terracotta
fill 489 112 502 489 113 502 minecraft:red_terracotta
setblock 491 112 504 minecraft:terracotta
setblock 492 112 504 minecraft:red_terracotta
setblock 501 112 504 minecraft:terracotta
fill 502 112 464 502 115 464 minecraft:red_terracotta
fill 502 112 504 505 112 504 minecraft:red_terracotta
fill 503 112 503 506 112 503 minecraft:red_terracotta
setblock 505 112 465 minecraft:terracotta
setblock 506 112 464 minecraft:terracotta
fill 506 112 465 506 115 465 minecraft:red_terracotta
setblock 506 112 504 minecraft:terracotta
fill 507 112 464 507 115 464 minecraft:red_terracotta
setblock 507 112 503 minecraft:terracotta
fill 507 112 504 507 115 504 minecraft:red_terracotta
setblock 508 112 477 minecraft:terracotta
fill 508 112 478 508 113 478 minecraft:red_terracotta
fill 508 112 503 508 114 503 minecraft:red_terracotta
setblock 509 112 472 minecraft:red_terracotta
setblock 509 112 476 minecraft:terracotta
fill 509 112 477 509 114 477 minecraft:red_terracotta
setblock 509 112 481 minecraft:terracotta
setblock 509 112 482 minecraft:red_terracotta
setblock 510 112 470 minecraft:terracotta
setblock 510 112 471 minecraft:red_terracotta
setblock 510 112 475 minecraft:terracotta
fill 510 112 476 510 114 476 minecraft:red_terracotta
setblock 510 112 480 minecraft:terracotta
fill 510 112 481 510 114 481 minecraft:red_terracotta
setblock 510 112 500 minecraft:terracotta
setblock 510 112 501 minecraft:red_terracotta
setblock 511 112 464 minecraft:terracotta
fill 511 112 465 511 115 465 minecraft:red_terracotta
setblock 511 112 469 minecraft:terracotta
fill 511 112 470 511 113 470 minecraft:red_terracotta
setblock 511 112 474 minecraft:terracotta
fill 511 112 475 511 115 475 minecraft:red_terracotta
setblock 511 112 479 minecraft:terracotta
fill 511 112 480 511 115 480 minecraft:red_terracotta
setblock 511 112 484 minecraft:terracotta
setblock 511 112 499 minecraft:terracotta
fill 511 112 500 511 114 500 minecraft:red_terracotta
setblock 511 112 504 minecraft:terracotta
fill 471 113 464 471 113 466 minecraft:red_terracotta
setblock 471 113 474 minecraft:red_terracotta
setblock 471 113 478 minecraft:terracotta
setblock 471 113 479 minecraft:red_terracotta
setblock 471 113 498 minecraft:terracotta
fill 471 113 499 471 116 499 minecraft:red_terracotta
setblock 471 113 503 minecraft:terracotta
fill 471 113 504 474 113 504 minecraft:red_terracotta
setblock 472 113 502 minecraft:terracotta
fill 472 113 503 475 113 503 minecraft:red_terracotta
fill 474 113 493 475 114 494 minecraft:orange_concrete
setblock 475 113 504 minecraft:terracotta
setblock 476 113 503 minecraft:terracotta
fill 476 113 504 479 113 504 minecraft:red_terracotta
fill 477 113 503 480 113 503 minecraft:red_terracotta
fill 478 113 502 481 113 502 minecraft:red_terracotta
setblock 479 113 464 minecraft:red_terracotta
setblock 480 113 464 minecraft:terracotta
setblock 480 113 504 minecraft:terracotta
fill 481 113 464 481 116 464 minecraft:red_terracotta
fill 481 113 501 482 113 501 minecraft:red_terracotta
setblock 481 113 503 minecraft:terracotta
fill 481 113 504 481 116 504 minecraft:red_terracotta
setblock 482 113 502 minecraft:terracotta
fill 482 113 503 482 116 503 minecraft:red_terracotta
setblock 483 113 501 minecraft:terracotta
fill 483 113 502 483 116 502 minecraft:red_terracotta
fill 484 113 501 484 115 501 minecraft:red_terracotta
setblock 485 113 464 minecraft:terracotta
setblock 485 113 504 minecraft:terracotta
fill 486 113 464 486 116 464 minecraft:red_terracotta
setblock 486 113 503 minecraft:terracotta
fill 486 113 504 486 116 504 minecraft:red_terracotta
setblock 487 113 502 minecraft:terracotta
fill 487 113 503 487 116 503 minecraft:red_terracotta
fill 488 113 502 488 114 502 minecraft:red_terracotta
setblock 490 113 504 minecraft:terracotta
fill 491 113 504 491 114 504 minecraft:red_terracotta
setblock 500 113 504 minecraft:terracotta
fill 501 113 504 504 113 504 minecraft:red_terracotta
fill 503 113 503 505 113 503 minecraft:red_terracotta
setblock 505 113 464 minecraft:terracotta
fill 505 113 465 505 116 465 minecraft:red_terracotta
setblock 505 113 504 minecraft:terracotta
fill 506 113 464 506 116 464 minecraft:red_terracotta
setblock 506 113 503 minecraft:terracotta
fill 506 113 504 506 116 504 minecraft:red_terracotta
fill 507 113 503 507 115 503 minecraft:red_terracotta
setblock 508 113 477 minecraft:red_terracotta
setblock 509 113 475 minecraft:terracotta
setblock 509 113 476 minecraft:red_terracotta
setblock 509 113 480 minecraft:terracotta
setblock 509 113 481 minecraft:red_terracotta
setblock 510 113 464 minecraft:terracotta
setblock 510 113 474 minecraft:terracotta
fill 510 113 475 510 114 475 minecraft:red_terracotta
setblock 510 113 479 minecraft:terracotta
fill 510 113 480 510 115 480 minecraft:red_terracotta
setblock 510 113 504 minecraft:terracotta
fill 511 113 464 511 116 464 minecraft:red_terracotta
setblock 511 113 468 minecraft:terracotta
setblock 511 113 469 minecraft:red_terracotta
setblock 511 113 473 minecraft:terracotta
fill 511 113 474 511 114 474 minecraft:red_terracotta
setblock 511 113 478 minecraft:terracotta
fill 511 113 479 511 116 479 minecraft:red_terracotta
setblock 511 113 483 minecraft:terracotta
setblock 511 113 498 minecraft:terracotta
setblock 511 113 499 minecraft:red_terracotta
setblock 511 113 503 minecraft:terracotta
fill 511 113 504 511 116 504 minecraft:red_terracotta
fill 471 114 464 471 114 465 minecraft:red_terracotta
setblock 471 114 497 minecraft:terracotta
fill 471 114 498 471 115 498 minecraft:red_terracotta
setblock 471 114 502 minecraft:terracotta
fill 471 114 503 473 114 504 minecraft:red_terracotta
setblock 472 114 501 minecraft:terracotta
fill 472 114 502 472 115 502 minecraft:red_terracotta
setblock 474 114 503 minecraft:red_terracotta
setblock 474 114 504 minecraft:terracotta
setblock 475 114 503 minecraft:terracotta
fill 475 114 504 478 114 504 minecraft:red_terracotta
fill 476 114 503 479 114 503 minecraft:red_terracotta
fill 478 114 502 480 114 502 minecraft:red_terracotta
setblock 479 114 464 minecraft:terracotta
setblock 479 114 504 minecraft:terracotta
fill 480 114 464 480 117 464 minecraft:red_terracotta
setblock 480 114 503 minecraft:terracotta
fill 480 114 504 480 117 504 minecraft:red_terracotta
setblock 481 114 501 minecraft:red_terracotta
setblock 481 114 502 minecraft:terracotta
fill 481 114 503 481 117 503 minecraft:red_terracotta
setblock 482 114 501 minecraft:terracotta
fill 482 114 502 482 117 502 minecraft:red_terracotta
fill 483 114 501 483 115 501 minecraft:red_terracotta
setblock 484 114 464 minecraft:terracotta
setblock 484 114 504 minecraft:terracotta
fill 485 114 464 485 117 464 minecraft:red_terracotta
setblock 485 114 503 minecraft:terracotta
fill 485 114 504 485 117 504 minecraft:red_terracotta
setblock 486 114 502 minecraft:terracotta
fill 486 114 503 486 117 503 minecraft:red_terracotta
fill 487 114 502 487 115 502 minecraft:red_terracotta
setblock 489 114 504 minecraft:terracotta
fill 490 114 504 490 116 504 minecraft:red_terracotta
fill 500 114 504 503 114 504 minecraft:red_terracotta
fill 501 114 464 501 116 464 minecraft:red_terracotta
fill 503 114 503 504 114 503 minecraft:red_terracotta
setblock 504 114 464 minecraft:terracotta
fill 504 114 465 504 117 465 minecraft:red_terracotta
setblock 504 114 504 minecraft:terracotta
fill 505 114 464 505 117 464 minecraft:red_terracotta
setblock 505 114 503 minecraft:terracotta
fill 505 114 504 505 117 504 minecraft:red_terracotta
fill 506 114 503 506 117 503 minecraft:red_terracotta
setblock 508 114 465 minecraft:terracotta
setblock 509 114 464 minecraft:terracotta
setblock 509 114 479 minecraft:terracotta
setblock 509 114 504 minecraft:terracotta
fill 510 114 464 510 117 464 minecraft:red_terracotta
setblock 510 114 474 minecraft:red_terracotta
setblock 510 114 478 minecraft:terracotta
fill 510 114 479 510 115 479 minecraft:red_terracotta
fill 510 114 504 510 117 504 minecraft:red_terracotta
setblock 511 114 472 minecraft:terracotta
setblock 511 114 473 minecraft:red_terracotta
setblock 511 114 477 minecraft:terracotta
fill 511 114 478 511 116 478 minecraft:red_terracotta
setblock 511 114 482 minecraft:terracotta
setblock 511 114 483 minecraft:red_terracotta
setblock 511 114 502 minecraft:terracotta
fill 511 114 503 511 117 503 minecraft:red_terracotta
fill 471 115 464 471 116 464 minecraft:red_terracotta
setblock 471 115 501 minecraft:terracotta
fill 471 115 502 471 116 504 minecraft:red_terracotta
fill 472 115 503 472 115 504 minecraft:red_terracotta
setblock 473 115 503 minecraft:red_terracotta
setblock 473 115 504 minecraft:terracotta
setblock 474 115 503 minecraft:terracotta
fill 474 115 504 477 115 504 minecraft:red_terracotta
fill 475 115 503 478 115 503 minecraft:red_terracotta
setblock 478 115 464 minecraft:terracotta
fill 478 115 502 479 115 502 minecraft:red_terracotta
setblock 478 115 504 minecraft:terracotta
fill 479 115 464 479 118 464 minecraft:red_terracotta
fill 479 115 477 481 116 478 minecraft:orange_concrete
setblock 479 115 503 minecraft:terracotta
fill 479 115 504 479 118 504 minecraft:red_terracotta
setblock 480 115 502 minecraft:terracotta
fill 480 115 503 480 118 503 minecraft:red_terracotta
fill 481 115 502 481 118 502 minecraft:red_terracotta
setblock 482 115 501 minecraft:red_terracotta
setblock 483 115 464 minecraft:terracotta
setblock 483 115 504 minecraft:terracotta
fill 484 115 464 484 118 464 minecraft:red_terracotta
setblock 484 115 503 minecraft:terracotta
fill 484 115 504 484 118 504 minecraft:red_terracotta
setblock 485 115 502 minecraft:terracotta
fill 485 115 503 485 118 503 minecraft:red_terracotta
fill 486 115 502 486 116 502 minecraft:red_terracotta
setblock 488 115 504 minecraft:terracotta
fill 489 115 504 489 118 504 minecraft:red_terracotta
fill 497 115 489 498 116 489 minecraft:magma_block
fill 499 115 504 502 115 504 minecraft:red_terracotta
fill 500 115 464 500 117 464 minecraft:red_terracotta
fill 502 115 503 503 115 503 minecraft:red_terracotta
setblock 503 115 464 minecraft:terracotta
fill 503 115 465 503 118 465 minecraft:red_terracotta
setblock 503 115 504 minecraft:terracotta
fill 504 115 464 504 118 464 minecraft:red_terracotta
setblock 504 115 503 minecraft:terracotta
fill 504 115 504 504 118 504 minecraft:red_terracotta
fill 505 115 503 505 118 503 minecraft:red_terracotta
setblock 507 115 465 minecraft:terracotta
setblock 508 115 464 minecraft:terracotta
setblock 508 115 504 minecraft:terracotta
fill 509 115 464 509 118 464 minecraft:red_terracotta
fill 509 115 504 509 118 504 minecraft:red_terracotta
setblock 510 115 478 minecraft:red_terracotta
setblock 511 115 476 minecraft:terracotta
fill 511 115 477 511 116 477 minecraft:red_terracotta
setblock 511 115 481 minecraft:terracotta
setblock 511 115 482 minecraft:red_terracotta
setblock 511 115 501 minecraft:terracotta
fill 511 115 502 511 118 502 minecraft:red_terracotta
setblock 471 116 500 minecraft:terracotta
fill 471 116 501 471 119 501 minecraft:red_terracotta
setblock 472 116 464 minecraft:terracotta
setblock 472 116 503 minecraft:red_terracotta
setblock 472 116 504 minecraft:terracotta
setblock 473 116 503 minecraft:terracotta
fill 473 116 504 476 116 504 minecraft:red_terracotta
fill 474 116 503 477 116 503 minecraft:red_terracotta
setblock 477 116 464 minecraft:terracotta
setblock 477 116 504 minecraft:terracotta
fill 478 116 464 478 119 464 minecraft:red_terracotta
setblock 478 116 502 minecraft:red_terracotta
setblock 478 116 503 minecraft:terracotta
fill 478 116 504 478 119 504 minecraft:red_terracotta
setblock 479 116 502 minecraft:terracotta
fill 479 116 503 479 119 503 minecraft:red_terracotta
fill 480 116 502 480 119 502 minecraft:red_terracotta
setblock 482 116 464 minecraft:terracotta
setblock 482 116 504 minecraft:terracotta
fill 483 116 464 483 119 464 minecraft:red_terracotta
setblock 483 116 503 minecraft:terracotta
fill 483 116 504 483 119 504 minecraft:red_terracotta
setblock 484 116 502 minecraft:terracotta
fill 484 116 503 484 119 503 minecraft:red_terracotta
fill 485 116 502 485 118 502 minecraft:red_terracotta
setblock 487 116 504 minecraft:terracotta
setblock 488 116 503 minecraft:terracotta
fill 488 116 504 488 119 504 minecraft:red_terracotta
fill 499 116 464 499 118 464 minecraft:red_terracotta
fill 499 116 504 501 116 504 minecraft:red_terracotta
setblock 502 116 464 minecraft:terracotta
fill 502 116 465 502 119 465 minecraft:red_terracotta
setblock 502 116 503 minecraft:red_terracotta
setblock 502 116 504 minecraft:terracotta
fill 503 116 464 503 119 464 minecraft:red_terracotta
setblock 503 116 503 minecraft:terracotta
fill 503 116 504 503 119 504 minecraft:red_terracotta
fill 504 116 503 504 119 503 minecraft:red_terracotta
setblock 506 116 465 minecraft:terracotta
fill 506 116 480 509 149 482 minecraft:terracotta
setblock 507 116 464 minecraft:terracotta
fill 507 116 465 507 119 465 minecraft:red_terracotta
fill 507 116 479 508 160 479 minecraft:terracotta
fill 507 116 483 508 160 483 minecraft:terracotta
setblock 507 116 504 minecraft:terracotta
fill 508 116 464 508 119 464 minecraft:red_terracotta
fill 508 116 504 508 119 504 minecraft:red_terracotta
setblock 511 116 465 minecraft:terracotta
setblock 511 116 480 minecraft:terracotta
setblock 511 116 481 minecraft:red_terracotta
setblock 471 117 464 minecraft:terracotta
fill 471 117 500 471 120 500 minecraft:red_terracotta
fill 471 117 502 471 117 503 minecraft:red_terracotta
setblock 471 117 504 minecraft:terracotta
fill 472 117 464 475 117 464 minecraft:red_terracotta
setblock 472 117 503 minecraft:terracotta
fill 472 117 504 475 117 504 minecraft:red_terracotta
setblock 473 117 466 minecraft:light[level=14]
setblock 473 117 474 minecraft:light[level=14]
setblock 473 117 482 minecraft:light[level=14]
setblock 473 117 490 minecraft:light[level=14]
setblock 473 117 498 minecraft:light[level=14]
fill 473 117 503 476 117 503 minecraft:red_terracotta
setblock 476 117 464 minecraft:terracotta
setblock 476 117 504 minecraft:terracotta
fill 477 117 464 477 120 464 minecraft:red_terracotta
setblock 477 117 502 minecraft:red_terracotta
setblock 477 117 503 minecraft:terracotta
fill 477 117 504 477 120 504 minecraft:red_terracotta
setblock 478 117 502 minecraft:terracotta
fill 478 117 503 478 120 503 minecraft:red_terracotta
fill 479 117 502 479 120 502 minecraft:red_terracotta
setblock 481 117 464 minecraft:terracotta
setblock 481 117 466 minecraft:light[level=14]
setblock 481 117 474 minecraft:light[level=14]
setblock 481 117 482 minecraft:light[level=14]
setblock 481 117 490 minecraft:light[level=14]
setblock 481 117 498 minecraft:light[level=14]
setblock 481 117 504 minecraft:terracotta
fill 482 117 464 482 120 464 minecraft:red_terracotta
setblock 482 117 503 minecraft:terracotta
fill 482 117 504 482 120 504 minecraft:red_terracotta
setblock 483 117 502 minecraft:terracotta
fill 483 117 503 483 120 503 minecraft:red_terracotta
fill 484 117 502 484 120 502 minecraft:red_terracotta
setblock 486 117 464 minecraft:terracotta
setblock 486 117 504 minecraft:terracotta
setblock 487 117 503 minecraft:terracotta
fill 487 117 504 487 120 504 minecraft:red_terracotta
setblock 489 117 466 minecraft:light[level=14]
setblock 489 117 474 minecraft:light[level=14]
setblock 489 117 482 minecraft:light[level=14]
setblock 489 117 490 minecraft:light[level=14]
setblock 489 117 498 minecraft:light[level=14]
setblock 497 117 466 minecraft:light[level=14]
setblock 497 117 474 minecraft:light[level=14]
setblock 497 117 482 minecraft:light[level=14]
setblock 497 117 490 minecraft:light[level=14]
setblock 497 117 498 minecraft:light[level=14]
fill 498 117 464 498 119 464 minecraft:red_terracotta
fill 498 117 504 500 117 504 minecraft:red_terracotta
setblock 501 117 464 minecraft:terracotta
fill 501 117 465 501 120 465 minecraft:red_terracotta
setblock 501 117 503 minecraft:red_terracotta
setblock 501 117 504 minecraft:terracotta
fill 502 117 464 502 120 464 minecraft:red_terracotta
setblock 502 117 503 minecraft:terracotta
fill 502 117 504 502 120 504 minecraft:red_terracotta
fill 503 117 503 503 120 503 minecraft:red_terracotta
setblock 505 117 465 minecraft:terracotta
setblock 505 117 466 minecraft:light[level=14]
setblock 505 117 474 minecraft:light[level=14]
fill 505 117 480 505 118 483 minecraft:brown_terracotta
setblock 505 117 490 minecraft:light[level=14]
setblock 505 117 498 minecraft:light[level=14]
setblock 506 117 464 minecraft:terracotta
fill 506 117 465 506 120 465 minecraft:red_terracotta
fill 506 117 479 506 118 479 minecraft:brown_terracotta
fill 506 117 483 506 118 483 minecraft:brown_terracotta
setblock 506 117 504 minecraft:terracotta
fill 507 117 464 507 120 464 minecraft:red_terracotta
fill 507 117 484 508 118 484 minecraft:brown_terracotta
fill 507 117 504 507 120 504 minecraft:red_terracotta
fill 508 117 465 508 118 465 minecraft:red_terracotta
fill 509 117 479 509 118 479 minecraft:brown_terracotta
fill 509 117 483 509 118 483 minecraft:brown_terracotta
fill 510 117 480 510 118 482 minecraft:brown_terracotta
schedule function dropper:buildpart/118_4 1t
