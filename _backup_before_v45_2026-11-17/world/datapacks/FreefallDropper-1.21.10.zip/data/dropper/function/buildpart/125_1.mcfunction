setblock 248 129 552 minecraft:crying_obsidian
fill 249 129 552 249 135 552 minecraft:obsidian
setblock 253 129 510 minecraft:crying_obsidian
fill 255 129 510 255 135 510 minecraft:obsidian
fill 257 129 546 258 130 547 minecraft:obsidian
setblock 263 129 552 minecraft:amethyst_block
setblock 265 129 510 minecraft:white_concrete
fill 265 129 552 265 135 552 minecraft:obsidian
fill 271 129 510 271 135 510 minecraft:obsidian
setblock 274 129 552 minecraft:amethyst_block
fill 275 129 552 276 151 552 minecraft:obsidian
fill 277 129 520 277 135 521 minecraft:obsidian
fill 277 129 536 277 135 536 minecraft:obsidian
setblock 277 129 544 minecraft:crying_obsidian
setblock 235 130 518 minecraft:white_concrete
fill 235 130 548 235 151 548 minecraft:obsidian
fill 239 130 524 240 130 524 minecraft:bone_block
fill 239 130 537 240 130 537 minecraft:bone_block
fill 240 130 525 240 131 528 minecraft:bone_block
fill 240 130 536 240 131 536 minecraft:bone_block
fill 241 130 529 243 135 529 minecraft:bone_block
fill 242 130 524 242 131 524 minecraft:bone_block
setblock 243 130 523 minecraft:bone_block
fill 243 130 525 244 131 525 minecraft:bone_block
setblock 244 130 524 minecraft:bone_block
fill 244 130 528 244 133 528 minecraft:bone_block
setblock 248 130 510 minecraft:white_concrete
fill 248 130 552 248 140 552 minecraft:obsidian
fill 253 130 510 253 145 510 minecraft:obsidian
fill 263 130 552 263 154 552 minecraft:obsidian
fill 265 130 510 265 154 510 minecraft:obsidian
fill 266 130 529 267 131 530 minecraft:amethyst_block
fill 274 130 552 274 154 552 minecraft:obsidian
setblock 277 130 519 minecraft:crying_obsidian
fill 277 130 544 277 155 544 minecraft:obsidian
setblock 277 130 546 minecraft:white_concrete
fill 235 131 518 235 135 518 minecraft:obsidian
setblock 235 131 547 minecraft:crying_obsidian
setblock 238 131 513 minecraft:light[level=12]
setblock 238 131 521 minecraft:light[level=12]
setblock 238 131 529 minecraft:light[level=12]
setblock 238 131 537 minecraft:light[level=12]
setblock 238 131 545 minecraft:light[level=12]
setblock 239 131 536 minecraft:bone_block
setblock 240 131 510 minecraft:amethyst_block
setblock 240 131 524 minecraft:bone_block
fill 240 131 529 240 135 529 minecraft:bone_block
fill 240 131 535 240 132 535 minecraft:bone_block
setblock 240 131 537 minecraft:bone_block
fill 241 131 525 241 131 526 minecraft:bone_block
fill 241 131 530 243 136 530 minecraft:bone_block
setblock 246 131 513 minecraft:light[level=12]
setblock 246 131 521 minecraft:light[level=12]
setblock 246 131 529 minecraft:light[level=12]
setblock 246 131 537 minecraft:light[level=12]
setblock 246 131 545 minecraft:light[level=12]
fill 248 131 510 248 152 510 minecraft:obsidian
setblock 249 131 510 minecraft:amethyst_block
setblock 254 131 513 minecraft:light[level=12]
setblock 254 131 521 minecraft:light[level=12]
setblock 254 131 529 minecraft:light[level=12]
setblock 254 131 537 minecraft:light[level=12]
setblock 254 131 545 minecraft:light[level=12]
setblock 262 131 513 minecraft:light[level=12]
setblock 262 131 521 minecraft:light[level=12]
setblock 262 131 529 minecraft:light[level=12]
setblock 262 131 537 minecraft:light[level=12]
setblock 262 131 545 minecraft:light[level=12]
setblock 266 131 552 minecraft:crying_obsidian
setblock 270 131 513 minecraft:light[level=12]
setblock 270 131 521 minecraft:light[level=12]
setblock 270 131 529 minecraft:light[level=12]
setblock 270 131 537 minecraft:light[level=12]
setblock 270 131 545 minecraft:light[level=12]
fill 277 131 519 277 154 519 minecraft:obsidian
fill 277 131 546 277 138 546 minecraft:obsidian
fill 235 132 547 235 150 547 minecraft:obsidian
fill 240 132 510 240 146 510 minecraft:obsidian
fill 240 132 526 240 132 528 minecraft:bone_block
fill 240 132 530 240 136 530 minecraft:bone_block
fill 240 132 533 241 132 534 minecraft:bone_block
setblock 241 132 526 minecraft:bone_block
fill 241 132 531 243 137 531 minecraft:bone_block
setblock 241 132 535 minecraft:bone_block
fill 243 132 525 243 132 526 minecraft:bone_block
fill 244 132 529 244 133 529 minecraft:bone_block
fill 249 132 510 249 153 510 minecraft:obsidian
setblock 266 132 552 minecraft:obsidian
setblock 277 132 526 minecraft:white_concrete
setblock 277 132 545 minecraft:amethyst_block
setblock 277 132 550 minecraft:white_concrete
fill 240 133 528 240 134 528 minecraft:bone_block
fill 240 133 531 240 133 533 minecraft:bone_block
setblock 240 133 552 minecraft:amethyst_block
fill 241 133 532 241 133 534 minecraft:bone_block
fill 242 133 526 242 133 527 minecraft:bone_block
fill 242 133 532 243 138 532 minecraft:bone_block
setblock 243 133 527 minecraft:bone_block
setblock 266 133 552 minecraft:amethyst_block
fill 277 133 526 277 150 526 minecraft:obsidian
fill 277 133 545 277 152 545 minecraft:obsidian
fill 277 133 550 277 155 550 minecraft:obsidian
fill 240 134 531 240 137 532 minecraft:bone_block
fill 240 134 552 240 150 552 minecraft:obsidian
setblock 241 134 528 minecraft:bone_block
fill 241 134 532 241 138 533 minecraft:bone_block
setblock 242 134 527 minecraft:bone_block
fill 242 134 533 243 139 533 minecraft:bone_block
fill 266 134 552 266 136 552 minecraft:obsidian
fill 235 135 513 235 150 515 minecraft:obsidian
setblock 235 135 516 minecraft:crying_obsidian
fill 240 135 533 240 138 533 minecraft:bone_block
fill 241 135 534 243 140 534 minecraft:bone_block
setblock 242 135 528 minecraft:bone_block
fill 252 135 552 252 154 552 minecraft:obsidian
setblock 253 135 552 minecraft:amethyst_block
setblock 260 135 510 minecraft:amethyst_block
setblock 277 135 532 minecraft:amethyst_block
fill 235 136 516 235 154 516 minecraft:obsidian
fill 235 136 518 235 137 518 minecraft:purple_concrete
fill 235 136 534 235 137 534 minecraft:purple_concrete
fill 235 136 550 235 137 550 minecraft:purple_concrete
fill 237 136 533 237 137 533 minecraft:bone_block
fill 239 136 510 239 137 510 minecraft:purple_concrete
fill 240 136 534 240 139 534 minecraft:bone_block
fill 241 136 535 243 141 535 minecraft:bone_block
fill 244 136 532 244 136 533 minecraft:bone_block
fill 249 136 552 249 137 552 minecraft:purple_concrete
fill 253 136 552 253 154 552 minecraft:obsidian
fill 255 136 510 255 137 510 minecraft:purple_concrete
fill 260 136 510 260 154 510 minecraft:obsidian
fill 265 136 552 265 137 552 minecraft:purple_concrete
fill 271 136 510 271 137 510 minecraft:purple_concrete
fill 271 136 541 271 137 541 minecraft:white_concrete
fill 272 136 534 273 137 535 minecraft:amethyst_block
setblock 277 136 515 minecraft:amethyst_block
fill 277 136 520 277 137 520 minecraft:purple_concrete
fill 277 136 521 277 151 521 minecraft:obsidian
fill 277 136 532 277 154 532 minecraft:obsidian
fill 277 136 536 277 137 536 minecraft:purple_concrete
setblock 277 136 541 minecraft:amethyst_block
setblock 236 137 533 minecraft:bone_block
fill 237 137 534 238 138 534 minecraft:bone_block
setblock 238 137 510 minecraft:amethyst_block
fill 240 137 535 240 139 535 minecraft:bone_block
fill 241 137 536 243 141 536 minecraft:bone_block
fill 244 137 533 244 137 535 minecraft:bone_block
fill 247 137 547 247 137 549 minecraft:bone_block
setblock 248 137 548 minecraft:bone_block
setblock 266 137 552 minecraft:white_concrete
setblock 270 137 510 minecraft:crying_obsidian
fill 277 137 515 277 155 515 minecraft:obsidian
fill 277 137 541 277 155 541 minecraft:obsidian
fill 235 138 518 235 144 518 minecraft:obsidian
fill 235 138 534 235 144 534 minecraft:obsidian
fill 235 138 550 235 144 550 minecraft:obsidian
fill 238 138 510 239 144 510 minecraft:obsidian
fill 238 138 535 239 139 535 minecraft:bone_block
setblock 239 138 534 minecraft:bone_block
fill 241 138 537 244 141 537 minecraft:bone_block
fill 244 138 534 244 139 536 minecraft:bone_block
setblock 244 138 552 minecraft:crying_obsidian
fill 246 138 545 246 138 547 minecraft:bone_block
fill 247 138 546 247 138 548 minecraft:bone_block
fill 249 138 552 249 144 552 minecraft:obsidian
fill 255 138 510 255 144 510 minecraft:obsidian
setblock 265 138 552 minecraft:white_concrete
fill 266 138 552 266 154 552 minecraft:obsidian
fill 270 138 510 271 144 510 minecraft:obsidian
setblock 275 138 510 minecraft:white_concrete
setblock 277 138 520 minecraft:crying_obsidian
fill 277 138 536 277 142 536 minecraft:obsidian
setblock 238 139 513 minecraft:light[level=12]
setblock 238 139 521 minecraft:light[level=12]
setblock 238 139 529 minecraft:light[level=12]
setblock 238 139 537 minecraft:light[level=12]
setblock 238 139 545 minecraft:light[level=12]
fill 239 139 536 240 139 536 minecraft:bone_block
setblock 241 139 533 minecraft:bone_block
fill 241 139 538 244 141 538 minecraft:bone_block
fill 244 139 552 244 154 552 minecraft:obsidian
setblock 246 139 513 minecraft:light[level=12]
setblock 246 139 521 minecraft:light[level=12]
setblock 246 139 529 minecraft:light[level=12]
setblock 246 139 537 minecraft:light[level=12]
fill 246 139 544 246 139 546 minecraft:bone_block
setblock 247 139 546 minecraft:bone_block
setblock 254 139 513 minecraft:light[level=12]
setblock 254 139 521 minecraft:light[level=12]
setblock 254 139 529 minecraft:light[level=12]
setblock 254 139 537 minecraft:light[level=12]
setblock 254 139 545 minecraft:light[level=12]
setblock 261 139 552 minecraft:amethyst_block
setblock 262 139 513 minecraft:light[level=12]
setblock 262 139 521 minecraft:light[level=12]
setblock 262 139 529 minecraft:light[level=12]
setblock 262 139 537 minecraft:light[level=12]
setblock 262 139 545 minecraft:light[level=12]
fill 265 139 552 265 144 552 minecraft:obsidian
setblock 270 139 513 minecraft:light[level=12]
setblock 270 139 521 minecraft:light[level=12]
setblock 270 139 529 minecraft:light[level=12]
setblock 270 139 537 minecraft:light[level=12]
setblock 270 139 545 minecraft:light[level=12]
fill 275 139 510 275 150 510 minecraft:obsidian
fill 277 139 520 277 143 520 minecraft:obsidian
setblock 277 139 523 minecraft:amethyst_block
fill 277 139 524 277 148 524 minecraft:obsidian
setblock 277 139 546 minecraft:amethyst_block
fill 240 140 536 240 140 537 minecraft:bone_block
fill 242 140 539 245 143 539 minecraft:bone_block
fill 244 140 535 244 141 536 minecraft:bone_block
fill 245 140 537 245 143 538 minecraft:bone_block
fill 245 140 542 245 140 544 minecraft:bone_block
setblock 245 140 552 minecraft:amethyst_block
fill 246 140 543 246 140 545 minecraft:bone_block
fill 261 140 552 261 154 552 minecraft:obsidian
fill 277 140 523 277 148 523 minecraft:obsidian
fill 277 140 546 277 152 546 minecraft:obsidian
setblock 277 140 549 minecraft:crying_obsidian
setblock 238 141 552 minecraft:white_concrete
fill 243 141 540 245 145 540 minecraft:bone_block
setblock 245 141 536 minecraft:bone_block
fill 245 141 541 245 141 543 minecraft:bone_block
fill 245 141 552 245 147 552 minecraft:obsidian
setblock 246 141 543 minecraft:bone_block
setblock 248 141 552 minecraft:white_concrete
setblock 258 141 510 minecraft:white_concrete
fill 277 141 549 277 152 549 minecraft:obsidian
fill 238 142 552 238 154 552 minecraft:obsidian
fill 242 142 536 244 142 538 minecraft:bone_block
fill 242 142 540 242 143 540 minecraft:bone_block
fill 243 142 541 246 145 541 minecraft:bone_block
fill 245 142 542 245 147 542 minecraft:bone_block
fill 246 142 538 246 144 540 minecraft:bone_block
fill 248 142 552 248 151 552 minecraft:obsidian
fill 258 142 510 258 154 510 minecraft:obsidian
fill 242 143 537 244 143 538 minecraft:bone_block
fill 244 143 542 244 146 542 minecraft:bone_block
fill 246 143 542 246 147 542 minecraft:bone_block
fill 247 143 540 247 147 541 minecraft:bone_block
setblock 277 143 536 minecraft:white_concrete
fill 243 144 538 245 144 539 minecraft:bone_block
fill 245 144 543 247 147 543 minecraft:bone_block
setblock 247 144 539 minecraft:bone_block
fill 247 144 542 247 147 542 minecraft:bone_block
setblock 256 144 552 minecraft:crying_obsidian
setblock 277 144 520 minecraft:crying_obsidian
setblock 277 144 536 minecraft:obsidian
fill 235 145 518 235 146 518 minecraft:purple_concrete
fill 235 145 534 235 146 534 minecraft:purple_concrete
setblock 235 145 546 minecraft:amethyst_block
fill 235 145 550 235 146 550 minecraft:purple_concrete
setblock 237 145 552 minecraft:crying_obsidian
fill 238 145 510 238 152 510 minecraft:obsidian
fill 239 145 510 239 146 510 minecraft:purple_concrete
fill 241 145 544 242 146 544 minecraft:bone_block
fill 243 145 539 246 145 539 minecraft:bone_block
setblock 245 145 538 minecraft:bone_block
fill 246 145 540 246 147 540 minecraft:bone_block
fill 248 145 541 248 147 543 minecraft:bone_block
fill 249 145 552 249 146 552 minecraft:purple_concrete
fill 255 145 510 255 146 510 minecraft:purple_concrete
fill 256 145 552 256 150 552 minecraft:obsidian
fill 259 145 550 259 145 551 minecraft:bone_block
setblock 262 145 510 minecraft:amethyst_block
fill 263 145 510 263 154 510 minecraft:obsidian
fill 265 145 552 265 146 552 minecraft:purple_concrete
fill 270 145 510 270 151 510 minecraft:obsidian
fill 271 145 510 271 146 510 minecraft:purple_concrete
fill 277 145 520 277 146 520 minecraft:purple_concrete
fill 277 145 536 277 146 536 minecraft:purple_concrete
fill 235 146 546 235 154 546 minecraft:obsidian
fill 237 146 552 237 154 552 minecraft:obsidian
fill 243 146 544 243 146 545 minecraft:bone_block
fill 244 146 540 245 146 541 minecraft:bone_block
fill 244 146 544 244 147 544 minecraft:bone_block
fill 245 146 539 246 146 539 minecraft:bone_block
fill 246 146 541 246 147 541 minecraft:bone_block
fill 246 146 544 249 147 544 minecraft:bone_block
fill 249 146 542 249 147 543 minecraft:bone_block
setblock 253 146 510 minecraft:crying_obsidian
fill 257 146 549 258 147 549 minecraft:bone_block
fill 258 146 550 259 146 550 minecraft:bone_block
fill 262 146 510 262 150 510 minecraft:obsidian
fill 235 147 518 235 154 518 minecraft:obsidian
setblock 235 147 533 minecraft:amethyst_block
fill 235 147 534 235 150 534 minecraft:obsidian
fill 235 147 550 235 154 550 minecraft:obsidian
setblock 237 147 510 minecraft:amethyst_block
setblock 238 147 513 minecraft:light[level=12]
setblock 238 147 521 minecraft:light[level=12]
setblock 238 147 529 minecraft:light[level=12]
setblock 238 147 537 minecraft:light[level=12]
setblock 238 147 545 minecraft:light[level=12]
fill 239 147 510 239 154 510 minecraft:obsidian
setblock 240 147 510 minecraft:amethyst_block
setblock 243 147 544 minecraft:bone_block
fill 244 147 545 245 147 545 minecraft:bone_block
fill 245 147 540 245 147 541 minecraft:bone_block
setblock 245 147 544 minecraft:bone_block
setblock 246 147 513 minecraft:light[level=12]
setblock 246 147 521 minecraft:light[level=12]
setblock 246 147 529 minecraft:light[level=12]
setblock 246 147 537 minecraft:light[level=12]
setblock 246 147 545 minecraft:light[level=12]
fill 247 147 545 249 147 545 minecraft:bone_block
setblock 249 147 541 minecraft:bone_block
fill 249 147 552 249 155 552 minecraft:obsidian
fill 250 147 543 250 147 544 minecraft:bone_block
fill 253 147 510 253 154 510 minecraft:obsidian
setblock 254 147 513 minecraft:light[level=12]
setblock 254 147 521 minecraft:light[level=12]
setblock 254 147 529 minecraft:light[level=12]
setblock 254 147 537 minecraft:light[level=12]
setblock 254 147 545 minecraft:light[level=12]
fill 255 147 510 255 155 510 minecraft:obsidian
fill 256 147 548 256 147 549 minecraft:bone_block
setblock 257 147 548 minecraft:bone_block
setblock 262 147 513 minecraft:light[level=12]
setblock 262 147 521 minecraft:light[level=12]
setblock 262 147 529 minecraft:light[level=12]
setblock 262 147 537 minecraft:light[level=12]
setblock 262 147 545 minecraft:light[level=12]
fill 265 147 552 265 150 552 minecraft:obsidian
setblock 270 147 513 minecraft:light[level=12]
setblock 270 147 521 minecraft:light[level=12]
setblock 270 147 529 minecraft:light[level=12]
setblock 270 147 537 minecraft:light[level=12]
setblock 270 147 545 minecraft:light[level=12]
fill 271 147 510 271 154 510 minecraft:obsidian
fill 277 147 520 277 150 520 minecraft:obsidian
fill 277 147 536 277 154 536 minecraft:obsidian
fill 235 148 533 235 154 533 minecraft:obsidian
fill 237 148 510 237 152 510 minecraft:obsidian
fill 240 148 510 240 154 510 minecraft:obsidian
setblock 245 148 552 minecraft:crying_obsidian
setblock 235 149 551 minecraft:crying_obsidian
fill 245 149 552 245 154 552 minecraft:obsidian
fill 277 149 523 277 149 524 minecraft:crying_obsidian
setblock 235 150 523 minecraft:amethyst_block
fill 235 150 551 235 154 551 minecraft:obsidian
fill 277 150 523 277 154 524 minecraft:obsidian
fill 235 151 513 235 152 513 minecraft:obsidian
setblock 235 151 514 minecraft:black_concrete
fill 235 151 515 235 154 515 minecraft:obsidian
setblock 235 151 517 minecraft:black_concrete
setblock 235 151 523 minecraft:obsidian
setblock 235 151 524 minecraft:crying_obsidian
setblock 235 151 525 minecraft:black_concrete
fill 235 151 526 235 154 526 minecraft:obsidian
setblock 235 151 534 minecraft:amethyst_block
setblock 235 151 547 minecraft:black_concrete
setblock 235 151 552 minecraft:black_concrete
setblock 236 151 510 minecraft:black_concrete
setblock 240 151 552 minecraft:black_concrete
fill 254 151 531 254 151 533 minecraft:amethyst_block
fill 255 151 530 257 151 531 minecraft:amethyst_block
setblock 255 151 534 minecraft:amethyst_block
setblock 256 151 552 minecraft:black_concrete
fill 257 151 532 257 151 534 minecraft:amethyst_block
fill 258 151 531 258 151 533 minecraft:amethyst_block
setblock 262 151 510 minecraft:white_concrete
setblock 262 151 552 minecraft:black_concrete
setblock 265 151 552 minecraft:black_concrete
fill 266 151 510 267 152 510 minecraft:obsidian
setblock 268 151 510 minecraft:white_concrete
setblock 271 151 552 minecraft:black_concrete
setblock 275 151 510 minecraft:black_concrete
setblock 277 151 516 minecraft:black_concrete
setblock 277 151 520 minecraft:black_concrete
setblock 277 151 526 minecraft:black_concrete
setblock 277 151 534 minecraft:black_concrete
setblock 277 151 548 minecraft:black_concrete
fill 235 152 514 235 154 514 minecraft:obsidian
fill 235 152 517 235 154 517 minecraft:obsidian
setblock 235 152 523 minecraft:amethyst_block
fill 235 152 524 235 154 525 minecraft:obsidian
setblock 235 152 531 minecraft:black_concrete
fill 235 152 534 235 154 534 minecraft:obsidian
fill 235 152 540 235 153 540 minecraft:black_concrete
setblock 235 152 543 minecraft:black_concrete
fill 235 152 547 235 154 547 minecraft:obsidian
setblock 235 152 548 minecraft:black_concrete
fill 235 152 552 235 154 552 minecraft:obsidian
setblock 236 152 510 minecraft:obsidian
fill 240 152 552 240 154 552 minecraft:obsidian
setblock 242 152 510 minecraft:black_concrete
fill 243 152 510 243 154 510 minecraft:obsidian
setblock 246 152 552 minecraft:black_concrete
setblock 248 152 552 minecraft:black_concrete
setblock 250 152 552 minecraft:black_concrete
fill 252 152 531 253 152 533 minecraft:amethyst_block
fill 253 152 529 254 152 530 minecraft:amethyst_block
fill 253 152 534 254 152 535 minecraft:amethyst_block
fill 254 152 531 254 161 532 minecraft:crying_obsidian
fill 255 152 528 257 152 529 minecraft:amethyst_block
fill 255 152 530 255 161 531 minecraft:crying_obsidian
fill 255 152 535 255 152 536 minecraft:amethyst_block
fill 256 152 530 257 163 530 minecraft:crying_obsidian
fill 256 152 536 257 152 536 minecraft:amethyst_block
fill 256 152 552 256 154 552 minecraft:obsidian
fill 257 152 531 258 161 531 minecraft:crying_obsidian
fill 257 152 535 259 152 535 minecraft:amethyst_block
fill 258 152 529 259 152 530 minecraft:amethyst_block
fill 258 152 532 258 161 532 minecraft:crying_obsidian
fill 258 152 534 259 152 534 minecraft:amethyst_block
fill 259 152 531 260 152 533 minecraft:amethyst_block
fill 262 152 510 262 154 510 minecraft:obsidian
fill 262 152 552 262 154 552 minecraft:obsidian
setblock 264 152 510 minecraft:black_concrete
fill 265 152 552 265 154 552 minecraft:obsidian
fill 268 152 510 268 154 510 minecraft:obsidian
setblock 268 152 552 minecraft:amethyst_block
setblock 270 152 510 minecraft:black_concrete
setblock 271 152 552 minecraft:crying_obsidian
fill 275 152 510 275 154 510 minecraft:obsidian
fill 275 152 552 275 154 552 minecraft:obsidian
setblock 276 152 552 minecraft:black_concrete
setblock 277 152 510 minecraft:black_concrete
fill 277 152 516 277 154 516 minecraft:obsidian
fill 277 152 520 277 154 520 minecraft:obsidian
setblock 277 152 521 minecraft:black_concrete
fill 277 152 526 277 153 526 minecraft:obsidian
setblock 277 152 530 minecraft:crying_obsidian
fill 277 152 534 277 154 534 minecraft:obsidian
setblock 277 152 537 minecraft:black_concrete
fill 277 152 538 277 154 538 minecraft:obsidian
fill 277 152 542 277 152 543 minecraft:black_concrete
fill 277 152 548 277 154 548 minecraft:obsidian
setblock 235 153 513 minecraft:crying_obsidian
setblock 235 153 519 minecraft:black_concrete
fill 235 153 523 235 154 523 minecraft:obsidian
fill 235 153 531 235 154 531 minecraft:obsidian
setblock 235 153 541 minecraft:crying_obsidian
fill 235 153 542 235 154 543 minecraft:obsidian
setblock 235 153 545 minecraft:black_concrete
fill 235 153 548 235 154 548 minecraft:obsidian
setblock 236 153 510 minecraft:black_concrete
setblock 237 153 510 minecraft:amethyst_block
setblock 238 153 510 minecraft:black_concrete
fill 242 153 510 242 154 510 minecraft:obsidian
fill 246 153 552 246 154 552 minecraft:obsidian
setblock 248 153 510 minecraft:black_concrete
fill 248 153 552 248 154 552 minecraft:obsidian
setblock 250 153 552 minecraft:obsidian
fill 251 153 531 251 153 533 minecraft:amethyst_block
fill 252 153 529 252 153 530 minecraft:amethyst_block
fill 252 153 531 253 162 533 minecraft:crying_obsidian
fill 252 153 534 252 153 535 minecraft:amethyst_block
fill 253 153 528 254 153 528 minecraft:amethyst_block
fill 253 153 529 254 162 530 minecraft:crying_obsidian
fill 253 153 534 254 161 535 minecraft:crying_obsidian
fill 253 153 536 254 153 536 minecraft:amethyst_block
fill 255 153 527 257 153 527 minecraft:amethyst_block
fill 255 153 528 257 162 529 minecraft:crying_obsidian
fill 255 153 535 255 161 536 minecraft:crying_obsidian
fill 255 153 537 257 153 537 minecraft:amethyst_block
setblock 255 153 552 minecraft:black_concrete
fill 256 153 536 257 162 536 minecraft:crying_obsidian
fill 257 153 535 259 161 535 minecraft:crying_obsidian
fill 258 153 528 259 153 528 minecraft:amethyst_block
fill 258 153 529 259 162 530 minecraft:crying_obsidian
fill 258 153 534 259 161 534 minecraft:crying_obsidian
fill 258 153 536 259 153 536 minecraft:amethyst_block
setblock 258 153 552 minecraft:black_concrete
fill 259 153 531 260 162 533 minecraft:crying_obsidian
fill 260 153 529 260 153 530 minecraft:amethyst_block
fill 260 153 534 260 153 535 minecraft:amethyst_block
fill 261 153 531 261 153 533 minecraft:amethyst_block
fill 264 153 510 264 154 510 minecraft:obsidian
setblock 264 153 552 minecraft:crying_obsidian
fill 266 153 510 266 154 510 minecraft:obsidian
setblock 267 153 510 minecraft:black_concrete
fill 268 153 552 268 155 552 minecraft:obsidian
setblock 269 153 510 minecraft:black_concrete
fill 270 153 510 270 154 510 minecraft:obsidian
fill 271 153 552 271 154 552 minecraft:obsidian
fill 276 153 552 276 154 552 minecraft:obsidian
fill 277 153 510 277 154 510 minecraft:obsidian
setblock 277 153 512 minecraft:black_concrete
setblock 277 153 521 minecraft:obsidian
setblock 277 153 522 minecraft:black_concrete
fill 277 153 530 277 154 530 minecraft:obsidian
fill 277 153 537 277 154 537 minecraft:obsidian
setblock 277 153 542 minecraft:black_concrete
setblock 277 153 543 minecraft:obsidian
fill 277 153 545 277 153 547 minecraft:black_concrete
setblock 277 153 549 minecraft:black_concrete
setblock 277 153 552 minecraft:black_concrete
setblock 235 154 513 minecraft:obsidian
setblock 235 154 519 minecraft:obsidian
fill 235 154 540 235 154 541 minecraft:obsidian
setblock 235 154 545 minecraft:obsidian
fill 236 154 510 238 154 510 minecraft:obsidian
setblock 245 154 510 minecraft:white_concrete
setblock 248 154 510 minecraft:obsidian
setblock 249 154 510 minecraft:crying_obsidian
fill 250 154 532 250 161 532 minecraft:amethyst_block
setblock 250 154 552 minecraft:crying_obsidian
fill 251 154 529 251 154 531 minecraft:amethyst_block
fill 251 154 532 251 161 532 minecraft:crying_obsidian
fill 251 154 533 251 154 535 minecraft:amethyst_block
setblock 252 154 528 minecraft:amethyst_block
fill 252 154 529 252 161 530 minecraft:crying_obsidian
fill 252 154 534 252 161 535 minecraft:crying_obsidian
setblock 252 154 536 minecraft:amethyst_block
fill 253 154 527 255 154 527 minecraft:amethyst_block
fill 253 154 528 254 161 528 minecraft:crying_obsidian
fill 253 154 536 254 161 536 minecraft:crying_obsidian
fill 253 154 537 255 154 537 minecraft:amethyst_block
setblock 255 154 552 minecraft:obsidian
fill 256 154 526 256 161 526 minecraft:amethyst_block
fill 256 154 527 256 161 527 minecraft:crying_obsidian
fill 256 154 537 256 161 537 minecraft:crying_obsidian
fill 256 154 538 256 161 538 minecraft:amethyst_block
fill 257 154 527 259 154 527 minecraft:amethyst_block
fill 257 154 537 259 154 537 minecraft:amethyst_block
fill 258 154 528 259 161 528 minecraft:crying_obsidian
fill 258 154 536 259 161 536 minecraft:crying_obsidian
setblock 258 154 552 minecraft:obsidian
setblock 260 154 528 minecraft:amethyst_block
fill 260 154 529 260 161 530 minecraft:crying_obsidian
fill 260 154 534 260 161 535 minecraft:crying_obsidian
setblock 260 154 536 minecraft:amethyst_block
fill 261 154 529 261 154 531 minecraft:amethyst_block
fill 261 154 532 261 161 532 minecraft:crying_obsidian
fill 261 154 533 261 154 535 minecraft:amethyst_block
fill 262 154 532 262 161 532 minecraft:amethyst_block
setblock 264 154 552 minecraft:obsidian
setblock 267 154 510 minecraft:obsidian
setblock 267 154 552 minecraft:white_concrete
setblock 269 154 510 minecraft:obsidian
fill 277 154 512 277 155 512 minecraft:obsidian
setblock 277 154 521 minecraft:white_concrete
setblock 277 154 522 minecraft:obsidian
setblock 277 154 526 minecraft:crying_obsidian
setblock 277 154 542 minecraft:obsidian
setblock 277 154 543 minecraft:amethyst_block
fill 277 154 545 277 154 547 minecraft:obsidian
setblock 277 154 549 minecraft:obsidian
setblock 277 154 552 minecraft:obsidian
fill 235 155 510 235 156 521 minecraft:black_concrete
fill 235 155 523 235 155 542 minecraft:black_concrete
setblock 235 155 543 minecraft:obsidian
fill 235 155 544 235 155 552 minecraft:black_concrete
fill 236 155 510 250 155 510 minecraft:black_concrete
fill 236 155 552 241 155 552 minecraft:black_concrete
setblock 238 155 513 minecraft:light[level=12]
setblock 238 155 521 minecraft:light[level=12]
setblock 238 155 529 minecraft:light[level=12]
setblock 238 155 537 minecraft:light[level=12]
setblock 238 155 545 minecraft:light[level=12]
fill 243 155 552 248 156 552 minecraft:black_concrete
setblock 246 155 513 minecraft:light[level=12]
setblock 246 155 521 minecraft:light[level=12]
setblock 246 155 529 minecraft:light[level=12]
setblock 246 155 537 minecraft:light[level=12]
setblock 246 155 545 minecraft:light[level=12]
fill 250 155 530 250 160 531 minecraft:amethyst_block
fill 250 155 533 250 160 534 minecraft:amethyst_block
fill 250 155 552 267 155 552 minecraft:black_concrete
fill 251 155 528 251 155 529 minecraft:amethyst_block
fill 251 155 530 251 160 531 minecraft:crying_obsidian
fill 251 155 533 251 160 534 minecraft:crying_obsidian
fill 251 155 535 251 155 536 minecraft:amethyst_block
fill 252 155 510 254 155 510 minecraft:black_concrete
fill 252 155 527 253 155 527 minecraft:amethyst_block
fill 252 155 528 252 160 528 minecraft:crying_obsidian
fill 252 155 536 252 160 536 minecraft:crying_obsidian
fill 252 155 537 253 155 537 minecraft:amethyst_block
setblock 254 155 513 minecraft:light[level=12]
setblock 254 155 521 minecraft:light[level=12]
fill 254 155 526 255 160 526 minecraft:amethyst_block
fill 254 155 527 255 160 527 minecraft:crying_obsidian
fill 254 155 537 255 160 537 minecraft:crying_obsidian
fill 254 155 538 255 160 538 minecraft:amethyst_block
setblock 254 155 545 minecraft:light[level=12]
fill 256 155 510 260 155 510 minecraft:black_concrete
fill 257 155 526 258 160 526 minecraft:amethyst_block
fill 257 155 527 258 160 527 minecraft:crying_obsidian
fill 257 155 537 258 160 537 minecraft:crying_obsidian
fill 257 155 538 258 160 538 minecraft:amethyst_block
fill 259 155 527 260 155 527 minecraft:amethyst_block
fill 259 155 537 260 155 537 minecraft:amethyst_block
fill 260 155 528 260 160 528 minecraft:crying_obsidian
fill 260 155 536 260 160 536 minecraft:crying_obsidian
setblock 261 155 510 minecraft:crying_obsidian
fill 261 155 528 261 155 529 minecraft:amethyst_block
fill 261 155 530 261 160 531 minecraft:crying_obsidian
fill 261 155 533 261 160 534 minecraft:crying_obsidian
fill 261 155 535 261 155 536 minecraft:amethyst_block
fill 262 155 510 277 155 510 minecraft:black_concrete
setblock 262 155 513 minecraft:light[level=12]
setblock 262 155 521 minecraft:light[level=12]
setblock 262 155 529 minecraft:light[level=12]
fill 262 155 530 262 160 531 minecraft:amethyst_block
fill 262 155 533 262 160 534 minecraft:amethyst_block
setblock 262 155 537 minecraft:light[level=12]
setblock 262 155 545 minecraft:light[level=12]
setblock 270 155 513 minecraft:light[level=12]
setblock 270 155 521 minecraft:light[level=12]
setblock 270 155 529 minecraft:light[level=12]
setblock 270 155 537 minecraft:light[level=12]
setblock 270 155 545 minecraft:light[level=12]
fill 270 155 552 277 155 552 minecraft:black_concrete
fill 277 155 511 277 156 511 minecraft:black_concrete
fill 277 155 513 277 162 514 minecraft:black_concrete
fill 277 155 516 277 156 517 minecraft:black_concrete
fill 277 155 519 277 170 522 minecraft:black_concrete
setblock 277 155 523 minecraft:obsidian
fill 277 155 524 277 155 528 minecraft:black_concrete
fill 277 155 530 277 155 532 minecraft:black_concrete
setblock 277 155 533 minecraft:white_concrete
fill 277 155 534 277 155 540 minecraft:black_concrete
fill 277 155 542 277 167 543 minecraft:black_concrete
fill 277 155 545 277 155 549 minecraft:black_concrete
setblock 277 155 551 minecraft:black_concrete
fill 235 156 522 235 156 528 minecraft:black_concrete
setblock 235 156 529 minecraft:amethyst_block
fill 235 156 530 235 172 530 minecraft:black_concrete
setblock 235 156 531 minecraft:amethyst_block
fill 235 156 532 235 156 533 minecraft:black_concrete
setblock 235 156 534 minecraft:obsidian
fill 235 156 535 235 156 539 minecraft:black_concrete
fill 235 156 540 235 157 540 minecraft:obsidian
fill 235 156 541 235 174 544 minecraft:black_concrete
setblock 235 156 545 minecraft:obsidian
setblock 235 156 546 minecraft:white_concrete
fill 235 156 547 235 156 550 minecraft:black_concrete
setblock 235 156 551 minecraft:white_concrete
fill 235 156 552 236 195 552 minecraft:black_concrete
fill 236 156 510 249 156 510 minecraft:black_concrete
fill 237 156 552 237 157 552 minecraft:obsidian
fill 238 156 552 242 156 552 minecraft:black_concrete
fill 249 156 552 258 156 552 minecraft:black_concrete
fill 250 156 510 250 157 510 minecraft:obsidian
fill 250 156 529 250 159 529 minecraft:amethyst_block
fill 250 156 535 250 159 535 minecraft:amethyst_block
fill 251 156 510 252 176 510 minecraft:black_concrete
fill 251 156 528 251 160 528 minecraft:amethyst_block
fill 251 156 529 251 159 529 minecraft:crying_obsidian
fill 251 156 535 251 159 535 minecraft:crying_obsidian
fill 251 156 536 251 160 536 minecraft:amethyst_block
fill 252 156 527 252 160 527 minecraft:amethyst_block
fill 252 156 537 252 160 537 minecraft:amethyst_block
setblock 253 156 510 minecraft:obsidian
fill 253 156 526 253 159 526 minecraft:amethyst_block
fill 253 156 527 253 159 527 minecraft:crying_obsidian
fill 253 156 537 253 159 537 minecraft:crying_obsidian
fill 253 156 538 253 159 538 minecraft:amethyst_block
fill 254 156 510 257 156 510 minecraft:black_concrete
setblock 258 156 510 minecraft:obsidian
fill 259 156 510 262 224 510 minecraft:black_concrete
fill 259 156 526 259 159 526 minecraft:amethyst_block
fill 259 156 527 259 159 527 minecraft:crying_obsidian
fill 259 156 537 259 159 537 minecraft:crying_obsidian
fill 259 156 538 259 159 538 minecraft:amethyst_block
setblock 259 156 552 minecraft:obsidian
fill 260 156 527 260 160 527 minecraft:amethyst_block
fill 260 156 537 260 160 537 minecraft:amethyst_block
fill 260 156 552 276 156 552 minecraft:black_concrete
fill 261 156 528 261 160 528 minecraft:amethyst_block
fill 261 156 529 261 159 529 minecraft:crying_obsidian
fill 261 156 535 261 159 535 minecraft:crying_obsidian
fill 261 156 536 261 160 536 minecraft:amethyst_block
fill 262 156 529 262 159 529 minecraft:amethyst_block
fill 262 156 535 262 159 535 minecraft:amethyst_block
setblock 263 156 510 minecraft:obsidian
fill 264 156 510 272 159 510 minecraft:black_concrete
setblock 273 156 510 minecraft:white_concrete
setblock 274 156 510 minecraft:obsidian
fill 275 156 510 277 158 510 minecraft:black_concrete
fill 277 156 512 277 170 512 minecraft:black_concrete
fill 277 156 515 277 164 515 minecraft:black_concrete
setblock 277 156 518 minecraft:black_concrete
fill 277 156 523 277 163 525 minecraft:black_concrete
setblock 277 156 526 minecraft:obsidian
fill 277 156 527 277 174 530 minecraft:black_concrete
setblock 277 156 531 minecraft:obsidian
fill 277 156 532 277 156 535 minecraft:black_concrete
setblock 277 156 536 minecraft:obsidian
fill 277 156 537 277 172 537 minecraft:black_concrete
setblock 277 156 538 minecraft:obsidian
setblock 277 156 539 minecraft:black_concrete
setblock 277 156 540 minecraft:obsidian
setblock 277 156 541 minecraft:black_concrete
fill 277 156 544 277 156 548 minecraft:black_concrete
setblock 277 156 549 minecraft:obsidian
fill 277 156 550 277 216 550 minecraft:black_concrete
fill 277 156 551 277 156 552 minecraft:obsidian
setblock 235 157 510 minecraft:obsidian
fill 235 157 511 235 158 516 minecraft:black_concrete
setblock 235 157 517 minecraft:obsidian
fill 235 157 518 235 170 522 minecraft:black_concrete
setblock 235 157 523 minecraft:crying_obsidian
fill 235 157 524 235 157 529 minecraft:black_concrete
fill 235 157 531 235 175 532 minecraft:black_concrete
setblock 235 157 533 minecraft:obsidian
fill 235 157 534 235 170 534 minecraft:black_concrete
setblock 235 157 535 minecraft:obsidian
fill 235 157 536 235 194 538 minecraft:black_concrete
setblock 235 157 539 minecraft:amethyst_block
fill 235 157 545 235 168 547 minecraft:black_concrete
setblock 235 157 548 minecraft:obsidian
fill 235 157 549 235 170 550 minecraft:black_concrete
setblock 235 157 551 minecraft:obsidian
fill 236 157 510 238 170 510 minecraft:black_concrete
fill 238 157 552 239 163 552 minecraft:black_concrete
setblock 239 157 510 minecraft:obsidian
fill 240 157 510 241 176 510 minecraft:black_concrete
fill 240 157 552 241 157 552 minecraft:obsidian
setblock 242 157 510 minecraft:obsidian
fill 242 157 552 246 163 552 minecraft:black_concrete
fill 243 157 510 249 175 510 minecraft:black_concrete
fill 247 157 552 248 157 552 minecraft:obsidian
fill 249 157 552 254 170 552 minecraft:black_concrete
fill 253 157 510 253 254 510 minecraft:black_concrete
fill 254 157 510 255 157 510 minecraft:obsidian
setblock 255 157 552 minecraft:obsidian
fill 256 157 510 258 160 510 minecraft:black_concrete
fill 256 157 552 269 164 552 minecraft:black_concrete
fill 263 157 510 263 167 510 minecraft:black_concrete
setblock 270 157 552 minecraft:obsidian
fill 271 157 552 277 170 552 minecraft:black_concrete
setblock 273 157 510 minecraft:obsidian
fill 274 157 510 274 163 510 minecraft:black_concrete
setblock 277 157 511 minecraft:obsidian
fill 277 157 516 277 192 516 minecraft:black_concrete
fill 277 157 517 277 157 518 minecraft:obsidian
fill 277 157 526 277 247 526 minecraft:black_concrete
setblock 277 157 531 minecraft:crying_obsidian
fill 277 157 532 277 190 534 minecraft:black_concrete
setblock 277 157 535 minecraft:amethyst_block
fill 277 157 536 277 170 536 minecraft:black_concrete
fill 277 157 538 277 208 538 minecraft:black_concrete
setblock 277 157 539 minecraft:white_concrete
fill 277 157 540 277 307 540 minecraft:black_concrete
setblock 277 157 541 minecraft:obsidian
fill 277 157 544 277 158 545 minecraft:black_concrete
setblock 277 157 546 minecraft:obsidian
fill 277 157 547 277 161 549 minecraft:black_concrete
fill 277 157 551 277 180 551 minecraft:black_concrete
fill 235 158 510 235 307 510 minecraft:black_concrete
fill 235 158 517 235 171 517 minecraft:black_concrete
fill 235 158 523 235 162 524 minecraft:black_concrete
setblock 235 158 525 minecraft:amethyst_block
fill 235 158 526 235 160 529 minecraft:black_concrete
fill 235 158 533 235 179 533 minecraft:black_concrete
fill 235 158 535 235 169 535 minecraft:black_concrete
fill 235 158 539 235 167 540 minecraft:black_concrete
fill 235 158 548 235 254 548 minecraft:black_concrete
fill 235 158 551 235 176 551 minecraft:black_concrete
fill 237 158 552 237 161 552 minecraft:black_concrete
fill 239 158 510 239 170 510 minecraft:black_concrete
fill 240 158 552 241 163 552 minecraft:black_concrete
fill 242 158 510 242 307 510 minecraft:black_concrete
fill 247 158 552 248 218 552 minecraft:black_concrete
fill 250 158 510 250 174 510 minecraft:black_concrete
fill 254 158 510 255 170 510 minecraft:black_concrete
fill 255 158 552 255 232 552 minecraft:black_concrete
fill 270 158 552 270 160 552 minecraft:black_concrete
fill 273 158 510 273 237 510 minecraft:black_concrete
fill 277 158 511 277 213 511 minecraft:black_concrete
fill 277 158 517 277 224 518 minecraft:black_concrete
setblock 277 158 531 minecraft:black_concrete
fill 277 158 535 277 254 535 minecraft:black_concrete
fill 277 158 539 277 223 539 minecraft:black_concrete
fill 277 158 541 277 175 541 minecraft:black_concrete
fill 277 158 546 277 169 546 minecraft:black_concrete
fill 235 159 511 235 172 514 minecraft:black_concrete
setblock 235 159 515 minecraft:amethyst_block
fill 235 159 516 235 209 516 minecraft:black_concrete
fill 235 159 525 235 167 525 minecraft:black_concrete
fill 275 159 510 275 304 510 minecraft:black_concrete
setblock 276 159 510 minecraft:white_concrete
fill 277 159 510 277 307 510 minecraft:black_concrete
setblock 277 159 531 minecraft:amethyst_block
setblock 277 159 544 minecraft:white_concrete
fill 277 159 545 277 258 545 minecraft:black_concrete
fill 235 160 515 235 167 515 minecraft:black_concrete
fill 251 160 529 251 161 529 minecraft:amethyst_block
fill 251 160 535 251 161 535 minecraft:amethyst_block
fill 253 160 527 253 161 527 minecraft:amethyst_block
fill 253 160 537 253 161 537 minecraft:amethyst_block
fill 259 160 527 259 161 527 minecraft:amethyst_block
fill 259 160 537 259 161 537 minecraft:amethyst_block
fill 261 160 529 261 161 529 minecraft:amethyst_block
fill 261 160 535 261 161 535 minecraft:amethyst_block
fill 264 160 510 266 168 510 minecraft:black_concrete
setblock 267 160 510 minecraft:white_concrete
fill 268 160 510 272 160 510 minecraft:black_concrete
fill 276 160 510 276 189 510 minecraft:black_concrete
fill 277 160 531 277 211 531 minecraft:black_concrete
fill 277 160 544 277 179 544 minecraft:black_concrete
setblock 235 161 526 minecraft:amethyst_block
fill 235 161 527 235 213 529 minecraft:black_concrete
fill 251 161 530 251 161 531 minecraft:amethyst_block
fill 251 161 533 251 161 534 minecraft:amethyst_block
setblock 252 161 528 minecraft:amethyst_block
setblock 252 161 536 minecraft:amethyst_block
fill 254 161 527 255 161 527 minecraft:amethyst_block
fill 254 161 537 255 161 537 minecraft:amethyst_block
setblock 256 161 510 minecraft:white_concrete
fill 257 161 510 258 174 510 minecraft:black_concrete
fill 257 161 527 258 161 527 minecraft:amethyst_block
fill 257 161 537 258 161 537 minecraft:amethyst_block
setblock 260 161 528 minecraft:amethyst_block
setblock 260 161 536 minecraft:amethyst_block
fill 261 161 530 261 161 531 minecraft:amethyst_block
fill 261 161 533 261 161 534 minecraft:amethyst_block
fill 267 161 510 268 165 510 minecraft:black_concrete
setblock 269 161 510 minecraft:crying_obsidian
fill 270 161 510 272 170 510 minecraft:black_concrete
setblock 270 161 552 minecraft:white_concrete
fill 235 162 526 235 179 526 minecraft:black_concrete
fill 236 162 511 250 162 551 minecraft:obsidian
setblock 237 162 552 minecraft:white_concrete
fill 251 162 511 251 162 530 minecraft:obsidian
fill 251 162 531 251 162 533 minecraft:amethyst_block
fill 251 162 534 251 162 551 minecraft:obsidian
fill 252 162 511 252 162 528 minecraft:obsidian
fill 252 162 529 252 162 530 minecraft:amethyst_block
fill 252 162 534 252 162 535 minecraft:amethyst_block
fill 252 162 536 252 162 551 minecraft:obsidian
fill 253 162 511 254 162 527 minecraft:obsidian
fill 253 162 528 254 162 528 minecraft:amethyst_block
fill 253 162 534 253 162 535 minecraft:crying_obsidian
fill 253 162 536 254 162 536 minecraft:amethyst_block
fill 253 162 537 254 162 551 minecraft:obsidian
fill 254 162 531 254 162 532 minecraft:shroomlight
fill 254 162 534 254 162 535 minecraft:shroomlight
fill 255 162 511 276 162 526 minecraft:obsidian
fill 255 162 527 257 162 527 minecraft:amethyst_block
fill 255 162 530 255 163 530 minecraft:crying_obsidian
setblock 255 162 531 minecraft:shroomlight
setblock 255 162 535 minecraft:shroomlight
setblock 255 162 536 minecraft:crying_obsidian
fill 255 162 537 257 162 537 minecraft:amethyst_block
fill 255 162 538 276 162 551 minecraft:obsidian
fill 256 162 510 256 194 510 minecraft:black_concrete
fill 257 162 531 258 162 531 minecraft:shroomlight
fill 257 162 535 258 162 535 minecraft:shroomlight
fill 258 162 527 276 162 527 minecraft:obsidian
fill 258 162 528 259 162 528 minecraft:amethyst_block
setblock 258 162 532 minecraft:shroomlight
setblock 258 162 534 minecraft:shroomlight
fill 258 162 536 259 162 536 minecraft:amethyst_block
fill 258 162 537 276 162 537 minecraft:obsidian
fill 259 162 534 259 162 535 minecraft:crying_obsidian
fill 260 162 528 276 162 528 minecraft:obsidian
fill 260 162 529 260 162 530 minecraft:amethyst_block
fill 260 162 534 260 162 535 minecraft:amethyst_block
fill 260 162 536 276 162 536 minecraft:obsidian
fill 261 162 529 276 162 530 minecraft:obsidian
fill 261 162 531 261 162 533 minecraft:amethyst_block
fill 261 162 534 276 162 535 minecraft:obsidian
fill 262 162 531 276 162 533 minecraft:obsidian
fill 269 162 510 269 174 510 minecraft:black_concrete
fill 270 162 552 270 195 552 minecraft:black_concrete
setblock 277 162 547 minecraft:amethyst_block
fill 277 162 548 277 198 549 minecraft:black_concrete
fill 235 163 523 235 307 523 minecraft:black_concrete
setblock 235 163 524 minecraft:crying_obsidian
fill 236 163 521 237 163 545 minecraft:basalt
fill 237 163 520 243 163 520 minecraft:basalt
setblock 237 163 546 minecraft:basalt
fill 237 163 552 237 241 552 minecraft:black_concrete
setblock 238 163 513 minecraft:light[level=12]
fill 238 163 518 240 163 518 minecraft:basalt
setblock 238 163 519 minecraft:magma_block
fill 238 163 521 240 165 521 minecraft:basalt
setblock 238 163 522 minecraft:magma_block
fill 238 163 523 240 165 524 minecraft:basalt
setblock 238 163 525 minecraft:magma_block
fill 238 163 526 240 167 527 minecraft:basalt
setblock 238 163 528 minecraft:magma_block
fill 238 163 529 240 168 530 minecraft:basalt
setblock 238 163 531 minecraft:magma_block
fill 238 163 532 240 168 533 minecraft:basalt
setblock 238 163 534 minecraft:magma_block
fill 238 163 535 240 168 536 minecraft:basalt
setblock 238 163 537 minecraft:magma_block
fill 238 163 538 240 168 539 minecraft:basalt
setblock 238 163 540 minecraft:magma_block
fill 238 163 541 240 165 542 minecraft:basalt
setblock 238 163 543 minecraft:magma_block
fill 238 163 544 240 165 545 minecraft:basalt
setblock 238 163 546 minecraft:magma_block
fill 238 163 547 240 163 548 minecraft:basalt
fill 239 163 517 243 163 517 minecraft:basalt
fill 239 163 519 246 164 519 minecraft:basalt
fill 239 163 522 246 166 522 minecraft:basalt
fill 239 163 525 243 168 525 minecraft:basalt
fill 239 163 528 242 169 528 minecraft:basalt
fill 239 163 531 241 170 531 minecraft:basalt
fill 239 163 534 241 170 534 minecraft:basalt
fill 239 163 537 241 169 537 minecraft:basalt
fill 239 163 540 243 163 540 minecraft:basalt
fill 239 163 543 245 167 543 minecraft:basalt
fill 239 163 546 246 164 546 minecraft:basalt
fill 239 163 549 246 163 549 minecraft:basalt
fill 240 163 516 246 163 516 minecraft:basalt
fill 240 163 550 243 163 550 minecraft:basalt
setblock 241 163 515 minecraft:magma_block
setblock 241 163 518 minecraft:magma_block
setblock 241 163 521 minecraft:magma_block
fill 241 163 523 243 169 523 minecraft:basalt
setblock 241 163 524 minecraft:magma_block
fill 241 163 526 243 171 526 minecraft:basalt
setblock 241 163 527 minecraft:magma_block
fill 241 163 529 241 172 529 minecraft:basalt
setblock 241 163 530 minecraft:magma_block
fill 241 163 532 241 172 532 minecraft:basalt
setblock 241 163 533 minecraft:magma_block
fill 241 163 535 241 172 535 minecraft:basalt
setblock 241 163 536 minecraft:magma_block
fill 241 163 538 242 171 538 minecraft:basalt
setblock 241 163 539 minecraft:magma_block
fill 241 163 541 243 170 541 minecraft:basalt
setblock 241 163 542 minecraft:magma_block
fill 241 163 544 243 168 544 minecraft:basalt
setblock 241 163 545 minecraft:magma_block
fill 241 163 547 243 165 547 minecraft:basalt
setblock 241 163 548 minecraft:magma_block
setblock 241 163 551 minecraft:magma_block
fill 242 163 515 249 163 515 minecraft:basalt
fill 242 163 518 249 166 518 minecraft:basalt
fill 242 163 521 247 168 521 minecraft:basalt
fill 242 163 524 244 170 524 minecraft:basalt
fill 242 163 527 242 172 527 minecraft:basalt
fill 242 163 539 242 172 539 minecraft:basalt
fill 242 163 542 244 170 542 minecraft:basalt
fill 242 163 545 247 168 545 minecraft:basalt
fill 242 163 548 249 166 548 minecraft:basalt
fill 242 163 551 249 163 551 minecraft:basalt
setblock 243 163 514 minecraft:basalt
fill 244 163 513 246 163 513 minecraft:basalt
setblock 244 163 514 minecraft:magma_block
setblock 244 163 517 minecraft:magma_block
setblock 244 163 520 minecraft:magma_block
setblock 244 163 523 minecraft:magma_block
setblock 244 163 544 minecraft:magma_block
setblock 244 163 547 minecraft:magma_block
setblock 244 163 550 minecraft:magma_block
fill 245 163 514 252 164 514 minecraft:basalt
fill 245 163 517 252 167 517 minecraft:basalt
fill 245 163 520 249 163 520 minecraft:basalt
fill 245 163 523 245 172 523 minecraft:basalt
fill 245 163 544 246 172 544 minecraft:basalt
fill 245 163 547 251 169 547 minecraft:basalt
fill 245 163 550 252 166 550 minecraft:basalt
fill 246 163 512 249 163 512 minecraft:basalt
setblock 246 163 529 minecraft:light[level=12]
setblock 246 163 537 minecraft:light[level=12]
setblock 247 163 513 minecraft:magma_block
setblock 247 163 516 minecraft:magma_block
setblock 247 163 519 minecraft:magma_block
setblock 247 163 546 minecraft:magma_block
setblock 247 163 549 minecraft:magma_block
fill 248 163 511 252 163 511 minecraft:basalt
fill 248 163 513 255 164 513 minecraft:basalt
fill 248 163 516 255 168 516 minecraft:basalt
fill 248 163 519 251 171 519 minecraft:basalt
fill 248 163 546 249 172 546 minecraft:basalt
fill 248 163 549 255 169 549 minecraft:basalt
setblock 250 163 512 minecraft:magma_block
setblock 250 163 515 minecraft:magma_block
setblock 250 163 518 minecraft:magma_block
setblock 250 163 548 minecraft:magma_block
setblock 250 163 551 minecraft:magma_block
fill 251 163 512 258 164 512 minecraft:basalt
fill 251 163 515 258 168 515 minecraft:basalt
fill 251 163 518 258 163 518 minecraft:basalt
fill 251 163 548 258 163 548 minecraft:basalt
fill 251 163 551 258 168 551 minecraft:basalt
fill 252 163 531 253 163 533 minecraft:amethyst_block
setblock 253 163 511 minecraft:magma_block
setblock 253 163 514 minecraft:magma_block
setblock 253 163 517 minecraft:magma_block
fill 253 163 529 254 163 530 minecraft:amethyst_block
fill 253 163 534 254 163 535 minecraft:amethyst_block
setblock 253 163 550 minecraft:magma_block
fill 254 163 511 261 163 511 minecraft:basalt
fill 254 163 514 261 167 514 minecraft:basalt
fill 254 163 517 261 169 517 minecraft:basalt
setblock 254 163 521 minecraft:light[level=12]
fill 254 163 531 254 163 532 minecraft:crying_obsidian
setblock 254 163 537 minecraft:light[level=12]
setblock 254 163 545 minecraft:light[level=12]
fill 254 163 550 261 169 550 minecraft:basalt
fill 255 163 528 257 163 529 minecraft:amethyst_block
setblock 255 163 531 minecraft:crying_obsidian
fill 255 163 535 255 163 536 minecraft:amethyst_block
setblock 256 163 513 minecraft:magma_block
setblock 256 163 516 minecraft:magma_block
fill 256 163 536 257 163 536 minecraft:amethyst_block
setblock 256 163 549 minecraft:magma_block
fill 257 163 513 264 165 513 minecraft:basalt
fill 257 163 516 264 167 516 minecraft:basalt
fill 257 163 531 258 163 531 minecraft:crying_obsidian
fill 257 163 535 259 163 535 minecraft:amethyst_block
fill 257 163 549 264 169 549 minecraft:basalt
fill 258 163 529 259 163 530 minecraft:amethyst_block
setblock 258 163 532 minecraft:crying_obsidian
fill 258 163 534 259 163 534 minecraft:amethyst_block
setblock 259 163 512 minecraft:magma_block
setblock 259 163 515 minecraft:magma_block
setblock 259 163 518 minecraft:magma_block
fill 259 163 531 260 163 533 minecraft:amethyst_block
setblock 259 163 548 minecraft:magma_block
setblock 259 163 551 minecraft:magma_block
fill 260 163 512 266 163 512 minecraft:basalt
fill 260 163 515 267 165 515 minecraft:basalt
fill 260 163 518 267 168 518 minecraft:basalt
fill 260 163 548 267 168 548 minecraft:basalt
fill 260 163 551 267 165 551 minecraft:basalt
fill 261 163 519 264 163 519 minecraft:basalt
fill 261 163 547 261 172 547 minecraft:basalt
setblock 262 163 511 minecraft:magma_block
setblock 262 163 514 minecraft:magma_block
setblock 262 163 517 minecraft:magma_block
setblock 262 163 521 minecraft:light[level=12]
setblock 262 163 529 minecraft:light[level=12]
setblock 262 163 537 minecraft:light[level=12]
setblock 262 163 545 minecraft:light[level=12]
setblock 262 163 547 minecraft:magma_block
setblock 262 163 550 minecraft:magma_block
fill 263 163 511 264 163 511 minecraft:basalt
fill 263 163 514 269 163 514 minecraft:basalt
fill 263 163 517 270 165 517 minecraft:basalt
fill 263 163 520 270 167 520 minecraft:basalt
fill 263 163 546 264 171 547 minecraft:basalt
fill 263 163 550 270 164 550 minecraft:basalt
setblock 265 163 513 minecraft:magma_block
setblock 265 163 516 minecraft:magma_block
setblock 265 163 519 minecraft:magma_block
fill 265 163 521 267 171 521 minecraft:basalt
fill 265 163 545 267 171 545 minecraft:basalt
setblock 265 163 546 minecraft:magma_block
fill 265 163 547 270 167 547 minecraft:basalt
setblock 265 163 549 minecraft:magma_block
fill 266 163 513 268 163 513 minecraft:basalt
fill 266 163 516 272 163 516 minecraft:basalt
fill 266 163 519 273 164 519 minecraft:basalt
fill 266 163 522 273 166 522 minecraft:basalt
fill 266 163 544 270 169 544 minecraft:basalt
fill 266 163 546 273 165 546 minecraft:basalt
fill 266 163 549 273 163 549 minecraft:basalt
fill 267 163 523 270 169 523 minecraft:basalt
fill 267 163 543 273 167 543 minecraft:basalt
setblock 268 163 515 minecraft:magma_block
setblock 268 163 518 minecraft:magma_block
setblock 268 163 521 minecraft:magma_block
setblock 268 163 524 minecraft:magma_block
setblock 268 163 542 minecraft:magma_block
setblock 268 163 545 minecraft:magma_block
setblock 268 163 548 minecraft:magma_block
setblock 268 163 551 minecraft:magma_block
fill 269 163 515 271 163 515 minecraft:basalt
fill 269 163 518 274 163 518 minecraft:basalt
fill 269 163 521 276 163 521 minecraft:basalt
fill 269 163 524 270 170 526 minecraft:basalt
fill 269 163 540 270 170 542 minecraft:basalt
fill 269 163 545 276 163 545 minecraft:basalt
fill 269 163 548 274 163 548 minecraft:basalt
fill 269 163 551 271 163 551 minecraft:basalt
setblock 270 163 513 minecraft:light[level=12]
fill 270 163 527 273 163 528 minecraft:basalt
setblock 270 163 529 minecraft:light[level=12]
setblock 270 163 537 minecraft:light[level=12]
fill 270 163 538 270 172 539 minecraft:basalt
setblock 271 163 517 minecraft:magma_block
setblock 271 163 520 minecraft:magma_block
setblock 271 163 523 minecraft:magma_block
fill 271 163 524 273 167 525 minecraft:basalt
setblock 271 163 526 minecraft:magma_block
setblock 271 163 529 minecraft:magma_block
fill 271 163 530 273 169 531 minecraft:basalt
setblock 271 163 532 minecraft:magma_block
fill 271 163 533 273 169 534 minecraft:basalt
setblock 271 163 535 minecraft:magma_block
fill 271 163 536 273 169 537 minecraft:basalt
setblock 271 163 538 minecraft:magma_block
fill 271 163 539 273 168 540 minecraft:basalt
setblock 271 163 541 minecraft:magma_block
fill 271 163 542 276 164 542 minecraft:basalt
setblock 271 163 544 minecraft:magma_block
setblock 271 163 547 minecraft:magma_block
setblock 271 163 550 minecraft:magma_block
fill 272 163 517 273 163 517 minecraft:basalt
fill 272 163 520 275 163 520 minecraft:basalt
fill 272 163 523 276 163 523 minecraft:basalt
fill 272 163 526 276 165 526 minecraft:basalt
fill 272 163 529 276 166 529 minecraft:basalt
fill 272 163 532 276 167 532 minecraft:basalt
fill 272 163 535 276 166 535 minecraft:basalt
fill 272 163 538 276 166 538 minecraft:basalt
fill 272 163 541 276 165 541 minecraft:basalt
fill 272 163 544 276 163 544 minecraft:basalt
fill 272 163 547 274 163 547 minecraft:basalt
setblock 272 163 550 minecraft:basalt
setblock 274 163 519 minecraft:magma_block
setblock 274 163 522 minecraft:magma_block
fill 274 163 524 276 164 524 minecraft:basalt
setblock 274 163 525 minecraft:magma_block
fill 274 163 527 276 166 527 minecraft:basalt
setblock 274 163 528 minecraft:magma_block
fill 274 163 530 276 166 530 minecraft:basalt
setblock 274 163 531 minecraft:magma_block
fill 274 163 533 276 167 533 minecraft:basalt
setblock 274 163 534 minecraft:magma_block
fill 274 163 536 276 166 536 minecraft:basalt
setblock 274 163 537 minecraft:magma_block
fill 274 163 539 276 166 539 minecraft:basalt
setblock 274 163 540 minecraft:magma_block
setblock 274 163 543 minecraft:magma_block
setblock 274 163 546 minecraft:magma_block
fill 275 163 522 276 163 522 minecraft:basalt
fill 275 163 525 276 165 525 minecraft:basalt
fill 275 163 528 276 166 528 minecraft:basalt
fill 275 163 531 276 166 531 minecraft:basalt
fill 275 163 534 276 166 534 minecraft:basalt
fill 275 163 537 276 166 537 minecraft:basalt
fill 275 163 540 276 165 540 minecraft:basalt
fill 275 163 543 276 164 543 minecraft:basalt
setblock 275 163 546 minecraft:basalt
fill 277 163 513 277 210 513 minecraft:black_concrete
setblock 277 163 514 minecraft:amethyst_block
fill 277 163 547 277 192 547 minecraft:black_concrete
fill 235 164 524 235 214 524 minecraft:black_concrete
fill 236 164 523 237 164 543 minecraft:basalt
setblock 237 164 521 minecraft:magma_block
fill 237 164 522 238 164 522 minecraft:basalt
setblock 237 164 544 minecraft:basalt
setblock 237 164 545 minecraft:magma_block
fill 238 164 520 248 164 520 minecraft:basalt
fill 238 164 525 238 167 525 minecraft:basalt
fill 238 164 528 238 168 528 minecraft:basalt
fill 238 164 531 238 169 531 minecraft:basalt
fill 238 164 534 238 169 534 minecraft:basalt
fill 238 164 537 238 168 537 minecraft:basalt
fill 238 164 540 242 167 540 minecraft:basalt
fill 238 164 543 238 166 543 minecraft:basalt
setblock 238 164 546 minecraft:basalt
fill 238 164 552 238 175 552 minecraft:black_concrete
fill 239 164 518 241 164 518 minecraft:basalt
fill 239 164 547 240 164 548 minecraft:basalt
fill 239 164 552 240 164 552 minecraft:crying_obsidian
setblock 240 164 517 minecraft:magma_block
fill 240 164 549 247 164 549 minecraft:basalt
fill 241 164 516 244 164 517 minecraft:basalt
fill 241 164 521 241 167 521 minecraft:basalt
fill 241 164 524 241 169 524 minecraft:basalt
fill 241 164 527 241 171 527 minecraft:basalt
fill 241 164 530 242 164 530 minecraft:basalt
fill 241 164 533 241 171 533 minecraft:basalt
fill 241 164 536 242 164 536 minecraft:basalt
fill 241 164 539 241 171 539 minecraft:basalt
fill 241 164 542 241 169 542 minecraft:basalt
fill 241 164 545 241 167 545 minecraft:basalt
fill 241 164 548 241 165 548 minecraft:basalt
fill 241 164 550 244 164 550 minecraft:basalt
fill 241 164 552 242 166 552 minecraft:black_concrete
fill 242 164 529 242 173 529 minecraft:basalt
fill 242 164 531 242 173 531 minecraft:basalt
fill 242 164 535 242 173 535 minecraft:basalt
fill 242 164 537 242 173 537 minecraft:basalt
fill 243 164 515 250 164 515 minecraft:basalt
fill 243 164 527 243 173 527 minecraft:basalt
fill 243 164 539 243 173 539 minecraft:basalt
setblock 243 164 540 minecraft:magma_block
fill 243 164 551 250 164 551 minecraft:basalt
setblock 243 164 552 minecraft:crying_obsidian
setblock 244 164 514 minecraft:basalt
fill 244 164 523 244 171 523 minecraft:basalt
fill 244 164 525 244 173 525 minecraft:basalt
fill 244 164 541 244 173 541 minecraft:basalt
fill 244 164 544 244 171 544 minecraft:basalt
fill 244 164 547 244 168 547 minecraft:basalt
fill 244 164 552 246 193 552 minecraft:black_concrete
fill 245 164 516 247 166 516 minecraft:basalt
fill 245 164 524 245 173 524 minecraft:basalt
fill 245 164 542 245 173 542 minecraft:basalt
fill 246 164 513 247 164 513 minecraft:basalt
fill 246 164 523 246 173 523 minecraft:basalt
fill 246 164 543 246 173 543 minecraft:basalt
fill 247 164 519 247 170 519 minecraft:basalt
fill 247 164 522 247 173 522 minecraft:basalt
fill 247 164 544 247 173 544 minecraft:basalt
fill 247 164 546 247 171 546 minecraft:basalt
fill 248 164 512 250 164 512 minecraft:basalt
fill 248 164 521 248 173 521 minecraft:basalt
fill 248 164 545 248 173 545 minecraft:basalt
setblock 249 164 520 minecraft:magma_block
fill 250 164 518 254 171 518 minecraft:basalt
fill 250 164 520 250 173 520 minecraft:basalt
fill 250 164 546 250 173 546 minecraft:basalt
fill 250 164 548 254 171 548 minecraft:basalt
fill 251 164 511 257 164 511 minecraft:basalt
setblock 252 164 519 minecraft:magma_block
fill 252 164 547 254 164 547 minecraft:basalt
fill 253 164 514 253 167 514 minecraft:basalt
fill 253 164 517 253 171 517 minecraft:basalt
fill 253 164 519 254 173 519 minecraft:basalt
fill 253 164 550 253 170 550 minecraft:basalt
fill 254 164 531 254 164 532 minecraft:amethyst_block
setblock 255 164 518 minecraft:magma_block
fill 255 164 530 255 164 531 minecraft:amethyst_block
setblock 255 164 548 minecraft:magma_block
fill 256 164 513 256 167 513 minecraft:basalt
fill 256 164 516 256 170 516 minecraft:basalt
fill 256 164 518 259 171 518 minecraft:basalt
fill 256 164 530 257 164 530 minecraft:amethyst_block
fill 256 164 548 256 171 549 minecraft:basalt
fill 257 164 531 258 164 531 minecraft:amethyst_block
fill 257 164 548 259 171 548 minecraft:basalt
setblock 258 164 511 minecraft:magma_block
fill 258 164 519 260 173 519 minecraft:basalt
setblock 258 164 532 minecraft:amethyst_block
setblock 258 164 547 minecraft:magma_block
fill 259 164 511 261 164 512 minecraft:basalt
fill 259 164 515 259 169 515 minecraft:basalt
fill 259 164 547 260 173 547 minecraft:basalt
fill 259 164 551 259 169 551 minecraft:basalt
setblock 261 164 519 minecraft:magma_block
fill 262 164 512 263 164 512 minecraft:basalt
fill 262 164 514 266 165 514 minecraft:basalt
fill 262 164 517 262 170 517 minecraft:basalt
fill 262 164 519 262 172 520 minecraft:basalt
fill 262 164 546 262 171 547 minecraft:basalt
fill 262 164 550 262 169 550 minecraft:basalt
fill 263 164 519 265 170 519 minecraft:basalt
setblock 264 164 512 minecraft:magma_block
setblock 264 164 521 minecraft:magma_block
setblock 264 164 545 minecraft:magma_block
fill 265 164 513 266 164 513 minecraft:basalt
fill 265 164 516 269 165 516 minecraft:basalt
fill 265 164 522 265 173 522 minecraft:basalt
fill 265 164 544 265 173 544 minecraft:basalt
fill 265 164 546 265 171 546 minecraft:basalt
fill 265 164 549 272 164 549 minecraft:basalt
fill 266 164 523 266 173 523 minecraft:basalt
fill 266 164 543 266 173 543 minecraft:basalt
setblock 267 164 514 minecraft:magma_block
fill 267 164 524 268 171 524 minecraft:basalt
fill 267 164 542 268 171 542 minecraft:basalt
fill 268 164 514 268 164 515 minecraft:basalt
fill 268 164 518 272 164 518 minecraft:basalt
fill 268 164 521 275 164 521 minecraft:basalt
fill 268 164 525 268 173 525 minecraft:basalt
fill 268 164 541 268 173 541 minecraft:basalt
fill 268 164 545 275 164 545 minecraft:basalt
fill 268 164 548 272 164 548 minecraft:basalt
fill 268 164 551 269 164 551 minecraft:basalt
setblock 269 164 515 minecraft:basalt
fill 269 164 527 273 164 527 minecraft:basalt
setblock 269 164 539 minecraft:basalt
setblock 270 164 516 minecraft:magma_block
setblock 270 164 528 minecraft:magma_block
fill 270 164 529 270 173 530 minecraft:basalt
setblock 270 164 531 minecraft:magma_block
fill 270 164 535 270 173 536 minecraft:basalt
setblock 270 164 537 minecraft:magma_block
fill 271 164 516 271 164 517 minecraft:basalt
fill 271 164 520 274 164 520 minecraft:basalt
fill 271 164 523 275 165 523 minecraft:basalt
fill 271 164 526 271 171 526 minecraft:basalt
fill 271 164 528 271 171 529 minecraft:basalt
fill 271 164 532 271 171 532 minecraft:basalt
fill 271 164 535 271 171 535 minecraft:basalt
fill 271 164 538 271 171 538 minecraft:basalt
fill 271 164 541 271 170 541 minecraft:basalt
fill 271 164 544 275 164 544 minecraft:basalt
fill 271 164 547 273 164 547 minecraft:basalt
setblock 271 164 550 minecraft:basalt
setblock 272 164 517 minecraft:basalt
fill 272 164 528 274 168 528 minecraft:basalt
setblock 273 164 518 minecraft:magma_block
setblock 273 164 548 minecraft:magma_block
setblock 274 164 510 minecraft:amethyst_block
fill 274 164 522 275 164 522 minecraft:basalt
fill 274 164 525 274 167 525 minecraft:basalt
fill 274 164 531 274 169 531 minecraft:basalt
fill 274 164 534 274 169 534 minecraft:basalt
fill 274 164 537 274 168 537 minecraft:basalt
fill 274 164 540 274 167 540 minecraft:basalt
fill 274 164 543 274 166 543 minecraft:basalt
setblock 274 164 546 minecraft:basalt
setblock 276 164 523 minecraft:magma_block
fill 277 164 514 277 234 514 minecraft:black_concrete
fill 277 164 523 277 183 523 minecraft:black_concrete
setblock 277 164 524 minecraft:crying_obsidian
fill 277 164 525 277 244 525 minecraft:black_concrete
fill 236 165 525 237 165 525 minecraft:basalt
setblock 236 165 526 minecraft:magma_block
fill 236 165 527 237 165 540 minecraft:basalt
setblock 236 165 541 minecraft:magma_block
fill 237 165 523 237 165 524 minecraft:basalt
fill 237 165 526 237 166 526 minecraft:basalt
fill 237 165 541 237 165 543 minecraft:basalt
setblock 238 165 522 minecraft:basalt
fill 239 165 520 249 165 520 minecraft:basalt
setblock 239 165 546 minecraft:magma_block
fill 239 165 552 240 220 552 minecraft:black_concrete
fill 240 165 519 246 165 519 minecraft:basalt
fill 240 165 546 240 165 547 minecraft:basalt
setblock 241 165 518 minecraft:basalt
fill 241 165 530 241 171 530 minecraft:basalt
fill 241 165 536 241 171 536 minecraft:basalt
fill 241 165 546 246 167 546 minecraft:basalt
fill 242 165 517 244 165 517 minecraft:basalt
setblock 242 165 530 minecraft:magma_block
fill 242 165 532 242 173 532 minecraft:basalt
setblock 242 165 533 minecraft:magma_block
fill 242 165 534 242 173 534 minecraft:basalt
setblock 242 165 536 minecraft:magma_block
fill 242 165 549 247 165 549 minecraft:basalt
fill 243 165 516 244 165 516 minecraft:basalt
fill 243 165 528 243 172 529 minecraft:basalt
fill 243 165 537 243 174 538 minecraft:basalt
fill 243 165 540 244 172 540 minecraft:basalt
fill 243 165 550 244 165 550 minecraft:basalt
fill 243 165 552 243 167 552 minecraft:black_concrete
fill 244 165 515 250 165 515 minecraft:basalt
fill 244 165 526 244 174 526 minecraft:basalt
fill 244 165 551 250 165 551 minecraft:basalt
fill 245 165 525 245 174 525 minecraft:basalt
setblock 245 165 541 minecraft:magma_block
fill 246 165 514 252 165 514 minecraft:basalt
fill 246 165 524 246 174 524 minecraft:basalt
fill 246 165 542 246 174 542 minecraft:basalt
fill 247 165 523 247 174 523 minecraft:basalt
fill 247 165 543 247 174 543 minecraft:basalt
setblock 248 165 513 minecraft:magma_block
setblock 248 165 522 minecraft:magma_block
fill 248 165 544 248 174 544 minecraft:basalt
fill 249 165 513 255 165 513 minecraft:basalt
fill 249 165 521 249 174 521 minecraft:basalt
fill 249 165 545 249 174 545 minecraft:basalt
setblock 251 165 512 minecraft:magma_block
fill 251 165 520 252 174 520 minecraft:basalt
fill 251 165 546 252 174 546 minecraft:basalt
fill 252 165 512 259 165 512 minecraft:basalt
fill 252 165 519 252 172 519 minecraft:basalt
fill 252 165 547 253 173 547 minecraft:basalt
setblock 254 165 547 minecraft:magma_block
fill 255 165 518 255 172 519 minecraft:basalt
fill 255 165 547 255 172 548 minecraft:basalt
fill 256 165 519 256 173 519 minecraft:basalt
fill 256 165 547 258 172 547 minecraft:basalt
setblock 256 165 552 minecraft:amethyst_block
setblock 257 165 519 minecraft:magma_block
fill 257 165 552 269 165 552 minecraft:black_concrete
setblock 260 165 512 minecraft:magma_block
fill 260 165 520 261 174 520 minecraft:basalt
fill 260 165 546 261 172 546 minecraft:basalt
setblock 261 165 512 minecraft:basalt
fill 261 165 519 261 172 519 minecraft:basalt
fill 263 165 521 264 172 521 minecraft:basalt
fill 263 165 545 264 172 545 minecraft:basalt
fill 263 165 550 269 165 550 minecraft:basalt
fill 264 165 522 264 174 522 minecraft:basalt
fill 264 165 544 264 174 544 minecraft:basalt
fill 265 165 523 265 174 523 minecraft:basalt
fill 265 165 543 265 174 543 minecraft:basalt
fill 265 165 549 270 165 549 minecraft:basalt
fill 266 165 519 272 165 519 minecraft:basalt
fill 266 165 524 266 174 524 minecraft:basalt
fill 266 165 542 266 174 542 minecraft:basalt
fill 267 165 525 267 174 525 minecraft:basalt
fill 267 165 541 267 174 541 minecraft:basalt
setblock 268 165 515 minecraft:basalt
fill 268 165 518 271 165 518 minecraft:basalt
fill 268 165 521 274 165 521 minecraft:basalt
fill 268 165 526 268 174 526 minecraft:basalt
fill 268 165 540 268 174 540 minecraft:basalt
fill 268 165 545 274 165 545 minecraft:basalt
fill 268 165 548 271 165 548 minecraft:basalt
setblock 268 165 551 minecraft:basalt
setblock 269 165 527 minecraft:magma_block
fill 269 165 528 269 174 529 minecraft:basalt
fill 269 165 537 269 174 538 minecraft:basalt
setblock 269 165 539 minecraft:magma_block
fill 270 165 527 270 172 528 minecraft:basalt
fill 270 165 531 270 172 534 minecraft:basalt
fill 270 165 537 270 172 537 minecraft:basalt
fill 271 165 520 273 165 520 minecraft:basalt
fill 271 165 527 273 169 527 minecraft:basalt
fill 271 165 542 275 165 542 minecraft:basalt
fill 271 165 544 274 165 544 minecraft:basalt
fill 271 165 547 271 166 547 minecraft:basalt
setblock 272 165 547 minecraft:magma_block
fill 274 165 510 274 297 510 minecraft:black_concrete
setblock 274 165 522 minecraft:basalt
fill 274 165 524 275 165 524 minecraft:basalt
setblock 275 165 543 minecraft:magma_block
setblock 277 165 515 minecraft:crying_obsidian
fill 277 165 524 277 239 524 minecraft:black_concrete
fill 236 166 527 237 166 539 minecraft:basalt
setblock 237 166 525 minecraft:basalt
fill 237 166 540 237 166 541 minecraft:basalt
fill 238 166 523 240 166 523 minecraft:basalt
setblock 238 166 524 minecraft:magma_block
fill 238 166 541 240 167 541 minecraft:basalt
setblock 238 166 542 minecraft:magma_block
fill 239 166 521 240 166 521 minecraft:basalt
fill 239 166 524 240 167 524 minecraft:basalt
fill 239 166 542 240 167 542 minecraft:basalt
fill 239 166 544 240 166 545 minecraft:basalt
fill 240 166 520 249 166 520 minecraft:basalt
setblock 240 166 546 minecraft:basalt
fill 241 166 519 246 166 519 minecraft:basalt
setblock 241 166 547 minecraft:magma_block
fill 242 166 530 243 173 530 minecraft:basalt
fill 242 166 533 243 166 533 minecraft:basalt
fill 242 166 536 243 173 536 minecraft:basalt
fill 242 166 547 243 167 547 minecraft:basalt
fill 243 166 517 244 166 517 minecraft:basalt
fill 243 166 531 243 174 532 minecraft:basalt
fill 243 166 534 243 174 535 minecraft:basalt
fill 243 166 549 247 166 549 minecraft:basalt
setblock 244 166 516 minecraft:magma_block
fill 244 166 527 244 174 527 minecraft:basalt
setblock 244 166 528 minecraft:magma_block
fill 244 166 538 244 174 539 minecraft:basalt
setblock 244 166 550 minecraft:basalt
fill 245 166 526 245 175 526 minecraft:basalt
fill 245 166 540 245 173 541 minecraft:basalt
setblock 246 166 515 minecraft:basalt
setblock 246 166 551 minecraft:basalt
setblock 247 166 515 minecraft:magma_block
setblock 247 166 551 minecraft:magma_block
fill 248 166 514 250 166 515 minecraft:basalt
fill 248 166 522 249 173 522 minecraft:basalt
fill 248 166 551 250 167 551 minecraft:basalt
fill 249 166 544 249 175 544 minecraft:basalt
fill 250 166 513 252 166 513 minecraft:basalt
fill 250 166 521 251 174 521 minecraft:basalt
fill 250 166 545 251 174 545 minecraft:basalt
fill 251 166 514 252 167 514 minecraft:basalt
setblock 253 166 513 minecraft:magma_block
fill 253 166 520 258 166 520 minecraft:basalt
setblock 253 166 546 minecraft:magma_block
fill 254 166 513 255 166 513 minecraft:basalt
fill 254 166 546 254 173 547 minecraft:basalt
fill 255 166 546 259 166 546 minecraft:basalt
fill 256 166 552 261 166 552 minecraft:black_concrete
fill 257 166 513 261 166 513 minecraft:basalt
fill 257 166 519 257 173 519 minecraft:basalt
setblock 259 166 520 minecraft:magma_block
fill 260 166 515 264 167 515 minecraft:basalt
fill 260 166 551 264 167 551 minecraft:basalt
fill 261 166 521 262 166 521 minecraft:basalt
fill 261 166 545 262 166 545 minecraft:basalt
setblock 262 166 513 minecraft:magma_block
fill 262 166 514 264 166 514 minecraft:basalt
setblock 262 166 552 minecraft:amethyst_block
fill 263 166 517 269 166 517 minecraft:basalt
fill 263 166 522 263 175 522 minecraft:basalt
fill 263 166 542 264 166 543 minecraft:bone_block
fill 263 166 544 263 175 544 minecraft:basalt
fill 263 166 550 267 166 550 minecraft:basalt
fill 263 166 552 269 168 552 minecraft:black_concrete
fill 264 166 541 266 166 541 minecraft:bone_block
setblock 265 166 515 minecraft:magma_block
fill 265 166 516 268 166 516 minecraft:basalt
fill 265 166 540 266 166 540 minecraft:bone_block
setblock 265 166 542 minecraft:bone_block
fill 265 166 549 269 166 549 minecraft:basalt
setblock 265 166 551 minecraft:magma_block
setblock 266 166 515 minecraft:basalt
fill 266 166 519 270 167 519 minecraft:basalt
fill 266 166 539 267 166 539 minecraft:bone_block
fill 266 166 546 272 166 546 minecraft:basalt
setblock 266 166 551 minecraft:basalt
fill 267 166 510 267 214 510 minecraft:black_concrete
fill 267 166 526 267 175 526 minecraft:basalt
fill 267 166 540 267 175 540 minecraft:basalt
setblock 268 166 510 minecraft:white_concrete
fill 268 166 518 270 166 518 minecraft:basalt
fill 268 166 521 273 166 521 minecraft:basalt
fill 268 166 527 268 174 528 minecraft:basalt
setblock 268 166 538 minecraft:magma_block
fill 268 166 539 269 173 539 minecraft:basalt
fill 268 166 545 273 166 545 minecraft:basalt
fill 268 166 548 270 166 548 minecraft:basalt
setblock 268 166 550 minecraft:magma_block
fill 269 166 527 269 173 527 minecraft:basalt
fill 269 166 530 269 173 536 minecraft:basalt
setblock 271 166 519 minecraft:magma_block
fill 271 166 520 272 166 520 minecraft:basalt
fill 271 166 523 274 166 523 minecraft:basalt
fill 271 166 542 273 167 542 minecraft:basalt
fill 271 166 544 273 166 544 minecraft:basalt
fill 272 166 526 275 166 526 minecraft:basalt
fill 272 166 541 275 166 541 minecraft:basalt
setblock 274 166 524 minecraft:magma_block
setblock 274 166 542 minecraft:magma_block
setblock 275 166 525 minecraft:basalt
setblock 275 166 540 minecraft:basalt
setblock 277 166 515 minecraft:amethyst_block
fill 236 167 532 237 167 534 minecraft:basalt
fill 237 167 527 237 167 528 minecraft:basalt
setblock 237 167 529 minecraft:magma_block
fill 237 167 530 237 167 531 minecraft:basalt
setblock 237 167 535 minecraft:magma_block
fill 237 167 536 237 167 537 minecraft:basalt
setblock 237 167 538 minecraft:magma_block
setblock 237 167 539 minecraft:basalt
fill 239 167 523 240 167 523 minecraft:basalt
setblock 240 167 521 minecraft:basalt
setblock 240 167 522 minecraft:magma_block
fill 240 167 544 240 167 545 minecraft:basalt
fill 241 167 520 249 167 520 minecraft:basalt
fill 241 167 522 246 168 522 minecraft:basalt
setblock 241 167 552 minecraft:amethyst_block
fill 242 167 519 246 167 519 minecraft:basalt
fill 242 167 533 242 173 533 minecraft:basalt
fill 242 167 552 242 307 552 minecraft:black_concrete
setblock 243 167 518 minecraft:magma_block
setblock 243 167 533 minecraft:magma_block
setblock 243 167 548 minecraft:magma_block
fill 244 167 517 244 167 518 minecraft:basalt
fill 244 167 528 244 174 530 minecraft:basalt
fill 244 167 536 244 174 537 minecraft:basalt
fill 244 167 548 247 167 549 minecraft:basalt
fill 245 167 518 249 168 518 minecraft:basalt
fill 245 167 527 245 175 527 minecraft:basalt
fill 245 167 539 245 175 539 minecraft:basalt
fill 246 167 516 247 167 516 minecraft:basalt
fill 246 167 525 246 175 525 minecraft:basalt
setblock 246 167 526 minecraft:magma_block
fill 246 167 540 246 175 540 minecraft:basalt
setblock 246 167 541 minecraft:magma_block
setblock 246 167 550 minecraft:magma_block
fill 247 167 524 247 174 524 minecraft:basalt
fill 247 167 542 247 174 542 minecraft:basalt
fill 247 167 550 252 167 550 minecraft:basalt
fill 248 167 515 250 167 515 minecraft:basalt
fill 248 167 523 249 175 523 minecraft:basalt
fill 248 167 543 248 175 543 minecraft:basalt
fill 248 167 548 249 169 548 minecraft:basalt
setblock 249 167 543 minecraft:magma_block
setblock 250 167 514 minecraft:basalt
fill 250 167 522 250 175 522 minecraft:basalt
fill 250 167 544 250 174 544 minecraft:basalt
setblock 252 167 521 minecraft:magma_block
setblock 252 167 545 minecraft:magma_block
fill 253 167 520 253 174 521 minecraft:basalt
fill 253 167 545 253 174 546 minecraft:basalt
fill 254 167 520 254 173 520 minecraft:basalt
setblock 255 167 513 minecraft:basalt
setblock 255 167 520 minecraft:magma_block
fill 255 167 546 257 173 546 minecraft:basalt
fill 256 167 520 259 174 520 minecraft:basalt
setblock 256 167 552 minecraft:white_concrete
setblock 257 167 513 minecraft:basalt
fill 257 167 552 262 168 552 minecraft:black_concrete
setblock 258 167 546 minecraft:magma_block
fill 259 167 521 260 175 521 minecraft:basalt
fill 259 167 545 259 174 546 minecraft:basalt
fill 260 167 545 260 175 545 minecraft:basalt
setblock 261 167 521 minecraft:magma_block
setblock 261 167 545 minecraft:magma_block
setblock 262 167 514 minecraft:basalt
fill 262 167 521 262 174 522 minecraft:basalt
fill 262 167 544 262 174 545 minecraft:basalt
fill 263 167 517 268 167 517 minecraft:basalt
fill 263 167 523 263 175 523 minecraft:basalt
fill 263 167 543 264 167 543 minecraft:basalt
fill 263 167 550 266 167 550 minecraft:basalt
setblock 264 167 523 minecraft:magma_block
fill 264 167 541 264 167 542 minecraft:bone_block
fill 265 167 516 266 167 516 minecraft:basalt
fill 265 167 524 265 174 524 minecraft:basalt
fill 265 167 539 265 167 541 minecraft:bone_block
fill 265 167 542 265 174 542 minecraft:basalt
fill 265 167 549 266 168 549 minecraft:basalt
fill 266 167 522 272 167 522 minecraft:basalt
fill 266 167 525 266 175 526 minecraft:basalt
setblock 266 167 539 minecraft:bone_block
fill 266 167 540 266 175 541 minecraft:basalt
fill 266 167 546 271 167 546 minecraft:basalt
fill 267 167 527 267 175 527 minecraft:basalt
setblock 267 167 538 minecraft:bone_block
fill 267 167 539 267 175 539 minecraft:basalt
setblock 267 167 549 minecraft:magma_block
fill 268 167 510 268 223 510 minecraft:black_concrete
fill 268 167 518 269 167 518 minecraft:basalt
fill 268 167 521 272 167 521 minecraft:basalt
fill 268 167 529 268 174 530 minecraft:basalt
fill 268 167 536 268 174 538 minecraft:basalt
fill 268 167 545 272 167 545 minecraft:basalt
fill 268 167 548 268 167 549 minecraft:basalt
setblock 269 167 548 minecraft:basalt
setblock 271 167 520 minecraft:basalt
fill 271 167 523 272 168 523 minecraft:basalt
fill 271 167 544 272 167 544 minecraft:basalt
fill 272 167 526 274 167 526 minecraft:basalt
fill 272 167 529 275 167 529 minecraft:basalt
fill 272 167 535 275 168 535 minecraft:basalt
fill 272 167 538 275 167 538 minecraft:basalt
fill 272 167 541 274 167 541 minecraft:basalt
setblock 273 167 523 minecraft:magma_block
fill 274 167 527 275 167 527 minecraft:basalt
fill 274 167 530 275 167 530 minecraft:basalt
fill 274 167 536 275 167 536 minecraft:basalt
fill 274 167 539 275 167 539 minecraft:basalt
setblock 275 167 528 minecraft:basalt
fill 275 167 531 275 168 531 minecraft:basalt
fill 275 167 534 275 168 534 minecraft:basalt
setblock 275 167 537 minecraft:basalt
setblock 276 167 534 minecraft:magma_block
fill 277 167 515 277 228 515 minecraft:black_concrete
setblock 235 168 515 minecraft:white_concrete
setblock 235 168 525 minecraft:white_concrete
fill 235 168 539 235 192 539 minecraft:black_concrete
setblock 235 168 540 minecraft:crying_obsidian
fill 237 168 531 237 168 535 minecraft:basalt
fill 238 168 527 240 168 527 minecraft:basalt
fill 239 168 526 240 168 526 minecraft:basalt
fill 239 168 540 240 168 541 minecraft:basalt
fill 240 168 523 240 168 524 minecraft:basalt
fill 240 168 542 240 168 543 minecraft:basalt
fill 241 168 540 242 171 540 minecraft:basalt
fill 241 168 543 245 168 543 minecraft:basalt
fill 241 168 552 241 307 552 minecraft:black_concrete
setblock 242 168 520 minecraft:magma_block
fill 242 168 546 246 168 546 minecraft:basalt
fill 243 168 519 246 168 520 minecraft:basalt
fill 243 168 533 244 175 533 minecraft:basalt
setblock 243 168 547 minecraft:basalt
setblock 243 168 552 minecraft:amethyst_block
fill 244 168 531 244 174 532 minecraft:basalt
fill 244 168 534 244 176 535 minecraft:basalt
setblock 245 168 528 minecraft:magma_block
fill 245 168 529 245 176 529 minecraft:basalt
setblock 245 168 537 minecraft:magma_block
fill 245 168 538 245 176 538 minecraft:basalt
fill 245 168 548 247 168 548 minecraft:basalt
fill 246 168 517 252 168 517 minecraft:basalt
fill 246 168 526 246 175 527 minecraft:basalt
fill 246 168 539 246 176 539 minecraft:basalt
fill 246 168 541 247 175 541 minecraft:basalt
fill 246 168 549 247 168 549 minecraft:basalt
fill 247 168 520 249 171 520 minecraft:basalt
fill 247 168 525 247 176 525 minecraft:basalt
setblock 248 168 524 minecraft:magma_block
setblock 248 168 542 minecraft:magma_block
fill 248 168 550 252 168 550 minecraft:basalt
fill 249 168 543 250 168 543 minecraft:basalt
setblock 250 168 515 minecraft:basalt
fill 250 168 523 250 176 523 minecraft:basalt
setblock 250 168 551 minecraft:basalt
fill 251 168 522 252 176 522 minecraft:basalt
setblock 251 168 544 minecraft:magma_block
fill 252 168 521 252 175 521 minecraft:basalt
fill 252 168 544 252 175 545 minecraft:basalt
fill 254 168 514 258 168 514 minecraft:basalt
fill 254 168 521 256 176 521 minecraft:basalt
fill 254 168 545 256 176 545 minecraft:basalt
fill 255 168 520 255 175 520 minecraft:basalt
fill 256 168 552 256 189 552 minecraft:black_concrete
fill 257 168 516 262 169 516 minecraft:basalt
setblock 257 168 521 minecraft:magma_block
setblock 257 168 545 minecraft:magma_block
fill 258 168 521 258 176 521 minecraft:basalt
fill 258 168 545 258 174 546 minecraft:basalt
fill 260 168 515 262 168 515 minecraft:basalt
fill 260 168 522 261 176 522 minecraft:basalt
setblock 260 168 544 minecraft:magma_block
fill 260 168 551 262 168 551 minecraft:basalt
fill 261 168 521 261 175 521 minecraft:basalt
fill 261 168 544 261 175 545 minecraft:basalt
fill 262 168 523 262 176 523 minecraft:basalt
fill 262 168 543 262 176 543 minecraft:basalt
setblock 263 168 510 minecraft:crying_obsidian
setblock 263 168 516 minecraft:magma_block
fill 263 168 517 266 168 517 minecraft:basalt
fill 263 168 520 268 169 520 minecraft:basalt
setblock 263 168 543 minecraft:magma_block
fill 263 168 550 264 168 550 minecraft:basalt
setblock 264 168 516 minecraft:basalt
fill 264 168 523 264 175 524 minecraft:basalt
fill 264 168 542 264 175 543 minecraft:basalt
fill 265 168 525 265 176 525 minecraft:basalt
setblock 265 168 540 minecraft:bone_block
fill 265 168 541 265 176 541 minecraft:basalt
fill 265 168 547 268 168 547 minecraft:basalt
fill 266 168 519 269 168 519 minecraft:basalt
fill 266 168 522 271 168 522 minecraft:basalt
setblock 266 168 527 minecraft:magma_block
setblock 266 168 538 minecraft:bone_block
setblock 266 168 539 minecraft:magma_block
fill 266 168 546 270 168 546 minecraft:basalt
fill 267 168 528 267 175 529 minecraft:basalt
fill 267 168 537 267 175 538 minecraft:basalt
fill 267 168 543 271 169 543 minecraft:basalt
fill 268 168 521 270 168 521 minecraft:basalt
fill 268 168 531 268 174 535 minecraft:basalt
fill 268 168 545 270 168 545 minecraft:basalt
setblock 269 168 520 minecraft:magma_block
setblock 269 168 547 minecraft:magma_block
setblock 270 168 520 minecraft:basalt
fill 271 168 524 272 168 525 minecraft:basalt
fill 271 168 542 272 168 542 minecraft:basalt
setblock 271 168 544 minecraft:basalt
fill 272 168 526 273 168 526 minecraft:basalt
fill 272 168 529 274 168 529 minecraft:basalt
fill 272 168 532 275 168 532 minecraft:basalt
fill 272 168 538 274 168 538 minecraft:basalt
fill 272 168 541 273 168 541 minecraft:basalt
setblock 272 168 543 minecraft:magma_block
setblock 273 168 525 minecraft:basalt
setblock 274 168 527 minecraft:basalt
fill 274 168 530 274 169 530 minecraft:basalt
fill 274 168 533 274 169 533 minecraft:basalt
fill 274 168 536 274 169 536 minecraft:basalt
setblock 274 168 539 minecraft:basalt
setblock 275 168 533 minecraft:magma_block
setblock 277 168 542 minecraft:white_concrete
fill 277 168 543 277 252 543 minecraft:black_concrete
fill 235 169 515 235 197 515 minecraft:black_concrete
fill 235 169 525 235 205 525 minecraft:black_concrete
fill 235 169 540 235 232 540 minecraft:black_concrete
fill 235 169 545 235 195 546 minecraft:black_concrete
setblock 235 169 547 minecraft:white_concrete
fill 238 169 530 240 169 530 minecraft:basalt
setblock 238 169 532 minecraft:magma_block
fill 238 169 533 240 169 533 minecraft:basalt
setblock 238 169 535 minecraft:magma_block
fill 238 169 536 240 169 536 minecraft:basalt
fill 239 169 527 240 169 527 minecraft:basalt
fill 239 169 529 240 169 529 minecraft:basalt
fill 239 169 532 240 170 532 minecraft:basalt
fill 239 169 535 240 170 535 minecraft:basalt
fill 239 169 538 240 169 539 minecraft:basalt
fill 240 169 525 240 169 526 minecraft:basalt
fill 240 169 540 240 169 541 minecraft:basalt
fill 241 169 525 243 170 525 minecraft:basalt
setblock 241 169 543 minecraft:magma_block
fill 242 169 522 246 169 522 minecraft:basalt
fill 242 169 543 243 169 544 minecraft:basalt
fill 243 169 521 247 169 521 minecraft:basalt
fill 243 169 545 247 169 545 minecraft:basalt
fill 243 169 552 243 218 552 minecraft:black_concrete
fill 244 169 520 246 169 520 minecraft:basalt
fill 244 169 543 245 172 543 minecraft:basalt
fill 244 169 546 246 169 546 minecraft:basalt
fill 245 169 519 246 169 519 minecraft:basalt
fill 245 169 528 246 169 528 minecraft:basalt
fill 245 169 530 245 176 537 minecraft:basalt
fill 246 169 518 249 169 518 minecraft:basalt
fill 246 169 538 246 177 538 minecraft:basalt
fill 246 169 548 247 169 548 minecraft:basalt
setblock 247 169 526 minecraft:magma_block
fill 247 169 540 247 176 540 minecraft:basalt
fill 248 169 517 252 169 517 minecraft:basalt
fill 248 169 524 248 176 525 minecraft:basalt
fill 248 169 541 248 176 542 minecraft:basalt
fill 249 169 524 249 176 524 minecraft:basalt
fill 249 169 542 249 175 543 minecraft:basalt
setblock 250 169 516 minecraft:magma_block
setblock 250 169 543 minecraft:magma_block
fill 250 169 550 252 169 550 minecraft:basalt
fill 251 169 516 255 169 516 minecraft:basalt
fill 251 169 523 251 176 523 minecraft:basalt
fill 251 169 543 251 176 544 minecraft:basalt
setblock 253 169 515 minecraft:magma_block
fill 253 169 522 258 169 522 minecraft:basalt
fill 253 169 544 255 176 544 minecraft:basalt
setblock 253 169 551 minecraft:magma_block
fill 254 169 515 258 169 515 minecraft:basalt
fill 254 169 551 258 169 551 minecraft:basalt
setblock 256 169 544 minecraft:magma_block
fill 257 169 521 257 176 521 minecraft:basalt
fill 257 169 544 257 176 545 minecraft:basalt
setblock 257 169 552 minecraft:white_concrete
fill 258 169 544 260 176 544 minecraft:basalt
fill 258 169 552 268 170 552 minecraft:black_concrete
setblock 259 169 522 minecraft:magma_block
fill 260 169 518 266 169 518 minecraft:basalt
fill 260 169 548 266 169 548 minecraft:basalt
setblock 261 169 523 minecraft:basalt
fill 261 169 543 261 177 543 minecraft:basalt
fill 263 169 510 265 181 510 minecraft:black_concrete
fill 263 169 517 264 169 517 minecraft:basalt
fill 263 169 524 263 176 524 minecraft:basalt
fill 263 169 542 263 175 543 minecraft:basalt
fill 264 169 525 264 176 525 minecraft:basalt
fill 264 169 541 264 175 541 minecraft:basalt
setblock 265 169 526 minecraft:magma_block
fill 265 169 540 265 176 540 minecraft:basalt
fill 265 169 547 267 169 547 minecraft:basalt
setblock 266 169 510 minecraft:amethyst_block
fill 266 169 519 267 169 519 minecraft:basalt
fill 266 169 522 270 169 522 minecraft:basalt
fill 266 169 527 266 176 528 minecraft:basalt
fill 266 169 538 266 176 539 minecraft:basalt
fill 266 169 546 267 170 546 minecraft:basalt
fill 267 169 530 267 169 536 minecraft:basalt
fill 268 169 521 269 169 521 minecraft:basalt
fill 268 169 545 269 169 545 minecraft:basalt
setblock 268 169 546 minecraft:magma_block
setblock 269 169 552 minecraft:crying_obsidian
setblock 271 169 523 minecraft:basalt
setblock 271 169 524 minecraft:magma_block
fill 271 169 525 272 169 525 minecraft:basalt
fill 271 169 539 272 169 540 minecraft:basalt
setblock 271 169 542 minecraft:magma_block
setblock 272 169 526 minecraft:basalt
fill 272 169 528 273 169 529 minecraft:basalt
fill 272 169 532 273 170 532 minecraft:basalt
fill 272 169 535 273 170 535 minecraft:basalt
fill 272 169 538 273 169 538 minecraft:basalt
setblock 272 169 541 minecraft:basalt
setblock 273 169 539 minecraft:basalt
setblock 274 169 532 minecraft:magma_block
setblock 274 169 535 minecraft:magma_block
fill 277 169 542 277 235 542 minecraft:black_concrete
setblock 235 170 535 minecraft:crying_obsidian
fill 235 170 547 235 205 547 minecraft:black_concrete
fill 239 170 530 240 170 530 minecraft:basalt
fill 239 170 533 240 170 533 minecraft:basalt
fill 239 170 536 240 170 536 minecraft:basalt
fill 240 170 524 241 171 524 minecraft:amethyst_block
setblock 240 170 527 minecraft:magma_block
fill 240 170 528 240 170 529 minecraft:basalt
fill 240 170 537 240 170 538 minecraft:basalt
setblock 240 170 539 minecraft:magma_block
fill 241 170 528 242 171 528 minecraft:basalt
fill 241 170 537 241 172 537 minecraft:basalt
fill 242 170 523 243 170 523 minecraft:basalt
fill 242 170 543 243 170 543 minecraft:basalt
fill 243 170 522 246 170 522 minecraft:basalt
setblock 243 170 544 minecraft:magma_block
fill 244 170 521 247 170 521 minecraft:basalt
fill 244 170 545 247 170 545 minecraft:basalt
fill 245 170 520 246 170 520 minecraft:basalt
fill 245 170 528 245 176 528 minecraft:basalt
fill 245 170 546 246 170 546 minecraft:basalt
setblock 246 170 519 minecraft:magma_block
setblock 246 170 528 minecraft:magma_block
fill 246 170 529 246 177 530 minecraft:basalt
fill 246 170 536 246 177 536 minecraft:basalt
setblock 246 170 537 minecraft:magma_block
fill 246 170 547 251 170 547 minecraft:basalt
fill 247 170 526 247 176 527 minecraft:basalt
fill 247 170 539 247 177 539 minecraft:basalt
setblock 248 170 518 minecraft:basalt
fill 248 170 526 248 177 526 minecraft:basalt
fill 248 170 540 248 177 540 minecraft:basalt
setblock 248 170 548 minecraft:basalt
setblock 249 170 518 minecraft:magma_block
fill 249 170 525 249 177 525 minecraft:basalt
fill 249 170 541 249 177 541 minecraft:basalt
setblock 249 170 548 minecraft:magma_block
fill 250 170 517 251 170 517 minecraft:basalt
fill 250 170 524 250 177 524 minecraft:basalt
fill 250 170 542 250 176 543 minecraft:basalt
fill 250 170 549 255 170 549 minecraft:basalt
setblock 252 170 517 minecraft:magma_block
setblock 252 170 523 minecraft:magma_block
fill 252 170 543 253 177 543 minecraft:basalt
fill 253 170 516 254 170 516 minecraft:basalt
fill 253 170 522 253 176 523 minecraft:basalt
fill 254 170 517 260 170 517 minecraft:basalt
fill 254 170 522 254 176 522 minecraft:basalt
fill 254 170 550 259 170 550 minecraft:basalt
setblock 255 170 516 minecraft:magma_block
setblock 255 170 522 minecraft:magma_block
fill 256 170 522 259 176 522 minecraft:basalt
fill 256 170 544 256 177 544 minecraft:basalt
fill 257 170 516 259 170 516 minecraft:basalt
fill 257 170 549 262 170 549 minecraft:basalt
fill 257 170 552 257 200 552 minecraft:black_concrete
fill 259 170 523 260 176 523 minecraft:basalt
fill 259 170 543 260 177 543 minecraft:basalt
fill 260 170 518 264 170 518 minecraft:basalt
fill 260 170 548 264 170 548 minecraft:basalt
setblock 261 170 517 minecraft:magma_block
setblock 261 170 523 minecraft:magma_block
fill 262 170 524 262 177 524 minecraft:basalt
fill 262 170 542 262 177 542 minecraft:basalt
fill 263 170 520 267 170 520 minecraft:basalt
fill 263 170 525 263 176 525 minecraft:basalt
fill 263 170 541 263 177 541 minecraft:basalt
fill 264 170 526 265 176 526 minecraft:basalt
setblock 264 170 540 minecraft:magma_block
fill 265 170 527 265 177 527 minecraft:basalt
fill 265 170 539 265 177 539 minecraft:basalt
fill 265 170 547 266 170 547 minecraft:basalt
fill 266 170 510 266 175 510 minecraft:black_concrete
setblock 266 170 519 minecraft:basalt
fill 266 170 522 269 170 522 minecraft:basalt
fill 266 170 529 266 176 530 minecraft:basalt
fill 266 170 536 266 176 537 minecraft:basalt
fill 266 170 544 269 170 544 minecraft:basalt
fill 267 170 523 269 171 523 minecraft:basalt
fill 267 170 530 267 176 532 minecraft:basalt
setblock 267 170 533 minecraft:magma_block
fill 267 170 534 267 176 536 minecraft:basalt
fill 267 170 543 270 170 543 minecraft:basalt
setblock 268 170 521 minecraft:basalt
setblock 268 170 545 minecraft:basalt
fill 269 170 552 269 181 552 minecraft:black_concrete
setblock 270 170 523 minecraft:magma_block
setblock 271 170 525 minecraft:basalt
fill 271 170 527 272 170 527 minecraft:basalt
fill 271 170 530 272 170 531 minecraft:basalt
fill 271 170 533 272 170 534 minecraft:basalt
fill 271 170 536 272 170 537 minecraft:basalt
fill 271 170 539 271 171 540 minecraft:basalt
fill 272 170 528 272 170 529 minecraft:basalt
fill 272 170 538 272 170 539 minecraft:basalt
setblock 273 170 530 minecraft:basalt
setblock 273 170 531 minecraft:magma_block
setblock 273 170 533 minecraft:basalt
setblock 273 170 534 minecraft:magma_block
setblock 273 170 536 minecraft:basalt
setblock 277 170 546 minecraft:crying_obsidian
fill 235 171 518 235 173 518 minecraft:purple_concrete
fill 235 171 519 235 208 522 minecraft:black_concrete
fill 235 171 534 235 173 534 minecraft:purple_concrete
fill 235 171 535 235 231 535 minecraft:black_concrete
fill 235 171 549 235 252 549 minecraft:black_concrete
fill 235 171 550 235 173 550 minecraft:purple_concrete
fill 236 171 510 236 183 510 minecraft:black_concrete
setblock 237 171 510 minecraft:crying_obsidian
fill 238 171 510 238 181 510 minecraft:black_concrete
setblock 238 171 513 minecraft:light[level=12]
setblock 238 171 521 minecraft:light[level=12]
setblock 238 171 529 minecraft:light[level=12]
setblock 238 171 537 minecraft:light[level=12]
setblock 238 171 545 minecraft:light[level=12]
fill 239 171 510 239 173 510 minecraft:purple_concrete
fill 240 171 529 240 171 537 minecraft:basalt
fill 241 171 531 241 172 531 minecraft:basalt
fill 241 171 534 241 172 534 minecraft:basalt
setblock 242 171 525 minecraft:magma_block
fill 242 171 541 243 171 541 minecraft:basalt
fill 243 171 523 243 171 525 minecraft:basalt
fill 243 171 542 243 171 543 minecraft:basalt
fill 244 171 522 246 171 522 minecraft:basalt
fill 244 171 524 244 172 524 minecraft:basalt
fill 244 171 542 244 172 542 minecraft:basalt
setblock 245 171 521 minecraft:magma_block
setblock 245 171 545 minecraft:magma_block
setblock 246 171 513 minecraft:light[level=12]
fill 246 171 520 246 171 521 minecraft:basalt
fill 246 171 528 247 177 528 minecraft:basalt
fill 246 171 531 246 178 535 minecraft:basalt
fill 246 171 537 247 171 537 minecraft:basalt
fill 246 171 545 246 171 546 minecraft:basalt
fill 247 171 521 247 172 521 minecraft:basalt
fill 247 171 529 247 177 529 minecraft:basalt
fill 247 171 538 247 177 538 minecraft:basalt
fill 247 171 545 247 172 545 minecraft:basalt
fill 248 171 527 248 178 527 minecraft:basalt
fill 248 171 539 248 178 539 minecraft:basalt
setblock 248 171 547 minecraft:magma_block
setblock 249 171 518 minecraft:basalt
fill 249 171 526 249 178 526 minecraft:basalt
fill 249 171 540 249 178 540 minecraft:basalt
fill 249 171 547 249 171 548 minecraft:basalt
fill 249 171 552 249 173 552 minecraft:purple_concrete
fill 250 171 525 250 177 525 minecraft:basalt
fill 250 171 541 250 178 541 minecraft:basalt
fill 250 171 547 251 172 547 minecraft:basalt
fill 250 171 552 254 178 552 minecraft:black_concrete
fill 251 171 524 252 178 524 minecraft:basalt
fill 251 171 542 252 178 542 minecraft:basalt
setblock 252 171 517 minecraft:basalt
fill 252 171 523 252 177 523 minecraft:basalt
fill 252 171 549 255 171 549 minecraft:basalt
fill 254 171 510 254 173 510 minecraft:black_concrete
setblock 254 171 513 minecraft:light[level=12]
fill 254 171 517 256 171 517 minecraft:basalt
fill 254 171 523 256 177 523 minecraft:basalt
setblock 254 171 529 minecraft:light[level=12]
setblock 254 171 537 minecraft:light[level=12]
fill 254 171 543 258 171 543 minecraft:basalt
fill 255 171 510 255 173 510 minecraft:purple_concrete
fill 255 171 522 255 177 522 minecraft:basalt
setblock 257 171 517 minecraft:magma_block
setblock 257 171 523 minecraft:magma_block
fill 257 171 549 259 171 549 minecraft:basalt
fill 258 171 517 260 171 517 minecraft:basalt
fill 258 171 523 258 178 523 minecraft:basalt
fill 258 171 552 264 180 552 minecraft:black_concrete
fill 260 171 518 262 171 518 minecraft:basalt
fill 260 171 524 261 178 524 minecraft:basalt
fill 260 171 542 261 178 542 minecraft:basalt
fill 260 171 548 262 171 548 minecraft:basalt
setblock 260 171 549 minecraft:magma_block
fill 261 171 523 261 177 523 minecraft:basalt
setblock 262 171 513 minecraft:light[level=12]
fill 262 171 525 262 178 525 minecraft:basalt
setblock 262 171 529 minecraft:light[level=12]
setblock 262 171 537 minecraft:light[level=12]
fill 262 171 541 262 178 541 minecraft:basalt
setblock 263 171 518 minecraft:magma_block
fill 263 171 519 264 171 520 minecraft:basalt
fill 263 171 526 263 178 526 minecraft:basalt
fill 263 171 540 264 177 540 minecraft:basalt
setblock 263 171 548 minecraft:magma_block
fill 264 171 527 264 178 527 minecraft:basalt
fill 264 171 539 264 178 539 minecraft:basalt
setblock 265 171 520 minecraft:basalt
fill 265 171 528 265 177 529 minecraft:basalt
fill 265 171 537 265 171 538 minecraft:basalt
fill 265 171 552 265 173 552 minecraft:purple_concrete
setblock 266 171 520 minecraft:magma_block
fill 266 171 522 268 171 522 minecraft:basalt
fill 266 171 531 266 178 531 minecraft:basalt
setblock 266 171 532 minecraft:magma_block
fill 266 171 533 266 178 534 minecraft:basalt
setblock 266 171 535 minecraft:magma_block
fill 266 171 544 268 171 544 minecraft:basalt
setblock 266 171 546 minecraft:basalt
fill 266 171 552 268 218 552 minecraft:black_concrete
fill 267 171 533 267 177 533 minecraft:basalt
fill 267 171 543 268 172 543 minecraft:basalt
fill 269 171 524 269 171 526 minecraft:basalt
fill 269 171 540 269 171 542 minecraft:basalt
setblock 269 171 543 minecraft:magma_block
fill 270 171 510 270 307 510 minecraft:black_concrete
setblock 270 171 513 minecraft:light[level=12]
setblock 270 171 521 minecraft:light[level=12]
fill 270 171 525 270 171 526 minecraft:basalt
fill 270 171 540 270 171 541 minecraft:basalt
setblock 270 171 545 minecraft:light[level=12]
fill 271 171 510 271 173 510 minecraft:purple_concrete
setblock 271 171 527 minecraft:basalt
fill 271 171 530 271 172 531 minecraft:basalt
fill 271 171 533 271 172 534 minecraft:basalt
fill 271 171 536 271 172 537 minecraft:basalt
fill 271 171 552 271 172 552 minecraft:black_concrete
fill 272 171 510 272 178 510 minecraft:black_concrete
setblock 272 171 529 minecraft:basalt
setblock 272 171 530 minecraft:magma_block
fill 272 171 531 272 171 532 minecraft:basalt
setblock 272 171 533 minecraft:magma_block
fill 272 171 534 272 171 535 minecraft:basalt
setblock 272 171 536 minecraft:magma_block
setblock 272 171 537 minecraft:basalt
fill 272 171 540 273 172 540 minecraft:bone_block
setblock 272 171 552 minecraft:white_concrete
fill 273 171 522 273 172 523 minecraft:bone_block
setblock 273 171 541 minecraft:bone_block
fill 273 171 552 277 174 552 minecraft:black_concrete
setblock 274 171 522 minecraft:bone_block
setblock 277 171 512 minecraft:amethyst_block
fill 277 171 519 277 176 519 minecraft:black_concrete
fill 277 171 520 277 173 520 minecraft:purple_concrete
fill 277 171 521 277 173 522 minecraft:black_concrete
fill 277 171 536 277 173 536 minecraft:purple_concrete
fill 277 171 546 277 210 546 minecraft:black_concrete
setblock 235 172 517 minecraft:crying_obsidian
fill 237 172 510 237 204 510 minecraft:black_concrete
setblock 241 172 530 minecraft:magma_block
setblock 241 172 533 minecraft:magma_block
setblock 241 172 536 minecraft:magma_block
fill 242 172 526 243 172 526 minecraft:basalt
setblock 242 172 528 minecraft:basalt
setblock 242 172 538 minecraft:basalt
setblock 242 172 540 minecraft:basalt
setblock 243 172 525 minecraft:basalt
setblock 243 172 541 minecraft:basalt
setblock 244 172 523 minecraft:magma_block
fill 245 172 522 246 172 522 minecraft:basalt
setblock 246 172 521 minecraft:basalt
fill 246 172 537 246 177 537 minecraft:basalt
setblock 246 172 545 minecraft:basalt
fill 247 172 530 247 178 530 minecraft:basalt
setblock 247 172 531 minecraft:magma_block
fill 247 172 535 247 177 536 minecraft:basalt
setblock 247 172 537 minecraft:magma_block
fill 248 172 520 249 172 520 minecraft:basalt
fill 248 172 528 248 178 528 minecraft:basalt
fill 248 172 538 248 178 538 minecraft:basalt
fill 249 172 519 251 172 519 minecraft:basalt
fill 249 172 527 249 178 527 minecraft:basalt
fill 249 172 539 249 178 539 minecraft:basalt
setblock 249 172 547 minecraft:basalt
fill 250 172 526 250 178 526 minecraft:basalt
fill 250 172 540 250 177 540 minecraft:basalt
fill 251 172 525 251 178 525 minecraft:basalt
fill 251 172 541 251 178 541 minecraft:basalt
fill 252 172 518 254 172 518 minecraft:basalt
fill 252 172 548 254 172 548 minecraft:basalt
fill 253 172 524 254 177 524 minecraft:basalt
fill 253 172 542 254 177 542 minecraft:basalt
fill 254 172 543 255 178 543 minecraft:basalt
fill 256 172 518 258 172 518 minecraft:basalt
setblock 256 172 543 minecraft:magma_block
fill 256 172 548 258 172 548 minecraft:basalt
fill 257 172 523 257 178 523 minecraft:basalt
fill 257 172 543 258 178 543 minecraft:basalt
fill 258 172 524 258 178 524 minecraft:basalt
fill 258 172 542 258 178 542 minecraft:basalt
setblock 259 172 518 minecraft:magma_block
setblock 259 172 524 minecraft:magma_block
setblock 259 172 542 minecraft:magma_block
setblock 259 172 548 minecraft:magma_block
setblock 260 172 518 minecraft:basalt
setblock 260 172 548 minecraft:basalt
fill 261 172 525 261 178 525 minecraft:basalt
fill 261 172 541 261 178 541 minecraft:basalt
setblock 262 172 526 minecraft:magma_block
fill 262 172 540 262 178 540 minecraft:basalt
fill 262 172 546 264 172 546 minecraft:basalt
setblock 262 172 547 minecraft:magma_block
fill 263 172 519 263 172 520 minecraft:basalt
fill 263 172 527 263 178 527 minecraft:basalt
fill 263 172 539 263 178 539 minecraft:basalt
setblock 263 172 547 minecraft:basalt
setblock 264 172 520 minecraft:basalt
fill 264 172 528 264 178 528 minecraft:basalt
fill 264 172 538 265 177 538 minecraft:basalt
fill 265 172 521 266 172 521 minecraft:basalt
fill 265 172 530 265 178 530 minecraft:basalt
setblock 265 172 531 minecraft:magma_block
fill 265 172 535 265 177 536 minecraft:basalt
setblock 265 172 537 minecraft:magma_block
fill 265 172 545 266 172 545 minecraft:basalt
fill 266 172 522 267 172 522 minecraft:basalt
fill 266 172 532 266 178 532 minecraft:basalt
fill 266 172 535 266 178 535 minecraft:basalt
fill 266 172 544 267 172 544 minecraft:basalt
fill 267 172 523 267 172 524 minecraft:basalt
fill 267 172 542 267 173 542 minecraft:basalt
setblock 268 172 523 minecraft:basalt
setblock 268 172 524 minecraft:magma_block
setblock 268 172 542 minecraft:magma_block
fill 269 172 525 269 172 526 minecraft:basalt
fill 269 172 540 269 172 541 minecraft:basalt
setblock 270 172 526 minecraft:basalt
setblock 270 172 540 minecraft:basalt
setblock 271 172 529 minecraft:magma_block
setblock 271 172 532 minecraft:magma_block
setblock 271 172 535 minecraft:magma_block
fill 271 172 538 273 172 538 minecraft:bone_block
fill 272 172 524 273 173 524 minecraft:bone_block
fill 272 172 539 273 172 539 minecraft:bone_block
fill 272 172 552 272 307 552 minecraft:black_concrete
fill 277 172 512 277 240 512 minecraft:black_concrete
fill 235 173 511 235 179 513 minecraft:black_concrete
setblock 235 173 514 minecraft:crying_obsidian
fill 235 173 517 235 307 517 minecraft:black_concrete
setblock 235 173 530 minecraft:crying_obsidian
setblock 243 173 526 minecraft:basalt
setblock 243 173 528 minecraft:magma_block
fill 243 173 529 243 174 529 minecraft:basalt
setblock 243 173 540 minecraft:magma_block
fill 244 173 540 244 174 540 minecraft:basalt
fill 247 173 531 247 177 534 minecraft:basalt
fill 247 173 537 248 178 537 minecraft:basalt
fill 248 173 529 248 178 530 minecraft:basalt
fill 248 173 536 248 178 536 minecraft:basalt
setblock 249 173 520 minecraft:magma_block
fill 249 173 528 249 178 528 minecraft:basalt
setblock 249 173 538 minecraft:magma_block
setblock 249 173 546 minecraft:basalt
fill 250 173 527 250 178 527 minecraft:basalt
fill 250 173 539 250 178 539 minecraft:basalt
fill 251 173 526 251 178 526 minecraft:basalt
fill 251 173 540 251 178 540 minecraft:basalt
setblock 252 173 519 minecraft:magma_block
setblock 252 173 525 minecraft:magma_block
fill 252 173 541 253 178 541 minecraft:basalt
fill 253 173 525 253 178 525 minecraft:basalt
setblock 255 173 519 minecraft:basalt
setblock 255 173 524 minecraft:magma_block
setblock 255 173 542 minecraft:magma_block
fill 255 173 547 257 173 547 minecraft:basalt
fill 256 173 524 257 178 524 minecraft:basalt
fill 256 173 542 256 178 543 minecraft:basalt
fill 257 173 542 257 178 542 minecraft:basalt
setblock 258 173 547 minecraft:magma_block
fill 259 173 524 259 177 525 minecraft:basalt
fill 259 173 541 259 178 542 minecraft:basalt
fill 260 173 525 260 178 525 minecraft:basalt
fill 260 173 541 260 178 541 minecraft:basalt
fill 260 173 546 260 174 546 minecraft:basalt
fill 261 173 526 262 178 526 minecraft:basalt
setblock 261 173 540 minecraft:magma_block
setblock 261 173 546 minecraft:magma_block
fill 262 173 520 263 173 520 minecraft:basalt
fill 262 173 527 262 177 527 minecraft:basalt
fill 262 173 539 262 177 539 minecraft:basalt
fill 262 173 546 263 173 546 minecraft:basalt
fill 263 173 521 263 174 521 minecraft:basalt
fill 263 173 528 263 178 528 minecraft:basalt
setblock 263 173 538 minecraft:basalt
fill 263 173 545 263 174 545 minecraft:basalt
setblock 264 173 521 minecraft:magma_block
fill 264 173 529 264 178 529 minecraft:basalt
setblock 264 173 530 minecraft:magma_block
setblock 264 173 536 minecraft:magma_block
fill 264 173 537 265 178 537 minecraft:basalt
setblock 264 173 545 minecraft:magma_block
fill 265 173 531 265 177 534 minecraft:basalt
setblock 267 173 524 minecraft:basalt
setblock 269 173 526 minecraft:basalt
setblock 269 173 540 minecraft:basalt
setblock 270 173 531 minecraft:magma_block
fill 270 173 532 270 173 533 minecraft:basalt
setblock 270 173 534 minecraft:magma_block
setblock 270 173 537 minecraft:magma_block
setblock 270 173 538 minecraft:bone_block
fill 271 173 533 271 174 537 minecraft:bone_block
setblock 271 173 552 minecraft:amethyst_block
fill 272 173 525 272 174 526 minecraft:bone_block
fill 272 173 534 272 173 538 minecraft:bone_block
setblock 273 173 525 minecraft:bone_block
setblock 273 173 538 minecraft:bone_block
setblock 277 173 537 minecraft:white_concrete
fill 235 174 514 235 307 514 minecraft:black_concrete
fill 235 174 518 235 179 518 minecraft:black_concrete
fill 235 174 530 235 213 530 minecraft:black_concrete
fill 235 174 534 235 179 534 minecraft:black_concrete
fill 235 174 550 235 179 550 minecraft:black_concrete
fill 239 174 510 239 179 510 minecraft:black_concrete
setblock 243 174 528 minecraft:basalt
setblock 243 174 530 minecraft:basalt
setblock 243 174 536 minecraft:basalt
fill 245 174 540 245 175 540 minecraft:basalt
setblock 245 174 541 minecraft:magma_block
setblock 248 174 522 minecraft:magma_block
setblock 248 174 531 minecraft:magma_block
fill 248 174 532 248 178 533 minecraft:basalt
setblock 248 174 534 minecraft:magma_block
fill 248 174 535 248 178 535 minecraft:basalt
fill 249 174 522 249 175 522 minecraft:basalt
fill 249 174 529 249 178 529 minecraft:basalt
fill 249 174 537 249 178 538 minecraft:basalt
fill 249 174 552 249 179 552 minecraft:black_concrete
fill 252 174 525 252 178 526 minecraft:basalt
fill 252 174 540 252 178 540 minecraft:basalt
setblock 254 174 510 minecraft:crying_obsidian
setblock 254 174 520 minecraft:magma_block
fill 254 174 525 256 178 525 minecraft:basalt
setblock 254 174 541 minecraft:magma_block
fill 254 174 546 256 174 546 minecraft:basalt
fill 255 174 510 255 179 510 minecraft:black_concrete
fill 255 174 524 255 178 524 minecraft:basalt
fill 255 174 541 255 178 542 minecraft:basalt
fill 256 174 541 258 177 541 minecraft:basalt
setblock 257 174 525 minecraft:magma_block
setblock 257 174 546 minecraft:magma_block
fill 258 174 525 258 178 525 minecraft:basalt
fill 260 174 526 260 178 526 minecraft:basalt
fill 260 174 540 261 178 540 minecraft:basalt
setblock 261 174 546 minecraft:basalt
setblock 263 174 529 minecraft:magma_block
fill 263 174 537 263 178 537 minecraft:basalt
setblock 263 174 538 minecraft:magma_block
fill 264 174 530 264 178 536 minecraft:basalt
fill 265 174 552 265 179 552 minecraft:black_concrete
setblock 268 174 539 minecraft:basalt
setblock 269 174 530 minecraft:magma_block
fill 269 174 531 269 174 532 minecraft:basalt
setblock 269 174 533 minecraft:magma_block
fill 269 174 534 269 174 535 minecraft:basalt
setblock 269 174 536 minecraft:magma_block
fill 270 174 531 270 174 537 minecraft:bone_block
fill 271 174 510 271 179 510 minecraft:black_concrete
fill 271 174 527 272 175 527 minecraft:bone_block
fill 271 174 532 272 178 532 minecraft:bone_block
fill 271 174 552 271 255 552 minecraft:black_concrete
fill 272 174 528 272 175 528 minecraft:bone_block
fill 272 174 533 272 174 537 minecraft:bone_block
fill 277 174 520 277 179 520 minecraft:black_concrete
setblock 277 174 521 minecraft:amethyst_block
fill 277 174 522 277 208 522 minecraft:black_concrete
fill 277 174 536 277 175 537 minecraft:black_concrete
setblock 235 175 541 minecraft:amethyst_block
fill 235 175 542 235 196 544 minecraft:black_concrete
fill 243 175 532 244 175 532 minecraft:basalt
setblock 243 175 534 minecraft:basalt
setblock 244 175 528 minecraft:magma_block
fill 244 175 529 244 175 530 minecraft:basalt
setblock 244 175 531 minecraft:magma_block
setblock 244 175 536 minecraft:basalt
setblock 244 175 537 minecraft:magma_block
setblock 244 175 538 minecraft:basalt
setblock 247 175 524 minecraft:magma_block
setblock 247 175 542 minecraft:magma_block
fill 248 175 531 249 175 531 minecraft:basalt
fill 248 175 534 248 178 534 minecraft:basalt
fill 249 175 530 249 178 530 minecraft:basalt
fill 249 175 535 249 178 536 minecraft:basalt
setblock 250 175 510 minecraft:white_concrete
fill 250 175 528 250 177 528 minecraft:basalt
setblock 250 175 529 minecraft:magma_block
fill 250 175 537 250 177 537 minecraft:basalt
setblock 250 175 538 minecraft:magma_block
setblock 250 175 544 minecraft:magma_block
setblock 251 175 521 minecraft:basalt
fill 251 175 527 252 175 527 minecraft:basalt
fill 251 175 539 252 175 539 minecraft:basalt
setblock 251 175 545 minecraft:basalt
setblock 253 175 521 minecraft:basalt
fill 253 175 526 254 178 526 minecraft:basalt
setblock 253 175 540 minecraft:magma_block
setblock 253 175 545 minecraft:basalt
fill 254 175 510 254 181 510 minecraft:black_concrete
fill 254 175 540 254 178 541 minecraft:basalt
fill 255 175 546 257 175 546 minecraft:basalt
fill 256 175 520 257 175 520 minecraft:basalt
setblock 257 175 510 minecraft:crying_obsidian
fill 257 175 525 257 178 525 minecraft:basalt
fill 258 175 510 258 180 510 minecraft:black_concrete
fill 258 175 526 258 178 526 minecraft:basalt
fill 258 175 540 259 175 540 minecraft:basalt
fill 258 175 545 259 175 545 minecraft:basalt
setblock 259 175 526 minecraft:magma_block
fill 260 175 527 261 178 527 minecraft:basalt
fill 260 175 539 261 178 539 minecraft:basalt
setblock 262 175 522 minecraft:magma_block
setblock 262 175 528 minecraft:magma_block
fill 262 175 529 263 178 529 minecraft:basalt
setblock 262 175 537 minecraft:magma_block
fill 262 175 538 263 178 538 minecraft:basalt
setblock 262 175 544 minecraft:basalt
fill 263 175 530 263 178 531 minecraft:basalt
fill 263 175 535 263 178 536 minecraft:basalt
setblock 265 175 524 minecraft:magma_block
setblock 265 175 542 minecraft:magma_block
setblock 268 175 528 minecraft:basalt
setblock 268 175 529 minecraft:magma_block
fill 268 175 530 268 175 534 minecraft:basalt
setblock 268 175 535 minecraft:magma_block
fill 268 175 536 268 175 537 minecraft:basalt
setblock 268 175 538 minecraft:magma_block
setblock 269 175 510 minecraft:white_concrete
fill 269 175 531 272 179 531 minecraft:bone_block
fill 269 175 532 269 175 534 minecraft:basalt
fill 269 175 535 271 175 536 minecraft:bone_block
fill 270 175 530 271 181 530 minecraft:bone_block
fill 270 175 532 270 177 534 minecraft:bone_block
fill 271 175 528 271 175 529 minecraft:bone_block
fill 271 175 533 272 176 534 minecraft:bone_block
setblock 272 175 529 minecraft:bone_block
setblock 272 175 535 minecraft:bone_block
fill 273 175 552 273 293 552 minecraft:black_concrete
setblock 274 175 552 minecraft:crying_obsidian
fill 275 175 552 277 198 552 minecraft:black_concrete
fill 277 175 521 277 305 521 minecraft:black_concrete
fill 277 175 527 277 266 527 minecraft:black_concrete
setblock 277 175 528 minecraft:crying_obsidian
fill 277 175 529 277 193 530 minecraft:black_concrete
fill 235 176 531 235 195 531 minecraft:black_concrete
setblock 235 176 532 minecraft:crying_obsidian
fill 235 176 541 235 193 541 minecraft:black_concrete
setblock 238 176 552 minecraft:crying_obsidian
fill 243 176 510 248 176 510 minecraft:black_concrete
fill 244 176 531 244 176 533 minecraft:basalt
setblock 246 176 527 minecraft:basalt
setblock 247 176 541 minecraft:basalt
fill 248 176 531 248 178 531 minecraft:basalt
setblock 249 176 510 minecraft:white_concrete
setblock 249 176 531 minecraft:magma_block
fill 249 176 532 249 178 533 minecraft:basalt
setblock 249 176 534 minecraft:magma_block
setblock 249 176 542 minecraft:basalt
fill 250 176 510 250 231 510 minecraft:black_concrete
fill 250 176 529 250 178 530 minecraft:basalt
fill 250 176 536 250 178 536 minecraft:basalt
fill 250 176 538 251 178 538 minecraft:basalt
fill 251 176 527 251 178 528 minecraft:basalt
fill 251 176 539 251 178 539 minecraft:basalt
setblock 252 176 527 minecraft:magma_block
setblock 252 176 539 minecraft:magma_block
setblock 252 176 544 minecraft:basalt
fill 253 176 527 253 177 527 minecraft:basalt
fill 253 176 539 253 177 540 minecraft:basalt
setblock 255 176 526 minecraft:magma_block
fill 255 176 540 257 178 540 minecraft:basalt
fill 256 176 526 257 177 526 minecraft:basalt
fill 257 176 510 257 241 510 minecraft:black_concrete
setblock 258 176 540 minecraft:magma_block
setblock 258 176 545 minecraft:basalt
fill 259 176 526 259 178 527 minecraft:basalt
fill 259 176 539 259 177 540 minecraft:basalt
fill 261 176 528 262 178 528 minecraft:basalt
fill 261 176 538 261 178 538 minecraft:basalt
setblock 261 176 544 minecraft:basalt
fill 262 176 530 262 177 530 minecraft:basalt
fill 262 176 536 262 177 537 minecraft:basalt
fill 263 176 532 263 178 534 minecraft:basalt
fill 263 176 542 264 176 542 minecraft:basalt
setblock 264 176 524 minecraft:basalt
setblock 264 176 541 minecraft:magma_block
setblock 266 176 510 minecraft:crying_obsidian
setblock 267 176 528 minecraft:magma_block
setblock 267 176 529 minecraft:basalt
setblock 267 176 537 minecraft:magma_block
setblock 267 176 538 minecraft:basalt
fill 268 176 531 268 176 535 minecraft:basalt
fill 269 176 510 269 199 510 minecraft:black_concrete
fill 269 176 530 269 180 530 minecraft:bone_block
fill 269 176 532 269 176 535 minecraft:bone_block
fill 270 176 529 271 182 529 minecraft:bone_block
fill 270 176 535 271 176 535 minecraft:bone_block
fill 272 176 530 272 180 530 minecraft:bone_block
fill 274 176 552 274 186 552 minecraft:black_concrete
fill 277 176 528 277 275 528 minecraft:black_concrete
setblock 277 176 536 minecraft:amethyst_block
fill 277 176 537 277 223 537 minecraft:black_concrete
setblock 277 176 541 minecraft:white_concrete
fill 235 177 532 235 189 532 minecraft:black_concrete
setblock 235 177 551 minecraft:crying_obsidian
fill 238 177 552 238 228 552 minecraft:black_concrete
fill 240 177 510 240 178 510 minecraft:white_concrete
fill 241 177 510 241 231 510 minecraft:black_concrete
fill 243 177 510 246 192 510 minecraft:black_concrete
setblock 245 177 531 minecraft:magma_block
fill 245 177 532 245 177 533 minecraft:basalt
setblock 245 177 534 minecraft:magma_block
setblock 245 177 535 minecraft:basalt
setblock 247 177 510 minecraft:white_concrete
setblock 247 177 527 minecraft:basalt
fill 248 177 510 249 186 510 minecraft:black_concrete
fill 249 177 531 250 177 531 minecraft:basalt
fill 249 177 534 250 177 534 minecraft:basalt
fill 250 177 532 250 177 533 minecraft:basalt
fill 250 177 535 250 178 535 minecraft:basalt
setblock 250 177 542 minecraft:basalt
setblock 251 177 510 minecraft:white_concrete
setblock 251 177 523 minecraft:magma_block
setblock 251 177 529 minecraft:magma_block
fill 251 177 537 251 178 537 minecraft:basalt
setblock 251 177 543 minecraft:basalt
fill 252 177 510 252 229 510 minecraft:black_concrete
fill 252 177 527 252 178 528 minecraft:basalt
fill 252 177 538 252 178 539 minecraft:basalt
setblock 253 177 523 minecraft:basalt
setblock 254 177 522 minecraft:magma_block
fill 254 177 527 256 177 527 minecraft:basalt
fill 254 177 539 256 177 539 minecraft:basalt
fill 254 177 544 255 177 544 minecraft:basalt
fill 255 177 526 255 178 526 minecraft:basalt
fill 256 177 522 258 177 522 minecraft:basalt
fill 257 177 527 257 178 527 minecraft:magma_block
fill 257 177 539 257 178 539 minecraft:magma_block
fill 257 177 544 258 177 544 minecraft:basalt
fill 258 177 527 258 178 527 minecraft:basalt
fill 258 177 539 258 178 540 minecraft:basalt
setblock 259 177 523 minecraft:basalt
setblock 260 177 523 minecraft:magma_block
fill 260 177 528 260 178 528 minecraft:basalt
setblock 260 177 538 minecraft:magma_block
fill 261 177 529 261 178 529 minecraft:basalt
fill 261 177 537 261 178 537 minecraft:basalt
fill 262 177 531 262 177 535 minecraft:basalt
setblock 263 177 525 minecraft:magma_block
setblock 264 177 526 minecraft:basalt
fill 266 177 510 266 307 510 minecraft:black_concrete
fill 266 177 528 266 177 529 minecraft:basalt
setblock 266 177 530 minecraft:magma_block
setblock 266 177 536 minecraft:magma_block
fill 266 177 537 266 177 538 minecraft:basalt
fill 267 177 531 267 177 532 minecraft:basalt
fill 267 177 534 267 177 535 minecraft:basalt
fill 269 177 529 269 182 529 minecraft:bone_block
fill 269 177 532 269 177 534 minecraft:bone_block
fill 270 177 528 271 182 528 minecraft:bone_block
fill 271 177 533 271 177 534 minecraft:bone_block
fill 272 177 529 272 181 529 minecraft:bone_block
setblock 272 177 533 minecraft:bone_block
setblock 277 177 519 minecraft:crying_obsidian
fill 277 177 536 277 179 536 minecraft:black_concrete
fill 277 177 541 277 190 541 minecraft:black_concrete
fill 235 178 551 235 186 551 minecraft:black_concrete
fill 247 178 510 247 281 510 minecraft:black_concrete
setblock 247 178 528 minecraft:basalt
setblock 247 178 529 minecraft:magma_block
setblock 247 178 531 minecraft:basalt
setblock 247 178 532 minecraft:magma_block
fill 247 178 533 247 178 534 minecraft:basalt
setblock 247 178 535 minecraft:magma_block
setblock 247 178 536 minecraft:basalt
setblock 247 178 538 minecraft:magma_block
setblock 249 178 531 minecraft:basalt
setblock 249 178 534 minecraft:basalt
setblock 250 178 525 minecraft:magma_block
setblock 250 178 528 minecraft:magma_block
fill 250 178 531 250 178 534 minecraft:magma_block
setblock 250 178 537 minecraft:magma_block
setblock 250 178 540 minecraft:magma_block
fill 251 178 510 251 201 510 minecraft:black_concrete
setblock 251 178 529 minecraft:basalt
fill 251 178 530 251 178 532 minecraft:magma_block
fill 251 178 534 251 178 536 minecraft:magma_block
setblock 252 178 529 minecraft:magma_block
setblock 252 178 537 minecraft:magma_block
setblock 253 178 524 minecraft:magma_block
schedule function dropper:buildpart/125_2 1t
