fill 182 220 351 183 220 351 minecraft:blue_terracotta
setblock 182 220 355 minecraft:dark_prismarine
fill 182 220 356 182 222 357 minecraft:blue_terracotta
setblock 182 220 362 minecraft:purple_concrete
setblock 183 220 329 minecraft:blue_terracotta
setblock 183 220 339 minecraft:blue_terracotta
setblock 183 220 350 minecraft:blue_terracotta
setblock 183 220 353 minecraft:blue_terracotta
setblock 183 220 356 minecraft:blue_terracotta
setblock 183 220 360 minecraft:blue_terracotta
fill 141 221 322 141 222 323 minecraft:blue_concrete
setblock 141 221 324 minecraft:blue_terracotta
fill 141 221 325 141 221 339 minecraft:blue_concrete
fill 141 221 341 141 221 347 minecraft:blue_concrete
fill 141 221 349 141 221 359 minecraft:blue_concrete
fill 141 221 361 141 256 363 minecraft:blue_concrete
fill 142 221 322 147 222 322 minecraft:blue_concrete
setblock 142 221 329 minecraft:dark_prismarine
fill 142 221 330 142 223 330 minecraft:blue_terracotta
fill 142 221 332 142 222 332 minecraft:blue_terracotta
setblock 142 221 349 minecraft:dark_prismarine
fill 142 221 350 142 224 350 minecraft:blue_terracotta
setblock 142 221 354 minecraft:dark_prismarine
fill 142 221 355 142 224 355 minecraft:blue_terracotta
setblock 142 221 359 minecraft:dark_prismarine
fill 142 221 360 142 222 362 minecraft:blue_terracotta
fill 142 221 364 144 221 364 minecraft:blue_concrete
setblock 143 221 348 minecraft:dark_prismarine
fill 143 221 349 143 224 349 minecraft:blue_terracotta
setblock 143 221 353 minecraft:dark_prismarine
fill 143 221 354 143 224 354 minecraft:blue_terracotta
setblock 143 221 358 minecraft:dark_prismarine
setblock 143 221 363 minecraft:dark_prismarine
setblock 144 221 325 minecraft:light[level=13]
setblock 144 221 332 minecraft:light[level=12]
setblock 144 221 333 minecraft:light[level=13]
setblock 144 221 339 minecraft:light[level=12]
setblock 144 221 341 minecraft:light[level=13]
setblock 144 221 346 minecraft:light[level=12]
setblock 144 221 349 minecraft:light[level=13]
fill 144 221 350 144 221 351 minecraft:blue_terracotta
setblock 144 221 352 minecraft:dark_prismarine
fill 144 221 353 144 224 353 minecraft:blue_terracotta
fill 144 221 355 144 221 356 minecraft:blue_terracotta
setblock 144 221 357 minecraft:light[level=13]
setblock 144 221 360 minecraft:light[level=12]
fill 144 221 363 144 224 363 minecraft:blue_terracotta
setblock 146 221 323 minecraft:purple_concrete
fill 146 221 364 149 221 364 minecraft:blue_concrete
setblock 148 221 322 minecraft:blue_terracotta
setblock 148 221 323 minecraft:dark_prismarine
setblock 148 221 362 minecraft:blue_terracotta
setblock 148 221 363 minecraft:dark_prismarine
fill 149 221 322 155 221 322 minecraft:blue_concrete
fill 149 221 323 150 222 323 minecraft:blue_terracotta
fill 149 221 324 149 222 324 minecraft:dark_prismarine
fill 149 221 326 149 222 326 minecraft:dark_prismarine
fill 149 221 328 149 222 328 minecraft:dark_prismarine
setblock 149 221 362 minecraft:dark_prismarine
fill 149 221 363 149 224 363 minecraft:blue_terracotta
fill 150 221 325 150 222 325 minecraft:dark_prismarine
fill 150 221 327 150 222 327 minecraft:dark_prismarine
fill 150 221 362 150 224 362 minecraft:blue_terracotta
setblock 150 221 364 minecraft:blue_terracotta
fill 151 221 324 151 222 324 minecraft:dark_prismarine
fill 151 221 326 151 222 326 minecraft:dark_prismarine
fill 151 221 328 151 222 328 minecraft:dark_prismarine
setblock 151 221 332 minecraft:light[level=12]
setblock 151 221 339 minecraft:light[level=12]
setblock 151 221 346 minecraft:light[level=12]
setblock 151 221 353 minecraft:light[level=12]
setblock 151 221 360 minecraft:light[level=12]
fill 151 221 364 170 221 364 minecraft:blue_concrete
setblock 152 221 323 minecraft:blue_terracotta
fill 152 221 325 152 222 325 minecraft:dark_prismarine
fill 152 221 327 152 222 327 minecraft:dark_prismarine
setblock 152 221 333 minecraft:light[level=13]
setblock 152 221 341 minecraft:light[level=13]
setblock 152 221 349 minecraft:light[level=13]
setblock 152 221 357 minecraft:light[level=13]
fill 153 221 323 153 221 324 minecraft:dark_prismarine
fill 153 221 326 153 222 326 minecraft:dark_prismarine
fill 153 221 328 153 222 328 minecraft:dark_prismarine
setblock 153 221 363 minecraft:dark_prismarine
setblock 154 221 323 minecraft:blue_terracotta
fill 154 221 325 154 222 325 minecraft:dark_prismarine
fill 154 221 327 154 222 327 minecraft:dark_prismarine
setblock 154 221 363 minecraft:blue_terracotta
fill 155 221 323 155 222 324 minecraft:dark_prismarine
fill 155 221 326 155 222 326 minecraft:dark_prismarine
fill 155 221 328 155 222 328 minecraft:dark_prismarine
fill 157 221 322 163 221 322 minecraft:blue_concrete
setblock 158 221 325 minecraft:light[level=12]
setblock 158 221 332 minecraft:light[level=12]
setblock 158 221 339 minecraft:light[level=12]
setblock 158 221 346 minecraft:light[level=12]
setblock 158 221 353 minecraft:light[level=12]
setblock 158 221 360 minecraft:light[level=12]
setblock 160 221 325 minecraft:light[level=13]
setblock 160 221 333 minecraft:light[level=13]
setblock 160 221 349 minecraft:light[level=13]
setblock 160 221 357 minecraft:light[level=13]
fill 165 221 322 169 221 322 minecraft:blue_concrete
fill 165 221 323 165 223 323 minecraft:blue_terracotta
setblock 165 221 325 minecraft:light[level=12]
setblock 165 221 332 minecraft:light[level=12]
setblock 165 221 339 minecraft:light[level=12]
setblock 165 221 346 minecraft:light[level=12]
setblock 165 221 353 minecraft:light[level=12]
setblock 165 221 360 minecraft:light[level=12]
setblock 166 221 324 minecraft:blue_terracotta
setblock 167 221 324 minecraft:dark_prismarine
setblock 168 221 323 minecraft:dark_prismarine
fill 168 221 324 168 224 324 minecraft:blue_terracotta
setblock 168 221 333 minecraft:light[level=13]
setblock 168 221 341 minecraft:light[level=13]
setblock 168 221 349 minecraft:light[level=13]
setblock 168 221 357 minecraft:light[level=13]
fill 169 221 323 169 224 323 minecraft:blue_terracotta
fill 169 221 363 169 224 363 minecraft:blue_terracotta
setblock 170 221 322 minecraft:blue_terracotta
setblock 170 221 326 minecraft:dark_prismarine
fill 171 221 322 172 221 322 minecraft:blue_concrete
setblock 171 221 325 minecraft:dark_prismarine
fill 171 221 326 171 223 326 minecraft:blue_terracotta
setblock 172 221 324 minecraft:dark_prismarine
fill 172 221 325 172 224 325 minecraft:blue_terracotta
setblock 172 221 332 minecraft:light[level=12]
setblock 172 221 339 minecraft:light[level=12]
setblock 172 221 346 minecraft:light[level=12]
setblock 172 221 353 minecraft:light[level=12]
setblock 172 221 360 minecraft:light[level=12]
fill 172 221 364 174 221 364 minecraft:blue_concrete
setblock 173 221 322 minecraft:cyan_concrete
setblock 173 221 323 minecraft:dark_prismarine
fill 173 221 324 173 224 324 minecraft:blue_terracotta
setblock 173 221 363 minecraft:dark_prismarine
fill 174 221 322 183 221 322 minecraft:blue_concrete
fill 174 221 323 174 224 323 minecraft:blue_terracotta
fill 174 221 363 174 224 363 minecraft:blue_terracotta
setblock 175 221 326 minecraft:dark_prismarine
setblock 175 221 364 minecraft:blue_terracotta
setblock 176 221 325 minecraft:dark_prismarine
setblock 176 221 333 minecraft:light[level=13]
setblock 176 221 341 minecraft:light[level=13]
setblock 176 221 349 minecraft:light[level=13]
setblock 176 221 357 minecraft:light[level=13]
setblock 177 221 324 minecraft:dark_prismarine
setblock 177 221 325 minecraft:blue_terracotta
fill 177 221 364 180 222 364 minecraft:blue_concrete
setblock 178 221 323 minecraft:dark_prismarine
fill 178 221 324 178 222 324 minecraft:blue_terracotta
setblock 178 221 363 minecraft:dark_prismarine
fill 179 221 323 179 223 323 minecraft:blue_terracotta
setblock 179 221 325 minecraft:light[level=12]
setblock 179 221 332 minecraft:light[level=12]
setblock 179 221 339 minecraft:light[level=12]
setblock 179 221 346 minecraft:light[level=12]
setblock 179 221 353 minecraft:light[level=12]
setblock 179 221 360 minecraft:light[level=12]
setblock 181 221 326 minecraft:blue_terracotta
setblock 181 221 330 minecraft:dark_prismarine
fill 181 221 331 181 222 331 minecraft:blue_terracotta
setblock 182 221 323 minecraft:blue_terracotta
setblock 182 221 324 minecraft:dark_prismarine
fill 182 221 325 182 223 325 minecraft:blue_terracotta
setblock 182 221 329 minecraft:dark_prismarine
fill 182 221 330 183 221 330 minecraft:blue_terracotta
setblock 182 221 334 minecraft:dark_prismarine
setblock 182 221 349 minecraft:dark_prismarine
fill 182 221 350 182 221 353 minecraft:blue_terracotta
setblock 182 221 354 minecraft:dark_prismarine
fill 182 221 355 182 224 355 minecraft:blue_terracotta
setblock 182 221 358 minecraft:blue_terracotta
setblock 182 221 359 minecraft:dark_prismarine
fill 182 221 364 183 221 364 minecraft:blue_concrete
fill 183 221 323 183 221 329 minecraft:blue_concrete
fill 183 221 331 183 221 353 minecraft:blue_concrete
setblock 183 221 354 minecraft:blue_terracotta
fill 183 221 355 183 308 356 minecraft:blue_concrete
fill 183 221 358 183 221 363 minecraft:blue_concrete
fill 141 222 324 141 247 324 minecraft:blue_concrete
setblock 141 222 325 minecraft:blue_terracotta
fill 141 222 326 141 224 329 minecraft:blue_concrete
setblock 141 222 330 minecraft:blue_terracotta
fill 141 222 331 141 238 335 minecraft:blue_concrete
setblock 141 222 336 minecraft:blue_terracotta
fill 141 222 337 141 222 340 minecraft:blue_concrete
setblock 141 222 341 minecraft:blue_terracotta
fill 141 222 342 141 222 351 minecraft:blue_concrete
setblock 141 222 352 minecraft:cyan_concrete
fill 141 222 353 141 222 360 minecraft:blue_concrete
setblock 142 222 328 minecraft:dark_prismarine
fill 142 222 329 142 223 329 minecraft:blue_terracotta
setblock 142 222 333 minecraft:dark_prismarine
setblock 142 222 336 minecraft:purple_concrete
setblock 142 222 348 minecraft:dark_prismarine
fill 142 222 349 142 225 349 minecraft:blue_terracotta
setblock 142 222 353 minecraft:dark_prismarine
fill 142 222 354 142 225 354 minecraft:blue_terracotta
setblock 142 222 357 minecraft:blue_terracotta
setblock 142 222 358 minecraft:dark_prismarine
fill 142 222 359 143 224 359 minecraft:blue_terracotta
fill 142 222 364 142 308 364 minecraft:blue_concrete
setblock 143 222 348 minecraft:blue_terracotta
setblock 143 222 352 minecraft:dark_prismarine
fill 143 222 353 143 225 353 minecraft:blue_terracotta
setblock 143 222 357 minecraft:dark_prismarine
fill 143 222 358 143 225 358 minecraft:blue_terracotta
fill 143 222 363 143 222 364 minecraft:blue_terracotta
setblock 144 222 350 minecraft:blue_terracotta
setblock 144 222 351 minecraft:dark_prismarine
fill 144 222 352 145 224 352 minecraft:blue_terracotta
setblock 144 222 355 minecraft:blue_terracotta
setblock 144 222 356 minecraft:dark_prismarine
fill 144 222 357 144 225 357 minecraft:blue_terracotta
fill 144 222 364 148 258 364 minecraft:blue_concrete
fill 145 222 353 145 222 354 minecraft:blue_terracotta
setblock 147 222 323 minecraft:dark_prismarine
setblock 147 222 362 minecraft:blue_terracotta
setblock 147 222 363 minecraft:dark_prismarine
fill 148 222 322 153 222 322 minecraft:blue_concrete
fill 148 222 323 148 223 323 minecraft:blue_terracotta
setblock 148 222 362 minecraft:dark_prismarine
fill 148 222 363 148 225 363 minecraft:blue_terracotta
fill 149 222 362 149 225 362 minecraft:blue_terracotta
setblock 149 222 364 minecraft:blue_terracotta
fill 150 222 364 152 308 364 minecraft:blue_concrete
setblock 152 222 323 minecraft:dark_prismarine
setblock 152 222 363 minecraft:dark_prismarine
setblock 153 222 323 minecraft:blue_terracotta
setblock 153 222 324 minecraft:dark_prismarine
fill 153 222 363 153 222 364 minecraft:blue_terracotta
setblock 154 222 322 minecraft:blue_terracotta
setblock 154 222 323 minecraft:dark_prismarine
fill 154 222 364 156 239 364 minecraft:blue_concrete
fill 155 222 322 159 238 322 minecraft:blue_concrete
setblock 157 222 364 minecraft:blue_terracotta
fill 158 222 364 162 278 364 minecraft:blue_concrete
setblock 159 222 363 minecraft:purple_concrete
fill 160 222 322 161 222 322 minecraft:blue_terracotta
fill 162 222 322 167 222 322 minecraft:blue_concrete
setblock 163 222 364 minecraft:blue_terracotta
fill 164 222 364 167 245 364 minecraft:blue_concrete
setblock 166 222 324 minecraft:dark_prismarine
setblock 167 222 323 minecraft:dark_prismarine
fill 167 222 324 167 225 324 minecraft:blue_terracotta
fill 168 222 322 168 222 323 minecraft:blue_terracotta
fill 168 222 363 168 222 364 minecraft:blue_terracotta
fill 169 222 322 170 249 322 minecraft:blue_concrete
setblock 169 222 326 minecraft:dark_prismarine
fill 169 222 364 170 222 364 minecraft:blue_terracotta
setblock 170 222 325 minecraft:dark_prismarine
fill 170 222 326 170 223 326 minecraft:blue_terracotta
setblock 171 222 322 minecraft:blue_terracotta
setblock 171 222 324 minecraft:dark_prismarine
fill 171 222 325 171 224 325 minecraft:blue_terracotta
fill 171 222 364 172 222 364 minecraft:blue_concrete
fill 172 222 322 172 308 322 minecraft:blue_concrete
setblock 172 222 323 minecraft:dark_prismarine
fill 172 222 324 172 225 324 minecraft:blue_terracotta
setblock 172 222 363 minecraft:dark_prismarine
fill 173 222 322 173 222 323 minecraft:blue_terracotta
fill 173 222 363 173 223 364 minecraft:blue_terracotta
fill 174 222 322 174 247 322 minecraft:blue_concrete
fill 174 222 364 176 308 364 minecraft:blue_concrete
setblock 175 222 322 minecraft:blue_terracotta
setblock 175 222 325 minecraft:dark_prismarine
fill 175 222 326 175 226 326 minecraft:black_concrete
fill 176 222 322 177 308 322 minecraft:blue_concrete
setblock 176 222 324 minecraft:dark_prismarine
setblock 177 222 323 minecraft:dark_prismarine
setblock 177 222 324 minecraft:blue_terracotta
setblock 177 222 363 minecraft:dark_prismarine
fill 178 222 322 178 222 323 minecraft:blue_terracotta
setblock 178 222 363 minecraft:blue_terracotta
fill 179 222 322 182 263 322 minecraft:blue_concrete
setblock 181 222 329 minecraft:dark_prismarine
fill 181 222 330 182 222 330 minecraft:blue_terracotta
setblock 182 222 323 minecraft:dark_prismarine
fill 182 222 324 183 222 324 minecraft:blue_terracotta
setblock 182 222 328 minecraft:dark_prismarine
fill 182 222 329 182 225 329 minecraft:blue_terracotta
setblock 182 222 332 minecraft:blue_terracotta
setblock 182 222 333 minecraft:dark_prismarine
fill 182 222 334 182 225 334 minecraft:blue_terracotta
fill 182 222 350 182 222 352 minecraft:blue_terracotta
setblock 182 222 353 minecraft:dark_prismarine
fill 182 222 354 182 225 354 minecraft:blue_terracotta
setblock 182 222 358 minecraft:dark_prismarine
fill 182 222 359 182 222 362 minecraft:blue_terracotta
setblock 182 222 363 minecraft:dark_prismarine
fill 182 222 364 182 306 364 minecraft:blue_concrete
setblock 183 222 322 minecraft:blue_terracotta
fill 183 222 323 183 262 323 minecraft:blue_concrete
fill 183 222 325 183 222 342 minecraft:blue_concrete
setblock 183 222 343 minecraft:blue_terracotta
fill 183 222 344 183 247 345 minecraft:blue_concrete
fill 183 222 346 183 223 346 minecraft:blue_terracotta
fill 183 222 347 183 249 354 minecraft:blue_concrete
fill 183 222 357 183 283 357 minecraft:blue_concrete
setblock 183 222 358 minecraft:blue_terracotta
fill 183 222 359 183 243 363 minecraft:blue_concrete
setblock 183 222 364 minecraft:blue_terracotta
setblock 141 223 322 minecraft:blue_terracotta
fill 141 223 323 141 263 323 minecraft:blue_concrete
fill 141 223 325 141 308 325 minecraft:blue_concrete
fill 141 223 330 141 308 330 minecraft:blue_concrete
fill 141 223 336 141 308 337 minecraft:blue_concrete
setblock 141 223 338 minecraft:blue_terracotta
fill 141 223 339 141 230 344 minecraft:blue_concrete
setblock 141 223 345 minecraft:blue_terracotta
fill 141 223 346 141 308 346 minecraft:blue_concrete
setblock 141 223 347 minecraft:blue_terracotta
fill 141 223 348 141 260 354 minecraft:blue_concrete
setblock 141 223 355 minecraft:blue_terracotta
fill 141 223 356 141 254 360 minecraft:blue_concrete
fill 142 223 322 144 298 322 minecraft:blue_concrete
setblock 142 223 323 minecraft:purple_concrete
setblock 142 223 332 minecraft:dark_prismarine
fill 142 223 333 142 226 333 minecraft:blue_terracotta
setblock 142 223 342 minecraft:purple_concrete
setblock 142 223 347 minecraft:dark_prismarine
fill 142 223 348 142 226 348 minecraft:blue_terracotta
setblock 142 223 352 minecraft:dark_prismarine
fill 142 223 353 142 226 353 minecraft:blue_terracotta
setblock 142 223 356 minecraft:blue_terracotta
setblock 142 223 357 minecraft:dark_prismarine
fill 142 223 358 142 226 358 minecraft:blue_terracotta
fill 142 223 360 142 223 361 minecraft:blue_terracotta
setblock 142 223 362 minecraft:dark_prismarine
setblock 143 223 351 minecraft:dark_prismarine
fill 143 223 352 143 226 352 minecraft:blue_terracotta
setblock 143 223 356 minecraft:dark_prismarine
fill 143 223 357 143 226 357 minecraft:blue_terracotta
setblock 143 223 360 minecraft:blue_terracotta
fill 143 223 363 143 225 363 minecraft:blue_terracotta
fill 143 223 364 143 279 364 minecraft:blue_concrete
setblock 144 223 350 minecraft:dark_prismarine
fill 144 223 351 144 226 351 minecraft:blue_terracotta
setblock 144 223 355 minecraft:dark_prismarine
fill 144 223 356 144 226 356 minecraft:blue_terracotta
fill 144 223 358 144 224 358 minecraft:blue_terracotta
setblock 145 223 322 minecraft:blue_terracotta
setblock 145 223 353 minecraft:blue_terracotta
setblock 145 223 354 minecraft:dark_prismarine
fill 145 223 355 145 226 355 minecraft:blue_terracotta
fill 146 223 322 149 291 322 minecraft:blue_concrete
setblock 146 223 362 minecraft:blue_terracotta
setblock 146 223 363 minecraft:dark_prismarine
setblock 147 223 362 minecraft:dark_prismarine
fill 147 223 363 147 226 363 minecraft:blue_terracotta
fill 148 223 362 148 226 362 minecraft:blue_terracotta
setblock 149 223 323 minecraft:blue_terracotta
setblock 149 223 324 minecraft:sea_lantern
setblock 149 223 326 minecraft:sea_lantern
setblock 149 223 328 minecraft:sea_lantern
fill 149 223 364 149 308 364 minecraft:blue_concrete
setblock 150 223 322 minecraft:blue_terracotta
setblock 150 223 323 minecraft:sea_lantern
setblock 150 223 325 minecraft:sea_lantern
setblock 150 223 327 minecraft:sea_lantern
fill 151 223 322 154 236 322 minecraft:blue_concrete
fill 151 223 323 151 229 323 minecraft:dark_prismarine
setblock 151 223 324 minecraft:sea_lantern
setblock 151 223 326 minecraft:sea_lantern
setblock 151 223 328 minecraft:sea_lantern
setblock 151 223 363 minecraft:dark_prismarine
setblock 152 223 323 minecraft:sea_lantern
setblock 152 223 325 minecraft:sea_lantern
setblock 152 223 327 minecraft:sea_lantern
fill 152 223 363 153 223 363 minecraft:blue_terracotta
fill 153 223 323 153 224 323 minecraft:purple_concrete
setblock 153 223 324 minecraft:sea_lantern
setblock 153 223 326 minecraft:sea_lantern
setblock 153 223 328 minecraft:sea_lantern
fill 153 223 364 153 308 364 minecraft:blue_concrete
setblock 154 223 323 minecraft:sea_lantern
setblock 154 223 325 minecraft:sea_lantern
setblock 154 223 327 minecraft:sea_lantern
fill 155 223 323 155 229 323 minecraft:dark_prismarine
setblock 155 223 324 minecraft:sea_lantern
setblock 155 223 326 minecraft:sea_lantern
setblock 155 223 328 minecraft:sea_lantern
fill 157 223 364 157 308 364 minecraft:blue_concrete
setblock 159 223 323 minecraft:purple_concrete
fill 160 223 322 163 228 322 minecraft:blue_concrete
fill 163 223 364 163 295 364 minecraft:blue_concrete
setblock 164 223 322 minecraft:blue_terracotta
fill 165 223 322 168 308 322 minecraft:blue_concrete
setblock 165 223 363 minecraft:purple_concrete
setblock 166 223 323 minecraft:dark_prismarine
setblock 166 223 324 minecraft:blue_terracotta
fill 167 223 323 168 225 323 minecraft:blue_terracotta
fill 168 223 363 168 225 363 minecraft:blue_terracotta
fill 168 223 364 169 308 364 minecraft:blue_concrete
setblock 169 223 325 minecraft:dark_prismarine
setblock 170 223 324 minecraft:dark_prismarine
fill 170 223 325 170 224 325 minecraft:blue_terracotta
fill 170 223 364 172 223 364 minecraft:blue_terracotta
fill 171 223 322 171 308 322 minecraft:blue_concrete
setblock 171 223 323 minecraft:dark_prismarine
fill 171 223 324 171 226 324 minecraft:blue_terracotta
setblock 171 223 363 minecraft:dark_prismarine
fill 172 223 323 173 225 323 minecraft:blue_terracotta
fill 172 223 363 172 226 363 minecraft:blue_terracotta
fill 173 223 322 173 295 322 minecraft:blue_concrete
setblock 174 223 325 minecraft:dark_prismarine
fill 175 223 322 175 293 322 minecraft:blue_concrete
setblock 175 223 324 minecraft:dark_prismarine
setblock 176 223 323 minecraft:dark_prismarine
setblock 176 223 324 minecraft:blue_terracotta
setblock 176 223 363 minecraft:dark_prismarine
fill 177 223 323 178 223 323 minecraft:blue_terracotta
setblock 177 223 363 minecraft:blue_terracotta
fill 177 223 364 179 228 364 minecraft:blue_concrete
fill 178 223 322 178 308 322 minecraft:blue_concrete
setblock 180 223 364 minecraft:blue_terracotta
fill 181 223 355 181 225 355 minecraft:blue_terracotta
fill 181 223 364 181 308 364 minecraft:blue_concrete
setblock 182 223 324 minecraft:blue_terracotta
setblock 182 223 327 minecraft:dark_prismarine
fill 182 223 328 182 224 328 minecraft:blue_terracotta
fill 182 223 330 182 224 330 minecraft:blue_terracotta
setblock 182 223 332 minecraft:dark_prismarine
fill 182 223 333 183 223 333 minecraft:blue_terracotta
setblock 182 223 344 minecraft:purple_concrete
fill 182 223 350 182 223 351 minecraft:blue_terracotta
setblock 182 223 352 minecraft:dark_prismarine
fill 182 223 353 182 226 353 minecraft:blue_terracotta
setblock 182 223 356 minecraft:blue_terracotta
setblock 182 223 357 minecraft:dark_prismarine
fill 182 223 358 182 223 361 minecraft:blue_terracotta
setblock 182 223 362 minecraft:dark_prismarine
fill 182 223 363 182 226 363 minecraft:blue_terracotta
fill 183 223 322 183 308 322 minecraft:blue_concrete
fill 183 223 324 183 226 332 minecraft:blue_concrete
fill 183 223 334 183 232 341 minecraft:blue_concrete
setblock 183 223 342 minecraft:blue_terracotta
fill 183 223 343 183 308 343 minecraft:blue_concrete
fill 183 223 358 183 308 358 minecraft:blue_concrete
fill 183 223 364 183 308 364 minecraft:blue_concrete
fill 141 224 322 141 308 322 minecraft:blue_concrete
fill 141 224 338 141 308 338 minecraft:blue_concrete
fill 141 224 345 141 235 345 minecraft:blue_concrete
fill 141 224 347 141 238 347 minecraft:blue_concrete
fill 141 224 355 141 308 355 minecraft:blue_concrete
fill 141 224 364 141 308 364 minecraft:blue_concrete
setblock 142 224 329 minecraft:purple_concrete
setblock 142 224 331 minecraft:dark_prismarine
fill 142 224 332 142 225 332 minecraft:blue_terracotta
fill 142 224 334 142 225 334 minecraft:blue_terracotta
setblock 142 224 351 minecraft:dark_prismarine
fill 142 224 352 142 227 352 minecraft:blue_terracotta
setblock 142 224 356 minecraft:dark_prismarine
fill 142 224 357 142 227 357 minecraft:blue_terracotta
setblock 142 224 360 minecraft:blue_terracotta
setblock 142 224 361 minecraft:dark_prismarine
fill 142 224 362 142 227 362 minecraft:blue_terracotta
setblock 143 224 350 minecraft:dark_prismarine
fill 143 224 351 143 227 351 minecraft:blue_terracotta
setblock 143 224 355 minecraft:dark_prismarine
fill 143 224 356 143 227 356 minecraft:blue_terracotta
setblock 143 224 360 minecraft:dark_prismarine
setblock 144 224 350 minecraft:blue_terracotta
setblock 144 224 354 minecraft:dark_prismarine
fill 144 224 355 144 227 355 minecraft:blue_terracotta
fill 145 224 322 145 298 322 minecraft:blue_concrete
setblock 145 224 353 minecraft:dark_prismarine
fill 145 224 354 145 226 354 minecraft:blue_terracotta
fill 145 224 356 145 225 356 minecraft:blue_terracotta
setblock 145 224 363 minecraft:dark_prismarine
setblock 146 224 362 minecraft:dark_prismarine
fill 146 224 363 146 227 363 minecraft:blue_terracotta
setblock 147 224 323 minecraft:purple_concrete
fill 147 224 362 147 227 362 minecraft:blue_terracotta
fill 149 224 323 149 225 324 minecraft:dark_prismarine
fill 149 224 326 149 225 326 minecraft:dark_prismarine
fill 149 224 328 149 225 328 minecraft:dark_prismarine
fill 150 224 322 150 308 322 minecraft:blue_concrete
fill 150 224 323 150 225 323 minecraft:dark_prismarine
fill 150 224 325 150 225 325 minecraft:dark_prismarine
fill 150 224 327 150 225 327 minecraft:dark_prismarine
setblock 150 224 363 minecraft:dark_prismarine
fill 151 224 324 151 225 324 minecraft:dark_prismarine
fill 151 224 326 151 225 326 minecraft:dark_prismarine
fill 151 224 328 151 225 328 minecraft:dark_prismarine
fill 151 224 363 152 224 363 minecraft:blue_terracotta
fill 152 224 323 152 225 323 minecraft:dark_prismarine
fill 152 224 325 152 225 325 minecraft:dark_prismarine
fill 152 224 327 152 225 327 minecraft:dark_prismarine
fill 153 224 324 153 225 324 minecraft:dark_prismarine
fill 153 224 326 153 225 326 minecraft:dark_prismarine
fill 153 224 328 153 225 328 minecraft:dark_prismarine
fill 154 224 323 154 225 323 minecraft:dark_prismarine
fill 154 224 325 154 225 325 minecraft:dark_prismarine
fill 154 224 327 154 225 327 minecraft:dark_prismarine
fill 155 224 324 155 225 324 minecraft:dark_prismarine
fill 155 224 326 155 225 326 minecraft:dark_prismarine
fill 155 224 328 155 225 328 minecraft:dark_prismarine
fill 164 224 322 164 265 322 minecraft:blue_concrete
setblock 165 224 323 minecraft:dark_prismarine
fill 166 224 323 166 227 323 minecraft:blue_terracotta
fill 167 224 363 167 226 363 minecraft:blue_terracotta
setblock 168 224 325 minecraft:dark_prismarine
setblock 169 224 324 minecraft:dark_prismarine
setblock 169 224 325 minecraft:blue_terracotta
setblock 170 224 323 minecraft:dark_prismarine
fill 170 224 324 170 227 324 minecraft:blue_terracotta
setblock 170 224 363 minecraft:dark_prismarine
fill 170 224 364 173 230 364 minecraft:blue_concrete
fill 171 224 323 171 227 323 minecraft:blue_terracotta
fill 171 224 363 171 227 363 minecraft:blue_terracotta
fill 173 224 363 173 225 363 minecraft:blue_terracotta
setblock 174 224 324 minecraft:dark_prismarine
setblock 175 224 323 minecraft:dark_prismarine
setblock 175 224 324 minecraft:blue_terracotta
setblock 175 224 363 minecraft:dark_prismarine
fill 176 224 323 177 224 323 minecraft:blue_terracotta
setblock 176 224 363 minecraft:blue_terracotta
fill 180 224 364 180 308 364 minecraft:blue_concrete
setblock 181 224 356 minecraft:blue_terracotta
setblock 181 224 357 minecraft:dark_prismarine
setblock 182 224 326 minecraft:dark_prismarine
setblock 182 224 327 minecraft:blue_terracotta
setblock 182 224 331 minecraft:dark_prismarine
fill 182 224 332 182 226 333 minecraft:blue_terracotta
setblock 182 224 335 minecraft:blue_terracotta
setblock 182 224 338 minecraft:purple_concrete
setblock 182 224 350 minecraft:blue_terracotta
setblock 182 224 351 minecraft:dark_prismarine
fill 182 224 352 182 227 352 minecraft:blue_terracotta
setblock 182 224 356 minecraft:dark_prismarine
fill 182 224 357 182 224 360 minecraft:blue_terracotta
setblock 182 224 361 minecraft:dark_prismarine
fill 182 224 362 182 227 362 minecraft:blue_terracotta
fill 183 224 333 183 308 333 minecraft:blue_concrete
fill 183 224 342 183 307 342 minecraft:blue_concrete
fill 183 224 346 183 239 346 minecraft:blue_concrete
fill 141 225 326 141 303 327 minecraft:blue_concrete
setblock 141 225 328 minecraft:cyan_concrete
fill 141 225 329 141 308 329 minecraft:blue_concrete
setblock 142 225 335 minecraft:dark_prismarine
setblock 142 225 350 minecraft:dark_prismarine
fill 142 225 351 142 228 351 minecraft:blue_terracotta
setblock 142 225 355 minecraft:dark_prismarine
fill 142 225 356 142 228 356 minecraft:blue_terracotta
setblock 142 225 359 minecraft:blue_terracotta
setblock 142 225 360 minecraft:dark_prismarine
fill 142 225 361 142 228 361 minecraft:blue_terracotta
setblock 143 225 349 minecraft:dark_prismarine
fill 143 225 350 143 227 350 minecraft:blue_terracotta
setblock 143 225 354 minecraft:dark_prismarine
fill 143 225 355 143 228 355 minecraft:blue_terracotta
setblock 143 225 359 minecraft:dark_prismarine
fill 143 225 360 143 228 360 minecraft:blue_terracotta
setblock 144 225 352 minecraft:blue_terracotta
setblock 144 225 353 minecraft:dark_prismarine
fill 144 225 354 144 228 354 minecraft:blue_terracotta
setblock 144 225 358 minecraft:dark_prismarine
setblock 144 225 363 minecraft:dark_prismarine
setblock 145 225 353 minecraft:blue_terracotta
fill 145 225 363 145 228 363 minecraft:blue_terracotta
fill 146 225 362 146 228 362 minecraft:blue_terracotta
fill 148 225 345 148 234 345 minecraft:magenta_terracotta
setblock 149 225 363 minecraft:dark_prismarine
fill 150 225 363 151 225 363 minecraft:blue_terracotta
fill 153 225 323 153 229 323 minecraft:dark_prismarine
setblock 158 225 363 minecraft:purple_concrete
fill 165 225 323 165 228 323 minecraft:blue_terracotta
setblock 168 225 324 minecraft:dark_prismarine
setblock 169 225 323 minecraft:dark_prismarine
fill 169 225 324 169 227 324 minecraft:blue_terracotta
setblock 169 225 363 minecraft:dark_prismarine
fill 170 225 323 170 228 323 minecraft:blue_terracotta
fill 170 225 363 170 228 363 minecraft:blue_terracotta
setblock 173 225 324 minecraft:dark_prismarine
setblock 174 225 323 minecraft:dark_prismarine
fill 174 225 326 174 226 326 minecraft:black_concrete
setblock 174 225 363 minecraft:dark_prismarine
fill 175 225 323 176 225 323 minecraft:blue_terracotta
fill 175 225 325 175 226 325 minecraft:black_concrete
fill 175 225 327 175 226 327 minecraft:black_concrete
setblock 175 225 363 minecraft:blue_terracotta
fill 176 225 326 176 226 326 minecraft:black_concrete
setblock 177 225 363 minecraft:purple_concrete
setblock 181 225 356 minecraft:dark_prismarine
fill 181 225 357 182 226 358 minecraft:blue_terracotta
setblock 182 225 326 minecraft:purple_concrete
setblock 182 225 330 minecraft:dark_prismarine
fill 182 225 331 182 226 331 minecraft:blue_terracotta
setblock 182 225 335 minecraft:dark_prismarine
fill 182 225 351 182 226 351 minecraft:blue_terracotta
setblock 182 225 355 minecraft:dark_prismarine
fill 182 225 356 182 228 356 minecraft:blue_terracotta
setblock 182 225 359 minecraft:blue_terracotta
setblock 182 225 360 minecraft:dark_prismarine
fill 182 225 361 182 228 361 minecraft:blue_terracotta
fill 141 226 328 141 308 328 minecraft:blue_concrete
setblock 142 226 334 minecraft:dark_prismarine
fill 142 226 335 142 228 336 minecraft:blue_terracotta
setblock 142 226 341 minecraft:purple_concrete
setblock 142 226 349 minecraft:dark_prismarine
fill 142 226 350 142 229 350 minecraft:blue_terracotta
setblock 142 226 354 minecraft:dark_prismarine
fill 142 226 355 142 229 355 minecraft:blue_terracotta
setblock 142 226 359 minecraft:dark_prismarine
fill 142 226 360 142 229 360 minecraft:blue_terracotta
setblock 143 226 353 minecraft:dark_prismarine
fill 143 226 354 143 229 354 minecraft:blue_terracotta
setblock 143 226 358 minecraft:dark_prismarine
fill 143 226 359 144 228 359 minecraft:blue_terracotta
fill 143 226 361 143 227 361 minecraft:blue_terracotta
setblock 143 226 363 minecraft:dark_prismarine
setblock 144 226 352 minecraft:dark_prismarine
fill 144 226 353 144 229 353 minecraft:blue_terracotta
setblock 144 226 357 minecraft:dark_prismarine
fill 144 226 358 144 229 358 minecraft:blue_terracotta
fill 144 226 363 144 229 363 minecraft:blue_terracotta
setblock 145 226 356 minecraft:dark_prismarine
setblock 148 226 363 minecraft:dark_prismarine
fill 149 226 323 149 229 323 minecraft:dark_prismarine
setblock 149 226 324 minecraft:sea_lantern
setblock 149 226 326 minecraft:sea_lantern
setblock 149 226 328 minecraft:sea_lantern
fill 149 226 363 150 227 363 minecraft:blue_terracotta
setblock 150 226 323 minecraft:sea_lantern
setblock 150 226 325 minecraft:sea_lantern
setblock 150 226 327 minecraft:sea_lantern
setblock 151 226 324 minecraft:sea_lantern
setblock 151 226 326 minecraft:sea_lantern
setblock 151 226 328 minecraft:sea_lantern
setblock 152 226 323 minecraft:sea_lantern
setblock 152 226 325 minecraft:sea_lantern
setblock 152 226 327 minecraft:sea_lantern
setblock 153 226 324 minecraft:sea_lantern
setblock 153 226 326 minecraft:sea_lantern
setblock 153 226 328 minecraft:sea_lantern
setblock 154 226 323 minecraft:sea_lantern
setblock 154 226 325 minecraft:sea_lantern
setblock 154 226 327 minecraft:sea_lantern
setblock 155 226 324 minecraft:sea_lantern
setblock 155 226 326 minecraft:sea_lantern
setblock 155 226 328 minecraft:sea_lantern
setblock 160 226 323 minecraft:purple_concrete
setblock 164 226 363 minecraft:purple_concrete
setblock 167 226 323 minecraft:blue_terracotta
setblock 167 226 324 minecraft:dark_prismarine
setblock 168 226 323 minecraft:dark_prismarine
fill 168 226 324 168 229 324 minecraft:blue_terracotta
setblock 168 226 363 minecraft:dark_prismarine
fill 169 226 323 169 229 323 minecraft:blue_terracotta
fill 169 226 363 169 229 363 minecraft:blue_terracotta
setblock 172 226 323 minecraft:blue_terracotta
setblock 173 226 323 minecraft:dark_prismarine
setblock 173 226 363 minecraft:dark_prismarine
setblock 174 226 323 minecraft:blue_terracotta
fill 174 226 363 174 229 363 minecraft:blue_terracotta
setblock 179 226 323 minecraft:purple_concrete
setblock 181 226 355 minecraft:dark_prismarine
fill 181 226 356 181 229 356 minecraft:blue_terracotta
setblock 181 226 359 minecraft:blue_terracotta
fill 181 226 363 181 227 363 minecraft:blue_terracotta
setblock 182 226 334 minecraft:dark_prismarine
setblock 182 226 345 minecraft:purple_concrete
setblock 182 226 354 minecraft:dark_prismarine
fill 182 226 355 182 229 355 minecraft:blue_terracotta
setblock 182 226 359 minecraft:dark_prismarine
fill 182 226 360 182 229 360 minecraft:blue_terracotta
fill 142 227 328 142 228 328 minecraft:purple_concrete
fill 142 227 334 142 229 334 minecraft:blue_terracotta
setblock 142 227 337 minecraft:blue_terracotta
setblock 142 227 338 minecraft:dark_prismarine
setblock 142 227 347 minecraft:purple_concrete
fill 142 227 349 142 229 349 minecraft:blue_terracotta
setblock 142 227 353 minecraft:dark_prismarine
fill 142 227 354 142 229 354 minecraft:blue_terracotta
setblock 142 227 358 minecraft:dark_prismarine
fill 142 227 359 142 229 359 minecraft:blue_terracotta
setblock 142 227 363 minecraft:dark_prismarine
setblock 143 227 352 minecraft:dark_prismarine
fill 143 227 353 143 229 353 minecraft:blue_terracotta
setblock 143 227 357 minecraft:dark_prismarine
fill 143 227 358 143 229 358 minecraft:blue_terracotta
fill 143 227 363 143 229 363 minecraft:blue_terracotta
setblock 144 227 325 minecraft:light[level=12]
setblock 144 227 332 minecraft:light[level=12]
setblock 144 227 339 minecraft:light[level=12]
setblock 144 227 346 minecraft:light[level=12]
setblock 144 227 352 minecraft:blue_terracotta
setblock 144 227 356 minecraft:dark_prismarine
fill 144 227 357 144 229 357 minecraft:blue_terracotta
setblock 144 227 360 minecraft:light[level=12]
fill 145 227 362 145 229 362 minecraft:blue_terracotta
setblock 147 227 363 minecraft:dark_prismarine
setblock 148 227 362 minecraft:dark_prismarine
fill 148 227 363 148 229 363 minecraft:blue_terracotta
fill 149 227 324 149 229 324 minecraft:dark_prismarine
fill 149 227 326 149 229 326 minecraft:dark_prismarine
fill 149 227 328 149 229 328 minecraft:dark_prismarine
fill 150 227 323 150 229 323 minecraft:dark_prismarine
fill 150 227 325 150 229 325 minecraft:dark_prismarine
fill 150 227 327 150 229 327 minecraft:dark_prismarine
fill 151 227 324 151 229 324 minecraft:dark_prismarine
fill 151 227 326 151 229 326 minecraft:dark_prismarine
fill 151 227 328 151 229 328 minecraft:dark_prismarine
setblock 151 227 332 minecraft:light[level=12]
setblock 151 227 339 minecraft:light[level=12]
setblock 151 227 346 minecraft:light[level=12]
setblock 151 227 353 minecraft:light[level=12]
setblock 151 227 360 minecraft:light[level=12]
setblock 151 227 363 minecraft:purple_concrete
fill 152 227 323 152 229 323 minecraft:dark_prismarine
fill 152 227 325 152 229 325 minecraft:dark_prismarine
fill 152 227 327 152 229 327 minecraft:dark_prismarine
fill 153 227 324 153 229 324 minecraft:dark_prismarine
fill 153 227 326 153 229 326 minecraft:dark_prismarine
fill 153 227 328 153 229 328 minecraft:dark_prismarine
setblock 154 227 323 minecraft:purple_concrete
fill 154 227 325 154 229 325 minecraft:dark_prismarine
fill 154 227 327 154 229 327 minecraft:dark_prismarine
fill 155 227 324 155 229 324 minecraft:dark_prismarine
fill 155 227 326 155 229 326 minecraft:dark_prismarine
fill 155 227 328 155 229 328 minecraft:dark_prismarine
setblock 158 227 325 minecraft:light[level=12]
setblock 158 227 332 minecraft:light[level=12]
setblock 158 227 339 minecraft:light[level=12]
setblock 158 227 346 minecraft:light[level=12]
setblock 158 227 353 minecraft:light[level=12]
setblock 158 227 360 minecraft:light[level=12]
setblock 165 227 325 minecraft:light[level=12]
setblock 165 227 332 minecraft:light[level=12]
setblock 165 227 339 minecraft:light[level=12]
setblock 165 227 346 minecraft:light[level=12]
setblock 165 227 353 minecraft:light[level=12]
setblock 165 227 360 minecraft:light[level=12]
setblock 166 227 363 minecraft:blue_terracotta
setblock 167 227 323 minecraft:dark_prismarine
setblock 167 227 324 minecraft:blue_terracotta
setblock 167 227 363 minecraft:dark_prismarine
fill 168 227 323 168 229 323 minecraft:blue_terracotta
fill 168 227 363 168 229 363 minecraft:blue_terracotta
setblock 172 227 323 minecraft:dark_prismarine
setblock 172 227 325 minecraft:light[level=12]
setblock 172 227 332 minecraft:light[level=12]
setblock 172 227 339 minecraft:light[level=12]
setblock 172 227 346 minecraft:light[level=12]
setblock 172 227 353 minecraft:light[level=12]
setblock 172 227 360 minecraft:light[level=12]
setblock 172 227 363 minecraft:dark_prismarine
fill 173 227 323 173 228 323 minecraft:blue_terracotta
fill 173 227 363 173 229 363 minecraft:blue_terracotta
setblock 179 227 325 minecraft:light[level=12]
setblock 179 227 332 minecraft:light[level=12]
setblock 179 227 339 minecraft:light[level=12]
setblock 179 227 346 minecraft:light[level=12]
setblock 179 227 353 minecraft:light[level=12]
setblock 179 227 360 minecraft:light[level=12]
fill 181 227 355 181 229 355 minecraft:blue_terracotta
fill 181 227 357 181 227 358 minecraft:blue_terracotta
setblock 181 227 359 minecraft:dark_prismarine
fill 181 227 360 181 229 360 minecraft:blue_terracotta
setblock 182 227 339 minecraft:purple_concrete
setblock 182 227 353 minecraft:dark_prismarine
fill 182 227 354 182 229 354 minecraft:blue_terracotta
setblock 182 227 357 minecraft:blue_terracotta
setblock 182 227 358 minecraft:dark_prismarine
fill 182 227 359 182 229 359 minecraft:blue_terracotta
setblock 182 227 363 minecraft:dark_prismarine
fill 183 227 324 183 230 330 minecraft:blue_concrete
setblock 183 227 331 minecraft:cyan_concrete
fill 183 227 332 183 308 332 minecraft:blue_concrete
setblock 142 228 337 minecraft:dark_prismarine
fill 142 228 338 142 229 340 minecraft:blue_terracotta
setblock 142 228 352 minecraft:dark_prismarine
fill 142 228 353 142 229 353 minecraft:blue_terracotta
setblock 142 228 357 minecraft:dark_prismarine
fill 142 228 358 142 229 358 minecraft:blue_terracotta
setblock 142 228 362 minecraft:dark_prismarine
fill 142 228 363 142 229 363 minecraft:blue_terracotta
setblock 143 228 351 minecraft:dark_prismarine
fill 143 228 352 143 229 352 minecraft:blue_terracotta
setblock 143 228 356 minecraft:dark_prismarine
fill 143 228 357 143 229 357 minecraft:blue_terracotta
setblock 143 228 361 minecraft:dark_prismarine
setblock 144 228 355 minecraft:dark_prismarine
fill 144 228 356 144 229 356 minecraft:blue_terracotta
fill 144 228 362 144 229 362 minecraft:blue_terracotta
setblock 146 228 363 minecraft:dark_prismarine
setblock 147 228 362 minecraft:dark_prismarine
fill 147 228 363 147 229 363 minecraft:blue_terracotta
setblock 148 228 323 minecraft:purple_concrete
fill 149 228 363 149 229 363 minecraft:blue_terracotta
fill 154 228 323 154 229 323 minecraft:dark_prismarine
setblock 157 228 363 minecraft:purple_concrete
fill 164 228 323 164 229 323 minecraft:blue_terracotta
setblock 165 228 363 minecraft:blue_terracotta
setblock 166 228 323 minecraft:dark_prismarine
setblock 166 228 363 minecraft:dark_prismarine
fill 167 228 323 167 229 323 minecraft:blue_terracotta
fill 167 228 363 167 229 363 minecraft:blue_terracotta
fill 168 228 362 169 229 362 minecraft:blue_terracotta
setblock 171 228 323 minecraft:dark_prismarine
setblock 171 228 363 minecraft:dark_prismarine
fill 172 228 323 172 229 323 minecraft:blue_terracotta
fill 172 228 363 172 229 363 minecraft:blue_terracotta
fill 176 228 341 176 234 341 minecraft:magenta_terracotta
setblock 176 228 363 minecraft:purple_concrete
setblock 180 228 363 minecraft:blue_terracotta
setblock 181 228 357 minecraft:blue_terracotta
setblock 181 228 358 minecraft:dark_prismarine
fill 181 228 359 181 229 359 minecraft:blue_terracotta
fill 181 228 361 181 229 361 minecraft:blue_terracotta
setblock 181 228 363 minecraft:dark_prismarine
setblock 182 228 333 minecraft:purple_concrete
setblock 182 228 352 minecraft:dark_prismarine
fill 182 228 353 182 229 353 minecraft:blue_terracotta
setblock 182 228 357 minecraft:dark_prismarine
fill 182 228 358 182 229 358 minecraft:blue_terracotta
setblock 182 228 362 minecraft:dark_prismarine
fill 182 228 363 182 229 363 minecraft:blue_terracotta
fill 183 228 331 183 286 331 minecraft:blue_concrete
setblock 142 229 335 minecraft:blue_terracotta
setblock 142 229 336 minecraft:dark_prismarine
fill 142 229 337 143 229 337 minecraft:blue_terracotta
setblock 142 229 341 minecraft:dark_prismarine
fill 142 229 342 142 229 343 minecraft:blue_terracotta
setblock 142 229 348 minecraft:blue_terracotta
setblock 142 229 351 minecraft:dark_prismarine
setblock 142 229 352 minecraft:blue_terracotta
setblock 142 229 356 minecraft:dark_prismarine
setblock 142 229 357 minecraft:blue_terracotta
setblock 142 229 361 minecraft:dark_prismarine
fill 142 229 362 143 229 362 minecraft:blue_terracotta
setblock 143 229 336 minecraft:blue_terracotta
fill 143 229 338 143 229 339 minecraft:blue_terracotta
setblock 143 229 340 minecraft:dark_prismarine
setblock 143 229 351 minecraft:blue_terracotta
setblock 143 229 355 minecraft:dark_prismarine
setblock 143 229 356 minecraft:blue_terracotta
setblock 143 229 359 minecraft:blue_terracotta
setblock 143 229 360 minecraft:dark_prismarine
setblock 143 229 361 minecraft:blue_terracotta
setblock 144 229 325 minecraft:light[level=13]
setblock 144 229 333 minecraft:light[level=13]
setblock 144 229 341 minecraft:light[level=13]
setblock 144 229 349 minecraft:light[level=13]
setblock 144 229 354 minecraft:dark_prismarine
setblock 144 229 355 minecraft:blue_terracotta
setblock 144 229 359 minecraft:dark_prismarine
setblock 144 229 360 minecraft:blue_terracotta
setblock 145 229 363 minecraft:dark_prismarine
setblock 146 229 362 minecraft:dark_prismarine
setblock 146 229 363 minecraft:blue_terracotta
fill 147 229 362 148 229 362 minecraft:blue_terracotta
setblock 152 229 333 minecraft:light[level=13]
setblock 152 229 341 minecraft:light[level=13]
setblock 152 229 349 minecraft:light[level=13]
setblock 152 229 357 minecraft:light[level=13]
setblock 160 229 322 minecraft:light_blue_wool
setblock 160 229 325 minecraft:light[level=13]
setblock 160 229 333 minecraft:light[level=13]
setblock 160 229 349 minecraft:light[level=13]
setblock 160 229 357 minecraft:light[level=13]
fill 161 229 322 163 258 322 minecraft:blue_concrete
setblock 161 229 323 minecraft:purple_concrete
setblock 163 229 323 minecraft:blue_terracotta
setblock 163 229 363 minecraft:purple_concrete
setblock 164 229 363 minecraft:blue_terracotta
setblock 165 229 323 minecraft:dark_prismarine
setblock 165 229 363 minecraft:dark_prismarine
setblock 166 229 323 minecraft:blue_terracotta
setblock 166 229 362 minecraft:dark_prismarine
setblock 166 229 363 minecraft:blue_terracotta
setblock 167 229 324 minecraft:blue_terracotta
setblock 167 229 362 minecraft:blue_terracotta
setblock 168 229 325 minecraft:light[level=13]
setblock 168 229 333 minecraft:light[level=13]
setblock 168 229 341 minecraft:light[level=13]
setblock 168 229 349 minecraft:light[level=13]
setblock 168 229 357 minecraft:light[level=13]
fill 169 229 357 169 234 357 minecraft:magenta_terracotta
setblock 170 229 323 minecraft:dark_prismarine
setblock 170 229 362 minecraft:blue_terracotta
setblock 170 229 363 minecraft:dark_prismarine
setblock 171 229 323 minecraft:blue_terracotta
setblock 171 229 363 minecraft:blue_terracotta
fill 175 229 340 175 230 340 minecraft:magenta_terracotta
setblock 175 229 363 minecraft:dark_prismarine
setblock 176 229 325 minecraft:light[level=13]
setblock 176 229 333 minecraft:light[level=13]
setblock 176 229 349 minecraft:light[level=13]
setblock 176 229 357 minecraft:light[level=13]
fill 177 229 363 179 229 363 minecraft:blue_terracotta
setblock 177 229 364 minecraft:cyan_concrete
fill 178 229 364 179 240 364 minecraft:blue_concrete
setblock 180 229 363 minecraft:dark_prismarine
setblock 181 229 357 minecraft:dark_prismarine
setblock 181 229 358 minecraft:blue_terracotta
setblock 181 229 362 minecraft:dark_prismarine
setblock 181 229 363 minecraft:blue_terracotta
setblock 182 229 327 minecraft:purple_concrete
setblock 182 229 335 minecraft:blue_terracotta
setblock 182 229 336 minecraft:dark_prismarine
setblock 182 229 346 minecraft:purple_concrete
setblock 182 229 352 minecraft:blue_terracotta
setblock 182 229 356 minecraft:dark_prismarine
setblock 182 229 357 minecraft:blue_terracotta
setblock 182 229 361 minecraft:dark_prismarine
setblock 182 229 362 minecraft:blue_terracotta
fill 160 230 322 160 308 322 minecraft:blue_concrete
fill 176 230 339 176 233 339 minecraft:magenta_terracotta
fill 177 230 364 177 308 364 minecraft:blue_concrete
fill 141 231 339 141 248 343 minecraft:blue_concrete
setblock 141 231 344 minecraft:cyan_concrete
fill 169 231 340 175 248 342 minecraft:jungle_log
fill 170 231 339 174 249 339 minecraft:jungle_log
fill 170 231 343 174 249 343 minecraft:jungle_log
fill 170 231 364 172 308 364 minecraft:blue_concrete
fill 171 231 338 173 249 338 minecraft:jungle_log
fill 171 231 344 173 249 344 minecraft:jungle_log
setblock 173 231 364 minecraft:light_blue_wool
fill 183 231 324 183 234 327 minecraft:blue_concrete
setblock 183 231 328 minecraft:cyan_concrete
fill 183 231 329 183 288 330 minecraft:blue_concrete
fill 141 232 344 141 307 344 minecraft:blue_concrete
fill 173 232 364 173 308 364 minecraft:blue_concrete
fill 183 232 328 183 285 328 minecraft:blue_concrete
setblock 144 233 325 minecraft:light[level=12]
setblock 144 233 332 minecraft:light[level=12]
setblock 144 233 339 minecraft:light[level=12]
setblock 144 233 346 minecraft:light[level=12]
setblock 144 233 353 minecraft:light[level=12]
setblock 144 233 360 minecraft:light[level=12]
setblock 151 233 325 minecraft:light[level=12]
setblock 151 233 332 minecraft:light[level=12]
setblock 151 233 339 minecraft:light[level=12]
setblock 151 233 346 minecraft:light[level=12]
setblock 151 233 353 minecraft:light[level=12]
setblock 151 233 360 minecraft:light[level=12]
fill 155 233 329 155 234 329 minecraft:magenta_terracotta
fill 156 233 330 156 234 330 minecraft:magenta_terracotta
setblock 158 233 325 minecraft:light[level=12]
setblock 158 233 332 minecraft:light[level=12]
setblock 158 233 339 minecraft:light[level=12]
setblock 158 233 346 minecraft:light[level=12]
setblock 158 233 353 minecraft:light[level=12]
setblock 158 233 360 minecraft:light[level=12]
setblock 165 233 325 minecraft:light[level=12]
setblock 165 233 332 minecraft:light[level=12]
setblock 165 233 339 minecraft:light[level=12]
setblock 165 233 346 minecraft:light[level=12]
setblock 165 233 353 minecraft:light[level=12]
setblock 165 233 360 minecraft:light[level=12]
setblock 172 233 325 minecraft:light[level=12]
setblock 172 233 332 minecraft:light[level=12]
setblock 172 233 346 minecraft:light[level=12]
setblock 172 233 353 minecraft:light[level=12]
setblock 172 233 360 minecraft:light[level=12]
setblock 179 233 325 minecraft:light[level=12]
setblock 179 233 332 minecraft:light[level=12]
setblock 179 233 339 minecraft:light[level=12]
setblock 179 233 346 minecraft:light[level=12]
setblock 179 233 353 minecraft:light[level=12]
setblock 179 233 360 minecraft:light[level=12]
fill 183 233 334 183 238 339 minecraft:blue_concrete
setblock 183 233 340 minecraft:light_blue_wool
fill 183 233 341 183 308 341 minecraft:blue_concrete
setblock 149 234 345 minecraft:magenta_terracotta
setblock 170 234 357 minecraft:magenta_terracotta
fill 183 234 340 183 308 340 minecraft:blue_concrete
fill 142 235 323 144 237 323 minecraft:black_stained_glass
fill 142 235 324 142 237 331 minecraft:black_wool
fill 142 235 332 144 237 336 minecraft:black_stained_glass
fill 142 235 337 145 237 344 minecraft:black_wool
fill 142 235 345 143 237 349 minecraft:black_stained_glass
fill 142 235 350 145 237 356 minecraft:black_wool
fill 142 235 357 143 237 361 minecraft:black_stained_glass
fill 142 235 362 146 237 363 minecraft:black_wool
fill 143 235 324 143 237 324 minecraft:black_stained_glass
fill 143 235 325 145 237 331 minecraft:black_wool
fill 144 235 324 151 237 324 minecraft:black_wool
fill 144 235 345 144 237 348 minecraft:black_stained_glass
fill 144 235 349 150 237 349 minecraft:black_wool
fill 144 235 357 150 237 357 minecraft:black_wool
fill 144 235 358 144 237 361 minecraft:black_stained_glass
fill 145 235 323 150 237 323 minecraft:black_wool
fill 145 235 332 149 237 336 minecraft:black_wool
fill 145 235 345 149 237 348 minecraft:black_wool
fill 145 235 358 149 237 361 minecraft:black_wool
fill 146 235 325 182 237 325 minecraft:black_wool
fill 146 235 326 148 237 329 minecraft:black_stained_glass
fill 146 235 330 146 237 331 minecraft:black_wool
fill 146 235 337 146 237 338 minecraft:black_wool
fill 146 235 339 148 237 342 minecraft:black_stained_glass
fill 146 235 343 159 236 344 minecraft:black_wool
fill 146 235 350 182 237 350 minecraft:black_wool
fill 146 235 351 148 237 355 minecraft:black_stained_glass
fill 146 235 356 182 237 356 minecraft:black_wool
fill 147 235 330 148 237 330 minecraft:black_stained_glass
fill 147 235 331 182 237 331 minecraft:black_wool
fill 147 235 337 182 237 337 minecraft:black_wool
fill 147 235 338 148 237 338 minecraft:black_stained_glass
fill 147 235 362 182 237 362 minecraft:black_wool
fill 147 235 363 147 237 363 minecraft:black_stained_glass
fill 148 235 363 155 237 363 minecraft:black_wool
fill 149 235 326 154 237 326 minecraft:black_wool
fill 149 235 327 149 237 328 minecraft:black_stained_glass
fill 149 235 329 154 237 330 minecraft:black_wool
fill 149 235 338 154 237 339 minecraft:black_wool
fill 149 235 340 149 237 341 minecraft:black_stained_glass
fill 149 235 342 154 237 342 minecraft:black_wool
fill 149 235 351 154 237 352 minecraft:black_wool
fill 149 235 353 149 237 353 minecraft:black_stained_glass
fill 149 235 354 154 237 355 minecraft:black_wool
fill 150 235 327 154 237 328 minecraft:black_wool
fill 150 235 332 150 237 332 minecraft:black_wool
fill 150 235 333 153 237 335 minecraft:black_stained_glass
fill 150 235 336 150 237 336 minecraft:black_wool
fill 150 235 340 154 237 341 minecraft:black_wool
fill 150 235 345 150 237 345 minecraft:black_wool
fill 150 235 346 153 237 347 minecraft:black_stained_glass
fill 150 235 348 150 237 348 minecraft:black_wool
fill 150 235 353 154 237 353 minecraft:black_wool
fill 150 235 358 150 237 358 minecraft:black_wool
fill 150 235 359 153 237 360 minecraft:black_stained_glass
fill 150 235 361 150 237 361 minecraft:black_wool
fill 151 235 323 153 237 323 minecraft:black_stained_glass
fill 151 235 332 153 237 332 minecraft:black_stained_glass
fill 151 235 336 153 237 336 minecraft:black_stained_glass
fill 151 235 345 153 237 345 minecraft:black_stained_glass
fill 151 235 348 152 237 349 minecraft:black_stained_glass
fill 151 235 357 152 237 358 minecraft:black_stained_glass
fill 151 235 361 153 237 361 minecraft:black_stained_glass
fill 152 235 324 152 237 324 minecraft:black_stained_glass
fill 153 235 324 160 237 324 minecraft:black_wool
fill 153 235 348 153 237 348 minecraft:black_stained_glass
fill 153 235 349 159 237 349 minecraft:black_wool
fill 153 235 357 159 237 357 minecraft:black_wool
fill 153 235 358 153 237 358 minecraft:black_stained_glass
fill 154 235 323 159 237 323 minecraft:black_wool
fill 154 235 332 158 237 336 minecraft:black_wool
fill 154 235 345 158 237 348 minecraft:black_wool
fill 154 235 358 158 237 361 minecraft:black_wool
fill 155 235 326 157 237 329 minecraft:black_stained_glass
fill 155 235 330 155 237 330 minecraft:black_wool
fill 155 235 338 155 237 338 minecraft:black_wool
fill 155 235 339 157 237 342 minecraft:black_stained_glass
fill 155 235 351 157 237 355 minecraft:black_stained_glass
fill 156 235 330 157 237 330 minecraft:black_stained_glass
fill 156 235 338 157 237 338 minecraft:black_stained_glass
fill 156 235 363 156 237 363 minecraft:black_stained_glass
fill 157 235 363 164 237 363 minecraft:black_wool
fill 158 235 326 163 237 327 minecraft:black_wool
fill 158 235 328 158 237 328 minecraft:black_stained_glass
fill 158 235 329 163 237 330 minecraft:black_wool
fill 158 235 338 159 236 339 minecraft:black_wool
fill 158 235 340 158 236 340 minecraft:black_stained_glass
fill 158 235 341 158 236 342 minecraft:black_wool
fill 158 235 351 163 237 352 minecraft:black_wool
fill 158 235 353 158 237 353 minecraft:black_stained_glass
fill 158 235 354 163 237 355 minecraft:black_wool
fill 159 235 328 163 237 328 minecraft:black_wool
fill 159 235 332 159 237 332 minecraft:black_wool
fill 159 235 333 162 237 335 minecraft:black_stained_glass
fill 159 235 336 159 237 336 minecraft:black_wool
fill 159 235 345 159 237 345 minecraft:black_wool
fill 159 235 346 162 237 347 minecraft:black_stained_glass
fill 159 235 348 159 237 348 minecraft:black_wool
fill 159 235 353 163 237 353 minecraft:black_wool
fill 159 235 358 162 237 360 minecraft:black_stained_glass
fill 159 235 361 159 237 361 minecraft:black_wool
fill 160 235 323 162 237 323 minecraft:black_stained_glass
fill 160 235 332 162 237 332 minecraft:black_stained_glass
fill 160 235 336 162 237 336 minecraft:black_stained_glass
fill 160 235 338 164 236 338 minecraft:black_wool
fill 160 235 344 170 236 344 minecraft:black_wool
fill 160 235 345 162 237 345 minecraft:black_stained_glass
fill 160 235 348 161 237 349 minecraft:black_stained_glass
fill 160 235 357 161 237 357 minecraft:black_stained_glass
fill 160 235 361 162 237 361 minecraft:black_stained_glass
fill 161 235 324 161 237 324 minecraft:black_stained_glass
fill 162 235 324 169 237 324 minecraft:black_wool
fill 162 235 348 162 237 348 minecraft:black_stained_glass
fill 162 235 349 168 237 349 minecraft:black_wool
fill 162 235 357 168 237 357 minecraft:black_wool
fill 163 235 323 168 237 323 minecraft:black_wool
fill 163 235 332 167 237 336 minecraft:black_wool
fill 163 235 339 163 236 339 minecraft:black_wool
fill 163 235 343 169 236 343 minecraft:black_wool
fill 163 235 345 167 237 348 minecraft:black_wool
fill 163 235 358 167 237 361 minecraft:black_wool
fill 164 235 326 166 237 330 minecraft:black_stained_glass
fill 164 235 339 166 236 342 minecraft:black_stained_glass
fill 164 235 351 166 237 355 minecraft:black_stained_glass
fill 165 235 338 166 237 338 minecraft:black_stained_glass
fill 165 235 363 165 237 363 minecraft:black_stained_glass
fill 166 235 363 173 237 363 minecraft:black_wool
fill 167 235 326 172 237 330 minecraft:black_wool
fill 167 235 338 168 237 342 minecraft:black_wool
fill 167 235 351 172 237 355 minecraft:black_wool
fill 168 235 332 168 237 332 minecraft:black_wool
fill 168 235 333 171 237 335 minecraft:black_stained_glass
fill 168 235 336 168 237 336 minecraft:black_wool
fill 168 235 345 168 237 345 minecraft:black_wool
fill 168 235 346 171 237 348 minecraft:black_stained_glass
fill 168 235 358 171 237 360 minecraft:black_stained_glass
fill 168 235 361 168 237 361 minecraft:black_wool
fill 169 235 323 171 237 323 minecraft:black_stained_glass
fill 169 235 332 171 237 332 minecraft:black_stained_glass
fill 169 235 336 171 237 336 minecraft:black_stained_glass
fill 169 235 338 169 237 339 minecraft:black_wool
fill 169 235 345 171 237 345 minecraft:black_stained_glass
fill 169 235 349 170 237 349 minecraft:black_stained_glass
fill 169 235 357 170 237 357 minecraft:black_stained_glass
fill 169 235 361 171 237 361 minecraft:black_stained_glass
fill 170 235 324 170 237 324 minecraft:black_stained_glass
fill 170 235 338 170 237 338 minecraft:black_wool
fill 171 235 324 178 237 324 minecraft:black_wool
fill 171 235 349 177 237 349 minecraft:black_wool
fill 171 235 357 177 237 357 minecraft:black_wool
fill 172 235 323 177 237 323 minecraft:black_wool
fill 172 235 332 176 237 336 minecraft:black_wool
fill 172 235 345 176 237 348 minecraft:black_wool
fill 172 235 358 176 237 361 minecraft:black_wool
fill 173 235 326 175 237 330 minecraft:black_stained_glass
fill 173 235 351 175 237 355 minecraft:black_stained_glass
fill 174 235 338 175 237 338 minecraft:black_stained_glass
fill 174 235 344 182 237 344 minecraft:black_wool
fill 174 235 363 174 237 363 minecraft:black_stained_glass
fill 175 235 339 175 237 339 minecraft:black_stained_glass
fill 175 235 343 182 237 343 minecraft:black_wool
fill 175 235 363 182 237 363 minecraft:black_wool
fill 176 235 326 181 237 330 minecraft:black_wool
fill 176 235 338 181 237 342 minecraft:black_wool
fill 176 235 351 181 237 355 minecraft:black_wool
fill 177 235 332 177 237 332 minecraft:black_wool
fill 177 235 333 180 237 335 minecraft:black_stained_glass
fill 177 235 336 177 237 336 minecraft:black_wool
fill 177 235 345 177 237 345 minecraft:black_wool
fill 177 235 346 180 237 348 minecraft:black_stained_glass
fill 177 235 358 180 237 360 minecraft:black_stained_glass
fill 177 235 361 177 237 361 minecraft:black_wool
fill 178 235 323 180 237 323 minecraft:black_stained_glass
fill 178 235 332 179 237 332 minecraft:black_stained_glass
fill 178 235 336 180 237 336 minecraft:black_stained_glass
fill 178 235 345 180 237 345 minecraft:black_stained_glass
fill 178 235 349 179 237 349 minecraft:black_stained_glass
fill 178 235 357 179 237 357 minecraft:black_stained_glass
fill 178 235 361 180 237 361 minecraft:black_stained_glass
fill 179 235 324 179 237 324 minecraft:black_stained_glass
fill 180 235 324 182 237 324 minecraft:black_wool
fill 180 235 332 182 237 332 minecraft:black_wool
fill 180 235 349 182 237 349 minecraft:black_wool
fill 180 235 357 182 237 357 minecraft:black_wool
fill 181 235 323 182 237 323 minecraft:black_wool
fill 181 235 333 182 237 336 minecraft:black_wool
fill 181 235 345 182 237 348 minecraft:black_wool
fill 181 235 358 182 237 361 minecraft:black_wool
fill 182 235 326 182 237 330 minecraft:black_stained_glass
fill 182 235 338 182 237 338 minecraft:black_wool
fill 182 235 339 182 237 342 minecraft:black_stained_glass
fill 182 235 351 182 237 355 minecraft:black_stained_glass
fill 183 235 324 183 266 325 minecraft:blue_concrete
setblock 183 235 326 minecraft:light_blue_wool
fill 183 235 327 183 291 327 minecraft:blue_concrete
setblock 141 236 345 minecraft:cyan_concrete
fill 183 236 326 183 308 326 minecraft:blue_concrete
fill 141 237 345 141 308 345 minecraft:blue_concrete
fill 146 237 343 157 237 344 minecraft:black_wool
fill 151 237 322 151 308 322 minecraft:blue_concrete
setblock 152 237 322 minecraft:cyan_concrete
fill 153 237 322 154 272 322 minecraft:blue_concrete
setblock 158 237 338 minecraft:black_wool
setblock 158 237 339 minecraft:sea_lantern
fill 158 237 340 158 237 342 minecraft:ochre_froglight
setblock 158 237 343 minecraft:sea_lantern
setblock 158 237 344 minecraft:black_wool
setblock 159 237 338 minecraft:sea_lantern
setblock 159 237 339 minecraft:ochre_froglight
setblock 159 237 343 minecraft:ochre_froglight
setblock 159 237 344 minecraft:sea_lantern
fill 160 237 338 162 237 338 minecraft:ochre_froglight
fill 160 237 344 162 237 344 minecraft:ochre_froglight
setblock 163 237 338 minecraft:sea_lantern
setblock 163 237 339 minecraft:ochre_froglight
setblock 163 237 343 minecraft:ochre_froglight
setblock 163 237 344 minecraft:sea_lantern
setblock 164 237 338 minecraft:black_wool
setblock 164 237 339 minecraft:sea_lantern
fill 164 237 340 164 237 342 minecraft:ochre_froglight
setblock 164 237 343 minecraft:sea_lantern
fill 164 237 344 170 237 344 minecraft:black_wool
fill 165 237 339 166 237 342 minecraft:black_stained_glass
fill 165 237 343 169 237 343 minecraft:black_wool
fill 148 238 345 149 239 346 minecraft:magenta_terracotta
fill 152 238 322 152 308 322 minecraft:blue_concrete
fill 154 238 330 156 242 330 minecraft:magenta_terracotta
fill 155 238 329 155 270 329 minecraft:magenta_terracotta
fill 155 238 358 156 262 359 minecraft:magenta_terracotta
fill 168 238 327 170 247 327 minecraft:magenta_terracotta
fill 169 238 328 169 262 328 minecraft:magenta_terracotta
fill 169 238 356 170 242 357 minecraft:magenta_terracotta
fill 176 238 340 177 240 341 minecraft:magenta_terracotta
fill 141 239 331 141 308 331 minecraft:blue_concrete
setblock 141 239 332 minecraft:light_blue_wool
fill 141 239 333 141 270 335 minecraft:blue_concrete
setblock 141 239 347 minecraft:cyan_concrete
setblock 144 239 325 minecraft:light[level=12]
setblock 144 239 332 minecraft:light[level=12]
setblock 144 239 339 minecraft:light[level=12]
setblock 144 239 346 minecraft:light[level=12]
setblock 144 239 353 minecraft:light[level=12]
setblock 144 239 360 minecraft:light[level=12]
setblock 151 239 325 minecraft:light[level=12]
setblock 151 239 332 minecraft:light[level=12]
setblock 151 239 339 minecraft:light[level=12]
setblock 151 239 346 minecraft:light[level=12]
setblock 151 239 353 minecraft:light[level=12]
setblock 151 239 360 minecraft:light[level=12]
fill 155 239 322 157 308 322 minecraft:blue_concrete
setblock 158 239 322 minecraft:cyan_concrete
setblock 158 239 325 minecraft:light[level=12]
setblock 158 239 332 minecraft:light[level=12]
setblock 158 239 339 minecraft:light[level=12]
setblock 158 239 346 minecraft:light[level=12]
setblock 158 239 353 minecraft:light[level=12]
setblock 158 239 360 minecraft:light[level=12]
fill 159 239 322 159 308 322 minecraft:blue_concrete
setblock 165 239 325 minecraft:light[level=12]
setblock 165 239 332 minecraft:light[level=12]
setblock 165 239 339 minecraft:light[level=12]
setblock 165 239 346 minecraft:light[level=12]
setblock 165 239 353 minecraft:light[level=12]
setblock 165 239 360 minecraft:light[level=12]
setblock 172 239 325 minecraft:light[level=12]
setblock 172 239 332 minecraft:light[level=12]
setblock 172 239 346 minecraft:light[level=12]
setblock 172 239 353 minecraft:light[level=12]
setblock 172 239 360 minecraft:light[level=12]
setblock 179 239 325 minecraft:light[level=12]
setblock 179 239 332 minecraft:light[level=12]
setblock 179 239 339 minecraft:light[level=12]
setblock 179 239 346 minecraft:light[level=12]
setblock 179 239 353 minecraft:light[level=12]
setblock 179 239 360 minecraft:light[level=12]
fill 183 239 334 183 308 334 minecraft:blue_concrete
setblock 183 239 335 minecraft:cyan_concrete
fill 183 239 336 183 264 336 minecraft:blue_concrete
setblock 183 239 337 minecraft:cyan_concrete
fill 183 239 338 183 308 339 minecraft:blue_concrete
fill 141 240 332 141 308 332 minecraft:blue_concrete
fill 141 240 347 141 308 347 minecraft:blue_concrete
fill 148 240 345 148 246 346 minecraft:magenta_terracotta
fill 149 240 345 149 255 345 minecraft:magenta_terracotta
setblock 154 240 364 minecraft:light_blue_wool
fill 155 240 364 156 308 364 minecraft:blue_concrete
fill 158 240 322 158 308 322 minecraft:blue_concrete
fill 183 240 335 183 308 335 minecraft:blue_concrete
fill 183 240 337 183 308 337 minecraft:blue_concrete
setblock 183 240 346 minecraft:light_blue_wool
setblock 142 241 323 minecraft:blue_terracotta
setblock 142 241 324 minecraft:dark_prismarine
fill 142 241 325 142 241 328 minecraft:blue_terracotta
setblock 142 241 329 minecraft:dark_prismarine
fill 142 241 330 142 241 333 minecraft:blue_terracotta
setblock 142 241 334 minecraft:dark_prismarine
fill 142 241 335 142 241 338 minecraft:blue_terracotta
setblock 142 241 339 minecraft:dark_prismarine
fill 142 241 340 142 241 343 minecraft:blue_terracotta
setblock 142 241 344 minecraft:dark_prismarine
fill 142 241 345 142 241 348 minecraft:blue_terracotta
setblock 142 241 349 minecraft:dark_prismarine
fill 142 241 350 142 241 353 minecraft:blue_terracotta
setblock 142 241 354 minecraft:dark_prismarine
fill 142 241 355 142 241 358 minecraft:blue_terracotta
setblock 142 241 359 minecraft:dark_prismarine
fill 142 241 360 142 241 363 minecraft:blue_terracotta
setblock 143 241 323 minecraft:dark_prismarine
fill 143 241 324 143 241 325 minecraft:blue_terracotta
setblock 143 241 337 minecraft:blue_terracotta
setblock 143 241 338 minecraft:dark_prismarine
fill 143 241 339 143 241 342 minecraft:blue_terracotta
setblock 143 241 343 minecraft:dark_prismarine
fill 143 241 344 143 241 347 minecraft:blue_terracotta
setblock 143 241 348 minecraft:dark_prismarine
fill 143 241 349 143 242 351 minecraft:blue_terracotta
setblock 143 241 363 minecraft:dark_prismarine
fill 144 241 323 147 241 323 minecraft:blue_terracotta
setblock 144 241 341 minecraft:blue_terracotta
setblock 144 241 342 minecraft:dark_prismarine
fill 144 241 343 144 241 346 minecraft:blue_terracotta
setblock 144 241 347 minecraft:dark_prismarine
setblock 144 241 348 minecraft:blue_terracotta
setblock 144 241 363 minecraft:blue_terracotta
setblock 147 241 363 minecraft:purple_concrete
setblock 148 241 323 minecraft:dark_prismarine
fill 149 241 323 152 241 323 minecraft:blue_terracotta
setblock 153 241 323 minecraft:dark_prismarine
fill 153 241 324 156 241 324 minecraft:blue_terracotta
fill 154 241 323 157 241 323 minecraft:blue_terracotta
fill 154 241 364 154 267 364 minecraft:blue_concrete
fill 155 241 363 157 241 363 minecraft:blue_terracotta
setblock 156 241 325 minecraft:dark_prismarine
setblock 157 241 324 minecraft:dark_prismarine
fill 157 241 325 160 241 325 minecraft:blue_terracotta
setblock 158 241 323 minecraft:dark_prismarine
fill 158 241 324 161 241 324 minecraft:blue_terracotta
setblock 158 241 362 minecraft:blue_terracotta
setblock 158 241 363 minecraft:dark_prismarine
fill 159 241 323 162 241 323 minecraft:blue_terracotta
setblock 159 241 326 minecraft:blue_terracotta
setblock 159 241 362 minecraft:dark_prismarine
fill 159 241 363 162 241 363 minecraft:blue_terracotta
setblock 160 241 326 minecraft:dark_prismarine
fill 160 241 362 163 241 362 minecraft:blue_terracotta
setblock 161 241 325 minecraft:dark_prismarine
fill 161 241 326 162 241 326 minecraft:blue_terracotta
setblock 162 241 324 minecraft:dark_prismarine
fill 162 241 325 165 241 325 minecraft:blue_terracotta
setblock 163 241 323 minecraft:dark_prismarine
fill 163 241 324 166 241 324 minecraft:blue_terracotta
setblock 163 241 363 minecraft:dark_prismarine
fill 164 241 323 167 241 323 minecraft:blue_terracotta
setblock 164 241 362 minecraft:dark_prismarine
fill 164 241 363 167 241 363 minecraft:blue_terracotta
fill 165 241 362 166 241 362 minecraft:blue_terracotta
setblock 167 241 324 minecraft:dark_prismarine
fill 167 241 328 167 243 328 minecraft:iron_bars
setblock 168 241 323 minecraft:dark_prismarine
fill 168 241 324 169 241 324 minecraft:blue_terracotta
setblock 168 241 363 minecraft:dark_prismarine
fill 169 241 323 172 241 323 minecraft:blue_terracotta
fill 169 241 363 172 241 363 minecraft:blue_terracotta
setblock 173 241 323 minecraft:dark_prismarine
setblock 173 241 363 minecraft:dark_prismarine
fill 174 241 323 176 241 324 minecraft:blue_terracotta
setblock 174 241 362 minecraft:dark_prismarine
fill 174 241 363 177 241 363 minecraft:blue_terracotta
fill 175 241 362 178 241 362 minecraft:blue_terracotta
fill 176 241 340 176 248 341 minecraft:magenta_terracotta
setblock 177 241 323 minecraft:blue_terracotta
setblock 177 241 324 minecraft:dark_prismarine
fill 177 241 341 177 250 341 minecraft:magenta_terracotta
setblock 178 241 323 minecraft:dark_prismarine
fill 178 241 324 181 241 324 minecraft:blue_terracotta
fill 178 241 361 179 241 361 minecraft:blue_terracotta
setblock 178 241 363 minecraft:dark_prismarine
setblock 178 241 364 minecraft:cyan_concrete
fill 179 241 323 182 241 323 minecraft:blue_terracotta
setblock 179 241 362 minecraft:dark_prismarine
fill 179 241 363 182 241 363 minecraft:blue_terracotta
fill 179 241 364 179 308 364 minecraft:blue_concrete
fill 180 241 342 180 241 345 minecraft:blue_terracotta
setblock 180 241 346 minecraft:dark_prismarine
fill 180 241 347 180 241 350 minecraft:blue_terracotta
setblock 180 241 351 minecraft:dark_prismarine
setblock 180 241 361 minecraft:dark_prismarine
fill 180 241 362 182 242 362 minecraft:blue_terracotta
setblock 181 241 325 minecraft:dark_prismarine
fill 181 241 326 182 243 326 minecraft:blue_terracotta
setblock 181 241 340 minecraft:dark_prismarine
fill 181 241 341 181 241 344 minecraft:blue_terracotta
setblock 181 241 345 minecraft:dark_prismarine
fill 181 241 346 181 241 349 minecraft:blue_terracotta
setblock 181 241 350 minecraft:dark_prismarine
fill 181 241 351 181 241 354 minecraft:blue_terracotta
setblock 181 241 355 minecraft:dark_prismarine
fill 181 241 356 181 241 359 minecraft:blue_terracotta
setblock 181 241 360 minecraft:dark_prismarine
fill 181 241 361 182 243 361 minecraft:blue_terracotta
setblock 182 241 324 minecraft:dark_prismarine
fill 182 241 325 182 244 325 minecraft:blue_terracotta
fill 182 241 327 182 241 328 minecraft:blue_terracotta
setblock 182 241 329 minecraft:dark_prismarine
fill 182 241 337 182 241 338 minecraft:blue_terracotta
setblock 182 241 339 minecraft:dark_prismarine
fill 182 241 340 182 241 343 minecraft:blue_terracotta
setblock 182 241 344 minecraft:dark_prismarine
fill 182 241 345 182 241 348 minecraft:blue_terracotta
setblock 182 241 349 minecraft:dark_prismarine
fill 182 241 350 182 241 353 minecraft:blue_terracotta
setblock 182 241 354 minecraft:dark_prismarine
fill 182 241 355 182 241 358 minecraft:blue_terracotta
setblock 182 241 359 minecraft:dark_prismarine
fill 182 241 360 182 244 360 minecraft:blue_terracotta
fill 183 241 346 183 308 346 minecraft:blue_concrete
setblock 142 242 323 minecraft:dark_prismarine
fill 142 242 324 142 242 327 minecraft:blue_terracotta
setblock 142 242 328 minecraft:dark_prismarine
fill 142 242 329 142 242 332 minecraft:blue_terracotta
setblock 142 242 333 minecraft:dark_prismarine
fill 142 242 334 142 242 337 minecraft:blue_terracotta
setblock 142 242 338 minecraft:dark_prismarine
fill 142 242 339 142 242 342 minecraft:blue_terracotta
setblock 142 242 343 minecraft:dark_prismarine
fill 142 242 344 142 242 347 minecraft:blue_terracotta
setblock 142 242 348 minecraft:dark_prismarine
fill 142 242 349 142 242 352 minecraft:blue_terracotta
setblock 142 242 353 minecraft:dark_prismarine
fill 142 242 354 142 242 355 minecraft:blue_terracotta
fill 142 242 361 142 242 362 minecraft:blue_terracotta
setblock 142 242 363 minecraft:dark_prismarine
fill 143 242 323 146 242 323 minecraft:blue_terracotta
fill 143 242 339 143 242 341 minecraft:blue_terracotta
setblock 143 242 342 minecraft:dark_prismarine
fill 143 242 343 143 242 346 minecraft:blue_terracotta
setblock 143 242 347 minecraft:dark_prismarine
fill 143 242 348 143 245 348 minecraft:blue_terracotta
setblock 143 242 363 minecraft:blue_terracotta
fill 144 242 342 144 242 345 minecraft:blue_terracotta
setblock 144 242 346 minecraft:dark_prismarine
setblock 144 242 347 minecraft:blue_terracotta
setblock 151 242 323 minecraft:blue_terracotta
setblock 152 242 323 minecraft:dark_prismarine
fill 153 242 323 155 242 324 minecraft:blue_terracotta
setblock 153 242 363 minecraft:purple_concrete
setblock 155 242 325 minecraft:dark_prismarine
fill 155 242 363 156 242 363 minecraft:blue_terracotta
setblock 156 242 323 minecraft:blue_terracotta
setblock 156 242 324 minecraft:dark_prismarine
fill 156 242 325 159 242 325 minecraft:blue_terracotta
setblock 157 242 323 minecraft:dark_prismarine
fill 157 242 324 160 242 324 minecraft:blue_terracotta
setblock 157 242 363 minecraft:dark_prismarine
fill 158 242 323 161 242 323 minecraft:blue_terracotta
setblock 158 242 326 minecraft:blue_terracotta
fill 158 242 363 161 242 363 minecraft:blue_terracotta
setblock 159 242 326 minecraft:dark_prismarine
fill 159 242 362 162 242 362 minecraft:blue_terracotta
setblock 160 242 325 minecraft:dark_prismarine
fill 160 242 326 161 244 326 minecraft:blue_terracotta
setblock 161 242 324 minecraft:dark_prismarine
fill 161 242 325 164 242 325 minecraft:blue_terracotta
setblock 162 242 323 minecraft:dark_prismarine
fill 162 242 324 165 242 324 minecraft:blue_terracotta
setblock 162 242 363 minecraft:dark_prismarine
fill 163 242 323 166 242 323 minecraft:blue_terracotta
setblock 163 242 362 minecraft:dark_prismarine
fill 163 242 363 166 242 363 minecraft:blue_terracotta
setblock 164 242 362 minecraft:blue_terracotta
setblock 165 242 325 minecraft:dark_prismarine
setblock 166 242 324 minecraft:dark_prismarine
setblock 167 242 323 minecraft:dark_prismarine
fill 167 242 324 168 242 324 minecraft:blue_terracotta
setblock 167 242 363 minecraft:dark_prismarine
fill 168 242 323 171 242 323 minecraft:blue_terracotta
fill 168 242 363 171 242 363 minecraft:blue_terracotta
setblock 172 242 323 minecraft:dark_prismarine
setblock 172 242 363 minecraft:dark_prismarine
fill 173 242 323 176 242 323 minecraft:blue_terracotta
fill 173 242 363 176 242 363 minecraft:blue_terracotta
setblock 175 242 324 minecraft:blue_terracotta
fill 175 242 362 177 242 362 minecraft:blue_terracotta
setblock 176 242 324 minecraft:dark_prismarine
setblock 177 242 323 minecraft:dark_prismarine
fill 177 242 324 180 242 324 minecraft:blue_terracotta
setblock 177 242 363 minecraft:dark_prismarine
fill 178 242 323 181 242 323 minecraft:blue_terracotta
setblock 178 242 362 minecraft:dark_prismarine
fill 178 242 363 181 242 363 minecraft:blue_terracotta
fill 178 242 364 178 292 364 minecraft:blue_concrete
fill 179 242 362 179 245 362 minecraft:blue_terracotta
fill 180 242 343 180 242 344 minecraft:blue_terracotta
setblock 180 242 345 minecraft:dark_prismarine
fill 180 242 346 180 242 349 minecraft:blue_terracotta
setblock 180 242 350 minecraft:dark_prismarine
fill 180 242 351 182 243 351 minecraft:blue_terracotta
setblock 181 242 324 minecraft:dark_prismarine
fill 181 242 325 181 244 325 minecraft:blue_terracotta
fill 181 242 341 181 242 343 minecraft:blue_terracotta
setblock 181 242 344 minecraft:dark_prismarine
fill 181 242 345 181 242 348 minecraft:blue_terracotta
setblock 181 242 349 minecraft:dark_prismarine
fill 181 242 350 182 244 350 minecraft:blue_terracotta
fill 181 242 352 181 242 353 minecraft:blue_terracotta
setblock 181 242 354 minecraft:dark_prismarine
fill 181 242 355 181 242 358 minecraft:blue_terracotta
setblock 181 242 359 minecraft:dark_prismarine
setblock 181 242 360 minecraft:blue_terracotta
setblock 182 242 323 minecraft:dark_prismarine
fill 182 242 324 182 245 324 minecraft:blue_terracotta
setblock 182 242 327 minecraft:blue_terracotta
setblock 182 242 328 minecraft:dark_prismarine
fill 182 242 329 182 245 329 minecraft:blue_terracotta
setblock 182 242 331 minecraft:purple_concrete
setblock 182 242 338 minecraft:dark_prismarine
fill 182 242 339 182 242 342 minecraft:blue_terracotta
setblock 182 242 343 minecraft:dark_prismarine
fill 182 242 344 182 242 347 minecraft:blue_terracotta
setblock 182 242 348 minecraft:dark_prismarine
fill 182 242 349 182 245 349 minecraft:blue_terracotta
setblock 182 242 352 minecraft:blue_terracotta
setblock 182 242 353 minecraft:dark_prismarine
fill 182 242 354 182 242 357 minecraft:blue_terracotta
setblock 182 242 358 minecraft:dark_prismarine
fill 182 242 359 182 245 359 minecraft:blue_terracotta
setblock 182 242 363 minecraft:dark_prismarine
fill 142 243 323 142 243 326 minecraft:blue_terracotta
setblock 142 243 327 minecraft:dark_prismarine
fill 142 243 328 142 243 331 minecraft:blue_terracotta
setblock 142 243 332 minecraft:dark_prismarine
fill 142 243 333 142 243 336 minecraft:blue_terracotta
setblock 142 243 337 minecraft:dark_prismarine
fill 142 243 338 142 243 341 minecraft:blue_terracotta
setblock 142 243 342 minecraft:dark_prismarine
fill 142 243 343 142 243 346 minecraft:blue_terracotta
setblock 142 243 347 minecraft:dark_prismarine
fill 142 243 348 142 243 351 minecraft:blue_terracotta
setblock 142 243 352 minecraft:dark_prismarine
fill 142 243 353 142 245 354 minecraft:blue_terracotta
setblock 142 243 361 minecraft:purple_concrete
fill 143 243 323 145 243 323 minecraft:blue_terracotta
setblock 143 243 340 minecraft:blue_terracotta
setblock 143 243 341 minecraft:dark_prismarine
fill 143 243 342 143 243 345 minecraft:blue_terracotta
setblock 143 243 346 minecraft:dark_prismarine
fill 143 243 347 143 246 347 minecraft:blue_terracotta
fill 143 243 349 143 243 350 minecraft:blue_terracotta
setblock 143 243 351 minecraft:dark_prismarine
setblock 144 243 345 minecraft:dark_prismarine
setblock 144 243 346 minecraft:blue_terracotta
fill 148 243 344 148 262 344 minecraft:magenta_terracotta
setblock 151 243 323 minecraft:dark_prismarine
fill 152 243 323 155 243 323 minecraft:blue_terracotta
fill 153 243 324 154 243 324 minecraft:blue_terracotta
setblock 155 243 324 minecraft:dark_prismarine
fill 155 243 325 158 243 325 minecraft:blue_terracotta
fill 155 243 330 156 244 330 minecraft:magenta_terracotta
setblock 155 243 363 minecraft:blue_terracotta
setblock 156 243 323 minecraft:dark_prismarine
fill 156 243 324 159 243 324 minecraft:blue_terracotta
setblock 156 243 363 minecraft:dark_prismarine
fill 157 243 323 160 243 323 minecraft:blue_terracotta
fill 157 243 363 160 243 363 minecraft:blue_terracotta
setblock 158 243 326 minecraft:dark_prismarine
setblock 159 243 325 minecraft:dark_prismarine
fill 159 243 326 159 246 326 minecraft:blue_terracotta
setblock 160 243 324 minecraft:dark_prismarine
fill 160 243 325 163 243 325 minecraft:blue_terracotta
fill 160 243 362 161 243 362 minecraft:blue_terracotta
setblock 161 243 323 minecraft:dark_prismarine
fill 161 243 324 164 243 324 minecraft:blue_terracotta
setblock 161 243 363 minecraft:dark_prismarine
fill 162 243 323 165 243 323 minecraft:blue_terracotta
fill 162 243 363 165 243 363 minecraft:blue_terracotta
setblock 164 243 325 minecraft:dark_prismarine
setblock 165 243 324 minecraft:dark_prismarine
setblock 166 243 323 minecraft:dark_prismarine
fill 166 243 324 167 243 324 minecraft:blue_terracotta
setblock 166 243 363 minecraft:dark_prismarine
fill 167 243 323 170 243 323 minecraft:blue_terracotta
fill 167 243 363 170 243 363 minecraft:blue_terracotta
fill 169 243 356 169 249 357 minecraft:magenta_terracotta
fill 170 243 357 170 255 357 minecraft:magenta_terracotta
setblock 171 243 323 minecraft:dark_prismarine
setblock 171 243 363 minecraft:dark_prismarine
fill 172 243 323 175 243 323 minecraft:blue_terracotta
fill 172 243 363 175 243 363 minecraft:blue_terracotta
setblock 175 243 324 minecraft:dark_prismarine
fill 175 243 362 176 243 362 minecraft:blue_terracotta
setblock 176 243 323 minecraft:dark_prismarine
fill 176 243 324 179 243 324 minecraft:blue_terracotta
fill 176 243 330 178 243 331 minecraft:dark_prismarine
setblock 176 243 363 minecraft:dark_prismarine
fill 177 243 323 180 243 323 minecraft:blue_terracotta
fill 177 243 329 178 245 329 minecraft:dark_prismarine
setblock 177 243 362 minecraft:dark_prismarine
fill 177 243 363 180 243 363 minecraft:blue_terracotta
fill 178 243 362 178 246 362 minecraft:blue_terracotta
setblock 180 243 324 minecraft:dark_prismarine
setblock 180 243 344 minecraft:dark_prismarine
fill 180 243 345 180 243 348 minecraft:blue_terracotta
setblock 180 243 349 minecraft:dark_prismarine
fill 180 243 350 180 246 350 minecraft:blue_terracotta
fill 180 243 352 181 243 352 minecraft:blue_terracotta
fill 180 243 362 181 243 362 minecraft:blue_terracotta
setblock 181 243 323 minecraft:dark_prismarine
setblock 181 243 324 minecraft:blue_terracotta
fill 181 243 341 181 243 342 minecraft:blue_terracotta
setblock 181 243 343 minecraft:dark_prismarine
fill 181 243 344 181 243 347 minecraft:blue_terracotta
setblock 181 243 348 minecraft:dark_prismarine
fill 181 243 349 181 246 349 minecraft:blue_terracotta
setblock 181 243 353 minecraft:dark_prismarine
fill 181 243 354 182 244 355 minecraft:blue_terracotta
setblock 181 243 363 minecraft:dark_prismarine
fill 182 243 323 182 246 323 minecraft:blue_terracotta
setblock 182 243 327 minecraft:dark_prismarine
fill 182 243 328 182 246 328 minecraft:blue_terracotta
fill 182 243 339 182 243 341 minecraft:blue_terracotta
setblock 182 243 342 minecraft:dark_prismarine
fill 182 243 343 182 243 346 minecraft:blue_terracotta
setblock 182 243 347 minecraft:dark_prismarine
fill 182 243 348 182 246 348 minecraft:blue_terracotta
setblock 182 243 352 minecraft:dark_prismarine
fill 182 243 353 182 246 353 minecraft:blue_terracotta
setblock 182 243 356 minecraft:blue_terracotta
setblock 182 243 357 minecraft:dark_prismarine
fill 182 243 358 182 246 358 minecraft:blue_terracotta
setblock 182 243 362 minecraft:dark_prismarine
fill 182 243 363 182 245 363 minecraft:blue_terracotta
fill 142 244 323 142 244 325 minecraft:blue_terracotta
setblock 142 244 326 minecraft:dark_prismarine
fill 142 244 327 142 244 330 minecraft:blue_terracotta
setblock 142 244 331 minecraft:dark_prismarine
fill 142 244 332 142 244 335 minecraft:blue_terracotta
setblock 142 244 336 minecraft:dark_prismarine
fill 142 244 337 142 244 340 minecraft:blue_terracotta
setblock 142 244 341 minecraft:dark_prismarine
fill 142 244 342 142 244 345 minecraft:blue_terracotta
setblock 142 244 346 minecraft:dark_prismarine
fill 142 244 347 142 244 350 minecraft:blue_terracotta
setblock 142 244 351 minecraft:dark_prismarine
fill 142 244 352 142 247 352 minecraft:blue_terracotta
fill 143 244 323 144 244 323 minecraft:blue_terracotta
fill 143 244 341 143 244 344 minecraft:blue_terracotta
setblock 143 244 345 minecraft:dark_prismarine
fill 143 244 346 143 247 346 minecraft:blue_terracotta
setblock 143 244 349 minecraft:blue_terracotta
setblock 143 244 350 minecraft:dark_prismarine
fill 143 244 351 143 247 351 minecraft:blue_terracotta
setblock 146 244 363 minecraft:purple_concrete
setblock 150 244 323 minecraft:dark_prismarine
fill 151 244 323 154 244 323 minecraft:blue_terracotta
fill 152 244 324 153 244 324 minecraft:blue_terracotta
setblock 154 244 324 minecraft:dark_prismarine
fill 154 244 325 157 244 325 minecraft:blue_terracotta
setblock 155 244 323 minecraft:dark_prismarine
fill 155 244 324 158 244 324 minecraft:blue_terracotta
setblock 155 244 363 minecraft:dark_prismarine
fill 156 244 323 159 244 323 minecraft:blue_terracotta
fill 156 244 329 156 262 329 minecraft:magenta_terracotta
fill 156 244 363 159 244 363 minecraft:blue_terracotta
setblock 157 244 326 minecraft:dark_prismarine
setblock 158 244 325 minecraft:dark_prismarine
fill 158 244 326 158 247 326 minecraft:blue_terracotta
setblock 159 244 324 minecraft:dark_prismarine
fill 159 244 325 162 244 325 minecraft:blue_terracotta
setblock 160 244 323 minecraft:dark_prismarine
fill 160 244 324 163 244 324 minecraft:blue_terracotta
setblock 160 244 363 minecraft:dark_prismarine
fill 161 244 323 164 244 323 minecraft:blue_terracotta
fill 161 244 363 164 244 363 minecraft:blue_terracotta
setblock 163 244 325 minecraft:dark_prismarine
setblock 164 244 324 minecraft:dark_prismarine
setblock 165 244 323 minecraft:dark_prismarine
fill 165 244 324 166 245 324 minecraft:blue_terracotta
setblock 165 244 363 minecraft:dark_prismarine
fill 166 244 323 169 244 323 minecraft:blue_terracotta
fill 166 244 363 167 244 363 minecraft:blue_terracotta
setblock 170 244 323 minecraft:dark_prismarine
setblock 170 244 363 minecraft:dark_prismarine
fill 171 244 323 174 244 323 minecraft:blue_terracotta
fill 171 244 363 174 244 363 minecraft:blue_terracotta
setblock 175 244 323 minecraft:dark_prismarine
fill 175 244 324 178 244 324 minecraft:blue_terracotta
fill 175 244 330 175 245 330 minecraft:black_concrete
setblock 175 244 362 minecraft:blue_terracotta
setblock 175 244 363 minecraft:dark_prismarine
fill 176 244 323 179 244 323 minecraft:blue_terracotta
fill 176 244 329 176 245 329 minecraft:black_concrete
fill 176 244 330 176 245 331 minecraft:dark_prismarine
fill 176 244 332 178 245 332 minecraft:black_concrete
setblock 176 244 362 minecraft:dark_prismarine
fill 176 244 363 179 244 363 minecraft:blue_terracotta
fill 177 244 328 177 245 328 minecraft:black_concrete
fill 177 244 330 177 249 330 minecraft:purple_concrete
fill 177 244 331 178 245 331 minecraft:dark_prismarine
fill 177 244 362 177 247 362 minecraft:blue_terracotta
fill 178 244 330 178 246 330 minecraft:dark_prismarine
setblock 179 244 324 minecraft:dark_prismarine
fill 179 244 329 179 245 331 minecraft:black_concrete
setblock 180 244 323 minecraft:dark_prismarine
fill 180 244 324 180 245 324 minecraft:blue_terracotta
fill 180 244 344 180 244 347 minecraft:blue_terracotta
setblock 180 244 348 minecraft:dark_prismarine
fill 180 244 349 180 247 349 minecraft:blue_terracotta
fill 180 244 351 180 244 352 minecraft:blue_terracotta
setblock 180 244 353 minecraft:dark_prismarine
setblock 180 244 362 minecraft:blue_terracotta
setblock 180 244 363 minecraft:dark_prismarine
fill 181 244 323 181 247 323 minecraft:blue_terracotta
setblock 181 244 342 minecraft:dark_prismarine
fill 181 244 343 181 244 346 minecraft:blue_terracotta
setblock 181 244 347 minecraft:dark_prismarine
fill 181 244 348 181 247 348 minecraft:blue_terracotta
setblock 181 244 351 minecraft:blue_terracotta
setblock 181 244 352 minecraft:dark_prismarine
fill 181 244 353 181 247 353 minecraft:blue_terracotta
fill 181 244 363 181 247 363 minecraft:blue_terracotta
setblock 182 244 326 minecraft:dark_prismarine
fill 182 244 327 182 247 327 minecraft:blue_terracotta
fill 182 244 338 182 245 338 minecraft:purple_concrete
setblock 182 244 340 minecraft:blue_terracotta
setblock 182 244 341 minecraft:dark_prismarine
fill 182 244 342 182 244 345 minecraft:blue_terracotta
setblock 182 244 346 minecraft:dark_prismarine
fill 182 244 347 182 247 347 minecraft:blue_terracotta
setblock 182 244 351 minecraft:dark_prismarine
fill 182 244 352 182 247 352 minecraft:blue_terracotta
setblock 182 244 356 minecraft:dark_prismarine
fill 182 244 357 182 247 357 minecraft:blue_terracotta
setblock 182 244 361 minecraft:dark_prismarine
fill 182 244 362 182 245 362 minecraft:blue_terracotta
fill 183 244 359 183 308 359 minecraft:blue_concrete
setblock 183 244 360 minecraft:light_blue_wool
fill 183 244 361 183 308 363 minecraft:blue_concrete
fill 142 245 323 142 245 324 minecraft:blue_terracotta
setblock 142 245 325 minecraft:dark_prismarine
fill 142 245 326 142 245 329 minecraft:blue_terracotta
setblock 142 245 330 minecraft:dark_prismarine
fill 142 245 331 142 245 334 minecraft:blue_terracotta
setblock 142 245 335 minecraft:dark_prismarine
fill 142 245 336 142 245 339 minecraft:blue_terracotta
setblock 142 245 340 minecraft:dark_prismarine
fill 142 245 341 142 245 344 minecraft:blue_terracotta
setblock 142 245 345 minecraft:dark_prismarine
fill 142 245 346 142 245 349 minecraft:blue_terracotta
setblock 142 245 350 minecraft:dark_prismarine
fill 142 245 351 142 248 351 minecraft:blue_terracotta
setblock 143 245 323 minecraft:blue_terracotta
fill 143 245 342 143 245 343 minecraft:blue_terracotta
setblock 143 245 344 minecraft:dark_prismarine
fill 143 245 345 143 248 345 minecraft:blue_terracotta
setblock 143 245 349 minecraft:dark_prismarine
fill 143 245 350 143 248 350 minecraft:blue_terracotta
setblock 144 245 325 minecraft:light[level=13]
setblock 144 245 332 minecraft:light[level=12]
setblock 144 245 333 minecraft:light[level=13]
setblock 144 245 339 minecraft:light[level=12]
setblock 144 245 341 minecraft:light[level=13]
setblock 144 245 346 minecraft:light[level=12]
setblock 144 245 349 minecraft:light[level=13]
setblock 144 245 353 minecraft:light[level=12]
setblock 144 245 357 minecraft:light[level=13]
setblock 144 245 360 minecraft:light[level=12]
fill 146 245 331 146 253 331 minecraft:green_terracotta
setblock 147 245 323 minecraft:purple_concrete
fill 150 245 323 153 245 323 minecraft:blue_terracotta
setblock 151 245 325 minecraft:light[level=12]
setblock 151 245 332 minecraft:light[level=12]
setblock 151 245 339 minecraft:light[level=12]
setblock 151 245 346 minecraft:light[level=12]
setblock 151 245 353 minecraft:light[level=12]
setblock 151 245 360 minecraft:light[level=12]
setblock 152 245 324 minecraft:blue_terracotta
setblock 152 245 325 minecraft:light[level=13]
setblock 152 245 333 minecraft:light[level=13]
setblock 152 245 341 minecraft:light[level=13]
setblock 152 245 349 minecraft:light[level=13]
setblock 152 245 357 minecraft:light[level=13]
setblock 152 245 363 minecraft:purple_concrete
setblock 153 245 324 minecraft:dark_prismarine
setblock 154 245 323 minecraft:dark_prismarine
fill 154 245 324 156 245 325 minecraft:blue_terracotta
fill 154 245 329 154 246 329 minecraft:magenta_terracotta
fill 155 245 323 158 245 323 minecraft:blue_terracotta
fill 155 245 330 155 253 330 minecraft:magenta_terracotta
fill 155 245 363 158 245 363 minecraft:blue_terracotta
setblock 156 245 326 minecraft:dark_prismarine
setblock 157 245 324 minecraft:blue_terracotta
setblock 157 245 325 minecraft:dark_prismarine
fill 157 245 326 157 248 326 minecraft:blue_terracotta
setblock 158 245 324 minecraft:dark_prismarine
fill 158 245 325 161 245 325 minecraft:blue_terracotta
setblock 158 245 332 minecraft:light[level=12]
setblock 158 245 346 minecraft:light[level=12]
setblock 158 245 353 minecraft:light[level=12]
setblock 158 245 360 minecraft:light[level=12]
setblock 159 245 323 minecraft:dark_prismarine
fill 159 245 324 162 245 324 minecraft:blue_terracotta
setblock 159 245 363 minecraft:dark_prismarine
fill 160 245 323 163 245 323 minecraft:blue_terracotta
setblock 160 245 326 minecraft:blue_terracotta
setblock 160 245 333 minecraft:light[level=13]
setblock 160 245 349 minecraft:light[level=13]
setblock 160 245 357 minecraft:light[level=13]
fill 160 245 363 163 245 363 minecraft:blue_terracotta
setblock 162 245 325 minecraft:dark_prismarine
setblock 163 245 324 minecraft:dark_prismarine
fill 163 245 325 163 246 325 minecraft:blue_terracotta
setblock 164 245 323 minecraft:dark_prismarine
fill 164 245 324 164 248 324 minecraft:blue_terracotta
setblock 164 245 363 minecraft:dark_prismarine
fill 165 245 323 168 245 323 minecraft:blue_terracotta
setblock 165 245 325 minecraft:light[level=12]
setblock 165 245 332 minecraft:light[level=12]
setblock 165 245 339 minecraft:light[level=12]
setblock 165 245 346 minecraft:light[level=12]
setblock 165 245 353 minecraft:light[level=12]
setblock 165 245 360 minecraft:light[level=12]
fill 165 245 363 166 245 363 minecraft:blue_terracotta
setblock 168 245 325 minecraft:light[level=13]
setblock 168 245 333 minecraft:light[level=13]
setblock 168 245 341 minecraft:light[level=13]
setblock 168 245 349 minecraft:light[level=13]
fill 168 245 357 168 247 357 minecraft:magenta_terracotta
setblock 169 245 323 minecraft:dark_prismarine
fill 170 245 323 173 245 323 minecraft:blue_terracotta
fill 170 245 363 173 245 363 minecraft:blue_terracotta
setblock 172 245 325 minecraft:light[level=12]
setblock 172 245 332 minecraft:light[level=12]
setblock 172 245 346 minecraft:light[level=12]
setblock 172 245 353 minecraft:light[level=12]
setblock 172 245 360 minecraft:light[level=12]
setblock 174 245 323 minecraft:dark_prismarine
fill 174 245 324 177 245 324 minecraft:blue_terracotta
setblock 174 245 363 minecraft:dark_prismarine
fill 175 245 323 178 245 323 minecraft:blue_terracotta
setblock 175 245 329 minecraft:black_concrete
setblock 175 245 331 minecraft:black_concrete
setblock 175 245 362 minecraft:dark_prismarine
fill 175 245 363 178 245 363 minecraft:blue_terracotta
setblock 176 245 325 minecraft:light[level=13]
setblock 176 245 328 minecraft:black_concrete
setblock 176 245 333 minecraft:light[level=13]
setblock 176 245 349 minecraft:light[level=13]
setblock 176 245 357 minecraft:light[level=13]
fill 176 245 362 176 248 362 minecraft:blue_terracotta
setblock 178 245 324 minecraft:dark_prismarine
setblock 178 245 328 minecraft:black_concrete
setblock 179 245 323 minecraft:dark_prismarine
fill 179 245 324 179 248 324 minecraft:blue_terracotta
setblock 179 245 325 minecraft:light[level=12]
setblock 179 245 332 minecraft:black_concrete
setblock 179 245 339 minecraft:light[level=12]
setblock 179 245 346 minecraft:light[level=12]
setblock 179 245 347 minecraft:blue_terracotta
setblock 179 245 348 minecraft:dark_prismarine
fill 179 245 349 179 247 350 minecraft:blue_terracotta
setblock 179 245 353 minecraft:light[level=12]
setblock 179 245 360 minecraft:light[level=12]
setblock 179 245 363 minecraft:dark_prismarine
fill 180 245 323 180 248 323 minecraft:blue_terracotta
fill 180 245 344 180 245 346 minecraft:blue_terracotta
setblock 180 245 347 minecraft:dark_prismarine
fill 180 245 348 180 248 348 minecraft:blue_terracotta
setblock 180 245 351 minecraft:blue_terracotta
setblock 180 245 352 minecraft:dark_prismarine
fill 180 245 353 180 248 353 minecraft:blue_terracotta
fill 180 245 363 180 248 363 minecraft:blue_terracotta
fill 181 245 342 181 245 345 minecraft:blue_terracotta
setblock 181 245 346 minecraft:dark_prismarine
fill 181 245 347 181 248 347 minecraft:blue_terracotta
setblock 181 245 350 minecraft:blue_terracotta
setblock 181 245 351 minecraft:dark_prismarine
fill 181 245 352 181 248 352 minecraft:blue_terracotta
fill 181 245 354 181 245 355 minecraft:blue_terracotta
setblock 182 245 325 minecraft:dark_prismarine
fill 182 245 326 182 248 326 minecraft:blue_terracotta
setblock 182 245 330 minecraft:dark_prismarine
setblock 182 245 332 minecraft:purple_concrete
setblock 182 245 340 minecraft:dark_prismarine
fill 182 245 341 182 245 344 minecraft:blue_terracotta
setblock 182 245 345 minecraft:dark_prismarine
fill 182 245 346 182 248 346 minecraft:blue_terracotta
setblock 182 245 350 minecraft:dark_prismarine
fill 182 245 351 182 248 351 minecraft:blue_terracotta
setblock 182 245 354 minecraft:blue_terracotta
setblock 182 245 355 minecraft:dark_prismarine
fill 182 245 356 182 248 356 minecraft:blue_terracotta
setblock 182 245 361 minecraft:blue_terracotta
fill 183 245 360 183 308 360 minecraft:blue_concrete
setblock 142 246 323 minecraft:blue_terracotta
setblock 142 246 324 minecraft:dark_prismarine
fill 142 246 325 142 246 328 minecraft:blue_terracotta
setblock 142 246 329 minecraft:dark_prismarine
fill 142 246 330 142 246 333 minecraft:blue_terracotta
setblock 142 246 334 minecraft:dark_prismarine
fill 142 246 335 142 246 338 minecraft:blue_terracotta
setblock 142 246 339 minecraft:dark_prismarine
fill 142 246 340 142 246 343 minecraft:blue_terracotta
setblock 142 246 344 minecraft:dark_prismarine
fill 142 246 345 142 246 348 minecraft:blue_terracotta
setblock 142 246 349 minecraft:dark_prismarine
fill 142 246 350 142 249 350 minecraft:blue_terracotta
setblock 142 246 353 minecraft:blue_terracotta
setblock 142 246 354 minecraft:dark_prismarine
fill 142 246 360 142 247 360 minecraft:purple_concrete
setblock 143 246 327 minecraft:blue_terracotta
setblock 143 246 328 minecraft:dark_prismarine
fill 143 246 329 143 248 330 minecraft:blue_terracotta
setblock 143 246 343 minecraft:dark_prismarine
fill 143 246 344 143 247 344 minecraft:blue_terracotta
setblock 143 246 348 minecraft:dark_prismarine
fill 143 246 349 143 249 349 minecraft:blue_terracotta
fill 149 246 323 152 246 323 minecraft:blue_terracotta
setblock 151 246 324 minecraft:blue_terracotta
setblock 152 246 324 minecraft:dark_prismarine
setblock 153 246 323 minecraft:dark_prismarine
fill 153 246 324 155 246 325 minecraft:blue_terracotta
fill 154 246 323 157 246 323 minecraft:blue_terracotta
setblock 155 246 326 minecraft:dark_prismarine
fill 155 246 363 157 246 363 minecraft:blue_terracotta
setblock 156 246 324 minecraft:blue_terracotta
setblock 156 246 325 minecraft:dark_prismarine
fill 156 246 326 156 249 326 minecraft:blue_terracotta
setblock 157 246 324 minecraft:dark_prismarine
fill 157 246 325 160 246 325 minecraft:blue_terracotta
setblock 158 246 323 minecraft:dark_prismarine
fill 158 246 324 161 246 324 minecraft:blue_terracotta
setblock 158 246 363 minecraft:dark_prismarine
fill 159 246 323 162 246 323 minecraft:blue_terracotta
fill 159 246 363 162 246 363 minecraft:blue_terracotta
setblock 160 246 326 minecraft:dark_prismarine
setblock 161 246 325 minecraft:dark_prismarine
setblock 162 246 324 minecraft:dark_prismarine
fill 162 246 325 162 248 325 minecraft:blue_terracotta
setblock 163 246 323 minecraft:dark_prismarine
fill 163 246 324 163 249 324 minecraft:blue_terracotta
setblock 163 246 363 minecraft:dark_prismarine
fill 164 246 323 167 246 323 minecraft:blue_terracotta
fill 164 246 363 165 248 363 minecraft:blue_terracotta
fill 164 246 364 165 308 364 minecraft:blue_concrete
fill 165 246 324 165 247 324 minecraft:blue_terracotta
setblock 166 246 364 minecraft:cyan_concrete
fill 167 246 364 167 308 364 minecraft:blue_concrete
setblock 168 246 323 minecraft:dark_prismarine
fill 169 246 323 172 246 323 minecraft:blue_terracotta
fill 170 246 363 172 246 363 minecraft:blue_terracotta
setblock 173 246 323 minecraft:dark_prismarine
setblock 173 246 363 minecraft:dark_prismarine
fill 174 246 323 176 246 324 minecraft:blue_terracotta
fill 174 246 363 177 246 363 minecraft:blue_terracotta
fill 175 246 362 175 249 362 minecraft:blue_terracotta
fill 176 246 330 176 249 330 minecraft:purple_concrete
setblock 176 246 331 minecraft:dark_prismarine
fill 176 246 342 176 251 342 minecraft:magenta_terracotta
setblock 177 246 323 minecraft:blue_terracotta
setblock 177 246 324 minecraft:dark_prismarine
fill 177 246 329 177 249 329 minecraft:purple_concrete
fill 177 246 331 177 249 331 minecraft:purple_concrete
setblock 178 246 323 minecraft:dark_prismarine
fill 178 246 324 178 249 324 minecraft:blue_terracotta
setblock 178 246 329 minecraft:dark_prismarine
setblock 178 246 331 minecraft:dark_prismarine
setblock 178 246 363 minecraft:dark_prismarine
fill 179 246 323 179 249 323 minecraft:blue_terracotta
setblock 179 246 347 minecraft:dark_prismarine
fill 179 246 348 179 249 348 minecraft:blue_terracotta
setblock 179 246 351 minecraft:blue_terracotta
setblock 179 246 352 minecraft:dark_prismarine
fill 179 246 363 179 249 363 minecraft:blue_terracotta
fill 180 246 344 180 246 345 minecraft:blue_terracotta
setblock 180 246 346 minecraft:dark_prismarine
fill 180 246 347 180 249 347 minecraft:blue_terracotta
setblock 180 246 351 minecraft:dark_prismarine
fill 180 246 352 180 249 352 minecraft:blue_terracotta
fill 180 246 354 181 246 354 minecraft:blue_terracotta
fill 181 246 342 181 246 344 minecraft:blue_terracotta
setblock 181 246 345 minecraft:dark_prismarine
fill 181 246 346 181 249 346 minecraft:blue_terracotta
setblock 181 246 350 minecraft:dark_prismarine
fill 181 246 351 181 249 351 minecraft:blue_terracotta
setblock 181 246 355 minecraft:dark_prismarine
fill 181 246 356 181 249 356 minecraft:blue_terracotta
setblock 182 246 324 minecraft:dark_prismarine
fill 182 246 325 182 249 325 minecraft:blue_terracotta
setblock 182 246 329 minecraft:dark_prismarine
fill 182 246 330 182 248 331 minecraft:blue_terracotta
fill 182 246 340 182 246 343 minecraft:blue_terracotta
setblock 182 246 344 minecraft:dark_prismarine
fill 182 246 345 182 249 345 minecraft:blue_terracotta
setblock 182 246 349 minecraft:dark_prismarine
fill 182 246 350 182 249 350 minecraft:blue_terracotta
setblock 182 246 354 minecraft:dark_prismarine
fill 182 246 355 182 249 355 minecraft:blue_terracotta
setblock 142 247 323 minecraft:dark_prismarine
fill 142 247 324 142 247 327 minecraft:blue_terracotta
setblock 142 247 328 minecraft:dark_prismarine
fill 142 247 329 142 247 332 minecraft:blue_terracotta
setblock 142 247 333 minecraft:dark_prismarine
fill 142 247 334 142 247 337 minecraft:blue_terracotta
setblock 142 247 338 minecraft:dark_prismarine
fill 142 247 339 142 247 342 minecraft:blue_terracotta
setblock 142 247 343 minecraft:dark_prismarine
fill 142 247 344 142 247 347 minecraft:blue_terracotta
setblock 142 247 348 minecraft:dark_prismarine
fill 142 247 349 142 250 349 minecraft:blue_terracotta
setblock 142 247 353 minecraft:dark_prismarine
fill 142 247 354 142 249 355 minecraft:blue_terracotta
setblock 143 247 327 minecraft:dark_prismarine
fill 143 247 328 143 250 328 minecraft:blue_terracotta
setblock 143 247 331 minecraft:blue_terracotta
setblock 143 247 332 minecraft:dark_prismarine
setblock 143 247 347 minecraft:dark_prismarine
fill 143 247 348 143 250 348 minecraft:blue_terracotta
setblock 145 247 363 minecraft:purple_concrete
fill 148 247 345 148 255 345 minecraft:magenta_terracotta
fill 149 247 323 151 247 323 minecraft:blue_terracotta
setblock 150 247 324 minecraft:blue_terracotta
setblock 151 247 324 minecraft:dark_prismarine
setblock 152 247 323 minecraft:dark_prismarine
fill 152 247 324 154 247 325 minecraft:blue_terracotta
fill 153 247 323 156 247 323 minecraft:blue_terracotta
setblock 154 247 326 minecraft:dark_prismarine
fill 154 247 363 156 247 363 minecraft:blue_terracotta
setblock 155 247 324 minecraft:blue_terracotta
setblock 155 247 325 minecraft:dark_prismarine
fill 155 247 326 155 250 326 minecraft:blue_terracotta
setblock 156 247 324 minecraft:dark_prismarine
fill 156 247 325 159 247 325 minecraft:blue_terracotta
setblock 157 247 323 minecraft:dark_prismarine
fill 157 247 324 160 247 324 minecraft:blue_terracotta
setblock 157 247 363 minecraft:dark_prismarine
fill 158 247 323 161 247 323 minecraft:blue_terracotta
fill 158 247 363 161 247 363 minecraft:blue_terracotta
setblock 159 247 326 minecraft:dark_prismarine
setblock 160 247 325 minecraft:dark_prismarine
fill 160 247 326 160 248 326 minecraft:blue_terracotta
setblock 161 247 324 minecraft:dark_prismarine
fill 161 247 325 161 250 325 minecraft:blue_terracotta
setblock 162 247 323 minecraft:dark_prismarine
fill 162 247 324 162 250 324 minecraft:blue_terracotta
setblock 162 247 363 minecraft:dark_prismarine
fill 163 247 323 166 247 323 minecraft:blue_terracotta
fill 163 247 363 163 250 363 minecraft:blue_terracotta
fill 166 247 364 166 308 364 minecraft:blue_concrete
setblock 167 247 323 minecraft:dark_prismarine
fill 168 247 323 171 247 323 minecraft:blue_terracotta
fill 169 247 358 169 262 358 minecraft:magenta_terracotta
fill 169 247 363 171 247 363 minecraft:blue_terracotta
setblock 172 247 323 minecraft:dark_prismarine
setblock 172 247 363 minecraft:dark_prismarine
fill 173 247 323 175 247 324 minecraft:blue_terracotta
fill 173 247 363 176 247 363 minecraft:blue_terracotta
fill 174 247 362 174 250 362 minecraft:blue_terracotta
fill 175 247 332 177 247 334 minecraft:dark_prismarine
setblock 176 247 323 minecraft:blue_terracotta
setblock 176 247 324 minecraft:dark_prismarine
fill 176 247 329 176 249 329 minecraft:purple_concrete
fill 176 247 331 176 249 331 minecraft:purple_concrete
setblock 177 247 323 minecraft:dark_prismarine
fill 177 247 324 177 250 324 minecraft:blue_terracotta
setblock 177 247 363 minecraft:dark_prismarine
fill 178 247 323 178 250 323 minecraft:blue_terracotta
fill 178 247 329 178 249 331 minecraft:purple_concrete
fill 178 247 333 178 272 333 minecraft:dark_prismarine
setblock 178 247 362 minecraft:dark_prismarine
fill 178 247 363 178 250 363 minecraft:blue_terracotta
fill 179 247 347 179 250 347 minecraft:blue_terracotta
setblock 179 247 351 minecraft:dark_prismarine
fill 179 247 352 179 249 353 minecraft:blue_terracotta
setblock 180 247 344 minecraft:blue_terracotta
setblock 180 247 345 minecraft:dark_prismarine
fill 180 247 346 180 250 346 minecraft:blue_terracotta
setblock 180 247 350 minecraft:dark_prismarine
fill 180 247 351 180 250 351 minecraft:blue_terracotta
setblock 180 247 354 minecraft:blue_terracotta
setblock 180 247 355 minecraft:dark_prismarine
fill 181 247 327 181 247 328 minecraft:blue_terracotta
setblock 181 247 329 minecraft:dark_prismarine
fill 181 247 342 181 247 343 minecraft:blue_terracotta
setblock 181 247 344 minecraft:dark_prismarine
fill 181 247 345 181 250 345 minecraft:blue_terracotta
setblock 181 247 349 minecraft:dark_prismarine
fill 181 247 350 181 250 350 minecraft:blue_terracotta
setblock 181 247 354 minecraft:dark_prismarine
fill 181 247 355 181 250 355 minecraft:blue_terracotta
fill 182 247 324 182 248 324 minecraft:blue_terracotta
setblock 182 247 328 minecraft:dark_prismarine
fill 182 247 329 182 250 329 minecraft:blue_terracotta
setblock 182 247 332 minecraft:blue_terracotta
setblock 182 247 333 minecraft:dark_prismarine
fill 182 247 340 182 247 342 minecraft:blue_terracotta
setblock 182 247 343 minecraft:dark_prismarine
fill 182 247 344 182 250 344 minecraft:blue_terracotta
setblock 182 247 348 minecraft:dark_prismarine
fill 182 247 349 182 250 349 minecraft:blue_terracotta
setblock 182 247 353 minecraft:dark_prismarine
fill 182 247 354 182 250 354 minecraft:blue_terracotta
setblock 182 247 358 minecraft:dark_prismarine
setblock 141 248 324 minecraft:cyan_concrete
fill 142 248 324 142 248 326 minecraft:blue_terracotta
setblock 142 248 327 minecraft:dark_prismarine
fill 142 248 328 142 248 331 minecraft:blue_terracotta
setblock 142 248 332 minecraft:dark_prismarine
fill 142 248 333 142 248 336 minecraft:blue_terracotta
setblock 142 248 337 minecraft:dark_prismarine
fill 142 248 338 142 248 341 minecraft:blue_terracotta
setblock 142 248 342 minecraft:dark_prismarine
fill 142 248 343 142 248 346 minecraft:blue_terracotta
setblock 142 248 347 minecraft:dark_prismarine
fill 142 248 348 142 251 348 minecraft:blue_terracotta
setblock 142 248 352 minecraft:dark_prismarine
fill 142 248 353 142 251 353 minecraft:blue_terracotta
setblock 143 248 326 minecraft:dark_prismarine
fill 143 248 327 143 251 327 minecraft:blue_terracotta
setblock 143 248 331 minecraft:dark_prismarine
fill 143 248 332 143 250 333 minecraft:blue_terracotta
setblock 143 248 346 minecraft:dark_prismarine
fill 143 248 347 143 249 347 minecraft:blue_terracotta
setblock 143 248 351 minecraft:dark_prismarine
fill 145 248 340 145 253 340 minecraft:purple_concrete
fill 148 248 323 150 248 323 minecraft:blue_terracotta
setblock 150 248 324 minecraft:dark_prismarine
setblock 151 248 323 minecraft:dark_prismarine
fill 151 248 324 153 248 325 minecraft:blue_terracotta
setblock 151 248 363 minecraft:purple_concrete
fill 152 248 323 155 248 323 minecraft:blue_terracotta
setblock 153 248 326 minecraft:dark_prismarine
fill 153 248 363 155 248 363 minecraft:blue_terracotta
setblock 154 248 324 minecraft:blue_terracotta
setblock 154 248 325 minecraft:dark_prismarine
fill 154 248 326 154 251 326 minecraft:blue_terracotta
setblock 155 248 324 minecraft:dark_prismarine
fill 155 248 325 158 248 325 minecraft:blue_terracotta
setblock 156 248 323 minecraft:dark_prismarine
fill 156 248 324 159 248 324 minecraft:blue_terracotta
setblock 156 248 327 minecraft:blue_terracotta
setblock 156 248 363 minecraft:dark_prismarine
fill 157 248 323 160 248 323 minecraft:blue_terracotta
fill 157 248 363 160 248 363 minecraft:blue_terracotta
setblock 158 248 326 minecraft:dark_prismarine
fill 158 248 362 158 251 362 minecraft:blue_terracotta
setblock 159 248 325 minecraft:dark_prismarine
fill 159 248 326 159 250 326 minecraft:blue_terracotta
setblock 160 248 324 minecraft:dark_prismarine
fill 160 248 325 160 250 325 minecraft:blue_terracotta
setblock 161 248 323 minecraft:dark_prismarine
fill 161 248 324 161 251 324 minecraft:blue_terracotta
setblock 161 248 363 minecraft:dark_prismarine
fill 162 248 323 165 248 323 minecraft:blue_terracotta
fill 162 248 363 162 251 363 minecraft:blue_terracotta
setblock 166 248 323 minecraft:dark_prismarine
fill 167 248 323 170 248 323 minecraft:blue_terracotta
fill 168 248 363 170 248 363 minecraft:blue_terracotta
fill 169 248 327 170 255 327 minecraft:magenta_terracotta
fill 170 248 328 171 249 329 minecraft:black_concrete
setblock 171 248 323 minecraft:dark_prismarine
setblock 171 248 363 minecraft:dark_prismarine
fill 172 248 323 174 248 324 minecraft:blue_terracotta
fill 172 248 363 175 248 363 minecraft:blue_terracotta
fill 173 248 362 173 251 362 minecraft:blue_terracotta
setblock 174 248 322 minecraft:cyan_concrete
fill 174 248 333 174 249 334 minecraft:black_concrete
setblock 175 248 323 minecraft:blue_terracotta
setblock 175 248 324 minecraft:dark_prismarine
fill 175 248 329 175 249 331 minecraft:purple_concrete
fill 175 248 332 176 248 334 minecraft:dark_prismarine
fill 175 248 335 178 249 335 minecraft:black_concrete
setblock 176 248 323 minecraft:dark_prismarine
fill 176 248 324 176 250 324 minecraft:blue_terracotta
setblock 176 248 363 minecraft:dark_prismarine
fill 177 248 323 177 251 323 minecraft:blue_terracotta
fill 177 248 328 177 249 328 minecraft:purple_concrete
fill 177 248 332 177 249 332 minecraft:purple_concrete
fill 177 248 333 177 272 334 minecraft:dark_prismarine
setblock 177 248 362 minecraft:dark_prismarine
fill 177 248 363 177 251 363 minecraft:blue_terracotta
setblock 178 248 332 minecraft:black_concrete
fill 178 248 334 178 249 334 minecraft:black_concrete
fill 178 248 362 178 249 362 minecraft:blue_terracotta
setblock 179 248 349 minecraft:blue_terracotta
setblock 179 248 350 minecraft:dark_prismarine
fill 179 248 351 179 251 351 minecraft:blue_terracotta
setblock 179 248 354 minecraft:blue_terracotta
setblock 180 248 344 minecraft:dark_prismarine
fill 180 248 345 180 250 345 minecraft:blue_terracotta
setblock 180 248 349 minecraft:dark_prismarine
fill 180 248 350 180 251 350 minecraft:blue_terracotta
setblock 180 248 354 minecraft:dark_prismarine
fill 180 248 355 180 251 355 minecraft:blue_terracotta
setblock 181 248 323 minecraft:dark_prismarine
setblock 181 248 327 minecraft:blue_terracotta
setblock 181 248 328 minecraft:dark_prismarine
fill 181 248 329 181 249 331 minecraft:blue_terracotta
setblock 181 248 342 minecraft:blue_terracotta
setblock 181 248 343 minecraft:dark_prismarine
fill 181 248 344 181 251 344 minecraft:blue_terracotta
setblock 181 248 348 minecraft:dark_prismarine
fill 181 248 349 181 251 349 minecraft:blue_terracotta
setblock 181 248 353 minecraft:dark_prismarine
fill 181 248 354 181 251 354 minecraft:blue_terracotta
setblock 181 248 357 minecraft:blue_terracotta
setblock 182 248 327 minecraft:dark_prismarine
fill 182 248 328 182 251 328 minecraft:blue_terracotta
setblock 182 248 332 minecraft:dark_prismarine
fill 182 248 333 182 248 336 minecraft:blue_terracotta
fill 182 248 339 182 248 341 minecraft:blue_terracotta
setblock 182 248 342 minecraft:dark_prismarine
fill 182 248 343 182 251 343 minecraft:blue_terracotta
setblock 182 248 347 minecraft:dark_prismarine
fill 182 248 348 182 251 348 minecraft:blue_terracotta
setblock 182 248 352 minecraft:dark_prismarine
fill 182 248 353 182 251 353 minecraft:blue_terracotta
setblock 182 248 357 minecraft:dark_prismarine
fill 182 248 358 182 251 358 minecraft:blue_terracotta
setblock 183 248 344 minecraft:cyan_concrete
fill 183 248 345 183 308 345 minecraft:blue_concrete
fill 141 249 324 141 308 324 minecraft:blue_concrete
fill 141 249 339 141 291 342 minecraft:blue_concrete
setblock 141 249 343 minecraft:light_blue_wool
fill 142 249 324 142 249 325 minecraft:blue_terracotta
setblock 142 249 326 minecraft:dark_prismarine
fill 142 249 327 142 249 330 minecraft:blue_terracotta
setblock 142 249 331 minecraft:dark_prismarine
fill 142 249 332 142 249 335 minecraft:blue_terracotta
setblock 142 249 336 minecraft:dark_prismarine
fill 142 249 337 142 249 340 minecraft:blue_terracotta
setblock 142 249 341 minecraft:dark_prismarine
fill 142 249 342 142 249 345 minecraft:blue_terracotta
setblock 142 249 346 minecraft:dark_prismarine
fill 142 249 347 142 252 347 minecraft:blue_terracotta
setblock 142 249 351 minecraft:dark_prismarine
fill 142 249 352 143 250 352 minecraft:blue_terracotta
setblock 143 249 329 minecraft:blue_terracotta
setblock 143 249 330 minecraft:dark_prismarine
fill 143 249 331 143 252 331 minecraft:blue_terracotta
setblock 143 249 334 minecraft:blue_terracotta
setblock 143 249 335 minecraft:dark_prismarine
setblock 143 249 346 minecraft:blue_terracotta
setblock 143 249 350 minecraft:dark_prismarine
fill 143 249 351 143 250 351 minecraft:blue_terracotta
fill 146 249 340 146 253 340 minecraft:purple_concrete
fill 148 249 323 149 249 323 minecraft:blue_terracotta
setblock 149 249 324 minecraft:dark_prismarine
setblock 150 249 323 minecraft:dark_prismarine
fill 150 249 324 153 249 324 minecraft:blue_terracotta
fill 151 249 323 154 249 323 minecraft:blue_terracotta
fill 151 249 325 152 249 325 minecraft:blue_terracotta
setblock 152 249 326 minecraft:dark_prismarine
fill 152 249 363 154 249 363 minecraft:blue_terracotta
setblock 153 249 325 minecraft:dark_prismarine
fill 153 249 326 153 252 326 minecraft:blue_terracotta
setblock 154 249 324 minecraft:dark_prismarine
fill 154 249 325 157 249 325 minecraft:blue_terracotta
setblock 155 249 323 minecraft:dark_prismarine
fill 155 249 324 158 249 324 minecraft:blue_terracotta
setblock 155 249 327 minecraft:blue_terracotta
setblock 155 249 363 minecraft:dark_prismarine
fill 156 249 323 159 249 323 minecraft:blue_terracotta
setblock 156 249 327 minecraft:dark_prismarine
setblock 156 249 362 minecraft:dark_prismarine
fill 156 249 363 159 249 363 minecraft:blue_terracotta
setblock 157 249 326 minecraft:dark_prismarine
setblock 157 249 327 minecraft:blue_terracotta
fill 157 249 362 157 252 362 minecraft:blue_terracotta
setblock 158 249 325 minecraft:dark_prismarine
fill 158 249 326 158 251 326 minecraft:blue_terracotta
setblock 159 249 324 minecraft:dark_prismarine
fill 159 249 325 159 251 325 minecraft:blue_terracotta
fill 159 249 362 159 250 362 minecraft:blue_terracotta
setblock 160 249 323 minecraft:dark_prismarine
fill 160 249 324 160 252 324 minecraft:blue_terracotta
setblock 160 249 363 minecraft:dark_prismarine
fill 161 249 323 164 249 323 minecraft:blue_terracotta
fill 161 249 363 161 252 363 minecraft:blue_terracotta
fill 162 249 336 166 252 336 minecraft:jungle_leaves[persistent=true]
fill 162 249 346 166 252 346 minecraft:jungle_leaves[persistent=true]
fill 163 249 341 163 250 341 minecraft:jungle_log
fill 164 249 337 168 251 337 minecraft:jungle_leaves[persistent=true]
fill 164 249 345 168 251 345 minecraft:jungle_leaves[persistent=true]
setblock 164 249 363 minecraft:blue_terracotta
setblock 165 249 323 minecraft:dark_prismarine
fill 165 249 338 169 251 338 minecraft:jungle_leaves[persistent=true]
fill 165 249 344 169 251 344 minecraft:jungle_leaves[persistent=true]
setblock 165 249 363 minecraft:dark_prismarine
fill 166 249 323 169 249 323 minecraft:blue_terracotta
fill 166 249 339 169 249 343 minecraft:jungle_leaves[persistent=true]
fill 166 249 363 169 249 363 minecraft:blue_terracotta
fill 168 249 357 168 250 357 minecraft:magenta_terracotta
setblock 170 249 323 minecraft:dark_prismarine
fill 170 249 340 170 251 342 minecraft:jungle_leaves[persistent=true]
setblock 170 249 363 minecraft:dark_prismarine
fill 171 249 323 174 249 323 minecraft:blue_terracotta
fill 171 249 340 175 249 342 minecraft:jungle_log
fill 171 249 363 174 249 363 minecraft:blue_terracotta
fill 172 249 324 173 249 324 minecraft:blue_terracotta
fill 172 249 362 172 252 362 minecraft:blue_terracotta
fill 174 249 322 174 308 322 minecraft:blue_concrete
setblock 174 249 324 minecraft:dark_prismarine
fill 174 249 331 174 249 332 minecraft:black_concrete
setblock 174 249 335 minecraft:black_concrete
setblock 175 249 323 minecraft:dark_prismarine
fill 175 249 324 175 251 324 minecraft:blue_terracotta
fill 175 249 332 175 272 334 minecraft:dark_prismarine
fill 175 249 336 178 249 336 minecraft:black_concrete
setblock 175 249 363 minecraft:dark_prismarine
fill 176 249 323 176 252 323 minecraft:blue_terracotta
setblock 176 249 328 minecraft:purple_concrete
setblock 176 249 332 minecraft:purple_concrete
fill 176 249 333 176 249 334 minecraft:dark_prismarine
fill 176 249 341 176 250 341 minecraft:magenta_terracotta
setblock 176 249 362 minecraft:dark_prismarine
fill 176 249 363 176 252 363 minecraft:blue_terracotta
fill 177 249 362 177 251 362 minecraft:blue_terracotta
setblock 178 249 328 minecraft:purple_concrete
setblock 178 249 332 minecraft:purple_concrete
setblock 178 249 350 minecraft:dark_prismarine
fill 178 249 351 178 250 352 minecraft:blue_terracotta
fill 179 249 329 179 249 331 minecraft:purple_concrete
fill 179 249 332 179 249 335 minecraft:black_concrete
setblock 179 249 349 minecraft:dark_prismarine
fill 179 249 350 179 252 350 minecraft:blue_terracotta
setblock 179 249 354 minecraft:dark_prismarine
setblock 180 249 323 minecraft:dark_prismarine
setblock 180 249 348 minecraft:dark_prismarine
fill 180 249 349 180 252 349 minecraft:blue_terracotta
setblock 180 249 353 minecraft:dark_prismarine
fill 180 249 354 180 252 354 minecraft:blue_terracotta
fill 180 249 356 180 250 356 minecraft:blue_terracotta
setblock 180 249 363 minecraft:dark_prismarine
fill 181 249 328 181 250 328 minecraft:blue_terracotta
setblock 181 249 332 minecraft:dark_prismarine
fill 181 249 333 182 251 333 minecraft:blue_terracotta
fill 181 249 341 181 250 341 minecraft:jungle_log
fill 181 249 343 181 250 343 minecraft:blue_terracotta
setblock 181 249 347 minecraft:dark_prismarine
fill 181 249 348 181 252 348 minecraft:blue_terracotta
setblock 181 249 352 minecraft:dark_prismarine
fill 181 249 353 181 252 353 minecraft:blue_terracotta
setblock 181 249 357 minecraft:dark_prismarine
setblock 182 249 326 minecraft:dark_prismarine
fill 182 249 327 182 251 327 minecraft:blue_terracotta
setblock 182 249 330 minecraft:blue_terracotta
setblock 182 249 331 minecraft:dark_prismarine
fill 182 249 332 182 252 332 minecraft:blue_terracotta
fill 182 249 334 182 249 335 minecraft:blue_terracotta
setblock 182 249 336 minecraft:dark_prismarine
fill 182 249 337 182 249 340 minecraft:blue_terracotta
setblock 182 249 341 minecraft:dark_prismarine
fill 182 249 342 182 252 342 minecraft:blue_terracotta
setblock 182 249 346 minecraft:dark_prismarine
fill 182 249 347 182 252 347 minecraft:blue_terracotta
setblock 182 249 351 minecraft:dark_prismarine
fill 182 249 352 182 252 352 minecraft:blue_terracotta
setblock 182 249 356 minecraft:dark_prismarine
fill 182 249 357 182 252 357 minecraft:blue_terracotta
fill 183 249 344 183 308 344 minecraft:blue_concrete
fill 141 250 343 141 308 343 minecraft:blue_concrete
setblock 142 250 324 minecraft:blue_terracotta
setblock 142 250 325 minecraft:dark_prismarine
fill 142 250 326 142 250 329 minecraft:blue_terracotta
setblock 142 250 330 minecraft:dark_prismarine
fill 142 250 331 142 250 334 minecraft:blue_terracotta
setblock 142 250 335 minecraft:dark_prismarine
fill 142 250 336 142 250 339 minecraft:blue_terracotta
setblock 142 250 340 minecraft:dark_prismarine
fill 142 250 341 142 250 344 minecraft:blue_terracotta
setblock 142 250 345 minecraft:dark_prismarine
fill 142 250 346 142 252 346 minecraft:blue_terracotta
setblock 142 250 350 minecraft:dark_prismarine
fill 142 250 351 142 253 351 minecraft:blue_terracotta
setblock 142 250 354 minecraft:blue_terracotta
setblock 142 250 355 minecraft:dark_prismarine
fill 142 250 356 142 251 356 minecraft:blue_terracotta
setblock 142 250 359 minecraft:purple_concrete
setblock 143 250 329 minecraft:dark_prismarine
fill 143 250 330 143 253 330 minecraft:blue_terracotta
setblock 143 250 334 minecraft:dark_prismarine
fill 143 250 335 143 252 336 minecraft:blue_terracotta
setblock 143 250 349 minecraft:dark_prismarine
setblock 143 250 350 minecraft:blue_terracotta
fill 144 250 340 144 253 340 minecraft:purple_concrete
fill 145 250 339 146 253 339 minecraft:purple_concrete
fill 145 250 341 146 253 341 minecraft:purple_concrete
fill 147 250 323 148 250 323 minecraft:blue_terracotta
setblock 149 250 323 minecraft:dark_prismarine
fill 149 250 324 152 250 324 minecraft:blue_terracotta
fill 149 250 344 149 255 344 minecraft:magenta_terracotta
fill 150 250 323 153 250 323 minecraft:blue_terracotta
fill 150 250 325 151 250 325 minecraft:blue_terracotta
setblock 152 250 325 minecraft:dark_prismarine
fill 152 250 326 152 252 326 minecraft:blue_terracotta
fill 152 250 363 153 250 363 minecraft:blue_terracotta
setblock 153 250 324 minecraft:dark_prismarine
fill 153 250 325 156 250 325 minecraft:blue_terracotta
setblock 154 250 323 minecraft:dark_prismarine
fill 154 250 324 157 250 324 minecraft:blue_terracotta
setblock 154 250 327 minecraft:blue_terracotta
fill 154 250 340 156 251 342 minecraft:jungle_leaves[persistent=true]
setblock 154 250 363 minecraft:dark_prismarine
fill 155 250 323 158 250 323 minecraft:blue_terracotta
setblock 155 250 327 minecraft:dark_prismarine
fill 155 250 338 156 254 339 minecraft:jungle_leaves[persistent=true]
fill 155 250 343 156 254 344 minecraft:jungle_leaves[persistent=true]
setblock 155 250 362 minecraft:dark_prismarine
fill 155 250 363 158 250 363 minecraft:blue_terracotta
setblock 156 250 326 minecraft:dark_prismarine
setblock 156 250 327 minecraft:blue_terracotta
fill 156 250 336 158 251 337 minecraft:jungle_leaves[persistent=true]
fill 156 250 345 158 251 346 minecraft:jungle_leaves[persistent=true]
fill 156 250 362 156 253 362 minecraft:blue_terracotta
setblock 157 250 325 minecraft:dark_prismarine
fill 157 250 326 157 251 326 minecraft:blue_terracotta
fill 157 250 335 167 255 335 minecraft:jungle_leaves[persistent=true]
fill 157 250 338 157 251 338 minecraft:jungle_leaves[persistent=true]
fill 157 250 344 157 251 344 minecraft:jungle_leaves[persistent=true]
fill 157 250 347 167 255 347 minecraft:jungle_leaves[persistent=true]
setblock 158 250 324 minecraft:dark_prismarine
fill 158 250 325 158 252 325 minecraft:blue_terracotta
setblock 159 250 323 minecraft:dark_prismarine
fill 159 250 324 159 253 324 minecraft:blue_terracotta
fill 159 250 334 167 255 334 minecraft:jungle_leaves[persistent=true]
fill 159 250 336 161 251 336 minecraft:jungle_leaves[persistent=true]
fill 159 250 346 161 251 346 minecraft:jungle_leaves[persistent=true]
fill 159 250 348 167 255 348 minecraft:jungle_leaves[persistent=true]
setblock 159 250 363 minecraft:dark_prismarine
fill 160 250 323 163 250 323 minecraft:blue_terracotta
fill 160 250 363 160 253 363 minecraft:blue_terracotta
fill 161 250 333 167 255 333 minecraft:jungle_leaves[persistent=true]
fill 161 250 349 167 255 349 minecraft:jungle_leaves[persistent=true]
setblock 164 250 323 minecraft:dark_prismarine
fill 164 250 341 166 250 341 minecraft:jungle_log
setblock 164 250 363 minecraft:dark_prismarine
fill 165 250 323 168 250 323 minecraft:blue_terracotta
fill 165 250 363 168 250 363 minecraft:blue_terracotta
fill 166 250 339 169 252 340 minecraft:jungle_leaves[persistent=true]
fill 166 250 342 169 252 343 minecraft:jungle_leaves[persistent=true]
fill 167 250 336 168 255 336 minecraft:jungle_leaves[persistent=true]
fill 167 250 341 169 250 341 minecraft:jungle_leaves[persistent=true]
fill 167 250 346 168 255 346 minecraft:jungle_leaves[persistent=true]
fill 168 250 334 168 250 335 minecraft:jungle_log
fill 168 250 347 168 250 348 minecraft:jungle_log
fill 169 250 322 169 308 322 minecraft:blue_concrete
setblock 169 250 323 minecraft:dark_prismarine
fill 169 250 334 169 255 334 minecraft:jungle_leaves[persistent=true]
fill 169 250 335 169 250 336 minecraft:jungle_log
fill 169 250 337 172 250 337 minecraft:jungle_leaves[persistent=true]
fill 169 250 345 172 250 345 minecraft:jungle_leaves[persistent=true]
fill 169 250 346 169 250 347 minecraft:jungle_log
fill 169 250 348 169 255 348 minecraft:jungle_leaves[persistent=true]
fill 169 250 357 169 268 357 minecraft:magenta_terracotta
setblock 169 250 363 minecraft:dark_prismarine
setblock 170 250 322 minecraft:cyan_concrete
fill 170 250 323 173 250 323 minecraft:blue_terracotta
fill 170 250 335 171 255 336 minecraft:jungle_leaves[persistent=true]
fill 170 250 338 173 250 339 minecraft:jungle_leaves[persistent=true]
fill 170 250 343 173 250 344 minecraft:jungle_leaves[persistent=true]
fill 170 250 346 171 255 347 minecraft:jungle_leaves[persistent=true]
fill 170 250 363 173 250 363 minecraft:blue_terracotta
fill 171 250 340 174 251 342 minecraft:jungle_leaves[persistent=true]
fill 171 250 362 171 253 362 minecraft:blue_terracotta
setblock 172 250 324 minecraft:blue_terracotta
fill 172 250 327 174 251 333 minecraft:dark_prismarine
fill 172 250 336 172 259 336 minecraft:jungle_leaves[persistent=true]
fill 172 250 346 172 259 346 minecraft:jungle_leaves[persistent=true]
setblock 173 250 324 minecraft:dark_prismarine
setblock 174 250 323 minecraft:dark_prismarine
fill 174 250 324 174 251 324 minecraft:blue_terracotta
setblock 174 250 339 minecraft:jungle_log
setblock 174 250 343 minecraft:jungle_log
setblock 174 250 363 minecraft:dark_prismarine
fill 175 250 323 175 253 323 minecraft:blue_terracotta
fill 175 250 327 180 272 331 minecraft:dark_prismarine
fill 175 250 335 175 250 336 minecraft:jungle_log
fill 175 250 340 175 250 342 minecraft:jungle_log
fill 175 250 346 175 250 347 minecraft:jungle_log
setblock 175 250 362 minecraft:dark_prismarine
fill 175 250 363 175 253 363 minecraft:blue_terracotta
fill 176 250 332 176 272 333 minecraft:dark_prismarine
fill 176 250 334 176 250 335 minecraft:jungle_log
fill 176 250 347 176 250 348 minecraft:jungle_log
fill 176 250 362 176 253 362 minecraft:blue_terracotta
fill 177 250 332 180 272 332 minecraft:dark_prismarine
fill 178 250 341 180 250 341 minecraft:jungle_log
setblock 178 250 350 minecraft:blue_terracotta
setblock 179 250 323 minecraft:dark_prismarine
fill 179 250 333 180 272 333 minecraft:dark_prismarine
setblock 179 250 348 minecraft:dark_prismarine
fill 179 250 349 179 251 349 minecraft:blue_terracotta
setblock 179 250 352 minecraft:blue_terracotta
setblock 179 250 353 minecraft:dark_prismarine
fill 179 250 354 179 251 355 minecraft:blue_terracotta
setblock 179 250 363 minecraft:dark_prismarine
setblock 180 250 347 minecraft:dark_prismarine
fill 180 250 348 180 252 348 minecraft:blue_terracotta
setblock 180 250 352 minecraft:dark_prismarine
fill 180 250 353 180 253 353 minecraft:blue_terracotta
fill 181 250 327 181 267 327 minecraft:dark_prismarine
fill 181 250 329 181 250 330 minecraft:blue_terracotta
setblock 181 250 331 minecraft:dark_prismarine
fill 181 250 332 181 253 332 minecraft:blue_terracotta
fill 181 250 334 182 250 334 minecraft:blue_terracotta
setblock 181 250 346 minecraft:dark_prismarine
fill 181 250 347 181 253 347 minecraft:blue_terracotta
setblock 181 250 351 minecraft:dark_prismarine
fill 181 250 352 181 253 352 minecraft:blue_terracotta
setblock 181 250 356 minecraft:dark_prismarine
fill 181 250 357 181 252 357 minecraft:blue_terracotta
setblock 182 250 326 minecraft:blue_terracotta
setblock 182 250 330 minecraft:dark_prismarine
fill 182 250 331 182 253 331 minecraft:blue_terracotta
setblock 182 250 335 minecraft:dark_prismarine
fill 182 250 336 182 250 339 minecraft:blue_terracotta
setblock 182 250 340 minecraft:dark_prismarine
fill 182 250 341 182 253 341 minecraft:blue_terracotta
setblock 182 250 345 minecraft:dark_prismarine
fill 182 250 346 182 253 346 minecraft:blue_terracotta
setblock 182 250 350 minecraft:dark_prismarine
fill 182 250 351 182 253 351 minecraft:blue_terracotta
setblock 182 250 355 minecraft:dark_prismarine
fill 182 250 356 182 253 356 minecraft:blue_terracotta
setblock 182 250 363 minecraft:purple_concrete
fill 183 250 347 183 253 350 minecraft:blue_concrete
setblock 183 250 351 minecraft:light_blue_wool
fill 183 250 352 183 264 354 minecraft:blue_concrete
fill 142 251 325 142 251 328 minecraft:blue_terracotta
schedule function dropper:buildpart/75_12 1t
