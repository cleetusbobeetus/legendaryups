setblock 331 57 417 minecraft:red_concrete
setblock 331 57 457 minecraft:red_concrete
fill 337 57 443 337 58 443 minecraft:jack_o_lantern
setblock 338 57 417 minecraft:red_concrete
setblock 345 57 417 minecraft:red_concrete
fill 347 57 443 347 58 443 minecraft:jack_o_lantern
setblock 352 57 417 minecraft:red_concrete
setblock 352 57 457 minecraft:red_concrete
setblock 359 57 417 minecraft:red_concrete
setblock 359 57 457 minecraft:red_concrete
setblock 366 57 417 minecraft:red_concrete
setblock 366 57 457 minecraft:red_concrete
fill 368 57 429 368 70 430 minecraft:red_wool
fill 368 57 432 368 70 433 minecraft:red_wool
setblock 370 57 420 minecraft:red_concrete
setblock 370 57 427 minecraft:red_concrete
setblock 370 57 434 minecraft:red_concrete
setblock 370 57 441 minecraft:red_concrete
setblock 370 57 448 minecraft:red_concrete
setblock 370 57 455 minecraft:red_concrete
setblock 330 58 417 minecraft:red_concrete
setblock 330 58 424 minecraft:red_concrete
setblock 330 58 431 minecraft:red_concrete
setblock 330 58 438 minecraft:red_concrete
setblock 330 58 445 minecraft:red_concrete
setblock 330 58 452 minecraft:red_concrete
setblock 332 58 457 minecraft:red_concrete
setblock 337 58 417 minecraft:red_concrete
fill 338 58 442 338 58 443 minecraft:jack_o_lantern
setblock 339 58 442 minecraft:jack_o_lantern
setblock 344 58 417 minecraft:red_concrete
fill 345 58 442 346 58 442 minecraft:jack_o_lantern
fill 346 58 443 346 59 443 minecraft:jack_o_lantern
setblock 351 58 417 minecraft:red_concrete
setblock 353 58 457 minecraft:red_concrete
setblock 358 58 417 minecraft:red_concrete
setblock 360 58 457 minecraft:red_concrete
setblock 365 58 417 minecraft:red_concrete
setblock 367 58 457 minecraft:red_concrete
setblock 370 58 419 minecraft:red_concrete
setblock 370 58 426 minecraft:red_concrete
setblock 370 58 433 minecraft:red_concrete
setblock 370 58 440 minecraft:red_concrete
setblock 370 58 447 minecraft:red_concrete
setblock 370 58 454 minecraft:red_concrete
fill 330 59 418 330 60 418 minecraft:red_concrete
fill 330 59 425 330 60 425 minecraft:red_concrete
fill 330 59 432 330 60 432 minecraft:red_concrete
fill 330 59 439 330 60 439 minecraft:red_concrete
fill 330 59 446 330 60 446 minecraft:red_concrete
fill 330 59 453 330 60 453 minecraft:red_concrete
fill 333 59 457 333 60 457 minecraft:red_concrete
fill 336 59 417 336 60 417 minecraft:red_concrete
setblock 338 59 443 minecraft:jack_o_lantern
fill 343 59 417 343 60 417 minecraft:red_concrete
fill 350 59 417 350 60 417 minecraft:red_concrete
fill 354 59 457 354 60 457 minecraft:red_concrete
fill 357 59 417 357 60 417 minecraft:red_concrete
fill 361 59 457 361 60 457 minecraft:red_concrete
fill 364 59 417 364 60 417 minecraft:red_concrete
fill 368 59 457 368 60 457 minecraft:red_concrete
fill 370 59 418 370 60 418 minecraft:red_concrete
fill 370 59 425 370 60 425 minecraft:red_concrete
fill 370 59 432 370 60 432 minecraft:red_concrete
fill 370 59 439 370 60 439 minecraft:red_concrete
fill 370 59 446 370 60 446 minecraft:red_concrete
fill 370 59 453 370 60 453 minecraft:red_concrete
fill 330 60 417 331 60 417 minecraft:red_concrete
fill 330 60 419 330 60 421 minecraft:red_concrete
fill 330 60 423 330 60 424 minecraft:red_concrete
fill 330 60 426 330 60 428 minecraft:red_concrete
fill 330 60 430 330 60 431 minecraft:red_concrete
fill 330 60 433 330 60 435 minecraft:red_concrete
fill 330 60 437 330 60 438 minecraft:red_concrete
fill 330 60 440 330 60 442 minecraft:red_concrete
fill 330 60 444 330 60 445 minecraft:red_concrete
fill 330 60 447 330 60 449 minecraft:red_concrete
fill 330 60 451 330 60 452 minecraft:red_concrete
fill 330 60 454 330 60 456 minecraft:red_concrete
fill 331 60 457 332 60 457 minecraft:red_concrete
fill 333 60 417 335 60 417 minecraft:red_concrete
fill 334 60 457 335 60 457 minecraft:red_concrete
fill 337 60 417 338 60 417 minecraft:red_concrete
fill 340 60 417 342 60 417 minecraft:red_concrete
fill 344 60 417 345 60 417 minecraft:red_concrete
fill 347 60 417 349 60 417 minecraft:red_concrete
fill 349 60 457 350 60 457 minecraft:red_concrete
fill 351 60 417 352 60 417 minecraft:red_concrete
fill 352 60 457 353 60 457 minecraft:red_concrete
fill 354 60 417 356 60 417 minecraft:red_concrete
fill 355 60 457 357 60 457 minecraft:red_concrete
fill 358 60 417 359 60 417 minecraft:red_concrete
fill 359 60 457 360 60 457 minecraft:red_concrete
fill 361 60 417 363 60 417 minecraft:red_concrete
fill 362 60 457 364 60 457 minecraft:red_concrete
fill 365 60 417 366 60 417 minecraft:red_concrete
fill 366 60 457 367 60 457 minecraft:red_concrete
fill 368 60 417 370 60 417 minecraft:red_concrete
fill 369 60 457 370 60 457 minecraft:red_concrete
fill 370 60 419 370 60 420 minecraft:red_concrete
fill 370 60 422 370 60 424 minecraft:red_concrete
fill 370 60 426 370 60 427 minecraft:red_concrete
fill 370 60 429 370 60 431 minecraft:red_concrete
fill 370 60 433 370 60 434 minecraft:red_concrete
fill 370 60 436 370 60 438 minecraft:red_concrete
fill 370 60 440 370 60 441 minecraft:red_concrete
fill 370 60 443 370 60 445 minecraft:red_concrete
fill 370 60 447 370 60 448 minecraft:red_concrete
fill 370 60 450 370 60 452 minecraft:red_concrete
fill 370 60 454 370 60 455 minecraft:red_concrete
setblock 330 61 420 minecraft:red_concrete
setblock 330 61 427 minecraft:red_concrete
setblock 330 61 434 minecraft:red_concrete
setblock 330 61 441 minecraft:red_concrete
setblock 330 61 448 minecraft:red_concrete
setblock 330 61 455 minecraft:red_concrete
setblock 334 61 417 minecraft:red_concrete
setblock 335 61 457 minecraft:red_concrete
setblock 341 61 417 minecraft:red_concrete
setblock 348 61 417 minecraft:red_concrete
setblock 349 61 457 minecraft:red_concrete
setblock 355 61 417 minecraft:red_concrete
setblock 356 61 457 minecraft:red_concrete
setblock 362 61 417 minecraft:red_concrete
setblock 363 61 457 minecraft:red_concrete
setblock 369 61 417 minecraft:red_concrete
setblock 370 61 423 minecraft:red_concrete
setblock 370 61 430 minecraft:red_concrete
setblock 370 61 437 minecraft:red_concrete
setblock 370 61 444 minecraft:red_concrete
setblock 370 61 451 minecraft:red_concrete
setblock 370 61 457 minecraft:red_concrete
setblock 330 62 421 minecraft:red_concrete
setblock 330 62 428 minecraft:red_concrete
setblock 330 62 435 minecraft:red_concrete
setblock 330 62 442 minecraft:red_concrete
setblock 330 62 449 minecraft:red_concrete
setblock 330 62 456 minecraft:red_concrete
setblock 332 62 419 minecraft:light[level=12]
setblock 332 62 427 minecraft:light[level=12]
setblock 332 62 435 minecraft:light[level=12]
setblock 332 62 443 minecraft:light[level=12]
setblock 332 62 451 minecraft:light[level=12]
setblock 333 62 417 minecraft:red_concrete
setblock 336 62 457 minecraft:red_concrete
setblock 338 62 456 minecraft:red_concrete
setblock 340 62 417 minecraft:red_concrete
setblock 340 62 419 minecraft:light[level=12]
setblock 340 62 427 minecraft:light[level=12]
setblock 340 62 435 minecraft:light[level=12]
setblock 340 62 443 minecraft:light[level=12]
setblock 345 62 457 minecraft:red_concrete
setblock 347 62 417 minecraft:red_concrete
setblock 348 62 419 minecraft:light[level=12]
setblock 348 62 427 minecraft:light[level=12]
setblock 348 62 435 minecraft:light[level=12]
setblock 348 62 443 minecraft:light[level=12]
setblock 350 62 457 minecraft:red_concrete
setblock 354 62 417 minecraft:red_concrete
setblock 356 62 419 minecraft:light[level=12]
setblock 356 62 427 minecraft:light[level=12]
setblock 356 62 435 minecraft:light[level=12]
setblock 356 62 443 minecraft:light[level=12]
setblock 356 62 451 minecraft:light[level=12]
setblock 357 62 457 minecraft:red_concrete
setblock 361 62 417 minecraft:red_concrete
setblock 364 62 419 minecraft:light[level=12]
setblock 364 62 427 minecraft:light[level=12]
setblock 364 62 435 minecraft:light[level=12]
setblock 364 62 443 minecraft:light[level=12]
setblock 364 62 451 minecraft:light[level=12]
setblock 364 62 457 minecraft:red_concrete
setblock 368 62 417 minecraft:red_concrete
setblock 370 62 422 minecraft:red_concrete
setblock 370 62 429 minecraft:red_concrete
setblock 370 62 436 minecraft:red_concrete
setblock 370 62 443 minecraft:red_concrete
setblock 370 62 450 minecraft:red_concrete
setblock 330 64 423 minecraft:red_concrete
setblock 330 64 430 minecraft:red_concrete
setblock 330 64 437 minecraft:red_concrete
setblock 330 64 444 minecraft:red_concrete
setblock 330 64 451 minecraft:red_concrete
setblock 331 64 417 minecraft:red_concrete
setblock 331 64 457 minecraft:red_concrete
setblock 338 64 417 minecraft:red_concrete
setblock 338 64 457 minecraft:red_concrete
setblock 345 64 417 minecraft:red_concrete
setblock 345 64 457 minecraft:red_concrete
setblock 352 64 417 minecraft:red_concrete
setblock 352 64 457 minecraft:red_concrete
setblock 359 64 417 minecraft:red_concrete
setblock 359 64 457 minecraft:red_concrete
setblock 366 64 417 minecraft:red_concrete
setblock 366 64 457 minecraft:red_concrete
fill 368 64 427 368 70 428 minecraft:red_wool
setblock 370 64 420 minecraft:red_concrete
setblock 370 64 427 minecraft:red_concrete
setblock 370 64 434 minecraft:red_concrete
setblock 370 64 441 minecraft:red_concrete
setblock 370 64 448 minecraft:red_concrete
setblock 370 64 455 minecraft:red_concrete
setblock 330 65 417 minecraft:red_concrete
setblock 330 65 424 minecraft:red_concrete
setblock 330 65 431 minecraft:red_concrete
setblock 330 65 438 minecraft:red_concrete
setblock 330 65 445 minecraft:red_concrete
setblock 330 65 452 minecraft:red_concrete
setblock 332 65 457 minecraft:red_concrete
setblock 337 65 417 minecraft:red_concrete
setblock 339 65 457 minecraft:red_concrete
setblock 344 65 417 minecraft:red_concrete
setblock 346 65 457 minecraft:red_concrete
setblock 351 65 417 minecraft:red_concrete
setblock 353 65 457 minecraft:red_concrete
setblock 358 65 417 minecraft:red_concrete
setblock 360 65 457 minecraft:red_concrete
setblock 365 65 417 minecraft:red_concrete
setblock 367 65 457 minecraft:red_concrete
setblock 370 65 419 minecraft:red_concrete
setblock 370 65 426 minecraft:red_concrete
setblock 370 65 433 minecraft:red_concrete
setblock 370 65 440 minecraft:red_concrete
setblock 370 65 447 minecraft:red_concrete
setblock 370 65 454 minecraft:red_concrete
setblock 330 66 418 minecraft:red_concrete
setblock 330 66 425 minecraft:red_concrete
setblock 330 66 432 minecraft:red_concrete
setblock 330 66 439 minecraft:red_concrete
setblock 330 66 446 minecraft:red_concrete
setblock 330 66 453 minecraft:red_concrete
setblock 333 66 457 minecraft:red_concrete
setblock 336 66 417 minecraft:red_concrete
setblock 340 66 457 minecraft:red_concrete
setblock 343 66 417 minecraft:red_concrete
fill 345 66 455 345 67 455 minecraft:red_wool
setblock 347 66 457 minecraft:red_concrete
setblock 350 66 417 minecraft:red_concrete
setblock 354 66 457 minecraft:red_concrete
setblock 357 66 417 minecraft:red_concrete
setblock 361 66 457 minecraft:red_concrete
setblock 364 66 417 minecraft:red_concrete
setblock 368 66 457 minecraft:red_concrete
setblock 370 66 418 minecraft:red_concrete
setblock 370 66 425 minecraft:red_concrete
setblock 370 66 432 minecraft:red_concrete
setblock 370 66 439 minecraft:red_concrete
setblock 370 66 446 minecraft:red_concrete
setblock 370 66 453 minecraft:red_concrete
setblock 330 67 419 minecraft:red_concrete
setblock 330 67 426 minecraft:red_concrete
setblock 330 67 433 minecraft:red_concrete
setblock 330 67 440 minecraft:red_concrete
setblock 330 67 447 minecraft:red_concrete
setblock 330 67 454 minecraft:red_concrete
setblock 334 67 457 minecraft:red_concrete
setblock 335 67 417 minecraft:red_concrete
setblock 341 67 457 minecraft:red_concrete
setblock 342 67 417 minecraft:red_concrete
setblock 348 67 457 minecraft:red_concrete
setblock 349 67 417 minecraft:red_concrete
setblock 355 67 457 minecraft:red_concrete
setblock 356 67 417 minecraft:red_concrete
setblock 362 67 457 minecraft:red_concrete
setblock 363 67 417 minecraft:red_concrete
setblock 369 67 457 minecraft:red_concrete
setblock 370 67 417 minecraft:red_concrete
setblock 370 67 424 minecraft:red_concrete
setblock 370 67 431 minecraft:red_concrete
setblock 370 67 438 minecraft:red_concrete
setblock 370 67 445 minecraft:red_concrete
setblock 370 67 452 minecraft:red_concrete
setblock 330 68 420 minecraft:red_concrete
setblock 330 68 427 minecraft:red_concrete
setblock 330 68 434 minecraft:red_concrete
setblock 330 68 441 minecraft:red_concrete
setblock 330 68 448 minecraft:red_concrete
setblock 330 68 455 minecraft:red_concrete
setblock 334 68 417 minecraft:red_concrete
setblock 335 68 457 minecraft:red_concrete
setblock 341 68 417 minecraft:red_concrete
setblock 342 68 457 minecraft:red_concrete
setblock 348 68 417 minecraft:red_concrete
setblock 349 68 457 minecraft:red_concrete
setblock 355 68 417 minecraft:red_concrete
setblock 356 68 457 minecraft:red_concrete
setblock 362 68 417 minecraft:red_concrete
setblock 363 68 457 minecraft:red_concrete
setblock 369 68 417 minecraft:red_concrete
setblock 370 68 423 minecraft:red_concrete
setblock 370 68 430 minecraft:red_concrete
setblock 370 68 437 minecraft:red_concrete
setblock 370 68 444 minecraft:red_concrete
setblock 370 68 451 minecraft:red_concrete
setblock 370 68 457 minecraft:red_concrete
fill 330 69 421 330 70 421 minecraft:red_concrete
fill 330 69 428 330 70 428 minecraft:red_concrete
fill 330 69 435 330 70 435 minecraft:red_concrete
fill 330 69 442 330 70 442 minecraft:red_concrete
fill 330 69 449 330 70 449 minecraft:red_concrete
fill 330 69 456 330 70 456 minecraft:red_concrete
fill 333 69 417 333 70 417 minecraft:red_concrete
fill 336 69 457 336 70 457 minecraft:red_concrete
fill 340 69 417 340 70 417 minecraft:red_concrete
fill 343 69 457 343 70 457 minecraft:red_concrete
fill 347 69 417 347 70 417 minecraft:red_concrete
fill 350 69 457 350 70 457 minecraft:red_concrete
fill 354 69 417 354 70 417 minecraft:red_concrete
fill 357 69 457 357 70 457 minecraft:red_concrete
fill 361 69 417 361 70 417 minecraft:red_concrete
fill 364 69 457 364 70 457 minecraft:red_concrete
fill 368 69 417 368 70 417 minecraft:red_concrete
fill 370 69 422 370 70 422 minecraft:red_concrete
fill 370 69 429 370 70 429 minecraft:red_concrete
fill 370 69 436 370 70 436 minecraft:red_concrete
fill 370 69 443 370 70 443 minecraft:red_concrete
fill 370 69 450 370 70 450 minecraft:red_concrete
fill 330 70 417 330 70 420 minecraft:red_concrete
fill 330 70 423 330 70 427 minecraft:red_concrete
fill 330 70 430 330 70 434 minecraft:red_concrete
fill 330 70 437 330 70 441 minecraft:red_concrete
fill 330 70 444 330 70 448 minecraft:red_concrete
fill 330 70 451 330 70 455 minecraft:red_concrete
fill 331 70 417 331 71 417 minecraft:red_concrete
fill 331 70 457 335 70 457 minecraft:red_concrete
setblock 332 70 419 minecraft:light[level=12]
setblock 332 70 427 minecraft:light[level=12]
setblock 332 70 435 minecraft:light[level=12]
setblock 332 70 443 minecraft:light[level=12]
setblock 332 70 451 minecraft:light[level=12]
fill 334 70 417 338 70 417 minecraft:red_concrete
fill 338 70 457 342 70 457 minecraft:red_concrete
setblock 340 70 419 minecraft:light[level=12]
setblock 340 70 427 minecraft:light[level=12]
setblock 340 70 435 minecraft:light[level=12]
setblock 340 70 443 minecraft:light[level=12]
setblock 340 70 451 minecraft:light[level=12]
fill 341 70 417 345 70 417 minecraft:red_concrete
fill 345 70 457 349 70 457 minecraft:red_concrete
fill 348 70 417 352 70 417 minecraft:red_concrete
setblock 348 70 419 minecraft:light[level=12]
setblock 348 70 427 minecraft:light[level=12]
setblock 348 70 435 minecraft:light[level=12]
setblock 348 70 443 minecraft:light[level=12]
setblock 348 70 451 minecraft:light[level=12]
fill 352 70 457 356 70 457 minecraft:red_concrete
fill 355 70 417 359 70 417 minecraft:red_concrete
setblock 356 70 419 minecraft:light[level=12]
setblock 356 70 427 minecraft:light[level=12]
setblock 356 70 435 minecraft:light[level=12]
setblock 356 70 443 minecraft:light[level=12]
setblock 356 70 451 minecraft:light[level=12]
fill 359 70 457 363 70 457 minecraft:red_concrete
fill 362 70 417 366 70 417 minecraft:red_concrete
setblock 364 70 419 minecraft:light[level=12]
setblock 364 70 427 minecraft:light[level=12]
setblock 364 70 435 minecraft:light[level=12]
setblock 364 70 443 minecraft:light[level=12]
setblock 364 70 451 minecraft:light[level=12]
fill 366 70 457 370 70 457 minecraft:red_concrete
fill 369 70 417 370 70 417 minecraft:red_concrete
fill 370 70 418 370 70 420 minecraft:red_concrete
fill 370 70 423 370 70 427 minecraft:red_concrete
fill 370 70 430 370 70 434 minecraft:red_concrete
fill 370 70 437 370 70 441 minecraft:red_concrete
fill 370 70 444 370 70 448 minecraft:red_concrete
fill 370 70 451 370 70 455 minecraft:red_concrete
setblock 330 71 423 minecraft:red_concrete
setblock 330 71 430 minecraft:red_concrete
setblock 330 71 437 minecraft:red_concrete
setblock 330 71 444 minecraft:red_concrete
setblock 330 71 451 minecraft:red_concrete
setblock 331 71 457 minecraft:red_concrete
setblock 338 71 417 minecraft:red_concrete
setblock 338 71 457 minecraft:red_concrete
setblock 345 71 417 minecraft:red_concrete
setblock 345 71 457 minecraft:red_concrete
setblock 352 71 417 minecraft:red_concrete
setblock 352 71 457 minecraft:red_concrete
setblock 359 71 417 minecraft:red_concrete
setblock 359 71 457 minecraft:red_concrete
setblock 366 71 417 minecraft:red_concrete
setblock 366 71 457 minecraft:red_concrete
fill 368 71 427 368 75 427 minecraft:red_wool
fill 368 71 428 368 72 434 minecraft:gray_concrete
setblock 370 71 420 minecraft:red_concrete
setblock 370 71 427 minecraft:red_concrete
setblock 370 71 434 minecraft:red_concrete
setblock 370 71 441 minecraft:red_concrete
setblock 370 71 448 minecraft:red_concrete
setblock 370 71 455 minecraft:red_concrete
setblock 330 72 417 minecraft:red_concrete
setblock 330 72 424 minecraft:red_concrete
setblock 330 72 431 minecraft:red_concrete
setblock 330 72 438 minecraft:red_concrete
setblock 330 72 445 minecraft:red_concrete
setblock 330 72 452 minecraft:red_concrete
setblock 332 72 457 minecraft:red_concrete
setblock 337 72 417 minecraft:red_concrete
setblock 339 72 457 minecraft:red_concrete
setblock 344 72 417 minecraft:red_concrete
setblock 346 72 457 minecraft:red_concrete
setblock 351 72 417 minecraft:red_concrete
setblock 353 72 457 minecraft:red_concrete
setblock 358 72 417 minecraft:red_concrete
setblock 360 72 457 minecraft:red_concrete
setblock 365 72 417 minecraft:red_concrete
setblock 367 72 457 minecraft:red_concrete
setblock 370 72 419 minecraft:red_concrete
setblock 370 72 426 minecraft:red_concrete
setblock 370 72 433 minecraft:red_concrete
setblock 370 72 440 minecraft:red_concrete
setblock 370 72 447 minecraft:red_concrete
setblock 370 72 454 minecraft:red_concrete
setblock 330 73 418 minecraft:red_concrete
setblock 330 73 425 minecraft:red_concrete
setblock 330 73 432 minecraft:red_concrete
setblock 330 73 439 minecraft:red_concrete
setblock 330 73 446 minecraft:red_concrete
setblock 330 73 453 minecraft:red_concrete
setblock 333 73 457 minecraft:red_concrete
setblock 336 73 417 minecraft:red_concrete
setblock 340 73 457 minecraft:red_concrete
setblock 343 73 417 minecraft:red_concrete
setblock 347 73 457 minecraft:red_concrete
setblock 350 73 417 minecraft:red_concrete
setblock 354 73 457 minecraft:red_concrete
setblock 357 73 417 minecraft:red_concrete
setblock 361 73 457 minecraft:red_concrete
setblock 364 73 417 minecraft:red_concrete
fill 368 73 428 368 75 431 minecraft:red_wool
setblock 368 73 457 minecraft:red_concrete
setblock 370 73 418 minecraft:red_concrete
setblock 370 73 425 minecraft:red_concrete
setblock 370 73 432 minecraft:red_concrete
setblock 370 73 439 minecraft:red_concrete
setblock 370 73 446 minecraft:red_concrete
setblock 370 73 453 minecraft:red_concrete
setblock 330 74 419 minecraft:red_concrete
setblock 330 74 426 minecraft:red_concrete
setblock 330 74 433 minecraft:red_concrete
setblock 330 74 440 minecraft:red_concrete
setblock 330 74 447 minecraft:red_concrete
setblock 330 74 454 minecraft:red_concrete
setblock 334 74 457 minecraft:red_concrete
setblock 335 74 417 minecraft:red_concrete
setblock 341 74 457 minecraft:red_concrete
setblock 342 74 417 minecraft:red_concrete
setblock 348 74 457 minecraft:red_concrete
setblock 349 74 417 minecraft:red_concrete
setblock 355 74 457 minecraft:red_concrete
setblock 356 74 417 minecraft:red_concrete
setblock 362 74 457 minecraft:red_concrete
setblock 363 74 417 minecraft:red_concrete
setblock 369 74 457 minecraft:red_concrete
setblock 370 74 417 minecraft:red_concrete
setblock 370 74 424 minecraft:red_concrete
setblock 370 74 431 minecraft:red_concrete
setblock 370 74 438 minecraft:red_concrete
setblock 370 74 445 minecraft:red_concrete
setblock 370 74 452 minecraft:red_concrete
setblock 330 75 420 minecraft:red_concrete
setblock 330 75 427 minecraft:red_concrete
setblock 330 75 434 minecraft:red_concrete
setblock 330 75 441 minecraft:red_concrete
setblock 330 75 448 minecraft:red_concrete
setblock 330 75 455 minecraft:red_concrete
setblock 334 75 417 minecraft:red_concrete
setblock 335 75 457 minecraft:red_concrete
setblock 341 75 417 minecraft:red_concrete
setblock 342 75 457 minecraft:red_concrete
setblock 348 75 417 minecraft:red_concrete
setblock 349 75 457 minecraft:red_concrete
setblock 355 75 417 minecraft:red_concrete
setblock 356 75 457 minecraft:red_concrete
setblock 362 75 417 minecraft:red_concrete
setblock 363 75 457 minecraft:red_concrete
setblock 369 75 417 minecraft:red_concrete
setblock 370 75 423 minecraft:red_concrete
setblock 370 75 430 minecraft:red_concrete
setblock 370 75 437 minecraft:red_concrete
setblock 370 75 444 minecraft:red_concrete
setblock 370 75 451 minecraft:red_concrete
setblock 370 75 457 minecraft:red_concrete
setblock 330 76 421 minecraft:red_concrete
setblock 330 76 428 minecraft:red_concrete
setblock 330 76 435 minecraft:red_concrete
setblock 330 76 442 minecraft:red_concrete
setblock 330 76 449 minecraft:red_concrete
setblock 330 76 456 minecraft:red_concrete
setblock 333 76 417 minecraft:red_concrete
setblock 336 76 457 minecraft:red_concrete
setblock 340 76 417 minecraft:red_concrete
setblock 343 76 457 minecraft:red_concrete
setblock 347 76 417 minecraft:red_concrete
setblock 350 76 457 minecraft:red_concrete
setblock 354 76 417 minecraft:red_concrete
setblock 357 76 457 minecraft:red_concrete
setblock 361 76 417 minecraft:red_concrete
setblock 364 76 457 minecraft:red_concrete
setblock 368 76 417 minecraft:red_concrete
fill 368 76 426 368 77 432 minecraft:gray_concrete
setblock 370 76 422 minecraft:red_concrete
setblock 370 76 429 minecraft:red_concrete
setblock 370 76 436 minecraft:red_concrete
setblock 370 76 443 minecraft:red_concrete
setblock 370 76 450 minecraft:red_concrete
fill 363 77 440 367 78 444 minecraft:black_concrete
fill 368 77 442 369 77 442 minecraft:black_concrete
setblock 330 78 423 minecraft:red_concrete
setblock 330 78 430 minecraft:red_concrete
setblock 330 78 437 minecraft:red_concrete
setblock 330 78 444 minecraft:red_concrete
setblock 330 78 451 minecraft:red_concrete
setblock 331 78 417 minecraft:red_concrete
setblock 331 78 457 minecraft:red_concrete
setblock 332 78 419 minecraft:light[level=12]
setblock 332 78 427 minecraft:light[level=12]
setblock 332 78 435 minecraft:light[level=12]
setblock 332 78 443 minecraft:light[level=12]
setblock 332 78 451 minecraft:light[level=12]
setblock 338 78 417 minecraft:red_concrete
setblock 338 78 457 minecraft:red_concrete
setblock 340 78 419 minecraft:light[level=12]
setblock 340 78 427 minecraft:light[level=12]
setblock 340 78 435 minecraft:light[level=12]
setblock 340 78 443 minecraft:light[level=12]
setblock 340 78 451 minecraft:light[level=12]
setblock 345 78 417 minecraft:red_concrete
setblock 345 78 457 minecraft:red_concrete
setblock 348 78 419 minecraft:light[level=12]
setblock 348 78 427 minecraft:light[level=12]
setblock 348 78 435 minecraft:light[level=12]
setblock 348 78 443 minecraft:light[level=12]
setblock 348 78 451 minecraft:light[level=12]
setblock 352 78 417 minecraft:red_concrete
setblock 352 78 457 minecraft:red_concrete
setblock 356 78 419 minecraft:light[level=12]
setblock 356 78 427 minecraft:light[level=12]
setblock 356 78 435 minecraft:light[level=12]
setblock 356 78 443 minecraft:light[level=12]
setblock 356 78 451 minecraft:light[level=12]
setblock 359 78 417 minecraft:red_concrete
setblock 359 78 457 minecraft:red_concrete
setblock 364 78 419 minecraft:light[level=12]
setblock 364 78 427 minecraft:light[level=12]
setblock 364 78 435 minecraft:light[level=12]
setblock 364 78 451 minecraft:light[level=12]
setblock 366 78 417 minecraft:red_concrete
setblock 366 78 457 minecraft:red_concrete
setblock 370 78 420 minecraft:red_concrete
setblock 370 78 427 minecraft:red_concrete
setblock 370 78 434 minecraft:red_concrete
setblock 370 78 441 minecraft:red_concrete
setblock 370 78 448 minecraft:red_concrete
setblock 370 78 455 minecraft:red_concrete
fill 330 79 417 330 80 417 minecraft:red_concrete
fill 330 79 424 330 80 424 minecraft:red_concrete
fill 330 79 431 330 80 431 minecraft:red_concrete
fill 330 79 438 330 80 438 minecraft:red_concrete
fill 330 79 445 330 80 445 minecraft:red_concrete
fill 330 79 452 330 80 452 minecraft:red_concrete
fill 332 79 457 332 80 457 minecraft:red_concrete
fill 337 79 417 337 80 417 minecraft:red_concrete
fill 339 79 457 339 80 457 minecraft:red_concrete
fill 344 79 417 344 80 417 minecraft:red_concrete
fill 346 79 457 346 80 457 minecraft:red_concrete
fill 351 79 417 351 80 417 minecraft:red_concrete
fill 353 79 457 353 80 457 minecraft:red_concrete
fill 358 79 417 358 80 417 minecraft:red_concrete
fill 360 79 457 360 80 457 minecraft:red_concrete
fill 365 79 417 365 80 417 minecraft:red_concrete
fill 365 79 442 365 84 442 minecraft:bone_block
fill 367 79 457 367 80 457 minecraft:red_concrete
fill 370 79 419 370 80 419 minecraft:red_concrete
fill 370 79 426 370 80 426 minecraft:red_concrete
fill 370 79 433 370 80 433 minecraft:red_concrete
fill 370 79 440 370 80 440 minecraft:red_concrete
fill 370 79 447 370 80 447 minecraft:red_concrete
fill 370 79 454 370 80 454 minecraft:red_concrete
fill 330 80 418 330 80 421 minecraft:red_concrete
setblock 330 80 423 minecraft:red_concrete
fill 330 80 425 330 80 428 minecraft:red_concrete
setblock 330 80 430 minecraft:red_concrete
fill 330 80 432 330 80 435 minecraft:red_concrete
setblock 330 80 437 minecraft:red_concrete
fill 330 80 439 330 80 442 minecraft:red_concrete
setblock 330 80 444 minecraft:red_concrete
fill 330 80 446 330 80 449 minecraft:red_concrete
setblock 330 80 451 minecraft:red_concrete
fill 330 80 453 330 80 456 minecraft:red_concrete
setblock 331 80 417 minecraft:red_concrete
setblock 331 80 457 minecraft:red_concrete
fill 333 80 417 336 80 417 minecraft:red_concrete
fill 333 80 457 336 80 457 minecraft:red_concrete
setblock 338 80 417 minecraft:red_concrete
setblock 338 80 457 minecraft:red_concrete
fill 340 80 417 343 80 417 minecraft:red_concrete
fill 340 80 457 343 80 457 minecraft:red_concrete
setblock 345 80 417 minecraft:red_concrete
setblock 345 80 457 minecraft:red_concrete
fill 347 80 417 350 80 417 minecraft:red_concrete
fill 347 80 457 350 80 457 minecraft:red_concrete
setblock 352 80 417 minecraft:red_concrete
setblock 352 80 457 minecraft:red_concrete
fill 354 80 417 357 80 417 minecraft:red_concrete
fill 354 80 457 357 80 457 minecraft:red_concrete
setblock 359 80 417 minecraft:red_concrete
setblock 359 80 457 minecraft:red_concrete
fill 361 80 417 364 80 417 minecraft:red_concrete
fill 361 80 457 364 80 457 minecraft:red_concrete
fill 363 80 441 364 83 443 minecraft:bone_block
fill 364 80 440 366 83 440 minecraft:bone_block
fill 364 80 444 366 83 444 minecraft:bone_block
fill 365 80 441 367 83 441 minecraft:bone_block
fill 365 80 443 367 83 443 minecraft:bone_block
setblock 366 80 417 minecraft:red_concrete
fill 366 80 442 367 83 442 minecraft:bone_block
setblock 366 80 457 minecraft:red_concrete
fill 368 80 417 370 80 417 minecraft:red_concrete
fill 368 80 457 370 80 457 minecraft:red_concrete
setblock 370 80 418 minecraft:red_concrete
setblock 370 80 420 minecraft:red_concrete
fill 370 80 422 370 80 425 minecraft:red_concrete
setblock 370 80 427 minecraft:red_concrete
fill 370 80 429 370 80 432 minecraft:red_concrete
setblock 370 80 434 minecraft:red_concrete
fill 370 80 436 370 80 439 minecraft:red_concrete
setblock 370 80 441 minecraft:red_concrete
fill 370 80 443 370 80 446 minecraft:red_concrete
setblock 370 80 448 minecraft:red_concrete
fill 370 80 450 370 80 453 minecraft:red_concrete
setblock 370 80 455 minecraft:red_concrete
setblock 330 81 419 minecraft:red_concrete
setblock 330 81 426 minecraft:red_concrete
setblock 330 81 433 minecraft:red_concrete
setblock 330 81 440 minecraft:red_concrete
setblock 330 81 447 minecraft:red_concrete
setblock 330 81 454 minecraft:red_concrete
setblock 334 81 457 minecraft:red_concrete
setblock 335 81 417 minecraft:red_concrete
setblock 341 81 457 minecraft:red_concrete
setblock 342 81 417 minecraft:red_concrete
setblock 348 81 457 minecraft:red_concrete
setblock 349 81 417 minecraft:red_concrete
setblock 355 81 457 minecraft:red_concrete
setblock 356 81 417 minecraft:red_concrete
setblock 362 81 457 minecraft:red_concrete
setblock 363 81 417 minecraft:red_concrete
setblock 369 81 457 minecraft:red_concrete
setblock 370 81 417 minecraft:red_concrete
setblock 370 81 424 minecraft:red_concrete
setblock 370 81 431 minecraft:red_concrete
setblock 370 81 438 minecraft:red_concrete
setblock 370 81 445 minecraft:red_concrete
setblock 370 81 452 minecraft:red_concrete
setblock 330 82 420 minecraft:red_concrete
setblock 330 82 427 minecraft:red_concrete
setblock 330 82 434 minecraft:red_concrete
setblock 330 82 441 minecraft:red_concrete
setblock 330 82 448 minecraft:red_concrete
setblock 330 82 455 minecraft:red_concrete
setblock 334 82 417 minecraft:red_concrete
setblock 335 82 457 minecraft:red_concrete
setblock 341 82 417 minecraft:red_concrete
setblock 342 82 457 minecraft:red_concrete
setblock 348 82 417 minecraft:red_concrete
setblock 349 82 457 minecraft:red_concrete
setblock 355 82 417 minecraft:red_concrete
setblock 356 82 457 minecraft:red_concrete
setblock 362 82 417 minecraft:red_concrete
setblock 363 82 457 minecraft:red_concrete
setblock 369 82 417 minecraft:red_concrete
setblock 370 82 423 minecraft:red_concrete
setblock 370 82 430 minecraft:red_concrete
setblock 370 82 437 minecraft:red_concrete
setblock 370 82 444 minecraft:red_concrete
setblock 370 82 451 minecraft:red_concrete
setblock 370 82 457 minecraft:red_concrete
setblock 330 83 421 minecraft:red_concrete
setblock 330 83 428 minecraft:red_concrete
setblock 330 83 435 minecraft:red_concrete
setblock 330 83 442 minecraft:red_concrete
setblock 330 83 449 minecraft:red_concrete
setblock 330 83 456 minecraft:red_concrete
setblock 333 83 417 minecraft:red_concrete
setblock 336 83 457 minecraft:red_concrete
setblock 340 83 417 minecraft:red_concrete
setblock 343 83 457 minecraft:red_concrete
setblock 347 83 417 minecraft:red_concrete
setblock 350 83 457 minecraft:red_concrete
setblock 354 83 417 minecraft:red_concrete
setblock 357 83 457 minecraft:red_concrete
setblock 361 83 417 minecraft:red_concrete
setblock 364 83 457 minecraft:red_concrete
setblock 368 83 417 minecraft:red_concrete
setblock 370 83 422 minecraft:red_concrete
setblock 370 83 429 minecraft:red_concrete
setblock 370 83 436 minecraft:red_concrete
setblock 370 83 443 minecraft:red_concrete
setblock 370 83 450 minecraft:red_concrete
setblock 330 85 423 minecraft:red_concrete
setblock 330 85 430 minecraft:red_concrete
setblock 330 85 437 minecraft:red_concrete
setblock 330 85 444 minecraft:red_concrete
setblock 330 85 451 minecraft:red_concrete
setblock 331 85 417 minecraft:red_concrete
setblock 331 85 457 minecraft:red_concrete
setblock 338 85 417 minecraft:red_concrete
setblock 338 85 457 minecraft:red_concrete
setblock 345 85 417 minecraft:red_concrete
setblock 345 85 457 minecraft:red_concrete
setblock 352 85 417 minecraft:red_concrete
setblock 352 85 457 minecraft:red_concrete
setblock 359 85 417 minecraft:red_concrete
setblock 359 85 457 minecraft:red_concrete
setblock 366 85 417 minecraft:red_concrete
setblock 366 85 457 minecraft:red_concrete
setblock 370 85 420 minecraft:red_concrete
setblock 370 85 427 minecraft:red_concrete
setblock 370 85 434 minecraft:red_concrete
setblock 370 85 441 minecraft:red_concrete
setblock 370 85 448 minecraft:red_concrete
setblock 370 85 455 minecraft:red_concrete
setblock 330 86 417 minecraft:red_concrete
setblock 330 86 424 minecraft:red_concrete
setblock 330 86 431 minecraft:red_concrete
setblock 330 86 438 minecraft:red_concrete
setblock 330 86 445 minecraft:red_concrete
setblock 330 86 452 minecraft:red_concrete
setblock 332 86 419 minecraft:light[level=12]
setblock 332 86 427 minecraft:light[level=12]
setblock 332 86 435 minecraft:light[level=12]
setblock 332 86 443 minecraft:light[level=12]
setblock 332 86 451 minecraft:light[level=12]
setblock 332 86 457 minecraft:red_concrete
setblock 337 86 417 minecraft:red_concrete
setblock 339 86 457 minecraft:red_concrete
setblock 340 86 419 minecraft:light[level=12]
setblock 340 86 427 minecraft:light[level=12]
setblock 340 86 435 minecraft:light[level=12]
setblock 340 86 443 minecraft:light[level=12]
setblock 340 86 451 minecraft:light[level=12]
setblock 344 86 417 minecraft:red_concrete
setblock 346 86 457 minecraft:red_concrete
setblock 348 86 419 minecraft:light[level=12]
fill 348 86 423 348 87 423 minecraft:red_wool
setblock 348 86 427 minecraft:light[level=12]
setblock 348 86 435 minecraft:light[level=12]
setblock 348 86 443 minecraft:light[level=12]
setblock 348 86 451 minecraft:light[level=12]
setblock 351 86 417 minecraft:red_concrete
setblock 353 86 457 minecraft:red_concrete
setblock 356 86 419 minecraft:light[level=12]
setblock 356 86 427 minecraft:light[level=12]
setblock 356 86 435 minecraft:light[level=12]
setblock 356 86 443 minecraft:light[level=12]
setblock 356 86 451 minecraft:light[level=12]
setblock 358 86 417 minecraft:red_concrete
setblock 360 86 457 minecraft:red_concrete
setblock 364 86 419 minecraft:light[level=12]
setblock 364 86 427 minecraft:light[level=12]
setblock 364 86 435 minecraft:light[level=12]
setblock 364 86 443 minecraft:light[level=12]
setblock 364 86 451 minecraft:light[level=12]
setblock 365 86 417 minecraft:red_concrete
setblock 367 86 457 minecraft:red_concrete
setblock 370 86 419 minecraft:red_concrete
setblock 370 86 426 minecraft:red_concrete
setblock 370 86 433 minecraft:red_concrete
setblock 370 86 440 minecraft:red_concrete
setblock 370 86 447 minecraft:red_concrete
setblock 370 86 454 minecraft:red_concrete
setblock 330 87 418 minecraft:red_concrete
setblock 330 87 425 minecraft:red_concrete
setblock 330 87 432 minecraft:red_concrete
setblock 330 87 439 minecraft:red_concrete
setblock 330 87 446 minecraft:red_concrete
setblock 330 87 453 minecraft:red_concrete
setblock 333 87 457 minecraft:red_concrete
setblock 336 87 417 minecraft:red_concrete
setblock 340 87 457 minecraft:red_concrete
setblock 343 87 417 minecraft:red_concrete
setblock 347 87 457 minecraft:red_concrete
setblock 350 87 417 minecraft:red_concrete
setblock 354 87 457 minecraft:red_concrete
setblock 357 87 417 minecraft:red_concrete
setblock 361 87 457 minecraft:red_concrete
setblock 364 87 417 minecraft:red_concrete
setblock 368 87 457 minecraft:red_concrete
setblock 370 87 418 minecraft:red_concrete
setblock 370 87 425 minecraft:red_concrete
setblock 370 87 432 minecraft:red_concrete
setblock 370 87 439 minecraft:red_concrete
setblock 370 87 446 minecraft:red_concrete
setblock 370 87 453 minecraft:red_concrete
setblock 330 88 419 minecraft:red_concrete
setblock 330 88 426 minecraft:red_concrete
setblock 330 88 433 minecraft:red_concrete
setblock 330 88 440 minecraft:red_concrete
setblock 330 88 447 minecraft:red_concrete
setblock 330 88 454 minecraft:red_concrete
setblock 334 88 457 minecraft:red_concrete
setblock 335 88 417 minecraft:red_concrete
setblock 341 88 457 minecraft:red_concrete
setblock 342 88 417 minecraft:red_concrete
setblock 348 88 457 minecraft:red_concrete
setblock 349 88 417 minecraft:red_concrete
setblock 355 88 457 minecraft:red_concrete
setblock 356 88 417 minecraft:red_concrete
setblock 362 88 457 minecraft:red_concrete
setblock 363 88 417 minecraft:red_concrete
setblock 369 88 457 minecraft:red_concrete
setblock 370 88 417 minecraft:red_concrete
setblock 370 88 424 minecraft:red_concrete
setblock 370 88 431 minecraft:red_concrete
setblock 370 88 438 minecraft:red_concrete
setblock 370 88 445 minecraft:red_concrete
setblock 370 88 452 minecraft:red_concrete
fill 330 89 420 330 90 420 minecraft:red_concrete
fill 330 89 427 330 90 427 minecraft:red_concrete
fill 330 89 434 330 90 434 minecraft:red_concrete
fill 330 89 441 330 90 441 minecraft:red_concrete
fill 330 89 448 330 90 448 minecraft:red_concrete
fill 330 89 455 330 90 455 minecraft:red_concrete
fill 334 89 417 334 90 417 minecraft:red_concrete
fill 335 89 457 335 90 457 minecraft:red_concrete
fill 341 89 417 341 90 417 minecraft:red_concrete
fill 342 89 457 342 90 457 minecraft:red_concrete
fill 348 89 417 348 90 417 minecraft:red_concrete
fill 349 89 457 349 90 457 minecraft:red_concrete
fill 355 89 417 355 90 417 minecraft:red_concrete
fill 356 89 457 356 90 457 minecraft:red_concrete
fill 362 89 417 362 90 417 minecraft:red_concrete
fill 363 89 457 363 90 457 minecraft:red_concrete
fill 369 89 417 369 90 417 minecraft:red_concrete
fill 370 89 423 370 90 423 minecraft:red_concrete
fill 370 89 430 370 90 430 minecraft:red_concrete
fill 370 89 437 370 90 437 minecraft:red_concrete
fill 370 89 444 370 90 444 minecraft:red_concrete
fill 370 89 451 370 90 451 minecraft:red_concrete
fill 370 89 457 370 90 457 minecraft:red_concrete
fill 330 90 417 330 90 419 minecraft:red_concrete
setblock 330 90 421 minecraft:red_concrete
fill 330 90 423 330 90 426 minecraft:red_concrete
setblock 330 90 428 minecraft:red_concrete
fill 330 90 430 330 90 433 minecraft:red_concrete
setblock 330 90 435 minecraft:red_concrete
fill 330 90 437 330 90 440 minecraft:red_concrete
setblock 330 90 442 minecraft:red_concrete
fill 330 90 444 330 90 447 minecraft:red_concrete
setblock 330 90 449 minecraft:red_concrete
fill 330 90 451 330 90 454 minecraft:red_concrete
setblock 330 90 456 minecraft:red_concrete
setblock 331 90 417 minecraft:red_concrete
fill 331 90 457 334 90 457 minecraft:red_concrete
setblock 333 90 417 minecraft:red_concrete
fill 335 90 417 338 90 417 minecraft:red_concrete
setblock 336 90 457 minecraft:red_concrete
fill 338 90 457 341 90 457 minecraft:red_concrete
setblock 340 90 417 minecraft:red_concrete
fill 342 90 417 345 90 417 minecraft:red_concrete
setblock 343 90 457 minecraft:red_concrete
fill 345 90 457 348 90 457 minecraft:red_concrete
setblock 347 90 417 minecraft:red_concrete
fill 349 90 417 352 90 417 minecraft:red_concrete
setblock 350 90 457 minecraft:red_concrete
fill 352 90 457 355 90 457 minecraft:red_concrete
setblock 354 90 417 minecraft:red_concrete
fill 356 90 417 359 90 417 minecraft:red_concrete
setblock 357 90 457 minecraft:red_concrete
fill 359 90 457 362 90 457 minecraft:red_concrete
setblock 361 90 417 minecraft:red_concrete
fill 363 90 417 366 90 417 minecraft:red_concrete
setblock 364 90 457 minecraft:red_concrete
fill 366 90 457 369 90 457 minecraft:red_concrete
setblock 368 90 417 minecraft:red_concrete
fill 370 90 417 370 90 420 minecraft:red_concrete
setblock 370 90 422 minecraft:red_concrete
fill 370 90 424 370 90 427 minecraft:red_concrete
setblock 370 90 429 minecraft:red_concrete
fill 370 90 431 370 90 434 minecraft:red_concrete
setblock 370 90 436 minecraft:red_concrete
fill 370 90 438 370 90 441 minecraft:red_concrete
setblock 370 90 443 minecraft:red_concrete
fill 370 90 445 370 90 448 minecraft:red_concrete
setblock 370 90 450 minecraft:red_concrete
fill 370 90 452 370 90 455 minecraft:red_concrete
setblock 330 92 423 minecraft:red_concrete
setblock 330 92 430 minecraft:red_concrete
setblock 330 92 437 minecraft:red_concrete
setblock 330 92 444 minecraft:red_concrete
setblock 330 92 451 minecraft:red_concrete
setblock 331 92 417 minecraft:red_concrete
setblock 331 92 457 minecraft:red_concrete
setblock 338 92 417 minecraft:red_concrete
setblock 338 92 457 minecraft:red_concrete
setblock 345 92 417 minecraft:red_concrete
setblock 345 92 457 minecraft:red_concrete
setblock 352 92 417 minecraft:red_concrete
setblock 352 92 457 minecraft:red_concrete
setblock 359 92 417 minecraft:red_concrete
setblock 359 92 457 minecraft:red_concrete
setblock 366 92 417 minecraft:red_concrete
setblock 366 92 457 minecraft:red_concrete
setblock 370 92 420 minecraft:red_concrete
setblock 370 92 427 minecraft:red_concrete
setblock 370 92 434 minecraft:red_concrete
setblock 370 92 441 minecraft:red_concrete
setblock 370 92 448 minecraft:red_concrete
setblock 370 92 455 minecraft:red_concrete
setblock 330 93 417 minecraft:red_concrete
setblock 330 93 424 minecraft:red_concrete
setblock 330 93 431 minecraft:red_concrete
fill 330 93 434 336 93 434 minecraft:black_concrete
setblock 330 93 438 minecraft:red_concrete
setblock 330 93 445 minecraft:red_concrete
setblock 330 93 452 minecraft:red_concrete
fill 332 93 432 336 94 433 minecraft:black_concrete
fill 332 93 435 336 94 436 minecraft:black_concrete
setblock 332 93 457 minecraft:red_concrete
setblock 337 93 417 minecraft:red_concrete
setblock 339 93 457 minecraft:red_concrete
setblock 344 93 417 minecraft:red_concrete
setblock 346 93 457 minecraft:red_concrete
setblock 351 93 417 minecraft:red_concrete
setblock 353 93 457 minecraft:red_concrete
setblock 358 93 417 minecraft:red_concrete
setblock 360 93 457 minecraft:red_concrete
setblock 365 93 417 minecraft:red_concrete
setblock 367 93 457 minecraft:red_concrete
setblock 370 93 419 minecraft:red_concrete
setblock 370 93 426 minecraft:red_concrete
setblock 370 93 433 minecraft:red_concrete
setblock 370 93 440 minecraft:red_concrete
setblock 370 93 447 minecraft:red_concrete
setblock 370 93 454 minecraft:red_concrete
setblock 330 94 418 minecraft:red_concrete
setblock 330 94 425 minecraft:red_concrete
setblock 330 94 432 minecraft:red_concrete
setblock 330 94 439 minecraft:red_concrete
setblock 330 94 446 minecraft:red_concrete
setblock 330 94 453 minecraft:red_concrete
setblock 332 94 419 minecraft:light[level=12]
setblock 332 94 427 minecraft:light[level=12]
fill 332 94 434 336 94 434 minecraft:black_concrete
setblock 332 94 443 minecraft:light[level=12]
setblock 332 94 451 minecraft:light[level=12]
setblock 333 94 457 minecraft:red_concrete
setblock 336 94 417 minecraft:red_concrete
setblock 340 94 419 minecraft:light[level=12]
setblock 340 94 427 minecraft:light[level=12]
setblock 340 94 435 minecraft:light[level=12]
setblock 340 94 443 minecraft:light[level=12]
setblock 340 94 451 minecraft:light[level=12]
setblock 340 94 457 minecraft:red_concrete
setblock 343 94 417 minecraft:red_concrete
setblock 347 94 457 minecraft:red_concrete
setblock 348 94 419 minecraft:light[level=12]
setblock 348 94 427 minecraft:light[level=12]
setblock 348 94 435 minecraft:light[level=12]
setblock 348 94 443 minecraft:light[level=12]
setblock 348 94 451 minecraft:light[level=12]
setblock 350 94 417 minecraft:red_concrete
setblock 354 94 457 minecraft:red_concrete
setblock 356 94 419 minecraft:light[level=12]
setblock 356 94 427 minecraft:light[level=12]
setblock 356 94 435 minecraft:light[level=12]
setblock 356 94 443 minecraft:light[level=12]
setblock 356 94 451 minecraft:light[level=12]
setblock 357 94 417 minecraft:red_concrete
setblock 361 94 457 minecraft:red_concrete
setblock 364 94 417 minecraft:red_concrete
setblock 364 94 419 minecraft:light[level=12]
setblock 364 94 427 minecraft:light[level=12]
setblock 364 94 435 minecraft:light[level=12]
setblock 364 94 443 minecraft:light[level=12]
setblock 364 94 451 minecraft:light[level=12]
setblock 368 94 457 minecraft:red_concrete
setblock 370 94 418 minecraft:red_concrete
setblock 370 94 425 minecraft:red_concrete
setblock 370 94 432 minecraft:red_concrete
setblock 370 94 439 minecraft:red_concrete
setblock 370 94 446 minecraft:red_concrete
setblock 370 94 453 minecraft:red_concrete
setblock 330 95 419 minecraft:red_concrete
setblock 330 95 426 minecraft:red_concrete
setblock 330 95 433 minecraft:red_concrete
setblock 330 95 440 minecraft:red_concrete
setblock 330 95 447 minecraft:red_concrete
setblock 330 95 454 minecraft:red_concrete
setblock 334 95 434 minecraft:bone_block
setblock 334 95 457 minecraft:red_concrete
setblock 335 95 417 minecraft:red_concrete
setblock 341 95 457 minecraft:red_concrete
setblock 342 95 417 minecraft:red_concrete
setblock 348 95 457 minecraft:red_concrete
setblock 349 95 417 minecraft:red_concrete
setblock 355 95 457 minecraft:red_concrete
setblock 356 95 417 minecraft:red_concrete
setblock 362 95 457 minecraft:red_concrete
setblock 363 95 417 minecraft:red_concrete
setblock 369 95 457 minecraft:red_concrete
setblock 370 95 417 minecraft:red_concrete
setblock 370 95 424 minecraft:red_concrete
setblock 370 95 431 minecraft:red_concrete
setblock 370 95 438 minecraft:red_concrete
setblock 370 95 445 minecraft:red_concrete
setblock 370 95 452 minecraft:red_concrete
fill 346 100 442 348 100 444 minecraft:redstone_block
fill 350 100 434 352 100 436 minecraft:redstone_block
fill 353 100 443 355 100 445 minecraft:redstone_block
fill 355 100 438 357 100 440 minecraft:redstone_block
fill 335 101 440 340 102 440 minecraft:red_concrete
fill 336 101 435 340 102 439 minecraft:red_concrete
fill 336 101 441 339 102 445 minecraft:red_concrete
fill 337 101 433 337 102 433 minecraft:white_concrete
fill 337 101 434 349 101 434 minecraft:red_concrete
fill 337 101 446 339 102 447 minecraft:red_concrete
fill 338 101 431 338 102 432 minecraft:white_concrete
fill 338 101 433 353 101 433 minecraft:red_concrete
fill 338 101 448 339 102 449 minecraft:red_concrete
fill 339 101 430 340 102 431 minecraft:white_concrete
fill 339 101 432 352 102 432 minecraft:red_concrete
fill 339 101 450 340 102 450 minecraft:red_concrete
fill 340 101 429 355 102 429 minecraft:white_concrete
fill 340 101 441 343 102 449 minecraft:white_concrete
fill 340 101 451 340 102 451 minecraft:red_concrete
fill 341 101 428 353 102 428 minecraft:white_concrete
fill 341 101 430 342 102 430 minecraft:white_concrete
fill 341 101 431 351 102 431 minecraft:red_concrete
fill 341 101 435 341 102 438 minecraft:red_concrete
fill 341 101 439 344 102 440 minecraft:white_concrete
fill 341 101 450 344 102 451 minecraft:white_concrete
fill 341 101 452 341 102 452 minecraft:red_concrete
fill 342 101 427 352 102 427 minecraft:white_concrete
fill 342 101 435 342 102 437 minecraft:red_concrete
fill 342 101 438 348 102 438 minecraft:white_concrete
fill 342 101 452 346 102 453 minecraft:white_concrete
fill 343 101 430 349 102 430 minecraft:red_concrete
fill 343 101 435 344 102 436 minecraft:red_concrete
fill 343 101 437 349 101 437 minecraft:white_concrete
fill 344 101 426 349 102 426 minecraft:white_concrete
fill 344 101 441 345 101 448 minecraft:red_concrete
fill 344 101 449 344 102 449 minecraft:white_concrete
fill 344 101 454 348 102 454 minecraft:white_concrete
fill 345 101 435 349 101 435 minecraft:red_concrete
fill 345 101 436 349 101 436 minecraft:white_concrete
fill 345 101 439 345 102 439 minecraft:white_concrete
fill 345 101 440 347 102 440 minecraft:red_concrete
fill 345 101 449 353 102 450 minecraft:red_concrete
fill 345 101 451 345 102 451 minecraft:white_concrete
fill 346 101 425 356 102 425 minecraft:red_concrete
fill 346 101 439 347 102 439 minecraft:red_concrete
fill 346 101 441 347 101 441 minecraft:red_concrete
fill 346 101 445 348 101 448 minecraft:red_concrete
fill 346 101 451 362 102 451 minecraft:red_concrete
fill 346 101 455 351 102 455 minecraft:white_concrete
fill 347 101 452 361 102 452 minecraft:red_concrete
fill 347 101 453 347 102 453 minecraft:white_concrete
fill 348 101 439 349 101 441 minecraft:black_concrete
fill 348 101 453 360 102 453 minecraft:red_concrete
fill 349 101 438 353 101 438 minecraft:black_concrete
fill 349 101 442 353 101 442 minecraft:black_concrete
fill 349 101 443 349 101 445 minecraft:white_concrete
fill 349 101 446 349 102 448 minecraft:red_concrete
fill 349 101 454 358 102 454 minecraft:red_concrete
fill 350 101 426 358 102 426 minecraft:red_concrete
fill 350 101 430 355 102 430 minecraft:white_concrete
fill 350 101 437 352 101 437 minecraft:black_concrete
fill 350 101 443 352 101 443 minecraft:black_concrete
fill 350 101 444 351 102 447 minecraft:white_concrete
fill 350 101 448 351 102 448 minecraft:red_concrete
fill 351 101 424 351 102 424 minecraft:red_concrete
fill 351 101 456 351 102 456 minecraft:white_concrete
fill 352 101 431 356 102 431 minecraft:white_concrete
setblock 352 101 444 minecraft:red_concrete
fill 352 101 445 352 101 448 minecraft:white_concrete
fill 352 101 455 356 102 455 minecraft:red_concrete
fill 353 101 427 360 102 427 minecraft:red_concrete
fill 353 101 432 357 102 432 minecraft:white_concrete
fill 353 101 434 353 101 437 minecraft:red_concrete
fill 353 101 439 354 101 441 minecraft:black_concrete
fill 353 101 446 360 101 448 minecraft:white_concrete
fill 354 101 428 361 102 428 minecraft:red_concrete
fill 354 101 433 357 102 434 minecraft:white_concrete
fill 354 101 435 354 101 438 minecraft:red_concrete
fill 354 101 442 361 101 442 minecraft:red_concrete
fill 354 101 449 358 102 449 minecraft:white_concrete
fill 354 101 450 363 102 450 minecraft:red_concrete
fill 355 101 435 357 101 437 minecraft:white_concrete
fill 355 101 441 362 101 441 minecraft:red_concrete
fill 356 101 429 362 102 430 minecraft:red_concrete
fill 356 101 443 358 101 445 minecraft:red_concrete
fill 357 101 431 363 102 431 minecraft:red_concrete
fill 358 101 432 363 101 440 minecraft:red_concrete
fill 359 101 443 359 102 444 minecraft:red_concrete
fill 359 101 445 364 102 445 minecraft:white_concrete
fill 359 101 449 364 102 449 minecraft:red_concrete
fill 360 101 443 361 102 443 minecraft:red_concrete
fill 360 101 444 365 102 444 minecraft:white_concrete
fill 361 101 446 362 102 447 minecraft:white_concrete
fill 361 101 448 364 102 448 minecraft:red_concrete
fill 362 101 442 366 102 443 minecraft:white_concrete
fill 363 101 430 363 102 430 minecraft:red_concrete
fill 363 101 441 366 102 441 minecraft:white_concrete
fill 363 101 446 363 102 446 minecraft:white_concrete
fill 363 101 447 365 102 447 minecraft:red_concrete
fill 364 101 431 364 102 432 minecraft:white_concrete
fill 364 101 433 364 102 436 minecraft:red_concrete
fill 364 101 437 366 102 440 minecraft:white_concrete
fill 364 101 446 365 102 446 minecraft:red_concrete
fill 365 101 433 365 102 436 minecraft:white_concrete
fill 365 101 445 366 102 445 minecraft:red_concrete
fill 366 101 435 366 102 436 minecraft:white_concrete
fill 366 101 444 366 102 444 minecraft:red_concrete
fill 367 101 440 367 102 440 minecraft:white_concrete
fill 330 102 417 334 102 457 minecraft:purple_concrete
fill 335 102 417 335 102 439 minecraft:purple_concrete
fill 335 102 441 335 102 457 minecraft:purple_concrete
fill 336 102 417 336 102 434 minecraft:purple_concrete
fill 336 102 446 336 102 457 minecraft:purple_concrete
fill 337 102 417 337 102 432 minecraft:purple_concrete
fill 337 102 434 348 102 434 minecraft:red_concrete
fill 337 102 448 337 102 457 minecraft:purple_concrete
fill 338 102 417 338 102 430 minecraft:purple_concrete
fill 338 102 433 348 102 433 minecraft:red_concrete
fill 338 102 450 338 102 457 minecraft:purple_concrete
fill 339 102 417 339 102 429 minecraft:purple_concrete
fill 339 102 451 339 102 457 minecraft:purple_concrete
fill 340 102 417 340 102 428 minecraft:purple_concrete
fill 340 102 452 340 102 457 minecraft:purple_concrete
fill 341 102 417 341 102 427 minecraft:purple_concrete
fill 341 102 453 341 102 457 minecraft:purple_concrete
fill 342 102 417 343 102 426 minecraft:purple_concrete
fill 342 102 454 343 102 457 minecraft:purple_concrete
fill 343 102 437 348 102 437 minecraft:white_concrete
fill 344 102 417 345 102 425 minecraft:purple_concrete
fill 344 102 441 344 102 448 minecraft:red_concrete
fill 344 102 455 345 102 457 minecraft:purple_concrete
fill 345 102 435 348 102 435 minecraft:red_concrete
fill 345 102 436 348 102 436 minecraft:white_concrete
fill 345 102 441 345 102 445 minecraft:jack_o_lantern
fill 345 102 446 348 102 448 minecraft:red_concrete
fill 346 102 417 350 102 424 minecraft:purple_concrete
fill 346 102 441 349 102 441 minecraft:jack_o_lantern
fill 346 102 442 348 102 444 minecraft:purple_concrete
fill 346 102 445 349 102 445 minecraft:jack_o_lantern
fill 346 102 456 350 102 457 minecraft:purple_concrete
fill 348 102 439 348 102 440 minecraft:black_concrete
fill 349 102 433 349 102 440 minecraft:jack_o_lantern
fill 349 102 442 349 102 444 minecraft:jack_o_lantern
fill 350 102 433 353 102 433 minecraft:jack_o_lantern
fill 350 102 434 352 102 436 minecraft:purple_concrete
fill 350 102 437 354 102 438 minecraft:jack_o_lantern
fill 350 102 442 356 102 442 minecraft:jack_o_lantern
fill 350 102 443 351 102 443 minecraft:black_concrete
fill 351 102 417 370 102 423 minecraft:purple_concrete
fill 351 102 457 370 102 457 minecraft:purple_concrete
fill 352 102 424 370 102 424 minecraft:purple_concrete
fill 352 102 443 352 102 446 minecraft:jack_o_lantern
fill 352 102 447 360 102 448 minecraft:white_concrete
fill 352 102 456 370 102 456 minecraft:purple_concrete
fill 353 102 434 353 102 436 minecraft:jack_o_lantern
fill 353 102 439 354 102 441 minecraft:jack_o_lantern
fill 353 102 443 355 102 445 minecraft:purple_concrete
fill 353 102 446 356 102 446 minecraft:jack_o_lantern
fill 354 102 435 354 102 436 minecraft:red_concrete
fill 355 102 435 357 102 436 minecraft:white_concrete
fill 355 102 437 358 102 437 minecraft:jack_o_lantern
fill 355 102 438 357 102 440 minecraft:purple_concrete
fill 355 102 441 358 102 441 minecraft:jack_o_lantern
fill 356 102 443 356 102 445 minecraft:jack_o_lantern
fill 357 102 425 370 102 425 minecraft:purple_concrete
fill 357 102 442 358 102 445 minecraft:red_concrete
fill 357 102 446 360 102 446 minecraft:white_concrete
fill 357 102 455 370 102 455 minecraft:purple_concrete
fill 358 102 432 363 102 436 minecraft:red_concrete
fill 358 102 438 358 102 440 minecraft:jack_o_lantern
fill 359 102 426 370 102 426 minecraft:purple_concrete
fill 359 102 437 361 102 442 minecraft:red_concrete
fill 359 102 454 370 102 454 minecraft:purple_concrete
fill 361 102 427 370 102 427 minecraft:purple_concrete
fill 361 102 453 370 102 453 minecraft:purple_concrete
fill 362 102 428 370 102 428 minecraft:purple_concrete
fill 362 102 437 362 102 441 minecraft:red_concrete
fill 362 102 452 370 102 452 minecraft:purple_concrete
fill 363 102 429 370 102 429 minecraft:purple_concrete
fill 363 102 437 363 102 440 minecraft:red_concrete
fill 363 102 451 370 102 451 minecraft:purple_concrete
fill 364 102 430 370 102 430 minecraft:purple_concrete
fill 364 102 450 370 102 450 minecraft:purple_concrete
fill 365 102 431 370 102 432 minecraft:purple_concrete
fill 365 102 448 370 102 449 minecraft:purple_concrete
fill 366 102 433 370 102 434 minecraft:purple_concrete
fill 366 102 446 370 102 447 minecraft:purple_concrete
fill 367 102 435 370 102 439 minecraft:purple_concrete
fill 367 102 441 370 102 445 minecraft:purple_concrete
fill 368 102 440 370 102 440 minecraft:purple_concrete
fill 330 106 422 330 106 423 minecraft:red_concrete
fill 330 106 429 330 106 430 minecraft:red_concrete
fill 330 106 436 330 106 437 minecraft:red_concrete
fill 330 106 443 330 106 444 minecraft:red_concrete
fill 330 106 450 330 106 451 minecraft:red_concrete
fill 330 106 457 331 106 457 minecraft:red_concrete
fill 331 106 417 332 106 417 minecraft:red_concrete
fill 337 106 457 338 106 457 minecraft:red_concrete
fill 338 106 417 339 106 417 minecraft:red_concrete
fill 344 106 457 345 106 457 minecraft:red_concrete
fill 345 106 417 346 106 417 minecraft:red_concrete
fill 351 106 457 352 106 457 minecraft:red_concrete
fill 352 106 417 353 106 417 minecraft:red_concrete
fill 358 106 457 359 106 457 minecraft:red_concrete
fill 359 106 417 360 106 417 minecraft:red_concrete
fill 362 106 443 370 108 455 minecraft:red_concrete
fill 363 106 437 370 108 442 minecraft:red_concrete
fill 365 106 457 366 106 457 minecraft:red_concrete
fill 366 106 417 367 106 417 minecraft:red_concrete
fill 370 106 420 370 106 421 minecraft:red_concrete
fill 370 106 427 370 106 428 minecraft:red_concrete
fill 370 106 434 370 106 435 minecraft:red_concrete
fill 370 106 456 370 165 456 minecraft:red_concrete
fill 329 107 416 329 107 417 minecraft:black_concrete
setblock 329 107 418 minecraft:purple_terracotta
setblock 329 107 419 minecraft:black_concrete
setblock 329 107 420 minecraft:purple_terracotta
fill 329 107 421 329 108 423 minecraft:black_concrete
setblock 329 107 424 minecraft:purple_terracotta
fill 329 107 425 329 111 425 minecraft:black_concrete
fill 329 107 426 329 109 426 minecraft:purple_terracotta
fill 329 107 427 329 107 428 minecraft:black_concrete
setblock 329 107 429 minecraft:purple_terracotta
fill 329 107 430 329 107 439 minecraft:black_concrete
setblock 329 107 440 minecraft:purple_terracotta
fill 329 107 441 329 107 449 minecraft:black_concrete
setblock 329 107 450 minecraft:purple_terracotta
fill 329 107 451 329 107 455 minecraft:black_concrete
fill 329 107 456 329 107 457 minecraft:purple_terracotta
setblock 329 107 458 minecraft:black_concrete
fill 330 107 416 332 107 416 minecraft:purple_terracotta
setblock 330 107 417 minecraft:red_concrete
fill 330 107 422 330 165 422 minecraft:red_concrete
setblock 330 107 424 minecraft:red_concrete
fill 330 107 429 330 165 429 minecraft:red_concrete
setblock 330 107 431 minecraft:red_concrete
fill 330 107 436 330 165 436 minecraft:red_concrete
setblock 330 107 438 minecraft:red_concrete
fill 330 107 443 330 165 443 minecraft:red_concrete
setblock 330 107 445 minecraft:red_concrete
fill 330 107 450 330 165 450 minecraft:red_concrete
setblock 330 107 452 minecraft:red_concrete
fill 330 107 457 330 165 457 minecraft:red_concrete
fill 332 107 417 332 165 417 minecraft:red_concrete
setblock 332 107 457 minecraft:red_concrete
fill 333 107 416 344 107 416 minecraft:black_concrete
setblock 334 107 458 minecraft:purple_terracotta
fill 336 107 458 351 110 458 minecraft:black_concrete
setblock 337 107 417 minecraft:red_concrete
fill 337 107 457 337 165 457 minecraft:red_concrete
fill 339 107 417 339 165 417 minecraft:red_concrete
setblock 339 107 457 minecraft:red_concrete
setblock 344 107 417 minecraft:red_concrete
fill 344 107 457 344 165 457 minecraft:red_concrete
fill 345 107 416 345 108 416 minecraft:purple_terracotta
fill 346 107 416 357 107 416 minecraft:black_concrete
fill 346 107 417 346 165 417 minecraft:red_concrete
setblock 346 107 457 minecraft:red_concrete
setblock 351 107 417 minecraft:red_concrete
fill 351 107 457 351 165 457 minecraft:red_concrete
setblock 352 107 458 minecraft:purple_terracotta
fill 353 107 417 353 165 417 minecraft:red_concrete
setblock 353 107 457 minecraft:red_concrete
fill 353 107 458 360 108 458 minecraft:black_concrete
setblock 358 107 416 minecraft:purple_terracotta
setblock 358 107 417 minecraft:red_concrete
fill 358 107 457 358 165 457 minecraft:red_concrete
fill 359 107 416 362 110 416 minecraft:black_concrete
fill 360 107 417 360 165 417 minecraft:red_concrete
setblock 360 107 457 minecraft:red_concrete
fill 361 107 458 361 109 458 minecraft:purple_terracotta
fill 362 107 458 369 110 458 minecraft:black_concrete
setblock 363 107 416 minecraft:purple_terracotta
fill 364 107 416 365 108 416 minecraft:black_concrete
setblock 365 107 417 minecraft:red_concrete
fill 365 107 457 365 165 457 minecraft:red_concrete
setblock 366 107 416 minecraft:purple_terracotta
fill 367 107 416 371 110 416 minecraft:black_concrete
fill 367 107 417 367 165 417 minecraft:red_concrete
setblock 367 107 457 minecraft:red_concrete
setblock 370 107 419 minecraft:red_concrete
fill 370 107 421 370 165 421 minecraft:red_concrete
setblock 370 107 426 minecraft:red_concrete
fill 370 107 428 370 165 428 minecraft:red_concrete
setblock 370 107 433 minecraft:red_concrete
fill 370 107 435 370 165 435 minecraft:red_concrete
setblock 370 107 458 minecraft:purple_terracotta
fill 371 107 417 371 108 427 minecraft:black_concrete
setblock 371 107 428 minecraft:purple_terracotta
fill 371 107 429 371 107 444 minecraft:black_concrete
setblock 371 107 445 minecraft:purple_terracotta
fill 371 107 446 371 107 458 minecraft:black_concrete
setblock 329 108 416 minecraft:purple_terracotta
fill 329 108 417 329 110 418 minecraft:black_concrete
setblock 329 108 419 minecraft:purple_terracotta
fill 329 108 420 329 111 420 minecraft:black_concrete
fill 329 108 424 329 110 424 minecraft:black_concrete
setblock 329 108 427 minecraft:purple_terracotta
fill 329 108 428 329 110 430 minecraft:black_concrete
setblock 329 108 431 minecraft:purple_terracotta
fill 329 108 432 329 108 433 minecraft:black_concrete
fill 329 108 434 329 108 435 minecraft:purple_terracotta
fill 329 108 436 329 110 448 minecraft:black_concrete
setblock 329 108 449 minecraft:purple_terracotta
fill 329 108 450 329 110 450 minecraft:black_concrete
setblock 329 108 451 minecraft:purple_terracotta
fill 329 108 452 329 110 457 minecraft:black_concrete
fill 329 108 458 329 109 458 minecraft:purple_terracotta
fill 330 108 416 333 108 416 minecraft:black_concrete
setblock 330 108 418 minecraft:red_concrete
setblock 330 108 425 minecraft:red_concrete
setblock 330 108 432 minecraft:red_concrete
setblock 330 108 439 minecraft:red_concrete
setblock 330 108 446 minecraft:red_concrete
setblock 330 108 453 minecraft:red_concrete
setblock 332 108 458 minecraft:purple_terracotta
setblock 333 108 457 minecraft:red_concrete
setblock 334 108 416 minecraft:purple_terracotta
fill 334 108 458 334 110 458 minecraft:black_concrete
fill 335 108 416 341 110 416 minecraft:black_concrete
setblock 336 108 417 minecraft:red_concrete
setblock 340 108 457 minecraft:red_concrete
setblock 342 108 416 minecraft:purple_terracotta
fill 343 108 416 344 110 416 minecraft:black_concrete
setblock 343 108 417 minecraft:red_concrete
fill 346 108 416 351 110 416 minecraft:black_concrete
setblock 347 108 457 minecraft:red_concrete
setblock 350 108 417 minecraft:red_concrete
fill 352 108 416 352 109 416 minecraft:purple_terracotta
fill 352 108 458 352 110 458 minecraft:black_concrete
fill 353 108 416 353 110 416 minecraft:black_concrete
fill 354 108 416 355 108 416 minecraft:purple_terracotta
setblock 354 108 457 minecraft:red_concrete
fill 356 108 416 358 110 416 minecraft:black_concrete
setblock 357 108 417 minecraft:red_concrete
setblock 361 108 457 minecraft:red_concrete
setblock 363 108 416 minecraft:black_concrete
setblock 364 108 417 minecraft:red_concrete
fill 366 108 416 366 110 416 minecraft:black_concrete
setblock 368 108 457 minecraft:red_concrete
setblock 370 108 418 minecraft:red_concrete
setblock 370 108 425 minecraft:red_concrete
setblock 370 108 432 minecraft:red_concrete
fill 370 108 458 370 110 458 minecraft:black_concrete
fill 371 108 428 371 110 437 minecraft:black_concrete
setblock 371 108 438 minecraft:purple_terracotta
fill 371 108 439 371 110 441 minecraft:black_concrete
setblock 371 108 442 minecraft:purple_terracotta
fill 371 108 443 371 110 454 minecraft:black_concrete
setblock 371 108 455 minecraft:purple_terracotta
fill 371 108 456 371 110 457 minecraft:black_concrete
fill 371 108 458 371 109 458 minecraft:purple_terracotta
fill 329 109 416 332 110 416 minecraft:black_concrete
fill 329 109 419 329 110 419 minecraft:black_concrete
fill 329 109 421 329 110 422 minecraft:black_concrete
setblock 329 109 423 minecraft:purple_terracotta
fill 329 109 427 329 110 427 minecraft:black_concrete
fill 329 109 431 329 110 432 minecraft:black_concrete
setblock 329 109 433 minecraft:purple_terracotta
fill 329 109 434 329 110 435 minecraft:black_concrete
fill 329 109 449 329 110 449 minecraft:black_concrete
fill 329 109 451 329 110 451 minecraft:black_concrete
fill 330 109 419 330 110 419 minecraft:red_concrete
fill 330 109 426 330 110 426 minecraft:red_concrete
fill 330 109 433 330 110 433 minecraft:red_concrete
fill 330 109 440 330 110 440 minecraft:red_concrete
fill 330 109 447 330 110 447 minecraft:red_concrete
fill 330 109 454 330 110 454 minecraft:red_concrete
fill 332 109 458 332 110 458 minecraft:black_concrete
setblock 333 109 416 minecraft:purple_terracotta
fill 334 109 416 334 110 416 minecraft:black_concrete
fill 334 109 457 334 110 457 minecraft:red_concrete
fill 335 109 417 335 110 417 minecraft:red_concrete
fill 341 109 457 341 110 457 minecraft:red_concrete
fill 342 109 416 342 110 416 minecraft:black_concrete
fill 342 109 417 342 110 417 minecraft:red_concrete
fill 345 109 416 345 110 416 minecraft:black_concrete
fill 348 109 457 348 110 457 minecraft:red_concrete
fill 349 109 417 349 110 417 minecraft:red_concrete
fill 353 109 458 358 110 458 minecraft:black_concrete
fill 354 109 416 355 110 416 minecraft:black_concrete
fill 355 109 457 355 110 457 minecraft:red_concrete
fill 356 109 417 356 110 417 minecraft:red_concrete
setblock 359 109 458 minecraft:purple_terracotta
fill 360 109 458 360 110 458 minecraft:black_concrete
setblock 362 109 443 minecraft:jack_o_lantern
fill 362 109 444 362 131 444 minecraft:red_concrete
setblock 362 109 445 minecraft:jack_o_lantern
fill 362 109 446 362 131 446 minecraft:red_concrete
setblock 362 109 447 minecraft:jack_o_lantern
fill 362 109 448 362 131 448 minecraft:red_concrete
setblock 362 109 449 minecraft:jack_o_lantern
fill 362 109 450 362 131 450 minecraft:red_concrete
setblock 362 109 451 minecraft:jack_o_lantern
fill 362 109 452 362 131 452 minecraft:red_concrete
setblock 362 109 453 minecraft:jack_o_lantern
fill 362 109 454 362 131 454 minecraft:red_concrete
setblock 362 109 455 minecraft:jack_o_lantern
fill 362 109 457 362 110 457 minecraft:red_concrete
fill 363 109 416 364 109 416 minecraft:purple_terracotta
fill 363 109 417 363 110 417 minecraft:red_concrete
fill 363 109 437 363 121 437 minecraft:red_concrete
setblock 363 109 438 minecraft:jack_o_lantern
fill 363 109 439 363 121 439 minecraft:red_concrete
setblock 363 109 440 minecraft:jack_o_lantern
fill 363 109 441 363 121 441 minecraft:red_concrete
setblock 363 109 442 minecraft:jack_o_lantern
fill 363 109 443 363 131 443 minecraft:red_concrete
setblock 363 109 444 minecraft:jack_o_lantern
fill 363 109 445 363 131 445 minecraft:red_concrete
setblock 363 109 446 minecraft:jack_o_lantern
fill 363 109 447 363 131 447 minecraft:red_concrete
setblock 363 109 448 minecraft:jack_o_lantern
fill 363 109 449 363 131 449 minecraft:red_concrete
setblock 363 109 450 minecraft:jack_o_lantern
fill 363 109 451 363 131 451 minecraft:red_concrete
setblock 363 109 452 minecraft:jack_o_lantern
fill 363 109 453 363 131 453 minecraft:red_concrete
setblock 363 109 454 minecraft:jack_o_lantern
fill 363 109 455 363 131 455 minecraft:red_concrete
setblock 364 109 437 minecraft:jack_o_lantern
fill 364 109 438 364 121 438 minecraft:red_concrete
setblock 364 109 439 minecraft:jack_o_lantern
fill 364 109 440 364 121 440 minecraft:red_concrete
setblock 364 109 441 minecraft:jack_o_lantern
fill 364 109 442 364 121 442 minecraft:red_concrete
setblock 364 109 443 minecraft:jack_o_lantern
fill 364 109 444 364 121 444 minecraft:red_concrete
setblock 364 109 445 minecraft:jack_o_lantern
fill 364 109 446 364 121 446 minecraft:red_concrete
setblock 364 109 447 minecraft:jack_o_lantern
fill 364 109 448 364 121 448 minecraft:red_concrete
setblock 364 109 449 minecraft:jack_o_lantern
fill 364 109 450 364 131 450 minecraft:red_concrete
setblock 364 109 451 minecraft:jack_o_lantern
fill 364 109 452 364 131 452 minecraft:red_concrete
setblock 364 109 453 minecraft:jack_o_lantern
fill 364 109 454 364 131 454 minecraft:red_concrete
setblock 364 109 455 minecraft:jack_o_lantern
fill 365 109 416 365 110 416 minecraft:black_concrete
fill 365 109 437 365 121 437 minecraft:red_concrete
setblock 365 109 438 minecraft:jack_o_lantern
fill 365 109 439 365 121 439 minecraft:red_concrete
setblock 365 109 440 minecraft:jack_o_lantern
fill 365 109 441 365 121 441 minecraft:red_concrete
setblock 365 109 442 minecraft:jack_o_lantern
fill 365 109 443 365 121 443 minecraft:red_concrete
setblock 365 109 444 minecraft:jack_o_lantern
fill 365 109 445 365 121 445 minecraft:red_concrete
setblock 365 109 446 minecraft:jack_o_lantern
fill 365 109 447 365 121 447 minecraft:red_concrete
setblock 365 109 448 minecraft:jack_o_lantern
fill 365 109 449 365 131 449 minecraft:red_concrete
setblock 365 109 450 minecraft:jack_o_lantern
fill 365 109 451 365 131 451 minecraft:red_concrete
setblock 365 109 452 minecraft:jack_o_lantern
fill 365 109 453 365 131 453 minecraft:red_concrete
setblock 365 109 454 minecraft:jack_o_lantern
fill 365 109 455 365 131 455 minecraft:red_concrete
setblock 366 109 437 minecraft:jack_o_lantern
fill 366 109 438 366 121 438 minecraft:red_concrete
setblock 366 109 439 minecraft:jack_o_lantern
fill 366 109 440 366 121 440 minecraft:red_concrete
setblock 366 109 441 minecraft:jack_o_lantern
fill 366 109 442 366 121 442 minecraft:red_concrete
setblock 366 109 443 minecraft:jack_o_lantern
fill 366 109 444 366 121 444 minecraft:red_concrete
setblock 366 109 445 minecraft:jack_o_lantern
fill 366 109 446 366 121 446 minecraft:red_concrete
setblock 366 109 447 minecraft:jack_o_lantern
fill 366 109 448 366 121 448 minecraft:red_concrete
setblock 366 109 449 minecraft:jack_o_lantern
fill 366 109 450 366 131 450 minecraft:red_concrete
setblock 366 109 451 minecraft:jack_o_lantern
fill 366 109 452 366 131 452 minecraft:red_concrete
setblock 366 109 453 minecraft:jack_o_lantern
fill 366 109 454 366 131 454 minecraft:red_concrete
setblock 366 109 455 minecraft:jack_o_lantern
fill 367 109 437 367 121 437 minecraft:red_concrete
setblock 367 109 438 minecraft:jack_o_lantern
fill 367 109 439 367 121 439 minecraft:red_concrete
setblock 367 109 440 minecraft:jack_o_lantern
fill 367 109 441 367 121 441 minecraft:red_concrete
setblock 367 109 442 minecraft:jack_o_lantern
fill 367 109 443 367 121 443 minecraft:red_concrete
setblock 367 109 444 minecraft:jack_o_lantern
fill 367 109 445 367 121 445 minecraft:red_concrete
setblock 367 109 446 minecraft:jack_o_lantern
fill 367 109 447 367 121 447 minecraft:red_concrete
setblock 367 109 448 minecraft:jack_o_lantern
fill 367 109 449 367 131 449 minecraft:red_concrete
setblock 367 109 450 minecraft:jack_o_lantern
fill 367 109 451 367 131 451 minecraft:red_concrete
setblock 367 109 452 minecraft:jack_o_lantern
fill 367 109 453 367 131 453 minecraft:red_concrete
setblock 367 109 454 minecraft:jack_o_lantern
fill 367 109 455 367 131 455 minecraft:red_concrete
setblock 368 109 437 minecraft:jack_o_lantern
fill 368 109 438 368 121 438 minecraft:red_concrete
setblock 368 109 439 minecraft:jack_o_lantern
fill 368 109 440 368 121 440 minecraft:red_concrete
setblock 368 109 441 minecraft:jack_o_lantern
fill 368 109 442 368 121 442 minecraft:red_concrete
setblock 368 109 443 minecraft:jack_o_lantern
fill 368 109 444 368 121 444 minecraft:red_concrete
setblock 368 109 445 minecraft:jack_o_lantern
fill 368 109 446 368 121 446 minecraft:red_concrete
setblock 368 109 447 minecraft:jack_o_lantern
fill 368 109 448 368 121 448 minecraft:red_concrete
setblock 368 109 449 minecraft:jack_o_lantern
fill 368 109 450 368 131 450 minecraft:red_concrete
setblock 368 109 451 minecraft:jack_o_lantern
fill 368 109 452 368 131 452 minecraft:red_concrete
setblock 368 109 453 minecraft:jack_o_lantern
fill 368 109 454 368 131 454 minecraft:red_concrete
setblock 368 109 455 minecraft:jack_o_lantern
fill 369 109 437 369 121 437 minecraft:red_concrete
setblock 369 109 438 minecraft:jack_o_lantern
fill 369 109 439 369 121 439 minecraft:red_concrete
setblock 369 109 440 minecraft:jack_o_lantern
fill 369 109 441 369 121 441 minecraft:red_concrete
setblock 369 109 442 minecraft:jack_o_lantern
fill 369 109 443 369 121 443 minecraft:red_concrete
setblock 369 109 444 minecraft:jack_o_lantern
fill 369 109 445 369 121 445 minecraft:red_concrete
setblock 369 109 446 minecraft:jack_o_lantern
fill 369 109 447 369 121 447 minecraft:red_concrete
setblock 369 109 448 minecraft:jack_o_lantern
fill 369 109 449 369 131 449 minecraft:red_concrete
setblock 369 109 450 minecraft:jack_o_lantern
fill 369 109 451 369 131 451 minecraft:red_concrete
setblock 369 109 452 minecraft:jack_o_lantern
fill 369 109 453 369 131 453 minecraft:red_concrete
setblock 369 109 454 minecraft:jack_o_lantern
fill 369 109 455 369 131 455 minecraft:red_concrete
fill 369 109 457 369 110 457 minecraft:red_concrete
fill 370 109 417 370 110 417 minecraft:red_concrete
fill 370 109 424 370 110 424 minecraft:red_concrete
fill 370 109 431 370 110 431 minecraft:red_concrete
setblock 370 109 437 minecraft:jack_o_lantern
fill 370 109 438 370 121 438 minecraft:red_concrete
setblock 370 109 439 minecraft:jack_o_lantern
fill 370 109 440 370 121 440 minecraft:red_concrete
setblock 370 109 441 minecraft:jack_o_lantern
fill 370 109 442 370 165 442 minecraft:red_concrete
setblock 370 109 443 minecraft:jack_o_lantern
fill 370 109 444 370 131 444 minecraft:red_concrete
setblock 370 109 445 minecraft:jack_o_lantern
fill 370 109 446 370 131 446 minecraft:red_concrete
setblock 370 109 447 minecraft:jack_o_lantern
fill 370 109 448 370 131 448 minecraft:red_concrete
setblock 370 109 449 minecraft:jack_o_lantern
fill 370 109 450 370 132 450 minecraft:red_concrete
setblock 370 109 451 minecraft:jack_o_lantern
fill 370 109 452 370 131 452 minecraft:red_concrete
setblock 370 109 453 minecraft:jack_o_lantern
fill 370 109 454 370 131 454 minecraft:red_concrete
setblock 370 109 455 minecraft:jack_o_lantern
fill 371 109 417 371 110 422 minecraft:black_concrete
setblock 371 109 423 minecraft:purple_terracotta
fill 371 109 424 371 110 424 minecraft:black_concrete
setblock 371 109 425 minecraft:purple_terracotta
fill 371 109 426 371 110 427 minecraft:black_concrete
fill 371 109 438 371 110 438 minecraft:black_concrete
fill 371 109 442 371 111 442 minecraft:black_concrete
fill 371 109 455 371 110 455 minecraft:black_concrete
setblock 329 110 423 minecraft:black_concrete
setblock 329 110 426 minecraft:black_concrete
fill 329 110 433 329 111 433 minecraft:black_concrete
setblock 329 110 458 minecraft:black_concrete
fill 330 110 417 330 110 418 minecraft:red_concrete
fill 330 110 420 330 110 421 minecraft:red_concrete
fill 330 110 423 330 110 425 minecraft:red_concrete
fill 330 110 427 330 110 428 minecraft:red_concrete
fill 330 110 430 330 110 432 minecraft:red_concrete
fill 330 110 434 330 110 435 minecraft:red_concrete
fill 330 110 437 330 110 439 minecraft:red_concrete
fill 330 110 441 330 110 442 minecraft:red_concrete
fill 330 110 444 330 110 446 minecraft:red_concrete
fill 330 110 448 330 110 449 minecraft:red_concrete
fill 330 110 451 330 110 453 minecraft:red_concrete
fill 330 110 455 330 110 456 minecraft:red_concrete
setblock 331 110 417 minecraft:red_concrete
fill 331 110 457 333 110 457 minecraft:red_concrete
setblock 332 110 419 minecraft:light[level=12]
setblock 332 110 427 minecraft:light[level=12]
setblock 332 110 435 minecraft:light[level=12]
setblock 332 110 443 minecraft:light[level=12]
setblock 332 110 451 minecraft:light[level=12]
setblock 333 110 416 minecraft:black_concrete
fill 333 110 417 334 110 417 minecraft:red_concrete
fill 335 110 457 336 110 457 minecraft:red_concrete
fill 336 110 417 338 110 417 minecraft:red_concrete
fill 338 110 457 340 110 457 minecraft:red_concrete
fill 340 110 417 341 110 417 minecraft:red_concrete
setblock 340 110 419 minecraft:light[level=12]
setblock 340 110 427 minecraft:light[level=12]
setblock 340 110 435 minecraft:light[level=12]
setblock 340 110 443 minecraft:light[level=12]
setblock 340 110 451 minecraft:light[level=12]
fill 342 110 457 343 110 457 minecraft:red_concrete
fill 343 110 417 345 110 417 minecraft:red_concrete
fill 345 110 457 347 110 457 minecraft:red_concrete
fill 347 110 417 348 110 417 minecraft:red_concrete
setblock 348 110 419 minecraft:light[level=12]
setblock 348 110 427 minecraft:light[level=12]
setblock 348 110 435 minecraft:light[level=12]
setblock 348 110 443 minecraft:light[level=12]
setblock 348 110 451 minecraft:light[level=12]
fill 349 110 457 350 110 457 minecraft:red_concrete
fill 350 110 417 352 110 417 minecraft:red_concrete
setblock 352 110 416 minecraft:black_concrete
fill 352 110 457 354 110 457 minecraft:red_concrete
fill 354 110 417 355 110 417 minecraft:red_concrete
setblock 356 110 419 minecraft:light[level=12]
setblock 356 110 427 minecraft:light[level=12]
setblock 356 110 435 minecraft:light[level=12]
setblock 356 110 443 minecraft:light[level=12]
setblock 356 110 451 minecraft:light[level=12]
fill 356 110 457 357 110 457 minecraft:red_concrete
fill 357 110 417 359 110 417 minecraft:red_concrete
fill 359 110 457 361 110 457 minecraft:red_concrete
setblock 359 110 458 minecraft:black_concrete
fill 361 110 417 362 110 417 minecraft:red_concrete
setblock 361 110 458 minecraft:black_concrete
fill 362 110 443 362 111 443 minecraft:red_concrete
fill 362 110 445 362 111 445 minecraft:red_concrete
fill 362 110 447 362 111 447 minecraft:red_concrete
fill 362 110 449 362 111 449 minecraft:red_concrete
fill 362 110 451 362 111 451 minecraft:red_concrete
fill 362 110 453 362 111 453 minecraft:red_concrete
fill 362 110 455 362 111 455 minecraft:red_concrete
fill 363 110 416 364 110 416 minecraft:black_concrete
fill 363 110 438 363 111 438 minecraft:red_concrete
fill 363 110 440 363 111 440 minecraft:red_concrete
fill 363 110 442 363 111 442 minecraft:red_concrete
fill 363 110 444 363 111 444 minecraft:red_concrete
fill 363 110 446 363 111 446 minecraft:red_concrete
fill 363 110 448 363 111 448 minecraft:red_concrete
fill 363 110 450 363 111 450 minecraft:red_concrete
fill 363 110 452 363 111 452 minecraft:red_concrete
fill 363 110 454 363 111 454 minecraft:red_concrete
fill 363 110 457 364 110 457 minecraft:red_concrete
fill 364 110 417 366 110 417 minecraft:red_concrete
setblock 364 110 419 minecraft:light[level=12]
setblock 364 110 427 minecraft:light[level=12]
setblock 364 110 435 minecraft:light[level=12]
fill 364 110 437 364 111 437 minecraft:red_concrete
fill 364 110 439 364 111 439 minecraft:red_concrete
fill 364 110 441 364 111 441 minecraft:red_concrete
fill 364 110 443 364 111 443 minecraft:red_concrete
fill 364 110 445 364 111 445 minecraft:red_concrete
fill 364 110 447 364 111 447 minecraft:red_concrete
fill 364 110 449 364 111 449 minecraft:red_concrete
fill 364 110 451 364 111 451 minecraft:red_concrete
fill 364 110 453 364 111 453 minecraft:red_concrete
fill 364 110 455 364 111 455 minecraft:red_concrete
fill 365 110 438 365 111 438 minecraft:red_concrete
fill 365 110 440 365 111 440 minecraft:red_concrete
fill 365 110 442 365 111 442 minecraft:red_concrete
fill 365 110 444 365 111 444 minecraft:red_concrete
fill 365 110 446 365 111 446 minecraft:red_concrete
fill 365 110 448 365 111 448 minecraft:red_concrete
fill 365 110 450 365 111 450 minecraft:red_concrete
fill 365 110 452 365 111 452 minecraft:red_concrete
fill 365 110 454 365 111 454 minecraft:red_concrete
fill 366 110 437 366 111 437 minecraft:red_concrete
fill 366 110 439 366 111 439 minecraft:red_concrete
fill 366 110 441 366 111 441 minecraft:red_concrete
fill 366 110 443 366 111 443 minecraft:red_concrete
fill 366 110 445 366 111 445 minecraft:red_concrete
fill 366 110 447 366 111 447 minecraft:red_concrete
fill 366 110 449 366 111 449 minecraft:red_concrete
fill 366 110 451 366 111 451 minecraft:red_concrete
fill 366 110 453 366 111 453 minecraft:red_concrete
fill 366 110 455 366 111 455 minecraft:red_concrete
fill 366 110 457 368 110 457 minecraft:red_concrete
fill 367 110 438 367 111 438 minecraft:red_concrete
fill 367 110 440 367 111 440 minecraft:red_concrete
fill 367 110 442 367 111 442 minecraft:red_concrete
fill 367 110 444 367 111 444 minecraft:red_concrete
fill 367 110 446 367 111 446 minecraft:red_concrete
fill 367 110 448 367 111 448 minecraft:red_concrete
fill 367 110 450 367 111 450 minecraft:red_concrete
fill 367 110 452 367 111 452 minecraft:red_concrete
fill 367 110 454 367 111 454 minecraft:red_concrete
fill 368 110 417 369 110 417 minecraft:red_concrete
fill 368 110 437 368 111 437 minecraft:red_concrete
fill 368 110 439 368 111 439 minecraft:red_concrete
fill 368 110 441 368 111 441 minecraft:red_concrete
fill 368 110 443 368 111 443 minecraft:red_concrete
fill 368 110 445 368 111 445 minecraft:red_concrete
fill 368 110 447 368 111 447 minecraft:red_concrete
fill 368 110 449 368 111 449 minecraft:red_concrete
fill 368 110 451 368 111 451 minecraft:red_concrete
fill 368 110 453 368 111 453 minecraft:red_concrete
fill 368 110 455 368 111 455 minecraft:red_concrete
fill 369 110 438 369 111 438 minecraft:red_concrete
fill 369 110 440 369 111 440 minecraft:red_concrete
fill 369 110 442 369 111 442 minecraft:red_concrete
fill 369 110 444 369 111 444 minecraft:red_concrete
fill 369 110 446 369 111 446 minecraft:red_concrete
fill 369 110 448 369 111 448 minecraft:red_concrete
fill 369 110 450 369 111 450 minecraft:red_concrete
fill 369 110 452 369 111 452 minecraft:red_concrete
fill 369 110 454 369 111 454 minecraft:red_concrete
fill 370 110 418 370 110 420 minecraft:red_concrete
fill 370 110 422 370 110 423 minecraft:red_concrete
fill 370 110 425 370 110 427 minecraft:red_concrete
fill 370 110 429 370 110 430 minecraft:red_concrete
fill 370 110 432 370 110 434 minecraft:red_concrete
fill 370 110 436 370 111 437 minecraft:red_concrete
fill 370 110 439 370 111 439 minecraft:red_concrete
fill 370 110 441 370 111 441 minecraft:red_concrete
fill 370 110 443 370 111 443 minecraft:red_concrete
fill 370 110 445 370 111 445 minecraft:red_concrete
fill 370 110 447 370 111 447 minecraft:red_concrete
fill 370 110 449 370 111 449 minecraft:red_concrete
fill 370 110 451 370 111 451 minecraft:red_concrete
fill 370 110 453 370 111 453 minecraft:red_concrete
fill 370 110 455 370 111 455 minecraft:red_concrete
setblock 370 110 457 minecraft:red_concrete
fill 371 110 423 371 111 423 minecraft:black_concrete
fill 371 110 425 371 111 425 minecraft:black_concrete
setblock 371 110 458 minecraft:black_concrete
setblock 329 111 416 minecraft:black_concrete
fill 329 111 417 329 112 419 minecraft:purple_terracotta
fill 329 111 421 329 209 421 minecraft:purple_terracotta
setblock 329 111 422 minecraft:black_concrete
fill 329 111 423 329 209 424 minecraft:purple_terracotta
fill 329 111 426 329 209 427 minecraft:purple_terracotta
setblock 329 111 428 minecraft:black_concrete
fill 329 111 429 329 206 432 minecraft:purple_terracotta
fill 329 111 434 329 111 439 minecraft:purple_terracotta
setblock 329 111 440 minecraft:black_concrete
fill 329 111 441 329 112 445 minecraft:purple_terracotta
fill 329 111 446 329 111 447 minecraft:black_concrete
fill 329 111 448 329 111 458 minecraft:purple_terracotta
fill 330 111 416 334 111 416 minecraft:purple_terracotta
setblock 330 111 421 minecraft:red_concrete
setblock 330 111 428 minecraft:red_concrete
setblock 330 111 435 minecraft:red_concrete
setblock 330 111 442 minecraft:red_concrete
setblock 330 111 449 minecraft:red_concrete
setblock 330 111 456 minecraft:red_concrete
fill 331 111 458 345 111 458 minecraft:purple_terracotta
setblock 333 111 417 minecraft:red_concrete
setblock 335 111 416 minecraft:black_concrete
fill 336 111 416 338 111 416 minecraft:purple_terracotta
setblock 336 111 457 minecraft:red_concrete
setblock 339 111 416 minecraft:black_concrete
setblock 340 111 416 minecraft:purple_terracotta
setblock 340 111 417 minecraft:red_concrete
setblock 341 111 416 minecraft:black_concrete
fill 342 111 416 348 206 416 minecraft:purple_terracotta
setblock 343 111 457 minecraft:red_concrete
setblock 346 111 458 minecraft:black_concrete
setblock 347 111 417 minecraft:red_concrete
fill 347 111 458 364 111 458 minecraft:purple_terracotta
setblock 349 111 416 minecraft:black_concrete
fill 350 111 416 370 111 416 minecraft:purple_terracotta
setblock 350 111 457 minecraft:red_concrete
setblock 354 111 417 minecraft:red_concrete
setblock 357 111 457 minecraft:red_concrete
setblock 361 111 417 minecraft:red_concrete
setblock 364 111 457 minecraft:red_concrete
setblock 365 111 458 minecraft:black_concrete
fill 366 111 458 371 111 458 minecraft:purple_terracotta
setblock 368 111 417 minecraft:red_concrete
setblock 370 111 422 minecraft:red_concrete
setblock 370 111 429 minecraft:red_concrete
setblock 371 111 416 minecraft:black_concrete
fill 371 111 417 371 209 418 minecraft:purple_terracotta
setblock 371 111 419 minecraft:black_concrete
fill 371 111 420 371 112 420 minecraft:purple_terracotta
setblock 371 111 421 minecraft:black_concrete
fill 371 111 422 371 207 422 minecraft:purple_terracotta
fill 371 111 424 371 207 424 minecraft:purple_terracotta
fill 371 111 426 371 205 432 minecraft:purple_terracotta
setblock 371 111 433 minecraft:black_concrete
fill 371 111 434 371 205 441 minecraft:purple_terracotta
fill 371 111 443 371 205 451 minecraft:purple_terracotta
setblock 371 111 452 minecraft:black_concrete
fill 371 111 453 371 111 457 minecraft:purple_terracotta
fill 329 112 416 330 207 416 minecraft:purple_terracotta
fill 329 112 420 329 207 420 minecraft:purple_terracotta
fill 329 112 422 329 206 422 minecraft:purple_terracotta
fill 329 112 425 329 209 425 minecraft:purple_terracotta
fill 329 112 428 329 209 428 minecraft:purple_terracotta
fill 329 112 433 329 209 433 minecraft:purple_terracotta
fill 329 112 434 329 112 435 minecraft:black_concrete
fill 329 112 436 329 112 440 minecraft:purple_terracotta
setblock 329 112 446 minecraft:black_concrete
fill 329 112 447 329 112 453 minecraft:purple_terracotta
setblock 329 112 454 minecraft:black_concrete
fill 329 112 455 329 112 458 minecraft:purple_terracotta
fill 330 112 458 331 209 458 minecraft:purple_terracotta
setblock 331 112 416 minecraft:black_concrete
fill 332 112 416 336 209 416 minecraft:purple_terracotta
setblock 332 112 458 minecraft:black_concrete
fill 333 112 458 333 209 458 minecraft:purple_terracotta
setblock 334 112 458 minecraft:black_concrete
fill 335 112 458 349 112 458 minecraft:purple_terracotta
fill 337 112 416 338 112 416 minecraft:black_concrete
fill 339 112 416 339 209 416 minecraft:purple_terracotta
setblock 340 112 416 minecraft:black_concrete
fill 341 112 416 341 205 416 minecraft:purple_terracotta
fill 349 112 416 363 112 416 minecraft:purple_terracotta
setblock 350 112 458 minecraft:black_concrete
fill 351 112 458 363 112 458 minecraft:purple_terracotta
setblock 362 112 443 minecraft:jack_o_lantern
setblock 362 112 445 minecraft:jack_o_lantern
setblock 362 112 447 minecraft:jack_o_lantern
setblock 362 112 449 minecraft:jack_o_lantern
setblock 362 112 451 minecraft:jack_o_lantern
setblock 362 112 453 minecraft:jack_o_lantern
setblock 362 112 455 minecraft:jack_o_lantern
setblock 363 112 438 minecraft:jack_o_lantern
setblock 363 112 440 minecraft:jack_o_lantern
setblock 363 112 442 minecraft:jack_o_lantern
setblock 363 112 444 minecraft:jack_o_lantern
setblock 363 112 446 minecraft:jack_o_lantern
setblock 363 112 448 minecraft:jack_o_lantern
setblock 363 112 450 minecraft:jack_o_lantern
setblock 363 112 452 minecraft:jack_o_lantern
setblock 363 112 454 minecraft:jack_o_lantern
setblock 364 112 416 minecraft:black_concrete
setblock 364 112 437 minecraft:jack_o_lantern
setblock 364 112 439 minecraft:jack_o_lantern
setblock 364 112 441 minecraft:jack_o_lantern
setblock 364 112 443 minecraft:jack_o_lantern
setblock 364 112 445 minecraft:jack_o_lantern
setblock 364 112 447 minecraft:jack_o_lantern
setblock 364 112 449 minecraft:jack_o_lantern
setblock 364 112 451 minecraft:jack_o_lantern
setblock 364 112 453 minecraft:jack_o_lantern
setblock 364 112 455 minecraft:jack_o_lantern
setblock 364 112 458 minecraft:black_concrete
fill 365 112 416 369 207 416 minecraft:purple_terracotta
setblock 365 112 438 minecraft:jack_o_lantern
setblock 365 112 440 minecraft:jack_o_lantern
setblock 365 112 442 minecraft:jack_o_lantern
setblock 365 112 444 minecraft:jack_o_lantern
setblock 365 112 446 minecraft:jack_o_lantern
setblock 365 112 448 minecraft:jack_o_lantern
setblock 365 112 450 minecraft:jack_o_lantern
setblock 365 112 452 minecraft:jack_o_lantern
setblock 365 112 454 minecraft:jack_o_lantern
fill 365 112 458 365 209 458 minecraft:purple_terracotta
setblock 366 112 437 minecraft:jack_o_lantern
setblock 366 112 439 minecraft:jack_o_lantern
setblock 366 112 441 minecraft:jack_o_lantern
setblock 366 112 443 minecraft:jack_o_lantern
setblock 366 112 445 minecraft:jack_o_lantern
setblock 366 112 447 minecraft:jack_o_lantern
setblock 366 112 449 minecraft:jack_o_lantern
setblock 366 112 451 minecraft:jack_o_lantern
setblock 366 112 453 minecraft:jack_o_lantern
setblock 366 112 455 minecraft:jack_o_lantern
setblock 366 112 458 minecraft:black_concrete
setblock 367 112 438 minecraft:jack_o_lantern
setblock 367 112 440 minecraft:jack_o_lantern
setblock 367 112 442 minecraft:jack_o_lantern
setblock 367 112 444 minecraft:jack_o_lantern
setblock 367 112 446 minecraft:jack_o_lantern
setblock 367 112 448 minecraft:jack_o_lantern
setblock 367 112 450 minecraft:jack_o_lantern
setblock 367 112 452 minecraft:jack_o_lantern
setblock 367 112 454 minecraft:jack_o_lantern
fill 367 112 458 370 209 458 minecraft:purple_terracotta
setblock 368 112 437 minecraft:jack_o_lantern
setblock 368 112 439 minecraft:jack_o_lantern
setblock 368 112 441 minecraft:jack_o_lantern
setblock 368 112 443 minecraft:jack_o_lantern
setblock 368 112 445 minecraft:jack_o_lantern
setblock 368 112 447 minecraft:jack_o_lantern
setblock 368 112 449 minecraft:jack_o_lantern
setblock 368 112 451 minecraft:jack_o_lantern
setblock 368 112 453 minecraft:jack_o_lantern
setblock 368 112 455 minecraft:jack_o_lantern
setblock 369 112 438 minecraft:jack_o_lantern
setblock 369 112 440 minecraft:jack_o_lantern
setblock 369 112 442 minecraft:jack_o_lantern
setblock 369 112 444 minecraft:jack_o_lantern
setblock 369 112 446 minecraft:jack_o_lantern
setblock 369 112 448 minecraft:jack_o_lantern
setblock 369 112 450 minecraft:jack_o_lantern
setblock 369 112 452 minecraft:jack_o_lantern
setblock 369 112 454 minecraft:jack_o_lantern
setblock 370 112 416 minecraft:black_concrete
setblock 370 112 437 minecraft:jack_o_lantern
setblock 370 112 439 minecraft:jack_o_lantern
setblock 370 112 441 minecraft:jack_o_lantern
setblock 370 112 443 minecraft:jack_o_lantern
setblock 370 112 445 minecraft:jack_o_lantern
setblock 370 112 447 minecraft:jack_o_lantern
setblock 370 112 449 minecraft:jack_o_lantern
setblock 370 112 451 minecraft:jack_o_lantern
setblock 370 112 453 minecraft:jack_o_lantern
setblock 370 112 455 minecraft:jack_o_lantern
fill 371 112 416 371 209 416 minecraft:purple_terracotta
fill 371 112 419 371 206 419 minecraft:purple_terracotta
fill 371 112 421 371 209 421 minecraft:purple_terracotta
fill 371 112 423 371 209 423 minecraft:purple_terracotta
fill 371 112 425 371 209 425 minecraft:purple_terracotta
fill 371 112 433 371 209 433 minecraft:purple_terracotta
setblock 371 112 442 minecraft:purple_terracotta
fill 371 112 452 371 209 456 minecraft:purple_terracotta
fill 371 112 457 371 112 458 minecraft:black_concrete
setblock 329 113 417 minecraft:black_concrete
fill 329 113 418 329 207 419 minecraft:purple_terracotta
fill 329 113 434 329 207 437 minecraft:purple_terracotta
setblock 329 113 438 minecraft:black_concrete
fill 329 113 439 329 209 440 minecraft:purple_terracotta
setblock 329 113 441 minecraft:black_concrete
fill 329 113 442 329 205 449 minecraft:purple_terracotta
fill 329 113 450 329 113 451 minecraft:black_concrete
fill 329 113 452 329 206 457 minecraft:purple_terracotta
setblock 329 113 458 minecraft:black_concrete
setblock 330 113 423 minecraft:red_concrete
setblock 330 113 430 minecraft:red_concrete
setblock 330 113 437 minecraft:red_concrete
setblock 330 113 444 minecraft:red_concrete
setblock 330 113 451 minecraft:red_concrete
fill 331 113 416 331 209 416 minecraft:purple_terracotta
setblock 331 113 417 minecraft:red_concrete
setblock 331 113 457 minecraft:red_concrete
fill 332 113 458 332 209 458 minecraft:purple_terracotta
fill 334 113 458 344 205 458 minecraft:purple_terracotta
fill 337 113 416 338 209 416 minecraft:purple_terracotta
setblock 338 113 417 minecraft:red_concrete
setblock 338 113 457 minecraft:red_concrete
fill 340 113 416 340 209 416 minecraft:purple_terracotta
setblock 345 113 417 minecraft:red_concrete
setblock 345 113 457 minecraft:red_concrete
setblock 345 113 458 minecraft:black_concrete
fill 346 113 458 357 205 458 minecraft:purple_terracotta
fill 349 113 416 352 209 416 minecraft:purple_terracotta
setblock 352 113 417 minecraft:red_concrete
setblock 352 113 457 minecraft:red_concrete
setblock 353 113 416 minecraft:black_concrete
fill 354 113 416 355 207 416 minecraft:purple_terracotta
setblock 356 113 416 minecraft:black_concrete
fill 357 113 416 364 205 416 minecraft:purple_terracotta
setblock 358 113 458 minecraft:black_concrete
setblock 359 113 417 minecraft:red_concrete
setblock 359 113 457 minecraft:red_concrete
fill 359 113 458 364 205 458 minecraft:purple_terracotta
fill 362 113 443 362 114 443 minecraft:red_concrete
fill 362 113 445 362 114 445 minecraft:red_concrete
fill 362 113 447 362 114 447 minecraft:red_concrete
fill 362 113 449 362 114 449 minecraft:red_concrete
fill 362 113 451 362 114 451 minecraft:red_concrete
fill 362 113 453 362 114 453 minecraft:red_concrete
fill 362 113 455 362 114 455 minecraft:red_concrete
fill 363 113 438 363 114 438 minecraft:red_concrete
fill 363 113 440 363 114 440 minecraft:red_concrete
fill 363 113 442 363 114 442 minecraft:red_concrete
fill 363 113 444 363 114 444 minecraft:red_concrete
fill 363 113 446 363 114 446 minecraft:red_concrete
fill 363 113 448 363 114 448 minecraft:red_concrete
fill 363 113 450 363 114 450 minecraft:red_concrete
fill 363 113 452 363 114 452 minecraft:red_concrete
fill 363 113 454 363 114 454 minecraft:red_concrete
fill 364 113 437 364 114 437 minecraft:red_concrete
fill 364 113 439 364 114 439 minecraft:red_concrete
fill 364 113 441 364 114 441 minecraft:red_concrete
fill 364 113 443 364 114 443 minecraft:red_concrete
fill 364 113 445 364 114 445 minecraft:red_concrete
fill 364 113 447 364 114 447 minecraft:red_concrete
fill 364 113 449 364 114 449 minecraft:red_concrete
fill 364 113 451 364 114 451 minecraft:red_concrete
fill 364 113 453 364 114 453 minecraft:red_concrete
fill 364 113 455 364 114 455 minecraft:red_concrete
fill 365 113 438 365 114 438 minecraft:red_concrete
fill 365 113 440 365 114 440 minecraft:red_concrete
fill 365 113 442 365 114 442 minecraft:red_concrete
fill 365 113 444 365 114 444 minecraft:red_concrete
fill 365 113 446 365 114 446 minecraft:red_concrete
fill 365 113 448 365 114 448 minecraft:red_concrete
fill 365 113 450 365 114 450 minecraft:red_concrete
fill 365 113 452 365 114 452 minecraft:red_concrete
fill 365 113 454 365 114 454 minecraft:red_concrete
setblock 366 113 417 minecraft:red_concrete
fill 366 113 437 366 114 437 minecraft:red_concrete
fill 366 113 439 366 114 439 minecraft:red_concrete
fill 366 113 441 366 114 441 minecraft:red_concrete
fill 366 113 443 366 114 443 minecraft:red_concrete
fill 366 113 445 366 114 445 minecraft:red_concrete
fill 366 113 447 366 114 447 minecraft:red_concrete
fill 366 113 449 366 114 449 minecraft:red_concrete
fill 366 113 451 366 114 451 minecraft:red_concrete
fill 366 113 453 366 114 453 minecraft:red_concrete
fill 366 113 455 366 114 455 minecraft:red_concrete
setblock 366 113 457 minecraft:red_concrete
fill 366 113 458 366 209 458 minecraft:purple_terracotta
fill 367 113 438 367 114 438 minecraft:red_concrete
fill 367 113 440 367 114 440 minecraft:red_concrete
fill 367 113 442 367 114 442 minecraft:red_concrete
fill 367 113 444 367 114 444 minecraft:red_concrete
fill 367 113 446 367 114 446 minecraft:red_concrete
fill 367 113 448 367 114 448 minecraft:red_concrete
fill 367 113 450 367 114 450 minecraft:red_concrete
fill 367 113 452 367 114 452 minecraft:red_concrete
fill 367 113 454 367 114 454 minecraft:red_concrete
fill 368 113 437 368 114 437 minecraft:red_concrete
fill 368 113 439 368 114 439 minecraft:red_concrete
fill 368 113 441 368 114 441 minecraft:red_concrete
fill 368 113 443 368 114 443 minecraft:red_concrete
fill 368 113 445 368 114 445 minecraft:red_concrete
fill 368 113 447 368 114 447 minecraft:red_concrete
fill 368 113 449 368 114 449 minecraft:red_concrete
fill 368 113 451 368 114 451 minecraft:red_concrete
fill 368 113 453 368 114 453 minecraft:red_concrete
fill 368 113 455 368 114 455 minecraft:red_concrete
fill 369 113 438 369 114 438 minecraft:red_concrete
fill 369 113 440 369 114 440 minecraft:red_concrete
fill 369 113 442 369 114 442 minecraft:red_concrete
fill 369 113 444 369 114 444 minecraft:red_concrete
fill 369 113 446 369 114 446 minecraft:red_concrete
fill 369 113 448 369 114 448 minecraft:red_concrete
fill 369 113 450 369 114 450 minecraft:red_concrete
fill 369 113 452 369 114 452 minecraft:red_concrete
fill 369 113 454 369 114 454 minecraft:red_concrete
fill 370 113 416 370 205 416 minecraft:purple_terracotta
setblock 370 113 420 minecraft:red_concrete
setblock 370 113 427 minecraft:red_concrete
setblock 370 113 434 minecraft:red_concrete
fill 370 113 437 370 114 437 minecraft:red_concrete
fill 370 113 439 370 114 439 minecraft:red_concrete
fill 370 113 441 370 114 441 minecraft:red_concrete
fill 370 113 443 370 114 443 minecraft:red_concrete
fill 370 113 445 370 114 445 minecraft:red_concrete
fill 370 113 447 370 114 447 minecraft:red_concrete
fill 370 113 449 370 114 449 minecraft:red_concrete
fill 370 113 451 370 114 451 minecraft:red_concrete
fill 370 113 453 370 114 453 minecraft:red_concrete
fill 370 113 455 370 114 455 minecraft:red_concrete
setblock 371 113 420 minecraft:black_concrete
setblock 371 113 442 minecraft:black_concrete
fill 371 113 457 371 205 458 minecraft:purple_terracotta
fill 329 114 417 329 205 417 minecraft:purple_terracotta
fill 329 114 438 329 209 438 minecraft:purple_terracotta
fill 329 114 441 329 209 441 minecraft:purple_terracotta
fill 329 114 450 329 207 451 minecraft:purple_terracotta
fill 329 114 458 329 209 458 minecraft:purple_terracotta
setblock 330 114 417 minecraft:red_concrete
setblock 330 114 424 minecraft:red_concrete
setblock 330 114 431 minecraft:red_concrete
setblock 330 114 438 minecraft:red_concrete
setblock 330 114 445 minecraft:red_concrete
setblock 330 114 452 minecraft:red_concrete
setblock 332 114 457 minecraft:red_concrete
setblock 337 114 417 minecraft:red_concrete
setblock 339 114 457 minecraft:red_concrete
setblock 344 114 417 minecraft:red_concrete
fill 345 114 458 345 209 458 minecraft:purple_terracotta
setblock 346 114 457 minecraft:red_concrete
setblock 351 114 417 minecraft:red_concrete
fill 353 114 416 353 209 416 minecraft:purple_terracotta
setblock 353 114 457 minecraft:red_concrete
fill 356 114 416 356 206 416 minecraft:purple_terracotta
setblock 358 114 417 minecraft:red_concrete
fill 358 114 458 358 209 458 minecraft:purple_terracotta
setblock 360 114 457 minecraft:red_concrete
setblock 365 114 417 minecraft:red_concrete
setblock 367 114 457 minecraft:red_concrete
setblock 370 114 419 minecraft:red_concrete
setblock 370 114 426 minecraft:red_concrete
setblock 370 114 433 minecraft:red_concrete
fill 371 114 420 371 210 420 minecraft:purple_terracotta
fill 371 114 442 371 209 442 minecraft:purple_terracotta
setblock 330 115 418 minecraft:red_concrete
setblock 330 115 425 minecraft:red_concrete
setblock 330 115 432 minecraft:red_concrete
setblock 330 115 439 minecraft:red_concrete
setblock 330 115 446 minecraft:red_concrete
setblock 330 115 453 minecraft:red_concrete
setblock 333 115 457 minecraft:red_concrete
setblock 336 115 417 minecraft:red_concrete
setblock 340 115 457 minecraft:red_concrete
setblock 343 115 417 minecraft:red_concrete
setblock 347 115 457 minecraft:red_concrete
setblock 350 115 417 minecraft:red_concrete
setblock 354 115 457 minecraft:red_concrete
setblock 357 115 417 minecraft:red_concrete
setblock 361 115 457 minecraft:red_concrete
setblock 362 115 443 minecraft:jack_o_lantern
setblock 362 115 445 minecraft:jack_o_lantern
setblock 362 115 447 minecraft:jack_o_lantern
setblock 362 115 449 minecraft:jack_o_lantern
setblock 362 115 451 minecraft:jack_o_lantern
setblock 362 115 453 minecraft:jack_o_lantern
setblock 362 115 455 minecraft:jack_o_lantern
setblock 363 115 438 minecraft:jack_o_lantern
setblock 363 115 440 minecraft:jack_o_lantern
setblock 363 115 442 minecraft:jack_o_lantern
setblock 363 115 444 minecraft:jack_o_lantern
setblock 363 115 446 minecraft:jack_o_lantern
setblock 363 115 448 minecraft:jack_o_lantern
setblock 363 115 450 minecraft:jack_o_lantern
setblock 363 115 452 minecraft:jack_o_lantern
setblock 363 115 454 minecraft:jack_o_lantern
setblock 364 115 417 minecraft:red_concrete
setblock 364 115 437 minecraft:jack_o_lantern
setblock 364 115 439 minecraft:jack_o_lantern
setblock 364 115 441 minecraft:jack_o_lantern
setblock 364 115 443 minecraft:jack_o_lantern
setblock 364 115 445 minecraft:jack_o_lantern
setblock 364 115 447 minecraft:jack_o_lantern
setblock 364 115 449 minecraft:jack_o_lantern
setblock 364 115 451 minecraft:jack_o_lantern
setblock 364 115 453 minecraft:jack_o_lantern
setblock 364 115 455 minecraft:jack_o_lantern
setblock 365 115 438 minecraft:jack_o_lantern
setblock 365 115 440 minecraft:jack_o_lantern
setblock 365 115 442 minecraft:jack_o_lantern
setblock 365 115 444 minecraft:jack_o_lantern
setblock 365 115 446 minecraft:jack_o_lantern
setblock 365 115 448 minecraft:jack_o_lantern
setblock 365 115 450 minecraft:jack_o_lantern
setblock 365 115 452 minecraft:jack_o_lantern
setblock 365 115 454 minecraft:jack_o_lantern
setblock 366 115 437 minecraft:jack_o_lantern
setblock 366 115 439 minecraft:jack_o_lantern
setblock 366 115 441 minecraft:jack_o_lantern
setblock 366 115 443 minecraft:jack_o_lantern
setblock 366 115 445 minecraft:jack_o_lantern
setblock 366 115 447 minecraft:jack_o_lantern
setblock 366 115 449 minecraft:jack_o_lantern
setblock 366 115 451 minecraft:jack_o_lantern
setblock 366 115 453 minecraft:jack_o_lantern
setblock 366 115 455 minecraft:jack_o_lantern
setblock 367 115 438 minecraft:jack_o_lantern
setblock 367 115 440 minecraft:jack_o_lantern
setblock 367 115 442 minecraft:jack_o_lantern
setblock 367 115 444 minecraft:jack_o_lantern
setblock 367 115 446 minecraft:jack_o_lantern
setblock 367 115 448 minecraft:jack_o_lantern
setblock 367 115 450 minecraft:jack_o_lantern
setblock 367 115 452 minecraft:jack_o_lantern
setblock 367 115 454 minecraft:jack_o_lantern
setblock 368 115 437 minecraft:jack_o_lantern
setblock 368 115 439 minecraft:jack_o_lantern
setblock 368 115 441 minecraft:jack_o_lantern
setblock 368 115 443 minecraft:jack_o_lantern
setblock 368 115 445 minecraft:jack_o_lantern
setblock 368 115 447 minecraft:jack_o_lantern
setblock 368 115 449 minecraft:jack_o_lantern
setblock 368 115 451 minecraft:jack_o_lantern
setblock 368 115 453 minecraft:jack_o_lantern
setblock 368 115 455 minecraft:jack_o_lantern
setblock 368 115 457 minecraft:red_concrete
setblock 369 115 438 minecraft:jack_o_lantern
setblock 369 115 440 minecraft:jack_o_lantern
setblock 369 115 442 minecraft:jack_o_lantern
setblock 369 115 444 minecraft:jack_o_lantern
setblock 369 115 446 minecraft:jack_o_lantern
setblock 369 115 448 minecraft:jack_o_lantern
setblock 369 115 450 minecraft:jack_o_lantern
setblock 369 115 452 minecraft:jack_o_lantern
setblock 369 115 454 minecraft:jack_o_lantern
setblock 370 115 418 minecraft:red_concrete
setblock 370 115 425 minecraft:red_concrete
setblock 370 115 432 minecraft:red_concrete
setblock 370 115 437 minecraft:jack_o_lantern
setblock 370 115 439 minecraft:jack_o_lantern
setblock 370 115 441 minecraft:jack_o_lantern
setblock 370 115 443 minecraft:jack_o_lantern
setblock 370 115 445 minecraft:jack_o_lantern
setblock 370 115 447 minecraft:jack_o_lantern
setblock 370 115 449 minecraft:jack_o_lantern
setblock 370 115 451 minecraft:jack_o_lantern
setblock 370 115 453 minecraft:jack_o_lantern
setblock 370 115 455 minecraft:jack_o_lantern
setblock 330 116 419 minecraft:red_concrete
setblock 330 116 426 minecraft:red_concrete
setblock 330 116 433 minecraft:red_concrete
setblock 330 116 440 minecraft:red_concrete
setblock 330 116 447 minecraft:red_concrete
setblock 330 116 454 minecraft:red_concrete
setblock 334 116 457 minecraft:red_concrete
setblock 335 116 417 minecraft:red_concrete
setblock 341 116 457 minecraft:red_concrete
setblock 342 116 417 minecraft:red_concrete
setblock 348 116 457 minecraft:red_concrete
setblock 349 116 417 minecraft:red_concrete
setblock 355 116 457 minecraft:red_concrete
setblock 356 116 417 minecraft:red_concrete
fill 362 116 443 362 117 443 minecraft:red_concrete
fill 362 116 445 362 117 445 minecraft:red_concrete
fill 362 116 447 362 117 447 minecraft:red_concrete
fill 362 116 449 362 117 449 minecraft:red_concrete
fill 362 116 451 362 117 451 minecraft:red_concrete
fill 362 116 453 362 117 453 minecraft:red_concrete
fill 362 116 455 362 117 455 minecraft:red_concrete
setblock 362 116 457 minecraft:red_concrete
setblock 363 116 417 minecraft:red_concrete
fill 363 116 438 363 117 438 minecraft:red_concrete
fill 363 116 440 363 117 440 minecraft:red_concrete
fill 363 116 442 363 117 442 minecraft:red_concrete
fill 363 116 444 363 117 444 minecraft:red_concrete
fill 363 116 446 363 117 446 minecraft:red_concrete
fill 363 116 448 363 117 448 minecraft:red_concrete
fill 363 116 450 363 117 450 minecraft:red_concrete
fill 363 116 452 363 117 452 minecraft:red_concrete
fill 363 116 454 363 117 454 minecraft:red_concrete
fill 364 116 437 364 117 437 minecraft:red_concrete
fill 364 116 439 364 117 439 minecraft:red_concrete
fill 364 116 441 364 117 441 minecraft:red_concrete
fill 364 116 443 364 117 443 minecraft:red_concrete
fill 364 116 445 364 117 445 minecraft:red_concrete
fill 364 116 447 364 117 447 minecraft:red_concrete
fill 364 116 449 364 117 449 minecraft:red_concrete
fill 364 116 451 364 117 451 minecraft:red_concrete
fill 364 116 453 364 117 453 minecraft:red_concrete
fill 364 116 455 364 117 455 minecraft:red_concrete
fill 365 116 438 365 117 438 minecraft:red_concrete
fill 365 116 440 365 117 440 minecraft:red_concrete
fill 365 116 442 365 117 442 minecraft:red_concrete
fill 365 116 444 365 117 444 minecraft:red_concrete
fill 365 116 446 365 117 446 minecraft:red_concrete
fill 365 116 448 365 117 448 minecraft:red_concrete
fill 365 116 450 365 117 450 minecraft:red_concrete
fill 365 116 452 365 117 452 minecraft:red_concrete
fill 365 116 454 365 117 454 minecraft:red_concrete
fill 366 116 437 366 117 437 minecraft:red_concrete
fill 366 116 439 366 117 439 minecraft:red_concrete
fill 366 116 441 366 117 441 minecraft:red_concrete
fill 366 116 443 366 117 443 minecraft:red_concrete
fill 366 116 445 366 117 445 minecraft:red_concrete
fill 366 116 447 366 117 447 minecraft:red_concrete
fill 366 116 449 366 117 449 minecraft:red_concrete
fill 366 116 451 366 117 451 minecraft:red_concrete
fill 366 116 453 366 117 453 minecraft:red_concrete
fill 366 116 455 366 117 455 minecraft:red_concrete
fill 367 116 438 367 117 438 minecraft:red_concrete
fill 367 116 440 367 117 440 minecraft:red_concrete
fill 367 116 442 367 117 442 minecraft:red_concrete
fill 367 116 444 367 117 444 minecraft:red_concrete
fill 367 116 446 367 117 446 minecraft:red_concrete
fill 367 116 448 367 117 448 minecraft:red_concrete
fill 367 116 450 367 117 450 minecraft:red_concrete
fill 367 116 452 367 117 452 minecraft:red_concrete
fill 367 116 454 367 117 454 minecraft:red_concrete
fill 368 116 437 368 117 437 minecraft:red_concrete
fill 368 116 439 368 117 439 minecraft:red_concrete
fill 368 116 441 368 117 441 minecraft:red_concrete
fill 368 116 443 368 117 443 minecraft:red_concrete
fill 368 116 445 368 117 445 minecraft:red_concrete
fill 368 116 447 368 117 447 minecraft:red_concrete
fill 368 116 449 368 117 449 minecraft:red_concrete
fill 368 116 451 368 117 451 minecraft:red_concrete
fill 368 116 453 368 117 453 minecraft:red_concrete
fill 368 116 455 368 117 455 minecraft:red_concrete
fill 369 116 438 369 117 438 minecraft:red_concrete
fill 369 116 440 369 117 440 minecraft:red_concrete
fill 369 116 442 369 117 442 minecraft:red_concrete
fill 369 116 444 369 117 444 minecraft:red_concrete
fill 369 116 446 369 117 446 minecraft:red_concrete
fill 369 116 448 369 117 448 minecraft:red_concrete
fill 369 116 450 369 117 450 minecraft:red_concrete
fill 369 116 452 369 117 452 minecraft:red_concrete
fill 369 116 454 369 117 454 minecraft:red_concrete
setblock 369 116 457 minecraft:red_concrete
setblock 370 116 417 minecraft:red_concrete
setblock 370 116 424 minecraft:red_concrete
setblock 370 116 431 minecraft:red_concrete
fill 370 116 437 370 117 437 minecraft:red_concrete
fill 370 116 439 370 117 439 minecraft:red_concrete
fill 370 116 441 370 117 441 minecraft:red_concrete
fill 370 116 443 370 117 443 minecraft:red_concrete
fill 370 116 445 370 117 445 minecraft:red_concrete
fill 370 116 447 370 117 447 minecraft:red_concrete
fill 370 116 449 370 117 449 minecraft:red_concrete
fill 370 116 451 370 117 451 minecraft:red_concrete
fill 370 116 453 370 117 453 minecraft:red_concrete
fill 370 116 455 370 117 455 minecraft:red_concrete
setblock 330 117 420 minecraft:red_concrete
setblock 330 117 427 minecraft:red_concrete
setblock 330 117 434 minecraft:red_concrete
setblock 330 117 441 minecraft:red_concrete
setblock 330 117 448 minecraft:red_concrete
setblock 330 117 455 minecraft:red_concrete
setblock 334 117 417 minecraft:red_concrete
setblock 335 117 457 minecraft:red_concrete
setblock 341 117 417 minecraft:red_concrete
setblock 342 117 457 minecraft:red_concrete
setblock 348 117 417 minecraft:red_concrete
setblock 349 117 457 minecraft:red_concrete
setblock 355 117 417 minecraft:red_concrete
setblock 356 117 457 minecraft:red_concrete
setblock 362 117 417 minecraft:red_concrete
setblock 363 117 457 minecraft:red_concrete
setblock 369 117 417 minecraft:red_concrete
setblock 370 117 423 minecraft:red_concrete
setblock 370 117 430 minecraft:red_concrete
setblock 370 117 457 minecraft:red_concrete
setblock 330 118 421 minecraft:red_concrete
setblock 330 118 428 minecraft:red_concrete
setblock 330 118 435 minecraft:red_concrete
setblock 330 118 442 minecraft:red_concrete
setblock 330 118 449 minecraft:red_concrete
setblock 330 118 456 minecraft:red_concrete
setblock 332 118 419 minecraft:light[level=12]
setblock 332 118 427 minecraft:light[level=12]
setblock 332 118 435 minecraft:light[level=12]
setblock 332 118 443 minecraft:light[level=12]
setblock 332 118 451 minecraft:light[level=12]
setblock 333 118 417 minecraft:red_concrete
setblock 336 118 457 minecraft:red_concrete
setblock 340 118 417 minecraft:red_concrete
setblock 340 118 419 minecraft:light[level=12]
setblock 340 118 427 minecraft:light[level=12]
setblock 340 118 435 minecraft:light[level=12]
setblock 340 118 443 minecraft:light[level=12]
setblock 340 118 451 minecraft:light[level=12]
setblock 343 118 457 minecraft:red_concrete
setblock 347 118 417 minecraft:red_concrete
setblock 348 118 419 minecraft:light[level=12]
setblock 348 118 427 minecraft:light[level=12]
setblock 348 118 435 minecraft:light[level=12]
setblock 348 118 443 minecraft:light[level=12]
setblock 348 118 451 minecraft:light[level=12]
setblock 350 118 457 minecraft:red_concrete
setblock 354 118 417 minecraft:red_concrete
setblock 356 118 419 minecraft:light[level=12]
setblock 356 118 427 minecraft:light[level=12]
setblock 356 118 435 minecraft:light[level=12]
setblock 356 118 443 minecraft:light[level=12]
setblock 356 118 451 minecraft:light[level=12]
setblock 357 118 457 minecraft:red_concrete
setblock 361 118 417 minecraft:red_concrete
setblock 362 118 443 minecraft:jack_o_lantern
setblock 362 118 445 minecraft:jack_o_lantern
setblock 362 118 447 minecraft:jack_o_lantern
setblock 362 118 449 minecraft:jack_o_lantern
setblock 362 118 451 minecraft:jack_o_lantern
setblock 362 118 453 minecraft:jack_o_lantern
setblock 362 118 455 minecraft:jack_o_lantern
setblock 363 118 438 minecraft:jack_o_lantern
setblock 363 118 440 minecraft:jack_o_lantern
setblock 363 118 442 minecraft:jack_o_lantern
setblock 363 118 444 minecraft:jack_o_lantern
setblock 363 118 446 minecraft:jack_o_lantern
setblock 363 118 448 minecraft:jack_o_lantern
setblock 363 118 450 minecraft:jack_o_lantern
setblock 363 118 452 minecraft:jack_o_lantern
setblock 363 118 454 minecraft:jack_o_lantern
setblock 364 118 419 minecraft:light[level=12]
setblock 364 118 427 minecraft:light[level=12]
setblock 364 118 435 minecraft:light[level=12]
setblock 364 118 437 minecraft:jack_o_lantern
setblock 364 118 439 minecraft:jack_o_lantern
setblock 364 118 441 minecraft:jack_o_lantern
setblock 364 118 443 minecraft:jack_o_lantern
setblock 364 118 445 minecraft:jack_o_lantern
setblock 364 118 447 minecraft:jack_o_lantern
setblock 364 118 449 minecraft:jack_o_lantern
setblock 364 118 451 minecraft:jack_o_lantern
setblock 364 118 453 minecraft:jack_o_lantern
setblock 364 118 455 minecraft:jack_o_lantern
setblock 364 118 457 minecraft:red_concrete
setblock 365 118 438 minecraft:jack_o_lantern
setblock 365 118 440 minecraft:jack_o_lantern
setblock 365 118 442 minecraft:jack_o_lantern
setblock 365 118 444 minecraft:jack_o_lantern
setblock 365 118 446 minecraft:jack_o_lantern
setblock 365 118 448 minecraft:jack_o_lantern
setblock 365 118 450 minecraft:jack_o_lantern
setblock 365 118 452 minecraft:jack_o_lantern
setblock 365 118 454 minecraft:jack_o_lantern
setblock 366 118 437 minecraft:jack_o_lantern
setblock 366 118 439 minecraft:jack_o_lantern
setblock 366 118 441 minecraft:jack_o_lantern
setblock 366 118 443 minecraft:jack_o_lantern
setblock 366 118 445 minecraft:jack_o_lantern
setblock 366 118 447 minecraft:jack_o_lantern
setblock 366 118 449 minecraft:jack_o_lantern
setblock 366 118 451 minecraft:jack_o_lantern
setblock 366 118 453 minecraft:jack_o_lantern
setblock 366 118 455 minecraft:jack_o_lantern
setblock 367 118 438 minecraft:jack_o_lantern
setblock 367 118 440 minecraft:jack_o_lantern
setblock 367 118 442 minecraft:jack_o_lantern
setblock 367 118 444 minecraft:jack_o_lantern
setblock 367 118 446 minecraft:jack_o_lantern
setblock 367 118 448 minecraft:jack_o_lantern
setblock 367 118 450 minecraft:jack_o_lantern
setblock 367 118 452 minecraft:jack_o_lantern
setblock 367 118 454 minecraft:jack_o_lantern
setblock 368 118 417 minecraft:red_concrete
setblock 368 118 437 minecraft:jack_o_lantern
setblock 368 118 439 minecraft:jack_o_lantern
setblock 368 118 441 minecraft:jack_o_lantern
setblock 368 118 443 minecraft:jack_o_lantern
setblock 368 118 445 minecraft:jack_o_lantern
setblock 368 118 447 minecraft:jack_o_lantern
setblock 368 118 449 minecraft:jack_o_lantern
setblock 368 118 451 minecraft:jack_o_lantern
setblock 368 118 453 minecraft:jack_o_lantern
setblock 368 118 455 minecraft:jack_o_lantern
setblock 369 118 438 minecraft:jack_o_lantern
setblock 369 118 440 minecraft:jack_o_lantern
setblock 369 118 442 minecraft:jack_o_lantern
setblock 369 118 444 minecraft:jack_o_lantern
setblock 369 118 446 minecraft:jack_o_lantern
setblock 369 118 448 minecraft:jack_o_lantern
setblock 369 118 450 minecraft:jack_o_lantern
setblock 369 118 452 minecraft:jack_o_lantern
setblock 369 118 454 minecraft:jack_o_lantern
setblock 370 118 422 minecraft:red_concrete
setblock 370 118 429 minecraft:red_concrete
setblock 370 118 436 minecraft:red_concrete
setblock 370 118 437 minecraft:jack_o_lantern
setblock 370 118 439 minecraft:jack_o_lantern
setblock 370 118 441 minecraft:jack_o_lantern
setblock 370 118 443 minecraft:jack_o_lantern
setblock 370 118 445 minecraft:jack_o_lantern
setblock 370 118 447 minecraft:jack_o_lantern
setblock 370 118 449 minecraft:jack_o_lantern
setblock 370 118 451 minecraft:jack_o_lantern
setblock 370 118 453 minecraft:jack_o_lantern
setblock 370 118 455 minecraft:jack_o_lantern
fill 362 119 443 362 120 443 minecraft:red_concrete
fill 362 119 445 362 120 445 minecraft:red_concrete
fill 362 119 447 362 120 447 minecraft:red_concrete
fill 362 119 449 362 120 449 minecraft:red_concrete
fill 362 119 451 362 120 451 minecraft:red_concrete
fill 362 119 453 362 120 453 minecraft:red_concrete
fill 362 119 455 362 120 455 minecraft:red_concrete
fill 363 119 438 363 121 438 minecraft:red_concrete
fill 363 119 440 363 121 440 minecraft:red_concrete
fill 363 119 442 363 121 442 minecraft:red_concrete
fill 363 119 444 363 120 444 minecraft:red_concrete
fill 363 119 446 363 120 446 minecraft:red_concrete
fill 363 119 448 363 120 448 minecraft:red_concrete
fill 363 119 450 363 120 450 minecraft:red_concrete
fill 363 119 452 363 120 452 minecraft:red_concrete
fill 363 119 454 363 120 454 minecraft:red_concrete
fill 364 119 437 364 121 437 minecraft:red_concrete
fill 364 119 439 364 121 439 minecraft:red_concrete
fill 364 119 441 364 121 441 minecraft:red_concrete
fill 364 119 443 364 120 443 minecraft:red_concrete
fill 364 119 445 364 120 445 minecraft:red_concrete
fill 364 119 447 364 120 447 minecraft:red_concrete
fill 364 119 449 364 120 449 minecraft:red_concrete
fill 364 119 451 364 120 451 minecraft:red_concrete
fill 364 119 453 364 120 453 minecraft:red_concrete
fill 364 119 455 364 120 455 minecraft:red_concrete
fill 365 119 438 365 121 438 minecraft:red_concrete
fill 365 119 440 365 121 440 minecraft:red_concrete
fill 365 119 442 365 121 442 minecraft:red_concrete
fill 365 119 444 365 120 444 minecraft:red_concrete
fill 365 119 446 365 120 446 minecraft:red_concrete
fill 365 119 448 365 120 448 minecraft:red_concrete
fill 365 119 450 365 120 450 minecraft:red_concrete
fill 365 119 452 365 120 452 minecraft:red_concrete
fill 365 119 454 365 120 454 minecraft:red_concrete
fill 366 119 437 366 121 437 minecraft:red_concrete
fill 366 119 439 366 121 439 minecraft:red_concrete
fill 366 119 441 366 121 441 minecraft:red_concrete
fill 366 119 443 366 120 443 minecraft:red_concrete
fill 366 119 445 366 120 445 minecraft:red_concrete
fill 366 119 447 366 120 447 minecraft:red_concrete
fill 366 119 449 366 120 449 minecraft:red_concrete
fill 366 119 451 366 120 451 minecraft:red_concrete
fill 366 119 453 366 120 453 minecraft:red_concrete
fill 366 119 455 366 120 455 minecraft:red_concrete
fill 367 119 438 367 121 438 minecraft:red_concrete
fill 367 119 440 367 121 440 minecraft:red_concrete
fill 367 119 442 367 121 442 minecraft:red_concrete
fill 367 119 444 367 120 444 minecraft:red_concrete
fill 367 119 446 367 120 446 minecraft:red_concrete
fill 367 119 448 367 120 448 minecraft:red_concrete
fill 367 119 450 367 120 450 minecraft:red_concrete
fill 367 119 452 367 120 452 minecraft:red_concrete
fill 367 119 454 367 120 454 minecraft:red_concrete
fill 368 119 437 368 121 437 minecraft:red_concrete
fill 368 119 439 368 121 439 minecraft:red_concrete
fill 368 119 441 368 121 441 minecraft:red_concrete
fill 368 119 443 368 120 443 minecraft:red_concrete
fill 368 119 445 368 120 445 minecraft:red_concrete
fill 368 119 447 368 120 447 minecraft:red_concrete
fill 368 119 449 368 120 449 minecraft:red_concrete
fill 368 119 451 368 120 451 minecraft:red_concrete
fill 368 119 453 368 120 453 minecraft:red_concrete
fill 368 119 455 368 120 455 minecraft:red_concrete
fill 369 119 438 369 121 438 minecraft:red_concrete
fill 369 119 440 369 121 440 minecraft:red_concrete
fill 369 119 442 369 121 442 minecraft:red_concrete
schedule function dropper:buildpart/103_2 1t
