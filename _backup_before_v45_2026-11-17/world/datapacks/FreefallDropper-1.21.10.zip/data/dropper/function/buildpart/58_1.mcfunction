fill 510 98 233 510 102 233 minecraft:red_concrete
setblock 510 98 268 minecraft:white_concrete
fill 510 98 269 510 102 269 minecraft:red_concrete
fill 471 99 230 471 103 230 minecraft:white_concrete
fill 471 99 266 471 103 266 minecraft:white_concrete
setblock 473 99 239 minecraft:light[level=15]
setblock 473 99 247 minecraft:light[level=15]
setblock 473 99 255 minecraft:light[level=15]
setblock 473 99 263 minecraft:light[level=15]
fill 474 99 232 475 102 232 minecraft:red_concrete
fill 474 99 268 475 102 268 minecraft:red_concrete
setblock 481 99 231 minecraft:light[level=15]
setblock 481 99 239 minecraft:light[level=15]
setblock 481 99 247 minecraft:light[level=15]
setblock 481 99 255 minecraft:light[level=15]
setblock 481 99 263 minecraft:light[level=15]
setblock 489 99 231 minecraft:light[level=15]
setblock 489 99 239 minecraft:light[level=15]
setblock 489 99 247 minecraft:light[level=15]
setblock 489 99 255 minecraft:light[level=15]
setblock 489 99 263 minecraft:light[level=15]
setblock 497 99 231 minecraft:light[level=15]
setblock 497 99 239 minecraft:light[level=15]
setblock 497 99 247 minecraft:light[level=15]
setblock 497 99 255 minecraft:light[level=15]
setblock 497 99 263 minecraft:light[level=15]
setblock 505 99 231 minecraft:light[level=15]
setblock 505 99 239 minecraft:light[level=15]
setblock 505 99 255 minecraft:light[level=15]
setblock 505 99 263 minecraft:light[level=15]
fill 507 99 230 507 103 230 minecraft:white_concrete
fill 507 99 266 507 103 266 minecraft:white_concrete
fill 510 99 232 511 102 232 minecraft:red_concrete
fill 510 99 268 511 102 268 minecraft:red_concrete
fill 471 100 231 471 104 232 minecraft:white_concrete
fill 471 100 267 471 104 268 minecraft:white_concrete
fill 472 100 231 472 104 231 minecraft:white_concrete
setblock 472 100 232 minecraft:red_concrete
fill 472 100 267 472 104 267 minecraft:white_concrete
setblock 472 100 268 minecraft:red_concrete
fill 473 100 231 475 104 231 minecraft:red_concrete
setblock 473 100 238 minecraft:light[level=12]
setblock 473 100 245 minecraft:light[level=12]
setblock 473 100 252 minecraft:light[level=12]
setblock 473 100 259 minecraft:light[level=12]
fill 473 100 267 475 104 267 minecraft:red_concrete
setblock 480 100 231 minecraft:light[level=12]
setblock 480 100 238 minecraft:light[level=12]
setblock 480 100 245 minecraft:light[level=12]
setblock 480 100 252 minecraft:light[level=12]
setblock 480 100 259 minecraft:light[level=12]
setblock 480 100 266 minecraft:light[level=12]
fill 483 100 236 485 100 239 minecraft:orange_terracotta
fill 484 100 235 489 100 235 minecraft:orange_terracotta
fill 484 100 240 489 100 240 minecraft:orange_terracotta
fill 485 100 234 488 100 234 minecraft:orange_terracotta
fill 485 100 241 488 100 241 minecraft:orange_terracotta
fill 486 100 236 490 100 236 minecraft:orange_terracotta
fill 486 100 239 490 100 239 minecraft:orange_terracotta
setblock 487 100 231 minecraft:light[level=12]
setblock 487 100 238 minecraft:light[level=12]
setblock 487 100 245 minecraft:light[level=12]
setblock 487 100 252 minecraft:light[level=12]
setblock 487 100 259 minecraft:light[level=12]
setblock 487 100 266 minecraft:light[level=12]
fill 488 100 237 490 100 238 minecraft:orange_terracotta
setblock 494 100 231 minecraft:light[level=12]
setblock 494 100 238 minecraft:light[level=12]
setblock 494 100 245 minecraft:light[level=12]
setblock 494 100 252 minecraft:light[level=12]
setblock 494 100 259 minecraft:light[level=12]
setblock 494 100 266 minecraft:light[level=12]
setblock 501 100 231 minecraft:light[level=12]
setblock 501 100 238 minecraft:light[level=12]
fill 501 100 242 502 101 243 minecraft:pink_concrete
setblock 501 100 245 minecraft:light[level=12]
setblock 501 100 252 minecraft:light[level=12]
setblock 501 100 259 minecraft:light[level=12]
setblock 501 100 266 minecraft:light[level=12]
fill 503 100 242 503 101 242 minecraft:pink_concrete
fill 504 100 259 505 101 260 minecraft:pink_concrete
fill 507 100 231 507 104 232 minecraft:white_concrete
fill 507 100 267 507 104 268 minecraft:white_concrete
fill 508 100 231 508 104 231 minecraft:white_concrete
setblock 508 100 232 minecraft:red_concrete
setblock 508 100 238 minecraft:light[level=12]
setblock 508 100 245 minecraft:light[level=12]
setblock 508 100 252 minecraft:light[level=12]
setblock 508 100 259 minecraft:light[level=12]
fill 508 100 267 508 104 267 minecraft:white_concrete
setblock 508 100 268 minecraft:red_concrete
fill 509 100 231 511 104 231 minecraft:red_concrete
fill 509 100 267 511 104 267 minecraft:red_concrete
fill 472 101 232 472 105 233 minecraft:white_concrete
fill 472 101 268 472 105 269 minecraft:white_concrete
setblock 473 101 233 minecraft:red_concrete
setblock 473 101 269 minecraft:red_concrete
setblock 474 101 229 minecraft:white_concrete
fill 474 101 230 475 104 230 minecraft:red_concrete
setblock 474 101 265 minecraft:white_concrete
fill 474 101 266 475 104 266 minecraft:red_concrete
fill 483 101 236 485 101 239 minecraft:pink_concrete
fill 484 101 235 489 101 235 minecraft:pink_concrete
fill 484 101 240 489 101 240 minecraft:pink_concrete
fill 485 101 234 488 101 234 minecraft:pink_concrete
fill 485 101 241 488 101 241 minecraft:pink_concrete
fill 486 101 236 490 101 236 minecraft:pink_concrete
fill 486 101 239 490 101 239 minecraft:pink_concrete
fill 488 101 237 490 101 238 minecraft:pink_concrete
fill 508 101 232 508 105 233 minecraft:white_concrete
fill 508 101 268 508 105 269 minecraft:white_concrete
setblock 509 101 233 minecraft:red_concrete
setblock 509 101 269 minecraft:red_concrete
setblock 510 101 229 minecraft:white_concrete
fill 510 101 230 511 104 230 minecraft:red_concrete
setblock 510 101 265 minecraft:white_concrete
fill 510 101 266 511 104 266 minecraft:red_concrete
fill 473 102 229 473 106 230 minecraft:red_concrete
fill 473 102 232 473 106 233 minecraft:white_concrete
fill 473 102 265 473 106 266 minecraft:red_concrete
fill 473 102 268 473 106 269 minecraft:white_concrete
fill 474 102 229 474 105 229 minecraft:red_concrete
fill 474 102 265 474 105 265 minecraft:red_concrete
fill 485 102 239 485 102 241 minecraft:magenta_concrete
fill 486 102 238 488 102 238 minecraft:magenta_concrete
fill 486 102 239 487 105 240 minecraft:white_concrete
fill 486 102 241 486 102 242 minecraft:magenta_concrete
fill 487 102 241 487 105 241 minecraft:white_concrete
setblock 487 102 242 minecraft:magenta_concrete
fill 488 102 239 488 103 241 minecraft:magenta_concrete
fill 488 102 262 488 105 266 minecraft:magenta_concrete
fill 489 102 239 489 102 240 minecraft:magenta_concrete
fill 489 102 262 489 105 263 minecraft:magenta_concrete
fill 489 102 265 489 105 266 minecraft:magenta_concrete
fill 490 102 262 492 105 262 minecraft:magenta_concrete
fill 490 102 266 492 105 266 minecraft:magenta_concrete
fill 491 102 263 492 105 263 minecraft:magenta_concrete
fill 491 102 265 492 105 265 minecraft:magenta_concrete
fill 492 102 264 492 105 264 minecraft:magenta_concrete
fill 501 102 245 502 102 248 minecraft:magenta_concrete
fill 502 102 244 507 103 244 minecraft:magenta_concrete
fill 502 102 249 507 102 249 minecraft:magenta_concrete
fill 503 102 243 507 102 243 minecraft:magenta_concrete
fill 503 102 248 503 104 248 minecraft:magenta_concrete
fill 503 102 250 506 102 250 minecraft:magenta_concrete
fill 506 102 248 508 102 248 minecraft:magenta_concrete
fill 507 102 245 508 102 247 minecraft:magenta_concrete
fill 509 102 229 509 106 230 minecraft:red_concrete
fill 509 102 232 509 106 233 minecraft:white_concrete
fill 509 102 265 509 106 266 minecraft:red_concrete
fill 509 102 268 509 106 269 minecraft:white_concrete
fill 510 102 229 510 105 229 minecraft:red_concrete
fill 510 102 265 510 105 265 minecraft:red_concrete
fill 472 103 229 472 107 229 minecraft:red_concrete
setblock 472 103 230 minecraft:white_concrete
fill 472 103 265 472 107 265 minecraft:red_concrete
setblock 472 103 266 minecraft:white_concrete
fill 474 103 232 474 107 233 minecraft:white_concrete
fill 474 103 268 474 107 269 minecraft:white_concrete
setblock 475 103 232 minecraft:red_concrete
setblock 475 103 268 minecraft:red_concrete
fill 485 103 239 485 103 240 minecraft:magenta_concrete
fill 486 103 238 487 103 238 minecraft:magenta_concrete
fill 486 103 241 486 104 241 minecraft:magenta_concrete
fill 487 103 262 487 104 266 minecraft:magenta_concrete
fill 488 103 261 492 104 261 minecraft:magenta_concrete
fill 488 103 267 492 104 267 minecraft:magenta_concrete
fill 493 103 262 493 104 266 minecraft:magenta_concrete
fill 502 103 245 502 103 248 minecraft:magenta_concrete
fill 503 103 249 506 103 249 minecraft:magenta_concrete
fill 504 103 243 505 103 243 minecraft:magenta_concrete
fill 506 103 248 507 103 248 minecraft:magenta_concrete
fill 507 103 245 507 104 247 minecraft:magenta_concrete
fill 508 103 229 508 107 229 minecraft:red_concrete
setblock 508 103 230 minecraft:white_concrete
fill 508 103 265 508 107 265 minecraft:red_concrete
setblock 508 103 266 minecraft:white_concrete
fill 510 103 232 510 107 233 minecraft:white_concrete
fill 510 103 268 510 107 269 minecraft:white_concrete
setblock 511 103 232 minecraft:red_concrete
setblock 511 103 268 minecraft:red_concrete
fill 471 104 230 472 107 230 minecraft:red_concrete
fill 471 104 266 472 107 266 minecraft:red_concrete
fill 475 104 232 475 108 232 minecraft:white_concrete
fill 475 104 268 475 108 268 minecraft:white_concrete
fill 488 104 239 488 104 240 minecraft:magenta_concrete
fill 489 104 264 491 105 264 minecraft:magenta_concrete
fill 490 104 263 490 105 263 minecraft:magenta_concrete
fill 490 104 265 490 105 265 minecraft:magenta_concrete
fill 502 104 245 502 104 247 minecraft:magenta_concrete
fill 503 104 244 506 104 244 minecraft:magenta_concrete
fill 504 104 249 505 104 249 minecraft:magenta_concrete
setblock 506 104 248 minecraft:magenta_concrete
fill 507 104 230 508 107 230 minecraft:red_concrete
fill 507 104 266 508 107 266 minecraft:red_concrete
fill 511 104 232 511 108 232 minecraft:white_concrete
fill 511 104 268 511 108 268 minecraft:white_concrete
fill 471 105 231 472 109 231 minecraft:red_concrete
setblock 471 105 232 minecraft:white_concrete
fill 471 105 267 472 109 267 minecraft:red_concrete
setblock 471 105 268 minecraft:white_concrete
fill 473 105 231 475 109 231 minecraft:white_concrete
fill 473 105 267 475 109 267 minecraft:white_concrete
setblock 474 105 230 minecraft:red_concrete
setblock 474 105 266 minecraft:red_concrete
fill 475 105 230 475 110 230 minecraft:white_concrete
fill 475 105 266 475 110 266 minecraft:white_concrete
fill 507 105 231 508 109 231 minecraft:red_concrete
setblock 507 105 232 minecraft:white_concrete
fill 507 105 267 508 109 267 minecraft:red_concrete
setblock 507 105 268 minecraft:white_concrete
fill 509 105 231 511 109 231 minecraft:white_concrete
fill 509 105 267 511 109 267 minecraft:white_concrete
setblock 510 105 230 minecraft:red_concrete
setblock 510 105 266 minecraft:red_concrete
fill 511 105 230 511 110 230 minecraft:white_concrete
fill 511 105 266 511 110 266 minecraft:white_concrete
fill 471 106 232 472 109 232 minecraft:red_concrete
fill 471 106 268 472 109 268 minecraft:red_concrete
setblock 472 106 233 minecraft:white_concrete
setblock 472 106 269 minecraft:white_concrete
setblock 473 106 238 minecraft:light[level=12]
setblock 473 106 239 minecraft:light[level=15]
setblock 473 106 245 minecraft:light[level=12]
setblock 473 106 247 minecraft:light[level=15]
setblock 473 106 252 minecraft:light[level=12]
setblock 473 106 255 minecraft:light[level=15]
setblock 473 106 259 minecraft:light[level=12]
setblock 473 106 263 minecraft:light[level=15]
fill 474 106 229 474 110 230 minecraft:white_concrete
fill 474 106 265 474 110 266 minecraft:white_concrete
setblock 480 106 231 minecraft:light[level=12]
setblock 480 106 238 minecraft:light[level=12]
setblock 480 106 245 minecraft:light[level=12]
setblock 480 106 252 minecraft:light[level=12]
setblock 480 106 259 minecraft:light[level=12]
setblock 480 106 266 minecraft:light[level=12]
setblock 481 106 231 minecraft:light[level=15]
setblock 481 106 239 minecraft:light[level=15]
setblock 481 106 247 minecraft:light[level=15]
setblock 481 106 255 minecraft:light[level=15]
setblock 481 106 263 minecraft:light[level=15]
setblock 487 106 231 minecraft:light[level=12]
setblock 487 106 238 minecraft:light[level=12]
setblock 487 106 245 minecraft:light[level=12]
setblock 487 106 252 minecraft:light[level=12]
setblock 487 106 259 minecraft:light[level=12]
setblock 487 106 266 minecraft:light[level=12]
setblock 489 106 231 minecraft:light[level=15]
setblock 489 106 239 minecraft:light[level=15]
setblock 489 106 247 minecraft:light[level=15]
setblock 489 106 255 minecraft:light[level=15]
setblock 489 106 263 minecraft:light[level=15]
setblock 494 106 231 minecraft:light[level=12]
setblock 494 106 238 minecraft:light[level=12]
setblock 494 106 245 minecraft:light[level=12]
setblock 494 106 252 minecraft:light[level=12]
setblock 494 106 259 minecraft:light[level=12]
setblock 494 106 266 minecraft:light[level=12]
setblock 497 106 231 minecraft:light[level=15]
setblock 497 106 239 minecraft:light[level=15]
setblock 497 106 247 minecraft:light[level=15]
setblock 497 106 255 minecraft:light[level=15]
setblock 497 106 263 minecraft:light[level=15]
setblock 501 106 231 minecraft:light[level=12]
setblock 501 106 238 minecraft:light[level=12]
setblock 501 106 245 minecraft:light[level=12]
setblock 501 106 252 minecraft:light[level=12]
setblock 501 106 259 minecraft:light[level=12]
setblock 501 106 266 minecraft:light[level=12]
setblock 505 106 231 minecraft:light[level=15]
setblock 505 106 239 minecraft:light[level=15]
setblock 505 106 247 minecraft:light[level=15]
setblock 505 106 255 minecraft:light[level=15]
setblock 505 106 263 minecraft:light[level=15]
fill 507 106 232 508 109 232 minecraft:red_concrete
fill 507 106 268 508 109 268 minecraft:red_concrete
setblock 508 106 233 minecraft:white_concrete
setblock 508 106 238 minecraft:light[level=12]
setblock 508 106 245 minecraft:light[level=12]
setblock 508 106 252 minecraft:light[level=12]
setblock 508 106 259 minecraft:light[level=12]
setblock 508 106 269 minecraft:white_concrete
fill 510 106 229 510 110 230 minecraft:white_concrete
fill 510 106 265 510 110 266 minecraft:white_concrete
fill 472 107 233 473 110 233 minecraft:red_concrete
fill 472 107 269 473 110 269 minecraft:red_concrete
fill 473 107 229 473 111 230 minecraft:white_concrete
fill 473 107 232 473 111 232 minecraft:red_concrete
fill 473 107 265 473 111 266 minecraft:white_concrete
fill 473 107 268 473 111 268 minecraft:red_concrete
fill 508 107 233 509 110 233 minecraft:red_concrete
fill 508 107 269 509 110 269 minecraft:red_concrete
fill 509 107 229 509 111 230 minecraft:white_concrete
fill 509 107 232 509 111 232 minecraft:red_concrete
fill 509 107 265 509 111 266 minecraft:white_concrete
fill 509 107 268 509 111 268 minecraft:red_concrete
setblock 471 108 230 minecraft:red_concrete
setblock 471 108 266 minecraft:red_concrete
fill 472 108 229 472 112 230 minecraft:white_concrete
fill 472 108 265 472 112 266 minecraft:white_concrete
setblock 474 108 232 minecraft:white_concrete
fill 474 108 233 474 112 233 minecraft:red_concrete
setblock 474 108 268 minecraft:white_concrete
fill 474 108 269 474 112 269 minecraft:red_concrete
setblock 507 108 230 minecraft:red_concrete
setblock 507 108 266 minecraft:red_concrete
fill 508 108 229 508 112 230 minecraft:white_concrete
fill 508 108 265 508 112 266 minecraft:white_concrete
setblock 510 108 232 minecraft:white_concrete
fill 510 108 233 510 112 233 minecraft:red_concrete
setblock 510 108 268 minecraft:white_concrete
fill 510 108 269 510 112 269 minecraft:red_concrete
fill 471 109 230 471 113 230 minecraft:white_concrete
fill 471 109 266 471 113 266 minecraft:white_concrete
fill 474 109 232 475 112 232 minecraft:red_concrete
fill 474 109 268 475 112 268 minecraft:red_concrete
fill 507 109 230 507 113 230 minecraft:white_concrete
fill 507 109 266 507 113 266 minecraft:white_concrete
fill 510 109 232 511 112 232 minecraft:red_concrete
fill 510 109 268 511 112 268 minecraft:red_concrete
fill 471 110 231 471 114 232 minecraft:white_concrete
fill 471 110 267 471 114 268 minecraft:white_concrete
fill 472 110 231 472 114 231 minecraft:white_concrete
setblock 472 110 232 minecraft:red_concrete
fill 472 110 267 472 114 267 minecraft:white_concrete
setblock 472 110 268 minecraft:red_concrete
fill 473 110 231 475 114 231 minecraft:red_concrete
fill 473 110 267 475 114 267 minecraft:red_concrete
fill 507 110 231 507 114 232 minecraft:white_concrete
fill 507 110 267 507 114 268 minecraft:white_concrete
fill 508 110 231 508 114 231 minecraft:white_concrete
setblock 508 110 232 minecraft:red_concrete
fill 508 110 267 508 114 267 minecraft:white_concrete
setblock 508 110 268 minecraft:red_concrete
fill 509 110 231 511 114 231 minecraft:red_concrete
fill 509 110 267 511 114 267 minecraft:red_concrete
fill 472 111 232 472 115 233 minecraft:white_concrete
fill 472 111 268 472 115 269 minecraft:white_concrete
setblock 473 111 233 minecraft:red_concrete
setblock 473 111 269 minecraft:red_concrete
setblock 474 111 229 minecraft:white_concrete
fill 474 111 230 475 114 230 minecraft:red_concrete
setblock 474 111 265 minecraft:white_concrete
fill 474 111 266 475 114 266 minecraft:red_concrete
fill 486 111 247 487 115 251 minecraft:red_concrete
fill 486 111 252 487 115 255 minecraft:purple_concrete
fill 487 111 245 490 115 245 minecraft:orange_concrete
fill 487 111 246 487 115 246 minecraft:red_concrete
fill 487 111 256 487 115 256 minecraft:purple_concrete
fill 487 111 257 490 115 257 minecraft:light_blue_concrete
fill 488 111 244 491 115 244 minecraft:orange_concrete
fill 488 111 246 489 115 246 minecraft:orange_concrete
fill 488 111 247 488 115 249 minecraft:red_concrete
fill 488 111 251 492 112 251 minecraft:lime_stained_glass
fill 488 111 253 488 115 255 minecraft:purple_concrete
fill 488 111 256 489 115 256 minecraft:light_blue_concrete
fill 488 111 258 491 115 258 minecraft:light_blue_concrete
fill 489 111 243 491 115 243 minecraft:orange_concrete
fill 489 111 248 493 112 250 minecraft:lime_stained_glass
fill 489 111 252 493 112 254 minecraft:lime_stained_glass
fill 489 111 259 491 115 259 minecraft:light_blue_concrete
fill 490 111 242 490 115 242 minecraft:orange_concrete
fill 490 111 246 502 112 247 minecraft:lime_stained_glass
fill 490 111 255 502 112 256 minecraft:lime_stained_glass
fill 490 111 260 490 115 260 minecraft:light_blue_concrete
fill 491 111 242 495 115 242 minecraft:yellow_concrete
fill 491 111 245 501 112 245 minecraft:lime_stained_glass
fill 491 111 257 501 112 257 minecraft:lime_stained_glass
fill 491 111 260 496 115 260 minecraft:lime_concrete
fill 492 111 241 495 115 241 minecraft:yellow_concrete
fill 492 111 243 494 115 243 minecraft:yellow_concrete
fill 492 111 259 494 115 259 minecraft:lime_concrete
fill 492 111 261 496 115 261 minecraft:lime_concrete
fill 493 111 244 499 112 244 minecraft:lime_stained_glass
fill 493 111 258 499 112 258 minecraft:lime_stained_glass
fill 494 111 248 495 112 248 minecraft:lime_stained_glass
fill 494 111 254 495 112 254 minecraft:lime_stained_glass
fill 496 111 241 500 115 242 minecraft:lime_concrete
fill 496 111 243 496 113 243 minecraft:lime_stained_glass
fill 496 111 259 496 112 259 minecraft:lime_stained_glass
fill 497 111 248 503 112 248 minecraft:lime_stained_glass
fill 497 111 254 503 112 254 minecraft:lime_stained_glass
fill 497 111 260 500 115 261 minecraft:yellow_concrete
fill 498 111 243 500 115 243 minecraft:lime_concrete
fill 498 111 259 500 115 259 minecraft:yellow_concrete
fill 499 111 249 503 112 250 minecraft:lime_stained_glass
fill 499 111 252 503 112 253 minecraft:lime_stained_glass
fill 500 111 251 504 112 251 minecraft:lime_stained_glass
fill 501 111 242 501 115 242 minecraft:lime_concrete
fill 501 111 243 503 115 244 minecraft:light_blue_concrete
fill 501 111 258 503 115 259 minecraft:orange_concrete
fill 501 111 260 501 115 260 minecraft:yellow_concrete
fill 502 111 242 502 115 242 minecraft:light_blue_concrete
fill 502 111 245 505 115 245 minecraft:light_blue_concrete
fill 502 111 257 505 115 257 minecraft:orange_concrete
fill 502 111 260 502 115 260 minecraft:orange_concrete
fill 503 111 246 504 115 246 minecraft:light_blue_concrete
fill 503 111 256 504 115 256 minecraft:orange_concrete
fill 504 111 244 504 115 244 minecraft:light_blue_concrete
fill 504 111 247 506 115 249 minecraft:purple_concrete
fill 504 111 253 506 115 255 minecraft:red_concrete
fill 504 111 258 504 115 258 minecraft:orange_concrete
fill 505 111 246 505 115 246 minecraft:purple_concrete
fill 505 111 250 506 115 250 minecraft:purple_concrete
fill 505 111 251 506 115 252 minecraft:red_concrete
fill 505 111 256 505 115 256 minecraft:red_concrete
fill 508 111 232 508 115 233 minecraft:white_concrete
fill 508 111 268 508 115 269 minecraft:white_concrete
setblock 509 111 233 minecraft:red_concrete
setblock 509 111 269 minecraft:red_concrete
setblock 510 111 229 minecraft:white_concrete
fill 510 111 230 511 114 230 minecraft:red_concrete
setblock 510 111 265 minecraft:white_concrete
fill 510 111 266 511 114 266 minecraft:red_concrete
fill 473 112 229 473 116 230 minecraft:red_concrete
fill 473 112 232 473 115 233 minecraft:white_concrete
setblock 473 112 238 minecraft:light[level=12]
setblock 473 112 245 minecraft:light[level=12]
setblock 473 112 252 minecraft:light[level=12]
setblock 473 112 259 minecraft:light[level=12]
fill 473 112 265 473 116 266 minecraft:red_concrete
fill 473 112 268 473 116 269 minecraft:white_concrete
fill 474 112 229 474 115 229 minecraft:red_concrete
fill 474 112 265 474 115 265 minecraft:red_concrete
setblock 480 112 231 minecraft:light[level=12]
setblock 480 112 238 minecraft:light[level=12]
setblock 480 112 245 minecraft:light[level=12]
setblock 480 112 252 minecraft:light[level=12]
setblock 480 112 259 minecraft:light[level=12]
setblock 480 112 266 minecraft:light[level=12]
fill 485 112 248 485 114 251 minecraft:red_concrete
fill 485 112 252 485 114 254 minecraft:purple_concrete
fill 486 112 245 486 114 245 minecraft:orange_concrete
fill 486 112 246 486 114 246 minecraft:red_concrete
fill 486 112 256 486 114 256 minecraft:purple_concrete
fill 486 112 257 486 114 257 minecraft:light_blue_concrete
setblock 487 112 231 minecraft:light[level=12]
setblock 487 112 238 minecraft:light[level=12]
fill 487 112 244 487 114 244 minecraft:orange_concrete
fill 487 112 258 487 114 258 minecraft:light_blue_concrete
setblock 487 112 259 minecraft:light[level=12]
setblock 487 112 266 minecraft:light[level=12]
fill 488 112 243 488 114 243 minecraft:orange_concrete
fill 488 112 250 488 114 250 minecraft:red_concrete
fill 488 112 252 488 114 252 minecraft:purple_concrete
fill 488 112 259 488 114 259 minecraft:light_blue_concrete
fill 489 112 242 489 114 242 minecraft:orange_concrete
fill 489 112 247 489 114 247 minecraft:red_concrete
fill 489 112 255 489 114 255 minecraft:purple_concrete
fill 489 112 260 489 114 260 minecraft:light_blue_concrete
fill 490 112 241 490 114 241 minecraft:orange_concrete
fill 490 112 261 490 114 261 minecraft:light_blue_concrete
fill 491 112 241 491 114 241 minecraft:yellow_concrete
fill 491 112 261 491 114 261 minecraft:lime_concrete
fill 492 112 244 492 114 244 minecraft:yellow_concrete
fill 492 112 258 492 114 258 minecraft:lime_concrete
fill 493 112 240 495 114 240 minecraft:yellow_concrete
fill 493 112 262 496 114 262 minecraft:lime_concrete
setblock 494 112 231 minecraft:light[level=12]
setblock 494 112 238 minecraft:light[level=12]
setblock 494 112 266 minecraft:light[level=12]
fill 495 112 243 495 114 243 minecraft:yellow_concrete
fill 495 112 259 495 114 259 minecraft:lime_concrete
fill 496 112 240 499 114 240 minecraft:lime_concrete
fill 497 112 243 497 114 243 minecraft:lime_concrete
fill 497 112 259 497 114 259 minecraft:yellow_concrete
fill 497 112 262 499 114 262 minecraft:yellow_concrete
fill 500 112 244 500 114 244 minecraft:lime_concrete
fill 500 112 258 500 114 258 minecraft:yellow_concrete
setblock 501 112 231 minecraft:light[level=12]
setblock 501 112 238 minecraft:light[level=12]
fill 501 112 241 501 114 241 minecraft:lime_concrete
fill 501 112 261 501 114 261 minecraft:yellow_concrete
setblock 501 112 266 minecraft:light[level=12]
fill 502 112 241 502 114 241 minecraft:light_blue_concrete
fill 502 112 261 502 114 261 minecraft:orange_concrete
fill 503 112 242 503 114 242 minecraft:light_blue_concrete
fill 503 112 247 503 114 247 minecraft:purple_concrete
fill 503 112 255 503 114 255 minecraft:red_concrete
fill 503 112 260 503 114 260 minecraft:orange_concrete
fill 504 112 243 504 114 243 minecraft:light_blue_concrete
fill 504 112 250 504 114 250 minecraft:purple_concrete
fill 504 112 252 504 114 252 minecraft:red_concrete
fill 504 112 259 504 114 259 minecraft:orange_concrete
fill 505 112 244 505 114 244 minecraft:light_blue_concrete
fill 505 112 258 505 114 258 minecraft:orange_concrete
fill 506 112 245 506 114 245 minecraft:light_blue_concrete
fill 506 112 246 506 114 246 minecraft:purple_concrete
fill 506 112 256 506 114 256 minecraft:red_concrete
fill 506 112 257 506 114 257 minecraft:orange_concrete
fill 507 112 248 507 114 250 minecraft:purple_concrete
fill 507 112 251 507 114 254 minecraft:red_concrete
setblock 508 112 238 minecraft:light[level=12]
setblock 508 112 245 minecraft:light[level=12]
setblock 508 112 252 minecraft:light[level=12]
setblock 508 112 259 minecraft:light[level=12]
fill 509 112 229 509 116 230 minecraft:red_concrete
fill 509 112 232 509 115 233 minecraft:white_concrete
fill 509 112 265 509 116 266 minecraft:red_concrete
fill 509 112 268 509 116 269 minecraft:white_concrete
fill 510 112 229 510 115 229 minecraft:red_concrete
fill 510 112 265 510 115 265 minecraft:red_concrete
setblock 471 113 229 minecraft:lime_stained_glass
fill 471 113 233 471 113 234 minecraft:lime_stained_glass
setblock 471 113 235 minecraft:green_stained_glass
fill 471 113 236 471 113 238 minecraft:lime_stained_glass
setblock 471 113 239 minecraft:green_stained_glass
fill 471 113 240 471 113 242 minecraft:lime_stained_glass
setblock 471 113 243 minecraft:green_stained_glass
fill 471 113 244 471 113 246 minecraft:lime_stained_glass
setblock 471 113 247 minecraft:green_stained_glass
fill 471 113 248 471 113 250 minecraft:lime_stained_glass
setblock 471 113 251 minecraft:green_stained_glass
fill 471 113 252 471 113 254 minecraft:lime_stained_glass
setblock 471 113 255 minecraft:green_stained_glass
fill 471 113 256 471 113 258 minecraft:lime_stained_glass
setblock 471 113 259 minecraft:green_stained_glass
fill 471 113 260 471 113 262 minecraft:lime_stained_glass
setblock 471 113 263 minecraft:green_stained_glass
fill 471 113 264 471 113 265 minecraft:lime_stained_glass
setblock 471 113 269 minecraft:lime_stained_glass
fill 472 113 229 472 117 229 minecraft:red_concrete
setblock 472 113 230 minecraft:white_concrete
setblock 472 113 234 minecraft:green_stained_glass
fill 472 113 235 472 113 237 minecraft:lime_stained_glass
setblock 472 113 238 minecraft:green_stained_glass
fill 472 113 239 472 113 241 minecraft:lime_stained_glass
setblock 472 113 242 minecraft:green_stained_glass
fill 472 113 243 472 113 245 minecraft:lime_stained_glass
setblock 472 113 246 minecraft:green_stained_glass
fill 472 113 247 472 113 249 minecraft:lime_stained_glass
setblock 472 113 250 minecraft:green_stained_glass
fill 472 113 251 472 113 253 minecraft:lime_stained_glass
setblock 472 113 254 minecraft:green_stained_glass
fill 472 113 255 472 113 257 minecraft:lime_stained_glass
setblock 472 113 258 minecraft:green_stained_glass
fill 472 113 259 472 113 261 minecraft:lime_stained_glass
setblock 472 113 262 minecraft:green_stained_glass
fill 472 113 263 473 113 264 minecraft:lime_stained_glass
fill 472 113 265 472 117 265 minecraft:red_concrete
setblock 472 113 266 minecraft:white_concrete
fill 473 113 234 473 113 236 minecraft:lime_stained_glass
setblock 473 113 237 minecraft:green_stained_glass
fill 473 113 238 473 113 240 minecraft:lime_stained_glass
setblock 473 113 241 minecraft:green_stained_glass
fill 473 113 242 473 113 244 minecraft:lime_stained_glass
setblock 473 113 245 minecraft:green_stained_glass
fill 473 113 246 473 113 248 minecraft:lime_stained_glass
setblock 473 113 249 minecraft:green_stained_glass
fill 473 113 250 473 113 252 minecraft:lime_stained_glass
setblock 473 113 253 minecraft:green_stained_glass
fill 473 113 254 473 113 256 minecraft:lime_stained_glass
setblock 473 113 257 minecraft:green_stained_glass
fill 473 113 258 473 113 260 minecraft:lime_stained_glass
setblock 473 113 261 minecraft:green_stained_glass
fill 473 113 262 475 113 262 minecraft:lime_stained_glass
fill 474 113 232 474 115 233 minecraft:white_concrete
fill 474 113 234 474 113 235 minecraft:lime_stained_glass
setblock 474 113 236 minecraft:green_stained_glass
fill 474 113 237 474 113 239 minecraft:lime_stained_glass
setblock 474 113 240 minecraft:green_stained_glass
fill 474 113 241 474 113 243 minecraft:lime_stained_glass
setblock 474 113 244 minecraft:green_stained_glass
fill 474 113 245 474 113 247 minecraft:lime_stained_glass
setblock 474 113 248 minecraft:green_stained_glass
fill 474 113 249 474 113 251 minecraft:lime_stained_glass
setblock 474 113 252 minecraft:green_stained_glass
fill 474 113 253 474 113 255 minecraft:lime_stained_glass
setblock 474 113 256 minecraft:green_stained_glass
fill 474 113 257 474 113 259 minecraft:lime_stained_glass
setblock 474 113 260 minecraft:green_stained_glass
fill 474 113 261 476 113 261 minecraft:lime_stained_glass
setblock 474 113 263 minecraft:lime_stained_glass
setblock 474 113 264 minecraft:green_stained_glass
fill 474 113 268 474 117 269 minecraft:white_concrete
fill 475 113 229 476 113 229 minecraft:lime_stained_glass
setblock 475 113 232 minecraft:red_concrete
fill 475 113 233 475 113 234 minecraft:lime_stained_glass
setblock 475 113 235 minecraft:green_stained_glass
fill 475 113 236 475 113 238 minecraft:lime_stained_glass
setblock 475 113 239 minecraft:green_stained_glass
fill 475 113 240 475 113 242 minecraft:lime_stained_glass
setblock 475 113 243 minecraft:green_stained_glass
fill 475 113 244 475 113 246 minecraft:lime_stained_glass
setblock 475 113 247 minecraft:green_stained_glass
fill 475 113 248 475 113 250 minecraft:lime_stained_glass
setblock 475 113 251 minecraft:green_stained_glass
fill 475 113 252 475 113 254 minecraft:lime_stained_glass
setblock 475 113 255 minecraft:green_stained_glass
fill 475 113 256 475 113 258 minecraft:lime_stained_glass
setblock 475 113 259 minecraft:green_stained_glass
fill 475 113 260 477 113 260 minecraft:lime_stained_glass
setblock 475 113 263 minecraft:green_stained_glass
fill 475 113 264 476 113 265 minecraft:lime_stained_glass
setblock 475 113 268 minecraft:red_concrete
fill 475 113 269 476 113 269 minecraft:lime_stained_glass
setblock 476 113 230 minecraft:green_stained_glass
fill 476 113 231 476 113 233 minecraft:lime_stained_glass
setblock 476 113 234 minecraft:green_stained_glass
fill 476 113 235 476 113 237 minecraft:lime_stained_glass
setblock 476 113 238 minecraft:green_stained_glass
fill 476 113 239 476 113 241 minecraft:lime_stained_glass
setblock 476 113 242 minecraft:green_stained_glass
fill 476 113 243 476 113 245 minecraft:lime_stained_glass
setblock 476 113 246 minecraft:green_stained_glass
fill 476 113 247 476 113 249 minecraft:lime_stained_glass
setblock 476 113 250 minecraft:green_stained_glass
fill 476 113 251 476 113 253 minecraft:lime_stained_glass
setblock 476 113 254 minecraft:green_stained_glass
fill 476 113 255 476 113 257 minecraft:lime_stained_glass
setblock 476 113 258 minecraft:green_stained_glass
fill 476 113 259 478 113 259 minecraft:lime_stained_glass
setblock 476 113 262 minecraft:green_stained_glass
fill 476 113 263 478 113 263 minecraft:lime_stained_glass
setblock 476 113 266 minecraft:green_stained_glass
fill 476 113 267 477 113 268 minecraft:lime_stained_glass
setblock 477 113 229 minecraft:green_stained_glass
fill 477 113 230 477 113 232 minecraft:lime_stained_glass
setblock 477 113 233 minecraft:green_stained_glass
fill 477 113 234 477 113 236 minecraft:lime_stained_glass
setblock 477 113 237 minecraft:green_stained_glass
fill 477 113 238 477 113 240 minecraft:lime_stained_glass
setblock 477 113 241 minecraft:green_stained_glass
fill 477 113 242 477 113 244 minecraft:lime_stained_glass
setblock 477 113 245 minecraft:green_stained_glass
fill 477 113 246 477 113 248 minecraft:lime_stained_glass
setblock 477 113 249 minecraft:green_stained_glass
fill 477 113 250 477 113 252 minecraft:lime_stained_glass
setblock 477 113 253 minecraft:green_stained_glass
fill 477 113 254 477 113 256 minecraft:lime_stained_glass
setblock 477 113 257 minecraft:green_stained_glass
fill 477 113 258 479 113 258 minecraft:lime_stained_glass
setblock 477 113 261 minecraft:green_stained_glass
fill 477 113 262 479 113 262 minecraft:lime_stained_glass
setblock 477 113 264 minecraft:lime_stained_glass
setblock 477 113 265 minecraft:green_stained_glass
fill 477 113 266 479 113 266 minecraft:lime_stained_glass
setblock 477 113 269 minecraft:green_stained_glass
fill 478 113 229 478 113 231 minecraft:lime_stained_glass
setblock 478 113 232 minecraft:green_stained_glass
fill 478 113 233 478 113 235 minecraft:lime_stained_glass
setblock 478 113 236 minecraft:green_stained_glass
fill 478 113 237 478 113 239 minecraft:lime_stained_glass
setblock 478 113 240 minecraft:green_stained_glass
fill 478 113 241 478 113 243 minecraft:lime_stained_glass
setblock 478 113 244 minecraft:green_stained_glass
fill 478 113 245 478 113 247 minecraft:lime_stained_glass
setblock 478 113 248 minecraft:green_stained_glass
fill 478 113 249 478 113 251 minecraft:lime_stained_glass
setblock 478 113 252 minecraft:green_stained_glass
fill 478 113 253 478 113 255 minecraft:lime_stained_glass
setblock 478 113 256 minecraft:green_stained_glass
fill 478 113 257 480 113 257 minecraft:lime_stained_glass
setblock 478 113 260 minecraft:green_stained_glass
fill 478 113 261 480 113 261 minecraft:lime_stained_glass
setblock 478 113 264 minecraft:green_stained_glass
fill 478 113 265 480 113 265 minecraft:lime_stained_glass
setblock 478 113 267 minecraft:lime_stained_glass
setblock 478 113 268 minecraft:green_stained_glass
fill 478 113 269 480 113 269 minecraft:lime_stained_glass
fill 479 113 229 479 113 230 minecraft:lime_stained_glass
setblock 479 113 231 minecraft:green_stained_glass
fill 479 113 232 479 113 234 minecraft:lime_stained_glass
setblock 479 113 235 minecraft:green_stained_glass
fill 479 113 236 479 113 238 minecraft:lime_stained_glass
setblock 479 113 239 minecraft:green_stained_glass
fill 479 113 240 479 113 242 minecraft:lime_stained_glass
setblock 479 113 243 minecraft:green_stained_glass
fill 479 113 244 479 113 246 minecraft:lime_stained_glass
setblock 479 113 247 minecraft:green_stained_glass
fill 479 113 248 479 113 250 minecraft:lime_stained_glass
setblock 479 113 251 minecraft:green_stained_glass
fill 479 113 252 479 113 254 minecraft:lime_stained_glass
setblock 479 113 255 minecraft:green_stained_glass
fill 479 113 256 481 113 256 minecraft:lime_stained_glass
setblock 479 113 259 minecraft:green_stained_glass
fill 479 113 260 481 113 260 minecraft:lime_stained_glass
setblock 479 113 263 minecraft:green_stained_glass
fill 479 113 264 481 113 264 minecraft:lime_stained_glass
setblock 479 113 267 minecraft:green_stained_glass
fill 479 113 268 481 113 268 minecraft:lime_stained_glass
setblock 480 113 229 minecraft:lime_stained_glass
setblock 480 113 230 minecraft:green_stained_glass
fill 480 113 231 480 113 233 minecraft:lime_stained_glass
setblock 480 113 234 minecraft:green_stained_glass
fill 480 113 235 480 113 237 minecraft:lime_stained_glass
setblock 480 113 238 minecraft:green_stained_glass
fill 480 113 239 480 113 241 minecraft:lime_stained_glass
setblock 480 113 242 minecraft:green_stained_glass
fill 480 113 243 480 113 245 minecraft:lime_stained_glass
setblock 480 113 246 minecraft:green_stained_glass
fill 480 113 247 480 113 249 minecraft:lime_stained_glass
setblock 480 113 250 minecraft:green_stained_glass
fill 480 113 251 480 113 253 minecraft:lime_stained_glass
setblock 480 113 254 minecraft:green_stained_glass
fill 480 113 255 482 113 255 minecraft:lime_stained_glass
setblock 480 113 258 minecraft:green_stained_glass
fill 480 113 259 482 113 259 minecraft:lime_stained_glass
setblock 480 113 262 minecraft:green_stained_glass
fill 480 113 263 482 113 263 minecraft:lime_stained_glass
setblock 480 113 266 minecraft:green_stained_glass
fill 480 113 267 482 113 267 minecraft:lime_stained_glass
setblock 481 113 229 minecraft:green_stained_glass
fill 481 113 230 481 113 232 minecraft:lime_stained_glass
setblock 481 113 233 minecraft:green_stained_glass
fill 481 113 234 481 113 236 minecraft:lime_stained_glass
setblock 481 113 237 minecraft:green_stained_glass
fill 481 113 238 481 113 240 minecraft:lime_stained_glass
setblock 481 113 241 minecraft:green_stained_glass
fill 481 113 242 481 113 244 minecraft:lime_stained_glass
setblock 481 113 245 minecraft:green_stained_glass
fill 481 113 246 481 113 248 minecraft:lime_stained_glass
setblock 481 113 249 minecraft:green_stained_glass
fill 481 113 250 481 113 252 minecraft:lime_stained_glass
setblock 481 113 253 minecraft:green_stained_glass
fill 481 113 254 483 113 254 minecraft:lime_stained_glass
setblock 481 113 257 minecraft:green_stained_glass
fill 481 113 258 483 113 258 minecraft:lime_stained_glass
setblock 481 113 261 minecraft:green_stained_glass
fill 481 113 262 483 113 262 minecraft:lime_stained_glass
setblock 481 113 265 minecraft:green_stained_glass
fill 481 113 266 483 113 266 minecraft:lime_stained_glass
setblock 481 113 269 minecraft:green_stained_glass
fill 482 113 229 482 113 231 minecraft:lime_stained_glass
setblock 482 113 232 minecraft:green_stained_glass
fill 482 113 233 482 113 235 minecraft:lime_stained_glass
setblock 482 113 236 minecraft:green_stained_glass
fill 482 113 237 482 113 239 minecraft:lime_stained_glass
setblock 482 113 240 minecraft:green_stained_glass
fill 482 113 241 482 113 243 minecraft:lime_stained_glass
setblock 482 113 244 minecraft:green_stained_glass
fill 482 113 245 482 113 247 minecraft:lime_stained_glass
setblock 482 113 248 minecraft:green_stained_glass
fill 482 113 249 482 113 251 minecraft:lime_stained_glass
setblock 482 113 252 minecraft:green_stained_glass
fill 482 113 253 484 113 253 minecraft:lime_stained_glass
setblock 482 113 256 minecraft:green_stained_glass
fill 482 113 257 484 113 257 minecraft:lime_stained_glass
setblock 482 113 260 minecraft:green_stained_glass
fill 482 113 261 484 113 261 minecraft:lime_stained_glass
setblock 482 113 264 minecraft:green_stained_glass
fill 482 113 265 484 113 265 minecraft:lime_stained_glass
setblock 482 113 268 minecraft:green_stained_glass
fill 482 113 269 484 113 269 minecraft:lime_stained_glass
fill 483 113 229 483 113 230 minecraft:lime_stained_glass
setblock 483 113 231 minecraft:green_stained_glass
fill 483 113 232 483 113 234 minecraft:lime_stained_glass
setblock 483 113 235 minecraft:green_stained_glass
fill 483 113 236 483 113 238 minecraft:lime_stained_glass
setblock 483 113 239 minecraft:green_stained_glass
fill 483 113 240 483 113 242 minecraft:lime_stained_glass
setblock 483 113 243 minecraft:green_stained_glass
fill 483 113 244 483 113 246 minecraft:lime_stained_glass
setblock 483 113 247 minecraft:green_stained_glass
fill 483 113 248 483 113 250 minecraft:lime_stained_glass
setblock 483 113 251 minecraft:green_stained_glass
fill 483 113 252 484 113 252 minecraft:lime_stained_glass
setblock 483 113 255 minecraft:green_stained_glass
fill 483 113 256 485 113 256 minecraft:lime_stained_glass
setblock 483 113 259 minecraft:green_stained_glass
fill 483 113 260 485 113 260 minecraft:lime_stained_glass
setblock 483 113 263 minecraft:green_stained_glass
fill 483 113 264 485 113 264 minecraft:lime_stained_glass
setblock 483 113 267 minecraft:green_stained_glass
fill 483 113 268 485 113 268 minecraft:lime_stained_glass
setblock 484 113 229 minecraft:lime_stained_glass
setblock 484 113 230 minecraft:green_stained_glass
fill 484 113 231 484 113 233 minecraft:lime_stained_glass
setblock 484 113 234 minecraft:green_stained_glass
fill 484 113 235 484 113 237 minecraft:lime_stained_glass
setblock 484 113 238 minecraft:green_stained_glass
fill 484 113 239 484 113 241 minecraft:lime_stained_glass
setblock 484 113 242 minecraft:green_stained_glass
fill 484 113 243 484 113 245 minecraft:lime_stained_glass
setblock 484 113 246 minecraft:green_stained_glass
fill 484 113 247 484 113 249 minecraft:lime_stained_glass
setblock 484 113 250 minecraft:green_stained_glass
setblock 484 113 251 minecraft:lime_stained_glass
setblock 484 113 254 minecraft:green_stained_glass
setblock 484 113 255 minecraft:lime_stained_glass
setblock 484 113 258 minecraft:green_stained_glass
fill 484 113 259 486 113 259 minecraft:lime_stained_glass
setblock 484 113 262 minecraft:green_stained_glass
fill 484 113 263 486 113 263 minecraft:lime_stained_glass
setblock 484 113 266 minecraft:green_stained_glass
fill 484 113 267 486 113 267 minecraft:lime_stained_glass
setblock 485 113 229 minecraft:green_stained_glass
fill 485 113 230 485 113 232 minecraft:lime_stained_glass
setblock 485 113 233 minecraft:green_stained_glass
fill 485 113 234 485 113 236 minecraft:lime_stained_glass
setblock 485 113 237 minecraft:green_stained_glass
fill 485 113 238 485 113 240 minecraft:lime_stained_glass
setblock 485 113 241 minecraft:green_stained_glass
fill 485 113 242 485 113 244 minecraft:lime_stained_glass
setblock 485 113 245 minecraft:green_stained_glass
setblock 485 113 246 minecraft:lime_stained_glass
setblock 485 113 247 minecraft:red_concrete
setblock 485 113 255 minecraft:purple_concrete
setblock 485 113 257 minecraft:green_stained_glass
fill 485 113 258 486 113 258 minecraft:lime_stained_glass
setblock 485 113 261 minecraft:green_stained_glass
fill 485 113 262 487 113 262 minecraft:lime_stained_glass
setblock 485 113 265 minecraft:green_stained_glass
fill 485 113 266 487 113 266 minecraft:lime_stained_glass
setblock 485 113 269 minecraft:green_stained_glass
fill 486 113 229 486 113 231 minecraft:lime_stained_glass
setblock 486 113 232 minecraft:green_stained_glass
fill 486 113 233 486 113 235 minecraft:lime_stained_glass
setblock 486 113 236 minecraft:green_stained_glass
fill 486 113 237 486 113 239 minecraft:lime_stained_glass
setblock 486 113 240 minecraft:green_stained_glass
fill 486 113 241 486 113 243 minecraft:lime_stained_glass
setblock 486 113 244 minecraft:green_stained_glass
setblock 486 113 260 minecraft:green_stained_glass
fill 486 113 261 488 113 261 minecraft:lime_stained_glass
setblock 486 113 264 minecraft:green_stained_glass
fill 486 113 265 488 113 265 minecraft:lime_stained_glass
setblock 486 113 268 minecraft:green_stained_glass
fill 486 113 269 488 113 269 minecraft:lime_stained_glass
fill 487 113 229 487 113 230 minecraft:lime_stained_glass
setblock 487 113 231 minecraft:green_stained_glass
fill 487 113 232 487 113 234 minecraft:lime_stained_glass
setblock 487 113 235 minecraft:green_stained_glass
fill 487 113 236 487 113 238 minecraft:lime_stained_glass
setblock 487 113 239 minecraft:green_stained_glass
fill 487 113 240 487 113 242 minecraft:lime_stained_glass
setblock 487 113 243 minecraft:green_stained_glass
setblock 487 113 259 minecraft:green_stained_glass
fill 487 113 260 488 113 260 minecraft:lime_stained_glass
setblock 487 113 263 minecraft:green_stained_glass
fill 487 113 264 489 113 264 minecraft:lime_stained_glass
setblock 487 113 267 minecraft:green_stained_glass
fill 487 113 268 489 113 268 minecraft:lime_stained_glass
setblock 488 113 229 minecraft:lime_stained_glass
setblock 488 113 230 minecraft:green_stained_glass
fill 488 113 231 488 113 233 minecraft:lime_stained_glass
setblock 488 113 234 minecraft:green_stained_glass
fill 488 113 235 488 113 237 minecraft:lime_stained_glass
setblock 488 113 238 minecraft:green_stained_glass
fill 488 113 239 488 113 241 minecraft:lime_stained_glass
setblock 488 113 242 minecraft:green_stained_glass
setblock 488 113 251 minecraft:lime_stained_glass
setblock 488 113 262 minecraft:green_stained_glass
fill 488 113 263 490 113 263 minecraft:lime_stained_glass
setblock 488 113 266 minecraft:green_stained_glass
fill 488 113 267 490 113 267 minecraft:lime_stained_glass
setblock 489 113 229 minecraft:green_stained_glass
fill 489 113 230 489 113 232 minecraft:lime_stained_glass
setblock 489 113 233 minecraft:green_stained_glass
fill 489 113 234 489 113 236 minecraft:lime_stained_glass
setblock 489 113 237 minecraft:green_stained_glass
fill 489 113 238 489 113 240 minecraft:lime_stained_glass
setblock 489 113 241 minecraft:green_stained_glass
setblock 489 113 248 minecraft:green_stained_glass
fill 489 113 249 489 113 250 minecraft:lime_stained_glass
setblock 489 113 251 minecraft:green_stained_glass
fill 489 113 252 489 113 253 minecraft:lime_stained_glass
setblock 489 113 254 minecraft:green_stained_glass
setblock 489 113 261 minecraft:green_stained_glass
fill 489 113 262 491 113 262 minecraft:lime_stained_glass
setblock 489 113 265 minecraft:green_stained_glass
fill 489 113 266 491 113 266 minecraft:lime_stained_glass
setblock 489 113 269 minecraft:green_stained_glass
fill 490 113 229 490 113 231 minecraft:lime_stained_glass
setblock 490 113 232 minecraft:green_stained_glass
fill 490 113 233 490 113 235 minecraft:lime_stained_glass
setblock 490 113 236 minecraft:green_stained_glass
fill 490 113 237 490 113 239 minecraft:lime_stained_glass
setblock 490 113 240 minecraft:green_stained_glass
setblock 490 113 246 minecraft:lime_stained_glass
setblock 490 113 247 minecraft:green_stained_glass
fill 490 113 248 490 113 249 minecraft:lime_stained_glass
setblock 490 113 250 minecraft:green_stained_glass
fill 490 113 251 490 113 252 minecraft:lime_stained_glass
setblock 490 113 253 minecraft:green_stained_glass
fill 490 113 254 490 113 255 minecraft:lime_stained_glass
setblock 490 113 256 minecraft:green_stained_glass
setblock 490 113 264 minecraft:green_stained_glass
fill 490 113 265 492 113 265 minecraft:lime_stained_glass
setblock 490 113 268 minecraft:green_stained_glass
fill 490 113 269 492 113 269 minecraft:lime_stained_glass
fill 491 113 229 491 113 230 minecraft:lime_stained_glass
setblock 491 113 231 minecraft:green_stained_glass
fill 491 113 232 491 113 234 minecraft:lime_stained_glass
setblock 491 113 235 minecraft:green_stained_glass
fill 491 113 236 491 113 238 minecraft:lime_stained_glass
setblock 491 113 239 minecraft:green_stained_glass
setblock 491 113 240 minecraft:lime_stained_glass
setblock 491 113 245 minecraft:lime_stained_glass
setblock 491 113 246 minecraft:green_stained_glass
fill 491 113 247 491 113 248 minecraft:lime_stained_glass
setblock 491 113 249 minecraft:green_stained_glass
fill 491 113 250 491 113 251 minecraft:lime_stained_glass
setblock 491 113 252 minecraft:green_stained_glass
fill 491 113 253 491 113 254 minecraft:lime_stained_glass
setblock 491 113 255 minecraft:green_stained_glass
fill 491 113 256 491 113 257 minecraft:lime_stained_glass
setblock 491 113 263 minecraft:green_stained_glass
fill 491 113 264 493 113 264 minecraft:lime_stained_glass
setblock 491 113 267 minecraft:green_stained_glass
fill 491 113 268 493 113 268 minecraft:lime_stained_glass
setblock 492 113 229 minecraft:lime_stained_glass
setblock 492 113 230 minecraft:green_stained_glass
fill 492 113 231 492 113 233 minecraft:lime_stained_glass
setblock 492 113 234 minecraft:green_stained_glass
fill 492 113 235 492 113 237 minecraft:lime_stained_glass
setblock 492 113 238 minecraft:green_stained_glass
fill 492 113 239 494 113 239 minecraft:lime_stained_glass
setblock 492 113 240 minecraft:yellow_concrete
setblock 492 113 245 minecraft:green_stained_glass
fill 492 113 246 492 113 247 minecraft:lime_stained_glass
setblock 492 113 248 minecraft:green_stained_glass
setblock 492 113 249 minecraft:lime_stained_glass
fill 492 113 250 492 113 252 minecraft:lime_concrete
setblock 492 113 253 minecraft:lime_stained_glass
setblock 492 113 254 minecraft:green_stained_glass
fill 492 113 255 492 113 256 minecraft:lime_stained_glass
setblock 492 113 257 minecraft:green_stained_glass
setblock 492 113 262 minecraft:lime_concrete
fill 492 113 263 494 113 263 minecraft:lime_stained_glass
setblock 492 113 266 minecraft:green_stained_glass
fill 492 113 267 494 113 267 minecraft:lime_stained_glass
setblock 493 113 229 minecraft:green_stained_glass
fill 493 113 230 493 113 232 minecraft:lime_stained_glass
setblock 493 113 233 minecraft:green_stained_glass
fill 493 113 234 493 113 236 minecraft:lime_stained_glass
setblock 493 113 237 minecraft:green_stained_glass
fill 493 113 238 495 113 238 minecraft:lime_stained_glass
setblock 493 113 244 minecraft:green_stained_glass
fill 493 113 245 493 113 246 minecraft:lime_stained_glass
setblock 493 113 247 minecraft:green_stained_glass
fill 493 113 248 493 113 250 minecraft:lime_concrete
fill 493 113 252 493 113 254 minecraft:lime_concrete
setblock 493 113 255 minecraft:lime_stained_glass
setblock 493 113 256 minecraft:green_stained_glass
fill 493 113 257 493 113 258 minecraft:lime_stained_glass
setblock 493 113 265 minecraft:green_stained_glass
fill 493 113 266 495 113 266 minecraft:lime_stained_glass
setblock 493 113 269 minecraft:green_stained_glass
fill 494 113 229 494 113 231 minecraft:lime_stained_glass
setblock 494 113 232 minecraft:green_stained_glass
fill 494 113 233 494 113 235 minecraft:lime_stained_glass
setblock 494 113 236 minecraft:green_stained_glass
fill 494 113 237 496 113 237 minecraft:lime_stained_glass
fill 494 113 244 494 113 245 minecraft:lime_stained_glass
setblock 494 113 246 minecraft:green_stained_glass
setblock 494 113 247 minecraft:lime_stained_glass
fill 494 113 248 495 113 248 minecraft:lime_concrete
fill 494 113 254 495 113 254 minecraft:lime_concrete
setblock 494 113 255 minecraft:green_stained_glass
fill 494 113 256 494 113 257 minecraft:lime_stained_glass
setblock 494 113 258 minecraft:green_stained_glass
setblock 494 113 264 minecraft:green_stained_glass
fill 494 113 265 496 113 265 minecraft:lime_stained_glass
setblock 494 113 268 minecraft:green_stained_glass
fill 494 113 269 496 113 269 minecraft:lime_stained_glass
fill 495 113 229 495 113 230 minecraft:lime_stained_glass
setblock 495 113 231 minecraft:green_stained_glass
fill 495 113 232 495 113 234 minecraft:lime_stained_glass
setblock 495 113 235 minecraft:green_stained_glass
fill 495 113 236 497 113 236 minecraft:lime_stained_glass
setblock 495 113 239 minecraft:green_stained_glass
setblock 495 113 244 minecraft:lime_stained_glass
setblock 495 113 245 minecraft:green_stained_glass
fill 495 113 246 496 113 246 minecraft:lime_stained_glass
fill 495 113 247 497 113 247 minecraft:lime_concrete
fill 495 113 255 497 113 255 minecraft:lime_concrete
setblock 495 113 256 minecraft:lime_stained_glass
setblock 495 113 257 minecraft:green_stained_glass
fill 495 113 258 496 113 258 minecraft:lime_stained_glass
setblock 495 113 263 minecraft:green_stained_glass
fill 495 113 264 497 113 264 minecraft:lime_stained_glass
setblock 495 113 267 minecraft:green_stained_glass
fill 495 113 268 497 113 268 minecraft:lime_stained_glass
setblock 496 113 229 minecraft:lime_stained_glass
setblock 496 113 230 minecraft:green_stained_glass
fill 496 113 231 496 113 233 minecraft:lime_stained_glass
setblock 496 113 234 minecraft:green_stained_glass
fill 496 113 235 498 113 235 minecraft:lime_stained_glass
setblock 496 113 238 minecraft:green_stained_glass
fill 496 113 239 498 113 239 minecraft:lime_stained_glass
setblock 496 113 244 minecraft:green_stained_glass
fill 496 113 245 497 113 245 minecraft:lime_stained_glass
setblock 496 113 256 minecraft:green_stained_glass
fill 496 113 257 497 113 257 minecraft:lime_stained_glass
setblock 496 113 259 minecraft:green_stained_glass
fill 496 113 263 498 113 263 minecraft:lime_stained_glass
setblock 496 113 266 minecraft:green_stained_glass
fill 496 113 267 498 113 267 minecraft:lime_stained_glass
setblock 497 113 229 minecraft:green_stained_glass
fill 497 113 230 497 113 232 minecraft:lime_stained_glass
setblock 497 113 233 minecraft:green_stained_glass
fill 497 113 234 499 113 234 minecraft:lime_stained_glass
setblock 497 113 237 minecraft:green_stained_glass
fill 497 113 238 499 113 238 minecraft:lime_stained_glass
fill 497 113 244 498 113 244 minecraft:lime_stained_glass
setblock 497 113 246 minecraft:green_stained_glass
fill 497 113 248 499 113 248 minecraft:lime_concrete
fill 497 113 254 499 113 254 minecraft:lime_concrete
fill 497 113 256 498 113 256 minecraft:lime_stained_glass
setblock 497 113 258 minecraft:green_stained_glass
setblock 497 113 265 minecraft:green_stained_glass
fill 497 113 266 499 113 266 minecraft:lime_stained_glass
setblock 497 113 269 minecraft:green_stained_glass
fill 498 113 229 498 113 231 minecraft:lime_stained_glass
setblock 498 113 232 minecraft:green_stained_glass
fill 498 113 233 500 113 233 minecraft:lime_stained_glass
setblock 498 113 236 minecraft:green_stained_glass
fill 498 113 237 500 113 237 minecraft:lime_stained_glass
setblock 498 113 245 minecraft:green_stained_glass
fill 498 113 246 498 113 247 minecraft:lime_stained_glass
fill 498 113 255 499 113 255 minecraft:lime_stained_glass
setblock 498 113 257 minecraft:green_stained_glass
fill 498 113 258 499 113 258 minecraft:lime_stained_glass
setblock 498 113 264 minecraft:green_stained_glass
fill 498 113 265 500 113 265 minecraft:lime_stained_glass
setblock 498 113 268 minecraft:green_stained_glass
fill 498 113 269 500 113 269 minecraft:lime_stained_glass
fill 499 113 229 499 113 230 minecraft:lime_stained_glass
setblock 499 113 231 minecraft:green_stained_glass
fill 499 113 232 501 113 232 minecraft:lime_stained_glass
setblock 499 113 235 minecraft:green_stained_glass
fill 499 113 236 501 113 236 minecraft:lime_stained_glass
setblock 499 113 239 minecraft:green_stained_glass
setblock 499 113 244 minecraft:green_stained_glass
fill 499 113 245 499 113 246 minecraft:lime_stained_glass
setblock 499 113 247 minecraft:green_stained_glass
fill 499 113 249 499 113 250 minecraft:lime_concrete
fill 499 113 252 499 113 253 minecraft:lime_concrete
setblock 499 113 256 minecraft:green_stained_glass
fill 499 113 257 500 113 257 minecraft:lime_stained_glass
setblock 499 113 263 minecraft:green_stained_glass
fill 499 113 264 501 113 264 minecraft:lime_stained_glass
setblock 499 113 267 minecraft:green_stained_glass
fill 499 113 268 501 113 268 minecraft:lime_stained_glass
setblock 500 113 229 minecraft:lime_stained_glass
setblock 500 113 230 minecraft:green_stained_glass
fill 500 113 231 502 113 231 minecraft:lime_stained_glass
setblock 500 113 234 minecraft:green_stained_glass
fill 500 113 235 502 113 235 minecraft:lime_stained_glass
setblock 500 113 238 minecraft:green_stained_glass
fill 500 113 239 502 113 239 minecraft:lime_stained_glass
setblock 500 113 240 minecraft:lime_concrete
setblock 500 113 245 minecraft:lime_stained_glass
setblock 500 113 246 minecraft:green_stained_glass
fill 500 113 247 500 113 248 minecraft:lime_stained_glass
setblock 500 113 249 minecraft:green_stained_glass
fill 500 113 250 500 113 252 minecraft:lime_concrete
fill 500 113 253 500 113 254 minecraft:lime_stained_glass
setblock 500 113 255 minecraft:green_stained_glass
fill 500 113 256 501 113 256 minecraft:lime_stained_glass
setblock 500 113 262 minecraft:yellow_concrete
fill 500 113 263 502 113 263 minecraft:lime_stained_glass
setblock 500 113 266 minecraft:green_stained_glass
fill 500 113 267 502 113 267 minecraft:lime_stained_glass
setblock 501 113 229 minecraft:green_stained_glass
fill 501 113 230 503 113 230 minecraft:lime_stained_glass
setblock 501 113 233 minecraft:green_stained_glass
fill 501 113 234 503 113 234 minecraft:lime_stained_glass
setblock 501 113 237 minecraft:green_stained_glass
fill 501 113 238 503 113 238 minecraft:lime_stained_glass
setblock 501 113 240 minecraft:lime_stained_glass
setblock 501 113 245 minecraft:green_stained_glass
fill 501 113 246 501 113 247 minecraft:lime_stained_glass
setblock 501 113 248 minecraft:green_stained_glass
fill 501 113 249 501 113 250 minecraft:lime_stained_glass
setblock 501 113 251 minecraft:green_stained_glass
fill 501 113 252 501 113 253 minecraft:lime_stained_glass
setblock 501 113 254 minecraft:green_stained_glass
fill 501 113 255 502 113 255 minecraft:lime_stained_glass
setblock 501 113 257 minecraft:green_stained_glass
fill 501 113 262 503 113 262 minecraft:lime_stained_glass
setblock 501 113 265 minecraft:green_stained_glass
fill 501 113 266 503 113 266 minecraft:lime_stained_glass
setblock 501 113 269 minecraft:green_stained_glass
fill 502 113 229 504 113 229 minecraft:lime_stained_glass
setblock 502 113 232 minecraft:green_stained_glass
fill 502 113 233 504 113 233 minecraft:lime_stained_glass
setblock 502 113 236 minecraft:green_stained_glass
fill 502 113 237 504 113 237 minecraft:lime_stained_glass
setblock 502 113 240 minecraft:green_stained_glass
setblock 502 113 246 minecraft:lime_stained_glass
setblock 502 113 247 minecraft:green_stained_glass
fill 502 113 248 502 113 249 minecraft:lime_stained_glass
setblock 502 113 250 minecraft:green_stained_glass
fill 502 113 251 502 113 252 minecraft:lime_stained_glass
setblock 502 113 253 minecraft:green_stained_glass
fill 502 113 254 503 113 254 minecraft:lime_stained_glass
setblock 502 113 256 minecraft:green_stained_glass
setblock 502 113 264 minecraft:green_stained_glass
fill 502 113 265 504 113 265 minecraft:lime_stained_glass
setblock 502 113 268 minecraft:green_stained_glass
fill 502 113 269 504 113 269 minecraft:lime_stained_glass
setblock 503 113 231 minecraft:green_stained_glass
fill 503 113 232 505 113 232 minecraft:lime_stained_glass
setblock 503 113 235 minecraft:green_stained_glass
fill 503 113 236 505 113 236 minecraft:lime_stained_glass
setblock 503 113 239 minecraft:green_stained_glass
fill 503 113 240 504 113 241 minecraft:lime_stained_glass
setblock 503 113 248 minecraft:lime_stained_glass
setblock 503 113 249 minecraft:green_stained_glass
fill 503 113 250 503 113 251 minecraft:lime_stained_glass
setblock 503 113 252 minecraft:green_stained_glass
setblock 503 113 253 minecraft:lime_stained_glass
fill 503 113 261 504 113 261 minecraft:lime_stained_glass
setblock 503 113 263 minecraft:green_stained_glass
fill 503 113 264 505 113 264 minecraft:lime_stained_glass
setblock 503 113 267 minecraft:green_stained_glass
fill 503 113 268 505 113 268 minecraft:lime_stained_glass
setblock 504 113 230 minecraft:green_stained_glass
fill 504 113 231 506 113 231 minecraft:lime_stained_glass
setblock 504 113 234 minecraft:green_stained_glass
fill 504 113 235 506 113 235 minecraft:lime_stained_glass
setblock 504 113 238 minecraft:green_stained_glass
fill 504 113 239 506 113 239 minecraft:lime_stained_glass
setblock 504 113 242 minecraft:green_stained_glass
setblock 504 113 251 minecraft:green_stained_glass
fill 504 113 260 505 113 260 minecraft:lime_stained_glass
setblock 504 113 262 minecraft:green_stained_glass
fill 504 113 263 506 113 263 minecraft:lime_stained_glass
setblock 504 113 266 minecraft:green_stained_glass
fill 504 113 267 506 113 267 minecraft:lime_stained_glass
setblock 505 113 229 minecraft:green_stained_glass
fill 505 113 230 506 113 230 minecraft:lime_stained_glass
setblock 505 113 233 minecraft:green_stained_glass
fill 505 113 234 507 113 234 minecraft:lime_stained_glass
setblock 505 113 237 minecraft:green_stained_glass
fill 505 113 238 507 113 238 minecraft:lime_stained_glass
setblock 505 113 240 minecraft:lime_stained_glass
setblock 505 113 241 minecraft:green_stained_glass
fill 505 113 242 506 113 243 minecraft:lime_stained_glass
fill 505 113 259 506 113 259 minecraft:lime_stained_glass
setblock 505 113 261 minecraft:green_stained_glass
fill 505 113 262 507 113 262 minecraft:lime_stained_glass
setblock 505 113 265 minecraft:green_stained_glass
fill 505 113 266 506 113 266 minecraft:lime_stained_glass
setblock 505 113 269 minecraft:green_stained_glass
fill 506 113 229 507 113 229 minecraft:lime_stained_glass
setblock 506 113 232 minecraft:green_stained_glass
fill 506 113 233 507 113 233 minecraft:lime_stained_glass
setblock 506 113 236 minecraft:green_stained_glass
fill 506 113 237 508 113 237 minecraft:lime_stained_glass
setblock 506 113 240 minecraft:green_stained_glass
fill 506 113 241 508 113 241 minecraft:lime_stained_glass
setblock 506 113 244 minecraft:green_stained_glass
fill 506 113 258 507 113 258 minecraft:lime_stained_glass
setblock 506 113 260 minecraft:green_stained_glass
fill 506 113 261 508 113 261 minecraft:lime_stained_glass
setblock 506 113 264 minecraft:green_stained_glass
fill 506 113 265 507 113 265 minecraft:lime_stained_glass
setblock 506 113 268 minecraft:green_stained_glass
fill 506 113 269 507 113 269 minecraft:lime_stained_glass
setblock 507 113 235 minecraft:green_stained_glass
fill 507 113 236 509 113 236 minecraft:lime_stained_glass
setblock 507 113 239 minecraft:green_stained_glass
fill 507 113 240 509 113 240 minecraft:lime_stained_glass
setblock 507 113 242 minecraft:lime_stained_glass
setblock 507 113 243 minecraft:green_stained_glass
fill 507 113 244 507 113 246 minecraft:lime_stained_glass
setblock 507 113 247 minecraft:purple_concrete
setblock 507 113 255 minecraft:red_concrete
fill 507 113 256 508 113 257 minecraft:lime_stained_glass
setblock 507 113 259 minecraft:green_stained_glass
fill 507 113 260 509 113 260 minecraft:lime_stained_glass
setblock 507 113 263 minecraft:green_stained_glass
fill 507 113 264 509 113 264 minecraft:lime_stained_glass
fill 508 113 229 508 117 229 minecraft:red_concrete
setblock 508 113 230 minecraft:white_concrete
setblock 508 113 234 minecraft:green_stained_glass
fill 508 113 235 510 113 235 minecraft:lime_stained_glass
setblock 508 113 238 minecraft:green_stained_glass
fill 508 113 239 510 113 239 minecraft:lime_stained_glass
setblock 508 113 242 minecraft:green_stained_glass
fill 508 113 243 508 113 245 minecraft:lime_stained_glass
setblock 508 113 246 minecraft:green_stained_glass
fill 508 113 247 508 113 249 minecraft:lime_stained_glass
setblock 508 113 250 minecraft:green_stained_glass
fill 508 113 251 508 113 253 minecraft:lime_stained_glass
setblock 508 113 254 minecraft:green_stained_glass
fill 508 113 255 510 113 255 minecraft:lime_stained_glass
setblock 508 113 258 minecraft:green_stained_glass
fill 508 113 259 510 113 259 minecraft:lime_stained_glass
setblock 508 113 262 minecraft:green_stained_glass
fill 508 113 263 510 113 263 minecraft:lime_stained_glass
fill 508 113 265 508 117 265 minecraft:red_concrete
setblock 508 113 266 minecraft:white_concrete
fill 509 113 234 511 113 234 minecraft:lime_stained_glass
setblock 509 113 237 minecraft:green_stained_glass
fill 509 113 238 511 113 238 minecraft:lime_stained_glass
setblock 509 113 241 minecraft:green_stained_glass
fill 509 113 242 509 113 244 minecraft:lime_stained_glass
setblock 509 113 245 minecraft:green_stained_glass
fill 509 113 246 509 113 248 minecraft:lime_stained_glass
setblock 509 113 249 minecraft:green_stained_glass
fill 509 113 250 509 113 252 minecraft:lime_stained_glass
setblock 509 113 253 minecraft:green_stained_glass
fill 509 113 254 511 113 254 minecraft:lime_stained_glass
setblock 509 113 256 minecraft:lime_stained_glass
setblock 509 113 257 minecraft:green_stained_glass
fill 509 113 258 511 113 258 minecraft:lime_stained_glass
setblock 509 113 261 minecraft:green_stained_glass
fill 509 113 262 511 113 262 minecraft:lime_stained_glass
fill 510 113 232 510 115 233 minecraft:white_concrete
setblock 510 113 236 minecraft:green_stained_glass
fill 510 113 237 511 113 237 minecraft:lime_stained_glass
setblock 510 113 240 minecraft:green_stained_glass
fill 510 113 241 510 113 243 minecraft:lime_stained_glass
setblock 510 113 244 minecraft:green_stained_glass
fill 510 113 245 510 113 247 minecraft:lime_stained_glass
setblock 510 113 248 minecraft:green_stained_glass
fill 510 113 249 510 113 251 minecraft:lime_stained_glass
setblock 510 113 252 minecraft:green_stained_glass
fill 510 113 253 511 113 253 minecraft:lime_stained_glass
setblock 510 113 256 minecraft:green_stained_glass
fill 510 113 257 511 113 257 minecraft:lime_stained_glass
setblock 510 113 260 minecraft:green_stained_glass
fill 510 113 261 511 113 261 minecraft:lime_stained_glass
setblock 510 113 264 minecraft:green_stained_glass
fill 510 113 268 510 117 269 minecraft:white_concrete
setblock 511 113 229 minecraft:lime_stained_glass
setblock 511 113 232 minecraft:red_concrete
setblock 511 113 233 minecraft:lime_stained_glass
setblock 511 113 235 minecraft:green_stained_glass
setblock 511 113 236 minecraft:lime_stained_glass
setblock 511 113 239 minecraft:green_stained_glass
fill 511 113 240 511 113 242 minecraft:lime_stained_glass
setblock 511 113 243 minecraft:green_stained_glass
fill 511 113 244 511 113 246 minecraft:lime_stained_glass
setblock 511 113 247 minecraft:green_stained_glass
fill 511 113 248 511 113 250 minecraft:lime_stained_glass
setblock 511 113 251 minecraft:green_stained_glass
setblock 511 113 252 minecraft:lime_stained_glass
setblock 511 113 255 minecraft:green_stained_glass
setblock 511 113 256 minecraft:lime_stained_glass
setblock 511 113 259 minecraft:green_stained_glass
setblock 511 113 260 minecraft:lime_stained_glass
setblock 511 113 263 minecraft:green_stained_glass
fill 511 113 264 511 113 265 minecraft:lime_stained_glass
setblock 511 113 268 minecraft:red_concrete
setblock 511 113 269 minecraft:lime_stained_glass
fill 471 114 230 472 117 230 minecraft:red_concrete
fill 471 114 266 472 117 266 minecraft:red_concrete
fill 475 114 232 475 115 232 minecraft:white_concrete
fill 475 114 268 475 117 268 minecraft:white_concrete
setblock 488 114 251 minecraft:red_concrete
setblock 489 114 248 minecraft:red_concrete
setblock 489 114 254 minecraft:purple_concrete
setblock 490 114 246 minecraft:orange_concrete
setblock 490 114 256 minecraft:light_blue_concrete
setblock 491 114 245 minecraft:orange_concrete
setblock 491 114 257 minecraft:light_blue_concrete
setblock 493 114 244 minecraft:yellow_concrete
setblock 493 114 258 minecraft:lime_concrete
setblock 496 114 243 minecraft:lime_concrete
setblock 496 114 259 minecraft:lime_concrete
setblock 499 114 244 minecraft:lime_concrete
setblock 499 114 258 minecraft:yellow_concrete
setblock 501 114 245 minecraft:light_blue_concrete
setblock 501 114 257 minecraft:orange_concrete
setblock 502 114 246 minecraft:light_blue_concrete
setblock 502 114 256 minecraft:orange_concrete
setblock 503 114 248 minecraft:purple_concrete
setblock 503 114 254 minecraft:red_concrete
setblock 504 114 251 minecraft:red_concrete
fill 507 114 230 508 117 230 minecraft:red_concrete
fill 507 114 266 508 117 266 minecraft:red_concrete
fill 511 114 232 511 115 232 minecraft:white_concrete
fill 511 114 268 511 117 268 minecraft:white_concrete
fill 471 115 231 472 116 231 minecraft:red_concrete
setblock 471 115 232 minecraft:white_concrete
fill 471 115 267 472 117 267 minecraft:red_concrete
setblock 471 115 268 minecraft:white_concrete
fill 473 115 231 475 116 231 minecraft:white_concrete
fill 473 115 267 475 117 267 minecraft:white_concrete
setblock 474 115 230 minecraft:red_concrete
setblock 474 115 266 minecraft:red_concrete
fill 475 115 230 475 117 230 minecraft:white_concrete
fill 475 115 266 475 120 266 minecraft:white_concrete
fill 507 115 231 508 116 231 minecraft:red_concrete
setblock 507 115 232 minecraft:white_concrete
fill 507 115 267 508 117 267 minecraft:red_concrete
setblock 507 115 268 minecraft:white_concrete
fill 509 115 231 511 116 231 minecraft:white_concrete
fill 509 115 267 511 117 267 minecraft:white_concrete
setblock 510 115 230 minecraft:red_concrete
setblock 510 115 266 minecraft:red_concrete
fill 511 115 230 511 117 230 minecraft:white_concrete
fill 511 115 266 511 117 266 minecraft:white_concrete
setblock 470 116 231 minecraft:white_concrete
fill 470 116 232 511 119 232 minecraft:brown_terracotta
setblock 470 116 233 minecraft:white_concrete
setblock 470 116 234 minecraft:light_blue_concrete
fill 470 116 235 511 119 235 minecraft:brown_terracotta
setblock 470 116 236 minecraft:light_blue_concrete
fill 471 116 268 472 117 268 minecraft:red_concrete
fill 472 116 233 474 116 233 minecraft:white_concrete
setblock 472 116 269 minecraft:white_concrete
fill 474 116 229 474 117 230 minecraft:white_concrete
fill 474 116 265 474 120 266 minecraft:white_concrete
fill 507 116 268 508 117 268 minecraft:red_concrete
fill 508 116 233 510 116 233 minecraft:white_concrete
setblock 508 116 269 minecraft:white_concrete
fill 510 116 229 510 117 230 minecraft:white_concrete
fill 510 116 265 510 117 266 minecraft:white_concrete
fill 470 117 231 511 118 231 minecraft:brown_terracotta
fill 470 117 233 511 118 234 minecraft:brown_terracotta
fill 470 117 236 511 118 236 minecraft:brown_terracotta
fill 472 117 269 473 117 269 minecraft:red_concrete
fill 473 117 229 473 117 230 minecraft:white_concrete
fill 473 117 265 473 117 266 minecraft:white_concrete
setblock 473 117 268 minecraft:red_concrete
fill 507 117 249 508 118 249 minecraft:lime_concrete
fill 508 117 269 509 117 269 minecraft:red_concrete
fill 509 117 229 509 117 230 minecraft:white_concrete
fill 509 117 265 509 117 266 minecraft:white_concrete
setblock 509 117 268 minecraft:red_concrete
fill 512 117 231 512 308 231 minecraft:white_concrete
fill 512 117 232 512 118 232 minecraft:brown_terracotta
fill 512 117 233 512 308 233 minecraft:white_concrete
fill 512 117 234 512 308 234 minecraft:light_blue_concrete
fill 512 117 235 512 118 235 minecraft:brown_terracotta
fill 512 117 236 512 308 236 minecraft:light_blue_concrete
fill 471 118 229 511 118 230 minecraft:black_concrete
fill 471 118 237 473 118 269 minecraft:black_concrete
fill 474 118 267 511 118 269 minecraft:black_concrete
setblock 480 118 238 minecraft:light[level=12]
setblock 480 118 245 minecraft:light[level=12]
setblock 480 118 252 minecraft:light[level=12]
setblock 480 118 259 minecraft:light[level=12]
setblock 480 118 266 minecraft:light[level=12]
setblock 487 118 238 minecraft:light[level=12]
setblock 487 118 245 minecraft:light[level=12]
setblock 487 118 252 minecraft:light[level=12]
setblock 487 118 259 minecraft:light[level=12]
setblock 487 118 266 minecraft:light[level=12]
setblock 494 118 238 minecraft:light[level=12]
setblock 494 118 245 minecraft:light[level=12]
setblock 494 118 252 minecraft:light[level=12]
setblock 494 118 259 minecraft:light[level=12]
setblock 494 118 266 minecraft:light[level=12]
setblock 501 118 238 minecraft:light[level=12]
setblock 501 118 245 minecraft:light[level=12]
setblock 501 118 252 minecraft:light[level=12]
setblock 501 118 259 minecraft:light[level=12]
setblock 501 118 266 minecraft:light[level=12]
setblock 507 118 266 minecraft:red_concrete
setblock 508 118 238 minecraft:light[level=12]
setblock 508 118 245 minecraft:light[level=12]
setblock 508 118 252 minecraft:light[level=12]
setblock 508 118 259 minecraft:light[level=12]
fill 508 118 265 508 122 266 minecraft:white_concrete
fill 509 118 237 511 118 266 minecraft:black_concrete
fill 470 119 231 470 308 231 minecraft:white_concrete
fill 470 119 233 470 308 233 minecraft:white_concrete
fill 470 119 234 470 244 234 minecraft:light_blue_concrete
fill 470 119 236 470 244 236 minecraft:light_blue_concrete
fill 471 119 229 511 119 231 minecraft:gray_concrete
fill 471 119 233 473 119 234 minecraft:gray_concrete
fill 471 119 236 473 119 269 minecraft:gray_concrete
fill 474 119 233 474 122 233 minecraft:red_concrete
fill 474 119 267 511 119 269 minecraft:gray_concrete
fill 507 119 266 507 123 266 minecraft:white_concrete
fill 508 119 233 508 120 233 minecraft:red_concrete
fill 509 119 233 511 119 234 minecraft:gray_concrete
fill 509 119 236 511 119 266 minecraft:gray_concrete
fill 512 119 232 512 308 232 minecraft:white_concrete
fill 512 119 235 512 244 235 minecraft:light_blue_concrete
fill 470 120 232 471 125 232 minecraft:white_concrete
fill 470 120 235 470 243 235 minecraft:light_blue_concrete
fill 471 120 230 472 123 231 minecraft:white_concrete
setblock 471 120 233 minecraft:white_concrete
fill 471 120 266 471 123 268 minecraft:white_concrete
fill 472 120 229 474 121 229 minecraft:white_concrete
fill 472 120 232 473 120 233 minecraft:red_concrete
setblock 472 120 247 minecraft:light_blue_concrete
setblock 472 120 251 minecraft:orange_concrete
setblock 472 120 261 minecraft:magenta_concrete
fill 472 120 265 472 122 267 minecraft:white_concrete
fill 472 120 268 474 120 269 minecraft:red_concrete
fill 473 120 230 475 120 230 minecraft:white_concrete
fill 473 120 231 475 124 231 minecraft:red_concrete
setblock 473 120 239 minecraft:light[level=15]
setblock 473 120 247 minecraft:light[level=15]
setblock 473 120 255 minecraft:red_concrete
setblock 473 120 263 minecraft:light[level=15]
fill 473 120 265 473 121 266 minecraft:white_concrete
fill 473 120 267 475 124 267 minecraft:red_concrete
fill 474 120 232 475 122 232 minecraft:red_concrete
fill 475 120 268 475 123 268 minecraft:red_concrete
setblock 481 120 229 minecraft:white_concrete
setblock 481 120 231 minecraft:light[level=15]
setblock 481 120 239 minecraft:light[level=15]
setblock 481 120 247 minecraft:light[level=15]
setblock 481 120 255 minecraft:light[level=15]
setblock 481 120 263 minecraft:light[level=15]
setblock 483 120 229 minecraft:white_concrete
fill 483 120 267 483 121 267 minecraft:brown_concrete
fill 486 120 229 486 121 229 minecraft:brown_concrete
setblock 489 120 229 minecraft:white_concrete
setblock 489 120 231 minecraft:light[level=15]
setblock 489 120 239 minecraft:light[level=15]
setblock 489 120 247 minecraft:light[level=15]
setblock 489 120 255 minecraft:light[level=15]
setblock 489 120 263 minecraft:light[level=15]
setblock 494 120 229 minecraft:white_concrete
setblock 497 120 231 minecraft:light[level=15]
setblock 497 120 239 minecraft:light[level=15]
setblock 497 120 247 minecraft:light[level=15]
setblock 497 120 255 minecraft:light[level=15]
setblock 497 120 263 minecraft:light[level=15]
setblock 498 120 269 minecraft:white_concrete
setblock 505 120 231 minecraft:light[level=15]
setblock 505 120 239 minecraft:light[level=15]
setblock 505 120 247 minecraft:light[level=15]
setblock 505 120 255 minecraft:light[level=15]
setblock 505 120 263 minecraft:light[level=15]
fill 507 120 230 507 123 232 minecraft:white_concrete
fill 507 120 267 507 124 268 minecraft:white_concrete
fill 508 120 229 508 122 231 minecraft:white_concrete
fill 508 120 232 511 120 232 minecraft:red_concrete
fill 508 120 267 508 124 267 minecraft:white_concrete
fill 508 120 268 510 120 269 minecraft:red_concrete
fill 509 120 229 510 120 230 minecraft:white_concrete
fill 509 120 231 511 124 231 minecraft:red_concrete
fill 509 120 233 510 121 233 minecraft:red_concrete
setblock 509 120 251 minecraft:orange_concrete
fill 509 120 265 510 120 266 minecraft:white_concrete
fill 509 120 267 511 124 267 minecraft:red_concrete
setblock 510 120 246 minecraft:light_blue_concrete
setblock 510 120 259 minecraft:orange_concrete
fill 510 120 263 510 121 263 minecraft:brown_concrete
setblock 511 120 230 minecraft:white_concrete
setblock 511 120 266 minecraft:white_concrete
fill 511 120 268 511 123 268 minecraft:red_concrete
fill 472 121 232 472 125 233 minecraft:white_concrete
fill 472 121 268 472 125 269 minecraft:white_concrete
setblock 473 121 230 minecraft:white_concrete
fill 473 121 232 473 121 233 minecraft:red_concrete
fill 473 121 268 474 121 269 minecraft:red_concrete
fill 474 121 230 475 124 230 minecraft:red_concrete
setblock 474 121 265 minecraft:white_concrete
fill 474 121 266 475 124 266 minecraft:red_concrete
fill 508 121 232 508 125 233 minecraft:white_concrete
fill 508 121 268 508 125 269 minecraft:white_concrete
fill 509 121 229 509 121 230 minecraft:white_concrete
fill 509 121 232 511 121 232 minecraft:red_concrete
fill 509 121 265 509 121 266 minecraft:white_concrete
fill 509 121 268 510 121 269 minecraft:red_concrete
setblock 510 121 229 minecraft:white_concrete
fill 510 121 230 511 124 230 minecraft:red_concrete
setblock 510 121 265 minecraft:white_concrete
fill 510 121 266 511 124 266 minecraft:red_concrete
setblock 472 122 229 minecraft:white_concrete
fill 473 122 229 473 126 230 minecraft:red_concrete
fill 473 122 232 473 126 233 minecraft:white_concrete
fill 473 122 265 473 126 266 minecraft:red_concrete
fill 473 122 268 473 126 269 minecraft:white_concrete
fill 474 122 229 474 125 229 minecraft:red_concrete
fill 474 122 265 474 125 265 minecraft:red_concrete
fill 474 122 268 474 122 269 minecraft:red_concrete
fill 497 122 265 498 123 266 minecraft:lime_concrete
fill 509 122 229 509 126 230 minecraft:red_concrete
fill 509 122 232 509 126 233 minecraft:white_concrete
fill 509 122 265 509 126 266 minecraft:red_concrete
fill 509 122 268 509 126 269 minecraft:white_concrete
fill 510 122 229 510 125 229 minecraft:red_concrete
fill 510 122 232 510 122 233 minecraft:red_concrete
fill 510 122 265 510 125 265 minecraft:red_concrete
fill 510 122 268 510 122 269 minecraft:red_concrete
fill 511 122 232 511 123 232 minecraft:red_concrete
fill 472 123 229 472 127 229 minecraft:red_concrete
fill 472 123 265 472 127 265 minecraft:red_concrete
fill 472 123 266 472 123 267 minecraft:white_concrete
fill 474 123 232 474 127 233 minecraft:white_concrete
fill 474 123 268 474 127 269 minecraft:white_concrete
setblock 475 123 232 minecraft:red_concrete
fill 508 123 229 508 127 229 minecraft:red_concrete
fill 508 123 230 508 123 231 minecraft:white_concrete
fill 508 123 265 508 127 265 minecraft:red_concrete
setblock 508 123 266 minecraft:white_concrete
fill 510 123 232 510 127 233 minecraft:white_concrete
fill 510 123 268 510 127 269 minecraft:white_concrete
fill 471 124 230 472 127 230 minecraft:red_concrete
fill 471 124 231 472 124 231 minecraft:white_concrete
fill 471 124 266 472 127 266 minecraft:red_concrete
fill 471 124 267 471 124 268 minecraft:white_concrete
setblock 472 124 267 minecraft:white_concrete
setblock 473 124 238 minecraft:light[level=12]
setblock 473 124 245 minecraft:light[level=12]
setblock 473 124 252 minecraft:light[level=12]
setblock 473 124 259 minecraft:light[level=12]
fill 475 124 232 475 128 232 minecraft:white_concrete
fill 475 124 268 475 128 268 minecraft:white_concrete
setblock 480 124 231 minecraft:light[level=12]
setblock 480 124 238 minecraft:light[level=12]
setblock 480 124 245 minecraft:light[level=12]
setblock 480 124 252 minecraft:light[level=12]
setblock 480 124 259 minecraft:light[level=12]
setblock 480 124 266 minecraft:light[level=12]
setblock 487 124 231 minecraft:light[level=12]
setblock 487 124 238 minecraft:light[level=12]
setblock 487 124 245 minecraft:light[level=12]
setblock 487 124 252 minecraft:light[level=12]
setblock 487 124 259 minecraft:light[level=12]
setblock 487 124 266 minecraft:light[level=12]
setblock 494 124 231 minecraft:light[level=12]
setblock 494 124 238 minecraft:light[level=12]
setblock 494 124 245 minecraft:light[level=12]
setblock 494 124 252 minecraft:light[level=12]
setblock 494 124 259 minecraft:light[level=12]
setblock 494 124 266 minecraft:light[level=12]
setblock 501 124 231 minecraft:light[level=12]
setblock 501 124 238 minecraft:light[level=12]
setblock 501 124 245 minecraft:light[level=12]
setblock 501 124 252 minecraft:light[level=12]
setblock 501 124 259 minecraft:light[level=12]
setblock 501 124 266 minecraft:light[level=12]
fill 507 124 230 508 127 230 minecraft:red_concrete
fill 507 124 231 507 124 232 minecraft:white_concrete
fill 507 124 266 508 127 266 minecraft:red_concrete
setblock 508 124 231 minecraft:white_concrete
setblock 508 124 238 minecraft:light[level=12]
setblock 508 124 245 minecraft:light[level=12]
setblock 508 124 252 minecraft:light[level=12]
setblock 508 124 259 minecraft:light[level=12]
fill 511 124 232 511 128 232 minecraft:white_concrete
fill 511 124 268 511 128 268 minecraft:white_concrete
fill 471 125 231 472 129 231 minecraft:red_concrete
fill 471 125 267 472 129 267 minecraft:red_concrete
setblock 471 125 268 minecraft:white_concrete
fill 473 125 231 475 129 231 minecraft:white_concrete
fill 473 125 267 475 129 267 minecraft:white_concrete
setblock 474 125 230 minecraft:red_concrete
setblock 474 125 266 minecraft:red_concrete
fill 475 125 230 475 130 230 minecraft:white_concrete
fill 475 125 266 475 130 266 minecraft:white_concrete
fill 507 125 231 508 129 231 minecraft:red_concrete
setblock 507 125 232 minecraft:white_concrete
fill 507 125 267 508 129 267 minecraft:red_concrete
setblock 507 125 268 minecraft:white_concrete
fill 509 125 231 511 129 231 minecraft:white_concrete
fill 509 125 267 511 129 267 minecraft:white_concrete
setblock 510 125 230 minecraft:red_concrete
setblock 510 125 266 minecraft:red_concrete
fill 511 125 230 511 130 230 minecraft:white_concrete
fill 511 125 266 511 130 266 minecraft:white_concrete
fill 470 126 232 470 308 232 minecraft:white_concrete
fill 471 126 232 472 129 232 minecraft:red_concrete
fill 471 126 268 472 129 268 minecraft:red_concrete
setblock 472 126 233 minecraft:white_concrete
setblock 472 126 269 minecraft:white_concrete
fill 474 126 229 474 130 230 minecraft:white_concrete
fill 474 126 265 474 130 266 minecraft:white_concrete
fill 480 126 245 480 127 245 minecraft:yellow_concrete
fill 507 126 232 508 129 232 minecraft:red_concrete
fill 507 126 268 508 129 268 minecraft:red_concrete
setblock 508 126 233 minecraft:white_concrete
setblock 508 126 269 minecraft:white_concrete
fill 510 126 229 510 130 230 minecraft:white_concrete
fill 510 126 265 510 130 266 minecraft:white_concrete
fill 472 127 233 473 130 233 minecraft:red_concrete
fill 472 127 269 473 130 269 minecraft:red_concrete
fill 473 127 229 473 131 230 minecraft:white_concrete
fill 473 127 232 473 131 232 minecraft:red_concrete
setblock 473 127 239 minecraft:light[level=15]
setblock 473 127 247 minecraft:light[level=15]
setblock 473 127 255 minecraft:light[level=15]
setblock 473 127 263 minecraft:light[level=15]
fill 473 127 265 473 131 266 minecraft:white_concrete
fill 473 127 268 473 131 268 minecraft:red_concrete
setblock 481 127 231 minecraft:light[level=15]
setblock 481 127 239 minecraft:light[level=15]
setblock 481 127 247 minecraft:light[level=15]
setblock 481 127 255 minecraft:light[level=15]
setblock 481 127 263 minecraft:light[level=15]
setblock 489 127 231 minecraft:light[level=15]
setblock 489 127 239 minecraft:light[level=15]
setblock 489 127 247 minecraft:light[level=15]
setblock 489 127 255 minecraft:light[level=15]
setblock 489 127 263 minecraft:light[level=15]
setblock 497 127 231 minecraft:light[level=15]
setblock 497 127 239 minecraft:light[level=15]
setblock 497 127 247 minecraft:light[level=15]
setblock 497 127 255 minecraft:light[level=15]
setblock 497 127 263 minecraft:light[level=15]
fill 501 127 254 502 128 254 minecraft:pink_concrete
setblock 505 127 231 minecraft:light[level=15]
setblock 505 127 239 minecraft:light[level=15]
setblock 505 127 247 minecraft:light[level=15]
setblock 505 127 255 minecraft:light[level=15]
setblock 505 127 263 minecraft:light[level=15]
fill 508 127 233 509 130 233 minecraft:red_concrete
fill 508 127 269 509 130 269 minecraft:red_concrete
fill 509 127 229 509 131 230 minecraft:white_concrete
fill 509 127 232 509 131 232 minecraft:red_concrete
fill 509 127 265 509 131 266 minecraft:white_concrete
fill 509 127 268 509 131 268 minecraft:red_concrete
setblock 471 128 230 minecraft:red_concrete
setblock 471 128 266 minecraft:red_concrete
fill 472 128 229 472 132 230 minecraft:white_concrete
fill 472 128 265 472 132 266 minecraft:white_concrete
setblock 474 128 232 minecraft:white_concrete
fill 474 128 233 474 132 233 minecraft:red_concrete
setblock 474 128 268 minecraft:white_concrete
fill 474 128 269 474 132 269 minecraft:red_concrete
setblock 507 128 230 minecraft:red_concrete
setblock 507 128 266 minecraft:red_concrete
fill 508 128 229 508 132 230 minecraft:white_concrete
fill 508 128 265 508 132 266 minecraft:white_concrete
setblock 510 128 232 minecraft:white_concrete
fill 510 128 233 510 132 233 minecraft:red_concrete
setblock 510 128 268 minecraft:white_concrete
fill 510 128 269 510 132 269 minecraft:red_concrete
fill 471 129 230 471 133 230 minecraft:white_concrete
fill 471 129 266 471 133 266 minecraft:white_concrete
fill 474 129 232 475 132 232 minecraft:red_concrete
fill 474 129 268 475 132 268 minecraft:red_concrete
fill 507 129 230 507 133 230 minecraft:white_concrete
fill 507 129 266 507 133 266 minecraft:white_concrete
fill 510 129 232 511 132 232 minecraft:red_concrete
fill 510 129 268 511 132 268 minecraft:red_concrete
fill 471 130 231 471 134 232 minecraft:white_concrete
fill 471 130 267 471 134 268 minecraft:white_concrete
fill 472 130 231 472 134 231 minecraft:white_concrete
setblock 472 130 232 minecraft:red_concrete
fill 472 130 267 472 134 267 minecraft:white_concrete
setblock 472 130 268 minecraft:red_concrete
fill 473 130 231 475 134 231 minecraft:red_concrete
setblock 473 130 238 minecraft:light[level=12]
setblock 473 130 245 minecraft:light[level=12]
setblock 473 130 252 minecraft:light[level=12]
setblock 473 130 259 minecraft:light[level=12]
fill 473 130 267 475 134 267 minecraft:red_concrete
setblock 480 130 231 minecraft:light[level=12]
setblock 480 130 238 minecraft:light[level=12]
setblock 480 130 245 minecraft:light[level=12]
setblock 480 130 252 minecraft:light[level=12]
setblock 480 130 259 minecraft:light[level=12]
setblock 480 130 266 minecraft:light[level=12]
setblock 487 130 231 minecraft:light[level=12]
setblock 487 130 238 minecraft:light[level=12]
setblock 487 130 245 minecraft:light[level=12]
setblock 487 130 252 minecraft:light[level=12]
setblock 487 130 259 minecraft:light[level=12]
setblock 487 130 266 minecraft:light[level=12]
setblock 494 130 231 minecraft:light[level=12]
setblock 494 130 238 minecraft:light[level=12]
setblock 494 130 245 minecraft:light[level=12]
setblock 494 130 252 minecraft:light[level=12]
setblock 494 130 259 minecraft:light[level=12]
setblock 494 130 266 minecraft:light[level=12]
setblock 501 130 231 minecraft:light[level=12]
setblock 501 130 238 minecraft:light[level=12]
setblock 501 130 245 minecraft:light[level=12]
setblock 501 130 252 minecraft:light[level=12]
setblock 501 130 259 minecraft:light[level=12]
setblock 501 130 266 minecraft:light[level=12]
fill 507 130 231 507 134 232 minecraft:white_concrete
fill 507 130 267 507 134 268 minecraft:white_concrete
fill 508 130 231 508 134 231 minecraft:white_concrete
setblock 508 130 232 minecraft:red_concrete
setblock 508 130 238 minecraft:light[level=12]
setblock 508 130 245 minecraft:light[level=12]
setblock 508 130 252 minecraft:light[level=12]
setblock 508 130 259 minecraft:light[level=12]
fill 508 130 267 508 134 267 minecraft:white_concrete
setblock 508 130 268 minecraft:red_concrete
fill 509 130 231 511 134 231 minecraft:red_concrete
fill 509 130 267 511 134 267 minecraft:red_concrete
fill 472 131 232 472 135 233 minecraft:white_concrete
fill 472 131 268 472 135 269 minecraft:white_concrete
setblock 473 131 233 minecraft:red_concrete
setblock 473 131 269 minecraft:red_concrete
setblock 474 131 229 minecraft:white_concrete
fill 474 131 230 475 134 230 minecraft:red_concrete
setblock 474 131 265 minecraft:white_concrete
fill 474 131 266 475 134 266 minecraft:red_concrete
fill 508 131 232 508 135 233 minecraft:white_concrete
fill 508 131 268 508 135 269 minecraft:white_concrete
setblock 509 131 233 minecraft:red_concrete
setblock 509 131 269 minecraft:red_concrete
setblock 510 131 229 minecraft:white_concrete
fill 510 131 230 511 134 230 minecraft:red_concrete
setblock 510 131 265 minecraft:white_concrete
fill 510 131 266 511 134 266 minecraft:red_concrete
fill 473 132 229 473 136 230 minecraft:red_concrete
fill 473 132 232 473 136 233 minecraft:white_concrete
fill 473 132 265 473 136 266 minecraft:red_concrete
fill 473 132 268 473 136 269 minecraft:white_concrete
fill 474 132 229 474 135 229 minecraft:red_concrete
fill 474 132 265 474 135 265 minecraft:red_concrete
fill 509 132 229 509 136 230 minecraft:red_concrete
fill 509 132 232 509 136 233 minecraft:white_concrete
fill 509 132 265 509 136 266 minecraft:red_concrete
fill 509 132 268 509 136 269 minecraft:white_concrete
fill 510 132 229 510 135 229 minecraft:red_concrete
fill 510 132 265 510 135 265 minecraft:red_concrete
fill 472 133 229 472 137 229 minecraft:red_concrete
setblock 472 133 230 minecraft:white_concrete
fill 472 133 265 472 137 265 minecraft:red_concrete
setblock 472 133 266 minecraft:white_concrete
fill 474 133 232 474 137 233 minecraft:white_concrete
fill 474 133 268 474 137 269 minecraft:white_concrete
setblock 475 133 232 minecraft:red_concrete
setblock 475 133 268 minecraft:red_concrete
fill 508 133 229 508 137 229 minecraft:red_concrete
setblock 508 133 230 minecraft:white_concrete
fill 508 133 265 508 137 265 minecraft:red_concrete
setblock 508 133 266 minecraft:white_concrete
fill 510 133 232 510 137 233 minecraft:white_concrete
fill 510 133 268 510 137 269 minecraft:white_concrete
setblock 511 133 232 minecraft:red_concrete
setblock 511 133 268 minecraft:red_concrete
fill 471 134 230 472 137 230 minecraft:red_concrete
fill 471 134 266 472 137 266 minecraft:red_concrete
setblock 473 134 239 minecraft:light[level=15]
setblock 473 134 247 minecraft:light[level=15]
setblock 473 134 255 minecraft:light[level=15]
setblock 473 134 263 minecraft:light[level=15]
fill 475 134 232 475 138 232 minecraft:white_concrete
fill 475 134 268 475 138 268 minecraft:white_concrete
setblock 481 134 231 minecraft:light[level=15]
setblock 481 134 239 minecraft:light[level=15]
setblock 481 134 247 minecraft:light[level=15]
setblock 481 134 255 minecraft:light[level=15]
setblock 481 134 263 minecraft:light[level=15]
setblock 489 134 231 minecraft:light[level=15]
setblock 489 134 239 minecraft:light[level=15]
setblock 489 134 247 minecraft:light[level=15]
setblock 489 134 255 minecraft:light[level=15]
setblock 489 134 263 minecraft:light[level=15]
setblock 497 134 231 minecraft:light[level=15]
setblock 497 134 239 minecraft:light[level=15]
setblock 497 134 247 minecraft:light[level=15]
setblock 497 134 255 minecraft:light[level=15]
setblock 497 134 263 minecraft:light[level=15]
setblock 505 134 231 minecraft:light[level=15]
setblock 505 134 239 minecraft:light[level=15]
setblock 505 134 247 minecraft:light[level=15]
setblock 505 134 255 minecraft:light[level=15]
setblock 505 134 263 minecraft:light[level=15]
fill 507 134 230 508 137 230 minecraft:red_concrete
fill 507 134 266 508 137 266 minecraft:red_concrete
fill 511 134 232 511 138 232 minecraft:white_concrete
fill 511 134 268 511 138 268 minecraft:white_concrete
fill 471 135 231 472 138 231 minecraft:red_concrete
setblock 471 135 232 minecraft:white_concrete
fill 471 135 267 472 138 267 minecraft:red_concrete
setblock 471 135 268 minecraft:white_concrete
fill 473 135 231 475 138 231 minecraft:white_concrete
fill 473 135 267 475 138 267 minecraft:white_concrete
setblock 474 135 230 minecraft:red_concrete
setblock 474 135 266 minecraft:red_concrete
fill 475 135 230 475 138 230 minecraft:white_concrete
fill 475 135 266 475 140 266 minecraft:white_concrete
fill 486 135 239 489 194 240 minecraft:white_concrete
fill 487 135 238 489 194 238 minecraft:white_concrete
fill 487 135 241 489 194 241 minecraft:white_concrete
fill 490 135 239 490 194 239 minecraft:white_concrete
fill 507 135 231 508 138 231 minecraft:red_concrete
setblock 507 135 232 minecraft:white_concrete
fill 507 135 267 508 138 267 minecraft:red_concrete
setblock 507 135 268 minecraft:white_concrete
fill 509 135 231 511 138 231 minecraft:white_concrete
fill 509 135 267 511 138 267 minecraft:white_concrete
setblock 510 135 230 minecraft:red_concrete
setblock 510 135 266 minecraft:red_concrete
fill 511 135 230 511 138 230 minecraft:white_concrete
fill 511 135 266 511 138 266 minecraft:white_concrete
fill 471 136 232 472 138 232 minecraft:red_concrete
fill 471 136 268 472 138 268 minecraft:red_concrete
setblock 472 136 233 minecraft:white_concrete
setblock 472 136 269 minecraft:white_concrete
setblock 473 136 238 minecraft:light[level=12]
setblock 473 136 245 minecraft:light[level=12]
setblock 473 136 252 minecraft:light[level=12]
setblock 473 136 259 minecraft:light[level=12]
fill 474 136 229 474 138 230 minecraft:white_concrete
fill 474 136 265 474 140 266 minecraft:white_concrete
setblock 480 136 231 minecraft:light[level=12]
setblock 480 136 238 minecraft:light[level=12]
setblock 480 136 245 minecraft:light[level=12]
setblock 480 136 252 minecraft:light[level=12]
setblock 480 136 259 minecraft:light[level=12]
setblock 480 136 266 minecraft:light[level=12]
fill 485 136 239 485 137 240 minecraft:brown_terracotta
fill 486 136 237 486 137 238 minecraft:brown_terracotta
fill 486 136 241 486 137 241 minecraft:brown_terracotta
setblock 487 136 231 minecraft:light[level=12]
fill 487 136 237 490 137 237 minecraft:brown_terracotta
fill 487 136 242 489 137 242 minecraft:brown_terracotta
setblock 487 136 245 minecraft:light[level=12]
setblock 487 136 252 minecraft:light[level=12]
setblock 487 136 259 minecraft:light[level=12]
setblock 487 136 266 minecraft:light[level=12]
fill 490 136 238 490 137 238 minecraft:brown_terracotta
fill 490 136 240 490 137 241 minecraft:brown_terracotta
fill 493 136 249 493 194 251 minecraft:white_concrete
setblock 494 136 231 minecraft:light[level=12]
setblock 494 136 238 minecraft:light[level=12]
setblock 494 136 245 minecraft:light[level=12]
fill 494 136 251 494 194 252 minecraft:white_concrete
setblock 494 136 259 minecraft:light[level=12]
setblock 494 136 266 minecraft:light[level=12]
fill 495 136 252 495 194 252 minecraft:white_concrete
setblock 501 136 231 minecraft:light[level=12]
setblock 501 136 238 minecraft:light[level=12]
setblock 501 136 245 minecraft:light[level=12]
setblock 501 136 252 minecraft:light[level=12]
setblock 501 136 259 minecraft:light[level=12]
setblock 501 136 266 minecraft:light[level=12]
fill 507 136 232 508 139 232 minecraft:red_concrete
fill 507 136 268 508 138 268 minecraft:red_concrete
setblock 508 136 233 minecraft:white_concrete
setblock 508 136 238 minecraft:light[level=12]
setblock 508 136 245 minecraft:light[level=12]
setblock 508 136 252 minecraft:light[level=12]
setblock 508 136 259 minecraft:light[level=12]
setblock 508 136 269 minecraft:white_concrete
fill 510 136 229 510 138 230 minecraft:white_concrete
fill 510 136 265 510 138 266 minecraft:white_concrete
fill 472 137 233 473 138 233 minecraft:red_concrete
fill 472 137 269 473 138 269 minecraft:red_concrete
fill 473 137 229 473 138 230 minecraft:white_concrete
fill 473 137 232 473 138 232 minecraft:red_concrete
fill 473 137 265 473 138 266 minecraft:white_concrete
fill 473 137 268 473 138 268 minecraft:red_concrete
fill 485 137 237 485 137 238 minecraft:brown_terracotta
setblock 485 137 241 minecraft:brown_terracotta
fill 486 137 236 490 137 236 minecraft:brown_terracotta
setblock 486 137 242 minecraft:brown_terracotta
setblock 488 137 243 minecraft:brown_terracotta
setblock 490 137 242 minecraft:brown_terracotta
fill 491 137 237 491 137 241 minecraft:brown_terracotta
fill 492 137 249 492 138 251 minecraft:brown_terracotta
fill 493 137 248 493 138 248 minecraft:brown_terracotta
fill 493 137 252 493 138 252 minecraft:brown_terracotta
fill 494 137 253 496 138 253 minecraft:brown_terracotta
fill 508 137 233 509 138 233 minecraft:red_concrete
fill 508 137 269 509 138 269 minecraft:red_concrete
fill 509 137 229 509 138 230 minecraft:white_concrete
fill 509 137 232 509 138 232 minecraft:red_concrete
fill 509 137 265 509 138 266 minecraft:white_concrete
fill 509 137 268 509 138 268 minecraft:red_concrete
setblock 471 138 230 minecraft:red_concrete
setblock 471 138 266 minecraft:red_concrete
fill 472 138 229 472 138 230 minecraft:white_concrete
fill 472 138 265 472 138 266 minecraft:white_concrete
setblock 474 138 232 minecraft:white_concrete
fill 474 138 233 474 142 233 minecraft:red_concrete
setblock 474 138 268 minecraft:white_concrete
setblock 474 138 269 minecraft:red_concrete
fill 491 138 249 491 138 251 minecraft:brown_terracotta
fill 492 138 247 492 138 248 minecraft:brown_terracotta
setblock 492 138 252 minecraft:brown_terracotta
setblock 493 138 247 minecraft:brown_terracotta
setblock 493 138 253 minecraft:brown_terracotta
setblock 494 138 246 minecraft:brown_terracotta
fill 494 138 254 496 138 254 minecraft:brown_terracotta
fill 496 138 252 496 194 252 minecraft:white_concrete
setblock 497 138 253 minecraft:brown_terracotta
setblock 498 138 252 minecraft:brown_terracotta
setblock 507 138 230 minecraft:red_concrete
setblock 507 138 266 minecraft:red_concrete
fill 508 138 229 508 138 230 minecraft:white_concrete
fill 508 138 265 508 142 266 minecraft:white_concrete
setblock 510 138 232 minecraft:white_concrete
setblock 510 138 233 minecraft:red_concrete
setblock 510 138 268 minecraft:white_concrete
setblock 510 138 269 minecraft:red_concrete
fill 471 139 229 473 139 269 minecraft:black_concrete
fill 474 139 229 511 139 231 minecraft:black_concrete
fill 474 139 232 475 142 232 minecraft:red_concrete
fill 474 139 267 511 139 269 minecraft:black_concrete
fill 507 139 266 507 143 266 minecraft:white_concrete
fill 508 139 233 508 140 233 minecraft:red_concrete
fill 509 139 232 511 139 266 minecraft:black_concrete
fill 471 140 229 473 140 269 minecraft:gray_concrete
fill 474 140 229 511 140 231 minecraft:gray_concrete
fill 474 140 267 511 140 269 minecraft:gray_concrete
fill 507 140 232 507 145 232 minecraft:white_concrete
setblock 508 140 232 minecraft:red_concrete
fill 509 140 232 511 140 266 minecraft:gray_concrete
fill 471 141 230 472 143 232 minecraft:white_concrete
fill 471 141 237 471 146 237 minecraft:brown_terracotta
setblock 471 141 245 minecraft:lime_concrete
fill 471 141 250 471 142 250 minecraft:brown_concrete
fill 471 141 256 471 142 256 minecraft:brown_concrete
fill 471 141 266 472 143 268 minecraft:white_concrete
fill 472 141 229 474 141 229 minecraft:white_concrete
fill 472 141 233 472 146 233 minecraft:white_concrete
setblock 472 141 247 minecraft:white_concrete
setblock 472 141 248 minecraft:yellow_concrete
setblock 472 141 264 minecraft:red_concrete
fill 472 141 265 474 141 265 minecraft:white_concrete
fill 472 141 269 472 146 269 minecraft:white_concrete
setblock 473 141 230 minecraft:white_concrete
fill 473 141 231 473 141 233 minecraft:red_concrete
setblock 473 141 239 minecraft:light[level=15]
setblock 473 141 247 minecraft:light[level=15]
setblock 473 141 255 minecraft:light[level=15]
setblock 473 141 263 minecraft:light[level=15]
setblock 473 141 266 minecraft:white_concrete
fill 473 141 267 474 141 269 minecraft:red_concrete
fill 474 141 230 475 144 231 minecraft:red_concrete
fill 474 141 266 475 144 266 minecraft:red_concrete
fill 475 141 267 475 143 268 minecraft:red_concrete
fill 477 141 267 478 142 267 minecraft:brown_concrete
setblock 481 141 231 minecraft:light[level=15]
setblock 481 141 239 minecraft:light[level=15]
setblock 481 141 247 minecraft:light[level=15]
setblock 481 141 255 minecraft:light[level=15]
setblock 481 141 263 minecraft:light[level=15]
setblock 489 141 231 minecraft:light[level=15]
setblock 489 141 247 minecraft:light[level=15]
setblock 489 141 255 minecraft:light[level=15]
setblock 489 141 263 minecraft:light[level=15]
setblock 490 141 229 minecraft:light_blue_concrete
setblock 492 141 230 minecraft:white_concrete
setblock 497 141 231 minecraft:light[level=15]
setblock 497 141 239 minecraft:light[level=15]
setblock 497 141 247 minecraft:light[level=15]
setblock 497 141 255 minecraft:light[level=15]
setblock 497 141 263 minecraft:light[level=15]
setblock 499 141 231 minecraft:magenta_concrete
setblock 505 141 231 minecraft:light[level=15]
setblock 505 141 239 minecraft:light[level=15]
setblock 505 141 247 minecraft:light[level=15]
setblock 505 141 255 minecraft:light[level=15]
setblock 505 141 263 minecraft:light[level=15]
fill 506 141 229 506 142 229 minecraft:brown_concrete
fill 507 141 230 508 143 231 minecraft:white_concrete
fill 507 141 267 508 144 268 minecraft:white_concrete
fill 508 141 229 510 141 229 minecraft:white_concrete
fill 508 141 232 508 145 233 minecraft:white_concrete
fill 508 141 269 508 146 269 minecraft:white_concrete
setblock 509 141 230 minecraft:white_concrete
fill 509 141 231 510 141 233 minecraft:red_concrete
fill 509 141 263 509 142 263 minecraft:brown_concrete
fill 509 141 265 509 141 266 minecraft:white_concrete
fill 509 141 267 510 141 269 minecraft:red_concrete
fill 510 141 230 511 144 230 minecraft:red_concrete
setblock 510 141 250 minecraft:yellow_concrete
setblock 510 141 265 minecraft:white_concrete
fill 510 141 266 511 144 266 minecraft:red_concrete
fill 511 141 231 511 143 232 minecraft:red_concrete
setblock 511 141 259 minecraft:magenta_concrete
fill 511 141 267 511 143 268 minecraft:red_concrete
setblock 472 142 229 minecraft:white_concrete
setblock 472 142 265 minecraft:white_concrete
fill 473 142 229 473 144 231 minecraft:red_concrete
fill 473 142 232 473 146 233 minecraft:white_concrete
setblock 473 142 238 minecraft:light[level=12]
setblock 473 142 245 minecraft:light[level=12]
setblock 473 142 252 minecraft:light[level=12]
setblock 473 142 259 minecraft:light[level=12]
fill 473 142 265 473 144 267 minecraft:red_concrete
fill 473 142 268 473 146 269 minecraft:white_concrete
fill 474 142 229 474 145 229 minecraft:red_concrete
fill 474 142 265 474 145 265 minecraft:red_concrete
fill 474 142 267 474 142 269 minecraft:red_concrete
setblock 480 142 231 minecraft:light[level=12]
setblock 480 142 238 minecraft:light[level=12]
setblock 480 142 245 minecraft:light[level=12]
setblock 480 142 252 minecraft:light[level=12]
setblock 480 142 259 minecraft:light[level=12]
setblock 480 142 266 minecraft:light[level=12]
setblock 487 142 231 minecraft:light[level=12]
setblock 487 142 245 minecraft:light[level=12]
setblock 487 142 252 minecraft:light[level=12]
setblock 487 142 259 minecraft:light[level=12]
setblock 487 142 266 minecraft:light[level=12]
setblock 494 142 231 minecraft:light[level=12]
setblock 494 142 238 minecraft:light[level=12]
setblock 494 142 245 minecraft:light[level=12]
setblock 494 142 259 minecraft:light[level=12]
setblock 494 142 266 minecraft:light[level=12]
setblock 501 142 231 minecraft:light[level=12]
setblock 501 142 238 minecraft:light[level=12]
setblock 501 142 245 minecraft:light[level=12]
setblock 501 142 252 minecraft:light[level=12]
setblock 501 142 259 minecraft:light[level=12]
setblock 501 142 266 minecraft:light[level=12]
setblock 508 142 229 minecraft:white_concrete
setblock 508 142 238 minecraft:light[level=12]
setblock 508 142 245 minecraft:light[level=12]
setblock 508 142 252 minecraft:light[level=12]
setblock 508 142 259 minecraft:light[level=12]
fill 509 142 229 509 144 231 minecraft:red_concrete
fill 509 142 232 509 146 233 minecraft:white_concrete
fill 509 142 265 509 144 267 minecraft:red_concrete
fill 509 142 268 509 146 269 minecraft:white_concrete
fill 510 142 229 510 145 229 minecraft:red_concrete
fill 510 142 231 510 142 233 minecraft:red_concrete
fill 510 142 265 510 145 265 minecraft:red_concrete
fill 510 142 267 510 142 269 minecraft:red_concrete
fill 472 143 229 472 147 229 minecraft:red_concrete
fill 472 143 265 472 147 265 minecraft:red_concrete
fill 474 143 232 474 147 233 minecraft:white_concrete
fill 474 143 267 474 144 267 minecraft:red_concrete
fill 474 143 268 474 147 269 minecraft:white_concrete
setblock 475 143 232 minecraft:red_concrete
fill 508 143 229 508 147 229 minecraft:red_concrete
fill 508 143 265 508 147 265 minecraft:red_concrete
setblock 508 143 266 minecraft:white_concrete
fill 510 143 231 510 144 231 minecraft:red_concrete
fill 510 143 232 510 147 233 minecraft:white_concrete
fill 510 143 267 510 144 267 minecraft:red_concrete
fill 510 143 268 510 147 269 minecraft:white_concrete
fill 471 144 230 472 147 230 minecraft:red_concrete
fill 471 144 231 472 144 232 minecraft:white_concrete
fill 471 144 266 472 147 266 minecraft:red_concrete
fill 471 144 267 472 144 268 minecraft:white_concrete
fill 475 144 232 475 148 232 minecraft:white_concrete
setblock 475 144 267 minecraft:red_concrete
fill 475 144 268 475 148 268 minecraft:white_concrete
fill 507 144 230 508 147 230 minecraft:red_concrete
fill 507 144 231 508 144 231 minecraft:white_concrete
fill 507 144 266 508 147 266 minecraft:red_concrete
setblock 511 144 231 minecraft:red_concrete
fill 511 144 232 511 148 232 minecraft:white_concrete
setblock 511 144 267 minecraft:red_concrete
fill 511 144 268 511 148 268 minecraft:white_concrete
fill 471 145 231 472 149 231 minecraft:red_concrete
fill 471 145 232 472 145 232 minecraft:white_concrete
fill 471 145 267 472 149 267 minecraft:red_concrete
fill 471 145 268 472 145 268 minecraft:white_concrete
fill 473 145 229 473 146 230 minecraft:red_concrete
fill 473 145 231 475 149 231 minecraft:white_concrete
fill 473 145 265 473 146 266 minecraft:red_concrete
fill 473 145 267 475 149 267 minecraft:white_concrete
setblock 474 145 230 minecraft:red_concrete
setblock 474 145 266 minecraft:red_concrete
fill 475 145 230 475 150 230 minecraft:white_concrete
fill 475 145 266 475 150 266 minecraft:white_concrete
fill 503 145 245 503 146 245 minecraft:lime_concrete
fill 507 145 231 508 149 231 minecraft:red_concrete
fill 507 145 267 508 149 267 minecraft:red_concrete
fill 507 145 268 508 145 268 minecraft:white_concrete
fill 509 145 229 509 146 230 minecraft:red_concrete
fill 509 145 231 511 149 231 minecraft:white_concrete
fill 509 145 265 509 146 266 minecraft:red_concrete
fill 509 145 267 511 149 267 minecraft:white_concrete
setblock 510 145 230 minecraft:red_concrete
setblock 510 145 266 minecraft:red_concrete
fill 511 145 230 511 150 230 minecraft:white_concrete
fill 511 145 266 511 150 266 minecraft:white_concrete
fill 471 146 232 472 149 232 minecraft:red_concrete
fill 471 146 268 472 149 268 minecraft:red_concrete
fill 474 146 229 474 150 230 minecraft:white_concrete
fill 474 146 265 474 150 266 minecraft:white_concrete
fill 507 146 232 508 149 232 minecraft:red_concrete
fill 507 146 268 508 149 268 minecraft:red_concrete
setblock 508 146 233 minecraft:white_concrete
fill 510 146 229 510 150 230 minecraft:white_concrete
fill 510 146 265 510 150 266 minecraft:white_concrete
fill 472 147 233 473 150 233 minecraft:red_concrete
fill 472 147 269 473 150 269 minecraft:red_concrete
fill 473 147 229 473 151 230 minecraft:white_concrete
fill 473 147 232 473 151 232 minecraft:red_concrete
fill 473 147 265 473 151 266 minecraft:white_concrete
fill 473 147 268 473 151 268 minecraft:red_concrete
fill 508 147 233 509 150 233 minecraft:red_concrete
fill 508 147 269 509 150 269 minecraft:red_concrete
fill 509 147 229 509 151 230 minecraft:white_concrete
fill 509 147 232 509 151 232 minecraft:red_concrete
fill 509 147 265 509 151 266 minecraft:white_concrete
fill 509 147 268 509 151 268 minecraft:red_concrete
setblock 471 148 230 minecraft:red_concrete
setblock 471 148 266 minecraft:red_concrete
fill 472 148 229 472 152 230 minecraft:white_concrete
fill 472 148 265 472 152 266 minecraft:white_concrete
setblock 473 148 238 minecraft:light[level=12]
setblock 473 148 239 minecraft:light[level=15]
setblock 473 148 245 minecraft:light[level=12]
setblock 473 148 247 minecraft:light[level=15]
setblock 473 148 252 minecraft:light[level=12]
setblock 473 148 255 minecraft:light[level=15]
setblock 473 148 259 minecraft:light[level=12]
setblock 473 148 263 minecraft:light[level=15]
setblock 474 148 232 minecraft:white_concrete
fill 474 148 233 474 152 233 minecraft:red_concrete
setblock 474 148 268 minecraft:white_concrete
fill 474 148 269 474 152 269 minecraft:red_concrete
setblock 480 148 231 minecraft:light[level=12]
setblock 480 148 238 minecraft:light[level=12]
setblock 480 148 245 minecraft:light[level=12]
setblock 480 148 252 minecraft:light[level=12]
setblock 480 148 259 minecraft:light[level=12]
setblock 480 148 266 minecraft:light[level=12]
setblock 481 148 231 minecraft:light[level=15]
setblock 481 148 239 minecraft:light[level=15]
setblock 481 148 247 minecraft:light[level=15]
setblock 481 148 255 minecraft:light[level=15]
setblock 481 148 263 minecraft:light[level=15]
setblock 487 148 231 minecraft:light[level=12]
setblock 487 148 245 minecraft:light[level=12]
setblock 487 148 252 minecraft:light[level=12]
setblock 487 148 259 minecraft:light[level=12]
setblock 487 148 266 minecraft:light[level=12]
setblock 489 148 231 minecraft:light[level=15]
setblock 489 148 247 minecraft:light[level=15]
setblock 489 148 255 minecraft:light[level=15]
setblock 489 148 263 minecraft:light[level=15]
setblock 494 148 231 minecraft:light[level=12]
setblock 494 148 238 minecraft:light[level=12]
setblock 494 148 245 minecraft:light[level=12]
setblock 494 148 259 minecraft:light[level=12]
setblock 494 148 266 minecraft:light[level=12]
setblock 497 148 231 minecraft:light[level=15]
setblock 497 148 239 minecraft:light[level=15]
setblock 497 148 255 minecraft:light[level=15]
setblock 497 148 263 minecraft:light[level=15]
setblock 501 148 231 minecraft:light[level=12]
setblock 501 148 238 minecraft:light[level=12]
setblock 501 148 245 minecraft:light[level=12]
setblock 501 148 252 minecraft:light[level=12]
setblock 501 148 259 minecraft:light[level=12]
setblock 501 148 266 minecraft:light[level=12]
setblock 505 148 231 minecraft:light[level=15]
setblock 505 148 239 minecraft:light[level=15]
setblock 505 148 247 minecraft:light[level=15]
setblock 505 148 255 minecraft:light[level=15]
setblock 505 148 263 minecraft:light[level=15]
setblock 507 148 230 minecraft:red_concrete
setblock 507 148 266 minecraft:red_concrete
fill 508 148 229 508 152 230 minecraft:white_concrete
setblock 508 148 238 minecraft:light[level=12]
setblock 508 148 245 minecraft:light[level=12]
setblock 508 148 252 minecraft:light[level=12]
setblock 508 148 259 minecraft:light[level=12]
fill 508 148 265 508 152 266 minecraft:white_concrete
setblock 510 148 232 minecraft:white_concrete
fill 510 148 233 510 152 233 minecraft:red_concrete
setblock 510 148 268 minecraft:white_concrete
fill 510 148 269 510 152 269 minecraft:red_concrete
fill 471 149 230 471 153 230 minecraft:white_concrete
fill 471 149 266 471 153 266 minecraft:white_concrete
fill 474 149 232 475 152 232 minecraft:red_concrete
fill 474 149 268 475 152 268 minecraft:red_concrete
fill 507 149 230 507 153 230 minecraft:white_concrete
fill 507 149 266 507 153 266 minecraft:white_concrete
fill 510 149 232 511 152 232 minecraft:red_concrete
fill 510 149 268 511 152 268 minecraft:red_concrete
fill 471 150 231 471 154 232 minecraft:white_concrete
fill 471 150 267 471 154 268 minecraft:white_concrete
fill 472 150 231 472 154 231 minecraft:white_concrete
setblock 472 150 232 minecraft:red_concrete
fill 472 150 267 472 154 267 minecraft:white_concrete
setblock 472 150 268 minecraft:red_concrete
fill 473 150 231 475 154 231 minecraft:red_concrete
fill 473 150 267 475 154 267 minecraft:red_concrete
fill 495 150 251 495 194 251 minecraft:white_concrete
fill 507 150 231 507 154 232 minecraft:white_concrete
fill 507 150 267 507 154 268 minecraft:white_concrete
fill 508 150 231 508 154 231 minecraft:white_concrete
setblock 508 150 232 minecraft:red_concrete
fill 508 150 267 508 154 267 minecraft:white_concrete
setblock 508 150 268 minecraft:red_concrete
fill 509 150 231 511 154 231 minecraft:red_concrete
fill 509 150 267 511 154 267 minecraft:red_concrete
fill 472 151 232 472 155 233 minecraft:white_concrete
fill 472 151 268 472 155 269 minecraft:white_concrete
setblock 473 151 233 minecraft:red_concrete
setblock 473 151 269 minecraft:red_concrete
setblock 474 151 229 minecraft:white_concrete
fill 474 151 230 475 154 230 minecraft:red_concrete
setblock 474 151 265 minecraft:white_concrete
fill 474 151 266 475 154 266 minecraft:red_concrete
fill 508 151 232 508 155 233 minecraft:white_concrete
fill 508 151 268 508 155 269 minecraft:white_concrete
setblock 509 151 233 minecraft:red_concrete
setblock 509 151 269 minecraft:red_concrete
setblock 510 151 229 minecraft:white_concrete
fill 510 151 230 511 154 230 minecraft:red_concrete
setblock 510 151 265 minecraft:white_concrete
fill 510 151 266 511 154 266 minecraft:red_concrete
fill 473 152 229 473 156 230 minecraft:red_concrete
fill 473 152 232 473 156 233 minecraft:white_concrete
fill 473 152 265 473 156 266 minecraft:red_concrete
fill 473 152 268 473 156 269 minecraft:white_concrete
fill 474 152 229 474 155 229 minecraft:red_concrete
fill 474 152 265 474 155 265 minecraft:red_concrete
fill 509 152 229 509 156 230 minecraft:red_concrete
fill 509 152 232 509 156 233 minecraft:white_concrete
fill 509 152 265 509 156 266 minecraft:red_concrete
fill 509 152 268 509 156 269 minecraft:white_concrete
fill 510 152 229 510 155 229 minecraft:red_concrete
fill 510 152 265 510 155 265 minecraft:red_concrete
fill 472 153 229 472 157 229 minecraft:red_concrete
setblock 472 153 230 minecraft:white_concrete
fill 472 153 265 472 157 265 minecraft:red_concrete
setblock 472 153 266 minecraft:white_concrete
fill 474 153 232 474 157 233 minecraft:white_concrete
fill 474 153 268 474 157 269 minecraft:white_concrete
setblock 475 153 232 minecraft:red_concrete
setblock 475 153 268 minecraft:red_concrete
fill 487 153 235 488 154 236 minecraft:yellow_concrete
fill 494 153 250 494 194 250 minecraft:white_concrete
fill 508 153 229 508 157 229 minecraft:red_concrete
setblock 508 153 230 minecraft:white_concrete
fill 508 153 265 508 157 265 minecraft:red_concrete
setblock 508 153 266 minecraft:white_concrete
fill 510 153 232 510 157 233 minecraft:white_concrete
fill 510 153 268 510 157 269 minecraft:white_concrete
setblock 511 153 232 minecraft:red_concrete
setblock 511 153 268 minecraft:red_concrete
fill 471 154 230 472 157 230 minecraft:red_concrete
fill 471 154 266 472 157 266 minecraft:red_concrete
setblock 473 154 238 minecraft:light[level=12]
setblock 473 154 245 minecraft:light[level=12]
setblock 473 154 252 minecraft:light[level=12]
setblock 473 154 259 minecraft:light[level=12]
fill 475 154 232 475 158 232 minecraft:white_concrete
fill 475 154 268 475 158 268 minecraft:white_concrete
setblock 480 154 231 minecraft:light[level=12]
setblock 480 154 238 minecraft:light[level=12]
setblock 480 154 245 minecraft:light[level=12]
setblock 480 154 252 minecraft:light[level=12]
setblock 480 154 259 minecraft:light[level=12]
setblock 480 154 266 minecraft:light[level=12]
setblock 487 154 231 minecraft:light[level=12]
setblock 487 154 245 minecraft:light[level=12]
setblock 487 154 252 minecraft:light[level=12]
setblock 487 154 259 minecraft:light[level=12]
setblock 487 154 266 minecraft:light[level=12]
setblock 494 154 231 minecraft:light[level=12]
setblock 494 154 238 minecraft:light[level=12]
setblock 494 154 245 minecraft:light[level=12]
setblock 494 154 259 minecraft:light[level=12]
setblock 494 154 266 minecraft:light[level=12]
setblock 501 154 231 minecraft:light[level=12]
setblock 501 154 238 minecraft:light[level=12]
setblock 501 154 245 minecraft:light[level=12]
setblock 501 154 252 minecraft:light[level=12]
setblock 501 154 259 minecraft:light[level=12]
setblock 501 154 266 minecraft:light[level=12]
fill 507 154 230 508 157 230 minecraft:red_concrete
fill 507 154 266 508 157 266 minecraft:red_concrete
setblock 508 154 238 minecraft:light[level=12]
setblock 508 154 245 minecraft:light[level=12]
setblock 508 154 252 minecraft:light[level=12]
setblock 508 154 259 minecraft:light[level=12]
fill 511 154 232 511 158 232 minecraft:white_concrete
fill 511 154 268 511 158 268 minecraft:white_concrete
fill 471 155 231 472 159 231 minecraft:red_concrete
setblock 471 155 232 minecraft:white_concrete
fill 471 155 267 472 159 267 minecraft:red_concrete
setblock 471 155 268 minecraft:white_concrete
fill 473 155 231 475 159 231 minecraft:white_concrete
setblock 473 155 239 minecraft:light[level=15]
setblock 473 155 247 minecraft:light[level=15]
setblock 473 155 255 minecraft:light[level=15]
setblock 473 155 263 minecraft:light[level=15]
fill 473 155 267 475 159 267 minecraft:white_concrete
setblock 474 155 230 minecraft:red_concrete
setblock 474 155 266 minecraft:red_concrete
fill 475 155 230 475 159 230 minecraft:white_concrete
fill 475 155 266 475 160 266 minecraft:white_concrete
setblock 481 155 231 minecraft:light[level=15]
setblock 481 155 239 minecraft:light[level=15]
setblock 481 155 247 minecraft:light[level=15]
setblock 481 155 255 minecraft:light[level=15]
setblock 481 155 263 minecraft:light[level=15]
setblock 489 155 231 minecraft:light[level=15]
setblock 489 155 247 minecraft:light[level=15]
setblock 489 155 255 minecraft:light[level=15]
setblock 489 155 263 minecraft:light[level=15]
setblock 497 155 231 minecraft:light[level=15]
setblock 497 155 239 minecraft:light[level=15]
setblock 497 155 255 minecraft:light[level=15]
setblock 497 155 263 minecraft:light[level=15]
fill 501 155 243 502 156 244 minecraft:light_blue_concrete
setblock 505 155 231 minecraft:light[level=15]
setblock 505 155 239 minecraft:light[level=15]
setblock 505 155 247 minecraft:light[level=15]
setblock 505 155 255 minecraft:light[level=15]
setblock 505 155 263 minecraft:light[level=15]
fill 507 155 231 508 159 231 minecraft:red_concrete
setblock 507 155 232 minecraft:white_concrete
fill 507 155 267 508 159 267 minecraft:red_concrete
setblock 507 155 268 minecraft:white_concrete
fill 509 155 231 511 159 231 minecraft:white_concrete
fill 509 155 267 511 159 267 minecraft:white_concrete
setblock 510 155 230 minecraft:red_concrete
setblock 510 155 266 minecraft:red_concrete
fill 511 155 230 511 159 230 minecraft:white_concrete
fill 511 155 266 511 159 266 minecraft:white_concrete
fill 471 156 232 472 159 232 minecraft:red_concrete
fill 471 156 268 472 159 268 minecraft:red_concrete
setblock 472 156 233 minecraft:white_concrete
setblock 472 156 269 minecraft:white_concrete
fill 474 156 229 474 159 230 minecraft:white_concrete
fill 474 156 265 474 160 266 minecraft:white_concrete
fill 507 156 232 508 159 232 minecraft:red_concrete
fill 507 156 268 508 159 268 minecraft:red_concrete
setblock 508 156 233 minecraft:white_concrete
setblock 508 156 269 minecraft:white_concrete
fill 510 156 229 510 159 230 minecraft:white_concrete
fill 510 156 265 510 159 266 minecraft:white_concrete
fill 472 157 233 473 159 233 minecraft:red_concrete
fill 472 157 269 473 159 269 minecraft:red_concrete
fill 473 157 229 473 159 230 minecraft:white_concrete
fill 473 157 232 473 159 232 minecraft:red_concrete
fill 473 157 265 473 159 266 minecraft:white_concrete
fill 473 157 268 473 159 268 minecraft:red_concrete
fill 496 157 251 496 194 251 minecraft:white_concrete
fill 508 157 233 509 159 233 minecraft:red_concrete
fill 508 157 269 509 159 269 minecraft:red_concrete
fill 509 157 229 509 159 230 minecraft:white_concrete
fill 509 157 232 509 159 232 minecraft:red_concrete
fill 509 157 265 509 159 266 minecraft:white_concrete
fill 509 157 268 509 159 268 minecraft:red_concrete
setblock 471 158 230 minecraft:red_concrete
setblock 471 158 266 minecraft:red_concrete
fill 472 158 229 472 159 230 minecraft:white_concrete
fill 472 158 265 472 159 266 minecraft:white_concrete
setblock 474 158 232 minecraft:white_concrete
fill 474 158 233 474 162 233 minecraft:red_concrete
setblock 474 158 268 minecraft:white_concrete
fill 474 158 269 474 159 269 minecraft:red_concrete
fill 505 158 258 505 159 259 minecraft:light_blue_concrete
setblock 507 158 230 minecraft:red_concrete
setblock 507 158 266 minecraft:red_concrete
fill 508 158 229 508 159 230 minecraft:white_concrete
fill 508 158 265 508 162 266 minecraft:white_concrete
setblock 510 158 232 minecraft:white_concrete
fill 510 158 233 510 159 233 minecraft:red_concrete
setblock 510 158 268 minecraft:white_concrete
fill 510 158 269 510 159 269 minecraft:red_concrete
setblock 471 159 230 minecraft:white_concrete
setblock 471 159 266 minecraft:white_concrete
fill 474 159 232 475 162 232 minecraft:red_concrete
fill 474 159 268 475 159 268 minecraft:red_concrete
fill 497 159 251 497 194 251 minecraft:white_concrete
setblock 507 159 230 minecraft:white_concrete
fill 507 159 266 507 163 266 minecraft:white_concrete
fill 510 159 232 511 159 232 minecraft:red_concrete
fill 510 159 268 511 159 268 minecraft:red_concrete
fill 471 160 229 473 160 269 minecraft:black_concrete
fill 474 160 229 511 160 231 minecraft:black_concrete
fill 474 160 267 511 160 269 minecraft:black_concrete
setblock 480 160 238 minecraft:light[level=12]
setblock 480 160 245 minecraft:light[level=12]
setblock 480 160 252 minecraft:light[level=12]
setblock 480 160 259 minecraft:light[level=12]
setblock 480 160 266 minecraft:light[level=12]
setblock 487 160 245 minecraft:light[level=12]
setblock 487 160 252 minecraft:light[level=12]
setblock 487 160 259 minecraft:light[level=12]
setblock 487 160 266 minecraft:light[level=12]
setblock 494 160 238 minecraft:light[level=12]
setblock 494 160 245 minecraft:light[level=12]
setblock 494 160 259 minecraft:light[level=12]
setblock 494 160 266 minecraft:light[level=12]
setblock 501 160 238 minecraft:light[level=12]
setblock 501 160 245 minecraft:light[level=12]
setblock 501 160 252 minecraft:light[level=12]
setblock 501 160 259 minecraft:light[level=12]
setblock 501 160 266 minecraft:light[level=12]
fill 507 160 232 507 165 232 minecraft:white_concrete
fill 508 160 232 508 160 233 minecraft:red_concrete
setblock 508 160 238 minecraft:light[level=12]
setblock 508 160 245 minecraft:light[level=12]
setblock 508 160 252 minecraft:light[level=12]
setblock 508 160 259 minecraft:light[level=12]
fill 509 160 232 511 160 266 minecraft:black_concrete
fill 471 161 229 473 161 269 minecraft:gray_concrete
fill 474 161 229 511 161 231 minecraft:gray_concrete
fill 474 161 242 475 161 246 minecraft:orange_terracotta
setblock 474 161 265 minecraft:white_concrete
fill 474 161 266 475 164 266 minecraft:red_concrete
fill 474 161 267 511 161 269 minecraft:gray_concrete
fill 475 161 241 480 161 241 minecraft:orange_terracotta
fill 475 161 247 479 161 247 minecraft:orange_terracotta
fill 476 161 240 478 161 240 minecraft:orange_terracotta
fill 476 161 242 476 161 243 minecraft:orange_terracotta
fill 476 161 245 480 161 246 minecraft:orange_terracotta
fill 477 161 242 480 161 242 minecraft:orange_terracotta
fill 479 161 243 481 161 244 minecraft:orange_terracotta
fill 508 161 232 508 165 233 minecraft:white_concrete
fill 509 161 232 511 161 266 minecraft:gray_concrete
fill 471 162 230 472 163 232 minecraft:white_concrete
setblock 471 162 250 minecraft:yellow_concrete
fill 471 162 266 472 163 268 minecraft:white_concrete
setblock 472 162 229 minecraft:white_concrete
fill 472 162 233 473 166 233 minecraft:white_concrete
fill 472 162 258 472 163 258 minecraft:brown_concrete
setblock 472 162 265 minecraft:yellow_concrete
fill 472 162 269 473 166 269 minecraft:white_concrete
fill 473 162 229 474 164 231 minecraft:red_concrete
fill 473 162 232 473 166 232 minecraft:white_concrete
setblock 473 162 239 minecraft:light[level=15]
setblock 473 162 247 minecraft:light[level=15]
setblock 473 162 255 minecraft:light[level=15]
setblock 473 162 260 minecraft:orange_concrete
setblock 473 162 263 minecraft:light[level=15]
fill 473 162 265 473 163 267 minecraft:red_concrete
fill 473 162 268 473 166 268 minecraft:white_concrete
fill 474 162 242 475 162 246 minecraft:white_concrete
fill 474 162 265 474 163 265 minecraft:red_concrete
fill 474 162 267 474 162 269 minecraft:red_concrete
fill 475 162 230 475 164 231 minecraft:red_concrete
fill 475 162 241 480 162 241 minecraft:white_concrete
fill 475 162 247 479 162 247 minecraft:white_concrete
fill 475 162 267 475 163 268 minecraft:red_concrete
fill 476 162 240 478 162 240 minecraft:white_concrete
fill 476 162 242 476 162 243 minecraft:white_concrete
fill 476 162 245 480 162 246 minecraft:white_concrete
fill 477 162 242 480 162 242 minecraft:white_concrete
fill 479 162 243 481 162 244 minecraft:white_concrete
setblock 480 162 229 minecraft:lime_concrete
setblock 481 162 231 minecraft:light[level=15]
setblock 481 162 239 minecraft:light[level=15]
setblock 481 162 247 minecraft:light[level=15]
setblock 481 162 255 minecraft:light[level=15]
setblock 481 162 263 minecraft:light[level=15]
setblock 482 162 267 minecraft:white_concrete
setblock 486 162 230 minecraft:lime_concrete
setblock 489 162 231 minecraft:light[level=15]
setblock 489 162 247 minecraft:light[level=15]
setblock 489 162 255 minecraft:light[level=15]
setblock 489 162 263 minecraft:light[level=15]
fill 491 162 269 491 163 269 minecraft:brown_concrete
setblock 493 162 231 minecraft:magenta_concrete
setblock 497 162 231 minecraft:light[level=15]
setblock 497 162 239 minecraft:light[level=15]
setblock 497 162 255 minecraft:light[level=15]
setblock 497 162 263 minecraft:light[level=15]
setblock 499 162 269 minecraft:white_concrete
setblock 505 162 231 minecraft:light[level=15]
setblock 505 162 239 minecraft:light[level=15]
setblock 505 162 247 minecraft:light[level=15]
setblock 505 162 255 minecraft:light[level=15]
setblock 505 162 263 minecraft:light[level=15]
fill 506 162 268 506 163 268 minecraft:brown_concrete
fill 507 162 230 508 163 231 minecraft:white_concrete
fill 507 162 267 508 164 268 minecraft:white_concrete
setblock 508 162 229 minecraft:white_concrete
fill 508 162 269 509 166 269 minecraft:white_concrete
fill 509 162 229 510 164 231 minecraft:red_concrete
fill 509 162 232 509 166 233 minecraft:white_concrete
fill 509 162 262 509 163 262 minecraft:brown_concrete
fill 509 162 265 510 163 267 minecraft:red_concrete
fill 509 162 268 509 166 268 minecraft:white_concrete
fill 510 162 232 510 162 233 minecraft:red_concrete
setblock 510 162 257 minecraft:yellow_concrete
fill 510 162 268 510 162 269 minecraft:red_concrete
fill 511 162 230 511 163 232 minecraft:red_concrete
setblock 511 162 234 minecraft:yellow_concrete
setblock 511 162 256 minecraft:yellow_concrete
setblock 511 162 257 minecraft:white_concrete
fill 511 162 266 511 163 268 minecraft:red_concrete
fill 470 163 264 511 166 264 minecraft:brown_terracotta
fill 470 163 265 470 163 266 minecraft:white_concrete
fill 472 163 229 472 167 229 minecraft:red_concrete
setblock 472 163 265 minecraft:red_concrete
fill 474 163 232 474 167 233 minecraft:white_concrete
fill 474 163 267 474 164 267 minecraft:red_concrete
fill 474 163 268 474 167 269 minecraft:white_concrete
setblock 475 163 232 minecraft:red_concrete
fill 508 163 229 508 167 229 minecraft:red_concrete
setblock 508 163 265 minecraft:red_concrete
setblock 508 163 266 minecraft:white_concrete
fill 510 163 232 510 167 233 minecraft:white_concrete
fill 510 163 268 510 167 269 minecraft:white_concrete
fill 470 164 261 470 308 262 minecraft:lime_terracotta
fill 470 164 263 511 165 263 minecraft:brown_terracotta
fill 470 164 265 511 165 265 minecraft:brown_terracotta
fill 470 164 266 470 308 266 minecraft:white_concrete
fill 471 164 230 472 167 230 minecraft:red_concrete
fill 471 164 231 472 164 232 minecraft:white_concrete
fill 471 164 266 473 166 266 minecraft:red_concrete
fill 471 164 267 472 164 268 minecraft:white_concrete
setblock 473 164 267 minecraft:red_concrete
fill 475 164 232 475 168 232 minecraft:white_concrete
setblock 475 164 267 minecraft:red_concrete
fill 475 164 268 475 168 268 minecraft:white_concrete
fill 507 164 230 508 167 230 minecraft:red_concrete
fill 507 164 231 508 164 231 minecraft:white_concrete
fill 507 164 266 511 164 266 minecraft:red_concrete
fill 509 164 267 511 164 267 minecraft:red_concrete
fill 511 164 230 511 164 231 minecraft:red_concrete
fill 511 164 232 511 168 232 minecraft:white_concrete
fill 511 164 268 511 168 268 minecraft:white_concrete
fill 512 164 264 512 165 264 minecraft:brown_terracotta
fill 512 164 265 512 308 266 minecraft:white_concrete
fill 471 165 231 472 169 231 minecraft:red_concrete
fill 471 165 232 472 165 232 minecraft:white_concrete
fill 471 165 267 472 169 267 minecraft:red_concrete
fill 471 165 268 472 165 268 minecraft:white_concrete
fill 473 165 229 474 165 230 minecraft:red_concrete
fill 473 165 231 475 169 231 minecraft:white_concrete
fill 473 165 267 475 169 267 minecraft:white_concrete
setblock 474 165 266 minecraft:red_concrete
fill 475 165 230 475 170 230 minecraft:white_concrete
fill 475 165 266 475 170 266 minecraft:white_concrete
fill 494 165 234 494 166 234 minecraft:lime_concrete
fill 507 165 231 508 169 231 minecraft:red_concrete
schedule function dropper:buildpart/58_2 1t
