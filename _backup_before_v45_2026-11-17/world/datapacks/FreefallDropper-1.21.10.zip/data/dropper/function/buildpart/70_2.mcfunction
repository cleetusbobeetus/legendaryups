setblock 505 35 279 minecraft:cobbled_deepslate
fill 505 35 315 505 38 315 minecraft:deepslate_tiles
setblock 506 35 278 minecraft:cobbled_deepslate
setblock 506 35 279 minecraft:deepslate_tiles
setblock 507 35 277 minecraft:cobbled_deepslate
fill 507 35 278 507 36 278 minecraft:deepslate_tiles
setblock 508 35 276 minecraft:cobbled_deepslate
fill 508 35 277 508 36 277 minecraft:deepslate_tiles
fill 508 35 306 508 47 306 minecraft:white_wool
setblock 508 35 316 minecraft:cobbled_deepslate
fill 509 35 276 509 37 276 minecraft:deepslate_tiles
setblock 509 35 304 minecraft:deepslate_tiles
setblock 509 35 305 minecraft:cobbled_deepslate
setblock 509 35 306 minecraft:deepslate_tiles
setblock 509 35 315 minecraft:cobbled_deepslate
fill 509 35 316 509 37 316 minecraft:deepslate_tiles
setblock 510 35 279 minecraft:cobbled_deepslate
setblock 510 35 280 minecraft:deepslate_tiles
setblock 510 35 300 minecraft:deepslate_tiles
setblock 510 35 304 minecraft:cobbled_deepslate
fill 510 35 305 510 38 305 minecraft:deepslate_tiles
setblock 510 35 309 minecraft:cobbled_deepslate
setblock 510 35 310 minecraft:deepslate_tiles
setblock 511 35 278 minecraft:cobbled_deepslate
fill 511 35 279 511 36 279 minecraft:deepslate_tiles
setblock 511 35 283 minecraft:cobbled_deepslate
setblock 511 35 284 minecraft:deepslate_tiles
setblock 511 35 298 minecraft:cobbled_deepslate
fill 511 35 299 511 36 299 minecraft:deepslate_tiles
setblock 511 35 303 minecraft:cobbled_deepslate
fill 511 35 304 511 38 304 minecraft:deepslate_tiles
setblock 511 35 308 minecraft:cobbled_deepslate
fill 511 35 309 511 38 309 minecraft:deepslate_tiles
setblock 511 35 313 minecraft:cobbled_deepslate
setblock 511 35 314 minecraft:deepslate_tiles
setblock 471 36 297 minecraft:cobbled_deepslate
fill 471 36 298 471 37 298 minecraft:deepslate_tiles
setblock 471 36 302 minecraft:cobbled_deepslate
fill 471 36 303 471 39 303 minecraft:deepslate_tiles
setblock 471 36 307 minecraft:cobbled_deepslate
fill 471 36 308 471 39 308 minecraft:deepslate_tiles
setblock 472 36 301 minecraft:cobbled_deepslate
fill 472 36 302 472 37 302 minecraft:deepslate_tiles
setblock 472 36 306 minecraft:cobbled_deepslate
setblock 472 36 307 minecraft:deepslate_tiles
setblock 482 36 276 minecraft:cobbled_deepslate
setblock 482 36 277 minecraft:deepslate_tiles
fill 483 36 276 483 39 276 minecraft:deepslate_tiles
setblock 485 36 278 minecraft:cobbled_deepslate
setblock 486 36 277 minecraft:cobbled_deepslate
setblock 486 36 278 minecraft:deepslate_tiles
setblock 487 36 276 minecraft:cobbled_deepslate
setblock 487 36 277 minecraft:deepslate_tiles
fill 488 36 276 488 37 276 minecraft:deepslate_tiles
setblock 492 36 276 minecraft:cobbled_deepslate
setblock 493 36 276 minecraft:deepslate_tiles
fill 496 36 277 496 38 277 minecraft:cobbled_deepslate
setblock 497 36 276 minecraft:cobbled_deepslate
setblock 497 36 277 minecraft:deepslate_tiles
fill 498 36 276 498 39 276 minecraft:deepslate_tiles
setblock 500 36 278 minecraft:cobbled_deepslate
setblock 501 36 277 minecraft:cobbled_deepslate
fill 501 36 278 501 37 278 minecraft:deepslate_tiles
setblock 502 36 276 minecraft:cobbled_deepslate
fill 502 36 277 502 39 277 minecraft:deepslate_tiles
setblock 502 36 316 minecraft:cobbled_deepslate
fill 503 36 276 503 39 276 minecraft:deepslate_tiles
setblock 503 36 315 minecraft:cobbled_deepslate
fill 503 36 316 503 39 316 minecraft:deepslate_tiles
setblock 504 36 279 minecraft:cobbled_deepslate
fill 504 36 315 504 39 315 minecraft:deepslate_tiles
setblock 504 36 317 minecraft:white_wool
setblock 505 36 278 minecraft:cobbled_deepslate
setblock 506 36 277 minecraft:cobbled_deepslate
setblock 506 36 278 minecraft:deepslate_tiles
setblock 507 36 275 minecraft:white_wool
setblock 507 36 276 minecraft:cobbled_deepslate
fill 507 36 277 507 37 277 minecraft:deepslate_tiles
setblock 507 36 316 minecraft:cobbled_deepslate
fill 508 36 276 508 37 276 minecraft:deepslate_tiles
fill 508 36 316 508 38 316 minecraft:deepslate_tiles
setblock 510 36 303 minecraft:cobbled_deepslate
fill 510 36 304 510 38 304 minecraft:deepslate_tiles
setblock 510 36 308 minecraft:cobbled_deepslate
fill 510 36 309 510 37 309 minecraft:deepslate_tiles
setblock 511 36 277 minecraft:cobbled_deepslate
setblock 511 36 278 minecraft:deepslate_tiles
setblock 511 36 282 minecraft:cobbled_deepslate
setblock 511 36 283 minecraft:deepslate_tiles
setblock 511 36 302 minecraft:cobbled_deepslate
fill 511 36 303 511 39 303 minecraft:deepslate_tiles
setblock 511 36 307 minecraft:cobbled_deepslate
fill 511 36 308 511 39 308 minecraft:deepslate_tiles
setblock 511 36 312 minecraft:cobbled_deepslate
setblock 511 36 313 minecraft:deepslate_tiles
setblock 471 37 301 minecraft:cobbled_deepslate
fill 471 37 302 471 40 302 minecraft:deepslate_tiles
setblock 471 37 306 minecraft:cobbled_deepslate
fill 471 37 307 471 40 307 minecraft:deepslate_tiles
setblock 472 37 301 minecraft:deepslate_tiles
setblock 472 37 305 minecraft:cobbled_deepslate
fill 472 37 306 472 38 306 minecraft:deepslate_tiles
setblock 473 37 278 minecraft:light[level=13]
setblock 473 37 285 minecraft:light[level=12]
setblock 473 37 286 minecraft:light[level=13]
setblock 473 37 292 minecraft:light[level=12]
setblock 473 37 294 minecraft:light[level=13]
setblock 473 37 299 minecraft:light[level=12]
setblock 473 37 302 minecraft:light[level=13]
setblock 473 37 306 minecraft:light[level=12]
setblock 473 37 310 minecraft:light[level=13]
setblock 473 37 313 minecraft:light[level=12]
setblock 480 37 278 minecraft:light[level=12]
setblock 480 37 285 minecraft:light[level=12]
setblock 480 37 292 minecraft:light[level=12]
setblock 480 37 299 minecraft:light[level=12]
setblock 480 37 306 minecraft:light[level=12]
setblock 480 37 313 minecraft:light[level=12]
setblock 481 37 276 minecraft:cobbled_deepslate
setblock 481 37 278 minecraft:light[level=13]
setblock 481 37 286 minecraft:light[level=13]
setblock 481 37 294 minecraft:light[level=13]
setblock 481 37 302 minecraft:light[level=13]
setblock 481 37 310 minecraft:light[level=13]
fill 482 37 276 482 38 276 minecraft:deepslate_tiles
setblock 485 37 277 minecraft:cobbled_deepslate
setblock 486 37 276 minecraft:cobbled_deepslate
setblock 486 37 277 minecraft:deepslate_tiles
fill 487 37 276 487 38 276 minecraft:deepslate_tiles
setblock 487 37 278 minecraft:light[level=12]
setblock 487 37 285 minecraft:light[level=12]
setblock 487 37 292 minecraft:light[level=12]
setblock 487 37 299 minecraft:light[level=12]
setblock 487 37 306 minecraft:light[level=12]
setblock 487 37 313 minecraft:light[level=12]
setblock 489 37 278 minecraft:light[level=13]
setblock 489 37 286 minecraft:light[level=13]
setblock 489 37 294 minecraft:light[level=13]
setblock 489 37 302 minecraft:light[level=13]
setblock 489 37 310 minecraft:light[level=13]
setblock 494 37 278 minecraft:light[level=12]
setblock 494 37 285 minecraft:light[level=12]
setblock 494 37 292 minecraft:light[level=12]
setblock 494 37 299 minecraft:light[level=12]
setblock 494 37 306 minecraft:light[level=12]
setblock 494 37 313 minecraft:light[level=12]
setblock 496 37 276 minecraft:cobbled_deepslate
fill 496 37 278 496 38 278 minecraft:cobbled_deepslate
fill 497 37 276 497 40 276 minecraft:deepslate_tiles
fill 497 37 277 497 38 277 minecraft:cobbled_deepslate
setblock 497 37 286 minecraft:light[level=13]
setblock 497 37 294 minecraft:light[level=13]
setblock 497 37 302 minecraft:light[level=13]
setblock 497 37 310 minecraft:light[level=13]
fill 498 37 278 498 38 278 minecraft:cobbled_deepslate
setblock 500 37 277 minecraft:cobbled_deepslate
setblock 500 37 278 minecraft:deepslate_tiles
setblock 501 37 276 minecraft:cobbled_deepslate
fill 501 37 277 501 40 277 minecraft:deepslate_tiles
setblock 501 37 285 minecraft:light[level=12]
setblock 501 37 292 minecraft:light[level=12]
setblock 501 37 299 minecraft:light[level=12]
setblock 501 37 306 minecraft:light[level=12]
setblock 501 37 313 minecraft:light[level=12]
setblock 501 37 316 minecraft:cobbled_deepslate
fill 502 37 276 502 40 276 minecraft:deepslate_tiles
setblock 502 37 315 minecraft:cobbled_deepslate
fill 502 37 316 502 40 316 minecraft:deepslate_tiles
fill 503 37 315 503 40 315 minecraft:deepslate_tiles
setblock 504 37 278 minecraft:cobbled_deepslate
fill 504 37 317 504 94 317 minecraft:cobbled_deepslate
setblock 505 37 277 minecraft:cobbled_deepslate
setblock 505 37 278 minecraft:deepslate_tiles
setblock 505 37 286 minecraft:light[level=13]
setblock 505 37 294 minecraft:light[level=13]
setblock 505 37 302 minecraft:light[level=13]
setblock 505 37 310 minecraft:light[level=13]
setblock 506 37 276 minecraft:cobbled_deepslate
setblock 506 37 277 minecraft:deepslate_tiles
setblock 506 37 316 minecraft:cobbled_deepslate
fill 507 37 275 507 91 275 minecraft:cobbled_deepslate
fill 507 37 276 507 38 276 minecraft:deepslate_tiles
fill 507 37 316 507 40 316 minecraft:deepslate_tiles
setblock 508 37 278 minecraft:light[level=12]
setblock 508 37 285 minecraft:light[level=12]
setblock 508 37 292 minecraft:light[level=12]
setblock 508 37 299 minecraft:light[level=12]
setblock 508 37 313 minecraft:light[level=12]
setblock 510 37 303 minecraft:deepslate_tiles
setblock 510 37 307 minecraft:cobbled_deepslate
fill 510 37 308 510 40 308 minecraft:deepslate_tiles
setblock 511 37 301 minecraft:cobbled_deepslate
fill 511 37 302 511 39 302 minecraft:deepslate_tiles
setblock 511 37 306 minecraft:cobbled_deepslate
fill 511 37 307 511 40 307 minecraft:deepslate_tiles
setblock 511 37 311 minecraft:cobbled_deepslate
setblock 471 38 300 minecraft:cobbled_deepslate
fill 471 38 301 471 40 301 minecraft:deepslate_tiles
setblock 471 38 305 minecraft:cobbled_deepslate
fill 471 38 306 471 41 306 minecraft:deepslate_tiles
setblock 472 38 304 minecraft:cobbled_deepslate
fill 472 38 305 472 39 305 minecraft:deepslate_tiles
setblock 485 38 276 minecraft:cobbled_deepslate
setblock 486 38 276 minecraft:deepslate_tiles
fill 487 38 287 487 39 287 minecraft:white_wool
fill 494 38 275 494 94 275 minecraft:cobbled_deepslate
setblock 495 38 275 minecraft:white_wool
fill 496 38 275 497 94 275 minecraft:cobbled_deepslate
setblock 496 38 276 minecraft:deepslate_tiles
setblock 499 38 277 minecraft:cobbled_deepslate
setblock 500 38 276 minecraft:cobbled_deepslate
fill 500 38 277 500 41 277 minecraft:deepslate_tiles
setblock 500 38 316 minecraft:cobbled_deepslate
fill 501 38 276 501 41 276 minecraft:deepslate_tiles
fill 501 38 316 501 41 316 minecraft:deepslate_tiles
setblock 504 38 277 minecraft:cobbled_deepslate
setblock 505 38 276 minecraft:cobbled_deepslate
setblock 505 38 277 minecraft:deepslate_tiles
setblock 505 38 316 minecraft:cobbled_deepslate
fill 506 38 276 506 39 276 minecraft:deepslate_tiles
fill 506 38 316 506 41 316 minecraft:deepslate_tiles
setblock 510 38 306 minecraft:cobbled_deepslate
fill 510 38 307 510 41 307 minecraft:deepslate_tiles
setblock 511 38 301 minecraft:deepslate_tiles
setblock 511 38 305 minecraft:cobbled_deepslate
fill 511 38 306 511 41 306 minecraft:deepslate_tiles
setblock 511 38 310 minecraft:cobbled_deepslate
fill 511 38 311 511 41 311 minecraft:deepslate_tiles
fill 470 39 288 470 61 295 minecraft:cobbled_deepslate
setblock 470 39 296 minecraft:white_wool
fill 470 39 297 470 94 297 minecraft:cobbled_deepslate
setblock 470 39 311 minecraft:redstone_block
setblock 471 39 300 minecraft:deepslate_tiles
setblock 471 39 304 minecraft:cobbled_deepslate
fill 471 39 305 471 42 305 minecraft:deepslate_tiles
setblock 471 39 309 minecraft:cobbled_deepslate
setblock 484 39 276 minecraft:cobbled_deepslate
setblock 485 39 276 minecraft:deepslate_tiles
fill 495 39 275 495 66 275 minecraft:cobbled_deepslate
setblock 499 39 276 minecraft:cobbled_deepslate
fill 499 39 277 499 42 277 minecraft:deepslate_tiles
setblock 499 39 316 minecraft:cobbled_deepslate
fill 500 39 276 500 42 276 minecraft:deepslate_tiles
fill 500 39 316 500 42 316 minecraft:deepslate_tiles
fill 502 39 315 502 41 315 minecraft:deepslate_tiles
setblock 503 39 277 minecraft:cobbled_deepslate
setblock 504 39 276 minecraft:cobbled_deepslate
setblock 504 39 277 minecraft:deepslate_tiles
setblock 504 39 316 minecraft:cobbled_deepslate
fill 505 39 276 505 41 276 minecraft:deepslate_tiles
fill 505 39 316 505 42 316 minecraft:deepslate_tiles
setblock 510 39 305 minecraft:cobbled_deepslate
fill 510 39 306 510 42 306 minecraft:deepslate_tiles
setblock 511 39 304 minecraft:cobbled_deepslate
fill 511 39 305 511 42 305 minecraft:deepslate_tiles
setblock 511 39 309 minecraft:cobbled_deepslate
fill 511 39 310 511 42 310 minecraft:deepslate_tiles
fill 470 40 296 470 94 296 minecraft:cobbled_deepslate
fill 470 40 311 470 90 311 minecraft:cobbled_deepslate
setblock 471 40 303 minecraft:cobbled_deepslate
fill 471 40 304 471 43 304 minecraft:deepslate_tiles
setblock 471 40 308 minecraft:cobbled_deepslate
fill 471 40 309 471 42 310 minecraft:deepslate_tiles
setblock 498 40 276 minecraft:cobbled_deepslate
setblock 498 40 316 minecraft:cobbled_deepslate
fill 499 40 276 499 43 276 minecraft:deepslate_tiles
fill 499 40 316 499 43 316 minecraft:deepslate_tiles
fill 501 40 315 501 42 315 minecraft:deepslate_tiles
setblock 502 40 277 minecraft:cobbled_deepslate
setblock 503 40 276 minecraft:cobbled_deepslate
setblock 503 40 277 minecraft:deepslate_tiles
setblock 503 40 316 minecraft:cobbled_deepslate
fill 504 40 276 504 43 276 minecraft:deepslate_tiles
setblock 504 40 315 minecraft:cobbled_deepslate
fill 504 40 316 504 43 316 minecraft:deepslate_tiles
fill 507 40 295 507 61 295 minecraft:white_wool
setblock 510 40 309 minecraft:cobbled_deepslate
setblock 511 40 303 minecraft:cobbled_deepslate
fill 511 40 304 511 43 304 minecraft:deepslate_tiles
setblock 511 40 308 minecraft:cobbled_deepslate
fill 511 40 309 511 43 309 minecraft:deepslate_tiles
setblock 471 41 302 minecraft:cobbled_deepslate
fill 471 41 303 471 44 303 minecraft:deepslate_tiles
setblock 471 41 307 minecraft:cobbled_deepslate
fill 471 41 308 471 44 308 minecraft:deepslate_tiles
setblock 475 41 279 minecraft:white_wool
setblock 476 41 278 minecraft:white_wool
setblock 477 41 277 minecraft:white_wool
setblock 478 41 276 minecraft:white_wool
setblock 496 41 276 minecraft:deepslate_tiles
setblock 497 41 276 minecraft:cobbled_deepslate
setblock 497 41 316 minecraft:cobbled_deepslate
setblock 498 41 275 minecraft:white_wool
fill 498 41 276 498 44 276 minecraft:deepslate_tiles
fill 498 41 316 498 44 316 minecraft:deepslate_tiles
fill 499 41 315 500 43 315 minecraft:deepslate_tiles
setblock 501 41 277 minecraft:cobbled_deepslate
setblock 502 41 276 minecraft:cobbled_deepslate
setblock 502 41 277 minecraft:deepslate_tiles
setblock 502 41 316 minecraft:cobbled_deepslate
fill 503 41 276 503 44 276 minecraft:deepslate_tiles
setblock 503 41 315 minecraft:cobbled_deepslate
fill 503 41 316 503 44 316 minecraft:deepslate_tiles
fill 504 41 315 504 44 315 minecraft:deepslate_tiles
setblock 505 41 317 minecraft:white_wool
setblock 507 41 316 minecraft:cobbled_deepslate
setblock 510 41 308 minecraft:cobbled_deepslate
fill 510 41 309 510 44 309 minecraft:deepslate_tiles
fill 511 41 303 511 44 303 minecraft:deepslate_tiles
setblock 511 41 307 minecraft:cobbled_deepslate
fill 511 41 308 511 44 308 minecraft:deepslate_tiles
setblock 511 41 312 minecraft:cobbled_deepslate
setblock 471 42 283 minecraft:white_wool
setblock 471 42 286 minecraft:cobbled_deepslate
fill 471 42 287 471 43 289 minecraft:deepslate_tiles
fill 471 42 302 471 45 302 minecraft:deepslate_tiles
setblock 471 42 306 minecraft:cobbled_deepslate
fill 471 42 307 472 44 307 minecraft:deepslate_tiles
setblock 471 42 311 minecraft:cobbled_deepslate
setblock 472 42 282 minecraft:white_wool
fill 472 42 306 472 45 306 minecraft:deepslate_tiles
setblock 473 42 281 minecraft:white_wool
setblock 474 42 280 minecraft:white_wool
setblock 481 42 276 minecraft:cobbled_deepslate
fill 482 42 276 483 44 276 minecraft:deepslate_tiles
setblock 495 42 276 minecraft:deepslate_tiles
setblock 496 42 276 minecraft:cobbled_deepslate
fill 496 42 316 496 42 317 minecraft:cobbled_deepslate
fill 497 42 276 497 45 276 minecraft:deepslate_tiles
fill 497 42 316 497 45 316 minecraft:deepslate_tiles
setblock 497 42 317 minecraft:redstone_block
fill 498 42 275 498 87 275 minecraft:cobbled_deepslate
fill 498 42 277 498 43 277 minecraft:deepslate_tiles
fill 498 42 315 498 45 315 minecraft:deepslate_tiles
fill 498 42 317 498 90 317 minecraft:cobbled_deepslate
setblock 500 42 277 minecraft:cobbled_deepslate
setblock 501 42 276 minecraft:cobbled_deepslate
fill 501 42 277 501 45 277 minecraft:deepslate_tiles
fill 501 42 314 502 42 314 minecraft:deepslate_tiles
setblock 501 42 316 minecraft:cobbled_deepslate
fill 502 42 276 502 45 276 minecraft:deepslate_tiles
setblock 502 42 315 minecraft:cobbled_deepslate
fill 502 42 316 502 45 316 minecraft:deepslate_tiles
fill 503 42 315 503 45 315 minecraft:deepslate_tiles
fill 505 42 315 505 43 315 minecraft:deepslate_tiles
fill 505 42 317 505 92 317 minecraft:cobbled_deepslate
setblock 506 42 316 minecraft:cobbled_deepslate
fill 507 42 316 507 45 316 minecraft:deepslate_tiles
setblock 510 42 307 minecraft:cobbled_deepslate
fill 510 42 308 510 45 308 minecraft:deepslate_tiles
fill 510 42 310 510 42 311 minecraft:deepslate_tiles
setblock 511 42 306 minecraft:cobbled_deepslate
fill 511 42 307 511 45 307 minecraft:deepslate_tiles
setblock 511 42 311 minecraft:cobbled_deepslate
fill 511 42 312 511 44 313 minecraft:deepslate_tiles
setblock 471 43 285 minecraft:cobbled_deepslate
fill 471 43 286 471 46 286 minecraft:deepslate_tiles
setblock 471 43 290 minecraft:cobbled_deepslate
fill 471 43 291 471 44 293 minecraft:deepslate_tiles
setblock 471 43 305 minecraft:cobbled_deepslate
fill 471 43 306 471 46 306 minecraft:deepslate_tiles
setblock 471 43 309 minecraft:deepslate_tiles
setblock 471 43 310 minecraft:cobbled_deepslate
fill 471 43 311 471 45 312 minecraft:deepslate_tiles
setblock 472 43 308 minecraft:deepslate_tiles
setblock 472 43 309 minecraft:cobbled_deepslate
setblock 473 43 278 minecraft:light[level=12]
setblock 473 43 285 minecraft:light[level=12]
setblock 473 43 292 minecraft:light[level=12]
setblock 473 43 299 minecraft:light[level=12]
setblock 473 43 306 minecraft:light[level=12]
setblock 473 43 313 minecraft:light[level=12]
setblock 479 43 276 minecraft:deepslate_tiles
setblock 480 43 276 minecraft:cobbled_deepslate
setblock 480 43 278 minecraft:light[level=12]
setblock 480 43 285 minecraft:light[level=12]
setblock 480 43 292 minecraft:light[level=12]
setblock 480 43 299 minecraft:light[level=12]
setblock 480 43 306 minecraft:light[level=12]
setblock 480 43 313 minecraft:light[level=12]
fill 481 43 276 481 46 276 minecraft:deepslate_tiles
setblock 484 43 276 minecraft:deepslate_tiles
setblock 487 43 278 minecraft:light[level=12]
setblock 487 43 285 minecraft:light[level=12]
setblock 487 43 292 minecraft:light[level=12]
setblock 487 43 299 minecraft:light[level=12]
setblock 487 43 306 minecraft:light[level=12]
setblock 487 43 313 minecraft:light[level=12]
setblock 494 43 276 minecraft:deepslate_tiles
setblock 494 43 278 minecraft:light[level=12]
setblock 494 43 285 minecraft:light[level=12]
setblock 494 43 292 minecraft:light[level=12]
setblock 494 43 299 minecraft:light[level=12]
setblock 494 43 306 minecraft:light[level=12]
setblock 494 43 313 minecraft:light[level=12]
setblock 495 43 276 minecraft:cobbled_deepslate
setblock 495 43 316 minecraft:cobbled_deepslate
fill 496 43 276 496 46 276 minecraft:deepslate_tiles
setblock 496 43 315 minecraft:cobbled_deepslate
fill 496 43 316 496 46 316 minecraft:deepslate_tiles
fill 496 43 317 497 94 317 minecraft:cobbled_deepslate
fill 497 43 277 497 44 277 minecraft:deepslate_tiles
fill 497 43 315 497 46 315 minecraft:deepslate_tiles
fill 498 43 314 501 43 314 minecraft:deepslate_tiles
setblock 499 43 277 minecraft:cobbled_deepslate
setblock 500 43 276 minecraft:cobbled_deepslate
fill 500 43 277 500 46 277 minecraft:deepslate_tiles
setblock 500 43 316 minecraft:cobbled_deepslate
fill 501 43 276 501 46 276 minecraft:deepslate_tiles
setblock 501 43 278 minecraft:light[level=12]
setblock 501 43 285 minecraft:light[level=12]
setblock 501 43 292 minecraft:light[level=12]
setblock 501 43 299 minecraft:light[level=12]
setblock 501 43 306 minecraft:light[level=12]
setblock 501 43 313 minecraft:light[level=12]
setblock 501 43 315 minecraft:cobbled_deepslate
fill 501 43 316 501 46 316 minecraft:deepslate_tiles
setblock 502 43 314 minecraft:cobbled_deepslate
fill 502 43 315 502 46 315 minecraft:deepslate_tiles
fill 503 43 314 504 45 314 minecraft:deepslate_tiles
setblock 505 43 316 minecraft:cobbled_deepslate
setblock 506 43 315 minecraft:cobbled_deepslate
fill 506 43 316 506 46 316 minecraft:deepslate_tiles
setblock 508 43 278 minecraft:light[level=12]
setblock 508 43 285 minecraft:light[level=12]
setblock 508 43 292 minecraft:light[level=12]
setblock 508 43 299 minecraft:light[level=12]
setblock 508 43 313 minecraft:light[level=12]
setblock 510 43 305 minecraft:deepslate_tiles
setblock 510 43 306 minecraft:cobbled_deepslate
fill 510 43 307 510 46 307 minecraft:deepslate_tiles
setblock 510 43 310 minecraft:deepslate_tiles
setblock 510 43 311 minecraft:cobbled_deepslate
fill 510 43 312 510 46 312 minecraft:deepslate_tiles
setblock 511 43 305 minecraft:cobbled_deepslate
fill 511 43 306 511 46 306 minecraft:deepslate_tiles
setblock 511 43 310 minecraft:cobbled_deepslate
fill 511 43 311 511 46 311 minecraft:deepslate_tiles
setblock 511 43 314 minecraft:deepslate_tiles
setblock 470 44 283 minecraft:redstone_block
fill 470 44 284 470 91 286 minecraft:cobbled_deepslate
setblock 471 44 284 minecraft:cobbled_deepslate
fill 471 44 285 471 47 285 minecraft:deepslate_tiles
fill 471 44 287 471 44 288 minecraft:deepslate_tiles
setblock 471 44 289 minecraft:cobbled_deepslate
fill 471 44 290 472 46 290 minecraft:deepslate_tiles
setblock 471 44 294 minecraft:cobbled_deepslate
fill 471 44 295 471 46 296 minecraft:deepslate_tiles
fill 471 44 301 471 46 301 minecraft:deepslate_tiles
setblock 471 44 304 minecraft:cobbled_deepslate
fill 471 44 305 472 46 305 minecraft:deepslate_tiles
setblock 471 44 309 minecraft:cobbled_deepslate
fill 471 44 310 472 46 310 minecraft:deepslate_tiles
setblock 471 44 313 minecraft:deepslate_tiles
fill 472 44 286 472 44 287 minecraft:deepslate_tiles
setblock 472 44 288 minecraft:cobbled_deepslate
fill 472 44 289 472 47 289 minecraft:deepslate_tiles
fill 472 44 291 472 44 292 minecraft:deepslate_tiles
setblock 472 44 308 minecraft:cobbled_deepslate
fill 472 44 309 472 47 309 minecraft:deepslate_tiles
fill 477 44 313 477 50 313 minecraft:black_concrete
fill 477 44 316 478 44 316 minecraft:deepslate_tiles
setblock 478 44 276 minecraft:deepslate_tiles
setblock 479 44 276 minecraft:cobbled_deepslate
setblock 479 44 316 minecraft:cobbled_deepslate
fill 480 44 276 480 47 276 minecraft:deepslate_tiles
fill 480 44 316 482 45 316 minecraft:deepslate_tiles
setblock 484 44 276 minecraft:cobbled_deepslate
fill 485 44 276 485 47 276 minecraft:deepslate_tiles
setblock 493 44 276 minecraft:deepslate_tiles
setblock 493 44 316 minecraft:deepslate_tiles
setblock 494 44 276 minecraft:cobbled_deepslate
setblock 494 44 316 minecraft:cobbled_deepslate
fill 495 44 276 495 47 276 minecraft:deepslate_tiles
setblock 495 44 315 minecraft:cobbled_deepslate
fill 495 44 316 495 47 316 minecraft:deepslate_tiles
fill 496 44 277 496 45 277 minecraft:deepslate_tiles
fill 496 44 315 496 47 315 minecraft:deepslate_tiles
fill 497 44 314 500 44 314 minecraft:deepslate_tiles
setblock 498 44 277 minecraft:cobbled_deepslate
setblock 499 44 276 minecraft:cobbled_deepslate
fill 499 44 277 499 47 277 minecraft:deepslate_tiles
fill 499 44 313 501 44 313 minecraft:deepslate_tiles
setblock 499 44 315 minecraft:deepslate_tiles
setblock 499 44 316 minecraft:cobbled_deepslate
fill 500 44 276 500 47 276 minecraft:deepslate_tiles
setblock 500 44 315 minecraft:cobbled_deepslate
fill 500 44 316 500 47 316 minecraft:deepslate_tiles
setblock 501 44 314 minecraft:cobbled_deepslate
fill 501 44 315 501 47 315 minecraft:deepslate_tiles
setblock 502 44 313 minecraft:cobbled_deepslate
fill 502 44 314 502 47 314 minecraft:deepslate_tiles
setblock 504 44 276 minecraft:cobbled_deepslate
setblock 504 44 316 minecraft:cobbled_deepslate
setblock 505 44 314 minecraft:deepslate_tiles
setblock 505 44 315 minecraft:cobbled_deepslate
fill 505 44 316 505 47 316 minecraft:deepslate_tiles
setblock 506 44 275 minecraft:redstone_block
fill 506 44 315 506 47 315 minecraft:deepslate_tiles
setblock 508 44 316 minecraft:deepslate_tiles
setblock 510 44 305 minecraft:cobbled_deepslate
fill 510 44 306 510 47 306 minecraft:deepslate_tiles
setblock 510 44 310 minecraft:cobbled_deepslate
fill 510 44 311 510 47 311 minecraft:deepslate_tiles
fill 510 44 313 510 45 313 minecraft:deepslate_tiles
fill 511 44 302 511 45 302 minecraft:deepslate_tiles
setblock 511 44 304 minecraft:cobbled_deepslate
fill 511 44 305 511 47 305 minecraft:deepslate_tiles
setblock 511 44 309 minecraft:cobbled_deepslate
fill 511 44 310 511 47 310 minecraft:deepslate_tiles
setblock 511 44 314 minecraft:cobbled_deepslate
fill 511 44 315 511 47 315 minecraft:deepslate_tiles
setblock 512 44 284 minecraft:white_wool
fill 470 45 283 470 94 283 minecraft:cobbled_deepslate
fill 471 45 284 471 48 284 minecraft:deepslate_tiles
setblock 471 45 287 minecraft:deepslate_tiles
setblock 471 45 288 minecraft:cobbled_deepslate
fill 471 45 289 471 48 289 minecraft:deepslate_tiles
fill 471 45 291 471 45 292 minecraft:deepslate_tiles
setblock 471 45 293 minecraft:cobbled_deepslate
fill 471 45 294 472 47 294 minecraft:deepslate_tiles
setblock 471 45 297 minecraft:deepslate_tiles
setblock 471 45 298 minecraft:cobbled_deepslate
fill 471 45 299 471 47 300 minecraft:deepslate_tiles
setblock 471 45 303 minecraft:cobbled_deepslate
fill 471 45 304 471 48 304 minecraft:deepslate_tiles
setblock 471 45 307 minecraft:deepslate_tiles
setblock 471 45 308 minecraft:cobbled_deepslate
fill 471 45 309 471 48 309 minecraft:deepslate_tiles
setblock 471 45 313 minecraft:cobbled_deepslate
fill 471 45 314 471 48 314 minecraft:deepslate_tiles
fill 472 45 285 472 45 286 minecraft:deepslate_tiles
setblock 472 45 287 minecraft:cobbled_deepslate
fill 472 45 288 473 47 288 minecraft:deepslate_tiles
setblock 472 45 291 minecraft:deepslate_tiles
setblock 472 45 292 minecraft:cobbled_deepslate
fill 472 45 293 472 48 293 minecraft:deepslate_tiles
fill 472 45 295 472 46 295 minecraft:deepslate_tiles
setblock 472 45 307 minecraft:cobbled_deepslate
fill 472 45 308 472 48 308 minecraft:deepslate_tiles
setblock 472 45 311 minecraft:deepslate_tiles
setblock 473 45 278 minecraft:light[level=13]
setblock 473 45 286 minecraft:light[level=13]
fill 473 45 287 473 48 287 minecraft:deepslate_tiles
fill 473 45 289 473 45 290 minecraft:deepslate_tiles
setblock 473 45 291 minecraft:cobbled_deepslate
fill 473 45 292 473 48 292 minecraft:deepslate_tiles
setblock 473 45 294 minecraft:light[level=13]
setblock 473 45 302 minecraft:light[level=13]
setblock 473 45 310 minecraft:light[level=13]
fill 475 45 316 477 45 316 minecraft:deepslate_tiles
fill 476 45 276 477 45 276 minecraft:deepslate_tiles
setblock 478 45 276 minecraft:cobbled_deepslate
setblock 478 45 315 minecraft:deepslate_tiles
setblock 478 45 316 minecraft:cobbled_deepslate
fill 479 45 276 479 48 276 minecraft:deepslate_tiles
setblock 479 45 315 minecraft:cobbled_deepslate
fill 479 45 316 479 48 316 minecraft:deepslate_tiles
fill 480 45 315 480 48 315 minecraft:deepslate_tiles
setblock 481 45 278 minecraft:light[level=13]
setblock 481 45 286 minecraft:light[level=13]
setblock 481 45 294 minecraft:light[level=13]
setblock 481 45 302 minecraft:light[level=13]
setblock 481 45 310 minecraft:light[level=13]
setblock 482 45 276 minecraft:deepslate_tiles
setblock 483 45 276 minecraft:cobbled_deepslate
setblock 483 45 316 minecraft:cobbled_deepslate
fill 484 45 276 484 48 276 minecraft:deepslate_tiles
fill 484 45 316 484 48 316 minecraft:deepslate_tiles
setblock 485 45 275 minecraft:redstone_block
fill 486 45 275 488 88 275 minecraft:cobbled_deepslate
setblock 489 45 278 minecraft:light[level=13]
setblock 489 45 286 minecraft:light[level=13]
setblock 489 45 294 minecraft:light[level=13]
setblock 489 45 302 minecraft:light[level=13]
setblock 489 45 310 minecraft:light[level=13]
fill 491 45 276 492 45 276 minecraft:deepslate_tiles
fill 491 45 316 492 45 316 minecraft:deepslate_tiles
setblock 493 45 276 minecraft:cobbled_deepslate
setblock 493 45 315 minecraft:deepslate_tiles
setblock 493 45 316 minecraft:cobbled_deepslate
fill 494 45 276 494 48 276 minecraft:deepslate_tiles
setblock 494 45 315 minecraft:cobbled_deepslate
fill 494 45 316 494 48 316 minecraft:deepslate_tiles
fill 495 45 277 495 46 277 minecraft:deepslate_tiles
setblock 495 45 314 minecraft:cobbled_deepslate
fill 495 45 315 495 48 315 minecraft:deepslate_tiles
fill 496 45 314 499 45 314 minecraft:deepslate_tiles
setblock 497 45 277 minecraft:cobbled_deepslate
setblock 497 45 278 minecraft:light[level=13]
setblock 497 45 286 minecraft:light[level=13]
setblock 497 45 294 minecraft:light[level=13]
setblock 497 45 302 minecraft:light[level=13]
setblock 497 45 310 minecraft:light[level=13]
fill 497 45 313 500 45 313 minecraft:deepslate_tiles
setblock 498 45 276 minecraft:cobbled_deepslate
fill 498 45 277 498 48 277 minecraft:deepslate_tiles
setblock 498 45 316 minecraft:cobbled_deepslate
fill 499 45 276 499 48 276 minecraft:deepslate_tiles
setblock 499 45 315 minecraft:cobbled_deepslate
fill 499 45 316 499 48 316 minecraft:deepslate_tiles
setblock 500 45 314 minecraft:cobbled_deepslate
fill 500 45 315 500 48 315 minecraft:deepslate_tiles
setblock 501 45 313 minecraft:cobbled_deepslate
fill 501 45 314 501 48 314 minecraft:deepslate_tiles
fill 502 45 313 503 47 313 minecraft:deepslate_tiles
setblock 503 45 276 minecraft:cobbled_deepslate
setblock 503 45 316 minecraft:cobbled_deepslate
fill 504 45 276 504 47 276 minecraft:deepslate_tiles
setblock 504 45 315 minecraft:cobbled_deepslate
fill 504 45 316 504 48 316 minecraft:deepslate_tiles
setblock 505 45 278 minecraft:light[level=13]
setblock 505 45 286 minecraft:light[level=13]
setblock 505 45 294 minecraft:light[level=13]
setblock 505 45 302 minecraft:light[level=13]
setblock 505 45 310 minecraft:light[level=13]
setblock 505 45 314 minecraft:cobbled_deepslate
fill 505 45 315 505 48 315 minecraft:deepslate_tiles
fill 506 45 275 506 95 275 minecraft:cobbled_deepslate
fill 507 45 315 507 46 315 minecraft:deepslate_tiles
setblock 508 45 316 minecraft:cobbled_deepslate
setblock 509 45 309 minecraft:deepslate_tiles
setblock 509 45 310 minecraft:cobbled_deepslate
fill 509 45 316 511 46 316 minecraft:deepslate_tiles
fill 510 45 305 510 46 305 minecraft:deepslate_tiles
setblock 510 45 309 minecraft:cobbled_deepslate
fill 510 45 310 510 48 310 minecraft:deepslate_tiles
setblock 510 45 314 minecraft:cobbled_deepslate
setblock 511 45 287 minecraft:deepslate_tiles
setblock 511 45 288 minecraft:cobbled_deepslate
fill 511 45 289 511 45 292 minecraft:deepslate_tiles
setblock 511 45 293 minecraft:cobbled_deepslate
setblock 511 45 303 minecraft:cobbled_deepslate
fill 511 45 304 511 48 304 minecraft:deepslate_tiles
setblock 511 45 308 minecraft:cobbled_deepslate
fill 511 45 309 511 48 309 minecraft:deepslate_tiles
setblock 511 45 312 minecraft:deepslate_tiles
setblock 511 45 313 minecraft:cobbled_deepslate
fill 511 45 314 511 48 314 minecraft:deepslate_tiles
fill 512 45 284 512 94 284 minecraft:cobbled_deepslate
setblock 471 46 287 minecraft:cobbled_deepslate
fill 471 46 288 471 49 288 minecraft:deepslate_tiles
setblock 471 46 291 minecraft:deepslate_tiles
setblock 471 46 292 minecraft:cobbled_deepslate
fill 471 46 293 471 49 293 minecraft:deepslate_tiles
setblock 471 46 297 minecraft:cobbled_deepslate
fill 471 46 298 471 49 298 minecraft:deepslate_tiles
setblock 471 46 302 minecraft:cobbled_deepslate
fill 471 46 303 471 49 303 minecraft:deepslate_tiles
setblock 471 46 307 minecraft:cobbled_deepslate
fill 471 46 308 471 49 308 minecraft:deepslate_tiles
setblock 471 46 311 minecraft:deepslate_tiles
setblock 471 46 312 minecraft:cobbled_deepslate
fill 471 46 313 471 49 313 minecraft:deepslate_tiles
fill 471 46 315 471 47 315 minecraft:deepslate_tiles
setblock 472 46 285 minecraft:deepslate_tiles
setblock 472 46 286 minecraft:cobbled_deepslate
fill 472 46 287 472 49 287 minecraft:deepslate_tiles
setblock 472 46 291 minecraft:cobbled_deepslate
fill 472 46 292 472 49 292 minecraft:deepslate_tiles
setblock 472 46 296 minecraft:cobbled_deepslate
fill 472 46 297 472 49 297 minecraft:deepslate_tiles
setblock 472 46 306 minecraft:cobbled_deepslate
fill 472 46 307 472 48 307 minecraft:deepslate_tiles
setblock 472 46 311 minecraft:cobbled_deepslate
fill 472 46 312 472 49 312 minecraft:deepslate_tiles
fill 473 46 286 473 49 286 minecraft:deepslate_tiles
setblock 473 46 289 minecraft:deepslate_tiles
setblock 473 46 290 minecraft:cobbled_deepslate
fill 473 46 291 474 48 291 minecraft:deepslate_tiles
fill 473 46 293 473 46 294 minecraft:deepslate_tiles
fill 473 46 316 476 46 316 minecraft:deepslate_tiles
setblock 474 46 288 minecraft:deepslate_tiles
setblock 474 46 289 minecraft:cobbled_deepslate
fill 474 46 290 474 49 290 minecraft:deepslate_tiles
fill 474 46 292 474 47 292 minecraft:deepslate_tiles
fill 475 46 276 476 46 276 minecraft:deepslate_tiles
fill 476 46 315 477 46 315 minecraft:deepslate_tiles
setblock 477 46 276 minecraft:cobbled_deepslate
setblock 477 46 316 minecraft:cobbled_deepslate
fill 478 46 276 478 49 276 minecraft:deepslate_tiles
setblock 478 46 315 minecraft:cobbled_deepslate
fill 478 46 316 478 49 316 minecraft:deepslate_tiles
fill 479 46 277 480 46 277 minecraft:deepslate_tiles
fill 479 46 315 479 49 315 minecraft:deepslate_tiles
fill 480 46 316 481 46 316 minecraft:deepslate_tiles
setblock 481 46 277 minecraft:cobbled_deepslate
fill 481 46 315 482 46 315 minecraft:deepslate_tiles
setblock 482 46 276 minecraft:cobbled_deepslate
setblock 482 46 316 minecraft:cobbled_deepslate
fill 483 46 276 483 49 276 minecraft:deepslate_tiles
fill 483 46 316 483 49 316 minecraft:deepslate_tiles
fill 485 46 275 485 77 275 minecraft:cobbled_deepslate
fill 485 46 316 485 47 316 minecraft:deepslate_tiles
setblock 486 46 276 minecraft:deepslate_tiles
setblock 487 46 276 minecraft:cobbled_deepslate
fill 488 46 276 491 46 276 minecraft:deepslate_tiles
fill 489 46 316 491 46 316 minecraft:deepslate_tiles
setblock 491 46 317 minecraft:redstone_block
setblock 492 46 276 minecraft:cobbled_deepslate
setblock 492 46 315 minecraft:deepslate_tiles
setblock 492 46 316 minecraft:cobbled_deepslate
fill 493 46 276 493 49 276 minecraft:deepslate_tiles
setblock 493 46 315 minecraft:cobbled_deepslate
fill 493 46 316 493 49 316 minecraft:deepslate_tiles
fill 494 46 277 494 47 277 minecraft:deepslate_tiles
setblock 494 46 314 minecraft:cobbled_deepslate
fill 494 46 315 494 49 315 minecraft:deepslate_tiles
fill 495 46 314 498 46 314 minecraft:deepslate_tiles
setblock 496 46 277 minecraft:cobbled_deepslate
fill 496 46 313 499 46 313 minecraft:deepslate_tiles
setblock 497 46 276 minecraft:cobbled_deepslate
fill 497 46 277 497 49 277 minecraft:deepslate_tiles
setblock 497 46 316 minecraft:cobbled_deepslate
fill 498 46 276 498 49 276 minecraft:deepslate_tiles
setblock 498 46 315 minecraft:cobbled_deepslate
fill 498 46 316 498 49 316 minecraft:deepslate_tiles
fill 499 46 312 500 46 312 minecraft:deepslate_tiles
setblock 499 46 314 minecraft:cobbled_deepslate
fill 499 46 315 499 49 315 minecraft:deepslate_tiles
setblock 500 46 313 minecraft:cobbled_deepslate
fill 500 46 314 500 49 314 minecraft:deepslate_tiles
setblock 501 46 277 minecraft:cobbled_deepslate
fill 501 46 313 501 49 313 minecraft:deepslate_tiles
setblock 502 46 276 minecraft:cobbled_deepslate
setblock 502 46 316 minecraft:cobbled_deepslate
fill 503 46 276 503 49 276 minecraft:deepslate_tiles
setblock 503 46 314 minecraft:deepslate_tiles
setblock 503 46 315 minecraft:cobbled_deepslate
fill 503 46 316 503 49 316 minecraft:deepslate_tiles
setblock 504 46 314 minecraft:cobbled_deepslate
fill 504 46 315 504 49 315 minecraft:deepslate_tiles
fill 505 46 314 506 47 314 minecraft:deepslate_tiles
setblock 507 46 316 minecraft:cobbled_deepslate
setblock 508 46 315 minecraft:cobbled_deepslate
fill 508 46 316 508 49 316 minecraft:deepslate_tiles
setblock 509 46 309 minecraft:cobbled_deepslate
fill 509 46 310 509 47 311 minecraft:deepslate_tiles
fill 509 46 315 509 49 315 minecraft:deepslate_tiles
setblock 510 46 308 minecraft:cobbled_deepslate
fill 510 46 309 510 49 309 minecraft:deepslate_tiles
setblock 510 46 313 minecraft:cobbled_deepslate
fill 510 46 314 510 49 314 minecraft:deepslate_tiles
setblock 511 46 286 minecraft:deepslate_tiles
setblock 511 46 287 minecraft:cobbled_deepslate
fill 511 46 288 511 46 291 minecraft:deepslate_tiles
setblock 511 46 292 minecraft:cobbled_deepslate
fill 511 46 293 511 46 296 minecraft:deepslate_tiles
setblock 511 46 301 minecraft:deepslate_tiles
setblock 511 46 302 minecraft:cobbled_deepslate
fill 511 46 303 511 49 303 minecraft:deepslate_tiles
setblock 511 46 307 minecraft:cobbled_deepslate
fill 511 46 308 511 49 308 minecraft:deepslate_tiles
setblock 511 46 312 minecraft:cobbled_deepslate
fill 511 46 313 511 49 313 minecraft:deepslate_tiles
setblock 471 47 286 minecraft:cobbled_deepslate
fill 471 47 287 471 50 287 minecraft:deepslate_tiles
setblock 471 47 290 minecraft:deepslate_tiles
setblock 471 47 291 minecraft:cobbled_deepslate
fill 471 47 292 471 50 292 minecraft:deepslate_tiles
setblock 471 47 295 minecraft:deepslate_tiles
setblock 471 47 296 minecraft:cobbled_deepslate
fill 471 47 297 471 50 297 minecraft:deepslate_tiles
setblock 471 47 301 minecraft:cobbled_deepslate
fill 471 47 302 471 50 302 minecraft:deepslate_tiles
setblock 471 47 305 minecraft:deepslate_tiles
setblock 471 47 306 minecraft:cobbled_deepslate
fill 471 47 307 471 50 307 minecraft:deepslate_tiles
setblock 471 47 310 minecraft:deepslate_tiles
setblock 471 47 311 minecraft:cobbled_deepslate
fill 471 47 312 471 50 312 minecraft:deepslate_tiles
setblock 472 47 285 minecraft:cobbled_deepslate
fill 472 47 286 472 50 286 minecraft:deepslate_tiles
setblock 472 47 290 minecraft:cobbled_deepslate
fill 472 47 291 472 50 291 minecraft:deepslate_tiles
setblock 472 47 295 minecraft:cobbled_deepslate
fill 472 47 296 473 49 296 minecraft:deepslate_tiles
fill 472 47 298 472 48 298 minecraft:deepslate_tiles
setblock 472 47 306 minecraft:deepslate_tiles
setblock 472 47 310 minecraft:cobbled_deepslate
fill 472 47 311 472 50 311 minecraft:deepslate_tiles
fill 472 47 313 472 48 313 minecraft:deepslate_tiles
fill 472 47 316 475 47 316 minecraft:deepslate_tiles
setblock 473 47 289 minecraft:cobbled_deepslate
fill 473 47 290 473 50 290 minecraft:deepslate_tiles
setblock 473 47 293 minecraft:deepslate_tiles
setblock 473 47 294 minecraft:cobbled_deepslate
fill 473 47 295 473 50 295 minecraft:deepslate_tiles
fill 474 47 276 475 47 276 minecraft:deepslate_tiles
setblock 474 47 287 minecraft:deepslate_tiles
setblock 474 47 288 minecraft:cobbled_deepslate
fill 474 47 289 474 50 289 minecraft:deepslate_tiles
setblock 474 47 293 minecraft:cobbled_deepslate
fill 474 47 294 474 50 294 minecraft:deepslate_tiles
fill 474 47 315 476 47 315 minecraft:deepslate_tiles
setblock 476 47 276 minecraft:cobbled_deepslate
setblock 476 47 316 minecraft:cobbled_deepslate
fill 477 47 276 477 49 277 minecraft:deepslate_tiles
setblock 477 47 315 minecraft:cobbled_deepslate
fill 477 47 316 477 50 316 minecraft:deepslate_tiles
fill 478 47 277 479 47 277 minecraft:deepslate_tiles
fill 478 47 315 478 50 315 minecraft:deepslate_tiles
setblock 480 47 277 minecraft:cobbled_deepslate
setblock 480 47 316 minecraft:deepslate_tiles
setblock 481 47 276 minecraft:cobbled_deepslate
fill 481 47 277 481 49 277 minecraft:deepslate_tiles
setblock 481 47 315 minecraft:deepslate_tiles
setblock 481 47 316 minecraft:cobbled_deepslate
fill 482 47 276 482 50 276 minecraft:deepslate_tiles
setblock 482 47 315 minecraft:cobbled_deepslate
fill 482 47 316 482 50 316 minecraft:deepslate_tiles
setblock 486 47 276 minecraft:cobbled_deepslate
setblock 486 47 316 minecraft:cobbled_deepslate
fill 487 47 276 490 47 276 minecraft:deepslate_tiles
fill 487 47 316 490 47 316 minecraft:deepslate_tiles
setblock 487 47 317 minecraft:redstone_block
fill 488 47 317 488 94 317 minecraft:cobbled_deepslate
setblock 491 47 276 minecraft:cobbled_deepslate
setblock 491 47 315 minecraft:deepslate_tiles
fill 491 47 316 491 47 317 minecraft:cobbled_deepslate
fill 492 47 276 492 50 276 minecraft:deepslate_tiles
setblock 492 47 315 minecraft:cobbled_deepslate
fill 492 47 316 492 50 316 minecraft:deepslate_tiles
fill 493 47 277 493 48 277 minecraft:deepslate_tiles
setblock 493 47 314 minecraft:cobbled_deepslate
fill 493 47 315 493 50 315 minecraft:deepslate_tiles
fill 494 47 314 497 47 314 minecraft:deepslate_tiles
setblock 495 47 277 minecraft:cobbled_deepslate
fill 495 47 313 498 47 313 minecraft:deepslate_tiles
setblock 496 47 276 minecraft:cobbled_deepslate
fill 496 47 277 496 50 277 minecraft:deepslate_tiles
setblock 496 47 316 minecraft:cobbled_deepslate
fill 497 47 276 497 50 276 minecraft:deepslate_tiles
setblock 497 47 315 minecraft:cobbled_deepslate
fill 497 47 316 497 50 316 minecraft:deepslate_tiles
fill 498 47 312 499 47 312 minecraft:deepslate_tiles
setblock 498 47 314 minecraft:cobbled_deepslate
fill 498 47 315 498 50 315 minecraft:deepslate_tiles
setblock 499 47 313 minecraft:cobbled_deepslate
fill 499 47 314 499 50 314 minecraft:deepslate_tiles
setblock 500 47 277 minecraft:cobbled_deepslate
setblock 500 47 312 minecraft:cobbled_deepslate
fill 500 47 313 500 50 313 minecraft:deepslate_tiles
setblock 501 47 276 minecraft:cobbled_deepslate
setblock 501 47 277 minecraft:deepslate_tiles
setblock 501 47 316 minecraft:cobbled_deepslate
fill 502 47 276 502 50 276 minecraft:deepslate_tiles
setblock 502 47 315 minecraft:cobbled_deepslate
fill 502 47 316 502 50 316 minecraft:deepslate_tiles
setblock 503 47 314 minecraft:cobbled_deepslate
fill 503 47 315 503 50 315 minecraft:deepslate_tiles
fill 504 47 314 504 49 314 minecraft:deepslate_tiles
setblock 506 47 316 minecraft:cobbled_deepslate
setblock 507 47 315 minecraft:cobbled_deepslate
fill 507 47 316 507 50 316 minecraft:deepslate_tiles
fill 508 47 315 508 50 315 minecraft:deepslate_tiles
setblock 509 47 312 minecraft:deepslate_tiles
fill 509 47 316 510 47 316 minecraft:deepslate_tiles
setblock 510 47 307 minecraft:cobbled_deepslate
fill 510 47 308 510 50 308 minecraft:deepslate_tiles
setblock 510 47 312 minecraft:cobbled_deepslate
fill 510 47 313 510 50 313 minecraft:deepslate_tiles
fill 510 47 315 510 48 315 minecraft:deepslate_tiles
setblock 511 47 286 minecraft:cobbled_deepslate
fill 511 47 287 511 47 290 minecraft:deepslate_tiles
setblock 511 47 291 minecraft:cobbled_deepslate
fill 511 47 292 511 47 295 minecraft:deepslate_tiles
setblock 511 47 296 minecraft:cobbled_deepslate
fill 511 47 297 511 47 300 minecraft:deepslate_tiles
setblock 511 47 301 minecraft:cobbled_deepslate
fill 511 47 302 511 50 302 minecraft:deepslate_tiles
setblock 511 47 306 minecraft:cobbled_deepslate
fill 511 47 307 511 50 307 minecraft:deepslate_tiles
setblock 511 47 311 minecraft:cobbled_deepslate
fill 511 47 312 511 50 312 minecraft:deepslate_tiles
setblock 511 47 316 minecraft:cobbled_deepslate
setblock 512 47 287 minecraft:white_wool
setblock 512 47 306 minecraft:white_wool
setblock 471 48 285 minecraft:cobbled_deepslate
fill 471 48 286 471 51 286 minecraft:deepslate_tiles
setblock 471 48 290 minecraft:cobbled_deepslate
fill 471 48 291 471 51 291 minecraft:deepslate_tiles
setblock 471 48 294 minecraft:deepslate_tiles
setblock 471 48 295 minecraft:cobbled_deepslate
fill 471 48 296 471 51 296 minecraft:deepslate_tiles
setblock 471 48 299 minecraft:deepslate_tiles
setblock 471 48 300 minecraft:cobbled_deepslate
fill 471 48 301 471 51 301 minecraft:deepslate_tiles
setblock 471 48 305 minecraft:cobbled_deepslate
fill 471 48 306 471 50 306 minecraft:deepslate_tiles
setblock 471 48 310 minecraft:cobbled_deepslate
fill 471 48 311 471 51 311 minecraft:deepslate_tiles
setblock 471 48 315 minecraft:cobbled_deepslate
fill 471 48 316 474 48 316 minecraft:deepslate_tiles
fill 472 48 285 472 50 285 minecraft:deepslate_tiles
setblock 472 48 288 minecraft:deepslate_tiles
setblock 472 48 289 minecraft:cobbled_deepslate
fill 472 48 290 472 51 290 minecraft:deepslate_tiles
setblock 472 48 294 minecraft:cobbled_deepslate
fill 472 48 295 472 51 295 minecraft:deepslate_tiles
setblock 472 48 299 minecraft:cobbled_deepslate
setblock 472 48 309 minecraft:cobbled_deepslate
fill 472 48 310 472 50 310 minecraft:deepslate_tiles
setblock 472 48 314 minecraft:cobbled_deepslate
fill 473 48 276 474 48 276 minecraft:deepslate_tiles
setblock 473 48 288 minecraft:cobbled_deepslate
fill 473 48 289 473 51 289 minecraft:deepslate_tiles
setblock 473 48 293 minecraft:cobbled_deepslate
fill 473 48 294 473 51 294 minecraft:deepslate_tiles
setblock 473 48 297 minecraft:deepslate_tiles
fill 473 48 315 475 48 315 minecraft:deepslate_tiles
setblock 474 48 287 minecraft:cobbled_deepslate
fill 474 48 288 474 50 288 minecraft:deepslate_tiles
setblock 474 48 292 minecraft:cobbled_deepslate
fill 474 48 293 474 51 293 minecraft:deepslate_tiles
fill 474 48 295 474 49 295 minecraft:deepslate_tiles
setblock 475 48 276 minecraft:cobbled_deepslate
setblock 475 48 290 minecraft:deepslate_tiles
setblock 475 48 291 minecraft:cobbled_deepslate
fill 475 48 292 475 49 292 minecraft:deepslate_tiles
setblock 475 48 316 minecraft:cobbled_deepslate
fill 476 48 276 476 50 277 minecraft:deepslate_tiles
setblock 476 48 315 minecraft:cobbled_deepslate
fill 476 48 316 476 51 316 minecraft:deepslate_tiles
setblock 477 48 314 minecraft:cobbled_deepslate
fill 477 48 315 477 51 315 minecraft:deepslate_tiles
setblock 478 48 277 minecraft:deepslate_tiles
setblock 478 48 314 minecraft:deepslate_tiles
setblock 479 48 277 minecraft:cobbled_deepslate
setblock 480 48 276 minecraft:cobbled_deepslate
fill 480 48 277 480 51 277 minecraft:deepslate_tiles
setblock 480 48 316 minecraft:cobbled_deepslate
fill 481 48 276 481 51 276 minecraft:deepslate_tiles
setblock 481 48 315 minecraft:cobbled_deepslate
fill 481 48 316 481 51 316 minecraft:deepslate_tiles
fill 482 48 315 482 49 315 minecraft:deepslate_tiles
setblock 485 48 276 minecraft:cobbled_deepslate
setblock 485 48 316 minecraft:cobbled_deepslate
fill 486 48 276 489 48 276 minecraft:deepslate_tiles
fill 486 48 316 489 48 316 minecraft:deepslate_tiles
fill 487 48 317 487 94 317 minecraft:cobbled_deepslate
setblock 490 48 276 minecraft:cobbled_deepslate
setblock 490 48 315 minecraft:deepslate_tiles
setblock 490 48 316 minecraft:cobbled_deepslate
fill 491 48 276 491 51 276 minecraft:deepslate_tiles
setblock 491 48 315 minecraft:cobbled_deepslate
fill 491 48 316 491 51 316 minecraft:deepslate_tiles
fill 491 48 317 491 94 317 minecraft:cobbled_deepslate
fill 492 48 277 492 49 277 minecraft:deepslate_tiles
setblock 492 48 314 minecraft:cobbled_deepslate
fill 492 48 315 492 51 315 minecraft:deepslate_tiles
fill 493 48 314 496 48 314 minecraft:deepslate_tiles
setblock 494 48 277 minecraft:cobbled_deepslate
fill 494 48 313 497 48 313 minecraft:deepslate_tiles
setblock 495 48 276 minecraft:cobbled_deepslate
fill 495 48 277 495 51 277 minecraft:deepslate_tiles
setblock 495 48 316 minecraft:cobbled_deepslate
fill 496 48 276 496 51 276 minecraft:deepslate_tiles
setblock 496 48 315 minecraft:cobbled_deepslate
fill 496 48 316 496 51 316 minecraft:deepslate_tiles
fill 497 48 312 498 48 312 minecraft:deepslate_tiles
setblock 497 48 314 minecraft:cobbled_deepslate
fill 497 48 315 497 51 315 minecraft:deepslate_tiles
setblock 498 48 313 minecraft:cobbled_deepslate
fill 498 48 314 498 51 314 minecraft:deepslate_tiles
setblock 499 48 277 minecraft:cobbled_deepslate
setblock 499 48 312 minecraft:cobbled_deepslate
fill 499 48 313 499 51 313 minecraft:deepslate_tiles
setblock 500 48 276 minecraft:cobbled_deepslate
fill 500 48 277 500 49 277 minecraft:deepslate_tiles
setblock 500 48 316 minecraft:cobbled_deepslate
fill 501 48 276 501 51 276 minecraft:deepslate_tiles
setblock 501 48 315 minecraft:cobbled_deepslate
fill 501 48 316 501 51 316 minecraft:deepslate_tiles
setblock 502 48 313 minecraft:deepslate_tiles
setblock 502 48 314 minecraft:cobbled_deepslate
fill 502 48 315 502 51 315 minecraft:deepslate_tiles
setblock 503 48 313 minecraft:cobbled_deepslate
fill 503 48 314 503 50 314 minecraft:deepslate_tiles
fill 505 48 314 505 49 314 minecraft:deepslate_tiles
setblock 505 48 316 minecraft:cobbled_deepslate
setblock 506 48 315 minecraft:cobbled_deepslate
fill 506 48 316 506 51 316 minecraft:deepslate_tiles
fill 507 48 315 507 50 315 minecraft:deepslate_tiles
setblock 509 48 311 minecraft:deepslate_tiles
setblock 509 48 316 minecraft:deepslate_tiles
setblock 510 48 291 minecraft:cobbled_deepslate
fill 510 48 292 511 49 293 minecraft:deepslate_tiles
setblock 510 48 306 minecraft:cobbled_deepslate
fill 510 48 307 510 49 307 minecraft:deepslate_tiles
setblock 510 48 311 minecraft:cobbled_deepslate
fill 510 48 312 510 51 312 minecraft:deepslate_tiles
setblock 510 48 316 minecraft:cobbled_deepslate
fill 511 48 286 511 48 289 minecraft:deepslate_tiles
setblock 511 48 290 minecraft:cobbled_deepslate
fill 511 48 291 511 51 291 minecraft:deepslate_tiles
setblock 511 48 294 minecraft:deepslate_tiles
setblock 511 48 295 minecraft:cobbled_deepslate
fill 511 48 296 511 48 299 minecraft:deepslate_tiles
setblock 511 48 300 minecraft:cobbled_deepslate
fill 511 48 301 511 51 301 minecraft:deepslate_tiles
setblock 511 48 305 minecraft:cobbled_deepslate
fill 511 48 306 511 51 306 minecraft:deepslate_tiles
setblock 511 48 310 minecraft:cobbled_deepslate
fill 511 48 311 511 51 311 minecraft:deepslate_tiles
setblock 511 48 315 minecraft:cobbled_deepslate
fill 511 48 316 511 51 316 minecraft:deepslate_tiles
fill 512 48 287 512 91 287 minecraft:cobbled_deepslate
fill 512 48 306 512 92 306 minecraft:cobbled_deepslate
setblock 471 49 284 minecraft:cobbled_deepslate
fill 471 49 285 471 52 285 minecraft:deepslate_tiles
setblock 471 49 289 minecraft:cobbled_deepslate
fill 471 49 290 471 52 290 minecraft:deepslate_tiles
setblock 471 49 294 minecraft:cobbled_deepslate
fill 471 49 295 471 52 295 minecraft:deepslate_tiles
setblock 471 49 299 minecraft:cobbled_deepslate
fill 471 49 300 471 52 300 minecraft:deepslate_tiles
setblock 471 49 304 minecraft:cobbled_deepslate
fill 471 49 305 471 50 305 minecraft:deepslate_tiles
setblock 471 49 309 minecraft:cobbled_deepslate
fill 471 49 310 471 52 310 minecraft:deepslate_tiles
setblock 471 49 314 minecraft:cobbled_deepslate
fill 471 49 315 471 51 316 minecraft:deepslate_tiles
setblock 472 49 288 minecraft:cobbled_deepslate
fill 472 49 289 472 52 289 minecraft:deepslate_tiles
setblock 472 49 293 minecraft:cobbled_deepslate
fill 472 49 294 472 52 294 minecraft:deepslate_tiles
setblock 472 49 298 minecraft:cobbled_deepslate
fill 472 49 299 472 52 299 minecraft:deepslate_tiles
setblock 472 49 308 minecraft:cobbled_deepslate
setblock 472 49 309 minecraft:deepslate_tiles
setblock 472 49 313 minecraft:cobbled_deepslate
fill 472 49 314 472 51 314 minecraft:deepslate_tiles
fill 472 49 316 473 49 316 minecraft:deepslate_tiles
setblock 473 49 276 minecraft:deepslate_tiles
setblock 473 49 278 minecraft:light[level=12]
setblock 473 49 285 minecraft:light[level=12]
setblock 473 49 287 minecraft:cobbled_deepslate
fill 473 49 288 473 52 288 minecraft:deepslate_tiles
setblock 473 49 291 minecraft:deepslate_tiles
setblock 473 49 292 minecraft:cobbled_deepslate
fill 473 49 293 473 52 293 minecraft:deepslate_tiles
setblock 473 49 297 minecraft:cobbled_deepslate
setblock 473 49 299 minecraft:light[level=12]
setblock 473 49 306 minecraft:light[level=12]
setblock 473 49 313 minecraft:light[level=12]
fill 473 49 315 474 49 315 minecraft:deepslate_tiles
setblock 474 49 276 minecraft:cobbled_deepslate
setblock 474 49 291 minecraft:cobbled_deepslate
fill 474 49 292 474 52 292 minecraft:deepslate_tiles
setblock 474 49 316 minecraft:cobbled_deepslate
fill 475 49 276 475 52 276 minecraft:deepslate_tiles
setblock 475 49 291 minecraft:deepslate_tiles
setblock 475 49 315 minecraft:cobbled_deepslate
fill 475 49 316 475 52 316 minecraft:deepslate_tiles
fill 476 49 313 476 50 313 minecraft:black_concrete
fill 476 49 315 476 52 315 minecraft:deepslate_tiles
fill 477 49 312 477 50 312 minecraft:black_concrete
fill 477 49 314 477 50 314 minecraft:black_concrete
setblock 478 49 277 minecraft:cobbled_deepslate
fill 478 49 313 478 50 313 minecraft:black_concrete
setblock 479 49 276 minecraft:cobbled_deepslate
fill 479 49 277 479 52 277 minecraft:deepslate_tiles
setblock 479 49 316 minecraft:cobbled_deepslate
fill 480 49 276 480 52 276 minecraft:deepslate_tiles
setblock 480 49 278 minecraft:light[level=12]
setblock 480 49 285 minecraft:light[level=12]
setblock 480 49 292 minecraft:light[level=12]
setblock 480 49 299 minecraft:light[level=12]
setblock 480 49 306 minecraft:light[level=12]
setblock 480 49 313 minecraft:light[level=12]
setblock 480 49 315 minecraft:cobbled_deepslate
fill 480 49 316 480 52 316 minecraft:deepslate_tiles
fill 481 49 315 481 50 315 minecraft:deepslate_tiles
setblock 484 49 276 minecraft:cobbled_deepslate
setblock 484 49 316 minecraft:cobbled_deepslate
fill 485 49 276 488 49 276 minecraft:deepslate_tiles
fill 485 49 309 487 50 309 minecraft:white_wool
fill 485 49 316 488 49 316 minecraft:deepslate_tiles
fill 486 49 308 486 50 308 minecraft:white_wool
fill 486 49 310 486 50 310 minecraft:white_wool
setblock 487 49 278 minecraft:light[level=12]
setblock 487 49 285 minecraft:light[level=12]
setblock 487 49 292 minecraft:light[level=12]
setblock 487 49 299 minecraft:light[level=12]
setblock 487 49 306 minecraft:light[level=12]
setblock 487 49 313 minecraft:light[level=12]
setblock 489 49 276 minecraft:cobbled_deepslate
setblock 489 49 315 minecraft:deepslate_tiles
setblock 489 49 316 minecraft:cobbled_deepslate
fill 490 49 276 490 52 276 minecraft:deepslate_tiles
setblock 490 49 315 minecraft:cobbled_deepslate
fill 490 49 316 490 52 316 minecraft:deepslate_tiles
fill 491 49 277 491 50 277 minecraft:deepslate_tiles
setblock 491 49 314 minecraft:cobbled_deepslate
fill 491 49 315 491 52 315 minecraft:deepslate_tiles
fill 492 49 314 495 49 314 minecraft:deepslate_tiles
setblock 493 49 277 minecraft:cobbled_deepslate
setblock 494 49 276 minecraft:cobbled_deepslate
fill 494 49 277 494 52 277 minecraft:deepslate_tiles
setblock 494 49 278 minecraft:light[level=12]
setblock 494 49 285 minecraft:light[level=12]
setblock 494 49 292 minecraft:light[level=12]
setblock 494 49 299 minecraft:light[level=12]
setblock 494 49 306 minecraft:light[level=12]
fill 494 49 313 496 49 313 minecraft:deepslate_tiles
setblock 494 49 316 minecraft:cobbled_deepslate
fill 495 49 276 495 52 276 minecraft:deepslate_tiles
setblock 495 49 315 minecraft:cobbled_deepslate
fill 495 49 316 495 52 316 minecraft:deepslate_tiles
setblock 496 49 314 minecraft:cobbled_deepslate
fill 496 49 315 496 52 315 minecraft:deepslate_tiles
setblock 497 49 313 minecraft:cobbled_deepslate
fill 497 49 314 497 52 314 minecraft:deepslate_tiles
setblock 498 49 277 minecraft:cobbled_deepslate
fill 498 49 313 498 52 313 minecraft:deepslate_tiles
setblock 499 49 276 minecraft:cobbled_deepslate
fill 499 49 277 499 51 277 minecraft:deepslate_tiles
setblock 499 49 316 minecraft:cobbled_deepslate
fill 500 49 276 500 52 276 minecraft:deepslate_tiles
setblock 500 49 315 minecraft:cobbled_deepslate
fill 500 49 316 500 52 316 minecraft:deepslate_tiles
setblock 501 49 278 minecraft:light[level=12]
setblock 501 49 285 minecraft:light[level=12]
setblock 501 49 292 minecraft:light[level=12]
setblock 501 49 299 minecraft:light[level=12]
setblock 501 49 306 minecraft:light[level=12]
setblock 501 49 314 minecraft:cobbled_deepslate
fill 501 49 315 501 52 315 minecraft:deepslate_tiles
setblock 502 49 313 minecraft:cobbled_deepslate
fill 502 49 314 502 51 314 minecraft:deepslate_tiles
setblock 504 49 316 minecraft:cobbled_deepslate
setblock 505 49 315 minecraft:cobbled_deepslate
fill 505 49 316 505 52 316 minecraft:deepslate_tiles
fill 506 49 315 506 51 315 minecraft:deepslate_tiles
setblock 508 49 278 minecraft:light[level=12]
setblock 508 49 285 minecraft:light[level=12]
setblock 508 49 292 minecraft:light[level=12]
setblock 508 49 299 minecraft:light[level=12]
setblock 508 49 306 minecraft:light[level=12]
setblock 508 49 313 minecraft:light[level=12]
setblock 509 49 316 minecraft:cobbled_deepslate
fill 510 49 291 510 52 291 minecraft:deepslate_tiles
setblock 510 49 294 minecraft:deepslate_tiles
setblock 510 49 295 minecraft:cobbled_deepslate
setblock 510 49 310 minecraft:cobbled_deepslate
fill 510 49 311 510 52 311 minecraft:deepslate_tiles
setblock 510 49 315 minecraft:cobbled_deepslate
fill 510 49 316 510 52 316 minecraft:deepslate_tiles
fill 511 49 287 511 49 288 minecraft:deepslate_tiles
setblock 511 49 289 minecraft:cobbled_deepslate
fill 511 49 290 511 52 290 minecraft:deepslate_tiles
setblock 511 49 294 minecraft:cobbled_deepslate
fill 511 49 295 511 49 298 minecraft:deepslate_tiles
setblock 511 49 299 minecraft:cobbled_deepslate
fill 511 49 300 511 52 300 minecraft:deepslate_tiles
setblock 511 49 304 minecraft:cobbled_deepslate
fill 511 49 305 511 52 305 minecraft:deepslate_tiles
setblock 511 49 309 minecraft:cobbled_deepslate
fill 511 49 310 511 52 310 minecraft:deepslate_tiles
setblock 511 49 314 minecraft:cobbled_deepslate
fill 511 49 315 511 52 315 minecraft:deepslate_tiles
fill 471 50 284 471 51 284 minecraft:deepslate_tiles
setblock 471 50 288 minecraft:cobbled_deepslate
fill 471 50 289 471 53 289 minecraft:deepslate_tiles
setblock 471 50 293 minecraft:cobbled_deepslate
fill 471 50 294 471 53 294 minecraft:deepslate_tiles
setblock 471 50 298 minecraft:cobbled_deepslate
fill 471 50 299 471 53 299 minecraft:deepslate_tiles
setblock 471 50 303 minecraft:cobbled_deepslate
setblock 471 50 304 minecraft:deepslate_tiles
setblock 471 50 308 minecraft:cobbled_deepslate
fill 471 50 309 471 51 309 minecraft:deepslate_tiles
setblock 471 50 313 minecraft:cobbled_deepslate
fill 471 50 314 471 53 314 minecraft:deepslate_tiles
setblock 472 50 276 minecraft:deepslate_tiles
setblock 472 50 287 minecraft:cobbled_deepslate
fill 472 50 288 472 53 288 minecraft:deepslate_tiles
setblock 472 50 292 minecraft:cobbled_deepslate
fill 472 50 293 472 53 293 minecraft:deepslate_tiles
setblock 472 50 296 minecraft:deepslate_tiles
setblock 472 50 297 minecraft:cobbled_deepslate
fill 472 50 298 472 53 298 minecraft:deepslate_tiles
fill 472 50 300 472 51 300 minecraft:deepslate_tiles
setblock 472 50 312 minecraft:cobbled_deepslate
fill 472 50 313 472 51 313 minecraft:deepslate_tiles
fill 472 50 315 472 50 316 minecraft:deepslate_tiles
setblock 473 50 276 minecraft:cobbled_deepslate
fill 473 50 287 473 51 287 minecraft:deepslate_tiles
setblock 473 50 291 minecraft:cobbled_deepslate
fill 473 50 292 473 53 292 minecraft:deepslate_tiles
setblock 473 50 296 minecraft:cobbled_deepslate
fill 473 50 297 473 53 297 minecraft:deepslate_tiles
setblock 473 50 315 minecraft:deepslate_tiles
setblock 473 50 316 minecraft:cobbled_deepslate
fill 474 50 276 474 53 276 minecraft:deepslate_tiles
setblock 474 50 290 minecraft:cobbled_deepslate
fill 474 50 291 474 52 291 minecraft:deepslate_tiles
setblock 474 50 295 minecraft:cobbled_deepslate
setblock 474 50 315 minecraft:cobbled_deepslate
fill 474 50 316 474 53 316 minecraft:deepslate_tiles
fill 475 50 277 475 51 277 minecraft:deepslate_tiles
fill 475 50 315 475 53 315 minecraft:deepslate_tiles
setblock 477 50 276 minecraft:deepslate_tiles
setblock 477 50 277 minecraft:cobbled_deepslate
setblock 478 50 276 minecraft:cobbled_deepslate
fill 478 50 277 478 53 277 minecraft:deepslate_tiles
setblock 478 50 316 minecraft:cobbled_deepslate
fill 479 50 276 479 53 276 minecraft:deepslate_tiles
setblock 479 50 315 minecraft:cobbled_deepslate
fill 479 50 316 479 53 316 minecraft:deepslate_tiles
setblock 480 50 315 minecraft:deepslate_tiles
setblock 483 50 276 minecraft:cobbled_deepslate
setblock 483 50 316 minecraft:cobbled_deepslate
fill 484 50 276 487 50 276 minecraft:deepslate_tiles
fill 484 50 316 487 50 316 minecraft:deepslate_tiles
setblock 488 50 276 minecraft:cobbled_deepslate
setblock 488 50 316 minecraft:cobbled_deepslate
fill 489 50 276 489 53 276 minecraft:deepslate_tiles
setblock 489 50 315 minecraft:cobbled_deepslate
fill 489 50 316 489 53 316 minecraft:deepslate_tiles
fill 490 50 315 490 53 315 minecraft:deepslate_tiles
fill 491 50 314 494 50 314 minecraft:deepslate_tiles
setblock 492 50 277 minecraft:cobbled_deepslate
setblock 493 50 276 minecraft:cobbled_deepslate
fill 493 50 277 493 53 277 minecraft:deepslate_tiles
setblock 493 50 316 minecraft:cobbled_deepslate
fill 494 50 276 494 53 276 minecraft:deepslate_tiles
fill 494 50 313 495 50 313 minecraft:deepslate_tiles
setblock 494 50 315 minecraft:cobbled_deepslate
fill 494 50 316 494 53 316 minecraft:deepslate_tiles
setblock 495 50 314 minecraft:cobbled_deepslate
fill 495 50 315 495 53 315 minecraft:deepslate_tiles
setblock 496 50 313 minecraft:cobbled_deepslate
fill 496 50 314 496 53 314 minecraft:deepslate_tiles
setblock 497 50 277 minecraft:cobbled_deepslate
fill 497 50 313 497 52 313 minecraft:deepslate_tiles
setblock 498 50 276 minecraft:cobbled_deepslate
fill 498 50 277 498 53 277 minecraft:deepslate_tiles
setblock 498 50 316 minecraft:cobbled_deepslate
fill 499 50 276 499 53 276 minecraft:deepslate_tiles
setblock 499 50 315 minecraft:cobbled_deepslate
fill 499 50 316 499 53 316 minecraft:deepslate_tiles
setblock 500 50 314 minecraft:cobbled_deepslate
fill 500 50 315 500 53 315 minecraft:deepslate_tiles
setblock 501 50 313 minecraft:cobbled_deepslate
fill 501 50 314 501 52 314 minecraft:deepslate_tiles
setblock 501 50 317 minecraft:white_wool
fill 502 50 317 502 56 317 minecraft:cobbled_deepslate
setblock 503 50 316 minecraft:cobbled_deepslate
setblock 504 50 315 minecraft:cobbled_deepslate
fill 504 50 316 504 53 316 minecraft:deepslate_tiles
fill 505 50 315 505 51 315 minecraft:deepslate_tiles
setblock 508 50 316 minecraft:cobbled_deepslate
setblock 509 50 315 minecraft:cobbled_deepslate
fill 509 50 316 509 53 316 minecraft:deepslate_tiles
fill 510 50 292 510 50 293 minecraft:deepslate_tiles
setblock 510 50 294 minecraft:cobbled_deepslate
fill 510 50 295 511 51 296 minecraft:deepslate_tiles
setblock 510 50 309 minecraft:cobbled_deepslate
fill 510 50 310 510 51 310 minecraft:deepslate_tiles
setblock 510 50 314 minecraft:cobbled_deepslate
fill 510 50 315 510 53 315 minecraft:deepslate_tiles
setblock 511 50 287 minecraft:deepslate_tiles
setblock 511 50 288 minecraft:cobbled_deepslate
fill 511 50 289 511 53 289 minecraft:deepslate_tiles
setblock 511 50 292 minecraft:deepslate_tiles
setblock 511 50 293 minecraft:cobbled_deepslate
fill 511 50 294 511 53 294 minecraft:deepslate_tiles
setblock 511 50 297 minecraft:deepslate_tiles
setblock 511 50 298 minecraft:cobbled_deepslate
fill 511 50 299 511 53 299 minecraft:deepslate_tiles
setblock 511 50 303 minecraft:cobbled_deepslate
fill 511 50 304 511 53 304 minecraft:deepslate_tiles
setblock 511 50 308 minecraft:cobbled_deepslate
fill 511 50 309 511 53 309 minecraft:deepslate_tiles
setblock 511 50 313 minecraft:cobbled_deepslate
fill 511 50 314 511 53 314 minecraft:deepslate_tiles
setblock 471 51 287 minecraft:cobbled_deepslate
fill 471 51 288 471 54 288 minecraft:deepslate_tiles
setblock 471 51 292 minecraft:cobbled_deepslate
fill 471 51 293 471 54 293 minecraft:deepslate_tiles
setblock 471 51 297 minecraft:cobbled_deepslate
fill 471 51 298 471 54 298 minecraft:deepslate_tiles
setblock 471 51 302 minecraft:cobbled_deepslate
setblock 471 51 308 minecraft:deepslate_tiles
setblock 471 51 312 minecraft:cobbled_deepslate
fill 471 51 313 471 54 313 minecraft:deepslate_tiles
setblock 472 51 276 minecraft:cobbled_deepslate
setblock 472 51 286 minecraft:cobbled_deepslate
fill 472 51 287 472 54 287 minecraft:deepslate_tiles
setblock 472 51 291 minecraft:cobbled_deepslate
fill 472 51 292 472 54 292 minecraft:deepslate_tiles
setblock 472 51 296 minecraft:cobbled_deepslate
fill 472 51 297 472 54 297 minecraft:deepslate_tiles
setblock 472 51 316 minecraft:cobbled_deepslate
fill 473 51 276 473 54 276 minecraft:deepslate_tiles
setblock 473 51 290 minecraft:cobbled_deepslate
fill 473 51 291 473 54 291 minecraft:deepslate_tiles
setblock 473 51 295 minecraft:cobbled_deepslate
fill 473 51 296 473 54 296 minecraft:deepslate_tiles
fill 473 51 298 473 52 298 minecraft:deepslate_tiles
setblock 473 51 315 minecraft:cobbled_deepslate
fill 473 51 316 473 54 316 minecraft:deepslate_tiles
setblock 474 51 289 minecraft:cobbled_deepslate
fill 474 51 290 474 52 290 minecraft:deepslate_tiles
setblock 474 51 294 minecraft:cobbled_deepslate
fill 474 51 295 474 54 295 minecraft:deepslate_tiles
fill 474 51 315 474 54 315 minecraft:deepslate_tiles
setblock 476 51 276 minecraft:deepslate_tiles
setblock 476 51 277 minecraft:cobbled_deepslate
setblock 477 51 276 minecraft:cobbled_deepslate
fill 477 51 277 477 54 277 minecraft:deepslate_tiles
setblock 477 51 316 minecraft:cobbled_deepslate
fill 478 51 276 478 54 276 minecraft:deepslate_tiles
setblock 478 51 315 minecraft:cobbled_deepslate
fill 478 51 316 478 54 316 minecraft:deepslate_tiles
setblock 479 51 315 minecraft:deepslate_tiles
setblock 482 51 276 minecraft:cobbled_deepslate
setblock 482 51 316 minecraft:cobbled_deepslate
fill 483 51 276 486 51 276 minecraft:deepslate_tiles
fill 483 51 316 486 51 316 minecraft:deepslate_tiles
setblock 487 51 276 minecraft:cobbled_deepslate
setblock 487 51 316 minecraft:cobbled_deepslate
fill 488 51 276 488 54 276 minecraft:deepslate_tiles
fill 488 51 316 488 54 316 minecraft:deepslate_tiles
fill 489 51 315 489 54 315 minecraft:deepslate_tiles
setblock 490 51 277 minecraft:deepslate_tiles
setblock 491 51 277 minecraft:cobbled_deepslate
fill 491 51 314 493 51 314 minecraft:deepslate_tiles
setblock 492 51 276 minecraft:cobbled_deepslate
fill 492 51 277 492 54 277 minecraft:deepslate_tiles
setblock 492 51 316 minecraft:cobbled_deepslate
fill 493 51 276 493 54 276 minecraft:deepslate_tiles
setblock 493 51 315 minecraft:cobbled_deepslate
fill 493 51 316 493 54 316 minecraft:deepslate_tiles
setblock 494 51 313 minecraft:deepslate_tiles
setblock 494 51 314 minecraft:cobbled_deepslate
fill 494 51 315 494 54 315 minecraft:deepslate_tiles
setblock 495 51 313 minecraft:cobbled_deepslate
fill 495 51 314 495 54 314 minecraft:deepslate_tiles
setblock 496 51 277 minecraft:cobbled_deepslate
fill 496 51 313 496 52 313 minecraft:deepslate_tiles
setblock 497 51 276 minecraft:cobbled_deepslate
fill 497 51 277 497 54 277 minecraft:deepslate_tiles
setblock 497 51 316 minecraft:cobbled_deepslate
fill 498 51 276 498 54 276 minecraft:deepslate_tiles
setblock 498 51 315 minecraft:cobbled_deepslate
fill 498 51 316 498 54 316 minecraft:deepslate_tiles
setblock 499 51 314 minecraft:cobbled_deepslate
fill 499 51 315 499 54 315 minecraft:deepslate_tiles
fill 500 51 314 500 53 314 minecraft:deepslate_tiles
fill 501 51 317 501 94 317 minecraft:cobbled_deepslate
setblock 502 51 276 minecraft:cobbled_deepslate
setblock 502 51 316 minecraft:cobbled_deepslate
setblock 503 51 315 minecraft:cobbled_deepslate
fill 503 51 316 503 54 316 minecraft:deepslate_tiles
fill 504 51 315 504 52 315 minecraft:deepslate_tiles
setblock 507 51 316 minecraft:cobbled_deepslate
fill 508 51 316 508 54 316 minecraft:deepslate_tiles
setblock 509 51 315 minecraft:deepslate_tiles
setblock 510 51 292 minecraft:deepslate_tiles
setblock 510 51 293 minecraft:cobbled_deepslate
fill 510 51 294 510 54 294 minecraft:deepslate_tiles
setblock 510 51 297 minecraft:deepslate_tiles
setblock 510 51 313 minecraft:cobbled_deepslate
fill 510 51 314 510 53 314 minecraft:deepslate_tiles
fill 511 51 288 511 54 288 minecraft:deepslate_tiles
setblock 511 51 292 minecraft:cobbled_deepslate
fill 511 51 293 511 54 293 minecraft:deepslate_tiles
setblock 511 51 297 minecraft:cobbled_deepslate
fill 511 51 298 511 54 298 minecraft:deepslate_tiles
setblock 511 51 302 minecraft:cobbled_deepslate
fill 511 51 303 511 54 303 minecraft:deepslate_tiles
setblock 511 51 307 minecraft:cobbled_deepslate
fill 511 51 308 511 54 308 minecraft:deepslate_tiles
setblock 511 51 312 minecraft:cobbled_deepslate
fill 511 51 313 511 54 313 minecraft:deepslate_tiles
setblock 471 52 276 minecraft:cobbled_deepslate
fill 471 52 277 471 55 277 minecraft:deepslate_tiles
setblock 471 52 286 minecraft:cobbled_deepslate
fill 471 52 287 471 55 287 minecraft:deepslate_tiles
setblock 471 52 291 minecraft:cobbled_deepslate
fill 471 52 292 471 55 292 minecraft:deepslate_tiles
setblock 471 52 296 minecraft:cobbled_deepslate
fill 471 52 297 471 55 297 minecraft:deepslate_tiles
setblock 471 52 301 minecraft:cobbled_deepslate
fill 471 52 302 471 55 302 minecraft:deepslate_tiles
setblock 471 52 311 minecraft:cobbled_deepslate
fill 471 52 312 471 54 312 minecraft:deepslate_tiles
setblock 471 52 315 minecraft:deepslate_tiles
setblock 471 52 316 minecraft:cobbled_deepslate
fill 472 52 276 472 55 276 minecraft:deepslate_tiles
setblock 472 52 286 minecraft:deepslate_tiles
setblock 472 52 290 minecraft:cobbled_deepslate
fill 472 52 291 472 55 291 minecraft:deepslate_tiles
setblock 472 52 295 minecraft:cobbled_deepslate
fill 472 52 296 472 55 296 minecraft:deepslate_tiles
setblock 472 52 300 minecraft:cobbled_deepslate
fill 472 52 316 472 55 316 minecraft:deepslate_tiles
setblock 473 52 289 minecraft:cobbled_deepslate
fill 473 52 290 473 55 290 minecraft:deepslate_tiles
setblock 473 52 294 minecraft:cobbled_deepslate
fill 473 52 295 473 55 295 minecraft:deepslate_tiles
fill 473 52 315 473 54 315 minecraft:deepslate_tiles
setblock 474 52 277 minecraft:deepslate_tiles
setblock 474 52 293 minecraft:cobbled_deepslate
fill 474 52 294 474 54 294 minecraft:deepslate_tiles
setblock 475 52 277 minecraft:cobbled_deepslate
setblock 476 52 276 minecraft:cobbled_deepslate
fill 476 52 277 476 55 277 minecraft:deepslate_tiles
setblock 476 52 316 minecraft:cobbled_deepslate
fill 477 52 276 477 55 276 minecraft:deepslate_tiles
setblock 477 52 315 minecraft:cobbled_deepslate
fill 477 52 316 477 55 316 minecraft:deepslate_tiles
setblock 478 52 315 minecraft:deepslate_tiles
setblock 481 52 276 minecraft:cobbled_deepslate
setblock 481 52 316 minecraft:cobbled_deepslate
fill 482 52 276 485 52 276 minecraft:deepslate_tiles
fill 482 52 316 485 52 316 minecraft:deepslate_tiles
setblock 486 52 276 minecraft:cobbled_deepslate
setblock 486 52 316 minecraft:cobbled_deepslate
fill 487 52 276 487 55 276 minecraft:deepslate_tiles
fill 487 52 316 487 55 316 minecraft:deepslate_tiles
fill 488 52 315 488 55 315 minecraft:deepslate_tiles
setblock 490 52 277 minecraft:cobbled_deepslate
setblock 491 52 276 minecraft:cobbled_deepslate
fill 491 52 277 491 55 277 minecraft:deepslate_tiles
fill 491 52 314 492 52 314 minecraft:deepslate_tiles
setblock 491 52 316 minecraft:cobbled_deepslate
fill 492 52 276 492 55 276 minecraft:deepslate_tiles
setblock 492 52 315 minecraft:cobbled_deepslate
fill 492 52 316 492 55 316 minecraft:deepslate_tiles
setblock 493 52 314 minecraft:cobbled_deepslate
fill 493 52 315 493 55 315 minecraft:deepslate_tiles
setblock 494 52 313 minecraft:cobbled_deepslate
fill 494 52 314 494 55 314 minecraft:deepslate_tiles
setblock 495 52 277 minecraft:cobbled_deepslate
setblock 495 52 313 minecraft:deepslate_tiles
setblock 496 52 276 minecraft:cobbled_deepslate
fill 496 52 277 496 55 277 minecraft:deepslate_tiles
setblock 496 52 316 minecraft:cobbled_deepslate
fill 497 52 276 497 55 276 minecraft:deepslate_tiles
setblock 497 52 315 minecraft:cobbled_deepslate
fill 497 52 316 497 55 316 minecraft:deepslate_tiles
setblock 498 52 314 minecraft:cobbled_deepslate
fill 498 52 315 498 55 315 minecraft:deepslate_tiles
fill 499 52 314 499 54 314 minecraft:deepslate_tiles
setblock 501 52 276 minecraft:cobbled_deepslate
setblock 501 52 316 minecraft:cobbled_deepslate
setblock 502 52 315 minecraft:cobbled_deepslate
fill 502 52 316 502 55 316 minecraft:deepslate_tiles
fill 503 52 315 503 53 315 minecraft:deepslate_tiles
setblock 506 52 316 minecraft:cobbled_deepslate
fill 507 52 316 507 55 316 minecraft:deepslate_tiles
setblock 510 52 292 minecraft:cobbled_deepslate
fill 510 52 293 510 55 293 minecraft:deepslate_tiles
fill 510 52 295 510 52 296 minecraft:deepslate_tiles
setblock 510 52 297 minecraft:cobbled_deepslate
fill 510 52 298 510 54 299 minecraft:deepslate_tiles
setblock 510 52 312 minecraft:cobbled_deepslate
fill 510 52 313 510 53 313 minecraft:deepslate_tiles
setblock 511 52 291 minecraft:cobbled_deepslate
fill 511 52 292 511 55 292 minecraft:deepslate_tiles
setblock 511 52 295 minecraft:deepslate_tiles
setblock 511 52 296 minecraft:cobbled_deepslate
fill 511 52 297 511 55 297 minecraft:deepslate_tiles
setblock 511 52 301 minecraft:cobbled_deepslate
fill 511 52 302 511 55 302 minecraft:deepslate_tiles
setblock 511 52 306 minecraft:cobbled_deepslate
fill 511 52 307 511 55 307 minecraft:deepslate_tiles
setblock 511 52 311 minecraft:cobbled_deepslate
fill 511 52 312 511 55 312 minecraft:deepslate_tiles
setblock 511 52 316 minecraft:cobbled_deepslate
setblock 512 52 285 minecraft:white_wool
fill 471 53 276 471 56 276 minecraft:deepslate_tiles
fill 471 53 278 471 53 279 minecraft:deepslate_tiles
setblock 471 53 284 minecraft:deepslate_tiles
setblock 471 53 285 minecraft:cobbled_deepslate
fill 471 53 286 471 56 286 minecraft:deepslate_tiles
setblock 471 53 290 minecraft:cobbled_deepslate
fill 471 53 291 471 56 291 minecraft:deepslate_tiles
setblock 471 53 295 minecraft:cobbled_deepslate
fill 471 53 296 471 56 296 minecraft:deepslate_tiles
setblock 471 53 300 minecraft:cobbled_deepslate
fill 471 53 301 471 56 301 minecraft:deepslate_tiles
setblock 471 53 311 minecraft:deepslate_tiles
setblock 471 53 315 minecraft:cobbled_deepslate
fill 471 53 316 471 56 316 minecraft:deepslate_tiles
setblock 472 53 289 minecraft:cobbled_deepslate
fill 472 53 290 472 56 290 minecraft:deepslate_tiles
setblock 472 53 294 minecraft:cobbled_deepslate
fill 472 53 295 472 56 295 minecraft:deepslate_tiles
setblock 472 53 299 minecraft:cobbled_deepslate
fill 472 53 300 472 56 300 minecraft:deepslate_tiles
setblock 473 53 277 minecraft:deepslate_tiles
setblock 473 53 278 minecraft:light[level=13]
setblock 473 53 286 minecraft:light[level=13]
fill 473 53 289 473 54 289 minecraft:deepslate_tiles
setblock 473 53 293 minecraft:cobbled_deepslate
fill 473 53 294 473 56 294 minecraft:deepslate_tiles
setblock 473 53 298 minecraft:cobbled_deepslate
setblock 473 53 302 minecraft:light[level=13]
setblock 473 53 310 minecraft:light[level=13]
setblock 474 53 277 minecraft:cobbled_deepslate
setblock 474 53 292 minecraft:cobbled_deepslate
fill 474 53 293 474 54 293 minecraft:deepslate_tiles
setblock 475 53 276 minecraft:cobbled_deepslate
fill 475 53 277 475 56 277 minecraft:deepslate_tiles
setblock 475 53 316 minecraft:cobbled_deepslate
fill 476 53 276 476 56 276 minecraft:deepslate_tiles
setblock 476 53 315 minecraft:cobbled_deepslate
fill 476 53 316 476 56 316 minecraft:deepslate_tiles
setblock 477 53 315 minecraft:deepslate_tiles
setblock 479 53 277 minecraft:cobbled_deepslate
setblock 480 53 276 minecraft:cobbled_deepslate
setblock 480 53 316 minecraft:cobbled_deepslate
fill 481 53 276 484 53 276 minecraft:deepslate_tiles
setblock 481 53 278 minecraft:light[level=13]
setblock 481 53 286 minecraft:light[level=13]
setblock 481 53 294 minecraft:light[level=13]
setblock 481 53 302 minecraft:light[level=13]
setblock 481 53 310 minecraft:light[level=13]
fill 481 53 316 484 53 316 minecraft:deepslate_tiles
setblock 485 53 276 minecraft:cobbled_deepslate
setblock 485 53 316 minecraft:cobbled_deepslate
fill 486 53 276 486 56 276 minecraft:deepslate_tiles
fill 486 53 316 486 56 316 minecraft:deepslate_tiles
setblock 489 53 277 minecraft:cobbled_deepslate
setblock 489 53 278 minecraft:light[level=13]
setblock 489 53 286 minecraft:light[level=13]
setblock 489 53 294 minecraft:light[level=13]
setblock 489 53 302 minecraft:light[level=13]
setblock 489 53 310 minecraft:light[level=13]
setblock 490 53 276 minecraft:cobbled_deepslate
fill 490 53 277 490 56 277 minecraft:deepslate_tiles
setblock 490 53 316 minecraft:cobbled_deepslate
fill 491 53 276 491 56 276 minecraft:deepslate_tiles
setblock 491 53 314 minecraft:deepslate_tiles
setblock 491 53 315 minecraft:cobbled_deepslate
fill 491 53 316 491 56 316 minecraft:deepslate_tiles
setblock 492 53 314 minecraft:cobbled_deepslate
fill 492 53 315 492 56 315 minecraft:deepslate_tiles
fill 493 53 314 493 56 314 minecraft:deepslate_tiles
setblock 494 53 277 minecraft:cobbled_deepslate
setblock 495 53 276 minecraft:cobbled_deepslate
fill 495 53 277 495 56 277 minecraft:deepslate_tiles
setblock 495 53 316 minecraft:cobbled_deepslate
fill 496 53 276 496 56 276 minecraft:deepslate_tiles
setblock 496 53 315 minecraft:cobbled_deepslate
fill 496 53 316 496 56 316 minecraft:deepslate_tiles
setblock 497 53 278 minecraft:light[level=13]
setblock 497 53 286 minecraft:light[level=13]
setblock 497 53 294 minecraft:light[level=13]
setblock 497 53 302 minecraft:light[level=13]
setblock 497 53 310 minecraft:light[level=13]
setblock 497 53 314 minecraft:cobbled_deepslate
fill 497 53 315 497 56 315 minecraft:deepslate_tiles
fill 498 53 314 498 55 314 minecraft:deepslate_tiles
setblock 500 53 276 minecraft:cobbled_deepslate
setblock 500 53 316 minecraft:cobbled_deepslate
setblock 501 53 276 minecraft:deepslate_tiles
setblock 501 53 315 minecraft:cobbled_deepslate
fill 501 53 316 501 56 316 minecraft:deepslate_tiles
fill 502 53 315 502 54 315 minecraft:deepslate_tiles
setblock 505 53 278 minecraft:light[level=13]
setblock 505 53 286 minecraft:light[level=13]
setblock 505 53 294 minecraft:light[level=13]
setblock 505 53 302 minecraft:light[level=13]
setblock 505 53 310 minecraft:light[level=13]
setblock 505 53 316 minecraft:cobbled_deepslate
fill 506 53 316 506 56 316 minecraft:deepslate_tiles
fill 510 53 292 510 56 292 minecraft:deepslate_tiles
setblock 510 53 295 minecraft:deepslate_tiles
setblock 510 53 296 minecraft:cobbled_deepslate
fill 510 53 297 510 56 297 minecraft:deepslate_tiles
setblock 510 53 300 minecraft:deepslate_tiles
setblock 510 53 316 minecraft:cobbled_deepslate
setblock 511 53 290 minecraft:cobbled_deepslate
fill 511 53 291 511 56 291 minecraft:deepslate_tiles
setblock 511 53 295 minecraft:cobbled_deepslate
fill 511 53 296 511 56 296 minecraft:deepslate_tiles
setblock 511 53 300 minecraft:cobbled_deepslate
fill 511 53 301 511 56 301 minecraft:deepslate_tiles
setblock 511 53 305 minecraft:cobbled_deepslate
fill 511 53 306 511 56 306 minecraft:deepslate_tiles
setblock 511 53 310 minecraft:cobbled_deepslate
fill 511 53 311 511 56 311 minecraft:deepslate_tiles
setblock 511 53 315 minecraft:cobbled_deepslate
fill 511 53 316 511 56 316 minecraft:deepslate_tiles
fill 512 53 285 512 92 285 minecraft:cobbled_deepslate
setblock 471 54 278 minecraft:deepslate_tiles
setblock 471 54 279 minecraft:cobbled_deepslate
fill 471 54 280 471 54 283 minecraft:deepslate_tiles
setblock 471 54 284 minecraft:cobbled_deepslate
fill 471 54 285 471 57 285 minecraft:deepslate_tiles
setblock 471 54 289 minecraft:cobbled_deepslate
fill 471 54 290 471 57 290 minecraft:deepslate_tiles
setblock 471 54 294 minecraft:cobbled_deepslate
fill 471 54 295 471 57 295 minecraft:deepslate_tiles
setblock 471 54 299 minecraft:cobbled_deepslate
fill 471 54 300 471 57 300 minecraft:deepslate_tiles
setblock 471 54 303 minecraft:deepslate_tiles
setblock 471 54 314 minecraft:cobbled_deepslate
fill 471 54 315 471 57 315 minecraft:deepslate_tiles
setblock 472 54 277 minecraft:deepslate_tiles
setblock 472 54 278 minecraft:cobbled_deepslate
setblock 472 54 288 minecraft:cobbled_deepslate
fill 472 54 289 472 57 289 minecraft:deepslate_tiles
setblock 472 54 293 minecraft:cobbled_deepslate
fill 472 54 294 472 57 294 minecraft:deepslate_tiles
setblock 472 54 298 minecraft:cobbled_deepslate
fill 472 54 299 472 57 299 minecraft:deepslate_tiles
setblock 473 54 277 minecraft:cobbled_deepslate
setblock 473 54 292 minecraft:cobbled_deepslate
fill 473 54 293 473 57 293 minecraft:deepslate_tiles
setblock 473 54 297 minecraft:cobbled_deepslate
fill 473 54 298 473 57 298 minecraft:deepslate_tiles
setblock 474 54 276 minecraft:cobbled_deepslate
fill 474 54 277 474 57 277 minecraft:deepslate_tiles
setblock 474 54 316 minecraft:cobbled_deepslate
fill 475 54 276 475 57 276 minecraft:deepslate_tiles
setblock 475 54 315 minecraft:cobbled_deepslate
fill 475 54 316 475 57 316 minecraft:deepslate_tiles
setblock 478 54 277 minecraft:cobbled_deepslate
setblock 479 54 276 minecraft:cobbled_deepslate
fill 479 54 277 479 57 277 minecraft:deepslate_tiles
setblock 479 54 316 minecraft:cobbled_deepslate
fill 480 54 276 483 54 276 minecraft:deepslate_tiles
fill 480 54 316 483 54 316 minecraft:deepslate_tiles
setblock 484 54 276 minecraft:cobbled_deepslate
setblock 484 54 316 minecraft:cobbled_deepslate
fill 485 54 276 485 57 276 minecraft:deepslate_tiles
fill 485 54 316 485 57 316 minecraft:deepslate_tiles
setblock 488 54 277 minecraft:cobbled_deepslate
setblock 489 54 276 minecraft:cobbled_deepslate
fill 489 54 277 489 57 277 minecraft:deepslate_tiles
setblock 489 54 316 minecraft:cobbled_deepslate
fill 490 54 276 490 57 276 minecraft:deepslate_tiles
setblock 490 54 315 minecraft:cobbled_deepslate
fill 490 54 316 490 57 316 minecraft:deepslate_tiles
setblock 491 54 275 minecraft:redstone_block
setblock 491 54 314 minecraft:cobbled_deepslate
fill 491 54 315 491 57 315 minecraft:deepslate_tiles
fill 492 54 314 492 57 314 minecraft:deepslate_tiles
setblock 493 54 277 minecraft:cobbled_deepslate
setblock 494 54 276 minecraft:cobbled_deepslate
fill 494 54 277 494 57 277 minecraft:deepslate_tiles
setblock 494 54 316 minecraft:cobbled_deepslate
fill 495 54 276 495 57 276 minecraft:deepslate_tiles
setblock 495 54 315 minecraft:cobbled_deepslate
fill 495 54 316 495 57 316 minecraft:deepslate_tiles
setblock 496 54 314 minecraft:cobbled_deepslate
fill 496 54 315 496 57 315 minecraft:deepslate_tiles
fill 497 54 314 497 56 314 minecraft:deepslate_tiles
setblock 499 54 276 minecraft:cobbled_deepslate
setblock 499 54 316 minecraft:cobbled_deepslate
fill 500 54 276 500 57 276 minecraft:deepslate_tiles
setblock 500 54 315 minecraft:cobbled_deepslate
fill 500 54 316 500 57 316 minecraft:deepslate_tiles
fill 501 54 315 501 55 315 minecraft:deepslate_tiles
setblock 504 54 316 minecraft:cobbled_deepslate
fill 505 54 316 505 57 316 minecraft:deepslate_tiles
setblock 509 54 316 minecraft:cobbled_deepslate
fill 510 54 291 510 57 291 minecraft:deepslate_tiles
setblock 510 54 295 minecraft:cobbled_deepslate
fill 510 54 296 510 57 296 minecraft:deepslate_tiles
setblock 510 54 300 minecraft:cobbled_deepslate
fill 510 54 301 510 57 301 minecraft:deepslate_tiles
setblock 510 54 315 minecraft:cobbled_deepslate
fill 510 54 316 510 57 316 minecraft:deepslate_tiles
fill 511 54 276 511 56 276 minecraft:deepslate_tiles
setblock 511 54 289 minecraft:cobbled_deepslate
fill 511 54 290 511 57 290 minecraft:deepslate_tiles
setblock 511 54 294 minecraft:cobbled_deepslate
fill 511 54 295 511 57 295 minecraft:deepslate_tiles
setblock 511 54 299 minecraft:cobbled_deepslate
fill 511 54 300 511 57 300 minecraft:deepslate_tiles
setblock 511 54 304 minecraft:cobbled_deepslate
fill 511 54 305 511 57 305 minecraft:deepslate_tiles
setblock 511 54 309 minecraft:cobbled_deepslate
fill 511 54 310 511 57 310 minecraft:deepslate_tiles
setblock 511 54 314 minecraft:cobbled_deepslate
fill 511 54 315 511 57 315 minecraft:deepslate_tiles
fill 470 55 306 470 94 307 minecraft:cobbled_deepslate
setblock 470 55 308 minecraft:redstone_block
fill 470 55 309 470 90 309 minecraft:cobbled_deepslate
setblock 471 55 278 minecraft:cobbled_deepslate
fill 471 55 279 471 55 282 minecraft:deepslate_tiles
setblock 471 55 283 minecraft:cobbled_deepslate
fill 471 55 284 471 58 284 minecraft:deepslate_tiles
setblock 471 55 288 minecraft:cobbled_deepslate
fill 471 55 289 471 58 289 minecraft:deepslate_tiles
setblock 471 55 293 minecraft:cobbled_deepslate
fill 471 55 294 471 58 294 minecraft:deepslate_tiles
setblock 471 55 298 minecraft:cobbled_deepslate
fill 471 55 299 471 58 299 minecraft:deepslate_tiles
setblock 471 55 303 minecraft:cobbled_deepslate
setblock 471 55 313 minecraft:cobbled_deepslate
fill 471 55 314 471 58 314 minecraft:deepslate_tiles
setblock 472 55 277 minecraft:cobbled_deepslate
fill 472 55 278 472 56 280 minecraft:deepslate_tiles
setblock 472 55 286 minecraft:deepslate_tiles
setblock 472 55 287 minecraft:cobbled_deepslate
fill 472 55 288 472 58 288 minecraft:deepslate_tiles
setblock 472 55 292 minecraft:cobbled_deepslate
fill 472 55 293 472 58 293 minecraft:deepslate_tiles
setblock 472 55 297 minecraft:cobbled_deepslate
fill 472 55 298 472 58 298 minecraft:deepslate_tiles
setblock 472 55 301 minecraft:deepslate_tiles
setblock 473 55 276 minecraft:cobbled_deepslate
fill 473 55 277 473 58 277 minecraft:deepslate_tiles
setblock 473 55 278 minecraft:light[level=12]
setblock 473 55 285 minecraft:light[level=12]
setblock 473 55 291 minecraft:cobbled_deepslate
fill 473 55 292 473 58 292 minecraft:deepslate_tiles
setblock 473 55 296 minecraft:cobbled_deepslate
fill 473 55 297 473 58 297 minecraft:deepslate_tiles
fill 473 55 299 473 56 299 minecraft:deepslate_tiles
setblock 473 55 306 minecraft:light[level=12]
setblock 473 55 313 minecraft:light[level=12]
setblock 473 55 316 minecraft:cobbled_deepslate
fill 474 55 276 474 58 276 minecraft:deepslate_tiles
setblock 474 55 315 minecraft:cobbled_deepslate
fill 474 55 316 474 58 316 minecraft:deepslate_tiles
setblock 477 55 277 minecraft:cobbled_deepslate
setblock 478 55 276 minecraft:cobbled_deepslate
fill 478 55 277 478 58 277 minecraft:deepslate_tiles
setblock 478 55 316 minecraft:cobbled_deepslate
fill 479 55 276 482 55 276 minecraft:deepslate_tiles
fill 479 55 316 482 55 316 minecraft:deepslate_tiles
fill 480 55 277 480 56 277 minecraft:deepslate_tiles
setblock 480 55 278 minecraft:light[level=12]
setblock 480 55 285 minecraft:light[level=12]
setblock 480 55 292 minecraft:light[level=12]
setblock 480 55 299 minecraft:light[level=12]
setblock 480 55 306 minecraft:light[level=12]
setblock 480 55 313 minecraft:light[level=12]
setblock 483 55 276 minecraft:cobbled_deepslate
setblock 483 55 316 minecraft:cobbled_deepslate
fill 484 55 276 484 58 276 minecraft:deepslate_tiles
fill 484 55 316 484 58 316 minecraft:deepslate_tiles
setblock 486 55 277 minecraft:deepslate_tiles
setblock 487 55 277 minecraft:cobbled_deepslate
setblock 487 55 278 minecraft:light[level=12]
setblock 487 55 285 minecraft:light[level=12]
setblock 487 55 292 minecraft:light[level=12]
setblock 487 55 299 minecraft:light[level=12]
setblock 487 55 306 minecraft:light[level=12]
setblock 487 55 313 minecraft:light[level=12]
setblock 488 55 276 minecraft:cobbled_deepslate
fill 488 55 277 488 58 277 minecraft:deepslate_tiles
setblock 488 55 316 minecraft:cobbled_deepslate
fill 489 55 276 489 58 276 minecraft:deepslate_tiles
setblock 489 55 315 minecraft:cobbled_deepslate
fill 489 55 316 489 58 316 minecraft:deepslate_tiles
fill 490 55 315 490 58 315 minecraft:deepslate_tiles
fill 491 55 275 491 94 275 minecraft:cobbled_deepslate
fill 491 55 314 491 58 314 minecraft:deepslate_tiles
setblock 492 55 277 minecraft:cobbled_deepslate
fill 492 55 278 493 57 278 minecraft:deepslate_tiles
setblock 493 55 276 minecraft:cobbled_deepslate
fill 493 55 277 493 58 277 minecraft:deepslate_tiles
setblock 493 55 316 minecraft:cobbled_deepslate
fill 494 55 276 494 58 276 minecraft:deepslate_tiles
setblock 494 55 278 minecraft:light[level=12]
setblock 494 55 285 minecraft:light[level=12]
setblock 494 55 292 minecraft:light[level=12]
setblock 494 55 299 minecraft:light[level=12]
setblock 494 55 306 minecraft:light[level=12]
setblock 494 55 313 minecraft:light[level=12]
setblock 494 55 315 minecraft:cobbled_deepslate
fill 494 55 316 494 58 316 minecraft:deepslate_tiles
setblock 495 55 314 minecraft:cobbled_deepslate
fill 495 55 315 495 58 315 minecraft:deepslate_tiles
fill 496 55 314 496 58 314 minecraft:deepslate_tiles
setblock 497 55 277 minecraft:cobbled_deepslate
setblock 498 55 276 minecraft:cobbled_deepslate
setblock 498 55 316 minecraft:cobbled_deepslate
fill 499 55 276 499 58 276 minecraft:deepslate_tiles
setblock 499 55 315 minecraft:cobbled_deepslate
fill 499 55 316 499 58 316 minecraft:deepslate_tiles
fill 500 55 315 500 57 315 minecraft:deepslate_tiles
setblock 501 55 278 minecraft:light[level=12]
setblock 501 55 285 minecraft:light[level=12]
setblock 501 55 292 minecraft:light[level=12]
setblock 501 55 299 minecraft:light[level=12]
setblock 501 55 306 minecraft:light[level=12]
setblock 501 55 313 minecraft:light[level=12]
setblock 503 55 316 minecraft:cobbled_deepslate
fill 504 55 316 504 58 316 minecraft:deepslate_tiles
setblock 508 55 278 minecraft:light[level=12]
setblock 508 55 285 minecraft:light[level=12]
setblock 508 55 292 minecraft:light[level=12]
setblock 508 55 299 minecraft:light[level=12]
setblock 508 55 306 minecraft:light[level=12]
setblock 508 55 313 minecraft:light[level=12]
setblock 508 55 316 minecraft:cobbled_deepslate
fill 509 55 296 509 57 297 minecraft:deepslate_tiles
fill 509 55 316 509 58 316 minecraft:deepslate_tiles
fill 510 55 276 510 57 276 minecraft:deepslate_tiles
setblock 510 55 294 minecraft:cobbled_deepslate
fill 510 55 295 510 58 295 minecraft:deepslate_tiles
setblock 510 55 298 minecraft:deepslate_tiles
setblock 510 55 299 minecraft:cobbled_deepslate
fill 510 55 300 510 58 300 minecraft:deepslate_tiles
fill 510 55 302 510 56 302 minecraft:deepslate_tiles
fill 510 55 315 510 58 315 minecraft:deepslate_tiles
setblock 511 55 277 minecraft:deepslate_tiles
setblock 511 55 278 minecraft:cobbled_deepslate
setblock 511 55 288 minecraft:cobbled_deepslate
fill 511 55 289 511 58 289 minecraft:deepslate_tiles
setblock 511 55 293 minecraft:cobbled_deepslate
fill 511 55 294 511 58 294 minecraft:deepslate_tiles
setblock 511 55 298 minecraft:cobbled_deepslate
fill 511 55 299 511 58 299 minecraft:deepslate_tiles
setblock 511 55 303 minecraft:cobbled_deepslate
fill 511 55 304 511 58 304 minecraft:deepslate_tiles
setblock 511 55 308 minecraft:cobbled_deepslate
fill 511 55 309 511 58 309 minecraft:deepslate_tiles
setblock 511 55 313 minecraft:cobbled_deepslate
fill 511 55 314 511 58 314 minecraft:deepslate_tiles
fill 470 56 278 470 90 279 minecraft:cobbled_deepslate
setblock 470 56 280 minecraft:redstone_block
fill 470 56 281 470 82 281 minecraft:cobbled_deepslate
setblock 470 56 299 minecraft:white_wool
fill 470 56 308 470 90 308 minecraft:cobbled_deepslate
setblock 471 56 277 minecraft:cobbled_deepslate
fill 471 56 278 471 56 281 minecraft:deepslate_tiles
setblock 471 56 282 minecraft:cobbled_deepslate
fill 471 56 283 472 58 283 minecraft:deepslate_tiles
setblock 471 56 287 minecraft:cobbled_deepslate
fill 471 56 288 471 59 288 minecraft:deepslate_tiles
setblock 471 56 292 minecraft:cobbled_deepslate
fill 471 56 293 471 59 293 minecraft:deepslate_tiles
setblock 471 56 297 minecraft:cobbled_deepslate
fill 471 56 298 471 59 298 minecraft:deepslate_tiles
setblock 471 56 302 minecraft:cobbled_deepslate
fill 471 56 303 471 58 304 minecraft:deepslate_tiles
fill 471 56 313 471 59 313 minecraft:deepslate_tiles
setblock 472 56 276 minecraft:cobbled_deepslate
fill 472 56 277 472 59 277 minecraft:deepslate_tiles
setblock 472 56 281 minecraft:cobbled_deepslate
fill 472 56 282 472 59 282 minecraft:deepslate_tiles
fill 472 56 284 472 56 285 minecraft:deepslate_tiles
setblock 472 56 286 minecraft:cobbled_deepslate
fill 472 56 287 472 59 287 minecraft:deepslate_tiles
setblock 472 56 291 minecraft:cobbled_deepslate
fill 472 56 292 472 59 292 minecraft:deepslate_tiles
setblock 472 56 296 minecraft:cobbled_deepslate
fill 472 56 297 472 59 297 minecraft:deepslate_tiles
setblock 472 56 301 minecraft:cobbled_deepslate
fill 472 56 302 472 59 302 minecraft:deepslate_tiles
setblock 472 56 316 minecraft:cobbled_deepslate
fill 473 56 276 473 59 276 minecraft:deepslate_tiles
fill 473 56 278 474 56 278 minecraft:deepslate_tiles
setblock 473 56 290 minecraft:cobbled_deepslate
fill 473 56 291 473 59 291 minecraft:deepslate_tiles
setblock 473 56 295 minecraft:cobbled_deepslate
fill 473 56 296 473 59 296 minecraft:deepslate_tiles
fill 473 56 316 473 59 316 minecraft:deepslate_tiles
setblock 475 56 278 minecraft:cobbled_deepslate
setblock 476 56 277 minecraft:cobbled_deepslate
fill 476 56 278 476 59 278 minecraft:deepslate_tiles
setblock 477 56 276 minecraft:cobbled_deepslate
fill 477 56 277 477 59 277 minecraft:deepslate_tiles
setblock 477 56 316 minecraft:cobbled_deepslate
fill 478 56 276 481 56 276 minecraft:deepslate_tiles
fill 478 56 316 481 56 316 minecraft:deepslate_tiles
setblock 481 56 277 minecraft:cobbled_deepslate
setblock 482 56 276 minecraft:cobbled_deepslate
fill 482 56 277 485 56 277 minecraft:deepslate_tiles
setblock 482 56 316 minecraft:cobbled_deepslate
fill 483 56 276 483 59 276 minecraft:deepslate_tiles
fill 483 56 316 483 59 316 minecraft:deepslate_tiles
fill 484 56 285 485 57 286 minecraft:white_wool
setblock 486 56 277 minecraft:cobbled_deepslate
setblock 487 56 276 minecraft:cobbled_deepslate
fill 487 56 277 487 59 277 minecraft:deepslate_tiles
setblock 487 56 315 minecraft:deepslate_tiles
setblock 487 56 316 minecraft:cobbled_deepslate
fill 488 56 276 488 59 276 minecraft:deepslate_tiles
setblock 488 56 315 minecraft:cobbled_deepslate
fill 488 56 316 488 59 316 minecraft:deepslate_tiles
fill 489 56 315 489 59 315 minecraft:deepslate_tiles
setblock 490 56 278 minecraft:cobbled_deepslate
fill 490 56 314 490 59 314 minecraft:deepslate_tiles
setblock 491 56 277 minecraft:cobbled_deepslate
fill 491 56 278 491 59 278 minecraft:deepslate_tiles
setblock 492 56 276 minecraft:cobbled_deepslate
fill 492 56 277 492 59 277 minecraft:deepslate_tiles
setblock 492 56 316 minecraft:cobbled_deepslate
fill 493 56 276 493 59 276 minecraft:deepslate_tiles
setblock 493 56 315 minecraft:cobbled_deepslate
fill 493 56 316 493 59 316 minecraft:deepslate_tiles
setblock 494 56 278 minecraft:deepslate_tiles
setblock 494 56 314 minecraft:cobbled_deepslate
fill 494 56 315 494 59 315 minecraft:deepslate_tiles
fill 495 56 314 495 59 314 minecraft:deepslate_tiles
setblock 496 56 277 minecraft:cobbled_deepslate
setblock 497 56 276 minecraft:cobbled_deepslate
fill 497 56 277 497 59 277 minecraft:deepslate_tiles
setblock 497 56 316 minecraft:cobbled_deepslate
fill 498 56 276 498 59 276 minecraft:deepslate_tiles
setblock 498 56 315 minecraft:cobbled_deepslate
fill 498 56 316 498 59 316 minecraft:deepslate_tiles
fill 499 56 315 499 58 315 minecraft:deepslate_tiles
setblock 502 56 316 minecraft:cobbled_deepslate
fill 503 56 316 503 59 316 minecraft:deepslate_tiles
setblock 507 56 316 minecraft:cobbled_deepslate
fill 508 56 276 509 58 276 minecraft:deepslate_tiles
fill 508 56 316 508 59 316 minecraft:deepslate_tiles
setblock 509 56 294 minecraft:cobbled_deepslate
fill 509 56 295 509 59 295 minecraft:deepslate_tiles
setblock 509 56 298 minecraft:deepslate_tiles
setblock 509 56 299 minecraft:cobbled_deepslate
fill 509 56 300 509 59 300 minecraft:deepslate_tiles
setblock 510 56 293 minecraft:cobbled_deepslate
fill 510 56 294 510 59 294 minecraft:deepslate_tiles
setblock 510 56 298 minecraft:cobbled_deepslate
fill 510 56 299 510 59 299 minecraft:deepslate_tiles
setblock 510 56 303 minecraft:cobbled_deepslate
fill 510 56 304 510 59 304 minecraft:deepslate_tiles
setblock 511 56 277 minecraft:cobbled_deepslate
fill 511 56 278 511 57 280 minecraft:deepslate_tiles
setblock 511 56 287 minecraft:cobbled_deepslate
fill 511 56 288 511 59 288 minecraft:deepslate_tiles
setblock 511 56 292 minecraft:cobbled_deepslate
fill 511 56 293 511 59 293 minecraft:deepslate_tiles
setblock 511 56 297 minecraft:cobbled_deepslate
fill 511 56 298 511 59 298 minecraft:deepslate_tiles
setblock 511 56 302 minecraft:cobbled_deepslate
fill 511 56 303 511 59 303 minecraft:deepslate_tiles
setblock 511 56 307 minecraft:cobbled_deepslate
fill 511 56 308 511 59 308 minecraft:deepslate_tiles
setblock 511 56 312 minecraft:cobbled_deepslate
fill 511 56 313 511 59 313 minecraft:deepslate_tiles
setblock 512 56 279 minecraft:white_wool
fill 470 57 280 470 94 280 minecraft:cobbled_deepslate
fill 470 57 299 470 91 299 minecraft:cobbled_deepslate
setblock 471 57 276 minecraft:cobbled_deepslate
fill 471 57 277 471 57 280 minecraft:deepslate_tiles
setblock 471 57 281 minecraft:cobbled_deepslate
fill 471 57 282 471 60 282 minecraft:deepslate_tiles
setblock 471 57 286 minecraft:cobbled_deepslate
fill 471 57 287 471 60 287 minecraft:deepslate_tiles
setblock 471 57 291 minecraft:cobbled_deepslate
fill 471 57 292 471 60 292 minecraft:deepslate_tiles
setblock 471 57 296 minecraft:cobbled_deepslate
fill 471 57 297 471 60 297 minecraft:deepslate_tiles
setblock 471 57 301 minecraft:cobbled_deepslate
fill 471 57 302 471 60 302 minecraft:deepslate_tiles
setblock 471 57 305 minecraft:deepslate_tiles
setblock 471 57 316 minecraft:cobbled_deepslate
fill 472 57 276 472 60 276 minecraft:deepslate_tiles
fill 472 57 278 472 57 279 minecraft:deepslate_tiles
setblock 472 57 280 minecraft:cobbled_deepslate
fill 472 57 281 473 59 281 minecraft:deepslate_tiles
setblock 472 57 284 minecraft:deepslate_tiles
setblock 472 57 285 minecraft:cobbled_deepslate
fill 472 57 286 472 60 286 minecraft:deepslate_tiles
setblock 472 57 290 minecraft:cobbled_deepslate
fill 472 57 291 472 60 291 minecraft:deepslate_tiles
setblock 472 57 295 minecraft:cobbled_deepslate
fill 472 57 296 472 60 296 minecraft:deepslate_tiles
setblock 472 57 300 minecraft:cobbled_deepslate
fill 472 57 301 472 60 301 minecraft:deepslate_tiles
fill 472 57 303 472 58 303 minecraft:deepslate_tiles
fill 472 57 316 472 60 316 minecraft:deepslate_tiles
setblock 473 57 278 minecraft:deepslate_tiles
setblock 473 57 279 minecraft:cobbled_deepslate
fill 473 57 280 473 60 280 minecraft:deepslate_tiles
fill 473 57 290 473 58 290 minecraft:deepslate_tiles
setblock 473 57 294 minecraft:cobbled_deepslate
fill 473 57 295 473 60 295 minecraft:deepslate_tiles
setblock 473 57 299 minecraft:cobbled_deepslate
fill 473 57 300 473 60 300 minecraft:deepslate_tiles
fill 473 57 315 473 58 315 minecraft:deepslate_tiles
setblock 474 57 278 minecraft:cobbled_deepslate
setblock 475 57 277 minecraft:cobbled_deepslate
fill 475 57 278 475 60 278 minecraft:deepslate_tiles
setblock 476 57 276 minecraft:cobbled_deepslate
fill 476 57 277 476 60 277 minecraft:deepslate_tiles
setblock 476 57 316 minecraft:cobbled_deepslate
fill 477 57 276 480 57 276 minecraft:deepslate_tiles
fill 477 57 278 477 58 278 minecraft:deepslate_tiles
fill 477 57 316 480 57 316 minecraft:deepslate_tiles
setblock 480 57 277 minecraft:cobbled_deepslate
setblock 481 57 276 minecraft:cobbled_deepslate
fill 481 57 277 484 57 277 minecraft:deepslate_tiles
setblock 481 57 316 minecraft:cobbled_deepslate
fill 482 57 276 482 60 276 minecraft:deepslate_tiles
fill 482 57 316 482 60 316 minecraft:deepslate_tiles
setblock 485 57 277 minecraft:cobbled_deepslate
setblock 486 57 276 minecraft:cobbled_deepslate
fill 486 57 277 486 60 277 minecraft:deepslate_tiles
setblock 486 57 316 minecraft:cobbled_deepslate
fill 487 57 276 487 60 276 minecraft:deepslate_tiles
setblock 487 57 315 minecraft:cobbled_deepslate
fill 487 57 316 487 60 316 minecraft:deepslate_tiles
setblock 488 57 278 minecraft:deepslate_tiles
fill 488 57 315 488 60 315 minecraft:deepslate_tiles
setblock 489 57 278 minecraft:cobbled_deepslate
setblock 490 57 277 minecraft:cobbled_deepslate
fill 490 57 278 490 60 278 minecraft:deepslate_tiles
setblock 491 57 276 minecraft:cobbled_deepslate
fill 491 57 277 491 60 277 minecraft:deepslate_tiles
setblock 491 57 316 minecraft:cobbled_deepslate
fill 492 57 276 492 60 276 minecraft:deepslate_tiles
setblock 492 57 315 minecraft:cobbled_deepslate
fill 492 57 316 492 60 316 minecraft:deepslate_tiles
setblock 493 57 314 minecraft:cobbled_deepslate
fill 493 57 315 493 60 315 minecraft:deepslate_tiles
setblock 494 57 278 minecraft:cobbled_deepslate
fill 494 57 314 494 60 314 minecraft:deepslate_tiles
setblock 495 57 277 minecraft:cobbled_deepslate
setblock 496 57 276 minecraft:cobbled_deepslate
fill 496 57 277 496 60 277 minecraft:deepslate_tiles
setblock 496 57 316 minecraft:cobbled_deepslate
fill 497 57 276 497 60 276 minecraft:deepslate_tiles
setblock 497 57 315 minecraft:cobbled_deepslate
fill 497 57 316 497 60 316 minecraft:deepslate_tiles
fill 498 57 315 498 60 315 minecraft:deepslate_tiles
setblock 501 57 316 minecraft:cobbled_deepslate
fill 502 57 316 502 60 316 minecraft:deepslate_tiles
setblock 502 57 317 minecraft:white_wool
setblock 506 57 316 minecraft:cobbled_deepslate
fill 507 57 276 507 60 276 minecraft:deepslate_tiles
fill 507 57 316 507 60 316 minecraft:deepslate_tiles
fill 509 57 294 509 60 294 minecraft:deepslate_tiles
setblock 509 57 298 minecraft:cobbled_deepslate
fill 509 57 299 509 60 299 minecraft:deepslate_tiles
fill 509 57 301 509 57 302 minecraft:deepslate_tiles
setblock 510 57 277 minecraft:cobbled_deepslate
fill 510 57 290 510 58 290 minecraft:deepslate_tiles
setblock 510 57 292 minecraft:cobbled_deepslate
fill 510 57 293 510 60 293 minecraft:deepslate_tiles
setblock 510 57 297 minecraft:cobbled_deepslate
fill 510 57 298 510 60 298 minecraft:deepslate_tiles
setblock 510 57 302 minecraft:cobbled_deepslate
fill 510 57 303 510 60 303 minecraft:deepslate_tiles
fill 510 57 305 510 58 305 minecraft:deepslate_tiles
setblock 511 57 276 minecraft:cobbled_deepslate
fill 511 57 277 511 60 277 minecraft:deepslate_tiles
setblock 511 57 281 minecraft:cobbled_deepslate
fill 511 57 282 511 57 285 minecraft:deepslate_tiles
setblock 511 57 286 minecraft:cobbled_deepslate
fill 511 57 287 511 60 287 minecraft:deepslate_tiles
setblock 511 57 291 minecraft:cobbled_deepslate
fill 511 57 292 511 60 292 minecraft:deepslate_tiles
setblock 511 57 296 minecraft:cobbled_deepslate
fill 511 57 297 511 60 297 minecraft:deepslate_tiles
setblock 511 57 301 minecraft:cobbled_deepslate
fill 511 57 302 511 60 302 minecraft:deepslate_tiles
setblock 511 57 306 minecraft:cobbled_deepslate
fill 511 57 307 511 60 307 minecraft:deepslate_tiles
setblock 511 57 311 minecraft:cobbled_deepslate
fill 511 57 312 511 60 312 minecraft:deepslate_tiles
setblock 511 57 316 minecraft:cobbled_deepslate
fill 512 57 279 512 95 279 minecraft:cobbled_deepslate
fill 512 57 307 512 90 307 minecraft:cobbled_deepslate
setblock 512 57 308 minecraft:white_wool
fill 512 57 309 512 91 310 minecraft:cobbled_deepslate
fill 471 58 276 471 58 279 minecraft:deepslate_tiles
setblock 471 58 280 minecraft:cobbled_deepslate
fill 471 58 281 471 61 281 minecraft:deepslate_tiles
setblock 471 58 285 minecraft:cobbled_deepslate
fill 471 58 286 471 61 286 minecraft:deepslate_tiles
setblock 471 58 290 minecraft:cobbled_deepslate
fill 471 58 291 471 61 291 minecraft:deepslate_tiles
setblock 471 58 295 minecraft:cobbled_deepslate
fill 471 58 296 471 61 296 minecraft:deepslate_tiles
setblock 471 58 300 minecraft:cobbled_deepslate
fill 471 58 301 471 61 301 minecraft:deepslate_tiles
setblock 471 58 305 minecraft:cobbled_deepslate
fill 471 58 306 471 61 306 minecraft:deepslate_tiles
fill 471 58 312 471 60 312 minecraft:deepslate_tiles
setblock 471 58 315 minecraft:cobbled_deepslate
fill 471 58 316 471 61 316 minecraft:deepslate_tiles
setblock 472 58 278 minecraft:deepslate_tiles
setblock 472 58 279 minecraft:cobbled_deepslate
fill 472 58 280 472 61 280 minecraft:deepslate_tiles
setblock 472 58 284 minecraft:cobbled_deepslate
fill 472 58 285 472 61 285 minecraft:deepslate_tiles
setblock 472 58 289 minecraft:cobbled_deepslate
fill 472 58 290 472 61 290 minecraft:deepslate_tiles
setblock 472 58 294 minecraft:cobbled_deepslate
fill 472 58 295 472 61 295 minecraft:deepslate_tiles
setblock 472 58 299 minecraft:cobbled_deepslate
fill 472 58 300 472 61 300 minecraft:deepslate_tiles
fill 472 58 315 472 59 315 minecraft:deepslate_tiles
setblock 473 58 278 minecraft:cobbled_deepslate
fill 473 58 279 473 61 279 minecraft:deepslate_tiles
setblock 473 58 282 minecraft:deepslate_tiles
setblock 473 58 283 minecraft:cobbled_deepslate
setblock 473 58 293 minecraft:cobbled_deepslate
fill 473 58 294 473 61 294 minecraft:deepslate_tiles
setblock 473 58 298 minecraft:cobbled_deepslate
fill 473 58 299 473 61 299 minecraft:deepslate_tiles
fill 473 58 301 473 59 301 minecraft:deepslate_tiles
setblock 474 58 277 minecraft:cobbled_deepslate
fill 474 58 278 474 61 278 minecraft:deepslate_tiles
setblock 475 58 276 minecraft:cobbled_deepslate
fill 475 58 277 475 61 277 minecraft:deepslate_tiles
setblock 475 58 316 minecraft:cobbled_deepslate
fill 476 58 276 479 58 276 minecraft:deepslate_tiles
fill 476 58 316 479 58 316 minecraft:deepslate_tiles
setblock 478 58 278 minecraft:cobbled_deepslate
setblock 479 58 277 minecraft:cobbled_deepslate
setblock 480 58 276 minecraft:cobbled_deepslate
fill 480 58 277 483 58 277 minecraft:deepslate_tiles
setblock 480 58 316 minecraft:cobbled_deepslate
fill 481 58 276 481 61 276 minecraft:deepslate_tiles
fill 481 58 316 481 61 316 minecraft:deepslate_tiles
setblock 484 58 277 minecraft:cobbled_deepslate
setblock 485 58 276 minecraft:cobbled_deepslate
fill 485 58 277 485 61 277 minecraft:deepslate_tiles
setblock 485 58 316 minecraft:cobbled_deepslate
fill 486 58 276 486 61 276 minecraft:deepslate_tiles
fill 486 58 278 487 58 278 minecraft:deepslate_tiles
setblock 486 58 315 minecraft:cobbled_deepslate
fill 486 58 316 486 61 316 minecraft:deepslate_tiles
fill 487 58 315 487 61 315 minecraft:deepslate_tiles
setblock 488 58 278 minecraft:cobbled_deepslate
setblock 489 58 277 minecraft:cobbled_deepslate
fill 489 58 278 489 61 278 minecraft:deepslate_tiles
fill 489 58 314 489 60 314 minecraft:deepslate_tiles
setblock 490 58 276 minecraft:cobbled_deepslate
fill 490 58 277 490 61 277 minecraft:deepslate_tiles
setblock 490 58 316 minecraft:cobbled_deepslate
fill 491 58 276 491 61 276 minecraft:deepslate_tiles
setblock 491 58 315 minecraft:cobbled_deepslate
fill 491 58 316 491 61 316 minecraft:deepslate_tiles
setblock 492 58 278 minecraft:deepslate_tiles
setblock 492 58 314 minecraft:cobbled_deepslate
fill 492 58 315 492 61 315 minecraft:deepslate_tiles
setblock 493 58 278 minecraft:cobbled_deepslate
fill 493 58 314 493 61 314 minecraft:deepslate_tiles
setblock 494 58 277 minecraft:cobbled_deepslate
fill 494 58 278 495 60 278 minecraft:deepslate_tiles
setblock 495 58 276 minecraft:cobbled_deepslate
fill 495 58 277 495 61 277 minecraft:deepslate_tiles
setblock 495 58 316 minecraft:cobbled_deepslate
fill 496 58 276 496 61 276 minecraft:deepslate_tiles
setblock 496 58 315 minecraft:cobbled_deepslate
fill 496 58 316 496 61 316 minecraft:deepslate_tiles
fill 497 58 315 497 61 315 minecraft:deepslate_tiles
setblock 498 58 277 minecraft:deepslate_tiles
setblock 500 58 276 minecraft:cobbled_deepslate
setblock 500 58 316 minecraft:cobbled_deepslate
fill 501 58 276 501 61 276 minecraft:deepslate_tiles
fill 501 58 316 501 61 316 minecraft:deepslate_tiles
fill 502 58 317 502 94 317 minecraft:cobbled_deepslate
setblock 505 58 276 minecraft:cobbled_deepslate
setblock 505 58 316 minecraft:cobbled_deepslate
fill 506 58 276 506 61 276 minecraft:deepslate_tiles
fill 506 58 316 506 61 316 minecraft:deepslate_tiles
setblock 508 58 298 minecraft:cobbled_deepslate
fill 508 58 299 508 61 299 minecraft:deepslate_tiles
setblock 509 58 277 minecraft:cobbled_deepslate
fill 509 58 293 509 61 293 minecraft:deepslate_tiles
setblock 509 58 296 minecraft:deepslate_tiles
setblock 509 58 297 minecraft:cobbled_deepslate
fill 509 58 298 509 61 298 minecraft:deepslate_tiles
setblock 509 58 301 minecraft:deepslate_tiles
setblock 509 58 302 minecraft:cobbled_deepslate
fill 509 58 303 509 61 303 minecraft:deepslate_tiles
fill 509 58 315 509 59 315 minecraft:deepslate_tiles
setblock 510 58 276 minecraft:cobbled_deepslate
fill 510 58 277 510 58 280 minecraft:deepslate_tiles
setblock 510 58 291 minecraft:cobbled_deepslate
fill 510 58 292 510 61 292 minecraft:deepslate_tiles
setblock 510 58 296 minecraft:cobbled_deepslate
fill 510 58 297 510 61 297 minecraft:deepslate_tiles
setblock 510 58 301 minecraft:cobbled_deepslate
fill 510 58 302 510 61 302 minecraft:deepslate_tiles
setblock 510 58 306 minecraft:cobbled_deepslate
fill 510 58 314 510 59 314 minecraft:deepslate_tiles
setblock 510 58 316 minecraft:cobbled_deepslate
fill 511 58 276 511 61 276 minecraft:deepslate_tiles
fill 511 58 278 511 58 279 minecraft:deepslate_tiles
setblock 511 58 280 minecraft:cobbled_deepslate
fill 511 58 281 511 58 284 minecraft:deepslate_tiles
setblock 511 58 285 minecraft:cobbled_deepslate
fill 511 58 286 511 61 286 minecraft:deepslate_tiles
setblock 511 58 290 minecraft:cobbled_deepslate
fill 511 58 291 511 61 291 minecraft:deepslate_tiles
setblock 511 58 295 minecraft:cobbled_deepslate
fill 511 58 296 511 61 296 minecraft:deepslate_tiles
setblock 511 58 300 minecraft:cobbled_deepslate
fill 511 58 301 511 61 301 minecraft:deepslate_tiles
setblock 511 58 305 minecraft:cobbled_deepslate
fill 511 58 306 511 61 306 minecraft:deepslate_tiles
setblock 511 58 310 minecraft:cobbled_deepslate
fill 511 58 311 511 61 311 minecraft:deepslate_tiles
setblock 511 58 315 minecraft:cobbled_deepslate
fill 511 58 316 511 61 316 minecraft:deepslate_tiles
fill 512 58 308 512 94 308 minecraft:cobbled_deepslate
setblock 470 59 316 minecraft:white_wool
fill 470 59 317 470 90 317 minecraft:cobbled_deepslate
fill 471 59 276 471 59 278 minecraft:deepslate_tiles
setblock 471 59 279 minecraft:cobbled_deepslate
fill 471 59 280 471 62 280 minecraft:deepslate_tiles
setblock 471 59 283 minecraft:deepslate_tiles
setblock 471 59 284 minecraft:cobbled_deepslate
fill 471 59 285 471 62 285 minecraft:deepslate_tiles
setblock 471 59 289 minecraft:cobbled_deepslate
fill 471 59 290 471 62 290 minecraft:deepslate_tiles
setblock 471 59 294 minecraft:cobbled_deepslate
fill 471 59 295 471 62 295 minecraft:deepslate_tiles
setblock 471 59 299 minecraft:cobbled_deepslate
fill 471 59 300 471 62 300 minecraft:deepslate_tiles
setblock 471 59 303 minecraft:deepslate_tiles
setblock 471 59 304 minecraft:cobbled_deepslate
fill 471 59 305 471 62 305 minecraft:deepslate_tiles
fill 471 59 307 471 59 308 minecraft:deepslate_tiles
setblock 471 59 314 minecraft:cobbled_deepslate
fill 471 59 315 471 62 315 minecraft:deepslate_tiles
setblock 472 59 278 minecraft:cobbled_deepslate
fill 472 59 279 472 62 279 minecraft:deepslate_tiles
setblock 472 59 283 minecraft:cobbled_deepslate
fill 472 59 284 473 61 284 minecraft:deepslate_tiles
setblock 472 59 288 minecraft:cobbled_deepslate
fill 472 59 289 472 62 289 minecraft:deepslate_tiles
setblock 472 59 293 minecraft:cobbled_deepslate
fill 472 59 294 472 62 294 minecraft:deepslate_tiles
setblock 472 59 298 minecraft:cobbled_deepslate
fill 472 59 299 472 62 299 minecraft:deepslate_tiles
setblock 472 59 303 minecraft:cobbled_deepslate
fill 472 59 304 472 62 304 minecraft:deepslate_tiles
setblock 473 59 277 minecraft:cobbled_deepslate
fill 473 59 278 473 62 278 minecraft:deepslate_tiles
setblock 473 59 282 minecraft:cobbled_deepslate
fill 473 59 283 473 62 283 minecraft:deepslate_tiles
fill 473 59 285 473 60 285 minecraft:deepslate_tiles
setblock 473 59 292 minecraft:cobbled_deepslate
fill 473 59 293 473 60 293 minecraft:deepslate_tiles
setblock 473 59 297 minecraft:cobbled_deepslate
fill 473 59 298 473 62 298 minecraft:deepslate_tiles
setblock 474 59 276 minecraft:cobbled_deepslate
fill 474 59 277 474 62 277 minecraft:deepslate_tiles
fill 474 59 279 474 59 280 minecraft:deepslate_tiles
setblock 474 59 316 minecraft:cobbled_deepslate
fill 475 59 276 478 59 276 minecraft:deepslate_tiles
setblock 475 59 279 minecraft:deepslate_tiles
fill 475 59 316 478 59 316 minecraft:deepslate_tiles
setblock 477 59 278 minecraft:cobbled_deepslate
setblock 478 59 277 minecraft:cobbled_deepslate
fill 478 59 278 479 61 278 minecraft:deepslate_tiles
setblock 479 59 276 minecraft:cobbled_deepslate
fill 479 59 277 482 59 277 minecraft:deepslate_tiles
setblock 479 59 316 minecraft:cobbled_deepslate
fill 480 59 276 480 62 276 minecraft:deepslate_tiles
fill 480 59 316 480 62 316 minecraft:deepslate_tiles
setblock 483 59 277 minecraft:cobbled_deepslate
fill 483 59 278 486 59 278 minecraft:deepslate_tiles
setblock 484 59 276 minecraft:cobbled_deepslate
fill 484 59 277 484 62 277 minecraft:deepslate_tiles
setblock 484 59 316 minecraft:cobbled_deepslate
fill 485 59 276 485 62 276 minecraft:deepslate_tiles
setblock 485 59 315 minecraft:cobbled_deepslate
fill 485 59 316 485 62 316 minecraft:deepslate_tiles
fill 486 59 315 486 62 315 minecraft:deepslate_tiles
setblock 487 59 278 minecraft:cobbled_deepslate
setblock 488 59 277 minecraft:cobbled_deepslate
fill 488 59 278 488 62 278 minecraft:deepslate_tiles
setblock 489 59 276 minecraft:cobbled_deepslate
fill 489 59 277 489 62 277 minecraft:deepslate_tiles
fill 489 59 279 490 59 279 minecraft:deepslate_tiles
setblock 489 59 316 minecraft:cobbled_deepslate
fill 490 59 276 490 62 276 minecraft:deepslate_tiles
setblock 490 59 315 minecraft:cobbled_deepslate
fill 490 59 316 490 62 316 minecraft:deepslate_tiles
setblock 491 59 279 minecraft:cobbled_deepslate
setblock 491 59 314 minecraft:cobbled_deepslate
fill 491 59 315 491 62 315 minecraft:deepslate_tiles
setblock 492 59 278 minecraft:cobbled_deepslate
fill 492 59 314 492 62 314 minecraft:deepslate_tiles
setblock 493 59 277 minecraft:cobbled_deepslate
fill 493 59 278 493 62 278 minecraft:deepslate_tiles
setblock 494 59 276 minecraft:cobbled_deepslate
fill 494 59 277 494 62 277 minecraft:deepslate_tiles
setblock 494 59 316 minecraft:cobbled_deepslate
fill 495 59 276 495 62 276 minecraft:deepslate_tiles
setblock 495 59 315 minecraft:cobbled_deepslate
fill 495 59 316 495 62 316 minecraft:deepslate_tiles
fill 496 59 315 496 62 315 minecraft:deepslate_tiles
setblock 498 59 277 minecraft:cobbled_deepslate
setblock 499 59 276 minecraft:cobbled_deepslate
setblock 499 59 316 minecraft:cobbled_deepslate
fill 500 59 276 500 61 276 minecraft:deepslate_tiles
fill 500 59 316 500 62 316 minecraft:deepslate_tiles
fill 502 59 276 503 59 276 minecraft:deepslate_tiles
setblock 504 59 276 minecraft:cobbled_deepslate
setblock 504 59 316 minecraft:cobbled_deepslate
fill 505 59 276 505 62 276 minecraft:deepslate_tiles
fill 505 59 316 505 62 316 minecraft:deepslate_tiles
setblock 508 59 276 minecraft:deepslate_tiles
setblock 508 59 277 minecraft:cobbled_deepslate
setblock 508 59 296 minecraft:deepslate_tiles
setblock 508 59 297 minecraft:cobbled_deepslate
fill 508 59 298 508 62 298 minecraft:deepslate_tiles
fill 508 59 300 508 59 301 minecraft:deepslate_tiles
setblock 509 59 276 minecraft:cobbled_deepslate
fill 509 59 277 510 61 277 minecraft:deepslate_tiles
setblock 509 59 296 minecraft:cobbled_deepslate
fill 509 59 297 509 62 297 minecraft:deepslate_tiles
setblock 509 59 301 minecraft:cobbled_deepslate
fill 509 59 302 509 62 302 minecraft:deepslate_tiles
fill 509 59 304 509 60 304 minecraft:deepslate_tiles
setblock 509 59 316 minecraft:cobbled_deepslate
fill 510 59 276 510 62 276 minecraft:deepslate_tiles
fill 510 59 278 510 59 279 minecraft:deepslate_tiles
setblock 510 59 280 minecraft:cobbled_deepslate
fill 510 59 281 510 59 284 minecraft:deepslate_tiles
fill 510 59 288 510 59 289 minecraft:deepslate_tiles
setblock 510 59 290 minecraft:cobbled_deepslate
fill 510 59 291 510 62 291 minecraft:deepslate_tiles
setblock 510 59 295 minecraft:cobbled_deepslate
fill 510 59 296 510 62 296 minecraft:deepslate_tiles
setblock 510 59 300 minecraft:cobbled_deepslate
fill 510 59 301 510 62 301 minecraft:deepslate_tiles
setblock 510 59 305 minecraft:cobbled_deepslate
fill 510 59 306 510 60 308 minecraft:deepslate_tiles
setblock 510 59 315 minecraft:cobbled_deepslate
fill 510 59 316 510 62 316 minecraft:deepslate_tiles
setblock 511 59 278 minecraft:deepslate_tiles
setblock 511 59 279 minecraft:cobbled_deepslate
fill 511 59 280 511 59 283 minecraft:deepslate_tiles
setblock 511 59 284 minecraft:cobbled_deepslate
fill 511 59 285 511 62 285 minecraft:deepslate_tiles
setblock 511 59 289 minecraft:cobbled_deepslate
fill 511 59 290 511 62 290 minecraft:deepslate_tiles
setblock 511 59 294 minecraft:cobbled_deepslate
fill 511 59 295 511 62 295 minecraft:deepslate_tiles
setblock 511 59 299 minecraft:cobbled_deepslate
fill 511 59 300 511 62 300 minecraft:deepslate_tiles
setblock 511 59 304 minecraft:cobbled_deepslate
fill 511 59 305 511 62 305 minecraft:deepslate_tiles
setblock 511 59 309 minecraft:cobbled_deepslate
fill 511 59 310 511 62 310 minecraft:deepslate_tiles
setblock 511 59 314 minecraft:cobbled_deepslate
fill 511 59 315 511 62 315 minecraft:deepslate_tiles
fill 470 60 316 470 80 316 minecraft:cobbled_deepslate
fill 471 60 275 472 91 275 minecraft:cobbled_deepslate
fill 471 60 276 471 60 277 minecraft:deepslate_tiles
setblock 471 60 278 minecraft:cobbled_deepslate
fill 471 60 279 471 62 279 minecraft:deepslate_tiles
setblock 471 60 283 minecraft:cobbled_deepslate
fill 471 60 284 471 62 284 minecraft:deepslate_tiles
setblock 471 60 288 minecraft:cobbled_deepslate
fill 471 60 289 471 62 289 minecraft:deepslate_tiles
setblock 471 60 293 minecraft:cobbled_deepslate
fill 471 60 294 471 62 294 minecraft:deepslate_tiles
setblock 471 60 298 minecraft:cobbled_deepslate
fill 471 60 299 471 62 299 minecraft:deepslate_tiles
setblock 471 60 303 minecraft:cobbled_deepslate
fill 471 60 304 471 62 304 minecraft:deepslate_tiles
setblock 471 60 307 minecraft:deepslate_tiles
setblock 471 60 308 minecraft:cobbled_deepslate
fill 471 60 309 471 62 309 minecraft:deepslate_tiles
setblock 471 60 313 minecraft:cobbled_deepslate
fill 471 60 314 471 62 314 minecraft:deepslate_tiles
setblock 472 60 277 minecraft:cobbled_deepslate
fill 472 60 278 472 62 278 minecraft:deepslate_tiles
setblock 472 60 281 minecraft:deepslate_tiles
setblock 472 60 282 minecraft:cobbled_deepslate
fill 472 60 283 472 62 283 minecraft:deepslate_tiles
setblock 472 60 287 minecraft:cobbled_deepslate
fill 472 60 288 472 62 288 minecraft:deepslate_tiles
setblock 472 60 292 minecraft:cobbled_deepslate
fill 472 60 293 472 62 293 minecraft:deepslate_tiles
setblock 472 60 297 minecraft:cobbled_deepslate
fill 472 60 298 472 62 298 minecraft:deepslate_tiles
setblock 472 60 302 minecraft:cobbled_deepslate
fill 472 60 303 472 62 303 minecraft:deepslate_tiles
fill 472 60 305 472 61 305 minecraft:deepslate_tiles
setblock 473 60 275 minecraft:redstone_block
setblock 473 60 276 minecraft:cobbled_deepslate
fill 473 60 277 473 62 277 minecraft:deepslate_tiles
setblock 473 60 281 minecraft:cobbled_deepslate
fill 473 60 282 473 62 282 minecraft:deepslate_tiles
setblock 473 60 286 minecraft:cobbled_deepslate
setblock 473 60 292 minecraft:deepslate_tiles
setblock 473 60 296 minecraft:cobbled_deepslate
fill 473 60 297 473 62 297 minecraft:deepslate_tiles
setblock 473 60 301 minecraft:cobbled_deepslate
fill 473 60 302 473 61 302 minecraft:deepslate_tiles
setblock 473 60 316 minecraft:cobbled_deepslate
fill 474 60 276 477 60 276 minecraft:deepslate_tiles
setblock 474 60 279 minecraft:deepslate_tiles
setblock 474 60 280 minecraft:cobbled_deepslate
fill 474 60 281 474 62 281 minecraft:deepslate_tiles
fill 474 60 316 477 60 316 minecraft:deepslate_tiles
setblock 475 60 279 minecraft:cobbled_deepslate
setblock 476 60 278 minecraft:cobbled_deepslate
setblock 477 60 277 minecraft:cobbled_deepslate
fill 477 60 278 477 62 278 minecraft:deepslate_tiles
setblock 478 60 276 minecraft:cobbled_deepslate
fill 478 60 277 481 60 277 minecraft:deepslate_tiles
setblock 478 60 316 minecraft:cobbled_deepslate
fill 479 60 276 479 62 276 minecraft:deepslate_tiles
fill 479 60 316 479 61 316 minecraft:deepslate_tiles
setblock 480 60 278 minecraft:deepslate_tiles
setblock 481 60 278 minecraft:cobbled_deepslate
setblock 482 60 277 minecraft:cobbled_deepslate
fill 482 60 278 485 60 278 minecraft:deepslate_tiles
setblock 483 60 276 minecraft:cobbled_deepslate
fill 483 60 277 483 62 277 minecraft:deepslate_tiles
setblock 483 60 316 minecraft:cobbled_deepslate
fill 484 60 276 484 62 276 minecraft:deepslate_tiles
fill 484 60 316 484 62 316 minecraft:deepslate_tiles
fill 485 60 315 485 62 315 minecraft:deepslate_tiles
setblock 486 60 278 minecraft:cobbled_deepslate
setblock 487 60 277 minecraft:cobbled_deepslate
fill 487 60 278 487 62 279 minecraft:deepslate_tiles
setblock 488 60 276 minecraft:cobbled_deepslate
fill 488 60 277 488 62 277 minecraft:deepslate_tiles
fill 488 60 279 489 60 279 minecraft:deepslate_tiles
fill 488 60 314 488 61 314 minecraft:deepslate_tiles
setblock 488 60 316 minecraft:cobbled_deepslate
fill 489 60 276 489 62 276 minecraft:deepslate_tiles
setblock 489 60 315 minecraft:cobbled_deepslate
fill 489 60 316 489 62 316 minecraft:deepslate_tiles
setblock 490 60 279 minecraft:cobbled_deepslate
setblock 490 60 314 minecraft:cobbled_deepslate
fill 490 60 315 490 62 315 minecraft:deepslate_tiles
setblock 491 60 278 minecraft:cobbled_deepslate
fill 491 60 279 492 61 279 minecraft:deepslate_tiles
fill 491 60 314 491 62 314 minecraft:deepslate_tiles
setblock 492 60 277 minecraft:cobbled_deepslate
fill 492 60 278 492 62 278 minecraft:deepslate_tiles
setblock 493 60 276 minecraft:cobbled_deepslate
fill 493 60 277 493 62 277 minecraft:deepslate_tiles
setblock 493 60 316 minecraft:cobbled_deepslate
fill 494 60 276 494 62 276 minecraft:deepslate_tiles
setblock 494 60 315 minecraft:cobbled_deepslate
fill 494 60 316 494 62 316 minecraft:deepslate_tiles
setblock 495 60 314 minecraft:cobbled_deepslate
fill 495 60 315 495 62 315 minecraft:deepslate_tiles
setblock 497 60 277 minecraft:cobbled_deepslate
setblock 498 60 276 minecraft:cobbled_deepslate
setblock 498 60 316 minecraft:cobbled_deepslate
fill 499 60 276 499 62 276 minecraft:deepslate_tiles
fill 499 60 316 499 62 316 minecraft:deepslate_tiles
setblock 502 60 276 minecraft:deepslate_tiles
setblock 503 60 276 minecraft:cobbled_deepslate
setblock 503 60 316 minecraft:cobbled_deepslate
fill 504 60 276 504 62 276 minecraft:deepslate_tiles
fill 504 60 316 504 62 316 minecraft:deepslate_tiles
setblock 507 60 277 minecraft:cobbled_deepslate
setblock 508 60 276 minecraft:cobbled_deepslate
fill 508 60 277 508 62 277 minecraft:deepslate_tiles
setblock 508 60 296 minecraft:cobbled_deepslate
fill 508 60 297 508 62 297 minecraft:deepslate_tiles
setblock 508 60 300 minecraft:deepslate_tiles
setblock 508 60 301 minecraft:cobbled_deepslate
fill 508 60 302 508 62 303 minecraft:deepslate_tiles
setblock 508 60 316 minecraft:cobbled_deepslate
fill 509 60 276 509 62 276 minecraft:deepslate_tiles
fill 509 60 278 509 60 279 minecraft:deepslate_tiles
fill 509 60 292 509 62 292 minecraft:deepslate_tiles
setblock 509 60 295 minecraft:cobbled_deepslate
fill 509 60 296 509 62 296 minecraft:deepslate_tiles
setblock 509 60 300 minecraft:cobbled_deepslate
fill 509 60 301 509 62 301 minecraft:deepslate_tiles
setblock 509 60 305 minecraft:cobbled_deepslate
fill 509 60 306 509 62 306 minecraft:deepslate_tiles
setblock 509 60 315 minecraft:cobbled_deepslate
fill 509 60 316 509 62 316 minecraft:deepslate_tiles
setblock 510 60 278 minecraft:deepslate_tiles
setblock 510 60 279 minecraft:cobbled_deepslate
fill 510 60 280 510 60 283 minecraft:deepslate_tiles
setblock 510 60 284 minecraft:cobbled_deepslate
fill 510 60 285 510 60 288 minecraft:deepslate_tiles
setblock 510 60 289 minecraft:cobbled_deepslate
fill 510 60 290 510 62 290 minecraft:deepslate_tiles
setblock 510 60 294 minecraft:cobbled_deepslate
fill 510 60 295 510 62 295 minecraft:deepslate_tiles
setblock 510 60 299 minecraft:cobbled_deepslate
fill 510 60 300 510 62 300 minecraft:deepslate_tiles
setblock 510 60 304 minecraft:cobbled_deepslate
fill 510 60 305 510 62 305 minecraft:deepslate_tiles
setblock 510 60 309 minecraft:cobbled_deepslate
fill 510 60 315 510 61 315 minecraft:deepslate_tiles
setblock 511 60 278 minecraft:cobbled_deepslate
fill 511 60 279 511 60 282 minecraft:deepslate_tiles
setblock 511 60 283 minecraft:cobbled_deepslate
fill 511 60 284 511 62 284 minecraft:deepslate_tiles
setblock 511 60 288 minecraft:cobbled_deepslate
fill 511 60 289 511 62 289 minecraft:deepslate_tiles
setblock 511 60 293 minecraft:cobbled_deepslate
fill 511 60 294 511 62 294 minecraft:deepslate_tiles
setblock 511 60 298 minecraft:cobbled_deepslate
fill 511 60 299 511 62 299 minecraft:deepslate_tiles
setblock 511 60 303 minecraft:cobbled_deepslate
fill 511 60 304 511 62 304 minecraft:deepslate_tiles
setblock 511 60 308 minecraft:cobbled_deepslate
fill 511 60 309 511 62 309 minecraft:deepslate_tiles
setblock 511 60 313 minecraft:cobbled_deepslate
schedule function dropper:buildpart/70_3 1t
