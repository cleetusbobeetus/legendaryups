setblock 258 203 325 minecraft:mushroom_stem
fill 258 203 326 261 203 326 minecraft:moss_block
setblock 259 203 324 minecraft:mushroom_stem
fill 259 203 325 259 206 325 minecraft:moss_block
setblock 260 203 323 minecraft:mushroom_stem
fill 260 203 324 260 206 324 minecraft:moss_block
setblock 260 203 363 minecraft:mushroom_stem
fill 261 203 323 261 206 323 minecraft:moss_block
setblock 261 203 362 minecraft:mushroom_stem
fill 261 203 363 261 206 363 minecraft:moss_block
setblock 262 203 326 minecraft:mushroom_stem
fill 262 203 362 262 204 362 minecraft:moss_block
setblock 263 203 325 minecraft:mushroom_stem
fill 263 203 326 263 204 326 minecraft:moss_block
setblock 264 203 324 minecraft:mushroom_stem
fill 264 203 325 264 206 325 minecraft:moss_block
setblock 265 203 323 minecraft:mushroom_stem
fill 265 203 324 265 206 324 minecraft:moss_block
setblock 265 203 363 minecraft:mushroom_stem
fill 266 203 323 266 206 323 minecraft:moss_block
fill 266 203 363 266 205 363 minecraft:moss_block
setblock 268 203 325 minecraft:mushroom_stem
setblock 269 203 324 minecraft:mushroom_stem
fill 269 203 325 272 203 325 minecraft:moss_block
setblock 270 203 323 minecraft:mushroom_stem
fill 270 203 324 270 206 324 minecraft:moss_block
setblock 270 203 363 minecraft:mushroom_stem
fill 271 203 323 271 206 323 minecraft:moss_block
setblock 271 203 362 minecraft:mushroom_stem
fill 271 203 363 271 206 363 minecraft:moss_block
fill 272 203 362 272 205 362 minecraft:moss_block
setblock 273 203 325 minecraft:mushroom_stem
setblock 274 203 324 minecraft:mushroom_stem
fill 274 203 325 274 206 325 minecraft:moss_block
setblock 275 203 323 minecraft:mushroom_stem
fill 275 203 324 275 206 324 minecraft:moss_block
setblock 275 203 328 minecraft:mushroom_stem
fill 275 203 329 275 206 329 minecraft:moss_block
setblock 275 203 343 minecraft:mushroom_stem
fill 275 203 344 275 206 344 minecraft:moss_block
setblock 275 203 348 minecraft:mushroom_stem
fill 275 203 349 276 205 349 minecraft:moss_block
setblock 275 203 358 minecraft:mushroom_stem
fill 275 203 359 275 206 359 minecraft:moss_block
setblock 275 203 363 minecraft:mushroom_stem
fill 276 203 323 276 206 323 minecraft:moss_block
setblock 276 203 327 minecraft:mushroom_stem
fill 276 203 328 276 206 328 minecraft:moss_block
setblock 276 203 332 minecraft:mushroom_stem
setblock 276 203 338 minecraft:moss_block
setblock 276 203 342 minecraft:mushroom_stem
fill 276 203 343 276 206 343 minecraft:moss_block
setblock 276 203 346 minecraft:moss_block
setblock 276 203 347 minecraft:mushroom_stem
fill 276 203 348 276 206 348 minecraft:moss_block
fill 276 203 350 276 203 351 minecraft:moss_block
setblock 276 203 352 minecraft:mushroom_stem
fill 276 203 353 276 206 353 minecraft:moss_block
setblock 276 203 357 minecraft:mushroom_stem
fill 276 203 358 276 206 358 minecraft:moss_block
setblock 276 203 362 minecraft:mushroom_stem
fill 276 203 363 276 206 363 minecraft:moss_block
setblock 236 204 326 minecraft:mushroom_stem
fill 236 204 327 236 207 327 minecraft:moss_block
setblock 236 204 331 minecraft:mushroom_stem
setblock 236 204 335 minecraft:red_mushroom_block
fill 236 204 337 236 204 340 minecraft:moss_block
setblock 236 204 341 minecraft:mushroom_stem
fill 236 204 342 236 204 345 minecraft:moss_block
setblock 236 204 346 minecraft:mushroom_stem
fill 236 204 347 236 207 347 minecraft:moss_block
setblock 236 204 351 minecraft:mushroom_stem
fill 236 204 352 236 207 352 minecraft:moss_block
setblock 236 204 356 minecraft:mushroom_stem
fill 236 204 357 236 207 357 minecraft:moss_block
setblock 236 204 361 minecraft:mushroom_stem
fill 236 204 362 236 207 362 minecraft:moss_block
setblock 237 204 325 minecraft:mushroom_stem
fill 237 204 326 237 207 326 minecraft:moss_block
setblock 237 204 340 minecraft:mushroom_stem
fill 237 204 341 237 204 344 minecraft:moss_block
setblock 237 204 345 minecraft:mushroom_stem
fill 237 204 346 237 207 346 minecraft:moss_block
setblock 237 204 350 minecraft:mushroom_stem
fill 237 204 351 237 207 351 minecraft:moss_block
setblock 237 204 355 minecraft:mushroom_stem
fill 237 204 356 237 207 356 minecraft:moss_block
setblock 237 204 360 minecraft:mushroom_stem
fill 237 204 361 237 207 361 minecraft:moss_block
setblock 238 204 324 minecraft:mushroom_stem
setblock 238 204 325 minecraft:moss_block
setblock 238 204 344 minecraft:mushroom_stem
fill 238 204 345 238 207 345 minecraft:moss_block
setblock 238 204 348 minecraft:moss_block
setblock 238 204 349 minecraft:mushroom_stem
fill 238 204 350 238 207 350 minecraft:moss_block
setblock 238 204 354 minecraft:mushroom_stem
fill 238 204 355 238 205 355 minecraft:moss_block
setblock 238 204 359 minecraft:mushroom_stem
setblock 238 204 360 minecraft:moss_block
setblock 239 204 323 minecraft:mushroom_stem
fill 239 204 324 239 206 324 minecraft:moss_block
setblock 239 204 343 minecraft:mushroom_stem
fill 239 204 344 239 205 344 minecraft:moss_block
setblock 239 204 348 minecraft:mushroom_stem
fill 239 204 349 239 207 349 minecraft:moss_block
setblock 239 204 363 minecraft:mushroom_stem
fill 240 204 323 240 207 323 minecraft:moss_block
setblock 240 204 362 minecraft:mushroom_stem
fill 240 204 363 240 207 363 minecraft:moss_block
fill 241 204 362 241 205 362 minecraft:moss_block
setblock 243 204 324 minecraft:mushroom_stem
setblock 244 204 323 minecraft:mushroom_stem
setblock 244 204 363 minecraft:mushroom_stem
fill 245 204 323 247 204 323 minecraft:moss_block
setblock 245 204 363 minecraft:moss_block
setblock 249 204 323 minecraft:mushroom_stem
fill 250 204 323 250 205 323 minecraft:moss_block
setblock 252 204 324 minecraft:moss_block
setblock 252 204 363 minecraft:red_mushroom_block
setblock 253 204 324 minecraft:mushroom_stem
setblock 253 204 363 minecraft:moss_block
setblock 254 204 323 minecraft:mushroom_stem
fill 254 204 324 254 206 325 minecraft:moss_block
setblock 254 204 363 minecraft:mushroom_stem
fill 255 204 323 255 207 323 minecraft:moss_block
fill 255 204 363 255 206 363 minecraft:moss_block
setblock 257 204 324 minecraft:moss_block
setblock 257 204 325 minecraft:mushroom_stem
fill 257 204 326 260 204 326 minecraft:moss_block
setblock 258 204 324 minecraft:mushroom_stem
fill 258 204 325 258 207 325 minecraft:moss_block
setblock 259 204 323 minecraft:mushroom_stem
fill 259 204 324 259 207 324 minecraft:moss_block
setblock 259 204 363 minecraft:mushroom_stem
fill 260 204 323 260 207 323 minecraft:moss_block
setblock 260 204 362 minecraft:mushroom_stem
fill 260 204 363 260 207 363 minecraft:moss_block
setblock 261 204 326 minecraft:mushroom_stem
setblock 261 204 362 minecraft:moss_block
setblock 262 204 325 minecraft:mushroom_stem
fill 262 204 326 262 205 326 minecraft:moss_block
setblock 263 204 324 minecraft:mushroom_stem
fill 263 204 325 263 207 325 minecraft:moss_block
setblock 264 204 323 minecraft:mushroom_stem
fill 264 204 324 264 207 324 minecraft:moss_block
setblock 264 204 363 minecraft:mushroom_stem
fill 265 204 323 265 207 323 minecraft:moss_block
fill 265 204 363 265 205 363 minecraft:moss_block
setblock 267 204 325 minecraft:mushroom_stem
setblock 268 204 324 minecraft:mushroom_stem
setblock 268 204 325 minecraft:moss_block
setblock 269 204 323 minecraft:mushroom_stem
fill 269 204 324 269 207 324 minecraft:moss_block
setblock 269 204 363 minecraft:mushroom_stem
fill 270 204 323 270 207 323 minecraft:moss_block
fill 270 204 363 270 207 363 minecraft:moss_block
setblock 271 204 325 minecraft:moss_block
fill 271 204 332 271 209 332 minecraft:dirt
setblock 272 204 325 minecraft:mushroom_stem
fill 272 204 331 272 209 331 minecraft:dirt
fill 272 204 333 272 209 333 minecraft:dirt
setblock 273 204 324 minecraft:mushroom_stem
fill 273 204 325 273 207 325 minecraft:moss_block
fill 273 204 332 273 209 332 minecraft:dirt
setblock 274 204 323 minecraft:mushroom_stem
fill 274 204 324 274 207 324 minecraft:moss_block
setblock 274 204 327 minecraft:moss_block
setblock 274 204 363 minecraft:mushroom_stem
fill 275 204 323 275 207 323 minecraft:moss_block
setblock 275 204 327 minecraft:mushroom_stem
fill 275 204 328 275 207 328 minecraft:moss_block
setblock 275 204 343 minecraft:moss_block
fill 275 204 345 275 204 346 minecraft:moss_block
setblock 275 204 347 minecraft:mushroom_stem
fill 275 204 348 275 207 348 minecraft:moss_block
fill 275 204 350 275 204 351 minecraft:moss_block
fill 275 204 358 275 205 358 minecraft:moss_block
setblock 275 204 362 minecraft:mushroom_stem
fill 275 204 363 275 207 363 minecraft:moss_block
setblock 276 204 326 minecraft:mushroom_stem
fill 276 204 327 276 207 327 minecraft:moss_block
setblock 276 204 330 minecraft:moss_block
setblock 276 204 331 minecraft:mushroom_stem
fill 276 204 332 276 207 332 minecraft:moss_block
setblock 276 204 341 minecraft:mushroom_stem
fill 276 204 342 276 207 342 minecraft:moss_block
setblock 276 204 346 minecraft:mushroom_stem
fill 276 204 347 276 207 347 minecraft:moss_block
setblock 276 204 350 minecraft:moss_block
setblock 276 204 351 minecraft:mushroom_stem
fill 276 204 352 276 207 352 minecraft:moss_block
setblock 276 204 356 minecraft:mushroom_stem
fill 276 204 357 276 207 357 minecraft:moss_block
setblock 276 204 361 minecraft:mushroom_stem
fill 276 204 362 276 207 362 minecraft:moss_block
fill 235 205 332 235 226 333 minecraft:green_terracotta
setblock 235 205 334 minecraft:shroomlight
fill 235 205 335 235 213 335 minecraft:green_terracotta
setblock 236 205 325 minecraft:mushroom_stem
fill 236 205 326 236 208 326 minecraft:moss_block
setblock 236 205 329 minecraft:moss_block
setblock 236 205 330 minecraft:mushroom_stem
fill 236 205 331 236 207 332 minecraft:moss_block
fill 236 205 338 236 205 339 minecraft:moss_block
setblock 236 205 340 minecraft:mushroom_stem
fill 236 205 341 236 205 344 minecraft:moss_block
setblock 236 205 345 minecraft:mushroom_stem
fill 236 205 346 236 208 346 minecraft:moss_block
setblock 236 205 350 minecraft:mushroom_stem
fill 236 205 351 236 208 351 minecraft:moss_block
setblock 236 205 355 minecraft:mushroom_stem
fill 236 205 356 236 208 356 minecraft:moss_block
setblock 236 205 360 minecraft:mushroom_stem
fill 236 205 361 236 208 361 minecraft:moss_block
setblock 237 205 324 minecraft:mushroom_stem
fill 237 205 325 237 208 325 minecraft:moss_block
setblock 237 205 329 minecraft:mushroom_stem
fill 237 205 340 237 205 343 minecraft:moss_block
setblock 237 205 344 minecraft:mushroom_stem
fill 237 205 345 237 208 345 minecraft:moss_block
setblock 237 205 349 minecraft:mushroom_stem
fill 237 205 350 237 208 350 minecraft:moss_block
setblock 237 205 354 minecraft:mushroom_stem
fill 237 205 355 237 208 355 minecraft:moss_block
setblock 237 205 359 minecraft:mushroom_stem
fill 237 205 360 237 206 360 minecraft:moss_block
setblock 238 205 323 minecraft:mushroom_stem
fill 238 205 324 238 207 324 minecraft:moss_block
setblock 238 205 325 minecraft:light[level=15]
setblock 238 205 333 minecraft:light[level=15]
setblock 238 205 341 minecraft:light[level=15]
setblock 238 205 343 minecraft:mushroom_stem
fill 238 205 344 238 208 344 minecraft:moss_block
setblock 238 205 348 minecraft:mushroom_stem
fill 238 205 349 238 208 349 minecraft:moss_block
setblock 238 205 353 minecraft:mushroom_stem
fill 238 205 354 238 208 354 minecraft:moss_block
setblock 238 205 357 minecraft:light[level=15]
setblock 238 205 363 minecraft:mushroom_stem
fill 239 205 323 239 208 323 minecraft:moss_block
setblock 239 205 347 minecraft:mushroom_stem
fill 239 205 348 239 207 348 minecraft:moss_block
setblock 239 205 362 minecraft:mushroom_stem
fill 239 205 363 239 208 363 minecraft:moss_block
setblock 240 205 362 minecraft:moss_block
setblock 242 205 324 minecraft:mushroom_stem
setblock 243 205 323 minecraft:mushroom_stem
setblock 243 205 363 minecraft:mushroom_stem
setblock 244 205 323 minecraft:moss_block
setblock 246 205 325 minecraft:light[level=15]
setblock 246 205 333 minecraft:light[level=15]
setblock 246 205 341 minecraft:light[level=15]
setblock 246 205 349 minecraft:light[level=15]
setblock 246 205 357 minecraft:light[level=15]
setblock 252 205 324 minecraft:mushroom_stem
setblock 253 205 323 minecraft:mushroom_stem
fill 253 205 324 253 208 324 minecraft:moss_block
fill 253 205 327 253 213 327 minecraft:dirt
fill 254 205 323 254 208 323 minecraft:moss_block
setblock 254 205 341 minecraft:light[level=15]
setblock 254 205 349 minecraft:light[level=15]
setblock 254 205 357 minecraft:light[level=15]
setblock 254 205 363 minecraft:moss_block
setblock 256 205 324 minecraft:moss_block
setblock 256 205 325 minecraft:mushroom_stem
fill 256 205 326 259 205 326 minecraft:moss_block
setblock 257 205 324 minecraft:mushroom_stem
fill 257 205 325 257 208 325 minecraft:moss_block
setblock 258 205 323 minecraft:mushroom_stem
fill 258 205 324 258 208 324 minecraft:moss_block
setblock 258 205 363 minecraft:mushroom_stem
fill 259 205 323 259 208 323 minecraft:moss_block
fill 259 205 363 259 207 363 minecraft:moss_block
setblock 260 205 322 minecraft:red_mushroom_block
setblock 260 205 326 minecraft:mushroom_stem
setblock 261 205 325 minecraft:mushroom_stem
fill 261 205 326 261 206 326 minecraft:moss_block
setblock 262 205 324 minecraft:mushroom_stem
fill 262 205 325 262 207 325 minecraft:moss_block
setblock 262 205 333 minecraft:light[level=15]
setblock 262 205 341 minecraft:light[level=15]
setblock 262 205 349 minecraft:light[level=15]
setblock 262 205 357 minecraft:light[level=15]
setblock 263 205 323 minecraft:mushroom_stem
fill 263 205 324 263 208 324 minecraft:moss_block
setblock 263 205 363 minecraft:mushroom_stem
fill 264 205 323 264 208 323 minecraft:moss_block
fill 264 205 363 264 206 363 minecraft:moss_block
setblock 266 205 325 minecraft:mushroom_stem
setblock 267 205 324 minecraft:mushroom_stem
setblock 268 205 323 minecraft:mushroom_stem
fill 268 205 324 268 207 324 minecraft:moss_block
setblock 268 205 363 minecraft:mushroom_stem
fill 269 205 323 269 208 323 minecraft:moss_block
fill 269 205 363 269 206 363 minecraft:moss_block
setblock 270 205 325 minecraft:light[level=15]
setblock 270 205 333 minecraft:light[level=15]
setblock 270 205 341 minecraft:light[level=15]
setblock 270 205 349 minecraft:light[level=15]
setblock 270 205 357 minecraft:light[level=15]
setblock 271 205 322 minecraft:red_mushroom_block
setblock 272 205 324 minecraft:mushroom_stem
fill 272 205 325 272 206 325 minecraft:moss_block
setblock 273 205 323 minecraft:mushroom_stem
fill 273 205 324 273 208 324 minecraft:moss_block
setblock 273 205 363 minecraft:mushroom_stem
fill 274 205 323 274 208 323 minecraft:moss_block
setblock 274 205 327 minecraft:mushroom_stem
setblock 274 205 362 minecraft:mushroom_stem
fill 274 205 363 274 208 363 minecraft:moss_block
setblock 275 205 326 minecraft:mushroom_stem
fill 275 205 327 275 208 327 minecraft:moss_block
setblock 275 205 330 minecraft:moss_block
setblock 275 205 345 minecraft:moss_block
setblock 275 205 346 minecraft:mushroom_stem
fill 275 205 347 275 208 347 minecraft:moss_block
setblock 275 205 350 minecraft:moss_block
setblock 275 205 351 minecraft:mushroom_stem
fill 275 205 352 275 207 353 minecraft:moss_block
setblock 275 205 361 minecraft:mushroom_stem
fill 275 205 362 275 208 362 minecraft:moss_block
setblock 276 205 325 minecraft:mushroom_stem
fill 276 205 326 276 208 326 minecraft:moss_block
setblock 276 205 330 minecraft:mushroom_stem
fill 276 205 331 276 208 331 minecraft:moss_block
setblock 276 205 340 minecraft:mushroom_stem
fill 276 205 341 276 206 341 minecraft:moss_block
setblock 276 205 345 minecraft:mushroom_stem
fill 276 205 346 276 208 346 minecraft:moss_block
setblock 276 205 350 minecraft:mushroom_stem
fill 276 205 351 276 208 351 minecraft:moss_block
setblock 276 205 355 minecraft:mushroom_stem
fill 276 205 356 276 208 356 minecraft:moss_block
setblock 276 205 360 minecraft:mushroom_stem
fill 276 205 361 276 208 361 minecraft:moss_block
fill 235 206 334 235 224 334 minecraft:green_terracotta
setblock 236 206 324 minecraft:mushroom_stem
fill 236 206 325 236 209 325 minecraft:moss_block
setblock 236 206 328 minecraft:moss_block
setblock 236 206 329 minecraft:mushroom_stem
fill 236 206 330 236 209 330 minecraft:moss_block
setblock 236 206 338 minecraft:moss_block
setblock 236 206 339 minecraft:mushroom_stem
fill 236 206 340 236 206 343 minecraft:moss_block
setblock 236 206 344 minecraft:mushroom_stem
fill 236 206 345 236 209 345 minecraft:moss_block
setblock 236 206 349 minecraft:mushroom_stem
fill 236 206 350 236 209 350 minecraft:moss_block
setblock 236 206 354 minecraft:mushroom_stem
fill 236 206 355 236 209 355 minecraft:moss_block
setblock 236 206 359 minecraft:mushroom_stem
fill 236 206 360 236 209 360 minecraft:moss_block
setblock 237 206 323 minecraft:mushroom_stem
fill 237 206 324 237 207 324 minecraft:moss_block
setblock 237 206 328 minecraft:mushroom_stem
fill 237 206 329 237 207 329 minecraft:moss_block
fill 237 206 341 237 206 342 minecraft:moss_block
setblock 237 206 343 minecraft:mushroom_stem
fill 237 206 344 237 209 344 minecraft:moss_block
setblock 237 206 348 minecraft:mushroom_stem
fill 237 206 349 237 209 349 minecraft:moss_block
setblock 237 206 353 minecraft:mushroom_stem
fill 237 206 354 237 209 354 minecraft:moss_block
setblock 237 206 358 minecraft:mushroom_stem
fill 237 206 359 237 207 359 minecraft:moss_block
setblock 237 206 363 minecraft:mushroom_stem
fill 238 206 323 238 209 323 minecraft:moss_block
fill 238 206 343 238 207 343 minecraft:moss_block
setblock 238 206 347 minecraft:mushroom_stem
fill 238 206 348 238 209 348 minecraft:moss_block
setblock 238 206 351 minecraft:moss_block
setblock 238 206 352 minecraft:mushroom_stem
fill 238 206 353 238 209 353 minecraft:moss_block
setblock 238 206 362 minecraft:mushroom_stem
fill 238 206 363 238 209 363 minecraft:moss_block
setblock 239 206 346 minecraft:mushroom_stem
fill 239 206 347 239 207 347 minecraft:moss_block
setblock 239 206 351 minecraft:mushroom_stem
setblock 239 206 362 minecraft:moss_block
setblock 242 206 323 minecraft:mushroom_stem
setblock 242 206 363 minecraft:mushroom_stem
setblock 243 206 323 minecraft:moss_block
setblock 244 206 327 minecraft:shroomlight
fill 245 206 363 245 207 363 minecraft:red_mushroom_block
fill 246 206 356 250 207 360 minecraft:dirt
setblock 248 206 323 minecraft:red_mushroom_block
fill 248 206 361 248 206 362 minecraft:dirt
setblock 252 206 323 minecraft:mushroom_stem
fill 252 206 324 252 209 324 minecraft:moss_block
fill 253 206 323 253 209 323 minecraft:moss_block
setblock 255 206 324 minecraft:moss_block
setblock 255 206 325 minecraft:mushroom_stem
setblock 256 206 324 minecraft:mushroom_stem
fill 256 206 325 256 208 326 minecraft:moss_block
setblock 257 206 323 minecraft:mushroom_stem
fill 257 206 324 257 209 324 minecraft:moss_block
fill 257 206 326 258 206 326 minecraft:moss_block
setblock 257 206 363 minecraft:mushroom_stem
fill 258 206 323 258 209 323 minecraft:moss_block
fill 258 206 363 258 208 363 minecraft:moss_block
setblock 259 206 326 minecraft:mushroom_stem
fill 260 206 322 260 225 322 minecraft:green_terracotta
setblock 260 206 325 minecraft:mushroom_stem
fill 260 206 326 260 207 326 minecraft:moss_block
setblock 261 206 324 minecraft:mushroom_stem
fill 261 206 325 261 208 325 minecraft:moss_block
setblock 262 206 323 minecraft:mushroom_stem
fill 262 206 324 262 209 324 minecraft:moss_block
setblock 262 206 363 minecraft:mushroom_stem
fill 263 206 323 263 209 323 minecraft:moss_block
setblock 263 206 363 minecraft:moss_block
setblock 266 206 324 minecraft:mushroom_stem
setblock 267 206 323 minecraft:mushroom_stem
fill 267 206 324 267 207 324 minecraft:moss_block
fill 268 206 323 268 209 323 minecraft:moss_block
fill 271 206 322 271 218 322 minecraft:green_terracotta
setblock 271 206 324 minecraft:mushroom_stem
fill 271 206 331 271 209 331 minecraft:dirt
fill 271 206 333 271 209 333 minecraft:dirt
setblock 272 206 323 minecraft:mushroom_stem
fill 272 206 324 272 209 324 minecraft:moss_block
setblock 272 206 363 minecraft:mushroom_stem
fill 273 206 323 273 209 323 minecraft:moss_block
fill 273 206 331 273 209 331 minecraft:dirt
fill 273 206 333 273 209 333 minecraft:dirt
setblock 273 206 362 minecraft:mushroom_stem
fill 273 206 363 273 209 363 minecraft:moss_block
setblock 274 206 326 minecraft:mushroom_stem
fill 274 206 327 274 207 327 minecraft:moss_block
fill 274 206 362 274 209 362 minecraft:moss_block
setblock 275 206 325 minecraft:mushroom_stem
fill 275 206 326 275 209 326 minecraft:moss_block
setblock 275 206 330 minecraft:mushroom_stem
setblock 275 206 345 minecraft:mushroom_stem
fill 275 206 346 275 209 346 minecraft:moss_block
setblock 275 206 349 minecraft:moss_block
setblock 275 206 350 minecraft:mushroom_stem
fill 275 206 351 275 209 351 minecraft:moss_block
setblock 275 206 354 minecraft:moss_block
setblock 275 206 355 minecraft:mushroom_stem
setblock 275 206 360 minecraft:mushroom_stem
fill 275 206 361 275 209 361 minecraft:moss_block
setblock 276 206 324 minecraft:mushroom_stem
fill 276 206 325 276 209 325 minecraft:moss_block
setblock 276 206 329 minecraft:mushroom_stem
fill 276 206 330 276 209 330 minecraft:moss_block
setblock 276 206 339 minecraft:red_mushroom_block
setblock 276 206 344 minecraft:mushroom_stem
fill 276 206 345 276 209 345 minecraft:moss_block
setblock 276 206 349 minecraft:mushroom_stem
fill 276 206 350 276 209 350 minecraft:moss_block
setblock 276 206 354 minecraft:mushroom_stem
fill 276 206 355 276 209 355 minecraft:moss_block
setblock 276 206 359 minecraft:mushroom_stem
fill 276 206 360 276 209 360 minecraft:moss_block
setblock 235 207 349 minecraft:red_mushroom_block
setblock 236 207 323 minecraft:mushroom_stem
fill 236 207 324 236 210 324 minecraft:moss_block
setblock 236 207 328 minecraft:mushroom_stem
fill 236 207 329 236 210 329 minecraft:moss_block
fill 236 207 334 236 208 334 minecraft:red_mushroom_block
fill 236 207 339 236 207 342 minecraft:moss_block
setblock 236 207 343 minecraft:mushroom_stem
fill 236 207 344 236 210 344 minecraft:moss_block
setblock 236 207 348 minecraft:mushroom_stem
fill 236 207 349 236 210 349 minecraft:moss_block
setblock 236 207 353 minecraft:mushroom_stem
fill 236 207 354 236 210 354 minecraft:moss_block
setblock 236 207 358 minecraft:mushroom_stem
fill 236 207 359 236 210 359 minecraft:moss_block
setblock 236 207 363 minecraft:mushroom_stem
fill 237 207 323 237 210 323 minecraft:moss_block
setblock 237 207 327 minecraft:mushroom_stem
fill 237 207 328 237 210 328 minecraft:moss_block
setblock 237 207 341 minecraft:moss_block
setblock 237 207 342 minecraft:mushroom_stem
fill 237 207 343 237 210 343 minecraft:moss_block
setblock 237 207 347 minecraft:mushroom_stem
fill 237 207 348 237 210 348 minecraft:moss_block
setblock 237 207 352 minecraft:mushroom_stem
fill 237 207 353 237 210 353 minecraft:moss_block
setblock 237 207 357 minecraft:mushroom_stem
setblock 237 207 358 minecraft:moss_block
setblock 237 207 362 minecraft:mushroom_stem
fill 237 207 363 237 210 363 minecraft:moss_block
setblock 238 207 325 minecraft:light[level=12]
setblock 238 207 332 minecraft:light[level=12]
setblock 238 207 339 minecraft:light[level=12]
setblock 238 207 346 minecraft:mushroom_stem
fill 238 207 347 238 210 347 minecraft:moss_block
setblock 238 207 351 minecraft:mushroom_stem
fill 238 207 352 238 210 352 minecraft:moss_block
setblock 238 207 360 minecraft:light[level=12]
setblock 239 207 346 minecraft:moss_block
setblock 239 207 350 minecraft:mushroom_stem
setblock 241 207 323 minecraft:mushroom_stem
setblock 242 207 323 minecraft:red_mushroom_block
fill 244 207 327 244 211 327 minecraft:mushroom_stem
setblock 245 207 325 minecraft:light[level=12]
setblock 245 207 332 minecraft:light[level=12]
setblock 245 207 339 minecraft:light[level=12]
setblock 245 207 346 minecraft:light[level=12]
setblock 245 207 353 minecraft:light[level=12]
setblock 245 207 360 minecraft:light[level=12]
setblock 251 207 323 minecraft:mushroom_stem
setblock 251 207 363 minecraft:red_mushroom_block
fill 252 207 323 252 210 323 minecraft:moss_block
setblock 252 207 325 minecraft:light[level=12]
setblock 252 207 332 minecraft:light[level=12]
setblock 252 207 346 minecraft:light[level=12]
setblock 252 207 353 minecraft:light[level=12]
setblock 252 207 360 minecraft:light[level=12]
setblock 254 207 324 minecraft:moss_block
setblock 254 207 325 minecraft:mushroom_stem
setblock 255 207 324 minecraft:mushroom_stem
fill 255 207 325 255 210 325 minecraft:moss_block
setblock 256 207 323 minecraft:mushroom_stem
fill 256 207 324 256 210 324 minecraft:moss_block
setblock 256 207 363 minecraft:mushroom_stem
fill 257 207 323 257 210 323 minecraft:moss_block
setblock 257 207 326 minecraft:moss_block
fill 257 207 363 257 208 363 minecraft:moss_block
setblock 258 207 326 minecraft:mushroom_stem
setblock 259 207 325 minecraft:mushroom_stem
setblock 259 207 326 minecraft:moss_block
setblock 259 207 332 minecraft:light[level=12]
setblock 259 207 339 minecraft:light[level=12]
setblock 259 207 346 minecraft:light[level=12]
setblock 259 207 353 minecraft:light[level=12]
setblock 259 207 360 minecraft:light[level=12]
setblock 260 207 324 minecraft:mushroom_stem
fill 260 207 325 260 209 325 minecraft:moss_block
setblock 261 207 323 minecraft:mushroom_stem
fill 261 207 324 261 210 324 minecraft:moss_block
setblock 261 207 363 minecraft:mushroom_stem
fill 262 207 323 262 210 323 minecraft:moss_block
setblock 265 207 324 minecraft:mushroom_stem
setblock 266 207 323 minecraft:mushroom_stem
setblock 266 207 324 minecraft:moss_block
setblock 266 207 325 minecraft:light[level=12]
setblock 266 207 332 minecraft:light[level=12]
setblock 266 207 339 minecraft:light[level=12]
setblock 266 207 346 minecraft:light[level=12]
setblock 266 207 353 minecraft:light[level=12]
setblock 266 207 360 minecraft:light[level=12]
fill 267 207 323 267 210 323 minecraft:moss_block
setblock 270 207 324 minecraft:mushroom_stem
setblock 271 207 323 minecraft:mushroom_stem
fill 271 207 324 271 210 324 minecraft:moss_block
setblock 271 207 363 minecraft:mushroom_stem
fill 272 207 323 272 210 323 minecraft:moss_block
fill 272 207 363 272 210 363 minecraft:moss_block
setblock 273 207 339 minecraft:light[level=12]
setblock 273 207 346 minecraft:light[level=12]
setblock 273 207 353 minecraft:light[level=12]
setblock 273 207 360 minecraft:light[level=12]
setblock 273 207 362 minecraft:moss_block
setblock 274 207 325 minecraft:mushroom_stem
fill 274 207 326 274 208 326 minecraft:moss_block
setblock 275 207 324 minecraft:mushroom_stem
fill 275 207 325 275 210 325 minecraft:moss_block
setblock 275 207 329 minecraft:mushroom_stem
fill 275 207 330 275 210 330 minecraft:moss_block
fill 275 207 345 275 208 345 minecraft:moss_block
setblock 275 207 349 minecraft:mushroom_stem
fill 275 207 350 275 210 350 minecraft:moss_block
setblock 275 207 354 minecraft:mushroom_stem
fill 275 207 355 275 209 356 minecraft:moss_block
setblock 275 207 359 minecraft:mushroom_stem
fill 275 207 360 275 210 360 minecraft:moss_block
setblock 276 207 323 minecraft:mushroom_stem
fill 276 207 324 276 210 324 minecraft:moss_block
setblock 276 207 328 minecraft:mushroom_stem
fill 276 207 329 276 210 329 minecraft:moss_block
setblock 276 207 333 minecraft:red_mushroom_block
setblock 276 207 343 minecraft:mushroom_stem
fill 276 207 344 276 210 344 minecraft:moss_block
setblock 276 207 348 minecraft:mushroom_stem
fill 276 207 349 276 210 349 minecraft:moss_block
setblock 276 207 353 minecraft:mushroom_stem
fill 276 207 354 276 210 354 minecraft:moss_block
setblock 276 207 358 minecraft:mushroom_stem
fill 276 207 359 276 210 359 minecraft:moss_block
setblock 276 207 363 minecraft:mushroom_stem
fill 235 208 349 235 224 349 minecraft:green_terracotta
setblock 235 208 363 minecraft:shroomlight
fill 235 208 364 235 224 364 minecraft:green_terracotta
fill 236 208 323 236 211 323 minecraft:moss_block
setblock 236 208 327 minecraft:mushroom_stem
fill 236 208 328 236 211 328 minecraft:moss_block
setblock 236 208 331 minecraft:moss_block
setblock 236 208 332 minecraft:mushroom_stem
fill 236 208 333 236 211 333 minecraft:moss_block
fill 236 208 340 236 208 341 minecraft:moss_block
setblock 236 208 342 minecraft:mushroom_stem
fill 236 208 343 236 211 343 minecraft:moss_block
setblock 236 208 347 minecraft:mushroom_stem
fill 236 208 348 236 211 348 minecraft:moss_block
setblock 236 208 352 minecraft:mushroom_stem
fill 236 208 353 236 211 353 minecraft:moss_block
setblock 236 208 357 minecraft:mushroom_stem
fill 236 208 358 236 211 358 minecraft:moss_block
setblock 236 208 362 minecraft:mushroom_stem
fill 236 208 363 236 211 363 minecraft:moss_block
setblock 237 208 326 minecraft:mushroom_stem
fill 237 208 327 237 209 327 minecraft:moss_block
setblock 237 208 342 minecraft:moss_block
setblock 237 208 346 minecraft:mushroom_stem
fill 237 208 347 237 211 347 minecraft:moss_block
setblock 237 208 351 minecraft:mushroom_stem
fill 237 208 352 237 211 352 minecraft:moss_block
setblock 237 208 356 minecraft:mushroom_stem
fill 237 208 357 237 211 357 minecraft:moss_block
setblock 238 208 345 minecraft:mushroom_stem
fill 238 208 346 238 210 346 minecraft:moss_block
setblock 238 208 350 minecraft:mushroom_stem
fill 238 208 351 238 211 351 minecraft:moss_block
setblock 239 208 349 minecraft:mushroom_stem
fill 247 208 358 249 214 358 minecraft:mushroom_stem
fill 248 208 357 248 214 357 minecraft:mushroom_stem
fill 248 208 359 248 214 359 minecraft:mushroom_stem
setblock 249 208 364 minecraft:red_mushroom_block
fill 251 208 323 251 211 323 minecraft:moss_block
setblock 254 208 324 minecraft:mushroom_stem
fill 254 208 325 254 211 325 minecraft:moss_block
setblock 255 208 323 minecraft:mushroom_stem
fill 255 208 324 255 211 324 minecraft:moss_block
fill 256 208 323 256 211 323 minecraft:moss_block
setblock 257 208 326 minecraft:mushroom_stem
setblock 258 208 325 minecraft:mushroom_stem
setblock 258 208 326 minecraft:moss_block
setblock 259 208 324 minecraft:mushroom_stem
fill 259 208 325 259 210 325 minecraft:moss_block
setblock 260 208 323 minecraft:mushroom_stem
fill 260 208 324 260 211 324 minecraft:moss_block
fill 261 208 323 261 211 323 minecraft:moss_block
setblock 264 208 324 minecraft:mushroom_stem
setblock 265 208 323 minecraft:mushroom_stem
setblock 265 208 324 minecraft:moss_block
fill 266 208 323 266 211 323 minecraft:moss_block
setblock 269 208 324 minecraft:mushroom_stem
setblock 270 208 323 minecraft:mushroom_stem
fill 270 208 324 270 209 324 minecraft:moss_block
setblock 270 208 363 minecraft:mushroom_stem
fill 271 208 323 271 211 323 minecraft:moss_block
fill 271 208 363 271 211 363 minecraft:moss_block
setblock 274 208 322 minecraft:shroomlight
setblock 274 208 324 minecraft:mushroom_stem
setblock 274 208 325 minecraft:moss_block
setblock 275 208 323 minecraft:mushroom_stem
fill 275 208 324 275 211 324 minecraft:moss_block
setblock 275 208 328 minecraft:mushroom_stem
fill 275 208 329 275 211 329 minecraft:moss_block
setblock 275 208 348 minecraft:mushroom_stem
fill 275 208 349 275 211 349 minecraft:moss_block
setblock 275 208 352 minecraft:moss_block
setblock 275 208 353 minecraft:mushroom_stem
fill 275 208 354 275 211 354 minecraft:moss_block
setblock 275 208 357 minecraft:moss_block
setblock 275 208 358 minecraft:mushroom_stem
fill 275 208 359 275 211 359 minecraft:moss_block
setblock 275 208 363 minecraft:mushroom_stem
fill 276 208 323 276 211 323 minecraft:moss_block
setblock 276 208 327 minecraft:mushroom_stem
fill 276 208 328 276 211 328 minecraft:moss_block
setblock 276 208 332 minecraft:mushroom_stem
setblock 276 208 342 minecraft:mushroom_stem
fill 276 208 343 276 211 343 minecraft:moss_block
setblock 276 208 347 minecraft:mushroom_stem
fill 276 208 348 276 211 348 minecraft:moss_block
setblock 276 208 352 minecraft:mushroom_stem
fill 276 208 353 276 211 353 minecraft:moss_block
setblock 276 208 357 minecraft:mushroom_stem
fill 276 208 358 276 211 358 minecraft:moss_block
setblock 276 208 362 minecraft:mushroom_stem
fill 276 208 363 276 211 363 minecraft:moss_block
setblock 277 208 327 minecraft:red_mushroom_block
fill 235 209 363 235 228 363 minecraft:green_terracotta
setblock 236 209 326 minecraft:mushroom_stem
fill 236 209 327 236 212 327 minecraft:moss_block
setblock 236 209 331 minecraft:mushroom_stem
fill 236 209 332 236 212 332 minecraft:moss_block
fill 236 209 334 236 210 334 minecraft:moss_block
setblock 236 209 340 minecraft:moss_block
setblock 236 209 341 minecraft:mushroom_stem
fill 236 209 342 236 212 342 minecraft:moss_block
setblock 236 209 346 minecraft:mushroom_stem
fill 236 209 347 236 212 347 minecraft:moss_block
setblock 236 209 351 minecraft:mushroom_stem
fill 236 209 352 236 212 352 minecraft:moss_block
setblock 236 209 356 minecraft:mushroom_stem
fill 236 209 357 236 212 357 minecraft:moss_block
setblock 236 209 361 minecraft:mushroom_stem
fill 236 209 362 236 212 362 minecraft:moss_block
setblock 237 209 345 minecraft:mushroom_stem
fill 237 209 346 237 212 346 minecraft:moss_block
setblock 237 209 350 minecraft:mushroom_stem
fill 237 209 351 237 212 351 minecraft:moss_block
setblock 237 209 355 minecraft:mushroom_stem
fill 237 209 356 237 212 356 minecraft:moss_block
setblock 238 209 345 minecraft:moss_block
setblock 238 209 349 minecraft:mushroom_stem
fill 238 209 350 238 212 350 minecraft:moss_block
setblock 238 209 354 minecraft:mushroom_stem
setblock 249 209 323 minecraft:red_mushroom_block
fill 249 209 364 249 228 364 minecraft:green_terracotta
setblock 253 209 324 minecraft:mushroom_stem
setblock 254 209 323 minecraft:mushroom_stem
fill 254 209 324 254 212 324 minecraft:moss_block
fill 255 209 323 255 212 323 minecraft:moss_block
setblock 256 209 325 minecraft:moss_block
setblock 257 209 325 minecraft:mushroom_stem
setblock 258 209 324 minecraft:mushroom_stem
fill 258 209 325 258 212 325 minecraft:moss_block
setblock 259 209 323 minecraft:mushroom_stem
fill 259 209 324 259 212 324 minecraft:moss_block
fill 260 209 323 260 212 323 minecraft:moss_block
setblock 263 209 324 minecraft:mushroom_stem
setblock 263 209 363 minecraft:red_mushroom_block
setblock 264 209 323 minecraft:mushroom_stem
fill 265 209 323 265 210 323 minecraft:moss_block
setblock 269 209 323 minecraft:mushroom_stem
fill 270 209 323 270 212 323 minecraft:moss_block
setblock 270 209 332 minecraft:dirt
setblock 272 209 330 minecraft:dirt
setblock 272 209 334 minecraft:dirt
setblock 273 209 324 minecraft:mushroom_stem
fill 274 209 322 274 228 322 minecraft:green_terracotta
setblock 274 209 323 minecraft:mushroom_stem
fill 274 209 324 274 212 324 minecraft:moss_block
setblock 274 209 332 minecraft:dirt
setblock 274 209 363 minecraft:mushroom_stem
fill 275 209 323 275 212 323 minecraft:moss_block
setblock 275 209 327 minecraft:mushroom_stem
fill 275 209 328 275 212 328 minecraft:moss_block
setblock 275 209 347 minecraft:mushroom_stem
fill 275 209 348 275 212 348 minecraft:moss_block
setblock 275 209 352 minecraft:mushroom_stem
fill 275 209 353 275 212 353 minecraft:moss_block
setblock 275 209 357 minecraft:mushroom_stem
fill 275 209 358 275 212 358 minecraft:moss_block
setblock 275 209 362 minecraft:mushroom_stem
fill 275 209 363 275 212 363 minecraft:moss_block
setblock 276 209 326 minecraft:mushroom_stem
fill 276 209 327 276 212 327 minecraft:moss_block
setblock 276 209 331 minecraft:mushroom_stem
fill 276 209 332 276 211 333 minecraft:moss_block
setblock 276 209 340 minecraft:red_mushroom_block
setblock 276 209 346 minecraft:mushroom_stem
fill 276 209 347 276 212 347 minecraft:moss_block
setblock 276 209 351 minecraft:mushroom_stem
fill 276 209 352 276 212 352 minecraft:moss_block
setblock 276 209 356 minecraft:mushroom_stem
fill 276 209 357 276 212 357 minecraft:moss_block
setblock 276 209 361 minecraft:mushroom_stem
fill 276 209 362 276 212 362 minecraft:moss_block
fill 277 209 327 277 228 327 minecraft:green_terracotta
setblock 235 210 362 minecraft:red_mushroom_block
setblock 236 210 325 minecraft:mushroom_stem
fill 236 210 326 236 213 326 minecraft:moss_block
setblock 236 210 330 minecraft:mushroom_stem
fill 236 210 331 236 213 331 minecraft:moss_block
setblock 236 210 335 minecraft:mushroom_stem
setblock 236 210 340 minecraft:mushroom_stem
fill 236 210 341 236 213 341 minecraft:moss_block
setblock 236 210 345 minecraft:mushroom_stem
fill 236 210 346 236 213 346 minecraft:moss_block
setblock 236 210 350 minecraft:mushroom_stem
fill 236 210 351 236 213 351 minecraft:moss_block
setblock 236 210 355 minecraft:mushroom_stem
fill 236 210 356 236 213 356 minecraft:moss_block
setblock 236 210 360 minecraft:mushroom_stem
fill 236 210 361 236 213 361 minecraft:moss_block
setblock 237 210 329 minecraft:mushroom_stem
setblock 237 210 344 minecraft:mushroom_stem
fill 237 210 345 237 213 345 minecraft:moss_block
setblock 237 210 349 minecraft:mushroom_stem
fill 237 210 350 237 213 350 minecraft:moss_block
setblock 237 210 354 minecraft:mushroom_stem
fill 237 210 355 237 213 355 minecraft:moss_block
setblock 238 210 348 minecraft:mushroom_stem
fill 238 210 349 238 213 349 minecraft:moss_block
setblock 238 210 353 minecraft:mushroom_stem
fill 238 210 354 238 213 354 minecraft:moss_block
setblock 243 210 323 minecraft:red_mushroom_block
setblock 244 210 363 minecraft:red_mushroom_block
setblock 252 210 324 minecraft:mushroom_stem
setblock 253 210 323 minecraft:mushroom_stem
fill 253 210 324 253 213 324 minecraft:moss_block
fill 254 210 323 254 213 323 minecraft:moss_block
setblock 256 210 325 minecraft:mushroom_stem
setblock 257 210 324 minecraft:mushroom_stem
fill 257 210 325 257 213 325 minecraft:moss_block
setblock 258 210 323 minecraft:mushroom_stem
fill 258 210 324 258 213 324 minecraft:moss_block
fill 259 210 323 259 213 323 minecraft:moss_block
setblock 263 210 323 minecraft:mushroom_stem
fill 264 210 323 264 211 323 minecraft:moss_block
setblock 268 210 323 minecraft:mushroom_stem
fill 269 210 323 269 213 323 minecraft:moss_block
setblock 269 210 363 minecraft:red_mushroom_block
fill 270 210 363 270 212 363 minecraft:moss_block
setblock 272 210 324 minecraft:mushroom_stem
setblock 273 210 323 minecraft:mushroom_stem
fill 273 210 324 273 213 324 minecraft:moss_block
setblock 273 210 363 minecraft:mushroom_stem
fill 274 210 323 274 213 323 minecraft:moss_block
fill 274 210 349 274 210 351 minecraft:moss_block
setblock 274 210 352 minecraft:mushroom_stem
fill 274 210 353 274 212 354 minecraft:moss_block
setblock 274 210 362 minecraft:mushroom_stem
fill 274 210 363 274 213 363 minecraft:moss_block
setblock 275 210 326 minecraft:mushroom_stem
fill 275 210 327 275 213 327 minecraft:moss_block
setblock 275 210 331 minecraft:mushroom_stem
setblock 275 210 346 minecraft:mushroom_stem
fill 275 210 347 275 213 347 minecraft:moss_block
setblock 275 210 351 minecraft:mushroom_stem
fill 275 210 352 275 213 352 minecraft:moss_block
setblock 275 210 355 minecraft:moss_block
setblock 275 210 356 minecraft:mushroom_stem
fill 275 210 357 275 213 357 minecraft:moss_block
setblock 275 210 361 minecraft:mushroom_stem
fill 275 210 362 275 213 362 minecraft:moss_block
setblock 276 210 325 minecraft:mushroom_stem
fill 276 210 326 276 213 326 minecraft:moss_block
setblock 276 210 330 minecraft:mushroom_stem
fill 276 210 331 276 213 331 minecraft:moss_block
setblock 276 210 334 minecraft:red_mushroom_block
setblock 276 210 345 minecraft:mushroom_stem
fill 276 210 346 276 213 346 minecraft:moss_block
setblock 276 210 350 minecraft:mushroom_stem
fill 276 210 351 276 213 351 minecraft:moss_block
setblock 276 210 355 minecraft:mushroom_stem
fill 276 210 356 276 213 356 minecraft:moss_block
setblock 276 210 360 minecraft:mushroom_stem
fill 276 210 361 276 213 361 minecraft:moss_block
setblock 277 210 336 minecraft:red_mushroom_block
fill 277 210 337 277 228 338 minecraft:green_terracotta
fill 235 211 362 235 229 362 minecraft:green_terracotta
setblock 236 211 324 minecraft:mushroom_stem
fill 236 211 325 236 214 325 minecraft:moss_block
setblock 236 211 329 minecraft:mushroom_stem
fill 236 211 330 237 213 330 minecraft:moss_block
setblock 236 211 334 minecraft:mushroom_stem
fill 236 211 335 236 211 338 minecraft:moss_block
setblock 236 211 339 minecraft:mushroom_stem
fill 236 211 340 236 214 340 minecraft:moss_block
setblock 236 211 344 minecraft:mushroom_stem
fill 236 211 345 236 214 345 minecraft:moss_block
setblock 236 211 349 minecraft:mushroom_stem
fill 236 211 350 236 214 350 minecraft:moss_block
setblock 236 211 354 minecraft:mushroom_stem
fill 236 211 355 236 214 355 minecraft:moss_block
setblock 236 211 359 minecraft:mushroom_stem
fill 236 211 360 236 214 360 minecraft:moss_block
setblock 237 211 323 minecraft:red_mushroom_block
fill 237 211 329 237 214 329 minecraft:moss_block
fill 237 211 331 237 212 331 minecraft:moss_block
setblock 237 211 343 minecraft:mushroom_stem
fill 237 211 344 237 214 344 minecraft:moss_block
setblock 237 211 348 minecraft:mushroom_stem
fill 237 211 349 237 214 349 minecraft:moss_block
setblock 237 211 353 minecraft:mushroom_stem
fill 237 211 354 237 214 354 minecraft:moss_block
setblock 238 211 347 minecraft:mushroom_stem
fill 238 211 348 238 214 348 minecraft:moss_block
setblock 238 211 352 minecraft:mushroom_stem
fill 238 211 353 238 214 353 minecraft:moss_block
setblock 250 211 363 minecraft:red_mushroom_block
setblock 252 211 323 minecraft:mushroom_stem
fill 252 211 324 252 214 324 minecraft:moss_block
fill 253 211 323 253 214 323 minecraft:moss_block
fill 253 211 325 253 212 325 minecraft:moss_block
setblock 255 211 325 minecraft:mushroom_stem
setblock 256 211 324 minecraft:mushroom_stem
fill 256 211 325 256 214 325 minecraft:moss_block
setblock 257 211 323 minecraft:mushroom_stem
fill 257 211 324 257 214 324 minecraft:moss_block
fill 258 211 323 258 214 323 minecraft:moss_block
setblock 261 211 324 minecraft:mushroom_stem
setblock 262 211 323 minecraft:mushroom_stem
fill 263 211 323 263 214 323 minecraft:moss_block
setblock 267 211 323 minecraft:mushroom_stem
fill 268 211 323 268 214 323 minecraft:moss_block
setblock 271 211 324 minecraft:mushroom_stem
setblock 272 211 323 minecraft:mushroom_stem
fill 272 211 324 272 214 324 minecraft:moss_block
setblock 272 211 363 minecraft:mushroom_stem
fill 273 211 323 273 214 323 minecraft:moss_block
setblock 273 211 362 minecraft:mushroom_stem
fill 273 211 363 273 214 363 minecraft:moss_block
fill 274 211 349 274 211 350 minecraft:moss_block
setblock 274 211 351 minecraft:mushroom_stem
fill 274 211 352 274 214 352 minecraft:moss_block
setblock 274 211 355 minecraft:moss_block
setblock 274 211 356 minecraft:mushroom_stem
fill 274 211 362 274 214 362 minecraft:moss_block
setblock 275 211 325 minecraft:mushroom_stem
fill 275 211 326 275 214 326 minecraft:moss_block
setblock 275 211 330 minecraft:mushroom_stem
fill 275 211 331 275 213 332 minecraft:moss_block
fill 275 211 346 275 214 346 minecraft:moss_block
setblock 275 211 350 minecraft:mushroom_stem
fill 275 211 351 275 214 351 minecraft:moss_block
setblock 275 211 355 minecraft:mushroom_stem
fill 275 211 356 275 214 356 minecraft:moss_block
setblock 275 211 360 minecraft:mushroom_stem
fill 275 211 361 275 214 361 minecraft:moss_block
setblock 276 211 324 minecraft:mushroom_stem
fill 276 211 325 276 214 325 minecraft:moss_block
setblock 276 211 329 minecraft:mushroom_stem
fill 276 211 330 276 214 330 minecraft:moss_block
setblock 276 211 334 minecraft:mushroom_stem
setblock 276 211 344 minecraft:mushroom_stem
fill 276 211 345 276 214 345 minecraft:moss_block
setblock 276 211 349 minecraft:mushroom_stem
fill 276 211 350 276 214 350 minecraft:moss_block
setblock 276 211 354 minecraft:mushroom_stem
fill 276 211 355 276 214 355 minecraft:moss_block
setblock 276 211 359 minecraft:mushroom_stem
fill 276 211 360 276 214 360 minecraft:moss_block
fill 277 211 336 277 228 336 minecraft:green_terracotta
fill 277 211 346 277 228 347 minecraft:green_terracotta
setblock 277 211 348 minecraft:red_mushroom_block
setblock 235 212 344 minecraft:red_mushroom_block
setblock 236 212 324 minecraft:moss_block
setblock 236 212 328 minecraft:mushroom_stem
fill 236 212 329 236 215 329 minecraft:moss_block
setblock 236 212 333 minecraft:mushroom_stem
fill 236 212 334 236 212 337 minecraft:moss_block
setblock 236 212 338 minecraft:mushroom_stem
fill 236 212 339 236 215 339 minecraft:moss_block
setblock 236 212 343 minecraft:mushroom_stem
fill 236 212 344 236 215 344 minecraft:moss_block
setblock 236 212 348 minecraft:mushroom_stem
fill 236 212 349 236 215 349 minecraft:moss_block
setblock 236 212 353 minecraft:mushroom_stem
fill 236 212 354 236 215 354 minecraft:moss_block
setblock 236 212 358 minecraft:mushroom_stem
fill 236 212 359 236 215 359 minecraft:moss_block
setblock 236 212 363 minecraft:mushroom_stem
setblock 237 212 332 minecraft:mushroom_stem
fill 237 212 333 237 215 333 minecraft:moss_block
setblock 237 212 347 minecraft:mushroom_stem
fill 237 212 348 237 215 348 minecraft:moss_block
setblock 237 212 352 minecraft:mushroom_stem
fill 237 212 353 237 215 353 minecraft:moss_block
setblock 237 212 357 minecraft:mushroom_stem
fill 237 212 358 237 215 358 minecraft:moss_block
setblock 237 212 363 minecraft:red_mushroom_block
setblock 238 212 347 minecraft:moss_block
setblock 238 212 351 minecraft:mushroom_stem
fill 238 212 352 238 215 352 minecraft:moss_block
fill 242 212 326 246 212 328 minecraft:red_mushroom_block
fill 243 212 325 245 212 325 minecraft:red_mushroom_block
fill 243 212 329 245 212 329 minecraft:red_mushroom_block
fill 245 212 335 246 212 339 minecraft:red_mushroom_block
fill 246 212 334 252 212 334 minecraft:red_mushroom_block
fill 246 212 340 248 212 340 minecraft:red_mushroom_block
fill 247 212 333 251 212 333 minecraft:red_mushroom_block
fill 247 212 335 247 214 335 minecraft:red_mushroom_block
fill 247 212 339 249 213 339 minecraft:red_mushroom_block
fill 247 212 341 248 212 342 minecraft:red_mushroom_block
fill 248 212 336 248 215 337 minecraft:mushroom_stem
fill 248 212 338 254 212 338 minecraft:red_mushroom_block
fill 248 212 343 250 212 343 minecraft:red_mushroom_block
fill 249 212 336 249 215 336 minecraft:mushroom_stem
fill 249 212 337 253 212 337 minecraft:red_mushroom_block
fill 249 212 342 249 214 342 minecraft:red_mushroom_block
setblock 249 212 344 minecraft:red_mushroom_block
setblock 250 212 323 minecraft:moss_block
setblock 251 212 323 minecraft:mushroom_stem
fill 251 212 324 251 215 324 minecraft:moss_block
fill 251 212 331 252 212 332 minecraft:red_mushroom_block
fill 251 212 335 256 212 335 minecraft:red_mushroom_block
fill 252 212 323 252 215 323 minecraft:moss_block
fill 252 212 327 252 213 327 minecraft:dirt
fill 252 212 330 256 212 330 minecraft:red_mushroom_block
fill 252 212 336 254 212 336 minecraft:red_mushroom_block
fill 253 212 326 253 213 326 minecraft:dirt
fill 253 212 328 253 213 328 minecraft:dirt
fill 253 212 331 253 214 331 minecraft:red_mushroom_block
fill 253 212 339 255 212 339 minecraft:red_mushroom_block
fill 253 212 343 255 212 343 minecraft:red_mushroom_block
setblock 254 212 325 minecraft:mushroom_stem
fill 254 212 327 254 213 327 minecraft:dirt
fill 254 212 340 255 212 342 minecraft:red_mushroom_block
setblock 254 212 344 minecraft:red_mushroom_block
setblock 255 212 324 minecraft:mushroom_stem
fill 255 212 325 255 215 325 minecraft:moss_block
fill 255 212 331 256 213 331 minecraft:red_mushroom_block
setblock 256 212 323 minecraft:mushroom_stem
fill 256 212 324 256 215 324 minecraft:moss_block
fill 256 212 332 257 212 334 minecraft:red_mushroom_block
setblock 256 212 363 minecraft:red_mushroom_block
fill 257 212 323 257 215 323 minecraft:moss_block
setblock 260 212 324 minecraft:mushroom_stem
setblock 261 212 323 minecraft:mushroom_stem
fill 262 212 323 262 215 323 minecraft:moss_block
setblock 266 212 323 minecraft:mushroom_stem
fill 267 212 323 267 215 323 minecraft:moss_block
fill 269 212 363 269 213 363 minecraft:moss_block
setblock 270 212 324 minecraft:mushroom_stem
setblock 271 212 323 minecraft:mushroom_stem
fill 271 212 324 271 215 324 minecraft:moss_block
setblock 271 212 363 minecraft:mushroom_stem
fill 272 212 323 272 215 323 minecraft:moss_block
setblock 272 212 362 minecraft:mushroom_stem
fill 272 212 363 272 215 363 minecraft:moss_block
fill 273 212 362 273 215 362 minecraft:moss_block
fill 274 212 348 274 212 349 minecraft:moss_block
setblock 274 212 350 minecraft:mushroom_stem
fill 274 212 351 274 215 351 minecraft:moss_block
setblock 274 212 355 minecraft:mushroom_stem
fill 274 212 356 274 213 358 minecraft:moss_block
setblock 275 212 324 minecraft:mushroom_stem
fill 275 212 325 275 214 325 minecraft:moss_block
setblock 275 212 329 minecraft:mushroom_stem
fill 275 212 330 275 215 330 minecraft:moss_block
setblock 275 212 333 minecraft:moss_block
setblock 275 212 349 minecraft:mushroom_stem
fill 275 212 350 275 215 350 minecraft:moss_block
setblock 275 212 354 minecraft:mushroom_stem
fill 275 212 355 275 215 355 minecraft:moss_block
setblock 275 212 359 minecraft:mushroom_stem
fill 275 212 360 275 215 360 minecraft:moss_block
setblock 276 212 323 minecraft:mushroom_stem
fill 276 212 324 276 215 324 minecraft:moss_block
setblock 276 212 328 minecraft:mushroom_stem
fill 276 212 329 276 215 329 minecraft:moss_block
setblock 276 212 332 minecraft:moss_block
setblock 276 212 333 minecraft:mushroom_stem
fill 276 212 334 276 213 336 minecraft:moss_block
setblock 276 212 343 minecraft:mushroom_stem
fill 276 212 344 276 215 344 minecraft:moss_block
setblock 276 212 348 minecraft:mushroom_stem
fill 276 212 349 276 215 349 minecraft:moss_block
setblock 276 212 353 minecraft:mushroom_stem
fill 276 212 354 276 215 354 minecraft:moss_block
setblock 276 212 358 minecraft:mushroom_stem
fill 276 212 359 276 215 359 minecraft:moss_block
setblock 276 212 363 minecraft:mushroom_stem
fill 277 212 348 277 228 348 minecraft:green_terracotta
fill 235 213 344 235 228 344 minecraft:green_terracotta
setblock 236 213 327 minecraft:mushroom_stem
fill 236 213 328 236 215 328 minecraft:moss_block
setblock 236 213 332 minecraft:mushroom_stem
fill 236 213 333 236 213 336 minecraft:moss_block
setblock 236 213 337 minecraft:mushroom_stem
fill 236 213 338 236 215 338 minecraft:moss_block
setblock 236 213 342 minecraft:mushroom_stem
fill 236 213 343 236 215 343 minecraft:moss_block
setblock 236 213 347 minecraft:mushroom_stem
fill 236 213 348 236 215 348 minecraft:moss_block
setblock 236 213 352 minecraft:mushroom_stem
fill 236 213 353 236 215 353 minecraft:moss_block
setblock 236 213 357 minecraft:mushroom_stem
fill 236 213 358 236 215 358 minecraft:moss_block
setblock 236 213 362 minecraft:mushroom_stem
fill 236 213 363 236 215 363 minecraft:moss_block
setblock 237 213 331 minecraft:mushroom_stem
fill 237 213 332 237 215 332 minecraft:moss_block
fill 237 213 334 237 213 335 minecraft:moss_block
setblock 237 213 336 minecraft:mushroom_stem
setblock 237 213 346 minecraft:mushroom_stem
fill 237 213 347 237 215 347 minecraft:moss_block
setblock 237 213 351 minecraft:mushroom_stem
fill 237 213 352 237 215 352 minecraft:moss_block
setblock 237 213 356 minecraft:mushroom_stem
fill 237 213 357 237 215 357 minecraft:moss_block
setblock 238 213 325 minecraft:light[level=15]
setblock 238 213 332 minecraft:light[level=12]
setblock 238 213 333 minecraft:light[level=15]
setblock 238 213 339 minecraft:light[level=12]
setblock 238 213 341 minecraft:light[level=15]
setblock 238 213 346 minecraft:light[level=12]
setblock 238 213 350 minecraft:mushroom_stem
fill 238 213 351 238 215 351 minecraft:moss_block
setblock 238 213 355 minecraft:mushroom_stem
setblock 238 213 357 minecraft:light[level=15]
setblock 238 213 360 minecraft:light[level=12]
setblock 243 213 363 minecraft:red_mushroom_block
fill 244 213 323 244 214 323 minecraft:red_mushroom_block
setblock 245 213 325 minecraft:light[level=12]
setblock 245 213 332 minecraft:light[level=12]
fill 245 213 337 246 213 338 minecraft:red_mushroom_block
setblock 245 213 339 minecraft:light[level=12]
setblock 245 213 346 minecraft:light[level=12]
setblock 245 213 353 minecraft:light[level=12]
setblock 245 213 360 minecraft:light[level=12]
setblock 246 213 325 minecraft:light[level=15]
setblock 246 213 333 minecraft:light[level=15]
fill 246 213 335 246 213 336 minecraft:red_mushroom_block
setblock 246 213 339 minecraft:red_mushroom_block
setblock 246 213 341 minecraft:light[level=15]
setblock 246 213 349 minecraft:light[level=15]
setblock 246 213 357 minecraft:light[level=15]
setblock 247 213 322 minecraft:red_mushroom_block
fill 247 213 334 252 213 334 minecraft:red_mushroom_block
fill 247 213 340 248 213 340 minecraft:red_mushroom_block
fill 248 213 338 248 215 338 minecraft:mushroom_stem
fill 248 213 341 248 213 342 minecraft:red_mushroom_block
fill 249 213 337 250 215 337 minecraft:mushroom_stem
fill 249 213 338 253 213 338 minecraft:red_mushroom_block
fill 249 213 343 250 213 343 minecraft:red_mushroom_block
setblock 250 213 323 minecraft:mushroom_stem
fill 251 213 323 251 215 323 minecraft:moss_block
fill 251 213 332 251 213 333 minecraft:red_mushroom_block
fill 251 213 335 255 213 335 minecraft:red_mushroom_block
fill 251 213 337 252 213 337 minecraft:red_mushroom_block
setblock 252 213 325 minecraft:moss_block
fill 252 213 331 252 213 332 minecraft:red_mushroom_block
setblock 252 213 336 minecraft:red_mushroom_block
setblock 252 213 353 minecraft:light[level=12]
setblock 252 213 360 minecraft:light[level=12]
setblock 253 213 325 minecraft:mushroom_stem
fill 253 213 330 254 213 330 minecraft:red_mushroom_block
fill 253 213 339 254 213 339 minecraft:red_mushroom_block
fill 253 213 343 254 213 343 minecraft:red_mushroom_block
setblock 254 213 324 minecraft:mushroom_stem
fill 254 213 325 254 215 325 minecraft:moss_block
fill 254 213 340 254 214 342 minecraft:red_mushroom_block
setblock 254 213 349 minecraft:light[level=15]
setblock 254 213 357 minecraft:light[level=15]
setblock 255 213 323 minecraft:mushroom_stem
fill 255 213 324 255 215 324 minecraft:moss_block
setblock 255 213 341 minecraft:red_mushroom_block
setblock 255 213 363 minecraft:mushroom_stem
fill 256 213 323 256 215 323 minecraft:moss_block
fill 256 213 332 256 213 334 minecraft:red_mushroom_block
setblock 259 213 324 minecraft:mushroom_stem
setblock 259 213 325 minecraft:light[level=12]
setblock 259 213 332 minecraft:light[level=12]
setblock 259 213 339 minecraft:light[level=12]
setblock 259 213 346 minecraft:light[level=12]
setblock 259 213 353 minecraft:light[level=12]
setblock 259 213 360 minecraft:light[level=12]
setblock 260 213 323 minecraft:mushroom_stem
fill 261 213 323 261 215 323 minecraft:moss_block
setblock 262 213 325 minecraft:light[level=15]
setblock 262 213 333 minecraft:light[level=15]
setblock 262 213 341 minecraft:light[level=15]
setblock 262 213 349 minecraft:light[level=15]
setblock 262 213 357 minecraft:light[level=15]
setblock 262 213 363 minecraft:red_mushroom_block
setblock 265 213 323 minecraft:mushroom_stem
fill 266 213 323 266 215 323 minecraft:moss_block
setblock 266 213 325 minecraft:light[level=12]
setblock 266 213 332 minecraft:light[level=12]
setblock 266 213 339 minecraft:light[level=12]
setblock 266 213 346 minecraft:light[level=12]
setblock 266 213 353 minecraft:light[level=12]
setblock 266 213 360 minecraft:light[level=12]
fill 268 213 363 268 214 363 minecraft:moss_block
setblock 270 213 323 minecraft:mushroom_stem
fill 270 213 324 270 215 324 minecraft:moss_block
setblock 270 213 325 minecraft:light[level=15]
setblock 270 213 333 minecraft:light[level=15]
setblock 270 213 341 minecraft:light[level=15]
setblock 270 213 349 minecraft:light[level=15]
setblock 270 213 357 minecraft:light[level=15]
setblock 270 213 362 minecraft:moss_block
setblock 270 213 363 minecraft:mushroom_stem
fill 271 213 323 271 215 323 minecraft:moss_block
setblock 271 213 362 minecraft:mushroom_stem
fill 271 213 363 271 215 363 minecraft:moss_block
fill 272 213 362 272 215 362 minecraft:moss_block
setblock 273 213 325 minecraft:light[level=12]
setblock 273 213 332 minecraft:light[level=12]
setblock 273 213 339 minecraft:light[level=12]
setblock 273 213 346 minecraft:light[level=12]
fill 273 213 351 273 213 354 minecraft:moss_block
setblock 273 213 355 minecraft:mushroom_stem
fill 273 213 356 273 215 356 minecraft:moss_block
setblock 273 213 360 minecraft:light[level=12]
setblock 274 213 324 minecraft:mushroom_stem
setblock 274 213 348 minecraft:moss_block
setblock 274 213 349 minecraft:mushroom_stem
fill 274 213 350 274 215 350 minecraft:moss_block
setblock 274 213 353 minecraft:moss_block
setblock 274 213 354 minecraft:mushroom_stem
fill 274 213 355 274 215 355 minecraft:moss_block
setblock 274 213 359 minecraft:mushroom_stem
fill 274 213 360 274 215 360 minecraft:moss_block
setblock 275 213 323 minecraft:mushroom_stem
setblock 275 213 324 minecraft:moss_block
setblock 275 213 328 minecraft:mushroom_stem
fill 275 213 329 275 215 329 minecraft:moss_block
setblock 275 213 333 minecraft:mushroom_stem
fill 275 213 334 275 215 334 minecraft:moss_block
setblock 275 213 348 minecraft:mushroom_stem
fill 275 213 349 275 215 349 minecraft:moss_block
setblock 275 213 353 minecraft:mushroom_stem
fill 275 213 354 275 215 354 minecraft:moss_block
setblock 275 213 358 minecraft:mushroom_stem
fill 275 213 359 275 215 359 minecraft:moss_block
setblock 275 213 363 minecraft:mushroom_stem
fill 276 213 323 276 215 323 minecraft:moss_block
setblock 276 213 327 minecraft:mushroom_stem
fill 276 213 328 276 215 328 minecraft:moss_block
setblock 276 213 332 minecraft:mushroom_stem
fill 276 213 333 276 215 333 minecraft:moss_block
setblock 276 213 337 minecraft:mushroom_stem
setblock 276 213 341 minecraft:red_mushroom_block
fill 276 213 343 276 215 343 minecraft:moss_block
setblock 276 213 347 minecraft:mushroom_stem
fill 276 213 348 276 215 348 minecraft:moss_block
setblock 276 213 352 minecraft:mushroom_stem
fill 276 213 353 276 215 353 minecraft:moss_block
setblock 276 213 357 minecraft:mushroom_stem
fill 276 213 358 276 215 358 minecraft:moss_block
setblock 276 213 362 minecraft:mushroom_stem
fill 276 213 363 276 215 363 minecraft:moss_block
setblock 235 214 335 minecraft:shroomlight
setblock 236 214 326 minecraft:mushroom_stem
fill 236 214 327 236 215 327 minecraft:moss_block
setblock 236 214 330 minecraft:moss_block
setblock 236 214 331 minecraft:mushroom_stem
fill 236 214 332 236 214 335 minecraft:moss_block
setblock 236 214 336 minecraft:mushroom_stem
fill 236 214 337 237 215 337 minecraft:moss_block
setblock 236 214 341 minecraft:mushroom_stem
fill 236 214 342 236 215 342 minecraft:moss_block
setblock 236 214 346 minecraft:mushroom_stem
fill 236 214 347 236 215 347 minecraft:moss_block
setblock 236 214 351 minecraft:mushroom_stem
fill 236 214 352 236 215 352 minecraft:moss_block
setblock 236 214 356 minecraft:mushroom_stem
fill 236 214 357 236 215 357 minecraft:moss_block
setblock 236 214 361 minecraft:mushroom_stem
fill 236 214 362 236 215 362 minecraft:moss_block
setblock 237 214 330 minecraft:mushroom_stem
fill 237 214 331 237 215 331 minecraft:moss_block
setblock 237 214 334 minecraft:moss_block
setblock 237 214 335 minecraft:mushroom_stem
fill 237 214 336 237 215 336 minecraft:moss_block
fill 237 214 338 237 215 338 minecraft:moss_block
fill 237 214 343 237 215 343 minecraft:moss_block
setblock 237 214 345 minecraft:mushroom_stem
fill 237 214 346 237 215 346 minecraft:moss_block
setblock 237 214 350 minecraft:mushroom_stem
fill 237 214 351 237 215 351 minecraft:moss_block
setblock 237 214 355 minecraft:mushroom_stem
fill 237 214 356 237 215 356 minecraft:moss_block
setblock 238 214 323 minecraft:red_mushroom_block
setblock 238 214 349 minecraft:mushroom_stem
fill 238 214 350 238 215 350 minecraft:moss_block
setblock 238 214 354 minecraft:mushroom_stem
fill 238 214 355 238 215 355 minecraft:moss_block
setblock 240 214 364 minecraft:shroomlight
fill 246 214 336 246 214 338 minecraft:red_mushroom_block
fill 247 214 322 247 224 322 minecraft:green_terracotta
setblock 247 214 339 minecraft:red_mushroom_block
fill 248 214 334 249 214 334 minecraft:red_mushroom_block
fill 248 214 339 248 215 339 minecraft:mushroom_stem
setblock 248 214 340 minecraft:red_mushroom_block
setblock 249 214 323 minecraft:mushroom_stem
fill 249 214 338 249 215 338 minecraft:mushroom_stem
setblock 249 214 339 minecraft:red_mushroom_block
setblock 249 214 363 minecraft:red_mushroom_block
fill 250 214 323 250 215 324 minecraft:moss_block
fill 250 214 338 252 214 338 minecraft:red_mushroom_block
setblock 250 214 343 minecraft:red_mushroom_block
setblock 251 214 335 minecraft:red_mushroom_block
fill 251 214 337 251 215 337 minecraft:mushroom_stem
setblock 252 214 325 minecraft:mushroom_stem
setblock 252 214 332 minecraft:red_mushroom_block
setblock 252 214 334 minecraft:red_mushroom_block
setblock 252 214 337 minecraft:red_mushroom_block
fill 252 214 363 253 214 363 minecraft:moss_block
setblock 253 214 324 minecraft:mushroom_stem
fill 253 214 325 253 215 325 minecraft:moss_block
setblock 253 214 339 minecraft:red_mushroom_block
setblock 253 214 343 minecraft:red_mushroom_block
setblock 254 214 323 minecraft:mushroom_stem
fill 254 214 324 254 215 324 minecraft:moss_block
setblock 254 214 335 minecraft:red_mushroom_block
setblock 254 214 363 minecraft:mushroom_stem
fill 255 214 323 255 215 323 minecraft:moss_block
setblock 255 214 331 minecraft:red_mushroom_block
fill 255 214 363 257 215 363 minecraft:moss_block
fill 256 214 332 256 214 333 minecraft:red_mushroom_block
setblock 257 214 325 minecraft:mushroom_stem
setblock 258 214 324 minecraft:mushroom_stem
setblock 259 214 323 minecraft:mushroom_stem
setblock 259 214 324 minecraft:moss_block
fill 260 214 323 260 215 323 minecraft:moss_block
setblock 261 214 364 minecraft:red_mushroom_block
setblock 264 214 323 minecraft:mushroom_stem
fill 265 214 323 265 215 323 minecraft:moss_block
fill 267 214 363 267 215 363 minecraft:moss_block
setblock 269 214 323 minecraft:mushroom_stem
fill 269 214 324 269 215 324 minecraft:moss_block
setblock 269 214 362 minecraft:moss_block
setblock 269 214 363 minecraft:mushroom_stem
fill 270 214 323 270 215 323 minecraft:moss_block
setblock 270 214 362 minecraft:mushroom_stem
fill 270 214 363 270 215 363 minecraft:moss_block
fill 271 214 362 271 215 362 minecraft:moss_block
fill 272 214 361 274 215 361 minecraft:moss_block
setblock 273 214 324 minecraft:mushroom_stem
fill 273 214 351 273 214 353 minecraft:moss_block
setblock 273 214 354 minecraft:mushroom_stem
fill 273 214 355 273 215 355 minecraft:moss_block
fill 273 214 357 273 214 358 minecraft:moss_block
setblock 274 214 323 minecraft:mushroom_stem
fill 274 214 324 274 215 324 minecraft:moss_block
fill 274 214 330 274 215 331 minecraft:moss_block
setblock 274 214 348 minecraft:mushroom_stem
fill 274 214 349 274 215 349 minecraft:moss_block
setblock 274 214 353 minecraft:mushroom_stem
fill 274 214 354 274 215 354 minecraft:moss_block
fill 274 214 356 274 214 357 minecraft:moss_block
setblock 274 214 358 minecraft:mushroom_stem
fill 274 214 359 274 215 359 minecraft:moss_block
setblock 274 214 363 minecraft:mushroom_stem
fill 275 214 323 275 215 323 minecraft:moss_block
setblock 275 214 327 minecraft:mushroom_stem
fill 275 214 328 275 215 328 minecraft:moss_block
setblock 275 214 331 minecraft:moss_block
setblock 275 214 332 minecraft:mushroom_stem
fill 275 214 333 275 215 333 minecraft:moss_block
fill 275 214 335 276 214 335 minecraft:moss_block
setblock 275 214 347 minecraft:mushroom_stem
fill 275 214 348 275 215 348 minecraft:moss_block
setblock 275 214 352 minecraft:mushroom_stem
fill 275 214 353 275 215 353 minecraft:moss_block
setblock 275 214 357 minecraft:mushroom_stem
fill 275 214 358 275 215 358 minecraft:moss_block
setblock 275 214 362 minecraft:mushroom_stem
fill 275 214 363 275 215 363 minecraft:moss_block
setblock 276 214 326 minecraft:mushroom_stem
fill 276 214 327 276 215 327 minecraft:moss_block
setblock 276 214 331 minecraft:mushroom_stem
fill 276 214 332 276 215 332 minecraft:moss_block
fill 276 214 334 276 215 334 minecraft:moss_block
setblock 276 214 336 minecraft:mushroom_stem
fill 276 214 337 276 214 340 minecraft:moss_block
setblock 276 214 341 minecraft:mushroom_stem
fill 276 214 342 276 215 342 minecraft:moss_block
setblock 276 214 346 minecraft:mushroom_stem
fill 276 214 347 276 215 347 minecraft:moss_block
setblock 276 214 351 minecraft:mushroom_stem
fill 276 214 352 276 215 352 minecraft:moss_block
setblock 276 214 356 minecraft:mushroom_stem
fill 276 214 357 276 215 357 minecraft:moss_block
setblock 276 214 361 minecraft:mushroom_stem
fill 276 214 362 276 215 362 minecraft:moss_block
fill 235 215 335 235 228 335 minecraft:green_terracotta
setblock 235 215 345 minecraft:red_mushroom_block
setblock 236 215 326 minecraft:moss_block
setblock 236 215 330 minecraft:mushroom_stem
fill 236 215 331 236 215 334 minecraft:moss_block
setblock 236 215 335 minecraft:mushroom_stem
setblock 236 215 336 minecraft:moss_block
setblock 236 215 340 minecraft:mushroom_stem
setblock 236 215 341 minecraft:moss_block
setblock 236 215 345 minecraft:mushroom_stem
setblock 236 215 346 minecraft:moss_block
setblock 236 215 350 minecraft:mushroom_stem
setblock 236 215 351 minecraft:moss_block
setblock 236 215 355 minecraft:mushroom_stem
setblock 236 215 356 minecraft:moss_block
setblock 236 215 360 minecraft:mushroom_stem
setblock 236 215 361 minecraft:moss_block
setblock 237 215 329 minecraft:mushroom_stem
setblock 237 215 330 minecraft:moss_block
setblock 237 215 334 minecraft:mushroom_stem
setblock 237 215 335 minecraft:moss_block
setblock 237 215 339 minecraft:mushroom_stem
setblock 237 215 340 minecraft:moss_block
setblock 237 215 344 minecraft:mushroom_stem
setblock 237 215 345 minecraft:moss_block
setblock 237 215 349 minecraft:mushroom_stem
setblock 237 215 350 minecraft:moss_block
setblock 237 215 354 minecraft:mushroom_stem
setblock 237 215 355 minecraft:moss_block
setblock 237 215 359 minecraft:mushroom_stem
setblock 237 215 364 minecraft:red_mushroom_block
setblock 238 215 349 minecraft:moss_block
setblock 238 215 353 minecraft:mushroom_stem
setblock 238 215 354 minecraft:moss_block
fill 240 215 364 240 223 364 minecraft:green_terracotta
fill 246 215 356 247 215 360 minecraft:red_mushroom_block
setblock 248 215 323 minecraft:mushroom_stem
fill 248 215 356 250 215 357 minecraft:red_mushroom_block
setblock 248 215 358 minecraft:mushroom_stem
fill 248 215 359 250 215 360 minecraft:red_mushroom_block
setblock 249 215 323 minecraft:moss_block
setblock 249 215 339 minecraft:mushroom_stem
fill 249 215 358 250 215 358 minecraft:red_mushroom_block
fill 250 215 338 251 215 338 minecraft:mushroom_stem
setblock 251 215 325 minecraft:mushroom_stem
fill 251 215 363 252 215 363 minecraft:moss_block
setblock 252 215 324 minecraft:mushroom_stem
setblock 252 215 325 minecraft:moss_block
setblock 253 215 323 minecraft:mushroom_stem
setblock 253 215 324 minecraft:moss_block
setblock 253 215 363 minecraft:mushroom_stem
setblock 254 215 323 minecraft:moss_block
setblock 254 215 363 minecraft:moss_block
setblock 256 215 325 minecraft:mushroom_stem
setblock 257 215 324 minecraft:mushroom_stem
setblock 258 215 323 minecraft:mushroom_stem
setblock 258 215 324 minecraft:moss_block
setblock 258 215 363 minecraft:mushroom_stem
setblock 259 215 323 minecraft:moss_block
fill 261 215 364 261 228 364 minecraft:green_terracotta
setblock 263 215 323 minecraft:mushroom_stem
setblock 264 215 323 minecraft:moss_block
fill 265 215 363 266 215 363 minecraft:moss_block
setblock 268 215 323 minecraft:mushroom_stem
setblock 268 215 362 minecraft:moss_block
setblock 268 215 363 minecraft:mushroom_stem
setblock 269 215 323 minecraft:moss_block
setblock 269 215 362 minecraft:mushroom_stem
setblock 269 215 363 minecraft:moss_block
setblock 270 215 361 minecraft:mushroom_stem
setblock 270 215 362 minecraft:moss_block
setblock 271 215 361 minecraft:moss_block
setblock 272 215 324 minecraft:mushroom_stem
setblock 273 215 323 minecraft:mushroom_stem
setblock 273 215 324 minecraft:moss_block
fill 273 215 350 273 215 352 minecraft:moss_block
setblock 273 215 353 minecraft:mushroom_stem
setblock 273 215 354 minecraft:moss_block
setblock 273 215 357 minecraft:moss_block
setblock 273 215 358 minecraft:mushroom_stem
setblock 273 215 359 minecraft:moss_block
setblock 273 215 363 minecraft:mushroom_stem
setblock 274 215 323 minecraft:moss_block
setblock 274 215 332 minecraft:mushroom_stem
setblock 274 215 333 minecraft:moss_block
setblock 274 215 348 minecraft:moss_block
setblock 274 215 352 minecraft:mushroom_stem
setblock 274 215 353 minecraft:moss_block
setblock 274 215 356 minecraft:moss_block
setblock 274 215 357 minecraft:mushroom_stem
setblock 274 215 358 minecraft:moss_block
setblock 274 215 362 minecraft:mushroom_stem
setblock 274 215 363 minecraft:moss_block
setblock 275 215 326 minecraft:mushroom_stem
setblock 275 215 327 minecraft:moss_block
setblock 275 215 331 minecraft:mushroom_stem
setblock 275 215 332 minecraft:moss_block
setblock 275 215 335 minecraft:moss_block
setblock 275 215 336 minecraft:mushroom_stem
fill 275 215 337 276 215 337 minecraft:moss_block
setblock 275 215 345 minecraft:moss_block
setblock 275 215 346 minecraft:mushroom_stem
setblock 275 215 347 minecraft:moss_block
setblock 275 215 351 minecraft:mushroom_stem
setblock 275 215 352 minecraft:moss_block
setblock 275 215 356 minecraft:mushroom_stem
setblock 275 215 357 minecraft:moss_block
setblock 275 215 361 minecraft:mushroom_stem
setblock 275 215 362 minecraft:moss_block
setblock 276 215 325 minecraft:mushroom_stem
setblock 276 215 326 minecraft:moss_block
setblock 276 215 330 minecraft:mushroom_stem
setblock 276 215 331 minecraft:moss_block
setblock 276 215 335 minecraft:mushroom_stem
setblock 276 215 336 minecraft:moss_block
fill 276 215 338 276 215 339 minecraft:moss_block
setblock 276 215 340 minecraft:mushroom_stem
setblock 276 215 341 minecraft:moss_block
setblock 276 215 345 minecraft:mushroom_stem
setblock 276 215 346 minecraft:moss_block
setblock 276 215 350 minecraft:mushroom_stem
setblock 276 215 351 minecraft:moss_block
setblock 276 215 355 minecraft:mushroom_stem
setblock 276 215 356 minecraft:moss_block
setblock 276 215 360 minecraft:mushroom_stem
setblock 276 215 361 minecraft:moss_block
setblock 277 215 341 minecraft:shroomlight
fill 235 216 345 235 226 345 minecraft:green_terracotta
setblock 237 216 322 minecraft:red_mushroom_block
fill 237 216 364 237 228 364 minecraft:green_terracotta
fill 277 216 341 277 224 341 minecraft:green_terracotta
fill 237 217 322 237 228 322 minecraft:green_terracotta
fill 235 219 350 235 224 354 minecraft:green_terracotta
setblock 235 219 355 minecraft:shroomlight
setblock 238 219 325 minecraft:light[level=12]
setblock 238 219 332 minecraft:light[level=12]
setblock 238 219 339 minecraft:light[level=12]
setblock 238 219 346 minecraft:light[level=12]
setblock 238 219 353 minecraft:light[level=12]
setblock 238 219 360 minecraft:light[level=12]
setblock 245 219 325 minecraft:light[level=12]
setblock 245 219 332 minecraft:light[level=12]
setblock 245 219 339 minecraft:light[level=12]
setblock 245 219 346 minecraft:light[level=12]
setblock 245 219 353 minecraft:light[level=12]
setblock 245 219 360 minecraft:light[level=12]
fill 250 219 364 250 224 364 minecraft:green_terracotta
setblock 251 219 364 minecraft:red_mushroom_block
setblock 252 219 325 minecraft:light[level=12]
setblock 252 219 332 minecraft:light[level=12]
setblock 252 219 339 minecraft:light[level=12]
setblock 252 219 353 minecraft:light[level=12]
setblock 252 219 360 minecraft:light[level=12]
setblock 259 219 325 minecraft:light[level=12]
setblock 259 219 332 minecraft:light[level=12]
setblock 259 219 339 minecraft:light[level=12]
setblock 259 219 346 minecraft:light[level=12]
setblock 259 219 353 minecraft:light[level=12]
setblock 259 219 360 minecraft:light[level=12]
setblock 266 219 325 minecraft:light[level=12]
setblock 266 219 332 minecraft:light[level=12]
setblock 266 219 339 minecraft:light[level=12]
setblock 266 219 346 minecraft:light[level=12]
setblock 266 219 353 minecraft:light[level=12]
setblock 266 219 360 minecraft:light[level=12]
setblock 271 219 322 minecraft:shroomlight
setblock 273 219 325 minecraft:light[level=12]
setblock 273 219 332 minecraft:light[level=12]
setblock 273 219 339 minecraft:light[level=12]
setblock 273 219 346 minecraft:light[level=12]
setblock 273 219 353 minecraft:light[level=12]
setblock 273 219 360 minecraft:light[level=12]
fill 235 220 355 235 228 355 minecraft:green_terracotta
fill 246 220 364 246 228 364 minecraft:green_terracotta
setblock 247 220 364 minecraft:shroomlight
fill 248 220 364 248 221 364 minecraft:green_terracotta
fill 251 220 364 251 228 364 minecraft:green_terracotta
fill 271 220 322 271 228 322 minecraft:green_terracotta
setblock 235 221 357 minecraft:red_mushroom_block
fill 235 221 358 235 228 360 minecraft:green_terracotta
setblock 238 221 325 minecraft:light[level=15]
setblock 238 221 333 minecraft:light[level=15]
setblock 238 221 341 minecraft:light[level=15]
setblock 238 221 349 minecraft:light[level=15]
setblock 238 221 357 minecraft:light[level=15]
fill 241 221 347 249 221 347 minecraft:brown_mushroom_block
fill 242 221 343 249 221 346 minecraft:brown_mushroom_block
fill 242 221 348 249 221 351 minecraft:brown_mushroom_block
fill 243 221 341 261 221 342 minecraft:brown_mushroom_block
fill 243 221 352 261 221 353 minecraft:brown_mushroom_block
fill 244 221 340 260 221 340 minecraft:brown_mushroom_block
fill 244 221 354 260 221 354 minecraft:brown_mushroom_block
fill 245 221 339 259 221 339 minecraft:brown_mushroom_block
fill 245 221 355 259 221 355 minecraft:brown_mushroom_block
setblock 246 221 325 minecraft:light[level=15]
setblock 246 221 333 minecraft:light[level=15]
fill 246 221 338 258 221 338 minecraft:brown_mushroom_block
fill 246 221 356 258 221 356 minecraft:brown_mushroom_block
setblock 246 221 357 minecraft:light[level=15]
fill 247 221 364 247 228 364 minecraft:green_terracotta
fill 248 221 337 256 221 337 minecraft:brown_mushroom_block
fill 248 221 357 256 221 357 minecraft:brown_mushroom_block
fill 250 221 343 250 221 345 minecraft:brown_mushroom_block
fill 250 221 349 250 221 351 minecraft:brown_mushroom_block
fill 251 221 343 262 221 344 minecraft:brown_mushroom_block
fill 251 221 350 262 221 351 minecraft:brown_mushroom_block
fill 252 221 336 252 222 336 minecraft:brown_mushroom_block
fill 252 221 358 252 222 358 minecraft:brown_mushroom_block
setblock 254 221 325 minecraft:light[level=15]
setblock 254 221 333 minecraft:light[level=15]
fill 254 221 345 262 221 345 minecraft:brown_mushroom_block
fill 254 221 349 262 221 349 minecraft:brown_mushroom_block
fill 255 221 346 262 221 348 minecraft:brown_mushroom_block
setblock 262 221 325 minecraft:light[level=15]
setblock 262 221 333 minecraft:light[level=15]
setblock 262 221 341 minecraft:light[level=15]
setblock 262 221 357 minecraft:light[level=15]
fill 263 221 347 263 222 347 minecraft:brown_mushroom_block
setblock 270 221 325 minecraft:light[level=15]
setblock 270 221 333 minecraft:light[level=15]
setblock 270 221 341 minecraft:light[level=15]
setblock 270 221 349 minecraft:light[level=15]
setblock 270 221 357 minecraft:light[level=15]
fill 235 222 357 235 225 357 minecraft:green_terracotta
fill 236 222 323 236 222 324 minecraft:moss_block
setblock 236 222 325 minecraft:brown_mushroom_block
fill 236 222 326 236 222 328 minecraft:moss_block
setblock 236 222 329 minecraft:brown_mushroom_block
fill 236 222 330 236 222 332 minecraft:moss_block
setblock 236 222 333 minecraft:brown_mushroom_block
fill 236 222 334 236 222 336 minecraft:moss_block
setblock 236 222 337 minecraft:brown_mushroom_block
fill 236 222 338 236 222 340 minecraft:moss_block
setblock 236 222 341 minecraft:brown_mushroom_block
fill 236 222 342 236 222 344 minecraft:moss_block
setblock 236 222 345 minecraft:brown_mushroom_block
fill 236 222 346 236 222 348 minecraft:moss_block
setblock 236 222 349 minecraft:brown_mushroom_block
fill 236 222 350 236 222 352 minecraft:moss_block
setblock 236 222 353 minecraft:brown_mushroom_block
fill 236 222 354 236 222 356 minecraft:moss_block
setblock 236 222 357 minecraft:brown_mushroom_block
fill 236 222 358 236 222 360 minecraft:moss_block
setblock 236 222 361 minecraft:brown_mushroom_block
fill 236 222 362 237 222 363 minecraft:moss_block
setblock 237 222 323 minecraft:moss_block
setblock 237 222 324 minecraft:brown_mushroom_block
fill 237 222 325 237 222 327 minecraft:moss_block
setblock 237 222 328 minecraft:brown_mushroom_block
fill 237 222 329 237 222 331 minecraft:moss_block
setblock 237 222 332 minecraft:brown_mushroom_block
fill 237 222 333 237 222 335 minecraft:moss_block
setblock 237 222 336 minecraft:brown_mushroom_block
fill 237 222 337 237 222 339 minecraft:moss_block
setblock 237 222 340 minecraft:brown_mushroom_block
fill 237 222 341 237 222 343 minecraft:moss_block
setblock 237 222 344 minecraft:brown_mushroom_block
fill 237 222 345 237 222 347 minecraft:moss_block
setblock 237 222 348 minecraft:brown_mushroom_block
fill 237 222 349 237 222 351 minecraft:moss_block
setblock 237 222 352 minecraft:brown_mushroom_block
fill 237 222 353 237 222 355 minecraft:moss_block
setblock 237 222 356 minecraft:brown_mushroom_block
fill 237 222 357 237 222 359 minecraft:moss_block
setblock 237 222 360 minecraft:brown_mushroom_block
fill 237 222 361 239 222 361 minecraft:moss_block
setblock 238 222 323 minecraft:brown_mushroom_block
fill 238 222 324 238 222 326 minecraft:moss_block
setblock 238 222 327 minecraft:brown_mushroom_block
fill 238 222 328 238 222 330 minecraft:moss_block
setblock 238 222 331 minecraft:brown_mushroom_block
fill 238 222 332 238 222 334 minecraft:moss_block
setblock 238 222 335 minecraft:brown_mushroom_block
fill 238 222 336 238 222 338 minecraft:moss_block
setblock 238 222 339 minecraft:brown_mushroom_block
fill 238 222 340 238 222 342 minecraft:moss_block
setblock 238 222 343 minecraft:brown_mushroom_block
fill 238 222 344 238 222 346 minecraft:moss_block
setblock 238 222 347 minecraft:brown_mushroom_block
fill 238 222 348 238 222 350 minecraft:moss_block
setblock 238 222 351 minecraft:brown_mushroom_block
fill 238 222 352 238 222 354 minecraft:moss_block
setblock 238 222 355 minecraft:brown_mushroom_block
fill 238 222 356 238 222 358 minecraft:moss_block
setblock 238 222 359 minecraft:brown_mushroom_block
fill 238 222 360 240 222 360 minecraft:moss_block
setblock 238 222 362 minecraft:moss_block
setblock 238 222 363 minecraft:brown_mushroom_block
fill 239 222 323 239 222 325 minecraft:moss_block
setblock 239 222 326 minecraft:brown_mushroom_block
fill 239 222 327 239 222 329 minecraft:moss_block
setblock 239 222 330 minecraft:brown_mushroom_block
fill 239 222 331 239 222 333 minecraft:moss_block
setblock 239 222 334 minecraft:brown_mushroom_block
fill 239 222 335 239 222 337 minecraft:moss_block
setblock 239 222 338 minecraft:brown_mushroom_block
fill 239 222 339 239 222 341 minecraft:moss_block
setblock 239 222 342 minecraft:brown_mushroom_block
fill 239 222 343 239 222 345 minecraft:moss_block
setblock 239 222 346 minecraft:brown_mushroom_block
fill 239 222 347 239 222 349 minecraft:moss_block
setblock 239 222 350 minecraft:brown_mushroom_block
fill 239 222 351 239 222 353 minecraft:moss_block
setblock 239 222 354 minecraft:brown_mushroom_block
fill 239 222 355 239 222 357 minecraft:moss_block
setblock 239 222 358 minecraft:brown_mushroom_block
fill 239 222 359 241 222 359 minecraft:moss_block
setblock 239 222 362 minecraft:brown_mushroom_block
fill 239 222 363 241 222 363 minecraft:moss_block
fill 240 222 323 240 222 324 minecraft:moss_block
setblock 240 222 325 minecraft:brown_mushroom_block
fill 240 222 326 240 222 328 minecraft:moss_block
setblock 240 222 329 minecraft:brown_mushroom_block
fill 240 222 330 240 222 332 minecraft:moss_block
setblock 240 222 333 minecraft:brown_mushroom_block
fill 240 222 334 240 222 336 minecraft:moss_block
setblock 240 222 337 minecraft:brown_mushroom_block
fill 240 222 338 240 222 340 minecraft:moss_block
setblock 240 222 341 minecraft:brown_mushroom_block
fill 240 222 342 240 222 344 minecraft:moss_block
setblock 240 222 345 minecraft:brown_mushroom_block
fill 240 222 346 240 222 348 minecraft:moss_block
setblock 240 222 349 minecraft:brown_mushroom_block
fill 240 222 350 240 222 352 minecraft:moss_block
setblock 240 222 353 minecraft:brown_mushroom_block
fill 240 222 354 240 222 356 minecraft:moss_block
setblock 240 222 357 minecraft:brown_mushroom_block
fill 240 222 358 242 222 358 minecraft:moss_block
setblock 240 222 361 minecraft:brown_mushroom_block
fill 240 222 362 242 222 362 minecraft:moss_block
setblock 241 222 323 minecraft:moss_block
setblock 241 222 324 minecraft:brown_mushroom_block
fill 241 222 325 241 222 327 minecraft:moss_block
setblock 241 222 328 minecraft:brown_mushroom_block
fill 241 222 329 241 222 331 minecraft:moss_block
setblock 241 222 332 minecraft:brown_mushroom_block
fill 241 222 333 241 222 335 minecraft:moss_block
setblock 241 222 336 minecraft:brown_mushroom_block
fill 241 222 337 241 222 339 minecraft:moss_block
setblock 241 222 340 minecraft:brown_mushroom_block
fill 241 222 341 241 222 343 minecraft:moss_block
setblock 241 222 344 minecraft:brown_mushroom_block
fill 241 222 345 241 222 346 minecraft:moss_block
fill 241 222 347 241 222 348 minecraft:brown_mushroom_block
fill 241 222 349 241 222 351 minecraft:moss_block
setblock 241 222 352 minecraft:brown_mushroom_block
fill 241 222 353 241 222 355 minecraft:moss_block
setblock 241 222 356 minecraft:brown_mushroom_block
fill 241 222 357 243 222 357 minecraft:moss_block
setblock 241 222 360 minecraft:brown_mushroom_block
fill 241 222 361 243 222 361 minecraft:moss_block
setblock 242 222 323 minecraft:brown_mushroom_block
fill 242 222 324 242 222 326 minecraft:moss_block
setblock 242 222 327 minecraft:brown_mushroom_block
fill 242 222 328 242 222 330 minecraft:moss_block
setblock 242 222 331 minecraft:brown_mushroom_block
fill 242 222 332 242 222 334 minecraft:moss_block
setblock 242 222 335 minecraft:brown_mushroom_block
fill 242 222 336 242 222 338 minecraft:moss_block
setblock 242 222 339 minecraft:brown_mushroom_block
fill 242 222 340 242 222 342 minecraft:moss_block
fill 242 222 343 242 222 346 minecraft:mushroom_stem
fill 242 222 347 245 222 347 minecraft:brown_mushroom_block
fill 242 222 348 242 222 351 minecraft:mushroom_stem
fill 242 222 352 242 222 354 minecraft:moss_block
setblock 242 222 355 minecraft:brown_mushroom_block
fill 242 222 356 244 222 356 minecraft:moss_block
setblock 242 222 359 minecraft:brown_mushroom_block
fill 242 222 360 244 222 360 minecraft:moss_block
setblock 242 222 363 minecraft:brown_mushroom_block
fill 243 222 323 243 222 325 minecraft:moss_block
setblock 243 222 326 minecraft:brown_mushroom_block
fill 243 222 327 243 222 329 minecraft:moss_block
setblock 243 222 330 minecraft:brown_mushroom_block
fill 243 222 331 243 222 333 minecraft:moss_block
setblock 243 222 334 minecraft:brown_mushroom_block
fill 243 222 335 243 222 337 minecraft:moss_block
setblock 243 222 338 minecraft:brown_mushroom_block
fill 243 222 339 243 222 340 minecraft:moss_block
fill 243 222 341 243 222 342 minecraft:mushroom_stem
fill 243 222 343 245 222 346 minecraft:brown_mushroom_block
fill 243 222 348 245 222 351 minecraft:brown_mushroom_block
fill 243 222 352 243 222 353 minecraft:mushroom_stem
setblock 243 222 354 minecraft:brown_mushroom_block
fill 243 222 355 244 222 355 minecraft:moss_block
setblock 243 222 358 minecraft:brown_mushroom_block
fill 243 222 359 245 222 359 minecraft:moss_block
setblock 243 222 362 minecraft:brown_mushroom_block
fill 243 222 363 245 222 363 minecraft:moss_block
fill 244 222 323 244 222 324 minecraft:moss_block
setblock 244 222 325 minecraft:brown_mushroom_block
fill 244 222 326 244 222 328 minecraft:moss_block
setblock 244 222 329 minecraft:brown_mushroom_block
fill 244 222 330 244 222 332 minecraft:moss_block
setblock 244 222 333 minecraft:brown_mushroom_block
fill 244 222 334 244 222 336 minecraft:moss_block
setblock 244 222 337 minecraft:brown_mushroom_block
fill 244 222 338 244 222 339 minecraft:moss_block
setblock 244 222 340 minecraft:mushroom_stem
fill 244 222 341 247 222 342 minecraft:brown_mushroom_block
fill 244 222 352 247 222 353 minecraft:brown_mushroom_block
setblock 244 222 354 minecraft:mushroom_stem
setblock 244 222 357 minecraft:brown_mushroom_block
fill 244 222 358 246 222 358 minecraft:moss_block
setblock 244 222 361 minecraft:brown_mushroom_block
fill 244 222 362 246 222 362 minecraft:moss_block
setblock 245 222 323 minecraft:moss_block
setblock 245 222 324 minecraft:brown_mushroom_block
fill 245 222 325 245 222 327 minecraft:moss_block
setblock 245 222 328 minecraft:brown_mushroom_block
fill 245 222 329 245 222 331 minecraft:moss_block
setblock 245 222 332 minecraft:brown_mushroom_block
fill 245 222 333 245 222 335 minecraft:moss_block
setblock 245 222 336 minecraft:brown_mushroom_block
fill 245 222 337 245 222 338 minecraft:moss_block
setblock 245 222 339 minecraft:mushroom_stem
fill 245 222 340 259 222 340 minecraft:brown_mushroom_block
fill 245 222 354 259 222 354 minecraft:brown_mushroom_block
setblock 245 222 355 minecraft:mushroom_stem
setblock 245 222 356 minecraft:brown_mushroom_block
fill 245 222 357 247 222 357 minecraft:moss_block
setblock 245 222 360 minecraft:brown_mushroom_block
fill 245 222 361 247 222 361 minecraft:moss_block
setblock 246 222 323 minecraft:brown_mushroom_block
fill 246 222 324 246 222 326 minecraft:moss_block
setblock 246 222 327 minecraft:brown_mushroom_block
fill 246 222 328 246 222 330 minecraft:moss_block
setblock 246 222 331 minecraft:brown_mushroom_block
fill 246 222 332 246 222 334 minecraft:moss_block
setblock 246 222 335 minecraft:brown_mushroom_block
fill 246 222 336 247 222 337 minecraft:moss_block
fill 246 222 338 247 222 338 minecraft:mushroom_stem
fill 246 222 339 258 222 339 minecraft:brown_mushroom_block
fill 246 222 343 246 222 344 minecraft:brown_mushroom_block
fill 246 222 345 249 222 349 minecraft:mossy_stone_bricks
fill 246 222 350 246 222 351 minecraft:brown_mushroom_block
fill 246 222 355 258 222 355 minecraft:brown_mushroom_block
fill 246 222 356 247 222 356 minecraft:mushroom_stem
setblock 246 222 359 minecraft:brown_mushroom_block
fill 246 222 360 248 222 360 minecraft:moss_block
setblock 246 222 363 minecraft:brown_mushroom_block
fill 247 222 323 247 222 325 minecraft:moss_block
setblock 247 222 326 minecraft:brown_mushroom_block
fill 247 222 327 247 222 329 minecraft:moss_block
setblock 247 222 330 minecraft:brown_mushroom_block
fill 247 222 331 247 222 333 minecraft:moss_block
setblock 247 222 334 minecraft:brown_mushroom_block
fill 247 222 335 249 222 335 minecraft:moss_block
fill 247 222 343 257 222 344 minecraft:mossy_stone_bricks
fill 247 222 350 257 222 351 minecraft:mossy_stone_bricks
setblock 247 222 358 minecraft:brown_mushroom_block
fill 247 222 359 249 222 359 minecraft:moss_block
setblock 247 222 362 minecraft:brown_mushroom_block
fill 247 222 363 249 222 363 minecraft:moss_block
fill 248 222 323 248 222 324 minecraft:moss_block
setblock 248 222 325 minecraft:brown_mushroom_block
fill 248 222 326 248 222 328 minecraft:moss_block
setblock 248 222 329 minecraft:brown_mushroom_block
fill 248 222 330 248 222 332 minecraft:moss_block
setblock 248 222 333 minecraft:brown_mushroom_block
fill 248 222 334 250 222 334 minecraft:moss_block
setblock 248 222 336 minecraft:moss_block
fill 248 222 337 251 222 337 minecraft:mushroom_stem
fill 248 222 338 256 222 338 minecraft:brown_mushroom_block
fill 248 222 341 249 222 341 minecraft:brown_mushroom_block
fill 248 222 342 256 222 342 minecraft:mossy_stone_bricks
fill 248 222 352 256 222 352 minecraft:mossy_stone_bricks
fill 248 222 353 249 222 353 minecraft:brown_mushroom_block
fill 248 222 356 256 222 356 minecraft:brown_mushroom_block
fill 248 222 357 251 222 357 minecraft:mushroom_stem
fill 248 222 358 250 222 358 minecraft:moss_block
setblock 248 222 361 minecraft:brown_mushroom_block
fill 248 222 362 250 222 362 minecraft:moss_block
setblock 248 222 364 minecraft:shroomlight
setblock 249 222 323 minecraft:moss_block
setblock 249 222 324 minecraft:brown_mushroom_block
fill 249 222 325 249 222 327 minecraft:moss_block
setblock 249 222 328 minecraft:brown_mushroom_block
fill 249 222 329 249 222 331 minecraft:moss_block
setblock 249 222 332 minecraft:brown_mushroom_block
fill 249 222 333 251 222 333 minecraft:moss_block
setblock 249 222 336 minecraft:brown_mushroom_block
setblock 249 222 360 minecraft:brown_mushroom_block
fill 249 222 361 251 222 361 minecraft:moss_block
setblock 250 222 323 minecraft:brown_mushroom_block
fill 250 222 324 250 222 326 minecraft:moss_block
setblock 250 222 327 minecraft:brown_mushroom_block
fill 250 222 328 250 222 330 minecraft:moss_block
setblock 250 222 331 minecraft:brown_mushroom_block
fill 250 222 332 252 222 332 minecraft:moss_block
setblock 250 222 335 minecraft:brown_mushroom_block
fill 250 222 336 251 222 336 minecraft:moss_block
fill 250 222 341 254 222 341 minecraft:mossy_stone_bricks
setblock 250 222 345 minecraft:mossy_stone_bricks
setblock 250 222 349 minecraft:mossy_stone_bricks
fill 250 222 353 254 222 353 minecraft:mossy_stone_bricks
setblock 250 222 359 minecraft:brown_mushroom_block
fill 250 222 360 252 222 360 minecraft:moss_block
setblock 250 222 363 minecraft:brown_mushroom_block
fill 251 222 323 251 222 325 minecraft:moss_block
setblock 251 222 326 minecraft:brown_mushroom_block
fill 251 222 327 251 222 329 minecraft:moss_block
setblock 251 222 330 minecraft:brown_mushroom_block
fill 251 222 331 253 222 331 minecraft:moss_block
setblock 251 222 334 minecraft:brown_mushroom_block
fill 251 222 335 253 222 335 minecraft:moss_block
setblock 251 222 358 minecraft:brown_mushroom_block
fill 251 222 359 253 222 359 minecraft:moss_block
setblock 251 222 362 minecraft:brown_mushroom_block
fill 251 222 363 253 222 363 minecraft:moss_block
fill 252 222 323 252 222 324 minecraft:moss_block
setblock 252 222 325 minecraft:brown_mushroom_block
fill 252 222 326 252 222 328 minecraft:moss_block
setblock 252 222 329 minecraft:brown_mushroom_block
fill 252 222 330 254 222 330 minecraft:moss_block
setblock 252 222 333 minecraft:brown_mushroom_block
fill 252 222 334 254 222 334 minecraft:moss_block
setblock 252 222 337 minecraft:brown_mushroom_block
setblock 252 222 357 minecraft:brown_mushroom_block
setblock 252 222 361 minecraft:brown_mushroom_block
fill 252 222 362 254 222 362 minecraft:moss_block
setblock 253 222 323 minecraft:moss_block
setblock 253 222 324 minecraft:brown_mushroom_block
fill 253 222 325 253 222 327 minecraft:moss_block
setblock 253 222 328 minecraft:brown_mushroom_block
fill 253 222 329 255 222 329 minecraft:moss_block
setblock 253 222 332 minecraft:brown_mushroom_block
fill 253 222 333 255 222 333 minecraft:moss_block
setblock 253 222 336 minecraft:brown_mushroom_block
fill 253 222 337 256 222 337 minecraft:mushroom_stem
fill 253 222 357 256 222 357 minecraft:mushroom_stem
fill 253 222 358 254 222 358 minecraft:moss_block
setblock 253 222 360 minecraft:brown_mushroom_block
fill 253 222 361 255 222 361 minecraft:moss_block
setblock 254 222 323 minecraft:brown_mushroom_block
fill 254 222 324 254 222 326 minecraft:moss_block
setblock 254 222 327 minecraft:brown_mushroom_block
fill 254 222 328 256 222 328 minecraft:moss_block
setblock 254 222 331 minecraft:brown_mushroom_block
fill 254 222 332 256 222 332 minecraft:moss_block
setblock 254 222 335 minecraft:brown_mushroom_block
fill 254 222 336 256 222 336 minecraft:moss_block
fill 254 222 345 258 222 345 minecraft:mossy_stone_bricks
fill 254 222 349 258 222 349 minecraft:mossy_stone_bricks
setblock 254 222 359 minecraft:brown_mushroom_block
fill 254 222 360 256 222 360 minecraft:moss_block
setblock 254 222 363 minecraft:brown_mushroom_block
fill 255 222 323 255 222 325 minecraft:moss_block
setblock 255 222 326 minecraft:brown_mushroom_block
fill 255 222 327 257 222 327 minecraft:moss_block
setblock 255 222 330 minecraft:brown_mushroom_block
fill 255 222 331 257 222 331 minecraft:moss_block
setblock 255 222 334 minecraft:brown_mushroom_block
fill 255 222 335 257 222 335 minecraft:moss_block
fill 255 222 341 260 222 341 minecraft:brown_mushroom_block
fill 255 222 346 258 222 348 minecraft:mossy_stone_bricks
fill 255 222 353 260 222 353 minecraft:brown_mushroom_block
setblock 255 222 358 minecraft:brown_mushroom_block
fill 255 222 359 257 222 359 minecraft:moss_block
setblock 255 222 362 minecraft:brown_mushroom_block
fill 255 222 363 257 222 363 minecraft:moss_block
fill 256 222 323 256 222 324 minecraft:moss_block
setblock 256 222 325 minecraft:brown_mushroom_block
fill 256 222 326 258 222 326 minecraft:moss_block
setblock 256 222 329 minecraft:brown_mushroom_block
fill 256 222 330 258 222 330 minecraft:moss_block
setblock 256 222 333 minecraft:brown_mushroom_block
fill 256 222 334 258 222 334 minecraft:moss_block
fill 256 222 358 258 222 358 minecraft:moss_block
setblock 256 222 361 minecraft:brown_mushroom_block
fill 256 222 362 258 222 362 minecraft:moss_block
setblock 257 222 323 minecraft:moss_block
setblock 257 222 324 minecraft:brown_mushroom_block
fill 257 222 325 259 222 325 minecraft:moss_block
setblock 257 222 328 minecraft:brown_mushroom_block
fill 257 222 329 259 222 329 minecraft:moss_block
setblock 257 222 332 minecraft:brown_mushroom_block
fill 257 222 333 259 222 333 minecraft:moss_block
setblock 257 222 336 minecraft:brown_mushroom_block
fill 257 222 337 259 222 337 minecraft:moss_block
fill 257 222 338 258 222 338 minecraft:mushroom_stem
fill 257 222 342 260 222 342 minecraft:brown_mushroom_block
fill 257 222 352 260 222 352 minecraft:brown_mushroom_block
fill 257 222 356 258 222 356 minecraft:mushroom_stem
fill 257 222 357 259 222 357 minecraft:moss_block
setblock 257 222 360 minecraft:brown_mushroom_block
fill 257 222 361 259 222 361 minecraft:moss_block
setblock 258 222 323 minecraft:brown_mushroom_block
fill 258 222 324 260 222 324 minecraft:moss_block
setblock 258 222 327 minecraft:brown_mushroom_block
fill 258 222 328 260 222 328 minecraft:moss_block
setblock 258 222 331 minecraft:brown_mushroom_block
fill 258 222 332 260 222 332 minecraft:moss_block
setblock 258 222 335 minecraft:brown_mushroom_block
fill 258 222 336 260 222 336 minecraft:moss_block
fill 258 222 343 261 222 344 minecraft:brown_mushroom_block
fill 258 222 350 261 222 351 minecraft:brown_mushroom_block
setblock 258 222 359 minecraft:brown_mushroom_block
fill 258 222 360 260 222 360 minecraft:moss_block
setblock 258 222 363 minecraft:brown_mushroom_block
fill 259 222 323 261 222 323 minecraft:moss_block
setblock 259 222 326 minecraft:brown_mushroom_block
fill 259 222 327 261 222 327 minecraft:moss_block
setblock 259 222 330 minecraft:brown_mushroom_block
fill 259 222 331 261 222 331 minecraft:moss_block
setblock 259 222 334 minecraft:brown_mushroom_block
fill 259 222 335 261 222 335 minecraft:moss_block
setblock 259 222 338 minecraft:brown_mushroom_block
setblock 259 222 339 minecraft:mushroom_stem
fill 259 222 345 261 222 349 minecraft:brown_mushroom_block
setblock 259 222 355 minecraft:mushroom_stem
fill 259 222 356 260 222 356 minecraft:moss_block
setblock 259 222 358 minecraft:brown_mushroom_block
fill 259 222 359 261 222 359 minecraft:moss_block
setblock 259 222 362 minecraft:brown_mushroom_block
fill 259 222 363 261 222 363 minecraft:moss_block
setblock 260 222 325 minecraft:brown_mushroom_block
fill 260 222 326 262 222 326 minecraft:moss_block
setblock 260 222 329 minecraft:brown_mushroom_block
fill 260 222 330 262 222 330 minecraft:moss_block
setblock 260 222 333 minecraft:brown_mushroom_block
fill 260 222 334 262 222 334 minecraft:moss_block
setblock 260 222 337 minecraft:brown_mushroom_block
fill 260 222 338 261 222 339 minecraft:moss_block
setblock 260 222 340 minecraft:mushroom_stem
setblock 260 222 354 minecraft:mushroom_stem
fill 260 222 355 261 222 355 minecraft:moss_block
setblock 260 222 357 minecraft:brown_mushroom_block
fill 260 222 358 262 222 358 minecraft:moss_block
setblock 260 222 361 minecraft:brown_mushroom_block
fill 260 222 362 262 222 362 minecraft:moss_block
setblock 261 222 324 minecraft:brown_mushroom_block
fill 261 222 325 263 222 325 minecraft:moss_block
setblock 261 222 328 minecraft:brown_mushroom_block
fill 261 222 329 263 222 329 minecraft:moss_block
setblock 261 222 332 minecraft:brown_mushroom_block
fill 261 222 333 263 222 333 minecraft:moss_block
setblock 261 222 336 minecraft:brown_mushroom_block
fill 261 222 337 263 222 337 minecraft:moss_block
setblock 261 222 340 minecraft:brown_mushroom_block
fill 261 222 341 261 222 342 minecraft:mushroom_stem
fill 261 222 352 261 222 353 minecraft:mushroom_stem
fill 261 222 354 262 222 354 minecraft:moss_block
setblock 261 222 356 minecraft:brown_mushroom_block
fill 261 222 357 263 222 357 minecraft:moss_block
setblock 261 222 360 minecraft:brown_mushroom_block
fill 261 222 361 263 222 361 minecraft:moss_block
setblock 262 222 323 minecraft:brown_mushroom_block
fill 262 222 324 264 222 324 minecraft:moss_block
setblock 262 222 327 minecraft:brown_mushroom_block
fill 262 222 328 264 222 328 minecraft:moss_block
setblock 262 222 331 minecraft:brown_mushroom_block
fill 262 222 332 264 222 332 minecraft:moss_block
setblock 262 222 335 minecraft:brown_mushroom_block
fill 262 222 336 264 222 336 minecraft:moss_block
setblock 262 222 338 minecraft:moss_block
setblock 262 222 339 minecraft:brown_mushroom_block
fill 262 222 340 262 222 342 minecraft:moss_block
fill 262 222 343 262 222 346 minecraft:mushroom_stem
setblock 262 222 347 minecraft:brown_mushroom_block
fill 262 222 348 262 222 351 minecraft:mushroom_stem
fill 262 222 352 263 222 353 minecraft:moss_block
setblock 262 222 355 minecraft:brown_mushroom_block
fill 262 222 356 264 222 356 minecraft:moss_block
setblock 262 222 359 minecraft:brown_mushroom_block
fill 262 222 360 264 222 360 minecraft:moss_block
setblock 262 222 363 minecraft:brown_mushroom_block
fill 263 222 323 265 222 323 minecraft:moss_block
setblock 263 222 326 minecraft:brown_mushroom_block
fill 263 222 327 265 222 327 minecraft:moss_block
setblock 263 222 330 minecraft:brown_mushroom_block
fill 263 222 331 265 222 331 minecraft:moss_block
setblock 263 222 334 minecraft:brown_mushroom_block
fill 263 222 335 265 222 335 minecraft:moss_block
setblock 263 222 338 minecraft:brown_mushroom_block
fill 263 222 339 263 222 341 minecraft:moss_block
setblock 263 222 342 minecraft:brown_mushroom_block
fill 263 222 343 263 222 345 minecraft:moss_block
setblock 263 222 346 minecraft:brown_mushroom_block
fill 263 222 348 263 222 349 minecraft:moss_block
setblock 263 222 350 minecraft:brown_mushroom_block
fill 263 222 351 265 222 351 minecraft:moss_block
setblock 263 222 354 minecraft:brown_mushroom_block
fill 263 222 355 265 222 355 minecraft:moss_block
setblock 263 222 358 minecraft:brown_mushroom_block
fill 263 222 359 265 222 359 minecraft:moss_block
setblock 263 222 362 minecraft:brown_mushroom_block
fill 263 222 363 265 222 363 minecraft:moss_block
setblock 264 222 325 minecraft:brown_mushroom_block
fill 264 222 326 266 222 326 minecraft:moss_block
setblock 264 222 329 minecraft:brown_mushroom_block
fill 264 222 330 266 222 330 minecraft:moss_block
setblock 264 222 333 minecraft:brown_mushroom_block
fill 264 222 334 266 222 334 minecraft:moss_block
setblock 264 222 337 minecraft:brown_mushroom_block
fill 264 222 338 264 222 340 minecraft:moss_block
setblock 264 222 341 minecraft:brown_mushroom_block
fill 264 222 342 264 222 344 minecraft:moss_block
setblock 264 222 345 minecraft:brown_mushroom_block
fill 264 222 346 264 222 348 minecraft:moss_block
setblock 264 222 349 minecraft:brown_mushroom_block
fill 264 222 350 266 222 350 minecraft:moss_block
setblock 264 222 352 minecraft:moss_block
setblock 264 222 353 minecraft:brown_mushroom_block
fill 264 222 354 266 222 354 minecraft:moss_block
setblock 264 222 357 minecraft:brown_mushroom_block
fill 264 222 358 266 222 358 minecraft:moss_block
setblock 264 222 361 minecraft:brown_mushroom_block
fill 264 222 362 266 222 362 minecraft:moss_block
setblock 265 222 324 minecraft:brown_mushroom_block
fill 265 222 325 267 222 325 minecraft:moss_block
setblock 265 222 328 minecraft:brown_mushroom_block
fill 265 222 329 267 222 329 minecraft:moss_block
setblock 265 222 332 minecraft:brown_mushroom_block
fill 265 222 333 267 222 333 minecraft:moss_block
setblock 265 222 336 minecraft:brown_mushroom_block
fill 265 222 337 265 222 339 minecraft:moss_block
setblock 265 222 340 minecraft:brown_mushroom_block
fill 265 222 341 265 222 343 minecraft:moss_block
setblock 265 222 344 minecraft:brown_mushroom_block
fill 265 222 345 265 222 347 minecraft:moss_block
setblock 265 222 348 minecraft:brown_mushroom_block
fill 265 222 349 267 222 349 minecraft:moss_block
setblock 265 222 352 minecraft:brown_mushroom_block
fill 265 222 353 267 222 353 minecraft:moss_block
setblock 265 222 356 minecraft:brown_mushroom_block
fill 265 222 357 267 222 357 minecraft:moss_block
setblock 265 222 360 minecraft:brown_mushroom_block
fill 265 222 361 267 222 361 minecraft:moss_block
setblock 266 222 323 minecraft:brown_mushroom_block
fill 266 222 324 268 222 324 minecraft:moss_block
setblock 266 222 327 minecraft:brown_mushroom_block
fill 266 222 328 268 222 328 minecraft:moss_block
setblock 266 222 331 minecraft:brown_mushroom_block
fill 266 222 332 268 222 332 minecraft:moss_block
setblock 266 222 335 minecraft:brown_mushroom_block
fill 266 222 336 266 222 338 minecraft:moss_block
setblock 266 222 339 minecraft:brown_mushroom_block
fill 266 222 340 266 222 342 minecraft:moss_block
setblock 266 222 343 minecraft:brown_mushroom_block
fill 266 222 344 266 222 346 minecraft:moss_block
setblock 266 222 347 minecraft:brown_mushroom_block
fill 266 222 348 268 222 348 minecraft:moss_block
setblock 266 222 351 minecraft:brown_mushroom_block
fill 266 222 352 268 222 352 minecraft:moss_block
setblock 266 222 355 minecraft:brown_mushroom_block
fill 266 222 356 268 222 356 minecraft:moss_block
setblock 266 222 359 minecraft:brown_mushroom_block
fill 266 222 360 268 222 360 minecraft:moss_block
setblock 266 222 363 minecraft:brown_mushroom_block
fill 267 222 323 269 222 323 minecraft:moss_block
setblock 267 222 326 minecraft:brown_mushroom_block
fill 267 222 327 269 222 327 minecraft:moss_block
setblock 267 222 330 minecraft:brown_mushroom_block
fill 267 222 331 269 222 331 minecraft:moss_block
setblock 267 222 334 minecraft:brown_mushroom_block
fill 267 222 335 267 222 337 minecraft:moss_block
setblock 267 222 338 minecraft:brown_mushroom_block
fill 267 222 339 267 222 341 minecraft:moss_block
setblock 267 222 342 minecraft:brown_mushroom_block
fill 267 222 343 267 222 345 minecraft:moss_block
setblock 267 222 346 minecraft:brown_mushroom_block
fill 267 222 347 269 222 347 minecraft:moss_block
setblock 267 222 350 minecraft:brown_mushroom_block
fill 267 222 351 269 222 351 minecraft:moss_block
setblock 267 222 354 minecraft:brown_mushroom_block
fill 267 222 355 269 222 355 minecraft:moss_block
setblock 267 222 358 minecraft:brown_mushroom_block
fill 267 222 359 269 222 359 minecraft:moss_block
setblock 267 222 362 minecraft:brown_mushroom_block
fill 267 222 363 269 222 363 minecraft:moss_block
setblock 268 222 325 minecraft:brown_mushroom_block
fill 268 222 326 270 222 326 minecraft:moss_block
setblock 268 222 329 minecraft:brown_mushroom_block
fill 268 222 330 270 222 330 minecraft:moss_block
setblock 268 222 333 minecraft:brown_mushroom_block
fill 268 222 334 268 222 336 minecraft:moss_block
setblock 268 222 337 minecraft:brown_mushroom_block
fill 268 222 338 268 222 340 minecraft:moss_block
setblock 268 222 341 minecraft:brown_mushroom_block
fill 268 222 342 268 222 344 minecraft:moss_block
setblock 268 222 345 minecraft:brown_mushroom_block
fill 268 222 346 270 222 346 minecraft:moss_block
setblock 268 222 349 minecraft:brown_mushroom_block
fill 268 222 350 270 222 350 minecraft:moss_block
setblock 268 222 353 minecraft:brown_mushroom_block
fill 268 222 354 270 222 354 minecraft:moss_block
setblock 268 222 357 minecraft:brown_mushroom_block
fill 268 222 358 270 222 358 minecraft:moss_block
setblock 268 222 361 minecraft:brown_mushroom_block
fill 268 222 362 270 222 362 minecraft:moss_block
setblock 269 222 324 minecraft:brown_mushroom_block
fill 269 222 325 271 222 325 minecraft:moss_block
setblock 269 222 328 minecraft:brown_mushroom_block
fill 269 222 329 271 222 329 minecraft:moss_block
setblock 269 222 332 minecraft:brown_mushroom_block
fill 269 222 333 269 222 335 minecraft:moss_block
setblock 269 222 336 minecraft:brown_mushroom_block
fill 269 222 337 269 222 339 minecraft:moss_block
setblock 269 222 340 minecraft:brown_mushroom_block
fill 269 222 341 269 222 343 minecraft:moss_block
setblock 269 222 344 minecraft:brown_mushroom_block
fill 269 222 345 271 222 345 minecraft:moss_block
setblock 269 222 348 minecraft:brown_mushroom_block
fill 269 222 349 271 222 349 minecraft:moss_block
setblock 269 222 352 minecraft:brown_mushroom_block
fill 269 222 353 271 222 353 minecraft:moss_block
setblock 269 222 356 minecraft:brown_mushroom_block
fill 269 222 357 271 222 357 minecraft:moss_block
setblock 269 222 360 minecraft:brown_mushroom_block
fill 269 222 361 271 222 361 minecraft:moss_block
setblock 270 222 323 minecraft:brown_mushroom_block
fill 270 222 324 272 222 324 minecraft:moss_block
setblock 270 222 327 minecraft:brown_mushroom_block
fill 270 222 328 272 222 328 minecraft:moss_block
setblock 270 222 331 minecraft:brown_mushroom_block
fill 270 222 332 270 222 334 minecraft:moss_block
setblock 270 222 335 minecraft:brown_mushroom_block
fill 270 222 336 270 222 338 minecraft:moss_block
setblock 270 222 339 minecraft:brown_mushroom_block
fill 270 222 340 270 222 342 minecraft:moss_block
setblock 270 222 343 minecraft:brown_mushroom_block
fill 270 222 344 272 222 344 minecraft:moss_block
setblock 270 222 347 minecraft:brown_mushroom_block
fill 270 222 348 272 222 348 minecraft:moss_block
setblock 270 222 351 minecraft:brown_mushroom_block
fill 270 222 352 272 222 352 minecraft:moss_block
setblock 270 222 355 minecraft:brown_mushroom_block
fill 270 222 356 272 222 356 minecraft:moss_block
setblock 270 222 359 minecraft:brown_mushroom_block
fill 270 222 360 272 222 360 minecraft:moss_block
setblock 270 222 363 minecraft:brown_mushroom_block
fill 271 222 323 273 222 323 minecraft:moss_block
setblock 271 222 326 minecraft:brown_mushroom_block
fill 271 222 327 273 222 327 minecraft:moss_block
setblock 271 222 330 minecraft:brown_mushroom_block
fill 271 222 331 271 222 333 minecraft:moss_block
setblock 271 222 334 minecraft:brown_mushroom_block
fill 271 222 335 271 222 337 minecraft:moss_block
setblock 271 222 338 minecraft:brown_mushroom_block
fill 271 222 339 271 222 341 minecraft:moss_block
setblock 271 222 342 minecraft:brown_mushroom_block
fill 271 222 343 273 222 343 minecraft:moss_block
setblock 271 222 346 minecraft:brown_mushroom_block
fill 271 222 347 273 222 347 minecraft:moss_block
setblock 271 222 350 minecraft:brown_mushroom_block
fill 271 222 351 273 222 351 minecraft:moss_block
setblock 271 222 354 minecraft:brown_mushroom_block
fill 271 222 355 273 222 355 minecraft:moss_block
setblock 271 222 358 minecraft:brown_mushroom_block
fill 271 222 359 273 222 359 minecraft:moss_block
setblock 271 222 362 minecraft:brown_mushroom_block
fill 271 222 363 273 222 363 minecraft:moss_block
setblock 272 222 325 minecraft:brown_mushroom_block
fill 272 222 326 274 222 326 minecraft:moss_block
setblock 272 222 329 minecraft:brown_mushroom_block
fill 272 222 330 272 222 332 minecraft:moss_block
setblock 272 222 333 minecraft:brown_mushroom_block
fill 272 222 334 272 222 336 minecraft:moss_block
setblock 272 222 337 minecraft:brown_mushroom_block
fill 272 222 338 272 222 340 minecraft:moss_block
setblock 272 222 341 minecraft:brown_mushroom_block
fill 272 222 342 274 222 342 minecraft:moss_block
setblock 272 222 345 minecraft:brown_mushroom_block
fill 272 222 346 274 222 346 minecraft:moss_block
setblock 272 222 349 minecraft:brown_mushroom_block
fill 272 222 350 274 222 350 minecraft:moss_block
setblock 272 222 353 minecraft:brown_mushroom_block
fill 272 222 354 274 222 354 minecraft:moss_block
setblock 272 222 357 minecraft:brown_mushroom_block
fill 272 222 358 274 222 358 minecraft:moss_block
setblock 272 222 361 minecraft:brown_mushroom_block
fill 272 222 362 274 222 362 minecraft:moss_block
setblock 273 222 324 minecraft:brown_mushroom_block
fill 273 222 325 275 222 325 minecraft:moss_block
setblock 273 222 328 minecraft:brown_mushroom_block
fill 273 222 329 273 222 331 minecraft:moss_block
setblock 273 222 332 minecraft:brown_mushroom_block
fill 273 222 333 273 222 335 minecraft:moss_block
setblock 273 222 336 minecraft:brown_mushroom_block
fill 273 222 337 273 222 339 minecraft:moss_block
setblock 273 222 340 minecraft:brown_mushroom_block
fill 273 222 341 275 222 341 minecraft:moss_block
setblock 273 222 344 minecraft:brown_mushroom_block
fill 273 222 345 275 222 345 minecraft:moss_block
setblock 273 222 348 minecraft:brown_mushroom_block
fill 273 222 349 275 222 349 minecraft:moss_block
setblock 273 222 352 minecraft:brown_mushroom_block
fill 273 222 353 275 222 353 minecraft:moss_block
setblock 273 222 356 minecraft:brown_mushroom_block
fill 273 222 357 275 222 357 minecraft:moss_block
setblock 273 222 360 minecraft:brown_mushroom_block
fill 273 222 361 275 222 361 minecraft:moss_block
setblock 274 222 323 minecraft:brown_mushroom_block
fill 274 222 324 276 222 324 minecraft:moss_block
setblock 274 222 327 minecraft:brown_mushroom_block
fill 274 222 328 274 222 330 minecraft:moss_block
setblock 274 222 331 minecraft:brown_mushroom_block
fill 274 222 332 274 222 334 minecraft:moss_block
setblock 274 222 335 minecraft:brown_mushroom_block
fill 274 222 336 274 222 338 minecraft:moss_block
setblock 274 222 339 minecraft:brown_mushroom_block
fill 274 222 340 276 222 340 minecraft:moss_block
setblock 274 222 343 minecraft:brown_mushroom_block
fill 274 222 344 276 222 344 minecraft:moss_block
setblock 274 222 347 minecraft:brown_mushroom_block
fill 274 222 348 276 222 348 minecraft:moss_block
setblock 274 222 351 minecraft:brown_mushroom_block
fill 274 222 352 276 222 352 minecraft:moss_block
setblock 274 222 355 minecraft:brown_mushroom_block
fill 274 222 356 276 222 356 minecraft:moss_block
setblock 274 222 359 minecraft:brown_mushroom_block
fill 274 222 360 276 222 360 minecraft:moss_block
setblock 274 222 363 minecraft:brown_mushroom_block
fill 275 222 323 276 222 323 minecraft:moss_block
setblock 275 222 326 minecraft:brown_mushroom_block
fill 275 222 327 275 222 329 minecraft:moss_block
setblock 275 222 330 minecraft:brown_mushroom_block
fill 275 222 331 275 222 333 minecraft:moss_block
setblock 275 222 334 minecraft:brown_mushroom_block
fill 275 222 335 275 222 337 minecraft:moss_block
setblock 275 222 338 minecraft:brown_mushroom_block
fill 275 222 339 276 222 339 minecraft:moss_block
setblock 275 222 342 minecraft:brown_mushroom_block
fill 275 222 343 276 222 343 minecraft:moss_block
setblock 275 222 346 minecraft:brown_mushroom_block
fill 275 222 347 276 222 347 minecraft:moss_block
setblock 275 222 350 minecraft:brown_mushroom_block
fill 275 222 351 276 222 351 minecraft:moss_block
setblock 275 222 354 minecraft:brown_mushroom_block
fill 275 222 355 276 222 355 minecraft:moss_block
setblock 275 222 358 minecraft:brown_mushroom_block
fill 275 222 359 276 222 359 minecraft:moss_block
setblock 275 222 362 minecraft:brown_mushroom_block
fill 275 222 363 276 222 363 minecraft:moss_block
setblock 276 222 325 minecraft:brown_mushroom_block
fill 276 222 326 276 222 328 minecraft:moss_block
setblock 276 222 329 minecraft:brown_mushroom_block
fill 276 222 330 276 222 332 minecraft:moss_block
setblock 276 222 333 minecraft:brown_mushroom_block
fill 276 222 334 276 222 336 minecraft:moss_block
setblock 276 222 337 minecraft:brown_mushroom_block
setblock 276 222 338 minecraft:moss_block
setblock 276 222 341 minecraft:brown_mushroom_block
setblock 276 222 342 minecraft:moss_block
setblock 276 222 345 minecraft:brown_mushroom_block
setblock 276 222 346 minecraft:moss_block
setblock 276 222 349 minecraft:brown_mushroom_block
setblock 276 222 350 minecraft:moss_block
setblock 276 222 353 minecraft:brown_mushroom_block
setblock 276 222 354 minecraft:moss_block
setblock 276 222 357 minecraft:brown_mushroom_block
setblock 276 222 358 minecraft:moss_block
setblock 276 222 361 minecraft:brown_mushroom_block
setblock 276 222 362 minecraft:moss_block
setblock 235 223 361 minecraft:shroomlight
fill 244 223 345 245 232 349 minecraft:stone_bricks
fill 245 223 340 247 235 343 minecraft:cobblestone
fill 245 223 344 246 232 344 minecraft:stone_bricks
fill 245 223 350 246 233 350 minecraft:stone_bricks
fill 245 223 351 247 235 354 minecraft:cobblestone
fill 248 223 340 248 235 342 minecraft:cobblestone
fill 248 223 352 248 235 354 minecraft:cobblestone
fill 248 223 364 248 225 364 minecraft:green_terracotta
fill 249 223 340 249 232 341 minecraft:stone_bricks
fill 249 223 353 249 232 354 minecraft:stone_bricks
fill 250 223 339 254 232 340 minecraft:stone_bricks
fill 250 223 354 254 232 355 minecraft:stone_bricks
fill 255 223 340 255 232 341 minecraft:stone_bricks
fill 255 223 353 255 233 354 minecraft:stone_bricks
fill 256 223 340 259 235 342 minecraft:cobblestone
fill 256 223 352 259 235 354 minecraft:cobblestone
fill 257 223 343 259 235 343 minecraft:cobblestone
fill 257 223 351 259 235 351 minecraft:cobblestone
fill 258 223 344 259 233 344 minecraft:stone_bricks
fill 258 223 350 259 232 350 minecraft:stone_bricks
fill 259 223 345 260 232 349 minecraft:stone_bricks
fill 235 224 361 235 228 361 minecraft:green_terracotta
setblock 240 224 364 minecraft:red_mushroom_block
setblock 277 224 323 minecraft:red_mushroom_block
fill 277 224 324 277 228 324 minecraft:green_terracotta
fill 235 225 322 235 225 323 minecraft:moss_block
setblock 235 225 334 minecraft:moss_block
setblock 235 225 339 minecraft:shroomlight
setblock 235 225 341 minecraft:moss_block
setblock 235 225 346 minecraft:moss_block
setblock 235 225 349 minecraft:moss_block
fill 235 225 350 235 225 353 minecraft:green_terracotta
setblock 235 225 354 minecraft:moss_block
fill 235 225 364 236 225 364 minecraft:moss_block
setblock 238 225 325 minecraft:light[level=12]
setblock 238 225 332 minecraft:light[level=12]
setblock 238 225 339 minecraft:light[level=12]
setblock 238 225 346 minecraft:light[level=12]
setblock 238 225 353 minecraft:light[level=12]
setblock 238 225 360 minecraft:light[level=12]
setblock 239 225 364 minecraft:moss_block
fill 240 225 364 240 228 364 minecraft:green_terracotta
setblock 242 225 364 minecraft:moss_block
setblock 245 225 325 minecraft:light[level=12]
setblock 245 225 332 minecraft:light[level=12]
setblock 245 225 339 minecraft:light[level=12]
setblock 245 225 360 minecraft:light[level=12]
setblock 247 225 322 minecraft:moss_block
fill 250 225 322 251 226 322 minecraft:green_terracotta
setblock 250 225 364 minecraft:shroomlight
fill 252 225 322 253 225 322 minecraft:moss_block
setblock 252 225 325 minecraft:light[level=12]
setblock 252 225 332 minecraft:light[level=12]
setblock 252 225 353 minecraft:light[level=12]
setblock 252 225 360 minecraft:light[level=12]
setblock 259 225 325 minecraft:light[level=12]
setblock 259 225 332 minecraft:light[level=12]
setblock 259 225 339 minecraft:light[level=12]
setblock 259 225 360 minecraft:light[level=12]
setblock 266 225 325 minecraft:light[level=12]
setblock 266 225 332 minecraft:light[level=12]
setblock 266 225 339 minecraft:light[level=12]
setblock 266 225 346 minecraft:light[level=12]
setblock 266 225 353 minecraft:light[level=12]
setblock 266 225 360 minecraft:light[level=12]
setblock 273 225 325 minecraft:light[level=12]
setblock 273 225 332 minecraft:light[level=12]
setblock 273 225 339 minecraft:light[level=12]
setblock 273 225 346 minecraft:light[level=12]
setblock 273 225 353 minecraft:light[level=12]
setblock 273 225 360 minecraft:light[level=12]
fill 277 225 323 277 228 323 minecraft:green_terracotta
fill 277 225 328 277 225 329 minecraft:moss_block
setblock 277 225 341 minecraft:moss_block
setblock 277 225 355 minecraft:moss_block
fill 235 226 322 235 226 323 minecraft:green_terracotta
fill 235 226 327 235 226 328 minecraft:green_terracotta
setblock 235 226 329 minecraft:moss_block
fill 235 226 334 235 228 334 minecraft:green_terracotta
fill 235 226 339 235 229 339 minecraft:green_terracotta
setblock 235 226 340 minecraft:shroomlight
fill 235 226 341 235 228 341 minecraft:green_terracotta
setblock 235 226 346 minecraft:green_terracotta
fill 235 226 349 235 228 349 minecraft:green_terracotta
setblock 235 226 350 minecraft:moss_block
fill 235 226 351 235 228 351 minecraft:green_terracotta
fill 235 226 352 235 227 352 minecraft:moss_block
fill 235 226 353 235 228 354 minecraft:green_terracotta
setblock 235 226 357 minecraft:moss_block
fill 235 226 364 235 229 364 minecraft:green_terracotta
fill 236 226 322 236 227 322 minecraft:moss_block
fill 236 226 335 236 226 338 minecraft:moss_block
setblock 236 226 339 minecraft:mushroom_stem
fill 236 226 340 236 226 343 minecraft:moss_block
setblock 236 226 344 minecraft:mushroom_stem
fill 236 226 345 236 229 345 minecraft:moss_block
setblock 236 226 360 minecraft:red_mushroom_block
fill 236 226 364 236 227 364 minecraft:moss_block
setblock 237 226 338 minecraft:mushroom_stem
fill 237 226 339 237 226 342 minecraft:moss_block
setblock 239 226 322 minecraft:moss_block
fill 239 226 363 239 227 363 minecraft:red_mushroom_block
fill 239 226 364 239 228 364 minecraft:green_terracotta
setblock 241 226 323 minecraft:moss_block
setblock 241 226 363 minecraft:moss_block
setblock 242 226 323 minecraft:mushroom_stem
setblock 242 226 363 minecraft:mushroom_stem
fill 242 226 364 242 228 364 minecraft:green_terracotta
fill 243 226 323 245 226 324 minecraft:moss_block
fill 243 226 363 246 226 363 minecraft:moss_block
setblock 243 226 364 minecraft:shroomlight
fill 244 226 362 247 226 362 minecraft:moss_block
setblock 244 226 364 minecraft:moss_block
setblock 246 226 323 minecraft:moss_block
setblock 246 226 324 minecraft:mushroom_stem
fill 247 226 322 247 228 322 minecraft:green_terracotta
setblock 247 226 323 minecraft:mushroom_stem
fill 247 226 324 250 226 324 minecraft:moss_block
setblock 247 226 363 minecraft:mushroom_stem
fill 248 226 323 251 226 323 minecraft:moss_block
setblock 248 226 362 minecraft:mushroom_stem
fill 248 226 363 251 226 363 minecraft:moss_block
setblock 248 226 364 minecraft:red_mushroom_block
fill 249 226 362 252 226 362 minecraft:moss_block
setblock 250 226 364 minecraft:moss_block
setblock 251 226 324 minecraft:mushroom_stem
fill 252 226 322 253 226 322 minecraft:green_terracotta
setblock 252 226 323 minecraft:mushroom_stem
fill 252 226 324 252 229 324 minecraft:moss_block
fill 252 226 325 252 230 325 minecraft:iron_block
setblock 252 226 363 minecraft:mushroom_stem
fill 253 226 323 256 226 323 minecraft:moss_block
setblock 253 226 362 minecraft:mushroom_stem
fill 253 226 363 256 226 363 minecraft:moss_block
fill 254 226 362 254 229 362 minecraft:moss_block
fill 255 226 326 259 232 328 minecraft:dirt
fill 256 226 325 258 232 325 minecraft:dirt
fill 256 226 329 258 232 329 minecraft:dirt
setblock 257 226 323 minecraft:mushroom_stem
setblock 257 226 362 minecraft:moss_block
setblock 257 226 363 minecraft:mushroom_stem
fill 258 226 323 261 226 323 minecraft:moss_block
setblock 258 226 362 minecraft:mushroom_stem
fill 258 226 363 261 226 363 minecraft:moss_block
fill 259 226 362 262 226 362 minecraft:moss_block
setblock 260 226 322 minecraft:moss_block
fill 261 226 361 263 226 361 minecraft:moss_block
setblock 262 226 322 minecraft:green_terracotta
setblock 262 226 323 minecraft:mushroom_stem
fill 262 226 339 265 269 340 minecraft:mushroom_stem
setblock 262 226 363 minecraft:mushroom_stem
fill 263 226 322 264 226 323 minecraft:moss_block
fill 263 226 338 264 269 338 minecraft:mushroom_stem
fill 263 226 341 264 269 341 minecraft:mushroom_stem
setblock 263 226 362 minecraft:mushroom_stem
fill 263 226 363 263 226 364 minecraft:moss_block
setblock 264 226 360 minecraft:moss_block
setblock 264 226 361 minecraft:mushroom_stem
fill 264 226 362 266 226 363 minecraft:moss_block
fill 264 226 364 266 228 364 minecraft:green_terracotta
fill 265 226 323 266 226 323 minecraft:moss_block
setblock 265 226 360 minecraft:mushroom_stem
fill 265 226 361 268 226 361 minecraft:moss_block
fill 266 226 360 269 226 360 minecraft:moss_block
setblock 267 226 323 minecraft:mushroom_stem
setblock 267 226 362 minecraft:moss_block
setblock 267 226 363 minecraft:mushroom_stem
fill 268 226 323 270 227 323 minecraft:moss_block
setblock 268 226 362 minecraft:mushroom_stem
fill 268 226 363 271 226 363 minecraft:moss_block
setblock 268 226 364 minecraft:red_mushroom_block
setblock 269 226 361 minecraft:mushroom_stem
fill 269 226 362 272 226 362 minecraft:moss_block
fill 269 226 364 270 228 364 minecraft:green_terracotta
fill 270 226 361 271 228 361 minecraft:moss_block
setblock 272 226 363 minecraft:mushroom_stem
setblock 273 226 323 minecraft:red_mushroom_block
setblock 273 226 362 minecraft:mushroom_stem
fill 273 226 363 275 227 363 minecraft:moss_block
fill 276 226 337 276 226 338 minecraft:moss_block
setblock 276 226 339 minecraft:mushroom_stem
fill 276 226 340 276 226 343 minecraft:moss_block
setblock 276 226 344 minecraft:mushroom_stem
fill 276 226 345 276 228 346 minecraft:moss_block
setblock 276 226 358 minecraft:moss_block
setblock 276 226 359 minecraft:mushroom_stem
fill 276 226 360 276 227 362 minecraft:moss_block
fill 277 226 328 277 228 329 minecraft:green_terracotta
fill 277 226 331 277 226 332 minecraft:moss_block
fill 277 226 333 277 228 333 minecraft:green_terracotta
fill 277 226 341 277 228 341 minecraft:green_terracotta
setblock 277 226 345 minecraft:moss_block
fill 277 226 350 277 226 351 minecraft:moss_block
fill 277 226 352 277 229 352 minecraft:green_terracotta
schedule function dropper:buildpart/77_7 1t
