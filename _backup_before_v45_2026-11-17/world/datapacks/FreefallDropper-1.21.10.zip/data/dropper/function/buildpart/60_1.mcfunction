fill 0 37 300 0 39 301 minecraft:blackstone
setblock 0 37 311 minecraft:cobbled_deepslate
setblock 0 37 314 minecraft:cobbled_deepslate
fill 0 37 315 0 39 316 minecraft:blackstone
fill 0 37 317 1 37 317 minecraft:cobbled_deepslate
fill 2 37 315 2 38 315 minecraft:amethyst_block
fill 2 37 317 5 37 317 minecraft:amethyst_block
fill 4 37 275 6 37 275 minecraft:blackstone
setblock 5 37 316 minecraft:amethyst_block
setblock 7 37 275 minecraft:cobbled_deepslate
fill 8 37 275 8 39 275 minecraft:blackstone
setblock 9 37 275 minecraft:cobbled_deepslate
fill 11 37 317 12 39 317 minecraft:blackstone
setblock 18 37 275 minecraft:cobbled_deepslate
fill 20 37 317 20 39 317 minecraft:blackstone
setblock 21 37 317 minecraft:cobbled_deepslate
setblock 28 37 317 minecraft:cobbled_deepslate
fill 30 37 317 30 38 317 minecraft:cobbled_deepslate
fill 32 37 276 32 39 276 minecraft:amethyst_block
setblock 36 37 275 minecraft:cobbled_deepslate
fill 38 37 317 38 39 317 minecraft:blackstone
fill 42 37 281 42 38 281 minecraft:blackstone
fill 42 37 285 42 38 285 minecraft:cobbled_deepslate
fill 42 37 286 42 39 286 minecraft:blackstone
setblock 42 37 290 minecraft:blackstone
fill 42 37 295 42 39 295 minecraft:blackstone
fill 42 37 297 42 37 298 minecraft:blackstone
fill 42 37 307 42 39 308 minecraft:blackstone
setblock 42 37 309 minecraft:cobbled_deepslate
setblock 42 37 310 minecraft:blackstone
setblock 42 37 311 minecraft:cobbled_deepslate
fill 42 37 312 42 40 312 minecraft:blackstone
fill 0 38 279 0 39 279 minecraft:blackstone
fill 0 38 289 0 39 289 minecraft:blackstone
setblock 0 38 294 minecraft:cobbled_deepslate
fill 0 38 297 0 39 297 minecraft:blackstone
fill 0 38 299 0 39 299 minecraft:blackstone
fill 0 38 311 0 40 311 minecraft:blackstone
fill 0 38 314 0 39 314 minecraft:blackstone
fill 0 38 317 0 39 317 minecraft:blackstone
setblock 1 38 317 minecraft:cobbled_deepslate
fill 2 38 317 4 38 317 minecraft:amethyst_block
fill 4 38 275 5 39 275 minecraft:blackstone
setblock 4 38 315 minecraft:amethyst_block
fill 5 38 317 5 40 317 minecraft:blackstone
setblock 6 38 275 minecraft:cobbled_deepslate
setblock 6 38 317 minecraft:cobbled_deepslate
fill 7 38 275 7 39 275 minecraft:blackstone
fill 8 38 317 8 39 317 minecraft:blackstone
fill 9 38 275 9 39 275 minecraft:blackstone
fill 9 38 317 10 38 317 minecraft:cobbled_deepslate
setblock 17 38 317 minecraft:cobbled_deepslate
fill 18 38 275 20 39 275 minecraft:blackstone
setblock 21 38 275 minecraft:cobbled_deepslate
fill 21 38 317 21 39 317 minecraft:blackstone
setblock 27 38 317 minecraft:cobbled_deepslate
fill 28 38 317 28 40 317 minecraft:blackstone
fill 30 38 275 31 38 275 minecraft:cobbled_deepslate
fill 31 38 276 31 39 276 minecraft:amethyst_block
fill 32 38 275 32 39 275 minecraft:amethyst_block
fill 32 38 277 33 38 277 minecraft:amethyst_block
setblock 33 38 275 minecraft:blackstone
fill 33 38 276 33 39 276 minecraft:amethyst_block
fill 36 38 275 36 39 275 minecraft:blackstone
fill 38 38 275 38 39 275 minecraft:blackstone
setblock 39 38 275 minecraft:cobbled_deepslate
fill 40 38 275 40 39 275 minecraft:blackstone
setblock 42 38 290 minecraft:purple_concrete
fill 42 38 297 42 39 297 minecraft:blackstone
fill 42 38 298 42 38 300 minecraft:cobbled_deepslate
fill 42 38 309 42 39 309 minecraft:blackstone
setblock 42 38 310 minecraft:cobbled_deepslate
fill 42 38 311 42 39 311 minecraft:blackstone
setblock 0 39 294 minecraft:blackstone
fill 1 39 317 2 39 317 minecraft:blackstone
fill 2 39 316 3 39 316 minecraft:amethyst_block
setblock 3 39 317 minecraft:amethyst_block
setblock 4 39 317 minecraft:blackstone
fill 6 39 275 6 40 275 minecraft:blackstone
setblock 6 39 317 minecraft:blackstone
fill 9 39 317 10 39 317 minecraft:blackstone
setblock 17 39 317 minecraft:blackstone
setblock 21 39 275 minecraft:blackstone
setblock 27 39 317 minecraft:blackstone
fill 30 39 275 31 39 275 minecraft:blackstone
setblock 30 39 317 minecraft:blackstone
setblock 32 39 277 minecraft:amethyst_block
setblock 33 39 275 minecraft:amethyst_block
setblock 39 39 275 minecraft:blackstone
setblock 42 39 275 minecraft:blackstone
setblock 42 39 281 minecraft:crying_obsidian
setblock 42 39 285 minecraft:blackstone
fill 42 39 290 42 41 290 minecraft:blackstone
fill 42 39 298 42 39 300 minecraft:blackstone
setblock 42 39 310 minecraft:blackstone
fill 0 40 275 1 40 275 minecraft:cobbled_deepslate
setblock 0 40 276 minecraft:blackstone
fill 0 40 277 0 40 289 minecraft:cobbled_deepslate
fill 0 40 291 0 52 294 minecraft:cobbled_deepslate
fill 0 40 296 0 40 310 minecraft:cobbled_deepslate
fill 0 40 312 0 129 312 minecraft:cobbled_deepslate
fill 0 40 314 0 40 317 minecraft:cobbled_deepslate
fill 1 40 317 4 41 317 minecraft:cobbled_deepslate
setblock 2 40 275 minecraft:blackstone
fill 3 40 275 5 52 275 minecraft:cobbled_deepslate
fill 6 40 317 10 40 317 minecraft:cobbled_deepslate
fill 7 40 275 9 66 275 minecraft:cobbled_deepslate
fill 11 40 275 11 113 275 minecraft:cobbled_deepslate
setblock 11 40 317 minecraft:blackstone
fill 12 40 317 13 125 317 minecraft:cobbled_deepslate
fill 13 40 275 16 64 275 minecraft:cobbled_deepslate
fill 15 40 317 16 41 317 minecraft:cobbled_deepslate
setblock 17 40 275 minecraft:blackstone
setblock 17 40 317 minecraft:amethyst_block
fill 18 40 275 42 40 275 minecraft:cobbled_deepslate
fill 18 40 317 27 41 317 minecraft:cobbled_deepslate
fill 29 40 317 31 97 317 minecraft:cobbled_deepslate
setblock 32 40 317 minecraft:blackstone
fill 33 40 317 36 104 317 minecraft:cobbled_deepslate
fill 38 40 317 40 40 317 minecraft:cobbled_deepslate
setblock 41 40 317 minecraft:blackstone
fill 42 40 277 42 41 283 minecraft:cobbled_deepslate
setblock 42 40 284 minecraft:purple_concrete
fill 42 40 285 42 59 289 minecraft:cobbled_deepslate
setblock 42 40 291 minecraft:cobbled_deepslate
setblock 42 40 292 minecraft:blackstone
fill 42 40 293 42 40 304 minecraft:cobbled_deepslate
fill 42 40 306 42 40 311 minecraft:cobbled_deepslate
fill 42 40 313 42 96 313 minecraft:cobbled_deepslate
fill 42 40 315 42 40 317 minecraft:cobbled_deepslate
fill 0 41 275 0 41 284 minecraft:cobbled_deepslate
setblock 0 41 285 minecraft:blackstone
fill 0 41 286 0 61 288 minecraft:cobbled_deepslate
setblock 0 41 289 minecraft:blackstone
fill 0 41 290 0 126 290 minecraft:cobbled_deepslate
fill 0 41 295 0 51 295 minecraft:cobbled_deepslate
setblock 0 41 296 minecraft:blackstone
fill 0 41 297 0 41 311 minecraft:cobbled_deepslate
fill 0 41 313 0 129 315 minecraft:cobbled_deepslate
setblock 0 41 316 minecraft:blackstone
fill 0 41 317 0 126 317 minecraft:cobbled_deepslate
setblock 1 41 275 minecraft:blackstone
fill 2 41 275 2 108 275 minecraft:cobbled_deepslate
fill 5 41 317 6 88 317 minecraft:cobbled_deepslate
fill 6 41 275 6 129 275 minecraft:cobbled_deepslate
setblock 7 41 317 minecraft:blackstone
fill 8 41 317 11 100 317 minecraft:cobbled_deepslate
fill 10 41 275 10 53 275 minecraft:cobbled_deepslate
fill 12 41 275 12 109 275 minecraft:cobbled_deepslate
fill 14 41 317 14 76 317 minecraft:cobbled_deepslate
fill 17 41 275 35 41 275 minecraft:cobbled_deepslate
fill 17 41 317 17 117 317 minecraft:cobbled_deepslate
fill 28 41 317 28 78 317 minecraft:cobbled_deepslate
fill 32 41 317 32 126 317 minecraft:cobbled_deepslate
setblock 36 41 275 minecraft:blackstone
fill 37 41 275 42 53 275 minecraft:cobbled_deepslate
fill 37 41 317 38 125 317 minecraft:cobbled_deepslate
setblock 39 41 317 minecraft:blackstone
fill 40 41 317 42 80 317 minecraft:cobbled_deepslate
fill 42 41 276 42 125 276 minecraft:cobbled_deepslate
fill 42 41 284 42 45 284 minecraft:cobbled_deepslate
setblock 42 41 291 minecraft:blackstone
fill 42 41 292 42 41 299 minecraft:cobbled_deepslate
setblock 42 41 300 minecraft:blackstone
fill 42 41 301 42 58 307 minecraft:cobbled_deepslate
setblock 42 41 308 minecraft:blackstone
fill 42 41 309 42 50 312 minecraft:cobbled_deepslate
fill 42 41 314 42 115 315 minecraft:cobbled_deepslate
setblock 42 41 316 minecraft:blackstone
fill 0 42 275 0 126 276 minecraft:cobbled_deepslate
setblock 0 42 277 minecraft:blackstone
fill 0 42 278 0 66 285 minecraft:cobbled_deepslate
fill 0 42 289 0 86 289 minecraft:cobbled_deepslate
fill 0 42 296 0 54 297 minecraft:cobbled_deepslate
setblock 0 42 298 minecraft:blackstone
fill 0 42 299 0 80 299 minecraft:cobbled_deepslate
setblock 0 42 300 minecraft:blackstone
fill 0 42 301 0 45 302 minecraft:cobbled_deepslate
fill 0 42 303 0 42 305 minecraft:blackstone
fill 0 42 306 0 62 311 minecraft:cobbled_deepslate
fill 0 42 316 0 129 316 minecraft:cobbled_deepslate
fill 1 42 275 1 125 275 minecraft:cobbled_deepslate
setblock 1 42 317 minecraft:blackstone
fill 2 42 317 4 75 317 minecraft:cobbled_deepslate
fill 3 42 278 3 43 278 minecraft:light[level=12]
setblock 3 42 285 minecraft:light[level=12]
setblock 3 42 292 minecraft:light[level=12]
setblock 3 42 299 minecraft:light[level=12]
setblock 3 42 306 minecraft:light[level=12]
setblock 3 42 313 minecraft:light[level=12]
fill 7 42 317 7 64 317 minecraft:cobbled_deepslate
setblock 10 42 278 minecraft:light[level=12]
setblock 10 42 285 minecraft:light[level=12]
setblock 10 42 292 minecraft:light[level=12]
setblock 10 42 299 minecraft:light[level=12]
setblock 10 42 306 minecraft:light[level=12]
setblock 10 42 313 minecraft:light[level=12]
fill 15 42 317 15 129 317 minecraft:cobbled_deepslate
setblock 16 42 317 minecraft:blackstone
fill 17 42 275 19 54 275 minecraft:cobbled_deepslate
setblock 17 42 278 minecraft:light[level=12]
setblock 17 42 285 minecraft:light[level=12]
setblock 17 42 292 minecraft:light[level=12]
setblock 17 42 299 minecraft:light[level=12]
setblock 17 42 306 minecraft:light[level=12]
setblock 17 42 313 minecraft:light[level=12]
fill 18 42 317 21 77 317 minecraft:cobbled_deepslate
setblock 20 42 275 minecraft:blackstone
fill 21 42 275 32 60 275 minecraft:cobbled_deepslate
setblock 22 42 317 minecraft:blackstone
fill 23 42 317 26 53 317 minecraft:cobbled_deepslate
setblock 24 42 278 minecraft:light[level=12]
setblock 24 42 285 minecraft:light[level=12]
setblock 24 42 292 minecraft:light[level=12]
setblock 24 42 299 minecraft:light[level=12]
setblock 24 42 306 minecraft:light[level=12]
setblock 24 42 313 minecraft:light[level=12]
setblock 27 42 317 minecraft:blackstone
setblock 31 42 278 minecraft:light[level=12]
setblock 31 42 285 minecraft:light[level=12]
setblock 31 42 292 minecraft:light[level=12]
setblock 31 42 299 minecraft:light[level=12]
setblock 31 42 306 minecraft:light[level=12]
setblock 31 42 313 minecraft:light[level=12]
setblock 33 42 275 minecraft:blackstone
fill 34 42 275 36 52 275 minecraft:cobbled_deepslate
setblock 38 42 278 minecraft:light[level=12]
setblock 38 42 285 minecraft:light[level=12]
setblock 38 42 292 minecraft:light[level=12]
setblock 38 42 299 minecraft:light[level=12]
setblock 38 42 306 minecraft:light[level=12]
setblock 38 42 313 minecraft:light[level=12]
fill 39 42 317 39 106 317 minecraft:cobbled_deepslate
fill 42 42 277 42 44 282 minecraft:cobbled_deepslate
setblock 42 42 283 minecraft:blackstone
fill 42 42 290 42 49 296 minecraft:cobbled_deepslate
setblock 42 42 297 minecraft:blackstone
fill 42 42 298 42 49 300 minecraft:cobbled_deepslate
fill 42 42 308 42 110 308 minecraft:cobbled_deepslate
fill 42 42 316 42 129 316 minecraft:cobbled_deepslate
fill 0 43 277 0 72 277 minecraft:cobbled_deepslate
fill 0 43 298 0 129 298 minecraft:cobbled_deepslate
fill 0 43 300 0 129 300 minecraft:cobbled_deepslate
fill 0 43 303 0 88 305 minecraft:cobbled_deepslate
fill 1 43 317 1 129 317 minecraft:cobbled_deepslate
setblock 3 43 286 minecraft:light[level=12]
setblock 3 43 294 minecraft:light[level=12]
setblock 3 43 302 minecraft:light[level=12]
setblock 3 43 310 minecraft:light[level=12]
setblock 11 43 278 minecraft:light[level=12]
setblock 11 43 286 minecraft:light[level=12]
setblock 11 43 294 minecraft:light[level=12]
setblock 11 43 302 minecraft:light[level=12]
setblock 11 43 310 minecraft:light[level=12]
fill 16 43 317 16 129 317 minecraft:cobbled_deepslate
setblock 19 43 278 minecraft:light[level=12]
setblock 19 43 286 minecraft:light[level=12]
setblock 19 43 294 minecraft:light[level=12]
setblock 19 43 302 minecraft:light[level=12]
setblock 19 43 310 minecraft:light[level=12]
fill 20 43 275 20 130 275 minecraft:cobbled_deepslate
fill 22 43 317 22 52 317 minecraft:cobbled_deepslate
setblock 27 43 278 minecraft:light[level=12]
setblock 27 43 286 minecraft:light[level=12]
setblock 27 43 294 minecraft:light[level=12]
setblock 27 43 302 minecraft:light[level=12]
setblock 27 43 310 minecraft:light[level=12]
fill 27 43 317 27 47 317 minecraft:cobbled_deepslate
fill 33 43 275 33 129 275 minecraft:cobbled_deepslate
setblock 35 43 278 minecraft:light[level=12]
setblock 35 43 286 minecraft:light[level=12]
setblock 35 43 294 minecraft:light[level=12]
setblock 35 43 302 minecraft:light[level=12]
setblock 35 43 310 minecraft:light[level=12]
fill 42 43 283 42 125 283 minecraft:cobbled_deepslate
fill 42 43 297 42 68 297 minecraft:cobbled_deepslate
fill 42 45 277 42 129 279 minecraft:cobbled_deepslate
setblock 42 45 280 minecraft:purple_concrete
fill 42 45 281 42 52 282 minecraft:cobbled_deepslate
setblock 0 46 301 minecraft:amethyst_block
fill 0 46 302 0 101 302 minecraft:cobbled_deepslate
fill 42 46 280 42 84 280 minecraft:cobbled_deepslate
setblock 42 46 284 minecraft:magma_block
fill 0 47 301 0 129 301 minecraft:cobbled_deepslate
fill 42 47 284 42 81 284 minecraft:cobbled_deepslate
setblock 3 48 278 minecraft:light[level=12]
setblock 3 48 285 minecraft:light[level=12]
setblock 3 48 292 minecraft:light[level=12]
setblock 3 48 299 minecraft:light[level=12]
setblock 3 48 306 minecraft:light[level=12]
setblock 3 48 313 minecraft:light[level=12]
setblock 10 48 278 minecraft:light[level=12]
setblock 10 48 285 minecraft:light[level=12]
setblock 10 48 292 minecraft:light[level=12]
setblock 10 48 299 minecraft:light[level=12]
setblock 10 48 306 minecraft:light[level=12]
setblock 10 48 313 minecraft:light[level=12]
setblock 17 48 278 minecraft:light[level=12]
setblock 17 48 285 minecraft:light[level=12]
setblock 17 48 292 minecraft:light[level=12]
setblock 17 48 299 minecraft:light[level=12]
setblock 17 48 306 minecraft:light[level=12]
setblock 17 48 313 minecraft:light[level=12]
setblock 24 48 278 minecraft:light[level=12]
setblock 24 48 285 minecraft:light[level=12]
setblock 24 48 292 minecraft:light[level=12]
setblock 24 48 299 minecraft:light[level=12]
setblock 24 48 306 minecraft:light[level=12]
setblock 24 48 313 minecraft:light[level=12]
setblock 27 48 317 minecraft:amethyst_block
setblock 31 48 278 minecraft:light[level=12]
setblock 31 48 285 minecraft:light[level=12]
setblock 31 48 292 minecraft:light[level=12]
setblock 31 48 299 minecraft:light[level=12]
setblock 31 48 306 minecraft:light[level=12]
setblock 31 48 313 minecraft:light[level=12]
setblock 38 48 278 minecraft:light[level=12]
setblock 38 48 285 minecraft:light[level=12]
setblock 38 48 292 minecraft:light[level=12]
setblock 38 48 299 minecraft:light[level=12]
setblock 38 48 306 minecraft:light[level=12]
setblock 38 48 313 minecraft:light[level=12]
fill 27 49 317 27 127 317 minecraft:cobbled_deepslate
setblock 3 50 278 minecraft:light[level=12]
setblock 3 50 286 minecraft:light[level=12]
setblock 3 50 294 minecraft:light[level=12]
setblock 3 50 302 minecraft:light[level=12]
setblock 3 50 310 minecraft:light[level=12]
setblock 11 50 278 minecraft:light[level=12]
setblock 11 50 286 minecraft:light[level=12]
setblock 11 50 294 minecraft:light[level=12]
setblock 11 50 302 minecraft:light[level=12]
setblock 11 50 310 minecraft:light[level=12]
setblock 19 50 278 minecraft:light[level=12]
setblock 19 50 286 minecraft:light[level=12]
setblock 19 50 294 minecraft:light[level=12]
setblock 19 50 302 minecraft:light[level=12]
setblock 19 50 310 minecraft:light[level=12]
setblock 27 50 278 minecraft:light[level=12]
setblock 27 50 286 minecraft:light[level=12]
setblock 27 50 294 minecraft:light[level=12]
setblock 27 50 302 minecraft:light[level=12]
setblock 27 50 310 minecraft:light[level=12]
setblock 35 50 278 minecraft:light[level=12]
setblock 35 50 286 minecraft:light[level=12]
setblock 35 50 294 minecraft:light[level=12]
setblock 35 50 302 minecraft:light[level=12]
setblock 35 50 310 minecraft:light[level=12]
fill 42 50 290 42 55 293 minecraft:cobbled_deepslate
setblock 42 50 294 minecraft:crying_obsidian
fill 42 50 295 42 127 296 minecraft:cobbled_deepslate
fill 42 50 298 42 84 299 minecraft:cobbled_deepslate
setblock 42 50 300 minecraft:purple_concrete
fill 42 51 294 42 129 294 minecraft:cobbled_deepslate
fill 42 51 300 42 71 300 minecraft:cobbled_deepslate
fill 42 51 309 42 92 310 minecraft:cobbled_deepslate
setblock 42 51 311 minecraft:magma_block
fill 42 51 312 42 64 312 minecraft:cobbled_deepslate
setblock 0 52 295 minecraft:amethyst_block
fill 42 52 311 42 129 311 minecraft:cobbled_deepslate
setblock 0 53 291 minecraft:crying_obsidian
fill 0 53 292 0 66 295 minecraft:cobbled_deepslate
fill 3 53 275 3 130 275 minecraft:cobbled_deepslate
setblock 4 53 275 minecraft:amethyst_block
fill 5 53 275 5 129 275 minecraft:cobbled_deepslate
setblock 22 53 317 minecraft:crying_obsidian
fill 34 53 275 35 125 275 minecraft:cobbled_deepslate
setblock 36 53 275 minecraft:crying_obsidian
fill 42 53 281 42 112 281 minecraft:cobbled_deepslate
setblock 42 53 282 minecraft:purple_concrete
fill 0 54 291 0 124 291 minecraft:cobbled_deepslate
setblock 3 54 278 minecraft:light[level=12]
setblock 3 54 285 minecraft:light[level=12]
setblock 3 54 292 minecraft:light[level=12]
setblock 3 54 299 minecraft:light[level=12]
setblock 3 54 306 minecraft:light[level=12]
setblock 3 54 313 minecraft:light[level=12]
fill 4 54 275 4 67 275 minecraft:cobbled_deepslate
setblock 10 54 275 minecraft:magma_block
setblock 10 54 278 minecraft:light[level=12]
setblock 10 54 285 minecraft:light[level=12]
setblock 10 54 292 minecraft:light[level=12]
setblock 10 54 299 minecraft:light[level=12]
setblock 10 54 306 minecraft:light[level=12]
setblock 10 54 313 minecraft:light[level=12]
setblock 17 54 278 minecraft:light[level=12]
setblock 17 54 285 minecraft:light[level=12]
setblock 17 54 292 minecraft:light[level=12]
setblock 17 54 299 minecraft:light[level=12]
setblock 17 54 306 minecraft:light[level=12]
setblock 17 54 313 minecraft:light[level=12]
fill 22 54 317 23 105 317 minecraft:cobbled_deepslate
setblock 24 54 278 minecraft:light[level=12]
setblock 24 54 285 minecraft:light[level=12]
setblock 24 54 292 minecraft:light[level=12]
setblock 24 54 299 minecraft:light[level=12]
setblock 24 54 306 minecraft:light[level=12]
setblock 24 54 313 minecraft:light[level=12]
setblock 24 54 317 minecraft:magma_block
fill 25 54 317 26 74 317 minecraft:cobbled_deepslate
setblock 31 54 278 minecraft:light[level=12]
setblock 31 54 285 minecraft:light[level=12]
setblock 31 54 292 minecraft:light[level=12]
setblock 31 54 299 minecraft:light[level=12]
setblock 31 54 306 minecraft:light[level=12]
setblock 31 54 313 minecraft:light[level=12]
fill 36 54 275 37 110 275 minecraft:cobbled_deepslate
setblock 38 54 275 minecraft:purple_concrete
setblock 38 54 278 minecraft:light[level=12]
setblock 38 54 285 minecraft:light[level=12]
setblock 38 54 292 minecraft:light[level=12]
setblock 38 54 299 minecraft:light[level=12]
setblock 38 54 306 minecraft:light[level=12]
setblock 38 54 313 minecraft:light[level=12]
fill 39 54 275 42 124 275 minecraft:cobbled_deepslate
fill 42 54 282 42 129 282 minecraft:cobbled_deepslate
fill 0 55 296 0 129 296 minecraft:cobbled_deepslate
setblock 0 55 297 minecraft:crying_obsidian
fill 10 55 275 10 129 275 minecraft:cobbled_deepslate
fill 17 55 275 18 82 275 minecraft:cobbled_deepslate
setblock 19 55 275 minecraft:magma_block
fill 24 55 317 24 129 317 minecraft:cobbled_deepslate
fill 38 55 275 38 126 275 minecraft:cobbled_deepslate
fill 0 56 297 0 127 297 minecraft:cobbled_deepslate
fill 19 56 275 19 58 275 minecraft:cobbled_deepslate
setblock 42 56 290 minecraft:amethyst_block
fill 42 56 291 42 118 293 minecraft:cobbled_deepslate
setblock 3 57 278 minecraft:light[level=12]
setblock 3 57 286 minecraft:light[level=12]
setblock 3 57 294 minecraft:light[level=12]
setblock 3 57 302 minecraft:light[level=12]
setblock 3 57 310 minecraft:light[level=12]
setblock 11 57 278 minecraft:light[level=12]
setblock 11 57 286 minecraft:light[level=12]
setblock 11 57 294 minecraft:light[level=12]
setblock 11 57 302 minecraft:light[level=12]
setblock 11 57 310 minecraft:light[level=12]
setblock 19 57 278 minecraft:light[level=12]
setblock 19 57 286 minecraft:light[level=12]
setblock 19 57 294 minecraft:light[level=12]
setblock 19 57 302 minecraft:light[level=12]
setblock 19 57 310 minecraft:light[level=12]
setblock 27 57 278 minecraft:light[level=12]
setblock 27 57 286 minecraft:light[level=12]
setblock 27 57 294 minecraft:light[level=12]
setblock 27 57 302 minecraft:light[level=12]
setblock 27 57 310 minecraft:light[level=12]
setblock 35 57 278 minecraft:light[level=12]
setblock 35 57 286 minecraft:light[level=12]
setblock 35 57 294 minecraft:light[level=12]
setblock 35 57 302 minecraft:light[level=12]
setblock 35 57 310 minecraft:light[level=12]
fill 42 57 290 42 131 290 minecraft:cobbled_deepslate
fill 36 58 276 38 61 277 minecraft:amethyst_block
fill 17 59 283 17 60 283 minecraft:raw_gold_block
setblock 19 59 275 minecraft:amethyst_block
fill 33 59 306 33 60 306 minecraft:raw_gold_block
fill 35 59 276 35 60 277 minecraft:amethyst_block
fill 36 59 278 38 61 278 minecraft:amethyst_block
fill 37 59 279 37 62 279 minecraft:amethyst_block
fill 39 59 276 39 60 277 minecraft:amethyst_block
fill 42 59 301 42 76 306 minecraft:cobbled_deepslate
setblock 42 59 307 minecraft:amethyst_block
setblock 3 60 278 minecraft:light[level=12]
setblock 3 60 285 minecraft:light[level=12]
setblock 3 60 292 minecraft:light[level=12]
setblock 3 60 299 minecraft:light[level=12]
setblock 3 60 306 minecraft:light[level=12]
setblock 3 60 313 minecraft:light[level=12]
setblock 10 60 278 minecraft:light[level=12]
setblock 10 60 285 minecraft:light[level=12]
setblock 10 60 292 minecraft:light[level=12]
setblock 10 60 299 minecraft:light[level=12]
setblock 10 60 306 minecraft:light[level=12]
setblock 10 60 313 minecraft:light[level=12]
setblock 17 60 278 minecraft:light[level=12]
setblock 17 60 285 minecraft:light[level=12]
setblock 17 60 292 minecraft:light[level=12]
setblock 17 60 299 minecraft:light[level=12]
setblock 17 60 306 minecraft:light[level=12]
setblock 17 60 313 minecraft:light[level=12]
fill 19 60 275 19 126 275 minecraft:cobbled_deepslate
setblock 24 60 278 minecraft:light[level=12]
setblock 24 60 285 minecraft:light[level=12]
setblock 24 60 292 minecraft:light[level=12]
setblock 24 60 299 minecraft:light[level=12]
setblock 24 60 306 minecraft:light[level=12]
setblock 24 60 313 minecraft:light[level=12]
setblock 31 60 278 minecraft:light[level=12]
setblock 31 60 285 minecraft:light[level=12]
setblock 31 60 292 minecraft:light[level=12]
setblock 31 60 299 minecraft:light[level=12]
setblock 31 60 306 minecraft:light[level=12]
setblock 31 60 313 minecraft:light[level=12]
fill 36 60 279 36 61 280 minecraft:amethyst_block
fill 37 60 280 38 62 280 minecraft:amethyst_block
fill 38 60 279 38 61 279 minecraft:amethyst_block
setblock 38 60 285 minecraft:light[level=12]
setblock 38 60 292 minecraft:light[level=12]
setblock 38 60 299 minecraft:light[level=12]
setblock 38 60 306 minecraft:light[level=12]
setblock 38 60 313 minecraft:light[level=12]
setblock 42 60 285 minecraft:purple_concrete
fill 42 60 286 42 127 289 minecraft:cobbled_deepslate
fill 42 60 307 42 127 307 minecraft:cobbled_deepslate
fill 21 61 275 23 90 275 minecraft:cobbled_deepslate
setblock 24 61 275 minecraft:purple_concrete
fill 25 61 275 32 64 275 minecraft:cobbled_deepslate
fill 31 61 286 32 62 286 minecraft:raw_gold_block
fill 36 61 281 38 61 281 minecraft:amethyst_block
fill 37 61 282 37 62 282 minecraft:amethyst_block
fill 42 61 285 42 129 285 minecraft:cobbled_deepslate
fill 0 62 286 0 74 287 minecraft:cobbled_deepslate
setblock 0 62 288 minecraft:crying_obsidian
fill 24 62 275 24 63 275 minecraft:cobbled_deepslate
setblock 36 62 280 minecraft:amethyst_block
fill 37 62 277 37 62 278 minecraft:amethyst_block
setblock 37 62 281 minecraft:amethyst_block
fill 37 62 283 37 63 283 minecraft:amethyst_block
fill 0 63 288 0 66 288 minecraft:cobbled_deepslate
fill 0 63 306 0 97 309 minecraft:cobbled_deepslate
setblock 0 63 310 minecraft:purple_concrete
fill 0 63 311 0 73 311 minecraft:cobbled_deepslate
fill 0 64 310 0 129 310 minecraft:cobbled_deepslate
setblock 3 64 278 minecraft:light[level=12]
setblock 3 64 286 minecraft:light[level=12]
setblock 3 64 294 minecraft:light[level=12]
setblock 3 64 302 minecraft:light[level=12]
setblock 3 64 310 minecraft:light[level=12]
setblock 11 64 278 minecraft:light[level=12]
setblock 11 64 286 minecraft:light[level=12]
setblock 11 64 294 minecraft:light[level=12]
setblock 11 64 302 minecraft:light[level=12]
setblock 11 64 310 minecraft:light[level=12]
setblock 19 64 278 minecraft:light[level=12]
setblock 19 64 286 minecraft:light[level=12]
setblock 19 64 294 minecraft:light[level=12]
setblock 19 64 302 minecraft:light[level=12]
setblock 19 64 310 minecraft:light[level=12]
setblock 24 64 275 minecraft:magma_block
setblock 27 64 278 minecraft:light[level=12]
setblock 27 64 286 minecraft:light[level=12]
setblock 27 64 294 minecraft:light[level=12]
setblock 27 64 302 minecraft:light[level=12]
setblock 27 64 310 minecraft:light[level=12]
setblock 35 64 278 minecraft:light[level=12]
setblock 35 64 286 minecraft:light[level=12]
setblock 35 64 294 minecraft:light[level=12]
setblock 35 64 302 minecraft:light[level=12]
setblock 35 64 310 minecraft:light[level=12]
fill 38 64 277 38 70 277 minecraft:polished_blackstone
setblock 7 65 317 minecraft:crying_obsidian
fill 13 65 275 15 77 275 minecraft:cobbled_deepslate
setblock 16 65 275 minecraft:purple_concrete
fill 24 65 275 26 126 275 minecraft:cobbled_deepslate
setblock 27 65 275 minecraft:amethyst_block
fill 28 65 275 32 69 275 minecraft:cobbled_deepslate
setblock 42 65 312 minecraft:purple_concrete
setblock 3 66 278 minecraft:light[level=12]
setblock 3 66 285 minecraft:light[level=12]
setblock 3 66 292 minecraft:light[level=12]
setblock 3 66 299 minecraft:light[level=12]
setblock 3 66 306 minecraft:light[level=12]
setblock 3 66 313 minecraft:light[level=12]
fill 7 66 317 7 129 317 minecraft:cobbled_deepslate
setblock 10 66 278 minecraft:light[level=12]
setblock 10 66 285 minecraft:light[level=12]
setblock 10 66 292 minecraft:light[level=12]
setblock 10 66 299 minecraft:light[level=12]
setblock 10 66 306 minecraft:light[level=12]
setblock 10 66 313 minecraft:light[level=12]
fill 16 66 275 16 129 275 minecraft:cobbled_deepslate
setblock 17 66 278 minecraft:light[level=12]
setblock 17 66 285 minecraft:light[level=12]
setblock 17 66 292 minecraft:light[level=12]
setblock 17 66 299 minecraft:light[level=12]
setblock 17 66 306 minecraft:light[level=12]
setblock 17 66 313 minecraft:light[level=12]
setblock 24 66 278 minecraft:light[level=12]
setblock 24 66 285 minecraft:light[level=12]
setblock 24 66 292 minecraft:light[level=12]
setblock 24 66 299 minecraft:light[level=12]
setblock 24 66 306 minecraft:light[level=12]
setblock 24 66 313 minecraft:light[level=12]
fill 27 66 275 27 129 275 minecraft:cobbled_deepslate
setblock 31 66 278 minecraft:light[level=12]
setblock 31 66 285 minecraft:light[level=12]
setblock 31 66 292 minecraft:light[level=12]
setblock 31 66 299 minecraft:light[level=12]
setblock 31 66 306 minecraft:light[level=12]
setblock 31 66 313 minecraft:light[level=12]
setblock 38 66 278 minecraft:light[level=12]
setblock 38 66 285 minecraft:light[level=12]
setblock 38 66 292 minecraft:light[level=12]
setblock 38 66 299 minecraft:light[level=12]
setblock 38 66 306 minecraft:light[level=12]
setblock 38 66 313 minecraft:light[level=12]
fill 42 66 312 42 127 312 minecraft:cobbled_deepslate
fill 0 67 278 0 98 279 minecraft:cobbled_deepslate
setblock 0 67 280 minecraft:purple_concrete
fill 0 67 281 0 70 285 minecraft:cobbled_deepslate
setblock 0 67 288 minecraft:crying_obsidian
setblock 0 67 292 minecraft:crying_obsidian
fill 0 67 293 0 74 295 minecraft:cobbled_deepslate
fill 7 67 275 7 125 275 minecraft:cobbled_deepslate
setblock 8 67 275 minecraft:purple_concrete
fill 9 67 275 9 129 275 minecraft:cobbled_deepslate
fill 37 67 277 37 70 277 minecraft:polished_blackstone
fill 38 67 276 38 70 276 minecraft:polished_blackstone
fill 38 67 278 38 70 278 minecraft:polished_blackstone
fill 39 67 277 39 70 277 minecraft:polished_blackstone
fill 0 68 280 0 125 280 minecraft:cobbled_deepslate
fill 0 68 288 0 129 288 minecraft:cobbled_deepslate
fill 0 68 292 0 125 292 minecraft:cobbled_deepslate
setblock 4 68 275 minecraft:amethyst_block
fill 8 68 275 8 127 275 minecraft:cobbled_deepslate
fill 37 68 276 37 70 276 minecraft:polished_blackstone
fill 37 68 278 37 70 278 minecraft:polished_blackstone
fill 39 68 276 39 70 276 minecraft:polished_blackstone
fill 39 68 278 39 70 278 minecraft:polished_blackstone
fill 4 69 275 4 129 275 minecraft:cobbled_deepslate
setblock 42 69 297 minecraft:crying_obsidian
fill 28 70 275 30 126 275 minecraft:cobbled_deepslate
setblock 31 70 275 minecraft:amethyst_block
fill 32 70 275 32 77 275 minecraft:cobbled_deepslate
setblock 36 70 277 minecraft:polished_blackstone
setblock 38 70 279 minecraft:polished_blackstone
setblock 40 70 277 minecraft:polished_blackstone
fill 42 70 297 42 126 297 minecraft:cobbled_deepslate
fill 0 71 281 0 92 283 minecraft:cobbled_deepslate
setblock 0 71 284 minecraft:amethyst_block
fill 0 71 285 0 130 285 minecraft:cobbled_deepslate
fill 3 71 278 3 72 278 minecraft:light[level=12]
setblock 3 71 286 minecraft:light[level=12]
setblock 3 71 294 minecraft:light[level=12]
setblock 3 71 302 minecraft:light[level=12]
setblock 3 71 310 minecraft:light[level=12]
setblock 11 71 278 minecraft:light[level=12]
setblock 11 71 286 minecraft:light[level=12]
setblock 11 71 294 minecraft:light[level=12]
setblock 11 71 302 minecraft:light[level=12]
setblock 11 71 310 minecraft:light[level=12]
setblock 19 71 278 minecraft:light[level=12]
setblock 19 71 286 minecraft:light[level=12]
setblock 19 71 294 minecraft:light[level=12]
setblock 19 71 302 minecraft:light[level=12]
setblock 19 71 310 minecraft:light[level=12]
setblock 27 71 278 minecraft:light[level=12]
setblock 27 71 286 minecraft:light[level=12]
setblock 27 71 294 minecraft:light[level=12]
setblock 27 71 302 minecraft:light[level=12]
setblock 27 71 310 minecraft:light[level=12]
fill 31 71 275 31 129 275 minecraft:cobbled_deepslate
setblock 35 71 278 minecraft:light[level=12]
setblock 35 71 286 minecraft:light[level=12]
setblock 35 71 294 minecraft:light[level=12]
setblock 35 71 302 minecraft:light[level=12]
setblock 35 71 310 minecraft:light[level=12]
fill 0 72 284 0 129 284 minecraft:cobbled_deepslate
setblock 3 72 285 minecraft:light[level=12]
setblock 3 72 292 minecraft:light[level=12]
setblock 3 72 299 minecraft:light[level=12]
setblock 3 72 306 minecraft:light[level=12]
setblock 3 72 313 minecraft:light[level=12]
setblock 10 72 278 minecraft:light[level=12]
setblock 10 72 285 minecraft:light[level=12]
setblock 10 72 292 minecraft:light[level=12]
setblock 10 72 299 minecraft:light[level=12]
setblock 10 72 306 minecraft:light[level=12]
setblock 10 72 313 minecraft:light[level=12]
setblock 17 72 278 minecraft:light[level=12]
setblock 17 72 285 minecraft:light[level=12]
setblock 17 72 292 minecraft:light[level=12]
setblock 17 72 299 minecraft:light[level=12]
setblock 17 72 306 minecraft:light[level=12]
setblock 17 72 313 minecraft:light[level=12]
setblock 24 72 278 minecraft:light[level=12]
setblock 24 72 285 minecraft:light[level=12]
setblock 24 72 292 minecraft:light[level=12]
setblock 24 72 299 minecraft:light[level=12]
setblock 24 72 306 minecraft:light[level=12]
setblock 24 72 313 minecraft:light[level=12]
setblock 31 72 278 minecraft:light[level=12]
setblock 31 72 285 minecraft:light[level=12]
setblock 31 72 292 minecraft:light[level=12]
setblock 31 72 299 minecraft:light[level=12]
setblock 31 72 306 minecraft:light[level=12]
setblock 31 72 313 minecraft:light[level=12]
setblock 38 72 278 minecraft:light[level=12]
setblock 38 72 285 minecraft:light[level=12]
setblock 38 72 292 minecraft:light[level=12]
setblock 38 72 299 minecraft:light[level=12]
setblock 38 72 306 minecraft:light[level=12]
setblock 38 72 313 minecraft:light[level=12]
setblock 42 72 300 minecraft:amethyst_block
setblock 0 73 277 minecraft:magma_block
fill 42 73 300 42 125 300 minecraft:cobbled_deepslate
fill 0 74 277 0 129 277 minecraft:cobbled_deepslate
setblock 0 74 311 minecraft:crying_obsidian
setblock 0 75 286 minecraft:amethyst_block
fill 0 75 287 0 129 287 minecraft:cobbled_deepslate
fill 0 75 293 0 123 294 minecraft:cobbled_deepslate
setblock 0 75 295 minecraft:magma_block
fill 0 75 311 0 129 311 minecraft:cobbled_deepslate
fill 25 75 317 25 129 317 minecraft:cobbled_deepslate
setblock 26 75 317 minecraft:amethyst_block
fill 0 76 286 0 129 286 minecraft:cobbled_deepslate
fill 0 76 295 0 129 295 minecraft:cobbled_deepslate
setblock 2 76 317 minecraft:amethyst_block
fill 3 76 317 4 95 317 minecraft:cobbled_deepslate
fill 26 76 317 26 99 317 minecraft:cobbled_deepslate
fill 2 77 317 2 130 317 minecraft:cobbled_deepslate
setblock 14 77 317 minecraft:amethyst_block
fill 42 77 301 42 87 302 minecraft:cobbled_deepslate
setblock 42 77 303 minecraft:purple_concrete
fill 42 77 304 42 88 306 minecraft:cobbled_deepslate
setblock 3 78 278 minecraft:light[level=12]
fill 3 78 285 3 78 286 minecraft:light[level=12]
setblock 3 78 292 minecraft:light[level=12]
setblock 3 78 294 minecraft:light[level=12]
setblock 3 78 299 minecraft:light[level=12]
setblock 3 78 302 minecraft:light[level=12]
setblock 3 78 306 minecraft:light[level=12]
setblock 3 78 310 minecraft:light[level=12]
setblock 3 78 313 minecraft:light[level=12]
fill 10 78 278 11 78 278 minecraft:light[level=12]
setblock 10 78 285 minecraft:light[level=12]
setblock 10 78 292 minecraft:light[level=12]
setblock 10 78 299 minecraft:light[level=12]
setblock 10 78 306 minecraft:light[level=12]
setblock 10 78 313 minecraft:light[level=12]
setblock 11 78 286 minecraft:light[level=12]
setblock 11 78 294 minecraft:light[level=12]
setblock 11 78 302 minecraft:light[level=12]
setblock 11 78 310 minecraft:light[level=12]
fill 13 78 275 14 129 275 minecraft:cobbled_deepslate
fill 14 78 317 14 94 317 minecraft:cobbled_deepslate
setblock 15 78 275 minecraft:crying_obsidian
setblock 17 78 278 minecraft:light[level=12]
setblock 17 78 285 minecraft:light[level=12]
setblock 17 78 292 minecraft:light[level=12]
setblock 17 78 299 minecraft:light[level=12]
setblock 17 78 306 minecraft:light[level=12]
setblock 17 78 313 minecraft:light[level=12]
fill 18 78 317 19 127 317 minecraft:cobbled_deepslate
setblock 19 78 278 minecraft:light[level=12]
setblock 19 78 286 minecraft:light[level=12]
setblock 19 78 294 minecraft:light[level=12]
setblock 19 78 302 minecraft:light[level=12]
setblock 19 78 310 minecraft:light[level=12]
setblock 20 78 317 minecraft:magma_block
fill 21 78 317 21 129 317 minecraft:cobbled_deepslate
setblock 24 78 278 minecraft:light[level=12]
setblock 24 78 285 minecraft:light[level=12]
setblock 24 78 292 minecraft:light[level=12]
setblock 24 78 299 minecraft:light[level=12]
setblock 24 78 306 minecraft:light[level=12]
setblock 24 78 313 minecraft:light[level=12]
setblock 27 78 278 minecraft:light[level=12]
setblock 27 78 286 minecraft:light[level=12]
setblock 27 78 294 minecraft:light[level=12]
setblock 27 78 302 minecraft:light[level=12]
setblock 27 78 310 minecraft:light[level=12]
setblock 31 78 278 minecraft:light[level=12]
setblock 31 78 285 minecraft:light[level=12]
setblock 31 78 292 minecraft:light[level=12]
setblock 31 78 299 minecraft:light[level=12]
setblock 31 78 306 minecraft:light[level=12]
setblock 31 78 313 minecraft:light[level=12]
setblock 32 78 275 minecraft:amethyst_block
setblock 35 78 278 minecraft:light[level=12]
setblock 35 78 286 minecraft:light[level=12]
setblock 35 78 294 minecraft:light[level=12]
setblock 35 78 302 minecraft:light[level=12]
setblock 35 78 310 minecraft:light[level=12]
setblock 38 78 278 minecraft:light[level=12]
setblock 38 78 285 minecraft:light[level=12]
setblock 38 78 292 minecraft:light[level=12]
setblock 38 78 299 minecraft:light[level=12]
setblock 38 78 306 minecraft:light[level=12]
setblock 38 78 313 minecraft:light[level=12]
fill 42 78 303 42 127 303 minecraft:cobbled_deepslate
fill 15 79 275 15 129 275 minecraft:cobbled_deepslate
fill 20 79 317 20 112 317 minecraft:cobbled_deepslate
setblock 28 79 317 minecraft:magma_block
fill 32 79 275 32 106 275 minecraft:cobbled_deepslate
fill 28 80 317 28 129 317 minecraft:cobbled_deepslate
setblock 0 81 299 minecraft:purple_concrete
fill 21 81 279 22 82 280 minecraft:gold_block
fill 40 81 317 40 129 317 minecraft:cobbled_deepslate
setblock 41 81 317 minecraft:amethyst_block
fill 42 81 317 42 129 317 minecraft:cobbled_deepslate
fill 0 82 299 0 129 299 minecraft:cobbled_deepslate
fill 41 82 317 41 129 317 minecraft:cobbled_deepslate
setblock 42 82 284 minecraft:crying_obsidian
fill 17 83 275 17 129 275 minecraft:cobbled_deepslate
setblock 18 83 275 minecraft:magma_block
fill 42 83 284 42 94 284 minecraft:cobbled_deepslate
fill 3 84 278 3 85 278 minecraft:light[level=12]
setblock 3 84 285 minecraft:light[level=12]
setblock 3 84 292 minecraft:light[level=12]
setblock 3 84 299 minecraft:light[level=12]
setblock 3 84 306 minecraft:light[level=12]
setblock 3 84 313 minecraft:light[level=12]
fill 7 84 287 7 85 287 minecraft:gold_block
setblock 10 84 278 minecraft:light[level=12]
setblock 10 84 285 minecraft:light[level=12]
setblock 10 84 292 minecraft:light[level=12]
setblock 10 84 299 minecraft:light[level=12]
setblock 10 84 306 minecraft:light[level=12]
setblock 10 84 313 minecraft:light[level=12]
setblock 17 84 278 minecraft:light[level=12]
setblock 17 84 285 minecraft:light[level=12]
setblock 17 84 292 minecraft:light[level=12]
setblock 17 84 299 minecraft:light[level=12]
setblock 17 84 306 minecraft:light[level=12]
setblock 17 84 313 minecraft:light[level=12]
fill 18 84 275 18 102 275 minecraft:cobbled_deepslate
setblock 24 84 278 minecraft:light[level=12]
setblock 24 84 285 minecraft:light[level=12]
setblock 24 84 292 minecraft:light[level=12]
setblock 24 84 299 minecraft:light[level=12]
setblock 24 84 306 minecraft:light[level=12]
setblock 24 84 313 minecraft:light[level=12]
setblock 31 84 278 minecraft:light[level=12]
setblock 31 84 285 minecraft:light[level=12]
setblock 31 84 292 minecraft:light[level=12]
setblock 31 84 299 minecraft:light[level=12]
setblock 31 84 306 minecraft:light[level=12]
setblock 31 84 313 minecraft:light[level=12]
setblock 38 84 278 minecraft:light[level=12]
setblock 38 84 285 minecraft:light[level=12]
setblock 38 84 292 minecraft:light[level=12]
setblock 38 84 299 minecraft:light[level=12]
setblock 38 84 306 minecraft:light[level=12]
setblock 38 84 313 minecraft:light[level=12]
setblock 3 85 286 minecraft:light[level=12]
setblock 3 85 294 minecraft:light[level=12]
setblock 3 85 302 minecraft:light[level=12]
setblock 3 85 310 minecraft:light[level=12]
setblock 11 85 278 minecraft:light[level=12]
setblock 11 85 286 minecraft:light[level=12]
setblock 11 85 294 minecraft:light[level=12]
setblock 11 85 302 minecraft:light[level=12]
setblock 11 85 310 minecraft:light[level=12]
setblock 19 85 278 minecraft:light[level=12]
setblock 19 85 286 minecraft:light[level=12]
setblock 19 85 294 minecraft:light[level=12]
setblock 19 85 302 minecraft:light[level=12]
setblock 19 85 310 minecraft:light[level=12]
setblock 27 85 278 minecraft:light[level=12]
setblock 27 85 286 minecraft:light[level=12]
setblock 27 85 294 minecraft:light[level=12]
setblock 27 85 302 minecraft:light[level=12]
setblock 27 85 310 minecraft:light[level=12]
setblock 35 85 278 minecraft:light[level=12]
setblock 35 85 286 minecraft:light[level=12]
setblock 35 85 294 minecraft:light[level=12]
setblock 35 85 302 minecraft:light[level=12]
setblock 35 85 310 minecraft:light[level=12]
setblock 42 85 280 minecraft:crying_obsidian
fill 42 85 298 42 127 298 minecraft:cobbled_deepslate
setblock 42 85 299 minecraft:magma_block
fill 42 86 280 42 125 280 minecraft:cobbled_deepslate
fill 42 86 299 42 129 299 minecraft:cobbled_deepslate
setblock 0 87 289 minecraft:magma_block
fill 12 87 276 14 88 277 minecraft:amethyst_block
fill 13 87 278 13 89 278 minecraft:amethyst_block
fill 24 87 315 24 90 315 minecraft:amethyst_block
fill 0 88 289 0 96 289 minecraft:cobbled_deepslate
setblock 12 88 278 minecraft:amethyst_block
fill 13 88 279 13 89 280 minecraft:amethyst_block
setblock 14 88 278 minecraft:amethyst_block
fill 23 88 314 23 89 316 minecraft:amethyst_block
fill 24 88 312 24 89 314 minecraft:amethyst_block
fill 24 88 316 25 89 316 minecraft:amethyst_block
fill 25 88 314 25 89 315 minecraft:amethyst_block
setblock 42 88 301 minecraft:amethyst_block
fill 42 88 302 42 129 302 minecraft:cobbled_deepslate
fill 0 89 303 0 101 303 minecraft:cobbled_deepslate
setblock 0 89 304 minecraft:crying_obsidian
fill 0 89 305 0 129 305 minecraft:cobbled_deepslate
fill 5 89 317 5 125 317 minecraft:cobbled_deepslate
setblock 6 89 317 minecraft:amethyst_block
setblock 13 89 277 minecraft:amethyst_block
setblock 13 89 281 minecraft:amethyst_block
setblock 23 89 313 minecraft:amethyst_block
fill 24 89 310 24 89 311 minecraft:amethyst_block
setblock 25 89 313 minecraft:amethyst_block
fill 42 89 301 42 129 301 minecraft:cobbled_deepslate
setblock 42 89 304 minecraft:amethyst_block
fill 42 89 305 42 120 306 minecraft:cobbled_deepslate
fill 0 90 304 0 102 304 minecraft:cobbled_deepslate
setblock 3 90 278 minecraft:light[level=12]
setblock 3 90 285 minecraft:light[level=12]
setblock 3 90 292 minecraft:light[level=12]
setblock 3 90 299 minecraft:light[level=12]
setblock 3 90 306 minecraft:light[level=12]
setblock 3 90 313 minecraft:light[level=12]
fill 6 90 317 6 108 317 minecraft:cobbled_deepslate
setblock 10 90 278 minecraft:light[level=12]
setblock 10 90 285 minecraft:light[level=12]
setblock 10 90 292 minecraft:light[level=12]
setblock 10 90 299 minecraft:light[level=12]
setblock 10 90 306 minecraft:light[level=12]
setblock 10 90 313 minecraft:light[level=12]
setblock 17 90 278 minecraft:light[level=12]
setblock 17 90 285 minecraft:light[level=12]
setblock 17 90 292 minecraft:light[level=12]
setblock 17 90 299 minecraft:light[level=12]
setblock 17 90 306 minecraft:light[level=12]
setblock 17 90 313 minecraft:light[level=12]
setblock 24 90 278 minecraft:light[level=12]
setblock 24 90 285 minecraft:light[level=12]
setblock 24 90 292 minecraft:light[level=12]
setblock 24 90 299 minecraft:light[level=12]
setblock 24 90 306 minecraft:light[level=12]
setblock 24 90 313 minecraft:light[level=12]
setblock 31 90 278 minecraft:light[level=12]
fill 31 90 283 31 91 283 minecraft:amethyst_block
setblock 31 90 285 minecraft:light[level=12]
setblock 31 90 292 minecraft:light[level=12]
setblock 31 90 299 minecraft:light[level=12]
setblock 31 90 306 minecraft:light[level=12]
setblock 31 90 313 minecraft:light[level=12]
setblock 38 90 278 minecraft:light[level=12]
setblock 38 90 285 minecraft:light[level=12]
setblock 38 90 292 minecraft:light[level=12]
setblock 38 90 299 minecraft:light[level=12]
setblock 38 90 306 minecraft:light[level=12]
setblock 38 90 313 minecraft:light[level=12]
fill 42 90 304 42 105 304 minecraft:cobbled_deepslate
fill 21 91 275 21 129 275 minecraft:cobbled_deepslate
setblock 22 91 275 minecraft:purple_concrete
fill 23 91 275 23 129 275 minecraft:cobbled_deepslate
setblock 3 92 278 minecraft:light[level=12]
fill 3 92 281 3 96 281 minecraft:blackstone
setblock 3 92 286 minecraft:light[level=12]
setblock 3 92 294 minecraft:light[level=12]
setblock 3 92 302 minecraft:light[level=12]
setblock 3 92 310 minecraft:light[level=12]
setblock 11 92 278 minecraft:light[level=12]
setblock 11 92 286 minecraft:light[level=12]
setblock 11 92 294 minecraft:light[level=12]
setblock 11 92 302 minecraft:light[level=12]
setblock 11 92 310 minecraft:light[level=12]
setblock 19 92 278 minecraft:light[level=12]
setblock 19 92 286 minecraft:light[level=12]
setblock 19 92 294 minecraft:light[level=12]
setblock 19 92 302 minecraft:light[level=12]
setblock 19 92 310 minecraft:light[level=12]
fill 22 92 275 22 123 275 minecraft:cobbled_deepslate
setblock 27 92 278 minecraft:light[level=12]
setblock 27 92 286 minecraft:light[level=12]
setblock 27 92 294 minecraft:light[level=12]
setblock 27 92 302 minecraft:light[level=12]
setblock 27 92 310 minecraft:light[level=12]
fill 30 92 283 31 99 283 minecraft:blackstone
setblock 35 92 278 minecraft:light[level=12]
setblock 35 92 286 minecraft:light[level=12]
setblock 35 92 294 minecraft:light[level=12]
setblock 35 92 302 minecraft:light[level=12]
setblock 35 92 310 minecraft:light[level=12]
fill 0 93 281 0 118 282 minecraft:cobbled_deepslate
setblock 0 93 283 minecraft:crying_obsidian
fill 5 93 287 5 100 287 minecraft:polished_blackstone
fill 30 93 282 31 99 282 minecraft:blackstone
setblock 42 93 309 minecraft:crying_obsidian
fill 42 93 310 42 131 310 minecraft:cobbled_deepslate
fill 0 94 283 0 129 283 minecraft:cobbled_deepslate
fill 13 94 290 13 95 290 minecraft:raw_gold_block
fill 30 94 284 31 99 284 minecraft:blackstone
fill 32 94 283 32 99 283 minecraft:blackstone
fill 42 94 309 42 129 309 minecraft:cobbled_deepslate
setblock 14 95 317 minecraft:crying_obsidian
fill 29 95 282 29 99 284 minecraft:blackstone
fill 30 95 281 31 99 281 minecraft:blackstone
fill 32 95 282 32 99 282 minecraft:blackstone
fill 32 95 284 32 99 284 minecraft:blackstone
setblock 42 95 284 minecraft:amethyst_block
setblock 2 96 281 minecraft:blackstone
setblock 3 96 278 minecraft:light[level=12]
setblock 3 96 280 minecraft:blackstone
setblock 3 96 282 minecraft:blackstone
setblock 3 96 285 minecraft:light[level=12]
setblock 3 96 292 minecraft:light[level=12]
setblock 3 96 299 minecraft:light[level=12]
setblock 3 96 306 minecraft:light[level=12]
setblock 3 96 313 minecraft:light[level=12]
setblock 3 96 317 minecraft:magma_block
setblock 4 96 281 minecraft:blackstone
fill 4 96 287 4 100 287 minecraft:polished_blackstone
fill 4 96 317 4 129 317 minecraft:cobbled_deepslate
fill 5 96 286 5 100 286 minecraft:polished_blackstone
fill 5 96 288 5 100 288 minecraft:polished_blackstone
fill 6 96 287 6 100 287 minecraft:polished_blackstone
setblock 10 96 278 minecraft:light[level=12]
setblock 10 96 285 minecraft:light[level=12]
setblock 10 96 292 minecraft:light[level=12]
setblock 10 96 299 minecraft:light[level=12]
setblock 10 96 306 minecraft:light[level=12]
setblock 10 96 313 minecraft:light[level=12]
fill 14 96 317 14 127 317 minecraft:cobbled_deepslate
setblock 17 96 278 minecraft:light[level=12]
setblock 17 96 285 minecraft:light[level=12]
setblock 17 96 292 minecraft:light[level=12]
setblock 17 96 299 minecraft:light[level=12]
setblock 17 96 306 minecraft:light[level=12]
setblock 17 96 313 minecraft:light[level=12]
setblock 24 96 278 minecraft:light[level=12]
setblock 24 96 285 minecraft:light[level=12]
setblock 24 96 292 minecraft:light[level=12]
setblock 24 96 299 minecraft:light[level=12]
setblock 24 96 306 minecraft:light[level=12]
setblock 24 96 313 minecraft:light[level=12]
fill 29 96 281 29 99 281 minecraft:blackstone
fill 30 96 285 31 99 285 minecraft:blackstone
setblock 31 96 278 minecraft:light[level=12]
setblock 31 96 292 minecraft:light[level=12]
setblock 31 96 299 minecraft:light[level=12]
setblock 31 96 306 minecraft:light[level=12]
setblock 31 96 313 minecraft:light[level=12]
fill 32 96 281 32 99 281 minecraft:blackstone
setblock 38 96 278 minecraft:light[level=12]
setblock 38 96 285 minecraft:light[level=12]
setblock 38 96 292 minecraft:light[level=12]
setblock 38 96 299 minecraft:light[level=12]
setblock 38 96 306 minecraft:light[level=12]
setblock 38 96 313 minecraft:light[level=12]
fill 42 96 284 42 129 284 minecraft:cobbled_deepslate
setblock 0 97 289 minecraft:purple_concrete
fill 3 97 317 3 125 317 minecraft:cobbled_deepslate
fill 25 97 309 27 98 309 minecraft:raw_gold_block
fill 26 97 308 26 98 308 minecraft:raw_gold_block
fill 26 97 310 26 98 310 minecraft:raw_gold_block
fill 28 97 282 28 99 284 minecraft:blackstone
fill 29 97 285 29 99 285 minecraft:blackstone
fill 30 97 280 31 99 280 minecraft:blackstone
fill 32 97 285 32 99 285 minecraft:blackstone
fill 33 97 282 33 99 284 minecraft:blackstone
setblock 42 97 313 minecraft:crying_obsidian
fill 0 98 289 0 129 289 minecraft:cobbled_deepslate
fill 0 98 306 0 129 306 minecraft:cobbled_deepslate
setblock 0 98 307 minecraft:crying_obsidian
fill 0 98 308 0 127 309 minecraft:cobbled_deepslate
fill 4 98 286 4 100 286 minecraft:polished_blackstone
fill 4 98 288 4 100 288 minecraft:polished_blackstone
fill 6 98 286 6 100 286 minecraft:polished_blackstone
fill 6 98 288 6 100 288 minecraft:polished_blackstone
fill 28 98 281 28 99 281 minecraft:blackstone
fill 28 98 285 28 99 285 minecraft:blackstone
fill 29 98 280 29 99 280 minecraft:blackstone
fill 29 98 317 30 108 317 minecraft:cobbled_deepslate
fill 30 98 286 31 99 286 minecraft:blackstone
setblock 31 98 317 minecraft:crying_obsidian
fill 32 98 280 32 99 280 minecraft:blackstone
fill 33 98 281 33 99 281 minecraft:blackstone
fill 33 98 285 33 99 285 minecraft:blackstone
fill 42 98 313 42 126 313 minecraft:cobbled_deepslate
fill 0 99 278 0 129 278 minecraft:cobbled_deepslate
setblock 0 99 279 minecraft:magma_block
fill 0 99 307 0 126 307 minecraft:cobbled_deepslate
setblock 3 99 278 minecraft:light[level=12]
setblock 3 99 286 minecraft:light[level=12]
setblock 3 99 294 minecraft:light[level=12]
setblock 3 99 302 minecraft:light[level=12]
setblock 3 99 310 minecraft:light[level=12]
setblock 11 99 278 minecraft:light[level=12]
setblock 11 99 286 minecraft:light[level=12]
setblock 11 99 294 minecraft:light[level=12]
setblock 11 99 302 minecraft:light[level=12]
setblock 11 99 310 minecraft:light[level=12]
setblock 19 99 278 minecraft:light[level=12]
setblock 19 99 286 minecraft:light[level=12]
setblock 19 99 294 minecraft:light[level=12]
setblock 19 99 302 minecraft:light[level=12]
setblock 19 99 310 minecraft:light[level=12]
setblock 27 99 278 minecraft:light[level=12]
fill 27 99 282 27 99 284 minecraft:blackstone
setblock 27 99 286 minecraft:light[level=12]
setblock 27 99 294 minecraft:light[level=12]
setblock 27 99 302 minecraft:light[level=12]
setblock 27 99 310 minecraft:light[level=12]
setblock 28 99 280 minecraft:blackstone
setblock 29 99 286 minecraft:blackstone
fill 30 99 279 31 99 279 minecraft:blackstone
fill 31 99 317 31 129 317 minecraft:cobbled_deepslate
setblock 32 99 286 minecraft:blackstone
setblock 33 99 280 minecraft:blackstone
fill 34 99 282 34 99 284 minecraft:blackstone
setblock 35 99 278 minecraft:light[level=12]
setblock 35 99 286 minecraft:light[level=12]
setblock 35 99 294 minecraft:light[level=12]
setblock 35 99 302 minecraft:light[level=12]
setblock 35 99 310 minecraft:light[level=12]
fill 0 100 279 0 129 279 minecraft:cobbled_deepslate
setblock 3 100 287 minecraft:polished_blackstone
setblock 5 100 285 minecraft:polished_blackstone
setblock 5 100 289 minecraft:polished_blackstone
setblock 7 100 287 minecraft:polished_blackstone
setblock 26 100 317 minecraft:crying_obsidian
fill 30 100 282 31 100 283 minecraft:amethyst_block
fill 8 101 317 9 129 317 minecraft:cobbled_deepslate
setblock 10 101 317 minecraft:amethyst_block
fill 11 101 317 11 129 317 minecraft:cobbled_deepslate
fill 26 101 317 26 125 317 minecraft:cobbled_deepslate
fill 0 102 302 0 105 303 minecraft:amethyst_block
fill 1 102 303 1 105 304 minecraft:amethyst_block
fill 2 102 302 2 104 303 minecraft:amethyst_block
setblock 3 102 278 minecraft:light[level=12]
setblock 3 102 285 minecraft:light[level=12]
setblock 3 102 292 minecraft:light[level=12]
setblock 3 102 299 minecraft:light[level=12]
fill 3 102 303 3 104 303 minecraft:amethyst_block
setblock 3 102 306 minecraft:light[level=12]
setblock 3 102 313 minecraft:light[level=12]
setblock 10 102 278 minecraft:light[level=12]
setblock 10 102 285 minecraft:light[level=12]
setblock 10 102 292 minecraft:light[level=12]
setblock 10 102 299 minecraft:light[level=12]
setblock 10 102 306 minecraft:light[level=12]
setblock 10 102 313 minecraft:light[level=12]
fill 10 102 317 10 125 317 minecraft:cobbled_deepslate
setblock 17 102 278 minecraft:light[level=12]
setblock 17 102 285 minecraft:light[level=12]
setblock 17 102 292 minecraft:light[level=12]
setblock 17 102 299 minecraft:light[level=12]
setblock 17 102 306 minecraft:light[level=12]
setblock 17 102 313 minecraft:light[level=12]
setblock 24 102 278 minecraft:light[level=12]
setblock 24 102 285 minecraft:light[level=12]
setblock 24 102 292 minecraft:light[level=12]
setblock 24 102 299 minecraft:light[level=12]
setblock 24 102 306 minecraft:light[level=12]
setblock 24 102 313 minecraft:light[level=12]
setblock 31 102 278 minecraft:light[level=12]
setblock 31 102 285 minecraft:light[level=12]
setblock 31 102 292 minecraft:light[level=12]
setblock 31 102 299 minecraft:light[level=12]
setblock 31 102 306 minecraft:light[level=12]
setblock 31 102 313 minecraft:light[level=12]
setblock 38 102 278 minecraft:light[level=12]
setblock 38 102 285 minecraft:light[level=12]
setblock 38 102 292 minecraft:light[level=12]
setblock 38 102 299 minecraft:light[level=12]
setblock 38 102 306 minecraft:light[level=12]
setblock 38 102 313 minecraft:light[level=12]
fill 0 103 304 0 105 304 minecraft:amethyst_block
fill 1 103 302 1 105 302 minecraft:amethyst_block
fill 2 103 304 3 104 304 minecraft:amethyst_block
setblock 18 103 275 minecraft:magma_block
setblock 1 104 301 minecraft:amethyst_block
fill 18 104 275 18 127 275 minecraft:cobbled_deepslate
setblock 2 105 302 minecraft:amethyst_block
fill 33 105 317 35 125 317 minecraft:cobbled_deepslate
setblock 36 105 317 minecraft:amethyst_block
fill 0 106 302 0 108 304 minecraft:cobbled_deepslate
setblock 1 106 304 minecraft:amethyst_block
setblock 3 106 278 minecraft:light[level=12]
setblock 3 106 286 minecraft:light[level=12]
setblock 3 106 294 minecraft:light[level=12]
setblock 3 106 302 minecraft:light[level=12]
setblock 3 106 310 minecraft:light[level=12]
setblock 11 106 278 minecraft:light[level=12]
setblock 11 106 286 minecraft:light[level=12]
fill 11 106 293 11 108 293 minecraft:red_nether_bricks
fill 11 106 295 11 106 296 minecraft:red_nether_bricks
fill 11 106 297 13 106 297 minecraft:nether_wart_block
fill 11 106 298 31 106 299 minecraft:red_nether_bricks
setblock 11 106 302 minecraft:light[level=12]
setblock 11 106 310 minecraft:light[level=12]
fill 12 106 290 30 108 290 minecraft:red_nether_bricks
fill 12 106 291 13 106 291 minecraft:nether_wart_block
fill 12 106 300 30 106 300 minecraft:nether_wart_block
fill 12 106 301 30 109 302 minecraft:red_nether_bricks
fill 13 106 288 29 106 288 minecraft:nether_wart_block
fill 13 106 289 29 109 289 minecraft:red_nether_bricks
fill 13 106 303 29 106 303 minecraft:nether_wart_block
fill 13 106 304 29 106 304 minecraft:red_nether_bricks
fill 14 106 287 28 110 287 minecraft:red_nether_bricks
fill 14 106 305 28 109 305 minecraft:red_nether_bricks
fill 15 106 286 27 110 286 minecraft:red_nether_bricks
fill 15 106 291 30 106 291 minecraft:nether_wart_block
fill 15 106 297 31 106 297 minecraft:nether_wart_block
fill 15 106 306 27 106 306 minecraft:nether_wart_block
fill 16 106 285 26 106 285 minecraft:nether_wart_block
fill 16 106 307 26 109 307 minecraft:red_nether_bricks
fill 17 106 284 25 111 284 minecraft:red_nether_bricks
fill 17 106 292 30 107 293 minecraft:red_nether_bricks
fill 17 106 295 31 106 296 minecraft:red_nether_bricks
fill 17 106 308 25 109 308 minecraft:red_nether_bricks
fill 18 106 294 31 106 294 minecraft:nether_wart_block
setblock 19 106 278 minecraft:light[level=12]
fill 19 106 283 23 106 283 minecraft:red_nether_bricks
fill 19 106 309 23 106 309 minecraft:nether_wart_block
setblock 19 106 310 minecraft:light[level=12]
setblock 22 106 317 minecraft:purple_concrete
fill 23 106 317 23 129 317 minecraft:cobbled_deepslate
setblock 27 106 278 minecraft:light[level=12]
setblock 27 106 310 minecraft:light[level=12]
fill 31 106 293 31 109 293 minecraft:red_nether_bricks
setblock 35 106 278 minecraft:light[level=12]
setblock 35 106 286 minecraft:light[level=12]
setblock 35 106 294 minecraft:light[level=12]
setblock 35 106 302 minecraft:light[level=12]
setblock 35 106 310 minecraft:light[level=12]
fill 36 106 317 36 127 317 minecraft:cobbled_deepslate
setblock 42 106 304 minecraft:magma_block
fill 11 107 291 13 107 291 minecraft:red_nether_bricks
setblock 11 107 292 minecraft:nether_wart_block
setblock 11 107 295 minecraft:nether_wart_block
fill 11 107 296 11 108 297 minecraft:red_nether_bricks
setblock 11 107 298 minecraft:nether_wart_block
fill 11 107 299 31 109 300 minecraft:red_nether_bricks
setblock 11 107 301 minecraft:nether_wart_block
setblock 12 107 289 minecraft:nether_wart_block
fill 12 107 297 13 107 298 minecraft:red_nether_bricks
fill 12 107 303 30 109 303 minecraft:red_nether_bricks
fill 13 107 287 13 107 288 minecraft:red_nether_bricks
setblock 13 107 304 minecraft:nether_wart_block
setblock 13 107 305 minecraft:red_nether_bricks
setblock 14 107 286 minecraft:nether_wart_block
fill 14 107 288 29 109 288 minecraft:red_nether_bricks
fill 14 107 298 30 108 298 minecraft:red_nether_bricks
fill 14 107 304 28 109 304 minecraft:red_nether_bricks
fill 14 107 306 28 109 306 minecraft:red_nether_bricks
fill 15 107 285 27 109 285 minecraft:red_nether_bricks
fill 15 107 291 31 107 291 minecraft:red_nether_bricks
fill 15 107 297 31 107 297 minecraft:red_nether_bricks
setblock 15 107 307 minecraft:nether_wart_block
fill 16 107 284 16 118 284 minecraft:red_nether_bricks
fill 16 107 308 16 112 308 minecraft:red_nether_bricks
fill 17 107 283 20 107 283 minecraft:nether_wart_block
fill 17 107 295 30 107 296 minecraft:red_nether_bricks
fill 17 107 309 25 109 309 minecraft:red_nether_bricks
fill 18 107 294 31 108 294 minecraft:red_nether_bricks
fill 21 107 282 21 108 283 minecraft:red_nether_bricks
setblock 21 107 310 minecraft:nether_wart_block
fill 22 107 283 25 107 283 minecraft:nether_wart_block
fill 22 107 317 22 129 317 minecraft:cobbled_deepslate
fill 26 107 284 26 110 284 minecraft:red_nether_bricks
fill 26 107 308 26 109 308 minecraft:red_nether_bricks
setblock 27 107 307 minecraft:nether_wart_block
setblock 28 107 286 minecraft:nether_wart_block
setblock 29 107 287 minecraft:red_nether_bricks
setblock 29 107 304 minecraft:nether_wart_block
setblock 29 107 305 minecraft:red_nether_bricks
setblock 30 107 289 minecraft:nether_wart_block
setblock 31 107 292 minecraft:nether_wart_block
setblock 31 107 295 minecraft:nether_wart_block
fill 31 107 296 31 109 296 minecraft:red_nether_bricks
setblock 31 107 298 minecraft:nether_wart_block
setblock 31 107 301 minecraft:nether_wart_block
setblock 32 107 275 minecraft:amethyst_block
setblock 39 107 317 minecraft:crying_obsidian
fill 42 107 304 42 129 304 minecraft:cobbled_deepslate
setblock 3 108 278 minecraft:light[level=12]
setblock 3 108 285 minecraft:light[level=12]
setblock 3 108 292 minecraft:light[level=12]
setblock 3 108 299 minecraft:light[level=12]
setblock 3 108 306 minecraft:light[level=12]
setblock 3 108 313 minecraft:light[level=12]
setblock 10 108 278 minecraft:light[level=12]
setblock 10 108 285 minecraft:light[level=12]
setblock 10 108 292 minecraft:light[level=12]
setblock 10 108 293 minecraft:nether_wart_block
fill 10 108 294 10 108 295 minecraft:red_nether_bricks
setblock 10 108 296 minecraft:nether_wart_block
fill 10 108 297 10 108 298 minecraft:red_nether_bricks
setblock 10 108 299 minecraft:nether_wart_block
setblock 10 108 306 minecraft:light[level=12]
setblock 10 108 313 minecraft:light[level=12]
setblock 11 108 290 minecraft:nether_wart_block
fill 11 108 291 11 108 292 minecraft:red_nether_bricks
setblock 11 108 295 minecraft:red_nether_bricks
fill 11 108 298 13 108 298 minecraft:red_nether_bricks
fill 11 108 301 11 115 301 minecraft:red_nether_bricks
setblock 11 108 302 minecraft:nether_wart_block
fill 12 108 288 12 108 289 minecraft:red_nether_bricks
setblock 12 108 291 minecraft:red_nether_bricks
setblock 12 108 297 minecraft:red_nether_bricks
fill 12 108 304 13 115 304 minecraft:red_nether_bricks
fill 13 108 286 14 109 286 minecraft:red_nether_bricks
setblock 13 108 287 minecraft:nether_wart_block
fill 13 108 288 13 117 288 minecraft:red_nether_bricks
setblock 13 108 291 minecraft:magma_block
setblock 13 108 297 minecraft:magma_block
setblock 13 108 305 minecraft:nether_wart_block
setblock 13 108 306 minecraft:red_nether_bricks
setblock 14 108 285 minecraft:red_nether_bricks
fill 14 108 307 15 114 307 minecraft:red_nether_bricks
setblock 15 108 284 minecraft:nether_wart_block
setblock 15 108 291 minecraft:magma_block
setblock 15 108 297 minecraft:magma_block
setblock 15 108 308 minecraft:nether_wart_block
fill 16 108 283 20 109 283 minecraft:red_nether_bricks
fill 16 108 291 31 108 291 minecraft:red_nether_bricks
fill 16 108 297 32 108 297 minecraft:red_nether_bricks
setblock 16 108 309 minecraft:red_nether_bricks
setblock 17 108 278 minecraft:light[level=12]
fill 17 108 292 31 108 292 minecraft:red_nether_bricks
setblock 17 108 293 minecraft:magma_block
setblock 17 108 295 minecraft:magma_block
fill 17 108 296 30 108 296 minecraft:red_nether_bricks
setblock 17 108 313 minecraft:light[level=12]
fill 18 108 282 20 108 282 minecraft:red_nether_bricks
fill 18 108 293 30 108 293 minecraft:red_nether_bricks
fill 18 108 295 32 108 295 minecraft:red_nether_bricks
fill 18 108 310 24 109 310 minecraft:red_nether_bricks
fill 22 108 282 24 108 283 minecraft:red_nether_bricks
setblock 24 108 278 minecraft:light[level=12]
setblock 24 108 313 minecraft:light[level=12]
fill 25 108 283 26 109 283 minecraft:red_nether_bricks
setblock 26 108 309 minecraft:red_nether_bricks
setblock 27 108 284 minecraft:nether_wart_block
fill 27 108 307 28 109 307 minecraft:red_nether_bricks
setblock 27 108 308 minecraft:nether_wart_block
fill 28 108 285 28 108 286 minecraft:red_nether_bricks
fill 29 108 286 29 109 286 minecraft:red_nether_bricks
setblock 29 108 287 minecraft:nether_wart_block
fill 29 108 304 30 109 304 minecraft:red_nether_bricks
setblock 29 108 305 minecraft:nether_wart_block
setblock 29 108 306 minecraft:red_nether_bricks
fill 30 108 288 30 108 289 minecraft:red_nether_bricks
setblock 31 108 278 minecraft:light[level=12]
setblock 31 108 285 minecraft:light[level=12]
setblock 31 108 290 minecraft:nether_wart_block
fill 31 108 298 32 109 298 minecraft:red_nether_bricks
fill 31 108 301 31 109 301 minecraft:red_nether_bricks
setblock 31 108 302 minecraft:nether_wart_block
setblock 31 108 306 minecraft:light[level=12]
setblock 31 108 313 minecraft:light[level=12]
fill 32 108 275 32 129 275 minecraft:cobbled_deepslate
setblock 32 108 293 minecraft:nether_wart_block
setblock 32 108 294 minecraft:red_nether_bricks
setblock 32 108 296 minecraft:nether_wart_block
setblock 32 108 299 minecraft:nether_wart_block
setblock 38 108 278 minecraft:light[level=12]
setblock 38 108 285 minecraft:light[level=12]
setblock 38 108 292 minecraft:light[level=12]
setblock 38 108 299 minecraft:light[level=12]
setblock 38 108 306 minecraft:light[level=12]
setblock 38 108 313 minecraft:light[level=12]
fill 39 108 317 39 130 317 minecraft:cobbled_deepslate
fill 0 109 302 0 129 302 minecraft:cobbled_deepslate
setblock 0 109 303 minecraft:amethyst_block
fill 0 109 304 0 120 304 minecraft:cobbled_deepslate
fill 1 109 276 9 109 316 minecraft:blackstone
setblock 2 109 275 minecraft:crying_obsidian
setblock 6 109 317 minecraft:amethyst_block
fill 10 109 276 10 109 291 minecraft:blackstone
setblock 10 109 292 minecraft:red_nether_bricks
fill 10 109 293 10 109 295 minecraft:magma_block
fill 10 109 296 10 110 296 minecraft:red_nether_bricks
setblock 10 109 297 minecraft:nether_wart_block
fill 10 109 298 10 109 299 minecraft:red_nether_bricks
setblock 10 109 300 minecraft:nether_wart_block
fill 10 109 301 10 109 316 minecraft:blackstone
fill 11 109 276 11 109 288 minecraft:blackstone
fill 11 109 289 12 109 290 minecraft:red_nether_bricks
setblock 11 109 291 minecraft:magma_block
fill 11 109 292 11 109 293 minecraft:shroomlight
fill 11 109 295 11 109 296 minecraft:shroomlight
setblock 11 109 297 minecraft:magma_block
fill 11 109 298 12 110 298 minecraft:red_nether_bricks
fill 11 109 302 11 110 302 minecraft:red_nether_bricks
setblock 11 109 303 minecraft:nether_wart_block
fill 11 109 304 11 109 316 minecraft:blackstone
fill 12 109 276 12 109 286 minecraft:blackstone
fill 12 109 287 13 110 287 minecraft:red_nether_bricks
setblock 12 109 288 minecraft:nether_wart_block
fill 12 109 291 13 109 291 minecraft:shroomlight
fill 12 109 297 13 109 297 minecraft:shroomlight
fill 12 109 305 13 110 305 minecraft:red_nether_bricks
fill 12 109 306 12 109 316 minecraft:blackstone
fill 13 109 276 13 109 285 minecraft:blackstone
fill 13 109 290 15 109 290 minecraft:magma_block
fill 13 109 298 15 109 298 minecraft:magma_block
setblock 13 109 306 minecraft:nether_wart_block
fill 13 109 307 13 109 316 minecraft:blackstone
fill 14 109 276 14 109 284 minecraft:blackstone
setblock 14 109 285 minecraft:nether_wart_block
fill 14 109 308 14 109 316 minecraft:blackstone
fill 15 109 276 15 109 283 minecraft:blackstone
fill 15 109 284 15 116 284 minecraft:red_nether_bricks
fill 15 109 291 16 109 291 minecraft:shroomlight
fill 15 109 297 16 109 297 minecraft:shroomlight
fill 15 109 308 15 112 308 minecraft:red_nether_bricks
fill 15 109 309 15 109 316 minecraft:blackstone
fill 16 109 276 16 109 282 minecraft:blackstone
fill 16 109 290 31 109 290 minecraft:red_nether_bricks
fill 16 109 298 30 109 298 minecraft:red_nether_bricks
setblock 16 109 309 minecraft:nether_wart_block
fill 16 109 310 16 109 316 minecraft:blackstone
fill 17 109 276 41 109 281 minecraft:blackstone
fill 17 109 282 25 109 282 minecraft:nether_wart_block
setblock 17 109 291 minecraft:magma_block
fill 17 109 292 17 109 293 minecraft:shroomlight
fill 17 109 295 17 109 296 minecraft:shroomlight
setblock 17 109 297 minecraft:magma_block
setblock 17 109 310 minecraft:red_nether_bricks
fill 17 109 311 41 109 316 minecraft:blackstone
fill 18 109 291 30 109 292 minecraft:red_nether_bricks
fill 18 109 293 18 109 295 minecraft:magma_block
fill 18 109 296 30 109 297 minecraft:red_nether_bricks
fill 19 109 293 30 109 295 minecraft:red_nether_bricks
fill 21 109 283 24 111 283 minecraft:red_nether_bricks
setblock 25 109 310 minecraft:red_nether_bricks
fill 26 109 282 41 109 282 minecraft:blackstone
setblock 26 109 309 minecraft:nether_wart_block
fill 26 109 310 41 109 310 minecraft:blackstone
fill 27 109 283 41 109 283 minecraft:blackstone
setblock 27 109 284 minecraft:red_nether_bricks
setblock 27 109 308 minecraft:red_nether_bricks
fill 27 109 309 41 109 309 minecraft:blackstone
fill 28 109 284 41 109 284 minecraft:blackstone
setblock 28 109 285 minecraft:nether_wart_block
setblock 28 109 286 minecraft:red_nether_bricks
fill 28 109 308 41 109 308 minecraft:blackstone
fill 29 109 285 41 109 285 minecraft:blackstone
fill 29 109 287 30 109 287 minecraft:red_nether_bricks
fill 29 109 305 30 109 305 minecraft:red_nether_bricks
setblock 29 109 306 minecraft:nether_wart_block
fill 29 109 307 41 109 307 minecraft:blackstone
fill 29 109 317 29 129 317 minecraft:cobbled_deepslate
fill 30 109 286 41 109 286 minecraft:blackstone
setblock 30 109 288 minecraft:nether_wart_block
fill 30 109 289 31 109 289 minecraft:red_nether_bricks
fill 30 109 306 41 109 306 minecraft:blackstone
setblock 30 109 317 minecraft:crying_obsidian
fill 31 109 287 41 109 288 minecraft:blackstone
setblock 31 109 291 minecraft:nether_wart_block
fill 31 109 292 32 109 292 minecraft:red_nether_bricks
fill 31 109 294 31 109 295 minecraft:red_nether_bricks
setblock 31 109 297 minecraft:red_nether_bricks
setblock 31 109 302 minecraft:red_nether_bricks
setblock 31 109 303 minecraft:nether_wart_block
fill 31 109 304 41 109 305 minecraft:blackstone
fill 32 109 289 41 109 291 minecraft:blackstone
setblock 32 109 293 minecraft:red_nether_bricks
setblock 32 109 294 minecraft:nether_wart_block
fill 32 109 295 32 109 296 minecraft:red_nether_bricks
setblock 32 109 297 minecraft:nether_wart_block
setblock 32 109 299 minecraft:red_nether_bricks
setblock 32 109 300 minecraft:nether_wart_block
fill 32 109 301 41 109 303 minecraft:blackstone
fill 33 109 292 41 109 300 minecraft:blackstone
fill 0 110 303 0 129 303 minecraft:cobbled_deepslate
fill 1 110 276 1 110 285 minecraft:basalt
fill 1 110 286 9 110 302 minecraft:blackstone
fill 1 110 303 1 110 314 minecraft:basalt
fill 1 110 315 1 111 316 minecraft:blackstone
fill 2 110 275 2 126 275 minecraft:cobbled_deepslate
fill 2 110 276 4 112 276 minecraft:basalt
setblock 2 110 277 minecraft:magma_block
fill 2 110 278 4 115 279 minecraft:basalt
setblock 2 110 280 minecraft:magma_block
fill 2 110 281 3 117 282 minecraft:basalt
setblock 2 110 283 minecraft:magma_block
fill 2 110 284 12 110 285 minecraft:blackstone
fill 2 110 303 10 110 304 minecraft:blackstone
fill 2 110 305 2 118 306 minecraft:basalt
setblock 2 110 307 minecraft:magma_block
fill 2 110 308 4 115 309 minecraft:basalt
setblock 2 110 310 minecraft:magma_block
fill 2 110 311 4 112 312 minecraft:basalt
setblock 2 110 313 minecraft:magma_block
fill 2 110 314 4 110 315 minecraft:basalt
fill 2 110 316 3 111 316 minecraft:blackstone
fill 3 110 277 10 114 277 minecraft:basalt
fill 3 110 280 6 117 280 minecraft:basalt
fill 3 110 283 14 110 283 minecraft:blackstone
fill 3 110 305 11 110 305 minecraft:blackstone
fill 3 110 306 3 118 307 minecraft:basalt
fill 3 110 310 10 115 310 minecraft:basalt
fill 3 110 313 10 111 313 minecraft:basalt
fill 4 110 281 5 119 281 minecraft:basalt
fill 4 110 282 16 110 282 minecraft:blackstone
fill 4 110 306 12 110 306 minecraft:blackstone
fill 4 110 307 5 119 307 minecraft:basalt
fill 4 110 316 10 110 316 minecraft:basalt
setblock 5 110 276 minecraft:magma_block
fill 5 110 278 7 117 278 minecraft:basalt
setblock 5 110 279 minecraft:magma_block
fill 5 110 308 6 119 308 minecraft:basalt
setblock 5 110 309 minecraft:magma_block
fill 5 110 311 7 116 311 minecraft:basalt
setblock 5 110 312 minecraft:magma_block
fill 5 110 314 7 112 314 minecraft:basalt
setblock 5 110 315 minecraft:magma_block
fill 6 110 276 13 115 276 minecraft:basalt
fill 6 110 279 9 118 279 minecraft:basalt
fill 6 110 281 19 110 281 minecraft:blackstone
fill 6 110 307 12 110 307 minecraft:blackstone
fill 6 110 309 9 118 309 minecraft:basalt
fill 6 110 312 13 115 312 minecraft:basalt
fill 6 110 315 13 111 315 minecraft:basalt
fill 6 110 317 6 115 317 minecraft:cobbled_deepslate
fill 7 110 280 21 110 280 minecraft:blackstone
fill 7 110 308 13 110 308 minecraft:blackstone
setblock 8 110 278 minecraft:magma_block
setblock 8 110 311 minecraft:magma_block
setblock 8 110 314 minecraft:magma_block
fill 9 110 278 16 110 278 minecraft:basalt
fill 9 110 311 16 117 311 minecraft:basalt
fill 9 110 314 16 113 314 minecraft:basalt
fill 10 110 279 18 110 279 minecraft:blackstone
fill 10 110 286 10 111 290 minecraft:blackstone
fill 10 110 291 11 111 291 minecraft:red_nether_bricks
setblock 10 110 292 minecraft:nether_wart_block
fill 10 110 293 10 110 294 minecraft:red_nether_bricks
setblock 10 110 295 minecraft:nether_wart_block
fill 10 110 297 11 111 297 minecraft:red_nether_bricks
setblock 10 110 298 minecraft:nether_wart_block
fill 10 110 299 13 110 300 minecraft:red_nether_bricks
setblock 10 110 301 minecraft:nether_wart_block
fill 10 110 302 10 111 302 minecraft:blackstone
fill 10 110 309 14 110 309 minecraft:blackstone
setblock 11 110 277 minecraft:magma_block
fill 11 110 286 11 111 287 minecraft:blackstone
fill 11 110 288 12 111 288 minecraft:red_nether_bricks
setblock 11 110 289 minecraft:nether_wart_block
fill 11 110 290 12 110 290 minecraft:red_nether_bricks
fill 11 110 292 11 110 293 minecraft:red_terracotta
fill 11 110 295 11 110 296 minecraft:red_terracotta
fill 11 110 303 26 111 303 minecraft:red_nether_bricks
setblock 11 110 304 minecraft:nether_wart_block
setblock 11 110 310 minecraft:magma_block
setblock 11 110 313 minecraft:magma_block
setblock 11 110 316 minecraft:magma_block
setblock 12 110 275 minecraft:crying_obsidian
fill 12 110 277 19 116 277 minecraft:basalt
setblock 12 110 286 minecraft:blackstone
fill 12 110 289 28 110 289 minecraft:red_nether_bricks
setblock 12 110 291 minecraft:red_terracotta
setblock 12 110 297 minecraft:red_terracotta
fill 12 110 301 27 110 302 minecraft:red_nether_bricks
fill 12 110 310 19 118 310 minecraft:basalt
fill 12 110 313 19 114 313 minecraft:basalt
fill 12 110 316 19 111 316 minecraft:basalt
fill 13 110 284 13 111 284 minecraft:blackstone
fill 13 110 285 26 111 285 minecraft:red_nether_bricks
setblock 13 110 286 minecraft:nether_wart_block
fill 13 110 290 16 110 290 minecraft:red_terracotta
setblock 13 110 298 minecraft:red_terracotta
fill 13 110 306 24 110 306 minecraft:red_nether_bricks
setblock 13 110 307 minecraft:nether_wart_block
setblock 14 110 276 minecraft:magma_block
setblock 14 110 284 minecraft:red_nether_bricks
fill 14 110 286 14 118 286 minecraft:red_nether_bricks
fill 14 110 288 28 110 288 minecraft:red_nether_bricks
fill 14 110 299 15 110 299 minecraft:red_terracotta
fill 14 110 300 28 110 300 minecraft:red_nether_bricks
fill 14 110 304 25 110 305 minecraft:red_nether_bricks
setblock 14 110 308 minecraft:red_nether_bricks
setblock 14 110 312 minecraft:magma_block
setblock 14 110 315 minecraft:magma_block
fill 15 110 276 22 114 276 minecraft:basalt
fill 15 110 283 16 110 283 minecraft:nether_wart_block
fill 15 110 309 18 110 309 minecraft:red_nether_bricks
fill 15 110 312 22 114 312 minecraft:basalt
fill 15 110 315 22 112 315 minecraft:basalt
fill 16 110 298 17 110 298 minecraft:red_terracotta
fill 16 110 299 28 110 299 minecraft:red_nether_bricks
fill 16 110 307 22 110 307 minecraft:red_nether_bricks
setblock 17 110 278 minecraft:magma_block
fill 17 110 282 20 111 283 minecraft:red_nether_bricks
fill 17 110 290 29 110 290 minecraft:red_nether_bricks
setblock 17 110 291 minecraft:red_terracotta
fill 17 110 308 21 110 308 minecraft:red_nether_bricks
setblock 17 110 311 minecraft:magma_block
setblock 17 110 314 minecraft:magma_block
fill 18 110 278 25 115 278 minecraft:basalt
fill 18 110 291 29 110 291 minecraft:red_nether_bricks
setblock 18 110 292 minecraft:red_terracotta
fill 18 110 296 18 110 297 minecraft:red_terracotta
fill 18 110 298 29 110 298 minecraft:red_nether_bricks
fill 18 110 311 25 114 311 minecraft:basalt
fill 18 110 314 25 111 314 minecraft:basalt
fill 19 110 279 22 110 279 minecraft:basalt
fill 19 110 292 29 110 292 minecraft:red_nether_bricks
fill 19 110 293 19 110 295 minecraft:red_terracotta
fill 19 110 296 29 110 297 minecraft:red_nether_bricks
fill 19 110 309 22 110 309 minecraft:basalt
setblock 20 110 277 minecraft:magma_block
fill 20 110 281 22 110 281 minecraft:red_nether_bricks
fill 20 110 293 29 111 295 minecraft:red_nether_bricks
setblock 20 110 310 minecraft:magma_block
setblock 20 110 313 minecraft:magma_block
setblock 20 110 316 minecraft:magma_block
fill 21 110 277 28 112 277 minecraft:basalt
fill 21 110 282 24 110 282 minecraft:red_nether_bricks
fill 21 110 310 28 113 310 minecraft:basalt
fill 21 110 313 28 111 313 minecraft:basalt
fill 21 110 316 24 110 316 minecraft:basalt
fill 22 110 280 28 115 280 minecraft:basalt
fill 22 110 308 25 116 308 minecraft:basalt
setblock 23 110 276 minecraft:magma_block
setblock 23 110 279 minecraft:magma_block
fill 23 110 281 25 118 281 minecraft:basalt
fill 23 110 307 28 116 307 minecraft:basalt
setblock 23 110 309 minecraft:magma_block
setblock 23 110 312 minecraft:magma_block
setblock 23 110 315 minecraft:magma_block
fill 24 110 276 30 110 276 minecraft:basalt
fill 24 110 279 31 112 279 minecraft:basalt
fill 24 110 309 31 112 309 minecraft:basalt
fill 24 110 312 30 110 312 minecraft:basalt
fill 24 110 315 26 110 315 minecraft:basalt
fill 25 110 282 31 114 282 minecraft:basalt
setblock 25 110 283 minecraft:red_nether_bricks
fill 25 110 306 31 114 306 minecraft:basalt
fill 25 110 316 41 111 316 minecraft:blackstone
setblock 26 110 278 minecraft:magma_block
setblock 26 110 281 minecraft:magma_block
fill 26 110 283 28 116 283 minecraft:basalt
setblock 26 110 304 minecraft:red_nether_bricks
setblock 26 110 305 minecraft:magma_block
setblock 26 110 308 minecraft:magma_block
setblock 26 110 311 minecraft:magma_block
setblock 26 110 314 minecraft:magma_block
fill 27 110 278 32 110 278 minecraft:basalt
fill 27 110 281 34 110 281 minecraft:basalt
fill 27 110 284 31 115 285 minecraft:basalt
fill 27 110 303 28 117 305 minecraft:basalt
fill 27 110 308 34 110 308 minecraft:basalt
fill 27 110 311 31 110 311 minecraft:basalt
fill 27 110 314 28 110 314 minecraft:basalt
fill 27 110 315 41 111 315 minecraft:blackstone
fill 28 110 286 28 119 286 minecraft:basalt
setblock 28 110 301 minecraft:red_nether_bricks
fill 28 110 302 34 113 302 minecraft:basalt
setblock 29 110 277 minecraft:magma_block
setblock 29 110 280 minecraft:magma_block
setblock 29 110 283 minecraft:magma_block
setblock 29 110 286 minecraft:magma_block
fill 29 110 287 31 116 288 minecraft:basalt
setblock 29 110 289 minecraft:magma_block
fill 29 110 299 31 116 300 minecraft:basalt
setblock 29 110 301 minecraft:magma_block
fill 29 110 303 31 116 303 minecraft:basalt
setblock 29 110 304 minecraft:magma_block
fill 29 110 305 34 111 305 minecraft:basalt
setblock 29 110 307 minecraft:magma_block
setblock 29 110 310 minecraft:magma_block
setblock 29 110 313 minecraft:magma_block
fill 29 110 314 41 111 314 minecraft:blackstone
fill 30 110 277 31 110 277 minecraft:basalt
fill 30 110 280 34 110 280 minecraft:basalt
fill 30 110 283 35 110 283 minecraft:basalt
fill 30 110 286 37 110 286 minecraft:basalt
fill 30 110 289 31 117 298 minecraft:basalt
fill 30 110 301 37 110 301 minecraft:basalt
fill 30 110 304 36 110 304 minecraft:basalt
fill 30 110 307 34 110 307 minecraft:basalt
fill 30 110 310 32 110 310 minecraft:basalt
fill 30 110 313 41 111 313 minecraft:blackstone
fill 30 110 317 30 113 317 minecraft:cobbled_deepslate
fill 31 110 276 41 111 276 minecraft:blackstone
fill 31 110 312 41 111 312 minecraft:blackstone
fill 32 110 277 41 111 277 minecraft:blackstone
setblock 32 110 279 minecraft:magma_block
setblock 32 110 282 minecraft:magma_block
fill 32 110 284 34 112 284 minecraft:basalt
setblock 32 110 285 minecraft:magma_block
fill 32 110 287 34 113 287 minecraft:basalt
setblock 32 110 288 minecraft:magma_block
fill 32 110 289 34 114 290 minecraft:basalt
setblock 32 110 291 minecraft:magma_block
fill 32 110 292 34 115 293 minecraft:basalt
setblock 32 110 294 minecraft:magma_block
fill 32 110 295 34 115 296 minecraft:basalt
setblock 32 110 297 minecraft:magma_block
fill 32 110 298 34 114 299 minecraft:basalt
setblock 32 110 300 minecraft:magma_block
setblock 32 110 303 minecraft:magma_block
setblock 32 110 306 minecraft:magma_block
setblock 32 110 309 minecraft:magma_block
fill 32 110 311 41 111 311 minecraft:blackstone
fill 33 110 278 41 111 278 minecraft:blackstone
setblock 33 110 279 minecraft:basalt
fill 33 110 282 35 110 282 minecraft:basalt
fill 33 110 285 36 110 285 minecraft:basalt
fill 33 110 288 37 110 288 minecraft:basalt
fill 33 110 291 38 110 291 minecraft:basalt
fill 33 110 294 38 110 294 minecraft:basalt
fill 33 110 297 38 110 297 minecraft:basalt
fill 33 110 300 37 110 300 minecraft:basalt
fill 33 110 303 36 110 303 minecraft:basalt
fill 33 110 306 35 110 306 minecraft:basalt
setblock 33 110 309 minecraft:basalt
fill 33 110 310 41 111 310 minecraft:blackstone
fill 34 110 279 41 111 279 minecraft:blackstone
fill 34 110 309 41 111 309 minecraft:blackstone
fill 35 110 280 41 111 281 minecraft:blackstone
setblock 35 110 284 minecraft:magma_block
setblock 35 110 287 minecraft:magma_block
fill 35 110 289 37 111 289 minecraft:basalt
setblock 35 110 290 minecraft:magma_block
fill 35 110 292 37 111 292 minecraft:basalt
setblock 35 110 293 minecraft:magma_block
fill 35 110 295 37 111 295 minecraft:basalt
setblock 35 110 296 minecraft:magma_block
fill 35 110 298 37 111 298 minecraft:basalt
setblock 35 110 299 minecraft:magma_block
setblock 35 110 302 minecraft:magma_block
setblock 35 110 305 minecraft:magma_block
fill 35 110 307 41 111 308 minecraft:blackstone
fill 36 110 282 41 111 283 minecraft:blackstone
setblock 36 110 284 minecraft:basalt
fill 36 110 287 37 110 287 minecraft:basalt
fill 36 110 290 38 110 290 minecraft:basalt
fill 36 110 293 38 110 293 minecraft:basalt
fill 36 110 296 38 110 296 minecraft:basalt
fill 36 110 299 38 110 299 minecraft:basalt
fill 36 110 302 37 110 302 minecraft:basalt
fill 36 110 305 41 111 306 minecraft:blackstone
fill 37 110 284 41 111 285 minecraft:blackstone
fill 37 110 303 41 111 304 minecraft:blackstone
fill 38 110 286 41 111 288 minecraft:blackstone
setblock 38 110 289 minecraft:magma_block
setblock 38 110 292 minecraft:magma_block
setblock 38 110 295 minecraft:magma_block
setblock 38 110 298 minecraft:magma_block
fill 38 110 300 41 111 302 minecraft:blackstone
fill 39 110 289 41 111 299 minecraft:blackstone
fill 1 111 276 1 112 284 minecraft:basalt
setblock 1 111 285 minecraft:magma_block
fill 1 111 286 1 120 286 minecraft:basalt
fill 1 111 287 9 111 301 minecraft:blackstone
fill 1 111 302 1 120 302 minecraft:basalt
setblock 1 111 303 minecraft:magma_block
fill 1 111 304 1 111 313 minecraft:basalt
setblock 1 111 314 minecraft:blackstone
fill 2 111 277 2 114 277 minecraft:basalt
fill 2 111 280 2 116 280 minecraft:basalt
fill 2 111 283 2 118 284 minecraft:basalt
fill 2 111 285 9 111 286 minecraft:blackstone
fill 2 111 302 9 111 303 minecraft:blackstone
fill 2 111 304 2 120 304 minecraft:basalt
fill 2 111 307 2 117 307 minecraft:basalt
fill 2 111 310 2 115 310 minecraft:basalt
fill 2 111 313 2 111 314 minecraft:basalt
fill 2 111 315 3 111 315 minecraft:blackstone
fill 3 111 283 3 120 283 minecraft:basalt
fill 3 111 284 12 111 284 minecraft:blackstone
fill 3 111 304 10 111 304 minecraft:blackstone
fill 3 111 305 3 120 305 minecraft:basalt
fill 3 111 314 4 111 314 minecraft:basalt
fill 4 111 282 4 120 282 minecraft:basalt
fill 4 111 283 14 111 283 minecraft:blackstone
fill 4 111 305 11 111 305 minecraft:blackstone
fill 4 111 306 4 120 306 minecraft:basalt
fill 4 111 315 5 111 315 minecraft:basalt
fill 4 111 316 5 111 316 minecraft:blackstone
fill 5 111 276 5 115 276 minecraft:basalt
fill 5 111 279 5 118 279 minecraft:basalt
fill 5 111 282 16 111 282 minecraft:blackstone
fill 5 111 306 11 111 306 minecraft:blackstone
fill 5 111 309 5 118 309 minecraft:basalt
fill 5 111 312 5 115 312 minecraft:basalt
fill 6 111 281 6 120 281 minecraft:basalt
fill 6 111 307 6 120 307 minecraft:basalt
setblock 6 111 316 minecraft:basalt
setblock 7 111 280 minecraft:magma_block
fill 7 111 281 18 111 281 minecraft:blackstone
fill 7 111 307 12 111 307 minecraft:blackstone
fill 7 111 308 8 120 308 minecraft:basalt
setblock 7 111 316 minecraft:magma_block
fill 8 111 278 12 118 278 minecraft:basalt
fill 8 111 280 8 120 280 minecraft:basalt
fill 8 111 311 8 117 311 minecraft:basalt
fill 8 111 314 8 114 314 minecraft:basalt
fill 8 111 316 11 112 316 minecraft:basalt
fill 9 111 280 19 111 280 minecraft:blackstone
fill 9 111 308 13 111 308 minecraft:blackstone
setblock 10 111 279 minecraft:magma_block
fill 10 111 285 12 111 285 minecraft:blackstone
fill 10 111 292 10 112 292 minecraft:red_nether_bricks
setblock 10 111 293 minecraft:nether_wart_block
fill 10 111 294 10 111 295 minecraft:red_nether_bricks
setblock 10 111 296 minecraft:nether_wart_block
fill 10 111 298 11 112 298 minecraft:red_nether_bricks
setblock 10 111 299 minecraft:nether_wart_block
fill 10 111 300 10 111 301 minecraft:red_nether_bricks
setblock 10 111 303 minecraft:blackstone
setblock 10 111 309 minecraft:magma_block
fill 11 111 277 11 118 277 minecraft:basalt
fill 11 111 279 12 120 279 minecraft:basalt
fill 11 111 289 14 111 289 minecraft:red_nether_bricks
setblock 11 111 290 minecraft:nether_wart_block
fill 11 111 292 11 111 293 minecraft:magma_block
fill 11 111 295 11 111 296 minecraft:magma_block
fill 11 111 299 12 117 300 minecraft:red_nether_bricks
setblock 11 111 302 minecraft:nether_wart_block
fill 11 111 304 11 112 304 minecraft:red_nether_bricks
fill 11 111 309 11 118 310 minecraft:basalt
fill 11 111 313 11 116 313 minecraft:basalt
fill 12 111 275 12 129 275 minecraft:cobbled_deepslate
fill 12 111 286 13 112 286 minecraft:red_nether_bricks
setblock 12 111 287 minecraft:nether_wart_block
fill 12 111 290 12 119 290 minecraft:red_nether_bricks
setblock 12 111 291 minecraft:magma_block
fill 12 111 297 12 111 298 minecraft:magma_block
fill 12 111 301 26 112 302 minecraft:red_nether_bricks
setblock 12 111 305 minecraft:nether_wart_block
fill 12 111 306 23 111 306 minecraft:red_nether_bricks
fill 12 111 309 12 120 309 minecraft:basalt
setblock 13 111 278 minecraft:magma_block
fill 13 111 279 15 111 279 minecraft:blackstone
fill 13 111 287 27 111 287 minecraft:red_nether_bricks
fill 13 111 290 14 111 290 minecraft:magma_block
fill 13 111 299 17 111 299 minecraft:magma_block
fill 13 111 300 27 111 300 minecraft:red_nether_bricks
fill 13 111 305 24 111 305 minecraft:red_nether_bricks
fill 13 111 307 13 112 307 minecraft:red_nether_bricks
fill 13 111 309 14 111 309 minecraft:blackstone
fill 14 111 276 14 117 276 minecraft:basalt
fill 14 111 278 17 118 278 minecraft:basalt
setblock 14 111 284 minecraft:nether_wart_block
fill 14 111 288 27 112 288 minecraft:red_nether_bricks
fill 14 111 304 25 111 304 minecraft:red_nether_bricks
setblock 14 111 308 minecraft:nether_wart_block
fill 14 111 312 14 117 312 minecraft:basalt
fill 14 111 315 14 114 315 minecraft:basalt
fill 15 111 283 16 112 283 minecraft:red_nether_bricks
fill 15 111 286 26 112 286 minecraft:red_nether_bricks
setblock 15 111 289 minecraft:magma_block
setblock 15 111 309 minecraft:red_nether_bricks
fill 16 111 279 18 120 279 minecraft:basalt
fill 16 111 289 28 111 289 minecraft:red_nether_bricks
fill 16 111 290 17 111 290 minecraft:magma_block
fill 16 111 307 21 111 307 minecraft:red_nether_bricks
fill 16 111 309 18 120 309 minecraft:basalt
fill 17 111 308 19 111 308 minecraft:red_nether_bricks
fill 17 111 311 17 118 311 minecraft:basalt
fill 17 111 314 17 114 314 minecraft:basalt
fill 18 111 290 28 111 290 minecraft:red_nether_bricks
setblock 18 111 291 minecraft:magma_block
setblock 18 111 298 minecraft:magma_block
fill 18 111 299 28 111 299 minecraft:red_nether_bricks
setblock 19 111 279 minecraft:magma_block
fill 19 111 281 21 111 281 minecraft:nether_wart_block
fill 19 111 291 28 111 291 minecraft:red_nether_bricks
fill 19 111 292 19 111 297 minecraft:magma_block
fill 19 111 298 28 111 298 minecraft:red_nether_bricks
setblock 19 111 309 minecraft:magma_block
fill 20 111 277 20 117 277 minecraft:basalt
fill 20 111 279 21 119 280 minecraft:basalt
fill 20 111 292 28 111 292 minecraft:red_nether_bricks
fill 20 111 296 28 111 297 minecraft:red_nether_bricks
fill 20 111 308 20 118 310 minecraft:basalt
fill 20 111 313 20 115 313 minecraft:basalt
fill 20 111 316 22 111 316 minecraft:basalt
fill 21 111 282 23 111 282 minecraft:red_nether_bricks
fill 21 111 308 21 119 309 minecraft:basalt
fill 22 111 279 23 118 279 minecraft:basalt
setblock 22 111 281 minecraft:magma_block
fill 22 111 307 22 120 307 minecraft:basalt
fill 22 111 309 23 118 309 minecraft:basalt
fill 23 111 276 29 111 276 minecraft:basalt
fill 23 111 312 29 111 312 minecraft:basalt
fill 23 111 315 24 111 315 minecraft:basalt
fill 23 111 316 24 111 316 minecraft:blackstone
fill 24 111 282 24 120 282 minecraft:basalt
fill 24 111 306 24 120 306 minecraft:basalt
setblock 25 111 283 minecraft:magma_block
fill 25 111 305 26 118 305 minecraft:basalt
fill 25 111 315 26 111 315 minecraft:blackstone
fill 26 111 278 30 112 278 minecraft:basalt
fill 26 111 281 33 111 281 minecraft:basalt
fill 26 111 284 26 120 284 minecraft:basalt
fill 26 111 304 26 120 304 minecraft:basalt
fill 26 111 308 33 111 308 minecraft:basalt
fill 26 111 311 30 111 311 minecraft:basalt
setblock 26 111 314 minecraft:basalt
fill 27 111 286 27 120 286 minecraft:basalt
setblock 27 111 301 minecraft:red_nether_bricks
setblock 27 111 302 minecraft:basalt
fill 27 111 314 28 111 314 minecraft:blackstone
fill 28 111 287 28 120 287 minecraft:basalt
setblock 28 111 288 minecraft:magma_block
setblock 28 111 300 minecraft:magma_block
fill 28 111 301 36 111 301 minecraft:basalt
fill 29 111 277 30 111 277 minecraft:basalt
fill 29 111 280 33 111 280 minecraft:basalt
fill 29 111 283 33 112 283 minecraft:basalt
fill 29 111 286 36 111 286 minecraft:basalt
fill 29 111 289 29 118 292 minecraft:basalt
fill 29 111 296 29 120 298 minecraft:basalt
fill 29 111 304 35 111 304 minecraft:basalt
fill 29 111 307 33 111 307 minecraft:basalt
fill 29 111 310 31 111 310 minecraft:basalt
setblock 29 111 313 minecraft:blackstone
setblock 30 111 276 minecraft:blackstone
setblock 30 111 312 minecraft:blackstone
setblock 31 111 277 minecraft:blackstone
setblock 31 111 278 minecraft:magma_block
setblock 31 111 311 minecraft:blackstone
setblock 32 111 278 minecraft:blackstone
setblock 32 111 279 minecraft:basalt
fill 32 111 282 34 111 282 minecraft:basalt
fill 32 111 285 35 111 285 minecraft:basalt
fill 32 111 288 36 112 288 minecraft:basalt
fill 32 111 291 36 112 291 minecraft:basalt
fill 32 111 294 36 112 294 minecraft:basalt
fill 32 111 297 36 112 297 minecraft:basalt
fill 32 111 300 36 112 300 minecraft:basalt
fill 32 111 303 35 111 303 minecraft:basalt
fill 32 111 306 34 111 306 minecraft:basalt
setblock 32 111 309 minecraft:basalt
setblock 32 111 310 minecraft:blackstone
setblock 33 111 279 minecraft:blackstone
setblock 33 111 309 minecraft:blackstone
fill 34 111 280 34 111 281 minecraft:blackstone
setblock 34 111 283 minecraft:magma_block
fill 34 111 307 34 111 308 minecraft:blackstone
fill 35 111 282 35 111 283 minecraft:blackstone
setblock 35 111 284 minecraft:basalt
fill 35 111 287 36 111 287 minecraft:basalt
fill 35 111 290 37 111 290 minecraft:basalt
fill 35 111 293 37 111 293 minecraft:basalt
fill 35 111 296 37 111 296 minecraft:basalt
fill 35 111 299 37 111 299 minecraft:basalt
fill 35 111 302 36 111 302 minecraft:basalt
fill 35 111 305 35 111 306 minecraft:blackstone
setblock 36 111 275 minecraft:purple_concrete
fill 36 111 284 36 111 285 minecraft:blackstone
fill 36 111 303 36 111 304 minecraft:blackstone
fill 37 111 275 37 129 275 minecraft:cobbled_deepslate
fill 37 111 286 37 111 288 minecraft:blackstone
setblock 37 111 291 minecraft:magma_block
setblock 37 111 294 minecraft:magma_block
setblock 37 111 297 minecraft:magma_block
fill 37 111 300 37 111 302 minecraft:blackstone
fill 38 111 289 38 111 299 minecraft:blackstone
setblock 42 111 308 minecraft:amethyst_block
fill 1 112 285 2 119 285 minecraft:basalt
fill 1 112 287 1 121 287 minecraft:basalt
fill 1 112 301 1 121 301 minecraft:basalt
fill 1 112 303 1 112 312 minecraft:basalt
fill 2 112 303 2 120 303 minecraft:basalt
setblock 2 112 313 minecraft:basalt
fill 3 112 284 3 121 284 minecraft:basalt
setblock 3 112 304 minecraft:magma_block
setblock 3 112 313 minecraft:magma_block
fill 4 112 283 4 121 283 minecraft:basalt
fill 4 112 305 4 121 305 minecraft:basalt
fill 4 112 313 4 112 314 minecraft:basalt
fill 5 112 282 5 120 282 minecraft:basalt
fill 5 112 306 5 120 306 minecraft:basalt
fill 5 112 313 10 114 313 minecraft:basalt
setblock 6 112 315 minecraft:magma_block
fill 7 112 280 7 119 281 minecraft:basalt
fill 7 112 307 7 121 307 minecraft:basalt
fill 7 112 315 13 112 315 minecraft:basalt
fill 9 112 280 10 121 280 minecraft:basalt
setblock 9 112 308 minecraft:magma_block
fill 10 112 279 10 119 279 minecraft:basalt
fill 10 112 290 11 113 290 minecraft:red_nether_bricks
setblock 10 112 291 minecraft:nether_wart_block
fill 10 112 293 10 113 293 minecraft:red_nether_bricks
setblock 10 112 294 minecraft:nether_wart_block
fill 10 112 295 10 112 296 minecraft:red_nether_bricks
setblock 10 112 297 minecraft:nether_wart_block
fill 10 112 299 10 113 299 minecraft:red_nether_bricks
setblock 10 112 300 minecraft:nether_wart_block
fill 10 112 301 10 112 302 minecraft:red_nether_bricks
fill 10 112 308 10 119 309 minecraft:basalt
setblock 11 112 288 minecraft:nether_wart_block
fill 11 112 289 13 112 289 minecraft:red_nether_bricks
fill 11 112 291 11 117 291 minecraft:red_nether_bricks
fill 11 112 292 11 112 296 minecraft:red_terracotta
fill 11 112 297 11 117 297 minecraft:red_nether_bricks
fill 11 112 302 11 113 302 minecraft:red_nether_bricks
setblock 11 112 303 minecraft:nether_wart_block
fill 12 112 287 12 113 288 minecraft:red_nether_bricks
fill 12 112 291 12 113 291 minecraft:red_terracotta
fill 12 112 297 12 113 298 minecraft:red_terracotta
fill 12 112 303 25 112 303 minecraft:red_nether_bricks
fill 12 112 305 23 112 305 minecraft:red_nether_bricks
setblock 12 112 306 minecraft:nether_wart_block
setblock 12 112 316 minecraft:magma_block
fill 13 112 278 13 119 279 minecraft:basalt
setblock 13 112 285 minecraft:nether_wart_block
fill 13 112 287 26 112 287 minecraft:red_nether_bricks
fill 13 112 290 13 113 290 minecraft:red_terracotta
fill 13 112 299 14 112 299 minecraft:red_terracotta
fill 13 112 300 14 112 300 minecraft:red_nether_bricks
fill 13 112 306 22 112 306 minecraft:red_nether_bricks
fill 13 112 309 14 120 309 minecraft:basalt
fill 13 112 316 20 112 316 minecraft:basalt
fill 14 112 279 14 120 279 minecraft:basalt
fill 14 112 284 14 113 285 minecraft:red_nether_bricks
fill 14 112 289 17 113 289 minecraft:red_terracotta
fill 14 112 304 24 112 304 minecraft:red_nether_bricks
setblock 14 112 308 minecraft:red_nether_bricks
setblock 15 112 279 minecraft:magma_block
fill 15 112 285 25 112 285 minecraft:red_nether_bricks
fill 15 112 300 17 113 300 minecraft:red_terracotta
setblock 15 112 309 minecraft:magma_block
fill 16 112 282 18 112 282 minecraft:nether_wart_block
fill 16 112 307 20 112 307 minecraft:red_nether_bricks
fill 17 112 283 23 112 284 minecraft:red_nether_bricks
setblock 17 112 308 minecraft:red_nether_bricks
fill 18 112 280 19 121 280 minecraft:basalt
fill 18 112 289 27 112 289 minecraft:red_nether_bricks
setblock 18 112 290 minecraft:red_terracotta
setblock 18 112 299 minecraft:red_terracotta
fill 18 112 300 27 112 300 minecraft:red_nether_bricks
setblock 18 112 308 minecraft:magma_block
fill 18 112 314 24 112 314 minecraft:basalt
fill 19 112 279 19 119 279 minecraft:basalt
fill 19 112 281 20 112 282 minecraft:red_nether_bricks
fill 19 112 290 27 112 290 minecraft:red_nether_bricks
setblock 19 112 291 minecraft:red_terracotta
setblock 19 112 298 minecraft:red_terracotta
fill 19 112 299 27 112 299 minecraft:red_nether_bricks
fill 19 112 308 19 119 309 minecraft:basalt
fill 20 112 291 28 112 291 minecraft:red_nether_bricks
fill 20 112 292 20 112 297 minecraft:red_terracotta
fill 20 112 298 27 112 298 minecraft:red_nether_bricks
fill 21 112 281 22 119 281 minecraft:basalt
fill 21 112 282 22 112 282 minecraft:red_nether_bricks
fill 21 112 292 28 112 297 minecraft:red_nether_bricks
setblock 21 112 307 minecraft:magma_block
fill 21 112 313 26 112 313 minecraft:basalt
fill 23 112 276 28 112 276 minecraft:basalt
fill 23 112 282 23 120 282 minecraft:basalt
fill 23 112 306 23 120 306 minecraft:basalt
fill 23 112 312 28 112 312 minecraft:basalt
fill 24 112 283 25 119 283 minecraft:basalt
setblock 24 112 284 minecraft:red_nether_bricks
fill 24 112 305 24 121 305 minecraft:basalt
fill 25 112 284 25 121 284 minecraft:basalt
fill 25 112 304 25 121 304 minecraft:basalt
fill 26 112 281 32 112 281 minecraft:basalt
fill 26 112 285 26 120 285 minecraft:basalt
fill 26 112 303 26 120 303 minecraft:basalt
fill 26 112 308 32 112 308 minecraft:basalt
fill 26 112 311 29 112 311 minecraft:basalt
setblock 27 112 287 minecraft:magma_block
fill 27 112 301 35 112 301 minecraft:basalt
setblock 27 112 302 minecraft:magma_block
fill 28 112 288 28 119 290 minecraft:basalt
fill 28 112 298 28 119 300 minecraft:basalt
setblock 29 112 277 minecraft:basalt
fill 29 112 280 32 112 280 minecraft:basalt
fill 29 112 286 35 112 286 minecraft:basalt
fill 29 112 293 29 120 295 minecraft:basalt
fill 29 112 304 33 112 305 minecraft:basalt
fill 29 112 307 32 112 307 minecraft:basalt
fill 29 112 310 29 113 310 minecraft:basalt
setblock 30 112 310 minecraft:magma_block
fill 32 112 282 32 113 282 minecraft:basalt
fill 32 112 285 34 113 285 minecraft:basalt
fill 32 112 303 34 113 303 minecraft:basalt
fill 32 112 306 32 113 306 minecraft:basalt
setblock 33 112 282 minecraft:magma_block
setblock 33 112 306 minecraft:magma_block
setblock 34 112 304 minecraft:basalt
setblock 35 112 287 minecraft:basalt
fill 35 112 289 35 112 290 minecraft:basalt
fill 35 112 292 35 112 293 minecraft:basalt
fill 35 112 295 35 112 296 minecraft:basalt
fill 35 112 298 35 112 299 minecraft:basalt
setblock 35 112 302 minecraft:basalt
fill 36 112 275 36 126 275 minecraft:cobbled_deepslate
setblock 36 112 289 minecraft:basalt
setblock 36 112 290 minecraft:magma_block
setblock 36 112 292 minecraft:basalt
setblock 36 112 293 minecraft:magma_block
setblock 36 112 295 minecraft:basalt
setblock 36 112 296 minecraft:magma_block
setblock 36 112 298 minecraft:basalt
setblock 36 112 299 minecraft:magma_block
fill 42 112 308 42 126 308 minecraft:cobbled_deepslate
fill 1 113 277 1 113 284 minecraft:basalt
fill 1 113 288 1 121 289 minecraft:basalt
fill 1 113 299 1 113 300 minecraft:basalt
fill 1 113 303 1 113 311 minecraft:basalt
setblock 2 113 276 minecraft:magma_block
fill 2 113 286 2 121 287 minecraft:basalt
fill 2 113 301 2 121 302 minecraft:basalt
fill 2 113 311 4 114 311 minecraft:basalt
setblock 2 113 312 minecraft:magma_block
fill 3 113 276 4 113 276 minecraft:basalt
fill 3 113 285 3 121 285 minecraft:basalt
setblock 3 113 286 minecraft:light[level=12]
setblock 3 113 294 minecraft:light[level=12]
setblock 3 113 302 minecraft:light[level=12]
fill 3 113 303 3 120 304 minecraft:basalt
fill 3 113 312 4 113 312 minecraft:basalt
fill 4 113 284 4 121 284 minecraft:basalt
fill 4 113 304 4 121 304 minecraft:basalt
setblock 4 113 313 minecraft:basalt
fill 5 113 283 5 121 283 minecraft:basalt
setblock 5 113 305 minecraft:magma_block
setblock 5 113 314 minecraft:magma_block
fill 6 113 282 7 113 282 minecraft:basalt
fill 6 113 306 7 113 306 minecraft:basalt
fill 6 113 314 7 113 314 minecraft:basalt
fill 8 113 281 9 121 281 minecraft:basalt
setblock 8 113 307 minecraft:magma_block
fill 8 113 315 10 113 315 minecraft:basalt
fill 9 113 307 9 120 308 minecraft:basalt
fill 10 113 291 10 114 291 minecraft:red_nether_bricks
setblock 10 113 292 minecraft:nether_wart_block
fill 10 113 294 10 114 294 minecraft:red_nether_bricks
setblock 10 113 295 minecraft:nether_wart_block
fill 10 113 296 10 113 297 minecraft:red_nether_bricks
setblock 10 113 298 minecraft:nether_wart_block
fill 10 113 300 10 114 300 minecraft:red_nether_bricks
setblock 10 113 301 minecraft:nether_wart_block
setblock 10 113 302 minecraft:red_nether_bricks
fill 11 113 280 16 113 280 minecraft:basalt
setblock 11 113 286 minecraft:light[level=12]
fill 11 113 288 11 114 288 minecraft:red_nether_bricks
setblock 11 113 289 minecraft:nether_wart_block
fill 11 113 292 11 118 292 minecraft:red_nether_bricks
fill 11 113 293 11 113 296 minecraft:red_terracotta
fill 11 113 298 11 118 298 minecraft:red_nether_bricks
fill 11 113 303 24 113 303 minecraft:red_nether_bricks
setblock 11 113 304 minecraft:nether_wart_block
fill 11 113 308 13 121 308 minecraft:basalt
setblock 11 113 315 minecraft:magma_block
setblock 12 113 286 minecraft:nether_wart_block
fill 12 113 289 13 118 289 minecraft:red_nether_bricks
setblock 12 113 292 minecraft:red_terracotta
fill 12 113 301 25 113 302 minecraft:red_nether_bricks
fill 12 113 305 20 113 306 minecraft:red_nether_bricks
fill 12 113 315 13 113 315 minecraft:basalt
fill 13 113 285 13 114 287 minecraft:red_nether_bricks
setblock 13 113 299 minecraft:red_terracotta
fill 13 113 300 13 114 300 minecraft:red_nether_bricks
setblock 13 113 307 minecraft:nether_wart_block
fill 14 113 287 25 113 288 minecraft:red_nether_bricks
setblock 14 113 300 minecraft:red_terracotta
fill 14 113 304 23 113 304 minecraft:red_nether_bricks
setblock 14 113 308 minecraft:magma_block
fill 15 113 279 15 120 279 minecraft:basalt
setblock 15 113 283 minecraft:nether_wart_block
fill 15 113 285 24 113 286 minecraft:red_nether_bricks
fill 15 113 308 15 120 309 minecraft:basalt
fill 15 113 315 19 113 315 minecraft:basalt
fill 16 113 282 20 113 283 minecraft:red_nether_bricks
fill 16 113 307 18 113 307 minecraft:red_nether_bricks
fill 16 113 308 18 120 308 minecraft:basalt
setblock 17 113 280 minecraft:magma_block
fill 17 113 284 23 113 284 minecraft:red_nether_bricks
setblock 18 113 289 minecraft:red_terracotta
setblock 18 113 300 minecraft:red_terracotta
fill 18 113 314 22 113 314 minecraft:basalt
fill 19 113 281 20 113 281 minecraft:basalt
fill 19 113 289 26 113 289 minecraft:red_nether_bricks
setblock 19 113 290 minecraft:red_terracotta
setblock 19 113 294 minecraft:light[level=12]
setblock 19 113 299 minecraft:red_terracotta
fill 19 113 300 26 113 300 minecraft:red_nether_bricks
fill 19 113 307 21 120 307 minecraft:basalt
fill 20 113 290 27 113 290 minecraft:red_nether_bricks
fill 20 113 291 20 113 292 minecraft:red_terracotta
fill 20 113 297 20 113 298 minecraft:red_terracotta
fill 20 113 299 26 113 299 minecraft:red_nether_bricks
setblock 20 113 315 minecraft:magma_block
setblock 20 113 317 minecraft:crying_obsidian
fill 21 113 277 27 113 277 minecraft:basalt
fill 21 113 282 22 121 282 minecraft:basalt
fill 21 113 283 22 113 283 minecraft:red_nether_bricks
fill 21 113 291 27 113 292 minecraft:red_nether_bricks
fill 21 113 293 21 113 296 minecraft:red_terracotta
fill 21 113 297 27 113 298 minecraft:red_nether_bricks
fill 21 113 305 22 113 305 minecraft:red_nether_bricks
fill 21 113 306 22 121 306 minecraft:basalt
fill 21 113 313 24 113 313 minecraft:basalt
fill 22 113 293 27 113 296 minecraft:red_nether_bricks
fill 23 113 276 26 113 276 minecraft:basalt
fill 23 113 283 23 121 283 minecraft:basalt
setblock 23 113 305 minecraft:magma_block
fill 23 113 312 26 113 312 minecraft:basalt
setblock 23 113 314 minecraft:magma_block
fill 24 113 279 28 114 279 minecraft:basalt
fill 24 113 284 24 121 284 minecraft:basalt
fill 24 113 304 24 121 304 minecraft:basalt
fill 24 113 309 28 114 309 minecraft:basalt
fill 25 113 285 25 121 285 minecraft:basalt
setblock 25 113 286 minecraft:red_nether_bricks
fill 25 113 303 25 121 303 minecraft:basalt
fill 26 113 278 29 113 278 minecraft:basalt
fill 26 113 281 31 113 281 minecraft:basalt
setblock 26 113 286 minecraft:magma_block
fill 26 113 287 27 120 287 minecraft:basalt
setblock 26 113 288 minecraft:red_nether_bricks
setblock 26 113 301 minecraft:magma_block
fill 26 113 302 27 120 302 minecraft:basalt
fill 26 113 308 30 113 308 minecraft:basalt
fill 26 113 311 27 113 311 minecraft:basalt
fill 27 113 288 27 121 289 minecraft:basalt
fill 27 113 299 27 121 301 minecraft:basalt
fill 28 113 291 28 113 297 minecraft:basalt
fill 28 113 301 34 113 301 minecraft:basalt
setblock 29 113 279 minecraft:magma_block
fill 29 113 280 30 113 280 minecraft:basalt
fill 29 113 283 32 113 283 minecraft:basalt
fill 29 113 286 34 113 286 minecraft:basalt
fill 29 113 304 31 114 305 minecraft:basalt
fill 29 113 307 31 113 307 minecraft:basalt
setblock 29 113 309 minecraft:magma_block
setblock 30 113 279 minecraft:basalt
setblock 30 113 309 minecraft:basalt
fill 32 113 284 33 113 284 minecraft:basalt
fill 32 113 288 35 113 288 minecraft:basalt
fill 32 113 291 35 113 291 minecraft:basalt
fill 32 113 294 35 114 294 minecraft:basalt
fill 32 113 297 35 113 297 minecraft:basalt
fill 32 113 300 35 113 300 minecraft:basalt
fill 32 113 304 33 113 304 minecraft:basalt
setblock 32 113 305 minecraft:magma_block
setblock 35 113 278 minecraft:light[level=12]
setblock 35 113 286 minecraft:light[level=12]
setblock 35 113 289 minecraft:magma_block
setblock 35 113 290 minecraft:basalt
setblock 35 113 292 minecraft:magma_block
fill 35 113 293 35 114 293 minecraft:basalt
setblock 35 113 295 minecraft:magma_block
setblock 35 113 296 minecraft:basalt
setblock 35 113 298 minecraft:magma_block
setblock 35 113 299 minecraft:basalt
setblock 35 113 302 minecraft:light[level=12]
setblock 35 113 310 minecraft:light[level=12]
setblock 42 113 281 minecraft:magma_block
setblock 1 114 278 minecraft:magma_block
fill 1 114 279 1 115 284 minecraft:basalt
setblock 1 114 290 minecraft:magma_block
fill 1 114 291 1 122 291 minecraft:basalt
fill 1 114 297 1 122 298 minecraft:basalt
setblock 1 114 299 minecraft:magma_block
fill 1 114 300 2 121 300 minecraft:basalt
fill 1 114 303 1 114 310 minecraft:basalt
fill 2 114 288 2 121 288 minecraft:basalt
fill 3 114 286 3 122 286 minecraft:basalt
setblock 3 114 292 minecraft:light[level=12]
setblock 3 114 299 minecraft:light[level=12]
fill 3 114 302 3 122 302 minecraft:basalt
setblock 3 114 313 minecraft:light[level=12]
setblock 4 114 276 minecraft:basalt
fill 4 114 285 4 122 285 minecraft:basalt
fill 4 114 303 4 122 303 minecraft:basalt
setblock 4 114 312 minecraft:basalt
fill 5 114 284 5 121 284 minecraft:basalt
fill 5 114 304 5 121 305 minecraft:basalt
fill 6 114 282 6 120 283 minecraft:basalt
fill 6 114 305 6 120 306 minecraft:basalt
setblock 7 114 282 minecraft:magma_block
setblock 7 114 306 minecraft:magma_block
fill 8 114 282 8 122 282 minecraft:basalt
fill 8 114 306 8 121 307 minecraft:basalt
setblock 9 114 314 minecraft:basalt
setblock 10 114 281 minecraft:magma_block
setblock 10 114 285 minecraft:light[level=12]
fill 10 114 292 10 115 292 minecraft:red_nether_bricks
setblock 10 114 293 minecraft:nether_wart_block
fill 10 114 295 10 115 295 minecraft:red_nether_bricks
setblock 10 114 296 minecraft:nether_wart_block
fill 10 114 297 10 114 298 minecraft:red_nether_bricks
setblock 10 114 299 minecraft:nether_wart_block
fill 10 114 301 10 115 301 minecraft:red_nether_bricks
setblock 10 114 306 minecraft:light[level=12]
fill 10 114 307 11 122 307 minecraft:basalt
setblock 10 114 314 minecraft:magma_block
setblock 11 114 275 minecraft:crying_obsidian
fill 11 114 280 11 121 281 minecraft:basalt
fill 11 114 289 11 115 289 minecraft:red_nether_bricks
setblock 11 114 290 minecraft:nether_wart_block
fill 11 114 293 11 114 296 minecraft:magma_block
setblock 11 114 302 minecraft:nether_wart_block
fill 11 114 303 11 114 304 minecraft:red_nether_bricks
fill 11 114 314 16 114 314 minecraft:basalt
fill 12 114 280 12 120 280 minecraft:basalt
setblock 12 114 286 minecraft:red_nether_bricks
setblock 12 114 287 minecraft:nether_wart_block
fill 12 114 288 12 117 288 minecraft:red_nether_bricks
fill 12 114 291 12 114 292 minecraft:magma_block
fill 12 114 297 12 114 298 minecraft:magma_block
fill 12 114 301 14 114 303 minecraft:red_nether_bricks
setblock 12 114 305 minecraft:nether_wart_block
fill 12 114 306 19 114 306 minecraft:red_nether_bricks
setblock 13 114 280 minecraft:magma_block
setblock 13 114 290 minecraft:magma_block
setblock 13 114 299 minecraft:magma_block
fill 13 114 305 21 114 305 minecraft:red_nether_bricks
setblock 13 114 307 minecraft:red_nether_bricks
setblock 13 114 315 minecraft:basalt
fill 14 114 280 17 121 280 minecraft:basalt
setblock 14 114 284 minecraft:nether_wart_block
fill 14 114 285 23 114 285 minecraft:red_nether_bricks
fill 14 114 287 15 114 288 minecraft:red_nether_bricks
fill 14 114 289 15 114 289 minecraft:magma_block
setblock 14 114 300 minecraft:magma_block
fill 14 114 304 22 114 304 minecraft:red_nether_bricks
fill 14 114 308 14 121 308 minecraft:basalt
fill 15 114 283 21 114 283 minecraft:red_nether_bricks
fill 15 114 286 24 114 286 minecraft:red_nether_bricks
fill 15 114 301 18 114 301 minecraft:magma_block
fill 15 114 302 23 114 303 minecraft:red_nether_bricks
setblock 15 114 315 minecraft:basalt
fill 16 114 287 25 114 287 minecraft:red_nether_bricks
fill 16 114 288 17 114 288 minecraft:magma_block
setblock 16 114 307 minecraft:red_nether_bricks
fill 17 114 281 18 122 281 minecraft:basalt
fill 17 114 282 19 114 282 minecraft:red_nether_bricks
fill 17 114 284 22 114 284 minecraft:red_nether_bricks
setblock 17 114 292 minecraft:light[level=12]
setblock 17 114 299 minecraft:light[level=12]
fill 17 114 307 18 121 307 minecraft:basalt
fill 18 114 288 25 114 288 minecraft:red_nether_bricks
fill 18 114 289 19 114 289 minecraft:magma_block
setblock 18 114 314 minecraft:basalt
setblock 19 114 281 minecraft:magma_block
setblock 19 114 300 minecraft:magma_block
fill 19 114 301 25 114 301 minecraft:red_nether_bricks
setblock 19 114 314 minecraft:magma_block
fill 20 114 281 20 121 282 minecraft:basalt
fill 20 114 289 26 114 289 minecraft:red_nether_bricks
setblock 20 114 290 minecraft:magma_block
setblock 20 114 299 minecraft:magma_block
fill 20 114 300 25 114 300 minecraft:red_nether_bricks
fill 20 114 306 20 121 306 minecraft:basalt
setblock 20 114 314 minecraft:basalt
fill 20 114 317 20 129 317 minecraft:cobbled_deepslate
fill 21 114 277 26 114 277 minecraft:basalt
fill 21 114 290 26 114 290 minecraft:red_nether_bricks
fill 21 114 291 21 114 293 minecraft:magma_block
fill 21 114 296 21 114 298 minecraft:magma_block
fill 21 114 299 26 114 299 minecraft:red_nether_bricks
fill 21 114 310 27 114 310 minecraft:basalt
setblock 21 114 313 minecraft:basalt
setblock 22 114 283 minecraft:magma_block
fill 22 114 291 26 114 293 minecraft:red_nether_bricks
fill 22 114 294 22 114 295 minecraft:magma_block
fill 22 114 296 26 114 298 minecraft:red_nether_bricks
fill 22 114 305 23 121 305 minecraft:basalt
setblock 22 114 313 minecraft:magma_block
fill 23 114 276 24 114 276 minecraft:basalt
fill 23 114 284 23 121 284 minecraft:basalt
fill 23 114 294 27 114 295 minecraft:red_nether_bricks
fill 23 114 304 23 122 304 minecraft:basalt
fill 23 114 312 23 114 313 minecraft:basalt
fill 24 114 285 24 122 285 minecraft:basalt
setblock 24 114 302 minecraft:red_nether_bricks
fill 24 114 303 24 122 303 minecraft:basalt
setblock 24 114 312 minecraft:basalt
setblock 24 114 313 minecraft:light[level=12]
fill 25 114 286 26 121 286 minecraft:basalt
fill 25 114 302 25 122 302 minecraft:basalt
fill 26 114 278 27 114 278 minecraft:basalt
fill 26 114 281 30 114 281 minecraft:basalt
fill 26 114 288 26 122 288 minecraft:basalt
fill 26 114 300 26 121 301 minecraft:basalt
fill 26 114 308 29 114 308 minecraft:basalt
setblock 26 114 311 minecraft:basalt
fill 27 114 290 27 122 291 minecraft:basalt
fill 27 114 292 27 114 293 minecraft:red_nether_bricks
setblock 27 114 296 minecraft:red_nether_bricks
fill 27 114 297 27 122 298 minecraft:basalt
fill 28 114 291 28 121 292 minecraft:basalt
setblock 28 114 293 minecraft:magma_block
fill 28 114 294 28 122 295 minecraft:basalt
setblock 28 114 296 minecraft:magma_block
fill 28 114 297 28 121 297 minecraft:basalt
fill 28 114 301 33 114 302 minecraft:basalt
setblock 29 114 280 minecraft:basalt
fill 29 114 283 30 115 283 minecraft:basalt
fill 29 114 286 33 114 286 minecraft:basalt
fill 29 114 307 30 114 307 minecraft:basalt
setblock 30 114 317 minecraft:purple_concrete
setblock 31 114 278 minecraft:light[level=12]
setblock 31 114 283 minecraft:magma_block
setblock 31 114 313 minecraft:light[level=12]
fill 32 114 284 32 114 285 minecraft:basalt
fill 32 114 287 33 114 288 minecraft:basalt
fill 32 114 291 33 116 291 minecraft:basalt
fill 32 114 297 33 116 297 minecraft:basalt
fill 32 114 300 33 115 300 minecraft:basalt
fill 32 114 303 32 114 304 minecraft:basalt
setblock 33 114 285 minecraft:basalt
setblock 33 114 303 minecraft:basalt
setblock 34 114 288 minecraft:magma_block
setblock 34 114 291 minecraft:magma_block
setblock 34 114 297 minecraft:magma_block
setblock 34 114 300 minecraft:magma_block
setblock 35 114 295 minecraft:basalt
setblock 38 114 278 minecraft:light[level=12]
setblock 38 114 285 minecraft:light[level=12]
setblock 38 114 292 minecraft:light[level=12]
setblock 38 114 299 minecraft:light[level=12]
setblock 38 114 306 minecraft:light[level=12]
setblock 38 114 313 minecraft:light[level=12]
fill 42 114 281 42 129 281 minecraft:cobbled_deepslate
fill 1 115 290 2 115 290 minecraft:basalt
fill 1 115 292 1 122 296 minecraft:basalt
fill 1 115 299 2 122 299 minecraft:basalt
fill 1 115 303 1 115 309 minecraft:basalt
fill 2 115 289 2 123 289 minecraft:basalt
fill 2 115 298 2 123 298 minecraft:basalt
fill 3 115 287 3 123 287 minecraft:basalt
fill 3 115 301 3 123 301 minecraft:basalt
fill 4 115 277 10 115 277 minecraft:basalt
fill 4 115 286 4 122 286 minecraft:basalt
fill 4 115 302 4 123 302 minecraft:basalt
setblock 4 115 311 minecraft:basalt
fill 5 115 285 5 123 285 minecraft:basalt
fill 5 115 303 5 123 303 minecraft:basalt
setblock 6 115 284 minecraft:magma_block
fill 6 115 304 6 123 304 minecraft:basalt
fill 7 115 282 7 122 283 minecraft:basalt
fill 7 115 305 7 122 306 minecraft:basalt
setblock 8 115 313 minecraft:basalt
fill 9 115 282 10 123 282 minecraft:basalt
fill 9 115 306 10 123 306 minecraft:basalt
setblock 9 115 313 minecraft:magma_block
fill 10 115 281 10 122 281 minecraft:basalt
setblock 10 115 291 minecraft:nether_wart_block
fill 10 115 293 11 116 293 minecraft:red_nether_bricks
setblock 10 115 294 minecraft:nether_wart_block
fill 10 115 296 10 116 296 minecraft:red_nether_bricks
setblock 10 115 297 minecraft:nether_wart_block
fill 10 115 298 10 115 299 minecraft:red_nether_bricks
setblock 10 115 300 minecraft:nether_wart_block
setblock 10 115 313 minecraft:basalt
fill 10 115 314 11 116 314 minecraft:polished_blackstone
fill 11 115 275 11 125 275 minecraft:cobbled_deepslate
setblock 11 115 288 minecraft:nether_wart_block
fill 11 115 290 11 116 290 minecraft:red_nether_bricks
fill 11 115 294 11 115 296 minecraft:red_terracotta
fill 11 115 302 15 115 302 minecraft:red_nether_bricks
setblock 11 115 303 minecraft:nether_wart_block
setblock 11 115 304 minecraft:red_nether_bricks
fill 12 115 281 14 123 281 minecraft:basalt
fill 12 115 287 24 115 287 minecraft:red_nether_bricks
fill 12 115 291 12 115 293 minecraft:red_terracotta
fill 12 115 297 12 116 298 minecraft:red_terracotta
fill 12 115 301 13 118 301 minecraft:red_nether_bricks
fill 12 115 303 22 115 303 minecraft:red_nether_bricks
fill 12 115 305 20 115 305 minecraft:red_nether_bricks
fill 12 115 307 16 122 307 minecraft:basalt
fill 12 115 313 14 115 314 minecraft:basalt
fill 13 115 280 13 122 280 minecraft:basalt
setblock 13 115 285 minecraft:nether_wart_block
setblock 13 115 286 minecraft:red_nether_bricks
fill 13 115 290 13 116 290 minecraft:red_terracotta
fill 13 115 299 13 116 300 minecraft:red_terracotta
setblock 13 115 306 minecraft:nether_wart_block
fill 14 115 284 14 115 285 minecraft:red_nether_bricks
fill 14 115 288 14 120 288 minecraft:red_nether_bricks
fill 14 115 289 14 116 289 minecraft:red_terracotta
fill 14 115 301 15 115 301 minecraft:red_terracotta
fill 14 115 304 21 115 304 minecraft:red_nether_bricks
fill 14 115 306 17 115 306 minecraft:red_nether_bricks
fill 15 115 276 20 116 276 minecraft:basalt
setblock 15 115 281 minecraft:magma_block
fill 15 115 283 20 115 283 minecraft:red_nether_bricks
fill 15 115 285 22 115 286 minecraft:red_nether_bricks
fill 15 115 288 18 116 288 minecraft:red_terracotta
fill 15 115 312 17 116 313 minecraft:basalt
setblock 15 115 314 minecraft:magma_block
fill 16 115 281 16 123 281 minecraft:basalt
fill 16 115 302 18 116 302 minecraft:red_terracotta
setblock 16 115 314 minecraft:basalt
setblock 17 115 282 minecraft:nether_wart_block
fill 17 115 284 21 115 284 minecraft:red_nether_bricks
fill 18 115 282 19 123 282 minecraft:basalt
fill 18 115 306 19 123 306 minecraft:basalt
fill 18 115 311 20 116 312 minecraft:basalt
setblock 18 115 313 minecraft:magma_block
fill 19 115 281 19 122 281 minecraft:basalt
fill 19 115 288 25 115 288 minecraft:red_nether_bricks
fill 19 115 289 20 115 289 minecraft:red_terracotta
setblock 19 115 301 minecraft:red_terracotta
fill 19 115 302 23 115 302 minecraft:red_nether_bricks
setblock 19 115 313 minecraft:basalt
setblock 20 115 300 minecraft:red_terracotta
fill 20 115 301 24 115 301 minecraft:red_nether_bricks
setblock 21 115 276 minecraft:magma_block
fill 21 115 277 24 115 277 minecraft:basalt
fill 21 115 283 22 122 283 minecraft:basalt
fill 21 115 289 25 115 289 minecraft:red_nether_bricks
fill 21 115 290 21 115 291 minecraft:red_terracotta
setblock 21 115 299 minecraft:red_terracotta
fill 21 115 300 25 115 300 minecraft:red_nether_bricks
fill 21 115 305 21 123 305 minecraft:basalt
fill 21 115 310 23 116 311 minecraft:basalt
setblock 21 115 312 minecraft:magma_block
fill 22 115 276 23 115 276 minecraft:basalt
fill 22 115 284 22 123 284 minecraft:basalt
fill 22 115 290 25 115 291 minecraft:red_nether_bricks
fill 22 115 292 22 115 298 minecraft:red_terracotta
fill 22 115 299 25 115 299 minecraft:red_nether_bricks
fill 22 115 304 22 122 304 minecraft:basalt
fill 22 115 312 23 115 312 minecraft:basalt
schedule function dropper:buildpart/60_2 1t
