setblock 4 142 646 minecraft:white_concrete
fill 6 142 646 6 170 646 minecraft:black_concrete
setblock 7 142 646 minecraft:glowstone
fill 9 142 631 10 143 631 minecraft:moss_block
fill 18 142 611 18 145 611 minecraft:dirt
fill 18 142 615 18 145 615 minecraft:dirt
fill 20 142 635 20 147 637 minecraft:dirt
fill 21 142 604 22 170 604 minecraft:black_concrete
fill 22 142 611 22 145 611 minecraft:dirt
fill 22 142 615 22 145 615 minecraft:dirt
fill 23 142 635 23 147 637 minecraft:dirt
fill 24 142 616 25 143 616 minecraft:stone
setblock 25 142 646 minecraft:glowstone
fill 26 142 646 27 166 646 minecraft:black_concrete
fill 37 142 646 37 151 646 minecraft:black_concrete
fill 42 142 631 42 146 631 minecraft:black_concrete
fill 4 143 646 4 148 646 minecraft:black_concrete
setblock 7 143 646 minecraft:black_concrete
fill 17 143 612 17 145 614 minecraft:dirt
fill 19 143 610 21 145 610 minecraft:dirt
fill 19 143 616 21 145 616 minecraft:dirt
setblock 20 143 646 minecraft:diamond_block
fill 21 143 634 22 147 634 minecraft:dirt
fill 21 143 638 22 147 638 minecraft:dirt
fill 23 143 612 23 145 614 minecraft:dirt
fill 25 143 646 25 168 646 minecraft:black_concrete
fill 29 143 616 29 149 616 minecraft:dirt
setblock 38 143 604 minecraft:glowstone
setblock 0 144 627 minecraft:diamond_block
setblock 7 144 646 minecraft:glowstone
setblock 15 144 646 minecraft:diamond_block
setblock 16 144 604 minecraft:diamond_block
fill 16 144 646 20 146 646 minecraft:black_concrete
fill 17 144 611 17 145 611 minecraft:dirt
fill 17 144 615 17 145 615 minecraft:dirt
fill 18 144 610 18 145 610 minecraft:dirt
fill 18 144 616 18 145 616 minecraft:dirt
fill 19 144 635 19 147 637 minecraft:dirt
fill 20 144 634 20 147 634 minecraft:dirt
fill 20 144 638 20 147 638 minecraft:dirt
fill 22 144 610 22 145 610 minecraft:dirt
fill 22 144 616 22 145 616 minecraft:dirt
fill 23 144 611 23 145 611 minecraft:dirt
fill 23 144 615 23 145 615 minecraft:dirt
fill 23 144 634 23 147 634 minecraft:dirt
fill 23 144 638 23 147 638 minecraft:dirt
fill 24 144 606 25 145 607 minecraft:stone
fill 24 144 635 24 147 637 minecraft:dirt
fill 24 144 638 26 144 638 minecraft:coal_block
fill 25 144 637 25 145 637 minecraft:coal_block
fill 25 144 639 25 145 639 minecraft:coal_block
fill 29 144 617 29 149 617 minecraft:dirt
fill 38 144 604 38 171 604 minecraft:black_concrete
setblock 42 144 622 minecraft:glowstone
fill 0 145 612 0 146 612 minecraft:moss_block
fill 0 145 627 0 166 627 minecraft:black_concrete
fill 0 145 628 0 146 628 minecraft:moss_block
fill 0 145 644 0 146 644 minecraft:moss_block
fill 4 145 604 4 146 604 minecraft:moss_block
fill 7 145 646 7 170 646 minecraft:black_concrete
fill 14 145 646 14 146 646 minecraft:moss_block
fill 15 145 646 15 170 646 minecraft:black_concrete
fill 16 145 604 16 170 604 minecraft:black_concrete
fill 16 145 612 16 145 614 minecraft:dirt
setblock 17 145 610 minecraft:dirt
setblock 17 145 616 minecraft:dirt
fill 19 145 609 21 145 609 minecraft:dirt
fill 19 145 617 21 145 617 minecraft:dirt
fill 19 145 634 19 147 634 minecraft:dirt
fill 19 145 638 19 147 638 minecraft:dirt
fill 20 145 604 20 146 604 minecraft:moss_block
fill 21 145 633 22 147 633 minecraft:dirt
fill 21 145 639 22 147 639 minecraft:dirt
setblock 23 145 610 minecraft:dirt
setblock 23 145 616 minecraft:dirt
fill 24 145 612 24 145 614 minecraft:dirt
fill 24 145 634 24 147 634 minecraft:dirt
fill 24 145 638 24 147 638 minecraft:dirt
fill 25 145 638 26 145 638 minecraft:coal_block
fill 28 145 616 28 149 616 minecraft:dirt
fill 30 145 616 30 149 617 minecraft:dirt
fill 30 145 646 30 146 646 minecraft:moss_block
setblock 34 145 604 minecraft:white_concrete
fill 36 145 604 36 146 604 minecraft:moss_block
fill 42 145 614 42 146 614 minecraft:moss_block
fill 42 145 622 42 148 622 minecraft:black_concrete
fill 42 145 630 42 146 630 minecraft:moss_block
setblock 1 146 604 minecraft:white_concrete
fill 18 146 635 18 147 637 minecraft:dirt
fill 20 146 613 20 149 613 minecraft:stone
fill 20 146 633 20 147 633 minecraft:dirt
fill 20 146 639 20 147 639 minecraft:dirt
fill 23 146 633 23 147 633 minecraft:dirt
fill 23 146 639 23 147 639 minecraft:dirt
setblock 24 146 604 minecraft:glowstone
fill 25 146 635 25 147 637 minecraft:dirt
fill 28 146 615 30 149 615 minecraft:dirt
fill 28 146 617 28 149 617 minecraft:dirt
fill 34 146 604 34 170 604 minecraft:black_concrete
setblock 42 146 607 minecraft:white_concrete
setblock 42 146 626 minecraft:white_concrete
setblock 0 147 605 minecraft:diamond_block
fill 0 147 612 0 153 612 minecraft:black_concrete
setblock 0 147 628 minecraft:black_concrete
fill 0 147 644 0 153 644 minecraft:black_concrete
fill 1 147 604 1 170 604 minecraft:black_concrete
setblock 3 147 607 minecraft:light[level=14]
setblock 3 147 615 minecraft:light[level=14]
setblock 3 147 623 minecraft:light[level=14]
setblock 3 147 631 minecraft:light[level=14]
setblock 3 147 639 minecraft:light[level=14]
fill 4 147 604 4 153 604 minecraft:black_concrete
setblock 11 147 604 minecraft:white_concrete
setblock 11 147 607 minecraft:light[level=14]
setblock 11 147 615 minecraft:light[level=14]
setblock 11 147 623 minecraft:light[level=14]
setblock 11 147 631 minecraft:light[level=14]
setblock 11 147 639 minecraft:light[level=14]
fill 14 147 646 14 153 646 minecraft:black_concrete
fill 16 147 646 17 168 646 minecraft:black_concrete
setblock 18 147 634 minecraft:dirt
setblock 18 147 638 minecraft:dirt
setblock 18 147 646 minecraft:glowstone
setblock 19 147 607 minecraft:light[level=14]
setblock 19 147 615 minecraft:light[level=14]
setblock 19 147 623 minecraft:light[level=14]
setblock 19 147 631 minecraft:light[level=14]
setblock 19 147 633 minecraft:dirt
setblock 19 147 639 minecraft:dirt
fill 19 147 646 20 154 646 minecraft:black_concrete
fill 20 147 604 20 153 604 minecraft:black_concrete
fill 20 147 640 22 147 640 minecraft:dirt
fill 21 147 632 22 147 632 minecraft:dirt
fill 24 147 604 24 168 604 minecraft:black_concrete
setblock 24 147 633 minecraft:dirt
setblock 24 147 639 minecraft:dirt
setblock 25 147 634 minecraft:dirt
setblock 25 147 638 minecraft:dirt
setblock 27 147 607 minecraft:light[level=14]
setblock 27 147 615 minecraft:light[level=14]
fill 27 147 616 27 149 616 minecraft:dirt
setblock 27 147 623 minecraft:light[level=14]
setblock 27 147 631 minecraft:light[level=14]
setblock 27 147 639 minecraft:light[level=14]
fill 28 147 618 30 149 618 minecraft:dirt
fill 30 147 646 30 153 646 minecraft:black_concrete
fill 31 147 616 31 149 617 minecraft:dirt
setblock 35 147 607 minecraft:light[level=14]
setblock 35 147 615 minecraft:light[level=14]
setblock 35 147 623 minecraft:light[level=14]
setblock 35 147 631 minecraft:light[level=14]
setblock 35 147 639 minecraft:light[level=14]
fill 36 147 604 36 153 604 minecraft:black_concrete
setblock 41 147 604 minecraft:white_concrete
fill 42 147 604 42 166 604 minecraft:black_concrete
fill 42 147 607 42 168 607 minecraft:black_concrete
fill 42 147 614 42 153 614 minecraft:black_concrete
fill 42 147 626 42 149 626 minecraft:black_concrete
fill 42 147 630 42 153 630 minecraft:black_concrete
setblock 42 147 631 minecraft:white_concrete
fill 0 148 605 0 150 605 minecraft:black_concrete
setblock 0 148 626 minecraft:white_concrete
setblock 0 148 628 minecraft:white_concrete
fill 11 148 604 11 171 604 minecraft:black_concrete
setblock 15 148 604 minecraft:glowstone
fill 18 148 646 18 166 646 minecraft:black_concrete
fill 21 148 636 22 150 636 minecraft:stone
fill 27 148 615 27 149 615 minecraft:dirt
fill 27 148 617 27 149 617 minecraft:dirt
fill 28 148 614 30 149 614 minecraft:dirt
fill 31 148 615 31 149 615 minecraft:dirt
setblock 33 148 604 minecraft:diamond_block
fill 41 148 604 41 167 604 minecraft:black_concrete
setblock 42 148 618 minecraft:diamond_block
fill 42 148 631 42 170 631 minecraft:black_concrete
fill 0 149 626 0 151 626 minecraft:black_concrete
fill 0 149 628 0 153 628 minecraft:black_concrete
setblock 4 149 646 minecraft:diamond_block
setblock 12 149 604 minecraft:glowstone
fill 15 149 604 15 170 604 minecraft:black_concrete
fill 19 149 612 19 151 614 minecraft:oak_leaves[persistent=true]
fill 20 149 611 20 151 612 minecraft:oak_leaves[persistent=true]
fill 20 149 614 21 151 614 minecraft:oak_leaves[persistent=true]
fill 21 149 612 21 151 613 minecraft:oak_leaves[persistent=true]
setblock 21 149 646 minecraft:diamond_block
fill 22 149 613 22 151 613 minecraft:oak_leaves[persistent=true]
setblock 27 149 618 minecraft:dirt
fill 28 149 619 30 149 619 minecraft:dirt
setblock 31 149 614 minecraft:dirt
setblock 31 149 618 minecraft:dirt
setblock 32 149 616 minecraft:dirt
fill 33 149 604 33 166 604 minecraft:black_concrete
setblock 39 149 604 minecraft:diamond_block
fill 42 149 618 42 170 618 minecraft:black_concrete
setblock 42 149 622 minecraft:white_concrete
setblock 42 149 633 minecraft:white_concrete
fill 1 150 646 2 153 646 minecraft:black_concrete
setblock 3 150 646 minecraft:diamond_block
fill 4 150 646 4 170 646 minecraft:black_concrete
fill 12 150 604 12 170 604 minecraft:black_concrete
fill 18 150 612 18 150 614 minecraft:oak_leaves[persistent=true]
setblock 19 150 611 minecraft:oak_leaves[persistent=true]
fill 19 150 615 21 150 615 minecraft:oak_leaves[persistent=true]
fill 20 150 613 20 151 613 minecraft:oak_leaves[persistent=true]
setblock 21 150 611 minecraft:oak_leaves[persistent=true]
fill 21 150 646 21 166 646 minecraft:black_concrete
setblock 22 150 612 minecraft:oak_leaves[persistent=true]
setblock 22 150 614 minecraft:oak_leaves[persistent=true]
fill 29 150 616 29 153 616 minecraft:stone
fill 39 150 604 39 167 604 minecraft:black_concrete
fill 42 150 622 42 170 622 minecraft:black_concrete
setblock 42 150 626 minecraft:diamond_block
fill 42 150 633 42 170 633 minecraft:black_concrete
setblock 0 151 605 minecraft:glowstone
setblock 0 151 606 minecraft:white_concrete
fill 3 151 646 3 155 646 minecraft:black_concrete
setblock 9 151 604 minecraft:glowstone
setblock 10 151 646 minecraft:white_concrete
fill 11 151 644 13 154 644 minecraft:diamond_block
fill 12 151 643 12 154 643 minecraft:diamond_block
fill 12 151 645 12 154 645 minecraft:diamond_block
fill 20 151 635 23 153 637 minecraft:oak_leaves[persistent=true]
fill 42 151 626 42 167 626 minecraft:black_concrete
fill 0 152 605 0 167 606 minecraft:black_concrete
setblock 0 152 626 minecraft:white_concrete
fill 9 152 604 9 171 604 minecraft:black_concrete
setblock 10 152 604 minecraft:white_concrete
fill 10 152 646 10 170 646 minecraft:black_concrete
fill 11 152 643 11 154 643 minecraft:diamond_block
fill 11 152 645 11 153 645 minecraft:diamond_block
fill 12 152 642 12 155 642 minecraft:diamond_block
fill 13 152 643 13 154 643 minecraft:diamond_block
fill 13 152 645 13 153 645 minecraft:diamond_block
fill 21 152 634 22 152 634 minecraft:oak_leaves[persistent=true]
fill 21 152 638 22 152 638 minecraft:oak_leaves[persistent=true]
setblock 32 152 646 minecraft:glowstone
setblock 37 152 646 minecraft:diamond_block
setblock 42 152 612 minecraft:diamond_block
fill 0 153 626 0 170 626 minecraft:black_concrete
fill 10 153 604 10 170 604 minecraft:black_concrete
fill 11 153 642 11 154 642 minecraft:diamond_block
fill 12 153 641 12 155 641 minecraft:diamond_block
fill 13 153 642 13 154 642 minecraft:diamond_block
fill 28 153 615 28 155 617 minecraft:oak_leaves[persistent=true]
fill 29 153 615 30 155 615 minecraft:oak_leaves[persistent=true]
fill 29 153 617 29 155 618 minecraft:oak_leaves[persistent=true]
fill 30 153 616 30 155 617 minecraft:oak_leaves[persistent=true]
fill 31 153 616 31 155 616 minecraft:oak_leaves[persistent=true]
setblock 32 153 646 minecraft:black_concrete
fill 37 153 646 37 171 646 minecraft:black_concrete
fill 42 153 612 42 170 612 minecraft:black_concrete
fill 0 154 612 0 155 612 minecraft:moss_block
fill 0 154 619 0 166 619 minecraft:black_concrete
setblock 0 154 620 minecraft:white_concrete
fill 0 154 628 0 155 628 minecraft:moss_block
fill 0 154 644 0 155 644 minecraft:moss_block
setblock 1 154 646 minecraft:glowstone
fill 2 154 646 2 170 646 minecraft:black_concrete
fill 4 154 604 4 155 604 minecraft:moss_block
setblock 11 154 641 minecraft:diamond_block
fill 12 154 640 12 155 640 minecraft:diamond_block
setblock 13 154 641 minecraft:diamond_block
fill 14 154 646 14 155 646 minecraft:moss_block
fill 20 154 604 20 155 604 minecraft:moss_block
fill 27 154 615 27 154 617 minecraft:oak_leaves[persistent=true]
setblock 28 154 618 minecraft:oak_leaves[persistent=true]
setblock 29 154 614 minecraft:oak_leaves[persistent=true]
fill 29 154 616 29 155 616 minecraft:oak_leaves[persistent=true]
setblock 30 154 618 minecraft:oak_leaves[persistent=true]
fill 30 154 646 30 155 646 minecraft:moss_block
setblock 31 154 615 minecraft:oak_leaves[persistent=true]
setblock 31 154 617 minecraft:oak_leaves[persistent=true]
setblock 32 154 646 minecraft:diamond_block
fill 36 154 604 36 155 604 minecraft:moss_block
fill 42 154 614 42 155 614 minecraft:moss_block
fill 42 154 630 42 155 630 minecraft:moss_block
setblock 0 155 609 minecraft:glowstone
fill 0 155 620 0 161 620 minecraft:black_concrete
fill 1 155 646 1 170 646 minecraft:black_concrete
setblock 3 155 607 minecraft:light[level=14]
setblock 3 155 615 minecraft:light[level=14]
setblock 3 155 623 minecraft:light[level=14]
setblock 3 155 631 minecraft:light[level=14]
setblock 3 155 639 minecraft:light[level=14]
setblock 11 155 607 minecraft:light[level=14]
setblock 11 155 615 minecraft:light[level=14]
setblock 11 155 623 minecraft:light[level=14]
setblock 11 155 631 minecraft:light[level=14]
setblock 11 155 639 minecraft:light[level=14]
setblock 12 155 639 minecraft:diamond_block
setblock 19 155 607 minecraft:light[level=14]
setblock 19 155 615 minecraft:light[level=14]
setblock 19 155 623 minecraft:light[level=14]
setblock 19 155 631 minecraft:light[level=14]
setblock 19 155 639 minecraft:light[level=14]
fill 19 155 646 19 161 646 minecraft:black_concrete
setblock 20 155 646 minecraft:diamond_block
setblock 27 155 607 minecraft:light[level=14]
setblock 27 155 615 minecraft:light[level=14]
setblock 27 155 623 minecraft:light[level=14]
setblock 27 155 631 minecraft:light[level=14]
setblock 27 155 639 minecraft:light[level=14]
fill 32 155 646 32 170 646 minecraft:black_concrete
setblock 35 155 607 minecraft:light[level=14]
setblock 35 155 615 minecraft:light[level=14]
setblock 35 155 623 minecraft:light[level=14]
setblock 35 155 631 minecraft:light[level=14]
setblock 35 155 639 minecraft:light[level=14]
setblock 42 155 627 minecraft:glowstone
fill 0 156 609 0 166 609 minecraft:black_concrete
fill 0 156 612 0 161 612 minecraft:black_concrete
setblock 0 156 622 minecraft:white_concrete
fill 0 156 623 0 170 623 minecraft:black_concrete
fill 0 156 628 0 161 628 minecraft:black_concrete
fill 0 156 644 0 161 644 minecraft:black_concrete
setblock 3 156 646 minecraft:white_concrete
setblock 4 156 604 minecraft:black_concrete
setblock 12 156 646 minecraft:white_concrete
fill 14 156 646 14 161 646 minecraft:black_concrete
fill 20 156 604 20 161 604 minecraft:black_concrete
fill 20 156 646 20 168 646 minecraft:black_concrete
fill 30 156 646 30 161 646 minecraft:black_concrete
fill 36 156 604 36 158 604 minecraft:black_concrete
fill 42 156 614 42 161 614 minecraft:black_concrete
fill 42 156 627 42 170 627 minecraft:black_concrete
fill 42 156 630 42 161 630 minecraft:black_concrete
setblock 42 156 637 minecraft:diamond_block
setblock 42 156 639 minecraft:glowstone
setblock 0 157 613 minecraft:diamond_block
setblock 0 157 621 minecraft:diamond_block
fill 0 157 622 0 170 622 minecraft:black_concrete
fill 3 157 646 3 160 646 minecraft:black_concrete
setblock 4 157 604 minecraft:white_concrete
fill 12 157 646 12 170 646 minecraft:black_concrete
fill 42 157 637 42 170 637 minecraft:black_concrete
fill 42 157 639 42 164 639 minecraft:black_concrete
setblock 0 158 611 minecraft:diamond_block
fill 0 158 613 0 170 613 minecraft:black_concrete
fill 0 158 621 0 168 621 minecraft:black_concrete
fill 4 158 604 4 161 604 minecraft:black_concrete
fill 17 158 637 17 159 638 minecraft:moss_block
setblock 22 158 646 minecraft:glowstone
setblock 41 158 646 minecraft:glowstone
fill 0 159 611 0 165 611 minecraft:black_concrete
fill 11 159 618 11 160 618 minecraft:dirt
fill 22 159 646 22 166 646 minecraft:black_concrete
fill 36 159 604 36 160 604 minecraft:glowstone
fill 41 159 646 41 166 646 minecraft:black_concrete
setblock 42 159 629 minecraft:diamond_block
setblock 42 159 643 minecraft:diamond_block
fill 42 160 629 42 171 629 minecraft:black_concrete
fill 42 160 643 42 170 643 minecraft:black_concrete
setblock 3 161 646 minecraft:white_concrete
fill 22 161 633 22 162 633 minecraft:stone
setblock 36 161 604 minecraft:black_concrete
setblock 37 161 604 minecraft:white_concrete
setblock 42 161 641 minecraft:white_concrete
fill 0 162 612 0 164 612 minecraft:moss_block
setblock 0 162 618 minecraft:glowstone
setblock 0 162 620 minecraft:white_concrete
fill 0 162 628 0 164 628 minecraft:moss_block
setblock 0 162 629 minecraft:diamond_block
fill 0 162 644 0 164 644 minecraft:moss_block
fill 3 162 646 3 170 646 minecraft:black_concrete
fill 4 162 604 4 164 604 minecraft:moss_block
fill 14 162 646 14 164 646 minecraft:moss_block
fill 15 162 631 16 163 631 minecraft:coal_block
setblock 19 162 646 minecraft:glowstone
fill 20 162 604 20 164 604 minecraft:moss_block
fill 30 162 646 30 164 646 minecraft:moss_block
fill 31 162 604 31 171 604 minecraft:black_concrete
setblock 32 162 604 minecraft:diamond_block
fill 36 162 604 36 164 604 minecraft:moss_block
fill 37 162 604 37 170 604 minecraft:black_concrete
fill 42 162 614 42 164 614 minecraft:moss_block
fill 42 162 630 42 164 630 minecraft:moss_block
fill 42 162 641 42 170 641 minecraft:black_concrete
fill 0 163 618 0 170 618 minecraft:black_concrete
fill 0 163 620 0 165 620 minecraft:black_concrete
fill 0 163 629 0 168 629 minecraft:black_concrete
setblock 3 163 607 minecraft:light[level=14]
setblock 3 163 615 minecraft:light[level=14]
setblock 3 163 623 minecraft:light[level=14]
setblock 3 163 631 minecraft:light[level=14]
setblock 3 163 639 minecraft:light[level=14]
setblock 5 163 604 minecraft:glowstone
fill 6 163 604 6 170 604 minecraft:black_concrete
setblock 11 163 607 minecraft:light[level=14]
setblock 11 163 615 minecraft:light[level=14]
setblock 11 163 623 minecraft:light[level=14]
setblock 11 163 631 minecraft:light[level=14]
setblock 11 163 639 minecraft:light[level=14]
setblock 19 163 607 minecraft:light[level=14]
setblock 19 163 615 minecraft:light[level=14]
setblock 19 163 623 minecraft:light[level=14]
setblock 19 163 631 minecraft:light[level=14]
setblock 19 163 639 minecraft:light[level=14]
fill 19 163 646 19 168 646 minecraft:black_concrete
setblock 27 163 607 minecraft:light[level=14]
setblock 27 163 615 minecraft:light[level=14]
setblock 27 163 623 minecraft:light[level=14]
setblock 27 163 631 minecraft:light[level=14]
setblock 27 163 639 minecraft:light[level=14]
fill 32 163 604 32 166 604 minecraft:black_concrete
setblock 35 163 607 minecraft:light[level=14]
setblock 35 163 615 minecraft:light[level=14]
setblock 35 163 623 minecraft:light[level=14]
setblock 35 163 631 minecraft:light[level=14]
setblock 35 163 639 minecraft:light[level=14]
setblock 5 164 604 minecraft:black_concrete
fill 36 164 629 38 165 629 minecraft:moss_block
fill 37 164 628 37 165 628 minecraft:moss_block
fill 37 164 630 37 165 630 minecraft:moss_block
fill 0 165 612 0 170 612 minecraft:black_concrete
fill 0 165 628 0 170 628 minecraft:black_concrete
fill 0 165 644 0 166 644 minecraft:black_concrete
fill 4 165 604 4 167 604 minecraft:black_concrete
setblock 5 165 604 minecraft:white_concrete
fill 14 165 646 14 170 646 minecraft:black_concrete
fill 20 165 604 20 170 604 minecraft:black_concrete
fill 30 165 646 30 166 646 minecraft:black_concrete
fill 36 165 604 36 166 604 minecraft:black_concrete
fill 42 165 614 42 166 614 minecraft:black_concrete
fill 42 165 630 42 166 630 minecraft:black_concrete
setblock 42 165 639 minecraft:white_concrete
setblock 0 166 611 minecraft:glowstone
setblock 0 166 620 minecraft:glowstone
fill 5 166 604 5 170 604 minecraft:black_concrete
fill 8 166 613 9 167 613 minecraft:raw_iron_block
setblock 40 166 646 minecraft:white_concrete
fill 42 166 639 42 170 639 minecraft:black_concrete
fill 0 167 604 0 168 604 minecraft:blue_concrete
setblock 0 167 609 minecraft:blue_concrete
setblock 0 167 611 minecraft:black_concrete
setblock 0 167 619 minecraft:blue_concrete
fill 0 167 620 0 170 620 minecraft:black_concrete
setblock 0 167 627 minecraft:blue_concrete
setblock 0 167 632 minecraft:blue_concrete
setblock 0 167 635 minecraft:glowstone
fill 0 167 636 0 168 636 minecraft:blue_concrete
fill 0 167 637 0 170 637 minecraft:black_concrete
fill 0 167 641 0 168 641 minecraft:blue_concrete
setblock 0 167 644 minecraft:blue_concrete
setblock 5 167 646 minecraft:blue_concrete
setblock 13 167 646 minecraft:blue_concrete
setblock 18 167 646 minecraft:white_concrete
fill 21 167 646 22 167 646 minecraft:blue_concrete
setblock 24 167 646 minecraft:diamond_block
fill 26 167 646 26 170 646 minecraft:black_concrete
setblock 27 167 646 minecraft:blue_concrete
setblock 30 167 646 minecraft:white_concrete
fill 32 167 604 33 167 604 minecraft:blue_concrete
setblock 33 167 646 minecraft:blue_concrete
fill 35 167 604 36 167 604 minecraft:blue_concrete
fill 40 167 646 40 168 646 minecraft:black_concrete
setblock 41 167 646 minecraft:blue_concrete
setblock 42 167 604 minecraft:blue_concrete
setblock 42 167 606 minecraft:blue_concrete
setblock 42 167 610 minecraft:blue_concrete
setblock 42 167 614 minecraft:blue_concrete
setblock 42 167 630 minecraft:blue_concrete
setblock 42 167 640 minecraft:blue_concrete
setblock 42 167 644 minecraft:blue_concrete
fill 0 168 605 0 170 605 minecraft:black_concrete
setblock 0 168 606 minecraft:blue_concrete
fill 0 168 609 0 170 609 minecraft:black_concrete
setblock 0 168 611 minecraft:blue_concrete
setblock 0 168 616 minecraft:blue_concrete
fill 0 168 619 0 171 619 minecraft:black_concrete
fill 0 168 627 0 170 627 minecraft:black_concrete
fill 0 168 632 0 170 632 minecraft:black_concrete
fill 0 168 634 0 169 634 minecraft:blue_concrete
fill 0 168 635 0 170 635 minecraft:black_concrete
fill 0 168 639 0 170 639 minecraft:black_concrete
setblock 0 168 640 minecraft:white_concrete
fill 0 168 644 0 170 644 minecraft:black_concrete
setblock 4 168 604 minecraft:blue_concrete
fill 5 168 646 5 170 646 minecraft:black_concrete
fill 13 168 646 13 170 646 minecraft:black_concrete
fill 18 168 646 18 170 646 minecraft:black_concrete
fill 21 168 646 22 168 646 minecraft:black_concrete
fill 24 168 646 24 170 646 minecraft:black_concrete
fill 25 168 604 26 170 604 minecraft:black_concrete
setblock 27 168 604 minecraft:blue_concrete
setblock 27 168 646 minecraft:glowstone
fill 28 168 604 28 170 604 minecraft:black_concrete
setblock 30 168 646 minecraft:black_concrete
fill 32 168 604 33 170 604 minecraft:black_concrete
fill 33 168 646 33 170 646 minecraft:black_concrete
fill 35 168 604 36 169 604 minecraft:black_concrete
setblock 39 168 604 minecraft:blue_concrete
fill 41 168 604 41 169 604 minecraft:blue_concrete
fill 41 168 646 41 170 646 minecraft:black_concrete
fill 42 168 604 42 170 604 minecraft:black_concrete
fill 42 168 606 42 170 606 minecraft:black_concrete
fill 42 168 610 42 170 610 minecraft:black_concrete
setblock 42 168 613 minecraft:blue_concrete
setblock 42 168 614 minecraft:black_concrete
setblock 42 168 615 minecraft:blue_concrete
setblock 42 168 626 minecraft:blue_concrete
fill 42 168 630 42 170 630 minecraft:black_concrete
fill 42 168 640 42 170 640 minecraft:black_concrete
fill 42 168 644 42 170 644 minecraft:black_concrete
fill 0 169 604 0 170 604 minecraft:black_concrete
fill 0 169 606 0 170 606 minecraft:black_concrete
fill 0 169 611 0 170 611 minecraft:black_concrete
fill 0 169 616 0 170 616 minecraft:black_concrete
setblock 0 169 621 minecraft:blue_concrete
setblock 0 169 629 minecraft:blue_concrete
setblock 0 169 633 minecraft:white_concrete
fill 0 169 636 0 170 636 minecraft:black_concrete
fill 0 169 640 0 170 641 minecraft:black_concrete
fill 4 169 604 4 170 604 minecraft:black_concrete
setblock 13 169 604 minecraft:blue_concrete
fill 16 169 646 16 170 646 minecraft:black_concrete
setblock 17 169 604 minecraft:blue_concrete
setblock 17 169 646 minecraft:blue_concrete
fill 19 169 646 20 169 646 minecraft:blue_concrete
fill 21 169 646 21 170 646 minecraft:black_concrete
setblock 22 169 646 minecraft:blue_concrete
setblock 24 169 604 minecraft:blue_concrete
setblock 25 169 646 minecraft:blue_concrete
fill 27 169 604 27 170 604 minecraft:black_concrete
setblock 27 169 646 minecraft:black_concrete
setblock 30 169 646 minecraft:blue_concrete
fill 39 169 604 39 171 604 minecraft:black_concrete
setblock 40 169 604 minecraft:white_concrete
setblock 40 169 646 minecraft:white_concrete
setblock 42 169 607 minecraft:blue_concrete
fill 42 169 613 42 170 613 minecraft:black_concrete
setblock 42 169 614 minecraft:blue_concrete
fill 42 169 615 42 170 615 minecraft:black_concrete
fill 42 169 626 42 170 626 minecraft:black_concrete
setblock 42 169 628 minecraft:blue_concrete
setblock 0 170 610 minecraft:glowstone
setblock 0 170 614 minecraft:white_concrete
setblock 0 170 621 minecraft:black_concrete
fill 0 170 629 0 172 629 minecraft:black_concrete
fill 0 170 633 0 170 634 minecraft:black_concrete
setblock 13 170 604 minecraft:black_concrete
setblock 17 170 604 minecraft:black_concrete
setblock 17 170 646 minecraft:black_concrete
fill 19 170 646 20 170 646 minecraft:black_concrete
setblock 22 170 646 minecraft:black_concrete
fill 24 170 604 24 171 604 minecraft:black_concrete
setblock 25 170 646 minecraft:black_concrete
setblock 27 170 646 minecraft:glowstone
setblock 30 170 646 minecraft:black_concrete
setblock 35 170 604 minecraft:black_concrete
setblock 36 170 604 minecraft:white_concrete
fill 40 170 604 41 170 604 minecraft:black_concrete
fill 40 170 646 40 171 646 minecraft:black_concrete
setblock 42 170 607 minecraft:black_concrete
setblock 42 170 614 minecraft:black_concrete
setblock 42 170 628 minecraft:black_concrete
fill 0 171 604 0 171 611 minecraft:blue_concrete
fill 0 171 612 0 173 612 minecraft:moss_block
fill 0 171 613 0 171 618 minecraft:blue_concrete
fill 0 171 620 0 171 623 minecraft:blue_concrete
fill 0 171 625 0 210 627 minecraft:blue_concrete
fill 0 171 628 0 173 628 minecraft:moss_block
fill 0 171 630 0 179 633 minecraft:blue_concrete
setblock 0 171 634 minecraft:black_concrete
fill 0 171 635 0 171 643 minecraft:blue_concrete
fill 0 171 644 0 173 644 minecraft:moss_block
fill 0 171 645 0 215 646 minecraft:blue_concrete
fill 1 171 604 3 178 604 minecraft:blue_concrete
fill 1 171 646 13 171 646 minecraft:blue_concrete
setblock 3 171 607 minecraft:light[level=14]
setblock 3 171 615 minecraft:light[level=14]
setblock 3 171 623 minecraft:light[level=14]
setblock 3 171 631 minecraft:light[level=14]
setblock 3 171 639 minecraft:light[level=14]
fill 4 171 604 4 173 604 minecraft:moss_block
fill 5 171 604 8 174 604 minecraft:blue_concrete
fill 10 171 604 10 190 604 minecraft:blue_concrete
setblock 11 171 607 minecraft:light[level=14]
setblock 11 171 615 minecraft:light[level=14]
setblock 11 171 623 minecraft:light[level=14]
setblock 11 171 631 minecraft:light[level=14]
setblock 11 171 639 minecraft:light[level=14]
fill 12 171 604 18 171 604 minecraft:blue_concrete
fill 14 171 646 14 173 646 minecraft:moss_block
fill 15 171 646 18 180 646 minecraft:blue_concrete
setblock 19 171 607 minecraft:light[level=14]
setblock 19 171 615 minecraft:light[level=14]
setblock 19 171 623 minecraft:light[level=14]
setblock 19 171 631 minecraft:light[level=14]
setblock 19 171 639 minecraft:light[level=14]
setblock 19 171 646 minecraft:black_concrete
fill 20 171 604 20 173 604 minecraft:moss_block
fill 20 171 646 28 171 646 minecraft:blue_concrete
fill 21 171 604 23 173 604 minecraft:blue_concrete
fill 25 171 604 30 171 604 minecraft:blue_concrete
setblock 27 171 607 minecraft:light[level=14]
setblock 27 171 615 minecraft:light[level=14]
setblock 27 171 623 minecraft:light[level=14]
setblock 27 171 631 minecraft:light[level=14]
setblock 27 171 639 minecraft:light[level=14]
setblock 29 171 646 minecraft:white_concrete
fill 30 171 646 30 173 646 minecraft:moss_block
fill 32 171 604 35 171 604 minecraft:blue_concrete
fill 32 171 646 33 194 646 minecraft:blue_concrete
setblock 35 171 607 minecraft:light[level=14]
setblock 35 171 615 minecraft:light[level=14]
setblock 35 171 623 minecraft:light[level=14]
setblock 35 171 631 minecraft:light[level=14]
setblock 35 171 639 minecraft:light[level=14]
fill 35 171 646 36 188 646 minecraft:blue_concrete
fill 36 171 604 36 173 604 minecraft:moss_block
fill 37 171 604 37 172 604 minecraft:blue_concrete
fill 38 171 646 39 171 646 minecraft:blue_concrete
fill 40 171 604 42 177 604 minecraft:blue_concrete
fill 41 171 646 41 180 646 minecraft:blue_concrete
fill 42 171 605 42 171 613 minecraft:blue_concrete
fill 42 171 614 42 173 614 minecraft:moss_block
fill 42 171 615 42 175 619 minecraft:blue_concrete
fill 42 171 621 42 176 628 minecraft:blue_concrete
fill 42 171 630 42 173 630 minecraft:moss_block
fill 42 171 631 42 171 633 minecraft:blue_concrete
fill 42 171 635 42 171 645 minecraft:blue_concrete
setblock 0 172 604 minecraft:black_concrete
fill 0 172 605 0 188 610 minecraft:blue_concrete
setblock 0 172 611 minecraft:white_concrete
fill 0 172 613 0 189 615 minecraft:blue_concrete
setblock 0 172 616 minecraft:black_concrete
fill 0 172 617 0 172 621 minecraft:blue_concrete
setblock 0 172 622 minecraft:black_concrete
fill 0 172 623 0 195 624 minecraft:blue_concrete
fill 0 172 634 0 179 637 minecraft:blue_concrete
setblock 0 172 638 minecraft:black_concrete
fill 0 172 639 0 172 641 minecraft:blue_concrete
setblock 0 172 642 minecraft:black_concrete
fill 0 172 643 0 182 643 minecraft:blue_concrete
fill 1 172 646 2 174 646 minecraft:blue_concrete
fill 3 172 646 3 173 646 minecraft:black_concrete
fill 4 172 646 4 240 646 minecraft:blue_concrete
fill 5 172 646 6 172 646 minecraft:black_concrete
fill 7 172 646 13 172 646 minecraft:blue_concrete
fill 9 172 604 9 173 604 minecraft:blue_concrete
fill 11 172 604 13 195 604 minecraft:blue_concrete
setblock 14 172 604 minecraft:black_concrete
fill 15 172 604 15 239 604 minecraft:blue_concrete
setblock 16 172 604 minecraft:black_concrete
fill 17 172 604 19 176 604 minecraft:blue_concrete
fill 19 172 646 26 174 646 minecraft:blue_concrete
fill 24 172 604 24 215 604 minecraft:blue_concrete
setblock 25 172 604 minecraft:black_concrete
fill 26 172 604 31 172 604 minecraft:blue_concrete
setblock 27 172 646 minecraft:black_concrete
fill 28 172 646 29 208 646 minecraft:blue_concrete
fill 31 172 646 31 239 646 minecraft:blue_concrete
setblock 32 172 604 minecraft:black_concrete
fill 33 172 604 35 196 604 minecraft:blue_concrete
fill 34 172 646 34 197 646 minecraft:blue_concrete
fill 37 172 619 37 173 620 minecraft:raw_iron_block
fill 37 172 646 38 207 646 minecraft:blue_concrete
fill 38 172 604 39 172 604 minecraft:blue_concrete
setblock 39 172 646 minecraft:black_concrete
fill 40 172 646 40 233 646 minecraft:blue_concrete
fill 42 172 605 42 183 606 minecraft:blue_concrete
setblock 42 172 607 minecraft:diamond_block
fill 42 172 608 42 192 611 minecraft:blue_concrete
fill 42 172 612 42 172 613 minecraft:black_concrete
fill 42 172 620 42 192 620 minecraft:blue_concrete
setblock 42 172 629 minecraft:blue_concrete
setblock 42 172 631 minecraft:black_concrete
fill 42 172 632 42 179 640 minecraft:blue_concrete
setblock 42 172 641 minecraft:black_concrete
fill 42 172 642 42 205 643 minecraft:blue_concrete
setblock 42 172 644 minecraft:glowstone
setblock 42 172 645 minecraft:diamond_block
fill 42 172 646 42 236 646 minecraft:blue_concrete
fill 0 173 604 0 236 604 minecraft:blue_concrete
fill 0 173 611 0 183 611 minecraft:blue_concrete
fill 0 173 616 0 173 620 minecraft:blue_concrete
setblock 0 173 621 minecraft:black_concrete
fill 0 173 622 0 189 622 minecraft:blue_concrete
fill 0 173 629 0 239 629 minecraft:blue_concrete
fill 0 173 638 0 184 640 minecraft:blue_concrete
setblock 0 173 641 minecraft:black_concrete
fill 0 173 642 0 179 642 minecraft:blue_concrete
setblock 5 173 646 minecraft:black_concrete
fill 6 173 646 9 179 646 minecraft:blue_concrete
setblock 10 173 646 minecraft:black_concrete
fill 11 173 646 12 239 646 minecraft:blue_concrete
setblock 13 173 646 minecraft:black_concrete
fill 14 173 604 14 236 604 minecraft:blue_concrete
fill 16 173 604 16 239 604 minecraft:blue_concrete
setblock 25 173 604 minecraft:white_concrete
setblock 26 173 604 minecraft:black_concrete
fill 27 173 604 32 184 604 minecraft:blue_concrete
fill 27 173 646 27 235 646 minecraft:blue_concrete
fill 37 173 604 38 173 604 minecraft:black_concrete
fill 39 173 604 39 241 604 minecraft:blue_concrete
fill 39 173 646 39 234 646 minecraft:blue_concrete
fill 42 173 607 42 178 607 minecraft:blue_concrete
fill 42 173 612 42 203 612 minecraft:blue_concrete
setblock 42 173 613 minecraft:black_concrete
setblock 42 173 629 minecraft:black_concrete
fill 42 173 631 42 230 631 minecraft:blue_concrete
fill 42 173 641 42 188 641 minecraft:blue_concrete
fill 42 173 644 42 239 645 minecraft:blue_concrete
fill 0 174 612 0 179 612 minecraft:blue_concrete
setblock 0 174 616 minecraft:white_concrete
fill 0 174 617 0 189 621 minecraft:blue_concrete
fill 0 174 628 0 179 628 minecraft:blue_concrete
fill 0 174 641 0 239 641 minecraft:blue_concrete
fill 0 174 644 0 179 644 minecraft:blue_concrete
fill 3 174 646 3 181 646 minecraft:blue_concrete
fill 4 174 604 4 179 604 minecraft:blue_concrete
fill 5 174 646 5 239 646 minecraft:blue_concrete
setblock 9 174 604 minecraft:glowstone
fill 10 174 646 10 239 646 minecraft:blue_concrete
fill 13 174 646 14 176 646 minecraft:blue_concrete
fill 20 174 604 20 179 604 minecraft:blue_concrete
setblock 21 174 604 minecraft:glowstone
fill 22 174 604 23 189 604 minecraft:blue_concrete
fill 25 174 604 26 182 604 minecraft:blue_concrete
fill 30 174 646 30 179 646 minecraft:blue_concrete
fill 36 174 604 38 177 604 minecraft:blue_concrete
fill 42 174 613 42 179 614 minecraft:blue_concrete
fill 42 174 629 42 179 630 minecraft:blue_concrete
fill 0 175 616 0 205 616 minecraft:blue_concrete
setblock 1 175 646 minecraft:diamond_block
fill 2 175 646 2 239 646 minecraft:blue_concrete
setblock 5 175 604 minecraft:glowstone
fill 6 175 604 9 177 604 minecraft:blue_concrete
fill 19 175 646 25 178 646 minecraft:blue_concrete
fill 21 175 604 21 234 604 minecraft:blue_concrete
setblock 26 175 646 minecraft:white_concrete
fill 1 176 646 1 219 646 minecraft:blue_concrete
fill 5 176 604 5 239 604 minecraft:blue_concrete
fill 26 176 646 26 180 646 minecraft:blue_concrete
fill 42 176 615 42 181 618 minecraft:blue_concrete
setblock 42 176 619 minecraft:diamond_block
fill 13 177 646 13 236 646 minecraft:blue_concrete
setblock 14 177 646 minecraft:white_concrete
fill 17 177 604 18 184 604 minecraft:blue_concrete
setblock 19 177 604 minecraft:glowstone
fill 42 177 619 42 188 619 minecraft:blue_concrete
fill 42 177 621 42 184 624 minecraft:blue_concrete
setblock 42 177 625 minecraft:white_concrete
fill 42 177 626 42 202 628 minecraft:blue_concrete
fill 5 178 634 6 179 634 minecraft:gold_block
fill 6 178 604 7 220 604 minecraft:blue_concrete
setblock 8 178 604 minecraft:glowstone
fill 9 178 604 9 197 604 minecraft:blue_concrete
fill 14 178 646 14 179 646 minecraft:blue_concrete
fill 19 178 604 19 236 604 minecraft:blue_concrete
fill 36 178 604 37 179 604 minecraft:blue_concrete
setblock 38 178 604 minecraft:diamond_block
fill 40 178 604 40 239 604 minecraft:blue_concrete
setblock 41 178 604 minecraft:white_concrete
fill 42 178 604 42 236 604 minecraft:blue_concrete
fill 42 178 625 42 187 625 minecraft:blue_concrete
setblock 1 179 604 minecraft:white_concrete
fill 2 179 604 3 237 604 minecraft:blue_concrete
setblock 3 179 607 minecraft:light[level=14]
setblock 3 179 615 minecraft:light[level=14]
setblock 3 179 623 minecraft:light[level=14]
setblock 3 179 631 minecraft:light[level=14]
setblock 3 179 639 minecraft:light[level=14]
fill 8 179 604 8 235 604 minecraft:blue_concrete
setblock 11 179 607 minecraft:light[level=14]
setblock 11 179 615 minecraft:light[level=14]
setblock 11 179 623 minecraft:light[level=14]
setblock 11 179 631 minecraft:light[level=14]
setblock 11 179 639 minecraft:light[level=14]
setblock 19 179 607 minecraft:light[level=14]
setblock 19 179 615 minecraft:light[level=14]
setblock 19 179 623 minecraft:light[level=14]
setblock 19 179 631 minecraft:light[level=14]
setblock 19 179 639 minecraft:light[level=14]
fill 19 179 646 21 227 646 minecraft:blue_concrete
setblock 22 179 646 minecraft:glowstone
fill 23 179 646 25 184 646 minecraft:blue_concrete
setblock 27 179 607 minecraft:light[level=14]
setblock 27 179 615 minecraft:light[level=14]
setblock 27 179 623 minecraft:light[level=14]
setblock 27 179 631 minecraft:light[level=14]
setblock 27 179 639 minecraft:light[level=14]
setblock 35 179 607 minecraft:light[level=14]
setblock 35 179 615 minecraft:light[level=14]
setblock 35 179 623 minecraft:light[level=14]
setblock 35 179 631 minecraft:light[level=14]
setblock 35 179 639 minecraft:light[level=14]
fill 38 179 604 38 180 604 minecraft:blue_concrete
fill 41 179 604 41 239 604 minecraft:blue_concrete
setblock 42 179 607 minecraft:glowstone
fill 0 180 612 0 181 612 minecraft:moss_block
fill 0 180 628 0 181 628 minecraft:moss_block
fill 0 180 630 0 186 632 minecraft:blue_concrete
setblock 0 180 633 minecraft:diamond_block
setblock 0 180 634 minecraft:white_concrete
fill 0 180 635 0 195 637 minecraft:blue_concrete
setblock 0 180 642 minecraft:diamond_block
fill 0 180 644 0 181 644 minecraft:moss_block
fill 1 180 604 1 184 604 minecraft:blue_concrete
fill 4 180 604 4 181 604 minecraft:moss_block
fill 6 180 646 6 239 646 minecraft:blue_concrete
setblock 7 180 646 minecraft:diamond_block
fill 8 180 646 9 213 646 minecraft:blue_concrete
fill 10 180 640 11 181 640 minecraft:moss_block
fill 11 180 641 11 181 641 minecraft:moss_block
fill 14 180 646 14 181 646 minecraft:moss_block
fill 20 180 604 20 181 604 minecraft:moss_block
fill 22 180 646 22 239 646 minecraft:blue_concrete
fill 30 180 646 30 181 646 minecraft:moss_block
fill 36 180 604 36 181 604 minecraft:moss_block
fill 37 180 604 37 202 604 minecraft:blue_concrete
fill 42 180 607 42 237 607 minecraft:blue_concrete
fill 42 180 613 42 232 613 minecraft:blue_concrete
fill 42 180 614 42 181 614 minecraft:moss_block
fill 42 180 629 42 190 629 minecraft:blue_concrete
fill 42 180 630 42 181 630 minecraft:moss_block
fill 42 180 632 42 222 632 minecraft:blue_concrete
setblock 42 180 633 minecraft:diamond_block
fill 42 180 634 42 200 640 minecraft:blue_concrete
fill 0 181 633 0 209 634 minecraft:blue_concrete
fill 0 181 642 0 192 642 minecraft:blue_concrete
fill 7 181 646 7 227 646 minecraft:blue_concrete
fill 15 181 646 15 238 646 minecraft:blue_concrete
setblock 16 181 646 minecraft:white_concrete
fill 17 181 646 18 196 646 minecraft:blue_concrete
setblock 26 181 646 minecraft:diamond_block
setblock 38 181 604 minecraft:diamond_block
setblock 41 181 646 minecraft:diamond_block
fill 42 181 633 42 239 633 minecraft:blue_concrete
fill 0 182 612 0 189 612 minecraft:blue_concrete
fill 0 182 628 0 197 628 minecraft:blue_concrete
fill 0 182 644 0 197 644 minecraft:blue_concrete
setblock 3 182 646 minecraft:diamond_block
fill 4 182 604 4 196 604 minecraft:blue_concrete
fill 14 182 646 14 183 646 minecraft:blue_concrete
fill 16 182 646 16 239 646 minecraft:blue_concrete
fill 20 182 604 20 197 604 minecraft:blue_concrete
fill 26 182 646 26 235 646 minecraft:blue_concrete
fill 30 182 646 30 197 646 minecraft:blue_concrete
fill 36 182 604 36 197 604 minecraft:blue_concrete
fill 38 182 604 38 239 604 minecraft:blue_concrete
fill 41 182 646 41 212 646 minecraft:blue_concrete
fill 42 182 614 42 197 617 minecraft:blue_concrete
setblock 42 182 618 minecraft:glowstone
fill 42 182 630 42 197 630 minecraft:blue_concrete
setblock 0 183 643 minecraft:glowstone
fill 3 183 646 3 215 646 minecraft:blue_concrete
fill 25 183 604 25 219 604 minecraft:blue_concrete
setblock 26 183 604 minecraft:diamond_block
fill 42 183 618 42 237 618 minecraft:blue_concrete
setblock 0 184 611 minecraft:glowstone
fill 0 184 643 0 206 643 minecraft:blue_concrete
setblock 14 184 646 minecraft:white_concrete
fill 26 184 604 26 239 604 minecraft:blue_concrete
fill 42 184 605 42 237 605 minecraft:blue_concrete
setblock 42 184 606 minecraft:glowstone
fill 0 185 611 0 239 611 minecraft:blue_concrete
setblock 0 185 638 minecraft:white_concrete
fill 0 185 639 0 226 640 minecraft:blue_concrete
setblock 1 185 604 minecraft:diamond_block
fill 14 185 646 14 197 646 minecraft:blue_concrete
setblock 17 185 604 minecraft:glowstone
fill 18 185 604 18 239 604 minecraft:blue_concrete
setblock 23 185 646 minecraft:glowstone
fill 24 185 646 25 187 646 minecraft:blue_concrete
fill 27 185 604 31 191 604 minecraft:blue_concrete
setblock 32 185 604 minecraft:diamond_block
fill 42 185 606 42 239 606 minecraft:blue_concrete
fill 42 185 621 42 187 621 minecraft:blue_concrete
setblock 42 185 622 minecraft:diamond_block
fill 42 185 623 42 204 624 minecraft:blue_concrete
fill 0 186 638 0 239 638 minecraft:blue_concrete
fill 1 186 604 1 237 604 minecraft:blue_concrete
fill 15 186 627 17 186 629 minecraft:redstone_block
fill 17 186 604 17 194 604 minecraft:blue_concrete
fill 19 186 619 21 186 621 minecraft:redstone_block
fill 23 186 646 23 210 646 minecraft:blue_concrete
fill 24 186 624 26 186 626 minecraft:redstone_block
fill 32 186 604 32 212 604 minecraft:blue_concrete
fill 42 186 622 42 187 622 minecraft:blue_concrete
setblock 0 187 630 minecraft:diamond_block
fill 0 187 631 0 196 632 minecraft:blue_concrete
fill 1 187 605 1 188 606 minecraft:deepslate
fill 1 187 607 1 187 609 minecraft:stone
fill 1 187 610 1 187 612 minecraft:deepslate
fill 1 187 613 1 187 615 minecraft:stone
fill 1 187 616 1 187 618 minecraft:deepslate
fill 1 187 619 1 187 621 minecraft:stone
fill 1 187 622 1 187 624 minecraft:deepslate
fill 1 187 625 1 187 627 minecraft:stone
fill 1 187 628 1 187 630 minecraft:deepslate
fill 1 187 631 1 187 633 minecraft:stone
fill 1 187 634 1 187 636 minecraft:deepslate
fill 1 187 637 1 187 639 minecraft:stone
fill 1 187 640 1 187 642 minecraft:deepslate
fill 1 187 643 1 187 645 minecraft:stone
fill 2 187 605 4 187 606 minecraft:stone
fill 2 187 607 4 187 609 minecraft:deepslate
fill 2 187 610 4 187 612 minecraft:stone
fill 2 187 613 4 187 615 minecraft:deepslate
fill 2 187 616 4 187 618 minecraft:stone
fill 2 187 619 4 187 621 minecraft:deepslate
fill 2 187 622 4 187 624 minecraft:stone
fill 2 187 625 4 187 627 minecraft:deepslate
fill 2 187 628 4 187 630 minecraft:stone
fill 2 187 631 4 187 633 minecraft:deepslate
fill 2 187 634 4 187 636 minecraft:stone
fill 2 187 637 4 187 639 minecraft:deepslate
fill 2 187 640 4 187 642 minecraft:stone
fill 2 187 643 4 187 645 minecraft:deepslate
fill 5 187 605 7 187 606 minecraft:deepslate
fill 5 187 607 7 187 609 minecraft:stone
fill 5 187 610 7 187 612 minecraft:deepslate
fill 5 187 613 7 187 615 minecraft:stone
fill 5 187 616 7 187 618 minecraft:deepslate
fill 5 187 619 7 187 621 minecraft:stone
fill 5 187 622 7 187 624 minecraft:deepslate
fill 5 187 625 7 187 627 minecraft:stone
fill 5 187 628 7 187 630 minecraft:deepslate
fill 5 187 631 7 187 633 minecraft:stone
fill 5 187 634 7 187 636 minecraft:deepslate
fill 5 187 637 7 187 639 minecraft:stone
fill 5 187 640 7 187 642 minecraft:deepslate
fill 5 187 643 7 187 645 minecraft:stone
fill 8 187 605 10 187 606 minecraft:stone
fill 8 187 607 10 187 609 minecraft:deepslate
fill 8 187 610 10 187 612 minecraft:stone
fill 8 187 613 10 187 615 minecraft:deepslate
fill 8 187 616 10 187 618 minecraft:stone
fill 8 187 619 10 187 621 minecraft:deepslate
fill 8 187 622 10 187 624 minecraft:stone
fill 8 187 625 10 187 627 minecraft:deepslate
fill 8 187 628 10 187 630 minecraft:stone
fill 8 187 631 10 187 633 minecraft:deepslate
fill 8 187 634 10 187 636 minecraft:stone
fill 8 187 637 10 187 639 minecraft:deepslate
fill 8 187 640 10 187 642 minecraft:stone
fill 8 187 643 10 187 645 minecraft:deepslate
fill 11 187 605 13 187 606 minecraft:deepslate
fill 11 187 607 13 187 609 minecraft:stone
fill 11 187 610 13 187 612 minecraft:deepslate
fill 11 187 613 13 187 615 minecraft:stone
fill 11 187 616 13 187 618 minecraft:deepslate
fill 11 187 619 13 187 621 minecraft:stone
fill 11 187 622 13 187 624 minecraft:deepslate
fill 11 187 625 13 187 627 minecraft:stone
fill 11 187 628 13 187 630 minecraft:deepslate
fill 11 187 631 13 187 633 minecraft:stone
fill 11 187 634 13 187 636 minecraft:deepslate
fill 11 187 637 13 187 639 minecraft:stone
fill 11 187 640 13 187 642 minecraft:deepslate
fill 11 187 643 13 187 645 minecraft:stone
fill 14 187 605 16 187 606 minecraft:stone
fill 14 187 607 16 187 609 minecraft:deepslate
fill 14 187 610 16 187 612 minecraft:stone
fill 14 187 613 16 187 615 minecraft:deepslate
fill 14 187 616 16 187 618 minecraft:stone
fill 14 187 619 16 187 621 minecraft:deepslate
fill 14 187 622 16 187 624 minecraft:stone
fill 14 187 625 14 187 627 minecraft:deepslate
fill 14 187 628 14 187 630 minecraft:stone
fill 14 187 631 16 187 633 minecraft:deepslate
fill 14 187 634 16 187 636 minecraft:stone
fill 14 187 637 16 187 639 minecraft:deepslate
fill 14 187 640 16 187 642 minecraft:stone
fill 14 187 643 16 187 645 minecraft:deepslate
fill 15 187 625 16 187 626 minecraft:deepslate
fill 15 187 630 16 187 630 minecraft:stone
fill 17 187 605 19 187 606 minecraft:deepslate
fill 17 187 607 19 187 609 minecraft:stone
fill 17 187 610 19 187 612 minecraft:deepslate
fill 17 187 613 19 187 615 minecraft:stone
fill 17 187 616 19 187 618 minecraft:deepslate
fill 17 187 619 18 187 621 minecraft:stone
fill 17 187 622 18 187 624 minecraft:deepslate
fill 17 187 625 18 187 626 minecraft:stone
fill 17 187 630 19 187 630 minecraft:deepslate
fill 17 187 631 19 187 633 minecraft:stone
fill 17 187 634 19 187 636 minecraft:deepslate
fill 17 187 637 19 187 639 minecraft:stone
fill 17 187 640 19 187 642 minecraft:deepslate
fill 17 187 643 19 187 645 minecraft:stone
fill 18 187 627 19 187 627 minecraft:stone
fill 18 187 628 19 187 629 minecraft:deepslate
fill 19 187 622 19 187 623 minecraft:deepslate
fill 20 187 605 22 187 606 minecraft:stone
fill 20 187 607 22 187 609 minecraft:deepslate
fill 20 187 610 22 187 612 minecraft:stone
fill 20 187 613 22 187 615 minecraft:deepslate
fill 20 187 616 22 187 618 minecraft:stone
fill 20 187 622 22 187 623 minecraft:stone
fill 20 187 627 22 187 627 minecraft:deepslate
fill 20 187 628 22 187 630 minecraft:stone
fill 20 187 631 22 187 633 minecraft:deepslate
fill 20 187 634 22 187 636 minecraft:stone
fill 20 187 637 22 187 639 minecraft:deepslate
fill 20 187 640 22 187 642 minecraft:stone
fill 20 187 643 22 187 645 minecraft:deepslate
fill 22 187 619 22 187 621 minecraft:deepslate
setblock 22 187 624 minecraft:stone
fill 22 187 625 22 187 626 minecraft:deepslate
fill 23 187 605 25 187 606 minecraft:deepslate
fill 23 187 607 25 187 609 minecraft:stone
fill 23 187 610 25 187 612 minecraft:deepslate
fill 23 187 613 25 187 615 minecraft:stone
fill 23 187 616 25 187 618 minecraft:deepslate
fill 23 187 619 25 187 621 minecraft:stone
fill 23 187 622 23 187 624 minecraft:deepslate
fill 23 187 625 23 187 627 minecraft:stone
fill 23 187 628 25 187 630 minecraft:deepslate
fill 23 187 631 25 187 633 minecraft:stone
fill 23 187 634 25 187 636 minecraft:deepslate
fill 23 187 637 25 187 639 minecraft:stone
fill 23 187 640 25 187 642 minecraft:deepslate
fill 23 187 643 25 187 645 minecraft:stone
fill 24 187 622 25 187 623 minecraft:deepslate
fill 24 187 627 25 187 627 minecraft:stone
fill 26 187 605 28 187 606 minecraft:stone
fill 26 187 607 28 187 609 minecraft:deepslate
fill 26 187 610 28 187 612 minecraft:stone
fill 26 187 613 28 187 615 minecraft:deepslate
fill 26 187 616 28 187 618 minecraft:stone
fill 26 187 619 28 187 621 minecraft:deepslate
fill 26 187 622 28 187 623 minecraft:stone
fill 26 187 627 28 187 627 minecraft:deepslate
fill 26 187 628 28 187 630 minecraft:stone
fill 26 187 631 28 187 633 minecraft:deepslate
fill 26 187 634 28 187 636 minecraft:stone
fill 26 187 637 28 187 639 minecraft:deepslate
fill 26 187 640 28 187 642 minecraft:stone
fill 26 187 643 28 187 645 minecraft:deepslate
fill 27 187 624 28 187 624 minecraft:stone
fill 27 187 625 28 187 626 minecraft:deepslate
fill 29 187 605 31 187 606 minecraft:deepslate
fill 29 187 607 31 187 609 minecraft:stone
fill 29 187 610 31 187 612 minecraft:deepslate
fill 29 187 613 31 187 615 minecraft:stone
fill 29 187 616 31 187 618 minecraft:deepslate
fill 29 187 619 31 187 621 minecraft:stone
fill 29 187 622 31 187 624 minecraft:deepslate
fill 29 187 625 31 187 627 minecraft:stone
fill 29 187 628 31 187 630 minecraft:deepslate
fill 29 187 631 31 187 633 minecraft:stone
fill 29 187 634 31 187 636 minecraft:deepslate
fill 29 187 637 31 187 639 minecraft:stone
fill 29 187 640 31 187 642 minecraft:deepslate
fill 29 187 643 31 187 645 minecraft:stone
fill 32 187 605 34 187 606 minecraft:stone
fill 32 187 607 34 187 609 minecraft:deepslate
fill 32 187 610 34 187 612 minecraft:stone
fill 32 187 613 34 187 615 minecraft:deepslate
fill 32 187 616 34 187 618 minecraft:stone
fill 32 187 619 34 187 621 minecraft:deepslate
fill 32 187 622 34 187 624 minecraft:stone
fill 32 187 625 34 187 627 minecraft:deepslate
fill 32 187 628 34 187 630 minecraft:stone
fill 32 187 631 34 187 633 minecraft:deepslate
fill 32 187 634 34 187 636 minecraft:stone
fill 32 187 637 34 187 639 minecraft:deepslate
fill 32 187 640 34 187 642 minecraft:stone
fill 32 187 643 34 187 645 minecraft:deepslate
fill 35 187 605 37 187 606 minecraft:deepslate
fill 35 187 607 37 187 609 minecraft:stone
fill 35 187 610 37 187 612 minecraft:deepslate
fill 35 187 613 37 187 615 minecraft:stone
fill 35 187 616 37 187 618 minecraft:deepslate
fill 35 187 619 37 187 621 minecraft:stone
fill 35 187 622 37 187 624 minecraft:deepslate
fill 35 187 625 37 187 627 minecraft:stone
fill 35 187 628 37 187 630 minecraft:deepslate
fill 35 187 631 37 187 633 minecraft:stone
fill 35 187 634 37 187 636 minecraft:deepslate
fill 35 187 637 37 187 639 minecraft:stone
fill 35 187 640 37 187 642 minecraft:deepslate
fill 35 187 643 37 187 645 minecraft:stone
fill 38 187 605 40 187 606 minecraft:stone
fill 38 187 607 40 187 609 minecraft:deepslate
fill 38 187 610 40 187 612 minecraft:stone
fill 38 187 613 40 187 615 minecraft:deepslate
fill 38 187 616 40 187 618 minecraft:stone
fill 38 187 619 40 187 621 minecraft:deepslate
fill 38 187 622 40 187 624 minecraft:stone
fill 38 187 625 40 187 627 minecraft:deepslate
fill 38 187 628 40 187 630 minecraft:stone
fill 38 187 631 40 187 633 minecraft:deepslate
fill 38 187 634 40 187 636 minecraft:stone
fill 38 187 637 40 187 639 minecraft:deepslate
fill 38 187 640 40 187 642 minecraft:stone
fill 38 187 643 40 187 645 minecraft:deepslate
fill 41 187 605 41 187 606 minecraft:deepslate
fill 41 187 607 41 187 609 minecraft:stone
fill 41 187 610 41 187 612 minecraft:deepslate
fill 41 187 613 41 187 615 minecraft:stone
fill 41 187 616 41 187 618 minecraft:deepslate
fill 41 187 619 41 187 621 minecraft:stone
fill 41 187 622 41 187 624 minecraft:deepslate
fill 41 187 625 41 187 627 minecraft:stone
fill 41 187 628 41 187 630 minecraft:deepslate
fill 41 187 631 41 187 633 minecraft:stone
fill 41 187 634 41 187 636 minecraft:deepslate
fill 41 187 637 41 187 639 minecraft:stone
fill 41 187 640 41 187 642 minecraft:deepslate
fill 41 187 643 41 187 645 minecraft:stone
fill 0 188 630 0 193 630 minecraft:blue_concrete
fill 1 188 607 41 188 607 minecraft:diamond_block
fill 1 188 608 1 188 609 minecraft:stone
fill 1 188 610 41 188 610 minecraft:diamond_block
fill 1 188 611 1 188 612 minecraft:deepslate
fill 1 188 613 41 188 613 minecraft:diamond_block
fill 1 188 614 1 188 615 minecraft:stone
fill 1 188 616 41 188 616 minecraft:diamond_block
fill 1 188 617 1 188 618 minecraft:deepslate
fill 1 188 619 17 188 619 minecraft:diamond_block
fill 1 188 620 1 188 621 minecraft:stone
fill 1 188 622 17 188 622 minecraft:diamond_block
fill 1 188 623 1 188 624 minecraft:deepslate
fill 1 188 625 16 188 625 minecraft:diamond_block
fill 1 188 626 1 188 627 minecraft:stone
fill 1 188 628 13 188 628 minecraft:diamond_block
fill 1 188 629 1 188 630 minecraft:deepslate
fill 1 188 631 41 188 631 minecraft:diamond_block
fill 1 188 632 1 188 633 minecraft:stone
fill 1 188 634 41 188 634 minecraft:diamond_block
fill 1 188 635 1 188 636 minecraft:deepslate
fill 1 188 637 41 188 637 minecraft:diamond_block
fill 1 188 638 1 188 639 minecraft:stone
fill 1 188 640 41 188 640 minecraft:diamond_block
fill 1 188 641 1 188 642 minecraft:deepslate
fill 1 188 643 41 188 643 minecraft:diamond_block
fill 1 188 644 1 188 645 minecraft:stone
fill 2 188 605 2 188 606 minecraft:diamond_block
fill 2 188 608 2 188 609 minecraft:diamond_block
fill 2 188 611 2 188 612 minecraft:diamond_block
fill 2 188 614 2 188 615 minecraft:diamond_block
fill 2 188 617 2 188 618 minecraft:diamond_block
fill 2 188 620 2 188 621 minecraft:diamond_block
fill 2 188 623 2 188 624 minecraft:diamond_block
fill 2 188 626 2 188 627 minecraft:diamond_block
fill 2 188 629 2 188 630 minecraft:diamond_block
fill 2 188 632 2 188 633 minecraft:diamond_block
fill 2 188 635 2 188 636 minecraft:diamond_block
fill 2 188 638 2 188 639 minecraft:diamond_block
fill 2 188 641 2 188 642 minecraft:diamond_block
fill 2 188 644 2 188 645 minecraft:diamond_block
fill 3 188 605 4 188 606 minecraft:stone
fill 3 188 608 4 188 609 minecraft:deepslate
fill 3 188 611 4 188 612 minecraft:stone
fill 3 188 614 4 188 615 minecraft:deepslate
fill 3 188 617 4 188 618 minecraft:stone
fill 3 188 620 4 188 621 minecraft:deepslate
fill 3 188 623 4 188 624 minecraft:stone
fill 3 188 626 4 188 627 minecraft:deepslate
fill 3 188 629 4 188 630 minecraft:stone
fill 3 188 632 4 188 633 minecraft:deepslate
fill 3 188 635 4 188 636 minecraft:stone
fill 3 188 638 4 188 639 minecraft:deepslate
fill 3 188 641 4 188 642 minecraft:stone
fill 3 188 644 4 188 645 minecraft:deepslate
fill 5 188 605 5 188 606 minecraft:diamond_block
fill 5 188 608 5 188 609 minecraft:diamond_block
fill 5 188 611 5 188 612 minecraft:diamond_block
fill 5 188 614 5 188 615 minecraft:diamond_block
fill 5 188 617 5 188 618 minecraft:diamond_block
fill 5 188 620 5 188 621 minecraft:diamond_block
fill 5 188 623 5 188 624 minecraft:diamond_block
fill 5 188 626 5 188 627 minecraft:diamond_block
fill 5 188 629 5 188 630 minecraft:diamond_block
fill 5 188 632 5 188 633 minecraft:diamond_block
fill 5 188 635 5 188 636 minecraft:diamond_block
fill 5 188 638 5 188 639 minecraft:diamond_block
fill 5 188 641 5 188 642 minecraft:diamond_block
fill 5 188 644 5 188 645 minecraft:diamond_block
fill 6 188 605 7 188 606 minecraft:deepslate
fill 6 188 608 7 188 609 minecraft:stone
fill 6 188 611 7 188 612 minecraft:deepslate
fill 6 188 614 7 188 615 minecraft:stone
fill 6 188 617 7 188 618 minecraft:deepslate
fill 6 188 620 7 188 621 minecraft:stone
fill 6 188 623 7 188 624 minecraft:deepslate
fill 6 188 626 7 188 627 minecraft:stone
fill 6 188 629 7 188 630 minecraft:deepslate
fill 6 188 632 7 188 633 minecraft:stone
fill 6 188 635 7 188 636 minecraft:deepslate
fill 6 188 638 7 188 639 minecraft:stone
fill 6 188 641 7 188 642 minecraft:deepslate
fill 6 188 644 7 188 645 minecraft:stone
fill 8 188 605 8 188 606 minecraft:diamond_block
fill 8 188 608 8 188 609 minecraft:diamond_block
fill 8 188 611 8 188 612 minecraft:diamond_block
fill 8 188 614 8 188 615 minecraft:diamond_block
fill 8 188 617 8 188 618 minecraft:diamond_block
fill 8 188 620 8 188 621 minecraft:diamond_block
fill 8 188 623 8 188 624 minecraft:diamond_block
fill 8 188 626 8 188 627 minecraft:diamond_block
fill 8 188 629 8 188 630 minecraft:diamond_block
fill 8 188 632 8 188 633 minecraft:diamond_block
fill 8 188 635 8 188 636 minecraft:diamond_block
fill 8 188 638 8 188 639 minecraft:diamond_block
fill 8 188 641 8 188 642 minecraft:diamond_block
fill 8 188 644 8 188 645 minecraft:diamond_block
fill 9 188 605 10 188 606 minecraft:stone
fill 9 188 608 10 188 609 minecraft:deepslate
fill 9 188 611 10 188 612 minecraft:stone
fill 9 188 614 10 188 615 minecraft:deepslate
fill 9 188 617 10 188 618 minecraft:stone
fill 9 188 620 10 188 621 minecraft:deepslate
fill 9 188 623 10 188 624 minecraft:stone
fill 9 188 626 10 188 627 minecraft:deepslate
fill 9 188 629 10 188 630 minecraft:stone
fill 9 188 632 10 188 633 minecraft:deepslate
fill 9 188 635 10 188 636 minecraft:stone
fill 9 188 638 10 188 639 minecraft:deepslate
fill 9 188 641 10 188 642 minecraft:stone
fill 9 188 644 10 188 645 minecraft:deepslate
fill 11 188 605 11 188 606 minecraft:diamond_block
fill 11 188 608 11 188 609 minecraft:diamond_block
fill 11 188 611 11 188 612 minecraft:diamond_block
fill 11 188 614 11 188 615 minecraft:diamond_block
fill 11 188 617 11 188 618 minecraft:diamond_block
fill 11 188 620 11 188 621 minecraft:diamond_block
fill 11 188 623 11 188 624 minecraft:diamond_block
fill 11 188 626 11 188 627 minecraft:diamond_block
fill 11 188 629 11 188 630 minecraft:diamond_block
fill 11 188 632 11 188 633 minecraft:diamond_block
fill 11 188 635 11 188 636 minecraft:diamond_block
fill 11 188 638 11 188 639 minecraft:diamond_block
fill 11 188 641 11 188 642 minecraft:diamond_block
fill 11 188 644 11 188 645 minecraft:diamond_block
fill 12 188 605 13 188 606 minecraft:deepslate
fill 12 188 608 13 188 609 minecraft:stone
fill 12 188 611 13 188 612 minecraft:deepslate
fill 12 188 614 13 188 615 minecraft:stone
fill 12 188 617 13 188 618 minecraft:deepslate
fill 12 188 620 13 188 621 minecraft:stone
fill 12 188 623 13 188 624 minecraft:deepslate
fill 12 188 626 13 188 627 minecraft:stone
fill 12 188 629 13 188 630 minecraft:deepslate
fill 12 188 632 13 188 633 minecraft:stone
fill 12 188 635 13 188 636 minecraft:deepslate
fill 12 188 638 13 188 639 minecraft:stone
fill 12 188 641 13 188 642 minecraft:deepslate
fill 12 188 644 13 188 645 minecraft:stone
fill 14 188 605 14 188 606 minecraft:diamond_block
fill 14 188 608 14 188 609 minecraft:diamond_block
fill 14 188 611 14 188 612 minecraft:diamond_block
fill 14 188 614 14 188 615 minecraft:diamond_block
fill 14 188 617 14 188 618 minecraft:diamond_block
fill 14 188 620 14 188 621 minecraft:diamond_block
fill 14 188 623 14 188 624 minecraft:diamond_block
fill 14 188 626 14 188 630 minecraft:glowstone
fill 14 188 632 14 188 633 minecraft:diamond_block
fill 14 188 635 14 188 636 minecraft:diamond_block
fill 14 188 638 14 188 639 minecraft:diamond_block
fill 14 188 641 14 188 642 minecraft:diamond_block
fill 14 188 644 14 188 645 minecraft:diamond_block
fill 15 188 605 16 188 606 minecraft:stone
fill 15 188 608 16 188 609 minecraft:deepslate
fill 15 188 611 16 188 612 minecraft:stone
fill 15 188 614 16 188 615 minecraft:deepslate
fill 15 188 617 16 188 618 minecraft:stone
fill 15 188 620 16 188 621 minecraft:deepslate
fill 15 188 623 16 188 624 minecraft:stone
fill 15 188 626 16 188 626 minecraft:glowstone
fill 15 188 627 17 188 629 minecraft:stone
fill 15 188 630 18 188 630 minecraft:glowstone
fill 15 188 632 16 188 633 minecraft:deepslate
fill 15 188 635 16 188 636 minecraft:stone
fill 15 188 638 16 188 639 minecraft:deepslate
fill 15 188 641 16 188 642 minecraft:stone
fill 15 188 644 16 188 645 minecraft:deepslate
fill 17 188 605 17 188 606 minecraft:diamond_block
fill 17 188 608 17 188 609 minecraft:diamond_block
fill 17 188 611 17 188 612 minecraft:diamond_block
fill 17 188 614 17 188 615 minecraft:diamond_block
fill 17 188 617 17 188 618 minecraft:diamond_block
fill 17 188 620 17 188 621 minecraft:diamond_block
setblock 17 188 623 minecraft:diamond_block
fill 17 188 624 17 188 626 minecraft:red_nether_bricks
fill 17 188 632 17 188 633 minecraft:diamond_block
fill 17 188 635 17 188 636 minecraft:diamond_block
fill 17 188 638 17 188 639 minecraft:diamond_block
fill 17 188 641 17 188 642 minecraft:diamond_block
fill 17 188 644 17 188 645 minecraft:diamond_block
fill 18 188 605 19 188 606 minecraft:deepslate
fill 18 188 608 19 188 609 minecraft:stone
fill 18 188 611 19 188 612 minecraft:deepslate
fill 18 188 614 19 188 615 minecraft:stone
fill 18 188 617 19 188 617 minecraft:deepslate
fill 18 188 618 18 188 622 minecraft:glowstone
setblock 18 188 623 minecraft:red_nether_bricks
fill 18 188 624 18 188 626 minecraft:shroomlight
setblock 18 188 627 minecraft:red_nether_bricks
fill 18 188 628 18 188 629 minecraft:glowstone
fill 18 188 632 19 188 633 minecraft:stone
fill 18 188 635 19 188 636 minecraft:deepslate
fill 18 188 638 19 188 639 minecraft:stone
fill 18 188 641 19 188 642 minecraft:deepslate
fill 18 188 644 19 188 645 minecraft:stone
fill 19 188 618 22 188 618 minecraft:glowstone
fill 19 188 619 21 188 621 minecraft:stone
fill 19 188 622 22 188 622 minecraft:glowstone
fill 19 188 623 21 188 623 minecraft:shroomlight
fill 19 188 627 21 188 627 minecraft:shroomlight
fill 19 188 628 41 188 628 minecraft:diamond_block
fill 19 188 629 19 188 630 minecraft:deepslate
fill 20 188 605 20 188 606 minecraft:diamond_block
fill 20 188 608 20 188 609 minecraft:diamond_block
fill 20 188 611 20 188 612 minecraft:diamond_block
fill 20 188 614 20 188 615 minecraft:diamond_block
setblock 20 188 617 minecraft:diamond_block
fill 20 188 629 20 188 630 minecraft:diamond_block
fill 20 188 632 20 188 633 minecraft:diamond_block
fill 20 188 635 20 188 636 minecraft:diamond_block
fill 20 188 638 20 188 639 minecraft:diamond_block
fill 20 188 641 20 188 642 minecraft:diamond_block
fill 20 188 644 20 188 645 minecraft:diamond_block
fill 21 188 605 22 188 606 minecraft:stone
fill 21 188 608 22 188 609 minecraft:deepslate
fill 21 188 611 22 188 612 minecraft:stone
fill 21 188 614 22 188 615 minecraft:deepslate
fill 21 188 617 22 188 617 minecraft:stone
fill 21 188 629 22 188 630 minecraft:stone
fill 21 188 632 22 188 633 minecraft:deepslate
fill 21 188 635 22 188 636 minecraft:stone
fill 21 188 638 22 188 639 minecraft:deepslate
fill 21 188 641 22 188 642 minecraft:stone
fill 21 188 644 22 188 645 minecraft:deepslate
fill 22 188 619 22 188 621 minecraft:glowstone
setblock 22 188 623 minecraft:red_nether_bricks
fill 22 188 624 22 188 626 minecraft:shroomlight
setblock 22 188 627 minecraft:red_nether_bricks
fill 23 188 605 23 188 606 minecraft:diamond_block
fill 23 188 608 23 188 609 minecraft:diamond_block
fill 23 188 611 23 188 612 minecraft:diamond_block
fill 23 188 614 23 188 615 minecraft:diamond_block
fill 23 188 617 23 188 622 minecraft:diamond_block
fill 23 188 623 27 188 623 minecraft:glowstone
fill 23 188 624 23 188 626 minecraft:red_nether_bricks
fill 23 188 627 27 188 627 minecraft:glowstone
fill 23 188 629 23 188 630 minecraft:diamond_block
fill 23 188 632 23 188 633 minecraft:diamond_block
fill 23 188 635 23 188 636 minecraft:diamond_block
fill 23 188 638 23 188 639 minecraft:diamond_block
fill 23 188 641 23 188 642 minecraft:diamond_block
fill 23 188 644 23 188 645 minecraft:diamond_block
fill 24 188 605 25 188 606 minecraft:deepslate
fill 24 188 608 25 188 609 minecraft:stone
fill 24 188 611 25 188 612 minecraft:deepslate
fill 24 188 614 25 188 615 minecraft:stone
fill 24 188 617 25 188 618 minecraft:deepslate
fill 24 188 619 41 188 619 minecraft:diamond_block
fill 24 188 620 25 188 621 minecraft:stone
fill 24 188 622 41 188 622 minecraft:diamond_block
fill 24 188 624 26 188 626 minecraft:stone
fill 24 188 629 25 188 630 minecraft:deepslate
fill 24 188 632 25 188 633 minecraft:stone
fill 24 188 635 25 188 636 minecraft:deepslate
fill 24 188 638 25 188 639 minecraft:stone
fill 24 188 641 25 188 642 minecraft:deepslate
fill 24 188 644 25 188 645 minecraft:stone
setblock 24 188 646 minecraft:diamond_block
fill 25 188 646 25 201 646 minecraft:blue_concrete
fill 26 188 605 26 188 606 minecraft:diamond_block
fill 26 188 608 26 188 609 minecraft:diamond_block
fill 26 188 611 26 188 612 minecraft:diamond_block
fill 26 188 614 26 188 615 minecraft:diamond_block
fill 26 188 617 26 188 618 minecraft:diamond_block
fill 26 188 620 26 188 621 minecraft:diamond_block
fill 26 188 629 26 188 630 minecraft:diamond_block
fill 26 188 632 26 188 633 minecraft:diamond_block
fill 26 188 635 26 188 636 minecraft:diamond_block
fill 26 188 638 26 188 639 minecraft:diamond_block
fill 26 188 641 26 188 642 minecraft:diamond_block
fill 26 188 644 26 188 645 minecraft:diamond_block
fill 27 188 605 28 188 606 minecraft:stone
fill 27 188 608 28 188 609 minecraft:deepslate
fill 27 188 611 28 188 612 minecraft:stone
fill 27 188 614 28 188 615 minecraft:deepslate
fill 27 188 617 28 188 618 minecraft:stone
fill 27 188 620 28 188 621 minecraft:deepslate
fill 27 188 624 27 188 626 minecraft:glowstone
fill 27 188 629 28 188 630 minecraft:stone
fill 27 188 632 28 188 633 minecraft:deepslate
fill 27 188 635 28 188 636 minecraft:stone
fill 27 188 638 28 188 639 minecraft:deepslate
fill 27 188 641 28 188 642 minecraft:stone
fill 27 188 644 28 188 645 minecraft:deepslate
fill 28 188 623 28 188 624 minecraft:stone
fill 28 188 625 42 188 625 minecraft:diamond_block
fill 28 188 626 28 188 627 minecraft:deepslate
fill 29 188 605 29 188 606 minecraft:diamond_block
fill 29 188 608 29 188 609 minecraft:diamond_block
fill 29 188 611 29 188 612 minecraft:diamond_block
fill 29 188 614 29 188 615 minecraft:diamond_block
fill 29 188 617 29 188 618 minecraft:diamond_block
fill 29 188 620 29 188 621 minecraft:diamond_block
fill 29 188 623 29 188 624 minecraft:diamond_block
fill 29 188 626 29 188 627 minecraft:diamond_block
fill 29 188 629 29 188 630 minecraft:diamond_block
fill 29 188 632 29 188 633 minecraft:diamond_block
fill 29 188 635 29 188 636 minecraft:diamond_block
fill 29 188 638 29 188 639 minecraft:diamond_block
fill 29 188 641 29 188 642 minecraft:diamond_block
fill 29 188 644 29 188 645 minecraft:diamond_block
fill 30 188 605 31 188 606 minecraft:deepslate
fill 30 188 608 31 188 609 minecraft:stone
fill 30 188 611 31 188 612 minecraft:deepslate
fill 30 188 614 31 188 615 minecraft:stone
fill 30 188 617 31 188 618 minecraft:deepslate
fill 30 188 620 31 188 621 minecraft:stone
fill 30 188 623 31 188 624 minecraft:deepslate
fill 30 188 626 31 188 627 minecraft:stone
fill 30 188 629 31 188 630 minecraft:deepslate
fill 30 188 632 31 188 633 minecraft:stone
fill 30 188 635 31 188 636 minecraft:deepslate
fill 30 188 638 31 188 639 minecraft:stone
fill 30 188 641 31 188 642 minecraft:deepslate
fill 30 188 644 31 188 645 minecraft:stone
fill 32 188 605 32 188 606 minecraft:diamond_block
fill 32 188 608 32 188 609 minecraft:diamond_block
fill 32 188 611 32 188 612 minecraft:diamond_block
fill 32 188 614 32 188 615 minecraft:diamond_block
fill 32 188 617 32 188 618 minecraft:diamond_block
fill 32 188 620 32 188 621 minecraft:diamond_block
fill 32 188 623 32 188 624 minecraft:diamond_block
fill 32 188 626 32 188 627 minecraft:diamond_block
fill 32 188 629 32 188 630 minecraft:diamond_block
fill 32 188 632 32 188 633 minecraft:diamond_block
fill 32 188 635 32 188 636 minecraft:diamond_block
fill 32 188 638 32 188 639 minecraft:diamond_block
fill 32 188 641 32 188 642 minecraft:diamond_block
fill 32 188 644 32 188 645 minecraft:diamond_block
fill 33 188 605 34 188 606 minecraft:stone
fill 33 188 608 34 188 609 minecraft:deepslate
fill 33 188 611 34 188 612 minecraft:stone
fill 33 188 614 34 188 615 minecraft:deepslate
fill 33 188 617 34 188 618 minecraft:stone
fill 33 188 620 34 188 621 minecraft:deepslate
fill 33 188 623 34 188 624 minecraft:stone
fill 33 188 626 34 188 627 minecraft:deepslate
fill 33 188 629 34 188 630 minecraft:stone
fill 33 188 632 34 188 633 minecraft:deepslate
fill 33 188 635 34 188 636 minecraft:stone
fill 33 188 638 34 188 639 minecraft:deepslate
fill 33 188 641 34 188 642 minecraft:stone
fill 33 188 644 34 188 645 minecraft:deepslate
fill 35 188 605 35 188 606 minecraft:diamond_block
fill 35 188 608 35 188 609 minecraft:diamond_block
fill 35 188 611 35 188 612 minecraft:diamond_block
fill 35 188 614 35 188 615 minecraft:diamond_block
fill 35 188 617 35 188 618 minecraft:diamond_block
fill 35 188 620 35 188 621 minecraft:diamond_block
fill 35 188 623 35 188 624 minecraft:diamond_block
fill 35 188 626 35 188 627 minecraft:diamond_block
fill 35 188 629 35 188 630 minecraft:diamond_block
fill 35 188 632 35 188 633 minecraft:diamond_block
fill 35 188 635 35 188 636 minecraft:diamond_block
fill 35 188 638 35 188 639 minecraft:diamond_block
fill 35 188 641 35 188 642 minecraft:diamond_block
fill 35 188 644 35 188 645 minecraft:diamond_block
fill 36 188 605 37 188 606 minecraft:deepslate
fill 36 188 608 37 188 609 minecraft:stone
fill 36 188 611 37 188 612 minecraft:deepslate
fill 36 188 614 37 188 615 minecraft:stone
fill 36 188 617 37 188 618 minecraft:deepslate
fill 36 188 620 37 188 621 minecraft:stone
fill 36 188 623 37 188 624 minecraft:deepslate
fill 36 188 626 37 188 627 minecraft:stone
fill 36 188 629 37 188 630 minecraft:deepslate
fill 36 188 632 37 188 633 minecraft:stone
fill 36 188 635 37 188 636 minecraft:deepslate
fill 36 188 638 37 188 639 minecraft:stone
fill 36 188 641 37 188 642 minecraft:deepslate
fill 36 188 644 37 188 645 minecraft:stone
fill 38 188 605 38 188 606 minecraft:diamond_block
fill 38 188 608 38 188 609 minecraft:diamond_block
fill 38 188 611 38 188 612 minecraft:diamond_block
fill 38 188 614 38 188 615 minecraft:diamond_block
fill 38 188 617 38 188 618 minecraft:diamond_block
fill 38 188 620 38 188 621 minecraft:diamond_block
fill 38 188 623 38 188 624 minecraft:diamond_block
fill 38 188 626 38 188 627 minecraft:diamond_block
fill 38 188 629 38 188 630 minecraft:diamond_block
fill 38 188 632 38 188 633 minecraft:diamond_block
fill 38 188 635 38 188 636 minecraft:diamond_block
fill 38 188 638 38 188 639 minecraft:diamond_block
fill 38 188 641 38 188 642 minecraft:diamond_block
fill 38 188 644 38 188 645 minecraft:diamond_block
fill 39 188 605 40 188 606 minecraft:stone
fill 39 188 608 40 188 609 minecraft:deepslate
fill 39 188 611 40 188 612 minecraft:stone
fill 39 188 614 40 188 615 minecraft:deepslate
fill 39 188 617 40 188 618 minecraft:stone
fill 39 188 620 40 188 621 minecraft:deepslate
fill 39 188 623 40 188 624 minecraft:stone
fill 39 188 626 40 188 627 minecraft:deepslate
fill 39 188 629 40 188 630 minecraft:stone
fill 39 188 632 40 188 633 minecraft:deepslate
fill 39 188 635 40 188 636 minecraft:stone
fill 39 188 638 40 188 639 minecraft:deepslate
fill 39 188 641 40 188 642 minecraft:stone
fill 39 188 644 40 188 645 minecraft:deepslate
fill 41 188 605 41 188 606 minecraft:diamond_block
fill 41 188 608 41 188 609 minecraft:diamond_block
fill 41 188 611 41 188 612 minecraft:diamond_block
fill 41 188 614 41 188 615 minecraft:diamond_block
fill 41 188 617 41 188 618 minecraft:diamond_block
fill 41 188 620 41 188 621 minecraft:diamond_block
fill 41 188 623 41 188 624 minecraft:diamond_block
fill 41 188 626 41 188 627 minecraft:diamond_block
fill 41 188 629 41 188 630 minecraft:diamond_block
fill 41 188 632 41 188 633 minecraft:diamond_block
fill 41 188 635 41 188 636 minecraft:diamond_block
fill 41 188 638 41 188 639 minecraft:diamond_block
fill 41 188 641 41 188 642 minecraft:diamond_block
fill 41 188 644 41 188 645 minecraft:diamond_block
fill 42 188 621 42 188 622 minecraft:white_concrete
fill 0 189 605 0 191 606 minecraft:blue_concrete
setblock 0 189 607 minecraft:glowstone
fill 0 189 608 0 191 610 minecraft:blue_concrete
fill 14 189 625 16 189 625 minecraft:red_nether_bricks
fill 15 189 623 17 189 624 minecraft:red_nether_bricks
fill 15 189 626 17 189 627 minecraft:red_nether_bricks
fill 16 189 622 19 189 622 minecraft:red_nether_bricks
fill 16 189 628 19 189 628 minecraft:red_nether_bricks
fill 17 189 621 23 189 621 minecraft:red_nether_bricks
fill 17 189 625 18 189 625 minecraft:quartz_block
fill 17 189 629 23 189 629 minecraft:red_nether_bricks
fill 18 189 623 18 190 624 minecraft:quartz_block
fill 18 189 626 18 190 627 minecraft:quartz_block
fill 19 189 623 19 190 623 minecraft:quartz_block
fill 19 189 627 22 189 627 minecraft:quartz_block
fill 20 189 622 20 190 622 minecraft:quartz_block
fill 20 189 628 20 190 628 minecraft:quartz_block
fill 21 189 622 24 189 622 minecraft:red_nether_bricks
fill 21 189 628 24 189 628 minecraft:red_nether_bricks
fill 22 189 623 22 189 626 minecraft:quartz_block
fill 23 189 623 25 189 624 minecraft:red_nether_bricks
fill 23 189 625 23 190 625 minecraft:quartz_block
fill 23 189 626 25 189 627 minecraft:red_nether_bricks
fill 24 189 625 26 189 625 minecraft:red_nether_bricks
fill 24 189 646 24 235 646 minecraft:blue_concrete
setblock 35 189 646 minecraft:white_concrete
fill 36 189 646 36 239 646 minecraft:blue_concrete
setblock 42 189 619 minecraft:diamond_block
fill 42 189 621 42 189 622 minecraft:blue_concrete
fill 42 189 625 42 220 625 minecraft:blue_concrete
setblock 42 189 641 minecraft:diamond_block
fill 0 190 607 0 239 607 minecraft:blue_concrete
setblock 0 190 612 minecraft:diamond_block
fill 0 190 613 0 235 614 minecraft:blue_concrete
setblock 0 190 615 minecraft:diamond_block
fill 0 190 617 0 197 620 minecraft:blue_concrete
setblock 0 190 621 minecraft:diamond_block
setblock 0 190 622 minecraft:white_concrete
fill 13 190 623 15 198 627 minecraft:red_nether_bricks
fill 14 190 622 17 196 622 minecraft:red_nether_bricks
fill 14 190 628 17 196 628 minecraft:red_nether_bricks
fill 15 190 621 19 195 621 minecraft:red_nether_bricks
fill 15 190 629 19 195 629 minecraft:red_nether_bricks
fill 16 190 620 24 197 620 minecraft:red_nether_bricks
fill 16 190 623 16 195 624 minecraft:red_nether_bricks
fill 16 190 625 17 190 625 minecraft:quartz_block
fill 16 190 626 16 195 627 minecraft:red_nether_bricks
fill 16 190 630 24 197 630 minecraft:red_nether_bricks
fill 17 190 623 17 190 624 minecraft:quartz_block
fill 17 190 626 17 190 627 minecraft:quartz_block
fill 18 190 622 19 190 622 minecraft:quartz_block
fill 18 190 628 19 190 628 minecraft:quartz_block
fill 19 190 619 21 199 619 minecraft:red_nether_bricks
setblock 19 190 627 minecraft:quartz_block
fill 19 190 631 21 199 631 minecraft:red_nether_bricks
setblock 20 190 621 minecraft:quartz_block
setblock 20 190 629 minecraft:quartz_block
fill 21 190 621 25 195 621 minecraft:red_nether_bricks
fill 21 190 622 22 190 622 minecraft:quartz_block
fill 21 190 627 22 190 628 minecraft:quartz_block
fill 21 190 629 25 195 629 minecraft:red_nether_bricks
setblock 22 190 604 minecraft:glowstone
fill 22 190 623 23 190 624 minecraft:quartz_block
fill 22 190 626 23 190 626 minecraft:quartz_block
fill 23 190 604 23 239 604 minecraft:blue_concrete
fill 23 190 622 26 190 622 minecraft:red_nether_bricks
setblock 23 190 627 minecraft:quartz_block
fill 23 190 628 26 190 628 minecraft:red_nether_bricks
fill 24 190 623 24 190 624 minecraft:red_nether_bricks
setblock 24 190 625 minecraft:quartz_block
fill 24 190 626 24 190 627 minecraft:red_nether_bricks
setblock 25 190 623 minecraft:red_nether_bricks
fill 25 190 624 31 196 626 minecraft:nether_bricks
setblock 25 190 627 minecraft:red_nether_bricks
fill 26 190 623 30 196 623 minecraft:nether_bricks
fill 26 190 627 30 196 627 minecraft:nether_bricks
fill 35 190 646 35 191 646 minecraft:blue_concrete
fill 42 190 619 42 198 619 minecraft:blue_concrete
setblock 42 190 621 minecraft:glowstone
fill 42 190 622 42 216 622 minecraft:blue_concrete
setblock 42 190 641 minecraft:glowstone
fill 0 191 612 0 197 612 minecraft:blue_concrete
fill 0 191 615 0 236 615 minecraft:blue_concrete
fill 0 191 621 0 191 622 minecraft:blue_concrete
setblock 10 191 604 minecraft:diamond_block
fill 12 191 623 12 198 627 minecraft:red_nether_bricks
fill 13 191 622 13 199 622 minecraft:red_nether_bricks
fill 13 191 628 13 199 628 minecraft:red_nether_bricks
fill 14 191 621 14 199 621 minecraft:red_nether_bricks
fill 14 191 629 14 199 629 minecraft:red_nether_bricks
fill 15 191 620 15 199 620 minecraft:red_nether_bricks
fill 15 191 630 15 199 630 minecraft:red_nether_bricks
fill 16 191 619 18 198 619 minecraft:red_nether_bricks
fill 16 191 625 17 192 625 minecraft:red_nether_bricks
fill 16 191 631 18 198 631 minecraft:red_nether_bricks
fill 17 191 623 17 192 624 minecraft:red_nether_bricks
fill 17 191 626 17 192 627 minecraft:red_nether_bricks
fill 18 191 622 18 191 623 minecraft:red_nether_bricks
fill 18 191 627 18 191 628 minecraft:red_nether_bricks
fill 19 191 622 24 191 622 minecraft:red_nether_bricks
fill 19 191 628 24 191 628 minecraft:red_nether_bricks
fill 20 191 621 20 195 621 minecraft:red_nether_bricks
fill 20 191 629 20 195 629 minecraft:red_nether_bricks
fill 22 191 604 22 212 604 minecraft:blue_concrete
fill 22 191 619 24 198 619 minecraft:red_nether_bricks
fill 22 191 623 23 191 623 minecraft:red_nether_bricks
fill 22 191 627 23 191 627 minecraft:red_nether_bricks
fill 22 191 631 24 198 631 minecraft:red_nether_bricks
setblock 23 191 624 minecraft:red_nether_bricks
fill 23 191 625 24 192 625 minecraft:nether_bricks
setblock 23 191 626 minecraft:red_nether_bricks
fill 24 191 623 24 195 624 minecraft:nether_bricks
fill 24 191 626 24 195 627 minecraft:nether_bricks
fill 25 191 620 25 199 620 minecraft:red_nether_bricks
fill 25 191 622 25 195 623 minecraft:nether_bricks
fill 25 191 627 25 195 628 minecraft:nether_bricks
fill 25 191 630 25 199 630 minecraft:red_nether_bricks
setblock 26 191 621 minecraft:red_nether_bricks
fill 26 191 622 31 195 622 minecraft:nether_bricks
fill 26 191 628 31 195 628 minecraft:nether_bricks
setblock 26 191 629 minecraft:red_nether_bricks
fill 31 191 623 32 193 623 minecraft:nether_bricks
fill 31 191 627 32 193 627 minecraft:nether_bricks
fill 32 191 624 32 195 626 minecraft:nether_bricks
fill 33 191 625 33 195 625 minecraft:nether_bricks
fill 42 191 621 42 226 621 minecraft:blue_concrete
setblock 42 191 629 minecraft:diamond_block
fill 42 191 641 42 208 641 minecraft:blue_concrete
fill 0 192 605 0 223 605 minecraft:blue_concrete
setblock 0 192 606 minecraft:white_concrete
setblock 0 192 608 minecraft:glowstone
fill 0 192 609 0 232 610 minecraft:blue_concrete
fill 0 192 621 0 239 621 minecraft:blue_concrete
setblock 0 192 622 minecraft:white_concrete
fill 10 192 604 10 236 604 minecraft:blue_concrete
fill 10 192 634 10 200 634 minecraft:dirt
fill 11 192 624 11 197 626 minecraft:red_nether_bricks
fill 12 192 622 12 198 622 minecraft:red_nether_bricks
fill 12 192 628 12 198 628 minecraft:red_nether_bricks
fill 13 192 621 13 198 621 minecraft:red_nether_bricks
fill 13 192 629 13 198 629 minecraft:red_nether_bricks
fill 14 192 620 14 198 620 minecraft:red_nether_bricks
fill 14 192 630 14 198 630 minecraft:red_nether_bricks
fill 15 192 619 15 197 619 minecraft:red_nether_bricks
fill 15 192 631 15 197 631 minecraft:red_nether_bricks
fill 17 192 618 23 196 618 minecraft:red_nether_bricks
fill 17 192 632 23 196 632 minecraft:red_nether_bricks
fill 18 192 622 23 192 622 minecraft:red_nether_bricks
fill 18 192 628 23 192 628 minecraft:red_nether_bricks
fill 23 192 623 23 192 624 minecraft:nether_bricks
fill 23 192 626 23 192 627 minecraft:nether_bricks
fill 24 192 622 24 194 622 minecraft:nether_bricks
fill 24 192 628 24 194 628 minecraft:nether_bricks
fill 25 192 619 25 197 619 minecraft:red_nether_bricks
fill 25 192 631 25 197 631 minecraft:red_nether_bricks
fill 26 192 620 26 198 620 minecraft:red_nether_bricks
fill 26 192 621 30 194 621 minecraft:nether_bricks
fill 26 192 629 30 194 629 minecraft:nether_bricks
fill 26 192 630 26 198 630 minecraft:red_nether_bricks
fill 27 192 604 29 194 604 minecraft:blue_concrete
fill 27 192 634 27 200 635 minecraft:dirt
fill 29 192 632 29 193 632 minecraft:coal_block
setblock 30 192 604 minecraft:glowstone
fill 30 192 620 34 196 620 minecraft:dirt
fill 31 192 604 31 196 604 minecraft:blue_concrete
fill 31 192 619 34 196 619 minecraft:dirt
fill 31 192 621 35 196 621 minecraft:dirt
fill 32 192 622 32 194 622 minecraft:nether_bricks
fill 32 192 628 32 194 628 minecraft:nether_bricks
fill 33 192 622 34 196 622 minecraft:dirt
fill 33 192 623 33 194 624 minecraft:nether_bricks
fill 33 192 626 33 194 627 minecraft:nether_bricks
setblock 35 192 646 minecraft:glowstone
fill 42 192 629 42 235 629 minecraft:blue_concrete
fill 0 193 606 0 216 606 minecraft:blue_concrete
fill 0 193 608 0 237 608 minecraft:blue_concrete
fill 0 193 622 0 239 622 minecraft:blue_concrete
setblock 0 193 642 minecraft:diamond_block
fill 11 193 623 11 197 623 minecraft:red_nether_bricks
fill 11 193 627 11 197 627 minecraft:red_nether_bricks
fill 12 193 621 12 197 621 minecraft:red_nether_bricks
fill 12 193 629 12 197 629 minecraft:red_nether_bricks
fill 13 193 620 13 197 620 minecraft:red_nether_bricks
fill 13 193 630 13 197 630 minecraft:red_nether_bricks
fill 14 193 619 14 196 619 minecraft:red_nether_bricks
fill 14 193 631 14 196 631 minecraft:red_nether_bricks
fill 16 193 618 16 196 618 minecraft:red_nether_bricks
fill 16 193 625 16 195 625 minecraft:red_nether_bricks
fill 16 193 632 16 196 632 minecraft:red_nether_bricks
fill 17 193 623 17 194 623 minecraft:red_nether_bricks
fill 17 193 627 17 194 627 minecraft:red_nether_bricks
fill 18 193 622 18 194 622 minecraft:red_nether_bricks
fill 18 193 628 18 194 628 minecraft:red_nether_bricks
fill 22 193 622 23 194 622 minecraft:red_nether_bricks
fill 22 193 628 23 194 628 minecraft:red_nether_bricks
fill 23 193 623 23 194 623 minecraft:nether_bricks
fill 23 193 627 23 194 627 minecraft:nether_bricks
fill 24 193 618 24 196 618 minecraft:red_nether_bricks
fill 24 193 625 24 195 625 minecraft:nether_bricks
fill 24 193 632 24 196 632 minecraft:red_nether_bricks
fill 26 193 619 26 196 619 minecraft:red_nether_bricks
fill 26 193 631 26 196 631 minecraft:red_nether_bricks
fill 26 193 634 26 200 635 minecraft:dirt
fill 27 193 620 27 197 620 minecraft:red_nether_bricks
fill 27 193 630 27 197 630 minecraft:red_nether_bricks
fill 27 193 633 27 200 633 minecraft:dirt
fill 28 193 634 28 200 634 minecraft:dirt
fill 30 193 604 30 214 604 minecraft:blue_concrete
fill 30 193 619 30 196 619 minecraft:dirt
fill 32 193 618 33 196 618 minecraft:dirt
fill 34 193 623 34 196 623 minecraft:dirt
fill 35 193 620 35 196 620 minecraft:dirt
fill 35 193 622 35 196 622 minecraft:dirt
fill 35 193 646 35 198 646 minecraft:blue_concrete
setblock 42 193 608 minecraft:white_concrete
fill 42 193 609 42 194 611 minecraft:blue_concrete
setblock 42 193 620 minecraft:diamond_block
setblock 0 194 630 minecraft:white_concrete
fill 0 194 642 0 239 642 minecraft:blue_concrete
fill 10 194 635 10 200 635 minecraft:dirt
fill 11 194 622 11 196 622 minecraft:red_nether_bricks
fill 11 194 628 11 196 628 minecraft:red_nether_bricks
fill 11 194 634 11 200 634 minecraft:dirt
fill 26 194 633 26 200 633 minecraft:dirt
fill 27 194 636 27 200 636 minecraft:dirt
fill 28 194 633 28 200 633 minecraft:dirt
fill 28 194 635 28 200 635 minecraft:dirt
fill 29 194 620 29 196 620 minecraft:dirt
fill 31 194 618 31 196 618 minecraft:dirt
fill 31 194 623 31 196 623 minecraft:nether_bricks
fill 31 194 627 31 196 627 minecraft:nether_bricks
fill 32 194 623 32 195 623 minecraft:black_concrete
fill 32 194 627 32 195 627 minecraft:black_concrete
fill 34 194 618 34 196 618 minecraft:dirt
fill 34 194 624 34 196 624 minecraft:dirt
fill 35 194 619 35 196 619 minecraft:dirt
fill 35 194 623 35 196 623 minecraft:dirt
fill 36 194 621 36 196 621 minecraft:dirt
fill 42 194 608 42 239 608 minecraft:blue_concrete
fill 42 194 620 42 213 620 minecraft:blue_concrete
fill 0 195 630 0 236 630 minecraft:blue_concrete
fill 1 195 640 2 196 642 minecraft:diamond_block
setblock 3 195 607 minecraft:light[level=14]
setblock 3 195 615 minecraft:light[level=14]
setblock 3 195 623 minecraft:light[level=14]
setblock 3 195 631 minecraft:light[level=14]
setblock 3 195 639 minecraft:light[level=14]
fill 3 195 641 3 197 641 minecraft:diamond_block
fill 9 195 634 9 200 634 minecraft:dirt
fill 10 195 633 11 200 633 minecraft:dirt
setblock 11 195 607 minecraft:light[level=14]
setblock 11 195 615 minecraft:light[level=14]
setblock 11 195 631 minecraft:light[level=14]
fill 11 195 635 11 200 635 minecraft:dirt
setblock 11 195 639 minecraft:light[level=14]
setblock 17 195 604 minecraft:glowstone
setblock 19 195 607 minecraft:light[level=14]
setblock 19 195 615 minecraft:light[level=14]
setblock 19 195 639 minecraft:light[level=14]
fill 23 195 622 24 196 622 minecraft:red_nether_bricks
fill 23 195 628 24 196 628 minecraft:red_nether_bricks
fill 25 195 618 27 196 618 minecraft:raw_iron_block
fill 25 195 633 25 200 635 minecraft:dirt
fill 26 195 617 27 196 617 minecraft:raw_iron_block
fill 26 195 621 28 197 621 minecraft:red_nether_bricks
fill 26 195 629 28 197 629 minecraft:red_nether_bricks
fill 26 195 636 26 200 636 minecraft:dirt
fill 27 195 604 28 211 604 minecraft:blue_concrete
setblock 27 195 607 minecraft:light[level=14]
setblock 27 195 615 minecraft:light[level=14]
setblock 27 195 631 minecraft:light[level=14]
fill 27 195 632 27 200 632 minecraft:dirt
setblock 27 195 639 minecraft:light[level=14]
fill 28 195 636 28 200 636 minecraft:dirt
setblock 29 195 604 minecraft:diamond_block
fill 29 195 619 29 196 619 minecraft:dirt
fill 29 195 621 30 196 621 minecraft:dirt
fill 29 195 634 29 200 635 minecraft:dirt
fill 30 195 618 30 196 618 minecraft:dirt
fill 32 195 617 33 196 617 minecraft:dirt
fill 32 195 622 32 196 622 minecraft:dirt
setblock 32 195 646 minecraft:white_concrete
fill 33 195 623 33 196 623 minecraft:dirt
setblock 33 195 624 minecraft:nether_bricks
setblock 33 195 626 minecraft:nether_bricks
setblock 33 195 646 minecraft:diamond_block
setblock 35 195 607 minecraft:light[level=14]
setblock 35 195 615 minecraft:light[level=14]
fill 35 195 618 35 196 618 minecraft:dirt
fill 35 195 624 35 196 624 minecraft:dirt
setblock 35 195 631 minecraft:light[level=14]
setblock 35 195 639 minecraft:light[level=14]
fill 36 195 619 36 196 620 minecraft:dirt
fill 36 195 622 36 196 622 minecraft:dirt
fill 42 195 609 42 198 609 minecraft:blue_concrete
setblock 42 195 610 minecraft:glowstone
fill 42 195 611 42 210 611 minecraft:blue_concrete
setblock 0 196 623 minecraft:glowstone
fill 0 196 624 0 203 624 minecraft:blue_concrete
setblock 0 196 635 minecraft:diamond_block
fill 0 196 636 0 206 637 minecraft:blue_concrete
setblock 3 196 640 minecraft:diamond_block
setblock 3 196 642 minecraft:diamond_block
fill 4 196 641 5 197 641 minecraft:diamond_block
fill 9 196 633 9 200 633 minecraft:dirt
fill 9 196 635 9 200 635 minecraft:dirt
fill 10 196 636 10 199 636 minecraft:dirt
setblock 11 196 604 minecraft:white_concrete
fill 12 196 604 13 239 604 minecraft:blue_concrete
fill 12 196 633 12 198 635 minecraft:dirt
fill 15 196 621 18 197 621 minecraft:red_nether_bricks
fill 15 196 629 18 197 629 minecraft:red_nether_bricks
fill 16 196 623 16 197 623 minecraft:red_nether_bricks
fill 16 196 627 16 197 627 minecraft:red_nether_bricks
fill 17 196 604 17 210 604 minecraft:blue_concrete
fill 22 196 621 25 197 621 minecraft:red_nether_bricks
fill 22 196 629 25 197 629 minecraft:red_nether_bricks
fill 24 196 623 24 197 623 minecraft:red_nether_bricks
fill 24 196 627 24 197 627 minecraft:red_nether_bricks
fill 25 196 622 26 199 622 minecraft:red_nether_bricks
setblock 25 196 623 minecraft:nether_bricks
setblock 25 196 627 minecraft:nether_bricks
fill 25 196 628 26 199 628 minecraft:red_nether_bricks
fill 25 196 636 25 200 636 minecraft:dirt
fill 26 196 632 26 200 632 minecraft:dirt
fill 27 196 622 29 196 622 minecraft:nether_bricks
fill 27 196 628 29 196 628 minecraft:nether_bricks
fill 27 196 637 27 200 637 minecraft:dirt
setblock 28 196 620 minecraft:dirt
fill 28 196 632 28 200 632 minecraft:dirt
fill 29 196 604 29 205 604 minecraft:blue_concrete
setblock 29 196 618 minecraft:dirt
fill 29 196 633 29 200 633 minecraft:dirt
fill 29 196 636 29 200 636 minecraft:dirt
fill 30 196 622 31 196 622 minecraft:dirt
setblock 31 196 617 minecraft:dirt
fill 31 196 628 32 197 628 minecraft:coal_block
fill 32 196 623 32 196 624 minecraft:dirt
setblock 32 196 625 minecraft:nether_bricks
fill 32 196 627 32 197 627 minecraft:coal_block
fill 32 196 646 33 214 646 minecraft:blue_concrete
fill 33 196 624 33 196 625 minecraft:dirt
setblock 34 196 617 minecraft:dirt
setblock 34 196 625 minecraft:dirt
setblock 36 196 623 minecraft:dirt
setblock 37 196 621 minecraft:dirt
fill 42 196 610 42 237 610 minecraft:blue_concrete
setblock 0 197 623 minecraft:blue_concrete
setblock 0 197 631 minecraft:glowstone
fill 0 197 632 0 225 632 minecraft:blue_concrete
fill 0 197 635 0 236 635 minecraft:blue_concrete
setblock 2 197 641 minecraft:diamond_block
setblock 4 197 604 minecraft:diamond_block
setblock 6 197 641 minecraft:diamond_block
fill 8 197 634 8 200 634 minecraft:dirt
fill 9 197 632 11 200 632 minecraft:dirt
fill 9 197 636 9 200 636 minecraft:dirt
fill 11 197 604 11 239 604 minecraft:blue_concrete
fill 11 197 636 11 200 636 minecraft:dirt
fill 14 197 622 16 198 622 minecraft:red_nether_bricks
fill 14 197 628 16 198 628 minecraft:red_nether_bricks
setblock 17 197 618 minecraft:red_nether_bricks
setblock 17 197 632 minecraft:red_nether_bricks
setblock 17 197 646 minecraft:white_concrete
setblock 18 197 618 minecraft:black_concrete
setblock 18 197 632 minecraft:black_concrete
fill 18 197 646 18 217 646 minecraft:blue_concrete
fill 19 197 618 23 197 618 minecraft:red_nether_bricks
fill 19 197 632 23 197 632 minecraft:red_nether_bricks
fill 24 197 622 24 198 622 minecraft:red_nether_bricks
fill 24 197 628 24 198 628 minecraft:red_nether_bricks
fill 24 197 633 24 200 635 minecraft:dirt
fill 25 197 623 26 198 627 minecraft:red_nether_bricks
fill 25 197 632 25 200 632 minecraft:dirt
fill 26 197 637 26 200 637 minecraft:dirt
fill 27 197 622 28 198 624 minecraft:red_nether_bricks
fill 27 197 625 29 197 625 minecraft:nether_bricks
fill 27 197 626 28 198 628 minecraft:red_nether_bricks
fill 27 197 631 27 200 631 minecraft:dirt
fill 28 197 637 28 200 637 minecraft:dirt
fill 29 197 623 29 197 624 minecraft:red_nether_bricks
fill 29 197 626 29 197 627 minecraft:red_nether_bricks
fill 29 197 632 29 200 632 minecraft:dirt
fill 30 197 634 30 200 635 minecraft:dirt
setblock 31 197 604 minecraft:glowstone
setblock 31 197 627 minecraft:coal_block
fill 32 197 621 33 199 621 minecraft:stone
fill 33 197 604 34 235 604 minecraft:blue_concrete
setblock 35 197 604 minecraft:diamond_block
fill 0 198 612 0 200 612 minecraft:moss_block
fill 0 198 617 0 224 619 minecraft:blue_concrete
setblock 0 198 620 minecraft:glowstone
setblock 0 198 623 minecraft:diamond_block
fill 0 198 628 0 200 628 minecraft:moss_block
setblock 0 198 631 minecraft:blue_concrete
fill 0 198 644 0 200 644 minecraft:moss_block
fill 4 198 604 4 200 604 minecraft:moss_block
fill 8 198 633 8 200 633 minecraft:dirt
fill 8 198 635 8 200 635 minecraft:dirt
setblock 9 198 604 minecraft:white_concrete
fill 10 198 637 10 200 637 minecraft:dirt
fill 12 198 632 12 200 632 minecraft:dirt
fill 12 198 636 12 200 636 minecraft:dirt
fill 13 198 633 13 198 635 minecraft:dirt
fill 14 198 646 14 200 646 minecraft:moss_block
fill 15 198 617 18 198 617 minecraft:black_concrete
fill 15 198 621 17 198 621 minecraft:red_nether_bricks
fill 15 198 629 17 198 629 minecraft:red_nether_bricks
fill 15 198 633 18 198 633 minecraft:black_concrete
fill 16 198 620 22 198 620 minecraft:red_nether_bricks
fill 16 198 630 22 198 630 minecraft:red_nether_bricks
fill 17 198 646 17 212 646 minecraft:blue_concrete
fill 19 198 618 21 198 618 minecraft:red_nether_bricks
fill 19 198 632 21 198 632 minecraft:red_nether_bricks
fill 20 198 604 20 200 604 minecraft:moss_block
fill 23 198 620 23 198 621 minecraft:shroomlight
fill 23 198 629 23 198 630 minecraft:shroomlight
fill 24 198 620 24 198 621 minecraft:red_nether_bricks
fill 24 198 629 24 198 630 minecraft:red_nether_bricks
fill 24 198 632 24 200 632 minecraft:dirt
fill 24 198 636 24 200 636 minecraft:dirt
fill 25 198 621 27 198 621 minecraft:red_nether_bricks
fill 25 198 629 27 198 629 minecraft:red_nether_bricks
fill 25 198 637 25 200 637 minecraft:dirt
fill 26 198 631 26 200 631 minecraft:dirt
fill 27 198 625 28 199 625 minecraft:red_nether_bricks
fill 28 198 631 28 200 631 minecraft:dirt
fill 29 198 637 29 200 637 minecraft:dirt
fill 30 198 633 30 200 633 minecraft:dirt
fill 30 198 636 30 200 636 minecraft:dirt
fill 30 198 646 30 200 646 minecraft:moss_block
fill 31 198 604 31 228 604 minecraft:blue_concrete
setblock 34 198 646 minecraft:diamond_block
fill 35 198 604 35 239 604 minecraft:blue_concrete
fill 36 198 604 36 200 604 minecraft:moss_block
fill 42 198 614 42 200 614 minecraft:moss_block
fill 42 198 615 42 219 617 minecraft:blue_concrete
fill 42 198 630 42 200 630 minecraft:moss_block
fill 0 199 620 0 240 620 minecraft:blue_concrete
fill 0 199 623 0 239 623 minecraft:blue_concrete
setblock 0 199 631 minecraft:white_concrete
fill 7 199 634 7 200 634 minecraft:dirt
fill 8 199 632 8 200 632 minecraft:dirt
fill 8 199 636 8 200 636 minecraft:dirt
fill 9 199 604 9 206 604 minecraft:blue_concrete
fill 9 199 631 11 200 631 minecraft:dirt
fill 9 199 637 9 200 637 minecraft:dirt
fill 11 199 637 12 200 637 minecraft:dirt
fill 12 199 615 14 199 615 minecraft:black_concrete
fill 12 199 625 14 199 625 minecraft:red_nether_bricks
fill 12 199 633 12 200 634 minecraft:dirt
fill 12 199 635 14 199 635 minecraft:black_concrete
fill 13 199 616 17 199 616 minecraft:black_concrete
fill 13 199 623 15 199 624 minecraft:red_nether_bricks
fill 13 199 626 15 199 627 minecraft:red_nether_bricks
fill 13 199 632 13 200 633 minecraft:dirt
fill 13 199 634 17 199 634 minecraft:black_concrete
setblock 13 199 636 minecraft:dirt
fill 14 199 622 15 199 622 minecraft:red_nether_bricks
fill 14 199 628 15 199 628 minecraft:red_nether_bricks
fill 15 199 621 16 199 621 minecraft:red_nether_bricks
fill 15 199 629 16 199 629 minecraft:red_nether_bricks
fill 16 199 620 19 199 620 minecraft:red_nether_bricks
fill 16 199 630 19 199 630 minecraft:red_nether_bricks
setblock 18 199 617 minecraft:black_concrete
setblock 18 199 619 minecraft:red_nether_bricks
setblock 18 199 631 minecraft:red_nether_bricks
setblock 18 199 633 minecraft:black_concrete
setblock 21 199 620 minecraft:red_nether_bricks
setblock 21 199 630 minecraft:red_nether_bricks
setblock 22 199 619 minecraft:red_nether_bricks
fill 22 199 620 24 199 620 minecraft:shroomlight
fill 22 199 630 24 199 630 minecraft:shroomlight
setblock 22 199 631 minecraft:red_nether_bricks
fill 23 199 633 23 200 635 minecraft:dirt
setblock 24 199 621 minecraft:shroomlight
setblock 24 199 629 minecraft:shroomlight
fill 24 199 637 24 200 637 minecraft:dirt
fill 25 199 621 26 199 621 minecraft:red_nether_bricks
fill 25 199 623 27 199 624 minecraft:red_nether_bricks
fill 25 199 626 27 199 627 minecraft:red_nether_bricks
fill 25 199 629 26 199 629 minecraft:red_nether_bricks
fill 25 199 631 25 200 631 minecraft:dirt
fill 25 199 638 28 200 638 minecraft:dirt
fill 26 199 625 26 200 625 minecraft:red_nether_bricks
setblock 27 199 622 minecraft:red_nether_bricks
setblock 27 199 628 minecraft:red_nether_bricks
fill 29 199 631 29 200 631 minecraft:dirt
fill 30 199 632 30 200 632 minecraft:dirt
fill 30 199 637 30 200 637 minecraft:dirt
fill 31 199 634 31 200 635 minecraft:dirt
fill 34 199 646 34 206 646 minecraft:blue_concrete
setblock 35 199 646 minecraft:white_concrete
setblock 42 199 609 minecraft:white_concrete
setblock 42 199 619 minecraft:white_concrete
fill 0 200 631 0 226 631 minecraft:blue_concrete
fill 7 200 632 7 200 633 minecraft:dirt
fill 7 200 635 7 200 636 minecraft:dirt
setblock 8 200 631 minecraft:dirt
setblock 8 200 637 minecraft:dirt
setblock 10 200 614 minecraft:black_concrete
setblock 10 200 636 minecraft:black_concrete
setblock 12 200 631 minecraft:dirt
fill 12 200 635 13 200 635 minecraft:dirt
setblock 13 200 614 minecraft:black_concrete
fill 13 200 634 14 200 634 minecraft:dirt
setblock 13 200 636 minecraft:black_concrete
fill 14 200 615 15 200 615 minecraft:black_concrete
fill 14 200 623 14 200 627 minecraft:red_nether_bricks
setblock 14 200 633 minecraft:dirt
fill 14 200 635 15 200 635 minecraft:black_concrete
fill 15 200 622 15 200 623 minecraft:red_nether_bricks
fill 15 200 627 15 200 628 minecraft:red_nether_bricks
fill 16 200 621 16 201 621 minecraft:blackstone
fill 16 200 629 16 201 629 minecraft:blackstone
setblock 17 200 615 minecraft:black_concrete
fill 17 200 620 17 201 620 minecraft:blackstone
fill 17 200 630 17 201 630 minecraft:blackstone
setblock 17 200 635 minecraft:black_concrete
setblock 18 200 616 minecraft:black_concrete
setblock 18 200 620 minecraft:red_nether_bricks
setblock 18 200 630 minecraft:red_nether_bricks
setblock 18 200 634 minecraft:black_concrete
fill 19 200 609 19 201 609 minecraft:dirt
setblock 22 200 620 minecraft:red_nether_bricks
setblock 22 200 630 minecraft:red_nether_bricks
setblock 23 200 632 minecraft:dirt
setblock 23 200 636 minecraft:dirt
setblock 24 200 621 minecraft:red_nether_bricks
setblock 24 200 629 minecraft:red_nether_bricks
setblock 24 200 631 minecraft:dirt
fill 25 200 622 25 200 623 minecraft:red_nether_bricks
fill 25 200 627 25 200 628 minecraft:red_nether_bricks
fill 25 200 630 28 200 630 minecraft:dirt
fill 26 200 623 26 200 624 minecraft:red_nether_bricks
fill 26 200 626 26 200 627 minecraft:red_nether_bricks
setblock 29 200 638 minecraft:dirt
setblock 30 200 631 minecraft:dirt
fill 31 200 620 34 202 622 minecraft:oak_leaves[persistent=true]
fill 31 200 632 31 200 633 minecraft:dirt
setblock 31 200 636 minecraft:dirt
fill 32 200 619 33 202 619 minecraft:oak_leaves[persistent=true]
fill 35 200 646 35 239 646 minecraft:blue_concrete
fill 42 200 609 42 235 609 minecraft:blue_concrete
fill 42 200 619 42 239 619 minecraft:blue_concrete
fill 0 201 612 0 206 612 minecraft:blue_concrete
fill 0 201 628 0 206 628 minecraft:blue_concrete
fill 0 201 644 0 206 644 minecraft:blue_concrete
fill 4 201 604 4 206 604 minecraft:blue_concrete
fill 6 201 612 7 201 612 minecraft:black_concrete
fill 6 201 638 7 201 638 minecraft:black_concrete
fill 7 201 613 8 201 613 minecraft:black_concrete
fill 7 201 637 8 201 637 minecraft:black_concrete
fill 10 201 634 10 204 634 minecraft:stone
fill 11 201 613 12 201 613 minecraft:black_concrete
fill 11 201 637 12 201 637 minecraft:black_concrete
fill 11 201 643 13 204 645 minecraft:diamond_block
setblock 14 201 614 minecraft:black_concrete
setblock 14 201 636 minecraft:black_concrete
setblock 14 201 646 minecraft:diamond_block
fill 16 201 614 16 202 614 minecraft:black_concrete
fill 16 201 620 16 203 620 minecraft:blackstone
fill 16 201 630 16 203 630 minecraft:blackstone
fill 16 201 636 16 202 636 minecraft:black_concrete
fill 18 201 615 18 202 615 minecraft:black_concrete
fill 18 201 635 18 202 635 minecraft:black_concrete
fill 20 201 604 20 202 604 minecraft:blue_concrete
fill 27 201 634 27 204 634 minecraft:stone
fill 30 201 646 30 206 646 minecraft:blue_concrete
setblock 31 201 619 minecraft:oak_leaves[persistent=true]
fill 32 201 623 33 201 623 minecraft:oak_leaves[persistent=true]
fill 36 201 604 36 206 604 minecraft:blue_concrete
setblock 42 201 614 minecraft:blue_concrete
fill 42 201 630 42 206 630 minecraft:blue_concrete
fill 42 201 634 42 212 635 minecraft:blue_concrete
setblock 42 201 636 minecraft:diamond_block
fill 42 201 637 42 203 640 minecraft:blue_concrete
setblock 6 202 612 minecraft:black_concrete
setblock 6 202 638 minecraft:black_concrete
fill 9 202 611 9 203 611 minecraft:black_concrete
fill 9 202 639 9 203 639 minecraft:black_concrete
setblock 10 202 612 minecraft:black_concrete
setblock 10 202 638 minecraft:black_concrete
fill 10 202 644 10 203 644 minecraft:diamond_block
fill 11 202 641 13 204 642 minecraft:diamond_block
fill 13 202 613 13 203 613 minecraft:black_concrete
fill 13 202 637 13 203 637 minecraft:black_concrete
fill 14 202 644 14 203 644 minecraft:diamond_block
fill 14 202 646 14 206 646 minecraft:blue_concrete
fill 15 202 619 15 204 620 minecraft:blackstone
fill 15 202 630 15 204 631 minecraft:blackstone
fill 16 202 613 16 203 613 minecraft:black_concrete
fill 16 202 619 16 203 619 minecraft:blackstone
fill 16 202 631 16 203 631 minecraft:blackstone
fill 16 202 637 16 203 637 minecraft:black_concrete
fill 18 202 614 18 203 614 minecraft:black_concrete
fill 18 202 636 18 203 636 minecraft:black_concrete
setblock 25 202 646 minecraft:glowstone
setblock 42 202 614 minecraft:diamond_block
fill 42 202 636 42 237 636 minecraft:blue_concrete
setblock 3 203 607 minecraft:light[level=14]
setblock 3 203 615 minecraft:light[level=14]
setblock 3 203 623 minecraft:light[level=14]
setblock 3 203 631 minecraft:light[level=14]
setblock 3 203 639 minecraft:light[level=14]
setblock 11 203 607 minecraft:light[level=14]
setblock 11 203 615 minecraft:light[level=14]
setblock 11 203 623 minecraft:light[level=14]
setblock 11 203 631 minecraft:light[level=14]
setblock 11 203 639 minecraft:light[level=14]
fill 11 203 640 13 204 640 minecraft:diamond_block
fill 12 203 612 12 204 612 minecraft:black_concrete
fill 12 203 638 12 204 638 minecraft:black_concrete
fill 12 203 639 12 204 639 minecraft:diamond_block
fill 14 203 619 14 205 619 minecraft:blackstone
fill 14 203 631 14 205 631 minecraft:blackstone
setblock 19 203 607 minecraft:light[level=14]
setblock 19 203 615 minecraft:light[level=14]
setblock 19 203 639 minecraft:light[level=14]
setblock 20 203 604 minecraft:white_concrete
fill 25 203 646 25 225 646 minecraft:blue_concrete
setblock 27 203 607 minecraft:light[level=14]
setblock 27 203 615 minecraft:light[level=14]
setblock 27 203 623 minecraft:light[level=14]
setblock 27 203 631 minecraft:light[level=14]
setblock 27 203 639 minecraft:light[level=14]
setblock 35 203 607 minecraft:light[level=14]
setblock 35 203 615 minecraft:light[level=14]
setblock 35 203 623 minecraft:light[level=14]
setblock 35 203 631 minecraft:light[level=14]
setblock 35 203 639 minecraft:light[level=14]
setblock 37 203 604 minecraft:white_concrete
fill 42 203 614 42 206 614 minecraft:blue_concrete
fill 42 203 626 42 239 626 minecraft:blue_concrete
setblock 42 203 627 minecraft:glowstone
fill 42 203 628 42 239 628 minecraft:blue_concrete
setblock 0 204 624 minecraft:white_concrete
fill 9 204 633 9 206 635 minecraft:oak_leaves[persistent=true]
fill 10 204 632 11 204 632 minecraft:stone
fill 10 204 633 12 205 633 minecraft:oak_leaves[persistent=true]
fill 10 204 635 10 206 636 minecraft:oak_leaves[persistent=true]
fill 11 204 634 12 206 635 minecraft:oak_leaves[persistent=true]
setblock 12 204 637 minecraft:diamond_block
fill 14 204 618 15 204 618 minecraft:blackstone
fill 14 204 632 15 204 632 minecraft:blackstone
fill 15 204 611 15 204 612 minecraft:black_concrete
fill 15 204 638 15 204 639 minecraft:black_concrete
setblock 18 204 613 minecraft:black_concrete
setblock 18 204 637 minecraft:black_concrete
fill 20 204 604 20 206 604 minecraft:blue_concrete
fill 25 204 634 26 206 634 minecraft:oak_leaves[persistent=true]
fill 26 204 633 28 206 633 minecraft:oak_leaves[persistent=true]
fill 26 204 635 27 206 636 minecraft:oak_leaves[persistent=true]
fill 26 204 637 26 205 637 minecraft:stone
fill 28 204 634 28 206 635 minecraft:oak_leaves[persistent=true]
fill 37 204 604 37 235 604 minecraft:blue_concrete
setblock 42 204 612 minecraft:diamond_block
fill 42 204 627 42 235 627 minecraft:blue_concrete
fill 42 204 637 42 220 639 minecraft:blue_concrete
setblock 42 204 640 minecraft:glowstone
fill 0 205 624 0 240 624 minecraft:blue_concrete
setblock 8 205 634 minecraft:oak_leaves[persistent=true]
setblock 9 205 636 minecraft:oak_leaves[persistent=true]
fill 10 205 632 11 205 632 minecraft:oak_leaves[persistent=true]
fill 10 205 634 10 206 634 minecraft:oak_leaves[persistent=true]
setblock 11 205 636 minecraft:oak_leaves[persistent=true]
fill 13 205 618 13 206 619 minecraft:blackstone
fill 13 205 631 13 206 632 minecraft:blackstone
fill 14 205 618 14 206 618 minecraft:blackstone
fill 14 205 632 14 206 632 minecraft:blackstone
setblock 15 205 611 minecraft:black_concrete
setblock 15 205 619 minecraft:blackstone
setblock 15 205 631 minecraft:blackstone
setblock 15 205 639 minecraft:black_concrete
fill 18 205 612 18 206 612 minecraft:black_concrete
fill 18 205 638 18 206 638 minecraft:black_concrete
setblock 25 205 633 minecraft:oak_leaves[persistent=true]
setblock 25 205 635 minecraft:oak_leaves[persistent=true]
setblock 27 205 632 minecraft:oak_leaves[persistent=true]
fill 27 205 634 27 206 634 minecraft:oak_leaves[persistent=true]
setblock 28 205 636 minecraft:oak_leaves[persistent=true]
fill 29 205 634 29 205 635 minecraft:oak_leaves[persistent=true]
fill 42 205 612 42 228 612 minecraft:blue_concrete
setblock 42 205 623 minecraft:white_concrete
fill 42 205 624 42 239 624 minecraft:blue_concrete
fill 42 205 640 42 213 640 minecraft:blue_concrete
setblock 0 206 616 minecraft:white_concrete
fill 10 206 633 11 206 633 minecraft:oak_leaves[persistent=true]
fill 12 206 617 12 207 618 minecraft:blackstone
fill 12 206 632 12 207 633 minecraft:blackstone
fill 13 206 617 13 207 617 minecraft:blackstone
fill 13 206 633 13 207 633 minecraft:blackstone
setblock 29 206 604 minecraft:white_concrete
fill 42 206 623 42 232 623 minecraft:blue_concrete
setblock 42 206 642 minecraft:glowstone
fill 42 206 643 42 237 643 minecraft:blue_concrete
fill 0 207 612 0 209 612 minecraft:moss_block
fill 0 207 616 0 231 616 minecraft:blue_concrete
fill 0 207 628 0 209 628 minecraft:moss_block
fill 0 207 636 0 215 636 minecraft:blue_concrete
setblock 0 207 637 minecraft:diamond_block
setblock 0 207 643 minecraft:white_concrete
fill 0 207 644 0 209 644 minecraft:moss_block
fill 4 207 604 4 209 604 minecraft:moss_block
setblock 9 207 604 minecraft:glowstone
setblock 13 207 618 minecraft:blackstone
setblock 13 207 632 minecraft:blackstone
fill 14 207 646 14 209 646 minecraft:moss_block
fill 20 207 604 20 209 604 minecraft:moss_block
fill 29 207 604 29 235 604 minecraft:blue_concrete
fill 30 207 646 30 209 646 minecraft:moss_block
setblock 34 207 646 minecraft:glowstone
fill 36 207 604 36 209 604 minecraft:moss_block
fill 42 207 614 42 209 614 minecraft:moss_block
fill 42 207 630 42 209 630 minecraft:moss_block
fill 42 207 642 42 224 642 minecraft:blue_concrete
fill 0 208 637 0 239 637 minecraft:blue_concrete
fill 0 208 643 0 224 643 minecraft:blue_concrete
fill 9 208 604 9 239 604 minecraft:blue_concrete
setblock 12 208 617 minecraft:blackstone
setblock 12 208 633 minecraft:blackstone
fill 34 208 646 34 231 646 minecraft:blue_concrete
setblock 37 208 646 minecraft:glowstone
fill 38 208 646 38 239 646 minecraft:blue_concrete
fill 28 209 646 28 239 646 minecraft:blue_concrete
setblock 29 209 646 minecraft:glowstone
fill 37 209 646 37 221 646 minecraft:blue_concrete
setblock 42 209 641 minecraft:glowstone
fill 0 210 612 0 215 612 minecraft:blue_concrete
fill 0 210 628 0 215 628 minecraft:blue_concrete
setblock 0 210 633 minecraft:white_concrete
fill 0 210 634 0 239 634 minecraft:blue_concrete
fill 0 210 644 0 215 644 minecraft:blue_concrete
fill 4 210 604 4 215 604 minecraft:blue_concrete
fill 14 210 646 14 215 646 minecraft:blue_concrete
fill 20 210 604 20 215 604 minecraft:blue_concrete
fill 29 210 646 30 215 646 minecraft:blue_concrete
fill 36 210 604 36 215 604 minecraft:blue_concrete
fill 36 210 615 36 211 615 minecraft:diamond_block
fill 42 210 614 42 215 614 minecraft:blue_concrete
fill 42 210 630 42 215 630 minecraft:blue_concrete
fill 42 210 641 42 235 641 minecraft:blue_concrete
setblock 0 211 625 minecraft:diamond_block
fill 0 211 626 0 226 627 minecraft:blue_concrete
fill 0 211 633 0 225 633 minecraft:blue_concrete
setblock 3 211 607 minecraft:light[level=14]
setblock 3 211 615 minecraft:light[level=14]
setblock 3 211 623 minecraft:light[level=14]
setblock 3 211 631 minecraft:light[level=14]
setblock 3 211 639 minecraft:light[level=14]
setblock 11 211 607 minecraft:light[level=14]
setblock 11 211 615 minecraft:light[level=14]
setblock 11 211 623 minecraft:light[level=14]
setblock 11 211 631 minecraft:light[level=14]
setblock 11 211 639 minecraft:light[level=14]
setblock 17 211 604 minecraft:glowstone
setblock 19 211 607 minecraft:light[level=14]
setblock 19 211 615 minecraft:light[level=14]
setblock 19 211 623 minecraft:light[level=14]
setblock 19 211 631 minecraft:light[level=14]
setblock 19 211 639 minecraft:light[level=14]
setblock 23 211 646 minecraft:diamond_block
setblock 27 211 607 minecraft:light[level=14]
setblock 27 211 615 minecraft:light[level=14]
setblock 27 211 623 minecraft:light[level=14]
setblock 27 211 631 minecraft:light[level=14]
setblock 27 211 639 minecraft:light[level=14]
fill 28 211 630 28 212 630 minecraft:coal_block
setblock 35 211 607 minecraft:light[level=14]
setblock 35 211 615 minecraft:light[level=14]
setblock 35 211 623 minecraft:light[level=14]
setblock 35 211 631 minecraft:light[level=14]
setblock 35 211 639 minecraft:light[level=14]
fill 37 211 614 41 212 616 minecraft:diamond_block
setblock 42 211 611 minecraft:glowstone
fill 0 212 625 0 235 625 minecraft:blue_concrete
fill 17 212 604 17 239 604 minecraft:blue_concrete
fill 23 212 646 23 233 646 minecraft:blue_concrete
fill 27 212 604 27 239 604 minecraft:blue_concrete
setblock 28 212 604 minecraft:diamond_block
fill 40 212 613 40 213 613 minecraft:diamond_block
fill 40 212 617 40 213 617 minecraft:diamond_block
fill 42 212 611 42 239 611 minecraft:blue_concrete
fill 14 213 635 14 214 635 minecraft:coal_block
setblock 17 213 646 minecraft:white_concrete
setblock 22 213 604 minecraft:glowstone
fill 28 213 604 28 235 604 minecraft:blue_concrete
setblock 32 213 604 minecraft:glowstone
fill 38 213 614 41 213 616 minecraft:diamond_block
setblock 41 213 646 minecraft:white_concrete
fill 42 213 634 42 239 634 minecraft:blue_concrete
setblock 42 213 635 minecraft:diamond_block
setblock 8 214 646 minecraft:diamond_block
fill 9 214 646 9 239 646 minecraft:blue_concrete
fill 17 214 646 17 216 646 minecraft:blue_concrete
fill 22 214 604 22 239 604 minecraft:blue_concrete
fill 32 214 604 32 216 604 minecraft:blue_concrete
fill 39 214 614 41 214 616 minecraft:diamond_block
fill 41 214 646 41 218 646 minecraft:blue_concrete
setblock 42 214 620 minecraft:glowstone
fill 42 214 635 42 239 635 minecraft:blue_concrete
setblock 42 214 640 minecraft:diamond_block
fill 8 215 646 8 239 646 minecraft:blue_concrete
setblock 30 215 604 minecraft:diamond_block
setblock 32 215 646 minecraft:glowstone
fill 33 215 646 33 236 646 minecraft:blue_concrete
fill 42 215 620 42 225 620 minecraft:blue_concrete
fill 42 215 640 42 239 640 minecraft:blue_concrete
fill 0 216 612 0 218 612 minecraft:moss_block
fill 0 216 628 0 218 628 minecraft:moss_block
setblock 0 216 636 minecraft:glowstone
fill 0 216 644 0 218 644 minecraft:moss_block
setblock 0 216 645 minecraft:white_concrete
fill 0 216 646 0 240 646 minecraft:blue_concrete
setblock 3 216 646 minecraft:white_concrete
fill 4 216 604 4 218 604 minecraft:moss_block
fill 14 216 646 14 218 646 minecraft:moss_block
fill 20 216 604 20 218 604 minecraft:moss_block
setblock 24 216 604 minecraft:diamond_block
fill 29 216 646 29 239 646 minecraft:blue_concrete
fill 30 216 604 30 239 604 minecraft:blue_concrete
fill 30 216 646 30 218 646 minecraft:moss_block
fill 32 216 646 32 239 646 minecraft:blue_concrete
fill 36 216 604 36 218 604 minecraft:moss_block
fill 42 216 614 42 218 614 minecraft:moss_block
fill 42 216 630 42 218 630 minecraft:moss_block
fill 0 217 606 0 218 606 minecraft:glowstone
fill 0 217 636 0 238 636 minecraft:blue_concrete
fill 0 217 645 0 225 645 minecraft:blue_concrete
fill 3 217 646 3 230 646 minecraft:blue_concrete
setblock 17 217 646 minecraft:diamond_block
fill 24 217 604 24 239 604 minecraft:blue_concrete
setblock 32 217 604 minecraft:diamond_block
setblock 42 217 622 minecraft:glowstone
fill 17 218 646 17 230 646 minecraft:blue_concrete
setblock 18 218 646 minecraft:white_concrete
fill 32 218 604 32 237 604 minecraft:blue_concrete
fill 42 218 622 42 236 622 minecraft:blue_concrete
fill 0 219 606 0 239 606 minecraft:blue_concrete
fill 0 219 612 0 224 612 minecraft:blue_concrete
fill 0 219 628 0 224 628 minecraft:blue_concrete
fill 0 219 644 0 221 644 minecraft:blue_concrete
setblock 3 219 607 minecraft:light[level=14]
setblock 3 219 615 minecraft:light[level=14]
setblock 3 219 623 minecraft:light[level=14]
setblock 3 219 631 minecraft:light[level=14]
setblock 3 219 639 minecraft:light[level=14]
fill 4 219 604 4 224 604 minecraft:blue_concrete
setblock 11 219 607 minecraft:light[level=14]
setblock 11 219 615 minecraft:light[level=14]
setblock 11 219 623 minecraft:light[level=14]
setblock 11 219 631 minecraft:light[level=14]
setblock 11 219 639 minecraft:light[level=14]
fill 14 219 646 14 224 646 minecraft:blue_concrete
fill 18 219 646 18 230 646 minecraft:blue_concrete
setblock 19 219 607 minecraft:light[level=14]
setblock 19 219 615 minecraft:light[level=14]
setblock 19 219 623 minecraft:light[level=14]
setblock 19 219 631 minecraft:light[level=14]
setblock 19 219 639 minecraft:light[level=14]
fill 20 219 604 20 224 604 minecraft:blue_concrete
setblock 27 219 607 minecraft:light[level=14]
setblock 27 219 615 minecraft:light[level=14]
setblock 27 219 623 minecraft:light[level=14]
setblock 27 219 631 minecraft:light[level=14]
setblock 27 219 639 minecraft:light[level=14]
fill 30 219 646 30 224 646 minecraft:blue_concrete
setblock 35 219 607 minecraft:light[level=14]
setblock 35 219 615 minecraft:light[level=14]
setblock 35 219 623 minecraft:light[level=14]
setblock 35 219 631 minecraft:light[level=14]
setblock 35 219 639 minecraft:light[level=14]
fill 36 219 604 36 220 604 minecraft:blue_concrete
setblock 41 219 646 minecraft:white_concrete
fill 42 219 614 42 224 614 minecraft:blue_concrete
fill 42 219 630 42 224 630 minecraft:blue_concrete
setblock 1 220 646 minecraft:diamond_block
setblock 25 220 604 minecraft:glowstone
fill 27 220 608 28 221 608 minecraft:moss_block
fill 41 220 646 41 239 646 minecraft:blue_concrete
fill 42 220 615 42 227 616 minecraft:blue_concrete
setblock 42 220 617 minecraft:glowstone
fill 1 221 646 1 235 646 minecraft:blue_concrete
setblock 6 221 604 minecraft:diamond_block
fill 7 221 604 7 239 604 minecraft:blue_concrete
fill 25 221 604 25 222 604 minecraft:blue_concrete
setblock 36 221 604 minecraft:glowstone
fill 42 221 617 42 225 617 minecraft:blue_concrete
setblock 42 221 625 minecraft:diamond_block
fill 42 221 637 42 239 638 minecraft:blue_concrete
setblock 42 221 639 minecraft:white_concrete
setblock 0 222 644 minecraft:white_concrete
fill 6 222 604 6 239 604 minecraft:blue_concrete
fill 36 222 604 36 224 604 minecraft:blue_concrete
setblock 37 222 646 minecraft:glowstone
fill 42 222 625 42 237 625 minecraft:blue_concrete
fill 42 222 639 42 239 639 minecraft:blue_concrete
fill 0 223 644 0 224 644 minecraft:blue_concrete
setblock 25 223 604 minecraft:glowstone
fill 37 223 646 37 239 646 minecraft:blue_concrete
setblock 42 223 632 minecraft:diamond_block
setblock 0 224 605 minecraft:glowstone
fill 25 224 604 25 235 604 minecraft:blue_concrete
fill 30 224 621 30 225 621 minecraft:dirt
fill 42 224 632 42 237 632 minecraft:blue_concrete
fill 0 225 605 0 229 605 minecraft:blue_concrete
fill 0 225 612 0 227 612 minecraft:moss_block
fill 0 225 617 0 227 618 minecraft:blue_concrete
setblock 0 225 619 minecraft:glowstone
fill 0 225 628 0 227 628 minecraft:moss_block
setblock 0 225 643 minecraft:diamond_block
fill 0 225 644 0 227 644 minecraft:moss_block
fill 4 225 604 4 227 604 minecraft:moss_block
fill 14 225 646 14 227 646 minecraft:moss_block
fill 20 225 604 20 227 604 minecraft:moss_block
fill 30 225 646 30 227 646 minecraft:moss_block
fill 36 225 604 36 227 604 minecraft:moss_block
fill 42 225 614 42 227 614 minecraft:moss_block
fill 42 225 630 42 227 630 minecraft:moss_block
setblock 42 225 642 minecraft:diamond_block
fill 0 226 619 0 231 619 minecraft:blue_concrete
setblock 0 226 632 minecraft:glowstone
setblock 0 226 633 minecraft:white_concrete
fill 0 226 643 0 242 643 minecraft:blue_concrete
setblock 0 226 645 minecraft:glowstone
setblock 25 226 646 minecraft:glowstone
setblock 42 226 617 minecraft:diamond_block
setblock 42 226 620 minecraft:glowstone
fill 42 226 642 42 239 642 minecraft:blue_concrete
setblock 0 227 626 minecraft:white_concrete
fill 0 227 627 0 239 627 minecraft:blue_concrete
setblock 0 227 631 minecraft:white_concrete
fill 0 227 632 0 239 633 minecraft:blue_concrete
setblock 0 227 639 minecraft:glowstone
setblock 0 227 640 minecraft:diamond_block
fill 0 227 645 0 239 645 minecraft:blue_concrete
setblock 3 227 607 minecraft:light[level=14]
setblock 3 227 615 minecraft:light[level=14]
setblock 3 227 623 minecraft:light[level=14]
setblock 3 227 631 minecraft:light[level=14]
setblock 3 227 639 minecraft:light[level=14]
setblock 11 227 607 minecraft:light[level=14]
setblock 11 227 615 minecraft:light[level=14]
setblock 11 227 623 minecraft:light[level=14]
setblock 11 227 631 minecraft:light[level=14]
setblock 11 227 639 minecraft:light[level=14]
setblock 19 227 607 minecraft:light[level=14]
setblock 19 227 615 minecraft:light[level=14]
setblock 19 227 623 minecraft:light[level=14]
setblock 19 227 631 minecraft:light[level=14]
setblock 19 227 639 minecraft:light[level=14]
fill 25 227 646 25 239 646 minecraft:blue_concrete
setblock 27 227 607 minecraft:light[level=14]
setblock 27 227 615 minecraft:light[level=14]
setblock 27 227 623 minecraft:light[level=14]
setblock 27 227 631 minecraft:light[level=14]
setblock 27 227 639 minecraft:light[level=14]
setblock 35 227 607 minecraft:light[level=14]
setblock 35 227 615 minecraft:light[level=14]
setblock 35 227 623 minecraft:light[level=14]
setblock 35 227 631 minecraft:light[level=14]
setblock 35 227 639 minecraft:light[level=14]
fill 42 227 617 42 240 617 minecraft:blue_concrete
fill 42 227 620 42 232 620 minecraft:blue_concrete
setblock 42 227 621 minecraft:glowstone
fill 0 228 612 0 236 612 minecraft:blue_concrete
setblock 0 228 617 minecraft:white_concrete
fill 0 228 618 0 239 618 minecraft:blue_concrete
fill 0 228 626 0 237 626 minecraft:blue_concrete
fill 0 228 628 0 236 628 minecraft:blue_concrete
fill 0 228 631 0 236 631 minecraft:blue_concrete
fill 0 228 639 0 239 640 minecraft:blue_concrete
fill 0 228 644 0 236 644 minecraft:blue_concrete
fill 4 228 604 4 239 604 minecraft:blue_concrete
setblock 7 228 646 minecraft:white_concrete
fill 14 228 646 14 236 646 minecraft:blue_concrete
fill 19 228 646 20 235 646 minecraft:blue_concrete
fill 20 228 604 20 230 604 minecraft:blue_concrete
setblock 21 228 646 minecraft:diamond_block
fill 30 228 646 30 239 646 minecraft:blue_concrete
fill 36 228 604 36 239 604 minecraft:blue_concrete
fill 42 228 614 42 239 614 minecraft:blue_concrete
setblock 42 228 615 minecraft:diamond_block
schedule function dropper:buildpart/144_2 1t
