fill 368 25 469 368 28 469 minecraft:pink_terracotta
setblock 368 25 503 minecraft:red_nether_bricks
fill 368 25 504 368 28 504 minecraft:pink_terracotta
setblock 369 25 467 minecraft:red_nether_bricks
fill 369 25 468 369 28 468 minecraft:pink_terracotta
setblock 369 25 472 minecraft:red_nether_bricks
setblock 369 25 488 minecraft:pink_terracotta
setblock 369 25 503 minecraft:pink_terracotta
setblock 370 25 466 minecraft:red_nether_bricks
fill 370 25 467 370 28 467 minecraft:pink_terracotta
setblock 370 25 471 minecraft:red_nether_bricks
fill 370 25 472 370 28 472 minecraft:pink_terracotta
setblock 370 25 476 minecraft:white_concrete
setblock 370 25 486 minecraft:red_nether_bricks
fill 370 25 487 370 27 487 minecraft:pink_terracotta
setblock 370 25 491 minecraft:red_nether_bricks
fill 370 25 492 370 28 492 minecraft:pink_terracotta
setblock 370 25 501 minecraft:red_nether_bricks
fill 370 25 502 370 28 502 minecraft:pink_terracotta
setblock 330 26 465 minecraft:red_nether_bricks
fill 330 26 466 330 29 466 minecraft:pink_terracotta
setblock 330 26 470 minecraft:red_nether_bricks
setblock 330 26 473 minecraft:white_concrete
setblock 330 26 485 minecraft:red_nether_bricks
fill 330 26 486 330 26 489 minecraft:pink_terracotta
setblock 330 26 490 minecraft:red_nether_bricks
fill 330 26 491 330 29 491 minecraft:pink_terracotta
setblock 330 26 495 minecraft:red_nether_bricks
fill 330 26 496 330 29 496 minecraft:pink_terracotta
setblock 330 26 500 minecraft:red_nether_bricks
fill 330 26 501 330 29 501 minecraft:pink_terracotta
setblock 331 26 464 minecraft:red_nether_bricks
setblock 331 26 489 minecraft:red_nether_bricks
fill 331 26 490 331 29 490 minecraft:pink_terracotta
setblock 331 26 504 minecraft:red_nether_bricks
setblock 332 26 464 minecraft:white_concrete
setblock 332 26 504 minecraft:pink_terracotta
setblock 343 26 504 minecraft:white_concrete
setblock 345 26 465 minecraft:red_nether_bricks
setblock 346 26 464 minecraft:red_nether_bricks
fill 346 26 465 346 29 465 minecraft:pink_terracotta
fill 347 26 464 350 26 464 minecraft:pink_terracotta
setblock 350 26 466 minecraft:red_terracotta
setblock 350 26 468 minecraft:red_terracotta
setblock 351 26 464 minecraft:red_nether_bricks
fill 351 26 465 353 26 465 minecraft:red_terracotta
setblock 351 26 469 minecraft:red_terracotta
fill 352 26 464 353 26 464 minecraft:pink_terracotta
setblock 353 26 469 minecraft:red_terracotta
fill 354 26 466 354 26 468 minecraft:red_terracotta
fill 357 26 464 357 29 464 minecraft:pink_terracotta
fill 358 26 480 358 27 480 minecraft:red_terracotta
fill 359 26 479 359 27 479 minecraft:red_terracotta
setblock 360 26 465 minecraft:red_nether_bricks
fill 360 26 481 360 27 481 minecraft:red_terracotta
setblock 361 26 464 minecraft:red_nether_bricks
fill 361 26 465 361 28 466 minecraft:pink_terracotta
fill 362 26 464 362 29 464 minecraft:pink_terracotta
setblock 364 26 466 minecraft:red_nether_bricks
fill 364 26 467 364 29 467 minecraft:pink_terracotta
setblock 365 26 465 minecraft:red_nether_bricks
fill 365 26 466 365 29 466 minecraft:pink_terracotta
setblock 366 26 464 minecraft:red_nether_bricks
fill 366 26 465 366 29 465 minecraft:pink_terracotta
setblock 366 26 504 minecraft:red_nether_bricks
fill 367 26 464 367 29 464 minecraft:pink_terracotta
setblock 367 26 468 minecraft:red_nether_bricks
setblock 367 26 503 minecraft:red_nether_bricks
fill 367 26 504 367 29 504 minecraft:pink_terracotta
setblock 368 26 467 minecraft:red_nether_bricks
fill 368 26 468 368 29 468 minecraft:pink_terracotta
setblock 368 26 503 minecraft:pink_terracotta
setblock 369 26 466 minecraft:red_nether_bricks
fill 369 26 467 369 29 467 minecraft:pink_terracotta
setblock 369 26 471 minecraft:red_nether_bricks
fill 369 26 472 369 29 472 minecraft:pink_terracotta
setblock 370 26 465 minecraft:red_nether_bricks
fill 370 26 466 370 29 466 minecraft:pink_terracotta
setblock 370 26 470 minecraft:red_nether_bricks
fill 370 26 471 370 29 471 minecraft:pink_terracotta
setblock 370 26 486 minecraft:pink_terracotta
setblock 370 26 490 minecraft:red_nether_bricks
fill 370 26 491 370 29 491 minecraft:pink_terracotta
setblock 370 26 495 minecraft:red_nether_bricks
fill 370 26 501 370 27 501 minecraft:pink_terracotta
setblock 330 27 464 minecraft:red_nether_bricks
fill 330 27 465 330 28 465 minecraft:pink_terracotta
setblock 330 27 469 minecraft:red_nether_bricks
fill 330 27 470 330 30 470 minecraft:pink_terracotta
setblock 330 27 479 minecraft:white_concrete
fill 330 27 485 330 27 488 minecraft:pink_terracotta
setblock 330 27 489 minecraft:red_nether_bricks
fill 330 27 490 330 30 490 minecraft:pink_terracotta
setblock 330 27 494 minecraft:red_nether_bricks
fill 330 27 495 330 30 495 minecraft:pink_terracotta
setblock 330 27 499 minecraft:red_nether_bricks
fill 330 27 500 330 30 500 minecraft:pink_terracotta
setblock 330 27 504 minecraft:red_nether_bricks
setblock 331 27 488 minecraft:red_nether_bricks
fill 331 27 489 331 30 489 minecraft:pink_terracotta
setblock 331 27 493 minecraft:red_nether_bricks
fill 331 27 494 331 30 494 minecraft:pink_terracotta
setblock 331 27 504 minecraft:pink_terracotta
setblock 345 27 464 minecraft:red_nether_bricks
fill 345 27 465 345 30 465 minecraft:pink_terracotta
fill 346 27 464 349 27 464 minecraft:pink_terracotta
setblock 349 27 504 minecraft:white_concrete
setblock 350 27 464 minecraft:red_nether_bricks
setblock 351 27 464 minecraft:pink_terracotta
fill 355 27 504 355 28 504 minecraft:white_concrete
setblock 358 27 481 minecraft:red_terracotta
setblock 359 27 465 minecraft:red_nether_bricks
setblock 359 27 482 minecraft:red_terracotta
setblock 360 27 464 minecraft:red_nether_bricks
fill 360 27 465 360 30 465 minecraft:pink_terracotta
setblock 360 27 479 minecraft:red_terracotta
fill 361 27 464 361 30 464 minecraft:pink_terracotta
fill 362 27 504 362 29 504 minecraft:pink_terracotta
setblock 363 27 466 minecraft:red_nether_bricks
setblock 364 27 465 minecraft:red_nether_bricks
fill 364 27 466 364 30 466 minecraft:pink_terracotta
setblock 365 27 464 minecraft:red_nether_bricks
fill 365 27 465 365 30 465 minecraft:pink_terracotta
setblock 365 27 504 minecraft:red_nether_bricks
fill 366 27 464 366 30 464 minecraft:pink_terracotta
fill 366 27 504 366 30 504 minecraft:pink_terracotta
setblock 367 27 467 minecraft:red_nether_bricks
setblock 368 27 466 minecraft:red_nether_bricks
fill 368 27 467 368 30 467 minecraft:pink_terracotta
setblock 369 27 465 minecraft:red_nether_bricks
fill 369 27 466 369 30 466 minecraft:pink_terracotta
setblock 369 27 470 minecraft:red_nether_bricks
fill 369 27 471 369 30 471 minecraft:pink_terracotta
setblock 370 27 464 minecraft:red_nether_bricks
fill 370 27 465 370 30 465 minecraft:pink_terracotta
setblock 370 27 469 minecraft:red_nether_bricks
fill 370 27 470 370 30 470 minecraft:pink_terracotta
setblock 370 27 483 minecraft:white_concrete
setblock 370 27 489 minecraft:red_nether_bricks
fill 370 27 490 370 30 490 minecraft:pink_terracotta
setblock 370 27 494 minecraft:red_nether_bricks
fill 370 27 495 370 29 496 minecraft:pink_terracotta
setblock 370 27 504 minecraft:red_nether_bricks
setblock 330 28 464 minecraft:pink_terracotta
setblock 330 28 468 minecraft:red_nether_bricks
fill 330 28 469 330 31 469 minecraft:pink_terracotta
setblock 330 28 485 minecraft:white_concrete
fill 330 28 486 330 28 487 minecraft:pink_terracotta
setblock 330 28 488 minecraft:red_nether_bricks
fill 330 28 489 330 31 489 minecraft:pink_terracotta
setblock 330 28 493 minecraft:red_nether_bricks
fill 330 28 494 330 31 494 minecraft:pink_terracotta
setblock 330 28 498 minecraft:red_nether_bricks
fill 330 28 499 330 31 499 minecraft:pink_terracotta
setblock 330 28 503 minecraft:red_nether_bricks
setblock 330 28 504 minecraft:pink_terracotta
setblock 331 28 488 minecraft:pink_terracotta
setblock 331 28 492 minecraft:red_nether_bricks
fill 331 28 493 331 31 493 minecraft:pink_terracotta
fill 331 28 495 331 29 495 minecraft:pink_terracotta
setblock 336 28 504 minecraft:white_concrete
setblock 339 28 464 minecraft:white_concrete
fill 342 28 464 342 29 464 minecraft:pink_terracotta
setblock 344 28 464 minecraft:red_nether_bricks
fill 345 28 464 348 28 464 minecraft:pink_terracotta
setblock 349 28 464 minecraft:red_nether_bricks
setblock 350 28 464 minecraft:pink_terracotta
setblock 359 28 464 minecraft:red_nether_bricks
fill 359 28 465 359 31 465 minecraft:pink_terracotta
fill 360 28 464 360 31 464 minecraft:pink_terracotta
setblock 361 28 504 minecraft:white_concrete
setblock 362 28 466 minecraft:red_nether_bricks
setblock 363 28 465 minecraft:red_nether_bricks
fill 363 28 466 363 30 467 minecraft:pink_terracotta
setblock 364 28 464 minecraft:red_nether_bricks
fill 364 28 465 364 31 465 minecraft:pink_terracotta
setblock 364 28 504 minecraft:red_nether_bricks
fill 365 28 464 365 31 464 minecraft:pink_terracotta
fill 365 28 504 365 31 504 minecraft:pink_terracotta
setblock 366 28 467 minecraft:red_nether_bricks
setblock 367 28 466 minecraft:red_nether_bricks
setblock 368 28 465 minecraft:red_nether_bricks
fill 368 28 466 368 30 466 minecraft:pink_terracotta
setblock 368 28 470 minecraft:red_nether_bricks
setblock 369 28 464 minecraft:red_nether_bricks
fill 369 28 465 369 31 465 minecraft:pink_terracotta
setblock 369 28 469 minecraft:red_nether_bricks
fill 369 28 470 369 31 470 minecraft:pink_terracotta
fill 369 28 491 369 28 493 minecraft:pink_terracotta
setblock 369 28 504 minecraft:red_nether_bricks
fill 370 28 464 370 31 464 minecraft:pink_terracotta
setblock 370 28 468 minecraft:red_nether_bricks
fill 370 28 469 370 31 469 minecraft:pink_terracotta
setblock 370 28 473 minecraft:red_nether_bricks
setblock 370 28 477 minecraft:white_concrete
setblock 370 28 488 minecraft:red_nether_bricks
fill 370 28 489 370 31 489 minecraft:pink_terracotta
setblock 370 28 493 minecraft:red_nether_bricks
fill 370 28 494 370 31 494 minecraft:pink_terracotta
setblock 370 28 497 minecraft:pink_terracotta
setblock 370 28 498 minecraft:red_nether_bricks
setblock 370 28 503 minecraft:red_nether_bricks
fill 370 28 504 370 31 504 minecraft:pink_terracotta
setblock 330 29 467 minecraft:red_nether_bricks
fill 330 29 468 330 31 468 minecraft:pink_terracotta
setblock 330 29 471 minecraft:pink_terracotta
setblock 330 29 472 minecraft:white_concrete
setblock 330 29 486 minecraft:pink_terracotta
setblock 330 29 487 minecraft:red_nether_bricks
fill 330 29 488 330 32 488 minecraft:pink_terracotta
setblock 330 29 492 minecraft:red_nether_bricks
fill 330 29 493 330 32 493 minecraft:pink_terracotta
setblock 330 29 497 minecraft:red_nether_bricks
fill 330 29 498 330 32 498 minecraft:pink_terracotta
setblock 331 29 491 minecraft:red_nether_bricks
fill 331 29 492 331 32 492 minecraft:pink_terracotta
setblock 331 29 496 minecraft:red_nether_bricks
setblock 333 29 464 minecraft:white_concrete
setblock 342 29 504 minecraft:white_concrete
setblock 343 29 464 minecraft:red_nether_bricks
fill 344 29 464 347 29 464 minecraft:pink_terracotta
setblock 348 29 464 minecraft:red_nether_bricks
fill 349 29 464 349 31 464 minecraft:pink_terracotta
fill 356 29 464 356 30 464 minecraft:pink_terracotta
setblock 358 29 464 minecraft:red_nether_bricks
fill 358 29 465 358 32 465 minecraft:pink_terracotta
fill 359 29 464 359 32 464 minecraft:pink_terracotta
setblock 360 29 466 minecraft:pink_terracotta
setblock 361 29 465 minecraft:pink_terracotta
setblock 361 29 466 minecraft:red_nether_bricks
fill 361 29 504 361 30 504 minecraft:pink_terracotta
setblock 362 29 465 minecraft:red_nether_bricks
fill 362 29 466 362 31 467 minecraft:pink_terracotta
setblock 363 29 464 minecraft:red_nether_bricks
fill 363 29 465 363 32 465 minecraft:pink_terracotta
setblock 363 29 504 minecraft:red_nether_bricks
fill 364 29 464 364 32 464 minecraft:pink_terracotta
fill 364 29 504 364 32 504 minecraft:pink_terracotta
setblock 365 29 467 minecraft:red_nether_bricks
setblock 366 29 466 minecraft:red_nether_bricks
setblock 366 29 467 minecraft:pink_terracotta
fill 366 29 503 366 31 503 minecraft:pink_terracotta
setblock 367 29 465 minecraft:red_nether_bricks
fill 367 29 466 367 31 466 minecraft:pink_terracotta
setblock 368 29 464 minecraft:red_nether_bricks
fill 368 29 465 368 32 465 minecraft:pink_terracotta
setblock 368 29 469 minecraft:red_nether_bricks
fill 368 29 470 368 31 471 minecraft:pink_terracotta
setblock 368 29 504 minecraft:red_nether_bricks
fill 369 29 464 369 32 464 minecraft:pink_terracotta
setblock 369 29 468 minecraft:red_nether_bricks
fill 369 29 469 369 32 469 minecraft:pink_terracotta
fill 369 29 490 369 29 492 minecraft:pink_terracotta
setblock 369 29 493 minecraft:red_nether_bricks
fill 369 29 494 369 31 495 minecraft:pink_terracotta
fill 369 29 504 369 32 504 minecraft:pink_terracotta
setblock 370 29 467 minecraft:red_nether_bricks
fill 370 29 468 370 32 468 minecraft:pink_terracotta
setblock 370 29 472 minecraft:red_nether_bricks
fill 370 29 473 370 32 473 minecraft:pink_terracotta
fill 370 29 488 370 31 488 minecraft:pink_terracotta
setblock 370 29 492 minecraft:red_nether_bricks
fill 370 29 493 370 32 493 minecraft:pink_terracotta
setblock 370 29 497 minecraft:red_nether_bricks
fill 370 29 498 370 29 501 minecraft:pink_terracotta
setblock 370 29 502 minecraft:red_nether_bricks
fill 370 29 503 370 32 503 minecraft:pink_terracotta
setblock 330 30 467 minecraft:pink_terracotta
setblock 330 30 471 minecraft:red_nether_bricks
fill 330 30 472 330 33 472 minecraft:pink_terracotta
setblock 330 30 478 minecraft:white_concrete
setblock 330 30 486 minecraft:red_nether_bricks
fill 330 30 487 330 33 487 minecraft:pink_terracotta
setblock 330 30 491 minecraft:red_nether_bricks
fill 330 30 492 330 33 492 minecraft:pink_terracotta
setblock 330 30 496 minecraft:red_nether_bricks
fill 330 30 497 331 32 497 minecraft:pink_terracotta
setblock 330 30 501 minecraft:red_nether_bricks
setblock 330 30 503 minecraft:white_concrete
setblock 331 30 490 minecraft:red_nether_bricks
fill 331 30 491 331 33 491 minecraft:pink_terracotta
setblock 331 30 495 minecraft:red_nether_bricks
fill 331 30 496 331 33 496 minecraft:pink_terracotta
setblock 341 30 464 minecraft:pink_terracotta
setblock 342 30 464 minecraft:red_nether_bricks
fill 343 30 464 346 30 464 minecraft:pink_terracotta
fill 344 30 465 344 31 465 minecraft:pink_terracotta
setblock 346 30 465 minecraft:red_nether_bricks
setblock 347 30 464 minecraft:red_nether_bricks
fill 348 30 464 348 32 464 minecraft:pink_terracotta
setblock 348 30 504 minecraft:white_concrete
setblock 352 30 464 minecraft:white_concrete
setblock 357 30 464 minecraft:red_nether_bricks
fill 358 30 464 358 33 464 minecraft:pink_terracotta
setblock 359 30 466 minecraft:pink_terracotta
setblock 360 30 466 minecraft:red_nether_bricks
fill 360 30 504 360 31 504 minecraft:pink_terracotta
setblock 361 30 465 minecraft:red_nether_bricks
fill 361 30 466 361 32 467 minecraft:pink_terracotta
setblock 362 30 464 minecraft:red_nether_bricks
fill 362 30 465 362 33 465 minecraft:pink_terracotta
setblock 362 30 504 minecraft:red_nether_bricks
fill 363 30 464 363 33 464 minecraft:pink_terracotta
fill 363 30 504 363 33 504 minecraft:pink_terracotta
setblock 364 30 467 minecraft:red_nether_bricks
fill 364 30 503 365 32 503 minecraft:pink_terracotta
setblock 365 30 466 minecraft:red_nether_bricks
fill 365 30 467 365 31 467 minecraft:pink_terracotta
setblock 366 30 465 minecraft:red_nether_bricks
fill 366 30 466 366 33 466 minecraft:pink_terracotta
setblock 367 30 464 minecraft:red_nether_bricks
fill 367 30 465 367 33 465 minecraft:pink_terracotta
setblock 367 30 503 minecraft:pink_terracotta
setblock 367 30 504 minecraft:red_nether_bricks
fill 368 30 464 368 33 464 minecraft:pink_terracotta
setblock 368 30 468 minecraft:red_nether_bricks
fill 368 30 469 368 31 469 minecraft:pink_terracotta
fill 368 30 504 368 33 504 minecraft:pink_terracotta
setblock 369 30 467 minecraft:red_nether_bricks
fill 369 30 468 369 32 468 minecraft:pink_terracotta
setblock 369 30 472 minecraft:red_nether_bricks
fill 369 30 490 369 30 491 minecraft:pink_terracotta
setblock 369 30 492 minecraft:red_nether_bricks
fill 369 30 493 369 33 493 minecraft:pink_terracotta
setblock 369 30 496 minecraft:pink_terracotta
setblock 369 30 497 minecraft:red_nether_bricks
setblock 370 30 466 minecraft:red_nether_bricks
fill 370 30 467 370 33 467 minecraft:pink_terracotta
setblock 370 30 471 minecraft:red_nether_bricks
fill 370 30 472 370 33 472 minecraft:pink_terracotta
fill 370 30 474 370 31 474 minecraft:pink_terracotta
setblock 370 30 491 minecraft:red_nether_bricks
fill 370 30 492 370 33 492 minecraft:pink_terracotta
setblock 370 30 495 minecraft:pink_terracotta
setblock 370 30 496 minecraft:red_nether_bricks
fill 370 30 497 370 30 500 minecraft:pink_terracotta
setblock 370 30 501 minecraft:red_nether_bricks
fill 370 30 502 370 33 502 minecraft:pink_terracotta
setblock 330 31 465 minecraft:white_concrete
setblock 330 31 470 minecraft:red_nether_bricks
fill 330 31 471 330 33 471 minecraft:pink_terracotta
fill 330 31 473 330 32 473 minecraft:pink_terracotta
setblock 330 31 484 minecraft:white_concrete
fill 330 31 486 330 32 486 minecraft:pink_terracotta
setblock 330 31 490 minecraft:red_nether_bricks
fill 330 31 491 330 34 491 minecraft:pink_terracotta
setblock 330 31 495 minecraft:red_nether_bricks
fill 330 31 496 330 34 496 minecraft:pink_terracotta
setblock 330 31 500 minecraft:red_nether_bricks
fill 330 31 501 330 33 502 minecraft:pink_terracotta
setblock 331 31 489 minecraft:red_nether_bricks
fill 331 31 490 331 34 490 minecraft:pink_terracotta
setblock 331 31 494 minecraft:red_nether_bricks
fill 331 31 495 331 34 495 minecraft:pink_terracotta
setblock 332 31 466 minecraft:light[level=12]
setblock 332 31 474 minecraft:light[level=12]
setblock 332 31 482 minecraft:light[level=12]
setblock 332 31 490 minecraft:light[level=12]
setblock 332 31 498 minecraft:light[level=12]
setblock 335 31 504 minecraft:white_concrete
setblock 340 31 466 minecraft:light[level=12]
setblock 340 31 474 minecraft:light[level=12]
setblock 340 31 482 minecraft:light[level=12]
setblock 340 31 490 minecraft:light[level=12]
setblock 340 31 498 minecraft:light[level=12]
setblock 341 31 464 minecraft:red_nether_bricks
fill 342 31 464 345 31 464 minecraft:pink_terracotta
fill 343 31 465 343 32 465 minecraft:pink_terracotta
setblock 345 31 465 minecraft:red_nether_bricks
setblock 346 31 464 minecraft:red_nether_bricks
setblock 346 31 465 minecraft:pink_terracotta
fill 347 31 464 347 33 464 minecraft:pink_terracotta
setblock 348 31 466 minecraft:light[level=12]
setblock 348 31 474 minecraft:light[level=12]
setblock 348 31 482 minecraft:light[level=12]
setblock 348 31 490 minecraft:light[level=12]
setblock 348 31 498 minecraft:light[level=12]
setblock 354 31 504 minecraft:white_concrete
setblock 355 31 464 minecraft:pink_terracotta
setblock 356 31 464 minecraft:red_nether_bricks
setblock 356 31 466 minecraft:light[level=12]
setblock 356 31 474 minecraft:light[level=12]
setblock 356 31 482 minecraft:light[level=12]
setblock 356 31 490 minecraft:light[level=12]
setblock 356 31 498 minecraft:light[level=12]
fill 357 31 464 357 33 465 minecraft:pink_terracotta
setblock 359 31 466 minecraft:red_nether_bricks
fill 359 31 504 359 32 504 minecraft:pink_terracotta
setblock 360 31 465 minecraft:red_nether_bricks
fill 360 31 466 360 34 466 minecraft:pink_terracotta
setblock 361 31 464 minecraft:red_nether_bricks
fill 361 31 465 361 34 465 minecraft:pink_terracotta
setblock 361 31 504 minecraft:red_nether_bricks
fill 362 31 464 362 34 464 minecraft:pink_terracotta
setblock 362 31 503 minecraft:red_nether_bricks
fill 362 31 504 362 34 504 minecraft:pink_terracotta
setblock 363 31 466 minecraft:pink_terracotta
setblock 363 31 467 minecraft:red_nether_bricks
fill 363 31 503 363 34 503 minecraft:pink_terracotta
setblock 364 31 466 minecraft:red_nether_bricks
fill 364 31 467 364 32 467 minecraft:pink_terracotta
setblock 364 31 474 minecraft:light[level=12]
setblock 364 31 482 minecraft:light[level=12]
setblock 364 31 490 minecraft:light[level=12]
setblock 364 31 498 minecraft:light[level=12]
setblock 365 31 465 minecraft:red_nether_bricks
fill 365 31 466 365 33 466 minecraft:pink_terracotta
setblock 366 31 464 minecraft:red_nether_bricks
fill 366 31 465 366 34 465 minecraft:pink_terracotta
setblock 366 31 504 minecraft:red_nether_bricks
fill 367 31 464 367 34 464 minecraft:pink_terracotta
setblock 367 31 503 minecraft:red_nether_bricks
fill 367 31 504 367 34 504 minecraft:pink_terracotta
setblock 368 31 467 minecraft:red_nether_bricks
setblock 368 31 468 minecraft:pink_terracotta
setblock 369 31 466 minecraft:red_nether_bricks
fill 369 31 467 369 32 467 minecraft:pink_terracotta
setblock 369 31 471 minecraft:red_nether_bricks
fill 369 31 472 369 33 473 minecraft:pink_terracotta
setblock 369 31 490 minecraft:pink_terracotta
setblock 369 31 491 minecraft:red_nether_bricks
fill 369 31 492 369 34 492 minecraft:pink_terracotta
setblock 369 31 496 minecraft:red_nether_bricks
fill 369 31 497 370 31 499 minecraft:pink_terracotta
setblock 370 31 465 minecraft:red_nether_bricks
fill 370 31 466 370 33 466 minecraft:pink_terracotta
setblock 370 31 470 minecraft:red_nether_bricks
fill 370 31 471 370 34 471 minecraft:pink_terracotta
setblock 370 31 484 minecraft:white_concrete
setblock 370 31 490 minecraft:red_nether_bricks
fill 370 31 491 370 34 491 minecraft:pink_terracotta
setblock 370 31 495 minecraft:red_nether_bricks
fill 370 31 496 370 34 496 minecraft:pink_terracotta
setblock 370 31 500 minecraft:red_nether_bricks
fill 370 31 501 370 34 501 minecraft:pink_terracotta
setblock 330 32 469 minecraft:red_nether_bricks
fill 330 32 470 330 33 470 minecraft:pink_terracotta
setblock 330 32 474 minecraft:red_nether_bricks
setblock 330 32 489 minecraft:red_nether_bricks
fill 330 32 490 330 35 490 minecraft:pink_terracotta
setblock 330 32 494 minecraft:red_nether_bricks
fill 330 32 495 330 35 495 minecraft:pink_terracotta
setblock 330 32 499 minecraft:red_nether_bricks
fill 330 32 500 330 35 500 minecraft:pink_terracotta
fill 331 32 489 331 33 489 minecraft:pink_terracotta
setblock 331 32 493 minecraft:red_nether_bricks
fill 331 32 494 332 34 494 minecraft:pink_terracotta
setblock 331 32 498 minecraft:red_nether_bricks
setblock 332 32 492 minecraft:red_nether_bricks
fill 332 32 493 332 34 493 minecraft:pink_terracotta
setblock 340 32 464 minecraft:red_nether_bricks
fill 341 32 464 344 32 464 minecraft:pink_terracotta
setblock 341 32 504 minecraft:white_concrete
fill 342 32 504 342 34 504 minecraft:pink_terracotta
setblock 344 32 465 minecraft:red_nether_bricks
setblock 345 32 464 minecraft:red_nether_bricks
setblock 345 32 465 minecraft:pink_terracotta
fill 346 32 464 346 34 464 minecraft:pink_terracotta
setblock 355 32 464 minecraft:red_nether_bricks
fill 356 32 464 356 35 464 minecraft:pink_terracotta
setblock 358 32 466 minecraft:red_nether_bricks
setblock 359 32 465 minecraft:red_nether_bricks
fill 359 32 466 359 35 466 minecraft:pink_terracotta
setblock 360 32 464 minecraft:red_nether_bricks
fill 360 32 465 360 35 465 minecraft:pink_terracotta
fill 360 32 467 360 33 467 minecraft:pink_terracotta
setblock 360 32 504 minecraft:red_nether_bricks
fill 361 32 464 361 35 464 minecraft:pink_terracotta
setblock 361 32 503 minecraft:red_nether_bricks
fill 361 32 504 361 35 504 minecraft:pink_terracotta
setblock 362 32 466 minecraft:pink_terracotta
setblock 362 32 467 minecraft:red_nether_bricks
fill 362 32 503 362 35 503 minecraft:pink_terracotta
setblock 363 32 466 minecraft:red_nether_bricks
fill 363 32 467 363 33 467 minecraft:pink_terracotta
setblock 364 32 465 minecraft:red_nether_bricks
fill 364 32 466 364 34 466 minecraft:pink_terracotta
setblock 365 32 464 minecraft:red_nether_bricks
fill 365 32 465 365 35 465 minecraft:pink_terracotta
setblock 365 32 504 minecraft:red_nether_bricks
fill 366 32 464 366 35 464 minecraft:pink_terracotta
setblock 366 32 503 minecraft:red_nether_bricks
fill 366 32 504 366 35 504 minecraft:pink_terracotta
fill 367 32 503 368 34 503 minecraft:pink_terracotta
fill 368 32 493 368 32 495 minecraft:pink_terracotta
setblock 368 32 496 minecraft:red_nether_bricks
setblock 369 32 466 minecraft:pink_terracotta
setblock 369 32 470 minecraft:red_nether_bricks
fill 369 32 471 369 33 471 minecraft:pink_terracotta
fill 369 32 491 369 33 491 minecraft:pink_terracotta
setblock 369 32 494 minecraft:pink_terracotta
setblock 369 32 495 minecraft:red_nether_bricks
fill 369 32 496 369 32 499 minecraft:pink_terracotta
setblock 369 32 500 minecraft:red_nether_bricks
setblock 370 32 464 minecraft:red_nether_bricks
fill 370 32 465 370 33 465 minecraft:pink_terracotta
setblock 370 32 469 minecraft:red_nether_bricks
fill 370 32 470 370 34 470 minecraft:pink_terracotta
setblock 370 32 474 minecraft:red_nether_bricks
fill 370 32 475 370 35 475 minecraft:pink_terracotta
setblock 370 32 478 minecraft:white_concrete
setblock 370 32 489 minecraft:red_nether_bricks
fill 370 32 490 370 35 490 minecraft:pink_terracotta
setblock 370 32 494 minecraft:red_nether_bricks
fill 370 32 495 370 35 495 minecraft:pink_terracotta
fill 370 32 497 370 32 498 minecraft:pink_terracotta
setblock 370 32 499 minecraft:red_nether_bricks
fill 370 32 500 370 35 500 minecraft:pink_terracotta
setblock 370 32 504 minecraft:red_nether_bricks
setblock 330 33 473 minecraft:red_nether_bricks
fill 330 33 474 330 35 475 minecraft:pink_terracotta
setblock 330 33 477 minecraft:white_concrete
setblock 330 33 488 minecraft:red_nether_bricks
fill 330 33 489 330 36 489 minecraft:pink_terracotta
setblock 330 33 493 minecraft:red_nether_bricks
fill 330 33 494 330 36 494 minecraft:pink_terracotta
setblock 330 33 497 minecraft:pink_terracotta
setblock 330 33 498 minecraft:red_nether_bricks
fill 330 33 499 331 35 499 minecraft:pink_terracotta
setblock 331 33 492 minecraft:red_nether_bricks
fill 331 33 493 331 36 493 minecraft:pink_terracotta
setblock 331 33 497 minecraft:red_nether_bricks
fill 331 33 498 331 36 498 minecraft:pink_terracotta
setblock 332 33 492 minecraft:pink_terracotta
setblock 332 33 495 minecraft:pink_terracotta
setblock 334 33 464 minecraft:white_concrete
fill 340 33 464 343 33 464 minecraft:pink_terracotta
fill 340 33 504 341 35 504 minecraft:pink_terracotta
setblock 343 33 504 minecraft:pink_terracotta
setblock 344 33 464 minecraft:red_nether_bricks
fill 345 33 464 345 35 464 minecraft:pink_terracotta
setblock 347 33 504 minecraft:white_concrete
setblock 353 33 464 minecraft:white_concrete
setblock 354 33 464 minecraft:red_nether_bricks
fill 355 33 464 355 36 464 minecraft:pink_terracotta
fill 356 33 465 356 34 465 minecraft:pink_terracotta
setblock 358 33 465 minecraft:red_nether_bricks
fill 358 33 466 358 35 466 minecraft:pink_terracotta
setblock 358 33 504 minecraft:pink_terracotta
setblock 359 33 464 minecraft:red_nether_bricks
fill 359 33 465 359 36 465 minecraft:pink_terracotta
setblock 359 33 504 minecraft:red_nether_bricks
fill 360 33 464 360 36 464 minecraft:pink_terracotta
setblock 360 33 503 minecraft:red_nether_bricks
fill 360 33 504 360 36 504 minecraft:pink_terracotta
setblock 361 33 466 minecraft:pink_terracotta
setblock 361 33 467 minecraft:red_nether_bricks
fill 361 33 503 361 36 503 minecraft:pink_terracotta
setblock 362 33 466 minecraft:red_nether_bricks
setblock 362 33 467 minecraft:pink_terracotta
setblock 363 33 465 minecraft:red_nether_bricks
fill 363 33 466 363 35 466 minecraft:pink_terracotta
setblock 364 33 464 minecraft:red_nether_bricks
fill 364 33 465 364 36 465 minecraft:pink_terracotta
setblock 364 33 503 minecraft:pink_terracotta
setblock 364 33 504 minecraft:red_nether_bricks
fill 365 33 464 365 36 464 minecraft:pink_terracotta
setblock 365 33 503 minecraft:red_nether_bricks
fill 365 33 504 365 36 504 minecraft:pink_terracotta
fill 366 33 503 366 36 503 minecraft:pink_terracotta
fill 368 33 493 368 33 494 minecraft:pink_terracotta
setblock 368 33 495 minecraft:red_nether_bricks
fill 368 33 496 369 33 498 minecraft:pink_terracotta
setblock 369 33 464 minecraft:red_nether_bricks
setblock 369 33 469 minecraft:red_nether_bricks
setblock 369 33 470 minecraft:pink_terracotta
setblock 369 33 494 minecraft:red_nether_bricks
fill 369 33 495 369 36 495 minecraft:pink_terracotta
setblock 369 33 499 minecraft:red_nether_bricks
fill 369 33 500 369 35 501 minecraft:pink_terracotta
setblock 369 33 504 minecraft:red_nether_bricks
setblock 370 33 468 minecraft:red_nether_bricks
fill 370 33 469 370 34 469 minecraft:pink_terracotta
setblock 370 33 473 minecraft:red_nether_bricks
fill 370 33 474 370 35 474 minecraft:pink_terracotta
setblock 370 33 489 minecraft:pink_terracotta
setblock 370 33 493 minecraft:red_nether_bricks
fill 370 33 494 370 36 494 minecraft:pink_terracotta
setblock 370 33 497 minecraft:pink_terracotta
setblock 370 33 498 minecraft:red_nether_bricks
fill 370 33 499 370 36 499 minecraft:pink_terracotta
setblock 370 33 503 minecraft:red_nether_bricks
fill 370 33 504 370 36 504 minecraft:pink_terracotta
setblock 330 34 472 minecraft:red_nether_bricks
fill 330 34 473 330 35 473 minecraft:pink_terracotta
setblock 330 34 476 minecraft:pink_terracotta
setblock 330 34 483 minecraft:white_concrete
setblock 330 34 487 minecraft:red_nether_bricks
fill 330 34 488 330 35 488 minecraft:pink_terracotta
setblock 330 34 492 minecraft:red_nether_bricks
fill 330 34 493 330 37 493 minecraft:pink_terracotta
setblock 330 34 497 minecraft:red_nether_bricks
fill 330 34 498 330 37 498 minecraft:pink_terracotta
setblock 330 34 501 minecraft:pink_terracotta
setblock 330 34 502 minecraft:red_nether_bricks
setblock 331 34 491 minecraft:red_nether_bricks
fill 331 34 492 331 36 492 minecraft:pink_terracotta
setblock 331 34 496 minecraft:red_nether_bricks
fill 331 34 497 331 37 497 minecraft:pink_terracotta
setblock 332 34 495 minecraft:red_nether_bricks
fill 332 34 496 332 35 496 minecraft:pink_terracotta
fill 339 34 504 339 37 504 minecraft:pink_terracotta
fill 340 34 464 342 34 464 minecraft:pink_terracotta
setblock 343 34 464 minecraft:red_nether_bricks
setblock 343 34 504 minecraft:red_nether_bricks
fill 344 34 464 344 35 464 minecraft:pink_terracotta
setblock 347 34 464 minecraft:white_concrete
setblock 353 34 504 minecraft:white_concrete
fill 354 34 464 354 37 464 minecraft:pink_terracotta
setblock 357 34 464 minecraft:pink_terracotta
setblock 357 34 465 minecraft:red_nether_bricks
setblock 357 34 504 minecraft:pink_terracotta
setblock 358 34 464 minecraft:red_nether_bricks
fill 358 34 465 358 37 465 minecraft:pink_terracotta
setblock 358 34 504 minecraft:red_nether_bricks
fill 359 34 464 359 37 464 minecraft:pink_terracotta
setblock 359 34 503 minecraft:red_nether_bricks
fill 359 34 504 359 37 504 minecraft:pink_terracotta
fill 360 34 503 360 37 503 minecraft:pink_terracotta
setblock 361 34 466 minecraft:red_nether_bricks
setblock 362 34 465 minecraft:red_nether_bricks
fill 362 34 466 362 35 466 minecraft:pink_terracotta
fill 362 34 502 364 34 502 minecraft:pink_terracotta
setblock 363 34 464 minecraft:red_nether_bricks
fill 363 34 465 363 37 465 minecraft:pink_terracotta
setblock 363 34 504 minecraft:red_nether_bricks
fill 364 34 464 364 37 464 minecraft:pink_terracotta
setblock 364 34 503 minecraft:red_nether_bricks
fill 364 34 504 364 37 504 minecraft:pink_terracotta
setblock 365 34 502 minecraft:red_nether_bricks
fill 365 34 503 365 37 503 minecraft:pink_terracotta
setblock 368 34 464 minecraft:red_nether_bricks
setblock 368 34 494 minecraft:red_nether_bricks
fill 368 34 495 368 34 498 minecraft:pink_terracotta
setblock 368 34 504 minecraft:red_nether_bricks
setblock 369 34 493 minecraft:red_nether_bricks
fill 369 34 494 369 37 494 minecraft:pink_terracotta
fill 369 34 496 369 34 497 minecraft:pink_terracotta
setblock 369 34 498 minecraft:red_nether_bricks
fill 369 34 499 369 37 499 minecraft:pink_terracotta
fill 369 34 504 369 37 504 minecraft:pink_terracotta
setblock 370 34 466 minecraft:white_concrete
setblock 370 34 468 minecraft:pink_terracotta
setblock 370 34 472 minecraft:red_nether_bricks
fill 370 34 473 370 35 473 minecraft:pink_terracotta
setblock 370 34 485 minecraft:white_concrete
setblock 370 34 492 minecraft:red_nether_bricks
fill 370 34 493 370 37 493 minecraft:pink_terracotta
setblock 370 34 497 minecraft:red_nether_bricks
fill 370 34 498 370 37 498 minecraft:pink_terracotta
setblock 370 34 502 minecraft:red_nether_bricks
fill 370 34 503 370 37 503 minecraft:pink_terracotta
setblock 330 35 464 minecraft:white_concrete
setblock 330 35 476 minecraft:red_nether_bricks
fill 330 35 477 330 38 477 minecraft:pink_terracotta
setblock 330 35 491 minecraft:red_nether_bricks
fill 330 35 492 330 38 492 minecraft:pink_terracotta
setblock 330 35 496 minecraft:red_nether_bricks
fill 330 35 497 330 38 497 minecraft:pink_terracotta
setblock 330 35 501 minecraft:red_nether_bricks
fill 330 35 502 330 36 502 minecraft:pink_terracotta
setblock 331 35 490 minecraft:red_nether_bricks
setblock 331 35 491 minecraft:pink_terracotta
setblock 331 35 494 minecraft:pink_terracotta
setblock 331 35 495 minecraft:red_nether_bricks
fill 331 35 496 331 38 496 minecraft:pink_terracotta
setblock 332 35 494 minecraft:red_nether_bricks
setblock 332 35 495 minecraft:pink_terracotta
setblock 334 35 504 minecraft:white_concrete
fill 340 35 464 341 35 464 minecraft:pink_terracotta
setblock 342 35 464 minecraft:red_nether_bricks
setblock 342 35 504 minecraft:red_nether_bricks
fill 343 35 464 343 36 464 minecraft:pink_terracotta
setblock 356 35 465 minecraft:red_nether_bricks
setblock 356 35 504 minecraft:pink_terracotta
setblock 357 35 464 minecraft:red_nether_bricks
fill 357 35 465 357 38 465 minecraft:pink_terracotta
setblock 357 35 504 minecraft:red_nether_bricks
fill 358 35 464 358 38 464 minecraft:pink_terracotta
setblock 358 35 503 minecraft:red_nether_bricks
fill 358 35 504 358 38 504 minecraft:pink_terracotta
fill 359 35 503 359 38 503 minecraft:pink_terracotta
setblock 360 35 466 minecraft:red_nether_bricks
setblock 361 35 465 minecraft:red_nether_bricks
fill 361 35 466 361 36 466 minecraft:pink_terracotta
fill 361 35 502 363 35 502 minecraft:pink_terracotta
setblock 362 35 464 minecraft:red_nether_bricks
fill 362 35 465 362 37 465 minecraft:pink_terracotta
setblock 362 35 504 minecraft:red_nether_bricks
fill 363 35 464 363 38 464 minecraft:pink_terracotta
setblock 363 35 503 minecraft:red_nether_bricks
fill 363 35 504 363 38 504 minecraft:pink_terracotta
setblock 364 35 502 minecraft:red_nether_bricks
fill 364 35 503 364 38 503 minecraft:pink_terracotta
setblock 365 35 502 minecraft:pink_terracotta
setblock 367 35 464 minecraft:red_nether_bricks
setblock 367 35 503 minecraft:pink_terracotta
setblock 367 35 504 minecraft:red_nether_bricks
fill 368 35 495 368 35 497 minecraft:pink_terracotta
setblock 368 35 498 minecraft:red_nether_bricks
fill 368 35 504 368 38 504 minecraft:pink_terracotta
setblock 369 35 492 minecraft:red_nether_bricks
fill 369 35 493 369 36 493 minecraft:pink_terracotta
setblock 369 35 496 minecraft:pink_terracotta
setblock 369 35 497 minecraft:red_nether_bricks
fill 369 35 498 369 38 498 minecraft:pink_terracotta
setblock 370 35 471 minecraft:red_nether_bricks
setblock 370 35 472 minecraft:pink_terracotta
setblock 370 35 479 minecraft:white_concrete
setblock 370 35 491 minecraft:red_nether_bricks
fill 370 35 492 370 37 492 minecraft:pink_terracotta
setblock 370 35 496 minecraft:red_nether_bricks
fill 370 35 497 370 38 497 minecraft:pink_terracotta
setblock 370 35 501 minecraft:red_nether_bricks
fill 370 35 502 370 38 502 minecraft:pink_terracotta
setblock 330 36 470 minecraft:white_concrete
setblock 330 36 474 minecraft:pink_terracotta
setblock 330 36 475 minecraft:red_nether_bricks
fill 330 36 476 330 37 476 minecraft:pink_terracotta
setblock 330 36 490 minecraft:red_nether_bricks
fill 330 36 491 330 38 491 minecraft:pink_terracotta
setblock 330 36 495 minecraft:red_nether_bricks
fill 330 36 496 330 39 496 minecraft:pink_terracotta
setblock 330 36 499 minecraft:pink_terracotta
setblock 330 36 500 minecraft:red_nether_bricks
fill 330 36 501 330 39 501 minecraft:pink_terracotta
setblock 331 36 494 minecraft:red_nether_bricks
fill 331 36 495 331 38 495 minecraft:pink_terracotta
setblock 331 36 499 minecraft:red_nether_bricks
setblock 335 36 464 minecraft:white_concrete
fill 338 36 504 338 38 504 minecraft:pink_terracotta
setblock 340 36 464 minecraft:pink_terracotta
setblock 340 36 504 minecraft:pink_terracotta
setblock 341 36 464 minecraft:red_nether_bricks
setblock 341 36 504 minecraft:red_nether_bricks
setblock 342 36 464 minecraft:pink_terracotta
setblock 342 36 504 minecraft:pink_terracotta
setblock 356 36 464 minecraft:red_nether_bricks
setblock 356 36 465 minecraft:pink_terracotta
setblock 356 36 504 minecraft:red_nether_bricks
fill 357 36 464 357 39 464 minecraft:pink_terracotta
fill 357 36 504 357 39 504 minecraft:pink_terracotta
fill 358 36 503 358 39 503 minecraft:pink_terracotta
setblock 359 36 466 minecraft:red_nether_bricks
setblock 360 36 465 minecraft:red_nether_bricks
setblock 360 36 466 minecraft:pink_terracotta
fill 360 36 502 362 36 502 minecraft:pink_terracotta
setblock 361 36 464 minecraft:red_nether_bricks
fill 361 36 465 361 38 465 minecraft:pink_terracotta
setblock 361 36 504 minecraft:red_nether_bricks
fill 362 36 464 362 39 464 minecraft:pink_terracotta
setblock 362 36 503 minecraft:red_nether_bricks
fill 362 36 504 362 39 504 minecraft:pink_terracotta
setblock 363 36 502 minecraft:red_nether_bricks
fill 363 36 503 363 39 503 minecraft:pink_terracotta
fill 364 36 502 364 37 502 minecraft:pink_terracotta
setblock 366 36 464 minecraft:red_nether_bricks
setblock 366 36 504 minecraft:red_nether_bricks
setblock 367 36 503 minecraft:red_nether_bricks
fill 367 36 504 367 39 504 minecraft:pink_terracotta
setblock 368 36 497 minecraft:red_nether_bricks
setblock 368 36 498 minecraft:pink_terracotta
setblock 369 36 496 minecraft:red_nether_bricks
fill 369 36 497 369 39 497 minecraft:pink_terracotta
setblock 369 36 500 minecraft:pink_terracotta
setblock 369 36 501 minecraft:red_nether_bricks
setblock 370 36 473 minecraft:white_concrete
setblock 370 36 491 minecraft:pink_terracotta
setblock 370 36 495 minecraft:red_nether_bricks
fill 370 36 496 370 39 496 minecraft:pink_terracotta
setblock 370 36 500 minecraft:red_nether_bricks
fill 370 36 501 370 39 501 minecraft:pink_terracotta
setblock 330 37 478 minecraft:pink_terracotta
setblock 330 37 490 minecraft:pink_terracotta
setblock 330 37 494 minecraft:red_nether_bricks
fill 330 37 495 330 40 495 minecraft:pink_terracotta
setblock 330 37 499 minecraft:red_nether_bricks
fill 330 37 500 330 40 500 minecraft:pink_terracotta
setblock 331 37 493 minecraft:red_nether_bricks
fill 331 37 494 331 38 494 minecraft:pink_terracotta
setblock 331 37 498 minecraft:red_nether_bricks
setblock 331 37 499 minecraft:pink_terracotta
setblock 340 37 504 minecraft:red_nether_bricks
setblock 341 37 504 minecraft:pink_terracotta
setblock 346 37 504 minecraft:white_concrete
setblock 348 37 464 minecraft:white_concrete
fill 352 37 504 352 38 504 minecraft:white_concrete
setblock 355 37 464 minecraft:red_nether_bricks
setblock 355 37 504 minecraft:red_nether_bricks
fill 356 37 464 356 40 464 minecraft:pink_terracotta
fill 356 37 504 356 40 504 minecraft:pink_terracotta
fill 357 37 503 357 40 503 minecraft:pink_terracotta
setblock 359 37 465 minecraft:red_nether_bricks
fill 359 37 502 361 37 502 minecraft:pink_terracotta
setblock 360 37 464 minecraft:red_nether_bricks
fill 360 37 465 360 39 465 minecraft:pink_terracotta
setblock 360 37 504 minecraft:red_nether_bricks
fill 361 37 464 361 40 464 minecraft:pink_terracotta
setblock 361 37 503 minecraft:red_nether_bricks
fill 361 37 504 361 40 504 minecraft:pink_terracotta
setblock 362 37 502 minecraft:red_nether_bricks
fill 362 37 503 362 40 503 minecraft:pink_terracotta
fill 363 37 502 363 40 502 minecraft:pink_terracotta
setblock 365 37 464 minecraft:red_nether_bricks
setblock 365 37 504 minecraft:red_nether_bricks
setblock 366 37 503 minecraft:red_nether_bricks
fill 366 37 504 366 40 504 minecraft:pink_terracotta
setblock 369 37 495 minecraft:red_nether_bricks
fill 369 37 496 369 38 496 minecraft:pink_terracotta
setblock 369 37 500 minecraft:red_nether_bricks
fill 369 37 501 369 38 501 minecraft:pink_terracotta
setblock 370 37 467 minecraft:white_concrete
setblock 370 37 486 minecraft:white_concrete
setblock 370 37 494 minecraft:red_nether_bricks
fill 370 37 495 370 40 495 minecraft:pink_terracotta
setblock 370 37 499 minecraft:red_nether_bricks
fill 370 37 500 370 40 500 minecraft:pink_terracotta
setblock 370 37 504 minecraft:red_nether_bricks
setblock 330 38 478 minecraft:red_nether_bricks
setblock 330 38 482 minecraft:white_concrete
fill 330 38 488 330 39 488 minecraft:white_concrete
setblock 330 38 493 minecraft:red_nether_bricks
fill 330 38 494 330 41 494 minecraft:pink_terracotta
setblock 330 38 498 minecraft:red_nether_bricks
fill 330 38 499 330 41 499 minecraft:pink_terracotta
setblock 331 38 497 minecraft:red_nether_bricks
setblock 331 38 498 minecraft:pink_terracotta
setblock 333 38 504 minecraft:white_concrete
setblock 339 38 504 minecraft:red_nether_bricks
fill 340 38 504 340 41 504 minecraft:pink_terracotta
setblock 342 38 464 minecraft:white_concrete
setblock 354 38 464 minecraft:red_nether_bricks
fill 355 38 464 355 41 464 minecraft:pink_terracotta
fill 355 38 504 355 41 504 minecraft:pink_terracotta
fill 356 38 503 356 41 503 minecraft:pink_terracotta
setblock 358 38 465 minecraft:red_nether_bricks
fill 358 38 502 360 38 502 minecraft:pink_terracotta
setblock 359 38 464 minecraft:red_nether_bricks
fill 359 38 465 359 41 465 minecraft:pink_terracotta
setblock 359 38 504 minecraft:red_nether_bricks
fill 360 38 464 360 41 464 minecraft:pink_terracotta
setblock 360 38 503 minecraft:red_nether_bricks
fill 360 38 504 360 41 504 minecraft:pink_terracotta
setblock 361 38 502 minecraft:red_nether_bricks
fill 361 38 503 361 41 503 minecraft:pink_terracotta
fill 362 38 502 362 41 502 minecraft:pink_terracotta
setblock 364 38 464 minecraft:red_nether_bricks
setblock 364 38 504 minecraft:red_nether_bricks
setblock 365 38 503 minecraft:red_nether_bricks
fill 365 38 504 365 41 504 minecraft:pink_terracotta
setblock 366 38 503 minecraft:pink_terracotta
setblock 367 38 464 minecraft:white_concrete
setblock 369 38 499 minecraft:red_nether_bricks
fill 369 38 500 369 41 500 minecraft:pink_terracotta
setblock 369 38 504 minecraft:red_nether_bricks
setblock 370 38 480 minecraft:white_concrete
setblock 370 38 493 minecraft:red_nether_bricks
fill 370 38 494 370 40 494 minecraft:pink_terracotta
setblock 370 38 498 minecraft:red_nether_bricks
fill 370 38 499 370 41 499 minecraft:pink_terracotta
setblock 370 38 503 minecraft:red_nether_bricks
setblock 330 39 469 minecraft:white_concrete
setblock 330 39 477 minecraft:red_nether_bricks
fill 330 39 478 330 40 480 minecraft:pink_terracotta
setblock 330 39 492 minecraft:red_nether_bricks
setblock 330 39 493 minecraft:pink_terracotta
setblock 330 39 497 minecraft:red_nether_bricks
fill 330 39 498 330 42 498 minecraft:pink_terracotta
setblock 331 39 496 minecraft:red_nether_bricks
setblock 331 39 497 minecraft:pink_terracotta
setblock 332 39 466 minecraft:light[level=12]
setblock 332 39 474 minecraft:light[level=12]
setblock 332 39 482 minecraft:light[level=12]
setblock 332 39 490 minecraft:light[level=12]
setblock 332 39 498 minecraft:light[level=12]
setblock 336 39 464 minecraft:white_concrete
setblock 337 39 504 minecraft:pink_terracotta
setblock 338 39 504 minecraft:red_nether_bricks
fill 339 39 504 339 42 504 minecraft:pink_terracotta
setblock 340 39 466 minecraft:light[level=12]
setblock 340 39 474 minecraft:light[level=12]
setblock 340 39 482 minecraft:light[level=12]
setblock 340 39 490 minecraft:light[level=12]
setblock 340 39 498 minecraft:light[level=12]
setblock 348 39 466 minecraft:light[level=12]
setblock 348 39 474 minecraft:light[level=12]
setblock 348 39 482 minecraft:light[level=12]
setblock 348 39 490 minecraft:light[level=12]
setblock 348 39 498 minecraft:light[level=12]
fill 354 39 464 354 42 464 minecraft:pink_terracotta
fill 354 39 504 354 42 504 minecraft:pink_terracotta
setblock 356 39 466 minecraft:light[level=12]
setblock 356 39 474 minecraft:light[level=12]
setblock 356 39 482 minecraft:light[level=12]
setblock 356 39 490 minecraft:light[level=12]
setblock 356 39 498 minecraft:light[level=12]
setblock 357 39 465 minecraft:red_nether_bricks
setblock 358 39 464 minecraft:red_nether_bricks
fill 358 39 465 358 42 465 minecraft:pink_terracotta
fill 358 39 502 359 39 502 minecraft:pink_terracotta
setblock 358 39 504 minecraft:red_nether_bricks
fill 359 39 464 359 42 464 minecraft:pink_terracotta
setblock 359 39 503 minecraft:red_nether_bricks
fill 359 39 504 359 42 504 minecraft:pink_terracotta
setblock 360 39 502 minecraft:red_nether_bricks
fill 360 39 503 360 42 503 minecraft:pink_terracotta
fill 361 39 502 361 42 502 minecraft:pink_terracotta
setblock 363 39 464 minecraft:red_nether_bricks
setblock 363 39 504 minecraft:red_nether_bricks
setblock 364 39 466 minecraft:light[level=12]
setblock 364 39 474 minecraft:light[level=12]
setblock 364 39 482 minecraft:light[level=12]
setblock 364 39 490 minecraft:light[level=12]
setblock 364 39 498 minecraft:light[level=12]
setblock 364 39 503 minecraft:red_nether_bricks
fill 364 39 504 364 42 504 minecraft:pink_terracotta
fill 365 39 503 365 42 503 minecraft:pink_terracotta
setblock 368 39 504 minecraft:red_nether_bricks
setblock 369 39 498 minecraft:red_nether_bricks
fill 369 39 499 369 42 499 minecraft:pink_terracotta
setblock 370 39 474 minecraft:white_concrete
setblock 370 39 497 minecraft:red_nether_bricks
fill 370 39 498 370 42 498 minecraft:pink_terracotta
setblock 370 39 502 minecraft:red_nether_bricks
fill 370 39 503 370 42 503 minecraft:pink_terracotta
setblock 330 40 475 minecraft:white_concrete
fill 330 40 477 330 43 477 minecraft:pink_terracotta
setblock 330 40 481 minecraft:red_nether_bricks
setblock 330 40 496 minecraft:red_nether_bricks
fill 330 40 497 330 43 497 minecraft:pink_terracotta
setblock 330 40 501 minecraft:red_nether_bricks
fill 335 40 484 335 41 486 minecraft:pink_concrete
fill 336 40 485 336 41 486 minecraft:pink_concrete
setblock 336 40 504 minecraft:pink_terracotta
setblock 337 40 504 minecraft:red_nether_bricks
fill 338 40 504 338 43 504 minecraft:pink_terracotta
setblock 345 40 504 minecraft:white_concrete
fill 353 40 464 353 43 464 minecraft:pink_terracotta
fill 353 40 504 353 43 504 minecraft:pink_terracotta
fill 355 40 503 355 42 503 minecraft:pink_terracotta
setblock 357 40 464 minecraft:red_nether_bricks
fill 357 40 465 357 43 465 minecraft:pink_terracotta
fill 357 40 502 358 40 502 minecraft:pink_terracotta
setblock 357 40 504 minecraft:red_nether_bricks
fill 358 40 464 358 43 464 minecraft:pink_terracotta
setblock 358 40 503 minecraft:red_nether_bricks
fill 358 40 504 358 43 504 minecraft:pink_terracotta
setblock 359 40 502 minecraft:red_nether_bricks
fill 359 40 503 359 43 503 minecraft:pink_terracotta
fill 360 40 502 360 43 502 minecraft:pink_terracotta
setblock 362 40 464 minecraft:red_nether_bricks
setblock 362 40 504 minecraft:red_nether_bricks
fill 363 40 464 363 43 464 minecraft:pink_terracotta
setblock 363 40 503 minecraft:red_nether_bricks
fill 363 40 504 363 43 504 minecraft:pink_terracotta
fill 364 40 503 364 43 503 minecraft:pink_terracotta
setblock 367 40 504 minecraft:red_nether_bricks
fill 368 40 504 370 41 504 minecraft:pink_terracotta
fill 369 40 498 369 43 498 minecraft:pink_terracotta
setblock 370 40 468 minecraft:white_concrete
setblock 370 40 493 minecraft:white_concrete
setblock 370 40 496 minecraft:red_nether_bricks
fill 370 40 497 370 43 497 minecraft:pink_terracotta
setblock 370 40 501 minecraft:red_nether_bricks
fill 370 40 502 370 43 502 minecraft:pink_terracotta
fill 330 41 478 330 41 479 minecraft:pink_terracotta
setblock 330 41 480 minecraft:red_nether_bricks
fill 330 41 481 330 42 483 minecraft:pink_terracotta
setblock 330 41 495 minecraft:red_nether_bricks
fill 330 41 496 330 44 496 minecraft:pink_terracotta
setblock 330 41 500 minecraft:red_nether_bricks
fill 330 41 501 330 43 502 minecraft:pink_terracotta
setblock 332 41 504 minecraft:white_concrete
fill 334 41 504 335 41 504 minecraft:pink_terracotta
setblock 336 41 504 minecraft:red_nether_bricks
fill 337 41 504 337 44 504 minecraft:pink_terracotta
setblock 349 41 464 minecraft:white_concrete
setblock 351 41 504 minecraft:white_concrete
fill 352 41 464 352 44 464 minecraft:pink_terracotta
fill 352 41 504 352 44 504 minecraft:pink_terracotta
fill 354 41 503 354 43 503 minecraft:pink_terracotta
setblock 356 41 464 minecraft:red_nether_bricks
fill 356 41 465 356 44 465 minecraft:pink_terracotta
fill 356 41 502 357 41 502 minecraft:pink_terracotta
setblock 356 41 504 minecraft:red_nether_bricks
fill 357 41 464 357 44 464 minecraft:pink_terracotta
setblock 357 41 503 minecraft:red_nether_bricks
fill 357 41 504 357 44 504 minecraft:pink_terracotta
setblock 358 41 502 minecraft:red_nether_bricks
fill 358 41 503 358 44 503 minecraft:pink_terracotta
fill 359 41 502 359 44 502 minecraft:pink_terracotta
setblock 361 41 464 minecraft:red_nether_bricks
setblock 361 41 504 minecraft:red_nether_bricks
fill 362 41 464 362 44 464 minecraft:pink_terracotta
setblock 362 41 503 minecraft:red_nether_bricks
fill 362 41 504 362 44 504 minecraft:pink_terracotta
fill 363 41 503 363 44 503 minecraft:pink_terracotta
setblock 366 41 504 minecraft:red_nether_bricks
fill 367 41 504 367 44 504 minecraft:pink_terracotta
setblock 368 41 464 minecraft:white_concrete
setblock 369 41 501 minecraft:red_nether_bricks
setblock 370 41 487 minecraft:white_concrete
setblock 370 41 495 minecraft:red_nether_bricks
fill 370 41 496 370 44 496 minecraft:pink_terracotta
setblock 370 41 500 minecraft:red_nether_bricks
fill 370 41 501 370 44 501 minecraft:pink_terracotta
setblock 330 42 468 minecraft:white_concrete
fill 330 42 476 330 44 476 minecraft:pink_terracotta
setblock 330 42 478 minecraft:pink_terracotta
setblock 330 42 479 minecraft:red_nether_bricks
fill 330 42 480 331 44 480 minecraft:pink_terracotta
setblock 330 42 484 minecraft:red_nether_bricks
fill 330 42 485 330 45 485 minecraft:pink_terracotta
setblock 330 42 487 minecraft:white_concrete
fill 330 42 495 330 45 495 minecraft:pink_terracotta
setblock 330 42 499 minecraft:red_nether_bricks
fill 330 42 500 330 45 500 minecraft:pink_terracotta
setblock 331 42 478 minecraft:red_nether_bricks
fill 331 42 479 331 45 479 minecraft:pink_terracotta
fill 331 42 481 331 42 482 minecraft:pink_terracotta
setblock 331 42 483 minecraft:red_nether_bricks
fill 333 42 504 334 42 504 minecraft:pink_terracotta
setblock 335 42 504 minecraft:red_nether_bricks
fill 336 42 504 336 45 504 minecraft:pink_terracotta
fill 337 42 464 339 42 464 minecraft:pink_terracotta
setblock 340 42 464 minecraft:red_nether_bricks
setblock 340 42 504 minecraft:red_nether_bricks
fill 341 42 504 341 45 504 minecraft:pink_terracotta
setblock 343 42 464 minecraft:white_concrete
fill 351 42 464 351 45 464 minecraft:pink_terracotta
fill 351 42 504 351 45 504 minecraft:pink_terracotta
fill 353 42 503 353 44 503 minecraft:pink_terracotta
setblock 354 42 465 minecraft:red_nether_bricks
setblock 355 42 464 minecraft:red_nether_bricks
fill 355 42 465 355 45 465 minecraft:pink_terracotta
fill 355 42 502 356 42 502 minecraft:pink_terracotta
setblock 355 42 504 minecraft:red_nether_bricks
fill 356 42 464 356 45 464 minecraft:pink_terracotta
setblock 356 42 503 minecraft:red_nether_bricks
fill 356 42 504 356 45 504 minecraft:pink_terracotta
setblock 357 42 502 minecraft:red_nether_bricks
fill 357 42 503 357 45 503 minecraft:pink_terracotta
fill 358 42 502 358 45 502 minecraft:pink_terracotta
setblock 359 42 465 minecraft:red_nether_bricks
setblock 360 42 464 minecraft:red_nether_bricks
setblock 360 42 504 minecraft:red_nether_bricks
fill 361 42 464 361 45 464 minecraft:pink_terracotta
setblock 361 42 503 minecraft:red_nether_bricks
fill 361 42 504 361 45 504 minecraft:pink_terracotta
setblock 362 42 502 minecraft:red_nether_bricks
fill 362 42 503 362 45 503 minecraft:pink_terracotta
fill 363 42 502 363 45 502 minecraft:pink_terracotta
setblock 365 42 504 minecraft:red_nether_bricks
setblock 366 42 503 minecraft:red_nether_bricks
fill 366 42 504 366 45 504 minecraft:pink_terracotta
fill 368 42 504 369 42 504 minecraft:pink_terracotta
setblock 369 42 500 minecraft:red_nether_bricks
fill 369 42 501 369 44 502 minecraft:pink_terracotta
setblock 370 42 481 minecraft:white_concrete
fill 370 42 495 370 45 495 minecraft:pink_terracotta
setblock 370 42 499 minecraft:red_nether_bricks
fill 370 42 500 370 45 500 minecraft:pink_terracotta
setblock 370 42 504 minecraft:red_nether_bricks
setblock 330 43 474 minecraft:white_concrete
setblock 330 43 478 minecraft:red_nether_bricks
fill 330 43 479 330 46 479 minecraft:pink_terracotta
fill 330 43 481 330 43 482 minecraft:pink_terracotta
setblock 330 43 483 minecraft:red_nether_bricks
fill 330 43 484 331 45 484 minecraft:pink_terracotta
fill 330 43 486 330 43 487 minecraft:pink_terracotta
setblock 330 43 493 minecraft:white_concrete
setblock 330 43 498 minecraft:red_nether_bricks
fill 330 43 499 330 46 499 minecraft:pink_terracotta
setblock 330 43 503 minecraft:red_nether_bricks
setblock 331 43 477 minecraft:red_nether_bricks
fill 331 43 478 331 46 478 minecraft:pink_terracotta
setblock 331 43 481 minecraft:pink_terracotta
setblock 331 43 482 minecraft:red_nether_bricks
fill 331 43 483 331 46 483 minecraft:pink_terracotta
fill 331 43 485 331 44 485 minecraft:pink_terracotta
fill 331 43 504 333 43 504 minecraft:pink_terracotta
fill 332 43 479 332 43 480 minecraft:pink_terracotta
setblock 332 43 481 minecraft:red_nether_bricks
fill 332 43 482 332 46 482 minecraft:pink_terracotta
setblock 334 43 503 minecraft:pink_terracotta
setblock 334 43 504 minecraft:red_nether_bricks
fill 335 43 464 338 43 464 minecraft:pink_terracotta
setblock 335 43 503 minecraft:red_nether_bricks
fill 335 43 504 335 46 504 minecraft:pink_terracotta
fill 336 43 503 338 44 503 minecraft:pink_terracotta
setblock 339 43 464 minecraft:red_nether_bricks
setblock 339 43 504 minecraft:red_nether_bricks
fill 340 43 464 341 45 464 minecraft:pink_terracotta
fill 340 43 504 340 46 504 minecraft:pink_terracotta
setblock 344 43 504 minecraft:white_concrete
setblock 349 43 464 minecraft:red_nether_bricks
fill 350 43 464 350 46 464 minecraft:pink_terracotta
fill 350 43 504 350 46 504 minecraft:pink_terracotta
fill 352 43 503 352 45 503 minecraft:pink_terracotta
setblock 353 43 465 minecraft:red_nether_bricks
setblock 354 43 464 minecraft:red_nether_bricks
fill 354 43 465 354 46 465 minecraft:pink_terracotta
fill 354 43 502 355 43 502 minecraft:pink_terracotta
setblock 354 43 504 minecraft:red_nether_bricks
fill 355 43 464 355 46 464 minecraft:pink_terracotta
setblock 355 43 503 minecraft:red_nether_bricks
fill 355 43 504 355 46 504 minecraft:pink_terracotta
setblock 356 43 502 minecraft:red_nether_bricks
fill 356 43 503 356 46 503 minecraft:pink_terracotta
fill 357 43 502 357 46 502 minecraft:pink_terracotta
setblock 358 43 465 minecraft:red_nether_bricks
fill 358 43 501 359 45 501 minecraft:pink_terracotta
setblock 359 43 464 minecraft:red_nether_bricks
fill 359 43 465 360 45 465 minecraft:pink_terracotta
setblock 359 43 504 minecraft:red_nether_bricks
fill 360 43 464 360 46 464 minecraft:pink_terracotta
setblock 360 43 503 minecraft:red_nether_bricks
fill 360 43 504 360 46 504 minecraft:pink_terracotta
setblock 361 43 502 minecraft:red_nether_bricks
fill 361 43 503 361 46 503 minecraft:pink_terracotta
fill 362 43 502 362 46 502 minecraft:pink_terracotta
setblock 364 43 504 minecraft:red_nether_bricks
setblock 365 43 503 minecraft:red_nether_bricks
fill 365 43 504 365 46 504 minecraft:pink_terracotta
fill 366 43 503 369 43 503 minecraft:pink_terracotta
setblock 368 43 504 minecraft:pink_terracotta
setblock 369 43 499 minecraft:red_nether_bricks
fill 369 43 500 369 46 500 minecraft:pink_terracotta
setblock 369 43 504 minecraft:red_nether_bricks
setblock 370 43 475 minecraft:white_concrete
fill 370 43 480 370 43 482 minecraft:pink_terracotta
fill 370 43 494 370 46 494 minecraft:pink_terracotta
setblock 370 43 498 minecraft:red_nether_bricks
fill 370 43 499 370 46 499 minecraft:pink_terracotta
setblock 370 43 503 minecraft:red_nether_bricks
fill 370 43 504 370 46 504 minecraft:pink_terracotta
fill 330 44 475 330 45 475 minecraft:pink_terracotta
setblock 330 44 477 minecraft:red_nether_bricks
fill 330 44 478 330 47 478 minecraft:pink_terracotta
setblock 330 44 481 minecraft:pink_terracotta
setblock 330 44 482 minecraft:red_nether_bricks
fill 330 44 483 330 47 483 minecraft:pink_terracotta
setblock 330 44 486 minecraft:pink_terracotta
setblock 330 44 487 minecraft:red_nether_bricks
fill 330 44 488 330 45 490 minecraft:pink_terracotta
fill 330 44 494 330 46 494 minecraft:pink_terracotta
setblock 330 44 497 minecraft:red_nether_bricks
fill 330 44 498 330 47 498 minecraft:pink_terracotta
setblock 330 44 501 minecraft:pink_terracotta
setblock 330 44 502 minecraft:red_nether_bricks
fill 330 44 503 330 46 504 minecraft:pink_terracotta
setblock 331 44 464 minecraft:white_concrete
setblock 331 44 476 minecraft:red_nether_bricks
fill 331 44 477 331 47 477 minecraft:pink_terracotta
setblock 331 44 481 minecraft:red_nether_bricks
fill 331 44 482 331 47 482 minecraft:pink_terracotta
setblock 331 44 486 minecraft:red_nether_bricks
fill 331 44 487 331 47 487 minecraft:pink_terracotta
fill 331 44 499 331 44 500 minecraft:pink_terracotta
setblock 331 44 501 minecraft:red_nether_bricks
fill 331 44 502 331 47 502 minecraft:pink_terracotta
fill 331 44 504 332 44 504 minecraft:pink_terracotta
fill 332 44 478 332 44 479 minecraft:pink_terracotta
setblock 332 44 480 minecraft:red_nether_bricks
fill 332 44 481 333 46 481 minecraft:pink_terracotta
fill 332 44 483 332 44 484 minecraft:pink_terracotta
setblock 332 44 485 minecraft:red_nether_bricks
fill 332 44 503 333 44 503 minecraft:pink_terracotta
setblock 333 44 464 minecraft:red_nether_bricks
fill 333 44 480 333 47 480 minecraft:pink_terracotta
fill 333 44 482 333 45 482 minecraft:pink_terracotta
setblock 333 44 504 minecraft:red_nether_bricks
fill 334 44 464 337 44 464 minecraft:pink_terracotta
setblock 334 44 503 minecraft:red_nether_bricks
fill 334 44 504 334 47 504 minecraft:pink_terracotta
fill 335 44 503 335 47 503 minecraft:pink_terracotta
setblock 338 44 464 minecraft:red_nether_bricks
setblock 338 44 504 minecraft:red_nether_bricks
fill 339 44 464 339 47 464 minecraft:pink_terracotta
setblock 339 44 503 minecraft:red_nether_bricks
fill 339 44 504 339 47 504 minecraft:pink_terracotta
setblock 342 44 464 minecraft:pink_terracotta
setblock 342 44 504 minecraft:pink_terracotta
setblock 343 44 464 minecraft:red_nether_bricks
fill 344 44 464 344 47 464 minecraft:pink_terracotta
fill 346 44 464 347 44 464 minecraft:pink_terracotta
setblock 348 44 464 minecraft:red_nether_bricks
setblock 348 44 504 minecraft:red_nether_bricks
fill 349 44 464 349 47 464 minecraft:pink_terracotta
fill 349 44 504 349 47 504 minecraft:pink_terracotta
fill 350 44 503 351 46 503 minecraft:pink_terracotta
setblock 351 44 465 minecraft:pink_terracotta
setblock 352 44 465 minecraft:red_nether_bricks
setblock 353 44 464 minecraft:red_nether_bricks
fill 353 44 465 353 47 465 minecraft:pink_terracotta
fill 353 44 502 354 44 502 minecraft:pink_terracotta
setblock 353 44 504 minecraft:red_nether_bricks
fill 354 44 464 354 47 464 minecraft:pink_terracotta
setblock 354 44 503 minecraft:red_nether_bricks
fill 354 44 504 354 47 504 minecraft:pink_terracotta
setblock 355 44 502 minecraft:red_nether_bricks
fill 355 44 503 355 47 503 minecraft:pink_terracotta
setblock 356 44 501 minecraft:red_nether_bricks
fill 356 44 502 356 47 502 minecraft:pink_terracotta
setblock 357 44 465 minecraft:red_nether_bricks
fill 357 44 501 357 47 501 minecraft:pink_terracotta
setblock 358 44 464 minecraft:red_nether_bricks
fill 358 44 465 358 47 465 minecraft:pink_terracotta
setblock 358 44 504 minecraft:red_nether_bricks
fill 359 44 464 359 47 464 minecraft:pink_terracotta
setblock 359 44 503 minecraft:red_nether_bricks
fill 359 44 504 359 47 504 minecraft:pink_terracotta
setblock 360 44 502 minecraft:red_nether_bricks
fill 360 44 503 360 47 503 minecraft:pink_terracotta
fill 361 44 502 361 47 502 minecraft:pink_terracotta
setblock 363 44 464 minecraft:red_nether_bricks
setblock 363 44 504 minecraft:red_nether_bricks
setblock 364 44 503 minecraft:red_nether_bricks
fill 364 44 504 364 47 504 minecraft:pink_terracotta
fill 365 44 503 368 44 503 minecraft:pink_terracotta
setblock 368 44 504 minecraft:red_nether_bricks
setblock 369 44 498 minecraft:red_nether_bricks
fill 369 44 499 369 47 499 minecraft:pink_terracotta
setblock 369 44 503 minecraft:red_nether_bricks
fill 369 44 504 369 47 504 minecraft:pink_terracotta
setblock 370 44 469 minecraft:white_concrete
fill 370 44 478 370 44 481 minecraft:pink_terracotta
setblock 370 44 482 minecraft:red_nether_bricks
fill 370 44 483 370 44 486 minecraft:pink_terracotta
setblock 370 44 487 minecraft:red_nether_bricks
setblock 370 44 488 minecraft:white_concrete
fill 370 44 493 370 47 493 minecraft:pink_terracotta
setblock 370 44 497 minecraft:red_nether_bricks
fill 370 44 498 370 47 498 minecraft:pink_terracotta
setblock 370 44 502 minecraft:red_nether_bricks
fill 370 44 503 370 47 503 minecraft:pink_terracotta
setblock 330 45 476 minecraft:red_nether_bricks
fill 330 45 477 330 48 477 minecraft:pink_terracotta
setblock 330 45 480 minecraft:pink_terracotta
setblock 330 45 481 minecraft:red_nether_bricks
fill 330 45 482 330 48 482 minecraft:pink_terracotta
setblock 330 45 486 minecraft:red_nether_bricks
fill 330 45 487 330 48 487 minecraft:pink_terracotta
setblock 330 45 491 minecraft:red_nether_bricks
fill 330 45 492 330 47 493 minecraft:pink_terracotta
setblock 330 45 496 minecraft:red_nether_bricks
fill 330 45 497 330 48 497 minecraft:pink_terracotta
setblock 330 45 501 minecraft:red_nether_bricks
fill 330 45 502 330 48 502 minecraft:pink_terracotta
setblock 331 45 464 minecraft:pink_terracotta
fill 331 45 476 331 48 476 minecraft:pink_terracotta
setblock 331 45 480 minecraft:red_nether_bricks
fill 331 45 481 331 48 481 minecraft:pink_terracotta
setblock 331 45 485 minecraft:red_nether_bricks
fill 331 45 486 332 47 486 minecraft:pink_terracotta
fill 331 45 488 331 45 489 minecraft:pink_terracotta
fill 331 45 498 331 45 499 minecraft:pink_terracotta
setblock 331 45 500 minecraft:red_nether_bricks
fill 331 45 501 331 48 501 minecraft:pink_terracotta
fill 331 45 503 331 45 504 minecraft:pink_terracotta
setblock 332 45 464 minecraft:red_nether_bricks
fill 332 45 477 332 45 478 minecraft:pink_terracotta
setblock 332 45 479 minecraft:red_nether_bricks
fill 332 45 480 332 48 480 minecraft:pink_terracotta
setblock 332 45 483 minecraft:pink_terracotta
setblock 332 45 484 minecraft:red_nether_bricks
fill 332 45 485 332 48 485 minecraft:pink_terracotta
fill 332 45 487 332 46 487 minecraft:pink_terracotta
setblock 332 45 503 minecraft:pink_terracotta
setblock 332 45 504 minecraft:red_nether_bricks
fill 333 45 464 336 45 464 minecraft:pink_terracotta
setblock 333 45 478 minecraft:red_nether_bricks
fill 333 45 479 333 48 479 minecraft:pink_terracotta
setblock 333 45 483 minecraft:red_nether_bricks
fill 333 45 484 333 48 484 minecraft:pink_terracotta
setblock 333 45 503 minecraft:red_nether_bricks
fill 333 45 504 333 48 504 minecraft:pink_terracotta
fill 334 45 503 334 48 503 minecraft:pink_terracotta
setblock 335 45 465 minecraft:pink_terracotta
setblock 336 45 465 minecraft:red_nether_bricks
fill 336 45 503 337 45 503 minecraft:pink_terracotta
setblock 337 45 464 minecraft:red_nether_bricks
fill 337 45 465 339 46 465 minecraft:pink_terracotta
setblock 337 45 504 minecraft:red_nether_bricks
fill 338 45 464 338 48 464 minecraft:pink_terracotta
setblock 338 45 503 minecraft:red_nether_bricks
fill 338 45 504 338 48 504 minecraft:pink_terracotta
fill 339 45 503 339 48 503 minecraft:pink_terracotta
setblock 342 45 464 minecraft:red_nether_bricks
setblock 342 45 504 minecraft:red_nether_bricks
fill 343 45 464 343 48 464 minecraft:pink_terracotta
fill 343 45 504 346 45 504 minecraft:pink_terracotta
fill 345 45 464 346 45 464 minecraft:pink_terracotta
setblock 347 45 464 minecraft:red_nether_bricks
setblock 347 45 504 minecraft:red_nether_bricks
fill 348 45 464 348 48 464 minecraft:pink_terracotta
fill 348 45 504 348 48 504 minecraft:pink_terracotta
fill 349 45 465 350 45 465 minecraft:pink_terracotta
fill 349 45 503 349 48 503 minecraft:pink_terracotta
setblock 351 45 465 minecraft:red_nether_bricks
setblock 352 45 464 minecraft:red_nether_bricks
fill 352 45 465 352 48 465 minecraft:pink_terracotta
fill 352 45 502 353 45 502 minecraft:pink_terracotta
setblock 352 45 504 minecraft:red_nether_bricks
fill 353 45 464 353 48 464 minecraft:pink_terracotta
fill 353 45 466 354 45 466 minecraft:pink_terracotta
setblock 353 45 503 minecraft:red_nether_bricks
fill 353 45 504 353 48 504 minecraft:pink_terracotta
setblock 354 45 502 minecraft:red_nether_bricks
fill 354 45 503 354 48 503 minecraft:pink_terracotta
setblock 355 45 466 minecraft:red_nether_bricks
setblock 355 45 501 minecraft:red_nether_bricks
fill 355 45 502 355 48 502 minecraft:pink_terracotta
setblock 356 45 465 minecraft:red_nether_bricks
fill 356 45 466 357 47 466 minecraft:pink_terracotta
fill 356 45 501 356 48 501 minecraft:pink_terracotta
setblock 357 45 464 minecraft:red_nether_bricks
fill 357 45 465 357 48 465 minecraft:pink_terracotta
setblock 357 45 504 minecraft:red_nether_bricks
fill 358 45 464 358 48 464 minecraft:pink_terracotta
setblock 358 45 503 minecraft:red_nether_bricks
fill 358 45 504 358 48 504 minecraft:pink_terracotta
setblock 359 45 502 minecraft:red_nether_bricks
fill 359 45 503 359 48 503 minecraft:pink_terracotta
fill 360 45 502 360 48 502 minecraft:pink_terracotta
setblock 362 45 464 minecraft:red_nether_bricks
setblock 362 45 504 minecraft:red_nether_bricks
fill 363 45 464 364 47 464 minecraft:pink_terracotta
setblock 363 45 503 minecraft:red_nether_bricks
fill 363 45 504 363 48 504 minecraft:pink_terracotta
fill 364 45 503 367 45 503 minecraft:pink_terracotta
setblock 367 45 504 minecraft:red_nether_bricks
setblock 368 45 503 minecraft:red_nether_bricks
fill 368 45 504 368 48 504 minecraft:pink_terracotta
setblock 369 45 464 minecraft:white_concrete
setblock 369 45 497 minecraft:red_nether_bricks
fill 369 45 498 369 48 498 minecraft:pink_terracotta
setblock 369 45 501 minecraft:pink_terracotta
setblock 369 45 502 minecraft:red_nether_bricks
fill 369 45 503 369 48 503 minecraft:pink_terracotta
fill 370 45 477 370 45 480 minecraft:pink_terracotta
setblock 370 45 481 minecraft:red_nether_bricks
fill 370 45 482 370 45 485 minecraft:pink_terracotta
setblock 370 45 486 minecraft:red_nether_bricks
fill 370 45 487 370 45 490 minecraft:pink_terracotta
setblock 370 45 491 minecraft:red_nether_bricks
fill 370 45 492 370 48 492 minecraft:pink_terracotta
setblock 370 45 496 minecraft:red_nether_bricks
fill 370 45 497 370 48 497 minecraft:pink_terracotta
setblock 370 45 501 minecraft:red_nether_bricks
fill 370 45 502 370 48 502 minecraft:pink_terracotta
setblock 330 46 464 minecraft:pink_terracotta
setblock 330 46 465 minecraft:red_nether_bricks
setblock 330 46 467 minecraft:white_concrete
setblock 330 46 474 minecraft:pink_terracotta
setblock 330 46 475 minecraft:red_nether_bricks
fill 330 46 476 330 49 476 minecraft:pink_terracotta
setblock 330 46 480 minecraft:red_nether_bricks
fill 330 46 481 330 49 481 minecraft:pink_terracotta
setblock 330 46 484 minecraft:pink_terracotta
setblock 330 46 485 minecraft:red_nether_bricks
fill 330 46 486 330 49 486 minecraft:pink_terracotta
fill 330 46 488 330 46 489 minecraft:pink_terracotta
setblock 330 46 490 minecraft:red_nether_bricks
fill 330 46 491 331 48 491 minecraft:pink_terracotta
setblock 330 46 495 minecraft:red_nether_bricks
fill 330 46 496 330 49 496 minecraft:pink_terracotta
setblock 330 46 500 minecraft:red_nether_bricks
fill 330 46 501 330 49 501 minecraft:pink_terracotta
setblock 331 46 464 minecraft:red_nether_bricks
fill 331 46 475 331 49 475 minecraft:pink_terracotta
setblock 331 46 479 minecraft:red_nether_bricks
fill 331 46 480 331 49 480 minecraft:pink_terracotta
setblock 331 46 484 minecraft:red_nether_bricks
fill 331 46 485 331 49 485 minecraft:pink_terracotta
setblock 331 46 488 minecraft:pink_terracotta
setblock 331 46 489 minecraft:red_nether_bricks
fill 331 46 490 331 49 490 minecraft:pink_terracotta
setblock 331 46 498 minecraft:pink_terracotta
setblock 331 46 499 minecraft:red_nether_bricks
fill 331 46 500 331 49 500 minecraft:pink_terracotta
setblock 331 46 503 minecraft:pink_terracotta
setblock 331 46 504 minecraft:red_nether_bricks
fill 332 46 464 335 46 464 minecraft:pink_terracotta
fill 332 46 476 332 46 477 minecraft:pink_terracotta
setblock 332 46 478 minecraft:red_nether_bricks
fill 332 46 479 332 49 479 minecraft:pink_terracotta
setblock 332 46 483 minecraft:red_nether_bricks
fill 332 46 484 332 49 484 minecraft:pink_terracotta
setblock 332 46 488 minecraft:red_nether_bricks
setblock 332 46 503 minecraft:red_nether_bricks
fill 332 46 504 332 49 504 minecraft:pink_terracotta
fill 333 46 465 334 46 465 minecraft:pink_terracotta
fill 333 46 478 333 49 478 minecraft:pink_terracotta
setblock 333 46 482 minecraft:red_nether_bricks
fill 333 46 483 334 48 483 minecraft:pink_terracotta
fill 333 46 485 333 46 486 minecraft:pink_terracotta
fill 333 46 503 333 49 503 minecraft:pink_terracotta
setblock 334 46 480 minecraft:pink_terracotta
setblock 334 46 481 minecraft:red_nether_bricks
fill 334 46 482 334 49 482 minecraft:pink_terracotta
fill 334 46 502 335 47 502 minecraft:pink_terracotta
setblock 335 46 465 minecraft:red_nether_bricks
setblock 336 46 464 minecraft:red_nether_bricks
fill 336 46 465 336 49 465 minecraft:pink_terracotta
setblock 336 46 503 minecraft:pink_terracotta
setblock 336 46 504 minecraft:red_nether_bricks
fill 337 46 464 337 49 464 minecraft:pink_terracotta
setblock 337 46 503 minecraft:red_nether_bricks
fill 337 46 504 337 49 504 minecraft:pink_terracotta
fill 338 46 502 340 49 502 minecraft:white_concrete
fill 338 46 503 338 49 503 minecraft:pink_terracotta
fill 339 46 501 339 49 501 minecraft:white_concrete
setblock 340 46 464 minecraft:pink_terracotta
setblock 340 46 465 minecraft:red_nether_bricks
setblock 340 46 503 minecraft:pink_terracotta
setblock 341 46 464 minecraft:red_nether_bricks
fill 341 46 465 341 49 465 minecraft:pink_terracotta
fill 341 46 503 341 49 503 minecraft:white_concrete
setblock 341 46 504 minecraft:red_nether_bricks
fill 342 46 464 342 49 464 minecraft:pink_terracotta
fill 342 46 504 345 46 504 minecraft:pink_terracotta
setblock 345 46 464 minecraft:pink_terracotta
setblock 346 46 464 minecraft:red_nether_bricks
setblock 346 46 504 minecraft:red_nether_bricks
fill 347 46 464 347 48 465 minecraft:pink_terracotta
fill 347 46 504 347 49 504 minecraft:pink_terracotta
fill 348 46 465 349 46 465 minecraft:pink_terracotta
fill 348 46 503 348 49 503 minecraft:pink_terracotta
setblock 350 46 465 minecraft:red_nether_bricks
setblock 351 46 464 minecraft:red_nether_bricks
fill 351 46 465 351 48 466 minecraft:pink_terracotta
fill 351 46 467 352 48 468 minecraft:red_nether_bricks
fill 351 46 502 352 46 502 minecraft:pink_terracotta
setblock 351 46 504 minecraft:red_nether_bricks
fill 352 46 464 352 49 464 minecraft:pink_terracotta
fill 352 46 466 353 46 466 minecraft:pink_terracotta
setblock 352 46 503 minecraft:red_nether_bricks
fill 352 46 504 352 49 504 minecraft:pink_terracotta
setblock 353 46 502 minecraft:red_nether_bricks
fill 353 46 503 353 49 503 minecraft:pink_terracotta
setblock 354 46 466 minecraft:red_nether_bricks
setblock 354 46 501 minecraft:red_nether_bricks
fill 354 46 502 354 49 502 minecraft:pink_terracotta
setblock 355 46 465 minecraft:red_nether_bricks
fill 355 46 466 355 49 466 minecraft:pink_terracotta
fill 355 46 501 355 49 501 minecraft:pink_terracotta
setblock 356 46 464 minecraft:red_nether_bricks
fill 356 46 465 356 49 465 minecraft:pink_terracotta
setblock 356 46 504 minecraft:red_nether_bricks
fill 357 46 464 357 49 464 minecraft:pink_terracotta
setblock 357 46 503 minecraft:red_nether_bricks
fill 357 46 504 357 49 504 minecraft:pink_terracotta
setblock 358 46 466 minecraft:pink_terracotta
setblock 358 46 501 minecraft:pink_terracotta
setblock 358 46 502 minecraft:red_nether_bricks
fill 358 46 503 358 49 503 minecraft:pink_terracotta
setblock 359 46 465 minecraft:pink_terracotta
setblock 359 46 501 minecraft:red_nether_bricks
fill 359 46 502 359 49 502 minecraft:pink_terracotta
setblock 360 46 465 minecraft:red_nether_bricks
setblock 361 46 464 minecraft:red_nether_bricks
fill 361 46 465 361 49 465 minecraft:pink_terracotta
setblock 361 46 504 minecraft:red_nether_bricks
fill 362 46 464 362 49 464 minecraft:pink_terracotta
setblock 362 46 503 minecraft:red_nether_bricks
fill 362 46 504 362 49 504 minecraft:pink_terracotta
setblock 363 46 502 minecraft:red_nether_bricks
fill 363 46 503 366 46 503 minecraft:pink_terracotta
setblock 364 46 502 minecraft:pink_terracotta
setblock 365 46 464 minecraft:pink_terracotta
setblock 366 46 504 minecraft:red_nether_bricks
setblock 367 46 503 minecraft:red_nether_bricks
fill 367 46 504 367 49 504 minecraft:pink_terracotta
fill 368 46 464 370 46 464 minecraft:pink_terracotta
fill 368 46 503 368 49 503 minecraft:pink_terracotta
setblock 369 46 481 minecraft:red_nether_bricks
fill 369 46 482 369 46 485 minecraft:pink_terracotta
setblock 369 46 486 minecraft:red_nether_bricks
fill 369 46 497 369 49 497 minecraft:pink_terracotta
setblock 369 46 501 minecraft:red_nether_bricks
fill 369 46 502 369 49 502 minecraft:pink_terracotta
setblock 370 46 465 minecraft:red_nether_bricks
setblock 370 46 476 minecraft:white_concrete
fill 370 46 477 370 46 479 minecraft:pink_terracotta
setblock 370 46 480 minecraft:red_nether_bricks
fill 370 46 481 370 46 484 minecraft:pink_terracotta
setblock 370 46 485 minecraft:red_nether_bricks
fill 370 46 486 370 46 489 minecraft:pink_terracotta
setblock 370 46 490 minecraft:red_nether_bricks
fill 370 46 491 370 49 491 minecraft:pink_terracotta
setblock 370 46 495 minecraft:red_nether_bricks
fill 370 46 496 370 49 496 minecraft:pink_terracotta
setblock 370 46 500 minecraft:red_nether_bricks
fill 370 46 501 370 49 501 minecraft:pink_terracotta
setblock 330 47 464 minecraft:red_nether_bricks
fill 330 47 465 330 47 468 minecraft:pink_terracotta
fill 330 47 472 330 47 473 minecraft:pink_terracotta
setblock 330 47 474 minecraft:red_nether_bricks
fill 330 47 475 330 50 475 minecraft:pink_terracotta
setblock 330 47 479 minecraft:red_nether_bricks
fill 330 47 480 330 50 480 minecraft:pink_terracotta
setblock 330 47 484 minecraft:red_nether_bricks
fill 330 47 485 330 50 485 minecraft:pink_terracotta
setblock 330 47 488 minecraft:pink_terracotta
setblock 330 47 489 minecraft:red_nether_bricks
fill 330 47 490 330 50 490 minecraft:pink_terracotta
setblock 330 47 494 minecraft:red_nether_bricks
fill 330 47 495 330 50 495 minecraft:pink_terracotta
setblock 330 47 499 minecraft:red_nether_bricks
fill 330 47 500 330 50 500 minecraft:pink_terracotta
setblock 330 47 503 minecraft:pink_terracotta
setblock 330 47 504 minecraft:red_nether_bricks
fill 331 47 464 333 47 465 minecraft:pink_terracotta
fill 331 47 474 331 50 474 minecraft:pink_terracotta
setblock 331 47 478 minecraft:red_nether_bricks
fill 331 47 479 331 50 479 minecraft:pink_terracotta
setblock 331 47 483 minecraft:red_nether_bricks
fill 331 47 484 331 50 484 minecraft:pink_terracotta
setblock 331 47 488 minecraft:red_nether_bricks
fill 331 47 489 332 49 489 minecraft:pink_terracotta
setblock 331 47 492 minecraft:pink_terracotta
setblock 331 47 498 minecraft:red_nether_bricks
fill 331 47 499 331 49 499 minecraft:pink_terracotta
setblock 331 47 503 minecraft:red_nether_bricks
fill 331 47 504 331 50 504 minecraft:pink_terracotta
setblock 332 47 466 minecraft:light[level=12]
setblock 332 47 474 minecraft:light[level=12]
setblock 332 47 476 minecraft:pink_terracotta
setblock 332 47 477 minecraft:red_nether_bricks
fill 332 47 478 332 50 478 minecraft:pink_terracotta
setblock 332 47 481 minecraft:pink_terracotta
setblock 332 47 482 minecraft:red_nether_bricks
fill 332 47 483 332 50 483 minecraft:pink_terracotta
setblock 332 47 487 minecraft:red_nether_bricks
fill 332 47 488 332 50 488 minecraft:pink_terracotta
setblock 332 47 490 minecraft:light[level=12]
setblock 332 47 498 minecraft:light[level=12]
fill 332 47 503 332 50 503 minecraft:pink_terracotta
setblock 333 47 481 minecraft:red_nether_bricks
fill 333 47 482 333 50 482 minecraft:pink_terracotta
setblock 333 47 485 minecraft:pink_terracotta
setblock 333 47 486 minecraft:red_nether_bricks
fill 333 47 487 333 50 487 minecraft:pink_terracotta
setblock 333 47 502 minecraft:pink_terracotta
setblock 334 47 464 minecraft:pink_terracotta
setblock 334 47 465 minecraft:red_nether_bricks
setblock 334 47 480 minecraft:red_nether_bricks
fill 334 47 481 334 49 481 minecraft:pink_terracotta
setblock 334 47 484 minecraft:pink_terracotta
setblock 335 47 464 minecraft:red_nether_bricks
fill 335 47 465 335 50 465 minecraft:pink_terracotta
setblock 335 47 504 minecraft:red_nether_bricks
fill 336 47 464 336 50 464 minecraft:pink_terracotta
setblock 336 47 503 minecraft:red_nether_bricks
fill 336 47 504 336 50 504 minecraft:pink_terracotta
fill 337 47 465 338 47 465 minecraft:pink_terracotta
fill 337 47 502 337 48 502 minecraft:white_concrete
fill 337 47 503 337 49 503 minecraft:pink_terracotta
fill 338 47 501 338 48 501 minecraft:white_concrete
setblock 339 47 465 minecraft:red_nether_bricks
setblock 340 47 464 minecraft:red_nether_bricks
fill 340 47 465 340 50 465 minecraft:pink_terracotta
setblock 340 47 466 minecraft:light[level=12]
setblock 340 47 474 minecraft:light[level=12]
setblock 340 47 482 minecraft:light[level=12]
setblock 340 47 490 minecraft:light[level=12]
setblock 340 47 498 minecraft:light[level=12]
fill 340 47 501 340 48 501 minecraft:white_concrete
fill 340 47 503 340 49 503 minecraft:white_concrete
setblock 340 47 504 minecraft:red_nether_bricks
fill 341 47 464 341 50 464 minecraft:pink_terracotta
fill 341 47 502 341 48 502 minecraft:white_concrete
fill 341 47 504 344 47 504 minecraft:pink_terracotta
fill 342 47 465 343 47 465 minecraft:pink_terracotta
setblock 344 47 465 minecraft:red_nether_bricks
setblock 345 47 464 minecraft:red_nether_bricks
fill 345 47 465 346 49 465 minecraft:pink_terracotta
setblock 345 47 504 minecraft:red_nether_bricks
fill 346 47 464 346 50 464 minecraft:pink_terracotta
fill 346 47 504 346 50 504 minecraft:pink_terracotta
fill 347 47 503 347 50 503 minecraft:pink_terracotta
setblock 348 47 465 minecraft:pink_terracotta
setblock 348 47 466 minecraft:light[level=12]
setblock 348 47 474 minecraft:light[level=12]
setblock 348 47 482 minecraft:light[level=12]
setblock 348 47 490 minecraft:light[level=12]
setblock 348 47 498 minecraft:light[level=12]
setblock 349 47 465 minecraft:red_nether_bricks
setblock 350 47 464 minecraft:red_nether_bricks
fill 350 47 465 350 49 466 minecraft:pink_terracotta
fill 350 47 502 350 47 503 minecraft:pink_terracotta
setblock 350 47 504 minecraft:red_nether_bricks
fill 351 47 464 351 50 464 minecraft:pink_terracotta
setblock 351 47 502 minecraft:pink_terracotta
setblock 351 47 503 minecraft:red_nether_bricks
fill 351 47 504 351 50 504 minecraft:pink_terracotta
setblock 352 47 466 minecraft:pink_terracotta
setblock 352 47 502 minecraft:red_nether_bricks
fill 352 47 503 352 50 503 minecraft:pink_terracotta
setblock 353 47 466 minecraft:red_nether_bricks
setblock 353 47 501 minecraft:red_nether_bricks
fill 353 47 502 353 50 502 minecraft:pink_terracotta
setblock 354 47 465 minecraft:red_nether_bricks
fill 354 47 466 354 50 466 minecraft:pink_terracotta
fill 354 47 501 354 49 501 minecraft:pink_terracotta
setblock 355 47 464 minecraft:red_nether_bricks
fill 355 47 465 355 50 465 minecraft:pink_terracotta
setblock 355 47 504 minecraft:red_nether_bricks
fill 356 47 464 356 50 464 minecraft:pink_terracotta
setblock 356 47 474 minecraft:light[level=12]
setblock 356 47 482 minecraft:light[level=12]
setblock 356 47 490 minecraft:light[level=12]
setblock 356 47 498 minecraft:light[level=12]
setblock 356 47 503 minecraft:red_nether_bricks
fill 356 47 504 356 50 504 minecraft:pink_terracotta
setblock 357 47 502 minecraft:red_nether_bricks
fill 357 47 503 357 50 503 minecraft:pink_terracotta
setblock 358 47 466 minecraft:red_nether_bricks
setblock 358 47 501 minecraft:red_nether_bricks
fill 358 47 502 358 50 502 minecraft:pink_terracotta
setblock 359 47 465 minecraft:red_nether_bricks
setblock 359 47 501 minecraft:pink_terracotta
setblock 360 47 464 minecraft:red_nether_bricks
fill 360 47 465 360 50 465 minecraft:pink_terracotta
setblock 360 47 504 minecraft:red_nether_bricks
fill 361 47 464 361 50 464 minecraft:pink_terracotta
setblock 361 47 503 minecraft:red_nether_bricks
fill 361 47 504 361 50 504 minecraft:pink_terracotta
setblock 362 47 502 minecraft:red_nether_bricks
fill 362 47 503 365 47 503 minecraft:pink_terracotta
setblock 363 47 502 minecraft:pink_terracotta
setblock 364 47 466 minecraft:light[level=12]
setblock 364 47 474 minecraft:light[level=12]
setblock 364 47 482 minecraft:light[level=12]
setblock 364 47 490 minecraft:light[level=12]
setblock 364 47 498 minecraft:light[level=12]
setblock 365 47 464 minecraft:red_nether_bricks
setblock 365 47 504 minecraft:red_nether_bricks
fill 366 47 464 369 47 464 minecraft:pink_terracotta
setblock 366 47 503 minecraft:red_nether_bricks
fill 366 47 504 366 50 504 minecraft:pink_terracotta
fill 367 47 503 367 50 503 minecraft:pink_terracotta
fill 368 47 502 368 48 502 minecraft:pink_terracotta
setblock 369 47 480 minecraft:red_nether_bricks
fill 369 47 481 369 47 484 minecraft:pink_terracotta
setblock 369 47 485 minecraft:red_nether_bricks
fill 369 47 486 369 47 489 minecraft:pink_terracotta
setblock 369 47 490 minecraft:red_nether_bricks
fill 369 47 496 369 50 496 minecraft:pink_terracotta
setblock 369 47 500 minecraft:red_nether_bricks
fill 369 47 501 369 50 501 minecraft:pink_terracotta
setblock 370 47 464 minecraft:red_nether_bricks
fill 370 47 465 370 49 466 minecraft:pink_terracotta
setblock 370 47 470 minecraft:white_concrete
fill 370 47 476 370 47 478 minecraft:pink_terracotta
setblock 370 47 479 minecraft:red_nether_bricks
fill 370 47 480 370 47 483 minecraft:pink_terracotta
setblock 370 47 484 minecraft:red_nether_bricks
fill 370 47 485 370 47 488 minecraft:pink_terracotta
setblock 370 47 489 minecraft:red_nether_bricks
fill 370 47 490 370 50 490 minecraft:pink_terracotta
setblock 370 47 494 minecraft:red_nether_bricks
fill 370 47 495 370 50 495 minecraft:pink_terracotta
setblock 370 47 499 minecraft:red_nether_bricks
fill 370 47 500 370 50 500 minecraft:pink_terracotta
setblock 370 47 504 minecraft:red_nether_bricks
fill 330 48 464 330 48 467 minecraft:pink_terracotta
setblock 330 48 468 minecraft:red_nether_bricks
fill 330 48 469 330 48 472 minecraft:pink_terracotta
setblock 330 48 473 minecraft:red_nether_bricks
fill 330 48 474 330 51 474 minecraft:pink_terracotta
setblock 330 48 478 minecraft:red_nether_bricks
fill 330 48 479 330 51 479 minecraft:pink_terracotta
setblock 330 48 483 minecraft:red_nether_bricks
fill 330 48 484 330 51 484 minecraft:pink_terracotta
setblock 330 48 488 minecraft:red_nether_bricks
fill 330 48 489 330 51 489 minecraft:pink_terracotta
setblock 330 48 492 minecraft:pink_terracotta
setblock 330 48 493 minecraft:red_nether_bricks
fill 330 48 494 330 51 494 minecraft:pink_terracotta
setblock 330 48 498 minecraft:red_nether_bricks
fill 330 48 499 330 51 499 minecraft:pink_terracotta
setblock 330 48 503 minecraft:red_nether_bricks
fill 330 48 504 330 51 504 minecraft:pink_terracotta
fill 331 48 464 331 48 466 minecraft:pink_terracotta
setblock 331 48 467 minecraft:red_nether_bricks
setblock 331 48 477 minecraft:red_nether_bricks
fill 331 48 478 331 51 478 minecraft:pink_terracotta
setblock 331 48 482 minecraft:red_nether_bricks
fill 331 48 483 331 51 483 minecraft:pink_terracotta
setblock 331 48 486 minecraft:pink_terracotta
setblock 331 48 487 minecraft:red_nether_bricks
fill 331 48 488 331 51 488 minecraft:pink_terracotta
setblock 331 48 492 minecraft:red_nether_bricks
fill 331 48 493 331 51 493 minecraft:pink_terracotta
setblock 331 48 498 minecraft:pink_terracotta
setblock 331 48 502 minecraft:red_nether_bricks
fill 331 48 503 331 51 503 minecraft:pink_terracotta
fill 332 48 464 332 48 465 minecraft:pink_terracotta
setblock 332 48 476 minecraft:red_nether_bricks
fill 332 48 477 332 51 477 minecraft:pink_terracotta
setblock 332 48 481 minecraft:red_nether_bricks
fill 332 48 482 332 51 482 minecraft:pink_terracotta
setblock 332 48 486 minecraft:red_nether_bricks
fill 332 48 487 332 51 487 minecraft:pink_terracotta
setblock 332 48 490 minecraft:pink_terracotta
setblock 333 48 464 minecraft:pink_terracotta
setblock 333 48 465 minecraft:red_nether_bricks
fill 333 48 466 336 48 466 minecraft:pink_terracotta
setblock 333 48 480 minecraft:red_nether_bricks
fill 333 48 481 333 51 481 minecraft:pink_terracotta
setblock 333 48 485 minecraft:red_nether_bricks
fill 333 48 486 333 51 486 minecraft:pink_terracotta
fill 333 48 488 333 49 488 minecraft:pink_terracotta
setblock 334 48 464 minecraft:red_nether_bricks
fill 334 48 465 334 51 465 minecraft:pink_terracotta
setblock 334 48 480 minecraft:pink_terracotta
setblock 334 48 484 minecraft:red_nether_bricks
fill 334 48 485 334 49 485 minecraft:pink_terracotta
setblock 334 48 504 minecraft:red_nether_bricks
fill 335 48 464 335 51 464 minecraft:pink_terracotta
setblock 335 48 503 minecraft:red_nether_bricks
fill 335 48 504 335 51 504 minecraft:pink_terracotta
fill 336 48 503 336 50 503 minecraft:pink_terracotta
setblock 337 48 465 minecraft:pink_terracotta
setblock 337 48 466 minecraft:red_nether_bricks
setblock 338 48 465 minecraft:red_nether_bricks
setblock 339 48 464 minecraft:red_nether_bricks
fill 339 48 465 339 51 465 minecraft:pink_terracotta
setblock 339 48 500 minecraft:black_concrete
setblock 339 48 504 minecraft:red_nether_bricks
fill 340 48 464 340 51 464 minecraft:pink_terracotta
fill 340 48 504 343 48 504 minecraft:pink_terracotta
setblock 342 48 465 minecraft:pink_terracotta
setblock 343 48 465 minecraft:red_nether_bricks
setblock 344 48 464 minecraft:red_nether_bricks
fill 344 48 465 344 51 465 minecraft:pink_terracotta
setblock 344 48 504 minecraft:red_nether_bricks
fill 345 48 464 345 51 464 minecraft:pink_terracotta
fill 345 48 504 345 51 504 minecraft:pink_terracotta
setblock 348 48 465 minecraft:red_nether_bricks
fill 348 48 466 349 50 466 minecraft:pink_terracotta
setblock 349 48 464 minecraft:red_nether_bricks
fill 349 48 465 349 51 465 minecraft:pink_terracotta
setblock 349 48 504 minecraft:red_nether_bricks
fill 350 48 464 350 51 464 minecraft:pink_terracotta
setblock 350 48 502 minecraft:pink_terracotta
setblock 350 48 503 minecraft:red_nether_bricks
fill 350 48 504 350 51 504 minecraft:pink_terracotta
setblock 351 48 502 minecraft:red_nether_bricks
fill 351 48 503 351 51 503 minecraft:pink_terracotta
setblock 352 48 466 minecraft:red_nether_bricks
fill 352 48 502 352 51 502 minecraft:pink_terracotta
setblock 353 48 465 minecraft:red_nether_bricks
fill 353 48 466 353 51 466 minecraft:pink_terracotta
fill 353 48 501 353 49 501 minecraft:pink_terracotta
setblock 354 48 464 minecraft:red_nether_bricks
fill 354 48 465 354 51 465 minecraft:pink_terracotta
setblock 354 48 504 minecraft:red_nether_bricks
fill 355 48 464 355 51 464 minecraft:pink_terracotta
setblock 355 48 503 minecraft:red_nether_bricks
fill 355 48 504 355 51 504 minecraft:pink_terracotta
setblock 356 48 466 minecraft:pink_terracotta
setblock 356 48 502 minecraft:red_nether_bricks
fill 356 48 503 356 51 503 minecraft:pink_terracotta
setblock 357 48 466 minecraft:red_nether_bricks
fill 357 48 488 358 49 488 minecraft:red_concrete
setblock 357 48 501 minecraft:red_nether_bricks
fill 357 48 502 357 51 502 minecraft:pink_terracotta
setblock 358 48 465 minecraft:red_nether_bricks
fill 358 48 466 358 49 466 minecraft:pink_terracotta
setblock 358 48 501 minecraft:pink_terracotta
setblock 359 48 464 minecraft:red_nether_bricks
fill 359 48 465 359 51 465 minecraft:pink_terracotta
setblock 359 48 504 minecraft:red_nether_bricks
fill 360 48 464 360 51 464 minecraft:pink_terracotta
setblock 360 48 503 minecraft:red_nether_bricks
fill 360 48 504 360 51 504 minecraft:pink_terracotta
setblock 361 48 502 minecraft:red_nether_bricks
fill 361 48 503 364 48 503 minecraft:pink_terracotta
setblock 362 48 502 minecraft:pink_terracotta
setblock 363 48 464 minecraft:pink_terracotta
setblock 364 48 464 minecraft:red_nether_bricks
setblock 364 48 504 minecraft:red_nether_bricks
fill 365 48 464 368 48 464 minecraft:pink_terracotta
setblock 365 48 503 minecraft:red_nether_bricks
fill 365 48 504 365 51 504 minecraft:pink_terracotta
fill 366 48 503 366 51 503 minecraft:pink_terracotta
setblock 369 48 464 minecraft:red_nether_bricks
setblock 369 48 479 minecraft:red_nether_bricks
fill 369 48 480 369 48 483 minecraft:pink_terracotta
setblock 369 48 484 minecraft:red_nether_bricks
fill 369 48 485 369 48 488 minecraft:pink_terracotta
setblock 369 48 489 minecraft:red_nether_bricks
fill 369 48 490 369 48 493 minecraft:pink_terracotta
setblock 369 48 494 minecraft:red_nether_bricks
fill 369 48 495 369 51 495 minecraft:pink_terracotta
setblock 369 48 499 minecraft:red_nether_bricks
fill 369 48 500 369 51 500 minecraft:pink_terracotta
setblock 369 48 504 minecraft:red_nether_bricks
fill 370 48 464 370 51 464 minecraft:pink_terracotta
setblock 370 48 467 minecraft:pink_terracotta
fill 370 48 476 370 48 477 minecraft:pink_terracotta
setblock 370 48 478 minecraft:red_nether_bricks
fill 370 48 479 370 48 482 minecraft:pink_terracotta
setblock 370 48 483 minecraft:red_nether_bricks
fill 370 48 484 370 48 487 minecraft:pink_terracotta
setblock 370 48 488 minecraft:red_nether_bricks
fill 370 48 489 370 51 489 minecraft:pink_terracotta
setblock 370 48 493 minecraft:red_nether_bricks
fill 370 48 494 370 51 494 minecraft:pink_terracotta
setblock 370 48 498 minecraft:red_nether_bricks
fill 370 48 499 370 51 499 minecraft:pink_terracotta
setblock 370 48 503 minecraft:red_nether_bricks
fill 370 48 504 370 51 504 minecraft:pink_terracotta
fill 330 49 464 330 49 466 minecraft:pink_terracotta
setblock 330 49 467 minecraft:red_nether_bricks
fill 330 49 468 330 49 471 minecraft:pink_terracotta
setblock 330 49 472 minecraft:red_nether_bricks
fill 330 49 473 331 51 473 minecraft:pink_terracotta
setblock 330 49 477 minecraft:red_nether_bricks
fill 330 49 478 330 52 478 minecraft:pink_terracotta
setblock 330 49 482 minecraft:red_nether_bricks
fill 330 49 483 330 52 483 minecraft:pink_terracotta
setblock 330 49 487 minecraft:red_nether_bricks
fill 330 49 488 330 52 488 minecraft:pink_terracotta
setblock 330 49 491 minecraft:pink_terracotta
setblock 330 49 492 minecraft:red_nether_bricks
fill 330 49 493 330 52 493 minecraft:pink_terracotta
setblock 330 49 497 minecraft:red_nether_bricks
fill 330 49 498 330 51 498 minecraft:pink_terracotta
setblock 330 49 502 minecraft:red_nether_bricks
fill 330 49 503 330 52 503 minecraft:pink_terracotta
fill 331 49 464 331 49 465 minecraft:pink_terracotta
setblock 331 49 466 minecraft:red_nether_bricks
fill 331 49 467 331 49 470 minecraft:pink_terracotta
setblock 331 49 471 minecraft:red_nether_bricks
fill 331 49 472 331 52 472 minecraft:pink_terracotta
setblock 331 49 476 minecraft:red_nether_bricks
fill 331 49 477 331 52 477 minecraft:pink_terracotta
setblock 331 49 481 minecraft:red_nether_bricks
fill 331 49 482 331 52 482 minecraft:pink_terracotta
setblock 331 49 486 minecraft:red_nether_bricks
fill 331 49 487 331 52 487 minecraft:pink_terracotta
setblock 331 49 491 minecraft:red_nether_bricks
fill 331 49 492 331 52 492 minecraft:pink_terracotta
setblock 331 49 501 minecraft:red_nether_bricks
fill 331 49 502 331 50 502 minecraft:pink_terracotta
setblock 332 49 464 minecraft:pink_terracotta
setblock 332 49 465 minecraft:red_nether_bricks
fill 332 49 466 335 49 466 minecraft:pink_terracotta
fill 332 49 476 332 50 476 minecraft:pink_terracotta
setblock 332 49 480 minecraft:red_nether_bricks
fill 332 49 481 332 52 481 minecraft:pink_terracotta
setblock 332 49 485 minecraft:red_nether_bricks
fill 332 49 486 332 52 486 minecraft:pink_terracotta
setblock 332 49 490 minecraft:red_nether_bricks
setblock 333 49 464 minecraft:red_nether_bricks
fill 333 49 465 333 52 465 minecraft:pink_terracotta
setblock 333 49 479 minecraft:red_nether_bricks
fill 333 49 480 333 51 480 minecraft:pink_terracotta
setblock 333 49 483 minecraft:pink_terracotta
setblock 333 49 484 minecraft:red_nether_bricks
fill 333 49 485 333 52 485 minecraft:pink_terracotta
setblock 333 49 504 minecraft:red_nether_bricks
fill 334 49 464 334 52 464 minecraft:pink_terracotta
setblock 334 49 483 minecraft:red_nether_bricks
setblock 334 49 484 minecraft:pink_terracotta
setblock 334 49 503 minecraft:red_nether_bricks
fill 334 49 504 334 52 504 minecraft:pink_terracotta
fill 335 49 503 335 50 503 minecraft:pink_terracotta
setblock 336 49 466 minecraft:red_nether_bricks
setblock 337 49 465 minecraft:red_nether_bricks
fill 337 49 466 338 50 466 minecraft:pink_terracotta
setblock 338 49 464 minecraft:red_nether_bricks
fill 338 49 465 338 52 465 minecraft:pink_terracotta
setblock 338 49 504 minecraft:red_nether_bricks
fill 339 49 464 339 52 464 minecraft:pink_terracotta
fill 339 49 503 339 50 503 minecraft:white_concrete
fill 339 49 504 342 49 504 minecraft:pink_terracotta
setblock 342 49 465 minecraft:red_nether_bricks
setblock 343 49 464 minecraft:red_nether_bricks
fill 343 49 465 343 52 465 minecraft:pink_terracotta
setblock 343 49 504 minecraft:red_nether_bricks
fill 344 49 464 344 52 464 minecraft:pink_terracotta
fill 344 49 504 344 52 504 minecraft:pink_terracotta
setblock 347 49 464 minecraft:pink_terracotta
setblock 347 49 465 minecraft:red_nether_bricks
fill 347 49 466 347 52 466 minecraft:pink_terracotta
setblock 348 49 464 minecraft:red_nether_bricks
fill 348 49 465 348 52 465 minecraft:pink_terracotta
setblock 348 49 504 minecraft:red_nether_bricks
fill 349 49 464 349 52 464 minecraft:pink_terracotta
setblock 349 49 503 minecraft:red_nether_bricks
fill 349 49 504 349 52 504 minecraft:pink_terracotta
setblock 350 49 502 minecraft:red_nether_bricks
fill 350 49 503 350 52 503 minecraft:pink_terracotta
setblock 351 49 465 minecraft:pink_terracotta
fill 351 49 466 351 49 468 minecraft:red_nether_bricks
fill 351 49 502 351 52 502 minecraft:pink_terracotta
setblock 352 49 465 minecraft:red_nether_bricks
fill 352 49 466 352 51 467 minecraft:pink_terracotta
fill 352 49 468 352 82 468 minecraft:red_nether_bricks
setblock 353 49 464 minecraft:red_nether_bricks
fill 353 49 465 353 52 465 minecraft:pink_terracotta
fill 353 49 467 354 49 467 minecraft:pink_terracotta
setblock 353 49 504 minecraft:red_nether_bricks
fill 354 49 464 354 52 464 minecraft:pink_terracotta
setblock 354 49 503 minecraft:red_nether_bricks
fill 354 49 504 354 52 504 minecraft:pink_terracotta
setblock 355 49 502 minecraft:red_nether_bricks
fill 355 49 503 355 52 503 minecraft:pink_terracotta
setblock 356 49 466 minecraft:red_nether_bricks
setblock 356 49 501 minecraft:red_nether_bricks
fill 356 49 502 356 51 502 minecraft:pink_terracotta
setblock 357 49 465 minecraft:red_nether_bricks
fill 357 49 466 357 51 466 minecraft:pink_terracotta
setblock 358 49 464 minecraft:red_nether_bricks
fill 358 49 465 358 52 465 minecraft:pink_terracotta
setblock 358 49 504 minecraft:red_nether_bricks
fill 359 49 464 359 52 464 minecraft:pink_terracotta
setblock 359 49 503 minecraft:red_nether_bricks
fill 359 49 504 359 52 504 minecraft:pink_terracotta
setblock 360 49 502 minecraft:red_nether_bricks
fill 360 49 503 363 49 503 minecraft:pink_terracotta
setblock 361 49 502 minecraft:pink_terracotta
setblock 363 49 464 minecraft:red_nether_bricks
setblock 363 49 504 minecraft:red_nether_bricks
fill 364 49 464 367 49 464 minecraft:pink_terracotta
setblock 364 49 503 minecraft:red_nether_bricks
fill 364 49 504 364 52 504 minecraft:pink_terracotta
fill 365 49 503 365 51 503 minecraft:pink_terracotta
setblock 368 49 464 minecraft:red_nether_bricks
setblock 368 49 483 minecraft:pink_terracotta
setblock 368 49 484 minecraft:red_nether_bricks
fill 368 49 485 369 49 487 minecraft:pink_terracotta
setblock 368 49 504 minecraft:red_nether_bricks
fill 369 49 464 369 52 464 minecraft:pink_terracotta
fill 369 49 479 369 49 482 minecraft:pink_terracotta
setblock 369 49 483 minecraft:red_nether_bricks
fill 369 49 484 370 51 484 minecraft:pink_terracotta
setblock 369 49 488 minecraft:red_nether_bricks
fill 369 49 489 369 49 492 minecraft:pink_terracotta
setblock 369 49 493 minecraft:red_nether_bricks
fill 369 49 494 369 52 494 minecraft:pink_terracotta
setblock 369 49 498 minecraft:red_nether_bricks
fill 369 49 499 369 51 499 minecraft:pink_terracotta
setblock 369 49 503 minecraft:red_nether_bricks
fill 369 49 504 369 52 504 minecraft:pink_terracotta
setblock 370 49 467 minecraft:red_nether_bricks
fill 370 49 468 370 52 468 minecraft:pink_terracotta
setblock 370 49 476 minecraft:pink_terracotta
setblock 370 49 477 minecraft:red_nether_bricks
fill 370 49 478 370 49 481 minecraft:pink_terracotta
setblock 370 49 482 minecraft:red_nether_bricks
fill 370 49 483 370 52 483 minecraft:pink_terracotta
fill 370 49 485 370 49 486 minecraft:pink_terracotta
setblock 370 49 487 minecraft:red_nether_bricks
fill 370 49 488 370 52 488 minecraft:pink_terracotta
setblock 370 49 492 minecraft:red_nether_bricks
fill 370 49 493 370 52 493 minecraft:pink_terracotta
setblock 370 49 497 minecraft:red_nether_bricks
fill 370 49 498 370 52 498 minecraft:pink_terracotta
setblock 370 49 502 minecraft:red_nether_bricks
fill 370 49 503 370 52 503 minecraft:pink_terracotta
fill 330 50 464 330 50 465 minecraft:pink_terracotta
setblock 330 50 466 minecraft:red_nether_bricks
fill 330 50 467 330 50 470 minecraft:pink_terracotta
setblock 330 50 471 minecraft:red_nether_bricks
fill 330 50 472 330 53 472 minecraft:pink_terracotta
setblock 330 50 476 minecraft:red_nether_bricks
fill 330 50 477 330 53 477 minecraft:pink_terracotta
setblock 330 50 481 minecraft:red_nether_bricks
fill 330 50 482 330 53 482 minecraft:pink_terracotta
setblock 330 50 486 minecraft:red_nether_bricks
fill 330 50 487 330 53 487 minecraft:pink_terracotta
setblock 330 50 491 minecraft:red_nether_bricks
fill 330 50 492 330 53 492 minecraft:pink_terracotta
setblock 330 50 496 minecraft:red_nether_bricks
fill 330 50 497 330 51 497 minecraft:pink_terracotta
setblock 330 50 501 minecraft:red_nether_bricks
fill 330 50 502 330 53 502 minecraft:pink_terracotta
setblock 331 50 464 minecraft:pink_terracotta
setblock 331 50 465 minecraft:red_nether_bricks
fill 331 50 466 331 50 469 minecraft:pink_terracotta
setblock 331 50 470 minecraft:red_nether_bricks
fill 331 50 471 331 53 471 minecraft:pink_terracotta
setblock 331 50 475 minecraft:red_nether_bricks
fill 331 50 476 331 53 476 minecraft:pink_terracotta
setblock 331 50 480 minecraft:red_nether_bricks
fill 331 50 481 331 53 481 minecraft:pink_terracotta
setblock 331 50 485 minecraft:red_nether_bricks
fill 331 50 486 331 53 486 minecraft:pink_terracotta
setblock 331 50 489 minecraft:pink_terracotta
setblock 331 50 490 minecraft:red_nether_bricks
fill 331 50 491 332 51 491 minecraft:pink_terracotta
setblock 331 50 501 minecraft:pink_terracotta
setblock 332 50 464 minecraft:red_nether_bricks
fill 332 50 465 332 50 468 minecraft:pink_terracotta
setblock 332 50 479 minecraft:red_nether_bricks
fill 332 50 480 332 53 480 minecraft:pink_terracotta
setblock 332 50 484 minecraft:red_nether_bricks
fill 332 50 485 332 53 485 minecraft:pink_terracotta
setblock 332 50 489 minecraft:red_nether_bricks
fill 332 50 490 332 53 490 minecraft:pink_terracotta
setblock 332 50 504 minecraft:red_nether_bricks
fill 333 50 464 333 53 464 minecraft:pink_terracotta
fill 333 50 466 334 50 466 minecraft:pink_terracotta
setblock 333 50 479 minecraft:pink_terracotta
setblock 333 50 483 minecraft:red_nether_bricks
fill 333 50 484 333 52 484 minecraft:pink_terracotta
setblock 333 50 488 minecraft:red_nether_bricks
setblock 333 50 503 minecraft:red_nether_bricks
fill 333 50 504 333 53 504 minecraft:pink_terracotta
fill 334 50 503 334 51 503 minecraft:pink_terracotta
setblock 335 50 466 minecraft:red_nether_bricks
setblock 336 50 465 minecraft:red_nether_bricks
fill 336 50 466 336 52 466 minecraft:pink_terracotta
setblock 337 50 464 minecraft:red_nether_bricks
fill 337 50 465 337 53 465 minecraft:pink_terracotta
setblock 337 50 504 minecraft:red_nether_bricks
fill 338 50 464 338 53 464 minecraft:pink_terracotta
fill 338 50 504 341 50 504 minecraft:pink_terracotta
setblock 341 50 465 minecraft:red_nether_bricks
setblock 342 50 464 minecraft:red_nether_bricks
fill 342 50 465 342 53 465 minecraft:pink_terracotta
setblock 342 50 504 minecraft:red_nether_bricks
fill 343 50 464 343 53 464 minecraft:pink_terracotta
fill 343 50 504 343 51 504 minecraft:pink_terracotta
setblock 345 50 465 minecraft:pink_terracotta
setblock 346 50 465 minecraft:red_nether_bricks
fill 346 50 466 346 53 466 minecraft:pink_terracotta
setblock 347 50 464 minecraft:red_nether_bricks
fill 347 50 465 347 53 465 minecraft:pink_terracotta
setblock 347 50 504 minecraft:red_nether_bricks
fill 348 50 464 348 53 464 minecraft:pink_terracotta
setblock 348 50 503 minecraft:red_nether_bricks
fill 348 50 504 348 53 504 minecraft:pink_terracotta
fill 349 50 503 349 53 503 minecraft:pink_terracotta
setblock 350 50 465 minecraft:pink_terracotta
setblock 350 50 466 minecraft:red_nether_bricks
fill 350 50 502 350 51 502 minecraft:pink_terracotta
setblock 351 50 465 minecraft:red_nether_bricks
fill 351 50 466 351 52 467 minecraft:pink_terracotta
fill 351 50 468 351 82 468 minecraft:red_nether_bricks
setblock 352 50 464 minecraft:red_nether_bricks
fill 352 50 465 352 53 465 minecraft:pink_terracotta
setblock 352 50 504 minecraft:red_nether_bricks
fill 353 50 464 353 53 464 minecraft:pink_terracotta
setblock 353 50 467 minecraft:pink_terracotta
setblock 353 50 503 minecraft:red_nether_bricks
fill 353 50 504 353 53 504 minecraft:pink_terracotta
setblock 354 50 467 minecraft:red_nether_bricks
setblock 354 50 502 minecraft:red_nether_bricks
fill 354 50 503 354 53 503 minecraft:pink_terracotta
setblock 355 50 466 minecraft:red_nether_bricks
fill 355 50 502 355 52 502 minecraft:pink_terracotta
setblock 356 50 465 minecraft:red_nether_bricks
fill 356 50 466 356 52 466 minecraft:pink_terracotta
setblock 357 50 464 minecraft:red_nether_bricks
fill 357 50 465 357 53 465 minecraft:pink_terracotta
setblock 357 50 504 minecraft:red_nether_bricks
fill 358 50 464 358 53 464 minecraft:pink_terracotta
setblock 358 50 503 minecraft:red_nether_bricks
fill 358 50 504 358 53 504 minecraft:pink_terracotta
setblock 359 50 502 minecraft:red_nether_bricks
fill 359 50 503 362 50 503 minecraft:pink_terracotta
setblock 362 50 464 minecraft:red_nether_bricks
setblock 362 50 504 minecraft:red_nether_bricks
fill 363 50 464 366 50 464 minecraft:pink_terracotta
setblock 363 50 503 minecraft:red_nether_bricks
fill 363 50 504 363 53 504 minecraft:pink_terracotta
fill 364 50 484 364 51 485 minecraft:red_concrete
setblock 364 50 503 minecraft:pink_terracotta
setblock 367 50 464 minecraft:red_nether_bricks
setblock 367 50 504 minecraft:red_nether_bricks
fill 368 50 464 368 53 464 minecraft:pink_terracotta
setblock 368 50 483 minecraft:red_nether_bricks
fill 368 50 484 368 50 487 minecraft:pink_terracotta
setblock 368 50 488 minecraft:red_nether_bricks
fill 368 50 489 369 52 489 minecraft:pink_terracotta
setblock 368 50 503 minecraft:red_nether_bricks
fill 368 50 504 368 53 504 minecraft:pink_terracotta
fill 369 50 465 370 50 465 minecraft:pink_terracotta
fill 369 50 480 369 50 481 minecraft:pink_terracotta
setblock 369 50 482 minecraft:red_nether_bricks
fill 369 50 483 369 53 483 minecraft:pink_terracotta
fill 369 50 485 369 50 486 minecraft:pink_terracotta
setblock 369 50 487 minecraft:red_nether_bricks
fill 369 50 488 369 53 488 minecraft:pink_terracotta
fill 369 50 490 369 50 491 minecraft:pink_terracotta
setblock 369 50 492 minecraft:red_nether_bricks
fill 369 50 493 369 53 493 minecraft:pink_terracotta
setblock 369 50 497 minecraft:red_nether_bricks
fill 369 50 498 369 51 498 minecraft:pink_terracotta
setblock 369 50 502 minecraft:red_nether_bricks
fill 369 50 503 369 52 503 minecraft:pink_terracotta
setblock 370 50 466 minecraft:red_nether_bricks
fill 370 50 467 370 53 467 minecraft:pink_terracotta
fill 370 50 469 370 51 469 minecraft:pink_terracotta
setblock 370 50 471 minecraft:white_concrete
setblock 370 50 476 minecraft:red_nether_bricks
fill 370 50 477 370 50 480 minecraft:pink_terracotta
setblock 370 50 481 minecraft:red_nether_bricks
fill 370 50 482 370 53 482 minecraft:pink_terracotta
setblock 370 50 485 minecraft:pink_terracotta
setblock 370 50 486 minecraft:red_nether_bricks
fill 370 50 487 370 53 487 minecraft:pink_terracotta
setblock 370 50 491 minecraft:red_nether_bricks
fill 370 50 492 370 53 492 minecraft:pink_terracotta
setblock 370 50 496 minecraft:red_nether_bricks
fill 370 50 497 370 53 497 minecraft:pink_terracotta
setblock 370 50 501 minecraft:red_nether_bricks
fill 370 50 502 370 53 502 minecraft:pink_terracotta
setblock 330 51 464 minecraft:pink_terracotta
setblock 330 51 465 minecraft:red_nether_bricks
fill 330 51 466 330 51 469 minecraft:pink_terracotta
setblock 330 51 470 minecraft:red_nether_bricks
fill 330 51 471 330 54 471 minecraft:pink_terracotta
setblock 330 51 475 minecraft:red_nether_bricks
fill 330 51 476 330 54 476 minecraft:pink_terracotta
setblock 330 51 480 minecraft:red_nether_bricks
fill 330 51 481 330 54 481 minecraft:pink_terracotta
setblock 330 51 485 minecraft:red_nether_bricks
fill 330 51 486 330 54 486 minecraft:pink_terracotta
setblock 330 51 490 minecraft:red_nether_bricks
fill 330 51 491 330 54 491 minecraft:pink_terracotta
setblock 330 51 495 minecraft:red_nether_bricks
fill 330 51 496 330 52 496 minecraft:pink_terracotta
setblock 330 51 500 minecraft:red_nether_bricks
fill 330 51 501 330 52 501 minecraft:pink_terracotta
setblock 331 51 464 minecraft:red_nether_bricks
fill 331 51 465 331 51 468 minecraft:pink_terracotta
setblock 331 51 469 minecraft:red_nether_bricks
fill 331 51 470 331 54 470 minecraft:pink_terracotta
setblock 331 51 474 minecraft:red_nether_bricks
fill 331 51 475 331 54 475 minecraft:pink_terracotta
setblock 331 51 479 minecraft:red_nether_bricks
fill 331 51 480 331 54 480 minecraft:pink_terracotta
setblock 331 51 484 minecraft:red_nether_bricks
fill 331 51 485 331 54 485 minecraft:pink_terracotta
setblock 331 51 489 minecraft:red_nether_bricks
fill 331 51 490 331 54 490 minecraft:pink_terracotta
setblock 331 51 504 minecraft:red_nether_bricks
fill 332 51 464 332 51 467 minecraft:pink_terracotta
setblock 332 51 468 minecraft:red_nether_bricks
fill 332 51 469 332 54 469 minecraft:pink_terracotta
setblock 332 51 478 minecraft:red_nether_bricks
fill 332 51 479 332 52 479 minecraft:pink_terracotta
setblock 332 51 483 minecraft:red_nether_bricks
fill 332 51 484 332 54 484 minecraft:pink_terracotta
setblock 332 51 488 minecraft:red_nether_bricks
fill 332 51 489 332 54 489 minecraft:pink_terracotta
setblock 332 51 503 minecraft:red_nether_bricks
fill 332 51 504 332 54 504 minecraft:pink_terracotta
setblock 333 51 466 minecraft:pink_terracotta
setblock 333 51 482 minecraft:red_nether_bricks
fill 333 51 483 333 52 483 minecraft:pink_terracotta
setblock 333 51 487 minecraft:red_nether_bricks
setblock 333 51 488 minecraft:pink_terracotta
setblock 333 51 503 minecraft:pink_terracotta
setblock 334 51 466 minecraft:red_nether_bricks
setblock 335 51 465 minecraft:red_nether_bricks
fill 335 51 466 335 53 466 minecraft:pink_terracotta
setblock 336 51 464 minecraft:red_nether_bricks
fill 336 51 465 336 54 465 minecraft:pink_terracotta
setblock 336 51 504 minecraft:red_nether_bricks
fill 337 51 464 337 54 464 minecraft:pink_terracotta
setblock 337 51 466 minecraft:pink_terracotta
fill 337 51 504 340 51 504 minecraft:pink_terracotta
setblock 340 51 465 minecraft:red_nether_bricks
setblock 341 51 464 minecraft:red_nether_bricks
fill 341 51 465 341 54 465 minecraft:pink_terracotta
setblock 341 51 504 minecraft:red_nether_bricks
fill 342 51 464 342 54 464 minecraft:pink_terracotta
setblock 342 51 504 minecraft:pink_terracotta
setblock 345 51 465 minecraft:red_nether_bricks
setblock 346 51 464 minecraft:red_nether_bricks
fill 346 51 465 346 54 465 minecraft:pink_terracotta
setblock 346 51 504 minecraft:red_nether_bricks
fill 347 51 464 347 54 464 minecraft:pink_terracotta
setblock 347 51 503 minecraft:red_nether_bricks
fill 347 51 504 347 54 504 minecraft:pink_terracotta
setblock 348 51 466 minecraft:pink_terracotta
fill 348 51 503 348 54 503 minecraft:pink_terracotta
setblock 349 51 466 minecraft:red_nether_bricks
setblock 350 51 465 minecraft:red_nether_bricks
fill 350 51 466 350 53 467 minecraft:pink_terracotta
setblock 351 51 464 minecraft:red_nether_bricks
fill 351 51 465 351 54 465 minecraft:pink_terracotta
setblock 351 51 504 minecraft:red_nether_bricks
fill 352 51 464 352 54 464 minecraft:pink_terracotta
setblock 352 51 503 minecraft:red_nether_bricks
fill 352 51 504 352 54 504 minecraft:pink_terracotta
fill 353 51 467 353 82 467 minecraft:red_nether_bricks
setblock 353 51 502 minecraft:red_nether_bricks
fill 353 51 503 353 54 503 minecraft:pink_terracotta
setblock 354 51 466 minecraft:red_nether_bricks
fill 354 51 502 354 52 502 minecraft:pink_terracotta
setblock 355 51 465 minecraft:red_nether_bricks
fill 355 51 466 355 53 466 minecraft:pink_terracotta
setblock 356 51 464 minecraft:red_nether_bricks
fill 356 51 465 356 54 465 minecraft:pink_terracotta
setblock 356 51 504 minecraft:red_nether_bricks
fill 357 51 464 357 54 464 minecraft:pink_terracotta
setblock 357 51 503 minecraft:red_nether_bricks
fill 357 51 504 357 54 504 minecraft:pink_terracotta
fill 358 51 503 361 51 503 minecraft:pink_terracotta
setblock 361 51 464 minecraft:red_nether_bricks
setblock 361 51 504 minecraft:red_nether_bricks
fill 362 51 464 365 51 464 minecraft:pink_terracotta
setblock 362 51 503 minecraft:red_nether_bricks
fill 362 51 504 362 53 504 minecraft:pink_terracotta
setblock 366 51 464 minecraft:red_nether_bricks
setblock 366 51 504 minecraft:red_nether_bricks
fill 367 51 464 367 54 464 minecraft:pink_terracotta
setblock 367 51 503 minecraft:red_nether_bricks
fill 367 51 504 367 54 504 minecraft:pink_terracotta
fill 368 51 483 368 51 486 minecraft:pink_terracotta
setblock 368 51 487 minecraft:red_nether_bricks
fill 368 51 488 368 54 488 minecraft:pink_terracotta
fill 368 51 490 369 51 490 minecraft:pink_terracotta
fill 368 51 503 368 52 503 minecraft:pink_terracotta
setblock 369 51 465 minecraft:pink_terracotta
setblock 369 51 480 minecraft:pink_terracotta
setblock 369 51 481 minecraft:red_nether_bricks
fill 369 51 482 369 54 482 minecraft:pink_terracotta
setblock 369 51 485 minecraft:pink_terracotta
setblock 369 51 486 minecraft:red_nether_bricks
fill 369 51 487 369 54 487 minecraft:pink_terracotta
setblock 369 51 491 minecraft:red_nether_bricks
fill 369 51 492 369 54 492 minecraft:pink_terracotta
setblock 369 51 496 minecraft:red_nether_bricks
setblock 369 51 501 minecraft:red_nether_bricks
fill 369 51 502 369 52 502 minecraft:pink_terracotta
setblock 370 51 465 minecraft:red_nether_bricks
fill 370 51 466 370 54 466 minecraft:pink_terracotta
setblock 370 51 470 minecraft:red_nether_bricks
fill 370 51 476 370 51 479 minecraft:pink_terracotta
setblock 370 51 480 minecraft:red_nether_bricks
fill 370 51 481 370 54 481 minecraft:pink_terracotta
setblock 370 51 485 minecraft:red_nether_bricks
fill 370 51 486 370 54 486 minecraft:pink_terracotta
setblock 370 51 490 minecraft:red_nether_bricks
fill 370 51 491 370 54 491 minecraft:pink_terracotta
setblock 370 51 495 minecraft:red_nether_bricks
fill 370 51 496 370 54 496 minecraft:pink_terracotta
setblock 370 51 500 minecraft:red_nether_bricks
fill 370 51 501 370 54 501 minecraft:pink_terracotta
setblock 330 52 464 minecraft:red_nether_bricks
fill 330 52 465 330 52 468 minecraft:pink_terracotta
setblock 330 52 469 minecraft:red_nether_bricks
fill 330 52 470 330 55 470 minecraft:pink_terracotta
setblock 330 52 473 minecraft:pink_terracotta
setblock 330 52 474 minecraft:red_nether_bricks
fill 330 52 475 330 55 475 minecraft:pink_terracotta
setblock 330 52 479 minecraft:red_nether_bricks
fill 330 52 480 330 55 480 minecraft:pink_terracotta
setblock 330 52 484 minecraft:red_nether_bricks
fill 330 52 485 330 55 485 minecraft:pink_terracotta
setblock 330 52 489 minecraft:red_nether_bricks
fill 330 52 490 330 55 490 minecraft:pink_terracotta
setblock 330 52 494 minecraft:red_nether_bricks
fill 330 52 495 330 55 495 minecraft:pink_terracotta
setblock 330 52 500 minecraft:pink_terracotta
setblock 330 52 504 minecraft:red_nether_bricks
fill 331 52 464 331 52 467 minecraft:pink_terracotta
setblock 331 52 468 minecraft:red_nether_bricks
fill 331 52 469 331 55 469 minecraft:pink_terracotta
setblock 331 52 473 minecraft:red_nether_bricks
fill 331 52 474 331 55 474 minecraft:pink_terracotta
setblock 331 52 478 minecraft:red_nether_bricks
fill 331 52 479 331 55 479 minecraft:pink_terracotta
setblock 331 52 483 minecraft:red_nether_bricks
fill 331 52 484 331 55 484 minecraft:pink_terracotta
setblock 331 52 488 minecraft:red_nether_bricks
fill 331 52 489 331 55 489 minecraft:pink_terracotta
fill 331 52 491 331 53 491 minecraft:pink_terracotta
setblock 331 52 493 minecraft:red_nether_bricks
fill 331 52 504 331 54 504 minecraft:pink_terracotta
fill 332 52 464 332 52 466 minecraft:pink_terracotta
setblock 332 52 467 minecraft:red_nether_bricks
fill 332 52 468 332 55 468 minecraft:pink_terracotta
setblock 332 52 482 minecraft:red_nether_bricks
fill 332 52 483 332 54 483 minecraft:pink_terracotta
setblock 332 52 487 minecraft:red_nether_bricks
fill 332 52 488 332 55 488 minecraft:pink_terracotta
setblock 333 52 466 minecraft:red_nether_bricks
setblock 333 52 482 minecraft:pink_terracotta
setblock 333 52 486 minecraft:red_nether_bricks
setblock 333 52 487 minecraft:pink_terracotta
setblock 334 52 465 minecraft:red_nether_bricks
fill 334 52 466 334 54 466 minecraft:pink_terracotta
setblock 335 52 464 minecraft:red_nether_bricks
fill 335 52 465 335 55 465 minecraft:pink_terracotta
setblock 335 52 504 minecraft:red_nether_bricks
fill 336 52 464 336 55 464 minecraft:pink_terracotta
fill 336 52 504 337 52 504 minecraft:pink_terracotta
setblock 339 52 465 minecraft:red_nether_bricks
setblock 340 52 464 minecraft:red_nether_bricks
fill 340 52 465 340 54 465 minecraft:pink_terracotta
fill 341 52 464 341 55 464 minecraft:pink_terracotta
setblock 344 52 465 minecraft:red_nether_bricks
setblock 345 52 464 minecraft:red_nether_bricks
fill 345 52 465 345 54 466 minecraft:pink_terracotta
setblock 345 52 504 minecraft:red_nether_bricks
fill 346 52 464 346 55 464 minecraft:pink_terracotta
fill 346 52 504 346 55 504 minecraft:pink_terracotta
setblock 347 52 503 minecraft:pink_terracotta
setblock 348 52 466 minecraft:red_nether_bricks
setblock 349 52 465 minecraft:red_nether_bricks
fill 349 52 466 349 55 466 minecraft:pink_terracotta
setblock 350 52 464 minecraft:red_nether_bricks
fill 350 52 465 350 55 465 minecraft:pink_terracotta
setblock 350 52 504 minecraft:red_nether_bricks
fill 351 52 464 351 55 464 minecraft:pink_terracotta
setblock 351 52 503 minecraft:red_nether_bricks
fill 351 52 504 351 55 504 minecraft:pink_terracotta
setblock 352 52 466 minecraft:pink_terracotta
fill 352 52 467 352 82 467 minecraft:red_nether_bricks
setblock 352 52 502 minecraft:red_nether_bricks
fill 352 52 503 352 55 503 minecraft:pink_terracotta
setblock 353 52 466 minecraft:red_nether_bricks
setblock 353 52 502 minecraft:pink_terracotta
setblock 354 52 465 minecraft:red_nether_bricks
fill 354 52 466 354 54 466 minecraft:pink_terracotta
setblock 355 52 464 minecraft:red_nether_bricks
fill 355 52 465 355 55 465 minecraft:pink_terracotta
setblock 355 52 504 minecraft:red_nether_bricks
fill 356 52 464 356 55 464 minecraft:pink_terracotta
setblock 356 52 503 minecraft:red_nether_bricks
fill 356 52 504 356 55 504 minecraft:pink_terracotta
fill 357 52 503 359 52 503 minecraft:pink_terracotta
setblock 360 52 464 minecraft:red_nether_bricks
setblock 360 52 504 minecraft:red_nether_bricks
fill 361 52 464 364 52 464 minecraft:pink_terracotta
fill 361 52 504 361 53 504 minecraft:pink_terracotta
setblock 365 52 464 minecraft:red_nether_bricks
setblock 365 52 504 minecraft:red_nether_bricks
fill 366 52 464 366 55 464 minecraft:pink_terracotta
fill 366 52 504 366 55 504 minecraft:pink_terracotta
setblock 367 52 503 minecraft:pink_terracotta
fill 368 52 484 368 52 485 minecraft:pink_terracotta
setblock 368 52 486 minecraft:red_nether_bricks
fill 368 52 487 368 55 487 minecraft:pink_terracotta
setblock 368 52 490 minecraft:pink_terracotta
setblock 368 52 491 minecraft:red_nether_bricks
setblock 369 52 465 minecraft:red_nether_bricks
fill 369 52 466 369 55 466 minecraft:pink_terracotta
setblock 369 52 480 minecraft:red_nether_bricks
fill 369 52 481 369 55 481 minecraft:pink_terracotta
setblock 369 52 484 minecraft:pink_terracotta
setblock 369 52 485 minecraft:red_nether_bricks
fill 369 52 486 369 55 486 minecraft:pink_terracotta
setblock 369 52 490 minecraft:red_nether_bricks
fill 369 52 491 369 55 491 minecraft:pink_terracotta
setblock 369 52 495 minecraft:red_nether_bricks
setblock 369 52 501 minecraft:pink_terracotta
setblock 370 52 464 minecraft:red_nether_bricks
fill 370 52 465 370 55 465 minecraft:pink_terracotta
setblock 370 52 469 minecraft:red_nether_bricks
fill 370 52 470 370 54 471 minecraft:pink_terracotta
fill 370 52 476 370 52 478 minecraft:pink_terracotta
setblock 370 52 479 minecraft:red_nether_bricks
fill 370 52 480 370 55 480 minecraft:pink_terracotta
setblock 370 52 484 minecraft:red_nether_bricks
fill 370 52 485 370 55 485 minecraft:pink_terracotta
setblock 370 52 489 minecraft:red_nether_bricks
fill 370 52 490 370 55 490 minecraft:pink_terracotta
setblock 370 52 494 minecraft:red_nether_bricks
fill 370 52 495 370 55 495 minecraft:pink_terracotta
setblock 370 52 499 minecraft:red_nether_bricks
fill 370 52 500 370 55 500 minecraft:pink_terracotta
setblock 370 52 504 minecraft:red_nether_bricks
fill 330 53 464 330 53 467 minecraft:pink_terracotta
setblock 330 53 468 minecraft:red_nether_bricks
fill 330 53 469 330 56 469 minecraft:pink_terracotta
setblock 330 53 473 minecraft:red_nether_bricks
fill 330 53 474 330 56 474 minecraft:pink_terracotta
setblock 330 53 478 minecraft:red_nether_bricks
fill 330 53 479 330 56 479 minecraft:pink_terracotta
setblock 330 53 483 minecraft:red_nether_bricks
fill 330 53 484 330 56 484 minecraft:pink_terracotta
setblock 330 53 488 minecraft:red_nether_bricks
fill 330 53 489 330 56 489 minecraft:pink_terracotta
setblock 330 53 493 minecraft:red_nether_bricks
fill 330 53 494 330 56 494 minecraft:pink_terracotta
setblock 330 53 503 minecraft:red_nether_bricks
fill 330 53 504 330 54 504 minecraft:pink_terracotta
fill 331 53 464 331 53 466 minecraft:pink_terracotta
setblock 331 53 467 minecraft:red_nether_bricks
fill 331 53 468 331 56 468 minecraft:pink_terracotta
setblock 331 53 472 minecraft:red_nether_bricks
fill 331 53 473 331 56 473 minecraft:pink_terracotta
setblock 331 53 477 minecraft:red_nether_bricks
fill 331 53 478 331 56 478 minecraft:pink_terracotta
setblock 331 53 482 minecraft:red_nether_bricks
fill 331 53 483 331 56 483 minecraft:pink_terracotta
setblock 331 53 487 minecraft:red_nether_bricks
fill 331 53 488 331 56 488 minecraft:pink_terracotta
setblock 331 53 492 minecraft:red_nether_bricks
setblock 331 53 493 minecraft:pink_terracotta
fill 332 53 464 332 53 465 minecraft:pink_terracotta
setblock 332 53 466 minecraft:red_nether_bricks
fill 332 53 467 332 56 467 minecraft:pink_terracotta
setblock 332 53 481 minecraft:red_nether_bricks
fill 332 53 482 332 54 482 minecraft:pink_terracotta
setblock 332 53 486 minecraft:red_nether_bricks
fill 332 53 487 332 56 487 minecraft:pink_terracotta
setblock 333 53 465 minecraft:red_nether_bricks
fill 333 53 466 333 55 466 minecraft:pink_terracotta
setblock 334 53 464 minecraft:red_nether_bricks
fill 334 53 465 334 56 465 minecraft:pink_terracotta
setblock 334 53 504 minecraft:red_nether_bricks
fill 335 53 464 335 56 464 minecraft:pink_terracotta
setblock 335 53 504 minecraft:pink_terracotta
setblock 338 53 465 minecraft:red_nether_bricks
setblock 339 53 464 minecraft:red_nether_bricks
fill 339 53 465 339 54 465 minecraft:pink_terracotta
fill 340 53 464 340 56 464 minecraft:pink_terracotta
setblock 341 53 504 minecraft:white_concrete
setblock 343 53 465 minecraft:red_nether_bricks
setblock 344 53 464 minecraft:red_nether_bricks
fill 344 53 465 344 56 465 minecraft:pink_terracotta
setblock 344 53 504 minecraft:red_nether_bricks
fill 345 53 464 345 56 464 minecraft:pink_terracotta
fill 345 53 504 345 56 504 minecraft:pink_terracotta
setblock 347 53 466 minecraft:red_nether_bricks
setblock 348 53 465 minecraft:red_nether_bricks
fill 348 53 466 348 56 466 minecraft:pink_terracotta
setblock 349 53 464 minecraft:red_nether_bricks
fill 349 53 465 349 56 465 minecraft:pink_terracotta
setblock 349 53 504 minecraft:red_nether_bricks
fill 350 53 464 350 56 464 minecraft:pink_terracotta
setblock 350 53 503 minecraft:red_nether_bricks
fill 350 53 504 350 56 504 minecraft:pink_terracotta
setblock 351 53 466 minecraft:pink_terracotta
fill 351 53 467 351 82 467 minecraft:red_nether_bricks
fill 351 53 503 351 56 503 minecraft:pink_terracotta
setblock 352 53 466 minecraft:red_nether_bricks
setblock 353 53 465 minecraft:red_nether_bricks
fill 353 53 466 353 55 466 minecraft:pink_terracotta
setblock 354 53 464 minecraft:red_nether_bricks
fill 354 53 465 354 56 465 minecraft:pink_terracotta
setblock 354 53 504 minecraft:red_nether_bricks
fill 355 53 464 355 56 464 minecraft:pink_terracotta
setblock 355 53 503 minecraft:red_nether_bricks
fill 355 53 504 355 56 504 minecraft:pink_terracotta
fill 356 53 503 357 53 503 minecraft:pink_terracotta
setblock 359 53 464 minecraft:red_nether_bricks
setblock 359 53 504 minecraft:red_nether_bricks
fill 360 53 464 361 53 464 minecraft:pink_terracotta
fill 360 53 504 360 54 504 minecraft:pink_terracotta
setblock 364 53 504 minecraft:red_nether_bricks
setblock 365 53 464 minecraft:pink_terracotta
fill 365 53 504 365 54 504 minecraft:pink_terracotta
setblock 368 53 484 minecraft:pink_terracotta
setblock 368 53 485 minecraft:red_nether_bricks
fill 368 53 486 368 56 486 minecraft:pink_terracotta
setblock 368 53 489 minecraft:pink_terracotta
setblock 368 53 490 minecraft:red_nether_bricks
fill 368 53 491 368 56 491 minecraft:pink_terracotta
setblock 369 53 464 minecraft:red_nether_bricks
setblock 369 53 465 minecraft:pink_terracotta
setblock 369 53 484 minecraft:red_nether_bricks
fill 369 53 485 369 56 485 minecraft:pink_terracotta
setblock 369 53 489 minecraft:red_nether_bricks
fill 369 53 490 369 56 490 minecraft:pink_terracotta
setblock 369 53 494 minecraft:red_nether_bricks
fill 369 53 495 369 56 495 minecraft:pink_terracotta
setblock 369 53 504 minecraft:red_nether_bricks
fill 370 53 464 370 56 464 minecraft:pink_terracotta
setblock 370 53 468 minecraft:red_nether_bricks
fill 370 53 469 370 56 469 minecraft:pink_terracotta
setblock 370 53 472 minecraft:pink_terracotta
setblock 370 53 477 minecraft:pink_terracotta
setblock 370 53 478 minecraft:red_nether_bricks
fill 370 53 479 370 56 479 minecraft:pink_terracotta
setblock 370 53 483 minecraft:red_nether_bricks
fill 370 53 484 370 56 484 minecraft:pink_terracotta
setblock 370 53 488 minecraft:red_nether_bricks
fill 370 53 489 370 56 489 minecraft:pink_terracotta
setblock 370 53 493 minecraft:red_nether_bricks
fill 370 53 494 370 56 494 minecraft:pink_terracotta
setblock 370 53 498 minecraft:red_nether_bricks
fill 370 53 499 370 56 499 minecraft:pink_terracotta
setblock 370 53 503 minecraft:red_nether_bricks
fill 370 53 504 370 56 504 minecraft:pink_terracotta
fill 330 54 464 330 54 466 minecraft:pink_terracotta
setblock 330 54 467 minecraft:red_nether_bricks
fill 330 54 468 330 57 468 minecraft:pink_terracotta
setblock 330 54 472 minecraft:red_nether_bricks
fill 330 54 473 330 57 473 minecraft:pink_terracotta
setblock 330 54 477 minecraft:red_nether_bricks
fill 330 54 478 330 57 478 minecraft:pink_terracotta
setblock 330 54 482 minecraft:red_nether_bricks
fill 330 54 483 330 57 483 minecraft:pink_terracotta
setblock 330 54 487 minecraft:red_nether_bricks
fill 330 54 488 330 57 488 minecraft:pink_terracotta
schedule function dropper:buildpart/115_2 1t
