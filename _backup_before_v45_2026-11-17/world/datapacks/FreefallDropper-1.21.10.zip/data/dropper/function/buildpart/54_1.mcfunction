fill 297 78 263 297 80 263 minecraft:polished_blackstone
fill 297 78 264 297 80 266 minecraft:blackstone
fill 297 78 267 297 80 267 minecraft:polished_blackstone
setblock 297 78 270 minecraft:crying_obsidian
fill 298 78 247 300 80 247 minecraft:blackstone
fill 298 78 248 298 80 248 minecraft:polished_blackstone
fill 298 78 251 300 80 251 minecraft:blackstone
fill 298 78 252 298 79 252 minecraft:polished_blackstone
fill 298 78 260 298 79 260 minecraft:polished_blackstone
fill 298 78 261 298 80 261 minecraft:blackstone
fill 298 78 263 300 80 263 minecraft:blackstone
fill 298 78 264 298 80 264 minecraft:polished_blackstone
fill 298 78 265 298 78 269 minecraft:blackstone
fill 298 78 270 307 93 270 minecraft:basalt
fill 299 78 228 304 81 228 minecraft:basalt
fill 299 78 248 301 80 248 minecraft:blackstone
fill 299 78 249 299 80 249 minecraft:polished_blackstone
fill 299 78 250 299 80 250 minecraft:blackstone
fill 299 78 252 300 79 252 minecraft:blackstone
fill 299 78 253 299 79 253 minecraft:polished_blackstone
fill 299 78 259 300 79 259 minecraft:blackstone
fill 299 78 260 299 79 260 minecraft:magma_block
fill 299 78 261 299 80 261 minecraft:polished_blackstone
fill 299 78 264 301 80 264 minecraft:blackstone
fill 299 78 265 299 80 265 minecraft:polished_blackstone
fill 299 78 266 299 78 269 minecraft:blackstone
fill 300 78 246 300 80 246 minecraft:polished_blackstone
fill 300 78 249 301 80 249 minecraft:blackstone
fill 300 78 250 300 80 250 minecraft:polished_blackstone
fill 300 78 253 302 79 253 minecraft:blackstone
fill 300 78 254 300 79 254 minecraft:polished_blackstone
fill 300 78 258 300 79 258 minecraft:polished_blackstone
fill 300 78 260 301 80 260 minecraft:blackstone
fill 300 78 261 300 80 261 minecraft:magma_block
fill 300 78 262 300 80 262 minecraft:polished_blackstone
fill 300 78 265 302 80 265 minecraft:blackstone
fill 300 78 266 300 80 266 minecraft:polished_blackstone
fill 300 78 267 323 78 269 minecraft:blackstone
setblock 301 78 231 minecraft:light[level=12]
setblock 301 78 239 minecraft:light[level=12]
fill 301 78 246 303 78 246 minecraft:blackstone
fill 301 78 247 301 80 247 minecraft:polished_blackstone
fill 301 78 250 301 80 250 minecraft:blackstone
fill 301 78 251 301 80 251 minecraft:polished_blackstone
fill 301 78 252 301 80 252 minecraft:magma_block
fill 301 78 254 303 79 254 minecraft:blackstone
fill 301 78 255 301 79 255 minecraft:polished_blackstone
fill 301 78 256 301 79 256 minecraft:blackstone
fill 301 78 257 303 79 257 minecraft:magma_block
fill 301 78 258 303 79 258 minecraft:blackstone
fill 301 78 259 301 80 259 minecraft:polished_blackstone
fill 301 78 261 302 80 261 minecraft:blackstone
fill 301 78 262 301 80 262 minecraft:magma_block
fill 301 78 263 301 80 263 minecraft:polished_blackstone
fill 301 78 266 323 78 266 minecraft:blackstone
fill 302 78 231 308 78 231 minecraft:blackstone
fill 302 78 239 308 78 239 minecraft:blackstone
fill 302 78 247 303 80 247 minecraft:blackstone
fill 302 78 248 302 80 248 minecraft:polished_blackstone
fill 302 78 249 302 80 251 minecraft:magma_block
fill 302 78 252 302 80 252 minecraft:polished_blackstone
fill 302 78 255 304 80 255 minecraft:blackstone
fill 302 78 256 302 80 256 minecraft:polished_blackstone
fill 302 78 259 304 80 259 minecraft:blackstone
fill 302 78 260 302 80 260 minecraft:polished_blackstone
fill 302 78 262 302 80 263 minecraft:blackstone
fill 302 78 264 302 80 264 minecraft:polished_blackstone
fill 303 78 248 323 78 248 minecraft:blackstone
fill 303 78 249 303 80 249 minecraft:polished_blackstone
fill 303 78 250 303 80 252 minecraft:blackstone
fill 303 78 253 303 80 253 minecraft:polished_blackstone
fill 303 78 256 304 80 256 minecraft:blackstone
fill 303 78 260 305 80 260 minecraft:blackstone
fill 303 78 261 303 80 261 minecraft:polished_blackstone
fill 303 78 262 303 80 262 minecraft:blackstone
fill 303 78 263 304 80 263 minecraft:magma_block
fill 303 78 264 323 78 264 minecraft:blackstone
fill 303 78 265 303 80 265 minecraft:polished_blackstone
fill 304 78 249 323 78 249 minecraft:blackstone
fill 304 78 250 304 80 250 minecraft:polished_blackstone
fill 304 78 251 304 80 253 minecraft:blackstone
fill 304 78 254 304 80 254 minecraft:polished_blackstone
fill 304 78 257 306 80 257 minecraft:blackstone
fill 304 78 258 304 80 258 minecraft:polished_blackstone
fill 304 78 261 307 78 261 minecraft:blackstone
fill 304 78 262 304 80 262 minecraft:polished_blackstone
fill 304 78 265 323 78 265 minecraft:blackstone
setblock 305 78 228 minecraft:netherrack
fill 305 78 244 323 78 244 minecraft:blackstone
fill 305 78 250 323 78 250 minecraft:blackstone
fill 305 78 251 305 80 251 minecraft:polished_blackstone
fill 305 78 252 305 80 254 minecraft:blackstone
fill 305 78 255 305 80 255 minecraft:polished_blackstone
fill 305 78 256 306 80 256 minecraft:magma_block
fill 305 78 258 323 78 258 minecraft:blackstone
fill 305 78 259 305 80 259 minecraft:polished_blackstone
fill 305 78 262 307 78 262 minecraft:blackstone
fill 305 78 263 305 80 263 minecraft:polished_blackstone
fill 306 78 228 308 93 228 minecraft:basalt
fill 306 78 251 323 78 251 minecraft:blackstone
fill 306 78 252 306 80 252 minecraft:polished_blackstone
fill 306 78 253 306 80 255 minecraft:blackstone
fill 306 78 259 323 78 259 minecraft:blackstone
fill 306 78 260 306 80 260 minecraft:polished_blackstone
fill 306 78 263 308 78 263 minecraft:blackstone
fill 307 78 245 308 78 247 minecraft:blackstone
fill 307 78 252 323 78 252 minecraft:blackstone
fill 307 78 253 307 80 253 minecraft:polished_blackstone
fill 307 78 254 323 78 254 minecraft:blackstone
fill 307 78 255 307 80 255 minecraft:magma_block
fill 307 78 256 323 78 256 minecraft:blackstone
fill 307 78 257 307 80 257 minecraft:polished_blackstone
fill 307 78 260 307 80 260 minecraft:blackstone
fill 308 78 253 323 78 253 minecraft:blackstone
setblock 308 78 255 minecraft:blackstone
fill 308 78 257 323 78 257 minecraft:blackstone
fill 308 78 270 309 78 270 minecraft:netherrack
setblock 309 78 228 minecraft:netherrack
setblock 309 78 231 minecraft:light[level=12]
setblock 309 78 239 minecraft:light[level=12]
fill 309 78 245 323 78 246 minecraft:blackstone
setblock 309 78 247 minecraft:light[level=12]
setblock 309 78 255 minecraft:light[level=12]
setblock 309 78 263 minecraft:light[level=12]
fill 310 78 228 312 85 228 minecraft:basalt
fill 310 78 231 316 78 231 minecraft:blackstone
fill 310 78 239 316 78 239 minecraft:blackstone
fill 310 78 247 316 78 247 minecraft:blackstone
fill 310 78 255 316 78 255 minecraft:blackstone
fill 310 78 260 323 78 260 minecraft:blackstone
fill 310 78 263 316 78 263 minecraft:blackstone
fill 310 78 270 310 82 270 minecraft:basalt
fill 311 78 261 323 78 262 minecraft:blackstone
fill 311 78 270 311 79 270 minecraft:magma_block
fill 312 78 270 312 79 270 minecraft:basalt
fill 313 78 228 314 78 228 minecraft:netherrack
fill 315 78 228 315 179 228 minecraft:basalt
setblock 316 78 228 minecraft:shroomlight
setblock 317 78 228 minecraft:netherrack
setblock 317 78 231 minecraft:light[level=12]
setblock 317 78 239 minecraft:light[level=12]
setblock 317 78 247 minecraft:light[level=12]
setblock 317 78 255 minecraft:light[level=12]
setblock 317 78 263 minecraft:light[level=12]
fill 318 78 228 322 80 228 minecraft:basalt
fill 318 78 231 323 78 231 minecraft:blackstone
fill 318 78 239 323 78 239 minecraft:blackstone
fill 318 78 247 323 78 247 minecraft:blackstone
fill 318 78 255 323 78 255 minecraft:blackstone
fill 318 78 263 323 78 263 minecraft:blackstone
fill 322 78 270 322 176 270 minecraft:basalt
fill 324 78 234 324 175 236 minecraft:basalt
setblock 324 78 237 minecraft:netherrack
fill 324 78 240 324 176 240 minecraft:basalt
fill 324 78 241 324 79 241 minecraft:magma_block
fill 324 78 242 324 79 242 minecraft:basalt
fill 324 78 246 324 150 246 minecraft:basalt
setblock 324 78 247 minecraft:shroomlight
fill 324 78 248 324 143 253 minecraft:basalt
setblock 324 78 254 minecraft:netherrack
fill 324 78 255 324 142 258 minecraft:basalt
fill 324 78 263 324 179 263 minecraft:basalt
setblock 324 78 267 minecraft:magma_block
fill 282 79 236 282 177 236 minecraft:basalt
fill 282 79 240 282 133 240 minecraft:basalt
fill 282 79 251 282 175 251 minecraft:basalt
fill 282 79 268 282 121 268 minecraft:basalt
fill 283 79 270 283 179 270 minecraft:basalt
fill 287 79 228 288 82 228 minecraft:basalt
fill 287 79 252 287 80 252 minecraft:blackstone
fill 287 79 255 288 80 255 minecraft:blackstone
fill 287 79 260 288 80 260 minecraft:blackstone
fill 289 79 249 289 80 249 minecraft:blackstone
setblock 289 79 270 minecraft:magma_block
fill 290 79 228 290 123 228 minecraft:basalt
fill 290 79 270 290 140 270 minecraft:basalt
fill 291 79 247 292 80 247 minecraft:blackstone
fill 293 79 266 295 80 266 minecraft:blackstone
fill 297 79 228 298 179 228 minecraft:basalt
fill 297 79 245 297 80 245 minecraft:blackstone
fill 297 79 270 297 179 270 minecraft:basalt
fill 298 79 265 298 80 266 minecraft:blackstone
fill 299 79 266 299 80 266 minecraft:blackstone
fill 301 79 246 301 80 246 minecraft:blackstone
fill 301 79 266 301 80 266 minecraft:blackstone
fill 303 79 248 304 80 248 minecraft:blackstone
fill 303 79 264 304 80 264 minecraft:blackstone
fill 304 79 249 305 80 249 minecraft:blackstone
fill 304 79 261 306 80 261 minecraft:blackstone
fill 305 79 228 305 91 228 minecraft:basalt
fill 305 79 250 306 80 250 minecraft:blackstone
fill 305 79 258 307 80 258 minecraft:blackstone
fill 305 79 262 306 80 262 minecraft:blackstone
fill 306 79 251 306 80 251 minecraft:blackstone
fill 306 79 259 307 80 259 minecraft:blackstone
fill 307 79 252 307 80 252 minecraft:blackstone
fill 307 79 254 307 80 254 minecraft:blackstone
fill 307 79 256 308 80 256 minecraft:blackstone
fill 308 79 270 309 88 270 minecraft:basalt
fill 309 79 228 309 176 228 minecraft:basalt
fill 313 79 228 314 179 228 minecraft:basalt
fill 316 79 228 317 85 228 minecraft:basalt
fill 324 79 237 324 108 237 minecraft:basalt
fill 324 79 247 324 179 247 minecraft:basalt
fill 324 79 254 324 175 254 minecraft:basalt
fill 324 79 267 324 177 267 minecraft:basalt
setblock 282 80 249 minecraft:shroomlight
fill 282 80 250 282 179 250 minecraft:basalt
setblock 289 80 270 minecraft:shroomlight
fill 293 80 254 293 80 258 minecraft:shroomlight
fill 294 80 253 294 80 254 minecraft:shroomlight
fill 294 80 258 294 80 259 minecraft:shroomlight
fill 295 80 252 295 80 253 minecraft:shroomlight
fill 295 80 259 295 80 260 minecraft:shroomlight
fill 295 80 261 295 80 265 minecraft:magma_block
fill 296 80 252 299 80 252 minecraft:shroomlight
fill 296 80 260 299 80 260 minecraft:shroomlight
fill 296 80 261 297 80 261 minecraft:blackstone
fill 299 80 253 300 80 253 minecraft:shroomlight
fill 299 80 259 300 80 259 minecraft:shroomlight
setblock 300 80 252 minecraft:blackstone
fill 300 80 254 301 80 254 minecraft:shroomlight
fill 300 80 258 301 80 258 minecraft:shroomlight
fill 301 80 253 302 80 253 minecraft:blackstone
fill 301 80 255 301 80 257 minecraft:shroomlight
fill 302 80 254 303 80 254 minecraft:blackstone
fill 302 80 257 303 80 257 minecraft:magma_block
fill 302 80 258 303 80 258 minecraft:blackstone
fill 311 80 270 311 88 270 minecraft:basalt
setblock 312 80 270 minecraft:magma_block
fill 313 80 270 315 80 270 minecraft:basalt
setblock 316 80 270 minecraft:shroomlight
fill 317 80 270 321 85 270 minecraft:basalt
fill 324 80 241 324 92 241 minecraft:basalt
setblock 324 80 242 minecraft:shroomlight
fill 282 81 249 282 130 249 minecraft:basalt
setblock 285 81 231 minecraft:light[level=12]
setblock 285 81 238 minecraft:light[level=12]
setblock 285 81 245 minecraft:light[level=12]
setblock 285 81 252 minecraft:light[level=12]
setblock 285 81 259 minecraft:light[level=12]
setblock 285 81 266 minecraft:light[level=12]
setblock 289 81 270 minecraft:magma_block
setblock 292 81 231 minecraft:light[level=12]
setblock 292 81 238 minecraft:light[level=12]
setblock 292 81 245 minecraft:light[level=12]
setblock 292 81 252 minecraft:light[level=12]
setblock 292 81 259 minecraft:light[level=12]
setblock 292 81 266 minecraft:light[level=12]
setblock 299 81 231 minecraft:light[level=12]
setblock 299 81 238 minecraft:light[level=12]
setblock 299 81 245 minecraft:light[level=12]
setblock 299 81 252 minecraft:light[level=12]
setblock 299 81 259 minecraft:light[level=12]
setblock 299 81 266 minecraft:light[level=12]
setblock 306 81 231 minecraft:light[level=12]
setblock 306 81 238 minecraft:light[level=12]
setblock 306 81 245 minecraft:light[level=12]
setblock 306 81 252 minecraft:light[level=12]
setblock 306 81 259 minecraft:light[level=12]
setblock 306 81 266 minecraft:light[level=12]
setblock 312 81 270 minecraft:basalt
setblock 313 81 231 minecraft:light[level=12]
setblock 313 81 238 minecraft:light[level=12]
setblock 313 81 245 minecraft:light[level=12]
setblock 313 81 252 minecraft:light[level=12]
setblock 313 81 259 minecraft:light[level=12]
setblock 313 81 266 minecraft:light[level=12]
setblock 313 81 270 minecraft:shroomlight
fill 314 81 270 316 84 270 minecraft:basalt
setblock 318 81 228 minecraft:magma_block
fill 319 81 228 322 91 228 minecraft:basalt
setblock 320 81 231 minecraft:light[level=12]
setblock 320 81 238 minecraft:light[level=12]
setblock 320 81 245 minecraft:light[level=12]
setblock 320 81 252 minecraft:light[level=12]
setblock 320 81 259 minecraft:light[level=12]
setblock 320 81 266 minecraft:light[level=12]
setblock 324 81 242 minecraft:magma_block
fill 282 82 257 282 94 259 minecraft:basalt
setblock 282 82 260 minecraft:crying_obsidian
fill 288 82 270 288 83 270 minecraft:magma_block
fill 289 82 270 289 175 270 minecraft:basalt
setblock 299 82 228 minecraft:crying_obsidian
fill 300 82 228 304 111 228 minecraft:basalt
setblock 312 82 270 minecraft:magma_block
setblock 313 82 270 minecraft:basalt
fill 318 82 228 318 175 228 minecraft:basalt
setblock 324 82 242 minecraft:basalt
setblock 324 82 243 minecraft:magma_block
fill 324 82 244 324 86 245 minecraft:basalt
setblock 282 83 241 minecraft:magma_block
fill 282 83 242 282 87 244 minecraft:basalt
fill 282 83 260 282 179 260 minecraft:basalt
fill 287 83 228 287 179 228 minecraft:basalt
setblock 288 83 228 minecraft:shroomlight
fill 299 83 228 299 104 228 minecraft:basalt
setblock 310 83 270 minecraft:magma_block
fill 312 83 270 312 87 270 minecraft:basalt
fill 313 83 270 313 84 270 minecraft:magma_block
setblock 324 83 242 minecraft:magma_block
fill 324 83 243 324 179 243 minecraft:basalt
fill 282 84 241 282 156 241 minecraft:basalt
fill 285 84 261 285 85 261 minecraft:blackstone
fill 288 84 228 288 176 228 minecraft:basalt
setblock 288 84 270 minecraft:shroomlight
fill 310 84 270 310 94 270 minecraft:basalt
fill 318 84 256 318 90 256 minecraft:blackstone
setblock 324 84 242 minecraft:shroomlight
fill 283 85 229 284 85 269 minecraft:blackstone
fill 285 85 229 286 85 260 minecraft:blackstone
fill 285 85 262 286 85 269 minecraft:blackstone
setblock 286 85 261 minecraft:blackstone
fill 287 85 229 323 85 232 minecraft:blackstone
fill 287 85 266 323 85 269 minecraft:blackstone
fill 288 85 270 288 146 270 minecraft:basalt
setblock 292 85 270 minecraft:crying_obsidian
setblock 293 85 239 minecraft:light[level=12]
setblock 293 85 247 minecraft:light[level=12]
setblock 293 85 255 minecraft:light[level=12]
setblock 293 85 263 minecraft:light[level=12]
fill 293 85 270 294 94 270 minecraft:basalt
setblock 301 85 239 minecraft:light[level=12]
setblock 301 85 247 minecraft:light[level=12]
setblock 301 85 255 minecraft:light[level=12]
setblock 301 85 263 minecraft:light[level=12]
setblock 309 85 239 minecraft:light[level=12]
setblock 309 85 247 minecraft:light[level=12]
setblock 309 85 255 minecraft:light[level=12]
setblock 309 85 263 minecraft:light[level=12]
fill 313 85 270 313 86 270 minecraft:basalt
setblock 314 85 270 minecraft:shroomlight
fill 315 85 270 316 115 270 minecraft:basalt
setblock 317 85 239 minecraft:light[level=12]
setblock 317 85 247 minecraft:light[level=12]
setblock 317 85 255 minecraft:light[level=12]
setblock 317 85 263 minecraft:light[level=12]
fill 320 85 233 323 85 265 minecraft:blackstone
fill 324 85 242 324 176 242 minecraft:basalt
fill 283 86 229 285 86 269 minecraft:magma_block
fill 286 86 229 323 86 231 minecraft:magma_block
fill 286 86 267 323 86 269 minecraft:magma_block
fill 292 86 270 292 180 270 minecraft:basalt
fill 310 86 228 310 179 228 minecraft:basalt
setblock 311 86 228 minecraft:magma_block
fill 312 86 228 312 179 228 minecraft:basalt
setblock 314 86 270 minecraft:magma_block
fill 316 86 228 316 179 228 minecraft:basalt
setblock 317 86 228 minecraft:crying_obsidian
fill 317 86 270 318 89 270 minecraft:basalt
setblock 319 86 270 minecraft:magma_block
fill 320 86 270 321 94 270 minecraft:basalt
fill 321 86 232 323 86 266 minecraft:magma_block
fill 324 86 259 324 179 259 minecraft:basalt
setblock 324 86 260 minecraft:magma_block
fill 324 86 261 324 100 262 minecraft:basalt
fill 282 87 237 282 179 237 minecraft:basalt
setblock 282 87 238 minecraft:magma_block
fill 282 87 239 282 158 239 minecraft:basalt
fill 283 87 229 284 87 269 minecraft:shroomlight
fill 285 87 229 323 87 230 minecraft:shroomlight
setblock 285 87 231 minecraft:light[level=12]
setblock 285 87 238 minecraft:light[level=12]
setblock 285 87 245 minecraft:light[level=12]
setblock 285 87 252 minecraft:light[level=12]
setblock 285 87 259 minecraft:light[level=12]
fill 285 87 260 285 91 262 minecraft:blackstone
setblock 285 87 266 minecraft:light[level=12]
fill 285 87 268 323 87 269 minecraft:shroomlight
fill 286 87 261 286 91 261 minecraft:blackstone
setblock 292 87 231 minecraft:light[level=12]
setblock 292 87 238 minecraft:light[level=12]
setblock 292 87 245 minecraft:light[level=12]
setblock 292 87 252 minecraft:light[level=12]
setblock 292 87 259 minecraft:light[level=12]
setblock 292 87 266 minecraft:light[level=12]
setblock 299 87 231 minecraft:light[level=12]
setblock 299 87 238 minecraft:light[level=12]
setblock 299 87 245 minecraft:light[level=12]
setblock 299 87 252 minecraft:light[level=12]
setblock 299 87 259 minecraft:light[level=12]
setblock 299 87 266 minecraft:light[level=12]
setblock 306 87 231 minecraft:light[level=12]
setblock 306 87 238 minecraft:light[level=12]
setblock 306 87 245 minecraft:light[level=12]
setblock 306 87 252 minecraft:light[level=12]
setblock 306 87 259 minecraft:light[level=12]
setblock 306 87 266 minecraft:light[level=12]
fill 311 87 228 311 175 228 minecraft:basalt
setblock 313 87 231 minecraft:light[level=12]
setblock 313 87 238 minecraft:light[level=12]
setblock 313 87 245 minecraft:light[level=12]
setblock 313 87 252 minecraft:light[level=12]
setblock 313 87 259 minecraft:light[level=12]
setblock 313 87 266 minecraft:light[level=12]
setblock 313 87 270 minecraft:magma_block
fill 314 87 270 314 105 270 minecraft:basalt
fill 317 87 228 317 134 228 minecraft:basalt
fill 319 87 270 319 177 270 minecraft:basalt
setblock 320 87 231 minecraft:light[level=12]
setblock 320 87 238 minecraft:light[level=12]
setblock 320 87 245 minecraft:light[level=12]
setblock 320 87 252 minecraft:light[level=12]
setblock 320 87 259 minecraft:light[level=12]
setblock 320 87 266 minecraft:light[level=12]
fill 322 87 231 323 87 267 minecraft:shroomlight
fill 324 87 244 324 177 244 minecraft:basalt
setblock 324 87 245 minecraft:magma_block
fill 324 87 260 324 173 260 minecraft:basalt
fill 282 88 238 282 176 238 minecraft:basalt
fill 282 88 242 282 127 242 minecraft:basalt
setblock 282 88 243 minecraft:magma_block
fill 282 88 244 282 139 244 minecraft:basalt
fill 284 88 261 284 91 261 minecraft:blackstone
fill 293 88 238 293 89 239 minecraft:blackstone
setblock 312 88 270 minecraft:magma_block
fill 313 88 270 313 124 270 minecraft:basalt
fill 317 88 256 317 90 256 minecraft:blackstone
fill 318 88 255 318 90 255 minecraft:blackstone
fill 318 88 257 318 90 257 minecraft:blackstone
fill 319 88 256 319 90 256 minecraft:blackstone
fill 324 88 245 324 177 245 minecraft:basalt
fill 282 89 243 282 103 243 minecraft:basalt
fill 284 89 260 284 91 260 minecraft:blackstone
fill 284 89 262 284 91 262 minecraft:blackstone
fill 286 89 260 286 91 260 minecraft:blackstone
fill 286 89 262 286 91 262 minecraft:blackstone
setblock 291 89 270 minecraft:magma_block
fill 297 89 241 297 90 243 minecraft:blackstone
fill 298 89 241 298 90 242 minecraft:blackstone
fill 308 89 270 308 90 270 minecraft:basalt
setblock 309 89 270 minecraft:magma_block
setblock 311 89 270 minecraft:shroomlight
fill 312 89 270 312 91 270 minecraft:basalt
fill 291 90 270 291 168 270 minecraft:basalt
fill 309 90 270 309 96 270 minecraft:basalt
fill 311 90 270 311 91 270 minecraft:magma_block
fill 317 90 270 317 179 270 minecraft:basalt
setblock 318 90 270 minecraft:magma_block
fill 324 90 264 324 154 265 minecraft:basalt
setblock 324 90 266 minecraft:shroomlight
setblock 308 91 270 minecraft:magma_block
fill 318 91 270 318 179 270 minecraft:basalt
fill 324 91 266 324 118 266 minecraft:basalt
fill 282 92 252 282 120 253 minecraft:basalt
setblock 282 92 254 minecraft:crying_obsidian
fill 282 92 255 282 93 256 minecraft:basalt
setblock 282 92 269 minecraft:magma_block
fill 282 92 270 282 177 270 minecraft:basalt
fill 285 92 231 285 93 231 minecraft:light[level=12]
setblock 285 92 239 minecraft:light[level=12]
setblock 285 92 247 minecraft:light[level=12]
setblock 285 92 255 minecraft:light[level=12]
setblock 285 92 263 minecraft:light[level=12]
setblock 293 92 231 minecraft:light[level=12]
setblock 293 92 239 minecraft:light[level=12]
setblock 293 92 247 minecraft:light[level=12]
setblock 293 92 255 minecraft:light[level=12]
setblock 293 92 263 minecraft:light[level=12]
setblock 301 92 231 minecraft:light[level=12]
setblock 301 92 239 minecraft:light[level=12]
setblock 301 92 247 minecraft:light[level=12]
setblock 301 92 255 minecraft:light[level=12]
setblock 301 92 263 minecraft:light[level=12]
setblock 305 92 228 minecraft:magma_block
fill 308 92 270 308 179 270 minecraft:basalt
setblock 309 92 231 minecraft:light[level=12]
setblock 309 92 239 minecraft:light[level=12]
setblock 309 92 247 minecraft:light[level=12]
setblock 309 92 255 minecraft:light[level=12]
setblock 309 92 263 minecraft:light[level=12]
fill 311 92 270 311 93 270 minecraft:basalt
setblock 312 92 270 minecraft:magma_block
setblock 317 92 231 minecraft:light[level=12]
setblock 317 92 239 minecraft:light[level=12]
setblock 317 92 247 minecraft:light[level=12]
setblock 317 92 255 minecraft:light[level=12]
setblock 317 92 263 minecraft:light[level=12]
setblock 319 92 228 minecraft:shroomlight
fill 320 92 228 322 98 228 minecraft:basalt
fill 282 93 254 282 122 254 minecraft:basalt
fill 282 93 269 282 179 269 minecraft:basalt
setblock 285 93 238 minecraft:light[level=12]
setblock 285 93 245 minecraft:light[level=12]
setblock 285 93 252 minecraft:light[level=12]
setblock 285 93 259 minecraft:light[level=12]
setblock 285 93 266 minecraft:light[level=12]
setblock 292 93 231 minecraft:light[level=12]
setblock 292 93 238 minecraft:light[level=12]
setblock 292 93 245 minecraft:light[level=12]
setblock 292 93 252 minecraft:light[level=12]
setblock 292 93 259 minecraft:light[level=12]
setblock 292 93 266 minecraft:light[level=12]
setblock 299 93 231 minecraft:light[level=12]
setblock 299 93 238 minecraft:light[level=12]
setblock 299 93 245 minecraft:light[level=12]
setblock 299 93 252 minecraft:light[level=12]
setblock 299 93 259 minecraft:light[level=12]
setblock 299 93 266 minecraft:light[level=12]
fill 304 93 238 305 94 238 minecraft:basalt
fill 305 93 228 305 179 228 minecraft:basalt
setblock 306 93 231 minecraft:light[level=12]
setblock 306 93 238 minecraft:light[level=12]
setblock 306 93 245 minecraft:light[level=12]
setblock 306 93 252 minecraft:light[level=12]
setblock 306 93 259 minecraft:light[level=12]
setblock 306 93 266 minecraft:light[level=12]
setblock 312 93 270 minecraft:shroomlight
setblock 313 93 231 minecraft:light[level=12]
setblock 313 93 238 minecraft:light[level=12]
setblock 313 93 245 minecraft:light[level=12]
setblock 313 93 252 minecraft:light[level=12]
setblock 313 93 259 minecraft:light[level=12]
setblock 313 93 266 minecraft:light[level=12]
fill 319 93 228 319 164 228 minecraft:basalt
setblock 320 93 231 minecraft:light[level=12]
setblock 320 93 238 minecraft:light[level=12]
setblock 320 93 245 minecraft:light[level=12]
setblock 320 93 252 minecraft:light[level=12]
setblock 320 93 259 minecraft:light[level=12]
setblock 320 93 266 minecraft:light[level=12]
setblock 324 93 241 minecraft:crying_obsidian
fill 282 94 255 282 102 255 minecraft:basalt
setblock 282 94 256 minecraft:magma_block
fill 298 94 270 298 114 270 minecraft:basalt
setblock 299 94 270 minecraft:crying_obsidian
fill 300 94 270 307 96 270 minecraft:basalt
fill 302 94 235 302 96 235 minecraft:basalt
setblock 302 94 236 minecraft:magma_block
fill 303 94 234 303 96 234 minecraft:basalt
setblock 303 94 235 minecraft:magma_block
fill 303 94 236 303 95 238 minecraft:basalt
setblock 304 94 234 minecraft:magma_block
fill 304 94 235 305 94 237 minecraft:basalt
fill 304 94 239 304 95 239 minecraft:basalt
setblock 305 94 239 minecraft:magma_block
fill 306 94 228 306 179 228 minecraft:basalt
setblock 306 94 238 minecraft:magma_block
setblock 307 94 228 minecraft:shroomlight
fill 308 94 228 308 177 228 minecraft:basalt
setblock 311 94 270 minecraft:magma_block
fill 312 94 270 312 100 270 minecraft:basalt
fill 324 94 241 324 179 241 minecraft:basalt
fill 282 95 256 282 179 257 minecraft:basalt
setblock 282 95 258 minecraft:shroomlight
fill 282 95 259 282 179 259 minecraft:basalt
fill 293 95 270 293 179 270 minecraft:basalt
setblock 294 95 270 minecraft:magma_block
fill 299 95 270 299 177 270 minecraft:basalt
fill 302 95 236 302 96 237 minecraft:basalt
fill 303 95 235 306 95 235 minecraft:basalt
fill 304 95 234 305 96 234 minecraft:basalt
fill 304 95 236 304 95 237 minecraft:basalt
setblock 304 95 238 minecraft:magma_block
fill 305 95 236 305 99 236 minecraft:basalt
setblock 305 95 237 minecraft:magma_block
fill 305 95 238 306 95 239 minecraft:basalt
setblock 306 95 236 minecraft:magma_block
fill 306 95 237 307 96 237 minecraft:basalt
fill 307 95 228 307 112 228 minecraft:basalt
fill 307 95 238 307 98 238 minecraft:basalt
fill 310 95 270 310 96 270 minecraft:magma_block
fill 311 95 270 311 98 270 minecraft:basalt
setblock 320 95 270 minecraft:magma_block
fill 321 95 270 321 117 270 minecraft:basalt
fill 282 96 258 282 177 258 minecraft:basalt
fill 294 96 270 294 179 270 minecraft:basalt
setblock 302 96 238 minecraft:magma_block
fill 303 96 235 303 96 236 minecraft:basalt
setblock 303 96 237 minecraft:magma_block
fill 303 96 238 306 96 238 minecraft:basalt
fill 304 96 235 304 99 235 minecraft:basalt
setblock 304 96 236 minecraft:magma_block
fill 304 96 237 305 97 237 minecraft:basalt
setblock 305 96 235 minecraft:magma_block
setblock 305 96 239 minecraft:basalt
setblock 306 96 234 minecraft:magma_block
fill 306 96 235 307 97 236 minecraft:basalt
fill 308 96 236 308 96 237 minecraft:basalt
fill 320 96 270 320 175 270 minecraft:basalt
fill 300 97 270 306 111 270 minecraft:basalt
fill 302 97 237 303 97 237 minecraft:basalt
setblock 303 97 235 minecraft:magma_block
fill 303 97 236 304 98 236 minecraft:basalt
fill 303 97 238 305 97 238 minecraft:basalt
setblock 304 97 234 minecraft:magma_block
fill 305 97 234 305 98 235 minecraft:basalt
fill 306 97 234 307 98 234 minecraft:basalt
fill 306 97 237 306 98 237 minecraft:basalt
setblock 306 97 238 minecraft:magma_block
setblock 307 97 237 minecraft:magma_block
setblock 307 97 270 minecraft:magma_block
fill 308 97 235 308 98 235 minecraft:basalt
setblock 308 97 236 minecraft:magma_block
fill 308 97 237 308 98 237 minecraft:basalt
setblock 309 97 270 minecraft:shroomlight
setblock 310 97 270 minecraft:basalt
fill 298 98 240 298 99 241 minecraft:blackstone
fill 299 98 241 299 99 241 minecraft:blackstone
fill 303 98 237 304 98 237 minecraft:basalt
setblock 304 98 238 minecraft:magma_block
setblock 305 98 237 minecraft:magma_block
fill 305 98 238 306 98 238 minecraft:basalt
fill 306 98 235 306 99 235 minecraft:basalt
setblock 306 98 236 minecraft:magma_block
setblock 307 98 235 minecraft:magma_block
fill 307 98 236 307 98 237 minecraft:basalt
fill 307 98 270 307 123 270 minecraft:basalt
setblock 308 98 236 minecraft:basalt
fill 309 98 270 309 178 270 minecraft:basalt
setblock 310 98 270 minecraft:magma_block
fill 312 98 257 312 98 259 minecraft:basalt
setblock 312 98 260 minecraft:magma_block
fill 313 98 257 313 98 258 minecraft:basalt
setblock 313 98 259 minecraft:magma_block
fill 283 99 228 285 101 228 minecraft:basalt
setblock 285 99 231 minecraft:light[level=12]
fill 285 99 238 285 99 239 minecraft:light[level=12]
setblock 285 99 245 minecraft:light[level=12]
setblock 285 99 247 minecraft:light[level=12]
setblock 285 99 252 minecraft:light[level=12]
setblock 285 99 255 minecraft:light[level=12]
setblock 285 99 259 minecraft:light[level=12]
setblock 285 99 263 minecraft:light[level=12]
setblock 285 99 266 minecraft:light[level=12]
setblock 286 99 228 minecraft:shroomlight
fill 292 99 231 293 99 231 minecraft:light[level=12]
setblock 292 99 238 minecraft:light[level=12]
setblock 292 99 245 minecraft:light[level=12]
setblock 292 99 252 minecraft:light[level=12]
setblock 292 99 259 minecraft:light[level=12]
setblock 292 99 266 minecraft:light[level=12]
setblock 293 99 239 minecraft:light[level=12]
setblock 293 99 247 minecraft:light[level=12]
setblock 293 99 255 minecraft:light[level=12]
setblock 293 99 263 minecraft:light[level=12]
setblock 299 99 231 minecraft:light[level=12]
setblock 299 99 238 minecraft:light[level=12]
setblock 299 99 245 minecraft:light[level=12]
setblock 299 99 252 minecraft:light[level=12]
setblock 299 99 259 minecraft:light[level=12]
setblock 299 99 266 minecraft:light[level=12]
setblock 301 99 231 minecraft:light[level=12]
setblock 301 99 239 minecraft:light[level=12]
setblock 301 99 247 minecraft:light[level=12]
setblock 301 99 255 minecraft:light[level=12]
fill 301 99 256 302 175 258 minecraft:basalt
setblock 301 99 263 minecraft:light[level=12]
setblock 303 99 236 minecraft:basalt
fill 303 99 256 303 175 257 minecraft:basalt
setblock 304 99 236 minecraft:magma_block
fill 304 99 237 305 99 238 minecraft:basalt
setblock 305 99 235 minecraft:magma_block
setblock 306 99 231 minecraft:light[level=12]
setblock 306 99 238 minecraft:light[level=12]
setblock 306 99 245 minecraft:light[level=12]
setblock 306 99 252 minecraft:light[level=12]
setblock 306 99 259 minecraft:light[level=12]
setblock 306 99 266 minecraft:light[level=12]
setblock 309 99 231 minecraft:light[level=12]
setblock 309 99 239 minecraft:light[level=12]
setblock 309 99 247 minecraft:light[level=12]
setblock 309 99 255 minecraft:light[level=12]
setblock 309 99 263 minecraft:light[level=12]
fill 310 99 270 310 179 270 minecraft:basalt
fill 311 99 257 311 99 258 minecraft:basalt
setblock 311 99 259 minecraft:magma_block
fill 311 99 270 311 100 270 minecraft:magma_block
fill 312 99 257 312 102 257 minecraft:basalt
setblock 312 99 258 minecraft:magma_block
fill 312 99 259 315 99 260 minecraft:basalt
setblock 313 99 231 minecraft:light[level=12]
setblock 313 99 238 minecraft:light[level=12]
setblock 313 99 245 minecraft:light[level=12]
setblock 313 99 252 minecraft:light[level=12]
setblock 313 99 257 minecraft:magma_block
fill 313 99 258 314 100 258 minecraft:basalt
fill 313 99 261 314 99 261 minecraft:basalt
setblock 313 99 266 minecraft:light[level=12]
fill 314 99 257 314 103 257 minecraft:basalt
setblock 317 99 231 minecraft:light[level=12]
setblock 317 99 239 minecraft:light[level=12]
setblock 317 99 247 minecraft:light[level=12]
setblock 317 99 255 minecraft:light[level=12]
setblock 317 99 263 minecraft:light[level=12]
fill 320 99 228 320 114 228 minecraft:basalt
setblock 320 99 231 minecraft:light[level=12]
setblock 320 99 238 minecraft:light[level=12]
setblock 320 99 245 minecraft:light[level=12]
setblock 320 99 252 minecraft:light[level=12]
setblock 320 99 259 minecraft:light[level=12]
setblock 320 99 266 minecraft:light[level=12]
setblock 321 99 228 minecraft:magma_block
fill 322 99 228 322 179 228 minecraft:basalt
fill 286 100 228 286 179 228 minecraft:basalt
fill 297 100 241 298 101 241 minecraft:magma_block
fill 301 100 255 302 101 255 minecraft:blackstone
fill 303 100 258 303 101 258 minecraft:blackstone
setblock 304 100 236 minecraft:basalt
fill 304 100 237 304 101 237 minecraft:blackstone
setblock 305 100 237 minecraft:basalt
setblock 311 100 257 minecraft:magma_block
fill 311 100 258 312 101 259 minecraft:basalt
fill 312 100 260 313 100 260 minecraft:basalt
fill 313 100 257 313 101 257 minecraft:basalt
fill 313 100 259 314 100 259 minecraft:basalt
setblock 313 100 261 minecraft:magma_block
setblock 314 100 260 minecraft:magma_block
fill 314 100 261 314 101 261 minecraft:basalt
fill 315 100 257 315 100 258 minecraft:basalt
setblock 315 100 259 minecraft:magma_block
fill 315 100 260 315 101 260 minecraft:basalt
fill 321 100 228 321 179 228 minecraft:basalt
setblock 300 101 258 minecraft:blackstone
fill 301 101 259 303 101 259 minecraft:blackstone
setblock 303 101 255 minecraft:blackstone
fill 304 101 256 304 101 258 minecraft:blackstone
setblock 311 101 257 minecraft:basalt
fill 311 101 270 311 157 270 minecraft:basalt
setblock 312 101 260 minecraft:magma_block
setblock 312 101 270 minecraft:shroomlight
fill 313 101 258 313 103 258 minecraft:basalt
setblock 313 101 259 minecraft:magma_block
fill 313 101 260 313 101 261 minecraft:basalt
setblock 314 101 256 minecraft:basalt
setblock 314 101 258 minecraft:magma_block
fill 314 101 259 314 102 260 minecraft:basalt
setblock 315 101 257 minecraft:magma_block
fill 315 101 258 315 102 259 minecraft:basalt
setblock 324 101 261 minecraft:crying_obsidian
fill 324 101 262 324 143 262 minecraft:basalt
setblock 282 102 246 minecraft:magma_block
fill 282 102 247 282 145 247 minecraft:basalt
setblock 283 102 228 minecraft:crying_obsidian
fill 284 102 228 285 159 228 minecraft:basalt
setblock 312 102 258 minecraft:magma_block
fill 312 102 259 313 102 259 minecraft:basalt
fill 312 102 270 312 178 270 minecraft:basalt
setblock 313 102 257 minecraft:magma_block
setblock 313 102 260 minecraft:basalt
fill 314 102 258 314 103 258 minecraft:basalt
setblock 315 102 257 minecraft:basalt
fill 324 102 261 324 175 261 minecraft:basalt
fill 282 103 246 282 144 246 minecraft:basalt
setblock 282 103 255 minecraft:magma_block
fill 283 103 228 283 167 228 minecraft:basalt
setblock 313 103 257 minecraft:basalt
fill 282 104 243 282 105 243 minecraft:shroomlight
fill 282 104 255 282 179 255 minecraft:basalt
fill 283 104 229 286 104 269 minecraft:blackstone
fill 287 104 229 323 104 232 minecraft:blackstone
fill 287 104 266 323 104 269 minecraft:blackstone
fill 320 104 233 323 104 265 minecraft:blackstone
fill 282 105 228 282 175 228 minecraft:basalt
fill 282 105 229 323 105 229 minecraft:magma_block
fill 282 105 230 282 179 230 minecraft:basalt
fill 283 105 230 285 105 269 minecraft:magma_block
fill 286 105 230 323 105 231 minecraft:magma_block
fill 286 105 267 323 105 269 minecraft:magma_block
setblock 292 105 238 minecraft:light[level=12]
setblock 292 105 245 minecraft:light[level=12]
setblock 292 105 252 minecraft:light[level=12]
setblock 292 105 259 minecraft:light[level=12]
setblock 292 105 266 minecraft:light[level=12]
setblock 299 105 228 minecraft:crying_obsidian
setblock 299 105 238 minecraft:light[level=12]
setblock 299 105 245 minecraft:light[level=12]
setblock 299 105 252 minecraft:light[level=12]
setblock 299 105 259 minecraft:light[level=12]
setblock 299 105 266 minecraft:light[level=12]
setblock 306 105 238 minecraft:light[level=12]
setblock 306 105 245 minecraft:light[level=12]
setblock 306 105 252 minecraft:light[level=12]
setblock 306 105 259 minecraft:light[level=12]
setblock 306 105 266 minecraft:light[level=12]
setblock 313 105 238 minecraft:light[level=12]
setblock 313 105 245 minecraft:light[level=12]
setblock 313 105 252 minecraft:light[level=12]
setblock 313 105 259 minecraft:light[level=12]
setblock 313 105 266 minecraft:light[level=12]
setblock 320 105 238 minecraft:light[level=12]
setblock 320 105 245 minecraft:light[level=12]
setblock 320 105 252 minecraft:light[level=12]
setblock 320 105 259 minecraft:light[level=12]
setblock 320 105 266 minecraft:light[level=12]
fill 321 105 232 323 105 266 minecraft:magma_block
fill 282 106 229 282 179 229 minecraft:basalt
fill 282 106 243 282 137 243 minecraft:basalt
fill 283 106 229 284 106 269 minecraft:shroomlight
fill 285 106 229 323 106 230 minecraft:shroomlight
setblock 285 106 231 minecraft:light[level=12]
setblock 285 106 239 minecraft:light[level=12]
setblock 285 106 247 minecraft:light[level=12]
setblock 285 106 255 minecraft:light[level=12]
setblock 285 106 263 minecraft:light[level=12]
fill 285 106 268 323 106 269 minecraft:shroomlight
setblock 293 106 231 minecraft:light[level=12]
setblock 293 106 239 minecraft:light[level=12]
setblock 293 106 247 minecraft:light[level=12]
setblock 293 106 255 minecraft:light[level=12]
setblock 293 106 263 minecraft:light[level=12]
fill 299 106 228 299 159 228 minecraft:basalt
setblock 301 106 231 minecraft:light[level=12]
setblock 301 106 239 minecraft:light[level=12]
setblock 301 106 247 minecraft:light[level=12]
setblock 301 106 255 minecraft:light[level=12]
setblock 301 106 263 minecraft:light[level=12]
setblock 309 106 231 minecraft:light[level=12]
setblock 309 106 239 minecraft:light[level=12]
setblock 309 106 247 minecraft:light[level=12]
setblock 309 106 255 minecraft:light[level=12]
setblock 309 106 263 minecraft:light[level=12]
setblock 314 106 270 minecraft:shroomlight
setblock 317 106 231 minecraft:light[level=12]
setblock 317 106 239 minecraft:light[level=12]
setblock 317 106 247 minecraft:light[level=12]
setblock 317 106 255 minecraft:light[level=12]
setblock 317 106 263 minecraft:light[level=12]
fill 322 106 231 323 106 267 minecraft:shroomlight
fill 314 107 270 314 179 270 minecraft:basalt
fill 284 108 248 286 122 250 minecraft:basalt
fill 282 109 262 282 123 264 minecraft:basalt
setblock 282 109 265 minecraft:crying_obsidian
fill 282 109 266 282 176 266 minecraft:basalt
fill 283 109 248 283 110 249 minecraft:blackstone
fill 284 109 247 286 110 247 minecraft:blackstone
fill 284 109 251 286 110 251 minecraft:blackstone
fill 287 109 248 287 110 250 minecraft:blackstone
fill 288 109 242 288 110 243 minecraft:basalt
fill 291 109 228 293 179 228 minecraft:basalt
setblock 294 109 228 minecraft:crying_obsidian
fill 295 109 228 296 176 228 minecraft:basalt
fill 307 109 238 309 161 240 minecraft:basalt
fill 308 109 237 309 175 237 minecraft:basalt
fill 310 109 238 310 163 239 minecraft:basalt
setblock 324 109 237 minecraft:magma_block
fill 282 110 265 282 179 265 minecraft:basalt
setblock 283 110 247 minecraft:blackstone
fill 283 110 250 283 110 251 minecraft:blackstone
fill 285 110 246 286 110 246 minecraft:blackstone
setblock 285 110 252 minecraft:blackstone
setblock 287 110 247 minecraft:blackstone
setblock 287 110 251 minecraft:blackstone
fill 288 110 248 288 110 250 minecraft:blackstone
fill 294 110 228 294 175 228 minecraft:basalt
fill 306 110 238 306 111 240 minecraft:blackstone
fill 307 110 237 307 111 237 minecraft:blackstone
fill 307 110 241 310 111 241 minecraft:blackstone
fill 310 110 237 310 111 237 minecraft:blackstone
fill 310 110 240 310 111 240 minecraft:blackstone
fill 311 110 239 311 111 239 minecraft:blackstone
fill 324 110 237 324 179 237 minecraft:basalt
setblock 285 111 231 minecraft:light[level=12]
setblock 285 111 238 minecraft:light[level=12]
setblock 285 111 245 minecraft:light[level=12]
setblock 285 111 252 minecraft:light[level=12]
setblock 285 111 259 minecraft:light[level=12]
setblock 285 111 266 minecraft:light[level=12]
setblock 292 111 231 minecraft:light[level=12]
setblock 292 111 238 minecraft:light[level=12]
setblock 292 111 245 minecraft:light[level=12]
setblock 292 111 252 minecraft:light[level=12]
setblock 292 111 259 minecraft:light[level=12]
setblock 292 111 266 minecraft:light[level=12]
setblock 299 111 231 minecraft:light[level=12]
setblock 299 111 238 minecraft:light[level=12]
setblock 299 111 245 minecraft:light[level=12]
setblock 299 111 252 minecraft:light[level=12]
setblock 299 111 259 minecraft:light[level=12]
setblock 299 111 266 minecraft:light[level=12]
fill 305 111 238 305 111 240 minecraft:blackstone
setblock 306 111 231 minecraft:light[level=12]
fill 306 111 236 306 111 237 minecraft:blackstone
setblock 306 111 241 minecraft:blackstone
setblock 306 111 245 minecraft:light[level=12]
setblock 306 111 252 minecraft:light[level=12]
setblock 306 111 259 minecraft:light[level=12]
setblock 306 111 266 minecraft:light[level=12]
fill 307 111 236 310 111 236 minecraft:blackstone
fill 307 111 242 310 111 242 minecraft:blackstone
fill 311 111 237 311 111 238 minecraft:blackstone
fill 311 111 240 311 111 241 minecraft:blackstone
setblock 313 111 231 minecraft:light[level=12]
setblock 313 111 238 minecraft:light[level=12]
setblock 313 111 245 minecraft:light[level=12]
setblock 313 111 252 minecraft:light[level=12]
setblock 313 111 259 minecraft:light[level=12]
setblock 313 111 266 minecraft:light[level=12]
setblock 320 111 231 minecraft:light[level=12]
setblock 320 111 238 minecraft:light[level=12]
setblock 320 111 245 minecraft:light[level=12]
setblock 320 111 252 minecraft:light[level=12]
setblock 320 111 259 minecraft:light[level=12]
setblock 320 111 266 minecraft:light[level=12]
setblock 300 112 228 minecraft:magma_block
fill 300 112 270 300 128 270 minecraft:basalt
fill 301 112 228 304 160 228 minecraft:basalt
setblock 301 112 270 minecraft:shroomlight
fill 302 112 270 306 140 270 minecraft:basalt
setblock 285 113 231 minecraft:light[level=12]
setblock 285 113 239 minecraft:light[level=12]
setblock 285 113 247 minecraft:light[level=12]
setblock 285 113 255 minecraft:light[level=12]
setblock 285 113 263 minecraft:light[level=12]
setblock 293 113 231 minecraft:light[level=12]
setblock 293 113 239 minecraft:light[level=12]
setblock 293 113 247 minecraft:light[level=12]
setblock 293 113 255 minecraft:light[level=12]
setblock 293 113 263 minecraft:light[level=12]
fill 300 113 228 300 127 228 minecraft:basalt
setblock 301 113 231 minecraft:light[level=12]
setblock 301 113 239 minecraft:light[level=12]
setblock 301 113 247 minecraft:light[level=12]
setblock 301 113 255 minecraft:light[level=12]
setblock 301 113 263 minecraft:light[level=12]
fill 301 113 270 301 178 270 minecraft:basalt
setblock 307 113 228 minecraft:magma_block
setblock 309 113 231 minecraft:light[level=12]
setblock 309 113 247 minecraft:light[level=12]
setblock 309 113 255 minecraft:light[level=12]
setblock 309 113 263 minecraft:light[level=12]
setblock 317 113 231 minecraft:light[level=12]
setblock 317 113 239 minecraft:light[level=12]
setblock 317 113 247 minecraft:light[level=12]
setblock 317 113 255 minecraft:light[level=12]
setblock 317 113 263 minecraft:light[level=12]
fill 288 114 263 291 175 264 minecraft:basalt
fill 289 114 262 290 175 262 minecraft:basalt
fill 289 114 265 290 175 265 minecraft:basalt
fill 307 114 228 307 179 228 minecraft:basalt
fill 287 115 263 287 116 263 minecraft:blackstone
fill 288 115 262 288 116 262 minecraft:blackstone
fill 288 115 265 288 116 265 minecraft:blackstone
fill 289 115 261 290 116 261 minecraft:blackstone
fill 291 115 262 291 116 262 minecraft:blackstone
fill 291 115 265 291 116 265 minecraft:blackstone
setblock 298 115 270 minecraft:magma_block
fill 312 115 261 312 116 261 minecraft:blackstone
setblock 320 115 228 minecraft:magma_block
fill 324 115 238 324 180 238 minecraft:basalt
setblock 324 115 239 minecraft:crying_obsidian
setblock 287 116 262 minecraft:blackstone
fill 287 116 264 287 116 265 minecraft:blackstone
setblock 288 116 261 minecraft:blackstone
fill 288 116 266 291 116 266 minecraft:blackstone
setblock 291 116 261 minecraft:blackstone
fill 292 116 262 292 116 265 minecraft:blackstone
fill 298 116 270 298 179 270 minecraft:basalt
fill 315 116 270 315 177 270 minecraft:basalt
setblock 316 116 270 minecraft:crying_obsidian
fill 320 116 228 320 179 228 minecraft:basalt
fill 324 116 239 324 179 239 minecraft:basalt
setblock 285 117 231 minecraft:light[level=12]
setblock 285 117 238 minecraft:light[level=12]
setblock 285 117 245 minecraft:light[level=12]
setblock 285 117 252 minecraft:light[level=12]
setblock 285 117 259 minecraft:light[level=12]
setblock 285 117 266 minecraft:light[level=12]
setblock 292 117 231 minecraft:light[level=12]
setblock 292 117 238 minecraft:light[level=12]
setblock 292 117 245 minecraft:light[level=12]
setblock 292 117 252 minecraft:light[level=12]
setblock 292 117 259 minecraft:light[level=12]
setblock 292 117 266 minecraft:light[level=12]
setblock 299 117 231 minecraft:light[level=12]
setblock 299 117 238 minecraft:light[level=12]
setblock 299 117 245 minecraft:light[level=12]
setblock 299 117 252 minecraft:light[level=12]
setblock 299 117 259 minecraft:light[level=12]
setblock 299 117 266 minecraft:light[level=12]
setblock 306 117 231 minecraft:light[level=12]
setblock 306 117 238 minecraft:light[level=12]
setblock 306 117 245 minecraft:light[level=12]
setblock 306 117 252 minecraft:light[level=12]
setblock 306 117 259 minecraft:light[level=12]
setblock 306 117 266 minecraft:light[level=12]
setblock 313 117 231 minecraft:light[level=12]
setblock 313 117 238 minecraft:light[level=12]
setblock 313 117 245 minecraft:light[level=12]
setblock 313 117 252 minecraft:light[level=12]
setblock 313 117 259 minecraft:light[level=12]
setblock 313 117 266 minecraft:light[level=12]
fill 316 117 270 316 131 270 minecraft:basalt
setblock 320 117 231 minecraft:light[level=12]
setblock 320 117 238 minecraft:light[level=12]
setblock 320 117 245 minecraft:light[level=12]
setblock 320 117 252 minecraft:light[level=12]
setblock 320 117 259 minecraft:light[level=12]
setblock 320 117 266 minecraft:light[level=12]
setblock 321 118 270 minecraft:crying_obsidian
setblock 282 119 232 minecraft:magma_block
fill 282 119 233 282 175 233 minecraft:basalt
fill 321 119 270 321 179 270 minecraft:basalt
setblock 324 119 266 minecraft:magma_block
fill 282 120 232 282 155 232 minecraft:basalt
setblock 285 120 231 minecraft:light[level=12]
setblock 285 120 239 minecraft:light[level=12]
setblock 285 120 247 minecraft:light[level=12]
setblock 285 120 255 minecraft:light[level=12]
setblock 285 120 263 minecraft:light[level=12]
setblock 293 120 231 minecraft:light[level=12]
setblock 293 120 239 minecraft:light[level=12]
setblock 293 120 247 minecraft:light[level=12]
setblock 293 120 255 minecraft:light[level=12]
setblock 293 120 263 minecraft:light[level=12]
setblock 301 120 231 minecraft:light[level=12]
setblock 301 120 239 minecraft:light[level=12]
setblock 301 120 247 minecraft:light[level=12]
setblock 301 120 255 minecraft:light[level=12]
setblock 301 120 263 minecraft:light[level=12]
setblock 309 120 231 minecraft:light[level=12]
setblock 309 120 247 minecraft:light[level=12]
setblock 309 120 255 minecraft:light[level=12]
setblock 309 120 263 minecraft:light[level=12]
setblock 317 120 231 minecraft:light[level=12]
setblock 317 120 239 minecraft:light[level=12]
setblock 317 120 247 minecraft:light[level=12]
setblock 317 120 255 minecraft:light[level=12]
setblock 317 120 263 minecraft:light[level=12]
fill 324 120 266 324 176 266 minecraft:basalt
setblock 282 121 252 minecraft:shroomlight
fill 282 121 253 282 155 253 minecraft:basalt
fill 300 121 260 301 121 262 minecraft:blackstone
fill 282 122 252 282 179 252 minecraft:basalt
setblock 282 122 268 minecraft:magma_block
fill 299 122 261 299 122 262 minecraft:blackstone
fill 300 122 260 301 122 260 minecraft:blackstone
fill 300 122 261 301 122 262 minecraft:magma_block
fill 300 122 263 301 122 264 minecraft:blackstone
fill 302 122 240 303 123 241 minecraft:magma_block
fill 302 122 261 302 122 262 minecraft:blackstone
fill 303 122 242 303 123 242 minecraft:magma_block
setblock 282 123 248 minecraft:magma_block
setblock 282 123 254 minecraft:magma_block
fill 282 123 268 282 179 268 minecraft:basalt
fill 283 123 229 286 123 269 minecraft:blackstone
fill 287 123 229 323 123 232 minecraft:blackstone
fill 287 123 266 323 123 269 minecraft:blackstone
setblock 292 123 238 minecraft:light[level=12]
setblock 292 123 245 minecraft:light[level=12]
setblock 292 123 252 minecraft:light[level=12]
setblock 292 123 259 minecraft:light[level=12]
setblock 299 123 238 minecraft:light[level=12]
setblock 299 123 245 minecraft:light[level=12]
setblock 299 123 252 minecraft:light[level=12]
setblock 299 123 259 minecraft:light[level=12]
fill 299 123 263 299 123 264 minecraft:blackstone
fill 300 123 261 301 123 262 minecraft:blackstone
fill 300 123 263 301 123 264 minecraft:magma_block
fill 300 123 265 301 123 265 minecraft:blackstone
fill 302 123 263 302 123 264 minecraft:blackstone
setblock 306 123 238 minecraft:light[level=12]
setblock 306 123 245 minecraft:light[level=12]
setblock 306 123 252 minecraft:light[level=12]
setblock 306 123 259 minecraft:light[level=12]
setblock 313 123 238 minecraft:light[level=12]
setblock 313 123 245 minecraft:light[level=12]
setblock 313 123 252 minecraft:light[level=12]
setblock 313 123 259 minecraft:light[level=12]
fill 320 123 233 323 123 265 minecraft:blackstone
fill 282 124 248 282 150 248 minecraft:basalt
fill 282 124 254 282 144 254 minecraft:basalt
fill 282 124 262 285 124 262 minecraft:magma_block
fill 282 124 263 282 179 264 minecraft:basalt
fill 283 124 229 285 124 261 minecraft:magma_block
fill 283 124 263 285 124 269 minecraft:magma_block
fill 286 124 229 323 124 231 minecraft:magma_block
fill 286 124 248 286 141 250 minecraft:basalt
fill 286 124 267 299 124 269 minecraft:magma_block
setblock 290 124 228 minecraft:magma_block
fill 299 124 265 299 124 266 minecraft:blackstone
fill 300 124 263 301 124 264 minecraft:blackstone
fill 300 124 265 301 124 266 minecraft:magma_block
fill 300 124 267 301 124 268 minecraft:blackstone
fill 300 124 269 323 124 269 minecraft:magma_block
fill 302 124 265 302 124 266 minecraft:blackstone
fill 302 124 267 323 124 268 minecraft:magma_block
setblock 307 124 270 minecraft:magma_block
fill 321 124 232 323 124 266 minecraft:magma_block
fill 282 125 262 282 149 262 minecraft:basalt
fill 283 125 229 284 125 269 minecraft:shroomlight
fill 285 125 229 323 125 230 minecraft:shroomlight
fill 285 125 248 285 141 250 minecraft:basalt
fill 285 125 268 298 125 269 minecraft:shroomlight
setblock 286 125 270 minecraft:magma_block
fill 290 125 228 290 179 228 minecraft:basalt
fill 299 125 267 299 125 268 minecraft:blackstone
setblock 299 125 269 minecraft:shroomlight
fill 300 125 265 301 125 266 minecraft:blackstone
fill 300 125 267 301 125 268 minecraft:magma_block
fill 300 125 269 301 126 269 minecraft:blackstone
fill 302 125 267 302 125 268 minecraft:blackstone
fill 302 125 269 323 125 269 minecraft:shroomlight
fill 303 125 268 323 125 268 minecraft:shroomlight
fill 307 125 270 307 154 270 minecraft:basalt
setblock 313 125 270 minecraft:crying_obsidian
fill 317 125 245 317 126 245 minecraft:blackstone
fill 322 125 231 323 125 267 minecraft:shroomlight
fill 284 126 248 284 141 250 minecraft:basalt
fill 286 126 270 286 176 270 minecraft:basalt
fill 300 126 267 301 126 268 minecraft:blackstone
fill 313 126 270 313 179 270 minecraft:basalt
setblock 285 127 231 minecraft:light[level=12]
setblock 285 127 239 minecraft:light[level=12]
setblock 285 127 247 minecraft:light[level=12]
setblock 285 127 255 minecraft:light[level=12]
setblock 285 127 263 minecraft:light[level=12]
setblock 293 127 231 minecraft:light[level=12]
setblock 293 127 239 minecraft:light[level=12]
setblock 293 127 247 minecraft:light[level=12]
setblock 293 127 255 minecraft:light[level=12]
setblock 293 127 263 minecraft:light[level=12]
setblock 301 127 231 minecraft:light[level=12]
setblock 301 127 239 minecraft:light[level=12]
setblock 301 127 247 minecraft:light[level=12]
setblock 301 127 255 minecraft:light[level=12]
setblock 301 127 263 minecraft:light[level=12]
setblock 309 127 231 minecraft:light[level=12]
setblock 309 127 247 minecraft:light[level=12]
setblock 309 127 255 minecraft:light[level=12]
setblock 309 127 263 minecraft:light[level=12]
setblock 317 127 231 minecraft:light[level=12]
setblock 317 127 239 minecraft:light[level=12]
setblock 317 127 247 minecraft:light[level=12]
setblock 317 127 255 minecraft:light[level=12]
setblock 317 127 263 minecraft:light[level=12]
setblock 282 128 242 minecraft:shroomlight
fill 289 128 257 289 129 258 minecraft:magma_block
setblock 300 128 228 minecraft:magma_block
fill 282 129 242 282 136 242 minecraft:basalt
setblock 285 129 231 minecraft:light[level=12]
setblock 285 129 238 minecraft:light[level=12]
setblock 285 129 245 minecraft:light[level=12]
setblock 285 129 252 minecraft:light[level=12]
setblock 285 129 259 minecraft:light[level=12]
setblock 285 129 266 minecraft:light[level=12]
setblock 292 129 231 minecraft:light[level=12]
setblock 292 129 238 minecraft:light[level=12]
setblock 292 129 245 minecraft:light[level=12]
setblock 292 129 252 minecraft:light[level=12]
setblock 292 129 259 minecraft:light[level=12]
setblock 292 129 266 minecraft:light[level=12]
setblock 299 129 231 minecraft:light[level=12]
setblock 299 129 238 minecraft:light[level=12]
setblock 299 129 245 minecraft:light[level=12]
setblock 299 129 252 minecraft:light[level=12]
setblock 299 129 259 minecraft:light[level=12]
setblock 299 129 266 minecraft:light[level=12]
fill 300 129 228 300 179 228 minecraft:basalt
setblock 300 129 270 minecraft:shroomlight
setblock 306 129 231 minecraft:light[level=12]
setblock 306 129 238 minecraft:light[level=12]
setblock 306 129 245 minecraft:light[level=12]
setblock 306 129 252 minecraft:light[level=12]
setblock 306 129 259 minecraft:light[level=12]
setblock 306 129 266 minecraft:light[level=12]
setblock 313 129 231 minecraft:light[level=12]
setblock 313 129 238 minecraft:light[level=12]
setblock 313 129 245 minecraft:light[level=12]
setblock 313 129 252 minecraft:light[level=12]
setblock 313 129 259 minecraft:light[level=12]
setblock 313 129 266 minecraft:light[level=12]
setblock 320 129 231 minecraft:light[level=12]
setblock 320 129 238 minecraft:light[level=12]
setblock 320 129 245 minecraft:light[level=12]
setblock 320 129 252 minecraft:light[level=12]
setblock 320 129 259 minecraft:light[level=12]
setblock 320 129 266 minecraft:light[level=12]
fill 300 130 270 300 175 270 minecraft:basalt
setblock 282 131 249 minecraft:magma_block
fill 282 132 249 282 179 249 minecraft:basalt
setblock 316 132 270 minecraft:crying_obsidian
setblock 324 132 229 minecraft:shroomlight
fill 324 132 230 324 135 232 minecraft:basalt
fill 311 133 238 311 136 238 minecraft:basalt
setblock 311 133 239 minecraft:magma_block
fill 311 133 240 312 134 241 minecraft:basalt
fill 316 133 270 316 180 270 minecraft:basalt
fill 324 133 229 324 153 229 minecraft:basalt
setblock 282 134 240 minecraft:crying_obsidian
fill 285 134 231 285 135 231 minecraft:light[level=12]
setblock 285 134 239 minecraft:light[level=12]
setblock 285 134 247 minecraft:light[level=12]
setblock 285 134 255 minecraft:light[level=12]
setblock 285 134 263 minecraft:light[level=12]
setblock 293 134 231 minecraft:light[level=12]
setblock 293 134 239 minecraft:light[level=12]
setblock 293 134 247 minecraft:light[level=12]
setblock 293 134 255 minecraft:light[level=12]
setblock 293 134 263 minecraft:light[level=12]
setblock 301 134 231 minecraft:light[level=12]
setblock 301 134 239 minecraft:light[level=12]
setblock 301 134 247 minecraft:light[level=12]
setblock 301 134 255 minecraft:light[level=12]
setblock 301 134 263 minecraft:light[level=12]
setblock 309 134 231 minecraft:light[level=12]
setblock 309 134 247 minecraft:light[level=12]
setblock 309 134 255 minecraft:light[level=12]
setblock 309 134 263 minecraft:light[level=12]
fill 310 134 240 310 135 241 minecraft:basalt
fill 311 134 239 313 134 239 minecraft:basalt
fill 312 134 238 313 134 238 minecraft:basalt
fill 313 134 240 313 135 240 minecraft:basalt
setblock 317 134 231 minecraft:light[level=12]
setblock 317 134 239 minecraft:light[level=12]
setblock 317 134 247 minecraft:light[level=12]
setblock 317 134 255 minecraft:light[level=12]
setblock 317 134 263 minecraft:light[level=12]
fill 282 135 240 282 157 240 minecraft:basalt
setblock 285 135 238 minecraft:light[level=12]
setblock 285 135 245 minecraft:light[level=12]
setblock 285 135 252 minecraft:light[level=12]
setblock 285 135 259 minecraft:light[level=12]
setblock 285 135 266 minecraft:light[level=12]
setblock 292 135 231 minecraft:light[level=12]
setblock 292 135 238 minecraft:light[level=12]
setblock 292 135 245 minecraft:light[level=12]
setblock 292 135 252 minecraft:light[level=12]
setblock 292 135 259 minecraft:light[level=12]
setblock 292 135 266 minecraft:light[level=12]
setblock 299 135 231 minecraft:light[level=12]
setblock 299 135 238 minecraft:light[level=12]
setblock 299 135 245 minecraft:light[level=12]
setblock 299 135 252 minecraft:light[level=12]
setblock 299 135 259 minecraft:light[level=12]
setblock 299 135 266 minecraft:light[level=12]
setblock 306 135 231 minecraft:light[level=12]
setblock 306 135 238 minecraft:light[level=12]
setblock 306 135 245 minecraft:light[level=12]
setblock 306 135 252 minecraft:light[level=12]
setblock 306 135 259 minecraft:light[level=12]
setblock 306 135 266 minecraft:light[level=12]
fill 311 135 239 311 135 240 minecraft:basalt
setblock 311 135 241 minecraft:magma_block
fill 312 135 238 312 135 239 minecraft:basalt
setblock 312 135 240 minecraft:magma_block
fill 312 135 241 312 136 241 minecraft:basalt
setblock 313 135 231 minecraft:light[level=12]
setblock 313 135 238 minecraft:light[level=12]
setblock 313 135 239 minecraft:magma_block
setblock 313 135 245 minecraft:light[level=12]
setblock 313 135 252 minecraft:light[level=12]
setblock 313 135 259 minecraft:light[level=12]
setblock 313 135 266 minecraft:light[level=12]
setblock 317 135 228 minecraft:magma_block
setblock 320 135 231 minecraft:light[level=12]
setblock 320 135 238 minecraft:light[level=12]
setblock 320 135 245 minecraft:light[level=12]
setblock 320 135 252 minecraft:light[level=12]
setblock 320 135 259 minecraft:light[level=12]
setblock 320 135 266 minecraft:light[level=12]
setblock 311 136 239 minecraft:magma_block
fill 311 136 240 311 136 241 minecraft:basalt
setblock 312 136 240 minecraft:basalt
fill 317 136 228 317 179 228 minecraft:basalt
setblock 324 136 230 minecraft:crying_obsidian
fill 324 136 231 324 137 232 minecraft:basalt
setblock 282 137 242 minecraft:magma_block
fill 324 137 230 324 179 230 minecraft:basalt
fill 282 138 242 282 154 242 minecraft:basalt
setblock 282 138 243 minecraft:magma_block
fill 324 138 231 324 176 231 minecraft:basalt
setblock 324 138 232 minecraft:shroomlight
setblock 282 139 243 minecraft:shroomlight
fill 324 139 232 324 179 232 minecraft:basalt
fill 282 140 243 282 152 243 minecraft:basalt
fill 282 140 244 282 142 244 minecraft:magma_block
setblock 285 141 231 minecraft:light[level=12]
fill 285 141 238 285 141 239 minecraft:light[level=12]
setblock 285 141 245 minecraft:light[level=12]
setblock 285 141 247 minecraft:light[level=12]
setblock 285 141 252 minecraft:light[level=12]
setblock 285 141 255 minecraft:light[level=12]
setblock 285 141 259 minecraft:light[level=12]
setblock 285 141 263 minecraft:light[level=12]
setblock 285 141 266 minecraft:light[level=12]
setblock 290 141 270 minecraft:magma_block
fill 292 141 231 293 141 231 minecraft:light[level=12]
setblock 292 141 238 minecraft:light[level=12]
setblock 292 141 245 minecraft:light[level=12]
setblock 292 141 252 minecraft:light[level=12]
setblock 292 141 259 minecraft:light[level=12]
setblock 292 141 266 minecraft:light[level=12]
setblock 293 141 239 minecraft:light[level=12]
setblock 293 141 247 minecraft:light[level=12]
setblock 293 141 255 minecraft:light[level=12]
setblock 293 141 263 minecraft:light[level=12]
setblock 299 141 231 minecraft:light[level=12]
setblock 299 141 238 minecraft:light[level=12]
setblock 299 141 245 minecraft:light[level=12]
setblock 299 141 252 minecraft:light[level=12]
setblock 299 141 259 minecraft:light[level=12]
setblock 299 141 266 minecraft:light[level=12]
fill 300 141 258 300 142 258 minecraft:magma_block
setblock 301 141 231 minecraft:light[level=12]
setblock 301 141 239 minecraft:light[level=12]
setblock 301 141 247 minecraft:light[level=12]
setblock 301 141 255 minecraft:light[level=12]
setblock 301 141 263 minecraft:light[level=12]
fill 302 141 270 302 145 270 minecraft:basalt
setblock 303 141 270 minecraft:magma_block
fill 304 141 270 306 176 270 minecraft:basalt
setblock 306 141 231 minecraft:light[level=12]
setblock 306 141 238 minecraft:light[level=12]
setblock 306 141 245 minecraft:light[level=12]
setblock 306 141 252 minecraft:light[level=12]
setblock 306 141 259 minecraft:light[level=12]
setblock 306 141 266 minecraft:light[level=12]
setblock 309 141 231 minecraft:light[level=12]
setblock 309 141 247 minecraft:light[level=12]
setblock 309 141 255 minecraft:light[level=12]
setblock 309 141 263 minecraft:light[level=12]
setblock 313 141 231 minecraft:light[level=12]
setblock 313 141 238 minecraft:light[level=12]
setblock 313 141 245 minecraft:light[level=12]
setblock 313 141 252 minecraft:light[level=12]
setblock 313 141 259 minecraft:light[level=12]
setblock 313 141 266 minecraft:light[level=12]
setblock 317 141 231 minecraft:light[level=12]
setblock 317 141 239 minecraft:light[level=12]
setblock 317 141 247 minecraft:light[level=12]
setblock 317 141 255 minecraft:light[level=12]
setblock 317 141 263 minecraft:light[level=12]
setblock 320 141 231 minecraft:light[level=12]
setblock 320 141 238 minecraft:light[level=12]
setblock 320 141 245 minecraft:light[level=12]
setblock 320 141 252 minecraft:light[level=12]
setblock 320 141 259 minecraft:light[level=12]
setblock 320 141 266 minecraft:light[level=12]
fill 283 142 229 286 142 269 minecraft:blackstone
fill 287 142 229 323 142 232 minecraft:blackstone
fill 287 142 266 323 142 269 minecraft:blackstone
fill 290 142 270 290 179 270 minecraft:basalt
fill 303 142 270 303 180 270 minecraft:basalt
fill 305 142 240 305 143 240 minecraft:basalt
fill 320 142 233 323 142 265 minecraft:blackstone
fill 282 143 244 282 149 244 minecraft:basalt
setblock 282 143 245 minecraft:shroomlight
fill 283 143 229 285 143 269 minecraft:magma_block
fill 286 143 229 323 143 231 minecraft:magma_block
fill 286 143 248 286 160 250 minecraft:basalt
fill 286 143 267 323 143 269 minecraft:magma_block
fill 321 143 232 323 143 266 minecraft:magma_block
fill 324 143 255 324 179 256 minecraft:basalt
setblock 324 143 257 minecraft:shroomlight
fill 324 143 258 324 179 258 minecraft:basalt
fill 324 143 268 324 179 268 minecraft:basalt
setblock 324 143 269 minecraft:magma_block
setblock 282 144 245 minecraft:magma_block
fill 283 144 229 284 144 269 minecraft:shroomlight
fill 285 144 229 323 144 230 minecraft:shroomlight
fill 285 144 248 285 160 250 minecraft:basalt
fill 285 144 268 323 144 269 minecraft:shroomlight
fill 322 144 231 323 144 267 minecraft:shroomlight
fill 324 144 248 324 147 252 minecraft:basalt
setblock 324 144 253 minecraft:shroomlight
fill 324 144 257 324 179 257 minecraft:basalt
setblock 324 144 262 minecraft:crying_obsidian
fill 324 144 269 324 154 269 minecraft:basalt
fill 282 145 245 282 148 245 minecraft:basalt
setblock 282 145 246 minecraft:magma_block
setblock 282 145 254 minecraft:shroomlight
fill 284 145 248 284 160 250 minecraft:basalt
fill 324 145 253 324 179 253 minecraft:basalt
fill 324 145 262 324 179 262 minecraft:basalt
setblock 282 146 246 minecraft:basalt
setblock 282 146 247 minecraft:magma_block
fill 282 146 254 282 179 254 minecraft:basalt
setblock 302 146 270 minecraft:magma_block
setblock 282 147 246 minecraft:shroomlight
fill 282 147 247 282 180 247 minecraft:basalt
fill 285 147 231 285 148 231 minecraft:light[level=12]
setblock 285 147 238 minecraft:light[level=12]
setblock 285 147 245 minecraft:light[level=12]
setblock 285 147 252 minecraft:light[level=12]
setblock 285 147 259 minecraft:light[level=12]
setblock 285 147 266 minecraft:light[level=12]
setblock 288 147 270 minecraft:magma_block
setblock 292 147 231 minecraft:light[level=12]
setblock 292 147 238 minecraft:light[level=12]
setblock 292 147 245 minecraft:light[level=12]
setblock 292 147 252 minecraft:light[level=12]
setblock 292 147 259 minecraft:light[level=12]
setblock 292 147 266 minecraft:light[level=12]
setblock 299 147 231 minecraft:light[level=12]
setblock 299 147 238 minecraft:light[level=12]
setblock 299 147 245 minecraft:light[level=12]
setblock 299 147 252 minecraft:light[level=12]
setblock 299 147 259 minecraft:light[level=12]
setblock 299 147 266 minecraft:light[level=12]
fill 302 147 270 302 175 270 minecraft:basalt
setblock 306 147 231 minecraft:light[level=12]
setblock 306 147 238 minecraft:light[level=12]
setblock 306 147 245 minecraft:light[level=12]
setblock 306 147 252 minecraft:light[level=12]
setblock 306 147 259 minecraft:light[level=12]
setblock 306 147 266 minecraft:light[level=12]
setblock 313 147 231 minecraft:light[level=12]
setblock 313 147 238 minecraft:light[level=12]
setblock 313 147 245 minecraft:light[level=12]
setblock 313 147 252 minecraft:light[level=12]
setblock 313 147 259 minecraft:light[level=12]
setblock 313 147 266 minecraft:light[level=12]
setblock 320 147 231 minecraft:light[level=12]
setblock 320 147 238 minecraft:light[level=12]
setblock 320 147 245 minecraft:light[level=12]
setblock 320 147 252 minecraft:light[level=12]
setblock 320 147 259 minecraft:light[level=12]
setblock 320 147 266 minecraft:light[level=12]
setblock 282 148 246 minecraft:magma_block
setblock 285 148 239 minecraft:light[level=12]
setblock 285 148 247 minecraft:light[level=12]
setblock 285 148 255 minecraft:light[level=12]
setblock 285 148 263 minecraft:light[level=12]
fill 288 148 270 288 176 270 minecraft:basalt
setblock 293 148 231 minecraft:light[level=12]
setblock 293 148 239 minecraft:light[level=12]
setblock 293 148 247 minecraft:light[level=12]
setblock 293 148 255 minecraft:light[level=12]
setblock 293 148 263 minecraft:light[level=12]
setblock 301 148 231 minecraft:light[level=12]
setblock 301 148 239 minecraft:light[level=12]
setblock 301 148 247 minecraft:light[level=12]
setblock 301 148 255 minecraft:light[level=12]
setblock 301 148 263 minecraft:light[level=12]
setblock 309 148 231 minecraft:light[level=12]
setblock 309 148 247 minecraft:light[level=12]
setblock 309 148 255 minecraft:light[level=12]
setblock 309 148 263 minecraft:light[level=12]
setblock 317 148 231 minecraft:light[level=12]
setblock 317 148 239 minecraft:light[level=12]
setblock 317 148 247 minecraft:light[level=12]
setblock 317 148 255 minecraft:light[level=12]
setblock 317 148 263 minecraft:light[level=12]
fill 324 148 248 324 177 248 minecraft:basalt
setblock 324 148 249 minecraft:crying_obsidian
fill 324 148 250 324 162 252 minecraft:basalt
setblock 282 149 245 minecraft:magma_block
fill 282 149 246 282 171 246 minecraft:basalt
fill 324 149 249 324 179 249 minecraft:basalt
setblock 282 150 244 minecraft:magma_block
fill 282 150 245 282 180 245 minecraft:basalt
setblock 282 150 262 minecraft:magma_block
setblock 282 151 231 minecraft:magma_block
setblock 282 151 244 minecraft:shroomlight
setblock 282 151 248 minecraft:shroomlight
fill 282 151 262 282 177 262 minecraft:basalt
setblock 324 151 246 minecraft:crying_obsidian
fill 282 152 231 282 179 231 minecraft:basalt
setblock 282 152 244 minecraft:magma_block
fill 282 152 248 282 161 248 minecraft:basalt
fill 297 152 242 298 153 242 minecraft:magma_block
fill 324 152 246 324 179 246 minecraft:basalt
fill 282 153 243 282 154 243 minecraft:magma_block
fill 282 153 244 282 179 244 minecraft:basalt
setblock 285 153 231 minecraft:light[level=12]
setblock 285 153 238 minecraft:light[level=12]
setblock 285 153 245 minecraft:light[level=12]
setblock 285 153 252 minecraft:light[level=12]
setblock 285 153 259 minecraft:light[level=12]
setblock 285 153 266 minecraft:light[level=12]
setblock 292 153 231 minecraft:light[level=12]
setblock 292 153 238 minecraft:light[level=12]
setblock 292 153 245 minecraft:light[level=12]
setblock 292 153 252 minecraft:light[level=12]
setblock 292 153 259 minecraft:light[level=12]
setblock 292 153 266 minecraft:light[level=12]
setblock 299 153 231 minecraft:light[level=12]
setblock 299 153 238 minecraft:light[level=12]
setblock 299 153 245 minecraft:light[level=12]
setblock 299 153 252 minecraft:light[level=12]
setblock 299 153 259 minecraft:light[level=12]
setblock 299 153 266 minecraft:light[level=12]
setblock 306 153 231 minecraft:light[level=12]
setblock 306 153 238 minecraft:light[level=12]
setblock 306 153 245 minecraft:light[level=12]
setblock 306 153 252 minecraft:light[level=12]
setblock 306 153 259 minecraft:light[level=12]
setblock 306 153 266 minecraft:light[level=12]
setblock 313 153 231 minecraft:light[level=12]
setblock 313 153 238 minecraft:light[level=12]
setblock 313 153 245 minecraft:light[level=12]
setblock 313 153 252 minecraft:light[level=12]
setblock 313 153 259 minecraft:light[level=12]
setblock 313 153 266 minecraft:light[level=12]
setblock 320 153 231 minecraft:light[level=12]
setblock 320 153 238 minecraft:light[level=12]
setblock 320 153 245 minecraft:light[level=12]
setblock 320 153 252 minecraft:light[level=12]
setblock 320 153 259 minecraft:light[level=12]
setblock 320 153 266 minecraft:light[level=12]
setblock 324 154 229 minecraft:magma_block
setblock 282 155 242 minecraft:shroomlight
fill 282 155 243 282 179 243 minecraft:basalt
setblock 285 155 231 minecraft:light[level=12]
setblock 285 155 239 minecraft:light[level=12]
setblock 285 155 247 minecraft:light[level=12]
setblock 285 155 255 minecraft:light[level=12]
setblock 285 155 263 minecraft:light[level=12]
setblock 293 155 231 minecraft:light[level=12]
setblock 293 155 239 minecraft:light[level=12]
setblock 293 155 247 minecraft:light[level=12]
setblock 293 155 255 minecraft:light[level=12]
setblock 293 155 263 minecraft:light[level=12]
setblock 301 155 231 minecraft:light[level=12]
setblock 301 155 239 minecraft:light[level=12]
setblock 301 155 247 minecraft:light[level=12]
setblock 301 155 255 minecraft:light[level=12]
setblock 301 155 263 minecraft:light[level=12]
setblock 307 155 270 minecraft:shroomlight
setblock 309 155 231 minecraft:light[level=12]
setblock 309 155 247 minecraft:light[level=12]
setblock 309 155 255 minecraft:light[level=12]
setblock 309 155 263 minecraft:light[level=12]
setblock 317 155 231 minecraft:light[level=12]
setblock 317 155 239 minecraft:light[level=12]
setblock 317 155 247 minecraft:light[level=12]
setblock 317 155 255 minecraft:light[level=12]
setblock 317 155 263 minecraft:light[level=12]
fill 324 155 229 324 180 229 minecraft:basalt
fill 324 155 264 324 179 264 minecraft:basalt
setblock 324 155 265 minecraft:crying_obsidian
setblock 324 155 269 minecraft:magma_block
setblock 282 156 232 minecraft:shroomlight
setblock 282 156 242 minecraft:magma_block
setblock 282 156 253 minecraft:shroomlight
fill 307 156 270 307 179 270 minecraft:basalt
fill 319 156 244 319 157 245 minecraft:basalt
fill 324 156 265 324 181 265 minecraft:basalt
fill 324 156 269 324 161 269 minecraft:basalt
fill 282 157 232 282 179 232 minecraft:basalt
setblock 282 157 241 minecraft:magma_block
fill 282 157 242 282 175 242 minecraft:basalt
fill 282 157 253 282 179 253 minecraft:basalt
setblock 282 158 240 minecraft:magma_block
fill 282 158 241 282 179 241 minecraft:basalt
setblock 289 158 228 minecraft:magma_block
fill 294 158 257 295 159 258 minecraft:magma_block
setblock 311 158 270 minecraft:magma_block
setblock 282 159 239 minecraft:shroomlight
setblock 282 159 240 minecraft:basalt
setblock 285 159 231 minecraft:light[level=12]
setblock 285 159 238 minecraft:light[level=12]
setblock 285 159 245 minecraft:light[level=12]
setblock 285 159 252 minecraft:light[level=12]
setblock 285 159 259 minecraft:light[level=12]
setblock 285 159 266 minecraft:light[level=12]
fill 289 159 228 289 179 228 minecraft:basalt
setblock 292 159 231 minecraft:light[level=12]
setblock 292 159 238 minecraft:light[level=12]
setblock 292 159 245 minecraft:light[level=12]
setblock 292 159 252 minecraft:light[level=12]
setblock 292 159 259 minecraft:light[level=12]
setblock 292 159 266 minecraft:light[level=12]
setblock 299 159 231 minecraft:light[level=12]
setblock 299 159 238 minecraft:light[level=12]
setblock 299 159 245 minecraft:light[level=12]
setblock 299 159 259 minecraft:light[level=12]
setblock 299 159 266 minecraft:light[level=12]
fill 302 159 261 302 163 261 minecraft:basalt
setblock 302 159 262 minecraft:magma_block
fill 302 159 263 303 160 264 minecraft:basalt
setblock 303 159 261 minecraft:magma_block
fill 303 159 262 305 160 262 minecraft:basalt
fill 305 159 261 305 160 261 minecraft:basalt
setblock 306 159 231 minecraft:light[level=12]
setblock 306 159 238 minecraft:light[level=12]
setblock 306 159 245 minecraft:light[level=12]
setblock 306 159 252 minecraft:light[level=12]
setblock 306 159 259 minecraft:light[level=12]
setblock 306 159 266 minecraft:light[level=12]
fill 311 159 270 311 179 270 minecraft:basalt
setblock 313 159 231 minecraft:light[level=12]
setblock 313 159 238 minecraft:light[level=12]
setblock 313 159 245 minecraft:light[level=12]
setblock 313 159 252 minecraft:light[level=12]
setblock 313 159 259 minecraft:light[level=12]
setblock 313 159 266 minecraft:light[level=12]
setblock 320 159 231 minecraft:light[level=12]
setblock 320 159 238 minecraft:light[level=12]
setblock 320 159 245 minecraft:light[level=12]
setblock 320 159 252 minecraft:light[level=12]
setblock 320 159 259 minecraft:light[level=12]
setblock 320 159 266 minecraft:light[level=12]
fill 282 160 239 282 161 239 minecraft:basalt
fill 282 160 240 282 161 240 minecraft:magma_block
fill 284 160 228 284 180 228 minecraft:basalt
setblock 285 160 228 minecraft:crying_obsidian
setblock 299 160 228 minecraft:magma_block
setblock 301 160 261 minecraft:magma_block
fill 301 160 262 301 161 264 minecraft:basalt
fill 302 160 262 302 161 262 minecraft:basalt
fill 302 160 265 302 161 265 minecraft:basalt
fill 303 160 261 304 161 261 minecraft:basalt
fill 304 160 260 305 161 260 minecraft:basalt
fill 304 160 263 304 165 263 minecraft:basalt
setblock 305 160 263 minecraft:magma_block
fill 306 160 261 306 162 261 minecraft:basalt
setblock 306 160 262 minecraft:magma_block
fill 283 161 229 286 161 269 minecraft:blackstone
fill 285 161 228 285 174 228 minecraft:basalt
fill 287 161 229 323 161 232 minecraft:blackstone
fill 287 161 266 323 161 269 minecraft:blackstone
fill 299 161 228 299 179 228 minecraft:basalt
fill 300 161 262 300 162 262 minecraft:basalt
setblock 301 161 228 minecraft:magma_block
fill 301 161 261 301 162 261 minecraft:basalt
fill 302 161 228 304 179 228 minecraft:basalt
fill 302 161 263 302 163 263 minecraft:basalt
setblock 302 161 264 minecraft:magma_block
fill 303 161 260 303 163 260 minecraft:basalt
fill 303 161 262 303 164 262 minecraft:basalt
setblock 303 161 263 minecraft:magma_block
fill 303 161 264 303 162 265 minecraft:basalt
setblock 304 161 262 minecraft:magma_block
fill 304 161 264 304 162 264 minecraft:basalt
setblock 305 161 261 minecraft:magma_block
fill 305 161 262 305 162 263 minecraft:basalt
setblock 306 161 260 minecraft:magma_block
fill 306 161 262 306 162 262 minecraft:basalt
fill 320 161 233 323 161 265 minecraft:blackstone
fill 282 162 239 285 162 239 minecraft:magma_block
fill 282 162 240 282 177 240 minecraft:basalt
fill 282 162 248 285 162 248 minecraft:magma_block
fill 283 162 229 285 162 238 minecraft:magma_block
fill 283 162 240 285 162 247 minecraft:magma_block
fill 283 162 249 285 162 269 minecraft:magma_block
fill 286 162 229 323 162 231 minecraft:magma_block
fill 286 162 248 286 175 250 minecraft:basalt
fill 286 162 267 323 162 269 minecraft:magma_block
setblock 293 162 239 minecraft:light[level=12]
setblock 293 162 247 minecraft:light[level=12]
setblock 293 162 255 minecraft:light[level=12]
setblock 293 162 263 minecraft:light[level=12]
fill 301 162 228 301 182 228 minecraft:basalt
setblock 301 162 239 minecraft:light[level=12]
setblock 301 162 247 minecraft:light[level=12]
setblock 301 162 255 minecraft:light[level=12]
fill 301 162 262 301 163 262 minecraft:basalt
setblock 301 162 263 minecraft:magma_block
setblock 302 162 262 minecraft:magma_block
setblock 302 162 264 minecraft:basalt
setblock 303 162 261 minecraft:magma_block
fill 303 162 263 303 163 263 minecraft:basalt
setblock 304 162 260 minecraft:magma_block
fill 304 162 261 304 163 262 minecraft:basalt
fill 304 162 265 304 163 265 minecraft:basalt
fill 305 162 260 305 163 261 minecraft:basalt
fill 305 162 264 305 163 264 minecraft:basalt
setblock 306 162 260 minecraft:basalt
fill 307 162 238 307 175 240 minecraft:basalt
setblock 308 162 238 minecraft:magma_block
fill 308 162 239 309 163 240 minecraft:basalt
fill 309 162 238 309 175 238 minecraft:basalt
setblock 309 162 247 minecraft:light[level=12]
setblock 309 162 255 minecraft:light[level=12]
setblock 309 162 263 minecraft:light[level=12]
setblock 310 162 240 minecraft:basalt
setblock 317 162 239 minecraft:light[level=12]
setblock 317 162 247 minecraft:light[level=12]
setblock 317 162 255 minecraft:light[level=12]
setblock 317 162 263 minecraft:light[level=12]
fill 321 162 232 323 162 266 minecraft:magma_block
setblock 324 162 269 minecraft:crying_obsidian
fill 282 163 239 284 163 239 minecraft:shroomlight
fill 282 163 248 282 179 248 minecraft:basalt
fill 283 163 229 284 163 238 minecraft:shroomlight
fill 283 163 240 284 163 269 minecraft:shroomlight
fill 285 163 229 323 163 230 minecraft:shroomlight
fill 285 163 248 285 175 250 minecraft:basalt
fill 285 163 268 323 163 269 minecraft:shroomlight
fill 302 163 262 302 164 262 minecraft:basalt
fill 303 163 261 303 164 261 minecraft:basalt
setblock 303 163 264 minecraft:basalt
fill 304 163 260 304 164 260 minecraft:basalt
setblock 304 163 264 minecraft:magma_block
setblock 305 163 262 minecraft:basalt
setblock 305 163 263 minecraft:magma_block
fill 308 163 238 308 175 238 minecraft:basalt
setblock 309 163 241 minecraft:magma_block
setblock 310 163 240 minecraft:magma_block
fill 310 163 241 310 164 241 minecraft:basalt
fill 322 163 231 323 163 267 minecraft:shroomlight
fill 324 163 250 324 179 251 minecraft:basalt
setblock 324 163 252 minecraft:magma_block
fill 324 163 269 324 179 269 minecraft:basalt
fill 282 164 239 282 179 239 minecraft:basalt
fill 284 164 248 284 175 250 minecraft:basalt
setblock 304 164 261 minecraft:basalt
setblock 304 164 264 minecraft:basalt
fill 308 164 239 308 175 239 minecraft:basalt
setblock 308 164 240 minecraft:magma_block
fill 308 164 241 309 165 241 minecraft:basalt
setblock 309 164 239 minecraft:magma_block
fill 309 164 240 310 165 240 minecraft:basalt
setblock 310 164 238 minecraft:magma_block
fill 310 164 239 310 175 239 minecraft:basalt
fill 324 164 252 324 179 252 minecraft:basalt
setblock 285 165 231 minecraft:light[level=12]
setblock 285 165 238 minecraft:light[level=12]
setblock 285 165 245 minecraft:light[level=12]
setblock 285 165 252 minecraft:light[level=12]
setblock 285 165 259 minecraft:light[level=12]
setblock 285 165 266 minecraft:light[level=12]
setblock 292 165 231 minecraft:light[level=12]
setblock 292 165 238 minecraft:light[level=12]
setblock 292 165 245 minecraft:light[level=12]
setblock 292 165 252 minecraft:light[level=12]
setblock 292 165 259 minecraft:light[level=12]
setblock 292 165 266 minecraft:light[level=12]
setblock 299 165 231 minecraft:light[level=12]
setblock 299 165 238 minecraft:light[level=12]
setblock 299 165 245 minecraft:light[level=12]
setblock 299 165 259 minecraft:light[level=12]
setblock 299 165 266 minecraft:light[level=12]
setblock 306 165 231 minecraft:light[level=12]
setblock 306 165 238 minecraft:light[level=12]
setblock 306 165 245 minecraft:light[level=12]
setblock 306 165 252 minecraft:light[level=12]
setblock 306 165 259 minecraft:light[level=12]
setblock 306 165 266 minecraft:light[level=12]
fill 308 165 240 308 175 240 minecraft:basalt
fill 309 165 239 309 175 239 minecraft:basalt
fill 310 165 238 310 175 238 minecraft:basalt
setblock 313 165 231 minecraft:light[level=12]
setblock 313 165 238 minecraft:light[level=12]
setblock 313 165 245 minecraft:light[level=12]
setblock 313 165 252 minecraft:light[level=12]
setblock 313 165 259 minecraft:light[level=12]
setblock 313 165 266 minecraft:light[level=12]
setblock 319 165 228 minecraft:magma_block
setblock 320 165 231 minecraft:light[level=12]
setblock 320 165 238 minecraft:light[level=12]
setblock 320 165 245 minecraft:light[level=12]
setblock 320 165 252 minecraft:light[level=12]
setblock 320 165 259 minecraft:light[level=12]
setblock 320 165 266 minecraft:light[level=12]
fill 309 166 240 309 175 240 minecraft:basalt
fill 319 166 228 319 179 228 minecraft:basalt
setblock 283 168 228 minecraft:magma_block
fill 283 169 228 283 179 228 minecraft:basalt
setblock 285 169 231 minecraft:light[level=12]
setblock 285 169 239 minecraft:light[level=12]
setblock 285 169 247 minecraft:light[level=12]
setblock 285 169 255 minecraft:light[level=12]
setblock 285 169 263 minecraft:light[level=12]
setblock 291 169 270 minecraft:magma_block
setblock 293 169 231 minecraft:light[level=12]
setblock 293 169 239 minecraft:light[level=12]
setblock 293 169 247 minecraft:light[level=12]
setblock 293 169 255 minecraft:light[level=12]
setblock 293 169 263 minecraft:light[level=12]
setblock 301 169 231 minecraft:light[level=12]
setblock 301 169 239 minecraft:light[level=12]
setblock 301 169 247 minecraft:light[level=12]
setblock 301 169 255 minecraft:light[level=12]
setblock 301 169 263 minecraft:light[level=12]
setblock 309 169 231 minecraft:light[level=12]
setblock 309 169 247 minecraft:light[level=12]
setblock 309 169 255 minecraft:light[level=12]
setblock 309 169 263 minecraft:light[level=12]
setblock 317 169 231 minecraft:light[level=12]
setblock 317 169 239 minecraft:light[level=12]
setblock 317 169 247 minecraft:light[level=12]
setblock 317 169 255 minecraft:light[level=12]
setblock 317 169 263 minecraft:light[level=12]
fill 319 169 242 319 173 242 minecraft:basalt
fill 291 170 270 291 176 270 minecraft:basalt
setblock 285 171 231 minecraft:light[level=12]
setblock 285 171 238 minecraft:light[level=12]
setblock 285 171 245 minecraft:light[level=12]
setblock 285 171 252 minecraft:light[level=12]
setblock 285 171 259 minecraft:light[level=12]
setblock 285 171 266 minecraft:light[level=12]
setblock 292 171 231 minecraft:light[level=12]
setblock 292 171 238 minecraft:light[level=12]
setblock 292 171 245 minecraft:light[level=12]
setblock 292 171 252 minecraft:light[level=12]
setblock 292 171 259 minecraft:light[level=12]
setblock 292 171 266 minecraft:light[level=12]
setblock 299 171 231 minecraft:light[level=12]
setblock 299 171 238 minecraft:light[level=12]
setblock 299 171 245 minecraft:light[level=12]
setblock 299 171 259 minecraft:light[level=12]
setblock 299 171 266 minecraft:light[level=12]
setblock 306 171 231 minecraft:light[level=12]
setblock 306 171 238 minecraft:light[level=12]
setblock 306 171 245 minecraft:light[level=12]
setblock 306 171 252 minecraft:light[level=12]
setblock 306 171 259 minecraft:light[level=12]
setblock 306 171 266 minecraft:light[level=12]
setblock 313 171 231 minecraft:light[level=12]
setblock 313 171 238 minecraft:light[level=12]
setblock 313 171 245 minecraft:light[level=12]
setblock 313 171 252 minecraft:light[level=12]
setblock 313 171 259 minecraft:light[level=12]
setblock 313 171 266 minecraft:light[level=12]
fill 318 171 242 318 173 242 minecraft:basalt
fill 319 171 241 319 173 241 minecraft:basalt
fill 319 171 243 319 173 243 minecraft:basalt
setblock 320 171 231 minecraft:light[level=12]
setblock 320 171 238 minecraft:light[level=12]
fill 320 171 242 320 173 242 minecraft:basalt
setblock 320 171 245 minecraft:light[level=12]
setblock 320 171 252 minecraft:light[level=12]
setblock 320 171 259 minecraft:light[level=12]
setblock 320 171 266 minecraft:light[level=12]
setblock 282 172 246 minecraft:crying_obsidian
fill 283 172 247 283 172 251 minecraft:orange_concrete
fill 284 172 246 286 172 247 minecraft:orange_concrete
fill 284 172 251 286 172 252 minecraft:orange_concrete
fill 287 172 247 287 173 251 minecraft:orange_concrete
fill 287 172 262 287 172 265 minecraft:orange_concrete
fill 288 172 248 288 172 250 minecraft:orange_concrete
fill 288 172 261 288 173 262 minecraft:orange_concrete
fill 288 172 265 288 172 266 minecraft:orange_concrete
fill 289 172 261 291 173 261 minecraft:orange_concrete
fill 289 172 266 291 172 266 minecraft:orange_concrete
fill 291 172 262 292 172 262 minecraft:orange_concrete
fill 291 172 265 292 172 265 minecraft:orange_concrete
fill 292 172 263 292 173 264 minecraft:orange_concrete
fill 299 172 257 300 172 257 minecraft:orange_concrete
fill 300 172 256 300 174 256 minecraft:orange_concrete
fill 300 172 258 300 172 259 minecraft:orange_concrete
fill 301 172 259 303 172 259 minecraft:orange_concrete
fill 302 172 255 304 172 255 minecraft:orange_concrete
fill 303 172 258 304 172 258 minecraft:orange_concrete
fill 304 172 256 304 173 257 minecraft:orange_concrete
fill 305 172 237 306 172 241 minecraft:orange_concrete
fill 306 172 236 310 172 236 minecraft:orange_concrete
fill 306 172 242 310 172 242 minecraft:orange_concrete
fill 307 172 237 307 174 237 minecraft:orange_concrete
fill 307 172 241 311 172 241 minecraft:orange_concrete
setblock 308 172 235 minecraft:orange_concrete
fill 310 172 237 311 172 237 minecraft:orange_concrete
fill 310 172 240 312 172 240 minecraft:orange_concrete
fill 311 172 238 312 172 239 minecraft:orange_concrete
fill 318 172 241 318 173 241 minecraft:basalt
fill 318 172 243 318 173 243 minecraft:basalt
fill 320 172 241 320 173 241 minecraft:basalt
fill 320 172 243 320 173 243 minecraft:basalt
fill 282 173 246 282 176 246 minecraft:basalt
fill 283 173 248 283 173 250 minecraft:orange_concrete
fill 284 173 247 286 173 247 minecraft:orange_concrete
fill 284 173 251 286 173 251 minecraft:orange_concrete
fill 287 173 262 287 173 264 minecraft:orange_concrete
fill 288 173 265 288 174 265 minecraft:orange_concrete
fill 289 173 266 290 173 266 minecraft:orange_concrete
fill 291 173 262 291 174 262 minecraft:orange_concrete
fill 291 173 265 291 174 265 minecraft:orange_concrete
fill 300 173 257 300 173 258 minecraft:orange_concrete
fill 301 173 259 302 173 259 minecraft:orange_concrete
fill 302 173 255 303 173 255 minecraft:orange_concrete
fill 303 173 258 303 174 258 minecraft:orange_concrete
fill 305 173 239 306 173 239 minecraft:orange_concrete
fill 306 173 237 306 173 238 minecraft:orange_concrete
fill 306 173 240 306 173 241 minecraft:orange_concrete
fill 307 173 236 309 173 236 minecraft:orange_concrete
fill 307 173 241 310 173 241 minecraft:orange_concrete
fill 308 173 242 309 173 242 minecraft:orange_concrete
fill 310 173 237 310 174 237 minecraft:orange_concrete
fill 310 173 240 311 173 240 minecraft:orange_concrete
fill 311 173 238 311 173 239 minecraft:orange_concrete
setblock 283 174 249 minecraft:orange_concrete
fill 285 174 247 286 174 247 minecraft:orange_concrete
fill 285 174 251 286 174 251 minecraft:orange_concrete
fill 287 174 248 287 174 250 minecraft:orange_concrete
setblock 288 174 262 minecraft:orange_concrete
setblock 300 174 257 minecraft:orange_concrete
setblock 302 174 255 minecraft:orange_concrete
fill 306 174 238 306 174 240 minecraft:orange_concrete
fill 307 174 241 309 174 241 minecraft:orange_concrete
setblock 310 174 240 minecraft:orange_concrete
setblock 324 174 260 minecraft:shroomlight
setblock 285 175 228 minecraft:magma_block
fill 302 175 235 303 175 237 minecraft:basalt
fill 324 175 260 324 179 260 minecraft:basalt
fill 282 176 228 282 178 228 minecraft:blackstone
setblock 282 176 233 minecraft:blackstone
setblock 282 176 242 minecraft:blackstone
setblock 282 176 251 minecraft:blackstone
fill 285 176 228 285 177 228 minecraft:basalt
fill 285 176 231 285 177 231 minecraft:light[level=12]
setblock 285 176 239 minecraft:light[level=12]
setblock 285 176 247 minecraft:light[level=12]
setblock 285 176 255 minecraft:light[level=12]
setblock 285 176 263 minecraft:light[level=12]
setblock 289 176 270 minecraft:blackstone
setblock 293 176 231 minecraft:light[level=12]
setblock 293 176 239 minecraft:light[level=12]
setblock 293 176 247 minecraft:light[level=12]
setblock 293 176 255 minecraft:light[level=12]
setblock 293 176 263 minecraft:light[level=12]
setblock 294 176 228 minecraft:blackstone
fill 300 176 270 300 177 270 minecraft:blackstone
setblock 301 176 231 minecraft:light[level=12]
fill 301 176 234 301 177 236 minecraft:basalt
setblock 301 176 239 minecraft:light[level=12]
setblock 301 176 247 minecraft:light[level=12]
setblock 301 176 255 minecraft:light[level=12]
setblock 301 176 263 minecraft:light[level=12]
fill 302 176 234 303 176 234 minecraft:basalt
fill 302 176 235 302 176 236 minecraft:magma_block
fill 302 176 237 303 176 237 minecraft:basalt
setblock 302 176 270 minecraft:blackstone
fill 303 176 235 303 177 236 minecraft:basalt
setblock 309 176 231 minecraft:light[level=12]
setblock 309 176 239 minecraft:light[level=12]
setblock 309 176 247 minecraft:light[level=12]
setblock 309 176 255 minecraft:light[level=12]
setblock 309 176 263 minecraft:light[level=12]
setblock 311 176 228 minecraft:blackstone
setblock 317 176 231 minecraft:light[level=12]
setblock 317 176 239 minecraft:light[level=12]
setblock 317 176 247 minecraft:light[level=12]
setblock 317 176 255 minecraft:light[level=12]
setblock 317 176 263 minecraft:light[level=12]
setblock 318 176 228 minecraft:blackstone
setblock 320 176 270 minecraft:blackstone
fill 323 176 270 323 177 270 minecraft:basalt
setblock 324 176 234 minecraft:blackstone
fill 324 176 235 324 179 236 minecraft:basalt
setblock 324 176 254 minecraft:blackstone
setblock 324 176 261 minecraft:blackstone
setblock 324 176 270 minecraft:blackstone
fill 282 177 233 282 179 233 minecraft:basalt
setblock 282 177 238 minecraft:blackstone
setblock 282 177 242 minecraft:basalt
setblock 282 177 246 minecraft:blackstone
fill 282 177 251 282 179 251 minecraft:basalt
setblock 282 177 261 minecraft:blackstone
fill 282 177 266 282 177 267 minecraft:blackstone
setblock 284 177 270 minecraft:blackstone
setblock 285 177 238 minecraft:light[level=12]
setblock 285 177 245 minecraft:light[level=12]
setblock 285 177 252 minecraft:light[level=12]
setblock 285 177 259 minecraft:light[level=12]
setblock 285 177 266 minecraft:light[level=12]
fill 285 177 270 285 179 270 minecraft:basalt
setblock 286 177 270 minecraft:blackstone
fill 288 177 228 288 178 228 minecraft:blackstone
setblock 288 177 270 minecraft:blackstone
fill 289 177 270 289 179 270 minecraft:basalt
setblock 291 177 270 minecraft:blackstone
setblock 292 177 231 minecraft:light[level=12]
setblock 292 177 238 minecraft:light[level=12]
setblock 292 177 245 minecraft:light[level=12]
setblock 292 177 252 minecraft:light[level=12]
setblock 292 177 259 minecraft:light[level=12]
setblock 292 177 266 minecraft:light[level=12]
setblock 294 177 228 minecraft:basalt
fill 295 177 228 296 177 228 minecraft:blackstone
setblock 295 177 270 minecraft:blackstone
fill 296 177 252 297 179 252 minecraft:basalt
fill 296 177 270 296 179 270 minecraft:basalt
fill 298 177 249 300 179 250 minecraft:basalt
setblock 299 177 231 minecraft:light[level=12]
setblock 299 177 238 minecraft:light[level=12]
setblock 299 177 245 minecraft:light[level=12]
fill 299 177 248 299 182 248 minecraft:basalt
fill 299 177 254 302 179 255 minecraft:basalt
setblock 299 177 259 minecraft:light[level=12]
setblock 299 177 266 minecraft:light[level=12]
fill 300 177 251 300 179 251 minecraft:basalt
fill 300 177 253 302 179 253 minecraft:basalt
fill 300 177 256 301 182 256 minecraft:basalt
fill 301 177 233 303 177 233 minecraft:basalt
fill 301 177 252 301 179 252 minecraft:basalt
fill 302 177 232 302 180 232 minecraft:basalt
fill 302 177 234 302 177 235 minecraft:magma_block
fill 302 177 236 302 177 237 minecraft:basalt
fill 302 177 270 302 179 270 minecraft:basalt
fill 303 177 234 303 178 234 minecraft:basalt
fill 304 177 270 305 179 270 minecraft:basalt
setblock 306 177 231 minecraft:light[level=12]
setblock 306 177 238 minecraft:light[level=12]
setblock 306 177 245 minecraft:light[level=12]
setblock 306 177 252 minecraft:light[level=12]
setblock 306 177 259 minecraft:light[level=12]
setblock 306 177 266 minecraft:light[level=12]
setblock 306 177 270 minecraft:blackstone
setblock 309 177 228 minecraft:blackstone
fill 311 177 228 311 179 228 minecraft:basalt
setblock 313 177 231 minecraft:light[level=12]
setblock 313 177 238 minecraft:light[level=12]
setblock 313 177 245 minecraft:light[level=12]
setblock 313 177 252 minecraft:light[level=12]
setblock 313 177 259 minecraft:light[level=12]
setblock 313 177 266 minecraft:light[level=12]
fill 318 177 228 318 179 228 minecraft:basalt
setblock 320 177 231 minecraft:light[level=12]
setblock 320 177 238 minecraft:light[level=12]
setblock 320 177 245 minecraft:light[level=12]
setblock 320 177 252 minecraft:light[level=12]
setblock 320 177 259 minecraft:light[level=12]
setblock 320 177 266 minecraft:light[level=12]
setblock 320 177 270 minecraft:magma_block
setblock 322 177 270 minecraft:blackstone
fill 323 177 228 323 179 228 minecraft:basalt
setblock 324 177 228 minecraft:blackstone
fill 324 177 231 324 178 231 minecraft:blackstone
setblock 324 177 234 minecraft:basalt
setblock 324 177 240 minecraft:blackstone
fill 324 177 242 324 178 242 minecraft:blackstone
fill 324 177 254 324 179 254 minecraft:basalt
fill 324 177 261 324 179 261 minecraft:basalt
setblock 324 177 266 minecraft:crying_obsidian
fill 324 177 270 324 179 270 minecraft:basalt
fill 282 178 234 282 179 234 minecraft:basalt
fill 282 178 235 282 178 236 minecraft:blackstone
fill 282 178 238 282 179 238 minecraft:basalt
setblock 282 178 240 minecraft:blackstone
setblock 282 178 242 minecraft:blackstone
fill 282 178 246 282 179 246 minecraft:basalt
setblock 282 178 258 minecraft:shroomlight
fill 282 178 261 282 179 261 minecraft:basalt
setblock 282 178 262 minecraft:blackstone
fill 282 178 266 282 179 266 minecraft:basalt
setblock 282 178 267 minecraft:blackstone
setblock 282 178 270 minecraft:blackstone
fill 284 178 270 284 180 270 minecraft:basalt
setblock 285 178 228 minecraft:blackstone
fill 286 178 270 286 179 270 minecraft:basalt
fill 288 178 270 288 179 270 minecraft:basalt
fill 291 178 252 295 182 253 minecraft:basalt
fill 291 178 270 291 181 270 minecraft:basalt
fill 292 178 249 297 179 251 minecraft:basalt
fill 292 178 254 298 179 256 minecraft:basalt
fill 293 178 247 298 182 248 minecraft:basalt
fill 293 178 257 304 182 257 minecraft:basalt
setblock 294 178 228 minecraft:blackstone
fill 294 178 246 303 182 246 minecraft:basalt
fill 294 178 258 303 182 258 minecraft:basalt
fill 295 178 228 296 179 228 minecraft:basalt
fill 295 178 245 302 182 245 minecraft:basalt
fill 295 178 270 295 179 270 minecraft:basalt
fill 296 178 253 297 179 253 minecraft:basalt
fill 296 178 259 301 182 259 minecraft:basalt
fill 297 178 244 300 182 244 minecraft:basalt
fill 298 178 251 298 179 251 minecraft:basalt
fill 299 178 247 304 182 247 minecraft:basalt
fill 299 178 256 299 182 256 minecraft:basalt
setblock 299 178 270 minecraft:blackstone
fill 300 178 248 305 182 248 minecraft:basalt
fill 300 178 270 300 179 270 minecraft:basalt
fill 301 178 231 301 178 235 minecraft:basalt
fill 301 178 249 305 179 251 minecraft:basalt
fill 302 178 231 302 181 231 minecraft:basalt
fill 302 178 233 302 178 234 minecraft:magma_block
fill 302 178 235 303 178 235 minecraft:basalt
fill 302 178 252 306 179 252 minecraft:basalt
fill 302 178 256 305 182 256 minecraft:basalt
setblock 303 178 233 minecraft:basalt
fill 303 178 253 305 182 255 minecraft:basalt
fill 306 178 251 306 182 251 minecraft:basalt
fill 306 178 253 306 182 253 minecraft:basalt
fill 306 178 270 306 179 270 minecraft:basalt
setblock 308 178 228 minecraft:blackstone
fill 309 178 228 309 179 228 minecraft:basalt
setblock 315 178 270 minecraft:blackstone
setblock 319 178 270 minecraft:blackstone
fill 320 178 270 320 179 270 minecraft:basalt
setblock 322 178 270 minecraft:basalt
setblock 323 178 270 minecraft:blackstone
fill 324 178 228 324 179 228 minecraft:basalt
setblock 324 178 234 minecraft:blackstone
fill 324 178 240 324 181 240 minecraft:basalt
fill 324 178 244 324 178 245 minecraft:blackstone
setblock 324 178 248 minecraft:blackstone
fill 324 178 266 324 179 266 minecraft:basalt
setblock 324 178 267 minecraft:blackstone
setblock 282 179 228 minecraft:basalt
fill 282 179 235 282 179 236 minecraft:basalt
setblock 282 179 240 minecraft:basalt
setblock 282 179 242 minecraft:basalt
setblock 282 179 258 minecraft:basalt
setblock 282 179 262 minecraft:basalt
setblock 282 179 267 minecraft:basalt
setblock 282 179 270 minecraft:basalt
setblock 285 179 228 minecraft:basalt
setblock 288 179 228 minecraft:basalt
fill 290 179 248 290 181 256 minecraft:basalt
fill 291 179 246 291 181 251 minecraft:basalt
fill 291 179 254 291 181 258 minecraft:basalt
fill 292 179 245 292 181 248 minecraft:basalt
fill 292 179 257 292 181 259 minecraft:basalt
fill 293 179 244 293 181 246 minecraft:basalt
fill 293 179 258 293 181 260 minecraft:basalt
fill 294 179 228 294 180 228 minecraft:basalt
fill 294 179 244 294 181 245 minecraft:basalt
fill 294 179 259 295 182 260 minecraft:basalt
fill 295 179 243 296 181 244 minecraft:basalt
fill 295 179 261 301 182 261 minecraft:basalt
fill 296 179 260 303 182 260 minecraft:basalt
fill 297 179 243 302 181 243 minecraft:basalt
setblock 299 179 270 minecraft:basalt
fill 300 179 230 300 180 232 minecraft:basalt
fill 301 179 230 302 179 230 minecraft:basalt
fill 301 179 231 301 179 232 minecraft:magma_block
fill 301 179 233 302 179 234 minecraft:basalt
fill 301 179 244 304 181 244 minecraft:basalt
setblock 301 179 270 minecraft:magma_block
fill 302 179 259 304 182 259 minecraft:basalt
fill 303 179 245 305 182 245 minecraft:basalt
fill 304 179 246 306 182 246 minecraft:basalt
fill 304 179 258 305 182 258 minecraft:basalt
fill 305 179 247 307 182 247 minecraft:basalt
fill 305 179 257 306 182 257 minecraft:basalt
fill 306 179 248 307 182 250 minecraft:basalt
fill 306 179 254 307 182 256 minecraft:basalt
fill 307 179 251 308 182 253 minecraft:basalt
setblock 308 179 228 minecraft:basalt
fill 308 179 249 308 182 250 minecraft:basalt
fill 308 179 254 308 182 254 minecraft:basalt
setblock 309 179 270 minecraft:magma_block
setblock 312 179 270 minecraft:crying_obsidian
setblock 315 179 270 minecraft:basalt
setblock 319 179 270 minecraft:basalt
setblock 322 179 270 minecraft:crying_obsidian
setblock 323 179 270 minecraft:basalt
setblock 324 179 231 minecraft:basalt
setblock 324 179 234 minecraft:basalt
setblock 324 179 242 minecraft:basalt
fill 324 179 244 324 179 245 minecraft:basalt
setblock 324 179 248 minecraft:basalt
setblock 324 179 267 minecraft:basalt
fill 282 180 228 283 180 237 minecraft:blackstone
setblock 282 180 238 minecraft:magma_block
fill 282 180 239 286 180 244 minecraft:blackstone
fill 282 180 246 286 180 246 minecraft:blackstone
fill 282 180 248 283 180 270 minecraft:blackstone
fill 283 180 238 286 180 238 minecraft:blackstone
fill 283 180 245 286 180 245 minecraft:blackstone
fill 283 180 247 286 180 247 minecraft:blackstone
fill 284 180 229 286 180 237 minecraft:blackstone
fill 284 180 248 286 180 269 minecraft:blackstone
fill 285 180 228 293 180 228 minecraft:blackstone
fill 285 180 270 290 180 270 minecraft:blackstone
fill 287 180 229 299 180 232 minecraft:blackstone
fill 287 180 266 324 180 269 minecraft:blackstone
fill 289 180 249 289 180 254 minecraft:basalt
fill 290 180 247 290 181 247 minecraft:basalt
fill 290 180 257 290 181 257 minecraft:basalt
setblock 291 180 245 minecraft:basalt
setblock 291 180 259 minecraft:basalt
setblock 292 180 244 minecraft:basalt
fill 292 180 249 295 182 251 minecraft:basalt
fill 292 180 254 296 182 256 minecraft:basalt
fill 292 180 260 292 181 260 minecraft:basalt
fill 293 180 261 294 180 261 minecraft:basalt
fill 293 180 270 302 180 270 minecraft:blackstone
setblock 294 180 243 minecraft:basalt
fill 295 180 228 300 180 228 minecraft:blackstone
fill 295 180 262 300 180 262 minecraft:basalt
fill 296 180 249 296 182 250 minecraft:basalt
fill 297 180 242 300 180 242 minecraft:basalt
fill 297 180 249 297 182 249 minecraft:basalt
fill 297 180 255 297 182 256 minecraft:basalt
fill 298 180 256 298 182 256 minecraft:basalt
fill 300 180 229 302 180 229 minecraft:basalt
fill 301 180 230 301 180 231 minecraft:magma_block
fill 301 180 232 301 180 233 minecraft:basalt
fill 301 180 249 305 182 249 minecraft:basalt
fill 301 180 255 302 182 255 minecraft:basalt
fill 302 180 228 303 181 228 minecraft:blackstone
fill 302 180 230 302 181 230 minecraft:basalt
fill 302 180 250 305 182 250 minecraft:basalt
fill 302 180 254 302 182 254 minecraft:basalt
fill 302 180 261 303 181 261 minecraft:basalt
fill 303 180 229 323 180 232 minecraft:blackstone
setblock 303 180 243 minecraft:basalt
fill 303 180 251 305 182 252 minecraft:basalt
setblock 304 180 228 minecraft:basalt
fill 304 180 260 304 181 260 minecraft:basalt
fill 304 180 270 315 181 270 minecraft:blackstone
fill 305 180 228 324 180 228 minecraft:blackstone
fill 305 180 244 305 181 244 minecraft:basalt
fill 305 180 259 306 181 259 minecraft:basalt
fill 306 180 245 306 181 245 minecraft:basalt
fill 306 180 252 306 182 252 minecraft:basalt
fill 306 180 258 307 181 258 minecraft:basalt
fill 307 180 246 307 181 246 minecraft:basalt
fill 307 180 257 307 182 257 minecraft:basalt
fill 308 180 247 308 181 248 minecraft:basalt
fill 308 180 255 308 182 256 minecraft:basalt
fill 309 180 249 309 181 255 minecraft:basalt
fill 317 180 270 324 180 270 minecraft:blackstone
fill 320 180 233 323 180 265 minecraft:blackstone
fill 324 180 230 324 180 237 minecraft:blackstone
fill 324 180 239 324 283 239 minecraft:blackstone
fill 324 180 241 324 181 253 minecraft:blackstone
setblock 324 180 254 minecraft:shroomlight
fill 324 180 255 324 180 264 minecraft:blackstone
fill 282 181 228 285 224 228 minecraft:blackstone
setblock 282 181 229 minecraft:basalt
fill 282 181 230 282 261 230 minecraft:blackstone
setblock 282 181 231 minecraft:basalt
fill 282 181 232 282 181 233 minecraft:blackstone
setblock 282 181 234 minecraft:basalt
fill 282 181 235 282 283 235 minecraft:blackstone
setblock 282 181 236 minecraft:basalt
fill 282 181 237 282 181 261 minecraft:blackstone
setblock 282 181 262 minecraft:basalt
fill 282 181 263 282 181 269 minecraft:blackstone
setblock 282 181 270 minecraft:basalt
fill 283 181 229 285 181 269 minecraft:magma_block
fill 283 181 270 286 181 270 minecraft:blackstone
setblock 286 181 228 minecraft:basalt
fill 286 181 229 299 181 231 minecraft:magma_block
fill 286 181 267 323 181 269 minecraft:magma_block
fill 287 181 228 295 181 228 minecraft:blackstone
setblock 287 181 270 minecraft:basalt
fill 288 181 270 290 181 270 minecraft:blackstone
fill 289 181 249 289 181 251 minecraft:basalt
fill 292 181 270 292 250 270 minecraft:blackstone
setblock 293 181 270 minecraft:basalt
setblock 294 181 261 minecraft:basalt
fill 294 181 270 297 181 270 minecraft:blackstone
setblock 296 181 228 minecraft:basalt
fill 296 181 262 300 181 262 minecraft:basalt
fill 297 181 228 299 204 228 minecraft:blackstone
setblock 298 181 270 minecraft:basalt
fill 299 181 270 301 181 270 minecraft:blackstone
fill 300 181 228 300 181 231 minecraft:basalt
fill 301 181 229 301 181 230 minecraft:magma_block
setblock 301 181 231 minecraft:basalt
setblock 302 181 229 minecraft:basalt
setblock 302 181 270 minecraft:crying_obsidian
fill 303 181 229 323 181 231 minecraft:magma_block
fill 303 181 270 303 260 270 minecraft:blackstone
fill 304 181 228 305 212 228 minecraft:blackstone
setblock 305 181 260 minecraft:basalt
setblock 306 181 228 minecraft:basalt
fill 307 181 228 308 241 228 minecraft:blackstone
setblock 308 181 257 minecraft:basalt
setblock 309 181 228 minecraft:basalt
setblock 309 181 248 minecraft:basalt
fill 310 181 228 321 181 228 minecraft:blackstone
fill 310 181 251 310 181 253 minecraft:basalt
fill 316 181 270 319 181 270 minecraft:blackstone
setblock 320 181 270 minecraft:basalt
fill 321 181 232 323 181 266 minecraft:magma_block
fill 321 181 270 324 190 270 minecraft:blackstone
setblock 322 181 228 minecraft:crying_obsidian
setblock 323 181 228 minecraft:basalt
fill 324 181 228 324 181 232 minecraft:blackstone
setblock 324 181 233 minecraft:basalt
fill 324 181 234 324 254 238 minecraft:blackstone
fill 324 181 254 324 195 255 minecraft:blackstone
setblock 324 181 256 minecraft:basalt
fill 324 181 257 324 192 260 minecraft:blackstone
fill 324 181 261 324 181 262 minecraft:basalt
fill 324 181 263 324 249 264 minecraft:blackstone
fill 324 181 266 324 181 269 minecraft:blackstone
fill 282 182 229 282 283 229 minecraft:blackstone
fill 282 182 231 282 273 231 minecraft:blackstone
setblock 282 182 232 minecraft:basalt
fill 282 182 233 282 223 234 minecraft:blackstone
fill 282 182 236 282 183 248 minecraft:blackstone
fill 282 182 249 282 182 250 minecraft:basalt
fill 282 182 251 282 231 257 minecraft:blackstone
setblock 282 182 258 minecraft:basalt
fill 282 182 259 282 186 263 minecraft:blackstone
setblock 282 182 264 minecraft:basalt
fill 282 182 265 282 195 270 minecraft:blackstone
fill 283 182 229 284 182 269 minecraft:shroomlight
fill 283 182 270 284 215 270 minecraft:blackstone
fill 285 182 229 299 182 230 minecraft:shroomlight
fill 285 182 268 323 182 269 minecraft:shroomlight
setblock 285 182 270 minecraft:basalt
fill 286 182 228 289 220 228 minecraft:blackstone
fill 286 182 270 287 224 270 minecraft:blackstone
setblock 288 182 270 minecraft:basalt
fill 289 182 270 291 208 270 minecraft:blackstone
setblock 290 182 228 minecraft:basalt
fill 290 182 248 291 182 251 minecraft:basalt
fill 291 182 228 296 211 228 minecraft:blackstone
fill 291 182 247 292 182 247 minecraft:basalt
fill 291 182 254 291 182 257 minecraft:basalt
fill 292 182 246 293 182 246 minecraft:basalt
setblock 292 182 248 minecraft:basalt
fill 292 182 257 292 182 258 minecraft:basalt
fill 293 182 245 294 182 245 minecraft:basalt
fill 293 182 258 293 182 259 minecraft:basalt
fill 293 182 270 294 184 270 minecraft:blackstone
fill 295 182 244 296 182 244 minecraft:basalt
setblock 295 182 270 minecraft:basalt
fill 296 182 270 298 211 270 minecraft:blackstone
setblock 299 182 270 minecraft:basalt
fill 300 182 228 300 182 230 minecraft:basalt
fill 300 182 270 302 183 270 minecraft:blackstone
fill 301 182 229 301 182 230 minecraft:basalt
fill 301 182 244 302 182 244 minecraft:basalt
fill 302 182 228 302 283 228 minecraft:blackstone
fill 302 182 229 323 182 230 minecraft:shroomlight
setblock 303 182 228 minecraft:crying_obsidian
fill 304 182 270 307 199 270 minecraft:blackstone
setblock 305 182 259 minecraft:basalt
fill 306 182 228 306 263 228 minecraft:blackstone
setblock 306 182 258 minecraft:basalt
setblock 308 182 248 minecraft:basalt
setblock 308 182 270 minecraft:basalt
fill 309 182 228 316 185 228 minecraft:blackstone
fill 309 182 249 309 182 254 minecraft:basalt
fill 309 182 270 313 198 270 minecraft:blackstone
setblock 314 182 270 minecraft:basalt
fill 315 182 270 316 283 270 minecraft:blackstone
setblock 317 182 228 minecraft:basalt
setblock 317 182 270 minecraft:basalt
fill 318 182 228 321 185 228 minecraft:blackstone
setblock 318 182 270 minecraft:magma_block
fill 319 182 270 320 236 270 minecraft:blackstone
setblock 322 182 228 minecraft:basalt
fill 322 182 231 323 182 267 minecraft:shroomlight
fill 323 182 228 324 250 228 minecraft:blackstone
fill 324 182 229 324 283 229 minecraft:blackstone
setblock 324 182 230 minecraft:basalt
fill 324 182 231 324 253 233 minecraft:blackstone
fill 324 182 240 324 195 245 minecraft:blackstone
setblock 324 182 246 minecraft:basalt
fill 324 182 247 324 223 253 minecraft:blackstone
fill 324 182 256 324 252 256 minecraft:blackstone
fill 324 182 261 324 214 261 minecraft:blackstone
setblock 324 182 262 minecraft:basalt
fill 324 182 265 324 184 268 minecraft:blackstone
setblock 324 182 269 minecraft:basalt
fill 282 183 232 282 283 232 minecraft:blackstone
fill 282 183 249 282 283 250 minecraft:blackstone
fill 282 183 258 282 254 258 minecraft:blackstone
fill 282 183 264 282 232 264 minecraft:blackstone
setblock 285 183 231 minecraft:light[level=12]
fill 285 183 238 285 183 239 minecraft:light[level=12]
setblock 285 183 245 minecraft:light[level=12]
setblock 285 183 247 minecraft:light[level=12]
setblock 285 183 252 minecraft:light[level=12]
setblock 285 183 255 minecraft:light[level=12]
setblock 285 183 259 minecraft:light[level=12]
setblock 285 183 263 minecraft:light[level=12]
setblock 285 183 266 minecraft:light[level=12]
fill 285 183 270 285 283 270 minecraft:blackstone
fill 288 183 270 288 205 270 minecraft:blackstone
fill 289 183 249 289 183 255 minecraft:magma_block
fill 290 183 228 290 196 228 minecraft:blackstone
fill 290 183 247 290 183 249 minecraft:magma_block
fill 290 183 255 290 183 257 minecraft:magma_block
fill 291 183 246 291 183 247 minecraft:magma_block
fill 291 183 250 291 183 251 minecraft:blackstone
fill 291 183 257 291 183 258 minecraft:magma_block
fill 292 183 231 293 183 231 minecraft:light[level=12]
setblock 292 183 238 minecraft:light[level=12]
setblock 292 183 245 minecraft:magma_block
fill 292 183 248 292 183 250 minecraft:blackstone
fill 292 183 251 294 183 253 minecraft:magma_block
fill 292 183 254 292 183 255 minecraft:blackstone
setblock 292 183 259 minecraft:magma_block
setblock 292 183 266 minecraft:light[level=12]
setblock 293 183 239 minecraft:light[level=12]
fill 293 183 244 294 183 244 minecraft:magma_block
fill 293 183 247 293 183 248 minecraft:blackstone
fill 293 183 249 294 183 250 minecraft:magma_block
fill 293 183 254 294 183 255 minecraft:magma_block
fill 293 183 256 293 183 257 minecraft:blackstone
fill 293 183 260 294 183 260 minecraft:magma_block
setblock 293 183 263 minecraft:light[level=12]
fill 294 183 243 296 183 243 minecraft:magma_block
fill 294 183 247 296 183 248 minecraft:magma_block
fill 294 183 256 296 183 257 minecraft:magma_block
fill 294 183 258 295 183 258 minecraft:blackstone
fill 294 183 261 296 183 261 minecraft:magma_block
setblock 295 183 246 minecraft:blackstone
fill 295 183 249 295 184 249 minecraft:magma_block
fill 295 183 250 296 183 250 minecraft:ochre_froglight
fill 295 183 251 295 183 253 minecraft:shroomlight
fill 295 183 254 296 183 254 minecraft:ochre_froglight
fill 295 183 255 295 184 255 minecraft:magma_block
fill 295 183 259 297 183 259 minecraft:blackstone
fill 295 183 270 295 199 270 minecraft:blackstone
fill 296 183 242 302 183 242 minecraft:magma_block
fill 296 183 246 302 183 246 minecraft:magma_block
setblock 296 183 249 minecraft:shroomlight
setblock 296 183 255 minecraft:shroomlight
fill 296 183 258 302 183 258 minecraft:magma_block
fill 296 183 262 302 183 262 minecraft:magma_block
fill 297 183 247 304 183 247 minecraft:magma_block
fill 297 183 248 297 183 249 minecraft:ochre_froglight
fill 297 183 255 297 183 256 minecraft:ochre_froglight
fill 297 183 257 304 183 257 minecraft:magma_block
fill 298 183 245 300 184 245 minecraft:magma_block
fill 298 183 248 300 183 248 minecraft:shroomlight
fill 298 183 256 300 183 256 minecraft:shroomlight
fill 298 183 259 300 184 259 minecraft:magma_block
setblock 299 183 231 minecraft:light[level=12]
setblock 299 183 238 minecraft:light[level=12]
setblock 299 183 266 minecraft:light[level=12]
fill 299 183 270 299 218 270 minecraft:blackstone
fill 300 183 228 301 231 228 minecraft:blackstone
setblock 301 183 231 minecraft:light[level=12]
setblock 301 183 239 minecraft:light[level=12]
fill 301 183 248 301 183 249 minecraft:ochre_froglight
fill 301 183 255 301 183 256 minecraft:ochre_froglight
setblock 301 183 263 minecraft:light[level=12]
fill 302 183 243 304 183 243 minecraft:magma_block
fill 302 183 248 304 183 248 minecraft:magma_block
setblock 302 183 249 minecraft:shroomlight
fill 302 183 250 303 183 250 minecraft:ochre_froglight
fill 302 183 254 303 183 254 minecraft:ochre_froglight
setblock 302 183 255 minecraft:shroomlight
fill 302 183 256 304 183 256 minecraft:magma_block
fill 302 183 261 304 183 261 minecraft:magma_block
fill 303 183 228 303 213 228 minecraft:blackstone
setblock 303 183 246 minecraft:blackstone
fill 303 183 249 305 183 249 minecraft:magma_block
fill 303 183 251 303 183 253 minecraft:shroomlight
fill 303 183 255 305 183 255 minecraft:magma_block
fill 304 183 244 305 183 244 minecraft:magma_block
fill 304 183 250 305 183 254 minecraft:magma_block
fill 304 183 260 305 183 260 minecraft:magma_block
fill 305 183 247 305 183 248 minecraft:blackstone
setblock 305 183 256 minecraft:blackstone
setblock 306 183 231 minecraft:light[level=12]
setblock 306 183 238 minecraft:light[level=12]
setblock 306 183 245 minecraft:magma_block
fill 306 183 248 306 183 250 minecraft:blackstone
fill 306 183 251 306 184 253 minecraft:magma_block
fill 306 183 254 306 183 255 minecraft:blackstone
setblock 306 183 259 minecraft:magma_block
setblock 306 183 266 minecraft:light[level=12]
fill 307 183 246 307 183 247 minecraft:magma_block
fill 307 183 249 307 183 254 minecraft:blackstone
fill 307 183 257 307 183 258 minecraft:magma_block
fill 308 183 247 308 183 249 minecraft:magma_block
fill 308 183 255 308 183 257 minecraft:magma_block
fill 308 183 270 308 236 270 minecraft:blackstone
setblock 309 183 231 minecraft:light[level=12]
setblock 309 183 239 minecraft:light[level=12]
setblock 309 183 247 minecraft:light[level=12]
fill 309 183 249 309 183 255 minecraft:magma_block
setblock 309 183 263 minecraft:light[level=12]
setblock 313 183 231 minecraft:light[level=12]
setblock 313 183 238 minecraft:light[level=12]
setblock 313 183 245 minecraft:light[level=12]
setblock 313 183 252 minecraft:light[level=12]
setblock 313 183 259 minecraft:light[level=12]
setblock 313 183 266 minecraft:light[level=12]
setblock 314 183 270 minecraft:blackstone
fill 317 183 228 317 283 228 minecraft:blackstone
setblock 317 183 231 minecraft:light[level=12]
setblock 317 183 239 minecraft:light[level=12]
setblock 317 183 247 minecraft:light[level=12]
setblock 317 183 255 minecraft:light[level=12]
setblock 317 183 263 minecraft:light[level=12]
fill 317 183 270 318 283 270 minecraft:blackstone
setblock 320 183 231 minecraft:light[level=12]
setblock 320 183 238 minecraft:light[level=12]
setblock 320 183 245 minecraft:light[level=12]
setblock 320 183 252 minecraft:light[level=12]
setblock 320 183 259 minecraft:light[level=12]
setblock 320 183 266 minecraft:light[level=12]
fill 322 183 228 322 223 228 minecraft:blackstone
fill 324 183 230 324 210 230 minecraft:blackstone
fill 324 183 246 324 283 246 minecraft:blackstone
fill 324 183 262 324 283 262 minecraft:blackstone
fill 324 183 269 324 283 269 minecraft:blackstone
fill 282 184 236 282 184 241 minecraft:blackstone
setblock 282 184 242 minecraft:crying_obsidian
fill 282 184 243 282 200 248 minecraft:blackstone
fill 283 184 233 283 184 249 minecraft:basalt
fill 283 184 255 283 185 269 minecraft:basalt
fill 284 184 232 284 184 245 minecraft:basalt
fill 284 184 259 284 186 269 minecraft:basalt
fill 285 184 232 287 184 232 minecraft:basalt
setblock 285 184 233 minecraft:magma_block
fill 285 184 234 287 186 235 minecraft:basalt
setblock 285 184 236 minecraft:magma_block
fill 285 184 237 287 189 238 minecraft:basalt
setblock 285 184 239 minecraft:magma_block
fill 285 184 240 287 191 241 minecraft:basalt
setblock 285 184 242 minecraft:magma_block
fill 285 184 243 285 193 243 minecraft:basalt
fill 285 184 261 285 192 262 minecraft:basalt
setblock 285 184 263 minecraft:magma_block
fill 285 184 264 287 190 265 minecraft:basalt
setblock 285 184 266 minecraft:magma_block
fill 285 184 267 287 188 268 minecraft:basalt
setblock 285 184 269 minecraft:magma_block
fill 286 184 231 290 184 231 minecraft:basalt
fill 286 184 233 293 185 233 minecraft:basalt
fill 286 184 236 293 189 236 minecraft:basalt
fill 286 184 239 289 191 239 minecraft:basalt
fill 286 184 242 286 193 242 minecraft:basalt
fill 286 184 262 286 193 263 minecraft:basalt
fill 286 184 266 290 190 266 minecraft:basalt
fill 286 184 269 293 187 269 minecraft:basalt
fill 287 184 230 293 184 230 minecraft:basalt
fill 287 184 263 287 194 263 minecraft:basalt
setblock 288 184 232 minecraft:magma_block
fill 288 184 234 290 188 234 minecraft:basalt
setblock 288 184 235 minecraft:magma_block
fill 288 184 237 290 191 237 minecraft:basalt
setblock 288 184 238 minecraft:magma_block
schedule function dropper:buildpart/54_2 1t
