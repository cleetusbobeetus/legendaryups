fill 276 54 590 276 54 592 minecraft:orange_concrete
fill 276 54 594 276 54 596 minecraft:orange_concrete
setblock 277 54 565 minecraft:yellow_concrete
fill 277 54 566 277 59 567 minecraft:black_concrete
fill 277 54 568 277 55 569 minecraft:yellow_concrete
fill 277 54 574 277 59 575 minecraft:black_concrete
fill 277 54 576 277 54 577 minecraft:yellow_concrete
fill 277 54 578 277 59 578 minecraft:black_concrete
fill 277 54 586 277 59 587 minecraft:black_concrete
fill 277 54 588 277 55 589 minecraft:yellow_concrete
fill 277 54 595 277 59 595 minecraft:black_concrete
setblock 277 54 597 minecraft:yellow_concrete
fill 277 54 598 277 59 598 minecraft:black_concrete
setblock 235 55 559 minecraft:yellow_concrete
fill 235 55 563 235 58 563 minecraft:black_concrete
fill 235 55 579 235 55 580 minecraft:yellow_concrete
setblock 235 55 583 minecraft:yellow_concrete
fill 235 55 584 235 58 584 minecraft:black_concrete
fill 235 55 595 235 58 595 minecraft:black_concrete
setblock 236 55 599 minecraft:yellow_concrete
setblock 238 55 560 minecraft:light[level=14]
setblock 238 55 568 minecraft:light[level=14]
setblock 238 55 576 minecraft:light[level=14]
setblock 238 55 584 minecraft:light[level=14]
setblock 238 55 592 minecraft:light[level=14]
fill 244 55 557 244 58 557 minecraft:black_concrete
setblock 245 55 557 minecraft:yellow_concrete
setblock 246 55 560 minecraft:light[level=14]
setblock 246 55 568 minecraft:light[level=14]
setblock 246 55 576 minecraft:light[level=14]
setblock 246 55 584 minecraft:light[level=14]
setblock 246 55 592 minecraft:light[level=14]
setblock 247 55 599 minecraft:yellow_concrete
fill 248 55 557 249 55 557 minecraft:yellow_concrete
fill 251 55 599 252 58 599 minecraft:black_concrete
setblock 254 55 560 minecraft:light[level=14]
setblock 254 55 568 minecraft:light[level=14]
setblock 254 55 576 minecraft:light[level=14]
setblock 254 55 584 minecraft:light[level=14]
setblock 254 55 592 minecraft:light[level=14]
fill 259 55 568 259 56 569 minecraft:shroomlight
setblock 262 55 560 minecraft:light[level=14]
setblock 262 55 568 minecraft:light[level=14]
setblock 262 55 576 minecraft:light[level=14]
setblock 262 55 584 minecraft:light[level=14]
setblock 262 55 592 minecraft:light[level=14]
fill 264 55 557 265 57 557 minecraft:black_concrete
setblock 268 55 599 minecraft:yellow_concrete
setblock 269 55 557 minecraft:yellow_concrete
setblock 270 55 560 minecraft:light[level=14]
setblock 270 55 568 minecraft:light[level=14]
setblock 270 55 576 minecraft:light[level=14]
setblock 270 55 584 minecraft:light[level=14]
setblock 270 55 592 minecraft:light[level=14]
setblock 271 55 599 minecraft:yellow_concrete
fill 272 55 599 272 58 599 minecraft:black_concrete
setblock 277 55 560 minecraft:yellow_concrete
fill 277 55 565 277 58 565 minecraft:black_concrete
fill 277 55 576 277 58 576 minecraft:black_concrete
setblock 277 55 577 minecraft:yellow_concrete
fill 277 55 580 277 55 581 minecraft:yellow_concrete
fill 277 55 597 277 58 597 minecraft:black_concrete
fill 235 56 557 235 57 558 minecraft:yellow_concrete
fill 235 56 559 235 61 560 minecraft:black_concrete
fill 235 56 569 235 56 570 minecraft:yellow_concrete
fill 235 56 571 235 61 572 minecraft:black_concrete
fill 235 56 578 235 57 578 minecraft:yellow_concrete
fill 235 56 579 235 61 580 minecraft:black_concrete
setblock 235 56 581 minecraft:yellow_concrete
fill 235 56 583 235 61 583 minecraft:black_concrete
fill 235 56 589 235 57 590 minecraft:yellow_concrete
fill 235 56 591 235 61 592 minecraft:black_concrete
fill 236 56 557 237 61 557 minecraft:black_concrete
fill 236 56 599 236 61 599 minecraft:black_concrete
fill 237 56 599 238 56 599 minecraft:yellow_concrete
fill 238 56 557 239 57 557 minecraft:yellow_concrete
fill 239 56 599 240 61 599 minecraft:black_concrete
fill 245 56 557 245 61 557 minecraft:black_concrete
fill 245 56 599 246 57 599 minecraft:yellow_concrete
fill 246 56 557 247 56 557 minecraft:yellow_concrete
fill 247 56 599 248 61 599 minecraft:black_concrete
fill 248 56 557 249 57 557 minecraft:black_concrete
setblock 249 56 599 minecraft:yellow_concrete
fill 250 56 557 250 57 557 minecraft:yellow_concrete
fill 256 56 557 257 61 557 minecraft:black_concrete
fill 257 56 599 258 57 599 minecraft:yellow_concrete
fill 258 56 557 259 57 557 minecraft:yellow_concrete
fill 259 56 599 260 61 599 minecraft:black_concrete
fill 266 56 557 266 59 557 minecraft:black_concrete
fill 266 56 599 266 57 599 minecraft:yellow_concrete
setblock 267 56 557 minecraft:yellow_concrete
fill 268 56 557 269 61 557 minecraft:black_concrete
fill 268 56 599 268 61 599 minecraft:black_concrete
fill 269 56 599 270 56 599 minecraft:yellow_concrete
fill 270 56 557 271 57 557 minecraft:yellow_concrete
fill 271 56 599 271 61 599 minecraft:black_concrete
fill 276 56 557 277 58 557 minecraft:black_concrete
fill 277 56 558 277 56 559 minecraft:yellow_concrete
fill 277 56 560 277 61 560 minecraft:black_concrete
fill 277 56 568 277 61 569 minecraft:black_concrete
fill 277 56 570 277 57 571 minecraft:yellow_concrete
fill 277 56 577 277 61 577 minecraft:black_concrete
setblock 277 56 579 minecraft:yellow_concrete
fill 277 56 580 277 61 581 minecraft:black_concrete
fill 277 56 582 277 57 582 minecraft:yellow_concrete
fill 277 56 588 277 61 589 minecraft:black_concrete
fill 277 56 590 277 56 591 minecraft:yellow_concrete
fill 277 56 599 277 57 599 minecraft:yellow_concrete
setblock 235 57 566 minecraft:yellow_concrete
setblock 235 57 569 minecraft:yellow_concrete
fill 235 57 570 235 60 570 minecraft:black_concrete
setblock 235 57 577 minecraft:yellow_concrete
fill 235 57 581 235 60 581 minecraft:black_concrete
fill 235 57 597 235 57 598 minecraft:yellow_concrete
setblock 237 57 599 minecraft:yellow_concrete
fill 238 57 599 238 60 599 minecraft:black_concrete
fill 246 57 557 247 59 557 minecraft:black_concrete
fill 249 57 599 249 60 599 minecraft:black_concrete
setblock 251 57 557 minecraft:yellow_concrete
setblock 254 57 599 minecraft:yellow_concrete
setblock 262 57 557 minecraft:yellow_concrete
setblock 265 57 599 minecraft:yellow_concrete
fill 267 57 557 267 59 557 minecraft:black_concrete
fill 269 57 599 270 60 599 minecraft:black_concrete
fill 277 57 558 277 60 558 minecraft:black_concrete
setblock 277 57 559 minecraft:yellow_concrete
fill 277 57 562 277 57 563 minecraft:yellow_concrete
fill 277 57 579 277 60 579 minecraft:black_concrete
setblock 277 57 583 minecraft:yellow_concrete
fill 277 57 590 277 60 590 minecraft:black_concrete
setblock 277 57 591 minecraft:yellow_concrete
setblock 277 57 594 minecraft:yellow_concrete
fill 235 58 557 235 63 558 minecraft:black_concrete
fill 235 58 564 235 59 564 minecraft:yellow_concrete
fill 235 58 566 235 63 566 minecraft:black_concrete
fill 235 58 567 235 58 568 minecraft:yellow_concrete
fill 235 58 569 235 63 569 minecraft:black_concrete
fill 235 58 575 235 59 576 minecraft:yellow_concrete
fill 235 58 577 235 63 578 minecraft:black_concrete
fill 235 58 587 235 58 588 minecraft:yellow_concrete
fill 235 58 589 235 63 590 minecraft:black_concrete
fill 235 58 596 235 59 596 minecraft:yellow_concrete
fill 235 58 597 235 63 598 minecraft:black_concrete
setblock 235 58 599 minecraft:yellow_concrete
fill 237 58 599 237 63 599 minecraft:black_concrete
fill 238 58 557 239 63 557 minecraft:black_concrete
fill 240 58 557 241 58 557 minecraft:yellow_concrete
fill 240 58 579 240 59 580 minecraft:shroomlight
fill 243 58 599 244 59 599 minecraft:yellow_concrete
fill 245 58 599 246 63 599 minecraft:black_concrete
fill 248 58 557 248 61 557 minecraft:black_concrete
setblock 249 58 557 minecraft:yellow_concrete
fill 250 58 557 251 63 557 minecraft:black_concrete
fill 252 58 557 253 59 557 minecraft:yellow_concrete
fill 252 58 594 252 59 595 minecraft:orange_concrete
fill 254 58 599 254 63 599 minecraft:black_concrete
fill 255 58 599 256 58 599 minecraft:yellow_concrete
fill 257 58 599 258 63 599 minecraft:black_concrete
fill 258 58 557 259 60 557 minecraft:black_concrete
fill 260 58 557 261 58 557 minecraft:yellow_concrete
fill 262 58 557 262 63 557 minecraft:black_concrete
fill 263 58 599 264 59 599 minecraft:yellow_concrete
fill 264 58 557 264 59 557 minecraft:yellow_concrete
setblock 265 58 557 minecraft:black_concrete
fill 265 58 599 266 63 599 minecraft:black_concrete
setblock 267 58 599 minecraft:yellow_concrete
fill 270 58 557 271 63 557 minecraft:black_concrete
fill 272 58 557 273 59 557 minecraft:yellow_concrete
fill 275 58 599 276 59 599 minecraft:yellow_concrete
fill 277 58 559 277 60 559 minecraft:black_concrete
setblock 277 58 561 minecraft:yellow_concrete
fill 277 58 562 277 63 563 minecraft:black_concrete
fill 277 58 564 277 59 564 minecraft:yellow_concrete
fill 277 58 570 277 63 571 minecraft:black_concrete
fill 277 58 572 277 58 573 minecraft:yellow_concrete
fill 277 58 582 277 63 583 minecraft:black_concrete
fill 277 58 584 277 59 585 minecraft:yellow_concrete
fill 277 58 591 277 63 591 minecraft:black_concrete
fill 277 58 592 277 58 593 minecraft:yellow_concrete
fill 277 58 594 277 63 594 minecraft:black_concrete
fill 277 58 596 277 59 596 minecraft:yellow_concrete
fill 277 58 599 277 63 599 minecraft:black_concrete
setblock 235 59 563 minecraft:yellow_concrete
fill 235 59 567 235 62 568 minecraft:black_concrete
setblock 235 59 584 minecraft:yellow_concrete
setblock 235 59 587 minecraft:yellow_concrete
fill 235 59 588 235 62 588 minecraft:black_concrete
setblock 235 59 595 minecraft:yellow_concrete
fill 235 59 599 235 62 599 minecraft:black_concrete
fill 240 59 557 240 62 557 minecraft:black_concrete
setblock 241 59 557 minecraft:yellow_concrete
setblock 244 59 557 minecraft:yellow_concrete
fill 249 59 557 249 61 557 minecraft:black_concrete
fill 251 59 599 252 59 599 minecraft:yellow_concrete
setblock 255 59 599 minecraft:yellow_concrete
fill 256 59 599 256 62 599 minecraft:black_concrete
fill 260 59 557 260 62 557 minecraft:black_concrete
setblock 261 59 557 minecraft:yellow_concrete
setblock 265 59 557 minecraft:yellow_concrete
fill 267 59 599 267 62 599 minecraft:black_concrete
setblock 272 59 599 minecraft:yellow_concrete
setblock 276 59 557 minecraft:yellow_concrete
fill 277 59 557 277 61 557 minecraft:black_concrete
fill 277 59 561 277 62 561 minecraft:black_concrete
setblock 277 59 565 minecraft:yellow_concrete
fill 277 59 572 277 62 572 minecraft:black_concrete
setblock 277 59 573 minecraft:yellow_concrete
setblock 277 59 576 minecraft:yellow_concrete
fill 277 59 592 277 62 593 minecraft:black_concrete
setblock 277 59 597 minecraft:yellow_concrete
fill 235 60 561 235 61 562 minecraft:yellow_concrete
fill 235 60 563 235 65 564 minecraft:black_concrete
setblock 235 60 565 minecraft:yellow_concrete
fill 235 60 573 235 61 574 minecraft:yellow_concrete
fill 235 60 575 235 65 576 minecraft:black_concrete
fill 235 60 582 235 61 582 minecraft:yellow_concrete
fill 235 60 584 235 65 584 minecraft:black_concrete
fill 235 60 585 235 60 586 minecraft:yellow_concrete
fill 235 60 587 235 65 587 minecraft:black_concrete
fill 235 60 593 235 61 594 minecraft:yellow_concrete
fill 235 60 595 235 65 596 minecraft:black_concrete
fill 236 60 558 238 60 558 minecraft:orange_concrete
fill 236 60 560 236 60 562 minecraft:orange_concrete
fill 236 60 564 236 60 566 minecraft:orange_concrete
fill 236 60 568 236 60 570 minecraft:orange_concrete
fill 236 60 572 236 60 574 minecraft:orange_concrete
fill 236 60 576 236 60 578 minecraft:orange_concrete
fill 236 60 580 236 60 582 minecraft:orange_concrete
fill 236 60 584 236 60 586 minecraft:orange_concrete
fill 236 60 588 236 60 590 minecraft:orange_concrete
fill 236 60 592 236 60 594 minecraft:orange_concrete
fill 236 60 596 236 60 598 minecraft:orange_concrete
fill 238 60 598 240 60 598 minecraft:orange_concrete
fill 240 60 558 242 60 558 minecraft:orange_concrete
fill 241 60 557 241 65 557 minecraft:black_concrete
fill 241 60 599 242 60 599 minecraft:yellow_concrete
fill 242 60 557 243 60 557 minecraft:yellow_concrete
fill 242 60 598 244 60 598 minecraft:orange_concrete
fill 243 60 599 244 65 599 minecraft:black_concrete
fill 244 60 557 244 65 557 minecraft:black_concrete
fill 244 60 558 246 60 558 minecraft:orange_concrete
fill 246 60 557 246 61 557 minecraft:yellow_concrete
fill 246 60 598 248 60 598 minecraft:orange_concrete
setblock 247 60 557 minecraft:black_concrete
fill 248 60 558 250 60 558 minecraft:orange_concrete
fill 250 60 598 252 60 598 minecraft:orange_concrete
fill 250 60 599 250 61 599 minecraft:yellow_concrete
fill 251 60 599 252 65 599 minecraft:black_concrete
fill 252 60 557 253 65 557 minecraft:black_concrete
fill 252 60 558 254 60 558 minecraft:orange_concrete
setblock 253 60 599 minecraft:yellow_concrete
fill 254 60 557 255 61 557 minecraft:yellow_concrete
fill 254 60 598 256 60 598 minecraft:orange_concrete
fill 255 60 596 257 61 597 minecraft:magma_block
fill 255 60 599 255 65 599 minecraft:black_concrete
fill 256 60 558 258 60 558 minecraft:orange_concrete
fill 256 60 593 256 61 595 minecraft:magma_block
fill 258 60 598 260 60 598 minecraft:orange_concrete
fill 260 60 558 262 60 558 minecraft:orange_concrete
fill 261 60 557 261 62 557 minecraft:black_concrete
fill 261 60 599 262 61 599 minecraft:yellow_concrete
fill 262 60 598 264 60 598 minecraft:orange_concrete
setblock 263 60 557 minecraft:yellow_concrete
fill 263 60 599 264 65 599 minecraft:black_concrete
fill 264 60 557 265 65 557 minecraft:black_concrete
fill 264 60 558 266 60 558 minecraft:orange_concrete
fill 266 60 557 267 61 557 minecraft:yellow_concrete
fill 266 60 598 268 60 598 minecraft:orange_concrete
fill 268 60 558 270 60 558 minecraft:orange_concrete
fill 270 60 598 272 60 598 minecraft:orange_concrete
fill 272 60 557 273 65 557 minecraft:black_concrete
fill 272 60 558 274 60 558 minecraft:orange_concrete
fill 272 60 599 272 65 599 minecraft:black_concrete
fill 273 60 599 274 60 599 minecraft:yellow_concrete
fill 274 60 557 275 60 557 minecraft:yellow_concrete
fill 274 60 598 276 60 598 minecraft:orange_concrete
fill 275 60 599 276 65 599 minecraft:black_concrete
fill 276 60 557 276 61 557 minecraft:black_concrete
fill 276 60 558 276 60 560 minecraft:orange_concrete
fill 276 60 562 276 60 564 minecraft:orange_concrete
fill 276 60 566 276 60 568 minecraft:orange_concrete
fill 276 60 570 276 60 572 minecraft:orange_concrete
fill 276 60 574 276 60 576 minecraft:orange_concrete
fill 276 60 578 276 60 580 minecraft:orange_concrete
fill 276 60 582 276 60 584 minecraft:orange_concrete
fill 276 60 586 276 60 588 minecraft:orange_concrete
fill 276 60 590 276 60 592 minecraft:orange_concrete
fill 276 60 594 276 60 596 minecraft:orange_concrete
fill 277 60 564 277 65 565 minecraft:black_concrete
fill 277 60 566 277 61 567 minecraft:yellow_concrete
fill 277 60 573 277 65 573 minecraft:black_concrete
fill 277 60 574 277 60 575 minecraft:yellow_concrete
fill 277 60 576 277 65 576 minecraft:black_concrete
fill 277 60 578 277 61 578 minecraft:yellow_concrete
fill 277 60 584 277 65 585 minecraft:black_concrete
fill 277 60 586 277 61 587 minecraft:yellow_concrete
setblock 277 60 595 minecraft:yellow_concrete
fill 277 60 596 277 65 597 minecraft:black_concrete
fill 277 60 598 277 61 598 minecraft:yellow_concrete
fill 235 61 565 235 64 565 minecraft:black_concrete
setblock 235 61 570 minecraft:yellow_concrete
setblock 235 61 581 minecraft:yellow_concrete
fill 235 61 585 235 64 586 minecraft:black_concrete
setblock 238 61 599 minecraft:yellow_concrete
setblock 241 61 599 minecraft:yellow_concrete
fill 242 61 557 243 64 557 minecraft:black_concrete
fill 242 61 599 242 64 599 minecraft:black_concrete
setblock 247 61 557 minecraft:yellow_concrete
setblock 249 61 599 minecraft:yellow_concrete
fill 253 61 599 253 64 599 minecraft:black_concrete
fill 256 61 591 256 61 592 minecraft:magma_block
setblock 256 61 598 minecraft:magma_block
setblock 258 61 557 minecraft:yellow_concrete
fill 259 61 557 259 63 557 minecraft:black_concrete
fill 263 61 557 263 64 557 minecraft:black_concrete
fill 269 61 599 270 61 599 minecraft:yellow_concrete
setblock 273 61 599 minecraft:yellow_concrete
fill 274 61 557 274 64 557 minecraft:black_concrete
fill 274 61 599 274 64 599 minecraft:black_concrete
setblock 275 61 557 minecraft:yellow_concrete
fill 277 61 558 277 61 559 minecraft:yellow_concrete
fill 277 61 574 277 64 575 minecraft:black_concrete
setblock 277 61 579 minecraft:yellow_concrete
setblock 277 61 590 minecraft:yellow_concrete
fill 277 61 595 277 64 595 minecraft:black_concrete
fill 235 62 559 235 63 560 minecraft:yellow_concrete
fill 235 62 561 235 67 562 minecraft:black_concrete
fill 235 62 570 235 67 570 minecraft:black_concrete
fill 235 62 571 235 62 572 minecraft:yellow_concrete
fill 235 62 573 235 67 574 minecraft:black_concrete
fill 235 62 579 235 63 580 minecraft:yellow_concrete
fill 235 62 581 235 67 582 minecraft:black_concrete
setblock 235 62 583 minecraft:yellow_concrete
fill 235 62 591 235 63 592 minecraft:yellow_concrete
fill 235 62 593 235 67 594 minecraft:black_concrete
fill 236 62 557 237 63 557 minecraft:yellow_concrete
fill 236 62 599 236 63 599 minecraft:yellow_concrete
fill 238 62 599 238 67 599 minecraft:black_concrete
fill 239 62 599 240 62 599 minecraft:yellow_concrete
fill 241 62 599 241 67 599 minecraft:black_concrete
setblock 245 62 557 minecraft:yellow_concrete
fill 246 62 557 247 67 557 minecraft:black_concrete
fill 247 62 599 248 63 599 minecraft:yellow_concrete
fill 248 62 557 249 63 557 minecraft:yellow_concrete
fill 249 62 599 250 67 599 minecraft:black_concrete
fill 254 62 557 255 67 557 minecraft:black_concrete
fill 256 62 557 257 62 557 minecraft:yellow_concrete
fill 258 62 557 258 63 557 minecraft:black_concrete
fill 259 62 599 260 62 599 minecraft:yellow_concrete
fill 261 62 599 262 67 599 minecraft:black_concrete
fill 266 62 557 267 67 557 minecraft:black_concrete
fill 268 62 557 269 63 557 minecraft:yellow_concrete
fill 268 62 599 268 63 599 minecraft:yellow_concrete
fill 269 62 599 270 67 599 minecraft:black_concrete
setblock 271 62 599 minecraft:yellow_concrete
fill 273 62 599 273 67 599 minecraft:black_concrete
fill 275 62 557 275 67 557 minecraft:black_concrete
fill 276 62 557 277 62 557 minecraft:yellow_concrete
fill 277 62 558 277 63 559 minecraft:black_concrete
fill 277 62 560 277 63 560 minecraft:yellow_concrete
fill 277 62 566 277 67 567 minecraft:black_concrete
fill 277 62 568 277 63 569 minecraft:yellow_concrete
setblock 277 62 577 minecraft:yellow_concrete
fill 277 62 578 277 67 579 minecraft:black_concrete
fill 277 62 580 277 63 581 minecraft:yellow_concrete
fill 277 62 586 277 67 587 minecraft:black_concrete
fill 277 62 588 277 62 589 minecraft:yellow_concrete
fill 277 62 590 277 67 590 minecraft:black_concrete
fill 277 62 598 277 67 598 minecraft:black_concrete
fill 235 63 567 235 63 568 minecraft:yellow_concrete
setblock 235 63 571 minecraft:yellow_concrete
fill 235 63 572 235 66 572 minecraft:black_concrete
fill 235 63 583 235 66 583 minecraft:black_concrete
setblock 235 63 588 minecraft:yellow_concrete
setblock 235 63 599 minecraft:yellow_concrete
setblock 238 63 560 minecraft:light[level=14]
setblock 238 63 568 minecraft:light[level=14]
setblock 238 63 576 minecraft:light[level=14]
setblock 238 63 584 minecraft:light[level=14]
setblock 238 63 592 minecraft:light[level=14]
fill 239 63 599 240 66 599 minecraft:black_concrete
setblock 240 63 557 minecraft:yellow_concrete
fill 245 63 557 245 66 557 minecraft:black_concrete
setblock 246 63 560 minecraft:light[level=14]
setblock 246 63 568 minecraft:light[level=14]
setblock 246 63 576 minecraft:light[level=14]
setblock 246 63 584 minecraft:light[level=14]
setblock 246 63 592 minecraft:light[level=14]
setblock 254 63 560 minecraft:light[level=14]
setblock 254 63 568 minecraft:light[level=14]
setblock 254 63 576 minecraft:light[level=14]
setblock 254 63 584 minecraft:light[level=14]
setblock 254 63 592 minecraft:light[level=14]
fill 256 63 557 256 66 557 minecraft:black_concrete
setblock 256 63 599 minecraft:yellow_concrete
setblock 257 63 557 minecraft:yellow_concrete
setblock 259 63 599 minecraft:yellow_concrete
fill 260 63 557 261 63 557 minecraft:yellow_concrete
fill 260 63 599 260 66 599 minecraft:black_concrete
setblock 262 63 560 minecraft:light[level=14]
setblock 262 63 568 minecraft:light[level=14]
setblock 262 63 576 minecraft:light[level=14]
setblock 262 63 584 minecraft:light[level=14]
setblock 262 63 592 minecraft:light[level=14]
setblock 267 63 599 minecraft:yellow_concrete
setblock 270 63 560 minecraft:light[level=14]
setblock 270 63 568 minecraft:light[level=14]
setblock 270 63 576 minecraft:light[level=14]
setblock 270 63 584 minecraft:light[level=14]
setblock 270 63 592 minecraft:light[level=14]
fill 271 63 599 271 66 599 minecraft:black_concrete
fill 276 63 557 277 65 557 minecraft:black_concrete
setblock 277 63 561 minecraft:yellow_concrete
setblock 277 63 572 minecraft:yellow_concrete
fill 277 63 577 277 66 577 minecraft:black_concrete
fill 277 63 588 277 66 588 minecraft:black_concrete
setblock 277 63 589 minecraft:yellow_concrete
fill 277 63 592 277 63 593 minecraft:yellow_concrete
fill 235 64 557 235 64 558 minecraft:yellow_concrete
fill 235 64 559 235 69 560 minecraft:black_concrete
fill 235 64 566 235 65 566 minecraft:yellow_concrete
fill 235 64 567 235 69 568 minecraft:black_concrete
setblock 235 64 569 minecraft:yellow_concrete
fill 235 64 571 235 69 571 minecraft:black_concrete
fill 235 64 577 235 65 578 minecraft:yellow_concrete
fill 235 64 579 235 69 580 minecraft:black_concrete
fill 235 64 588 235 69 588 minecraft:black_concrete
fill 235 64 589 235 64 590 minecraft:yellow_concrete
fill 235 64 591 235 69 592 minecraft:black_concrete
fill 235 64 597 235 65 598 minecraft:yellow_concrete
fill 235 64 599 236 69 599 minecraft:black_concrete
fill 236 64 557 237 69 557 minecraft:black_concrete
setblock 237 64 599 minecraft:yellow_concrete
fill 238 64 557 239 64 557 minecraft:yellow_concrete
fill 240 64 557 240 69 557 minecraft:black_concrete
fill 245 64 599 246 65 599 minecraft:yellow_concrete
fill 247 64 599 248 69 599 minecraft:black_concrete
fill 248 64 557 249 69 557 minecraft:black_concrete
fill 250 64 557 251 65 557 minecraft:yellow_concrete
fill 254 64 599 254 65 599 minecraft:yellow_concrete
fill 256 64 599 256 69 599 minecraft:black_concrete
fill 257 64 557 257 69 557 minecraft:black_concrete
fill 257 64 599 258 64 599 minecraft:yellow_concrete
fill 258 64 557 259 64 557 minecraft:yellow_concrete
fill 259 64 599 259 69 599 minecraft:black_concrete
fill 260 64 557 261 65 557 minecraft:black_concrete
fill 262 64 557 262 65 557 minecraft:yellow_concrete
fill 265 64 599 266 65 599 minecraft:yellow_concrete
fill 267 64 599 268 69 599 minecraft:black_concrete
fill 268 64 557 269 69 557 minecraft:black_concrete
fill 270 64 557 271 65 557 minecraft:yellow_concrete
fill 277 64 558 277 67 558 minecraft:black_concrete
setblock 277 64 559 minecraft:yellow_concrete
fill 277 64 560 277 69 561 minecraft:black_concrete
fill 277 64 562 277 65 563 minecraft:yellow_concrete
fill 277 64 568 277 66 569 minecraft:black_concrete
fill 277 64 570 277 64 571 minecraft:yellow_concrete
fill 277 64 572 277 69 572 minecraft:black_concrete
fill 277 64 580 277 69 581 minecraft:black_concrete
fill 277 64 582 277 65 583 minecraft:yellow_concrete
fill 277 64 589 277 69 589 minecraft:black_concrete
setblock 277 64 591 minecraft:yellow_concrete
fill 277 64 592 277 69 593 minecraft:black_concrete
fill 277 64 594 277 65 594 minecraft:yellow_concrete
fill 277 64 599 277 65 599 minecraft:yellow_concrete
setblock 235 65 557 minecraft:yellow_concrete
fill 235 65 558 235 68 558 minecraft:black_concrete
setblock 235 65 565 minecraft:yellow_concrete
fill 235 65 569 235 68 569 minecraft:black_concrete
fill 235 65 585 235 65 586 minecraft:yellow_concrete
setblock 235 65 589 minecraft:yellow_concrete
fill 235 65 590 235 68 590 minecraft:black_concrete
fill 237 65 599 237 68 599 minecraft:black_concrete
fill 238 65 557 238 68 557 minecraft:black_concrete
setblock 239 65 557 minecraft:yellow_concrete
fill 242 65 557 243 65 557 minecraft:yellow_concrete
setblock 242 65 599 minecraft:yellow_concrete
setblock 253 65 599 minecraft:yellow_concrete
fill 257 65 599 258 68 599 minecraft:black_concrete
fill 258 65 557 259 67 557 minecraft:black_concrete
setblock 263 65 557 minecraft:yellow_concrete
setblock 274 65 557 minecraft:yellow_concrete
setblock 274 65 599 minecraft:yellow_concrete
fill 277 65 559 277 67 559 minecraft:black_concrete
fill 277 65 570 277 68 570 minecraft:black_concrete
setblock 277 65 571 minecraft:yellow_concrete
fill 277 65 574 277 65 575 minecraft:yellow_concrete
fill 277 65 591 277 68 591 minecraft:black_concrete
setblock 277 65 595 minecraft:yellow_concrete
fill 235 66 557 235 71 557 minecraft:black_concrete
fill 235 66 563 235 67 564 minecraft:yellow_concrete
fill 235 66 565 235 71 566 minecraft:black_concrete
fill 235 66 575 235 66 576 minecraft:yellow_concrete
fill 235 66 577 235 71 578 minecraft:black_concrete
fill 235 66 584 235 67 584 minecraft:yellow_concrete
fill 235 66 585 235 71 586 minecraft:black_concrete
setblock 235 66 587 minecraft:yellow_concrete
fill 235 66 589 235 71 589 minecraft:black_concrete
fill 235 66 595 235 67 596 minecraft:yellow_concrete
fill 235 66 597 235 71 598 minecraft:black_concrete
fill 236 66 558 238 66 558 minecraft:orange_concrete
fill 236 66 560 236 66 562 minecraft:orange_concrete
fill 236 66 564 236 66 566 minecraft:orange_concrete
fill 236 66 568 236 66 570 minecraft:orange_concrete
fill 236 66 572 236 66 574 minecraft:orange_concrete
fill 236 66 576 236 66 578 minecraft:orange_concrete
fill 236 66 580 236 66 582 minecraft:orange_concrete
fill 236 66 584 236 66 586 minecraft:orange_concrete
fill 236 66 588 236 66 590 minecraft:orange_concrete
fill 236 66 592 236 66 594 minecraft:orange_concrete
fill 236 66 596 236 66 598 minecraft:orange_concrete
fill 238 66 598 240 66 598 minecraft:orange_concrete
fill 239 66 557 239 71 557 minecraft:black_concrete
fill 240 66 558 242 66 558 minecraft:orange_concrete
setblock 241 66 557 minecraft:yellow_concrete
fill 242 66 557 243 71 557 minecraft:black_concrete
fill 242 66 598 244 66 598 minecraft:orange_concrete
fill 242 66 599 242 71 599 minecraft:black_concrete
fill 243 66 599 244 66 599 minecraft:yellow_concrete
fill 244 66 557 244 67 557 minecraft:yellow_concrete
fill 244 66 558 246 66 558 minecraft:orange_concrete
fill 245 66 599 246 71 599 minecraft:black_concrete
fill 246 66 598 248 66 598 minecraft:orange_concrete
fill 248 66 558 250 66 558 minecraft:orange_concrete
fill 250 66 557 251 71 557 minecraft:black_concrete
fill 250 66 598 252 66 598 minecraft:orange_concrete
fill 251 66 599 252 67 599 minecraft:yellow_concrete
fill 252 66 557 253 66 557 minecraft:yellow_concrete
fill 252 66 558 254 66 558 minecraft:orange_concrete
fill 253 66 599 254 71 599 minecraft:black_concrete
fill 254 66 598 256 66 598 minecraft:orange_concrete
setblock 255 66 599 minecraft:yellow_concrete
fill 256 66 558 258 66 558 minecraft:orange_concrete
fill 258 66 598 260 66 598 minecraft:orange_concrete
fill 260 66 557 260 69 557 minecraft:black_concrete
fill 260 66 558 262 66 558 minecraft:orange_concrete
setblock 261 66 557 minecraft:yellow_concrete
fill 262 66 557 263 71 557 minecraft:black_concrete
fill 262 66 598 264 66 598 minecraft:orange_concrete
fill 263 66 599 264 67 599 minecraft:yellow_concrete
fill 264 66 557 265 67 557 minecraft:yellow_concrete
fill 264 66 558 266 66 558 minecraft:orange_concrete
fill 265 66 599 266 71 599 minecraft:black_concrete
fill 266 66 598 268 66 598 minecraft:orange_concrete
fill 268 66 558 270 66 558 minecraft:orange_concrete
fill 270 66 557 271 68 557 minecraft:black_concrete
fill 270 66 598 272 66 598 minecraft:orange_concrete
fill 272 66 557 273 66 557 minecraft:yellow_concrete
fill 272 66 558 274 66 558 minecraft:orange_concrete
fill 272 66 599 272 67 599 minecraft:yellow_concrete
fill 274 66 557 274 71 557 minecraft:black_concrete
fill 274 66 598 276 66 598 minecraft:orange_concrete
fill 274 66 599 274 71 599 minecraft:black_concrete
fill 275 66 599 276 66 599 minecraft:yellow_concrete
fill 276 66 557 276 67 557 minecraft:yellow_concrete
fill 276 66 558 276 66 560 minecraft:orange_concrete
fill 276 66 562 276 66 564 minecraft:orange_concrete
fill 276 66 566 276 66 568 minecraft:orange_concrete
fill 276 66 570 276 66 572 minecraft:orange_concrete
fill 276 66 574 276 66 576 minecraft:orange_concrete
fill 276 66 578 276 66 580 minecraft:orange_concrete
fill 276 66 582 276 66 584 minecraft:orange_concrete
fill 276 66 586 276 66 588 minecraft:orange_concrete
fill 276 66 590 276 66 592 minecraft:orange_concrete
fill 276 66 594 276 66 596 minecraft:orange_concrete
setblock 277 66 557 minecraft:black_concrete
fill 277 66 562 277 71 563 minecraft:black_concrete
fill 277 66 564 277 67 565 minecraft:yellow_concrete
fill 277 66 571 277 68 571 minecraft:black_concrete
setblock 277 66 573 minecraft:yellow_concrete
fill 277 66 574 277 71 575 minecraft:black_concrete
fill 277 66 576 277 67 576 minecraft:yellow_concrete
fill 277 66 582 277 71 583 minecraft:black_concrete
fill 277 66 584 277 66 585 minecraft:yellow_concrete
fill 277 66 594 277 71 595 minecraft:black_concrete
fill 277 66 596 277 67 597 minecraft:yellow_concrete
fill 277 66 599 277 71 599 minecraft:black_concrete
setblock 235 67 572 minecraft:yellow_concrete
setblock 235 67 575 minecraft:yellow_concrete
fill 235 67 576 235 70 576 minecraft:black_concrete
setblock 235 67 583 minecraft:yellow_concrete
fill 235 67 587 235 70 587 minecraft:black_concrete
fill 239 67 599 240 67 599 minecraft:yellow_concrete
fill 241 67 557 241 70 557 minecraft:black_concrete
setblock 243 67 599 minecraft:yellow_concrete
fill 244 67 599 244 70 599 minecraft:black_concrete
setblock 245 67 557 minecraft:yellow_concrete
fill 252 67 557 252 70 557 minecraft:black_concrete
setblock 253 67 557 minecraft:yellow_concrete
fill 255 67 599 255 70 599 minecraft:black_concrete
setblock 256 67 557 minecraft:yellow_concrete
setblock 260 67 599 minecraft:yellow_concrete
fill 261 67 557 261 69 557 minecraft:black_concrete
setblock 271 67 599 minecraft:yellow_concrete
fill 272 67 557 272 70 557 minecraft:black_concrete
setblock 273 67 557 minecraft:yellow_concrete
fill 275 67 599 276 70 599 minecraft:black_concrete
setblock 277 67 557 minecraft:yellow_concrete
setblock 277 67 568 minecraft:yellow_concrete
fill 277 67 569 277 69 569 minecraft:black_concrete
fill 277 67 573 277 70 573 minecraft:black_concrete
setblock 277 67 577 minecraft:yellow_concrete
fill 277 67 584 277 70 584 minecraft:black_concrete
setblock 277 67 585 minecraft:yellow_concrete
setblock 277 67 588 minecraft:yellow_concrete
fill 235 68 561 235 69 562 minecraft:yellow_concrete
fill 235 68 563 235 73 564 minecraft:black_concrete
fill 235 68 570 235 69 570 minecraft:yellow_concrete
fill 235 68 572 235 73 572 minecraft:black_concrete
fill 235 68 573 235 68 574 minecraft:yellow_concrete
fill 235 68 575 235 73 575 minecraft:black_concrete
fill 235 68 581 235 69 582 minecraft:yellow_concrete
fill 235 68 583 235 73 584 minecraft:black_concrete
fill 235 68 593 235 68 594 minecraft:yellow_concrete
fill 235 68 595 235 73 596 minecraft:black_concrete
fill 238 68 599 238 69 599 minecraft:yellow_concrete
fill 239 68 599 240 73 599 minecraft:black_concrete
fill 241 68 574 241 69 575 minecraft:orange_concrete
setblock 241 68 599 minecraft:yellow_concrete
fill 243 68 599 243 73 599 minecraft:black_concrete
fill 244 68 557 245 73 557 minecraft:black_concrete
fill 246 68 557 247 69 557 minecraft:yellow_concrete
fill 249 68 599 250 69 599 minecraft:yellow_concrete
fill 251 68 599 252 73 599 minecraft:black_concrete
fill 253 68 557 253 73 557 minecraft:black_concrete
fill 254 68 557 255 68 557 minecraft:yellow_concrete
fill 256 68 557 256 73 557 minecraft:black_concrete
fill 258 68 557 258 69 557 minecraft:yellow_concrete
setblock 259 68 557 minecraft:black_concrete
fill 260 68 599 260 73 599 minecraft:black_concrete
fill 261 68 599 262 68 599 minecraft:yellow_concrete
fill 263 68 599 264 73 599 minecraft:black_concrete
fill 264 68 557 265 73 557 minecraft:black_concrete
fill 266 68 557 267 69 557 minecraft:yellow_concrete
fill 269 68 599 270 69 599 minecraft:yellow_concrete
fill 271 68 599 272 73 599 minecraft:black_concrete
fill 273 68 557 273 70 557 minecraft:black_concrete
setblock 273 68 599 minecraft:yellow_concrete
setblock 275 68 557 minecraft:yellow_concrete
fill 276 68 557 277 73 557 minecraft:black_concrete
fill 277 68 558 277 69 559 minecraft:yellow_concrete
fill 277 68 564 277 73 565 minecraft:black_concrete
fill 277 68 566 277 68 567 minecraft:yellow_concrete
fill 277 68 568 277 69 568 minecraft:black_concrete
fill 277 68 576 277 73 577 minecraft:black_concrete
fill 277 68 578 277 69 579 minecraft:yellow_concrete
fill 277 68 585 277 73 585 minecraft:black_concrete
fill 277 68 586 277 68 587 minecraft:yellow_concrete
fill 277 68 588 277 73 588 minecraft:black_concrete
fill 277 68 590 277 69 590 minecraft:yellow_concrete
fill 277 68 596 277 73 597 minecraft:black_concrete
fill 277 68 598 277 69 598 minecraft:yellow_concrete
setblock 235 69 558 minecraft:yellow_concrete
setblock 235 69 569 minecraft:yellow_concrete
fill 235 69 573 235 72 574 minecraft:black_concrete
setblock 235 69 590 minecraft:yellow_concrete
setblock 235 69 593 minecraft:yellow_concrete
fill 235 69 594 235 72 594 minecraft:black_concrete
setblock 237 69 599 minecraft:yellow_concrete
setblock 238 69 557 minecraft:yellow_concrete
fill 241 69 599 241 72 599 minecraft:black_concrete
fill 253 69 594 255 70 594 minecraft:orange_concrete
fill 254 69 557 255 72 557 minecraft:black_concrete
fill 254 69 593 254 70 593 minecraft:orange_concrete
fill 254 69 595 255 70 595 minecraft:orange_concrete
fill 257 69 599 258 69 599 minecraft:yellow_concrete
setblock 259 69 557 minecraft:yellow_concrete
setblock 261 69 599 minecraft:yellow_concrete
fill 262 69 599 262 72 599 minecraft:black_concrete
setblock 270 69 557 minecraft:yellow_concrete
fill 271 69 557 271 71 557 minecraft:black_concrete
fill 273 69 599 273 72 599 minecraft:black_concrete
fill 275 69 557 275 72 557 minecraft:black_concrete
fill 277 69 566 277 72 566 minecraft:black_concrete
setblock 277 69 567 minecraft:yellow_concrete
fill 277 69 570 277 69 571 minecraft:yellow_concrete
fill 277 69 586 277 72 587 minecraft:black_concrete
setblock 277 69 591 minecraft:yellow_concrete
fill 235 70 558 235 75 558 minecraft:black_concrete
fill 235 70 559 235 70 560 minecraft:yellow_concrete
fill 235 70 561 235 75 562 minecraft:black_concrete
fill 235 70 567 235 71 568 minecraft:yellow_concrete
fill 235 70 569 235 75 570 minecraft:black_concrete
setblock 235 70 571 minecraft:yellow_concrete
fill 235 70 579 235 71 580 minecraft:yellow_concrete
fill 235 70 581 235 75 582 minecraft:black_concrete
fill 235 70 588 235 71 588 minecraft:yellow_concrete
fill 235 70 590 235 75 590 minecraft:black_concrete
fill 235 70 591 235 70 592 minecraft:yellow_concrete
fill 235 70 593 235 75 593 minecraft:black_concrete
fill 235 70 599 236 71 599 minecraft:yellow_concrete
fill 236 70 557 237 70 557 minecraft:yellow_concrete
fill 237 70 599 238 75 599 minecraft:black_concrete
fill 238 70 557 238 75 557 minecraft:black_concrete
fill 240 70 557 240 71 557 minecraft:yellow_concrete
fill 246 70 557 247 75 557 minecraft:black_concrete
fill 247 70 599 248 70 599 minecraft:yellow_concrete
fill 248 70 557 249 71 557 minecraft:yellow_concrete
fill 249 70 599 250 75 599 minecraft:black_concrete
fill 256 70 599 256 71 599 minecraft:yellow_concrete
setblock 257 70 557 minecraft:yellow_concrete
fill 257 70 599 258 75 599 minecraft:black_concrete
fill 258 70 557 259 75 557 minecraft:black_concrete
setblock 259 70 599 minecraft:yellow_concrete
fill 260 70 557 261 71 557 minecraft:yellow_concrete
fill 261 70 599 261 75 599 minecraft:black_concrete
fill 266 70 557 267 75 557 minecraft:black_concrete
fill 267 70 599 268 71 599 minecraft:yellow_concrete
fill 268 70 557 269 70 557 minecraft:yellow_concrete
fill 269 70 599 270 75 599 minecraft:black_concrete
fill 270 70 557 270 71 557 minecraft:black_concrete
fill 277 70 558 277 75 559 minecraft:black_concrete
fill 277 70 560 277 71 561 minecraft:yellow_concrete
fill 277 70 567 277 75 567 minecraft:black_concrete
fill 277 70 568 277 70 569 minecraft:yellow_concrete
fill 277 70 570 277 71 571 minecraft:black_concrete
fill 277 70 572 277 71 572 minecraft:yellow_concrete
fill 277 70 578 277 75 579 minecraft:black_concrete
fill 277 70 580 277 71 581 minecraft:yellow_concrete
setblock 277 70 589 minecraft:yellow_concrete
fill 277 70 590 277 75 591 minecraft:black_concrete
fill 277 70 592 277 71 593 minecraft:yellow_concrete
fill 277 70 598 277 75 598 minecraft:black_concrete
setblock 235 71 559 minecraft:yellow_concrete
fill 235 71 560 235 74 560 minecraft:black_concrete
fill 235 71 571 235 74 571 minecraft:black_concrete
setblock 235 71 576 minecraft:yellow_concrete
setblock 235 71 587 minecraft:yellow_concrete
fill 235 71 591 235 74 592 minecraft:black_concrete
fill 236 71 557 237 74 557 minecraft:black_concrete
setblock 238 71 560 minecraft:light[level=14]
setblock 238 71 568 minecraft:light[level=14]
setblock 238 71 576 minecraft:light[level=14]
setblock 238 71 584 minecraft:light[level=14]
setblock 238 71 592 minecraft:light[level=14]
setblock 241 71 557 minecraft:yellow_concrete
setblock 244 71 599 minecraft:yellow_concrete
setblock 246 71 560 minecraft:light[level=14]
setblock 246 71 568 minecraft:light[level=14]
setblock 246 71 576 minecraft:light[level=14]
setblock 246 71 584 minecraft:light[level=14]
setblock 246 71 592 minecraft:light[level=14]
setblock 247 71 599 minecraft:yellow_concrete
fill 248 71 599 248 74 599 minecraft:black_concrete
setblock 252 71 557 minecraft:yellow_concrete
setblock 254 71 560 minecraft:light[level=14]
setblock 254 71 568 minecraft:light[level=14]
setblock 254 71 576 minecraft:light[level=14]
setblock 254 71 584 minecraft:light[level=14]
setblock 254 71 592 minecraft:light[level=14]
setblock 255 71 599 minecraft:yellow_concrete
fill 257 71 557 257 74 557 minecraft:black_concrete
fill 259 71 599 259 74 599 minecraft:black_concrete
setblock 262 71 560 minecraft:light[level=14]
setblock 262 71 568 minecraft:light[level=14]
setblock 262 71 576 minecraft:light[level=14]
setblock 262 71 584 minecraft:light[level=14]
setblock 262 71 592 minecraft:light[level=14]
fill 268 71 557 268 74 557 minecraft:black_concrete
setblock 269 71 557 minecraft:yellow_concrete
setblock 270 71 560 minecraft:light[level=14]
setblock 270 71 568 minecraft:light[level=14]
setblock 270 71 576 minecraft:light[level=14]
setblock 270 71 584 minecraft:light[level=14]
setblock 270 71 592 minecraft:light[level=14]
fill 272 71 557 273 71 557 minecraft:yellow_concrete
fill 275 71 599 276 71 599 minecraft:yellow_concrete
fill 277 71 568 277 73 569 minecraft:black_concrete
setblock 277 71 573 minecraft:yellow_concrete
setblock 277 71 584 minecraft:yellow_concrete
fill 277 71 589 277 74 589 minecraft:black_concrete
setblock 235 72 557 minecraft:yellow_concrete
fill 235 72 559 235 77 559 minecraft:black_concrete
fill 235 72 565 235 73 566 minecraft:yellow_concrete
fill 235 72 567 235 77 568 minecraft:black_concrete
fill 235 72 576 235 77 576 minecraft:black_concrete
fill 235 72 577 235 72 578 minecraft:yellow_concrete
fill 235 72 579 235 77 580 minecraft:black_concrete
fill 235 72 585 235 73 586 minecraft:yellow_concrete
fill 235 72 587 235 77 588 minecraft:black_concrete
setblock 235 72 589 minecraft:yellow_concrete
fill 235 72 597 235 73 598 minecraft:yellow_concrete
fill 235 72 599 236 77 599 minecraft:black_concrete
fill 236 72 558 238 72 558 minecraft:orange_concrete
fill 236 72 560 236 72 562 minecraft:orange_concrete
fill 236 72 564 236 72 566 minecraft:orange_concrete
fill 236 72 568 236 72 570 minecraft:orange_concrete
fill 236 72 572 236 72 574 minecraft:orange_concrete
fill 236 72 576 236 72 578 minecraft:orange_concrete
fill 236 72 580 236 72 582 minecraft:orange_concrete
fill 236 72 584 236 72 586 minecraft:orange_concrete
fill 236 72 588 236 72 590 minecraft:orange_concrete
fill 236 72 592 236 72 594 minecraft:orange_concrete
fill 236 72 596 236 72 598 minecraft:orange_concrete
fill 238 72 598 240 72 598 minecraft:orange_concrete
setblock 239 72 557 minecraft:yellow_concrete
fill 240 72 557 241 77 557 minecraft:black_concrete
fill 240 72 558 242 72 558 minecraft:orange_concrete
fill 242 72 557 243 73 557 minecraft:yellow_concrete
fill 242 72 598 244 72 598 minecraft:orange_concrete
fill 242 72 599 242 73 599 minecraft:yellow_concrete
fill 244 72 558 246 72 558 minecraft:orange_concrete
fill 244 72 599 244 77 599 minecraft:black_concrete
fill 245 72 599 246 72 599 minecraft:yellow_concrete
fill 246 72 598 248 72 598 minecraft:orange_concrete
fill 247 72 599 247 77 599 minecraft:black_concrete
fill 248 72 557 249 77 557 minecraft:black_concrete
fill 248 72 558 250 72 558 minecraft:orange_concrete
fill 250 72 557 251 72 557 minecraft:yellow_concrete
fill 250 72 598 252 72 598 minecraft:orange_concrete
fill 252 72 557 252 77 557 minecraft:black_concrete
fill 252 72 558 254 72 558 minecraft:orange_concrete
fill 253 72 599 254 73 599 minecraft:yellow_concrete
fill 254 72 598 256 72 598 minecraft:orange_concrete
fill 255 72 599 256 77 599 minecraft:black_concrete
fill 256 72 558 258 72 558 minecraft:orange_concrete
fill 258 72 598 260 72 598 minecraft:orange_concrete
fill 260 72 557 261 77 557 minecraft:black_concrete
fill 260 72 558 262 72 558 minecraft:orange_concrete
fill 262 72 557 263 73 557 minecraft:yellow_concrete
fill 262 72 598 264 72 598 minecraft:orange_concrete
fill 264 72 558 266 72 558 minecraft:orange_concrete
fill 265 72 599 266 72 599 minecraft:yellow_concrete
fill 266 72 598 268 72 598 minecraft:orange_concrete
fill 267 72 599 268 77 599 minecraft:black_concrete
fill 268 72 558 270 72 558 minecraft:orange_concrete
fill 269 72 557 269 77 557 minecraft:black_concrete
fill 270 72 557 271 72 557 minecraft:yellow_concrete
fill 270 72 598 272 72 598 minecraft:orange_concrete
fill 272 72 557 273 73 557 minecraft:black_concrete
fill 272 72 558 274 72 558 minecraft:orange_concrete
fill 274 72 557 274 73 557 minecraft:yellow_concrete
fill 274 72 598 276 72 598 minecraft:orange_concrete
fill 274 72 599 274 73 599 minecraft:yellow_concrete
fill 275 72 599 276 77 599 minecraft:black_concrete
fill 276 72 558 276 72 560 minecraft:orange_concrete
fill 276 72 562 276 72 564 minecraft:orange_concrete
fill 276 72 566 276 72 568 minecraft:orange_concrete
fill 276 72 570 276 72 572 minecraft:orange_concrete
fill 276 72 574 276 72 576 minecraft:orange_concrete
fill 276 72 578 276 72 580 minecraft:orange_concrete
fill 276 72 582 276 72 584 minecraft:orange_concrete
fill 276 72 586 276 72 588 minecraft:orange_concrete
fill 276 72 590 276 72 592 minecraft:orange_concrete
fill 276 72 594 276 72 596 minecraft:orange_concrete
fill 277 72 560 277 77 561 minecraft:black_concrete
fill 277 72 562 277 73 563 minecraft:yellow_concrete
fill 277 72 570 277 75 570 minecraft:black_concrete
setblock 277 72 571 minecraft:yellow_concrete
fill 277 72 572 277 77 573 minecraft:black_concrete
fill 277 72 574 277 73 575 minecraft:yellow_concrete
fill 277 72 580 277 74 581 minecraft:black_concrete
fill 277 72 582 277 72 583 minecraft:yellow_concrete
fill 277 72 584 277 77 584 minecraft:black_concrete
fill 277 72 592 277 77 593 minecraft:black_concrete
fill 277 72 594 277 73 595 minecraft:yellow_concrete
setblock 277 72 599 minecraft:yellow_concrete
fill 235 73 557 235 76 557 minecraft:black_concrete
fill 235 73 573 235 73 574 minecraft:yellow_concrete
setblock 235 73 577 minecraft:yellow_concrete
fill 235 73 578 235 76 578 minecraft:black_concrete
fill 235 73 589 235 76 589 minecraft:black_concrete
setblock 235 73 594 minecraft:yellow_concrete
fill 239 73 557 239 76 557 minecraft:black_concrete
setblock 241 73 599 minecraft:yellow_concrete
fill 245 73 599 246 76 599 minecraft:black_concrete
fill 250 73 557 250 76 557 minecraft:black_concrete
setblock 251 73 557 minecraft:yellow_concrete
fill 254 73 557 255 73 557 minecraft:yellow_concrete
setblock 262 73 599 minecraft:yellow_concrete
setblock 265 73 599 minecraft:yellow_concrete
fill 266 73 599 266 76 599 minecraft:black_concrete
fill 270 73 557 271 75 557 minecraft:black_concrete
setblock 273 73 599 minecraft:yellow_concrete
setblock 275 73 557 minecraft:yellow_concrete
setblock 277 73 566 minecraft:yellow_concrete
fill 277 73 571 277 75 571 minecraft:black_concrete
fill 277 73 582 277 76 582 minecraft:black_concrete
setblock 277 73 583 minecraft:yellow_concrete
fill 277 73 586 277 73 587 minecraft:yellow_concrete
fill 277 73 599 277 76 599 minecraft:black_concrete
fill 235 74 563 235 74 564 minecraft:yellow_concrete
fill 235 74 565 235 79 566 minecraft:black_concrete
fill 235 74 572 235 75 572 minecraft:yellow_concrete
fill 235 74 573 235 79 574 minecraft:black_concrete
setblock 235 74 575 minecraft:yellow_concrete
fill 235 74 577 235 79 577 minecraft:black_concrete
fill 235 74 583 235 75 584 minecraft:yellow_concrete
fill 235 74 585 235 79 586 minecraft:black_concrete
fill 235 74 594 235 79 594 minecraft:black_concrete
fill 235 74 595 235 74 596 minecraft:yellow_concrete
fill 235 74 597 235 79 598 minecraft:black_concrete
fill 239 74 599 240 75 599 minecraft:yellow_concrete
fill 241 74 599 242 79 599 minecraft:black_concrete
fill 242 74 557 243 79 557 minecraft:black_concrete
setblock 243 74 599 minecraft:yellow_concrete
fill 244 74 557 245 75 557 minecraft:yellow_concrete
fill 246 74 576 246 75 577 minecraft:red_concrete
fill 251 74 557 251 79 557 minecraft:black_concrete
fill 251 74 599 252 75 599 minecraft:yellow_concrete
setblock 253 74 557 minecraft:yellow_concrete
fill 253 74 599 254 79 599 minecraft:black_concrete
fill 254 74 557 255 79 557 minecraft:black_concrete
fill 256 74 557 256 75 557 minecraft:yellow_concrete
fill 260 74 599 260 75 599 minecraft:yellow_concrete
fill 262 74 557 263 79 557 minecraft:black_concrete
fill 262 74 599 262 79 599 minecraft:black_concrete
fill 263 74 599 264 74 599 minecraft:yellow_concrete
fill 264 74 557 265 74 557 minecraft:yellow_concrete
fill 265 74 599 265 79 599 minecraft:black_concrete
fill 271 74 599 272 75 599 minecraft:yellow_concrete
fill 272 74 557 272 77 557 minecraft:black_concrete
setblock 273 74 557 minecraft:yellow_concrete
fill 273 74 599 274 79 599 minecraft:black_concrete
fill 274 74 557 275 79 557 minecraft:black_concrete
fill 276 74 557 277 75 557 minecraft:yellow_concrete
fill 277 74 562 277 76 563 minecraft:black_concrete
fill 277 74 564 277 74 565 minecraft:yellow_concrete
fill 277 74 566 277 79 566 minecraft:black_concrete
fill 277 74 568 277 75 568 minecraft:yellow_concrete
setblock 277 74 569 minecraft:black_concrete
fill 277 74 574 277 79 575 minecraft:black_concrete
fill 277 74 576 277 75 577 minecraft:yellow_concrete
fill 277 74 583 277 76 583 minecraft:black_concrete
setblock 277 74 585 minecraft:yellow_concrete
fill 277 74 586 277 79 587 minecraft:black_concrete
fill 277 74 588 277 75 588 minecraft:yellow_concrete
fill 277 74 594 277 79 595 minecraft:black_concrete
fill 277 74 596 277 74 597 minecraft:yellow_concrete
setblock 235 75 560 minecraft:yellow_concrete
setblock 235 75 563 minecraft:yellow_concrete
fill 235 75 564 235 78 564 minecraft:black_concrete
setblock 235 75 571 minecraft:yellow_concrete
fill 235 75 575 235 78 575 minecraft:black_concrete
fill 235 75 591 235 75 592 minecraft:yellow_concrete
setblock 235 75 595 minecraft:yellow_concrete
fill 235 75 596 235 78 596 minecraft:black_concrete
fill 236 75 557 237 75 557 minecraft:yellow_concrete
fill 243 75 599 243 78 599 minecraft:black_concrete
setblock 248 75 599 minecraft:yellow_concrete
fill 253 75 557 253 78 557 minecraft:black_concrete
setblock 257 75 557 minecraft:yellow_concrete
setblock 259 75 599 minecraft:yellow_concrete
fill 263 75 599 264 78 599 minecraft:black_concrete
fill 264 75 557 264 78 557 minecraft:black_concrete
setblock 265 75 557 minecraft:yellow_concrete
setblock 268 75 557 minecraft:yellow_concrete
fill 273 75 557 273 77 557 minecraft:black_concrete
fill 277 75 564 277 78 564 minecraft:black_concrete
setblock 277 75 565 minecraft:yellow_concrete
setblock 277 75 569 minecraft:yellow_concrete
setblock 277 75 580 minecraft:yellow_concrete
fill 277 75 581 277 77 581 minecraft:black_concrete
fill 277 75 585 277 78 585 minecraft:black_concrete
setblock 277 75 589 minecraft:yellow_concrete
fill 277 75 596 277 78 596 minecraft:black_concrete
setblock 277 75 597 minecraft:yellow_concrete
fill 235 76 558 235 77 558 minecraft:yellow_concrete
fill 235 76 560 235 81 560 minecraft:black_concrete
fill 235 76 561 235 76 562 minecraft:yellow_concrete
fill 235 76 563 235 81 563 minecraft:black_concrete
fill 235 76 569 235 77 570 minecraft:yellow_concrete
fill 235 76 571 235 81 572 minecraft:black_concrete
fill 235 76 581 235 76 582 minecraft:yellow_concrete
fill 235 76 583 235 81 584 minecraft:black_concrete
fill 235 76 590 235 77 590 minecraft:yellow_concrete
fill 235 76 591 235 81 592 minecraft:black_concrete
setblock 235 76 593 minecraft:yellow_concrete
fill 235 76 595 235 81 595 minecraft:black_concrete
fill 236 76 557 237 81 557 minecraft:black_concrete
fill 237 76 599 238 77 599 minecraft:yellow_concrete
fill 238 76 557 238 77 557 minecraft:yellow_concrete
fill 239 76 599 240 81 599 minecraft:black_concrete
fill 244 76 557 245 81 557 minecraft:black_concrete
fill 246 76 557 247 76 557 minecraft:yellow_concrete
fill 246 76 583 248 77 584 minecraft:yellow_concrete
fill 248 76 599 248 81 599 minecraft:black_concrete
fill 249 76 599 250 76 599 minecraft:yellow_concrete
fill 251 76 558 251 76 563 minecraft:magma_block
fill 251 76 599 252 81 599 minecraft:black_concrete
fill 256 76 557 257 81 557 minecraft:black_concrete
fill 257 76 599 258 77 599 minecraft:yellow_concrete
fill 258 76 557 259 77 557 minecraft:yellow_concrete
fill 259 76 599 260 81 599 minecraft:black_concrete
setblock 261 76 599 minecraft:yellow_concrete
fill 265 76 557 265 81 557 minecraft:black_concrete
fill 266 76 557 267 76 557 minecraft:yellow_concrete
fill 268 76 557 268 81 557 minecraft:black_concrete
fill 269 76 599 270 77 599 minecraft:yellow_concrete
fill 270 76 557 270 77 557 minecraft:yellow_concrete
setblock 271 76 557 minecraft:black_concrete
fill 271 76 599 272 81 599 minecraft:black_concrete
fill 276 76 557 277 81 557 minecraft:black_concrete
fill 277 76 558 277 77 559 minecraft:yellow_concrete
fill 277 76 565 277 78 565 minecraft:black_concrete
setblock 277 76 567 minecraft:yellow_concrete
fill 277 76 568 277 81 569 minecraft:black_concrete
fill 277 76 570 277 77 571 minecraft:yellow_concrete
fill 277 76 576 277 81 577 minecraft:black_concrete
fill 277 76 578 277 76 579 minecraft:yellow_concrete
fill 277 76 580 277 77 580 minecraft:black_concrete
fill 277 76 588 277 81 589 minecraft:black_concrete
fill 277 76 590 277 77 591 minecraft:yellow_concrete
fill 277 76 597 277 81 597 minecraft:black_concrete
setblock 277 76 598 minecraft:yellow_concrete
setblock 235 77 557 minecraft:yellow_concrete
fill 235 77 561 235 80 562 minecraft:black_concrete
setblock 235 77 578 minecraft:yellow_concrete
setblock 235 77 581 minecraft:yellow_concrete
fill 235 77 582 235 80 582 minecraft:black_concrete
setblock 235 77 589 minecraft:yellow_concrete
fill 235 77 593 235 80 593 minecraft:black_concrete
setblock 239 77 557 minecraft:yellow_concrete
fill 245 77 599 246 77 599 minecraft:yellow_concrete
fill 246 77 557 246 80 557 minecraft:black_concrete
setblock 247 77 557 minecraft:yellow_concrete
setblock 249 77 599 minecraft:yellow_concrete
setblock 250 77 557 minecraft:yellow_concrete
fill 250 77 558 252 77 560 minecraft:magma_block
fill 250 77 599 250 80 599 minecraft:black_concrete
fill 251 77 561 251 77 562 minecraft:magma_block
fill 261 77 599 261 80 599 minecraft:black_concrete
fill 266 77 557 267 80 557 minecraft:black_concrete
setblock 266 77 599 minecraft:yellow_concrete
setblock 271 77 557 minecraft:yellow_concrete
setblock 277 77 562 minecraft:yellow_concrete
fill 277 77 563 277 79 563 minecraft:black_concrete
fill 277 77 567 277 80 567 minecraft:black_concrete
fill 277 77 578 277 80 578 minecraft:black_concrete
setblock 277 77 579 minecraft:yellow_concrete
fill 277 77 582 277 77 583 minecraft:yellow_concrete
fill 277 77 598 277 80 598 minecraft:black_concrete
setblock 277 77 599 minecraft:yellow_concrete
fill 235 78 557 235 83 558 minecraft:black_concrete
setblock 235 78 559 minecraft:yellow_concrete
fill 235 78 567 235 79 568 minecraft:yellow_concrete
fill 235 78 569 235 83 570 minecraft:black_concrete
fill 235 78 576 235 79 576 minecraft:yellow_concrete
fill 235 78 578 235 83 578 minecraft:black_concrete
fill 235 78 579 235 78 580 minecraft:yellow_concrete
fill 235 78 581 235 83 581 minecraft:black_concrete
fill 235 78 587 235 79 588 minecraft:yellow_concrete
fill 235 78 589 235 83 590 minecraft:black_concrete
fill 235 78 599 236 78 599 minecraft:yellow_concrete
fill 236 78 558 238 78 558 minecraft:orange_concrete
fill 236 78 560 236 78 562 minecraft:orange_concrete
fill 236 78 564 236 78 566 minecraft:orange_concrete
fill 236 78 568 236 78 570 minecraft:orange_concrete
fill 236 78 572 236 78 574 minecraft:orange_concrete
fill 236 78 576 236 78 578 minecraft:orange_concrete
fill 236 78 580 236 78 582 minecraft:orange_concrete
fill 236 78 584 236 78 586 minecraft:orange_concrete
fill 236 78 588 236 78 590 minecraft:orange_concrete
fill 236 78 592 236 78 594 minecraft:orange_concrete
fill 236 78 596 236 78 598 minecraft:orange_concrete
fill 237 78 599 238 83 599 minecraft:black_concrete
fill 238 78 557 239 83 557 minecraft:black_concrete
fill 238 78 598 240 78 598 minecraft:orange_concrete
fill 240 78 557 241 79 557 minecraft:yellow_concrete
fill 240 78 558 242 78 558 minecraft:orange_concrete
fill 242 78 598 244 78 598 minecraft:orange_concrete
fill 244 78 558 246 78 558 minecraft:orange_concrete
fill 244 78 599 244 79 599 minecraft:yellow_concrete
fill 245 78 599 246 83 599 minecraft:black_concrete
fill 246 78 598 248 78 598 minecraft:orange_concrete
fill 247 78 557 247 83 557 minecraft:black_concrete
setblock 247 78 599 minecraft:yellow_concrete
fill 248 78 557 249 78 557 minecraft:yellow_concrete
fill 248 78 558 250 78 558 minecraft:orange_concrete
fill 249 78 599 249 83 599 minecraft:black_concrete
fill 250 78 557 250 83 557 minecraft:black_concrete
fill 250 78 559 252 78 559 minecraft:magma_block
fill 250 78 598 252 78 598 minecraft:orange_concrete
fill 251 78 558 251 79 558 minecraft:magma_block
setblock 251 78 560 minecraft:magma_block
fill 252 78 557 252 79 557 minecraft:yellow_concrete
fill 252 78 558 254 78 558 minecraft:orange_concrete
fill 253 78 567 254 79 568 minecraft:shroomlight
fill 254 78 569 254 79 569 minecraft:shroomlight
fill 254 78 598 256 78 598 minecraft:orange_concrete
fill 255 78 599 256 79 599 minecraft:yellow_concrete
fill 256 78 558 258 78 558 minecraft:orange_concrete
fill 257 78 599 258 83 599 minecraft:black_concrete
fill 258 78 557 259 83 557 minecraft:black_concrete
fill 258 78 598 260 78 598 minecraft:orange_concrete
fill 260 78 557 261 79 557 minecraft:yellow_concrete
fill 260 78 558 262 78 558 minecraft:orange_concrete
fill 262 78 598 264 78 598 minecraft:orange_concrete
fill 264 78 558 266 78 558 minecraft:orange_concrete
fill 266 78 598 268 78 598 minecraft:orange_concrete
fill 266 78 599 266 83 599 minecraft:black_concrete
fill 267 78 599 268 78 599 minecraft:yellow_concrete
fill 268 78 558 270 78 558 minecraft:orange_concrete
setblock 269 78 557 minecraft:yellow_concrete
fill 269 78 599 270 83 599 minecraft:black_concrete
fill 270 78 557 271 83 557 minecraft:black_concrete
fill 270 78 598 272 78 598 minecraft:orange_concrete
fill 272 78 557 273 79 557 minecraft:yellow_concrete
fill 272 78 558 274 78 558 minecraft:orange_concrete
fill 274 78 598 276 78 598 minecraft:orange_concrete
fill 275 78 599 276 79 599 minecraft:yellow_concrete
fill 276 78 558 276 78 560 minecraft:orange_concrete
fill 276 78 562 276 78 564 minecraft:orange_concrete
fill 276 78 566 276 78 568 minecraft:orange_concrete
fill 276 78 570 276 78 572 minecraft:orange_concrete
fill 276 78 574 276 78 576 minecraft:orange_concrete
fill 276 78 578 276 78 580 minecraft:orange_concrete
fill 276 78 582 276 78 584 minecraft:orange_concrete
fill 276 78 586 276 78 588 minecraft:orange_concrete
fill 276 78 590 276 78 592 minecraft:orange_concrete
fill 276 78 594 276 78 596 minecraft:orange_concrete
fill 277 78 558 277 83 559 minecraft:black_concrete
fill 277 78 560 277 78 561 minecraft:yellow_concrete
fill 277 78 562 277 79 562 minecraft:black_concrete
fill 277 78 570 277 83 571 minecraft:black_concrete
fill 277 78 572 277 79 573 minecraft:yellow_concrete
fill 277 78 579 277 83 579 minecraft:black_concrete
fill 277 78 580 277 78 581 minecraft:yellow_concrete
fill 277 78 582 277 79 583 minecraft:black_concrete
fill 277 78 584 277 79 584 minecraft:yellow_concrete
fill 277 78 590 277 83 591 minecraft:black_concrete
fill 277 78 592 277 79 593 minecraft:yellow_concrete
fill 277 78 599 277 83 599 minecraft:black_concrete
fill 235 79 559 235 82 559 minecraft:black_concrete
setblock 235 79 564 minecraft:yellow_concrete
setblock 235 79 575 minecraft:yellow_concrete
fill 235 79 579 235 82 580 minecraft:black_concrete
setblock 235 79 596 minecraft:yellow_concrete
setblock 235 79 599 minecraft:yellow_concrete
fill 236 79 599 236 82 599 minecraft:black_concrete
setblock 238 79 560 minecraft:light[level=14]
setblock 238 79 568 minecraft:light[level=14]
setblock 238 79 576 minecraft:light[level=14]
setblock 238 79 584 minecraft:light[level=14]
setblock 238 79 592 minecraft:light[level=14]
setblock 243 79 599 minecraft:yellow_concrete
setblock 246 79 560 minecraft:light[level=14]
setblock 246 79 568 minecraft:light[level=14]
setblock 246 79 576 minecraft:light[level=14]
setblock 246 79 584 minecraft:light[level=14]
setblock 246 79 592 minecraft:light[level=14]
fill 247 79 599 247 82 599 minecraft:black_concrete
fill 248 79 557 249 82 557 minecraft:black_concrete
setblock 253 79 557 minecraft:yellow_concrete
setblock 254 79 560 minecraft:light[level=14]
setblock 254 79 576 minecraft:light[level=14]
setblock 254 79 584 minecraft:light[level=14]
setblock 254 79 592 minecraft:light[level=14]
setblock 262 79 560 minecraft:light[level=14]
setblock 262 79 568 minecraft:light[level=14]
setblock 262 79 576 minecraft:light[level=14]
setblock 262 79 584 minecraft:light[level=14]
setblock 262 79 592 minecraft:light[level=14]
fill 263 79 599 264 79 599 minecraft:yellow_concrete
setblock 264 79 557 minecraft:yellow_concrete
setblock 267 79 599 minecraft:yellow_concrete
fill 268 79 599 268 82 599 minecraft:black_concrete
fill 269 79 557 269 82 557 minecraft:black_concrete
setblock 270 79 560 minecraft:light[level=14]
setblock 270 79 568 minecraft:light[level=14]
setblock 270 79 576 minecraft:light[level=14]
setblock 270 79 584 minecraft:light[level=14]
setblock 270 79 592 minecraft:light[level=14]
fill 277 79 560 277 82 560 minecraft:black_concrete
setblock 277 79 561 minecraft:yellow_concrete
fill 277 79 564 277 79 565 minecraft:yellow_concrete
fill 277 79 580 277 81 581 minecraft:black_concrete
setblock 277 79 585 minecraft:yellow_concrete
setblock 277 79 596 minecraft:yellow_concrete
fill 235 80 564 235 85 564 minecraft:black_concrete
fill 235 80 565 235 80 566 minecraft:yellow_concrete
fill 235 80 567 235 85 568 minecraft:black_concrete
fill 235 80 573 235 81 574 minecraft:yellow_concrete
fill 235 80 575 235 85 576 minecraft:black_concrete
setblock 235 80 577 minecraft:yellow_concrete
fill 235 80 585 235 81 586 minecraft:yellow_concrete
fill 235 80 587 235 85 588 minecraft:black_concrete
fill 235 80 594 235 81 594 minecraft:yellow_concrete
fill 235 80 596 235 85 596 minecraft:black_concrete
fill 235 80 597 235 80 598 minecraft:yellow_concrete
fill 235 80 599 235 85 599 minecraft:black_concrete
fill 240 80 557 241 85 557 minecraft:black_concrete
fill 241 80 599 242 81 599 minecraft:yellow_concrete
fill 242 80 557 243 81 557 minecraft:yellow_concrete
fill 243 80 599 244 85 599 minecraft:black_concrete
setblock 251 80 557 minecraft:yellow_concrete
fill 252 80 557 253 85 557 minecraft:black_concrete
fill 253 80 599 254 80 599 minecraft:yellow_concrete
fill 254 80 557 255 81 557 minecraft:yellow_concrete
fill 255 80 599 256 85 599 minecraft:black_concrete
fill 260 80 557 261 85 557 minecraft:black_concrete
fill 262 80 557 263 80 557 minecraft:yellow_concrete
fill 262 80 599 262 81 599 minecraft:yellow_concrete
fill 263 80 568 263 81 568 minecraft:orange_concrete
fill 263 80 599 264 85 599 minecraft:black_concrete
fill 264 80 557 264 85 557 minecraft:black_concrete
setblock 265 80 599 minecraft:yellow_concrete
fill 267 80 599 267 85 599 minecraft:black_concrete
fill 272 80 557 273 85 557 minecraft:black_concrete
fill 273 80 599 274 81 599 minecraft:yellow_concrete
fill 274 80 557 275 81 557 minecraft:yellow_concrete
fill 275 80 599 276 85 599 minecraft:black_concrete
fill 277 80 561 277 85 561 minecraft:black_concrete
fill 277 80 562 277 80 563 minecraft:yellow_concrete
fill 277 80 564 277 81 565 minecraft:black_concrete
fill 277 80 566 277 81 566 minecraft:yellow_concrete
fill 277 80 572 277 85 573 minecraft:black_concrete
fill 277 80 574 277 81 575 minecraft:yellow_concrete
fill 277 80 582 277 83 582 minecraft:black_concrete
setblock 277 80 583 minecraft:yellow_concrete
fill 277 80 584 277 85 585 minecraft:black_concrete
fill 277 80 586 277 81 587 minecraft:yellow_concrete
fill 277 80 592 277 82 593 minecraft:black_concrete
fill 277 80 594 277 80 595 minecraft:yellow_concrete
fill 277 80 596 277 85 596 minecraft:black_concrete
fill 235 81 561 235 81 562 minecraft:yellow_concrete
setblock 235 81 565 minecraft:yellow_concrete
fill 235 81 566 235 84 566 minecraft:black_concrete
fill 235 81 577 235 84 577 minecraft:black_concrete
setblock 235 81 582 minecraft:yellow_concrete
setblock 235 81 593 minecraft:yellow_concrete
fill 235 81 597 235 84 598 minecraft:black_concrete
setblock 246 81 557 minecraft:yellow_concrete
setblock 250 81 599 minecraft:yellow_concrete
fill 251 81 557 251 84 557 minecraft:black_concrete
setblock 253 81 599 minecraft:yellow_concrete
fill 254 81 599 254 84 599 minecraft:black_concrete
setblock 261 81 599 minecraft:yellow_concrete
fill 262 81 557 262 84 557 minecraft:black_concrete
setblock 263 81 557 minecraft:yellow_concrete
fill 265 81 599 265 84 599 minecraft:black_concrete
fill 266 81 557 267 81 557 minecraft:yellow_concrete
fill 277 81 562 277 83 563 minecraft:black_concrete
setblock 277 81 567 minecraft:yellow_concrete
setblock 277 81 578 minecraft:yellow_concrete
fill 277 81 583 277 83 583 minecraft:black_concrete
fill 277 81 594 277 84 594 minecraft:black_concrete
setblock 277 81 595 minecraft:yellow_concrete
setblock 277 81 598 minecraft:yellow_concrete
fill 235 82 560 235 83 560 minecraft:yellow_concrete
fill 235 82 561 235 87 562 minecraft:black_concrete
setblock 235 82 563 minecraft:yellow_concrete
fill 235 82 565 235 87 565 minecraft:black_concrete
fill 235 82 571 235 83 572 minecraft:yellow_concrete
fill 235 82 573 235 87 574 minecraft:black_concrete
fill 235 82 582 235 87 582 minecraft:black_concrete
fill 235 82 583 235 82 584 minecraft:yellow_concrete
fill 235 82 585 235 87 586 minecraft:black_concrete
fill 235 82 591 235 83 592 minecraft:yellow_concrete
fill 235 82 593 235 87 594 minecraft:black_concrete
setblock 235 82 595 minecraft:yellow_concrete
fill 236 82 557 237 83 557 minecraft:yellow_concrete
fill 239 82 599 240 83 599 minecraft:yellow_concrete
fill 241 82 599 242 87 599 minecraft:black_concrete
fill 242 82 557 243 87 557 minecraft:black_concrete
fill 244 82 557 245 82 557 minecraft:yellow_concrete
fill 246 82 557 246 87 557 minecraft:black_concrete
fill 248 82 599 248 83 599 minecraft:yellow_concrete
fill 250 82 599 250 87 599 minecraft:black_concrete
fill 251 82 599 252 82 599 minecraft:yellow_concrete
fill 252 82 565 252 83 565 minecraft:red_concrete
fill 253 82 599 253 87 599 minecraft:black_concrete
fill 254 82 557 255 87 557 minecraft:black_concrete
fill 256 82 557 257 83 557 minecraft:yellow_concrete
fill 259 82 599 260 83 599 minecraft:yellow_concrete
fill 261 82 599 262 87 599 minecraft:black_concrete
fill 263 82 557 263 87 557 minecraft:black_concrete
setblock 265 82 557 minecraft:yellow_concrete
fill 266 82 557 267 87 557 minecraft:black_concrete
fill 268 82 557 268 83 557 minecraft:yellow_concrete
fill 271 82 599 272 82 599 minecraft:yellow_concrete
fill 273 82 599 274 87 599 minecraft:black_concrete
fill 274 82 557 275 87 557 minecraft:black_concrete
fill 276 82 557 277 82 557 minecraft:yellow_concrete
fill 277 82 564 277 85 564 minecraft:black_concrete
setblock 277 82 565 minecraft:yellow_concrete
fill 277 82 566 277 87 567 minecraft:black_concrete
fill 277 82 568 277 83 569 minecraft:yellow_concrete
fill 277 82 574 277 84 575 minecraft:black_concrete
fill 277 82 576 277 82 577 minecraft:yellow_concrete
fill 277 82 578 277 87 578 minecraft:black_concrete
fill 277 82 580 277 83 580 minecraft:yellow_concrete
setblock 277 82 581 minecraft:black_concrete
fill 277 82 586 277 87 587 minecraft:black_concrete
fill 277 82 588 277 83 589 minecraft:yellow_concrete
fill 277 82 595 277 84 595 minecraft:black_concrete
setblock 277 82 597 minecraft:yellow_concrete
fill 277 82 598 277 87 598 minecraft:black_concrete
setblock 235 83 559 minecraft:yellow_concrete
fill 235 83 563 235 86 563 minecraft:black_concrete
fill 235 83 579 235 83 580 minecraft:yellow_concrete
setblock 235 83 583 minecraft:yellow_concrete
fill 235 83 584 235 86 584 minecraft:black_concrete
fill 235 83 595 235 86 595 minecraft:black_concrete
setblock 236 83 599 minecraft:yellow_concrete
fill 244 83 557 244 86 557 minecraft:black_concrete
setblock 245 83 557 minecraft:yellow_concrete
setblock 247 83 599 minecraft:yellow_concrete
fill 248 83 557 249 83 557 minecraft:yellow_concrete
fill 251 83 599 252 86 599 minecraft:black_concrete
fill 265 83 557 265 86 557 minecraft:black_concrete
setblock 268 83 599 minecraft:yellow_concrete
setblock 269 83 557 minecraft:yellow_concrete
setblock 271 83 599 minecraft:yellow_concrete
fill 272 83 599 272 86 599 minecraft:black_concrete
fill 276 83 557 276 86 557 minecraft:black_concrete
setblock 277 83 557 minecraft:yellow_concrete
setblock 277 83 560 minecraft:yellow_concrete
fill 277 83 565 277 85 565 minecraft:black_concrete
fill 277 83 576 277 86 576 minecraft:black_concrete
setblock 277 83 577 minecraft:yellow_concrete
setblock 277 83 581 minecraft:yellow_concrete
setblock 277 83 592 minecraft:yellow_concrete
fill 277 83 593 277 85 593 minecraft:black_concrete
fill 277 83 597 277 86 597 minecraft:black_concrete
fill 235 84 557 235 85 558 minecraft:yellow_concrete
fill 235 84 559 235 89 560 minecraft:black_concrete
fill 235 84 569 235 84 570 minecraft:yellow_concrete
fill 235 84 571 235 89 572 minecraft:black_concrete
fill 235 84 578 235 85 578 minecraft:yellow_concrete
fill 235 84 579 235 89 580 minecraft:black_concrete
setblock 235 84 581 minecraft:yellow_concrete
fill 235 84 583 235 89 583 minecraft:black_concrete
fill 235 84 589 235 85 590 minecraft:yellow_concrete
fill 235 84 591 235 89 592 minecraft:black_concrete
fill 236 84 557 237 89 557 minecraft:black_concrete
fill 236 84 558 238 84 558 minecraft:orange_concrete
fill 236 84 560 236 84 562 minecraft:orange_concrete
fill 236 84 564 236 84 566 minecraft:orange_concrete
fill 236 84 568 236 84 570 minecraft:orange_concrete
fill 236 84 572 236 84 574 minecraft:orange_concrete
fill 236 84 576 236 84 578 minecraft:orange_concrete
fill 236 84 580 236 84 582 minecraft:orange_concrete
fill 236 84 584 236 84 586 minecraft:orange_concrete
fill 236 84 588 236 84 590 minecraft:orange_concrete
fill 236 84 592 236 84 594 minecraft:orange_concrete
fill 236 84 596 236 84 598 minecraft:orange_concrete
fill 236 84 599 236 89 599 minecraft:black_concrete
fill 237 84 599 238 84 599 minecraft:yellow_concrete
fill 238 84 557 239 85 557 minecraft:yellow_concrete
fill 238 84 598 240 84 598 minecraft:orange_concrete
fill 239 84 599 240 89 599 minecraft:black_concrete
fill 240 84 558 242 84 558 minecraft:orange_concrete
fill 242 84 598 244 84 598 minecraft:orange_concrete
fill 244 84 558 246 84 558 minecraft:orange_concrete
fill 245 84 557 245 89 557 minecraft:black_concrete
fill 245 84 599 246 85 599 minecraft:yellow_concrete
fill 246 84 598 248 84 598 minecraft:orange_concrete
setblock 247 84 557 minecraft:yellow_concrete
fill 247 84 599 248 89 599 minecraft:black_concrete
fill 248 84 557 249 89 557 minecraft:black_concrete
fill 248 84 558 250 84 558 minecraft:orange_concrete
setblock 249 84 599 minecraft:yellow_concrete
fill 250 84 557 250 85 557 minecraft:yellow_concrete
fill 250 84 598 252 84 598 minecraft:orange_concrete
fill 252 84 558 254 84 558 minecraft:orange_concrete
fill 254 84 598 256 84 598 minecraft:orange_concrete
fill 256 84 557 257 89 557 minecraft:black_concrete
fill 256 84 558 258 84 558 minecraft:orange_concrete
fill 257 84 599 258 85 599 minecraft:yellow_concrete
fill 258 84 557 259 84 557 minecraft:yellow_concrete
fill 258 84 598 260 84 598 minecraft:orange_concrete
fill 259 84 599 260 89 599 minecraft:black_concrete
fill 260 84 558 262 84 558 minecraft:orange_concrete
fill 262 84 598 264 84 598 minecraft:orange_concrete
fill 264 84 558 266 84 558 minecraft:orange_concrete
fill 266 84 598 268 84 598 minecraft:orange_concrete
fill 266 84 599 266 85 599 minecraft:yellow_concrete
fill 268 84 557 269 89 557 minecraft:black_concrete
fill 268 84 558 270 84 558 minecraft:orange_concrete
fill 268 84 599 268 89 599 minecraft:black_concrete
fill 269 84 599 270 84 599 minecraft:yellow_concrete
fill 270 84 557 271 85 557 minecraft:yellow_concrete
fill 270 84 598 272 84 598 minecraft:orange_concrete
fill 271 84 599 271 89 599 minecraft:black_concrete
fill 272 84 558 274 84 558 minecraft:orange_concrete
fill 274 84 598 276 84 598 minecraft:orange_concrete
fill 276 84 558 276 84 560 minecraft:orange_concrete
fill 276 84 562 276 84 564 minecraft:orange_concrete
fill 276 84 566 276 84 568 minecraft:orange_concrete
fill 276 84 570 276 84 572 minecraft:orange_concrete
fill 276 84 574 276 84 576 minecraft:orange_concrete
fill 276 84 578 276 84 580 minecraft:orange_concrete
fill 276 84 582 276 84 584 minecraft:orange_concrete
fill 276 84 586 276 84 588 minecraft:orange_concrete
fill 276 84 590 276 84 592 minecraft:orange_concrete
fill 276 84 594 276 84 596 minecraft:orange_concrete
fill 277 84 557 277 89 557 minecraft:black_concrete
fill 277 84 558 277 84 559 minecraft:yellow_concrete
fill 277 84 560 277 89 560 minecraft:black_concrete
fill 277 84 562 277 85 562 minecraft:yellow_concrete
setblock 277 84 563 minecraft:black_concrete
fill 277 84 568 277 89 569 minecraft:black_concrete
fill 277 84 570 277 85 571 minecraft:yellow_concrete
fill 277 84 577 277 86 577 minecraft:black_concrete
setblock 277 84 579 minecraft:yellow_concrete
fill 277 84 580 277 89 581 minecraft:black_concrete
fill 277 84 582 277 85 583 minecraft:yellow_concrete
fill 277 84 588 277 89 589 minecraft:black_concrete
fill 277 84 590 277 84 591 minecraft:yellow_concrete
fill 277 84 592 277 85 592 minecraft:black_concrete
fill 277 84 599 277 85 599 minecraft:yellow_concrete
setblock 235 85 566 minecraft:yellow_concrete
setblock 235 85 569 minecraft:yellow_concrete
fill 235 85 570 235 88 570 minecraft:black_concrete
setblock 235 85 577 minecraft:yellow_concrete
fill 235 85 581 235 88 581 minecraft:black_concrete
fill 235 85 597 235 85 598 minecraft:yellow_concrete
setblock 237 85 599 minecraft:yellow_concrete
fill 238 85 599 238 88 599 minecraft:black_concrete
fill 247 85 557 247 88 557 minecraft:black_concrete
fill 249 85 599 249 88 599 minecraft:black_concrete
setblock 251 85 557 minecraft:yellow_concrete
setblock 254 85 599 minecraft:yellow_concrete
fill 258 85 557 258 88 557 minecraft:black_concrete
setblock 259 85 557 minecraft:yellow_concrete
setblock 262 85 557 minecraft:yellow_concrete
setblock 265 85 599 minecraft:yellow_concrete
fill 269 85 599 270 88 599 minecraft:black_concrete
fill 277 85 558 277 88 559 minecraft:black_concrete
setblock 277 85 563 minecraft:yellow_concrete
setblock 277 85 574 minecraft:yellow_concrete
fill 277 85 575 277 87 575 minecraft:black_concrete
fill 277 85 579 277 88 579 minecraft:black_concrete
fill 277 85 590 277 88 590 minecraft:black_concrete
setblock 277 85 591 minecraft:yellow_concrete
fill 277 85 594 277 85 595 minecraft:yellow_concrete
fill 235 86 557 235 91 558 minecraft:black_concrete
fill 235 86 564 235 87 564 minecraft:yellow_concrete
fill 235 86 566 235 91 566 minecraft:black_concrete
fill 235 86 567 235 86 568 minecraft:yellow_concrete
fill 235 86 569 235 91 569 minecraft:black_concrete
fill 235 86 575 235 87 576 minecraft:yellow_concrete
fill 235 86 577 235 91 578 minecraft:black_concrete
fill 235 86 587 235 86 588 minecraft:yellow_concrete
fill 235 86 589 235 91 590 minecraft:black_concrete
fill 235 86 596 235 87 596 minecraft:yellow_concrete
fill 235 86 597 235 91 598 minecraft:black_concrete
setblock 235 86 599 minecraft:yellow_concrete
fill 237 86 599 237 91 599 minecraft:black_concrete
fill 238 86 557 239 91 557 minecraft:black_concrete
fill 240 86 557 241 86 557 minecraft:yellow_concrete
fill 243 86 599 244 87 599 minecraft:yellow_concrete
fill 245 86 599 246 91 599 minecraft:black_concrete
fill 250 86 557 251 91 557 minecraft:black_concrete
fill 252 86 557 253 87 557 minecraft:yellow_concrete
fill 254 86 599 254 91 599 minecraft:black_concrete
fill 255 86 599 256 86 599 minecraft:yellow_concrete
fill 257 86 599 258 91 599 minecraft:black_concrete
fill 259 86 557 259 91 557 minecraft:black_concrete
fill 260 86 557 261 86 557 minecraft:yellow_concrete
fill 262 86 557 262 91 557 minecraft:black_concrete
fill 263 86 599 264 87 599 minecraft:yellow_concrete
fill 264 86 557 264 87 557 minecraft:yellow_concrete
fill 265 86 599 266 91 599 minecraft:black_concrete
setblock 267 86 599 minecraft:yellow_concrete
fill 270 86 557 271 91 557 minecraft:black_concrete
fill 272 86 557 273 87 557 minecraft:yellow_concrete
fill 275 86 599 276 87 599 minecraft:yellow_concrete
setblock 277 86 561 minecraft:yellow_concrete
fill 277 86 562 277 91 563 minecraft:black_concrete
fill 277 86 564 277 87 565 minecraft:yellow_concrete
fill 277 86 570 277 91 571 minecraft:black_concrete
fill 277 86 572 277 86 573 minecraft:yellow_concrete
fill 277 86 574 277 87 574 minecraft:black_concrete
fill 277 86 582 277 91 583 minecraft:black_concrete
fill 277 86 584 277 87 585 minecraft:yellow_concrete
fill 277 86 591 277 91 591 minecraft:black_concrete
fill 277 86 592 277 86 593 minecraft:yellow_concrete
fill 277 86 594 277 87 595 minecraft:black_concrete
fill 277 86 596 277 87 596 minecraft:yellow_concrete
fill 277 86 599 277 91 599 minecraft:black_concrete
setblock 235 87 563 minecraft:yellow_concrete
fill 235 87 567 235 90 568 minecraft:black_concrete
setblock 235 87 584 minecraft:yellow_concrete
setblock 235 87 587 minecraft:yellow_concrete
fill 235 87 588 235 90 588 minecraft:black_concrete
setblock 235 87 595 minecraft:yellow_concrete
fill 235 87 599 235 90 599 minecraft:black_concrete
setblock 238 87 560 minecraft:light[level=14]
setblock 238 87 568 minecraft:light[level=14]
setblock 238 87 576 minecraft:light[level=14]
setblock 238 87 584 minecraft:light[level=14]
setblock 238 87 592 minecraft:light[level=14]
fill 240 87 557 240 90 557 minecraft:black_concrete
setblock 241 87 557 minecraft:yellow_concrete
setblock 244 87 557 minecraft:yellow_concrete
setblock 246 87 560 minecraft:light[level=14]
setblock 246 87 568 minecraft:light[level=14]
setblock 246 87 576 minecraft:light[level=14]
setblock 246 87 584 minecraft:light[level=14]
setblock 246 87 592 minecraft:light[level=14]
fill 251 87 599 252 87 599 minecraft:yellow_concrete
setblock 254 87 560 minecraft:light[level=14]
setblock 254 87 568 minecraft:light[level=14]
setblock 254 87 576 minecraft:light[level=14]
setblock 254 87 584 minecraft:light[level=14]
setblock 254 87 592 minecraft:light[level=14]
setblock 255 87 599 minecraft:yellow_concrete
fill 256 87 599 256 90 599 minecraft:black_concrete
fill 260 87 557 261 90 557 minecraft:black_concrete
setblock 262 87 560 minecraft:light[level=14]
setblock 262 87 568 minecraft:light[level=14]
setblock 262 87 576 minecraft:light[level=14]
setblock 262 87 584 minecraft:light[level=14]
setblock 262 87 592 minecraft:light[level=14]
setblock 265 87 557 minecraft:yellow_concrete
fill 267 87 599 267 90 599 minecraft:black_concrete
setblock 270 87 560 minecraft:light[level=14]
setblock 270 87 568 minecraft:light[level=14]
setblock 270 87 576 minecraft:light[level=14]
setblock 270 87 584 minecraft:light[level=14]
setblock 270 87 592 minecraft:light[level=14]
setblock 272 87 599 minecraft:yellow_concrete
setblock 276 87 557 minecraft:yellow_concrete
fill 277 87 561 277 90 561 minecraft:black_concrete
fill 277 87 572 277 90 572 minecraft:black_concrete
setblock 277 87 573 minecraft:yellow_concrete
fill 277 87 576 277 87 577 minecraft:yellow_concrete
fill 277 87 592 277 89 593 minecraft:black_concrete
setblock 277 87 597 minecraft:yellow_concrete
fill 235 88 561 235 89 562 minecraft:yellow_concrete
fill 235 88 563 235 93 564 minecraft:black_concrete
setblock 235 88 565 minecraft:yellow_concrete
fill 235 88 573 235 89 574 minecraft:yellow_concrete
fill 235 88 575 235 93 576 minecraft:black_concrete
fill 235 88 582 235 89 582 minecraft:yellow_concrete
fill 235 88 584 235 93 584 minecraft:black_concrete
fill 235 88 585 235 88 586 minecraft:yellow_concrete
fill 235 88 587 235 93 587 minecraft:black_concrete
fill 235 88 593 235 89 594 minecraft:yellow_concrete
fill 235 88 595 235 93 596 minecraft:black_concrete
fill 241 88 557 241 93 557 minecraft:black_concrete
fill 241 88 599 242 88 599 minecraft:yellow_concrete
fill 242 88 557 243 88 557 minecraft:yellow_concrete
fill 243 88 599 244 93 599 minecraft:black_concrete
fill 244 88 557 244 93 557 minecraft:black_concrete
fill 246 88 557 246 89 557 minecraft:yellow_concrete
fill 250 88 599 250 89 599 minecraft:yellow_concrete
fill 251 88 599 252 93 599 minecraft:black_concrete
fill 252 88 557 253 93 557 minecraft:black_concrete
setblock 253 88 599 minecraft:yellow_concrete
fill 254 88 557 255 89 557 minecraft:yellow_concrete
fill 255 88 599 255 93 599 minecraft:black_concrete
fill 261 88 599 262 89 599 minecraft:yellow_concrete
setblock 263 88 557 minecraft:yellow_concrete
fill 263 88 599 264 93 599 minecraft:black_concrete
fill 264 88 557 265 93 557 minecraft:black_concrete
fill 266 88 557 267 89 557 minecraft:yellow_concrete
fill 272 88 557 273 93 557 minecraft:black_concrete
fill 272 88 599 272 93 599 minecraft:black_concrete
fill 273 88 599 274 88 599 minecraft:yellow_concrete
fill 274 88 557 275 88 557 minecraft:yellow_concrete
fill 275 88 599 276 90 599 minecraft:black_concrete
fill 276 88 557 276 93 557 minecraft:black_concrete
fill 277 88 564 277 93 565 minecraft:black_concrete
fill 277 88 566 277 89 567 minecraft:yellow_concrete
fill 277 88 573 277 93 573 minecraft:black_concrete
fill 277 88 574 277 88 575 minecraft:yellow_concrete
fill 277 88 576 277 89 577 minecraft:black_concrete
fill 277 88 578 277 89 578 minecraft:yellow_concrete
fill 277 88 584 277 93 585 minecraft:black_concrete
fill 277 88 586 277 89 587 minecraft:yellow_concrete
fill 277 88 594 277 91 594 minecraft:black_concrete
setblock 277 88 595 minecraft:yellow_concrete
fill 277 88 596 277 93 597 minecraft:black_concrete
fill 277 88 598 277 89 598 minecraft:yellow_concrete
fill 235 89 565 235 92 565 minecraft:black_concrete
setblock 235 89 570 minecraft:yellow_concrete
setblock 235 89 581 minecraft:yellow_concrete
fill 235 89 585 235 92 586 minecraft:black_concrete
setblock 238 89 599 minecraft:yellow_concrete
setblock 241 89 599 minecraft:yellow_concrete
fill 242 89 557 243 92 557 minecraft:black_concrete
fill 242 89 599 242 92 599 minecraft:black_concrete
setblock 247 89 557 minecraft:yellow_concrete
setblock 249 89 599 minecraft:yellow_concrete
fill 253 89 599 253 92 599 minecraft:black_concrete
setblock 258 89 557 minecraft:yellow_concrete
fill 263 89 557 263 92 557 minecraft:black_concrete
fill 269 89 599 270 89 599 minecraft:yellow_concrete
setblock 273 89 599 minecraft:yellow_concrete
fill 274 89 557 274 92 557 minecraft:black_concrete
fill 274 89 599 274 92 599 minecraft:black_concrete
setblock 275 89 557 minecraft:yellow_concrete
fill 277 89 558 277 89 559 minecraft:yellow_concrete
fill 277 89 574 277 91 575 minecraft:black_concrete
setblock 277 89 579 minecraft:yellow_concrete
setblock 277 89 590 minecraft:yellow_concrete
fill 277 89 595 277 91 595 minecraft:black_concrete
fill 235 90 559 235 91 560 minecraft:yellow_concrete
fill 235 90 561 235 102 562 minecraft:black_concrete
fill 235 90 570 235 101 570 minecraft:black_concrete
fill 235 90 571 235 90 572 minecraft:yellow_concrete
fill 235 90 573 235 101 574 minecraft:black_concrete
fill 235 90 579 235 91 580 minecraft:yellow_concrete
fill 235 90 581 235 102 582 minecraft:black_concrete
setblock 235 90 583 minecraft:yellow_concrete
fill 235 90 591 235 91 592 minecraft:yellow_concrete
fill 235 90 593 235 105 594 minecraft:black_concrete
fill 236 90 557 237 91 557 minecraft:yellow_concrete
fill 236 90 558 238 90 558 minecraft:orange_concrete
fill 236 90 560 236 90 562 minecraft:orange_concrete
fill 236 90 564 236 90 566 minecraft:orange_concrete
fill 236 90 568 236 90 570 minecraft:orange_concrete
fill 236 90 572 236 90 574 minecraft:orange_concrete
fill 236 90 576 236 90 578 minecraft:orange_concrete
fill 236 90 580 236 90 582 minecraft:orange_concrete
fill 236 90 584 236 90 586 minecraft:orange_concrete
fill 236 90 588 236 90 590 minecraft:orange_concrete
fill 236 90 592 236 90 594 minecraft:orange_concrete
fill 236 90 596 236 90 598 minecraft:orange_concrete
fill 236 90 599 236 91 599 minecraft:yellow_concrete
fill 238 90 598 240 90 598 minecraft:orange_concrete
fill 238 90 599 238 102 599 minecraft:black_concrete
fill 239 90 599 240 90 599 minecraft:yellow_concrete
fill 240 90 558 242 90 558 minecraft:orange_concrete
fill 241 90 599 241 105 599 minecraft:black_concrete
fill 242 90 598 244 90 598 minecraft:orange_concrete
fill 244 90 558 246 90 558 minecraft:orange_concrete
setblock 245 90 557 minecraft:yellow_concrete
fill 246 90 557 247 103 557 minecraft:black_concrete
fill 246 90 598 248 90 598 minecraft:orange_concrete
fill 247 90 599 248 91 599 minecraft:yellow_concrete
fill 248 90 557 249 91 557 minecraft:yellow_concrete
fill 248 90 558 250 90 558 minecraft:orange_concrete
fill 249 90 599 250 102 599 minecraft:black_concrete
fill 250 90 598 252 90 598 minecraft:orange_concrete
fill 252 90 558 254 90 558 minecraft:orange_concrete
fill 254 90 557 255 105 557 minecraft:black_concrete
fill 254 90 598 256 90 598 minecraft:orange_concrete
fill 256 90 557 257 90 557 minecraft:yellow_concrete
fill 256 90 558 258 90 558 minecraft:orange_concrete
fill 258 90 557 258 105 557 minecraft:black_concrete
fill 258 90 598 260 90 598 minecraft:orange_concrete
fill 259 90 599 260 90 599 minecraft:yellow_concrete
fill 260 90 558 262 90 558 minecraft:orange_concrete
fill 261 90 599 262 105 599 minecraft:black_concrete
fill 262 90 598 264 90 598 minecraft:orange_concrete
fill 264 90 558 266 90 558 minecraft:orange_concrete
fill 266 90 557 267 105 557 minecraft:black_concrete
fill 266 90 583 266 91 584 minecraft:orange_concrete
fill 266 90 598 268 90 598 minecraft:orange_concrete
fill 268 90 557 269 91 557 minecraft:yellow_concrete
fill 268 90 558 270 90 558 minecraft:orange_concrete
fill 268 90 599 268 91 599 minecraft:yellow_concrete
fill 269 90 599 270 105 599 minecraft:black_concrete
fill 270 90 598 272 90 598 minecraft:orange_concrete
setblock 271 90 599 minecraft:yellow_concrete
fill 272 90 558 274 90 558 minecraft:orange_concrete
fill 273 90 599 273 92 599 minecraft:black_concrete
fill 274 90 598 276 90 598 minecraft:orange_concrete
fill 275 90 557 275 103 557 minecraft:black_concrete
fill 276 90 558 276 90 560 minecraft:orange_concrete
fill 276 90 562 276 90 564 minecraft:orange_concrete
fill 276 90 566 276 90 568 minecraft:orange_concrete
fill 276 90 570 276 90 572 minecraft:orange_concrete
fill 276 90 574 276 90 576 minecraft:orange_concrete
fill 276 90 578 276 90 580 minecraft:orange_concrete
fill 276 90 582 276 90 584 minecraft:orange_concrete
fill 276 90 586 276 90 588 minecraft:orange_concrete
fill 276 90 590 276 90 592 minecraft:orange_concrete
fill 276 90 594 276 90 596 minecraft:orange_concrete
setblock 277 90 557 minecraft:yellow_concrete
fill 277 90 558 277 103 559 minecraft:black_concrete
fill 277 90 560 277 91 560 minecraft:yellow_concrete
fill 277 90 566 277 102 567 minecraft:black_concrete
fill 277 90 568 277 90 569 minecraft:yellow_concrete
fill 277 90 576 277 93 576 minecraft:black_concrete
setblock 277 90 577 minecraft:yellow_concrete
fill 277 90 578 277 105 579 minecraft:black_concrete
fill 277 90 580 277 91 581 minecraft:yellow_concrete
fill 277 90 586 277 92 587 minecraft:black_concrete
fill 277 90 588 277 90 589 minecraft:yellow_concrete
fill 277 90 590 277 105 590 minecraft:black_concrete
fill 277 90 592 277 91 592 minecraft:yellow_concrete
setblock 277 90 593 minecraft:black_concrete
fill 277 90 598 277 102 598 minecraft:black_concrete
fill 235 91 567 235 91 568 minecraft:yellow_concrete
setblock 235 91 571 minecraft:yellow_concrete
fill 235 91 572 235 94 572 minecraft:black_concrete
fill 235 91 583 235 94 583 minecraft:black_concrete
setblock 235 91 588 minecraft:yellow_concrete
setblock 235 91 599 minecraft:yellow_concrete
fill 239 91 599 240 94 599 minecraft:black_concrete
setblock 240 91 557 minecraft:yellow_concrete
fill 245 91 557 245 94 557 minecraft:black_concrete
fill 256 91 557 256 94 557 minecraft:black_concrete
setblock 256 91 599 minecraft:yellow_concrete
setblock 257 91 557 minecraft:yellow_concrete
setblock 259 91 599 minecraft:yellow_concrete
fill 260 91 557 261 91 557 minecraft:yellow_concrete
fill 260 91 599 260 94 599 minecraft:black_concrete
setblock 267 91 599 minecraft:yellow_concrete
fill 271 91 599 271 94 599 minecraft:black_concrete
fill 275 91 599 275 93 599 minecraft:black_concrete
setblock 276 91 599 minecraft:yellow_concrete
fill 277 91 557 277 94 557 minecraft:black_concrete
setblock 277 91 561 minecraft:yellow_concrete
fill 277 91 568 277 94 568 minecraft:black_concrete
setblock 277 91 569 minecraft:yellow_concrete
setblock 277 91 572 minecraft:yellow_concrete
fill 277 91 577 277 93 577 minecraft:black_concrete
fill 277 91 588 277 94 588 minecraft:black_concrete
setblock 277 91 589 minecraft:yellow_concrete
setblock 277 91 593 minecraft:yellow_concrete
fill 235 92 557 235 92 558 minecraft:yellow_concrete
fill 235 92 559 235 105 560 minecraft:black_concrete
fill 235 92 566 235 93 566 minecraft:yellow_concrete
fill 235 92 567 235 105 568 minecraft:black_concrete
setblock 235 92 569 minecraft:yellow_concrete
fill 235 92 571 235 105 571 minecraft:black_concrete
fill 235 92 577 235 93 578 minecraft:yellow_concrete
fill 235 92 579 235 105 580 minecraft:black_concrete
fill 235 92 588 235 105 588 minecraft:black_concrete
fill 235 92 589 235 92 590 minecraft:yellow_concrete
fill 235 92 591 235 105 592 minecraft:black_concrete
fill 235 92 597 235 93 598 minecraft:yellow_concrete
fill 235 92 599 236 105 599 minecraft:black_concrete
fill 236 92 557 237 105 557 minecraft:black_concrete
setblock 237 92 599 minecraft:yellow_concrete
fill 238 92 557 239 92 557 minecraft:yellow_concrete
fill 240 92 557 240 105 557 minecraft:black_concrete
fill 245 92 599 246 93 599 minecraft:yellow_concrete
fill 247 92 599 248 105 599 minecraft:black_concrete
fill 248 92 557 249 103 557 minecraft:black_concrete
fill 250 92 557 251 93 557 minecraft:yellow_concrete
fill 254 92 599 254 93 599 minecraft:yellow_concrete
fill 256 92 599 256 105 599 minecraft:black_concrete
fill 257 92 557 257 105 557 minecraft:black_concrete
fill 257 92 599 258 92 599 minecraft:yellow_concrete
setblock 259 92 557 minecraft:yellow_concrete
fill 259 92 599 259 102 599 minecraft:black_concrete
fill 260 92 557 261 105 557 minecraft:black_concrete
fill 262 92 557 262 93 557 minecraft:yellow_concrete
fill 265 92 599 266 93 599 minecraft:yellow_concrete
fill 267 92 599 268 101 599 minecraft:black_concrete
fill 268 92 557 269 101 557 minecraft:black_concrete
fill 270 92 557 271 92 557 minecraft:yellow_concrete
fill 276 92 599 276 93 599 minecraft:black_concrete
fill 277 92 560 277 105 561 minecraft:black_concrete
fill 277 92 562 277 93 563 minecraft:yellow_concrete
fill 277 92 569 277 105 569 minecraft:black_concrete
fill 277 92 570 277 92 571 minecraft:yellow_concrete
fill 277 92 572 277 105 572 minecraft:black_concrete
fill 277 92 574 277 93 574 minecraft:yellow_concrete
setblock 277 92 575 minecraft:black_concrete
fill 277 92 580 277 101 581 minecraft:black_concrete
fill 277 92 582 277 93 583 minecraft:yellow_concrete
fill 277 92 589 277 94 589 minecraft:black_concrete
setblock 277 92 591 minecraft:yellow_concrete
fill 277 92 592 277 105 593 minecraft:black_concrete
fill 277 92 594 277 93 595 minecraft:yellow_concrete
fill 277 92 599 277 93 599 minecraft:yellow_concrete
setblock 235 93 557 minecraft:yellow_concrete
fill 235 93 558 235 101 558 minecraft:black_concrete
setblock 235 93 565 minecraft:yellow_concrete
fill 235 93 569 235 105 569 minecraft:black_concrete
fill 235 93 585 235 93 586 minecraft:yellow_concrete
setblock 235 93 589 minecraft:yellow_concrete
fill 235 93 590 235 106 590 minecraft:black_concrete
fill 237 93 599 237 103 599 minecraft:black_concrete
fill 238 93 557 238 105 557 minecraft:black_concrete
setblock 239 93 557 minecraft:yellow_concrete
fill 242 93 557 243 93 557 minecraft:yellow_concrete
setblock 242 93 599 minecraft:yellow_concrete
setblock 253 93 599 minecraft:yellow_concrete
fill 257 93 599 258 101 599 minecraft:black_concrete
fill 259 93 557 259 105 557 minecraft:black_concrete
setblock 263 93 557 minecraft:yellow_concrete
fill 270 93 557 270 105 557 minecraft:black_concrete
setblock 271 93 557 minecraft:yellow_concrete
fill 273 93 599 274 93 599 minecraft:yellow_concrete
setblock 274 93 557 minecraft:yellow_concrete
fill 277 93 570 277 103 571 minecraft:black_concrete
setblock 277 93 575 minecraft:yellow_concrete
setblock 277 93 586 minecraft:yellow_concrete
fill 277 93 587 277 106 587 minecraft:black_concrete
fill 277 93 591 277 103 591 minecraft:black_concrete
fill 235 94 557 235 102 557 minecraft:black_concrete
fill 235 94 563 235 95 564 minecraft:yellow_concrete
fill 235 94 565 235 101 566 minecraft:black_concrete
fill 235 94 575 235 94 576 minecraft:yellow_concrete
fill 235 94 577 235 105 578 minecraft:black_concrete
fill 235 94 584 235 95 584 minecraft:yellow_concrete
fill 235 94 585 235 105 586 minecraft:black_concrete
setblock 235 94 587 minecraft:yellow_concrete
fill 235 94 589 235 102 589 minecraft:black_concrete
fill 235 94 595 235 95 596 minecraft:yellow_concrete
fill 235 94 597 235 102 598 minecraft:black_concrete
fill 239 94 557 239 105 557 minecraft:black_concrete
setblock 241 94 557 minecraft:yellow_concrete
fill 242 94 557 243 105 557 minecraft:black_concrete
fill 242 94 599 242 105 599 minecraft:black_concrete
fill 243 94 599 244 94 599 minecraft:yellow_concrete
fill 244 94 557 244 95 557 minecraft:yellow_concrete
fill 245 94 599 246 102 599 minecraft:black_concrete
fill 250 94 557 251 101 557 minecraft:black_concrete
fill 251 94 599 252 95 599 minecraft:yellow_concrete
fill 252 94 557 253 94 557 minecraft:yellow_concrete
fill 253 94 599 254 105 599 minecraft:black_concrete
setblock 255 94 599 minecraft:yellow_concrete
fill 262 94 557 263 101 557 minecraft:black_concrete
fill 263 94 599 264 95 599 minecraft:yellow_concrete
fill 264 94 557 265 95 557 minecraft:yellow_concrete
fill 265 94 599 266 105 599 minecraft:black_concrete
fill 271 94 557 271 103 557 minecraft:black_concrete
fill 272 94 557 273 94 557 minecraft:yellow_concrete
fill 272 94 599 272 95 599 minecraft:yellow_concrete
fill 273 94 599 274 105 599 minecraft:black_concrete
fill 274 94 557 274 105 557 minecraft:black_concrete
fill 275 94 599 276 94 599 minecraft:yellow_concrete
fill 276 94 557 276 95 557 minecraft:yellow_concrete
fill 277 94 562 277 105 563 minecraft:black_concrete
fill 277 94 564 277 95 565 minecraft:yellow_concrete
setblock 277 94 573 minecraft:yellow_concrete
fill 277 94 574 277 105 575 minecraft:black_concrete
fill 277 94 576 277 95 577 minecraft:yellow_concrete
fill 277 94 582 277 105 583 minecraft:black_concrete
fill 277 94 584 277 94 585 minecraft:yellow_concrete
fill 277 94 586 277 101 586 minecraft:black_concrete
fill 277 94 594 277 105 595 minecraft:black_concrete
fill 277 94 596 277 95 597 minecraft:yellow_concrete
fill 277 94 599 277 105 599 minecraft:black_concrete
setblock 235 95 572 minecraft:yellow_concrete
setblock 235 95 575 minecraft:yellow_concrete
fill 235 95 576 235 105 576 minecraft:black_concrete
setblock 235 95 583 minecraft:yellow_concrete
fill 235 95 587 235 102 587 minecraft:black_concrete
setblock 238 95 560 minecraft:light[level=14]
setblock 238 95 568 minecraft:light[level=14]
setblock 238 95 576 minecraft:light[level=14]
setblock 238 95 584 minecraft:light[level=14]
setblock 238 95 592 minecraft:light[level=14]
fill 239 95 599 240 95 599 minecraft:yellow_concrete
fill 241 95 557 241 105 557 minecraft:black_concrete
setblock 243 95 599 minecraft:yellow_concrete
fill 244 95 599 244 105 599 minecraft:black_concrete
setblock 245 95 557 minecraft:yellow_concrete
setblock 246 95 560 minecraft:light[level=14]
setblock 246 95 568 minecraft:light[level=14]
setblock 246 95 576 minecraft:light[level=14]
setblock 246 95 584 minecraft:light[level=14]
setblock 246 95 592 minecraft:light[level=14]
fill 252 95 557 252 103 557 minecraft:black_concrete
setblock 253 95 557 minecraft:yellow_concrete
setblock 254 95 560 minecraft:light[level=14]
setblock 254 95 568 minecraft:light[level=14]
setblock 254 95 576 minecraft:light[level=14]
setblock 254 95 584 minecraft:light[level=14]
setblock 254 95 592 minecraft:light[level=14]
fill 255 95 599 255 103 599 minecraft:black_concrete
setblock 256 95 557 minecraft:yellow_concrete
setblock 260 95 599 minecraft:yellow_concrete
setblock 262 95 560 minecraft:light[level=14]
setblock 262 95 568 minecraft:light[level=14]
setblock 262 95 576 minecraft:light[level=14]
setblock 262 95 584 minecraft:light[level=14]
setblock 262 95 592 minecraft:light[level=14]
setblock 270 95 560 minecraft:light[level=14]
setblock 270 95 568 minecraft:light[level=14]
setblock 270 95 576 minecraft:light[level=14]
setblock 270 95 584 minecraft:light[level=14]
setblock 270 95 592 minecraft:light[level=14]
setblock 271 95 599 minecraft:yellow_concrete
fill 272 95 557 273 105 557 minecraft:black_concrete
fill 275 95 599 276 102 599 minecraft:black_concrete
setblock 277 95 557 minecraft:yellow_concrete
setblock 277 95 568 minecraft:yellow_concrete
fill 277 95 573 277 105 573 minecraft:black_concrete
fill 277 95 584 277 105 584 minecraft:black_concrete
setblock 277 95 585 minecraft:yellow_concrete
fill 277 95 588 277 95 589 minecraft:yellow_concrete
fill 235 96 563 235 102 564 minecraft:black_concrete
fill 235 96 572 235 103 572 minecraft:black_concrete
fill 235 96 575 235 105 575 minecraft:black_concrete
fill 235 96 583 235 102 584 minecraft:black_concrete
fill 235 96 595 235 102 596 minecraft:black_concrete
fill 239 96 599 240 103 599 minecraft:black_concrete
fill 243 96 599 243 103 599 minecraft:black_concrete
fill 244 96 557 245 101 557 minecraft:black_concrete
fill 251 96 599 252 101 599 minecraft:black_concrete
fill 253 96 557 253 103 557 minecraft:black_concrete
fill 256 96 557 256 105 557 minecraft:black_concrete
fill 260 96 599 260 105 599 minecraft:black_concrete
fill 263 96 599 264 105 599 minecraft:black_concrete
fill 264 96 557 265 102 557 minecraft:black_concrete
fill 271 96 599 272 105 599 minecraft:black_concrete
fill 276 96 557 277 105 557 minecraft:black_concrete
fill 277 96 564 277 102 565 minecraft:black_concrete
fill 277 96 568 277 102 568 minecraft:black_concrete
fill 277 96 576 277 105 577 minecraft:black_concrete
fill 277 96 585 277 105 585 minecraft:black_concrete
fill 277 96 588 277 101 589 minecraft:black_concrete
fill 277 96 596 277 103 597 minecraft:black_concrete
fill 252 100 573 254 100 575 minecraft:redstone_block
fill 254 100 582 256 100 584 minecraft:redstone_block
fill 258 100 573 260 100 575 minecraft:redstone_block
fill 259 100 580 261 100 582 minecraft:redstone_block
fill 238 101 578 254 101 578 minecraft:gray_concrete
fill 239 101 573 251 101 577 minecraft:gray_concrete
fill 239 101 579 253 101 583 minecraft:gray_concrete
fill 240 101 570 272 101 572 minecraft:gray_concrete
fill 240 101 584 253 101 586 minecraft:gray_concrete
fill 241 101 569 271 101 569 minecraft:gray_concrete
fill 241 101 587 271 101 587 minecraft:gray_concrete
fill 242 101 567 270 101 568 minecraft:gray_concrete
fill 242 101 588 270 101 589 minecraft:gray_concrete
fill 243 101 566 269 101 566 minecraft:gray_concrete
fill 243 101 590 269 101 590 minecraft:gray_concrete
fill 244 101 565 268 101 565 minecraft:gray_concrete
fill 244 101 591 268 101 591 minecraft:gray_concrete
fill 245 101 564 267 101 564 minecraft:gray_concrete
fill 245 101 592 267 101 592 minecraft:gray_concrete
fill 247 101 563 265 101 563 minecraft:gray_concrete
fill 247 101 593 265 101 593 minecraft:gray_concrete
fill 248 101 562 264 101 562 minecraft:gray_concrete
fill 248 101 594 264 101 594 minecraft:gray_concrete
fill 251 101 561 261 101 561 minecraft:gray_concrete
fill 251 101 595 261 101 595 minecraft:gray_concrete
fill 252 101 576 254 101 577 minecraft:gray_concrete
fill 254 101 579 254 101 581 minecraft:gray_concrete
fill 254 101 585 272 101 586 minecraft:gray_concrete
fill 255 101 573 257 101 576 minecraft:gray_concrete
fill 255 101 580 258 101 581 minecraft:gray_concrete
fill 256 101 560 256 108 560 minecraft:gray_concrete
fill 256 101 596 256 108 596 minecraft:gray_concrete
fill 257 101 582 258 101 584 minecraft:gray_concrete
fill 258 101 576 273 101 579 minecraft:gray_concrete
fill 259 101 583 272 101 584 minecraft:gray_concrete
fill 261 101 573 273 101 575 minecraft:gray_concrete
fill 262 101 580 273 101 582 minecraft:gray_concrete
fill 273 101 583 273 108 583 minecraft:gray_concrete
fill 274 101 578 274 108 578 minecraft:gray_concrete
setblock 235 102 558 minecraft:orange_terracotta
fill 235 102 565 235 106 565 minecraft:black_concrete
setblock 235 102 566 minecraft:orange_terracotta
setblock 235 102 570 minecraft:orange_terracotta
fill 235 102 573 235 105 573 minecraft:black_concrete
setblock 235 102 574 minecraft:orange_terracotta
fill 236 102 558 238 102 598 minecraft:gray_concrete
fill 239 102 558 241 102 574 minecraft:gray_concrete
fill 239 102 575 240 108 575 minecraft:magma_block
fill 239 102 576 239 102 598 minecraft:gray_concrete
fill 240 102 576 240 108 581 minecraft:gray_concrete
fill 240 102 582 240 108 582 minecraft:magma_block
fill 240 102 583 242 102 598 minecraft:gray_concrete
fill 241 102 575 241 108 580 minecraft:gray_concrete
fill 241 102 581 241 108 581 minecraft:magma_block
fill 241 102 582 246 106 582 minecraft:gray_concrete
fill 242 102 558 246 102 567 minecraft:gray_concrete
fill 242 102 568 243 108 568 minecraft:magma_block
fill 242 102 569 246 106 573 minecraft:gray_concrete
fill 242 102 574 243 108 574 minecraft:magma_block
fill 242 102 575 243 107 579 minecraft:gray_concrete
fill 242 102 580 242 108 580 minecraft:magma_block
fill 242 102 581 247 106 581 minecraft:gray_concrete
fill 243 102 580 251 104 580 minecraft:gray_concrete
fill 243 102 583 243 108 589 minecraft:gray_concrete
fill 243 102 590 243 108 590 minecraft:magma_block
fill 243 102 591 248 102 598 minecraft:gray_concrete
fill 244 102 557 245 102 557 minecraft:orange_terracotta
fill 244 102 568 253 106 568 minecraft:gray_concrete
fill 244 102 574 248 105 578 minecraft:gray_concrete
fill 244 102 579 244 107 579 minecraft:magma_block
fill 244 102 583 244 107 586 minecraft:gray_concrete
fill 244 102 587 244 108 587 minecraft:magma_block
fill 244 102 588 248 107 590 minecraft:gray_concrete
fill 245 102 579 251 104 579 minecraft:gray_concrete
fill 245 102 583 245 107 584 minecraft:gray_concrete
fill 245 102 585 245 107 585 minecraft:magma_block
fill 245 102 586 256 105 587 minecraft:gray_concrete
fill 246 102 583 246 106 583 minecraft:magma_block
fill 246 102 584 252 105 585 minecraft:gray_concrete
fill 247 102 558 254 102 562 minecraft:gray_concrete
fill 247 102 563 248 108 563 minecraft:magma_block
fill 247 102 564 250 107 567 minecraft:gray_concrete
fill 247 102 569 248 107 569 minecraft:magma_block
fill 247 102 570 249 105 573 minecraft:gray_concrete
fill 247 102 582 247 106 582 minecraft:magma_block
fill 247 102 583 252 104 583 minecraft:gray_concrete
fill 248 102 581 248 105 581 minecraft:magma_block
fill 248 102 582 252 104 582 minecraft:gray_concrete
fill 249 102 563 276 102 563 minecraft:gray_concrete
fill 249 102 569 267 105 569 minecraft:gray_concrete
fill 249 102 574 249 105 576 minecraft:gray_concrete
fill 249 102 577 249 105 577 minecraft:magma_block
fill 249 102 578 251 104 578 minecraft:gray_concrete
fill 249 102 581 252 104 581 minecraft:gray_concrete
fill 249 102 588 249 107 592 minecraft:magma_block
fill 249 102 593 255 102 598 minecraft:gray_concrete
setblock 250 102 557 minecraft:orange_terracotta
fill 250 102 570 250 106 570 minecraft:magma_block
fill 250 102 571 250 105 573 minecraft:gray_concrete
fill 250 102 574 250 105 574 minecraft:magma_block
fill 250 102 575 250 104 577 minecraft:gray_concrete
fill 250 102 588 253 106 592 minecraft:gray_concrete
fill 251 102 557 251 103 557 minecraft:black_concrete
fill 251 102 564 256 108 564 minecraft:gray_concrete
fill 251 102 565 251 108 565 minecraft:magma_block
fill 251 102 566 251 107 567 minecraft:gray_concrete
fill 251 102 570 254 105 571 minecraft:gray_concrete
fill 251 102 572 251 102 576 minecraft:shroomlight
fill 251 102 577 251 104 577 minecraft:gray_concrete
setblock 251 102 599 minecraft:black_concrete
fill 252 102 565 262 107 565 minecraft:gray_concrete
fill 252 102 566 252 107 566 minecraft:magma_block
fill 252 102 567 252 107 567 minecraft:gray_concrete
fill 252 102 572 255 102 572 minecraft:shroomlight
fill 252 102 573 254 102 575 minecraft:gray_concrete
fill 252 102 576 261 102 576 minecraft:shroomlight
fill 252 102 577 253 103 580 minecraft:orange_concrete
setblock 252 102 599 minecraft:orange_terracotta
fill 253 102 566 257 107 566 minecraft:gray_concrete
fill 253 102 567 253 107 567 minecraft:magma_block
fill 253 102 581 253 102 585 minecraft:shroomlight
fill 254 102 567 257 106 567 minecraft:gray_concrete
fill 254 102 568 254 106 568 minecraft:magma_block
fill 254 102 577 254 102 581 minecraft:shroomlight
fill 254 102 582 256 102 584 minecraft:gray_concrete
fill 254 102 585 257 102 585 minecraft:shroomlight
fill 254 102 588 257 106 588 minecraft:gray_concrete
fill 254 102 589 254 106 590 minecraft:magma_block
fill 254 102 591 254 107 592 minecraft:gray_concrete
fill 255 102 558 255 102 560 minecraft:gray_concrete
fill 255 102 561 255 108 561 minecraft:magma_block
fill 255 102 562 255 108 562 minecraft:gray_concrete
fill 255 102 568 262 106 568 minecraft:gray_concrete
fill 255 102 570 255 105 570 minecraft:magma_block
fill 255 102 571 266 105 571 minecraft:gray_concrete
fill 255 102 573 255 102 575 minecraft:shroomlight
fill 255 102 580 258 102 581 minecraft:shroomlight
fill 255 102 589 258 106 591 minecraft:gray_concrete
fill 255 102 592 255 108 592 minecraft:magma_block
fill 256 102 558 276 102 559 minecraft:gray_concrete
fill 256 102 561 276 102 561 minecraft:gray_concrete
fill 256 102 562 256 108 562 minecraft:magma_block
fill 256 102 570 276 102 570 minecraft:gray_concrete
fill 256 102 572 256 104 572 minecraft:gray_concrete
fill 256 102 573 256 104 573 minecraft:magma_block
fill 256 102 574 256 103 575 minecraft:orange_concrete
fill 256 102 592 263 108 593 minecraft:gray_concrete
fill 256 102 594 256 108 594 minecraft:magma_block
fill 256 102 595 256 108 595 minecraft:gray_concrete
fill 256 102 597 276 102 598 minecraft:gray_concrete
fill 257 102 560 276 102 560 minecraft:gray_concrete
fill 257 102 562 276 102 562 minecraft:gray_concrete
fill 257 102 564 257 108 564 minecraft:magma_block
fill 257 102 572 257 102 575 minecraft:shroomlight
fill 257 102 582 257 102 584 minecraft:shroomlight
fill 257 102 586 257 105 586 minecraft:magma_block
fill 257 102 587 263 105 587 minecraft:gray_concrete
fill 257 102 594 276 102 594 minecraft:gray_concrete
fill 257 102 595 257 108 595 minecraft:magma_block
fill 257 102 596 276 102 596 minecraft:gray_concrete
fill 257 102 599 257 105 599 minecraft:black_concrete
fill 258 102 564 262 108 564 minecraft:gray_concrete
fill 258 102 566 258 106 567 minecraft:magma_block
fill 258 102 572 261 102 572 minecraft:shroomlight
fill 258 102 573 260 102 575 minecraft:gray_concrete
fill 258 102 577 258 102 579 minecraft:shroomlight
fill 258 102 582 258 102 583 minecraft:shroomlight
fill 258 102 584 261 104 586 minecraft:gray_concrete
fill 258 102 588 258 106 588 minecraft:magma_block
fill 258 102 595 276 102 595 minecraft:gray_concrete
fill 258 102 599 258 103 599 minecraft:orange_terracotta
fill 259 102 566 262 107 567 minecraft:gray_concrete
fill 259 102 577 260 103 578 minecraft:orange_concrete
fill 259 102 579 262 102 579 minecraft:shroomlight
fill 259 102 580 261 102 582 minecraft:gray_concrete
fill 259 102 583 262 102 583 minecraft:shroomlight
fill 259 102 588 268 106 588 minecraft:gray_concrete
fill 259 102 589 259 107 589 minecraft:magma_block
fill 259 102 590 259 107 591 minecraft:gray_concrete
fill 260 102 589 276 102 589 minecraft:gray_concrete
fill 260 102 590 260 107 590 minecraft:magma_block
fill 260 102 591 260 108 591 minecraft:gray_concrete
fill 261 102 573 261 102 575 minecraft:shroomlight
fill 261 102 577 267 104 578 minecraft:gray_concrete
fill 261 102 590 276 102 590 minecraft:gray_concrete
fill 261 102 591 261 108 591 minecraft:magma_block
setblock 262 102 557 minecraft:orange_terracotta
fill 262 102 572 263 104 576 minecraft:gray_concrete
fill 262 102 580 262 102 582 minecraft:shroomlight
fill 262 102 584 276 102 585 minecraft:gray_concrete
fill 262 102 586 262 106 586 minecraft:magma_block
fill 262 102 591 276 102 591 minecraft:gray_concrete
fill 263 102 557 263 103 557 minecraft:black_concrete
fill 263 102 564 263 107 568 minecraft:magma_block
fill 263 102 579 263 105 579 minecraft:magma_block
fill 263 102 580 268 105 583 minecraft:gray_concrete
fill 263 102 586 276 102 586 minecraft:gray_concrete
fill 264 102 564 268 102 568 minecraft:gray_concrete
fill 264 102 572 264 105 574 minecraft:gray_concrete
fill 264 102 575 264 105 575 minecraft:magma_block
fill 264 102 576 269 105 576 minecraft:gray_concrete
fill 264 102 579 276 102 579 minecraft:gray_concrete
fill 264 102 587 265 107 587 minecraft:magma_block
fill 264 102 592 276 102 592 minecraft:gray_concrete
fill 264 102 593 265 108 593 minecraft:magma_block
fill 265 102 572 265 106 573 minecraft:gray_concrete
fill 265 102 574 265 106 574 minecraft:magma_block
fill 265 102 575 270 106 575 minecraft:gray_concrete
fill 266 102 572 276 102 572 minecraft:gray_concrete
fill 266 102 573 266 106 573 minecraft:magma_block
fill 266 102 574 271 106 574 minecraft:gray_concrete
fill 266 102 587 276 102 587 minecraft:gray_concrete
fill 266 102 593 276 102 593 minecraft:gray_concrete
fill 267 102 571 267 107 571 minecraft:magma_block
fill 267 102 573 276 102 573 minecraft:gray_concrete
setblock 267 102 599 minecraft:orange_terracotta
setblock 268 102 557 minecraft:orange_terracotta
fill 268 102 569 268 108 569 minecraft:magma_block
fill 268 102 571 276 102 571 minecraft:gray_concrete
fill 268 102 577 268 107 577 minecraft:magma_block
fill 268 102 578 273 107 578 minecraft:gray_concrete
fill 268 102 599 268 105 599 minecraft:black_concrete
fill 269 102 557 269 105 557 minecraft:black_concrete
fill 269 102 564 276 102 565 minecraft:gray_concrete
fill 269 102 566 269 108 566 minecraft:magma_block
fill 269 102 567 276 102 569 minecraft:gray_concrete
fill 269 102 577 276 102 577 minecraft:gray_concrete
fill 269 102 580 271 107 581 minecraft:gray_concrete
fill 269 102 582 270 108 582 minecraft:magma_block
fill 269 102 583 272 108 583 minecraft:gray_concrete
fill 269 102 588 270 108 588 minecraft:magma_block
fill 270 102 566 276 102 566 minecraft:gray_concrete
fill 270 102 576 270 108 576 minecraft:magma_block
fill 271 102 575 271 108 575 minecraft:magma_block
fill 271 102 576 276 102 576 minecraft:gray_concrete
fill 271 102 582 276 102 582 minecraft:gray_concrete
fill 271 102 588 276 102 588 minecraft:gray_concrete
fill 272 102 574 272 108 574 minecraft:magma_block
fill 272 102 575 276 102 575 minecraft:gray_concrete
fill 272 102 580 276 102 580 minecraft:gray_concrete
fill 272 102 581 273 108 581 minecraft:magma_block
fill 273 102 574 276 102 574 minecraft:gray_concrete
fill 274 102 581 276 102 581 minecraft:gray_concrete
fill 274 102 583 276 102 583 minecraft:gray_concrete
fill 275 102 578 276 102 578 minecraft:gray_concrete
setblock 277 102 580 minecraft:orange_terracotta
fill 277 102 581 277 105 581 minecraft:black_concrete
setblock 277 102 586 minecraft:orange_terracotta
setblock 277 102 588 minecraft:orange_terracotta
fill 277 102 589 277 106 589 minecraft:black_concrete
setblock 235 103 557 minecraft:orange_terracotta
fill 235 103 558 235 105 558 minecraft:black_concrete
setblock 235 103 561 minecraft:orange_terracotta
fill 235 103 562 235 105 563 minecraft:black_concrete
setblock 235 103 564 minecraft:orange_terracotta
setblock 235 103 566 minecraft:black_concrete
setblock 235 103 570 minecraft:black_concrete
fill 235 103 574 235 105 574 minecraft:black_concrete
fill 235 103 581 235 105 581 minecraft:black_concrete
setblock 235 103 582 minecraft:orange_terracotta
fill 235 103 583 235 105 583 minecraft:black_concrete
setblock 235 103 584 minecraft:orange_terracotta
setblock 235 103 587 minecraft:orange_terracotta
setblock 235 103 589 minecraft:orange_terracotta
setblock 235 103 595 minecraft:orange_terracotta
fill 235 103 596 235 105 597 minecraft:black_concrete
setblock 235 103 598 minecraft:orange_terracotta
setblock 238 103 560 minecraft:light[level=14]
setblock 238 103 568 minecraft:light[level=14]
setblock 238 103 576 minecraft:light[level=14]
fill 238 103 578 239 108 578 minecraft:gray_concrete
setblock 238 103 584 minecraft:light[level=14]
setblock 238 103 592 minecraft:light[level=14]
setblock 238 103 599 minecraft:orange_terracotta
fill 239 103 573 241 108 574 minecraft:gray_concrete
fill 239 103 576 239 108 577 minecraft:gray_concrete
fill 239 103 579 239 108 583 minecraft:gray_concrete
fill 240 103 570 241 108 572 minecraft:gray_concrete
fill 240 103 583 242 108 586 minecraft:gray_concrete
fill 241 103 569 241 108 569 minecraft:gray_concrete
fill 241 103 587 242 108 587 minecraft:gray_concrete
fill 242 103 567 246 108 567 minecraft:gray_concrete
fill 242 103 588 242 108 589 minecraft:gray_concrete
fill 243 103 566 246 108 566 minecraft:gray_concrete
fill 244 103 557 245 105 557 minecraft:black_concrete
fill 244 103 565 246 108 565 minecraft:gray_concrete
fill 244 103 591 248 108 591 minecraft:gray_concrete
fill 245 103 564 246 108 564 minecraft:gray_concrete
fill 245 103 592 248 108 592 minecraft:gray_concrete
setblock 245 103 599 minecraft:orange_terracotta
setblock 246 103 560 minecraft:light[level=14]
fill 246 103 599 246 106 599 minecraft:black_concrete
fill 247 103 593 255 108 593 minecraft:gray_concrete
fill 248 103 562 254 108 562 minecraft:gray_concrete
fill 248 103 594 255 108 594 minecraft:gray_concrete
fill 249 103 563 265 108 563 minecraft:gray_concrete
setblock 249 103 599 minecraft:orange_terracotta
fill 250 103 557 250 105 557 minecraft:black_concrete
fill 250 103 599 250 105 599 minecraft:black_concrete
fill 251 103 561 254 108 561 minecraft:gray_concrete
fill 251 103 572 251 104 576 minecraft:gray_concrete
fill 251 103 595 255 108 595 minecraft:gray_concrete
setblock 251 103 599 minecraft:orange_terracotta
fill 252 103 572 252 104 575 minecraft:gray_concrete
fill 252 103 576 254 103 576 minecraft:orange_concrete
fill 252 103 599 252 105 599 minecraft:black_concrete
fill 253 103 572 253 104 574 minecraft:gray_concrete
fill 253 103 575 255 103 575 minecraft:orange_concrete
fill 253 103 581 259 103 581 minecraft:orange_concrete
fill 253 103 582 253 104 585 minecraft:gray_concrete
setblock 254 103 560 minecraft:light[level=14]
fill 254 103 572 255 104 573 minecraft:gray_concrete
fill 254 103 574 255 103 574 minecraft:orange_concrete
setblock 254 103 580 minecraft:orange_concrete
fill 254 103 582 258 103 582 minecraft:orange_concrete
fill 254 103 583 255 104 585 minecraft:gray_concrete
fill 256 103 561 261 108 561 minecraft:gray_concrete
fill 256 103 570 272 105 570 minecraft:gray_concrete
fill 256 103 583 256 104 583 minecraft:magma_block
fill 256 103 584 257 104 585 minecraft:gray_concrete
fill 257 103 562 264 108 562 minecraft:gray_concrete
fill 257 103 572 261 104 573 minecraft:gray_concrete
fill 257 103 574 258 103 575 minecraft:orange_concrete
fill 257 103 583 262 104 583 minecraft:gray_concrete
fill 257 103 594 264 108 594 minecraft:gray_concrete
fill 258 103 576 260 103 576 minecraft:orange_concrete
fill 258 103 580 260 103 580 minecraft:orange_concrete
fill 258 103 595 261 108 595 minecraft:gray_concrete
fill 259 103 574 261 104 574 minecraft:gray_concrete
setblock 259 103 575 minecraft:orange_concrete
fill 259 103 579 260 103 579 minecraft:orange_concrete
fill 259 103 582 261 104 582 minecraft:gray_concrete
setblock 259 103 599 minecraft:orange_terracotta
fill 260 103 575 261 104 575 minecraft:gray_concrete
fill 260 103 581 262 104 581 minecraft:gray_concrete
fill 260 103 589 270 107 589 minecraft:gray_concrete
fill 261 103 576 261 104 576 minecraft:gray_concrete
fill 261 103 579 262 104 580 minecraft:gray_concrete
fill 261 103 590 269 107 590 minecraft:gray_concrete
fill 262 103 557 262 105 557 minecraft:black_concrete
setblock 262 103 560 minecraft:light[level=14]
fill 262 103 582 262 105 582 minecraft:magma_block
fill 262 103 584 272 105 585 minecraft:gray_concrete
fill 262 103 591 268 108 591 minecraft:gray_concrete
fill 263 103 586 272 106 586 minecraft:gray_concrete
fill 264 103 557 264 105 557 minecraft:black_concrete
fill 264 103 564 267 107 568 minecraft:gray_concrete
fill 264 103 579 273 105 579 minecraft:gray_concrete
fill 264 103 592 267 108 592 minecraft:gray_concrete
setblock 265 103 557 minecraft:orange_terracotta
fill 266 103 572 272 107 572 minecraft:gray_concrete
fill 266 103 587 271 108 587 minecraft:gray_concrete
fill 267 103 573 273 107 573 minecraft:gray_concrete
setblock 267 103 599 minecraft:black_concrete
fill 268 103 557 268 106 557 minecraft:black_concrete
fill 268 103 565 268 108 568 minecraft:gray_concrete
fill 268 103 571 272 108 571 minecraft:gray_concrete
fill 269 103 567 270 108 569 minecraft:gray_concrete
fill 269 103 577 273 107 577 minecraft:gray_concrete
setblock 270 103 560 minecraft:light[level=14]
setblock 270 103 592 minecraft:light[level=14]
fill 271 103 569 271 108 569 minecraft:gray_concrete
fill 271 103 576 273 108 576 minecraft:gray_concrete
fill 271 103 582 273 108 582 minecraft:gray_concrete
fill 272 103 575 273 108 575 minecraft:gray_concrete
fill 272 103 580 273 108 580 minecraft:gray_concrete
fill 273 103 574 273 108 574 minecraft:gray_concrete
setblock 275 103 599 minecraft:orange_terracotta
fill 276 103 599 276 105 599 minecraft:black_concrete
setblock 277 103 564 minecraft:orange_terracotta
fill 277 103 565 277 103 566 minecraft:black_concrete
fill 277 103 567 277 103 568 minecraft:orange_terracotta
fill 277 103 580 277 105 580 minecraft:black_concrete
setblock 277 103 586 minecraft:black_concrete
fill 277 103 588 277 106 588 minecraft:black_concrete
setblock 277 103 598 minecraft:orange_terracotta
fill 235 104 557 235 106 557 minecraft:black_concrete
fill 235 104 561 235 105 561 minecraft:black_concrete
fill 235 104 564 235 106 564 minecraft:black_concrete
setblock 235 104 566 minecraft:orange_terracotta
setblock 235 104 570 minecraft:orange_terracotta
setblock 235 104 572 minecraft:orange_terracotta
fill 235 104 582 235 105 582 minecraft:black_concrete
fill 235 104 584 235 105 584 minecraft:black_concrete
fill 235 104 587 235 105 587 minecraft:black_concrete
fill 235 104 589 235 105 589 minecraft:black_concrete
fill 235 104 595 235 105 595 minecraft:black_concrete
fill 235 104 598 235 105 598 minecraft:black_concrete
setblock 237 104 599 minecraft:orange_terracotta
fill 238 104 599 239 105 599 minecraft:black_concrete
setblock 240 104 599 minecraft:orange_terracotta
setblock 243 104 599 minecraft:orange_terracotta
fill 245 104 599 245 105 599 minecraft:black_concrete
fill 246 104 557 246 105 557 minecraft:black_concrete
fill 247 104 557 248 104 557 minecraft:orange_terracotta
fill 249 104 557 249 105 557 minecraft:black_concrete
fill 249 104 599 249 105 599 minecraft:black_concrete
fill 251 104 557 253 104 557 minecraft:orange_terracotta
fill 251 104 599 251 105 599 minecraft:black_concrete
setblock 255 104 599 minecraft:orange_terracotta
fill 258 104 599 259 105 599 minecraft:black_concrete
setblock 263 104 557 minecraft:orange_terracotta
fill 265 104 557 265 107 557 minecraft:black_concrete
setblock 267 104 599 minecraft:orange_terracotta
setblock 271 104 557 minecraft:orange_terracotta
setblock 275 104 557 minecraft:orange_terracotta
fill 275 104 599 275 105 599 minecraft:black_concrete
setblock 277 104 558 minecraft:orange_terracotta
fill 277 104 559 277 105 559 minecraft:black_concrete
fill 277 104 564 277 105 564 minecraft:black_concrete
setblock 277 104 565 minecraft:orange_terracotta
fill 277 104 566 277 105 568 minecraft:black_concrete
setblock 277 104 570 minecraft:orange_terracotta
fill 277 104 571 277 106 571 minecraft:black_concrete
setblock 277 104 586 minecraft:orange_terracotta
setblock 277 104 591 minecraft:orange_terracotta
fill 277 104 596 277 105 596 minecraft:black_concrete
setblock 277 104 597 minecraft:orange_terracotta
fill 277 104 598 277 105 598 minecraft:black_concrete
setblock 235 105 566 minecraft:black_concrete
setblock 235 105 570 minecraft:black_concrete
setblock 235 105 572 minecraft:black_concrete
setblock 237 105 599 minecraft:black_concrete
fill 240 105 599 240 107 599 minecraft:black_concrete
fill 243 105 580 249 105 580 minecraft:gray_concrete
setblock 243 105 599 minecraft:black_concrete
fill 245 105 579 249 105 579 minecraft:gray_concrete
fill 247 105 557 248 105 557 minecraft:black_concrete
fill 247 105 583 251 105 583 minecraft:gray_concrete
fill 248 105 582 250 105 582 minecraft:gray_concrete
setblock 249 105 578 minecraft:gray_concrete
setblock 249 105 581 minecraft:gray_concrete
fill 251 105 557 253 105 557 minecraft:black_concrete
fill 251 105 572 251 105 573 minecraft:gray_concrete
setblock 252 105 572 minecraft:gray_concrete
fill 253 105 585 261 105 585 minecraft:gray_concrete
setblock 255 105 599 minecraft:black_concrete
fill 258 105 586 261 105 586 minecraft:gray_concrete
fill 260 105 572 263 105 572 minecraft:gray_concrete
fill 260 105 584 261 105 584 minecraft:gray_concrete
fill 261 105 573 263 105 573 minecraft:gray_concrete
fill 261 105 583 262 105 583 minecraft:gray_concrete
fill 262 105 574 263 105 574 minecraft:gray_concrete
setblock 263 105 557 minecraft:black_concrete
fill 263 105 575 263 105 578 minecraft:gray_concrete
fill 264 105 577 267 105 578 minecraft:gray_concrete
setblock 267 105 599 minecraft:black_concrete
setblock 271 105 557 minecraft:black_concrete
setblock 275 105 557 minecraft:black_concrete
fill 277 105 558 277 106 558 minecraft:black_concrete
setblock 277 105 565 minecraft:black_concrete
setblock 277 105 570 minecraft:black_concrete
setblock 277 105 586 minecraft:black_concrete
setblock 277 105 591 minecraft:black_concrete
setblock 277 105 597 minecraft:black_concrete
fill 235 106 558 235 111 558 minecraft:orange_terracotta
setblock 235 106 559 minecraft:yellow_concrete
fill 235 106 560 235 106 562 minecraft:orange_terracotta
fill 235 106 563 235 107 563 minecraft:black_concrete
setblock 235 106 566 minecraft:orange_terracotta
fill 235 106 567 235 107 568 minecraft:yellow_concrete
fill 235 106 569 235 106 575 minecraft:orange_terracotta
fill 235 106 576 235 107 576 minecraft:yellow_concrete
setblock 235 106 577 minecraft:black_concrete
fill 235 106 578 235 111 578 minecraft:orange_terracotta
fill 235 106 579 235 106 580 minecraft:yellow_concrete
fill 235 106 581 235 106 586 minecraft:orange_terracotta
fill 235 106 587 235 107 588 minecraft:yellow_concrete
fill 235 106 589 235 111 589 minecraft:orange_terracotta
fill 235 106 591 235 106 598 minecraft:orange_terracotta
fill 235 106 599 236 106 599 minecraft:yellow_concrete
fill 236 106 557 239 106 557 minecraft:orange_terracotta
fill 237 106 599 239 109 599 minecraft:orange_terracotta
fill 240 106 557 241 107 557 minecraft:yellow_concrete
fill 241 106 599 243 106 599 minecraft:orange_terracotta
fill 242 106 557 247 107 557 minecraft:orange_terracotta
fill 243 106 580 247 106 580 minecraft:gray_concrete
fill 244 106 574 246 106 578 minecraft:gray_concrete
fill 244 106 599 244 107 599 minecraft:yellow_concrete
fill 245 106 579 246 106 579 minecraft:gray_concrete
fill 245 106 586 251 106 587 minecraft:gray_concrete
fill 245 106 599 245 111 599 minecraft:orange_terracotta
fill 246 106 584 249 106 585 minecraft:gray_concrete
fill 247 106 570 247 106 576 minecraft:gray_concrete
fill 247 106 583 248 106 583 minecraft:gray_concrete
setblock 247 106 599 minecraft:yellow_concrete
fill 248 106 557 249 106 557 minecraft:yellow_concrete
fill 248 106 570 248 106 573 minecraft:gray_concrete
fill 248 106 599 254 106 599 minecraft:orange_terracotta
fill 249 106 569 249 106 572 minecraft:gray_concrete
fill 250 106 557 251 107 557 minecraft:orange_terracotta
fill 250 106 569 254 106 569 minecraft:gray_concrete
setblock 250 106 571 minecraft:gray_concrete
setblock 250 106 585 minecraft:gray_concrete
setblock 251 106 570 minecraft:gray_concrete
fill 252 106 557 252 107 557 minecraft:yellow_concrete
fill 252 106 587 254 106 587 minecraft:gray_concrete
fill 253 106 557 254 106 557 minecraft:orange_terracotta
setblock 255 106 557 minecraft:black_concrete
fill 255 106 599 256 107 599 minecraft:yellow_concrete
fill 256 106 557 259 107 557 minecraft:orange_terracotta
fill 257 106 599 257 111 599 minecraft:orange_terracotta
fill 258 106 569 267 106 569 minecraft:gray_concrete
fill 258 106 587 263 106 587 minecraft:gray_concrete
setblock 258 106 599 minecraft:black_concrete
fill 259 106 599 263 106 599 minecraft:orange_terracotta
fill 260 106 557 261 107 557 minecraft:yellow_concrete
fill 261 106 570 272 106 570 minecraft:gray_concrete
setblock 261 106 586 minecraft:gray_concrete
fill 262 106 557 264 106 557 minecraft:orange_terracotta
fill 262 106 571 266 106 571 minecraft:gray_concrete
fill 262 106 585 272 106 585 minecraft:gray_concrete
fill 263 106 572 264 106 572 minecraft:gray_concrete
fill 263 106 584 272 106 584 minecraft:gray_concrete
setblock 264 106 573 minecraft:gray_concrete
fill 264 106 583 268 106 583 minecraft:gray_concrete
fill 264 106 599 264 107 599 minecraft:yellow_concrete
fill 265 106 576 269 106 576 minecraft:gray_concrete
fill 265 106 580 268 106 582 minecraft:gray_concrete
fill 265 106 599 266 107 599 minecraft:orange_terracotta
fill 266 106 557 267 106 557 minecraft:orange_terracotta
fill 266 106 577 267 106 579 minecraft:gray_concrete
fill 267 106 599 268 106 599 minecraft:yellow_concrete
fill 268 106 579 273 107 579 minecraft:gray_concrete
setblock 269 106 557 minecraft:yellow_concrete
setblock 269 106 599 minecraft:black_concrete
fill 270 106 557 271 111 557 minecraft:orange_terracotta
fill 270 106 599 274 106 599 minecraft:orange_terracotta
fill 272 106 557 273 107 557 minecraft:yellow_concrete
fill 274 106 557 277 107 557 minecraft:orange_terracotta
fill 275 106 599 276 107 599 minecraft:yellow_concrete
fill 277 106 559 277 111 559 minecraft:orange_terracotta
fill 277 106 560 277 106 561 minecraft:yellow_concrete
fill 277 106 562 277 106 570 minecraft:orange_terracotta
fill 277 106 572 277 107 573 minecraft:yellow_concrete
setblock 277 106 574 minecraft:black_concrete
fill 277 106 575 277 106 580 minecraft:orange_terracotta
setblock 277 106 581 minecraft:yellow_concrete
fill 277 106 582 277 107 583 minecraft:orange_terracotta
fill 277 106 584 277 107 584 minecraft:yellow_concrete
fill 277 106 585 277 106 586 minecraft:orange_terracotta
fill 277 106 590 277 111 591 minecraft:orange_terracotta
fill 277 106 592 277 106 593 minecraft:yellow_concrete
fill 277 106 594 277 106 599 minecraft:orange_terracotta
fill 235 107 557 236 109 557 minecraft:orange_terracotta
fill 235 107 559 235 109 560 minecraft:orange_terracotta
setblock 235 107 561 minecraft:black_concrete
fill 235 107 562 235 108 562 minecraft:orange_terracotta
setblock 235 107 564 minecraft:yellow_concrete
setblock 235 107 565 minecraft:orange_terracotta
setblock 235 107 566 minecraft:black_concrete
fill 235 107 569 235 107 574 minecraft:orange_terracotta
setblock 235 107 575 minecraft:yellow_concrete
setblock 235 107 577 minecraft:orange_terracotta
fill 235 107 579 235 108 582 minecraft:orange_terracotta
setblock 235 107 583 minecraft:black_concrete
fill 235 107 584 235 107 586 minecraft:orange_terracotta
fill 235 107 590 235 107 595 minecraft:orange_terracotta
setblock 235 107 596 minecraft:yellow_concrete
setblock 235 107 597 minecraft:orange_terracotta
setblock 235 107 598 minecraft:black_concrete
setblock 235 107 599 minecraft:yellow_concrete
fill 236 107 599 236 110 599 minecraft:orange_terracotta
setblock 237 107 557 minecraft:black_concrete
fill 238 107 557 239 111 557 minecraft:orange_terracotta
fill 241 107 582 245 107 582 minecraft:gray_concrete
fill 241 107 599 242 107 599 minecraft:orange_terracotta
fill 242 107 569 245 107 573 minecraft:gray_concrete
fill 242 107 581 245 107 581 minecraft:gray_concrete
fill 243 107 580 244 107 580 minecraft:gray_concrete
setblock 243 107 599 minecraft:yellow_concrete
fill 244 107 568 250 107 568 minecraft:gray_concrete
fill 244 107 574 244 107 578 minecraft:gray_concrete
fill 245 107 574 245 107 575 minecraft:gray_concrete
fill 245 107 586 248 107 587 minecraft:gray_concrete
fill 246 107 569 246 107 572 minecraft:gray_concrete
fill 246 107 584 246 107 585 minecraft:gray_concrete
fill 246 107 599 251 107 599 minecraft:orange_terracotta
fill 247 107 570 247 107 571 minecraft:gray_concrete
setblock 247 107 585 minecraft:gray_concrete
setblock 248 107 557 minecraft:black_concrete
setblock 248 107 570 minecraft:gray_concrete
fill 249 107 557 249 110 557 minecraft:orange_terracotta
setblock 249 107 569 minecraft:gray_concrete
setblock 249 107 587 minecraft:gray_concrete
fill 250 107 588 250 107 592 minecraft:gray_concrete
fill 251 107 589 253 107 592 minecraft:gray_concrete
setblock 252 107 599 minecraft:yellow_concrete
setblock 253 107 557 minecraft:yellow_concrete
fill 253 107 599 254 107 599 minecraft:orange_terracotta
fill 254 107 557 255 107 557 minecraft:orange_terracotta
setblock 254 107 590 minecraft:magma_block
fill 255 107 590 258 107 591 minecraft:gray_concrete
setblock 258 107 566 minecraft:magma_block
fill 258 107 599 259 107 599 minecraft:orange_terracotta
fill 260 107 599 261 107 599 minecraft:black_concrete
fill 262 107 557 263 107 557 minecraft:orange_terracotta
setblock 262 107 568 minecraft:gray_concrete
fill 262 107 588 268 107 588 minecraft:gray_concrete
setblock 262 107 599 minecraft:orange_terracotta
fill 263 107 569 267 107 569 minecraft:gray_concrete
setblock 263 107 587 minecraft:gray_concrete
setblock 263 107 599 minecraft:yellow_concrete
setblock 264 107 557 minecraft:yellow_concrete
fill 264 107 570 272 107 570 minecraft:gray_concrete
schedule function dropper:buildpart/137_2 1t
