fill 86 151 569 86 151 570 minecraft:cobbled_deepslate
setblock 86 151 571 minecraft:calcite
fill 86 151 572 86 153 573 minecraft:cobbled_deepslate
setblock 86 151 586 minecraft:calcite
fill 86 151 587 86 154 587 minecraft:cobbled_deepslate
setblock 86 151 591 minecraft:calcite
fill 86 151 592 86 154 592 minecraft:cobbled_deepslate
setblock 86 151 596 minecraft:calcite
fill 86 151 597 86 154 597 minecraft:cobbled_deepslate
setblock 87 151 570 minecraft:calcite
fill 87 151 571 87 154 571 minecraft:cobbled_deepslate
setblock 87 151 575 minecraft:calcite
fill 87 151 576 87 154 576 minecraft:cobbled_deepslate
fill 87 151 578 87 151 579 minecraft:cobbled_deepslate
setblock 87 151 580 minecraft:calcite
fill 87 151 581 87 154 581 minecraft:cobbled_deepslate
setblock 87 151 585 minecraft:calcite
fill 87 151 586 87 154 586 minecraft:cobbled_deepslate
setblock 87 151 590 minecraft:calcite
fill 87 151 591 87 154 591 minecraft:cobbled_deepslate
setblock 87 151 595 minecraft:calcite
fill 87 151 596 87 154 596 minecraft:cobbled_deepslate
setblock 88 151 564 minecraft:calcite
fill 88 151 565 88 152 565 minecraft:cobbled_deepslate
setblock 88 151 569 minecraft:calcite
fill 88 151 570 88 154 570 minecraft:cobbled_deepslate
setblock 88 151 574 minecraft:calcite
fill 88 151 575 88 154 575 minecraft:cobbled_deepslate
setblock 88 151 579 minecraft:calcite
fill 88 151 580 88 154 580 minecraft:cobbled_deepslate
setblock 88 151 584 minecraft:calcite
fill 88 151 585 88 154 585 minecraft:cobbled_deepslate
setblock 88 151 589 minecraft:calcite
fill 88 151 590 88 154 590 minecraft:cobbled_deepslate
setblock 88 151 594 minecraft:calcite
fill 88 151 595 88 154 595 minecraft:cobbled_deepslate
fill 48 152 564 48 153 564 minecraft:cobbled_deepslate
setblock 48 152 568 minecraft:calcite
fill 48 152 569 48 152 572 minecraft:cobbled_deepslate
setblock 48 152 573 minecraft:calcite
fill 48 152 574 48 155 574 minecraft:cobbled_deepslate
setblock 48 152 577 minecraft:cobbled_deepslate
setblock 48 152 578 minecraft:calcite
fill 48 152 579 48 155 579 minecraft:cobbled_deepslate
setblock 48 152 583 minecraft:calcite
fill 48 152 584 48 154 584 minecraft:cobbled_deepslate
setblock 48 152 588 minecraft:calcite
fill 48 152 589 48 155 589 minecraft:cobbled_deepslate
setblock 48 152 593 minecraft:calcite
fill 48 152 594 48 155 594 minecraft:cobbled_deepslate
setblock 48 152 598 minecraft:calcite
setblock 49 152 567 minecraft:calcite
fill 49 152 568 49 154 568 minecraft:cobbled_deepslate
setblock 49 152 572 minecraft:calcite
fill 49 152 573 49 155 573 minecraft:cobbled_deepslate
setblock 49 152 577 minecraft:calcite
fill 49 152 578 49 155 578 minecraft:cobbled_deepslate
setblock 49 152 588 minecraft:cobbled_deepslate
setblock 49 152 592 minecraft:calcite
fill 49 152 593 49 153 593 minecraft:cobbled_deepslate
setblock 50 152 571 minecraft:calcite
fill 50 152 572 50 154 572 minecraft:cobbled_deepslate
setblock 57 152 558 minecraft:cobbled_deepslate
setblock 58 152 558 minecraft:calcite
setblock 58 152 598 minecraft:calcite
fill 59 152 558 59 154 559 minecraft:cobbled_deepslate
setblock 59 152 597 minecraft:calcite
fill 59 152 598 62 152 598 minecraft:cobbled_deepslate
fill 60 152 597 63 152 597 minecraft:cobbled_deepslate
setblock 62 152 558 minecraft:cobbled_deepslate
setblock 62 152 559 minecraft:calcite
fill 62 152 560 62 155 560 minecraft:cobbled_deepslate
fill 62 152 596 64 152 596 minecraft:cobbled_deepslate
setblock 63 152 558 minecraft:calcite
fill 63 152 559 63 155 559 minecraft:cobbled_deepslate
setblock 63 152 598 minecraft:calcite
fill 64 152 558 64 155 558 minecraft:cobbled_deepslate
setblock 64 152 597 minecraft:calcite
fill 64 152 598 64 155 598 minecraft:cobbled_deepslate
setblock 65 152 596 minecraft:calcite
fill 65 152 597 65 155 597 minecraft:cobbled_deepslate
fill 66 152 596 68 153 596 minecraft:cobbled_deepslate
setblock 67 152 559 minecraft:calcite
fill 67 152 597 68 152 597 minecraft:cobbled_deepslate
setblock 68 152 558 minecraft:calcite
fill 68 152 559 68 153 559 minecraft:cobbled_deepslate
setblock 68 152 598 minecraft:calcite
fill 69 152 558 69 155 558 minecraft:cobbled_deepslate
setblock 69 152 597 minecraft:calcite
fill 69 152 598 69 155 598 minecraft:cobbled_deepslate
fill 70 152 597 70 155 597 minecraft:cobbled_deepslate
fill 72 152 597 73 152 597 minecraft:cobbled_deepslate
setblock 73 152 598 minecraft:calcite
setblock 74 152 597 minecraft:calcite
fill 74 152 598 74 155 598 minecraft:cobbled_deepslate
fill 75 152 597 78 152 597 minecraft:cobbled_deepslate
fill 76 152 558 77 152 558 minecraft:cobbled_deepslate
fill 76 152 596 79 152 596 minecraft:cobbled_deepslate
setblock 77 152 598 minecraft:cobbled_deepslate
setblock 78 152 558 minecraft:calcite
setblock 78 152 598 minecraft:calcite
fill 79 152 558 79 155 558 minecraft:cobbled_deepslate
fill 79 152 595 80 152 595 minecraft:cobbled_deepslate
setblock 79 152 597 minecraft:calcite
fill 79 152 598 79 155 598 minecraft:cobbled_deepslate
setblock 80 152 596 minecraft:calcite
fill 80 152 597 80 155 597 minecraft:cobbled_deepslate
setblock 81 152 594 minecraft:cobbled_deepslate
setblock 81 152 595 minecraft:calcite
fill 81 152 596 81 155 596 minecraft:cobbled_deepslate
setblock 82 152 594 minecraft:calcite
fill 82 152 595 82 155 595 minecraft:cobbled_deepslate
setblock 83 152 558 minecraft:calcite
fill 83 152 594 83 154 594 minecraft:cobbled_deepslate
setblock 83 152 598 minecraft:calcite
fill 84 152 558 84 155 558 minecraft:cobbled_deepslate
fill 84 152 590 84 152 591 minecraft:cobbled_deepslate
setblock 84 152 592 minecraft:calcite
fill 84 152 593 84 153 593 minecraft:cobbled_deepslate
setblock 84 152 597 minecraft:calcite
fill 84 152 598 84 155 598 minecraft:cobbled_deepslate
setblock 85 152 587 minecraft:cobbled_deepslate
setblock 85 152 591 minecraft:calcite
fill 85 152 592 85 155 592 minecraft:cobbled_deepslate
setblock 85 152 596 minecraft:calcite
fill 85 152 597 85 155 597 minecraft:cobbled_deepslate
setblock 86 152 570 minecraft:calcite
fill 86 152 571 86 153 571 minecraft:cobbled_deepslate
setblock 86 152 574 minecraft:cobbled_deepslate
setblock 86 152 575 minecraft:calcite
setblock 86 152 585 minecraft:calcite
fill 86 152 586 86 153 586 minecraft:cobbled_deepslate
setblock 86 152 590 minecraft:calcite
fill 86 152 591 86 155 591 minecraft:cobbled_deepslate
setblock 86 152 595 minecraft:calcite
fill 86 152 596 86 155 596 minecraft:cobbled_deepslate
setblock 87 152 569 minecraft:calcite
fill 87 152 570 87 155 570 minecraft:cobbled_deepslate
setblock 87 152 573 minecraft:cobbled_deepslate
setblock 87 152 574 minecraft:calcite
fill 87 152 575 87 155 575 minecraft:cobbled_deepslate
setblock 87 152 578 minecraft:cobbled_deepslate
setblock 87 152 579 minecraft:calcite
fill 87 152 580 87 155 580 minecraft:cobbled_deepslate
setblock 87 152 584 minecraft:calcite
fill 87 152 585 87 154 585 minecraft:cobbled_deepslate
setblock 87 152 589 minecraft:calcite
fill 87 152 590 87 155 590 minecraft:cobbled_deepslate
setblock 87 152 594 minecraft:calcite
fill 87 152 595 87 155 595 minecraft:cobbled_deepslate
setblock 88 152 568 minecraft:calcite
fill 88 152 569 88 155 569 minecraft:cobbled_deepslate
setblock 88 152 573 minecraft:calcite
fill 88 152 574 88 155 574 minecraft:cobbled_deepslate
setblock 88 152 578 minecraft:calcite
fill 88 152 579 88 155 579 minecraft:cobbled_deepslate
setblock 88 152 583 minecraft:calcite
fill 88 152 584 88 155 584 minecraft:cobbled_deepslate
setblock 88 152 588 minecraft:calcite
fill 88 152 589 88 155 589 minecraft:cobbled_deepslate
setblock 88 152 593 minecraft:calcite
fill 88 152 594 88 155 594 minecraft:cobbled_deepslate
setblock 88 152 598 minecraft:calcite
setblock 48 153 567 minecraft:calcite
fill 48 153 568 48 153 571 minecraft:cobbled_deepslate
setblock 48 153 572 minecraft:calcite
fill 48 153 573 48 156 573 minecraft:cobbled_deepslate
setblock 48 153 577 minecraft:calcite
fill 48 153 578 48 156 578 minecraft:cobbled_deepslate
setblock 48 153 582 minecraft:calcite
fill 48 153 583 48 154 583 minecraft:cobbled_deepslate
setblock 48 153 587 minecraft:calcite
fill 48 153 588 48 154 588 minecraft:cobbled_deepslate
setblock 48 153 592 minecraft:calcite
fill 48 153 593 48 155 593 minecraft:cobbled_deepslate
setblock 48 153 597 minecraft:calcite
setblock 48 153 598 minecraft:cobbled_deepslate
setblock 49 153 567 minecraft:cobbled_deepslate
setblock 49 153 571 minecraft:calcite
fill 49 153 572 49 156 572 minecraft:cobbled_deepslate
setblock 49 153 576 minecraft:calcite
fill 49 153 577 49 156 577 minecraft:cobbled_deepslate
setblock 49 153 591 minecraft:calcite
setblock 49 153 592 minecraft:cobbled_deepslate
setblock 50 153 570 minecraft:calcite
fill 50 153 571 50 154 571 minecraft:cobbled_deepslate
setblock 50 153 575 minecraft:calcite
setblock 56 153 558 minecraft:cobbled_deepslate
setblock 56 153 598 minecraft:cobbled_deepslate
setblock 57 153 558 minecraft:calcite
setblock 57 153 598 minecraft:calcite
fill 58 153 558 58 156 558 minecraft:cobbled_deepslate
setblock 58 153 597 minecraft:calcite
fill 58 153 598 61 153 598 minecraft:cobbled_deepslate
fill 59 153 597 62 153 597 minecraft:cobbled_deepslate
fill 60 153 596 63 153 596 minecraft:cobbled_deepslate
setblock 61 153 558 minecraft:cobbled_deepslate
setblock 61 153 559 minecraft:calcite
fill 61 153 560 61 156 560 minecraft:cobbled_deepslate
setblock 62 153 558 minecraft:calcite
fill 62 153 559 62 156 559 minecraft:cobbled_deepslate
setblock 62 153 598 minecraft:calcite
fill 63 153 558 63 156 558 minecraft:cobbled_deepslate
fill 63 153 560 64 153 560 minecraft:cobbled_deepslate
setblock 63 153 597 minecraft:calcite
fill 63 153 598 63 156 598 minecraft:cobbled_deepslate
setblock 64 153 596 minecraft:calcite
fill 64 153 597 64 156 597 minecraft:cobbled_deepslate
fill 65 153 596 65 156 596 minecraft:cobbled_deepslate
setblock 66 153 559 minecraft:calcite
setblock 67 153 558 minecraft:calcite
fill 67 153 559 67 155 559 minecraft:cobbled_deepslate
setblock 67 153 597 minecraft:cobbled_deepslate
setblock 67 153 598 minecraft:calcite
fill 68 153 558 68 156 558 minecraft:cobbled_deepslate
setblock 68 153 597 minecraft:calcite
fill 68 153 598 68 156 598 minecraft:cobbled_deepslate
fill 69 153 597 69 156 597 minecraft:cobbled_deepslate
setblock 72 153 558 minecraft:calcite
setblock 72 153 597 minecraft:cobbled_deepslate
setblock 72 153 598 minecraft:calcite
fill 73 153 558 76 153 558 minecraft:cobbled_deepslate
setblock 73 153 597 minecraft:calcite
fill 73 153 598 73 156 598 minecraft:cobbled_deepslate
fill 74 153 597 77 153 597 minecraft:cobbled_deepslate
fill 75 153 596 78 153 596 minecraft:cobbled_deepslate
setblock 77 153 558 minecraft:calcite
setblock 77 153 598 minecraft:calcite
fill 78 153 558 78 156 558 minecraft:cobbled_deepslate
fill 78 153 595 79 153 595 minecraft:cobbled_deepslate
setblock 78 153 597 minecraft:calcite
fill 78 153 598 78 156 598 minecraft:cobbled_deepslate
setblock 79 153 596 minecraft:calcite
fill 79 153 597 79 156 597 minecraft:cobbled_deepslate
setblock 80 153 594 minecraft:cobbled_deepslate
setblock 80 153 595 minecraft:calcite
fill 80 153 596 80 156 596 minecraft:cobbled_deepslate
setblock 81 153 594 minecraft:calcite
fill 81 153 595 81 156 595 minecraft:cobbled_deepslate
setblock 82 153 558 minecraft:calcite
fill 82 153 594 82 154 594 minecraft:cobbled_deepslate
setblock 82 153 598 minecraft:calcite
fill 83 153 558 83 156 558 minecraft:cobbled_deepslate
setblock 83 153 597 minecraft:calcite
fill 83 153 598 83 156 598 minecraft:cobbled_deepslate
setblock 84 153 591 minecraft:calcite
setblock 84 153 592 minecraft:cobbled_deepslate
setblock 84 153 595 minecraft:cobbled_deepslate
setblock 84 153 596 minecraft:calcite
fill 84 153 597 84 156 597 minecraft:cobbled_deepslate
setblock 85 153 590 minecraft:calcite
fill 85 153 591 85 154 591 minecraft:cobbled_deepslate
setblock 85 153 595 minecraft:calcite
fill 85 153 596 85 156 596 minecraft:cobbled_deepslate
setblock 86 153 570 minecraft:cobbled_deepslate
setblock 86 153 574 minecraft:calcite
fill 86 153 575 86 155 576 minecraft:cobbled_deepslate
setblock 86 153 589 minecraft:calcite
fill 86 153 590 86 155 590 minecraft:cobbled_deepslate
setblock 86 153 594 minecraft:calcite
fill 86 153 595 86 156 595 minecraft:cobbled_deepslate
setblock 87 153 568 minecraft:calcite
fill 87 153 569 87 154 569 minecraft:cobbled_deepslate
setblock 87 153 573 minecraft:calcite
fill 87 153 574 87 156 574 minecraft:cobbled_deepslate
setblock 87 153 578 minecraft:calcite
fill 87 153 579 87 156 579 minecraft:cobbled_deepslate
setblock 87 153 583 minecraft:calcite
fill 87 153 584 87 154 584 minecraft:cobbled_deepslate
setblock 87 153 588 minecraft:calcite
fill 87 153 589 87 155 589 minecraft:cobbled_deepslate
setblock 87 153 593 minecraft:calcite
fill 87 153 594 87 156 594 minecraft:cobbled_deepslate
setblock 87 153 598 minecraft:calcite
setblock 88 153 567 minecraft:calcite
fill 88 153 568 88 155 568 minecraft:cobbled_deepslate
setblock 88 153 572 minecraft:calcite
fill 88 153 573 88 156 573 minecraft:cobbled_deepslate
setblock 88 153 577 minecraft:calcite
fill 88 153 578 88 156 578 minecraft:cobbled_deepslate
setblock 88 153 582 minecraft:calcite
fill 88 153 583 88 156 583 minecraft:cobbled_deepslate
setblock 88 153 587 minecraft:calcite
fill 88 153 588 88 156 588 minecraft:cobbled_deepslate
setblock 88 153 592 minecraft:calcite
fill 88 153 593 88 156 593 minecraft:cobbled_deepslate
setblock 88 153 597 minecraft:calcite
fill 88 153 598 88 156 598 minecraft:cobbled_deepslate
setblock 48 154 566 minecraft:calcite
fill 48 154 567 48 154 570 minecraft:cobbled_deepslate
setblock 48 154 571 minecraft:calcite
fill 48 154 572 48 157 572 minecraft:cobbled_deepslate
setblock 48 154 576 minecraft:calcite
fill 48 154 577 48 157 577 minecraft:cobbled_deepslate
setblock 48 154 581 minecraft:calcite
fill 48 154 582 48 155 582 minecraft:cobbled_deepslate
setblock 48 154 586 minecraft:calcite
setblock 48 154 587 minecraft:cobbled_deepslate
setblock 48 154 591 minecraft:calcite
fill 48 154 592 48 155 592 minecraft:cobbled_deepslate
setblock 48 154 596 minecraft:calcite
fill 48 154 597 48 155 597 minecraft:cobbled_deepslate
setblock 49 154 570 minecraft:calcite
fill 49 154 571 49 157 571 minecraft:cobbled_deepslate
setblock 49 154 574 minecraft:cobbled_deepslate
setblock 49 154 575 minecraft:calcite
fill 49 154 576 49 157 576 minecraft:cobbled_deepslate
setblock 50 154 574 minecraft:calcite
setblock 56 154 558 minecraft:calcite
setblock 56 154 598 minecraft:calcite
fill 57 154 558 57 157 558 minecraft:cobbled_deepslate
fill 57 154 598 60 154 598 minecraft:cobbled_deepslate
fill 58 154 559 58 155 559 minecraft:cobbled_deepslate
fill 58 154 597 61 154 597 minecraft:cobbled_deepslate
setblock 60 154 558 minecraft:cobbled_deepslate
setblock 60 154 559 minecraft:calcite
fill 60 154 596 62 154 596 minecraft:cobbled_deepslate
setblock 61 154 558 minecraft:calcite
fill 61 154 559 61 157 559 minecraft:cobbled_deepslate
setblock 61 154 598 minecraft:calcite
fill 62 154 558 62 157 558 minecraft:cobbled_deepslate
setblock 62 154 597 minecraft:calcite
fill 62 154 598 62 157 598 minecraft:cobbled_deepslate
setblock 63 154 560 minecraft:cobbled_deepslate
setblock 63 154 596 minecraft:calcite
fill 63 154 597 63 157 597 minecraft:cobbled_deepslate
setblock 64 154 560 minecraft:calcite
fill 64 154 596 64 157 596 minecraft:cobbled_deepslate
setblock 65 154 559 minecraft:calcite
setblock 66 154 558 minecraft:calcite
fill 66 154 559 66 156 559 minecraft:cobbled_deepslate
fill 66 154 596 67 154 596 minecraft:cobbled_deepslate
setblock 66 154 598 minecraft:calcite
fill 67 154 558 67 157 558 minecraft:cobbled_deepslate
setblock 67 154 597 minecraft:calcite
fill 67 154 598 67 157 598 minecraft:cobbled_deepslate
setblock 68 154 596 minecraft:calcite
fill 68 154 597 68 157 597 minecraft:cobbled_deepslate
setblock 71 154 558 minecraft:calcite
setblock 71 154 598 minecraft:calcite
fill 72 154 558 75 154 558 minecraft:cobbled_deepslate
setblock 72 154 597 minecraft:calcite
fill 72 154 598 72 157 598 minecraft:cobbled_deepslate
fill 73 154 597 76 154 597 minecraft:cobbled_deepslate
fill 74 154 596 77 154 596 minecraft:cobbled_deepslate
setblock 76 154 558 minecraft:calcite
setblock 76 154 598 minecraft:calcite
fill 77 154 558 77 157 558 minecraft:cobbled_deepslate
fill 77 154 595 78 154 595 minecraft:cobbled_deepslate
setblock 77 154 597 minecraft:calcite
fill 77 154 598 77 157 598 minecraft:cobbled_deepslate
setblock 78 154 596 minecraft:calcite
fill 78 154 597 78 157 597 minecraft:cobbled_deepslate
setblock 79 154 595 minecraft:calcite
fill 79 154 596 79 157 596 minecraft:cobbled_deepslate
setblock 80 154 594 minecraft:calcite
fill 80 154 595 80 157 595 minecraft:cobbled_deepslate
setblock 81 154 558 minecraft:calcite
fill 81 154 594 81 155 594 minecraft:cobbled_deepslate
setblock 81 154 598 minecraft:calcite
fill 82 154 558 82 157 558 minecraft:cobbled_deepslate
setblock 82 154 597 minecraft:calcite
fill 82 154 598 82 157 598 minecraft:cobbled_deepslate
setblock 83 154 596 minecraft:calcite
fill 83 154 597 83 157 597 minecraft:cobbled_deepslate
setblock 84 154 595 minecraft:calcite
fill 84 154 596 84 157 596 minecraft:cobbled_deepslate
setblock 85 154 590 minecraft:cobbled_deepslate
setblock 85 154 594 minecraft:calcite
fill 85 154 595 85 155 595 minecraft:cobbled_deepslate
setblock 86 154 572 minecraft:cobbled_deepslate
setblock 86 154 573 minecraft:calcite
fill 86 154 574 86 155 574 minecraft:cobbled_deepslate
setblock 86 154 577 minecraft:cobbled_deepslate
setblock 86 154 588 minecraft:calcite
fill 86 154 589 86 155 589 minecraft:cobbled_deepslate
setblock 86 154 593 minecraft:calcite
fill 86 154 594 86 156 594 minecraft:cobbled_deepslate
setblock 86 154 598 minecraft:calcite
setblock 87 154 572 minecraft:calcite
fill 87 154 573 87 157 573 minecraft:cobbled_deepslate
setblock 87 154 577 minecraft:calcite
fill 87 154 578 87 157 578 minecraft:cobbled_deepslate
setblock 87 154 582 minecraft:calcite
setblock 87 154 583 minecraft:cobbled_deepslate
setblock 87 154 587 minecraft:calcite
fill 87 154 588 87 155 588 minecraft:cobbled_deepslate
setblock 87 154 592 minecraft:calcite
fill 87 154 593 87 156 593 minecraft:cobbled_deepslate
setblock 87 154 597 minecraft:calcite
fill 87 154 598 87 157 598 minecraft:cobbled_deepslate
setblock 88 154 567 minecraft:cobbled_deepslate
setblock 88 154 571 minecraft:calcite
fill 88 154 572 88 157 572 minecraft:cobbled_deepslate
setblock 88 154 576 minecraft:calcite
fill 88 154 577 88 157 577 minecraft:cobbled_deepslate
setblock 88 154 581 minecraft:calcite
fill 88 154 582 88 157 582 minecraft:cobbled_deepslate
setblock 88 154 586 minecraft:calcite
fill 88 154 587 88 156 587 minecraft:cobbled_deepslate
setblock 88 154 591 minecraft:calcite
fill 88 154 592 88 157 592 minecraft:cobbled_deepslate
setblock 88 154 596 minecraft:calcite
fill 88 154 597 88 157 597 minecraft:cobbled_deepslate
fill 48 155 566 48 155 569 minecraft:cobbled_deepslate
setblock 48 155 570 minecraft:calcite
fill 48 155 571 48 158 571 minecraft:cobbled_deepslate
setblock 48 155 575 minecraft:calcite
fill 48 155 576 48 158 576 minecraft:cobbled_deepslate
setblock 48 155 580 minecraft:calcite
fill 48 155 581 48 156 581 minecraft:cobbled_deepslate
setblock 48 155 590 minecraft:calcite
setblock 48 155 591 minecraft:cobbled_deepslate
setblock 48 155 595 minecraft:calcite
setblock 48 155 596 minecraft:cobbled_deepslate
setblock 49 155 569 minecraft:calcite
fill 49 155 570 49 156 570 minecraft:cobbled_deepslate
setblock 49 155 574 minecraft:calcite
fill 49 155 575 49 158 575 minecraft:cobbled_deepslate
setblock 50 155 573 minecraft:calcite
setblock 55 155 558 minecraft:calcite
setblock 55 155 598 minecraft:calcite
fill 56 155 558 56 158 558 minecraft:cobbled_deepslate
fill 56 155 598 59 155 598 minecraft:cobbled_deepslate
fill 57 155 559 57 156 559 minecraft:cobbled_deepslate
fill 57 155 597 60 155 597 minecraft:cobbled_deepslate
setblock 59 155 558 minecraft:cobbled_deepslate
setblock 59 155 559 minecraft:calcite
fill 59 155 596 61 155 596 minecraft:cobbled_deepslate
setblock 60 155 558 minecraft:calcite
fill 60 155 559 60 158 559 minecraft:cobbled_deepslate
setblock 60 155 598 minecraft:calcite
fill 61 155 558 61 158 558 minecraft:cobbled_deepslate
setblock 61 155 597 minecraft:calcite
fill 61 155 598 61 158 598 minecraft:cobbled_deepslate
setblock 62 155 596 minecraft:calcite
fill 62 155 597 62 158 597 minecraft:cobbled_deepslate
setblock 63 155 560 minecraft:calcite
fill 63 155 596 63 158 596 minecraft:cobbled_deepslate
setblock 64 155 559 minecraft:calcite
fill 64 155 560 64 159 561 minecraft:light_blue_stained_glass
setblock 65 155 558 minecraft:calcite
fill 65 155 559 65 158 559 minecraft:cobbled_deepslate
fill 65 155 560 65 159 560 minecraft:light_blue_stained_glass
setblock 65 155 598 minecraft:calcite
fill 66 155 558 66 158 558 minecraft:cobbled_deepslate
setblock 66 155 596 minecraft:cobbled_deepslate
setblock 66 155 597 minecraft:calcite
fill 66 155 598 66 158 598 minecraft:cobbled_deepslate
setblock 67 155 596 minecraft:calcite
fill 67 155 597 67 158 597 minecraft:cobbled_deepslate
setblock 70 155 558 minecraft:calcite
setblock 70 155 598 minecraft:calcite
fill 71 155 558 74 155 558 minecraft:cobbled_deepslate
setblock 71 155 597 minecraft:calcite
fill 71 155 598 71 158 598 minecraft:cobbled_deepslate
fill 72 155 597 75 155 597 minecraft:cobbled_deepslate
fill 74 155 596 76 155 596 minecraft:cobbled_deepslate
setblock 75 155 558 minecraft:calcite
setblock 75 155 598 minecraft:calcite
fill 76 155 558 76 158 558 minecraft:cobbled_deepslate
setblock 76 155 597 minecraft:calcite
fill 76 155 598 76 158 598 minecraft:cobbled_deepslate
setblock 77 155 595 minecraft:cobbled_deepslate
setblock 77 155 596 minecraft:calcite
fill 77 155 597 77 158 597 minecraft:cobbled_deepslate
setblock 78 155 595 minecraft:calcite
fill 78 155 596 78 158 596 minecraft:cobbled_deepslate
fill 79 155 595 79 158 595 minecraft:cobbled_deepslate
setblock 80 155 558 minecraft:calcite
setblock 80 155 598 minecraft:calcite
fill 81 155 558 81 158 558 minecraft:cobbled_deepslate
setblock 81 155 597 minecraft:calcite
fill 81 155 598 81 158 598 minecraft:cobbled_deepslate
setblock 82 155 596 minecraft:calcite
fill 82 155 597 82 158 597 minecraft:cobbled_deepslate
setblock 83 155 595 minecraft:calcite
fill 83 155 596 83 158 596 minecraft:cobbled_deepslate
setblock 84 155 595 minecraft:cobbled_deepslate
setblock 85 155 558 minecraft:calcite
setblock 85 155 593 minecraft:calcite
setblock 85 155 594 minecraft:cobbled_deepslate
setblock 85 155 598 minecraft:calcite
setblock 86 155 573 minecraft:cobbled_deepslate
setblock 86 155 592 minecraft:calcite
fill 86 155 593 86 156 593 minecraft:cobbled_deepslate
setblock 86 155 597 minecraft:calcite
fill 86 155 598 86 158 598 minecraft:cobbled_deepslate
setblock 87 155 571 minecraft:calcite
fill 87 155 572 87 156 572 minecraft:cobbled_deepslate
setblock 87 155 576 minecraft:calcite
fill 87 155 577 87 158 577 minecraft:cobbled_deepslate
setblock 87 155 587 minecraft:cobbled_deepslate
setblock 87 155 591 minecraft:calcite
fill 87 155 592 87 156 592 minecraft:cobbled_deepslate
setblock 87 155 596 minecraft:calcite
fill 87 155 597 87 156 597 minecraft:cobbled_deepslate
setblock 88 155 570 minecraft:calcite
fill 88 155 571 88 157 571 minecraft:cobbled_deepslate
setblock 88 155 575 minecraft:calcite
fill 88 155 576 88 158 576 minecraft:cobbled_deepslate
setblock 88 155 580 minecraft:calcite
fill 88 155 581 88 158 581 minecraft:cobbled_deepslate
setblock 88 155 585 minecraft:calcite
fill 88 155 586 88 156 586 minecraft:cobbled_deepslate
setblock 88 155 590 minecraft:calcite
fill 88 155 591 88 157 591 minecraft:cobbled_deepslate
setblock 88 155 595 minecraft:calcite
fill 88 155 596 88 158 596 minecraft:cobbled_deepslate
fill 48 156 567 48 156 568 minecraft:cobbled_deepslate
setblock 48 156 569 minecraft:calcite
fill 48 156 570 48 158 570 minecraft:cobbled_deepslate
setblock 48 156 574 minecraft:calcite
fill 48 156 575 48 159 575 minecraft:cobbled_deepslate
setblock 48 156 579 minecraft:calcite
fill 48 156 580 48 159 580 minecraft:cobbled_deepslate
setblock 48 156 594 minecraft:calcite
setblock 48 156 595 minecraft:cobbled_deepslate
setblock 49 156 573 minecraft:calcite
fill 49 156 574 49 158 574 minecraft:cobbled_deepslate
setblock 50 156 560 minecraft:light[level=14]
setblock 50 156 568 minecraft:light[level=14]
setblock 50 156 576 minecraft:light[level=14]
setblock 50 156 584 minecraft:light[level=14]
setblock 50 156 592 minecraft:light[level=14]
setblock 54 156 558 minecraft:calcite
setblock 54 156 598 minecraft:calcite
fill 55 156 558 55 159 558 minecraft:cobbled_deepslate
fill 55 156 598 58 156 598 minecraft:cobbled_deepslate
fill 57 156 597 59 156 597 minecraft:cobbled_deepslate
setblock 58 156 559 minecraft:calcite
setblock 58 156 560 minecraft:light[level=14]
setblock 58 156 568 minecraft:light[level=14]
setblock 58 156 576 minecraft:light[level=14]
setblock 58 156 584 minecraft:light[level=14]
setblock 58 156 592 minecraft:light[level=14]
setblock 59 156 558 minecraft:calcite
fill 59 156 559 59 159 559 minecraft:cobbled_deepslate
fill 59 156 596 60 156 596 minecraft:cobbled_deepslate
setblock 59 156 598 minecraft:calcite
fill 60 156 558 60 159 558 minecraft:cobbled_deepslate
setblock 60 156 597 minecraft:calcite
fill 60 156 598 60 159 598 minecraft:cobbled_deepslate
setblock 61 156 596 minecraft:calcite
fill 61 156 597 61 159 597 minecraft:cobbled_deepslate
setblock 62 156 560 minecraft:calcite
fill 62 156 596 62 158 596 minecraft:cobbled_deepslate
setblock 63 156 559 minecraft:calcite
fill 63 156 560 63 159 561 minecraft:light_blue_stained_glass
setblock 64 156 558 minecraft:calcite
fill 64 156 559 64 159 559 minecraft:cobbled_deepslate
fill 64 156 562 64 160 562 minecraft:light_blue_stained_glass
setblock 64 156 598 minecraft:calcite
fill 65 156 558 65 159 558 minecraft:cobbled_deepslate
fill 65 156 561 65 159 561 minecraft:light_blue_stained_glass
setblock 65 156 597 minecraft:calcite
fill 65 156 598 65 159 598 minecraft:cobbled_deepslate
fill 66 156 560 66 158 560 minecraft:light_blue_stained_glass
setblock 66 156 568 minecraft:light[level=14]
setblock 66 156 576 minecraft:light[level=14]
setblock 66 156 592 minecraft:light[level=14]
setblock 66 156 596 minecraft:calcite
fill 66 156 597 66 159 597 minecraft:cobbled_deepslate
setblock 69 156 558 minecraft:calcite
setblock 69 156 598 minecraft:calcite
fill 70 156 558 73 156 558 minecraft:cobbled_deepslate
setblock 70 156 597 minecraft:calcite
fill 70 156 598 70 159 598 minecraft:cobbled_deepslate
fill 71 156 597 74 156 597 minecraft:cobbled_deepslate
setblock 74 156 558 minecraft:calcite
setblock 74 156 560 minecraft:light[level=14]
setblock 74 156 568 minecraft:light[level=14]
setblock 74 156 576 minecraft:light[level=14]
setblock 74 156 584 minecraft:light[level=14]
setblock 74 156 592 minecraft:light[level=14]
fill 74 156 596 75 156 596 minecraft:cobbled_deepslate
setblock 74 156 598 minecraft:calcite
fill 75 156 558 75 159 558 minecraft:cobbled_deepslate
setblock 75 156 597 minecraft:calcite
fill 75 156 598 75 159 598 minecraft:cobbled_deepslate
setblock 76 156 596 minecraft:calcite
fill 76 156 597 76 159 597 minecraft:cobbled_deepslate
setblock 77 156 595 minecraft:calcite
fill 77 156 596 77 159 596 minecraft:cobbled_deepslate
fill 78 156 595 78 158 595 minecraft:cobbled_deepslate
setblock 79 156 558 minecraft:calcite
setblock 79 156 598 minecraft:calcite
fill 80 156 558 80 159 558 minecraft:cobbled_deepslate
setblock 80 156 597 minecraft:calcite
fill 80 156 598 80 159 598 minecraft:cobbled_deepslate
setblock 81 156 596 minecraft:calcite
fill 81 156 597 81 159 597 minecraft:cobbled_deepslate
setblock 82 156 560 minecraft:light[level=14]
setblock 82 156 568 minecraft:light[level=14]
setblock 82 156 576 minecraft:light[level=14]
setblock 82 156 584 minecraft:light[level=14]
setblock 82 156 592 minecraft:light[level=14]
setblock 82 156 595 minecraft:calcite
fill 82 156 596 82 159 596 minecraft:cobbled_deepslate
setblock 83 156 595 minecraft:cobbled_deepslate
setblock 84 156 558 minecraft:calcite
setblock 84 156 598 minecraft:calcite
setblock 85 156 597 minecraft:calcite
fill 85 156 598 85 159 598 minecraft:cobbled_deepslate
fill 86 156 597 86 157 597 minecraft:cobbled_deepslate
setblock 87 156 575 minecraft:calcite
fill 87 156 576 87 159 576 minecraft:cobbled_deepslate
setblock 87 156 580 minecraft:calcite
setblock 87 156 590 minecraft:calcite
setblock 87 156 591 minecraft:cobbled_deepslate
setblock 87 156 595 minecraft:calcite
setblock 87 156 596 minecraft:cobbled_deepslate
setblock 88 156 570 minecraft:cobbled_deepslate
setblock 88 156 574 minecraft:calcite
fill 88 156 575 88 159 575 minecraft:cobbled_deepslate
setblock 88 156 579 minecraft:calcite
fill 88 156 580 88 159 580 minecraft:cobbled_deepslate
setblock 88 156 584 minecraft:calcite
setblock 88 156 585 minecraft:cobbled_deepslate
setblock 88 156 589 minecraft:calcite
fill 88 156 590 88 157 590 minecraft:cobbled_deepslate
setblock 88 156 594 minecraft:calcite
fill 88 156 595 88 158 595 minecraft:cobbled_deepslate
setblock 48 157 569 minecraft:cobbled_deepslate
setblock 48 157 573 minecraft:calcite
fill 48 157 574 48 160 574 minecraft:cobbled_deepslate
setblock 48 157 578 minecraft:calcite
fill 48 157 579 48 160 579 minecraft:cobbled_deepslate
setblock 49 157 572 minecraft:calcite
fill 49 157 573 49 158 573 minecraft:cobbled_deepslate
setblock 49 157 577 minecraft:calcite
fill 54 157 558 54 160 558 minecraft:cobbled_deepslate
fill 54 157 598 57 157 598 minecraft:cobbled_deepslate
setblock 56 157 559 minecraft:cobbled_deepslate
fill 56 157 597 58 157 597 minecraft:cobbled_deepslate
setblock 57 157 559 minecraft:calcite
setblock 58 157 558 minecraft:calcite
fill 58 157 559 58 160 559 minecraft:cobbled_deepslate
setblock 58 157 598 minecraft:calcite
fill 59 157 558 59 160 558 minecraft:cobbled_deepslate
setblock 59 157 596 minecraft:cobbled_deepslate
setblock 59 157 597 minecraft:calcite
fill 59 157 598 59 160 598 minecraft:cobbled_deepslate
setblock 60 157 560 minecraft:cobbled_deepslate
setblock 60 157 596 minecraft:calcite
fill 60 157 597 60 160 597 minecraft:cobbled_deepslate
setblock 61 157 560 minecraft:calcite
fill 61 157 596 61 158 596 minecraft:cobbled_deepslate
setblock 62 157 559 minecraft:calcite
fill 62 157 560 62 158 561 minecraft:light_blue_stained_glass
setblock 63 157 558 minecraft:calcite
fill 63 157 559 63 160 559 minecraft:cobbled_deepslate
fill 63 157 562 63 159 562 minecraft:light_blue_stained_glass
setblock 63 157 598 minecraft:calcite
fill 64 157 558 64 160 558 minecraft:cobbled_deepslate
fill 64 157 563 64 160 563 minecraft:light_blue_stained_glass
setblock 64 157 597 minecraft:calcite
fill 64 157 598 64 160 598 minecraft:cobbled_deepslate
fill 65 157 562 65 159 562 minecraft:light_blue_stained_glass
fill 65 157 597 65 160 597 minecraft:cobbled_deepslate
fill 66 157 559 66 158 559 minecraft:light_blue_stained_glass
fill 66 157 561 66 158 561 minecraft:light_blue_stained_glass
setblock 68 157 558 minecraft:calcite
setblock 68 157 598 minecraft:calcite
fill 69 157 558 72 157 558 minecraft:cobbled_deepslate
setblock 69 157 597 minecraft:calcite
fill 69 157 598 69 160 598 minecraft:cobbled_deepslate
fill 70 157 597 73 157 597 minecraft:cobbled_deepslate
setblock 73 157 558 minecraft:calcite
setblock 73 157 598 minecraft:calcite
fill 74 157 558 74 160 558 minecraft:cobbled_deepslate
setblock 74 157 596 minecraft:cobbled_deepslate
setblock 74 157 597 minecraft:calcite
fill 74 157 598 74 160 598 minecraft:cobbled_deepslate
setblock 75 157 596 minecraft:calcite
fill 75 157 597 75 160 597 minecraft:cobbled_deepslate
fill 76 157 596 76 160 596 minecraft:cobbled_deepslate
setblock 77 157 595 minecraft:cobbled_deepslate
setblock 78 157 558 minecraft:calcite
setblock 78 157 598 minecraft:calcite
fill 79 157 558 79 160 558 minecraft:cobbled_deepslate
setblock 79 157 597 minecraft:calcite
fill 79 157 598 79 160 598 minecraft:cobbled_deepslate
setblock 80 157 596 minecraft:calcite
fill 80 157 597 80 160 597 minecraft:cobbled_deepslate
setblock 81 157 595 minecraft:calcite
fill 81 157 596 81 160 596 minecraft:cobbled_deepslate
setblock 82 157 595 minecraft:cobbled_deepslate
setblock 83 157 558 minecraft:calcite
setblock 83 157 598 minecraft:calcite
setblock 84 157 558 minecraft:cobbled_deepslate
setblock 84 157 597 minecraft:calcite
fill 84 157 598 84 160 598 minecraft:cobbled_deepslate
fill 85 157 597 85 158 597 minecraft:cobbled_deepslate
setblock 87 157 574 minecraft:calcite
fill 87 157 575 87 159 575 minecraft:cobbled_deepslate
setblock 87 157 579 minecraft:calcite
setblock 87 157 594 minecraft:calcite
setblock 87 157 595 minecraft:cobbled_deepslate
setblock 88 157 573 minecraft:calcite
fill 88 157 574 88 160 574 minecraft:cobbled_deepslate
setblock 88 157 578 minecraft:calcite
fill 88 157 579 88 160 579 minecraft:cobbled_deepslate
setblock 88 157 593 minecraft:calcite
fill 88 157 594 88 158 594 minecraft:cobbled_deepslate
setblock 88 157 598 minecraft:calcite
setblock 48 158 572 minecraft:calcite
fill 48 158 573 48 161 573 minecraft:cobbled_deepslate
setblock 48 158 577 minecraft:calcite
fill 48 158 578 48 161 578 minecraft:cobbled_deepslate
setblock 49 158 576 minecraft:calcite
setblock 49 158 577 minecraft:cobbled_deepslate
fill 53 158 558 53 161 558 minecraft:cobbled_deepslate
fill 54 158 598 56 158 598 minecraft:cobbled_deepslate
setblock 56 158 559 minecraft:calcite
fill 56 158 596 58 163 596 minecraft:light_blue_stained_glass
fill 56 158 597 57 158 597 minecraft:cobbled_deepslate
setblock 57 158 558 minecraft:calcite
fill 57 158 559 57 161 559 minecraft:cobbled_deepslate
setblock 57 158 598 minecraft:calcite
fill 58 158 558 58 161 558 minecraft:cobbled_deepslate
setblock 58 158 597 minecraft:calcite
fill 58 158 598 58 161 598 minecraft:cobbled_deepslate
fill 59 158 597 59 161 597 minecraft:cobbled_deepslate
setblock 60 158 560 minecraft:calcite
setblock 60 158 596 minecraft:cobbled_deepslate
setblock 61 158 559 minecraft:calcite
setblock 62 158 558 minecraft:calcite
fill 62 158 559 62 161 559 minecraft:cobbled_deepslate
setblock 62 158 598 minecraft:calcite
fill 63 158 558 63 161 558 minecraft:cobbled_deepslate
fill 63 158 563 63 159 563 minecraft:light_blue_stained_glass
setblock 63 158 597 minecraft:calcite
fill 63 158 598 63 161 598 minecraft:cobbled_deepslate
fill 64 158 564 64 160 564 minecraft:light_blue_stained_glass
fill 64 158 597 64 161 597 minecraft:cobbled_deepslate
fill 65 158 563 65 159 563 minecraft:light_blue_stained_glass
setblock 67 158 558 minecraft:calcite
setblock 67 158 598 minecraft:calcite
fill 68 158 558 71 158 558 minecraft:cobbled_deepslate
setblock 68 158 597 minecraft:calcite
fill 68 158 598 68 161 598 minecraft:cobbled_deepslate
fill 69 158 597 72 158 597 minecraft:cobbled_deepslate
setblock 72 158 558 minecraft:calcite
setblock 72 158 598 minecraft:calcite
fill 73 158 558 73 161 558 minecraft:cobbled_deepslate
setblock 73 158 597 minecraft:calcite
fill 73 158 598 73 161 598 minecraft:cobbled_deepslate
setblock 74 158 596 minecraft:calcite
fill 74 158 597 74 161 597 minecraft:cobbled_deepslate
fill 75 158 596 75 161 596 minecraft:cobbled_deepslate
setblock 77 158 558 minecraft:calcite
setblock 77 158 598 minecraft:calcite
fill 78 158 558 78 161 558 minecraft:cobbled_deepslate
setblock 78 158 597 minecraft:calcite
fill 78 158 598 78 161 598 minecraft:cobbled_deepslate
setblock 79 158 596 minecraft:calcite
fill 79 158 597 79 161 597 minecraft:cobbled_deepslate
setblock 80 158 595 minecraft:calcite
fill 80 158 596 80 161 596 minecraft:cobbled_deepslate
setblock 82 158 558 minecraft:calcite
setblock 82 158 598 minecraft:calcite
fill 83 158 558 83 161 558 minecraft:cobbled_deepslate
setblock 83 158 597 minecraft:calcite
fill 83 158 598 83 161 598 minecraft:cobbled_deepslate
fill 84 158 597 84 159 597 minecraft:cobbled_deepslate
setblock 87 158 574 minecraft:cobbled_deepslate
setblock 87 158 578 minecraft:calcite
fill 87 158 579 87 161 579 minecraft:cobbled_deepslate
setblock 87 158 598 minecraft:calcite
setblock 88 158 572 minecraft:calcite
fill 88 158 573 88 161 573 minecraft:cobbled_deepslate
setblock 88 158 577 minecraft:calcite
fill 88 158 578 88 161 578 minecraft:cobbled_deepslate
setblock 88 158 582 minecraft:calcite
setblock 88 158 597 minecraft:calcite
setblock 48 159 571 minecraft:calcite
fill 48 159 572 48 162 572 minecraft:cobbled_deepslate
setblock 48 159 576 minecraft:calcite
fill 48 159 577 48 162 577 minecraft:cobbled_deepslate
setblock 49 159 575 minecraft:calcite
setblock 49 159 576 minecraft:cobbled_deepslate
fill 52 159 558 52 162 558 minecraft:cobbled_deepslate
fill 53 159 598 55 159 598 minecraft:cobbled_deepslate
setblock 55 159 559 minecraft:calcite
fill 55 159 596 55 160 597 minecraft:light_blue_stained_glass
setblock 56 159 558 minecraft:calcite
fill 56 159 559 56 162 559 minecraft:cobbled_deepslate
fill 56 159 595 58 162 595 minecraft:light_blue_stained_glass
setblock 56 159 597 minecraft:cobbled_deepslate
setblock 56 159 598 minecraft:calcite
fill 57 159 558 57 162 558 minecraft:cobbled_deepslate
fill 57 159 594 57 163 594 minecraft:light_blue_stained_glass
setblock 57 159 597 minecraft:calcite
fill 57 159 598 57 162 598 minecraft:cobbled_deepslate
setblock 58 159 560 minecraft:cobbled_deepslate
fill 58 159 597 58 162 597 minecraft:cobbled_deepslate
setblock 59 159 560 minecraft:calcite
fill 59 159 596 59 166 596 minecraft:light_blue_stained_glass
setblock 60 159 559 minecraft:calcite
fill 60 159 560 60 162 560 minecraft:cobbled_deepslate
setblock 61 159 558 minecraft:calcite
fill 61 159 559 61 162 559 minecraft:cobbled_deepslate
setblock 61 159 598 minecraft:calcite
fill 62 159 558 62 162 558 minecraft:cobbled_deepslate
setblock 62 159 597 minecraft:calcite
fill 62 159 598 62 162 598 minecraft:cobbled_deepslate
setblock 63 159 564 minecraft:light_blue_stained_glass
fill 63 159 597 63 162 597 minecraft:cobbled_deepslate
fill 64 159 565 64 160 565 minecraft:light_blue_stained_glass
setblock 65 159 559 minecraft:calcite
setblock 65 159 564 minecraft:light_blue_stained_glass
setblock 66 159 558 minecraft:calcite
setblock 66 159 598 minecraft:calcite
fill 67 159 558 70 159 558 minecraft:cobbled_deepslate
setblock 67 159 597 minecraft:calcite
fill 67 159 598 67 162 598 minecraft:cobbled_deepslate
fill 68 159 597 71 159 597 minecraft:cobbled_deepslate
setblock 71 159 558 minecraft:calcite
setblock 71 159 598 minecraft:calcite
fill 72 159 558 72 162 558 minecraft:cobbled_deepslate
setblock 72 159 597 minecraft:calcite
fill 72 159 598 72 162 598 minecraft:cobbled_deepslate
fill 73 159 597 73 162 597 minecraft:cobbled_deepslate
fill 74 159 596 74 162 596 minecraft:cobbled_deepslate
setblock 76 159 558 minecraft:calcite
setblock 76 159 598 minecraft:calcite
fill 77 159 558 77 162 558 minecraft:cobbled_deepslate
setblock 77 159 597 minecraft:calcite
fill 77 159 598 77 162 598 minecraft:cobbled_deepslate
setblock 78 159 596 minecraft:calcite
fill 78 159 597 78 162 597 minecraft:cobbled_deepslate
fill 79 159 596 79 162 596 minecraft:cobbled_deepslate
setblock 81 159 558 minecraft:calcite
setblock 81 159 598 minecraft:calcite
fill 82 159 558 82 162 558 minecraft:cobbled_deepslate
setblock 82 159 597 minecraft:calcite
fill 82 159 598 82 162 598 minecraft:cobbled_deepslate
fill 83 159 597 83 161 597 minecraft:cobbled_deepslate
setblock 86 159 598 minecraft:calcite
setblock 87 159 577 minecraft:calcite
fill 87 159 578 87 162 578 minecraft:cobbled_deepslate
setblock 88 159 576 minecraft:calcite
fill 88 159 577 88 162 577 minecraft:cobbled_deepslate
setblock 88 159 581 minecraft:calcite
setblock 48 160 575 minecraft:calcite
fill 48 160 576 48 163 576 minecraft:cobbled_deepslate
setblock 48 160 580 minecraft:calcite
fill 51 160 558 51 163 558 minecraft:cobbled_deepslate
fill 53 160 598 54 160 598 minecraft:cobbled_deepslate
setblock 54 160 559 minecraft:calcite
fill 54 160 597 54 161 597 minecraft:light_blue_stained_glass
setblock 55 160 558 minecraft:calcite
fill 55 160 559 55 163 559 minecraft:cobbled_deepslate
fill 55 160 595 55 162 595 minecraft:light_blue_stained_glass
setblock 55 160 598 minecraft:calcite
fill 56 160 558 56 163 558 minecraft:cobbled_deepslate
fill 56 160 593 56 162 594 minecraft:light_blue_stained_glass
setblock 56 160 597 minecraft:calcite
fill 56 160 598 56 163 598 minecraft:cobbled_deepslate
setblock 57 160 560 minecraft:cobbled_deepslate
fill 57 160 593 58 162 593 minecraft:light_blue_stained_glass
fill 57 160 597 57 163 597 minecraft:cobbled_deepslate
setblock 58 160 560 minecraft:calcite
fill 58 160 594 58 162 594 minecraft:light_blue_stained_glass
setblock 59 160 559 minecraft:calcite
fill 59 160 560 59 163 560 minecraft:cobbled_deepslate
fill 59 160 595 59 165 595 minecraft:light_blue_stained_glass
setblock 60 160 558 minecraft:calcite
fill 60 160 559 60 163 559 minecraft:cobbled_deepslate
setblock 60 160 598 minecraft:calcite
fill 61 160 558 61 163 558 minecraft:cobbled_deepslate
fill 61 160 560 61 161 560 minecraft:cobbled_deepslate
setblock 61 160 597 minecraft:calcite
fill 61 160 598 61 163 598 minecraft:cobbled_deepslate
fill 62 160 597 62 163 597 minecraft:cobbled_deepslate
setblock 64 160 559 minecraft:calcite
setblock 65 160 558 minecraft:calcite
fill 65 160 559 65 163 559 minecraft:cobbled_deepslate
setblock 65 160 598 minecraft:calcite
fill 66 160 558 69 160 558 minecraft:cobbled_deepslate
setblock 66 160 597 minecraft:calcite
fill 66 160 598 66 163 598 minecraft:cobbled_deepslate
setblock 67 160 597 minecraft:cobbled_deepslate
fill 69 160 597 70 160 597 minecraft:cobbled_deepslate
setblock 70 160 558 minecraft:calcite
setblock 70 160 598 minecraft:calcite
fill 71 160 558 71 163 558 minecraft:cobbled_deepslate
setblock 71 160 597 minecraft:calcite
fill 71 160 598 71 163 598 minecraft:cobbled_deepslate
fill 72 160 597 72 163 597 minecraft:cobbled_deepslate
setblock 75 160 558 minecraft:calcite
setblock 75 160 598 minecraft:calcite
fill 76 160 558 76 163 558 minecraft:cobbled_deepslate
setblock 76 160 597 minecraft:calcite
fill 76 160 598 76 163 598 minecraft:cobbled_deepslate
setblock 77 160 596 minecraft:calcite
fill 77 160 597 77 163 597 minecraft:cobbled_deepslate
fill 78 160 596 78 163 596 minecraft:cobbled_deepslate
setblock 80 160 558 minecraft:calcite
setblock 80 160 598 minecraft:calcite
fill 81 160 558 81 163 558 minecraft:cobbled_deepslate
setblock 81 160 597 minecraft:calcite
fill 81 160 598 81 163 598 minecraft:cobbled_deepslate
fill 82 160 597 82 163 597 minecraft:cobbled_deepslate
setblock 85 160 598 minecraft:calcite
setblock 86 160 598 minecraft:cobbled_deepslate
setblock 87 160 576 minecraft:calcite
fill 87 160 577 87 163 577 minecraft:cobbled_deepslate
setblock 88 160 575 minecraft:calcite
fill 88 160 576 88 163 576 minecraft:cobbled_deepslate
setblock 88 160 580 minecraft:calcite
fill 88 160 581 88 162 582 minecraft:cobbled_deepslate
setblock 48 161 574 minecraft:calcite
fill 48 161 575 48 164 575 minecraft:cobbled_deepslate
setblock 48 161 579 minecraft:calcite
fill 48 161 580 48 164 580 minecraft:cobbled_deepslate
fill 50 161 558 50 164 558 minecraft:cobbled_deepslate
fill 52 161 598 53 161 598 minecraft:cobbled_deepslate
setblock 53 161 559 minecraft:calcite
setblock 54 161 558 minecraft:calcite
fill 54 161 559 54 164 559 minecraft:cobbled_deepslate
setblock 54 161 598 minecraft:calcite
fill 55 161 558 55 164 558 minecraft:cobbled_deepslate
fill 55 161 560 56 161 560 minecraft:cobbled_deepslate
setblock 55 161 594 minecraft:light_blue_stained_glass
fill 55 161 596 55 162 596 minecraft:light_blue_stained_glass
setblock 55 161 597 minecraft:calcite
fill 55 161 598 55 164 598 minecraft:cobbled_deepslate
fill 56 161 592 58 162 592 minecraft:light_blue_stained_glass
fill 56 161 597 56 164 597 minecraft:cobbled_deepslate
setblock 57 161 560 minecraft:calcite
fill 57 161 591 57 162 591 minecraft:light_blue_stained_glass
setblock 58 161 559 minecraft:calcite
fill 58 161 560 58 164 560 minecraft:cobbled_deepslate
setblock 59 161 558 minecraft:calcite
fill 59 161 559 59 164 559 minecraft:cobbled_deepslate
setblock 59 161 594 minecraft:light_blue_stained_glass
setblock 59 161 598 minecraft:calcite
fill 60 161 558 60 164 558 minecraft:cobbled_deepslate
setblock 60 161 597 minecraft:calcite
fill 60 161 598 60 164 598 minecraft:cobbled_deepslate
fill 61 161 597 61 164 597 minecraft:cobbled_deepslate
setblock 63 161 559 minecraft:calcite
setblock 64 161 558 minecraft:calcite
fill 64 161 559 64 164 559 minecraft:cobbled_deepslate
setblock 64 161 598 minecraft:calcite
fill 65 161 558 68 161 558 minecraft:cobbled_deepslate
setblock 65 161 597 minecraft:calcite
fill 65 161 598 65 164 598 minecraft:cobbled_deepslate
fill 66 161 597 66 164 597 minecraft:cobbled_deepslate
setblock 69 161 558 minecraft:calcite
setblock 69 161 597 minecraft:cobbled_deepslate
setblock 69 161 598 minecraft:calcite
fill 70 161 558 70 164 558 minecraft:cobbled_deepslate
setblock 70 161 597 minecraft:calcite
fill 70 161 598 70 164 598 minecraft:cobbled_deepslate
fill 71 161 597 71 164 597 minecraft:cobbled_deepslate
setblock 74 161 558 minecraft:calcite
setblock 74 161 598 minecraft:calcite
fill 75 161 558 75 164 558 minecraft:cobbled_deepslate
setblock 75 161 597 minecraft:calcite
fill 75 161 598 75 164 598 minecraft:cobbled_deepslate
fill 76 161 559 77 161 559 minecraft:cobbled_deepslate
setblock 76 161 596 minecraft:calcite
fill 76 161 597 76 164 597 minecraft:cobbled_deepslate
fill 77 161 596 77 164 596 minecraft:cobbled_deepslate
setblock 78 161 559 minecraft:calcite
setblock 79 161 558 minecraft:calcite
fill 79 161 559 79 164 559 minecraft:cobbled_deepslate
setblock 79 161 598 minecraft:calcite
fill 80 161 558 80 164 558 minecraft:cobbled_deepslate
setblock 80 161 597 minecraft:calcite
fill 80 161 598 80 164 598 minecraft:cobbled_deepslate
fill 81 161 597 81 164 597 minecraft:cobbled_deepslate
setblock 84 161 598 minecraft:calcite
fill 85 161 598 85 162 598 minecraft:cobbled_deepslate
fill 87 161 576 87 164 576 minecraft:cobbled_deepslate
setblock 87 161 580 minecraft:calcite
setblock 88 161 574 minecraft:calcite
fill 88 161 575 88 164 575 minecraft:cobbled_deepslate
setblock 88 161 579 minecraft:calcite
fill 88 161 580 88 164 580 minecraft:cobbled_deepslate
setblock 48 162 558 minecraft:calcite
fill 48 162 559 48 165 559 minecraft:cobbled_deepslate
setblock 48 162 573 minecraft:calcite
fill 48 162 574 48 165 574 minecraft:cobbled_deepslate
setblock 48 162 578 minecraft:calcite
fill 48 162 579 48 165 579 minecraft:cobbled_deepslate
fill 48 162 581 48 163 581 minecraft:cobbled_deepslate
fill 49 162 558 49 165 558 minecraft:cobbled_deepslate
setblock 49 162 577 minecraft:calcite
setblock 51 162 559 minecraft:cobbled_deepslate
setblock 52 162 559 minecraft:calcite
setblock 52 162 598 minecraft:cobbled_deepslate
setblock 53 162 558 minecraft:calcite
fill 53 162 559 53 165 559 minecraft:cobbled_deepslate
setblock 53 162 598 minecraft:calcite
fill 54 162 558 54 165 558 minecraft:cobbled_deepslate
fill 54 162 560 55 162 560 minecraft:cobbled_deepslate
setblock 54 162 597 minecraft:calcite
fill 54 162 598 54 165 598 minecraft:cobbled_deepslate
fill 55 162 597 55 165 597 minecraft:cobbled_deepslate
setblock 56 162 560 minecraft:calcite
setblock 57 162 559 minecraft:calcite
fill 57 162 560 57 165 560 minecraft:cobbled_deepslate
setblock 58 162 558 minecraft:calcite
fill 58 162 559 58 165 559 minecraft:cobbled_deepslate
setblock 58 162 598 minecraft:calcite
fill 59 162 558 59 165 558 minecraft:cobbled_deepslate
setblock 59 162 597 minecraft:calcite
fill 59 162 598 59 165 598 minecraft:cobbled_deepslate
fill 60 162 593 60 162 595 minecraft:light_blue_stained_glass
fill 60 162 597 60 165 597 minecraft:cobbled_deepslate
setblock 61 162 560 minecraft:calcite
setblock 62 162 559 minecraft:calcite
fill 62 162 560 62 165 560 minecraft:cobbled_deepslate
setblock 63 162 558 minecraft:calcite
fill 63 162 559 63 165 559 minecraft:cobbled_deepslate
setblock 63 162 598 minecraft:calcite
fill 64 162 558 67 162 558 minecraft:cobbled_deepslate
setblock 64 162 597 minecraft:calcite
fill 64 162 598 64 165 598 minecraft:cobbled_deepslate
fill 65 162 597 65 165 597 minecraft:cobbled_deepslate
setblock 68 162 558 minecraft:calcite
setblock 68 162 597 minecraft:cobbled_deepslate
setblock 68 162 598 minecraft:calcite
fill 69 162 558 69 165 558 minecraft:cobbled_deepslate
setblock 69 162 597 minecraft:calcite
fill 69 162 598 69 165 598 minecraft:cobbled_deepslate
fill 70 162 597 70 165 597 minecraft:cobbled_deepslate
setblock 73 162 558 minecraft:calcite
fill 73 162 559 76 162 559 minecraft:cobbled_deepslate
setblock 73 162 598 minecraft:calcite
fill 74 162 558 74 165 558 minecraft:cobbled_deepslate
setblock 74 162 597 minecraft:calcite
fill 74 162 598 74 165 598 minecraft:cobbled_deepslate
setblock 75 162 596 minecraft:calcite
fill 75 162 597 75 165 597 minecraft:cobbled_deepslate
fill 76 162 596 76 165 596 minecraft:cobbled_deepslate
setblock 77 162 559 minecraft:calcite
setblock 78 162 558 minecraft:calcite
fill 78 162 559 78 165 559 minecraft:cobbled_deepslate
setblock 78 162 598 minecraft:calcite
fill 79 162 558 79 165 558 minecraft:cobbled_deepslate
setblock 79 162 597 minecraft:calcite
fill 79 162 598 79 165 598 minecraft:cobbled_deepslate
setblock 80 162 596 minecraft:calcite
fill 80 162 597 80 165 597 minecraft:cobbled_deepslate
setblock 83 162 558 minecraft:calcite
setblock 83 162 598 minecraft:calcite
fill 84 162 598 84 164 598 minecraft:cobbled_deepslate
setblock 87 162 579 minecraft:calcite
fill 87 162 580 87 164 581 minecraft:cobbled_deepslate
setblock 88 162 573 minecraft:calcite
fill 88 162 574 88 165 574 minecraft:cobbled_deepslate
setblock 88 162 578 minecraft:calcite
fill 88 162 579 88 165 579 minecraft:cobbled_deepslate
setblock 88 162 583 minecraft:calcite
fill 48 163 558 48 166 558 minecraft:cobbled_deepslate
fill 48 163 560 48 163 561 minecraft:cobbled_deepslate
setblock 48 163 562 minecraft:calcite
setblock 48 163 572 minecraft:calcite
fill 48 163 573 48 166 573 minecraft:cobbled_deepslate
setblock 48 163 577 minecraft:calcite
fill 48 163 578 49 165 578 minecraft:cobbled_deepslate
setblock 48 163 582 minecraft:calcite
setblock 49 163 576 minecraft:calcite
fill 49 163 577 49 166 577 minecraft:cobbled_deepslate
fill 49 163 579 49 164 579 minecraft:cobbled_deepslate
setblock 50 163 559 minecraft:cobbled_deepslate
setblock 51 163 559 minecraft:calcite
setblock 51 163 598 minecraft:cobbled_deepslate
setblock 52 163 558 minecraft:calcite
fill 52 163 559 52 165 560 minecraft:cobbled_deepslate
setblock 52 163 598 minecraft:calcite
fill 53 163 558 53 166 558 minecraft:cobbled_deepslate
fill 53 163 560 54 163 560 minecraft:cobbled_deepslate
fill 53 163 598 53 166 598 minecraft:cobbled_deepslate
fill 54 163 597 54 166 597 minecraft:cobbled_deepslate
setblock 55 163 560 minecraft:calcite
setblock 56 163 559 minecraft:calcite
fill 56 163 560 56 165 561 minecraft:cobbled_deepslate
setblock 57 163 558 minecraft:calcite
fill 57 163 559 57 166 559 minecraft:cobbled_deepslate
fill 57 163 561 58 163 561 minecraft:cobbled_deepslate
setblock 57 163 595 minecraft:light_blue_stained_glass
setblock 57 163 598 minecraft:calcite
fill 58 163 558 58 166 558 minecraft:cobbled_deepslate
setblock 58 163 597 minecraft:calcite
fill 58 163 598 58 166 598 minecraft:cobbled_deepslate
fill 59 163 594 61 163 594 minecraft:light_blue_stained_glass
fill 59 163 597 59 166 597 minecraft:cobbled_deepslate
setblock 60 163 560 minecraft:calcite
fill 60 163 595 61 165 596 minecraft:light_blue_stained_glass
setblock 61 163 559 minecraft:calcite
fill 61 163 560 61 166 560 minecraft:cobbled_deepslate
setblock 62 163 558 minecraft:calcite
fill 62 163 559 62 166 559 minecraft:cobbled_deepslate
setblock 62 163 598 minecraft:calcite
fill 63 163 558 66 163 558 minecraft:cobbled_deepslate
setblock 63 163 597 minecraft:calcite
fill 63 163 598 63 166 598 minecraft:cobbled_deepslate
fill 64 163 597 64 166 597 minecraft:cobbled_deepslate
setblock 66 163 559 minecraft:calcite
setblock 67 163 558 minecraft:calcite
setblock 67 163 597 minecraft:cobbled_deepslate
setblock 67 163 598 minecraft:calcite
fill 68 163 558 68 166 558 minecraft:cobbled_deepslate
setblock 68 163 597 minecraft:calcite
fill 68 163 598 68 166 598 minecraft:cobbled_deepslate
fill 69 163 597 69 166 597 minecraft:cobbled_deepslate
setblock 71 163 559 minecraft:calcite
setblock 72 163 558 minecraft:calcite
fill 72 163 559 75 163 559 minecraft:cobbled_deepslate
setblock 72 163 598 minecraft:calcite
fill 73 163 558 73 166 558 minecraft:cobbled_deepslate
setblock 73 163 596 minecraft:cobbled_deepslate
setblock 73 163 597 minecraft:calcite
fill 73 163 598 73 166 598 minecraft:cobbled_deepslate
setblock 74 163 596 minecraft:calcite
fill 74 163 597 74 166 597 minecraft:cobbled_deepslate
fill 75 163 596 75 166 596 minecraft:cobbled_deepslate
setblock 76 163 559 minecraft:calcite
setblock 77 163 558 minecraft:calcite
fill 77 163 559 77 166 559 minecraft:cobbled_deepslate
setblock 77 163 598 minecraft:calcite
fill 78 163 558 78 166 558 minecraft:cobbled_deepslate
setblock 78 163 597 minecraft:calcite
fill 78 163 598 78 166 598 minecraft:cobbled_deepslate
setblock 79 163 596 minecraft:calcite
fill 79 163 597 79 166 597 minecraft:cobbled_deepslate
setblock 80 163 559 minecraft:cobbled_deepslate
setblock 82 163 558 minecraft:calcite
setblock 82 163 598 minecraft:calcite
fill 83 163 558 83 166 558 minecraft:cobbled_deepslate
fill 83 163 598 83 165 598 minecraft:cobbled_deepslate
setblock 87 163 578 minecraft:calcite
fill 87 163 579 87 166 579 minecraft:cobbled_deepslate
setblock 87 163 582 minecraft:cobbled_deepslate
fill 88 163 573 88 166 573 minecraft:cobbled_deepslate
setblock 88 163 577 minecraft:calcite
fill 88 163 578 88 166 578 minecraft:cobbled_deepslate
setblock 88 163 581 minecraft:cobbled_deepslate
setblock 88 163 582 minecraft:calcite
fill 88 163 583 88 165 584 minecraft:cobbled_deepslate
setblock 48 164 560 minecraft:cobbled_deepslate
setblock 48 164 561 minecraft:calcite
fill 48 164 562 48 164 565 minecraft:cobbled_deepslate
fill 48 164 572 48 167 572 minecraft:cobbled_deepslate
setblock 48 164 576 minecraft:calcite
fill 48 164 577 48 167 577 minecraft:cobbled_deepslate
setblock 48 164 581 minecraft:calcite
fill 48 164 582 48 166 583 minecraft:cobbled_deepslate
setblock 49 164 559 minecraft:cobbled_deepslate
setblock 49 164 560 minecraft:calcite
fill 49 164 561 49 166 562 minecraft:cobbled_deepslate
fill 49 164 576 49 167 576 minecraft:cobbled_deepslate
setblock 49 164 580 minecraft:calcite
setblock 50 164 559 minecraft:calcite
setblock 50 164 560 minecraft:light[level=14]
setblock 50 164 568 minecraft:light[level=14]
setblock 50 164 576 minecraft:light[level=14]
setblock 50 164 584 minecraft:light[level=14]
setblock 50 164 592 minecraft:light[level=14]
setblock 50 164 598 minecraft:cobbled_deepslate
setblock 51 164 558 minecraft:calcite
fill 51 164 559 51 166 560 minecraft:cobbled_deepslate
setblock 51 164 598 minecraft:calcite
fill 52 164 558 52 167 558 minecraft:cobbled_deepslate
fill 52 164 598 52 167 598 minecraft:cobbled_deepslate
setblock 53 164 560 minecraft:cobbled_deepslate
fill 53 164 597 53 167 597 minecraft:cobbled_deepslate
setblock 54 164 560 minecraft:calcite
fill 54 164 561 55 166 561 minecraft:cobbled_deepslate
setblock 55 164 559 minecraft:calcite
fill 55 164 560 55 167 560 minecraft:cobbled_deepslate
setblock 56 164 558 minecraft:calcite
fill 56 164 559 56 167 559 minecraft:cobbled_deepslate
setblock 56 164 598 minecraft:calcite
fill 57 164 558 57 167 558 minecraft:cobbled_deepslate
setblock 57 164 561 minecraft:cobbled_deepslate
setblock 57 164 597 minecraft:calcite
fill 57 164 598 57 167 598 minecraft:cobbled_deepslate
setblock 58 164 561 minecraft:calcite
setblock 58 164 568 minecraft:light[level=14]
setblock 58 164 576 minecraft:light[level=14]
setblock 58 164 584 minecraft:light[level=14]
setblock 58 164 592 minecraft:light[level=14]
fill 58 164 597 58 167 597 minecraft:cobbled_deepslate
setblock 59 164 560 minecraft:calcite
fill 59 164 561 59 167 561 minecraft:cobbled_deepslate
setblock 60 164 559 minecraft:calcite
fill 60 164 560 60 167 560 minecraft:cobbled_deepslate
setblock 60 164 594 minecraft:light_blue_stained_glass
setblock 61 164 558 minecraft:calcite
fill 61 164 559 61 167 559 minecraft:cobbled_deepslate
setblock 61 164 598 minecraft:calcite
fill 62 164 558 65 164 558 minecraft:cobbled_deepslate
setblock 62 164 597 minecraft:calcite
fill 62 164 598 62 167 598 minecraft:cobbled_deepslate
fill 63 164 585 64 164 585 minecraft:diamond_block
fill 63 164 597 63 166 597 minecraft:cobbled_deepslate
fill 64 164 583 65 164 584 minecraft:diamond_block
fill 64 164 586 65 164 587 minecraft:diamond_block
setblock 65 164 559 minecraft:calcite
fill 65 164 582 69 164 582 minecraft:diamond_block
fill 65 164 588 69 164 588 minecraft:diamond_block
setblock 66 164 558 minecraft:calcite
fill 66 164 559 69 164 559 minecraft:cobbled_deepslate
setblock 66 164 560 minecraft:light[level=14]
setblock 66 164 568 minecraft:light[level=14]
setblock 66 164 576 minecraft:light[level=14]
fill 66 164 583 66 166 583 minecraft:diamond_block
fill 66 164 587 66 166 587 minecraft:diamond_block
setblock 66 164 592 minecraft:light[level=14]
setblock 66 164 598 minecraft:calcite
fill 67 164 558 67 167 558 minecraft:cobbled_deepslate
setblock 67 164 589 minecraft:diamond_block
setblock 67 164 597 minecraft:calcite
fill 67 164 598 67 167 598 minecraft:cobbled_deepslate
fill 68 164 583 70 164 583 minecraft:diamond_block
fill 68 164 587 70 164 587 minecraft:diamond_block
fill 68 164 597 68 167 597 minecraft:cobbled_deepslate
fill 69 164 584 70 165 584 minecraft:diamond_block
fill 69 164 586 70 165 586 minecraft:diamond_block
setblock 70 164 559 minecraft:calcite
fill 70 164 585 70 165 585 minecraft:diamond_block
setblock 71 164 558 minecraft:calcite
fill 71 164 559 74 164 559 minecraft:cobbled_deepslate
setblock 71 164 598 minecraft:calcite
fill 72 164 558 72 167 558 minecraft:cobbled_deepslate
setblock 72 164 597 minecraft:calcite
fill 72 164 598 72 167 598 minecraft:cobbled_deepslate
setblock 73 164 596 minecraft:calcite
fill 73 164 597 73 167 597 minecraft:cobbled_deepslate
setblock 74 164 560 minecraft:light[level=14]
setblock 74 164 568 minecraft:light[level=14]
setblock 74 164 576 minecraft:light[level=14]
setblock 74 164 584 minecraft:light[level=14]
setblock 74 164 592 minecraft:light[level=14]
fill 74 164 596 74 167 596 minecraft:cobbled_deepslate
setblock 75 164 559 minecraft:calcite
setblock 76 164 558 minecraft:calcite
fill 76 164 559 76 167 559 minecraft:cobbled_deepslate
setblock 76 164 598 minecraft:calcite
fill 77 164 558 77 167 558 minecraft:cobbled_deepslate
setblock 77 164 597 minecraft:calcite
fill 77 164 598 77 167 598 minecraft:cobbled_deepslate
setblock 78 164 596 minecraft:calcite
fill 78 164 597 78 167 597 minecraft:cobbled_deepslate
setblock 79 164 596 minecraft:cobbled_deepslate
setblock 80 164 559 minecraft:calcite
setblock 81 164 558 minecraft:calcite
setblock 81 164 598 minecraft:calcite
fill 82 164 558 82 167 558 minecraft:cobbled_deepslate
setblock 82 164 560 minecraft:light[level=14]
setblock 82 164 568 minecraft:light[level=14]
setblock 82 164 576 minecraft:light[level=14]
setblock 82 164 584 minecraft:light[level=14]
setblock 82 164 592 minecraft:light[level=14]
fill 82 164 598 82 166 598 minecraft:cobbled_deepslate
fill 84 164 558 84 165 558 minecraft:cobbled_deepslate
setblock 87 164 577 minecraft:calcite
fill 87 164 578 87 167 578 minecraft:cobbled_deepslate
setblock 87 164 582 minecraft:calcite
fill 87 164 583 87 167 583 minecraft:cobbled_deepslate
setblock 88 164 576 minecraft:calcite
fill 88 164 577 88 167 577 minecraft:cobbled_deepslate
setblock 88 164 581 minecraft:calcite
fill 88 164 582 88 167 582 minecraft:cobbled_deepslate
setblock 88 164 585 minecraft:cobbled_deepslate
setblock 48 165 560 minecraft:calcite
fill 48 165 561 48 165 564 minecraft:cobbled_deepslate
setblock 48 165 565 minecraft:calcite
fill 48 165 566 48 165 569 minecraft:cobbled_deepslate
setblock 48 165 570 minecraft:calcite
fill 48 165 571 48 167 571 minecraft:cobbled_deepslate
setblock 48 165 575 minecraft:calcite
fill 48 165 576 48 167 576 minecraft:cobbled_deepslate
setblock 48 165 580 minecraft:calcite
fill 48 165 581 49 167 581 minecraft:cobbled_deepslate
setblock 48 165 584 minecraft:cobbled_deepslate
setblock 49 165 559 minecraft:calcite
fill 49 165 560 50 167 560 minecraft:cobbled_deepslate
setblock 49 165 563 minecraft:cobbled_deepslate
setblock 49 165 564 minecraft:calcite
fill 49 165 565 49 167 565 minecraft:cobbled_deepslate
fill 49 165 575 49 166 575 minecraft:cobbled_deepslate
setblock 49 165 579 minecraft:calcite
fill 49 165 580 49 167 580 minecraft:cobbled_deepslate
fill 49 165 582 49 166 582 minecraft:cobbled_deepslate
setblock 49 165 598 minecraft:cobbled_deepslate
setblock 50 165 558 minecraft:calcite
fill 50 165 559 50 167 559 minecraft:cobbled_deepslate
fill 50 165 561 50 165 562 minecraft:cobbled_deepslate
setblock 50 165 598 minecraft:calcite
fill 51 165 558 51 167 558 minecraft:cobbled_deepslate
fill 51 165 598 51 167 598 minecraft:cobbled_deepslate
setblock 52 165 561 minecraft:calcite
setblock 53 165 560 minecraft:calcite
fill 53 165 561 53 167 561 minecraft:cobbled_deepslate
setblock 54 165 559 minecraft:calcite
fill 54 165 560 54 167 560 minecraft:cobbled_deepslate
setblock 55 165 558 minecraft:calcite
fill 55 165 559 55 167 559 minecraft:cobbled_deepslate
setblock 55 165 598 minecraft:calcite
fill 56 165 558 56 167 558 minecraft:cobbled_deepslate
setblock 56 165 597 minecraft:calcite
fill 56 165 598 56 167 598 minecraft:cobbled_deepslate
setblock 57 165 561 minecraft:calcite
fill 57 165 597 57 167 597 minecraft:cobbled_deepslate
setblock 58 165 560 minecraft:calcite
fill 58 165 561 58 167 561 minecraft:cobbled_deepslate
setblock 59 165 559 minecraft:calcite
fill 59 165 560 59 167 560 minecraft:cobbled_deepslate
setblock 60 165 558 minecraft:calcite
fill 60 165 559 60 167 559 minecraft:cobbled_deepslate
fill 60 165 561 60 166 561 minecraft:cobbled_deepslate
setblock 60 165 598 minecraft:calcite
fill 61 165 558 64 165 558 minecraft:cobbled_deepslate
setblock 61 165 597 minecraft:calcite
fill 61 165 598 61 167 598 minecraft:cobbled_deepslate
fill 62 165 597 62 167 597 minecraft:cobbled_deepslate
setblock 63 165 560 minecraft:calcite
setblock 64 165 559 minecraft:calcite
fill 64 165 584 64 165 586 minecraft:diamond_block
setblock 65 165 558 minecraft:calcite
fill 65 165 559 68 165 559 minecraft:cobbled_deepslate
fill 65 165 583 65 165 584 minecraft:diamond_block
fill 65 165 586 65 166 587 minecraft:diamond_block
setblock 65 165 598 minecraft:calcite
fill 66 165 558 66 167 558 minecraft:cobbled_deepslate
fill 66 165 582 68 165 582 minecraft:diamond_block
fill 66 165 588 68 165 588 minecraft:diamond_block
setblock 66 165 597 minecraft:calcite
fill 66 165 598 66 167 598 minecraft:cobbled_deepslate
fill 67 165 597 67 167 597 minecraft:cobbled_deepslate
fill 68 165 583 69 165 583 minecraft:diamond_block
fill 68 165 587 69 165 587 minecraft:diamond_block
setblock 69 165 559 minecraft:calcite
setblock 70 165 558 minecraft:calcite
fill 70 165 559 73 165 559 minecraft:cobbled_deepslate
setblock 70 165 598 minecraft:calcite
fill 71 165 558 71 167 558 minecraft:cobbled_deepslate
setblock 71 165 597 minecraft:calcite
fill 71 165 598 71 167 598 minecraft:cobbled_deepslate
setblock 72 165 596 minecraft:calcite
fill 72 165 597 72 167 597 minecraft:cobbled_deepslate
fill 73 165 596 73 167 596 minecraft:cobbled_deepslate
setblock 74 165 559 minecraft:calcite
fill 74 165 560 77 165 560 minecraft:cobbled_deepslate
setblock 75 165 558 minecraft:calcite
fill 75 165 559 75 167 559 minecraft:cobbled_deepslate
setblock 75 165 598 minecraft:calcite
fill 76 165 558 76 167 558 minecraft:cobbled_deepslate
setblock 76 165 597 minecraft:calcite
fill 76 165 598 76 167 598 minecraft:cobbled_deepslate
setblock 77 165 596 minecraft:calcite
fill 77 165 597 77 167 597 minecraft:cobbled_deepslate
setblock 78 165 596 minecraft:cobbled_deepslate
setblock 79 165 559 minecraft:calcite
setblock 80 165 558 minecraft:calcite
fill 80 165 559 80 167 559 minecraft:cobbled_deepslate
setblock 80 165 598 minecraft:calcite
fill 81 165 558 81 167 558 minecraft:cobbled_deepslate
setblock 81 165 597 minecraft:calcite
fill 81 165 598 81 167 598 minecraft:cobbled_deepslate
fill 86 165 580 87 165 580 minecraft:cobbled_deepslate
fill 87 165 558 88 166 558 minecraft:cobbled_deepslate
setblock 87 165 576 minecraft:calcite
fill 87 165 577 87 167 577 minecraft:cobbled_deepslate
setblock 87 165 581 minecraft:calcite
fill 87 165 582 87 167 582 minecraft:cobbled_deepslate
fill 87 165 584 87 166 584 minecraft:cobbled_deepslate
setblock 88 165 559 minecraft:cobbled_deepslate
setblock 88 165 560 minecraft:calcite
fill 88 165 561 88 166 563 minecraft:cobbled_deepslate
fill 88 165 572 88 167 572 minecraft:cobbled_deepslate
setblock 88 165 575 minecraft:calcite
fill 88 165 576 88 167 576 minecraft:cobbled_deepslate
setblock 88 165 580 minecraft:calcite
fill 88 165 581 88 167 581 minecraft:cobbled_deepslate
setblock 88 165 585 minecraft:calcite
fill 88 165 586 88 167 586 minecraft:cobbled_deepslate
setblock 48 166 559 minecraft:calcite
fill 48 166 560 48 166 563 minecraft:cobbled_deepslate
setblock 48 166 564 minecraft:calcite
fill 48 166 565 48 166 568 minecraft:cobbled_deepslate
setblock 48 166 569 minecraft:calcite
fill 48 166 570 48 167 570 minecraft:cobbled_deepslate
setblock 48 166 574 minecraft:calcite
fill 48 166 575 48 167 575 minecraft:cobbled_deepslate
setblock 48 166 578 minecraft:cobbled_deepslate
setblock 48 166 579 minecraft:calcite
fill 48 166 580 48 167 580 minecraft:cobbled_deepslate
setblock 48 166 584 minecraft:calcite
fill 48 166 585 48 167 585 minecraft:cobbled_deepslate
setblock 49 166 558 minecraft:calcite
fill 49 166 559 49 167 559 minecraft:cobbled_deepslate
setblock 49 166 563 minecraft:calcite
fill 49 166 564 50 167 564 minecraft:cobbled_deepslate
fill 49 166 566 49 166 567 minecraft:cobbled_deepslate
setblock 49 166 578 minecraft:calcite
fill 49 166 579 49 167 579 minecraft:cobbled_deepslate
setblock 49 166 583 minecraft:calcite
setblock 49 166 598 minecraft:calcite
fill 50 166 558 50 167 558 minecraft:cobbled_deepslate
setblock 50 166 561 minecraft:cobbled_deepslate
setblock 50 166 562 minecraft:calcite
fill 50 166 563 50 167 563 minecraft:cobbled_deepslate
fill 50 166 565 50 167 565 minecraft:cobbled_deepslate
fill 50 166 598 50 167 598 minecraft:cobbled_deepslate
setblock 51 166 561 minecraft:calcite
fill 51 166 562 51 167 562 minecraft:cobbled_deepslate
setblock 52 166 559 minecraft:cobbled_deepslate
setblock 52 166 560 minecraft:calcite
fill 52 166 561 52 167 561 minecraft:cobbled_deepslate
fill 52 166 597 52 167 597 minecraft:cobbled_deepslate
setblock 53 166 559 minecraft:calcite
fill 53 166 560 53 167 560 minecraft:cobbled_deepslate
setblock 54 166 558 minecraft:calcite
fill 54 166 559 54 167 559 minecraft:cobbled_deepslate
setblock 54 166 598 minecraft:calcite
fill 55 166 558 55 167 558 minecraft:cobbled_deepslate
setblock 55 166 562 minecraft:calcite
setblock 55 166 597 minecraft:calcite
fill 55 166 598 55 167 598 minecraft:cobbled_deepslate
setblock 56 166 560 minecraft:cobbled_deepslate
setblock 56 166 561 minecraft:calcite
fill 56 166 562 56 167 562 minecraft:cobbled_deepslate
fill 56 166 597 56 167 597 minecraft:cobbled_deepslate
setblock 57 166 560 minecraft:calcite
fill 57 166 561 57 167 561 minecraft:cobbled_deepslate
setblock 58 166 559 minecraft:calcite
fill 58 166 560 58 167 560 minecraft:cobbled_deepslate
setblock 59 166 558 minecraft:calcite
fill 59 166 559 59 167 559 minecraft:cobbled_deepslate
setblock 59 166 598 minecraft:calcite
fill 60 166 558 63 166 558 minecraft:cobbled_deepslate
fill 60 166 596 61 166 596 minecraft:light_blue_stained_glass
setblock 60 166 597 minecraft:calcite
fill 60 166 598 60 167 598 minecraft:cobbled_deepslate
fill 61 166 597 61 167 597 minecraft:cobbled_deepslate
setblock 62 166 560 minecraft:calcite
setblock 63 166 559 minecraft:calcite
setblock 63 166 560 minecraft:cobbled_deepslate
setblock 64 166 558 minecraft:calcite
fill 64 166 559 67 166 559 minecraft:cobbled_deepslate
setblock 64 166 598 minecraft:calcite
fill 65 166 558 65 167 558 minecraft:cobbled_deepslate
setblock 65 166 584 minecraft:diamond_block
fill 65 166 598 65 167 598 minecraft:cobbled_deepslate
setblock 66 166 597 minecraft:cobbled_deepslate
setblock 68 166 559 minecraft:calcite
setblock 68 166 583 minecraft:diamond_block
setblock 68 166 587 minecraft:diamond_block
setblock 69 166 558 minecraft:calcite
fill 69 166 559 72 166 559 minecraft:cobbled_deepslate
setblock 69 166 584 minecraft:diamond_block
setblock 69 166 586 minecraft:diamond_block
setblock 69 166 598 minecraft:calcite
fill 70 166 558 70 167 558 minecraft:cobbled_deepslate
setblock 70 166 597 minecraft:calcite
fill 70 166 598 70 167 598 minecraft:cobbled_deepslate
fill 71 166 597 71 167 597 minecraft:cobbled_deepslate
setblock 72 166 560 minecraft:calcite
fill 72 166 596 72 167 596 minecraft:cobbled_deepslate
setblock 73 166 559 minecraft:calcite
fill 73 166 560 76 166 560 minecraft:cobbled_deepslate
setblock 74 166 558 minecraft:calcite
fill 74 166 559 74 167 559 minecraft:cobbled_deepslate
setblock 74 166 598 minecraft:calcite
fill 75 166 558 75 167 558 minecraft:cobbled_deepslate
setblock 75 166 597 minecraft:calcite
fill 75 166 598 75 167 598 minecraft:cobbled_deepslate
setblock 76 166 596 minecraft:calcite
fill 76 166 597 76 167 597 minecraft:cobbled_deepslate
setblock 77 166 560 minecraft:calcite
setblock 77 166 596 minecraft:cobbled_deepslate
setblock 78 166 559 minecraft:calcite
setblock 79 166 558 minecraft:calcite
fill 79 166 559 79 167 559 minecraft:cobbled_deepslate
setblock 79 166 598 minecraft:calcite
fill 80 166 558 80 167 558 minecraft:cobbled_deepslate
setblock 80 166 597 minecraft:calcite
fill 80 166 598 80 167 598 minecraft:cobbled_deepslate
setblock 84 166 558 minecraft:calcite
fill 85 166 558 86 166 558 minecraft:cobbled_deepslate
fill 86 166 579 86 166 580 minecraft:cobbled_deepslate
setblock 86 166 581 minecraft:calcite
fill 86 166 582 86 167 582 minecraft:cobbled_deepslate
fill 87 166 576 87 167 576 minecraft:cobbled_deepslate
setblock 87 166 580 minecraft:calcite
fill 87 166 581 87 167 581 minecraft:cobbled_deepslate
setblock 87 166 585 minecraft:calcite
setblock 88 166 559 minecraft:calcite
fill 88 166 560 88 167 560 minecraft:cobbled_deepslate
setblock 88 166 564 minecraft:calcite
fill 88 166 565 88 167 566 minecraft:cobbled_deepslate
fill 88 166 571 88 167 571 minecraft:cobbled_deepslate
setblock 88 166 574 minecraft:calcite
fill 88 166 575 88 167 575 minecraft:cobbled_deepslate
setblock 88 166 579 minecraft:calcite
fill 88 166 580 88 167 580 minecraft:cobbled_deepslate
setblock 88 166 583 minecraft:cobbled_deepslate
setblock 88 166 584 minecraft:calcite
fill 88 166 585 88 167 585 minecraft:cobbled_deepslate
fill 88 166 587 88 167 587 minecraft:cobbled_deepslate
setblock 48 167 558 minecraft:calcite
fill 48 167 559 48 167 562 minecraft:cobbled_deepslate
setblock 48 167 563 minecraft:calcite
fill 48 167 564 48 167 567 minecraft:cobbled_deepslate
setblock 48 167 568 minecraft:calcite
fill 48 167 569 49 167 569 minecraft:cobbled_deepslate
setblock 48 167 573 minecraft:calcite
setblock 48 167 574 minecraft:cobbled_deepslate
setblock 48 167 578 minecraft:calcite
setblock 48 167 579 minecraft:cobbled_deepslate
setblock 48 167 582 minecraft:cobbled_deepslate
setblock 48 167 583 minecraft:calcite
fill 48 167 584 49 167 584 minecraft:cobbled_deepslate
setblock 48 167 586 minecraft:cobbled_deepslate
setblock 49 167 558 minecraft:cobbled_deepslate
setblock 49 167 561 minecraft:cobbled_deepslate
setblock 49 167 562 minecraft:calcite
setblock 49 167 563 minecraft:cobbled_deepslate
setblock 49 167 566 minecraft:cobbled_deepslate
setblock 49 167 567 minecraft:calcite
setblock 49 167 568 minecraft:cobbled_deepslate
setblock 49 167 577 minecraft:calcite
setblock 49 167 578 minecraft:cobbled_deepslate
setblock 49 167 582 minecraft:calcite
setblock 49 167 583 minecraft:cobbled_deepslate
setblock 49 167 598 minecraft:cobbled_deepslate
setblock 50 167 561 minecraft:calcite
setblock 50 167 562 minecraft:cobbled_deepslate
setblock 50 167 566 minecraft:calcite
setblock 51 167 559 minecraft:cobbled_deepslate
setblock 51 167 560 minecraft:calcite
setblock 51 167 561 minecraft:cobbled_deepslate
fill 51 167 563 51 167 564 minecraft:cobbled_deepslate
setblock 52 167 559 minecraft:calcite
setblock 52 167 560 minecraft:cobbled_deepslate
setblock 53 167 558 minecraft:calcite
setblock 53 167 559 minecraft:cobbled_deepslate
setblock 53 167 562 minecraft:cobbled_deepslate
setblock 53 167 598 minecraft:calcite
setblock 54 167 558 minecraft:cobbled_deepslate
setblock 54 167 561 minecraft:cobbled_deepslate
setblock 54 167 562 minecraft:calcite
setblock 54 167 597 minecraft:calcite
setblock 54 167 598 minecraft:cobbled_deepslate
setblock 55 167 561 minecraft:calcite
setblock 55 167 562 minecraft:cobbled_deepslate
setblock 55 167 597 minecraft:cobbled_deepslate
setblock 56 167 560 minecraft:calcite
setblock 56 167 561 minecraft:cobbled_deepslate
setblock 57 167 559 minecraft:calcite
setblock 57 167 560 minecraft:cobbled_deepslate
setblock 58 167 558 minecraft:calcite
setblock 58 167 559 minecraft:cobbled_deepslate
setblock 58 167 598 minecraft:calcite
fill 59 167 558 62 167 558 minecraft:cobbled_deepslate
setblock 59 167 597 minecraft:calcite
setblock 59 167 598 minecraft:cobbled_deepslate
setblock 60 167 597 minecraft:cobbled_deepslate
setblock 61 167 560 minecraft:calcite
setblock 62 167 559 minecraft:calcite
setblock 62 167 560 minecraft:cobbled_deepslate
setblock 63 167 558 minecraft:calcite
fill 63 167 559 66 167 559 minecraft:cobbled_deepslate
setblock 63 167 598 minecraft:calcite
setblock 64 167 558 minecraft:cobbled_deepslate
setblock 64 167 598 minecraft:cobbled_deepslate
setblock 67 167 559 minecraft:calcite
setblock 68 167 558 minecraft:calcite
fill 68 167 559 71 167 559 minecraft:cobbled_deepslate
setblock 68 167 598 minecraft:calcite
setblock 69 167 558 minecraft:cobbled_deepslate
setblock 69 167 597 minecraft:calcite
setblock 69 167 598 minecraft:cobbled_deepslate
setblock 70 167 597 minecraft:cobbled_deepslate
setblock 71 167 560 minecraft:calcite
setblock 72 167 559 minecraft:calcite
fill 72 167 560 75 167 560 minecraft:cobbled_deepslate
setblock 73 167 558 minecraft:calcite
setblock 73 167 559 minecraft:cobbled_deepslate
setblock 73 167 598 minecraft:calcite
setblock 74 167 558 minecraft:cobbled_deepslate
setblock 74 167 597 minecraft:calcite
setblock 74 167 598 minecraft:cobbled_deepslate
setblock 75 167 596 minecraft:calcite
setblock 75 167 597 minecraft:cobbled_deepslate
setblock 76 167 560 minecraft:calcite
setblock 76 167 596 minecraft:cobbled_deepslate
setblock 77 167 559 minecraft:calcite
setblock 77 167 560 minecraft:cobbled_deepslate
setblock 78 167 558 minecraft:calcite
setblock 78 167 559 minecraft:cobbled_deepslate
setblock 78 167 598 minecraft:calcite
setblock 79 167 558 minecraft:cobbled_deepslate
setblock 79 167 597 minecraft:calcite
setblock 79 167 598 minecraft:cobbled_deepslate
setblock 83 167 558 minecraft:calcite
fill 86 167 558 87 167 558 minecraft:cobbled_deepslate
setblock 86 167 580 minecraft:calcite
setblock 86 167 581 minecraft:cobbled_deepslate
setblock 87 167 579 minecraft:calcite
setblock 87 167 580 minecraft:cobbled_deepslate
setblock 87 167 584 minecraft:calcite
setblock 87 167 585 minecraft:cobbled_deepslate
setblock 88 167 558 minecraft:calcite
setblock 88 167 559 minecraft:cobbled_deepslate
fill 88 167 561 88 167 562 minecraft:cobbled_deepslate
setblock 88 167 563 minecraft:calcite
setblock 88 167 564 minecraft:cobbled_deepslate
setblock 88 167 567 minecraft:cobbled_deepslate
setblock 88 167 568 minecraft:calcite
fill 88 167 569 88 167 570 minecraft:cobbled_deepslate
setblock 88 167 573 minecraft:calcite
setblock 88 167 574 minecraft:cobbled_deepslate
setblock 88 167 578 minecraft:calcite
setblock 88 167 579 minecraft:cobbled_deepslate
setblock 88 167 583 minecraft:calcite
setblock 88 167 584 minecraft:cobbled_deepslate
setblock 88 167 588 minecraft:calcite
setblock 50 172 560 minecraft:light[level=14]
setblock 50 172 568 minecraft:light[level=14]
setblock 50 172 576 minecraft:light[level=14]
setblock 50 172 584 minecraft:light[level=14]
setblock 50 172 592 minecraft:light[level=14]
setblock 58 172 560 minecraft:light[level=14]
setblock 58 172 568 minecraft:light[level=14]
setblock 58 172 576 minecraft:light[level=14]
setblock 58 172 584 minecraft:light[level=14]
setblock 58 172 592 minecraft:light[level=14]
fill 63 172 575 65 172 577 minecraft:redstone_block
setblock 66 172 560 minecraft:light[level=14]
setblock 66 172 568 minecraft:light[level=14]
setblock 66 172 576 minecraft:light[level=14]
setblock 66 172 584 minecraft:light[level=14]
setblock 66 172 592 minecraft:light[level=14]
fill 68 172 570 70 172 572 minecraft:redstone_block
fill 73 172 575 75 172 577 minecraft:redstone_block
setblock 74 172 560 minecraft:light[level=14]
setblock 74 172 568 minecraft:light[level=14]
setblock 74 172 584 minecraft:light[level=14]
setblock 74 172 592 minecraft:light[level=14]
setblock 82 172 560 minecraft:light[level=14]
setblock 82 172 568 minecraft:light[level=14]
setblock 82 172 576 minecraft:light[level=14]
setblock 82 172 584 minecraft:light[level=14]
setblock 82 172 592 minecraft:light[level=14]
fill 48 173 558 62 173 598 minecraft:calcite
fill 63 173 558 67 173 574 minecraft:calcite
fill 63 173 578 88 173 598 minecraft:calcite
fill 66 173 575 67 173 577 minecraft:calcite
fill 68 173 558 88 173 569 minecraft:calcite
fill 68 173 573 88 173 574 minecraft:calcite
fill 71 173 570 88 173 572 minecraft:calcite
fill 71 173 575 72 173 577 minecraft:calcite
fill 76 173 575 88 173 577 minecraft:calcite
setblock 48 174 558 minecraft:diamond_block
fill 48 174 559 49 174 561 minecraft:calcite
fill 48 174 562 48 174 565 minecraft:diamond_block
fill 48 174 566 49 174 568 minecraft:calcite
fill 48 174 569 48 174 572 minecraft:diamond_block
fill 48 174 573 49 174 575 minecraft:calcite
fill 48 174 576 48 174 579 minecraft:diamond_block
fill 48 174 580 49 174 582 minecraft:calcite
fill 48 174 583 48 174 586 minecraft:diamond_block
fill 48 174 587 49 174 589 minecraft:calcite
fill 48 174 590 48 174 593 minecraft:diamond_block
fill 48 174 594 49 174 596 minecraft:calcite
fill 48 174 597 48 174 598 minecraft:diamond_block
fill 49 174 558 54 174 558 minecraft:calcite
fill 49 174 562 88 174 562 minecraft:diamond_block
fill 49 174 563 54 174 565 minecraft:calcite
fill 49 174 569 60 174 569 minecraft:diamond_block
fill 49 174 570 54 174 572 minecraft:calcite
fill 49 174 576 55 174 576 minecraft:diamond_block
fill 49 174 577 54 174 579 minecraft:calcite
fill 49 174 583 60 174 583 minecraft:diamond_block
fill 49 174 584 54 174 586 minecraft:calcite
fill 49 174 590 88 174 590 minecraft:diamond_block
fill 49 174 591 54 174 593 minecraft:calcite
fill 49 174 597 88 174 597 minecraft:diamond_block
fill 49 174 598 54 174 598 minecraft:calcite
fill 50 174 559 50 174 561 minecraft:diamond_block
fill 50 174 566 50 174 568 minecraft:diamond_block
fill 50 174 573 50 174 575 minecraft:diamond_block
fill 50 174 580 50 174 582 minecraft:diamond_block
fill 50 174 587 50 174 589 minecraft:diamond_block
fill 50 174 594 50 174 596 minecraft:diamond_block
fill 51 174 559 52 174 561 minecraft:calcite
fill 51 174 566 52 174 568 minecraft:calcite
fill 51 174 573 52 174 575 minecraft:calcite
fill 51 174 580 52 174 582 minecraft:calcite
fill 51 174 587 52 174 589 minecraft:calcite
fill 51 174 594 52 174 596 minecraft:calcite
fill 53 174 559 53 174 561 minecraft:diamond_block
fill 53 174 566 53 174 568 minecraft:diamond_block
fill 53 174 573 53 174 575 minecraft:diamond_block
fill 53 174 580 53 174 582 minecraft:diamond_block
fill 53 174 587 53 174 589 minecraft:diamond_block
fill 53 174 594 53 174 596 minecraft:diamond_block
fill 54 174 559 56 174 561 minecraft:calcite
fill 54 174 566 56 174 568 minecraft:calcite
fill 54 174 573 56 174 575 minecraft:calcite
fill 54 174 580 56 174 582 minecraft:calcite
fill 54 174 587 56 174 589 minecraft:calcite
fill 54 174 594 56 174 596 minecraft:calcite
setblock 55 174 558 minecraft:diamond_block
fill 55 174 563 55 174 565 minecraft:diamond_block
fill 55 174 570 55 174 572 minecraft:diamond_block
fill 55 174 577 55 174 579 minecraft:diamond_block
fill 55 174 584 55 174 586 minecraft:diamond_block
fill 55 174 591 55 174 593 minecraft:diamond_block
setblock 55 174 598 minecraft:diamond_block
fill 56 174 558 61 174 558 minecraft:calcite
fill 56 174 563 61 174 565 minecraft:calcite
fill 56 174 570 56 174 572 minecraft:calcite
fill 56 174 576 65 175 576 minecraft:iron_block
fill 56 174 577 56 174 579 minecraft:calcite
fill 56 174 584 60 174 586 minecraft:calcite
fill 56 174 591 61 174 593 minecraft:calcite
fill 56 174 598 61 174 598 minecraft:calcite
fill 57 174 559 57 174 561 minecraft:diamond_block
fill 57 174 566 57 174 568 minecraft:diamond_block
setblock 57 174 570 minecraft:calcite
fill 57 174 571 81 175 571 minecraft:iron_block
setblock 57 174 572 minecraft:calcite
fill 57 174 573 57 174 574 minecraft:diamond_block
fill 57 174 575 57 175 575 minecraft:iron_block
fill 57 174 577 57 175 577 minecraft:iron_block
fill 57 174 578 58 174 579 minecraft:calcite
setblock 57 174 580 minecraft:diamond_block
fill 57 174 581 81 175 581 minecraft:iron_block
setblock 57 174 582 minecraft:diamond_block
fill 57 174 587 57 174 589 minecraft:diamond_block
fill 57 174 594 57 174 596 minecraft:diamond_block
fill 58 174 559 59 174 561 minecraft:calcite
fill 58 174 566 59 174 568 minecraft:calcite
fill 58 174 570 80 175 570 minecraft:iron_block
fill 58 174 572 80 175 572 minecraft:iron_block
fill 58 174 573 58 174 575 minecraft:calcite
setblock 58 174 577 minecraft:calcite
fill 58 174 580 80 175 580 minecraft:iron_block
fill 58 174 582 80 175 582 minecraft:iron_block
fill 58 174 587 59 174 589 minecraft:calcite
fill 58 174 594 59 174 596 minecraft:calcite
fill 59 174 573 66 175 575 minecraft:iron_block
fill 59 174 577 66 175 579 minecraft:iron_block
fill 60 174 559 60 174 561 minecraft:diamond_block
fill 60 174 566 60 174 568 minecraft:diamond_block
fill 60 174 587 60 174 589 minecraft:diamond_block
fill 60 174 594 60 174 596 minecraft:diamond_block
fill 61 174 559 63 174 561 minecraft:calcite
fill 61 174 566 62 175 567 minecraft:iron_block
setblock 61 174 568 minecraft:calcite
fill 61 174 569 77 175 569 minecraft:iron_block
fill 61 174 583 77 175 583 minecraft:iron_block
setblock 61 174 584 minecraft:calcite
fill 61 174 585 62 175 586 minecraft:iron_block
fill 61 174 587 63 174 589 minecraft:calcite
fill 61 174 594 63 174 596 minecraft:calcite
setblock 62 174 558 minecraft:diamond_block
fill 62 174 563 62 174 565 minecraft:diamond_block
fill 62 174 568 76 175 568 minecraft:iron_block
fill 62 174 584 76 175 584 minecraft:iron_block
fill 62 174 591 62 174 593 minecraft:diamond_block
setblock 62 174 598 minecraft:diamond_block
fill 63 174 558 68 174 558 minecraft:calcite
fill 63 174 563 63 174 566 minecraft:calcite
fill 63 174 567 77 175 567 minecraft:iron_block
fill 63 174 585 77 175 585 minecraft:iron_block
fill 63 174 586 64 174 586 minecraft:calcite
fill 63 174 591 68 174 593 minecraft:calcite
fill 63 174 598 68 174 598 minecraft:calcite
fill 64 174 559 64 174 561 minecraft:diamond_block
fill 64 174 563 65 174 565 minecraft:calcite
setblock 64 174 566 minecraft:diamond_block
fill 64 174 587 64 174 589 minecraft:diamond_block
fill 64 174 594 64 174 596 minecraft:diamond_block
fill 65 174 559 66 174 561 minecraft:calcite
fill 65 174 566 73 175 566 minecraft:iron_block
fill 65 174 586 73 175 586 minecraft:iron_block
fill 65 174 587 65 174 589 minecraft:calcite
fill 65 174 594 66 174 596 minecraft:calcite
fill 66 174 563 68 174 563 minecraft:calcite
fill 66 174 564 67 175 565 minecraft:iron_block
fill 66 174 576 67 174 576 minecraft:waxed_copper_block
fill 66 174 587 67 175 588 minecraft:iron_block
setblock 66 174 589 minecraft:calcite
fill 67 174 559 67 174 561 minecraft:diamond_block
fill 67 174 573 68 175 573 minecraft:iron_block
fill 67 174 574 67 175 575 minecraft:waxed_copper_block
fill 67 174 577 67 175 578 minecraft:waxed_copper_block
fill 67 174 579 68 175 579 minecraft:iron_block
setblock 67 174 589 minecraft:diamond_block
fill 67 174 594 67 174 596 minecraft:diamond_block
fill 68 174 559 70 174 561 minecraft:calcite
fill 68 174 564 68 174 565 minecraft:calcite
fill 68 174 574 71 174 574 minecraft:waxed_copper_block
fill 68 174 578 71 174 578 minecraft:waxed_copper_block
fill 68 174 587 68 174 589 minecraft:calcite
fill 68 174 594 70 174 596 minecraft:calcite
setblock 69 174 558 minecraft:diamond_block
fill 69 174 563 69 174 564 minecraft:diamond_block
fill 69 174 565 69 175 565 minecraft:iron_block
fill 69 174 573 69 176 573 minecraft:waxed_copper_block
fill 69 174 579 69 176 579 minecraft:waxed_copper_block
fill 69 174 587 69 175 587 minecraft:iron_block
fill 69 174 588 70 174 589 minecraft:calcite
fill 69 174 591 69 174 593 minecraft:diamond_block
setblock 69 174 598 minecraft:diamond_block
fill 70 174 558 75 174 558 minecraft:calcite
fill 70 174 563 70 174 565 minecraft:calcite
fill 70 174 573 79 175 573 minecraft:iron_block
fill 70 174 579 79 175 579 minecraft:iron_block
setblock 70 174 587 minecraft:calcite
fill 70 174 591 75 174 593 minecraft:calcite
fill 70 174 598 75 174 598 minecraft:calcite
fill 71 174 559 71 174 561 minecraft:diamond_block
fill 71 174 563 75 174 563 minecraft:calcite
fill 71 174 564 72 175 565 minecraft:iron_block
fill 71 174 575 71 174 577 minecraft:waxed_copper_block
fill 71 174 587 72 175 588 minecraft:iron_block
setblock 71 174 589 minecraft:diamond_block
fill 71 174 594 71 174 596 minecraft:diamond_block
fill 72 174 559 73 174 561 minecraft:calcite
fill 72 174 574 79 175 575 minecraft:iron_block
fill 72 174 576 72 176 576 minecraft:waxed_copper_block
fill 72 174 577 79 175 578 minecraft:iron_block
fill 72 174 589 73 174 589 minecraft:calcite
fill 72 174 594 73 174 596 minecraft:calcite
fill 73 174 564 75 174 565 minecraft:calcite
fill 73 174 576 82 175 576 minecraft:iron_block
fill 73 174 587 73 174 588 minecraft:calcite
fill 74 174 559 74 174 561 minecraft:diamond_block
setblock 74 174 566 minecraft:diamond_block
fill 74 174 586 75 174 586 minecraft:calcite
fill 74 174 587 74 174 589 minecraft:diamond_block
fill 74 174 594 74 174 596 minecraft:diamond_block
fill 75 174 559 77 174 561 minecraft:calcite
setblock 75 174 566 minecraft:calcite
fill 75 174 587 77 174 589 minecraft:calcite
fill 75 174 594 77 174 596 minecraft:calcite
setblock 76 174 558 minecraft:diamond_block
fill 76 174 563 76 174 565 minecraft:diamond_block
fill 76 174 566 77 175 566 minecraft:iron_block
fill 76 174 586 77 175 586 minecraft:iron_block
fill 76 174 591 76 174 593 minecraft:diamond_block
setblock 76 174 598 minecraft:diamond_block
fill 77 174 558 82 174 558 minecraft:calcite
fill 77 174 563 82 174 565 minecraft:calcite
setblock 77 174 568 minecraft:calcite
fill 77 174 584 82 174 584 minecraft:calcite
fill 77 174 591 82 174 593 minecraft:calcite
fill 77 174 598 82 174 598 minecraft:calcite
fill 78 174 559 78 174 561 minecraft:diamond_block
fill 78 174 566 78 174 569 minecraft:diamond_block
fill 78 174 583 88 174 583 minecraft:diamond_block
fill 78 174 585 82 174 586 minecraft:calcite
fill 78 174 587 78 174 589 minecraft:diamond_block
fill 78 174 594 78 174 596 minecraft:diamond_block
fill 79 174 559 80 174 561 minecraft:calcite
fill 79 174 566 80 174 568 minecraft:calcite
fill 79 174 569 88 174 569 minecraft:diamond_block
fill 79 174 587 80 174 589 minecraft:calcite
fill 79 174 594 80 174 596 minecraft:calcite
fill 80 174 573 80 174 575 minecraft:calcite
fill 80 174 577 80 174 579 minecraft:calcite
fill 81 174 559 81 174 561 minecraft:diamond_block
fill 81 174 566 81 174 568 minecraft:diamond_block
fill 81 174 570 82 174 570 minecraft:calcite
fill 81 174 572 82 174 572 minecraft:calcite
fill 81 174 573 81 174 574 minecraft:diamond_block
fill 81 174 575 81 175 575 minecraft:iron_block
fill 81 174 577 81 175 577 minecraft:iron_block
fill 81 174 578 82 174 579 minecraft:calcite
setblock 81 174 580 minecraft:diamond_block
setblock 81 174 582 minecraft:diamond_block
fill 81 174 587 81 174 589 minecraft:diamond_block
fill 81 174 594 81 174 596 minecraft:diamond_block
fill 82 174 559 84 174 561 minecraft:calcite
fill 82 174 566 84 174 568 minecraft:calcite
setblock 82 174 571 minecraft:calcite
fill 82 174 573 84 174 575 minecraft:calcite
setblock 82 174 577 minecraft:calcite
fill 82 174 580 84 174 582 minecraft:calcite
fill 82 174 587 84 174 589 minecraft:calcite
fill 82 174 594 84 174 596 minecraft:calcite
setblock 83 174 558 minecraft:diamond_block
fill 83 174 563 83 174 565 minecraft:diamond_block
fill 83 174 570 83 174 572 minecraft:diamond_block
fill 83 174 576 83 174 579 minecraft:diamond_block
fill 83 174 584 83 174 586 minecraft:diamond_block
fill 83 174 591 83 174 593 minecraft:diamond_block
setblock 83 174 598 minecraft:diamond_block
fill 84 174 558 88 174 558 minecraft:calcite
fill 84 174 563 88 174 565 minecraft:calcite
fill 84 174 570 88 174 572 minecraft:calcite
fill 84 174 576 88 174 576 minecraft:diamond_block
fill 84 174 577 88 174 579 minecraft:calcite
fill 84 174 584 88 174 586 minecraft:calcite
fill 84 174 591 88 174 593 minecraft:calcite
fill 84 174 598 88 174 598 minecraft:calcite
fill 85 174 559 85 174 561 minecraft:diamond_block
fill 85 174 566 85 174 568 minecraft:diamond_block
fill 85 174 573 85 174 575 minecraft:diamond_block
fill 85 174 580 85 174 582 minecraft:diamond_block
fill 85 174 587 85 174 589 minecraft:diamond_block
fill 85 174 594 85 174 596 minecraft:diamond_block
fill 86 174 559 87 174 561 minecraft:calcite
fill 86 174 566 87 174 568 minecraft:calcite
fill 86 174 573 87 174 575 minecraft:calcite
fill 86 174 580 87 174 582 minecraft:calcite
fill 86 174 587 87 174 589 minecraft:calcite
fill 86 174 594 87 174 596 minecraft:calcite
fill 88 174 559 88 174 561 minecraft:diamond_block
fill 88 174 566 88 174 568 minecraft:diamond_block
fill 88 174 573 88 174 575 minecraft:diamond_block
fill 88 174 580 88 174 582 minecraft:diamond_block
fill 88 174 587 88 174 589 minecraft:diamond_block
fill 88 174 594 88 174 596 minecraft:diamond_block
fill 66 175 576 66 176 576 minecraft:waxed_copper_block
setblock 68 175 574 minecraft:waxed_copper_block
setblock 68 175 578 minecraft:waxed_copper_block
fill 70 175 574 71 175 574 minecraft:waxed_copper_block
fill 70 175 578 71 175 578 minecraft:waxed_copper_block
setblock 71 175 575 minecraft:waxed_copper_block
setblock 71 175 577 minecraft:waxed_copper_block
fill 62 176 574 62 176 578 minecraft:waxed_oxidized_copper
fill 63 176 572 63 176 573 minecraft:waxed_oxidized_copper
fill 63 176 579 63 176 580 minecraft:waxed_oxidized_copper
setblock 64 176 571 minecraft:waxed_oxidized_copper
setblock 64 176 581 minecraft:waxed_oxidized_copper
fill 65 176 570 66 176 570 minecraft:waxed_oxidized_copper
fill 65 176 582 66 176 582 minecraft:waxed_oxidized_copper
fill 67 176 569 71 176 569 minecraft:waxed_oxidized_copper
setblock 67 176 574 minecraft:waxed_copper_block
setblock 67 176 578 minecraft:waxed_copper_block
fill 67 176 583 71 176 583 minecraft:waxed_oxidized_copper
setblock 71 176 574 minecraft:waxed_copper_block
setblock 71 176 578 minecraft:waxed_copper_block
fill 72 176 570 73 176 570 minecraft:waxed_oxidized_copper
fill 72 176 582 73 176 582 minecraft:waxed_oxidized_copper
setblock 74 176 571 minecraft:waxed_oxidized_copper
setblock 74 176 581 minecraft:waxed_oxidized_copper
fill 75 176 572 75 176 573 minecraft:waxed_oxidized_copper
fill 75 176 579 75 176 580 minecraft:waxed_oxidized_copper
fill 76 176 574 76 176 578 minecraft:waxed_oxidized_copper
fill 48 178 558 48 178 561 minecraft:cobbled_deepslate
setblock 48 178 562 minecraft:calcite
fill 48 178 563 48 178 566 minecraft:cobbled_deepslate
setblock 48 178 567 minecraft:calcite
fill 48 178 568 48 178 571 minecraft:cobbled_deepslate
setblock 48 178 572 minecraft:calcite
fill 48 178 573 48 178 576 minecraft:cobbled_deepslate
setblock 48 178 577 minecraft:calcite
fill 48 178 583 48 178 586 minecraft:cobbled_deepslate
setblock 48 178 587 minecraft:calcite
fill 48 178 588 48 178 591 minecraft:cobbled_deepslate
setblock 48 178 592 minecraft:calcite
fill 48 178 593 48 178 596 minecraft:cobbled_deepslate
setblock 48 178 597 minecraft:calcite
fill 48 178 598 51 178 598 minecraft:cobbled_deepslate
fill 49 178 558 49 178 560 minecraft:cobbled_deepslate
setblock 49 178 561 minecraft:calcite
fill 49 178 562 49 178 565 minecraft:cobbled_deepslate
setblock 49 178 566 minecraft:calcite
fill 49 178 567 49 178 570 minecraft:cobbled_deepslate
setblock 49 178 571 minecraft:calcite
fill 49 178 572 49 179 574 minecraft:cobbled_deepslate
setblock 49 178 586 minecraft:calcite
fill 49 178 587 49 178 590 minecraft:cobbled_deepslate
setblock 49 178 591 minecraft:calcite
fill 49 178 592 49 178 595 minecraft:cobbled_deepslate
setblock 49 178 596 minecraft:calcite
fill 49 178 597 52 178 597 minecraft:cobbled_deepslate
fill 50 178 558 50 178 559 minecraft:cobbled_deepslate
fill 50 178 561 50 178 564 minecraft:cobbled_deepslate
setblock 50 178 565 minecraft:calcite
fill 50 178 566 50 178 569 minecraft:cobbled_deepslate
setblock 50 178 570 minecraft:calcite
fill 50 178 571 50 181 571 minecraft:cobbled_deepslate
setblock 50 178 589 minecraft:cobbled_deepslate
setblock 50 178 590 minecraft:calcite
fill 50 178 591 50 179 593 minecraft:cobbled_deepslate
setblock 51 178 558 minecraft:cobbled_deepslate
setblock 51 178 559 minecraft:calcite
setblock 52 178 558 minecraft:calcite
fill 52 178 559 52 180 559 minecraft:cobbled_deepslate
setblock 52 178 598 minecraft:calcite
fill 53 178 558 54 180 558 minecraft:cobbled_deepslate
setblock 53 178 597 minecraft:calcite
fill 53 178 598 56 178 598 minecraft:cobbled_deepslate
setblock 62 178 598 minecraft:calcite
fill 63 178 598 66 178 598 minecraft:cobbled_deepslate
fill 65 178 597 67 178 597 minecraft:cobbled_deepslate
setblock 67 178 598 minecraft:calcite
setblock 68 178 597 minecraft:calcite
fill 68 178 598 71 178 598 minecraft:cobbled_deepslate
fill 69 178 597 70 180 597 minecraft:cobbled_deepslate
setblock 72 178 598 minecraft:calcite
setblock 86 178 558 minecraft:cobbled_deepslate
setblock 86 178 564 minecraft:calcite
fill 86 178 565 86 178 568 minecraft:cobbled_deepslate
setblock 86 178 569 minecraft:calcite
fill 86 178 570 86 178 573 minecraft:cobbled_deepslate
setblock 87 178 558 minecraft:calcite
fill 87 178 560 87 178 562 minecraft:cobbled_deepslate
setblock 87 178 563 minecraft:calcite
fill 87 178 564 87 178 567 minecraft:cobbled_deepslate
setblock 87 178 568 minecraft:calcite
fill 87 178 569 87 178 572 minecraft:cobbled_deepslate
setblock 87 178 573 minecraft:calcite
fill 87 178 574 87 178 577 minecraft:cobbled_deepslate
fill 87 178 585 87 178 587 minecraft:cobbled_deepslate
setblock 87 178 588 minecraft:calcite
fill 87 178 589 87 178 592 minecraft:cobbled_deepslate
fill 88 178 558 88 178 561 minecraft:cobbled_deepslate
setblock 88 178 562 minecraft:calcite
fill 88 178 563 88 178 566 minecraft:cobbled_deepslate
setblock 88 178 567 minecraft:calcite
fill 88 178 568 88 178 571 minecraft:cobbled_deepslate
setblock 88 178 572 minecraft:calcite
fill 88 178 573 88 178 576 minecraft:cobbled_deepslate
setblock 88 178 577 minecraft:calcite
fill 88 178 578 88 178 581 minecraft:cobbled_deepslate
setblock 88 178 582 minecraft:calcite
fill 88 178 583 88 178 586 minecraft:cobbled_deepslate
setblock 88 178 587 minecraft:calcite
fill 88 178 588 88 178 591 minecraft:cobbled_deepslate
setblock 88 178 592 minecraft:calcite
fill 88 178 593 88 178 596 minecraft:cobbled_deepslate
setblock 88 178 597 minecraft:calcite
fill 48 179 558 48 179 560 minecraft:cobbled_deepslate
setblock 48 179 561 minecraft:calcite
fill 48 179 562 48 179 565 minecraft:cobbled_deepslate
setblock 48 179 566 minecraft:calcite
fill 48 179 567 48 179 570 minecraft:cobbled_deepslate
setblock 48 179 571 minecraft:calcite
fill 48 179 572 48 179 575 minecraft:cobbled_deepslate
setblock 48 179 576 minecraft:calcite
fill 48 179 577 48 181 578 minecraft:cobbled_deepslate
fill 48 179 583 48 179 585 minecraft:cobbled_deepslate
setblock 48 179 586 minecraft:calcite
fill 48 179 587 48 179 590 minecraft:cobbled_deepslate
setblock 48 179 591 minecraft:calcite
fill 48 179 592 48 179 595 minecraft:cobbled_deepslate
setblock 48 179 596 minecraft:calcite
fill 48 179 597 50 179 598 minecraft:cobbled_deepslate
fill 49 179 558 49 179 559 minecraft:cobbled_deepslate
setblock 49 179 560 minecraft:calcite
fill 49 179 561 49 179 564 minecraft:cobbled_deepslate
setblock 49 179 565 minecraft:calcite
fill 49 179 566 49 179 569 minecraft:cobbled_deepslate
setblock 49 179 570 minecraft:calcite
fill 49 179 571 49 182 571 minecraft:cobbled_deepslate
fill 49 179 586 49 179 589 minecraft:cobbled_deepslate
setblock 49 179 590 minecraft:calcite
fill 49 179 591 49 179 594 minecraft:cobbled_deepslate
setblock 49 179 595 minecraft:calcite
fill 49 179 596 50 181 596 minecraft:cobbled_deepslate
setblock 50 179 558 minecraft:cobbled_deepslate
setblock 50 179 559 minecraft:calcite
fill 50 179 561 50 179 563 minecraft:cobbled_deepslate
setblock 50 179 564 minecraft:calcite
fill 50 179 565 50 179 568 minecraft:cobbled_deepslate
setblock 50 179 569 minecraft:calcite
fill 50 179 570 50 182 570 minecraft:cobbled_deepslate
setblock 50 179 589 minecraft:calcite
fill 50 179 590 50 182 590 minecraft:cobbled_deepslate
setblock 50 179 594 minecraft:calcite
fill 50 179 595 50 182 595 minecraft:cobbled_deepslate
setblock 51 179 558 minecraft:calcite
fill 51 179 559 51 182 559 minecraft:cobbled_deepslate
setblock 51 179 597 minecraft:cobbled_deepslate
setblock 51 179 598 minecraft:calcite
fill 52 179 558 52 182 558 minecraft:cobbled_deepslate
setblock 52 179 597 minecraft:calcite
fill 52 179 598 55 179 598 minecraft:cobbled_deepslate
fill 53 179 597 54 181 597 minecraft:cobbled_deepslate
setblock 56 179 598 minecraft:calcite
fill 57 179 598 60 179 598 minecraft:cobbled_deepslate
setblock 61 179 598 minecraft:calcite
fill 62 179 598 65 179 598 minecraft:cobbled_deepslate
fill 63 179 597 66 179 597 minecraft:cobbled_deepslate
fill 65 179 596 67 179 596 minecraft:cobbled_deepslate
setblock 66 179 598 minecraft:calcite
setblock 67 179 597 minecraft:calcite
fill 67 179 598 70 179 598 minecraft:cobbled_deepslate
setblock 68 179 596 minecraft:calcite
fill 68 179 597 68 182 597 minecraft:cobbled_deepslate
fill 69 179 596 69 182 596 minecraft:cobbled_deepslate
setblock 71 179 597 minecraft:cobbled_deepslate
setblock 71 179 598 minecraft:calcite
fill 72 179 598 72 182 598 minecraft:cobbled_deepslate
setblock 85 179 558 minecraft:cobbled_deepslate
fill 85 179 567 85 179 568 minecraft:cobbled_deepslate
setblock 85 179 569 minecraft:calcite
fill 85 179 570 87 179 571 minecraft:cobbled_deepslate
setblock 86 179 558 minecraft:calcite
setblock 86 179 563 minecraft:calcite
fill 86 179 564 86 179 567 minecraft:cobbled_deepslate
setblock 86 179 568 minecraft:calcite
fill 86 179 569 88 180 569 minecraft:cobbled_deepslate
setblock 86 179 572 minecraft:cobbled_deepslate
setblock 86 179 573 minecraft:calcite
fill 86 179 574 88 179 575 minecraft:cobbled_deepslate
fill 87 179 558 87 179 561 minecraft:cobbled_deepslate
setblock 87 179 562 minecraft:calcite
fill 87 179 563 87 179 566 minecraft:cobbled_deepslate
setblock 87 179 567 minecraft:calcite
fill 87 179 568 88 181 568 minecraft:cobbled_deepslate
setblock 87 179 572 minecraft:calcite
fill 87 179 573 88 181 573 minecraft:cobbled_deepslate
setblock 87 179 576 minecraft:cobbled_deepslate
setblock 87 179 577 minecraft:calcite
fill 87 179 578 88 181 578 minecraft:cobbled_deepslate
fill 87 179 585 87 179 586 minecraft:cobbled_deepslate
setblock 87 179 587 minecraft:calcite
fill 87 179 588 87 179 591 minecraft:cobbled_deepslate
setblock 87 179 592 minecraft:calcite
fill 87 179 593 88 180 594 minecraft:cobbled_deepslate
fill 87 179 598 88 181 598 minecraft:cobbled_deepslate
fill 88 179 558 88 179 560 minecraft:cobbled_deepslate
setblock 88 179 561 minecraft:calcite
fill 88 179 562 88 179 565 minecraft:cobbled_deepslate
setblock 88 179 566 minecraft:calcite
fill 88 179 567 88 182 567 minecraft:cobbled_deepslate
setblock 88 179 570 minecraft:cobbled_deepslate
setblock 88 179 571 minecraft:calcite
fill 88 179 572 88 182 572 minecraft:cobbled_deepslate
setblock 88 179 576 minecraft:calcite
fill 88 179 577 88 182 577 minecraft:cobbled_deepslate
fill 88 179 579 88 179 580 minecraft:cobbled_deepslate
setblock 88 179 581 minecraft:calcite
fill 88 179 582 88 179 585 minecraft:cobbled_deepslate
setblock 88 179 586 minecraft:calcite
fill 88 179 587 88 179 590 minecraft:cobbled_deepslate
setblock 88 179 591 minecraft:calcite
fill 88 179 592 88 182 592 minecraft:cobbled_deepslate
setblock 88 179 595 minecraft:cobbled_deepslate
setblock 88 179 596 minecraft:calcite
fill 88 179 597 88 182 597 minecraft:cobbled_deepslate
fill 48 180 558 48 180 559 minecraft:cobbled_deepslate
setblock 48 180 560 minecraft:calcite
fill 48 180 561 48 180 564 minecraft:cobbled_deepslate
setblock 48 180 565 minecraft:calcite
fill 48 180 566 48 180 569 minecraft:cobbled_deepslate
setblock 48 180 570 minecraft:calcite
fill 48 180 571 48 180 574 minecraft:cobbled_deepslate
setblock 48 180 575 minecraft:calcite
fill 48 180 576 48 183 576 minecraft:cobbled_deepslate
setblock 48 180 579 minecraft:cobbled_deepslate
fill 48 180 582 48 180 584 minecraft:cobbled_deepslate
setblock 48 180 585 minecraft:calcite
fill 48 180 586 48 180 589 minecraft:cobbled_deepslate
setblock 48 180 590 minecraft:calcite
fill 48 180 591 48 180 594 minecraft:cobbled_deepslate
setblock 48 180 595 minecraft:calcite
fill 48 180 596 48 181 598 minecraft:cobbled_deepslate
setblock 49 180 558 minecraft:cobbled_deepslate
setblock 49 180 559 minecraft:calcite
fill 49 180 560 49 180 563 minecraft:cobbled_deepslate
setblock 49 180 564 minecraft:calcite
fill 49 180 565 49 180 568 minecraft:cobbled_deepslate
setblock 49 180 569 minecraft:calcite
fill 49 180 570 49 183 570 minecraft:cobbled_deepslate
fill 49 180 572 49 180 573 minecraft:cobbled_deepslate
setblock 49 180 574 minecraft:calcite
fill 49 180 575 49 183 575 minecraft:cobbled_deepslate
fill 49 180 586 49 180 588 minecraft:cobbled_deepslate
setblock 49 180 589 minecraft:calcite
fill 49 180 590 49 180 593 minecraft:cobbled_deepslate
setblock 49 180 594 minecraft:calcite
fill 49 180 595 49 183 595 minecraft:cobbled_deepslate
fill 49 180 597 49 180 598 minecraft:cobbled_deepslate
setblock 50 180 558 minecraft:calcite
fill 50 180 559 50 183 559 minecraft:cobbled_deepslate
setblock 50 180 560 minecraft:light[level=14]
setblock 50 180 562 minecraft:cobbled_deepslate
setblock 50 180 563 minecraft:calcite
fill 50 180 564 50 180 567 minecraft:cobbled_deepslate
setblock 50 180 568 minecraft:calcite
fill 50 180 569 50 182 569 minecraft:cobbled_deepslate
setblock 50 180 572 minecraft:cobbled_deepslate
setblock 50 180 576 minecraft:light[level=14]
setblock 50 180 584 minecraft:light[level=14]
fill 50 180 589 50 181 589 minecraft:cobbled_deepslate
fill 50 180 591 50 180 592 minecraft:cobbled_deepslate
setblock 50 180 593 minecraft:calcite
fill 50 180 594 50 183 594 minecraft:cobbled_deepslate
setblock 50 180 597 minecraft:cobbled_deepslate
setblock 50 180 598 minecraft:calcite
fill 51 180 558 51 183 558 minecraft:cobbled_deepslate
setblock 51 180 596 minecraft:cobbled_deepslate
setblock 51 180 597 minecraft:calcite
fill 51 180 598 54 180 598 minecraft:cobbled_deepslate
setblock 52 180 596 minecraft:calcite
fill 52 180 597 52 183 597 minecraft:cobbled_deepslate
setblock 55 180 597 minecraft:cobbled_deepslate
setblock 55 180 598 minecraft:calcite
fill 56 180 598 59 180 598 minecraft:cobbled_deepslate
setblock 58 180 560 minecraft:light[level=14]
setblock 58 180 568 minecraft:light[level=14]
setblock 58 180 576 minecraft:light[level=14]
setblock 58 180 584 minecraft:light[level=14]
setblock 58 180 592 minecraft:light[level=14]
setblock 60 180 597 minecraft:cobbled_deepslate
setblock 60 180 598 minecraft:calcite
setblock 61 180 597 minecraft:calcite
fill 61 180 598 64 180 598 minecraft:cobbled_deepslate
fill 62 180 597 65 180 597 minecraft:cobbled_deepslate
fill 63 180 596 66 180 596 minecraft:cobbled_deepslate
fill 65 180 595 67 180 595 minecraft:cobbled_deepslate
setblock 65 180 598 minecraft:calcite
fill 66 180 558 68 181 558 minecraft:cobbled_deepslate
setblock 66 180 560 minecraft:light[level=14]
setblock 66 180 568 minecraft:light[level=14]
setblock 66 180 584 minecraft:light[level=14]
setblock 66 180 592 minecraft:light[level=14]
setblock 66 180 597 minecraft:calcite
fill 66 180 598 69 180 598 minecraft:cobbled_deepslate
setblock 67 180 596 minecraft:calcite
fill 67 180 597 67 183 597 minecraft:cobbled_deepslate
setblock 68 180 595 minecraft:calcite
fill 68 180 596 68 183 596 minecraft:cobbled_deepslate
fill 70 180 596 70 181 596 minecraft:cobbled_deepslate
setblock 70 180 598 minecraft:calcite
setblock 71 180 597 minecraft:calcite
fill 71 180 598 71 183 598 minecraft:cobbled_deepslate
fill 73 180 573 74 181 579 minecraft:waxed_copper_block
setblock 74 180 560 minecraft:light[level=14]
setblock 74 180 568 minecraft:light[level=14]
fill 74 180 572 82 181 572 minecraft:waxed_copper_block
fill 74 180 580 82 181 580 minecraft:waxed_copper_block
setblock 74 180 584 minecraft:light[level=14]
setblock 74 180 592 minecraft:light[level=14]
fill 75 180 571 81 181 571 minecraft:waxed_copper_block
fill 75 180 573 75 181 575 minecraft:waxed_copper_block
fill 75 180 577 75 181 579 minecraft:waxed_copper_block
fill 75 180 581 81 181 581 minecraft:waxed_copper_block
fill 76 180 573 77 181 573 minecraft:waxed_copper_block
fill 76 180 579 77 181 579 minecraft:waxed_copper_block
fill 78 180 570 78 181 570 minecraft:waxed_copper_block
fill 78 180 582 78 181 582 minecraft:waxed_copper_block
fill 79 180 573 83 181 573 minecraft:waxed_copper_block
fill 79 180 579 83 181 579 minecraft:waxed_copper_block
fill 81 180 574 83 181 575 minecraft:waxed_copper_block
fill 81 180 577 83 181 578 minecraft:waxed_copper_block
setblock 82 180 560 minecraft:light[level=14]
setblock 82 180 568 minecraft:light[level=14]
fill 82 180 576 84 181 576 minecraft:waxed_copper_block
setblock 82 180 584 minecraft:light[level=14]
setblock 82 180 592 minecraft:light[level=14]
setblock 84 180 558 minecraft:cobbled_deepslate
setblock 85 180 558 minecraft:calcite
fill 85 180 566 85 180 567 minecraft:cobbled_deepslate
setblock 85 180 568 minecraft:calcite
fill 85 180 569 85 180 572 minecraft:cobbled_deepslate
setblock 85 180 573 minecraft:calcite
setblock 85 180 598 minecraft:calcite
fill 86 180 558 88 180 559 minecraft:cobbled_deepslate
fill 86 180 563 86 180 566 minecraft:cobbled_deepslate
setblock 86 180 567 minecraft:calcite
fill 86 180 568 86 183 568 minecraft:cobbled_deepslate
fill 86 180 570 86 180 571 minecraft:cobbled_deepslate
setblock 86 180 572 minecraft:calcite
fill 86 180 573 86 180 576 minecraft:cobbled_deepslate
fill 86 180 598 86 183 598 minecraft:cobbled_deepslate
setblock 87 180 560 minecraft:cobbled_deepslate
setblock 87 180 561 minecraft:calcite
fill 87 180 562 87 180 565 minecraft:cobbled_deepslate
setblock 87 180 566 minecraft:calcite
fill 87 180 567 87 183 567 minecraft:cobbled_deepslate
setblock 87 180 570 minecraft:cobbled_deepslate
setblock 87 180 571 minecraft:calcite
fill 87 180 572 87 183 572 minecraft:cobbled_deepslate
fill 87 180 574 87 180 575 minecraft:cobbled_deepslate
setblock 87 180 576 minecraft:calcite
fill 87 180 577 87 183 577 minecraft:cobbled_deepslate
fill 87 180 579 88 180 579 minecraft:cobbled_deepslate
setblock 87 180 585 minecraft:cobbled_deepslate
setblock 87 180 586 minecraft:calcite
fill 87 180 587 87 180 590 minecraft:cobbled_deepslate
setblock 87 180 591 minecraft:calcite
fill 87 180 592 87 183 592 minecraft:cobbled_deepslate
setblock 87 180 595 minecraft:cobbled_deepslate
setblock 87 180 596 minecraft:calcite
fill 87 180 597 87 183 597 minecraft:cobbled_deepslate
setblock 88 180 560 minecraft:calcite
fill 88 180 561 88 180 564 minecraft:cobbled_deepslate
setblock 88 180 565 minecraft:calcite
fill 88 180 566 88 183 566 minecraft:cobbled_deepslate
setblock 88 180 570 minecraft:calcite
fill 88 180 571 88 183 571 minecraft:cobbled_deepslate
setblock 88 180 574 minecraft:cobbled_deepslate
setblock 88 180 575 minecraft:calcite
fill 88 180 576 88 183 576 minecraft:cobbled_deepslate
setblock 88 180 580 minecraft:calcite
fill 88 180 581 88 180 584 minecraft:cobbled_deepslate
setblock 88 180 585 minecraft:calcite
fill 88 180 586 88 180 589 minecraft:cobbled_deepslate
setblock 88 180 590 minecraft:calcite
fill 88 180 591 88 183 591 minecraft:cobbled_deepslate
setblock 88 180 595 minecraft:calcite
fill 88 180 596 88 183 596 minecraft:cobbled_deepslate
setblock 48 181 558 minecraft:cobbled_deepslate
setblock 48 181 559 minecraft:calcite
fill 48 181 560 48 181 563 minecraft:cobbled_deepslate
setblock 48 181 564 minecraft:calcite
fill 48 181 565 48 181 568 minecraft:cobbled_deepslate
setblock 48 181 569 minecraft:calcite
fill 48 181 570 48 181 573 minecraft:cobbled_deepslate
setblock 48 181 574 minecraft:calcite
fill 48 181 575 48 184 575 minecraft:cobbled_deepslate
setblock 48 181 579 minecraft:calcite
fill 48 181 580 48 183 580 minecraft:cobbled_deepslate
fill 48 181 582 48 181 583 minecraft:cobbled_deepslate
setblock 48 181 584 minecraft:calcite
fill 48 181 585 48 181 588 minecraft:cobbled_deepslate
setblock 48 181 589 minecraft:calcite
fill 48 181 590 48 181 593 minecraft:cobbled_deepslate
setblock 48 181 594 minecraft:calcite
fill 48 181 595 48 184 595 minecraft:cobbled_deepslate
setblock 49 181 558 minecraft:calcite
fill 49 181 559 49 181 562 minecraft:cobbled_deepslate
setblock 49 181 563 minecraft:calcite
fill 49 181 564 49 181 567 minecraft:cobbled_deepslate
setblock 49 181 568 minecraft:calcite
fill 49 181 569 49 184 569 minecraft:cobbled_deepslate
setblock 49 181 572 minecraft:cobbled_deepslate
setblock 49 181 573 minecraft:calcite
fill 49 181 574 49 184 574 minecraft:cobbled_deepslate
fill 49 181 576 49 182 576 minecraft:cobbled_deepslate
fill 49 181 586 49 181 587 minecraft:cobbled_deepslate
setblock 49 181 588 minecraft:calcite
fill 49 181 589 49 181 592 minecraft:cobbled_deepslate
setblock 49 181 593 minecraft:calcite
fill 49 181 594 49 184 594 minecraft:cobbled_deepslate
setblock 49 181 597 minecraft:cobbled_deepslate
setblock 49 181 598 minecraft:calcite
fill 50 181 558 50 184 558 minecraft:cobbled_deepslate
fill 50 181 564 50 181 566 minecraft:cobbled_deepslate
setblock 50 181 567 minecraft:calcite
fill 50 181 568 50 182 568 minecraft:cobbled_deepslate
setblock 50 181 572 minecraft:calcite
setblock 50 181 591 minecraft:cobbled_deepslate
setblock 50 181 592 minecraft:calcite
fill 50 181 593 50 184 593 minecraft:cobbled_deepslate
setblock 50 181 597 minecraft:calcite
fill 50 181 598 53 181 598 minecraft:cobbled_deepslate
setblock 51 181 596 minecraft:calcite
fill 51 181 597 51 184 597 minecraft:cobbled_deepslate
fill 52 181 596 53 183 596 minecraft:cobbled_deepslate
setblock 53 181 558 minecraft:cobbled_deepslate
setblock 54 181 558 minecraft:calcite
setblock 54 181 598 minecraft:calcite
setblock 55 181 597 minecraft:calcite
fill 55 181 598 58 181 598 minecraft:cobbled_deepslate
fill 56 181 597 59 181 597 minecraft:cobbled_deepslate
setblock 59 181 598 minecraft:calcite
setblock 60 181 597 minecraft:calcite
fill 60 181 598 63 181 598 minecraft:cobbled_deepslate
setblock 61 181 596 minecraft:calcite
fill 61 181 597 64 181 597 minecraft:cobbled_deepslate
fill 62 181 596 65 181 596 minecraft:cobbled_deepslate
setblock 64 181 558 minecraft:calcite
fill 64 181 595 66 181 595 minecraft:cobbled_deepslate
setblock 64 181 598 minecraft:calcite
fill 65 181 558 65 184 558 minecraft:cobbled_deepslate
setblock 65 181 597 minecraft:calcite
fill 65 181 598 68 181 598 minecraft:cobbled_deepslate
setblock 66 181 596 minecraft:calcite
fill 66 181 597 66 184 597 minecraft:cobbled_deepslate
setblock 67 181 595 minecraft:calcite
fill 67 181 596 67 184 596 minecraft:cobbled_deepslate
fill 68 181 595 69 182 595 minecraft:cobbled_deepslate
setblock 69 181 558 minecraft:calcite
setblock 69 181 597 minecraft:cobbled_deepslate
setblock 69 181 598 minecraft:calcite
setblock 70 181 597 minecraft:calcite
fill 70 181 598 70 184 598 minecraft:cobbled_deepslate
fill 71 181 597 71 183 597 minecraft:cobbled_deepslate
setblock 73 181 598 minecraft:cobbled_deepslate
setblock 83 181 558 minecraft:cobbled_deepslate
setblock 83 181 598 minecraft:cobbled_deepslate
setblock 84 181 558 minecraft:calcite
setblock 84 181 598 minecraft:calcite
fill 85 181 558 87 181 559 minecraft:cobbled_deepslate
setblock 85 181 566 minecraft:cobbled_deepslate
setblock 85 181 567 minecraft:calcite
fill 85 181 568 85 181 571 minecraft:cobbled_deepslate
setblock 85 181 572 minecraft:calcite
fill 85 181 573 86 182 574 minecraft:cobbled_deepslate
fill 85 181 598 85 184 598 minecraft:cobbled_deepslate
fill 86 181 562 86 181 565 minecraft:cobbled_deepslate
setblock 86 181 566 minecraft:calcite
fill 86 181 567 86 184 567 minecraft:cobbled_deepslate
fill 86 181 569 86 181 570 minecraft:cobbled_deepslate
setblock 86 181 571 minecraft:calcite
fill 86 181 572 86 184 572 minecraft:cobbled_deepslate
setblock 86 181 575 minecraft:cobbled_deepslate
setblock 86 181 576 minecraft:calcite
fill 86 181 577 86 184 577 minecraft:cobbled_deepslate
setblock 86 181 591 minecraft:calcite
fill 86 181 592 86 183 593 minecraft:cobbled_deepslate
fill 86 181 597 86 184 597 minecraft:cobbled_deepslate
setblock 87 181 560 minecraft:calcite
fill 87 181 561 87 181 564 minecraft:cobbled_deepslate
setblock 87 181 565 minecraft:calcite
fill 87 181 566 87 184 566 minecraft:cobbled_deepslate
setblock 87 181 569 minecraft:cobbled_deepslate
setblock 87 181 570 minecraft:calcite
fill 87 181 571 87 184 571 minecraft:cobbled_deepslate
setblock 87 181 574 minecraft:cobbled_deepslate
setblock 87 181 575 minecraft:calcite
fill 87 181 576 87 184 576 minecraft:cobbled_deepslate
setblock 87 181 579 minecraft:cobbled_deepslate
setblock 87 181 580 minecraft:calcite
fill 87 181 586 87 181 589 minecraft:cobbled_deepslate
setblock 87 181 590 minecraft:calcite
fill 87 181 591 87 184 591 minecraft:cobbled_deepslate
fill 87 181 593 87 181 594 minecraft:cobbled_deepslate
setblock 87 181 595 minecraft:calcite
fill 87 181 596 87 184 596 minecraft:cobbled_deepslate
setblock 88 181 558 minecraft:cobbled_deepslate
setblock 88 181 559 minecraft:calcite
fill 88 181 560 88 181 563 minecraft:cobbled_deepslate
setblock 88 181 564 minecraft:calcite
fill 88 181 565 88 184 565 minecraft:cobbled_deepslate
setblock 88 181 569 minecraft:calcite
fill 88 181 570 88 184 570 minecraft:cobbled_deepslate
setblock 88 181 574 minecraft:calcite
fill 88 181 575 88 184 575 minecraft:cobbled_deepslate
setblock 88 181 579 minecraft:calcite
fill 88 181 580 88 181 583 minecraft:cobbled_deepslate
setblock 88 181 584 minecraft:calcite
fill 88 181 585 88 181 588 minecraft:cobbled_deepslate
setblock 88 181 589 minecraft:calcite
fill 88 181 590 88 184 590 minecraft:cobbled_deepslate
setblock 88 181 593 minecraft:cobbled_deepslate
setblock 88 181 594 minecraft:calcite
fill 88 181 595 88 184 595 minecraft:cobbled_deepslate
setblock 48 182 558 minecraft:calcite
fill 48 182 559 48 182 562 minecraft:cobbled_deepslate
setblock 48 182 563 minecraft:calcite
fill 48 182 564 48 182 567 minecraft:cobbled_deepslate
setblock 48 182 568 minecraft:calcite
fill 48 182 569 48 182 572 minecraft:cobbled_deepslate
setblock 48 182 573 minecraft:calcite
fill 48 182 574 48 185 574 minecraft:cobbled_deepslate
setblock 48 182 577 minecraft:cobbled_deepslate
setblock 48 182 578 minecraft:calcite
fill 48 182 579 48 185 579 minecraft:cobbled_deepslate
setblock 48 182 583 minecraft:calcite
fill 48 182 584 48 182 587 minecraft:cobbled_deepslate
setblock 48 182 588 minecraft:calcite
fill 48 182 589 48 182 592 minecraft:cobbled_deepslate
setblock 48 182 593 minecraft:calcite
fill 48 182 594 48 185 594 minecraft:cobbled_deepslate
fill 48 182 596 48 182 597 minecraft:cobbled_deepslate
setblock 48 182 598 minecraft:calcite
fill 49 182 558 49 182 561 minecraft:cobbled_deepslate
setblock 49 182 562 minecraft:calcite
fill 49 182 563 49 182 566 minecraft:cobbled_deepslate
setblock 49 182 567 minecraft:calcite
fill 49 182 568 49 184 568 minecraft:cobbled_deepslate
setblock 49 182 572 minecraft:calcite
fill 49 182 573 49 185 573 minecraft:cobbled_deepslate
setblock 49 182 587 minecraft:calcite
fill 49 182 588 49 182 591 minecraft:cobbled_deepslate
setblock 49 182 592 minecraft:calcite
fill 49 182 593 49 185 593 minecraft:cobbled_deepslate
setblock 49 182 596 minecraft:cobbled_deepslate
setblock 49 182 597 minecraft:calcite
fill 49 182 598 52 182 598 minecraft:cobbled_deepslate
setblock 50 182 567 minecraft:cobbled_deepslate
setblock 50 182 571 minecraft:calcite
setblock 50 182 572 minecraft:cobbled_deepslate
setblock 50 182 591 minecraft:calcite
fill 50 182 592 50 184 592 minecraft:cobbled_deepslate
setblock 50 182 596 minecraft:calcite
fill 50 182 597 50 185 597 minecraft:cobbled_deepslate
fill 51 182 596 51 185 596 minecraft:cobbled_deepslate
setblock 53 182 558 minecraft:calcite
setblock 53 182 597 minecraft:cobbled_deepslate
setblock 53 182 598 minecraft:calcite
fill 54 182 558 54 183 558 minecraft:cobbled_deepslate
setblock 54 182 597 minecraft:calcite
fill 54 182 598 57 182 598 minecraft:cobbled_deepslate
fill 55 182 597 58 182 597 minecraft:cobbled_deepslate
setblock 58 182 598 minecraft:calcite
setblock 59 182 597 minecraft:calcite
fill 59 182 598 62 182 598 minecraft:cobbled_deepslate
schedule function dropper:buildpart/133_6 1t
