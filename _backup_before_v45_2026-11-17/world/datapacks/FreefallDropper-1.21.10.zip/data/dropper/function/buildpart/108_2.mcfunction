fill 8 98 497 8 99 497 minecraft:bookshelf
fill 8 98 499 8 99 499 minecraft:bookshelf
fill 8 98 501 8 99 501 minecraft:bookshelf
fill 8 98 503 8 99 503 minecraft:bookshelf
fill 9 98 494 9 99 494 minecraft:bookshelf
fill 9 98 496 9 99 496 minecraft:bookshelf
fill 9 98 498 9 99 498 minecraft:bookshelf
fill 9 98 500 9 99 500 minecraft:bookshelf
fill 9 98 502 9 99 502 minecraft:bookshelf
fill 9 98 504 9 99 504 minecraft:bookshelf
fill 10 98 463 11 201 463 minecraft:bookshelf
fill 10 98 495 10 99 495 minecraft:bookshelf
fill 10 98 497 10 99 497 minecraft:bookshelf
fill 10 98 499 10 99 499 minecraft:bookshelf
fill 10 98 501 10 99 501 minecraft:bookshelf
fill 10 98 503 10 99 503 minecraft:bookshelf
fill 10 98 505 10 201 505 minecraft:bookshelf
fill 11 98 494 11 99 494 minecraft:bookshelf
fill 11 98 496 11 99 496 minecraft:bookshelf
fill 11 98 498 11 99 498 minecraft:bookshelf
fill 11 98 500 11 99 500 minecraft:bookshelf
fill 11 98 502 11 99 502 minecraft:bookshelf
fill 11 98 504 11 99 504 minecraft:bookshelf
fill 12 98 495 12 99 495 minecraft:bookshelf
fill 12 98 497 12 99 497 minecraft:bookshelf
fill 12 98 499 12 99 499 minecraft:bookshelf
fill 12 98 501 12 99 501 minecraft:bookshelf
fill 12 98 503 12 99 503 minecraft:bookshelf
fill 15 98 463 15 198 463 minecraft:bookshelf
fill 21 98 505 21 199 505 minecraft:bookshelf
fill 22 98 463 22 201 463 minecraft:bookshelf
fill 32 98 463 32 204 463 minecraft:bookshelf
fill 42 98 474 42 201 474 minecraft:bookshelf
fill 42 98 487 42 197 487 minecraft:bookshelf
fill 42 98 489 42 201 490 minecraft:bookshelf
fill 42 98 496 42 197 497 minecraft:bookshelf
fill 42 98 501 42 201 501 minecraft:bookshelf
fill 42 98 503 42 199 503 minecraft:bookshelf
fill 1 99 484 1 100 484 minecraft:bookshelf
fill 1 99 491 1 100 491 minecraft:bookshelf
fill 1 99 498 1 101 498 minecraft:bookshelf
fill 1 99 502 4 99 503 minecraft:bookshelf
fill 2 99 464 2 100 464 minecraft:bookshelf
fill 2 99 501 3 100 501 minecraft:bookshelf
fill 2 99 504 3 100 504 minecraft:bookshelf
fill 3 99 500 3 100 500 minecraft:bookshelf
setblock 5 99 502 minecraft:bookshelf
fill 9 99 464 9 100 464 minecraft:bookshelf
fill 16 99 464 16 100 464 minecraft:bookshelf
fill 16 99 504 16 100 504 minecraft:bookshelf
fill 23 99 464 23 100 464 minecraft:bookshelf
fill 23 99 504 23 100 504 minecraft:bookshelf
fill 30 99 464 30 100 464 minecraft:bookshelf
fill 30 99 504 30 100 504 minecraft:bookshelf
fill 37 99 464 37 100 464 minecraft:bookshelf
fill 37 99 504 37 100 504 minecraft:bookshelf
fill 41 99 467 41 100 467 minecraft:bookshelf
fill 41 99 474 41 100 474 minecraft:bookshelf
fill 41 99 481 41 100 481 minecraft:bookshelf
fill 41 99 488 41 100 488 minecraft:bookshelf
fill 41 99 495 41 100 495 minecraft:bookshelf
fill 41 99 502 41 100 502 minecraft:bookshelf
fill 1 100 464 1 100 468 minecraft:bookshelf
fill 1 100 478 1 100 482 minecraft:bookshelf
fill 1 100 485 1 100 489 minecraft:bookshelf
fill 1 100 492 1 100 496 minecraft:bookshelf
fill 1 100 499 1 100 503 minecraft:bookshelf
fill 2 100 496 2 100 500 minecraft:bookshelf
fill 2 100 502 2 100 503 minecraft:bookshelf
fill 3 100 496 3 100 499 minecraft:bookshelf
setblock 3 100 502 minecraft:bookshelf
fill 4 100 464 8 100 464 minecraft:bookshelf
setblock 6 100 495 minecraft:ochre_froglight
setblock 6 100 497 minecraft:ochre_froglight
setblock 6 100 499 minecraft:ochre_froglight
setblock 6 100 501 minecraft:ochre_froglight
setblock 6 100 503 minecraft:ochre_froglight
setblock 7 100 494 minecraft:ochre_froglight
setblock 7 100 496 minecraft:ochre_froglight
setblock 7 100 498 minecraft:ochre_froglight
setblock 7 100 500 minecraft:ochre_froglight
setblock 7 100 502 minecraft:ochre_froglight
setblock 7 100 504 minecraft:ochre_froglight
setblock 8 100 495 minecraft:ochre_froglight
setblock 8 100 497 minecraft:ochre_froglight
setblock 8 100 499 minecraft:ochre_froglight
setblock 8 100 501 minecraft:ochre_froglight
setblock 8 100 503 minecraft:ochre_froglight
setblock 9 100 494 minecraft:ochre_froglight
setblock 9 100 496 minecraft:ochre_froglight
setblock 9 100 498 minecraft:ochre_froglight
setblock 9 100 500 minecraft:ochre_froglight
setblock 9 100 502 minecraft:ochre_froglight
setblock 9 100 504 minecraft:ochre_froglight
setblock 10 100 495 minecraft:ochre_froglight
setblock 10 100 497 minecraft:ochre_froglight
setblock 10 100 499 minecraft:ochre_froglight
setblock 10 100 501 minecraft:ochre_froglight
setblock 10 100 503 minecraft:ochre_froglight
fill 11 100 464 15 100 464 minecraft:bookshelf
setblock 11 100 494 minecraft:ochre_froglight
setblock 11 100 496 minecraft:ochre_froglight
setblock 11 100 498 minecraft:ochre_froglight
setblock 11 100 500 minecraft:ochre_froglight
setblock 11 100 502 minecraft:ochre_froglight
setblock 11 100 504 minecraft:ochre_froglight
setblock 12 100 495 minecraft:ochre_froglight
setblock 12 100 497 minecraft:ochre_froglight
setblock 12 100 499 minecraft:ochre_froglight
setblock 12 100 501 minecraft:ochre_froglight
setblock 12 100 503 minecraft:ochre_froglight
fill 13 100 504 14 100 504 minecraft:bookshelf
fill 17 100 504 21 100 504 minecraft:bookshelf
fill 18 100 464 22 100 464 minecraft:bookshelf
fill 24 100 504 28 100 504 minecraft:bookshelf
fill 25 100 464 29 100 464 minecraft:bookshelf
fill 31 100 504 35 100 504 minecraft:bookshelf
fill 32 100 464 36 100 464 minecraft:bookshelf
fill 38 100 504 41 100 504 minecraft:bookshelf
fill 39 100 464 41 100 464 minecraft:bookshelf
fill 41 100 465 41 100 466 minecraft:bookshelf
fill 41 100 469 41 100 473 minecraft:bookshelf
fill 41 100 476 41 100 480 minecraft:bookshelf
fill 41 100 483 41 100 487 minecraft:bookshelf
fill 41 100 490 41 100 494 minecraft:bookshelf
fill 41 100 497 41 100 501 minecraft:bookshelf
setblock 1 101 465 minecraft:bookshelf
setblock 1 101 479 minecraft:bookshelf
setblock 1 101 486 minecraft:bookshelf
fill 1 101 493 3 101 496 minecraft:bookshelf
fill 1 101 499 1 101 500 minecraft:bookshelf
fill 2 101 492 3 102 492 minecraft:bookshelf
fill 2 101 497 2 101 498 minecraft:bookshelf
setblock 3 101 497 minecraft:bookshelf
setblock 4 101 504 minecraft:bookshelf
fill 6 101 495 6 102 495 minecraft:bookshelf
fill 6 101 497 6 102 497 minecraft:bookshelf
fill 6 101 499 6 102 499 minecraft:bookshelf
fill 6 101 501 6 102 501 minecraft:bookshelf
fill 6 101 503 6 102 503 minecraft:bookshelf
setblock 7 101 464 minecraft:bookshelf
fill 7 101 494 7 102 494 minecraft:bookshelf
fill 7 101 496 7 102 496 minecraft:bookshelf
fill 7 101 498 7 102 498 minecraft:bookshelf
fill 7 101 500 7 102 500 minecraft:bookshelf
fill 7 101 502 7 102 502 minecraft:bookshelf
fill 7 101 504 7 102 504 minecraft:bookshelf
fill 8 101 495 8 102 495 minecraft:bookshelf
fill 8 101 497 8 102 497 minecraft:bookshelf
fill 8 101 499 8 102 499 minecraft:bookshelf
fill 8 101 501 8 102 501 minecraft:bookshelf
fill 8 101 503 8 102 503 minecraft:bookshelf
fill 9 101 494 9 102 494 minecraft:bookshelf
fill 9 101 496 9 102 496 minecraft:bookshelf
fill 9 101 498 9 102 498 minecraft:bookshelf
fill 9 101 500 9 102 500 minecraft:bookshelf
fill 9 101 502 9 102 502 minecraft:bookshelf
fill 9 101 504 9 102 504 minecraft:bookshelf
fill 10 101 495 10 102 495 minecraft:bookshelf
fill 10 101 497 10 102 497 minecraft:bookshelf
fill 10 101 499 10 102 499 minecraft:bookshelf
fill 10 101 501 10 102 501 minecraft:bookshelf
fill 10 101 503 10 102 503 minecraft:bookshelf
fill 11 101 494 11 102 494 minecraft:bookshelf
fill 11 101 496 11 102 496 minecraft:bookshelf
fill 11 101 498 11 102 498 minecraft:bookshelf
fill 11 101 500 11 102 500 minecraft:bookshelf
fill 11 101 502 11 102 502 minecraft:bookshelf
fill 11 101 504 11 102 504 minecraft:bookshelf
fill 12 101 495 12 102 495 minecraft:bookshelf
fill 12 101 497 12 102 497 minecraft:bookshelf
fill 12 101 499 12 102 499 minecraft:bookshelf
fill 12 101 501 12 102 501 minecraft:bookshelf
fill 12 101 503 12 102 503 minecraft:bookshelf
setblock 14 101 464 minecraft:bookshelf
setblock 18 101 504 minecraft:bookshelf
setblock 21 101 464 minecraft:bookshelf
setblock 25 101 504 minecraft:bookshelf
setblock 28 101 464 minecraft:bookshelf
setblock 32 101 504 minecraft:bookshelf
setblock 35 101 464 minecraft:bookshelf
setblock 39 101 504 minecraft:bookshelf
setblock 41 101 465 minecraft:bookshelf
setblock 41 101 472 minecraft:bookshelf
setblock 41 101 479 minecraft:bookshelf
setblock 41 101 486 minecraft:bookshelf
setblock 41 101 493 minecraft:bookshelf
setblock 41 101 500 minecraft:bookshelf
setblock 1 102 466 minecraft:bookshelf
setblock 1 102 480 minecraft:bookshelf
fill 1 102 487 1 104 487 minecraft:bookshelf
fill 1 102 489 3 103 489 minecraft:bookshelf
fill 1 102 491 1 102 494 minecraft:bookshelf
setblock 1 102 501 minecraft:bookshelf
fill 2 102 490 3 102 491 minecraft:bookshelf
fill 2 102 493 2 102 494 minecraft:bookshelf
setblock 3 102 466 minecraft:light[level=12]
setblock 3 102 482 minecraft:light[level=12]
setblock 3 102 493 minecraft:bookshelf
setblock 3 102 498 minecraft:light[level=12]
setblock 5 102 504 minecraft:bookshelf
setblock 6 102 464 minecraft:bookshelf
setblock 11 102 466 minecraft:light[level=12]
setblock 11 102 474 minecraft:light[level=12]
setblock 11 102 482 minecraft:light[level=12]
setblock 11 102 490 minecraft:light[level=12]
setblock 13 102 464 minecraft:bookshelf
setblock 19 102 466 minecraft:light[level=12]
setblock 19 102 474 minecraft:light[level=12]
setblock 19 102 482 minecraft:light[level=12]
setblock 19 102 498 minecraft:light[level=12]
setblock 19 102 504 minecraft:bookshelf
setblock 20 102 464 minecraft:bookshelf
setblock 26 102 504 minecraft:bookshelf
setblock 27 102 464 minecraft:bookshelf
setblock 27 102 466 minecraft:light[level=12]
setblock 27 102 474 minecraft:light[level=12]
setblock 27 102 482 minecraft:light[level=12]
setblock 27 102 490 minecraft:light[level=12]
setblock 27 102 498 minecraft:light[level=12]
setblock 33 102 504 minecraft:bookshelf
setblock 34 102 464 minecraft:bookshelf
setblock 35 102 466 minecraft:light[level=12]
setblock 35 102 474 minecraft:light[level=12]
setblock 35 102 482 minecraft:light[level=12]
setblock 35 102 490 minecraft:light[level=12]
setblock 35 102 498 minecraft:light[level=12]
setblock 40 102 504 minecraft:bookshelf
setblock 41 102 464 minecraft:bookshelf
setblock 41 102 471 minecraft:bookshelf
setblock 41 102 478 minecraft:bookshelf
setblock 41 102 485 minecraft:bookshelf
setblock 41 102 492 minecraft:bookshelf
setblock 41 102 499 minecraft:bookshelf
setblock 1 103 467 minecraft:bookshelf
fill 1 103 469 1 152 469 minecraft:bookshelf
setblock 1 103 474 minecraft:bookshelf
fill 1 103 476 1 152 476 minecraft:bookshelf
setblock 1 103 481 minecraft:bookshelf
fill 1 103 486 3 104 486 minecraft:bookshelf
fill 1 103 488 3 103 488 minecraft:bookshelf
setblock 1 103 495 minecraft:bookshelf
setblock 1 103 502 minecraft:bookshelf
fill 2 103 487 3 104 487 minecraft:bookshelf
fill 2 103 490 3 103 490 minecraft:bookshelf
setblock 5 103 464 minecraft:bookshelf
setblock 6 103 495 minecraft:ochre_froglight
setblock 6 103 497 minecraft:ochre_froglight
setblock 6 103 499 minecraft:ochre_froglight
setblock 6 103 501 minecraft:ochre_froglight
setblock 6 103 503 minecraft:ochre_froglight
setblock 7 103 494 minecraft:ochre_froglight
setblock 7 103 496 minecraft:ochre_froglight
setblock 7 103 498 minecraft:ochre_froglight
setblock 7 103 500 minecraft:ochre_froglight
setblock 7 103 502 minecraft:ochre_froglight
setblock 7 103 504 minecraft:ochre_froglight
setblock 8 103 495 minecraft:ochre_froglight
setblock 8 103 497 minecraft:ochre_froglight
setblock 8 103 499 minecraft:ochre_froglight
setblock 8 103 501 minecraft:ochre_froglight
setblock 8 103 503 minecraft:ochre_froglight
setblock 9 103 494 minecraft:ochre_froglight
setblock 9 103 496 minecraft:ochre_froglight
setblock 9 103 498 minecraft:ochre_froglight
setblock 9 103 500 minecraft:ochre_froglight
setblock 9 103 502 minecraft:ochre_froglight
setblock 9 103 504 minecraft:ochre_froglight
setblock 10 103 495 minecraft:ochre_froglight
setblock 10 103 497 minecraft:ochre_froglight
setblock 10 103 499 minecraft:ochre_froglight
setblock 10 103 501 minecraft:ochre_froglight
setblock 10 103 503 minecraft:ochre_froglight
setblock 11 103 494 minecraft:ochre_froglight
setblock 11 103 496 minecraft:ochre_froglight
setblock 11 103 498 minecraft:ochre_froglight
setblock 11 103 500 minecraft:ochre_froglight
setblock 11 103 502 minecraft:ochre_froglight
setblock 11 103 504 minecraft:ochre_froglight
setblock 12 103 464 minecraft:bookshelf
setblock 12 103 495 minecraft:ochre_froglight
setblock 12 103 497 minecraft:ochre_froglight
setblock 12 103 499 minecraft:ochre_froglight
setblock 12 103 501 minecraft:ochre_froglight
setblock 12 103 503 minecraft:ochre_froglight
setblock 13 103 504 minecraft:bookshelf
setblock 19 103 464 minecraft:bookshelf
setblock 20 103 504 minecraft:bookshelf
setblock 26 103 464 minecraft:bookshelf
setblock 27 103 504 minecraft:bookshelf
setblock 33 103 464 minecraft:bookshelf
setblock 34 103 504 minecraft:bookshelf
setblock 40 103 464 minecraft:bookshelf
setblock 41 103 470 minecraft:bookshelf
setblock 41 103 477 minecraft:bookshelf
setblock 41 103 484 minecraft:bookshelf
setblock 41 103 491 minecraft:bookshelf
setblock 41 103 498 minecraft:bookshelf
setblock 41 103 504 minecraft:bookshelf
setblock 1 104 468 minecraft:bookshelf
setblock 1 104 475 minecraft:bookshelf
fill 1 104 482 1 105 482 minecraft:bookshelf
fill 1 104 484 3 104 485 minecraft:bookshelf
setblock 1 104 489 minecraft:bookshelf
setblock 1 104 496 minecraft:bookshelf
setblock 1 104 503 minecraft:bookshelf
fill 2 104 483 3 105 483 minecraft:bookshelf
setblock 4 104 464 minecraft:bookshelf
fill 6 104 495 6 105 495 minecraft:bookshelf
fill 6 104 497 6 105 497 minecraft:bookshelf
fill 6 104 499 6 105 499 minecraft:bookshelf
fill 6 104 501 6 105 501 minecraft:bookshelf
fill 6 104 503 6 105 503 minecraft:bookshelf
fill 7 104 494 7 105 494 minecraft:bookshelf
fill 7 104 496 7 105 496 minecraft:bookshelf
fill 7 104 498 7 105 498 minecraft:bookshelf
fill 7 104 500 7 105 500 minecraft:bookshelf
fill 7 104 502 7 105 502 minecraft:bookshelf
fill 7 104 504 7 105 504 minecraft:bookshelf
fill 8 104 495 8 105 495 minecraft:bookshelf
fill 8 104 497 8 105 497 minecraft:bookshelf
fill 8 104 499 8 105 499 minecraft:bookshelf
fill 8 104 501 8 105 501 minecraft:bookshelf
fill 8 104 503 8 105 503 minecraft:bookshelf
fill 9 104 494 9 105 494 minecraft:bookshelf
fill 9 104 496 9 105 496 minecraft:bookshelf
fill 9 104 498 9 105 498 minecraft:bookshelf
fill 9 104 500 9 105 500 minecraft:bookshelf
fill 9 104 502 9 105 502 minecraft:bookshelf
fill 9 104 504 9 106 504 minecraft:bookshelf
fill 10 104 495 10 105 495 minecraft:bookshelf
fill 10 104 497 10 105 497 minecraft:bookshelf
fill 10 104 499 10 105 499 minecraft:bookshelf
fill 10 104 501 10 105 501 minecraft:bookshelf
fill 10 104 503 10 105 503 minecraft:bookshelf
setblock 11 104 464 minecraft:bookshelf
fill 11 104 494 11 105 494 minecraft:bookshelf
fill 11 104 496 11 105 496 minecraft:bookshelf
fill 11 104 498 11 105 498 minecraft:bookshelf
fill 11 104 500 11 105 500 minecraft:bookshelf
fill 11 104 502 11 105 502 minecraft:bookshelf
fill 11 104 504 11 105 504 minecraft:bookshelf
fill 12 104 495 12 105 495 minecraft:bookshelf
fill 12 104 497 12 105 497 minecraft:bookshelf
fill 12 104 499 12 105 499 minecraft:bookshelf
fill 12 104 501 12 105 501 minecraft:bookshelf
fill 12 104 503 12 105 503 minecraft:bookshelf
setblock 14 104 504 minecraft:bookshelf
setblock 18 104 464 minecraft:bookshelf
setblock 21 104 504 minecraft:bookshelf
setblock 25 104 464 minecraft:bookshelf
setblock 28 104 504 minecraft:bookshelf
setblock 32 104 464 minecraft:bookshelf
setblock 35 104 504 minecraft:bookshelf
setblock 39 104 464 minecraft:bookshelf
setblock 41 104 469 minecraft:bookshelf
setblock 41 104 476 minecraft:bookshelf
setblock 41 104 483 minecraft:bookshelf
setblock 41 104 490 minecraft:bookshelf
setblock 41 104 497 minecraft:bookshelf
fill 1 105 480 3 106 481 minecraft:bookshelf
fill 1 105 484 3 105 484 minecraft:bookshelf
fill 2 105 482 3 105 482 minecraft:bookshelf
setblock 1 106 470 minecraft:bookshelf
fill 1 106 477 3 106 479 minecraft:bookshelf
setblock 1 106 484 minecraft:bookshelf
setblock 1 106 491 minecraft:bookshelf
setblock 1 106 498 minecraft:bookshelf
setblock 2 106 464 minecraft:bookshelf
setblock 2 106 504 minecraft:bookshelf
setblock 9 106 464 minecraft:bookshelf
setblock 16 106 464 minecraft:bookshelf
setblock 16 106 504 minecraft:bookshelf
setblock 23 106 464 minecraft:bookshelf
setblock 23 106 504 minecraft:bookshelf
setblock 30 106 464 minecraft:bookshelf
setblock 30 106 504 minecraft:bookshelf
setblock 37 106 464 minecraft:bookshelf
setblock 37 106 504 minecraft:bookshelf
setblock 41 106 467 minecraft:bookshelf
setblock 41 106 474 minecraft:bookshelf
setblock 41 106 481 minecraft:bookshelf
setblock 41 106 488 minecraft:bookshelf
setblock 41 106 495 minecraft:bookshelf
setblock 41 106 502 minecraft:bookshelf
setblock 1 107 464 minecraft:bookshelf
fill 1 107 471 1 107 475 minecraft:bookshelf
fill 1 107 477 3 107 478 minecraft:bookshelf
setblock 1 107 485 minecraft:bookshelf
setblock 1 107 492 minecraft:bookshelf
setblock 1 107 499 minecraft:bookshelf
fill 2 107 473 3 107 476 minecraft:bookshelf
setblock 3 107 504 minecraft:bookshelf
setblock 8 107 464 minecraft:bookshelf
setblock 10 107 504 minecraft:bookshelf
setblock 15 107 464 minecraft:bookshelf
setblock 17 107 504 minecraft:bookshelf
setblock 22 107 464 minecraft:bookshelf
setblock 24 107 504 minecraft:bookshelf
setblock 29 107 464 minecraft:bookshelf
setblock 31 107 504 minecraft:bookshelf
setblock 36 107 464 minecraft:bookshelf
setblock 38 107 504 minecraft:bookshelf
setblock 41 107 466 minecraft:bookshelf
setblock 41 107 473 minecraft:bookshelf
setblock 41 107 480 minecraft:bookshelf
setblock 41 107 487 minecraft:bookshelf
setblock 41 107 494 minecraft:bookshelf
setblock 41 107 501 minecraft:bookshelf
fill 1 108 465 1 110 465 minecraft:bookshelf
fill 1 108 467 1 110 468 minecraft:bookshelf
fill 1 108 470 3 108 474 minecraft:bookshelf
setblock 1 108 479 minecraft:bookshelf
setblock 1 108 486 minecraft:bookshelf
setblock 1 108 493 minecraft:bookshelf
setblock 1 108 500 minecraft:bookshelf
fill 2 108 468 2 109 469 minecraft:bookshelf
fill 3 108 469 3 109 469 minecraft:bookshelf
setblock 3 108 475 minecraft:bookshelf
setblock 4 108 504 minecraft:bookshelf
setblock 7 108 464 minecraft:bookshelf
setblock 11 108 504 minecraft:bookshelf
setblock 14 108 464 minecraft:bookshelf
setblock 18 108 504 minecraft:bookshelf
setblock 21 108 464 minecraft:bookshelf
setblock 25 108 504 minecraft:bookshelf
setblock 28 108 464 minecraft:bookshelf
setblock 32 108 504 minecraft:bookshelf
setblock 35 108 464 minecraft:bookshelf
setblock 39 108 504 minecraft:bookshelf
setblock 41 108 465 minecraft:bookshelf
setblock 41 108 472 minecraft:bookshelf
setblock 41 108 479 minecraft:bookshelf
setblock 41 108 486 minecraft:bookshelf
setblock 41 108 493 minecraft:bookshelf
setblock 41 108 500 minecraft:bookshelf
fill 1 109 464 2 110 464 minecraft:bookshelf
fill 1 109 466 5 109 466 minecraft:bookshelf
fill 1 109 473 1 110 473 minecraft:bookshelf
fill 1 109 480 1 110 480 minecraft:bookshelf
fill 1 109 487 1 110 487 minecraft:bookshelf
fill 1 109 494 1 110 494 minecraft:bookshelf
fill 1 109 501 1 110 501 minecraft:bookshelf
fill 2 109 465 4 110 465 minecraft:bookshelf
fill 2 109 467 3 109 467 minecraft:bookshelf
fill 2 109 470 3 109 470 minecraft:bookshelf
setblock 3 109 468 minecraft:bookshelf
setblock 3 109 471 minecraft:bookshelf
fill 5 109 504 5 110 504 minecraft:bookshelf
fill 6 109 464 6 111 464 minecraft:bookshelf
fill 12 109 504 12 110 504 minecraft:bookshelf
fill 13 109 464 13 110 464 minecraft:bookshelf
fill 19 109 504 19 110 504 minecraft:bookshelf
fill 20 109 464 20 110 464 minecraft:bookshelf
fill 26 109 504 26 110 504 minecraft:bookshelf
fill 27 109 464 27 110 464 minecraft:bookshelf
fill 31 109 487 32 110 488 minecraft:blue_wool
fill 33 109 488 33 110 488 minecraft:blue_wool
fill 33 109 504 33 110 504 minecraft:bookshelf
fill 34 109 464 34 110 464 minecraft:bookshelf
fill 40 109 504 40 110 504 minecraft:bookshelf
fill 41 109 464 41 110 464 minecraft:bookshelf
fill 41 109 471 41 110 471 minecraft:bookshelf
fill 41 109 478 41 110 478 minecraft:bookshelf
fill 41 109 485 41 110 485 minecraft:bookshelf
fill 41 109 492 41 110 492 minecraft:bookshelf
fill 41 109 499 41 110 499 minecraft:bookshelf
setblock 1 110 466 minecraft:bookshelf
fill 1 110 470 1 110 472 minecraft:bookshelf
fill 1 110 474 1 110 475 minecraft:bookshelf
fill 1 110 477 1 110 479 minecraft:bookshelf
fill 1 110 481 1 110 482 minecraft:bookshelf
fill 1 110 484 1 110 486 minecraft:bookshelf
fill 1 110 488 1 110 489 minecraft:bookshelf
fill 1 110 491 1 110 493 minecraft:bookshelf
fill 1 110 495 1 110 496 minecraft:bookshelf
fill 1 110 498 1 110 500 minecraft:bookshelf
fill 1 110 502 1 110 503 minecraft:bookshelf
fill 2 110 504 4 110 504 minecraft:bookshelf
fill 3 110 466 9 110 466 minecraft:bookshelf
setblock 3 110 474 minecraft:light[level=12]
setblock 3 110 482 minecraft:light[level=12]
setblock 3 110 490 minecraft:light[level=12]
setblock 3 110 498 minecraft:light[level=12]
fill 4 110 464 5 110 464 minecraft:bookshelf
fill 5 110 465 9 110 465 minecraft:bookshelf
fill 6 110 504 7 110 504 minecraft:bookshelf
fill 7 110 464 9 111 464 minecraft:bookshelf
fill 9 110 504 11 110 504 minecraft:bookshelf
fill 11 110 464 12 112 464 minecraft:bookshelf
setblock 11 110 466 minecraft:light[level=12]
setblock 11 110 474 minecraft:light[level=12]
setblock 11 110 482 minecraft:light[level=12]
setblock 11 110 490 minecraft:light[level=12]
setblock 11 110 498 minecraft:light[level=12]
fill 13 110 504 14 110 504 minecraft:bookshelf
fill 14 110 464 16 110 464 minecraft:bookshelf
fill 16 110 504 18 110 504 minecraft:bookshelf
fill 18 110 464 19 110 464 minecraft:bookshelf
setblock 19 110 466 minecraft:light[level=12]
setblock 19 110 474 minecraft:light[level=12]
setblock 19 110 482 minecraft:light[level=12]
setblock 19 110 498 minecraft:light[level=12]
fill 20 110 504 21 110 504 minecraft:bookshelf
fill 21 110 464 23 110 464 minecraft:bookshelf
fill 23 110 504 25 110 504 minecraft:bookshelf
fill 25 110 464 26 110 464 minecraft:bookshelf
setblock 27 110 466 minecraft:light[level=12]
setblock 27 110 474 minecraft:light[level=12]
setblock 27 110 482 minecraft:light[level=12]
setblock 27 110 490 minecraft:light[level=12]
setblock 27 110 498 minecraft:light[level=12]
fill 27 110 504 28 110 504 minecraft:bookshelf
fill 28 110 464 30 110 464 minecraft:bookshelf
fill 30 110 504 32 110 504 minecraft:bookshelf
fill 32 110 464 33 110 464 minecraft:bookshelf
fill 34 110 504 35 110 504 minecraft:bookshelf
fill 35 110 464 37 110 464 minecraft:bookshelf
setblock 35 110 466 minecraft:light[level=12]
setblock 35 110 474 minecraft:light[level=12]
setblock 35 110 482 minecraft:light[level=12]
setblock 35 110 490 minecraft:light[level=12]
setblock 35 110 498 minecraft:light[level=12]
fill 37 110 504 39 110 504 minecraft:bookshelf
fill 39 110 464 40 110 464 minecraft:bookshelf
fill 41 110 465 41 110 467 minecraft:bookshelf
fill 41 110 469 41 110 470 minecraft:bookshelf
fill 41 110 472 41 110 474 minecraft:bookshelf
fill 41 110 476 41 110 477 minecraft:bookshelf
fill 41 110 479 41 110 481 minecraft:bookshelf
fill 41 110 483 41 110 484 minecraft:bookshelf
fill 41 110 486 41 110 488 minecraft:bookshelf
fill 41 110 490 41 110 491 minecraft:bookshelf
fill 41 110 493 41 110 495 minecraft:bookshelf
fill 41 110 497 41 110 498 minecraft:bookshelf
fill 41 110 500 41 110 502 minecraft:bookshelf
setblock 41 110 504 minecraft:bookshelf
setblock 1 111 468 minecraft:bookshelf
setblock 1 111 475 minecraft:bookshelf
setblock 1 111 482 minecraft:bookshelf
setblock 1 111 489 minecraft:bookshelf
setblock 1 111 496 minecraft:bookshelf
setblock 1 111 503 minecraft:bookshelf
setblock 4 111 464 minecraft:bookshelf
fill 7 111 465 13 111 465 minecraft:bookshelf
setblock 7 111 504 minecraft:bookshelf
fill 8 111 466 13 111 466 minecraft:bookshelf
setblock 14 111 504 minecraft:bookshelf
setblock 18 111 464 minecraft:bookshelf
setblock 21 111 504 minecraft:bookshelf
setblock 25 111 464 minecraft:bookshelf
setblock 28 111 504 minecraft:bookshelf
setblock 32 111 464 minecraft:bookshelf
setblock 35 111 504 minecraft:bookshelf
setblock 39 111 464 minecraft:bookshelf
setblock 41 111 469 minecraft:bookshelf
setblock 41 111 476 minecraft:bookshelf
setblock 41 111 483 minecraft:bookshelf
setblock 41 111 490 minecraft:bookshelf
setblock 41 111 497 minecraft:bookshelf
fill 11 112 465 16 112 465 minecraft:bookshelf
fill 12 112 466 16 112 466 minecraft:bookshelf
fill 13 112 464 16 112 464 minecraft:bookshelf
setblock 1 113 470 minecraft:bookshelf
setblock 1 113 477 minecraft:bookshelf
setblock 1 113 484 minecraft:bookshelf
setblock 1 113 491 minecraft:bookshelf
setblock 1 113 498 minecraft:bookshelf
setblock 2 113 464 minecraft:bookshelf
setblock 2 113 504 minecraft:bookshelf
setblock 9 113 464 minecraft:bookshelf
setblock 9 113 504 minecraft:bookshelf
fill 15 113 464 16 113 466 minecraft:bookshelf
setblock 16 113 504 minecraft:bookshelf
fill 17 113 465 19 113 466 minecraft:bookshelf
fill 18 113 464 19 114 464 minecraft:bookshelf
setblock 23 113 464 minecraft:bookshelf
setblock 23 113 504 minecraft:bookshelf
setblock 30 113 464 minecraft:bookshelf
setblock 30 113 504 minecraft:bookshelf
setblock 37 113 464 minecraft:bookshelf
setblock 37 113 504 minecraft:bookshelf
setblock 41 113 467 minecraft:bookshelf
setblock 41 113 474 minecraft:bookshelf
setblock 41 113 481 minecraft:bookshelf
setblock 41 113 488 minecraft:bookshelf
setblock 41 113 495 minecraft:bookshelf
setblock 41 113 502 minecraft:bookshelf
setblock 1 114 464 minecraft:bookshelf
setblock 1 114 471 minecraft:bookshelf
setblock 1 114 478 minecraft:bookshelf
setblock 1 114 485 minecraft:bookshelf
setblock 1 114 492 minecraft:bookshelf
setblock 1 114 499 minecraft:bookshelf
setblock 3 114 504 minecraft:bookshelf
setblock 8 114 464 minecraft:bookshelf
setblock 10 114 504 minecraft:bookshelf
setblock 15 114 464 minecraft:bookshelf
setblock 17 114 504 minecraft:bookshelf
fill 18 114 465 22 114 466 minecraft:bookshelf
fill 20 114 464 22 114 464 minecraft:bookshelf
setblock 24 114 504 minecraft:bookshelf
setblock 29 114 464 minecraft:bookshelf
setblock 31 114 504 minecraft:bookshelf
setblock 36 114 464 minecraft:bookshelf
setblock 38 114 504 minecraft:bookshelf
setblock 41 114 466 minecraft:bookshelf
setblock 41 114 473 minecraft:bookshelf
setblock 41 114 480 minecraft:bookshelf
setblock 41 114 487 minecraft:bookshelf
setblock 41 114 494 minecraft:bookshelf
setblock 41 114 501 minecraft:bookshelf
setblock 1 115 465 minecraft:bookshelf
setblock 1 115 472 minecraft:bookshelf
setblock 1 115 479 minecraft:bookshelf
setblock 1 115 486 minecraft:bookshelf
setblock 1 115 493 minecraft:bookshelf
setblock 1 115 500 minecraft:bookshelf
setblock 4 115 504 minecraft:bookshelf
setblock 7 115 464 minecraft:bookshelf
setblock 11 115 504 minecraft:bookshelf
setblock 14 115 464 minecraft:bookshelf
setblock 18 115 504 minecraft:bookshelf
fill 21 115 464 23 115 466 minecraft:bookshelf
fill 24 115 465 25 116 466 minecraft:bookshelf
fill 25 115 464 25 116 464 minecraft:bookshelf
setblock 25 115 504 minecraft:bookshelf
fill 28 115 464 28 117 464 minecraft:bookshelf
setblock 32 115 504 minecraft:bookshelf
setblock 35 115 464 minecraft:bookshelf
fill 38 115 485 40 116 485 minecraft:gold_block
setblock 39 115 504 minecraft:bookshelf
setblock 41 115 465 minecraft:bookshelf
setblock 41 115 472 minecraft:bookshelf
setblock 41 115 479 minecraft:bookshelf
setblock 41 115 486 minecraft:bookshelf
setblock 41 115 493 minecraft:bookshelf
setblock 41 115 500 minecraft:bookshelf
setblock 1 116 466 minecraft:bookshelf
setblock 1 116 473 minecraft:bookshelf
setblock 1 116 480 minecraft:bookshelf
setblock 1 116 487 minecraft:bookshelf
setblock 1 116 494 minecraft:bookshelf
setblock 1 116 501 minecraft:bookshelf
setblock 5 116 504 minecraft:bookshelf
setblock 6 116 464 minecraft:bookshelf
setblock 12 116 504 minecraft:bookshelf
setblock 13 116 464 minecraft:bookshelf
setblock 19 116 504 minecraft:bookshelf
setblock 20 116 464 minecraft:bookshelf
fill 26 116 464 27 116 466 minecraft:bookshelf
setblock 26 116 504 minecraft:bookshelf
fill 28 116 465 28 117 466 minecraft:bookshelf
fill 29 116 464 29 117 464 minecraft:bookshelf
setblock 33 116 504 minecraft:bookshelf
setblock 34 116 464 minecraft:bookshelf
setblock 40 116 504 minecraft:bookshelf
setblock 41 116 464 minecraft:bookshelf
setblock 41 116 471 minecraft:bookshelf
setblock 41 116 478 minecraft:bookshelf
setblock 41 116 485 minecraft:bookshelf
setblock 41 116 492 minecraft:bookshelf
setblock 41 116 499 minecraft:bookshelf
setblock 1 117 467 minecraft:bookshelf
setblock 1 117 474 minecraft:bookshelf
setblock 1 117 481 minecraft:bookshelf
setblock 1 117 488 minecraft:bookshelf
setblock 1 117 495 minecraft:bookshelf
setblock 1 117 502 minecraft:bookshelf
setblock 5 117 464 minecraft:bookshelf
setblock 6 117 504 minecraft:bookshelf
setblock 12 117 464 minecraft:bookshelf
setblock 13 117 504 minecraft:bookshelf
setblock 19 117 464 minecraft:bookshelf
setblock 20 117 504 minecraft:bookshelf
setblock 26 117 464 minecraft:bookshelf
fill 27 117 465 27 117 466 minecraft:bookshelf
setblock 27 117 504 minecraft:bookshelf
fill 29 117 465 32 117 466 minecraft:bookshelf
setblock 30 117 464 minecraft:bookshelf
fill 32 117 464 33 118 464 minecraft:bookshelf
setblock 34 117 504 minecraft:bookshelf
setblock 40 117 464 minecraft:bookshelf
setblock 41 117 470 minecraft:bookshelf
setblock 41 117 477 minecraft:bookshelf
setblock 41 117 484 minecraft:bookshelf
setblock 41 117 491 minecraft:bookshelf
setblock 41 117 498 minecraft:bookshelf
setblock 41 117 504 minecraft:bookshelf
setblock 1 118 468 minecraft:bookshelf
setblock 1 118 475 minecraft:bookshelf
setblock 1 118 482 minecraft:bookshelf
setblock 1 118 489 minecraft:bookshelf
setblock 1 118 496 minecraft:bookshelf
setblock 1 118 503 minecraft:bookshelf
setblock 3 118 466 minecraft:light[level=12]
setblock 3 118 474 minecraft:light[level=12]
setblock 3 118 482 minecraft:light[level=12]
setblock 3 118 490 minecraft:light[level=12]
setblock 3 118 498 minecraft:light[level=12]
setblock 4 118 464 minecraft:bookshelf
setblock 7 118 504 minecraft:bookshelf
setblock 11 118 464 minecraft:bookshelf
setblock 11 118 466 minecraft:light[level=12]
setblock 11 118 474 minecraft:light[level=12]
setblock 11 118 482 minecraft:light[level=12]
setblock 11 118 490 minecraft:light[level=12]
setblock 11 118 498 minecraft:light[level=12]
setblock 14 118 504 minecraft:bookshelf
setblock 18 118 464 minecraft:bookshelf
setblock 19 118 466 minecraft:light[level=12]
setblock 19 118 474 minecraft:light[level=12]
setblock 19 118 482 minecraft:light[level=12]
setblock 19 118 498 minecraft:light[level=12]
setblock 21 118 504 minecraft:bookshelf
setblock 25 118 464 minecraft:bookshelf
setblock 27 118 466 minecraft:light[level=12]
setblock 27 118 474 minecraft:light[level=12]
setblock 27 118 482 minecraft:light[level=12]
setblock 27 118 490 minecraft:light[level=12]
setblock 27 118 498 minecraft:light[level=12]
setblock 28 118 504 minecraft:bookshelf
fill 30 118 466 36 118 466 minecraft:bookshelf
fill 31 118 465 37 118 465 minecraft:bookshelf
fill 34 118 464 37 118 464 minecraft:bookshelf
setblock 35 118 474 minecraft:light[level=12]
setblock 35 118 482 minecraft:light[level=12]
setblock 35 118 490 minecraft:light[level=12]
setblock 35 118 498 minecraft:light[level=12]
setblock 35 118 504 minecraft:bookshelf
fill 39 118 464 39 120 464 minecraft:bookshelf
setblock 41 118 469 minecraft:bookshelf
setblock 41 118 476 minecraft:bookshelf
setblock 41 118 483 minecraft:bookshelf
setblock 41 118 490 minecraft:bookshelf
setblock 41 118 497 minecraft:bookshelf
fill 23 119 493 23 120 494 minecraft:white_wool
fill 34 119 466 41 119 466 minecraft:bookshelf
fill 35 119 465 41 119 465 minecraft:bookshelf
fill 36 119 464 37 120 464 minecraft:bookshelf
fill 39 119 467 39 120 468 minecraft:bookshelf
fill 40 119 464 41 120 464 minecraft:bookshelf
fill 40 119 467 40 120 467 minecraft:bookshelf
fill 1 120 464 1 120 468 minecraft:bookshelf
fill 1 120 470 1 120 475 minecraft:bookshelf
fill 1 120 477 1 120 482 minecraft:bookshelf
fill 1 120 484 1 120 489 minecraft:bookshelf
fill 1 120 491 1 120 496 minecraft:bookshelf
fill 1 120 498 1 120 503 minecraft:bookshelf
setblock 2 120 464 minecraft:bookshelf
fill 2 120 504 7 120 504 minecraft:bookshelf
fill 4 120 464 9 120 464 minecraft:bookshelf
fill 9 120 504 14 120 504 minecraft:bookshelf
fill 11 120 464 16 120 464 minecraft:bookshelf
fill 16 120 504 21 120 504 minecraft:bookshelf
fill 18 120 464 23 120 464 minecraft:bookshelf
fill 23 120 504 28 120 504 minecraft:bookshelf
fill 25 120 464 30 120 464 minecraft:bookshelf
fill 30 120 504 35 120 504 minecraft:bookshelf
fill 32 120 464 35 120 464 minecraft:bookshelf
fill 37 120 504 41 120 504 minecraft:bookshelf
fill 39 120 466 41 120 466 minecraft:bookshelf
fill 39 120 469 41 120 472 minecraft:bookshelf
fill 40 120 465 41 120 465 minecraft:bookshelf
setblock 40 120 468 minecraft:bookshelf
setblock 41 120 467 minecraft:bookshelf
fill 41 120 473 41 121 474 minecraft:bookshelf
fill 41 120 476 41 120 481 minecraft:bookshelf
fill 41 120 483 41 120 488 minecraft:bookshelf
fill 41 120 490 41 120 495 minecraft:bookshelf
fill 41 120 497 41 120 502 minecraft:bookshelf
setblock 1 121 464 minecraft:bookshelf
setblock 1 121 471 minecraft:bookshelf
setblock 1 121 478 minecraft:bookshelf
setblock 1 121 485 minecraft:bookshelf
setblock 1 121 492 minecraft:bookshelf
setblock 1 121 499 minecraft:bookshelf
setblock 3 121 504 minecraft:bookshelf
setblock 8 121 464 minecraft:bookshelf
setblock 10 121 504 minecraft:bookshelf
setblock 15 121 464 minecraft:bookshelf
setblock 17 121 504 minecraft:bookshelf
setblock 22 121 464 minecraft:bookshelf
setblock 24 121 504 minecraft:bookshelf
setblock 29 121 464 minecraft:bookshelf
setblock 31 121 504 minecraft:bookshelf
setblock 36 121 464 minecraft:bookshelf
fill 38 121 474 38 122 474 minecraft:gold_block
setblock 38 121 504 minecraft:bookshelf
fill 39 121 471 40 121 476 minecraft:bookshelf
fill 40 121 470 41 121 470 minecraft:bookshelf
setblock 41 121 466 minecraft:bookshelf
setblock 41 121 469 minecraft:bookshelf
fill 41 121 471 41 121 472 minecraft:bookshelf
setblock 41 121 480 minecraft:bookshelf
setblock 41 121 487 minecraft:bookshelf
setblock 41 121 494 minecraft:bookshelf
setblock 41 121 501 minecraft:bookshelf
setblock 1 122 465 minecraft:bookshelf
setblock 1 122 472 minecraft:bookshelf
setblock 1 122 479 minecraft:bookshelf
setblock 1 122 486 minecraft:bookshelf
setblock 1 122 493 minecraft:bookshelf
setblock 1 122 500 minecraft:bookshelf
setblock 4 122 504 minecraft:bookshelf
setblock 7 122 464 minecraft:bookshelf
setblock 11 122 504 minecraft:bookshelf
setblock 14 122 464 minecraft:bookshelf
setblock 18 122 504 minecraft:bookshelf
setblock 21 122 464 minecraft:bookshelf
setblock 25 122 504 minecraft:bookshelf
setblock 28 122 464 minecraft:bookshelf
setblock 32 122 504 minecraft:bookshelf
setblock 35 122 464 minecraft:bookshelf
setblock 39 122 474 minecraft:gold_block
fill 39 122 475 40 122 479 minecraft:bookshelf
setblock 39 122 504 minecraft:bookshelf
fill 40 122 474 41 122 474 minecraft:bookshelf
setblock 41 122 465 minecraft:bookshelf
setblock 41 122 472 minecraft:bookshelf
fill 41 122 476 41 122 479 minecraft:bookshelf
setblock 41 122 486 minecraft:bookshelf
setblock 41 122 493 minecraft:bookshelf
setblock 41 122 500 minecraft:bookshelf
setblock 1 123 466 minecraft:bookshelf
setblock 1 123 473 minecraft:bookshelf
setblock 1 123 480 minecraft:bookshelf
setblock 1 123 487 minecraft:bookshelf
setblock 1 123 494 minecraft:bookshelf
setblock 1 123 501 minecraft:bookshelf
setblock 5 123 504 minecraft:bookshelf
setblock 6 123 464 minecraft:bookshelf
setblock 12 123 504 minecraft:bookshelf
setblock 13 123 464 minecraft:bookshelf
setblock 19 123 504 minecraft:bookshelf
setblock 20 123 464 minecraft:bookshelf
setblock 26 123 504 minecraft:bookshelf
setblock 27 123 464 minecraft:bookshelf
setblock 33 123 504 minecraft:bookshelf
setblock 34 123 464 minecraft:bookshelf
fill 39 123 478 40 123 482 minecraft:bookshelf
setblock 40 123 504 minecraft:bookshelf
setblock 41 123 464 minecraft:bookshelf
setblock 41 123 471 minecraft:bookshelf
fill 41 123 478 41 123 481 minecraft:bookshelf
fill 41 123 485 41 125 485 minecraft:bookshelf
setblock 41 123 492 minecraft:bookshelf
setblock 41 123 499 minecraft:bookshelf
setblock 1 124 467 minecraft:bookshelf
setblock 1 124 474 minecraft:bookshelf
setblock 1 124 481 minecraft:bookshelf
setblock 1 124 488 minecraft:bookshelf
setblock 1 124 495 minecraft:bookshelf
setblock 1 124 502 minecraft:bookshelf
setblock 5 124 464 minecraft:bookshelf
setblock 6 124 504 minecraft:bookshelf
setblock 12 124 464 minecraft:bookshelf
setblock 13 124 504 minecraft:bookshelf
setblock 19 124 464 minecraft:bookshelf
setblock 20 124 504 minecraft:bookshelf
setblock 26 124 464 minecraft:bookshelf
setblock 27 124 504 minecraft:bookshelf
setblock 33 124 464 minecraft:bookshelf
setblock 34 124 504 minecraft:bookshelf
fill 39 124 481 40 124 485 minecraft:bookshelf
setblock 40 124 464 minecraft:bookshelf
setblock 41 124 470 minecraft:bookshelf
setblock 41 124 477 minecraft:bookshelf
setblock 41 124 481 minecraft:bookshelf
fill 41 124 483 41 125 484 minecraft:bookshelf
setblock 41 124 491 minecraft:bookshelf
setblock 41 124 498 minecraft:bookshelf
setblock 41 124 504 minecraft:bookshelf
setblock 1 125 468 minecraft:bookshelf
setblock 1 125 475 minecraft:bookshelf
setblock 1 125 482 minecraft:bookshelf
setblock 1 125 489 minecraft:bookshelf
setblock 1 125 496 minecraft:bookshelf
setblock 1 125 503 minecraft:bookshelf
setblock 4 125 464 minecraft:bookshelf
setblock 7 125 504 minecraft:bookshelf
setblock 11 125 464 minecraft:bookshelf
setblock 14 125 504 minecraft:bookshelf
setblock 18 125 464 minecraft:bookshelf
setblock 21 125 504 minecraft:bookshelf
setblock 25 125 464 minecraft:bookshelf
setblock 28 125 504 minecraft:bookshelf
setblock 32 125 464 minecraft:bookshelf
setblock 35 125 504 minecraft:bookshelf
setblock 39 125 464 minecraft:bookshelf
fill 39 125 484 40 125 488 minecraft:bookshelf
setblock 41 125 469 minecraft:bookshelf
setblock 41 125 476 minecraft:bookshelf
fill 41 125 486 41 125 488 minecraft:bookshelf
fill 41 125 490 41 126 490 minecraft:bookshelf
setblock 41 125 497 minecraft:bookshelf
setblock 3 126 466 minecraft:light[level=12]
setblock 3 126 474 minecraft:light[level=12]
setblock 3 126 482 minecraft:light[level=12]
setblock 3 126 490 minecraft:light[level=12]
setblock 3 126 498 minecraft:light[level=12]
setblock 11 126 466 minecraft:light[level=12]
setblock 11 126 474 minecraft:light[level=12]
setblock 11 126 482 minecraft:light[level=12]
setblock 11 126 490 minecraft:light[level=12]
setblock 11 126 498 minecraft:light[level=12]
setblock 19 126 466 minecraft:light[level=12]
setblock 19 126 474 minecraft:light[level=12]
setblock 19 126 482 minecraft:light[level=12]
setblock 19 126 498 minecraft:light[level=12]
setblock 27 126 466 minecraft:light[level=12]
setblock 27 126 474 minecraft:light[level=12]
setblock 27 126 482 minecraft:light[level=12]
setblock 27 126 490 minecraft:light[level=12]
setblock 27 126 498 minecraft:light[level=12]
fill 34 126 475 38 127 479 minecraft:dark_oak_planks
setblock 35 126 466 minecraft:light[level=12]
setblock 35 126 474 minecraft:light[level=12]
setblock 35 126 482 minecraft:light[level=12]
setblock 35 126 490 minecraft:light[level=12]
setblock 35 126 498 minecraft:light[level=12]
fill 39 126 477 40 126 477 minecraft:dark_oak_planks
fill 39 126 487 40 126 491 minecraft:bookshelf
fill 41 126 487 41 126 488 minecraft:bookshelf
fill 41 126 491 41 127 492 minecraft:bookshelf
setblock 1 127 470 minecraft:bookshelf
setblock 1 127 477 minecraft:bookshelf
setblock 1 127 484 minecraft:bookshelf
setblock 1 127 491 minecraft:bookshelf
setblock 1 127 498 minecraft:bookshelf
setblock 2 127 464 minecraft:bookshelf
setblock 2 127 504 minecraft:bookshelf
setblock 9 127 464 minecraft:bookshelf
setblock 9 127 504 minecraft:bookshelf
setblock 16 127 464 minecraft:bookshelf
setblock 16 127 504 minecraft:bookshelf
setblock 23 127 464 minecraft:bookshelf
setblock 23 127 504 minecraft:bookshelf
setblock 30 127 464 minecraft:bookshelf
setblock 30 127 504 minecraft:bookshelf
setblock 37 127 464 minecraft:bookshelf
setblock 37 127 504 minecraft:bookshelf
fill 39 127 490 40 127 495 minecraft:bookshelf
setblock 41 127 467 minecraft:bookshelf
setblock 41 127 474 minecraft:bookshelf
setblock 41 127 481 minecraft:bookshelf
setblock 41 127 488 minecraft:bookshelf
fill 41 127 493 41 127 495 minecraft:bookshelf
setblock 41 127 502 minecraft:bookshelf
setblock 1 128 464 minecraft:bookshelf
setblock 1 128 471 minecraft:bookshelf
setblock 1 128 478 minecraft:bookshelf
setblock 1 128 485 minecraft:bookshelf
setblock 1 128 492 minecraft:bookshelf
setblock 1 128 499 minecraft:bookshelf
setblock 3 128 504 minecraft:bookshelf
setblock 8 128 464 minecraft:bookshelf
setblock 10 128 504 minecraft:bookshelf
setblock 15 128 464 minecraft:bookshelf
setblock 17 128 504 minecraft:bookshelf
setblock 22 128 464 minecraft:bookshelf
setblock 24 128 504 minecraft:bookshelf
setblock 29 128 464 minecraft:bookshelf
setblock 31 128 504 minecraft:bookshelf
fill 35 128 477 37 135 477 minecraft:purple_concrete
setblock 36 128 464 minecraft:bookshelf
fill 36 128 476 36 135 476 minecraft:purple_concrete
fill 36 128 478 36 135 478 minecraft:purple_concrete
setblock 38 128 504 minecraft:bookshelf
fill 39 128 493 39 128 499 minecraft:bookshelf
fill 40 128 494 40 128 500 minecraft:bookshelf
setblock 41 128 466 minecraft:bookshelf
setblock 41 128 473 minecraft:bookshelf
setblock 41 128 480 minecraft:bookshelf
setblock 41 128 487 minecraft:bookshelf
fill 41 128 494 41 128 495 minecraft:bookshelf
fill 41 128 497 41 128 501 minecraft:bookshelf
fill 1 129 465 1 130 465 minecraft:bookshelf
fill 1 129 472 1 130 472 minecraft:bookshelf
fill 1 129 479 1 130 479 minecraft:bookshelf
fill 1 129 486 1 130 486 minecraft:bookshelf
fill 1 129 493 1 130 493 minecraft:bookshelf
fill 1 129 500 1 130 500 minecraft:bookshelf
fill 4 129 504 4 130 504 minecraft:bookshelf
fill 7 129 464 7 130 464 minecraft:bookshelf
fill 11 129 504 11 130 504 minecraft:bookshelf
fill 14 129 464 14 130 464 minecraft:bookshelf
fill 18 129 504 18 130 504 minecraft:bookshelf
fill 21 129 464 21 130 464 minecraft:bookshelf
fill 25 129 504 25 130 504 minecraft:bookshelf
fill 28 129 464 28 130 464 minecraft:bookshelf
fill 32 129 504 32 131 504 minecraft:bookshelf
fill 35 129 464 35 130 464 minecraft:bookshelf
fill 37 129 502 41 129 502 minecraft:bookshelf
fill 38 129 503 40 130 503 minecraft:bookshelf
fill 39 129 497 39 129 501 minecraft:bookshelf
fill 39 129 504 41 130 504 minecraft:bookshelf
fill 40 129 498 40 129 501 minecraft:bookshelf
fill 41 129 465 41 130 465 minecraft:bookshelf
fill 41 129 472 41 130 472 minecraft:bookshelf
fill 41 129 479 41 130 479 minecraft:bookshelf
fill 41 129 486 41 130 486 minecraft:bookshelf
fill 41 129 493 41 130 493 minecraft:bookshelf
fill 41 129 499 41 130 501 minecraft:bookshelf
fill 1 130 464 2 130 464 minecraft:bookshelf
fill 1 130 466 1 130 468 minecraft:bookshelf
fill 1 130 470 1 130 471 minecraft:bookshelf
fill 1 130 473 1 130 475 minecraft:bookshelf
fill 1 130 477 1 130 478 minecraft:bookshelf
fill 1 130 480 1 130 482 minecraft:bookshelf
fill 1 130 484 1 130 485 minecraft:bookshelf
fill 1 130 487 1 130 489 minecraft:bookshelf
fill 1 130 491 1 130 492 minecraft:bookshelf
fill 1 130 494 1 130 496 minecraft:bookshelf
fill 1 130 498 1 130 499 minecraft:bookshelf
fill 1 130 501 1 130 503 minecraft:bookshelf
fill 2 130 504 3 130 504 minecraft:bookshelf
fill 4 130 464 6 130 464 minecraft:bookshelf
fill 5 130 504 7 130 504 minecraft:bookshelf
fill 8 130 464 9 130 464 minecraft:bookshelf
fill 9 130 504 10 130 504 minecraft:bookshelf
fill 11 130 464 13 130 464 minecraft:bookshelf
fill 12 130 504 14 130 504 minecraft:bookshelf
fill 15 130 464 16 130 464 minecraft:bookshelf
fill 16 130 504 17 130 504 minecraft:bookshelf
fill 18 130 464 20 130 464 minecraft:bookshelf
fill 19 130 504 21 130 504 minecraft:bookshelf
fill 22 130 464 23 130 464 minecraft:bookshelf
fill 23 130 504 24 130 504 minecraft:bookshelf
fill 25 130 464 27 130 464 minecraft:bookshelf
fill 26 130 504 28 130 504 minecraft:bookshelf
fill 29 130 464 30 130 464 minecraft:bookshelf
fill 30 130 504 31 132 504 minecraft:bookshelf
fill 31 130 484 32 131 485 minecraft:green_wool
fill 32 130 464 34 130 464 minecraft:bookshelf
fill 33 130 502 35 130 504 minecraft:bookshelf
fill 36 130 464 37 130 464 minecraft:bookshelf
fill 36 130 502 37 130 503 minecraft:bookshelf
fill 37 130 504 38 130 504 minecraft:bookshelf
fill 38 130 502 39 130 502 minecraft:bookshelf
fill 39 130 464 41 130 464 minecraft:bookshelf
fill 41 130 466 41 130 467 minecraft:bookshelf
fill 41 130 469 41 130 471 minecraft:bookshelf
fill 41 130 473 41 130 474 minecraft:bookshelf
fill 41 130 476 41 130 478 minecraft:bookshelf
fill 41 130 480 41 130 481 minecraft:bookshelf
fill 41 130 483 41 130 485 minecraft:bookshelf
fill 41 130 487 41 130 488 minecraft:bookshelf
fill 41 130 490 41 130 492 minecraft:bookshelf
fill 41 130 494 41 130 495 minecraft:bookshelf
fill 41 130 497 41 130 498 minecraft:bookshelf
setblock 41 130 502 minecraft:bookshelf
setblock 1 131 467 minecraft:bookshelf
setblock 1 131 474 minecraft:bookshelf
setblock 1 131 481 minecraft:bookshelf
setblock 1 131 488 minecraft:bookshelf
setblock 1 131 495 minecraft:bookshelf
setblock 1 131 502 minecraft:bookshelf
setblock 5 131 464 minecraft:bookshelf
setblock 6 131 504 minecraft:bookshelf
setblock 12 131 464 minecraft:bookshelf
setblock 13 131 504 minecraft:bookshelf
setblock 19 131 464 minecraft:bookshelf
setblock 20 131 504 minecraft:bookshelf
setblock 26 131 464 minecraft:bookshelf
fill 27 131 504 27 133 504 minecraft:bookshelf
fill 29 131 502 34 131 503 minecraft:bookshelf
setblock 33 131 464 minecraft:bookshelf
fill 33 131 504 35 131 504 minecraft:bookshelf
setblock 35 131 503 minecraft:bookshelf
setblock 40 131 464 minecraft:bookshelf
setblock 41 131 470 minecraft:bookshelf
setblock 41 131 477 minecraft:bookshelf
setblock 41 131 484 minecraft:bookshelf
setblock 41 131 491 minecraft:bookshelf
setblock 41 131 498 minecraft:bookshelf
setblock 41 131 504 minecraft:bookshelf
setblock 1 132 468 minecraft:bookshelf
setblock 1 132 475 minecraft:bookshelf
setblock 1 132 482 minecraft:bookshelf
setblock 1 132 489 minecraft:bookshelf
setblock 1 132 496 minecraft:bookshelf
setblock 1 132 503 minecraft:bookshelf
setblock 4 132 464 minecraft:bookshelf
setblock 7 132 504 minecraft:bookshelf
setblock 11 132 464 minecraft:bookshelf
setblock 14 132 504 minecraft:bookshelf
setblock 18 132 464 minecraft:bookshelf
setblock 21 132 504 minecraft:bookshelf
setblock 25 132 464 minecraft:bookshelf
fill 26 132 502 26 133 504 minecraft:bookshelf
fill 27 132 502 30 132 503 minecraft:bookshelf
setblock 28 132 504 minecraft:bookshelf
setblock 31 132 503 minecraft:bookshelf
setblock 32 132 464 minecraft:bookshelf
setblock 35 132 504 minecraft:bookshelf
setblock 39 132 464 minecraft:bookshelf
setblock 41 132 469 minecraft:bookshelf
setblock 41 132 476 minecraft:bookshelf
setblock 41 132 483 minecraft:bookshelf
setblock 41 132 490 minecraft:bookshelf
setblock 41 132 497 minecraft:bookshelf
fill 23 133 502 25 133 504 minecraft:bookshelf
fill 27 133 502 27 133 503 minecraft:bookshelf
setblock 1 134 470 minecraft:bookshelf
setblock 1 134 477 minecraft:bookshelf
setblock 1 134 484 minecraft:bookshelf
setblock 1 134 491 minecraft:bookshelf
setblock 1 134 498 minecraft:bookshelf
setblock 2 134 464 minecraft:bookshelf
setblock 2 134 504 minecraft:bookshelf
setblock 3 134 466 minecraft:light[level=12]
setblock 3 134 474 minecraft:light[level=12]
setblock 3 134 482 minecraft:light[level=12]
setblock 3 134 490 minecraft:light[level=12]
setblock 3 134 498 minecraft:light[level=12]
setblock 9 134 464 minecraft:bookshelf
setblock 9 134 504 minecraft:bookshelf
setblock 11 134 466 minecraft:light[level=12]
setblock 11 134 474 minecraft:light[level=12]
setblock 11 134 482 minecraft:light[level=12]
setblock 11 134 490 minecraft:light[level=12]
setblock 11 134 498 minecraft:light[level=12]
setblock 16 134 464 minecraft:bookshelf
setblock 16 134 504 minecraft:bookshelf
setblock 19 134 466 minecraft:light[level=12]
setblock 19 134 474 minecraft:light[level=12]
setblock 19 134 482 minecraft:light[level=12]
setblock 19 134 498 minecraft:light[level=12]
fill 20 134 502 21 135 504 minecraft:bookshelf
fill 22 134 502 24 134 503 minecraft:bookshelf
setblock 23 134 464 minecraft:bookshelf
fill 23 134 504 24 134 504 minecraft:bookshelf
setblock 27 134 466 minecraft:light[level=12]
setblock 27 134 474 minecraft:light[level=12]
setblock 27 134 482 minecraft:light[level=12]
setblock 27 134 490 minecraft:light[level=12]
setblock 27 134 498 minecraft:light[level=12]
fill 29 134 484 29 135 484 minecraft:red_wool
setblock 30 134 464 minecraft:bookshelf
setblock 30 134 504 minecraft:bookshelf
setblock 35 134 466 minecraft:light[level=12]
setblock 35 134 474 minecraft:light[level=12]
setblock 35 134 482 minecraft:light[level=12]
setblock 35 134 490 minecraft:light[level=12]
setblock 35 134 498 minecraft:light[level=12]
setblock 37 134 464 minecraft:bookshelf
setblock 37 134 504 minecraft:bookshelf
setblock 41 134 467 minecraft:bookshelf
setblock 41 134 474 minecraft:bookshelf
setblock 41 134 481 minecraft:bookshelf
setblock 41 134 488 minecraft:bookshelf
setblock 41 134 495 minecraft:bookshelf
setblock 41 134 502 minecraft:bookshelf
setblock 1 135 464 minecraft:bookshelf
setblock 1 135 471 minecraft:bookshelf
setblock 1 135 478 minecraft:bookshelf
setblock 1 135 485 minecraft:bookshelf
setblock 1 135 492 minecraft:bookshelf
setblock 1 135 499 minecraft:bookshelf
setblock 3 135 504 minecraft:bookshelf
setblock 8 135 464 minecraft:bookshelf
setblock 10 135 504 minecraft:bookshelf
setblock 15 135 464 minecraft:bookshelf
fill 17 135 502 19 135 504 minecraft:bookshelf
setblock 22 135 464 minecraft:bookshelf
setblock 24 135 504 minecraft:bookshelf
setblock 29 135 464 minecraft:bookshelf
setblock 31 135 504 minecraft:bookshelf
setblock 36 135 464 minecraft:bookshelf
setblock 38 135 504 minecraft:bookshelf
setblock 41 135 466 minecraft:bookshelf
setblock 41 135 473 minecraft:bookshelf
setblock 41 135 480 minecraft:bookshelf
setblock 41 135 487 minecraft:bookshelf
setblock 41 135 494 minecraft:bookshelf
setblock 41 135 501 minecraft:bookshelf
setblock 1 136 465 minecraft:bookshelf
setblock 1 136 472 minecraft:bookshelf
setblock 1 136 479 minecraft:bookshelf
setblock 1 136 486 minecraft:bookshelf
setblock 1 136 493 minecraft:bookshelf
setblock 1 136 500 minecraft:bookshelf
setblock 4 136 504 minecraft:bookshelf
setblock 7 136 464 minecraft:bookshelf
fill 11 136 504 11 138 504 minecraft:bookshelf
fill 13 136 504 14 137 504 minecraft:bookshelf
setblock 14 136 464 minecraft:bookshelf
fill 14 136 502 18 136 503 minecraft:bookshelf
fill 16 136 504 18 136 504 minecraft:bookshelf
setblock 21 136 464 minecraft:bookshelf
setblock 25 136 504 minecraft:bookshelf
setblock 28 136 464 minecraft:bookshelf
setblock 32 136 504 minecraft:bookshelf
setblock 35 136 464 minecraft:bookshelf
setblock 39 136 504 minecraft:bookshelf
setblock 41 136 465 minecraft:bookshelf
setblock 41 136 472 minecraft:bookshelf
setblock 41 136 479 minecraft:bookshelf
setblock 41 136 486 minecraft:bookshelf
setblock 41 136 493 minecraft:bookshelf
setblock 41 136 500 minecraft:bookshelf
setblock 1 137 466 minecraft:bookshelf
setblock 1 137 473 minecraft:bookshelf
setblock 1 137 480 minecraft:bookshelf
setblock 1 137 487 minecraft:bookshelf
setblock 1 137 494 minecraft:bookshelf
setblock 1 137 501 minecraft:bookshelf
fill 5 137 504 5 140 504 minecraft:bookshelf
setblock 6 137 464 minecraft:bookshelf
fill 9 137 504 10 138 504 minecraft:bookshelf
fill 10 137 502 15 137 503 minecraft:bookshelf
setblock 12 137 504 minecraft:bookshelf
setblock 13 137 464 minecraft:bookshelf
setblock 19 137 504 minecraft:bookshelf
setblock 20 137 464 minecraft:bookshelf
setblock 26 137 504 minecraft:bookshelf
setblock 27 137 464 minecraft:bookshelf
setblock 33 137 504 minecraft:bookshelf
setblock 34 137 464 minecraft:bookshelf
setblock 40 137 504 minecraft:bookshelf
setblock 41 137 464 minecraft:bookshelf
setblock 41 137 471 minecraft:bookshelf
setblock 41 137 478 minecraft:bookshelf
setblock 41 137 485 minecraft:bookshelf
setblock 41 137 492 minecraft:bookshelf
setblock 41 137 499 minecraft:bookshelf
setblock 1 138 467 minecraft:bookshelf
setblock 1 138 474 minecraft:bookshelf
setblock 1 138 481 minecraft:bookshelf
setblock 1 138 488 minecraft:bookshelf
setblock 1 138 495 minecraft:bookshelf
fill 1 138 502 1 140 502 minecraft:bookshelf
fill 4 138 504 4 140 504 minecraft:bookshelf
setblock 5 138 464 minecraft:bookshelf
fill 5 138 503 11 138 503 minecraft:bookshelf
fill 6 138 502 12 138 502 minecraft:bookshelf
fill 6 138 504 7 140 504 minecraft:bookshelf
setblock 12 138 464 minecraft:bookshelf
setblock 13 138 504 minecraft:bookshelf
setblock 19 138 464 minecraft:bookshelf
setblock 20 138 504 minecraft:bookshelf
setblock 26 138 464 minecraft:bookshelf
setblock 27 138 504 minecraft:bookshelf
setblock 33 138 464 minecraft:bookshelf
setblock 34 138 504 minecraft:bookshelf
fill 35 138 484 35 139 484 minecraft:white_wool
setblock 36 138 477 minecraft:ochre_froglight
setblock 40 138 464 minecraft:bookshelf
setblock 41 138 470 minecraft:bookshelf
setblock 41 138 477 minecraft:bookshelf
setblock 41 138 484 minecraft:bookshelf
setblock 41 138 491 minecraft:bookshelf
setblock 41 138 498 minecraft:bookshelf
setblock 41 138 504 minecraft:bookshelf
fill 1 139 468 1 140 468 minecraft:bookshelf
fill 1 139 475 1 140 475 minecraft:bookshelf
fill 1 139 482 1 140 482 minecraft:bookshelf
fill 1 139 489 1 140 489 minecraft:bookshelf
fill 1 139 496 1 141 496 minecraft:bookshelf
fill 1 139 503 7 139 503 minecraft:bookshelf
fill 2 139 501 3 140 502 minecraft:bookshelf
fill 2 139 504 3 140 504 minecraft:bookshelf
fill 3 139 500 3 140 500 minecraft:bookshelf
fill 4 139 464 4 140 464 minecraft:bookshelf
fill 4 139 502 8 139 502 minecraft:bookshelf
fill 11 139 464 11 140 464 minecraft:bookshelf
fill 14 139 504 14 140 504 minecraft:bookshelf
fill 18 139 464 18 140 464 minecraft:bookshelf
fill 21 139 504 21 140 504 minecraft:bookshelf
fill 25 139 464 25 140 464 minecraft:bookshelf
fill 28 139 504 28 140 504 minecraft:bookshelf
fill 32 139 464 32 140 464 minecraft:bookshelf
fill 35 139 504 35 140 504 minecraft:bookshelf
fill 39 139 464 39 140 464 minecraft:bookshelf
fill 41 139 469 41 140 469 minecraft:bookshelf
fill 41 139 476 41 140 476 minecraft:bookshelf
fill 41 139 483 41 140 483 minecraft:bookshelf
fill 41 139 490 41 140 490 minecraft:bookshelf
fill 41 139 497 41 140 497 minecraft:bookshelf
fill 1 140 464 1 140 467 minecraft:bookshelf
fill 1 140 470 1 140 474 minecraft:bookshelf
fill 1 140 477 1 140 481 minecraft:bookshelf
fill 1 140 484 1 140 488 minecraft:bookshelf
fill 1 140 491 1 140 495 minecraft:bookshelf
fill 1 140 498 1 140 501 minecraft:bookshelf
fill 1 140 503 2 140 503 minecraft:bookshelf
fill 2 140 464 2 141 464 minecraft:bookshelf
fill 2 140 496 2 140 500 minecraft:bookshelf
fill 3 140 496 3 140 499 minecraft:bookshelf
fill 5 140 464 9 140 464 minecraft:bookshelf
fill 9 140 504 13 140 504 minecraft:bookshelf
fill 12 140 464 16 140 464 minecraft:bookshelf
fill 16 140 504 20 140 504 minecraft:bookshelf
fill 19 140 464 23 140 464 minecraft:bookshelf
fill 23 140 465 23 141 466 minecraft:gold_block
fill 23 140 504 27 140 504 minecraft:bookshelf
fill 26 140 464 30 140 464 minecraft:bookshelf
fill 30 140 504 34 140 504 minecraft:bookshelf
fill 33 140 464 37 140 464 minecraft:bookshelf
fill 37 140 504 41 140 504 minecraft:bookshelf
fill 40 140 464 41 140 464 minecraft:bookshelf
fill 41 140 465 41 140 467 minecraft:bookshelf
fill 41 140 470 41 140 474 minecraft:bookshelf
fill 41 140 477 41 140 481 minecraft:bookshelf
fill 41 140 484 41 140 488 minecraft:bookshelf
fill 41 140 491 41 140 495 minecraft:bookshelf
fill 41 140 498 41 140 502 minecraft:bookshelf
setblock 1 141 470 minecraft:bookshelf
setblock 1 141 477 minecraft:bookshelf
setblock 1 141 484 minecraft:bookshelf
fill 1 141 491 1 142 491 minecraft:bookshelf
fill 1 141 493 3 141 495 minecraft:bookshelf
fill 1 141 498 1 141 499 minecraft:bookshelf
fill 2 141 492 3 142 492 minecraft:bookshelf
fill 2 141 496 2 141 498 minecraft:bookshelf
setblock 2 141 504 minecraft:bookshelf
fill 3 141 496 3 141 497 minecraft:bookshelf
setblock 9 141 464 minecraft:bookshelf
setblock 9 141 504 minecraft:bookshelf
setblock 16 141 464 minecraft:bookshelf
setblock 16 141 504 minecraft:bookshelf
setblock 23 141 464 minecraft:bookshelf
setblock 23 141 504 minecraft:bookshelf
setblock 30 141 464 minecraft:bookshelf
setblock 30 141 504 minecraft:bookshelf
setblock 37 141 464 minecraft:bookshelf
setblock 37 141 504 minecraft:bookshelf
setblock 41 141 467 minecraft:bookshelf
setblock 41 141 474 minecraft:bookshelf
setblock 41 141 481 minecraft:bookshelf
setblock 41 141 488 minecraft:bookshelf
setblock 41 141 495 minecraft:bookshelf
setblock 41 141 502 minecraft:bookshelf
setblock 1 142 464 minecraft:bookshelf
setblock 1 142 471 minecraft:bookshelf
setblock 1 142 478 minecraft:bookshelf
setblock 1 142 485 minecraft:bookshelf
fill 1 142 489 3 143 489 minecraft:bookshelf
fill 1 142 492 1 142 494 minecraft:bookshelf
setblock 1 142 499 minecraft:bookshelf
fill 2 142 490 3 142 491 minecraft:bookshelf
fill 2 142 493 2 142 494 minecraft:bookshelf
setblock 3 142 466 minecraft:light[level=12]
setblock 3 142 474 minecraft:light[level=12]
setblock 3 142 482 minecraft:light[level=12]
setblock 3 142 493 minecraft:bookshelf
setblock 3 142 498 minecraft:light[level=12]
setblock 3 142 504 minecraft:bookshelf
setblock 8 142 464 minecraft:bookshelf
setblock 10 142 504 minecraft:bookshelf
setblock 11 142 466 minecraft:light[level=12]
setblock 11 142 474 minecraft:light[level=12]
setblock 11 142 482 minecraft:light[level=12]
setblock 11 142 490 minecraft:light[level=12]
setblock 11 142 498 minecraft:light[level=12]
setblock 15 142 464 minecraft:bookshelf
setblock 17 142 504 minecraft:bookshelf
setblock 19 142 466 minecraft:light[level=12]
setblock 19 142 474 minecraft:light[level=12]
setblock 19 142 482 minecraft:light[level=12]
setblock 19 142 490 minecraft:light[level=12]
setblock 19 142 498 minecraft:light[level=12]
setblock 22 142 464 minecraft:bookshelf
setblock 24 142 504 minecraft:bookshelf
setblock 27 142 466 minecraft:light[level=12]
setblock 27 142 474 minecraft:light[level=12]
setblock 27 142 482 minecraft:light[level=12]
setblock 27 142 490 minecraft:light[level=12]
setblock 27 142 498 minecraft:light[level=12]
setblock 29 142 464 minecraft:bookshelf
setblock 31 142 504 minecraft:bookshelf
setblock 35 142 466 minecraft:light[level=12]
setblock 35 142 474 minecraft:light[level=12]
setblock 35 142 482 minecraft:light[level=12]
setblock 35 142 490 minecraft:light[level=12]
setblock 35 142 498 minecraft:light[level=12]
setblock 36 142 464 minecraft:bookshelf
setblock 38 142 504 minecraft:bookshelf
setblock 41 142 466 minecraft:bookshelf
setblock 41 142 473 minecraft:bookshelf
setblock 41 142 480 minecraft:bookshelf
setblock 41 142 487 minecraft:bookshelf
setblock 41 142 494 minecraft:bookshelf
setblock 41 142 501 minecraft:bookshelf
setblock 1 143 465 minecraft:bookshelf
setblock 1 143 472 minecraft:bookshelf
setblock 1 143 479 minecraft:bookshelf
fill 1 143 486 3 143 488 minecraft:bookshelf
setblock 1 143 493 minecraft:bookshelf
setblock 1 143 500 minecraft:bookshelf
fill 2 143 490 3 143 490 minecraft:bookshelf
setblock 4 143 504 minecraft:bookshelf
setblock 7 143 464 minecraft:bookshelf
setblock 11 143 504 minecraft:bookshelf
setblock 14 143 464 minecraft:bookshelf
setblock 18 143 504 minecraft:bookshelf
setblock 21 143 464 minecraft:bookshelf
setblock 25 143 504 minecraft:bookshelf
setblock 28 143 464 minecraft:bookshelf
setblock 32 143 504 minecraft:bookshelf
setblock 35 143 464 minecraft:bookshelf
setblock 39 143 504 minecraft:bookshelf
setblock 41 143 465 minecraft:bookshelf
setblock 41 143 472 minecraft:bookshelf
setblock 41 143 479 minecraft:bookshelf
setblock 41 143 486 minecraft:bookshelf
setblock 41 143 493 minecraft:bookshelf
setblock 41 143 500 minecraft:bookshelf
setblock 1 144 466 minecraft:bookshelf
setblock 1 144 473 minecraft:bookshelf
fill 1 144 480 1 146 480 minecraft:bookshelf
fill 1 144 484 3 144 487 minecraft:bookshelf
setblock 1 144 494 minecraft:bookshelf
setblock 1 144 501 minecraft:bookshelf
fill 2 144 483 3 145 483 minecraft:bookshelf
setblock 5 144 504 minecraft:bookshelf
setblock 6 144 464 minecraft:bookshelf
setblock 12 144 504 minecraft:bookshelf
setblock 13 144 464 minecraft:bookshelf
setblock 19 144 504 minecraft:bookshelf
setblock 20 144 464 minecraft:bookshelf
setblock 26 144 504 minecraft:bookshelf
setblock 27 144 464 minecraft:bookshelf
setblock 33 144 504 minecraft:bookshelf
setblock 34 144 464 minecraft:bookshelf
setblock 40 144 504 minecraft:bookshelf
setblock 41 144 464 minecraft:bookshelf
setblock 41 144 471 minecraft:bookshelf
setblock 41 144 478 minecraft:bookshelf
setblock 41 144 485 minecraft:bookshelf
setblock 41 144 492 minecraft:bookshelf
setblock 41 144 499 minecraft:bookshelf
setblock 1 145 467 minecraft:bookshelf
setblock 1 145 474 minecraft:bookshelf
fill 1 145 481 3 145 482 minecraft:bookshelf
fill 1 145 484 3 145 484 minecraft:bookshelf
setblock 1 145 488 minecraft:bookshelf
setblock 1 145 495 minecraft:bookshelf
setblock 1 145 502 minecraft:bookshelf
fill 2 145 480 3 146 480 minecraft:bookshelf
setblock 5 145 464 minecraft:bookshelf
setblock 6 145 504 minecraft:bookshelf
setblock 12 145 464 minecraft:bookshelf
setblock 13 145 504 minecraft:bookshelf
setblock 19 145 464 minecraft:bookshelf
setblock 20 145 504 minecraft:bookshelf
setblock 26 145 464 minecraft:bookshelf
setblock 27 145 504 minecraft:bookshelf
setblock 33 145 464 minecraft:bookshelf
setblock 34 145 504 minecraft:bookshelf
setblock 40 145 464 minecraft:bookshelf
setblock 41 145 470 minecraft:bookshelf
setblock 41 145 477 minecraft:bookshelf
setblock 41 145 484 minecraft:bookshelf
setblock 41 145 491 minecraft:bookshelf
setblock 41 145 498 minecraft:bookshelf
setblock 41 145 504 minecraft:bookshelf
setblock 1 146 468 minecraft:bookshelf
fill 1 146 475 1 147 475 minecraft:bookshelf
fill 1 146 477 3 146 479 minecraft:bookshelf
fill 1 146 481 1 146 482 minecraft:bookshelf
setblock 1 146 489 minecraft:bookshelf
setblock 1 146 496 minecraft:bookshelf
setblock 1 146 503 minecraft:bookshelf
fill 2 146 481 3 146 481 minecraft:bookshelf
setblock 4 146 464 minecraft:bookshelf
setblock 7 146 504 minecraft:bookshelf
setblock 11 146 464 minecraft:bookshelf
setblock 14 146 504 minecraft:bookshelf
setblock 18 146 464 minecraft:bookshelf
setblock 21 146 504 minecraft:bookshelf
setblock 25 146 464 minecraft:bookshelf
setblock 28 146 504 minecraft:bookshelf
setblock 32 146 464 minecraft:bookshelf
setblock 35 146 504 minecraft:bookshelf
setblock 39 146 464 minecraft:bookshelf
setblock 41 146 469 minecraft:bookshelf
setblock 41 146 476 minecraft:bookshelf
setblock 41 146 483 minecraft:bookshelf
setblock 41 146 490 minecraft:bookshelf
setblock 41 146 497 minecraft:bookshelf
fill 1 147 472 1 148 474 minecraft:bookshelf
fill 1 147 477 3 147 477 minecraft:bookshelf
fill 2 147 473 3 147 476 minecraft:bookshelf
fill 2 147 478 3 147 478 minecraft:bookshelf
fill 1 148 467 1 150 468 minecraft:bookshelf
fill 1 148 470 3 148 471 minecraft:bookshelf
setblock 1 148 477 minecraft:bookshelf
setblock 1 148 484 minecraft:bookshelf
setblock 1 148 491 minecraft:bookshelf
setblock 1 148 498 minecraft:bookshelf
fill 2 148 464 2 150 464 minecraft:bookshelf
fill 2 148 468 2 149 469 minecraft:bookshelf
fill 2 148 472 3 148 474 minecraft:bookshelf
setblock 2 148 504 minecraft:bookshelf
fill 3 148 469 3 149 469 minecraft:bookshelf
setblock 3 148 475 minecraft:bookshelf
setblock 9 148 464 minecraft:bookshelf
setblock 9 148 504 minecraft:bookshelf
setblock 16 148 464 minecraft:bookshelf
setblock 16 148 504 minecraft:bookshelf
setblock 23 148 464 minecraft:bookshelf
setblock 23 148 504 minecraft:bookshelf
setblock 30 148 464 minecraft:bookshelf
setblock 30 148 504 minecraft:bookshelf
setblock 37 148 464 minecraft:bookshelf
setblock 37 148 504 minecraft:bookshelf
setblock 41 148 467 minecraft:bookshelf
setblock 41 148 474 minecraft:bookshelf
setblock 41 148 481 minecraft:bookshelf
setblock 41 148 488 minecraft:bookshelf
setblock 41 148 495 minecraft:bookshelf
setblock 41 148 502 minecraft:bookshelf
fill 1 149 464 1 150 466 minecraft:bookshelf
fill 1 149 471 1 150 471 minecraft:bookshelf
fill 1 149 478 1 150 478 minecraft:bookshelf
fill 1 149 485 1 150 485 minecraft:bookshelf
fill 1 149 492 1 150 492 minecraft:bookshelf
fill 1 149 499 1 150 499 minecraft:bookshelf
fill 2 149 465 3 149 467 minecraft:bookshelf
fill 2 149 470 3 149 470 minecraft:bookshelf
setblock 3 149 468 minecraft:bookshelf
setblock 3 149 471 minecraft:bookshelf
fill 3 149 504 3 150 504 minecraft:bookshelf
fill 4 149 465 4 150 466 minecraft:bookshelf
fill 5 149 466 5 150 466 minecraft:bookshelf
fill 8 149 464 8 151 464 minecraft:bookshelf
fill 10 149 504 10 150 504 minecraft:bookshelf
fill 15 149 464 15 150 464 minecraft:bookshelf
fill 17 149 504 17 150 504 minecraft:bookshelf
fill 22 149 464 22 150 464 minecraft:bookshelf
fill 24 149 504 24 150 504 minecraft:bookshelf
fill 29 149 464 29 150 464 minecraft:bookshelf
fill 31 149 504 31 150 504 minecraft:bookshelf
fill 36 149 464 36 150 464 minecraft:bookshelf
fill 38 149 467 40 150 467 minecraft:gold_block
fill 38 149 504 38 150 504 minecraft:bookshelf
fill 41 149 466 41 150 466 minecraft:bookshelf
fill 41 149 473 41 150 473 minecraft:bookshelf
fill 41 149 480 41 150 480 minecraft:bookshelf
fill 41 149 487 41 150 487 minecraft:bookshelf
fill 41 149 494 41 150 494 minecraft:bookshelf
fill 41 149 501 41 150 501 minecraft:bookshelf
setblock 1 150 470 minecraft:bookshelf
fill 1 150 472 1 150 475 minecraft:bookshelf
setblock 1 150 477 minecraft:bookshelf
fill 1 150 479 1 150 482 minecraft:bookshelf
setblock 1 150 484 minecraft:bookshelf
fill 1 150 486 1 150 489 minecraft:bookshelf
setblock 1 150 491 minecraft:bookshelf
fill 1 150 493 1 150 496 minecraft:bookshelf
setblock 1 150 498 minecraft:bookshelf
fill 1 150 500 1 150 503 minecraft:bookshelf
fill 2 150 465 3 150 465 minecraft:bookshelf
setblock 2 150 504 minecraft:bookshelf
setblock 3 150 466 minecraft:bookshelf
setblock 3 150 474 minecraft:light[level=12]
setblock 3 150 482 minecraft:light[level=12]
setblock 3 150 490 minecraft:light[level=12]
setblock 3 150 498 minecraft:light[level=12]
fill 4 150 464 7 150 464 minecraft:bookshelf
fill 4 150 504 7 150 504 minecraft:bookshelf
fill 5 150 465 9 150 465 minecraft:bookshelf
fill 6 150 466 9 150 466 minecraft:bookshelf
fill 9 150 464 9 151 464 minecraft:bookshelf
setblock 9 150 504 minecraft:bookshelf
fill 11 150 464 14 150 464 minecraft:bookshelf
setblock 11 150 466 minecraft:light[level=12]
setblock 11 150 474 minecraft:light[level=12]
setblock 11 150 482 minecraft:light[level=12]
setblock 11 150 490 minecraft:light[level=12]
setblock 11 150 498 minecraft:light[level=12]
fill 11 150 504 14 150 504 minecraft:bookshelf
setblock 16 150 464 minecraft:bookshelf
setblock 16 150 504 minecraft:bookshelf
fill 18 150 464 21 150 464 minecraft:bookshelf
fill 18 150 504 21 150 504 minecraft:bookshelf
setblock 19 150 466 minecraft:light[level=12]
setblock 19 150 474 minecraft:light[level=12]
setblock 19 150 482 minecraft:light[level=12]
setblock 19 150 490 minecraft:light[level=12]
setblock 19 150 498 minecraft:light[level=12]
setblock 23 150 464 minecraft:bookshelf
setblock 23 150 504 minecraft:bookshelf
fill 25 150 464 28 150 464 minecraft:bookshelf
fill 25 150 504 28 150 504 minecraft:bookshelf
setblock 27 150 466 minecraft:light[level=12]
setblock 27 150 474 minecraft:light[level=12]
setblock 27 150 482 minecraft:light[level=12]
setblock 27 150 490 minecraft:light[level=12]
setblock 27 150 498 minecraft:light[level=12]
setblock 30 150 464 minecraft:bookshelf
setblock 30 150 504 minecraft:bookshelf
fill 32 150 464 35 150 464 minecraft:bookshelf
fill 32 150 504 35 150 504 minecraft:bookshelf
setblock 35 150 466 minecraft:light[level=12]
setblock 35 150 474 minecraft:light[level=12]
setblock 35 150 482 minecraft:light[level=12]
setblock 35 150 490 minecraft:light[level=12]
setblock 35 150 498 minecraft:light[level=12]
setblock 37 150 464 minecraft:bookshelf
setblock 37 150 504 minecraft:bookshelf
fill 39 150 464 41 150 464 minecraft:bookshelf
fill 39 150 504 41 150 504 minecraft:bookshelf
setblock 41 150 465 minecraft:bookshelf
setblock 41 150 467 minecraft:bookshelf
fill 41 150 469 41 150 472 minecraft:bookshelf
setblock 41 150 474 minecraft:bookshelf
fill 41 150 476 41 150 479 minecraft:bookshelf
setblock 41 150 481 minecraft:bookshelf
fill 41 150 483 41 150 486 minecraft:bookshelf
setblock 41 150 488 minecraft:bookshelf
fill 41 150 490 41 150 493 minecraft:bookshelf
setblock 41 150 495 minecraft:bookshelf
fill 41 150 497 41 150 500 minecraft:bookshelf
setblock 41 150 502 minecraft:bookshelf
setblock 1 151 466 minecraft:bookshelf
setblock 1 151 473 minecraft:bookshelf
setblock 1 151 480 minecraft:bookshelf
setblock 1 151 487 minecraft:bookshelf
setblock 1 151 494 minecraft:bookshelf
setblock 1 151 501 minecraft:bookshelf
setblock 5 151 504 minecraft:bookshelf
fill 6 151 464 7 151 464 minecraft:bookshelf
fill 7 151 465 13 151 465 minecraft:bookshelf
fill 8 151 466 13 151 466 minecraft:bookshelf
fill 11 151 464 13 152 464 minecraft:bookshelf
setblock 12 151 504 minecraft:bookshelf
setblock 19 151 504 minecraft:bookshelf
setblock 20 151 464 minecraft:bookshelf
setblock 26 151 504 minecraft:bookshelf
setblock 27 151 464 minecraft:bookshelf
setblock 33 151 504 minecraft:bookshelf
setblock 34 151 464 minecraft:bookshelf
setblock 40 151 504 minecraft:bookshelf
setblock 41 151 464 minecraft:bookshelf
setblock 41 151 471 minecraft:bookshelf
setblock 41 151 478 minecraft:bookshelf
setblock 41 151 485 minecraft:bookshelf
setblock 41 151 492 minecraft:bookshelf
setblock 41 151 499 minecraft:bookshelf
setblock 1 152 467 minecraft:bookshelf
setblock 1 152 474 minecraft:bookshelf
setblock 1 152 481 minecraft:bookshelf
setblock 1 152 488 minecraft:bookshelf
setblock 1 152 495 minecraft:bookshelf
setblock 1 152 502 minecraft:bookshelf
setblock 5 152 464 minecraft:bookshelf
setblock 6 152 504 minecraft:bookshelf
fill 11 152 465 16 152 465 minecraft:bookshelf
fill 12 152 466 16 152 466 minecraft:bookshelf
setblock 13 152 504 minecraft:bookshelf
fill 14 152 464 16 152 464 minecraft:bookshelf
setblock 19 152 464 minecraft:bookshelf
setblock 20 152 504 minecraft:bookshelf
setblock 26 152 464 minecraft:bookshelf
setblock 27 152 504 minecraft:bookshelf
setblock 33 152 464 minecraft:bookshelf
setblock 34 152 504 minecraft:bookshelf
setblock 40 152 464 minecraft:bookshelf
setblock 41 152 470 minecraft:bookshelf
setblock 41 152 477 minecraft:bookshelf
setblock 41 152 484 minecraft:bookshelf
setblock 41 152 491 minecraft:bookshelf
setblock 41 152 498 minecraft:bookshelf
setblock 41 152 504 minecraft:bookshelf
setblock 3 158 466 minecraft:light[level=12]
setblock 3 158 474 minecraft:light[level=12]
setblock 3 158 482 minecraft:light[level=12]
setblock 3 158 490 minecraft:light[level=12]
setblock 3 158 498 minecraft:light[level=12]
fill 7 158 488 15 158 488 minecraft:white_wool
fill 8 158 484 16 158 487 minecraft:white_wool
fill 8 158 489 16 158 492 minecraft:white_wool
fill 9 158 482 27 158 483 minecraft:white_wool
fill 9 158 493 27 158 494 minecraft:white_wool
fill 10 158 481 26 158 481 minecraft:white_wool
fill 10 158 495 26 158 495 minecraft:white_wool
setblock 11 158 466 minecraft:light[level=12]
setblock 11 158 474 minecraft:light[level=12]
fill 11 158 480 25 158 480 minecraft:white_wool
fill 11 158 496 25 158 496 minecraft:white_wool
setblock 11 158 498 minecraft:light[level=12]
fill 12 158 479 24 158 479 minecraft:white_wool
fill 12 158 497 24 158 497 minecraft:white_wool
fill 14 158 478 22 158 478 minecraft:white_wool
fill 14 158 498 22 158 498 minecraft:white_wool
fill 17 158 484 17 158 486 minecraft:white_wool
fill 17 158 490 17 158 492 minecraft:white_wool
setblock 18 158 477 minecraft:white_wool
fill 18 158 484 28 158 485 minecraft:white_wool
fill 18 158 491 28 158 492 minecraft:white_wool
setblock 18 158 499 minecraft:white_wool
setblock 19 158 466 minecraft:light[level=12]
setblock 19 158 474 minecraft:light[level=12]
fill 19 158 486 28 158 486 minecraft:white_wool
fill 19 158 490 28 158 490 minecraft:white_wool
fill 20 158 487 28 158 487 minecraft:white_wool
fill 20 158 489 28 158 489 minecraft:white_wool
fill 21 158 488 29 158 488 minecraft:white_wool
setblock 27 158 466 minecraft:light[level=12]
setblock 27 158 474 minecraft:light[level=12]
setblock 27 158 498 minecraft:light[level=12]
setblock 35 158 466 minecraft:light[level=12]
setblock 35 158 474 minecraft:light[level=12]
setblock 35 158 482 minecraft:light[level=12]
setblock 35 158 490 minecraft:light[level=12]
setblock 35 158 498 minecraft:light[level=12]
fill 1 159 464 6 159 504 minecraft:dark_oak_planks
fill 7 159 464 7 159 487 minecraft:dark_oak_planks
fill 7 159 488 8 159 488 minecraft:brown_wool
fill 7 159 489 7 159 504 minecraft:dark_oak_planks
fill 8 159 464 8 159 483 minecraft:dark_oak_planks
fill 8 159 484 8 159 487 minecraft:brown_wool
fill 8 159 489 8 159 492 minecraft:brown_wool
fill 8 159 493 8 159 504 minecraft:dark_oak_planks
fill 9 159 464 9 159 481 minecraft:dark_oak_planks
fill 9 159 482 9 159 484 minecraft:brown_wool
fill 9 159 485 11 159 491 minecraft:white_wool
fill 9 159 492 9 159 494 minecraft:brown_wool
fill 9 159 495 9 159 504 minecraft:dark_oak_planks
fill 10 159 464 10 159 480 minecraft:dark_oak_planks
fill 10 159 481 10 159 482 minecraft:brown_wool
fill 10 159 483 12 159 484 minecraft:white_wool
fill 10 159 492 12 159 493 minecraft:white_wool
fill 10 159 494 10 159 495 minecraft:brown_wool
fill 10 159 496 10 159 504 minecraft:dark_oak_planks
fill 11 159 464 11 159 479 minecraft:dark_oak_planks
fill 11 159 480 11 159 481 minecraft:brown_wool
fill 11 159 482 15 159 482 minecraft:white_wool
fill 11 159 494 15 159 494 minecraft:white_wool
fill 11 159 495 11 159 496 minecraft:brown_wool
fill 11 159 497 11 159 504 minecraft:dark_oak_planks
fill 12 159 464 13 159 478 minecraft:dark_oak_planks
fill 12 159 479 12 159 480 minecraft:brown_wool
fill 12 159 481 24 159 481 minecraft:white_wool
setblock 12 159 485 minecraft:white_wool
fill 12 159 486 15 159 490 minecraft:mossy_stone_bricks
setblock 12 159 491 minecraft:white_wool
fill 12 159 495 24 159 495 minecraft:white_wool
fill 12 159 496 12 159 497 minecraft:brown_wool
fill 12 159 498 13 159 504 minecraft:dark_oak_planks
fill 13 159 479 14 159 479 minecraft:brown_wool
fill 13 159 480 23 159 480 minecraft:white_wool
setblock 13 159 483 minecraft:white_wool
fill 13 159 484 23 159 485 minecraft:mossy_stone_bricks
fill 13 159 491 23 159 492 minecraft:mossy_stone_bricks
setblock 13 159 493 minecraft:white_wool
fill 13 159 496 23 159 496 minecraft:white_wool
fill 13 159 497 14 159 497 minecraft:brown_wool
fill 14 159 464 17 159 477 minecraft:dark_oak_planks
fill 14 159 478 22 159 478 minecraft:brown_wool
fill 14 159 483 22 159 483 minecraft:mossy_stone_bricks
fill 14 159 493 22 159 493 minecraft:mossy_stone_bricks
fill 14 159 498 22 159 498 minecraft:brown_wool
fill 14 159 499 17 159 504 minecraft:dark_oak_planks
fill 15 159 479 21 159 479 minecraft:white_wool
fill 15 159 497 21 159 497 minecraft:white_wool
fill 16 159 482 20 159 482 minecraft:mossy_stone_bricks
fill 16 159 486 16 159 487 minecraft:mossy_stone_bricks
fill 16 159 489 16 159 490 minecraft:mossy_stone_bricks
fill 16 159 494 20 159 494 minecraft:mossy_stone_bricks
setblock 17 159 486 minecraft:mossy_stone_bricks
setblock 17 159 490 minecraft:mossy_stone_bricks
fill 18 159 464 41 159 476 minecraft:dark_oak_planks
setblock 18 159 477 minecraft:brown_wool
setblock 18 159 499 minecraft:brown_wool
fill 18 159 500 41 159 504 minecraft:dark_oak_planks
fill 19 159 477 41 159 477 minecraft:dark_oak_planks
fill 19 159 486 24 159 486 minecraft:mossy_stone_bricks
fill 19 159 490 24 159 490 minecraft:mossy_stone_bricks
fill 19 159 499 41 159 499 minecraft:dark_oak_planks
fill 20 159 487 24 159 487 minecraft:mossy_stone_bricks
fill 20 159 489 24 159 489 minecraft:mossy_stone_bricks
fill 21 159 482 25 159 482 minecraft:white_wool
fill 21 159 488 24 159 488 minecraft:mossy_stone_bricks
fill 21 159 494 25 159 494 minecraft:white_wool
fill 22 159 479 24 159 479 minecraft:brown_wool
fill 22 159 497 24 159 497 minecraft:brown_wool
fill 23 159 478 41 159 478 minecraft:dark_oak_planks
fill 23 159 483 26 159 483 minecraft:white_wool
fill 23 159 493 26 159 493 minecraft:white_wool
fill 23 159 498 41 159 498 minecraft:dark_oak_planks
fill 24 159 480 25 159 480 minecraft:brown_wool
fill 24 159 484 26 159 485 minecraft:white_wool
fill 24 159 491 26 159 492 minecraft:white_wool
fill 24 159 496 25 159 496 minecraft:brown_wool
fill 25 159 479 41 159 479 minecraft:dark_oak_planks
fill 25 159 481 26 159 481 minecraft:brown_wool
fill 25 159 486 27 159 490 minecraft:white_wool
fill 25 159 495 26 159 495 minecraft:brown_wool
fill 25 159 497 41 159 497 minecraft:dark_oak_planks
fill 26 159 480 41 159 480 minecraft:dark_oak_planks
fill 26 159 482 27 159 482 minecraft:brown_wool
fill 26 159 494 27 159 494 minecraft:brown_wool
fill 26 159 496 41 159 496 minecraft:dark_oak_planks
fill 27 159 481 41 159 481 minecraft:dark_oak_planks
fill 27 159 483 27 159 484 minecraft:brown_wool
setblock 27 159 485 minecraft:white_wool
setblock 27 159 491 minecraft:white_wool
fill 27 159 492 27 159 493 minecraft:brown_wool
fill 27 159 495 41 159 495 minecraft:dark_oak_planks
fill 28 159 482 41 159 483 minecraft:dark_oak_planks
fill 28 159 484 28 159 492 minecraft:brown_wool
fill 28 159 493 41 159 494 minecraft:dark_oak_planks
fill 29 159 484 41 159 487 minecraft:dark_oak_planks
setblock 29 159 488 minecraft:brown_wool
fill 29 159 489 41 159 492 minecraft:dark_oak_planks
fill 30 159 488 41 159 488 minecraft:dark_oak_planks
fill 10 160 486 11 169 490 minecraft:stone_bricks
fill 11 160 481 13 172 484 minecraft:cobblestone
fill 11 160 485 12 169 485 minecraft:stone_bricks
fill 11 160 491 12 170 491 minecraft:stone_bricks
fill 11 160 492 13 172 495 minecraft:cobblestone
fill 14 160 481 14 172 483 minecraft:cobblestone
fill 14 160 493 14 172 495 minecraft:cobblestone
fill 15 160 481 15 169 482 minecraft:stone_bricks
fill 15 160 494 15 169 495 minecraft:stone_bricks
fill 16 160 480 20 169 481 minecraft:stone_bricks
fill 16 160 495 20 169 496 minecraft:stone_bricks
fill 21 160 481 21 169 482 minecraft:stone_bricks
fill 21 160 494 21 170 495 minecraft:stone_bricks
fill 22 160 481 25 172 483 minecraft:cobblestone
fill 22 160 493 25 172 495 minecraft:cobblestone
fill 23 160 484 25 172 484 minecraft:cobblestone
fill 23 160 492 25 172 492 minecraft:cobblestone
fill 24 160 485 25 170 485 minecraft:stone_bricks
fill 24 160 491 25 169 491 minecraft:stone_bricks
fill 25 160 486 26 169 490 minecraft:stone_bricks
setblock 1 163 464 minecraft:bookshelf
fill 1 163 469 1 220 469 minecraft:bookshelf
setblock 1 163 471 minecraft:bookshelf
fill 1 163 476 1 220 476 minecraft:bookshelf
setblock 1 163 478 minecraft:bookshelf
fill 1 163 483 1 220 483 minecraft:bookshelf
setblock 1 163 485 minecraft:bookshelf
fill 1 163 490 1 220 490 minecraft:bookshelf
setblock 1 163 492 minecraft:bookshelf
fill 1 163 497 1 220 497 minecraft:bookshelf
setblock 1 163 499 minecraft:bookshelf
fill 1 163 504 1 220 504 minecraft:bookshelf
fill 3 163 464 3 220 464 minecraft:bookshelf
setblock 3 163 504 minecraft:bookshelf
setblock 8 163 464 minecraft:bookshelf
fill 8 163 504 8 220 504 minecraft:bookshelf
fill 10 163 464 10 220 464 minecraft:bookshelf
setblock 10 163 504 minecraft:bookshelf
setblock 15 163 464 minecraft:bookshelf
fill 15 163 504 15 220 504 minecraft:bookshelf
fill 17 163 464 17 220 464 minecraft:bookshelf
setblock 17 163 504 minecraft:bookshelf
setblock 22 163 464 minecraft:bookshelf
fill 22 163 504 22 220 504 minecraft:bookshelf
fill 24 163 464 24 220 464 minecraft:bookshelf
setblock 24 163 504 minecraft:bookshelf
fill 28 163 464 36 186 471 minecraft:bookshelf
fill 29 163 504 29 220 504 minecraft:bookshelf
setblock 31 163 504 minecraft:bookshelf
fill 33 163 497 41 165 504 minecraft:bookshelf
fill 38 163 464 38 220 464 minecraft:bookshelf
fill 39 163 481 41 163 485 minecraft:bookshelf
setblock 41 163 466 minecraft:bookshelf
fill 41 163 468 41 220 468 minecraft:bookshelf
setblock 41 163 473 minecraft:bookshelf
fill 41 163 475 41 220 475 minecraft:bookshelf
setblock 41 163 480 minecraft:bookshelf
fill 41 163 487 41 165 487 minecraft:bookshelf
fill 41 163 489 41 220 489 minecraft:bookshelf
setblock 41 163 494 minecraft:bookshelf
fill 41 163 496 41 220 496 minecraft:bookshelf
setblock 1 164 465 minecraft:bookshelf
setblock 1 164 472 minecraft:bookshelf
setblock 1 164 479 minecraft:bookshelf
setblock 1 164 486 minecraft:bookshelf
setblock 1 164 493 minecraft:bookshelf
setblock 1 164 500 minecraft:bookshelf
setblock 4 164 504 minecraft:bookshelf
setblock 7 164 464 minecraft:bookshelf
setblock 11 164 504 minecraft:bookshelf
setblock 14 164 464 minecraft:bookshelf
setblock 18 164 504 minecraft:bookshelf
setblock 21 164 464 minecraft:bookshelf
setblock 25 164 504 minecraft:bookshelf
setblock 32 164 504 minecraft:bookshelf
fill 39 164 484 40 164 488 minecraft:bookshelf
setblock 41 164 465 minecraft:bookshelf
setblock 41 164 472 minecraft:bookshelf
setblock 41 164 479 minecraft:bookshelf
fill 41 164 482 41 220 482 minecraft:bookshelf
fill 41 164 484 41 164 486 minecraft:bookshelf
fill 41 164 488 41 165 488 minecraft:bookshelf
setblock 41 164 493 minecraft:bookshelf
setblock 1 165 466 minecraft:bookshelf
setblock 1 165 473 minecraft:bookshelf
setblock 1 165 480 minecraft:bookshelf
setblock 1 165 487 minecraft:bookshelf
setblock 1 165 494 minecraft:bookshelf
setblock 1 165 501 minecraft:bookshelf
setblock 5 165 504 minecraft:bookshelf
setblock 6 165 464 minecraft:bookshelf
setblock 12 165 504 minecraft:bookshelf
setblock 13 165 464 minecraft:bookshelf
setblock 19 165 504 minecraft:bookshelf
setblock 20 165 464 minecraft:bookshelf
setblock 26 165 504 minecraft:bookshelf
setblock 27 165 464 minecraft:bookshelf
fill 39 165 487 40 165 491 minecraft:bookshelf
setblock 41 165 464 minecraft:bookshelf
setblock 41 165 471 minecraft:bookshelf
setblock 41 165 478 minecraft:bookshelf
setblock 41 165 485 minecraft:bookshelf
fill 41 165 490 41 165 492 minecraft:bookshelf
setblock 1 166 467 minecraft:bookshelf
setblock 1 166 474 minecraft:bookshelf
setblock 1 166 481 minecraft:bookshelf
setblock 1 166 488 minecraft:bookshelf
setblock 1 166 495 minecraft:bookshelf
setblock 1 166 502 minecraft:bookshelf
setblock 3 166 466 minecraft:light[level=12]
setblock 3 166 474 minecraft:light[level=12]
setblock 3 166 482 minecraft:light[level=12]
setblock 3 166 490 minecraft:light[level=12]
setblock 3 166 498 minecraft:light[level=12]
setblock 5 166 464 minecraft:bookshelf
setblock 6 166 504 minecraft:bookshelf
setblock 11 166 466 minecraft:light[level=12]
setblock 11 166 474 minecraft:light[level=12]
setblock 11 166 498 minecraft:light[level=12]
setblock 12 166 464 minecraft:bookshelf
setblock 13 166 504 minecraft:bookshelf
setblock 19 166 464 minecraft:bookshelf
setblock 19 166 466 minecraft:light[level=12]
setblock 19 166 474 minecraft:light[level=12]
setblock 19 166 482 minecraft:light[level=12]
setblock 19 166 490 minecraft:light[level=12]
setblock 19 166 498 minecraft:light[level=12]
setblock 20 166 504 minecraft:bookshelf
setblock 26 166 464 minecraft:bookshelf
setblock 27 166 466 minecraft:light[level=12]
setblock 27 166 474 minecraft:light[level=12]
setblock 27 166 482 minecraft:light[level=12]
setblock 27 166 490 minecraft:light[level=12]
setblock 27 166 498 minecraft:light[level=12]
setblock 27 166 504 minecraft:bookshelf
fill 33 166 497 33 187 497 minecraft:bookshelf
setblock 33 166 498 minecraft:ochre_froglight
fill 33 166 499 33 187 499 minecraft:bookshelf
setblock 33 166 500 minecraft:ochre_froglight
fill 33 166 501 33 187 501 minecraft:bookshelf
setblock 33 166 502 minecraft:ochre_froglight
fill 33 166 503 33 187 503 minecraft:bookshelf
setblock 33 166 504 minecraft:ochre_froglight
setblock 34 166 497 minecraft:ochre_froglight
fill 34 166 498 34 187 498 minecraft:bookshelf
setblock 34 166 499 minecraft:ochre_froglight
fill 34 166 500 34 187 500 minecraft:bookshelf
setblock 34 166 501 minecraft:ochre_froglight
fill 34 166 502 34 187 502 minecraft:bookshelf
setblock 34 166 503 minecraft:ochre_froglight
fill 34 166 504 34 187 504 minecraft:bookshelf
setblock 35 166 474 minecraft:light[level=12]
setblock 35 166 482 minecraft:light[level=12]
setblock 35 166 490 minecraft:light[level=12]
fill 35 166 497 35 187 497 minecraft:bookshelf
setblock 35 166 498 minecraft:ochre_froglight
fill 35 166 499 35 187 499 minecraft:bookshelf
setblock 35 166 500 minecraft:ochre_froglight
fill 35 166 501 35 187 501 minecraft:bookshelf
setblock 35 166 502 minecraft:ochre_froglight
fill 35 166 503 35 187 503 minecraft:bookshelf
setblock 35 166 504 minecraft:ochre_froglight
setblock 36 166 497 minecraft:ochre_froglight
fill 36 166 498 36 187 498 minecraft:bookshelf
setblock 36 166 499 minecraft:ochre_froglight
fill 36 166 500 36 187 500 minecraft:bookshelf
setblock 36 166 501 minecraft:ochre_froglight
fill 36 166 502 36 187 502 minecraft:bookshelf
setblock 36 166 503 minecraft:ochre_froglight
fill 36 166 504 36 220 504 minecraft:bookshelf
fill 37 166 497 37 187 497 minecraft:bookshelf
setblock 37 166 498 minecraft:ochre_froglight
fill 37 166 499 37 187 499 minecraft:bookshelf
setblock 37 166 500 minecraft:ochre_froglight
fill 37 166 501 37 187 501 minecraft:bookshelf
setblock 37 166 502 minecraft:ochre_froglight
fill 37 166 503 37 187 503 minecraft:bookshelf
setblock 37 166 504 minecraft:ochre_froglight
setblock 38 166 497 minecraft:ochre_froglight
fill 38 166 498 38 187 498 minecraft:bookshelf
setblock 38 166 499 minecraft:ochre_froglight
fill 38 166 500 38 187 500 minecraft:bookshelf
setblock 38 166 501 minecraft:ochre_froglight
fill 38 166 502 38 187 502 minecraft:bookshelf
setblock 38 166 503 minecraft:ochre_froglight
fill 38 166 504 38 187 504 minecraft:bookshelf
fill 39 166 490 40 166 495 minecraft:bookshelf
fill 39 166 497 39 187 497 minecraft:bookshelf
setblock 39 166 498 minecraft:ochre_froglight
fill 39 166 499 39 187 499 minecraft:bookshelf
setblock 39 166 500 minecraft:ochre_froglight
fill 39 166 501 39 187 501 minecraft:bookshelf
setblock 39 166 502 minecraft:ochre_froglight
fill 39 166 503 39 187 503 minecraft:bookshelf
setblock 39 166 504 minecraft:ochre_froglight
setblock 40 166 464 minecraft:bookshelf
setblock 40 166 497 minecraft:ochre_froglight
fill 40 166 498 40 187 498 minecraft:bookshelf
setblock 40 166 499 minecraft:ochre_froglight
fill 40 166 500 40 187 500 minecraft:bookshelf
setblock 40 166 501 minecraft:ochre_froglight
fill 40 166 502 40 187 502 minecraft:bookshelf
setblock 40 166 503 minecraft:ochre_froglight
fill 40 166 504 40 187 504 minecraft:bookshelf
setblock 41 166 470 minecraft:bookshelf
setblock 41 166 477 minecraft:bookshelf
setblock 41 166 484 minecraft:bookshelf
fill 41 166 491 41 166 495 minecraft:bookshelf
fill 41 166 497 41 188 497 minecraft:bookshelf
setblock 41 166 498 minecraft:ochre_froglight
fill 41 166 499 41 187 499 minecraft:bookshelf
setblock 41 166 500 minecraft:ochre_froglight
fill 41 166 501 41 187 501 minecraft:bookshelf
setblock 41 166 502 minecraft:ochre_froglight
fill 41 166 503 41 220 503 minecraft:bookshelf
setblock 41 166 504 minecraft:ochre_froglight
setblock 1 167 468 minecraft:bookshelf
setblock 1 167 475 minecraft:bookshelf
setblock 1 167 482 minecraft:bookshelf
setblock 1 167 489 minecraft:bookshelf
setblock 1 167 496 minecraft:bookshelf
setblock 1 167 503 minecraft:bookshelf
setblock 4 167 464 minecraft:bookshelf
setblock 7 167 504 minecraft:bookshelf
setblock 11 167 464 minecraft:bookshelf
setblock 14 167 504 minecraft:bookshelf
setblock 18 167 464 minecraft:bookshelf
setblock 21 167 504 minecraft:bookshelf
setblock 25 167 464 minecraft:bookshelf
setblock 28 167 504 minecraft:bookshelf
fill 33 167 498 33 168 498 minecraft:bookshelf
fill 33 167 500 33 168 500 minecraft:bookshelf
fill 33 167 502 33 168 502 minecraft:bookshelf
fill 33 167 504 33 168 504 minecraft:bookshelf
fill 34 167 497 34 168 497 minecraft:bookshelf
fill 34 167 499 34 168 499 minecraft:bookshelf
fill 34 167 501 34 168 501 minecraft:bookshelf
fill 34 167 503 34 168 503 minecraft:bookshelf
fill 35 167 498 35 168 498 minecraft:bookshelf
fill 35 167 500 35 168 500 minecraft:bookshelf
fill 35 167 502 35 168 502 minecraft:bookshelf
fill 35 167 504 35 168 504 minecraft:bookshelf
fill 36 167 497 36 168 497 minecraft:bookshelf
fill 36 167 499 36 168 499 minecraft:bookshelf
fill 36 167 501 36 168 501 minecraft:bookshelf
fill 36 167 503 36 168 503 minecraft:bookshelf
fill 37 167 498 37 168 498 minecraft:bookshelf
fill 37 167 500 37 168 500 minecraft:bookshelf
fill 37 167 502 37 168 502 minecraft:bookshelf
fill 37 167 504 37 168 504 minecraft:bookshelf
fill 38 167 497 38 168 497 minecraft:bookshelf
fill 38 167 499 38 168 499 minecraft:bookshelf
fill 38 167 501 38 168 501 minecraft:bookshelf
fill 38 167 503 38 168 503 minecraft:bookshelf
setblock 39 167 464 minecraft:bookshelf
fill 39 167 493 39 167 496 minecraft:bookshelf
fill 39 167 498 39 168 498 minecraft:bookshelf
fill 39 167 500 39 168 500 minecraft:bookshelf
fill 39 167 502 39 168 502 minecraft:bookshelf
fill 39 167 504 39 168 504 minecraft:bookshelf
fill 40 167 494 40 167 497 minecraft:bookshelf
fill 40 167 499 40 168 499 minecraft:bookshelf
fill 40 167 501 40 168 501 minecraft:bookshelf
fill 40 167 503 40 168 503 minecraft:bookshelf
setblock 41 167 469 minecraft:bookshelf
setblock 41 167 476 minecraft:bookshelf
setblock 41 167 483 minecraft:bookshelf
setblock 41 167 490 minecraft:bookshelf
fill 41 167 494 41 167 495 minecraft:bookshelf
fill 41 167 498 41 168 498 minecraft:bookshelf
fill 41 167 500 41 168 500 minecraft:bookshelf
fill 41 167 502 41 168 502 minecraft:bookshelf
fill 41 167 504 41 168 504 minecraft:bookshelf
setblock 40 168 497 minecraft:bookshelf
fill 1 169 470 1 170 470 minecraft:bookshelf
fill 1 169 477 1 170 477 minecraft:bookshelf
fill 1 169 484 1 170 484 minecraft:bookshelf
fill 1 169 491 1 170 491 minecraft:bookshelf
fill 1 169 498 1 170 498 minecraft:bookshelf
fill 2 169 464 2 170 464 minecraft:bookshelf
fill 2 169 504 2 170 504 minecraft:bookshelf
fill 9 169 464 9 170 464 minecraft:bookshelf
fill 9 169 504 9 170 504 minecraft:bookshelf
fill 16 169 464 16 170 464 minecraft:bookshelf
fill 16 169 504 16 170 504 minecraft:bookshelf
fill 23 169 464 23 170 464 minecraft:bookshelf
fill 23 169 504 23 170 504 minecraft:bookshelf
fill 30 169 504 30 171 504 minecraft:bookshelf
setblock 33 169 498 minecraft:ochre_froglight
setblock 33 169 500 minecraft:ochre_froglight
setblock 33 169 502 minecraft:ochre_froglight
setblock 33 169 504 minecraft:ochre_froglight
setblock 34 169 497 minecraft:ochre_froglight
setblock 34 169 499 minecraft:ochre_froglight
setblock 34 169 501 minecraft:ochre_froglight
setblock 34 169 503 minecraft:ochre_froglight
setblock 35 169 498 minecraft:ochre_froglight
setblock 35 169 500 minecraft:ochre_froglight
setblock 35 169 502 minecraft:ochre_froglight
setblock 35 169 504 minecraft:ochre_froglight
setblock 36 169 497 minecraft:ochre_froglight
setblock 36 169 499 minecraft:ochre_froglight
setblock 36 169 501 minecraft:ochre_froglight
setblock 36 169 503 minecraft:ochre_froglight
fill 37 169 464 37 170 464 minecraft:bookshelf
setblock 37 169 498 minecraft:ochre_froglight
setblock 37 169 500 minecraft:ochre_froglight
setblock 37 169 502 minecraft:ochre_froglight
setblock 37 169 504 minecraft:ochre_froglight
fill 38 169 485 39 170 486 minecraft:white_wool
setblock 38 169 497 minecraft:ochre_froglight
setblock 38 169 499 minecraft:ochre_froglight
setblock 38 169 501 minecraft:ochre_froglight
setblock 38 169 503 minecraft:ochre_froglight
setblock 39 169 498 minecraft:ochre_froglight
setblock 39 169 500 minecraft:ochre_froglight
setblock 39 169 502 minecraft:ochre_froglight
setblock 39 169 504 minecraft:ochre_froglight
setblock 40 169 497 minecraft:ochre_froglight
setblock 40 169 499 minecraft:ochre_froglight
setblock 40 169 501 minecraft:ochre_froglight
setblock 40 169 503 minecraft:ochre_froglight
fill 41 169 467 41 170 467 minecraft:bookshelf
fill 41 169 474 41 170 474 minecraft:bookshelf
fill 41 169 481 41 170 481 minecraft:bookshelf
fill 41 169 488 41 170 488 minecraft:bookshelf
fill 41 169 495 41 170 495 minecraft:bookshelf
setblock 41 169 498 minecraft:ochre_froglight
setblock 41 169 500 minecraft:ochre_froglight
setblock 41 169 502 minecraft:ochre_froglight
setblock 41 169 504 minecraft:ochre_froglight
fill 1 170 464 1 170 468 minecraft:bookshelf
fill 1 170 471 1 170 475 minecraft:bookshelf
fill 1 170 478 1 170 482 minecraft:bookshelf
fill 1 170 485 1 170 489 minecraft:bookshelf
fill 1 170 492 1 170 496 minecraft:bookshelf
fill 1 170 499 1 170 503 minecraft:bookshelf
fill 3 170 504 7 170 504 minecraft:bookshelf
fill 4 170 464 8 170 464 minecraft:bookshelf
fill 10 170 486 11 170 486 minecraft:stone_bricks
fill 10 170 488 10 170 489 minecraft:stone_bricks
fill 10 170 504 14 170 504 minecraft:bookshelf
fill 11 170 464 15 170 464 minecraft:bookshelf
fill 11 170 487 11 170 488 minecraft:stone_bricks
fill 15 170 481 16 170 481 minecraft:stone_bricks
setblock 15 170 494 minecraft:stone_bricks
setblock 16 170 480 minecraft:stone_bricks
fill 17 170 495 18 170 496 minecraft:stone_bricks
fill 17 170 504 21 170 504 minecraft:bookshelf
fill 18 170 464 22 170 464 minecraft:bookshelf
fill 19 170 480 20 170 481 minecraft:stone_bricks
fill 24 170 504 28 170 504 minecraft:bookshelf
fill 25 170 464 27 170 464 minecraft:bookshelf
setblock 25 170 486 minecraft:stone_bricks
fill 25 170 488 26 170 489 minecraft:stone_bricks
setblock 26 170 490 minecraft:stone_bricks
fill 29 170 502 32 170 503 minecraft:bookshelf
fill 31 170 504 33 171 504 minecraft:bookshelf
fill 33 170 498 33 171 498 minecraft:bookshelf
fill 33 170 500 33 171 500 minecraft:bookshelf
fill 33 170 502 33 171 502 minecraft:bookshelf
fill 34 170 497 34 171 497 minecraft:bookshelf
fill 34 170 499 34 171 499 minecraft:bookshelf
fill 34 170 501 34 171 501 minecraft:bookshelf
fill 34 170 503 34 171 503 minecraft:bookshelf
fill 35 170 498 35 171 498 minecraft:bookshelf
fill 35 170 500 35 171 500 minecraft:bookshelf
fill 35 170 502 35 171 502 minecraft:bookshelf
fill 35 170 504 35 171 504 minecraft:bookshelf
fill 36 170 497 36 171 497 minecraft:bookshelf
fill 36 170 499 36 171 499 minecraft:bookshelf
fill 36 170 501 36 171 501 minecraft:bookshelf
fill 36 170 503 36 171 503 minecraft:bookshelf
fill 37 170 498 37 171 498 minecraft:bookshelf
fill 37 170 500 37 171 500 minecraft:bookshelf
fill 37 170 502 37 171 502 minecraft:bookshelf
fill 37 170 504 37 171 504 minecraft:bookshelf
fill 38 170 497 38 171 497 minecraft:bookshelf
fill 38 170 499 38 171 499 minecraft:bookshelf
fill 38 170 501 38 171 501 minecraft:bookshelf
fill 38 170 503 38 171 503 minecraft:bookshelf
fill 39 170 464 41 170 464 minecraft:bookshelf
fill 39 170 498 39 171 498 minecraft:bookshelf
fill 39 170 500 39 171 500 minecraft:bookshelf
fill 39 170 502 39 171 502 minecraft:bookshelf
fill 39 170 504 39 171 504 minecraft:bookshelf
fill 40 170 497 40 171 497 minecraft:bookshelf
fill 40 170 499 40 171 499 minecraft:bookshelf
fill 40 170 501 40 171 501 minecraft:bookshelf
fill 40 170 503 40 171 503 minecraft:bookshelf
fill 41 170 465 41 170 466 minecraft:bookshelf
fill 41 170 469 41 170 473 minecraft:bookshelf
fill 41 170 476 41 170 480 minecraft:bookshelf
fill 41 170 483 41 170 487 minecraft:bookshelf
fill 41 170 490 41 170 494 minecraft:bookshelf
fill 41 170 498 41 171 498 minecraft:bookshelf
fill 41 170 500 41 171 500 minecraft:bookshelf
fill 41 170 502 41 171 502 minecraft:bookshelf
fill 41 170 504 41 171 504 minecraft:bookshelf
setblock 1 171 465 minecraft:bookshelf
setblock 1 171 472 minecraft:bookshelf
setblock 1 171 479 minecraft:bookshelf
setblock 1 171 486 minecraft:bookshelf
setblock 1 171 493 minecraft:bookshelf
setblock 1 171 500 minecraft:bookshelf
setblock 4 171 504 minecraft:bookshelf
setblock 7 171 464 minecraft:bookshelf
setblock 11 171 504 minecraft:bookshelf
setblock 14 171 464 minecraft:bookshelf
setblock 18 171 504 minecraft:bookshelf
setblock 21 171 464 minecraft:bookshelf
fill 25 171 504 28 171 504 minecraft:bookshelf
fill 26 171 502 30 171 503 minecraft:bookshelf
setblock 31 171 503 minecraft:bookshelf
setblock 41 171 465 minecraft:bookshelf
setblock 41 171 472 minecraft:bookshelf
setblock 41 171 479 minecraft:bookshelf
setblock 41 171 486 minecraft:bookshelf
setblock 41 171 493 minecraft:bookshelf
setblock 1 172 466 minecraft:bookshelf
setblock 1 172 473 minecraft:bookshelf
setblock 1 172 480 minecraft:bookshelf
setblock 1 172 487 minecraft:bookshelf
setblock 1 172 494 minecraft:bookshelf
setblock 1 172 501 minecraft:bookshelf
setblock 5 172 504 minecraft:bookshelf
setblock 6 172 464 minecraft:bookshelf
setblock 12 172 504 minecraft:bookshelf
setblock 13 172 464 minecraft:bookshelf
setblock 19 172 504 minecraft:bookshelf
setblock 20 172 464 minecraft:bookshelf
fill 23 172 502 27 172 504 minecraft:bookshelf
setblock 27 172 464 minecraft:bookshelf
setblock 33 172 498 minecraft:ochre_froglight
setblock 33 172 500 minecraft:ochre_froglight
setblock 33 172 502 minecraft:ochre_froglight
setblock 33 172 504 minecraft:ochre_froglight
setblock 34 172 497 minecraft:ochre_froglight
setblock 34 172 499 minecraft:ochre_froglight
setblock 34 172 501 minecraft:ochre_froglight
setblock 34 172 503 minecraft:ochre_froglight
setblock 35 172 498 minecraft:ochre_froglight
setblock 35 172 500 minecraft:ochre_froglight
setblock 35 172 502 minecraft:ochre_froglight
setblock 35 172 504 minecraft:ochre_froglight
setblock 36 172 497 minecraft:ochre_froglight
setblock 36 172 499 minecraft:ochre_froglight
setblock 36 172 501 minecraft:ochre_froglight
setblock 36 172 503 minecraft:ochre_froglight
setblock 37 172 498 minecraft:ochre_froglight
setblock 37 172 500 minecraft:ochre_froglight
setblock 37 172 502 minecraft:ochre_froglight
setblock 37 172 504 minecraft:ochre_froglight
setblock 38 172 497 minecraft:ochre_froglight
setblock 38 172 499 minecraft:ochre_froglight
setblock 38 172 501 minecraft:ochre_froglight
setblock 38 172 503 minecraft:ochre_froglight
setblock 39 172 498 minecraft:ochre_froglight
setblock 39 172 500 minecraft:ochre_froglight
setblock 39 172 502 minecraft:ochre_froglight
setblock 39 172 504 minecraft:ochre_froglight
setblock 40 172 497 minecraft:ochre_froglight
setblock 40 172 499 minecraft:ochre_froglight
setblock 40 172 501 minecraft:ochre_froglight
setblock 40 172 503 minecraft:ochre_froglight
setblock 41 172 464 minecraft:bookshelf
setblock 41 172 471 minecraft:bookshelf
setblock 41 172 478 minecraft:bookshelf
setblock 41 172 485 minecraft:bookshelf
setblock 41 172 492 minecraft:bookshelf
setblock 41 172 498 minecraft:ochre_froglight
setblock 41 172 500 minecraft:ochre_froglight
setblock 41 172 502 minecraft:ochre_froglight
setblock 41 172 504 minecraft:ochre_froglight
setblock 1 173 467 minecraft:bookshelf
setblock 1 173 474 minecraft:bookshelf
setblock 1 173 481 minecraft:bookshelf
setblock 1 173 488 minecraft:bookshelf
setblock 1 173 495 minecraft:bookshelf
setblock 1 173 502 minecraft:bookshelf
setblock 5 173 464 minecraft:bookshelf
setblock 6 173 504 minecraft:bookshelf
fill 10 173 482 14 173 483 minecraft:dark_oak_planks
fill 10 173 493 14 173 494 minecraft:dark_oak_planks
fill 11 173 481 14 173 481 minecraft:dark_oak_planks
fill 11 173 484 14 173 484 minecraft:dark_oak_planks
fill 11 173 492 14 173 492 minecraft:dark_oak_planks
fill 11 173 495 14 173 495 minecraft:dark_oak_planks
setblock 12 173 464 minecraft:bookshelf
fill 12 173 480 13 173 480 minecraft:dark_oak_planks
fill 12 173 496 13 173 496 minecraft:dark_oak_planks
setblock 13 173 504 minecraft:bookshelf
setblock 19 173 464 minecraft:bookshelf
fill 20 173 502 21 174 504 minecraft:bookshelf
fill 22 173 481 25 173 484 minecraft:dark_oak_planks
fill 22 173 492 25 173 495 minecraft:dark_oak_planks
fill 22 173 502 24 173 503 minecraft:bookshelf
fill 23 173 480 24 173 480 minecraft:dark_oak_planks
fill 23 173 496 24 173 496 minecraft:dark_oak_planks
fill 23 173 504 24 173 504 minecraft:bookshelf
setblock 26 173 464 minecraft:bookshelf
fill 26 173 482 26 173 483 minecraft:dark_oak_planks
fill 26 173 493 26 173 494 minecraft:dark_oak_planks
setblock 27 173 504 minecraft:bookshelf
fill 33 173 498 33 174 498 minecraft:bookshelf
fill 33 173 500 33 174 500 minecraft:bookshelf
fill 33 173 502 33 174 502 minecraft:bookshelf
fill 33 173 504 33 174 504 minecraft:bookshelf
fill 34 173 497 34 174 497 minecraft:bookshelf
fill 34 173 499 34 174 499 minecraft:bookshelf
fill 34 173 501 34 174 501 minecraft:bookshelf
fill 34 173 503 34 174 503 minecraft:bookshelf
fill 35 173 498 35 174 498 minecraft:bookshelf
fill 35 173 500 35 174 500 minecraft:bookshelf
fill 35 173 502 35 174 502 minecraft:bookshelf
fill 35 173 504 35 174 504 minecraft:bookshelf
fill 36 173 497 36 174 497 minecraft:bookshelf
fill 36 173 499 36 174 499 minecraft:bookshelf
fill 36 173 501 36 174 501 minecraft:bookshelf
fill 36 173 503 36 174 503 minecraft:bookshelf
fill 37 173 498 37 174 498 minecraft:bookshelf
fill 37 173 500 37 174 500 minecraft:bookshelf
fill 37 173 502 37 174 502 minecraft:bookshelf
fill 37 173 504 37 174 504 minecraft:bookshelf
fill 38 173 497 38 174 497 minecraft:bookshelf
fill 38 173 499 38 174 499 minecraft:bookshelf
fill 38 173 501 38 174 501 minecraft:bookshelf
fill 38 173 503 38 174 503 minecraft:bookshelf
fill 39 173 498 39 174 498 minecraft:bookshelf
fill 39 173 500 39 174 500 minecraft:bookshelf
fill 39 173 502 39 174 502 minecraft:bookshelf
fill 39 173 504 39 174 504 minecraft:bookshelf
setblock 40 173 464 minecraft:bookshelf
fill 40 173 497 40 174 497 minecraft:bookshelf
fill 40 173 499 40 174 499 minecraft:bookshelf
fill 40 173 501 40 174 501 minecraft:bookshelf
fill 40 173 503 40 174 503 minecraft:bookshelf
setblock 41 173 470 minecraft:bookshelf
setblock 41 173 477 minecraft:bookshelf
setblock 41 173 484 minecraft:bookshelf
setblock 41 173 491 minecraft:bookshelf
fill 41 173 498 41 174 498 minecraft:bookshelf
fill 41 173 500 41 174 500 minecraft:bookshelf
fill 41 173 502 41 174 502 minecraft:bookshelf
fill 41 173 504 41 174 504 minecraft:bookshelf
setblock 1 174 468 minecraft:bookshelf
setblock 1 174 475 minecraft:bookshelf
setblock 1 174 482 minecraft:bookshelf
setblock 1 174 489 minecraft:bookshelf
setblock 1 174 496 minecraft:bookshelf
setblock 1 174 503 minecraft:bookshelf
setblock 3 174 466 minecraft:light[level=12]
setblock 3 174 474 minecraft:light[level=12]
setblock 3 174 482 minecraft:light[level=12]
setblock 3 174 490 minecraft:light[level=12]
setblock 3 174 498 minecraft:light[level=12]
setblock 4 174 464 minecraft:bookshelf
setblock 7 174 504 minecraft:bookshelf
setblock 11 174 464 minecraft:bookshelf
setblock 11 174 466 minecraft:light[level=12]
setblock 11 174 474 minecraft:light[level=12]
fill 11 174 481 13 174 483 minecraft:dark_oak_planks
setblock 11 174 490 minecraft:light[level=12]
fill 11 174 493 13 174 495 minecraft:dark_oak_planks
setblock 11 174 498 minecraft:light[level=12]
fill 12 174 484 13 174 484 minecraft:dark_oak_planks
fill 12 174 492 13 174 492 minecraft:dark_oak_planks
fill 14 174 482 14 174 483 minecraft:dark_oak_planks
fill 14 174 493 14 174 494 minecraft:dark_oak_planks
fill 14 174 504 14 176 504 minecraft:bookshelf
fill 17 174 502 19 174 504 minecraft:bookshelf
setblock 18 174 464 minecraft:bookshelf
setblock 19 174 466 minecraft:light[level=12]
setblock 19 174 474 minecraft:light[level=12]
setblock 19 174 482 minecraft:light[level=12]
setblock 19 174 490 minecraft:light[level=12]
setblock 19 174 498 minecraft:light[level=12]
fill 22 174 482 25 174 483 minecraft:dark_oak_planks
fill 22 174 493 25 174 494 minecraft:dark_oak_planks
fill 23 174 481 25 174 481 minecraft:dark_oak_planks
fill 23 174 484 24 174 484 minecraft:dark_oak_planks
fill 23 174 492 24 174 492 minecraft:dark_oak_planks
fill 23 174 495 25 174 495 minecraft:dark_oak_planks
setblock 25 174 464 minecraft:bookshelf
setblock 27 174 466 minecraft:light[level=12]
setblock 27 174 474 minecraft:light[level=12]
setblock 27 174 482 minecraft:light[level=12]
setblock 27 174 490 minecraft:light[level=12]
setblock 27 174 498 minecraft:light[level=12]
setblock 28 174 504 minecraft:bookshelf
setblock 35 174 474 minecraft:light[level=12]
setblock 35 174 482 minecraft:light[level=12]
setblock 35 174 490 minecraft:light[level=12]
setblock 39 174 464 minecraft:bookshelf
setblock 41 174 469 minecraft:bookshelf
setblock 41 174 476 minecraft:bookshelf
setblock 41 174 483 minecraft:bookshelf
setblock 41 174 490 minecraft:bookshelf
fill 11 175 482 13 175 483 minecraft:dark_oak_planks
fill 11 175 493 13 175 494 minecraft:dark_oak_planks
fill 12 175 481 13 175 481 minecraft:dark_oak_planks
fill 12 175 495 13 175 495 minecraft:dark_oak_planks
setblock 13 175 492 minecraft:blue_wool
fill 13 175 504 13 176 504 minecraft:bookshelf
fill 14 175 502 18 175 503 minecraft:bookshelf
fill 16 175 504 18 175 504 minecraft:bookshelf
fill 23 175 481 24 175 483 minecraft:dark_oak_planks
fill 23 175 493 24 175 495 minecraft:dark_oak_planks
fill 25 175 482 25 175 483 minecraft:dark_oak_planks
fill 25 175 493 25 175 494 minecraft:dark_oak_planks
setblock 33 175 498 minecraft:ochre_froglight
setblock 33 175 500 minecraft:ochre_froglight
setblock 33 175 502 minecraft:ochre_froglight
setblock 33 175 504 minecraft:ochre_froglight
setblock 34 175 497 minecraft:ochre_froglight
setblock 34 175 499 minecraft:ochre_froglight
setblock 34 175 501 minecraft:ochre_froglight
setblock 34 175 503 minecraft:ochre_froglight
setblock 35 175 498 minecraft:ochre_froglight
setblock 35 175 500 minecraft:ochre_froglight
setblock 35 175 502 minecraft:ochre_froglight
setblock 35 175 504 minecraft:ochre_froglight
setblock 36 175 497 minecraft:ochre_froglight
setblock 36 175 499 minecraft:ochre_froglight
setblock 36 175 501 minecraft:ochre_froglight
setblock 36 175 503 minecraft:ochre_froglight
setblock 37 175 498 minecraft:ochre_froglight
setblock 37 175 500 minecraft:ochre_froglight
setblock 37 175 502 minecraft:ochre_froglight
setblock 37 175 504 minecraft:ochre_froglight
fill 38 175 480 39 176 480 minecraft:blue_wool
setblock 38 175 497 minecraft:ochre_froglight
setblock 38 175 499 minecraft:ochre_froglight
setblock 38 175 501 minecraft:ochre_froglight
setblock 38 175 503 minecraft:ochre_froglight
setblock 39 175 498 minecraft:ochre_froglight
setblock 39 175 500 minecraft:ochre_froglight
setblock 39 175 502 minecraft:ochre_froglight
setblock 39 175 504 minecraft:ochre_froglight
setblock 40 175 497 minecraft:ochre_froglight
setblock 40 175 499 minecraft:ochre_froglight
setblock 40 175 501 minecraft:ochre_froglight
setblock 40 175 503 minecraft:ochre_froglight
setblock 41 175 498 minecraft:ochre_froglight
setblock 41 175 500 minecraft:ochre_froglight
setblock 41 175 502 minecraft:ochre_froglight
setblock 41 175 504 minecraft:ochre_froglight
setblock 1 176 470 minecraft:bookshelf
setblock 1 176 477 minecraft:bookshelf
setblock 1 176 484 minecraft:bookshelf
setblock 1 176 491 minecraft:bookshelf
setblock 1 176 498 minecraft:bookshelf
setblock 2 176 464 minecraft:bookshelf
setblock 2 176 504 minecraft:bookshelf
setblock 9 176 464 minecraft:bookshelf
fill 9 176 504 12 176 504 minecraft:bookshelf
fill 10 176 502 15 176 503 minecraft:bookshelf
fill 12 176 482 13 176 483 minecraft:dark_oak_planks
fill 12 176 493 13 176 494 minecraft:dark_oak_planks
setblock 16 176 464 minecraft:bookshelf
setblock 16 176 504 minecraft:bookshelf
setblock 23 176 464 minecraft:bookshelf
fill 23 176 482 24 176 483 minecraft:dark_oak_planks
fill 23 176 493 24 176 494 minecraft:dark_oak_planks
setblock 23 176 504 minecraft:bookshelf
setblock 30 176 504 minecraft:bookshelf
fill 33 176 498 33 177 498 minecraft:bookshelf
fill 33 176 500 33 177 500 minecraft:bookshelf
fill 33 176 502 33 177 502 minecraft:bookshelf
fill 33 176 504 33 177 504 minecraft:bookshelf
fill 34 176 497 34 177 497 minecraft:bookshelf
fill 34 176 499 34 177 499 minecraft:bookshelf
fill 34 176 501 34 177 501 minecraft:bookshelf
fill 34 176 503 34 177 503 minecraft:bookshelf
fill 35 176 498 35 177 498 minecraft:bookshelf
fill 35 176 500 35 177 500 minecraft:bookshelf
fill 35 176 502 35 177 502 minecraft:bookshelf
fill 35 176 504 35 177 504 minecraft:bookshelf
fill 36 176 497 36 177 497 minecraft:bookshelf
fill 36 176 499 36 177 499 minecraft:bookshelf
fill 36 176 501 36 177 501 minecraft:bookshelf
fill 36 176 503 36 177 503 minecraft:bookshelf
setblock 37 176 464 minecraft:bookshelf
fill 37 176 498 37 177 498 minecraft:bookshelf
fill 37 176 500 37 177 500 minecraft:bookshelf
fill 37 176 502 37 177 502 minecraft:bookshelf
fill 37 176 504 37 177 504 minecraft:bookshelf
fill 38 176 497 38 177 497 minecraft:bookshelf
fill 38 176 499 38 177 499 minecraft:bookshelf
fill 38 176 501 38 177 501 minecraft:bookshelf
schedule function dropper:buildpart/108_3 1t
