fill 517 150 278 517 157 278 minecraft:brown_terracotta
setblock 517 150 279 minecraft:white_concrete
fill 517 150 280 517 157 280 minecraft:brown_terracotta
fill 517 150 281 517 151 284 minecraft:shroomlight
fill 517 150 286 517 157 286 minecraft:brown_terracotta
fill 517 150 287 518 150 287 minecraft:white_concrete
fill 517 150 288 517 157 288 minecraft:brown_terracotta
fill 517 150 290 517 157 290 minecraft:brown_terracotta
setblock 517 150 291 minecraft:white_concrete
fill 517 150 292 517 157 292 minecraft:brown_terracotta
fill 517 150 293 517 151 296 minecraft:shroomlight
fill 517 150 298 517 157 298 minecraft:brown_terracotta
fill 517 150 299 518 150 299 minecraft:white_concrete
fill 517 150 300 517 157 300 minecraft:brown_terracotta
fill 517 150 302 517 157 302 minecraft:brown_terracotta
setblock 517 150 303 minecraft:white_concrete
fill 517 150 304 517 157 304 minecraft:brown_terracotta
fill 517 150 305 517 151 308 minecraft:shroomlight
fill 517 150 310 517 157 310 minecraft:brown_terracotta
fill 517 150 311 518 150 311 minecraft:white_concrete
fill 517 150 312 517 157 312 minecraft:brown_terracotta
fill 517 150 314 517 157 314 minecraft:brown_terracotta
setblock 517 150 315 minecraft:white_concrete
fill 517 150 316 517 157 316 minecraft:brown_terracotta
fill 517 150 317 520 151 317 minecraft:shroomlight
fill 518 150 275 518 157 275 minecraft:brown_terracotta
fill 518 150 276 520 213 276 minecraft:white_concrete
fill 518 150 286 518 213 286 minecraft:white_concrete
fill 518 150 288 518 213 288 minecraft:white_concrete
fill 518 150 298 518 213 298 minecraft:white_concrete
fill 518 150 300 518 213 300 minecraft:white_concrete
fill 518 150 310 518 213 310 minecraft:white_concrete
fill 518 150 312 518 213 312 minecraft:white_concrete
fill 519 150 279 519 150 281 minecraft:brown_terracotta
fill 520 150 275 520 157 275 minecraft:brown_terracotta
fill 520 150 278 522 150 278 minecraft:brown_terracotta
fill 520 150 279 522 213 281 minecraft:white_concrete
fill 520 150 282 522 150 282 minecraft:brown_terracotta
setblock 521 150 275 minecraft:white_concrete
setblock 521 150 317 minecraft:white_concrete
fill 522 150 275 522 157 275 minecraft:brown_terracotta
fill 522 150 317 522 157 317 minecraft:brown_terracotta
fill 523 150 279 523 150 281 minecraft:brown_terracotta
fill 524 150 275 527 151 275 minecraft:shroomlight
fill 524 150 316 526 213 316 minecraft:white_concrete
fill 524 150 317 524 157 317 minecraft:brown_terracotta
setblock 525 150 298 minecraft:white_concrete
setblock 525 150 317 minecraft:white_concrete
fill 526 150 317 526 157 317 minecraft:brown_terracotta
fill 528 150 275 528 157 275 minecraft:brown_terracotta
setblock 528 150 291 minecraft:white_concrete
setblock 528 150 305 minecraft:white_concrete
fill 528 150 317 528 157 317 minecraft:brown_terracotta
setblock 529 150 275 minecraft:white_concrete
fill 529 150 317 532 151 317 minecraft:shroomlight
fill 530 150 275 530 157 275 minecraft:brown_terracotta
fill 530 150 276 532 213 276 minecraft:white_concrete
fill 532 150 275 532 157 275 minecraft:brown_terracotta
setblock 533 150 275 minecraft:white_concrete
setblock 533 150 317 minecraft:white_concrete
fill 534 150 275 534 157 275 minecraft:brown_terracotta
fill 534 150 317 534 157 317 minecraft:brown_terracotta
setblock 535 150 288 minecraft:white_concrete
setblock 535 150 308 minecraft:white_concrete
fill 536 150 275 539 151 275 minecraft:shroomlight
fill 536 150 316 538 186 316 minecraft:white_concrete
fill 536 150 317 536 157 317 minecraft:brown_terracotta
setblock 537 150 317 minecraft:white_concrete
fill 538 150 317 538 157 317 minecraft:brown_terracotta
fill 540 150 275 540 157 275 minecraft:brown_terracotta
fill 540 150 317 540 157 317 minecraft:brown_terracotta
setblock 541 150 275 minecraft:white_concrete
fill 541 150 317 544 151 317 minecraft:shroomlight
fill 542 150 275 542 157 275 minecraft:brown_terracotta
fill 542 150 276 544 213 276 minecraft:white_concrete
setblock 542 150 291 minecraft:white_concrete
setblock 542 150 305 minecraft:white_concrete
fill 544 150 275 544 157 275 minecraft:brown_terracotta
setblock 545 150 275 minecraft:white_concrete
setblock 545 150 298 minecraft:white_concrete
setblock 545 150 317 minecraft:white_concrete
fill 546 150 275 546 157 275 minecraft:brown_terracotta
fill 546 150 317 546 157 317 minecraft:brown_terracotta
fill 548 150 275 551 151 275 minecraft:shroomlight
fill 548 150 283 558 150 289 minecraft:white_concrete
fill 548 150 316 550 213 316 minecraft:white_concrete
fill 548 150 317 548 157 317 minecraft:brown_terracotta
setblock 549 150 317 minecraft:white_concrete
fill 550 150 276 558 150 282 minecraft:white_concrete
fill 550 150 296 558 150 306 minecraft:white_concrete
fill 550 150 317 550 157 317 minecraft:brown_terracotta
fill 552 150 275 552 157 275 minecraft:brown_terracotta
fill 552 150 294 558 150 295 minecraft:white_concrete
fill 552 150 317 552 157 317 minecraft:brown_terracotta
setblock 553 150 275 minecraft:white_concrete
fill 553 150 317 556 151 317 minecraft:shroomlight
fill 554 150 275 554 157 275 minecraft:brown_terracotta
fill 556 150 275 556 157 275 minecraft:brown_terracotta
setblock 557 150 275 minecraft:white_concrete
setblock 557 150 317 minecraft:white_concrete
fill 558 150 275 558 157 275 minecraft:brown_terracotta
fill 558 150 308 558 213 310 minecraft:white_concrete
fill 558 150 317 558 157 317 minecraft:brown_terracotta
setblock 559 150 275 minecraft:white_concrete
fill 559 150 276 559 151 279 minecraft:shroomlight
fill 559 150 280 559 157 280 minecraft:brown_terracotta
fill 559 150 282 559 157 282 minecraft:brown_terracotta
setblock 559 150 283 minecraft:white_concrete
fill 559 150 284 559 157 284 minecraft:brown_terracotta
fill 559 150 286 559 157 286 minecraft:brown_terracotta
setblock 559 150 287 minecraft:white_concrete
fill 559 150 288 559 151 291 minecraft:shroomlight
fill 559 150 292 559 157 292 minecraft:brown_terracotta
fill 559 150 294 559 157 294 minecraft:brown_terracotta
setblock 559 150 295 minecraft:white_concrete
fill 559 150 296 559 157 296 minecraft:brown_terracotta
fill 559 150 298 559 157 298 minecraft:brown_terracotta
setblock 559 150 299 minecraft:white_concrete
fill 559 150 300 559 151 303 minecraft:shroomlight
fill 559 150 304 559 157 304 minecraft:brown_terracotta
fill 559 150 306 559 157 306 minecraft:brown_terracotta
setblock 559 150 307 minecraft:white_concrete
fill 559 150 308 559 157 308 minecraft:brown_terracotta
fill 559 150 310 559 157 310 minecraft:brown_terracotta
setblock 559 150 311 minecraft:white_concrete
fill 559 150 312 559 151 315 minecraft:shroomlight
fill 559 150 316 559 157 316 minecraft:brown_terracotta
fill 517 151 275 517 158 275 minecraft:brown_terracotta
fill 517 151 279 517 158 279 minecraft:brown_terracotta
fill 517 151 287 517 158 287 minecraft:brown_terracotta
fill 517 151 291 517 158 291 minecraft:brown_terracotta
fill 517 151 299 517 158 299 minecraft:brown_terracotta
fill 517 151 303 517 158 303 minecraft:brown_terracotta
fill 517 151 311 517 158 311 minecraft:brown_terracotta
fill 517 151 315 517 158 315 minecraft:brown_terracotta
fill 518 151 287 518 213 287 minecraft:white_concrete
fill 518 151 299 518 213 299 minecraft:white_concrete
fill 518 151 311 518 213 311 minecraft:white_concrete
setblock 520 151 278 minecraft:light[level=12]
setblock 520 151 285 minecraft:light[level=12]
setblock 520 151 292 minecraft:light[level=12]
setblock 520 151 299 minecraft:light[level=12]
setblock 520 151 306 minecraft:light[level=12]
setblock 520 151 313 minecraft:light[level=12]
fill 521 151 275 521 158 275 minecraft:brown_terracotta
fill 521 151 317 521 158 317 minecraft:brown_terracotta
setblock 525 151 298 minecraft:red_concrete
fill 525 151 317 525 158 317 minecraft:brown_terracotta
setblock 527 151 278 minecraft:light[level=12]
setblock 527 151 285 minecraft:light[level=12]
setblock 527 151 292 minecraft:light[level=12]
setblock 527 151 299 minecraft:light[level=12]
setblock 527 151 306 minecraft:light[level=12]
setblock 527 151 313 minecraft:light[level=12]
setblock 528 151 291 minecraft:red_concrete
setblock 528 151 305 minecraft:red_concrete
fill 529 151 275 529 158 275 minecraft:brown_terracotta
fill 533 151 275 533 158 275 minecraft:brown_terracotta
fill 533 151 317 533 158 317 minecraft:brown_terracotta
setblock 534 151 278 minecraft:light[level=12]
setblock 534 151 285 minecraft:light[level=12]
setblock 534 151 292 minecraft:light[level=12]
setblock 534 151 306 minecraft:light[level=12]
setblock 534 151 313 minecraft:light[level=12]
setblock 535 151 288 minecraft:red_concrete
setblock 535 151 308 minecraft:red_concrete
fill 537 151 317 537 158 317 minecraft:brown_terracotta
fill 541 151 275 541 158 275 minecraft:brown_terracotta
setblock 541 151 278 minecraft:light[level=12]
setblock 541 151 285 minecraft:light[level=12]
setblock 541 151 292 minecraft:light[level=12]
setblock 541 151 299 minecraft:light[level=12]
setblock 541 151 306 minecraft:light[level=12]
setblock 541 151 313 minecraft:light[level=12]
setblock 542 151 291 minecraft:red_concrete
setblock 542 151 305 minecraft:red_concrete
fill 545 151 275 545 158 275 minecraft:brown_terracotta
setblock 545 151 298 minecraft:red_concrete
fill 545 151 317 545 158 317 minecraft:brown_terracotta
setblock 548 151 278 minecraft:light[level=12]
fill 548 151 283 548 174 283 minecraft:white_concrete
setblock 548 151 284 minecraft:shroomlight
fill 548 151 285 548 174 285 minecraft:white_concrete
setblock 548 151 286 minecraft:shroomlight
fill 548 151 287 548 174 287 minecraft:white_concrete
setblock 548 151 288 minecraft:shroomlight
fill 548 151 289 548 174 289 minecraft:white_concrete
setblock 548 151 292 minecraft:light[level=12]
setblock 548 151 299 minecraft:light[level=12]
setblock 548 151 306 minecraft:light[level=12]
setblock 548 151 313 minecraft:light[level=12]
setblock 549 151 283 minecraft:shroomlight
fill 549 151 284 549 174 284 minecraft:white_concrete
setblock 549 151 285 minecraft:shroomlight
fill 549 151 286 549 174 286 minecraft:white_concrete
setblock 549 151 287 minecraft:shroomlight
fill 549 151 288 549 174 288 minecraft:white_concrete
setblock 549 151 289 minecraft:shroomlight
fill 549 151 317 549 158 317 minecraft:brown_terracotta
setblock 550 151 276 minecraft:shroomlight
fill 550 151 277 550 169 277 minecraft:white_concrete
setblock 550 151 278 minecraft:shroomlight
fill 550 151 279 550 169 279 minecraft:white_concrete
setblock 550 151 280 minecraft:shroomlight
fill 550 151 281 550 169 281 minecraft:white_concrete
setblock 550 151 282 minecraft:shroomlight
fill 550 151 283 550 174 283 minecraft:white_concrete
setblock 550 151 284 minecraft:shroomlight
fill 550 151 285 550 174 285 minecraft:white_concrete
setblock 550 151 286 minecraft:shroomlight
fill 550 151 287 550 174 287 minecraft:white_concrete
setblock 550 151 288 minecraft:shroomlight
fill 550 151 289 550 174 289 minecraft:white_concrete
fill 550 151 296 551 162 306 minecraft:white_concrete
fill 551 151 276 551 164 276 minecraft:white_concrete
setblock 551 151 277 minecraft:shroomlight
fill 551 151 278 551 169 278 minecraft:white_concrete
setblock 551 151 279 minecraft:shroomlight
fill 551 151 280 551 169 280 minecraft:white_concrete
setblock 551 151 281 minecraft:shroomlight
fill 551 151 282 551 169 282 minecraft:white_concrete
setblock 551 151 283 minecraft:shroomlight
fill 551 151 284 551 174 284 minecraft:white_concrete
setblock 551 151 285 minecraft:shroomlight
fill 551 151 286 551 174 286 minecraft:white_concrete
setblock 551 151 287 minecraft:shroomlight
fill 551 151 288 551 174 288 minecraft:white_concrete
setblock 551 151 289 minecraft:shroomlight
setblock 552 151 276 minecraft:shroomlight
fill 552 151 277 552 169 277 minecraft:white_concrete
setblock 552 151 278 minecraft:shroomlight
fill 552 151 279 552 169 279 minecraft:white_concrete
setblock 552 151 280 minecraft:shroomlight
fill 552 151 281 552 169 281 minecraft:white_concrete
setblock 552 151 282 minecraft:shroomlight
fill 552 151 283 552 174 283 minecraft:white_concrete
setblock 552 151 284 minecraft:shroomlight
fill 552 151 285 552 174 285 minecraft:white_concrete
setblock 552 151 286 minecraft:shroomlight
fill 552 151 287 552 174 287 minecraft:white_concrete
setblock 552 151 288 minecraft:shroomlight
fill 552 151 289 552 174 289 minecraft:white_concrete
setblock 552 151 294 minecraft:shroomlight
fill 552 151 295 552 161 295 minecraft:white_concrete
setblock 552 151 296 minecraft:shroomlight
fill 552 151 297 552 162 297 minecraft:white_concrete
setblock 552 151 298 minecraft:shroomlight
fill 552 151 299 552 162 299 minecraft:white_concrete
setblock 552 151 300 minecraft:shroomlight
fill 552 151 301 552 162 301 minecraft:white_concrete
setblock 552 151 302 minecraft:shroomlight
fill 552 151 303 552 162 303 minecraft:white_concrete
setblock 552 151 304 minecraft:shroomlight
fill 552 151 305 552 162 305 minecraft:white_concrete
setblock 552 151 306 minecraft:shroomlight
setblock 553 151 275 minecraft:shroomlight
fill 553 151 276 553 169 276 minecraft:white_concrete
setblock 553 151 277 minecraft:shroomlight
fill 553 151 278 553 169 278 minecraft:white_concrete
setblock 553 151 279 minecraft:shroomlight
fill 553 151 280 553 169 280 minecraft:white_concrete
setblock 553 151 281 minecraft:shroomlight
fill 553 151 282 553 169 282 minecraft:white_concrete
setblock 553 151 283 minecraft:shroomlight
fill 553 151 284 553 174 284 minecraft:white_concrete
setblock 553 151 285 minecraft:shroomlight
fill 553 151 286 553 174 286 minecraft:white_concrete
setblock 553 151 287 minecraft:shroomlight
fill 553 151 288 553 174 288 minecraft:white_concrete
setblock 553 151 289 minecraft:shroomlight
fill 553 151 294 553 161 294 minecraft:white_concrete
setblock 553 151 295 minecraft:shroomlight
fill 553 151 296 553 161 296 minecraft:white_concrete
setblock 553 151 297 minecraft:shroomlight
fill 553 151 298 553 161 298 minecraft:white_concrete
setblock 553 151 299 minecraft:shroomlight
fill 553 151 300 553 161 300 minecraft:white_concrete
setblock 553 151 301 minecraft:shroomlight
fill 553 151 302 553 161 302 minecraft:white_concrete
setblock 553 151 303 minecraft:shroomlight
fill 553 151 304 553 161 304 minecraft:white_concrete
setblock 553 151 305 minecraft:shroomlight
fill 553 151 306 553 162 306 minecraft:white_concrete
setblock 554 151 276 minecraft:shroomlight
fill 554 151 277 554 169 277 minecraft:white_concrete
setblock 554 151 278 minecraft:shroomlight
fill 554 151 279 554 169 279 minecraft:white_concrete
setblock 554 151 280 minecraft:shroomlight
fill 554 151 281 554 169 281 minecraft:white_concrete
setblock 554 151 282 minecraft:shroomlight
fill 554 151 283 554 174 283 minecraft:white_concrete
setblock 554 151 284 minecraft:shroomlight
fill 554 151 285 554 174 285 minecraft:white_concrete
setblock 554 151 286 minecraft:shroomlight
fill 554 151 287 554 174 287 minecraft:white_concrete
setblock 554 151 288 minecraft:shroomlight
fill 554 151 289 554 174 289 minecraft:white_concrete
setblock 554 151 294 minecraft:shroomlight
fill 554 151 295 554 161 295 minecraft:white_concrete
setblock 554 151 296 minecraft:shroomlight
fill 554 151 297 554 161 297 minecraft:white_concrete
setblock 554 151 298 minecraft:shroomlight
fill 554 151 299 554 161 299 minecraft:white_concrete
setblock 554 151 300 minecraft:shroomlight
fill 554 151 301 554 161 301 minecraft:white_concrete
setblock 554 151 302 minecraft:shroomlight
fill 554 151 303 554 161 303 minecraft:white_concrete
setblock 554 151 304 minecraft:shroomlight
fill 554 151 305 554 161 305 minecraft:white_concrete
setblock 554 151 306 minecraft:shroomlight
setblock 555 151 275 minecraft:shroomlight
fill 555 151 276 555 213 276 minecraft:white_concrete
setblock 555 151 277 minecraft:shroomlight
fill 555 151 278 555 169 278 minecraft:white_concrete
setblock 555 151 279 minecraft:shroomlight
fill 555 151 280 555 169 280 minecraft:white_concrete
setblock 555 151 281 minecraft:shroomlight
fill 555 151 282 555 169 282 minecraft:white_concrete
setblock 555 151 283 minecraft:shroomlight
fill 555 151 284 555 174 284 minecraft:white_concrete
setblock 555 151 285 minecraft:shroomlight
fill 555 151 286 555 174 286 minecraft:white_concrete
setblock 555 151 287 minecraft:shroomlight
fill 555 151 288 555 174 288 minecraft:white_concrete
setblock 555 151 289 minecraft:shroomlight
setblock 555 151 292 minecraft:light[level=12]
fill 555 151 294 555 161 294 minecraft:white_concrete
setblock 555 151 295 minecraft:shroomlight
fill 555 151 296 555 161 296 minecraft:white_concrete
setblock 555 151 297 minecraft:shroomlight
fill 555 151 298 555 161 298 minecraft:white_concrete
setblock 555 151 299 minecraft:shroomlight
fill 555 151 300 555 161 300 minecraft:white_concrete
setblock 555 151 301 minecraft:shroomlight
fill 555 151 302 555 161 302 minecraft:white_concrete
setblock 555 151 303 minecraft:shroomlight
fill 555 151 304 555 161 304 minecraft:white_concrete
setblock 555 151 305 minecraft:shroomlight
fill 555 151 306 555 162 306 minecraft:white_concrete
setblock 555 151 313 minecraft:light[level=12]
setblock 556 151 276 minecraft:shroomlight
fill 556 151 277 556 169 277 minecraft:white_concrete
setblock 556 151 278 minecraft:shroomlight
fill 556 151 279 556 169 279 minecraft:white_concrete
setblock 556 151 280 minecraft:shroomlight
fill 556 151 281 556 169 281 minecraft:white_concrete
setblock 556 151 282 minecraft:shroomlight
fill 556 151 283 556 174 283 minecraft:white_concrete
setblock 556 151 284 minecraft:shroomlight
fill 556 151 285 556 174 285 minecraft:white_concrete
setblock 556 151 286 minecraft:shroomlight
fill 556 151 287 556 174 287 minecraft:white_concrete
setblock 556 151 288 minecraft:shroomlight
fill 556 151 289 556 174 289 minecraft:white_concrete
setblock 556 151 294 minecraft:shroomlight
fill 556 151 295 556 161 295 minecraft:white_concrete
setblock 556 151 296 minecraft:shroomlight
fill 556 151 297 556 161 297 minecraft:white_concrete
setblock 556 151 298 minecraft:shroomlight
fill 556 151 299 556 161 299 minecraft:white_concrete
setblock 556 151 300 minecraft:shroomlight
fill 556 151 301 556 161 301 minecraft:white_concrete
setblock 556 151 302 minecraft:shroomlight
fill 556 151 303 556 161 303 minecraft:white_concrete
setblock 556 151 304 minecraft:shroomlight
fill 556 151 305 556 161 305 minecraft:white_concrete
setblock 556 151 306 minecraft:shroomlight
setblock 557 151 275 minecraft:shroomlight
fill 557 151 276 557 169 276 minecraft:white_concrete
setblock 557 151 277 minecraft:shroomlight
fill 557 151 278 557 169 278 minecraft:white_concrete
setblock 557 151 279 minecraft:shroomlight
fill 557 151 280 557 169 280 minecraft:white_concrete
setblock 557 151 281 minecraft:shroomlight
fill 557 151 282 557 169 282 minecraft:white_concrete
setblock 557 151 283 minecraft:shroomlight
fill 557 151 284 557 174 284 minecraft:white_concrete
setblock 557 151 285 minecraft:shroomlight
fill 557 151 286 557 174 286 minecraft:white_concrete
setblock 557 151 287 minecraft:shroomlight
fill 557 151 288 557 174 288 minecraft:white_concrete
setblock 557 151 289 minecraft:shroomlight
fill 557 151 294 557 161 294 minecraft:white_concrete
setblock 557 151 295 minecraft:shroomlight
fill 557 151 296 557 161 296 minecraft:white_concrete
setblock 557 151 297 minecraft:shroomlight
fill 557 151 298 557 165 298 minecraft:white_concrete
setblock 557 151 299 minecraft:shroomlight
fill 557 151 300 557 161 300 minecraft:white_concrete
setblock 557 151 301 minecraft:shroomlight
fill 557 151 302 557 161 302 minecraft:white_concrete
setblock 557 151 303 minecraft:shroomlight
fill 557 151 304 557 161 304 minecraft:white_concrete
setblock 557 151 305 minecraft:shroomlight
fill 557 151 306 557 162 306 minecraft:white_concrete
fill 557 151 317 557 158 317 minecraft:brown_terracotta
setblock 558 151 276 minecraft:shroomlight
fill 558 151 277 558 164 277 minecraft:white_concrete
setblock 558 151 278 minecraft:shroomlight
fill 558 151 279 558 164 279 minecraft:white_concrete
setblock 558 151 280 minecraft:shroomlight
fill 558 151 281 558 164 281 minecraft:white_concrete
setblock 558 151 282 minecraft:shroomlight
fill 558 151 283 558 174 283 minecraft:white_concrete
setblock 558 151 284 minecraft:shroomlight
fill 558 151 285 558 213 285 minecraft:white_concrete
setblock 558 151 286 minecraft:shroomlight
fill 558 151 287 558 174 287 minecraft:white_concrete
setblock 558 151 288 minecraft:shroomlight
fill 558 151 289 558 164 289 minecraft:white_concrete
setblock 558 151 294 minecraft:shroomlight
fill 558 151 295 558 161 295 minecraft:white_concrete
setblock 558 151 296 minecraft:shroomlight
fill 558 151 297 558 169 297 minecraft:white_concrete
setblock 558 151 298 minecraft:shroomlight
fill 558 151 299 558 162 299 minecraft:white_concrete
setblock 558 151 300 minecraft:shroomlight
fill 558 151 301 558 162 301 minecraft:white_concrete
setblock 558 151 302 minecraft:shroomlight
fill 558 151 303 558 162 303 minecraft:white_concrete
setblock 558 151 304 minecraft:shroomlight
fill 558 151 305 558 162 305 minecraft:white_concrete
setblock 558 151 306 minecraft:shroomlight
fill 559 151 275 559 156 275 minecraft:brown_terracotta
fill 559 151 283 559 158 283 minecraft:brown_terracotta
fill 559 151 287 559 158 287 minecraft:brown_terracotta
fill 559 151 295 559 158 295 minecraft:brown_terracotta
fill 559 151 299 559 158 299 minecraft:brown_terracotta
fill 559 151 307 559 158 307 minecraft:brown_terracotta
fill 559 151 311 559 158 311 minecraft:brown_terracotta
fill 517 152 281 517 156 281 minecraft:brown_terracotta
fill 517 152 282 517 152 283 minecraft:shroomlight
fill 517 152 284 517 157 284 minecraft:brown_terracotta
fill 517 152 293 517 156 293 minecraft:brown_terracotta
fill 517 152 294 517 152 295 minecraft:shroomlight
fill 517 152 296 517 157 296 minecraft:brown_terracotta
fill 517 152 305 517 156 305 minecraft:brown_terracotta
fill 517 152 306 517 152 307 minecraft:shroomlight
fill 517 152 308 517 157 308 minecraft:brown_terracotta
fill 517 152 317 517 156 317 minecraft:brown_terracotta
fill 518 152 317 519 152 317 minecraft:shroomlight
fill 520 152 317 520 157 317 minecraft:brown_terracotta
fill 524 152 275 524 157 275 minecraft:brown_terracotta
fill 525 152 275 526 152 275 minecraft:shroomlight
fill 527 152 275 527 156 275 minecraft:brown_terracotta
fill 529 152 317 529 158 317 minecraft:brown_terracotta
fill 530 152 317 531 152 317 minecraft:shroomlight
fill 532 152 317 532 157 317 minecraft:brown_terracotta
fill 536 152 275 536 157 275 minecraft:brown_terracotta
fill 537 152 275 538 152 275 minecraft:shroomlight
fill 539 152 275 539 156 275 minecraft:brown_terracotta
fill 541 152 317 541 158 317 minecraft:brown_terracotta
fill 542 152 317 543 152 317 minecraft:shroomlight
fill 544 152 317 544 157 317 minecraft:brown_terracotta
fill 548 152 275 548 157 275 minecraft:brown_terracotta
fill 548 152 284 548 153 284 minecraft:white_concrete
fill 548 152 286 548 153 286 minecraft:white_concrete
fill 548 152 288 548 153 288 minecraft:white_concrete
fill 549 152 275 550 152 275 minecraft:shroomlight
fill 549 152 283 549 153 283 minecraft:white_concrete
fill 549 152 285 549 153 285 minecraft:white_concrete
fill 549 152 287 549 153 287 minecraft:white_concrete
fill 549 152 289 549 153 289 minecraft:white_concrete
fill 550 152 276 550 153 276 minecraft:white_concrete
fill 550 152 278 550 153 278 minecraft:white_concrete
fill 550 152 280 550 153 280 minecraft:white_concrete
fill 550 152 282 550 153 282 minecraft:white_concrete
fill 550 152 284 550 153 284 minecraft:white_concrete
fill 550 152 286 550 153 286 minecraft:white_concrete
fill 550 152 288 550 153 288 minecraft:white_concrete
fill 551 152 275 551 153 275 minecraft:brown_terracotta
fill 551 152 277 551 153 277 minecraft:white_concrete
fill 551 152 279 551 153 279 minecraft:white_concrete
fill 551 152 281 551 153 281 minecraft:white_concrete
fill 551 152 283 551 153 283 minecraft:white_concrete
fill 551 152 285 551 153 285 minecraft:white_concrete
fill 551 152 287 551 153 287 minecraft:white_concrete
fill 551 152 289 551 153 289 minecraft:white_concrete
fill 552 152 276 552 153 276 minecraft:white_concrete
fill 552 152 278 552 153 278 minecraft:white_concrete
fill 552 152 280 552 153 280 minecraft:white_concrete
fill 552 152 282 552 153 282 minecraft:white_concrete
fill 552 152 284 552 153 284 minecraft:white_concrete
fill 552 152 286 552 153 286 minecraft:white_concrete
fill 552 152 288 552 153 288 minecraft:white_concrete
fill 552 152 294 552 153 294 minecraft:white_concrete
fill 552 152 296 552 153 296 minecraft:white_concrete
fill 552 152 298 552 153 298 minecraft:white_concrete
fill 552 152 300 552 153 300 minecraft:white_concrete
fill 552 152 302 552 153 302 minecraft:white_concrete
fill 552 152 304 552 153 304 minecraft:white_concrete
fill 552 152 306 552 153 306 minecraft:white_concrete
fill 553 152 275 553 153 275 minecraft:brown_terracotta
fill 553 152 277 553 153 277 minecraft:white_concrete
fill 553 152 279 553 153 279 minecraft:white_concrete
fill 553 152 281 553 153 281 minecraft:white_concrete
fill 553 152 283 553 153 283 minecraft:white_concrete
fill 553 152 285 553 153 285 minecraft:white_concrete
fill 553 152 287 553 153 287 minecraft:white_concrete
fill 553 152 289 553 153 289 minecraft:white_concrete
fill 553 152 295 553 153 295 minecraft:white_concrete
fill 553 152 297 553 153 297 minecraft:white_concrete
fill 553 152 299 553 153 299 minecraft:white_concrete
fill 553 152 301 553 153 301 minecraft:white_concrete
fill 553 152 303 553 153 303 minecraft:white_concrete
fill 553 152 305 553 153 305 minecraft:white_concrete
fill 553 152 317 553 158 317 minecraft:brown_terracotta
fill 554 152 276 554 153 276 minecraft:white_concrete
fill 554 152 278 554 153 278 minecraft:white_concrete
fill 554 152 280 554 153 280 minecraft:white_concrete
fill 554 152 282 554 153 282 minecraft:white_concrete
fill 554 152 284 554 153 284 minecraft:white_concrete
fill 554 152 286 554 153 286 minecraft:white_concrete
fill 554 152 288 554 153 288 minecraft:white_concrete
fill 554 152 294 554 153 294 minecraft:white_concrete
fill 554 152 296 554 153 296 minecraft:white_concrete
fill 554 152 298 554 153 298 minecraft:white_concrete
fill 554 152 300 554 153 300 minecraft:white_concrete
fill 554 152 302 554 153 302 minecraft:white_concrete
fill 554 152 304 554 153 304 minecraft:white_concrete
fill 554 152 306 554 153 306 minecraft:white_concrete
fill 554 152 317 555 152 317 minecraft:shroomlight
fill 555 152 275 555 153 275 minecraft:brown_terracotta
fill 555 152 277 555 153 277 minecraft:white_concrete
fill 555 152 279 555 153 279 minecraft:white_concrete
fill 555 152 281 555 153 281 minecraft:white_concrete
fill 555 152 283 555 153 283 minecraft:white_concrete
fill 555 152 285 555 153 285 minecraft:white_concrete
fill 555 152 287 555 153 287 minecraft:white_concrete
fill 555 152 289 555 153 289 minecraft:white_concrete
fill 555 152 295 555 153 295 minecraft:white_concrete
fill 555 152 297 555 153 297 minecraft:white_concrete
fill 555 152 299 555 153 299 minecraft:white_concrete
fill 555 152 301 555 153 301 minecraft:white_concrete
fill 555 152 303 555 153 303 minecraft:white_concrete
fill 555 152 305 555 153 305 minecraft:white_concrete
fill 556 152 276 556 153 276 minecraft:white_concrete
fill 556 152 278 556 153 278 minecraft:white_concrete
fill 556 152 280 556 153 280 minecraft:white_concrete
fill 556 152 282 556 153 282 minecraft:white_concrete
fill 556 152 284 556 153 284 minecraft:white_concrete
fill 556 152 286 556 153 286 minecraft:white_concrete
fill 556 152 288 556 153 288 minecraft:white_concrete
fill 556 152 294 556 153 294 minecraft:white_concrete
fill 556 152 296 556 153 296 minecraft:white_concrete
fill 556 152 298 556 153 298 minecraft:white_concrete
fill 556 152 300 556 153 300 minecraft:white_concrete
fill 556 152 302 556 153 302 minecraft:white_concrete
fill 556 152 304 556 153 304 minecraft:white_concrete
fill 556 152 306 556 153 306 minecraft:white_concrete
fill 556 152 317 556 157 317 minecraft:brown_terracotta
fill 557 152 275 557 153 275 minecraft:brown_terracotta
fill 557 152 277 557 153 277 minecraft:white_concrete
fill 557 152 279 557 153 279 minecraft:white_concrete
fill 557 152 281 557 153 281 minecraft:white_concrete
fill 557 152 283 557 153 283 minecraft:white_concrete
fill 557 152 285 557 153 285 minecraft:white_concrete
fill 557 152 287 557 153 287 minecraft:white_concrete
fill 557 152 289 557 153 289 minecraft:white_concrete
fill 557 152 295 557 153 295 minecraft:white_concrete
fill 557 152 297 557 153 297 minecraft:white_concrete
fill 557 152 299 557 153 299 minecraft:white_concrete
fill 557 152 301 557 153 301 minecraft:white_concrete
fill 557 152 303 557 153 303 minecraft:white_concrete
fill 557 152 305 557 153 305 minecraft:white_concrete
fill 558 152 276 558 153 276 minecraft:white_concrete
fill 558 152 278 558 153 278 minecraft:white_concrete
fill 558 152 280 558 153 280 minecraft:white_concrete
fill 558 152 282 558 153 282 minecraft:white_concrete
fill 558 152 284 558 153 284 minecraft:white_concrete
fill 558 152 286 558 153 286 minecraft:white_concrete
fill 558 152 288 558 153 288 minecraft:white_concrete
fill 558 152 294 558 153 294 minecraft:white_concrete
fill 558 152 296 558 153 296 minecraft:white_concrete
fill 558 152 298 558 153 298 minecraft:white_concrete
fill 558 152 300 558 153 300 minecraft:white_concrete
fill 558 152 302 558 153 302 minecraft:white_concrete
fill 558 152 304 558 153 304 minecraft:white_concrete
fill 558 152 306 558 153 306 minecraft:white_concrete
fill 559 152 276 559 157 276 minecraft:brown_terracotta
fill 559 152 277 559 152 278 minecraft:shroomlight
fill 559 152 279 559 158 279 minecraft:brown_terracotta
fill 559 152 288 559 157 288 minecraft:brown_terracotta
fill 559 152 289 559 152 290 minecraft:shroomlight
fill 559 152 291 559 158 291 minecraft:brown_terracotta
fill 559 152 300 559 157 300 minecraft:brown_terracotta
fill 559 152 301 559 152 302 minecraft:shroomlight
fill 559 152 303 559 158 303 minecraft:brown_terracotta
fill 559 152 312 559 157 312 minecraft:brown_terracotta
fill 559 152 313 559 152 314 minecraft:shroomlight
fill 559 152 315 559 158 315 minecraft:brown_terracotta
fill 517 153 282 517 157 283 minecraft:brown_terracotta
fill 517 153 294 517 157 295 minecraft:brown_terracotta
fill 517 153 306 517 157 307 minecraft:brown_terracotta
fill 518 153 317 519 156 317 minecraft:brown_terracotta
fill 525 153 275 526 157 275 minecraft:brown_terracotta
fill 530 153 317 531 156 317 minecraft:brown_terracotta
fill 537 153 275 538 157 275 minecraft:brown_terracotta
fill 539 153 286 540 154 286 minecraft:white_concrete
fill 542 153 317 543 156 317 minecraft:brown_terracotta
fill 549 153 275 550 157 275 minecraft:brown_terracotta
fill 554 153 317 555 156 317 minecraft:brown_terracotta
fill 556 153 292 556 164 293 minecraft:red_wool
fill 559 153 277 559 156 278 minecraft:brown_terracotta
fill 559 153 289 559 156 290 minecraft:brown_terracotta
fill 559 153 301 559 156 302 minecraft:brown_terracotta
fill 559 153 313 559 156 314 minecraft:brown_terracotta
setblock 548 154 284 minecraft:shroomlight
setblock 548 154 286 minecraft:shroomlight
setblock 548 154 288 minecraft:shroomlight
setblock 549 154 283 minecraft:shroomlight
setblock 549 154 285 minecraft:shroomlight
setblock 549 154 287 minecraft:shroomlight
setblock 549 154 289 minecraft:shroomlight
setblock 550 154 276 minecraft:shroomlight
setblock 550 154 278 minecraft:shroomlight
setblock 550 154 280 minecraft:shroomlight
setblock 550 154 282 minecraft:shroomlight
setblock 550 154 284 minecraft:shroomlight
setblock 550 154 286 minecraft:shroomlight
setblock 550 154 288 minecraft:shroomlight
setblock 551 154 275 minecraft:shroomlight
setblock 551 154 277 minecraft:shroomlight
setblock 551 154 279 minecraft:shroomlight
setblock 551 154 281 minecraft:shroomlight
setblock 551 154 283 minecraft:shroomlight
setblock 551 154 285 minecraft:shroomlight
setblock 551 154 287 minecraft:shroomlight
setblock 551 154 289 minecraft:shroomlight
setblock 552 154 276 minecraft:shroomlight
setblock 552 154 278 minecraft:shroomlight
setblock 552 154 280 minecraft:shroomlight
setblock 552 154 282 minecraft:shroomlight
setblock 552 154 284 minecraft:shroomlight
setblock 552 154 286 minecraft:shroomlight
setblock 552 154 288 minecraft:shroomlight
setblock 552 154 294 minecraft:shroomlight
setblock 552 154 296 minecraft:shroomlight
setblock 552 154 298 minecraft:shroomlight
setblock 552 154 300 minecraft:shroomlight
setblock 552 154 302 minecraft:shroomlight
setblock 552 154 304 minecraft:shroomlight
setblock 552 154 306 minecraft:shroomlight
setblock 553 154 275 minecraft:shroomlight
setblock 553 154 277 minecraft:shroomlight
setblock 553 154 279 minecraft:shroomlight
setblock 553 154 281 minecraft:shroomlight
setblock 553 154 283 minecraft:shroomlight
setblock 553 154 285 minecraft:shroomlight
setblock 553 154 287 minecraft:shroomlight
setblock 553 154 289 minecraft:shroomlight
setblock 553 154 295 minecraft:shroomlight
setblock 553 154 297 minecraft:shroomlight
setblock 553 154 299 minecraft:shroomlight
setblock 553 154 301 minecraft:shroomlight
setblock 553 154 303 minecraft:shroomlight
setblock 553 154 305 minecraft:shroomlight
setblock 554 154 276 minecraft:shroomlight
setblock 554 154 278 minecraft:shroomlight
setblock 554 154 280 minecraft:shroomlight
setblock 554 154 282 minecraft:shroomlight
setblock 554 154 284 minecraft:shroomlight
setblock 554 154 286 minecraft:shroomlight
setblock 554 154 288 minecraft:shroomlight
setblock 554 154 294 minecraft:shroomlight
setblock 554 154 296 minecraft:shroomlight
setblock 554 154 298 minecraft:shroomlight
setblock 554 154 300 minecraft:shroomlight
setblock 554 154 302 minecraft:shroomlight
setblock 554 154 304 minecraft:shroomlight
setblock 554 154 306 minecraft:shroomlight
setblock 555 154 275 minecraft:shroomlight
setblock 555 154 277 minecraft:shroomlight
setblock 555 154 279 minecraft:shroomlight
setblock 555 154 281 minecraft:shroomlight
setblock 555 154 283 minecraft:shroomlight
setblock 555 154 285 minecraft:shroomlight
setblock 555 154 287 minecraft:shroomlight
setblock 555 154 289 minecraft:shroomlight
setblock 555 154 295 minecraft:shroomlight
setblock 555 154 297 minecraft:shroomlight
setblock 555 154 299 minecraft:shroomlight
setblock 555 154 301 minecraft:shroomlight
setblock 555 154 303 minecraft:shroomlight
setblock 555 154 305 minecraft:shroomlight
setblock 556 154 276 minecraft:shroomlight
setblock 556 154 278 minecraft:shroomlight
setblock 556 154 280 minecraft:shroomlight
setblock 556 154 282 minecraft:shroomlight
setblock 556 154 284 minecraft:shroomlight
setblock 556 154 286 minecraft:shroomlight
setblock 556 154 288 minecraft:shroomlight
setblock 556 154 294 minecraft:shroomlight
setblock 556 154 296 minecraft:shroomlight
setblock 556 154 298 minecraft:shroomlight
setblock 556 154 300 minecraft:shroomlight
setblock 556 154 302 minecraft:shroomlight
setblock 556 154 304 minecraft:shroomlight
setblock 556 154 306 minecraft:shroomlight
setblock 557 154 275 minecraft:shroomlight
setblock 557 154 277 minecraft:shroomlight
setblock 557 154 279 minecraft:shroomlight
setblock 557 154 281 minecraft:shroomlight
setblock 557 154 283 minecraft:shroomlight
setblock 557 154 285 minecraft:shroomlight
setblock 557 154 287 minecraft:shroomlight
setblock 557 154 289 minecraft:shroomlight
setblock 557 154 295 minecraft:shroomlight
setblock 557 154 297 minecraft:shroomlight
setblock 557 154 299 minecraft:shroomlight
setblock 557 154 301 minecraft:shroomlight
setblock 557 154 303 minecraft:shroomlight
setblock 557 154 305 minecraft:shroomlight
setblock 558 154 276 minecraft:shroomlight
setblock 558 154 278 minecraft:shroomlight
setblock 558 154 280 minecraft:shroomlight
setblock 558 154 282 minecraft:shroomlight
setblock 558 154 284 minecraft:shroomlight
setblock 558 154 286 minecraft:shroomlight
setblock 558 154 288 minecraft:shroomlight
setblock 558 154 294 minecraft:shroomlight
setblock 558 154 296 minecraft:shroomlight
setblock 558 154 298 minecraft:shroomlight
setblock 558 154 300 minecraft:shroomlight
setblock 558 154 302 minecraft:shroomlight
setblock 558 154 304 minecraft:shroomlight
setblock 558 154 306 minecraft:shroomlight
fill 548 155 284 548 156 284 minecraft:white_concrete
fill 548 155 286 548 156 286 minecraft:white_concrete
fill 548 155 288 548 156 288 minecraft:white_concrete
fill 549 155 283 549 156 283 minecraft:white_concrete
fill 549 155 285 549 156 285 minecraft:white_concrete
fill 549 155 287 549 156 287 minecraft:white_concrete
fill 549 155 289 549 156 289 minecraft:white_concrete
fill 550 155 276 550 156 276 minecraft:white_concrete
fill 550 155 278 550 156 278 minecraft:white_concrete
fill 550 155 280 550 156 280 minecraft:white_concrete
fill 550 155 282 550 156 282 minecraft:white_concrete
fill 550 155 284 550 156 284 minecraft:white_concrete
fill 550 155 286 550 156 286 minecraft:white_concrete
fill 550 155 288 550 156 288 minecraft:white_concrete
fill 551 155 275 551 156 275 minecraft:brown_terracotta
fill 551 155 277 551 156 277 minecraft:white_concrete
fill 551 155 279 551 156 279 minecraft:white_concrete
fill 551 155 281 551 156 281 minecraft:white_concrete
fill 551 155 283 551 156 283 minecraft:white_concrete
fill 551 155 285 551 156 285 minecraft:white_concrete
fill 551 155 287 551 156 287 minecraft:white_concrete
fill 551 155 289 551 156 289 minecraft:white_concrete
fill 552 155 276 552 156 276 minecraft:white_concrete
fill 552 155 278 552 156 278 minecraft:white_concrete
fill 552 155 280 552 156 280 minecraft:white_concrete
fill 552 155 282 552 156 282 minecraft:white_concrete
fill 552 155 284 552 156 284 minecraft:white_concrete
fill 552 155 286 552 156 286 minecraft:white_concrete
fill 552 155 288 552 156 288 minecraft:white_concrete
fill 552 155 294 552 156 294 minecraft:white_concrete
fill 552 155 296 552 156 296 minecraft:white_concrete
fill 552 155 298 552 156 298 minecraft:white_concrete
fill 552 155 300 552 156 300 minecraft:white_concrete
fill 552 155 302 552 156 302 minecraft:white_concrete
fill 552 155 304 552 156 304 minecraft:white_concrete
fill 552 155 306 552 156 306 minecraft:white_concrete
fill 553 155 275 553 156 275 minecraft:brown_terracotta
fill 553 155 277 553 156 277 minecraft:white_concrete
fill 553 155 279 553 156 279 minecraft:white_concrete
fill 553 155 281 553 156 281 minecraft:white_concrete
fill 553 155 283 553 156 283 minecraft:white_concrete
fill 553 155 285 553 156 285 minecraft:white_concrete
fill 553 155 287 553 156 287 minecraft:white_concrete
fill 553 155 289 553 156 289 minecraft:white_concrete
fill 553 155 295 553 156 295 minecraft:white_concrete
fill 553 155 297 553 156 297 minecraft:white_concrete
fill 553 155 299 553 156 299 minecraft:white_concrete
fill 553 155 301 553 156 301 minecraft:white_concrete
fill 553 155 303 553 156 303 minecraft:white_concrete
fill 553 155 305 553 156 305 minecraft:white_concrete
fill 554 155 276 554 156 276 minecraft:white_concrete
fill 554 155 278 554 156 278 minecraft:white_concrete
fill 554 155 280 554 156 280 minecraft:white_concrete
fill 554 155 282 554 156 282 minecraft:white_concrete
fill 554 155 284 554 156 284 minecraft:white_concrete
fill 554 155 286 554 156 286 minecraft:white_concrete
fill 554 155 288 554 156 288 minecraft:white_concrete
fill 554 155 294 554 156 294 minecraft:white_concrete
fill 554 155 296 554 156 296 minecraft:white_concrete
fill 554 155 298 554 156 298 minecraft:white_concrete
fill 554 155 300 554 156 300 minecraft:white_concrete
fill 554 155 302 554 156 302 minecraft:white_concrete
fill 554 155 304 554 156 304 minecraft:white_concrete
fill 554 155 306 554 156 306 minecraft:white_concrete
fill 555 155 275 555 156 275 minecraft:brown_terracotta
fill 555 155 277 555 156 277 minecraft:white_concrete
fill 555 155 279 555 156 279 minecraft:white_concrete
fill 555 155 281 555 156 281 minecraft:white_concrete
fill 555 155 283 555 156 283 minecraft:white_concrete
fill 555 155 285 555 156 285 minecraft:white_concrete
fill 555 155 287 555 156 287 minecraft:white_concrete
fill 555 155 289 555 156 289 minecraft:white_concrete
fill 555 155 295 555 156 295 minecraft:white_concrete
fill 555 155 297 555 156 297 minecraft:white_concrete
fill 555 155 299 555 156 299 minecraft:white_concrete
fill 555 155 301 555 156 301 minecraft:white_concrete
fill 555 155 303 555 156 303 minecraft:white_concrete
fill 555 155 305 555 156 305 minecraft:white_concrete
fill 556 155 276 556 156 276 minecraft:white_concrete
fill 556 155 278 556 156 278 minecraft:white_concrete
fill 556 155 280 556 156 280 minecraft:white_concrete
fill 556 155 282 556 156 282 minecraft:white_concrete
fill 556 155 284 556 156 284 minecraft:white_concrete
fill 556 155 286 556 156 286 minecraft:white_concrete
fill 556 155 288 556 156 288 minecraft:white_concrete
fill 556 155 294 556 156 294 minecraft:white_concrete
fill 556 155 296 556 156 296 minecraft:white_concrete
fill 556 155 298 556 156 298 minecraft:white_concrete
fill 556 155 300 556 156 300 minecraft:white_concrete
fill 556 155 302 556 156 302 minecraft:white_concrete
fill 556 155 304 556 156 304 minecraft:white_concrete
fill 556 155 306 556 156 306 minecraft:white_concrete
fill 557 155 275 557 156 275 minecraft:brown_terracotta
fill 557 155 277 557 156 277 minecraft:white_concrete
fill 557 155 279 557 156 279 minecraft:white_concrete
fill 557 155 281 557 156 281 minecraft:white_concrete
fill 557 155 283 557 156 283 minecraft:white_concrete
fill 557 155 285 557 156 285 minecraft:white_concrete
fill 557 155 287 557 156 287 minecraft:white_concrete
fill 557 155 289 557 156 289 minecraft:white_concrete
fill 557 155 295 557 156 295 minecraft:white_concrete
fill 557 155 297 557 156 297 minecraft:white_concrete
fill 557 155 299 557 156 299 minecraft:white_concrete
fill 557 155 301 557 156 301 minecraft:white_concrete
fill 557 155 303 557 156 303 minecraft:white_concrete
fill 557 155 305 557 156 305 minecraft:white_concrete
fill 558 155 276 558 156 276 minecraft:white_concrete
fill 558 155 278 558 156 278 minecraft:white_concrete
fill 558 155 280 558 156 280 minecraft:white_concrete
fill 558 155 282 558 156 282 minecraft:white_concrete
fill 558 155 284 558 156 284 minecraft:white_concrete
fill 558 155 286 558 156 286 minecraft:white_concrete
fill 558 155 288 558 156 288 minecraft:white_concrete
fill 558 155 294 558 156 294 minecraft:white_concrete
fill 558 155 296 558 156 296 minecraft:white_concrete
fill 558 155 298 558 156 298 minecraft:white_concrete
fill 558 155 300 558 156 300 minecraft:white_concrete
fill 558 155 302 558 156 302 minecraft:white_concrete
fill 558 155 304 558 156 304 minecraft:white_concrete
fill 558 155 306 558 156 306 minecraft:white_concrete
setblock 517 157 277 minecraft:white_concrete
setblock 517 157 281 minecraft:white_concrete
setblock 517 157 285 minecraft:white_concrete
setblock 517 157 289 minecraft:white_concrete
setblock 517 157 293 minecraft:white_concrete
setblock 517 157 297 minecraft:white_concrete
setblock 517 157 301 minecraft:white_concrete
setblock 517 157 305 minecraft:white_concrete
setblock 517 157 309 minecraft:white_concrete
setblock 517 157 313 minecraft:white_concrete
setblock 517 157 317 minecraft:white_concrete
setblock 518 157 317 minecraft:brown_terracotta
setblock 519 157 275 minecraft:white_concrete
setblock 519 157 317 minecraft:white_concrete
setblock 520 157 278 minecraft:light[level=15]
setblock 520 157 285 minecraft:light[level=12]
setblock 520 157 286 minecraft:light[level=15]
setblock 520 157 292 minecraft:light[level=12]
setblock 520 157 294 minecraft:light[level=15]
setblock 520 157 299 minecraft:light[level=12]
setblock 520 157 302 minecraft:light[level=15]
setblock 520 157 306 minecraft:light[level=12]
setblock 520 157 310 minecraft:light[level=15]
setblock 520 157 313 minecraft:light[level=12]
setblock 523 157 275 minecraft:white_concrete
setblock 523 157 317 minecraft:white_concrete
setblock 527 157 275 minecraft:white_concrete
setblock 527 157 278 minecraft:light[level=12]
setblock 527 157 285 minecraft:light[level=12]
setblock 527 157 292 minecraft:light[level=12]
setblock 527 157 299 minecraft:light[level=12]
setblock 527 157 306 minecraft:light[level=12]
setblock 527 157 313 minecraft:light[level=12]
setblock 527 157 317 minecraft:white_concrete
setblock 528 157 278 minecraft:light[level=15]
setblock 528 157 286 minecraft:light[level=15]
setblock 528 157 294 minecraft:light[level=15]
setblock 528 157 302 minecraft:light[level=15]
setblock 528 157 310 minecraft:light[level=15]
setblock 530 157 317 minecraft:brown_terracotta
setblock 531 157 275 minecraft:white_concrete
setblock 531 157 317 minecraft:white_concrete
setblock 534 157 278 minecraft:light[level=12]
setblock 534 157 285 minecraft:light[level=12]
setblock 534 157 292 minecraft:light[level=12]
setblock 534 157 306 minecraft:light[level=12]
setblock 534 157 313 minecraft:light[level=12]
setblock 535 157 275 minecraft:white_concrete
setblock 535 157 317 minecraft:white_concrete
setblock 536 157 278 minecraft:light[level=15]
setblock 536 157 286 minecraft:light[level=15]
setblock 536 157 294 minecraft:light[level=15]
setblock 536 157 302 minecraft:light[level=15]
setblock 536 157 310 minecraft:light[level=15]
setblock 539 157 275 minecraft:white_concrete
setblock 539 157 317 minecraft:white_concrete
setblock 541 157 278 minecraft:light[level=12]
setblock 541 157 285 minecraft:light[level=12]
setblock 541 157 292 minecraft:light[level=12]
setblock 541 157 299 minecraft:light[level=12]
setblock 541 157 306 minecraft:light[level=12]
setblock 541 157 313 minecraft:light[level=12]
setblock 542 157 317 minecraft:brown_terracotta
setblock 543 157 275 minecraft:white_concrete
setblock 543 157 317 minecraft:white_concrete
setblock 544 157 278 minecraft:light[level=15]
setblock 544 157 286 minecraft:light[level=15]
setblock 544 157 294 minecraft:light[level=15]
setblock 544 157 302 minecraft:light[level=15]
setblock 544 157 310 minecraft:light[level=15]
setblock 547 157 275 minecraft:white_concrete
setblock 547 157 317 minecraft:white_concrete
setblock 548 157 278 minecraft:light[level=12]
setblock 548 157 284 minecraft:shroomlight
setblock 548 157 286 minecraft:shroomlight
setblock 548 157 288 minecraft:shroomlight
setblock 548 157 292 minecraft:light[level=12]
setblock 548 157 299 minecraft:light[level=12]
setblock 548 157 306 minecraft:light[level=12]
setblock 548 157 313 minecraft:light[level=12]
setblock 549 157 283 minecraft:shroomlight
setblock 549 157 285 minecraft:shroomlight
setblock 549 157 287 minecraft:shroomlight
setblock 549 157 289 minecraft:shroomlight
setblock 550 157 276 minecraft:shroomlight
setblock 550 157 278 minecraft:shroomlight
setblock 550 157 280 minecraft:shroomlight
setblock 550 157 282 minecraft:shroomlight
setblock 550 157 284 minecraft:shroomlight
setblock 550 157 286 minecraft:shroomlight
setblock 550 157 288 minecraft:shroomlight
setblock 551 157 275 minecraft:shroomlight
setblock 551 157 277 minecraft:shroomlight
setblock 551 157 279 minecraft:shroomlight
setblock 551 157 281 minecraft:shroomlight
setblock 551 157 283 minecraft:shroomlight
setblock 551 157 285 minecraft:shroomlight
setblock 551 157 287 minecraft:shroomlight
setblock 551 157 289 minecraft:shroomlight
setblock 551 157 317 minecraft:white_concrete
setblock 552 157 276 minecraft:shroomlight
setblock 552 157 278 minecraft:shroomlight
setblock 552 157 280 minecraft:shroomlight
setblock 552 157 282 minecraft:shroomlight
setblock 552 157 284 minecraft:shroomlight
setblock 552 157 286 minecraft:shroomlight
setblock 552 157 288 minecraft:shroomlight
setblock 552 157 294 minecraft:shroomlight
setblock 552 157 296 minecraft:shroomlight
setblock 552 157 298 minecraft:shroomlight
setblock 552 157 300 minecraft:shroomlight
setblock 552 157 302 minecraft:shroomlight
setblock 552 157 304 minecraft:shroomlight
setblock 552 157 306 minecraft:shroomlight
setblock 552 157 310 minecraft:light[level=15]
setblock 553 157 275 minecraft:shroomlight
setblock 553 157 277 minecraft:shroomlight
setblock 553 157 279 minecraft:shroomlight
setblock 553 157 281 minecraft:shroomlight
setblock 553 157 283 minecraft:shroomlight
setblock 553 157 285 minecraft:shroomlight
setblock 553 157 287 minecraft:shroomlight
setblock 553 157 289 minecraft:shroomlight
setblock 553 157 295 minecraft:shroomlight
setblock 553 157 297 minecraft:shroomlight
setblock 553 157 299 minecraft:shroomlight
setblock 553 157 301 minecraft:shroomlight
setblock 553 157 303 minecraft:shroomlight
setblock 553 157 305 minecraft:shroomlight
setblock 554 157 276 minecraft:shroomlight
setblock 554 157 278 minecraft:shroomlight
setblock 554 157 280 minecraft:shroomlight
setblock 554 157 282 minecraft:shroomlight
setblock 554 157 284 minecraft:shroomlight
setblock 554 157 286 minecraft:shroomlight
setblock 554 157 288 minecraft:shroomlight
setblock 554 157 294 minecraft:shroomlight
setblock 554 157 296 minecraft:shroomlight
setblock 554 157 298 minecraft:shroomlight
setblock 554 157 300 minecraft:shroomlight
setblock 554 157 302 minecraft:shroomlight
setblock 554 157 304 minecraft:shroomlight
setblock 554 157 306 minecraft:shroomlight
setblock 554 157 317 minecraft:brown_terracotta
setblock 555 157 275 minecraft:shroomlight
setblock 555 157 277 minecraft:shroomlight
setblock 555 157 279 minecraft:shroomlight
setblock 555 157 281 minecraft:shroomlight
setblock 555 157 283 minecraft:shroomlight
setblock 555 157 285 minecraft:shroomlight
setblock 555 157 287 minecraft:shroomlight
setblock 555 157 289 minecraft:shroomlight
setblock 555 157 292 minecraft:light[level=12]
setblock 555 157 295 minecraft:shroomlight
setblock 555 157 297 minecraft:shroomlight
setblock 555 157 299 minecraft:shroomlight
setblock 555 157 301 minecraft:shroomlight
setblock 555 157 303 minecraft:shroomlight
setblock 555 157 305 minecraft:shroomlight
setblock 555 157 313 minecraft:light[level=12]
setblock 555 157 317 minecraft:white_concrete
setblock 556 157 276 minecraft:shroomlight
setblock 556 157 278 minecraft:shroomlight
setblock 556 157 280 minecraft:shroomlight
setblock 556 157 282 minecraft:shroomlight
setblock 556 157 284 minecraft:shroomlight
setblock 556 157 286 minecraft:shroomlight
setblock 556 157 288 minecraft:shroomlight
setblock 556 157 294 minecraft:shroomlight
setblock 556 157 296 minecraft:shroomlight
setblock 556 157 298 minecraft:shroomlight
setblock 556 157 300 minecraft:shroomlight
setblock 556 157 302 minecraft:shroomlight
setblock 556 157 304 minecraft:shroomlight
setblock 556 157 306 minecraft:shroomlight
setblock 557 157 275 minecraft:shroomlight
setblock 557 157 277 minecraft:shroomlight
setblock 557 157 279 minecraft:shroomlight
setblock 557 157 281 minecraft:shroomlight
setblock 557 157 283 minecraft:shroomlight
setblock 557 157 285 minecraft:shroomlight
setblock 557 157 287 minecraft:shroomlight
setblock 557 157 289 minecraft:shroomlight
setblock 557 157 295 minecraft:shroomlight
setblock 557 157 297 minecraft:shroomlight
setblock 557 157 299 minecraft:shroomlight
setblock 557 157 301 minecraft:shroomlight
setblock 557 157 303 minecraft:shroomlight
setblock 557 157 305 minecraft:shroomlight
setblock 558 157 276 minecraft:shroomlight
setblock 558 157 278 minecraft:shroomlight
setblock 558 157 280 minecraft:shroomlight
setblock 558 157 282 minecraft:shroomlight
setblock 558 157 284 minecraft:shroomlight
setblock 558 157 286 minecraft:shroomlight
setblock 558 157 288 minecraft:shroomlight
setblock 558 157 294 minecraft:shroomlight
setblock 558 157 296 minecraft:shroomlight
setblock 558 157 298 minecraft:shroomlight
setblock 558 157 300 minecraft:shroomlight
setblock 558 157 302 minecraft:shroomlight
setblock 558 157 304 minecraft:shroomlight
setblock 558 157 306 minecraft:shroomlight
setblock 559 157 275 minecraft:white_concrete
setblock 559 157 277 minecraft:white_concrete
setblock 559 157 278 minecraft:brown_terracotta
setblock 559 157 281 minecraft:white_concrete
setblock 559 157 285 minecraft:white_concrete
setblock 559 157 289 minecraft:white_concrete
setblock 559 157 290 minecraft:brown_terracotta
setblock 559 157 293 minecraft:white_concrete
setblock 559 157 297 minecraft:white_concrete
setblock 559 157 301 minecraft:white_concrete
setblock 559 157 302 minecraft:brown_terracotta
setblock 559 157 305 minecraft:white_concrete
setblock 559 157 309 minecraft:white_concrete
setblock 559 157 313 minecraft:white_concrete
setblock 559 157 314 minecraft:brown_terracotta
setblock 559 157 317 minecraft:white_concrete
setblock 517 158 276 minecraft:white_concrete
fill 517 158 277 517 165 277 minecraft:brown_terracotta
setblock 517 158 278 minecraft:white_concrete
setblock 517 158 280 minecraft:white_concrete
fill 517 158 281 517 165 281 minecraft:brown_terracotta
setblock 517 158 282 minecraft:white_concrete
setblock 517 158 283 minecraft:brown_terracotta
setblock 517 158 284 minecraft:white_concrete
fill 517 158 285 517 165 285 minecraft:brown_terracotta
setblock 517 158 286 minecraft:white_concrete
setblock 517 158 288 minecraft:white_concrete
fill 517 158 289 517 165 289 minecraft:brown_terracotta
setblock 517 158 290 minecraft:white_concrete
setblock 517 158 292 minecraft:white_concrete
fill 517 158 293 517 165 293 minecraft:brown_terracotta
setblock 517 158 294 minecraft:white_concrete
setblock 517 158 295 minecraft:brown_terracotta
setblock 517 158 296 minecraft:white_concrete
fill 517 158 297 517 165 297 minecraft:brown_terracotta
setblock 517 158 298 minecraft:white_concrete
setblock 517 158 300 minecraft:white_concrete
fill 517 158 301 517 165 301 minecraft:brown_terracotta
setblock 517 158 302 minecraft:white_concrete
setblock 517 158 304 minecraft:white_concrete
fill 517 158 305 517 165 305 minecraft:brown_terracotta
setblock 517 158 306 minecraft:white_concrete
setblock 517 158 307 minecraft:brown_terracotta
setblock 517 158 308 minecraft:white_concrete
fill 517 158 309 517 165 309 minecraft:brown_terracotta
setblock 517 158 310 minecraft:white_concrete
setblock 517 158 312 minecraft:white_concrete
fill 517 158 313 517 165 313 minecraft:brown_terracotta
setblock 517 158 314 minecraft:white_concrete
setblock 517 158 316 minecraft:white_concrete
setblock 517 158 317 minecraft:brown_terracotta
setblock 518 158 275 minecraft:white_concrete
setblock 518 158 317 minecraft:white_concrete
fill 519 158 275 519 165 275 minecraft:brown_terracotta
fill 519 158 279 519 158 281 minecraft:brown_terracotta
fill 519 158 317 519 165 317 minecraft:brown_terracotta
setblock 520 158 275 minecraft:white_concrete
fill 520 158 278 522 158 278 minecraft:brown_terracotta
fill 520 158 282 522 158 282 minecraft:brown_terracotta
setblock 520 158 317 minecraft:white_concrete
setblock 522 158 275 minecraft:white_concrete
setblock 522 158 317 minecraft:white_concrete
fill 523 158 275 523 165 275 minecraft:brown_terracotta
fill 523 158 279 523 158 281 minecraft:brown_terracotta
fill 523 158 317 523 165 317 minecraft:brown_terracotta
setblock 524 158 275 minecraft:white_concrete
setblock 524 158 317 minecraft:white_concrete
setblock 525 158 275 minecraft:brown_terracotta
setblock 526 158 275 minecraft:white_concrete
setblock 526 158 317 minecraft:white_concrete
fill 527 158 275 527 165 275 minecraft:brown_terracotta
fill 527 158 317 527 165 317 minecraft:brown_terracotta
setblock 528 158 275 minecraft:white_concrete
fill 528 158 288 528 159 289 minecraft:white_concrete
setblock 528 158 317 minecraft:white_concrete
setblock 530 158 275 minecraft:white_concrete
setblock 530 158 317 minecraft:white_concrete
fill 531 158 275 531 165 275 minecraft:brown_terracotta
fill 531 158 317 531 165 317 minecraft:brown_terracotta
setblock 532 158 275 minecraft:white_concrete
setblock 532 158 317 minecraft:white_concrete
setblock 534 158 275 minecraft:white_concrete
setblock 534 158 317 minecraft:white_concrete
fill 535 158 275 535 165 275 minecraft:brown_terracotta
fill 535 158 317 535 165 317 minecraft:brown_terracotta
setblock 536 158 275 minecraft:white_concrete
setblock 536 158 317 minecraft:white_concrete
setblock 537 158 275 minecraft:brown_terracotta
setblock 538 158 275 minecraft:white_concrete
setblock 538 158 317 minecraft:white_concrete
fill 539 158 275 539 165 275 minecraft:brown_terracotta
fill 539 158 317 539 165 317 minecraft:brown_terracotta
setblock 540 158 275 minecraft:white_concrete
setblock 540 158 317 minecraft:white_concrete
setblock 542 158 275 minecraft:white_concrete
setblock 542 158 317 minecraft:white_concrete
fill 543 158 275 543 165 275 minecraft:brown_terracotta
fill 543 158 317 543 165 317 minecraft:brown_terracotta
setblock 544 158 275 minecraft:white_concrete
setblock 544 158 317 minecraft:white_concrete
setblock 546 158 275 minecraft:white_concrete
setblock 546 158 317 minecraft:white_concrete
fill 547 158 275 547 165 275 minecraft:brown_terracotta
fill 547 158 317 547 165 317 minecraft:brown_terracotta
setblock 548 158 275 minecraft:white_concrete
fill 548 158 284 548 159 284 minecraft:white_concrete
fill 548 158 286 548 159 286 minecraft:white_concrete
fill 548 158 288 548 159 288 minecraft:white_concrete
setblock 548 158 317 minecraft:white_concrete
setblock 549 158 275 minecraft:brown_terracotta
fill 549 158 283 549 159 283 minecraft:white_concrete
fill 549 158 285 549 159 285 minecraft:white_concrete
fill 549 158 287 549 159 287 minecraft:white_concrete
fill 549 158 289 549 159 289 minecraft:white_concrete
fill 550 158 275 550 158 276 minecraft:white_concrete
fill 550 158 278 550 159 278 minecraft:white_concrete
fill 550 158 280 550 159 280 minecraft:white_concrete
fill 550 158 282 550 159 282 minecraft:white_concrete
fill 550 158 284 550 159 284 minecraft:white_concrete
fill 550 158 286 550 159 286 minecraft:white_concrete
fill 550 158 288 550 159 288 minecraft:white_concrete
setblock 550 158 317 minecraft:white_concrete
fill 551 158 275 551 159 275 minecraft:brown_terracotta
fill 551 158 277 551 159 277 minecraft:white_concrete
fill 551 158 279 551 159 279 minecraft:white_concrete
fill 551 158 281 551 159 281 minecraft:white_concrete
fill 551 158 283 551 159 283 minecraft:white_concrete
fill 551 158 285 551 159 285 minecraft:white_concrete
fill 551 158 287 551 159 287 minecraft:white_concrete
fill 551 158 289 551 159 289 minecraft:white_concrete
fill 551 158 317 551 165 317 minecraft:brown_terracotta
fill 552 158 275 552 158 276 minecraft:white_concrete
fill 552 158 278 552 159 278 minecraft:white_concrete
fill 552 158 280 552 159 280 minecraft:white_concrete
fill 552 158 282 552 159 282 minecraft:white_concrete
fill 552 158 284 552 159 284 minecraft:white_concrete
fill 552 158 286 552 159 286 minecraft:white_concrete
fill 552 158 288 552 159 288 minecraft:white_concrete
fill 552 158 294 552 159 294 minecraft:white_concrete
fill 552 158 296 552 159 296 minecraft:white_concrete
fill 552 158 298 552 159 298 minecraft:white_concrete
fill 552 158 300 552 159 300 minecraft:white_concrete
fill 552 158 302 552 159 302 minecraft:white_concrete
fill 552 158 304 552 159 304 minecraft:white_concrete
fill 552 158 306 552 159 306 minecraft:white_concrete
setblock 552 158 317 minecraft:white_concrete
setblock 553 158 275 minecraft:brown_terracotta
fill 553 158 277 553 159 277 minecraft:white_concrete
fill 553 158 279 553 159 279 minecraft:white_concrete
fill 553 158 281 553 159 281 minecraft:white_concrete
fill 553 158 283 553 159 283 minecraft:white_concrete
fill 553 158 285 553 159 285 minecraft:white_concrete
fill 553 158 287 553 159 287 minecraft:white_concrete
fill 553 158 289 553 159 289 minecraft:white_concrete
fill 553 158 295 553 159 295 minecraft:white_concrete
fill 553 158 297 553 159 297 minecraft:white_concrete
fill 553 158 299 553 159 299 minecraft:white_concrete
fill 553 158 301 553 159 301 minecraft:white_concrete
fill 553 158 303 553 159 303 minecraft:white_concrete
fill 553 158 305 553 159 305 minecraft:white_concrete
fill 554 158 275 554 158 276 minecraft:white_concrete
fill 554 158 278 554 159 278 minecraft:white_concrete
fill 554 158 280 554 159 280 minecraft:white_concrete
fill 554 158 282 554 159 282 minecraft:white_concrete
fill 554 158 284 554 159 284 minecraft:white_concrete
fill 554 158 286 554 159 286 minecraft:white_concrete
fill 554 158 288 554 159 288 minecraft:white_concrete
fill 554 158 294 554 159 294 minecraft:white_concrete
fill 554 158 296 554 159 296 minecraft:white_concrete
fill 554 158 298 554 159 298 minecraft:white_concrete
fill 554 158 300 554 159 300 minecraft:white_concrete
fill 554 158 302 554 159 302 minecraft:white_concrete
fill 554 158 304 554 159 304 minecraft:white_concrete
fill 554 158 306 554 159 306 minecraft:white_concrete
setblock 554 158 317 minecraft:white_concrete
fill 555 158 275 555 159 275 minecraft:brown_terracotta
fill 555 158 277 555 159 277 minecraft:white_concrete
fill 555 158 279 555 159 279 minecraft:white_concrete
fill 555 158 281 555 159 281 minecraft:white_concrete
fill 555 158 283 555 159 283 minecraft:white_concrete
fill 555 158 285 555 159 285 minecraft:white_concrete
fill 555 158 287 555 159 287 minecraft:white_concrete
fill 555 158 289 555 159 289 minecraft:white_concrete
fill 555 158 295 555 159 295 minecraft:white_concrete
fill 555 158 297 555 159 297 minecraft:white_concrete
fill 555 158 299 555 159 299 minecraft:white_concrete
fill 555 158 301 555 159 301 minecraft:white_concrete
fill 555 158 303 555 159 303 minecraft:white_concrete
fill 555 158 305 555 159 305 minecraft:white_concrete
fill 555 158 317 555 165 317 minecraft:brown_terracotta
fill 556 158 275 556 158 276 minecraft:white_concrete
fill 556 158 278 556 159 278 minecraft:white_concrete
fill 556 158 280 556 159 280 minecraft:white_concrete
fill 556 158 282 556 159 282 minecraft:white_concrete
fill 556 158 284 556 159 284 minecraft:white_concrete
fill 556 158 286 556 159 286 minecraft:white_concrete
fill 556 158 288 556 159 288 minecraft:white_concrete
fill 556 158 294 556 159 294 minecraft:white_concrete
fill 556 158 296 556 159 296 minecraft:white_concrete
fill 556 158 298 556 159 298 minecraft:white_concrete
fill 556 158 300 556 159 300 minecraft:white_concrete
fill 556 158 302 556 159 302 minecraft:white_concrete
fill 556 158 304 556 159 304 minecraft:white_concrete
fill 556 158 306 556 159 306 minecraft:white_concrete
setblock 556 158 317 minecraft:white_concrete
setblock 557 158 275 minecraft:brown_terracotta
fill 557 158 277 557 159 277 minecraft:white_concrete
fill 557 158 279 557 159 279 minecraft:white_concrete
fill 557 158 281 557 159 281 minecraft:white_concrete
fill 557 158 283 557 159 283 minecraft:white_concrete
fill 557 158 285 557 159 285 minecraft:white_concrete
fill 557 158 287 557 159 287 minecraft:white_concrete
fill 557 158 289 557 159 289 minecraft:white_concrete
fill 557 158 295 557 159 295 minecraft:white_concrete
fill 557 158 297 557 159 297 minecraft:white_concrete
fill 557 158 299 557 159 299 minecraft:white_concrete
fill 557 158 301 557 159 301 minecraft:white_concrete
fill 557 158 303 557 159 303 minecraft:white_concrete
fill 557 158 305 557 159 305 minecraft:white_concrete
fill 558 158 275 558 158 276 minecraft:white_concrete
fill 558 158 278 559 158 278 minecraft:white_concrete
fill 558 158 280 559 158 280 minecraft:white_concrete
fill 558 158 282 559 158 282 minecraft:white_concrete
fill 558 158 284 559 158 284 minecraft:white_concrete
fill 558 158 286 559 158 286 minecraft:white_concrete
fill 558 158 288 559 158 288 minecraft:white_concrete
fill 558 158 294 559 158 294 minecraft:white_concrete
fill 558 158 296 559 158 296 minecraft:white_concrete
fill 558 158 298 559 158 298 minecraft:white_concrete
fill 558 158 300 559 158 300 minecraft:white_concrete
fill 558 158 302 559 158 302 minecraft:white_concrete
fill 558 158 304 559 158 304 minecraft:white_concrete
fill 558 158 306 559 158 306 minecraft:white_concrete
setblock 558 158 317 minecraft:white_concrete
setblock 559 158 275 minecraft:brown_terracotta
setblock 559 158 276 minecraft:white_concrete
fill 559 158 277 559 165 277 minecraft:brown_terracotta
fill 559 158 281 559 165 281 minecraft:brown_terracotta
fill 559 158 285 559 165 285 minecraft:brown_terracotta
fill 559 158 289 559 165 289 minecraft:brown_terracotta
setblock 559 158 290 minecraft:white_concrete
setblock 559 158 292 minecraft:white_concrete
fill 559 158 293 559 165 293 minecraft:brown_terracotta
fill 559 158 297 559 165 297 minecraft:brown_terracotta
fill 559 158 301 559 165 301 minecraft:brown_terracotta
fill 559 158 305 559 165 305 minecraft:brown_terracotta
setblock 559 158 308 minecraft:white_concrete
fill 559 158 309 559 165 309 minecraft:brown_terracotta
setblock 559 158 310 minecraft:white_concrete
setblock 559 158 312 minecraft:white_concrete
fill 559 158 313 559 165 313 minecraft:brown_terracotta
setblock 559 158 314 minecraft:white_concrete
setblock 559 158 316 minecraft:white_concrete
fill 559 158 317 559 165 317 minecraft:brown_terracotta
setblock 517 159 275 minecraft:white_concrete
fill 517 159 276 517 166 276 minecraft:brown_terracotta
fill 517 159 278 517 166 278 minecraft:brown_terracotta
setblock 517 159 279 minecraft:white_concrete
fill 517 159 280 517 166 280 minecraft:brown_terracotta
fill 517 159 282 517 165 282 minecraft:brown_terracotta
setblock 517 159 283 minecraft:white_concrete
fill 517 159 284 517 165 284 minecraft:brown_terracotta
fill 517 159 286 517 166 286 minecraft:brown_terracotta
setblock 517 159 287 minecraft:white_concrete
fill 517 159 288 517 166 288 minecraft:brown_terracotta
fill 517 159 290 517 166 290 minecraft:brown_terracotta
setblock 517 159 291 minecraft:white_concrete
fill 517 159 292 517 166 292 minecraft:brown_terracotta
fill 517 159 294 517 165 294 minecraft:brown_terracotta
setblock 517 159 295 minecraft:white_concrete
fill 517 159 296 517 165 296 minecraft:brown_terracotta
fill 517 159 298 517 166 298 minecraft:brown_terracotta
setblock 517 159 299 minecraft:white_concrete
fill 517 159 300 517 166 300 minecraft:brown_terracotta
fill 517 159 302 517 166 302 minecraft:brown_terracotta
setblock 517 159 303 minecraft:white_concrete
fill 517 159 304 517 166 304 minecraft:brown_terracotta
fill 517 159 306 517 165 306 minecraft:brown_terracotta
setblock 517 159 307 minecraft:white_concrete
fill 517 159 308 517 165 308 minecraft:brown_terracotta
fill 517 159 310 517 166 310 minecraft:brown_terracotta
setblock 517 159 311 minecraft:white_concrete
fill 517 159 312 517 166 312 minecraft:brown_terracotta
fill 517 159 314 517 166 314 minecraft:brown_terracotta
setblock 517 159 315 minecraft:white_concrete
fill 517 159 316 517 166 316 minecraft:brown_terracotta
setblock 517 159 317 minecraft:white_concrete
fill 518 159 275 518 166 275 minecraft:brown_terracotta
fill 518 159 317 518 165 317 minecraft:brown_terracotta
fill 520 159 275 520 166 275 minecraft:brown_terracotta
fill 520 159 317 520 165 317 minecraft:brown_terracotta
setblock 521 159 275 minecraft:white_concrete
setblock 521 159 317 minecraft:white_concrete
fill 522 159 275 522 166 275 minecraft:brown_terracotta
fill 522 159 317 522 166 317 minecraft:brown_terracotta
fill 524 159 275 524 165 275 minecraft:brown_terracotta
fill 524 159 317 524 166 317 minecraft:brown_terracotta
setblock 525 159 275 minecraft:white_concrete
setblock 525 159 317 minecraft:white_concrete
fill 526 159 275 526 165 275 minecraft:brown_terracotta
fill 526 159 317 526 166 317 minecraft:brown_terracotta
fill 528 159 275 528 166 275 minecraft:brown_terracotta
fill 528 159 317 528 166 317 minecraft:brown_terracotta
setblock 529 159 275 minecraft:white_concrete
setblock 529 159 317 minecraft:white_concrete
fill 530 159 275 530 166 275 minecraft:brown_terracotta
fill 530 159 317 530 165 317 minecraft:brown_terracotta
fill 532 159 275 532 166 275 minecraft:brown_terracotta
fill 532 159 317 532 165 317 minecraft:brown_terracotta
setblock 533 159 275 minecraft:white_concrete
setblock 533 159 317 minecraft:white_concrete
fill 534 159 275 534 166 275 minecraft:brown_terracotta
fill 534 159 317 534 166 317 minecraft:brown_terracotta
fill 536 159 275 536 165 275 minecraft:brown_terracotta
fill 536 159 317 536 166 317 minecraft:brown_terracotta
setblock 537 159 275 minecraft:white_concrete
setblock 537 159 317 minecraft:white_concrete
fill 538 159 275 538 165 275 minecraft:brown_terracotta
fill 538 159 317 538 166 317 minecraft:brown_terracotta
fill 540 159 275 540 166 275 minecraft:brown_terracotta
fill 540 159 317 540 166 317 minecraft:brown_terracotta
setblock 541 159 275 minecraft:white_concrete
setblock 541 159 317 minecraft:white_concrete
fill 542 159 275 542 166 275 minecraft:brown_terracotta
fill 542 159 317 542 165 317 minecraft:brown_terracotta
fill 544 159 275 544 166 275 minecraft:brown_terracotta
fill 544 159 317 544 165 317 minecraft:brown_terracotta
setblock 545 159 275 minecraft:white_concrete
setblock 545 159 317 minecraft:white_concrete
fill 546 159 275 546 166 275 minecraft:brown_terracotta
fill 546 159 317 546 166 317 minecraft:brown_terracotta
fill 548 159 275 548 165 275 minecraft:brown_terracotta
fill 548 159 317 548 166 317 minecraft:brown_terracotta
setblock 549 159 275 minecraft:white_concrete
setblock 549 159 317 minecraft:white_concrete
fill 550 159 275 550 165 275 minecraft:brown_terracotta
setblock 550 159 276 minecraft:white_concrete
fill 550 159 317 550 166 317 minecraft:brown_terracotta
fill 552 159 275 552 166 275 minecraft:brown_terracotta
setblock 552 159 276 minecraft:white_concrete
fill 552 159 317 552 166 317 minecraft:brown_terracotta
setblock 553 159 275 minecraft:white_concrete
setblock 553 159 317 minecraft:white_concrete
fill 554 159 275 554 166 275 minecraft:brown_terracotta
setblock 554 159 276 minecraft:white_concrete
fill 554 159 317 554 165 317 minecraft:brown_terracotta
fill 556 159 275 556 166 275 minecraft:brown_terracotta
setblock 556 159 276 minecraft:white_concrete
fill 556 159 317 556 165 317 minecraft:brown_terracotta
setblock 557 159 275 minecraft:white_concrete
setblock 557 159 317 minecraft:white_concrete
fill 558 159 275 558 166 275 minecraft:brown_terracotta
setblock 558 159 276 minecraft:white_concrete
setblock 558 159 278 minecraft:white_concrete
setblock 558 159 280 minecraft:white_concrete
setblock 558 159 282 minecraft:white_concrete
setblock 558 159 284 minecraft:white_concrete
setblock 558 159 286 minecraft:white_concrete
setblock 558 159 288 minecraft:white_concrete
setblock 558 159 294 minecraft:white_concrete
setblock 558 159 296 minecraft:white_concrete
setblock 558 159 298 minecraft:white_concrete
setblock 558 159 300 minecraft:white_concrete
setblock 558 159 302 minecraft:white_concrete
setblock 558 159 304 minecraft:white_concrete
setblock 558 159 306 minecraft:white_concrete
fill 558 159 317 558 166 317 minecraft:brown_terracotta
setblock 559 159 275 minecraft:white_concrete
fill 559 159 276 559 165 276 minecraft:brown_terracotta
fill 559 159 278 559 165 278 minecraft:brown_terracotta
setblock 559 159 279 minecraft:white_concrete
fill 559 159 280 559 166 280 minecraft:brown_terracotta
fill 559 159 282 559 166 282 minecraft:brown_terracotta
setblock 559 159 283 minecraft:white_concrete
fill 559 159 284 559 166 284 minecraft:brown_terracotta
fill 559 159 286 559 166 286 minecraft:brown_terracotta
setblock 559 159 287 minecraft:white_concrete
fill 559 159 288 559 165 288 minecraft:brown_terracotta
fill 559 159 290 559 165 290 minecraft:brown_terracotta
setblock 559 159 291 minecraft:white_concrete
fill 559 159 292 559 166 292 minecraft:brown_terracotta
fill 559 159 294 559 166 294 minecraft:brown_terracotta
setblock 559 159 295 minecraft:white_concrete
fill 559 159 296 559 166 296 minecraft:brown_terracotta
fill 559 159 298 559 166 298 minecraft:brown_terracotta
setblock 559 159 299 minecraft:white_concrete
fill 559 159 300 559 165 300 minecraft:brown_terracotta
fill 559 159 302 559 165 302 minecraft:brown_terracotta
setblock 559 159 303 minecraft:white_concrete
fill 559 159 304 559 166 304 minecraft:brown_terracotta
fill 559 159 306 559 166 306 minecraft:brown_terracotta
setblock 559 159 307 minecraft:white_concrete
fill 559 159 308 559 166 308 minecraft:brown_terracotta
fill 559 159 310 559 166 310 minecraft:brown_terracotta
setblock 559 159 311 minecraft:white_concrete
fill 559 159 312 559 165 312 minecraft:brown_terracotta
fill 559 159 314 559 165 314 minecraft:brown_terracotta
setblock 559 159 315 minecraft:white_concrete
fill 559 159 316 559 166 316 minecraft:brown_terracotta
fill 517 160 275 517 167 275 minecraft:brown_terracotta
fill 517 160 279 517 167 279 minecraft:brown_terracotta
fill 517 160 283 517 165 283 minecraft:brown_terracotta
fill 517 160 287 517 167 287 minecraft:brown_terracotta
fill 517 160 291 517 167 291 minecraft:brown_terracotta
fill 517 160 295 517 165 295 minecraft:brown_terracotta
fill 517 160 299 517 167 299 minecraft:brown_terracotta
fill 517 160 303 517 167 303 minecraft:brown_terracotta
fill 517 160 307 517 165 307 minecraft:brown_terracotta
fill 517 160 311 517 167 311 minecraft:brown_terracotta
fill 517 160 315 517 167 315 minecraft:brown_terracotta
fill 517 160 317 517 165 317 minecraft:brown_terracotta
fill 519 160 285 519 165 287 minecraft:white_concrete
fill 519 160 297 519 165 299 minecraft:white_concrete
fill 519 160 309 519 165 311 minecraft:white_concrete
fill 521 160 275 521 167 275 minecraft:brown_terracotta
fill 521 160 317 521 167 317 minecraft:brown_terracotta
fill 525 160 275 525 165 275 minecraft:brown_terracotta
fill 525 160 315 527 165 315 minecraft:white_concrete
fill 525 160 317 525 167 317 minecraft:brown_terracotta
fill 527 160 294 527 161 296 minecraft:red_concrete
fill 528 160 295 528 161 296 minecraft:red_concrete
fill 529 160 275 529 167 275 minecraft:brown_terracotta
fill 529 160 277 531 165 277 minecraft:white_concrete
fill 529 160 317 529 165 317 minecraft:brown_terracotta
fill 533 160 275 533 167 275 minecraft:brown_terracotta
fill 533 160 317 533 167 317 minecraft:brown_terracotta
fill 537 160 275 537 165 275 minecraft:brown_terracotta
fill 537 160 315 539 165 315 minecraft:white_concrete
fill 537 160 317 537 167 317 minecraft:brown_terracotta
fill 541 160 275 541 167 275 minecraft:brown_terracotta
fill 541 160 277 543 165 277 minecraft:white_concrete
fill 541 160 317 541 165 317 minecraft:brown_terracotta
fill 545 160 275 545 167 275 minecraft:brown_terracotta
fill 545 160 317 545 167 317 minecraft:brown_terracotta
setblock 548 160 284 minecraft:shroomlight
setblock 548 160 286 minecraft:shroomlight
setblock 548 160 288 minecraft:shroomlight
fill 549 160 275 549 165 275 minecraft:brown_terracotta
setblock 549 160 283 minecraft:shroomlight
setblock 549 160 285 minecraft:shroomlight
setblock 549 160 287 minecraft:shroomlight
setblock 549 160 289 minecraft:shroomlight
fill 549 160 315 551 165 315 minecraft:white_concrete
fill 549 160 317 549 167 317 minecraft:brown_terracotta
setblock 550 160 276 minecraft:shroomlight
setblock 550 160 278 minecraft:shroomlight
setblock 550 160 280 minecraft:shroomlight
setblock 550 160 282 minecraft:shroomlight
setblock 550 160 284 minecraft:shroomlight
setblock 550 160 286 minecraft:shroomlight
setblock 550 160 288 minecraft:shroomlight
setblock 551 160 275 minecraft:shroomlight
setblock 551 160 277 minecraft:shroomlight
setblock 551 160 279 minecraft:shroomlight
setblock 551 160 281 minecraft:shroomlight
setblock 551 160 283 minecraft:shroomlight
setblock 551 160 285 minecraft:shroomlight
setblock 551 160 287 minecraft:shroomlight
setblock 551 160 289 minecraft:shroomlight
setblock 552 160 276 minecraft:shroomlight
setblock 552 160 278 minecraft:shroomlight
setblock 552 160 280 minecraft:shroomlight
setblock 552 160 282 minecraft:shroomlight
setblock 552 160 284 minecraft:shroomlight
setblock 552 160 286 minecraft:shroomlight
setblock 552 160 288 minecraft:shroomlight
setblock 552 160 294 minecraft:shroomlight
setblock 552 160 296 minecraft:shroomlight
setblock 552 160 298 minecraft:shroomlight
setblock 552 160 300 minecraft:shroomlight
setblock 552 160 302 minecraft:shroomlight
setblock 552 160 304 minecraft:shroomlight
setblock 552 160 306 minecraft:shroomlight
setblock 553 160 275 minecraft:shroomlight
setblock 553 160 277 minecraft:shroomlight
setblock 553 160 279 minecraft:shroomlight
setblock 553 160 281 minecraft:shroomlight
setblock 553 160 283 minecraft:shroomlight
setblock 553 160 285 minecraft:shroomlight
setblock 553 160 287 minecraft:shroomlight
setblock 553 160 289 minecraft:shroomlight
setblock 553 160 295 minecraft:shroomlight
setblock 553 160 297 minecraft:shroomlight
setblock 553 160 299 minecraft:shroomlight
setblock 553 160 301 minecraft:shroomlight
setblock 553 160 303 minecraft:shroomlight
setblock 553 160 305 minecraft:shroomlight
fill 553 160 317 553 165 317 minecraft:brown_terracotta
setblock 554 160 276 minecraft:shroomlight
setblock 554 160 278 minecraft:shroomlight
setblock 554 160 280 minecraft:shroomlight
setblock 554 160 282 minecraft:shroomlight
setblock 554 160 284 minecraft:shroomlight
setblock 554 160 286 minecraft:shroomlight
setblock 554 160 288 minecraft:shroomlight
setblock 554 160 294 minecraft:shroomlight
setblock 554 160 296 minecraft:shroomlight
setblock 554 160 298 minecraft:shroomlight
setblock 554 160 300 minecraft:shroomlight
setblock 554 160 302 minecraft:shroomlight
setblock 554 160 304 minecraft:shroomlight
setblock 554 160 306 minecraft:shroomlight
setblock 555 160 275 minecraft:shroomlight
setblock 555 160 277 minecraft:shroomlight
setblock 555 160 279 minecraft:shroomlight
setblock 555 160 281 minecraft:shroomlight
setblock 555 160 283 minecraft:shroomlight
setblock 555 160 285 minecraft:shroomlight
setblock 555 160 287 minecraft:shroomlight
setblock 555 160 289 minecraft:shroomlight
setblock 555 160 295 minecraft:shroomlight
setblock 555 160 297 minecraft:shroomlight
setblock 555 160 299 minecraft:shroomlight
setblock 555 160 301 minecraft:shroomlight
setblock 555 160 303 minecraft:shroomlight
setblock 555 160 305 minecraft:shroomlight
setblock 556 160 276 minecraft:shroomlight
setblock 556 160 278 minecraft:shroomlight
setblock 556 160 280 minecraft:shroomlight
setblock 556 160 282 minecraft:shroomlight
setblock 556 160 284 minecraft:shroomlight
setblock 556 160 286 minecraft:shroomlight
setblock 556 160 288 minecraft:shroomlight
setblock 556 160 294 minecraft:shroomlight
setblock 556 160 296 minecraft:shroomlight
setblock 556 160 298 minecraft:shroomlight
setblock 556 160 300 minecraft:shroomlight
setblock 556 160 302 minecraft:shroomlight
setblock 556 160 304 minecraft:shroomlight
setblock 556 160 306 minecraft:shroomlight
setblock 557 160 275 minecraft:shroomlight
setblock 557 160 277 minecraft:shroomlight
setblock 557 160 279 minecraft:shroomlight
setblock 557 160 281 minecraft:shroomlight
setblock 557 160 283 minecraft:shroomlight
setblock 557 160 285 minecraft:shroomlight
setblock 557 160 287 minecraft:shroomlight
setblock 557 160 289 minecraft:shroomlight
setblock 557 160 295 minecraft:shroomlight
setblock 557 160 297 minecraft:shroomlight
setblock 557 160 299 minecraft:shroomlight
setblock 557 160 301 minecraft:shroomlight
setblock 557 160 303 minecraft:shroomlight
setblock 557 160 305 minecraft:shroomlight
fill 557 160 309 557 165 311 minecraft:white_concrete
fill 557 160 317 557 167 317 minecraft:brown_terracotta
setblock 558 160 276 minecraft:shroomlight
setblock 558 160 278 minecraft:shroomlight
setblock 558 160 280 minecraft:shroomlight
setblock 558 160 282 minecraft:shroomlight
setblock 558 160 284 minecraft:shroomlight
setblock 558 160 286 minecraft:shroomlight
setblock 558 160 288 minecraft:shroomlight
setblock 558 160 294 minecraft:shroomlight
setblock 558 160 296 minecraft:shroomlight
setblock 558 160 298 minecraft:shroomlight
setblock 558 160 300 minecraft:shroomlight
setblock 558 160 302 minecraft:shroomlight
setblock 558 160 304 minecraft:shroomlight
setblock 558 160 306 minecraft:shroomlight
fill 559 160 275 559 165 275 minecraft:brown_terracotta
fill 559 160 279 559 165 279 minecraft:brown_terracotta
fill 559 160 283 559 167 283 minecraft:brown_terracotta
fill 559 160 287 559 167 287 minecraft:brown_terracotta
fill 559 160 291 559 165 291 minecraft:brown_terracotta
fill 559 160 295 559 167 295 minecraft:brown_terracotta
fill 559 160 299 559 167 299 minecraft:brown_terracotta
fill 559 160 303 559 165 303 minecraft:brown_terracotta
fill 559 160 307 559 167 307 minecraft:brown_terracotta
fill 559 160 311 559 167 311 minecraft:brown_terracotta
fill 559 160 315 559 165 315 minecraft:brown_terracotta
fill 548 161 284 548 162 284 minecraft:white_concrete
fill 548 161 286 548 162 286 minecraft:white_concrete
fill 548 161 288 548 162 288 minecraft:white_concrete
fill 549 161 283 549 162 283 minecraft:white_concrete
fill 549 161 285 549 162 285 minecraft:white_concrete
fill 549 161 287 549 162 287 minecraft:white_concrete
fill 549 161 289 549 162 289 minecraft:white_concrete
fill 550 161 276 550 162 276 minecraft:white_concrete
fill 550 161 278 550 162 278 minecraft:white_concrete
fill 550 161 280 550 162 280 minecraft:white_concrete
fill 550 161 282 550 162 282 minecraft:white_concrete
fill 550 161 284 550 162 284 minecraft:white_concrete
fill 550 161 286 550 162 286 minecraft:white_concrete
fill 550 161 288 550 162 288 minecraft:white_concrete
fill 551 161 275 551 162 275 minecraft:brown_terracotta
fill 551 161 277 551 162 277 minecraft:white_concrete
fill 551 161 279 551 162 279 minecraft:white_concrete
fill 551 161 281 551 162 281 minecraft:white_concrete
fill 551 161 283 551 162 283 minecraft:white_concrete
fill 551 161 285 551 162 285 minecraft:white_concrete
fill 551 161 287 551 162 287 minecraft:white_concrete
fill 551 161 289 551 162 289 minecraft:white_concrete
fill 552 161 276 552 162 276 minecraft:white_concrete
fill 552 161 278 552 162 278 minecraft:white_concrete
fill 552 161 280 552 162 280 minecraft:white_concrete
fill 552 161 282 552 162 282 minecraft:white_concrete
fill 552 161 284 552 162 284 minecraft:white_concrete
fill 552 161 286 552 162 286 minecraft:white_concrete
fill 552 161 288 552 162 288 minecraft:white_concrete
setblock 552 161 294 minecraft:white_concrete
fill 552 161 296 552 162 296 minecraft:white_concrete
fill 552 161 298 552 162 298 minecraft:white_concrete
fill 552 161 300 552 162 300 minecraft:white_concrete
fill 552 161 302 552 162 302 minecraft:white_concrete
fill 552 161 304 552 162 304 minecraft:white_concrete
fill 552 161 306 552 162 306 minecraft:white_concrete
fill 553 161 275 553 162 275 minecraft:brown_terracotta
fill 553 161 277 553 162 277 minecraft:white_concrete
fill 553 161 279 553 162 279 minecraft:white_concrete
fill 553 161 281 553 162 281 minecraft:white_concrete
fill 553 161 283 553 162 283 minecraft:white_concrete
fill 553 161 285 553 162 285 minecraft:white_concrete
fill 553 161 287 553 162 287 minecraft:white_concrete
fill 553 161 289 553 162 289 minecraft:white_concrete
setblock 553 161 295 minecraft:white_concrete
setblock 553 161 297 minecraft:white_concrete
setblock 553 161 299 minecraft:white_concrete
setblock 553 161 301 minecraft:white_concrete
setblock 553 161 303 minecraft:white_concrete
setblock 553 161 305 minecraft:white_concrete
fill 554 161 276 554 162 276 minecraft:white_concrete
fill 554 161 278 554 162 278 minecraft:white_concrete
fill 554 161 280 554 162 280 minecraft:white_concrete
fill 554 161 282 554 162 282 minecraft:white_concrete
fill 554 161 284 554 162 284 minecraft:white_concrete
fill 554 161 286 554 162 286 minecraft:white_concrete
fill 554 161 288 554 162 288 minecraft:white_concrete
setblock 554 161 294 minecraft:white_concrete
setblock 554 161 296 minecraft:white_concrete
setblock 554 161 298 minecraft:white_concrete
setblock 554 161 300 minecraft:white_concrete
setblock 554 161 302 minecraft:white_concrete
setblock 554 161 304 minecraft:white_concrete
fill 554 161 306 554 162 306 minecraft:white_concrete
fill 555 161 275 555 162 275 minecraft:brown_terracotta
fill 555 161 277 555 162 277 minecraft:white_concrete
fill 555 161 279 555 162 279 minecraft:white_concrete
fill 555 161 281 555 162 281 minecraft:white_concrete
fill 555 161 283 555 162 283 minecraft:white_concrete
fill 555 161 285 555 162 285 minecraft:white_concrete
fill 555 161 287 555 162 287 minecraft:white_concrete
fill 555 161 289 555 162 289 minecraft:white_concrete
setblock 555 161 295 minecraft:white_concrete
setblock 555 161 297 minecraft:white_concrete
setblock 555 161 299 minecraft:white_concrete
setblock 555 161 301 minecraft:white_concrete
setblock 555 161 303 minecraft:white_concrete
setblock 555 161 305 minecraft:white_concrete
fill 556 161 276 556 162 276 minecraft:white_concrete
fill 556 161 278 556 162 278 minecraft:white_concrete
fill 556 161 280 556 162 280 minecraft:white_concrete
fill 556 161 282 556 162 282 minecraft:white_concrete
fill 556 161 284 556 162 284 minecraft:white_concrete
fill 556 161 286 556 162 286 minecraft:white_concrete
fill 556 161 288 556 162 288 minecraft:white_concrete
setblock 556 161 294 minecraft:white_concrete
setblock 556 161 296 minecraft:white_concrete
setblock 556 161 298 minecraft:white_concrete
setblock 556 161 300 minecraft:white_concrete
setblock 556 161 302 minecraft:white_concrete
setblock 556 161 304 minecraft:white_concrete
fill 556 161 306 556 162 306 minecraft:white_concrete
fill 557 161 275 557 162 275 minecraft:brown_terracotta
fill 557 161 277 557 162 277 minecraft:white_concrete
fill 557 161 279 557 162 279 minecraft:white_concrete
fill 557 161 281 557 162 281 minecraft:white_concrete
fill 557 161 283 557 162 283 minecraft:white_concrete
fill 557 161 285 557 162 285 minecraft:white_concrete
fill 557 161 287 557 162 287 minecraft:white_concrete
fill 557 161 289 557 162 289 minecraft:white_concrete
setblock 557 161 295 minecraft:white_concrete
fill 557 161 297 557 165 297 minecraft:white_concrete
fill 557 161 299 557 165 299 minecraft:white_concrete
setblock 557 161 301 minecraft:white_concrete
setblock 557 161 303 minecraft:white_concrete
setblock 557 161 305 minecraft:white_concrete
fill 558 161 276 558 162 276 minecraft:white_concrete
fill 558 161 278 558 162 278 minecraft:white_concrete
fill 558 161 280 558 162 280 minecraft:white_concrete
fill 558 161 282 558 162 282 minecraft:white_concrete
fill 558 161 284 558 162 284 minecraft:white_concrete
fill 558 161 286 558 162 286 minecraft:white_concrete
fill 558 161 288 558 162 288 minecraft:white_concrete
setblock 558 161 294 minecraft:white_concrete
fill 558 161 296 558 169 296 minecraft:white_concrete
fill 558 161 298 558 213 298 minecraft:white_concrete
fill 558 161 300 558 162 300 minecraft:white_concrete
fill 558 161 302 558 162 302 minecraft:white_concrete
fill 558 161 304 558 162 304 minecraft:white_concrete
fill 558 161 306 558 162 306 minecraft:white_concrete
fill 553 162 295 556 162 305 minecraft:red_concrete
fill 556 162 294 556 164 294 minecraft:red_wool
fill 557 162 295 557 162 296 minecraft:red_concrete
fill 557 162 300 557 163 305 minecraft:red_concrete
setblock 520 163 278 minecraft:light[level=12]
setblock 520 163 285 minecraft:light[level=12]
setblock 520 163 292 minecraft:light[level=12]
setblock 520 163 299 minecraft:light[level=12]
setblock 520 163 306 minecraft:light[level=12]
setblock 520 163 313 minecraft:light[level=12]
setblock 527 163 278 minecraft:light[level=12]
setblock 527 163 285 minecraft:light[level=12]
setblock 527 163 292 minecraft:light[level=12]
setblock 527 163 299 minecraft:light[level=12]
setblock 527 163 306 minecraft:light[level=12]
setblock 527 163 313 minecraft:light[level=12]
setblock 534 163 278 minecraft:light[level=12]
setblock 534 163 285 minecraft:light[level=12]
setblock 534 163 292 minecraft:light[level=12]
setblock 534 163 306 minecraft:light[level=12]
setblock 534 163 313 minecraft:light[level=12]
setblock 541 163 278 minecraft:light[level=12]
setblock 541 163 285 minecraft:light[level=12]
setblock 541 163 292 minecraft:light[level=12]
setblock 541 163 299 minecraft:light[level=12]
setblock 541 163 306 minecraft:light[level=12]
setblock 541 163 313 minecraft:light[level=12]
setblock 548 163 278 minecraft:light[level=12]
setblock 548 163 284 minecraft:shroomlight
setblock 548 163 286 minecraft:shroomlight
setblock 548 163 288 minecraft:shroomlight
setblock 548 163 292 minecraft:light[level=12]
setblock 548 163 299 minecraft:light[level=12]
setblock 548 163 306 minecraft:light[level=12]
setblock 548 163 313 minecraft:light[level=12]
setblock 549 163 283 minecraft:shroomlight
setblock 549 163 285 minecraft:shroomlight
setblock 549 163 287 minecraft:shroomlight
setblock 549 163 289 minecraft:shroomlight
setblock 550 163 276 minecraft:shroomlight
setblock 550 163 278 minecraft:shroomlight
setblock 550 163 280 minecraft:shroomlight
setblock 550 163 282 minecraft:shroomlight
setblock 550 163 284 minecraft:shroomlight
setblock 550 163 286 minecraft:shroomlight
setblock 550 163 288 minecraft:shroomlight
setblock 551 163 275 minecraft:shroomlight
setblock 551 163 277 minecraft:shroomlight
setblock 551 163 279 minecraft:shroomlight
setblock 551 163 281 minecraft:shroomlight
setblock 551 163 283 minecraft:shroomlight
setblock 551 163 285 minecraft:shroomlight
setblock 551 163 287 minecraft:shroomlight
setblock 551 163 289 minecraft:shroomlight
fill 551 163 297 556 163 305 minecraft:red_concrete
setblock 552 163 276 minecraft:shroomlight
setblock 552 163 278 minecraft:shroomlight
setblock 552 163 280 minecraft:shroomlight
setblock 552 163 282 minecraft:shroomlight
setblock 552 163 284 minecraft:shroomlight
setblock 552 163 286 minecraft:shroomlight
setblock 552 163 288 minecraft:shroomlight
setblock 553 163 275 minecraft:shroomlight
setblock 553 163 277 minecraft:shroomlight
setblock 553 163 279 minecraft:shroomlight
setblock 553 163 281 minecraft:shroomlight
setblock 553 163 283 minecraft:shroomlight
setblock 553 163 285 minecraft:shroomlight
setblock 553 163 287 minecraft:shroomlight
setblock 553 163 289 minecraft:shroomlight
setblock 554 163 276 minecraft:shroomlight
setblock 554 163 278 minecraft:shroomlight
setblock 554 163 280 minecraft:shroomlight
setblock 554 163 282 minecraft:shroomlight
setblock 554 163 284 minecraft:shroomlight
setblock 554 163 286 minecraft:shroomlight
setblock 554 163 288 minecraft:shroomlight
fill 554 163 296 556 163 296 minecraft:red_concrete
setblock 555 163 275 minecraft:shroomlight
setblock 555 163 277 minecraft:shroomlight
setblock 555 163 279 minecraft:shroomlight
setblock 555 163 281 minecraft:shroomlight
setblock 555 163 283 minecraft:shroomlight
setblock 555 163 285 minecraft:shroomlight
setblock 555 163 287 minecraft:shroomlight
setblock 555 163 289 minecraft:shroomlight
setblock 555 163 292 minecraft:light[level=12]
setblock 555 163 306 minecraft:light[level=12]
setblock 555 163 313 minecraft:light[level=12]
setblock 556 163 276 minecraft:shroomlight
setblock 556 163 278 minecraft:shroomlight
setblock 556 163 280 minecraft:shroomlight
setblock 556 163 282 minecraft:shroomlight
setblock 556 163 284 minecraft:shroomlight
setblock 556 163 286 minecraft:shroomlight
setblock 556 163 288 minecraft:shroomlight
fill 556 163 295 556 164 295 minecraft:red_wool
setblock 557 163 275 minecraft:shroomlight
setblock 557 163 277 minecraft:shroomlight
setblock 557 163 279 minecraft:shroomlight
setblock 557 163 281 minecraft:shroomlight
setblock 557 163 283 minecraft:shroomlight
setblock 557 163 285 minecraft:shroomlight
setblock 557 163 287 minecraft:shroomlight
setblock 557 163 289 minecraft:shroomlight
setblock 558 163 276 minecraft:shroomlight
setblock 558 163 278 minecraft:shroomlight
setblock 558 163 280 minecraft:shroomlight
setblock 558 163 282 minecraft:shroomlight
setblock 558 163 284 minecraft:shroomlight
setblock 558 163 286 minecraft:shroomlight
setblock 558 163 288 minecraft:shroomlight
fill 532 164 312 532 165 312 minecraft:red_concrete
fill 548 164 284 548 165 284 minecraft:white_concrete
fill 548 164 286 548 165 286 minecraft:white_concrete
fill 548 164 288 548 165 288 minecraft:white_concrete
fill 549 164 283 549 165 283 minecraft:white_concrete
fill 549 164 285 549 165 285 minecraft:white_concrete
fill 549 164 287 549 165 287 minecraft:white_concrete
fill 549 164 289 549 165 289 minecraft:white_concrete
setblock 550 164 276 minecraft:white_concrete
fill 550 164 278 550 165 278 minecraft:white_concrete
fill 550 164 280 550 165 280 minecraft:white_concrete
fill 550 164 282 550 165 282 minecraft:white_concrete
fill 550 164 284 550 165 284 minecraft:white_concrete
fill 550 164 286 550 165 286 minecraft:white_concrete
fill 550 164 288 550 165 288 minecraft:white_concrete
fill 551 164 275 551 165 275 minecraft:brown_terracotta
fill 551 164 277 551 165 277 minecraft:white_concrete
fill 551 164 279 551 165 279 minecraft:white_concrete
fill 551 164 281 551 165 281 minecraft:white_concrete
fill 551 164 283 551 165 283 minecraft:white_concrete
fill 551 164 285 551 165 285 minecraft:white_concrete
fill 551 164 287 551 165 287 minecraft:white_concrete
fill 551 164 289 551 165 289 minecraft:white_concrete
fill 552 164 276 552 165 276 minecraft:white_concrete
fill 552 164 278 552 165 278 minecraft:white_concrete
fill 552 164 280 552 165 280 minecraft:white_concrete
fill 552 164 282 552 165 282 minecraft:white_concrete
fill 552 164 284 552 165 284 minecraft:white_concrete
fill 552 164 286 552 165 286 minecraft:white_concrete
fill 552 164 288 552 165 288 minecraft:white_concrete
fill 552 164 298 556 164 304 minecraft:red_concrete
fill 553 164 275 553 165 275 minecraft:brown_terracotta
fill 553 164 277 553 165 277 minecraft:white_concrete
fill 553 164 279 553 165 279 minecraft:white_concrete
fill 553 164 281 553 165 281 minecraft:white_concrete
fill 553 164 283 553 165 283 minecraft:white_concrete
fill 553 164 285 553 165 285 minecraft:white_concrete
fill 553 164 287 553 165 287 minecraft:white_concrete
fill 553 164 289 553 165 289 minecraft:white_concrete
fill 554 164 276 554 165 276 minecraft:white_concrete
fill 554 164 278 554 165 278 minecraft:white_concrete
fill 554 164 280 554 165 280 minecraft:white_concrete
fill 554 164 282 554 165 282 minecraft:white_concrete
fill 554 164 284 554 165 284 minecraft:white_concrete
fill 554 164 286 554 165 286 minecraft:white_concrete
fill 554 164 288 554 165 288 minecraft:white_concrete
fill 555 164 275 555 165 275 minecraft:brown_terracotta
fill 555 164 277 555 165 277 minecraft:white_concrete
fill 555 164 279 555 165 279 minecraft:white_concrete
fill 555 164 281 555 165 281 minecraft:white_concrete
fill 555 164 283 555 165 283 minecraft:white_concrete
fill 555 164 285 555 165 285 minecraft:white_concrete
fill 555 164 287 555 165 287 minecraft:white_concrete
fill 555 164 289 555 165 289 minecraft:white_concrete
setblock 555 164 297 minecraft:red_concrete
fill 556 164 276 556 165 276 minecraft:white_concrete
fill 556 164 278 556 165 278 minecraft:white_concrete
fill 556 164 280 556 165 280 minecraft:white_concrete
fill 556 164 282 556 165 282 minecraft:white_concrete
fill 556 164 284 556 165 284 minecraft:white_concrete
fill 556 164 286 556 165 286 minecraft:white_concrete
fill 556 164 288 556 165 288 minecraft:white_concrete
setblock 556 164 296 minecraft:red_wool
fill 557 164 275 557 165 275 minecraft:brown_terracotta
fill 557 164 277 557 165 277 minecraft:white_concrete
fill 557 164 279 557 165 279 minecraft:white_concrete
fill 557 164 281 557 165 281 minecraft:white_concrete
fill 557 164 283 557 165 283 minecraft:white_concrete
fill 557 164 285 557 165 285 minecraft:white_concrete
fill 557 164 287 557 165 287 minecraft:white_concrete
fill 557 164 289 557 165 289 minecraft:white_concrete
setblock 558 164 276 minecraft:white_concrete
setblock 558 164 278 minecraft:white_concrete
setblock 558 164 280 minecraft:white_concrete
fill 558 164 282 558 165 282 minecraft:white_concrete
fill 558 164 284 558 165 284 minecraft:white_concrete
fill 558 164 286 558 165 286 minecraft:white_concrete
setblock 558 164 288 minecraft:white_concrete
fill 518 165 279 518 165 284 minecraft:brown_terracotta
fill 518 165 291 518 165 296 minecraft:brown_terracotta
fill 518 165 303 518 165 308 minecraft:brown_terracotta
fill 518 165 315 518 165 316 minecraft:brown_terracotta
fill 519 165 316 522 165 316 minecraft:brown_terracotta
setblock 520 165 278 minecraft:light[level=15]
setblock 520 165 286 minecraft:light[level=15]
setblock 520 165 294 minecraft:light[level=15]
setblock 520 165 302 minecraft:light[level=15]
setblock 520 165 310 minecraft:light[level=15]
fill 522 165 276 527 165 276 minecraft:brown_terracotta
setblock 528 165 278 minecraft:light[level=15]
setblock 528 165 286 minecraft:light[level=15]
setblock 528 165 294 minecraft:light[level=15]
setblock 528 165 302 minecraft:light[level=15]
setblock 528 165 310 minecraft:light[level=15]
fill 529 165 316 534 165 316 minecraft:brown_terracotta
fill 534 165 276 539 165 276 minecraft:brown_terracotta
setblock 536 165 278 minecraft:light[level=15]
setblock 536 165 286 minecraft:light[level=15]
setblock 536 165 294 minecraft:light[level=15]
setblock 536 165 302 minecraft:light[level=15]
setblock 536 165 310 minecraft:light[level=15]
fill 541 165 316 546 165 316 minecraft:brown_terracotta
setblock 544 165 278 minecraft:light[level=15]
setblock 544 165 286 minecraft:light[level=15]
setblock 544 165 294 minecraft:light[level=15]
setblock 544 165 302 minecraft:light[level=15]
setblock 544 165 310 minecraft:light[level=15]
fill 546 165 276 551 165 276 minecraft:brown_terracotta
setblock 552 165 294 minecraft:light[level=15]
setblock 552 165 302 minecraft:light[level=15]
setblock 552 165 310 minecraft:light[level=15]
fill 553 165 299 555 165 303 minecraft:red_concrete
fill 553 165 316 558 165 316 minecraft:brown_terracotta
fill 554 165 298 556 165 298 minecraft:red_concrete
fill 556 165 291 556 166 297 minecraft:iron_block
fill 556 165 299 556 165 302 minecraft:red_concrete
fill 558 165 276 558 165 281 minecraft:brown_terracotta
fill 558 165 288 558 165 293 minecraft:brown_terracotta
fill 558 165 300 558 165 305 minecraft:brown_terracotta
fill 558 165 312 558 165 315 minecraft:brown_terracotta
setblock 517 166 277 minecraft:white_concrete
fill 517 166 281 517 171 284 minecraft:shroomlight
setblock 517 166 285 minecraft:white_concrete
setblock 517 166 289 minecraft:white_concrete
fill 517 166 293 517 171 296 minecraft:shroomlight
setblock 517 166 297 minecraft:white_concrete
setblock 517 166 301 minecraft:white_concrete
fill 517 166 305 517 171 308 minecraft:shroomlight
setblock 517 166 309 minecraft:white_concrete
setblock 517 166 313 minecraft:white_concrete
fill 517 166 317 520 171 317 minecraft:shroomlight
setblock 519 166 275 minecraft:white_concrete
fill 519 166 279 519 166 281 minecraft:brown_terracotta
fill 520 166 278 522 166 278 minecraft:brown_terracotta
fill 520 166 282 522 166 282 minecraft:brown_terracotta
setblock 523 166 275 minecraft:white_concrete
fill 523 166 279 523 166 281 minecraft:brown_terracotta
setblock 523 166 317 minecraft:white_concrete
fill 524 166 275 527 171 275 minecraft:shroomlight
setblock 527 166 317 minecraft:white_concrete
fill 529 166 317 532 171 317 minecraft:shroomlight
setblock 531 166 275 minecraft:white_concrete
setblock 535 166 275 minecraft:white_concrete
setblock 535 166 317 minecraft:white_concrete
fill 536 166 275 539 171 275 minecraft:shroomlight
setblock 539 166 317 minecraft:white_concrete
fill 541 166 317 544 171 317 minecraft:shroomlight
setblock 543 166 275 minecraft:white_concrete
setblock 547 166 275 minecraft:white_concrete
setblock 547 166 317 minecraft:white_concrete
fill 548 166 275 551 171 275 minecraft:shroomlight
setblock 548 166 284 minecraft:shroomlight
setblock 548 166 286 minecraft:shroomlight
setblock 548 166 288 minecraft:shroomlight
setblock 549 166 283 minecraft:shroomlight
setblock 549 166 285 minecraft:shroomlight
setblock 549 166 287 minecraft:shroomlight
setblock 549 166 289 minecraft:shroomlight
setblock 550 166 276 minecraft:shroomlight
setblock 550 166 278 minecraft:shroomlight
setblock 550 166 280 minecraft:shroomlight
setblock 550 166 282 minecraft:shroomlight
setblock 550 166 284 minecraft:shroomlight
setblock 550 166 286 minecraft:shroomlight
setblock 550 166 288 minecraft:shroomlight
fill 551 166 276 551 169 276 minecraft:white_concrete
setblock 551 166 277 minecraft:shroomlight
setblock 551 166 279 minecraft:shroomlight
setblock 551 166 281 minecraft:shroomlight
setblock 551 166 283 minecraft:shroomlight
setblock 551 166 285 minecraft:shroomlight
setblock 551 166 287 minecraft:shroomlight
setblock 551 166 289 minecraft:shroomlight
setblock 551 166 317 minecraft:white_concrete
setblock 552 166 276 minecraft:shroomlight
setblock 552 166 278 minecraft:shroomlight
setblock 552 166 280 minecraft:shroomlight
setblock 552 166 282 minecraft:shroomlight
setblock 552 166 284 minecraft:shroomlight
setblock 552 166 286 minecraft:shroomlight
setblock 552 166 288 minecraft:shroomlight
setblock 553 166 275 minecraft:shroomlight
setblock 553 166 277 minecraft:shroomlight
setblock 553 166 279 minecraft:shroomlight
setblock 553 166 281 minecraft:shroomlight
setblock 553 166 283 minecraft:shroomlight
setblock 553 166 285 minecraft:shroomlight
setblock 553 166 287 minecraft:shroomlight
setblock 553 166 289 minecraft:shroomlight
fill 553 166 317 556 171 317 minecraft:shroomlight
setblock 554 166 276 minecraft:shroomlight
setblock 554 166 278 minecraft:shroomlight
setblock 554 166 280 minecraft:shroomlight
setblock 554 166 282 minecraft:shroomlight
setblock 554 166 284 minecraft:shroomlight
setblock 554 166 286 minecraft:shroomlight
setblock 554 166 288 minecraft:shroomlight
fill 554 166 300 554 166 302 minecraft:red_concrete
setblock 555 166 275 minecraft:shroomlight
setblock 555 166 277 minecraft:shroomlight
setblock 555 166 279 minecraft:shroomlight
setblock 555 166 281 minecraft:shroomlight
setblock 555 166 283 minecraft:shroomlight
setblock 555 166 285 minecraft:shroomlight
setblock 555 166 287 minecraft:shroomlight
setblock 555 166 289 minecraft:shroomlight
setblock 556 166 276 minecraft:shroomlight
setblock 556 166 278 minecraft:shroomlight
setblock 556 166 280 minecraft:shroomlight
setblock 556 166 282 minecraft:shroomlight
setblock 556 166 284 minecraft:shroomlight
setblock 556 166 286 minecraft:shroomlight
setblock 556 166 288 minecraft:shroomlight
setblock 557 166 275 minecraft:shroomlight
setblock 557 166 277 minecraft:shroomlight
setblock 557 166 279 minecraft:shroomlight
setblock 557 166 281 minecraft:shroomlight
setblock 557 166 283 minecraft:shroomlight
setblock 557 166 285 minecraft:shroomlight
setblock 557 166 287 minecraft:shroomlight
setblock 557 166 289 minecraft:shroomlight
fill 558 166 276 559 166 276 minecraft:shroomlight
fill 558 166 277 558 169 277 minecraft:white_concrete
fill 558 166 278 559 166 278 minecraft:shroomlight
fill 558 166 279 558 169 279 minecraft:white_concrete
setblock 558 166 280 minecraft:shroomlight
fill 558 166 281 559 166 281 minecraft:white_concrete
setblock 558 166 282 minecraft:shroomlight
setblock 558 166 284 minecraft:shroomlight
setblock 558 166 286 minecraft:shroomlight
fill 558 166 288 559 166 288 minecraft:shroomlight
fill 558 166 289 558 174 289 minecraft:white_concrete
setblock 559 166 275 minecraft:white_concrete
fill 559 166 277 559 172 277 minecraft:shroomlight
fill 559 166 279 559 171 279 minecraft:shroomlight
setblock 559 166 285 minecraft:white_concrete
fill 559 166 289 559 171 291 minecraft:shroomlight
setblock 559 166 293 minecraft:white_concrete
setblock 559 166 297 minecraft:white_concrete
fill 559 166 300 559 171 303 minecraft:shroomlight
setblock 559 166 305 minecraft:white_concrete
setblock 559 166 309 minecraft:white_concrete
fill 559 166 312 559 171 315 minecraft:shroomlight
setblock 559 166 317 minecraft:white_concrete
setblock 517 167 276 minecraft:white_concrete
fill 517 167 277 517 174 277 minecraft:brown_terracotta
setblock 517 167 278 minecraft:white_concrete
setblock 517 167 280 minecraft:white_concrete
fill 517 167 285 517 174 285 minecraft:brown_terracotta
setblock 517 167 286 minecraft:white_concrete
setblock 517 167 288 minecraft:white_concrete
fill 517 167 289 517 174 289 minecraft:brown_terracotta
setblock 517 167 290 minecraft:white_concrete
setblock 517 167 292 minecraft:white_concrete
fill 517 167 297 517 174 297 minecraft:brown_terracotta
setblock 517 167 298 minecraft:white_concrete
setblock 517 167 300 minecraft:white_concrete
fill 517 167 301 517 174 301 minecraft:brown_terracotta
setblock 517 167 302 minecraft:white_concrete
setblock 517 167 304 minecraft:white_concrete
fill 517 167 309 517 174 309 minecraft:brown_terracotta
setblock 517 167 310 minecraft:white_concrete
setblock 517 167 312 minecraft:white_concrete
fill 517 167 313 517 174 313 minecraft:brown_terracotta
setblock 517 167 314 minecraft:white_concrete
setblock 517 167 316 minecraft:white_concrete
setblock 518 167 275 minecraft:white_concrete
fill 519 167 275 519 174 275 minecraft:brown_terracotta
setblock 520 167 275 minecraft:white_concrete
setblock 522 167 275 minecraft:white_concrete
setblock 522 167 317 minecraft:white_concrete
fill 523 167 275 523 174 275 minecraft:brown_terracotta
fill 523 167 317 523 174 317 minecraft:brown_terracotta
setblock 524 167 317 minecraft:white_concrete
setblock 526 167 317 minecraft:white_concrete
fill 527 167 317 527 174 317 minecraft:brown_terracotta
setblock 528 167 275 minecraft:white_concrete
setblock 528 167 317 minecraft:white_concrete
setblock 530 167 275 minecraft:white_concrete
fill 531 167 275 531 174 275 minecraft:brown_terracotta
setblock 532 167 275 minecraft:white_concrete
setblock 534 167 275 minecraft:white_concrete
setblock 534 167 317 minecraft:white_concrete
fill 535 167 275 535 174 275 minecraft:brown_terracotta
fill 535 167 317 535 174 317 minecraft:brown_terracotta
setblock 536 167 317 minecraft:white_concrete
setblock 538 167 317 minecraft:white_concrete
fill 539 167 317 539 174 317 minecraft:brown_terracotta
setblock 540 167 275 minecraft:white_concrete
setblock 540 167 317 minecraft:white_concrete
setblock 542 167 275 minecraft:white_concrete
fill 543 167 275 543 174 275 minecraft:brown_terracotta
setblock 544 167 275 minecraft:white_concrete
fill 545 167 311 549 167 315 minecraft:orange_terracotta
setblock 546 167 275 minecraft:white_concrete
setblock 546 167 317 minecraft:white_concrete
fill 547 167 275 547 174 275 minecraft:brown_terracotta
fill 547 167 317 547 174 317 minecraft:brown_terracotta
fill 548 167 284 548 168 284 minecraft:white_concrete
fill 548 167 286 548 168 286 minecraft:white_concrete
fill 548 167 288 548 168 288 minecraft:white_concrete
setblock 548 167 317 minecraft:white_concrete
fill 549 167 283 549 168 283 minecraft:white_concrete
fill 549 167 285 549 168 285 minecraft:white_concrete
fill 549 167 287 549 168 287 minecraft:white_concrete
fill 549 167 289 549 168 289 minecraft:white_concrete
fill 550 167 276 550 169 276 minecraft:white_concrete
fill 550 167 278 550 169 278 minecraft:white_concrete
fill 550 167 280 550 169 280 minecraft:white_concrete
fill 550 167 282 550 169 282 minecraft:white_concrete
fill 550 167 284 550 168 284 minecraft:white_concrete
fill 550 167 286 550 168 286 minecraft:white_concrete
fill 550 167 288 550 168 288 minecraft:white_concrete
setblock 550 167 317 minecraft:white_concrete
fill 551 167 277 551 169 277 minecraft:white_concrete
fill 551 167 279 551 169 279 minecraft:white_concrete
fill 551 167 281 551 169 281 minecraft:white_concrete
fill 551 167 283 551 168 283 minecraft:white_concrete
fill 551 167 285 551 168 285 minecraft:white_concrete
fill 551 167 287 551 168 287 minecraft:white_concrete
fill 551 167 289 551 168 289 minecraft:white_concrete
fill 551 167 317 551 174 317 minecraft:brown_terracotta
fill 552 167 275 552 167 276 minecraft:white_concrete
fill 552 167 278 552 169 278 minecraft:white_concrete
fill 552 167 280 552 169 280 minecraft:white_concrete
fill 552 167 282 552 169 282 minecraft:white_concrete
fill 552 167 284 552 168 284 minecraft:white_concrete
fill 552 167 286 552 168 286 minecraft:white_concrete
fill 552 167 288 552 168 288 minecraft:white_concrete
setblock 552 167 317 minecraft:white_concrete
setblock 553 167 275 minecraft:brown_terracotta
fill 553 167 277 553 169 277 minecraft:white_concrete
fill 553 167 279 553 169 279 minecraft:white_concrete
fill 553 167 281 553 169 281 minecraft:white_concrete
fill 553 167 283 553 168 283 minecraft:white_concrete
fill 553 167 285 553 168 285 minecraft:white_concrete
fill 553 167 287 553 168 287 minecraft:white_concrete
fill 553 167 289 553 168 289 minecraft:white_concrete
fill 554 167 275 554 167 276 minecraft:white_concrete
fill 554 167 278 554 169 278 minecraft:white_concrete
fill 554 167 280 554 169 280 minecraft:white_concrete
fill 554 167 282 554 169 282 minecraft:white_concrete
fill 554 167 284 554 168 284 minecraft:white_concrete
fill 554 167 286 554 168 286 minecraft:white_concrete
fill 554 167 288 554 168 288 minecraft:white_concrete
fill 555 167 275 555 174 275 minecraft:brown_terracotta
fill 555 167 277 555 169 277 minecraft:white_concrete
fill 555 167 279 555 169 279 minecraft:white_concrete
fill 555 167 281 555 169 281 minecraft:white_concrete
fill 555 167 283 555 168 283 minecraft:white_concrete
fill 555 167 285 555 168 285 minecraft:white_concrete
fill 555 167 287 555 168 287 minecraft:white_concrete
fill 555 167 289 555 168 289 minecraft:white_concrete
fill 556 167 275 556 167 276 minecraft:white_concrete
fill 556 167 278 556 169 278 minecraft:white_concrete
fill 556 167 280 556 169 280 minecraft:white_concrete
fill 556 167 282 556 169 282 minecraft:white_concrete
fill 556 167 284 556 168 284 minecraft:white_concrete
fill 556 167 286 556 168 286 minecraft:white_concrete
fill 556 167 288 556 168 288 minecraft:white_concrete
setblock 557 167 275 minecraft:brown_terracotta
fill 557 167 277 557 169 277 minecraft:white_concrete
fill 557 167 279 557 169 279 minecraft:white_concrete
fill 557 167 281 558 169 281 minecraft:white_concrete
fill 557 167 283 557 168 283 minecraft:white_concrete
fill 557 167 285 557 168 285 minecraft:white_concrete
fill 557 167 287 557 168 287 minecraft:white_concrete
fill 557 167 289 557 168 289 minecraft:white_concrete
fill 558 167 275 558 167 276 minecraft:white_concrete
fill 558 167 278 558 169 278 minecraft:white_concrete
fill 558 167 280 559 167 280 minecraft:white_concrete
fill 558 167 282 559 167 282 minecraft:white_concrete
fill 558 167 284 559 167 284 minecraft:white_concrete
fill 558 167 286 559 167 286 minecraft:white_concrete
fill 558 167 288 558 168 288 minecraft:white_concrete
setblock 558 167 317 minecraft:white_concrete
setblock 559 167 275 minecraft:brown_terracotta
fill 559 167 276 559 171 276 minecraft:shroomlight
fill 559 167 278 559 172 278 minecraft:shroomlight
fill 559 167 281 559 174 281 minecraft:brown_terracotta
fill 559 167 285 559 174 285 minecraft:brown_terracotta
fill 559 167 288 559 171 288 minecraft:shroomlight
setblock 559 167 292 minecraft:white_concrete
fill 559 167 293 559 174 293 minecraft:brown_terracotta
setblock 559 167 294 minecraft:white_concrete
setblock 559 167 296 minecraft:white_concrete
fill 559 167 297 559 174 297 minecraft:brown_terracotta
setblock 559 167 298 minecraft:white_concrete
setblock 559 167 304 minecraft:white_concrete
fill 559 167 305 559 174 305 minecraft:brown_terracotta
setblock 559 167 306 minecraft:white_concrete
setblock 559 167 308 minecraft:white_concrete
fill 559 167 309 559 174 309 minecraft:brown_terracotta
setblock 559 167 310 minecraft:white_concrete
setblock 559 167 316 minecraft:white_concrete
fill 559 167 317 559 174 317 minecraft:brown_terracotta
setblock 517 168 275 minecraft:white_concrete
fill 517 168 276 517 175 276 minecraft:brown_terracotta
fill 517 168 278 517 175 278 minecraft:brown_terracotta
setblock 517 168 279 minecraft:white_concrete
fill 517 168 280 517 175 280 minecraft:brown_terracotta
fill 517 168 286 517 175 286 minecraft:brown_terracotta
setblock 517 168 287 minecraft:white_concrete
fill 517 168 288 517 175 288 minecraft:brown_terracotta
fill 517 168 290 517 175 290 minecraft:brown_terracotta
setblock 517 168 291 minecraft:white_concrete
fill 517 168 292 517 175 292 minecraft:brown_terracotta
fill 517 168 298 517 175 298 minecraft:brown_terracotta
setblock 517 168 299 minecraft:white_concrete
fill 517 168 300 517 175 300 minecraft:brown_terracotta
fill 517 168 302 517 175 302 minecraft:brown_terracotta
setblock 517 168 303 minecraft:white_concrete
fill 517 168 304 517 175 304 minecraft:brown_terracotta
fill 517 168 310 517 175 310 minecraft:brown_terracotta
setblock 517 168 311 minecraft:white_concrete
fill 517 168 312 517 175 312 minecraft:brown_terracotta
fill 517 168 314 517 175 314 minecraft:brown_terracotta
setblock 517 168 315 minecraft:white_concrete
fill 517 168 316 517 175 316 minecraft:brown_terracotta
fill 518 168 275 518 175 275 minecraft:brown_terracotta
fill 520 168 275 520 175 275 minecraft:brown_terracotta
setblock 521 168 275 minecraft:white_concrete
setblock 521 168 317 minecraft:white_concrete
fill 522 168 275 522 175 275 minecraft:brown_terracotta
fill 522 168 317 522 175 317 minecraft:brown_terracotta
fill 524 168 317 524 175 317 minecraft:brown_terracotta
setblock 525 168 317 minecraft:white_concrete
fill 526 168 317 526 175 317 minecraft:brown_terracotta
fill 528 168 275 528 175 275 minecraft:brown_terracotta
fill 528 168 317 528 175 317 minecraft:brown_terracotta
setblock 529 168 275 minecraft:white_concrete
fill 530 168 275 530 175 275 minecraft:brown_terracotta
fill 532 168 275 532 175 275 minecraft:brown_terracotta
setblock 533 168 275 minecraft:white_concrete
setblock 533 168 317 minecraft:white_concrete
fill 534 168 275 534 175 275 minecraft:brown_terracotta
fill 534 168 317 534 175 317 minecraft:brown_terracotta
fill 536 168 317 536 175 317 minecraft:brown_terracotta
setblock 537 168 317 minecraft:white_concrete
fill 538 168 317 538 175 317 minecraft:brown_terracotta
fill 540 168 275 540 175 275 minecraft:brown_terracotta
fill 540 168 317 540 175 317 minecraft:brown_terracotta
setblock 541 168 275 minecraft:white_concrete
fill 542 168 275 542 175 275 minecraft:brown_terracotta
fill 544 168 275 544 175 275 minecraft:brown_terracotta
setblock 545 168 275 minecraft:white_concrete
fill 545 168 311 546 171 315 minecraft:orange_terracotta
setblock 545 168 317 minecraft:white_concrete
fill 546 168 275 546 175 275 minecraft:brown_terracotta
fill 546 168 317 546 175 317 minecraft:brown_terracotta
fill 547 168 311 549 171 312 minecraft:orange_terracotta
fill 547 168 313 547 169 313 minecraft:ochre_froglight
fill 547 168 314 549 171 315 minecraft:orange_terracotta
fill 548 168 313 549 171 313 minecraft:orange_terracotta
fill 548 168 317 548 175 317 minecraft:brown_terracotta
setblock 549 168 317 minecraft:white_concrete
fill 550 168 317 550 175 317 minecraft:brown_terracotta
fill 552 168 275 552 175 275 minecraft:brown_terracotta
fill 552 168 276 552 169 276 minecraft:white_concrete
fill 552 168 317 552 175 317 minecraft:brown_terracotta
setblock 553 168 275 minecraft:white_concrete
fill 554 168 275 554 175 275 minecraft:brown_terracotta
fill 554 168 276 554 213 276 minecraft:white_concrete
fill 556 168 275 556 175 275 minecraft:brown_terracotta
fill 556 168 276 556 213 276 minecraft:white_concrete
setblock 557 168 275 minecraft:white_concrete
setblock 557 168 317 minecraft:white_concrete
fill 558 168 275 558 175 275 minecraft:brown_terracotta
fill 558 168 276 558 169 276 minecraft:white_concrete
fill 558 168 280 558 169 280 minecraft:white_concrete
fill 558 168 282 558 169 282 minecraft:white_concrete
setblock 558 168 284 minecraft:white_concrete
setblock 558 168 286 minecraft:white_concrete
fill 558 168 317 558 175 317 minecraft:brown_terracotta
setblock 559 168 275 minecraft:white_concrete
fill 559 168 280 559 175 280 minecraft:brown_terracotta
fill 559 168 282 559 175 282 minecraft:brown_terracotta
setblock 559 168 283 minecraft:white_concrete
fill 559 168 284 559 175 284 minecraft:brown_terracotta
fill 559 168 286 559 175 286 minecraft:brown_terracotta
setblock 559 168 287 minecraft:white_concrete
fill 559 168 292 559 175 292 minecraft:brown_terracotta
fill 559 168 294 559 175 294 minecraft:brown_terracotta
setblock 559 168 295 minecraft:white_concrete
fill 559 168 296 559 175 296 minecraft:brown_terracotta
fill 559 168 298 559 175 298 minecraft:brown_terracotta
setblock 559 168 299 minecraft:white_concrete
fill 559 168 304 559 175 304 minecraft:brown_terracotta
fill 559 168 306 559 175 306 minecraft:brown_terracotta
setblock 559 168 307 minecraft:white_concrete
fill 559 168 308 559 175 308 minecraft:brown_terracotta
fill 559 168 310 559 175 310 minecraft:brown_terracotta
setblock 559 168 311 minecraft:white_concrete
fill 559 168 316 559 175 316 minecraft:brown_terracotta
fill 517 169 275 517 176 275 minecraft:brown_terracotta
fill 517 169 279 517 176 279 minecraft:brown_terracotta
fill 517 169 287 517 176 287 minecraft:brown_terracotta
fill 517 169 291 517 176 291 minecraft:brown_terracotta
fill 517 169 299 517 176 299 minecraft:brown_terracotta
fill 517 169 303 517 176 303 minecraft:brown_terracotta
fill 517 169 311 517 176 311 minecraft:brown_terracotta
fill 517 169 315 517 176 315 minecraft:brown_terracotta
setblock 520 169 278 minecraft:light[level=12]
setblock 520 169 285 minecraft:light[level=12]
setblock 520 169 292 minecraft:light[level=12]
setblock 520 169 299 minecraft:light[level=12]
setblock 520 169 306 minecraft:light[level=12]
setblock 520 169 313 minecraft:light[level=12]
fill 521 169 275 521 176 275 minecraft:brown_terracotta
fill 521 169 317 521 176 317 minecraft:brown_terracotta
fill 525 169 317 525 176 317 minecraft:brown_terracotta
setblock 527 169 278 minecraft:light[level=12]
setblock 527 169 285 minecraft:light[level=12]
setblock 527 169 292 minecraft:light[level=12]
setblock 527 169 299 minecraft:light[level=12]
setblock 527 169 306 minecraft:light[level=12]
setblock 527 169 313 minecraft:light[level=12]
fill 529 169 275 529 176 275 minecraft:brown_terracotta
fill 533 169 275 533 176 275 minecraft:brown_terracotta
fill 533 169 317 533 176 317 minecraft:brown_terracotta
setblock 534 169 278 minecraft:light[level=12]
setblock 534 169 285 minecraft:light[level=12]
setblock 534 169 292 minecraft:light[level=12]
setblock 534 169 306 minecraft:light[level=12]
setblock 534 169 313 minecraft:light[level=12]
fill 537 169 286 539 170 286 minecraft:white_concrete
fill 537 169 317 537 176 317 minecraft:brown_terracotta
fill 538 169 285 539 170 285 minecraft:white_concrete
fill 541 169 275 541 176 275 minecraft:brown_terracotta
setblock 541 169 278 minecraft:light[level=12]
setblock 541 169 285 minecraft:light[level=12]
setblock 541 169 292 minecraft:light[level=12]
setblock 541 169 299 minecraft:light[level=12]
setblock 541 169 306 minecraft:light[level=12]
setblock 541 169 313 minecraft:light[level=12]
fill 545 169 275 545 176 275 minecraft:brown_terracotta
fill 545 169 317 545 176 317 minecraft:brown_terracotta
setblock 548 169 278 minecraft:light[level=12]
setblock 548 169 284 minecraft:shroomlight
setblock 548 169 286 minecraft:shroomlight
setblock 548 169 288 minecraft:shroomlight
setblock 548 169 292 minecraft:light[level=12]
setblock 548 169 299 minecraft:light[level=12]
setblock 548 169 306 minecraft:light[level=12]
setblock 549 169 283 minecraft:shroomlight
setblock 549 169 285 minecraft:shroomlight
setblock 549 169 287 minecraft:shroomlight
setblock 549 169 289 minecraft:shroomlight
fill 549 169 317 549 176 317 minecraft:brown_terracotta
setblock 550 169 284 minecraft:shroomlight
setblock 550 169 286 minecraft:shroomlight
setblock 550 169 288 minecraft:shroomlight
setblock 551 169 283 minecraft:shroomlight
setblock 551 169 285 minecraft:shroomlight
setblock 551 169 287 minecraft:shroomlight
setblock 551 169 289 minecraft:shroomlight
setblock 552 169 284 minecraft:shroomlight
setblock 552 169 286 minecraft:shroomlight
setblock 552 169 288 minecraft:shroomlight
fill 553 169 275 553 176 275 minecraft:brown_terracotta
setblock 553 169 283 minecraft:shroomlight
setblock 553 169 285 minecraft:shroomlight
setblock 553 169 287 minecraft:shroomlight
setblock 553 169 289 minecraft:shroomlight
setblock 554 169 284 minecraft:shroomlight
setblock 554 169 286 minecraft:shroomlight
setblock 554 169 288 minecraft:shroomlight
setblock 555 169 283 minecraft:shroomlight
setblock 555 169 285 minecraft:shroomlight
setblock 555 169 287 minecraft:shroomlight
setblock 555 169 289 minecraft:shroomlight
setblock 555 169 292 minecraft:light[level=12]
setblock 555 169 299 minecraft:light[level=12]
setblock 555 169 306 minecraft:light[level=12]
setblock 555 169 313 minecraft:light[level=12]
setblock 556 169 284 minecraft:shroomlight
setblock 556 169 286 minecraft:shroomlight
setblock 556 169 288 minecraft:shroomlight
fill 557 169 275 557 176 275 minecraft:brown_terracotta
setblock 557 169 283 minecraft:shroomlight
setblock 557 169 285 minecraft:shroomlight
setblock 557 169 287 minecraft:shroomlight
setblock 557 169 289 minecraft:shroomlight
fill 557 169 317 557 176 317 minecraft:brown_terracotta
setblock 558 169 284 minecraft:shroomlight
setblock 558 169 286 minecraft:shroomlight
setblock 558 169 288 minecraft:shroomlight
fill 559 169 275 559 174 275 minecraft:brown_terracotta
fill 559 169 283 559 176 283 minecraft:brown_terracotta
fill 559 169 287 559 176 287 minecraft:brown_terracotta
fill 559 169 295 559 176 295 minecraft:brown_terracotta
fill 559 169 299 559 176 299 minecraft:brown_terracotta
fill 559 169 307 559 176 307 minecraft:brown_terracotta
fill 559 169 311 559 176 311 minecraft:brown_terracotta
fill 547 170 313 547 171 313 minecraft:orange_terracotta
fill 548 170 284 548 171 284 minecraft:white_concrete
fill 548 170 286 548 171 286 minecraft:white_concrete
fill 548 170 288 548 171 288 minecraft:white_concrete
fill 549 170 283 549 171 283 minecraft:white_concrete
fill 549 170 285 549 171 285 minecraft:white_concrete
fill 549 170 287 549 171 287 minecraft:white_concrete
fill 549 170 289 549 171 289 minecraft:white_concrete
fill 550 170 284 550 171 284 minecraft:white_concrete
fill 550 170 286 550 171 286 minecraft:white_concrete
fill 550 170 288 550 171 288 minecraft:white_concrete
fill 551 170 276 553 170 282 minecraft:red_concrete
fill 551 170 283 551 171 283 minecraft:white_concrete
fill 551 170 285 551 171 285 minecraft:white_concrete
fill 551 170 287 551 171 287 minecraft:white_concrete
fill 551 170 289 551 171 289 minecraft:white_concrete
fill 552 170 284 552 171 284 minecraft:white_concrete
fill 552 170 286 552 171 286 minecraft:white_concrete
fill 552 170 288 552 171 288 minecraft:white_concrete
fill 553 170 283 553 171 283 minecraft:white_concrete
fill 553 170 285 553 171 285 minecraft:white_concrete
fill 553 170 287 553 171 287 minecraft:white_concrete
fill 553 170 289 553 171 289 minecraft:white_concrete
fill 554 170 277 557 170 282 minecraft:red_concrete
fill 554 170 284 554 171 284 minecraft:white_concrete
fill 554 170 286 554 171 286 minecraft:white_concrete
fill 554 170 288 554 171 288 minecraft:white_concrete
fill 554 170 293 558 170 297 minecraft:orange_terracotta
fill 555 170 283 555 171 283 minecraft:white_concrete
fill 555 170 285 555 171 285 minecraft:white_concrete
fill 555 170 287 555 171 287 minecraft:white_concrete
fill 555 170 289 555 171 289 minecraft:white_concrete
fill 556 170 284 556 171 284 minecraft:white_concrete
fill 556 170 286 556 171 286 minecraft:white_concrete
fill 556 170 288 556 171 288 minecraft:white_concrete
setblock 557 170 276 minecraft:red_concrete
fill 557 170 283 557 171 283 minecraft:white_concrete
fill 557 170 285 557 171 285 minecraft:white_concrete
fill 557 170 287 557 171 287 minecraft:white_concrete
fill 557 170 289 557 171 289 minecraft:white_concrete
fill 558 170 284 558 171 284 minecraft:white_concrete
fill 558 170 286 558 171 286 minecraft:white_concrete
fill 558 170 288 558 171 288 minecraft:white_concrete
fill 518 171 295 518 172 297 minecraft:white_concrete
fill 552 171 276 553 171 281 minecraft:red_concrete
fill 554 171 277 556 171 281 minecraft:red_concrete
fill 554 171 293 555 174 297 minecraft:orange_terracotta
fill 556 171 293 558 174 294 minecraft:orange_terracotta
fill 556 171 295 556 172 295 minecraft:ochre_froglight
fill 556 171 296 558 174 297 minecraft:orange_terracotta
fill 557 171 295 558 174 295 minecraft:orange_terracotta
fill 517 172 281 517 174 281 minecraft:brown_terracotta
fill 517 172 282 517 172 283 minecraft:shroomlight
schedule function dropper:buildpart/71_4 1t
