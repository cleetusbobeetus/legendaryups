setblock 491 112 276 minecraft:cobbled_deepslate
setblock 491 112 316 minecraft:cobbled_deepslate
fill 492 112 276 492 115 276 minecraft:deepslate_tiles
fill 492 112 316 492 115 316 minecraft:deepslate_tiles
setblock 496 112 276 minecraft:cobbled_deepslate
setblock 496 112 315 minecraft:deepslate_tiles
setblock 496 112 316 minecraft:cobbled_deepslate
fill 497 112 276 497 115 276 minecraft:deepslate_tiles
setblock 497 112 315 minecraft:cobbled_deepslate
fill 497 112 316 497 115 316 minecraft:deepslate_tiles
fill 498 112 277 498 113 277 minecraft:deepslate_tiles
fill 498 112 315 498 115 315 minecraft:deepslate_tiles
fill 499 112 314 499 115 314 minecraft:deepslate_tiles
setblock 500 112 277 minecraft:cobbled_deepslate
setblock 501 112 276 minecraft:cobbled_deepslate
fill 501 112 277 501 115 277 minecraft:deepslate_tiles
setblock 501 112 316 minecraft:cobbled_deepslate
fill 502 112 276 502 115 276 minecraft:deepslate_tiles
setblock 502 112 315 minecraft:cobbled_deepslate
fill 502 112 316 502 115 316 minecraft:deepslate_tiles
setblock 503 112 314 minecraft:cobbled_deepslate
fill 503 112 315 503 115 315 minecraft:deepslate_tiles
setblock 504 112 313 minecraft:cobbled_deepslate
fill 504 112 314 504 115 314 minecraft:deepslate_tiles
setblock 505 112 277 minecraft:cobbled_deepslate
setblock 506 112 276 minecraft:cobbled_deepslate
setblock 506 112 316 minecraft:cobbled_deepslate
fill 507 112 276 507 115 276 minecraft:deepslate_tiles
setblock 507 112 315 minecraft:cobbled_deepslate
fill 507 112 316 507 115 316 minecraft:deepslate_tiles
setblock 508 112 314 minecraft:cobbled_deepslate
fill 508 112 315 508 115 315 minecraft:deepslate_tiles
setblock 510 112 312 minecraft:cobbled_deepslate
setblock 510 112 313 minecraft:deepslate_tiles
setblock 511 112 311 minecraft:cobbled_deepslate
fill 511 112 312 511 115 312 minecraft:deepslate_tiles
setblock 511 112 316 minecraft:cobbled_deepslate
fill 471 113 291 471 116 291 minecraft:deepslate_tiles
setblock 471 113 295 minecraft:cobbled_deepslate
fill 471 113 296 471 116 296 minecraft:deepslate_tiles
fill 472 113 295 472 116 295 minecraft:deepslate_tiles
fill 473 113 317 473 201 317 minecraft:black_concrete
fill 477 113 316 479 113 316 minecraft:deepslate_tiles
fill 478 113 276 478 114 276 minecraft:deepslate_tiles
setblock 480 113 276 minecraft:cobbled_deepslate
fill 480 113 277 481 115 277 minecraft:deepslate_tiles
setblock 480 113 316 minecraft:cobbled_deepslate
fill 481 113 276 481 116 276 minecraft:deepslate_tiles
setblock 481 113 315 minecraft:cobbled_deepslate
fill 481 113 316 481 116 316 minecraft:deepslate_tiles
fill 482 113 315 482 116 315 minecraft:deepslate_tiles
setblock 484 113 277 minecraft:cobbled_deepslate
setblock 485 113 276 minecraft:cobbled_deepslate
fill 485 113 277 485 116 277 minecraft:deepslate_tiles
setblock 485 113 316 minecraft:cobbled_deepslate
fill 486 113 276 489 113 276 minecraft:deepslate_tiles
fill 486 113 316 489 113 316 minecraft:deepslate_tiles
setblock 490 113 276 minecraft:cobbled_deepslate
setblock 490 113 316 minecraft:cobbled_deepslate
fill 491 113 276 491 116 276 minecraft:deepslate_tiles
fill 491 113 316 491 116 316 minecraft:deepslate_tiles
setblock 495 113 276 minecraft:cobbled_deepslate
setblock 495 113 316 minecraft:cobbled_deepslate
fill 496 113 276 496 116 276 minecraft:deepslate_tiles
setblock 496 113 315 minecraft:cobbled_deepslate
fill 496 113 316 496 116 316 minecraft:deepslate_tiles
fill 497 113 277 497 114 277 minecraft:deepslate_tiles
fill 497 113 315 497 116 315 minecraft:deepslate_tiles
setblock 499 113 277 minecraft:cobbled_deepslate
setblock 500 113 276 minecraft:cobbled_deepslate
fill 500 113 277 500 116 277 minecraft:deepslate_tiles
setblock 500 113 316 minecraft:cobbled_deepslate
fill 501 113 276 501 116 276 minecraft:deepslate_tiles
setblock 501 113 315 minecraft:cobbled_deepslate
fill 501 113 316 501 116 316 minecraft:deepslate_tiles
setblock 502 113 314 minecraft:cobbled_deepslate
fill 502 113 315 502 116 315 minecraft:deepslate_tiles
fill 503 113 314 503 116 314 minecraft:deepslate_tiles
setblock 504 113 277 minecraft:cobbled_deepslate
setblock 505 113 276 minecraft:cobbled_deepslate
fill 505 113 277 505 116 277 minecraft:deepslate_tiles
setblock 505 113 316 minecraft:cobbled_deepslate
fill 506 113 276 506 116 276 minecraft:deepslate_tiles
setblock 506 113 315 minecraft:cobbled_deepslate
fill 506 113 316 506 116 316 minecraft:deepslate_tiles
setblock 507 113 314 minecraft:cobbled_deepslate
fill 507 113 315 507 116 315 minecraft:deepslate_tiles
setblock 510 113 316 minecraft:cobbled_deepslate
setblock 511 113 295 minecraft:cobbled_deepslate
fill 511 113 296 511 115 297 minecraft:deepslate_tiles
setblock 511 113 311 minecraft:deepslate_tiles
setblock 511 113 315 minecraft:cobbled_deepslate
fill 511 113 316 511 116 316 minecraft:deepslate_tiles
setblock 471 114 294 minecraft:cobbled_deepslate
fill 471 114 295 471 117 295 minecraft:deepslate_tiles
setblock 471 114 299 minecraft:cobbled_deepslate
fill 471 114 300 471 117 300 minecraft:deepslate_tiles
fill 472 114 294 472 117 294 minecraft:deepslate_tiles
fill 472 114 296 472 114 297 minecraft:deepslate_tiles
fill 476 114 276 477 115 276 minecraft:deepslate_tiles
fill 477 114 316 478 114 316 minecraft:deepslate_tiles
setblock 479 114 276 minecraft:cobbled_deepslate
fill 479 114 277 479 117 277 minecraft:deepslate_tiles
setblock 479 114 316 minecraft:cobbled_deepslate
fill 480 114 276 480 117 276 minecraft:deepslate_tiles
setblock 480 114 315 minecraft:cobbled_deepslate
fill 480 114 316 480 117 316 minecraft:deepslate_tiles
fill 481 114 315 481 117 315 minecraft:deepslate_tiles
setblock 483 114 276 minecraft:deepslate_tiles
setblock 483 114 277 minecraft:cobbled_deepslate
setblock 484 114 276 minecraft:cobbled_deepslate
fill 484 114 277 484 117 277 minecraft:deepslate_tiles
setblock 484 114 316 minecraft:cobbled_deepslate
fill 485 114 276 488 114 276 minecraft:deepslate_tiles
fill 485 114 316 488 114 316 minecraft:deepslate_tiles
setblock 488 114 277 minecraft:cobbled_deepslate
setblock 489 114 276 minecraft:cobbled_deepslate
setblock 489 114 316 minecraft:cobbled_deepslate
fill 490 114 276 490 117 276 minecraft:deepslate_tiles
fill 490 114 316 490 117 316 minecraft:deepslate_tiles
setblock 494 114 276 minecraft:cobbled_deepslate
setblock 494 114 316 minecraft:cobbled_deepslate
fill 495 114 276 495 116 277 minecraft:deepslate_tiles
setblock 495 114 315 minecraft:cobbled_deepslate
fill 495 114 316 495 117 316 minecraft:deepslate_tiles
fill 496 114 277 496 115 277 minecraft:deepslate_tiles
fill 496 114 315 496 117 315 minecraft:deepslate_tiles
setblock 498 114 277 minecraft:cobbled_deepslate
fill 498 114 314 498 116 314 minecraft:deepslate_tiles
setblock 499 114 276 minecraft:cobbled_deepslate
fill 499 114 277 499 117 277 minecraft:deepslate_tiles
setblock 499 114 316 minecraft:cobbled_deepslate
fill 500 114 276 500 117 276 minecraft:deepslate_tiles
setblock 500 114 315 minecraft:cobbled_deepslate
fill 500 114 316 500 117 316 minecraft:deepslate_tiles
setblock 501 114 314 minecraft:cobbled_deepslate
fill 501 114 315 501 117 315 minecraft:deepslate_tiles
fill 502 114 314 502 117 314 minecraft:deepslate_tiles
setblock 503 114 277 minecraft:cobbled_deepslate
setblock 504 114 276 minecraft:cobbled_deepslate
fill 504 114 277 504 117 277 minecraft:deepslate_tiles
setblock 504 114 316 minecraft:cobbled_deepslate
fill 505 114 276 505 117 276 minecraft:deepslate_tiles
setblock 505 114 315 minecraft:cobbled_deepslate
fill 505 114 316 505 117 316 minecraft:deepslate_tiles
setblock 506 114 314 minecraft:cobbled_deepslate
fill 506 114 315 506 117 315 minecraft:deepslate_tiles
setblock 509 114 316 minecraft:cobbled_deepslate
fill 510 114 316 510 117 316 minecraft:deepslate_tiles
setblock 511 114 294 minecraft:cobbled_deepslate
fill 511 114 295 511 117 295 minecraft:deepslate_tiles
setblock 511 114 298 minecraft:deepslate_tiles
setblock 511 114 299 minecraft:cobbled_deepslate
setblock 511 114 314 minecraft:cobbled_deepslate
fill 511 114 315 511 117 315 minecraft:deepslate_tiles
setblock 471 115 293 minecraft:cobbled_deepslate
fill 471 115 294 471 118 294 minecraft:deepslate_tiles
setblock 471 115 298 minecraft:cobbled_deepslate
fill 471 115 299 471 118 299 minecraft:deepslate_tiles
fill 471 115 301 471 116 301 minecraft:deepslate_tiles
fill 472 115 293 472 118 293 minecraft:deepslate_tiles
setblock 472 115 296 minecraft:deepslate_tiles
setblock 472 115 297 minecraft:cobbled_deepslate
fill 472 115 298 472 118 298 minecraft:deepslate_tiles
setblock 473 115 278 minecraft:light[level=12]
setblock 473 115 285 minecraft:light[level=12]
setblock 473 115 292 minecraft:light[level=12]
setblock 473 115 299 minecraft:light[level=12]
setblock 473 115 306 minecraft:light[level=12]
setblock 473 115 313 minecraft:light[level=12]
fill 475 115 276 475 117 276 minecraft:deepslate_tiles
fill 476 115 316 477 115 316 minecraft:deepslate_tiles
setblock 478 115 276 minecraft:cobbled_deepslate
fill 478 115 277 478 118 277 minecraft:deepslate_tiles
setblock 478 115 316 minecraft:cobbled_deepslate
fill 479 115 276 479 118 276 minecraft:deepslate_tiles
fill 479 115 316 479 118 316 minecraft:deepslate_tiles
setblock 480 115 278 minecraft:light[level=12]
setblock 480 115 285 minecraft:light[level=12]
setblock 480 115 292 minecraft:light[level=12]
setblock 480 115 299 minecraft:light[level=12]
setblock 480 115 306 minecraft:light[level=12]
setblock 480 115 313 minecraft:light[level=12]
fill 480 115 315 480 118 315 minecraft:deepslate_tiles
setblock 481 115 278 minecraft:cobbled_deepslate
setblock 482 115 276 minecraft:deepslate_tiles
setblock 482 115 277 minecraft:cobbled_deepslate
fill 482 115 278 484 116 278 minecraft:deepslate_tiles
setblock 483 115 276 minecraft:cobbled_deepslate
fill 483 115 277 483 118 277 minecraft:deepslate_tiles
setblock 483 115 316 minecraft:cobbled_deepslate
fill 484 115 276 487 115 276 minecraft:deepslate_tiles
setblock 484 115 315 minecraft:cobbled_deepslate
fill 484 115 316 487 115 316 minecraft:deepslate_tiles
setblock 487 115 277 minecraft:cobbled_deepslate
setblock 487 115 278 minecraft:light[level=12]
setblock 487 115 285 minecraft:light[level=12]
setblock 487 115 292 minecraft:light[level=12]
setblock 487 115 299 minecraft:light[level=12]
setblock 487 115 306 minecraft:light[level=12]
setblock 487 115 313 minecraft:light[level=12]
setblock 488 115 276 minecraft:cobbled_deepslate
fill 488 115 277 491 115 277 minecraft:deepslate_tiles
setblock 488 115 316 minecraft:cobbled_deepslate
fill 489 115 276 489 118 276 minecraft:deepslate_tiles
fill 489 115 316 489 118 316 minecraft:deepslate_tiles
setblock 492 115 277 minecraft:cobbled_deepslate
setblock 493 115 276 minecraft:cobbled_deepslate
fill 493 115 277 494 117 277 minecraft:deepslate_tiles
setblock 493 115 316 minecraft:cobbled_deepslate
fill 494 115 276 494 118 276 minecraft:deepslate_tiles
setblock 494 115 278 minecraft:light[level=12]
setblock 494 115 285 minecraft:light[level=12]
setblock 494 115 292 minecraft:light[level=12]
setblock 494 115 299 minecraft:light[level=12]
setblock 494 115 306 minecraft:light[level=12]
setblock 494 115 313 minecraft:light[level=12]
fill 494 115 316 494 118 316 minecraft:deepslate_tiles
fill 495 115 315 495 118 315 minecraft:deepslate_tiles
setblock 497 115 277 minecraft:cobbled_deepslate
setblock 498 115 276 minecraft:cobbled_deepslate
fill 498 115 277 498 118 277 minecraft:deepslate_tiles
setblock 498 115 316 minecraft:cobbled_deepslate
fill 499 115 276 499 118 276 minecraft:deepslate_tiles
fill 499 115 278 500 115 278 minecraft:deepslate_tiles
setblock 499 115 315 minecraft:cobbled_deepslate
fill 499 115 316 499 118 316 minecraft:deepslate_tiles
setblock 500 115 314 minecraft:cobbled_deepslate
fill 500 115 315 500 118 315 minecraft:deepslate_tiles
setblock 501 115 278 minecraft:cobbled_deepslate
setblock 501 115 285 minecraft:light[level=12]
setblock 501 115 292 minecraft:light[level=12]
setblock 501 115 299 minecraft:light[level=12]
setblock 501 115 306 minecraft:light[level=12]
setblock 501 115 313 minecraft:light[level=12]
fill 501 115 314 501 118 314 minecraft:deepslate_tiles
setblock 502 115 277 minecraft:cobbled_deepslate
setblock 503 115 276 minecraft:cobbled_deepslate
fill 503 115 277 503 118 277 minecraft:deepslate_tiles
setblock 503 115 316 minecraft:cobbled_deepslate
fill 504 115 276 504 118 276 minecraft:deepslate_tiles
setblock 504 115 315 minecraft:cobbled_deepslate
fill 504 115 316 504 118 316 minecraft:deepslate_tiles
setblock 505 115 314 minecraft:cobbled_deepslate
fill 505 115 315 505 118 315 minecraft:deepslate_tiles
setblock 506 115 314 minecraft:deepslate_tiles
fill 507 115 275 508 197 275 minecraft:black_concrete
setblock 508 115 276 minecraft:cobbled_deepslate
setblock 508 115 278 minecraft:light[level=12]
setblock 508 115 285 minecraft:light[level=12]
setblock 508 115 292 minecraft:light[level=12]
setblock 508 115 299 minecraft:light[level=12]
setblock 508 115 306 minecraft:light[level=12]
setblock 508 115 313 minecraft:light[level=12]
setblock 508 115 316 minecraft:cobbled_deepslate
setblock 509 115 275 minecraft:redstone_block
setblock 509 115 315 minecraft:cobbled_deepslate
fill 509 115 316 509 118 316 minecraft:deepslate_tiles
fill 511 115 294 511 118 294 minecraft:deepslate_tiles
setblock 511 115 298 minecraft:cobbled_deepslate
fill 511 115 299 511 116 301 minecraft:deepslate_tiles
setblock 511 115 313 minecraft:cobbled_deepslate
fill 511 115 314 511 118 314 minecraft:deepslate_tiles
fill 470 116 303 470 198 304 minecraft:black_concrete
setblock 470 116 305 minecraft:redstone_block
setblock 471 116 292 minecraft:cobbled_deepslate
fill 471 116 293 471 119 293 minecraft:deepslate_tiles
setblock 471 116 297 minecraft:cobbled_deepslate
fill 471 116 298 471 119 298 minecraft:deepslate_tiles
setblock 471 116 302 minecraft:cobbled_deepslate
setblock 472 116 296 minecraft:cobbled_deepslate
fill 472 116 297 472 119 297 minecraft:deepslate_tiles
fill 472 116 299 472 116 300 minecraft:deepslate_tiles
fill 474 116 276 474 118 276 minecraft:deepslate_tiles
fill 475 116 316 476 116 316 minecraft:deepslate_tiles
setblock 476 116 276 minecraft:deepslate_tiles
setblock 476 116 277 minecraft:cobbled_deepslate
setblock 477 116 276 minecraft:cobbled_deepslate
fill 477 116 277 477 119 277 minecraft:deepslate_tiles
setblock 477 116 316 minecraft:cobbled_deepslate
fill 478 116 276 478 119 276 minecraft:deepslate_tiles
fill 478 116 316 478 119 316 minecraft:deepslate_tiles
setblock 479 116 278 minecraft:deepslate_tiles
fill 479 116 315 479 119 315 minecraft:deepslate_tiles
setblock 480 116 277 minecraft:deepslate_tiles
setblock 480 116 278 minecraft:cobbled_deepslate
setblock 481 116 277 minecraft:cobbled_deepslate
fill 481 116 278 481 119 278 minecraft:deepslate_tiles
setblock 482 116 276 minecraft:cobbled_deepslate
fill 482 116 277 482 119 277 minecraft:deepslate_tiles
setblock 482 116 316 minecraft:cobbled_deepslate
fill 483 116 276 486 116 276 minecraft:deepslate_tiles
setblock 483 116 315 minecraft:cobbled_deepslate
fill 483 116 316 486 116 316 minecraft:deepslate_tiles
setblock 484 116 315 minecraft:deepslate_tiles
setblock 485 116 278 minecraft:cobbled_deepslate
setblock 486 116 277 minecraft:cobbled_deepslate
setblock 487 116 276 minecraft:cobbled_deepslate
fill 487 116 277 490 116 277 minecraft:deepslate_tiles
setblock 487 116 316 minecraft:cobbled_deepslate
fill 488 116 276 488 119 276 minecraft:deepslate_tiles
fill 488 116 316 488 119 316 minecraft:deepslate_tiles
setblock 491 116 277 minecraft:cobbled_deepslate
setblock 492 116 276 minecraft:cobbled_deepslate
fill 492 116 277 492 119 277 minecraft:deepslate_tiles
setblock 492 116 316 minecraft:cobbled_deepslate
fill 493 116 276 493 119 276 minecraft:deepslate_tiles
fill 493 116 316 493 119 316 minecraft:deepslate_tiles
fill 494 116 315 494 119 315 minecraft:deepslate_tiles
setblock 496 116 277 minecraft:cobbled_deepslate
fill 496 116 278 499 116 278 minecraft:deepslate_tiles
setblock 497 116 276 minecraft:cobbled_deepslate
fill 497 116 277 497 119 277 minecraft:deepslate_tiles
fill 497 116 314 497 117 314 minecraft:deepslate_tiles
setblock 497 116 316 minecraft:cobbled_deepslate
fill 498 116 276 498 119 276 minecraft:deepslate_tiles
setblock 498 116 315 minecraft:cobbled_deepslate
fill 498 116 316 498 119 316 minecraft:deepslate_tiles
setblock 499 116 314 minecraft:cobbled_deepslate
fill 499 116 315 499 119 315 minecraft:deepslate_tiles
setblock 500 116 278 minecraft:cobbled_deepslate
fill 500 116 314 500 119 314 minecraft:deepslate_tiles
setblock 501 116 277 minecraft:cobbled_deepslate
fill 501 116 278 502 118 278 minecraft:deepslate_tiles
setblock 502 116 276 minecraft:cobbled_deepslate
fill 502 116 277 502 119 277 minecraft:deepslate_tiles
setblock 502 116 316 minecraft:cobbled_deepslate
fill 503 116 276 503 119 276 minecraft:deepslate_tiles
setblock 503 116 315 minecraft:cobbled_deepslate
fill 503 116 316 503 119 316 minecraft:deepslate_tiles
setblock 504 116 314 minecraft:cobbled_deepslate
fill 504 116 315 504 119 315 minecraft:deepslate_tiles
fill 505 116 314 505 117 314 minecraft:deepslate_tiles
fill 506 116 317 506 199 317 minecraft:black_concrete
setblock 507 116 276 minecraft:cobbled_deepslate
setblock 507 116 316 minecraft:cobbled_deepslate
setblock 507 116 317 minecraft:redstone_block
fill 508 116 276 509 118 276 minecraft:deepslate_tiles
setblock 508 116 315 minecraft:cobbled_deepslate
fill 508 116 316 508 119 316 minecraft:deepslate_tiles
fill 508 116 317 511 201 317 minecraft:black_concrete
fill 509 116 275 509 190 275 minecraft:black_concrete
setblock 511 116 296 minecraft:deepslate_tiles
setblock 511 116 297 minecraft:cobbled_deepslate
fill 511 116 298 511 119 298 minecraft:deepslate_tiles
setblock 511 116 302 minecraft:cobbled_deepslate
fill 511 116 303 511 119 303 minecraft:deepslate_tiles
fill 511 116 313 511 118 313 minecraft:deepslate_tiles
setblock 470 117 299 minecraft:redstone_block
setblock 470 117 305 minecraft:white_wool
setblock 471 117 291 minecraft:cobbled_deepslate
fill 471 117 292 472 119 292 minecraft:deepslate_tiles
setblock 471 117 296 minecraft:cobbled_deepslate
fill 471 117 297 471 120 297 minecraft:deepslate_tiles
setblock 471 117 301 minecraft:cobbled_deepslate
fill 471 117 302 471 119 303 minecraft:deepslate_tiles
fill 472 117 276 473 119 276 minecraft:deepslate_tiles
setblock 472 117 295 minecraft:cobbled_deepslate
fill 472 117 296 473 119 296 minecraft:deepslate_tiles
setblock 472 117 299 minecraft:deepslate_tiles
setblock 472 117 300 minecraft:cobbled_deepslate
fill 472 117 301 472 120 301 minecraft:deepslate_tiles
setblock 473 117 278 minecraft:light[level=13]
setblock 473 117 286 minecraft:light[level=13]
setblock 473 117 294 minecraft:light[level=13]
fill 473 117 295 473 120 295 minecraft:deepslate_tiles
fill 473 117 297 473 117 298 minecraft:deepslate_tiles
setblock 473 117 299 minecraft:cobbled_deepslate
setblock 473 117 302 minecraft:light[level=13]
setblock 473 117 310 minecraft:light[level=13]
fill 474 117 316 475 117 316 minecraft:deepslate_tiles
setblock 475 117 277 minecraft:cobbled_deepslate
setblock 476 117 276 minecraft:cobbled_deepslate
fill 476 117 277 476 120 277 minecraft:deepslate_tiles
setblock 476 117 316 minecraft:cobbled_deepslate
fill 477 117 276 477 120 276 minecraft:deepslate_tiles
fill 477 117 278 478 117 278 minecraft:deepslate_tiles
fill 477 117 316 477 120 316 minecraft:deepslate_tiles
fill 478 117 315 478 120 315 minecraft:deepslate_tiles
setblock 479 117 278 minecraft:cobbled_deepslate
setblock 480 117 277 minecraft:cobbled_deepslate
fill 480 117 278 480 120 278 minecraft:deepslate_tiles
setblock 481 117 276 minecraft:cobbled_deepslate
fill 481 117 277 481 120 277 minecraft:deepslate_tiles
setblock 481 117 286 minecraft:light[level=13]
setblock 481 117 294 minecraft:light[level=13]
setblock 481 117 302 minecraft:light[level=13]
setblock 481 117 310 minecraft:light[level=13]
setblock 481 117 316 minecraft:cobbled_deepslate
fill 482 117 276 485 117 276 minecraft:deepslate_tiles
fill 482 117 278 483 117 278 minecraft:deepslate_tiles
setblock 482 117 315 minecraft:cobbled_deepslate
fill 482 117 316 485 117 316 minecraft:deepslate_tiles
fill 483 117 315 483 118 315 minecraft:deepslate_tiles
setblock 484 117 278 minecraft:cobbled_deepslate
setblock 485 117 277 minecraft:cobbled_deepslate
fill 485 117 278 486 119 278 minecraft:deepslate_tiles
setblock 486 117 276 minecraft:cobbled_deepslate
fill 486 117 277 489 117 277 minecraft:deepslate_tiles
setblock 486 117 316 minecraft:cobbled_deepslate
fill 487 117 276 487 120 276 minecraft:deepslate_tiles
fill 487 117 316 487 120 316 minecraft:deepslate_tiles
fill 489 117 275 490 125 275 minecraft:black_concrete
setblock 489 117 278 minecraft:light[level=13]
setblock 489 117 286 minecraft:light[level=13]
setblock 489 117 302 minecraft:light[level=13]
setblock 489 117 310 minecraft:light[level=13]
setblock 490 117 277 minecraft:cobbled_deepslate
setblock 491 117 275 minecraft:redstone_block
setblock 491 117 276 minecraft:cobbled_deepslate
fill 491 117 277 491 120 277 minecraft:deepslate_tiles
setblock 491 117 316 minecraft:cobbled_deepslate
fill 492 117 275 500 117 275 minecraft:black_concrete
fill 492 117 276 492 120 276 minecraft:deepslate_tiles
fill 492 117 316 492 120 316 minecraft:deepslate_tiles
fill 493 117 315 493 120 315 minecraft:deepslate_tiles
setblock 494 117 278 minecraft:cobbled_deepslate
setblock 495 117 276 minecraft:deepslate_tiles
setblock 495 117 277 minecraft:cobbled_deepslate
fill 495 117 278 498 117 278 minecraft:deepslate_tiles
setblock 496 117 276 minecraft:cobbled_deepslate
fill 496 117 277 496 120 277 minecraft:deepslate_tiles
fill 496 117 314 496 118 314 minecraft:deepslate_tiles
setblock 496 117 316 minecraft:cobbled_deepslate
fill 497 117 276 497 120 276 minecraft:deepslate_tiles
setblock 497 117 286 minecraft:light[level=13]
setblock 497 117 294 minecraft:light[level=13]
setblock 497 117 302 minecraft:light[level=13]
setblock 497 117 310 minecraft:light[level=13]
setblock 497 117 315 minecraft:cobbled_deepslate
fill 497 117 316 497 120 316 minecraft:deepslate_tiles
setblock 498 117 314 minecraft:cobbled_deepslate
fill 498 117 315 498 120 315 minecraft:deepslate_tiles
setblock 499 117 278 minecraft:cobbled_deepslate
fill 499 117 314 499 120 314 minecraft:deepslate_tiles
setblock 500 117 277 minecraft:cobbled_deepslate
fill 500 117 278 500 120 278 minecraft:deepslate_tiles
setblock 501 117 276 minecraft:cobbled_deepslate
fill 501 117 277 501 120 277 minecraft:deepslate_tiles
setblock 501 117 316 minecraft:cobbled_deepslate
fill 502 117 276 502 120 276 minecraft:deepslate_tiles
setblock 502 117 315 minecraft:cobbled_deepslate
fill 502 117 316 502 120 316 minecraft:deepslate_tiles
setblock 503 117 278 minecraft:deepslate_tiles
setblock 503 117 314 minecraft:cobbled_deepslate
fill 503 117 315 503 120 315 minecraft:deepslate_tiles
fill 504 117 314 504 118 314 minecraft:deepslate_tiles
setblock 505 117 277 minecraft:cobbled_deepslate
setblock 505 117 278 minecraft:light[level=13]
setblock 505 117 286 minecraft:light[level=13]
setblock 505 117 294 minecraft:light[level=13]
setblock 505 117 302 minecraft:light[level=13]
setblock 505 117 310 minecraft:light[level=13]
setblock 506 117 276 minecraft:cobbled_deepslate
fill 506 117 277 506 118 277 minecraft:deepslate_tiles
setblock 506 117 316 minecraft:cobbled_deepslate
fill 507 117 276 507 120 276 minecraft:deepslate_tiles
setblock 507 117 315 minecraft:cobbled_deepslate
fill 507 117 316 507 120 316 minecraft:deepslate_tiles
fill 507 117 317 507 202 317 minecraft:black_concrete
setblock 508 117 315 minecraft:deepslate_tiles
setblock 510 117 296 minecraft:deepslate_tiles
setblock 510 117 297 minecraft:cobbled_deepslate
fill 510 117 298 510 117 301 minecraft:deepslate_tiles
fill 511 117 293 511 119 293 minecraft:deepslate_tiles
setblock 511 117 296 minecraft:cobbled_deepslate
fill 511 117 297 511 120 297 minecraft:deepslate_tiles
fill 511 117 299 511 117 300 minecraft:deepslate_tiles
setblock 511 117 301 minecraft:cobbled_deepslate
fill 511 117 302 511 120 302 minecraft:deepslate_tiles
fill 511 117 304 511 117 305 minecraft:deepslate_tiles
setblock 511 117 316 minecraft:cobbled_deepslate
setblock 470 118 276 minecraft:redstone_block
fill 470 118 277 470 157 279 minecraft:black_concrete
fill 470 118 299 470 201 299 minecraft:black_concrete
fill 470 118 305 470 201 305 minecraft:black_concrete
fill 471 118 276 471 118 279 minecraft:deepslate_tiles
setblock 471 118 290 minecraft:cobbled_deepslate
fill 471 118 291 471 121 291 minecraft:deepslate_tiles
setblock 471 118 295 minecraft:cobbled_deepslate
fill 471 118 296 471 121 296 minecraft:deepslate_tiles
setblock 471 118 300 minecraft:cobbled_deepslate
fill 471 118 301 471 121 301 minecraft:deepslate_tiles
setblock 471 118 304 minecraft:deepslate_tiles
setblock 472 118 294 minecraft:cobbled_deepslate
fill 472 118 295 472 121 295 minecraft:deepslate_tiles
setblock 472 118 299 minecraft:cobbled_deepslate
fill 472 118 300 473 120 300 minecraft:deepslate_tiles
fill 472 118 302 472 119 302 minecraft:deepslate_tiles
fill 473 118 294 473 121 294 minecraft:deepslate_tiles
setblock 473 118 297 minecraft:deepslate_tiles
setblock 473 118 298 minecraft:cobbled_deepslate
fill 473 118 299 473 121 299 minecraft:deepslate_tiles
fill 473 118 316 474 118 316 minecraft:deepslate_tiles
setblock 474 118 277 minecraft:cobbled_deepslate
setblock 475 118 276 minecraft:cobbled_deepslate
fill 475 118 277 475 121 277 minecraft:deepslate_tiles
setblock 475 118 316 minecraft:cobbled_deepslate
fill 476 118 276 476 121 276 minecraft:deepslate_tiles
fill 476 118 278 477 118 278 minecraft:deepslate_tiles
fill 476 118 316 476 121 316 minecraft:deepslate_tiles
setblock 478 118 278 minecraft:cobbled_deepslate
fill 478 118 279 481 118 279 minecraft:deepslate_tiles
setblock 479 118 277 minecraft:cobbled_deepslate
fill 479 118 278 479 121 278 minecraft:deepslate_tiles
setblock 480 118 276 minecraft:cobbled_deepslate
fill 480 118 277 480 121 277 minecraft:deepslate_tiles
setblock 480 118 316 minecraft:cobbled_deepslate
fill 481 118 276 484 118 276 minecraft:deepslate_tiles
setblock 481 118 315 minecraft:cobbled_deepslate
fill 481 118 316 484 118 316 minecraft:deepslate_tiles
setblock 482 118 278 minecraft:deepslate_tiles
setblock 482 118 279 minecraft:cobbled_deepslate
fill 482 118 315 482 119 315 minecraft:deepslate_tiles
setblock 483 118 278 minecraft:cobbled_deepslate
fill 483 118 279 483 121 279 minecraft:deepslate_tiles
setblock 484 118 277 minecraft:cobbled_deepslate
fill 484 118 278 484 121 278 minecraft:deepslate_tiles
setblock 485 118 276 minecraft:cobbled_deepslate
fill 485 118 277 488 118 277 minecraft:deepslate_tiles
setblock 485 118 316 minecraft:cobbled_deepslate
fill 486 118 276 486 121 276 minecraft:deepslate_tiles
fill 486 118 316 486 121 316 minecraft:deepslate_tiles
setblock 487 118 278 minecraft:deepslate_tiles
setblock 488 118 278 minecraft:cobbled_deepslate
setblock 489 118 277 minecraft:cobbled_deepslate
setblock 490 118 276 minecraft:cobbled_deepslate
fill 490 118 277 490 121 277 minecraft:deepslate_tiles
setblock 490 118 316 minecraft:cobbled_deepslate
fill 491 118 275 492 201 275 minecraft:black_concrete
fill 491 118 276 491 121 276 minecraft:deepslate_tiles
fill 491 118 316 491 121 316 minecraft:deepslate_tiles
setblock 492 118 278 minecraft:deepslate_tiles
fill 492 118 315 492 121 315 minecraft:deepslate_tiles
setblock 493 118 275 minecraft:redstone_block
setblock 493 118 277 minecraft:deepslate_tiles
setblock 493 118 278 minecraft:cobbled_deepslate
fill 494 118 275 500 138 275 minecraft:black_concrete
setblock 494 118 277 minecraft:cobbled_deepslate
fill 494 118 278 497 118 278 minecraft:deepslate_tiles
setblock 495 118 276 minecraft:cobbled_deepslate
fill 495 118 277 495 121 277 minecraft:deepslate_tiles
setblock 495 118 316 minecraft:cobbled_deepslate
fill 496 118 276 496 121 276 minecraft:deepslate_tiles
setblock 496 118 315 minecraft:cobbled_deepslate
fill 496 118 316 496 121 316 minecraft:deepslate_tiles
setblock 497 118 314 minecraft:cobbled_deepslate
fill 497 118 315 497 121 315 minecraft:deepslate_tiles
setblock 498 118 278 minecraft:cobbled_deepslate
fill 498 118 314 498 121 314 minecraft:deepslate_tiles
setblock 499 118 277 minecraft:cobbled_deepslate
fill 499 118 278 499 121 278 minecraft:deepslate_tiles
setblock 500 118 276 minecraft:cobbled_deepslate
fill 500 118 277 500 121 277 minecraft:deepslate_tiles
setblock 500 118 316 minecraft:cobbled_deepslate
fill 501 118 276 501 121 276 minecraft:deepslate_tiles
setblock 501 118 315 minecraft:cobbled_deepslate
fill 501 118 316 501 121 316 minecraft:deepslate_tiles
setblock 502 118 314 minecraft:cobbled_deepslate
fill 502 118 315 502 121 315 minecraft:deepslate_tiles
setblock 503 118 278 minecraft:cobbled_deepslate
fill 503 118 314 503 119 314 minecraft:deepslate_tiles
setblock 504 118 277 minecraft:cobbled_deepslate
setblock 505 118 276 minecraft:cobbled_deepslate
fill 505 118 277 505 120 277 minecraft:deepslate_tiles
setblock 505 118 316 minecraft:cobbled_deepslate
fill 506 118 276 506 121 276 minecraft:deepslate_tiles
setblock 506 118 315 minecraft:cobbled_deepslate
fill 506 118 316 506 121 316 minecraft:deepslate_tiles
setblock 507 118 315 minecraft:deepslate_tiles
setblock 510 118 276 minecraft:cobbled_deepslate
setblock 510 118 296 minecraft:cobbled_deepslate
fill 510 118 297 510 118 300 minecraft:deepslate_tiles
setblock 510 118 301 minecraft:cobbled_deepslate
fill 510 118 302 510 120 303 minecraft:deepslate_tiles
setblock 510 118 316 minecraft:cobbled_deepslate
fill 511 118 276 511 120 277 minecraft:deepslate_tiles
setblock 511 118 295 minecraft:cobbled_deepslate
fill 511 118 296 511 121 296 minecraft:deepslate_tiles
setblock 511 118 299 minecraft:deepslate_tiles
setblock 511 118 300 minecraft:cobbled_deepslate
fill 511 118 301 511 121 301 minecraft:deepslate_tiles
setblock 511 118 304 minecraft:deepslate_tiles
setblock 511 118 305 minecraft:cobbled_deepslate
fill 511 118 306 511 120 307 minecraft:deepslate_tiles
setblock 511 118 315 minecraft:cobbled_deepslate
fill 511 118 316 511 121 316 minecraft:deepslate_tiles
fill 470 119 276 470 201 276 minecraft:black_concrete
fill 471 119 276 471 119 278 minecraft:deepslate_tiles
setblock 471 119 279 minecraft:cobbled_deepslate
fill 471 119 280 471 119 283 minecraft:deepslate_tiles
setblock 471 119 289 minecraft:cobbled_deepslate
fill 471 119 290 471 122 290 minecraft:deepslate_tiles
setblock 471 119 294 minecraft:cobbled_deepslate
fill 471 119 295 471 122 295 minecraft:deepslate_tiles
setblock 471 119 299 minecraft:cobbled_deepslate
fill 471 119 300 471 122 300 minecraft:deepslate_tiles
setblock 471 119 304 minecraft:cobbled_deepslate
fill 471 119 305 471 122 305 minecraft:deepslate_tiles
setblock 472 119 278 minecraft:cobbled_deepslate
setblock 472 119 293 minecraft:cobbled_deepslate
fill 472 119 294 472 122 294 minecraft:deepslate_tiles
setblock 472 119 298 minecraft:cobbled_deepslate
fill 472 119 299 472 122 299 minecraft:deepslate_tiles
setblock 472 119 303 minecraft:cobbled_deepslate
setblock 473 119 277 minecraft:cobbled_deepslate
setblock 473 119 297 minecraft:cobbled_deepslate
fill 473 119 298 474 121 298 minecraft:deepslate_tiles
setblock 473 119 301 minecraft:deepslate_tiles
setblock 473 119 316 minecraft:deepslate_tiles
setblock 474 119 276 minecraft:cobbled_deepslate
fill 474 119 277 474 122 277 minecraft:deepslate_tiles
fill 474 119 297 474 121 297 minecraft:deepslate_tiles
setblock 474 119 316 minecraft:cobbled_deepslate
fill 475 119 276 475 122 276 minecraft:deepslate_tiles
fill 475 119 278 476 119 278 minecraft:deepslate_tiles
fill 475 119 316 475 122 316 minecraft:deepslate_tiles
setblock 477 119 278 minecraft:cobbled_deepslate
fill 477 119 279 480 119 279 minecraft:deepslate_tiles
setblock 477 119 315 minecraft:deepslate_tiles
setblock 478 119 277 minecraft:cobbled_deepslate
fill 478 119 278 478 122 278 minecraft:deepslate_tiles
setblock 479 119 276 minecraft:cobbled_deepslate
fill 479 119 277 479 122 277 minecraft:deepslate_tiles
setblock 479 119 316 minecraft:cobbled_deepslate
fill 480 119 276 483 119 276 minecraft:deepslate_tiles
setblock 480 119 315 minecraft:cobbled_deepslate
fill 480 119 316 483 119 316 minecraft:deepslate_tiles
setblock 481 119 279 minecraft:cobbled_deepslate
setblock 481 119 315 minecraft:deepslate_tiles
setblock 482 119 278 minecraft:cobbled_deepslate
fill 482 119 279 482 122 279 minecraft:deepslate_tiles
setblock 483 119 277 minecraft:cobbled_deepslate
fill 483 119 278 483 122 278 minecraft:deepslate_tiles
setblock 484 119 276 minecraft:cobbled_deepslate
fill 484 119 277 487 119 277 minecraft:deepslate_tiles
setblock 484 119 316 minecraft:cobbled_deepslate
fill 485 119 276 485 122 276 minecraft:deepslate_tiles
fill 485 119 316 485 121 316 minecraft:deepslate_tiles
setblock 487 119 278 minecraft:cobbled_deepslate
setblock 488 119 277 minecraft:cobbled_deepslate
fill 488 119 278 491 119 278 minecraft:deepslate_tiles
setblock 489 119 276 minecraft:cobbled_deepslate
fill 489 119 277 489 122 277 minecraft:deepslate_tiles
setblock 489 119 316 minecraft:cobbled_deepslate
fill 490 119 276 490 122 276 minecraft:deepslate_tiles
fill 490 119 316 490 122 316 minecraft:deepslate_tiles
setblock 492 119 278 minecraft:cobbled_deepslate
fill 493 119 275 493 136 275 minecraft:black_concrete
setblock 493 119 277 minecraft:cobbled_deepslate
fill 493 119 278 496 119 278 minecraft:deepslate_tiles
setblock 494 119 276 minecraft:cobbled_deepslate
fill 494 119 277 494 122 277 minecraft:deepslate_tiles
setblock 494 119 316 minecraft:cobbled_deepslate
fill 495 119 276 495 122 276 minecraft:deepslate_tiles
setblock 495 119 314 minecraft:deepslate_tiles
setblock 495 119 315 minecraft:cobbled_deepslate
fill 495 119 316 495 122 316 minecraft:deepslate_tiles
setblock 496 119 279 minecraft:cobbled_deepslate
setblock 496 119 314 minecraft:cobbled_deepslate
fill 496 119 315 496 122 315 minecraft:deepslate_tiles
setblock 497 119 278 minecraft:cobbled_deepslate
fill 497 119 279 499 120 279 minecraft:deepslate_tiles
fill 497 119 314 497 122 314 minecraft:deepslate_tiles
setblock 498 119 277 minecraft:cobbled_deepslate
fill 498 119 278 498 122 278 minecraft:deepslate_tiles
setblock 499 119 276 minecraft:cobbled_deepslate
fill 499 119 277 499 122 277 minecraft:deepslate_tiles
setblock 499 119 316 minecraft:cobbled_deepslate
fill 500 119 276 500 122 276 minecraft:deepslate_tiles
setblock 500 119 315 minecraft:cobbled_deepslate
fill 500 119 316 500 122 316 minecraft:deepslate_tiles
fill 500 119 317 500 198 317 minecraft:black_concrete
setblock 501 119 278 minecraft:deepslate_tiles
setblock 501 119 314 minecraft:cobbled_deepslate
fill 501 119 315 501 122 315 minecraft:deepslate_tiles
setblock 501 119 317 minecraft:white_wool
setblock 502 119 278 minecraft:cobbled_deepslate
fill 502 119 314 502 120 314 minecraft:deepslate_tiles
fill 502 119 317 502 202 317 minecraft:black_concrete
setblock 503 119 277 minecraft:cobbled_deepslate
setblock 503 119 278 minecraft:deepslate_tiles
setblock 504 119 276 minecraft:cobbled_deepslate
fill 504 119 277 504 121 277 minecraft:deepslate_tiles
setblock 504 119 316 minecraft:cobbled_deepslate
fill 505 119 276 505 122 276 minecraft:deepslate_tiles
setblock 505 119 315 minecraft:cobbled_deepslate
fill 505 119 316 505 122 316 minecraft:deepslate_tiles
setblock 506 119 315 minecraft:deepslate_tiles
setblock 508 119 276 minecraft:deepslate_tiles
setblock 509 119 276 minecraft:cobbled_deepslate
setblock 509 119 316 minecraft:cobbled_deepslate
fill 510 119 276 510 121 276 minecraft:deepslate_tiles
fill 510 119 296 510 119 299 minecraft:deepslate_tiles
setblock 510 119 300 minecraft:cobbled_deepslate
fill 510 119 301 510 122 301 minecraft:deepslate_tiles
setblock 510 119 304 minecraft:deepslate_tiles
fill 510 119 316 510 120 316 minecraft:deepslate_tiles
setblock 511 119 278 minecraft:deepslate_tiles
setblock 511 119 294 minecraft:cobbled_deepslate
fill 511 119 295 511 122 295 minecraft:deepslate_tiles
setblock 511 119 299 minecraft:cobbled_deepslate
fill 511 119 300 511 122 300 minecraft:deepslate_tiles
setblock 511 119 304 minecraft:cobbled_deepslate
fill 511 119 305 511 122 305 minecraft:deepslate_tiles
setblock 511 119 308 minecraft:deepslate_tiles
setblock 511 119 314 minecraft:cobbled_deepslate
fill 511 119 315 511 120 315 minecraft:deepslate_tiles
fill 471 120 276 471 120 277 minecraft:deepslate_tiles
setblock 471 120 278 minecraft:cobbled_deepslate
fill 471 120 279 471 120 282 minecraft:deepslate_tiles
setblock 471 120 283 minecraft:cobbled_deepslate
fill 471 120 284 471 120 287 minecraft:deepslate_tiles
setblock 471 120 288 minecraft:cobbled_deepslate
fill 471 120 289 471 123 289 minecraft:deepslate_tiles
setblock 471 120 292 minecraft:deepslate_tiles
setblock 471 120 293 minecraft:cobbled_deepslate
fill 471 120 294 471 123 294 minecraft:deepslate_tiles
setblock 471 120 298 minecraft:cobbled_deepslate
fill 471 120 299 471 123 299 minecraft:deepslate_tiles
setblock 471 120 302 minecraft:deepslate_tiles
setblock 471 120 303 minecraft:cobbled_deepslate
fill 471 120 304 472 122 304 minecraft:deepslate_tiles
fill 471 120 306 471 121 306 minecraft:deepslate_tiles
setblock 472 120 276 minecraft:deepslate_tiles
setblock 472 120 277 minecraft:cobbled_deepslate
fill 472 120 278 472 120 281 minecraft:deepslate_tiles
setblock 472 120 282 minecraft:cobbled_deepslate
setblock 472 120 292 minecraft:cobbled_deepslate
fill 472 120 293 472 123 293 minecraft:deepslate_tiles
setblock 472 120 296 minecraft:deepslate_tiles
setblock 472 120 297 minecraft:cobbled_deepslate
fill 472 120 298 472 123 298 minecraft:deepslate_tiles
setblock 472 120 302 minecraft:cobbled_deepslate
fill 472 120 303 472 123 303 minecraft:deepslate_tiles
setblock 473 120 276 minecraft:cobbled_deepslate
fill 473 120 277 473 123 277 minecraft:deepslate_tiles
setblock 473 120 296 minecraft:cobbled_deepslate
fill 473 120 297 473 123 297 minecraft:deepslate_tiles
setblock 473 120 301 minecraft:cobbled_deepslate
fill 473 120 302 473 123 302 minecraft:deepslate_tiles
setblock 473 120 316 minecraft:cobbled_deepslate
fill 474 120 276 474 123 276 minecraft:deepslate_tiles
fill 474 120 278 475 120 278 minecraft:deepslate_tiles
setblock 474 120 299 minecraft:deepslate_tiles
fill 474 120 316 474 122 316 minecraft:deepslate_tiles
setblock 475 120 279 minecraft:white_wool
setblock 476 120 278 minecraft:white_wool
fill 476 120 279 479 120 279 minecraft:deepslate_tiles
setblock 477 120 277 minecraft:white_wool
fill 477 120 278 477 123 278 minecraft:deepslate_tiles
setblock 478 120 276 minecraft:white_wool
fill 478 120 277 478 123 277 minecraft:deepslate_tiles
setblock 478 120 316 minecraft:cobbled_deepslate
fill 479 120 276 482 120 276 minecraft:deepslate_tiles
setblock 479 120 315 minecraft:cobbled_deepslate
fill 479 120 316 482 120 316 minecraft:deepslate_tiles
setblock 480 120 279 minecraft:cobbled_deepslate
setblock 480 120 315 minecraft:deepslate_tiles
setblock 481 120 278 minecraft:cobbled_deepslate
fill 481 120 279 481 123 279 minecraft:deepslate_tiles
setblock 482 120 277 minecraft:cobbled_deepslate
fill 482 120 278 482 123 278 minecraft:deepslate_tiles
setblock 483 120 276 minecraft:cobbled_deepslate
fill 483 120 277 486 120 277 minecraft:deepslate_tiles
setblock 483 120 316 minecraft:cobbled_deepslate
fill 484 120 276 484 123 276 minecraft:deepslate_tiles
fill 484 120 316 484 122 316 minecraft:deepslate_tiles
setblock 485 120 278 minecraft:deepslate_tiles
setblock 486 120 278 minecraft:cobbled_deepslate
setblock 487 120 277 minecraft:cobbled_deepslate
fill 487 120 278 490 120 278 minecraft:deepslate_tiles
setblock 488 120 276 minecraft:cobbled_deepslate
fill 488 120 277 488 123 277 minecraft:deepslate_tiles
setblock 488 120 316 minecraft:cobbled_deepslate
fill 489 120 276 489 123 276 minecraft:deepslate_tiles
fill 489 120 316 489 123 316 minecraft:deepslate_tiles
setblock 491 120 278 minecraft:cobbled_deepslate
setblock 492 120 277 minecraft:cobbled_deepslate
fill 492 120 278 495 120 278 minecraft:deepslate_tiles
setblock 493 120 276 minecraft:cobbled_deepslate
fill 493 120 277 493 123 277 minecraft:deepslate_tiles
setblock 493 120 316 minecraft:cobbled_deepslate
fill 494 120 276 494 123 276 minecraft:deepslate_tiles
setblock 494 120 315 minecraft:cobbled_deepslate
fill 494 120 316 494 123 316 minecraft:deepslate_tiles
setblock 495 120 279 minecraft:cobbled_deepslate
setblock 495 120 314 minecraft:cobbled_deepslate
fill 495 120 315 495 123 315 minecraft:deepslate_tiles
setblock 496 120 278 minecraft:cobbled_deepslate
fill 496 120 279 496 122 279 minecraft:deepslate_tiles
fill 496 120 314 496 122 314 minecraft:deepslate_tiles
setblock 497 120 277 minecraft:cobbled_deepslate
fill 497 120 278 497 123 278 minecraft:deepslate_tiles
setblock 498 120 276 minecraft:cobbled_deepslate
fill 498 120 277 498 123 277 minecraft:deepslate_tiles
setblock 498 120 316 minecraft:cobbled_deepslate
fill 499 120 276 499 123 276 minecraft:deepslate_tiles
setblock 499 120 315 minecraft:cobbled_deepslate
fill 499 120 316 499 123 316 minecraft:deepslate_tiles
setblock 500 120 314 minecraft:cobbled_deepslate
fill 500 120 315 500 123 315 minecraft:deepslate_tiles
setblock 501 120 278 minecraft:cobbled_deepslate
fill 501 120 314 501 121 314 minecraft:deepslate_tiles
fill 501 120 317 501 201 317 minecraft:black_concrete
setblock 502 120 277 minecraft:cobbled_deepslate
fill 502 120 278 502 121 278 minecraft:deepslate_tiles
setblock 503 120 276 minecraft:cobbled_deepslate
fill 503 120 277 503 122 277 minecraft:deepslate_tiles
fill 503 120 278 503 121 278 minecraft:cobbled_deepslate
setblock 503 120 316 minecraft:cobbled_deepslate
fill 504 120 276 504 122 276 minecraft:deepslate_tiles
setblock 504 120 315 minecraft:cobbled_deepslate
fill 504 120 316 504 123 316 minecraft:deepslate_tiles
setblock 505 120 315 minecraft:deepslate_tiles
fill 507 120 305 507 126 305 minecraft:black_concrete
setblock 508 120 276 minecraft:cobbled_deepslate
setblock 508 120 316 minecraft:cobbled_deepslate
setblock 509 120 276 minecraft:deepslate_tiles
setblock 509 120 300 minecraft:cobbled_deepslate
setblock 509 120 316 minecraft:deepslate_tiles
fill 510 120 296 510 120 298 minecraft:deepslate_tiles
setblock 510 120 299 minecraft:cobbled_deepslate
fill 510 120 300 510 123 300 minecraft:deepslate_tiles
setblock 510 120 304 minecraft:cobbled_deepslate
fill 510 120 305 510 123 305 minecraft:deepslate_tiles
setblock 511 120 278 minecraft:cobbled_deepslate
fill 511 120 279 511 122 280 minecraft:deepslate_tiles
setblock 511 120 293 minecraft:cobbled_deepslate
fill 511 120 294 511 123 294 minecraft:deepslate_tiles
setblock 511 120 298 minecraft:cobbled_deepslate
fill 511 120 299 511 123 299 minecraft:deepslate_tiles
setblock 511 120 303 minecraft:cobbled_deepslate
fill 511 120 304 511 123 304 minecraft:deepslate_tiles
setblock 511 120 308 minecraft:cobbled_deepslate
fill 511 120 309 511 123 309 minecraft:deepslate_tiles
setblock 471 121 276 minecraft:deepslate_tiles
setblock 471 121 277 minecraft:cobbled_deepslate
fill 471 121 278 471 121 281 minecraft:deepslate_tiles
setblock 471 121 282 minecraft:cobbled_deepslate
setblock 471 121 283 minecraft:white_wool
fill 471 121 284 471 121 286 minecraft:deepslate_tiles
setblock 471 121 287 minecraft:cobbled_deepslate
fill 471 121 288 471 124 288 minecraft:deepslate_tiles
setblock 471 121 292 minecraft:cobbled_deepslate
fill 471 121 293 471 124 293 minecraft:deepslate_tiles
setblock 471 121 297 minecraft:cobbled_deepslate
fill 471 121 298 471 124 298 minecraft:deepslate_tiles
setblock 471 121 302 minecraft:cobbled_deepslate
fill 471 121 303 471 124 303 minecraft:deepslate_tiles
setblock 472 121 276 minecraft:cobbled_deepslate
fill 472 121 277 472 121 280 minecraft:deepslate_tiles
setblock 472 121 281 minecraft:cobbled_deepslate
setblock 472 121 282 minecraft:white_wool
fill 472 121 283 472 121 285 minecraft:deepslate_tiles
fill 472 121 292 472 122 292 minecraft:deepslate_tiles
setblock 472 121 296 minecraft:cobbled_deepslate
fill 472 121 297 472 124 297 minecraft:deepslate_tiles
setblock 472 121 300 minecraft:deepslate_tiles
setblock 472 121 301 minecraft:cobbled_deepslate
fill 472 121 302 472 124 302 minecraft:deepslate_tiles
fill 473 121 276 473 124 276 minecraft:deepslate_tiles
fill 473 121 278 473 121 279 minecraft:deepslate_tiles
setblock 473 121 280 minecraft:cobbled_deepslate
setblock 473 121 281 minecraft:white_wool
fill 473 121 282 473 123 282 minecraft:deepslate_tiles
setblock 473 121 285 minecraft:light[level=12]
setblock 473 121 292 minecraft:light[level=12]
setblock 473 121 295 minecraft:cobbled_deepslate
fill 473 121 296 473 123 296 minecraft:deepslate_tiles
setblock 473 121 300 minecraft:cobbled_deepslate
fill 473 121 301 473 124 301 minecraft:deepslate_tiles
fill 473 121 303 473 122 303 minecraft:deepslate_tiles
setblock 473 121 306 minecraft:light[level=12]
setblock 473 121 313 minecraft:light[level=12]
setblock 473 121 316 minecraft:deepslate_tiles
setblock 474 121 278 minecraft:deepslate_tiles
setblock 474 121 280 minecraft:white_wool
setblock 474 121 299 minecraft:cobbled_deepslate
setblock 474 121 300 minecraft:deepslate_tiles
setblock 475 121 278 minecraft:cobbled_deepslate
fill 475 121 279 478 121 279 minecraft:deepslate_tiles
setblock 476 121 277 minecraft:cobbled_deepslate
fill 476 121 278 476 124 278 minecraft:deepslate_tiles
setblock 477 121 276 minecraft:cobbled_deepslate
fill 477 121 277 477 124 277 minecraft:deepslate_tiles
setblock 477 121 316 minecraft:cobbled_deepslate
fill 478 121 276 481 121 276 minecraft:deepslate_tiles
fill 478 121 316 481 121 316 minecraft:deepslate_tiles
setblock 479 121 279 minecraft:cobbled_deepslate
setblock 480 121 278 minecraft:cobbled_deepslate
fill 480 121 279 480 123 279 minecraft:deepslate_tiles
setblock 480 121 285 minecraft:light[level=12]
setblock 480 121 292 minecraft:light[level=12]
setblock 480 121 299 minecraft:light[level=12]
setblock 480 121 306 minecraft:light[level=12]
setblock 480 121 313 minecraft:light[level=12]
setblock 481 121 277 minecraft:cobbled_deepslate
fill 481 121 278 481 124 278 minecraft:deepslate_tiles
setblock 482 121 276 minecraft:cobbled_deepslate
fill 482 121 277 485 121 277 minecraft:deepslate_tiles
setblock 482 121 316 minecraft:cobbled_deepslate
fill 483 121 276 483 124 276 minecraft:deepslate_tiles
fill 483 121 316 483 122 316 minecraft:deepslate_tiles
setblock 485 121 278 minecraft:cobbled_deepslate
setblock 486 121 277 minecraft:cobbled_deepslate
fill 486 121 278 489 121 278 minecraft:deepslate_tiles
setblock 487 121 276 minecraft:cobbled_deepslate
fill 487 121 277 487 124 277 minecraft:deepslate_tiles
setblock 487 121 285 minecraft:light[level=12]
setblock 487 121 292 minecraft:light[level=12]
setblock 487 121 299 minecraft:light[level=12]
setblock 487 121 306 minecraft:light[level=12]
setblock 487 121 313 minecraft:light[level=12]
setblock 487 121 316 minecraft:cobbled_deepslate
fill 488 121 276 488 124 276 minecraft:deepslate_tiles
fill 488 121 316 488 122 316 minecraft:deepslate_tiles
setblock 490 121 278 minecraft:cobbled_deepslate
setblock 491 121 277 minecraft:cobbled_deepslate
fill 491 121 278 494 121 278 minecraft:deepslate_tiles
setblock 492 121 276 minecraft:cobbled_deepslate
fill 492 121 277 492 124 277 minecraft:deepslate_tiles
setblock 492 121 316 minecraft:cobbled_deepslate
fill 493 121 276 493 124 276 minecraft:deepslate_tiles
setblock 493 121 315 minecraft:cobbled_deepslate
fill 493 121 316 493 124 316 minecraft:deepslate_tiles
setblock 494 121 279 minecraft:cobbled_deepslate
setblock 494 121 285 minecraft:light[level=12]
setblock 494 121 292 minecraft:light[level=12]
setblock 494 121 299 minecraft:light[level=12]
setblock 494 121 306 minecraft:light[level=12]
setblock 494 121 313 minecraft:light[level=12]
fill 494 121 315 494 124 315 minecraft:deepslate_tiles
setblock 495 121 278 minecraft:cobbled_deepslate
fill 495 121 279 495 122 279 minecraft:deepslate_tiles
setblock 495 121 314 minecraft:deepslate_tiles
setblock 496 121 277 minecraft:cobbled_deepslate
fill 496 121 278 496 124 278 minecraft:deepslate_tiles
setblock 497 121 276 minecraft:cobbled_deepslate
fill 497 121 277 497 124 277 minecraft:deepslate_tiles
fill 497 121 279 498 121 279 minecraft:deepslate_tiles
setblock 497 121 316 minecraft:cobbled_deepslate
fill 498 121 276 498 124 276 minecraft:deepslate_tiles
setblock 498 121 315 minecraft:cobbled_deepslate
fill 498 121 316 498 124 316 minecraft:deepslate_tiles
setblock 499 121 279 minecraft:cobbled_deepslate
setblock 499 121 314 minecraft:cobbled_deepslate
fill 499 121 315 499 124 315 minecraft:deepslate_tiles
setblock 500 121 278 minecraft:cobbled_deepslate
setblock 500 121 314 minecraft:deepslate_tiles
setblock 501 121 277 minecraft:cobbled_deepslate
fill 501 121 278 501 122 278 minecraft:deepslate_tiles
setblock 501 121 285 minecraft:light[level=12]
setblock 501 121 292 minecraft:light[level=12]
setblock 501 121 299 minecraft:light[level=12]
setblock 501 121 306 minecraft:light[level=12]
setblock 501 121 313 minecraft:light[level=12]
setblock 502 121 276 minecraft:cobbled_deepslate
fill 502 121 277 502 123 277 minecraft:deepslate_tiles
setblock 502 121 316 minecraft:cobbled_deepslate
fill 503 121 276 503 123 276 minecraft:deepslate_tiles
setblock 503 121 315 minecraft:cobbled_deepslate
fill 503 121 316 503 123 316 minecraft:deepslate_tiles
setblock 504 121 315 minecraft:deepslate_tiles
setblock 507 121 276 minecraft:cobbled_deepslate
setblock 507 121 316 minecraft:cobbled_deepslate
setblock 508 121 278 minecraft:light[level=12]
setblock 508 121 285 minecraft:light[level=12]
setblock 508 121 292 minecraft:light[level=12]
setblock 508 121 299 minecraft:light[level=12]
setblock 508 121 306 minecraft:light[level=12]
setblock 508 121 313 minecraft:light[level=12]
setblock 508 121 316 minecraft:deepslate_tiles
fill 509 121 300 509 122 302 minecraft:deepslate_tiles
fill 510 121 296 510 121 297 minecraft:deepslate_tiles
setblock 510 121 298 minecraft:cobbled_deepslate
fill 510 121 299 510 124 299 minecraft:deepslate_tiles
setblock 510 121 302 minecraft:deepslate_tiles
setblock 510 121 303 minecraft:cobbled_deepslate
fill 510 121 304 510 124 304 minecraft:deepslate_tiles
fill 510 121 306 511 121 306 minecraft:deepslate_tiles
setblock 511 121 276 minecraft:deepslate_tiles
setblock 511 121 277 minecraft:cobbled_deepslate
fill 511 121 278 511 124 278 minecraft:deepslate_tiles
setblock 511 121 281 minecraft:deepslate_tiles
fill 511 121 293 511 123 293 minecraft:deepslate_tiles
setblock 511 121 297 minecraft:cobbled_deepslate
fill 511 121 298 511 124 298 minecraft:deepslate_tiles
setblock 511 121 302 minecraft:cobbled_deepslate
fill 511 121 303 511 124 303 minecraft:deepslate_tiles
setblock 511 121 307 minecraft:cobbled_deepslate
fill 511 121 308 511 124 308 minecraft:deepslate_tiles
setblock 471 122 276 minecraft:cobbled_deepslate
fill 471 122 277 471 122 280 minecraft:deepslate_tiles
setblock 471 122 281 minecraft:cobbled_deepslate
fill 471 122 282 471 122 285 minecraft:deepslate_tiles
setblock 471 122 286 minecraft:cobbled_deepslate
fill 471 122 287 472 124 287 minecraft:deepslate_tiles
setblock 471 122 291 minecraft:cobbled_deepslate
fill 471 122 292 471 125 292 minecraft:deepslate_tiles
setblock 471 122 296 minecraft:cobbled_deepslate
fill 471 122 297 471 125 297 minecraft:deepslate_tiles
setblock 471 122 301 minecraft:cobbled_deepslate
fill 471 122 302 471 125 302 minecraft:deepslate_tiles
setblock 471 122 306 minecraft:cobbled_deepslate
fill 471 122 307 471 125 307 minecraft:deepslate_tiles
fill 472 122 276 472 122 279 minecraft:deepslate_tiles
setblock 472 122 280 minecraft:cobbled_deepslate
fill 472 122 281 472 122 284 minecraft:deepslate_tiles
setblock 472 122 285 minecraft:cobbled_deepslate
fill 472 122 286 472 125 286 minecraft:deepslate_tiles
setblock 472 122 295 minecraft:cobbled_deepslate
fill 472 122 296 472 125 296 minecraft:deepslate_tiles
setblock 472 122 300 minecraft:cobbled_deepslate
fill 472 122 301 472 125 301 minecraft:deepslate_tiles
setblock 472 122 305 minecraft:cobbled_deepslate
setblock 473 122 278 minecraft:deepslate_tiles
setblock 473 122 279 minecraft:cobbled_deepslate
fill 473 122 280 473 124 281 minecraft:deepslate_tiles
setblock 473 122 283 minecraft:deepslate_tiles
setblock 473 122 284 minecraft:cobbled_deepslate
setblock 473 122 295 minecraft:deepslate_tiles
setblock 473 122 298 minecraft:deepslate_tiles
setblock 473 122 299 minecraft:cobbled_deepslate
fill 473 122 300 473 124 300 minecraft:deepslate_tiles
setblock 474 122 278 minecraft:cobbled_deepslate
setblock 475 122 277 minecraft:cobbled_deepslate
fill 475 122 278 475 123 279 minecraft:deepslate_tiles
setblock 476 122 276 minecraft:cobbled_deepslate
fill 476 122 277 476 125 277 minecraft:deepslate_tiles
fill 476 122 279 477 122 279 minecraft:deepslate_tiles
setblock 476 122 316 minecraft:cobbled_deepslate
fill 477 122 276 480 122 276 minecraft:deepslate_tiles
fill 477 122 316 480 122 316 minecraft:deepslate_tiles
setblock 478 122 279 minecraft:cobbled_deepslate
setblock 479 122 278 minecraft:cobbled_deepslate
fill 479 122 279 479 124 279 minecraft:deepslate_tiles
setblock 480 122 277 minecraft:cobbled_deepslate
fill 480 122 278 480 125 278 minecraft:deepslate_tiles
fill 480 122 291 480 123 291 minecraft:white_wool
setblock 481 122 276 minecraft:cobbled_deepslate
fill 481 122 277 484 122 277 minecraft:deepslate_tiles
setblock 481 122 316 minecraft:cobbled_deepslate
fill 482 122 276 482 125 276 minecraft:deepslate_tiles
setblock 482 122 316 minecraft:deepslate_tiles
setblock 484 122 278 minecraft:cobbled_deepslate
setblock 485 122 277 minecraft:cobbled_deepslate
fill 485 122 278 486 122 278 minecraft:deepslate_tiles
setblock 486 122 276 minecraft:cobbled_deepslate
fill 486 122 277 486 124 277 minecraft:deepslate_tiles
fill 487 122 276 487 125 276 minecraft:deepslate_tiles
setblock 489 122 278 minecraft:cobbled_deepslate
setblock 490 122 277 minecraft:cobbled_deepslate
fill 490 122 278 493 122 278 minecraft:deepslate_tiles
setblock 491 122 276 minecraft:cobbled_deepslate
fill 491 122 277 491 125 277 minecraft:deepslate_tiles
setblock 491 122 316 minecraft:cobbled_deepslate
fill 492 122 276 492 125 276 minecraft:deepslate_tiles
setblock 492 122 315 minecraft:cobbled_deepslate
fill 492 122 316 492 125 316 minecraft:deepslate_tiles
fill 493 122 315 493 125 315 minecraft:deepslate_tiles
setblock 494 122 278 minecraft:cobbled_deepslate
setblock 494 122 279 minecraft:deepslate_tiles
setblock 495 122 277 minecraft:cobbled_deepslate
fill 495 122 278 495 125 278 minecraft:deepslate_tiles
setblock 496 122 276 minecraft:cobbled_deepslate
fill 496 122 277 496 125 277 minecraft:deepslate_tiles
setblock 496 122 316 minecraft:cobbled_deepslate
fill 497 122 276 497 125 276 minecraft:deepslate_tiles
setblock 497 122 279 minecraft:deepslate_tiles
setblock 497 122 315 minecraft:cobbled_deepslate
fill 497 122 316 497 125 316 minecraft:deepslate_tiles
setblock 498 122 279 minecraft:cobbled_deepslate
setblock 498 122 314 minecraft:cobbled_deepslate
fill 498 122 315 498 125 315 minecraft:deepslate_tiles
setblock 499 122 278 minecraft:cobbled_deepslate
setblock 499 122 314 minecraft:deepslate_tiles
setblock 500 122 277 minecraft:cobbled_deepslate
setblock 500 122 278 minecraft:deepslate_tiles
setblock 501 122 276 minecraft:cobbled_deepslate
fill 501 122 277 501 123 277 minecraft:deepslate_tiles
setblock 501 122 316 minecraft:cobbled_deepslate
fill 502 122 276 502 124 276 minecraft:deepslate_tiles
setblock 502 122 315 minecraft:cobbled_deepslate
fill 502 122 316 502 124 316 minecraft:deepslate_tiles
setblock 503 122 315 minecraft:deepslate_tiles
setblock 506 122 316 minecraft:cobbled_deepslate
fill 508 122 280 508 127 280 minecraft:black_concrete
setblock 510 122 296 minecraft:deepslate_tiles
setblock 510 122 297 minecraft:cobbled_deepslate
fill 510 122 298 510 125 298 minecraft:deepslate_tiles
setblock 510 122 302 minecraft:cobbled_deepslate
fill 510 122 303 510 125 303 minecraft:deepslate_tiles
setblock 510 122 306 minecraft:deepslate_tiles
setblock 511 122 276 minecraft:cobbled_deepslate
fill 511 122 277 511 123 277 minecraft:deepslate_tiles
setblock 511 122 281 minecraft:cobbled_deepslate
fill 511 122 282 511 124 283 minecraft:deepslate_tiles
setblock 511 122 296 minecraft:cobbled_deepslate
fill 511 122 297 511 125 297 minecraft:deepslate_tiles
setblock 511 122 301 minecraft:cobbled_deepslate
fill 511 122 302 511 125 302 minecraft:deepslate_tiles
setblock 511 122 306 minecraft:cobbled_deepslate
fill 511 122 307 511 125 307 minecraft:deepslate_tiles
fill 470 123 281 470 191 281 minecraft:black_concrete
setblock 470 123 282 minecraft:white_wool
fill 470 123 283 470 201 283 minecraft:black_concrete
fill 471 123 276 471 123 279 minecraft:deepslate_tiles
setblock 471 123 280 minecraft:cobbled_deepslate
fill 471 123 281 471 123 284 minecraft:deepslate_tiles
setblock 471 123 285 minecraft:cobbled_deepslate
fill 471 123 286 471 126 286 minecraft:deepslate_tiles
setblock 471 123 290 minecraft:cobbled_deepslate
fill 471 123 291 471 126 291 minecraft:deepslate_tiles
setblock 471 123 295 minecraft:cobbled_deepslate
fill 471 123 296 471 126 296 minecraft:deepslate_tiles
setblock 471 123 300 minecraft:cobbled_deepslate
fill 471 123 301 471 126 301 minecraft:deepslate_tiles
setblock 471 123 304 minecraft:deepslate_tiles
setblock 471 123 305 minecraft:cobbled_deepslate
fill 471 123 306 471 126 306 minecraft:deepslate_tiles
fill 472 123 276 472 123 278 minecraft:deepslate_tiles
setblock 472 123 279 minecraft:cobbled_deepslate
fill 472 123 280 472 123 283 minecraft:deepslate_tiles
setblock 472 123 284 minecraft:cobbled_deepslate
fill 472 123 285 473 125 285 minecraft:deepslate_tiles
setblock 472 123 288 minecraft:deepslate_tiles
setblock 472 123 294 minecraft:cobbled_deepslate
fill 472 123 295 472 124 295 minecraft:deepslate_tiles
setblock 472 123 299 minecraft:cobbled_deepslate
fill 472 123 300 472 126 300 minecraft:deepslate_tiles
setblock 472 123 304 minecraft:cobbled_deepslate
fill 472 123 305 472 126 305 minecraft:deepslate_tiles
setblock 473 123 278 minecraft:cobbled_deepslate
fill 473 123 279 473 126 279 minecraft:deepslate_tiles
setblock 473 123 283 minecraft:cobbled_deepslate
fill 473 123 284 473 126 284 minecraft:deepslate_tiles
setblock 473 123 298 minecraft:cobbled_deepslate
fill 473 123 299 473 124 299 minecraft:deepslate_tiles
setblock 473 123 303 minecraft:cobbled_deepslate
setblock 474 123 277 minecraft:cobbled_deepslate
fill 474 123 278 474 126 278 minecraft:deepslate_tiles
setblock 474 123 281 minecraft:deepslate_tiles
setblock 475 123 276 minecraft:cobbled_deepslate
fill 475 123 277 475 126 277 minecraft:deepslate_tiles
setblock 475 123 316 minecraft:cobbled_deepslate
fill 476 123 276 479 123 276 minecraft:deepslate_tiles
setblock 476 123 279 minecraft:deepslate_tiles
fill 476 123 316 479 123 316 minecraft:deepslate_tiles
setblock 477 123 279 minecraft:cobbled_deepslate
setblock 478 123 278 minecraft:cobbled_deepslate
fill 478 123 279 478 124 279 minecraft:deepslate_tiles
setblock 479 123 277 minecraft:cobbled_deepslate
fill 479 123 278 479 125 278 minecraft:deepslate_tiles
setblock 480 123 276 minecraft:cobbled_deepslate
fill 480 123 277 483 123 277 minecraft:deepslate_tiles
setblock 480 123 316 minecraft:cobbled_deepslate
fill 481 123 276 481 126 276 minecraft:deepslate_tiles
setblock 481 123 316 minecraft:deepslate_tiles
setblock 483 123 278 minecraft:cobbled_deepslate
setblock 484 123 277 minecraft:cobbled_deepslate
setblock 484 123 278 minecraft:deepslate_tiles
setblock 485 123 276 minecraft:cobbled_deepslate
fill 485 123 277 485 124 277 minecraft:deepslate_tiles
fill 486 123 276 486 125 276 minecraft:deepslate_tiles
fill 487 123 311 488 124 311 minecraft:white_wool
setblock 489 123 277 minecraft:cobbled_deepslate
fill 489 123 278 489 124 278 minecraft:black_concrete
setblock 490 123 276 minecraft:cobbled_deepslate
fill 490 123 277 490 123 278 minecraft:deepslate_tiles
fill 490 123 279 490 124 279 minecraft:black_concrete
setblock 490 123 316 minecraft:cobbled_deepslate
fill 491 123 276 491 126 276 minecraft:deepslate_tiles
fill 491 123 278 492 123 278 minecraft:deepslate_tiles
fill 491 123 316 491 126 316 minecraft:deepslate_tiles
setblock 493 123 278 minecraft:cobbled_deepslate
setblock 494 123 277 minecraft:cobbled_deepslate
fill 494 123 278 494 125 278 minecraft:deepslate_tiles
setblock 495 123 276 minecraft:cobbled_deepslate
fill 495 123 277 495 126 277 minecraft:deepslate_tiles
setblock 495 123 316 minecraft:cobbled_deepslate
fill 496 123 276 496 126 276 minecraft:deepslate_tiles
setblock 496 123 315 minecraft:cobbled_deepslate
fill 496 123 316 496 126 316 minecraft:deepslate_tiles
fill 497 123 315 497 126 315 minecraft:deepslate_tiles
setblock 498 123 278 minecraft:cobbled_deepslate
setblock 498 123 317 minecraft:redstone_block
setblock 499 123 277 minecraft:cobbled_deepslate
setblock 499 123 278 minecraft:deepslate_tiles
fill 499 123 317 499 127 317 minecraft:black_concrete
setblock 500 123 276 minecraft:cobbled_deepslate
fill 500 123 277 500 124 277 minecraft:deepslate_tiles
setblock 500 123 316 minecraft:cobbled_deepslate
fill 501 123 276 501 124 276 minecraft:deepslate_tiles
setblock 501 123 315 minecraft:cobbled_deepslate
fill 501 123 316 501 125 316 minecraft:deepslate_tiles
setblock 509 123 302 minecraft:cobbled_deepslate
fill 510 123 297 510 124 297 minecraft:deepslate_tiles
setblock 510 123 301 minecraft:cobbled_deepslate
fill 510 123 302 510 126 302 minecraft:deepslate_tiles
setblock 510 123 306 minecraft:cobbled_deepslate
setblock 511 123 279 minecraft:deepslate_tiles
setblock 511 123 280 minecraft:cobbled_deepslate
fill 511 123 281 511 126 281 minecraft:deepslate_tiles
setblock 511 123 284 minecraft:deepslate_tiles
setblock 511 123 295 minecraft:cobbled_deepslate
fill 511 123 296 511 126 296 minecraft:deepslate_tiles
setblock 511 123 300 minecraft:cobbled_deepslate
fill 511 123 301 511 126 301 minecraft:deepslate_tiles
setblock 511 123 305 minecraft:cobbled_deepslate
fill 511 123 306 511 126 306 minecraft:deepslate_tiles
fill 470 124 282 470 198 282 minecraft:black_concrete
fill 471 124 276 471 124 278 minecraft:deepslate_tiles
setblock 471 124 279 minecraft:cobbled_deepslate
fill 471 124 280 471 124 283 minecraft:deepslate_tiles
setblock 471 124 284 minecraft:cobbled_deepslate
fill 471 124 285 471 127 285 minecraft:deepslate_tiles
setblock 471 124 289 minecraft:cobbled_deepslate
fill 471 124 290 471 127 290 minecraft:deepslate_tiles
setblock 471 124 294 minecraft:cobbled_deepslate
fill 471 124 295 471 127 295 minecraft:deepslate_tiles
setblock 471 124 299 minecraft:cobbled_deepslate
fill 471 124 300 471 127 300 minecraft:deepslate_tiles
setblock 471 124 304 minecraft:cobbled_deepslate
fill 471 124 305 471 127 305 minecraft:deepslate_tiles
fill 472 124 276 472 124 277 minecraft:deepslate_tiles
setblock 472 124 278 minecraft:cobbled_deepslate
fill 472 124 279 472 124 282 minecraft:deepslate_tiles
setblock 472 124 283 minecraft:cobbled_deepslate
fill 472 124 284 472 127 284 minecraft:deepslate_tiles
setblock 472 124 288 minecraft:cobbled_deepslate
fill 472 124 289 472 127 289 minecraft:deepslate_tiles
setblock 472 124 294 minecraft:deepslate_tiles
setblock 472 124 298 minecraft:cobbled_deepslate
fill 472 124 299 472 127 299 minecraft:deepslate_tiles
setblock 472 124 303 minecraft:cobbled_deepslate
fill 472 124 304 472 127 304 minecraft:deepslate_tiles
setblock 473 124 277 minecraft:cobbled_deepslate
setblock 473 124 282 minecraft:cobbled_deepslate
fill 473 124 283 473 127 283 minecraft:deepslate_tiles
setblock 473 124 286 minecraft:deepslate_tiles
setblock 473 124 298 minecraft:deepslate_tiles
setblock 473 124 302 minecraft:cobbled_deepslate
setblock 473 124 303 minecraft:deepslate_tiles
setblock 474 124 276 minecraft:cobbled_deepslate
fill 474 124 277 474 127 277 minecraft:deepslate_tiles
setblock 474 124 281 minecraft:cobbled_deepslate
fill 474 124 282 474 127 282 minecraft:deepslate_tiles
fill 475 124 276 478 124 276 minecraft:deepslate_tiles
fill 475 124 278 475 125 278 minecraft:deepslate_tiles
setblock 476 124 279 minecraft:cobbled_deepslate
fill 476 124 316 478 124 316 minecraft:deepslate_tiles
setblock 477 124 278 minecraft:cobbled_deepslate
setblock 477 124 279 minecraft:deepslate_tiles
setblock 478 124 277 minecraft:cobbled_deepslate
fill 478 124 278 478 126 278 minecraft:deepslate_tiles
setblock 479 124 276 minecraft:cobbled_deepslate
fill 479 124 277 482 124 277 minecraft:deepslate_tiles
fill 480 124 276 480 127 276 minecraft:deepslate_tiles
fill 480 124 291 480 133 291 minecraft:black_concrete
setblock 482 124 278 minecraft:cobbled_deepslate
setblock 483 124 277 minecraft:cobbled_deepslate
setblock 484 124 276 minecraft:cobbled_deepslate
setblock 484 124 277 minecraft:deepslate_tiles
fill 485 124 276 485 125 276 minecraft:deepslate_tiles
setblock 488 124 277 minecraft:cobbled_deepslate
setblock 489 124 276 minecraft:cobbled_deepslate
fill 489 124 277 490 125 277 minecraft:deepslate_tiles
setblock 489 124 279 minecraft:black_concrete
fill 490 124 276 490 127 276 minecraft:deepslate_tiles
fill 490 124 278 491 124 278 minecraft:black_concrete
fill 490 124 316 490 127 316 minecraft:deepslate_tiles
setblock 491 124 279 minecraft:black_concrete
setblock 492 124 278 minecraft:cobbled_deepslate
setblock 493 124 277 minecraft:cobbled_deepslate
fill 493 124 278 493 125 278 minecraft:deepslate_tiles
setblock 494 124 276 minecraft:cobbled_deepslate
fill 494 124 277 494 127 277 minecraft:deepslate_tiles
setblock 494 124 316 minecraft:cobbled_deepslate
fill 495 124 276 495 127 276 minecraft:deepslate_tiles
setblock 495 124 315 minecraft:cobbled_deepslate
fill 495 124 316 495 127 316 minecraft:deepslate_tiles
fill 496 124 315 496 127 315 minecraft:deepslate_tiles
setblock 497 124 278 minecraft:cobbled_deepslate
setblock 498 124 277 minecraft:cobbled_deepslate
setblock 498 124 278 minecraft:deepslate_tiles
fill 498 124 317 498 186 317 minecraft:black_concrete
setblock 499 124 276 minecraft:cobbled_deepslate
setblock 499 124 277 minecraft:deepslate_tiles
setblock 499 124 316 minecraft:cobbled_deepslate
fill 500 124 276 500 125 276 minecraft:deepslate_tiles
setblock 500 124 315 minecraft:cobbled_deepslate
fill 500 124 316 500 126 316 minecraft:deepslate_tiles
fill 506 124 305 506 126 305 minecraft:black_concrete
fill 507 124 304 507 126 304 minecraft:black_concrete
fill 507 124 306 507 126 306 minecraft:black_concrete
fill 508 124 305 508 126 305 minecraft:black_concrete
setblock 510 124 300 minecraft:cobbled_deepslate
fill 510 124 301 510 127 301 minecraft:deepslate_tiles
setblock 510 124 305 minecraft:cobbled_deepslate
fill 510 124 306 510 127 306 minecraft:deepslate_tiles
setblock 511 124 279 minecraft:cobbled_deepslate
fill 511 124 280 511 127 280 minecraft:deepslate_tiles
setblock 511 124 284 minecraft:cobbled_deepslate
fill 511 124 285 511 127 285 minecraft:deepslate_tiles
setblock 511 124 294 minecraft:cobbled_deepslate
fill 511 124 295 511 127 295 minecraft:deepslate_tiles
setblock 511 124 299 minecraft:cobbled_deepslate
fill 511 124 300 511 127 300 minecraft:deepslate_tiles
setblock 511 124 304 minecraft:cobbled_deepslate
fill 511 124 305 511 127 305 minecraft:deepslate_tiles
setblock 511 124 309 minecraft:cobbled_deepslate
fill 471 125 276 471 125 277 minecraft:deepslate_tiles
setblock 471 125 278 minecraft:cobbled_deepslate
fill 471 125 279 471 125 282 minecraft:deepslate_tiles
setblock 471 125 283 minecraft:cobbled_deepslate
fill 471 125 284 471 128 284 minecraft:deepslate_tiles
setblock 471 125 287 minecraft:deepslate_tiles
setblock 471 125 288 minecraft:cobbled_deepslate
fill 471 125 289 471 128 289 minecraft:deepslate_tiles
setblock 471 125 293 minecraft:cobbled_deepslate
fill 471 125 294 471 128 294 minecraft:deepslate_tiles
setblock 471 125 298 minecraft:cobbled_deepslate
fill 471 125 299 471 128 299 minecraft:deepslate_tiles
setblock 471 125 303 minecraft:cobbled_deepslate
fill 471 125 304 471 128 304 minecraft:deepslate_tiles
setblock 472 125 276 minecraft:deepslate_tiles
setblock 472 125 277 minecraft:cobbled_deepslate
fill 472 125 278 472 125 281 minecraft:deepslate_tiles
setblock 472 125 282 minecraft:cobbled_deepslate
fill 472 125 283 472 128 283 minecraft:deepslate_tiles
setblock 472 125 287 minecraft:cobbled_deepslate
fill 472 125 288 472 128 288 minecraft:deepslate_tiles
setblock 472 125 297 minecraft:cobbled_deepslate
fill 472 125 298 472 126 298 minecraft:deepslate_tiles
setblock 472 125 302 minecraft:cobbled_deepslate
fill 472 125 303 472 128 303 minecraft:deepslate_tiles
setblock 473 125 276 minecraft:cobbled_deepslate
fill 473 125 277 473 128 277 minecraft:deepslate_tiles
setblock 473 125 278 minecraft:light[level=13]
setblock 473 125 280 minecraft:deepslate_tiles
setblock 473 125 281 minecraft:cobbled_deepslate
fill 473 125 282 473 128 282 minecraft:deepslate_tiles
setblock 473 125 286 minecraft:cobbled_deepslate
setblock 473 125 294 minecraft:light[level=13]
setblock 473 125 301 minecraft:cobbled_deepslate
setblock 473 125 302 minecraft:light[level=13]
setblock 473 125 310 minecraft:light[level=13]
fill 474 125 276 477 125 276 minecraft:deepslate_tiles
setblock 474 125 281 minecraft:deepslate_tiles
fill 474 125 283 474 126 283 minecraft:deepslate_tiles
setblock 476 125 278 minecraft:cobbled_deepslate
setblock 477 125 277 minecraft:cobbled_deepslate
fill 477 125 278 477 126 278 minecraft:deepslate_tiles
setblock 478 125 276 minecraft:cobbled_deepslate
fill 478 125 277 481 125 277 minecraft:deepslate_tiles
fill 479 125 276 479 128 276 minecraft:deepslate_tiles
fill 479 125 291 479 133 291 minecraft:black_concrete
setblock 481 125 278 minecraft:light[level=13]
setblock 481 125 286 minecraft:light[level=13]
setblock 481 125 294 minecraft:light[level=13]
setblock 481 125 302 minecraft:light[level=13]
setblock 481 125 310 minecraft:light[level=13]
setblock 482 125 277 minecraft:cobbled_deepslate
setblock 483 125 276 minecraft:cobbled_deepslate
fill 484 125 276 484 126 276 minecraft:deepslate_tiles
setblock 488 125 276 minecraft:cobbled_deepslate
fill 489 125 276 489 128 276 minecraft:deepslate_tiles
setblock 489 125 278 minecraft:light[level=13]
setblock 489 125 286 minecraft:light[level=13]
setblock 489 125 302 minecraft:light[level=13]
setblock 489 125 310 minecraft:light[level=13]
setblock 492 125 277 minecraft:cobbled_deepslate
setblock 493 125 276 minecraft:cobbled_deepslate
fill 493 125 277 493 128 277 minecraft:deepslate_tiles
setblock 493 125 316 minecraft:cobbled_deepslate
fill 494 125 276 494 128 276 minecraft:deepslate_tiles
setblock 494 125 315 minecraft:cobbled_deepslate
fill 494 125 316 494 128 316 minecraft:deepslate_tiles
fill 495 125 315 495 128 315 minecraft:deepslate_tiles
setblock 496 125 278 minecraft:cobbled_deepslate
setblock 497 125 277 minecraft:cobbled_deepslate
setblock 497 125 278 minecraft:light[level=13]
setblock 497 125 286 minecraft:light[level=13]
setblock 497 125 294 minecraft:light[level=13]
setblock 497 125 302 minecraft:light[level=13]
setblock 497 125 310 minecraft:light[level=13]
setblock 498 125 276 minecraft:cobbled_deepslate
setblock 498 125 277 minecraft:deepslate_tiles
setblock 498 125 316 minecraft:cobbled_deepslate
fill 499 125 276 499 126 276 minecraft:deepslate_tiles
fill 499 125 316 499 127 316 minecraft:deepslate_tiles
setblock 505 125 278 minecraft:light[level=13]
setblock 505 125 286 minecraft:light[level=13]
setblock 505 125 294 minecraft:light[level=13]
setblock 505 125 302 minecraft:light[level=13]
setblock 505 125 310 minecraft:light[level=13]
fill 506 125 304 506 126 304 minecraft:black_concrete
fill 506 125 306 506 126 306 minecraft:black_concrete
fill 508 125 304 508 126 304 minecraft:black_concrete
fill 508 125 306 508 126 306 minecraft:black_concrete
setblock 510 125 299 minecraft:cobbled_deepslate
fill 510 125 300 510 128 300 minecraft:deepslate_tiles
setblock 510 125 304 minecraft:cobbled_deepslate
fill 510 125 305 510 128 305 minecraft:deepslate_tiles
fill 510 125 307 510 126 307 minecraft:deepslate_tiles
fill 511 125 279 511 128 279 minecraft:deepslate_tiles
setblock 511 125 282 minecraft:deepslate_tiles
setblock 511 125 283 minecraft:cobbled_deepslate
fill 511 125 284 511 128 284 minecraft:deepslate_tiles
fill 511 125 286 511 125 287 minecraft:deepslate_tiles
fill 511 125 294 511 128 294 minecraft:deepslate_tiles
setblock 511 125 298 minecraft:cobbled_deepslate
fill 511 125 299 511 128 299 minecraft:deepslate_tiles
setblock 511 125 303 minecraft:cobbled_deepslate
fill 511 125 304 511 128 304 minecraft:deepslate_tiles
setblock 511 125 308 minecraft:cobbled_deepslate
fill 511 125 309 511 128 309 minecraft:deepslate_tiles
setblock 471 126 277 minecraft:cobbled_deepslate
fill 471 126 278 471 126 281 minecraft:deepslate_tiles
setblock 471 126 282 minecraft:cobbled_deepslate
fill 471 126 283 471 129 283 minecraft:deepslate_tiles
setblock 471 126 287 minecraft:cobbled_deepslate
fill 471 126 288 471 129 288 minecraft:deepslate_tiles
setblock 471 126 292 minecraft:cobbled_deepslate
fill 471 126 293 471 129 293 minecraft:deepslate_tiles
setblock 471 126 297 minecraft:cobbled_deepslate
fill 471 126 298 471 129 298 minecraft:deepslate_tiles
setblock 471 126 302 minecraft:cobbled_deepslate
fill 471 126 303 471 129 303 minecraft:deepslate_tiles
setblock 471 126 307 minecraft:cobbled_deepslate
fill 471 126 308 471 129 308 minecraft:deepslate_tiles
setblock 472 126 276 minecraft:cobbled_deepslate
fill 472 126 278 472 126 280 minecraft:deepslate_tiles
setblock 472 126 281 minecraft:cobbled_deepslate
fill 472 126 282 472 129 282 minecraft:deepslate_tiles
setblock 472 126 285 minecraft:deepslate_tiles
setblock 472 126 286 minecraft:cobbled_deepslate
fill 472 126 287 473 128 287 minecraft:deepslate_tiles
setblock 472 126 290 minecraft:deepslate_tiles
setblock 472 126 297 minecraft:deepslate_tiles
setblock 472 126 301 minecraft:cobbled_deepslate
fill 472 126 302 472 129 302 minecraft:deepslate_tiles
setblock 472 126 306 minecraft:cobbled_deepslate
fill 473 126 276 476 126 276 minecraft:deepslate_tiles
setblock 473 126 280 minecraft:cobbled_deepslate
fill 473 126 281 473 129 281 minecraft:deepslate_tiles
setblock 473 126 285 minecraft:cobbled_deepslate
fill 473 126 286 473 129 286 minecraft:deepslate_tiles
setblock 474 126 284 minecraft:cobbled_deepslate
setblock 475 126 278 minecraft:cobbled_deepslate
setblock 476 126 277 minecraft:cobbled_deepslate
setblock 476 126 278 minecraft:deepslate_tiles
setblock 477 126 276 minecraft:cobbled_deepslate
fill 477 126 277 480 126 277 minecraft:deepslate_tiles
fill 478 126 276 478 129 276 minecraft:deepslate_tiles
fill 479 126 290 480 133 290 minecraft:black_concrete
fill 480 126 292 480 133 292 minecraft:black_concrete
setblock 482 126 276 minecraft:cobbled_deepslate
setblock 483 126 276 minecraft:deepslate_tiles
setblock 487 126 276 minecraft:cobbled_deepslate
fill 488 126 276 488 129 276 minecraft:deepslate_tiles
setblock 489 126 275 minecraft:redstone_block
fill 490 126 275 490 173 275 minecraft:black_concrete
setblock 490 126 277 minecraft:deepslate_tiles
setblock 491 126 277 minecraft:cobbled_deepslate
setblock 492 126 276 minecraft:cobbled_deepslate
fill 492 126 277 492 128 277 minecraft:deepslate_tiles
setblock 492 126 316 minecraft:cobbled_deepslate
fill 493 126 276 493 129 276 minecraft:deepslate_tiles
fill 493 126 316 493 129 316 minecraft:deepslate_tiles
fill 494 126 315 494 129 315 minecraft:deepslate_tiles
setblock 496 126 277 minecraft:cobbled_deepslate
setblock 497 126 276 minecraft:cobbled_deepslate
setblock 497 126 277 minecraft:deepslate_tiles
setblock 497 126 316 minecraft:cobbled_deepslate
fill 498 126 276 498 127 276 minecraft:deepslate_tiles
fill 498 126 316 498 129 316 minecraft:deepslate_tiles
fill 507 126 280 507 127 280 minecraft:black_concrete
fill 508 126 279 508 127 279 minecraft:black_concrete
fill 508 126 281 508 127 281 minecraft:black_concrete
fill 509 126 280 509 127 280 minecraft:black_concrete
fill 510 126 299 510 129 299 minecraft:deepslate_tiles
setblock 510 126 303 minecraft:cobbled_deepslate
fill 510 126 304 510 129 304 minecraft:deepslate_tiles
setblock 511 126 282 minecraft:cobbled_deepslate
fill 511 126 283 511 129 283 minecraft:deepslate_tiles
setblock 511 126 286 minecraft:deepslate_tiles
setblock 511 126 287 minecraft:cobbled_deepslate
fill 511 126 288 511 127 290 minecraft:deepslate_tiles
fill 511 126 293 511 129 293 minecraft:deepslate_tiles
setblock 511 126 297 minecraft:cobbled_deepslate
fill 511 126 298 511 129 298 minecraft:deepslate_tiles
setblock 511 126 302 minecraft:cobbled_deepslate
fill 511 126 303 511 129 303 minecraft:deepslate_tiles
setblock 511 126 307 minecraft:cobbled_deepslate
fill 511 126 308 511 129 308 minecraft:deepslate_tiles
fill 511 126 310 511 127 310 minecraft:deepslate_tiles
fill 471 127 277 471 127 280 minecraft:deepslate_tiles
setblock 471 127 281 minecraft:cobbled_deepslate
fill 471 127 282 471 130 282 minecraft:deepslate_tiles
setblock 471 127 286 minecraft:cobbled_deepslate
fill 471 127 287 471 130 287 minecraft:deepslate_tiles
setblock 471 127 291 minecraft:cobbled_deepslate
fill 471 127 292 471 130 292 minecraft:deepslate_tiles
setblock 471 127 296 minecraft:cobbled_deepslate
fill 471 127 297 471 130 297 minecraft:deepslate_tiles
setblock 471 127 301 minecraft:cobbled_deepslate
fill 471 127 302 471 130 302 minecraft:deepslate_tiles
setblock 471 127 306 minecraft:cobbled_deepslate
fill 471 127 307 471 130 307 minecraft:deepslate_tiles
fill 472 127 276 475 127 276 minecraft:deepslate_tiles
fill 472 127 278 472 127 279 minecraft:deepslate_tiles
setblock 472 127 280 minecraft:cobbled_deepslate
fill 472 127 281 472 130 281 minecraft:deepslate_tiles
setblock 472 127 285 minecraft:cobbled_deepslate
fill 472 127 286 472 130 286 minecraft:deepslate_tiles
setblock 472 127 290 minecraft:cobbled_deepslate
fill 472 127 291 472 130 291 minecraft:deepslate_tiles
setblock 472 127 300 minecraft:cobbled_deepslate
fill 472 127 301 472 130 301 minecraft:deepslate_tiles
setblock 472 127 305 minecraft:cobbled_deepslate
fill 472 127 306 472 130 306 minecraft:deepslate_tiles
setblock 473 127 278 minecraft:light[level=12]
setblock 473 127 279 minecraft:cobbled_deepslate
fill 473 127 280 473 130 280 minecraft:deepslate_tiles
setblock 473 127 284 minecraft:cobbled_deepslate
fill 473 127 285 474 129 285 minecraft:deepslate_tiles
setblock 473 127 288 minecraft:deepslate_tiles
setblock 473 127 292 minecraft:light[level=12]
setblock 473 127 299 minecraft:light[level=12]
setblock 473 127 306 minecraft:light[level=12]
setblock 473 127 313 minecraft:light[level=12]
setblock 474 127 283 minecraft:cobbled_deepslate
fill 474 127 284 474 130 284 minecraft:deepslate_tiles
setblock 475 127 277 minecraft:cobbled_deepslate
setblock 476 127 276 minecraft:cobbled_deepslate
fill 476 127 277 479 127 277 minecraft:deepslate_tiles
fill 477 127 276 477 130 276 minecraft:deepslate_tiles
fill 478 127 291 478 133 291 minecraft:black_concrete
fill 479 127 292 479 133 292 minecraft:black_concrete
setblock 480 127 278 minecraft:light[level=12]
setblock 480 127 285 minecraft:light[level=12]
setblock 480 127 299 minecraft:light[level=12]
setblock 480 127 306 minecraft:light[level=12]
setblock 480 127 313 minecraft:light[level=12]
setblock 481 127 276 minecraft:cobbled_deepslate
fill 481 127 290 481 133 291 minecraft:black_concrete
fill 483 127 275 483 197 275 minecraft:black_concrete
setblock 484 127 275 minecraft:white_wool
fill 485 127 275 489 130 275 minecraft:black_concrete
setblock 487 127 278 minecraft:light[level=12]
setblock 487 127 285 minecraft:light[level=12]
setblock 487 127 292 minecraft:light[level=12]
setblock 487 127 299 minecraft:light[level=12]
setblock 487 127 306 minecraft:light[level=12]
setblock 487 127 313 minecraft:light[level=12]
setblock 491 127 276 minecraft:cobbled_deepslate
setblock 491 127 277 minecraft:deepslate_tiles
setblock 491 127 316 minecraft:cobbled_deepslate
fill 492 127 276 492 130 276 minecraft:deepslate_tiles
fill 492 127 316 492 130 316 minecraft:deepslate_tiles
setblock 494 127 278 minecraft:light[level=12]
setblock 494 127 285 minecraft:light[level=12]
setblock 494 127 292 minecraft:light[level=12]
setblock 494 127 299 minecraft:light[level=12]
setblock 494 127 306 minecraft:light[level=12]
setblock 494 127 313 minecraft:light[level=12]
setblock 495 127 277 minecraft:cobbled_deepslate
setblock 496 127 276 minecraft:cobbled_deepslate
setblock 496 127 316 minecraft:cobbled_deepslate
fill 497 127 276 497 128 276 minecraft:deepslate_tiles
fill 497 127 316 497 130 316 minecraft:deepslate_tiles
setblock 501 127 278 minecraft:light[level=12]
setblock 501 127 285 minecraft:light[level=12]
setblock 501 127 292 minecraft:light[level=12]
setblock 501 127 299 minecraft:light[level=12]
setblock 501 127 306 minecraft:light[level=12]
setblock 501 127 313 minecraft:light[level=12]
setblock 507 127 279 minecraft:black_concrete
setblock 507 127 281 minecraft:black_concrete
setblock 508 127 278 minecraft:light[level=12]
setblock 508 127 285 minecraft:light[level=12]
setblock 508 127 292 minecraft:light[level=12]
setblock 508 127 299 minecraft:light[level=12]
setblock 508 127 306 minecraft:light[level=12]
setblock 508 127 313 minecraft:light[level=12]
setblock 509 127 279 minecraft:black_concrete
setblock 509 127 281 minecraft:black_concrete
setblock 510 127 302 minecraft:cobbled_deepslate
fill 510 127 303 510 130 303 minecraft:deepslate_tiles
setblock 510 127 307 minecraft:cobbled_deepslate
fill 510 127 308 510 130 308 minecraft:deepslate_tiles
setblock 511 127 281 minecraft:cobbled_deepslate
fill 511 127 282 511 130 282 minecraft:deepslate_tiles
setblock 511 127 286 minecraft:cobbled_deepslate
fill 511 127 287 511 130 287 minecraft:deepslate_tiles
setblock 511 127 291 minecraft:cobbled_deepslate
fill 511 127 292 511 130 292 minecraft:deepslate_tiles
setblock 511 127 296 minecraft:cobbled_deepslate
fill 511 127 297 511 130 297 minecraft:deepslate_tiles
setblock 511 127 301 minecraft:cobbled_deepslate
fill 511 127 302 511 130 302 minecraft:deepslate_tiles
setblock 511 127 306 minecraft:cobbled_deepslate
fill 511 127 307 511 130 307 minecraft:deepslate_tiles
fill 471 128 276 471 128 279 minecraft:deepslate_tiles
setblock 471 128 280 minecraft:cobbled_deepslate
fill 471 128 281 471 131 281 minecraft:deepslate_tiles
setblock 471 128 285 minecraft:cobbled_deepslate
fill 471 128 286 471 131 286 minecraft:deepslate_tiles
setblock 471 128 290 minecraft:cobbled_deepslate
fill 471 128 291 471 131 291 minecraft:deepslate_tiles
setblock 471 128 295 minecraft:cobbled_deepslate
fill 471 128 296 471 131 296 minecraft:deepslate_tiles
setblock 471 128 300 minecraft:cobbled_deepslate
fill 471 128 301 471 131 301 minecraft:deepslate_tiles
setblock 471 128 305 minecraft:cobbled_deepslate
fill 471 128 306 471 131 306 minecraft:deepslate_tiles
setblock 471 128 309 minecraft:deepslate_tiles
fill 472 128 276 474 128 276 minecraft:deepslate_tiles
setblock 472 128 278 minecraft:deepslate_tiles
setblock 472 128 279 minecraft:cobbled_deepslate
fill 472 128 280 472 131 280 minecraft:deepslate_tiles
setblock 472 128 284 minecraft:cobbled_deepslate
fill 472 128 285 472 131 285 minecraft:deepslate_tiles
setblock 472 128 289 minecraft:cobbled_deepslate
fill 472 128 290 472 131 290 minecraft:deepslate_tiles
fill 472 128 292 472 129 292 minecraft:deepslate_tiles
fill 472 128 300 472 129 300 minecraft:deepslate_tiles
setblock 472 128 304 minecraft:cobbled_deepslate
fill 472 128 305 472 131 305 minecraft:deepslate_tiles
fill 472 128 307 472 129 307 minecraft:deepslate_tiles
fill 473 128 279 473 131 279 minecraft:deepslate_tiles
setblock 473 128 283 minecraft:cobbled_deepslate
fill 473 128 284 473 131 284 minecraft:deepslate_tiles
setblock 473 128 288 minecraft:cobbled_deepslate
fill 473 128 289 473 131 289 minecraft:deepslate_tiles
setblock 474 128 277 minecraft:cobbled_deepslate
setblock 474 128 282 minecraft:cobbled_deepslate
fill 474 128 283 474 131 283 minecraft:deepslate_tiles
setblock 474 128 286 minecraft:deepslate_tiles
fill 474 128 291 474 129 291 minecraft:white_wool
setblock 475 128 276 minecraft:cobbled_deepslate
fill 475 128 277 477 129 277 minecraft:deepslate_tiles
fill 476 128 276 476 131 276 minecraft:deepslate_tiles
fill 478 128 290 478 133 290 minecraft:black_concrete
fill 478 128 292 478 133 292 minecraft:black_concrete
fill 479 128 289 480 133 289 minecraft:black_concrete
setblock 480 128 276 minecraft:cobbled_deepslate
fill 480 128 293 480 133 293 minecraft:black_concrete
fill 481 128 292 481 133 292 minecraft:black_concrete
fill 484 128 275 484 201 275 minecraft:black_concrete
setblock 490 128 276 minecraft:cobbled_deepslate
setblock 490 128 316 minecraft:cobbled_deepslate
fill 491 128 276 491 131 276 minecraft:deepslate_tiles
fill 491 128 316 491 131 316 minecraft:deepslate_tiles
fill 493 128 315 493 130 315 minecraft:deepslate_tiles
setblock 494 128 277 minecraft:cobbled_deepslate
setblock 495 128 276 minecraft:cobbled_deepslate
setblock 495 128 316 minecraft:cobbled_deepslate
fill 496 128 276 496 129 276 minecraft:deepslate_tiles
fill 496 128 316 496 131 316 minecraft:deepslate_tiles
setblock 499 128 317 minecraft:redstone_block
fill 510 128 284 510 128 285 minecraft:deepslate_tiles
setblock 510 128 286 minecraft:cobbled_deepslate
setblock 510 128 301 minecraft:cobbled_deepslate
fill 510 128 302 510 131 302 minecraft:deepslate_tiles
setblock 510 128 306 minecraft:cobbled_deepslate
fill 510 128 307 510 131 307 minecraft:deepslate_tiles
setblock 511 128 280 minecraft:cobbled_deepslate
fill 511 128 281 511 131 281 minecraft:deepslate_tiles
setblock 511 128 285 minecraft:cobbled_deepslate
fill 511 128 286 511 131 286 minecraft:deepslate_tiles
fill 511 128 288 511 128 289 minecraft:deepslate_tiles
setblock 511 128 290 minecraft:cobbled_deepslate
fill 511 128 291 511 131 291 minecraft:deepslate_tiles
setblock 511 128 295 minecraft:cobbled_deepslate
fill 511 128 296 511 131 296 minecraft:deepslate_tiles
setblock 511 128 300 minecraft:cobbled_deepslate
fill 511 128 301 511 131 301 minecraft:deepslate_tiles
setblock 511 128 305 minecraft:cobbled_deepslate
fill 511 128 306 511 131 306 minecraft:deepslate_tiles
setblock 511 128 310 minecraft:cobbled_deepslate
fill 511 128 311 511 131 311 minecraft:deepslate_tiles
fill 471 129 276 471 129 278 minecraft:deepslate_tiles
setblock 471 129 279 minecraft:cobbled_deepslate
fill 471 129 280 471 132 280 minecraft:deepslate_tiles
setblock 471 129 284 minecraft:cobbled_deepslate
fill 471 129 285 471 132 285 minecraft:deepslate_tiles
setblock 471 129 289 minecraft:cobbled_deepslate
fill 471 129 290 471 132 290 minecraft:deepslate_tiles
setblock 471 129 294 minecraft:cobbled_deepslate
fill 471 129 295 471 132 295 minecraft:deepslate_tiles
setblock 471 129 299 minecraft:cobbled_deepslate
fill 471 129 300 471 132 300 minecraft:deepslate_tiles
setblock 471 129 304 minecraft:cobbled_deepslate
fill 471 129 305 471 132 305 minecraft:deepslate_tiles
setblock 471 129 309 minecraft:cobbled_deepslate
fill 471 129 310 471 131 311 minecraft:deepslate_tiles
fill 472 129 276 473 129 276 minecraft:deepslate_tiles
setblock 472 129 278 minecraft:cobbled_deepslate
fill 472 129 279 472 132 279 minecraft:deepslate_tiles
setblock 472 129 283 minecraft:cobbled_deepslate
fill 472 129 284 472 132 284 minecraft:deepslate_tiles
setblock 472 129 287 minecraft:deepslate_tiles
setblock 472 129 288 minecraft:cobbled_deepslate
fill 472 129 289 472 132 289 minecraft:deepslate_tiles
setblock 472 129 293 minecraft:cobbled_deepslate
setblock 472 129 303 minecraft:cobbled_deepslate
fill 472 129 304 472 132 304 minecraft:deepslate_tiles
setblock 472 129 308 minecraft:cobbled_deepslate
setblock 473 129 277 minecraft:cobbled_deepslate
setblock 473 129 282 minecraft:cobbled_deepslate
fill 473 129 283 473 132 283 minecraft:deepslate_tiles
setblock 473 129 287 minecraft:cobbled_deepslate
fill 473 129 288 473 132 288 minecraft:deepslate_tiles
fill 473 129 290 473 130 290 minecraft:deepslate_tiles
setblock 474 129 276 minecraft:cobbled_deepslate
fill 474 129 277 474 132 277 minecraft:deepslate_tiles
fill 474 129 282 474 132 282 minecraft:deepslate_tiles
setblock 474 129 286 minecraft:cobbled_deepslate
fill 474 129 287 474 132 287 minecraft:deepslate_tiles
fill 475 129 276 475 132 276 minecraft:deepslate_tiles
fill 477 129 290 477 133 291 minecraft:black_concrete
fill 478 129 289 478 133 289 minecraft:black_concrete
fill 478 129 293 479 133 293 minecraft:black_concrete
setblock 479 129 276 minecraft:cobbled_deepslate
fill 481 129 289 481 133 289 minecraft:black_concrete
fill 481 129 293 481 133 293 minecraft:black_concrete
fill 482 129 290 482 133 292 minecraft:black_concrete
setblock 489 129 276 minecraft:cobbled_deepslate
setblock 489 129 316 minecraft:cobbled_deepslate
fill 490 129 276 490 132 276 minecraft:deepslate_tiles
fill 490 129 316 490 132 316 minecraft:deepslate_tiles
fill 491 129 315 492 131 315 minecraft:deepslate_tiles
setblock 494 129 276 minecraft:cobbled_deepslate
setblock 494 129 316 minecraft:cobbled_deepslate
fill 495 129 276 495 132 276 minecraft:deepslate_tiles
setblock 495 129 315 minecraft:cobbled_deepslate
fill 495 129 316 495 132 316 minecraft:deepslate_tiles
fill 496 129 315 496 132 315 minecraft:deepslate_tiles
fill 499 129 317 499 197 317 minecraft:black_concrete
fill 509 129 304 509 129 305 minecraft:deepslate_tiles
fill 510 129 282 510 129 284 minecraft:deepslate_tiles
setblock 510 129 285 minecraft:cobbled_deepslate
fill 510 129 286 510 129 289 minecraft:deepslate_tiles
setblock 510 129 290 minecraft:cobbled_deepslate
setblock 510 129 300 minecraft:cobbled_deepslate
fill 510 129 301 510 132 301 minecraft:deepslate_tiles
setblock 510 129 305 minecraft:cobbled_deepslate
fill 510 129 306 510 132 306 minecraft:deepslate_tiles
setblock 510 129 309 minecraft:deepslate_tiles
setblock 511 129 279 minecraft:cobbled_deepslate
fill 511 129 280 511 132 280 minecraft:deepslate_tiles
setblock 511 129 284 minecraft:cobbled_deepslate
fill 511 129 285 511 132 285 minecraft:deepslate_tiles
setblock 511 129 288 minecraft:deepslate_tiles
setblock 511 129 289 minecraft:cobbled_deepslate
fill 511 129 290 511 132 290 minecraft:deepslate_tiles
setblock 511 129 294 minecraft:cobbled_deepslate
fill 511 129 295 511 132 295 minecraft:deepslate_tiles
setblock 511 129 299 minecraft:cobbled_deepslate
fill 511 129 300 511 132 300 minecraft:deepslate_tiles
setblock 511 129 304 minecraft:cobbled_deepslate
fill 511 129 305 511 132 305 minecraft:deepslate_tiles
setblock 511 129 309 minecraft:cobbled_deepslate
fill 511 129 310 511 132 310 minecraft:deepslate_tiles
fill 511 129 312 511 130 312 minecraft:deepslate_tiles
fill 471 130 276 471 130 277 minecraft:deepslate_tiles
setblock 471 130 278 minecraft:cobbled_deepslate
fill 471 130 279 471 133 279 minecraft:deepslate_tiles
setblock 471 130 283 minecraft:cobbled_deepslate
fill 471 130 284 471 133 284 minecraft:deepslate_tiles
setblock 471 130 288 minecraft:cobbled_deepslate
fill 471 130 289 471 133 289 minecraft:deepslate_tiles
setblock 471 130 293 minecraft:cobbled_deepslate
fill 471 130 294 472 132 294 minecraft:deepslate_tiles
setblock 471 130 298 minecraft:cobbled_deepslate
fill 471 130 299 471 133 299 minecraft:deepslate_tiles
setblock 471 130 303 minecraft:cobbled_deepslate
fill 471 130 304 471 133 304 minecraft:deepslate_tiles
setblock 471 130 308 minecraft:cobbled_deepslate
fill 471 130 309 472 132 309 minecraft:deepslate_tiles
setblock 471 130 312 minecraft:deepslate_tiles
setblock 472 130 276 minecraft:deepslate_tiles
setblock 472 130 277 minecraft:cobbled_deepslate
fill 472 130 278 472 133 278 minecraft:deepslate_tiles
setblock 472 130 282 minecraft:cobbled_deepslate
fill 472 130 283 472 133 283 minecraft:deepslate_tiles
setblock 472 130 287 minecraft:cobbled_deepslate
fill 472 130 288 472 133 288 minecraft:deepslate_tiles
setblock 472 130 292 minecraft:cobbled_deepslate
fill 472 130 293 472 133 293 minecraft:deepslate_tiles
setblock 472 130 302 minecraft:cobbled_deepslate
fill 472 130 303 472 133 303 minecraft:deepslate_tiles
setblock 472 130 307 minecraft:cobbled_deepslate
fill 472 130 308 472 133 308 minecraft:deepslate_tiles
setblock 473 130 276 minecraft:cobbled_deepslate
fill 473 130 277 473 133 277 minecraft:deepslate_tiles
setblock 473 130 281 minecraft:cobbled_deepslate
fill 473 130 282 473 133 282 minecraft:deepslate_tiles
setblock 473 130 285 minecraft:deepslate_tiles
setblock 473 130 286 minecraft:cobbled_deepslate
fill 473 130 287 473 133 287 minecraft:deepslate_tiles
setblock 473 130 291 minecraft:cobbled_deepslate
fill 474 130 276 474 133 276 minecraft:deepslate_tiles
setblock 474 130 285 minecraft:cobbled_deepslate
fill 474 130 286 474 133 286 minecraft:deepslate_tiles
fill 474 130 288 474 131 288 minecraft:deepslate_tiles
fill 475 130 277 476 130 277 minecraft:deepslate_tiles
fill 477 130 289 477 133 289 minecraft:black_concrete
fill 477 130 292 477 133 292 minecraft:black_concrete
setblock 478 130 276 minecraft:cobbled_deepslate
fill 479 130 276 479 133 276 minecraft:deepslate_tiles
fill 479 130 288 481 133 288 minecraft:black_concrete
fill 480 130 294 480 133 294 minecraft:black_concrete
fill 482 130 289 482 133 289 minecraft:black_concrete
setblock 487 130 276 minecraft:deepslate_tiles
setblock 487 130 316 minecraft:deepslate_tiles
setblock 488 130 276 minecraft:cobbled_deepslate
setblock 488 130 316 minecraft:cobbled_deepslate
fill 489 130 276 489 133 276 minecraft:deepslate_tiles
fill 489 130 316 489 133 316 minecraft:deepslate_tiles
fill 490 130 315 490 133 315 minecraft:deepslate_tiles
setblock 493 130 276 minecraft:cobbled_deepslate
setblock 493 130 316 minecraft:cobbled_deepslate
fill 494 130 276 494 133 276 minecraft:deepslate_tiles
setblock 494 130 315 minecraft:cobbled_deepslate
fill 494 130 316 494 133 316 minecraft:deepslate_tiles
fill 495 130 315 495 133 315 minecraft:deepslate_tiles
setblock 498 130 316 minecraft:cobbled_deepslate
fill 509 130 303 509 130 304 minecraft:deepslate_tiles
setblock 509 130 305 minecraft:cobbled_deepslate
fill 509 130 306 509 132 307 minecraft:deepslate_tiles
fill 510 130 282 510 130 283 minecraft:deepslate_tiles
setblock 510 130 284 minecraft:cobbled_deepslate
fill 510 130 285 510 130 288 minecraft:deepslate_tiles
setblock 510 130 289 minecraft:cobbled_deepslate
fill 510 130 290 510 130 293 minecraft:deepslate_tiles
setblock 510 130 294 minecraft:cobbled_deepslate
fill 510 130 297 510 130 298 minecraft:deepslate_tiles
setblock 510 130 299 minecraft:cobbled_deepslate
fill 510 130 300 510 133 300 minecraft:deepslate_tiles
setblock 510 130 304 minecraft:cobbled_deepslate
fill 510 130 305 510 133 305 minecraft:deepslate_tiles
setblock 510 130 309 minecraft:cobbled_deepslate
fill 510 130 310 510 133 310 minecraft:deepslate_tiles
setblock 511 130 278 minecraft:cobbled_deepslate
fill 511 130 279 511 133 279 minecraft:deepslate_tiles
setblock 511 130 283 minecraft:cobbled_deepslate
fill 511 130 284 511 133 284 minecraft:deepslate_tiles
setblock 511 130 288 minecraft:cobbled_deepslate
fill 511 130 289 511 133 289 minecraft:deepslate_tiles
setblock 511 130 293 minecraft:cobbled_deepslate
fill 511 130 294 511 133 294 minecraft:deepslate_tiles
setblock 511 130 298 minecraft:cobbled_deepslate
fill 511 130 299 511 133 299 minecraft:deepslate_tiles
setblock 511 130 303 minecraft:cobbled_deepslate
fill 511 130 304 511 133 304 minecraft:deepslate_tiles
setblock 511 130 308 minecraft:cobbled_deepslate
fill 511 130 309 511 133 309 minecraft:deepslate_tiles
setblock 511 130 313 minecraft:cobbled_deepslate
setblock 471 131 276 minecraft:deepslate_tiles
setblock 471 131 277 minecraft:cobbled_deepslate
fill 471 131 278 471 134 278 minecraft:deepslate_tiles
setblock 471 131 282 minecraft:cobbled_deepslate
fill 471 131 283 471 134 283 minecraft:deepslate_tiles
setblock 471 131 287 minecraft:cobbled_deepslate
fill 471 131 288 471 134 288 minecraft:deepslate_tiles
setblock 471 131 292 minecraft:cobbled_deepslate
fill 471 131 293 471 134 293 minecraft:deepslate_tiles
setblock 471 131 297 minecraft:cobbled_deepslate
fill 471 131 298 471 134 298 minecraft:deepslate_tiles
setblock 471 131 302 minecraft:cobbled_deepslate
fill 471 131 303 471 134 303 minecraft:deepslate_tiles
setblock 471 131 307 minecraft:cobbled_deepslate
fill 471 131 308 471 134 308 minecraft:deepslate_tiles
setblock 471 131 312 minecraft:cobbled_deepslate
fill 471 131 313 471 133 314 minecraft:deepslate_tiles
setblock 472 131 276 minecraft:cobbled_deepslate
fill 472 131 277 472 134 277 minecraft:deepslate_tiles
setblock 472 131 281 minecraft:cobbled_deepslate
fill 472 131 282 472 134 282 minecraft:deepslate_tiles
setblock 472 131 286 minecraft:cobbled_deepslate
fill 472 131 287 472 134 287 minecraft:deepslate_tiles
setblock 472 131 291 minecraft:cobbled_deepslate
fill 472 131 292 473 133 292 minecraft:deepslate_tiles
setblock 472 131 295 minecraft:deepslate_tiles
setblock 472 131 301 minecraft:cobbled_deepslate
fill 472 131 302 472 132 302 minecraft:deepslate_tiles
setblock 472 131 306 minecraft:cobbled_deepslate
fill 472 131 307 472 134 307 minecraft:deepslate_tiles
setblock 472 131 310 minecraft:deepslate_tiles
setblock 472 131 311 minecraft:cobbled_deepslate
setblock 472 131 316 minecraft:cobbled_deepslate
fill 473 131 276 473 134 276 minecraft:deepslate_tiles
setblock 473 131 280 minecraft:cobbled_deepslate
fill 473 131 281 473 134 281 minecraft:deepslate_tiles
setblock 473 131 285 minecraft:cobbled_deepslate
fill 473 131 286 473 134 286 minecraft:deepslate_tiles
setblock 473 131 290 minecraft:cobbled_deepslate
fill 473 131 291 473 134 291 minecraft:deepslate_tiles
fill 473 131 316 475 132 316 minecraft:deepslate_tiles
setblock 474 131 284 minecraft:cobbled_deepslate
fill 474 131 285 474 134 285 minecraft:deepslate_tiles
setblock 474 131 289 minecraft:cobbled_deepslate
setblock 475 131 277 minecraft:deepslate_tiles
setblock 476 131 277 minecraft:cobbled_deepslate
fill 476 131 290 476 133 291 minecraft:black_concrete
setblock 477 131 276 minecraft:cobbled_deepslate
fill 477 131 293 477 133 293 minecraft:black_concrete
fill 478 131 276 478 134 276 minecraft:deepslate_tiles
fill 478 131 288 478 133 288 minecraft:black_concrete
fill 478 131 294 479 133 294 minecraft:black_concrete
fill 481 131 294 481 133 294 minecraft:black_concrete
fill 482 131 293 482 133 293 minecraft:black_concrete
fill 483 131 290 483 133 292 minecraft:black_concrete
setblock 485 131 275 minecraft:redstone_block
fill 486 131 275 489 179 275 minecraft:black_concrete
setblock 486 131 276 minecraft:deepslate_tiles
setblock 486 131 316 minecraft:deepslate_tiles
setblock 487 131 276 minecraft:cobbled_deepslate
setblock 487 131 316 minecraft:cobbled_deepslate
fill 488 131 276 488 134 276 minecraft:deepslate_tiles
setblock 488 131 315 minecraft:cobbled_deepslate
fill 488 131 316 488 134 316 minecraft:deepslate_tiles
fill 489 131 315 489 134 315 minecraft:deepslate_tiles
fill 490 131 314 493 131 314 minecraft:deepslate_tiles
setblock 491 131 277 minecraft:cobbled_deepslate
setblock 492 131 276 minecraft:cobbled_deepslate
setblock 492 131 316 minecraft:cobbled_deepslate
fill 493 131 276 493 134 276 minecraft:deepslate_tiles
setblock 493 131 315 minecraft:cobbled_deepslate
fill 493 131 316 493 134 316 minecraft:deepslate_tiles
setblock 494 131 314 minecraft:cobbled_deepslate
fill 494 131 315 494 134 315 minecraft:deepslate_tiles
fill 495 131 314 495 134 314 minecraft:deepslate_tiles
setblock 497 131 316 minecraft:cobbled_deepslate
fill 498 131 316 498 134 316 minecraft:deepslate_tiles
fill 509 131 285 509 131 288 minecraft:deepslate_tiles
setblock 509 131 289 minecraft:cobbled_deepslate
fill 509 131 290 510 133 290 minecraft:deepslate_tiles
fill 509 131 302 509 131 303 minecraft:deepslate_tiles
setblock 509 131 304 minecraft:cobbled_deepslate
fill 509 131 305 509 134 305 minecraft:deepslate_tiles
setblock 509 131 308 minecraft:deepslate_tiles
setblock 509 131 309 minecraft:cobbled_deepslate
fill 510 131 281 510 131 282 minecraft:deepslate_tiles
setblock 510 131 283 minecraft:cobbled_deepslate
fill 510 131 284 510 131 287 minecraft:deepslate_tiles
setblock 510 131 288 minecraft:cobbled_deepslate
fill 510 131 289 510 134 289 minecraft:deepslate_tiles
fill 510 131 291 510 131 292 minecraft:deepslate_tiles
setblock 510 131 293 minecraft:cobbled_deepslate
fill 510 131 294 510 131 297 minecraft:deepslate_tiles
setblock 510 131 298 minecraft:cobbled_deepslate
fill 510 131 299 510 134 299 minecraft:deepslate_tiles
setblock 510 131 303 minecraft:cobbled_deepslate
fill 510 131 304 510 134 304 minecraft:deepslate_tiles
setblock 510 131 308 minecraft:cobbled_deepslate
fill 510 131 309 510 134 309 minecraft:deepslate_tiles
fill 510 131 311 510 131 312 minecraft:deepslate_tiles
fill 511 131 278 511 134 278 minecraft:deepslate_tiles
setblock 511 131 282 minecraft:cobbled_deepslate
fill 511 131 283 511 134 283 minecraft:deepslate_tiles
setblock 511 131 287 minecraft:cobbled_deepslate
fill 511 131 288 511 134 288 minecraft:deepslate_tiles
setblock 511 131 292 minecraft:cobbled_deepslate
fill 511 131 293 511 134 293 minecraft:deepslate_tiles
setblock 511 131 297 minecraft:cobbled_deepslate
fill 511 131 298 511 134 298 minecraft:deepslate_tiles
setblock 511 131 302 minecraft:cobbled_deepslate
fill 511 131 303 511 134 303 minecraft:deepslate_tiles
setblock 511 131 307 minecraft:cobbled_deepslate
fill 511 131 308 511 134 308 minecraft:deepslate_tiles
setblock 511 131 312 minecraft:cobbled_deepslate
fill 511 131 313 511 133 314 minecraft:deepslate_tiles
setblock 471 132 276 minecraft:cobbled_deepslate
fill 471 132 277 471 135 277 minecraft:deepslate_tiles
setblock 471 132 281 minecraft:cobbled_deepslate
fill 471 132 282 471 135 282 minecraft:deepslate_tiles
setblock 471 132 286 minecraft:cobbled_deepslate
fill 471 132 287 471 135 287 minecraft:deepslate_tiles
setblock 471 132 291 minecraft:cobbled_deepslate
fill 471 132 292 471 135 292 minecraft:deepslate_tiles
setblock 471 132 296 minecraft:cobbled_deepslate
fill 471 132 297 471 135 297 minecraft:deepslate_tiles
setblock 471 132 301 minecraft:cobbled_deepslate
fill 471 132 302 471 135 302 minecraft:deepslate_tiles
setblock 471 132 306 minecraft:cobbled_deepslate
fill 471 132 307 471 135 307 minecraft:deepslate_tiles
setblock 471 132 310 minecraft:deepslate_tiles
setblock 471 132 311 minecraft:cobbled_deepslate
fill 471 132 312 472 134 312 minecraft:deepslate_tiles
setblock 471 132 315 minecraft:deepslate_tiles
setblock 471 132 316 minecraft:cobbled_deepslate
fill 472 132 276 472 135 276 minecraft:deepslate_tiles
setblock 472 132 280 minecraft:cobbled_deepslate
fill 472 132 281 472 135 281 minecraft:deepslate_tiles
setblock 472 132 285 minecraft:cobbled_deepslate
fill 472 132 286 472 135 286 minecraft:deepslate_tiles
setblock 472 132 290 minecraft:cobbled_deepslate
fill 472 132 291 472 135 291 minecraft:deepslate_tiles
setblock 472 132 295 minecraft:cobbled_deepslate
fill 472 132 296 472 135 296 minecraft:deepslate_tiles
setblock 472 132 305 minecraft:cobbled_deepslate
fill 472 132 306 472 135 306 minecraft:deepslate_tiles
setblock 472 132 310 minecraft:cobbled_deepslate
fill 472 132 311 472 135 311 minecraft:deepslate_tiles
fill 472 132 313 472 133 313 minecraft:deepslate_tiles
fill 472 132 316 472 135 316 minecraft:deepslate_tiles
setblock 473 132 279 minecraft:cobbled_deepslate
fill 473 132 280 473 135 280 minecraft:deepslate_tiles
setblock 473 132 284 minecraft:cobbled_deepslate
fill 473 132 285 473 135 285 minecraft:deepslate_tiles
setblock 473 132 289 minecraft:cobbled_deepslate
fill 473 132 290 473 135 290 minecraft:deepslate_tiles
setblock 474 132 283 minecraft:cobbled_deepslate
fill 474 132 284 474 134 284 minecraft:deepslate_tiles
setblock 474 132 288 minecraft:cobbled_deepslate
fill 474 132 289 474 135 289 minecraft:deepslate_tiles
setblock 475 132 277 minecraft:cobbled_deepslate
setblock 476 132 276 minecraft:cobbled_deepslate
fill 476 132 277 476 133 277 minecraft:deepslate_tiles
fill 476 132 289 476 133 289 minecraft:black_concrete
fill 476 132 292 476 133 292 minecraft:black_concrete
setblock 476 132 316 minecraft:cobbled_deepslate
fill 477 132 276 477 135 276 minecraft:deepslate_tiles
fill 477 132 288 477 133 288 minecraft:black_concrete
fill 477 132 294 477 133 294 minecraft:black_concrete
fill 478 132 287 481 133 287 minecraft:black_concrete
fill 482 132 288 482 133 288 minecraft:black_concrete
fill 482 132 294 482 133 294 minecraft:black_concrete
fill 483 132 289 483 133 289 minecraft:black_concrete
fill 483 132 293 483 133 293 minecraft:black_concrete
fill 484 132 316 485 132 316 minecraft:deepslate_tiles
fill 485 132 275 485 202 275 minecraft:black_concrete
setblock 485 132 276 minecraft:deepslate_tiles
setblock 486 132 276 minecraft:cobbled_deepslate
setblock 486 132 316 minecraft:cobbled_deepslate
fill 487 132 276 487 135 276 minecraft:deepslate_tiles
setblock 487 132 315 minecraft:cobbled_deepslate
fill 487 132 316 487 135 316 minecraft:deepslate_tiles
setblock 488 132 314 minecraft:cobbled_deepslate
fill 488 132 315 488 135 315 minecraft:deepslate_tiles
fill 489 132 314 492 132 314 minecraft:deepslate_tiles
setblock 490 132 277 minecraft:cobbled_deepslate
setblock 491 132 276 minecraft:cobbled_deepslate
fill 491 132 277 492 132 277 minecraft:deepslate_tiles
fill 491 132 313 493 132 313 minecraft:deepslate_tiles
setblock 491 132 315 minecraft:deepslate_tiles
setblock 491 132 316 minecraft:cobbled_deepslate
fill 492 132 276 492 135 276 minecraft:deepslate_tiles
setblock 492 132 315 minecraft:cobbled_deepslate
fill 492 132 316 492 135 316 minecraft:deepslate_tiles
setblock 493 132 314 minecraft:cobbled_deepslate
fill 493 132 315 493 135 315 minecraft:deepslate_tiles
fill 494 132 314 494 135 314 minecraft:deepslate_tiles
setblock 496 132 316 minecraft:cobbled_deepslate
setblock 497 132 315 minecraft:cobbled_deepslate
fill 497 132 316 497 135 316 minecraft:deepslate_tiles
fill 509 132 284 509 132 287 minecraft:deepslate_tiles
setblock 509 132 288 minecraft:cobbled_deepslate
fill 509 132 289 509 135 289 minecraft:deepslate_tiles
fill 509 132 291 509 132 292 minecraft:deepslate_tiles
setblock 509 132 293 minecraft:cobbled_deepslate
fill 509 132 298 509 134 298 minecraft:black_concrete
setblock 509 132 302 minecraft:deepslate_tiles
setblock 509 132 303 minecraft:cobbled_deepslate
fill 509 132 304 509 135 304 minecraft:deepslate_tiles
setblock 509 132 308 minecraft:cobbled_deepslate
fill 509 132 309 509 134 310 minecraft:deepslate_tiles
setblock 510 132 281 minecraft:deepslate_tiles
setblock 510 132 282 minecraft:cobbled_deepslate
fill 510 132 283 510 132 286 minecraft:deepslate_tiles
setblock 510 132 287 minecraft:cobbled_deepslate
fill 510 132 288 510 135 288 minecraft:deepslate_tiles
setblock 510 132 291 minecraft:deepslate_tiles
setblock 510 132 292 minecraft:cobbled_deepslate
fill 510 132 293 510 132 296 minecraft:deepslate_tiles
setblock 510 132 297 minecraft:cobbled_deepslate
fill 510 132 298 510 135 298 minecraft:deepslate_tiles
setblock 510 132 302 minecraft:cobbled_deepslate
fill 510 132 303 510 135 303 minecraft:deepslate_tiles
setblock 510 132 307 minecraft:cobbled_deepslate
fill 510 132 308 510 135 308 minecraft:deepslate_tiles
setblock 510 132 311 minecraft:deepslate_tiles
setblock 510 132 312 minecraft:cobbled_deepslate
fill 510 132 313 510 135 313 minecraft:deepslate_tiles
fill 511 132 277 511 135 277 minecraft:deepslate_tiles
setblock 511 132 281 minecraft:cobbled_deepslate
fill 511 132 282 511 135 282 minecraft:deepslate_tiles
setblock 511 132 286 minecraft:cobbled_deepslate
fill 511 132 287 511 135 287 minecraft:deepslate_tiles
setblock 511 132 291 minecraft:cobbled_deepslate
fill 511 132 292 511 135 292 minecraft:deepslate_tiles
setblock 511 132 296 minecraft:cobbled_deepslate
fill 511 132 297 511 135 297 minecraft:deepslate_tiles
setblock 511 132 301 minecraft:cobbled_deepslate
fill 511 132 302 511 135 302 minecraft:deepslate_tiles
setblock 511 132 306 minecraft:cobbled_deepslate
fill 511 132 307 511 135 307 minecraft:deepslate_tiles
setblock 511 132 311 minecraft:cobbled_deepslate
fill 511 132 312 511 135 312 minecraft:deepslate_tiles
setblock 511 132 315 minecraft:deepslate_tiles
setblock 511 132 316 minecraft:cobbled_deepslate
setblock 512 132 306 minecraft:white_wool
setblock 470 133 312 minecraft:redstone_block
fill 470 133 313 470 174 313 minecraft:black_concrete
fill 471 133 276 471 136 276 minecraft:deepslate_tiles
setblock 471 133 280 minecraft:cobbled_deepslate
fill 471 133 281 471 136 281 minecraft:deepslate_tiles
setblock 471 133 285 minecraft:cobbled_deepslate
fill 471 133 286 471 136 286 minecraft:deepslate_tiles
setblock 471 133 290 minecraft:cobbled_deepslate
fill 471 133 291 471 136 291 minecraft:deepslate_tiles
setblock 471 133 294 minecraft:deepslate_tiles
setblock 471 133 295 minecraft:cobbled_deepslate
fill 471 133 296 471 136 296 minecraft:deepslate_tiles
setblock 471 133 300 minecraft:cobbled_deepslate
fill 471 133 301 471 136 301 minecraft:deepslate_tiles
setblock 471 133 305 minecraft:cobbled_deepslate
fill 471 133 306 471 136 306 minecraft:deepslate_tiles
setblock 471 133 309 minecraft:deepslate_tiles
setblock 471 133 310 minecraft:cobbled_deepslate
fill 471 133 311 471 136 311 minecraft:deepslate_tiles
setblock 471 133 315 minecraft:cobbled_deepslate
fill 471 133 316 471 136 316 minecraft:deepslate_tiles
setblock 472 133 279 minecraft:cobbled_deepslate
fill 472 133 280 472 136 280 minecraft:deepslate_tiles
setblock 472 133 284 minecraft:cobbled_deepslate
fill 472 133 285 472 136 285 minecraft:deepslate_tiles
setblock 472 133 289 minecraft:cobbled_deepslate
fill 472 133 290 472 136 290 minecraft:deepslate_tiles
setblock 472 133 294 minecraft:cobbled_deepslate
fill 472 133 295 472 136 295 minecraft:deepslate_tiles
setblock 472 133 304 minecraft:cobbled_deepslate
fill 472 133 305 472 135 305 minecraft:deepslate_tiles
setblock 472 133 309 minecraft:cobbled_deepslate
fill 472 133 310 472 136 310 minecraft:deepslate_tiles
setblock 472 133 314 minecraft:cobbled_deepslate
fill 472 133 315 473 135 315 minecraft:deepslate_tiles
setblock 473 133 278 minecraft:light[level=13]
fill 473 133 279 473 134 279 minecraft:deepslate_tiles
setblock 473 133 283 minecraft:cobbled_deepslate
fill 473 133 284 473 136 284 minecraft:deepslate_tiles
setblock 473 133 288 minecraft:cobbled_deepslate
fill 473 133 289 473 136 289 minecraft:deepslate_tiles
setblock 473 133 293 minecraft:cobbled_deepslate
setblock 473 133 294 minecraft:light[level=13]
setblock 473 133 299 minecraft:light[level=12]
setblock 473 133 302 minecraft:light[level=13]
setblock 473 133 306 minecraft:light[level=12]
setblock 473 133 310 minecraft:light[level=13]
setblock 473 133 313 minecraft:light[level=12]
fill 473 133 316 474 133 316 minecraft:deepslate_tiles
setblock 474 133 277 minecraft:cobbled_deepslate
setblock 474 133 283 minecraft:deepslate_tiles
setblock 474 133 287 minecraft:cobbled_deepslate
fill 474 133 288 474 135 288 minecraft:deepslate_tiles
fill 474 133 290 474 134 290 minecraft:deepslate_tiles
setblock 475 133 276 minecraft:cobbled_deepslate
fill 475 133 277 475 135 277 minecraft:deepslate_tiles
setblock 475 133 291 minecraft:black_concrete
setblock 475 133 316 minecraft:cobbled_deepslate
fill 476 133 276 476 136 276 minecraft:deepslate_tiles
setblock 476 133 288 minecraft:black_concrete
setblock 476 133 293 minecraft:black_concrete
fill 476 133 316 478 134 316 minecraft:deepslate_tiles
setblock 477 133 287 minecraft:black_concrete
fill 478 133 295 481 133 295 minecraft:black_concrete
setblock 480 133 276 minecraft:cobbled_deepslate
setblock 480 133 278 minecraft:light[level=12]
setblock 480 133 285 minecraft:light[level=12]
setblock 480 133 299 minecraft:light[level=12]
setblock 480 133 306 minecraft:light[level=12]
setblock 480 133 313 minecraft:light[level=12]
setblock 481 133 278 minecraft:light[level=13]
setblock 481 133 286 minecraft:light[level=13]
setblock 481 133 302 minecraft:light[level=13]
setblock 481 133 310 minecraft:light[level=13]
setblock 482 133 287 minecraft:black_concrete
fill 482 133 316 484 133 316 minecraft:deepslate_tiles
fill 483 133 276 484 133 276 minecraft:deepslate_tiles
setblock 483 133 288 minecraft:black_concrete
setblock 483 133 294 minecraft:black_concrete
fill 484 133 290 484 133 292 minecraft:black_concrete
setblock 485 133 276 minecraft:cobbled_deepslate
setblock 485 133 315 minecraft:deepslate_tiles
setblock 485 133 316 minecraft:cobbled_deepslate
fill 486 133 276 486 136 276 minecraft:deepslate_tiles
setblock 486 133 315 minecraft:cobbled_deepslate
fill 486 133 316 486 136 316 minecraft:deepslate_tiles
setblock 487 133 278 minecraft:light[level=12]
setblock 487 133 285 minecraft:light[level=12]
setblock 487 133 292 minecraft:light[level=12]
setblock 487 133 299 minecraft:light[level=12]
setblock 487 133 306 minecraft:light[level=12]
setblock 487 133 313 minecraft:light[level=12]
setblock 487 133 314 minecraft:cobbled_deepslate
fill 487 133 315 487 136 315 minecraft:deepslate_tiles
fill 488 133 314 491 133 314 minecraft:deepslate_tiles
setblock 489 133 277 minecraft:cobbled_deepslate
setblock 489 133 278 minecraft:light[level=13]
setblock 489 133 286 minecraft:light[level=13]
setblock 489 133 302 minecraft:light[level=13]
setblock 489 133 310 minecraft:light[level=13]
fill 489 133 313 492 133 313 minecraft:deepslate_tiles
setblock 490 133 276 minecraft:cobbled_deepslate
fill 490 133 277 491 135 277 minecraft:deepslate_tiles
setblock 490 133 316 minecraft:cobbled_deepslate
fill 491 133 276 491 136 276 minecraft:deepslate_tiles
setblock 491 133 315 minecraft:cobbled_deepslate
fill 491 133 316 491 136 316 minecraft:deepslate_tiles
setblock 492 133 314 minecraft:cobbled_deepslate
fill 492 133 315 492 136 315 minecraft:deepslate_tiles
setblock 493 133 313 minecraft:cobbled_deepslate
fill 493 133 314 493 136 314 minecraft:deepslate_tiles
setblock 494 133 278 minecraft:light[level=12]
setblock 494 133 285 minecraft:light[level=12]
setblock 494 133 292 minecraft:light[level=12]
setblock 494 133 299 minecraft:light[level=12]
setblock 494 133 306 minecraft:light[level=12]
fill 494 133 313 494 136 313 minecraft:deepslate_tiles
setblock 495 133 276 minecraft:cobbled_deepslate
setblock 495 133 316 minecraft:cobbled_deepslate
setblock 496 133 314 minecraft:deepslate_tiles
setblock 496 133 315 minecraft:cobbled_deepslate
fill 496 133 316 496 136 316 minecraft:deepslate_tiles
setblock 497 133 278 minecraft:light[level=13]
setblock 497 133 286 minecraft:light[level=13]
setblock 497 133 294 minecraft:light[level=13]
setblock 497 133 302 minecraft:light[level=13]
setblock 497 133 310 minecraft:light[level=13]
fill 497 133 315 497 136 315 minecraft:deepslate_tiles
setblock 501 133 278 minecraft:light[level=12]
setblock 501 133 285 minecraft:light[level=12]
setblock 501 133 292 minecraft:light[level=12]
setblock 501 133 299 minecraft:light[level=12]
setblock 501 133 306 minecraft:light[level=12]
setblock 501 133 313 minecraft:light[level=12]
setblock 505 133 278 minecraft:light[level=13]
setblock 505 133 286 minecraft:light[level=13]
setblock 505 133 294 minecraft:light[level=13]
setblock 505 133 302 minecraft:light[level=13]
setblock 505 133 310 minecraft:light[level=13]
setblock 508 133 278 minecraft:light[level=12]
setblock 508 133 285 minecraft:light[level=12]
setblock 508 133 292 minecraft:light[level=12]
setblock 508 133 299 minecraft:light[level=12]
setblock 508 133 306 minecraft:light[level=12]
setblock 508 133 313 minecraft:light[level=12]
fill 508 133 316 509 133 316 minecraft:deepslate_tiles
fill 509 133 283 509 133 286 minecraft:deepslate_tiles
setblock 509 133 287 minecraft:cobbled_deepslate
fill 509 133 288 509 136 288 minecraft:deepslate_tiles
setblock 509 133 291 minecraft:deepslate_tiles
setblock 509 133 292 minecraft:cobbled_deepslate
fill 509 133 293 510 133 295 minecraft:deepslate_tiles
setblock 509 133 302 minecraft:cobbled_deepslate
fill 509 133 303 509 135 303 minecraft:deepslate_tiles
setblock 509 133 306 minecraft:deepslate_tiles
setblock 509 133 307 minecraft:cobbled_deepslate
fill 509 133 308 509 136 308 minecraft:deepslate_tiles
setblock 509 133 311 minecraft:deepslate_tiles
setblock 510 133 276 minecraft:cobbled_deepslate
setblock 510 133 280 minecraft:deepslate_tiles
setblock 510 133 281 minecraft:cobbled_deepslate
fill 510 133 282 510 133 285 minecraft:deepslate_tiles
setblock 510 133 286 minecraft:cobbled_deepslate
fill 510 133 287 510 136 287 minecraft:deepslate_tiles
setblock 510 133 291 minecraft:cobbled_deepslate
fill 510 133 292 510 136 292 minecraft:deepslate_tiles
setblock 510 133 296 minecraft:cobbled_deepslate
fill 510 133 297 510 136 297 minecraft:deepslate_tiles
setblock 510 133 301 minecraft:cobbled_deepslate
fill 510 133 302 510 136 302 minecraft:deepslate_tiles
setblock 510 133 306 minecraft:cobbled_deepslate
fill 510 133 307 510 136 307 minecraft:deepslate_tiles
setblock 510 133 311 minecraft:cobbled_deepslate
fill 510 133 312 510 136 312 minecraft:deepslate_tiles
fill 510 133 314 510 134 314 minecraft:deepslate_tiles
setblock 510 133 316 minecraft:cobbled_deepslate
fill 511 133 276 511 136 276 minecraft:deepslate_tiles
setblock 511 133 280 minecraft:cobbled_deepslate
fill 511 133 281 511 136 281 minecraft:deepslate_tiles
setblock 511 133 285 minecraft:cobbled_deepslate
fill 511 133 286 511 136 286 minecraft:deepslate_tiles
setblock 511 133 290 minecraft:cobbled_deepslate
fill 511 133 291 511 136 291 minecraft:deepslate_tiles
setblock 511 133 295 minecraft:cobbled_deepslate
fill 511 133 296 511 136 296 minecraft:deepslate_tiles
setblock 511 133 300 minecraft:cobbled_deepslate
fill 511 133 301 511 136 301 minecraft:deepslate_tiles
setblock 511 133 305 minecraft:cobbled_deepslate
fill 511 133 306 511 136 306 minecraft:deepslate_tiles
setblock 511 133 310 minecraft:cobbled_deepslate
fill 511 133 311 511 136 311 minecraft:deepslate_tiles
setblock 511 133 315 minecraft:cobbled_deepslate
fill 511 133 316 511 136 316 minecraft:deepslate_tiles
fill 512 133 306 512 201 306 minecraft:black_concrete
fill 470 134 312 470 203 312 minecraft:black_concrete
setblock 471 134 279 minecraft:cobbled_deepslate
fill 471 134 280 471 137 280 minecraft:deepslate_tiles
setblock 471 134 284 minecraft:cobbled_deepslate
fill 471 134 285 471 137 285 minecraft:deepslate_tiles
setblock 471 134 289 minecraft:cobbled_deepslate
fill 471 134 290 471 137 290 minecraft:deepslate_tiles
setblock 471 134 294 minecraft:cobbled_deepslate
fill 471 134 295 471 137 295 minecraft:deepslate_tiles
setblock 471 134 299 minecraft:cobbled_deepslate
fill 471 134 300 471 136 300 minecraft:deepslate_tiles
setblock 471 134 304 minecraft:cobbled_deepslate
fill 471 134 305 471 137 305 minecraft:deepslate_tiles
setblock 471 134 309 minecraft:cobbled_deepslate
fill 471 134 310 471 137 310 minecraft:deepslate_tiles
setblock 471 134 313 minecraft:deepslate_tiles
setblock 471 134 314 minecraft:cobbled_deepslate
fill 471 134 315 471 137 315 minecraft:deepslate_tiles
setblock 472 134 278 minecraft:cobbled_deepslate
fill 472 134 279 472 137 279 minecraft:deepslate_tiles
setblock 472 134 283 minecraft:cobbled_deepslate
fill 472 134 284 472 137 284 minecraft:deepslate_tiles
setblock 472 134 288 minecraft:cobbled_deepslate
fill 472 134 289 472 137 289 minecraft:deepslate_tiles
setblock 472 134 292 minecraft:deepslate_tiles
setblock 472 134 293 minecraft:cobbled_deepslate
fill 472 134 294 472 137 294 minecraft:deepslate_tiles
setblock 472 134 304 minecraft:deepslate_tiles
setblock 472 134 308 minecraft:cobbled_deepslate
setblock 472 134 309 minecraft:deepslate_tiles
setblock 472 134 313 minecraft:cobbled_deepslate
fill 472 134 314 472 137 314 minecraft:deepslate_tiles
setblock 473 134 277 minecraft:cobbled_deepslate
setblock 473 134 282 minecraft:cobbled_deepslate
fill 473 134 283 473 136 283 minecraft:deepslate_tiles
setblock 473 134 287 minecraft:cobbled_deepslate
fill 473 134 288 473 137 288 minecraft:deepslate_tiles
setblock 473 134 292 minecraft:cobbled_deepslate
fill 473 134 293 473 136 293 minecraft:deepslate_tiles
setblock 473 134 310 minecraft:deepslate_tiles
setblock 473 134 316 minecraft:deepslate_tiles
setblock 474 134 276 minecraft:cobbled_deepslate
fill 474 134 277 474 137 277 minecraft:deepslate_tiles
setblock 474 134 286 minecraft:cobbled_deepslate
fill 474 134 287 474 135 287 minecraft:deepslate_tiles
setblock 474 134 315 minecraft:deepslate_tiles
setblock 474 134 316 minecraft:cobbled_deepslate
fill 475 134 276 475 137 276 minecraft:deepslate_tiles
setblock 475 134 312 minecraft:white_wool
setblock 475 134 315 minecraft:cobbled_deepslate
fill 475 134 316 475 137 316 minecraft:deepslate_tiles
setblock 476 134 313 minecraft:white_wool
setblock 477 134 314 minecraft:white_wool
setblock 478 134 315 minecraft:white_wool
setblock 479 134 276 minecraft:cobbled_deepslate
fill 479 134 290 480 135 291 minecraft:white_wool
setblock 479 134 316 minecraft:cobbled_deepslate
fill 480 134 276 483 134 276 minecraft:deepslate_tiles
setblock 480 134 292 minecraft:white_wool
fill 480 134 316 483 134 316 minecraft:deepslate_tiles
fill 483 134 315 484 134 315 minecraft:deepslate_tiles
setblock 484 134 276 minecraft:cobbled_deepslate
setblock 484 134 316 minecraft:cobbled_deepslate
fill 485 134 276 485 137 276 minecraft:deepslate_tiles
setblock 485 134 315 minecraft:cobbled_deepslate
fill 485 134 316 485 137 316 minecraft:deepslate_tiles
setblock 486 134 314 minecraft:cobbled_deepslate
fill 486 134 315 486 137 315 minecraft:deepslate_tiles
setblock 487 134 313 minecraft:cobbled_deepslate
fill 487 134 314 490 134 314 minecraft:deepslate_tiles
setblock 488 134 277 minecraft:cobbled_deepslate
fill 488 134 313 491 134 313 minecraft:deepslate_tiles
setblock 489 134 276 minecraft:cobbled_deepslate
fill 489 134 277 489 137 277 minecraft:deepslate_tiles
setblock 489 134 316 minecraft:cobbled_deepslate
fill 490 134 276 490 137 276 minecraft:deepslate_tiles
fill 490 134 312 492 134 312 minecraft:deepslate_tiles
setblock 490 134 315 minecraft:cobbled_deepslate
fill 490 134 316 490 137 316 minecraft:deepslate_tiles
setblock 491 134 314 minecraft:cobbled_deepslate
fill 491 134 315 491 137 315 minecraft:deepslate_tiles
setblock 492 134 313 minecraft:cobbled_deepslate
fill 492 134 314 492 137 314 minecraft:deepslate_tiles
fill 493 134 313 493 137 313 minecraft:deepslate_tiles
setblock 494 134 276 minecraft:cobbled_deepslate
setblock 494 134 316 minecraft:cobbled_deepslate
setblock 495 134 315 minecraft:cobbled_deepslate
fill 495 134 316 495 137 316 minecraft:deepslate_tiles
setblock 496 134 314 minecraft:cobbled_deepslate
fill 496 134 315 496 137 315 minecraft:deepslate_tiles
setblock 499 134 316 minecraft:cobbled_deepslate
fill 507 134 293 507 139 293 minecraft:white_wool
fill 507 134 316 508 134 316 minecraft:deepslate_tiles
setblock 508 134 287 minecraft:cobbled_deepslate
fill 508 134 288 508 134 291 minecraft:deepslate_tiles
setblock 508 134 292 minecraft:cobbled_deepslate
setblock 509 134 276 minecraft:cobbled_deepslate
fill 509 134 283 509 134 285 minecraft:deepslate_tiles
setblock 509 134 286 minecraft:cobbled_deepslate
fill 509 134 287 509 137 287 minecraft:deepslate_tiles
setblock 509 134 290 minecraft:deepslate_tiles
setblock 509 134 291 minecraft:cobbled_deepslate
fill 509 134 292 509 134 295 minecraft:deepslate_tiles
setblock 509 134 296 minecraft:cobbled_deepslate
fill 509 134 297 509 137 297 minecraft:deepslate_tiles
setblock 509 134 302 minecraft:deepslate_tiles
setblock 509 134 306 minecraft:cobbled_deepslate
fill 509 134 307 509 136 307 minecraft:deepslate_tiles
setblock 509 134 311 minecraft:cobbled_deepslate
fill 509 134 312 509 137 312 minecraft:deepslate_tiles
setblock 509 134 315 minecraft:deepslate_tiles
setblock 509 134 316 minecraft:cobbled_deepslate
fill 510 134 276 510 137 276 minecraft:deepslate_tiles
setblock 510 134 280 minecraft:cobbled_deepslate
fill 510 134 281 510 134 284 minecraft:deepslate_tiles
setblock 510 134 285 minecraft:cobbled_deepslate
fill 510 134 286 510 137 286 minecraft:deepslate_tiles
setblock 510 134 290 minecraft:cobbled_deepslate
fill 510 134 291 510 137 291 minecraft:deepslate_tiles
fill 510 134 293 510 134 294 minecraft:deepslate_tiles
setblock 510 134 295 minecraft:cobbled_deepslate
fill 510 134 296 510 137 296 minecraft:deepslate_tiles
setblock 510 134 300 minecraft:cobbled_deepslate
fill 510 134 301 510 137 301 minecraft:deepslate_tiles
setblock 510 134 305 minecraft:cobbled_deepslate
fill 510 134 306 510 137 306 minecraft:deepslate_tiles
setblock 510 134 310 minecraft:cobbled_deepslate
fill 510 134 311 510 137 311 minecraft:deepslate_tiles
setblock 510 134 315 minecraft:cobbled_deepslate
fill 510 134 316 510 137 316 minecraft:deepslate_tiles
setblock 511 134 279 minecraft:cobbled_deepslate
fill 511 134 280 511 137 280 minecraft:deepslate_tiles
setblock 511 134 284 minecraft:cobbled_deepslate
fill 511 134 285 511 137 285 minecraft:deepslate_tiles
setblock 511 134 289 minecraft:cobbled_deepslate
fill 511 134 290 511 137 290 minecraft:deepslate_tiles
setblock 511 134 294 minecraft:cobbled_deepslate
fill 511 134 295 511 137 295 minecraft:deepslate_tiles
setblock 511 134 299 minecraft:cobbled_deepslate
fill 511 134 300 511 137 300 minecraft:deepslate_tiles
setblock 511 134 304 minecraft:cobbled_deepslate
fill 511 134 305 511 137 305 minecraft:deepslate_tiles
setblock 511 134 309 minecraft:cobbled_deepslate
fill 511 134 310 511 137 310 minecraft:deepslate_tiles
setblock 511 134 313 minecraft:deepslate_tiles
setblock 511 134 314 minecraft:cobbled_deepslate
fill 511 134 315 511 137 315 minecraft:deepslate_tiles
setblock 471 135 278 minecraft:cobbled_deepslate
fill 471 135 279 471 138 279 minecraft:deepslate_tiles
setblock 471 135 283 minecraft:cobbled_deepslate
fill 471 135 284 471 138 284 minecraft:deepslate_tiles
setblock 471 135 288 minecraft:cobbled_deepslate
fill 471 135 289 471 138 289 minecraft:deepslate_tiles
setblock 471 135 293 minecraft:cobbled_deepslate
fill 471 135 294 471 138 294 minecraft:deepslate_tiles
setblock 471 135 298 minecraft:cobbled_deepslate
fill 471 135 299 471 137 299 minecraft:deepslate_tiles
setblock 471 135 303 minecraft:cobbled_deepslate
fill 471 135 304 471 137 304 minecraft:deepslate_tiles
setblock 471 135 308 minecraft:white_wool
fill 471 135 309 471 138 309 minecraft:deepslate_tiles
setblock 471 135 312 minecraft:deepslate_tiles
setblock 471 135 313 minecraft:cobbled_deepslate
fill 471 135 314 471 138 314 minecraft:deepslate_tiles
setblock 472 135 277 minecraft:cobbled_deepslate
fill 472 135 278 472 138 278 minecraft:deepslate_tiles
setblock 472 135 282 minecraft:cobbled_deepslate
fill 472 135 283 472 138 283 minecraft:deepslate_tiles
setblock 472 135 287 minecraft:cobbled_deepslate
fill 472 135 288 472 138 288 minecraft:deepslate_tiles
setblock 472 135 292 minecraft:cobbled_deepslate
fill 472 135 293 472 138 293 minecraft:deepslate_tiles
setblock 472 135 307 minecraft:cobbled_deepslate
fill 472 135 308 472 137 308 minecraft:deepslate_tiles
setblock 472 135 309 minecraft:white_wool
setblock 472 135 312 minecraft:cobbled_deepslate
fill 472 135 313 472 138 313 minecraft:deepslate_tiles
setblock 473 135 276 minecraft:cobbled_deepslate
fill 473 135 277 473 138 277 minecraft:deepslate_tiles
setblock 473 135 281 minecraft:cobbled_deepslate
fill 473 135 282 473 136 282 minecraft:deepslate_tiles
setblock 473 135 286 minecraft:cobbled_deepslate
fill 473 135 287 473 138 287 minecraft:deepslate_tiles
setblock 473 135 291 minecraft:cobbled_deepslate
fill 473 135 292 473 137 292 minecraft:deepslate_tiles
setblock 473 135 310 minecraft:white_wool
setblock 473 135 316 minecraft:cobbled_deepslate
fill 474 135 276 474 138 276 minecraft:deepslate_tiles
setblock 474 135 285 minecraft:cobbled_deepslate
setblock 474 135 286 minecraft:deepslate_tiles
setblock 474 135 311 minecraft:white_wool
setblock 474 135 315 minecraft:cobbled_deepslate
fill 474 135 316 474 138 316 minecraft:deepslate_tiles
fill 475 135 315 475 138 315 minecraft:deepslate_tiles
fill 476 135 316 477 135 316 minecraft:deepslate_tiles
setblock 478 135 276 minecraft:cobbled_deepslate
setblock 478 135 316 minecraft:cobbled_deepslate
fill 479 135 276 482 135 276 minecraft:deepslate_tiles
fill 479 135 316 482 135 316 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_6 1t
