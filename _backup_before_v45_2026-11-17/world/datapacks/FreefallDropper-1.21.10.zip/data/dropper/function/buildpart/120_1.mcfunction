fill 16 178 517 20 179 517 minecraft:black_concrete
setblock 16 178 529 minecraft:cyan_concrete
fill 16 178 531 19 178 531 minecraft:dark_oak_planks
fill 16 178 533 19 178 533 minecraft:dark_oak_planks
fill 16 178 547 23 179 547 minecraft:black_concrete
fill 17 178 529 19 178 529 minecraft:black_concrete
fill 17 178 530 20 178 530 minecraft:dark_oak_planks
fill 17 178 534 20 178 534 minecraft:dark_oak_planks
fill 17 178 535 18 178 540 minecraft:cyan_concrete
fill 17 178 541 17 179 543 minecraft:black_concrete
fill 18 178 525 21 179 525 minecraft:cyan_concrete
fill 18 178 541 20 179 542 minecraft:cyan_concrete
fill 18 178 543 18 179 543 minecraft:black_concrete
fill 19 178 522 25 179 522 minecraft:black_concrete
fill 19 178 523 19 179 524 minecraft:cyan_concrete
fill 19 178 535 19 178 537 minecraft:black_concrete
fill 19 178 538 19 179 540 minecraft:cyan_concrete
fill 19 178 543 23 179 543 minecraft:cyan_concrete
fill 20 178 523 26 179 523 minecraft:black_concrete
fill 20 178 524 20 179 524 minecraft:cyan_concrete
fill 20 178 526 22 179 526 minecraft:cyan_concrete
fill 20 178 529 22 179 529 minecraft:dark_oak_planks
fill 20 178 535 22 179 535 minecraft:dark_oak_planks
fill 20 178 536 21 178 540 minecraft:black_concrete
fill 20 178 544 26 179 544 minecraft:cyan_concrete
fill 20 178 545 20 179 545 minecraft:black_concrete
fill 21 178 516 21 179 517 minecraft:cyan_concrete
fill 21 178 524 26 179 524 minecraft:black_concrete
fill 21 178 527 22 178 528 minecraft:cyan_concrete
fill 21 178 541 34 179 541 minecraft:black_concrete
fill 21 178 542 21 179 542 minecraft:cyan_concrete
fill 21 178 545 30 179 545 minecraft:cyan_concrete
fill 21 178 548 21 179 548 minecraft:black_concrete
fill 22 178 517 26 179 517 minecraft:cyan_concrete
fill 22 178 525 26 179 525 minecraft:black_concrete
fill 22 178 530 25 178 530 minecraft:dark_oak_planks
fill 22 178 534 25 178 534 minecraft:dark_oak_planks
fill 22 178 536 34 178 536 minecraft:cyan_concrete
fill 22 178 537 22 179 540 minecraft:black_concrete
fill 22 178 542 33 179 542 minecraft:black_concrete
fill 22 178 546 28 179 546 minecraft:cyan_concrete
fill 23 178 518 27 179 518 minecraft:cyan_concrete
fill 23 178 526 25 178 529 minecraft:black_concrete
fill 23 178 531 26 178 531 minecraft:dark_oak_planks
fill 23 178 533 26 178 533 minecraft:dark_oak_planks
setblock 23 178 535 minecraft:cyan_concrete
fill 23 178 537 32 179 537 minecraft:cyan_concrete
fill 23 178 538 24 179 540 minecraft:black_concrete
fill 24 178 519 28 179 519 minecraft:cyan_concrete
fill 24 178 532 27 179 532 minecraft:dark_oak_planks
fill 24 178 535 29 178 535 minecraft:black_concrete
fill 24 178 543 32 179 543 minecraft:black_concrete
fill 24 178 547 26 179 547 minecraft:cyan_concrete
fill 25 178 520 28 179 520 minecraft:cyan_concrete
fill 25 178 538 30 179 538 minecraft:cyan_concrete
fill 25 178 539 34 179 540 minecraft:black_concrete
fill 26 178 521 29 179 522 minecraft:cyan_concrete
fill 26 178 526 26 178 528 minecraft:black_concrete
fill 26 178 529 28 178 530 minecraft:cyan_concrete
fill 26 178 534 31 178 534 minecraft:black_concrete
setblock 27 178 510 minecraft:light_blue_stained_glass
fill 27 178 523 29 179 528 minecraft:cyan_concrete
setblock 27 178 531 minecraft:cyan_concrete
fill 27 178 533 32 178 533 minecraft:black_concrete
fill 27 178 544 30 179 544 minecraft:black_concrete
fill 28 178 518 28 179 518 minecraft:black_concrete
fill 28 178 531 33 178 532 minecraft:black_concrete
fill 29 178 519 30 179 520 minecraft:black_concrete
fill 29 178 529 34 178 530 minecraft:black_concrete
fill 30 178 521 32 179 528 minecraft:black_concrete
fill 30 178 535 35 179 535 minecraft:cyan_concrete
fill 31 178 520 31 179 520 minecraft:black_concrete
fill 31 178 538 35 179 538 minecraft:black_concrete
fill 31 178 544 31 179 544 minecraft:cyan_concrete
fill 32 178 534 36 179 534 minecraft:cyan_concrete
fill 33 178 522 33 179 528 minecraft:black_concrete
fill 33 178 533 36 179 533 minecraft:cyan_concrete
fill 33 178 537 36 179 537 minecraft:black_concrete
fill 34 178 523 34 179 528 minecraft:black_concrete
fill 34 178 531 36 179 532 minecraft:cyan_concrete
fill 35 178 525 35 179 528 minecraft:black_concrete
fill 35 178 529 36 179 530 minecraft:cyan_concrete
fill 35 178 536 36 179 536 minecraft:black_concrete
fill 35 178 539 35 179 539 minecraft:black_concrete
fill 36 178 527 36 179 528 minecraft:cyan_concrete
fill 36 178 535 36 179 535 minecraft:black_concrete
fill 37 178 532 37 179 532 minecraft:cyan_concrete
fill 40 178 510 40 216 510 minecraft:gray_concrete
fill 42 178 551 42 198 551 minecraft:gray_concrete
fill 1 179 511 4 179 551 minecraft:black_concrete
fill 5 179 511 5 179 531 minecraft:black_concrete
fill 5 179 533 5 179 551 minecraft:black_concrete
fill 6 179 511 6 179 526 minecraft:black_concrete
fill 6 179 538 6 179 551 minecraft:black_concrete
fill 7 179 511 7 179 524 minecraft:black_concrete
fill 7 179 528 15 179 528 minecraft:black_concrete
fill 7 179 540 7 179 551 minecraft:black_concrete
fill 8 179 511 8 179 522 minecraft:black_concrete
fill 8 179 542 8 179 551 minecraft:black_concrete
fill 9 179 511 9 179 521 minecraft:black_concrete
fill 9 179 543 9 179 551 minecraft:black_concrete
fill 10 179 511 10 179 520 minecraft:black_concrete
fill 10 179 533 11 179 533 minecraft:cyan_concrete
fill 10 179 544 10 179 551 minecraft:black_concrete
fill 11 179 511 11 179 519 minecraft:black_concrete
setblock 11 179 532 minecraft:cyan_concrete
fill 11 179 545 11 179 551 minecraft:black_concrete
fill 12 179 511 13 179 518 minecraft:black_concrete
fill 12 179 529 13 179 529 minecraft:black_concrete
fill 12 179 530 14 179 534 minecraft:dark_oak_planks
setblock 12 179 535 minecraft:cyan_concrete
fill 12 179 536 15 179 543 minecraft:black_concrete
fill 12 179 546 13 179 551 minecraft:black_concrete
setblock 13 179 535 minecraft:black_concrete
fill 14 179 511 15 179 517 minecraft:black_concrete
fill 14 179 529 19 179 529 minecraft:dark_oak_planks
fill 14 179 535 19 179 535 minecraft:dark_oak_planks
fill 14 179 547 15 179 551 minecraft:black_concrete
fill 15 179 530 18 179 531 minecraft:dark_oak_planks
fill 15 179 533 18 179 534 minecraft:dark_oak_planks
fill 16 179 511 20 179 516 minecraft:black_concrete
fill 16 179 528 26 179 528 minecraft:dark_oak_planks
fill 16 179 536 26 179 536 minecraft:dark_oak_planks
fill 16 179 537 16 179 543 minecraft:black_concrete
fill 16 179 548 20 179 551 minecraft:black_concrete
fill 17 179 537 18 179 540 minecraft:cyan_concrete
fill 19 179 530 19 179 531 minecraft:sea_lantern
fill 19 179 533 19 179 534 minecraft:sea_lantern
fill 19 179 537 21 179 537 minecraft:black_concrete
setblock 19 179 552 minecraft:white_concrete
setblock 20 179 530 minecraft:sea_lantern
setblock 20 179 534 minecraft:sea_lantern
fill 20 179 538 21 179 540 minecraft:black_concrete
fill 21 179 511 41 179 515 minecraft:black_concrete
fill 21 179 527 22 179 527 minecraft:cyan_concrete
fill 21 179 549 41 179 551 minecraft:black_concrete
fill 22 179 516 41 179 516 minecraft:black_concrete
fill 22 179 530 23 179 530 minecraft:sea_lantern
fill 22 179 534 23 179 534 minecraft:sea_lantern
fill 22 179 548 41 179 548 minecraft:black_concrete
fill 23 179 526 26 179 527 minecraft:black_concrete
fill 23 179 529 28 179 529 minecraft:dark_oak_planks
setblock 23 179 531 minecraft:sea_lantern
setblock 23 179 533 minecraft:sea_lantern
fill 23 179 535 28 179 535 minecraft:dark_oak_planks
fill 24 179 530 30 179 531 minecraft:dark_oak_planks
fill 24 179 533 30 179 534 minecraft:dark_oak_planks
fill 27 179 510 27 194 510 minecraft:gray_concrete
fill 27 179 517 41 179 517 minecraft:black_concrete
fill 27 179 536 34 179 536 minecraft:cyan_concrete
fill 27 179 547 41 179 547 minecraft:black_concrete
fill 28 179 532 30 179 532 minecraft:dark_oak_planks
fill 29 179 518 41 179 518 minecraft:black_concrete
fill 29 179 529 34 179 529 minecraft:black_concrete
setblock 29 179 535 minecraft:black_concrete
fill 29 179 546 41 179 546 minecraft:black_concrete
fill 31 179 510 31 218 510 minecraft:gray_concrete
fill 31 179 519 41 179 519 minecraft:black_concrete
fill 31 179 530 31 179 534 minecraft:black_concrete
fill 31 179 545 41 179 545 minecraft:black_concrete
setblock 32 179 510 minecraft:light_blue_stained_glass
fill 32 179 520 41 179 520 minecraft:black_concrete
fill 32 179 530 32 179 533 minecraft:black_concrete
fill 32 179 544 41 179 544 minecraft:black_concrete
fill 32 179 552 32 196 552 minecraft:gray_concrete
fill 33 179 521 41 179 521 minecraft:black_concrete
fill 33 179 530 33 179 532 minecraft:black_concrete
fill 33 179 543 41 179 543 minecraft:black_concrete
setblock 33 179 552 minecraft:light_blue_stained_glass
fill 34 179 522 41 179 522 minecraft:black_concrete
setblock 34 179 530 minecraft:black_concrete
fill 34 179 542 41 179 542 minecraft:black_concrete
fill 35 179 523 41 179 524 minecraft:black_concrete
fill 35 179 540 41 179 541 minecraft:black_concrete
fill 36 179 525 41 179 526 minecraft:black_concrete
fill 36 179 538 41 179 539 minecraft:black_concrete
fill 37 179 527 41 179 531 minecraft:black_concrete
fill 37 179 533 41 179 537 minecraft:black_concrete
fill 38 179 532 41 179 532 minecraft:black_concrete
setblock 42 179 511 minecraft:sea_lantern
fill 42 179 548 42 214 548 minecraft:gray_concrete
setblock 42 179 549 minecraft:sea_lantern
setblock 8 180 510 minecraft:white_concrete
fill 9 180 532 11 180 532 minecraft:dark_oak_planks
fill 10 180 530 11 180 531 minecraft:dark_oak_planks
fill 10 180 533 11 180 534 minecraft:dark_oak_planks
fill 11 180 529 13 180 529 minecraft:dark_oak_planks
fill 11 180 535 13 180 535 minecraft:dark_oak_planks
fill 12 180 528 15 180 528 minecraft:dark_oak_planks
fill 12 180 536 15 180 536 minecraft:dark_oak_planks
fill 15 180 527 27 180 527 minecraft:dark_oak_planks
fill 15 180 537 27 180 537 minecraft:dark_oak_planks
fill 19 180 552 19 201 552 minecraft:gray_concrete
fill 20 180 526 22 182 526 minecraft:dark_oak_planks
fill 20 180 538 22 182 538 minecraft:dark_oak_planks
fill 27 180 528 30 180 528 minecraft:dark_oak_planks
fill 27 180 536 30 180 536 minecraft:dark_oak_planks
fill 29 180 529 31 180 529 minecraft:dark_oak_planks
fill 29 180 535 31 180 535 minecraft:dark_oak_planks
fill 31 180 530 32 180 534 minecraft:dark_oak_planks
fill 32 180 510 32 216 510 minecraft:gray_concrete
setblock 33 180 532 minecraft:dark_oak_planks
fill 33 180 552 33 216 552 minecraft:gray_concrete
setblock 34 180 510 minecraft:white_concrete
fill 42 180 511 42 184 511 minecraft:gray_concrete
fill 42 180 549 42 216 549 minecraft:gray_concrete
setblock 0 181 547 minecraft:sea_lantern
fill 8 181 510 8 200 510 minecraft:gray_concrete
fill 8 181 531 8 182 533 minecraft:dark_oak_planks
fill 9 181 530 9 181 531 minecraft:dark_oak_planks
fill 9 181 533 9 181 534 minecraft:dark_oak_planks
setblock 10 181 529 minecraft:dark_oak_planks
setblock 10 181 535 minecraft:dark_oak_planks
fill 11 181 528 12 181 528 minecraft:dark_oak_planks
fill 11 181 536 12 181 536 minecraft:dark_oak_planks
fill 13 181 527 15 181 527 minecraft:dark_oak_planks
fill 13 181 537 15 181 537 minecraft:dark_oak_planks
fill 16 181 526 19 182 526 minecraft:dark_oak_planks
fill 16 181 538 19 182 538 minecraft:dark_oak_planks
fill 23 181 526 26 182 526 minecraft:dark_oak_planks
fill 23 181 538 26 182 538 minecraft:dark_oak_planks
setblock 25 181 510 minecraft:light_blue_stained_glass
fill 27 181 527 29 181 527 minecraft:dark_oak_planks
fill 27 181 537 29 181 537 minecraft:dark_oak_planks
fill 30 181 528 31 181 528 minecraft:dark_oak_planks
fill 30 181 536 31 181 536 minecraft:dark_oak_planks
setblock 32 181 529 minecraft:dark_oak_planks
setblock 32 181 535 minecraft:dark_oak_planks
fill 33 181 530 33 181 531 minecraft:dark_oak_planks
fill 33 181 533 33 181 534 minecraft:dark_oak_planks
fill 34 181 510 34 185 510 minecraft:gray_concrete
fill 34 181 531 34 182 533 minecraft:dark_oak_planks
setblock 0 182 547 minecraft:light_blue_stained_glass
setblock 0 182 551 minecraft:white_concrete
setblock 8 182 530 minecraft:dark_oak_planks
setblock 8 182 534 minecraft:dark_oak_planks
setblock 9 182 529 minecraft:dark_oak_planks
setblock 9 182 535 minecraft:dark_oak_planks
fill 10 182 528 11 182 528 minecraft:dark_oak_planks
fill 10 182 536 11 182 536 minecraft:dark_oak_planks
fill 12 182 527 13 182 527 minecraft:dark_oak_planks
fill 12 182 537 13 182 537 minecraft:dark_oak_planks
fill 14 182 526 15 182 526 minecraft:dark_oak_planks
fill 14 182 538 15 182 538 minecraft:dark_oak_planks
fill 25 182 510 25 188 510 minecraft:gray_concrete
fill 27 182 526 28 182 526 minecraft:dark_oak_planks
fill 27 182 538 28 182 538 minecraft:dark_oak_planks
fill 29 182 527 30 182 527 minecraft:dark_oak_planks
fill 29 182 537 30 182 537 minecraft:dark_oak_planks
fill 31 182 528 32 182 528 minecraft:dark_oak_planks
fill 31 182 536 32 182 536 minecraft:dark_oak_planks
setblock 33 182 529 minecraft:dark_oak_planks
setblock 33 182 535 minecraft:dark_oak_planks
setblock 34 182 530 minecraft:dark_oak_planks
setblock 34 182 534 minecraft:dark_oak_planks
setblock 0 183 516 minecraft:light_blue_stained_glass
fill 0 183 547 0 199 547 minecraft:gray_concrete
setblock 0 183 551 minecraft:gray_concrete
fill 4 183 527 4 187 527 minecraft:iron_block
fill 8 183 530 17 183 534 minecraft:spruce_planks
fill 9 183 529 18 183 529 minecraft:spruce_planks
fill 9 183 535 18 183 535 minecraft:spruce_planks
fill 10 183 528 32 183 528 minecraft:spruce_planks
fill 10 183 536 32 183 536 minecraft:spruce_planks
fill 12 183 527 30 183 527 minecraft:spruce_planks
fill 12 183 537 30 183 537 minecraft:spruce_planks
fill 14 183 526 28 183 526 minecraft:spruce_planks
fill 14 183 538 28 183 538 minecraft:spruce_planks
fill 17 183 515 17 190 515 minecraft:iron_block
fill 24 183 529 33 183 529 minecraft:spruce_planks
fill 24 183 535 33 183 535 minecraft:spruce_planks
fill 25 183 530 34 183 534 minecraft:spruce_planks
fill 0 184 516 0 214 516 minecraft:gray_concrete
setblock 0 184 551 minecraft:light_blue_stained_glass
fill 28 184 532 28 187 532 minecraft:stripped_dark_oak_log
fill 0 185 551 0 192 551 minecraft:gray_concrete
setblock 42 185 511 minecraft:sea_lantern
setblock 17 186 552 minecraft:light_blue_stained_glass
fill 29 186 526 30 187 526 minecraft:light_blue_stained_glass
setblock 34 186 510 minecraft:light_blue_stained_glass
fill 42 186 511 42 202 511 minecraft:gray_concrete
setblock 42 186 545 minecraft:sea_lantern
setblock 0 187 514 minecraft:sea_lantern
setblock 0 187 515 minecraft:light_blue_stained_glass
setblock 0 187 523 minecraft:light_blue_stained_glass
setblock 0 187 542 minecraft:white_concrete
setblock 3 187 513 minecraft:light[level=11]
setblock 3 187 521 minecraft:light[level=11]
setblock 3 187 529 minecraft:light[level=11]
setblock 3 187 537 minecraft:light[level=11]
setblock 3 187 545 minecraft:light[level=11]
setblock 11 187 513 minecraft:light[level=11]
setblock 11 187 521 minecraft:light[level=11]
setblock 11 187 529 minecraft:light[level=11]
setblock 11 187 537 minecraft:light[level=11]
setblock 11 187 545 minecraft:light[level=11]
setblock 12 187 552 minecraft:light_blue_stained_glass
fill 13 187 552 13 216 552 minecraft:gray_concrete
fill 17 187 552 17 216 552 minecraft:gray_concrete
setblock 19 187 513 minecraft:light[level=11]
setblock 19 187 521 minecraft:light[level=11]
setblock 19 187 529 minecraft:light[level=11]
setblock 19 187 537 minecraft:light[level=11]
setblock 19 187 545 minecraft:light[level=11]
fill 21 187 545 23 188 546 minecraft:cyan_stained_glass
fill 22 187 513 24 190 515 minecraft:light_blue_stained_glass
setblock 27 187 513 minecraft:light[level=11]
setblock 27 187 521 minecraft:light[level=11]
setblock 27 187 529 minecraft:light[level=11]
setblock 27 187 537 minecraft:light[level=11]
setblock 27 187 545 minecraft:light[level=11]
fill 34 187 510 34 216 510 minecraft:gray_concrete
setblock 35 187 513 minecraft:light[level=11]
fill 35 187 514 35 195 514 minecraft:iron_block
setblock 35 187 521 minecraft:light[level=11]
setblock 35 187 529 minecraft:light[level=11]
setblock 35 187 537 minecraft:light[level=11]
setblock 35 187 545 minecraft:light[level=11]
setblock 40 187 552 minecraft:light_blue_stained_glass
setblock 42 187 513 minecraft:light_blue_stained_glass
setblock 42 187 528 minecraft:light_blue_stained_glass
setblock 42 187 535 minecraft:light_blue_stained_glass
setblock 42 187 542 minecraft:white_concrete
fill 42 187 545 42 194 545 minecraft:gray_concrete
fill 0 188 514 0 197 515 minecraft:gray_concrete
fill 0 188 523 0 213 523 minecraft:gray_concrete
fill 0 188 542 0 214 542 minecraft:gray_concrete
setblock 1 188 552 minecraft:sea_lantern
fill 12 188 552 12 189 552 minecraft:gray_concrete
fill 28 188 528 28 197 536 minecraft:white_wool
fill 40 188 552 40 211 552 minecraft:gray_concrete
fill 42 188 513 42 214 513 minecraft:gray_concrete
fill 42 188 528 42 216 528 minecraft:gray_concrete
fill 42 188 535 42 200 535 minecraft:gray_concrete
fill 42 188 542 42 216 542 minecraft:gray_concrete
setblock 42 188 547 minecraft:light_blue_stained_glass
fill 0 189 518 0 191 518 minecraft:cyan_concrete
fill 0 189 534 0 191 534 minecraft:cyan_concrete
setblock 0 189 548 minecraft:sea_lantern
fill 0 189 550 0 191 550 minecraft:cyan_concrete
fill 1 189 552 1 216 552 minecraft:gray_concrete
fill 4 189 510 4 191 510 minecraft:cyan_concrete
fill 14 189 552 14 191 552 minecraft:cyan_concrete
fill 20 189 510 20 191 510 minecraft:cyan_concrete
setblock 25 189 510 minecraft:white_concrete
fill 30 189 552 30 191 552 minecraft:cyan_concrete
fill 36 189 510 36 191 510 minecraft:cyan_concrete
fill 42 189 520 42 191 520 minecraft:cyan_concrete
fill 42 189 536 42 191 536 minecraft:cyan_concrete
setblock 42 189 541 minecraft:sea_lantern
fill 42 189 547 42 216 547 minecraft:gray_concrete
fill 0 190 548 0 213 548 minecraft:gray_concrete
setblock 10 190 510 minecraft:sea_lantern
fill 11 190 510 11 214 510 minecraft:gray_concrete
setblock 12 190 552 minecraft:sea_lantern
fill 25 190 510 25 216 510 minecraft:gray_concrete
fill 42 190 541 42 216 541 minecraft:gray_concrete
setblock 7 191 552 minecraft:white_concrete
fill 10 191 510 10 213 510 minecraft:gray_concrete
setblock 12 191 510 minecraft:sea_lantern
fill 12 191 552 12 193 552 minecraft:gray_concrete
setblock 0 192 518 minecraft:sea_lantern
setblock 0 192 521 minecraft:white_concrete
fill 0 192 534 0 197 534 minecraft:gray_concrete
fill 0 192 550 0 197 550 minecraft:gray_concrete
fill 4 192 510 4 197 510 minecraft:gray_concrete
fill 7 192 552 7 209 552 minecraft:gray_concrete
fill 12 192 510 12 198 510 minecraft:gray_concrete
setblock 13 192 510 minecraft:sea_lantern
fill 14 192 552 14 197 552 minecraft:gray_concrete
fill 20 192 510 20 197 510 minecraft:gray_concrete
fill 30 192 552 30 197 552 minecraft:gray_concrete
fill 36 192 510 36 197 510 minecraft:gray_concrete
fill 42 192 520 42 197 520 minecraft:gray_concrete
fill 42 192 536 42 197 536 minecraft:gray_concrete
fill 0 193 518 0 197 518 minecraft:gray_concrete
fill 0 193 521 0 216 521 minecraft:gray_concrete
setblock 0 193 551 minecraft:white_concrete
fill 13 193 510 13 207 510 minecraft:gray_concrete
setblock 42 193 521 minecraft:sea_lantern
fill 0 194 551 0 212 551 minecraft:gray_concrete
setblock 12 194 552 minecraft:white_concrete
fill 42 194 521 42 216 521 minecraft:gray_concrete
setblock 42 194 532 minecraft:white_concrete
setblock 0 195 545 minecraft:light_blue_stained_glass
setblock 3 195 513 minecraft:light[level=11]
setblock 3 195 521 minecraft:light[level=11]
setblock 3 195 529 minecraft:light[level=11]
setblock 3 195 537 minecraft:light[level=11]
setblock 3 195 545 minecraft:light[level=11]
setblock 11 195 513 minecraft:light[level=11]
setblock 11 195 521 minecraft:light[level=11]
setblock 11 195 529 minecraft:light[level=11]
setblock 11 195 537 minecraft:light[level=11]
setblock 11 195 545 minecraft:light[level=11]
fill 12 195 552 12 207 552 minecraft:gray_concrete
setblock 19 195 513 minecraft:light[level=11]
setblock 19 195 521 minecraft:light[level=11]
setblock 19 195 529 minecraft:light[level=11]
setblock 19 195 537 minecraft:light[level=11]
setblock 19 195 545 minecraft:light[level=11]
setblock 27 195 510 minecraft:sea_lantern
setblock 27 195 513 minecraft:light[level=11]
setblock 27 195 521 minecraft:light[level=11]
setblock 27 195 529 minecraft:light[level=11]
setblock 27 195 537 minecraft:light[level=11]
setblock 27 195 545 minecraft:light[level=11]
setblock 35 195 513 minecraft:light[level=11]
setblock 35 195 521 minecraft:light[level=11]
setblock 35 195 529 minecraft:light[level=11]
setblock 35 195 537 minecraft:light[level=11]
setblock 35 195 545 minecraft:light[level=11]
setblock 41 195 552 minecraft:light_blue_stained_glass
setblock 42 195 517 minecraft:light_blue_stained_glass
fill 42 195 518 42 216 518 minecraft:gray_concrete
fill 42 195 532 42 213 532 minecraft:gray_concrete
setblock 42 195 545 minecraft:sea_lantern
setblock 0 196 519 minecraft:light_blue_stained_glass
fill 0 196 545 0 213 545 minecraft:gray_concrete
fill 27 196 510 27 216 510 minecraft:gray_concrete
fill 41 196 552 41 212 552 minecraft:gray_concrete
fill 42 196 517 42 216 517 minecraft:gray_concrete
fill 42 196 545 42 200 545 minecraft:gray_concrete
fill 0 197 519 0 216 519 minecraft:gray_concrete
fill 27 197 520 27 198 520 minecraft:light_blue_stained_glass
setblock 32 197 552 minecraft:light_blue_stained_glass
fill 36 197 552 38 216 552 minecraft:gray_concrete
setblock 39 197 552 minecraft:light_blue_stained_glass
setblock 0 198 514 minecraft:light_blue_stained_glass
fill 0 198 515 0 212 515 minecraft:gray_concrete
fill 0 198 518 0 200 518 minecraft:cyan_concrete
fill 0 198 534 0 200 534 minecraft:cyan_concrete
fill 0 198 550 0 200 550 minecraft:cyan_concrete
fill 4 198 510 4 200 510 minecraft:cyan_concrete
fill 14 198 552 14 200 552 minecraft:cyan_concrete
fill 20 198 510 20 200 510 minecraft:cyan_concrete
fill 28 198 532 28 199 532 minecraft:stripped_dark_oak_log
fill 30 198 552 30 200 552 minecraft:cyan_concrete
fill 32 198 552 32 208 552 minecraft:gray_concrete
fill 34 198 522 38 199 526 minecraft:black_concrete
fill 36 198 510 36 200 510 minecraft:cyan_concrete
fill 39 198 524 40 198 524 minecraft:black_concrete
fill 39 198 552 39 200 552 minecraft:gray_concrete
setblock 41 198 510 minecraft:light_blue_stained_glass
fill 42 198 520 42 200 520 minecraft:cyan_concrete
fill 42 198 536 42 200 536 minecraft:cyan_concrete
setblock 42 198 543 minecraft:sea_lantern
fill 0 199 514 0 203 514 minecraft:gray_concrete
setblock 0 199 524 minecraft:sea_lantern
setblock 12 199 510 minecraft:white_concrete
setblock 17 199 510 minecraft:light_blue_stained_glass
fill 30 199 538 30 200 539 minecraft:cyan_stained_glass
fill 41 199 510 41 200 510 minecraft:gray_concrete
fill 42 199 543 42 216 543 minecraft:gray_concrete
setblock 42 199 551 minecraft:light_blue_stained_glass
setblock 0 200 520 minecraft:sea_lantern
fill 0 200 524 0 210 524 minecraft:gray_concrete
setblock 0 200 525 minecraft:light_blue_stained_glass
setblock 0 200 531 minecraft:sea_lantern
setblock 0 200 547 minecraft:light_blue_stained_glass
fill 12 200 510 12 216 510 minecraft:gray_concrete
fill 17 200 510 17 217 510 minecraft:gray_concrete
fill 35 200 524 37 204 524 minecraft:black_wool
setblock 42 200 522 minecraft:white_concrete
setblock 42 200 534 minecraft:light_blue_stained_glass
fill 42 200 551 42 205 551 minecraft:gray_concrete
setblock 0 201 511 minecraft:light_blue_stained_glass
fill 0 201 518 0 206 518 minecraft:gray_concrete
fill 0 201 520 0 216 520 minecraft:gray_concrete
fill 0 201 525 0 216 525 minecraft:gray_concrete
fill 0 201 531 0 212 531 minecraft:gray_concrete
fill 0 201 534 0 206 534 minecraft:gray_concrete
fill 0 201 547 0 216 547 minecraft:gray_concrete
fill 0 201 550 0 206 550 minecraft:gray_concrete
setblock 4 201 510 minecraft:white_concrete
setblock 8 201 510 minecraft:sea_lantern
fill 14 201 552 14 206 552 minecraft:gray_concrete
fill 17 201 514 17 202 514 minecraft:cyan_stained_glass
fill 18 201 519 18 202 519 minecraft:cyan_stained_glass
fill 20 201 510 20 206 510 minecraft:gray_concrete
fill 30 201 552 30 203 552 minecraft:gray_concrete
fill 36 201 510 36 206 510 minecraft:gray_concrete
setblock 39 201 552 minecraft:sea_lantern
setblock 41 201 510 minecraft:white_concrete
fill 42 201 520 42 206 520 minecraft:gray_concrete
fill 42 201 522 42 216 522 minecraft:gray_concrete
fill 42 201 534 42 216 534 minecraft:gray_concrete
setblock 42 201 535 minecraft:white_concrete
fill 42 201 536 42 206 536 minecraft:gray_concrete
setblock 42 201 544 minecraft:white_concrete
setblock 42 201 545 minecraft:light_blue_stained_glass
fill 0 202 511 0 209 511 minecraft:gray_concrete
setblock 0 202 537 minecraft:sea_lantern
fill 0 202 538 0 210 538 minecraft:gray_concrete
setblock 0 202 541 minecraft:light_blue_stained_glass
setblock 0 202 543 minecraft:light_blue_stained_glass
fill 4 202 510 4 206 510 minecraft:gray_concrete
fill 8 202 510 8 216 510 minecraft:gray_concrete
setblock 19 202 552 minecraft:sea_lantern
fill 39 202 552 39 216 552 minecraft:gray_concrete
fill 41 202 510 41 214 510 minecraft:gray_concrete
fill 42 202 535 42 207 535 minecraft:gray_concrete
fill 42 202 544 42 216 545 minecraft:gray_concrete
fill 0 203 537 0 216 537 minecraft:gray_concrete
fill 0 203 541 0 216 541 minecraft:gray_concrete
fill 0 203 543 0 213 543 minecraft:gray_concrete
setblock 3 203 513 minecraft:light[level=11]
setblock 3 203 521 minecraft:light[level=11]
setblock 3 203 529 minecraft:light[level=11]
setblock 3 203 537 minecraft:light[level=11]
setblock 3 203 545 minecraft:light[level=11]
setblock 11 203 513 minecraft:light[level=11]
setblock 11 203 521 minecraft:light[level=11]
setblock 11 203 529 minecraft:light[level=11]
setblock 11 203 537 minecraft:light[level=11]
setblock 11 203 545 minecraft:light[level=11]
setblock 19 203 513 minecraft:light[level=11]
setblock 19 203 521 minecraft:light[level=11]
setblock 19 203 529 minecraft:light[level=11]
setblock 19 203 537 minecraft:light[level=11]
setblock 19 203 545 minecraft:light[level=11]
fill 19 203 552 19 216 552 minecraft:gray_concrete
setblock 27 203 513 minecraft:light[level=11]
setblock 27 203 521 minecraft:light[level=11]
setblock 27 203 529 minecraft:light[level=11]
setblock 27 203 537 minecraft:light[level=11]
setblock 27 203 545 minecraft:light[level=11]
setblock 34 203 552 minecraft:white_concrete
setblock 35 203 513 minecraft:light[level=11]
setblock 35 203 521 minecraft:light[level=11]
setblock 35 203 529 minecraft:light[level=11]
setblock 35 203 537 minecraft:light[level=11]
setblock 35 203 545 minecraft:light[level=11]
fill 36 203 523 36 204 523 minecraft:black_wool
fill 36 203 525 36 204 525 minecraft:black_wool
setblock 39 203 510 minecraft:sea_lantern
fill 42 203 511 42 204 511 minecraft:light_blue_stained_glass
setblock 42 203 539 minecraft:white_concrete
fill 42 203 540 42 216 540 minecraft:gray_concrete
setblock 0 204 514 minecraft:white_concrete
setblock 26 204 510 minecraft:white_concrete
setblock 28 204 510 minecraft:light_blue_stained_glass
setblock 30 204 552 minecraft:sea_lantern
fill 34 204 552 34 212 552 minecraft:gray_concrete
fill 39 204 510 39 214 510 minecraft:gray_concrete
fill 42 204 539 42 216 539 minecraft:gray_concrete
fill 0 205 514 0 216 514 minecraft:gray_concrete
fill 26 205 510 26 214 510 minecraft:gray_concrete
fill 28 205 510 28 216 510 minecraft:gray_concrete
fill 30 205 552 30 206 552 minecraft:gray_concrete
fill 42 205 511 42 216 511 minecraft:gray_concrete
setblock 0 206 540 minecraft:light_blue_stained_glass
fill 3 206 525 5 209 527 minecraft:light_blue_stained_glass
setblock 16 206 510 minecraft:white_concrete
fill 27 206 552 28 214 552 minecraft:gray_concrete
setblock 29 206 552 minecraft:white_concrete
fill 36 206 546 38 209 548 minecraft:light_blue_stained_glass
fill 39 206 521 39 217 521 minecraft:iron_block
setblock 42 206 551 minecraft:white_concrete
fill 0 207 518 0 209 518 minecraft:cyan_concrete
fill 0 207 534 0 209 534 minecraft:cyan_concrete
fill 0 207 540 0 216 540 minecraft:gray_concrete
fill 0 207 550 0 209 550 minecraft:cyan_concrete
fill 4 207 510 4 209 510 minecraft:cyan_concrete
setblock 9 207 552 minecraft:light_blue_stained_glass
fill 14 207 552 14 209 552 minecraft:cyan_concrete
fill 16 207 510 16 216 510 minecraft:gray_concrete
fill 20 207 510 20 209 510 minecraft:cyan_concrete
fill 23 207 518 23 208 518 minecraft:cyan_stained_glass
fill 28 207 540 30 208 540 minecraft:cyan_stained_glass
fill 29 207 539 30 208 539 minecraft:cyan_stained_glass
fill 29 207 541 29 208 541 minecraft:cyan_stained_glass
fill 29 207 552 29 216 552 minecraft:gray_concrete
fill 30 207 552 30 209 552 minecraft:cyan_concrete
fill 36 207 510 36 209 510 minecraft:cyan_concrete
fill 42 207 520 42 209 520 minecraft:cyan_concrete
fill 42 207 536 42 209 536 minecraft:cyan_concrete
fill 42 207 551 42 216 551 minecraft:gray_concrete
setblock 0 208 544 minecraft:sea_lantern
fill 9 208 552 9 216 552 minecraft:gray_concrete
setblock 12 208 552 minecraft:sea_lantern
setblock 13 208 510 minecraft:sea_lantern
fill 15 208 552 15 214 552 minecraft:gray_concrete
setblock 16 208 552 minecraft:sea_lantern
setblock 42 208 535 minecraft:light_blue_stained_glass
fill 0 209 544 0 216 544 minecraft:gray_concrete
setblock 5 209 510 minecraft:light_blue_stained_glass
fill 8 209 527 8 210 527 minecraft:light_blue_stained_glass
fill 12 209 552 12 216 552 minecraft:gray_concrete
fill 13 209 510 13 216 510 minecraft:gray_concrete
fill 16 209 552 16 216 552 minecraft:gray_concrete
setblock 32 209 552 minecraft:light_blue_stained_glass
fill 42 209 535 42 213 535 minecraft:gray_concrete
setblock 0 210 511 minecraft:white_concrete
fill 0 210 518 0 212 518 minecraft:gray_concrete
fill 0 210 534 0 215 534 minecraft:gray_concrete
setblock 0 210 546 minecraft:white_concrete
fill 0 210 550 0 215 550 minecraft:gray_concrete
setblock 4 210 510 minecraft:sea_lantern
fill 5 210 510 5 217 510 minecraft:gray_concrete
setblock 7 210 552 minecraft:white_concrete
fill 14 210 552 14 215 552 minecraft:gray_concrete
fill 20 210 510 20 213 510 minecraft:gray_concrete
fill 30 210 552 30 215 552 minecraft:gray_concrete
fill 32 210 552 32 216 552 minecraft:gray_concrete
fill 36 210 510 36 214 510 minecraft:gray_concrete
fill 42 210 520 42 215 520 minecraft:gray_concrete
fill 42 210 523 42 216 524 minecraft:gray_concrete
setblock 42 210 525 minecraft:light_blue_stained_glass
fill 42 210 536 42 212 536 minecraft:gray_concrete
fill 0 211 511 0 217 511 minecraft:gray_concrete
setblock 0 211 524 minecraft:white_concrete
setblock 0 211 538 minecraft:white_concrete
fill 0 211 546 0 216 546 minecraft:gray_concrete
setblock 3 211 513 minecraft:light[level=11]
setblock 3 211 521 minecraft:light[level=11]
setblock 3 211 529 minecraft:light[level=11]
setblock 3 211 537 minecraft:light[level=11]
setblock 3 211 545 minecraft:light[level=11]
fill 4 211 510 4 214 510 minecraft:gray_concrete
setblock 5 211 552 minecraft:white_concrete
fill 7 211 552 7 214 552 minecraft:gray_concrete
setblock 11 211 513 minecraft:light[level=11]
setblock 11 211 521 minecraft:light[level=11]
setblock 11 211 529 minecraft:light[level=11]
setblock 11 211 537 minecraft:light[level=11]
setblock 11 211 545 minecraft:light[level=11]
setblock 19 211 513 minecraft:light[level=11]
setblock 19 211 521 minecraft:light[level=11]
setblock 19 211 529 minecraft:light[level=11]
setblock 19 211 537 minecraft:light[level=11]
setblock 19 211 545 minecraft:light[level=11]
setblock 27 211 513 minecraft:light[level=11]
setblock 27 211 521 minecraft:light[level=11]
setblock 27 211 529 minecraft:light[level=11]
setblock 27 211 537 minecraft:light[level=11]
setblock 27 211 545 minecraft:light[level=11]
setblock 35 211 513 minecraft:light[level=11]
setblock 35 211 521 minecraft:light[level=11]
setblock 35 211 529 minecraft:light[level=11]
setblock 35 211 537 minecraft:light[level=11]
setblock 35 211 545 minecraft:light[level=11]
fill 42 211 525 42 213 525 minecraft:gray_concrete
fill 0 212 524 0 216 524 minecraft:gray_concrete
setblock 0 212 528 minecraft:light_blue_stained_glass
fill 0 212 538 0 213 538 minecraft:gray_concrete
setblock 5 212 552 minecraft:gray_concrete
fill 36 212 523 37 213 524 minecraft:cyan_stained_glass
setblock 40 212 552 minecraft:white_concrete
fill 42 212 515 42 216 515 minecraft:gray_concrete
setblock 42 212 516 minecraft:sea_lantern
setblock 42 212 530 minecraft:sea_lantern
setblock 0 213 510 minecraft:black_concrete
setblock 0 213 515 minecraft:black_concrete
setblock 0 213 518 minecraft:white_concrete
fill 0 213 528 0 216 528 minecraft:gray_concrete
setblock 0 213 531 minecraft:black_concrete
fill 0 213 551 0 213 552 minecraft:black_concrete
setblock 2 213 510 minecraft:black_concrete
setblock 5 213 552 minecraft:black_concrete
fill 18 213 510 19 213 510 minecraft:black_concrete
setblock 23 213 510 minecraft:black_concrete
setblock 34 213 552 minecraft:sea_lantern
setblock 40 213 552 minecraft:gray_concrete
fill 41 213 552 42 214 552 minecraft:black_concrete
fill 42 213 516 42 216 516 minecraft:gray_concrete
setblock 42 213 529 minecraft:black_concrete
fill 42 213 530 42 216 530 minecraft:gray_concrete
setblock 42 213 536 minecraft:black_concrete
setblock 0 214 510 minecraft:gray_concrete
fill 0 214 515 0 216 515 minecraft:gray_concrete
fill 0 214 518 0 215 518 minecraft:gray_concrete
fill 0 214 523 0 215 523 minecraft:black_concrete
setblock 0 214 529 minecraft:black_concrete
fill 0 214 531 0 216 531 minecraft:gray_concrete
fill 0 214 532 0 214 533 minecraft:black_concrete
fill 0 214 538 0 215 538 minecraft:black_concrete
setblock 0 214 543 minecraft:light_blue_stained_glass
setblock 0 214 545 minecraft:black_concrete
setblock 0 214 548 minecraft:black_concrete
fill 0 214 551 0 214 552 minecraft:gray_concrete
setblock 2 214 510 minecraft:gray_concrete
setblock 3 214 552 minecraft:black_concrete
fill 5 214 552 5 216 552 minecraft:gray_concrete
setblock 6 214 552 minecraft:light_blue_stained_glass
setblock 8 214 552 minecraft:black_concrete
setblock 10 214 510 minecraft:black_concrete
fill 18 214 510 19 216 510 minecraft:gray_concrete
setblock 20 214 510 minecraft:black_concrete
fill 23 214 510 23 216 510 minecraft:gray_concrete
fill 25 214 552 26 214 552 minecraft:black_concrete
setblock 34 214 552 minecraft:black_concrete
fill 36 214 537 38 217 539 minecraft:light_blue_stained_glass
setblock 40 214 552 minecraft:white_concrete
setblock 42 214 512 minecraft:white_concrete
setblock 42 214 525 minecraft:black_concrete
fill 42 214 529 42 216 529 minecraft:gray_concrete
setblock 42 214 532 minecraft:black_concrete
setblock 42 214 535 minecraft:black_concrete
fill 42 214 536 42 215 536 minecraft:gray_concrete
setblock 42 214 537 minecraft:sea_lantern
setblock 0 215 510 minecraft:black_concrete
setblock 0 215 516 minecraft:sea_lantern
fill 0 215 529 0 216 529 minecraft:gray_concrete
fill 0 215 532 0 216 532 minecraft:gray_concrete
setblock 0 215 533 minecraft:black_concrete
setblock 0 215 542 minecraft:black_concrete
fill 0 215 543 0 217 543 minecraft:gray_concrete
fill 0 215 545 0 216 545 minecraft:gray_concrete
fill 0 215 548 0 216 548 minecraft:gray_concrete
fill 0 215 551 0 217 551 minecraft:gray_concrete
setblock 0 215 552 minecraft:black_concrete
setblock 2 215 510 minecraft:black_concrete
fill 3 215 552 3 217 552 minecraft:gray_concrete
setblock 4 215 510 minecraft:black_concrete
fill 6 215 552 7 215 552 minecraft:black_concrete
fill 8 215 552 8 216 552 minecraft:gray_concrete
setblock 10 215 510 minecraft:gray_concrete
setblock 11 215 510 minecraft:black_concrete
setblock 15 215 552 minecraft:black_concrete
setblock 18 215 552 minecraft:black_concrete
setblock 20 215 510 minecraft:gray_concrete
setblock 25 215 552 minecraft:sea_lantern
setblock 26 215 510 minecraft:black_concrete
fill 26 215 552 27 216 552 minecraft:gray_concrete
setblock 28 215 552 minecraft:black_concrete
setblock 34 215 552 minecraft:white_concrete
setblock 35 215 552 minecraft:black_concrete
setblock 36 215 510 minecraft:black_concrete
setblock 39 215 510 minecraft:black_concrete
fill 40 215 552 41 216 552 minecraft:gray_concrete
setblock 41 215 510 minecraft:black_concrete
fill 42 215 512 42 216 512 minecraft:gray_concrete
setblock 42 215 513 minecraft:black_concrete
fill 42 215 525 42 216 525 minecraft:gray_concrete
setblock 42 215 531 minecraft:black_concrete
fill 42 215 532 42 216 532 minecraft:gray_concrete
setblock 42 215 533 minecraft:white_concrete
fill 42 215 535 42 216 535 minecraft:gray_concrete
fill 42 215 537 42 216 537 minecraft:gray_concrete
setblock 42 215 548 minecraft:black_concrete
setblock 42 215 552 minecraft:black_concrete
setblock 0 216 510 minecraft:gray_concrete
setblock 0 216 516 minecraft:gray_concrete
fill 0 216 518 0 218 518 minecraft:cyan_concrete
setblock 0 216 523 minecraft:gray_concrete
setblock 0 216 533 minecraft:gray_concrete
fill 0 216 534 0 218 534 minecraft:cyan_concrete
setblock 0 216 538 minecraft:gray_concrete
setblock 0 216 542 minecraft:gray_concrete
fill 0 216 550 0 218 550 minecraft:cyan_concrete
setblock 0 216 552 minecraft:gray_concrete
setblock 2 216 510 minecraft:gray_concrete
fill 4 216 510 4 218 510 minecraft:cyan_concrete
fill 6 216 552 7 217 552 minecraft:gray_concrete
setblock 10 216 510 minecraft:sea_lantern
setblock 11 216 510 minecraft:gray_concrete
fill 14 216 552 14 218 552 minecraft:cyan_concrete
setblock 15 216 552 minecraft:gray_concrete
setblock 18 216 552 minecraft:gray_concrete
fill 20 216 510 20 218 510 minecraft:cyan_concrete
setblock 25 216 552 minecraft:gray_concrete
setblock 26 216 510 minecraft:gray_concrete
setblock 28 216 552 minecraft:gray_concrete
fill 30 216 552 30 218 552 minecraft:cyan_concrete
fill 34 216 552 35 216 552 minecraft:gray_concrete
fill 36 216 510 36 218 510 minecraft:cyan_concrete
setblock 39 216 510 minecraft:gray_concrete
setblock 41 216 510 minecraft:gray_concrete
setblock 42 216 513 minecraft:gray_concrete
fill 42 216 520 42 218 520 minecraft:cyan_concrete
setblock 42 216 531 minecraft:gray_concrete
fill 42 216 533 42 217 533 minecraft:gray_concrete
fill 42 216 536 42 218 536 minecraft:cyan_concrete
setblock 42 216 548 minecraft:gray_concrete
setblock 42 216 552 minecraft:gray_concrete
fill 0 217 510 2 217 510 minecraft:black_concrete
fill 0 217 512 0 218 517 minecraft:black_concrete
fill 0 217 519 0 219 533 minecraft:black_concrete
fill 0 217 535 0 217 542 minecraft:black_concrete
fill 0 217 544 0 217 546 minecraft:black_concrete
setblock 0 217 547 minecraft:light_blue_stained_glass
fill 0 217 548 0 255 549 minecraft:black_concrete
fill 0 217 552 2 218 552 minecraft:black_concrete
fill 5 217 552 5 307 552 minecraft:black_concrete
fill 6 217 510 13 217 510 minecraft:black_concrete
fill 8 217 552 13 225 552 minecraft:black_concrete
fill 15 217 510 16 223 510 minecraft:black_concrete
fill 15 217 552 19 234 552 minecraft:black_concrete
fill 18 217 510 19 263 510 minecraft:black_concrete
fill 21 217 510 28 218 510 minecraft:black_concrete
fill 21 217 552 28 233 552 minecraft:black_concrete
setblock 29 217 552 minecraft:light_blue_stained_glass
fill 30 217 510 30 218 510 minecraft:black_concrete
fill 31 217 552 33 218 552 minecraft:black_concrete
fill 32 217 510 35 232 510 minecraft:black_concrete
setblock 34 217 552 minecraft:gray_concrete
fill 35 217 552 42 217 552 minecraft:black_concrete
fill 37 217 510 41 218 510 minecraft:black_concrete
fill 42 217 511 42 217 519 minecraft:black_concrete
fill 42 217 521 42 217 532 minecraft:black_concrete
fill 42 217 534 42 217 535 minecraft:black_concrete
fill 42 217 537 42 217 551 minecraft:black_concrete
fill 0 218 510 0 259 511 minecraft:black_concrete
fill 0 218 535 0 227 539 minecraft:black_concrete
fill 0 218 540 0 219 540 minecraft:gray_concrete
fill 0 218 541 0 220 541 minecraft:black_concrete
setblock 0 218 542 minecraft:gray_concrete
fill 0 218 543 0 232 545 minecraft:black_concrete
setblock 0 218 546 minecraft:gray_concrete
fill 0 218 547 0 228 547 minecraft:black_concrete
fill 0 218 551 0 297 551 minecraft:black_concrete
fill 1 218 510 1 260 510 minecraft:black_concrete
setblock 2 218 510 minecraft:gray_concrete
fill 3 218 510 3 222 510 minecraft:black_concrete
fill 3 218 552 4 269 552 minecraft:black_concrete
fill 5 218 510 5 264 510 minecraft:black_concrete
fill 6 218 510 7 219 510 minecraft:gray_concrete
setblock 6 218 552 minecraft:gray_concrete
fill 7 218 552 7 307 552 minecraft:black_concrete
fill 8 218 510 12 218 510 minecraft:black_concrete
setblock 13 218 510 minecraft:light_blue_stained_glass
fill 14 218 510 14 221 510 minecraft:black_concrete
setblock 17 218 510 minecraft:black_concrete
fill 20 218 552 20 240 552 minecraft:black_concrete
fill 29 218 510 29 222 510 minecraft:black_concrete
fill 29 218 552 29 222 552 minecraft:black_concrete
setblock 34 218 552 minecraft:light_blue_stained_glass
fill 35 218 552 37 219 552 minecraft:black_concrete
setblock 38 218 552 minecraft:gray_concrete
fill 39 218 552 40 242 552 minecraft:black_concrete
setblock 41 218 552 minecraft:sea_lantern
fill 42 218 510 42 218 515 minecraft:black_concrete
setblock 42 218 516 minecraft:gray_concrete
fill 42 218 517 42 229 519 minecraft:black_concrete
fill 42 218 521 42 222 524 minecraft:black_concrete
setblock 42 218 525 minecraft:gray_concrete
fill 42 218 526 42 219 533 minecraft:black_concrete
setblock 42 218 534 minecraft:gray_concrete
setblock 42 218 535 minecraft:black_concrete
fill 42 218 537 42 218 542 minecraft:black_concrete
fill 42 218 543 42 218 544 minecraft:gray_concrete
fill 42 218 545 42 225 551 minecraft:black_concrete
fill 42 218 552 42 219 552 minecraft:gray_concrete
fill 0 219 512 0 246 512 minecraft:black_concrete
setblock 0 219 513 minecraft:gray_concrete
fill 0 219 514 0 219 518 minecraft:black_concrete
fill 0 219 534 0 224 534 minecraft:black_concrete
fill 0 219 542 0 224 542 minecraft:black_concrete
fill 0 219 546 0 272 546 minecraft:black_concrete
fill 0 219 550 0 224 550 minecraft:black_concrete
fill 0 219 552 0 307 552 minecraft:black_concrete
setblock 1 219 552 minecraft:gray_concrete
fill 2 219 510 2 228 510 minecraft:black_concrete
fill 2 219 552 2 295 552 minecraft:black_concrete
setblock 3 219 513 minecraft:light[level=11]
setblock 3 219 521 minecraft:light[level=11]
setblock 3 219 529 minecraft:light[level=11]
setblock 3 219 537 minecraft:light[level=11]
setblock 3 219 545 minecraft:light[level=11]
setblock 4 219 510 minecraft:gray_concrete
fill 6 219 552 6 271 552 minecraft:black_concrete
setblock 8 219 510 minecraft:gray_concrete
fill 9 219 510 13 226 510 minecraft:black_concrete
setblock 11 219 513 minecraft:light[level=11]
setblock 11 219 521 minecraft:light[level=11]
setblock 11 219 529 minecraft:light[level=11]
setblock 11 219 537 minecraft:light[level=11]
setblock 11 219 545 minecraft:light[level=11]
fill 14 219 552 14 224 552 minecraft:black_concrete
setblock 17 219 510 minecraft:gray_concrete
setblock 19 219 513 minecraft:light[level=11]
setblock 19 219 521 minecraft:light[level=11]
setblock 19 219 529 minecraft:light[level=11]
setblock 19 219 537 minecraft:light[level=11]
setblock 19 219 545 minecraft:light[level=11]
fill 20 219 510 21 224 510 minecraft:black_concrete
setblock 22 219 510 minecraft:gray_concrete
fill 23 219 510 27 235 510 minecraft:black_concrete
setblock 27 219 513 minecraft:light[level=11]
setblock 27 219 521 minecraft:light[level=11]
setblock 27 219 529 minecraft:light[level=11]
setblock 27 219 537 minecraft:light[level=11]
setblock 27 219 545 minecraft:light[level=11]
setblock 28 219 510 minecraft:gray_concrete
setblock 30 219 510 minecraft:gray_concrete
fill 30 219 552 32 219 552 minecraft:black_concrete
fill 31 219 510 31 242 510 minecraft:black_concrete
setblock 33 219 552 minecraft:gray_concrete
fill 34 219 552 34 232 552 minecraft:black_concrete
setblock 35 219 513 minecraft:light[level=11]
setblock 35 219 521 minecraft:light[level=11]
setblock 35 219 529 minecraft:light[level=11]
setblock 35 219 537 minecraft:light[level=11]
setblock 35 219 545 minecraft:light[level=11]
fill 36 219 510 36 224 510 minecraft:black_concrete
setblock 37 219 510 minecraft:gray_concrete
fill 38 219 510 39 307 510 minecraft:black_concrete
fill 38 219 552 38 273 552 minecraft:black_concrete
setblock 40 219 510 minecraft:gray_concrete
fill 41 219 510 42 256 510 minecraft:black_concrete
setblock 41 219 552 minecraft:light_blue_stained_glass
fill 42 219 511 42 234 513 minecraft:black_concrete
setblock 42 219 514 minecraft:gray_concrete
fill 42 219 515 42 274 515 minecraft:black_concrete
setblock 42 219 516 minecraft:white_concrete
fill 42 219 520 42 224 520 minecraft:black_concrete
fill 42 219 525 42 307 525 minecraft:black_concrete
fill 42 219 534 42 241 534 minecraft:black_concrete
setblock 42 219 535 minecraft:gray_concrete
setblock 42 219 536 minecraft:light_blue_stained_glass
setblock 42 219 537 minecraft:gray_concrete
fill 42 219 538 42 260 539 minecraft:black_concrete
setblock 42 219 540 minecraft:gray_concrete
fill 42 219 541 42 222 544 minecraft:black_concrete
fill 0 220 513 0 220 517 minecraft:black_concrete
setblock 0 220 518 minecraft:sea_lantern
fill 0 220 519 0 226 524 minecraft:black_concrete
setblock 0 220 525 minecraft:white_concrete
fill 0 220 526 0 224 533 minecraft:black_concrete
fill 0 220 540 0 251 540 minecraft:black_concrete
fill 1 220 552 1 227 552 minecraft:black_concrete
fill 4 220 510 4 224 510 minecraft:black_concrete
fill 6 220 510 8 230 510 minecraft:black_concrete
fill 17 220 510 17 252 510 minecraft:black_concrete
fill 22 220 510 22 222 510 minecraft:black_concrete
fill 28 220 510 28 276 510 minecraft:black_concrete
fill 30 220 510 30 287 510 minecraft:black_concrete
fill 30 220 552 30 224 552 minecraft:black_concrete
setblock 31 220 552 minecraft:white_concrete
fill 32 220 552 33 237 552 minecraft:black_concrete
fill 35 220 552 36 253 552 minecraft:black_concrete
fill 37 220 510 37 225 510 minecraft:black_concrete
setblock 37 220 552 minecraft:white_concrete
fill 40 220 510 40 236 510 minecraft:black_concrete
fill 41 220 552 42 236 552 minecraft:black_concrete
fill 42 220 514 42 304 514 minecraft:black_concrete
fill 42 220 516 42 243 516 minecraft:black_concrete
fill 42 220 526 42 271 526 minecraft:black_concrete
setblock 42 220 527 minecraft:white_concrete
fill 42 220 528 42 225 529 minecraft:black_concrete
setblock 42 220 530 minecraft:white_concrete
fill 42 220 531 42 239 533 minecraft:black_concrete
fill 42 220 535 42 224 537 minecraft:black_concrete
fill 42 220 540 42 266 540 minecraft:black_concrete
fill 0 221 513 0 228 516 minecraft:black_concrete
setblock 0 221 517 minecraft:light_blue_stained_glass
fill 0 221 518 0 223 518 minecraft:black_concrete
fill 0 221 525 0 244 525 minecraft:black_concrete
setblock 0 221 541 minecraft:sea_lantern
fill 31 221 552 31 235 552 minecraft:black_concrete
fill 37 221 552 37 275 552 minecraft:black_concrete
fill 42 221 527 42 228 527 minecraft:black_concrete
fill 42 221 530 42 307 530 minecraft:black_concrete
fill 0 222 517 0 307 517 minecraft:black_concrete
fill 0 222 541 0 287 541 minecraft:black_concrete
setblock 14 222 510 minecraft:light_blue_stained_glass
setblock 3 223 510 minecraft:light_blue_stained_glass
fill 14 223 510 14 275 510 minecraft:black_concrete
fill 18 223 518 18 224 518 minecraft:light_blue_stained_glass
setblock 22 223 510 minecraft:white_concrete
setblock 29 223 510 minecraft:sea_lantern
setblock 29 223 552 minecraft:light_blue_stained_glass
fill 42 223 521 42 246 521 minecraft:black_concrete
setblock 42 223 522 minecraft:light_blue_stained_glass
fill 42 223 523 42 240 524 minecraft:black_concrete
fill 42 223 541 42 244 542 minecraft:black_concrete
setblock 42 223 543 minecraft:sea_lantern
fill 42 223 544 42 305 544 minecraft:black_concrete
setblock 0 224 518 minecraft:sea_lantern
fill 3 224 510 3 279 510 minecraft:black_concrete
fill 15 224 510 15 283 510 minecraft:black_concrete
setblock 16 224 510 minecraft:sea_lantern
fill 22 224 510 22 240 510 minecraft:black_concrete
fill 29 224 510 29 289 510 minecraft:black_concrete
fill 29 224 552 29 307 552 minecraft:black_concrete
fill 42 224 522 42 241 522 minecraft:black_concrete
fill 42 224 543 42 273 543 minecraft:black_concrete
fill 0 225 518 0 227 518 minecraft:cyan_concrete
fill 0 225 526 0 262 529 minecraft:black_concrete
setblock 0 225 530 minecraft:light_blue_stained_glass
fill 0 225 531 0 274 533 minecraft:black_concrete
fill 0 225 534 0 227 534 minecraft:cyan_concrete
setblock 0 225 542 minecraft:sea_lantern
fill 0 225 550 0 227 550 minecraft:cyan_concrete
fill 4 225 510 4 227 510 minecraft:cyan_concrete
fill 14 225 552 14 227 552 minecraft:cyan_concrete
fill 16 225 510 16 282 510 minecraft:black_concrete
fill 20 225 510 20 227 510 minecraft:cyan_concrete
fill 21 225 510 21 245 510 minecraft:black_concrete
fill 30 225 552 30 227 552 minecraft:cyan_concrete
fill 36 225 510 36 227 510 minecraft:cyan_concrete
fill 42 225 520 42 227 520 minecraft:cyan_concrete
fill 42 225 535 42 307 535 minecraft:black_concrete
fill 42 225 536 42 227 536 minecraft:cyan_concrete
fill 42 225 537 42 245 537 minecraft:black_concrete
fill 0 226 530 0 265 530 minecraft:black_concrete
fill 0 226 542 0 230 542 minecraft:black_concrete
fill 8 226 552 9 294 552 minecraft:black_concrete
setblock 10 226 552 minecraft:light_blue_stained_glass
fill 11 226 552 13 231 552 minecraft:black_concrete
setblock 37 226 510 minecraft:sea_lantern
setblock 42 226 528 minecraft:sea_lantern
fill 42 226 529 42 234 529 minecraft:black_concrete
fill 42 226 545 42 229 546 minecraft:black_concrete
setblock 42 226 547 minecraft:white_concrete
fill 42 226 548 42 227 551 minecraft:black_concrete
fill 0 227 519 0 233 521 minecraft:black_concrete
setblock 0 227 522 minecraft:white_concrete
fill 0 227 523 0 307 524 minecraft:black_concrete
setblock 3 227 513 minecraft:light[level=11]
setblock 3 227 521 minecraft:light[level=11]
setblock 3 227 529 minecraft:light[level=11]
setblock 3 227 537 minecraft:light[level=11]
setblock 3 227 545 minecraft:light[level=11]
fill 9 227 510 9 232 510 minecraft:black_concrete
setblock 10 227 510 minecraft:white_concrete
fill 10 227 552 10 266 552 minecraft:black_concrete
fill 11 227 510 13 241 510 minecraft:black_concrete
setblock 11 227 513 minecraft:light[level=11]
setblock 11 227 521 minecraft:light[level=11]
setblock 11 227 529 minecraft:light[level=11]
setblock 11 227 537 minecraft:light[level=11]
setblock 11 227 545 minecraft:light[level=11]
setblock 19 227 513 minecraft:light[level=11]
setblock 19 227 521 minecraft:light[level=11]
setblock 19 227 529 minecraft:light[level=11]
setblock 19 227 537 minecraft:light[level=11]
setblock 19 227 545 minecraft:light[level=11]
setblock 27 227 513 minecraft:light[level=11]
setblock 27 227 521 minecraft:light[level=11]
setblock 27 227 529 minecraft:light[level=11]
setblock 27 227 537 minecraft:light[level=11]
setblock 27 227 545 minecraft:light[level=11]
setblock 35 227 513 minecraft:light[level=11]
setblock 35 227 521 minecraft:light[level=11]
setblock 35 227 529 minecraft:light[level=11]
setblock 35 227 537 minecraft:light[level=11]
setblock 35 227 545 minecraft:light[level=11]
fill 37 227 510 37 272 510 minecraft:black_concrete
fill 42 227 528 42 271 528 minecraft:black_concrete
fill 42 227 547 42 243 547 minecraft:black_concrete
fill 0 228 518 0 242 518 minecraft:black_concrete
fill 0 228 522 0 307 522 minecraft:black_concrete
fill 0 228 534 0 233 537 minecraft:black_concrete
setblock 0 228 538 minecraft:white_concrete
fill 0 228 539 0 232 539 minecraft:black_concrete
fill 0 228 550 0 242 550 minecraft:black_concrete
setblock 1 228 552 minecraft:white_concrete
fill 4 228 510 4 242 510 minecraft:black_concrete
fill 10 228 510 10 279 510 minecraft:black_concrete
fill 14 228 552 14 242 552 minecraft:black_concrete
fill 20 228 510 20 242 510 minecraft:black_concrete
fill 30 228 552 30 242 552 minecraft:black_concrete
fill 36 228 510 36 242 510 minecraft:black_concrete
fill 42 228 520 42 234 520 minecraft:black_concrete
fill 42 228 536 42 236 536 minecraft:black_concrete
fill 42 228 548 42 307 548 minecraft:black_concrete
setblock 42 228 549 minecraft:white_concrete
fill 42 228 550 42 237 551 minecraft:black_concrete
setblock 0 229 513 minecraft:white_concrete
fill 0 229 514 0 280 516 minecraft:black_concrete
fill 0 229 538 0 233 538 minecraft:black_concrete
setblock 0 229 547 minecraft:sea_lantern
fill 1 229 552 1 307 552 minecraft:black_concrete
setblock 2 229 510 minecraft:sea_lantern
setblock 42 229 527 minecraft:sea_lantern
fill 42 229 549 42 232 549 minecraft:black_concrete
fill 0 230 513 0 260 513 minecraft:black_concrete
fill 0 230 547 0 250 547 minecraft:black_concrete
fill 2 230 510 2 271 510 minecraft:black_concrete
fill 42 230 517 42 237 518 minecraft:black_concrete
setblock 42 230 519 minecraft:light_blue_stained_glass
fill 42 230 527 42 304 527 minecraft:black_concrete
setblock 42 230 545 minecraft:sea_lantern
fill 42 230 546 42 256 546 minecraft:black_concrete
setblock 0 231 542 minecraft:sea_lantern
setblock 6 231 510 minecraft:sea_lantern
fill 7 231 510 8 307 510 minecraft:black_concrete
fill 42 231 519 42 255 519 minecraft:black_concrete
setblock 42 231 545 minecraft:black_concrete
fill 0 232 542 0 289 542 minecraft:black_concrete
fill 6 232 510 6 255 510 minecraft:black_concrete
fill 11 232 552 12 307 552 minecraft:black_concrete
setblock 13 232 552 minecraft:white_concrete
setblock 42 232 545 minecraft:white_concrete
setblock 0 233 539 minecraft:light_blue_stained_glass
setblock 0 233 543 minecraft:light_blue_stained_glass
fill 0 233 544 0 257 545 minecraft:black_concrete
setblock 9 233 510 minecraft:sea_lantern
fill 13 233 552 13 307 552 minecraft:black_concrete
fill 32 233 510 34 253 510 minecraft:black_concrete
setblock 34 233 552 minecraft:sea_lantern
setblock 35 233 510 minecraft:white_concrete
fill 42 233 545 42 244 545 minecraft:black_concrete
setblock 42 233 549 minecraft:sea_lantern
fill 0 234 519 0 307 519 minecraft:black_concrete
setblock 0 234 520 minecraft:light_blue_stained_glass
fill 0 234 521 0 264 521 minecraft:black_concrete
setblock 0 234 534 minecraft:light_blue_stained_glass
fill 0 234 535 0 247 537 minecraft:black_concrete
setblock 0 234 538 minecraft:white_concrete
fill 0 234 539 0 235 539 minecraft:black_concrete
fill 0 234 543 0 284 543 minecraft:black_concrete
fill 9 234 510 9 307 510 minecraft:black_concrete
fill 21 234 552 27 235 552 minecraft:black_concrete
setblock 28 234 552 minecraft:white_concrete
fill 34 234 552 34 257 552 minecraft:black_concrete
fill 35 234 510 35 278 510 minecraft:black_concrete
fill 42 234 549 42 241 549 minecraft:black_concrete
fill 0 235 520 0 261 520 minecraft:black_concrete
fill 0 235 534 0 242 534 minecraft:black_concrete
fill 0 235 538 0 268 538 minecraft:black_concrete
setblock 3 235 513 minecraft:light[level=11]
setblock 3 235 521 minecraft:light[level=11]
setblock 3 235 529 minecraft:light[level=11]
setblock 3 235 537 minecraft:light[level=11]
setblock 3 235 545 minecraft:light[level=11]
fill 7 235 527 7 235 530 minecraft:iron_block
fill 7 235 531 8 235 531 minecraft:black_concrete
fill 7 235 532 7 235 535 minecraft:iron_block
fill 8 235 525 8 235 526 minecraft:iron_block
fill 8 235 527 8 235 528 minecraft:black_concrete
setblock 8 235 529 minecraft:gray_concrete
fill 8 235 530 9 235 530 minecraft:black_concrete
setblock 8 235 532 minecraft:gray_concrete
fill 8 235 533 8 235 534 minecraft:black_concrete
setblock 8 235 535 minecraft:gray_concrete
fill 8 235 536 8 235 537 minecraft:iron_block
fill 9 235 523 9 235 524 minecraft:iron_block
setblock 9 235 525 minecraft:gray_concrete
fill 9 235 526 9 235 527 minecraft:black_concrete
setblock 9 235 528 minecraft:gray_concrete
fill 9 235 529 10 235 529 minecraft:black_concrete
setblock 9 235 531 minecraft:gray_concrete
fill 9 235 532 9 235 533 minecraft:black_concrete
setblock 9 235 534 minecraft:gray_concrete
fill 9 235 535 9 235 536 minecraft:black_concrete
setblock 9 235 537 minecraft:gray_concrete
fill 9 235 538 9 235 539 minecraft:iron_block
fill 10 235 522 10 235 523 minecraft:iron_block
setblock 10 235 524 minecraft:gray_concrete
fill 10 235 525 10 235 526 minecraft:black_concrete
setblock 10 235 527 minecraft:gray_concrete
fill 10 235 528 11 235 528 minecraft:black_concrete
setblock 10 235 530 minecraft:gray_concrete
fill 10 235 531 10 235 532 minecraft:black_concrete
setblock 10 235 533 minecraft:gray_concrete
fill 10 235 534 10 235 535 minecraft:black_concrete
setblock 10 235 536 minecraft:gray_concrete
fill 10 235 537 10 235 538 minecraft:black_concrete
fill 10 235 539 10 235 540 minecraft:iron_block
setblock 11 235 513 minecraft:light[level=11]
fill 11 235 521 11 235 522 minecraft:iron_block
setblock 11 235 523 minecraft:gray_concrete
fill 11 235 524 11 235 525 minecraft:black_concrete
setblock 11 235 526 minecraft:gray_concrete
fill 11 235 527 12 235 527 minecraft:black_concrete
setblock 11 235 529 minecraft:gray_concrete
fill 11 235 530 11 235 531 minecraft:black_concrete
setblock 11 235 532 minecraft:gray_concrete
fill 11 235 533 11 235 534 minecraft:black_concrete
setblock 11 235 535 minecraft:gray_concrete
fill 11 235 536 11 235 537 minecraft:black_concrete
setblock 11 235 538 minecraft:gray_concrete
fill 11 235 539 12 235 539 minecraft:black_concrete
fill 11 235 540 11 235 541 minecraft:iron_block
setblock 11 235 545 minecraft:light[level=11]
setblock 12 235 521 minecraft:iron_block
setblock 12 235 522 minecraft:gray_concrete
fill 12 235 523 12 235 524 minecraft:black_concrete
setblock 12 235 525 minecraft:gray_concrete
fill 12 235 526 13 235 526 minecraft:black_concrete
setblock 12 235 528 minecraft:gray_concrete
fill 12 235 529 12 235 530 minecraft:black_concrete
setblock 12 235 531 minecraft:gray_concrete
fill 12 235 532 12 235 533 minecraft:black_concrete
setblock 12 235 534 minecraft:gray_concrete
fill 12 235 535 12 235 536 minecraft:black_concrete
setblock 12 235 537 minecraft:gray_concrete
fill 12 235 538 13 235 538 minecraft:black_concrete
setblock 12 235 540 minecraft:gray_concrete
setblock 12 235 541 minecraft:iron_block
fill 13 235 520 14 235 520 minecraft:iron_block
setblock 13 235 521 minecraft:gray_concrete
fill 13 235 522 13 235 523 minecraft:black_concrete
setblock 13 235 524 minecraft:gray_concrete
fill 13 235 525 14 235 525 minecraft:black_concrete
setblock 13 235 527 minecraft:gray_concrete
fill 13 235 528 13 235 529 minecraft:black_concrete
setblock 13 235 530 minecraft:gray_concrete
fill 13 235 531 13 235 532 minecraft:black_concrete
setblock 13 235 533 minecraft:gray_concrete
fill 13 235 534 13 235 535 minecraft:black_concrete
setblock 13 235 536 minecraft:gray_concrete
fill 13 235 537 14 235 537 minecraft:black_concrete
setblock 13 235 539 minecraft:gray_concrete
fill 13 235 540 13 235 541 minecraft:black_concrete
fill 13 235 542 14 235 542 minecraft:iron_block
fill 14 235 521 14 235 522 minecraft:black_concrete
setblock 14 235 523 minecraft:gray_concrete
fill 14 235 524 15 235 524 minecraft:black_concrete
setblock 14 235 526 minecraft:gray_concrete
fill 14 235 527 14 235 528 minecraft:black_concrete
setblock 14 235 529 minecraft:gray_concrete
fill 14 235 530 14 235 531 minecraft:black_concrete
setblock 14 235 532 minecraft:gray_concrete
fill 14 235 533 14 235 534 minecraft:black_concrete
setblock 14 235 535 minecraft:gray_concrete
fill 14 235 536 15 235 536 minecraft:black_concrete
setblock 14 235 538 minecraft:gray_concrete
fill 14 235 539 14 235 540 minecraft:black_concrete
setblock 14 235 541 minecraft:gray_concrete
fill 15 235 519 18 235 519 minecraft:iron_block
fill 15 235 520 15 235 521 minecraft:black_concrete
setblock 15 235 522 minecraft:gray_concrete
fill 15 235 523 16 235 523 minecraft:black_concrete
setblock 15 235 525 minecraft:gray_concrete
fill 15 235 526 15 235 527 minecraft:black_concrete
setblock 15 235 528 minecraft:gray_concrete
fill 15 235 529 15 235 530 minecraft:black_concrete
setblock 15 235 531 minecraft:gray_concrete
fill 15 235 532 15 235 533 minecraft:black_concrete
setblock 15 235 534 minecraft:gray_concrete
fill 15 235 535 16 235 535 minecraft:black_concrete
setblock 15 235 537 minecraft:gray_concrete
fill 15 235 538 15 235 539 minecraft:black_concrete
setblock 15 235 540 minecraft:gray_concrete
fill 15 235 541 15 235 542 minecraft:black_concrete
fill 15 235 543 18 235 543 minecraft:iron_block
fill 15 235 552 17 235 552 minecraft:black_concrete
setblock 16 235 520 minecraft:black_concrete
setblock 16 235 521 minecraft:gray_concrete
fill 16 235 522 17 235 522 minecraft:black_concrete
setblock 16 235 524 minecraft:gray_concrete
fill 16 235 525 16 235 526 minecraft:black_concrete
setblock 16 235 527 minecraft:gray_concrete
fill 16 235 528 16 235 529 minecraft:black_concrete
setblock 16 235 530 minecraft:gray_concrete
fill 16 235 531 16 235 532 minecraft:black_concrete
setblock 16 235 533 minecraft:gray_concrete
fill 16 235 534 17 235 534 minecraft:black_concrete
setblock 16 235 536 minecraft:gray_concrete
fill 16 235 537 16 235 538 minecraft:black_concrete
setblock 16 235 539 minecraft:gray_concrete
fill 16 235 540 16 235 541 minecraft:black_concrete
setblock 16 235 542 minecraft:gray_concrete
setblock 17 235 520 minecraft:gray_concrete
fill 17 235 521 18 235 521 minecraft:black_concrete
setblock 17 235 523 minecraft:gray_concrete
fill 17 235 524 17 235 525 minecraft:black_concrete
setblock 17 235 526 minecraft:gray_concrete
fill 17 235 527 17 235 528 minecraft:black_concrete
setblock 17 235 529 minecraft:gray_concrete
setblock 17 235 530 minecraft:black_concrete
setblock 17 235 532 minecraft:gray_concrete
fill 17 235 533 18 235 533 minecraft:black_concrete
setblock 17 235 535 minecraft:gray_concrete
fill 17 235 536 17 235 537 minecraft:black_concrete
setblock 17 235 538 minecraft:gray_concrete
fill 17 235 539 17 235 540 minecraft:black_concrete
setblock 17 235 541 minecraft:gray_concrete
fill 17 235 542 18 235 542 minecraft:black_concrete
fill 18 235 520 19 235 520 minecraft:black_concrete
setblock 18 235 522 minecraft:gray_concrete
fill 18 235 523 18 235 524 minecraft:black_concrete
setblock 18 235 525 minecraft:gray_concrete
fill 18 235 526 18 235 527 minecraft:black_concrete
setblock 18 235 528 minecraft:gray_concrete
setblock 18 235 529 minecraft:black_concrete
setblock 18 235 534 minecraft:gray_concrete
fill 18 235 535 18 235 536 minecraft:black_concrete
setblock 18 235 537 minecraft:gray_concrete
fill 18 235 538 18 235 539 minecraft:black_concrete
setblock 18 235 540 minecraft:gray_concrete
fill 18 235 541 19 235 541 minecraft:black_concrete
setblock 18 235 552 minecraft:light_blue_stained_glass
setblock 19 235 513 minecraft:light[level=11]
setblock 19 235 519 minecraft:black_concrete
setblock 19 235 521 minecraft:gray_concrete
fill 19 235 522 19 235 523 minecraft:black_concrete
setblock 19 235 524 minecraft:gray_concrete
fill 19 235 525 19 235 526 minecraft:black_concrete
setblock 19 235 527 minecraft:gray_concrete
fill 19 235 528 20 235 528 minecraft:black_concrete
fill 19 235 534 19 235 535 minecraft:black_concrete
setblock 19 235 536 minecraft:gray_concrete
fill 19 235 537 19 235 538 minecraft:black_concrete
setblock 19 235 539 minecraft:gray_concrete
fill 19 235 540 20 235 540 minecraft:black_concrete
setblock 19 235 542 minecraft:gray_concrete
setblock 19 235 543 minecraft:black_concrete
setblock 19 235 545 minecraft:light[level=11]
fill 19 235 552 19 256 552 minecraft:black_concrete
fill 20 235 519 23 235 519 minecraft:iron_block
setblock 20 235 520 minecraft:gray_concrete
fill 20 235 521 20 235 522 minecraft:black_concrete
setblock 20 235 523 minecraft:gray_concrete
fill 20 235 524 20 235 525 minecraft:black_concrete
setblock 20 235 526 minecraft:gray_concrete
fill 20 235 527 21 235 527 minecraft:black_concrete
setblock 20 235 529 minecraft:gray_concrete
fill 20 235 533 20 235 534 minecraft:black_concrete
setblock 20 235 535 minecraft:gray_concrete
fill 20 235 536 20 235 537 minecraft:black_concrete
setblock 20 235 538 minecraft:gray_concrete
fill 20 235 539 21 235 539 minecraft:black_concrete
setblock 20 235 541 minecraft:gray_concrete
fill 20 235 542 21 235 542 minecraft:black_concrete
fill 20 235 543 23 235 543 minecraft:iron_block
fill 21 235 520 21 235 521 minecraft:black_concrete
setblock 21 235 522 minecraft:gray_concrete
fill 21 235 523 21 235 524 minecraft:black_concrete
setblock 21 235 525 minecraft:gray_concrete
fill 21 235 526 22 235 526 minecraft:black_concrete
setblock 21 235 528 minecraft:gray_concrete
fill 21 235 529 21 235 530 minecraft:black_concrete
fill 21 235 532 21 235 533 minecraft:black_concrete
setblock 21 235 534 minecraft:gray_concrete
fill 21 235 535 21 235 536 minecraft:black_concrete
setblock 21 235 537 minecraft:gray_concrete
fill 21 235 538 22 235 538 minecraft:black_concrete
setblock 21 235 540 minecraft:gray_concrete
fill 21 235 541 22 235 541 minecraft:black_concrete
setblock 22 235 520 minecraft:black_concrete
setblock 22 235 521 minecraft:gray_concrete
fill 22 235 522 22 235 523 minecraft:black_concrete
setblock 22 235 524 minecraft:gray_concrete
fill 22 235 525 23 235 525 minecraft:black_concrete
setblock 22 235 527 minecraft:gray_concrete
fill 22 235 528 22 235 529 minecraft:black_concrete
setblock 22 235 530 minecraft:gray_concrete
fill 22 235 531 22 235 532 minecraft:black_concrete
setblock 22 235 533 minecraft:gray_concrete
fill 22 235 534 22 235 535 minecraft:black_concrete
setblock 22 235 536 minecraft:gray_concrete
fill 22 235 537 23 235 537 minecraft:black_concrete
setblock 22 235 539 minecraft:gray_concrete
fill 22 235 540 23 235 540 minecraft:black_concrete
setblock 22 235 542 minecraft:gray_concrete
setblock 23 235 520 minecraft:gray_concrete
fill 23 235 521 23 235 522 minecraft:black_concrete
setblock 23 235 523 minecraft:gray_concrete
fill 23 235 524 24 235 524 minecraft:black_concrete
setblock 23 235 526 minecraft:gray_concrete
fill 23 235 527 23 235 528 minecraft:black_concrete
setblock 23 235 529 minecraft:gray_concrete
fill 23 235 530 23 235 531 minecraft:black_concrete
setblock 23 235 532 minecraft:gray_concrete
fill 23 235 533 23 235 534 minecraft:black_concrete
setblock 23 235 535 minecraft:gray_concrete
fill 23 235 536 24 235 536 minecraft:black_concrete
setblock 23 235 538 minecraft:gray_concrete
fill 23 235 539 24 235 539 minecraft:black_concrete
setblock 23 235 541 minecraft:gray_concrete
setblock 23 235 542 minecraft:black_concrete
fill 24 235 520 25 235 520 minecraft:iron_block
setblock 24 235 521 minecraft:black_concrete
setblock 24 235 522 minecraft:gray_concrete
fill 24 235 523 25 235 523 minecraft:black_concrete
setblock 24 235 525 minecraft:gray_concrete
fill 24 235 526 24 235 527 minecraft:black_concrete
setblock 24 235 528 minecraft:gray_concrete
fill 24 235 529 24 235 530 minecraft:black_concrete
setblock 24 235 531 minecraft:gray_concrete
fill 24 235 532 24 235 533 minecraft:black_concrete
setblock 24 235 534 minecraft:gray_concrete
fill 24 235 535 25 235 535 minecraft:black_concrete
setblock 24 235 537 minecraft:gray_concrete
fill 24 235 538 25 235 538 minecraft:black_concrete
setblock 24 235 540 minecraft:gray_concrete
fill 24 235 541 25 235 541 minecraft:black_concrete
fill 24 235 542 25 235 542 minecraft:iron_block
setblock 25 235 521 minecraft:gray_concrete
fill 25 235 522 26 235 522 minecraft:black_concrete
setblock 25 235 524 minecraft:gray_concrete
fill 25 235 525 25 235 526 minecraft:black_concrete
setblock 25 235 527 minecraft:gray_concrete
fill 25 235 528 25 235 529 minecraft:black_concrete
setblock 25 235 530 minecraft:gray_concrete
fill 25 235 531 25 235 532 minecraft:black_concrete
setblock 25 235 533 minecraft:gray_concrete
fill 25 235 534 26 235 534 minecraft:black_concrete
setblock 25 235 536 minecraft:gray_concrete
fill 25 235 537 26 235 537 minecraft:black_concrete
setblock 25 235 539 minecraft:gray_concrete
fill 25 235 540 26 235 540 minecraft:black_concrete
fill 26 235 521 27 235 521 minecraft:iron_block
setblock 26 235 523 minecraft:gray_concrete
fill 26 235 524 26 235 525 minecraft:black_concrete
setblock 26 235 526 minecraft:gray_concrete
fill 26 235 527 26 235 528 minecraft:black_concrete
setblock 26 235 529 minecraft:gray_concrete
fill 26 235 530 26 235 531 minecraft:black_concrete
setblock 26 235 532 minecraft:gray_concrete
fill 26 235 533 27 235 533 minecraft:black_concrete
setblock 26 235 535 minecraft:gray_concrete
fill 26 235 536 27 235 536 minecraft:black_concrete
setblock 26 235 538 minecraft:gray_concrete
fill 26 235 539 27 235 539 minecraft:black_concrete
fill 26 235 541 27 235 541 minecraft:iron_block
setblock 27 235 513 minecraft:light[level=11]
fill 27 235 522 28 235 522 minecraft:iron_block
fill 27 235 523 27 235 524 minecraft:black_concrete
setblock 27 235 525 minecraft:gray_concrete
fill 27 235 526 27 235 527 minecraft:black_concrete
setblock 27 235 528 minecraft:gray_concrete
fill 27 235 529 27 235 530 minecraft:black_concrete
setblock 27 235 531 minecraft:gray_concrete
fill 27 235 532 28 235 532 minecraft:black_concrete
setblock 27 235 534 minecraft:gray_concrete
fill 27 235 535 28 235 535 minecraft:black_concrete
setblock 27 235 537 minecraft:gray_concrete
fill 27 235 538 28 235 538 minecraft:black_concrete
fill 27 235 540 28 235 540 minecraft:iron_block
setblock 27 235 545 minecraft:light[level=11]
fill 28 235 523 29 235 523 minecraft:iron_block
setblock 28 235 524 minecraft:gray_concrete
fill 28 235 525 28 235 526 minecraft:black_concrete
setblock 28 235 527 minecraft:gray_concrete
fill 28 235 528 28 235 529 minecraft:black_concrete
setblock 28 235 530 minecraft:gray_concrete
fill 28 235 531 29 235 531 minecraft:black_concrete
setblock 28 235 533 minecraft:gray_concrete
fill 28 235 534 29 235 534 minecraft:black_concrete
setblock 28 235 536 minecraft:gray_concrete
fill 28 235 537 29 235 537 minecraft:black_concrete
fill 28 235 539 29 235 539 minecraft:iron_block
fill 28 235 552 28 307 552 minecraft:black_concrete
setblock 29 235 524 minecraft:iron_block
setblock 29 235 525 minecraft:black_concrete
setblock 29 235 526 minecraft:gray_concrete
fill 29 235 527 29 235 528 minecraft:black_concrete
setblock 29 235 529 minecraft:gray_concrete
fill 29 235 530 30 235 530 minecraft:black_concrete
setblock 29 235 532 minecraft:gray_concrete
fill 29 235 533 30 235 533 minecraft:black_concrete
setblock 29 235 535 minecraft:gray_concrete
setblock 29 235 536 minecraft:black_concrete
setblock 29 235 538 minecraft:iron_block
fill 30 235 525 30 235 526 minecraft:iron_block
setblock 30 235 527 minecraft:black_concrete
setblock 30 235 528 minecraft:gray_concrete
setblock 30 235 529 minecraft:black_concrete
setblock 30 235 531 minecraft:gray_concrete
setblock 30 235 532 minecraft:black_concrete
setblock 30 235 534 minecraft:gray_concrete
setblock 30 235 535 minecraft:black_concrete
fill 30 235 536 30 235 537 minecraft:iron_block
fill 31 235 527 31 235 530 minecraft:iron_block
setblock 31 235 531 minecraft:black_concrete
fill 31 235 532 31 235 535 minecraft:iron_block
setblock 35 235 513 minecraft:light[level=11]
setblock 35 235 521 minecraft:light[level=11]
setblock 35 235 529 minecraft:light[level=11]
setblock 35 235 537 minecraft:light[level=11]
setblock 35 235 545 minecraft:light[level=11]
fill 42 235 511 42 266 511 minecraft:black_concrete
setblock 42 235 512 minecraft:sea_lantern
fill 42 235 513 42 245 513 minecraft:black_concrete
setblock 42 235 520 minecraft:white_concrete
setblock 42 235 529 minecraft:light_blue_stained_glass
setblock 0 236 539 minecraft:white_concrete
fill 1 236 511 1 236 515 minecraft:orange_terracotta
setblock 1 236 516 minecraft:white_concrete
fill 1 236 517 1 236 523 minecraft:orange_terracotta
setblock 1 236 524 minecraft:white_concrete
fill 1 236 525 1 236 531 minecraft:orange_terracotta
setblock 1 236 532 minecraft:white_concrete
fill 1 236 533 1 236 539 minecraft:orange_terracotta
setblock 1 236 540 minecraft:white_concrete
fill 1 236 541 1 236 547 minecraft:orange_terracotta
setblock 1 236 548 minecraft:white_concrete
fill 1 236 549 5 236 551 minecraft:orange_terracotta
fill 2 236 511 2 236 514 minecraft:orange_terracotta
setblock 2 236 515 minecraft:white_concrete
fill 2 236 516 2 236 522 minecraft:orange_terracotta
setblock 2 236 523 minecraft:white_concrete
fill 2 236 524 2 236 530 minecraft:orange_terracotta
setblock 2 236 531 minecraft:white_concrete
fill 2 236 532 2 236 538 minecraft:orange_terracotta
setblock 2 236 539 minecraft:white_concrete
fill 2 236 540 2 236 546 minecraft:orange_terracotta
setblock 2 236 547 minecraft:white_concrete
fill 2 236 548 8 236 548 minecraft:orange_terracotta
fill 3 236 511 3 236 513 minecraft:orange_terracotta
setblock 3 236 514 minecraft:white_concrete
fill 3 236 515 3 236 521 minecraft:orange_terracotta
setblock 3 236 522 minecraft:white_concrete
fill 3 236 523 3 236 529 minecraft:orange_terracotta
setblock 3 236 530 minecraft:white_concrete
fill 3 236 531 3 236 537 minecraft:orange_terracotta
setblock 3 236 538 minecraft:white_concrete
fill 3 236 539 3 236 545 minecraft:orange_terracotta
setblock 3 236 546 minecraft:white_concrete
fill 3 236 547 9 236 547 minecraft:orange_terracotta
fill 4 236 511 4 236 512 minecraft:orange_terracotta
setblock 4 236 513 minecraft:white_concrete
fill 4 236 514 4 236 520 minecraft:orange_terracotta
setblock 4 236 521 minecraft:white_concrete
fill 4 236 522 4 236 528 minecraft:orange_terracotta
setblock 4 236 529 minecraft:white_concrete
fill 4 236 530 4 236 536 minecraft:orange_terracotta
setblock 4 236 537 minecraft:white_concrete
fill 4 236 538 4 236 544 minecraft:orange_terracotta
setblock 4 236 545 minecraft:white_concrete
fill 4 236 546 10 236 546 minecraft:orange_terracotta
setblock 5 236 511 minecraft:orange_terracotta
setblock 5 236 512 minecraft:white_concrete
fill 5 236 513 5 236 519 minecraft:orange_terracotta
setblock 5 236 520 minecraft:white_concrete
fill 5 236 521 5 236 527 minecraft:orange_terracotta
setblock 5 236 528 minecraft:white_concrete
fill 5 236 529 5 236 535 minecraft:orange_terracotta
setblock 5 236 536 minecraft:white_concrete
fill 5 236 537 5 236 543 minecraft:orange_terracotta
setblock 5 236 544 minecraft:white_concrete
fill 5 236 545 11 236 545 minecraft:orange_terracotta
setblock 6 236 511 minecraft:white_concrete
fill 6 236 512 6 236 518 minecraft:orange_terracotta
setblock 6 236 519 minecraft:white_concrete
fill 6 236 520 6 236 526 minecraft:orange_terracotta
setblock 6 236 527 minecraft:white_concrete
fill 6 236 528 6 236 534 minecraft:orange_terracotta
setblock 6 236 535 minecraft:white_concrete
fill 6 236 536 6 236 542 minecraft:orange_terracotta
setblock 6 236 543 minecraft:white_concrete
fill 6 236 544 12 236 544 minecraft:orange_terracotta
fill 6 236 549 6 236 550 minecraft:orange_terracotta
setblock 6 236 551 minecraft:white_concrete
fill 7 236 511 7 236 517 minecraft:orange_terracotta
setblock 7 236 518 minecraft:white_concrete
fill 7 236 519 7 236 525 minecraft:orange_terracotta
setblock 7 236 526 minecraft:white_concrete
fill 7 236 527 7 236 533 minecraft:orange_terracotta
setblock 7 236 534 minecraft:white_concrete
fill 7 236 535 7 236 541 minecraft:orange_terracotta
setblock 7 236 542 minecraft:white_concrete
fill 7 236 543 13 236 543 minecraft:orange_terracotta
setblock 7 236 549 minecraft:orange_terracotta
setblock 7 236 550 minecraft:white_concrete
fill 7 236 551 13 236 551 minecraft:orange_terracotta
fill 8 236 511 8 236 516 minecraft:orange_terracotta
setblock 8 236 517 minecraft:white_concrete
fill 8 236 518 8 236 524 minecraft:orange_terracotta
setblock 8 236 525 minecraft:white_concrete
fill 8 236 526 8 236 532 minecraft:orange_terracotta
setblock 8 236 533 minecraft:white_concrete
fill 8 236 534 8 236 540 minecraft:orange_terracotta
setblock 8 236 541 minecraft:white_concrete
fill 8 236 542 14 236 542 minecraft:orange_terracotta
setblock 8 236 549 minecraft:white_concrete
fill 8 236 550 14 236 550 minecraft:orange_terracotta
fill 9 236 511 9 236 515 minecraft:orange_terracotta
setblock 9 236 516 minecraft:white_concrete
fill 9 236 517 9 236 523 minecraft:orange_terracotta
setblock 9 236 524 minecraft:white_concrete
fill 9 236 525 9 236 531 minecraft:orange_terracotta
setblock 9 236 532 minecraft:white_concrete
fill 9 236 533 9 236 539 minecraft:orange_terracotta
setblock 9 236 540 minecraft:white_concrete
fill 9 236 541 15 236 541 minecraft:orange_terracotta
setblock 9 236 548 minecraft:white_concrete
fill 9 236 549 15 236 549 minecraft:orange_terracotta
fill 10 236 511 10 236 514 minecraft:orange_terracotta
setblock 10 236 515 minecraft:white_concrete
fill 10 236 516 10 236 522 minecraft:orange_terracotta
setblock 10 236 523 minecraft:white_concrete
fill 10 236 524 10 236 530 minecraft:orange_terracotta
setblock 10 236 531 minecraft:white_concrete
fill 10 236 532 10 236 538 minecraft:orange_terracotta
setblock 10 236 539 minecraft:white_concrete
fill 10 236 540 16 236 540 minecraft:orange_terracotta
setblock 10 236 547 minecraft:white_concrete
fill 10 236 548 16 236 548 minecraft:orange_terracotta
fill 11 236 511 11 236 513 minecraft:orange_terracotta
setblock 11 236 514 minecraft:white_concrete
fill 11 236 515 11 236 521 minecraft:orange_terracotta
setblock 11 236 522 minecraft:white_concrete
fill 11 236 523 11 236 529 minecraft:orange_terracotta
setblock 11 236 530 minecraft:white_concrete
fill 11 236 531 11 236 537 minecraft:orange_terracotta
setblock 11 236 538 minecraft:white_concrete
fill 11 236 539 17 236 539 minecraft:orange_terracotta
setblock 11 236 546 minecraft:white_concrete
fill 11 236 547 17 236 547 minecraft:orange_terracotta
fill 12 236 511 12 236 512 minecraft:orange_terracotta
setblock 12 236 513 minecraft:white_concrete
fill 12 236 514 12 236 520 minecraft:orange_terracotta
setblock 12 236 521 minecraft:white_concrete
fill 12 236 522 12 236 528 minecraft:orange_terracotta
setblock 12 236 529 minecraft:white_concrete
fill 12 236 530 12 236 536 minecraft:orange_terracotta
setblock 12 236 537 minecraft:white_concrete
fill 12 236 538 18 236 538 minecraft:orange_terracotta
setblock 12 236 545 minecraft:white_concrete
fill 12 236 546 18 236 546 minecraft:orange_terracotta
setblock 13 236 511 minecraft:orange_terracotta
setblock 13 236 512 minecraft:white_concrete
fill 13 236 513 13 236 519 minecraft:orange_terracotta
setblock 13 236 520 minecraft:white_concrete
fill 13 236 521 13 236 527 minecraft:orange_terracotta
setblock 13 236 528 minecraft:white_concrete
fill 13 236 529 13 236 535 minecraft:orange_terracotta
setblock 13 236 536 minecraft:white_concrete
fill 13 236 537 19 236 537 minecraft:orange_terracotta
setblock 13 236 544 minecraft:white_concrete
fill 13 236 545 19 236 545 minecraft:orange_terracotta
setblock 14 236 511 minecraft:white_concrete
fill 14 236 512 14 236 518 minecraft:orange_terracotta
setblock 14 236 519 minecraft:white_concrete
fill 14 236 520 14 236 526 minecraft:orange_terracotta
setblock 14 236 527 minecraft:white_concrete
fill 14 236 528 14 236 534 minecraft:orange_terracotta
setblock 14 236 535 minecraft:white_concrete
fill 14 236 536 20 236 536 minecraft:orange_terracotta
setblock 14 236 543 minecraft:white_concrete
fill 14 236 544 20 236 544 minecraft:orange_terracotta
setblock 14 236 551 minecraft:white_concrete
fill 15 236 511 15 236 517 minecraft:orange_terracotta
setblock 15 236 518 minecraft:white_concrete
fill 15 236 519 15 236 525 minecraft:orange_terracotta
setblock 15 236 526 minecraft:white_concrete
fill 15 236 527 15 236 533 minecraft:orange_terracotta
setblock 15 236 534 minecraft:white_concrete
fill 15 236 535 21 236 535 minecraft:orange_terracotta
setblock 15 236 542 minecraft:white_concrete
fill 15 236 543 21 236 543 minecraft:orange_terracotta
setblock 15 236 550 minecraft:white_concrete
fill 15 236 551 21 236 551 minecraft:orange_terracotta
setblock 15 236 552 minecraft:black_concrete
fill 16 236 511 16 236 516 minecraft:orange_terracotta
setblock 16 236 517 minecraft:white_concrete
fill 16 236 518 16 236 524 minecraft:orange_terracotta
setblock 16 236 525 minecraft:white_concrete
fill 16 236 526 16 236 532 minecraft:orange_terracotta
setblock 16 236 533 minecraft:white_concrete
fill 16 236 534 22 236 534 minecraft:orange_terracotta
setblock 16 236 541 minecraft:white_concrete
fill 16 236 542 22 236 542 minecraft:orange_terracotta
setblock 16 236 549 minecraft:white_concrete
fill 16 236 550 22 236 550 minecraft:orange_terracotta
setblock 16 236 552 minecraft:white_concrete
fill 17 236 511 17 236 515 minecraft:orange_terracotta
setblock 17 236 516 minecraft:white_concrete
fill 17 236 517 17 236 523 minecraft:orange_terracotta
setblock 17 236 524 minecraft:white_concrete
fill 17 236 525 20 236 528 minecraft:orange_terracotta
fill 17 236 529 17 237 530 minecraft:orange_concrete
fill 17 236 532 17 237 533 minecraft:orange_concrete
setblock 17 236 540 minecraft:white_concrete
fill 17 236 541 23 236 541 minecraft:orange_terracotta
setblock 17 236 548 minecraft:white_concrete
fill 17 236 549 23 236 549 minecraft:orange_terracotta
fill 17 236 552 18 259 552 minecraft:black_concrete
fill 18 236 511 18 236 514 minecraft:orange_terracotta
setblock 18 236 515 minecraft:white_concrete
fill 18 236 516 18 236 522 minecraft:orange_terracotta
setblock 18 236 523 minecraft:white_concrete
fill 18 236 524 24 236 524 minecraft:orange_terracotta
fill 18 236 529 18 237 529 minecraft:orange_concrete
fill 18 236 533 18 237 533 minecraft:orange_concrete
setblock 18 236 539 minecraft:white_concrete
fill 18 236 540 24 236 540 minecraft:orange_terracotta
setblock 18 236 547 minecraft:white_concrete
fill 18 236 548 24 236 548 minecraft:orange_terracotta
fill 19 236 511 19 236 513 minecraft:orange_terracotta
setblock 19 236 514 minecraft:white_concrete
fill 19 236 515 19 236 521 minecraft:orange_terracotta
setblock 19 236 522 minecraft:white_concrete
fill 19 236 523 25 236 523 minecraft:orange_terracotta
setblock 19 236 538 minecraft:white_concrete
fill 19 236 539 25 236 539 minecraft:orange_terracotta
setblock 19 236 546 minecraft:white_concrete
fill 19 236 547 25 236 547 minecraft:orange_terracotta
fill 20 236 511 20 236 512 minecraft:orange_terracotta
setblock 20 236 513 minecraft:white_concrete
fill 20 236 514 20 236 520 minecraft:orange_terracotta
setblock 20 236 521 minecraft:white_concrete
fill 20 236 522 26 236 522 minecraft:orange_terracotta
fill 20 236 529 21 237 529 minecraft:orange_concrete
fill 20 236 533 21 237 533 minecraft:orange_concrete
setblock 20 236 537 minecraft:white_concrete
fill 20 236 538 26 236 538 minecraft:orange_terracotta
setblock 20 236 545 minecraft:white_concrete
fill 20 236 546 26 236 546 minecraft:orange_terracotta
setblock 21 236 511 minecraft:orange_terracotta
setblock 21 236 512 minecraft:white_concrete
fill 21 236 513 21 236 519 minecraft:orange_terracotta
setblock 21 236 520 minecraft:white_concrete
fill 21 236 521 27 236 521 minecraft:orange_terracotta
fill 21 236 525 21 236 527 minecraft:orange_terracotta
setblock 21 236 528 minecraft:white_concrete
fill 21 236 530 21 237 530 minecraft:orange_concrete
fill 21 236 532 21 237 532 minecraft:orange_concrete
setblock 21 236 536 minecraft:white_concrete
fill 21 236 537 27 236 537 minecraft:orange_terracotta
setblock 21 236 544 minecraft:white_concrete
fill 21 236 545 27 236 545 minecraft:orange_terracotta
fill 21 236 552 26 241 552 minecraft:black_concrete
setblock 22 236 511 minecraft:white_concrete
fill 22 236 512 22 236 518 minecraft:orange_terracotta
setblock 22 236 519 minecraft:white_concrete
fill 22 236 520 28 236 520 minecraft:orange_terracotta
fill 22 236 525 22 236 526 minecraft:orange_terracotta
setblock 22 236 527 minecraft:white_concrete
fill 22 236 528 23 236 533 minecraft:orange_terracotta
setblock 22 236 535 minecraft:white_concrete
fill 22 236 536 28 236 536 minecraft:orange_terracotta
setblock 22 236 543 minecraft:white_concrete
fill 22 236 544 28 236 544 minecraft:orange_terracotta
setblock 22 236 551 minecraft:white_concrete
fill 23 236 510 25 237 510 minecraft:black_concrete
fill 23 236 511 23 236 517 minecraft:orange_terracotta
setblock 23 236 518 minecraft:white_concrete
fill 23 236 519 29 236 519 minecraft:orange_terracotta
setblock 23 236 525 minecraft:orange_terracotta
setblock 23 236 526 minecraft:white_concrete
fill 23 236 527 29 236 527 minecraft:orange_terracotta
setblock 23 236 534 minecraft:white_concrete
fill 23 236 535 29 236 535 minecraft:orange_terracotta
setblock 23 236 542 minecraft:white_concrete
fill 23 236 543 29 236 543 minecraft:orange_terracotta
setblock 23 236 550 minecraft:white_concrete
fill 23 236 551 29 236 551 minecraft:orange_terracotta
fill 24 236 511 24 236 516 minecraft:orange_terracotta
setblock 24 236 517 minecraft:white_concrete
fill 24 236 518 30 236 518 minecraft:orange_terracotta
setblock 24 236 525 minecraft:white_concrete
fill 24 236 526 30 236 526 minecraft:orange_terracotta
fill 24 236 528 24 236 532 minecraft:orange_terracotta
fill 24 236 533 24 237 533 minecraft:white_concrete
fill 24 236 534 30 236 534 minecraft:orange_terracotta
setblock 24 236 541 minecraft:white_concrete
fill 24 236 542 30 236 542 minecraft:orange_terracotta
setblock 24 236 549 minecraft:white_concrete
fill 24 236 550 30 236 550 minecraft:orange_terracotta
fill 25 236 511 25 236 515 minecraft:orange_terracotta
setblock 25 236 516 minecraft:white_concrete
fill 25 236 517 31 236 517 minecraft:orange_terracotta
setblock 25 236 524 minecraft:white_concrete
fill 25 236 525 31 236 525 minecraft:orange_terracotta
fill 25 236 528 25 236 531 minecraft:orange_terracotta
setblock 25 236 532 minecraft:white_concrete
fill 25 236 533 31 236 533 minecraft:orange_terracotta
setblock 25 236 540 minecraft:white_concrete
fill 25 236 541 31 236 541 minecraft:orange_terracotta
setblock 25 236 548 minecraft:white_concrete
fill 25 236 549 31 236 549 minecraft:orange_terracotta
setblock 26 236 510 minecraft:light_blue_stained_glass
fill 26 236 511 26 236 514 minecraft:orange_terracotta
setblock 26 236 515 minecraft:white_concrete
fill 26 236 516 32 236 516 minecraft:orange_terracotta
setblock 26 236 523 minecraft:white_concrete
fill 26 236 524 32 236 524 minecraft:orange_terracotta
fill 26 236 528 26 236 530 minecraft:orange_terracotta
setblock 26 236 531 minecraft:white_concrete
fill 26 236 532 32 236 532 minecraft:orange_terracotta
setblock 26 236 539 minecraft:white_concrete
fill 26 236 540 32 236 540 minecraft:orange_terracotta
setblock 26 236 547 minecraft:white_concrete
fill 26 236 548 32 236 548 minecraft:orange_terracotta
fill 27 236 510 27 244 510 minecraft:black_concrete
fill 27 236 511 27 236 513 minecraft:orange_terracotta
setblock 27 236 514 minecraft:white_concrete
fill 27 236 515 33 236 515 minecraft:orange_terracotta
setblock 27 236 522 minecraft:white_concrete
fill 27 236 523 33 236 523 minecraft:orange_terracotta
fill 27 236 528 27 236 529 minecraft:orange_terracotta
setblock 27 236 530 minecraft:white_concrete
fill 27 236 531 33 236 531 minecraft:orange_terracotta
setblock 27 236 538 minecraft:white_concrete
fill 27 236 539 33 236 539 minecraft:orange_terracotta
setblock 27 236 546 minecraft:white_concrete
fill 27 236 547 33 236 547 minecraft:orange_terracotta
setblock 27 236 552 minecraft:light_blue_stained_glass
fill 28 236 511 28 236 512 minecraft:orange_terracotta
setblock 28 236 513 minecraft:white_concrete
fill 28 236 514 34 236 514 minecraft:orange_terracotta
setblock 28 236 521 minecraft:white_concrete
fill 28 236 522 34 236 522 minecraft:orange_terracotta
setblock 28 236 528 minecraft:orange_terracotta
setblock 28 236 529 minecraft:white_concrete
fill 28 236 530 34 236 530 minecraft:orange_terracotta
setblock 28 236 537 minecraft:white_concrete
fill 28 236 538 34 236 538 minecraft:orange_terracotta
setblock 28 236 545 minecraft:white_concrete
fill 28 236 546 34 236 546 minecraft:orange_terracotta
setblock 29 236 511 minecraft:orange_terracotta
setblock 29 236 512 minecraft:white_concrete
fill 29 236 513 35 236 513 minecraft:orange_terracotta
setblock 29 236 520 minecraft:white_concrete
fill 29 236 521 35 236 521 minecraft:orange_terracotta
setblock 29 236 528 minecraft:white_concrete
fill 29 236 529 35 236 529 minecraft:orange_terracotta
setblock 29 236 536 minecraft:white_concrete
fill 29 236 537 35 236 537 minecraft:orange_terracotta
setblock 29 236 544 minecraft:white_concrete
fill 29 236 545 35 236 545 minecraft:orange_terracotta
setblock 30 236 511 minecraft:white_concrete
fill 30 236 512 36 236 512 minecraft:orange_terracotta
setblock 30 236 519 minecraft:white_concrete
fill 30 236 520 36 236 520 minecraft:orange_terracotta
setblock 30 236 527 minecraft:white_concrete
fill 30 236 528 36 236 528 minecraft:orange_terracotta
setblock 30 236 535 minecraft:white_concrete
fill 30 236 536 36 236 536 minecraft:orange_terracotta
setblock 30 236 543 minecraft:white_concrete
fill 30 236 544 36 236 544 minecraft:orange_terracotta
setblock 30 236 551 minecraft:white_concrete
fill 31 236 511 37 236 511 minecraft:orange_terracotta
setblock 31 236 518 minecraft:white_concrete
fill 31 236 519 37 236 519 minecraft:orange_terracotta
setblock 31 236 526 minecraft:white_concrete
fill 31 236 527 37 236 527 minecraft:orange_terracotta
setblock 31 236 534 minecraft:white_concrete
fill 31 236 535 37 236 535 minecraft:orange_terracotta
setblock 31 236 542 minecraft:white_concrete
fill 31 236 543 37 236 543 minecraft:orange_terracotta
setblock 31 236 550 minecraft:white_concrete
fill 31 236 551 37 236 551 minecraft:orange_terracotta
setblock 31 236 552 minecraft:light_blue_stained_glass
setblock 32 236 517 minecraft:white_concrete
fill 32 236 518 38 236 518 minecraft:orange_terracotta
setblock 32 236 525 minecraft:white_concrete
fill 32 236 526 38 236 526 minecraft:orange_terracotta
setblock 32 236 533 minecraft:white_concrete
fill 32 236 534 38 236 534 minecraft:orange_terracotta
setblock 32 236 541 minecraft:white_concrete
fill 32 236 542 38 236 542 minecraft:orange_terracotta
setblock 32 236 549 minecraft:white_concrete
fill 32 236 550 38 236 550 minecraft:orange_terracotta
setblock 33 236 516 minecraft:white_concrete
fill 33 236 517 39 236 517 minecraft:orange_terracotta
setblock 33 236 524 minecraft:white_concrete
fill 33 236 525 39 236 525 minecraft:orange_terracotta
setblock 33 236 532 minecraft:white_concrete
fill 33 236 533 39 236 533 minecraft:orange_terracotta
setblock 33 236 540 minecraft:white_concrete
fill 33 236 541 39 236 541 minecraft:orange_terracotta
setblock 33 236 548 minecraft:white_concrete
fill 33 236 549 39 236 549 minecraft:orange_terracotta
setblock 34 236 515 minecraft:white_concrete
fill 34 236 516 40 236 516 minecraft:orange_terracotta
setblock 34 236 523 minecraft:white_concrete
fill 34 236 524 40 236 524 minecraft:orange_terracotta
setblock 34 236 531 minecraft:white_concrete
fill 34 236 532 40 236 532 minecraft:orange_terracotta
setblock 34 236 539 minecraft:white_concrete
fill 34 236 540 40 236 540 minecraft:orange_terracotta
setblock 34 236 547 minecraft:white_concrete
fill 34 236 548 40 236 548 minecraft:orange_terracotta
setblock 35 236 514 minecraft:white_concrete
fill 35 236 515 41 236 515 minecraft:orange_terracotta
setblock 35 236 522 minecraft:white_concrete
fill 35 236 523 41 236 523 minecraft:orange_terracotta
setblock 35 236 530 minecraft:white_concrete
fill 35 236 531 41 236 531 minecraft:orange_terracotta
setblock 35 236 538 minecraft:white_concrete
fill 35 236 539 41 236 539 minecraft:orange_terracotta
setblock 35 236 546 minecraft:white_concrete
fill 35 236 547 41 236 547 minecraft:orange_terracotta
setblock 36 236 513 minecraft:white_concrete
fill 36 236 514 41 236 514 minecraft:orange_terracotta
setblock 36 236 521 minecraft:white_concrete
fill 36 236 522 41 236 522 minecraft:orange_terracotta
setblock 36 236 529 minecraft:white_concrete
fill 36 236 530 41 236 530 minecraft:orange_terracotta
setblock 36 236 537 minecraft:white_concrete
fill 36 236 538 41 236 538 minecraft:orange_terracotta
setblock 36 236 545 minecraft:white_concrete
fill 36 236 546 41 236 546 minecraft:orange_terracotta
setblock 37 236 512 minecraft:white_concrete
fill 37 236 513 41 236 513 minecraft:orange_terracotta
setblock 37 236 520 minecraft:white_concrete
fill 37 236 521 41 236 521 minecraft:orange_terracotta
setblock 37 236 528 minecraft:white_concrete
fill 37 236 529 41 236 529 minecraft:orange_terracotta
setblock 37 236 536 minecraft:white_concrete
fill 37 236 537 41 236 537 minecraft:orange_terracotta
setblock 37 236 544 minecraft:white_concrete
fill 37 236 545 41 236 545 minecraft:orange_terracotta
setblock 38 236 511 minecraft:white_concrete
fill 38 236 512 41 236 512 minecraft:orange_terracotta
setblock 38 236 519 minecraft:white_concrete
fill 38 236 520 41 236 520 minecraft:orange_terracotta
setblock 38 236 527 minecraft:white_concrete
fill 38 236 528 41 236 528 minecraft:orange_terracotta
setblock 38 236 535 minecraft:white_concrete
fill 38 236 536 41 236 536 minecraft:orange_terracotta
setblock 38 236 543 minecraft:white_concrete
fill 38 236 544 41 236 544 minecraft:orange_terracotta
setblock 38 236 551 minecraft:white_concrete
fill 39 236 511 41 236 511 minecraft:orange_terracotta
setblock 39 236 518 minecraft:white_concrete
fill 39 236 519 41 236 519 minecraft:orange_terracotta
setblock 39 236 526 minecraft:white_concrete
fill 39 236 527 41 236 527 minecraft:orange_terracotta
setblock 39 236 534 minecraft:white_concrete
fill 39 236 535 41 236 535 minecraft:orange_terracotta
setblock 39 236 542 minecraft:white_concrete
fill 39 236 543 41 236 543 minecraft:orange_terracotta
setblock 39 236 550 minecraft:white_concrete
fill 39 236 551 41 236 551 minecraft:orange_terracotta
setblock 40 236 517 minecraft:white_concrete
fill 40 236 518 41 236 518 minecraft:orange_terracotta
setblock 40 236 525 minecraft:white_concrete
fill 40 236 526 41 236 526 minecraft:orange_terracotta
setblock 40 236 533 minecraft:white_concrete
fill 40 236 534 41 236 534 minecraft:orange_terracotta
setblock 40 236 541 minecraft:white_concrete
fill 40 236 542 41 236 542 minecraft:orange_terracotta
setblock 40 236 549 minecraft:white_concrete
fill 40 236 550 41 236 550 minecraft:orange_terracotta
setblock 41 236 516 minecraft:white_concrete
setblock 41 236 517 minecraft:orange_terracotta
setblock 41 236 524 minecraft:white_concrete
setblock 41 236 525 minecraft:orange_terracotta
setblock 41 236 532 minecraft:white_concrete
setblock 41 236 533 minecraft:orange_terracotta
setblock 41 236 540 minecraft:white_concrete
setblock 41 236 541 minecraft:orange_terracotta
setblock 41 236 548 minecraft:white_concrete
setblock 41 236 549 minecraft:orange_terracotta
fill 42 236 512 42 307 512 minecraft:black_concrete
fill 42 236 520 42 242 520 minecraft:black_concrete
fill 42 236 529 42 307 529 minecraft:black_concrete
fill 0 237 539 0 252 539 minecraft:black_concrete
fill 7 237 527 7 237 535 minecraft:iron_block
fill 8 237 525 8 237 530 minecraft:iron_block
fill 8 237 532 8 237 537 minecraft:iron_block
fill 9 237 523 9 237 526 minecraft:iron_block
fill 9 237 536 9 237 539 minecraft:iron_block
fill 10 237 522 10 237 524 minecraft:iron_block
fill 10 237 538 10 237 540 minecraft:iron_block
fill 11 237 521 11 237 523 minecraft:iron_block
fill 11 237 539 11 237 541 minecraft:iron_block
fill 12 237 521 12 237 522 minecraft:iron_block
fill 12 237 540 12 237 541 minecraft:iron_block
fill 13 237 520 14 237 521 minecraft:iron_block
fill 13 237 541 14 237 542 minecraft:iron_block
fill 15 237 519 18 237 520 minecraft:iron_block
fill 15 237 542 18 237 543 minecraft:iron_block
setblock 15 237 552 minecraft:light_blue_stained_glass
fill 16 237 552 16 307 552 minecraft:black_concrete
fill 19 237 519 23 237 519 minecraft:iron_block
fill 19 237 543 23 237 543 minecraft:iron_block
fill 20 237 520 25 237 520 minecraft:iron_block
fill 20 237 542 25 237 542 minecraft:iron_block
fill 24 237 521 27 237 521 minecraft:iron_block
fill 24 237 526 24 237 532 minecraft:white_concrete
fill 24 237 534 24 243 536 minecraft:white_concrete
fill 24 237 541 27 237 541 minecraft:iron_block
fill 26 237 510 26 273 510 minecraft:black_concrete
fill 26 237 522 28 237 522 minecraft:iron_block
fill 26 237 540 28 237 540 minecraft:iron_block
fill 27 237 523 29 237 523 minecraft:iron_block
fill 27 237 539 29 237 539 minecraft:iron_block
fill 27 237 552 27 245 552 minecraft:black_concrete
fill 28 237 524 29 237 524 minecraft:iron_block
fill 28 237 538 29 237 538 minecraft:iron_block
fill 29 237 525 30 237 526 minecraft:iron_block
fill 29 237 536 30 237 537 minecraft:iron_block
fill 30 237 527 31 237 530 minecraft:iron_block
fill 30 237 532 31 237 535 minecraft:iron_block
setblock 31 237 531 minecraft:iron_block
fill 31 237 552 31 248 552 minecraft:black_concrete
setblock 40 237 510 minecraft:sea_lantern
setblock 41 237 552 minecraft:white_concrete
setblock 42 237 536 minecraft:sea_lantern
fill 42 237 552 42 307 552 minecraft:black_concrete
fill 15 238 552 15 299 552 minecraft:black_concrete
setblock 23 238 510 minecraft:light_blue_stained_glass
fill 24 238 510 25 269 510 minecraft:black_concrete
fill 24 238 526 24 243 528 minecraft:white_concrete
fill 24 238 529 24 241 533 minecraft:red_concrete
setblock 32 238 552 minecraft:sea_lantern
fill 33 238 552 33 271 552 minecraft:black_concrete
fill 40 238 510 40 261 510 minecraft:black_concrete
fill 41 238 552 41 246 552 minecraft:black_concrete
setblock 42 238 517 minecraft:sea_lantern
fill 42 238 518 42 307 518 minecraft:black_concrete
fill 42 238 536 42 242 536 minecraft:black_concrete
setblock 42 238 550 minecraft:sea_lantern
fill 42 238 551 42 256 551 minecraft:black_concrete
fill 23 239 510 23 257 510 minecraft:black_concrete
fill 32 239 552 32 295 552 minecraft:black_concrete
fill 42 239 517 42 270 517 minecraft:black_concrete
fill 42 239 550 42 285 550 minecraft:black_concrete
fill 25 240 531 30 240 532 minecraft:gray_concrete
fill 35 240 513 35 244 513 minecraft:iron_block
setblock 42 240 531 minecraft:light_blue_stained_glass
fill 42 240 532 42 253 533 minecraft:black_concrete
fill 15 241 537 16 242 538 minecraft:light_blue_stained_glass
setblock 20 241 552 minecraft:sea_lantern
setblock 22 241 510 minecraft:sea_lantern
setblock 42 241 523 minecraft:sea_lantern
fill 42 241 524 42 266 524 minecraft:black_concrete
fill 42 241 531 42 249 531 minecraft:black_concrete
fill 11 242 510 12 245 510 minecraft:black_concrete
setblock 13 242 510 minecraft:white_concrete
fill 20 242 552 20 255 552 minecraft:black_concrete
setblock 21 242 552 minecraft:sea_lantern
fill 22 242 510 22 266 510 minecraft:black_concrete
fill 22 242 552 26 257 552 minecraft:black_concrete
fill 24 242 529 24 243 533 minecraft:white_concrete
setblock 42 242 522 minecraft:white_concrete
fill 42 242 523 42 280 523 minecraft:black_concrete
setblock 42 242 534 minecraft:white_concrete
setblock 42 242 549 minecraft:white_concrete
fill 0 243 518 0 245 518 minecraft:cyan_concrete
fill 0 243 534 0 245 534 minecraft:cyan_concrete
fill 0 243 550 0 245 550 minecraft:cyan_concrete
setblock 3 243 513 minecraft:light[level=11]
setblock 3 243 521 minecraft:light[level=11]
setblock 3 243 529 minecraft:light[level=11]
setblock 3 243 537 minecraft:light[level=11]
setblock 3 243 545 minecraft:light[level=11]
fill 4 243 510 4 245 510 minecraft:cyan_concrete
setblock 11 243 513 minecraft:light[level=11]
setblock 11 243 521 minecraft:light[level=11]
setblock 11 243 529 minecraft:light[level=11]
setblock 11 243 537 minecraft:light[level=11]
setblock 11 243 545 minecraft:light[level=11]
fill 13 243 510 13 253 510 minecraft:black_concrete
fill 14 243 552 14 245 552 minecraft:cyan_concrete
setblock 19 243 513 minecraft:light[level=11]
setblock 19 243 521 minecraft:light[level=11]
setblock 19 243 529 minecraft:light[level=11]
setblock 19 243 537 minecraft:light[level=11]
setblock 19 243 545 minecraft:light[level=11]
fill 20 243 510 20 245 510 minecraft:cyan_concrete
fill 21 243 552 21 261 552 minecraft:black_concrete
setblock 27 243 513 minecraft:light[level=11]
setblock 27 243 521 minecraft:light[level=11]
setblock 27 243 529 minecraft:light[level=11]
setblock 27 243 537 minecraft:light[level=11]
setblock 27 243 545 minecraft:light[level=11]
fill 30 243 552 30 245 552 minecraft:cyan_concrete
setblock 31 243 510 minecraft:sea_lantern
setblock 35 243 521 minecraft:light[level=11]
setblock 35 243 529 minecraft:light[level=11]
setblock 35 243 537 minecraft:light[level=11]
setblock 35 243 545 minecraft:light[level=11]
fill 36 243 510 36 245 510 minecraft:cyan_concrete
setblock 39 243 552 minecraft:light_blue_stained_glass
fill 40 243 552 40 268 552 minecraft:black_concrete
fill 42 243 520 42 245 520 minecraft:cyan_concrete
fill 42 243 522 42 270 522 minecraft:black_concrete
fill 42 243 534 42 248 534 minecraft:black_concrete
fill 42 243 536 42 245 536 minecraft:cyan_concrete
fill 42 243 549 42 307 549 minecraft:black_concrete
fill 2 244 527 15 244 535 minecraft:black_wool
fill 3 244 524 39 244 526 minecraft:black_wool
fill 3 244 536 39 244 538 minecraft:black_wool
fill 4 244 522 38 244 523 minecraft:black_wool
fill 4 244 539 38 244 540 minecraft:black_wool
fill 5 244 520 37 244 521 minecraft:black_wool
fill 5 244 541 37 244 542 minecraft:black_wool
fill 6 244 519 36 244 519 minecraft:black_wool
fill 6 244 543 36 244 543 minecraft:black_wool
fill 7 244 518 35 244 518 minecraft:black_wool
fill 7 244 544 35 244 544 minecraft:black_wool
fill 8 244 517 34 244 517 minecraft:black_wool
fill 8 244 545 34 244 545 minecraft:black_wool
fill 9 244 516 33 244 516 minecraft:black_wool
fill 9 244 546 33 244 546 minecraft:black_wool
fill 10 244 515 32 244 515 minecraft:black_wool
fill 10 244 547 32 244 547 minecraft:black_wool
fill 12 244 514 30 244 514 minecraft:black_wool
fill 12 244 548 30 244 548 minecraft:black_wool
fill 14 244 513 28 244 513 minecraft:black_wool
fill 14 244 549 28 244 549 minecraft:black_wool
fill 16 244 527 16 272 530 minecraft:black_wool
fill 16 244 533 16 272 535 minecraft:black_wool
fill 17 244 512 25 244 512 minecraft:black_wool
fill 17 244 527 17 272 529 minecraft:black_wool
fill 17 244 535 40 244 535 minecraft:black_wool
fill 17 244 550 25 244 550 minecraft:black_wool
fill 18 244 527 40 244 528 minecraft:black_wool
fill 22 244 529 40 244 529 minecraft:black_wool
fill 22 244 534 40 244 534 minecraft:black_wool
fill 23 244 530 40 244 533 minecraft:black_wool
fill 31 244 510 31 261 510 minecraft:black_concrete
setblock 39 244 552 minecraft:black_concrete
setblock 42 244 516 minecraft:light_blue_stained_glass
setblock 42 244 547 minecraft:light_blue_stained_glass
setblock 0 245 525 minecraft:white_concrete
fill 2 245 530 15 245 532 minecraft:black_wool
fill 3 245 525 15 245 529 minecraft:black_wool
fill 3 245 533 15 245 537 minecraft:black_wool
fill 4 245 523 38 245 524 minecraft:black_wool
fill 4 245 538 38 245 539 minecraft:black_wool
fill 5 245 521 37 245 522 minecraft:black_wool
fill 5 245 540 37 245 541 minecraft:black_wool
fill 6 245 520 36 245 520 minecraft:black_wool
fill 6 245 542 36 245 542 minecraft:black_wool
fill 7 245 519 35 246 519 minecraft:black_wool
fill 7 245 543 35 246 543 minecraft:black_wool
fill 8 245 518 34 246 518 minecraft:black_wool
fill 8 245 544 34 246 544 minecraft:black_wool
fill 9 245 517 33 246 517 minecraft:black_wool
fill 9 245 545 33 246 545 minecraft:black_wool
fill 10 245 516 32 245 516 minecraft:black_wool
fill 10 245 546 32 245 546 minecraft:black_wool
fill 11 245 515 31 245 515 minecraft:black_wool
fill 11 245 547 31 245 547 minecraft:black_wool
fill 13 245 514 29 245 514 minecraft:black_wool
fill 13 245 548 29 245 548 minecraft:black_wool
fill 15 245 513 27 245 513 minecraft:black_wool
fill 15 245 549 27 245 549 minecraft:black_wool
fill 16 245 525 39 245 526 minecraft:black_wool
fill 16 245 536 39 245 537 minecraft:black_wool
fill 17 245 535 18 249 535 minecraft:black_wool
fill 18 245 527 39 246 528 minecraft:black_wool
fill 20 245 512 22 245 512 minecraft:black_wool
fill 20 245 535 39 245 535 minecraft:black_wool
fill 20 245 550 22 245 550 minecraft:black_wool
fill 22 245 529 39 247 529 minecraft:black_wool
fill 22 245 534 39 246 534 minecraft:black_wool
fill 23 245 530 39 247 533 minecraft:black_wool
setblock 27 245 510 minecraft:white_concrete
setblock 39 245 552 minecraft:white_concrete
fill 40 245 530 40 245 532 minecraft:black_wool
fill 42 245 516 42 307 516 minecraft:black_concrete
setblock 42 245 541 minecraft:white_concrete
fill 42 245 542 42 299 542 minecraft:black_concrete
setblock 42 245 545 minecraft:white_concrete
fill 42 245 547 42 264 547 minecraft:black_concrete
fill 0 246 518 0 251 518 minecraft:black_concrete
fill 0 246 525 0 249 525 minecraft:black_concrete
setblock 0 246 534 minecraft:white_concrete
fill 0 246 550 0 251 550 minecraft:black_concrete
fill 3 246 527 15 246 535 minecraft:black_wool
fill 4 246 510 4 251 510 minecraft:black_concrete
fill 4 246 524 38 246 526 minecraft:black_wool
fill 4 246 536 38 246 538 minecraft:black_wool
fill 5 246 522 37 246 523 minecraft:black_wool
fill 5 246 539 37 246 540 minecraft:black_wool
fill 6 246 521 36 247 521 minecraft:black_wool
fill 6 246 541 36 247 541 minecraft:black_wool
fill 7 246 520 35 247 520 minecraft:black_wool
fill 7 246 542 35 247 542 minecraft:black_wool
setblock 11 246 510 minecraft:light_blue_stained_glass
fill 11 246 516 31 247 516 minecraft:black_wool
fill 11 246 546 31 247 546 minecraft:black_wool
fill 12 246 510 12 251 510 minecraft:black_concrete
fill 12 246 515 30 246 515 minecraft:black_wool
fill 12 246 547 30 246 547 minecraft:black_wool
fill 14 246 514 28 246 514 minecraft:black_wool
fill 14 246 548 28 246 548 minecraft:black_wool
fill 14 246 552 14 251 552 minecraft:black_concrete
fill 17 246 513 25 246 513 minecraft:black_wool
fill 17 246 549 25 246 549 minecraft:black_wool
fill 20 246 510 20 251 510 minecraft:black_concrete
setblock 21 246 510 minecraft:light_blue_stained_glass
fill 21 246 535 39 246 535 minecraft:black_wool
fill 27 246 510 27 307 510 minecraft:black_concrete
setblock 27 246 552 minecraft:sea_lantern
fill 30 246 552 30 251 552 minecraft:black_concrete
fill 36 246 510 36 251 510 minecraft:black_concrete
fill 39 246 552 39 254 552 minecraft:black_concrete
setblock 42 246 513 minecraft:sea_lantern
fill 42 246 520 42 251 520 minecraft:black_concrete
fill 42 246 536 42 251 536 minecraft:black_concrete
setblock 42 246 537 minecraft:sea_lantern
fill 42 246 541 42 250 541 minecraft:black_concrete
fill 42 246 545 42 293 545 minecraft:black_concrete
setblock 0 247 512 minecraft:white_concrete
fill 0 247 534 0 251 534 minecraft:black_concrete
fill 3 247 529 15 247 533 minecraft:black_wool
fill 4 247 525 15 247 528 minecraft:black_wool
fill 4 247 534 15 247 537 minecraft:black_wool
fill 5 247 523 37 247 524 minecraft:black_wool
fill 5 247 538 37 247 539 minecraft:black_wool
fill 6 247 522 36 248 522 minecraft:black_wool
fill 6 247 540 36 248 540 minecraft:black_wool
fill 8 247 519 34 248 519 minecraft:black_wool
fill 8 247 543 34 248 543 minecraft:black_wool
fill 9 247 518 33 248 518 minecraft:black_wool
fill 9 247 544 33 248 544 minecraft:black_wool
fill 10 247 517 32 247 517 minecraft:black_wool
fill 10 247 545 32 247 545 minecraft:black_wool
fill 11 247 510 11 302 510 minecraft:black_concrete
fill 13 247 515 29 247 515 minecraft:black_wool
fill 13 247 547 29 247 547 minecraft:black_wool
fill 15 247 514 27 247 514 minecraft:black_wool
fill 15 247 548 27 247 548 minecraft:black_wool
fill 16 247 525 38 247 526 minecraft:black_wool
fill 16 247 531 16 272 531 minecraft:black_wool
fill 16 247 536 38 247 537 minecraft:black_wool
fill 18 247 527 38 248 528 minecraft:black_wool
fill 19 247 513 23 247 513 minecraft:black_wool
fill 19 247 549 23 247 549 minecraft:black_wool
fill 21 247 510 21 258 510 minecraft:black_concrete
fill 21 247 535 38 248 535 minecraft:black_wool
fill 22 247 534 38 248 534 minecraft:black_wool
fill 27 247 552 27 272 552 minecraft:black_concrete
setblock 41 247 552 minecraft:sea_lantern
fill 42 247 513 42 267 513 minecraft:black_concrete
setblock 42 247 521 minecraft:light_blue_stained_glass
fill 42 247 537 42 307 537 minecraft:black_concrete
fill 0 248 512 0 250 512 minecraft:black_concrete
fill 0 248 535 0 249 535 minecraft:sea_lantern
fill 0 248 536 0 269 537 minecraft:black_concrete
fill 4 248 527 15 248 535 minecraft:black_wool
fill 5 248 524 37 248 526 minecraft:black_wool
fill 5 248 536 37 248 538 minecraft:black_wool
fill 6 248 523 36 249 523 minecraft:black_wool
fill 6 248 539 36 249 539 minecraft:black_wool
fill 7 248 521 35 249 521 minecraft:black_wool
fill 7 248 541 35 249 541 minecraft:black_wool
fill 8 248 520 34 249 520 minecraft:black_wool
fill 8 248 542 34 249 542 minecraft:black_wool
fill 11 248 517 31 249 517 minecraft:black_wool
fill 11 248 545 31 249 545 minecraft:black_wool
fill 12 248 516 30 248 516 minecraft:black_wool
fill 12 248 546 30 248 546 minecraft:black_wool
fill 14 248 515 28 248 515 minecraft:black_wool
fill 14 248 547 28 248 547 minecraft:black_wool
fill 17 248 514 25 248 514 minecraft:black_wool
fill 17 248 548 25 248 548 minecraft:black_wool
fill 22 248 529 38 249 529 minecraft:black_wool
fill 23 248 512 23 263 512 minecraft:iron_block
fill 23 248 530 38 249 533 minecraft:black_wool
fill 41 248 552 41 261 552 minecraft:black_concrete
fill 42 248 521 42 266 521 minecraft:black_concrete
fill 4 249 529 15 249 533 minecraft:black_wool
fill 5 249 525 15 249 528 minecraft:black_wool
fill 5 249 534 15 249 537 minecraft:black_wool
fill 6 249 524 36 250 524 minecraft:black_wool
fill 6 249 538 36 250 538 minecraft:black_wool
fill 7 249 522 35 250 522 minecraft:black_wool
fill 7 249 540 35 250 540 minecraft:black_wool
fill 9 249 519 33 249 519 minecraft:black_wool
fill 9 249 543 33 249 543 minecraft:black_wool
fill 10 249 518 32 249 518 minecraft:black_wool
fill 10 249 544 32 249 544 minecraft:black_wool
fill 13 249 516 29 249 516 minecraft:black_wool
fill 13 249 546 29 249 546 minecraft:black_wool
fill 15 249 515 27 249 515 minecraft:black_wool
fill 15 249 547 27 249 547 minecraft:black_wool
fill 16 249 525 37 249 526 minecraft:black_wool
fill 16 249 536 37 249 537 minecraft:black_wool
fill 18 249 527 37 250 528 minecraft:black_wool
fill 19 249 514 23 249 514 minecraft:black_wool
fill 19 249 548 23 249 548 minecraft:black_wool
fill 21 249 535 37 250 535 minecraft:black_wool
fill 23 249 534 37 251 534 minecraft:black_wool
setblock 31 249 552 minecraft:sea_lantern
setblock 42 249 534 minecraft:sea_lantern
setblock 0 250 525 minecraft:white_concrete
setblock 0 250 535 minecraft:light_blue_stained_glass
fill 5 250 526 15 250 536 minecraft:black_wool
fill 6 250 525 36 251 525 minecraft:black_wool
fill 6 250 537 36 251 537 minecraft:black_wool
fill 7 250 523 35 251 523 minecraft:black_wool
fill 7 250 539 35 251 539 minecraft:black_wool
fill 8 250 521 34 250 521 minecraft:black_wool
fill 8 250 541 34 250 541 minecraft:black_wool
fill 9 250 520 33 251 520 minecraft:black_wool
fill 9 250 542 33 251 542 minecraft:black_wool
fill 10 250 519 32 251 519 minecraft:black_wool
fill 10 250 543 32 251 543 minecraft:black_wool
fill 11 250 518 31 250 518 minecraft:black_wool
fill 11 250 544 31 250 544 minecraft:black_wool
fill 12 250 517 30 250 517 minecraft:black_wool
fill 12 250 545 30 250 545 minecraft:black_wool
fill 14 250 516 28 250 516 minecraft:black_wool
fill 14 250 546 28 250 546 minecraft:black_wool
fill 16 250 515 26 250 515 minecraft:black_wool
fill 16 250 526 37 250 526 minecraft:black_wool
fill 16 250 532 16 272 532 minecraft:black_wool
fill 16 250 536 37 250 536 minecraft:black_wool
fill 16 250 547 26 250 547 minecraft:black_wool
fill 17 250 535 17 272 535 minecraft:black_wool
fill 22 250 529 37 251 529 minecraft:black_wool
fill 23 250 530 37 251 533 minecraft:black_wool
fill 31 250 552 31 282 552 minecraft:black_concrete
fill 38 250 531 38 250 533 minecraft:light_blue_stained_glass
setblock 42 250 531 minecraft:light_blue_stained_glass
fill 42 250 534 42 255 534 minecraft:black_concrete
setblock 0 251 512 minecraft:light_blue_stained_glass
fill 0 251 525 0 307 525 minecraft:black_concrete
fill 0 251 535 0 260 535 minecraft:black_concrete
setblock 0 251 547 minecraft:white_concrete
setblock 3 251 513 minecraft:light[level=11]
setblock 3 251 521 minecraft:light[level=11]
setblock 3 251 529 minecraft:light[level=11]
setblock 3 251 537 minecraft:light[level=11]
setblock 3 251 545 minecraft:light[level=11]
fill 5 251 528 15 251 534 minecraft:black_wool
fill 6 251 526 15 252 527 minecraft:black_wool
fill 6 251 535 15 252 536 minecraft:black_wool
fill 7 251 524 35 252 524 minecraft:black_wool
fill 7 251 538 35 252 538 minecraft:black_wool
fill 8 251 522 34 252 522 minecraft:black_wool
fill 8 251 540 34 252 540 minecraft:black_wool
fill 9 251 521 33 252 521 minecraft:black_wool
fill 9 251 541 33 252 541 minecraft:black_wool
setblock 11 251 513 minecraft:light[level=11]
setblock 11 251 545 minecraft:light[level=11]
fill 12 251 518 30 252 518 minecraft:black_wool
fill 12 251 544 30 252 544 minecraft:black_wool
fill 13 251 517 29 251 517 minecraft:black_wool
fill 13 251 545 29 251 545 minecraft:black_wool
fill 15 251 516 27 251 516 minecraft:black_wool
fill 15 251 546 27 251 546 minecraft:black_wool
fill 16 251 526 36 252 526 minecraft:black_wool
fill 16 251 536 36 252 536 minecraft:black_wool
fill 18 251 515 24 251 515 minecraft:black_wool
fill 18 251 527 36 252 528 minecraft:black_wool
fill 18 251 547 24 251 547 minecraft:black_wool
setblock 19 251 513 minecraft:light[level=11]
setblock 19 251 529 minecraft:light[level=11]
fill 22 251 535 36 252 535 minecraft:black_wool
setblock 27 251 513 minecraft:light[level=11]
setblock 35 251 513 minecraft:light[level=11]
setblock 35 251 521 minecraft:light[level=11]
setblock 35 251 545 minecraft:light[level=11]
setblock 37 251 528 minecraft:black_wool
fill 42 251 531 42 307 531 minecraft:black_concrete
setblock 42 251 541 minecraft:light_blue_stained_glass
fill 0 252 512 0 307 512 minecraft:black_concrete
fill 0 252 518 0 254 518 minecraft:cyan_concrete
fill 0 252 534 0 254 534 minecraft:cyan_concrete
setblock 0 252 540 minecraft:white_concrete
fill 0 252 547 0 270 547 minecraft:black_concrete
fill 0 252 550 0 254 550 minecraft:cyan_concrete
fill 4 252 510 4 254 510 minecraft:cyan_concrete
fill 6 252 528 15 253 534 minecraft:black_wool
fill 7 252 525 35 253 525 minecraft:black_wool
fill 7 252 537 35 253 537 minecraft:black_wool
fill 8 252 523 34 253 523 minecraft:black_wool
fill 8 252 539 34 253 539 minecraft:black_wool
fill 10 252 520 32 252 520 minecraft:black_wool
fill 10 252 542 32 252 542 minecraft:black_wool
fill 11 252 519 31 252 519 minecraft:black_wool
fill 11 252 543 31 252 543 minecraft:black_wool
setblock 12 252 510 minecraft:white_concrete
fill 14 252 517 28 252 517 minecraft:black_wool
fill 14 252 545 28 252 545 minecraft:black_wool
fill 14 252 552 14 254 552 minecraft:cyan_concrete
fill 16 252 516 26 252 516 minecraft:black_wool
fill 16 252 546 26 252 546 minecraft:black_wool
fill 20 252 510 20 254 510 minecraft:cyan_concrete
fill 21 252 529 36 253 529 minecraft:black_wool
fill 23 252 530 36 253 534 minecraft:black_wool
fill 30 252 552 30 254 552 minecraft:cyan_concrete
fill 35 252 523 35 267 523 minecraft:iron_block
fill 36 252 510 36 254 510 minecraft:cyan_concrete
fill 42 252 520 42 254 520 minecraft:cyan_concrete
fill 42 252 536 42 254 536 minecraft:cyan_concrete
fill 42 252 541 42 307 541 minecraft:black_concrete
setblock 0 253 539 minecraft:sea_lantern
fill 0 253 540 0 263 540 minecraft:black_concrete
fill 7 253 526 15 254 527 minecraft:black_wool
fill 7 253 535 15 254 536 minecraft:black_wool
fill 8 253 524 34 254 524 minecraft:black_wool
fill 8 253 538 34 254 538 minecraft:black_wool
fill 9 253 522 33 254 522 minecraft:black_wool
fill 9 253 540 33 254 540 minecraft:black_wool
fill 10 253 521 32 254 521 minecraft:black_wool
fill 10 253 541 32 254 541 minecraft:black_wool
fill 11 253 520 31 254 520 minecraft:black_wool
fill 11 253 542 31 254 542 minecraft:black_wool
fill 12 253 510 12 307 510 minecraft:black_concrete
fill 12 253 519 30 254 519 minecraft:black_wool
fill 12 253 543 30 254 543 minecraft:black_wool
fill 13 253 518 29 253 518 minecraft:black_wool
fill 13 253 544 29 253 544 minecraft:black_wool
fill 15 253 517 27 253 517 minecraft:black_wool
fill 15 253 545 27 253 545 minecraft:black_wool
fill 16 253 526 35 254 526 minecraft:black_wool
fill 16 253 536 35 254 536 minecraft:black_wool
setblock 17 253 510 minecraft:sea_lantern
fill 18 253 516 24 253 516 minecraft:black_wool
fill 18 253 527 18 272 529 minecraft:black_wool
fill 18 253 546 24 253 546 minecraft:black_wool
fill 19 253 527 35 254 528 minecraft:black_wool
fill 22 253 535 35 254 535 minecraft:black_wool
setblock 36 253 528 minecraft:black_wool
fill 0 254 539 0 261 539 minecraft:black_concrete
fill 6 254 531 15 254 531 minecraft:black_wool
fill 7 254 528 15 255 530 minecraft:black_wool
fill 7 254 532 15 255 534 minecraft:black_wool
fill 8 254 525 34 255 525 minecraft:black_wool
fill 8 254 537 34 255 537 minecraft:black_wool
fill 9 254 523 33 255 523 minecraft:black_wool
fill 9 254 539 33 255 539 minecraft:black_wool
setblock 13 254 510 minecraft:white_concrete
fill 14 254 518 28 254 518 minecraft:black_wool
fill 14 254 544 28 254 544 minecraft:black_wool
fill 16 254 517 26 254 517 minecraft:black_wool
fill 16 254 545 26 254 545 minecraft:black_wool
fill 17 254 510 17 258 510 minecraft:black_concrete
setblock 21 254 516 minecraft:black_wool
fill 21 254 529 35 255 529 minecraft:black_wool
setblock 21 254 546 minecraft:black_wool
fill 23 254 530 35 255 534 minecraft:black_wool
fill 32 254 510 32 306 510 minecraft:black_concrete
setblock 33 254 510 minecraft:sea_lantern
setblock 34 254 510 minecraft:white_concrete
fill 35 254 552 35 307 552 minecraft:black_concrete
setblock 36 254 531 minecraft:black_wool
setblock 36 254 552 minecraft:sea_lantern
fill 42 254 532 42 307 532 minecraft:black_concrete
setblock 42 254 533 minecraft:sea_lantern
fill 0 255 518 0 260 518 minecraft:black_concrete
fill 0 255 534 0 260 534 minecraft:black_concrete
fill 0 255 550 0 260 550 minecraft:black_concrete
fill 4 255 510 4 260 510 minecraft:black_concrete
fill 7 255 531 15 256 531 minecraft:black_wool
fill 8 255 526 15 256 527 minecraft:black_wool
fill 8 255 535 15 256 536 minecraft:black_wool
fill 9 255 524 33 256 524 minecraft:black_wool
fill 9 255 538 33 256 538 minecraft:black_wool
fill 10 255 522 32 255 522 minecraft:black_wool
fill 10 255 540 32 255 540 minecraft:black_wool
fill 11 255 521 31 255 521 minecraft:black_wool
fill 11 255 541 31 255 541 minecraft:black_wool
fill 12 255 520 30 255 520 minecraft:black_wool
fill 12 255 542 30 255 542 minecraft:black_wool
fill 13 255 510 13 307 510 minecraft:black_concrete
fill 13 255 519 29 255 519 minecraft:black_wool
fill 13 255 543 29 255 543 minecraft:black_wool
fill 14 255 552 14 257 552 minecraft:black_concrete
fill 15 255 518 27 255 518 minecraft:black_wool
fill 15 255 544 27 255 544 minecraft:black_wool
fill 16 255 526 34 256 526 minecraft:black_wool
fill 16 255 536 34 256 536 minecraft:black_wool
fill 18 255 517 24 255 517 minecraft:black_wool
fill 18 255 545 24 255 545 minecraft:black_wool
fill 19 255 527 34 257 528 minecraft:black_wool
fill 20 255 510 20 260 510 minecraft:black_concrete
fill 22 255 535 34 257 535 minecraft:black_wool
fill 30 255 552 30 260 552 minecraft:black_concrete
setblock 33 255 510 minecraft:light_blue_stained_glass
fill 34 255 510 34 307 510 minecraft:black_concrete
setblock 35 255 528 minecraft:black_wool
fill 36 255 510 36 260 510 minecraft:black_concrete
setblock 36 255 552 minecraft:light_blue_stained_glass
setblock 39 255 552 minecraft:sea_lantern
fill 42 255 520 42 260 520 minecraft:black_concrete
fill 42 255 533 42 307 533 minecraft:black_concrete
fill 42 255 536 42 260 536 minecraft:black_concrete
fill 0 256 548 0 265 548 minecraft:black_concrete
setblock 0 256 549 minecraft:sea_lantern
setblock 6 256 510 minecraft:sea_lantern
fill 7 256 530 15 256 530 minecraft:black_wool
fill 7 256 532 15 256 532 minecraft:black_wool
fill 8 256 528 15 257 529 minecraft:black_wool
fill 8 256 533 15 257 534 minecraft:black_wool
fill 9 256 525 33 257 525 minecraft:black_wool
fill 9 256 537 33 257 537 minecraft:black_wool
fill 10 256 523 32 257 523 minecraft:black_wool
fill 10 256 539 32 257 539 minecraft:black_wool
fill 11 256 522 31 257 522 minecraft:black_wool
fill 11 256 540 31 257 540 minecraft:black_wool
fill 12 256 521 30 257 521 minecraft:black_wool
fill 12 256 541 30 257 541 minecraft:black_wool
fill 13 256 520 29 257 520 minecraft:black_wool
fill 13 256 542 29 257 542 minecraft:black_wool
fill 14 256 519 28 256 519 minecraft:black_wool
fill 14 256 543 28 256 543 minecraft:black_wool
fill 16 256 518 26 256 518 minecraft:black_wool
fill 16 256 544 26 256 544 minecraft:black_wool
fill 17 256 530 17 272 530 minecraft:black_wool
fill 20 256 517 22 256 517 minecraft:black_wool
fill 20 256 545 22 256 545 minecraft:black_wool
setblock 20 256 552 minecraft:sea_lantern
fill 21 256 529 34 258 529 minecraft:black_wool
fill 23 256 530 34 257 534 minecraft:black_wool
fill 33 256 510 33 261 510 minecraft:black_concrete
fill 35 256 530 35 256 532 minecraft:black_wool
fill 36 256 552 36 262 552 minecraft:black_concrete
fill 39 256 552 39 307 552 minecraft:black_concrete
setblock 42 256 519 minecraft:light_blue_stained_glass
setblock 42 256 534 minecraft:light_blue_stained_glass
fill 0 257 549 0 285 549 minecraft:black_concrete
fill 6 257 510 6 307 510 minecraft:black_concrete
fill 8 257 527 15 257 527 minecraft:black_wool
fill 8 257 530 15 258 532 minecraft:black_wool
fill 8 257 535 15 257 535 minecraft:black_wool
fill 9 257 526 33 258 526 minecraft:black_wool
fill 9 257 536 33 258 536 minecraft:black_wool
fill 10 257 524 32 258 524 minecraft:black_wool
fill 10 257 538 32 258 538 minecraft:black_wool
fill 15 257 519 27 257 519 minecraft:black_wool
fill 15 257 543 27 257 543 minecraft:black_wool
fill 17 257 518 25 257 518 minecraft:black_wool
fill 17 257 544 25 257 544 minecraft:black_wool
setblock 19 257 552 minecraft:sea_lantern
fill 20 257 552 20 302 552 minecraft:black_concrete
setblock 41 257 510 minecraft:sea_lantern
fill 42 257 510 42 307 510 minecraft:black_concrete
fill 42 257 519 42 307 519 minecraft:black_concrete
fill 42 257 534 42 299 534 minecraft:black_concrete
setblock 42 257 546 minecraft:light_blue_stained_glass
setblock 42 257 551 minecraft:light_blue_stained_glass
schedule function dropper:buildpart/120_2 1t
