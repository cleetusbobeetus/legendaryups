fill 120 152 317 121 153 317 minecraft:white_concrete
fill 121 152 285 121 160 285 minecraft:yellow_concrete
fill 122 152 275 123 153 275 minecraft:red_concrete
fill 122 152 276 122 153 276 minecraft:yellow_concrete
fill 122 152 284 122 160 284 minecraft:yellow_concrete
fill 122 152 317 123 153 317 minecraft:red_concrete
fill 123 152 277 123 153 278 minecraft:yellow_concrete
fill 123 152 282 123 160 283 minecraft:yellow_concrete
fill 124 152 275 125 153 275 minecraft:white_concrete
fill 124 152 317 125 153 317 minecraft:white_concrete
fill 126 152 275 127 153 275 minecraft:red_concrete
fill 126 152 317 127 153 317 minecraft:red_concrete
fill 128 152 275 129 153 275 minecraft:white_concrete
fill 128 152 317 129 153 317 minecraft:white_concrete
fill 129 152 294 129 153 294 minecraft:yellow_wool
fill 130 152 275 131 153 275 minecraft:red_concrete
fill 130 152 317 131 153 317 minecraft:red_concrete
fill 132 152 275 133 153 275 minecraft:white_concrete
fill 132 152 317 133 153 317 minecraft:white_concrete
fill 134 152 275 135 153 275 minecraft:red_concrete
fill 134 152 317 135 153 317 minecraft:red_concrete
fill 136 152 276 136 153 276 minecraft:red_concrete
fill 136 152 277 136 153 278 minecraft:white_concrete
fill 136 152 279 136 153 280 minecraft:red_concrete
fill 136 152 281 136 153 282 minecraft:white_concrete
fill 136 152 283 136 153 284 minecraft:red_concrete
fill 136 152 285 136 153 286 minecraft:white_concrete
fill 136 152 287 136 153 288 minecraft:red_concrete
fill 136 152 289 136 153 290 minecraft:white_concrete
fill 136 152 291 136 153 292 minecraft:red_concrete
fill 136 152 293 136 153 294 minecraft:white_concrete
fill 136 152 295 136 153 296 minecraft:red_concrete
fill 136 152 297 136 153 298 minecraft:white_concrete
fill 136 152 299 136 153 300 minecraft:red_concrete
fill 136 152 301 136 153 302 minecraft:white_concrete
fill 136 152 303 136 153 304 minecraft:red_concrete
fill 136 152 305 136 153 306 minecraft:white_concrete
fill 136 152 307 136 153 308 minecraft:red_concrete
fill 136 152 309 136 153 310 minecraft:white_concrete
fill 136 152 311 136 153 312 minecraft:red_concrete
fill 136 152 313 136 153 314 minecraft:white_concrete
fill 136 152 315 136 153 316 minecraft:red_concrete
fill 136 152 317 136 153 317 minecraft:white_concrete
setblock 97 153 278 minecraft:light[level=12]
setblock 97 153 285 minecraft:light[level=12]
setblock 97 153 292 minecraft:light[level=12]
setblock 97 153 299 minecraft:light[level=12]
setblock 97 153 306 minecraft:light[level=12]
setblock 97 153 310 minecraft:brown_terracotta
setblock 97 153 313 minecraft:brown_terracotta
fill 98 153 314 99 153 314 minecraft:brown_terracotta
setblock 99 153 309 minecraft:brown_terracotta
setblock 100 153 310 minecraft:brown_terracotta
setblock 100 153 313 minecraft:brown_terracotta
fill 101 153 311 101 153 312 minecraft:brown_terracotta
setblock 104 153 278 minecraft:light[level=12]
setblock 104 153 285 minecraft:light[level=12]
setblock 104 153 292 minecraft:light[level=12]
setblock 104 153 299 minecraft:light[level=12]
setblock 104 153 306 minecraft:light[level=12]
setblock 104 153 313 minecraft:light[level=12]
fill 110 153 282 110 159 282 minecraft:yellow_concrete
setblock 111 153 276 minecraft:yellow_concrete
fill 111 153 284 111 159 284 minecraft:yellow_concrete
setblock 111 153 285 minecraft:light[level=12]
setblock 111 153 292 minecraft:light[level=12]
setblock 111 153 299 minecraft:light[level=12]
setblock 111 153 306 minecraft:light[level=12]
setblock 111 153 313 minecraft:light[level=12]
fill 112 153 285 112 159 285 minecraft:yellow_concrete
fill 113 153 286 113 159 286 minecraft:yellow_concrete
fill 115 153 287 119 159 287 minecraft:yellow_concrete
setblock 118 153 292 minecraft:light[level=12]
setblock 118 153 299 minecraft:light[level=12]
setblock 118 153 306 minecraft:light[level=12]
setblock 118 153 313 minecraft:light[level=12]
fill 121 153 286 121 159 286 minecraft:yellow_concrete
fill 122 153 285 122 159 285 minecraft:yellow_concrete
setblock 123 153 276 minecraft:yellow_concrete
fill 123 153 284 123 159 284 minecraft:yellow_concrete
fill 124 153 278 124 159 282 minecraft:yellow_concrete
setblock 125 153 278 minecraft:light[level=12]
setblock 125 153 285 minecraft:light[level=12]
setblock 125 153 292 minecraft:light[level=12]
setblock 125 153 299 minecraft:light[level=12]
setblock 125 153 306 minecraft:light[level=12]
setblock 125 153 313 minecraft:light[level=12]
setblock 132 153 278 minecraft:light[level=12]
setblock 132 153 292 minecraft:light[level=12]
setblock 132 153 299 minecraft:light[level=12]
setblock 132 153 306 minecraft:light[level=12]
setblock 132 153 313 minecraft:light[level=12]
fill 94 154 275 94 155 276 minecraft:white_concrete
fill 94 154 277 94 155 278 minecraft:red_concrete
fill 94 154 279 94 155 280 minecraft:white_concrete
fill 94 154 281 94 155 282 minecraft:red_concrete
fill 94 154 283 94 155 284 minecraft:white_concrete
fill 94 154 285 94 155 286 minecraft:red_concrete
fill 94 154 287 94 155 288 minecraft:white_concrete
fill 94 154 289 94 155 290 minecraft:red_concrete
fill 94 154 291 94 155 292 minecraft:white_concrete
fill 94 154 293 94 155 294 minecraft:red_concrete
fill 94 154 295 94 155 296 minecraft:white_concrete
fill 94 154 297 94 155 298 minecraft:red_concrete
fill 94 154 299 94 155 300 minecraft:white_concrete
fill 94 154 301 94 155 302 minecraft:red_concrete
fill 94 154 303 94 155 304 minecraft:white_concrete
fill 94 154 305 94 155 306 minecraft:red_concrete
fill 94 154 307 94 155 308 minecraft:white_concrete
fill 94 154 309 94 155 310 minecraft:red_concrete
fill 94 154 311 94 155 312 minecraft:white_concrete
fill 94 154 313 94 155 314 minecraft:red_concrete
fill 94 154 315 94 155 316 minecraft:white_concrete
fill 95 154 275 95 155 275 minecraft:white_concrete
fill 95 154 276 95 155 281 minecraft:red_terracotta
fill 95 154 284 96 154 289 minecraft:red_terracotta
fill 95 154 292 96 154 297 minecraft:red_terracotta
fill 95 154 300 96 154 305 minecraft:red_terracotta
fill 95 154 308 96 154 313 minecraft:red_terracotta
fill 95 154 316 100 155 316 minecraft:red_terracotta
fill 95 154 317 95 155 317 minecraft:white_concrete
fill 96 154 275 97 155 275 minecraft:red_concrete
fill 96 154 277 96 154 283 minecraft:red_terracotta
fill 96 154 290 96 154 291 minecraft:red_terracotta
fill 96 154 298 96 154 299 minecraft:red_terracotta
fill 96 154 306 96 154 307 minecraft:red_terracotta
fill 96 154 314 96 154 315 minecraft:red_terracotta
fill 96 154 317 97 155 317 minecraft:red_concrete
fill 97 154 277 134 154 277 minecraft:red_terracotta
fill 97 154 315 135 154 315 minecraft:red_terracotta
fill 98 154 275 99 155 275 minecraft:white_concrete
fill 98 154 276 103 155 276 minecraft:red_terracotta
fill 98 154 317 99 155 317 minecraft:white_concrete
fill 100 154 275 101 155 275 minecraft:red_concrete
fill 100 154 317 101 155 317 minecraft:red_concrete
fill 102 154 275 103 155 275 minecraft:white_concrete
fill 102 154 317 103 155 317 minecraft:white_concrete
fill 103 154 316 108 155 316 minecraft:red_terracotta
fill 104 154 275 105 155 275 minecraft:red_concrete
fill 104 154 317 105 155 317 minecraft:red_concrete
fill 106 154 275 107 155 275 minecraft:white_concrete
fill 106 154 276 111 155 276 minecraft:red_terracotta
fill 106 154 317 107 155 317 minecraft:white_concrete
fill 108 154 275 109 155 275 minecraft:red_concrete
fill 108 154 317 109 155 317 minecraft:red_concrete
fill 110 154 275 111 155 275 minecraft:white_concrete
fill 110 154 283 110 158 283 minecraft:yellow_concrete
fill 110 154 317 111 155 317 minecraft:white_concrete
fill 111 154 316 116 155 316 minecraft:red_terracotta
fill 112 154 275 113 155 275 minecraft:red_concrete
fill 112 154 317 113 155 317 minecraft:red_concrete
fill 114 154 275 115 155 275 minecraft:white_concrete
fill 114 154 276 119 155 276 minecraft:red_terracotta
fill 114 154 287 114 158 287 minecraft:yellow_concrete
fill 114 154 317 115 155 317 minecraft:white_concrete
fill 116 154 275 117 155 275 minecraft:red_concrete
fill 116 154 317 117 155 317 minecraft:red_concrete
fill 118 154 275 119 155 275 minecraft:white_concrete
fill 118 154 317 119 155 317 minecraft:white_concrete
fill 119 154 316 124 155 316 minecraft:red_terracotta
fill 120 154 275 121 155 275 minecraft:red_concrete
fill 120 154 287 120 158 287 minecraft:yellow_concrete
fill 120 154 317 121 155 317 minecraft:red_concrete
fill 122 154 275 123 155 275 minecraft:white_concrete
fill 122 154 276 127 155 276 minecraft:red_terracotta
fill 122 154 278 123 160 278 minecraft:yellow_concrete
fill 122 154 317 123 155 317 minecraft:white_concrete
fill 124 154 275 125 155 275 minecraft:red_concrete
fill 124 154 283 124 158 283 minecraft:yellow_concrete
fill 124 154 317 125 155 317 minecraft:red_concrete
fill 126 154 275 127 155 275 minecraft:white_concrete
fill 126 154 317 127 155 317 minecraft:white_concrete
fill 127 154 316 132 155 316 minecraft:red_terracotta
fill 128 154 275 129 155 275 minecraft:red_concrete
fill 128 154 317 129 155 317 minecraft:red_concrete
fill 130 154 275 131 155 275 minecraft:white_concrete
fill 130 154 276 135 155 276 minecraft:red_terracotta
fill 130 154 317 131 155 317 minecraft:white_concrete
fill 132 154 275 133 155 275 minecraft:red_concrete
fill 132 154 317 133 155 317 minecraft:red_concrete
fill 134 154 275 135 155 275 minecraft:white_concrete
fill 134 154 278 134 154 314 minecraft:red_terracotta
fill 134 154 317 135 155 317 minecraft:white_concrete
fill 135 154 279 135 155 284 minecraft:red_terracotta
fill 135 154 287 135 155 292 minecraft:red_terracotta
fill 135 154 295 135 155 300 minecraft:red_terracotta
fill 135 154 303 135 155 308 minecraft:red_terracotta
fill 135 154 311 135 155 314 minecraft:red_terracotta
fill 135 154 316 135 155 316 minecraft:red_terracotta
fill 136 154 276 136 155 276 minecraft:white_concrete
fill 136 154 277 136 155 278 minecraft:red_concrete
fill 136 154 279 136 155 280 minecraft:white_concrete
fill 136 154 281 136 155 282 minecraft:red_concrete
fill 136 154 283 136 155 284 minecraft:white_concrete
fill 136 154 285 136 155 286 minecraft:red_concrete
fill 136 154 287 136 155 288 minecraft:white_concrete
fill 136 154 289 136 155 290 minecraft:red_concrete
fill 136 154 291 136 155 292 minecraft:white_concrete
fill 136 154 293 136 155 294 minecraft:red_concrete
fill 136 154 295 136 155 296 minecraft:white_concrete
fill 136 154 297 136 155 298 minecraft:red_concrete
fill 136 154 299 136 155 300 minecraft:white_concrete
fill 136 154 301 136 155 302 minecraft:red_concrete
fill 136 154 303 136 155 304 minecraft:white_concrete
fill 136 154 305 136 155 306 minecraft:red_concrete
fill 136 154 307 136 155 308 minecraft:white_concrete
fill 136 154 309 136 155 310 minecraft:red_concrete
fill 136 154 311 136 155 312 minecraft:white_concrete
fill 136 154 313 136 155 314 minecraft:red_concrete
fill 136 154 315 136 155 316 minecraft:white_concrete
fill 136 154 317 136 155 317 minecraft:red_concrete
fill 95 155 284 95 155 289 minecraft:red_terracotta
fill 95 155 292 95 155 297 minecraft:red_terracotta
fill 95 155 300 95 155 305 minecraft:red_terracotta
fill 95 155 308 95 155 313 minecraft:red_terracotta
fill 110 155 277 124 158 277 minecraft:yellow_concrete
fill 111 155 285 111 157 285 minecraft:yellow_concrete
fill 112 155 286 112 157 286 minecraft:yellow_concrete
fill 122 155 286 122 157 286 minecraft:yellow_concrete
fill 123 155 285 123 157 285 minecraft:yellow_concrete
fill 129 155 283 129 155 285 minecraft:red_terracotta
fill 130 155 282 132 155 282 minecraft:red_terracotta
fill 130 155 286 132 155 286 minecraft:red_terracotta
fill 133 155 283 133 155 285 minecraft:red_terracotta
setblock 135 155 315 minecraft:red_terracotta
fill 94 156 275 94 157 276 minecraft:red_concrete
fill 94 156 277 94 157 278 minecraft:white_concrete
fill 94 156 279 94 157 280 minecraft:red_concrete
fill 94 156 281 94 157 282 minecraft:white_concrete
fill 94 156 283 94 157 284 minecraft:red_concrete
fill 94 156 285 94 157 286 minecraft:white_concrete
fill 94 156 287 94 157 288 minecraft:red_concrete
fill 94 156 289 94 157 290 minecraft:white_concrete
fill 94 156 291 94 157 292 minecraft:red_concrete
fill 94 156 293 94 157 294 minecraft:white_concrete
fill 94 156 295 94 157 296 minecraft:red_concrete
fill 94 156 297 94 157 298 minecraft:white_concrete
fill 94 156 299 94 157 300 minecraft:red_concrete
fill 94 156 301 94 157 302 minecraft:white_concrete
fill 94 156 303 94 157 304 minecraft:red_concrete
fill 94 156 305 94 157 306 minecraft:white_concrete
fill 94 156 307 94 157 308 minecraft:red_concrete
fill 94 156 309 94 157 310 minecraft:white_concrete
fill 94 156 311 94 157 312 minecraft:red_concrete
fill 94 156 313 94 157 314 minecraft:white_concrete
fill 94 156 315 94 157 316 minecraft:red_concrete
fill 95 156 275 95 157 275 minecraft:red_concrete
fill 95 156 317 95 157 317 minecraft:red_concrete
fill 96 156 275 97 157 275 minecraft:white_concrete
fill 96 156 317 97 157 317 minecraft:white_concrete
fill 98 156 275 99 157 275 minecraft:red_concrete
fill 98 156 317 99 157 317 minecraft:red_concrete
fill 100 156 275 101 157 275 minecraft:white_concrete
fill 100 156 317 101 157 317 minecraft:white_concrete
fill 102 156 275 103 157 275 minecraft:red_concrete
fill 102 156 317 103 157 317 minecraft:red_concrete
fill 104 156 275 105 157 275 minecraft:white_concrete
fill 104 156 317 105 157 317 minecraft:white_concrete
fill 106 156 275 107 157 275 minecraft:red_concrete
fill 106 156 278 107 156 282 minecraft:shroomlight
fill 106 156 317 107 157 317 minecraft:red_concrete
fill 107 156 276 107 156 277 minecraft:shroomlight
fill 107 156 283 107 156 285 minecraft:shroomlight
fill 108 156 275 109 157 275 minecraft:white_concrete
setblock 108 156 276 minecraft:shroomlight
fill 108 156 284 108 156 286 minecraft:shroomlight
fill 108 156 317 109 157 317 minecraft:white_concrete
setblock 109 156 280 minecraft:yellow_concrete
fill 109 156 286 109 156 287 minecraft:shroomlight
fill 110 156 275 111 157 275 minecraft:red_concrete
fill 110 156 287 110 156 288 minecraft:shroomlight
fill 110 156 304 110 157 304 minecraft:green_concrete
fill 110 156 317 111 157 317 minecraft:red_concrete
fill 111 156 276 111 159 276 minecraft:yellow_concrete
fill 111 156 288 111 156 289 minecraft:shroomlight
fill 112 156 275 113 157 275 minecraft:white_concrete
fill 112 156 289 113 156 290 minecraft:shroomlight
fill 112 156 317 113 157 317 minecraft:white_concrete
fill 114 156 275 115 157 275 minecraft:red_concrete
fill 114 156 276 119 162 276 minecraft:yellow_concrete
fill 114 156 290 122 156 290 minecraft:shroomlight
fill 114 156 317 115 157 317 minecraft:red_concrete
fill 115 156 291 119 156 291 minecraft:shroomlight
fill 116 156 275 117 157 275 minecraft:white_concrete
fill 116 156 317 117 157 317 minecraft:white_concrete
setblock 117 156 288 minecraft:yellow_concrete
fill 118 156 275 119 157 275 minecraft:red_concrete
fill 118 156 317 119 157 317 minecraft:red_concrete
fill 120 156 275 121 157 275 minecraft:white_concrete
fill 120 156 317 121 157 317 minecraft:white_concrete
fill 121 156 289 123 156 289 minecraft:shroomlight
fill 122 156 275 123 157 275 minecraft:red_concrete
fill 122 156 276 123 159 276 minecraft:yellow_concrete
fill 122 156 317 123 157 317 minecraft:red_concrete
fill 123 156 288 124 156 288 minecraft:shroomlight
fill 124 156 275 125 157 275 minecraft:white_concrete
fill 124 156 287 125 156 287 minecraft:shroomlight
fill 124 156 317 125 157 317 minecraft:white_concrete
setblock 125 156 280 minecraft:yellow_concrete
fill 125 156 286 126 156 286 minecraft:shroomlight
fill 126 156 275 127 157 275 minecraft:red_concrete
fill 126 156 276 127 156 276 minecraft:shroomlight
fill 126 156 284 127 156 285 minecraft:shroomlight
fill 126 156 317 127 157 317 minecraft:red_concrete
fill 127 156 277 127 156 283 minecraft:shroomlight
fill 128 156 275 129 157 275 minecraft:white_concrete
fill 128 156 278 128 156 282 minecraft:shroomlight
fill 128 156 317 129 157 317 minecraft:white_concrete
fill 130 156 275 131 157 275 minecraft:red_concrete
fill 130 156 317 131 157 317 minecraft:red_concrete
fill 132 156 275 133 157 275 minecraft:white_concrete
fill 132 156 317 133 157 317 minecraft:white_concrete
fill 134 156 275 135 157 275 minecraft:red_concrete
fill 134 156 317 135 157 317 minecraft:red_concrete
fill 136 156 276 136 157 276 minecraft:red_concrete
fill 136 156 277 136 157 278 minecraft:white_concrete
fill 136 156 279 136 157 280 minecraft:red_concrete
fill 136 156 281 136 157 282 minecraft:white_concrete
fill 136 156 283 136 157 284 minecraft:red_concrete
fill 136 156 285 136 157 286 minecraft:white_concrete
fill 136 156 287 136 157 288 minecraft:red_concrete
fill 136 156 289 136 157 290 minecraft:white_concrete
fill 136 156 291 136 157 292 minecraft:red_concrete
fill 136 156 293 136 157 294 minecraft:white_concrete
fill 136 156 295 136 157 296 minecraft:red_concrete
fill 136 156 297 136 157 298 minecraft:white_concrete
fill 136 156 299 136 157 300 minecraft:red_concrete
fill 136 156 301 136 157 302 minecraft:white_concrete
fill 136 156 303 136 157 304 minecraft:red_concrete
fill 136 156 305 136 157 306 minecraft:white_concrete
fill 136 156 307 136 157 308 minecraft:red_concrete
fill 136 156 309 136 157 310 minecraft:white_concrete
fill 136 156 311 136 157 312 minecraft:red_concrete
fill 136 156 313 136 157 314 minecraft:white_concrete
fill 136 156 315 136 157 316 minecraft:red_concrete
fill 136 156 317 136 157 317 minecraft:white_concrete
setblock 97 157 278 minecraft:light[level=15]
setblock 97 157 286 minecraft:light[level=15]
setblock 97 157 294 minecraft:light[level=15]
setblock 97 157 302 minecraft:light[level=15]
setblock 97 157 310 minecraft:light[level=15]
setblock 105 157 278 minecraft:light[level=15]
setblock 105 157 286 minecraft:light[level=15]
setblock 105 157 294 minecraft:light[level=15]
setblock 105 157 302 minecraft:light[level=15]
setblock 105 157 310 minecraft:light[level=15]
setblock 113 157 294 minecraft:light[level=15]
setblock 113 157 302 minecraft:light[level=15]
setblock 113 157 310 minecraft:light[level=15]
setblock 121 157 294 minecraft:light[level=15]
setblock 121 157 302 minecraft:light[level=15]
setblock 121 157 310 minecraft:light[level=15]
setblock 129 157 278 minecraft:light[level=15]
setblock 129 157 286 minecraft:light[level=15]
setblock 129 157 294 minecraft:light[level=15]
setblock 129 157 302 minecraft:light[level=15]
setblock 129 157 310 minecraft:light[level=15]
fill 94 158 275 94 159 276 minecraft:white_concrete
fill 94 158 277 94 159 278 minecraft:red_concrete
fill 94 158 279 94 159 279 minecraft:white_concrete
fill 94 158 280 94 163 280 minecraft:shroomlight
fill 94 158 281 94 159 282 minecraft:red_concrete
fill 94 158 283 94 159 284 minecraft:white_concrete
fill 94 158 285 94 159 286 minecraft:red_concrete
fill 94 158 287 94 159 287 minecraft:white_concrete
fill 94 158 288 94 163 288 minecraft:shroomlight
fill 94 158 289 94 159 290 minecraft:red_concrete
fill 94 158 291 94 159 292 minecraft:white_concrete
fill 94 158 293 94 159 294 minecraft:red_concrete
fill 94 158 295 94 159 295 minecraft:white_concrete
fill 94 158 296 94 163 296 minecraft:shroomlight
fill 94 158 297 94 159 298 minecraft:red_concrete
fill 94 158 299 94 159 300 minecraft:white_concrete
fill 94 158 301 94 159 302 minecraft:red_concrete
fill 94 158 303 94 159 303 minecraft:white_concrete
fill 94 158 304 94 163 304 minecraft:shroomlight
fill 94 158 305 94 159 306 minecraft:red_concrete
fill 94 158 307 94 159 308 minecraft:white_concrete
fill 94 158 309 94 159 310 minecraft:red_concrete
fill 94 158 311 94 159 311 minecraft:white_concrete
fill 94 158 312 94 163 312 minecraft:shroomlight
fill 94 158 313 94 159 314 minecraft:red_concrete
fill 94 158 315 94 159 316 minecraft:white_concrete
fill 95 158 275 95 159 275 minecraft:white_concrete
fill 95 158 317 95 159 317 minecraft:white_concrete
fill 96 158 275 97 159 275 minecraft:red_concrete
fill 96 158 317 96 159 317 minecraft:red_concrete
fill 97 158 317 97 163 317 minecraft:shroomlight
fill 98 158 275 99 159 275 minecraft:white_concrete
fill 98 158 317 99 159 317 minecraft:white_concrete
fill 100 158 275 100 159 275 minecraft:red_concrete
fill 100 158 317 101 159 317 minecraft:red_concrete
fill 101 158 275 101 163 275 minecraft:shroomlight
fill 102 158 275 103 159 275 minecraft:white_concrete
fill 102 158 317 103 159 317 minecraft:white_concrete
fill 104 158 275 105 159 275 minecraft:red_concrete
fill 104 158 317 104 159 317 minecraft:red_concrete
fill 105 158 317 105 163 317 minecraft:shroomlight
fill 106 158 275 107 159 275 minecraft:white_concrete
fill 106 158 317 107 159 317 minecraft:white_concrete
fill 108 158 275 108 159 275 minecraft:red_concrete
fill 108 158 317 109 159 317 minecraft:red_concrete
fill 109 158 275 109 163 275 minecraft:shroomlight
fill 110 158 275 111 159 275 minecraft:white_concrete
fill 110 158 317 111 159 317 minecraft:white_concrete
fill 112 158 275 113 159 275 minecraft:red_concrete
fill 112 158 317 112 159 317 minecraft:red_concrete
fill 113 158 317 113 163 317 minecraft:shroomlight
fill 114 158 275 115 159 275 minecraft:white_concrete
fill 114 158 317 115 159 317 minecraft:white_concrete
fill 116 158 275 116 159 275 minecraft:red_concrete
fill 116 158 317 117 159 317 minecraft:red_concrete
fill 117 158 275 117 163 275 minecraft:shroomlight
fill 118 158 275 119 159 275 minecraft:white_concrete
fill 118 158 317 119 159 317 minecraft:white_concrete
fill 120 158 275 121 159 275 minecraft:red_concrete
fill 120 158 317 120 159 317 minecraft:red_concrete
fill 121 158 317 121 163 317 minecraft:shroomlight
fill 122 158 275 123 159 275 minecraft:white_concrete
fill 122 158 317 123 159 317 minecraft:white_concrete
fill 124 158 275 124 159 275 minecraft:red_concrete
fill 124 158 317 125 159 317 minecraft:red_concrete
fill 125 158 275 125 163 275 minecraft:shroomlight
fill 126 158 275 127 159 275 minecraft:white_concrete
fill 126 158 317 127 159 317 minecraft:white_concrete
fill 128 158 275 129 159 275 minecraft:red_concrete
fill 128 158 317 128 159 317 minecraft:red_concrete
fill 129 158 317 129 163 317 minecraft:shroomlight
fill 130 158 275 131 159 275 minecraft:white_concrete
fill 130 158 317 131 159 317 minecraft:white_concrete
fill 132 158 275 132 159 275 minecraft:red_concrete
fill 132 158 317 133 159 317 minecraft:red_concrete
fill 133 158 275 133 163 275 minecraft:shroomlight
fill 134 158 275 135 159 275 minecraft:white_concrete
fill 134 158 317 135 159 317 minecraft:white_concrete
fill 136 158 276 136 159 276 minecraft:white_concrete
fill 136 158 277 136 159 278 minecraft:red_concrete
fill 136 158 279 136 159 279 minecraft:white_concrete
fill 136 158 280 136 163 280 minecraft:shroomlight
fill 136 158 281 136 159 282 minecraft:red_concrete
fill 136 158 283 136 159 284 minecraft:white_concrete
fill 136 158 285 136 159 286 minecraft:red_concrete
fill 136 158 287 136 159 287 minecraft:white_concrete
fill 136 158 288 136 163 288 minecraft:shroomlight
fill 136 158 289 136 159 290 minecraft:red_concrete
fill 136 158 291 136 159 292 minecraft:white_concrete
fill 136 158 293 136 159 294 minecraft:red_concrete
fill 136 158 295 136 159 295 minecraft:white_concrete
fill 136 158 296 136 163 296 minecraft:shroomlight
fill 136 158 297 136 159 298 minecraft:red_concrete
fill 136 158 299 136 159 300 minecraft:white_concrete
fill 136 158 301 136 159 302 minecraft:red_concrete
fill 136 158 303 136 159 303 minecraft:white_concrete
fill 136 158 304 136 163 304 minecraft:shroomlight
fill 136 158 305 136 159 306 minecraft:red_concrete
fill 136 158 307 136 159 308 minecraft:white_concrete
fill 136 158 309 136 159 310 minecraft:red_concrete
fill 136 158 311 136 159 311 minecraft:white_concrete
fill 136 158 312 136 163 312 minecraft:shroomlight
fill 136 158 313 136 159 314 minecraft:red_concrete
fill 136 158 315 136 159 316 minecraft:white_concrete
fill 136 158 317 136 159 317 minecraft:red_concrete
setblock 97 159 278 minecraft:light[level=12]
setblock 97 159 285 minecraft:light[level=12]
setblock 97 159 292 minecraft:light[level=12]
setblock 97 159 299 minecraft:light[level=12]
setblock 97 159 306 minecraft:light[level=12]
setblock 97 159 313 minecraft:light[level=12]
setblock 104 159 278 minecraft:light[level=12]
setblock 104 159 285 minecraft:light[level=12]
setblock 104 159 292 minecraft:light[level=12]
setblock 104 159 299 minecraft:light[level=12]
setblock 104 159 306 minecraft:light[level=12]
setblock 104 159 313 minecraft:light[level=12]
fill 111 159 277 123 160 277 minecraft:yellow_concrete
setblock 111 159 285 minecraft:light[level=12]
setblock 111 159 292 minecraft:light[level=12]
setblock 111 159 299 minecraft:light[level=12]
setblock 111 159 306 minecraft:light[level=12]
setblock 111 159 313 minecraft:light[level=12]
setblock 118 159 292 minecraft:light[level=12]
setblock 118 159 299 minecraft:light[level=12]
setblock 118 159 306 minecraft:light[level=12]
setblock 118 159 313 minecraft:light[level=12]
setblock 125 159 278 minecraft:light[level=12]
setblock 125 159 285 minecraft:light[level=12]
setblock 125 159 292 minecraft:light[level=12]
setblock 125 159 299 minecraft:light[level=12]
setblock 125 159 306 minecraft:light[level=12]
setblock 125 159 313 minecraft:light[level=12]
setblock 132 159 278 minecraft:light[level=12]
setblock 132 159 292 minecraft:light[level=12]
setblock 132 159 299 minecraft:light[level=12]
setblock 132 159 306 minecraft:light[level=12]
setblock 132 159 313 minecraft:light[level=12]
fill 94 160 275 94 161 276 minecraft:red_concrete
fill 94 160 277 94 161 278 minecraft:white_concrete
fill 94 160 279 94 161 279 minecraft:red_concrete
fill 94 160 281 94 161 282 minecraft:white_concrete
fill 94 160 283 94 161 284 minecraft:red_concrete
fill 94 160 285 94 161 286 minecraft:white_concrete
fill 94 160 287 94 161 287 minecraft:red_concrete
fill 94 160 289 94 161 290 minecraft:white_concrete
fill 94 160 291 94 161 292 minecraft:red_concrete
fill 94 160 293 94 161 294 minecraft:white_concrete
fill 94 160 295 94 161 295 minecraft:red_concrete
fill 94 160 297 94 161 298 minecraft:white_concrete
fill 94 160 299 94 161 300 minecraft:red_concrete
fill 94 160 301 94 161 302 minecraft:white_concrete
fill 94 160 303 94 161 303 minecraft:red_concrete
fill 94 160 305 94 161 306 minecraft:white_concrete
fill 94 160 307 94 161 308 minecraft:red_concrete
fill 94 160 309 94 161 310 minecraft:white_concrete
fill 94 160 311 94 161 311 minecraft:red_concrete
fill 94 160 313 94 161 314 minecraft:white_concrete
fill 94 160 315 94 161 316 minecraft:red_concrete
fill 95 160 275 95 161 275 minecraft:red_concrete
fill 95 160 317 95 161 317 minecraft:red_concrete
fill 96 160 275 97 161 275 minecraft:white_concrete
fill 96 160 317 96 161 317 minecraft:white_concrete
fill 98 160 275 99 161 275 minecraft:red_concrete
fill 98 160 317 99 161 317 minecraft:red_concrete
fill 100 160 275 100 161 275 minecraft:white_concrete
fill 100 160 317 101 161 317 minecraft:white_concrete
fill 102 160 275 103 161 275 minecraft:red_concrete
fill 102 160 317 103 161 317 minecraft:red_concrete
fill 104 160 275 105 161 275 minecraft:white_concrete
fill 104 160 317 104 161 317 minecraft:white_concrete
fill 106 160 275 107 161 275 minecraft:red_concrete
fill 106 160 317 107 161 317 minecraft:red_concrete
fill 108 160 275 108 161 275 minecraft:white_concrete
fill 108 160 317 109 161 317 minecraft:white_concrete
fill 110 160 275 111 161 275 minecraft:red_concrete
fill 110 160 317 111 161 317 minecraft:red_concrete
fill 112 160 275 113 161 275 minecraft:white_concrete
fill 112 160 317 112 161 317 minecraft:white_concrete
fill 114 160 275 115 161 275 minecraft:red_concrete
fill 114 160 317 115 161 317 minecraft:red_concrete
fill 116 160 275 116 161 275 minecraft:white_concrete
fill 116 160 317 117 161 317 minecraft:white_concrete
fill 118 160 275 119 161 275 minecraft:red_concrete
fill 118 160 317 119 161 317 minecraft:red_concrete
fill 120 160 275 121 161 275 minecraft:white_concrete
fill 120 160 317 120 161 317 minecraft:white_concrete
fill 122 160 275 123 161 275 minecraft:red_concrete
setblock 122 160 276 minecraft:yellow_concrete
fill 122 160 317 123 161 317 minecraft:red_concrete
fill 124 160 275 124 161 275 minecraft:white_concrete
fill 124 160 317 125 161 317 minecraft:white_concrete
fill 126 160 275 127 161 275 minecraft:red_concrete
fill 126 160 317 127 161 317 minecraft:red_concrete
fill 128 160 275 129 161 275 minecraft:white_concrete
fill 128 160 317 128 161 317 minecraft:white_concrete
fill 130 160 275 131 161 275 minecraft:red_concrete
fill 130 160 317 131 161 317 minecraft:red_concrete
fill 132 160 275 132 161 275 minecraft:white_concrete
fill 132 160 317 133 161 317 minecraft:white_concrete
fill 134 160 275 135 161 275 minecraft:red_concrete
fill 134 160 317 135 161 317 minecraft:red_concrete
fill 136 160 276 136 161 276 minecraft:red_concrete
fill 136 160 277 136 161 278 minecraft:white_concrete
fill 136 160 279 136 161 279 minecraft:red_concrete
fill 136 160 281 136 161 282 minecraft:white_concrete
fill 136 160 283 136 161 284 minecraft:red_concrete
fill 136 160 285 136 161 286 minecraft:white_concrete
fill 136 160 287 136 161 287 minecraft:red_concrete
fill 136 160 289 136 161 290 minecraft:white_concrete
fill 136 160 291 136 161 292 minecraft:red_concrete
fill 136 160 293 136 161 294 minecraft:white_concrete
fill 136 160 295 136 161 295 minecraft:red_concrete
fill 136 160 297 136 161 298 minecraft:white_concrete
fill 136 160 299 136 161 300 minecraft:red_concrete
fill 136 160 301 136 161 302 minecraft:white_concrete
fill 136 160 303 136 161 303 minecraft:red_concrete
fill 136 160 305 136 161 306 minecraft:white_concrete
fill 136 160 307 136 161 308 minecraft:red_concrete
fill 136 160 309 136 161 310 minecraft:white_concrete
fill 136 160 311 136 161 311 minecraft:red_concrete
fill 136 160 313 136 161 314 minecraft:white_concrete
fill 136 160 315 136 161 316 minecraft:red_concrete
fill 136 160 317 136 161 317 minecraft:white_concrete
setblock 97 161 310 minecraft:brown_terracotta
setblock 97 161 313 minecraft:brown_terracotta
fill 98 161 314 99 161 314 minecraft:brown_terracotta
setblock 99 161 309 minecraft:brown_terracotta
setblock 100 161 310 minecraft:brown_terracotta
setblock 100 161 313 minecraft:brown_terracotta
fill 101 161 311 101 161 312 minecraft:brown_terracotta
fill 112 161 277 122 161 277 minecraft:yellow_concrete
setblock 122 161 278 minecraft:yellow_concrete
fill 132 161 284 134 161 284 minecraft:black_concrete
setblock 133 161 282 minecraft:iron_block
setblock 133 161 283 minecraft:black_concrete
setblock 133 161 285 minecraft:black_concrete
setblock 133 161 286 minecraft:iron_block
setblock 134 161 283 minecraft:iron_block
setblock 134 161 285 minecraft:iron_block
setblock 135 161 284 minecraft:iron_block
fill 94 162 275 94 163 276 minecraft:white_concrete
fill 94 162 277 94 163 278 minecraft:red_concrete
fill 94 162 279 94 163 279 minecraft:white_concrete
fill 94 162 281 94 163 282 minecraft:red_concrete
fill 94 162 283 94 163 284 minecraft:white_concrete
fill 94 162 285 94 163 286 minecraft:red_concrete
fill 94 162 287 94 163 287 minecraft:white_concrete
fill 94 162 289 94 163 290 minecraft:red_concrete
fill 94 162 291 94 163 292 minecraft:white_concrete
fill 94 162 293 94 163 294 minecraft:red_concrete
fill 94 162 295 94 163 295 minecraft:white_concrete
fill 94 162 297 94 163 298 minecraft:red_concrete
fill 94 162 299 94 163 300 minecraft:white_concrete
fill 94 162 301 94 163 302 minecraft:red_concrete
fill 94 162 303 94 163 303 minecraft:white_concrete
fill 94 162 305 94 163 306 minecraft:red_concrete
fill 94 162 307 94 163 308 minecraft:white_concrete
fill 94 162 309 94 163 310 minecraft:red_concrete
fill 94 162 311 94 163 311 minecraft:white_concrete
fill 94 162 313 94 163 314 minecraft:red_concrete
fill 94 162 315 94 163 316 minecraft:white_concrete
fill 95 162 275 95 163 275 minecraft:white_concrete
fill 95 162 317 95 163 317 minecraft:white_concrete
fill 96 162 275 97 163 275 minecraft:red_concrete
fill 96 162 317 96 163 317 minecraft:red_concrete
fill 98 162 275 99 163 275 minecraft:white_concrete
fill 98 162 317 99 163 317 minecraft:white_concrete
fill 100 162 275 100 163 275 minecraft:red_concrete
fill 100 162 317 101 163 317 minecraft:red_concrete
fill 102 162 275 103 163 275 minecraft:white_concrete
fill 102 162 317 103 163 317 minecraft:white_concrete
fill 104 162 275 105 163 275 minecraft:red_concrete
fill 104 162 317 104 163 317 minecraft:red_concrete
fill 106 162 275 107 163 275 minecraft:white_concrete
fill 106 162 317 107 163 317 minecraft:white_concrete
fill 108 162 275 108 163 275 minecraft:red_concrete
fill 108 162 317 109 163 317 minecraft:red_concrete
fill 110 162 275 111 163 275 minecraft:white_concrete
fill 110 162 317 111 163 317 minecraft:white_concrete
fill 112 162 275 113 163 275 minecraft:red_concrete
fill 112 162 317 112 163 317 minecraft:red_concrete
fill 113 162 277 121 162 277 minecraft:yellow_concrete
fill 114 162 275 115 163 275 minecraft:white_concrete
fill 114 162 317 115 163 317 minecraft:white_concrete
fill 116 162 275 116 163 275 minecraft:red_concrete
fill 116 162 317 117 163 317 minecraft:red_concrete
fill 118 162 275 119 163 275 minecraft:white_concrete
fill 118 162 317 119 163 317 minecraft:white_concrete
fill 120 162 275 121 163 275 minecraft:red_concrete
fill 120 162 317 120 163 317 minecraft:red_concrete
fill 122 162 275 123 163 275 minecraft:white_concrete
fill 122 162 317 123 163 317 minecraft:white_concrete
fill 124 162 275 124 163 275 minecraft:red_concrete
fill 124 162 317 125 163 317 minecraft:red_concrete
fill 126 162 275 127 163 275 minecraft:white_concrete
fill 126 162 317 127 163 317 minecraft:white_concrete
fill 128 162 275 129 163 275 minecraft:red_concrete
fill 128 162 317 128 163 317 minecraft:red_concrete
fill 130 162 275 131 163 275 minecraft:white_concrete
fill 130 162 317 131 163 317 minecraft:white_concrete
fill 132 162 275 132 163 275 minecraft:red_concrete
fill 132 162 284 132 200 284 minecraft:iron_block
fill 132 162 317 133 163 317 minecraft:red_concrete
fill 134 162 275 135 163 275 minecraft:white_concrete
fill 134 162 317 135 163 317 minecraft:white_concrete
fill 136 162 276 136 163 276 minecraft:white_concrete
fill 136 162 277 136 163 278 minecraft:red_concrete
fill 136 162 279 136 163 279 minecraft:white_concrete
fill 136 162 281 136 163 282 minecraft:red_concrete
fill 136 162 283 136 163 284 minecraft:white_concrete
fill 136 162 285 136 163 286 minecraft:red_concrete
fill 136 162 287 136 163 287 minecraft:white_concrete
fill 136 162 289 136 163 290 minecraft:red_concrete
fill 136 162 291 136 163 292 minecraft:white_concrete
fill 136 162 293 136 163 294 minecraft:red_concrete
fill 136 162 295 136 163 295 minecraft:white_concrete
fill 136 162 297 136 163 298 minecraft:red_concrete
fill 136 162 299 136 163 300 minecraft:white_concrete
fill 136 162 301 136 163 302 minecraft:red_concrete
fill 136 162 303 136 163 303 minecraft:white_concrete
fill 136 162 305 136 163 306 minecraft:red_concrete
fill 136 162 307 136 163 308 minecraft:white_concrete
fill 136 162 309 136 163 310 minecraft:red_concrete
fill 136 162 311 136 163 311 minecraft:white_concrete
fill 136 162 313 136 163 314 minecraft:red_concrete
fill 136 162 315 136 163 316 minecraft:white_concrete
fill 136 162 317 136 163 317 minecraft:red_concrete
fill 115 163 277 119 163 277 minecraft:yellow_concrete
fill 129 163 283 129 163 285 minecraft:red_terracotta
fill 130 163 282 132 163 282 minecraft:red_terracotta
fill 130 163 286 132 163 286 minecraft:red_terracotta
fill 133 163 283 133 163 285 minecraft:red_terracotta
fill 94 164 275 94 165 276 minecraft:red_concrete
fill 94 164 277 94 165 278 minecraft:white_concrete
fill 94 164 279 94 165 280 minecraft:red_concrete
fill 94 164 281 94 165 282 minecraft:white_concrete
fill 94 164 283 94 165 284 minecraft:red_concrete
fill 94 164 285 94 165 286 minecraft:white_concrete
fill 94 164 287 94 165 288 minecraft:red_concrete
fill 94 164 289 94 165 290 minecraft:white_concrete
fill 94 164 291 94 165 292 minecraft:red_concrete
fill 94 164 293 94 165 294 minecraft:white_concrete
fill 94 164 295 94 165 296 minecraft:red_concrete
fill 94 164 297 94 165 298 minecraft:white_concrete
fill 94 164 299 94 165 300 minecraft:red_concrete
fill 94 164 301 94 165 302 minecraft:white_concrete
fill 94 164 303 94 165 304 minecraft:red_concrete
fill 94 164 305 94 165 306 minecraft:white_concrete
fill 94 164 307 94 165 308 minecraft:red_concrete
fill 94 164 309 94 165 310 minecraft:white_concrete
fill 94 164 311 94 165 312 minecraft:red_concrete
fill 94 164 313 94 165 314 minecraft:white_concrete
fill 94 164 315 94 165 316 minecraft:red_concrete
fill 95 164 275 95 165 275 minecraft:red_concrete
fill 95 164 317 95 165 317 minecraft:red_concrete
fill 96 164 275 97 165 275 minecraft:white_concrete
fill 96 164 317 97 165 317 minecraft:white_concrete
fill 98 164 275 99 165 275 minecraft:red_concrete
fill 98 164 317 99 165 317 minecraft:red_concrete
fill 100 164 275 101 165 275 minecraft:white_concrete
fill 100 164 317 101 165 317 minecraft:white_concrete
fill 102 164 275 103 165 275 minecraft:red_concrete
fill 102 164 317 103 165 317 minecraft:red_concrete
fill 104 164 275 105 165 275 minecraft:white_concrete
fill 104 164 317 105 165 317 minecraft:white_concrete
fill 106 164 275 107 165 275 minecraft:red_concrete
fill 106 164 317 107 165 317 minecraft:red_concrete
fill 108 164 275 109 165 275 minecraft:white_concrete
fill 108 164 317 109 165 317 minecraft:white_concrete
fill 110 164 275 111 165 275 minecraft:red_concrete
fill 110 164 317 111 165 317 minecraft:red_concrete
fill 112 164 275 113 165 275 minecraft:white_concrete
fill 112 164 317 113 165 317 minecraft:white_concrete
fill 114 164 275 115 165 275 minecraft:red_concrete
fill 114 164 317 115 165 317 minecraft:red_concrete
fill 115 164 309 115 165 309 minecraft:yellow_wool
fill 116 164 275 117 165 275 minecraft:white_concrete
fill 116 164 317 117 165 317 minecraft:white_concrete
fill 118 164 275 119 165 275 minecraft:red_concrete
fill 118 164 317 119 165 317 minecraft:red_concrete
fill 120 164 275 121 165 275 minecraft:white_concrete
fill 120 164 317 121 165 317 minecraft:white_concrete
fill 122 164 275 123 165 275 minecraft:red_concrete
fill 122 164 317 123 165 317 minecraft:red_concrete
fill 124 164 275 125 165 275 minecraft:white_concrete
fill 124 164 317 125 165 317 minecraft:white_concrete
fill 126 164 275 127 165 275 minecraft:red_concrete
fill 126 164 317 127 165 317 minecraft:red_concrete
fill 128 164 275 129 165 275 minecraft:white_concrete
fill 128 164 317 129 165 317 minecraft:white_concrete
fill 130 164 275 131 165 275 minecraft:red_concrete
fill 130 164 317 131 165 317 minecraft:red_concrete
fill 132 164 275 133 165 275 minecraft:white_concrete
fill 132 164 317 133 165 317 minecraft:white_concrete
fill 134 164 275 135 165 275 minecraft:red_concrete
fill 134 164 317 135 165 317 minecraft:red_concrete
fill 136 164 276 136 165 276 minecraft:red_concrete
fill 136 164 277 136 165 278 minecraft:white_concrete
fill 136 164 279 136 165 280 minecraft:red_concrete
fill 136 164 281 136 165 282 minecraft:white_concrete
fill 136 164 283 136 165 284 minecraft:red_concrete
fill 136 164 285 136 165 286 minecraft:white_concrete
fill 136 164 287 136 165 288 minecraft:red_concrete
fill 136 164 289 136 165 290 minecraft:white_concrete
fill 136 164 291 136 165 292 minecraft:red_concrete
fill 136 164 293 136 165 294 minecraft:white_concrete
fill 136 164 295 136 165 296 minecraft:red_concrete
fill 136 164 297 136 165 298 minecraft:white_concrete
fill 136 164 299 136 165 300 minecraft:red_concrete
fill 136 164 301 136 165 302 minecraft:white_concrete
fill 136 164 303 136 165 304 minecraft:red_concrete
fill 136 164 305 136 165 306 minecraft:white_concrete
fill 136 164 307 136 165 308 minecraft:red_concrete
fill 136 164 309 136 165 310 minecraft:white_concrete
fill 136 164 311 136 165 312 minecraft:red_concrete
fill 136 164 313 136 165 314 minecraft:white_concrete
fill 136 164 315 136 165 316 minecraft:red_concrete
fill 136 164 317 136 165 317 minecraft:white_concrete
setblock 97 165 278 minecraft:light[level=15]
setblock 97 165 285 minecraft:light[level=12]
setblock 97 165 286 minecraft:light[level=15]
setblock 97 165 292 minecraft:light[level=12]
setblock 97 165 294 minecraft:light[level=15]
setblock 97 165 299 minecraft:light[level=12]
setblock 97 165 302 minecraft:light[level=15]
setblock 97 165 306 minecraft:light[level=12]
setblock 97 165 310 minecraft:light[level=15]
setblock 97 165 313 minecraft:light[level=12]
setblock 104 165 278 minecraft:light[level=12]
setblock 104 165 285 minecraft:light[level=12]
setblock 104 165 292 minecraft:light[level=12]
setblock 104 165 299 minecraft:light[level=12]
setblock 104 165 306 minecraft:light[level=12]
setblock 104 165 313 minecraft:light[level=12]
setblock 105 165 278 minecraft:light[level=15]
setblock 105 165 286 minecraft:light[level=15]
setblock 105 165 294 minecraft:light[level=15]
setblock 105 165 302 minecraft:light[level=15]
setblock 105 165 310 minecraft:light[level=15]
setblock 111 165 285 minecraft:light[level=12]
setblock 111 165 292 minecraft:light[level=12]
setblock 111 165 299 minecraft:light[level=12]
setblock 111 165 306 minecraft:light[level=12]
setblock 111 165 313 minecraft:light[level=12]
setblock 113 165 286 minecraft:light[level=15]
setblock 113 165 294 minecraft:light[level=15]
setblock 113 165 302 minecraft:light[level=15]
setblock 113 165 310 minecraft:light[level=15]
setblock 118 165 278 minecraft:light[level=12]
setblock 118 165 285 minecraft:light[level=12]
setblock 118 165 292 minecraft:light[level=12]
setblock 118 165 299 minecraft:light[level=12]
setblock 118 165 306 minecraft:light[level=12]
setblock 118 165 313 minecraft:light[level=12]
setblock 121 165 278 minecraft:light[level=15]
setblock 121 165 286 minecraft:light[level=15]
setblock 121 165 294 minecraft:light[level=15]
setblock 121 165 302 minecraft:light[level=15]
setblock 121 165 310 minecraft:light[level=15]
setblock 125 165 278 minecraft:light[level=12]
setblock 125 165 285 minecraft:light[level=12]
setblock 125 165 292 minecraft:light[level=12]
setblock 125 165 299 minecraft:light[level=12]
setblock 125 165 306 minecraft:light[level=12]
setblock 125 165 313 minecraft:light[level=12]
setblock 129 165 278 minecraft:light[level=15]
setblock 129 165 286 minecraft:light[level=15]
setblock 129 165 294 minecraft:light[level=15]
setblock 129 165 302 minecraft:light[level=15]
setblock 129 165 310 minecraft:light[level=15]
setblock 132 165 278 minecraft:light[level=12]
setblock 132 165 292 minecraft:light[level=12]
setblock 132 165 299 minecraft:light[level=12]
setblock 132 165 306 minecraft:light[level=12]
setblock 132 165 313 minecraft:light[level=12]
fill 94 166 275 94 167 276 minecraft:white_concrete
fill 94 166 277 94 167 278 minecraft:red_concrete
fill 94 166 279 94 167 280 minecraft:white_concrete
fill 94 166 281 94 167 282 minecraft:red_concrete
fill 94 166 283 94 167 284 minecraft:white_concrete
fill 94 166 285 94 167 286 minecraft:red_concrete
fill 94 166 287 94 167 288 minecraft:white_concrete
fill 94 166 289 94 167 290 minecraft:red_concrete
fill 94 166 291 94 167 292 minecraft:white_concrete
fill 94 166 293 94 167 294 minecraft:red_concrete
fill 94 166 295 94 167 296 minecraft:white_concrete
fill 94 166 297 94 167 298 minecraft:red_concrete
fill 94 166 299 94 167 300 minecraft:white_concrete
fill 94 166 301 94 167 302 minecraft:red_concrete
fill 94 166 303 94 167 304 minecraft:white_concrete
fill 94 166 305 94 167 306 minecraft:red_concrete
fill 94 166 307 94 167 308 minecraft:white_concrete
fill 94 166 309 94 167 310 minecraft:red_concrete
fill 94 166 311 94 167 312 minecraft:white_concrete
fill 94 166 313 94 167 314 minecraft:red_concrete
fill 94 166 315 94 167 316 minecraft:white_concrete
fill 95 166 275 95 167 275 minecraft:white_concrete
fill 95 166 317 95 167 317 minecraft:white_concrete
fill 96 166 275 97 167 275 minecraft:red_concrete
fill 96 166 317 97 167 317 minecraft:red_concrete
fill 98 166 275 99 167 275 minecraft:white_concrete
fill 98 166 317 99 167 317 minecraft:white_concrete
fill 100 166 275 101 167 275 minecraft:red_concrete
fill 100 166 317 101 167 317 minecraft:red_concrete
fill 102 166 275 103 167 275 minecraft:white_concrete
fill 102 166 317 103 167 317 minecraft:white_concrete
fill 104 166 275 105 167 275 minecraft:red_concrete
fill 104 166 317 105 167 317 minecraft:red_concrete
fill 106 166 275 107 167 275 minecraft:white_concrete
fill 106 166 317 107 167 317 minecraft:white_concrete
fill 108 166 275 109 167 275 minecraft:red_concrete
fill 108 166 317 109 167 317 minecraft:red_concrete
fill 110 166 275 111 167 275 minecraft:white_concrete
fill 110 166 317 111 167 317 minecraft:white_concrete
fill 112 166 275 113 167 275 minecraft:red_concrete
fill 112 166 317 113 167 317 minecraft:red_concrete
fill 114 166 275 115 167 275 minecraft:white_concrete
fill 114 166 317 115 167 317 minecraft:white_concrete
fill 116 166 275 117 167 275 minecraft:red_concrete
fill 116 166 317 117 167 317 minecraft:red_concrete
fill 118 166 275 119 167 275 minecraft:white_concrete
fill 118 166 304 118 167 305 minecraft:yellow_wool
fill 118 166 317 119 167 317 minecraft:white_concrete
fill 120 166 275 121 167 275 minecraft:red_concrete
fill 120 166 304 121 167 305 minecraft:yellow_wool
fill 120 166 317 121 167 317 minecraft:red_concrete
fill 121 166 306 121 167 306 minecraft:yellow_wool
fill 122 166 275 123 167 275 minecraft:white_concrete
fill 122 166 317 123 167 317 minecraft:white_concrete
fill 124 166 275 125 167 275 minecraft:red_concrete
fill 124 166 317 125 167 317 minecraft:red_concrete
fill 126 166 275 127 167 275 minecraft:white_concrete
fill 126 166 317 127 167 317 minecraft:white_concrete
fill 128 166 275 129 167 275 minecraft:red_concrete
fill 128 166 317 129 167 317 minecraft:red_concrete
fill 130 166 275 131 167 275 minecraft:white_concrete
fill 130 166 317 131 167 317 minecraft:white_concrete
fill 132 166 275 133 167 275 minecraft:red_concrete
fill 132 166 317 133 167 317 minecraft:red_concrete
fill 134 166 275 135 167 275 minecraft:white_concrete
fill 134 166 317 135 167 317 minecraft:white_concrete
fill 136 166 276 136 167 276 minecraft:white_concrete
fill 136 166 277 136 167 278 minecraft:red_concrete
fill 136 166 279 136 167 280 minecraft:white_concrete
fill 136 166 281 136 167 282 minecraft:red_concrete
fill 136 166 283 136 167 284 minecraft:white_concrete
fill 136 166 285 136 167 286 minecraft:red_concrete
fill 136 166 287 136 167 288 minecraft:white_concrete
fill 136 166 289 136 167 290 minecraft:red_concrete
fill 136 166 291 136 167 292 minecraft:white_concrete
fill 136 166 293 136 167 294 minecraft:red_concrete
fill 136 166 295 136 167 296 minecraft:white_concrete
fill 136 166 297 136 167 298 minecraft:red_concrete
fill 136 166 299 136 167 300 minecraft:white_concrete
fill 136 166 301 136 167 302 minecraft:red_concrete
fill 136 166 303 136 167 304 minecraft:white_concrete
fill 136 166 305 136 167 306 minecraft:red_concrete
fill 136 166 307 136 167 308 minecraft:white_concrete
fill 136 166 309 136 167 310 minecraft:red_concrete
fill 136 166 311 136 167 312 minecraft:white_concrete
fill 136 166 313 136 167 314 minecraft:red_concrete
fill 136 166 315 136 167 316 minecraft:white_concrete
fill 136 166 317 136 167 317 minecraft:red_concrete
fill 94 168 275 94 169 276 minecraft:red_concrete
fill 94 168 277 94 169 278 minecraft:white_concrete
fill 94 168 279 94 169 280 minecraft:red_concrete
fill 94 168 281 94 169 282 minecraft:white_concrete
fill 94 168 283 94 169 284 minecraft:red_concrete
fill 94 168 285 94 169 286 minecraft:white_concrete
fill 94 168 287 94 169 288 minecraft:red_concrete
fill 94 168 289 94 169 290 minecraft:white_concrete
fill 94 168 291 94 169 292 minecraft:red_concrete
fill 94 168 293 94 169 294 minecraft:white_concrete
fill 94 168 295 94 169 296 minecraft:red_concrete
fill 94 168 297 94 169 298 minecraft:white_concrete
fill 94 168 299 94 169 300 minecraft:red_concrete
fill 94 168 301 94 169 302 minecraft:white_concrete
fill 94 168 303 94 169 304 minecraft:red_concrete
fill 94 168 305 94 169 306 minecraft:white_concrete
fill 94 168 307 94 169 308 minecraft:red_concrete
fill 94 168 309 94 169 310 minecraft:white_concrete
fill 94 168 311 94 169 312 minecraft:red_concrete
fill 94 168 313 94 169 314 minecraft:white_concrete
fill 94 168 315 94 169 316 minecraft:red_concrete
fill 95 168 275 95 169 275 minecraft:red_concrete
fill 95 168 276 95 169 281 minecraft:red_terracotta
fill 95 168 284 96 168 289 minecraft:red_terracotta
fill 95 168 292 96 168 297 minecraft:red_terracotta
fill 95 168 300 96 168 305 minecraft:red_terracotta
fill 95 168 308 96 168 313 minecraft:red_terracotta
fill 95 168 316 100 169 316 minecraft:red_terracotta
fill 95 168 317 95 169 317 minecraft:red_concrete
fill 96 168 275 97 169 275 minecraft:white_concrete
fill 96 168 277 96 168 283 minecraft:red_terracotta
fill 96 168 290 96 168 291 minecraft:red_terracotta
fill 96 168 298 96 168 299 minecraft:red_terracotta
fill 96 168 306 96 168 307 minecraft:red_terracotta
fill 96 168 314 96 168 315 minecraft:red_terracotta
fill 96 168 317 97 169 317 minecraft:white_concrete
fill 97 168 277 134 168 277 minecraft:red_terracotta
fill 97 168 315 135 168 315 minecraft:red_terracotta
fill 98 168 275 99 169 275 minecraft:red_concrete
fill 98 168 276 103 169 276 minecraft:red_terracotta
fill 98 168 317 99 169 317 minecraft:red_concrete
fill 100 168 275 101 169 275 minecraft:white_concrete
fill 100 168 317 101 169 317 minecraft:white_concrete
fill 102 168 275 103 169 275 minecraft:red_concrete
fill 102 168 317 103 169 317 minecraft:red_concrete
fill 103 168 316 108 169 316 minecraft:red_terracotta
fill 104 168 275 105 169 275 minecraft:white_concrete
fill 104 168 317 105 169 317 minecraft:white_concrete
fill 106 168 275 107 169 275 minecraft:red_concrete
fill 106 168 276 111 169 276 minecraft:red_terracotta
fill 106 168 317 107 169 317 minecraft:red_concrete
fill 108 168 275 109 169 275 minecraft:white_concrete
fill 108 168 317 109 169 317 minecraft:white_concrete
fill 110 168 275 111 169 275 minecraft:red_concrete
fill 110 168 317 111 169 317 minecraft:red_concrete
fill 111 168 316 116 169 316 minecraft:red_terracotta
fill 112 168 275 113 169 275 minecraft:white_concrete
fill 112 168 317 113 169 317 minecraft:white_concrete
fill 114 168 275 115 169 275 minecraft:red_concrete
fill 114 168 276 119 169 276 minecraft:red_terracotta
fill 114 168 317 115 169 317 minecraft:red_concrete
fill 116 168 275 117 169 275 minecraft:white_concrete
fill 116 168 317 117 169 317 minecraft:white_concrete
fill 118 168 275 119 169 275 minecraft:red_concrete
fill 118 168 317 119 169 317 minecraft:red_concrete
fill 119 168 316 124 169 316 minecraft:red_terracotta
fill 120 168 275 121 169 275 minecraft:white_concrete
fill 120 168 317 121 169 317 minecraft:white_concrete
fill 122 168 275 123 169 275 minecraft:red_concrete
fill 122 168 276 127 169 276 minecraft:red_terracotta
fill 122 168 317 123 169 317 minecraft:red_concrete
fill 124 168 275 125 169 275 minecraft:white_concrete
fill 124 168 317 125 169 317 minecraft:white_concrete
fill 126 168 275 127 169 275 minecraft:red_concrete
fill 126 168 317 127 169 317 minecraft:red_concrete
fill 127 168 316 132 169 316 minecraft:red_terracotta
fill 128 168 275 129 169 275 minecraft:white_concrete
fill 128 168 317 129 169 317 minecraft:white_concrete
fill 130 168 275 131 169 275 minecraft:red_concrete
fill 130 168 276 135 169 276 minecraft:red_terracotta
fill 130 168 317 131 169 317 minecraft:red_concrete
fill 132 168 275 133 169 275 minecraft:white_concrete
fill 132 168 317 133 169 317 minecraft:white_concrete
fill 134 168 275 135 169 275 minecraft:red_concrete
fill 134 168 278 134 168 314 minecraft:red_terracotta
fill 134 168 317 135 169 317 minecraft:red_concrete
fill 135 168 279 135 169 284 minecraft:red_terracotta
fill 135 168 287 135 169 292 minecraft:red_terracotta
fill 135 168 295 135 169 300 minecraft:red_terracotta
fill 135 168 303 135 169 308 minecraft:red_terracotta
fill 135 168 311 135 169 314 minecraft:red_terracotta
fill 135 168 316 135 169 316 minecraft:red_terracotta
fill 136 168 276 136 169 276 minecraft:red_concrete
fill 136 168 277 136 169 278 minecraft:white_concrete
fill 136 168 279 136 169 280 minecraft:red_concrete
fill 136 168 281 136 169 282 minecraft:white_concrete
fill 136 168 283 136 169 284 minecraft:red_concrete
fill 136 168 285 136 169 286 minecraft:white_concrete
fill 136 168 287 136 169 288 minecraft:red_concrete
fill 136 168 289 136 169 290 minecraft:white_concrete
fill 136 168 291 136 169 292 minecraft:red_concrete
fill 136 168 293 136 169 294 minecraft:white_concrete
fill 136 168 295 136 169 296 minecraft:red_concrete
fill 136 168 297 136 169 298 minecraft:white_concrete
fill 136 168 299 136 169 300 minecraft:red_concrete
fill 136 168 301 136 169 302 minecraft:white_concrete
fill 136 168 303 136 169 304 minecraft:red_concrete
fill 136 168 305 136 169 306 minecraft:white_concrete
fill 136 168 307 136 169 308 minecraft:red_concrete
fill 136 168 309 136 169 310 minecraft:white_concrete
fill 136 168 311 136 169 312 minecraft:red_concrete
fill 136 168 313 136 169 314 minecraft:white_concrete
fill 136 168 315 136 169 316 minecraft:red_concrete
fill 136 168 317 136 169 317 minecraft:white_concrete
fill 95 169 284 95 169 289 minecraft:red_terracotta
fill 95 169 292 95 169 297 minecraft:red_terracotta
fill 95 169 300 95 169 305 minecraft:red_terracotta
fill 95 169 308 95 169 313 minecraft:red_terracotta
setblock 97 169 310 minecraft:brown_terracotta
setblock 97 169 313 minecraft:brown_terracotta
fill 98 169 314 99 169 314 minecraft:brown_terracotta
setblock 99 169 309 minecraft:brown_terracotta
setblock 100 169 310 minecraft:brown_terracotta
setblock 100 169 313 minecraft:brown_terracotta
fill 101 169 311 101 169 312 minecraft:brown_terracotta
setblock 135 169 315 minecraft:red_terracotta
fill 94 170 275 94 171 276 minecraft:white_concrete
fill 94 170 277 94 171 278 minecraft:red_concrete
fill 94 170 279 94 171 280 minecraft:white_concrete
fill 94 170 281 94 171 282 minecraft:red_concrete
fill 94 170 283 94 171 284 minecraft:white_concrete
fill 94 170 285 94 171 286 minecraft:red_concrete
fill 94 170 287 94 171 288 minecraft:white_concrete
fill 94 170 289 94 171 290 minecraft:red_concrete
fill 94 170 291 94 171 292 minecraft:white_concrete
fill 94 170 293 94 171 294 minecraft:red_concrete
fill 94 170 295 94 171 296 minecraft:white_concrete
fill 94 170 297 94 171 298 minecraft:red_concrete
fill 94 170 299 94 171 300 minecraft:white_concrete
fill 94 170 301 94 171 302 minecraft:red_concrete
fill 94 170 303 94 171 304 minecraft:white_concrete
fill 94 170 305 94 171 306 minecraft:red_concrete
fill 94 170 307 94 171 308 minecraft:white_concrete
fill 94 170 309 94 171 310 minecraft:red_concrete
fill 94 170 311 94 171 312 minecraft:white_concrete
fill 94 170 313 94 171 314 minecraft:red_concrete
fill 94 170 315 94 171 316 minecraft:white_concrete
fill 95 170 275 95 171 275 minecraft:white_concrete
fill 95 170 317 95 171 317 minecraft:white_concrete
fill 96 170 275 97 171 275 minecraft:red_concrete
fill 96 170 317 97 171 317 minecraft:red_concrete
fill 98 170 275 99 171 275 minecraft:white_concrete
fill 98 170 317 99 171 317 minecraft:white_concrete
fill 100 170 275 101 171 275 minecraft:red_concrete
fill 100 170 317 101 171 317 minecraft:red_concrete
fill 102 170 275 103 171 275 minecraft:white_concrete
fill 102 170 317 103 171 317 minecraft:white_concrete
fill 104 170 275 105 171 275 minecraft:red_concrete
fill 104 170 317 105 171 317 minecraft:red_concrete
fill 106 170 275 107 171 275 minecraft:white_concrete
fill 106 170 317 107 171 317 minecraft:white_concrete
fill 108 170 275 109 171 275 minecraft:red_concrete
fill 108 170 317 109 171 317 minecraft:red_concrete
fill 110 170 275 111 171 275 minecraft:white_concrete
fill 110 170 317 111 171 317 minecraft:white_concrete
fill 112 170 275 113 171 275 minecraft:red_concrete
fill 112 170 317 113 171 317 minecraft:red_concrete
fill 114 170 275 115 171 275 minecraft:white_concrete
fill 114 170 317 115 171 317 minecraft:white_concrete
fill 116 170 275 117 171 275 minecraft:red_concrete
fill 116 170 317 117 171 317 minecraft:red_concrete
fill 118 170 275 119 171 275 minecraft:white_concrete
fill 118 170 317 119 171 317 minecraft:white_concrete
fill 120 170 275 121 171 275 minecraft:red_concrete
fill 120 170 317 121 171 317 minecraft:red_concrete
fill 122 170 275 123 171 275 minecraft:white_concrete
fill 122 170 317 123 171 317 minecraft:white_concrete
fill 124 170 275 125 171 275 minecraft:red_concrete
fill 124 170 317 125 171 317 minecraft:red_concrete
fill 126 170 275 127 171 275 minecraft:white_concrete
fill 126 170 317 127 171 317 minecraft:white_concrete
fill 128 170 275 129 171 275 minecraft:red_concrete
fill 128 170 317 129 171 317 minecraft:red_concrete
fill 130 170 275 131 171 275 minecraft:white_concrete
fill 130 170 317 131 171 317 minecraft:white_concrete
fill 132 170 275 133 171 275 minecraft:red_concrete
fill 132 170 317 133 171 317 minecraft:red_concrete
fill 134 170 275 135 171 275 minecraft:white_concrete
fill 134 170 317 135 171 317 minecraft:white_concrete
fill 136 170 276 136 171 276 minecraft:white_concrete
fill 136 170 277 136 171 278 minecraft:red_concrete
fill 136 170 279 136 171 280 minecraft:white_concrete
fill 136 170 281 136 171 282 minecraft:red_concrete
fill 136 170 283 136 171 284 minecraft:white_concrete
fill 136 170 285 136 171 286 minecraft:red_concrete
fill 136 170 287 136 171 288 minecraft:white_concrete
fill 136 170 289 136 171 290 minecraft:red_concrete
fill 136 170 291 136 171 292 minecraft:white_concrete
fill 136 170 293 136 171 294 minecraft:red_concrete
fill 136 170 295 136 171 296 minecraft:white_concrete
fill 136 170 297 136 171 298 minecraft:red_concrete
fill 136 170 299 136 171 300 minecraft:white_concrete
fill 136 170 301 136 171 302 minecraft:red_concrete
fill 136 170 303 136 171 304 minecraft:white_concrete
fill 136 170 305 136 171 306 minecraft:red_concrete
fill 136 170 307 136 171 308 minecraft:white_concrete
fill 136 170 309 136 171 310 minecraft:red_concrete
fill 136 170 311 136 171 312 minecraft:white_concrete
fill 136 170 313 136 171 314 minecraft:red_concrete
fill 136 170 315 136 171 316 minecraft:white_concrete
fill 136 170 317 136 171 317 minecraft:red_concrete
setblock 97 171 278 minecraft:light[level=12]
setblock 97 171 285 minecraft:light[level=12]
setblock 97 171 292 minecraft:light[level=12]
setblock 97 171 299 minecraft:light[level=12]
setblock 97 171 306 minecraft:light[level=12]
setblock 97 171 313 minecraft:light[level=12]
setblock 104 171 278 minecraft:light[level=12]
setblock 104 171 285 minecraft:light[level=12]
setblock 104 171 292 minecraft:light[level=12]
setblock 104 171 299 minecraft:light[level=12]
setblock 104 171 306 minecraft:light[level=12]
setblock 104 171 313 minecraft:light[level=12]
setblock 111 171 285 minecraft:light[level=12]
setblock 111 171 292 minecraft:light[level=12]
setblock 111 171 299 minecraft:light[level=12]
setblock 111 171 306 minecraft:light[level=12]
setblock 111 171 313 minecraft:light[level=12]
setblock 118 171 278 minecraft:light[level=12]
setblock 118 171 285 minecraft:light[level=12]
setblock 118 171 292 minecraft:light[level=12]
setblock 118 171 299 minecraft:light[level=12]
setblock 118 171 306 minecraft:light[level=12]
setblock 118 171 313 minecraft:light[level=12]
setblock 125 171 278 minecraft:light[level=12]
setblock 125 171 285 minecraft:light[level=12]
setblock 125 171 292 minecraft:light[level=12]
setblock 125 171 299 minecraft:light[level=12]
setblock 125 171 306 minecraft:light[level=12]
setblock 125 171 313 minecraft:light[level=12]
fill 128 171 300 128 172 300 minecraft:brown_terracotta
fill 129 171 283 129 171 285 minecraft:red_terracotta
fill 130 171 282 132 171 282 minecraft:red_terracotta
fill 130 171 286 132 171 286 minecraft:red_terracotta
setblock 132 171 278 minecraft:light[level=12]
setblock 132 171 292 minecraft:light[level=12]
setblock 132 171 299 minecraft:light[level=12]
setblock 132 171 306 minecraft:light[level=12]
setblock 132 171 313 minecraft:light[level=12]
fill 133 171 283 133 171 285 minecraft:red_terracotta
fill 94 172 275 94 173 276 minecraft:red_concrete
fill 94 172 277 94 173 278 minecraft:white_concrete
fill 94 172 279 94 173 279 minecraft:red_concrete
fill 94 172 280 94 177 280 minecraft:shroomlight
fill 94 172 281 94 173 282 minecraft:white_concrete
fill 94 172 283 94 173 284 minecraft:red_concrete
fill 94 172 285 94 173 286 minecraft:white_concrete
fill 94 172 287 94 173 287 minecraft:red_concrete
fill 94 172 288 94 177 288 minecraft:shroomlight
fill 94 172 289 94 173 290 minecraft:white_concrete
fill 94 172 291 94 173 292 minecraft:red_concrete
fill 94 172 293 94 173 294 minecraft:white_concrete
fill 94 172 295 94 173 295 minecraft:red_concrete
fill 94 172 296 94 177 296 minecraft:shroomlight
fill 94 172 297 94 173 298 minecraft:white_concrete
fill 94 172 299 94 173 300 minecraft:red_concrete
fill 94 172 301 94 173 302 minecraft:white_concrete
fill 94 172 303 94 173 303 minecraft:red_concrete
fill 94 172 304 94 177 304 minecraft:shroomlight
fill 94 172 305 94 173 306 minecraft:white_concrete
fill 94 172 307 94 173 308 minecraft:red_concrete
fill 94 172 309 94 173 310 minecraft:white_concrete
fill 94 172 311 94 173 311 minecraft:red_concrete
fill 94 172 312 94 177 312 minecraft:shroomlight
fill 94 172 313 94 173 314 minecraft:white_concrete
fill 94 172 315 94 173 316 minecraft:red_concrete
fill 95 172 275 95 173 275 minecraft:red_concrete
fill 95 172 317 95 173 317 minecraft:red_concrete
fill 96 172 275 97 173 275 minecraft:white_concrete
fill 96 172 317 96 173 317 minecraft:white_concrete
fill 97 172 317 97 177 317 minecraft:shroomlight
fill 98 172 275 99 173 275 minecraft:red_concrete
fill 98 172 317 99 173 317 minecraft:red_concrete
fill 100 172 275 100 173 275 minecraft:white_concrete
fill 100 172 317 101 173 317 minecraft:white_concrete
fill 101 172 275 101 177 275 minecraft:shroomlight
fill 102 172 275 103 173 275 minecraft:red_concrete
fill 102 172 317 103 173 317 minecraft:red_concrete
fill 104 172 275 105 173 275 minecraft:white_concrete
fill 104 172 317 104 173 317 minecraft:white_concrete
fill 105 172 317 105 177 317 minecraft:shroomlight
fill 106 172 275 107 173 275 minecraft:red_concrete
fill 106 172 317 107 173 317 minecraft:red_concrete
fill 108 172 275 108 173 275 minecraft:white_concrete
fill 108 172 317 109 173 317 minecraft:white_concrete
fill 109 172 275 109 177 275 minecraft:shroomlight
fill 110 172 275 111 173 275 minecraft:red_concrete
fill 110 172 317 111 173 317 minecraft:red_concrete
fill 112 172 275 113 173 275 minecraft:white_concrete
fill 112 172 317 112 173 317 minecraft:white_concrete
fill 113 172 317 113 177 317 minecraft:shroomlight
fill 114 172 275 115 173 275 minecraft:red_concrete
fill 114 172 317 115 173 317 minecraft:red_concrete
fill 116 172 275 116 173 275 minecraft:white_concrete
fill 116 172 317 117 173 317 minecraft:white_concrete
fill 117 172 275 117 177 275 minecraft:shroomlight
fill 118 172 275 119 173 275 minecraft:red_concrete
fill 118 172 317 119 173 317 minecraft:red_concrete
fill 120 172 275 121 173 275 minecraft:white_concrete
fill 120 172 317 120 173 317 minecraft:white_concrete
fill 121 172 317 121 177 317 minecraft:shroomlight
fill 122 172 275 123 173 275 minecraft:red_concrete
fill 122 172 317 123 173 317 minecraft:red_concrete
fill 124 172 275 124 173 275 minecraft:white_concrete
fill 124 172 317 125 173 317 minecraft:white_concrete
fill 125 172 275 125 177 275 minecraft:shroomlight
fill 126 172 275 127 173 275 minecraft:red_concrete
fill 126 172 317 127 173 317 minecraft:red_concrete
fill 128 172 275 129 173 275 minecraft:white_concrete
fill 128 172 317 128 173 317 minecraft:white_concrete
fill 129 172 317 129 177 317 minecraft:shroomlight
fill 130 172 275 131 173 275 minecraft:red_concrete
fill 130 172 317 131 173 317 minecraft:red_concrete
fill 132 172 275 132 173 275 minecraft:white_concrete
fill 132 172 317 133 173 317 minecraft:white_concrete
fill 133 172 275 133 177 275 minecraft:shroomlight
fill 134 172 275 135 173 275 minecraft:red_concrete
fill 134 172 317 135 173 317 minecraft:red_concrete
fill 136 172 276 136 173 276 minecraft:red_concrete
fill 136 172 277 136 173 278 minecraft:white_concrete
fill 136 172 279 136 173 279 minecraft:red_concrete
fill 136 172 280 136 177 280 minecraft:shroomlight
fill 136 172 281 136 173 282 minecraft:white_concrete
fill 136 172 283 136 173 284 minecraft:red_concrete
fill 136 172 285 136 173 286 minecraft:white_concrete
fill 136 172 287 136 173 287 minecraft:red_concrete
fill 136 172 288 136 177 288 minecraft:shroomlight
fill 136 172 289 136 173 290 minecraft:white_concrete
fill 136 172 291 136 173 292 minecraft:red_concrete
fill 136 172 293 136 173 294 minecraft:white_concrete
fill 136 172 295 136 173 295 minecraft:red_concrete
fill 136 172 296 136 177 296 minecraft:shroomlight
fill 136 172 297 136 173 298 minecraft:white_concrete
fill 136 172 299 136 173 300 minecraft:red_concrete
fill 136 172 301 136 173 302 minecraft:white_concrete
fill 136 172 303 136 173 303 minecraft:red_concrete
fill 136 172 304 136 177 304 minecraft:shroomlight
fill 136 172 305 136 173 306 minecraft:white_concrete
fill 136 172 307 136 173 308 minecraft:red_concrete
fill 136 172 309 136 173 310 minecraft:white_concrete
fill 136 172 311 136 173 311 minecraft:red_concrete
fill 136 172 312 136 177 312 minecraft:shroomlight
fill 136 172 313 136 173 314 minecraft:white_concrete
fill 136 172 315 136 173 316 minecraft:red_concrete
fill 136 172 317 136 173 317 minecraft:white_concrete
setblock 97 173 278 minecraft:light[level=15]
setblock 97 173 286 minecraft:light[level=15]
setblock 97 173 294 minecraft:light[level=15]
setblock 97 173 302 minecraft:light[level=15]
setblock 97 173 310 minecraft:light[level=15]
setblock 105 173 278 minecraft:light[level=15]
setblock 105 173 286 minecraft:light[level=15]
setblock 105 173 294 minecraft:light[level=15]
setblock 105 173 302 minecraft:light[level=15]
setblock 105 173 310 minecraft:light[level=15]
fill 111 173 309 115 174 313 minecraft:brown_terracotta
setblock 113 173 286 minecraft:light[level=15]
setblock 113 173 294 minecraft:light[level=15]
setblock 113 173 302 minecraft:light[level=15]
fill 113 173 314 113 173 315 minecraft:brown_terracotta
setblock 121 173 278 minecraft:light[level=15]
setblock 121 173 286 minecraft:light[level=15]
setblock 121 173 294 minecraft:light[level=15]
setblock 121 173 302 minecraft:light[level=15]
setblock 121 173 310 minecraft:light[level=15]
setblock 129 173 278 minecraft:light[level=15]
setblock 129 173 286 minecraft:light[level=15]
setblock 129 173 294 minecraft:light[level=15]
setblock 129 173 302 minecraft:light[level=15]
setblock 129 173 310 minecraft:light[level=15]
fill 94 174 275 94 175 276 minecraft:white_concrete
fill 94 174 277 94 175 278 minecraft:red_concrete
fill 94 174 279 94 175 279 minecraft:white_concrete
fill 94 174 281 94 175 282 minecraft:red_concrete
fill 94 174 283 94 175 284 minecraft:white_concrete
fill 94 174 285 94 175 286 minecraft:red_concrete
fill 94 174 287 94 175 287 minecraft:white_concrete
fill 94 174 289 94 175 290 minecraft:red_concrete
fill 94 174 291 94 174 292 minecraft:white_concrete
fill 94 174 293 94 175 294 minecraft:red_concrete
fill 94 174 295 94 175 295 minecraft:white_concrete
fill 94 174 297 94 175 298 minecraft:red_concrete
fill 94 174 299 94 175 300 minecraft:white_concrete
fill 94 174 301 94 175 302 minecraft:red_concrete
fill 94 174 303 94 175 303 minecraft:white_concrete
fill 94 174 305 94 175 306 minecraft:red_concrete
fill 94 174 307 94 175 308 minecraft:white_concrete
fill 94 174 309 94 175 310 minecraft:red_concrete
fill 94 174 311 94 175 311 minecraft:white_concrete
fill 94 174 313 94 175 314 minecraft:red_concrete
fill 94 174 315 94 175 316 minecraft:white_concrete
fill 95 174 275 95 175 275 minecraft:white_concrete
fill 95 174 317 95 175 317 minecraft:white_concrete
fill 96 174 275 97 175 275 minecraft:red_concrete
fill 96 174 317 96 175 317 minecraft:red_concrete
fill 98 174 275 99 175 275 minecraft:white_concrete
fill 98 174 317 99 175 317 minecraft:white_concrete
fill 100 174 275 100 175 275 minecraft:red_concrete
fill 100 174 317 101 175 317 minecraft:red_concrete
fill 102 174 275 103 175 275 minecraft:white_concrete
fill 102 174 317 103 175 317 minecraft:white_concrete
fill 104 174 275 105 175 275 minecraft:red_concrete
fill 104 174 317 104 175 317 minecraft:red_concrete
fill 106 174 275 107 175 275 minecraft:white_concrete
fill 106 174 317 107 175 317 minecraft:white_concrete
fill 108 174 275 108 175 275 minecraft:red_concrete
fill 108 174 317 109 175 317 minecraft:red_concrete
fill 110 174 275 111 175 275 minecraft:white_concrete
fill 110 174 317 111 175 317 minecraft:white_concrete
fill 112 174 275 113 175 275 minecraft:red_concrete
fill 112 174 317 112 175 317 minecraft:red_concrete
fill 114 174 275 115 175 275 minecraft:white_concrete
fill 114 174 317 115 175 317 minecraft:white_concrete
fill 116 174 275 116 175 275 minecraft:red_concrete
fill 116 174 317 117 175 317 minecraft:red_concrete
fill 118 174 275 119 175 275 minecraft:white_concrete
fill 118 174 317 119 175 317 minecraft:white_concrete
fill 120 174 275 121 175 275 minecraft:red_concrete
fill 120 174 317 120 175 317 minecraft:red_concrete
fill 122 174 275 123 175 275 minecraft:white_concrete
fill 122 174 317 123 175 317 minecraft:white_concrete
fill 124 174 275 124 175 275 minecraft:red_concrete
fill 124 174 317 125 175 317 minecraft:red_concrete
fill 126 174 275 127 175 275 minecraft:white_concrete
fill 126 174 317 127 175 317 minecraft:white_concrete
fill 128 174 275 129 175 275 minecraft:red_concrete
fill 128 174 317 128 175 317 minecraft:red_concrete
fill 130 174 275 131 175 275 minecraft:white_concrete
fill 130 174 317 131 175 317 minecraft:white_concrete
fill 132 174 275 132 175 275 minecraft:red_concrete
fill 132 174 317 133 175 317 minecraft:red_concrete
fill 134 174 275 135 175 275 minecraft:white_concrete
fill 134 174 317 135 175 317 minecraft:white_concrete
fill 136 174 276 136 175 276 minecraft:white_concrete
fill 136 174 277 136 175 278 minecraft:red_concrete
fill 136 174 279 136 175 279 minecraft:white_concrete
fill 136 174 281 136 175 282 minecraft:red_concrete
fill 136 174 283 136 175 284 minecraft:white_concrete
fill 136 174 285 136 175 286 minecraft:red_concrete
fill 136 174 287 136 175 287 minecraft:white_concrete
fill 136 174 289 136 175 290 minecraft:red_concrete
fill 136 174 291 136 175 292 minecraft:white_concrete
fill 136 174 293 136 175 294 minecraft:red_concrete
fill 136 174 295 136 175 295 minecraft:white_concrete
fill 136 174 297 136 175 298 minecraft:red_concrete
fill 136 174 299 136 175 300 minecraft:white_concrete
fill 136 174 301 136 175 302 minecraft:red_concrete
fill 136 174 303 136 175 303 minecraft:white_concrete
fill 136 174 305 136 175 306 minecraft:red_concrete
fill 136 174 307 136 175 308 minecraft:white_concrete
fill 136 174 309 136 175 310 minecraft:red_concrete
fill 136 174 311 136 175 311 minecraft:white_concrete
fill 136 174 313 136 175 314 minecraft:red_concrete
fill 136 174 315 136 175 316 minecraft:white_concrete
fill 136 174 317 136 175 317 minecraft:red_concrete
setblock 94 175 291 minecraft:white_concrete
setblock 94 175 292 minecraft:iron_block
fill 95 175 290 95 200 290 minecraft:red_terracotta
setblock 95 175 291 minecraft:iron_block
fill 95 175 292 97 175 292 minecraft:black_concrete
setblock 95 175 293 minecraft:iron_block
setblock 96 175 290 minecraft:iron_block
setblock 96 175 291 minecraft:black_concrete
setblock 96 175 293 minecraft:black_concrete
setblock 96 175 294 minecraft:iron_block
setblock 97 175 291 minecraft:iron_block
setblock 97 175 293 minecraft:iron_block
setblock 98 175 292 minecraft:iron_block
fill 113 175 311 113 178 311 minecraft:red_terracotta
fill 133 175 283 134 176 285 minecraft:iron_block
fill 135 175 284 135 176 284 minecraft:iron_block
fill 94 176 275 94 177 276 minecraft:red_concrete
fill 94 176 277 94 177 278 minecraft:white_concrete
fill 94 176 279 94 177 279 minecraft:red_concrete
fill 94 176 281 94 177 282 minecraft:white_concrete
fill 94 176 283 94 177 284 minecraft:red_concrete
fill 94 176 285 94 177 286 minecraft:white_concrete
fill 94 176 287 94 177 287 minecraft:red_concrete
fill 94 176 289 94 177 290 minecraft:white_concrete
fill 94 176 291 94 177 292 minecraft:red_concrete
fill 94 176 293 94 177 294 minecraft:white_concrete
fill 94 176 295 94 177 295 minecraft:red_concrete
fill 94 176 297 94 177 298 minecraft:white_concrete
fill 94 176 299 94 177 300 minecraft:red_concrete
fill 94 176 301 94 177 302 minecraft:white_concrete
fill 94 176 303 94 177 303 minecraft:red_concrete
fill 94 176 305 94 177 306 minecraft:white_concrete
fill 94 176 307 94 177 308 minecraft:red_concrete
fill 94 176 309 94 177 310 minecraft:white_concrete
fill 94 176 311 94 177 311 minecraft:red_concrete
fill 94 176 313 94 177 314 minecraft:white_concrete
fill 94 176 315 94 177 316 minecraft:red_concrete
fill 95 176 275 95 177 275 minecraft:red_concrete
fill 95 176 291 95 200 291 minecraft:red_terracotta
fill 95 176 317 95 177 317 minecraft:red_concrete
fill 96 176 275 97 177 275 minecraft:white_concrete
fill 96 176 317 96 177 317 minecraft:white_concrete
fill 98 176 275 99 177 275 minecraft:red_concrete
fill 98 176 317 99 177 317 minecraft:red_concrete
fill 100 176 275 100 177 275 minecraft:white_concrete
fill 100 176 317 101 177 317 minecraft:white_concrete
fill 102 176 275 103 177 275 minecraft:red_concrete
fill 102 176 317 103 177 317 minecraft:red_concrete
fill 104 176 275 105 177 275 minecraft:white_concrete
fill 104 176 317 104 177 317 minecraft:white_concrete
fill 106 176 275 107 177 275 minecraft:red_concrete
fill 106 176 317 107 177 317 minecraft:red_concrete
fill 108 176 275 108 177 275 minecraft:white_concrete
fill 108 176 317 109 177 317 minecraft:white_concrete
fill 110 176 275 111 177 275 minecraft:red_concrete
fill 110 176 317 111 177 317 minecraft:red_concrete
fill 112 176 275 113 177 275 minecraft:white_concrete
fill 112 176 317 112 177 317 minecraft:white_concrete
fill 114 176 275 115 177 275 minecraft:red_concrete
fill 114 176 317 115 177 317 minecraft:red_concrete
fill 116 176 275 116 177 275 minecraft:white_concrete
fill 116 176 317 117 177 317 minecraft:white_concrete
fill 118 176 275 119 177 275 minecraft:red_concrete
fill 118 176 317 119 177 317 minecraft:red_concrete
fill 120 176 275 121 177 275 minecraft:white_concrete
fill 120 176 317 120 177 317 minecraft:white_concrete
fill 122 176 275 123 177 275 minecraft:red_concrete
fill 122 176 317 123 177 317 minecraft:red_concrete
fill 124 176 275 124 177 275 minecraft:white_concrete
fill 124 176 317 125 177 317 minecraft:white_concrete
fill 126 176 275 127 177 275 minecraft:red_concrete
fill 126 176 317 127 177 317 minecraft:red_concrete
fill 128 176 275 129 177 275 minecraft:white_concrete
fill 128 176 317 128 177 317 minecraft:white_concrete
setblock 129 176 284 minecraft:shroomlight
fill 130 176 275 131 177 275 minecraft:red_concrete
fill 130 176 317 131 177 317 minecraft:red_concrete
fill 132 176 275 132 177 275 minecraft:white_concrete
fill 132 176 317 133 177 317 minecraft:white_concrete
fill 134 176 275 135 177 275 minecraft:red_concrete
fill 134 176 317 135 177 317 minecraft:red_concrete
fill 136 176 276 136 177 276 minecraft:red_concrete
fill 136 176 277 136 177 278 minecraft:white_concrete
fill 136 176 279 136 177 279 minecraft:red_concrete
fill 136 176 281 136 177 282 minecraft:white_concrete
fill 136 176 283 136 177 284 minecraft:red_concrete
fill 136 176 285 136 177 286 minecraft:white_concrete
fill 136 176 287 136 177 287 minecraft:red_concrete
fill 136 176 289 136 177 290 minecraft:white_concrete
fill 136 176 291 136 177 292 minecraft:red_concrete
fill 136 176 293 136 177 294 minecraft:white_concrete
fill 136 176 295 136 177 295 minecraft:red_concrete
fill 136 176 297 136 177 298 minecraft:white_concrete
fill 136 176 299 136 177 300 minecraft:red_concrete
fill 136 176 301 136 177 302 minecraft:white_concrete
fill 136 176 303 136 177 303 minecraft:red_concrete
fill 136 176 305 136 177 306 minecraft:white_concrete
fill 136 176 307 136 177 308 minecraft:red_concrete
fill 136 176 309 136 177 310 minecraft:white_concrete
fill 136 176 311 136 177 311 minecraft:red_concrete
fill 136 176 313 136 177 314 minecraft:white_concrete
fill 136 176 315 136 177 316 minecraft:red_concrete
fill 136 176 317 136 177 317 minecraft:white_concrete
setblock 97 177 278 minecraft:light[level=12]
setblock 97 177 285 minecraft:light[level=12]
setblock 97 177 292 minecraft:light[level=12]
setblock 97 177 299 minecraft:light[level=12]
setblock 97 177 306 minecraft:light[level=12]
setblock 97 177 310 minecraft:brown_terracotta
setblock 97 177 313 minecraft:brown_terracotta
fill 98 177 314 99 177 314 minecraft:brown_terracotta
setblock 99 177 309 minecraft:brown_terracotta
setblock 100 177 310 minecraft:brown_terracotta
setblock 100 177 313 minecraft:brown_terracotta
fill 101 177 311 101 177 312 minecraft:brown_terracotta
setblock 104 177 278 minecraft:light[level=12]
setblock 104 177 285 minecraft:light[level=12]
setblock 104 177 292 minecraft:light[level=12]
setblock 104 177 299 minecraft:light[level=12]
setblock 104 177 306 minecraft:light[level=12]
setblock 104 177 313 minecraft:light[level=12]
setblock 111 177 285 minecraft:light[level=12]
setblock 111 177 292 minecraft:light[level=12]
setblock 111 177 299 minecraft:light[level=12]
setblock 111 177 306 minecraft:light[level=12]
setblock 111 177 313 minecraft:light[level=12]
setblock 118 177 278 minecraft:light[level=12]
setblock 118 177 285 minecraft:light[level=12]
setblock 118 177 292 minecraft:light[level=12]
setblock 118 177 299 minecraft:light[level=12]
setblock 118 177 306 minecraft:light[level=12]
setblock 118 177 313 minecraft:light[level=12]
setblock 125 177 278 minecraft:light[level=12]
setblock 125 177 285 minecraft:light[level=12]
setblock 125 177 292 minecraft:light[level=12]
setblock 125 177 299 minecraft:light[level=12]
setblock 125 177 306 minecraft:light[level=12]
setblock 125 177 313 minecraft:light[level=12]
setblock 132 177 278 minecraft:light[level=12]
setblock 132 177 292 minecraft:light[level=12]
setblock 132 177 299 minecraft:light[level=12]
setblock 132 177 306 minecraft:light[level=12]
setblock 132 177 313 minecraft:light[level=12]
fill 94 178 275 94 179 276 minecraft:white_concrete
fill 94 178 277 94 179 278 minecraft:red_concrete
fill 94 178 279 94 179 280 minecraft:white_concrete
fill 94 178 281 94 179 282 minecraft:red_concrete
fill 94 178 283 94 179 284 minecraft:white_concrete
fill 94 178 285 94 179 286 minecraft:red_concrete
fill 94 178 287 94 179 288 minecraft:white_concrete
fill 94 178 289 94 179 290 minecraft:red_concrete
fill 94 178 291 94 179 292 minecraft:white_concrete
fill 94 178 293 94 179 294 minecraft:red_concrete
fill 94 178 295 94 179 296 minecraft:white_concrete
fill 94 178 297 94 179 298 minecraft:red_concrete
fill 94 178 299 94 179 300 minecraft:white_concrete
fill 94 178 301 94 179 302 minecraft:red_concrete
fill 94 178 303 94 179 304 minecraft:white_concrete
fill 94 178 305 94 179 306 minecraft:red_concrete
fill 94 178 307 94 179 308 minecraft:white_concrete
fill 94 178 309 94 179 310 minecraft:red_concrete
fill 94 178 311 94 179 312 minecraft:white_concrete
fill 94 178 313 94 179 314 minecraft:red_concrete
fill 94 178 315 94 179 316 minecraft:white_concrete
fill 95 178 275 95 179 275 minecraft:white_concrete
fill 95 178 317 95 179 317 minecraft:white_concrete
fill 96 178 275 97 179 275 minecraft:red_concrete
fill 96 178 317 97 179 317 minecraft:red_concrete
fill 98 178 275 99 179 275 minecraft:white_concrete
fill 98 178 317 99 179 317 minecraft:white_concrete
fill 100 178 275 101 179 275 minecraft:red_concrete
fill 100 178 317 101 179 317 minecraft:red_concrete
fill 102 178 275 103 179 275 minecraft:white_concrete
fill 102 178 317 103 179 317 minecraft:white_concrete
fill 104 178 275 105 179 275 minecraft:red_concrete
fill 104 178 317 105 179 317 minecraft:red_concrete
fill 106 178 275 107 179 275 minecraft:white_concrete
fill 106 178 317 107 179 317 minecraft:white_concrete
fill 108 178 275 109 179 275 minecraft:red_concrete
fill 108 178 317 109 179 317 minecraft:red_concrete
fill 110 178 275 111 179 275 minecraft:white_concrete
fill 110 178 317 111 179 317 minecraft:white_concrete
fill 112 178 275 113 179 275 minecraft:red_concrete
fill 112 178 317 113 179 317 minecraft:red_concrete
fill 114 178 275 115 179 275 minecraft:white_concrete
fill 114 178 317 115 179 317 minecraft:white_concrete
fill 116 178 275 117 179 275 minecraft:red_concrete
fill 116 178 317 117 179 317 minecraft:red_concrete
fill 118 178 275 119 179 275 minecraft:white_concrete
fill 118 178 317 119 179 317 minecraft:white_concrete
fill 120 178 275 121 179 275 minecraft:red_concrete
fill 120 178 317 121 179 317 minecraft:red_concrete
fill 122 178 275 123 179 275 minecraft:white_concrete
fill 122 178 317 123 179 317 minecraft:white_concrete
fill 124 178 275 125 179 275 minecraft:red_concrete
fill 124 178 317 125 179 317 minecraft:red_concrete
fill 126 178 275 127 179 275 minecraft:white_concrete
fill 126 178 317 127 179 317 minecraft:white_concrete
fill 128 178 275 129 179 275 minecraft:red_concrete
fill 128 178 317 129 179 317 minecraft:red_concrete
fill 130 178 275 131 179 275 minecraft:white_concrete
fill 130 178 317 131 179 317 minecraft:white_concrete
fill 132 178 275 133 179 275 minecraft:red_concrete
fill 132 178 317 133 179 317 minecraft:red_concrete
fill 134 178 275 135 179 275 minecraft:white_concrete
fill 134 178 317 135 179 317 minecraft:white_concrete
fill 136 178 276 136 179 276 minecraft:white_concrete
fill 136 178 277 136 179 278 minecraft:red_concrete
fill 136 178 279 136 179 280 minecraft:white_concrete
fill 136 178 281 136 179 282 minecraft:red_concrete
fill 136 178 283 136 179 284 minecraft:white_concrete
fill 136 178 285 136 179 286 minecraft:red_concrete
fill 136 178 287 136 179 288 minecraft:white_concrete
fill 136 178 289 136 179 290 minecraft:red_concrete
fill 136 178 291 136 179 292 minecraft:white_concrete
fill 136 178 293 136 179 294 minecraft:red_concrete
fill 136 178 295 136 179 296 minecraft:white_concrete
fill 136 178 297 136 179 298 minecraft:red_concrete
fill 136 178 299 136 179 300 minecraft:white_concrete
fill 136 178 301 136 179 302 minecraft:red_concrete
fill 136 178 303 136 179 304 minecraft:white_concrete
fill 136 178 305 136 179 306 minecraft:red_concrete
fill 136 178 307 136 179 308 minecraft:white_concrete
fill 136 178 309 136 179 310 minecraft:red_concrete
fill 136 178 311 136 179 312 minecraft:white_concrete
fill 136 178 313 136 179 314 minecraft:red_concrete
fill 136 178 315 136 179 316 minecraft:white_concrete
fill 136 178 317 136 179 317 minecraft:red_concrete
fill 111 179 311 115 182 311 minecraft:yellow_concrete
fill 112 179 310 114 182 310 minecraft:yellow_concrete
fill 112 179 312 114 182 312 minecraft:yellow_concrete
fill 113 179 309 113 182 309 minecraft:yellow_concrete
fill 113 179 313 113 182 313 minecraft:yellow_concrete
fill 129 179 283 129 179 285 minecraft:red_terracotta
fill 130 179 282 132 179 282 minecraft:red_terracotta
fill 130 179 286 132 179 286 minecraft:red_terracotta
fill 133 179 283 133 179 285 minecraft:red_terracotta
fill 94 180 275 94 181 276 minecraft:red_concrete
fill 94 180 277 94 181 278 minecraft:white_concrete
fill 94 180 279 94 181 280 minecraft:red_concrete
fill 94 180 281 94 181 282 minecraft:white_concrete
fill 94 180 283 94 181 284 minecraft:red_concrete
fill 94 180 285 94 181 286 minecraft:white_concrete
fill 94 180 287 94 181 288 minecraft:red_concrete
fill 94 180 289 94 181 290 minecraft:white_concrete
fill 94 180 291 94 181 292 minecraft:red_concrete
fill 94 180 293 94 181 294 minecraft:white_concrete
fill 94 180 295 94 181 296 minecraft:red_concrete
fill 94 180 297 94 181 298 minecraft:white_concrete
fill 94 180 299 94 181 300 minecraft:red_concrete
fill 94 180 301 94 181 302 minecraft:white_concrete
fill 94 180 303 94 181 304 minecraft:red_concrete
fill 94 180 305 94 181 306 minecraft:white_concrete
fill 94 180 307 94 181 308 minecraft:red_concrete
fill 94 180 309 94 181 310 minecraft:white_concrete
fill 94 180 311 94 181 312 minecraft:red_concrete
fill 94 180 313 94 181 314 minecraft:white_concrete
fill 94 180 315 94 181 316 minecraft:red_concrete
fill 95 180 275 95 181 275 minecraft:red_concrete
fill 95 180 317 95 181 317 minecraft:red_concrete
fill 96 180 275 97 181 275 minecraft:white_concrete
fill 96 180 317 97 181 317 minecraft:white_concrete
fill 98 180 275 99 181 275 minecraft:red_concrete
fill 98 180 317 99 181 317 minecraft:red_concrete
fill 100 180 275 101 181 275 minecraft:white_concrete
fill 100 180 317 101 181 317 minecraft:white_concrete
fill 102 180 275 103 181 275 minecraft:red_concrete
fill 102 180 317 103 181 317 minecraft:red_concrete
fill 104 180 275 105 181 275 minecraft:white_concrete
fill 104 180 317 105 181 317 minecraft:white_concrete
fill 106 180 275 107 181 275 minecraft:red_concrete
fill 106 180 317 107 181 317 minecraft:red_concrete
fill 108 180 275 109 181 275 minecraft:white_concrete
fill 108 180 317 109 181 317 minecraft:white_concrete
fill 110 180 275 111 181 275 minecraft:red_concrete
fill 110 180 317 111 181 317 minecraft:red_concrete
fill 111 180 310 111 181 310 minecraft:yellow_concrete
fill 111 180 312 111 181 312 minecraft:yellow_concrete
fill 112 180 275 113 181 275 minecraft:white_concrete
fill 112 180 309 112 181 309 minecraft:yellow_concrete
fill 112 180 313 112 181 313 minecraft:yellow_concrete
fill 112 180 317 113 181 317 minecraft:white_concrete
fill 114 180 275 115 181 275 minecraft:red_concrete
fill 114 180 309 114 181 309 minecraft:yellow_concrete
fill 114 180 313 114 181 313 minecraft:yellow_concrete
fill 114 180 317 115 181 317 minecraft:red_concrete
fill 115 180 310 115 181 310 minecraft:yellow_concrete
fill 115 180 312 115 181 312 minecraft:yellow_concrete
fill 116 180 275 117 181 275 minecraft:white_concrete
fill 116 180 317 117 181 317 minecraft:white_concrete
fill 118 180 275 119 181 275 minecraft:red_concrete
fill 118 180 317 119 181 317 minecraft:red_concrete
fill 120 180 275 121 181 275 minecraft:white_concrete
fill 120 180 317 121 181 317 minecraft:white_concrete
fill 122 180 275 123 181 275 minecraft:red_concrete
fill 122 180 317 123 181 317 minecraft:red_concrete
fill 124 180 275 125 181 275 minecraft:white_concrete
fill 124 180 317 125 181 317 minecraft:white_concrete
fill 126 180 275 127 181 275 minecraft:red_concrete
fill 126 180 317 127 181 317 minecraft:red_concrete
fill 128 180 275 129 181 275 minecraft:white_concrete
fill 128 180 317 129 181 317 minecraft:white_concrete
fill 130 180 275 131 181 275 minecraft:red_concrete
fill 130 180 317 131 181 317 minecraft:red_concrete
fill 132 180 275 133 181 275 minecraft:white_concrete
fill 132 180 317 133 181 317 minecraft:white_concrete
fill 134 180 275 135 181 275 minecraft:red_concrete
fill 134 180 317 135 181 317 minecraft:red_concrete
fill 136 180 276 136 181 276 minecraft:red_concrete
fill 136 180 277 136 181 278 minecraft:white_concrete
fill 136 180 279 136 181 280 minecraft:red_concrete
fill 136 180 281 136 181 282 minecraft:white_concrete
fill 136 180 283 136 181 284 minecraft:red_concrete
fill 136 180 285 136 181 286 minecraft:white_concrete
fill 136 180 287 136 181 288 minecraft:red_concrete
fill 136 180 289 136 181 290 minecraft:white_concrete
fill 136 180 291 136 181 292 minecraft:red_concrete
fill 136 180 293 136 181 294 minecraft:white_concrete
fill 136 180 295 136 181 296 minecraft:red_concrete
fill 136 180 297 136 181 298 minecraft:white_concrete
fill 136 180 299 136 181 300 minecraft:red_concrete
fill 136 180 301 136 181 302 minecraft:white_concrete
fill 136 180 303 136 181 304 minecraft:red_concrete
fill 136 180 305 136 181 306 minecraft:white_concrete
fill 136 180 307 136 181 308 minecraft:red_concrete
fill 136 180 309 136 181 310 minecraft:white_concrete
fill 136 180 311 136 181 312 minecraft:red_concrete
fill 136 180 313 136 181 314 minecraft:white_concrete
fill 136 180 315 136 181 316 minecraft:red_concrete
fill 136 180 317 136 181 317 minecraft:white_concrete
setblock 97 181 278 minecraft:light[level=15]
setblock 97 181 286 minecraft:light[level=15]
setblock 97 181 294 minecraft:light[level=15]
setblock 97 181 302 minecraft:light[level=15]
setblock 97 181 310 minecraft:light[level=15]
fill 102 181 307 102 182 309 minecraft:brown_terracotta
fill 103 181 308 103 182 309 minecraft:brown_terracotta
setblock 105 181 278 minecraft:light[level=15]
setblock 105 181 286 minecraft:light[level=15]
setblock 105 181 294 minecraft:light[level=15]
setblock 105 181 302 minecraft:light[level=15]
setblock 105 181 310 minecraft:light[level=15]
setblock 113 181 286 minecraft:light[level=15]
setblock 113 181 294 minecraft:light[level=15]
setblock 113 181 302 minecraft:light[level=15]
setblock 121 181 278 minecraft:light[level=15]
setblock 121 181 286 minecraft:light[level=15]
setblock 121 181 294 minecraft:light[level=15]
setblock 121 181 302 minecraft:light[level=15]
setblock 121 181 310 minecraft:light[level=15]
setblock 129 181 278 minecraft:light[level=15]
setblock 129 181 286 minecraft:light[level=15]
setblock 129 181 294 minecraft:light[level=15]
setblock 129 181 302 minecraft:light[level=15]
setblock 129 181 310 minecraft:light[level=15]
fill 94 182 275 94 183 276 minecraft:white_concrete
fill 94 182 277 94 183 278 minecraft:red_concrete
fill 94 182 279 94 183 280 minecraft:white_concrete
fill 94 182 281 94 183 282 minecraft:red_concrete
fill 94 182 283 94 183 284 minecraft:white_concrete
fill 94 182 285 94 183 286 minecraft:red_concrete
fill 94 182 287 94 183 288 minecraft:white_concrete
fill 94 182 289 94 183 290 minecraft:red_concrete
fill 94 182 291 94 183 292 minecraft:white_concrete
fill 94 182 293 94 183 294 minecraft:red_concrete
fill 94 182 295 94 183 296 minecraft:white_concrete
fill 94 182 297 94 183 298 minecraft:red_concrete
fill 94 182 299 94 183 300 minecraft:white_concrete
fill 94 182 301 94 183 302 minecraft:red_concrete
fill 94 182 303 94 183 304 minecraft:white_concrete
fill 94 182 305 94 183 306 minecraft:red_concrete
fill 94 182 307 94 183 308 minecraft:white_concrete
fill 94 182 309 94 183 310 minecraft:red_concrete
fill 94 182 311 94 183 312 minecraft:white_concrete
fill 94 182 313 94 183 314 minecraft:red_concrete
fill 94 182 315 94 183 316 minecraft:white_concrete
fill 95 182 275 95 183 275 minecraft:white_concrete
fill 95 182 276 95 183 281 minecraft:red_terracotta
fill 95 182 284 96 182 289 minecraft:red_terracotta
fill 95 182 292 96 182 297 minecraft:red_terracotta
fill 95 182 300 96 182 305 minecraft:red_terracotta
fill 95 182 308 96 182 313 minecraft:red_terracotta
fill 95 182 316 100 183 316 minecraft:red_terracotta
fill 95 182 317 95 183 317 minecraft:white_concrete
fill 96 182 275 97 183 275 minecraft:red_concrete
fill 96 182 277 96 182 283 minecraft:red_terracotta
fill 96 182 290 96 182 291 minecraft:red_terracotta
fill 96 182 298 96 182 299 minecraft:red_terracotta
fill 96 182 306 96 182 307 minecraft:red_terracotta
fill 96 182 314 96 182 315 minecraft:red_terracotta
fill 96 182 317 97 183 317 minecraft:red_concrete
fill 97 182 277 134 182 277 minecraft:red_terracotta
fill 97 182 315 135 182 315 minecraft:red_terracotta
fill 98 182 275 99 183 275 minecraft:white_concrete
fill 98 182 276 103 183 276 minecraft:red_terracotta
fill 98 182 317 99 183 317 minecraft:white_concrete
fill 100 182 275 101 183 275 minecraft:red_concrete
fill 100 182 317 101 183 317 minecraft:red_concrete
fill 102 182 275 103 183 275 minecraft:white_concrete
fill 102 182 317 103 183 317 minecraft:white_concrete
fill 103 182 316 108 183 316 minecraft:red_terracotta
fill 104 182 275 105 183 275 minecraft:red_concrete
fill 104 182 317 105 183 317 minecraft:red_concrete
fill 106 182 275 107 183 275 minecraft:white_concrete
fill 106 182 276 111 183 276 minecraft:red_terracotta
fill 106 182 317 107 183 317 minecraft:white_concrete
fill 108 182 275 109 183 275 minecraft:red_concrete
fill 108 182 317 109 183 317 minecraft:red_concrete
fill 110 182 275 111 183 275 minecraft:white_concrete
fill 110 182 317 111 183 317 minecraft:white_concrete
fill 111 182 316 116 183 316 minecraft:red_terracotta
fill 112 182 275 113 183 275 minecraft:red_concrete
fill 112 182 317 113 183 317 minecraft:red_concrete
fill 114 182 275 115 183 275 minecraft:white_concrete
fill 114 182 276 119 183 276 minecraft:red_terracotta
fill 114 182 317 115 183 317 minecraft:white_concrete
fill 116 182 275 117 183 275 minecraft:red_concrete
fill 116 182 317 117 183 317 minecraft:red_concrete
fill 118 182 275 119 183 275 minecraft:white_concrete
fill 118 182 317 119 183 317 minecraft:white_concrete
fill 119 182 316 124 183 316 minecraft:red_terracotta
fill 120 182 275 121 183 275 minecraft:red_concrete
fill 120 182 317 121 183 317 minecraft:red_concrete
fill 122 182 275 123 183 275 minecraft:white_concrete
fill 122 182 276 127 183 276 minecraft:red_terracotta
fill 122 182 317 123 183 317 minecraft:white_concrete
fill 124 182 275 125 183 275 minecraft:red_concrete
fill 124 182 317 125 183 317 minecraft:red_concrete
fill 126 182 275 127 183 275 minecraft:white_concrete
fill 126 182 317 127 183 317 minecraft:white_concrete
fill 127 182 316 132 183 316 minecraft:red_terracotta
fill 128 182 275 129 183 275 minecraft:red_concrete
fill 128 182 317 129 183 317 minecraft:red_concrete
fill 130 182 275 131 183 275 minecraft:white_concrete
fill 130 182 276 135 183 276 minecraft:red_terracotta
fill 130 182 317 131 183 317 minecraft:white_concrete
fill 132 182 275 133 183 275 minecraft:red_concrete
fill 132 182 317 133 183 317 minecraft:red_concrete
fill 134 182 275 135 183 275 minecraft:white_concrete
fill 134 182 278 134 182 314 minecraft:red_terracotta
fill 134 182 317 135 183 317 minecraft:white_concrete
fill 135 182 279 135 183 284 minecraft:red_terracotta
fill 135 182 287 135 183 292 minecraft:red_terracotta
fill 135 182 295 135 183 300 minecraft:red_terracotta
fill 135 182 303 135 183 308 minecraft:red_terracotta
fill 135 182 311 135 183 314 minecraft:red_terracotta
fill 135 182 316 135 183 316 minecraft:red_terracotta
fill 136 182 276 136 183 276 minecraft:white_concrete
fill 136 182 277 136 183 278 minecraft:red_concrete
fill 136 182 279 136 183 280 minecraft:white_concrete
fill 136 182 281 136 183 282 minecraft:red_concrete
fill 136 182 283 136 183 284 minecraft:white_concrete
fill 136 182 285 136 183 286 minecraft:red_concrete
fill 136 182 287 136 183 288 minecraft:white_concrete
fill 136 182 289 136 183 290 minecraft:red_concrete
fill 136 182 291 136 183 292 minecraft:white_concrete
fill 136 182 293 136 183 294 minecraft:red_concrete
fill 136 182 295 136 183 296 minecraft:white_concrete
fill 136 182 297 136 183 298 minecraft:red_concrete
fill 136 182 299 136 183 300 minecraft:white_concrete
fill 136 182 301 136 183 302 minecraft:red_concrete
fill 136 182 303 136 183 304 minecraft:white_concrete
fill 136 182 305 136 183 306 minecraft:red_concrete
fill 136 182 307 136 183 308 minecraft:white_concrete
fill 136 182 309 136 183 310 minecraft:red_concrete
fill 136 182 311 136 183 312 minecraft:white_concrete
fill 136 182 313 136 183 314 minecraft:red_concrete
fill 136 182 315 136 183 316 minecraft:white_concrete
fill 136 182 317 136 183 317 minecraft:red_concrete
fill 95 183 284 95 183 289 minecraft:red_terracotta
fill 95 183 292 95 183 297 minecraft:red_terracotta
fill 95 183 300 95 183 305 minecraft:red_terracotta
fill 95 183 308 95 183 313 minecraft:red_terracotta
setblock 97 183 278 minecraft:light[level=12]
setblock 97 183 285 minecraft:light[level=12]
setblock 97 183 292 minecraft:light[level=12]
setblock 97 183 299 minecraft:light[level=12]
setblock 97 183 306 minecraft:light[level=12]
setblock 97 183 313 minecraft:light[level=12]
setblock 104 183 278 minecraft:light[level=12]
setblock 104 183 285 minecraft:light[level=12]
setblock 104 183 292 minecraft:light[level=12]
setblock 104 183 299 minecraft:light[level=12]
setblock 104 183 306 minecraft:light[level=12]
setblock 104 183 313 minecraft:light[level=12]
fill 108 183 302 108 184 302 minecraft:red_concrete
setblock 111 183 285 minecraft:light[level=12]
setblock 111 183 292 minecraft:light[level=12]
setblock 111 183 299 minecraft:light[level=12]
setblock 111 183 306 minecraft:light[level=12]
setblock 111 183 313 minecraft:light[level=12]
setblock 113 183 311 minecraft:yellow_concrete
setblock 118 183 278 minecraft:light[level=12]
setblock 118 183 285 minecraft:light[level=12]
setblock 118 183 292 minecraft:light[level=12]
setblock 118 183 299 minecraft:light[level=12]
setblock 118 183 306 minecraft:light[level=12]
setblock 118 183 313 minecraft:light[level=12]
setblock 125 183 278 minecraft:light[level=12]
setblock 125 183 285 minecraft:light[level=12]
setblock 125 183 292 minecraft:light[level=12]
setblock 125 183 299 minecraft:light[level=12]
setblock 125 183 306 minecraft:light[level=12]
setblock 125 183 313 minecraft:light[level=12]
setblock 132 183 278 minecraft:light[level=12]
setblock 132 183 292 minecraft:light[level=12]
setblock 132 183 299 minecraft:light[level=12]
setblock 132 183 306 minecraft:light[level=12]
setblock 132 183 313 minecraft:light[level=12]
setblock 135 183 315 minecraft:red_terracotta
fill 94 184 275 94 185 276 minecraft:red_concrete
fill 94 184 277 94 185 278 minecraft:white_concrete
fill 94 184 279 94 185 280 minecraft:red_concrete
fill 94 184 281 94 185 282 minecraft:white_concrete
fill 94 184 283 94 185 284 minecraft:red_concrete
fill 94 184 285 94 185 286 minecraft:white_concrete
fill 94 184 287 94 185 288 minecraft:red_concrete
fill 94 184 289 94 185 290 minecraft:white_concrete
fill 94 184 291 94 185 292 minecraft:red_concrete
fill 94 184 293 94 185 294 minecraft:white_concrete
fill 94 184 295 94 185 296 minecraft:red_concrete
fill 94 184 297 94 185 298 minecraft:white_concrete
fill 94 184 299 94 185 300 minecraft:red_concrete
fill 94 184 301 94 185 302 minecraft:white_concrete
fill 94 184 303 94 185 304 minecraft:red_concrete
fill 94 184 305 94 185 306 minecraft:white_concrete
fill 94 184 307 94 185 308 minecraft:red_concrete
fill 94 184 309 94 185 310 minecraft:white_concrete
fill 94 184 311 94 185 312 minecraft:red_concrete
fill 94 184 313 94 185 314 minecraft:white_concrete
fill 94 184 315 94 185 316 minecraft:red_concrete
fill 95 184 275 95 185 275 minecraft:red_concrete
fill 95 184 317 95 185 317 minecraft:red_concrete
fill 96 184 275 97 185 275 minecraft:white_concrete
fill 96 184 317 97 185 317 minecraft:white_concrete
fill 98 184 275 99 185 275 minecraft:red_concrete
fill 98 184 317 99 185 317 minecraft:red_concrete
fill 100 184 275 101 185 275 minecraft:white_concrete
fill 100 184 317 101 185 317 minecraft:white_concrete
fill 102 184 275 103 185 275 minecraft:red_concrete
fill 102 184 317 103 185 317 minecraft:red_concrete
fill 104 184 275 105 185 275 minecraft:white_concrete
fill 104 184 317 105 185 317 minecraft:white_concrete
fill 106 184 275 107 185 275 minecraft:red_concrete
fill 106 184 317 107 185 317 minecraft:red_concrete
fill 108 184 275 109 185 275 minecraft:white_concrete
fill 108 184 317 109 185 317 minecraft:white_concrete
fill 109 184 282 110 185 283 minecraft:red_concrete
fill 110 184 275 111 185 275 minecraft:red_concrete
fill 110 184 317 111 185 317 minecraft:red_concrete
fill 112 184 275 113 185 275 minecraft:white_concrete
fill 112 184 317 113 185 317 minecraft:white_concrete
fill 114 184 275 115 185 275 minecraft:red_concrete
fill 114 184 317 115 185 317 minecraft:red_concrete
fill 116 184 275 117 185 275 minecraft:white_concrete
fill 116 184 317 117 185 317 minecraft:white_concrete
fill 118 184 275 119 185 275 minecraft:red_concrete
fill 118 184 317 119 185 317 minecraft:red_concrete
fill 120 184 275 121 185 275 minecraft:white_concrete
fill 120 184 317 121 185 317 minecraft:white_concrete
fill 122 184 275 123 185 275 minecraft:red_concrete
fill 122 184 317 123 185 317 minecraft:red_concrete
fill 124 184 275 125 185 275 minecraft:white_concrete
fill 124 184 317 125 185 317 minecraft:white_concrete
fill 126 184 275 127 185 275 minecraft:red_concrete
fill 126 184 317 127 185 317 minecraft:red_concrete
fill 128 184 275 129 185 275 minecraft:white_concrete
fill 128 184 317 129 185 317 minecraft:white_concrete
fill 130 184 275 131 185 275 minecraft:red_concrete
fill 130 184 317 131 185 317 minecraft:red_concrete
fill 132 184 275 133 185 275 minecraft:white_concrete
fill 132 184 317 133 185 317 minecraft:white_concrete
fill 134 184 275 135 185 275 minecraft:red_concrete
fill 134 184 317 135 185 317 minecraft:red_concrete
fill 136 184 276 136 185 276 minecraft:red_concrete
fill 136 184 277 136 185 278 minecraft:white_concrete
fill 136 184 279 136 185 280 minecraft:red_concrete
fill 136 184 281 136 185 282 minecraft:white_concrete
fill 136 184 283 136 185 284 minecraft:red_concrete
fill 136 184 285 136 185 286 minecraft:white_concrete
fill 136 184 287 136 185 288 minecraft:red_concrete
fill 136 184 289 136 185 290 minecraft:white_concrete
fill 136 184 291 136 185 292 minecraft:red_concrete
fill 136 184 293 136 185 294 minecraft:white_concrete
fill 136 184 295 136 185 296 minecraft:red_concrete
fill 136 184 297 136 185 298 minecraft:white_concrete
fill 136 184 299 136 185 300 minecraft:red_concrete
fill 136 184 301 136 185 302 minecraft:white_concrete
fill 136 184 303 136 185 304 minecraft:red_concrete
fill 136 184 305 136 185 306 minecraft:white_concrete
fill 136 184 307 136 185 308 minecraft:red_concrete
fill 136 184 309 136 185 310 minecraft:white_concrete
fill 136 184 311 136 185 312 minecraft:red_concrete
fill 136 184 313 136 185 314 minecraft:white_concrete
fill 136 184 315 136 185 316 minecraft:red_concrete
fill 136 184 317 136 185 317 minecraft:white_concrete
setblock 97 185 310 minecraft:brown_terracotta
setblock 97 185 313 minecraft:brown_terracotta
fill 98 185 314 99 185 314 minecraft:brown_terracotta
setblock 99 185 309 minecraft:brown_terracotta
setblock 100 185 310 minecraft:brown_terracotta
setblock 100 185 313 minecraft:brown_terracotta
fill 101 185 311 101 185 312 minecraft:brown_terracotta
fill 120 185 307 120 186 307 minecraft:yellow_wool
fill 94 186 275 94 187 276 minecraft:white_concrete
fill 94 186 277 94 187 278 minecraft:red_concrete
fill 94 186 279 94 187 279 minecraft:white_concrete
fill 94 186 280 94 191 280 minecraft:shroomlight
fill 94 186 281 94 187 282 minecraft:red_concrete
fill 94 186 283 94 187 284 minecraft:white_concrete
fill 94 186 285 94 187 286 minecraft:red_concrete
fill 94 186 287 94 187 287 minecraft:white_concrete
fill 94 186 288 94 191 288 minecraft:shroomlight
fill 94 186 289 94 187 290 minecraft:red_concrete
fill 94 186 291 94 187 292 minecraft:white_concrete
fill 94 186 293 94 187 294 minecraft:red_concrete
fill 94 186 295 94 187 295 minecraft:white_concrete
fill 94 186 296 94 191 296 minecraft:shroomlight
fill 94 186 297 94 187 298 minecraft:red_concrete
fill 94 186 299 94 187 300 minecraft:white_concrete
fill 94 186 301 94 187 302 minecraft:red_concrete
fill 94 186 303 94 187 303 minecraft:white_concrete
fill 94 186 304 94 191 304 minecraft:shroomlight
fill 94 186 305 94 187 306 minecraft:red_concrete
fill 94 186 307 94 187 308 minecraft:white_concrete
fill 94 186 309 94 187 310 minecraft:red_concrete
fill 94 186 311 94 187 311 minecraft:white_concrete
fill 94 186 312 94 191 312 minecraft:shroomlight
fill 94 186 313 94 187 314 minecraft:red_concrete
fill 94 186 315 94 187 316 minecraft:white_concrete
fill 95 186 275 95 187 275 minecraft:white_concrete
fill 95 186 317 95 187 317 minecraft:white_concrete
fill 96 186 275 97 187 275 minecraft:red_concrete
fill 96 186 317 96 187 317 minecraft:red_concrete
fill 97 186 317 97 191 317 minecraft:shroomlight
fill 98 186 275 99 187 275 minecraft:white_concrete
fill 98 186 317 99 187 317 minecraft:white_concrete
fill 100 186 275 100 187 275 minecraft:red_concrete
fill 100 186 317 101 187 317 minecraft:red_concrete
fill 101 186 275 101 191 275 minecraft:shroomlight
fill 102 186 275 103 187 275 minecraft:white_concrete
fill 102 186 317 103 187 317 minecraft:white_concrete
fill 104 186 275 105 187 275 minecraft:red_concrete
fill 104 186 317 104 187 317 minecraft:red_concrete
fill 105 186 317 105 191 317 minecraft:shroomlight
fill 106 186 275 107 187 275 minecraft:white_concrete
fill 106 186 317 107 187 317 minecraft:white_concrete
fill 108 186 275 108 187 275 minecraft:red_concrete
fill 108 186 317 109 187 317 minecraft:red_concrete
fill 109 186 275 109 191 275 minecraft:shroomlight
fill 110 186 275 111 187 275 minecraft:white_concrete
fill 110 186 317 111 187 317 minecraft:white_concrete
fill 112 186 275 113 187 275 minecraft:red_concrete
fill 112 186 317 112 187 317 minecraft:red_concrete
fill 113 186 317 113 191 317 minecraft:shroomlight
fill 114 186 275 115 187 275 minecraft:white_concrete
fill 114 186 317 115 187 317 minecraft:white_concrete
fill 116 186 275 116 187 275 minecraft:red_concrete
fill 116 186 317 117 187 317 minecraft:red_concrete
fill 117 186 275 117 191 275 minecraft:shroomlight
fill 118 186 275 119 187 275 minecraft:white_concrete
fill 118 186 317 119 187 317 minecraft:white_concrete
fill 120 186 275 121 187 275 minecraft:red_concrete
fill 120 186 317 120 187 317 minecraft:red_concrete
fill 121 186 317 121 191 317 minecraft:shroomlight
fill 122 186 275 123 187 275 minecraft:white_concrete
fill 122 186 317 123 187 317 minecraft:white_concrete
fill 124 186 275 124 187 275 minecraft:red_concrete
fill 124 186 317 125 187 317 minecraft:red_concrete
fill 125 186 275 125 191 275 minecraft:shroomlight
fill 126 186 275 127 187 275 minecraft:white_concrete
fill 126 186 317 127 187 317 minecraft:white_concrete
fill 128 186 275 129 187 275 minecraft:red_concrete
fill 128 186 317 128 187 317 minecraft:red_concrete
fill 129 186 317 129 191 317 minecraft:shroomlight
fill 130 186 275 131 187 275 minecraft:white_concrete
fill 130 186 317 131 187 317 minecraft:white_concrete
fill 132 186 275 132 187 275 minecraft:red_concrete
fill 132 186 317 133 187 317 minecraft:red_concrete
fill 133 186 275 133 191 275 minecraft:shroomlight
fill 134 186 275 135 187 275 minecraft:white_concrete
fill 134 186 317 135 187 317 minecraft:white_concrete
fill 136 186 276 136 187 276 minecraft:white_concrete
fill 136 186 277 136 187 278 minecraft:red_concrete
fill 136 186 279 136 187 279 minecraft:white_concrete
fill 136 186 280 136 191 280 minecraft:shroomlight
fill 136 186 281 136 187 282 minecraft:red_concrete
fill 136 186 283 136 187 284 minecraft:white_concrete
fill 136 186 285 136 187 286 minecraft:red_concrete
fill 136 186 287 136 187 287 minecraft:white_concrete
fill 136 186 288 136 191 288 minecraft:shroomlight
fill 136 186 289 136 187 290 minecraft:red_concrete
fill 136 186 291 136 187 292 minecraft:white_concrete
fill 136 186 293 136 187 294 minecraft:red_concrete
fill 136 186 295 136 187 295 minecraft:white_concrete
fill 136 186 296 136 191 296 minecraft:shroomlight
fill 136 186 297 136 187 298 minecraft:red_concrete
fill 136 186 299 136 187 300 minecraft:white_concrete
fill 136 186 301 136 187 302 minecraft:red_concrete
fill 136 186 303 136 187 303 minecraft:white_concrete
fill 136 186 304 136 191 304 minecraft:shroomlight
fill 136 186 305 136 187 306 minecraft:red_concrete
fill 136 186 307 136 187 308 minecraft:white_concrete
fill 136 186 309 136 187 310 minecraft:red_concrete
fill 136 186 311 136 187 311 minecraft:white_concrete
fill 136 186 312 136 191 312 minecraft:shroomlight
fill 136 186 313 136 187 314 minecraft:red_concrete
fill 136 186 315 136 187 316 minecraft:white_concrete
fill 136 186 317 136 187 317 minecraft:red_concrete
fill 99 187 296 99 188 296 minecraft:green_concrete
fill 129 187 283 129 187 285 minecraft:red_terracotta
fill 130 187 282 132 187 282 minecraft:red_terracotta
fill 130 187 286 132 187 286 minecraft:red_terracotta
fill 133 187 283 133 187 285 minecraft:red_terracotta
fill 94 188 275 94 189 276 minecraft:red_concrete
fill 94 188 277 94 189 278 minecraft:white_concrete
fill 94 188 279 94 189 279 minecraft:red_concrete
fill 94 188 281 94 189 282 minecraft:white_concrete
fill 94 188 283 94 189 284 minecraft:red_concrete
fill 94 188 285 94 189 286 minecraft:white_concrete
fill 94 188 287 94 189 287 minecraft:red_concrete
fill 94 188 289 94 189 290 minecraft:white_concrete
fill 94 188 291 94 189 292 minecraft:red_concrete
fill 94 188 293 94 189 294 minecraft:white_concrete
fill 94 188 295 94 189 295 minecraft:red_concrete
fill 94 188 297 94 189 298 minecraft:white_concrete
fill 94 188 299 94 189 300 minecraft:red_concrete
fill 94 188 301 94 189 302 minecraft:white_concrete
fill 94 188 303 94 189 303 minecraft:red_concrete
fill 94 188 305 94 189 306 minecraft:white_concrete
fill 94 188 307 94 189 308 minecraft:red_concrete
fill 94 188 309 94 189 310 minecraft:white_concrete
fill 94 188 311 94 189 311 minecraft:red_concrete
fill 94 188 313 94 189 314 minecraft:white_concrete
fill 94 188 315 94 189 316 minecraft:red_concrete
fill 95 188 275 95 189 275 minecraft:red_concrete
fill 95 188 317 95 189 317 minecraft:red_concrete
fill 96 188 275 97 189 275 minecraft:white_concrete
fill 96 188 317 96 189 317 minecraft:white_concrete
fill 98 188 275 99 189 275 minecraft:red_concrete
fill 98 188 317 99 189 317 minecraft:red_concrete
fill 100 188 275 100 189 275 minecraft:white_concrete
fill 100 188 317 101 189 317 minecraft:white_concrete
fill 102 188 275 103 189 275 minecraft:red_concrete
fill 102 188 317 103 189 317 minecraft:red_concrete
fill 104 188 275 105 189 275 minecraft:white_concrete
fill 104 188 317 104 189 317 minecraft:white_concrete
fill 106 188 275 107 189 275 minecraft:red_concrete
fill 106 188 317 107 189 317 minecraft:red_concrete
fill 108 188 275 108 189 275 minecraft:white_concrete
fill 108 188 317 109 189 317 minecraft:white_concrete
fill 110 188 275 111 189 275 minecraft:red_concrete
fill 110 188 317 111 189 317 minecraft:red_concrete
fill 112 188 275 113 189 275 minecraft:white_concrete
fill 112 188 317 112 189 317 minecraft:white_concrete
fill 114 188 275 115 189 275 minecraft:red_concrete
fill 114 188 317 115 189 317 minecraft:red_concrete
fill 116 188 275 116 189 275 minecraft:white_concrete
fill 116 188 317 117 189 317 minecraft:white_concrete
fill 118 188 275 119 189 275 minecraft:red_concrete
fill 118 188 317 119 189 317 minecraft:red_concrete
fill 120 188 275 121 189 275 minecraft:white_concrete
fill 120 188 317 120 189 317 minecraft:white_concrete
fill 122 188 275 123 189 275 minecraft:red_concrete
fill 122 188 317 123 189 317 minecraft:red_concrete
fill 124 188 275 124 189 275 minecraft:white_concrete
fill 124 188 317 125 189 317 minecraft:white_concrete
fill 126 188 275 127 189 275 minecraft:red_concrete
fill 126 188 317 127 189 317 minecraft:red_concrete
fill 128 188 275 129 189 275 minecraft:white_concrete
fill 128 188 317 128 189 317 minecraft:white_concrete
fill 130 188 275 131 189 275 minecraft:red_concrete
fill 130 188 317 131 189 317 minecraft:red_concrete
fill 132 188 275 132 189 275 minecraft:white_concrete
fill 132 188 317 133 189 317 minecraft:white_concrete
fill 134 188 275 135 189 275 minecraft:red_concrete
fill 134 188 317 135 189 317 minecraft:red_concrete
fill 136 188 276 136 189 276 minecraft:red_concrete
fill 136 188 277 136 189 278 minecraft:white_concrete
fill 136 188 279 136 189 279 minecraft:red_concrete
fill 136 188 281 136 189 282 minecraft:white_concrete
fill 136 188 283 136 189 284 minecraft:red_concrete
fill 136 188 285 136 189 286 minecraft:white_concrete
fill 136 188 287 136 189 287 minecraft:red_concrete
fill 136 188 289 136 189 290 minecraft:white_concrete
fill 136 188 291 136 189 292 minecraft:red_concrete
fill 136 188 293 136 189 294 minecraft:white_concrete
fill 136 188 295 136 189 295 minecraft:red_concrete
fill 136 188 297 136 189 298 minecraft:white_concrete
fill 136 188 299 136 189 300 minecraft:red_concrete
fill 136 188 301 136 189 302 minecraft:white_concrete
fill 136 188 303 136 189 303 minecraft:red_concrete
fill 136 188 305 136 189 306 minecraft:white_concrete
fill 136 188 307 136 189 308 minecraft:red_concrete
fill 136 188 309 136 189 310 minecraft:white_concrete
fill 136 188 311 136 189 311 minecraft:red_concrete
fill 136 188 313 136 189 314 minecraft:white_concrete
fill 136 188 315 136 189 316 minecraft:red_concrete
fill 136 188 317 136 189 317 minecraft:white_concrete
setblock 97 189 278 minecraft:light[level=15]
setblock 97 189 285 minecraft:light[level=12]
setblock 97 189 286 minecraft:light[level=15]
setblock 97 189 292 minecraft:light[level=12]
setblock 97 189 294 minecraft:light[level=15]
setblock 97 189 299 minecraft:light[level=12]
setblock 97 189 302 minecraft:light[level=15]
setblock 97 189 306 minecraft:light[level=12]
setblock 97 189 310 minecraft:light[level=15]
setblock 97 189 313 minecraft:light[level=12]
setblock 104 189 278 minecraft:light[level=12]
setblock 104 189 285 minecraft:light[level=12]
setblock 104 189 292 minecraft:light[level=12]
setblock 104 189 299 minecraft:light[level=12]
setblock 104 189 306 minecraft:light[level=12]
setblock 104 189 313 minecraft:light[level=12]
setblock 105 189 278 minecraft:light[level=15]
setblock 105 189 286 minecraft:light[level=15]
setblock 105 189 294 minecraft:light[level=15]
setblock 105 189 302 minecraft:light[level=15]
setblock 105 189 310 minecraft:light[level=15]
setblock 111 189 285 minecraft:light[level=12]
setblock 111 189 292 minecraft:light[level=12]
setblock 111 189 299 minecraft:light[level=12]
setblock 111 189 306 minecraft:light[level=12]
setblock 111 189 313 minecraft:light[level=12]
setblock 113 189 286 minecraft:light[level=15]
setblock 113 189 294 minecraft:light[level=15]
setblock 113 189 302 minecraft:light[level=15]
setblock 113 189 310 minecraft:light[level=15]
setblock 118 189 278 minecraft:light[level=12]
setblock 118 189 285 minecraft:light[level=12]
setblock 118 189 292 minecraft:light[level=12]
setblock 118 189 299 minecraft:light[level=12]
setblock 118 189 306 minecraft:light[level=12]
setblock 118 189 313 minecraft:light[level=12]
setblock 121 189 278 minecraft:light[level=15]
setblock 121 189 286 minecraft:light[level=15]
setblock 121 189 294 minecraft:light[level=15]
setblock 121 189 302 minecraft:light[level=15]
setblock 121 189 310 minecraft:light[level=15]
setblock 125 189 278 minecraft:light[level=12]
setblock 125 189 285 minecraft:light[level=12]
setblock 125 189 292 minecraft:light[level=12]
setblock 125 189 299 minecraft:light[level=12]
setblock 125 189 306 minecraft:light[level=12]
setblock 125 189 313 minecraft:light[level=12]
setblock 129 189 278 minecraft:light[level=15]
setblock 129 189 286 minecraft:light[level=15]
setblock 129 189 294 minecraft:light[level=15]
setblock 129 189 302 minecraft:light[level=15]
setblock 129 189 310 minecraft:light[level=15]
setblock 132 189 278 minecraft:light[level=12]
setblock 132 189 292 minecraft:light[level=12]
setblock 132 189 299 minecraft:light[level=12]
setblock 132 189 306 minecraft:light[level=12]
setblock 132 189 313 minecraft:light[level=12]
fill 94 190 275 94 191 276 minecraft:white_concrete
fill 94 190 277 94 191 278 minecraft:red_concrete
fill 94 190 279 94 191 279 minecraft:white_concrete
fill 94 190 281 94 191 282 minecraft:red_concrete
fill 94 190 283 94 191 284 minecraft:white_concrete
fill 94 190 285 94 191 286 minecraft:red_concrete
fill 94 190 287 94 191 287 minecraft:white_concrete
fill 94 190 289 94 191 290 minecraft:red_concrete
fill 94 190 291 94 191 292 minecraft:white_concrete
fill 94 190 293 94 191 294 minecraft:red_concrete
fill 94 190 295 94 191 295 minecraft:white_concrete
fill 94 190 297 94 191 298 minecraft:red_concrete
fill 94 190 299 94 191 300 minecraft:white_concrete
fill 94 190 301 94 191 302 minecraft:red_concrete
fill 94 190 303 94 191 303 minecraft:white_concrete
fill 94 190 305 94 191 306 minecraft:red_concrete
fill 94 190 307 94 191 308 minecraft:white_concrete
fill 94 190 309 94 191 310 minecraft:red_concrete
fill 94 190 311 94 191 311 minecraft:white_concrete
fill 94 190 313 94 191 314 minecraft:red_concrete
fill 94 190 315 94 191 316 minecraft:white_concrete
fill 95 190 275 95 191 275 minecraft:white_concrete
fill 95 190 317 95 191 317 minecraft:white_concrete
fill 96 190 275 97 191 275 minecraft:red_concrete
fill 96 190 317 96 191 317 minecraft:red_concrete
fill 98 190 275 99 191 275 minecraft:white_concrete
fill 98 190 317 99 191 317 minecraft:white_concrete
fill 100 190 275 100 191 275 minecraft:red_concrete
fill 100 190 317 101 191 317 minecraft:red_concrete
fill 102 190 275 103 191 275 minecraft:white_concrete
fill 102 190 317 103 191 317 minecraft:white_concrete
fill 104 190 275 105 191 275 minecraft:red_concrete
fill 104 190 317 104 191 317 minecraft:red_concrete
fill 106 190 275 107 191 275 minecraft:white_concrete
fill 106 190 317 107 191 317 minecraft:white_concrete
fill 108 190 275 108 191 275 minecraft:red_concrete
fill 108 190 317 109 191 317 minecraft:red_concrete
fill 110 190 275 111 191 275 minecraft:white_concrete
fill 110 190 317 111 191 317 minecraft:white_concrete
fill 112 190 275 113 191 275 minecraft:red_concrete
fill 112 190 317 112 191 317 minecraft:red_concrete
fill 114 190 275 115 191 275 minecraft:white_concrete
fill 114 190 317 115 191 317 minecraft:white_concrete
fill 116 190 275 116 191 275 minecraft:red_concrete
fill 116 190 317 117 191 317 minecraft:red_concrete
fill 118 190 275 119 191 275 minecraft:white_concrete
fill 118 190 317 119 191 317 minecraft:white_concrete
fill 120 190 275 121 191 275 minecraft:red_concrete
fill 120 190 317 120 191 317 minecraft:red_concrete
fill 122 190 275 123 191 275 minecraft:white_concrete
fill 122 190 317 123 191 317 minecraft:white_concrete
fill 124 190 275 124 191 275 minecraft:red_concrete
fill 124 190 317 125 191 317 minecraft:red_concrete
fill 126 190 275 127 191 275 minecraft:white_concrete
fill 126 190 317 127 191 317 minecraft:white_concrete
fill 128 190 275 129 191 275 minecraft:red_concrete
fill 128 190 317 128 191 317 minecraft:red_concrete
fill 130 190 275 131 191 275 minecraft:white_concrete
fill 130 190 317 131 191 317 minecraft:white_concrete
fill 132 190 275 132 191 275 minecraft:red_concrete
fill 132 190 317 133 191 317 minecraft:red_concrete
fill 134 190 275 135 191 275 minecraft:white_concrete
fill 134 190 317 135 191 317 minecraft:white_concrete
fill 136 190 276 136 191 276 minecraft:white_concrete
fill 136 190 277 136 191 278 minecraft:red_concrete
fill 136 190 279 136 191 279 minecraft:white_concrete
fill 136 190 281 136 191 282 minecraft:red_concrete
fill 136 190 283 136 191 284 minecraft:white_concrete
fill 136 190 285 136 191 286 minecraft:red_concrete
fill 136 190 287 136 191 287 minecraft:white_concrete
fill 136 190 289 136 191 290 minecraft:red_concrete
fill 136 190 291 136 191 292 minecraft:white_concrete
fill 136 190 293 136 191 294 minecraft:red_concrete
fill 136 190 295 136 191 295 minecraft:white_concrete
fill 136 190 297 136 191 298 minecraft:red_concrete
fill 136 190 299 136 191 300 minecraft:white_concrete
fill 136 190 301 136 191 302 minecraft:red_concrete
fill 136 190 303 136 191 303 minecraft:white_concrete
fill 136 190 305 136 191 306 minecraft:red_concrete
fill 136 190 307 136 191 308 minecraft:white_concrete
fill 136 190 309 136 191 310 minecraft:red_concrete
fill 136 190 311 136 191 311 minecraft:white_concrete
fill 136 190 313 136 191 314 minecraft:red_concrete
fill 136 190 315 136 191 316 minecraft:white_concrete
fill 136 190 317 136 191 317 minecraft:red_concrete
fill 129 191 305 130 192 306 minecraft:green_concrete
fill 94 192 275 94 193 276 minecraft:red_concrete
fill 94 192 277 94 193 278 minecraft:white_concrete
fill 94 192 279 94 193 280 minecraft:red_concrete
fill 94 192 281 94 193 282 minecraft:white_concrete
fill 94 192 283 94 193 284 minecraft:red_concrete
fill 94 192 285 94 193 286 minecraft:white_concrete
fill 94 192 287 94 193 288 minecraft:red_concrete
fill 94 192 289 94 193 290 minecraft:white_concrete
fill 94 192 291 94 193 292 minecraft:red_concrete
fill 94 192 293 94 193 294 minecraft:white_concrete
fill 94 192 295 94 193 296 minecraft:red_concrete
fill 94 192 297 94 193 298 minecraft:white_concrete
fill 94 192 299 94 193 300 minecraft:red_concrete
fill 94 192 301 94 193 302 minecraft:white_concrete
fill 94 192 303 94 193 304 minecraft:red_concrete
fill 94 192 305 94 193 306 minecraft:white_concrete
fill 94 192 307 94 193 308 minecraft:red_concrete
fill 94 192 309 94 193 310 minecraft:white_concrete
fill 94 192 311 94 193 312 minecraft:red_concrete
fill 94 192 313 94 193 314 minecraft:white_concrete
fill 94 192 315 94 193 316 minecraft:red_concrete
fill 95 192 275 95 193 275 minecraft:red_concrete
fill 95 192 317 95 193 317 minecraft:red_concrete
fill 96 192 275 97 193 275 minecraft:white_concrete
fill 96 192 317 97 193 317 minecraft:white_concrete
fill 98 192 275 99 193 275 minecraft:red_concrete
fill 98 192 317 99 193 317 minecraft:red_concrete
fill 100 192 275 101 193 275 minecraft:white_concrete
fill 100 192 317 101 193 317 minecraft:white_concrete
fill 102 192 275 103 193 275 minecraft:red_concrete
fill 102 192 317 103 193 317 minecraft:red_concrete
fill 104 192 275 105 193 275 minecraft:white_concrete
fill 104 192 317 105 193 317 minecraft:white_concrete
fill 106 192 275 107 193 275 minecraft:red_concrete
fill 106 192 317 107 193 317 minecraft:red_concrete
fill 108 192 275 109 193 275 minecraft:white_concrete
fill 108 192 317 109 193 317 minecraft:white_concrete
fill 110 192 275 111 193 275 minecraft:red_concrete
fill 110 192 317 111 193 317 minecraft:red_concrete
fill 112 192 275 113 193 275 minecraft:white_concrete
fill 112 192 317 113 193 317 minecraft:white_concrete
fill 114 192 275 115 193 275 minecraft:red_concrete
fill 114 192 317 115 193 317 minecraft:red_concrete
fill 116 192 275 117 193 275 minecraft:white_concrete
fill 116 192 317 117 193 317 minecraft:white_concrete
fill 118 192 275 119 193 275 minecraft:red_concrete
fill 118 192 317 119 193 317 minecraft:red_concrete
fill 120 192 275 121 193 275 minecraft:white_concrete
fill 120 192 317 121 193 317 minecraft:white_concrete
fill 122 192 275 123 193 275 minecraft:red_concrete
fill 122 192 317 123 193 317 minecraft:red_concrete
fill 124 192 275 125 193 275 minecraft:white_concrete
fill 124 192 317 125 193 317 minecraft:white_concrete
fill 126 192 275 127 193 275 minecraft:red_concrete
fill 126 192 317 127 193 317 minecraft:red_concrete
fill 128 192 275 129 193 275 minecraft:white_concrete
fill 128 192 317 129 193 317 minecraft:white_concrete
fill 130 192 275 131 193 275 minecraft:red_concrete
fill 130 192 317 131 193 317 minecraft:red_concrete
fill 132 192 275 133 193 275 minecraft:white_concrete
fill 132 192 317 133 193 317 minecraft:white_concrete
fill 134 192 275 135 193 275 minecraft:red_concrete
fill 134 192 317 135 193 317 minecraft:red_concrete
fill 136 192 276 136 193 276 minecraft:red_concrete
fill 136 192 277 136 193 278 minecraft:white_concrete
fill 136 192 279 136 193 280 minecraft:red_concrete
fill 136 192 281 136 193 282 minecraft:white_concrete
fill 136 192 283 136 193 284 minecraft:red_concrete
fill 136 192 285 136 193 286 minecraft:white_concrete
fill 136 192 287 136 193 288 minecraft:red_concrete
fill 136 192 289 136 193 290 minecraft:white_concrete
fill 136 192 291 136 193 292 minecraft:red_concrete
fill 136 192 293 136 193 294 minecraft:white_concrete
fill 136 192 295 136 193 296 minecraft:red_concrete
fill 136 192 297 136 193 298 minecraft:white_concrete
fill 136 192 299 136 193 300 minecraft:red_concrete
fill 136 192 301 136 193 302 minecraft:white_concrete
fill 136 192 303 136 193 304 minecraft:red_concrete
fill 136 192 305 136 193 306 minecraft:white_concrete
fill 136 192 307 136 193 308 minecraft:red_concrete
fill 136 192 309 136 193 310 minecraft:white_concrete
fill 136 192 311 136 193 312 minecraft:red_concrete
fill 136 192 313 136 193 314 minecraft:white_concrete
fill 136 192 315 136 193 316 minecraft:red_concrete
fill 136 192 317 136 193 317 minecraft:white_concrete
setblock 97 193 310 minecraft:brown_terracotta
setblock 97 193 313 minecraft:brown_terracotta
fill 98 193 314 99 193 314 minecraft:brown_terracotta
setblock 99 193 309 minecraft:brown_terracotta
setblock 100 193 310 minecraft:brown_terracotta
setblock 100 193 313 minecraft:brown_terracotta
fill 101 193 311 101 193 312 minecraft:brown_terracotta
fill 94 194 275 94 195 276 minecraft:white_concrete
fill 94 194 277 94 195 278 minecraft:red_concrete
fill 94 194 279 94 195 280 minecraft:white_concrete
fill 94 194 281 94 195 282 minecraft:red_concrete
fill 94 194 283 94 195 284 minecraft:white_concrete
fill 94 194 285 94 195 286 minecraft:red_concrete
fill 94 194 287 94 195 288 minecraft:white_concrete
fill 94 194 289 94 195 290 minecraft:red_concrete
fill 94 194 291 94 195 292 minecraft:white_concrete
fill 94 194 293 94 195 294 minecraft:red_concrete
fill 94 194 295 94 195 296 minecraft:white_concrete
fill 94 194 297 94 195 298 minecraft:red_concrete
fill 94 194 299 94 195 300 minecraft:white_concrete
fill 94 194 301 94 195 302 minecraft:red_concrete
fill 94 194 303 94 195 304 minecraft:white_concrete
fill 94 194 305 94 195 306 minecraft:red_concrete
fill 94 194 307 94 195 308 minecraft:white_concrete
fill 94 194 309 94 195 310 minecraft:red_concrete
fill 94 194 311 94 195 312 minecraft:white_concrete
fill 94 194 313 94 195 314 minecraft:red_concrete
fill 94 194 315 94 195 316 minecraft:white_concrete
fill 95 194 275 95 195 275 minecraft:white_concrete
fill 95 194 317 95 195 317 minecraft:white_concrete
fill 96 194 275 97 195 275 minecraft:red_concrete
fill 96 194 317 97 195 317 minecraft:red_concrete
fill 98 194 275 99 195 275 minecraft:white_concrete
fill 98 194 317 99 195 317 minecraft:white_concrete
fill 100 194 275 101 195 275 minecraft:red_concrete
fill 100 194 317 101 195 317 minecraft:red_concrete
fill 102 194 275 103 195 275 minecraft:white_concrete
fill 102 194 317 103 195 317 minecraft:white_concrete
fill 104 194 275 105 195 275 minecraft:red_concrete
fill 104 194 317 105 195 317 minecraft:red_concrete
fill 106 194 275 107 195 275 minecraft:white_concrete
fill 106 194 317 107 195 317 minecraft:white_concrete
fill 108 194 275 109 195 275 minecraft:red_concrete
fill 108 194 317 109 195 317 minecraft:red_concrete
fill 110 194 275 111 195 275 minecraft:white_concrete
fill 110 194 317 111 195 317 minecraft:white_concrete
fill 112 194 275 113 195 275 minecraft:red_concrete
fill 112 194 317 113 195 317 minecraft:red_concrete
fill 114 194 275 115 195 275 minecraft:white_concrete
fill 114 194 317 115 195 317 minecraft:white_concrete
fill 116 194 275 117 195 275 minecraft:red_concrete
fill 116 194 317 117 195 317 minecraft:red_concrete
fill 118 194 275 119 195 275 minecraft:white_concrete
fill 118 194 317 119 195 317 minecraft:white_concrete
fill 120 194 275 121 195 275 minecraft:red_concrete
fill 120 194 317 121 195 317 minecraft:red_concrete
fill 122 194 275 123 195 275 minecraft:white_concrete
fill 122 194 317 123 195 317 minecraft:white_concrete
fill 124 194 275 125 195 275 minecraft:red_concrete
fill 124 194 317 125 195 317 minecraft:red_concrete
fill 126 194 275 127 195 275 minecraft:white_concrete
fill 126 194 317 127 195 317 minecraft:white_concrete
fill 128 194 275 129 195 275 minecraft:red_concrete
fill 128 194 317 129 195 317 minecraft:red_concrete
fill 130 194 275 131 195 275 minecraft:white_concrete
fill 130 194 317 131 195 317 minecraft:white_concrete
fill 132 194 275 133 195 275 minecraft:red_concrete
fill 132 194 317 133 195 317 minecraft:red_concrete
fill 134 194 275 135 195 275 minecraft:white_concrete
fill 134 194 317 135 195 317 minecraft:white_concrete
fill 136 194 276 136 195 276 minecraft:white_concrete
fill 136 194 277 136 195 278 minecraft:red_concrete
fill 136 194 279 136 195 280 minecraft:white_concrete
fill 136 194 281 136 195 282 minecraft:red_concrete
fill 136 194 283 136 195 284 minecraft:white_concrete
fill 136 194 285 136 195 286 minecraft:red_concrete
fill 136 194 287 136 195 288 minecraft:white_concrete
fill 136 194 289 136 195 290 minecraft:red_concrete
fill 136 194 291 136 195 292 minecraft:white_concrete
fill 136 194 293 136 195 294 minecraft:red_concrete
fill 136 194 295 136 195 296 minecraft:white_concrete
fill 136 194 297 136 195 298 minecraft:red_concrete
fill 136 194 299 136 195 300 minecraft:white_concrete
fill 136 194 301 136 195 302 minecraft:red_concrete
fill 136 194 303 136 195 304 minecraft:white_concrete
fill 136 194 305 136 195 306 minecraft:red_concrete
fill 136 194 307 136 195 308 minecraft:white_concrete
schedule function dropper:buildpart/62_5 1t
