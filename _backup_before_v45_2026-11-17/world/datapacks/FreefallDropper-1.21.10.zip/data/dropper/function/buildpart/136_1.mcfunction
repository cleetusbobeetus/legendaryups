fill 224 117 592 226 117 592 minecraft:yellow_terracotta
fill 224 117 593 226 170 595 minecraft:quartz_block
fill 224 117 596 227 117 596 minecraft:yellow_terracotta
fill 225 117 558 227 170 558 minecraft:quartz_block
setblock 227 117 593 minecraft:yellow_terracotta
fill 227 117 594 227 170 594 minecraft:quartz_block
setblock 227 117 595 minecraft:yellow_terracotta
fill 229 117 557 229 207 557 minecraft:yellow_terracotta
fill 229 117 566 229 170 568 minecraft:quartz_block
fill 229 117 578 229 170 580 minecraft:quartz_block
fill 229 117 590 229 170 592 minecraft:quartz_block
fill 230 117 573 230 125 573 minecraft:yellow_terracotta
fill 230 117 577 230 210 577 minecraft:yellow_terracotta
fill 230 117 581 230 125 582 minecraft:yellow_terracotta
fill 190 120 567 190 125 569 minecraft:quartz_block
fill 190 120 579 190 125 581 minecraft:quartz_block
fill 190 120 591 190 125 593 minecraft:quartz_block
fill 196 120 597 198 125 597 minecraft:quartz_block
fill 200 120 559 202 125 559 minecraft:quartz_block
fill 208 120 597 210 125 597 minecraft:quartz_block
fill 212 120 559 214 125 559 minecraft:quartz_block
fill 220 120 597 222 125 597 minecraft:quartz_block
fill 224 120 559 226 125 559 minecraft:quartz_block
fill 228 120 567 228 125 569 minecraft:quartz_block
fill 228 120 579 228 125 581 minecraft:quartz_block
fill 228 120 591 228 125 593 minecraft:quartz_block
fill 217 121 563 218 122 563 minecraft:gold_block
setblock 191 122 560 minecraft:light[level=14]
setblock 191 122 568 minecraft:light[level=14]
setblock 191 122 576 minecraft:light[level=14]
setblock 191 122 584 minecraft:light[level=14]
setblock 191 122 592 minecraft:light[level=14]
setblock 199 122 560 minecraft:light[level=14]
setblock 199 122 568 minecraft:light[level=14]
setblock 199 122 576 minecraft:light[level=14]
setblock 199 122 584 minecraft:light[level=14]
setblock 199 122 592 minecraft:light[level=14]
fill 202 122 596 208 123 596 minecraft:gold_block
setblock 207 122 560 minecraft:light[level=14]
setblock 207 122 568 minecraft:light[level=14]
setblock 207 122 576 minecraft:light[level=14]
setblock 207 122 584 minecraft:light[level=14]
setblock 207 122 592 minecraft:light[level=14]
setblock 215 122 560 minecraft:light[level=14]
setblock 215 122 568 minecraft:light[level=14]
setblock 215 122 576 minecraft:light[level=14]
setblock 215 122 584 minecraft:light[level=14]
setblock 215 122 592 minecraft:light[level=14]
setblock 223 122 560 minecraft:light[level=14]
setblock 223 122 568 minecraft:light[level=14]
setblock 223 122 576 minecraft:light[level=14]
setblock 223 122 584 minecraft:light[level=14]
setblock 223 122 592 minecraft:light[level=14]
fill 189 125 561 189 125 566 minecraft:yellow_terracotta
fill 189 125 573 189 125 578 minecraft:yellow_terracotta
fill 189 125 585 189 125 590 minecraft:yellow_terracotta
fill 189 125 597 189 125 598 minecraft:yellow_terracotta
fill 190 125 598 193 125 598 minecraft:yellow_terracotta
fill 193 125 558 198 125 558 minecraft:yellow_terracotta
fill 200 125 598 205 125 598 minecraft:yellow_terracotta
fill 205 125 558 210 125 558 minecraft:yellow_terracotta
fill 212 125 598 217 125 598 minecraft:yellow_terracotta
fill 217 125 558 222 125 558 minecraft:yellow_terracotta
fill 223 125 593 223 125 595 minecraft:yellow_terracotta
fill 224 125 592 226 125 592 minecraft:yellow_terracotta
fill 224 125 596 227 125 596 minecraft:yellow_terracotta
fill 224 125 598 229 125 598 minecraft:yellow_terracotta
setblock 227 125 593 minecraft:yellow_terracotta
setblock 227 125 595 minecraft:yellow_terracotta
fill 229 125 558 229 125 563 minecraft:yellow_terracotta
fill 229 125 570 229 125 575 minecraft:yellow_terracotta
fill 229 125 582 229 125 587 minecraft:yellow_terracotta
fill 229 125 594 229 125 597 minecraft:yellow_terracotta
fill 188 126 557 188 206 562 minecraft:yellow_terracotta
fill 188 126 563 188 131 566 minecraft:ochre_froglight
fill 188 126 567 188 206 571 minecraft:yellow_terracotta
fill 188 126 575 188 131 578 minecraft:ochre_froglight
fill 188 126 579 188 207 583 minecraft:yellow_terracotta
fill 188 126 586 188 210 586 minecraft:yellow_terracotta
fill 188 126 587 188 131 590 minecraft:ochre_froglight
fill 188 126 591 188 210 591 minecraft:yellow_terracotta
fill 188 126 593 188 206 598 minecraft:yellow_terracotta
fill 188 126 599 191 131 599 minecraft:ochre_froglight
fill 192 126 599 192 210 599 minecraft:yellow_terracotta
fill 193 126 557 194 208 557 minecraft:yellow_terracotta
fill 195 126 557 198 131 557 minecraft:ochre_froglight
fill 198 126 599 199 210 599 minecraft:yellow_terracotta
fill 199 126 557 206 208 557 minecraft:yellow_terracotta
fill 200 126 599 203 131 599 minecraft:ochre_froglight
fill 204 126 599 205 206 599 minecraft:yellow_terracotta
fill 207 126 557 210 131 557 minecraft:ochre_froglight
fill 208 126 599 211 206 599 minecraft:yellow_terracotta
fill 211 126 557 212 208 557 minecraft:yellow_terracotta
fill 212 126 599 215 131 599 minecraft:ochre_froglight
fill 216 126 599 219 210 599 minecraft:yellow_terracotta
fill 217 126 557 218 207 557 minecraft:yellow_terracotta
fill 219 126 557 222 131 557 minecraft:ochre_froglight
fill 223 126 557 228 207 557 minecraft:yellow_terracotta
fill 224 126 599 227 131 599 minecraft:ochre_froglight
fill 230 126 558 230 131 561 minecraft:ochre_froglight
fill 230 126 562 230 207 567 minecraft:yellow_terracotta
fill 230 126 569 230 207 569 minecraft:yellow_terracotta
fill 230 126 570 230 131 573 minecraft:ochre_froglight
fill 230 126 581 230 210 581 minecraft:yellow_terracotta
fill 230 126 582 230 131 585 minecraft:ochre_froglight
fill 230 126 586 230 210 586 minecraft:yellow_terracotta
fill 230 126 588 230 210 593 minecraft:yellow_terracotta
fill 230 126 594 230 131 597 minecraft:ochre_froglight
fill 220 129 583 220 130 584 minecraft:raw_gold_block
setblock 191 130 560 minecraft:light[level=14]
setblock 191 130 568 minecraft:light[level=14]
setblock 191 130 576 minecraft:light[level=14]
setblock 191 130 584 minecraft:light[level=14]
setblock 191 130 592 minecraft:light[level=14]
setblock 199 130 560 minecraft:light[level=14]
setblock 199 130 568 minecraft:light[level=14]
setblock 199 130 576 minecraft:light[level=14]
setblock 199 130 584 minecraft:light[level=14]
setblock 199 130 592 minecraft:light[level=14]
setblock 207 130 560 minecraft:light[level=14]
setblock 207 130 568 minecraft:light[level=14]
setblock 207 130 576 minecraft:light[level=14]
setblock 207 130 584 minecraft:light[level=14]
setblock 207 130 592 minecraft:light[level=14]
setblock 215 130 560 minecraft:light[level=14]
setblock 215 130 568 minecraft:light[level=14]
setblock 215 130 576 minecraft:light[level=14]
setblock 215 130 584 minecraft:light[level=14]
setblock 215 130 592 minecraft:light[level=14]
setblock 223 130 560 minecraft:light[level=14]
setblock 223 130 568 minecraft:light[level=14]
setblock 223 130 576 minecraft:light[level=14]
setblock 223 130 584 minecraft:light[level=14]
setblock 223 130 592 minecraft:light[level=14]
fill 188 132 563 188 145 563 minecraft:yellow_terracotta
fill 188 132 564 188 132 565 minecraft:ochre_froglight
fill 188 132 566 188 145 566 minecraft:yellow_terracotta
fill 188 132 575 188 145 575 minecraft:yellow_terracotta
fill 188 132 576 188 132 577 minecraft:ochre_froglight
fill 188 132 578 188 145 578 minecraft:yellow_terracotta
fill 188 132 587 188 145 587 minecraft:yellow_terracotta
fill 188 132 588 188 132 589 minecraft:ochre_froglight
fill 188 132 590 188 145 590 minecraft:yellow_terracotta
fill 188 132 599 188 145 599 minecraft:yellow_terracotta
fill 189 132 599 190 132 599 minecraft:ochre_froglight
fill 191 132 599 191 145 599 minecraft:yellow_terracotta
fill 195 132 557 195 145 557 minecraft:yellow_terracotta
fill 196 132 557 197 132 557 minecraft:ochre_froglight
fill 198 132 557 198 145 557 minecraft:yellow_terracotta
fill 200 132 599 200 145 599 minecraft:yellow_terracotta
fill 201 132 599 202 132 599 minecraft:ochre_froglight
fill 203 132 599 203 145 599 minecraft:yellow_terracotta
fill 207 132 557 207 145 557 minecraft:yellow_terracotta
fill 208 132 557 209 132 557 minecraft:ochre_froglight
fill 210 132 557 210 145 557 minecraft:yellow_terracotta
fill 212 132 599 212 145 599 minecraft:yellow_terracotta
fill 213 132 599 214 132 599 minecraft:ochre_froglight
fill 215 132 599 215 145 599 minecraft:yellow_terracotta
fill 219 132 557 219 145 557 minecraft:yellow_terracotta
fill 220 132 557 221 132 557 minecraft:ochre_froglight
fill 222 132 557 222 145 557 minecraft:yellow_terracotta
fill 224 132 599 224 145 599 minecraft:yellow_terracotta
fill 225 132 599 226 132 599 minecraft:ochre_froglight
fill 227 132 599 227 145 599 minecraft:yellow_terracotta
fill 230 132 558 230 145 558 minecraft:yellow_terracotta
fill 230 132 559 230 132 560 minecraft:ochre_froglight
fill 230 132 561 230 145 561 minecraft:yellow_terracotta
fill 230 132 570 230 145 570 minecraft:yellow_terracotta
fill 230 132 571 230 132 572 minecraft:ochre_froglight
fill 230 132 573 230 145 573 minecraft:yellow_terracotta
fill 230 132 582 230 145 582 minecraft:yellow_terracotta
fill 230 132 583 230 132 584 minecraft:ochre_froglight
fill 230 132 585 230 145 585 minecraft:yellow_terracotta
fill 230 132 594 230 145 594 minecraft:yellow_terracotta
fill 230 132 595 230 132 596 minecraft:ochre_froglight
fill 230 132 597 230 145 597 minecraft:yellow_terracotta
fill 188 133 564 188 145 565 minecraft:yellow_terracotta
fill 188 133 576 188 145 577 minecraft:yellow_terracotta
fill 188 133 588 188 145 589 minecraft:yellow_terracotta
fill 189 133 599 190 145 599 minecraft:yellow_terracotta
fill 196 133 557 197 145 557 minecraft:yellow_terracotta
fill 201 133 599 202 145 599 minecraft:yellow_terracotta
fill 208 133 557 209 145 557 minecraft:yellow_terracotta
fill 213 133 599 214 145 599 minecraft:yellow_terracotta
fill 220 133 557 221 145 557 minecraft:yellow_terracotta
fill 223 133 593 223 133 595 minecraft:yellow_terracotta
fill 224 133 592 226 133 592 minecraft:yellow_terracotta
fill 224 133 596 227 133 596 minecraft:yellow_terracotta
fill 225 133 599 226 145 599 minecraft:yellow_terracotta
setblock 227 133 593 minecraft:yellow_terracotta
setblock 227 133 595 minecraft:yellow_terracotta
fill 230 133 559 230 145 560 minecraft:yellow_terracotta
fill 230 133 571 230 145 572 minecraft:yellow_terracotta
fill 230 133 583 230 145 584 minecraft:yellow_terracotta
fill 230 133 595 230 145 596 minecraft:yellow_terracotta
fill 197 135 591 198 136 592 minecraft:gold_block
fill 193 136 584 194 137 584 minecraft:gold_block
setblock 191 138 560 minecraft:light[level=14]
setblock 191 138 568 minecraft:light[level=14]
setblock 191 138 576 minecraft:light[level=14]
setblock 191 138 584 minecraft:light[level=14]
setblock 191 138 592 minecraft:light[level=14]
setblock 199 138 560 minecraft:light[level=14]
setblock 199 138 568 minecraft:light[level=14]
setblock 199 138 576 minecraft:light[level=14]
setblock 199 138 584 minecraft:light[level=14]
setblock 199 138 592 minecraft:light[level=14]
setblock 207 138 560 minecraft:light[level=14]
setblock 207 138 568 minecraft:light[level=14]
setblock 207 138 576 minecraft:light[level=14]
setblock 207 138 584 minecraft:light[level=14]
setblock 207 138 592 minecraft:light[level=14]
setblock 215 138 560 minecraft:light[level=14]
setblock 215 138 568 minecraft:light[level=14]
setblock 215 138 576 minecraft:light[level=14]
setblock 215 138 584 minecraft:light[level=14]
setblock 215 138 592 minecraft:light[level=14]
setblock 223 138 560 minecraft:light[level=14]
setblock 223 138 568 minecraft:light[level=14]
setblock 223 138 576 minecraft:light[level=14]
setblock 223 138 584 minecraft:light[level=14]
setblock 223 138 592 minecraft:light[level=14]
fill 190 140 567 190 145 569 minecraft:quartz_block
fill 190 140 579 190 145 581 minecraft:quartz_block
fill 190 140 591 190 145 593 minecraft:quartz_block
fill 196 140 597 198 145 597 minecraft:quartz_block
fill 200 140 559 202 145 559 minecraft:quartz_block
fill 208 140 597 210 145 597 minecraft:quartz_block
fill 212 140 559 214 145 559 minecraft:quartz_block
fill 220 140 597 222 145 597 minecraft:quartz_block
fill 224 140 559 226 145 559 minecraft:quartz_block
fill 228 140 567 228 145 569 minecraft:quartz_block
fill 228 140 579 228 145 581 minecraft:quartz_block
fill 228 140 591 228 145 593 minecraft:quartz_block
fill 223 141 593 223 141 595 minecraft:yellow_terracotta
fill 224 141 592 226 141 592 minecraft:yellow_terracotta
fill 224 141 596 227 141 596 minecraft:yellow_terracotta
setblock 227 141 593 minecraft:yellow_terracotta
setblock 227 141 595 minecraft:yellow_terracotta
fill 189 145 561 189 145 566 minecraft:yellow_terracotta
fill 189 145 573 189 145 578 minecraft:yellow_terracotta
fill 189 145 585 189 145 590 minecraft:yellow_terracotta
fill 189 145 597 189 145 598 minecraft:yellow_terracotta
fill 190 145 598 193 145 598 minecraft:yellow_terracotta
fill 193 145 558 198 145 558 minecraft:yellow_terracotta
fill 200 145 598 205 145 598 minecraft:yellow_terracotta
fill 205 145 558 210 145 558 minecraft:yellow_terracotta
fill 212 145 598 217 145 598 minecraft:yellow_terracotta
fill 217 145 558 222 145 558 minecraft:yellow_terracotta
fill 224 145 598 229 145 598 minecraft:yellow_terracotta
fill 229 145 558 229 145 563 minecraft:yellow_terracotta
fill 229 145 570 229 145 575 minecraft:yellow_terracotta
fill 229 145 582 229 145 587 minecraft:yellow_terracotta
fill 229 145 594 229 145 597 minecraft:yellow_terracotta
fill 188 146 563 188 151 566 minecraft:ochre_froglight
fill 188 146 575 188 151 578 minecraft:ochre_froglight
fill 188 146 587 188 151 590 minecraft:ochre_froglight
fill 188 146 599 191 151 599 minecraft:ochre_froglight
setblock 191 146 560 minecraft:light[level=14]
setblock 191 146 568 minecraft:light[level=14]
setblock 191 146 576 minecraft:light[level=14]
setblock 191 146 584 minecraft:light[level=14]
setblock 191 146 592 minecraft:light[level=14]
fill 195 146 557 198 151 557 minecraft:ochre_froglight
setblock 199 146 560 minecraft:light[level=14]
setblock 199 146 568 minecraft:light[level=14]
setblock 199 146 576 minecraft:light[level=14]
setblock 199 146 584 minecraft:light[level=14]
setblock 199 146 592 minecraft:light[level=14]
fill 200 146 599 203 151 599 minecraft:ochre_froglight
fill 207 146 557 210 151 557 minecraft:ochre_froglight
setblock 207 146 560 minecraft:light[level=14]
setblock 207 146 568 minecraft:light[level=14]
setblock 207 146 576 minecraft:light[level=14]
setblock 207 146 584 minecraft:light[level=14]
setblock 207 146 592 minecraft:light[level=14]
fill 212 146 599 215 151 599 minecraft:ochre_froglight
setblock 215 146 560 minecraft:light[level=14]
setblock 215 146 568 minecraft:light[level=14]
setblock 215 146 576 minecraft:light[level=14]
setblock 215 146 584 minecraft:light[level=14]
setblock 215 146 592 minecraft:light[level=14]
fill 219 146 557 222 151 557 minecraft:ochre_froglight
setblock 223 146 560 minecraft:light[level=14]
setblock 223 146 568 minecraft:light[level=14]
setblock 223 146 576 minecraft:light[level=14]
setblock 223 146 584 minecraft:light[level=14]
setblock 223 146 592 minecraft:light[level=14]
fill 224 146 599 227 151 599 minecraft:ochre_froglight
fill 230 146 558 230 151 561 minecraft:ochre_froglight
fill 230 146 570 230 151 573 minecraft:ochre_froglight
fill 230 146 582 230 151 585 minecraft:ochre_froglight
fill 230 146 594 230 151 597 minecraft:ochre_froglight
fill 191 147 577 191 148 577 minecraft:raw_gold_block
fill 190 149 566 190 157 566 minecraft:red_wool
fill 199 149 571 200 150 571 minecraft:raw_gold_block
fill 223 149 593 223 149 595 minecraft:yellow_terracotta
fill 224 149 592 226 149 592 minecraft:yellow_terracotta
fill 224 149 596 227 149 596 minecraft:yellow_terracotta
setblock 227 149 593 minecraft:yellow_terracotta
setblock 227 149 595 minecraft:yellow_terracotta
fill 190 150 564 190 157 565 minecraft:red_wool
fill 190 150 567 190 157 568 minecraft:red_wool
fill 195 151 573 196 152 573 minecraft:gold_block
fill 188 152 563 188 165 563 minecraft:yellow_terracotta
fill 188 152 564 188 152 565 minecraft:ochre_froglight
fill 188 152 566 188 165 566 minecraft:yellow_terracotta
fill 188 152 575 188 165 575 minecraft:yellow_terracotta
fill 188 152 576 188 152 577 minecraft:ochre_froglight
fill 188 152 578 188 165 578 minecraft:yellow_terracotta
fill 188 152 587 188 165 587 minecraft:yellow_terracotta
fill 188 152 588 188 152 589 minecraft:ochre_froglight
fill 188 152 590 188 165 590 minecraft:yellow_terracotta
fill 188 152 599 188 165 599 minecraft:yellow_terracotta
fill 189 152 599 190 152 599 minecraft:ochre_froglight
fill 191 152 599 191 165 599 minecraft:yellow_terracotta
fill 195 152 557 195 165 557 minecraft:yellow_terracotta
fill 196 152 557 197 152 557 minecraft:ochre_froglight
fill 198 152 557 198 165 557 minecraft:yellow_terracotta
fill 200 152 599 200 165 599 minecraft:yellow_terracotta
fill 201 152 599 202 152 599 minecraft:ochre_froglight
fill 203 152 599 203 165 599 minecraft:yellow_terracotta
fill 207 152 557 207 165 557 minecraft:yellow_terracotta
fill 208 152 557 209 152 557 minecraft:ochre_froglight
fill 210 152 557 210 165 557 minecraft:yellow_terracotta
fill 212 152 599 212 165 599 minecraft:yellow_terracotta
fill 213 152 599 214 152 599 minecraft:ochre_froglight
fill 215 152 599 215 165 599 minecraft:yellow_terracotta
fill 219 152 557 219 165 557 minecraft:yellow_terracotta
fill 220 152 557 221 152 557 minecraft:ochre_froglight
fill 222 152 557 222 165 557 minecraft:yellow_terracotta
fill 224 152 599 224 165 599 minecraft:yellow_terracotta
fill 225 152 599 226 152 599 minecraft:ochre_froglight
fill 227 152 599 227 165 599 minecraft:yellow_terracotta
fill 230 152 558 230 165 558 minecraft:yellow_terracotta
fill 230 152 559 230 152 560 minecraft:ochre_froglight
fill 230 152 561 230 165 561 minecraft:yellow_terracotta
fill 230 152 570 230 165 570 minecraft:yellow_terracotta
fill 230 152 571 230 152 572 minecraft:ochre_froglight
fill 230 152 573 230 165 573 minecraft:yellow_terracotta
fill 230 152 582 230 165 582 minecraft:yellow_terracotta
fill 230 152 583 230 152 584 minecraft:ochre_froglight
fill 230 152 585 230 165 585 minecraft:yellow_terracotta
fill 230 152 594 230 165 594 minecraft:yellow_terracotta
fill 230 152 595 230 152 596 minecraft:ochre_froglight
fill 230 152 597 230 165 597 minecraft:yellow_terracotta
fill 188 153 564 188 165 565 minecraft:yellow_terracotta
fill 188 153 576 188 165 577 minecraft:yellow_terracotta
fill 188 153 588 188 165 589 minecraft:yellow_terracotta
fill 189 153 599 190 165 599 minecraft:yellow_terracotta
fill 196 153 557 197 165 557 minecraft:yellow_terracotta
fill 201 153 599 202 165 599 minecraft:yellow_terracotta
fill 208 153 557 209 165 557 minecraft:yellow_terracotta
fill 213 153 599 214 165 599 minecraft:yellow_terracotta
fill 220 153 557 221 165 557 minecraft:yellow_terracotta
fill 225 153 599 226 165 599 minecraft:yellow_terracotta
fill 230 153 559 230 165 560 minecraft:yellow_terracotta
fill 230 153 571 230 165 572 minecraft:yellow_terracotta
fill 230 153 583 230 165 584 minecraft:yellow_terracotta
fill 230 153 595 230 165 596 minecraft:yellow_terracotta
setblock 191 154 560 minecraft:light[level=14]
setblock 191 154 568 minecraft:light[level=14]
setblock 191 154 576 minecraft:light[level=14]
setblock 191 154 584 minecraft:light[level=14]
setblock 191 154 592 minecraft:light[level=14]
setblock 199 154 560 minecraft:light[level=14]
setblock 199 154 568 minecraft:light[level=14]
setblock 199 154 576 minecraft:light[level=14]
setblock 199 154 584 minecraft:light[level=14]
setblock 199 154 592 minecraft:light[level=14]
setblock 207 154 560 minecraft:light[level=14]
setblock 207 154 568 minecraft:light[level=14]
setblock 207 154 576 minecraft:light[level=14]
setblock 207 154 584 minecraft:light[level=14]
setblock 207 154 592 minecraft:light[level=14]
setblock 215 154 560 minecraft:light[level=14]
setblock 215 154 568 minecraft:light[level=14]
setblock 215 154 576 minecraft:light[level=14]
setblock 215 154 584 minecraft:light[level=14]
setblock 215 154 592 minecraft:light[level=14]
setblock 223 154 560 minecraft:light[level=14]
setblock 223 154 568 minecraft:light[level=14]
setblock 223 154 576 minecraft:light[level=14]
setblock 223 154 584 minecraft:light[level=14]
setblock 223 154 592 minecraft:light[level=14]
fill 223 157 593 223 157 595 minecraft:yellow_terracotta
fill 224 157 592 226 157 592 minecraft:yellow_terracotta
fill 224 157 596 227 157 596 minecraft:yellow_terracotta
setblock 227 157 593 minecraft:yellow_terracotta
setblock 227 157 595 minecraft:yellow_terracotta
fill 190 158 563 190 159 569 minecraft:gold_block
fill 190 160 567 190 165 569 minecraft:quartz_block
fill 190 160 579 190 165 581 minecraft:quartz_block
fill 190 160 591 190 165 593 minecraft:quartz_block
fill 196 160 597 198 165 597 minecraft:quartz_block
fill 200 160 559 202 165 559 minecraft:quartz_block
fill 208 160 597 210 165 597 minecraft:quartz_block
fill 212 160 559 214 165 559 minecraft:quartz_block
fill 220 160 597 222 165 597 minecraft:quartz_block
fill 224 160 559 226 165 559 minecraft:quartz_block
fill 228 160 567 228 165 569 minecraft:quartz_block
fill 228 160 579 228 165 581 minecraft:quartz_block
fill 228 160 591 228 165 593 minecraft:quartz_block
setblock 191 162 560 minecraft:light[level=14]
setblock 191 162 568 minecraft:light[level=14]
setblock 191 162 576 minecraft:light[level=14]
setblock 191 162 584 minecraft:light[level=14]
setblock 191 162 592 minecraft:light[level=14]
setblock 199 162 560 minecraft:light[level=14]
setblock 199 162 568 minecraft:light[level=14]
setblock 199 162 576 minecraft:light[level=14]
setblock 199 162 584 minecraft:light[level=14]
setblock 199 162 592 minecraft:light[level=14]
setblock 207 162 560 minecraft:light[level=14]
setblock 207 162 568 minecraft:light[level=14]
setblock 207 162 576 minecraft:light[level=14]
setblock 207 162 584 minecraft:light[level=14]
setblock 207 162 592 minecraft:light[level=14]
setblock 215 162 560 minecraft:light[level=14]
setblock 215 162 568 minecraft:light[level=14]
setblock 215 162 576 minecraft:light[level=14]
setblock 215 162 584 minecraft:light[level=14]
setblock 215 162 592 minecraft:light[level=14]
setblock 223 162 560 minecraft:light[level=14]
setblock 223 162 568 minecraft:light[level=14]
setblock 223 162 576 minecraft:light[level=14]
setblock 223 162 584 minecraft:light[level=14]
setblock 223 162 592 minecraft:light[level=14]
fill 189 165 561 189 165 566 minecraft:yellow_terracotta
fill 189 165 573 189 165 578 minecraft:yellow_terracotta
fill 189 165 585 189 165 590 minecraft:yellow_terracotta
fill 189 165 597 189 165 598 minecraft:yellow_terracotta
fill 190 165 598 193 165 598 minecraft:yellow_terracotta
fill 193 165 558 198 165 558 minecraft:yellow_terracotta
fill 200 165 598 205 165 598 minecraft:yellow_terracotta
fill 205 165 558 210 165 558 minecraft:yellow_terracotta
fill 212 165 598 217 165 598 minecraft:yellow_terracotta
fill 217 165 558 222 165 558 minecraft:yellow_terracotta
fill 223 165 593 223 165 595 minecraft:yellow_terracotta
fill 224 165 573 226 166 573 minecraft:gold_block
fill 224 165 592 226 165 592 minecraft:yellow_terracotta
fill 224 165 596 227 165 596 minecraft:yellow_terracotta
fill 224 165 598 229 165 598 minecraft:yellow_terracotta
fill 225 165 572 225 166 572 minecraft:gold_block
fill 225 165 574 225 166 574 minecraft:gold_block
setblock 227 165 593 minecraft:yellow_terracotta
setblock 227 165 595 minecraft:yellow_terracotta
fill 229 165 558 229 165 563 minecraft:yellow_terracotta
fill 229 165 570 229 165 575 minecraft:yellow_terracotta
fill 229 165 582 229 165 587 minecraft:yellow_terracotta
fill 229 165 594 229 165 597 minecraft:yellow_terracotta
fill 188 166 563 188 170 566 minecraft:ochre_froglight
fill 188 166 575 188 170 578 minecraft:ochre_froglight
fill 188 166 587 188 170 590 minecraft:ochre_froglight
fill 188 166 599 191 170 599 minecraft:ochre_froglight
fill 189 166 575 189 167 577 minecraft:quartz_block
fill 195 166 557 198 170 557 minecraft:ochre_froglight
fill 200 166 599 203 170 599 minecraft:ochre_froglight
fill 207 166 557 210 170 557 minecraft:ochre_froglight
fill 212 166 599 215 170 599 minecraft:ochre_froglight
fill 219 166 557 222 170 557 minecraft:ochre_froglight
fill 224 166 599 227 170 599 minecraft:ochre_froglight
fill 228 166 575 229 167 577 minecraft:quartz_block
fill 230 166 558 230 170 561 minecraft:ochre_froglight
fill 230 166 570 230 170 573 minecraft:ochre_froglight
fill 230 166 582 230 170 585 minecraft:ochre_froglight
fill 230 166 594 230 170 597 minecraft:ochre_froglight
fill 190 167 575 190 168 577 minecraft:quartz_block
fill 191 167 576 191 170 576 minecraft:quartz_block
fill 226 167 576 227 169 576 minecraft:quartz_block
fill 227 167 575 227 168 575 minecraft:quartz_block
fill 227 167 577 227 168 577 minecraft:quartz_block
setblock 189 168 576 minecraft:quartz_block
fill 191 168 575 191 169 575 minecraft:quartz_block
fill 191 168 577 191 169 577 minecraft:quartz_block
fill 192 168 576 192 170 576 minecraft:quartz_block
fill 211 168 570 211 169 570 minecraft:raw_gold_block
fill 225 168 576 225 170 576 minecraft:quartz_block
fill 226 168 575 226 169 575 minecraft:quartz_block
fill 226 168 577 226 169 577 minecraft:quartz_block
setblock 228 168 576 minecraft:quartz_block
setblock 229 168 576 minecraft:gold_block
setblock 189 169 576 minecraft:gold_block
setblock 190 169 576 minecraft:quartz_block
fill 192 169 575 193 170 575 minecraft:quartz_block
fill 192 169 577 193 170 577 minecraft:quartz_block
fill 193 169 576 193 170 576 minecraft:quartz_block
fill 223 169 594 223 170 594 minecraft:gold_block
fill 224 169 575 224 170 577 minecraft:quartz_block
fill 224 169 596 226 170 596 minecraft:gold_block
fill 225 169 575 225 170 575 minecraft:quartz_block
fill 225 169 577 225 170 577 minecraft:quartz_block
fill 225 169 592 226 170 592 minecraft:gold_block
fill 227 169 593 227 170 593 minecraft:gold_block
fill 227 169 595 227 170 595 minecraft:gold_block
setblock 228 169 576 minecraft:gold_block
setblock 190 170 576 minecraft:gold_block
setblock 191 170 560 minecraft:light[level=14]
setblock 191 170 568 minecraft:light[level=14]
setblock 191 170 584 minecraft:light[level=14]
setblock 191 170 592 minecraft:light[level=14]
fill 194 170 575 194 170 577 minecraft:quartz_block
setblock 195 170 576 minecraft:quartz_block
setblock 199 170 560 minecraft:light[level=14]
setblock 199 170 568 minecraft:light[level=14]
setblock 199 170 576 minecraft:light[level=14]
setblock 199 170 584 minecraft:light[level=14]
setblock 199 170 592 minecraft:light[level=14]
setblock 207 170 560 minecraft:light[level=14]
setblock 207 170 568 minecraft:light[level=14]
setblock 207 170 576 minecraft:light[level=14]
setblock 207 170 584 minecraft:light[level=14]
setblock 207 170 592 minecraft:light[level=14]
setblock 215 170 560 minecraft:light[level=14]
setblock 215 170 568 minecraft:light[level=14]
setblock 215 170 576 minecraft:light[level=14]
setblock 215 170 584 minecraft:light[level=14]
setblock 215 170 592 minecraft:light[level=14]
fill 222 170 576 223 170 576 minecraft:quartz_block
setblock 223 170 560 minecraft:light[level=14]
setblock 223 170 568 minecraft:light[level=14]
setblock 223 170 575 minecraft:quartz_block
setblock 223 170 577 minecraft:quartz_block
setblock 223 170 584 minecraft:light[level=14]
setblock 223 170 592 minecraft:light[level=14]
setblock 226 170 576 minecraft:quartz_block
setblock 227 170 576 minecraft:gold_block
fill 188 171 563 188 185 566 minecraft:yellow_terracotta
fill 188 171 575 188 185 578 minecraft:yellow_terracotta
fill 188 171 587 188 185 590 minecraft:yellow_terracotta
fill 188 171 599 191 185 599 minecraft:yellow_terracotta
fill 195 171 557 198 185 557 minecraft:yellow_terracotta
fill 200 171 599 203 185 599 minecraft:yellow_terracotta
fill 207 171 557 210 185 557 minecraft:yellow_terracotta
fill 212 171 599 215 185 599 minecraft:yellow_terracotta
fill 219 171 557 222 185 557 minecraft:yellow_terracotta
fill 224 171 599 227 185 599 minecraft:yellow_terracotta
fill 230 171 558 230 185 561 minecraft:yellow_terracotta
fill 230 171 570 230 185 573 minecraft:yellow_terracotta
fill 230 171 582 230 185 585 minecraft:yellow_terracotta
fill 230 171 594 230 185 597 minecraft:yellow_terracotta
fill 203 175 577 205 175 579 minecraft:redstone_block
fill 206 175 569 208 175 571 minecraft:redstone_block
fill 211 175 571 213 175 573 minecraft:redstone_block
fill 211 175 577 213 175 579 minecraft:redstone_block
fill 194 176 575 201 176 575 minecraft:gold_block
fill 196 176 574 202 176 574 minecraft:gold_block
fill 196 176 576 202 176 576 minecraft:gold_block
fill 199 176 566 201 177 568 minecraft:gold_block
fill 199 176 573 203 176 573 minecraft:gold_block
fill 199 176 577 202 176 577 minecraft:gold_block
fill 199 176 582 201 177 584 minecraft:gold_block
fill 200 176 569 205 176 570 minecraft:gold_block
fill 200 176 580 216 176 581 minecraft:gold_block
fill 201 176 571 205 176 571 minecraft:gold_block
fill 201 176 579 202 176 579 minecraft:gold_block
fill 202 176 567 203 177 568 minecraft:gold_block
fill 202 176 572 206 176 572 minecraft:gold_block
fill 202 176 575 206 176 575 minecraft:dark_oak_planks
setblock 202 176 578 minecraft:gold_block
fill 202 176 582 203 177 583 minecraft:gold_block
fill 203 176 574 206 176 574 minecraft:dark_oak_planks
fill 203 176 576 206 176 576 minecraft:dark_oak_planks
fill 204 176 568 204 177 568 minecraft:gold_block
fill 204 176 573 212 176 573 minecraft:dark_oak_planks
fill 204 176 577 212 176 577 minecraft:dark_oak_planks
fill 204 176 582 204 177 582 minecraft:gold_block
fill 206 176 566 210 176 568 minecraft:gold_block
fill 206 176 578 206 176 579 minecraft:gold_block
fill 206 176 582 210 176 584 minecraft:gold_block
fill 207 176 563 209 177 565 minecraft:gold_block
fill 207 176 572 209 177 572 minecraft:dark_oak_planks
fill 207 176 578 209 177 578 minecraft:dark_oak_planks
fill 207 176 579 210 176 579 minecraft:gold_block
fill 207 176 585 209 177 587 minecraft:gold_block
fill 208 176 561 208 177 562 minecraft:gold_block
fill 208 176 588 208 177 589 minecraft:gold_block
fill 209 176 569 210 176 571 minecraft:gold_block
setblock 210 176 572 minecraft:gold_block
fill 210 176 574 213 176 576 minecraft:dark_oak_planks
setblock 210 176 578 minecraft:gold_block
fill 211 176 569 216 176 570 minecraft:gold_block
fill 212 176 568 217 177 568 minecraft:gold_block
fill 212 176 582 217 177 582 minecraft:gold_block
fill 213 176 567 217 177 567 minecraft:gold_block
fill 213 176 583 217 177 583 minecraft:gold_block
fill 214 176 571 214 176 574 minecraft:gold_block
fill 214 176 575 214 177 575 minecraft:dark_oak_planks
fill 214 176 576 214 176 579 minecraft:gold_block
fill 215 176 566 217 177 566 minecraft:gold_block
fill 215 176 571 215 177 571 minecraft:gold_block
fill 215 176 573 217 176 577 minecraft:gold_block
fill 215 176 579 215 177 579 minecraft:gold_block
fill 215 176 584 217 177 584 minecraft:gold_block
fill 218 176 574 220 177 576 minecraft:gold_block
fill 221 176 575 222 177 575 minecraft:gold_block
fill 189 177 558 193 177 598 minecraft:yellow_terracotta
fill 194 177 558 195 177 574 minecraft:yellow_terracotta
fill 194 177 575 198 177 575 minecraft:gold_block
fill 194 177 576 195 177 598 minecraft:yellow_terracotta
fill 196 177 558 198 177 573 minecraft:yellow_terracotta
fill 196 177 574 198 177 574 minecraft:gold_block
fill 196 177 576 198 177 576 minecraft:gold_block
fill 196 177 577 198 177 598 minecraft:yellow_terracotta
fill 199 177 558 206 177 565 minecraft:yellow_terracotta
fill 199 177 569 199 177 572 minecraft:yellow_terracotta
fill 199 177 573 205 177 577 minecraft:dark_oak_planks
fill 199 177 578 199 177 581 minecraft:yellow_terracotta
fill 199 177 585 206 177 598 minecraft:yellow_terracotta
fill 200 177 569 201 177 570 minecraft:gold_block
fill 200 177 571 200 177 572 minecraft:yellow_terracotta
fill 200 177 578 200 177 579 minecraft:yellow_terracotta
fill 200 177 580 201 177 581 minecraft:gold_block
fill 201 177 571 202 177 571 minecraft:gold_block
fill 201 177 572 206 177 572 minecraft:dark_oak_planks
fill 201 177 578 206 177 578 minecraft:dark_oak_planks
setblock 201 177 579 minecraft:gold_block
fill 202 177 566 205 177 566 minecraft:yellow_terracotta
fill 202 177 569 203 177 570 minecraft:emerald_block
fill 202 177 579 202 177 580 minecraft:ochre_froglight
fill 202 177 581 203 177 581 minecraft:emerald_block
fill 202 177 584 205 177 584 minecraft:yellow_terracotta
fill 203 177 571 213 177 571 minecraft:dark_oak_planks
fill 203 177 579 213 177 579 minecraft:dark_oak_planks
fill 203 177 580 206 177 580 minecraft:ochre_froglight
fill 204 177 567 205 177 567 minecraft:yellow_terracotta
setblock 204 177 569 minecraft:gold_block
setblock 204 177 570 minecraft:emerald_block
fill 204 177 581 206 177 581 minecraft:gold_block
fill 204 177 583 205 177 583 minecraft:yellow_terracotta
fill 205 177 568 205 177 570 minecraft:ochre_froglight
setblock 205 177 582 minecraft:yellow_terracotta
fill 206 177 566 206 177 567 minecraft:gold_block
fill 206 177 568 209 177 568 minecraft:ochre_froglight
fill 206 177 569 208 177 570 minecraft:yellow_terracotta
setblock 206 177 573 minecraft:dark_oak_planks
fill 206 177 574 206 177 576 minecraft:sea_lantern
setblock 206 177 577 minecraft:dark_oak_planks
fill 206 177 582 206 177 584 minecraft:gold_block
fill 207 177 558 207 177 562 minecraft:yellow_terracotta
setblock 207 177 566 minecraft:gold_block
fill 207 177 567 209 177 567 minecraft:emerald_block
fill 207 177 573 209 177 573 minecraft:sea_lantern
fill 207 177 577 209 177 577 minecraft:sea_lantern
fill 207 177 580 209 177 583 minecraft:emerald_block
setblock 207 177 584 minecraft:gold_block
fill 207 177 588 207 177 598 minecraft:yellow_terracotta
fill 208 177 558 229 177 560 minecraft:yellow_terracotta
setblock 208 177 566 minecraft:emerald_block
setblock 208 177 584 minecraft:emerald_block
fill 208 177 590 229 177 598 minecraft:yellow_terracotta
fill 209 177 561 229 177 562 minecraft:yellow_terracotta
fill 209 177 566 210 177 566 minecraft:gold_block
fill 209 177 569 209 177 570 minecraft:ochre_froglight
fill 209 177 584 210 177 584 minecraft:gold_block
fill 209 177 588 229 177 589 minecraft:yellow_terracotta
fill 210 177 563 229 177 565 minecraft:yellow_terracotta
fill 210 177 567 210 177 569 minecraft:gold_block
fill 210 177 570 214 177 570 minecraft:ochre_froglight
fill 210 177 572 215 177 573 minecraft:dark_oak_planks
fill 210 177 574 210 177 576 minecraft:sea_lantern
fill 210 177 577 215 177 578 minecraft:dark_oak_planks
fill 210 177 580 214 177 580 minecraft:ochre_froglight
fill 210 177 581 210 177 583 minecraft:gold_block
fill 210 177 585 229 177 587 minecraft:yellow_terracotta
fill 211 177 566 211 177 568 minecraft:yellow_terracotta
fill 211 177 569 212 177 569 minecraft:gold_block
fill 211 177 574 213 177 576 minecraft:dark_oak_planks
fill 211 177 581 212 177 581 minecraft:gold_block
fill 211 177 582 211 177 584 minecraft:yellow_terracotta
fill 212 177 566 212 177 567 minecraft:yellow_terracotta
fill 212 177 583 212 177 584 minecraft:yellow_terracotta
fill 213 177 566 214 177 566 minecraft:yellow_terracotta
fill 213 177 569 214 177 569 minecraft:emerald_block
fill 213 177 581 214 177 581 minecraft:emerald_block
fill 213 177 584 214 177 584 minecraft:yellow_terracotta
setblock 214 177 571 minecraft:ochre_froglight
fill 214 177 574 217 177 574 minecraft:dark_oak_planks
fill 214 177 576 217 177 576 minecraft:dark_oak_planks
setblock 214 177 579 minecraft:ochre_froglight
fill 215 177 569 216 177 570 minecraft:gold_block
fill 215 177 575 217 177 575 minecraft:dark_oak_planks
fill 215 177 580 216 177 581 minecraft:gold_block
fill 216 177 571 229 177 572 minecraft:yellow_terracotta
fill 216 177 573 217 177 573 minecraft:dark_oak_planks
fill 216 177 577 217 177 577 minecraft:dark_oak_planks
fill 216 177 578 229 177 579 minecraft:yellow_terracotta
fill 217 177 569 229 177 570 minecraft:yellow_terracotta
fill 217 177 580 229 177 581 minecraft:yellow_terracotta
fill 218 177 566 229 177 568 minecraft:yellow_terracotta
fill 218 177 573 229 177 573 minecraft:yellow_terracotta
fill 218 177 577 229 177 577 minecraft:yellow_terracotta
fill 218 177 582 229 177 584 minecraft:yellow_terracotta
fill 221 177 574 229 177 574 minecraft:yellow_terracotta
fill 221 177 576 229 177 576 minecraft:yellow_terracotta
fill 223 177 575 229 177 575 minecraft:yellow_terracotta
setblock 191 178 560 minecraft:light[level=14]
setblock 191 178 568 minecraft:light[level=14]
setblock 191 178 576 minecraft:light[level=14]
setblock 191 178 584 minecraft:light[level=14]
setblock 191 178 592 minecraft:light[level=14]
fill 196 178 575 198 178 575 minecraft:dark_oak_planks
fill 197 178 573 198 178 574 minecraft:dark_oak_planks
fill 197 178 576 198 178 577 minecraft:dark_oak_planks
fill 198 178 572 200 178 572 minecraft:dark_oak_planks
fill 198 178 578 200 178 578 minecraft:dark_oak_planks
setblock 199 178 560 minecraft:light[level=14]
setblock 199 178 568 minecraft:light[level=14]
fill 199 178 571 202 178 571 minecraft:dark_oak_planks
setblock 199 178 576 minecraft:light[level=14]
fill 199 178 579 202 178 579 minecraft:dark_oak_planks
setblock 199 178 584 minecraft:light[level=14]
setblock 199 178 592 minecraft:light[level=14]
fill 202 178 570 214 178 570 minecraft:dark_oak_planks
fill 202 178 580 214 178 580 minecraft:dark_oak_planks
setblock 207 178 560 minecraft:light[level=14]
setblock 207 178 568 minecraft:light[level=14]
fill 207 178 569 209 180 569 minecraft:dark_oak_planks
fill 207 178 581 209 180 581 minecraft:dark_oak_planks
setblock 207 178 584 minecraft:light[level=14]
setblock 207 178 592 minecraft:light[level=14]
fill 214 178 571 217 178 571 minecraft:dark_oak_planks
fill 214 178 579 217 178 579 minecraft:dark_oak_planks
setblock 215 178 560 minecraft:light[level=14]
setblock 215 178 568 minecraft:light[level=14]
setblock 215 178 576 minecraft:light[level=14]
setblock 215 178 584 minecraft:light[level=14]
setblock 215 178 592 minecraft:light[level=14]
fill 216 178 572 218 178 572 minecraft:dark_oak_planks
fill 216 178 578 218 178 578 minecraft:dark_oak_planks
fill 218 178 573 219 178 577 minecraft:dark_oak_planks
setblock 220 178 575 minecraft:dark_oak_planks
setblock 223 178 560 minecraft:light[level=14]
setblock 223 178 568 minecraft:light[level=14]
setblock 223 178 576 minecraft:light[level=14]
setblock 223 178 584 minecraft:light[level=14]
setblock 223 178 592 minecraft:light[level=14]
fill 195 179 574 195 180 576 minecraft:dark_oak_planks
fill 196 179 573 196 179 574 minecraft:dark_oak_planks
fill 196 179 576 196 179 577 minecraft:dark_oak_planks
setblock 197 179 572 minecraft:dark_oak_planks
setblock 197 179 578 minecraft:dark_oak_planks
fill 198 179 571 199 179 571 minecraft:dark_oak_planks
fill 198 179 579 199 179 579 minecraft:dark_oak_planks
fill 200 179 570 202 179 570 minecraft:dark_oak_planks
fill 200 179 580 202 179 580 minecraft:dark_oak_planks
fill 203 179 569 206 180 569 minecraft:dark_oak_planks
fill 203 179 581 206 180 581 minecraft:dark_oak_planks
fill 210 179 569 213 180 569 minecraft:dark_oak_planks
fill 210 179 581 213 180 581 minecraft:dark_oak_planks
fill 214 179 570 216 179 570 minecraft:dark_oak_planks
fill 214 179 580 216 179 580 minecraft:dark_oak_planks
fill 217 179 571 218 179 571 minecraft:dark_oak_planks
fill 217 179 579 218 179 579 minecraft:dark_oak_planks
setblock 219 179 572 minecraft:dark_oak_planks
setblock 219 179 578 minecraft:dark_oak_planks
fill 220 179 573 220 179 574 minecraft:dark_oak_planks
fill 220 179 576 220 179 577 minecraft:dark_oak_planks
fill 221 179 574 221 180 576 minecraft:dark_oak_planks
setblock 195 180 573 minecraft:dark_oak_planks
setblock 195 180 577 minecraft:dark_oak_planks
setblock 196 180 572 minecraft:dark_oak_planks
setblock 196 180 578 minecraft:dark_oak_planks
fill 197 180 571 198 180 571 minecraft:dark_oak_planks
fill 197 180 579 198 180 579 minecraft:dark_oak_planks
fill 199 180 570 200 180 570 minecraft:dark_oak_planks
fill 199 180 580 200 180 580 minecraft:dark_oak_planks
fill 201 180 569 202 180 569 minecraft:dark_oak_planks
fill 201 180 581 202 180 581 minecraft:dark_oak_planks
fill 214 180 569 215 180 569 minecraft:dark_oak_planks
fill 214 180 581 215 180 581 minecraft:dark_oak_planks
fill 216 180 570 217 180 570 minecraft:dark_oak_planks
fill 216 180 580 217 180 580 minecraft:dark_oak_planks
fill 218 180 571 219 180 571 minecraft:dark_oak_planks
fill 218 180 579 219 180 579 minecraft:dark_oak_planks
setblock 220 180 572 minecraft:dark_oak_planks
setblock 220 180 578 minecraft:dark_oak_planks
setblock 221 180 573 minecraft:dark_oak_planks
setblock 221 180 577 minecraft:dark_oak_planks
fill 189 181 558 191 228 558 minecraft:quartz_block
fill 189 181 568 189 228 570 minecraft:quartz_block
fill 189 181 578 193 183 590 minecraft:quartz_block
fill 189 181 592 189 228 594 minecraft:quartz_block
fill 190 181 567 190 185 569 minecraft:quartz_block
fill 190 181 591 190 185 593 minecraft:quartz_block
fill 195 181 573 204 181 577 minecraft:spruce_planks
fill 195 181 598 197 228 598 minecraft:quartz_block
fill 196 181 558 204 183 564 minecraft:quartz_block
fill 196 181 572 206 181 572 minecraft:spruce_planks
fill 196 181 578 206 181 578 minecraft:spruce_planks
fill 196 181 597 198 185 597 minecraft:quartz_block
fill 197 181 571 219 181 571 minecraft:spruce_planks
fill 197 181 579 219 181 579 minecraft:spruce_planks
fill 199 181 570 217 181 570 minecraft:spruce_planks
fill 199 181 580 217 181 580 minecraft:spruce_planks
fill 201 181 569 215 181 569 minecraft:spruce_planks
fill 201 181 581 215 181 581 minecraft:spruce_planks
setblock 205 181 573 minecraft:spruce_planks
setblock 205 181 577 minecraft:spruce_planks
fill 207 181 598 209 228 598 minecraft:quartz_block
fill 208 181 597 210 185 597 minecraft:quartz_block
fill 210 181 572 220 181 572 minecraft:spruce_planks
fill 210 181 578 220 181 578 minecraft:spruce_planks
fill 211 181 573 221 181 573 minecraft:spruce_planks
fill 211 181 577 221 181 577 minecraft:spruce_planks
fill 212 181 559 214 185 559 minecraft:quartz_block
fill 212 181 574 221 181 576 minecraft:spruce_planks
fill 213 181 558 228 183 558 minecraft:quartz_block
fill 216 181 559 228 183 567 minecraft:quartz_block
fill 219 181 598 221 228 598 minecraft:quartz_block
fill 220 181 597 222 185 597 minecraft:quartz_block
fill 228 181 568 228 185 569 minecraft:quartz_block
fill 228 181 579 228 185 581 minecraft:quartz_block
fill 228 181 591 228 185 593 minecraft:quartz_block
fill 229 181 566 229 228 568 minecraft:quartz_block
fill 229 181 578 229 228 580 minecraft:quartz_block
fill 229 181 590 229 228 592 minecraft:quartz_block
fill 201 182 575 201 185 575 minecraft:stripped_dark_oak_log
setblock 189 184 578 minecraft:ochre_froglight
fill 189 184 579 189 194 579 minecraft:quartz_block
setblock 189 184 580 minecraft:ochre_froglight
fill 189 184 581 189 228 581 minecraft:quartz_block
setblock 189 184 582 minecraft:ochre_froglight
fill 189 184 583 189 194 583 minecraft:quartz_block
setblock 189 184 584 minecraft:ochre_froglight
setblock 189 184 585 minecraft:quartz_block
setblock 189 184 586 minecraft:ochre_froglight
setblock 189 184 587 minecraft:quartz_block
setblock 189 184 588 minecraft:ochre_froglight
setblock 189 184 589 minecraft:quartz_block
setblock 189 184 590 minecraft:ochre_froglight
fill 190 184 578 190 194 578 minecraft:quartz_block
setblock 190 184 579 minecraft:ochre_froglight
fill 190 184 580 190 194 580 minecraft:quartz_block
setblock 190 184 581 minecraft:ochre_froglight
fill 190 184 582 190 194 582 minecraft:quartz_block
setblock 190 184 583 minecraft:ochre_froglight
fill 190 184 584 190 194 584 minecraft:quartz_block
setblock 190 184 585 minecraft:ochre_froglight
fill 190 184 586 190 194 586 minecraft:quartz_block
setblock 190 184 587 minecraft:ochre_froglight
fill 190 184 588 190 194 588 minecraft:quartz_block
setblock 190 184 589 minecraft:ochre_froglight
fill 190 184 590 190 194 590 minecraft:quartz_block
setblock 191 184 578 minecraft:ochre_froglight
fill 191 184 579 191 194 579 minecraft:quartz_block
setblock 191 184 580 minecraft:ochre_froglight
fill 191 184 581 191 194 581 minecraft:quartz_block
setblock 191 184 582 minecraft:ochre_froglight
fill 191 184 583 191 194 583 minecraft:quartz_block
setblock 191 184 584 minecraft:ochre_froglight
fill 191 184 585 191 194 585 minecraft:quartz_block
setblock 191 184 586 minecraft:ochre_froglight
fill 191 184 587 191 194 587 minecraft:quartz_block
setblock 191 184 588 minecraft:ochre_froglight
fill 191 184 589 191 194 589 minecraft:quartz_block
setblock 191 184 590 minecraft:ochre_froglight
fill 192 184 578 192 194 578 minecraft:quartz_block
setblock 192 184 579 minecraft:ochre_froglight
fill 192 184 580 192 194 580 minecraft:quartz_block
setblock 192 184 581 minecraft:ochre_froglight
fill 192 184 582 192 194 582 minecraft:quartz_block
setblock 192 184 583 minecraft:ochre_froglight
fill 192 184 584 192 194 584 minecraft:quartz_block
setblock 192 184 585 minecraft:ochre_froglight
fill 192 184 586 192 194 586 minecraft:quartz_block
setblock 192 184 587 minecraft:ochre_froglight
fill 192 184 588 192 194 588 minecraft:quartz_block
setblock 192 184 589 minecraft:ochre_froglight
fill 192 184 590 192 194 590 minecraft:quartz_block
setblock 193 184 578 minecraft:ochre_froglight
fill 193 184 579 193 194 579 minecraft:quartz_block
setblock 193 184 580 minecraft:ochre_froglight
fill 193 184 581 193 194 581 minecraft:quartz_block
setblock 193 184 582 minecraft:ochre_froglight
fill 193 184 583 193 194 583 minecraft:quartz_block
setblock 193 184 584 minecraft:ochre_froglight
fill 193 184 585 193 194 585 minecraft:quartz_block
setblock 193 184 586 minecraft:ochre_froglight
fill 193 184 587 193 194 587 minecraft:quartz_block
setblock 193 184 588 minecraft:ochre_froglight
fill 193 184 589 193 194 589 minecraft:quartz_block
setblock 193 184 590 minecraft:ochre_froglight
setblock 196 184 558 minecraft:quartz_block
setblock 196 184 559 minecraft:ochre_froglight
fill 196 184 560 196 198 560 minecraft:quartz_block
setblock 196 184 561 minecraft:ochre_froglight
fill 196 184 562 196 198 562 minecraft:quartz_block
setblock 196 184 563 minecraft:ochre_froglight
fill 196 184 564 196 198 564 minecraft:quartz_block
setblock 197 184 558 minecraft:ochre_froglight
fill 197 184 559 197 198 559 minecraft:quartz_block
setblock 197 184 560 minecraft:ochre_froglight
fill 197 184 561 197 198 561 minecraft:quartz_block
setblock 197 184 562 minecraft:ochre_froglight
fill 197 184 563 197 198 563 minecraft:quartz_block
setblock 197 184 564 minecraft:ochre_froglight
setblock 198 184 558 minecraft:quartz_block
setblock 198 184 559 minecraft:ochre_froglight
fill 198 184 560 198 198 560 minecraft:quartz_block
setblock 198 184 561 minecraft:ochre_froglight
fill 198 184 562 198 198 562 minecraft:quartz_block
setblock 198 184 563 minecraft:ochre_froglight
fill 198 184 564 198 198 564 minecraft:quartz_block
setblock 199 184 558 minecraft:ochre_froglight
fill 199 184 559 199 198 559 minecraft:quartz_block
setblock 199 184 560 minecraft:ochre_froglight
fill 199 184 561 199 198 561 minecraft:quartz_block
setblock 199 184 562 minecraft:ochre_froglight
fill 199 184 563 199 198 563 minecraft:quartz_block
setblock 199 184 564 minecraft:ochre_froglight
fill 200 184 558 200 198 558 minecraft:quartz_block
setblock 200 184 559 minecraft:ochre_froglight
fill 200 184 560 200 198 560 minecraft:quartz_block
setblock 200 184 561 minecraft:ochre_froglight
fill 200 184 562 200 198 562 minecraft:quartz_block
setblock 200 184 563 minecraft:ochre_froglight
fill 200 184 564 200 198 564 minecraft:quartz_block
setblock 201 184 558 minecraft:ochre_froglight
fill 201 184 559 201 198 559 minecraft:quartz_block
setblock 201 184 560 minecraft:ochre_froglight
fill 201 184 561 201 198 561 minecraft:quartz_block
setblock 201 184 562 minecraft:ochre_froglight
fill 201 184 563 201 198 563 minecraft:quartz_block
setblock 201 184 564 minecraft:ochre_froglight
fill 202 184 558 202 228 558 minecraft:quartz_block
setblock 202 184 559 minecraft:ochre_froglight
fill 202 184 560 202 198 560 minecraft:quartz_block
setblock 202 184 561 minecraft:ochre_froglight
fill 202 184 562 202 198 562 minecraft:quartz_block
setblock 202 184 563 minecraft:ochre_froglight
fill 202 184 564 202 198 564 minecraft:quartz_block
setblock 203 184 558 minecraft:ochre_froglight
fill 203 184 559 203 198 559 minecraft:quartz_block
setblock 203 184 560 minecraft:ochre_froglight
fill 203 184 561 203 198 561 minecraft:quartz_block
setblock 203 184 562 minecraft:ochre_froglight
fill 203 184 563 203 198 563 minecraft:quartz_block
setblock 203 184 564 minecraft:ochre_froglight
fill 204 184 558 204 198 558 minecraft:quartz_block
setblock 204 184 559 minecraft:ochre_froglight
fill 204 184 560 204 198 560 minecraft:quartz_block
setblock 204 184 561 minecraft:ochre_froglight
fill 204 184 562 204 198 562 minecraft:quartz_block
setblock 204 184 563 minecraft:ochre_froglight
fill 204 184 564 204 198 564 minecraft:quartz_block
fill 213 184 558 216 197 558 minecraft:quartz_block
setblock 216 184 559 minecraft:ochre_froglight
fill 216 184 560 216 197 560 minecraft:quartz_block
setblock 216 184 561 minecraft:ochre_froglight
fill 216 184 562 216 197 562 minecraft:quartz_block
setblock 216 184 563 minecraft:ochre_froglight
fill 216 184 564 216 197 564 minecraft:quartz_block
setblock 216 184 565 minecraft:ochre_froglight
fill 216 184 566 216 197 566 minecraft:quartz_block
setblock 216 184 567 minecraft:ochre_froglight
setblock 217 184 558 minecraft:ochre_froglight
fill 217 184 559 217 197 559 minecraft:quartz_block
setblock 217 184 560 minecraft:ochre_froglight
fill 217 184 561 217 197 561 minecraft:quartz_block
setblock 217 184 562 minecraft:ochre_froglight
fill 217 184 563 217 197 563 minecraft:quartz_block
setblock 217 184 564 minecraft:ochre_froglight
fill 217 184 565 217 197 565 minecraft:quartz_block
setblock 217 184 566 minecraft:ochre_froglight
fill 217 184 567 217 197 567 minecraft:quartz_block
setblock 218 184 558 minecraft:quartz_block
setblock 218 184 559 minecraft:ochre_froglight
fill 218 184 560 218 197 560 minecraft:quartz_block
setblock 218 184 561 minecraft:ochre_froglight
fill 218 184 562 218 197 562 minecraft:quartz_block
setblock 218 184 563 minecraft:ochre_froglight
fill 218 184 564 218 197 564 minecraft:quartz_block
setblock 218 184 565 minecraft:ochre_froglight
fill 218 184 566 218 197 566 minecraft:quartz_block
setblock 218 184 567 minecraft:ochre_froglight
setblock 219 184 558 minecraft:ochre_froglight
fill 219 184 559 219 197 559 minecraft:quartz_block
setblock 219 184 560 minecraft:ochre_froglight
fill 219 184 561 219 197 561 minecraft:quartz_block
setblock 219 184 562 minecraft:ochre_froglight
fill 219 184 563 219 197 563 minecraft:quartz_block
setblock 219 184 564 minecraft:ochre_froglight
fill 219 184 565 219 197 565 minecraft:quartz_block
setblock 219 184 566 minecraft:ochre_froglight
fill 219 184 567 219 197 567 minecraft:quartz_block
setblock 220 184 558 minecraft:quartz_block
setblock 220 184 559 minecraft:ochre_froglight
fill 220 184 560 220 197 560 minecraft:quartz_block
setblock 220 184 561 minecraft:ochre_froglight
fill 220 184 562 220 197 562 minecraft:quartz_block
setblock 220 184 563 minecraft:ochre_froglight
fill 220 184 564 220 197 564 minecraft:quartz_block
setblock 220 184 565 minecraft:ochre_froglight
fill 220 184 566 220 197 566 minecraft:quartz_block
setblock 220 184 567 minecraft:ochre_froglight
setblock 221 184 558 minecraft:ochre_froglight
fill 221 184 559 221 197 559 minecraft:quartz_block
setblock 221 184 560 minecraft:ochre_froglight
fill 221 184 561 221 197 561 minecraft:quartz_block
setblock 221 184 562 minecraft:ochre_froglight
fill 221 184 563 221 197 563 minecraft:quartz_block
setblock 221 184 564 minecraft:ochre_froglight
fill 221 184 565 221 197 565 minecraft:quartz_block
setblock 221 184 566 minecraft:ochre_froglight
fill 221 184 567 221 197 567 minecraft:quartz_block
setblock 222 184 558 minecraft:quartz_block
setblock 222 184 559 minecraft:ochre_froglight
fill 222 184 560 222 197 560 minecraft:quartz_block
setblock 222 184 561 minecraft:ochre_froglight
fill 222 184 562 222 197 562 minecraft:quartz_block
setblock 222 184 563 minecraft:ochre_froglight
fill 222 184 564 222 197 564 minecraft:quartz_block
setblock 222 184 565 minecraft:ochre_froglight
fill 222 184 566 222 197 566 minecraft:quartz_block
setblock 222 184 567 minecraft:ochre_froglight
setblock 223 184 558 minecraft:ochre_froglight
fill 223 184 559 223 197 559 minecraft:quartz_block
setblock 223 184 560 minecraft:ochre_froglight
fill 223 184 561 223 197 561 minecraft:quartz_block
setblock 223 184 562 minecraft:ochre_froglight
fill 223 184 563 223 197 563 minecraft:quartz_block
setblock 223 184 564 minecraft:ochre_froglight
fill 223 184 565 223 197 565 minecraft:quartz_block
setblock 223 184 566 minecraft:ochre_froglight
fill 223 184 567 223 197 567 minecraft:quartz_block
fill 224 184 558 224 197 558 minecraft:quartz_block
setblock 224 184 559 minecraft:ochre_froglight
fill 224 184 560 224 197 560 minecraft:quartz_block
setblock 224 184 561 minecraft:ochre_froglight
fill 224 184 562 224 197 562 minecraft:quartz_block
setblock 224 184 563 minecraft:ochre_froglight
fill 224 184 564 224 197 564 minecraft:quartz_block
setblock 224 184 565 minecraft:ochre_froglight
fill 224 184 566 224 197 566 minecraft:quartz_block
setblock 224 184 567 minecraft:ochre_froglight
setblock 225 184 558 minecraft:ochre_froglight
fill 225 184 559 225 197 559 minecraft:quartz_block
setblock 225 184 560 minecraft:ochre_froglight
fill 225 184 561 225 197 561 minecraft:quartz_block
setblock 225 184 562 minecraft:ochre_froglight
fill 225 184 563 225 197 563 minecraft:quartz_block
setblock 225 184 564 minecraft:ochre_froglight
fill 225 184 565 225 197 565 minecraft:quartz_block
setblock 225 184 566 minecraft:ochre_froglight
fill 225 184 567 225 197 567 minecraft:quartz_block
fill 226 184 558 226 228 558 minecraft:quartz_block
setblock 226 184 559 minecraft:ochre_froglight
fill 226 184 560 226 197 560 minecraft:quartz_block
setblock 226 184 561 minecraft:ochre_froglight
fill 226 184 562 226 197 562 minecraft:quartz_block
setblock 226 184 563 minecraft:ochre_froglight
fill 226 184 564 226 197 564 minecraft:quartz_block
setblock 226 184 565 minecraft:ochre_froglight
fill 226 184 566 226 197 566 minecraft:quartz_block
setblock 226 184 567 minecraft:ochre_froglight
setblock 227 184 558 minecraft:ochre_froglight
fill 227 184 559 227 197 559 minecraft:quartz_block
setblock 227 184 560 minecraft:ochre_froglight
fill 227 184 561 227 197 561 minecraft:quartz_block
setblock 227 184 562 minecraft:ochre_froglight
fill 227 184 563 227 197 563 minecraft:quartz_block
setblock 227 184 564 minecraft:ochre_froglight
fill 227 184 565 227 197 565 minecraft:quartz_block
setblock 227 184 566 minecraft:ochre_froglight
fill 227 184 567 227 197 567 minecraft:quartz_block
fill 228 184 558 228 197 558 minecraft:quartz_block
setblock 228 184 559 minecraft:ochre_froglight
fill 228 184 560 228 197 560 minecraft:quartz_block
setblock 228 184 561 minecraft:ochre_froglight
fill 228 184 562 228 197 562 minecraft:quartz_block
setblock 228 184 563 minecraft:ochre_froglight
fill 228 184 564 228 197 564 minecraft:quartz_block
setblock 228 184 565 minecraft:ochre_froglight
fill 228 184 566 228 197 566 minecraft:quartz_block
setblock 228 184 567 minecraft:ochre_froglight
fill 189 185 561 189 185 566 minecraft:yellow_terracotta
fill 189 185 573 189 185 578 minecraft:yellow_terracotta
fill 189 185 580 189 186 580 minecraft:quartz_block
fill 189 185 582 189 186 582 minecraft:quartz_block
fill 189 185 584 189 186 584 minecraft:quartz_block
fill 189 185 585 189 185 590 minecraft:yellow_terracotta
fill 189 185 597 189 185 598 minecraft:yellow_terracotta
fill 190 185 579 190 186 579 minecraft:quartz_block
fill 190 185 581 190 186 581 minecraft:quartz_block
fill 190 185 583 190 186 583 minecraft:quartz_block
fill 190 185 585 190 186 585 minecraft:quartz_block
fill 190 185 587 190 186 587 minecraft:quartz_block
fill 190 185 589 190 186 589 minecraft:quartz_block
fill 190 185 598 193 185 598 minecraft:yellow_terracotta
fill 191 185 578 191 186 578 minecraft:quartz_block
fill 191 185 580 191 186 580 minecraft:quartz_block
fill 191 185 582 191 186 582 minecraft:quartz_block
fill 191 185 584 191 186 584 minecraft:quartz_block
fill 191 185 586 191 186 586 minecraft:quartz_block
fill 191 185 588 191 186 588 minecraft:quartz_block
fill 191 185 590 191 186 590 minecraft:quartz_block
fill 192 185 579 192 186 579 minecraft:quartz_block
fill 192 185 581 192 186 581 minecraft:quartz_block
fill 192 185 583 192 186 583 minecraft:quartz_block
fill 192 185 585 192 186 585 minecraft:quartz_block
fill 192 185 587 192 186 587 minecraft:quartz_block
fill 192 185 589 192 186 589 minecraft:quartz_block
fill 193 185 558 198 185 558 minecraft:yellow_terracotta
fill 193 185 578 193 186 578 minecraft:quartz_block
fill 193 185 580 193 186 580 minecraft:quartz_block
fill 193 185 582 193 186 582 minecraft:quartz_block
fill 193 185 584 193 186 584 minecraft:quartz_block
fill 193 185 586 193 186 586 minecraft:quartz_block
fill 193 185 588 193 186 588 minecraft:quartz_block
fill 193 185 590 193 186 590 minecraft:quartz_block
fill 196 185 559 196 186 559 minecraft:quartz_block
fill 196 185 561 196 186 561 minecraft:quartz_block
fill 196 185 563 196 186 563 minecraft:quartz_block
fill 197 185 560 197 186 560 minecraft:quartz_block
fill 197 185 562 197 186 562 minecraft:quartz_block
fill 197 185 564 197 186 564 minecraft:quartz_block
fill 198 185 559 198 186 559 minecraft:quartz_block
fill 198 185 561 198 186 561 minecraft:quartz_block
fill 198 185 563 198 186 563 minecraft:quartz_block
fill 199 185 558 199 186 558 minecraft:quartz_block
fill 199 185 560 199 186 560 minecraft:quartz_block
fill 199 185 562 199 186 562 minecraft:quartz_block
fill 199 185 564 199 186 564 minecraft:quartz_block
fill 200 185 559 200 186 559 minecraft:quartz_block
fill 200 185 561 200 186 561 minecraft:quartz_block
fill 200 185 563 200 186 563 minecraft:quartz_block
fill 200 185 598 205 185 598 minecraft:yellow_terracotta
fill 201 185 558 201 186 558 minecraft:quartz_block
fill 201 185 560 201 186 560 minecraft:quartz_block
fill 201 185 562 201 186 562 minecraft:quartz_block
fill 201 185 564 201 186 564 minecraft:quartz_block
fill 202 185 559 202 186 559 minecraft:quartz_block
fill 202 185 561 202 186 561 minecraft:quartz_block
fill 202 185 563 202 186 563 minecraft:quartz_block
fill 203 185 558 203 186 558 minecraft:quartz_block
fill 203 185 560 203 186 560 minecraft:quartz_block
fill 203 185 562 203 186 562 minecraft:quartz_block
fill 203 185 564 203 186 564 minecraft:quartz_block
fill 204 185 559 204 186 559 minecraft:quartz_block
fill 204 185 561 204 186 561 minecraft:quartz_block
fill 204 185 563 204 186 563 minecraft:quartz_block
fill 205 185 558 210 185 558 minecraft:yellow_terracotta
fill 212 185 598 217 185 598 minecraft:yellow_terracotta
fill 216 185 559 216 186 559 minecraft:quartz_block
fill 216 185 561 216 186 561 minecraft:quartz_block
fill 216 185 563 216 186 563 minecraft:quartz_block
fill 216 185 565 216 186 565 minecraft:quartz_block
fill 216 185 567 216 186 567 minecraft:quartz_block
fill 217 185 558 222 185 558 minecraft:yellow_terracotta
fill 217 185 560 217 186 560 minecraft:quartz_block
fill 217 185 562 217 186 562 minecraft:quartz_block
fill 217 185 564 217 186 564 minecraft:quartz_block
fill 217 185 566 217 186 566 minecraft:quartz_block
fill 218 185 559 218 186 559 minecraft:quartz_block
fill 218 185 561 218 186 561 minecraft:quartz_block
fill 218 185 563 218 186 563 minecraft:quartz_block
fill 218 185 565 218 186 565 minecraft:quartz_block
fill 218 185 567 218 186 567 minecraft:quartz_block
fill 219 185 560 219 186 560 minecraft:quartz_block
fill 219 185 562 219 186 562 minecraft:quartz_block
fill 219 185 564 219 186 564 minecraft:quartz_block
fill 219 185 566 219 186 566 minecraft:quartz_block
fill 220 185 559 220 186 559 minecraft:quartz_block
fill 220 185 561 220 186 561 minecraft:quartz_block
fill 220 185 563 220 186 563 minecraft:quartz_block
fill 220 185 565 220 186 565 minecraft:quartz_block
fill 220 185 567 220 186 567 minecraft:quartz_block
fill 221 185 560 221 186 560 minecraft:quartz_block
fill 221 185 562 221 186 562 minecraft:quartz_block
fill 221 185 564 221 186 564 minecraft:quartz_block
fill 221 185 566 221 186 566 minecraft:quartz_block
fill 222 185 559 222 186 559 minecraft:quartz_block
fill 222 185 561 222 186 561 minecraft:quartz_block
fill 222 185 563 222 186 563 minecraft:quartz_block
fill 222 185 565 222 186 565 minecraft:quartz_block
fill 222 185 567 222 186 567 minecraft:quartz_block
fill 223 185 558 223 186 558 minecraft:quartz_block
fill 223 185 560 223 186 560 minecraft:quartz_block
fill 223 185 562 223 186 562 minecraft:quartz_block
fill 223 185 564 223 186 564 minecraft:quartz_block
fill 223 185 566 223 186 566 minecraft:quartz_block
fill 224 185 559 224 186 559 minecraft:quartz_block
fill 224 185 561 224 186 561 minecraft:quartz_block
fill 224 185 563 224 186 563 minecraft:quartz_block
fill 224 185 565 224 186 565 minecraft:quartz_block
fill 224 185 567 224 186 567 minecraft:quartz_block
fill 224 185 598 229 185 598 minecraft:yellow_terracotta
fill 225 185 558 225 186 558 minecraft:quartz_block
fill 225 185 560 225 186 560 minecraft:quartz_block
fill 225 185 562 225 186 562 minecraft:quartz_block
fill 225 185 564 225 186 564 minecraft:quartz_block
fill 225 185 566 225 186 566 minecraft:quartz_block
fill 226 185 559 226 186 559 minecraft:quartz_block
fill 226 185 561 226 186 561 minecraft:quartz_block
fill 226 185 563 226 186 563 minecraft:quartz_block
fill 226 185 565 226 186 565 minecraft:quartz_block
fill 226 185 567 226 186 567 minecraft:quartz_block
fill 227 185 558 227 186 558 minecraft:quartz_block
fill 227 185 560 227 186 560 minecraft:quartz_block
fill 227 185 562 227 186 562 minecraft:quartz_block
fill 227 185 564 227 186 564 minecraft:quartz_block
fill 227 185 566 227 186 566 minecraft:quartz_block
fill 228 185 559 228 186 559 minecraft:quartz_block
fill 228 185 561 228 186 561 minecraft:quartz_block
fill 228 185 563 228 186 563 minecraft:quartz_block
fill 228 185 565 228 186 565 minecraft:quartz_block
fill 228 185 567 228 186 567 minecraft:quartz_block
fill 229 185 558 229 185 563 minecraft:yellow_terracotta
fill 229 185 570 229 185 575 minecraft:yellow_terracotta
fill 229 185 582 229 185 587 minecraft:yellow_terracotta
fill 229 185 594 229 185 597 minecraft:yellow_terracotta
fill 188 186 563 188 191 566 minecraft:ochre_froglight
fill 188 186 575 188 191 578 minecraft:ochre_froglight
fill 188 186 587 188 191 590 minecraft:ochre_froglight
fill 188 186 599 191 191 599 minecraft:ochre_froglight
setblock 189 186 578 minecraft:quartz_block
fill 189 186 585 189 186 590 minecraft:quartz_block
setblock 191 186 560 minecraft:light[level=14]
setblock 191 186 568 minecraft:light[level=14]
setblock 191 186 576 minecraft:light[level=14]
setblock 191 186 592 minecraft:light[level=14]
fill 195 186 557 198 191 557 minecraft:ochre_froglight
fill 196 186 558 198 186 558 minecraft:quartz_block
setblock 199 186 568 minecraft:light[level=14]
setblock 199 186 576 minecraft:light[level=14]
setblock 199 186 584 minecraft:light[level=14]
setblock 199 186 592 minecraft:light[level=14]
fill 200 186 599 203 191 599 minecraft:ochre_froglight
fill 201 186 571 201 195 579 minecraft:white_wool
fill 207 186 557 210 191 557 minecraft:ochre_froglight
setblock 207 186 560 minecraft:light[level=14]
setblock 207 186 568 minecraft:light[level=14]
setblock 207 186 576 minecraft:light[level=14]
setblock 207 186 584 minecraft:light[level=14]
setblock 207 186 592 minecraft:light[level=14]
fill 212 186 599 215 191 599 minecraft:ochre_froglight
setblock 215 186 560 minecraft:light[level=14]
setblock 215 186 568 minecraft:light[level=14]
setblock 215 186 576 minecraft:light[level=14]
setblock 215 186 584 minecraft:light[level=14]
setblock 215 186 592 minecraft:light[level=14]
fill 217 186 558 222 186 558 minecraft:quartz_block
fill 219 186 557 222 191 557 minecraft:ochre_froglight
setblock 223 186 568 minecraft:light[level=14]
setblock 223 186 576 minecraft:light[level=14]
setblock 223 186 584 minecraft:light[level=14]
setblock 223 186 592 minecraft:light[level=14]
fill 224 186 599 227 191 599 minecraft:ochre_froglight
fill 230 186 558 230 191 561 minecraft:ochre_froglight
fill 230 186 570 230 191 573 minecraft:ochre_froglight
fill 230 186 582 230 191 585 minecraft:ochre_froglight
fill 230 186 594 230 191 597 minecraft:ochre_froglight
setblock 189 187 578 minecraft:ochre_froglight
setblock 189 187 580 minecraft:ochre_froglight
setblock 189 187 582 minecraft:ochre_froglight
setblock 189 187 584 minecraft:ochre_froglight
fill 189 187 585 189 194 585 minecraft:quartz_block
setblock 189 187 586 minecraft:ochre_froglight
fill 189 187 587 189 194 587 minecraft:quartz_block
setblock 189 187 588 minecraft:ochre_froglight
fill 189 187 589 189 194 589 minecraft:quartz_block
setblock 189 187 590 minecraft:ochre_froglight
setblock 190 187 579 minecraft:ochre_froglight
setblock 190 187 581 minecraft:ochre_froglight
setblock 190 187 583 minecraft:ochre_froglight
setblock 190 187 585 minecraft:ochre_froglight
setblock 190 187 587 minecraft:ochre_froglight
setblock 190 187 589 minecraft:ochre_froglight
setblock 191 187 578 minecraft:ochre_froglight
setblock 191 187 580 minecraft:ochre_froglight
setblock 191 187 582 minecraft:ochre_froglight
setblock 191 187 584 minecraft:ochre_froglight
setblock 191 187 586 minecraft:ochre_froglight
setblock 191 187 588 minecraft:ochre_froglight
setblock 191 187 590 minecraft:ochre_froglight
setblock 192 187 579 minecraft:ochre_froglight
setblock 192 187 581 minecraft:ochre_froglight
setblock 192 187 583 minecraft:ochre_froglight
setblock 192 187 585 minecraft:ochre_froglight
setblock 192 187 587 minecraft:ochre_froglight
setblock 192 187 589 minecraft:ochre_froglight
setblock 193 187 578 minecraft:ochre_froglight
setblock 193 187 580 minecraft:ochre_froglight
setblock 193 187 582 minecraft:ochre_froglight
setblock 193 187 584 minecraft:ochre_froglight
setblock 193 187 586 minecraft:ochre_froglight
setblock 193 187 588 minecraft:ochre_froglight
setblock 193 187 590 minecraft:ochre_froglight
fill 196 187 558 196 198 558 minecraft:quartz_block
setblock 196 187 559 minecraft:ochre_froglight
setblock 196 187 561 minecraft:ochre_froglight
setblock 196 187 563 minecraft:ochre_froglight
setblock 197 187 558 minecraft:ochre_froglight
setblock 197 187 560 minecraft:ochre_froglight
setblock 197 187 562 minecraft:ochre_froglight
setblock 197 187 564 minecraft:ochre_froglight
fill 198 187 558 198 198 558 minecraft:quartz_block
setblock 198 187 559 minecraft:ochre_froglight
setblock 198 187 561 minecraft:ochre_froglight
setblock 198 187 563 minecraft:ochre_froglight
setblock 199 187 558 minecraft:ochre_froglight
setblock 199 187 560 minecraft:ochre_froglight
setblock 199 187 562 minecraft:ochre_froglight
setblock 199 187 564 minecraft:ochre_froglight
setblock 200 187 559 minecraft:ochre_froglight
setblock 200 187 561 minecraft:ochre_froglight
setblock 200 187 563 minecraft:ochre_froglight
setblock 201 187 558 minecraft:ochre_froglight
setblock 201 187 560 minecraft:ochre_froglight
setblock 201 187 562 minecraft:ochre_froglight
setblock 201 187 564 minecraft:ochre_froglight
setblock 202 187 559 minecraft:ochre_froglight
setblock 202 187 561 minecraft:ochre_froglight
setblock 202 187 563 minecraft:ochre_froglight
setblock 203 187 558 minecraft:ochre_froglight
setblock 203 187 560 minecraft:ochre_froglight
setblock 203 187 562 minecraft:ochre_froglight
setblock 203 187 564 minecraft:ochre_froglight
setblock 204 187 559 minecraft:ochre_froglight
setblock 204 187 561 minecraft:ochre_froglight
setblock 204 187 563 minecraft:ochre_froglight
setblock 216 187 559 minecraft:ochre_froglight
setblock 216 187 561 minecraft:ochre_froglight
setblock 216 187 563 minecraft:ochre_froglight
setblock 216 187 565 minecraft:ochre_froglight
setblock 216 187 567 minecraft:ochre_froglight
setblock 217 187 558 minecraft:ochre_froglight
setblock 217 187 560 minecraft:ochre_froglight
setblock 217 187 562 minecraft:ochre_froglight
setblock 217 187 564 minecraft:ochre_froglight
setblock 217 187 566 minecraft:ochre_froglight
fill 218 187 558 218 197 558 minecraft:quartz_block
setblock 218 187 559 minecraft:ochre_froglight
setblock 218 187 561 minecraft:ochre_froglight
setblock 218 187 563 minecraft:ochre_froglight
setblock 218 187 565 minecraft:ochre_froglight
setblock 218 187 567 minecraft:ochre_froglight
setblock 219 187 558 minecraft:ochre_froglight
setblock 219 187 560 minecraft:ochre_froglight
setblock 219 187 562 minecraft:ochre_froglight
setblock 219 187 564 minecraft:ochre_froglight
setblock 219 187 566 minecraft:ochre_froglight
fill 220 187 558 220 197 558 minecraft:quartz_block
setblock 220 187 559 minecraft:ochre_froglight
setblock 220 187 561 minecraft:ochre_froglight
setblock 220 187 563 minecraft:ochre_froglight
setblock 220 187 565 minecraft:ochre_froglight
setblock 220 187 567 minecraft:ochre_froglight
setblock 221 187 558 minecraft:ochre_froglight
setblock 221 187 560 minecraft:ochre_froglight
setblock 221 187 562 minecraft:ochre_froglight
setblock 221 187 564 minecraft:ochre_froglight
setblock 221 187 566 minecraft:ochre_froglight
fill 222 187 558 222 197 558 minecraft:quartz_block
setblock 222 187 559 minecraft:ochre_froglight
setblock 222 187 561 minecraft:ochre_froglight
setblock 222 187 563 minecraft:ochre_froglight
setblock 222 187 565 minecraft:ochre_froglight
setblock 222 187 567 minecraft:ochre_froglight
setblock 223 187 558 minecraft:ochre_froglight
setblock 223 187 560 minecraft:ochre_froglight
setblock 223 187 562 minecraft:ochre_froglight
setblock 223 187 564 minecraft:ochre_froglight
setblock 223 187 566 minecraft:ochre_froglight
setblock 224 187 559 minecraft:ochre_froglight
setblock 224 187 561 minecraft:ochre_froglight
setblock 224 187 563 minecraft:ochre_froglight
setblock 224 187 565 minecraft:ochre_froglight
setblock 224 187 567 minecraft:ochre_froglight
setblock 225 187 558 minecraft:ochre_froglight
setblock 225 187 560 minecraft:ochre_froglight
setblock 225 187 562 minecraft:ochre_froglight
setblock 225 187 564 minecraft:ochre_froglight
setblock 225 187 566 minecraft:ochre_froglight
fill 225 187 569 226 188 569 minecraft:raw_gold_block
setblock 226 187 559 minecraft:ochre_froglight
setblock 226 187 561 minecraft:ochre_froglight
setblock 226 187 563 minecraft:ochre_froglight
setblock 226 187 565 minecraft:ochre_froglight
setblock 226 187 567 minecraft:ochre_froglight
setblock 227 187 558 minecraft:ochre_froglight
setblock 227 187 560 minecraft:ochre_froglight
setblock 227 187 562 minecraft:ochre_froglight
setblock 227 187 564 minecraft:ochre_froglight
setblock 227 187 566 minecraft:ochre_froglight
setblock 228 187 559 minecraft:ochre_froglight
setblock 228 187 561 minecraft:ochre_froglight
setblock 228 187 563 minecraft:ochre_froglight
setblock 228 187 565 minecraft:ochre_froglight
setblock 228 187 567 minecraft:ochre_froglight
fill 189 188 578 189 189 578 minecraft:quartz_block
fill 189 188 580 189 189 580 minecraft:quartz_block
fill 189 188 582 189 189 582 minecraft:quartz_block
fill 189 188 584 189 189 584 minecraft:quartz_block
fill 189 188 586 189 189 586 minecraft:quartz_block
fill 189 188 588 189 189 588 minecraft:quartz_block
fill 189 188 590 189 189 590 minecraft:quartz_block
fill 190 188 579 190 189 579 minecraft:quartz_block
fill 190 188 581 190 189 581 minecraft:quartz_block
fill 190 188 583 190 189 583 minecraft:quartz_block
fill 190 188 585 190 189 585 minecraft:quartz_block
fill 190 188 587 190 189 587 minecraft:quartz_block
fill 190 188 589 190 189 589 minecraft:quartz_block
fill 191 188 578 191 189 578 minecraft:quartz_block
fill 191 188 580 191 189 580 minecraft:quartz_block
fill 191 188 582 191 189 582 minecraft:quartz_block
fill 191 188 584 191 189 584 minecraft:quartz_block
fill 191 188 586 191 189 586 minecraft:quartz_block
fill 191 188 588 191 189 588 minecraft:quartz_block
fill 191 188 590 191 189 590 minecraft:quartz_block
fill 192 188 579 192 189 579 minecraft:quartz_block
fill 192 188 581 192 189 581 minecraft:quartz_block
fill 192 188 583 192 189 583 minecraft:quartz_block
fill 192 188 585 192 189 585 minecraft:quartz_block
fill 192 188 587 192 189 587 minecraft:quartz_block
fill 192 188 589 192 189 589 minecraft:quartz_block
fill 193 188 578 193 189 578 minecraft:quartz_block
fill 193 188 580 193 189 580 minecraft:quartz_block
fill 193 188 582 193 189 582 minecraft:quartz_block
fill 193 188 584 193 189 584 minecraft:quartz_block
fill 193 188 586 193 189 586 minecraft:quartz_block
fill 193 188 588 193 189 588 minecraft:quartz_block
fill 193 188 590 193 189 590 minecraft:quartz_block
fill 196 188 559 196 189 559 minecraft:quartz_block
fill 196 188 561 196 189 561 minecraft:quartz_block
fill 196 188 563 196 189 563 minecraft:quartz_block
fill 197 188 558 197 189 558 minecraft:quartz_block
fill 197 188 560 197 189 560 minecraft:quartz_block
fill 197 188 562 197 189 562 minecraft:quartz_block
fill 197 188 564 197 189 564 minecraft:quartz_block
fill 198 188 559 198 189 559 minecraft:quartz_block
fill 198 188 561 198 189 561 minecraft:quartz_block
fill 198 188 563 198 189 563 minecraft:quartz_block
fill 199 188 558 199 189 558 minecraft:quartz_block
fill 199 188 560 199 189 560 minecraft:quartz_block
fill 199 188 562 199 189 562 minecraft:quartz_block
fill 199 188 564 199 189 564 minecraft:quartz_block
fill 200 188 559 200 189 559 minecraft:quartz_block
fill 200 188 561 200 189 561 minecraft:quartz_block
fill 200 188 563 200 189 563 minecraft:quartz_block
fill 201 188 558 201 189 558 minecraft:quartz_block
fill 201 188 560 201 189 560 minecraft:quartz_block
fill 201 188 562 201 189 562 minecraft:quartz_block
fill 201 188 564 201 189 564 minecraft:quartz_block
fill 202 188 559 202 189 559 minecraft:quartz_block
fill 202 188 561 202 189 561 minecraft:quartz_block
fill 202 188 563 202 189 563 minecraft:quartz_block
fill 203 188 558 203 189 558 minecraft:quartz_block
fill 203 188 560 203 189 560 minecraft:quartz_block
fill 203 188 562 203 189 562 minecraft:quartz_block
fill 203 188 564 203 189 564 minecraft:quartz_block
fill 204 188 559 204 189 559 minecraft:quartz_block
fill 204 188 561 204 189 561 minecraft:quartz_block
fill 204 188 563 204 189 563 minecraft:quartz_block
fill 216 188 559 216 189 559 minecraft:quartz_block
fill 216 188 561 216 189 561 minecraft:quartz_block
fill 216 188 563 216 189 563 minecraft:quartz_block
fill 216 188 565 216 189 565 minecraft:quartz_block
fill 216 188 567 216 189 567 minecraft:quartz_block
fill 217 188 558 217 189 558 minecraft:quartz_block
fill 217 188 560 217 189 560 minecraft:quartz_block
fill 217 188 562 217 189 562 minecraft:quartz_block
fill 217 188 564 217 189 564 minecraft:quartz_block
fill 217 188 566 217 189 566 minecraft:quartz_block
fill 218 188 559 218 189 559 minecraft:quartz_block
fill 218 188 561 218 189 561 minecraft:quartz_block
fill 218 188 563 218 189 563 minecraft:quartz_block
fill 218 188 565 218 189 565 minecraft:quartz_block
fill 218 188 567 218 189 567 minecraft:quartz_block
fill 219 188 558 219 189 558 minecraft:quartz_block
fill 219 188 560 219 189 560 minecraft:quartz_block
fill 219 188 562 219 189 562 minecraft:quartz_block
fill 219 188 564 219 189 564 minecraft:quartz_block
fill 219 188 566 219 189 566 minecraft:quartz_block
fill 220 188 559 220 189 559 minecraft:quartz_block
fill 220 188 561 220 189 561 minecraft:quartz_block
fill 220 188 563 220 189 563 minecraft:quartz_block
fill 220 188 565 220 189 565 minecraft:quartz_block
fill 220 188 567 220 189 567 minecraft:quartz_block
fill 221 188 558 221 189 558 minecraft:quartz_block
fill 221 188 560 221 189 560 minecraft:quartz_block
fill 221 188 562 221 189 562 minecraft:quartz_block
fill 221 188 564 221 189 564 minecraft:quartz_block
fill 221 188 566 221 189 566 minecraft:quartz_block
fill 222 188 559 222 189 559 minecraft:quartz_block
fill 222 188 561 222 189 561 minecraft:quartz_block
fill 222 188 563 222 189 563 minecraft:quartz_block
fill 222 188 565 222 189 565 minecraft:quartz_block
fill 222 188 567 222 189 567 minecraft:quartz_block
fill 223 188 558 223 189 558 minecraft:quartz_block
fill 223 188 560 223 189 560 minecraft:quartz_block
fill 223 188 562 223 189 562 minecraft:quartz_block
fill 223 188 564 223 189 564 minecraft:quartz_block
fill 223 188 566 223 189 566 minecraft:quartz_block
fill 224 188 559 224 189 559 minecraft:quartz_block
fill 224 188 561 224 189 561 minecraft:quartz_block
fill 224 188 563 224 189 563 minecraft:quartz_block
fill 224 188 565 224 189 565 minecraft:quartz_block
fill 224 188 567 224 189 567 minecraft:quartz_block
fill 225 188 558 225 189 558 minecraft:quartz_block
fill 225 188 560 225 189 560 minecraft:quartz_block
fill 225 188 562 225 189 562 minecraft:quartz_block
fill 225 188 564 225 189 564 minecraft:quartz_block
fill 225 188 566 225 189 566 minecraft:quartz_block
fill 226 188 559 226 189 559 minecraft:quartz_block
fill 226 188 561 226 189 561 minecraft:quartz_block
fill 226 188 563 226 189 563 minecraft:quartz_block
fill 226 188 565 226 189 565 minecraft:quartz_block
fill 226 188 567 226 189 567 minecraft:quartz_block
fill 227 188 558 227 189 558 minecraft:quartz_block
fill 227 188 560 227 189 560 minecraft:quartz_block
fill 227 188 562 227 189 562 minecraft:quartz_block
fill 227 188 564 227 189 564 minecraft:quartz_block
fill 227 188 566 227 189 566 minecraft:quartz_block
fill 228 188 559 228 189 559 minecraft:quartz_block
fill 228 188 561 228 189 561 minecraft:quartz_block
fill 228 188 563 228 189 563 minecraft:quartz_block
fill 228 188 565 228 189 565 minecraft:quartz_block
fill 228 188 567 228 189 567 minecraft:quartz_block
fill 215 189 561 215 190 561 minecraft:gold_block
setblock 189 190 578 minecraft:ochre_froglight
setblock 189 190 580 minecraft:ochre_froglight
setblock 189 190 582 minecraft:ochre_froglight
setblock 189 190 584 minecraft:ochre_froglight
setblock 189 190 586 minecraft:ochre_froglight
setblock 189 190 588 minecraft:ochre_froglight
setblock 189 190 590 minecraft:ochre_froglight
setblock 190 190 579 minecraft:ochre_froglight
setblock 190 190 581 minecraft:ochre_froglight
setblock 190 190 583 minecraft:ochre_froglight
setblock 190 190 585 minecraft:ochre_froglight
setblock 190 190 587 minecraft:ochre_froglight
setblock 190 190 589 minecraft:ochre_froglight
setblock 191 190 578 minecraft:ochre_froglight
setblock 191 190 580 minecraft:ochre_froglight
setblock 191 190 582 minecraft:ochre_froglight
setblock 191 190 584 minecraft:ochre_froglight
setblock 191 190 586 minecraft:ochre_froglight
setblock 191 190 588 minecraft:ochre_froglight
setblock 191 190 590 minecraft:ochre_froglight
setblock 192 190 579 minecraft:ochre_froglight
setblock 192 190 581 minecraft:ochre_froglight
setblock 192 190 583 minecraft:ochre_froglight
setblock 192 190 585 minecraft:ochre_froglight
setblock 192 190 587 minecraft:ochre_froglight
setblock 192 190 589 minecraft:ochre_froglight
setblock 193 190 578 minecraft:ochre_froglight
setblock 193 190 580 minecraft:ochre_froglight
setblock 193 190 582 minecraft:ochre_froglight
setblock 193 190 584 minecraft:ochre_froglight
setblock 193 190 586 minecraft:ochre_froglight
setblock 193 190 588 minecraft:ochre_froglight
setblock 193 190 590 minecraft:ochre_froglight
setblock 196 190 559 minecraft:ochre_froglight
setblock 196 190 561 minecraft:ochre_froglight
setblock 196 190 563 minecraft:ochre_froglight
setblock 197 190 558 minecraft:ochre_froglight
setblock 197 190 560 minecraft:ochre_froglight
setblock 197 190 562 minecraft:ochre_froglight
setblock 197 190 564 minecraft:ochre_froglight
setblock 198 190 559 minecraft:ochre_froglight
setblock 198 190 561 minecraft:ochre_froglight
setblock 198 190 563 minecraft:ochre_froglight
setblock 199 190 558 minecraft:ochre_froglight
setblock 199 190 560 minecraft:ochre_froglight
setblock 199 190 562 minecraft:ochre_froglight
setblock 199 190 564 minecraft:ochre_froglight
setblock 200 190 559 minecraft:ochre_froglight
setblock 200 190 561 minecraft:ochre_froglight
setblock 200 190 563 minecraft:ochre_froglight
setblock 201 190 558 minecraft:ochre_froglight
setblock 201 190 560 minecraft:ochre_froglight
setblock 201 190 562 minecraft:ochre_froglight
setblock 201 190 564 minecraft:ochre_froglight
setblock 202 190 559 minecraft:ochre_froglight
setblock 202 190 561 minecraft:ochre_froglight
setblock 202 190 563 minecraft:ochre_froglight
setblock 203 190 558 minecraft:ochre_froglight
setblock 203 190 560 minecraft:ochre_froglight
setblock 203 190 562 minecraft:ochre_froglight
setblock 203 190 564 minecraft:ochre_froglight
setblock 204 190 559 minecraft:ochre_froglight
setblock 204 190 561 minecraft:ochre_froglight
setblock 204 190 563 minecraft:ochre_froglight
setblock 216 190 559 minecraft:ochre_froglight
setblock 216 190 561 minecraft:ochre_froglight
setblock 216 190 563 minecraft:ochre_froglight
setblock 216 190 565 minecraft:ochre_froglight
setblock 216 190 567 minecraft:ochre_froglight
setblock 217 190 558 minecraft:ochre_froglight
setblock 217 190 560 minecraft:ochre_froglight
setblock 217 190 562 minecraft:ochre_froglight
setblock 217 190 564 minecraft:ochre_froglight
setblock 217 190 566 minecraft:ochre_froglight
setblock 218 190 559 minecraft:ochre_froglight
setblock 218 190 561 minecraft:ochre_froglight
setblock 218 190 563 minecraft:ochre_froglight
setblock 218 190 565 minecraft:ochre_froglight
setblock 218 190 567 minecraft:ochre_froglight
setblock 219 190 558 minecraft:ochre_froglight
setblock 219 190 560 minecraft:ochre_froglight
setblock 219 190 562 minecraft:ochre_froglight
setblock 219 190 564 minecraft:ochre_froglight
setblock 219 190 566 minecraft:ochre_froglight
setblock 220 190 559 minecraft:ochre_froglight
setblock 220 190 561 minecraft:ochre_froglight
setblock 220 190 563 minecraft:ochre_froglight
setblock 220 190 565 minecraft:ochre_froglight
setblock 220 190 567 minecraft:ochre_froglight
setblock 221 190 558 minecraft:ochre_froglight
setblock 221 190 560 minecraft:ochre_froglight
setblock 221 190 562 minecraft:ochre_froglight
setblock 221 190 564 minecraft:ochre_froglight
setblock 221 190 566 minecraft:ochre_froglight
setblock 222 190 559 minecraft:ochre_froglight
setblock 222 190 561 minecraft:ochre_froglight
setblock 222 190 563 minecraft:ochre_froglight
setblock 222 190 565 minecraft:ochre_froglight
setblock 222 190 567 minecraft:ochre_froglight
setblock 223 190 558 minecraft:ochre_froglight
setblock 223 190 560 minecraft:ochre_froglight
setblock 223 190 562 minecraft:ochre_froglight
setblock 223 190 564 minecraft:ochre_froglight
setblock 223 190 566 minecraft:ochre_froglight
setblock 224 190 559 minecraft:ochre_froglight
setblock 224 190 561 minecraft:ochre_froglight
setblock 224 190 563 minecraft:ochre_froglight
setblock 224 190 565 minecraft:ochre_froglight
setblock 224 190 567 minecraft:ochre_froglight
setblock 225 190 558 minecraft:ochre_froglight
setblock 225 190 560 minecraft:ochre_froglight
setblock 225 190 562 minecraft:ochre_froglight
setblock 225 190 564 minecraft:ochre_froglight
setblock 225 190 566 minecraft:ochre_froglight
setblock 226 190 559 minecraft:ochre_froglight
setblock 226 190 561 minecraft:ochre_froglight
setblock 226 190 563 minecraft:ochre_froglight
setblock 226 190 565 minecraft:ochre_froglight
setblock 226 190 567 minecraft:ochre_froglight
setblock 227 190 558 minecraft:ochre_froglight
setblock 227 190 560 minecraft:ochre_froglight
setblock 227 190 562 minecraft:ochre_froglight
setblock 227 190 564 minecraft:ochre_froglight
setblock 227 190 566 minecraft:ochre_froglight
setblock 228 190 559 minecraft:ochre_froglight
setblock 228 190 561 minecraft:ochre_froglight
setblock 228 190 563 minecraft:ochre_froglight
setblock 228 190 565 minecraft:ochre_froglight
setblock 228 190 567 minecraft:ochre_froglight
fill 189 191 578 189 192 578 minecraft:quartz_block
fill 189 191 580 189 192 580 minecraft:quartz_block
fill 189 191 582 189 192 582 minecraft:quartz_block
fill 189 191 584 189 192 584 minecraft:quartz_block
fill 189 191 586 189 192 586 minecraft:quartz_block
fill 189 191 588 189 192 588 minecraft:quartz_block
fill 189 191 590 189 192 590 minecraft:quartz_block
fill 190 191 579 190 192 579 minecraft:quartz_block
fill 190 191 581 190 192 581 minecraft:quartz_block
fill 190 191 583 190 192 583 minecraft:quartz_block
fill 190 191 585 190 192 585 minecraft:quartz_block
fill 190 191 587 190 192 587 minecraft:quartz_block
fill 190 191 589 190 192 589 minecraft:quartz_block
fill 191 191 578 191 192 578 minecraft:quartz_block
fill 191 191 580 191 192 580 minecraft:quartz_block
fill 191 191 582 191 192 582 minecraft:quartz_block
fill 191 191 584 191 192 584 minecraft:quartz_block
fill 191 191 586 191 192 586 minecraft:quartz_block
fill 191 191 588 191 192 588 minecraft:quartz_block
fill 191 191 590 191 192 590 minecraft:quartz_block
fill 192 191 579 192 192 579 minecraft:quartz_block
fill 192 191 581 192 192 581 minecraft:quartz_block
fill 192 191 583 192 192 583 minecraft:quartz_block
fill 192 191 585 192 192 585 minecraft:quartz_block
fill 192 191 587 192 192 587 minecraft:quartz_block
fill 192 191 589 192 192 589 minecraft:quartz_block
fill 193 191 578 193 192 578 minecraft:quartz_block
fill 193 191 580 193 192 580 minecraft:quartz_block
fill 193 191 582 193 192 582 minecraft:quartz_block
fill 193 191 584 193 192 584 minecraft:quartz_block
fill 193 191 586 193 192 586 minecraft:quartz_block
fill 193 191 588 193 192 588 minecraft:quartz_block
fill 193 191 590 193 192 590 minecraft:quartz_block
fill 196 191 559 196 192 559 minecraft:quartz_block
fill 196 191 561 196 192 561 minecraft:quartz_block
fill 196 191 563 196 192 563 minecraft:quartz_block
fill 197 191 558 197 192 558 minecraft:quartz_block
fill 197 191 560 197 192 560 minecraft:quartz_block
fill 197 191 562 197 192 562 minecraft:quartz_block
fill 197 191 564 197 192 564 minecraft:quartz_block
fill 198 191 559 198 192 559 minecraft:quartz_block
fill 198 191 561 198 192 561 minecraft:quartz_block
fill 198 191 563 198 192 563 minecraft:quartz_block
fill 199 191 558 199 192 558 minecraft:quartz_block
fill 199 191 560 199 192 560 minecraft:quartz_block
fill 199 191 562 199 192 562 minecraft:quartz_block
fill 199 191 564 199 192 564 minecraft:quartz_block
fill 200 191 559 200 192 559 minecraft:quartz_block
fill 200 191 561 200 192 561 minecraft:quartz_block
fill 200 191 563 200 192 563 minecraft:quartz_block
fill 201 191 558 201 192 558 minecraft:quartz_block
fill 201 191 560 201 192 560 minecraft:quartz_block
fill 201 191 562 201 192 562 minecraft:quartz_block
fill 201 191 564 201 192 564 minecraft:quartz_block
fill 202 191 559 202 192 559 minecraft:quartz_block
fill 202 191 561 202 192 561 minecraft:quartz_block
fill 202 191 563 202 192 563 minecraft:quartz_block
fill 203 191 558 203 192 558 minecraft:quartz_block
fill 203 191 560 203 192 560 minecraft:quartz_block
fill 203 191 562 203 192 562 minecraft:quartz_block
fill 203 191 564 203 192 564 minecraft:quartz_block
fill 204 191 559 204 192 559 minecraft:quartz_block
fill 204 191 561 204 192 561 minecraft:quartz_block
fill 204 191 563 204 192 563 minecraft:quartz_block
fill 216 191 559 216 192 559 minecraft:quartz_block
fill 216 191 561 216 192 561 minecraft:quartz_block
fill 216 191 563 216 192 563 minecraft:quartz_block
fill 216 191 565 216 192 565 minecraft:quartz_block
fill 216 191 567 216 192 567 minecraft:quartz_block
fill 217 191 558 217 192 558 minecraft:quartz_block
fill 217 191 560 217 192 560 minecraft:quartz_block
fill 217 191 562 217 192 562 minecraft:quartz_block
fill 217 191 564 217 192 564 minecraft:quartz_block
fill 217 191 566 217 192 566 minecraft:quartz_block
fill 218 191 559 218 192 559 minecraft:quartz_block
fill 218 191 561 218 192 561 minecraft:quartz_block
fill 218 191 563 218 192 563 minecraft:quartz_block
fill 218 191 565 218 192 565 minecraft:quartz_block
fill 218 191 567 218 192 567 minecraft:quartz_block
fill 219 191 558 219 192 558 minecraft:quartz_block
fill 219 191 560 219 192 560 minecraft:quartz_block
fill 219 191 562 219 192 562 minecraft:quartz_block
fill 219 191 564 219 192 564 minecraft:quartz_block
fill 219 191 566 219 192 566 minecraft:quartz_block
fill 220 191 559 220 192 559 minecraft:quartz_block
fill 220 191 561 220 192 561 minecraft:quartz_block
fill 220 191 563 220 192 563 minecraft:quartz_block
fill 220 191 565 220 192 565 minecraft:quartz_block
fill 220 191 567 220 192 567 minecraft:quartz_block
fill 221 191 558 221 192 558 minecraft:quartz_block
fill 221 191 560 221 192 560 minecraft:quartz_block
fill 221 191 562 221 192 562 minecraft:quartz_block
fill 221 191 564 221 192 564 minecraft:quartz_block
fill 221 191 566 221 192 566 minecraft:quartz_block
fill 222 191 559 222 192 559 minecraft:quartz_block
fill 222 191 561 222 192 561 minecraft:quartz_block
fill 222 191 563 222 192 563 minecraft:quartz_block
fill 222 191 565 222 192 565 minecraft:quartz_block
fill 222 191 567 222 192 567 minecraft:quartz_block
fill 223 191 558 223 192 558 minecraft:quartz_block
fill 223 191 560 223 192 560 minecraft:quartz_block
fill 223 191 562 223 192 562 minecraft:quartz_block
fill 223 191 564 223 192 564 minecraft:quartz_block
fill 223 191 566 223 192 566 minecraft:quartz_block
fill 224 191 559 224 192 559 minecraft:quartz_block
fill 224 191 561 224 192 561 minecraft:quartz_block
fill 224 191 563 224 192 563 minecraft:quartz_block
fill 224 191 565 224 192 565 minecraft:quartz_block
fill 224 191 567 224 192 567 minecraft:quartz_block
fill 225 191 558 225 192 558 minecraft:quartz_block
fill 225 191 560 225 192 560 minecraft:quartz_block
fill 225 191 562 225 192 562 minecraft:quartz_block
fill 225 191 564 225 192 564 minecraft:quartz_block
fill 225 191 566 225 192 566 minecraft:quartz_block
fill 226 191 559 226 192 559 minecraft:quartz_block
fill 226 191 561 226 192 561 minecraft:quartz_block
fill 226 191 563 226 192 563 minecraft:quartz_block
fill 226 191 565 226 192 565 minecraft:quartz_block
fill 226 191 567 226 192 567 minecraft:quartz_block
fill 227 191 558 227 192 558 minecraft:quartz_block
fill 227 191 560 227 192 560 minecraft:quartz_block
fill 227 191 562 227 192 562 minecraft:quartz_block
fill 227 191 564 227 192 564 minecraft:quartz_block
fill 227 191 566 227 192 566 minecraft:quartz_block
fill 228 191 559 228 192 559 minecraft:quartz_block
fill 228 191 561 228 192 561 minecraft:quartz_block
fill 228 191 563 228 192 563 minecraft:quartz_block
fill 228 191 565 228 192 565 minecraft:quartz_block
fill 228 191 567 228 192 567 minecraft:quartz_block
fill 188 192 563 188 205 563 minecraft:yellow_terracotta
fill 188 192 564 188 192 565 minecraft:ochre_froglight
fill 188 192 566 188 205 566 minecraft:yellow_terracotta
fill 188 192 575 188 205 575 minecraft:yellow_terracotta
fill 188 192 576 188 192 577 minecraft:ochre_froglight
fill 188 192 578 188 205 578 minecraft:yellow_terracotta
fill 188 192 587 188 205 587 minecraft:yellow_terracotta
fill 188 192 588 188 192 589 minecraft:ochre_froglight
fill 188 192 590 188 205 590 minecraft:yellow_terracotta
fill 188 192 599 188 205 599 minecraft:yellow_terracotta
fill 189 192 599 190 192 599 minecraft:ochre_froglight
fill 191 192 599 191 205 599 minecraft:yellow_terracotta
fill 195 192 557 195 205 557 minecraft:yellow_terracotta
fill 196 192 557 197 192 557 minecraft:ochre_froglight
fill 198 192 557 198 205 557 minecraft:yellow_terracotta
fill 200 192 599 200 205 599 minecraft:yellow_terracotta
fill 201 192 599 202 192 599 minecraft:ochre_froglight
fill 203 192 599 203 205 599 minecraft:yellow_terracotta
fill 207 192 557 207 205 557 minecraft:yellow_terracotta
fill 208 192 557 209 192 557 minecraft:ochre_froglight
fill 210 192 557 210 205 557 minecraft:yellow_terracotta
fill 212 192 599 212 205 599 minecraft:yellow_terracotta
fill 213 192 599 214 192 599 minecraft:ochre_froglight
fill 215 192 599 215 205 599 minecraft:yellow_terracotta
fill 219 192 557 219 205 557 minecraft:yellow_terracotta
fill 220 192 557 221 192 557 minecraft:ochre_froglight
fill 222 192 557 222 205 557 minecraft:yellow_terracotta
fill 224 192 599 224 205 599 minecraft:yellow_terracotta
fill 225 192 599 226 192 599 minecraft:ochre_froglight
fill 227 192 599 227 205 599 minecraft:yellow_terracotta
fill 230 192 558 230 205 558 minecraft:yellow_terracotta
fill 230 192 559 230 192 560 minecraft:ochre_froglight
fill 230 192 561 230 205 561 minecraft:yellow_terracotta
fill 230 192 570 230 205 570 minecraft:yellow_terracotta
fill 230 192 571 230 192 572 minecraft:ochre_froglight
fill 230 192 573 230 205 573 minecraft:yellow_terracotta
fill 230 192 582 230 205 582 minecraft:yellow_terracotta
fill 230 192 583 230 192 584 minecraft:ochre_froglight
fill 230 192 585 230 205 585 minecraft:yellow_terracotta
fill 230 192 594 230 205 594 minecraft:yellow_terracotta
fill 230 192 595 230 192 596 minecraft:ochre_froglight
fill 230 192 597 230 205 597 minecraft:yellow_terracotta
fill 188 193 564 188 205 565 minecraft:yellow_terracotta
fill 188 193 576 188 205 577 minecraft:yellow_terracotta
fill 188 193 588 188 205 589 minecraft:yellow_terracotta
setblock 189 193 578 minecraft:ochre_froglight
setblock 189 193 580 minecraft:ochre_froglight
setblock 189 193 582 minecraft:ochre_froglight
setblock 189 193 584 minecraft:ochre_froglight
setblock 189 193 586 minecraft:ochre_froglight
setblock 189 193 588 minecraft:ochre_froglight
setblock 189 193 590 minecraft:ochre_froglight
fill 189 193 599 190 205 599 minecraft:yellow_terracotta
setblock 190 193 579 minecraft:ochre_froglight
setblock 190 193 581 minecraft:ochre_froglight
setblock 190 193 583 minecraft:ochre_froglight
setblock 190 193 585 minecraft:ochre_froglight
setblock 190 193 587 minecraft:ochre_froglight
setblock 190 193 589 minecraft:ochre_froglight
setblock 191 193 578 minecraft:ochre_froglight
setblock 191 193 580 minecraft:ochre_froglight
setblock 191 193 582 minecraft:ochre_froglight
setblock 191 193 584 minecraft:ochre_froglight
setblock 191 193 586 minecraft:ochre_froglight
setblock 191 193 588 minecraft:ochre_froglight
setblock 191 193 590 minecraft:ochre_froglight
setblock 192 193 579 minecraft:ochre_froglight
setblock 192 193 581 minecraft:ochre_froglight
setblock 192 193 583 minecraft:ochre_froglight
setblock 192 193 585 minecraft:ochre_froglight
setblock 192 193 587 minecraft:ochre_froglight
setblock 192 193 589 minecraft:ochre_froglight
setblock 193 193 578 minecraft:ochre_froglight
setblock 193 193 580 minecraft:ochre_froglight
setblock 193 193 582 minecraft:ochre_froglight
setblock 193 193 584 minecraft:ochre_froglight
setblock 193 193 586 minecraft:ochre_froglight
setblock 193 193 588 minecraft:ochre_froglight
setblock 193 193 590 minecraft:ochre_froglight
fill 196 193 557 197 205 557 minecraft:yellow_terracotta
setblock 196 193 559 minecraft:ochre_froglight
setblock 196 193 561 minecraft:ochre_froglight
setblock 196 193 563 minecraft:ochre_froglight
setblock 197 193 558 minecraft:ochre_froglight
setblock 197 193 560 minecraft:ochre_froglight
setblock 197 193 562 minecraft:ochre_froglight
setblock 197 193 564 minecraft:ochre_froglight
setblock 198 193 559 minecraft:ochre_froglight
setblock 198 193 561 minecraft:ochre_froglight
setblock 198 193 563 minecraft:ochre_froglight
setblock 199 193 558 minecraft:ochre_froglight
setblock 199 193 560 minecraft:ochre_froglight
setblock 199 193 562 minecraft:ochre_froglight
setblock 199 193 564 minecraft:ochre_froglight
setblock 200 193 559 minecraft:ochre_froglight
setblock 200 193 561 minecraft:ochre_froglight
setblock 200 193 563 minecraft:ochre_froglight
setblock 201 193 558 minecraft:ochre_froglight
setblock 201 193 560 minecraft:ochre_froglight
setblock 201 193 562 minecraft:ochre_froglight
setblock 201 193 564 minecraft:ochre_froglight
fill 201 193 599 202 205 599 minecraft:yellow_terracotta
setblock 202 193 559 minecraft:ochre_froglight
setblock 202 193 561 minecraft:ochre_froglight
setblock 202 193 563 minecraft:ochre_froglight
setblock 203 193 558 minecraft:ochre_froglight
setblock 203 193 560 minecraft:ochre_froglight
setblock 203 193 562 minecraft:ochre_froglight
setblock 203 193 564 minecraft:ochre_froglight
setblock 204 193 559 minecraft:ochre_froglight
setblock 204 193 561 minecraft:ochre_froglight
setblock 204 193 563 minecraft:ochre_froglight
fill 208 193 557 209 205 557 minecraft:yellow_terracotta
fill 213 193 599 214 205 599 minecraft:yellow_terracotta
setblock 216 193 559 minecraft:ochre_froglight
setblock 216 193 561 minecraft:ochre_froglight
setblock 216 193 563 minecraft:ochre_froglight
setblock 216 193 565 minecraft:ochre_froglight
setblock 216 193 567 minecraft:ochre_froglight
setblock 217 193 558 minecraft:ochre_froglight
setblock 217 193 560 minecraft:ochre_froglight
setblock 217 193 562 minecraft:ochre_froglight
setblock 217 193 564 minecraft:ochre_froglight
setblock 217 193 566 minecraft:ochre_froglight
setblock 218 193 559 minecraft:ochre_froglight
setblock 218 193 561 minecraft:ochre_froglight
setblock 218 193 563 minecraft:ochre_froglight
setblock 218 193 565 minecraft:ochre_froglight
setblock 218 193 567 minecraft:ochre_froglight
setblock 219 193 558 minecraft:ochre_froglight
setblock 219 193 560 minecraft:ochre_froglight
setblock 219 193 562 minecraft:ochre_froglight
setblock 219 193 564 minecraft:ochre_froglight
setblock 219 193 566 minecraft:ochre_froglight
fill 220 193 557 221 205 557 minecraft:yellow_terracotta
setblock 220 193 559 minecraft:ochre_froglight
setblock 220 193 561 minecraft:ochre_froglight
setblock 220 193 563 minecraft:ochre_froglight
setblock 220 193 565 minecraft:ochre_froglight
setblock 220 193 567 minecraft:ochre_froglight
setblock 221 193 558 minecraft:ochre_froglight
setblock 221 193 560 minecraft:ochre_froglight
setblock 221 193 562 minecraft:ochre_froglight
setblock 221 193 564 minecraft:ochre_froglight
setblock 221 193 566 minecraft:ochre_froglight
setblock 222 193 559 minecraft:ochre_froglight
setblock 222 193 561 minecraft:ochre_froglight
setblock 222 193 563 minecraft:ochre_froglight
setblock 222 193 565 minecraft:ochre_froglight
setblock 222 193 567 minecraft:ochre_froglight
setblock 223 193 558 minecraft:ochre_froglight
setblock 223 193 560 minecraft:ochre_froglight
setblock 223 193 562 minecraft:ochre_froglight
setblock 223 193 564 minecraft:ochre_froglight
setblock 223 193 566 minecraft:ochre_froglight
setblock 224 193 559 minecraft:ochre_froglight
setblock 224 193 561 minecraft:ochre_froglight
setblock 224 193 563 minecraft:ochre_froglight
setblock 224 193 565 minecraft:ochre_froglight
setblock 224 193 567 minecraft:ochre_froglight
setblock 225 193 558 minecraft:ochre_froglight
setblock 225 193 560 minecraft:ochre_froglight
setblock 225 193 562 minecraft:ochre_froglight
setblock 225 193 564 minecraft:ochre_froglight
setblock 225 193 566 minecraft:ochre_froglight
fill 225 193 599 226 205 599 minecraft:yellow_terracotta
setblock 226 193 559 minecraft:ochre_froglight
setblock 226 193 561 minecraft:ochre_froglight
setblock 226 193 563 minecraft:ochre_froglight
setblock 226 193 565 minecraft:ochre_froglight
setblock 226 193 567 minecraft:ochre_froglight
setblock 227 193 558 minecraft:ochre_froglight
setblock 227 193 560 minecraft:ochre_froglight
setblock 227 193 562 minecraft:ochre_froglight
setblock 227 193 564 minecraft:ochre_froglight
setblock 227 193 566 minecraft:ochre_froglight
setblock 228 193 559 minecraft:ochre_froglight
setblock 228 193 561 minecraft:ochre_froglight
setblock 228 193 563 minecraft:ochre_froglight
setblock 228 193 565 minecraft:ochre_froglight
setblock 228 193 567 minecraft:ochre_froglight
fill 230 193 559 230 205 560 minecraft:yellow_terracotta
fill 230 193 571 230 205 572 minecraft:yellow_terracotta
fill 230 193 583 230 205 584 minecraft:yellow_terracotta
fill 230 193 595 230 205 596 minecraft:yellow_terracotta
setblock 189 194 578 minecraft:quartz_block
fill 189 194 580 189 228 580 minecraft:quartz_block
fill 189 194 582 189 228 582 minecraft:quartz_block
setblock 189 194 584 minecraft:quartz_block
setblock 189 194 586 minecraft:quartz_block
setblock 189 194 588 minecraft:quartz_block
setblock 189 194 590 minecraft:quartz_block
setblock 190 194 579 minecraft:quartz_block
setblock 190 194 581 minecraft:quartz_block
setblock 190 194 583 minecraft:quartz_block
setblock 190 194 585 minecraft:quartz_block
setblock 190 194 587 minecraft:quartz_block
setblock 190 194 589 minecraft:quartz_block
setblock 191 194 560 minecraft:light[level=14]
setblock 191 194 568 minecraft:light[level=14]
setblock 191 194 576 minecraft:light[level=14]
setblock 191 194 578 minecraft:quartz_block
setblock 191 194 580 minecraft:quartz_block
setblock 191 194 582 minecraft:quartz_block
setblock 191 194 584 minecraft:quartz_block
setblock 191 194 586 minecraft:quartz_block
setblock 191 194 588 minecraft:quartz_block
setblock 191 194 590 minecraft:quartz_block
setblock 191 194 592 minecraft:light[level=14]
setblock 192 194 579 minecraft:quartz_block
setblock 192 194 581 minecraft:quartz_block
setblock 192 194 583 minecraft:quartz_block
setblock 192 194 585 minecraft:quartz_block
setblock 192 194 587 minecraft:quartz_block
setblock 192 194 589 minecraft:quartz_block
setblock 193 194 578 minecraft:quartz_block
setblock 193 194 580 minecraft:quartz_block
setblock 193 194 582 minecraft:quartz_block
setblock 193 194 584 minecraft:quartz_block
setblock 193 194 586 minecraft:quartz_block
setblock 193 194 588 minecraft:quartz_block
setblock 193 194 590 minecraft:quartz_block
fill 196 194 559 196 195 559 minecraft:quartz_block
fill 196 194 561 196 195 561 minecraft:quartz_block
fill 196 194 563 196 195 563 minecraft:quartz_block
fill 197 194 558 197 195 558 minecraft:quartz_block
fill 197 194 560 197 195 560 minecraft:quartz_block
fill 197 194 562 197 195 562 minecraft:quartz_block
fill 197 194 564 197 195 564 minecraft:quartz_block
fill 198 194 559 198 195 559 minecraft:quartz_block
fill 198 194 561 198 195 561 minecraft:quartz_block
fill 198 194 563 198 195 563 minecraft:quartz_block
fill 199 194 558 199 195 558 minecraft:quartz_block
fill 199 194 560 199 195 560 minecraft:quartz_block
fill 199 194 562 199 195 562 minecraft:quartz_block
fill 199 194 564 199 195 564 minecraft:quartz_block
setblock 199 194 568 minecraft:light[level=14]
setblock 199 194 576 minecraft:light[level=14]
setblock 199 194 584 minecraft:light[level=14]
setblock 199 194 592 minecraft:light[level=14]
fill 200 194 559 200 195 559 minecraft:quartz_block
fill 200 194 561 200 195 561 minecraft:quartz_block
fill 200 194 563 200 195 563 minecraft:quartz_block
fill 201 194 558 201 195 558 minecraft:quartz_block
fill 201 194 560 201 195 560 minecraft:quartz_block
fill 201 194 562 201 195 562 minecraft:quartz_block
fill 201 194 564 201 195 564 minecraft:quartz_block
fill 202 194 559 202 195 559 minecraft:quartz_block
fill 202 194 561 202 195 561 minecraft:quartz_block
fill 202 194 563 202 195 563 minecraft:quartz_block
fill 203 194 558 203 195 558 minecraft:quartz_block
fill 203 194 560 203 195 560 minecraft:quartz_block
fill 203 194 562 203 195 562 minecraft:quartz_block
fill 203 194 564 203 195 564 minecraft:quartz_block
fill 204 194 559 204 195 559 minecraft:quartz_block
fill 204 194 561 204 195 561 minecraft:quartz_block
fill 204 194 563 204 195 563 minecraft:quartz_block
setblock 207 194 560 minecraft:light[level=14]
setblock 207 194 568 minecraft:light[level=14]
setblock 207 194 576 minecraft:light[level=14]
setblock 207 194 584 minecraft:light[level=14]
setblock 207 194 592 minecraft:light[level=14]
setblock 215 194 560 minecraft:light[level=14]
setblock 215 194 568 minecraft:light[level=14]
setblock 215 194 576 minecraft:light[level=14]
setblock 215 194 584 minecraft:light[level=14]
setblock 215 194 592 minecraft:light[level=14]
fill 216 194 559 216 195 559 minecraft:quartz_block
fill 216 194 561 216 195 561 minecraft:quartz_block
fill 216 194 563 216 195 563 minecraft:quartz_block
fill 216 194 565 216 195 565 minecraft:quartz_block
fill 216 194 567 216 195 567 minecraft:quartz_block
fill 217 194 558 217 195 558 minecraft:quartz_block
fill 217 194 560 217 195 560 minecraft:quartz_block
fill 217 194 562 217 195 562 minecraft:quartz_block
fill 217 194 564 217 195 564 minecraft:quartz_block
fill 217 194 566 217 195 566 minecraft:quartz_block
fill 218 194 559 218 195 559 minecraft:quartz_block
fill 218 194 561 218 195 561 minecraft:quartz_block
fill 218 194 563 218 195 563 minecraft:quartz_block
fill 218 194 565 218 195 565 minecraft:quartz_block
fill 218 194 567 218 195 567 minecraft:quartz_block
fill 219 194 558 219 195 558 minecraft:quartz_block
fill 219 194 560 219 195 560 minecraft:quartz_block
fill 219 194 562 219 195 562 minecraft:quartz_block
fill 219 194 564 219 195 564 minecraft:quartz_block
fill 219 194 566 219 195 566 minecraft:quartz_block
fill 220 194 559 220 195 559 minecraft:quartz_block
fill 220 194 561 220 195 561 minecraft:quartz_block
fill 220 194 563 220 195 563 minecraft:quartz_block
fill 220 194 565 220 195 565 minecraft:quartz_block
fill 220 194 567 220 195 567 minecraft:quartz_block
fill 221 194 558 221 195 558 minecraft:quartz_block
fill 221 194 560 221 195 560 minecraft:quartz_block
fill 221 194 562 221 195 562 minecraft:quartz_block
fill 221 194 564 221 195 564 minecraft:quartz_block
fill 221 194 566 221 195 566 minecraft:quartz_block
fill 222 194 559 222 195 559 minecraft:quartz_block
fill 222 194 561 222 195 561 minecraft:quartz_block
fill 222 194 563 222 195 563 minecraft:quartz_block
fill 222 194 565 222 195 565 minecraft:quartz_block
fill 222 194 567 222 195 567 minecraft:quartz_block
fill 223 194 558 223 195 558 minecraft:quartz_block
fill 223 194 560 223 195 560 minecraft:quartz_block
fill 223 194 562 223 195 562 minecraft:quartz_block
fill 223 194 564 223 195 564 minecraft:quartz_block
fill 223 194 566 223 195 566 minecraft:quartz_block
setblock 223 194 568 minecraft:light[level=14]
setblock 223 194 576 minecraft:light[level=14]
setblock 223 194 584 minecraft:light[level=14]
setblock 223 194 592 minecraft:light[level=14]
fill 224 194 559 224 195 559 minecraft:quartz_block
fill 224 194 561 224 195 561 minecraft:quartz_block
fill 224 194 563 224 195 563 minecraft:quartz_block
fill 224 194 565 224 195 565 minecraft:quartz_block
fill 224 194 567 224 195 567 minecraft:quartz_block
fill 225 194 558 225 195 558 minecraft:quartz_block
fill 225 194 560 225 195 560 minecraft:quartz_block
fill 225 194 562 225 195 562 minecraft:quartz_block
fill 225 194 564 225 195 564 minecraft:quartz_block
fill 225 194 566 225 195 566 minecraft:quartz_block
fill 226 194 559 226 195 559 minecraft:quartz_block
fill 226 194 561 226 195 561 minecraft:quartz_block
fill 226 194 563 226 195 563 minecraft:quartz_block
fill 226 194 565 226 195 565 minecraft:quartz_block
fill 226 194 567 226 195 567 minecraft:quartz_block
fill 227 194 558 227 195 558 minecraft:quartz_block
fill 227 194 560 227 195 560 minecraft:quartz_block
fill 227 194 562 227 195 562 minecraft:quartz_block
fill 227 194 564 227 195 564 minecraft:quartz_block
fill 227 194 566 227 195 566 minecraft:quartz_block
fill 228 194 559 228 195 559 minecraft:quartz_block
fill 228 194 561 228 195 561 minecraft:quartz_block
fill 228 194 563 228 195 563 minecraft:quartz_block
fill 228 194 565 228 195 565 minecraft:quartz_block
fill 228 194 567 228 195 567 minecraft:quartz_block
fill 190 195 579 192 195 589 minecraft:gold_block
fill 191 196 580 191 196 588 minecraft:gold_block
setblock 196 196 559 minecraft:ochre_froglight
setblock 196 196 561 minecraft:ochre_froglight
setblock 196 196 563 minecraft:ochre_froglight
setblock 197 196 558 minecraft:ochre_froglight
setblock 197 196 560 minecraft:ochre_froglight
setblock 197 196 562 minecraft:ochre_froglight
setblock 197 196 564 minecraft:ochre_froglight
setblock 198 196 559 minecraft:ochre_froglight
setblock 198 196 561 minecraft:ochre_froglight
setblock 198 196 563 minecraft:ochre_froglight
setblock 199 196 558 minecraft:ochre_froglight
setblock 199 196 560 minecraft:ochre_froglight
setblock 199 196 562 minecraft:ochre_froglight
setblock 199 196 564 minecraft:ochre_froglight
setblock 200 196 559 minecraft:ochre_froglight
setblock 200 196 561 minecraft:ochre_froglight
setblock 200 196 563 minecraft:ochre_froglight
setblock 201 196 558 minecraft:ochre_froglight
setblock 201 196 560 minecraft:ochre_froglight
setblock 201 196 562 minecraft:ochre_froglight
setblock 201 196 564 minecraft:ochre_froglight
fill 201 196 575 201 197 575 minecraft:stripped_dark_oak_log
setblock 202 196 559 minecraft:ochre_froglight
setblock 202 196 561 minecraft:ochre_froglight
setblock 202 196 563 minecraft:ochre_froglight
setblock 203 196 558 minecraft:ochre_froglight
setblock 203 196 560 minecraft:ochre_froglight
setblock 203 196 562 minecraft:ochre_froglight
setblock 203 196 564 minecraft:ochre_froglight
setblock 204 196 559 minecraft:ochre_froglight
setblock 204 196 561 minecraft:ochre_froglight
setblock 204 196 563 minecraft:ochre_froglight
setblock 216 196 559 minecraft:ochre_froglight
setblock 216 196 561 minecraft:ochre_froglight
setblock 216 196 563 minecraft:ochre_froglight
setblock 216 196 565 minecraft:ochre_froglight
setblock 216 196 567 minecraft:ochre_froglight
setblock 217 196 558 minecraft:ochre_froglight
setblock 217 196 560 minecraft:ochre_froglight
setblock 217 196 562 minecraft:ochre_froglight
setblock 217 196 564 minecraft:ochre_froglight
setblock 217 196 566 minecraft:ochre_froglight
setblock 218 196 559 minecraft:ochre_froglight
setblock 218 196 561 minecraft:ochre_froglight
setblock 218 196 563 minecraft:ochre_froglight
setblock 218 196 565 minecraft:ochre_froglight
setblock 218 196 567 minecraft:ochre_froglight
setblock 219 196 558 minecraft:ochre_froglight
setblock 219 196 560 minecraft:ochre_froglight
setblock 219 196 562 minecraft:ochre_froglight
setblock 219 196 564 minecraft:ochre_froglight
setblock 219 196 566 minecraft:ochre_froglight
setblock 220 196 559 minecraft:ochre_froglight
setblock 220 196 561 minecraft:ochre_froglight
setblock 220 196 563 minecraft:ochre_froglight
setblock 220 196 565 minecraft:ochre_froglight
setblock 220 196 567 minecraft:ochre_froglight
setblock 221 196 558 minecraft:ochre_froglight
setblock 221 196 560 minecraft:ochre_froglight
setblock 221 196 562 minecraft:ochre_froglight
setblock 221 196 564 minecraft:ochre_froglight
setblock 221 196 566 minecraft:ochre_froglight
setblock 222 196 559 minecraft:ochre_froglight
setblock 222 196 561 minecraft:ochre_froglight
setblock 222 196 563 minecraft:ochre_froglight
setblock 222 196 565 minecraft:ochre_froglight
setblock 222 196 567 minecraft:ochre_froglight
setblock 223 196 558 minecraft:ochre_froglight
setblock 223 196 560 minecraft:ochre_froglight
setblock 223 196 562 minecraft:ochre_froglight
setblock 223 196 564 minecraft:ochre_froglight
setblock 223 196 566 minecraft:ochre_froglight
setblock 224 196 559 minecraft:ochre_froglight
setblock 224 196 561 minecraft:ochre_froglight
setblock 224 196 563 minecraft:ochre_froglight
setblock 224 196 565 minecraft:ochre_froglight
setblock 224 196 567 minecraft:ochre_froglight
setblock 225 196 558 minecraft:ochre_froglight
setblock 225 196 560 minecraft:ochre_froglight
setblock 225 196 562 minecraft:ochre_froglight
setblock 225 196 564 minecraft:ochre_froglight
setblock 225 196 566 minecraft:ochre_froglight
setblock 226 196 559 minecraft:ochre_froglight
setblock 226 196 561 minecraft:ochre_froglight
setblock 226 196 563 minecraft:ochre_froglight
setblock 226 196 565 minecraft:ochre_froglight
setblock 226 196 567 minecraft:ochre_froglight
setblock 227 196 558 minecraft:ochre_froglight
setblock 227 196 560 minecraft:ochre_froglight
setblock 227 196 562 minecraft:ochre_froglight
setblock 227 196 564 minecraft:ochre_froglight
setblock 227 196 566 minecraft:ochre_froglight
setblock 228 196 559 minecraft:ochre_froglight
setblock 228 196 561 minecraft:ochre_froglight
setblock 228 196 563 minecraft:ochre_froglight
setblock 228 196 565 minecraft:ochre_froglight
setblock 228 196 567 minecraft:ochre_froglight
fill 190 197 581 192 197 587 minecraft:gold_block
fill 196 197 559 196 198 559 minecraft:quartz_block
fill 196 197 561 196 198 561 minecraft:quartz_block
fill 196 197 563 196 198 563 minecraft:quartz_block
fill 197 197 558 197 198 558 minecraft:quartz_block
fill 197 197 560 197 198 560 minecraft:quartz_block
fill 197 197 562 197 198 562 minecraft:quartz_block
fill 197 197 564 197 198 564 minecraft:quartz_block
fill 198 197 559 198 198 559 minecraft:quartz_block
fill 198 197 561 198 198 561 minecraft:quartz_block
fill 198 197 563 198 198 563 minecraft:quartz_block
fill 199 197 558 199 198 558 minecraft:quartz_block
fill 199 197 560 199 198 560 minecraft:quartz_block
fill 199 197 562 199 198 562 minecraft:quartz_block
fill 199 197 564 199 198 564 minecraft:quartz_block
fill 200 197 559 200 198 559 minecraft:quartz_block
fill 200 197 561 200 198 561 minecraft:quartz_block
fill 200 197 563 200 198 563 minecraft:quartz_block
fill 201 197 558 201 228 558 minecraft:quartz_block
fill 201 197 560 201 198 560 minecraft:quartz_block
fill 201 197 562 201 198 562 minecraft:quartz_block
fill 201 197 564 201 198 564 minecraft:quartz_block
fill 202 197 559 202 198 559 minecraft:quartz_block
fill 202 197 561 202 198 561 minecraft:quartz_block
fill 202 197 563 202 198 563 minecraft:quartz_block
fill 203 197 558 203 228 558 minecraft:quartz_block
fill 203 197 560 203 198 560 minecraft:quartz_block
fill 203 197 562 203 198 562 minecraft:quartz_block
fill 203 197 564 203 198 564 minecraft:quartz_block
fill 204 197 559 204 198 559 minecraft:quartz_block
fill 204 197 561 204 198 561 minecraft:quartz_block
fill 204 197 563 204 198 563 minecraft:quartz_block
setblock 216 197 559 minecraft:quartz_block
setblock 216 197 561 minecraft:quartz_block
setblock 216 197 563 minecraft:quartz_block
setblock 216 197 565 minecraft:quartz_block
setblock 216 197 567 minecraft:quartz_block
setblock 217 197 558 minecraft:quartz_block
setblock 217 197 560 minecraft:quartz_block
setblock 217 197 562 minecraft:quartz_block
setblock 217 197 564 minecraft:quartz_block
setblock 217 197 566 minecraft:quartz_block
setblock 218 197 559 minecraft:quartz_block
setblock 218 197 561 minecraft:quartz_block
setblock 218 197 563 minecraft:quartz_block
setblock 218 197 565 minecraft:quartz_block
setblock 218 197 567 minecraft:quartz_block
setblock 219 197 558 minecraft:quartz_block
setblock 219 197 560 minecraft:quartz_block
setblock 219 197 562 minecraft:quartz_block
setblock 219 197 564 minecraft:quartz_block
setblock 219 197 566 minecraft:quartz_block
setblock 220 197 559 minecraft:quartz_block
setblock 220 197 561 minecraft:quartz_block
setblock 220 197 563 minecraft:quartz_block
setblock 220 197 565 minecraft:quartz_block
setblock 220 197 567 minecraft:quartz_block
setblock 221 197 558 minecraft:quartz_block
setblock 221 197 560 minecraft:quartz_block
setblock 221 197 562 minecraft:quartz_block
setblock 221 197 564 minecraft:quartz_block
setblock 221 197 566 minecraft:quartz_block
setblock 222 197 559 minecraft:quartz_block
setblock 222 197 561 minecraft:quartz_block
setblock 222 197 563 minecraft:quartz_block
setblock 222 197 565 minecraft:quartz_block
setblock 222 197 567 minecraft:quartz_block
setblock 223 197 558 minecraft:quartz_block
setblock 223 197 560 minecraft:quartz_block
setblock 223 197 562 minecraft:quartz_block
setblock 223 197 564 minecraft:quartz_block
setblock 223 197 566 minecraft:quartz_block
setblock 224 197 559 minecraft:quartz_block
setblock 224 197 561 minecraft:quartz_block
setblock 224 197 563 minecraft:quartz_block
setblock 224 197 565 minecraft:quartz_block
setblock 224 197 567 minecraft:quartz_block
fill 225 197 558 225 228 558 minecraft:quartz_block
setblock 225 197 560 minecraft:quartz_block
setblock 225 197 562 minecraft:quartz_block
setblock 225 197 564 minecraft:quartz_block
setblock 225 197 566 minecraft:quartz_block
setblock 226 197 559 minecraft:quartz_block
setblock 226 197 561 minecraft:quartz_block
setblock 226 197 563 minecraft:quartz_block
setblock 226 197 565 minecraft:quartz_block
setblock 226 197 567 minecraft:quartz_block
fill 227 197 558 227 228 558 minecraft:quartz_block
setblock 227 197 560 minecraft:quartz_block
setblock 227 197 562 minecraft:quartz_block
setblock 227 197 564 minecraft:quartz_block
setblock 227 197 566 minecraft:quartz_block
setblock 228 197 559 minecraft:quartz_block
setblock 228 197 561 minecraft:quartz_block
setblock 228 197 563 minecraft:quartz_block
setblock 228 197 565 minecraft:quartz_block
setblock 228 197 567 minecraft:quartz_block
fill 189 198 583 193 198 586 minecraft:gold_block
fill 190 198 582 193 198 582 minecraft:gold_block
fill 205 198 558 207 199 558 minecraft:quartz_block
fill 205 198 597 206 199 598 minecraft:quartz_block
fill 207 198 597 207 199 597 minecraft:quartz_block
fill 213 198 558 215 228 558 minecraft:quartz_block
fill 217 198 559 227 198 566 minecraft:gold_block
fill 197 199 559 203 199 563 minecraft:gold_block
fill 205 199 559 207 200 559 minecraft:quartz_block
fill 205 199 596 207 200 596 minecraft:quartz_block
fill 206 199 560 206 202 560 minecraft:quartz_block
fill 206 199 595 206 202 595 minecraft:quartz_block
fill 218 199 560 226 199 565 minecraft:gold_block
fill 227 199 561 227 228 563 minecraft:quartz_block
fill 190 200 567 190 205 569 minecraft:quartz_block
fill 190 200 579 190 205 581 minecraft:quartz_block
fill 190 200 591 190 205 593 minecraft:quartz_block
fill 196 200 597 198 205 597 minecraft:quartz_block
fill 198 200 560 202 200 562 minecraft:gold_block
fill 200 200 559 202 205 559 minecraft:quartz_block
fill 205 200 560 205 201 560 minecraft:quartz_block
fill 205 200 595 205 201 595 minecraft:quartz_block
setblock 206 200 558 minecraft:quartz_block
fill 206 200 561 206 202 561 minecraft:quartz_block
fill 206 200 594 206 202 594 minecraft:quartz_block
setblock 206 200 597 minecraft:quartz_block
setblock 206 200 598 minecraft:gold_block
fill 207 200 560 207 201 560 minecraft:quartz_block
fill 207 200 595 207 201 595 minecraft:quartz_block
fill 208 200 597 210 205 597 minecraft:quartz_block
fill 212 200 559 214 205 559 minecraft:quartz_block
fill 219 200 561 225 200 564 minecraft:gold_block
fill 220 200 597 222 205 597 minecraft:quartz_block
fill 224 200 559 226 205 559 minecraft:quartz_block
fill 226 200 561 226 228 564 minecraft:quartz_block
fill 228 200 567 228 205 569 minecraft:quartz_block
fill 228 200 579 228 205 581 minecraft:quartz_block
fill 228 200 591 228 205 593 minecraft:quartz_block
fill 199 201 561 201 201 561 minecraft:gold_block
fill 205 201 561 205 202 562 minecraft:quartz_block
fill 205 201 593 205 202 594 minecraft:quartz_block
setblock 206 201 558 minecraft:gold_block
setblock 206 201 559 minecraft:quartz_block
fill 206 201 562 207 202 562 minecraft:quartz_block
fill 206 201 593 207 202 593 minecraft:quartz_block
setblock 206 201 596 minecraft:quartz_block
setblock 206 201 597 minecraft:gold_block
fill 207 201 561 207 202 561 minecraft:quartz_block
fill 207 201 594 207 202 594 minecraft:quartz_block
fill 220 201 562 224 201 563 minecraft:gold_block
fill 225 201 561 225 228 563 minecraft:quartz_block
setblock 191 202 560 minecraft:light[level=14]
setblock 191 202 568 minecraft:light[level=14]
setblock 191 202 576 minecraft:light[level=14]
setblock 191 202 584 minecraft:light[level=14]
setblock 191 202 592 minecraft:light[level=14]
setblock 199 202 560 minecraft:light[level=14]
setblock 199 202 568 minecraft:light[level=14]
setblock 199 202 576 minecraft:light[level=14]
setblock 199 202 584 minecraft:light[level=14]
setblock 199 202 592 minecraft:light[level=14]
fill 200 202 560 200 202 562 minecraft:gold_block
fill 205 202 563 207 203 563 minecraft:quartz_block
fill 205 202 592 207 203 592 minecraft:quartz_block
setblock 206 202 559 minecraft:gold_block
fill 206 202 564 206 204 564 minecraft:quartz_block
fill 206 202 591 206 204 591 minecraft:quartz_block
setblock 206 202 596 minecraft:gold_block
setblock 207 202 560 minecraft:light[level=14]
setblock 207 202 568 minecraft:light[level=14]
setblock 207 202 576 minecraft:light[level=14]
setblock 207 202 584 minecraft:light[level=14]
fill 215 202 559 215 213 559 minecraft:red_wool
setblock 215 202 560 minecraft:light[level=14]
setblock 215 202 568 minecraft:light[level=14]
setblock 215 202 576 minecraft:light[level=14]
setblock 215 202 584 minecraft:light[level=14]
setblock 215 202 592 minecraft:light[level=14]
setblock 223 202 560 minecraft:light[level=14]
setblock 223 202 568 minecraft:light[level=14]
setblock 223 202 576 minecraft:light[level=14]
setblock 223 202 584 minecraft:light[level=14]
setblock 223 202 592 minecraft:light[level=14]
fill 205 203 564 205 204 564 minecraft:quartz_block
fill 205 203 591 205 204 591 minecraft:quartz_block
setblock 206 203 561 minecraft:gold_block
setblock 206 203 562 minecraft:quartz_block
fill 206 203 565 206 205 565 minecraft:quartz_block
fill 206 203 590 206 205 590 minecraft:quartz_block
setblock 206 203 593 minecraft:quartz_block
setblock 206 203 594 minecraft:gold_block
fill 207 203 564 207 204 564 minecraft:quartz_block
fill 207 203 591 207 204 591 minecraft:quartz_block
fill 216 203 559 217 213 559 minecraft:red_wool
fill 218 203 580 218 204 581 minecraft:gold_block
fill 219 203 580 219 204 580 minecraft:gold_block
fill 205 204 565 205 204 566 minecraft:quartz_block
fill 205 204 589 205 204 590 minecraft:quartz_block
setblock 206 204 562 minecraft:gold_block
setblock 206 204 563 minecraft:quartz_block
fill 206 204 566 206 206 567 minecraft:quartz_block
fill 206 204 588 206 206 589 minecraft:quartz_block
setblock 206 204 592 minecraft:quartz_block
setblock 206 204 593 minecraft:gold_block
fill 207 204 565 207 204 566 minecraft:quartz_block
fill 207 204 589 207 204 590 minecraft:quartz_block
fill 189 205 561 189 205 566 minecraft:yellow_terracotta
fill 189 205 573 189 205 578 minecraft:yellow_terracotta
fill 189 205 585 189 205 590 minecraft:yellow_terracotta
fill 189 205 597 189 205 598 minecraft:yellow_terracotta
fill 190 205 598 193 205 598 minecraft:yellow_terracotta
fill 193 205 558 198 205 558 minecraft:yellow_terracotta
fill 200 205 598 205 205 598 minecraft:yellow_terracotta
fill 205 205 558 210 205 558 minecraft:yellow_terracotta
fill 205 205 566 205 205 568 minecraft:quartz_block
fill 205 205 587 205 205 589 minecraft:quartz_block
setblock 206 205 564 minecraft:gold_block
fill 206 205 568 206 206 569 minecraft:quartz_block
fill 206 205 586 206 207 587 minecraft:quartz_block
setblock 206 205 591 minecraft:gold_block
fill 207 205 566 207 205 568 minecraft:quartz_block
fill 207 205 587 207 205 589 minecraft:quartz_block
fill 212 205 598 217 205 598 minecraft:yellow_terracotta
fill 217 205 558 222 205 558 minecraft:yellow_terracotta
fill 224 205 561 224 205 563 minecraft:yellow_terracotta
fill 224 205 598 229 205 598 minecraft:yellow_terracotta
fill 225 205 560 227 205 560 minecraft:yellow_terracotta
setblock 225 205 564 minecraft:yellow_terracotta
setblock 227 205 564 minecraft:yellow_terracotta
fill 228 205 561 229 205 563 minecraft:yellow_terracotta
fill 229 205 558 229 205 560 minecraft:yellow_terracotta
fill 229 205 570 229 205 575 minecraft:yellow_terracotta
fill 229 205 582 229 205 587 minecraft:yellow_terracotta
fill 229 205 594 229 205 597 minecraft:yellow_terracotta
fill 188 206 563 188 211 566 minecraft:ochre_froglight
fill 188 206 575 188 211 578 minecraft:ochre_froglight
fill 188 206 587 188 211 590 minecraft:ochre_froglight
fill 188 206 599 191 211 599 minecraft:ochre_froglight
fill 195 206 557 198 211 557 minecraft:ochre_froglight
fill 200 206 599 203 211 599 minecraft:ochre_froglight
fill 205 206 567 205 206 570 minecraft:quartz_block
fill 205 206 585 205 206 588 minecraft:quartz_block
setblock 206 206 565 minecraft:gold_block
fill 206 206 570 206 208 571 minecraft:quartz_block
fill 206 206 584 206 208 585 minecraft:quartz_block
setblock 206 206 590 minecraft:gold_block
fill 207 206 557 210 211 557 minecraft:ochre_froglight
fill 207 206 567 207 206 570 minecraft:quartz_block
fill 207 206 585 207 206 588 minecraft:quartz_block
fill 212 206 599 215 211 599 minecraft:ochre_froglight
fill 213 206 559 214 213 559 minecraft:red_wool
fill 219 206 557 222 211 557 minecraft:ochre_froglight
fill 224 206 599 227 211 599 minecraft:ochre_froglight
fill 230 206 558 230 211 561 minecraft:ochre_froglight
fill 230 206 570 230 211 573 minecraft:ochre_froglight
fill 230 206 582 230 211 585 minecraft:ochre_froglight
fill 230 206 594 230 211 597 minecraft:ochre_froglight
fill 188 207 557 188 207 558 minecraft:gold_block
fill 188 207 559 188 207 562 minecraft:yellow_terracotta
fill 188 207 567 188 210 570 minecraft:yellow_terracotta
setblock 188 207 571 minecraft:gold_block
setblock 188 207 593 minecraft:gold_block
fill 188 207 594 188 207 598 minecraft:yellow_terracotta
setblock 204 207 599 minecraft:gold_block
fill 205 207 569 205 207 572 minecraft:quartz_block
fill 205 207 583 205 207 586 minecraft:quartz_block
fill 205 207 599 205 210 599 minecraft:yellow_terracotta
fill 206 207 567 206 207 568 minecraft:gold_block
fill 206 207 569 207 207 569 minecraft:quartz_block
fill 206 207 572 206 208 575 minecraft:quartz_block
fill 206 207 580 206 208 583 minecraft:quartz_block
setblock 206 207 588 minecraft:gold_block
fill 207 207 570 207 207 572 minecraft:quartz_block
fill 207 207 583 207 207 586 minecraft:quartz_block
setblock 208 207 599 minecraft:gold_block
fill 209 207 599 211 210 599 minecraft:yellow_terracotta
setblock 230 207 557 minecraft:gold_block
setblock 188 208 557 minecraft:gold_block
fill 188 208 558 188 210 558 minecraft:yellow_terracotta
setblock 188 208 559 minecraft:gold_block
fill 188 208 560 188 210 562 minecraft:yellow_terracotta
fill 188 208 571 188 211 571 minecraft:yellow_terracotta
setblock 188 208 573 minecraft:gold_block
fill 188 208 579 188 208 580 minecraft:gold_block
fill 188 208 581 188 210 583 minecraft:yellow_terracotta
fill 188 208 593 188 210 595 minecraft:yellow_terracotta
setblock 188 208 596 minecraft:gold_block
fill 188 208 597 188 210 598 minecraft:yellow_terracotta
fill 204 208 599 204 210 599 minecraft:yellow_terracotta
schedule function dropper:buildpart/136_2 1t
