setblock 12 48 361 minecraft:yellow_terracotta
fill 12 48 362 12 51 362 minecraft:honeycomb_block
setblock 13 48 325 minecraft:yellow_terracotta
fill 13 48 361 13 51 361 minecraft:honeycomb_block
setblock 14 48 324 minecraft:yellow_terracotta
fill 14 48 325 14 51 325 minecraft:honeycomb_block
setblock 15 48 323 minecraft:yellow_terracotta
fill 15 48 324 15 51 324 minecraft:honeycomb_block
setblock 15 48 363 minecraft:yellow_terracotta
fill 16 48 323 16 51 323 minecraft:honeycomb_block
setblock 16 48 362 minecraft:yellow_terracotta
fill 16 48 363 19 48 363 minecraft:honeycomb_block
setblock 17 48 361 minecraft:yellow_terracotta
fill 17 48 362 17 51 362 minecraft:honeycomb_block
setblock 19 48 325 minecraft:light[level=15]
setblock 19 48 333 minecraft:light[level=15]
setblock 19 48 341 minecraft:light[level=15]
setblock 19 48 349 minecraft:light[level=15]
setblock 19 48 357 minecraft:light[level=15]
setblock 20 48 323 minecraft:yellow_terracotta
setblock 20 48 363 minecraft:yellow_terracotta
fill 21 48 323 21 51 323 minecraft:honeycomb_block
setblock 21 48 362 minecraft:yellow_terracotta
fill 21 48 363 24 48 363 minecraft:honeycomb_block
fill 22 48 362 25 48 362 minecraft:honeycomb_block
fill 23 48 323 24 48 323 minecraft:honeycomb_block
setblock 25 48 323 minecraft:yellow_terracotta
setblock 25 48 363 minecraft:yellow_terracotta
fill 26 48 323 29 48 323 minecraft:honeycomb_block
setblock 26 48 361 minecraft:honeycomb_block
setblock 26 48 362 minecraft:yellow_terracotta
fill 26 48 363 29 48 363 minecraft:honeycomb_block
setblock 27 48 325 minecraft:light[level=15]
setblock 27 48 333 minecraft:light[level=15]
setblock 27 48 341 minecraft:light[level=15]
setblock 27 48 349 minecraft:light[level=15]
setblock 27 48 357 minecraft:light[level=15]
setblock 27 48 361 minecraft:yellow_terracotta
fill 27 48 362 27 51 362 minecraft:honeycomb_block
fill 28 48 361 28 51 361 minecraft:honeycomb_block
setblock 29 48 324 minecraft:yellow_terracotta
setblock 30 48 323 minecraft:yellow_terracotta
fill 30 48 324 33 48 324 minecraft:honeycomb_block
setblock 30 48 363 minecraft:yellow_terracotta
fill 31 48 323 31 51 323 minecraft:honeycomb_block
setblock 31 48 362 minecraft:yellow_terracotta
fill 31 48 363 31 51 363 minecraft:honeycomb_block
setblock 32 48 361 minecraft:yellow_terracotta
fill 32 48 362 32 51 362 minecraft:honeycomb_block
fill 33 48 361 33 49 361 minecraft:honeycomb_block
setblock 34 48 323 minecraft:honeycomb_block
setblock 35 48 323 minecraft:yellow_terracotta
setblock 35 48 325 minecraft:light[level=15]
setblock 35 48 333 minecraft:light[level=15]
setblock 35 48 341 minecraft:light[level=15]
setblock 35 48 349 minecraft:light[level=15]
setblock 35 48 357 minecraft:light[level=15]
setblock 35 48 363 minecraft:yellow_terracotta
fill 36 48 323 36 51 323 minecraft:honeycomb_block
setblock 36 48 362 minecraft:yellow_terracotta
fill 36 48 363 36 51 363 minecraft:honeycomb_block
fill 38 48 323 38 49 323 minecraft:honeycomb_block
fill 39 48 341 39 48 343 minecraft:honeycomb_block
setblock 40 48 338 minecraft:yellow_terracotta
fill 40 48 339 40 51 339 minecraft:honeycomb_block
setblock 40 48 343 minecraft:yellow_terracotta
fill 40 48 344 40 51 344 minecraft:honeycomb_block
fill 40 48 346 40 49 346 minecraft:honeycomb_block
setblock 41 48 323 minecraft:honey_block
fill 41 48 335 41 48 336 minecraft:honeycomb_block
setblock 41 48 337 minecraft:yellow_terracotta
fill 41 48 338 41 51 338 minecraft:honeycomb_block
setblock 41 48 342 minecraft:yellow_terracotta
fill 41 48 343 41 51 343 minecraft:honeycomb_block
setblock 41 48 347 minecraft:yellow_terracotta
fill 42 48 342 42 85 342 minecraft:honeycomb_block
setblock 0 49 323 minecraft:yellow_concrete
fill 1 49 323 3 49 323 minecraft:honeycomb_block
setblock 1 49 326 minecraft:yellow_terracotta
fill 1 49 327 1 52 327 minecraft:honeycomb_block
fill 1 49 329 1 49 330 minecraft:honeycomb_block
setblock 1 49 336 minecraft:yellow_terracotta
fill 1 49 337 1 52 337 minecraft:honeycomb_block
setblock 1 49 341 minecraft:yellow_terracotta
fill 1 49 342 1 52 342 minecraft:honeycomb_block
setblock 1 49 346 minecraft:yellow_terracotta
setblock 1 49 350 minecraft:honey_block
fill 1 49 362 1 51 363 minecraft:honeycomb_block
setblock 2 49 324 minecraft:honeycomb_block
setblock 2 49 325 minecraft:yellow_terracotta
fill 2 49 326 2 52 326 minecraft:honeycomb_block
fill 2 49 363 3 49 363 minecraft:honeycomb_block
setblock 3 49 324 minecraft:yellow_terracotta
setblock 4 49 323 minecraft:yellow_terracotta
fill 4 49 324 6 49 325 minecraft:honeycomb_block
setblock 4 49 362 minecraft:honeycomb_block
setblock 4 49 363 minecraft:yellow_terracotta
fill 5 49 323 8 49 323 minecraft:honeycomb_block
setblock 5 49 362 minecraft:yellow_terracotta
fill 5 49 363 8 49 363 minecraft:honeycomb_block
fill 6 49 362 9 49 362 minecraft:honeycomb_block
setblock 7 49 324 minecraft:honeycomb_block
setblock 7 49 325 minecraft:yellow_terracotta
fill 7 49 361 7 52 361 minecraft:honeycomb_block
setblock 8 49 324 minecraft:yellow_terracotta
fill 8 49 325 8 52 325 minecraft:honeycomb_block
setblock 9 49 323 minecraft:yellow_terracotta
fill 9 49 324 9 52 324 minecraft:honeycomb_block
fill 9 49 326 10 49 326 minecraft:honeycomb_block
setblock 9 49 363 minecraft:yellow_terracotta
fill 10 49 323 10 52 323 minecraft:honeycomb_block
setblock 10 49 362 minecraft:yellow_terracotta
fill 10 49 363 10 52 363 minecraft:honeycomb_block
setblock 11 49 325 minecraft:honeycomb_block
setblock 11 49 326 minecraft:yellow_terracotta
setblock 11 49 361 minecraft:yellow_terracotta
fill 11 49 362 11 52 362 minecraft:honeycomb_block
setblock 12 49 325 minecraft:yellow_terracotta
fill 12 49 361 12 52 361 minecraft:honeycomb_block
setblock 13 49 324 minecraft:yellow_terracotta
fill 13 49 325 13 52 325 minecraft:honeycomb_block
setblock 14 49 323 minecraft:yellow_terracotta
fill 14 49 324 14 52 324 minecraft:honeycomb_block
setblock 14 49 363 minecraft:yellow_terracotta
fill 15 49 323 15 52 323 minecraft:honeycomb_block
fill 15 49 325 15 50 325 minecraft:honeycomb_block
setblock 15 49 362 minecraft:yellow_terracotta
fill 15 49 363 18 49 363 minecraft:honeycomb_block
setblock 16 49 361 minecraft:yellow_terracotta
fill 16 49 362 16 52 362 minecraft:honeycomb_block
setblock 17 49 361 minecraft:honeycomb_block
setblock 18 49 324 minecraft:yellow_terracotta
setblock 19 49 323 minecraft:yellow_terracotta
fill 19 49 361 21 50 361 minecraft:yellow_concrete
setblock 19 49 363 minecraft:yellow_terracotta
fill 20 49 323 20 52 323 minecraft:honeycomb_block
fill 20 49 360 20 50 360 minecraft:yellow_concrete
setblock 20 49 362 minecraft:yellow_terracotta
fill 20 49 363 23 49 363 minecraft:honeycomb_block
fill 21 49 362 24 49 362 minecraft:honeycomb_block
setblock 23 49 323 minecraft:honeycomb_block
setblock 24 49 323 minecraft:yellow_terracotta
setblock 24 49 363 minecraft:yellow_terracotta
fill 25 49 323 28 49 323 minecraft:honeycomb_block
setblock 25 49 361 minecraft:honeycomb_block
setblock 25 49 362 minecraft:yellow_terracotta
fill 25 49 363 28 49 363 minecraft:honeycomb_block
fill 26 49 324 27 49 324 minecraft:honeycomb_block
setblock 26 49 361 minecraft:yellow_terracotta
fill 26 49 362 26 52 362 minecraft:honeycomb_block
fill 27 49 361 27 52 361 minecraft:honeycomb_block
setblock 28 49 324 minecraft:yellow_terracotta
setblock 29 49 323 minecraft:yellow_terracotta
fill 29 49 324 32 49 324 minecraft:honeycomb_block
setblock 29 49 363 minecraft:yellow_terracotta
fill 30 49 323 30 52 323 minecraft:honeycomb_block
setblock 30 49 362 minecraft:yellow_terracotta
fill 30 49 363 30 52 363 minecraft:honeycomb_block
setblock 31 49 361 minecraft:yellow_terracotta
fill 31 49 362 31 52 362 minecraft:honeycomb_block
fill 32 49 361 32 50 361 minecraft:honeycomb_block
setblock 33 49 324 minecraft:yellow_terracotta
setblock 34 49 323 minecraft:yellow_terracotta
fill 34 49 324 34 52 324 minecraft:honeycomb_block
setblock 34 49 363 minecraft:yellow_terracotta
fill 35 49 323 35 52 323 minecraft:honeycomb_block
setblock 35 49 362 minecraft:yellow_terracotta
fill 35 49 363 35 52 363 minecraft:honeycomb_block
setblock 39 49 322 minecraft:yellow_concrete
setblock 39 49 323 minecraft:yellow_terracotta
fill 39 49 341 39 49 342 minecraft:honeycomb_block
setblock 39 49 343 minecraft:yellow_terracotta
fill 39 49 344 39 51 344 minecraft:honeycomb_block
fill 40 49 323 41 51 323 minecraft:honeycomb_block
fill 40 49 338 40 50 338 minecraft:honeycomb_block
setblock 40 49 342 minecraft:yellow_terracotta
fill 40 49 343 40 52 343 minecraft:honeycomb_block
fill 41 49 324 41 49 325 minecraft:honeycomb_block
setblock 41 49 335 minecraft:honeycomb_block
setblock 41 49 336 minecraft:yellow_terracotta
fill 41 49 337 41 52 337 minecraft:honeycomb_block
setblock 41 49 341 minecraft:yellow_terracotta
fill 41 49 342 41 52 342 minecraft:honeycomb_block
setblock 41 49 345 minecraft:honeycomb_block
setblock 41 49 346 minecraft:yellow_terracotta
fill 41 49 347 41 51 348 minecraft:honeycomb_block
setblock 41 49 361 minecraft:honey_block
fill 0 50 323 2 50 323 minecraft:honeycomb_block
setblock 1 50 324 minecraft:honeycomb_block
setblock 1 50 325 minecraft:yellow_terracotta
fill 1 50 326 1 53 326 minecraft:honeycomb_block
setblock 1 50 329 minecraft:honeycomb_block
setblock 1 50 330 minecraft:yellow_terracotta
fill 1 50 331 1 52 332 minecraft:honeycomb_block
setblock 1 50 335 minecraft:yellow_terracotta
fill 1 50 336 1 51 336 minecraft:honeycomb_block
setblock 1 50 340 minecraft:yellow_terracotta
fill 1 50 341 2 50 341 minecraft:honeycomb_block
setblock 1 50 345 minecraft:yellow_terracotta
fill 1 50 346 1 53 346 minecraft:honeycomb_block
setblock 1 50 356 minecraft:honey_block
setblock 2 50 324 minecraft:yellow_terracotta
fill 2 50 325 5 50 325 minecraft:honeycomb_block
fill 2 50 327 2 50 328 minecraft:honeycomb_block
fill 2 50 342 2 50 343 minecraft:honeycomb_block
setblock 2 50 363 minecraft:honeycomb_block
setblock 3 50 323 minecraft:yellow_terracotta
fill 3 50 324 6 50 324 minecraft:honeycomb_block
setblock 3 50 332 minecraft:light[level=12]
setblock 3 50 339 minecraft:light[level=12]
setblock 3 50 346 minecraft:light[level=12]
setblock 3 50 353 minecraft:light[level=12]
setblock 3 50 360 minecraft:light[level=12]
setblock 3 50 363 minecraft:yellow_terracotta
fill 4 50 323 7 50 323 minecraft:honeycomb_block
setblock 4 50 362 minecraft:yellow_terracotta
fill 4 50 363 7 50 363 minecraft:honeycomb_block
fill 5 50 362 8 50 362 minecraft:honeycomb_block
setblock 6 50 325 minecraft:yellow_terracotta
setblock 6 50 364 minecraft:yellow_terracotta
setblock 7 50 324 minecraft:yellow_terracotta
fill 7 50 325 7 52 326 minecraft:honeycomb_block
fill 7 50 364 15 51 364 minecraft:honeycomb_block
setblock 8 50 323 minecraft:yellow_terracotta
fill 8 50 324 8 53 324 minecraft:honeycomb_block
fill 8 50 326 9 50 326 minecraft:honeycomb_block
setblock 8 50 363 minecraft:yellow_terracotta
fill 9 50 323 9 53 323 minecraft:honeycomb_block
setblock 9 50 362 minecraft:yellow_terracotta
fill 9 50 363 9 53 363 minecraft:honeycomb_block
setblock 10 50 326 minecraft:yellow_terracotta
setblock 10 50 332 minecraft:light[level=12]
setblock 10 50 339 minecraft:light[level=12]
setblock 10 50 346 minecraft:light[level=12]
setblock 10 50 353 minecraft:light[level=12]
setblock 10 50 360 minecraft:light[level=12]
setblock 10 50 361 minecraft:yellow_terracotta
fill 10 50 362 10 53 362 minecraft:honeycomb_block
setblock 11 50 325 minecraft:yellow_terracotta
fill 11 50 326 12 51 326 minecraft:honeycomb_block
fill 11 50 361 11 53 361 minecraft:honeycomb_block
setblock 12 50 324 minecraft:yellow_terracotta
fill 12 50 325 12 53 325 minecraft:honeycomb_block
setblock 13 50 323 minecraft:yellow_terracotta
fill 13 50 324 13 53 324 minecraft:honeycomb_block
setblock 13 50 363 minecraft:yellow_terracotta
fill 14 50 323 14 53 323 minecraft:honeycomb_block
setblock 14 50 362 minecraft:yellow_terracotta
fill 14 50 363 17 50 363 minecraft:honeycomb_block
setblock 15 50 361 minecraft:yellow_terracotta
fill 15 50 362 15 53 362 minecraft:honeycomb_block
setblock 16 50 361 minecraft:honeycomb_block
setblock 17 50 324 minecraft:yellow_terracotta
setblock 17 50 325 minecraft:light[level=12]
setblock 17 50 332 minecraft:light[level=12]
setblock 17 50 339 minecraft:light[level=12]
setblock 17 50 346 minecraft:light[level=12]
setblock 17 50 353 minecraft:light[level=12]
setblock 17 50 360 minecraft:light[level=12]
setblock 18 50 323 minecraft:yellow_terracotta
fill 18 50 324 18 52 324 minecraft:honeycomb_block
setblock 18 50 363 minecraft:yellow_terracotta
fill 19 50 323 19 53 323 minecraft:honeycomb_block
setblock 19 50 362 minecraft:yellow_terracotta
fill 19 50 363 22 50 363 minecraft:honeycomb_block
fill 20 50 362 23 50 362 minecraft:honeycomb_block
setblock 23 50 323 minecraft:yellow_terracotta
setblock 23 50 363 minecraft:yellow_terracotta
fill 24 50 323 27 50 323 minecraft:honeycomb_block
setblock 24 50 325 minecraft:light[level=12]
setblock 24 50 332 minecraft:light[level=12]
setblock 24 50 346 minecraft:light[level=12]
setblock 24 50 353 minecraft:light[level=12]
setblock 24 50 360 minecraft:light[level=12]
setblock 24 50 362 minecraft:yellow_terracotta
fill 24 50 363 27 50 363 minecraft:honeycomb_block
fill 25 50 324 26 50 324 minecraft:honeycomb_block
setblock 25 50 361 minecraft:yellow_terracotta
fill 25 50 362 25 53 362 minecraft:honeycomb_block
fill 26 50 361 26 52 361 minecraft:honeycomb_block
setblock 27 50 324 minecraft:yellow_terracotta
setblock 28 50 323 minecraft:yellow_terracotta
fill 28 50 324 31 50 324 minecraft:honeycomb_block
setblock 28 50 363 minecraft:yellow_terracotta
fill 29 50 323 29 53 323 minecraft:honeycomb_block
setblock 29 50 362 minecraft:yellow_terracotta
fill 29 50 363 29 53 363 minecraft:honeycomb_block
setblock 30 50 361 minecraft:yellow_terracotta
fill 30 50 362 30 53 362 minecraft:honeycomb_block
setblock 31 50 325 minecraft:light[level=12]
setblock 31 50 332 minecraft:light[level=12]
setblock 31 50 339 minecraft:light[level=12]
setblock 31 50 346 minecraft:light[level=12]
setblock 31 50 353 minecraft:light[level=12]
setblock 31 50 360 minecraft:light[level=12]
fill 31 50 361 31 51 361 minecraft:honeycomb_block
setblock 32 50 324 minecraft:yellow_terracotta
setblock 33 50 323 minecraft:yellow_terracotta
fill 33 50 324 33 53 324 minecraft:honeycomb_block
setblock 33 50 363 minecraft:yellow_terracotta
fill 34 50 323 34 53 323 minecraft:honeycomb_block
setblock 34 50 362 minecraft:yellow_terracotta
fill 34 50 363 34 53 363 minecraft:honeycomb_block
fill 35 50 324 35 51 324 minecraft:honeycomb_block
setblock 35 50 362 minecraft:honeycomb_block
setblock 38 50 323 minecraft:yellow_terracotta
setblock 38 50 325 minecraft:light[level=12]
setblock 38 50 332 minecraft:light[level=12]
setblock 38 50 339 minecraft:light[level=12]
setblock 38 50 346 minecraft:light[level=12]
setblock 38 50 353 minecraft:light[level=12]
setblock 38 50 360 minecraft:light[level=12]
setblock 38 50 363 minecraft:yellow_terracotta
fill 39 50 322 39 53 323 minecraft:honeycomb_block
setblock 39 50 342 minecraft:yellow_terracotta
fill 39 50 343 39 51 343 minecraft:honeycomb_block
setblock 40 50 341 minecraft:yellow_terracotta
fill 40 50 342 40 53 342 minecraft:honeycomb_block
setblock 40 50 346 minecraft:yellow_terracotta
fill 40 50 347 40 53 347 minecraft:honeycomb_block
setblock 41 50 324 minecraft:honeycomb_block
setblock 41 50 325 minecraft:yellow_terracotta
fill 41 50 326 41 51 328 minecraft:honeycomb_block
setblock 41 50 330 minecraft:honey_block
setblock 41 50 335 minecraft:yellow_terracotta
fill 41 50 336 41 53 336 minecraft:honeycomb_block
setblock 41 50 340 minecraft:yellow_terracotta
fill 41 50 341 41 53 341 minecraft:honeycomb_block
setblock 41 50 345 minecraft:yellow_terracotta
fill 41 50 346 41 53 346 minecraft:honeycomb_block
setblock 41 50 349 minecraft:honeycomb_block
setblock 41 50 355 minecraft:honey_block
fill 0 51 323 1 51 323 minecraft:honeycomb_block
setblock 1 51 324 minecraft:yellow_terracotta
fill 1 51 325 4 51 325 minecraft:honeycomb_block
setblock 1 51 329 minecraft:yellow_terracotta
fill 1 51 330 1 54 330 minecraft:honeycomb_block
setblock 1 51 333 minecraft:honeycomb_block
setblock 1 51 334 minecraft:yellow_terracotta
setblock 1 51 335 minecraft:honeycomb_block
setblock 1 51 339 minecraft:yellow_terracotta
fill 1 51 340 1 53 341 minecraft:honeycomb_block
setblock 1 51 344 minecraft:yellow_terracotta
fill 1 51 345 1 54 345 minecraft:honeycomb_block
fill 1 51 347 1 52 347 minecraft:honeycomb_block
setblock 2 51 323 minecraft:yellow_terracotta
fill 2 51 324 5 51 324 minecraft:honeycomb_block
setblock 2 51 327 minecraft:honeycomb_block
setblock 2 51 328 minecraft:yellow_terracotta
fill 2 51 329 2 54 329 minecraft:honeycomb_block
setblock 2 51 342 minecraft:honeycomb_block
setblock 2 51 343 minecraft:yellow_terracotta
setblock 2 51 344 minecraft:honeycomb_block
setblock 2 51 363 minecraft:yellow_terracotta
fill 3 51 323 6 51 323 minecraft:honeycomb_block
setblock 3 51 326 minecraft:honeycomb_block
setblock 3 51 327 minecraft:yellow_terracotta
fill 3 51 363 6 51 363 minecraft:honeycomb_block
fill 4 51 362 7 51 362 minecraft:honeycomb_block
setblock 5 51 325 minecraft:yellow_terracotta
fill 5 51 326 6 53 326 minecraft:honeycomb_block
setblock 6 51 324 minecraft:yellow_terracotta
fill 6 51 325 6 54 325 minecraft:honeycomb_block
fill 6 51 364 6 129 364 minecraft:honeycomb_block
setblock 7 51 323 minecraft:yellow_terracotta
fill 7 51 324 7 54 324 minecraft:honeycomb_block
setblock 7 51 363 minecraft:yellow_terracotta
fill 8 51 323 8 54 323 minecraft:honeycomb_block
setblock 8 51 326 minecraft:honeycomb_block
setblock 8 51 362 minecraft:yellow_terracotta
fill 8 51 363 8 54 363 minecraft:honeycomb_block
setblock 9 51 326 minecraft:yellow_terracotta
setblock 9 51 361 minecraft:yellow_terracotta
fill 9 51 362 9 54 362 minecraft:honeycomb_block
setblock 10 51 325 minecraft:yellow_terracotta
fill 10 51 326 10 54 326 minecraft:honeycomb_block
fill 10 51 361 10 53 361 minecraft:honeycomb_block
setblock 11 51 324 minecraft:yellow_terracotta
fill 11 51 325 11 54 325 minecraft:honeycomb_block
setblock 12 51 323 minecraft:yellow_terracotta
fill 12 51 324 12 54 324 minecraft:honeycomb_block
setblock 12 51 363 minecraft:yellow_terracotta
fill 13 51 323 13 54 323 minecraft:honeycomb_block
setblock 13 51 362 minecraft:yellow_terracotta
fill 13 51 363 16 51 363 minecraft:honeycomb_block
setblock 14 51 361 minecraft:yellow_terracotta
fill 14 51 362 14 54 362 minecraft:honeycomb_block
setblock 15 51 325 minecraft:yellow_terracotta
setblock 15 51 361 minecraft:honeycomb_block
setblock 16 51 324 minecraft:yellow_terracotta
setblock 17 51 323 minecraft:yellow_terracotta
fill 17 51 324 17 53 324 minecraft:honeycomb_block
setblock 17 51 363 minecraft:yellow_terracotta
fill 18 51 323 18 54 323 minecraft:honeycomb_block
setblock 18 51 362 minecraft:yellow_terracotta
fill 18 51 363 21 51 363 minecraft:honeycomb_block
fill 19 51 362 22 51 362 minecraft:honeycomb_block
setblock 22 51 323 minecraft:yellow_terracotta
setblock 22 51 363 minecraft:yellow_terracotta
fill 23 51 323 25 51 324 minecraft:honeycomb_block
setblock 23 51 362 minecraft:yellow_terracotta
fill 23 51 363 26 51 363 minecraft:honeycomb_block
fill 24 51 362 24 54 362 minecraft:honeycomb_block
setblock 25 51 361 minecraft:honeycomb_block
setblock 26 51 323 minecraft:honeycomb_block
setblock 26 51 324 minecraft:yellow_terracotta
setblock 27 51 323 minecraft:yellow_terracotta
fill 27 51 324 30 51 324 minecraft:honeycomb_block
setblock 27 51 363 minecraft:yellow_terracotta
fill 28 51 323 28 54 323 minecraft:honeycomb_block
setblock 28 51 362 minecraft:yellow_terracotta
fill 28 51 363 28 54 363 minecraft:honeycomb_block
setblock 29 51 361 minecraft:yellow_terracotta
fill 29 51 362 29 54 362 minecraft:honeycomb_block
setblock 30 51 325 minecraft:yellow_terracotta
setblock 30 51 361 minecraft:honeycomb_block
setblock 31 51 324 minecraft:yellow_terracotta
fill 32 51 322 32 91 322 minecraft:honeycomb_block
setblock 32 51 323 minecraft:yellow_terracotta
fill 32 51 324 32 54 324 minecraft:honeycomb_block
setblock 32 51 363 minecraft:yellow_terracotta
fill 33 51 323 33 54 323 minecraft:honeycomb_block
setblock 33 51 362 minecraft:yellow_terracotta
fill 33 51 363 33 53 363 minecraft:honeycomb_block
setblock 34 51 362 minecraft:honeycomb_block
setblock 37 51 323 minecraft:yellow_terracotta
setblock 37 51 363 minecraft:yellow_terracotta
fill 38 51 323 38 54 323 minecraft:honeycomb_block
setblock 40 51 340 minecraft:yellow_terracotta
fill 40 51 341 40 53 341 minecraft:honeycomb_block
setblock 40 51 345 minecraft:yellow_terracotta
fill 40 51 346 40 54 346 minecraft:honeycomb_block
setblock 41 51 324 minecraft:yellow_terracotta
fill 41 51 325 41 54 325 minecraft:honeycomb_block
setblock 41 51 329 minecraft:yellow_terracotta
fill 41 51 330 41 53 331 minecraft:honeycomb_block
setblock 41 51 334 minecraft:yellow_terracotta
fill 41 51 335 41 54 335 minecraft:honeycomb_block
setblock 41 51 339 minecraft:yellow_terracotta
fill 41 51 340 41 54 340 minecraft:honeycomb_block
setblock 41 51 344 minecraft:yellow_terracotta
fill 41 51 345 41 54 345 minecraft:honeycomb_block
setblock 41 51 349 minecraft:yellow_terracotta
setblock 42 51 340 minecraft:yellow_concrete
fill 42 51 341 42 86 341 minecraft:honeycomb_block
fill 42 51 352 42 74 353 minecraft:honeycomb_block
setblock 42 51 354 minecraft:orange_terracotta
fill 0 52 323 0 150 323 minecraft:honeycomb_block
setblock 1 52 323 minecraft:yellow_terracotta
fill 1 52 324 3 52 325 minecraft:honeycomb_block
setblock 1 52 328 minecraft:yellow_terracotta
fill 1 52 329 1 55 329 minecraft:honeycomb_block
setblock 1 52 333 minecraft:yellow_terracotta
setblock 1 52 334 minecraft:honeycomb_block
setblock 1 52 338 minecraft:yellow_terracotta
setblock 1 52 339 minecraft:honeycomb_block
setblock 1 52 343 minecraft:yellow_terracotta
fill 1 52 344 1 55 344 minecraft:honeycomb_block
setblock 1 52 348 minecraft:yellow_terracotta
setblock 1 52 362 minecraft:honeycomb_block
setblock 1 52 363 minecraft:yellow_terracotta
fill 2 52 323 5 52 323 minecraft:honeycomb_block
setblock 2 52 327 minecraft:yellow_terracotta
fill 2 52 328 3 54 328 minecraft:honeycomb_block
fill 2 52 330 2 53 330 minecraft:honeycomb_block
fill 2 52 363 5 52 363 minecraft:honeycomb_block
setblock 3 52 326 minecraft:yellow_terracotta
fill 3 52 327 3 55 327 minecraft:honeycomb_block
fill 3 52 362 6 52 362 minecraft:honeycomb_block
setblock 4 52 324 minecraft:honeycomb_block
setblock 4 52 325 minecraft:yellow_terracotta
fill 4 52 326 4 55 326 minecraft:honeycomb_block
setblock 5 52 324 minecraft:yellow_terracotta
fill 5 52 325 5 55 325 minecraft:honeycomb_block
setblock 6 52 323 minecraft:yellow_terracotta
fill 6 52 324 6 55 324 minecraft:honeycomb_block
setblock 6 52 363 minecraft:yellow_terracotta
fill 7 52 323 7 55 323 minecraft:honeycomb_block
setblock 7 52 362 minecraft:yellow_terracotta
fill 7 52 363 7 55 364 minecraft:honeycomb_block
setblock 8 52 326 minecraft:yellow_terracotta
setblock 8 52 361 minecraft:yellow_terracotta
fill 8 52 362 8 55 362 minecraft:honeycomb_block
fill 8 52 364 10 54 364 minecraft:honeycomb_block
setblock 9 52 325 minecraft:yellow_terracotta
fill 9 52 326 9 55 326 minecraft:honeycomb_block
fill 9 52 361 9 54 361 minecraft:honeycomb_block
setblock 10 52 324 minecraft:yellow_terracotta
fill 10 52 325 10 55 325 minecraft:honeycomb_block
setblock 10 52 327 minecraft:yellow_terracotta
setblock 11 52 323 minecraft:yellow_terracotta
fill 11 52 324 11 55 324 minecraft:honeycomb_block
fill 11 52 326 11 53 326 minecraft:honeycomb_block
fill 11 52 363 11 52 364 minecraft:yellow_terracotta
fill 12 52 323 12 55 323 minecraft:honeycomb_block
setblock 12 52 362 minecraft:yellow_terracotta
fill 12 52 363 15 52 364 minecraft:honeycomb_block
setblock 13 52 361 minecraft:yellow_terracotta
fill 13 52 362 13 54 362 minecraft:honeycomb_block
setblock 14 52 325 minecraft:yellow_terracotta
setblock 15 52 324 minecraft:yellow_terracotta
setblock 16 52 323 minecraft:yellow_terracotta
fill 16 52 324 16 53 324 minecraft:honeycomb_block
setblock 16 52 363 minecraft:yellow_terracotta
fill 17 52 323 17 55 323 minecraft:honeycomb_block
setblock 17 52 362 minecraft:yellow_terracotta
fill 17 52 363 20 52 363 minecraft:honeycomb_block
fill 18 52 362 21 52 362 minecraft:honeycomb_block
setblock 21 52 323 minecraft:yellow_terracotta
setblock 21 52 363 minecraft:yellow_terracotta
fill 22 52 323 25 52 323 minecraft:honeycomb_block
setblock 22 52 362 minecraft:yellow_terracotta
fill 22 52 363 25 52 363 minecraft:honeycomb_block
fill 23 52 324 24 52 324 minecraft:honeycomb_block
fill 23 52 362 23 54 362 minecraft:honeycomb_block
setblock 25 52 324 minecraft:yellow_terracotta
setblock 26 52 323 minecraft:yellow_terracotta
fill 26 52 324 29 52 324 minecraft:honeycomb_block
setblock 26 52 363 minecraft:yellow_terracotta
fill 27 52 323 27 55 323 minecraft:honeycomb_block
setblock 27 52 362 minecraft:yellow_terracotta
fill 27 52 363 27 55 363 minecraft:honeycomb_block
setblock 28 52 325 minecraft:honeycomb_block
setblock 28 52 361 minecraft:yellow_terracotta
fill 28 52 362 28 54 362 minecraft:honeycomb_block
setblock 29 52 325 minecraft:yellow_terracotta
fill 29 52 358 29 63 358 minecraft:iron_block
setblock 29 52 361 minecraft:honeycomb_block
setblock 30 52 324 minecraft:yellow_terracotta
setblock 30 52 325 minecraft:honeycomb_block
setblock 31 52 323 minecraft:yellow_terracotta
fill 31 52 324 31 55 324 minecraft:honeycomb_block
setblock 31 52 363 minecraft:yellow_terracotta
fill 32 52 323 32 55 323 minecraft:honeycomb_block
fill 32 52 355 33 53 356 minecraft:honey_block
setblock 32 52 362 minecraft:yellow_terracotta
fill 32 52 363 32 54 363 minecraft:honeycomb_block
setblock 33 52 362 minecraft:honeycomb_block
setblock 35 52 324 minecraft:yellow_terracotta
setblock 36 52 323 minecraft:yellow_terracotta
fill 37 52 323 37 54 323 minecraft:honeycomb_block
setblock 40 52 323 minecraft:honeycomb_block
setblock 40 52 340 minecraft:honeycomb_block
setblock 40 52 344 minecraft:yellow_terracotta
fill 40 52 345 40 55 345 minecraft:honeycomb_block
setblock 40 52 348 minecraft:honeycomb_block
setblock 41 52 323 minecraft:yellow_terracotta
fill 41 52 324 41 55 324 minecraft:honeycomb_block
fill 41 52 326 41 52 327 minecraft:honeycomb_block
setblock 41 52 328 minecraft:yellow_terracotta
fill 41 52 329 41 55 329 minecraft:honeycomb_block
setblock 41 52 332 minecraft:honeycomb_block
setblock 41 52 333 minecraft:yellow_terracotta
fill 41 52 334 41 55 334 minecraft:honeycomb_block
setblock 41 52 338 minecraft:yellow_terracotta
fill 41 52 339 41 55 339 minecraft:honeycomb_block
setblock 41 52 343 minecraft:yellow_terracotta
fill 41 52 344 41 55 344 minecraft:honeycomb_block
setblock 41 52 347 minecraft:honeycomb_block
setblock 41 52 348 minecraft:yellow_terracotta
fill 41 52 349 41 54 350 minecraft:honeycomb_block
setblock 41 52 362 minecraft:honey_block
fill 42 52 340 42 91 340 minecraft:honeycomb_block
fill 42 52 354 42 279 354 minecraft:honeycomb_block
fill 1 53 323 2 53 325 minecraft:honeycomb_block
setblock 1 53 327 minecraft:yellow_terracotta
fill 1 53 328 1 56 328 minecraft:honeycomb_block
setblock 1 53 331 minecraft:honeycomb_block
setblock 1 53 332 minecraft:yellow_terracotta
fill 1 53 333 1 56 333 minecraft:honeycomb_block
setblock 1 53 342 minecraft:yellow_terracotta
fill 1 53 343 1 54 343 minecraft:honeycomb_block
setblock 1 53 347 minecraft:yellow_terracotta
fill 1 53 348 1 56 348 minecraft:honeycomb_block
setblock 1 53 349 minecraft:honey_block
setblock 1 53 362 minecraft:yellow_terracotta
fill 1 53 363 4 53 363 minecraft:honeycomb_block
setblock 2 53 326 minecraft:yellow_terracotta
fill 2 53 327 2 56 327 minecraft:honeycomb_block
setblock 2 53 331 minecraft:yellow_terracotta
fill 3 53 323 3 53 324 minecraft:honeycomb_block
setblock 3 53 325 minecraft:yellow_terracotta
fill 3 53 326 3 56 326 minecraft:honeycomb_block
setblock 3 53 329 minecraft:honeycomb_block
setblock 4 53 323 minecraft:honeycomb_block
setblock 4 53 324 minecraft:yellow_terracotta
fill 4 53 325 4 56 325 minecraft:honeycomb_block
fill 4 53 327 4 54 327 minecraft:honeycomb_block
fill 4 53 362 5 53 362 minecraft:honeycomb_block
setblock 5 53 323 minecraft:yellow_terracotta
fill 5 53 324 5 56 324 minecraft:honeycomb_block
setblock 5 53 363 minecraft:yellow_terracotta
fill 6 53 323 6 56 323 minecraft:honeycomb_block
setblock 6 53 362 minecraft:yellow_terracotta
fill 6 53 363 6 56 363 minecraft:honeycomb_block
setblock 7 53 325 minecraft:honeycomb_block
setblock 7 53 326 minecraft:yellow_terracotta
setblock 7 53 361 minecraft:yellow_terracotta
fill 7 53 362 7 56 362 minecraft:honeycomb_block
setblock 8 53 325 minecraft:yellow_terracotta
fill 8 53 326 8 56 326 minecraft:honeycomb_block
setblock 8 53 361 minecraft:honeycomb_block
setblock 9 53 324 minecraft:yellow_terracotta
fill 9 53 325 9 56 325 minecraft:honeycomb_block
setblock 10 53 323 minecraft:yellow_terracotta
fill 10 53 324 10 56 324 minecraft:honeycomb_block
setblock 10 53 363 minecraft:yellow_terracotta
fill 11 53 323 11 56 323 minecraft:honeycomb_block
setblock 11 53 362 minecraft:yellow_terracotta
fill 11 53 363 14 53 364 minecraft:honeycomb_block
setblock 12 53 361 minecraft:yellow_terracotta
fill 12 53 362 12 55 362 minecraft:honeycomb_block
setblock 13 53 325 minecraft:yellow_terracotta
setblock 14 53 324 minecraft:yellow_terracotta
setblock 14 53 325 minecraft:honeycomb_block
setblock 15 53 323 minecraft:yellow_terracotta
fill 15 53 324 15 54 324 minecraft:honeycomb_block
setblock 15 53 363 minecraft:yellow_terracotta
fill 15 53 364 15 204 364 minecraft:honeycomb_block
fill 16 53 323 16 55 323 minecraft:honeycomb_block
setblock 16 53 362 minecraft:yellow_terracotta
fill 16 53 363 19 53 363 minecraft:honeycomb_block
setblock 17 53 362 minecraft:honeycomb_block
setblock 20 53 323 minecraft:yellow_terracotta
setblock 20 53 363 minecraft:yellow_terracotta
fill 21 53 323 24 53 323 minecraft:honeycomb_block
setblock 21 53 362 minecraft:yellow_terracotta
fill 21 53 363 24 53 363 minecraft:honeycomb_block
setblock 22 53 362 minecraft:honeycomb_block
setblock 23 53 324 minecraft:honeycomb_block
setblock 24 53 324 minecraft:yellow_terracotta
setblock 25 53 323 minecraft:yellow_terracotta
fill 25 53 324 28 53 324 minecraft:honeycomb_block
setblock 25 53 363 minecraft:yellow_terracotta
fill 26 53 323 26 56 323 minecraft:honeycomb_block
setblock 26 53 362 minecraft:yellow_terracotta
fill 26 53 363 26 56 363 minecraft:honeycomb_block
fill 27 53 362 27 54 362 minecraft:honeycomb_block
fill 27 53 364 28 79 364 minecraft:honeycomb_block
setblock 28 53 325 minecraft:yellow_terracotta
setblock 29 53 324 minecraft:yellow_terracotta
setblock 29 53 325 minecraft:honeycomb_block
setblock 29 53 364 minecraft:yellow_terracotta
setblock 30 53 323 minecraft:yellow_terracotta
fill 30 53 324 30 55 324 minecraft:honeycomb_block
setblock 30 53 363 minecraft:yellow_terracotta
fill 30 53 364 31 66 364 minecraft:honeycomb_block
fill 31 53 323 31 56 323 minecraft:honeycomb_block
setblock 31 53 362 minecraft:yellow_terracotta
fill 31 53 363 31 55 363 minecraft:honeycomb_block
setblock 34 53 324 minecraft:yellow_terracotta
setblock 35 53 323 minecraft:yellow_terracotta
fill 35 53 351 35 54 352 minecraft:yellow_concrete
fill 36 53 323 36 54 323 minecraft:honeycomb_block
setblock 40 53 323 minecraft:yellow_terracotta
fill 40 53 325 40 53 327 minecraft:honeycomb_block
setblock 40 53 343 minecraft:yellow_terracotta
fill 40 53 344 40 54 344 minecraft:honeycomb_block
setblock 40 53 348 minecraft:yellow_terracotta
fill 41 53 323 41 56 323 minecraft:honeycomb_block
setblock 41 53 326 minecraft:honeycomb_block
setblock 41 53 327 minecraft:yellow_terracotta
fill 41 53 328 41 56 328 minecraft:honeycomb_block
setblock 41 53 332 minecraft:yellow_terracotta
fill 41 53 333 41 56 333 minecraft:honeycomb_block
setblock 41 53 337 minecraft:yellow_terracotta
fill 41 53 338 41 55 338 minecraft:honeycomb_block
setblock 41 53 342 minecraft:yellow_terracotta
fill 41 53 343 41 56 343 minecraft:honeycomb_block
setblock 41 53 347 minecraft:yellow_terracotta
fill 41 53 348 41 56 348 minecraft:honeycomb_block
setblock 41 53 356 minecraft:honey_block
setblock 42 53 350 minecraft:yellow_concrete
setblock 0 54 332 minecraft:yellow_terracotta
fill 0 54 333 0 79 334 minecraft:honeycomb_block
fill 1 54 323 1 54 325 minecraft:honeycomb_block
setblock 1 54 326 minecraft:yellow_terracotta
fill 1 54 327 1 57 327 minecraft:honeycomb_block
setblock 1 54 331 minecraft:yellow_terracotta
fill 1 54 332 1 57 332 minecraft:honeycomb_block
setblock 1 54 336 minecraft:honey_block
setblock 1 54 342 minecraft:honeycomb_block
setblock 1 54 346 minecraft:yellow_terracotta
fill 1 54 347 1 57 347 minecraft:honeycomb_block
fill 1 54 349 1 55 349 minecraft:honeycomb_block
setblock 1 54 355 minecraft:honey_block
fill 1 54 363 3 54 363 minecraft:honeycomb_block
fill 2 54 323 2 54 324 minecraft:honeycomb_block
setblock 2 54 325 minecraft:yellow_terracotta
fill 2 54 326 2 57 326 minecraft:honeycomb_block
setblock 2 54 330 minecraft:yellow_terracotta
fill 2 54 331 2 57 331 minecraft:honeycomb_block
setblock 3 54 323 minecraft:honeycomb_block
setblock 3 54 324 minecraft:yellow_terracotta
fill 3 54 325 3 57 325 minecraft:honeycomb_block
setblock 3 54 329 minecraft:yellow_terracotta
setblock 4 54 323 minecraft:yellow_terracotta
fill 4 54 324 4 57 324 minecraft:honeycomb_block
setblock 4 54 362 minecraft:honeycomb_block
setblock 4 54 363 minecraft:yellow_terracotta
fill 5 54 323 5 57 323 minecraft:honeycomb_block
setblock 5 54 326 minecraft:honeycomb_block
setblock 5 54 362 minecraft:yellow_terracotta
fill 5 54 363 5 57 363 minecraft:honeycomb_block
setblock 6 54 326 minecraft:yellow_terracotta
fill 6 54 362 6 57 362 minecraft:honeycomb_block
setblock 7 54 325 minecraft:yellow_terracotta
fill 7 54 326 7 56 326 minecraft:honeycomb_block
fill 7 54 341 7 55 341 minecraft:black_concrete
setblock 8 54 324 minecraft:yellow_terracotta
fill 8 54 325 8 57 325 minecraft:honeycomb_block
setblock 9 54 323 minecraft:yellow_terracotta
fill 9 54 324 9 57 324 minecraft:honeycomb_block
setblock 9 54 363 minecraft:yellow_terracotta
fill 10 54 323 10 57 323 minecraft:honeycomb_block
setblock 10 54 362 minecraft:yellow_terracotta
fill 10 54 363 13 54 363 minecraft:honeycomb_block
fill 11 54 362 11 55 362 minecraft:honeycomb_block
fill 11 54 364 14 56 364 minecraft:honeycomb_block
setblock 12 54 325 minecraft:yellow_terracotta
setblock 13 54 324 minecraft:yellow_terracotta
setblock 13 54 325 minecraft:honeycomb_block
setblock 14 54 323 minecraft:yellow_terracotta
fill 14 54 324 14 55 324 minecraft:honeycomb_block
setblock 14 54 363 minecraft:yellow_terracotta
fill 15 54 323 15 56 323 minecraft:honeycomb_block
fill 15 54 363 18 54 363 minecraft:honeycomb_block
setblock 19 54 323 minecraft:yellow_terracotta
setblock 19 54 363 minecraft:yellow_terracotta
fill 20 54 323 23 54 323 minecraft:honeycomb_block
fill 20 54 363 23 54 363 minecraft:honeycomb_block
setblock 23 54 324 minecraft:yellow_terracotta
setblock 24 54 323 minecraft:yellow_terracotta
fill 24 54 324 27 54 324 minecraft:honeycomb_block
setblock 24 54 363 minecraft:yellow_terracotta
fill 25 54 323 25 57 323 minecraft:honeycomb_block
setblock 25 54 362 minecraft:yellow_terracotta
fill 25 54 363 25 57 363 minecraft:honeycomb_block
fill 26 54 362 26 55 362 minecraft:honeycomb_block
setblock 28 54 324 minecraft:yellow_terracotta
setblock 29 54 323 minecraft:yellow_terracotta
fill 29 54 324 29 56 324 minecraft:honeycomb_block
setblock 29 54 363 minecraft:yellow_terracotta
fill 29 54 364 29 146 364 minecraft:honeycomb_block
fill 30 54 323 30 57 323 minecraft:honeycomb_block
fill 30 54 363 30 55 363 minecraft:honeycomb_block
setblock 34 54 323 minecraft:yellow_terracotta
setblock 35 54 323 minecraft:honeycomb_block
setblock 37 54 363 minecraft:honey_block
fill 39 54 322 39 164 322 minecraft:honeycomb_block
setblock 39 54 323 minecraft:yellow_terracotta
fill 40 54 323 40 57 323 minecraft:honeycomb_block
fill 40 54 325 40 54 326 minecraft:honeycomb_block
setblock 40 54 327 minecraft:yellow_terracotta
fill 40 54 328 40 57 328 minecraft:honeycomb_block
setblock 40 54 343 minecraft:honeycomb_block
setblock 40 54 347 minecraft:yellow_terracotta
setblock 41 54 326 minecraft:yellow_terracotta
fill 41 54 327 41 57 327 minecraft:honeycomb_block
setblock 41 54 330 minecraft:honeycomb_block
setblock 41 54 331 minecraft:yellow_terracotta
fill 41 54 332 41 57 332 minecraft:honeycomb_block
setblock 41 54 336 minecraft:yellow_terracotta
setblock 41 54 337 minecraft:honeycomb_block
setblock 41 54 341 minecraft:yellow_terracotta
fill 41 54 342 41 57 342 minecraft:honeycomb_block
setblock 41 54 346 minecraft:yellow_terracotta
fill 41 54 347 41 57 347 minecraft:honeycomb_block
fill 42 54 350 42 58 350 minecraft:honeycomb_block
fill 0 55 332 0 58 332 minecraft:honeycomb_block
fill 1 55 323 1 55 324 minecraft:honeycomb_block
setblock 1 55 325 minecraft:yellow_terracotta
fill 1 55 326 1 58 326 minecraft:honeycomb_block
setblock 1 55 330 minecraft:yellow_terracotta
fill 1 55 331 1 58 331 minecraft:honeycomb_block
setblock 1 55 342 minecraft:honey_block
setblock 1 55 345 minecraft:yellow_terracotta
fill 1 55 346 1 56 346 minecraft:honeycomb_block
setblock 1 55 361 minecraft:honey_block
fill 1 55 363 2 55 363 minecraft:honeycomb_block
setblock 2 55 323 minecraft:honeycomb_block
setblock 2 55 324 minecraft:yellow_terracotta
fill 2 55 325 2 58 325 minecraft:honeycomb_block
setblock 2 55 328 minecraft:honeycomb_block
setblock 2 55 329 minecraft:yellow_terracotta
fill 2 55 330 2 58 330 minecraft:honeycomb_block
setblock 3 55 323 minecraft:yellow_terracotta
fill 3 55 324 3 58 324 minecraft:honeycomb_block
setblock 3 55 328 minecraft:yellow_terracotta
fill 3 55 329 3 58 329 minecraft:honeycomb_block
setblock 3 55 363 minecraft:yellow_terracotta
fill 4 55 323 4 58 323 minecraft:honeycomb_block
setblock 4 55 327 minecraft:yellow_terracotta
setblock 4 55 362 minecraft:yellow_terracotta
fill 4 55 363 4 58 363 minecraft:honeycomb_block
setblock 5 55 326 minecraft:yellow_terracotta
fill 5 55 362 5 57 362 minecraft:honeycomb_block
setblock 6 55 325 minecraft:yellow_terracotta
fill 6 55 326 6 57 326 minecraft:honeycomb_block
setblock 7 55 324 minecraft:yellow_terracotta
fill 7 55 325 7 58 325 minecraft:honeycomb_block
setblock 8 55 323 minecraft:yellow_terracotta
fill 8 55 324 8 58 324 minecraft:honeycomb_block
setblock 8 55 363 minecraft:yellow_terracotta
setblock 8 55 364 minecraft:orange_terracotta
fill 9 55 323 9 58 323 minecraft:honeycomb_block
setblock 9 55 362 minecraft:yellow_terracotta
fill 9 55 363 10 57 364 minecraft:honeycomb_block
fill 10 55 362 10 56 362 minecraft:honeycomb_block
setblock 11 55 325 minecraft:yellow_terracotta
fill 11 55 363 12 55 363 minecraft:honeycomb_block
setblock 12 55 324 minecraft:yellow_terracotta
setblock 12 55 325 minecraft:honeycomb_block
setblock 13 55 323 minecraft:yellow_terracotta
setblock 13 55 324 minecraft:honeycomb_block
setblock 13 55 363 minecraft:yellow_terracotta
fill 14 55 322 14 56 323 minecraft:honeycomb_block
fill 14 55 363 17 55 363 minecraft:honeycomb_block
fill 15 55 322 22 60 322 minecraft:honeycomb_block
setblock 18 55 323 minecraft:yellow_terracotta
setblock 18 55 363 minecraft:yellow_terracotta
fill 19 55 323 22 55 323 minecraft:honeycomb_block
fill 19 55 363 22 55 363 minecraft:honeycomb_block
setblock 23 55 322 minecraft:orange_terracotta
setblock 23 55 323 minecraft:yellow_terracotta
setblock 23 55 363 minecraft:yellow_terracotta
fill 24 55 323 24 55 324 minecraft:honeycomb_block
fill 24 55 359 25 56 359 minecraft:yellow_concrete
fill 24 55 363 24 58 363 minecraft:honeycomb_block
fill 25 55 324 26 55 324 minecraft:honeycomb_block
setblock 27 55 324 minecraft:yellow_terracotta
setblock 28 55 323 minecraft:yellow_terracotta
fill 28 55 324 28 56 324 minecraft:honeycomb_block
setblock 28 55 363 minecraft:yellow_terracotta
fill 29 55 323 29 57 323 minecraft:honeycomb_block
fill 29 55 363 29 56 363 minecraft:honeycomb_block
setblock 33 55 323 minecraft:yellow_terracotta
setblock 34 55 323 minecraft:honeycomb_block
fill 36 55 364 39 105 364 minecraft:honeycomb_block
fill 37 55 323 37 56 323 minecraft:honey_block
setblock 39 55 323 minecraft:honeycomb_block
setblock 40 55 325 minecraft:honeycomb_block
setblock 40 55 326 minecraft:yellow_terracotta
fill 40 55 327 40 58 327 minecraft:honeycomb_block
fill 40 55 329 40 56 329 minecraft:honeycomb_block
setblock 40 55 346 minecraft:yellow_terracotta
setblock 40 55 364 minecraft:yellow_concrete
setblock 41 55 325 minecraft:yellow_terracotta
fill 41 55 326 41 58 326 minecraft:honeycomb_block
setblock 41 55 330 minecraft:yellow_terracotta
fill 41 55 331 41 58 331 minecraft:honeycomb_block
setblock 41 55 335 minecraft:yellow_terracotta
setblock 41 55 336 minecraft:honeycomb_block
setblock 41 55 340 minecraft:yellow_terracotta
fill 41 55 341 41 56 341 minecraft:honeycomb_block
setblock 41 55 345 minecraft:yellow_terracotta
fill 41 55 346 41 58 346 minecraft:honeycomb_block
setblock 41 55 349 minecraft:honeycomb_block
setblock 41 55 350 minecraft:yellow_terracotta
fill 41 55 364 42 110 364 minecraft:honeycomb_block
setblock 0 56 344 minecraft:yellow_concrete
fill 0 56 345 0 279 346 minecraft:honeycomb_block
setblock 0 56 347 minecraft:yellow_concrete
setblock 1 56 323 minecraft:honeycomb_block
setblock 1 56 324 minecraft:yellow_terracotta
fill 1 56 325 1 59 325 minecraft:honeycomb_block
setblock 1 56 329 minecraft:yellow_terracotta
fill 1 56 330 1 59 330 minecraft:honeycomb_block
setblock 1 56 349 minecraft:yellow_terracotta
setblock 2 56 323 minecraft:yellow_terracotta
fill 2 56 324 2 59 324 minecraft:honeycomb_block
setblock 2 56 328 minecraft:yellow_terracotta
fill 2 56 329 2 59 329 minecraft:honeycomb_block
setblock 2 56 332 minecraft:honeycomb_block
setblock 2 56 363 minecraft:yellow_terracotta
fill 3 56 323 3 59 323 minecraft:honeycomb_block
setblock 3 56 327 minecraft:yellow_terracotta
fill 3 56 328 3 59 328 minecraft:honeycomb_block
fill 3 56 330 3 57 330 minecraft:honeycomb_block
setblock 3 56 332 minecraft:light[level=12]
setblock 3 56 333 minecraft:light[level=15]
setblock 3 56 339 minecraft:light[level=12]
setblock 3 56 341 minecraft:light[level=15]
setblock 3 56 346 minecraft:light[level=12]
setblock 3 56 349 minecraft:light[level=15]
setblock 3 56 353 minecraft:light[level=12]
setblock 3 56 357 minecraft:light[level=15]
setblock 3 56 360 minecraft:light[level=12]
fill 3 56 363 3 59 363 minecraft:honeycomb_block
setblock 4 56 326 minecraft:yellow_terracotta
fill 4 56 327 4 57 327 minecraft:honeycomb_block
setblock 5 56 325 minecraft:yellow_terracotta
fill 5 56 326 5 57 326 minecraft:honeycomb_block
setblock 6 56 324 minecraft:yellow_terracotta
fill 6 56 325 6 59 325 minecraft:honeycomb_block
setblock 7 56 323 minecraft:yellow_terracotta
fill 7 56 324 7 59 324 minecraft:honeycomb_block
setblock 7 56 363 minecraft:yellow_terracotta
fill 7 56 364 8 77 364 minecraft:honeycomb_block
fill 8 56 323 8 59 323 minecraft:honeycomb_block
setblock 8 56 362 minecraft:yellow_terracotta
fill 8 56 363 8 59 363 minecraft:honeycomb_block
setblock 9 56 362 minecraft:honeycomb_block
setblock 10 56 325 minecraft:yellow_terracotta
setblock 10 56 332 minecraft:light[level=12]
setblock 10 56 339 minecraft:light[level=12]
setblock 10 56 346 minecraft:light[level=12]
setblock 10 56 353 minecraft:light[level=12]
setblock 10 56 360 minecraft:light[level=12]
setblock 11 56 324 minecraft:yellow_terracotta
setblock 11 56 325 minecraft:light[level=15]
setblock 11 56 333 minecraft:light[level=15]
setblock 11 56 341 minecraft:light[level=15]
setblock 11 56 349 minecraft:light[level=15]
setblock 11 56 357 minecraft:light[level=15]
setblock 11 56 363 minecraft:honeycomb_block
setblock 12 56 323 minecraft:yellow_terracotta
setblock 12 56 324 minecraft:honeycomb_block
setblock 12 56 363 minecraft:yellow_terracotta
fill 13 56 323 13 57 323 minecraft:honeycomb_block
fill 13 56 363 15 56 363 minecraft:honeycomb_block
setblock 17 56 325 minecraft:light[level=12]
setblock 17 56 332 minecraft:light[level=12]
setblock 17 56 339 minecraft:light[level=12]
setblock 17 56 346 minecraft:light[level=12]
setblock 17 56 353 minecraft:light[level=12]
setblock 17 56 360 minecraft:light[level=12]
setblock 19 56 325 minecraft:light[level=15]
setblock 19 56 333 minecraft:light[level=15]
setblock 19 56 341 minecraft:light[level=15]
setblock 19 56 349 minecraft:light[level=15]
setblock 19 56 357 minecraft:light[level=15]
setblock 21 56 363 minecraft:honeycomb_block
setblock 22 56 323 minecraft:yellow_terracotta
setblock 22 56 363 minecraft:yellow_terracotta
fill 23 56 322 23 58 323 minecraft:honeycomb_block
fill 23 56 363 23 57 363 minecraft:honeycomb_block
fill 24 56 323 24 58 323 minecraft:honeycomb_block
setblock 24 56 325 minecraft:light[level=12]
setblock 24 56 332 minecraft:light[level=12]
setblock 24 56 346 minecraft:light[level=12]
setblock 24 56 353 minecraft:light[level=12]
setblock 24 56 360 minecraft:light[level=12]
setblock 25 56 324 minecraft:honeycomb_block
setblock 26 56 324 minecraft:yellow_terracotta
setblock 27 56 323 minecraft:yellow_terracotta
setblock 27 56 324 minecraft:honeycomb_block
setblock 27 56 325 minecraft:light[level=15]
setblock 27 56 333 minecraft:light[level=15]
setblock 27 56 341 minecraft:light[level=15]
setblock 27 56 349 minecraft:light[level=15]
setblock 27 56 357 minecraft:light[level=15]
setblock 27 56 363 minecraft:yellow_terracotta
fill 28 56 323 28 58 323 minecraft:honeycomb_block
setblock 28 56 363 minecraft:honeycomb_block
setblock 30 56 363 minecraft:honey_block
setblock 31 56 325 minecraft:light[level=12]
setblock 31 56 332 minecraft:light[level=12]
setblock 31 56 339 minecraft:light[level=12]
setblock 31 56 346 minecraft:light[level=12]
setblock 31 56 353 minecraft:light[level=12]
setblock 31 56 360 minecraft:light[level=12]
fill 33 56 322 33 145 322 minecraft:honeycomb_block
setblock 34 56 322 minecraft:yellow_concrete
setblock 35 56 325 minecraft:light[level=15]
setblock 35 56 333 minecraft:light[level=15]
setblock 35 56 341 minecraft:light[level=15]
setblock 35 56 349 minecraft:light[level=15]
setblock 35 56 357 minecraft:light[level=15]
setblock 38 56 325 minecraft:light[level=12]
setblock 38 56 332 minecraft:light[level=12]
setblock 38 56 339 minecraft:light[level=12]
setblock 38 56 346 minecraft:light[level=12]
setblock 38 56 353 minecraft:light[level=12]
setblock 38 56 360 minecraft:light[level=12]
fill 40 56 322 40 140 322 minecraft:honeycomb_block
setblock 40 56 325 minecraft:yellow_terracotta
fill 40 56 326 40 59 326 minecraft:honeycomb_block
setblock 40 56 330 minecraft:yellow_terracotta
fill 40 56 364 40 114 364 minecraft:honeycomb_block
setblock 41 56 322 minecraft:yellow_concrete
setblock 41 56 324 minecraft:yellow_terracotta
fill 41 56 325 41 59 325 minecraft:honeycomb_block
setblock 41 56 329 minecraft:yellow_terracotta
fill 41 56 330 41 59 330 minecraft:honeycomb_block
setblock 41 56 334 minecraft:yellow_terracotta
fill 41 56 335 41 59 335 minecraft:honeycomb_block
setblock 41 56 338 minecraft:honey_block
setblock 41 56 340 minecraft:honeycomb_block
setblock 41 56 344 minecraft:yellow_terracotta
fill 41 56 345 41 59 345 minecraft:honeycomb_block
setblock 41 56 349 minecraft:yellow_terracotta
fill 41 56 350 41 58 351 minecraft:honeycomb_block
fill 41 56 357 41 57 357 minecraft:honey_block
fill 42 56 322 42 308 322 minecraft:honeycomb_block
fill 0 57 344 0 111 344 minecraft:honeycomb_block
fill 0 57 347 0 163 347 minecraft:honeycomb_block
setblock 1 57 323 minecraft:yellow_terracotta
fill 1 57 324 1 60 324 minecraft:honeycomb_block
setblock 1 57 328 minecraft:yellow_terracotta
fill 1 57 329 1 60 329 minecraft:honeycomb_block
setblock 1 57 333 minecraft:yellow_terracotta
fill 1 57 334 1 60 334 minecraft:honeycomb_block
setblock 1 57 348 minecraft:yellow_terracotta
fill 1 57 349 1 59 350 minecraft:honeycomb_block
setblock 1 57 354 minecraft:honey_block
fill 2 57 323 2 60 323 minecraft:honeycomb_block
setblock 2 57 327 minecraft:yellow_terracotta
fill 2 57 328 2 60 328 minecraft:honeycomb_block
setblock 2 57 332 minecraft:yellow_terracotta
fill 2 57 363 2 60 363 minecraft:honeycomb_block
setblock 3 57 326 minecraft:yellow_terracotta
fill 3 57 327 3 60 327 minecraft:honeycomb_block
setblock 4 57 325 minecraft:yellow_terracotta
setblock 4 57 326 minecraft:honeycomb_block
setblock 5 57 324 minecraft:yellow_terracotta
fill 5 57 325 5 60 325 minecraft:honeycomb_block
setblock 6 57 323 minecraft:yellow_terracotta
fill 6 57 324 6 60 324 minecraft:honeycomb_block
setblock 6 57 363 minecraft:yellow_terracotta
fill 7 57 323 7 60 323 minecraft:honeycomb_block
setblock 7 57 362 minecraft:yellow_terracotta
fill 7 57 363 7 60 363 minecraft:honeycomb_block
setblock 8 57 362 minecraft:honeycomb_block
setblock 9 57 325 minecraft:yellow_terracotta
setblock 10 57 324 minecraft:yellow_terracotta
setblock 11 57 323 minecraft:yellow_terracotta
setblock 11 57 324 minecraft:honeycomb_block
setblock 11 57 363 minecraft:yellow_terracotta
fill 11 57 364 13 98 364 minecraft:honeycomb_block
fill 12 57 323 12 58 323 minecraft:honeycomb_block
fill 12 57 363 13 57 363 minecraft:honeycomb_block
fill 14 57 322 14 65 322 minecraft:honeycomb_block
setblock 14 57 364 minecraft:yellow_terracotta
fill 17 57 363 17 58 363 minecraft:honey_block
setblock 22 57 363 minecraft:honeycomb_block
setblock 26 57 323 minecraft:yellow_terracotta
setblock 26 57 363 minecraft:yellow_terracotta
fill 27 57 323 27 58 323 minecraft:honeycomb_block
setblock 27 57 363 minecraft:honeycomb_block
fill 34 57 322 34 197 322 minecraft:honeycomb_block
setblock 36 57 363 minecraft:honey_block
setblock 40 57 329 minecraft:yellow_terracotta
fill 40 57 330 40 59 331 minecraft:honeycomb_block
fill 41 57 322 41 106 322 minecraft:honeycomb_block
setblock 41 57 323 minecraft:yellow_terracotta
fill 41 57 324 41 60 324 minecraft:honeycomb_block
setblock 41 57 328 minecraft:yellow_terracotta
fill 41 57 329 41 60 329 minecraft:honeycomb_block
setblock 41 57 333 minecraft:yellow_terracotta
fill 41 57 334 41 60 334 minecraft:honeycomb_block
fill 41 57 336 41 58 336 minecraft:honeycomb_block
setblock 41 57 343 minecraft:yellow_terracotta
fill 41 57 344 41 59 344 minecraft:honeycomb_block
setblock 41 57 348 minecraft:yellow_terracotta
fill 41 57 349 41 60 349 minecraft:honeycomb_block
fill 0 58 324 0 60 327 minecraft:honeycomb_block
setblock 0 58 328 minecraft:orange_terracotta
fill 1 58 323 1 61 323 minecraft:honeycomb_block
setblock 1 58 327 minecraft:yellow_terracotta
fill 1 58 328 1 61 328 minecraft:honeycomb_block
setblock 1 58 332 minecraft:yellow_terracotta
fill 1 58 333 1 61 333 minecraft:honeycomb_block
setblock 1 58 335 minecraft:honey_block
fill 1 58 341 1 59 341 minecraft:honey_block
setblock 1 58 347 minecraft:yellow_terracotta
fill 1 58 348 1 61 348 minecraft:honeycomb_block
setblock 1 58 351 minecraft:honeycomb_block
setblock 1 58 352 minecraft:yellow_terracotta
setblock 1 58 360 minecraft:honey_block
setblock 2 58 326 minecraft:yellow_terracotta
fill 2 58 327 2 61 327 minecraft:honeycomb_block
setblock 2 58 331 minecraft:yellow_terracotta
fill 2 58 332 2 61 332 minecraft:honeycomb_block
setblock 3 58 325 minecraft:yellow_terracotta
fill 3 58 326 3 61 326 minecraft:honeycomb_block
setblock 3 58 330 minecraft:yellow_terracotta
setblock 4 58 324 minecraft:yellow_terracotta
fill 4 58 325 4 61 325 minecraft:honeycomb_block
setblock 5 58 323 minecraft:yellow_terracotta
fill 5 58 324 5 61 324 minecraft:honeycomb_block
setblock 5 58 363 minecraft:yellow_terracotta
fill 6 58 323 6 61 323 minecraft:honeycomb_block
setblock 6 58 362 minecraft:yellow_terracotta
fill 6 58 363 6 61 363 minecraft:honeycomb_block
setblock 8 58 325 minecraft:yellow_terracotta
setblock 9 58 324 minecraft:yellow_terracotta
fill 9 58 363 9 58 364 minecraft:honeycomb_block
setblock 10 58 323 minecraft:yellow_terracotta
setblock 10 58 324 minecraft:honeycomb_block
setblock 10 58 363 minecraft:yellow_terracotta
fill 10 58 364 10 147 364 minecraft:honeycomb_block
fill 11 58 323 11 59 323 minecraft:honeycomb_block
setblock 11 58 363 minecraft:honeycomb_block
setblock 12 58 322 minecraft:yellow_terracotta
fill 14 58 364 14 144 364 minecraft:honeycomb_block
setblock 19 58 323 minecraft:honey_block
setblock 23 58 363 minecraft:honey_block
setblock 25 58 323 minecraft:yellow_terracotta
setblock 25 58 363 minecraft:yellow_terracotta
fill 26 58 323 26 59 323 minecraft:honeycomb_block
setblock 40 58 323 minecraft:yellow_terracotta
fill 40 58 325 40 60 325 minecraft:honeycomb_block
setblock 40 58 328 minecraft:yellow_terracotta
fill 40 58 329 40 61 329 minecraft:honeycomb_block
setblock 40 58 332 minecraft:honeycomb_block
fill 41 58 323 41 61 323 minecraft:honeycomb_block
setblock 41 58 327 minecraft:yellow_terracotta
fill 41 58 328 41 61 328 minecraft:honeycomb_block
setblock 41 58 332 minecraft:yellow_terracotta
fill 41 58 333 41 61 333 minecraft:honeycomb_block
setblock 41 58 337 minecraft:yellow_terracotta
setblock 41 58 347 minecraft:yellow_terracotta
fill 41 58 348 41 61 348 minecraft:honeycomb_block
fill 0 59 328 0 104 328 minecraft:honeycomb_block
setblock 0 59 332 minecraft:yellow_concrete
setblock 1 59 326 minecraft:yellow_terracotta
fill 1 59 327 1 62 327 minecraft:honeycomb_block
setblock 1 59 331 minecraft:yellow_terracotta
fill 1 59 332 1 62 332 minecraft:honeycomb_block
setblock 1 59 335 minecraft:honeycomb_block
fill 1 59 347 1 62 347 minecraft:honeycomb_block
setblock 1 59 351 minecraft:yellow_terracotta
fill 1 59 352 1 60 354 minecraft:honeycomb_block
setblock 2 59 325 minecraft:yellow_terracotta
fill 2 59 326 2 62 326 minecraft:honeycomb_block
setblock 2 59 330 minecraft:yellow_terracotta
fill 2 59 331 3 61 331 minecraft:honeycomb_block
fill 2 59 333 2 60 333 minecraft:honeycomb_block
setblock 3 59 324 minecraft:yellow_terracotta
fill 3 59 325 3 62 325 minecraft:honeycomb_block
setblock 3 59 329 minecraft:yellow_terracotta
fill 3 59 330 3 62 330 minecraft:honeycomb_block
setblock 4 59 323 minecraft:yellow_terracotta
fill 4 59 324 4 62 324 minecraft:honeycomb_block
setblock 4 59 363 minecraft:yellow_terracotta
fill 5 59 323 5 62 323 minecraft:honeycomb_block
fill 5 59 363 5 62 363 minecraft:honeycomb_block
setblock 7 59 325 minecraft:yellow_terracotta
setblock 8 59 324 minecraft:yellow_terracotta
setblock 9 59 323 minecraft:yellow_terracotta
setblock 9 59 324 minecraft:honeycomb_block
setblock 9 59 363 minecraft:yellow_terracotta
fill 9 59 364 9 110 364 minecraft:honeycomb_block
fill 10 59 323 10 60 323 minecraft:honeycomb_block
fill 10 59 363 10 60 363 minecraft:honeycomb_block
fill 12 59 322 12 190 322 minecraft:honeycomb_block
setblock 13 59 323 minecraft:honey_block
fill 22 59 356 22 60 357 minecraft:black_concrete
fill 23 59 322 23 126 322 minecraft:honeycomb_block
setblock 24 59 323 minecraft:yellow_terracotta
setblock 25 59 323 minecraft:honeycomb_block
setblock 29 59 363 minecraft:honey_block
setblock 38 59 323 minecraft:honey_block
fill 40 59 323 40 62 323 minecraft:honeycomb_block
setblock 40 59 327 minecraft:yellow_terracotta
fill 40 59 328 40 62 328 minecraft:honeycomb_block
setblock 40 59 332 minecraft:yellow_terracotta
fill 40 59 333 40 62 333 minecraft:honeycomb_block
setblock 41 59 326 minecraft:yellow_terracotta
fill 41 59 327 41 62 327 minecraft:honeycomb_block
setblock 41 59 331 minecraft:yellow_terracotta
fill 41 59 332 41 62 332 minecraft:honeycomb_block
setblock 41 59 336 minecraft:yellow_terracotta
fill 41 59 337 41 61 338 minecraft:honeycomb_block
setblock 41 59 339 minecraft:honey_block
setblock 41 59 346 minecraft:yellow_terracotta
fill 41 59 347 41 62 347 minecraft:honeycomb_block
setblock 41 59 350 minecraft:honeycomb_block
setblock 41 59 351 minecraft:yellow_terracotta
fill 41 59 352 41 62 352 minecraft:honeycomb_block
setblock 42 59 350 minecraft:yellow_terracotta
fill 0 60 332 0 69 332 minecraft:honeycomb_block
setblock 1 60 325 minecraft:yellow_terracotta
fill 1 60 326 1 63 326 minecraft:honeycomb_block
setblock 1 60 330 minecraft:yellow_terracotta
fill 1 60 331 1 63 331 minecraft:honeycomb_block
setblock 1 60 335 minecraft:yellow_terracotta
fill 1 60 336 1 63 336 minecraft:honeycomb_block
setblock 1 60 349 minecraft:honeycomb_block
setblock 1 60 350 minecraft:yellow_terracotta
fill 1 60 351 2 62 351 minecraft:honeycomb_block
setblock 1 60 355 minecraft:yellow_terracotta
fill 1 60 356 1 61 358 minecraft:honeycomb_block
fill 1 60 362 1 61 363 minecraft:honeycomb_block
setblock 2 60 324 minecraft:yellow_terracotta
fill 2 60 325 2 63 325 minecraft:honeycomb_block
setblock 2 60 329 minecraft:yellow_terracotta
fill 2 60 330 2 63 330 minecraft:honeycomb_block
setblock 2 60 334 minecraft:yellow_terracotta
fill 2 60 350 2 63 350 minecraft:honeycomb_block
fill 2 60 352 2 60 353 minecraft:honeycomb_block
setblock 2 60 354 minecraft:yellow_terracotta
setblock 3 60 323 minecraft:yellow_terracotta
fill 3 60 324 3 63 324 minecraft:honeycomb_block
setblock 3 60 328 minecraft:yellow_terracotta
fill 3 60 329 3 63 329 minecraft:honeycomb_block
setblock 3 60 332 minecraft:honeycomb_block
setblock 3 60 363 minecraft:yellow_terracotta
fill 4 60 323 4 63 323 minecraft:honeycomb_block
fill 4 60 363 4 63 363 minecraft:honeycomb_block
fill 5 60 362 5 63 362 minecraft:honeycomb_block
setblock 6 60 325 minecraft:yellow_terracotta
setblock 7 60 324 minecraft:yellow_terracotta
setblock 8 60 323 minecraft:yellow_terracotta
setblock 8 60 324 minecraft:honeycomb_block
setblock 8 60 363 minecraft:yellow_terracotta
fill 9 60 322 9 62 323 minecraft:honeycomb_block
fill 9 60 363 9 63 363 minecraft:honeycomb_block
fill 10 60 322 10 157 322 minecraft:honeycomb_block
setblock 11 60 322 minecraft:yellow_concrete
setblock 32 60 323 minecraft:honey_block
fill 34 60 323 36 61 323 minecraft:yellow_terracotta
fill 34 60 362 34 61 363 minecraft:yellow_terracotta
fill 35 60 362 36 61 362 minecraft:yellow_terracotta
setblock 35 60 363 minecraft:honey_block
fill 36 60 363 36 61 363 minecraft:yellow_terracotta
setblock 40 60 326 minecraft:yellow_terracotta
fill 40 60 327 40 63 327 minecraft:honeycomb_block
setblock 40 60 330 minecraft:honeycomb_block
setblock 40 60 331 minecraft:yellow_terracotta
fill 40 60 332 40 63 332 minecraft:honeycomb_block
fill 40 60 334 40 60 335 minecraft:honeycomb_block
setblock 41 60 325 minecraft:yellow_terracotta
fill 41 60 326 41 63 326 minecraft:honeycomb_block
setblock 41 60 330 minecraft:yellow_terracotta
fill 41 60 331 41 63 331 minecraft:honeycomb_block
setblock 41 60 335 minecraft:yellow_terracotta
fill 41 60 336 41 63 336 minecraft:honeycomb_block
setblock 41 60 339 minecraft:honeycomb_block
setblock 41 60 345 minecraft:yellow_terracotta
fill 41 60 346 41 63 346 minecraft:honeycomb_block
setblock 41 60 350 minecraft:yellow_terracotta
fill 41 60 351 41 63 351 minecraft:honeycomb_block
fill 41 60 353 41 60 354 minecraft:honeycomb_block
setblock 41 60 358 minecraft:honey_block
fill 42 60 350 42 110 350 minecraft:honeycomb_block
fill 0 61 324 0 176 325 minecraft:honeycomb_block
setblock 0 61 326 minecraft:orange_terracotta
setblock 0 61 327 minecraft:honeycomb_block
setblock 1 61 324 minecraft:yellow_terracotta
fill 1 61 325 1 64 325 minecraft:honeycomb_block
setblock 1 61 329 minecraft:yellow_terracotta
fill 1 61 330 1 64 330 minecraft:honeycomb_block
setblock 1 61 334 minecraft:yellow_terracotta
fill 1 61 335 2 63 335 minecraft:honeycomb_block
fill 1 61 337 1 62 337 minecraft:honeycomb_block
setblock 1 61 349 minecraft:yellow_terracotta
fill 1 61 350 1 64 350 minecraft:honeycomb_block
fill 1 61 352 1 61 353 minecraft:honeycomb_block
setblock 1 61 354 minecraft:yellow_terracotta
fill 1 61 355 2 63 355 minecraft:honeycomb_block
setblock 1 61 359 minecraft:yellow_terracotta
fill 1 61 360 1 63 361 minecraft:honeycomb_block
setblock 2 61 323 minecraft:yellow_terracotta
fill 2 61 324 2 64 324 minecraft:honeycomb_block
setblock 2 61 328 minecraft:yellow_terracotta
fill 2 61 329 2 64 329 minecraft:honeycomb_block
setblock 2 61 333 minecraft:yellow_terracotta
fill 2 61 334 2 64 334 minecraft:honeycomb_block
fill 2 61 349 2 64 349 minecraft:honeycomb_block
setblock 2 61 352 minecraft:honeycomb_block
setblock 2 61 353 minecraft:yellow_terracotta
fill 2 61 354 2 64 354 minecraft:honeycomb_block
fill 2 61 356 2 61 357 minecraft:honeycomb_block
setblock 2 61 358 minecraft:yellow_terracotta
setblock 2 61 363 minecraft:yellow_terracotta
fill 3 61 323 3 64 323 minecraft:honeycomb_block
setblock 3 61 327 minecraft:yellow_terracotta
fill 3 61 328 3 64 328 minecraft:honeycomb_block
setblock 3 61 332 minecraft:yellow_terracotta
setblock 3 61 362 minecraft:yellow_terracotta
fill 3 61 363 3 64 363 minecraft:honeycomb_block
fill 4 61 362 4 64 362 minecraft:honeycomb_block
setblock 5 61 325 minecraft:yellow_terracotta
setblock 6 61 324 minecraft:yellow_terracotta
fill 6 61 362 6 62 362 minecraft:honeycomb_block
setblock 7 61 323 minecraft:yellow_terracotta
fill 7 61 324 7 62 324 minecraft:honeycomb_block
setblock 7 61 363 minecraft:yellow_terracotta
fill 8 61 323 8 64 323 minecraft:honeycomb_block
fill 8 61 363 8 64 363 minecraft:honeycomb_block
fill 11 61 322 11 98 322 minecraft:honeycomb_block
fill 15 61 322 17 81 322 minecraft:honeycomb_block
setblock 16 61 363 minecraft:honey_block
setblock 18 61 322 minecraft:orange_terracotta
fill 19 61 322 22 65 322 minecraft:honeycomb_block
setblock 26 61 323 minecraft:honey_block
fill 34 61 324 36 62 324 minecraft:yellow_terracotta
fill 34 61 361 36 62 361 minecraft:yellow_terracotta
fill 35 61 325 35 63 325 minecraft:yellow_terracotta
fill 35 61 360 35 63 360 minecraft:yellow_terracotta
setblock 35 61 363 minecraft:yellow_terracotta
fill 39 61 323 39 63 323 minecraft:honeycomb_block
fill 39 61 328 39 61 330 minecraft:honeycomb_block
setblock 39 61 331 minecraft:yellow_terracotta
fill 39 61 332 39 63 333 minecraft:honeycomb_block
setblock 40 61 324 minecraft:honeycomb_block
setblock 40 61 325 minecraft:yellow_terracotta
fill 40 61 326 40 64 326 minecraft:honeycomb_block
setblock 40 61 330 minecraft:yellow_terracotta
fill 40 61 331 40 64 331 minecraft:honeycomb_block
setblock 40 61 334 minecraft:honeycomb_block
setblock 40 61 335 minecraft:yellow_terracotta
fill 40 61 336 40 64 336 minecraft:honeycomb_block
setblock 41 61 324 minecraft:yellow_terracotta
fill 41 61 325 41 64 325 minecraft:honeycomb_block
setblock 41 61 329 minecraft:yellow_terracotta
fill 41 61 330 41 64 330 minecraft:honeycomb_block
setblock 41 61 334 minecraft:yellow_terracotta
fill 41 61 335 41 64 335 minecraft:honeycomb_block
setblock 41 61 339 minecraft:yellow_terracotta
fill 41 61 340 41 63 341 minecraft:honeycomb_block
setblock 41 61 344 minecraft:yellow_terracotta
fill 41 61 345 41 64 345 minecraft:honeycomb_block
setblock 41 61 349 minecraft:yellow_terracotta
fill 41 61 350 41 64 350 minecraft:honeycomb_block
setblock 41 61 353 minecraft:honeycomb_block
setblock 41 61 354 minecraft:yellow_terracotta
fill 41 61 355 41 63 356 minecraft:honeycomb_block
setblock 41 61 363 minecraft:honey_block
setblock 42 61 345 minecraft:orange_terracotta
fill 42 61 346 42 63 348 minecraft:honeycomb_block
fill 0 62 326 0 140 326 minecraft:honeycomb_block
setblock 0 62 327 minecraft:yellow_terracotta
setblock 1 62 323 minecraft:yellow_terracotta
fill 1 62 324 1 65 324 minecraft:honeycomb_block
setblock 1 62 328 minecraft:yellow_terracotta
fill 1 62 329 1 65 329 minecraft:honeycomb_block
setblock 1 62 333 minecraft:yellow_terracotta
fill 1 62 334 1 65 334 minecraft:honeycomb_block
setblock 1 62 338 minecraft:yellow_terracotta
setblock 1 62 340 minecraft:honey_block
fill 1 62 346 1 63 346 minecraft:honeycomb_block
setblock 1 62 348 minecraft:yellow_terracotta
fill 1 62 349 1 65 349 minecraft:honeycomb_block
setblock 1 62 352 minecraft:honeycomb_block
setblock 1 62 353 minecraft:yellow_terracotta
fill 1 62 354 1 65 354 minecraft:honeycomb_block
fill 1 62 356 1 62 357 minecraft:honeycomb_block
setblock 1 62 358 minecraft:yellow_terracotta
fill 1 62 359 2 64 359 minecraft:honeycomb_block
setblock 1 62 362 minecraft:honeycomb_block
setblock 1 62 363 minecraft:yellow_terracotta
fill 2 62 323 2 65 323 minecraft:honeycomb_block
setblock 2 62 327 minecraft:yellow_terracotta
fill 2 62 328 2 65 328 minecraft:honeycomb_block
setblock 2 62 331 minecraft:honeycomb_block
setblock 2 62 332 minecraft:yellow_terracotta
fill 2 62 333 3 64 333 minecraft:honeycomb_block
setblock 2 62 336 minecraft:honeycomb_block
setblock 2 62 352 minecraft:yellow_terracotta
fill 2 62 353 3 64 353 minecraft:honeycomb_block
setblock 2 62 356 minecraft:honeycomb_block
setblock 2 62 357 minecraft:yellow_terracotta
fill 2 62 358 2 65 358 minecraft:honeycomb_block
fill 2 62 360 2 62 361 minecraft:honeycomb_block
setblock 2 62 362 minecraft:yellow_terracotta
fill 2 62 363 2 65 363 minecraft:honeycomb_block
setblock 3 62 326 minecraft:yellow_terracotta
fill 3 62 327 3 65 327 minecraft:honeycomb_block
setblock 3 62 331 minecraft:yellow_terracotta
fill 3 62 332 3 65 332 minecraft:honeycomb_block
setblock 3 62 339 minecraft:light[level=12]
setblock 3 62 346 minecraft:light[level=12]
setblock 3 62 351 minecraft:yellow_terracotta
fill 3 62 352 3 65 352 minecraft:honeycomb_block
fill 3 62 354 3 62 355 minecraft:honeycomb_block
setblock 3 62 356 minecraft:yellow_terracotta
fill 3 62 357 3 65 357 minecraft:honeycomb_block
setblock 3 62 360 minecraft:light[level=12]
fill 3 62 362 3 65 362 minecraft:honeycomb_block
setblock 4 62 325 minecraft:yellow_terracotta
setblock 5 62 324 minecraft:yellow_terracotta
setblock 5 62 325 minecraft:honeycomb_block
setblock 6 62 323 minecraft:yellow_terracotta
fill 6 62 324 6 64 324 minecraft:honeycomb_block
setblock 6 62 363 minecraft:yellow_terracotta
fill 7 62 323 7 65 323 minecraft:honeycomb_block
setblock 7 62 362 minecraft:yellow_terracotta
fill 7 62 363 7 65 363 minecraft:honeycomb_block
setblock 10 62 325 minecraft:light[level=12]
setblock 10 62 332 minecraft:light[level=12]
setblock 10 62 339 minecraft:light[level=12]
setblock 10 62 346 minecraft:light[level=12]
setblock 10 62 353 minecraft:light[level=12]
setblock 10 62 360 minecraft:light[level=12]
setblock 17 62 325 minecraft:light[level=12]
setblock 17 62 332 minecraft:light[level=12]
setblock 17 62 339 minecraft:light[level=12]
setblock 17 62 346 minecraft:light[level=12]
setblock 17 62 353 minecraft:light[level=12]
setblock 17 62 360 minecraft:light[level=12]
fill 18 62 322 18 76 322 minecraft:honeycomb_block
setblock 20 62 323 minecraft:honey_block
setblock 21 62 363 minecraft:yellow_terracotta
fill 22 62 363 23 64 363 minecraft:honeycomb_block
setblock 24 62 325 minecraft:light[level=12]
setblock 24 62 332 minecraft:light[level=12]
setblock 24 62 346 minecraft:light[level=12]
setblock 24 62 353 minecraft:light[level=12]
setblock 24 62 360 minecraft:light[level=12]
setblock 31 62 325 minecraft:light[level=12]
setblock 31 62 332 minecraft:light[level=12]
setblock 31 62 339 minecraft:light[level=12]
setblock 31 62 346 minecraft:light[level=12]
setblock 31 62 353 minecraft:light[level=12]
setblock 31 62 360 minecraft:light[level=12]
fill 34 62 325 34 63 325 minecraft:yellow_terracotta
fill 34 62 360 34 63 360 minecraft:yellow_terracotta
setblock 35 62 323 minecraft:yellow_terracotta
fill 35 62 326 35 64 326 minecraft:yellow_terracotta
fill 35 62 359 35 64 359 minecraft:yellow_terracotta
setblock 35 62 362 minecraft:yellow_terracotta
setblock 35 62 363 minecraft:honey_block
fill 36 62 325 36 63 325 minecraft:yellow_terracotta
fill 36 62 360 36 63 360 minecraft:yellow_terracotta
setblock 38 62 325 minecraft:light[level=12]
setblock 38 62 332 minecraft:light[level=12]
setblock 38 62 339 minecraft:light[level=12]
setblock 38 62 346 minecraft:light[level=12]
setblock 38 62 353 minecraft:light[level=12]
setblock 38 62 360 minecraft:light[level=12]
fill 39 62 327 39 62 329 minecraft:honeycomb_block
setblock 39 62 330 minecraft:yellow_terracotta
fill 39 62 331 39 65 331 minecraft:honeycomb_block
setblock 39 62 334 minecraft:honeycomb_block
setblock 40 62 324 minecraft:yellow_terracotta
fill 40 62 325 40 65 325 minecraft:honeycomb_block
setblock 40 62 329 minecraft:yellow_terracotta
fill 40 62 330 40 65 330 minecraft:honeycomb_block
setblock 40 62 334 minecraft:yellow_terracotta
fill 40 62 335 40 65 335 minecraft:honeycomb_block
fill 40 62 337 40 62 338 minecraft:honeycomb_block
fill 40 62 351 40 62 353 minecraft:honeycomb_block
setblock 41 62 323 minecraft:yellow_terracotta
fill 41 62 324 41 65 324 minecraft:honeycomb_block
setblock 41 62 328 minecraft:yellow_terracotta
fill 41 62 329 41 65 329 minecraft:honeycomb_block
setblock 41 62 333 minecraft:yellow_terracotta
fill 41 62 334 41 65 334 minecraft:honeycomb_block
setblock 41 62 337 minecraft:honeycomb_block
setblock 41 62 338 minecraft:yellow_terracotta
fill 41 62 339 41 65 339 minecraft:honeycomb_block
setblock 41 62 342 minecraft:honeycomb_block
setblock 41 62 343 minecraft:yellow_terracotta
fill 41 62 344 41 65 344 minecraft:honeycomb_block
setblock 41 62 348 minecraft:yellow_terracotta
fill 41 62 349 41 65 349 minecraft:honeycomb_block
setblock 41 62 353 minecraft:yellow_terracotta
fill 41 62 354 41 65 354 minecraft:honeycomb_block
setblock 41 62 357 minecraft:honeycomb_block
setblock 41 62 358 minecraft:yellow_terracotta
fill 41 62 359 41 65 359 minecraft:honeycomb_block
fill 42 62 345 42 274 345 minecraft:honeycomb_block
fill 0 63 327 0 171 327 minecraft:honeycomb_block
fill 0 63 354 0 129 356 minecraft:honeycomb_block
fill 0 63 357 1 63 357 minecraft:yellow_terracotta
fill 1 63 323 1 66 323 minecraft:honeycomb_block
setblock 1 63 327 minecraft:yellow_terracotta
fill 1 63 328 1 66 328 minecraft:honeycomb_block
setblock 1 63 332 minecraft:yellow_terracotta
fill 1 63 333 1 66 333 minecraft:honeycomb_block
setblock 1 63 337 minecraft:yellow_terracotta
fill 1 63 338 1 65 339 minecraft:honeycomb_block
setblock 1 63 347 minecraft:yellow_terracotta
fill 1 63 348 2 65 348 minecraft:honeycomb_block
setblock 1 63 351 minecraft:honeycomb_block
setblock 1 63 352 minecraft:yellow_terracotta
fill 1 63 353 1 66 353 minecraft:honeycomb_block
setblock 1 63 356 minecraft:honeycomb_block
fill 1 63 358 1 66 358 minecraft:honeycomb_block
setblock 1 63 362 minecraft:yellow_terracotta
fill 1 63 363 1 66 363 minecraft:honeycomb_block
setblock 2 63 326 minecraft:yellow_terracotta
fill 2 63 327 2 66 327 minecraft:honeycomb_block
setblock 2 63 331 minecraft:yellow_terracotta
fill 2 63 332 2 66 332 minecraft:honeycomb_block
setblock 2 63 336 minecraft:yellow_terracotta
fill 2 63 337 2 66 337 minecraft:honeycomb_block
setblock 2 63 351 minecraft:yellow_terracotta
fill 2 63 352 2 66 352 minecraft:honeycomb_block
setblock 2 63 356 minecraft:yellow_terracotta
fill 2 63 357 2 66 357 minecraft:honeycomb_block
setblock 2 63 360 minecraft:honeycomb_block
setblock 2 63 361 minecraft:yellow_terracotta
fill 2 63 362 2 66 362 minecraft:honeycomb_block
setblock 3 63 325 minecraft:yellow_terracotta
fill 3 63 326 3 65 326 minecraft:honeycomb_block
setblock 3 63 330 minecraft:yellow_terracotta
fill 3 63 331 3 66 331 minecraft:honeycomb_block
setblock 3 63 334 minecraft:honeycomb_block
fill 3 63 351 3 66 351 minecraft:honeycomb_block
setblock 3 63 354 minecraft:honeycomb_block
setblock 3 63 355 minecraft:yellow_terracotta
fill 3 63 356 3 66 356 minecraft:honeycomb_block
fill 3 63 358 3 63 359 minecraft:honeycomb_block
setblock 3 63 360 minecraft:yellow_terracotta
setblock 4 63 324 minecraft:yellow_terracotta
setblock 4 63 325 minecraft:honeycomb_block
setblock 5 63 323 minecraft:yellow_terracotta
fill 5 63 324 5 65 324 minecraft:honeycomb_block
setblock 5 63 363 minecraft:yellow_terracotta
fill 6 63 323 6 66 323 minecraft:honeycomb_block
setblock 6 63 362 minecraft:yellow_terracotta
fill 6 63 363 6 66 363 minecraft:honeycomb_block
fill 7 63 362 7 66 362 minecraft:honeycomb_block
setblock 9 63 322 minecraft:honeycomb_block
setblock 10 63 363 minecraft:yellow_terracotta
setblock 14 63 323 minecraft:honey_block
setblock 19 63 363 minecraft:honeycomb_block
setblock 20 63 363 minecraft:yellow_terracotta
fill 21 63 363 21 66 363 minecraft:honeycomb_block
setblock 24 63 363 minecraft:honeycomb_block
setblock 28 63 363 minecraft:honey_block
setblock 33 63 323 minecraft:honey_block
fill 34 63 326 34 64 327 minecraft:yellow_terracotta
fill 34 63 358 34 64 359 minecraft:yellow_terracotta
setblock 35 63 323 minecraft:honey_block
setblock 35 63 324 minecraft:yellow_terracotta
fill 35 63 327 36 64 327 minecraft:yellow_terracotta
fill 35 63 358 36 64 358 minecraft:yellow_terracotta
setblock 35 63 361 minecraft:yellow_terracotta
setblock 35 63 362 minecraft:honey_block
fill 36 63 326 36 64 326 minecraft:yellow_terracotta
fill 36 63 345 36 64 345 minecraft:ochre_froglight
fill 36 63 359 36 64 359 minecraft:yellow_terracotta
fill 38 63 323 38 64 323 minecraft:honeycomb_block
setblock 39 63 324 minecraft:yellow_terracotta
fill 39 63 327 39 63 328 minecraft:honeycomb_block
setblock 39 63 329 minecraft:yellow_terracotta
fill 39 63 330 39 66 330 minecraft:honeycomb_block
setblock 39 63 334 minecraft:yellow_terracotta
fill 39 63 335 39 65 336 minecraft:honeycomb_block
setblock 40 63 323 minecraft:yellow_terracotta
fill 40 63 324 40 66 324 minecraft:honeycomb_block
setblock 40 63 328 minecraft:yellow_terracotta
fill 40 63 329 40 66 329 minecraft:honeycomb_block
setblock 40 63 333 minecraft:yellow_terracotta
fill 40 63 334 40 66 334 minecraft:honeycomb_block
setblock 40 63 337 minecraft:honeycomb_block
setblock 40 63 338 minecraft:yellow_terracotta
fill 40 63 339 40 66 339 minecraft:honeycomb_block
fill 40 63 350 40 63 352 minecraft:honeycomb_block
setblock 40 63 353 minecraft:yellow_terracotta
fill 40 63 354 40 64 356 minecraft:honeycomb_block
fill 41 63 323 41 66 323 minecraft:honeycomb_block
setblock 41 63 327 minecraft:yellow_terracotta
fill 41 63 328 41 66 328 minecraft:honeycomb_block
setblock 41 63 332 minecraft:yellow_terracotta
fill 41 63 333 41 66 333 minecraft:honeycomb_block
setblock 41 63 337 minecraft:yellow_terracotta
fill 41 63 338 41 66 338 minecraft:honeycomb_block
setblock 41 63 342 minecraft:yellow_terracotta
fill 41 63 343 41 66 343 minecraft:honeycomb_block
setblock 41 63 347 minecraft:yellow_terracotta
fill 41 63 348 41 66 348 minecraft:honeycomb_block
setblock 41 63 352 minecraft:yellow_terracotta
fill 41 63 353 41 66 353 minecraft:honeycomb_block
setblock 41 63 357 minecraft:yellow_terracotta
fill 41 63 358 41 66 358 minecraft:honeycomb_block
fill 41 63 360 41 63 361 minecraft:honeycomb_block
setblock 41 63 362 minecraft:yellow_terracotta
fill 41 63 363 41 66 363 minecraft:honeycomb_block
fill 0 64 357 1 67 357 minecraft:honeycomb_block
fill 0 64 359 0 89 361 minecraft:honeycomb_block
setblock 0 64 362 minecraft:yellow_concrete
fill 0 64 363 0 175 364 minecraft:honeycomb_block
setblock 1 64 326 minecraft:yellow_terracotta
fill 1 64 327 1 67 327 minecraft:honeycomb_block
setblock 1 64 331 minecraft:yellow_terracotta
fill 1 64 332 1 67 332 minecraft:honeycomb_block
setblock 1 64 335 minecraft:honeycomb_block
setblock 1 64 336 minecraft:yellow_terracotta
fill 1 64 337 1 67 337 minecraft:honeycomb_block
setblock 1 64 340 minecraft:honeycomb_block
setblock 1 64 341 minecraft:yellow_terracotta
setblock 1 64 345 minecraft:honeycomb_block
setblock 1 64 346 minecraft:yellow_terracotta
fill 1 64 347 1 67 347 minecraft:honeycomb_block
setblock 1 64 351 minecraft:yellow_terracotta
fill 1 64 352 1 67 352 minecraft:honeycomb_block
setblock 1 64 355 minecraft:honeycomb_block
setblock 1 64 356 minecraft:yellow_terracotta
setblock 1 64 360 minecraft:honeycomb_block
setblock 1 64 361 minecraft:yellow_terracotta
fill 1 64 362 1 67 362 minecraft:honeycomb_block
setblock 2 64 325 minecraft:yellow_terracotta
fill 2 64 326 2 67 326 minecraft:honeycomb_block
setblock 2 64 330 minecraft:yellow_terracotta
fill 2 64 331 2 67 331 minecraft:honeycomb_block
setblock 2 64 335 minecraft:yellow_terracotta
fill 2 64 336 2 67 336 minecraft:honeycomb_block
fill 2 64 338 2 65 338 minecraft:honeycomb_block
setblock 2 64 350 minecraft:yellow_terracotta
fill 2 64 351 2 67 351 minecraft:honeycomb_block
setblock 2 64 355 minecraft:yellow_terracotta
fill 2 64 356 2 67 356 minecraft:honeycomb_block
setblock 2 64 360 minecraft:yellow_terracotta
fill 2 64 361 5 64 361 minecraft:honeycomb_block
setblock 3 64 324 minecraft:yellow_terracotta
fill 3 64 325 3 65 325 minecraft:honeycomb_block
setblock 3 64 329 minecraft:yellow_terracotta
fill 3 64 330 3 66 330 minecraft:honeycomb_block
setblock 3 64 334 minecraft:yellow_terracotta
fill 3 64 335 3 67 335 minecraft:honeycomb_block
setblock 3 64 341 minecraft:light[level=15]
setblock 3 64 349 minecraft:light[level=15]
setblock 3 64 350 minecraft:honeycomb_block
setblock 3 64 354 minecraft:yellow_terracotta
fill 3 64 355 4 66 355 minecraft:honeycomb_block
setblock 3 64 358 minecraft:honeycomb_block
setblock 3 64 359 minecraft:yellow_terracotta
fill 3 64 360 3 67 360 minecraft:honeycomb_block
setblock 4 64 323 minecraft:yellow_terracotta
fill 4 64 324 4 66 324 minecraft:honeycomb_block
fill 4 64 354 4 66 354 minecraft:honeycomb_block
fill 4 64 356 4 64 357 minecraft:honeycomb_block
setblock 4 64 363 minecraft:yellow_terracotta
fill 5 64 323 5 67 323 minecraft:honeycomb_block
fill 5 64 338 5 69 338 minecraft:brown_terracotta
setblock 5 64 362 minecraft:yellow_terracotta
fill 5 64 363 5 67 363 minecraft:honeycomb_block
fill 6 64 362 6 67 362 minecraft:honeycomb_block
fill 8 64 362 8 65 362 minecraft:honeycomb_block
setblock 9 64 322 minecraft:orange_terracotta
setblock 9 64 363 minecraft:yellow_terracotta
fill 10 64 363 10 67 363 minecraft:honeycomb_block
setblock 11 64 325 minecraft:light[level=15]
setblock 11 64 333 minecraft:light[level=15]
setblock 11 64 341 minecraft:light[level=15]
fill 11 64 348 11 65 349 minecraft:yellow_concrete
setblock 11 64 357 minecraft:light[level=15]
setblock 15 64 363 minecraft:honey_block
fill 17 64 363 18 64 363 minecraft:honeycomb_block
setblock 19 64 325 minecraft:light[level=15]
setblock 19 64 333 minecraft:light[level=15]
setblock 19 64 341 minecraft:light[level=15]
setblock 19 64 349 minecraft:light[level=15]
setblock 19 64 357 minecraft:light[level=15]
setblock 19 64 363 minecraft:yellow_terracotta
fill 20 64 363 20 67 363 minecraft:honeycomb_block
fill 22 64 323 23 64 323 minecraft:honeycomb_block
setblock 24 64 363 minecraft:yellow_terracotta
setblock 27 64 323 minecraft:honey_block
setblock 27 64 325 minecraft:light[level=15]
setblock 27 64 333 minecraft:light[level=15]
setblock 27 64 341 minecraft:light[level=15]
setblock 27 64 349 minecraft:light[level=15]
setblock 27 64 357 minecraft:light[level=15]
fill 34 64 328 36 65 328 minecraft:yellow_terracotta
fill 34 64 357 36 65 357 minecraft:yellow_terracotta
setblock 34 64 363 minecraft:honey_block
setblock 35 64 325 minecraft:honey_block
fill 35 64 329 35 66 329 minecraft:yellow_terracotta
setblock 35 64 333 minecraft:light[level=15]
setblock 35 64 341 minecraft:light[level=15]
setblock 35 64 349 minecraft:light[level=15]
fill 35 64 356 35 66 356 minecraft:yellow_terracotta
setblock 35 64 360 minecraft:honey_block
fill 37 64 323 37 65 323 minecraft:honeycomb_block
fill 38 64 330 38 64 333 minecraft:honeycomb_block
setblock 38 64 334 minecraft:yellow_terracotta
setblock 39 64 323 minecraft:yellow_terracotta
fill 39 64 324 39 67 324 minecraft:honeycomb_block
fill 39 64 326 39 64 327 minecraft:honeycomb_block
setblock 39 64 328 minecraft:yellow_terracotta
fill 39 64 329 39 67 329 minecraft:honeycomb_block
setblock 39 64 332 minecraft:honeycomb_block
setblock 39 64 333 minecraft:yellow_terracotta
fill 39 64 334 39 67 334 minecraft:honeycomb_block
setblock 39 64 337 minecraft:honeycomb_block
fill 40 64 323 40 67 323 minecraft:honeycomb_block
setblock 40 64 327 minecraft:yellow_terracotta
fill 40 64 328 40 67 328 minecraft:honeycomb_block
setblock 40 64 332 minecraft:yellow_terracotta
fill 40 64 333 40 67 333 minecraft:honeycomb_block
setblock 40 64 337 minecraft:yellow_terracotta
fill 40 64 338 40 67 338 minecraft:honeycomb_block
fill 40 64 340 41 64 340 minecraft:honeycomb_block
fill 40 64 349 40 64 351 minecraft:honeycomb_block
setblock 40 64 352 minecraft:yellow_terracotta
fill 40 64 353 40 67 353 minecraft:honeycomb_block
setblock 40 64 357 minecraft:yellow_terracotta
fill 40 64 358 40 67 358 minecraft:honeycomb_block
fill 40 64 363 40 67 363 minecraft:honeycomb_block
setblock 41 64 326 minecraft:yellow_terracotta
fill 41 64 327 41 67 327 minecraft:honeycomb_block
setblock 41 64 331 minecraft:yellow_terracotta
fill 41 64 332 41 67 332 minecraft:honeycomb_block
setblock 41 64 336 minecraft:yellow_terracotta
fill 41 64 337 41 67 337 minecraft:honeycomb_block
setblock 41 64 341 minecraft:yellow_terracotta
fill 41 64 342 41 67 342 minecraft:honeycomb_block
setblock 41 64 346 minecraft:yellow_terracotta
fill 41 64 347 41 67 347 minecraft:honeycomb_block
setblock 41 64 351 minecraft:yellow_terracotta
fill 41 64 352 41 67 352 minecraft:honeycomb_block
setblock 41 64 355 minecraft:honeycomb_block
setblock 41 64 356 minecraft:yellow_terracotta
fill 41 64 357 41 67 357 minecraft:honeycomb_block
setblock 41 64 360 minecraft:honeycomb_block
setblock 41 64 361 minecraft:yellow_terracotta
fill 41 64 362 41 67 362 minecraft:honeycomb_block
fill 42 64 346 42 180 346 minecraft:honeycomb_block
setblock 42 64 347 minecraft:yellow_terracotta
fill 42 64 348 42 143 348 minecraft:honeycomb_block
setblock 0 65 362 minecraft:honeycomb_block
setblock 1 65 325 minecraft:yellow_terracotta
fill 1 65 326 1 68 326 minecraft:honeycomb_block
setblock 1 65 330 minecraft:yellow_terracotta
fill 1 65 331 1 68 331 minecraft:honeycomb_block
setblock 1 65 335 minecraft:yellow_terracotta
fill 1 65 336 1 68 336 minecraft:honeycomb_block
setblock 1 65 340 minecraft:yellow_terracotta
fill 1 65 341 1 65 344 minecraft:honeycomb_block
setblock 1 65 345 minecraft:yellow_terracotta
fill 1 65 346 1 67 346 minecraft:honeycomb_block
setblock 1 65 350 minecraft:yellow_terracotta
fill 1 65 351 1 68 351 minecraft:honeycomb_block
setblock 1 65 355 minecraft:yellow_terracotta
fill 1 65 356 1 68 356 minecraft:honeycomb_block
setblock 1 65 359 minecraft:honeycomb_block
setblock 1 65 360 minecraft:yellow_terracotta
fill 1 65 361 4 65 361 minecraft:honeycomb_block
setblock 2 65 324 minecraft:yellow_terracotta
fill 2 65 325 2 68 325 minecraft:honeycomb_block
setblock 2 65 329 minecraft:yellow_terracotta
fill 2 65 330 2 68 330 minecraft:honeycomb_block
setblock 2 65 333 minecraft:honeycomb_block
setblock 2 65 334 minecraft:yellow_terracotta
fill 2 65 335 2 68 335 minecraft:honeycomb_block
setblock 2 65 349 minecraft:yellow_terracotta
fill 2 65 350 2 68 350 minecraft:honeycomb_block
setblock 2 65 353 minecraft:honeycomb_block
setblock 2 65 354 minecraft:yellow_terracotta
fill 2 65 355 2 68 355 minecraft:honeycomb_block
setblock 2 65 359 minecraft:yellow_terracotta
fill 2 65 360 2 68 360 minecraft:honeycomb_block
setblock 3 65 323 minecraft:yellow_terracotta
fill 3 65 324 3 67 324 minecraft:honeycomb_block
setblock 3 65 328 minecraft:yellow_terracotta
fill 3 65 329 3 66 329 minecraft:honeycomb_block
setblock 3 65 333 minecraft:yellow_terracotta
fill 3 65 334 3 67 334 minecraft:honeycomb_block
setblock 3 65 353 minecraft:yellow_terracotta
fill 3 65 354 3 68 354 minecraft:honeycomb_block
setblock 3 65 358 minecraft:yellow_terracotta
fill 3 65 359 4 67 359 minecraft:honeycomb_block
setblock 3 65 363 minecraft:yellow_terracotta
fill 4 65 323 4 68 323 minecraft:honeycomb_block
setblock 4 65 353 minecraft:honeycomb_block
setblock 4 65 356 minecraft:honeycomb_block
setblock 4 65 357 minecraft:yellow_terracotta
fill 4 65 358 4 68 358 minecraft:honeycomb_block
setblock 4 65 362 minecraft:yellow_terracotta
fill 4 65 363 4 68 363 minecraft:honeycomb_block
setblock 5 65 361 minecraft:yellow_terracotta
fill 5 65 362 5 68 362 minecraft:honeycomb_block
fill 6 65 361 6 68 361 minecraft:honeycomb_block
setblock 8 65 363 minecraft:yellow_terracotta
fill 9 65 322 9 67 322 minecraft:honeycomb_block
fill 9 65 363 9 68 363 minecraft:honeycomb_block
fill 11 65 363 11 66 363 minecraft:honeycomb_block
fill 15 65 363 17 65 363 minecraft:honeycomb_block
setblock 18 65 363 minecraft:yellow_terracotta
setblock 19 65 362 minecraft:yellow_terracotta
fill 19 65 363 19 68 363 minecraft:honeycomb_block
fill 20 65 362 22 66 362 minecraft:honeycomb_block
fill 21 65 323 22 65 323 minecraft:honeycomb_block
setblock 22 65 363 minecraft:honeycomb_block
setblock 23 65 323 minecraft:yellow_terracotta
setblock 23 65 363 minecraft:yellow_terracotta
fill 24 65 363 24 68 363 minecraft:honeycomb_block
fill 34 65 329 34 66 329 minecraft:yellow_terracotta
fill 34 65 356 34 66 356 minecraft:yellow_terracotta
setblock 35 65 326 minecraft:honey_block
setblock 35 65 327 minecraft:yellow_terracotta
fill 35 65 330 35 67 330 minecraft:yellow_terracotta
fill 35 65 355 35 67 355 minecraft:yellow_terracotta
setblock 35 65 358 minecraft:yellow_terracotta
setblock 35 65 359 minecraft:honey_block
fill 36 65 323 36 66 323 minecraft:honeycomb_block
fill 36 65 329 36 66 329 minecraft:yellow_terracotta
fill 36 65 345 36 69 345 minecraft:brown_terracotta
fill 36 65 356 36 66 356 minecraft:yellow_terracotta
setblock 38 65 323 minecraft:yellow_terracotta
fill 38 65 324 38 68 324 minecraft:honeycomb_block
fill 38 65 330 38 65 332 minecraft:honeycomb_block
setblock 38 65 333 minecraft:yellow_terracotta
fill 38 65 334 38 67 335 minecraft:honeycomb_block
setblock 38 65 363 minecraft:yellow_terracotta
fill 39 65 323 39 68 323 minecraft:honeycomb_block
setblock 39 65 326 minecraft:honeycomb_block
setblock 39 65 327 minecraft:yellow_terracotta
fill 39 65 328 39 68 328 minecraft:honeycomb_block
setblock 39 65 332 minecraft:yellow_terracotta
fill 39 65 333 39 68 333 minecraft:honeycomb_block
setblock 39 65 337 minecraft:yellow_terracotta
fill 39 65 338 39 68 338 minecraft:honeycomb_block
fill 39 65 363 39 68 363 minecraft:honeycomb_block
setblock 40 65 326 minecraft:yellow_terracotta
fill 40 65 327 40 68 327 minecraft:honeycomb_block
setblock 40 65 331 minecraft:yellow_terracotta
fill 40 65 332 40 68 332 minecraft:honeycomb_block
setblock 40 65 336 minecraft:yellow_terracotta
fill 40 65 337 40 68 337 minecraft:honeycomb_block
setblock 40 65 340 minecraft:honeycomb_block
setblock 40 65 341 minecraft:yellow_terracotta
setblock 40 65 350 minecraft:honeycomb_block
setblock 40 65 351 minecraft:yellow_terracotta
fill 40 65 352 40 68 352 minecraft:honeycomb_block
fill 40 65 354 40 65 355 minecraft:honeycomb_block
setblock 40 65 356 minecraft:yellow_terracotta
fill 40 65 357 40 68 357 minecraft:honeycomb_block
fill 40 65 359 40 65 360 minecraft:honeycomb_block
setblock 40 65 361 minecraft:yellow_terracotta
setblock 41 65 325 minecraft:yellow_terracotta
fill 41 65 326 41 68 326 minecraft:honeycomb_block
setblock 41 65 330 minecraft:yellow_terracotta
fill 41 65 331 41 68 331 minecraft:honeycomb_block
setblock 41 65 335 minecraft:yellow_terracotta
fill 41 65 336 41 68 336 minecraft:honeycomb_block
setblock 41 65 340 minecraft:yellow_terracotta
fill 41 65 341 41 68 341 minecraft:honeycomb_block
setblock 41 65 345 minecraft:yellow_terracotta
fill 41 65 346 41 67 346 minecraft:honeycomb_block
setblock 41 65 350 minecraft:yellow_terracotta
fill 41 65 351 41 68 351 minecraft:honeycomb_block
setblock 41 65 355 minecraft:yellow_terracotta
fill 41 65 356 41 68 356 minecraft:honeycomb_block
setblock 41 65 360 minecraft:yellow_terracotta
fill 41 65 361 41 68 361 minecraft:honeycomb_block
fill 42 65 347 42 176 347 minecraft:honeycomb_block
setblock 0 66 341 minecraft:yellow_terracotta
setblock 0 66 362 minecraft:orange_terracotta
setblock 1 66 324 minecraft:yellow_terracotta
fill 1 66 325 1 69 325 minecraft:honeycomb_block
setblock 1 66 329 minecraft:yellow_terracotta
fill 1 66 330 1 69 330 minecraft:honeycomb_block
setblock 1 66 334 minecraft:yellow_terracotta
fill 1 66 335 1 69 335 minecraft:honeycomb_block
setblock 1 66 338 minecraft:honeycomb_block
setblock 1 66 339 minecraft:yellow_terracotta
fill 1 66 340 1 66 343 minecraft:honeycomb_block
setblock 1 66 344 minecraft:yellow_terracotta
fill 1 66 345 1 67 345 minecraft:honeycomb_block
setblock 1 66 348 minecraft:honeycomb_block
setblock 1 66 349 minecraft:yellow_terracotta
fill 1 66 350 1 69 350 minecraft:honeycomb_block
setblock 1 66 354 minecraft:yellow_terracotta
fill 1 66 355 1 69 355 minecraft:honeycomb_block
setblock 1 66 359 minecraft:yellow_terracotta
fill 1 66 360 1 68 361 minecraft:honeycomb_block
setblock 2 66 323 minecraft:yellow_terracotta
fill 2 66 324 2 68 324 minecraft:honeycomb_block
setblock 2 66 328 minecraft:yellow_terracotta
fill 2 66 329 2 68 329 minecraft:honeycomb_block
setblock 2 66 333 minecraft:yellow_terracotta
fill 2 66 334 2 69 334 minecraft:honeycomb_block
setblock 2 66 338 minecraft:yellow_terracotta
fill 2 66 339 2 69 339 minecraft:honeycomb_block
fill 2 66 349 2 67 349 minecraft:honeycomb_block
setblock 2 66 353 minecraft:yellow_terracotta
fill 2 66 354 2 69 354 minecraft:honeycomb_block
setblock 2 66 358 minecraft:yellow_terracotta
fill 2 66 359 2 69 359 minecraft:honeycomb_block
fill 2 66 361 3 66 361 minecraft:honeycomb_block
setblock 2 66 363 minecraft:yellow_terracotta
fill 3 66 323 3 69 323 minecraft:honeycomb_block
setblock 3 66 328 minecraft:honeycomb_block
setblock 3 66 332 minecraft:yellow_terracotta
fill 3 66 333 3 67 333 minecraft:honeycomb_block
setblock 3 66 352 minecraft:yellow_terracotta
fill 3 66 353 3 68 353 minecraft:honeycomb_block
setblock 3 66 357 minecraft:yellow_terracotta
fill 3 66 358 3 69 358 minecraft:honeycomb_block
setblock 3 66 362 minecraft:yellow_terracotta
fill 3 66 363 3 69 363 minecraft:honeycomb_block
setblock 4 66 356 minecraft:yellow_terracotta
fill 4 66 357 4 68 357 minecraft:honeycomb_block
setblock 4 66 361 minecraft:yellow_terracotta
fill 4 66 362 4 69 362 minecraft:honeycomb_block
fill 5 66 361 5 69 361 minecraft:honeycomb_block
setblock 7 66 323 minecraft:yellow_terracotta
setblock 7 66 363 minecraft:yellow_terracotta
setblock 8 66 362 minecraft:yellow_terracotta
fill 8 66 363 8 69 363 minecraft:honeycomb_block
setblock 12 66 363 minecraft:yellow_terracotta
fill 13 66 363 16 66 363 minecraft:honeycomb_block
setblock 14 66 322 minecraft:orange_terracotta
setblock 15 66 323 minecraft:honey_block
setblock 17 66 362 minecraft:honeycomb_block
setblock 17 66 363 minecraft:yellow_terracotta
setblock 18 66 362 minecraft:yellow_terracotta
fill 18 66 363 18 69 363 minecraft:honeycomb_block
fill 19 66 322 20 76 322 minecraft:honeycomb_block
fill 19 66 362 19 69 362 minecraft:honeycomb_block
setblock 21 66 322 minecraft:yellow_terracotta
setblock 21 66 323 minecraft:honeycomb_block
fill 22 66 322 22 78 322 minecraft:honeycomb_block
setblock 22 66 323 minecraft:yellow_terracotta
setblock 22 66 363 minecraft:yellow_terracotta
setblock 23 66 362 minecraft:yellow_terracotta
fill 23 66 363 23 69 363 minecraft:honeycomb_block
setblock 27 66 363 minecraft:honey_block
setblock 34 66 323 minecraft:honey_block
fill 34 66 330 34 66 331 minecraft:yellow_terracotta
fill 34 66 354 34 66 355 minecraft:yellow_terracotta
setblock 35 66 327 minecraft:honey_block
setblock 35 66 328 minecraft:yellow_terracotta
fill 35 66 331 35 67 332 minecraft:yellow_terracotta
fill 35 66 345 35 68 345 minecraft:brown_terracotta
fill 35 66 353 35 67 354 minecraft:yellow_terracotta
setblock 35 66 357 minecraft:yellow_terracotta
setblock 35 66 358 minecraft:honey_block
fill 36 66 330 36 66 331 minecraft:yellow_terracotta
fill 36 66 354 36 66 355 minecraft:yellow_terracotta
setblock 37 66 323 minecraft:yellow_terracotta
setblock 37 66 363 minecraft:yellow_terracotta
fill 38 66 323 38 69 323 minecraft:honeycomb_block
fill 38 66 330 38 66 331 minecraft:honeycomb_block
setblock 38 66 332 minecraft:yellow_terracotta
fill 38 66 333 38 69 333 minecraft:honeycomb_block
setblock 38 66 336 minecraft:honeycomb_block
fill 38 66 363 38 69 363 minecraft:honeycomb_block
setblock 39 66 326 minecraft:yellow_terracotta
fill 39 66 327 39 68 327 minecraft:honeycomb_block
setblock 39 66 331 minecraft:yellow_terracotta
fill 39 66 332 39 69 332 minecraft:honeycomb_block
setblock 39 66 335 minecraft:honeycomb_block
setblock 39 66 336 minecraft:yellow_terracotta
fill 39 66 337 39 69 337 minecraft:honeycomb_block
fill 39 66 339 39 67 339 minecraft:honeycomb_block
fill 39 66 362 40 68 362 minecraft:honeycomb_block
setblock 40 66 325 minecraft:yellow_terracotta
fill 40 66 326 40 69 326 minecraft:honeycomb_block
setblock 40 66 330 minecraft:yellow_terracotta
fill 40 66 331 40 69 331 minecraft:honeycomb_block
setblock 40 66 335 minecraft:yellow_terracotta
fill 40 66 336 40 69 336 minecraft:honeycomb_block
setblock 40 66 340 minecraft:yellow_terracotta
fill 40 66 341 40 69 341 minecraft:honeycomb_block
setblock 40 66 350 minecraft:yellow_terracotta
fill 40 66 351 40 67 351 minecraft:honeycomb_block
setblock 40 66 354 minecraft:honeycomb_block
setblock 40 66 355 minecraft:yellow_terracotta
fill 40 66 356 40 69 356 minecraft:honeycomb_block
setblock 40 66 359 minecraft:honeycomb_block
setblock 40 66 360 minecraft:yellow_terracotta
fill 40 66 361 40 69 361 minecraft:honeycomb_block
setblock 41 66 324 minecraft:yellow_terracotta
fill 41 66 325 41 69 325 minecraft:honeycomb_block
setblock 41 66 329 minecraft:yellow_terracotta
fill 41 66 330 41 69 330 minecraft:honeycomb_block
setblock 41 66 334 minecraft:yellow_terracotta
fill 41 66 335 41 69 335 minecraft:honeycomb_block
setblock 41 66 339 minecraft:yellow_terracotta
fill 41 66 340 41 69 340 minecraft:honeycomb_block
setblock 41 66 344 minecraft:yellow_terracotta
fill 41 66 345 41 68 345 minecraft:honeycomb_block
setblock 41 66 349 minecraft:yellow_terracotta
fill 41 66 350 41 69 350 minecraft:honeycomb_block
setblock 41 66 354 minecraft:yellow_terracotta
fill 41 66 355 41 69 355 minecraft:honeycomb_block
setblock 41 66 359 minecraft:yellow_terracotta
fill 41 66 360 41 69 360 minecraft:honeycomb_block
fill 0 67 341 1 68 341 minecraft:honeycomb_block
fill 0 67 362 0 92 362 minecraft:honeycomb_block
fill 1 67 322 4 77 322 minecraft:honeycomb_block
setblock 1 67 323 minecraft:yellow_terracotta
fill 1 67 324 1 70 324 minecraft:honeycomb_block
setblock 1 67 328 minecraft:yellow_terracotta
fill 1 67 329 1 70 329 minecraft:honeycomb_block
setblock 1 67 333 minecraft:yellow_terracotta
fill 1 67 334 1 70 334 minecraft:honeycomb_block
setblock 1 67 338 minecraft:yellow_terracotta
fill 1 67 339 1 69 340 minecraft:honeycomb_block
setblock 1 67 342 minecraft:honeycomb_block
setblock 1 67 343 minecraft:yellow_terracotta
setblock 1 67 344 minecraft:honeycomb_block
setblock 1 67 348 minecraft:yellow_terracotta
fill 1 67 349 1 69 349 minecraft:honeycomb_block
setblock 1 67 353 minecraft:yellow_terracotta
fill 1 67 354 1 70 354 minecraft:honeycomb_block
setblock 1 67 358 minecraft:yellow_terracotta
fill 1 67 359 1 70 359 minecraft:honeycomb_block
setblock 1 67 363 minecraft:yellow_terracotta
fill 2 67 323 2 70 323 minecraft:honeycomb_block
setblock 2 67 327 minecraft:yellow_terracotta
fill 2 67 328 2 68 328 minecraft:honeycomb_block
setblock 2 67 332 minecraft:yellow_terracotta
fill 2 67 333 2 69 333 minecraft:honeycomb_block
setblock 2 67 337 minecraft:yellow_terracotta
fill 2 67 338 2 69 338 minecraft:honeycomb_block
setblock 2 67 352 minecraft:yellow_terracotta
fill 2 67 353 2 70 353 minecraft:honeycomb_block
setblock 2 67 357 minecraft:yellow_terracotta
fill 2 67 358 2 70 358 minecraft:honeycomb_block
setblock 2 67 361 minecraft:honeycomb_block
setblock 2 67 362 minecraft:yellow_terracotta
fill 2 67 363 2 70 363 minecraft:honeycomb_block
setblock 3 67 331 minecraft:yellow_terracotta
setblock 3 67 332 minecraft:honeycomb_block
setblock 3 67 352 minecraft:honeycomb_block
setblock 3 67 355 minecraft:honeycomb_block
setblock 3 67 356 minecraft:yellow_terracotta
fill 3 67 357 3 70 357 minecraft:honeycomb_block
setblock 3 67 361 minecraft:yellow_terracotta
fill 3 67 362 3 70 362 minecraft:honeycomb_block
fill 4 67 338 4 69 338 minecraft:brown_terracotta
setblock 4 67 355 minecraft:yellow_terracotta
fill 4 67 356 4 68 356 minecraft:honeycomb_block
setblock 4 67 360 minecraft:yellow_terracotta
fill 4 67 361 4 70 361 minecraft:honeycomb_block
setblock 5 67 322 minecraft:yellow_terracotta
fill 5 67 337 5 69 337 minecraft:brown_terracotta
fill 5 67 339 5 69 339 minecraft:brown_terracotta
fill 6 67 322 8 69 322 minecraft:honeycomb_block
setblock 6 67 323 minecraft:yellow_terracotta
fill 6 67 338 6 69 338 minecraft:brown_terracotta
setblock 6 67 363 minecraft:yellow_terracotta
setblock 7 67 362 minecraft:yellow_terracotta
fill 7 67 363 7 70 363 minecraft:honeycomb_block
fill 8 67 362 8 68 362 minecraft:honeycomb_block
setblock 9 67 323 minecraft:honey_block
setblock 11 67 363 minecraft:yellow_terracotta
fill 12 67 363 15 67 363 minecraft:honeycomb_block
fill 14 67 322 14 82 322 minecraft:honeycomb_block
setblock 16 67 362 minecraft:honeycomb_block
setblock 16 67 363 minecraft:yellow_terracotta
setblock 17 67 362 minecraft:yellow_terracotta
fill 17 67 363 17 70 363 minecraft:honeycomb_block
fill 18 67 362 18 70 362 minecraft:honeycomb_block
fill 19 67 361 20 68 361 minecraft:honeycomb_block
fill 20 67 362 21 67 362 minecraft:honeycomb_block
fill 21 67 322 21 126 322 minecraft:honeycomb_block
setblock 21 67 363 minecraft:yellow_terracotta
setblock 22 67 362 minecraft:yellow_terracotta
fill 22 67 363 22 70 363 minecraft:honeycomb_block
setblock 28 67 323 minecraft:honey_block
fill 30 67 364 30 100 364 minecraft:honeycomb_block
setblock 31 67 364 minecraft:yellow_concrete
setblock 33 67 363 minecraft:honey_block
fill 34 67 331 34 67 333 minecraft:yellow_terracotta
fill 34 67 352 34 67 354 minecraft:yellow_terracotta
setblock 35 67 323 minecraft:honeycomb_block
setblock 35 67 329 minecraft:honey_block
fill 35 67 333 35 69 334 minecraft:yellow_terracotta
fill 35 67 344 36 68 344 minecraft:brown_terracotta
fill 35 67 346 36 68 346 minecraft:brown_terracotta
fill 35 67 351 35 69 352 minecraft:yellow_terracotta
setblock 35 67 356 minecraft:honey_block
setblock 36 67 323 minecraft:yellow_terracotta
fill 36 67 331 36 67 333 minecraft:yellow_terracotta
fill 36 67 352 36 67 354 minecraft:yellow_terracotta
fill 37 67 323 37 69 324 minecraft:honeycomb_block
fill 37 67 345 37 75 345 minecraft:brown_terracotta
fill 37 67 363 37 70 363 minecraft:honeycomb_block
setblock 38 67 330 minecraft:honeycomb_block
setblock 38 67 331 minecraft:yellow_terracotta
fill 38 67 332 38 69 332 minecraft:honeycomb_block
setblock 38 67 336 minecraft:yellow_terracotta
fill 38 67 337 38 69 337 minecraft:honeycomb_block
fill 38 67 362 38 70 362 minecraft:honeycomb_block
fill 39 67 326 39 68 326 minecraft:honeycomb_block
setblock 39 67 330 minecraft:yellow_terracotta
fill 39 67 331 39 70 331 minecraft:honeycomb_block
setblock 39 67 335 minecraft:yellow_terracotta
fill 39 67 336 39 70 336 minecraft:honeycomb_block
fill 39 67 356 39 68 358 minecraft:honeycomb_block
setblock 40 67 324 minecraft:yellow_terracotta
fill 40 67 325 40 70 325 minecraft:honeycomb_block
setblock 40 67 329 minecraft:yellow_terracotta
fill 40 67 330 40 70 330 minecraft:honeycomb_block
setblock 40 67 334 minecraft:yellow_terracotta
fill 40 67 335 40 70 335 minecraft:honeycomb_block
setblock 40 67 339 minecraft:yellow_terracotta
fill 40 67 340 40 70 340 minecraft:honeycomb_block
fill 40 67 342 40 68 342 minecraft:honeycomb_block
setblock 40 67 354 minecraft:yellow_terracotta
fill 40 67 355 40 70 355 minecraft:honeycomb_block
setblock 40 67 359 minecraft:yellow_terracotta
fill 40 67 360 40 70 360 minecraft:honeycomb_block
setblock 41 67 323 minecraft:yellow_terracotta
fill 41 67 324 41 70 324 minecraft:honeycomb_block
setblock 41 67 328 minecraft:yellow_terracotta
fill 41 67 329 41 70 329 minecraft:honeycomb_block
setblock 41 67 333 minecraft:yellow_terracotta
fill 41 67 334 41 70 334 minecraft:honeycomb_block
setblock 41 67 338 minecraft:yellow_terracotta
fill 41 67 339 41 70 339 minecraft:honeycomb_block
setblock 41 67 343 minecraft:yellow_terracotta
fill 41 67 344 41 69 344 minecraft:honeycomb_block
setblock 41 67 348 minecraft:yellow_terracotta
fill 41 67 349 41 68 349 minecraft:honeycomb_block
setblock 41 67 353 minecraft:yellow_terracotta
fill 41 67 354 41 70 354 minecraft:honeycomb_block
setblock 41 67 358 minecraft:yellow_terracotta
fill 41 67 359 41 70 359 minecraft:honeycomb_block
setblock 41 67 363 minecraft:yellow_terracotta
fill 0 68 357 0 158 357 minecraft:honeycomb_block
fill 1 68 323 1 71 323 minecraft:honeycomb_block
setblock 1 68 327 minecraft:yellow_terracotta
fill 1 68 328 1 70 328 minecraft:honeycomb_block
setblock 1 68 332 minecraft:yellow_terracotta
fill 1 68 333 1 71 333 minecraft:honeycomb_block
setblock 1 68 337 minecraft:yellow_terracotta
fill 1 68 338 1 71 338 minecraft:honeycomb_block
setblock 1 68 342 minecraft:yellow_terracotta
fill 1 68 343 1 69 343 minecraft:honeycomb_block
setblock 1 68 347 minecraft:yellow_terracotta
fill 1 68 348 1 69 348 minecraft:honeycomb_block
setblock 1 68 352 minecraft:yellow_terracotta
fill 1 68 353 1 71 353 minecraft:honeycomb_block
setblock 1 68 357 minecraft:yellow_terracotta
fill 1 68 358 1 71 358 minecraft:honeycomb_block
setblock 1 68 362 minecraft:yellow_terracotta
fill 1 68 363 1 71 363 minecraft:honeycomb_block
setblock 2 68 326 minecraft:yellow_terracotta
setblock 2 68 327 minecraft:honeycomb_block
setblock 2 68 331 minecraft:yellow_terracotta
fill 2 68 332 2 69 332 minecraft:honeycomb_block
setblock 2 68 336 minecraft:yellow_terracotta
fill 2 68 337 2 70 337 minecraft:honeycomb_block
fill 2 68 346 2 73 346 minecraft:brown_terracotta
setblock 2 68 351 minecraft:yellow_terracotta
fill 2 68 352 2 70 352 minecraft:honeycomb_block
setblock 2 68 356 minecraft:yellow_terracotta
fill 2 68 357 2 71 357 minecraft:honeycomb_block
setblock 2 68 361 minecraft:yellow_terracotta
fill 2 68 362 2 71 362 minecraft:honeycomb_block
setblock 3 68 325 minecraft:light[level=12]
setblock 3 68 332 minecraft:light[level=12]
setblock 3 68 339 minecraft:light[level=12]
setblock 3 68 346 minecraft:light[level=12]
setblock 3 68 355 minecraft:yellow_terracotta
fill 3 68 356 3 70 356 minecraft:honeycomb_block
setblock 3 68 359 minecraft:honeycomb_block
setblock 3 68 360 minecraft:yellow_terracotta
fill 3 68 361 3 71 361 minecraft:honeycomb_block
fill 4 68 337 4 69 337 minecraft:brown_terracotta
fill 4 68 339 4 69 339 minecraft:brown_terracotta
setblock 4 68 359 minecraft:yellow_terracotta
fill 5 68 322 5 110 322 minecraft:honeycomb_block
setblock 5 68 323 minecraft:yellow_terracotta
setblock 5 68 363 minecraft:yellow_terracotta
fill 6 68 337 6 69 337 minecraft:brown_terracotta
fill 6 68 339 6 69 339 minecraft:brown_terracotta
setblock 6 68 362 minecraft:yellow_terracotta
fill 6 68 363 6 71 363 minecraft:honeycomb_block
fill 7 68 362 7 70 362 minecraft:honeycomb_block
setblock 9 68 322 minecraft:yellow_concrete
setblock 10 68 325 minecraft:light[level=12]
setblock 10 68 332 minecraft:light[level=12]
setblock 10 68 339 minecraft:light[level=12]
setblock 10 68 346 minecraft:light[level=12]
setblock 10 68 353 minecraft:light[level=12]
setblock 10 68 360 minecraft:light[level=12]
setblock 10 68 363 minecraft:yellow_terracotta
fill 11 68 363 14 68 363 minecraft:honeycomb_block
setblock 15 68 362 minecraft:honeycomb_block
setblock 15 68 363 minecraft:yellow_terracotta
setblock 16 68 362 minecraft:yellow_terracotta
fill 16 68 363 16 71 363 minecraft:honeycomb_block
setblock 17 68 325 minecraft:light[level=12]
setblock 17 68 332 minecraft:light[level=12]
setblock 17 68 339 minecraft:light[level=12]
setblock 17 68 346 minecraft:light[level=12]
setblock 17 68 353 minecraft:light[level=12]
setblock 17 68 360 minecraft:light[level=12]
fill 17 68 362 17 71 362 minecraft:honeycomb_block
fill 18 68 361 18 69 361 minecraft:honeycomb_block
setblock 20 68 362 minecraft:honeycomb_block
setblock 20 68 363 minecraft:yellow_terracotta
setblock 21 68 362 minecraft:yellow_terracotta
fill 21 68 363 21 71 363 minecraft:honeycomb_block
setblock 22 68 323 minecraft:honey_block
fill 22 68 362 22 69 362 minecraft:honeycomb_block
setblock 24 68 325 minecraft:light[level=12]
setblock 24 68 332 minecraft:light[level=12]
setblock 24 68 346 minecraft:light[level=12]
setblock 24 68 353 minecraft:light[level=12]
setblock 24 68 360 minecraft:light[level=12]
setblock 31 68 325 minecraft:light[level=12]
setblock 31 68 332 minecraft:light[level=12]
setblock 31 68 339 minecraft:light[level=12]
setblock 31 68 346 minecraft:light[level=12]
setblock 31 68 353 minecraft:light[level=12]
setblock 31 68 360 minecraft:light[level=12]
fill 31 68 364 31 161 364 minecraft:honeycomb_block
fill 32 68 340 32 69 340 minecraft:ochre_froglight
fill 34 68 333 34 68 335 minecraft:yellow_terracotta
fill 34 68 345 34 69 345 minecraft:brown_terracotta
fill 34 68 350 34 68 352 minecraft:yellow_terracotta
setblock 35 68 323 minecraft:yellow_terracotta
fill 35 68 330 35 68 331 minecraft:honey_block
setblock 35 68 332 minecraft:yellow_terracotta
fill 35 68 335 35 70 336 minecraft:yellow_terracotta
fill 35 68 349 35 70 350 minecraft:yellow_terracotta
setblock 35 68 353 minecraft:yellow_terracotta
fill 35 68 354 35 68 355 minecraft:honey_block
fill 36 68 323 36 71 323 minecraft:honeycomb_block
fill 36 68 333 36 68 335 minecraft:yellow_terracotta
fill 36 68 350 36 68 352 minecraft:yellow_terracotta
fill 36 68 363 36 71 363 minecraft:honeycomb_block
fill 37 68 344 37 75 344 minecraft:brown_terracotta
fill 37 68 346 37 75 346 minecraft:brown_terracotta
setblock 38 68 325 minecraft:light[level=12]
setblock 38 68 331 minecraft:honeycomb_block
setblock 38 68 334 minecraft:honeycomb_block
setblock 38 68 335 minecraft:yellow_terracotta
fill 38 68 336 38 69 336 minecraft:honeycomb_block
setblock 38 68 339 minecraft:light[level=12]
setblock 38 68 346 minecraft:light[level=12]
setblock 38 68 353 minecraft:light[level=12]
setblock 38 68 360 minecraft:light[level=12]
setblock 39 68 324 minecraft:yellow_terracotta
setblock 39 68 329 minecraft:yellow_terracotta
fill 39 68 330 39 70 330 minecraft:honeycomb_block
setblock 39 68 334 minecraft:yellow_terracotta
fill 39 68 335 39 71 335 minecraft:honeycomb_block
setblock 39 68 339 minecraft:yellow_terracotta
setblock 39 68 359 minecraft:yellow_terracotta
setblock 40 68 323 minecraft:yellow_terracotta
fill 40 68 324 40 71 324 minecraft:honeycomb_block
setblock 40 68 328 minecraft:yellow_terracotta
fill 40 68 329 40 71 329 minecraft:honeycomb_block
setblock 40 68 333 minecraft:yellow_terracotta
fill 40 68 334 40 71 334 minecraft:honeycomb_block
setblock 40 68 338 minecraft:yellow_terracotta
fill 40 68 339 40 71 339 minecraft:honeycomb_block
setblock 40 68 353 minecraft:yellow_terracotta
fill 40 68 354 40 70 354 minecraft:honeycomb_block
setblock 40 68 358 minecraft:yellow_terracotta
fill 40 68 359 40 71 359 minecraft:honeycomb_block
setblock 40 68 363 minecraft:yellow_terracotta
fill 41 68 323 41 71 323 minecraft:honeycomb_block
setblock 41 68 327 minecraft:yellow_terracotta
fill 41 68 328 41 71 328 minecraft:honeycomb_block
setblock 41 68 332 minecraft:yellow_terracotta
fill 41 68 333 41 71 333 minecraft:honeycomb_block
setblock 41 68 337 minecraft:yellow_terracotta
fill 41 68 338 41 71 338 minecraft:honeycomb_block
setblock 41 68 342 minecraft:yellow_terracotta
fill 41 68 343 41 71 343 minecraft:honeycomb_block
setblock 41 68 348 minecraft:honeycomb_block
setblock 41 68 352 minecraft:yellow_terracotta
fill 41 68 353 41 71 353 minecraft:honeycomb_block
setblock 41 68 357 minecraft:yellow_terracotta
fill 41 68 358 41 71 358 minecraft:honeycomb_block
setblock 41 68 362 minecraft:yellow_terracotta
fill 41 68 363 41 71 363 minecraft:honeycomb_block
fill 0 69 341 0 136 341 minecraft:honeycomb_block
setblock 1 69 326 minecraft:yellow_terracotta
fill 1 69 327 1 70 327 minecraft:honeycomb_block
setblock 1 69 331 minecraft:yellow_terracotta
fill 1 69 332 1 71 332 minecraft:honeycomb_block
setblock 1 69 336 minecraft:yellow_terracotta
fill 1 69 337 1 72 337 minecraft:honeycomb_block
setblock 1 69 341 minecraft:yellow_terracotta
fill 1 69 342 1 72 342 minecraft:honeycomb_block
setblock 1 69 344 minecraft:honey_block
setblock 1 69 351 minecraft:yellow_terracotta
fill 1 69 352 1 72 352 minecraft:honeycomb_block
setblock 1 69 356 minecraft:yellow_terracotta
fill 1 69 357 1 72 357 minecraft:honeycomb_block
setblock 1 69 360 minecraft:honeycomb_block
setblock 1 69 361 minecraft:yellow_terracotta
fill 1 69 362 1 72 362 minecraft:honeycomb_block
setblock 2 69 330 minecraft:yellow_terracotta
setblock 2 69 331 minecraft:honeycomb_block
setblock 2 69 335 minecraft:yellow_terracotta
fill 2 69 336 2 70 336 minecraft:honeycomb_block
setblock 2 69 351 minecraft:honeycomb_block
setblock 2 69 355 minecraft:yellow_terracotta
fill 2 69 356 2 72 356 minecraft:honeycomb_block
setblock 2 69 360 minecraft:yellow_terracotta
fill 2 69 361 2 72 361 minecraft:honeycomb_block
setblock 3 69 354 minecraft:yellow_terracotta
fill 3 69 355 3 70 355 minecraft:honeycomb_block
setblock 3 69 359 minecraft:yellow_terracotta
fill 3 69 360 3 72 360 minecraft:honeycomb_block
setblock 4 69 323 minecraft:yellow_terracotta
setblock 4 69 363 minecraft:yellow_terracotta
setblock 5 69 362 minecraft:yellow_terracotta
fill 5 69 363 5 72 363 minecraft:honeycomb_block
fill 6 69 362 6 71 362 minecraft:honeycomb_block
fill 9 69 322 9 80 322 minecraft:honeycomb_block
setblock 9 69 363 minecraft:yellow_terracotta
fill 10 69 363 13 69 363 minecraft:honeycomb_block
setblock 14 69 362 minecraft:honeycomb_block
setblock 14 69 363 minecraft:yellow_terracotta
setblock 15 69 362 minecraft:yellow_terracotta
fill 15 69 363 15 72 363 minecraft:honeycomb_block
setblock 16 69 323 minecraft:honey_block
fill 16 69 362 16 72 362 minecraft:honeycomb_block
setblock 19 69 361 minecraft:honeycomb_block
setblock 19 69 363 minecraft:yellow_terracotta
setblock 20 69 362 minecraft:yellow_terracotta
fill 20 69 363 20 72 363 minecraft:honeycomb_block
fill 21 69 362 21 70 362 minecraft:honeycomb_block
setblock 26 69 363 minecraft:honey_block
fill 34 69 334 34 69 338 minecraft:yellow_terracotta
setblock 34 69 344 minecraft:brown_terracotta
setblock 34 69 346 minecraft:brown_terracotta
fill 34 69 347 34 69 351 minecraft:yellow_terracotta
fill 35 69 323 35 72 323 minecraft:honeycomb_block
setblock 35 69 332 minecraft:honey_block
fill 35 69 337 35 70 341 minecraft:yellow_terracotta
fill 35 69 343 37 69 343 minecraft:brown_terracotta
fill 35 69 344 35 70 348 minecraft:yellow_terracotta
setblock 35 69 353 minecraft:honey_block
fill 35 69 363 35 72 363 minecraft:honeycomb_block
fill 36 69 334 36 69 338 minecraft:yellow_terracotta
setblock 36 69 344 minecraft:brown_terracotta
setblock 36 69 346 minecraft:brown_terracotta
fill 36 69 347 36 69 351 minecraft:yellow_terracotta
fill 37 69 362 37 71 362 minecraft:honeycomb_block
setblock 38 69 324 minecraft:yellow_terracotta
setblock 38 69 334 minecraft:yellow_terracotta
fill 38 69 335 38 70 335 minecraft:honeycomb_block
fill 38 69 345 38 75 345 minecraft:brown_terracotta
setblock 39 69 323 minecraft:yellow_terracotta
fill 39 69 324 39 72 324 minecraft:honeycomb_block
setblock 39 69 328 minecraft:yellow_terracotta
setblock 39 69 329 minecraft:honeycomb_block
setblock 39 69 333 minecraft:yellow_terracotta
fill 39 69 334 39 72 334 minecraft:honeycomb_block
setblock 39 69 338 minecraft:yellow_terracotta
fill 39 69 339 39 71 339 minecraft:honeycomb_block
setblock 39 69 357 minecraft:honeycomb_block
setblock 39 69 358 minecraft:yellow_terracotta
fill 39 69 359 39 71 360 minecraft:honeycomb_block
setblock 39 69 362 minecraft:honeycomb_block
setblock 39 69 363 minecraft:yellow_terracotta
fill 40 69 323 40 72 323 minecraft:honeycomb_block
setblock 40 69 327 minecraft:yellow_terracotta
fill 40 69 328 40 71 328 minecraft:honeycomb_block
setblock 40 69 332 minecraft:yellow_terracotta
fill 40 69 333 40 72 333 minecraft:honeycomb_block
setblock 40 69 337 minecraft:yellow_terracotta
fill 40 69 338 40 72 338 minecraft:honeycomb_block
setblock 40 69 353 minecraft:honeycomb_block
setblock 40 69 357 minecraft:yellow_terracotta
fill 40 69 358 40 72 358 minecraft:honeycomb_block
setblock 40 69 362 minecraft:yellow_terracotta
fill 40 69 363 40 72 363 minecraft:honeycomb_block
setblock 41 69 326 minecraft:yellow_terracotta
fill 41 69 327 41 72 327 minecraft:honeycomb_block
setblock 41 69 331 minecraft:yellow_terracotta
fill 41 69 332 41 72 332 minecraft:honeycomb_block
setblock 41 69 336 minecraft:yellow_terracotta
fill 41 69 337 41 72 337 minecraft:honeycomb_block
setblock 41 69 341 minecraft:yellow_terracotta
fill 41 69 342 41 72 342 minecraft:honeycomb_block
setblock 41 69 351 minecraft:yellow_terracotta
fill 41 69 352 41 70 352 minecraft:honeycomb_block
setblock 41 69 356 minecraft:yellow_terracotta
fill 41 69 357 42 72 357 minecraft:honeycomb_block
setblock 41 69 361 minecraft:yellow_terracotta
fill 41 69 362 41 72 362 minecraft:honeycomb_block
fill 42 69 358 42 130 358 minecraft:honeycomb_block
setblock 42 69 359 minecraft:yellow_concrete
fill 42 69 360 42 106 360 minecraft:honeycomb_block
setblock 0 70 332 minecraft:yellow_terracotta
setblock 1 70 325 minecraft:yellow_terracotta
fill 1 70 326 1 71 326 minecraft:honeycomb_block
setblock 1 70 330 minecraft:yellow_terracotta
fill 1 70 331 1 71 331 minecraft:honeycomb_block
setblock 1 70 335 minecraft:yellow_terracotta
fill 1 70 336 1 73 336 minecraft:honeycomb_block
setblock 1 70 339 minecraft:honeycomb_block
setblock 1 70 340 minecraft:yellow_terracotta
fill 1 70 341 1 73 341 minecraft:honeycomb_block
setblock 1 70 350 minecraft:yellow_terracotta
fill 1 70 351 1 71 351 minecraft:honeycomb_block
setblock 1 70 355 minecraft:yellow_terracotta
fill 1 70 356 1 73 356 minecraft:honeycomb_block
setblock 1 70 360 minecraft:yellow_terracotta
fill 1 70 361 1 73 361 minecraft:honeycomb_block
setblock 2 70 334 minecraft:yellow_terracotta
setblock 2 70 335 minecraft:honeycomb_block
setblock 2 70 354 minecraft:yellow_terracotta
fill 2 70 355 2 72 355 minecraft:honeycomb_block
setblock 2 70 359 minecraft:yellow_terracotta
fill 2 70 360 2 73 360 minecraft:honeycomb_block
setblock 3 70 323 minecraft:yellow_terracotta
setblock 3 70 358 minecraft:yellow_terracotta
fill 3 70 359 3 72 359 minecraft:honeycomb_block
setblock 3 70 363 minecraft:yellow_terracotta
setblock 4 70 362 minecraft:yellow_terracotta
fill 4 70 363 4 73 363 minecraft:honeycomb_block
fill 5 70 362 5 73 362 minecraft:honeycomb_block
setblock 5 70 364 minecraft:yellow_concrete
fill 6 70 322 7 81 322 minecraft:honeycomb_block
setblock 8 70 322 minecraft:orange_terracotta
setblock 8 70 363 minecraft:yellow_terracotta
fill 9 70 363 12 70 363 minecraft:honeycomb_block
setblock 10 70 323 minecraft:honey_block
setblock 13 70 363 minecraft:yellow_terracotta
fill 14 70 353 15 71 353 minecraft:yellow_concrete
setblock 14 70 362 minecraft:yellow_terracotta
fill 14 70 363 14 73 363 minecraft:honeycomb_block
fill 15 70 362 15 73 362 minecraft:honeycomb_block
setblock 17 70 364 minecraft:orange_terracotta
setblock 18 70 363 minecraft:yellow_terracotta
setblock 19 70 362 minecraft:yellow_terracotta
fill 19 70 363 19 73 363 minecraft:honeycomb_block
fill 20 70 362 20 72 362 minecraft:honeycomb_block
setblock 23 70 363 minecraft:yellow_terracotta
fill 32 70 340 32 79 340 minecraft:brown_terracotta
setblock 32 70 363 minecraft:honey_block
fill 33 70 345 33 75 345 minecraft:brown_terracotta
fill 34 70 323 34 73 323 minecraft:honeycomb_block
fill 34 70 337 34 70 348 minecraft:yellow_terracotta
setblock 35 70 334 minecraft:honey_block
fill 35 70 342 36 71 343 minecraft:yellow_terracotta
setblock 35 70 351 minecraft:honey_block
fill 36 70 337 36 70 341 minecraft:yellow_terracotta
fill 36 70 344 36 70 348 minecraft:yellow_terracotta
setblock 37 70 323 minecraft:honeycomb_block
setblock 37 70 324 minecraft:yellow_terracotta
fill 37 70 343 37 75 343 minecraft:brown_terracotta
fill 37 70 347 37 75 347 minecraft:brown_terracotta
setblock 38 70 323 minecraft:yellow_terracotta
fill 38 70 324 38 73 324 minecraft:honeycomb_block
fill 38 70 344 38 75 344 minecraft:brown_terracotta
fill 38 70 346 38 75 346 minecraft:brown_terracotta
setblock 38 70 363 minecraft:yellow_terracotta
fill 39 70 323 39 73 323 minecraft:honeycomb_block
setblock 39 70 332 minecraft:yellow_terracotta
fill 39 70 333 39 71 333 minecraft:honeycomb_block
setblock 39 70 337 minecraft:yellow_terracotta
fill 39 70 338 39 72 338 minecraft:honeycomb_block
setblock 39 70 358 minecraft:honeycomb_block
setblock 39 70 361 minecraft:honeycomb_block
setblock 39 70 362 minecraft:yellow_terracotta
fill 39 70 363 39 73 363 minecraft:honeycomb_block
setblock 40 70 326 minecraft:yellow_terracotta
fill 40 70 327 40 71 327 minecraft:honeycomb_block
setblock 40 70 331 minecraft:yellow_terracotta
fill 40 70 332 40 72 332 minecraft:honeycomb_block
setblock 40 70 336 minecraft:yellow_terracotta
fill 40 70 337 40 73 337 minecraft:honeycomb_block
setblock 40 70 341 minecraft:yellow_terracotta
setblock 40 70 356 minecraft:yellow_terracotta
fill 40 70 357 40 73 357 minecraft:honeycomb_block
setblock 40 70 361 minecraft:yellow_terracotta
fill 40 70 362 40 73 362 minecraft:honeycomb_block
setblock 41 70 325 minecraft:yellow_terracotta
fill 41 70 326 41 73 326 minecraft:honeycomb_block
setblock 41 70 330 minecraft:yellow_terracotta
fill 41 70 331 41 73 331 minecraft:honeycomb_block
setblock 41 70 335 minecraft:yellow_terracotta
fill 41 70 336 41 73 336 minecraft:honeycomb_block
setblock 41 70 340 minecraft:yellow_terracotta
fill 41 70 341 41 73 341 minecraft:honeycomb_block
setblock 41 70 355 minecraft:yellow_terracotta
fill 41 70 356 41 73 356 minecraft:honeycomb_block
setblock 41 70 360 minecraft:yellow_terracotta
fill 41 70 361 41 73 361 minecraft:honeycomb_block
fill 42 70 359 42 130 359 minecraft:honeycomb_block
fill 0 71 332 0 212 332 minecraft:honeycomb_block
fill 0 71 335 0 146 338 minecraft:honeycomb_block
setblock 0 71 339 minecraft:yellow_concrete
fill 0 71 340 1 74 340 minecraft:honeycomb_block
setblock 0 71 353 minecraft:yellow_concrete
setblock 1 71 324 minecraft:yellow_terracotta
fill 1 71 325 1 72 325 minecraft:honeycomb_block
setblock 1 71 330 minecraft:honeycomb_block
setblock 1 71 334 minecraft:yellow_terracotta
fill 1 71 335 1 73 335 minecraft:honeycomb_block
setblock 1 71 339 minecraft:yellow_terracotta
setblock 1 71 354 minecraft:yellow_terracotta
fill 1 71 355 1 74 355 minecraft:honeycomb_block
setblock 1 71 359 minecraft:yellow_terracotta
fill 1 71 360 1 74 360 minecraft:honeycomb_block
setblock 2 71 323 minecraft:yellow_terracotta
setblock 2 71 354 minecraft:honeycomb_block
setblock 2 71 358 minecraft:yellow_terracotta
fill 2 71 359 2 74 359 minecraft:honeycomb_block
setblock 2 71 363 minecraft:yellow_terracotta
setblock 3 71 323 minecraft:honeycomb_block
setblock 3 71 357 minecraft:yellow_terracotta
fill 3 71 358 3 72 358 minecraft:honeycomb_block
setblock 3 71 362 minecraft:yellow_terracotta
fill 3 71 363 3 74 363 minecraft:honeycomb_block
setblock 4 71 323 minecraft:honey_block
setblock 4 71 361 minecraft:yellow_terracotta
fill 4 71 362 4 74 362 minecraft:honeycomb_block
fill 5 71 364 5 239 364 minecraft:honeycomb_block
setblock 7 71 363 minecraft:yellow_terracotta
fill 8 71 322 8 308 322 minecraft:honeycomb_block
fill 8 71 363 11 71 363 minecraft:honeycomb_block
setblock 12 71 363 minecraft:yellow_terracotta
fill 13 71 363 13 74 363 minecraft:honeycomb_block
fill 14 71 362 14 74 362 minecraft:honeycomb_block
setblock 17 71 363 minecraft:yellow_terracotta
fill 17 71 364 17 120 364 minecraft:honeycomb_block
schedule function dropper:buildpart/72_2 1t
