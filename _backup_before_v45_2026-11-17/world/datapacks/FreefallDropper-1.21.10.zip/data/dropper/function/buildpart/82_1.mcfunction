setblock 489 124 333 minecraft:light[level=14]
setblock 489 124 341 minecraft:light[level=14]
setblock 489 124 349 minecraft:light[level=14]
setblock 489 124 357 minecraft:light[level=14]
setblock 497 124 325 minecraft:light[level=14]
setblock 497 124 333 minecraft:light[level=14]
setblock 497 124 341 minecraft:light[level=14]
setblock 497 124 357 minecraft:light[level=14]
setblock 505 124 325 minecraft:light[level=14]
setblock 505 124 333 minecraft:light[level=14]
setblock 505 124 341 minecraft:light[level=14]
setblock 505 124 349 minecraft:light[level=14]
setblock 505 124 357 minecraft:light[level=14]
fill 471 126 323 471 127 328 minecraft:black_concrete
fill 471 126 331 472 126 336 minecraft:black_concrete
fill 471 126 339 472 126 344 minecraft:black_concrete
fill 471 126 347 472 126 352 minecraft:black_concrete
fill 471 126 355 472 126 360 minecraft:black_concrete
fill 471 126 363 476 127 363 minecraft:black_concrete
fill 472 126 324 472 126 330 minecraft:black_concrete
fill 472 126 337 472 126 338 minecraft:black_concrete
fill 472 126 345 472 126 346 minecraft:black_concrete
fill 472 126 353 472 126 354 minecraft:black_concrete
fill 472 126 361 472 126 362 minecraft:black_concrete
fill 473 126 324 510 126 324 minecraft:black_concrete
fill 473 126 362 511 126 362 minecraft:black_concrete
fill 474 126 323 479 127 323 minecraft:black_concrete
fill 479 126 363 484 127 363 minecraft:black_concrete
fill 482 126 323 487 127 323 minecraft:black_concrete
fill 487 126 363 492 127 363 minecraft:black_concrete
fill 490 126 323 495 127 323 minecraft:black_concrete
fill 495 126 363 500 127 363 minecraft:black_concrete
fill 498 126 323 503 127 323 minecraft:black_concrete
fill 503 126 363 508 127 363 minecraft:black_concrete
fill 506 126 323 511 127 323 minecraft:black_concrete
fill 510 126 325 510 126 361 minecraft:black_concrete
fill 511 126 326 511 127 331 minecraft:black_concrete
fill 511 126 334 511 127 339 minecraft:black_concrete
fill 511 126 342 511 127 347 minecraft:black_concrete
fill 511 126 350 511 127 355 minecraft:black_concrete
fill 511 126 358 511 127 361 minecraft:black_concrete
fill 511 126 363 511 127 363 minecraft:black_concrete
fill 471 127 331 471 127 336 minecraft:black_concrete
fill 471 127 339 471 127 344 minecraft:black_concrete
fill 471 127 347 471 127 352 minecraft:black_concrete
fill 471 127 355 471 127 360 minecraft:black_concrete
setblock 511 127 362 minecraft:black_concrete
fill 470 130 327 470 135 327 minecraft:sea_lantern
fill 470 130 335 470 135 335 minecraft:sea_lantern
fill 470 130 343 470 135 343 minecraft:sea_lantern
fill 470 130 351 470 135 351 minecraft:sea_lantern
fill 470 130 359 470 135 359 minecraft:sea_lantern
fill 473 130 364 473 135 364 minecraft:sea_lantern
fill 477 130 322 477 135 322 minecraft:sea_lantern
fill 481 130 364 481 135 364 minecraft:sea_lantern
fill 485 130 322 485 135 322 minecraft:sea_lantern
fill 489 130 364 489 135 364 minecraft:sea_lantern
fill 493 130 322 493 135 322 minecraft:sea_lantern
fill 497 130 364 497 135 364 minecraft:sea_lantern
fill 501 130 322 501 135 322 minecraft:sea_lantern
fill 505 130 364 505 135 364 minecraft:sea_lantern
fill 509 130 322 509 135 322 minecraft:sea_lantern
fill 512 130 327 512 135 327 minecraft:sea_lantern
fill 512 130 335 512 135 335 minecraft:sea_lantern
fill 512 130 343 512 135 343 minecraft:sea_lantern
fill 512 130 351 512 135 351 minecraft:sea_lantern
fill 512 130 359 512 135 359 minecraft:sea_lantern
fill 471 132 332 473 133 332 minecraft:iron_block
fill 471 132 344 477 132 344 minecraft:black_concrete
fill 472 132 330 473 133 330 minecraft:iron_block
setblock 473 132 325 minecraft:light[level=14]
setblock 473 132 333 minecraft:light[level=14]
setblock 473 132 341 minecraft:light[level=14]
fill 473 132 342 477 133 343 minecraft:black_concrete
fill 473 132 345 477 133 346 minecraft:black_concrete
setblock 473 132 349 minecraft:light[level=14]
setblock 473 132 357 minecraft:light[level=14]
setblock 481 132 325 minecraft:light[level=14]
setblock 481 132 333 minecraft:light[level=14]
setblock 481 132 341 minecraft:light[level=14]
setblock 481 132 349 minecraft:light[level=14]
setblock 481 132 357 minecraft:light[level=14]
setblock 489 132 325 minecraft:light[level=14]
setblock 489 132 333 minecraft:light[level=14]
setblock 489 132 341 minecraft:light[level=14]
setblock 489 132 349 minecraft:light[level=14]
setblock 489 132 357 minecraft:light[level=14]
setblock 497 132 325 minecraft:light[level=14]
setblock 497 132 333 minecraft:light[level=14]
setblock 497 132 341 minecraft:light[level=14]
setblock 497 132 357 minecraft:light[level=14]
setblock 505 132 325 minecraft:light[level=14]
setblock 505 132 333 minecraft:light[level=14]
setblock 505 132 341 minecraft:light[level=14]
setblock 505 132 349 minecraft:light[level=14]
setblock 505 132 357 minecraft:light[level=14]
fill 473 133 344 477 133 344 minecraft:black_concrete
fill 475 134 344 475 137 344 minecraft:black_concrete
fill 470 136 327 470 143 327 minecraft:purple_concrete
fill 470 136 335 470 143 335 minecraft:purple_concrete
fill 470 136 343 470 143 343 minecraft:purple_concrete
fill 470 136 351 470 143 351 minecraft:purple_concrete
fill 470 136 359 470 143 359 minecraft:purple_concrete
fill 473 136 364 473 143 364 minecraft:purple_concrete
fill 477 136 322 477 143 322 minecraft:purple_concrete
fill 481 136 364 481 143 364 minecraft:purple_concrete
fill 485 136 322 485 143 322 minecraft:purple_concrete
fill 489 136 364 489 143 364 minecraft:purple_concrete
fill 493 136 322 493 143 322 minecraft:purple_concrete
fill 497 136 364 497 143 364 minecraft:purple_concrete
fill 501 136 322 501 143 322 minecraft:purple_concrete
fill 505 136 364 505 143 364 minecraft:purple_concrete
fill 509 136 322 509 143 322 minecraft:purple_concrete
fill 512 136 327 512 143 327 minecraft:purple_concrete
fill 512 136 335 512 143 335 minecraft:purple_concrete
fill 512 136 343 512 143 343 minecraft:purple_concrete
fill 512 136 351 512 143 351 minecraft:purple_concrete
fill 512 136 359 512 143 359 minecraft:purple_concrete
fill 473 138 344 477 141 344 minecraft:yellow_concrete
fill 474 138 343 476 141 343 minecraft:yellow_concrete
fill 474 138 345 476 141 345 minecraft:yellow_concrete
fill 475 138 342 475 141 342 minecraft:yellow_concrete
fill 475 138 346 475 141 346 minecraft:yellow_concrete
fill 473 139 343 473 140 343 minecraft:yellow_concrete
fill 473 139 345 473 140 345 minecraft:yellow_concrete
fill 474 139 342 474 140 342 minecraft:yellow_concrete
fill 474 139 346 474 140 346 minecraft:yellow_concrete
fill 476 139 342 476 140 342 minecraft:yellow_concrete
fill 476 139 346 476 140 346 minecraft:yellow_concrete
fill 477 139 343 477 140 343 minecraft:yellow_concrete
fill 477 139 345 477 140 345 minecraft:yellow_concrete
fill 471 140 323 471 141 328 minecraft:black_concrete
fill 471 140 331 472 140 336 minecraft:black_concrete
fill 471 140 339 472 140 344 minecraft:black_concrete
fill 471 140 347 472 140 352 minecraft:black_concrete
fill 471 140 355 472 140 360 minecraft:black_concrete
fill 471 140 363 476 141 363 minecraft:black_concrete
fill 472 140 324 472 140 330 minecraft:black_concrete
fill 472 140 337 472 140 338 minecraft:black_concrete
fill 472 140 345 472 140 346 minecraft:black_concrete
fill 472 140 353 472 140 354 minecraft:black_concrete
fill 472 140 361 472 140 362 minecraft:black_concrete
fill 473 140 324 510 140 324 minecraft:black_concrete
setblock 473 140 325 minecraft:light[level=14]
setblock 473 140 333 minecraft:light[level=14]
setblock 473 140 341 minecraft:light[level=14]
setblock 473 140 349 minecraft:light[level=14]
setblock 473 140 357 minecraft:light[level=14]
fill 473 140 362 511 140 362 minecraft:black_concrete
fill 474 140 323 479 141 323 minecraft:black_concrete
fill 479 140 363 484 141 363 minecraft:black_concrete
setblock 481 140 325 minecraft:light[level=14]
setblock 481 140 333 minecraft:light[level=14]
setblock 481 140 341 minecraft:light[level=14]
setblock 481 140 349 minecraft:light[level=14]
setblock 481 140 357 minecraft:light[level=14]
fill 482 140 323 487 141 323 minecraft:black_concrete
fill 487 140 363 492 141 363 minecraft:black_concrete
setblock 489 140 325 minecraft:light[level=14]
setblock 489 140 333 minecraft:light[level=14]
setblock 489 140 341 minecraft:light[level=14]
setblock 489 140 349 minecraft:light[level=14]
setblock 489 140 357 minecraft:light[level=14]
fill 490 140 323 495 141 323 minecraft:black_concrete
fill 495 140 363 500 141 363 minecraft:black_concrete
setblock 497 140 325 minecraft:light[level=14]
setblock 497 140 333 minecraft:light[level=14]
setblock 497 140 341 minecraft:light[level=14]
setblock 497 140 357 minecraft:light[level=14]
fill 498 140 323 503 141 323 minecraft:black_concrete
fill 503 140 363 508 141 363 minecraft:black_concrete
setblock 505 140 325 minecraft:light[level=14]
setblock 505 140 333 minecraft:light[level=14]
setblock 505 140 341 minecraft:light[level=14]
setblock 505 140 349 minecraft:light[level=14]
setblock 505 140 357 minecraft:light[level=14]
fill 506 140 323 511 141 323 minecraft:black_concrete
fill 510 140 325 510 140 361 minecraft:black_concrete
fill 511 140 326 511 141 331 minecraft:black_concrete
fill 511 140 334 511 141 339 minecraft:black_concrete
fill 511 140 342 511 141 347 minecraft:black_concrete
fill 511 140 350 511 141 355 minecraft:black_concrete
fill 511 140 358 511 141 361 minecraft:black_concrete
fill 511 140 363 511 141 363 minecraft:black_concrete
fill 471 141 331 471 141 336 minecraft:black_concrete
fill 471 141 339 471 141 344 minecraft:black_concrete
fill 471 141 347 471 141 352 minecraft:black_concrete
fill 471 141 355 471 141 360 minecraft:black_concrete
setblock 511 141 362 minecraft:black_concrete
setblock 475 142 344 minecraft:yellow_concrete
fill 470 144 327 470 147 327 minecraft:sea_lantern
fill 470 144 335 470 147 335 minecraft:sea_lantern
fill 470 144 343 470 147 343 minecraft:sea_lantern
fill 470 144 351 470 147 351 minecraft:sea_lantern
fill 470 144 359 470 147 359 minecraft:sea_lantern
fill 472 144 361 473 145 361 minecraft:iron_block
fill 473 144 364 473 147 364 minecraft:sea_lantern
fill 477 144 322 477 147 322 minecraft:sea_lantern
fill 481 144 364 481 147 364 minecraft:sea_lantern
fill 485 144 322 485 147 322 minecraft:sea_lantern
fill 489 144 364 489 147 364 minecraft:sea_lantern
fill 493 144 322 493 147 322 minecraft:sea_lantern
fill 497 144 364 497 147 364 minecraft:sea_lantern
fill 501 144 322 501 147 322 minecraft:sea_lantern
fill 505 144 364 505 147 364 minecraft:sea_lantern
fill 509 144 322 509 147 322 minecraft:sea_lantern
fill 512 144 327 512 147 327 minecraft:sea_lantern
fill 512 144 335 512 147 335 minecraft:sea_lantern
fill 512 144 343 512 147 343 minecraft:sea_lantern
fill 512 144 351 512 147 351 minecraft:sea_lantern
fill 512 144 359 512 147 359 minecraft:sea_lantern
fill 470 148 327 470 157 327 minecraft:purple_concrete
fill 470 148 335 470 157 335 minecraft:purple_concrete
fill 470 148 343 470 157 343 minecraft:purple_concrete
fill 470 148 351 470 157 351 minecraft:purple_concrete
fill 470 148 359 470 157 359 minecraft:purple_concrete
setblock 473 148 325 minecraft:light[level=14]
setblock 473 148 333 minecraft:light[level=14]
setblock 473 148 341 minecraft:light[level=14]
setblock 473 148 349 minecraft:light[level=14]
setblock 473 148 357 minecraft:light[level=14]
fill 473 148 364 473 157 364 minecraft:purple_concrete
fill 477 148 322 477 157 322 minecraft:purple_concrete
setblock 481 148 325 minecraft:light[level=14]
setblock 481 148 333 minecraft:light[level=14]
setblock 481 148 341 minecraft:light[level=14]
setblock 481 148 349 minecraft:light[level=14]
setblock 481 148 357 minecraft:light[level=14]
fill 481 148 364 481 157 364 minecraft:purple_concrete
fill 485 148 322 485 157 322 minecraft:purple_concrete
setblock 489 148 325 minecraft:light[level=14]
setblock 489 148 333 minecraft:light[level=14]
setblock 489 148 341 minecraft:light[level=14]
setblock 489 148 349 minecraft:light[level=14]
setblock 489 148 357 minecraft:light[level=14]
fill 489 148 364 489 157 364 minecraft:purple_concrete
fill 493 148 322 493 157 322 minecraft:purple_concrete
setblock 497 148 325 minecraft:light[level=14]
setblock 497 148 333 minecraft:light[level=14]
setblock 497 148 341 minecraft:light[level=14]
setblock 497 148 357 minecraft:light[level=14]
fill 497 148 364 497 157 364 minecraft:purple_concrete
fill 501 148 322 501 157 322 minecraft:purple_concrete
setblock 505 148 325 minecraft:light[level=14]
setblock 505 148 333 minecraft:light[level=14]
setblock 505 148 341 minecraft:light[level=14]
setblock 505 148 349 minecraft:light[level=14]
setblock 505 148 357 minecraft:light[level=14]
fill 505 148 364 505 157 364 minecraft:purple_concrete
fill 509 148 322 509 157 322 minecraft:purple_concrete
fill 512 148 327 512 157 327 minecraft:purple_concrete
fill 512 148 335 512 157 335 minecraft:purple_concrete
fill 512 148 343 512 157 343 minecraft:purple_concrete
fill 512 148 351 512 157 351 minecraft:purple_concrete
fill 512 148 359 512 157 359 minecraft:purple_concrete
fill 482 153 348 494 153 348 minecraft:yellow_concrete
fill 484 153 347 494 153 347 minecraft:yellow_concrete
fill 484 153 349 494 153 349 minecraft:yellow_concrete
fill 486 153 346 495 153 346 minecraft:yellow_concrete
fill 486 153 350 495 153 350 minecraft:yellow_concrete
fill 487 153 338 488 154 339 minecraft:yellow_concrete
fill 487 153 357 488 154 358 minecraft:yellow_concrete
fill 488 153 340 492 153 342 minecraft:yellow_concrete
fill 488 153 354 492 153 356 minecraft:yellow_concrete
fill 489 153 339 491 154 339 minecraft:yellow_concrete
fill 489 153 343 505 153 343 minecraft:yellow_concrete
fill 489 153 353 505 153 353 minecraft:yellow_concrete
fill 489 153 357 491 154 357 minecraft:yellow_concrete
fill 490 153 344 504 153 344 minecraft:yellow_concrete
fill 490 153 352 504 153 352 minecraft:yellow_concrete
fill 491 153 345 503 153 345 minecraft:yellow_concrete
fill 491 153 351 503 153 351 minecraft:yellow_concrete
fill 493 153 341 493 153 342 minecraft:yellow_concrete
fill 493 153 354 493 153 355 minecraft:yellow_concrete
fill 494 153 342 506 153 342 minecraft:yellow_concrete
fill 494 153 354 506 153 354 minecraft:yellow_concrete
fill 495 153 337 499 153 341 minecraft:yellow_concrete
fill 495 153 355 499 153 359 minecraft:yellow_concrete
fill 496 153 335 498 154 336 minecraft:yellow_concrete
fill 496 153 360 498 154 361 minecraft:yellow_concrete
fill 497 153 333 497 154 334 minecraft:yellow_concrete
fill 497 153 362 497 154 363 minecraft:yellow_concrete
fill 499 153 346 508 153 346 minecraft:yellow_concrete
fill 499 153 350 508 153 350 minecraft:yellow_concrete
fill 500 153 347 510 153 349 minecraft:yellow_concrete
fill 501 153 341 506 153 341 minecraft:yellow_concrete
fill 501 153 355 506 153 355 minecraft:yellow_concrete
fill 502 153 340 506 154 340 minecraft:yellow_concrete
fill 502 153 356 506 154 356 minecraft:yellow_concrete
fill 503 153 339 507 154 339 minecraft:yellow_concrete
fill 503 153 357 507 154 357 minecraft:yellow_concrete
fill 506 153 338 507 154 338 minecraft:yellow_concrete
fill 506 153 358 507 154 358 minecraft:yellow_concrete
fill 511 153 348 512 154 348 minecraft:yellow_concrete
fill 512 153 346 512 194 347 minecraft:purple_concrete
fill 512 153 349 512 197 350 minecraft:purple_concrete
fill 471 154 323 481 154 363 minecraft:black_concrete
fill 482 154 323 483 154 347 minecraft:black_concrete
fill 482 154 348 486 154 348 minecraft:yellow_concrete
fill 482 154 349 483 154 363 minecraft:black_concrete
fill 484 154 323 485 154 346 minecraft:black_concrete
fill 484 154 347 488 154 347 minecraft:yellow_concrete
fill 484 154 349 488 154 349 minecraft:yellow_concrete
fill 484 154 350 485 154 363 minecraft:black_concrete
fill 486 154 323 486 154 345 minecraft:black_concrete
fill 486 154 346 492 154 346 minecraft:yellow_concrete
fill 486 154 350 492 154 350 minecraft:yellow_concrete
fill 486 154 351 486 154 363 minecraft:black_concrete
fill 487 154 323 494 154 337 minecraft:black_concrete
fill 487 154 340 487 154 345 minecraft:black_concrete
fill 487 154 348 492 154 348 minecraft:orange_concrete
fill 487 154 351 487 154 356 minecraft:black_concrete
fill 487 154 359 494 154 363 minecraft:black_concrete
fill 488 154 340 489 154 342 minecraft:yellow_concrete
fill 488 154 343 488 154 345 minecraft:black_concrete
fill 488 154 351 488 154 353 minecraft:black_concrete
fill 488 154 354 489 154 356 minecraft:yellow_concrete
fill 489 154 338 494 154 338 minecraft:black_concrete
fill 489 154 343 490 154 343 minecraft:yellow_concrete
fill 489 154 344 489 154 345 minecraft:black_concrete
fill 489 154 347 493 154 347 minecraft:orange_concrete
fill 489 154 349 493 154 349 minecraft:orange_concrete
fill 489 154 351 489 154 352 minecraft:black_concrete
fill 489 154 353 490 154 353 minecraft:yellow_concrete
fill 489 154 358 494 154 358 minecraft:black_concrete
fill 490 154 340 492 154 340 minecraft:yellow_concrete
fill 490 154 341 491 154 342 minecraft:orange_concrete
setblock 490 154 344 minecraft:yellow_concrete
setblock 490 154 345 minecraft:black_concrete
setblock 490 154 351 minecraft:black_concrete
setblock 490 154 352 minecraft:yellow_concrete
fill 490 154 354 491 154 355 minecraft:orange_concrete
fill 490 154 356 492 154 356 minecraft:yellow_concrete
fill 491 154 343 494 154 344 minecraft:orange_concrete
setblock 491 154 345 minecraft:yellow_concrete
setblock 491 154 351 minecraft:yellow_concrete
fill 491 154 352 494 154 353 minecraft:orange_concrete
fill 492 154 339 494 154 339 minecraft:black_concrete
fill 492 154 341 493 154 341 minecraft:yellow_concrete
fill 492 154 342 493 154 342 minecraft:orange_concrete
fill 492 154 345 494 154 345 minecraft:orange_concrete
fill 492 154 351 494 154 351 minecraft:orange_concrete
fill 492 154 354 493 154 354 minecraft:orange_concrete
fill 492 154 355 493 154 355 minecraft:yellow_concrete
fill 492 154 357 494 154 357 minecraft:black_concrete
fill 493 154 340 494 154 340 minecraft:black_concrete
setblock 493 154 346 minecraft:orange_concrete
setblock 493 154 348 minecraft:white_concrete
setblock 493 154 350 minecraft:orange_concrete
fill 493 154 356 494 154 356 minecraft:black_concrete
setblock 494 154 341 minecraft:black_concrete
fill 494 154 342 495 154 342 minecraft:yellow_concrete
fill 494 154 346 494 154 350 minecraft:sea_lantern
fill 494 154 354 495 154 354 minecraft:yellow_concrete
setblock 494 154 355 minecraft:black_concrete
fill 495 154 323 495 154 336 minecraft:black_concrete
fill 495 154 337 495 154 341 minecraft:yellow_concrete
setblock 495 154 343 minecraft:yellow_concrete
fill 495 154 344 496 154 344 minecraft:orange_concrete
fill 495 154 345 495 154 346 minecraft:sea_lantern
fill 495 154 350 495 154 351 minecraft:sea_lantern
fill 495 154 352 496 154 352 minecraft:orange_concrete
setblock 495 154 353 minecraft:yellow_concrete
fill 495 154 355 495 154 359 minecraft:yellow_concrete
fill 495 154 360 495 154 363 minecraft:black_concrete
fill 496 154 323 496 154 334 minecraft:black_concrete
fill 496 154 337 496 154 339 minecraft:yellow_concrete
fill 496 154 340 498 154 343 minecraft:orange_concrete
fill 496 154 345 499 154 345 minecraft:sea_lantern
fill 496 154 351 499 154 351 minecraft:sea_lantern
fill 496 154 353 498 154 356 minecraft:orange_concrete
fill 496 154 357 496 154 359 minecraft:yellow_concrete
fill 496 154 362 496 154 363 minecraft:black_concrete
fill 497 154 323 511 154 332 minecraft:black_concrete
fill 497 154 337 499 154 337 minecraft:yellow_concrete
fill 497 154 338 497 154 339 minecraft:orange_concrete
setblock 497 154 344 minecraft:white_concrete
setblock 497 154 352 minecraft:white_concrete
fill 497 154 357 497 154 358 minecraft:orange_concrete
fill 497 154 359 499 154 359 minecraft:yellow_concrete
fill 498 154 333 511 154 334 minecraft:black_concrete
fill 498 154 338 499 154 339 minecraft:yellow_concrete
fill 498 154 344 503 154 344 minecraft:orange_concrete
fill 498 154 352 503 154 352 minecraft:orange_concrete
fill 498 154 357 499 154 358 minecraft:yellow_concrete
fill 498 154 362 511 154 363 minecraft:black_concrete
fill 499 154 335 511 154 336 minecraft:black_concrete
fill 499 154 340 499 154 343 minecraft:yellow_concrete
fill 499 154 346 500 154 346 minecraft:sea_lantern
fill 499 154 350 500 154 350 minecraft:sea_lantern
fill 499 154 353 499 154 356 minecraft:yellow_concrete
fill 499 154 360 511 154 361 minecraft:black_concrete
fill 500 154 337 500 154 341 minecraft:black_concrete
setblock 500 154 342 minecraft:yellow_concrete
fill 500 154 343 503 154 343 minecraft:orange_concrete
fill 500 154 345 502 154 345 minecraft:orange_concrete
fill 500 154 347 500 154 349 minecraft:sea_lantern
fill 500 154 351 502 154 351 minecraft:orange_concrete
fill 500 154 353 503 154 353 minecraft:orange_concrete
setblock 500 154 354 minecraft:yellow_concrete
fill 500 154 355 500 154 359 minecraft:black_concrete
fill 501 154 337 501 154 340 minecraft:black_concrete
fill 501 154 341 502 154 341 minecraft:yellow_concrete
fill 501 154 342 504 154 342 minecraft:orange_concrete
fill 501 154 346 501 154 347 minecraft:orange_concrete
setblock 501 154 348 minecraft:white_concrete
fill 501 154 349 501 154 350 minecraft:orange_concrete
fill 501 154 354 504 154 354 minecraft:orange_concrete
fill 501 154 355 502 154 355 minecraft:yellow_concrete
fill 501 154 356 501 154 359 minecraft:black_concrete
fill 502 154 337 502 154 339 minecraft:black_concrete
fill 502 154 346 508 154 346 minecraft:yellow_concrete
fill 502 154 347 505 154 349 minecraft:orange_concrete
fill 502 154 350 508 154 350 minecraft:yellow_concrete
fill 502 154 357 502 154 359 minecraft:black_concrete
fill 503 154 337 505 154 338 minecraft:black_concrete
fill 503 154 341 504 154 341 minecraft:orange_concrete
setblock 503 154 345 minecraft:yellow_concrete
setblock 503 154 351 minecraft:yellow_concrete
fill 503 154 355 504 154 355 minecraft:orange_concrete
fill 503 154 358 505 154 359 minecraft:black_concrete
fill 504 154 343 504 154 344 minecraft:yellow_concrete
fill 504 154 345 511 154 345 minecraft:black_concrete
fill 504 154 351 511 154 351 minecraft:black_concrete
fill 504 154 352 504 154 353 minecraft:yellow_concrete
fill 505 154 341 505 154 343 minecraft:yellow_concrete
fill 505 154 344 511 154 344 minecraft:black_concrete
fill 505 154 352 511 154 352 minecraft:black_concrete
fill 505 154 353 505 154 355 minecraft:yellow_concrete
fill 506 154 337 511 154 337 minecraft:black_concrete
fill 506 154 341 506 154 342 minecraft:yellow_concrete
fill 506 154 343 511 154 343 minecraft:black_concrete
fill 506 154 347 510 154 347 minecraft:yellow_concrete
fill 506 154 348 507 154 348 minecraft:orange_concrete
fill 506 154 349 510 154 349 minecraft:yellow_concrete
fill 506 154 353 511 154 353 minecraft:black_concrete
fill 506 154 354 506 154 355 minecraft:yellow_concrete
fill 506 154 359 511 154 359 minecraft:black_concrete
fill 507 154 340 511 154 342 minecraft:black_concrete
fill 507 154 354 511 154 356 minecraft:black_concrete
fill 508 154 338 511 154 339 minecraft:black_concrete
fill 508 154 348 510 154 348 minecraft:yellow_concrete
fill 508 154 357 511 154 358 minecraft:black_concrete
fill 509 154 346 511 154 346 minecraft:black_concrete
fill 509 154 350 511 154 350 minecraft:black_concrete
setblock 511 154 347 minecraft:black_concrete
setblock 511 154 349 minecraft:black_concrete
fill 485 155 336 494 155 360 minecraft:prismarine_bricks
fill 495 155 336 509 155 345 minecraft:prismarine_bricks
fill 495 155 351 509 155 360 minecraft:prismarine_bricks
fill 500 155 346 509 155 350 minecraft:prismarine_bricks
fill 512 155 348 512 197 348 minecraft:purple_concrete
setblock 473 156 325 minecraft:light[level=14]
setblock 473 156 333 minecraft:light[level=14]
setblock 473 156 341 minecraft:light[level=14]
setblock 473 156 349 minecraft:light[level=14]
setblock 473 156 357 minecraft:light[level=14]
setblock 481 156 325 minecraft:light[level=14]
setblock 481 156 333 minecraft:light[level=14]
setblock 481 156 341 minecraft:light[level=14]
setblock 481 156 349 minecraft:light[level=14]
setblock 481 156 357 minecraft:light[level=14]
fill 485 156 336 493 156 360 minecraft:prismarine_bricks
setblock 489 156 325 minecraft:light[level=14]
setblock 489 156 333 minecraft:light[level=14]
fill 494 156 336 494 156 347 minecraft:prismarine_bricks
fill 494 156 349 494 156 360 minecraft:prismarine_bricks
fill 495 156 336 496 156 345 minecraft:prismarine_bricks
fill 495 156 351 496 156 360 minecraft:prismarine_bricks
setblock 497 156 325 minecraft:light[level=14]
setblock 497 156 333 minecraft:light[level=14]
fill 497 156 336 509 156 344 minecraft:prismarine_bricks
fill 497 156 352 509 156 360 minecraft:prismarine_bricks
fill 498 156 345 509 156 345 minecraft:prismarine_bricks
fill 498 156 351 509 156 351 minecraft:prismarine_bricks
fill 500 156 346 509 156 347 minecraft:prismarine_bricks
fill 500 156 349 509 156 350 minecraft:prismarine_bricks
fill 501 156 348 509 156 348 minecraft:prismarine_bricks
setblock 505 156 325 minecraft:light[level=14]
setblock 505 156 333 minecraft:light[level=14]
fill 486 157 337 486 158 337 minecraft:sea_lantern
fill 486 157 359 486 158 359 minecraft:sea_lantern
fill 487 157 338 493 158 358 minecraft:dark_prismarine
fill 494 157 338 494 158 346 minecraft:dark_prismarine
fill 494 157 350 494 158 358 minecraft:dark_prismarine
fill 495 157 338 495 158 345 minecraft:dark_prismarine
fill 495 157 351 495 158 358 minecraft:dark_prismarine
fill 496 157 338 507 158 344 minecraft:dark_prismarine
fill 496 157 352 507 158 358 minecraft:dark_prismarine
fill 499 157 345 507 158 345 minecraft:dark_prismarine
fill 499 157 351 507 158 351 minecraft:dark_prismarine
fill 500 157 346 507 158 346 minecraft:dark_prismarine
fill 500 157 350 507 158 350 minecraft:dark_prismarine
fill 501 157 347 507 158 349 minecraft:dark_prismarine
fill 508 157 337 508 158 337 minecraft:sea_lantern
fill 508 157 359 508 158 359 minecraft:sea_lantern
fill 470 158 327 470 163 327 minecraft:sea_lantern
fill 470 158 335 470 163 335 minecraft:sea_lantern
fill 470 158 343 470 163 343 minecraft:sea_lantern
fill 470 158 351 470 163 351 minecraft:sea_lantern
fill 470 158 359 470 163 359 minecraft:sea_lantern
fill 471 158 329 471 217 330 minecraft:black_concrete
fill 471 158 337 471 217 338 minecraft:black_concrete
fill 471 158 345 471 217 346 minecraft:black_concrete
fill 471 158 353 471 217 354 minecraft:black_concrete
fill 471 158 361 471 217 362 minecraft:black_concrete
fill 472 158 323 473 217 323 minecraft:black_concrete
fill 473 158 364 473 163 364 minecraft:sea_lantern
fill 477 158 322 477 163 322 minecraft:sea_lantern
fill 477 158 363 478 217 363 minecraft:black_concrete
fill 480 158 323 481 217 323 minecraft:black_concrete
fill 481 158 364 481 163 364 minecraft:sea_lantern
fill 485 158 322 485 163 322 minecraft:sea_lantern
fill 485 158 363 486 217 363 minecraft:black_concrete
fill 488 158 323 489 217 323 minecraft:black_concrete
fill 489 158 364 489 163 364 minecraft:sea_lantern
fill 493 158 322 493 163 322 minecraft:sea_lantern
fill 493 158 363 494 217 363 minecraft:black_concrete
fill 496 158 323 497 217 323 minecraft:black_concrete
fill 497 158 364 497 163 364 minecraft:sea_lantern
fill 501 158 322 501 163 322 minecraft:sea_lantern
fill 501 158 363 502 217 363 minecraft:black_concrete
fill 504 158 323 505 217 323 minecraft:black_concrete
fill 505 158 324 505 158 325 minecraft:iron_block
fill 505 158 364 505 163 364 minecraft:sea_lantern
fill 509 158 322 509 163 322 minecraft:sea_lantern
fill 509 158 363 510 217 363 minecraft:black_concrete
fill 511 158 324 511 217 325 minecraft:black_concrete
fill 511 158 332 511 217 333 minecraft:black_concrete
fill 511 158 340 511 217 341 minecraft:black_concrete
fill 511 158 348 511 217 349 minecraft:black_concrete
fill 511 158 356 511 217 357 minecraft:black_concrete
fill 512 158 327 512 163 327 minecraft:sea_lantern
fill 512 158 335 512 163 335 minecraft:sea_lantern
fill 512 158 343 512 163 343 minecraft:sea_lantern
fill 512 158 351 512 163 351 minecraft:sea_lantern
fill 512 158 359 512 163 359 minecraft:sea_lantern
fill 489 159 340 493 160 356 minecraft:prismarine_bricks
fill 494 159 340 494 160 345 minecraft:prismarine_bricks
fill 494 159 351 494 160 356 minecraft:prismarine_bricks
fill 495 159 340 505 160 344 minecraft:prismarine_bricks
fill 495 159 352 505 160 356 minecraft:prismarine_bricks
fill 500 159 345 505 160 345 minecraft:prismarine_bricks
fill 500 159 351 505 160 351 minecraft:prismarine_bricks
fill 501 159 346 505 160 350 minecraft:prismarine_bricks
fill 491 161 342 493 161 354 minecraft:dark_prismarine
fill 494 161 342 494 162 345 minecraft:dark_prismarine
fill 494 161 351 494 162 354 minecraft:dark_prismarine
fill 495 161 342 503 161 344 minecraft:dark_prismarine
fill 495 161 352 503 161 354 minecraft:dark_prismarine
fill 500 161 345 503 162 345 minecraft:dark_prismarine
fill 500 161 351 503 162 351 minecraft:dark_prismarine
fill 501 161 346 503 161 350 minecraft:dark_prismarine
fill 474 162 338 474 163 348 minecraft:black_concrete
fill 475 162 335 475 163 342 minecraft:black_concrete
fill 475 162 344 475 163 351 minecraft:black_concrete
fill 476 162 334 476 163 337 minecraft:black_concrete
fill 476 162 349 476 163 352 minecraft:black_concrete
fill 477 162 332 477 163 335 minecraft:black_concrete
fill 477 162 351 477 163 354 minecraft:black_concrete
fill 478 162 331 478 163 333 minecraft:black_concrete
fill 478 162 353 478 163 355 minecraft:black_concrete
fill 479 162 330 479 163 332 minecraft:black_concrete
fill 479 162 354 479 163 356 minecraft:black_concrete
fill 480 162 329 480 163 331 minecraft:black_concrete
fill 480 162 355 480 163 357 minecraft:black_concrete
fill 481 162 329 481 163 330 minecraft:black_concrete
fill 481 162 356 481 163 357 minecraft:black_concrete
fill 482 162 328 483 163 329 minecraft:black_concrete
fill 482 162 357 483 163 358 minecraft:black_concrete
fill 483 162 327 490 163 327 minecraft:black_concrete
fill 483 162 359 490 163 359 minecraft:black_concrete
fill 484 162 328 485 163 328 minecraft:black_concrete
fill 484 162 358 485 163 358 minecraft:black_concrete
fill 486 162 326 496 163 326 minecraft:black_concrete
fill 486 162 360 496 163 360 minecraft:black_concrete
fill 491 162 342 492 162 354 minecraft:dark_prismarine
fill 492 162 327 499 163 327 minecraft:black_concrete
fill 492 162 359 499 163 359 minecraft:black_concrete
fill 493 162 342 493 162 347 minecraft:dark_prismarine
fill 493 162 349 493 162 354 minecraft:dark_prismarine
fill 495 162 342 496 162 344 minecraft:dark_prismarine
fill 495 162 352 496 162 354 minecraft:dark_prismarine
fill 497 162 328 500 163 328 minecraft:black_concrete
fill 497 162 342 503 162 343 minecraft:dark_prismarine
fill 497 162 353 503 162 354 minecraft:dark_prismarine
fill 497 162 358 500 163 358 minecraft:black_concrete
fill 498 162 344 503 162 344 minecraft:dark_prismarine
fill 498 162 352 503 162 352 minecraft:dark_prismarine
fill 499 162 329 502 163 329 minecraft:black_concrete
fill 499 162 357 502 163 357 minecraft:black_concrete
fill 501 162 330 503 163 330 minecraft:black_concrete
fill 501 162 346 503 162 347 minecraft:dark_prismarine
fill 501 162 349 503 162 350 minecraft:dark_prismarine
fill 501 162 356 503 163 356 minecraft:black_concrete
fill 502 162 331 504 163 331 minecraft:black_concrete
fill 502 162 348 503 162 348 minecraft:dark_prismarine
fill 502 162 355 504 163 355 minecraft:black_concrete
fill 503 162 332 505 163 332 minecraft:black_concrete
fill 504 162 333 505 163 333 minecraft:black_concrete
fill 504 162 353 505 163 354 minecraft:black_concrete
fill 505 162 334 506 163 335 minecraft:black_concrete
fill 505 162 351 506 163 352 minecraft:black_concrete
fill 506 162 336 507 163 337 minecraft:black_concrete
fill 506 162 349 507 163 350 minecraft:black_concrete
fill 507 162 335 507 163 335 minecraft:black_concrete
fill 507 162 338 508 163 342 minecraft:black_concrete
fill 507 162 344 508 163 348 minecraft:black_concrete
fill 507 162 351 507 163 351 minecraft:black_concrete
fill 508 162 343 508 163 343 minecraft:black_concrete
fill 493 163 344 493 164 346 minecraft:prismarine_bricks
fill 493 163 350 493 164 352 minecraft:prismarine_bricks
fill 494 163 344 495 164 344 minecraft:prismarine_bricks
fill 494 163 352 495 164 352 minecraft:prismarine_bricks
fill 499 163 344 501 164 344 minecraft:prismarine_bricks
fill 499 163 352 501 164 352 minecraft:prismarine_bricks
fill 501 163 345 501 164 346 minecraft:prismarine_bricks
fill 501 163 350 501 164 351 minecraft:prismarine_bricks
setblock 503 163 354 minecraft:black_concrete
fill 470 164 327 470 171 327 minecraft:purple_concrete
fill 470 164 335 470 171 335 minecraft:purple_concrete
fill 470 164 343 470 171 343 minecraft:purple_concrete
fill 470 164 351 470 171 351 minecraft:purple_concrete
fill 470 164 359 470 171 359 minecraft:purple_concrete
setblock 473 164 325 minecraft:light[level=14]
setblock 473 164 333 minecraft:light[level=14]
setblock 473 164 341 minecraft:light[level=14]
fill 473 164 342 473 164 344 minecraft:sea_lantern
setblock 473 164 349 minecraft:light[level=14]
setblock 473 164 357 minecraft:light[level=14]
fill 473 164 364 473 171 364 minecraft:purple_concrete
fill 474 164 337 474 164 341 minecraft:sea_lantern
fill 474 164 345 474 164 349 minecraft:sea_lantern
fill 475 164 335 475 164 336 minecraft:sea_lantern
fill 476 164 333 476 164 334 minecraft:sea_lantern
fill 477 164 322 477 171 322 minecraft:purple_concrete
fill 477 164 332 477 164 333 minecraft:sea_lantern
setblock 478 164 331 minecraft:sea_lantern
setblock 479 164 330 minecraft:sea_lantern
fill 480 164 329 481 164 329 minecraft:sea_lantern
setblock 481 164 325 minecraft:light[level=14]
fill 481 164 328 482 164 328 minecraft:sea_lantern
setblock 481 164 333 minecraft:light[level=14]
setblock 481 164 341 minecraft:light[level=14]
setblock 481 164 349 minecraft:light[level=14]
setblock 481 164 357 minecraft:light[level=14]
fill 481 164 364 481 171 364 minecraft:purple_concrete
fill 483 164 327 484 164 327 minecraft:sea_lantern
fill 485 164 322 485 171 322 minecraft:purple_concrete
fill 485 164 326 489 164 326 minecraft:sea_lantern
setblock 489 164 325 minecraft:light[level=14]
setblock 489 164 333 minecraft:light[level=14]
setblock 489 164 341 minecraft:light[level=14]
setblock 489 164 349 minecraft:light[level=14]
setblock 489 164 357 minecraft:light[level=14]
fill 489 164 364 489 171 364 minecraft:purple_concrete
fill 490 164 325 491 164 325 minecraft:sea_lantern
fill 493 164 322 493 171 322 minecraft:purple_concrete
setblock 497 164 325 minecraft:light[level=14]
setblock 497 164 333 minecraft:light[level=14]
setblock 497 164 341 minecraft:light[level=14]
setblock 497 164 357 minecraft:light[level=14]
fill 497 164 364 497 171 364 minecraft:purple_concrete
fill 501 164 322 501 171 322 minecraft:purple_concrete
setblock 505 164 325 minecraft:light[level=14]
setblock 505 164 333 minecraft:light[level=14]
setblock 505 164 341 minecraft:light[level=14]
setblock 505 164 349 minecraft:light[level=14]
setblock 505 164 357 minecraft:light[level=14]
fill 505 164 364 505 171 364 minecraft:purple_concrete
fill 509 164 322 509 171 322 minecraft:purple_concrete
fill 512 164 327 512 171 327 minecraft:purple_concrete
fill 512 164 335 512 171 335 minecraft:purple_concrete
fill 512 164 343 512 171 343 minecraft:purple_concrete
fill 512 164 351 512 171 351 minecraft:purple_concrete
fill 512 164 359 512 171 359 minecraft:purple_concrete
fill 474 167 339 474 168 347 minecraft:black_concrete
fill 475 167 336 475 168 339 minecraft:black_concrete
fill 475 167 347 475 168 350 minecraft:black_concrete
fill 476 167 334 476 168 336 minecraft:black_concrete
fill 476 167 350 476 168 352 minecraft:black_concrete
fill 477 167 333 477 168 334 minecraft:black_concrete
fill 477 167 352 477 168 353 minecraft:black_concrete
fill 478 167 332 478 168 333 minecraft:black_concrete
fill 478 167 353 478 168 354 minecraft:black_concrete
fill 479 167 331 479 168 331 minecraft:black_concrete
fill 479 167 355 479 168 355 minecraft:black_concrete
fill 480 167 330 481 168 330 minecraft:black_concrete
fill 480 167 356 481 168 356 minecraft:black_concrete
fill 481 167 329 482 168 329 minecraft:black_concrete
fill 481 167 357 482 168 357 minecraft:black_concrete
fill 482 167 328 484 168 328 minecraft:black_concrete
fill 482 167 358 484 168 358 minecraft:black_concrete
fill 484 167 327 487 168 327 minecraft:black_concrete
fill 484 167 359 487 168 359 minecraft:black_concrete
fill 487 167 326 495 168 326 minecraft:black_concrete
fill 487 167 360 495 168 360 minecraft:black_concrete
fill 495 167 327 498 168 327 minecraft:black_concrete
fill 495 167 359 498 168 359 minecraft:black_concrete
fill 498 167 328 500 168 328 minecraft:black_concrete
fill 498 167 358 500 168 358 minecraft:black_concrete
fill 500 167 329 501 168 329 minecraft:black_concrete
fill 500 167 357 501 168 357 minecraft:black_concrete
fill 501 167 330 502 168 330 minecraft:black_concrete
fill 501 167 356 502 168 356 minecraft:black_concrete
fill 503 167 331 503 168 331 minecraft:black_concrete
fill 503 167 355 503 168 355 minecraft:black_concrete
fill 504 167 332 504 168 333 minecraft:black_concrete
fill 504 167 353 504 168 354 minecraft:black_concrete
fill 505 167 333 505 168 334 minecraft:black_concrete
fill 505 167 352 505 168 353 minecraft:black_concrete
fill 506 167 334 506 168 336 minecraft:black_concrete
fill 506 167 350 506 168 352 minecraft:black_concrete
fill 507 167 336 507 168 339 minecraft:black_concrete
fill 507 167 347 507 168 350 minecraft:black_concrete
fill 508 167 339 508 168 347 minecraft:black_concrete
fill 471 168 323 471 169 328 minecraft:black_concrete
fill 471 168 331 472 168 336 minecraft:black_concrete
fill 471 168 339 472 168 344 minecraft:black_concrete
fill 471 168 347 472 168 352 minecraft:black_concrete
fill 471 168 355 472 168 360 minecraft:black_concrete
fill 471 168 363 476 169 363 minecraft:black_concrete
fill 472 168 324 472 168 330 minecraft:black_concrete
fill 472 168 337 472 168 338 minecraft:black_concrete
fill 472 168 345 472 168 346 minecraft:black_concrete
fill 472 168 353 472 168 354 minecraft:black_concrete
fill 472 168 361 472 168 362 minecraft:black_concrete
fill 473 168 324 510 168 324 minecraft:black_concrete
fill 473 168 362 511 168 362 minecraft:black_concrete
fill 474 168 323 479 169 323 minecraft:black_concrete
fill 479 168 363 484 169 363 minecraft:black_concrete
fill 482 168 323 487 169 323 minecraft:black_concrete
fill 487 168 363 492 169 363 minecraft:black_concrete
fill 490 168 323 495 169 323 minecraft:black_concrete
fill 495 168 363 500 169 363 minecraft:black_concrete
fill 498 168 323 503 169 323 minecraft:black_concrete
fill 503 168 363 508 169 363 minecraft:black_concrete
fill 506 168 323 511 169 323 minecraft:black_concrete
fill 510 168 325 510 168 361 minecraft:black_concrete
fill 511 168 326 511 169 331 minecraft:black_concrete
fill 511 168 334 511 169 339 minecraft:black_concrete
fill 511 168 342 511 169 347 minecraft:black_concrete
fill 511 168 350 511 169 355 minecraft:black_concrete
fill 511 168 358 511 169 361 minecraft:black_concrete
fill 511 168 363 511 169 363 minecraft:black_concrete
fill 471 169 331 471 169 336 minecraft:black_concrete
fill 471 169 339 471 169 344 minecraft:black_concrete
fill 471 169 347 471 169 352 minecraft:black_concrete
fill 471 169 355 471 169 360 minecraft:black_concrete
setblock 478 169 355 minecraft:sea_lantern
setblock 479 169 356 minecraft:sea_lantern
fill 480 169 329 481 169 329 minecraft:sea_lantern
fill 480 169 357 481 169 357 minecraft:sea_lantern
fill 481 169 328 482 169 328 minecraft:sea_lantern
fill 481 169 358 482 169 358 minecraft:sea_lantern
fill 483 169 327 484 169 327 minecraft:sea_lantern
fill 483 169 359 484 169 359 minecraft:sea_lantern
fill 485 169 326 489 169 326 minecraft:sea_lantern
fill 485 169 360 489 169 360 minecraft:sea_lantern
fill 490 169 325 492 169 325 minecraft:sea_lantern
fill 490 169 361 492 169 361 minecraft:sea_lantern
fill 493 169 326 497 169 326 minecraft:sea_lantern
fill 493 169 360 497 169 360 minecraft:sea_lantern
fill 498 169 327 499 169 327 minecraft:sea_lantern
fill 498 169 359 499 169 359 minecraft:sea_lantern
fill 500 169 328 501 169 328 minecraft:sea_lantern
fill 500 169 358 501 169 358 minecraft:sea_lantern
fill 501 169 329 502 169 329 minecraft:sea_lantern
fill 501 169 357 502 169 357 minecraft:sea_lantern
setblock 503 169 330 minecraft:sea_lantern
setblock 503 169 356 minecraft:sea_lantern
setblock 504 169 331 minecraft:sea_lantern
setblock 504 169 355 minecraft:sea_lantern
fill 505 169 332 505 169 333 minecraft:sea_lantern
fill 505 169 353 505 169 354 minecraft:sea_lantern
fill 506 169 333 506 169 334 minecraft:sea_lantern
fill 506 169 352 506 169 353 minecraft:sea_lantern
fill 507 169 335 507 169 336 minecraft:sea_lantern
fill 507 169 350 507 169 351 minecraft:sea_lantern
fill 508 169 337 508 169 341 minecraft:sea_lantern
fill 508 169 345 508 169 349 minecraft:sea_lantern
fill 509 169 342 509 169 344 minecraft:sea_lantern
setblock 511 169 362 minecraft:black_concrete
fill 474 171 323 474 172 325 minecraft:iron_block
fill 470 172 327 470 177 327 minecraft:sea_lantern
fill 470 172 335 470 177 335 minecraft:sea_lantern
fill 470 172 343 470 177 343 minecraft:sea_lantern
fill 470 172 351 470 177 351 minecraft:sea_lantern
fill 470 172 359 470 177 359 minecraft:sea_lantern
setblock 473 172 325 minecraft:light[level=14]
setblock 473 172 333 minecraft:light[level=14]
setblock 473 172 341 minecraft:light[level=14]
setblock 473 172 349 minecraft:light[level=14]
setblock 473 172 357 minecraft:light[level=14]
fill 473 172 364 473 177 364 minecraft:sea_lantern
fill 477 172 322 477 177 322 minecraft:sea_lantern
setblock 481 172 325 minecraft:light[level=14]
setblock 481 172 333 minecraft:light[level=14]
setblock 481 172 341 minecraft:light[level=14]
setblock 481 172 349 minecraft:light[level=14]
setblock 481 172 357 minecraft:light[level=14]
fill 481 172 364 481 177 364 minecraft:sea_lantern
fill 485 172 322 485 177 322 minecraft:sea_lantern
setblock 489 172 325 minecraft:light[level=14]
setblock 489 172 333 minecraft:light[level=14]
setblock 489 172 341 minecraft:light[level=14]
setblock 489 172 349 minecraft:light[level=14]
setblock 489 172 357 minecraft:light[level=14]
fill 489 172 364 489 177 364 minecraft:sea_lantern
fill 493 172 322 493 177 322 minecraft:sea_lantern
setblock 497 172 325 minecraft:light[level=14]
setblock 497 172 333 minecraft:light[level=14]
setblock 497 172 341 minecraft:light[level=14]
setblock 497 172 349 minecraft:light[level=14]
setblock 497 172 357 minecraft:light[level=14]
fill 497 172 364 497 177 364 minecraft:sea_lantern
fill 501 172 322 501 177 322 minecraft:sea_lantern
setblock 505 172 325 minecraft:light[level=14]
setblock 505 172 333 minecraft:light[level=14]
setblock 505 172 341 minecraft:light[level=14]
setblock 505 172 349 minecraft:light[level=14]
setblock 505 172 357 minecraft:light[level=14]
fill 505 172 364 505 177 364 minecraft:sea_lantern
fill 509 172 322 509 177 322 minecraft:sea_lantern
fill 512 172 327 512 177 327 minecraft:sea_lantern
fill 512 172 335 512 177 335 minecraft:sea_lantern
fill 512 172 343 512 177 343 minecraft:sea_lantern
fill 512 172 351 512 177 351 minecraft:sea_lantern
fill 512 172 359 512 177 359 minecraft:sea_lantern
fill 470 178 327 470 185 327 minecraft:purple_concrete
fill 470 178 335 470 185 335 minecraft:purple_concrete
fill 470 178 343 470 185 343 minecraft:purple_concrete
fill 470 178 351 470 185 351 minecraft:purple_concrete
fill 470 178 359 470 185 359 minecraft:purple_concrete
fill 473 178 364 473 185 364 minecraft:purple_concrete
fill 477 178 322 477 185 322 minecraft:purple_concrete
fill 481 178 364 481 185 364 minecraft:purple_concrete
fill 485 178 322 485 185 322 minecraft:purple_concrete
fill 489 178 364 489 185 364 minecraft:purple_concrete
fill 493 178 322 493 185 322 minecraft:purple_concrete
fill 497 178 364 497 185 364 minecraft:purple_concrete
fill 501 178 322 501 185 322 minecraft:purple_concrete
fill 505 178 364 505 185 364 minecraft:purple_concrete
fill 509 178 322 509 185 322 minecraft:purple_concrete
fill 512 178 327 512 185 327 minecraft:purple_concrete
fill 512 178 335 512 185 335 minecraft:purple_concrete
fill 512 178 343 512 185 343 minecraft:purple_concrete
fill 512 178 351 512 185 351 minecraft:purple_concrete
fill 512 178 359 512 185 359 minecraft:purple_concrete
setblock 473 180 325 minecraft:light[level=14]
setblock 473 180 333 minecraft:light[level=14]
setblock 473 180 341 minecraft:light[level=14]
setblock 473 180 349 minecraft:light[level=14]
setblock 473 180 357 minecraft:light[level=14]
setblock 481 180 325 minecraft:light[level=14]
setblock 481 180 333 minecraft:light[level=14]
setblock 481 180 341 minecraft:light[level=14]
setblock 481 180 349 minecraft:light[level=14]
setblock 481 180 357 minecraft:light[level=14]
setblock 489 180 325 minecraft:light[level=14]
setblock 489 180 333 minecraft:light[level=14]
setblock 489 180 341 minecraft:light[level=14]
setblock 489 180 349 minecraft:light[level=14]
setblock 489 180 357 minecraft:light[level=14]
setblock 497 180 325 minecraft:light[level=14]
setblock 497 180 333 minecraft:light[level=14]
setblock 497 180 341 minecraft:light[level=14]
setblock 497 180 349 minecraft:light[level=14]
setblock 497 180 357 minecraft:light[level=14]
setblock 505 180 325 minecraft:light[level=14]
setblock 505 180 333 minecraft:light[level=14]
setblock 505 180 341 minecraft:light[level=14]
setblock 505 180 349 minecraft:light[level=14]
setblock 505 180 357 minecraft:light[level=14]
fill 471 182 323 471 183 328 minecraft:black_concrete
fill 471 182 331 472 182 336 minecraft:black_concrete
fill 471 182 339 472 182 344 minecraft:black_concrete
fill 471 182 347 472 182 352 minecraft:black_concrete
fill 471 182 355 472 182 360 minecraft:black_concrete
fill 471 182 363 476 183 363 minecraft:black_concrete
fill 472 182 324 472 182 330 minecraft:black_concrete
fill 472 182 337 472 182 338 minecraft:black_concrete
fill 472 182 345 472 182 346 minecraft:black_concrete
fill 472 182 353 472 182 354 minecraft:black_concrete
fill 472 182 361 472 182 362 minecraft:black_concrete
fill 473 182 324 510 182 324 minecraft:black_concrete
fill 473 182 362 511 182 362 minecraft:black_concrete
fill 474 182 323 479 183 323 minecraft:black_concrete
fill 479 182 363 484 183 363 minecraft:black_concrete
fill 482 182 323 487 183 323 minecraft:black_concrete
fill 487 182 363 492 183 363 minecraft:black_concrete
fill 490 182 323 495 183 323 minecraft:black_concrete
fill 495 182 363 500 183 363 minecraft:black_concrete
fill 498 182 323 503 183 323 minecraft:black_concrete
fill 503 182 363 508 183 363 minecraft:black_concrete
fill 506 182 323 511 183 323 minecraft:black_concrete
fill 510 182 325 510 182 361 minecraft:black_concrete
fill 511 182 326 511 183 331 minecraft:black_concrete
fill 511 182 334 511 183 339 minecraft:black_concrete
fill 511 182 342 511 183 347 minecraft:black_concrete
fill 511 182 350 511 183 355 minecraft:black_concrete
fill 511 182 358 511 183 361 minecraft:black_concrete
fill 511 182 363 511 183 363 minecraft:black_concrete
fill 471 183 331 471 183 336 minecraft:black_concrete
fill 471 183 339 471 183 344 minecraft:black_concrete
fill 471 183 347 471 183 352 minecraft:black_concrete
fill 471 183 355 471 183 360 minecraft:black_concrete
setblock 511 183 362 minecraft:black_concrete
fill 471 184 334 473 185 334 minecraft:iron_block
fill 470 186 327 470 191 327 minecraft:sea_lantern
fill 470 186 335 470 191 335 minecraft:sea_lantern
fill 470 186 343 470 191 343 minecraft:sea_lantern
fill 470 186 351 470 191 351 minecraft:sea_lantern
fill 470 186 359 470 191 359 minecraft:sea_lantern
fill 473 186 364 473 191 364 minecraft:sea_lantern
fill 477 186 322 477 191 322 minecraft:sea_lantern
fill 481 186 364 481 191 364 minecraft:sea_lantern
fill 485 186 322 485 191 322 minecraft:sea_lantern
fill 489 186 364 489 191 364 minecraft:sea_lantern
fill 493 186 322 493 191 322 minecraft:sea_lantern
fill 497 186 364 497 191 364 minecraft:sea_lantern
fill 501 186 322 501 191 322 minecraft:sea_lantern
fill 505 186 364 505 191 364 minecraft:sea_lantern
fill 509 186 322 509 191 322 minecraft:sea_lantern
fill 512 186 327 512 191 327 minecraft:sea_lantern
fill 512 186 335 512 191 335 minecraft:sea_lantern
fill 512 186 343 512 191 343 minecraft:sea_lantern
fill 512 186 351 512 191 351 minecraft:sea_lantern
fill 512 186 359 512 191 359 minecraft:sea_lantern
setblock 473 188 325 minecraft:light[level=14]
setblock 473 188 333 minecraft:light[level=14]
setblock 473 188 341 minecraft:light[level=14]
setblock 473 188 349 minecraft:light[level=14]
setblock 473 188 357 minecraft:light[level=14]
setblock 481 188 325 minecraft:light[level=14]
setblock 481 188 333 minecraft:light[level=14]
setblock 481 188 341 minecraft:light[level=14]
setblock 481 188 349 minecraft:light[level=14]
setblock 481 188 357 minecraft:light[level=14]
setblock 489 188 325 minecraft:light[level=14]
setblock 489 188 333 minecraft:light[level=14]
setblock 489 188 341 minecraft:light[level=14]
setblock 489 188 349 minecraft:light[level=14]
setblock 489 188 357 minecraft:light[level=14]
setblock 497 188 325 minecraft:light[level=14]
setblock 497 188 333 minecraft:light[level=14]
setblock 497 188 341 minecraft:light[level=14]
setblock 497 188 349 minecraft:light[level=14]
setblock 497 188 357 minecraft:light[level=14]
setblock 505 188 325 minecraft:light[level=14]
setblock 505 188 333 minecraft:light[level=14]
setblock 505 188 341 minecraft:light[level=14]
setblock 505 188 349 minecraft:light[level=14]
setblock 505 188 357 minecraft:light[level=14]
fill 470 192 327 470 197 327 minecraft:purple_concrete
fill 470 192 335 470 194 335 minecraft:purple_concrete
fill 470 192 343 470 198 343 minecraft:purple_concrete
fill 470 192 351 470 194 351 minecraft:purple_concrete
fill 470 192 359 470 197 359 minecraft:purple_concrete
fill 473 192 364 473 194 364 minecraft:purple_concrete
fill 477 192 322 477 197 322 minecraft:purple_concrete
fill 481 192 364 481 198 364 minecraft:purple_concrete
fill 485 192 322 485 197 322 minecraft:purple_concrete
fill 489 192 364 489 197 364 minecraft:purple_concrete
fill 493 192 322 493 194 322 minecraft:purple_concrete
fill 497 192 364 497 197 364 minecraft:purple_concrete
fill 501 192 322 501 195 322 minecraft:purple_concrete
fill 505 192 364 505 193 364 minecraft:purple_concrete
fill 509 192 322 509 197 322 minecraft:purple_concrete
fill 512 192 327 512 194 327 minecraft:purple_concrete
fill 512 192 335 512 197 335 minecraft:purple_concrete
fill 512 192 343 512 197 343 minecraft:purple_concrete
fill 512 192 351 512 197 351 minecraft:purple_concrete
fill 512 192 359 512 197 359 minecraft:purple_concrete
fill 508 193 356 510 194 356 minecraft:iron_block
fill 470 194 336 470 197 336 minecraft:purple_concrete
setblock 470 194 337 minecraft:blue_concrete
fill 470 194 338 470 195 341 minecraft:purple_concrete
fill 470 194 344 470 194 346 minecraft:purple_concrete
setblock 470 194 347 minecraft:blue_concrete
fill 470 194 348 470 195 350 minecraft:purple_concrete
setblock 470 194 353 minecraft:blue_concrete
setblock 470 194 358 minecraft:blue_concrete
fill 470 194 362 470 197 363 minecraft:purple_concrete
setblock 470 194 364 minecraft:blue_concrete
setblock 478 194 322 minecraft:blue_concrete
setblock 479 194 322 minecraft:purple_concrete
fill 479 194 364 479 195 364 minecraft:blue_concrete
fill 480 194 364 480 197 364 minecraft:purple_concrete
fill 486 194 322 486 198 322 minecraft:purple_concrete
setblock 487 194 322 minecraft:blue_concrete
fill 488 194 322 492 197 322 minecraft:purple_concrete
setblock 505 194 364 minecraft:blue_concrete
setblock 512 194 333 minecraft:blue_concrete
fill 512 194 352 512 197 353 minecraft:purple_concrete
setblock 512 194 354 minecraft:blue_concrete
fill 512 194 355 512 197 356 minecraft:purple_concrete
setblock 470 195 329 minecraft:blue_concrete
fill 470 195 330 470 197 332 minecraft:purple_concrete
setblock 470 195 335 minecraft:blue_concrete
fill 470 195 337 470 197 337 minecraft:purple_concrete
fill 470 195 344 470 197 344 minecraft:purple_concrete
setblock 470 195 345 minecraft:blue_concrete
fill 470 195 346 470 197 347 minecraft:purple_concrete
setblock 470 195 351 minecraft:blue_concrete
fill 470 195 353 470 197 353 minecraft:purple_concrete
fill 470 195 358 470 197 358 minecraft:purple_concrete
fill 470 195 364 470 198 364 minecraft:purple_concrete
setblock 473 195 364 minecraft:blue_concrete
setblock 476 195 322 minecraft:blue_concrete
fill 478 195 322 478 199 322 minecraft:purple_concrete
setblock 478 195 364 minecraft:blue_concrete
fill 479 195 322 480 195 322 minecraft:blue_concrete
fill 481 195 322 481 197 322 minecraft:purple_concrete
setblock 482 195 364 minecraft:blue_concrete
fill 483 195 364 487 195 364 minecraft:purple_concrete
fill 487 195 322 487 197 322 minecraft:purple_concrete
setblock 491 195 364 minecraft:blue_concrete
fill 492 195 364 492 197 364 minecraft:purple_concrete
fill 493 195 322 494 195 322 minecraft:blue_concrete
fill 502 195 322 502 197 322 minecraft:purple_concrete
setblock 503 195 322 minecraft:blue_concrete
fill 505 195 364 505 197 364 minecraft:purple_concrete
setblock 508 195 322 minecraft:blue_concrete
setblock 508 195 364 minecraft:blue_concrete
fill 509 195 364 509 198 364 minecraft:purple_concrete
fill 511 195 322 511 196 322 minecraft:blue_concrete
fill 512 195 322 512 198 322 minecraft:purple_concrete
setblock 512 195 327 minecraft:blue_concrete
fill 512 195 333 512 197 333 minecraft:purple_concrete
fill 512 195 338 512 197 338 minecraft:purple_concrete
fill 512 195 339 512 196 339 minecraft:blue_concrete
fill 512 195 346 512 197 346 minecraft:purple_concrete
setblock 512 195 347 minecraft:blue_concrete
fill 512 195 354 512 197 354 minecraft:purple_concrete
fill 470 196 329 470 197 329 minecraft:purple_concrete
fill 470 196 335 470 197 335 minecraft:purple_concrete
setblock 470 196 338 minecraft:blue_concrete
fill 470 196 339 470 197 341 minecraft:purple_concrete
fill 470 196 345 470 197 345 minecraft:purple_concrete
fill 470 196 348 470 197 348 minecraft:purple_concrete
setblock 470 196 349 minecraft:blue_concrete
fill 470 196 350 470 197 351 minecraft:purple_concrete
setblock 470 196 354 minecraft:blue_concrete
fill 470 196 355 470 197 357 minecraft:purple_concrete
fill 471 196 323 471 197 328 minecraft:black_concrete
fill 471 196 331 472 196 336 minecraft:black_concrete
fill 471 196 339 472 196 344 minecraft:black_concrete
fill 471 196 347 472 196 352 minecraft:black_concrete
fill 471 196 355 472 196 360 minecraft:black_concrete
fill 471 196 363 476 197 363 minecraft:black_concrete
fill 472 196 324 472 196 330 minecraft:black_concrete
fill 472 196 337 472 196 338 minecraft:black_concrete
fill 472 196 345 472 196 346 minecraft:black_concrete
fill 472 196 353 472 196 354 minecraft:black_concrete
fill 472 196 361 472 196 362 minecraft:black_concrete
fill 473 196 324 510 196 324 minecraft:black_concrete
setblock 473 196 325 minecraft:light[level=14]
setblock 473 196 333 minecraft:light[level=14]
setblock 473 196 341 minecraft:light[level=14]
setblock 473 196 349 minecraft:light[level=14]
setblock 473 196 357 minecraft:light[level=14]
fill 473 196 362 511 196 362 minecraft:black_concrete
fill 473 196 364 473 197 364 minecraft:purple_concrete
fill 474 196 323 479 197 323 minecraft:black_concrete
fill 476 196 322 476 197 322 minecraft:purple_concrete
fill 478 196 364 479 197 364 minecraft:purple_concrete
fill 479 196 322 480 197 322 minecraft:purple_concrete
fill 479 196 363 484 197 363 minecraft:black_concrete
setblock 481 196 325 minecraft:light[level=14]
setblock 481 196 333 minecraft:light[level=14]
setblock 481 196 341 minecraft:light[level=14]
setblock 481 196 349 minecraft:light[level=14]
setblock 481 196 357 minecraft:light[level=14]
fill 482 196 323 487 197 323 minecraft:black_concrete
fill 482 196 364 484 197 364 minecraft:purple_concrete
setblock 485 196 364 minecraft:blue_concrete
fill 486 196 364 486 197 364 minecraft:purple_concrete
fill 487 196 363 492 197 363 minecraft:black_concrete
setblock 487 196 364 minecraft:blue_concrete
setblock 489 196 325 minecraft:light[level=14]
setblock 489 196 333 minecraft:light[level=14]
setblock 489 196 341 minecraft:light[level=14]
setblock 489 196 349 minecraft:light[level=14]
setblock 489 196 357 minecraft:light[level=14]
fill 490 196 323 495 197 323 minecraft:black_concrete
setblock 490 196 364 minecraft:blue_concrete
fill 491 196 364 491 197 364 minecraft:purple_concrete
fill 493 196 322 494 197 322 minecraft:purple_concrete
fill 495 196 363 500 197 363 minecraft:black_concrete
fill 496 196 322 497 197 322 minecraft:purple_concrete
setblock 497 196 325 minecraft:light[level=14]
setblock 497 196 333 minecraft:light[level=14]
setblock 497 196 341 minecraft:light[level=14]
setblock 497 196 349 minecraft:light[level=14]
setblock 497 196 357 minecraft:light[level=14]
setblock 498 196 322 minecraft:blue_concrete
fill 498 196 323 503 197 323 minecraft:black_concrete
fill 499 196 322 500 197 322 minecraft:purple_concrete
fill 499 196 364 500 196 364 minecraft:blue_concrete
setblock 501 196 322 minecraft:blue_concrete
fill 501 196 364 504 197 364 minecraft:purple_concrete
fill 503 196 322 503 197 322 minecraft:purple_concrete
fill 503 196 363 508 197 363 minecraft:black_concrete
setblock 505 196 325 minecraft:light[level=14]
setblock 505 196 333 minecraft:light[level=14]
setblock 505 196 341 minecraft:light[level=14]
setblock 505 196 349 minecraft:light[level=14]
setblock 505 196 357 minecraft:light[level=14]
fill 506 196 323 511 197 323 minecraft:black_concrete
fill 508 196 322 508 197 322 minecraft:purple_concrete
fill 508 196 364 508 197 364 minecraft:purple_concrete
fill 510 196 325 510 196 361 minecraft:black_concrete
fill 511 196 326 511 197 331 minecraft:black_concrete
fill 511 196 334 511 197 339 minecraft:black_concrete
fill 511 196 342 511 197 347 minecraft:black_concrete
fill 511 196 350 511 197 355 minecraft:black_concrete
fill 511 196 358 511 197 361 minecraft:black_concrete
fill 511 196 363 511 197 363 minecraft:black_concrete
fill 512 196 327 512 197 327 minecraft:purple_concrete
fill 512 196 329 512 197 329 minecraft:purple_concrete
setblock 512 196 330 minecraft:blue_concrete
fill 512 196 331 512 198 331 minecraft:purple_concrete
fill 512 196 347 512 197 347 minecraft:purple_concrete
setblock 470 197 338 minecraft:purple_concrete
fill 470 197 349 470 198 349 minecraft:purple_concrete
setblock 470 197 354 minecraft:purple_concrete
fill 471 197 331 471 197 336 minecraft:black_concrete
fill 471 197 339 471 197 344 minecraft:black_concrete
fill 471 197 347 471 197 352 minecraft:black_concrete
fill 471 197 355 471 197 360 minecraft:black_concrete
setblock 485 197 364 minecraft:purple_concrete
fill 487 197 364 487 199 364 minecraft:purple_concrete
setblock 490 197 364 minecraft:purple_concrete
setblock 498 197 322 minecraft:purple_concrete
fill 499 197 364 500 197 364 minecraft:purple_concrete
setblock 501 197 322 minecraft:purple_concrete
setblock 511 197 322 minecraft:purple_concrete
setblock 511 197 362 minecraft:black_concrete
setblock 512 197 330 minecraft:purple_concrete
setblock 512 197 339 minecraft:purple_concrete
setblock 470 198 322 minecraft:purple_concrete
setblock 470 198 323 minecraft:blue_concrete
fill 470 198 325 470 198 330 minecraft:blue_concrete
setblock 470 198 331 minecraft:purple_concrete
fill 470 198 332 470 199 339 minecraft:blue_concrete
setblock 470 198 340 minecraft:purple_concrete
fill 470 198 341 470 307 342 minecraft:blue_concrete
fill 470 198 344 470 198 348 minecraft:blue_concrete
setblock 470 198 350 minecraft:purple_concrete
fill 470 198 351 470 199 354 minecraft:blue_concrete
fill 470 198 355 470 198 356 minecraft:purple_concrete
fill 470 198 357 470 199 363 minecraft:blue_concrete
fill 471 198 322 477 198 322 minecraft:blue_concrete
fill 471 198 326 473 199 326 minecraft:iron_block
fill 471 198 364 480 199 364 minecraft:blue_concrete
fill 479 198 322 481 307 322 minecraft:blue_concrete
fill 482 198 364 486 198 364 minecraft:blue_concrete
fill 483 198 322 485 198 322 minecraft:blue_concrete
fill 487 198 322 511 198 322 minecraft:blue_concrete
fill 489 198 364 492 199 364 minecraft:blue_concrete
fill 494 198 364 495 307 364 minecraft:blue_concrete
fill 497 198 364 499 198 364 minecraft:blue_concrete
setblock 500 198 364 minecraft:purple_concrete
fill 501 198 364 508 199 364 minecraft:blue_concrete
fill 510 198 364 511 307 364 minecraft:blue_concrete
setblock 512 198 323 minecraft:purple_concrete
fill 512 198 324 512 199 325 minecraft:blue_concrete
fill 512 198 327 512 199 327 minecraft:blue_concrete
fill 512 198 329 512 199 330 minecraft:blue_concrete
fill 512 198 332 512 198 344 minecraft:blue_concrete
fill 512 198 346 512 198 363 minecraft:blue_concrete
fill 512 198 364 512 199 364 minecraft:purple_concrete
fill 470 199 322 470 307 322 minecraft:blue_concrete
setblock 470 199 323 minecraft:purple_concrete
setblock 470 199 324 minecraft:blue_concrete
fill 470 199 325 470 199 326 minecraft:purple_concrete
fill 470 199 327 470 199 331 minecraft:blue_concrete
fill 470 199 340 470 307 340 minecraft:blue_concrete
fill 470 199 343 470 199 345 minecraft:blue_concrete
fill 470 199 346 470 199 347 minecraft:purple_concrete
fill 470 199 348 470 307 350 minecraft:blue_concrete
fill 470 199 355 470 307 356 minecraft:blue_concrete
setblock 470 199 364 minecraft:blue_concrete
setblock 471 199 322 minecraft:purple_concrete
fill 472 199 322 475 307 322 minecraft:blue_concrete
setblock 476 199 322 minecraft:purple_concrete
setblock 477 199 322 minecraft:blue_concrete
fill 481 199 364 484 199 364 minecraft:blue_concrete
fill 482 199 322 484 199 322 minecraft:blue_concrete
setblock 485 199 322 minecraft:purple_concrete
setblock 485 199 364 minecraft:purple_concrete
fill 486 199 322 491 307 322 minecraft:blue_concrete
fill 486 199 364 486 307 364 minecraft:blue_concrete
setblock 492 199 322 minecraft:purple_concrete
fill 493 199 322 502 199 322 minecraft:blue_concrete
fill 493 199 364 493 307 364 minecraft:blue_concrete
fill 496 199 364 498 199 364 minecraft:blue_concrete
setblock 499 199 364 minecraft:purple_concrete
setblock 500 199 364 minecraft:blue_concrete
setblock 503 199 322 minecraft:purple_concrete
fill 503 199 326 507 201 328 minecraft:blue_concrete
fill 504 199 322 512 199 322 minecraft:blue_concrete
fill 504 199 325 506 201 325 minecraft:blue_concrete
fill 504 199 329 506 201 329 minecraft:blue_concrete
fill 509 199 364 509 307 364 minecraft:blue_concrete
fill 512 199 323 512 307 323 minecraft:blue_concrete
fill 512 199 326 512 307 326 minecraft:blue_concrete
fill 512 199 328 512 307 328 minecraft:blue_concrete
fill 512 199 331 512 199 339 minecraft:blue_concrete
setblock 512 199 340 minecraft:purple_concrete
fill 512 199 341 512 199 350 minecraft:blue_concrete
setblock 512 199 351 minecraft:purple_concrete
fill 512 199 352 512 199 358 minecraft:blue_concrete
setblock 512 199 359 minecraft:purple_concrete
fill 512 199 360 512 307 363 minecraft:blue_concrete
fill 470 200 323 470 307 323 minecraft:blue_concrete
setblock 470 200 324 minecraft:purple_concrete
fill 470 200 325 470 307 326 minecraft:blue_concrete
fill 470 200 327 470 205 327 minecraft:sea_lantern
fill 470 200 328 470 307 330 minecraft:blue_concrete
setblock 470 200 331 minecraft:purple_concrete
fill 470 200 332 470 307 334 minecraft:blue_concrete
fill 470 200 335 470 205 335 minecraft:sea_lantern
fill 470 200 336 470 307 339 minecraft:blue_concrete
fill 470 200 343 470 205 343 minecraft:sea_lantern
fill 470 200 344 470 307 347 minecraft:blue_concrete
fill 470 200 351 470 205 351 minecraft:sea_lantern
fill 470 200 352 470 307 353 minecraft:blue_concrete
setblock 470 200 354 minecraft:purple_concrete
setblock 470 200 357 minecraft:purple_concrete
fill 470 200 358 470 307 358 minecraft:blue_concrete
fill 470 200 359 470 205 359 minecraft:sea_lantern
fill 470 200 360 470 307 363 minecraft:blue_concrete
setblock 470 200 364 minecraft:purple_concrete
fill 471 200 322 471 307 322 minecraft:blue_concrete
fill 471 200 364 472 307 364 minecraft:blue_concrete
fill 473 200 364 473 205 364 minecraft:sea_lantern
fill 474 200 364 480 307 364 minecraft:blue_concrete
fill 476 200 322 476 307 322 minecraft:blue_concrete
fill 477 200 322 477 205 322 minecraft:sea_lantern
fill 478 200 322 478 307 322 minecraft:blue_concrete
fill 481 200 364 481 205 364 minecraft:sea_lantern
setblock 482 200 322 minecraft:purple_concrete
fill 482 200 364 482 307 364 minecraft:blue_concrete
fill 483 200 322 484 307 322 minecraft:blue_concrete
setblock 483 200 364 minecraft:purple_concrete
fill 484 200 364 485 307 364 minecraft:blue_concrete
fill 485 200 322 485 205 322 minecraft:sea_lantern
fill 487 200 364 488 307 364 minecraft:blue_concrete
fill 489 200 364 489 205 364 minecraft:sea_lantern
fill 490 200 364 492 307 364 minecraft:blue_concrete
fill 492 200 322 492 307 322 minecraft:blue_concrete
fill 493 200 322 493 205 322 minecraft:sea_lantern
fill 494 200 322 500 307 322 minecraft:blue_concrete
setblock 496 200 364 minecraft:purple_concrete
fill 497 200 364 497 205 364 minecraft:sea_lantern
fill 498 200 364 499 307 364 minecraft:blue_concrete
setblock 500 200 364 minecraft:purple_concrete
fill 501 200 322 501 205 322 minecraft:sea_lantern
fill 501 200 364 504 307 364 minecraft:blue_concrete
fill 502 200 322 508 307 322 minecraft:blue_concrete
fill 505 200 364 505 205 364 minecraft:sea_lantern
fill 506 200 364 508 307 364 minecraft:blue_concrete
fill 509 200 322 509 205 322 minecraft:sea_lantern
fill 510 200 322 512 307 322 minecraft:blue_concrete
setblock 512 200 324 minecraft:purple_concrete
fill 512 200 325 512 307 325 minecraft:blue_concrete
fill 512 200 327 512 205 327 minecraft:sea_lantern
setblock 512 200 329 minecraft:purple_concrete
fill 512 200 330 512 307 331 minecraft:blue_concrete
fill 512 200 332 512 200 333 minecraft:purple_concrete
fill 512 200 334 512 307 334 minecraft:blue_concrete
fill 512 200 335 512 205 335 minecraft:sea_lantern
fill 512 200 336 512 307 342 minecraft:blue_concrete
fill 512 200 343 512 205 343 minecraft:sea_lantern
fill 512 200 344 512 307 346 minecraft:blue_concrete
setblock 512 200 347 minecraft:purple_concrete
fill 512 200 348 512 307 350 minecraft:blue_concrete
fill 512 200 351 512 205 351 minecraft:sea_lantern
fill 512 200 352 512 307 353 minecraft:blue_concrete
setblock 512 200 354 minecraft:purple_concrete
fill 512 200 355 512 307 358 minecraft:blue_concrete
fill 512 200 359 512 205 359 minecraft:sea_lantern
fill 512 200 364 512 307 364 minecraft:blue_concrete
fill 470 201 324 470 307 324 minecraft:blue_concrete
fill 470 201 331 470 307 331 minecraft:blue_concrete
fill 470 201 354 470 307 354 minecraft:blue_concrete
fill 470 201 357 470 307 357 minecraft:blue_concrete
fill 470 201 364 470 307 364 minecraft:blue_concrete
fill 482 201 322 482 307 322 minecraft:blue_concrete
fill 483 201 364 483 307 364 minecraft:blue_concrete
fill 496 201 364 496 307 364 minecraft:blue_concrete
fill 500 201 364 500 307 364 minecraft:blue_concrete
fill 512 201 324 512 307 324 minecraft:blue_concrete
fill 512 201 329 512 307 329 minecraft:blue_concrete
fill 512 201 332 512 307 333 minecraft:blue_concrete
fill 512 201 347 512 307 347 minecraft:blue_concrete
fill 512 201 354 512 307 354 minecraft:blue_concrete
fill 502 202 326 508 202 328 minecraft:sea_lantern
fill 503 202 325 507 202 325 minecraft:sea_lantern
fill 503 202 329 507 202 329 minecraft:sea_lantern
fill 504 202 324 506 202 324 minecraft:sea_lantern
fill 504 202 330 506 202 330 minecraft:sea_lantern
setblock 473 204 325 minecraft:light[level=14]
setblock 473 204 333 minecraft:light[level=14]
setblock 473 204 341 minecraft:light[level=14]
setblock 473 204 349 minecraft:light[level=14]
setblock 473 204 357 minecraft:light[level=14]
setblock 481 204 325 minecraft:light[level=14]
setblock 481 204 333 minecraft:light[level=14]
setblock 481 204 341 minecraft:light[level=14]
setblock 481 204 349 minecraft:light[level=14]
setblock 481 204 357 minecraft:light[level=14]
setblock 489 204 325 minecraft:light[level=14]
setblock 489 204 333 minecraft:light[level=14]
setblock 489 204 341 minecraft:light[level=14]
setblock 489 204 349 minecraft:light[level=14]
setblock 489 204 357 minecraft:light[level=14]
setblock 497 204 325 minecraft:light[level=14]
setblock 497 204 333 minecraft:light[level=14]
setblock 497 204 341 minecraft:light[level=14]
setblock 497 204 349 minecraft:light[level=14]
setblock 497 204 357 minecraft:light[level=14]
setblock 505 204 325 minecraft:light[level=14]
setblock 505 204 333 minecraft:light[level=14]
setblock 505 204 341 minecraft:light[level=14]
setblock 505 204 349 minecraft:light[level=14]
setblock 505 204 357 minecraft:light[level=14]
fill 508 204 333 510 205 333 minecraft:iron_block
fill 470 206 327 470 213 327 minecraft:blue_concrete
fill 470 206 335 470 213 335 minecraft:blue_concrete
fill 470 206 343 470 213 343 minecraft:blue_concrete
fill 470 206 351 470 213 351 minecraft:blue_concrete
fill 470 206 359 470 213 359 minecraft:blue_concrete
fill 473 206 364 473 213 364 minecraft:blue_concrete
fill 477 206 322 477 213 322 minecraft:blue_concrete
fill 481 206 364 481 213 364 minecraft:blue_concrete
fill 485 206 322 485 213 322 minecraft:blue_concrete
fill 489 206 364 489 213 364 minecraft:blue_concrete
fill 493 206 322 493 213 322 minecraft:blue_concrete
fill 497 206 364 497 213 364 minecraft:blue_concrete
fill 501 206 322 501 213 322 minecraft:blue_concrete
fill 505 206 364 505 213 364 minecraft:blue_concrete
fill 509 206 322 509 213 322 minecraft:blue_concrete
fill 512 206 327 512 213 327 minecraft:blue_concrete
fill 512 206 335 512 213 335 minecraft:blue_concrete
fill 512 206 343 512 213 343 minecraft:blue_concrete
fill 512 206 351 512 213 351 minecraft:blue_concrete
fill 512 206 359 512 213 359 minecraft:blue_concrete
fill 471 210 323 471 211 328 minecraft:black_concrete
fill 471 210 331 472 210 336 minecraft:black_concrete
fill 471 210 339 472 210 344 minecraft:black_concrete
fill 471 210 347 472 210 352 minecraft:black_concrete
fill 471 210 355 472 210 360 minecraft:black_concrete
fill 471 210 363 476 211 363 minecraft:black_concrete
fill 472 210 324 472 210 330 minecraft:black_concrete
fill 472 210 337 472 210 338 minecraft:black_concrete
fill 472 210 345 472 210 346 minecraft:black_concrete
fill 472 210 353 472 210 354 minecraft:black_concrete
fill 472 210 361 472 210 362 minecraft:black_concrete
fill 473 210 324 510 210 324 minecraft:black_concrete
fill 473 210 362 511 210 362 minecraft:black_concrete
fill 474 210 323 479 211 323 minecraft:black_concrete
fill 479 210 363 484 211 363 minecraft:black_concrete
fill 482 210 323 487 211 323 minecraft:black_concrete
fill 487 210 363 492 211 363 minecraft:black_concrete
fill 490 210 323 495 211 323 minecraft:black_concrete
fill 495 210 363 500 211 363 minecraft:black_concrete
fill 498 210 323 503 211 323 minecraft:black_concrete
fill 503 210 363 508 211 363 minecraft:black_concrete
fill 505 210 360 505 211 361 minecraft:black_concrete
fill 506 210 323 511 211 323 minecraft:black_concrete
fill 510 210 325 510 210 361 minecraft:black_concrete
fill 511 210 326 511 211 331 minecraft:black_concrete
fill 511 210 334 511 211 339 minecraft:black_concrete
fill 511 210 342 511 211 347 minecraft:black_concrete
fill 511 210 350 511 211 355 minecraft:black_concrete
fill 511 210 358 511 211 361 minecraft:black_concrete
fill 511 210 363 511 211 363 minecraft:black_concrete
fill 471 211 331 471 211 336 minecraft:black_concrete
fill 471 211 339 471 211 344 minecraft:black_concrete
fill 471 211 347 471 211 352 minecraft:black_concrete
fill 471 211 355 471 211 360 minecraft:black_concrete
fill 504 211 356 504 211 362 minecraft:black_concrete
fill 505 211 346 505 211 359 minecraft:black_concrete
setblock 505 211 362 minecraft:black_concrete
setblock 511 211 362 minecraft:black_concrete
setblock 473 212 325 minecraft:light[level=14]
setblock 473 212 333 minecraft:light[level=14]
setblock 473 212 341 minecraft:light[level=14]
setblock 473 212 349 minecraft:light[level=14]
setblock 473 212 357 minecraft:light[level=14]
setblock 481 212 325 minecraft:light[level=14]
setblock 481 212 333 minecraft:light[level=14]
setblock 481 212 341 minecraft:light[level=14]
setblock 481 212 349 minecraft:light[level=14]
setblock 481 212 357 minecraft:light[level=14]
setblock 489 212 325 minecraft:light[level=14]
setblock 489 212 333 minecraft:light[level=14]
setblock 489 212 341 minecraft:light[level=14]
setblock 489 212 349 minecraft:light[level=14]
setblock 489 212 357 minecraft:light[level=14]
setblock 497 212 325 minecraft:light[level=14]
setblock 497 212 333 minecraft:light[level=14]
setblock 497 212 341 minecraft:light[level=14]
setblock 497 212 349 minecraft:light[level=14]
setblock 497 212 357 minecraft:light[level=14]
setblock 505 212 325 minecraft:light[level=14]
setblock 505 212 333 minecraft:light[level=14]
fill 505 212 335 505 212 353 minecraft:black_concrete
fill 505 212 354 505 212 362 minecraft:yellow_concrete
fill 506 212 335 506 212 343 minecraft:black_concrete
fill 482 213 326 486 215 328 minecraft:yellow_concrete
fill 483 213 325 485 215 325 minecraft:yellow_concrete
fill 483 213 329 485 215 329 minecraft:yellow_concrete
fill 505 213 326 505 213 338 minecraft:black_concrete
fill 505 213 340 505 213 352 minecraft:yellow_concrete
fill 506 213 323 506 213 336 minecraft:black_concrete
fill 470 214 327 470 217 327 minecraft:sea_lantern
fill 470 214 335 470 217 335 minecraft:sea_lantern
fill 470 214 343 470 217 343 minecraft:sea_lantern
fill 470 214 351 470 217 351 minecraft:sea_lantern
fill 470 214 359 470 217 359 minecraft:sea_lantern
fill 473 214 364 473 217 364 minecraft:sea_lantern
fill 477 214 322 477 217 322 minecraft:sea_lantern
fill 481 214 364 481 217 364 minecraft:sea_lantern
fill 485 214 322 485 217 322 minecraft:sea_lantern
fill 489 214 364 489 217 364 minecraft:sea_lantern
fill 493 214 322 493 217 322 minecraft:sea_lantern
fill 497 214 364 497 217 364 minecraft:sea_lantern
fill 501 214 322 501 217 322 minecraft:sea_lantern
fill 505 214 333 505 214 336 minecraft:yellow_concrete
fill 505 214 364 505 217 364 minecraft:sea_lantern
fill 506 214 323 506 214 326 minecraft:black_concrete
fill 506 214 327 506 214 334 minecraft:yellow_concrete
fill 509 214 322 509 217 322 minecraft:sea_lantern
fill 512 214 327 512 217 327 minecraft:sea_lantern
fill 512 214 335 512 217 335 minecraft:sea_lantern
fill 512 214 343 512 217 343 minecraft:sea_lantern
fill 512 214 351 512 217 351 minecraft:sea_lantern
fill 512 214 359 512 217 359 minecraft:sea_lantern
fill 506 215 323 506 215 325 minecraft:yellow_concrete
fill 479 216 323 479 217 325 minecraft:iron_block
fill 481 216 326 487 216 328 minecraft:sea_lantern
fill 482 216 325 486 216 325 minecraft:sea_lantern
fill 482 216 329 486 216 329 minecraft:sea_lantern
fill 483 216 324 485 216 324 minecraft:sea_lantern
fill 483 216 330 485 216 330 minecraft:sea_lantern
fill 470 218 327 470 227 327 minecraft:blue_concrete
fill 470 218 335 470 227 335 minecraft:blue_concrete
fill 470 218 343 470 227 343 minecraft:blue_concrete
fill 470 218 351 470 227 351 minecraft:blue_concrete
fill 470 218 359 470 227 359 minecraft:blue_concrete
fill 473 218 364 473 227 364 minecraft:blue_concrete
fill 477 218 322 477 227 322 minecraft:blue_concrete
fill 481 218 364 481 227 364 minecraft:blue_concrete
fill 485 218 322 485 227 322 minecraft:blue_concrete
fill 489 218 364 489 227 364 minecraft:blue_concrete
fill 493 218 322 493 227 322 minecraft:blue_concrete
fill 497 218 364 497 227 364 minecraft:blue_concrete
fill 501 218 322 501 227 322 minecraft:blue_concrete
fill 505 218 364 505 227 364 minecraft:blue_concrete
fill 509 218 322 509 227 322 minecraft:blue_concrete
fill 512 218 327 512 227 327 minecraft:blue_concrete
fill 512 218 335 512 227 335 minecraft:blue_concrete
fill 512 218 343 512 227 343 minecraft:blue_concrete
fill 512 218 351 512 227 351 minecraft:blue_concrete
fill 512 218 359 512 227 359 minecraft:blue_concrete
setblock 473 220 325 minecraft:light[level=14]
setblock 473 220 333 minecraft:light[level=14]
setblock 473 220 341 minecraft:light[level=14]
setblock 473 220 349 minecraft:light[level=14]
setblock 473 220 357 minecraft:light[level=14]
setblock 481 220 325 minecraft:light[level=14]
setblock 481 220 333 minecraft:light[level=14]
setblock 481 220 341 minecraft:light[level=14]
setblock 481 220 349 minecraft:light[level=14]
setblock 481 220 357 minecraft:light[level=14]
setblock 489 220 325 minecraft:light[level=14]
setblock 489 220 333 minecraft:light[level=14]
setblock 489 220 341 minecraft:light[level=14]
setblock 489 220 349 minecraft:light[level=14]
setblock 489 220 357 minecraft:light[level=14]
setblock 497 220 325 minecraft:light[level=14]
setblock 497 220 333 minecraft:light[level=14]
setblock 497 220 341 minecraft:light[level=14]
setblock 497 220 349 minecraft:light[level=14]
setblock 497 220 357 minecraft:light[level=14]
setblock 505 220 325 minecraft:light[level=14]
setblock 505 220 333 minecraft:light[level=14]
setblock 505 220 341 minecraft:light[level=14]
setblock 505 220 349 minecraft:light[level=14]
setblock 505 220 357 minecraft:light[level=14]
fill 489 223 341 489 225 344 minecraft:red_concrete
fill 489 223 345 489 225 347 minecraft:white_concrete
fill 490 223 339 490 225 341 minecraft:red_concrete
fill 490 223 342 490 224 343 minecraft:purple_concrete
fill 490 223 344 490 224 344 minecraft:magenta_concrete
fill 490 223 345 490 224 346 minecraft:purple_concrete
fill 490 223 347 490 225 349 minecraft:white_concrete
fill 491 223 338 491 225 339 minecraft:red_concrete
fill 491 223 340 491 224 340 minecraft:magenta_concrete
fill 491 223 341 491 224 342 minecraft:purple_concrete
fill 491 223 343 491 224 343 minecraft:magenta_concrete
fill 491 223 344 491 224 345 minecraft:purple_concrete
fill 491 223 346 491 224 346 minecraft:magenta_concrete
fill 491 223 347 491 224 348 minecraft:purple_concrete
fill 491 223 349 491 225 350 minecraft:white_concrete
fill 492 223 337 492 225 338 minecraft:red_concrete
fill 492 223 339 492 224 339 minecraft:magenta_concrete
fill 492 223 340 492 224 341 minecraft:purple_concrete
fill 492 223 342 492 224 342 minecraft:magenta_concrete
fill 492 223 343 492 224 344 minecraft:purple_concrete
fill 492 223 345 492 224 345 minecraft:magenta_concrete
fill 492 223 346 492 224 347 minecraft:purple_concrete
fill 492 223 348 492 224 348 minecraft:magenta_concrete
fill 492 223 349 493 224 349 minecraft:purple_concrete
fill 492 223 350 492 225 351 minecraft:white_concrete
fill 493 223 337 494 225 337 minecraft:red_concrete
fill 493 223 338 493 224 338 minecraft:magenta_concrete
fill 493 223 339 493 224 340 minecraft:purple_concrete
fill 493 223 341 493 224 341 minecraft:magenta_concrete
fill 493 223 342 493 224 343 minecraft:purple_concrete
fill 493 223 344 493 224 344 minecraft:magenta_concrete
fill 493 223 345 493 224 346 minecraft:purple_concrete
fill 493 223 347 493 224 347 minecraft:magenta_concrete
fill 493 223 348 494 224 348 minecraft:purple_concrete
fill 493 223 350 493 224 350 minecraft:magenta_concrete
fill 493 223 351 494 225 351 minecraft:white_concrete
fill 494 223 336 496 225 336 minecraft:red_concrete
fill 494 223 338 494 224 339 minecraft:purple_concrete
fill 494 223 340 494 224 340 minecraft:magenta_concrete
fill 494 223 341 494 223 342 minecraft:purple_concrete
setblock 494 223 343 minecraft:magenta_concrete
fill 494 223 344 494 223 345 minecraft:purple_concrete
setblock 494 223 346 minecraft:magenta_concrete
fill 494 223 347 495 223 347 minecraft:purple_concrete
fill 494 223 349 494 224 349 minecraft:magenta_concrete
fill 494 223 350 495 224 350 minecraft:purple_concrete
fill 494 223 352 497 225 352 minecraft:white_concrete
fill 495 223 337 495 224 338 minecraft:purple_concrete
fill 495 223 339 495 224 339 minecraft:magenta_concrete
fill 495 223 340 495 223 341 minecraft:purple_concrete
setblock 495 223 342 minecraft:magenta_concrete
setblock 495 223 346 minecraft:purple_concrete
fill 495 223 348 495 224 348 minecraft:magenta_concrete
fill 495 223 349 496 224 349 minecraft:purple_concrete
fill 495 223 351 495 224 351 minecraft:magenta_concrete
fill 496 223 337 496 224 337 minecraft:purple_concrete
fill 496 223 338 496 224 338 minecraft:magenta_concrete
fill 496 223 339 496 224 340 minecraft:purple_concrete
setblock 496 223 341 minecraft:magenta_concrete
setblock 496 223 347 minecraft:magenta_concrete
fill 496 223 348 497 224 348 minecraft:purple_concrete
fill 496 223 350 496 224 350 minecraft:magenta_concrete
fill 496 223 351 497 224 351 minecraft:purple_concrete
fill 497 223 336 500 225 336 minecraft:white_concrete
fill 497 223 337 497 224 337 minecraft:magenta_concrete
fill 497 223 338 497 224 339 minecraft:purple_concrete
fill 497 223 340 497 224 340 minecraft:magenta_concrete
fill 497 223 341 498 223 341 minecraft:purple_concrete
fill 497 223 347 498 223 347 minecraft:purple_concrete
fill 497 223 349 497 224 349 minecraft:magenta_concrete
fill 497 223 350 498 224 350 minecraft:purple_concrete
fill 498 223 337 498 224 338 minecraft:purple_concrete
fill 498 223 339 498 224 339 minecraft:magenta_concrete
fill 498 223 340 499 224 340 minecraft:purple_concrete
fill 498 223 348 498 224 348 minecraft:magenta_concrete
fill 498 223 349 499 224 349 minecraft:purple_concrete
fill 498 223 351 498 224 351 minecraft:magenta_concrete
fill 498 223 352 500 225 352 minecraft:red_concrete
fill 499 223 337 499 224 337 minecraft:purple_concrete
fill 499 223 338 499 224 338 minecraft:magenta_concrete
fill 499 223 339 500 224 339 minecraft:purple_concrete
setblock 499 223 341 minecraft:magenta_concrete
fill 499 223 342 500 223 342 minecraft:purple_concrete
setblock 499 223 346 minecraft:purple_concrete
setblock 499 223 347 minecraft:magenta_concrete
fill 499 223 348 500 224 348 minecraft:purple_concrete
fill 499 223 350 499 224 350 minecraft:magenta_concrete
fill 499 223 351 499 224 351 minecraft:purple_concrete
fill 500 223 337 502 225 337 minecraft:white_concrete
fill 500 223 338 501 224 338 minecraft:purple_concrete
fill 500 223 340 500 224 340 minecraft:magenta_concrete
fill 500 223 341 501 224 341 minecraft:purple_concrete
setblock 500 223 343 minecraft:magenta_concrete
fill 500 223 344 500 223 345 minecraft:purple_concrete
setblock 500 223 346 minecraft:magenta_concrete
fill 500 223 347 501 224 347 minecraft:purple_concrete
fill 500 223 349 500 224 349 minecraft:magenta_concrete
fill 500 223 350 501 224 350 minecraft:purple_concrete
fill 500 223 351 502 225 351 minecraft:red_concrete
fill 501 223 339 501 224 339 minecraft:magenta_concrete
fill 501 223 340 502 224 340 minecraft:purple_concrete
fill 501 223 342 501 224 342 minecraft:magenta_concrete
fill 501 223 343 501 224 344 minecraft:purple_concrete
fill 501 223 345 501 224 345 minecraft:magenta_concrete
fill 501 223 346 502 224 346 minecraft:purple_concrete
fill 501 223 348 501 224 348 minecraft:magenta_concrete
fill 501 223 349 502 224 349 minecraft:purple_concrete
fill 502 223 338 503 225 338 minecraft:white_concrete
fill 502 223 339 502 224 339 minecraft:purple_concrete
fill 502 223 341 502 224 341 minecraft:magenta_concrete
fill 502 223 342 502 224 343 minecraft:purple_concrete
fill 502 223 344 502 224 344 minecraft:magenta_concrete
fill 502 223 345 503 224 345 minecraft:purple_concrete
fill 502 223 347 502 224 347 minecraft:magenta_concrete
fill 502 223 348 503 224 348 minecraft:purple_concrete
fill 502 223 350 503 225 350 minecraft:red_concrete
fill 503 223 339 504 225 339 minecraft:white_concrete
fill 503 223 340 503 224 340 minecraft:magenta_concrete
fill 503 223 341 503 224 342 minecraft:purple_concrete
fill 503 223 343 503 224 343 minecraft:magenta_concrete
fill 503 223 344 504 224 344 minecraft:purple_concrete
fill 503 223 346 503 224 346 minecraft:magenta_concrete
fill 503 223 347 503 224 347 minecraft:purple_concrete
fill 503 223 349 504 225 349 minecraft:red_concrete
fill 504 223 340 504 225 341 minecraft:white_concrete
fill 504 223 342 504 224 342 minecraft:magenta_concrete
fill 504 223 343 504 224 343 minecraft:purple_concrete
fill 504 223 345 504 224 345 minecraft:magenta_concrete
fill 504 223 346 504 224 346 minecraft:purple_concrete
fill 504 223 347 504 225 348 minecraft:red_concrete
fill 505 223 341 505 225 343 minecraft:white_concrete
fill 505 223 344 505 225 347 minecraft:red_concrete
setblock 471 224 323 minecraft:yellow_concrete
fill 471 224 324 471 224 327 minecraft:purple_concrete
setblock 471 224 328 minecraft:yellow_concrete
fill 471 224 329 471 224 332 minecraft:purple_concrete
setblock 471 224 333 minecraft:yellow_concrete
fill 471 224 334 471 224 337 minecraft:purple_concrete
setblock 471 224 338 minecraft:yellow_concrete
fill 471 224 339 471 224 342 minecraft:purple_concrete
setblock 471 224 343 minecraft:yellow_concrete
fill 471 224 344 471 224 347 minecraft:purple_concrete
setblock 471 224 348 minecraft:yellow_concrete
fill 471 224 349 471 224 352 minecraft:purple_concrete
setblock 471 224 353 minecraft:yellow_concrete
fill 471 224 354 471 224 357 minecraft:purple_concrete
setblock 471 224 358 minecraft:yellow_concrete
fill 471 224 359 471 224 362 minecraft:purple_concrete
setblock 471 224 363 minecraft:yellow_concrete
fill 472 224 323 475 224 323 minecraft:purple_concrete
setblock 472 224 324 minecraft:yellow_concrete
fill 472 224 325 472 224 328 minecraft:purple_concrete
setblock 472 224 329 minecraft:yellow_concrete
fill 472 224 330 472 224 333 minecraft:purple_concrete
setblock 472 224 334 minecraft:yellow_concrete
fill 472 224 335 472 224 338 minecraft:purple_concrete
setblock 472 224 339 minecraft:yellow_concrete
fill 472 224 340 472 224 343 minecraft:purple_concrete
setblock 472 224 344 minecraft:yellow_concrete
fill 472 224 345 472 224 348 minecraft:purple_concrete
setblock 472 224 349 minecraft:yellow_concrete
fill 472 224 350 472 224 353 minecraft:purple_concrete
setblock 472 224 354 minecraft:yellow_concrete
fill 472 224 355 472 224 358 minecraft:purple_concrete
setblock 472 224 359 minecraft:yellow_concrete
fill 472 224 360 472 224 363 minecraft:purple_concrete
fill 473 224 324 476 224 324 minecraft:purple_concrete
setblock 473 224 325 minecraft:yellow_concrete
fill 473 224 326 473 224 329 minecraft:purple_concrete
setblock 473 224 330 minecraft:yellow_concrete
fill 473 224 331 473 224 334 minecraft:purple_concrete
setblock 473 224 335 minecraft:yellow_concrete
fill 473 224 336 473 224 339 minecraft:purple_concrete
setblock 473 224 340 minecraft:yellow_concrete
fill 473 224 341 473 224 344 minecraft:purple_concrete
setblock 473 224 345 minecraft:yellow_concrete
fill 473 224 346 473 224 349 minecraft:purple_concrete
setblock 473 224 350 minecraft:yellow_concrete
fill 473 224 351 473 224 354 minecraft:purple_concrete
setblock 473 224 355 minecraft:yellow_concrete
fill 473 224 356 473 224 359 minecraft:purple_concrete
setblock 473 224 360 minecraft:yellow_concrete
fill 473 224 361 473 224 363 minecraft:purple_concrete
fill 474 224 325 477 224 325 minecraft:purple_concrete
setblock 474 224 326 minecraft:yellow_concrete
fill 474 224 327 474 224 330 minecraft:purple_concrete
setblock 474 224 331 minecraft:yellow_concrete
fill 474 224 332 474 224 335 minecraft:purple_concrete
setblock 474 224 336 minecraft:yellow_concrete
fill 474 224 337 474 224 340 minecraft:purple_concrete
setblock 474 224 341 minecraft:yellow_concrete
fill 474 224 342 474 224 345 minecraft:purple_concrete
setblock 474 224 346 minecraft:yellow_concrete
fill 474 224 347 474 224 350 minecraft:purple_concrete
setblock 474 224 351 minecraft:yellow_concrete
fill 474 224 352 474 224 355 minecraft:purple_concrete
setblock 474 224 356 minecraft:yellow_concrete
fill 474 224 357 474 224 360 minecraft:purple_concrete
setblock 474 224 361 minecraft:yellow_concrete
fill 474 224 362 474 224 363 minecraft:purple_concrete
fill 475 224 326 478 224 326 minecraft:purple_concrete
setblock 475 224 327 minecraft:yellow_concrete
fill 475 224 328 475 224 331 minecraft:purple_concrete
setblock 475 224 332 minecraft:yellow_concrete
fill 475 224 333 475 224 336 minecraft:purple_concrete
setblock 475 224 337 minecraft:yellow_concrete
fill 475 224 338 475 224 341 minecraft:purple_concrete
setblock 475 224 342 minecraft:yellow_concrete
fill 475 224 343 475 224 346 minecraft:purple_concrete
setblock 475 224 347 minecraft:yellow_concrete
fill 475 224 348 475 224 351 minecraft:purple_concrete
setblock 475 224 352 minecraft:yellow_concrete
fill 475 224 353 475 224 356 minecraft:purple_concrete
setblock 475 224 357 minecraft:yellow_concrete
fill 475 224 358 475 224 361 minecraft:purple_concrete
setblock 475 224 362 minecraft:yellow_concrete
setblock 475 224 363 minecraft:purple_concrete
setblock 476 224 323 minecraft:yellow_concrete
fill 476 224 327 479 224 327 minecraft:purple_concrete
setblock 476 224 328 minecraft:yellow_concrete
fill 476 224 329 476 224 332 minecraft:purple_concrete
setblock 476 224 333 minecraft:yellow_concrete
fill 476 224 334 476 224 337 minecraft:purple_concrete
setblock 476 224 338 minecraft:yellow_concrete
fill 476 224 339 476 224 342 minecraft:purple_concrete
setblock 476 224 343 minecraft:yellow_concrete
fill 476 224 344 476 224 347 minecraft:purple_concrete
setblock 476 224 348 minecraft:yellow_concrete
fill 476 224 349 476 224 352 minecraft:purple_concrete
setblock 476 224 353 minecraft:yellow_concrete
fill 476 224 354 476 224 357 minecraft:purple_concrete
setblock 476 224 358 minecraft:yellow_concrete
fill 476 224 359 476 224 362 minecraft:purple_concrete
setblock 476 224 363 minecraft:yellow_concrete
fill 477 224 323 480 224 323 minecraft:purple_concrete
setblock 477 224 324 minecraft:yellow_concrete
fill 477 224 328 480 224 328 minecraft:purple_concrete
setblock 477 224 329 minecraft:yellow_concrete
fill 477 224 330 477 224 333 minecraft:purple_concrete
setblock 477 224 334 minecraft:yellow_concrete
fill 477 224 335 477 224 338 minecraft:purple_concrete
setblock 477 224 339 minecraft:yellow_concrete
fill 477 224 340 477 224 343 minecraft:purple_concrete
setblock 477 224 344 minecraft:yellow_concrete
fill 477 224 345 477 224 348 minecraft:purple_concrete
setblock 477 224 349 minecraft:yellow_concrete
fill 477 224 350 477 224 353 minecraft:purple_concrete
setblock 477 224 354 minecraft:yellow_concrete
fill 477 224 355 477 224 358 minecraft:purple_concrete
setblock 477 224 359 minecraft:yellow_concrete
fill 477 224 360 477 224 363 minecraft:purple_concrete
fill 478 224 324 481 224 324 minecraft:purple_concrete
setblock 478 224 325 minecraft:yellow_concrete
fill 478 224 329 481 224 329 minecraft:purple_concrete
setblock 478 224 330 minecraft:yellow_concrete
fill 478 224 331 478 224 334 minecraft:purple_concrete
setblock 478 224 335 minecraft:yellow_concrete
fill 478 224 336 478 224 339 minecraft:purple_concrete
setblock 478 224 340 minecraft:yellow_concrete
fill 478 224 341 478 224 344 minecraft:purple_concrete
setblock 478 224 345 minecraft:yellow_concrete
fill 478 224 346 478 224 349 minecraft:purple_concrete
setblock 478 224 350 minecraft:yellow_concrete
fill 478 224 351 478 224 354 minecraft:purple_concrete
setblock 478 224 355 minecraft:yellow_concrete
fill 478 224 356 478 224 359 minecraft:purple_concrete
setblock 478 224 360 minecraft:yellow_concrete
fill 478 224 361 478 224 363 minecraft:purple_concrete
fill 479 224 325 482 224 325 minecraft:purple_concrete
setblock 479 224 326 minecraft:yellow_concrete
fill 479 224 330 482 224 330 minecraft:purple_concrete
setblock 479 224 331 minecraft:yellow_concrete
fill 479 224 332 479 224 335 minecraft:purple_concrete
setblock 479 224 336 minecraft:yellow_concrete
fill 479 224 337 479 224 340 minecraft:purple_concrete
setblock 479 224 341 minecraft:yellow_concrete
fill 479 224 342 479 224 345 minecraft:purple_concrete
setblock 479 224 346 minecraft:yellow_concrete
fill 479 224 347 479 224 350 minecraft:purple_concrete
setblock 479 224 351 minecraft:yellow_concrete
fill 479 224 352 479 224 355 minecraft:purple_concrete
setblock 479 224 356 minecraft:yellow_concrete
fill 479 224 357 479 224 360 minecraft:purple_concrete
setblock 479 224 361 minecraft:yellow_concrete
fill 479 224 362 479 224 363 minecraft:purple_concrete
fill 480 224 326 483 224 326 minecraft:purple_concrete
setblock 480 224 327 minecraft:yellow_concrete
fill 480 224 331 483 224 331 minecraft:purple_concrete
setblock 480 224 332 minecraft:yellow_concrete
fill 480 224 333 480 224 336 minecraft:purple_concrete
setblock 480 224 337 minecraft:yellow_concrete
fill 480 224 338 480 224 341 minecraft:purple_concrete
setblock 480 224 342 minecraft:yellow_concrete
fill 480 224 343 480 224 346 minecraft:purple_concrete
setblock 480 224 347 minecraft:yellow_concrete
fill 480 224 348 480 224 351 minecraft:purple_concrete
setblock 480 224 352 minecraft:yellow_concrete
fill 480 224 353 480 224 356 minecraft:purple_concrete
setblock 480 224 357 minecraft:yellow_concrete
fill 480 224 358 480 224 361 minecraft:purple_concrete
setblock 480 224 362 minecraft:yellow_concrete
setblock 480 224 363 minecraft:purple_concrete
setblock 481 224 323 minecraft:yellow_concrete
fill 481 224 327 484 224 327 minecraft:purple_concrete
setblock 481 224 328 minecraft:yellow_concrete
fill 481 224 332 484 224 332 minecraft:purple_concrete
setblock 481 224 333 minecraft:yellow_concrete
fill 481 224 334 481 224 337 minecraft:purple_concrete
setblock 481 224 338 minecraft:yellow_concrete
fill 481 224 339 481 224 342 minecraft:purple_concrete
setblock 481 224 343 minecraft:yellow_concrete
fill 481 224 344 481 224 347 minecraft:purple_concrete
setblock 481 224 348 minecraft:yellow_concrete
fill 481 224 349 481 224 352 minecraft:purple_concrete
setblock 481 224 353 minecraft:yellow_concrete
fill 481 224 354 481 224 357 minecraft:purple_concrete
setblock 481 224 358 minecraft:yellow_concrete
fill 481 224 359 481 224 362 minecraft:purple_concrete
setblock 481 224 363 minecraft:yellow_concrete
fill 482 224 323 485 224 323 minecraft:purple_concrete
setblock 482 224 324 minecraft:yellow_concrete
fill 482 224 328 485 224 328 minecraft:purple_concrete
setblock 482 224 329 minecraft:yellow_concrete
fill 482 224 333 485 224 333 minecraft:purple_concrete
setblock 482 224 334 minecraft:yellow_concrete
fill 482 224 335 482 224 338 minecraft:purple_concrete
setblock 482 224 339 minecraft:yellow_concrete
fill 482 224 340 482 224 343 minecraft:purple_concrete
setblock 482 224 344 minecraft:yellow_concrete
fill 482 224 345 482 224 348 minecraft:purple_concrete
setblock 482 224 349 minecraft:yellow_concrete
fill 482 224 350 482 224 353 minecraft:purple_concrete
setblock 482 224 354 minecraft:yellow_concrete
fill 482 224 355 482 224 358 minecraft:purple_concrete
setblock 482 224 359 minecraft:yellow_concrete
fill 482 224 360 482 224 363 minecraft:purple_concrete
fill 483 224 324 486 224 324 minecraft:purple_concrete
setblock 483 224 325 minecraft:yellow_concrete
fill 483 224 329 486 224 329 minecraft:purple_concrete
setblock 483 224 330 minecraft:yellow_concrete
fill 483 224 334 486 224 334 minecraft:purple_concrete
setblock 483 224 335 minecraft:yellow_concrete
fill 483 224 336 483 224 339 minecraft:purple_concrete
setblock 483 224 340 minecraft:yellow_concrete
fill 483 224 341 483 224 344 minecraft:purple_concrete
setblock 483 224 345 minecraft:yellow_concrete
fill 483 224 346 483 224 349 minecraft:purple_concrete
setblock 483 224 350 minecraft:yellow_concrete
fill 483 224 351 483 224 354 minecraft:purple_concrete
setblock 483 224 355 minecraft:yellow_concrete
fill 483 224 356 483 224 359 minecraft:purple_concrete
setblock 483 224 360 minecraft:yellow_concrete
fill 483 224 361 483 224 363 minecraft:purple_concrete
fill 484 224 325 487 224 325 minecraft:purple_concrete
setblock 484 224 326 minecraft:yellow_concrete
fill 484 224 330 487 224 330 minecraft:purple_concrete
setblock 484 224 331 minecraft:yellow_concrete
fill 484 224 335 487 224 335 minecraft:purple_concrete
setblock 484 224 336 minecraft:yellow_concrete
fill 484 224 337 484 224 340 minecraft:purple_concrete
setblock 484 224 341 minecraft:yellow_concrete
fill 484 224 342 484 224 345 minecraft:purple_concrete
setblock 484 224 346 minecraft:yellow_concrete
fill 484 224 347 484 224 350 minecraft:purple_concrete
setblock 484 224 351 minecraft:yellow_concrete
fill 484 224 352 484 224 355 minecraft:purple_concrete
setblock 484 224 356 minecraft:yellow_concrete
fill 484 224 357 484 224 360 minecraft:purple_concrete
setblock 484 224 361 minecraft:yellow_concrete
fill 484 224 362 484 224 363 minecraft:purple_concrete
fill 485 224 326 488 224 326 minecraft:purple_concrete
setblock 485 224 327 minecraft:yellow_concrete
fill 485 224 331 488 224 331 minecraft:purple_concrete
setblock 485 224 332 minecraft:yellow_concrete
fill 485 224 336 488 224 336 minecraft:purple_concrete
setblock 485 224 337 minecraft:yellow_concrete
fill 485 224 338 485 224 341 minecraft:purple_concrete
setblock 485 224 342 minecraft:yellow_concrete
fill 485 224 343 485 224 346 minecraft:purple_concrete
setblock 485 224 347 minecraft:yellow_concrete
fill 485 224 348 485 224 351 minecraft:purple_concrete
setblock 485 224 352 minecraft:yellow_concrete
fill 485 224 353 485 224 356 minecraft:purple_concrete
setblock 485 224 357 minecraft:yellow_concrete
fill 485 224 358 485 224 361 minecraft:purple_concrete
setblock 485 224 362 minecraft:yellow_concrete
setblock 485 224 363 minecraft:purple_concrete
setblock 486 224 323 minecraft:yellow_concrete
fill 486 224 327 489 224 327 minecraft:purple_concrete
setblock 486 224 328 minecraft:yellow_concrete
fill 486 224 332 489 224 332 minecraft:purple_concrete
setblock 486 224 333 minecraft:yellow_concrete
fill 486 224 337 489 224 337 minecraft:purple_concrete
setblock 486 224 338 minecraft:yellow_concrete
fill 486 224 339 486 224 342 minecraft:purple_concrete
setblock 486 224 343 minecraft:yellow_concrete
fill 486 224 344 486 224 347 minecraft:purple_concrete
setblock 486 224 348 minecraft:yellow_concrete
fill 486 224 349 486 224 352 minecraft:purple_concrete
setblock 486 224 353 minecraft:yellow_concrete
fill 486 224 354 486 224 357 minecraft:purple_concrete
setblock 486 224 358 minecraft:yellow_concrete
fill 486 224 359 486 224 362 minecraft:purple_concrete
setblock 486 224 363 minecraft:yellow_concrete
fill 487 224 323 490 224 323 minecraft:purple_concrete
setblock 487 224 324 minecraft:yellow_concrete
fill 487 224 328 490 224 328 minecraft:purple_concrete
setblock 487 224 329 minecraft:yellow_concrete
fill 487 224 333 490 224 333 minecraft:purple_concrete
setblock 487 224 334 minecraft:yellow_concrete
fill 487 224 338 490 224 338 minecraft:purple_concrete
setblock 487 224 339 minecraft:yellow_concrete
fill 487 224 340 487 224 343 minecraft:purple_concrete
setblock 487 224 344 minecraft:yellow_concrete
fill 487 224 345 487 224 348 minecraft:purple_concrete
setblock 487 224 349 minecraft:yellow_concrete
fill 487 224 350 487 224 353 minecraft:purple_concrete
setblock 487 224 354 minecraft:yellow_concrete
fill 487 224 355 487 224 358 minecraft:purple_concrete
setblock 487 224 359 minecraft:yellow_concrete
fill 487 224 360 487 224 363 minecraft:purple_concrete
fill 488 224 324 491 224 324 minecraft:purple_concrete
setblock 488 224 325 minecraft:yellow_concrete
fill 488 224 329 491 224 329 minecraft:purple_concrete
setblock 488 224 330 minecraft:yellow_concrete
fill 488 224 334 491 224 334 minecraft:purple_concrete
setblock 488 224 335 minecraft:yellow_concrete
fill 488 224 339 489 224 339 minecraft:purple_concrete
setblock 488 224 340 minecraft:yellow_concrete
fill 488 224 341 488 224 343 minecraft:purple_concrete
setblock 488 224 344 minecraft:red_concrete
setblock 488 224 345 minecraft:yellow_concrete
fill 488 224 346 488 224 349 minecraft:purple_concrete
setblock 488 224 350 minecraft:yellow_concrete
fill 488 224 351 488 224 354 minecraft:purple_concrete
setblock 488 224 355 minecraft:yellow_concrete
fill 488 224 356 488 224 359 minecraft:purple_concrete
setblock 488 224 360 minecraft:yellow_concrete
fill 488 224 361 488 224 363 minecraft:purple_concrete
fill 489 224 325 492 224 325 minecraft:purple_concrete
setblock 489 224 326 minecraft:yellow_concrete
fill 489 224 330 492 224 330 minecraft:purple_concrete
setblock 489 224 331 minecraft:yellow_concrete
fill 489 224 335 492 224 335 minecraft:purple_concrete
setblock 489 224 336 minecraft:yellow_concrete
setblock 489 224 340 minecraft:red_concrete
setblock 489 224 348 minecraft:white_concrete
fill 489 224 349 489 224 350 minecraft:purple_concrete
setblock 489 224 351 minecraft:yellow_concrete
fill 489 224 352 489 224 355 minecraft:purple_concrete
setblock 489 224 356 minecraft:yellow_concrete
fill 489 224 357 489 224 360 minecraft:purple_concrete
setblock 489 224 361 minecraft:yellow_concrete
fill 489 224 362 489 224 363 minecraft:purple_concrete
fill 490 224 326 493 224 326 minecraft:purple_concrete
setblock 490 224 327 minecraft:yellow_concrete
fill 490 224 331 493 224 331 minecraft:purple_concrete
setblock 490 224 332 minecraft:yellow_concrete
fill 490 224 336 492 224 336 minecraft:purple_concrete
setblock 490 224 337 minecraft:yellow_concrete
fill 490 224 350 490 224 351 minecraft:purple_concrete
setblock 490 224 352 minecraft:yellow_concrete
fill 490 224 353 490 224 356 minecraft:purple_concrete
setblock 490 224 357 minecraft:yellow_concrete
fill 490 224 358 490 224 361 minecraft:purple_concrete
setblock 490 224 362 minecraft:yellow_concrete
setblock 490 224 363 minecraft:purple_concrete
setblock 491 224 323 minecraft:yellow_concrete
fill 491 224 327 494 224 327 minecraft:purple_concrete
setblock 491 224 328 minecraft:yellow_concrete
fill 491 224 332 494 224 332 minecraft:purple_concrete
setblock 491 224 333 minecraft:yellow_concrete
setblock 491 224 337 minecraft:purple_concrete
fill 491 224 351 491 224 352 minecraft:purple_concrete
setblock 491 224 353 minecraft:yellow_concrete
fill 491 224 354 491 224 357 minecraft:purple_concrete
setblock 491 224 358 minecraft:yellow_concrete
fill 491 224 359 491 224 362 minecraft:purple_concrete
setblock 491 224 363 minecraft:yellow_concrete
fill 492 224 323 495 224 323 minecraft:purple_concrete
setblock 492 224 324 minecraft:yellow_concrete
fill 492 224 328 495 224 328 minecraft:purple_concrete
setblock 492 224 329 minecraft:yellow_concrete
fill 492 224 333 495 224 333 minecraft:purple_concrete
setblock 492 224 334 minecraft:yellow_concrete
fill 492 224 352 492 224 353 minecraft:purple_concrete
setblock 492 224 354 minecraft:yellow_concrete
fill 492 224 355 492 224 358 minecraft:purple_concrete
setblock 492 224 359 minecraft:yellow_concrete
fill 492 224 360 492 224 363 minecraft:purple_concrete
fill 493 224 324 496 224 324 minecraft:purple_concrete
setblock 493 224 325 minecraft:yellow_concrete
fill 493 224 329 496 224 329 minecraft:purple_concrete
setblock 493 224 330 minecraft:yellow_concrete
fill 493 224 334 496 224 334 minecraft:purple_concrete
setblock 493 224 335 minecraft:yellow_concrete
setblock 493 224 336 minecraft:red_concrete
setblock 493 224 352 minecraft:white_concrete
fill 493 224 353 495 224 354 minecraft:purple_concrete
setblock 493 224 355 minecraft:yellow_concrete
fill 493 224 356 493 224 359 minecraft:purple_concrete
setblock 493 224 360 minecraft:yellow_concrete
fill 493 224 361 493 224 363 minecraft:purple_concrete
fill 494 224 325 497 224 325 minecraft:purple_concrete
setblock 494 224 326 minecraft:yellow_concrete
fill 494 224 330 497 224 330 minecraft:purple_concrete
setblock 494 224 331 minecraft:yellow_concrete
fill 494 224 335 496 224 335 minecraft:purple_concrete
setblock 494 224 341 minecraft:purple_concrete
fill 494 224 342 494 224 346 minecraft:sea_lantern
setblock 494 224 347 minecraft:purple_concrete
fill 494 224 355 497 224 355 minecraft:purple_concrete
setblock 494 224 356 minecraft:yellow_concrete
fill 494 224 357 494 224 360 minecraft:purple_concrete
setblock 494 224 361 minecraft:yellow_concrete
fill 494 224 362 494 224 363 minecraft:purple_concrete
fill 495 224 326 498 224 326 minecraft:purple_concrete
setblock 495 224 327 minecraft:yellow_concrete
fill 495 224 331 498 224 331 minecraft:purple_concrete
setblock 495 224 332 minecraft:yellow_concrete
setblock 495 224 340 minecraft:purple_concrete
fill 495 224 341 495 224 342 minecraft:sea_lantern
fill 495 224 346 495 224 347 minecraft:sea_lantern
fill 495 224 356 498 224 356 minecraft:purple_concrete
setblock 495 224 357 minecraft:yellow_concrete
fill 495 224 358 495 224 361 minecraft:purple_concrete
setblock 495 224 362 minecraft:yellow_concrete
setblock 495 224 363 minecraft:purple_concrete
setblock 496 224 323 minecraft:yellow_concrete
fill 496 224 327 499 224 327 minecraft:purple_concrete
setblock 496 224 328 minecraft:yellow_concrete
fill 496 224 332 499 224 332 minecraft:purple_concrete
setblock 496 224 333 minecraft:yellow_concrete
fill 496 224 341 499 224 341 minecraft:sea_lantern
fill 496 224 347 499 224 347 minecraft:sea_lantern
setblock 496 224 353 minecraft:yellow_concrete
setblock 496 224 354 minecraft:purple_concrete
fill 496 224 357 499 224 357 minecraft:purple_concrete
setblock 496 224 358 minecraft:yellow_concrete
fill 496 224 359 496 224 362 minecraft:purple_concrete
setblock 496 224 363 minecraft:yellow_concrete
fill 497 224 323 500 224 323 minecraft:purple_concrete
setblock 497 224 324 minecraft:yellow_concrete
fill 497 224 328 500 224 328 minecraft:purple_concrete
setblock 497 224 329 minecraft:yellow_concrete
fill 497 224 333 500 224 333 minecraft:purple_concrete
setblock 497 224 334 minecraft:yellow_concrete
setblock 497 224 335 minecraft:white_concrete
setblock 497 224 353 minecraft:white_concrete
setblock 497 224 354 minecraft:yellow_concrete
fill 497 224 358 500 224 358 minecraft:purple_concrete
setblock 497 224 359 minecraft:yellow_concrete
fill 497 224 360 497 224 363 minecraft:purple_concrete
fill 498 224 324 501 224 324 minecraft:purple_concrete
setblock 498 224 325 minecraft:yellow_concrete
fill 498 224 329 501 224 329 minecraft:purple_concrete
setblock 498 224 330 minecraft:yellow_concrete
fill 498 224 334 501 224 334 minecraft:purple_concrete
setblock 498 224 335 minecraft:yellow_concrete
fill 498 224 353 500 224 354 minecraft:purple_concrete
setblock 498 224 355 minecraft:yellow_concrete
fill 498 224 359 501 224 359 minecraft:purple_concrete
setblock 498 224 360 minecraft:yellow_concrete
fill 498 224 361 498 224 363 minecraft:purple_concrete
fill 499 224 325 502 224 325 minecraft:purple_concrete
setblock 499 224 326 minecraft:yellow_concrete
fill 499 224 330 502 224 330 minecraft:purple_concrete
setblock 499 224 331 minecraft:yellow_concrete
fill 499 224 335 502 224 335 minecraft:purple_concrete
fill 499 224 342 500 224 342 minecraft:sea_lantern
fill 499 224 346 500 224 346 minecraft:sea_lantern
fill 499 224 355 502 224 355 minecraft:purple_concrete
setblock 499 224 356 minecraft:yellow_concrete
fill 499 224 360 502 224 360 minecraft:purple_concrete
setblock 499 224 361 minecraft:yellow_concrete
fill 499 224 362 499 224 363 minecraft:purple_concrete
fill 500 224 326 503 224 326 minecraft:purple_concrete
setblock 500 224 327 minecraft:yellow_concrete
fill 500 224 331 503 224 331 minecraft:purple_concrete
setblock 500 224 332 minecraft:yellow_concrete
fill 500 224 343 500 224 345 minecraft:sea_lantern
fill 500 224 356 503 224 356 minecraft:purple_concrete
setblock 500 224 357 minecraft:yellow_concrete
fill 500 224 361 503 224 361 minecraft:purple_concrete
setblock 500 224 362 minecraft:yellow_concrete
setblock 500 224 363 minecraft:purple_concrete
setblock 501 224 323 minecraft:yellow_concrete
fill 501 224 327 504 224 327 minecraft:purple_concrete
setblock 501 224 328 minecraft:yellow_concrete
fill 501 224 332 504 224 332 minecraft:purple_concrete
setblock 501 224 333 minecraft:yellow_concrete
setblock 501 224 336 minecraft:white_concrete
setblock 501 224 352 minecraft:red_concrete
setblock 501 224 353 minecraft:yellow_concrete
setblock 501 224 354 minecraft:purple_concrete
fill 501 224 357 504 224 357 minecraft:purple_concrete
setblock 501 224 358 minecraft:yellow_concrete
fill 501 224 362 504 224 362 minecraft:purple_concrete
setblock 501 224 363 minecraft:yellow_concrete
fill 502 224 323 505 224 323 minecraft:purple_concrete
setblock 502 224 324 minecraft:yellow_concrete
fill 502 224 328 505 224 328 minecraft:purple_concrete
setblock 502 224 329 minecraft:yellow_concrete
fill 502 224 333 505 224 333 minecraft:purple_concrete
setblock 502 224 334 minecraft:yellow_concrete
fill 502 224 336 503 224 336 minecraft:purple_concrete
fill 502 224 352 504 224 353 minecraft:purple_concrete
setblock 502 224 354 minecraft:yellow_concrete
fill 502 224 358 505 224 358 minecraft:purple_concrete
setblock 502 224 359 minecraft:yellow_concrete
fill 502 224 363 505 224 363 minecraft:purple_concrete
fill 503 224 324 506 224 324 minecraft:purple_concrete
setblock 503 224 325 minecraft:yellow_concrete
fill 503 224 329 506 224 329 minecraft:purple_concrete
setblock 503 224 330 minecraft:yellow_concrete
fill 503 224 334 506 224 334 minecraft:purple_concrete
setblock 503 224 335 minecraft:yellow_concrete
fill 503 224 337 504 224 337 minecraft:purple_concrete
setblock 503 224 351 minecraft:purple_concrete
fill 503 224 354 506 224 354 minecraft:purple_concrete
setblock 503 224 355 minecraft:yellow_concrete
fill 503 224 359 506 224 359 minecraft:purple_concrete
setblock 503 224 360 minecraft:yellow_concrete
fill 504 224 325 507 224 325 minecraft:purple_concrete
setblock 504 224 326 minecraft:yellow_concrete
fill 504 224 330 507 224 330 minecraft:purple_concrete
setblock 504 224 331 minecraft:yellow_concrete
fill 504 224 335 507 224 335 minecraft:purple_concrete
setblock 504 224 336 minecraft:yellow_concrete
fill 504 224 338 505 224 338 minecraft:purple_concrete
fill 504 224 350 507 224 350 minecraft:purple_concrete
setblock 504 224 351 minecraft:yellow_concrete
fill 504 224 355 507 224 355 minecraft:purple_concrete
setblock 504 224 356 minecraft:yellow_concrete
fill 504 224 360 507 224 360 minecraft:purple_concrete
setblock 504 224 361 minecraft:yellow_concrete
fill 505 224 326 508 224 326 minecraft:purple_concrete
setblock 505 224 327 minecraft:yellow_concrete
fill 505 224 331 508 224 331 minecraft:purple_concrete
setblock 505 224 332 minecraft:yellow_concrete
fill 505 224 336 508 224 336 minecraft:purple_concrete
setblock 505 224 337 minecraft:yellow_concrete
fill 505 224 339 506 224 339 minecraft:purple_concrete
setblock 505 224 340 minecraft:white_concrete
setblock 505 224 348 minecraft:red_concrete
fill 505 224 349 506 224 349 minecraft:purple_concrete
fill 505 224 351 508 224 351 minecraft:purple_concrete
setblock 505 224 352 minecraft:yellow_concrete
setblock 505 224 353 minecraft:purple_concrete
fill 505 224 356 508 224 356 minecraft:purple_concrete
setblock 505 224 357 minecraft:yellow_concrete
fill 505 224 361 508 224 361 minecraft:purple_concrete
setblock 505 224 362 minecraft:yellow_concrete
setblock 506 224 323 minecraft:yellow_concrete
fill 506 224 327 509 224 327 minecraft:purple_concrete
setblock 506 224 328 minecraft:yellow_concrete
fill 506 224 332 509 224 332 minecraft:purple_concrete
setblock 506 224 333 minecraft:yellow_concrete
fill 506 224 337 509 224 337 minecraft:purple_concrete
setblock 506 224 338 minecraft:yellow_concrete
fill 506 224 340 507 224 342 minecraft:purple_concrete
setblock 506 224 343 minecraft:yellow_concrete
setblock 506 224 344 minecraft:red_concrete
fill 506 224 345 507 224 347 minecraft:purple_concrete
setblock 506 224 348 minecraft:yellow_concrete
fill 506 224 352 509 224 352 minecraft:purple_concrete
setblock 506 224 353 minecraft:yellow_concrete
fill 506 224 357 509 224 357 minecraft:purple_concrete
setblock 506 224 358 minecraft:yellow_concrete
fill 506 224 362 509 224 362 minecraft:purple_concrete
setblock 506 224 363 minecraft:yellow_concrete
fill 507 224 323 510 224 323 minecraft:purple_concrete
setblock 507 224 324 minecraft:yellow_concrete
fill 507 224 328 510 224 328 minecraft:purple_concrete
setblock 507 224 329 minecraft:yellow_concrete
fill 507 224 333 510 224 333 minecraft:purple_concrete
setblock 507 224 334 minecraft:yellow_concrete
fill 507 224 338 510 224 338 minecraft:purple_concrete
setblock 507 224 339 minecraft:yellow_concrete
fill 507 224 343 510 224 343 minecraft:purple_concrete
setblock 507 224 344 minecraft:yellow_concrete
fill 507 224 348 510 224 348 minecraft:purple_concrete
setblock 507 224 349 minecraft:yellow_concrete
fill 507 224 353 510 224 353 minecraft:purple_concrete
setblock 507 224 354 minecraft:yellow_concrete
fill 507 224 358 510 224 358 minecraft:purple_concrete
setblock 507 224 359 minecraft:yellow_concrete
fill 507 224 363 510 224 363 minecraft:purple_concrete
fill 508 224 324 511 224 324 minecraft:purple_concrete
setblock 508 224 325 minecraft:yellow_concrete
fill 508 224 329 511 224 329 minecraft:purple_concrete
setblock 508 224 330 minecraft:yellow_concrete
fill 508 224 334 511 224 334 minecraft:purple_concrete
setblock 508 224 335 minecraft:yellow_concrete
fill 508 224 339 511 224 339 minecraft:purple_concrete
setblock 508 224 340 minecraft:yellow_concrete
fill 508 224 341 508 224 342 minecraft:purple_concrete
fill 508 224 344 511 224 344 minecraft:purple_concrete
setblock 508 224 345 minecraft:yellow_concrete
fill 508 224 346 508 224 347 minecraft:purple_concrete
fill 508 224 349 511 224 349 minecraft:purple_concrete
setblock 508 224 350 minecraft:yellow_concrete
fill 508 224 354 511 224 354 minecraft:purple_concrete
setblock 508 224 355 minecraft:yellow_concrete
fill 508 224 359 511 224 359 minecraft:purple_concrete
setblock 508 224 360 minecraft:yellow_concrete
fill 509 224 325 511 224 325 minecraft:purple_concrete
setblock 509 224 326 minecraft:yellow_concrete
fill 509 224 330 511 224 330 minecraft:purple_concrete
setblock 509 224 331 minecraft:yellow_concrete
fill 509 224 335 511 224 335 minecraft:purple_concrete
setblock 509 224 336 minecraft:yellow_concrete
fill 509 224 340 511 224 340 minecraft:purple_concrete
setblock 509 224 341 minecraft:yellow_concrete
setblock 509 224 342 minecraft:purple_concrete
fill 509 224 345 511 224 345 minecraft:purple_concrete
setblock 509 224 346 minecraft:yellow_concrete
setblock 509 224 347 minecraft:purple_concrete
fill 509 224 350 511 224 350 minecraft:purple_concrete
setblock 509 224 351 minecraft:yellow_concrete
fill 509 224 355 511 224 355 minecraft:purple_concrete
setblock 509 224 356 minecraft:yellow_concrete
fill 509 224 360 511 224 360 minecraft:purple_concrete
setblock 509 224 361 minecraft:yellow_concrete
fill 510 224 326 511 224 326 minecraft:purple_concrete
setblock 510 224 327 minecraft:yellow_concrete
fill 510 224 331 511 224 331 minecraft:purple_concrete
setblock 510 224 332 minecraft:yellow_concrete
fill 510 224 336 511 224 336 minecraft:purple_concrete
setblock 510 224 337 minecraft:yellow_concrete
fill 510 224 341 511 224 341 minecraft:purple_concrete
setblock 510 224 342 minecraft:yellow_concrete
fill 510 224 346 511 224 346 minecraft:purple_concrete
setblock 510 224 347 minecraft:yellow_concrete
fill 510 224 351 511 224 351 minecraft:purple_concrete
setblock 510 224 352 minecraft:yellow_concrete
fill 510 224 356 511 224 356 minecraft:purple_concrete
setblock 510 224 357 minecraft:yellow_concrete
fill 510 224 361 511 224 361 minecraft:purple_concrete
setblock 510 224 362 minecraft:yellow_concrete
setblock 511 224 323 minecraft:yellow_concrete
setblock 511 224 327 minecraft:purple_concrete
setblock 511 224 328 minecraft:yellow_concrete
setblock 511 224 332 minecraft:purple_concrete
setblock 511 224 333 minecraft:yellow_concrete
setblock 511 224 337 minecraft:purple_concrete
setblock 511 224 338 minecraft:yellow_concrete
setblock 511 224 342 minecraft:purple_concrete
setblock 511 224 343 minecraft:yellow_concrete
setblock 511 224 347 minecraft:purple_concrete
setblock 511 224 348 minecraft:yellow_concrete
setblock 511 224 352 minecraft:purple_concrete
setblock 511 224 353 minecraft:yellow_concrete
setblock 511 224 357 minecraft:purple_concrete
setblock 511 224 358 minecraft:yellow_concrete
setblock 511 224 362 minecraft:purple_concrete
setblock 511 224 363 minecraft:yellow_concrete
fill 490 225 342 490 225 344 minecraft:red_concrete
fill 490 225 345 490 225 346 minecraft:white_concrete
fill 491 225 340 491 225 341 minecraft:red_concrete
fill 491 225 347 491 225 348 minecraft:white_concrete
fill 492 225 339 492 225 340 minecraft:red_concrete
fill 492 225 348 492 225 349 minecraft:white_concrete
fill 493 225 338 493 225 339 minecraft:red_concrete
fill 493 225 349 493 225 350 minecraft:white_concrete
setblock 494 225 338 minecraft:red_concrete
setblock 494 225 350 minecraft:white_concrete
fill 495 225 337 496 225 337 minecraft:red_concrete
fill 495 225 351 497 225 351 minecraft:white_concrete
fill 497 225 337 499 225 337 minecraft:white_concrete
fill 498 225 351 499 225 351 minecraft:red_concrete
fill 500 225 338 501 225 338 minecraft:white_concrete
fill 500 225 350 501 225 350 minecraft:red_concrete
fill 501 225 339 502 225 339 minecraft:white_concrete
fill 501 225 349 502 225 349 minecraft:red_concrete
fill 502 225 340 503 225 340 minecraft:white_concrete
fill 502 225 348 503 225 348 minecraft:red_concrete
setblock 503 225 341 minecraft:white_concrete
setblock 503 225 347 minecraft:red_concrete
fill 504 225 342 504 225 343 minecraft:white_concrete
fill 504 225 344 504 225 346 minecraft:red_concrete
fill 470 228 327 470 233 327 minecraft:sea_lantern
fill 470 228 335 470 233 335 minecraft:sea_lantern
fill 470 228 343 470 233 343 minecraft:sea_lantern
fill 470 228 351 470 233 351 minecraft:sea_lantern
fill 470 228 359 470 233 359 minecraft:sea_lantern
fill 471 228 329 471 272 330 minecraft:black_concrete
fill 471 228 337 471 272 338 minecraft:black_concrete
fill 471 228 345 471 272 346 minecraft:black_concrete
fill 471 228 353 471 272 354 minecraft:black_concrete
fill 471 228 361 471 272 362 minecraft:black_concrete
fill 472 228 323 473 272 323 minecraft:black_concrete
setblock 473 228 325 minecraft:light[level=14]
setblock 473 228 333 minecraft:light[level=14]
setblock 473 228 341 minecraft:light[level=14]
setblock 473 228 349 minecraft:light[level=14]
setblock 473 228 357 minecraft:light[level=14]
fill 473 228 364 473 233 364 minecraft:sea_lantern
fill 477 228 322 477 233 322 minecraft:sea_lantern
fill 477 228 363 478 272 363 minecraft:black_concrete
fill 480 228 323 481 272 323 minecraft:black_concrete
setblock 481 228 325 minecraft:light[level=14]
setblock 481 228 333 minecraft:light[level=14]
setblock 481 228 341 minecraft:light[level=14]
setblock 481 228 349 minecraft:light[level=14]
setblock 481 228 357 minecraft:light[level=14]
fill 481 228 364 481 233 364 minecraft:sea_lantern
fill 485 228 322 485 233 322 minecraft:sea_lantern
fill 485 228 363 486 272 363 minecraft:black_concrete
fill 488 228 323 489 272 323 minecraft:black_concrete
setblock 489 228 325 minecraft:light[level=14]
setblock 489 228 333 minecraft:light[level=14]
setblock 489 228 341 minecraft:light[level=14]
setblock 489 228 349 minecraft:light[level=14]
setblock 489 228 357 minecraft:light[level=14]
fill 489 228 364 489 233 364 minecraft:sea_lantern
fill 493 228 322 493 233 322 minecraft:sea_lantern
fill 493 228 363 494 272 363 minecraft:black_concrete
fill 496 228 323 497 272 323 minecraft:black_concrete
setblock 497 228 325 minecraft:light[level=14]
setblock 497 228 333 minecraft:light[level=14]
setblock 497 228 341 minecraft:light[level=14]
setblock 497 228 349 minecraft:light[level=14]
setblock 497 228 357 minecraft:light[level=14]
fill 497 228 364 497 233 364 minecraft:sea_lantern
fill 501 228 322 501 233 322 minecraft:sea_lantern
fill 501 228 363 502 272 363 minecraft:black_concrete
fill 504 228 323 505 272 323 minecraft:black_concrete
setblock 505 228 325 minecraft:light[level=14]
setblock 505 228 333 minecraft:light[level=14]
setblock 505 228 341 minecraft:light[level=14]
setblock 505 228 349 minecraft:light[level=14]
setblock 505 228 357 minecraft:light[level=14]
fill 505 228 364 505 233 364 minecraft:sea_lantern
fill 509 228 322 509 233 322 minecraft:sea_lantern
fill 509 228 363 510 272 363 minecraft:black_concrete
fill 511 228 324 511 272 325 minecraft:black_concrete
fill 511 228 332 511 272 333 minecraft:black_concrete
fill 511 228 340 511 272 341 minecraft:black_concrete
fill 511 228 348 511 272 349 minecraft:black_concrete
fill 511 228 356 511 272 357 minecraft:black_concrete
fill 512 228 327 512 233 327 minecraft:sea_lantern
fill 512 228 335 512 233 335 minecraft:sea_lantern
fill 512 228 343 512 233 343 minecraft:sea_lantern
fill 512 228 351 512 233 351 minecraft:sea_lantern
fill 512 228 359 512 233 359 minecraft:sea_lantern
fill 493 233 326 497 235 328 minecraft:yellow_concrete
fill 494 233 325 496 235 325 minecraft:yellow_concrete
fill 494 233 329 496 235 329 minecraft:yellow_concrete
fill 470 234 327 470 241 327 minecraft:blue_concrete
fill 470 234 335 470 241 335 minecraft:blue_concrete
fill 470 234 343 470 241 343 minecraft:blue_concrete
fill 470 234 351 470 241 351 minecraft:blue_concrete
fill 470 234 359 470 241 359 minecraft:blue_concrete
fill 473 234 364 473 241 364 minecraft:blue_concrete
fill 477 234 322 477 241 322 minecraft:blue_concrete
fill 481 234 364 481 241 364 minecraft:blue_concrete
fill 485 234 322 485 241 322 minecraft:blue_concrete
fill 489 234 364 489 241 364 minecraft:blue_concrete
fill 493 234 322 493 241 322 minecraft:blue_concrete
fill 497 234 364 497 241 364 minecraft:blue_concrete
fill 501 234 322 501 241 322 minecraft:blue_concrete
fill 505 234 364 505 241 364 minecraft:blue_concrete
fill 509 234 322 509 241 322 minecraft:blue_concrete
fill 512 234 327 512 241 327 minecraft:blue_concrete
fill 512 234 335 512 241 335 minecraft:blue_concrete
fill 512 234 343 512 241 343 minecraft:blue_concrete
fill 512 234 351 512 241 351 minecraft:blue_concrete
fill 512 234 359 512 241 359 minecraft:blue_concrete
setblock 473 236 325 minecraft:light[level=14]
setblock 473 236 333 minecraft:light[level=14]
setblock 473 236 341 minecraft:light[level=14]
setblock 473 236 349 minecraft:light[level=14]
setblock 473 236 357 minecraft:light[level=14]
setblock 481 236 325 minecraft:light[level=14]
setblock 481 236 333 minecraft:light[level=14]
setblock 481 236 341 minecraft:light[level=14]
setblock 481 236 349 minecraft:light[level=14]
setblock 481 236 357 minecraft:light[level=14]
setblock 489 236 325 minecraft:light[level=14]
setblock 489 236 333 minecraft:light[level=14]
setblock 489 236 341 minecraft:light[level=14]
setblock 489 236 349 minecraft:light[level=14]
setblock 489 236 357 minecraft:light[level=14]
fill 492 236 326 498 236 328 minecraft:sea_lantern
fill 493 236 325 497 236 325 minecraft:sea_lantern
fill 493 236 329 497 236 329 minecraft:sea_lantern
fill 494 236 324 496 236 324 minecraft:sea_lantern
fill 494 236 330 496 236 330 minecraft:sea_lantern
setblock 497 236 333 minecraft:light[level=14]
setblock 497 236 341 minecraft:light[level=14]
setblock 497 236 349 minecraft:light[level=14]
setblock 497 236 357 minecraft:light[level=14]
setblock 505 236 325 minecraft:light[level=14]
setblock 505 236 333 minecraft:light[level=14]
setblock 505 236 341 minecraft:light[level=14]
setblock 505 236 349 minecraft:light[level=14]
setblock 505 236 357 minecraft:light[level=14]
fill 481 237 325 485 238 329 minecraft:black_concrete
fill 483 237 323 483 238 324 minecraft:black_concrete
fill 471 238 323 471 239 328 minecraft:black_concrete
fill 471 238 331 472 238 336 minecraft:black_concrete
fill 471 238 339 472 238 344 minecraft:black_concrete
fill 471 238 347 472 238 352 minecraft:black_concrete
fill 471 238 355 472 238 360 minecraft:black_concrete
fill 471 238 363 476 239 363 minecraft:black_concrete
fill 472 238 324 472 238 330 minecraft:black_concrete
fill 472 238 337 472 238 338 minecraft:black_concrete
fill 472 238 345 472 238 346 minecraft:black_concrete
fill 472 238 353 472 238 354 minecraft:black_concrete
fill 472 238 361 472 238 362 minecraft:black_concrete
fill 473 238 324 482 238 324 minecraft:black_concrete
fill 473 238 362 511 238 362 minecraft:black_concrete
fill 474 238 323 479 239 323 minecraft:black_concrete
fill 479 238 363 484 239 363 minecraft:black_concrete
fill 482 238 323 482 239 323 minecraft:black_concrete
fill 484 238 323 487 238 324 minecraft:black_concrete
fill 487 238 363 492 239 363 minecraft:black_concrete
fill 488 238 324 510 238 324 minecraft:black_concrete
fill 490 238 323 495 239 323 minecraft:black_concrete
fill 495 238 363 500 239 363 minecraft:black_concrete
fill 498 238 323 503 239 323 minecraft:black_concrete
fill 503 238 363 508 239 363 minecraft:black_concrete
fill 506 238 323 511 239 323 minecraft:black_concrete
fill 510 238 325 510 238 361 minecraft:black_concrete
fill 511 238 326 511 239 331 minecraft:black_concrete
fill 511 238 334 511 239 339 minecraft:black_concrete
fill 511 238 342 511 239 347 minecraft:black_concrete
fill 511 238 350 511 239 355 minecraft:black_concrete
fill 511 238 358 511 239 361 minecraft:black_concrete
fill 511 238 363 511 239 363 minecraft:black_concrete
fill 471 239 331 471 239 336 minecraft:black_concrete
fill 471 239 339 471 239 344 minecraft:black_concrete
fill 471 239 347 471 239 352 minecraft:black_concrete
fill 471 239 355 471 239 360 minecraft:black_concrete
fill 483 239 323 487 239 323 minecraft:black_concrete
fill 483 239 327 483 242 327 minecraft:black_concrete
setblock 511 239 362 minecraft:black_concrete
fill 470 242 327 470 247 327 minecraft:sea_lantern
fill 470 242 335 470 247 335 minecraft:sea_lantern
fill 470 242 343 470 247 343 minecraft:sea_lantern
fill 470 242 351 470 247 351 minecraft:sea_lantern
fill 470 242 359 470 247 359 minecraft:sea_lantern
fill 473 242 364 473 247 364 minecraft:sea_lantern
fill 477 242 322 477 247 322 minecraft:sea_lantern
fill 481 242 364 481 247 364 minecraft:sea_lantern
fill 485 242 322 485 247 322 minecraft:sea_lantern
fill 489 242 364 489 247 364 minecraft:sea_lantern
fill 493 242 322 493 247 322 minecraft:sea_lantern
fill 497 242 364 497 247 364 minecraft:sea_lantern
fill 501 242 322 501 247 322 minecraft:sea_lantern
fill 505 242 364 505 247 364 minecraft:sea_lantern
fill 509 242 322 509 247 322 minecraft:sea_lantern
fill 512 242 327 512 247 327 minecraft:sea_lantern
fill 512 242 335 512 247 335 minecraft:sea_lantern
fill 512 242 343 512 247 343 minecraft:sea_lantern
fill 512 242 351 512 247 351 minecraft:sea_lantern
fill 512 242 359 512 247 359 minecraft:sea_lantern
fill 481 243 327 485 246 327 minecraft:yellow_concrete
fill 482 243 326 484 246 326 minecraft:yellow_concrete
fill 482 243 328 484 246 328 minecraft:yellow_concrete
fill 483 243 325 483 246 325 minecraft:yellow_concrete
fill 483 243 329 483 246 329 minecraft:yellow_concrete
setblock 473 244 325 minecraft:light[level=14]
setblock 473 244 333 minecraft:light[level=14]
setblock 473 244 341 minecraft:light[level=14]
setblock 473 244 349 minecraft:light[level=14]
setblock 473 244 357 minecraft:light[level=14]
setblock 481 244 325 minecraft:light[level=14]
fill 481 244 326 481 245 326 minecraft:yellow_concrete
fill 481 244 328 481 245 328 minecraft:yellow_concrete
setblock 481 244 333 minecraft:light[level=14]
setblock 481 244 341 minecraft:light[level=14]
setblock 481 244 349 minecraft:light[level=14]
setblock 481 244 357 minecraft:light[level=14]
fill 482 244 325 482 245 325 minecraft:yellow_concrete
fill 482 244 329 482 245 329 minecraft:yellow_concrete
fill 484 244 325 484 245 325 minecraft:yellow_concrete
fill 484 244 329 484 245 329 minecraft:yellow_concrete
fill 485 244 326 485 245 326 minecraft:yellow_concrete
fill 485 244 328 485 245 328 minecraft:yellow_concrete
setblock 489 244 325 minecraft:light[level=14]
setblock 489 244 333 minecraft:light[level=14]
setblock 489 244 341 minecraft:light[level=14]
setblock 489 244 349 minecraft:light[level=14]
setblock 489 244 357 minecraft:light[level=14]
setblock 497 244 325 minecraft:light[level=14]
setblock 497 244 333 minecraft:light[level=14]
setblock 497 244 341 minecraft:light[level=14]
setblock 497 244 349 minecraft:light[level=14]
setblock 497 244 357 minecraft:light[level=14]
setblock 505 244 325 minecraft:light[level=14]
setblock 505 244 333 minecraft:light[level=14]
setblock 505 244 341 minecraft:light[level=14]
setblock 505 244 349 minecraft:light[level=14]
setblock 505 244 357 minecraft:light[level=14]
setblock 483 247 327 minecraft:yellow_concrete
fill 470 248 327 470 255 327 minecraft:blue_concrete
fill 470 248 335 470 255 335 minecraft:blue_concrete
fill 470 248 343 470 255 343 minecraft:blue_concrete
fill 470 248 351 470 255 351 minecraft:blue_concrete
fill 470 248 359 470 255 359 minecraft:blue_concrete
fill 473 248 364 473 255 364 minecraft:blue_concrete
fill 477 248 322 477 255 322 minecraft:blue_concrete
fill 481 248 364 481 255 364 minecraft:blue_concrete
fill 485 248 322 485 255 322 minecraft:blue_concrete
schedule function dropper:buildpart/82_2 1t
