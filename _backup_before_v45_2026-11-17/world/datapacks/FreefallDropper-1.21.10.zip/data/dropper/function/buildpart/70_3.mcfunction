fill 511 60 314 511 62 314 minecraft:deepslate_tiles
setblock 471 61 276 minecraft:deepslate_tiles
setblock 471 61 277 minecraft:cobbled_deepslate
fill 471 61 278 471 62 278 minecraft:deepslate_tiles
setblock 471 61 282 minecraft:cobbled_deepslate
fill 471 61 283 471 62 283 minecraft:deepslate_tiles
setblock 471 61 287 minecraft:cobbled_deepslate
fill 471 61 288 471 62 288 minecraft:deepslate_tiles
setblock 471 61 292 minecraft:cobbled_deepslate
fill 471 61 293 471 62 293 minecraft:deepslate_tiles
setblock 471 61 297 minecraft:cobbled_deepslate
fill 471 61 298 471 62 298 minecraft:deepslate_tiles
setblock 471 61 302 minecraft:cobbled_deepslate
fill 471 61 303 471 62 303 minecraft:deepslate_tiles
setblock 471 61 307 minecraft:cobbled_deepslate
fill 471 61 308 471 62 308 minecraft:deepslate_tiles
fill 471 61 310 471 61 311 minecraft:deepslate_tiles
setblock 471 61 312 minecraft:cobbled_deepslate
fill 471 61 313 471 62 313 minecraft:deepslate_tiles
setblock 472 61 276 minecraft:cobbled_deepslate
fill 472 61 277 472 62 277 minecraft:deepslate_tiles
setblock 472 61 281 minecraft:cobbled_deepslate
fill 472 61 282 472 62 282 minecraft:deepslate_tiles
setblock 472 61 286 minecraft:cobbled_deepslate
fill 472 61 287 472 62 287 minecraft:deepslate_tiles
setblock 472 61 291 minecraft:cobbled_deepslate
fill 472 61 292 472 62 292 minecraft:deepslate_tiles
setblock 472 61 296 minecraft:cobbled_deepslate
fill 472 61 297 472 62 297 minecraft:deepslate_tiles
setblock 472 61 301 minecraft:cobbled_deepslate
fill 472 61 302 472 62 302 minecraft:deepslate_tiles
setblock 472 61 316 minecraft:cobbled_deepslate
fill 473 61 275 473 90 275 minecraft:cobbled_deepslate
fill 473 61 276 476 61 276 minecraft:deepslate_tiles
setblock 473 61 280 minecraft:cobbled_deepslate
fill 473 61 281 473 62 281 minecraft:deepslate_tiles
setblock 473 61 285 minecraft:cobbled_deepslate
fill 473 61 286 473 62 286 minecraft:deepslate_tiles
setblock 473 61 292 minecraft:light[level=12]
setblock 473 61 295 minecraft:cobbled_deepslate
setblock 473 61 296 minecraft:deepslate_tiles
setblock 473 61 300 minecraft:cobbled_deepslate
fill 473 61 301 473 62 301 minecraft:deepslate_tiles
setblock 473 61 306 minecraft:light[level=12]
setblock 473 61 310 minecraft:light[level=13]
setblock 473 61 313 minecraft:light[level=12]
fill 473 61 316 476 61 316 minecraft:deepslate_tiles
setblock 474 61 279 minecraft:cobbled_deepslate
fill 474 61 280 474 62 280 minecraft:deepslate_tiles
fill 474 61 282 474 62 282 minecraft:deepslate_tiles
setblock 475 61 278 minecraft:cobbled_deepslate
fill 475 61 279 475 62 279 minecraft:deepslate_tiles
setblock 476 61 277 minecraft:cobbled_deepslate
fill 476 61 278 476 62 278 minecraft:deepslate_tiles
fill 476 61 317 480 90 317 minecraft:cobbled_deepslate
setblock 477 61 276 minecraft:cobbled_deepslate
fill 477 61 277 480 61 277 minecraft:deepslate_tiles
setblock 477 61 316 minecraft:cobbled_deepslate
fill 478 61 276 478 62 276 minecraft:deepslate_tiles
setblock 478 61 316 minecraft:deepslate_tiles
setblock 480 61 278 minecraft:cobbled_deepslate
setblock 480 61 285 minecraft:light[level=12]
setblock 480 61 292 minecraft:light[level=12]
setblock 480 61 299 minecraft:light[level=12]
setblock 480 61 306 minecraft:light[level=12]
setblock 480 61 313 minecraft:light[level=12]
setblock 481 61 277 minecraft:cobbled_deepslate
fill 481 61 278 484 61 278 minecraft:deepslate_tiles
setblock 481 61 286 minecraft:light[level=13]
setblock 481 61 294 minecraft:light[level=13]
setblock 481 61 302 minecraft:light[level=13]
setblock 481 61 310 minecraft:light[level=13]
setblock 481 61 317 minecraft:redstone_block
setblock 482 61 276 minecraft:cobbled_deepslate
fill 482 61 277 482 62 277 minecraft:deepslate_tiles
fill 482 61 316 482 61 317 minecraft:cobbled_deepslate
fill 483 61 276 483 62 276 minecraft:deepslate_tiles
fill 483 61 316 483 62 316 minecraft:deepslate_tiles
fill 483 61 317 485 85 317 minecraft:cobbled_deepslate
setblock 485 61 278 minecraft:cobbled_deepslate
setblock 486 61 277 minecraft:cobbled_deepslate
fill 486 61 278 486 62 279 minecraft:deepslate_tiles
setblock 487 61 276 minecraft:cobbled_deepslate
fill 487 61 277 487 62 277 minecraft:deepslate_tiles
setblock 487 61 285 minecraft:light[level=12]
setblock 487 61 292 minecraft:light[level=12]
setblock 487 61 299 minecraft:light[level=12]
setblock 487 61 306 minecraft:light[level=12]
setblock 487 61 313 minecraft:light[level=12]
setblock 487 61 316 minecraft:cobbled_deepslate
fill 488 61 276 488 62 276 minecraft:deepslate_tiles
setblock 488 61 279 minecraft:deepslate_tiles
setblock 488 61 315 minecraft:cobbled_deepslate
fill 488 61 316 488 62 316 minecraft:deepslate_tiles
setblock 489 61 279 minecraft:cobbled_deepslate
setblock 489 61 286 minecraft:light[level=13]
setblock 489 61 294 minecraft:light[level=13]
setblock 489 61 302 minecraft:light[level=13]
setblock 489 61 310 minecraft:light[level=13]
setblock 489 61 314 minecraft:cobbled_deepslate
fill 489 61 315 489 62 315 minecraft:deepslate_tiles
setblock 490 61 278 minecraft:cobbled_deepslate
fill 490 61 279 490 62 279 minecraft:deepslate_tiles
fill 490 61 314 490 62 314 minecraft:deepslate_tiles
setblock 491 61 277 minecraft:cobbled_deepslate
fill 491 61 278 491 62 278 minecraft:deepslate_tiles
setblock 492 61 276 minecraft:cobbled_deepslate
fill 492 61 277 492 62 277 minecraft:deepslate_tiles
setblock 492 61 316 minecraft:cobbled_deepslate
fill 493 61 276 493 62 276 minecraft:deepslate_tiles
setblock 493 61 315 minecraft:cobbled_deepslate
fill 493 61 316 493 62 316 minecraft:deepslate_tiles
setblock 494 61 278 minecraft:deepslate_tiles
setblock 494 61 285 minecraft:light[level=12]
setblock 494 61 292 minecraft:light[level=12]
setblock 494 61 299 minecraft:light[level=12]
setblock 494 61 306 minecraft:light[level=12]
setblock 494 61 313 minecraft:light[level=12]
setblock 494 61 314 minecraft:cobbled_deepslate
fill 494 61 315 494 62 315 minecraft:deepslate_tiles
setblock 496 61 277 minecraft:cobbled_deepslate
setblock 497 61 276 minecraft:cobbled_deepslate
setblock 497 61 277 minecraft:deepslate_tiles
setblock 497 61 278 minecraft:light[level=13]
setblock 497 61 286 minecraft:light[level=13]
setblock 497 61 294 minecraft:light[level=13]
setblock 497 61 302 minecraft:light[level=13]
setblock 497 61 310 minecraft:light[level=13]
setblock 497 61 316 minecraft:cobbled_deepslate
fill 498 61 276 498 62 276 minecraft:deepslate_tiles
fill 498 61 316 498 62 316 minecraft:deepslate_tiles
setblock 501 61 278 minecraft:light[level=12]
setblock 501 61 285 minecraft:light[level=12]
setblock 501 61 292 minecraft:light[level=12]
setblock 501 61 299 minecraft:light[level=12]
setblock 501 61 306 minecraft:light[level=12]
setblock 501 61 313 minecraft:light[level=12]
setblock 502 61 276 minecraft:cobbled_deepslate
setblock 502 61 316 minecraft:cobbled_deepslate
fill 503 61 276 503 62 276 minecraft:deepslate_tiles
fill 503 61 316 503 62 316 minecraft:deepslate_tiles
setblock 505 61 278 minecraft:light[level=13]
setblock 505 61 286 minecraft:light[level=13]
setblock 505 61 294 minecraft:light[level=13]
setblock 505 61 302 minecraft:light[level=13]
setblock 505 61 310 minecraft:light[level=13]
setblock 506 61 277 minecraft:cobbled_deepslate
setblock 507 61 276 minecraft:cobbled_deepslate
fill 507 61 277 507 62 277 minecraft:deepslate_tiles
setblock 507 61 316 minecraft:cobbled_deepslate
fill 508 61 276 508 62 276 minecraft:deepslate_tiles
fill 508 61 278 509 61 278 minecraft:deepslate_tiles
setblock 508 61 285 minecraft:light[level=12]
setblock 508 61 292 minecraft:light[level=12]
setblock 508 61 295 minecraft:cobbled_deepslate
fill 508 61 296 508 62 296 minecraft:deepslate_tiles
setblock 508 61 300 minecraft:cobbled_deepslate
fill 508 61 301 508 62 301 minecraft:deepslate_tiles
setblock 508 61 304 minecraft:deepslate_tiles
setblock 508 61 306 minecraft:light[level=12]
setblock 508 61 313 minecraft:light[level=12]
fill 508 61 316 508 62 316 minecraft:deepslate_tiles
setblock 509 61 279 minecraft:cobbled_deepslate
fill 509 61 280 510 61 282 minecraft:deepslate_tiles
setblock 509 61 294 minecraft:cobbled_deepslate
fill 509 61 295 509 62 295 minecraft:deepslate_tiles
setblock 509 61 299 minecraft:cobbled_deepslate
fill 509 61 300 509 62 300 minecraft:deepslate_tiles
setblock 509 61 304 minecraft:cobbled_deepslate
fill 509 61 305 509 62 305 minecraft:deepslate_tiles
setblock 509 61 315 minecraft:deepslate_tiles
setblock 510 61 278 minecraft:cobbled_deepslate
fill 510 61 279 511 62 279 minecraft:deepslate_tiles
setblock 510 61 283 minecraft:cobbled_deepslate
fill 510 61 284 510 61 287 minecraft:deepslate_tiles
setblock 510 61 288 minecraft:cobbled_deepslate
fill 510 61 289 510 62 289 minecraft:deepslate_tiles
setblock 510 61 293 minecraft:cobbled_deepslate
fill 510 61 294 510 62 294 minecraft:deepslate_tiles
setblock 510 61 298 minecraft:cobbled_deepslate
fill 510 61 299 510 62 299 minecraft:deepslate_tiles
setblock 510 61 303 minecraft:cobbled_deepslate
fill 510 61 304 510 62 304 minecraft:deepslate_tiles
fill 510 61 306 510 61 307 minecraft:deepslate_tiles
setblock 510 61 308 minecraft:cobbled_deepslate
fill 510 61 309 510 62 309 minecraft:deepslate_tiles
setblock 511 61 277 minecraft:cobbled_deepslate
fill 511 61 278 511 62 278 minecraft:deepslate_tiles
fill 511 61 280 511 61 281 minecraft:deepslate_tiles
setblock 511 61 282 minecraft:cobbled_deepslate
fill 511 61 283 511 62 283 minecraft:deepslate_tiles
setblock 511 61 287 minecraft:cobbled_deepslate
fill 511 61 288 511 62 288 minecraft:deepslate_tiles
setblock 511 61 292 minecraft:cobbled_deepslate
fill 511 61 293 511 62 293 minecraft:deepslate_tiles
setblock 511 61 297 minecraft:cobbled_deepslate
fill 511 61 298 511 62 298 minecraft:deepslate_tiles
setblock 511 61 302 minecraft:cobbled_deepslate
fill 511 61 303 511 62 303 minecraft:deepslate_tiles
setblock 511 61 307 minecraft:cobbled_deepslate
fill 511 61 308 511 62 308 minecraft:deepslate_tiles
setblock 511 61 312 minecraft:cobbled_deepslate
fill 511 61 313 511 62 313 minecraft:deepslate_tiles
fill 470 62 288 470 90 288 minecraft:cobbled_deepslate
setblock 470 62 289 minecraft:white_wool
fill 470 62 290 470 76 295 minecraft:cobbled_deepslate
setblock 471 62 276 minecraft:cobbled_deepslate
setblock 471 62 277 minecraft:deepslate_tiles
setblock 471 62 281 minecraft:cobbled_deepslate
setblock 471 62 282 minecraft:deepslate_tiles
setblock 471 62 286 minecraft:cobbled_deepslate
setblock 471 62 287 minecraft:deepslate_tiles
setblock 471 62 291 minecraft:cobbled_deepslate
setblock 471 62 292 minecraft:deepslate_tiles
setblock 471 62 296 minecraft:cobbled_deepslate
setblock 471 62 297 minecraft:deepslate_tiles
setblock 471 62 301 minecraft:cobbled_deepslate
setblock 471 62 302 minecraft:deepslate_tiles
setblock 471 62 306 minecraft:cobbled_deepslate
setblock 471 62 307 minecraft:deepslate_tiles
setblock 471 62 310 minecraft:deepslate_tiles
setblock 471 62 316 minecraft:cobbled_deepslate
fill 472 62 276 475 62 276 minecraft:deepslate_tiles
setblock 472 62 280 minecraft:cobbled_deepslate
setblock 472 62 281 minecraft:deepslate_tiles
setblock 472 62 284 minecraft:deepslate_tiles
setblock 472 62 285 minecraft:cobbled_deepslate
setblock 472 62 286 minecraft:deepslate_tiles
setblock 472 62 290 minecraft:cobbled_deepslate
setblock 472 62 291 minecraft:deepslate_tiles
setblock 472 62 295 minecraft:cobbled_deepslate
setblock 472 62 296 minecraft:deepslate_tiles
setblock 472 62 300 minecraft:cobbled_deepslate
setblock 472 62 301 minecraft:deepslate_tiles
setblock 472 62 305 minecraft:cobbled_deepslate
fill 472 62 316 475 62 316 minecraft:deepslate_tiles
setblock 473 62 279 minecraft:cobbled_deepslate
setblock 473 62 280 minecraft:deepslate_tiles
setblock 473 62 284 minecraft:cobbled_deepslate
setblock 473 62 285 minecraft:deepslate_tiles
setblock 473 62 299 minecraft:cobbled_deepslate
setblock 473 62 300 minecraft:deepslate_tiles
setblock 474 62 278 minecraft:cobbled_deepslate
setblock 474 62 279 minecraft:deepslate_tiles
setblock 475 62 277 minecraft:cobbled_deepslate
setblock 475 62 278 minecraft:deepslate_tiles
setblock 476 62 276 minecraft:cobbled_deepslate
fill 476 62 277 479 62 277 minecraft:deepslate_tiles
setblock 476 62 316 minecraft:cobbled_deepslate
setblock 477 62 276 minecraft:deepslate_tiles
setblock 477 62 316 minecraft:deepslate_tiles
setblock 478 62 278 minecraft:deepslate_tiles
setblock 479 62 278 minecraft:cobbled_deepslate
setblock 480 62 277 minecraft:cobbled_deepslate
fill 480 62 278 483 62 278 minecraft:deepslate_tiles
setblock 481 62 276 minecraft:cobbled_deepslate
setblock 481 62 277 minecraft:deepslate_tiles
fill 481 62 316 481 62 317 minecraft:cobbled_deepslate
setblock 482 62 276 minecraft:deepslate_tiles
setblock 482 62 316 minecraft:deepslate_tiles
fill 482 62 317 482 90 317 minecraft:cobbled_deepslate
setblock 484 62 278 minecraft:cobbled_deepslate
setblock 484 62 315 minecraft:deepslate_tiles
setblock 485 62 277 minecraft:cobbled_deepslate
fill 485 62 278 485 62 279 minecraft:deepslate_tiles
setblock 486 62 276 minecraft:cobbled_deepslate
setblock 486 62 277 minecraft:deepslate_tiles
setblock 486 62 316 minecraft:cobbled_deepslate
setblock 487 62 276 minecraft:deepslate_tiles
setblock 487 62 315 minecraft:cobbled_deepslate
setblock 487 62 316 minecraft:deepslate_tiles
setblock 488 62 279 minecraft:cobbled_deepslate
setblock 488 62 314 minecraft:cobbled_deepslate
setblock 488 62 315 minecraft:deepslate_tiles
setblock 489 62 278 minecraft:cobbled_deepslate
setblock 489 62 279 minecraft:deepslate_tiles
setblock 489 62 314 minecraft:deepslate_tiles
setblock 490 62 277 minecraft:cobbled_deepslate
setblock 490 62 278 minecraft:deepslate_tiles
setblock 491 62 276 minecraft:cobbled_deepslate
setblock 491 62 277 minecraft:deepslate_tiles
setblock 491 62 279 minecraft:deepslate_tiles
setblock 491 62 316 minecraft:cobbled_deepslate
setblock 492 62 276 minecraft:deepslate_tiles
setblock 492 62 315 minecraft:cobbled_deepslate
setblock 492 62 316 minecraft:deepslate_tiles
setblock 493 62 314 minecraft:cobbled_deepslate
setblock 493 62 315 minecraft:deepslate_tiles
setblock 494 62 278 minecraft:cobbled_deepslate
setblock 495 62 277 minecraft:cobbled_deepslate
setblock 496 62 276 minecraft:cobbled_deepslate
setblock 496 62 277 minecraft:deepslate_tiles
setblock 496 62 316 minecraft:cobbled_deepslate
setblock 497 62 276 minecraft:deepslate_tiles
setblock 497 62 316 minecraft:deepslate_tiles
setblock 500 62 275 minecraft:white_wool
fill 501 62 275 501 74 275 minecraft:cobbled_deepslate
setblock 506 62 276 minecraft:cobbled_deepslate
setblock 506 62 277 minecraft:deepslate_tiles
setblock 506 62 316 minecraft:cobbled_deepslate
setblock 507 62 276 minecraft:deepslate_tiles
setblock 507 62 316 minecraft:deepslate_tiles
setblock 508 62 278 minecraft:deepslate_tiles
setblock 508 62 299 minecraft:cobbled_deepslate
setblock 508 62 300 minecraft:deepslate_tiles
setblock 508 62 304 minecraft:cobbled_deepslate
setblock 509 62 277 minecraft:deepslate_tiles
setblock 509 62 278 minecraft:cobbled_deepslate
fill 509 62 279 509 62 282 minecraft:deepslate_tiles
setblock 509 62 283 minecraft:cobbled_deepslate
fill 509 62 284 510 62 285 minecraft:deepslate_tiles
setblock 509 62 293 minecraft:cobbled_deepslate
setblock 509 62 294 minecraft:deepslate_tiles
setblock 509 62 298 minecraft:cobbled_deepslate
setblock 509 62 299 minecraft:deepslate_tiles
setblock 509 62 303 minecraft:cobbled_deepslate
setblock 509 62 304 minecraft:deepslate_tiles
setblock 509 62 307 minecraft:deepslate_tiles
setblock 510 62 277 minecraft:cobbled_deepslate
setblock 510 62 278 minecraft:deepslate_tiles
fill 510 62 280 510 62 281 minecraft:deepslate_tiles
setblock 510 62 282 minecraft:cobbled_deepslate
setblock 510 62 283 minecraft:deepslate_tiles
setblock 510 62 286 minecraft:deepslate_tiles
setblock 510 62 287 minecraft:cobbled_deepslate
setblock 510 62 288 minecraft:deepslate_tiles
setblock 510 62 292 minecraft:cobbled_deepslate
setblock 510 62 293 minecraft:deepslate_tiles
setblock 510 62 297 minecraft:cobbled_deepslate
setblock 510 62 298 minecraft:deepslate_tiles
setblock 510 62 302 minecraft:cobbled_deepslate
setblock 510 62 303 minecraft:deepslate_tiles
setblock 510 62 306 minecraft:deepslate_tiles
setblock 510 62 307 minecraft:cobbled_deepslate
setblock 510 62 308 minecraft:deepslate_tiles
setblock 511 62 276 minecraft:cobbled_deepslate
setblock 511 62 277 minecraft:deepslate_tiles
setblock 511 62 280 minecraft:deepslate_tiles
setblock 511 62 281 minecraft:cobbled_deepslate
setblock 511 62 282 minecraft:deepslate_tiles
setblock 511 62 286 minecraft:cobbled_deepslate
setblock 511 62 287 minecraft:deepslate_tiles
setblock 511 62 291 minecraft:cobbled_deepslate
setblock 511 62 292 minecraft:deepslate_tiles
setblock 511 62 296 minecraft:cobbled_deepslate
setblock 511 62 297 minecraft:deepslate_tiles
fill 511 62 301 512 62 301 minecraft:cobbled_deepslate
setblock 511 62 302 minecraft:deepslate_tiles
setblock 511 62 306 minecraft:cobbled_deepslate
setblock 511 62 307 minecraft:deepslate_tiles
setblock 511 62 311 minecraft:cobbled_deepslate
setblock 511 62 312 minecraft:deepslate_tiles
setblock 511 62 316 minecraft:cobbled_deepslate
setblock 511 62 317 minecraft:white_wool
fill 512 62 299 512 67 299 minecraft:cobbled_deepslate
setblock 512 62 300 minecraft:redstone_block
fill 470 63 289 470 94 289 minecraft:cobbled_deepslate
fill 481 63 317 481 94 317 minecraft:cobbled_deepslate
fill 500 63 275 500 94 275 minecraft:cobbled_deepslate
fill 511 63 317 511 95 317 minecraft:cobbled_deepslate
fill 512 63 300 512 94 301 minecraft:cobbled_deepslate
fill 481 66 307 482 67 308 minecraft:white_terracotta
setblock 499 66 317 minecraft:white_wool
setblock 503 66 317 minecraft:white_wool
setblock 473 67 278 minecraft:light[level=12]
setblock 473 67 285 minecraft:light[level=12]
setblock 473 67 292 minecraft:light[level=12]
setblock 473 67 299 minecraft:light[level=12]
setblock 473 67 306 minecraft:light[level=12]
setblock 473 67 313 minecraft:light[level=12]
setblock 480 67 278 minecraft:light[level=12]
setblock 480 67 285 minecraft:light[level=12]
setblock 480 67 292 minecraft:light[level=12]
setblock 480 67 299 minecraft:light[level=12]
setblock 480 67 306 minecraft:light[level=12]
setblock 480 67 313 minecraft:light[level=12]
setblock 487 67 278 minecraft:light[level=12]
setblock 487 67 285 minecraft:light[level=12]
setblock 487 67 292 minecraft:light[level=12]
setblock 487 67 299 minecraft:light[level=12]
setblock 487 67 306 minecraft:light[level=12]
setblock 487 67 313 minecraft:light[level=12]
setblock 494 67 278 minecraft:light[level=12]
setblock 494 67 285 minecraft:light[level=12]
setblock 494 67 292 minecraft:light[level=12]
setblock 494 67 299 minecraft:light[level=12]
setblock 494 67 306 minecraft:light[level=12]
setblock 494 67 313 minecraft:light[level=12]
setblock 495 67 275 minecraft:redstone_block
fill 499 67 317 499 94 317 minecraft:cobbled_deepslate
setblock 501 67 278 minecraft:light[level=12]
setblock 501 67 285 minecraft:light[level=12]
setblock 501 67 292 minecraft:light[level=12]
setblock 501 67 299 minecraft:light[level=12]
setblock 501 67 306 minecraft:light[level=12]
setblock 501 67 313 minecraft:light[level=12]
fill 503 67 317 503 94 317 minecraft:cobbled_deepslate
setblock 508 67 278 minecraft:light[level=12]
setblock 508 67 285 minecraft:light[level=12]
setblock 508 67 292 minecraft:light[level=12]
setblock 508 67 299 minecraft:light[level=12]
setblock 508 67 306 minecraft:light[level=12]
setblock 508 67 313 minecraft:light[level=12]
fill 471 68 276 487 68 316 minecraft:gray_stained_glass
setblock 481 68 275 minecraft:redstone_block
fill 488 68 276 488 68 289 minecraft:gray_stained_glass
fill 488 68 293 488 68 316 minecraft:gray_stained_glass
fill 489 68 276 511 68 288 minecraft:gray_stained_glass
fill 489 68 294 511 68 316 minecraft:gray_stained_glass
fill 492 68 289 511 68 289 minecraft:gray_stained_glass
fill 492 68 293 511 68 293 minecraft:gray_stained_glass
fill 493 68 290 511 68 292 minecraft:gray_stained_glass
fill 495 68 275 495 85 275 minecraft:cobbled_deepslate
setblock 512 68 299 minecraft:redstone_block
fill 471 69 276 472 69 277 minecraft:white_wool
fill 471 69 278 471 69 282 minecraft:gray_stained_glass
setblock 471 69 283 minecraft:white_wool
fill 471 69 284 472 69 286 minecraft:gray_stained_glass
fill 471 69 287 474 69 287 minecraft:white_wool
fill 471 69 288 471 69 294 minecraft:gray_stained_glass
fill 471 69 295 474 69 295 minecraft:white_wool
fill 471 69 296 472 69 299 minecraft:gray_stained_glass
setblock 471 69 300 minecraft:white_wool
fill 471 69 301 471 69 305 minecraft:gray_stained_glass
fill 471 69 306 471 69 307 minecraft:white_wool
fill 471 69 308 476 69 310 minecraft:gray_stained_glass
setblock 471 69 311 minecraft:white_wool
fill 471 69 312 474 69 314 minecraft:gray_stained_glass
setblock 471 69 315 minecraft:white_wool
fill 471 69 316 477 69 316 minecraft:gray_stained_glass
fill 472 69 278 472 69 280 minecraft:gray_stained_glass
setblock 472 69 281 minecraft:white_wool
fill 472 69 282 473 69 283 minecraft:gray_stained_glass
fill 472 69 288 475 69 288 minecraft:gray_stained_glass
fill 472 69 289 472 69 294 minecraft:white_wool
fill 472 69 300 473 69 301 minecraft:gray_stained_glass
setblock 472 69 302 minecraft:white_wool
fill 472 69 303 472 69 304 minecraft:gray_stained_glass
fill 472 69 305 472 69 306 minecraft:white_wool
fill 472 69 307 475 69 307 minecraft:gray_stained_glass
fill 472 69 311 475 69 311 minecraft:gray_stained_glass
fill 472 69 315 476 69 315 minecraft:gray_stained_glass
fill 473 69 276 475 69 276 minecraft:gray_stained_glass
fill 473 69 277 473 69 279 minecraft:white_wool
fill 473 69 280 475 69 281 minecraft:gray_stained_glass
fill 473 69 284 476 69 284 minecraft:gray_stained_glass
fill 473 69 285 473 69 286 minecraft:white_wool
fill 473 69 289 474 69 294 minecraft:gray_stained_glass
fill 473 69 296 478 69 296 minecraft:gray_stained_glass
fill 473 69 297 473 69 298 minecraft:white_wool
fill 473 69 299 476 69 299 minecraft:gray_stained_glass
fill 473 69 302 474 69 303 minecraft:gray_stained_glass
fill 473 69 304 474 69 305 minecraft:white_wool
fill 473 69 306 474 69 306 minecraft:gray_stained_glass
setblock 474 69 277 minecraft:gray_stained_glass
setblock 474 69 278 minecraft:white_wool
setblock 474 69 279 minecraft:gray_stained_glass
fill 474 69 282 478 69 282 minecraft:gray_stained_glass
setblock 474 69 283 minecraft:white_wool
fill 474 69 285 475 69 286 minecraft:gray_stained_glass
fill 474 69 297 475 69 298 minecraft:gray_stained_glass
setblock 474 69 300 minecraft:white_wool
fill 474 69 301 476 69 301 minecraft:gray_stained_glass
setblock 475 69 277 minecraft:white_wool
fill 475 69 278 477 69 278 minecraft:gray_stained_glass
setblock 475 69 279 minecraft:white_wool
fill 475 69 283 479 69 283 minecraft:gray_stained_glass
fill 475 69 287 478 69 287 minecraft:gray_stained_glass
fill 475 69 289 475 69 294 minecraft:white_wool
fill 475 69 295 484 69 295 minecraft:gray_stained_glass
fill 475 69 300 478 69 300 minecraft:gray_stained_glass
setblock 475 69 302 minecraft:gray_stained_glass
fill 475 69 303 476 69 303 minecraft:white_wool
fill 475 69 304 476 69 305 minecraft:gray_stained_glass
setblock 475 69 306 minecraft:white_wool
fill 475 69 312 476 69 313 minecraft:gray_stained_glass
setblock 475 69 314 minecraft:white_wool
setblock 476 69 276 minecraft:white_wool
fill 476 69 277 482 69 277 minecraft:gray_stained_glass
setblock 476 69 279 minecraft:gray_stained_glass
setblock 476 69 280 minecraft:white_wool
setblock 476 69 281 minecraft:gray_stained_glass
fill 476 69 285 479 69 285 minecraft:gray_stained_glass
setblock 476 69 286 minecraft:white_wool
fill 476 69 288 478 69 288 minecraft:white_wool
fill 476 69 289 477 69 293 minecraft:gray_stained_glass
fill 476 69 294 478 69 294 minecraft:white_wool
setblock 476 69 297 minecraft:white_wool
fill 476 69 298 479 69 298 minecraft:gray_stained_glass
setblock 476 69 302 minecraft:white_wool
fill 476 69 306 478 69 306 minecraft:gray_stained_glass
setblock 476 69 307 minecraft:white_wool
setblock 476 69 311 minecraft:white_wool
fill 476 69 314 478 69 314 minecraft:gray_stained_glass
fill 477 69 276 480 69 276 minecraft:gray_stained_glass
setblock 477 69 279 minecraft:white_wool
fill 477 69 280 484 69 280 minecraft:gray_stained_glass
fill 477 69 281 479 69 281 minecraft:white_wool
setblock 477 69 284 minecraft:white_wool
fill 477 69 286 482 69 286 minecraft:gray_stained_glass
fill 477 69 297 482 69 297 minecraft:gray_stained_glass
setblock 477 69 299 minecraft:white_wool
fill 477 69 301 478 69 301 minecraft:white_wool
fill 477 69 302 478 69 303 minecraft:gray_stained_glass
setblock 477 69 304 minecraft:white_wool
setblock 477 69 305 minecraft:gray_stained_glass
fill 477 69 307 480 69 307 minecraft:gray_stained_glass
setblock 477 69 308 minecraft:white_wool
fill 477 69 309 477 69 311 minecraft:gray_stained_glass
setblock 477 69 312 minecraft:white_wool
fill 477 69 313 478 69 313 minecraft:gray_stained_glass
fill 477 69 315 479 69 315 minecraft:white_wool
setblock 478 69 278 minecraft:white_wool
fill 478 69 279 481 69 279 minecraft:gray_stained_glass
fill 478 69 284 480 69 284 minecraft:gray_stained_glass
fill 478 69 289 480 69 289 minecraft:gray_stained_glass
fill 478 69 290 478 69 293 minecraft:white_wool
fill 478 69 299 479 69 299 minecraft:gray_stained_glass
fill 478 69 304 483 69 304 minecraft:gray_stained_glass
setblock 478 69 305 minecraft:white_wool
fill 478 69 308 481 69 308 minecraft:gray_stained_glass
setblock 478 69 309 minecraft:white_wool
fill 478 69 310 479 69 312 minecraft:gray_stained_glass
setblock 478 69 316 minecraft:white_wool
fill 479 69 278 483 69 278 minecraft:gray_stained_glass
setblock 479 69 282 minecraft:white_wool
setblock 479 69 287 minecraft:white_wool
fill 479 69 288 484 69 288 minecraft:gray_stained_glass
fill 479 69 290 480 69 294 minecraft:gray_stained_glass
setblock 479 69 296 minecraft:white_wool
setblock 479 69 300 minecraft:white_wool
fill 479 69 301 484 69 301 minecraft:gray_stained_glass
setblock 479 69 302 minecraft:white_wool
setblock 479 69 303 minecraft:gray_stained_glass
fill 479 69 305 482 69 305 minecraft:gray_stained_glass
setblock 479 69 306 minecraft:white_wool
fill 479 69 309 480 69 309 minecraft:gray_stained_glass
fill 479 69 313 479 69 314 minecraft:white_wool
fill 479 69 316 489 69 316 minecraft:gray_stained_glass
fill 480 69 281 482 69 282 minecraft:gray_stained_glass
setblock 480 69 283 minecraft:white_wool
setblock 480 69 285 minecraft:white_wool
fill 480 69 287 481 69 287 minecraft:gray_stained_glass
fill 480 69 296 481 69 296 minecraft:gray_stained_glass
fill 480 69 298 480 69 299 minecraft:white_wool
fill 480 69 300 486 69 300 minecraft:gray_stained_glass
fill 480 69 302 483 69 302 minecraft:gray_stained_glass
setblock 480 69 303 minecraft:white_wool
fill 480 69 306 482 69 306 minecraft:gray_stained_glass
fill 480 69 310 480 69 313 minecraft:white_wool
fill 480 69 314 480 69 315 minecraft:gray_stained_glass
fill 481 69 275 481 94 275 minecraft:cobbled_deepslate
setblock 481 69 276 minecraft:white_wool
fill 481 69 283 485 69 283 minecraft:gray_stained_glass
setblock 481 69 284 minecraft:white_wool
fill 481 69 285 483 69 285 minecraft:gray_stained_glass
fill 481 69 289 481 69 293 minecraft:white_wool
fill 481 69 294 487 69 294 minecraft:gray_stained_glass
setblock 481 69 298 minecraft:white_wool
fill 481 69 299 484 69 299 minecraft:gray_stained_glass
fill 481 69 303 483 69 303 minecraft:gray_stained_glass
fill 481 69 307 482 69 307 minecraft:white_wool
fill 481 69 309 481 69 311 minecraft:white_wool
fill 481 69 312 484 69 313 minecraft:gray_stained_glass
setblock 481 69 314 minecraft:white_wool
fill 481 69 315 483 69 315 minecraft:gray_stained_glass
setblock 482 69 276 minecraft:gray_stained_glass
setblock 482 69 279 minecraft:white_wool
fill 482 69 284 484 69 284 minecraft:gray_stained_glass
setblock 482 69 287 minecraft:white_wool
setblock 482 69 289 minecraft:white_wool
fill 482 69 290 483 69 292 minecraft:gray_stained_glass
setblock 482 69 293 minecraft:white_wool
setblock 482 69 296 minecraft:white_wool
fill 482 69 298 483 69 298 minecraft:gray_stained_glass
fill 482 69 308 483 69 308 minecraft:white_wool
fill 482 69 309 484 69 310 minecraft:gray_stained_glass
setblock 482 69 311 minecraft:white_wool
fill 482 69 314 489 69 314 minecraft:gray_stained_glass
fill 483 69 276 483 69 277 minecraft:white_wool
setblock 483 69 279 minecraft:gray_stained_glass
setblock 483 69 281 minecraft:gray_stained_glass
setblock 483 69 282 minecraft:white_wool
fill 483 69 286 484 69 286 minecraft:white_wool
fill 483 69 287 484 69 287 minecraft:gray_stained_glass
fill 483 69 289 486 69 289 minecraft:gray_stained_glass
setblock 483 69 293 minecraft:gray_stained_glass
setblock 483 69 296 minecraft:gray_stained_glass
setblock 483 69 297 minecraft:white_wool
fill 483 69 305 483 69 306 minecraft:white_wool
fill 483 69 307 489 69 307 minecraft:gray_stained_glass
fill 483 69 311 489 69 311 minecraft:gray_stained_glass
fill 484 69 276 485 69 277 minecraft:gray_stained_glass
fill 484 69 278 484 69 279 minecraft:white_wool
fill 484 69 281 485 69 281 minecraft:white_wool
fill 484 69 282 489 69 282 minecraft:gray_stained_glass
setblock 484 69 285 minecraft:white_wool
fill 484 69 290 484 69 293 minecraft:white_wool
setblock 484 69 296 minecraft:white_wool
fill 484 69 297 486 69 297 minecraft:gray_stained_glass
setblock 484 69 298 minecraft:white_wool
fill 484 69 302 484 69 304 minecraft:white_wool
fill 484 69 305 484 69 306 minecraft:gray_stained_glass
fill 484 69 308 489 69 308 minecraft:gray_stained_glass
fill 484 69 315 485 69 315 minecraft:white_wool
fill 485 69 278 489 69 279 minecraft:gray_stained_glass
setblock 485 69 280 minecraft:white_wool
setblock 485 69 284 minecraft:white_wool
fill 485 69 285 486 69 286 minecraft:gray_stained_glass
fill 485 69 287 485 69 288 minecraft:white_wool
fill 485 69 290 485 69 293 minecraft:gray_stained_glass
setblock 485 69 295 minecraft:white_wool
setblock 485 69 296 minecraft:gray_stained_glass
fill 485 69 298 489 69 298 minecraft:gray_stained_glass
fill 485 69 299 486 69 299 minecraft:white_wool
fill 485 69 301 485 69 302 minecraft:white_wool
fill 485 69 303 485 69 305 minecraft:gray_stained_glass
fill 485 69 306 486 69 306 minecraft:white_wool
fill 485 69 309 486 69 309 minecraft:white_wool
fill 485 69 310 489 69 310 minecraft:gray_stained_glass
setblock 485 69 312 minecraft:white_wool
fill 485 69 313 489 69 313 minecraft:gray_stained_glass
fill 486 69 276 489 69 276 minecraft:gray_stained_glass
fill 486 69 277 488 69 277 minecraft:white_wool
fill 486 69 280 486 69 281 minecraft:gray_stained_glass
fill 486 69 283 488 69 283 minecraft:white_wool
fill 486 69 284 489 69 284 minecraft:gray_stained_glass
setblock 486 69 287 minecraft:white_wool
fill 486 69 288 487 69 288 minecraft:gray_stained_glass
setblock 486 69 290 minecraft:white_wool
setblock 486 69 291 minecraft:gray_stained_glass
setblock 486 69 292 minecraft:white_wool
setblock 486 69 293 minecraft:gray_stained_glass
fill 486 69 295 487 69 295 minecraft:gray_stained_glass
setblock 486 69 296 minecraft:white_wool
fill 486 69 301 489 69 302 minecraft:gray_stained_glass
setblock 486 69 303 minecraft:white_wool
fill 486 69 304 489 69 305 minecraft:gray_stained_glass
fill 486 69 312 489 69 312 minecraft:gray_stained_glass
fill 486 69 315 489 69 315 minecraft:gray_stained_glass
fill 487 69 280 488 69 280 minecraft:white_wool
fill 487 69 281 489 69 281 minecraft:gray_stained_glass
setblock 487 69 285 minecraft:white_wool
fill 487 69 286 487 69 287 minecraft:gray_stained_glass
fill 487 69 289 487 69 293 minecraft:redstone_block
fill 487 69 296 489 69 296 minecraft:gray_stained_glass
setblock 487 69 297 minecraft:white_wool
fill 487 69 299 489 69 299 minecraft:gray_stained_glass
setblock 487 69 300 minecraft:white_wool
fill 487 69 303 489 69 303 minecraft:gray_stained_glass
fill 487 69 306 489 69 306 minecraft:gray_stained_glass
fill 487 69 309 489 69 309 minecraft:gray_stained_glass
fill 488 69 285 489 69 285 minecraft:gray_stained_glass
fill 488 69 286 488 69 287 minecraft:white_wool
fill 488 69 288 488 69 289 minecraft:redstone_block
fill 488 69 293 488 69 294 minecraft:redstone_block
setblock 488 69 295 minecraft:white_wool
fill 488 69 297 489 69 297 minecraft:gray_stained_glass
fill 488 69 300 489 69 300 minecraft:gray_stained_glass
setblock 489 69 277 minecraft:gray_stained_glass
setblock 489 69 280 minecraft:gray_stained_glass
setblock 489 69 283 minecraft:gray_stained_glass
fill 489 69 286 489 69 287 minecraft:gray_stained_glass
fill 489 69 288 492 69 288 minecraft:redstone_block
fill 489 69 294 492 69 294 minecraft:redstone_block
setblock 489 69 295 minecraft:gray_stained_glass
fill 490 69 276 490 69 287 minecraft:white_wool
fill 490 69 295 490 69 316 minecraft:white_wool
fill 491 69 276 496 69 276 minecraft:gray_stained_glass
fill 491 69 277 493 69 277 minecraft:white_wool
fill 491 69 278 494 69 279 minecraft:gray_stained_glass
fill 491 69 280 492 69 280 minecraft:white_wool
fill 491 69 281 494 69 282 minecraft:gray_stained_glass
fill 491 69 283 492 69 283 minecraft:white_wool
fill 491 69 284 492 69 285 minecraft:gray_stained_glass
setblock 491 69 286 minecraft:white_wool
setblock 491 69 287 minecraft:gray_stained_glass
fill 491 69 295 491 69 316 minecraft:gray_stained_glass
fill 492 69 286 495 69 286 minecraft:gray_stained_glass
fill 492 69 287 493 69 287 minecraft:white_wool
fill 492 69 289 493 69 289 minecraft:redstone_block
fill 492 69 293 493 69 293 minecraft:redstone_block
setblock 492 69 295 minecraft:white_wool
fill 492 69 296 492 69 316 minecraft:gray_stained_glass
fill 493 69 280 494 69 280 minecraft:gray_stained_glass
fill 493 69 283 493 69 284 minecraft:gray_stained_glass
setblock 493 69 285 minecraft:white_wool
setblock 493 69 288 minecraft:gray_stained_glass
fill 493 69 290 493 69 292 minecraft:redstone_block
setblock 493 69 294 minecraft:white_wool
fill 493 69 295 494 69 296 minecraft:gray_stained_glass
fill 493 69 297 494 69 297 minecraft:white_wool
fill 493 69 298 493 69 316 minecraft:gray_stained_glass
fill 494 69 277 496 69 277 minecraft:gray_stained_glass
fill 494 69 283 494 69 284 minecraft:white_wool
setblock 494 69 285 minecraft:gray_stained_glass
setblock 494 69 287 minecraft:gray_stained_glass
setblock 494 69 288 minecraft:white_wool
fill 494 69 289 497 69 289 minecraft:gray_stained_glass
setblock 494 69 290 minecraft:white_wool
fill 494 69 291 511 69 291 minecraft:gray_stained_glass
fill 494 69 292 494 69 293 minecraft:white_wool
fill 494 69 294 499 69 294 minecraft:gray_stained_glass
fill 494 69 298 498 69 298 minecraft:gray_stained_glass
fill 494 69 299 494 69 300 minecraft:white_wool
fill 494 69 301 494 69 316 minecraft:gray_stained_glass
fill 495 69 278 496 69 278 minecraft:white_wool
setblock 495 69 279 minecraft:gray_stained_glass
fill 495 69 280 495 69 281 minecraft:white_wool
fill 495 69 282 495 69 284 minecraft:gray_stained_glass
setblock 495 69 285 minecraft:white_wool
setblock 495 69 287 minecraft:white_wool
fill 495 69 288 496 69 288 minecraft:gray_stained_glass
fill 495 69 290 511 69 290 minecraft:gray_stained_glass
fill 495 69 292 496 69 293 minecraft:gray_stained_glass
fill 495 69 295 496 69 296 minecraft:white_wool
fill 495 69 297 497 69 297 minecraft:gray_stained_glass
fill 495 69 299 495 69 300 minecraft:gray_stained_glass
fill 495 69 301 495 69 303 minecraft:white_wool
fill 495 69 304 495 69 305 minecraft:gray_stained_glass
setblock 495 69 306 minecraft:white_wool
fill 495 69 307 497 69 308 minecraft:gray_stained_glass
fill 495 69 309 496 69 309 minecraft:white_wool
fill 495 69 310 495 69 316 minecraft:gray_stained_glass
fill 496 69 279 497 69 279 minecraft:white_wool
fill 496 69 280 501 69 281 minecraft:gray_stained_glass
setblock 496 69 282 minecraft:white_wool
fill 496 69 283 497 69 285 minecraft:gray_stained_glass
setblock 496 69 286 minecraft:white_wool
fill 496 69 287 499 69 287 minecraft:gray_stained_glass
setblock 496 69 299 minecraft:white_wool
fill 496 69 300 496 69 302 minecraft:gray_stained_glass
fill 496 69 303 496 69 304 minecraft:white_wool
fill 496 69 305 496 69 306 minecraft:gray_stained_glass
fill 496 69 310 498 69 311 minecraft:gray_stained_glass
setblock 496 69 312 minecraft:white_wool
fill 496 69 313 499 69 314 minecraft:gray_stained_glass
fill 496 69 315 497 69 315 minecraft:white_wool
fill 496 69 316 501 69 316 minecraft:gray_stained_glass
fill 497 69 276 497 69 277 minecraft:white_wool
fill 497 69 278 500 69 278 minecraft:gray_stained_glass
fill 497 69 282 500 69 282 minecraft:gray_stained_glass
fill 497 69 286 505 69 286 minecraft:gray_stained_glass
setblock 497 69 288 minecraft:white_wool
fill 497 69 292 511 69 292 minecraft:gray_stained_glass
fill 497 69 293 500 69 293 minecraft:white_wool
fill 497 69 295 498 69 296 minecraft:gray_stained_glass
fill 497 69 299 499 69 301 minecraft:gray_stained_glass
setblock 497 69 302 minecraft:white_wool
fill 497 69 303 500 69 304 minecraft:gray_stained_glass
fill 497 69 305 497 69 306 minecraft:white_wool
fill 497 69 309 498 69 309 minecraft:gray_stained_glass
fill 497 69 312 499 69 312 minecraft:gray_stained_glass
setblock 498 69 276 minecraft:white_wool
fill 498 69 277 503 69 277 minecraft:gray_stained_glass
fill 498 69 279 501 69 279 minecraft:gray_stained_glass
fill 498 69 283 499 69 283 minecraft:gray_stained_glass
fill 498 69 284 499 69 284 minecraft:white_wool
setblock 498 69 285 minecraft:gray_stained_glass
fill 498 69 288 499 69 288 minecraft:gray_stained_glass
fill 498 69 289 499 69 289 minecraft:white_wool
setblock 498 69 297 minecraft:white_wool
fill 498 69 302 501 69 302 minecraft:gray_stained_glass
setblock 498 69 305 minecraft:white_wool
fill 498 69 306 501 69 306 minecraft:gray_stained_glass
fill 498 69 307 498 69 308 minecraft:white_wool
fill 498 69 315 500 69 315 minecraft:gray_stained_glass
fill 499 69 276 502 69 276 minecraft:gray_stained_glass
setblock 499 69 285 minecraft:white_wool
fill 499 69 295 505 69 295 minecraft:gray_stained_glass
setblock 499 69 296 minecraft:white_wool
fill 499 69 297 501 69 297 minecraft:gray_stained_glass
setblock 499 69 298 minecraft:white_wool
fill 499 69 305 502 69 305 minecraft:gray_stained_glass
fill 499 69 307 499 69 308 minecraft:gray_stained_glass
fill 499 69 309 499 69 311 minecraft:white_wool
fill 500 69 283 501 69 283 minecraft:white_wool
fill 500 69 284 501 69 285 minecraft:gray_stained_glass
fill 500 69 287 500 69 288 minecraft:white_wool
fill 500 69 289 511 69 289 minecraft:gray_stained_glass
setblock 500 69 294 minecraft:white_wool
fill 500 69 296 509 69 296 minecraft:gray_stained_glass
setblock 500 69 298 minecraft:gray_stained_glass
setblock 500 69 299 minecraft:white_wool
fill 500 69 300 500 69 301 minecraft:gray_stained_glass
setblock 500 69 307 minecraft:white_wool
fill 500 69 308 500 69 310 minecraft:gray_stained_glass
fill 500 69 311 500 69 314 minecraft:white_wool
setblock 501 69 278 minecraft:white_wool
setblock 501 69 282 minecraft:white_wool
fill 501 69 287 501 69 288 minecraft:gray_stained_glass
fill 501 69 293 501 69 294 minecraft:gray_stained_glass
setblock 501 69 298 minecraft:white_wool
fill 501 69 299 503 69 299 minecraft:gray_stained_glass
setblock 501 69 300 minecraft:white_wool
setblock 501 69 301 minecraft:gray_stained_glass
setblock 501 69 303 minecraft:white_wool
fill 501 69 304 503 69 304 minecraft:gray_stained_glass
fill 501 69 307 502 69 309 minecraft:gray_stained_glass
setblock 501 69 310 minecraft:white_wool
fill 501 69 311 503 69 312 minecraft:gray_stained_glass
fill 501 69 313 501 69 315 minecraft:white_wool
fill 502 69 278 504 69 278 minecraft:gray_stained_glass
setblock 502 69 279 minecraft:white_wool
setblock 502 69 280 minecraft:gray_stained_glass
fill 502 69 281 503 69 281 minecraft:white_wool
fill 502 69 282 503 69 283 minecraft:gray_stained_glass
setblock 502 69 284 minecraft:white_wool
fill 502 69 285 511 69 285 minecraft:gray_stained_glass
setblock 502 69 287 minecraft:gray_stained_glass
fill 502 69 288 504 69 288 minecraft:white_wool
fill 502 69 293 511 69 293 minecraft:gray_stained_glass
fill 502 69 294 504 69 294 minecraft:white_wool
setblock 502 69 297 minecraft:white_wool
fill 502 69 298 507 69 298 minecraft:gray_stained_glass
fill 502 69 300 506 69 300 minecraft:gray_stained_glass
fill 502 69 301 502 69 302 minecraft:white_wool
fill 502 69 303 504 69 303 minecraft:gray_stained_glass
setblock 502 69 306 minecraft:white_wool
fill 502 69 310 510 69 310 minecraft:gray_stained_glass
setblock 502 69 313 minecraft:white_wool
fill 502 69 314 505 69 314 minecraft:gray_stained_glass
fill 502 69 315 502 69 316 minecraft:white_wool
setblock 503 69 276 minecraft:white_wool
fill 503 69 279 504 69 279 minecraft:gray_stained_glass
fill 503 69 280 504 69 280 minecraft:white_wool
fill 503 69 284 504 69 284 minecraft:gray_stained_glass
setblock 503 69 287 minecraft:white_wool
fill 503 69 297 504 69 297 minecraft:gray_stained_glass
setblock 503 69 301 minecraft:white_wool
setblock 503 69 302 minecraft:gray_stained_glass
setblock 503 69 305 minecraft:white_wool
fill 503 69 306 503 69 308 minecraft:gray_stained_glass
setblock 503 69 309 minecraft:white_wool
fill 503 69 313 511 69 313 minecraft:gray_stained_glass
setblock 503 69 315 minecraft:gray_stained_glass
setblock 503 69 316 minecraft:white_wool
fill 504 69 276 506 69 276 minecraft:gray_stained_glass
setblock 504 69 277 minecraft:white_wool
fill 504 69 281 506 69 281 minecraft:gray_stained_glass
setblock 504 69 282 minecraft:white_wool
fill 504 69 283 507 69 283 minecraft:gray_stained_glass
fill 504 69 287 505 69 287 minecraft:gray_stained_glass
setblock 504 69 299 minecraft:white_wool
fill 504 69 301 509 69 301 minecraft:gray_stained_glass
setblock 504 69 302 minecraft:white_wool
setblock 504 69 304 minecraft:white_wool
fill 504 69 305 504 69 307 minecraft:gray_stained_glass
setblock 504 69 308 minecraft:white_wool
fill 504 69 309 511 69 309 minecraft:gray_stained_glass
setblock 504 69 311 minecraft:gray_stained_glass
setblock 504 69 312 minecraft:white_wool
setblock 504 69 315 minecraft:white_wool
fill 504 69 316 511 69 316 minecraft:gray_stained_glass
fill 505 69 277 506 69 277 minecraft:gray_stained_glass
fill 505 69 278 506 69 279 minecraft:white_wool
fill 505 69 280 509 69 280 minecraft:gray_stained_glass
fill 505 69 282 510 69 282 minecraft:gray_stained_glass
setblock 505 69 284 minecraft:white_wool
fill 505 69 288 511 69 288 minecraft:gray_stained_glass
setblock 505 69 294 minecraft:gray_stained_glass
setblock 505 69 297 minecraft:white_wool
fill 505 69 299 510 69 299 minecraft:gray_stained_glass
setblock 505 69 302 minecraft:gray_stained_glass
setblock 505 69 303 minecraft:white_wool
fill 505 69 304 505 69 306 minecraft:gray_stained_glass
setblock 505 69 307 minecraft:white_wool
fill 505 69 308 510 69 308 minecraft:gray_stained_glass
setblock 505 69 311 minecraft:white_wool
fill 505 69 312 508 69 312 minecraft:gray_stained_glass
fill 505 69 315 509 69 315 minecraft:gray_stained_glass
fill 506 69 284 511 69 284 minecraft:gray_stained_glass
fill 506 69 286 506 69 287 minecraft:white_wool
fill 506 69 294 506 69 295 minecraft:white_wool
fill 506 69 297 511 69 297 minecraft:gray_stained_glass
setblock 506 69 302 minecraft:white_wool
fill 506 69 303 511 69 303 minecraft:gray_stained_glass
fill 506 69 304 508 69 304 minecraft:white_wool
setblock 506 69 305 minecraft:gray_stained_glass
setblock 506 69 306 minecraft:white_wool
fill 506 69 307 508 69 307 minecraft:gray_stained_glass
fill 506 69 311 509 69 311 minecraft:gray_stained_glass
setblock 506 69 314 minecraft:white_wool
fill 507 69 276 507 69 278 minecraft:white_wool
fill 507 69 279 511 69 279 minecraft:gray_stained_glass
setblock 507 69 281 minecraft:white_wool
fill 507 69 286 508 69 286 minecraft:gray_stained_glass
fill 507 69 287 509 69 287 minecraft:white_wool
fill 507 69 294 508 69 294 minecraft:gray_stained_glass
fill 507 69 295 509 69 295 minecraft:white_wool
setblock 507 69 300 minecraft:white_wool
fill 507 69 302 511 69 302 minecraft:gray_stained_glass
fill 507 69 305 508 69 305 minecraft:white_wool
setblock 507 69 306 minecraft:gray_stained_glass
fill 507 69 314 510 69 314 minecraft:gray_stained_glass
fill 508 69 276 508 69 277 minecraft:white_wool
fill 508 69 278 511 69 278 minecraft:gray_stained_glass
fill 508 69 281 511 69 281 minecraft:gray_stained_glass
setblock 508 69 283 minecraft:white_wool
setblock 508 69 298 minecraft:white_wool
fill 508 69 300 511 69 300 minecraft:gray_stained_glass
fill 508 69 306 510 69 306 minecraft:white_wool
setblock 509 69 276 minecraft:white_wool
fill 509 69 277 511 69 277 minecraft:gray_stained_glass
fill 509 69 283 510 69 283 minecraft:gray_stained_glass
fill 509 69 286 511 69 286 minecraft:white_wool
setblock 509 69 294 minecraft:white_wool
fill 509 69 298 510 69 298 minecraft:gray_stained_glass
fill 509 69 304 510 69 305 minecraft:gray_stained_glass
fill 509 69 307 511 69 307 minecraft:white_wool
setblock 509 69 312 minecraft:white_wool
setblock 510 69 276 minecraft:gray_stained_glass
setblock 510 69 280 minecraft:white_wool
fill 510 69 287 511 69 287 minecraft:gray_stained_glass
fill 510 69 294 511 69 295 minecraft:gray_stained_glass
fill 510 69 296 511 69 296 minecraft:white_wool
setblock 510 69 301 minecraft:white_wool
setblock 510 69 311 minecraft:white_wool
fill 510 69 312 511 69 312 minecraft:gray_stained_glass
setblock 510 69 315 minecraft:white_wool
setblock 511 69 276 minecraft:white_wool
setblock 511 69 280 minecraft:gray_stained_glass
fill 511 69 282 511 69 283 minecraft:white_wool
fill 511 69 298 511 69 299 minecraft:white_wool
setblock 511 69 301 minecraft:gray_stained_glass
setblock 511 69 304 minecraft:gray_stained_glass
setblock 511 69 305 minecraft:white_wool
setblock 511 69 306 minecraft:gray_stained_glass
setblock 511 69 308 minecraft:white_wool
setblock 511 69 310 minecraft:white_wool
setblock 511 69 311 minecraft:gray_stained_glass
setblock 511 69 314 minecraft:white_wool
setblock 511 69 315 minecraft:gray_stained_glass
fill 512 69 299 512 91 299 minecraft:cobbled_deepslate
setblock 512 70 276 minecraft:white_wool
fill 512 71 276 512 77 276 minecraft:cobbled_deepslate
setblock 470 73 282 minecraft:redstone_block
fill 471 73 277 471 73 279 minecraft:deepslate_tiles
setblock 471 73 280 minecraft:cobbled_deepslate
fill 471 73 281 471 73 284 minecraft:deepslate_tiles
setblock 471 73 285 minecraft:cobbled_deepslate
fill 471 73 286 471 73 289 minecraft:deepslate_tiles
setblock 471 73 290 minecraft:cobbled_deepslate
fill 471 73 291 471 76 291 minecraft:deepslate_tiles
fill 471 73 307 471 73 309 minecraft:deepslate_tiles
setblock 471 73 310 minecraft:cobbled_deepslate
fill 471 73 311 471 74 313 minecraft:deepslate_tiles
setblock 472 73 283 minecraft:deepslate_tiles
setblock 472 73 284 minecraft:cobbled_deepslate
fill 472 73 285 472 73 288 minecraft:deepslate_tiles
setblock 473 73 278 minecraft:light[level=12]
setblock 473 73 285 minecraft:light[level=12]
setblock 473 73 292 minecraft:light[level=12]
setblock 473 73 299 minecraft:light[level=12]
setblock 473 73 306 minecraft:light[level=12]
setblock 473 73 313 minecraft:light[level=12]
fill 476 73 316 479 73 316 minecraft:deepslate_tiles
fill 477 73 276 479 73 276 minecraft:deepslate_tiles
fill 478 73 315 480 73 315 minecraft:deepslate_tiles
setblock 480 73 276 minecraft:cobbled_deepslate
setblock 480 73 278 minecraft:light[level=12]
setblock 480 73 285 minecraft:light[level=12]
setblock 480 73 292 minecraft:light[level=12]
setblock 480 73 299 minecraft:light[level=12]
setblock 480 73 306 minecraft:light[level=12]
setblock 480 73 313 minecraft:light[level=12]
fill 480 73 314 481 73 314 minecraft:deepslate_tiles
setblock 480 73 316 minecraft:cobbled_deepslate
fill 481 73 276 484 73 276 minecraft:deepslate_tiles
setblock 481 73 315 minecraft:cobbled_deepslate
fill 481 73 316 484 73 316 minecraft:deepslate_tiles
fill 482 73 277 483 73 277 minecraft:deepslate_tiles
setblock 482 73 314 minecraft:cobbled_deepslate
fill 482 73 315 485 73 315 minecraft:deepslate_tiles
setblock 483 73 313 minecraft:cobbled_deepslate
fill 483 73 314 486 73 314 minecraft:deepslate_tiles
fill 484 73 313 485 75 313 minecraft:deepslate_tiles
setblock 485 73 276 minecraft:cobbled_deepslate
setblock 485 73 316 minecraft:cobbled_deepslate
fill 486 73 276 487 75 276 minecraft:deepslate_tiles
setblock 486 73 315 minecraft:cobbled_deepslate
fill 486 73 316 489 73 316 minecraft:deepslate_tiles
setblock 487 73 278 minecraft:light[level=12]
setblock 487 73 285 minecraft:light[level=12]
setblock 487 73 292 minecraft:light[level=12]
setblock 487 73 299 minecraft:light[level=12]
setblock 487 73 306 minecraft:light[level=12]
setblock 487 73 313 minecraft:light[level=12]
setblock 487 73 314 minecraft:cobbled_deepslate
fill 487 73 315 489 74 315 minecraft:deepslate_tiles
setblock 490 73 316 minecraft:cobbled_deepslate
setblock 494 73 278 minecraft:light[level=12]
setblock 494 73 285 minecraft:light[level=12]
setblock 494 73 292 minecraft:light[level=12]
setblock 494 73 299 minecraft:light[level=12]
setblock 494 73 306 minecraft:light[level=12]
setblock 494 73 313 minecraft:light[level=12]
setblock 501 73 278 minecraft:light[level=12]
setblock 501 73 285 minecraft:light[level=12]
setblock 501 73 292 minecraft:light[level=12]
setblock 501 73 299 minecraft:light[level=12]
setblock 501 73 306 minecraft:light[level=12]
setblock 501 73 313 minecraft:light[level=12]
fill 502 73 316 504 73 316 minecraft:deepslate_tiles
setblock 505 73 276 minecraft:cobbled_deepslate
setblock 505 73 316 minecraft:cobbled_deepslate
fill 506 73 276 506 76 276 minecraft:deepslate_tiles
fill 507 73 302 509 75 302 minecraft:black_concrete
setblock 508 73 278 minecraft:light[level=12]
setblock 508 73 285 minecraft:light[level=12]
fill 508 73 286 508 73 287 minecraft:deepslate_tiles
setblock 508 73 288 minecraft:cobbled_deepslate
fill 508 73 289 511 73 289 minecraft:deepslate_tiles
setblock 508 73 292 minecraft:light[level=12]
setblock 508 73 299 minecraft:light[level=12]
fill 508 73 301 508 75 301 minecraft:black_concrete
fill 508 73 303 508 75 303 minecraft:black_concrete
setblock 508 73 306 minecraft:light[level=12]
setblock 508 73 313 minecraft:light[level=12]
fill 509 73 283 509 73 286 minecraft:deepslate_tiles
setblock 509 73 287 minecraft:cobbled_deepslate
fill 509 73 288 511 74 288 minecraft:deepslate_tiles
fill 509 73 290 509 73 291 minecraft:deepslate_tiles
fill 510 73 282 510 73 285 minecraft:deepslate_tiles
setblock 510 73 286 minecraft:cobbled_deepslate
fill 510 73 287 511 75 287 minecraft:deepslate_tiles
setblock 510 73 290 minecraft:deepslate_tiles
setblock 510 73 291 minecraft:cobbled_deepslate
fill 510 73 292 511 74 293 minecraft:deepslate_tiles
setblock 511 73 280 minecraft:cobbled_deepslate
fill 511 73 281 511 73 284 minecraft:deepslate_tiles
setblock 511 73 285 minecraft:cobbled_deepslate
fill 511 73 286 511 76 286 minecraft:deepslate_tiles
setblock 511 73 290 minecraft:cobbled_deepslate
fill 511 73 291 511 76 291 minecraft:deepslate_tiles
setblock 511 73 294 minecraft:deepslate_tiles
fill 511 73 306 511 73 309 minecraft:deepslate_tiles
setblock 511 73 310 minecraft:cobbled_deepslate
fill 470 74 282 470 94 282 minecraft:cobbled_deepslate
fill 471 74 276 471 74 278 minecraft:deepslate_tiles
setblock 471 74 279 minecraft:cobbled_deepslate
fill 471 74 280 471 74 283 minecraft:deepslate_tiles
setblock 471 74 284 minecraft:cobbled_deepslate
fill 471 74 285 471 74 288 minecraft:deepslate_tiles
setblock 471 74 289 minecraft:cobbled_deepslate
fill 471 74 290 471 77 290 minecraft:deepslate_tiles
fill 471 74 292 471 75 292 minecraft:deepslate_tiles
fill 471 74 307 471 74 308 minecraft:deepslate_tiles
setblock 471 74 309 minecraft:cobbled_deepslate
fill 471 74 310 471 77 310 minecraft:deepslate_tiles
setblock 471 74 314 minecraft:cobbled_deepslate
fill 471 74 315 471 77 315 minecraft:deepslate_tiles
fill 472 74 284 472 74 287 minecraft:deepslate_tiles
setblock 472 74 288 minecraft:cobbled_deepslate
setblock 474 74 316 minecraft:cobbled_deepslate
fill 475 74 276 478 74 276 minecraft:deepslate_tiles
fill 475 74 316 478 74 316 minecraft:deepslate_tiles
fill 477 74 315 479 74 315 minecraft:deepslate_tiles
setblock 479 74 276 minecraft:cobbled_deepslate
fill 479 74 278 479 82 278 minecraft:black_concrete
fill 479 74 314 480 74 314 minecraft:deepslate_tiles
setblock 479 74 316 minecraft:cobbled_deepslate
fill 480 74 276 483 74 276 minecraft:deepslate_tiles
setblock 480 74 315 minecraft:cobbled_deepslate
fill 480 74 316 483 74 316 minecraft:deepslate_tiles
fill 481 74 277 482 74 277 minecraft:deepslate_tiles
setblock 481 74 313 minecraft:deepslate_tiles
setblock 481 74 314 minecraft:cobbled_deepslate
fill 481 74 315 484 74 315 minecraft:deepslate_tiles
setblock 482 74 313 minecraft:cobbled_deepslate
fill 482 74 314 485 74 314 minecraft:deepslate_tiles
setblock 483 74 277 minecraft:cobbled_deepslate
fill 483 74 313 483 77 313 minecraft:deepslate_tiles
setblock 484 74 276 minecraft:cobbled_deepslate
setblock 484 74 316 minecraft:cobbled_deepslate
fill 485 74 276 485 77 276 minecraft:deepslate_tiles
setblock 485 74 315 minecraft:cobbled_deepslate
fill 485 74 316 488 74 316 minecraft:deepslate_tiles
setblock 486 74 313 minecraft:deepslate_tiles
setblock 486 74 314 minecraft:cobbled_deepslate
fill 486 74 315 486 77 315 minecraft:deepslate_tiles
fill 487 74 314 488 76 314 minecraft:deepslate_tiles
setblock 489 74 316 minecraft:cobbled_deepslate
fill 490 74 316 491 76 316 minecraft:deepslate_tiles
setblock 499 74 316 minecraft:cobbled_deepslate
fill 500 74 316 503 74 316 minecraft:deepslate_tiles
setblock 503 74 276 minecraft:deepslate_tiles
setblock 504 74 276 minecraft:cobbled_deepslate
setblock 504 74 316 minecraft:cobbled_deepslate
fill 505 74 276 505 77 276 minecraft:deepslate_tiles
fill 505 74 316 506 76 316 minecraft:deepslate_tiles
fill 507 74 276 507 75 276 minecraft:deepslate_tiles
fill 507 74 301 507 75 301 minecraft:black_concrete
fill 507 74 303 507 75 303 minecraft:black_concrete
fill 507 74 317 507 92 317 minecraft:cobbled_deepslate
setblock 508 74 286 minecraft:deepslate_tiles
setblock 508 74 287 minecraft:cobbled_deepslate
fill 508 74 288 508 75 290 minecraft:deepslate_tiles
setblock 508 74 317 minecraft:white_wool
fill 509 74 284 509 74 285 minecraft:deepslate_tiles
setblock 509 74 286 minecraft:cobbled_deepslate
fill 509 74 287 509 77 287 minecraft:deepslate_tiles
fill 509 74 289 509 74 290 minecraft:deepslate_tiles
setblock 509 74 291 minecraft:cobbled_deepslate
fill 509 74 292 509 77 292 minecraft:deepslate_tiles
fill 509 74 301 509 75 301 minecraft:black_concrete
fill 509 74 303 509 75 303 minecraft:black_concrete
fill 510 74 282 510 74 284 minecraft:deepslate_tiles
setblock 510 74 285 minecraft:cobbled_deepslate
fill 510 74 286 510 77 286 minecraft:deepslate_tiles
setblock 510 74 289 minecraft:deepslate_tiles
setblock 510 74 290 minecraft:cobbled_deepslate
fill 510 74 291 510 77 291 minecraft:deepslate_tiles
fill 511 74 280 511 74 283 minecraft:deepslate_tiles
setblock 511 74 284 minecraft:cobbled_deepslate
fill 511 74 285 511 77 285 minecraft:deepslate_tiles
setblock 511 74 289 minecraft:cobbled_deepslate
fill 511 74 290 511 77 290 minecraft:deepslate_tiles
setblock 511 74 294 minecraft:cobbled_deepslate
fill 511 74 295 511 77 295 minecraft:deepslate_tiles
fill 511 74 307 511 74 308 minecraft:deepslate_tiles
setblock 511 74 309 minecraft:cobbled_deepslate
fill 511 74 310 511 76 311 minecraft:deepslate_tiles
setblock 512 74 312 minecraft:white_wool
fill 512 74 313 512 91 315 minecraft:cobbled_deepslate
fill 471 75 276 471 75 277 minecraft:deepslate_tiles
setblock 471 75 278 minecraft:cobbled_deepslate
fill 471 75 279 471 75 282 minecraft:deepslate_tiles
setblock 471 75 283 minecraft:cobbled_deepslate
fill 471 75 284 471 75 287 minecraft:deepslate_tiles
setblock 471 75 288 minecraft:cobbled_deepslate
fill 471 75 289 472 75 289 minecraft:deepslate_tiles
setblock 471 75 308 minecraft:cobbled_deepslate
fill 471 75 309 471 78 309 minecraft:deepslate_tiles
fill 471 75 311 471 75 312 minecraft:deepslate_tiles
setblock 471 75 313 minecraft:cobbled_deepslate
fill 471 75 314 471 78 314 minecraft:deepslate_tiles
fill 471 75 316 472 75 316 minecraft:deepslate_tiles
setblock 472 75 276 minecraft:deepslate_tiles
fill 472 75 285 472 75 286 minecraft:deepslate_tiles
setblock 472 75 287 minecraft:cobbled_deepslate
fill 472 75 288 472 76 288 minecraft:deepslate_tiles
setblock 473 75 276 minecraft:cobbled_deepslate
setblock 473 75 316 minecraft:cobbled_deepslate
fill 474 75 276 477 75 276 minecraft:deepslate_tiles
fill 474 75 316 477 75 316 minecraft:deepslate_tiles
fill 475 75 315 478 75 315 minecraft:deepslate_tiles
fill 477 75 314 479 75 314 minecraft:deepslate_tiles
setblock 478 75 276 minecraft:cobbled_deepslate
setblock 478 75 316 minecraft:cobbled_deepslate
fill 479 75 276 481 75 277 minecraft:deepslate_tiles
fill 479 75 313 480 75 313 minecraft:deepslate_tiles
setblock 479 75 315 minecraft:cobbled_deepslate
fill 479 75 316 482 75 316 minecraft:deepslate_tiles
setblock 480 75 314 minecraft:cobbled_deepslate
fill 480 75 315 483 75 315 minecraft:deepslate_tiles
setblock 481 75 313 minecraft:cobbled_deepslate
fill 481 75 314 484 75 314 minecraft:deepslate_tiles
setblock 482 75 276 minecraft:deepslate_tiles
setblock 482 75 277 minecraft:cobbled_deepslate
setblock 482 75 312 minecraft:cobbled_deepslate
fill 482 75 313 482 78 313 minecraft:deepslate_tiles
setblock 483 75 276 minecraft:cobbled_deepslate
fill 483 75 277 483 77 277 minecraft:deepslate_tiles
fill 483 75 312 484 77 312 minecraft:deepslate_tiles
setblock 483 75 316 minecraft:cobbled_deepslate
fill 484 75 276 484 78 276 minecraft:deepslate_tiles
setblock 484 75 315 minecraft:cobbled_deepslate
fill 484 75 316 487 75 316 minecraft:deepslate_tiles
setblock 485 75 314 minecraft:cobbled_deepslate
fill 485 75 315 485 78 315 minecraft:deepslate_tiles
setblock 486 75 313 minecraft:cobbled_deepslate
fill 486 75 314 486 78 314 minecraft:deepslate_tiles
fill 487 75 313 487 76 313 minecraft:deepslate_tiles
fill 487 75 315 488 75 315 minecraft:deepslate_tiles
setblock 488 75 316 minecraft:cobbled_deepslate
setblock 489 75 315 minecraft:cobbled_deepslate
fill 489 75 316 489 78 316 minecraft:deepslate_tiles
fill 490 75 315 490 77 315 minecraft:deepslate_tiles
setblock 497 75 316 minecraft:deepslate_tiles
setblock 498 75 316 minecraft:cobbled_deepslate
fill 499 75 316 502 75 316 minecraft:deepslate_tiles
fill 500 75 315 503 75 315 minecraft:deepslate_tiles
setblock 501 75 275 minecraft:redstone_block
fill 501 75 276 502 75 276 minecraft:deepslate_tiles
setblock 503 75 276 minecraft:cobbled_deepslate
setblock 503 75 316 minecraft:cobbled_deepslate
fill 504 75 276 504 78 276 minecraft:deepslate_tiles
setblock 504 75 315 minecraft:cobbled_deepslate
fill 504 75 316 504 78 316 minecraft:deepslate_tiles
fill 505 75 315 505 78 315 minecraft:deepslate_tiles
setblock 507 75 316 minecraft:deepslate_tiles
setblock 508 75 276 minecraft:cobbled_deepslate
setblock 508 75 287 minecraft:deepslate_tiles
fill 508 75 317 508 94 317 minecraft:cobbled_deepslate
setblock 509 75 284 minecraft:deepslate_tiles
setblock 509 75 285 minecraft:cobbled_deepslate
fill 509 75 286 509 77 286 minecraft:deepslate_tiles
fill 509 75 288 509 75 289 minecraft:deepslate_tiles
setblock 509 75 290 minecraft:cobbled_deepslate
fill 509 75 291 509 78 291 minecraft:deepslate_tiles
fill 510 75 282 510 75 283 minecraft:deepslate_tiles
setblock 510 75 284 minecraft:cobbled_deepslate
fill 510 75 285 510 78 285 minecraft:deepslate_tiles
setblock 510 75 288 minecraft:deepslate_tiles
setblock 510 75 289 minecraft:cobbled_deepslate
fill 510 75 290 510 78 290 minecraft:deepslate_tiles
fill 510 75 292 510 75 293 minecraft:deepslate_tiles
setblock 510 75 294 minecraft:cobbled_deepslate
fill 511 75 280 511 75 282 minecraft:deepslate_tiles
setblock 511 75 283 minecraft:cobbled_deepslate
fill 511 75 284 511 78 284 minecraft:deepslate_tiles
setblock 511 75 288 minecraft:cobbled_deepslate
fill 511 75 289 511 78 289 minecraft:deepslate_tiles
setblock 511 75 292 minecraft:deepslate_tiles
setblock 511 75 293 minecraft:cobbled_deepslate
fill 511 75 294 511 78 294 minecraft:deepslate_tiles
setblock 511 75 308 minecraft:cobbled_deepslate
fill 511 75 309 511 76 309 minecraft:deepslate_tiles
setblock 511 75 312 minecraft:deepslate_tiles
fill 512 75 312 512 95 312 minecraft:cobbled_deepslate
setblock 471 76 276 minecraft:deepslate_tiles
setblock 471 76 277 minecraft:cobbled_deepslate
fill 471 76 278 471 76 281 minecraft:deepslate_tiles
setblock 471 76 282 minecraft:cobbled_deepslate
fill 471 76 283 471 76 286 minecraft:deepslate_tiles
setblock 471 76 287 minecraft:cobbled_deepslate
fill 471 76 288 471 78 289 minecraft:deepslate_tiles
setblock 471 76 292 minecraft:cobbled_deepslate
fill 471 76 308 471 77 308 minecraft:deepslate_tiles
setblock 471 76 311 minecraft:deepslate_tiles
setblock 471 76 312 minecraft:cobbled_deepslate
fill 471 76 313 472 78 313 minecraft:deepslate_tiles
setblock 471 76 316 minecraft:deepslate_tiles
setblock 472 76 276 minecraft:cobbled_deepslate
setblock 472 76 287 minecraft:deepslate_tiles
setblock 472 76 311 minecraft:cobbled_deepslate
fill 472 76 312 472 79 312 minecraft:deepslate_tiles
setblock 472 76 316 minecraft:cobbled_deepslate
fill 473 76 276 476 76 276 minecraft:deepslate_tiles
setblock 473 76 315 minecraft:cobbled_deepslate
fill 473 76 316 476 76 316 minecraft:deepslate_tiles
fill 474 76 315 477 76 315 minecraft:deepslate_tiles
fill 476 76 314 478 76 314 minecraft:deepslate_tiles
setblock 477 76 276 minecraft:cobbled_deepslate
setblock 477 76 316 minecraft:cobbled_deepslate
fill 478 76 276 480 76 277 minecraft:deepslate_tiles
fill 478 76 313 479 76 313 minecraft:deepslate_tiles
setblock 478 76 315 minecraft:cobbled_deepslate
fill 478 76 316 481 76 316 minecraft:deepslate_tiles
setblock 479 76 314 minecraft:cobbled_deepslate
fill 479 76 315 482 76 315 minecraft:deepslate_tiles
setblock 480 76 313 minecraft:cobbled_deepslate
fill 480 76 314 483 76 314 minecraft:deepslate_tiles
setblock 481 76 276 minecraft:deepslate_tiles
setblock 481 76 277 minecraft:cobbled_deepslate
setblock 481 76 312 minecraft:cobbled_deepslate
fill 481 76 313 481 79 313 minecraft:deepslate_tiles
setblock 482 76 276 minecraft:cobbled_deepslate
fill 482 76 277 482 78 277 minecraft:deepslate_tiles
fill 482 76 312 482 78 312 minecraft:deepslate_tiles
setblock 482 76 316 minecraft:cobbled_deepslate
fill 483 76 276 483 79 276 minecraft:deepslate_tiles
setblock 483 76 315 minecraft:cobbled_deepslate
fill 483 76 316 486 76 316 minecraft:deepslate_tiles
setblock 484 76 313 minecraft:deepslate_tiles
setblock 484 76 314 minecraft:cobbled_deepslate
fill 484 76 315 484 79 315 minecraft:deepslate_tiles
setblock 485 76 313 minecraft:cobbled_deepslate
fill 485 76 314 485 79 314 minecraft:deepslate_tiles
setblock 486 76 276 minecraft:deepslate_tiles
fill 486 76 313 486 78 313 minecraft:deepslate_tiles
setblock 487 76 315 minecraft:deepslate_tiles
setblock 487 76 316 minecraft:cobbled_deepslate
setblock 488 76 315 minecraft:cobbled_deepslate
fill 488 76 316 488 79 316 minecraft:deepslate_tiles
fill 489 76 315 489 78 315 minecraft:deepslate_tiles
setblock 492 76 316 minecraft:cobbled_deepslate
fill 495 76 316 496 76 316 minecraft:deepslate_tiles
setblock 497 76 316 minecraft:cobbled_deepslate
setblock 498 76 315 minecraft:cobbled_deepslate
fill 498 76 316 501 76 316 minecraft:deepslate_tiles
fill 499 76 315 502 76 315 minecraft:deepslate_tiles
fill 500 76 276 501 76 276 minecraft:deepslate_tiles
fill 501 76 275 501 95 275 minecraft:cobbled_deepslate
setblock 502 76 276 minecraft:cobbled_deepslate
setblock 502 76 316 minecraft:cobbled_deepslate
fill 503 76 276 503 79 276 minecraft:deepslate_tiles
setblock 503 76 315 minecraft:cobbled_deepslate
fill 503 76 316 503 79 316 minecraft:deepslate_tiles
fill 504 76 315 504 79 315 minecraft:deepslate_tiles
setblock 507 76 276 minecraft:cobbled_deepslate
setblock 507 76 316 minecraft:cobbled_deepslate
fill 508 76 276 508 79 276 minecraft:deepslate_tiles
fill 508 76 288 508 76 289 minecraft:deepslate_tiles
setblock 508 76 290 minecraft:cobbled_deepslate
fill 508 76 316 508 78 316 minecraft:deepslate_tiles
setblock 509 76 285 minecraft:deepslate_tiles
setblock 509 76 288 minecraft:deepslate_tiles
setblock 509 76 289 minecraft:cobbled_deepslate
fill 509 76 290 509 78 290 minecraft:deepslate_tiles
setblock 510 76 283 minecraft:cobbled_deepslate
fill 510 76 284 510 77 284 minecraft:deepslate_tiles
setblock 510 76 287 minecraft:deepslate_tiles
setblock 510 76 288 minecraft:cobbled_deepslate
fill 510 76 289 510 79 289 minecraft:deepslate_tiles
setblock 510 76 292 minecraft:deepslate_tiles
setblock 510 76 293 minecraft:cobbled_deepslate
fill 510 76 294 510 77 294 minecraft:deepslate_tiles
fill 511 76 280 511 76 281 minecraft:deepslate_tiles
setblock 511 76 282 minecraft:cobbled_deepslate
fill 511 76 283 511 78 283 minecraft:deepslate_tiles
setblock 511 76 287 minecraft:cobbled_deepslate
fill 511 76 288 511 79 288 minecraft:deepslate_tiles
setblock 511 76 292 minecraft:cobbled_deepslate
fill 511 76 293 511 79 293 minecraft:deepslate_tiles
setblock 511 76 312 minecraft:cobbled_deepslate
fill 511 76 313 511 78 313 minecraft:deepslate_tiles
setblock 470 77 290 minecraft:redstone_block
fill 470 77 291 470 94 295 minecraft:cobbled_deepslate
setblock 471 77 276 minecraft:cobbled_deepslate
fill 471 77 277 471 77 278 minecraft:deepslate_tiles
fill 471 77 282 471 77 285 minecraft:deepslate_tiles
setblock 471 77 286 minecraft:cobbled_deepslate
fill 471 77 287 471 79 287 minecraft:deepslate_tiles
setblock 471 77 291 minecraft:cobbled_deepslate
fill 471 77 292 471 77 293 minecraft:deepslate_tiles
setblock 471 77 311 minecraft:cobbled_deepslate
fill 471 77 312 471 80 312 minecraft:deepslate_tiles
setblock 471 77 316 minecraft:cobbled_deepslate
fill 472 77 276 475 77 276 minecraft:deepslate_tiles
fill 472 77 311 472 78 311 minecraft:deepslate_tiles
setblock 472 77 314 minecraft:deepslate_tiles
setblock 472 77 315 minecraft:cobbled_deepslate
fill 472 77 316 475 77 316 minecraft:deepslate_tiles
setblock 473 77 278 minecraft:light[level=13]
setblock 473 77 286 minecraft:light[level=13]
setblock 473 77 294 minecraft:light[level=13]
setblock 473 77 302 minecraft:light[level=13]
setblock 473 77 310 minecraft:light[level=13]
fill 473 77 315 476 77 315 minecraft:deepslate_tiles
fill 475 77 314 477 77 314 minecraft:deepslate_tiles
setblock 476 77 276 minecraft:cobbled_deepslate
setblock 476 77 316 minecraft:cobbled_deepslate
fill 477 77 276 479 77 277 minecraft:deepslate_tiles
fill 477 77 313 478 77 313 minecraft:deepslate_tiles
setblock 477 77 315 minecraft:cobbled_deepslate
fill 477 77 316 480 77 316 minecraft:deepslate_tiles
setblock 478 77 314 minecraft:cobbled_deepslate
fill 478 77 315 481 77 315 minecraft:deepslate_tiles
setblock 479 77 313 minecraft:cobbled_deepslate
fill 479 77 314 482 77 314 minecraft:deepslate_tiles
setblock 480 77 276 minecraft:deepslate_tiles
setblock 480 77 277 minecraft:cobbled_deepslate
setblock 480 77 312 minecraft:cobbled_deepslate
fill 480 77 313 480 80 313 minecraft:deepslate_tiles
setblock 481 77 276 minecraft:cobbled_deepslate
fill 481 77 277 481 80 277 minecraft:deepslate_tiles
setblock 481 77 278 minecraft:light[level=13]
setblock 481 77 286 minecraft:light[level=13]
setblock 481 77 294 minecraft:light[level=13]
setblock 481 77 302 minecraft:light[level=13]
setblock 481 77 310 minecraft:light[level=13]
fill 481 77 312 481 79 312 minecraft:deepslate_tiles
setblock 481 77 316 minecraft:cobbled_deepslate
fill 482 77 276 482 80 276 minecraft:deepslate_tiles
setblock 482 77 315 minecraft:cobbled_deepslate
fill 482 77 316 485 77 316 minecraft:deepslate_tiles
setblock 483 77 314 minecraft:cobbled_deepslate
fill 483 77 315 483 80 315 minecraft:deepslate_tiles
setblock 484 77 313 minecraft:cobbled_deepslate
fill 484 77 314 484 80 314 minecraft:deepslate_tiles
fill 485 77 313 485 79 313 minecraft:deepslate_tiles
setblock 486 77 276 minecraft:cobbled_deepslate
setblock 486 77 316 minecraft:cobbled_deepslate
setblock 487 77 314 minecraft:deepslate_tiles
setblock 487 77 315 minecraft:cobbled_deepslate
fill 487 77 316 487 80 316 minecraft:deepslate_tiles
setblock 488 77 314 minecraft:cobbled_deepslate
fill 488 77 315 488 79 315 minecraft:deepslate_tiles
setblock 489 77 278 minecraft:light[level=13]
setblock 489 77 286 minecraft:light[level=13]
setblock 489 77 294 minecraft:light[level=13]
setblock 489 77 302 minecraft:light[level=13]
setblock 489 77 310 minecraft:light[level=13]
setblock 490 77 316 minecraft:deepslate_tiles
setblock 491 77 316 minecraft:cobbled_deepslate
fill 492 77 316 495 77 316 minecraft:deepslate_tiles
setblock 496 77 316 minecraft:cobbled_deepslate
setblock 497 77 278 minecraft:light[level=13]
setblock 497 77 286 minecraft:light[level=13]
setblock 497 77 294 minecraft:light[level=13]
setblock 497 77 302 minecraft:light[level=13]
setblock 497 77 310 minecraft:light[level=13]
setblock 497 77 315 minecraft:cobbled_deepslate
fill 497 77 316 500 77 316 minecraft:deepslate_tiles
fill 498 77 315 501 77 315 minecraft:deepslate_tiles
fill 499 77 276 500 77 276 minecraft:deepslate_tiles
fill 500 77 314 502 77 314 minecraft:deepslate_tiles
setblock 501 77 276 minecraft:cobbled_deepslate
setblock 501 77 316 minecraft:cobbled_deepslate
fill 502 77 276 502 80 276 minecraft:deepslate_tiles
setblock 502 77 315 minecraft:cobbled_deepslate
fill 502 77 316 502 80 316 minecraft:deepslate_tiles
fill 503 77 315 503 80 315 minecraft:deepslate_tiles
setblock 505 77 278 minecraft:light[level=13]
setblock 505 77 286 minecraft:light[level=13]
setblock 505 77 294 minecraft:light[level=13]
setblock 505 77 302 minecraft:light[level=13]
setblock 505 77 310 minecraft:light[level=13]
setblock 505 77 316 minecraft:deepslate_tiles
setblock 506 77 276 minecraft:cobbled_deepslate
setblock 506 77 316 minecraft:cobbled_deepslate
fill 507 77 276 507 80 276 minecraft:deepslate_tiles
fill 507 77 316 507 80 316 minecraft:deepslate_tiles
setblock 509 77 288 minecraft:cobbled_deepslate
fill 509 77 289 509 78 289 minecraft:deepslate_tiles
setblock 510 77 287 minecraft:cobbled_deepslate
fill 510 77 288 510 79 288 minecraft:deepslate_tiles
setblock 510 77 292 minecraft:cobbled_deepslate
fill 510 77 293 510 79 293 minecraft:deepslate_tiles
setblock 511 77 281 minecraft:cobbled_deepslate
fill 511 77 282 511 78 282 minecraft:deepslate_tiles
setblock 511 77 286 minecraft:cobbled_deepslate
fill 511 77 287 511 80 287 minecraft:deepslate_tiles
setblock 511 77 291 minecraft:cobbled_deepslate
fill 511 77 292 511 80 292 minecraft:deepslate_tiles
setblock 511 77 311 minecraft:cobbled_deepslate
fill 511 77 312 511 78 312 minecraft:deepslate_tiles
fill 511 77 314 511 78 314 minecraft:deepslate_tiles
fill 470 78 290 471 78 290 minecraft:cobbled_deepslate
fill 471 78 276 471 80 277 minecraft:deepslate_tiles
setblock 471 78 285 minecraft:cobbled_deepslate
setblock 471 78 286 minecraft:deepslate_tiles
fill 471 78 291 471 79 292 minecraft:deepslate_tiles
setblock 471 78 310 minecraft:cobbled_deepslate
fill 471 78 311 471 81 311 minecraft:deepslate_tiles
setblock 471 78 315 minecraft:cobbled_deepslate
fill 471 78 316 474 78 316 minecraft:deepslate_tiles
fill 472 78 276 474 78 276 minecraft:deepslate_tiles
setblock 472 78 314 minecraft:cobbled_deepslate
fill 472 78 315 475 78 315 minecraft:deepslate_tiles
fill 474 78 300 474 86 300 minecraft:black_concrete
fill 474 78 314 476 78 314 minecraft:deepslate_tiles
setblock 475 78 276 minecraft:cobbled_deepslate
setblock 475 78 316 minecraft:cobbled_deepslate
fill 476 78 276 479 78 276 minecraft:deepslate_tiles
setblock 476 78 315 minecraft:cobbled_deepslate
fill 476 78 316 479 78 316 minecraft:deepslate_tiles
fill 477 78 277 478 78 277 minecraft:deepslate_tiles
setblock 477 78 313 minecraft:deepslate_tiles
setblock 477 78 314 minecraft:cobbled_deepslate
fill 477 78 315 480 78 315 minecraft:deepslate_tiles
fill 478 78 278 478 82 278 minecraft:black_concrete
setblock 478 78 313 minecraft:cobbled_deepslate
fill 478 78 314 481 78 314 minecraft:deepslate_tiles
setblock 479 78 277 minecraft:cobbled_deepslate
fill 479 78 279 479 82 279 minecraft:black_concrete
fill 479 78 313 479 81 313 minecraft:deepslate_tiles
setblock 480 78 276 minecraft:cobbled_deepslate
fill 480 78 277 480 81 277 minecraft:deepslate_tiles
fill 480 78 278 480 82 278 minecraft:black_concrete
setblock 480 78 312 minecraft:deepslate_tiles
setblock 480 78 316 minecraft:cobbled_deepslate
fill 481 78 276 481 81 276 minecraft:deepslate_tiles
setblock 481 78 315 minecraft:cobbled_deepslate
fill 481 78 316 484 78 316 minecraft:deepslate_tiles
setblock 482 78 314 minecraft:cobbled_deepslate
fill 482 78 315 482 81 315 minecraft:deepslate_tiles
setblock 483 78 312 minecraft:deepslate_tiles
setblock 483 78 313 minecraft:cobbled_deepslate
fill 483 78 314 483 81 314 minecraft:deepslate_tiles
fill 484 78 313 484 79 313 minecraft:deepslate_tiles
setblock 485 78 275 minecraft:white_wool
setblock 485 78 276 minecraft:cobbled_deepslate
setblock 485 78 316 minecraft:cobbled_deepslate
setblock 486 78 315 minecraft:cobbled_deepslate
fill 486 78 316 486 81 316 minecraft:deepslate_tiles
setblock 487 78 314 minecraft:cobbled_deepslate
fill 487 78 315 487 80 315 minecraft:deepslate_tiles
setblock 490 78 316 minecraft:cobbled_deepslate
fill 491 78 316 494 78 316 minecraft:deepslate_tiles
setblock 495 78 316 minecraft:cobbled_deepslate
setblock 496 78 315 minecraft:cobbled_deepslate
fill 496 78 316 499 78 316 minecraft:deepslate_tiles
fill 497 78 315 500 78 315 minecraft:deepslate_tiles
fill 498 78 276 499 78 276 minecraft:deepslate_tiles
setblock 500 78 276 minecraft:cobbled_deepslate
fill 500 78 314 501 78 314 minecraft:deepslate_tiles
setblock 500 78 316 minecraft:cobbled_deepslate
fill 501 78 276 501 81 276 minecraft:deepslate_tiles
setblock 501 78 315 minecraft:cobbled_deepslate
fill 501 78 316 501 81 316 minecraft:deepslate_tiles
fill 502 78 315 502 81 315 minecraft:deepslate_tiles
setblock 505 78 276 minecraft:cobbled_deepslate
setblock 505 78 316 minecraft:cobbled_deepslate
fill 506 78 276 506 81 276 minecraft:deepslate_tiles
fill 506 78 316 506 81 316 minecraft:deepslate_tiles
setblock 509 78 288 minecraft:deepslate_tiles
setblock 510 78 286 minecraft:cobbled_deepslate
fill 510 78 287 510 79 287 minecraft:deepslate_tiles
setblock 510 78 291 minecraft:cobbled_deepslate
fill 510 78 292 510 79 292 minecraft:deepslate_tiles
setblock 511 78 285 minecraft:cobbled_deepslate
fill 511 78 286 511 80 286 minecraft:deepslate_tiles
setblock 511 78 290 minecraft:cobbled_deepslate
fill 511 78 291 511 81 291 minecraft:deepslate_tiles
setblock 511 78 295 minecraft:cobbled_deepslate
setblock 512 78 276 minecraft:redstone_block
setblock 512 78 296 minecraft:redstone_block
fill 470 79 290 470 94 290 minecraft:cobbled_deepslate
setblock 471 79 288 minecraft:deepslate_tiles
setblock 471 79 289 minecraft:cobbled_deepslate
setblock 471 79 290 minecraft:deepslate_tiles
fill 471 79 310 471 80 310 minecraft:deepslate_tiles
setblock 471 79 313 minecraft:deepslate_tiles
setblock 471 79 314 minecraft:cobbled_deepslate
fill 471 79 315 473 79 316 minecraft:deepslate_tiles
fill 472 79 276 473 79 276 minecraft:deepslate_tiles
setblock 472 79 313 minecraft:cobbled_deepslate
fill 472 79 314 472 82 314 minecraft:deepslate_tiles
setblock 473 79 278 minecraft:light[level=12]
setblock 473 79 285 minecraft:light[level=12]
setblock 473 79 292 minecraft:light[level=12]
setblock 473 79 299 minecraft:light[level=12]
setblock 473 79 306 minecraft:light[level=12]
setblock 473 79 313 minecraft:light[level=12]
setblock 474 79 276 minecraft:cobbled_deepslate
fill 474 79 314 474 79 315 minecraft:deepslate_tiles
setblock 474 79 316 minecraft:cobbled_deepslate
fill 475 79 276 478 79 276 minecraft:deepslate_tiles
setblock 475 79 314 minecraft:deepslate_tiles
setblock 475 79 315 minecraft:cobbled_deepslate
fill 475 79 316 478 79 316 minecraft:deepslate_tiles
setblock 476 79 314 minecraft:cobbled_deepslate
fill 476 79 315 479 79 315 minecraft:deepslate_tiles
setblock 477 79 277 minecraft:deepslate_tiles
setblock 477 79 313 minecraft:cobbled_deepslate
fill 477 79 314 480 79 314 minecraft:deepslate_tiles
setblock 478 79 277 minecraft:cobbled_deepslate
fill 478 79 279 478 82 279 minecraft:black_concrete
fill 478 79 313 478 82 313 minecraft:deepslate_tiles
setblock 479 79 276 minecraft:cobbled_deepslate
fill 479 79 277 479 82 277 minecraft:deepslate_tiles
setblock 479 79 316 minecraft:cobbled_deepslate
fill 480 79 276 480 82 276 minecraft:deepslate_tiles
fill 480 79 279 480 82 279 minecraft:black_concrete
setblock 480 79 285 minecraft:light[level=12]
fill 480 79 287 481 80 289 minecraft:white_wool
setblock 480 79 292 minecraft:light[level=12]
setblock 480 79 299 minecraft:light[level=12]
setblock 480 79 306 minecraft:light[level=12]
setblock 480 79 315 minecraft:cobbled_deepslate
fill 480 79 316 483 79 316 minecraft:deepslate_tiles
setblock 481 79 314 minecraft:cobbled_deepslate
fill 481 79 315 481 82 315 minecraft:deepslate_tiles
setblock 482 79 313 minecraft:cobbled_deepslate
fill 482 79 314 482 82 314 minecraft:deepslate_tiles
fill 483 79 313 483 80 313 minecraft:deepslate_tiles
setblock 484 79 276 minecraft:cobbled_deepslate
setblock 484 79 316 minecraft:cobbled_deepslate
setblock 485 79 275 minecraft:cobbled_deepslate
setblock 485 79 276 minecraft:deepslate_tiles
setblock 485 79 315 minecraft:cobbled_deepslate
fill 485 79 316 485 82 316 minecraft:deepslate_tiles
setblock 486 79 314 minecraft:cobbled_deepslate
fill 486 79 315 486 81 315 minecraft:deepslate_tiles
setblock 487 79 278 minecraft:light[level=12]
setblock 487 79 285 minecraft:light[level=12]
setblock 487 79 292 minecraft:light[level=12]
setblock 487 79 299 minecraft:light[level=12]
setblock 487 79 306 minecraft:light[level=12]
setblock 487 79 313 minecraft:light[level=12]
setblock 487 79 314 minecraft:deepslate_tiles
setblock 489 79 316 minecraft:cobbled_deepslate
fill 490 79 316 493 79 316 minecraft:deepslate_tiles
setblock 494 79 278 minecraft:light[level=12]
setblock 494 79 285 minecraft:light[level=12]
setblock 494 79 292 minecraft:light[level=12]
setblock 494 79 299 minecraft:light[level=12]
setblock 494 79 306 minecraft:light[level=12]
setblock 494 79 313 minecraft:light[level=12]
setblock 494 79 316 minecraft:cobbled_deepslate
fill 495 79 316 498 79 316 minecraft:deepslate_tiles
fill 496 79 315 499 79 315 minecraft:deepslate_tiles
setblock 498 79 276 minecraft:deepslate_tiles
setblock 499 79 276 minecraft:cobbled_deepslate
setblock 499 79 316 minecraft:cobbled_deepslate
fill 500 79 276 500 82 276 minecraft:deepslate_tiles
setblock 500 79 315 minecraft:cobbled_deepslate
fill 500 79 316 500 82 316 minecraft:deepslate_tiles
setblock 501 79 278 minecraft:light[level=12]
setblock 501 79 285 minecraft:light[level=12]
setblock 501 79 292 minecraft:light[level=12]
setblock 501 79 299 minecraft:light[level=12]
setblock 501 79 306 minecraft:light[level=12]
setblock 501 79 313 minecraft:light[level=12]
fill 501 79 315 501 82 315 minecraft:deepslate_tiles
setblock 504 79 276 minecraft:cobbled_deepslate
setblock 504 79 316 minecraft:cobbled_deepslate
fill 505 79 276 505 82 276 minecraft:deepslate_tiles
fill 505 79 316 505 82 316 minecraft:deepslate_tiles
setblock 508 79 278 minecraft:light[level=12]
setblock 508 79 285 minecraft:light[level=12]
setblock 508 79 292 minecraft:light[level=12]
setblock 508 79 299 minecraft:light[level=12]
setblock 508 79 306 minecraft:light[level=12]
setblock 508 79 313 minecraft:light[level=12]
setblock 510 79 290 minecraft:cobbled_deepslate
fill 510 79 291 510 80 291 minecraft:deepslate_tiles
fill 511 79 276 511 81 276 minecraft:deepslate_tiles
setblock 511 79 284 minecraft:cobbled_deepslate
fill 511 79 285 511 80 285 minecraft:deepslate_tiles
fill 511 79 289 512 79 289 minecraft:cobbled_deepslate
fill 511 79 290 511 82 290 minecraft:deepslate_tiles
setblock 511 79 294 minecraft:cobbled_deepslate
fill 511 79 295 511 80 295 minecraft:deepslate_tiles
setblock 511 79 314 minecraft:cobbled_deepslate
setblock 511 79 315 minecraft:deepslate_tiles
fill 512 79 276 512 94 276 minecraft:cobbled_deepslate
fill 512 79 288 512 92 288 minecraft:cobbled_deepslate
fill 512 79 290 512 81 290 minecraft:cobbled_deepslate
setblock 512 79 291 minecraft:white_wool
fill 512 79 296 512 94 296 minecraft:cobbled_deepslate
setblock 471 80 313 minecraft:cobbled_deepslate
fill 471 80 314 471 81 316 minecraft:deepslate_tiles
setblock 472 80 276 minecraft:deepslate_tiles
setblock 472 80 312 minecraft:cobbled_deepslate
fill 472 80 313 472 83 313 minecraft:deepslate_tiles
fill 472 80 315 472 80 316 minecraft:deepslate_tiles
setblock 473 80 276 minecraft:cobbled_deepslate
setblock 473 80 315 minecraft:deepslate_tiles
setblock 473 80 316 minecraft:cobbled_deepslate
fill 474 80 276 477 80 276 minecraft:deepslate_tiles
setblock 474 80 314 minecraft:deepslate_tiles
setblock 474 80 315 minecraft:cobbled_deepslate
fill 474 80 316 477 80 316 minecraft:deepslate_tiles
setblock 475 80 314 minecraft:cobbled_deepslate
fill 475 80 315 478 80 315 minecraft:deepslate_tiles
setblock 476 80 277 minecraft:deepslate_tiles
fill 476 80 314 479 80 314 minecraft:deepslate_tiles
setblock 477 80 277 minecraft:cobbled_deepslate
fill 477 80 313 477 82 313 minecraft:deepslate_tiles
setblock 478 80 276 minecraft:cobbled_deepslate
fill 478 80 277 478 83 277 minecraft:deepslate_tiles
setblock 478 80 316 minecraft:cobbled_deepslate
fill 479 80 276 479 83 276 minecraft:deepslate_tiles
setblock 479 80 315 minecraft:cobbled_deepslate
fill 479 80 316 482 80 316 minecraft:deepslate_tiles
setblock 480 80 314 minecraft:cobbled_deepslate
fill 480 80 315 480 83 315 minecraft:deepslate_tiles
setblock 481 80 313 minecraft:cobbled_deepslate
fill 481 80 314 481 83 314 minecraft:deepslate_tiles
fill 482 80 313 482 81 313 minecraft:deepslate_tiles
setblock 483 80 276 minecraft:cobbled_deepslate
setblock 483 80 316 minecraft:cobbled_deepslate
fill 484 80 276 484 81 276 minecraft:deepslate_tiles
setblock 484 80 315 minecraft:cobbled_deepslate
fill 484 80 316 484 83 316 minecraft:deepslate_tiles
setblock 485 80 275 minecraft:redstone_block
setblock 485 80 314 minecraft:cobbled_deepslate
fill 485 80 315 485 83 315 minecraft:deepslate_tiles
setblock 486 80 314 minecraft:deepslate_tiles
setblock 488 80 316 minecraft:cobbled_deepslate
fill 489 80 316 492 80 316 minecraft:deepslate_tiles
setblock 493 80 316 minecraft:cobbled_deepslate
fill 494 80 316 497 80 316 minecraft:deepslate_tiles
fill 496 80 315 498 80 315 minecraft:deepslate_tiles
setblock 497 80 276 minecraft:deepslate_tiles
setblock 498 80 276 minecraft:cobbled_deepslate
setblock 498 80 316 minecraft:cobbled_deepslate
fill 499 80 276 499 83 276 minecraft:deepslate_tiles
setblock 499 80 315 minecraft:cobbled_deepslate
fill 499 80 316 499 83 316 minecraft:deepslate_tiles
fill 500 80 315 500 83 315 minecraft:deepslate_tiles
setblock 503 80 276 minecraft:cobbled_deepslate
setblock 503 80 316 minecraft:cobbled_deepslate
fill 504 80 276 504 83 276 minecraft:deepslate_tiles
fill 504 80 316 504 83 316 minecraft:deepslate_tiles
setblock 508 80 276 minecraft:cobbled_deepslate
fill 510 80 276 510 82 276 minecraft:deepslate_tiles
setblock 510 80 290 minecraft:deepslate_tiles
setblock 511 80 288 minecraft:cobbled_deepslate
fill 511 80 289 511 82 289 minecraft:deepslate_tiles
setblock 511 80 293 minecraft:cobbled_deepslate
fill 511 80 294 511 83 294 minecraft:deepslate_tiles
fill 512 80 289 512 94 289 minecraft:cobbled_deepslate
fill 512 80 291 512 90 291 minecraft:cobbled_deepslate
setblock 470 81 316 minecraft:white_wool
setblock 471 81 276 minecraft:deepslate_tiles
setblock 471 81 277 minecraft:cobbled_deepslate
setblock 471 81 312 minecraft:cobbled_deepslate
fill 471 81 313 471 84 313 minecraft:deepslate_tiles
setblock 472 81 276 minecraft:cobbled_deepslate
setblock 472 81 315 minecraft:deepslate_tiles
setblock 472 81 316 minecraft:cobbled_deepslate
fill 473 81 276 476 81 276 minecraft:deepslate_tiles
setblock 473 81 315 minecraft:cobbled_deepslate
fill 473 81 316 476 81 316 minecraft:deepslate_tiles
setblock 474 81 314 minecraft:cobbled_deepslate
fill 474 81 315 477 81 315 minecraft:deepslate_tiles
fill 475 81 314 478 81 314 minecraft:deepslate_tiles
setblock 476 81 277 minecraft:cobbled_deepslate
setblock 477 81 276 minecraft:cobbled_deepslate
fill 477 81 277 477 84 277 minecraft:deepslate_tiles
setblock 477 81 316 minecraft:cobbled_deepslate
fill 478 81 276 478 84 276 minecraft:deepslate_tiles
setblock 478 81 315 minecraft:cobbled_deepslate
fill 478 81 316 481 81 316 minecraft:deepslate_tiles
setblock 479 81 314 minecraft:cobbled_deepslate
fill 479 81 315 479 84 315 minecraft:deepslate_tiles
setblock 480 81 313 minecraft:cobbled_deepslate
fill 480 81 314 480 84 314 minecraft:deepslate_tiles
setblock 481 81 313 minecraft:deepslate_tiles
setblock 482 81 276 minecraft:cobbled_deepslate
setblock 482 81 316 minecraft:cobbled_deepslate
fill 483 81 276 483 84 276 minecraft:deepslate_tiles
setblock 483 81 315 minecraft:cobbled_deepslate
fill 483 81 316 483 84 316 minecraft:deepslate_tiles
setblock 484 81 314 minecraft:cobbled_deepslate
fill 484 81 315 484 84 315 minecraft:deepslate_tiles
fill 485 81 275 485 94 275 minecraft:cobbled_deepslate
setblock 487 81 316 minecraft:cobbled_deepslate
fill 488 81 316 490 81 316 minecraft:deepslate_tiles
setblock 492 81 316 minecraft:cobbled_deepslate
fill 493 81 316 496 81 316 minecraft:deepslate_tiles
fill 496 81 315 497 81 315 minecraft:deepslate_tiles
setblock 497 81 276 minecraft:cobbled_deepslate
setblock 497 81 316 minecraft:cobbled_deepslate
fill 498 81 276 498 84 276 minecraft:deepslate_tiles
setblock 498 81 315 minecraft:cobbled_deepslate
fill 498 81 316 498 84 316 minecraft:deepslate_tiles
fill 499 81 283 499 82 283 minecraft:white_wool
fill 499 81 315 499 84 315 minecraft:deepslate_tiles
setblock 502 81 276 minecraft:cobbled_deepslate
setblock 502 81 316 minecraft:cobbled_deepslate
setblock 503 81 275 minecraft:redstone_block
fill 503 81 276 503 84 276 minecraft:deepslate_tiles
fill 503 81 316 503 84 316 minecraft:deepslate_tiles
setblock 507 81 276 minecraft:cobbled_deepslate
fill 508 81 276 509 83 276 minecraft:deepslate_tiles
setblock 511 81 277 minecraft:cobbled_deepslate
setblock 511 81 287 minecraft:cobbled_deepslate
setblock 511 81 288 minecraft:deepslate_tiles
setblock 511 81 292 minecraft:cobbled_deepslate
fill 511 81 293 511 84 293 minecraft:deepslate_tiles
setblock 511 81 316 minecraft:deepslate_tiles
setblock 470 82 301 minecraft:redstone_block
fill 470 82 302 470 90 303 minecraft:cobbled_deepslate
fill 470 82 316 471 82 316 minecraft:cobbled_deepslate
setblock 471 82 276 minecraft:cobbled_deepslate
fill 471 82 277 471 85 277 minecraft:deepslate_tiles
setblock 471 82 311 minecraft:cobbled_deepslate
fill 471 82 312 471 85 312 minecraft:deepslate_tiles
fill 471 82 314 471 82 315 minecraft:deepslate_tiles
fill 472 82 276 475 82 276 minecraft:deepslate_tiles
setblock 472 82 315 minecraft:cobbled_deepslate
fill 472 82 316 475 82 316 minecraft:deepslate_tiles
fill 473 82 315 476 82 315 minecraft:deepslate_tiles
fill 474 82 314 477 82 314 minecraft:deepslate_tiles
setblock 475 82 277 minecraft:cobbled_deepslate
setblock 476 82 276 minecraft:cobbled_deepslate
fill 476 82 277 476 85 277 minecraft:deepslate_tiles
setblock 476 82 316 minecraft:cobbled_deepslate
fill 477 82 276 477 85 276 minecraft:deepslate_tiles
setblock 477 82 278 minecraft:black_concrete
setblock 477 82 315 minecraft:cobbled_deepslate
fill 477 82 316 480 82 316 minecraft:deepslate_tiles
setblock 478 82 314 minecraft:cobbled_deepslate
fill 478 82 315 478 85 315 minecraft:deepslate_tiles
setblock 479 82 280 minecraft:black_concrete
setblock 479 82 313 minecraft:cobbled_deepslate
fill 479 82 314 479 85 314 minecraft:deepslate_tiles
setblock 480 82 277 minecraft:cobbled_deepslate
setblock 480 82 313 minecraft:deepslate_tiles
setblock 481 82 276 minecraft:cobbled_deepslate
setblock 481 82 278 minecraft:black_concrete
setblock 481 82 316 minecraft:cobbled_deepslate
fill 482 82 276 482 85 276 minecraft:deepslate_tiles
setblock 482 82 315 minecraft:cobbled_deepslate
fill 482 82 316 482 85 316 minecraft:deepslate_tiles
setblock 483 82 314 minecraft:cobbled_deepslate
fill 483 82 315 483 85 315 minecraft:deepslate_tiles
setblock 486 82 316 minecraft:cobbled_deepslate
fill 487 82 316 488 82 316 minecraft:deepslate_tiles
fill 493 82 316 495 82 316 minecraft:deepslate_tiles
setblock 496 82 276 minecraft:cobbled_deepslate
setblock 496 82 316 minecraft:cobbled_deepslate
fill 497 82 276 497 85 276 minecraft:deepslate_tiles
fill 497 82 290 497 83 291 minecraft:white_wool
setblock 497 82 315 minecraft:cobbled_deepslate
fill 497 82 316 497 85 316 minecraft:deepslate_tiles
fill 498 82 315 498 85 315 minecraft:deepslate_tiles
setblock 501 82 276 minecraft:cobbled_deepslate
setblock 501 82 316 minecraft:cobbled_deepslate
fill 502 82 276 502 85 276 minecraft:deepslate_tiles
fill 502 82 316 502 85 316 minecraft:deepslate_tiles
fill 503 82 275 503 94 275 minecraft:cobbled_deepslate
setblock 506 82 276 minecraft:cobbled_deepslate
fill 507 82 276 507 85 276 minecraft:deepslate_tiles
setblock 511 82 276 minecraft:cobbled_deepslate
fill 511 82 277 511 85 277 minecraft:deepslate_tiles
setblock 511 82 291 minecraft:cobbled_deepslate
fill 511 82 292 511 85 292 minecraft:deepslate_tiles
setblock 511 82 315 minecraft:deepslate_tiles
setblock 511 82 316 minecraft:cobbled_deepslate
setblock 512 82 290 minecraft:white_wool
setblock 470 83 281 minecraft:redstone_block
fill 470 83 301 470 94 301 minecraft:cobbled_deepslate
fill 470 83 316 470 92 316 minecraft:cobbled_deepslate
fill 471 83 276 474 83 276 minecraft:deepslate_tiles
fill 471 83 278 471 84 278 minecraft:deepslate_tiles
setblock 471 83 314 minecraft:deepslate_tiles
setblock 471 83 315 minecraft:cobbled_deepslate
fill 471 83 316 474 83 316 minecraft:deepslate_tiles
setblock 472 83 314 minecraft:cobbled_deepslate
fill 472 83 315 475 83 315 minecraft:deepslate_tiles
fill 473 83 300 473 86 300 minecraft:black_concrete
setblock 474 83 277 minecraft:cobbled_deepslate
fill 474 83 299 474 86 299 minecraft:black_concrete
fill 474 83 301 474 86 301 minecraft:black_concrete
fill 474 83 314 476 83 314 minecraft:deepslate_tiles
setblock 475 83 276 minecraft:cobbled_deepslate
fill 475 83 277 475 86 277 minecraft:deepslate_tiles
fill 475 83 300 475 86 300 minecraft:black_concrete
setblock 475 83 316 minecraft:cobbled_deepslate
fill 476 83 276 476 86 276 minecraft:deepslate_tiles
setblock 476 83 315 minecraft:cobbled_deepslate
fill 476 83 316 479 83 316 minecraft:deepslate_tiles
setblock 477 83 314 minecraft:cobbled_deepslate
fill 477 83 315 477 86 315 minecraft:deepslate_tiles
setblock 478 83 313 minecraft:cobbled_deepslate
fill 478 83 314 478 86 314 minecraft:deepslate_tiles
setblock 479 83 277 minecraft:cobbled_deepslate
setblock 480 83 276 minecraft:cobbled_deepslate
setblock 480 83 316 minecraft:cobbled_deepslate
fill 481 83 276 481 86 276 minecraft:deepslate_tiles
setblock 481 83 315 minecraft:cobbled_deepslate
fill 481 83 316 481 86 316 minecraft:deepslate_tiles
setblock 482 83 314 minecraft:cobbled_deepslate
fill 482 83 315 482 86 315 minecraft:deepslate_tiles
setblock 485 83 316 minecraft:cobbled_deepslate
fill 486 83 316 487 84 316 minecraft:deepslate_tiles
fill 492 83 316 494 83 316 minecraft:deepslate_tiles
setblock 495 83 276 minecraft:cobbled_deepslate
setblock 495 83 316 minecraft:cobbled_deepslate
fill 496 83 276 496 86 276 minecraft:deepslate_tiles
fill 496 83 316 496 86 316 minecraft:deepslate_tiles
fill 497 83 315 497 86 315 minecraft:deepslate_tiles
setblock 499 83 277 minecraft:cobbled_deepslate
fill 499 83 282 499 91 283 minecraft:black_concrete
setblock 500 83 276 minecraft:cobbled_deepslate
fill 500 83 277 500 86 277 minecraft:deepslate_tiles
setblock 500 83 316 minecraft:cobbled_deepslate
fill 501 83 276 501 86 276 minecraft:deepslate_tiles
fill 501 83 316 501 86 316 minecraft:deepslate_tiles
setblock 505 83 276 minecraft:cobbled_deepslate
fill 506 83 276 506 86 276 minecraft:deepslate_tiles
setblock 510 83 276 minecraft:cobbled_deepslate
fill 511 83 276 511 86 276 minecraft:deepslate_tiles
fill 511 83 278 511 84 278 minecraft:deepslate_tiles
setblock 511 83 291 minecraft:deepslate_tiles
setblock 511 83 315 minecraft:cobbled_deepslate
fill 511 83 316 511 86 316 minecraft:deepslate_tiles
fill 512 83 290 512 91 290 minecraft:cobbled_deepslate
fill 470 84 281 470 94 281 minecraft:cobbled_deepslate
setblock 470 84 298 minecraft:redstone_block
fill 471 84 276 473 84 276 minecraft:deepslate_tiles
setblock 471 84 314 minecraft:cobbled_deepslate
fill 471 84 315 473 84 316 minecraft:deepslate_tiles
setblock 472 84 277 minecraft:deepslate_tiles
setblock 472 84 313 minecraft:cobbled_deepslate
fill 472 84 314 472 87 314 minecraft:deepslate_tiles
setblock 473 84 277 minecraft:cobbled_deepslate
setblock 474 84 276 minecraft:cobbled_deepslate
fill 474 84 277 474 87 277 minecraft:deepslate_tiles
fill 474 84 314 474 84 315 minecraft:deepslate_tiles
setblock 474 84 316 minecraft:cobbled_deepslate
fill 475 84 276 475 87 276 minecraft:deepslate_tiles
setblock 475 84 314 minecraft:deepslate_tiles
setblock 475 84 315 minecraft:cobbled_deepslate
fill 475 84 316 478 84 316 minecraft:deepslate_tiles
setblock 476 84 314 minecraft:cobbled_deepslate
fill 476 84 315 476 87 315 minecraft:deepslate_tiles
fill 477 84 314 477 87 314 minecraft:deepslate_tiles
setblock 478 84 277 minecraft:cobbled_deepslate
setblock 479 84 276 minecraft:cobbled_deepslate
fill 479 84 277 480 86 277 minecraft:deepslate_tiles
setblock 479 84 316 minecraft:cobbled_deepslate
fill 480 84 276 480 87 276 minecraft:deepslate_tiles
setblock 480 84 315 minecraft:cobbled_deepslate
fill 480 84 316 480 87 316 minecraft:deepslate_tiles
setblock 481 84 314 minecraft:cobbled_deepslate
fill 481 84 315 481 87 315 minecraft:deepslate_tiles
setblock 484 84 275 minecraft:redstone_block
setblock 484 84 316 minecraft:cobbled_deepslate
fill 485 84 316 485 87 316 minecraft:deepslate_tiles
fill 492 84 316 493 84 316 minecraft:deepslate_tiles
setblock 494 84 276 minecraft:cobbled_deepslate
setblock 494 84 316 minecraft:cobbled_deepslate
fill 495 84 276 495 87 276 minecraft:deepslate_tiles
fill 495 84 316 495 87 316 minecraft:deepslate_tiles
setblock 497 84 277 minecraft:deepslate_tiles
setblock 498 84 277 minecraft:cobbled_deepslate
setblock 499 84 276 minecraft:cobbled_deepslate
fill 499 84 277 499 87 277 minecraft:deepslate_tiles
setblock 499 84 316 minecraft:cobbled_deepslate
fill 500 84 276 500 87 276 minecraft:deepslate_tiles
fill 500 84 316 500 87 316 minecraft:deepslate_tiles
fill 501 84 277 502 84 277 minecraft:deepslate_tiles
setblock 504 84 276 minecraft:cobbled_deepslate
setblock 504 84 316 minecraft:cobbled_deepslate
fill 505 84 276 505 87 276 minecraft:deepslate_tiles
setblock 508 84 276 minecraft:deepslate_tiles
setblock 509 84 276 minecraft:cobbled_deepslate
fill 510 84 276 510 87 276 minecraft:deepslate_tiles
fill 510 84 316 510 87 316 minecraft:deepslate_tiles
setblock 511 84 279 minecraft:cobbled_deepslate
fill 511 84 280 511 87 280 minecraft:deepslate_tiles
setblock 511 84 294 minecraft:cobbled_deepslate
fill 511 84 315 511 87 315 minecraft:deepslate_tiles
fill 470 85 298 470 94 298 minecraft:cobbled_deepslate
fill 471 85 276 472 85 276 minecraft:deepslate_tiles
setblock 471 85 278 minecraft:cobbled_deepslate
fill 471 85 279 471 88 279 minecraft:deepslate_tiles
fill 471 85 311 471 86 311 minecraft:deepslate_tiles
setblock 471 85 313 minecraft:cobbled_deepslate
fill 471 85 314 471 86 316 minecraft:deepslate_tiles
setblock 472 85 277 minecraft:cobbled_deepslate
fill 472 85 278 472 88 278 minecraft:deepslate_tiles
fill 472 85 313 472 88 313 minecraft:deepslate_tiles
fill 472 85 315 472 85 316 minecraft:deepslate_tiles
setblock 473 85 276 minecraft:cobbled_deepslate
fill 473 85 277 473 88 277 minecraft:deepslate_tiles
setblock 473 85 278 minecraft:light[level=13]
setblock 473 85 285 minecraft:light[level=12]
setblock 473 85 286 minecraft:light[level=13]
setblock 473 85 292 minecraft:light[level=12]
setblock 473 85 294 minecraft:light[level=13]
setblock 473 85 299 minecraft:light[level=12]
setblock 473 85 302 minecraft:light[level=13]
setblock 473 85 306 minecraft:light[level=12]
setblock 473 85 310 minecraft:light[level=13]
setblock 473 85 313 minecraft:light[level=12]
fill 473 85 314 473 85 315 minecraft:deepslate_tiles
setblock 473 85 316 minecraft:cobbled_deepslate
fill 474 85 276 474 88 276 minecraft:deepslate_tiles
setblock 474 85 314 minecraft:deepslate_tiles
setblock 474 85 315 minecraft:cobbled_deepslate
fill 474 85 316 477 85 316 minecraft:deepslate_tiles
setblock 475 85 314 minecraft:cobbled_deepslate
fill 475 85 315 475 88 315 minecraft:deepslate_tiles
fill 476 85 314 476 88 314 minecraft:deepslate_tiles
setblock 477 85 277 minecraft:cobbled_deepslate
setblock 478 85 276 minecraft:cobbled_deepslate
fill 478 85 277 478 88 277 minecraft:deepslate_tiles
setblock 478 85 316 minecraft:cobbled_deepslate
fill 479 85 276 479 88 276 minecraft:deepslate_tiles
setblock 479 85 315 minecraft:cobbled_deepslate
fill 479 85 316 479 88 316 minecraft:deepslate_tiles
setblock 480 85 278 minecraft:light[level=12]
setblock 480 85 285 minecraft:light[level=12]
setblock 480 85 292 minecraft:light[level=12]
setblock 480 85 299 minecraft:light[level=12]
setblock 480 85 306 minecraft:light[level=12]
setblock 480 85 313 minecraft:light[level=12]
setblock 480 85 314 minecraft:cobbled_deepslate
fill 480 85 315 480 88 315 minecraft:deepslate_tiles
setblock 481 85 278 minecraft:light[level=13]
setblock 481 85 286 minecraft:light[level=13]
setblock 481 85 294 minecraft:light[level=13]
setblock 481 85 302 minecraft:light[level=13]
setblock 481 85 310 minecraft:light[level=13]
setblock 481 85 314 minecraft:deepslate_tiles
setblock 483 85 276 minecraft:cobbled_deepslate
setblock 483 85 316 minecraft:cobbled_deepslate
fill 484 85 275 484 94 275 minecraft:cobbled_deepslate
fill 484 85 316 484 88 316 minecraft:deepslate_tiles
fill 486 85 316 486 86 316 minecraft:deepslate_tiles
setblock 487 85 278 minecraft:light[level=12]
setblock 487 85 285 minecraft:light[level=12]
setblock 487 85 292 minecraft:light[level=12]
setblock 487 85 299 minecraft:light[level=12]
setblock 487 85 306 minecraft:light[level=12]
setblock 487 85 313 minecraft:light[level=12]
setblock 489 85 278 minecraft:light[level=13]
setblock 489 85 286 minecraft:light[level=13]
setblock 489 85 294 minecraft:light[level=13]
setblock 489 85 302 minecraft:light[level=13]
setblock 489 85 310 minecraft:light[level=13]
fill 491 85 316 492 85 316 minecraft:deepslate_tiles
setblock 493 85 276 minecraft:cobbled_deepslate
setblock 493 85 316 minecraft:cobbled_deepslate
fill 494 85 276 494 88 276 minecraft:deepslate_tiles
setblock 494 85 278 minecraft:light[level=12]
setblock 494 85 285 minecraft:light[level=12]
setblock 494 85 292 minecraft:light[level=12]
setblock 494 85 299 minecraft:light[level=12]
setblock 494 85 306 minecraft:light[level=12]
setblock 494 85 313 minecraft:light[level=12]
fill 494 85 316 494 88 316 minecraft:deepslate_tiles
setblock 494 85 317 minecraft:redstone_block
setblock 496 85 277 minecraft:deepslate_tiles
fill 496 85 315 496 87 315 minecraft:deepslate_tiles
setblock 497 85 277 minecraft:cobbled_deepslate
setblock 497 85 278 minecraft:light[level=13]
setblock 497 85 286 minecraft:light[level=13]
setblock 497 85 294 minecraft:light[level=13]
setblock 497 85 302 minecraft:light[level=13]
setblock 497 85 310 minecraft:light[level=13]
setblock 498 85 276 minecraft:cobbled_deepslate
fill 498 85 277 498 88 277 minecraft:deepslate_tiles
fill 498 85 282 498 91 283 minecraft:black_concrete
setblock 498 85 316 minecraft:cobbled_deepslate
fill 499 85 276 499 88 276 minecraft:deepslate_tiles
fill 499 85 316 499 88 316 minecraft:deepslate_tiles
fill 500 85 282 500 91 283 minecraft:black_concrete
setblock 501 85 277 minecraft:deepslate_tiles
setblock 501 85 278 minecraft:light[level=12]
setblock 501 85 285 minecraft:light[level=12]
setblock 501 85 292 minecraft:light[level=12]
setblock 501 85 299 minecraft:light[level=12]
setblock 501 85 306 minecraft:light[level=12]
setblock 501 85 313 minecraft:light[level=12]
setblock 502 85 277 minecraft:cobbled_deepslate
setblock 503 85 276 minecraft:cobbled_deepslate
fill 503 85 277 503 88 277 minecraft:deepslate_tiles
setblock 503 85 316 minecraft:cobbled_deepslate
fill 504 85 276 504 88 276 minecraft:deepslate_tiles
setblock 505 85 278 minecraft:light[level=13]
setblock 505 85 286 minecraft:light[level=13]
setblock 505 85 294 minecraft:light[level=13]
setblock 505 85 302 minecraft:light[level=13]
setblock 505 85 310 minecraft:light[level=13]
setblock 508 85 276 minecraft:cobbled_deepslate
setblock 508 85 278 minecraft:light[level=12]
setblock 508 85 285 minecraft:light[level=12]
setblock 508 85 292 minecraft:light[level=12]
setblock 508 85 299 minecraft:light[level=12]
setblock 508 85 306 minecraft:light[level=12]
setblock 508 85 313 minecraft:light[level=12]
fill 509 85 276 509 88 276 minecraft:deepslate_tiles
fill 509 85 316 509 88 316 minecraft:deepslate_tiles
fill 510 85 277 510 86 277 minecraft:deepslate_tiles
setblock 511 85 278 minecraft:cobbled_deepslate
fill 511 85 279 511 88 279 minecraft:deepslate_tiles
fill 511 85 281 511 86 281 minecraft:deepslate_tiles
setblock 511 85 293 minecraft:cobbled_deepslate
fill 511 85 294 511 86 296 minecraft:deepslate_tiles
fill 511 85 314 511 88 314 minecraft:deepslate_tiles
setblock 471 86 276 minecraft:deepslate_tiles
setblock 471 86 277 minecraft:cobbled_deepslate
fill 471 86 278 471 89 278 minecraft:deepslate_tiles
fill 471 86 280 471 87 280 minecraft:deepslate_tiles
fill 471 86 295 471 86 296 minecraft:deepslate_tiles
setblock 471 86 297 minecraft:cobbled_deepslate
fill 471 86 298 471 88 299 minecraft:deepslate_tiles
setblock 471 86 312 minecraft:cobbled_deepslate
fill 471 86 313 471 89 313 minecraft:deepslate_tiles
setblock 472 86 276 minecraft:cobbled_deepslate
fill 472 86 277 472 89 277 minecraft:deepslate_tiles
fill 472 86 279 472 87 279 minecraft:deepslate_tiles
fill 472 86 312 472 89 312 minecraft:deepslate_tiles
setblock 472 86 315 minecraft:deepslate_tiles
setblock 472 86 316 minecraft:cobbled_deepslate
fill 473 86 276 473 89 276 minecraft:deepslate_tiles
setblock 473 86 299 minecraft:black_concrete
setblock 473 86 301 minecraft:black_concrete
setblock 473 86 314 minecraft:deepslate_tiles
setblock 473 86 315 minecraft:cobbled_deepslate
fill 473 86 316 476 86 316 minecraft:deepslate_tiles
setblock 474 86 314 minecraft:cobbled_deepslate
fill 474 86 315 474 89 315 minecraft:deepslate_tiles
setblock 475 86 299 minecraft:black_concrete
setblock 475 86 301 minecraft:black_concrete
fill 475 86 314 475 89 314 minecraft:deepslate_tiles
setblock 476 86 277 minecraft:cobbled_deepslate
setblock 477 86 276 minecraft:cobbled_deepslate
fill 477 86 277 477 89 277 minecraft:deepslate_tiles
setblock 477 86 316 minecraft:cobbled_deepslate
fill 478 86 276 478 89 276 minecraft:deepslate_tiles
setblock 478 86 315 minecraft:cobbled_deepslate
fill 478 86 316 478 89 316 minecraft:deepslate_tiles
setblock 479 86 314 minecraft:cobbled_deepslate
fill 479 86 315 479 89 315 minecraft:deepslate_tiles
fill 480 86 314 480 87 314 minecraft:deepslate_tiles
setblock 482 86 276 minecraft:cobbled_deepslate
setblock 482 86 316 minecraft:cobbled_deepslate
fill 483 86 276 483 89 276 minecraft:deepslate_tiles
setblock 483 86 315 minecraft:cobbled_deepslate
fill 483 86 316 483 89 316 minecraft:deepslate_tiles
fill 483 86 317 483 87 317 minecraft:redstone_block
fill 484 86 317 485 94 317 minecraft:cobbled_deepslate
fill 490 86 316 491 86 316 minecraft:deepslate_tiles
setblock 491 86 276 minecraft:deepslate_tiles
setblock 492 86 276 minecraft:cobbled_deepslate
setblock 492 86 316 minecraft:cobbled_deepslate
fill 493 86 276 493 89 276 minecraft:deepslate_tiles
fill 493 86 309 497 87 313 minecraft:black_concrete
fill 493 86 316 493 89 316 minecraft:deepslate_tiles
fill 494 86 277 495 86 277 minecraft:deepslate_tiles
fill 494 86 317 494 91 317 minecraft:cobbled_deepslate
setblock 495 86 275 minecraft:redstone_block
fill 495 86 314 495 86 315 minecraft:black_concrete
setblock 496 86 277 minecraft:cobbled_deepslate
setblock 497 86 276 minecraft:cobbled_deepslate
fill 497 86 277 497 89 277 minecraft:deepslate_tiles
setblock 497 86 316 minecraft:cobbled_deepslate
fill 498 86 276 498 89 276 minecraft:deepslate_tiles
fill 498 86 281 500 91 281 minecraft:black_concrete
fill 498 86 284 500 91 284 minecraft:black_concrete
setblock 498 86 315 minecraft:cobbled_deepslate
fill 498 86 316 498 89 316 minecraft:deepslate_tiles
setblock 501 86 277 minecraft:cobbled_deepslate
setblock 502 86 276 minecraft:cobbled_deepslate
fill 502 86 277 502 89 277 minecraft:deepslate_tiles
setblock 502 86 316 minecraft:cobbled_deepslate
fill 503 86 276 503 89 276 minecraft:deepslate_tiles
fill 503 86 316 503 89 316 minecraft:deepslate_tiles
fill 504 86 277 505 86 277 minecraft:deepslate_tiles
setblock 507 86 276 minecraft:cobbled_deepslate
fill 508 86 276 508 88 277 minecraft:deepslate_tiles
fill 508 86 316 508 89 316 minecraft:deepslate_tiles
fill 509 86 277 509 87 277 minecraft:deepslate_tiles
setblock 510 86 278 minecraft:cobbled_deepslate
fill 510 86 279 510 89 279 minecraft:deepslate_tiles
setblock 511 86 277 minecraft:cobbled_deepslate
fill 511 86 278 511 89 278 minecraft:deepslate_tiles
setblock 511 86 282 minecraft:cobbled_deepslate
fill 511 86 283 511 89 283 minecraft:deepslate_tiles
setblock 511 86 292 minecraft:cobbled_deepslate
fill 511 86 293 511 89 293 minecraft:deepslate_tiles
setblock 511 86 297 minecraft:cobbled_deepslate
fill 511 86 298 511 89 298 minecraft:deepslate_tiles
setblock 512 86 293 minecraft:redstone_block
setblock 471 87 276 minecraft:cobbled_deepslate
fill 471 87 277 471 90 277 minecraft:deepslate_tiles
setblock 471 87 281 minecraft:cobbled_deepslate
fill 471 87 282 471 90 282 minecraft:deepslate_tiles
fill 471 87 294 471 87 295 minecraft:deepslate_tiles
setblock 471 87 296 minecraft:cobbled_deepslate
fill 471 87 297 472 89 297 minecraft:deepslate_tiles
setblock 471 87 300 minecraft:deepslate_tiles
setblock 471 87 301 minecraft:cobbled_deepslate
fill 471 87 302 471 89 303 minecraft:deepslate_tiles
fill 471 87 309 471 87 310 minecraft:deepslate_tiles
setblock 471 87 311 minecraft:cobbled_deepslate
fill 471 87 312 471 90 312 minecraft:deepslate_tiles
fill 471 87 314 471 87 315 minecraft:deepslate_tiles
setblock 471 87 316 minecraft:cobbled_deepslate
fill 472 87 276 472 90 276 minecraft:deepslate_tiles
setblock 472 87 280 minecraft:cobbled_deepslate
fill 472 87 298 472 87 299 minecraft:deepslate_tiles
setblock 472 87 300 minecraft:cobbled_deepslate
fill 472 87 311 472 90 311 minecraft:deepslate_tiles
setblock 472 87 315 minecraft:cobbled_deepslate
fill 472 87 316 475 87 316 minecraft:deepslate_tiles
setblock 473 87 278 minecraft:deepslate_tiles
setblock 473 87 313 minecraft:deepslate_tiles
setblock 473 87 314 minecraft:cobbled_deepslate
fill 473 87 315 473 90 315 minecraft:deepslate_tiles
setblock 474 87 278 minecraft:cobbled_deepslate
fill 474 87 314 474 90 314 minecraft:deepslate_tiles
setblock 475 87 277 minecraft:cobbled_deepslate
fill 475 87 278 477 88 278 minecraft:deepslate_tiles
setblock 476 87 276 minecraft:cobbled_deepslate
fill 476 87 277 476 90 277 minecraft:deepslate_tiles
setblock 476 87 316 minecraft:cobbled_deepslate
fill 477 87 276 477 90 276 minecraft:deepslate_tiles
setblock 477 87 315 minecraft:cobbled_deepslate
fill 477 87 316 477 90 316 minecraft:deepslate_tiles
setblock 478 87 314 minecraft:cobbled_deepslate
fill 478 87 315 478 90 315 minecraft:deepslate_tiles
setblock 479 87 277 minecraft:deepslate_tiles
fill 479 87 314 479 88 314 minecraft:deepslate_tiles
setblock 480 87 277 minecraft:cobbled_deepslate
setblock 481 87 276 minecraft:cobbled_deepslate
setblock 481 87 316 minecraft:cobbled_deepslate
fill 482 87 276 482 90 276 minecraft:deepslate_tiles
setblock 482 87 315 minecraft:cobbled_deepslate
fill 482 87 316 482 90 316 minecraft:deepslate_tiles
setblock 486 87 316 minecraft:cobbled_deepslate
fill 489 87 316 490 87 316 minecraft:deepslate_tiles
setblock 490 87 276 minecraft:deepslate_tiles
setblock 491 87 276 minecraft:cobbled_deepslate
setblock 491 87 316 minecraft:cobbled_deepslate
fill 492 87 276 492 90 276 minecraft:deepslate_tiles
fill 492 87 316 492 90 316 minecraft:deepslate_tiles
fill 493 87 277 494 87 277 minecraft:deepslate_tiles
fill 495 87 275 495 91 275 minecraft:cobbled_deepslate
setblock 495 87 277 minecraft:cobbled_deepslate
fill 495 87 315 495 88 315 minecraft:deepslate_tiles
setblock 496 87 276 minecraft:cobbled_deepslate
fill 496 87 277 496 89 278 minecraft:deepslate_tiles
setblock 496 87 316 minecraft:cobbled_deepslate
fill 497 87 276 497 90 276 minecraft:deepslate_tiles
fill 497 87 278 498 87 278 minecraft:deepslate_tiles
fill 497 87 282 497 91 283 minecraft:black_concrete
fill 497 87 314 497 107 314 minecraft:white_wool
setblock 497 87 315 minecraft:cobbled_deepslate
fill 497 87 316 497 90 316 minecraft:deepslate_tiles
setblock 499 87 278 minecraft:cobbled_deepslate
setblock 500 87 277 minecraft:cobbled_deepslate
fill 500 87 278 500 90 278 minecraft:deepslate_tiles
setblock 501 87 276 minecraft:cobbled_deepslate
fill 501 87 277 501 90 277 minecraft:deepslate_tiles
fill 501 87 282 501 91 283 minecraft:black_concrete
setblock 501 87 316 minecraft:cobbled_deepslate
fill 502 87 276 502 90 276 minecraft:deepslate_tiles
fill 502 87 316 502 89 316 minecraft:deepslate_tiles
setblock 504 87 277 minecraft:deepslate_tiles
setblock 505 87 277 minecraft:cobbled_deepslate
setblock 506 87 276 minecraft:cobbled_deepslate
fill 506 87 277 507 89 277 minecraft:deepslate_tiles
fill 507 87 276 507 90 276 minecraft:deepslate_tiles
fill 507 87 316 507 90 316 minecraft:deepslate_tiles
setblock 510 87 277 minecraft:cobbled_deepslate
fill 510 87 278 510 90 278 minecraft:deepslate_tiles
fill 510 87 280 510 87 281 minecraft:deepslate_tiles
setblock 511 87 276 minecraft:cobbled_deepslate
fill 511 87 277 511 90 277 minecraft:deepslate_tiles
setblock 511 87 281 minecraft:cobbled_deepslate
fill 511 87 282 511 90 282 minecraft:deepslate_tiles
fill 511 87 284 511 88 284 minecraft:deepslate_tiles
fill 511 87 292 511 90 292 minecraft:deepslate_tiles
fill 511 87 294 511 87 295 minecraft:deepslate_tiles
setblock 511 87 296 minecraft:cobbled_deepslate
fill 511 87 297 511 90 297 minecraft:deepslate_tiles
fill 511 87 299 511 87 300 minecraft:deepslate_tiles
fill 511 87 313 511 89 313 minecraft:deepslate_tiles
setblock 511 87 316 minecraft:cobbled_deepslate
fill 512 87 293 512 90 293 minecraft:cobbled_deepslate
fill 471 88 276 471 91 276 minecraft:deepslate_tiles
setblock 471 88 280 minecraft:cobbled_deepslate
fill 471 88 281 472 90 281 minecraft:deepslate_tiles
fill 471 88 283 471 89 283 minecraft:deepslate_tiles
fill 471 88 293 471 88 294 minecraft:deepslate_tiles
setblock 471 88 295 minecraft:cobbled_deepslate
fill 471 88 296 472 90 296 minecraft:deepslate_tiles
setblock 471 88 300 minecraft:cobbled_deepslate
fill 471 88 301 473 89 301 minecraft:deepslate_tiles
setblock 471 88 304 minecraft:deepslate_tiles
setblock 471 88 305 minecraft:cobbled_deepslate
fill 471 88 306 471 88 309 minecraft:deepslate_tiles
setblock 471 88 310 minecraft:cobbled_deepslate
fill 471 88 311 471 91 311 minecraft:deepslate_tiles
setblock 471 88 314 minecraft:deepslate_tiles
setblock 471 88 315 minecraft:cobbled_deepslate
fill 471 88 316 474 88 316 minecraft:deepslate_tiles
setblock 472 88 279 minecraft:cobbled_deepslate
fill 472 88 280 472 91 280 minecraft:deepslate_tiles
fill 472 88 295 472 91 295 minecraft:deepslate_tiles
setblock 472 88 298 minecraft:deepslate_tiles
setblock 472 88 299 minecraft:cobbled_deepslate
fill 472 88 300 473 90 300 minecraft:deepslate_tiles
fill 472 88 302 472 88 303 minecraft:deepslate_tiles
setblock 472 88 304 minecraft:cobbled_deepslate
fill 472 88 310 472 91 310 minecraft:deepslate_tiles
setblock 472 88 314 minecraft:cobbled_deepslate
fill 472 88 315 472 91 315 minecraft:deepslate_tiles
setblock 473 88 278 minecraft:cobbled_deepslate
fill 473 88 279 473 91 279 minecraft:deepslate_tiles
setblock 473 88 298 minecraft:cobbled_deepslate
fill 473 88 299 473 91 299 minecraft:deepslate_tiles
setblock 473 88 312 minecraft:deepslate_tiles
setblock 473 88 313 minecraft:cobbled_deepslate
fill 473 88 314 473 91 314 minecraft:deepslate_tiles
setblock 474 88 277 minecraft:cobbled_deepslate
fill 474 88 278 474 91 278 minecraft:deepslate_tiles
setblock 475 88 276 minecraft:cobbled_deepslate
fill 475 88 277 475 91 277 minecraft:deepslate_tiles
setblock 475 88 316 minecraft:cobbled_deepslate
fill 476 88 276 476 91 276 minecraft:deepslate_tiles
setblock 476 88 315 minecraft:cobbled_deepslate
fill 476 88 316 476 91 316 minecraft:deepslate_tiles
setblock 477 88 314 minecraft:cobbled_deepslate
fill 477 88 315 477 91 315 minecraft:deepslate_tiles
fill 478 88 314 478 89 314 minecraft:deepslate_tiles
setblock 479 88 277 minecraft:cobbled_deepslate
setblock 480 88 276 minecraft:cobbled_deepslate
fill 480 88 277 480 90 277 minecraft:deepslate_tiles
setblock 480 88 316 minecraft:cobbled_deepslate
fill 481 88 276 481 91 276 minecraft:deepslate_tiles
setblock 481 88 315 minecraft:cobbled_deepslate
fill 481 88 316 481 91 316 minecraft:deepslate_tiles
setblock 482 88 315 minecraft:deepslate_tiles
fill 483 88 317 483 95 317 minecraft:cobbled_deepslate
setblock 485 88 316 minecraft:cobbled_deepslate
setblock 486 88 316 minecraft:deepslate_tiles
fill 488 88 316 489 88 316 minecraft:deepslate_tiles
setblock 489 88 276 minecraft:deepslate_tiles
setblock 490 88 276 minecraft:cobbled_deepslate
setblock 490 88 316 minecraft:cobbled_deepslate
fill 491 88 276 491 90 277 minecraft:deepslate_tiles
fill 491 88 316 491 91 316 minecraft:deepslate_tiles
fill 492 88 277 493 88 277 minecraft:deepslate_tiles
setblock 494 88 277 minecraft:cobbled_deepslate
fill 494 88 278 495 90 278 minecraft:deepslate_tiles
fill 494 88 315 494 89 315 minecraft:deepslate_tiles
setblock 495 88 276 minecraft:cobbled_deepslate
fill 495 88 277 495 91 277 minecraft:deepslate_tiles
fill 495 88 311 495 93 311 minecraft:bone_block
setblock 495 88 316 minecraft:cobbled_deepslate
fill 496 88 276 496 91 276 minecraft:deepslate_tiles
setblock 496 88 315 minecraft:cobbled_deepslate
fill 496 88 316 496 91 316 minecraft:deepslate_tiles
setblock 497 88 278 minecraft:deepslate_tiles
fill 497 88 281 497 91 281 minecraft:black_concrete
fill 497 88 284 497 91 284 minecraft:black_concrete
setblock 497 88 315 minecraft:deepslate_tiles
setblock 498 88 275 minecraft:redstone_block
setblock 498 88 278 minecraft:cobbled_deepslate
fill 498 88 280 500 91 280 minecraft:black_concrete
fill 498 88 285 500 91 285 minecraft:black_concrete
setblock 499 88 277 minecraft:cobbled_deepslate
fill 499 88 278 499 91 278 minecraft:deepslate_tiles
setblock 500 88 276 minecraft:cobbled_deepslate
fill 500 88 277 500 91 277 minecraft:deepslate_tiles
setblock 500 88 316 minecraft:cobbled_deepslate
fill 501 88 276 501 91 276 minecraft:deepslate_tiles
fill 501 88 278 501 89 278 minecraft:deepslate_tiles
fill 501 88 281 501 91 281 minecraft:black_concrete
fill 501 88 284 501 91 284 minecraft:black_concrete
fill 501 88 316 501 90 316 minecraft:deepslate_tiles
setblock 504 88 277 minecraft:cobbled_deepslate
setblock 505 88 276 minecraft:cobbled_deepslate
fill 505 88 277 505 91 277 minecraft:deepslate_tiles
fill 506 88 276 506 91 276 minecraft:deepslate_tiles
fill 506 88 316 506 91 316 minecraft:deepslate_tiles
setblock 509 88 277 minecraft:cobbled_deepslate
fill 509 88 278 509 90 279 minecraft:deepslate_tiles
setblock 510 88 276 minecraft:cobbled_deepslate
fill 510 88 277 510 91 277 minecraft:deepslate_tiles
setblock 510 88 280 minecraft:deepslate_tiles
setblock 510 88 281 minecraft:cobbled_deepslate
fill 510 88 282 510 91 282 minecraft:deepslate_tiles
setblock 510 88 316 minecraft:cobbled_deepslate
fill 511 88 276 511 91 276 minecraft:deepslate_tiles
setblock 511 88 280 minecraft:cobbled_deepslate
fill 511 88 281 511 91 281 minecraft:deepslate_tiles
setblock 511 88 285 minecraft:cobbled_deepslate
fill 511 88 286 511 91 286 minecraft:deepslate_tiles
fill 511 88 291 511 91 291 minecraft:deepslate_tiles
setblock 511 88 294 minecraft:deepslate_tiles
setblock 511 88 295 minecraft:cobbled_deepslate
fill 511 88 296 511 91 296 minecraft:deepslate_tiles
setblock 511 88 299 minecraft:deepslate_tiles
setblock 511 88 300 minecraft:cobbled_deepslate
fill 511 88 301 511 90 302 minecraft:deepslate_tiles
fill 511 88 312 511 90 312 minecraft:deepslate_tiles
setblock 511 88 315 minecraft:cobbled_deepslate
fill 511 88 316 511 91 316 minecraft:deepslate_tiles
setblock 471 89 279 minecraft:cobbled_deepslate
fill 471 89 280 471 92 280 minecraft:deepslate_tiles
setblock 471 89 284 minecraft:cobbled_deepslate
setblock 471 89 293 minecraft:deepslate_tiles
setblock 471 89 294 minecraft:cobbled_deepslate
fill 471 89 295 471 92 295 minecraft:deepslate_tiles
setblock 471 89 298 minecraft:deepslate_tiles
setblock 471 89 299 minecraft:cobbled_deepslate
fill 471 89 300 471 92 300 minecraft:deepslate_tiles
setblock 471 89 304 minecraft:cobbled_deepslate
fill 471 89 305 471 89 308 minecraft:deepslate_tiles
setblock 471 89 309 minecraft:cobbled_deepslate
fill 471 89 310 471 92 310 minecraft:deepslate_tiles
setblock 471 89 314 minecraft:cobbled_deepslate
fill 471 89 315 471 91 316 minecraft:deepslate_tiles
setblock 472 89 278 minecraft:cobbled_deepslate
fill 472 89 279 472 92 279 minecraft:deepslate_tiles
setblock 472 89 282 minecraft:deepslate_tiles
setblock 472 89 298 minecraft:cobbled_deepslate
fill 472 89 299 472 92 299 minecraft:deepslate_tiles
setblock 472 89 302 minecraft:deepslate_tiles
setblock 472 89 303 minecraft:cobbled_deepslate
fill 472 89 304 472 89 307 minecraft:deepslate_tiles
setblock 472 89 308 minecraft:cobbled_deepslate
fill 472 89 309 472 92 309 minecraft:deepslate_tiles
setblock 472 89 313 minecraft:cobbled_deepslate
fill 472 89 314 472 92 314 minecraft:deepslate_tiles
fill 472 89 316 473 89 316 minecraft:deepslate_tiles
setblock 473 89 277 minecraft:cobbled_deepslate
fill 473 89 278 473 92 278 minecraft:deepslate_tiles
fill 473 89 280 473 90 280 minecraft:deepslate_tiles
setblock 473 89 297 minecraft:cobbled_deepslate
fill 473 89 298 473 92 298 minecraft:deepslate_tiles
setblock 473 89 302 minecraft:cobbled_deepslate
fill 473 89 303 473 91 304 minecraft:deepslate_tiles
setblock 473 89 312 minecraft:cobbled_deepslate
fill 473 89 313 473 92 313 minecraft:deepslate_tiles
setblock 474 89 276 minecraft:cobbled_deepslate
fill 474 89 277 474 92 277 minecraft:deepslate_tiles
setblock 474 89 316 minecraft:cobbled_deepslate
fill 475 89 276 475 92 276 minecraft:deepslate_tiles
fill 475 89 278 476 89 278 minecraft:deepslate_tiles
setblock 475 89 315 minecraft:cobbled_deepslate
fill 475 89 316 475 92 316 minecraft:deepslate_tiles
setblock 476 89 314 minecraft:cobbled_deepslate
fill 476 89 315 476 92 315 minecraft:deepslate_tiles
setblock 477 89 278 minecraft:cobbled_deepslate
fill 477 89 314 477 90 314 minecraft:deepslate_tiles
setblock 478 89 277 minecraft:cobbled_deepslate
setblock 478 89 278 minecraft:deepslate_tiles
setblock 479 89 276 minecraft:cobbled_deepslate
fill 479 89 277 479 91 277 minecraft:deepslate_tiles
setblock 479 89 316 minecraft:cobbled_deepslate
fill 480 89 276 480 92 276 minecraft:deepslate_tiles
setblock 480 89 315 minecraft:cobbled_deepslate
fill 480 89 316 480 92 316 minecraft:deepslate_tiles
setblock 481 89 315 minecraft:deepslate_tiles
setblock 484 89 276 minecraft:cobbled_deepslate
setblock 484 89 316 minecraft:cobbled_deepslate
setblock 485 89 316 minecraft:deepslate_tiles
setblock 486 89 275 minecraft:redstone_block
fill 487 89 275 488 94 275 minecraft:cobbled_deepslate
fill 487 89 276 488 89 276 minecraft:deepslate_tiles
setblock 488 89 316 minecraft:deepslate_tiles
setblock 489 89 276 minecraft:cobbled_deepslate
setblock 489 89 316 minecraft:cobbled_deepslate
fill 490 89 276 490 91 277 minecraft:deepslate_tiles
fill 490 89 316 490 92 316 minecraft:deepslate_tiles
setblock 492 89 277 minecraft:deepslate_tiles
setblock 493 89 277 minecraft:cobbled_deepslate
fill 493 89 278 493 92 278 minecraft:deepslate_tiles
fill 493 89 310 494 92 312 minecraft:bone_block
setblock 494 89 276 minecraft:cobbled_deepslate
fill 494 89 277 494 92 277 minecraft:deepslate_tiles
fill 494 89 309 496 92 309 minecraft:bone_block
fill 494 89 313 496 92 313 minecraft:bone_block
setblock 494 89 316 minecraft:cobbled_deepslate
fill 495 89 276 495 92 276 minecraft:deepslate_tiles
fill 495 89 310 497 92 310 minecraft:bone_block
fill 495 89 312 497 92 312 minecraft:bone_block
setblock 495 89 315 minecraft:cobbled_deepslate
fill 495 89 316 495 92 316 minecraft:deepslate_tiles
fill 496 89 282 496 91 283 minecraft:black_concrete
fill 496 89 311 497 92 311 minecraft:bone_block
setblock 496 89 315 minecraft:deepslate_tiles
setblock 497 89 278 minecraft:cobbled_deepslate
fill 497 89 279 497 92 279 minecraft:deepslate_tiles
fill 497 89 280 497 91 280 minecraft:black_concrete
fill 497 89 285 497 91 285 minecraft:black_concrete
fill 498 89 275 498 94 275 minecraft:cobbled_deepslate
setblock 498 89 277 minecraft:cobbled_deepslate
fill 498 89 278 498 92 278 minecraft:deepslate_tiles
setblock 499 89 276 minecraft:cobbled_deepslate
fill 499 89 277 499 92 277 minecraft:deepslate_tiles
setblock 499 89 316 minecraft:cobbled_deepslate
fill 500 89 276 500 92 276 minecraft:deepslate_tiles
fill 500 89 316 500 91 316 minecraft:deepslate_tiles
fill 501 89 280 501 91 280 minecraft:black_concrete
fill 501 89 285 501 91 285 minecraft:black_concrete
setblock 502 89 278 minecraft:cobbled_deepslate
fill 502 89 281 502 91 284 minecraft:black_concrete
setblock 503 89 277 minecraft:cobbled_deepslate
fill 503 89 278 503 92 278 minecraft:deepslate_tiles
setblock 504 89 276 minecraft:cobbled_deepslate
fill 504 89 277 504 92 277 minecraft:deepslate_tiles
fill 505 89 276 505 92 276 minecraft:deepslate_tiles
setblock 505 89 316 minecraft:deepslate_tiles
setblock 507 89 278 minecraft:cobbled_deepslate
setblock 508 89 276 minecraft:deepslate_tiles
setblock 508 89 277 minecraft:cobbled_deepslate
fill 508 89 278 508 92 278 minecraft:deepslate_tiles
setblock 509 89 276 minecraft:cobbled_deepslate
fill 509 89 277 509 92 277 minecraft:deepslate_tiles
setblock 509 89 280 minecraft:deepslate_tiles
setblock 509 89 316 minecraft:cobbled_deepslate
fill 510 89 276 510 92 276 minecraft:deepslate_tiles
setblock 510 89 280 minecraft:cobbled_deepslate
fill 510 89 281 510 92 281 minecraft:deepslate_tiles
fill 510 89 283 510 90 283 minecraft:deepslate_tiles
setblock 510 89 315 minecraft:cobbled_deepslate
fill 510 89 316 510 92 316 minecraft:deepslate_tiles
setblock 511 89 279 minecraft:cobbled_deepslate
fill 511 89 280 511 92 280 minecraft:deepslate_tiles
setblock 511 89 284 minecraft:cobbled_deepslate
fill 511 89 285 511 92 285 minecraft:deepslate_tiles
fill 511 89 287 511 89 288 minecraft:deepslate_tiles
setblock 511 89 289 minecraft:cobbled_deepslate
fill 511 89 290 511 92 290 minecraft:deepslate_tiles
setblock 511 89 294 minecraft:cobbled_deepslate
fill 511 89 295 511 92 295 minecraft:deepslate_tiles
setblock 511 89 299 minecraft:cobbled_deepslate
fill 511 89 300 511 92 300 minecraft:deepslate_tiles
setblock 511 89 303 minecraft:deepslate_tiles
setblock 511 89 304 minecraft:cobbled_deepslate
fill 511 89 311 511 91 311 minecraft:deepslate_tiles
setblock 511 89 314 minecraft:cobbled_deepslate
fill 511 89 315 511 92 315 minecraft:deepslate_tiles
setblock 471 90 278 minecraft:cobbled_deepslate
fill 471 90 279 471 93 279 minecraft:deepslate_tiles
setblock 471 90 283 minecraft:cobbled_deepslate
fill 471 90 284 471 92 285 minecraft:deepslate_tiles
setblock 471 90 292 minecraft:deepslate_tiles
setblock 471 90 293 minecraft:cobbled_deepslate
fill 471 90 294 472 90 294 minecraft:deepslate_tiles
setblock 471 90 297 minecraft:deepslate_tiles
setblock 471 90 298 minecraft:cobbled_deepslate
fill 471 90 299 471 93 299 minecraft:deepslate_tiles
fill 471 90 301 471 90 302 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_4 1t
