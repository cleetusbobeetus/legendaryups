setblock 313 237 360 minecraft:light[level=12]
setblock 320 237 325 minecraft:light[level=12]
setblock 320 237 332 minecraft:light[level=12]
setblock 320 237 339 minecraft:light[level=12]
setblock 320 237 346 minecraft:light[level=12]
setblock 320 237 353 minecraft:light[level=12]
setblock 320 237 360 minecraft:light[level=12]
setblock 285 239 325 minecraft:light[level=15]
setblock 285 239 333 minecraft:light[level=15]
setblock 285 239 341 minecraft:light[level=15]
setblock 285 239 349 minecraft:light[level=15]
setblock 285 239 357 minecraft:light[level=15]
setblock 293 239 333 minecraft:light[level=15]
fill 293 239 338 293 239 340 minecraft:iron_bars
setblock 293 239 349 minecraft:light[level=15]
setblock 293 239 357 minecraft:light[level=15]
setblock 301 239 325 minecraft:light[level=15]
setblock 301 239 333 minecraft:light[level=15]
setblock 301 239 341 minecraft:light[level=15]
setblock 301 239 349 minecraft:light[level=15]
setblock 301 239 357 minecraft:light[level=15]
setblock 309 239 325 minecraft:light[level=15]
setblock 309 239 333 minecraft:light[level=15]
fill 309 239 338 309 239 340 minecraft:iron_bars
setblock 309 239 349 minecraft:light[level=15]
setblock 309 239 357 minecraft:light[level=15]
setblock 317 239 325 minecraft:light[level=15]
setblock 317 239 333 minecraft:light[level=15]
setblock 317 239 341 minecraft:light[level=15]
setblock 317 239 349 minecraft:light[level=15]
setblock 317 239 357 minecraft:light[level=15]
fill 284 240 332 284 245 334 minecraft:polished_andesite
fill 284 240 344 284 245 346 minecraft:polished_andesite
fill 284 240 356 284 245 358 minecraft:polished_andesite
fill 290 240 362 292 245 362 minecraft:polished_andesite
fill 293 240 336 293 240 337 minecraft:iron_bars
fill 302 240 362 304 245 362 minecraft:polished_andesite
fill 306 240 324 308 244 324 minecraft:polished_andesite
fill 309 240 336 309 240 337 minecraft:iron_bars
fill 314 240 362 316 245 362 minecraft:polished_andesite
fill 318 240 324 320 245 324 minecraft:polished_andesite
fill 322 240 332 322 245 334 minecraft:polished_andesite
fill 322 240 344 322 245 346 minecraft:polished_andesite
fill 322 240 356 322 245 358 minecraft:polished_andesite
fill 293 241 334 293 241 335 minecraft:iron_bars
fill 309 241 334 309 241 335 minecraft:iron_bars
setblock 285 243 325 minecraft:light[level=12]
setblock 285 243 332 minecraft:light[level=12]
setblock 285 243 339 minecraft:light[level=12]
setblock 285 243 346 minecraft:light[level=12]
setblock 285 243 353 minecraft:light[level=12]
setblock 285 243 360 minecraft:light[level=12]
fill 288 243 323 293 244 331 minecraft:polished_andesite
setblock 292 243 332 minecraft:light[level=12]
setblock 292 243 339 minecraft:light[level=12]
setblock 292 243 346 minecraft:light[level=12]
setblock 292 243 353 minecraft:light[level=12]
setblock 292 243 360 minecraft:light[level=12]
fill 293 243 341 294 243 341 minecraft:stone_bricks
fill 293 243 343 293 243 344 minecraft:stone_bricks
fill 294 243 323 300 243 328 minecraft:polished_andesite
setblock 294 243 329 minecraft:iron_bars
fill 294 243 330 300 257 331 minecraft:polished_andesite
fill 294 243 342 294 243 343 minecraft:stone_bricks
fill 295 243 329 300 257 329 minecraft:polished_andesite
fill 298 243 336 299 243 336 minecraft:stone_bricks
setblock 298 243 349 minecraft:stone_bricks
setblock 299 243 332 minecraft:light[level=12]
setblock 299 243 335 minecraft:stone_bricks
setblock 299 243 339 minecraft:light[level=12]
setblock 299 243 346 minecraft:light[level=12]
setblock 299 243 353 minecraft:light[level=12]
setblock 299 243 360 minecraft:light[level=12]
fill 300 243 350 301 243 351 minecraft:stone_bricks
fill 302 243 335 303 243 336 minecraft:stone_bricks
setblock 306 243 325 minecraft:light[level=12]
setblock 306 243 332 minecraft:light[level=12]
setblock 306 243 346 minecraft:light[level=12]
setblock 306 243 353 minecraft:light[level=12]
setblock 306 243 360 minecraft:light[level=12]
setblock 308 243 329 minecraft:iron_bars
setblock 308 243 341 minecraft:stone_bricks
fill 308 243 343 309 243 344 minecraft:stone_bricks
setblock 309 243 345 minecraft:stone_bricks
setblock 313 243 325 minecraft:light[level=12]
setblock 313 243 332 minecraft:light[level=12]
setblock 313 243 339 minecraft:light[level=12]
setblock 313 243 346 minecraft:light[level=12]
setblock 313 243 353 minecraft:light[level=12]
setblock 313 243 360 minecraft:light[level=12]
setblock 320 243 325 minecraft:light[level=12]
setblock 320 243 332 minecraft:light[level=12]
setblock 320 243 339 minecraft:light[level=12]
setblock 320 243 346 minecraft:light[level=12]
setblock 320 243 353 minecraft:light[level=12]
setblock 320 243 360 minecraft:light[level=12]
fill 285 244 358 285 244 360 minecraft:cobblestone
setblock 286 244 357 minecraft:cobblestone
fill 286 244 361 288 244 361 minecraft:cobblestone
setblock 288 244 357 minecraft:cobblestone
fill 289 244 358 289 244 360 minecraft:cobblestone
fill 294 244 323 300 244 325 minecraft:polished_andesite
fill 294 244 326 294 244 327 minecraft:iron_bars
fill 294 244 328 294 257 329 minecraft:polished_andesite
fill 295 244 326 300 257 328 minecraft:polished_andesite
fill 308 244 326 308 244 327 minecraft:iron_bars
setblock 316 244 327 minecraft:cobblestone
fill 316 244 358 316 244 360 minecraft:cobblestone
setblock 317 244 326 minecraft:cobblestone
setblock 317 244 329 minecraft:cobblestone
fill 317 244 357 320 244 357 minecraft:cobblestone
fill 317 244 361 319 244 361 minecraft:cobblestone
fill 318 244 325 319 244 325 minecraft:cobblestone
setblock 320 244 326 minecraft:cobblestone
setblock 320 244 329 minecraft:cobblestone
setblock 320 244 358 minecraft:cobblestone
setblock 320 244 360 minecraft:cobblestone
fill 321 244 327 321 244 328 minecraft:cobblestone
fill 283 245 326 283 245 331 minecraft:cobblestone
fill 283 245 338 283 245 343 minecraft:cobblestone
fill 283 245 350 283 245 355 minecraft:cobblestone
fill 283 245 362 283 245 363 minecraft:cobblestone
fill 284 245 363 287 245 363 minecraft:cobblestone
fill 287 245 323 292 245 323 minecraft:cobblestone
fill 288 245 324 293 257 331 minecraft:polished_andesite
fill 293 245 323 298 257 323 minecraft:polished_andesite
fill 294 245 324 294 245 325 minecraft:iron_bars
fill 294 245 326 294 257 327 minecraft:polished_andesite
fill 294 245 363 299 245 363 minecraft:cobblestone
fill 295 245 324 300 257 325 minecraft:polished_andesite
fill 299 245 323 304 245 323 minecraft:cobblestone
fill 306 245 324 307 245 324 minecraft:polished_andesite
fill 306 245 363 311 245 363 minecraft:cobblestone
fill 308 245 324 308 245 325 minecraft:iron_bars
fill 311 245 323 316 245 323 minecraft:cobblestone
fill 318 245 363 323 245 363 minecraft:cobblestone
fill 320 245 331 322 246 331 minecraft:iron_bars
fill 323 245 323 323 245 328 minecraft:cobblestone
fill 323 245 335 323 245 340 minecraft:cobblestone
fill 323 245 347 323 245 352 minecraft:cobblestone
fill 323 245 359 323 245 362 minecraft:cobblestone
fill 282 246 328 282 251 331 minecraft:shroomlight
fill 282 246 340 282 251 343 minecraft:shroomlight
fill 282 246 352 282 251 355 minecraft:shroomlight
fill 282 246 364 285 251 364 minecraft:shroomlight
fill 288 246 323 292 257 323 minecraft:polished_andesite
fill 289 246 322 292 251 322 minecraft:shroomlight
fill 293 246 337 297 246 338 minecraft:dark_oak_planks
fill 293 246 348 297 246 349 minecraft:dark_oak_planks
fill 294 246 324 294 257 325 minecraft:polished_andesite
fill 294 246 336 297 246 336 minecraft:dark_oak_planks
fill 294 246 339 297 246 339 minecraft:dark_oak_planks
fill 294 246 347 297 246 347 minecraft:dark_oak_planks
fill 294 246 350 297 246 350 minecraft:dark_oak_planks
fill 294 246 364 297 251 364 minecraft:shroomlight
fill 295 246 335 296 246 335 minecraft:dark_oak_planks
fill 295 246 351 296 246 351 minecraft:dark_oak_planks
fill 299 246 323 300 257 323 minecraft:polished_andesite
fill 301 246 322 304 251 322 minecraft:shroomlight
fill 305 246 336 308 246 339 minecraft:dark_oak_planks
fill 305 246 347 308 246 350 minecraft:dark_oak_planks
fill 306 246 335 307 246 335 minecraft:dark_oak_planks
fill 306 246 351 307 246 351 minecraft:dark_oak_planks
fill 306 246 364 309 251 364 minecraft:shroomlight
fill 309 246 337 309 246 338 minecraft:dark_oak_planks
fill 309 246 348 309 246 349 minecraft:dark_oak_planks
fill 313 246 322 316 251 322 minecraft:shroomlight
fill 318 246 364 321 251 364 minecraft:shroomlight
fill 324 246 323 324 251 326 minecraft:shroomlight
fill 324 246 335 324 251 338 minecraft:shroomlight
fill 324 246 347 324 251 350 minecraft:shroomlight
fill 324 246 359 324 251 362 minecraft:shroomlight
setblock 285 247 325 minecraft:light[level=15]
setblock 285 247 333 minecraft:light[level=15]
setblock 285 247 341 minecraft:light[level=15]
setblock 285 247 349 minecraft:light[level=15]
setblock 285 247 357 minecraft:light[level=15]
setblock 293 247 333 minecraft:light[level=15]
setblock 293 247 341 minecraft:light[level=15]
setblock 293 247 349 minecraft:light[level=15]
setblock 293 247 357 minecraft:light[level=15]
fill 294 247 336 296 247 338 minecraft:dark_oak_planks
fill 294 247 348 296 247 350 minecraft:dark_oak_planks
fill 295 247 339 296 247 339 minecraft:dark_oak_planks
fill 295 247 347 296 247 347 minecraft:dark_oak_planks
fill 297 247 337 297 247 338 minecraft:dark_oak_planks
fill 297 247 348 297 247 349 minecraft:dark_oak_planks
setblock 301 247 325 minecraft:light[level=15]
setblock 301 247 333 minecraft:light[level=15]
setblock 301 247 341 minecraft:light[level=15]
setblock 301 247 349 minecraft:light[level=15]
setblock 301 247 357 minecraft:light[level=15]
fill 305 247 337 308 247 338 minecraft:dark_oak_planks
fill 305 247 348 308 247 349 minecraft:dark_oak_planks
fill 306 247 336 308 247 336 minecraft:dark_oak_planks
fill 306 247 339 307 247 339 minecraft:dark_oak_planks
fill 306 247 347 307 247 347 minecraft:dark_oak_planks
fill 306 247 350 308 247 350 minecraft:dark_oak_planks
setblock 309 247 325 minecraft:light[level=15]
setblock 309 247 333 minecraft:light[level=15]
setblock 309 247 341 minecraft:light[level=15]
setblock 309 247 349 minecraft:light[level=15]
setblock 309 247 357 minecraft:light[level=15]
setblock 317 247 325 minecraft:light[level=15]
setblock 317 247 333 minecraft:light[level=15]
setblock 317 247 341 minecraft:light[level=15]
setblock 317 247 349 minecraft:light[level=15]
setblock 317 247 357 minecraft:light[level=15]
fill 294 248 337 296 248 338 minecraft:dark_oak_planks
fill 294 248 348 296 248 349 minecraft:dark_oak_planks
fill 295 248 336 296 248 336 minecraft:dark_oak_planks
fill 295 248 350 296 248 350 minecraft:dark_oak_planks
fill 306 248 336 307 248 338 minecraft:dark_oak_planks
fill 306 248 348 307 248 350 minecraft:dark_oak_planks
fill 308 248 337 308 248 338 minecraft:dark_oak_planks
fill 308 248 348 308 248 349 minecraft:dark_oak_planks
fill 309 248 324 315 249 324 minecraft:iron_bars
fill 282 249 344 282 252 346 minecraft:mossy_stone_bricks
setblock 282 249 347 minecraft:stone_bricks
fill 282 249 348 282 252 351 minecraft:mossy_stone_bricks
fill 284 249 333 284 257 333 minecraft:red_wool
setblock 285 249 325 minecraft:light[level=12]
setblock 285 249 332 minecraft:light[level=12]
setblock 285 249 339 minecraft:light[level=12]
setblock 285 249 346 minecraft:light[level=12]
setblock 285 249 353 minecraft:light[level=12]
setblock 285 249 360 minecraft:light[level=12]
setblock 288 249 364 minecraft:stone_bricks
fill 289 249 364 289 252 364 minecraft:mossy_stone_bricks
fill 290 249 364 291 249 364 minecraft:stone_bricks
setblock 292 249 332 minecraft:light[level=12]
setblock 292 249 339 minecraft:light[level=12]
setblock 292 249 346 minecraft:light[level=12]
setblock 292 249 353 minecraft:light[level=12]
setblock 292 249 360 minecraft:light[level=12]
fill 292 249 364 293 249 364 minecraft:mossy_stone_bricks
fill 295 249 337 296 249 338 minecraft:dark_oak_planks
fill 295 249 348 296 249 349 minecraft:dark_oak_planks
setblock 299 249 332 minecraft:light[level=12]
setblock 299 249 339 minecraft:light[level=12]
setblock 299 249 346 minecraft:light[level=12]
setblock 299 249 353 minecraft:light[level=12]
setblock 299 249 360 minecraft:light[level=12]
fill 299 249 364 302 252 364 minecraft:mossy_stone_bricks
fill 303 249 364 304 249 364 minecraft:stone_bricks
setblock 305 249 322 minecraft:stone_bricks
fill 306 249 322 307 250 322 minecraft:mossy_stone_bricks
setblock 306 249 325 minecraft:light[level=12]
setblock 306 249 332 minecraft:light[level=12]
fill 306 249 337 307 249 338 minecraft:dark_oak_planks
setblock 306 249 339 minecraft:light[level=12]
setblock 306 249 346 minecraft:light[level=12]
fill 306 249 348 307 249 349 minecraft:dark_oak_planks
setblock 306 249 353 minecraft:light[level=12]
setblock 306 249 360 minecraft:light[level=12]
fill 310 249 364 310 252 364 minecraft:mossy_stone_bricks
setblock 311 249 364 minecraft:stone_bricks
setblock 312 249 322 minecraft:stone_bricks
fill 312 249 364 314 252 364 minecraft:mossy_stone_bricks
setblock 313 249 325 minecraft:light[level=12]
setblock 313 249 332 minecraft:light[level=12]
setblock 313 249 339 minecraft:light[level=12]
setblock 313 249 346 minecraft:light[level=12]
setblock 313 249 353 minecraft:light[level=12]
setblock 313 249 360 minecraft:light[level=12]
setblock 315 249 364 minecraft:stone_bricks
setblock 320 249 325 minecraft:light[level=12]
setblock 320 249 332 minecraft:light[level=12]
setblock 320 249 339 minecraft:light[level=12]
setblock 320 249 346 minecraft:light[level=12]
setblock 320 249 353 minecraft:light[level=12]
setblock 320 249 360 minecraft:light[level=12]
fill 322 249 364 323 249 364 minecraft:mossy_stone_bricks
fill 324 249 329 324 250 329 minecraft:stone_bricks
fill 324 249 330 324 252 330 minecraft:mossy_stone_bricks
setblock 324 249 331 minecraft:stone_bricks
fill 324 249 332 324 249 334 minecraft:mossy_stone_bricks
fill 324 249 339 324 250 340 minecraft:mossy_stone_bricks
setblock 324 249 341 minecraft:stone_bricks
setblock 324 249 346 minecraft:stone_bricks
setblock 324 249 351 minecraft:stone_bricks
setblock 324 249 364 minecraft:stone_bricks
setblock 282 250 332 minecraft:stone_bricks
fill 282 250 347 282 252 347 minecraft:mossy_stone_bricks
fill 282 250 356 282 252 357 minecraft:mossy_stone_bricks
setblock 282 250 358 minecraft:stone_bricks
fill 282 250 359 282 252 360 minecraft:mossy_stone_bricks
fill 284 250 331 284 257 332 minecraft:red_wool
fill 284 250 334 284 257 335 minecraft:red_wool
setblock 288 250 364 minecraft:mossy_stone_bricks
fill 290 250 364 291 252 364 minecraft:mossy_stone_bricks
setblock 292 250 364 minecraft:stone_bricks
setblock 293 250 364 minecraft:mossy_stone_bricks
setblock 295 250 337 minecraft:dark_oak_planks
setblock 295 250 349 minecraft:dark_oak_planks
fill 303 250 364 304 250 364 minecraft:mossy_stone_bricks
fill 305 250 322 305 252 322 minecraft:mossy_stone_bricks
setblock 307 250 337 minecraft:dark_oak_planks
setblock 307 250 349 minecraft:dark_oak_planks
fill 311 250 364 311 252 364 minecraft:mossy_stone_bricks
setblock 312 250 322 minecraft:mossy_stone_bricks
fill 315 250 364 315 252 364 minecraft:mossy_stone_bricks
setblock 317 250 364 minecraft:stone_bricks
setblock 322 250 364 minecraft:stone_bricks
fill 323 250 364 324 252 364 minecraft:mossy_stone_bricks
setblock 324 250 327 minecraft:stone_bricks
setblock 324 250 331 minecraft:mossy_stone_bricks
setblock 324 250 332 minecraft:stone_bricks
fill 324 250 333 324 252 334 minecraft:mossy_stone_bricks
fill 324 250 341 324 252 341 minecraft:mossy_stone_bricks
fill 324 250 346 324 252 346 minecraft:mossy_stone_bricks
fill 324 250 351 324 252 351 minecraft:mossy_stone_bricks
setblock 324 250 355 minecraft:stone_bricks
fill 324 250 356 324 250 358 minecraft:mossy_stone_bricks
fill 282 251 324 282 252 326 minecraft:mossy_stone_bricks
setblock 282 251 327 minecraft:stone_bricks
fill 282 251 332 282 252 332 minecraft:mossy_stone_bricks
fill 282 251 333 282 251 334 minecraft:stone_bricks
fill 282 251 335 282 252 338 minecraft:mossy_stone_bricks
setblock 282 251 339 minecraft:stone_bricks
fill 282 251 358 282 252 358 minecraft:mossy_stone_bricks
setblock 288 251 364 minecraft:stone_bricks
fill 292 251 364 292 252 364 minecraft:mossy_stone_bricks
setblock 293 251 364 minecraft:stone_bricks
setblock 298 251 364 minecraft:stone_bricks
fill 303 251 364 303 252 364 minecraft:mossy_stone_bricks
setblock 304 251 364 minecraft:stone_bricks
fill 306 251 322 307 251 322 minecraft:stone_bricks
fill 309 251 322 310 252 322 minecraft:mossy_stone_bricks
fill 311 251 322 312 251 322 minecraft:stone_bricks
fill 317 251 364 317 252 364 minecraft:mossy_stone_bricks
fill 322 251 364 322 252 364 minecraft:mossy_stone_bricks
fill 324 251 327 324 253 327 minecraft:mossy_stone_bricks
fill 324 251 329 324 252 329 minecraft:mossy_stone_bricks
setblock 324 251 331 minecraft:stone_bricks
fill 324 251 332 324 252 332 minecraft:mossy_stone_bricks
setblock 324 251 339 minecraft:stone_bricks
fill 324 251 340 324 252 340 minecraft:mossy_stone_bricks
fill 324 251 355 324 252 357 minecraft:mossy_stone_bricks
setblock 324 251 358 minecraft:stone_bricks
fill 282 252 327 282 252 328 minecraft:mossy_stone_bricks
fill 282 252 329 282 252 330 minecraft:shroomlight
setblock 282 252 331 minecraft:mossy_stone_bricks
fill 282 252 333 282 253 334 minecraft:mossy_stone_bricks
fill 282 252 339 282 252 340 minecraft:mossy_stone_bricks
fill 282 252 341 282 252 342 minecraft:shroomlight
setblock 282 252 343 minecraft:mossy_stone_bricks
setblock 282 252 352 minecraft:mossy_stone_bricks
fill 282 252 353 282 252 354 minecraft:shroomlight
setblock 282 252 355 minecraft:mossy_stone_bricks
setblock 282 252 364 minecraft:mossy_stone_bricks
fill 283 252 364 284 252 364 minecraft:shroomlight
fill 285 252 358 285 252 360 minecraft:cobblestone
setblock 285 252 364 minecraft:mossy_stone_bricks
setblock 286 252 357 minecraft:cobblestone
fill 286 252 361 288 252 361 minecraft:cobblestone
setblock 288 252 357 minecraft:cobblestone
setblock 288 252 364 minecraft:mossy_stone_bricks
setblock 289 252 322 minecraft:mossy_stone_bricks
fill 289 252 358 289 252 360 minecraft:cobblestone
fill 290 252 322 291 252 322 minecraft:shroomlight
setblock 292 252 322 minecraft:mossy_stone_bricks
fill 293 252 364 294 252 364 minecraft:mossy_stone_bricks
fill 295 252 364 296 252 364 minecraft:shroomlight
fill 297 252 364 298 252 364 minecraft:mossy_stone_bricks
setblock 301 252 322 minecraft:mossy_stone_bricks
fill 302 252 322 303 252 322 minecraft:shroomlight
setblock 304 252 322 minecraft:mossy_stone_bricks
fill 304 252 364 304 253 364 minecraft:mossy_stone_bricks
fill 306 252 322 307 252 322 minecraft:mossy_stone_bricks
setblock 306 252 364 minecraft:mossy_stone_bricks
fill 307 252 364 308 252 364 minecraft:shroomlight
setblock 309 252 364 minecraft:mossy_stone_bricks
fill 311 252 322 313 252 322 minecraft:mossy_stone_bricks
fill 314 252 322 315 252 322 minecraft:shroomlight
setblock 316 252 322 minecraft:mossy_stone_bricks
setblock 316 252 327 minecraft:cobblestone
fill 316 252 358 316 252 360 minecraft:cobblestone
setblock 317 252 326 minecraft:cobblestone
setblock 317 252 329 minecraft:cobblestone
fill 317 252 357 320 252 357 minecraft:cobblestone
fill 317 252 361 319 252 361 minecraft:cobblestone
fill 318 252 325 319 252 325 minecraft:cobblestone
setblock 318 252 364 minecraft:mossy_stone_bricks
fill 319 252 364 320 252 364 minecraft:shroomlight
setblock 320 252 326 minecraft:cobblestone
setblock 320 252 329 minecraft:cobblestone
setblock 320 252 358 minecraft:cobblestone
setblock 320 252 360 minecraft:cobblestone
fill 321 252 327 321 252 328 minecraft:cobblestone
setblock 321 252 364 minecraft:mossy_stone_bricks
setblock 324 252 323 minecraft:mossy_stone_bricks
fill 324 252 324 324 252 325 minecraft:shroomlight
fill 324 252 326 324 253 326 minecraft:mossy_stone_bricks
setblock 324 252 331 minecraft:mossy_stone_bricks
fill 324 252 335 324 253 335 minecraft:mossy_stone_bricks
fill 324 252 336 324 252 337 minecraft:shroomlight
fill 324 252 338 324 252 339 minecraft:mossy_stone_bricks
setblock 324 252 347 minecraft:mossy_stone_bricks
fill 324 252 348 324 252 349 minecraft:shroomlight
setblock 324 252 350 minecraft:mossy_stone_bricks
fill 324 252 358 324 252 359 minecraft:mossy_stone_bricks
fill 324 252 360 324 252 361 minecraft:shroomlight
setblock 324 252 362 minecraft:mossy_stone_bricks
fill 282 253 322 282 253 332 minecraft:stone_bricks
fill 282 253 335 282 254 335 minecraft:mossy_stone_bricks
fill 282 253 336 282 253 355 minecraft:stone_bricks
setblock 282 253 356 minecraft:mossy_stone_bricks
fill 282 253 357 282 253 364 minecraft:stone_bricks
fill 283 253 322 284 253 322 minecraft:stone_bricks
fill 283 253 364 283 265 364 minecraft:stone_bricks
setblock 284 253 364 minecraft:mossy_stone_bricks
fill 285 253 322 285 255 322 minecraft:mossy_stone_bricks
fill 285 253 364 303 253 364 minecraft:stone_bricks
fill 286 253 322 311 253 322 minecraft:stone_bricks
fill 290 253 361 290 261 361 minecraft:red_wool
fill 305 253 364 323 253 364 minecraft:stone_bricks
setblock 312 253 322 minecraft:mossy_stone_bricks
fill 313 253 322 324 253 322 minecraft:stone_bricks
fill 324 253 323 324 254 325 minecraft:stone_bricks
fill 324 253 328 324 308 332 minecraft:stone_bricks
fill 324 253 333 324 254 333 minecraft:mossy_stone_bricks
fill 324 253 334 324 254 334 minecraft:stone_bricks
fill 324 253 336 324 254 338 minecraft:stone_bricks
setblock 324 253 339 minecraft:mossy_stone_bricks
fill 324 253 340 324 253 343 minecraft:stone_bricks
fill 324 253 346 324 253 351 minecraft:stone_bricks
setblock 324 253 352 minecraft:mossy_stone_bricks
fill 324 253 353 324 253 363 minecraft:stone_bricks
setblock 324 253 364 minecraft:mossy_stone_bricks
fill 282 254 322 283 254 322 minecraft:mossy_stone_bricks
fill 282 254 323 282 254 330 minecraft:stone_bricks
setblock 282 254 331 minecraft:mossy_stone_bricks
fill 282 254 332 282 254 334 minecraft:stone_bricks
fill 282 254 336 282 308 337 minecraft:stone_bricks
setblock 282 254 338 minecraft:mossy_stone_bricks
fill 282 254 339 282 254 343 minecraft:stone_bricks
fill 282 254 344 282 254 345 minecraft:mossy_stone_bricks
fill 282 254 346 282 308 351 minecraft:stone_bricks
fill 282 254 352 282 255 352 minecraft:mossy_stone_bricks
fill 282 254 353 282 265 353 minecraft:stone_bricks
fill 282 254 354 282 255 354 minecraft:mossy_stone_bricks
fill 282 254 355 282 265 358 minecraft:stone_bricks
setblock 282 254 359 minecraft:mossy_stone_bricks
fill 282 254 360 282 265 364 minecraft:stone_bricks
setblock 284 254 322 minecraft:stone_bricks
fill 284 254 364 287 265 364 minecraft:stone_bricks
fill 286 254 322 300 254 322 minecraft:stone_bricks
fill 288 254 361 289 259 361 minecraft:red_wool
setblock 288 254 364 minecraft:mossy_stone_bricks
fill 289 254 364 307 254 364 minecraft:stone_bricks
fill 291 254 361 292 261 361 minecraft:red_wool
fill 301 254 322 301 255 322 minecraft:mossy_stone_bricks
fill 302 254 322 320 254 322 minecraft:stone_bricks
fill 308 254 343 322 255 343 minecraft:polished_andesite
setblock 308 254 364 minecraft:mossy_stone_bricks
fill 309 254 364 324 254 364 minecraft:stone_bricks
fill 317 254 342 323 255 342 minecraft:polished_andesite
setblock 321 254 322 minecraft:mossy_stone_bricks
fill 321 254 328 321 259 328 minecraft:red_wool
fill 322 254 322 323 308 322 minecraft:stone_bricks
setblock 324 254 322 minecraft:mossy_stone_bricks
fill 324 254 326 324 265 327 minecraft:stone_bricks
fill 324 254 335 324 265 335 minecraft:stone_bricks
fill 324 254 339 324 308 339 minecraft:stone_bricks
setblock 324 254 340 minecraft:mossy_stone_bricks
fill 324 254 341 324 265 350 minecraft:stone_bricks
setblock 324 254 351 minecraft:mossy_stone_bricks
fill 324 254 352 324 254 361 minecraft:stone_bricks
setblock 324 254 362 minecraft:mossy_stone_bricks
fill 324 254 363 324 308 363 minecraft:stone_bricks
fill 282 255 322 282 265 329 minecraft:stone_bricks
setblock 282 255 330 minecraft:mossy_stone_bricks
fill 282 255 331 282 265 331 minecraft:stone_bricks
setblock 282 255 332 minecraft:mossy_stone_bricks
fill 282 255 333 282 308 333 minecraft:stone_bricks
setblock 282 255 334 minecraft:mossy_stone_bricks
fill 282 255 335 282 308 335 minecraft:stone_bricks
fill 282 255 338 282 308 338 minecraft:stone_bricks
setblock 282 255 339 minecraft:mossy_stone_bricks
fill 282 255 340 282 265 345 minecraft:stone_bricks
fill 282 255 359 282 308 359 minecraft:stone_bricks
fill 283 255 322 284 255 322 minecraft:mossy_stone_bricks
fill 284 255 345 287 255 346 minecraft:polished_andesite
setblock 285 255 325 minecraft:light[level=15]
setblock 285 255 332 minecraft:light[level=12]
setblock 285 255 333 minecraft:light[level=15]
setblock 285 255 339 minecraft:light[level=12]
setblock 285 255 341 minecraft:light[level=15]
setblock 285 255 349 minecraft:light[level=15]
setblock 285 255 353 minecraft:light[level=12]
setblock 285 255 357 minecraft:light[level=15]
setblock 285 255 360 minecraft:light[level=12]
fill 286 255 322 289 265 322 minecraft:stone_bricks
fill 288 255 345 301 255 345 minecraft:polished_andesite
fill 288 255 364 295 265 364 minecraft:stone_bricks
fill 290 255 322 291 255 322 minecraft:mossy_stone_bricks
fill 290 255 344 300 255 344 minecraft:polished_andesite
fill 292 255 322 300 265 322 minecraft:stone_bricks
setblock 292 255 332 minecraft:light[level=12]
setblock 292 255 339 minecraft:light[level=12]
setblock 292 255 346 minecraft:light[level=12]
setblock 292 255 353 minecraft:light[level=12]
setblock 292 255 360 minecraft:light[level=12]
setblock 293 255 333 minecraft:light[level=15]
setblock 293 255 341 minecraft:light[level=15]
setblock 293 255 349 minecraft:light[level=15]
setblock 293 255 357 minecraft:light[level=15]
fill 296 255 364 297 255 364 minecraft:mossy_stone_bricks
fill 298 255 364 298 308 364 minecraft:stone_bricks
setblock 299 255 332 minecraft:light[level=12]
setblock 299 255 339 minecraft:light[level=12]
setblock 299 255 346 minecraft:light[level=12]
setblock 299 255 353 minecraft:light[level=12]
setblock 299 255 360 minecraft:light[level=12]
setblock 299 255 364 minecraft:mossy_stone_bricks
fill 300 255 364 316 265 364 minecraft:stone_bricks
setblock 301 255 325 minecraft:light[level=15]
setblock 301 255 333 minecraft:light[level=15]
setblock 301 255 341 minecraft:light[level=15]
setblock 301 255 349 minecraft:light[level=15]
setblock 301 255 357 minecraft:light[level=15]
fill 302 255 322 305 265 322 minecraft:stone_bricks
fill 306 255 322 307 255 322 minecraft:mossy_stone_bricks
setblock 306 255 325 minecraft:light[level=12]
setblock 306 255 332 minecraft:light[level=12]
setblock 306 255 339 minecraft:light[level=12]
setblock 306 255 346 minecraft:light[level=12]
setblock 306 255 353 minecraft:light[level=12]
setblock 306 255 360 minecraft:light[level=12]
fill 307 255 343 307 255 344 minecraft:polished_andesite
fill 308 255 322 314 265 322 minecraft:stone_bricks
fill 308 255 344 312 255 344 minecraft:polished_andesite
setblock 309 255 325 minecraft:light[level=15]
setblock 309 255 333 minecraft:light[level=15]
setblock 309 255 341 minecraft:light[level=15]
setblock 309 255 349 minecraft:light[level=15]
setblock 309 255 357 minecraft:light[level=15]
setblock 313 255 325 minecraft:light[level=12]
setblock 313 255 332 minecraft:light[level=12]
setblock 313 255 339 minecraft:light[level=12]
setblock 313 255 346 minecraft:light[level=12]
setblock 313 255 353 minecraft:light[level=12]
setblock 313 255 360 minecraft:light[level=12]
fill 314 255 342 316 255 342 minecraft:polished_andesite
setblock 315 255 322 minecraft:mossy_stone_bricks
fill 316 255 322 316 265 322 minecraft:stone_bricks
setblock 317 255 322 minecraft:mossy_stone_bricks
setblock 317 255 325 minecraft:light[level=15]
setblock 317 255 333 minecraft:light[level=15]
setblock 317 255 341 minecraft:light[level=15]
setblock 317 255 349 minecraft:light[level=15]
setblock 317 255 357 minecraft:light[level=15]
setblock 317 255 364 minecraft:mossy_stone_bricks
fill 318 255 322 321 308 322 minecraft:stone_bricks
fill 318 255 364 319 265 364 minecraft:stone_bricks
setblock 320 255 325 minecraft:light[level=12]
setblock 320 255 332 minecraft:light[level=12]
setblock 320 255 339 minecraft:light[level=12]
setblock 320 255 346 minecraft:light[level=12]
setblock 320 255 353 minecraft:light[level=12]
setblock 320 255 360 minecraft:light[level=12]
setblock 320 255 364 minecraft:mossy_stone_bricks
fill 321 255 326 321 259 327 minecraft:red_wool
fill 321 255 329 321 264 330 minecraft:red_wool
fill 321 255 364 323 265 364 minecraft:stone_bricks
fill 324 255 322 324 308 322 minecraft:stone_bricks
setblock 324 255 323 minecraft:mossy_stone_bricks
fill 324 255 324 324 265 325 minecraft:stone_bricks
fill 324 255 333 324 308 333 minecraft:stone_bricks
setblock 324 255 334 minecraft:mossy_stone_bricks
fill 324 255 336 324 265 337 minecraft:stone_bricks
setblock 324 255 338 minecraft:mossy_stone_bricks
fill 324 255 340 324 308 340 minecraft:stone_bricks
fill 324 255 351 324 308 356 minecraft:stone_bricks
setblock 324 255 357 minecraft:mossy_stone_bricks
fill 324 255 358 324 265 362 minecraft:stone_bricks
setblock 324 255 364 minecraft:mossy_stone_bricks
fill 282 256 330 282 265 330 minecraft:stone_bricks
fill 282 256 332 282 308 332 minecraft:stone_bricks
fill 282 256 334 282 308 334 minecraft:stone_bricks
fill 282 256 339 282 308 339 minecraft:stone_bricks
fill 282 256 352 282 265 352 minecraft:stone_bricks
fill 282 256 354 282 265 354 minecraft:stone_bricks
fill 283 256 322 285 308 322 minecraft:stone_bricks
fill 284 256 345 284 259 345 minecraft:red_wool
fill 284 256 346 286 256 346 minecraft:polished_andesite
fill 285 256 345 295 256 345 minecraft:polished_andesite
fill 290 256 322 291 265 322 minecraft:stone_bricks
fill 293 256 344 300 256 344 minecraft:polished_andesite
fill 296 256 364 297 265 364 minecraft:stone_bricks
fill 299 256 364 299 308 364 minecraft:stone_bricks
fill 301 256 322 301 265 322 minecraft:stone_bricks
fill 306 256 322 307 308 322 minecraft:stone_bricks
fill 308 256 343 320 256 343 minecraft:red_wool
fill 315 256 322 315 265 322 minecraft:stone_bricks
fill 317 256 322 317 308 322 minecraft:stone_bricks
fill 317 256 364 317 308 364 minecraft:stone_bricks
fill 319 256 342 322 256 342 minecraft:red_wool
fill 320 256 364 320 265 364 minecraft:stone_bricks
fill 324 256 323 324 265 323 minecraft:stone_bricks
fill 324 256 334 324 308 334 minecraft:stone_bricks
fill 324 256 338 324 265 338 minecraft:stone_bricks
fill 324 256 357 324 308 357 minecraft:stone_bricks
fill 324 256 364 324 308 364 minecraft:stone_bricks
fill 284 257 343 284 259 344 minecraft:red_wool
fill 284 257 346 284 259 347 minecraft:red_wool
fill 285 257 345 293 257 345 minecraft:red_wool
fill 298 257 344 300 257 344 minecraft:red_wool
fill 284 258 330 284 259 336 minecraft:iron_bars
fill 289 258 324 299 258 330 minecraft:red_wool
fill 295 258 323 297 259 323 minecraft:polished_andesite
fill 290 259 325 298 259 329 minecraft:red_wool
fill 283 260 351 283 262 353 minecraft:yellow_wool
fill 284 260 332 284 265 334 minecraft:polished_andesite
fill 284 260 343 284 270 343 minecraft:red_wool
fill 284 260 344 284 265 346 minecraft:polished_andesite
fill 284 260 347 284 270 347 minecraft:red_wool
fill 284 260 356 284 265 358 minecraft:polished_andesite
fill 285 260 358 285 260 360 minecraft:cobblestone
setblock 286 260 357 minecraft:cobblestone
fill 286 260 361 288 260 361 minecraft:cobblestone
setblock 288 260 357 minecraft:cobblestone
fill 289 260 358 289 260 360 minecraft:cobblestone
fill 289 260 361 289 261 361 minecraft:red_wool
fill 290 260 362 292 265 362 minecraft:polished_andesite
fill 291 260 326 297 260 328 minecraft:red_wool
fill 293 260 323 295 262 323 minecraft:red_wool
fill 294 260 324 296 265 324 minecraft:polished_andesite
fill 295 260 363 297 262 363 minecraft:blue_wool
fill 296 260 323 297 272 323 minecraft:polished_andesite
fill 302 260 362 304 265 362 minecraft:polished_andesite
fill 306 260 324 308 265 324 minecraft:polished_andesite
fill 314 260 362 316 265 362 minecraft:polished_andesite
setblock 316 260 327 minecraft:cobblestone
fill 316 260 358 316 260 360 minecraft:cobblestone
setblock 317 260 326 minecraft:cobblestone
setblock 317 260 329 minecraft:cobblestone
fill 317 260 357 320 260 357 minecraft:cobblestone
fill 317 260 361 319 260 361 minecraft:cobblestone
fill 318 260 324 320 265 324 minecraft:polished_andesite
fill 318 260 325 319 260 325 minecraft:cobblestone
setblock 320 260 326 minecraft:cobblestone
setblock 320 260 329 minecraft:cobblestone
setblock 320 260 358 minecraft:cobblestone
setblock 320 260 360 minecraft:cobblestone
fill 321 260 326 321 264 326 minecraft:red_wool
fill 321 260 327 321 260 328 minecraft:cobblestone
fill 322 260 332 322 265 334 minecraft:polished_andesite
fill 322 260 344 322 265 346 minecraft:polished_andesite
fill 322 260 356 322 265 358 minecraft:polished_andesite
fill 323 260 349 323 262 351 minecraft:red_wool
setblock 285 261 325 minecraft:light[level=12]
setblock 285 261 332 minecraft:light[level=12]
setblock 285 261 339 minecraft:light[level=12]
setblock 285 261 346 minecraft:light[level=12]
setblock 285 261 353 minecraft:light[level=12]
setblock 285 261 360 minecraft:light[level=12]
setblock 288 261 361 minecraft:red_wool
setblock 292 261 325 minecraft:light[level=12]
fill 292 261 327 296 261 327 minecraft:red_wool
setblock 292 261 332 minecraft:light[level=12]
setblock 292 261 339 minecraft:light[level=12]
setblock 292 261 346 minecraft:light[level=12]
setblock 292 261 353 minecraft:light[level=12]
setblock 292 261 360 minecraft:light[level=12]
setblock 299 261 325 minecraft:light[level=12]
setblock 299 261 332 minecraft:light[level=12]
setblock 299 261 339 minecraft:light[level=12]
setblock 299 261 346 minecraft:light[level=12]
setblock 299 261 353 minecraft:light[level=12]
setblock 299 261 360 minecraft:light[level=12]
setblock 306 261 325 minecraft:light[level=12]
setblock 306 261 332 minecraft:light[level=12]
setblock 306 261 339 minecraft:light[level=12]
setblock 306 261 346 minecraft:light[level=12]
setblock 306 261 353 minecraft:light[level=12]
setblock 306 261 360 minecraft:light[level=12]
setblock 313 261 325 minecraft:light[level=12]
setblock 313 261 332 minecraft:light[level=12]
setblock 313 261 339 minecraft:light[level=12]
setblock 313 261 346 minecraft:light[level=12]
setblock 313 261 353 minecraft:light[level=12]
setblock 313 261 360 minecraft:light[level=12]
setblock 320 261 325 minecraft:light[level=12]
setblock 320 261 332 minecraft:light[level=12]
setblock 320 261 339 minecraft:light[level=12]
setblock 320 261 346 minecraft:light[level=12]
setblock 320 261 353 minecraft:light[level=12]
setblock 320 261 360 minecraft:light[level=12]
fill 321 261 327 321 264 328 minecraft:red_wool
fill 287 262 361 293 263 361 minecraft:iron_bars
fill 283 263 351 283 268 351 minecraft:yellow_wool
fill 283 263 352 283 265 352 minecraft:gold_block
fill 283 263 353 283 268 353 minecraft:yellow_wool
setblock 285 263 325 minecraft:light[level=15]
setblock 285 263 333 minecraft:light[level=15]
setblock 285 263 341 minecraft:light[level=15]
setblock 285 263 349 minecraft:light[level=15]
setblock 285 263 357 minecraft:light[level=15]
fill 293 263 323 293 268 323 minecraft:red_wool
setblock 293 263 325 minecraft:light[level=15]
setblock 293 263 333 minecraft:light[level=15]
setblock 293 263 341 minecraft:light[level=15]
setblock 293 263 349 minecraft:light[level=15]
setblock 293 263 357 minecraft:light[level=15]
fill 294 263 323 294 265 323 minecraft:gold_block
fill 295 263 323 295 268 323 minecraft:red_wool
fill 295 263 363 295 268 363 minecraft:blue_wool
fill 296 263 363 296 265 363 minecraft:gold_block
fill 297 263 363 297 268 363 minecraft:blue_wool
setblock 301 263 325 minecraft:light[level=15]
setblock 301 263 333 minecraft:light[level=15]
setblock 301 263 341 minecraft:light[level=15]
setblock 301 263 349 minecraft:light[level=15]
setblock 301 263 357 minecraft:light[level=15]
setblock 309 263 325 minecraft:light[level=15]
setblock 309 263 333 minecraft:light[level=15]
setblock 309 263 341 minecraft:light[level=15]
setblock 309 263 349 minecraft:light[level=15]
setblock 309 263 357 minecraft:light[level=15]
setblock 317 263 325 minecraft:light[level=15]
setblock 317 263 333 minecraft:light[level=15]
setblock 317 263 341 minecraft:light[level=15]
setblock 317 263 349 minecraft:light[level=15]
setblock 317 263 357 minecraft:light[level=15]
fill 323 263 349 323 268 349 minecraft:red_wool
fill 323 263 350 323 265 350 minecraft:gold_block
fill 323 263 351 323 268 351 minecraft:red_wool
fill 283 265 326 283 265 331 minecraft:cobblestone
fill 283 265 338 283 265 343 minecraft:cobblestone
setblock 283 265 350 minecraft:cobblestone
fill 283 265 354 283 265 355 minecraft:cobblestone
fill 283 265 362 283 265 363 minecraft:cobblestone
fill 284 265 363 287 265 363 minecraft:cobblestone
fill 287 265 323 292 265 323 minecraft:cobblestone
setblock 294 265 363 minecraft:cobblestone
fill 298 265 363 299 265 363 minecraft:cobblestone
fill 299 265 323 304 265 323 minecraft:cobblestone
fill 306 265 363 311 265 363 minecraft:cobblestone
fill 311 265 323 316 265 323 minecraft:cobblestone
fill 318 265 363 323 265 363 minecraft:cobblestone
fill 321 265 325 321 266 331 minecraft:iron_bars
fill 323 265 323 323 265 328 minecraft:cobblestone
fill 323 265 335 323 265 340 minecraft:cobblestone
fill 323 265 347 323 265 348 minecraft:cobblestone
setblock 323 265 352 minecraft:cobblestone
fill 323 265 359 323 265 362 minecraft:cobblestone
fill 282 266 322 282 308 327 minecraft:stone_bricks
fill 282 266 328 282 271 331 minecraft:shroomlight
fill 282 266 340 282 271 343 minecraft:shroomlight
fill 282 266 344 282 308 345 minecraft:stone_bricks
fill 282 266 352 282 271 355 minecraft:shroomlight
fill 282 266 356 282 308 358 minecraft:stone_bricks
fill 282 266 360 282 308 363 minecraft:stone_bricks
fill 282 266 364 285 271 364 minecraft:shroomlight
fill 283 266 352 283 268 352 minecraft:yellow_wool
fill 284 266 344 284 270 346 minecraft:red_wool
fill 286 266 322 288 308 322 minecraft:stone_bricks
fill 286 266 364 293 308 364 minecraft:stone_bricks
fill 289 266 322 292 271 322 minecraft:shroomlight
fill 293 266 322 300 308 322 minecraft:stone_bricks
fill 294 266 323 294 268 323 minecraft:red_wool
fill 294 266 364 297 271 364 minecraft:shroomlight
fill 296 266 363 296 268 363 minecraft:blue_wool
fill 300 266 364 305 308 364 minecraft:stone_bricks
fill 301 266 322 304 271 322 minecraft:shroomlight
fill 305 266 322 305 308 322 minecraft:stone_bricks
fill 306 266 364 309 271 364 minecraft:shroomlight
fill 308 266 322 312 308 322 minecraft:stone_bricks
fill 310 266 364 316 285 364 minecraft:stone_bricks
fill 313 266 322 316 271 322 minecraft:shroomlight
fill 313 266 345 322 267 345 minecraft:polished_andesite
fill 318 266 364 321 271 364 minecraft:shroomlight
fill 321 266 344 322 267 344 minecraft:polished_andesite
fill 322 266 364 323 285 364 minecraft:stone_bricks
fill 323 266 350 323 268 350 minecraft:red_wool
fill 324 266 323 324 271 326 minecraft:shroomlight
fill 324 266 327 324 308 327 minecraft:stone_bricks
fill 324 266 335 324 271 338 minecraft:shroomlight
fill 324 266 341 324 308 346 minecraft:stone_bricks
fill 324 266 347 324 271 350 minecraft:shroomlight
fill 324 266 358 324 308 358 minecraft:stone_bricks
fill 324 266 359 324 271 362 minecraft:shroomlight
setblock 285 267 325 minecraft:light[level=12]
setblock 285 267 332 minecraft:light[level=12]
setblock 285 267 339 minecraft:light[level=12]
setblock 285 267 346 minecraft:light[level=12]
setblock 285 267 353 minecraft:light[level=12]
setblock 285 267 360 minecraft:light[level=12]
setblock 292 267 325 minecraft:light[level=12]
setblock 292 267 332 minecraft:light[level=12]
setblock 292 267 339 minecraft:light[level=12]
setblock 292 267 346 minecraft:light[level=12]
setblock 292 267 353 minecraft:light[level=12]
setblock 292 267 360 minecraft:light[level=12]
fill 294 267 346 316 267 346 minecraft:polished_andesite
setblock 299 267 325 minecraft:light[level=12]
setblock 299 267 332 minecraft:light[level=12]
setblock 299 267 339 minecraft:light[level=12]
setblock 299 267 353 minecraft:light[level=12]
setblock 299 267 360 minecraft:light[level=12]
fill 302 267 345 312 267 345 minecraft:polished_andesite
setblock 306 267 325 minecraft:light[level=12]
setblock 306 267 332 minecraft:light[level=12]
setblock 306 267 339 minecraft:light[level=12]
setblock 306 267 353 minecraft:light[level=12]
setblock 306 267 360 minecraft:light[level=12]
setblock 313 267 325 minecraft:light[level=12]
setblock 313 267 332 minecraft:light[level=12]
setblock 313 267 339 minecraft:light[level=12]
setblock 313 267 353 minecraft:light[level=12]
setblock 313 267 360 minecraft:light[level=12]
fill 317 267 344 320 267 344 minecraft:polished_andesite
fill 318 267 334 318 270 334 minecraft:iron_bars
setblock 320 267 325 minecraft:light[level=12]
setblock 320 267 332 minecraft:light[level=12]
setblock 320 267 339 minecraft:light[level=12]
setblock 320 267 346 minecraft:light[level=12]
setblock 320 267 353 minecraft:light[level=12]
setblock 320 267 360 minecraft:light[level=12]
fill 285 268 346 297 268 347 minecraft:polished_andesite
fill 285 268 358 285 268 360 minecraft:cobblestone
setblock 286 268 357 minecraft:cobblestone
fill 286 268 361 288 268 361 minecraft:cobblestone
setblock 288 268 357 minecraft:cobblestone
fill 289 268 358 289 268 360 minecraft:cobblestone
fill 298 268 346 308 268 346 minecraft:polished_andesite
fill 300 268 345 311 268 345 minecraft:polished_andesite
fill 312 268 345 322 268 345 minecraft:red_wool
setblock 316 268 327 minecraft:cobblestone
fill 316 268 358 316 268 360 minecraft:cobblestone
setblock 317 268 326 minecraft:cobblestone
setblock 317 268 329 minecraft:cobblestone
fill 317 268 357 320 268 357 minecraft:cobblestone
fill 317 268 361 319 268 361 minecraft:cobblestone
fill 318 268 325 319 268 325 minecraft:cobblestone
setblock 320 268 326 minecraft:cobblestone
setblock 320 268 329 minecraft:cobblestone
setblock 320 268 358 minecraft:cobblestone
setblock 320 268 360 minecraft:cobblestone
fill 321 268 327 321 268 328 minecraft:cobblestone
fill 285 269 346 289 269 347 minecraft:polished_andesite
setblock 290 269 346 minecraft:polished_andesite
fill 292 269 346 306 269 346 minecraft:red_wool
fill 295 269 323 295 272 323 minecraft:polished_andesite
fill 320 269 346 322 270 346 minecraft:iron_bars
fill 285 270 347 287 270 347 minecraft:red_wool
fill 284 271 342 284 272 348 minecraft:iron_bars
setblock 285 271 325 minecraft:light[level=15]
setblock 285 271 333 minecraft:light[level=15]
setblock 285 271 341 minecraft:light[level=15]
setblock 285 271 349 minecraft:light[level=15]
setblock 285 271 357 minecraft:light[level=15]
fill 285 271 358 285 272 360 minecraft:red_wool
fill 286 271 357 286 272 357 minecraft:red_wool
fill 287 271 361 287 272 361 minecraft:red_wool
fill 288 271 357 288 272 357 minecraft:red_wool
fill 289 271 358 289 272 359 minecraft:red_wool
setblock 293 271 325 minecraft:light[level=15]
setblock 293 271 333 minecraft:light[level=15]
setblock 293 271 341 minecraft:light[level=15]
setblock 293 271 349 minecraft:light[level=15]
setblock 293 271 357 minecraft:light[level=15]
setblock 301 271 325 minecraft:light[level=15]
setblock 301 271 333 minecraft:light[level=15]
setblock 301 271 341 minecraft:light[level=15]
setblock 301 271 349 minecraft:light[level=15]
setblock 301 271 357 minecraft:light[level=15]
setblock 309 271 325 minecraft:light[level=15]
setblock 309 271 333 minecraft:light[level=15]
setblock 309 271 341 minecraft:light[level=15]
setblock 309 271 349 minecraft:light[level=15]
setblock 309 271 357 minecraft:light[level=15]
fill 316 271 358 316 272 359 minecraft:red_wool
setblock 317 271 325 minecraft:light[level=15]
fill 317 271 326 317 272 326 minecraft:red_wool
fill 317 271 329 317 272 329 minecraft:red_wool
setblock 317 271 333 minecraft:light[level=15]
setblock 317 271 341 minecraft:light[level=15]
setblock 317 271 349 minecraft:light[level=15]
fill 317 271 357 319 272 357 minecraft:red_wool
fill 318 271 325 319 272 325 minecraft:red_wool
fill 318 271 331 322 271 337 minecraft:cobblestone
fill 318 271 361 319 272 361 minecraft:red_wool
fill 320 271 326 320 272 326 minecraft:red_wool
fill 320 271 329 320 272 329 minecraft:red_wool
fill 320 271 358 320 272 358 minecraft:red_wool
fill 320 271 360 320 272 360 minecraft:red_wool
fill 282 272 328 282 285 328 minecraft:stone_bricks
fill 282 272 329 282 272 330 minecraft:shroomlight
fill 282 272 331 282 285 331 minecraft:stone_bricks
fill 282 272 340 282 285 340 minecraft:stone_bricks
fill 282 272 341 282 272 342 minecraft:shroomlight
fill 282 272 343 282 285 343 minecraft:stone_bricks
fill 282 272 352 282 285 352 minecraft:stone_bricks
fill 282 272 353 282 272 354 minecraft:shroomlight
fill 282 272 355 282 285 355 minecraft:stone_bricks
fill 282 272 364 282 285 364 minecraft:stone_bricks
fill 283 272 364 284 272 364 minecraft:shroomlight
fill 285 272 364 285 285 364 minecraft:stone_bricks
fill 289 272 322 289 285 322 minecraft:stone_bricks
fill 290 272 322 291 272 322 minecraft:shroomlight
fill 292 272 322 292 285 322 minecraft:stone_bricks
fill 294 272 364 294 285 364 minecraft:stone_bricks
fill 295 272 364 296 272 364 minecraft:shroomlight
fill 297 272 364 297 285 364 minecraft:stone_bricks
fill 301 272 322 301 285 322 minecraft:stone_bricks
fill 302 272 322 303 272 322 minecraft:shroomlight
fill 304 272 322 304 285 322 minecraft:stone_bricks
fill 306 272 364 306 285 364 minecraft:stone_bricks
fill 307 272 364 308 272 364 minecraft:shroomlight
fill 309 272 364 309 285 364 minecraft:stone_bricks
fill 313 272 322 313 285 322 minecraft:stone_bricks
fill 314 272 322 315 272 322 minecraft:shroomlight
fill 316 272 322 316 285 322 minecraft:stone_bricks
fill 318 272 331 322 272 337 minecraft:polished_andesite
fill 318 272 364 318 285 364 minecraft:stone_bricks
fill 319 272 364 320 272 364 minecraft:shroomlight
fill 321 272 364 321 285 364 minecraft:stone_bricks
fill 324 272 323 324 285 323 minecraft:stone_bricks
fill 324 272 324 324 272 325 minecraft:shroomlight
fill 324 272 326 324 285 326 minecraft:stone_bricks
fill 324 272 335 324 285 335 minecraft:stone_bricks
fill 324 272 336 324 272 337 minecraft:shroomlight
fill 324 272 338 324 285 338 minecraft:stone_bricks
fill 324 272 347 324 285 347 minecraft:stone_bricks
fill 324 272 348 324 272 349 minecraft:shroomlight
fill 324 272 350 324 285 350 minecraft:stone_bricks
fill 324 272 359 324 285 359 minecraft:stone_bricks
fill 324 272 360 324 272 361 minecraft:shroomlight
fill 324 272 362 324 285 362 minecraft:stone_bricks
fill 282 273 329 282 285 330 minecraft:stone_bricks
fill 282 273 341 282 285 342 minecraft:stone_bricks
fill 282 273 353 282 285 354 minecraft:stone_bricks
fill 283 273 364 284 285 364 minecraft:stone_bricks
setblock 285 273 325 minecraft:light[level=12]
setblock 285 273 332 minecraft:light[level=12]
setblock 285 273 339 minecraft:light[level=12]
setblock 285 273 346 minecraft:light[level=12]
setblock 285 273 353 minecraft:light[level=12]
setblock 285 273 360 minecraft:light[level=12]
fill 290 273 322 291 285 322 minecraft:stone_bricks
setblock 292 273 325 minecraft:light[level=12]
setblock 292 273 332 minecraft:light[level=12]
setblock 292 273 339 minecraft:light[level=12]
setblock 292 273 346 minecraft:light[level=12]
setblock 292 273 353 minecraft:light[level=12]
setblock 292 273 360 minecraft:light[level=12]
fill 295 273 364 296 285 364 minecraft:stone_bricks
setblock 299 273 325 minecraft:light[level=12]
setblock 299 273 332 minecraft:light[level=12]
setblock 299 273 339 minecraft:light[level=12]
setblock 299 273 346 minecraft:light[level=12]
setblock 299 273 353 minecraft:light[level=12]
setblock 299 273 360 minecraft:light[level=12]
fill 302 273 322 303 285 322 minecraft:stone_bricks
setblock 306 273 325 minecraft:light[level=12]
setblock 306 273 332 minecraft:light[level=12]
setblock 306 273 339 minecraft:light[level=12]
setblock 306 273 346 minecraft:light[level=12]
setblock 306 273 353 minecraft:light[level=12]
setblock 306 273 360 minecraft:light[level=12]
fill 307 273 364 308 285 364 minecraft:stone_bricks
setblock 313 273 325 minecraft:light[level=12]
setblock 313 273 332 minecraft:light[level=12]
setblock 313 273 339 minecraft:light[level=12]
setblock 313 273 346 minecraft:light[level=12]
setblock 313 273 353 minecraft:light[level=12]
setblock 313 273 360 minecraft:light[level=12]
fill 314 273 322 315 285 322 minecraft:stone_bricks
fill 319 273 364 320 285 364 minecraft:stone_bricks
setblock 320 273 325 minecraft:light[level=12]
setblock 320 273 332 minecraft:light[level=12]
setblock 320 273 339 minecraft:light[level=12]
setblock 320 273 346 minecraft:light[level=12]
setblock 320 273 353 minecraft:light[level=12]
setblock 320 273 360 minecraft:light[level=12]
fill 323 273 333 323 276 335 minecraft:shroomlight
fill 324 273 324 324 285 325 minecraft:stone_bricks
fill 324 273 336 324 285 337 minecraft:stone_bricks
fill 324 273 348 324 285 349 minecraft:stone_bricks
fill 324 273 360 324 285 361 minecraft:stone_bricks
fill 293 278 341 301 278 341 minecraft:stone_bricks
fill 294 278 337 301 278 340 minecraft:stone_bricks
fill 294 278 342 301 278 345 minecraft:stone_bricks
fill 295 278 335 313 278 336 minecraft:stone_bricks
fill 295 278 346 313 278 347 minecraft:stone_bricks
fill 296 278 334 312 279 334 minecraft:stone_bricks
fill 296 278 348 312 279 348 minecraft:stone_bricks
fill 297 278 333 311 279 333 minecraft:stone_bricks
fill 297 278 349 311 279 349 minecraft:stone_bricks
fill 298 278 332 310 279 332 minecraft:stone_bricks
fill 298 278 350 310 279 350 minecraft:stone_bricks
fill 300 278 331 308 279 331 minecraft:stone_bricks
fill 300 278 351 308 279 351 minecraft:stone_bricks
fill 302 278 337 302 278 339 minecraft:stone_bricks
fill 302 278 343 302 278 345 minecraft:stone_bricks
fill 303 278 337 314 278 338 minecraft:stone_bricks
fill 303 278 344 314 278 345 minecraft:stone_bricks
fill 304 278 330 304 279 330 minecraft:stone_bricks
fill 304 278 352 304 279 352 minecraft:stone_bricks
fill 306 278 339 314 278 339 minecraft:stone_bricks
fill 306 278 343 314 278 343 minecraft:stone_bricks
fill 307 278 340 314 278 342 minecraft:stone_bricks
fill 315 278 341 315 281 341 minecraft:stone_bricks
fill 283 279 323 283 279 324 minecraft:cobblestone
setblock 283 279 325 minecraft:mossy_cobblestone
fill 283 279 326 283 279 328 minecraft:cobblestone
setblock 283 279 329 minecraft:mossy_cobblestone
fill 283 279 330 283 279 332 minecraft:cobblestone
setblock 283 279 333 minecraft:mossy_cobblestone
fill 283 279 334 283 279 336 minecraft:cobblestone
setblock 283 279 337 minecraft:mossy_cobblestone
fill 283 279 338 283 279 340 minecraft:cobblestone
setblock 283 279 341 minecraft:mossy_cobblestone
fill 283 279 342 283 279 344 minecraft:cobblestone
setblock 283 279 345 minecraft:mossy_cobblestone
fill 283 279 346 283 279 348 minecraft:cobblestone
setblock 283 279 349 minecraft:mossy_cobblestone
fill 283 279 350 283 279 352 minecraft:cobblestone
setblock 283 279 353 minecraft:mossy_cobblestone
fill 283 279 354 283 279 356 minecraft:cobblestone
setblock 283 279 357 minecraft:mossy_cobblestone
fill 283 279 358 283 279 360 minecraft:cobblestone
setblock 283 279 361 minecraft:mossy_cobblestone
fill 283 279 362 284 279 363 minecraft:cobblestone
setblock 284 279 323 minecraft:cobblestone
setblock 284 279 324 minecraft:mossy_cobblestone
fill 284 279 325 284 279 327 minecraft:cobblestone
setblock 284 279 328 minecraft:mossy_cobblestone
fill 284 279 329 284 279 331 minecraft:cobblestone
setblock 284 279 332 minecraft:mossy_cobblestone
fill 284 279 333 284 279 335 minecraft:cobblestone
setblock 284 279 336 minecraft:mossy_cobblestone
fill 284 279 337 284 279 339 minecraft:cobblestone
setblock 284 279 340 minecraft:mossy_cobblestone
fill 284 279 341 284 279 343 minecraft:cobblestone
setblock 284 279 344 minecraft:mossy_cobblestone
fill 284 279 345 284 279 347 minecraft:cobblestone
setblock 284 279 348 minecraft:mossy_cobblestone
fill 284 279 349 284 279 351 minecraft:cobblestone
setblock 284 279 352 minecraft:mossy_cobblestone
fill 284 279 353 284 279 355 minecraft:cobblestone
setblock 284 279 356 minecraft:mossy_cobblestone
fill 284 279 357 284 279 359 minecraft:cobblestone
setblock 284 279 360 minecraft:mossy_cobblestone
fill 284 279 361 286 279 361 minecraft:cobblestone
setblock 285 279 323 minecraft:mossy_cobblestone
fill 285 279 324 285 279 326 minecraft:cobblestone
setblock 285 279 327 minecraft:mossy_cobblestone
fill 285 279 328 285 279 330 minecraft:cobblestone
setblock 285 279 331 minecraft:mossy_cobblestone
fill 285 279 332 285 279 334 minecraft:cobblestone
setblock 285 279 335 minecraft:mossy_cobblestone
fill 285 279 336 285 279 338 minecraft:cobblestone
setblock 285 279 339 minecraft:mossy_cobblestone
fill 285 279 340 285 279 342 minecraft:cobblestone
setblock 285 279 343 minecraft:mossy_cobblestone
fill 285 279 344 285 279 346 minecraft:cobblestone
setblock 285 279 347 minecraft:mossy_cobblestone
fill 285 279 348 285 279 350 minecraft:cobblestone
setblock 285 279 351 minecraft:mossy_cobblestone
fill 285 279 352 285 279 354 minecraft:cobblestone
setblock 285 279 355 minecraft:mossy_cobblestone
fill 285 279 356 285 279 358 minecraft:cobblestone
setblock 285 279 359 minecraft:mossy_cobblestone
fill 285 279 360 287 279 360 minecraft:cobblestone
setblock 285 279 362 minecraft:cobblestone
setblock 285 279 363 minecraft:mossy_cobblestone
fill 286 279 323 286 279 325 minecraft:cobblestone
setblock 286 279 326 minecraft:mossy_cobblestone
fill 286 279 327 286 279 329 minecraft:cobblestone
setblock 286 279 330 minecraft:mossy_cobblestone
fill 286 279 331 286 279 333 minecraft:cobblestone
setblock 286 279 334 minecraft:mossy_cobblestone
fill 286 279 335 286 279 337 minecraft:cobblestone
setblock 286 279 338 minecraft:mossy_cobblestone
fill 286 279 339 286 279 341 minecraft:cobblestone
setblock 286 279 342 minecraft:mossy_cobblestone
fill 286 279 343 286 279 345 minecraft:cobblestone
setblock 286 279 346 minecraft:mossy_cobblestone
fill 286 279 347 286 279 349 minecraft:cobblestone
setblock 286 279 350 minecraft:mossy_cobblestone
fill 286 279 351 286 279 353 minecraft:cobblestone
setblock 286 279 354 minecraft:mossy_cobblestone
fill 286 279 355 286 279 357 minecraft:cobblestone
setblock 286 279 358 minecraft:mossy_cobblestone
fill 286 279 359 288 279 359 minecraft:cobblestone
setblock 286 279 362 minecraft:mossy_cobblestone
fill 286 279 363 288 279 363 minecraft:cobblestone
fill 287 279 323 287 279 324 minecraft:cobblestone
setblock 287 279 325 minecraft:mossy_cobblestone
fill 287 279 326 287 279 328 minecraft:cobblestone
setblock 287 279 329 minecraft:mossy_cobblestone
fill 287 279 330 287 279 332 minecraft:cobblestone
setblock 287 279 333 minecraft:mossy_cobblestone
fill 287 279 334 287 279 336 minecraft:cobblestone
setblock 287 279 337 minecraft:mossy_cobblestone
fill 287 279 338 287 279 340 minecraft:cobblestone
setblock 287 279 341 minecraft:mossy_cobblestone
fill 287 279 342 287 279 344 minecraft:cobblestone
setblock 287 279 345 minecraft:mossy_cobblestone
fill 287 279 346 287 279 348 minecraft:cobblestone
setblock 287 279 349 minecraft:mossy_cobblestone
fill 287 279 350 287 279 352 minecraft:cobblestone
setblock 287 279 353 minecraft:mossy_cobblestone
fill 287 279 354 287 279 356 minecraft:cobblestone
setblock 287 279 357 minecraft:mossy_cobblestone
fill 287 279 358 289 279 358 minecraft:cobblestone
setblock 287 279 361 minecraft:mossy_cobblestone
fill 287 279 362 289 279 362 minecraft:cobblestone
setblock 288 279 323 minecraft:cobblestone
setblock 288 279 324 minecraft:mossy_cobblestone
fill 288 279 325 288 279 327 minecraft:cobblestone
setblock 288 279 328 minecraft:mossy_cobblestone
fill 288 279 329 288 279 331 minecraft:cobblestone
setblock 288 279 332 minecraft:mossy_cobblestone
fill 288 279 333 288 279 335 minecraft:cobblestone
setblock 288 279 336 minecraft:mossy_cobblestone
fill 288 279 337 288 279 339 minecraft:cobblestone
setblock 288 279 340 minecraft:mossy_cobblestone
fill 288 279 341 288 279 343 minecraft:cobblestone
setblock 288 279 344 minecraft:mossy_cobblestone
fill 288 279 345 288 279 347 minecraft:cobblestone
setblock 288 279 348 minecraft:mossy_cobblestone
fill 288 279 349 288 279 351 minecraft:cobblestone
setblock 288 279 352 minecraft:mossy_cobblestone
fill 288 279 353 288 279 355 minecraft:cobblestone
setblock 288 279 356 minecraft:mossy_cobblestone
fill 288 279 357 290 279 357 minecraft:cobblestone
setblock 288 279 360 minecraft:mossy_cobblestone
fill 288 279 361 290 279 361 minecraft:cobblestone
setblock 289 279 323 minecraft:mossy_cobblestone
fill 289 279 324 289 279 326 minecraft:cobblestone
setblock 289 279 327 minecraft:mossy_cobblestone
fill 289 279 328 289 279 330 minecraft:cobblestone
setblock 289 279 331 minecraft:mossy_cobblestone
fill 289 279 332 289 279 334 minecraft:cobblestone
setblock 289 279 335 minecraft:mossy_cobblestone
fill 289 279 336 289 279 338 minecraft:cobblestone
setblock 289 279 339 minecraft:mossy_cobblestone
fill 289 279 340 289 279 342 minecraft:cobblestone
setblock 289 279 343 minecraft:mossy_cobblestone
fill 289 279 344 289 279 346 minecraft:cobblestone
setblock 289 279 347 minecraft:mossy_cobblestone
fill 289 279 348 289 279 350 minecraft:cobblestone
setblock 289 279 351 minecraft:mossy_cobblestone
fill 289 279 352 289 279 354 minecraft:cobblestone
setblock 289 279 355 minecraft:mossy_cobblestone
fill 289 279 356 291 279 356 minecraft:cobblestone
setblock 289 279 359 minecraft:mossy_cobblestone
fill 289 279 360 291 279 360 minecraft:cobblestone
setblock 289 279 363 minecraft:mossy_cobblestone
fill 290 279 323 290 279 325 minecraft:cobblestone
setblock 290 279 326 minecraft:mossy_cobblestone
fill 290 279 327 290 279 329 minecraft:cobblestone
setblock 290 279 330 minecraft:mossy_cobblestone
fill 290 279 331 290 279 333 minecraft:cobblestone
setblock 290 279 334 minecraft:mossy_cobblestone
fill 290 279 335 290 279 337 minecraft:cobblestone
setblock 290 279 338 minecraft:mossy_cobblestone
fill 290 279 339 290 279 341 minecraft:cobblestone
setblock 290 279 342 minecraft:mossy_cobblestone
fill 290 279 343 290 279 345 minecraft:cobblestone
setblock 290 279 346 minecraft:mossy_cobblestone
fill 290 279 347 290 279 349 minecraft:cobblestone
setblock 290 279 350 minecraft:mossy_cobblestone
fill 290 279 351 290 279 353 minecraft:cobblestone
setblock 290 279 354 minecraft:mossy_cobblestone
fill 290 279 355 292 279 355 minecraft:cobblestone
setblock 290 279 358 minecraft:mossy_cobblestone
fill 290 279 359 292 279 359 minecraft:cobblestone
setblock 290 279 362 minecraft:mossy_cobblestone
fill 290 279 363 292 279 363 minecraft:cobblestone
fill 291 279 323 291 279 324 minecraft:cobblestone
setblock 291 279 325 minecraft:mossy_cobblestone
fill 291 279 326 291 279 328 minecraft:cobblestone
setblock 291 279 329 minecraft:mossy_cobblestone
fill 291 279 330 291 279 332 minecraft:cobblestone
setblock 291 279 333 minecraft:mossy_cobblestone
fill 291 279 334 291 279 336 minecraft:cobblestone
setblock 291 279 337 minecraft:mossy_cobblestone
fill 291 279 338 291 279 340 minecraft:cobblestone
setblock 291 279 341 minecraft:mossy_cobblestone
fill 291 279 342 291 279 344 minecraft:cobblestone
setblock 291 279 345 minecraft:mossy_cobblestone
fill 291 279 346 291 279 348 minecraft:cobblestone
setblock 291 279 349 minecraft:mossy_cobblestone
fill 291 279 350 291 279 352 minecraft:cobblestone
setblock 291 279 353 minecraft:mossy_cobblestone
fill 291 279 354 293 279 354 minecraft:cobblestone
setblock 291 279 357 minecraft:mossy_cobblestone
fill 291 279 358 293 279 358 minecraft:cobblestone
setblock 291 279 361 minecraft:mossy_cobblestone
fill 291 279 362 293 279 362 minecraft:cobblestone
setblock 292 279 323 minecraft:cobblestone
setblock 292 279 324 minecraft:mossy_cobblestone
fill 292 279 325 292 279 327 minecraft:cobblestone
setblock 292 279 328 minecraft:mossy_cobblestone
fill 292 279 329 292 279 331 minecraft:cobblestone
setblock 292 279 332 minecraft:mossy_cobblestone
fill 292 279 333 292 279 335 minecraft:cobblestone
setblock 292 279 336 minecraft:mossy_cobblestone
fill 292 279 337 292 279 339 minecraft:cobblestone
setblock 292 279 340 minecraft:mossy_cobblestone
fill 292 279 341 292 279 343 minecraft:cobblestone
setblock 292 279 344 minecraft:mossy_cobblestone
fill 292 279 345 292 279 347 minecraft:cobblestone
setblock 292 279 348 minecraft:mossy_cobblestone
fill 292 279 349 292 279 351 minecraft:cobblestone
setblock 292 279 352 minecraft:mossy_cobblestone
fill 292 279 353 294 279 353 minecraft:cobblestone
setblock 292 279 356 minecraft:mossy_cobblestone
fill 292 279 357 294 279 357 minecraft:cobblestone
setblock 292 279 360 minecraft:mossy_cobblestone
fill 292 279 361 294 279 361 minecraft:cobblestone
setblock 293 279 323 minecraft:mossy_cobblestone
fill 293 279 324 293 279 326 minecraft:cobblestone
setblock 293 279 327 minecraft:mossy_cobblestone
fill 293 279 328 293 279 330 minecraft:cobblestone
setblock 293 279 331 minecraft:mossy_cobblestone
fill 293 279 332 293 279 334 minecraft:cobblestone
setblock 293 279 335 minecraft:mossy_cobblestone
fill 293 279 336 293 279 338 minecraft:cobblestone
setblock 293 279 339 minecraft:mossy_cobblestone
setblock 293 279 340 minecraft:cobblestone
fill 293 279 341 297 279 341 minecraft:stone_bricks
setblock 293 279 342 minecraft:cobblestone
setblock 293 279 343 minecraft:mossy_cobblestone
fill 293 279 344 293 279 346 minecraft:cobblestone
setblock 293 279 347 minecraft:mossy_cobblestone
fill 293 279 348 293 279 350 minecraft:cobblestone
setblock 293 279 351 minecraft:mossy_cobblestone
fill 293 279 352 295 279 352 minecraft:cobblestone
setblock 293 279 355 minecraft:mossy_cobblestone
fill 293 279 356 295 279 356 minecraft:cobblestone
setblock 293 279 359 minecraft:mossy_cobblestone
fill 293 279 360 295 279 360 minecraft:cobblestone
setblock 293 279 363 minecraft:mossy_cobblestone
fill 294 279 323 294 279 325 minecraft:cobblestone
setblock 294 279 326 minecraft:mossy_cobblestone
fill 294 279 327 294 279 329 minecraft:cobblestone
setblock 294 279 330 minecraft:mossy_cobblestone
fill 294 279 331 294 279 333 minecraft:cobblestone
setblock 294 279 334 minecraft:mossy_cobblestone
fill 294 279 335 294 279 336 minecraft:cobblestone
fill 294 279 337 297 279 340 minecraft:stone_bricks
fill 294 279 342 297 279 345 minecraft:stone_bricks
setblock 294 279 346 minecraft:mossy_cobblestone
fill 294 279 347 294 279 349 minecraft:cobblestone
setblock 294 279 350 minecraft:mossy_cobblestone
fill 294 279 351 296 279 351 minecraft:cobblestone
setblock 294 279 354 minecraft:mossy_cobblestone
fill 294 279 355 296 279 355 minecraft:cobblestone
setblock 294 279 358 minecraft:mossy_cobblestone
fill 294 279 359 296 279 359 minecraft:cobblestone
setblock 294 279 362 minecraft:mossy_cobblestone
fill 294 279 363 296 279 363 minecraft:cobblestone
fill 295 279 323 295 279 324 minecraft:cobblestone
setblock 295 279 325 minecraft:mossy_cobblestone
fill 295 279 326 295 279 328 minecraft:cobblestone
setblock 295 279 329 minecraft:mossy_cobblestone
fill 295 279 330 295 279 332 minecraft:cobblestone
setblock 295 279 333 minecraft:mossy_cobblestone
setblock 295 279 334 minecraft:cobblestone
fill 295 279 335 300 279 336 minecraft:stone_bricks
fill 295 279 346 300 279 347 minecraft:stone_bricks
setblock 295 279 348 minecraft:cobblestone
setblock 295 279 349 minecraft:mossy_cobblestone
fill 295 279 350 297 279 350 minecraft:cobblestone
setblock 295 279 353 minecraft:mossy_cobblestone
fill 295 279 354 297 279 354 minecraft:cobblestone
setblock 295 279 357 minecraft:mossy_cobblestone
fill 295 279 358 297 279 358 minecraft:cobblestone
setblock 295 279 361 minecraft:mossy_cobblestone
fill 295 279 362 297 279 362 minecraft:cobblestone
setblock 296 279 323 minecraft:cobblestone
setblock 296 279 324 minecraft:mossy_cobblestone
fill 296 279 325 296 279 327 minecraft:cobblestone
setblock 296 279 328 minecraft:mossy_cobblestone
fill 296 279 329 296 279 331 minecraft:cobblestone
setblock 296 279 332 minecraft:mossy_cobblestone
setblock 296 279 333 minecraft:cobblestone
setblock 296 279 349 minecraft:cobblestone
setblock 296 279 352 minecraft:mossy_cobblestone
fill 296 279 353 298 279 353 minecraft:cobblestone
setblock 296 279 356 minecraft:mossy_cobblestone
fill 296 279 357 298 279 357 minecraft:cobblestone
setblock 296 279 360 minecraft:mossy_cobblestone
fill 296 279 361 298 279 361 minecraft:cobblestone
setblock 297 279 323 minecraft:mossy_cobblestone
fill 297 279 324 297 279 326 minecraft:cobblestone
setblock 297 279 327 minecraft:mossy_cobblestone
fill 297 279 328 297 279 330 minecraft:cobblestone
setblock 297 279 331 minecraft:mossy_cobblestone
setblock 297 279 332 minecraft:cobblestone
setblock 297 279 351 minecraft:mossy_cobblestone
fill 297 279 352 299 279 352 minecraft:cobblestone
setblock 297 279 355 minecraft:mossy_cobblestone
fill 297 279 356 299 279 356 minecraft:cobblestone
setblock 297 279 359 minecraft:mossy_cobblestone
fill 297 279 360 299 279 360 minecraft:cobblestone
setblock 297 279 363 minecraft:mossy_cobblestone
fill 298 279 323 298 279 325 minecraft:cobblestone
setblock 298 279 326 minecraft:mossy_cobblestone
fill 298 279 327 298 279 329 minecraft:cobblestone
setblock 298 279 330 minecraft:mossy_cobblestone
fill 298 279 331 299 279 331 minecraft:cobblestone
fill 298 279 337 298 279 339 minecraft:stone_bricks
fill 298 279 340 298 279 342 minecraft:cobblestone
fill 298 279 343 298 279 345 minecraft:stone_bricks
fill 298 279 351 299 279 351 minecraft:cobblestone
setblock 298 279 354 minecraft:mossy_cobblestone
fill 298 279 355 300 279 355 minecraft:cobblestone
setblock 298 279 358 minecraft:mossy_cobblestone
fill 298 279 359 300 279 359 minecraft:cobblestone
setblock 298 279 362 minecraft:mossy_cobblestone
fill 298 279 363 300 279 363 minecraft:cobblestone
fill 299 279 323 299 279 324 minecraft:cobblestone
setblock 299 279 325 minecraft:mossy_cobblestone
fill 299 279 326 299 279 328 minecraft:cobblestone
setblock 299 279 329 minecraft:mossy_cobblestone
fill 299 279 330 301 279 330 minecraft:cobblestone
fill 299 279 337 314 279 337 minecraft:stone_bricks
setblock 299 279 338 minecraft:cobblestone
fill 299 279 339 300 279 343 minecraft:stone_bricks
setblock 299 279 344 minecraft:cobblestone
fill 299 279 345 314 279 345 minecraft:stone_bricks
setblock 299 279 353 minecraft:mossy_cobblestone
fill 299 279 354 301 279 354 minecraft:cobblestone
setblock 299 279 357 minecraft:mossy_cobblestone
fill 299 279 358 301 279 358 minecraft:cobblestone
setblock 299 279 361 minecraft:mossy_cobblestone
fill 299 279 362 301 279 362 minecraft:cobblestone
setblock 300 279 323 minecraft:cobblestone
setblock 300 279 324 minecraft:mossy_cobblestone
fill 300 279 325 300 279 327 minecraft:cobblestone
setblock 300 279 328 minecraft:mossy_cobblestone
fill 300 279 329 302 279 329 minecraft:cobblestone
fill 300 279 338 301 279 338 minecraft:stone_bricks
fill 300 279 344 301 279 344 minecraft:stone_bricks
setblock 300 279 352 minecraft:mossy_cobblestone
fill 300 279 353 302 279 353 minecraft:cobblestone
setblock 300 279 356 minecraft:mossy_cobblestone
fill 300 279 357 302 279 357 minecraft:cobblestone
setblock 300 279 360 minecraft:mossy_cobblestone
fill 300 279 361 302 279 361 minecraft:cobblestone
setblock 301 279 323 minecraft:mossy_cobblestone
fill 301 279 324 301 279 326 minecraft:cobblestone
setblock 301 279 327 minecraft:mossy_cobblestone
fill 301 279 328 303 279 328 minecraft:cobblestone
fill 301 279 335 302 279 335 minecraft:stone_bricks
setblock 301 279 336 minecraft:cobblestone
fill 301 279 339 301 279 343 minecraft:shroomlight
setblock 301 279 346 minecraft:cobblestone
fill 301 279 347 302 279 347 minecraft:stone_bricks
fill 301 279 352 303 279 352 minecraft:cobblestone
setblock 301 279 355 minecraft:mossy_cobblestone
fill 301 279 356 303 279 356 minecraft:cobblestone
setblock 301 279 359 minecraft:mossy_cobblestone
fill 301 279 360 303 279 360 minecraft:cobblestone
setblock 301 279 363 minecraft:mossy_cobblestone
fill 302 279 323 302 279 325 minecraft:cobblestone
setblock 302 279 326 minecraft:mossy_cobblestone
fill 302 279 327 304 279 327 minecraft:cobblestone
setblock 302 279 330 minecraft:mossy_cobblestone
fill 302 279 336 306 279 336 minecraft:stone_bricks
fill 302 279 338 302 279 339 minecraft:shroomlight
fill 302 279 343 302 279 344 minecraft:shroomlight
fill 302 279 346 306 279 346 minecraft:stone_bricks
setblock 302 279 354 minecraft:mossy_cobblestone
fill 302 279 355 304 279 355 minecraft:cobblestone
setblock 302 279 358 minecraft:mossy_cobblestone
fill 302 279 359 304 279 359 minecraft:cobblestone
setblock 302 279 362 minecraft:mossy_cobblestone
fill 302 279 363 304 279 363 minecraft:cobblestone
fill 303 279 323 303 279 324 minecraft:cobblestone
setblock 303 279 325 minecraft:mossy_cobblestone
fill 303 279 326 305 279 326 minecraft:cobblestone
setblock 303 279 329 minecraft:mossy_cobblestone
setblock 303 279 330 minecraft:cobblestone
fill 303 279 335 305 279 335 minecraft:cobblestone
fill 303 279 338 306 279 338 minecraft:shroomlight
fill 303 279 344 306 279 344 minecraft:shroomlight
fill 303 279 347 305 279 347 minecraft:cobblestone
setblock 303 279 353 minecraft:mossy_cobblestone
fill 303 279 354 305 279 354 minecraft:cobblestone
setblock 303 279 357 minecraft:mossy_cobblestone
fill 303 279 358 305 279 358 minecraft:cobblestone
setblock 303 279 361 minecraft:mossy_cobblestone
fill 303 279 362 305 279 362 minecraft:cobblestone
setblock 304 279 323 minecraft:cobblestone
setblock 304 279 324 minecraft:mossy_cobblestone
fill 304 279 325 306 279 325 minecraft:cobblestone
setblock 304 279 328 minecraft:mossy_cobblestone
fill 304 279 329 306 279 329 minecraft:cobblestone
fill 304 279 353 306 279 353 minecraft:cobblestone
setblock 304 279 356 minecraft:mossy_cobblestone
fill 304 279 357 306 279 357 minecraft:cobblestone
setblock 304 279 360 minecraft:mossy_cobblestone
fill 304 279 361 306 279 361 minecraft:cobblestone
setblock 305 279 323 minecraft:mossy_cobblestone
fill 305 279 324 307 279 324 minecraft:cobblestone
setblock 305 279 327 minecraft:mossy_cobblestone
fill 305 279 328 307 279 328 minecraft:cobblestone
setblock 305 279 330 minecraft:cobblestone
fill 305 279 352 307 279 352 minecraft:cobblestone
setblock 305 279 355 minecraft:mossy_cobblestone
fill 305 279 356 307 279 356 minecraft:cobblestone
setblock 305 279 359 minecraft:mossy_cobblestone
fill 305 279 360 307 279 360 minecraft:cobblestone
setblock 305 279 363 minecraft:mossy_cobblestone
fill 306 279 323 308 279 323 minecraft:cobblestone
setblock 306 279 326 minecraft:mossy_cobblestone
fill 306 279 327 308 279 327 minecraft:cobblestone
setblock 306 279 330 minecraft:mossy_cobblestone
fill 306 279 335 313 279 335 minecraft:stone_bricks
fill 306 279 339 307 279 339 minecraft:shroomlight
fill 306 279 343 307 279 343 minecraft:shroomlight
fill 306 279 347 313 279 347 minecraft:stone_bricks
setblock 306 279 354 minecraft:mossy_cobblestone
fill 306 279 355 308 279 355 minecraft:cobblestone
setblock 306 279 358 minecraft:mossy_cobblestone
fill 306 279 359 308 279 359 minecraft:cobblestone
setblock 306 279 362 minecraft:mossy_cobblestone
fill 306 279 363 308 279 363 minecraft:cobblestone
setblock 307 279 325 minecraft:mossy_cobblestone
fill 307 279 326 309 279 326 minecraft:cobblestone
setblock 307 279 329 minecraft:mossy_cobblestone
fill 307 279 330 309 279 330 minecraft:cobblestone
setblock 307 279 336 minecraft:cobblestone
fill 307 279 338 308 279 338 minecraft:stone_bricks
fill 307 279 340 307 279 342 minecraft:shroomlight
fill 307 279 344 308 279 344 minecraft:stone_bricks
setblock 307 279 346 minecraft:cobblestone
setblock 307 279 353 minecraft:mossy_cobblestone
fill 307 279 354 309 279 354 minecraft:cobblestone
setblock 307 279 357 minecraft:mossy_cobblestone
fill 307 279 358 309 279 358 minecraft:cobblestone
setblock 307 279 361 minecraft:mossy_cobblestone
fill 307 279 362 309 279 362 minecraft:cobblestone
setblock 308 279 324 minecraft:mossy_cobblestone
fill 308 279 325 310 279 325 minecraft:cobblestone
setblock 308 279 328 minecraft:mossy_cobblestone
fill 308 279 329 310 279 329 minecraft:cobblestone
fill 308 279 336 313 279 336 minecraft:stone_bricks
fill 308 279 339 309 279 343 minecraft:stone_bricks
fill 308 279 346 313 279 346 minecraft:stone_bricks
setblock 308 279 352 minecraft:mossy_cobblestone
fill 308 279 353 310 279 353 minecraft:cobblestone
setblock 308 279 356 minecraft:mossy_cobblestone
fill 308 279 357 310 279 357 minecraft:cobblestone
setblock 308 279 360 minecraft:mossy_cobblestone
fill 308 279 361 310 279 361 minecraft:cobblestone
setblock 309 279 323 minecraft:mossy_cobblestone
fill 309 279 324 311 279 324 minecraft:cobblestone
setblock 309 279 327 minecraft:mossy_cobblestone
fill 309 279 328 311 279 328 minecraft:cobblestone
setblock 309 279 331 minecraft:mossy_cobblestone
setblock 309 279 338 minecraft:cobblestone
setblock 309 279 344 minecraft:cobblestone
setblock 309 279 351 minecraft:mossy_cobblestone
fill 309 279 352 311 279 352 minecraft:cobblestone
setblock 309 279 355 minecraft:mossy_cobblestone
fill 309 279 356 311 279 356 minecraft:cobblestone
setblock 309 279 359 minecraft:mossy_cobblestone
fill 309 279 360 311 279 360 minecraft:cobblestone
setblock 309 279 363 minecraft:mossy_cobblestone
fill 310 279 323 312 279 323 minecraft:cobblestone
setblock 310 279 326 minecraft:mossy_cobblestone
fill 310 279 327 312 279 327 minecraft:cobblestone
setblock 310 279 330 minecraft:mossy_cobblestone
fill 310 279 331 312 279 331 minecraft:cobblestone
fill 310 279 338 314 279 339 minecraft:stone_bricks
fill 310 279 340 310 279 342 minecraft:cobblestone
fill 310 279 343 314 279 344 minecraft:stone_bricks
fill 310 279 351 312 279 351 minecraft:cobblestone
setblock 310 279 354 minecraft:mossy_cobblestone
fill 310 279 355 312 279 355 minecraft:cobblestone
setblock 310 279 358 minecraft:mossy_cobblestone
fill 310 279 359 312 279 359 minecraft:cobblestone
setblock 310 279 362 minecraft:mossy_cobblestone
fill 310 279 363 312 279 363 minecraft:cobblestone
setblock 311 279 325 minecraft:mossy_cobblestone
fill 311 279 326 313 279 326 minecraft:cobblestone
setblock 311 279 329 minecraft:mossy_cobblestone
fill 311 279 330 313 279 330 minecraft:cobblestone
setblock 311 279 332 minecraft:cobblestone
fill 311 279 340 314 279 342 minecraft:stone_bricks
fill 311 279 350 313 279 350 minecraft:cobblestone
setblock 311 279 353 minecraft:mossy_cobblestone
fill 311 279 354 313 279 354 minecraft:cobblestone
setblock 311 279 357 minecraft:mossy_cobblestone
fill 311 279 358 313 279 358 minecraft:cobblestone
setblock 311 279 361 minecraft:mossy_cobblestone
fill 311 279 362 313 279 362 minecraft:cobblestone
setblock 312 279 324 minecraft:mossy_cobblestone
fill 312 279 325 314 279 325 minecraft:cobblestone
setblock 312 279 328 minecraft:mossy_cobblestone
fill 312 279 329 314 279 329 minecraft:cobblestone
setblock 312 279 332 minecraft:mossy_cobblestone
fill 312 279 333 314 279 333 minecraft:cobblestone
fill 312 279 349 314 279 349 minecraft:cobblestone
setblock 312 279 352 minecraft:mossy_cobblestone
fill 312 279 353 314 279 353 minecraft:cobblestone
setblock 312 279 356 minecraft:mossy_cobblestone
fill 312 279 357 314 279 357 minecraft:cobblestone
setblock 312 279 360 minecraft:mossy_cobblestone
fill 312 279 361 314 279 361 minecraft:cobblestone
setblock 313 279 323 minecraft:mossy_cobblestone
fill 313 279 324 315 279 324 minecraft:cobblestone
setblock 313 279 327 minecraft:mossy_cobblestone
fill 313 279 328 315 279 328 minecraft:cobblestone
setblock 313 279 331 minecraft:mossy_cobblestone
fill 313 279 332 315 279 332 minecraft:cobblestone
setblock 313 279 334 minecraft:cobblestone
fill 313 279 348 315 279 348 minecraft:cobblestone
setblock 313 279 351 minecraft:mossy_cobblestone
fill 313 279 352 315 279 352 minecraft:cobblestone
setblock 313 279 355 minecraft:mossy_cobblestone
fill 313 279 356 315 279 356 minecraft:cobblestone
setblock 313 279 359 minecraft:mossy_cobblestone
fill 313 279 360 315 279 360 minecraft:cobblestone
setblock 313 279 363 minecraft:mossy_cobblestone
fill 314 279 323 316 279 323 minecraft:cobblestone
setblock 314 279 326 minecraft:mossy_cobblestone
fill 314 279 327 316 279 327 minecraft:cobblestone
setblock 314 279 330 minecraft:mossy_cobblestone
fill 314 279 331 316 279 331 minecraft:cobblestone
setblock 314 279 334 minecraft:mossy_cobblestone
fill 314 279 335 315 279 336 minecraft:cobblestone
setblock 314 279 346 minecraft:mossy_cobblestone
fill 314 279 347 316 279 347 minecraft:cobblestone
setblock 314 279 350 minecraft:mossy_cobblestone
fill 314 279 351 316 279 351 minecraft:cobblestone
setblock 314 279 354 minecraft:mossy_cobblestone
fill 314 279 355 316 279 355 minecraft:cobblestone
setblock 314 279 358 minecraft:mossy_cobblestone
fill 314 279 359 316 279 359 minecraft:cobblestone
setblock 314 279 362 minecraft:mossy_cobblestone
fill 314 279 363 316 279 363 minecraft:cobblestone
setblock 315 279 325 minecraft:mossy_cobblestone
fill 315 279 326 317 279 326 minecraft:cobblestone
setblock 315 279 329 minecraft:mossy_cobblestone
fill 315 279 330 317 279 330 minecraft:cobblestone
setblock 315 279 333 minecraft:mossy_cobblestone
fill 315 279 334 317 279 334 minecraft:cobblestone
setblock 315 279 337 minecraft:mossy_cobblestone
fill 315 279 338 315 279 340 minecraft:cobblestone
fill 315 279 342 315 279 344 minecraft:cobblestone
setblock 315 279 345 minecraft:mossy_cobblestone
fill 315 279 346 317 279 346 minecraft:cobblestone
setblock 315 279 349 minecraft:mossy_cobblestone
fill 315 279 350 317 279 350 minecraft:cobblestone
setblock 315 279 353 minecraft:mossy_cobblestone
fill 315 279 354 317 279 354 minecraft:cobblestone
setblock 315 279 357 minecraft:mossy_cobblestone
fill 315 279 358 317 279 358 minecraft:cobblestone
setblock 315 279 361 minecraft:mossy_cobblestone
fill 315 279 362 317 279 362 minecraft:cobblestone
setblock 316 279 324 minecraft:mossy_cobblestone
fill 316 279 325 318 279 325 minecraft:cobblestone
setblock 316 279 328 minecraft:mossy_cobblestone
fill 316 279 329 318 279 329 minecraft:cobblestone
setblock 316 279 332 minecraft:mossy_cobblestone
fill 316 279 333 318 279 333 minecraft:cobblestone
setblock 316 279 335 minecraft:cobblestone
setblock 316 279 336 minecraft:mossy_cobblestone
fill 316 279 337 316 279 339 minecraft:cobblestone
setblock 316 279 340 minecraft:mossy_cobblestone
fill 316 279 341 316 279 343 minecraft:cobblestone
setblock 316 279 344 minecraft:mossy_cobblestone
fill 316 279 345 318 279 345 minecraft:cobblestone
setblock 316 279 348 minecraft:mossy_cobblestone
fill 316 279 349 318 279 349 minecraft:cobblestone
setblock 316 279 352 minecraft:mossy_cobblestone
fill 316 279 353 318 279 353 minecraft:cobblestone
setblock 316 279 356 minecraft:mossy_cobblestone
fill 316 279 357 318 279 357 minecraft:cobblestone
setblock 316 279 360 minecraft:mossy_cobblestone
fill 316 279 361 318 279 361 minecraft:cobblestone
setblock 317 279 323 minecraft:mossy_cobblestone
fill 317 279 324 319 279 324 minecraft:cobblestone
setblock 317 279 327 minecraft:mossy_cobblestone
fill 317 279 328 319 279 328 minecraft:cobblestone
setblock 317 279 331 minecraft:mossy_cobblestone
fill 317 279 332 319 279 332 minecraft:cobblestone
setblock 317 279 335 minecraft:mossy_cobblestone
fill 317 279 336 317 279 338 minecraft:cobblestone
setblock 317 279 339 minecraft:mossy_cobblestone
fill 317 279 340 317 279 342 minecraft:cobblestone
setblock 317 279 343 minecraft:mossy_cobblestone
fill 317 279 344 319 279 344 minecraft:cobblestone
setblock 317 279 347 minecraft:mossy_cobblestone
fill 317 279 348 319 279 348 minecraft:cobblestone
setblock 317 279 351 minecraft:mossy_cobblestone
fill 317 279 352 319 279 352 minecraft:cobblestone
setblock 317 279 355 minecraft:mossy_cobblestone
fill 317 279 356 319 279 356 minecraft:cobblestone
setblock 317 279 359 minecraft:mossy_cobblestone
fill 317 279 360 319 279 360 minecraft:cobblestone
setblock 317 279 363 minecraft:mossy_cobblestone
fill 318 279 323 320 279 323 minecraft:cobblestone
setblock 318 279 326 minecraft:mossy_cobblestone
fill 318 279 327 320 279 327 minecraft:cobblestone
setblock 318 279 330 minecraft:mossy_cobblestone
fill 318 279 331 320 279 331 minecraft:cobblestone
setblock 318 279 334 minecraft:mossy_cobblestone
fill 318 279 335 318 279 337 minecraft:cobblestone
setblock 318 279 338 minecraft:mossy_cobblestone
fill 318 279 339 318 279 341 minecraft:cobblestone
setblock 318 279 342 minecraft:mossy_cobblestone
fill 318 279 343 320 279 343 minecraft:cobblestone
setblock 318 279 346 minecraft:mossy_cobblestone
fill 318 279 347 320 279 347 minecraft:cobblestone
setblock 318 279 350 minecraft:mossy_cobblestone
fill 318 279 351 320 279 351 minecraft:cobblestone
setblock 318 279 354 minecraft:mossy_cobblestone
fill 318 279 355 320 279 355 minecraft:cobblestone
setblock 318 279 358 minecraft:mossy_cobblestone
fill 318 279 359 320 279 359 minecraft:cobblestone
setblock 318 279 362 minecraft:mossy_cobblestone
fill 318 279 363 320 279 363 minecraft:cobblestone
setblock 319 279 325 minecraft:mossy_cobblestone
fill 319 279 326 321 279 326 minecraft:cobblestone
setblock 319 279 329 minecraft:mossy_cobblestone
fill 319 279 330 321 279 330 minecraft:cobblestone
setblock 319 279 333 minecraft:mossy_cobblestone
fill 319 279 334 319 279 336 minecraft:cobblestone
setblock 319 279 337 minecraft:mossy_cobblestone
fill 319 279 338 319 279 340 minecraft:cobblestone
setblock 319 279 341 minecraft:mossy_cobblestone
fill 319 279 342 321 279 342 minecraft:cobblestone
setblock 319 279 345 minecraft:mossy_cobblestone
fill 319 279 346 321 279 346 minecraft:cobblestone
setblock 319 279 349 minecraft:mossy_cobblestone
fill 319 279 350 321 279 350 minecraft:cobblestone
setblock 319 279 353 minecraft:mossy_cobblestone
fill 319 279 354 321 279 354 minecraft:cobblestone
setblock 319 279 357 minecraft:mossy_cobblestone
fill 319 279 358 321 279 358 minecraft:cobblestone
setblock 319 279 361 minecraft:mossy_cobblestone
fill 319 279 362 321 279 362 minecraft:cobblestone
setblock 320 279 324 minecraft:mossy_cobblestone
fill 320 279 325 322 279 325 minecraft:cobblestone
setblock 320 279 328 minecraft:mossy_cobblestone
fill 320 279 329 322 279 329 minecraft:cobblestone
setblock 320 279 332 minecraft:mossy_cobblestone
fill 320 279 333 320 279 335 minecraft:cobblestone
setblock 320 279 336 minecraft:mossy_cobblestone
fill 320 279 337 320 279 339 minecraft:cobblestone
setblock 320 279 340 minecraft:mossy_cobblestone
fill 320 279 341 322 279 341 minecraft:cobblestone
setblock 320 279 344 minecraft:mossy_cobblestone
fill 320 279 345 322 279 345 minecraft:cobblestone
setblock 320 279 348 minecraft:mossy_cobblestone
fill 320 279 349 322 279 349 minecraft:cobblestone
setblock 320 279 352 minecraft:mossy_cobblestone
fill 320 279 353 322 279 353 minecraft:cobblestone
setblock 320 279 356 minecraft:mossy_cobblestone
fill 320 279 357 322 279 357 minecraft:cobblestone
setblock 320 279 360 minecraft:mossy_cobblestone
fill 320 279 361 322 279 361 minecraft:cobblestone
setblock 321 279 323 minecraft:mossy_cobblestone
fill 321 279 324 323 279 324 minecraft:cobblestone
setblock 321 279 327 minecraft:mossy_cobblestone
fill 321 279 328 323 279 328 minecraft:cobblestone
setblock 321 279 331 minecraft:mossy_cobblestone
fill 321 279 332 321 279 334 minecraft:cobblestone
setblock 321 279 335 minecraft:mossy_cobblestone
fill 321 279 336 321 279 338 minecraft:cobblestone
setblock 321 279 339 minecraft:mossy_cobblestone
fill 321 279 340 323 279 340 minecraft:cobblestone
setblock 321 279 343 minecraft:mossy_cobblestone
fill 321 279 344 323 279 344 minecraft:cobblestone
setblock 321 279 347 minecraft:mossy_cobblestone
fill 321 279 348 323 279 348 minecraft:cobblestone
setblock 321 279 351 minecraft:mossy_cobblestone
fill 321 279 352 323 279 352 minecraft:cobblestone
setblock 321 279 355 minecraft:mossy_cobblestone
fill 321 279 356 323 279 356 minecraft:cobblestone
setblock 321 279 359 minecraft:mossy_cobblestone
fill 321 279 360 323 279 360 minecraft:cobblestone
setblock 321 279 363 minecraft:mossy_cobblestone
fill 322 279 323 323 279 323 minecraft:cobblestone
setblock 322 279 326 minecraft:mossy_cobblestone
fill 322 279 327 323 279 327 minecraft:cobblestone
setblock 322 279 330 minecraft:mossy_cobblestone
fill 322 279 331 322 279 333 minecraft:cobblestone
setblock 322 279 334 minecraft:mossy_cobblestone
fill 322 279 335 322 279 337 minecraft:cobblestone
setblock 322 279 338 minecraft:mossy_cobblestone
fill 322 279 339 323 279 339 minecraft:cobblestone
setblock 322 279 342 minecraft:mossy_cobblestone
fill 322 279 343 323 279 343 minecraft:cobblestone
setblock 322 279 346 minecraft:mossy_cobblestone
fill 322 279 347 323 279 347 minecraft:cobblestone
setblock 322 279 350 minecraft:mossy_cobblestone
fill 322 279 351 323 279 351 minecraft:cobblestone
setblock 322 279 354 minecraft:mossy_cobblestone
fill 322 279 355 323 279 355 minecraft:cobblestone
setblock 322 279 358 minecraft:mossy_cobblestone
fill 322 279 359 323 279 359 minecraft:cobblestone
setblock 322 279 362 minecraft:mossy_cobblestone
fill 322 279 363 323 279 363 minecraft:cobblestone
setblock 323 279 325 minecraft:mossy_cobblestone
setblock 323 279 326 minecraft:cobblestone
setblock 323 279 329 minecraft:mossy_cobblestone
fill 323 279 330 323 279 332 minecraft:cobblestone
setblock 323 279 333 minecraft:mossy_cobblestone
fill 323 279 334 323 279 336 minecraft:cobblestone
setblock 323 279 337 minecraft:mossy_cobblestone
setblock 323 279 338 minecraft:cobblestone
setblock 323 279 341 minecraft:mossy_cobblestone
setblock 323 279 342 minecraft:cobblestone
setblock 323 279 345 minecraft:mossy_cobblestone
setblock 323 279 346 minecraft:cobblestone
setblock 323 279 349 minecraft:mossy_cobblestone
setblock 323 279 350 minecraft:cobblestone
setblock 323 279 353 minecraft:mossy_cobblestone
setblock 323 279 354 minecraft:cobblestone
setblock 323 279 357 minecraft:mossy_cobblestone
setblock 323 279 358 minecraft:cobblestone
setblock 323 279 361 minecraft:mossy_cobblestone
setblock 323 279 362 minecraft:cobblestone
fill 293 280 341 293 281 341 minecraft:stone_bricks
fill 294 280 338 294 281 340 minecraft:stone_bricks
fill 294 280 345 294 281 345 minecraft:stone_bricks
fill 295 280 346 295 281 347 minecraft:stone_bricks
fill 296 280 334 296 281 334 minecraft:stone_bricks
fill 297 280 333 297 281 333 minecraft:stone_bricks
fill 298 280 350 299 281 350 minecraft:stone_bricks
fill 300 280 351 300 281 351 minecraft:stone_bricks
fill 301 280 331 303 281 331 minecraft:stone_bricks
fill 305 280 351 307 281 351 minecraft:stone_bricks
fill 308 280 331 308 281 331 minecraft:stone_bricks
fill 309 280 332 310 281 332 minecraft:stone_bricks
fill 311 280 349 311 281 349 minecraft:stone_bricks
fill 312 280 348 312 281 348 minecraft:stone_bricks
fill 313 280 335 313 281 336 minecraft:stone_bricks
fill 314 280 337 314 281 337 minecraft:stone_bricks
fill 314 280 342 314 281 344 minecraft:stone_bricks
fill 283 283 323 285 300 323 minecraft:polished_andesite
fill 283 283 325 289 284 342 minecraft:polished_andesite
fill 283 283 345 283 284 359 minecraft:polished_andesite
fill 284 283 344 284 285 358 minecraft:polished_andesite
fill 285 283 347 286 285 357 minecraft:polished_andesite
setblock 286 283 360 minecraft:shroomlight
fill 289 283 363 291 300 363 minecraft:polished_andesite
setblock 290 283 326 minecraft:shroomlight
fill 290 283 362 292 285 362 minecraft:polished_andesite
setblock 292 283 360 minecraft:shroomlight
fill 294 283 324 296 285 324 minecraft:polished_andesite
setblock 294 283 362 minecraft:cobblestone
fill 295 283 323 297 300 323 minecraft:polished_andesite
setblock 296 283 326 minecraft:shroomlight
setblock 298 283 360 minecraft:shroomlight
fill 301 283 363 303 300 363 minecraft:polished_andesite
setblock 302 283 326 minecraft:shroomlight
fill 302 283 362 304 285 362 minecraft:polished_andesite
setblock 304 283 360 minecraft:shroomlight
fill 306 283 324 308 285 324 minecraft:polished_andesite
fill 307 283 323 309 300 323 minecraft:polished_andesite
setblock 308 283 326 minecraft:shroomlight
setblock 310 283 360 minecraft:shroomlight
setblock 313 283 323 minecraft:cobblestone
fill 313 283 340 323 284 346 minecraft:polished_andesite
fill 313 283 351 323 284 357 minecraft:polished_andesite
fill 313 283 363 323 284 363 minecraft:polished_andesite
setblock 314 283 326 minecraft:shroomlight
fill 314 283 358 323 284 362 minecraft:polished_andesite
fill 318 283 324 320 285 324 minecraft:polished_andesite
fill 319 283 323 321 300 323 minecraft:polished_andesite
setblock 320 283 326 minecraft:shroomlight
setblock 320 283 332 minecraft:shroomlight
setblock 320 283 338 minecraft:shroomlight
setblock 320 283 350 minecraft:shroomlight
fill 322 283 332 322 285 334 minecraft:polished_andesite
setblock 322 283 335 minecraft:cobblestone
fill 323 283 331 323 300 333 minecraft:polished_andesite
fill 283 284 324 293 284 324 minecraft:polished_andesite
fill 283 284 343 283 284 344 minecraft:polished_andesite
fill 283 284 360 288 284 363 minecraft:polished_andesite
fill 284 284 343 286 284 343 minecraft:polished_andesite
fill 284 284 359 286 284 359 minecraft:polished_andesite
fill 285 284 344 286 284 346 minecraft:polished_andesite
fill 285 284 358 286 284 358 minecraft:polished_andesite
fill 286 284 323 294 284 323 minecraft:polished_andesite
fill 289 284 360 289 284 362 minecraft:polished_andesite
fill 290 284 325 323 284 326 minecraft:polished_andesite
fill 290 284 360 313 284 361 minecraft:polished_andesite
fill 292 284 363 300 284 363 minecraft:polished_andesite
fill 293 284 362 301 284 362 minecraft:polished_andesite
fill 297 284 324 305 284 324 minecraft:polished_andesite
fill 298 284 323 306 284 323 minecraft:polished_andesite
fill 304 284 363 312 284 363 minecraft:polished_andesite
fill 305 284 362 313 284 362 minecraft:polished_andesite
fill 309 284 324 317 284 324 minecraft:polished_andesite
fill 310 284 323 318 284 323 minecraft:polished_andesite
fill 320 284 327 321 284 339 minecraft:polished_andesite
fill 320 284 347 323 284 350 minecraft:polished_andesite
fill 321 284 324 323 284 324 minecraft:polished_andesite
fill 322 284 323 323 284 323 minecraft:polished_andesite
fill 322 284 327 322 284 331 minecraft:polished_andesite
fill 322 284 335 323 284 339 minecraft:polished_andesite
fill 323 284 327 323 284 330 minecraft:polished_andesite
setblock 323 284 334 minecraft:polished_andesite
fill 283 285 325 289 285 325 minecraft:polished_andesite
fill 283 285 326 283 285 331 minecraft:cobblestone
fill 283 285 332 289 285 337 minecraft:polished_andesite
fill 283 285 338 283 285 343 minecraft:cobblestone
fill 283 285 345 283 285 349 minecraft:polished_andesite
fill 283 285 350 283 285 355 minecraft:cobblestone
fill 283 285 356 283 285 359 minecraft:polished_andesite
fill 283 285 362 283 285 363 minecraft:cobblestone
fill 284 285 326 289 285 331 minecraft:polished_andesite
fill 284 285 338 289 285 342 minecraft:polished_andesite
fill 284 285 363 287 285 363 minecraft:cobblestone
setblock 285 285 346 minecraft:light[level=12]
setblock 285 285 360 minecraft:light[level=12]
fill 286 285 343 286 285 346 minecraft:red_wool
fill 286 285 358 286 285 360 minecraft:red_wool
fill 287 285 323 292 285 323 minecraft:cobblestone
fill 287 285 360 313 285 360 minecraft:red_wool
fill 290 285 326 320 285 326 minecraft:red_wool
fill 290 285 361 290 295 361 minecraft:red_wool
setblock 292 285 325 minecraft:light[level=12]
setblock 292 285 332 minecraft:light[level=12]
setblock 292 285 339 minecraft:light[level=12]
setblock 292 285 346 minecraft:light[level=12]
setblock 292 285 353 minecraft:light[level=12]
fill 294 285 363 299 285 363 minecraft:cobblestone
fill 299 285 323 304 285 323 minecraft:cobblestone
setblock 299 285 325 minecraft:light[level=12]
setblock 299 285 332 minecraft:light[level=12]
setblock 299 285 339 minecraft:light[level=12]
setblock 299 285 346 minecraft:light[level=12]
setblock 299 285 353 minecraft:light[level=12]
setblock 306 285 325 minecraft:light[level=12]
setblock 306 285 332 minecraft:light[level=12]
setblock 306 285 339 minecraft:light[level=12]
setblock 306 285 346 minecraft:light[level=12]
setblock 306 285 353 minecraft:light[level=12]
fill 306 285 363 311 285 363 minecraft:cobblestone
fill 311 285 323 316 285 323 minecraft:cobblestone
setblock 313 285 325 minecraft:light[level=12]
setblock 313 285 332 minecraft:light[level=12]
setblock 313 285 339 minecraft:light[level=12]
fill 313 285 340 322 285 346 minecraft:polished_andesite
fill 313 285 351 322 285 357 minecraft:polished_andesite
fill 313 285 363 317 285 363 minecraft:polished_andesite
fill 314 285 358 322 285 362 minecraft:polished_andesite
fill 318 285 363 323 285 363 minecraft:cobblestone
setblock 320 285 325 minecraft:light[level=12]
fill 320 285 327 320 285 339 minecraft:red_wool
fill 320 285 347 320 285 350 minecraft:red_wool
fill 323 285 323 323 285 328 minecraft:cobblestone
fill 323 285 335 323 285 340 minecraft:cobblestone
fill 323 285 341 323 285 346 minecraft:polished_andesite
fill 323 285 347 323 285 352 minecraft:cobblestone
fill 323 285 353 323 285 358 minecraft:polished_andesite
fill 323 285 359 323 285 362 minecraft:cobblestone
fill 282 286 328 282 291 331 minecraft:shroomlight
fill 282 286 340 282 291 343 minecraft:shroomlight
fill 282 286 352 282 291 355 minecraft:shroomlight
fill 282 286 364 285 291 364 minecraft:shroomlight
setblock 283 286 325 minecraft:shroomlight
fill 283 286 326 283 300 326 minecraft:polished_andesite
setblock 283 286 327 minecraft:shroomlight
fill 283 286 328 283 300 328 minecraft:polished_andesite
setblock 283 286 329 minecraft:shroomlight
fill 283 286 330 283 300 330 minecraft:polished_andesite
setblock 283 286 331 minecraft:shroomlight
fill 283 286 332 283 300 332 minecraft:polished_andesite
setblock 283 286 333 minecraft:shroomlight
fill 283 286 334 283 300 334 minecraft:polished_andesite
setblock 283 286 335 minecraft:shroomlight
fill 283 286 336 283 300 336 minecraft:polished_andesite
setblock 283 286 337 minecraft:shroomlight
fill 283 286 338 283 300 338 minecraft:polished_andesite
setblock 283 286 339 minecraft:shroomlight
fill 283 286 340 283 300 340 minecraft:polished_andesite
setblock 283 286 341 minecraft:shroomlight
fill 283 286 342 283 300 342 minecraft:polished_andesite
fill 283 286 345 283 300 346 minecraft:polished_andesite
setblock 283 286 347 minecraft:shroomlight
fill 283 286 348 283 300 348 minecraft:polished_andesite
setblock 283 286 349 minecraft:shroomlight
fill 283 286 350 283 300 350 minecraft:polished_andesite
setblock 283 286 351 minecraft:shroomlight
fill 283 286 352 283 300 352 minecraft:polished_andesite
setblock 283 286 353 minecraft:shroomlight
fill 283 286 354 283 300 354 minecraft:polished_andesite
setblock 283 286 355 minecraft:shroomlight
fill 283 286 356 283 300 356 minecraft:polished_andesite
setblock 283 286 357 minecraft:shroomlight
fill 283 286 358 283 300 359 minecraft:polished_andesite
fill 284 286 325 284 300 325 minecraft:polished_andesite
setblock 284 286 326 minecraft:shroomlight
fill 284 286 327 284 300 327 minecraft:polished_andesite
setblock 284 286 328 minecraft:shroomlight
fill 284 286 329 284 300 329 minecraft:polished_andesite
setblock 284 286 330 minecraft:shroomlight
fill 284 286 331 284 300 331 minecraft:polished_andesite
setblock 284 286 332 minecraft:shroomlight
fill 284 286 333 284 300 333 minecraft:polished_andesite
setblock 284 286 334 minecraft:shroomlight
fill 284 286 335 284 300 335 minecraft:polished_andesite
setblock 284 286 336 minecraft:shroomlight
fill 284 286 337 284 300 337 minecraft:polished_andesite
setblock 284 286 338 minecraft:shroomlight
fill 284 286 339 284 300 339 minecraft:polished_andesite
setblock 284 286 340 minecraft:shroomlight
fill 284 286 341 284 300 341 minecraft:polished_andesite
setblock 284 286 342 minecraft:shroomlight
fill 284 286 347 284 300 347 minecraft:polished_andesite
setblock 284 286 348 minecraft:shroomlight
fill 284 286 349 284 300 349 minecraft:polished_andesite
setblock 284 286 350 minecraft:shroomlight
fill 284 286 351 284 300 351 minecraft:polished_andesite
setblock 284 286 352 minecraft:shroomlight
fill 284 286 353 284 300 353 minecraft:polished_andesite
setblock 284 286 354 minecraft:shroomlight
fill 284 286 355 284 300 355 minecraft:polished_andesite
setblock 284 286 356 minecraft:shroomlight
fill 284 286 357 284 300 357 minecraft:polished_andesite
setblock 285 286 325 minecraft:shroomlight
fill 285 286 326 285 300 326 minecraft:polished_andesite
setblock 285 286 327 minecraft:shroomlight
fill 285 286 328 285 300 328 minecraft:polished_andesite
setblock 285 286 329 minecraft:shroomlight
fill 285 286 330 285 300 330 minecraft:polished_andesite
setblock 285 286 331 minecraft:shroomlight
fill 285 286 332 285 300 332 minecraft:polished_andesite
setblock 285 286 333 minecraft:shroomlight
fill 285 286 334 285 300 334 minecraft:polished_andesite
setblock 285 286 335 minecraft:shroomlight
fill 285 286 336 285 300 336 minecraft:polished_andesite
setblock 285 286 337 minecraft:shroomlight
fill 285 286 338 285 300 338 minecraft:polished_andesite
setblock 285 286 339 minecraft:shroomlight
fill 285 286 340 285 300 340 minecraft:polished_andesite
setblock 285 286 341 minecraft:shroomlight
fill 285 286 342 285 300 342 minecraft:polished_andesite
setblock 285 286 347 minecraft:shroomlight
fill 285 286 348 285 300 348 minecraft:polished_andesite
setblock 285 286 349 minecraft:shroomlight
fill 285 286 350 285 300 350 minecraft:polished_andesite
setblock 285 286 351 minecraft:shroomlight
fill 285 286 352 285 300 352 minecraft:polished_andesite
setblock 285 286 353 minecraft:shroomlight
fill 285 286 354 285 300 354 minecraft:polished_andesite
setblock 285 286 355 minecraft:shroomlight
fill 285 286 356 285 300 356 minecraft:polished_andesite
setblock 285 286 357 minecraft:shroomlight
fill 286 286 325 286 300 325 minecraft:polished_andesite
setblock 286 286 326 minecraft:shroomlight
fill 286 286 327 286 300 327 minecraft:polished_andesite
setblock 286 286 328 minecraft:shroomlight
fill 286 286 329 286 300 329 minecraft:polished_andesite
setblock 286 286 330 minecraft:shroomlight
fill 286 286 331 286 300 331 minecraft:polished_andesite
setblock 286 286 332 minecraft:shroomlight
fill 286 286 333 286 300 333 minecraft:polished_andesite
setblock 286 286 334 minecraft:shroomlight
fill 286 286 335 286 300 335 minecraft:polished_andesite
setblock 286 286 336 minecraft:shroomlight
fill 286 286 337 286 300 337 minecraft:polished_andesite
setblock 286 286 338 minecraft:shroomlight
fill 286 286 339 286 300 339 minecraft:polished_andesite
setblock 286 286 340 minecraft:shroomlight
fill 286 286 341 286 300 341 minecraft:polished_andesite
setblock 286 286 342 minecraft:shroomlight
fill 286 286 347 286 300 347 minecraft:polished_andesite
setblock 286 286 348 minecraft:shroomlight
fill 286 286 349 286 300 349 minecraft:polished_andesite
setblock 286 286 350 minecraft:shroomlight
fill 286 286 351 286 300 351 minecraft:polished_andesite
setblock 286 286 352 minecraft:shroomlight
fill 286 286 353 286 300 353 minecraft:polished_andesite
setblock 286 286 354 minecraft:shroomlight
fill 286 286 355 286 300 355 minecraft:polished_andesite
setblock 286 286 356 minecraft:shroomlight
fill 286 286 357 286 300 357 minecraft:polished_andesite
setblock 287 286 325 minecraft:shroomlight
fill 287 286 326 287 300 326 minecraft:polished_andesite
setblock 287 286 327 minecraft:shroomlight
fill 287 286 328 287 300 328 minecraft:polished_andesite
setblock 287 286 329 minecraft:shroomlight
fill 287 286 330 287 300 330 minecraft:polished_andesite
setblock 287 286 331 minecraft:shroomlight
fill 287 286 332 287 300 332 minecraft:polished_andesite
setblock 287 286 333 minecraft:shroomlight
fill 287 286 334 287 300 334 minecraft:polished_andesite
setblock 287 286 335 minecraft:shroomlight
fill 287 286 336 287 300 336 minecraft:polished_andesite
setblock 287 286 337 minecraft:shroomlight
fill 287 286 338 287 300 338 minecraft:polished_andesite
setblock 287 286 339 minecraft:shroomlight
fill 287 286 340 287 300 340 minecraft:polished_andesite
setblock 287 286 341 minecraft:shroomlight
fill 287 286 342 287 300 342 minecraft:polished_andesite
fill 288 286 325 288 300 325 minecraft:polished_andesite
setblock 288 286 326 minecraft:shroomlight
fill 288 286 327 288 300 327 minecraft:polished_andesite
setblock 288 286 328 minecraft:shroomlight
fill 288 286 329 288 300 329 minecraft:polished_andesite
setblock 288 286 330 minecraft:shroomlight
fill 288 286 331 288 300 331 minecraft:polished_andesite
setblock 288 286 332 minecraft:shroomlight
fill 288 286 333 288 300 333 minecraft:polished_andesite
setblock 288 286 334 minecraft:shroomlight
fill 288 286 335 288 300 335 minecraft:polished_andesite
setblock 288 286 336 minecraft:shroomlight
fill 288 286 337 288 300 337 minecraft:polished_andesite
setblock 288 286 338 minecraft:shroomlight
fill 288 286 339 288 300 339 minecraft:polished_andesite
setblock 288 286 340 minecraft:shroomlight
fill 288 286 341 288 300 341 minecraft:polished_andesite
setblock 288 286 342 minecraft:shroomlight
fill 288 286 361 289 295 361 minecraft:red_wool
fill 289 286 322 292 291 322 minecraft:shroomlight
setblock 289 286 325 minecraft:shroomlight
fill 289 286 326 289 300 326 minecraft:polished_andesite
setblock 289 286 327 minecraft:shroomlight
fill 289 286 328 289 300 328 minecraft:polished_andesite
setblock 289 286 329 minecraft:shroomlight
fill 289 286 330 289 300 330 minecraft:polished_andesite
setblock 289 286 331 minecraft:shroomlight
fill 289 286 332 289 300 332 minecraft:polished_andesite
setblock 289 286 333 minecraft:shroomlight
fill 289 286 334 289 300 334 minecraft:polished_andesite
setblock 289 286 335 minecraft:shroomlight
fill 289 286 336 289 300 336 minecraft:polished_andesite
setblock 289 286 337 minecraft:shroomlight
fill 289 286 338 289 300 338 minecraft:polished_andesite
setblock 289 286 339 minecraft:shroomlight
fill 289 286 340 289 300 340 minecraft:polished_andesite
setblock 289 286 341 minecraft:shroomlight
fill 289 286 342 289 300 342 minecraft:polished_andesite
fill 291 286 361 292 295 361 minecraft:red_wool
fill 294 286 364 297 291 364 minecraft:shroomlight
fill 301 286 322 304 291 322 minecraft:shroomlight
fill 306 286 364 309 291 364 minecraft:shroomlight
fill 310 286 364 313 308 364 minecraft:stone_bricks
fill 313 286 322 316 291 322 minecraft:shroomlight
fill 313 286 340 313 300 340 minecraft:polished_andesite
setblock 313 286 341 minecraft:shroomlight
fill 313 286 342 313 300 342 minecraft:polished_andesite
setblock 313 286 343 minecraft:shroomlight
fill 313 286 344 313 300 344 minecraft:polished_andesite
setblock 313 286 345 minecraft:shroomlight
fill 313 286 346 313 300 346 minecraft:polished_andesite
fill 313 286 351 313 297 357 minecraft:polished_andesite
fill 313 286 363 314 300 363 minecraft:polished_andesite
setblock 314 286 340 minecraft:shroomlight
fill 314 286 341 314 300 341 minecraft:polished_andesite
setblock 314 286 342 minecraft:shroomlight
fill 314 286 343 314 300 343 minecraft:polished_andesite
setblock 314 286 344 minecraft:shroomlight
fill 314 286 345 314 300 345 minecraft:polished_andesite
setblock 314 286 346 minecraft:shroomlight
fill 314 286 351 323 297 351 minecraft:polished_andesite
setblock 314 286 352 minecraft:shroomlight
fill 314 286 353 314 300 353 minecraft:polished_andesite
setblock 314 286 354 minecraft:shroomlight
fill 314 286 355 314 300 355 minecraft:polished_andesite
setblock 314 286 356 minecraft:shroomlight
fill 314 286 357 314 300 357 minecraft:polished_andesite
setblock 314 286 358 minecraft:shroomlight
fill 314 286 359 314 300 359 minecraft:polished_andesite
setblock 314 286 360 minecraft:shroomlight
fill 314 286 361 314 300 361 minecraft:polished_andesite
setblock 314 286 362 minecraft:shroomlight
setblock 314 286 364 minecraft:shroomlight
fill 315 286 340 315 300 340 minecraft:polished_andesite
setblock 315 286 341 minecraft:shroomlight
fill 315 286 342 315 300 342 minecraft:polished_andesite
setblock 315 286 343 minecraft:shroomlight
fill 315 286 344 315 300 344 minecraft:polished_andesite
setblock 315 286 345 minecraft:shroomlight
fill 315 286 346 315 300 346 minecraft:polished_andesite
fill 315 286 352 315 300 352 minecraft:polished_andesite
setblock 315 286 353 minecraft:shroomlight
fill 315 286 354 315 300 354 minecraft:polished_andesite
setblock 315 286 355 minecraft:shroomlight
fill 315 286 356 315 300 356 minecraft:polished_andesite
setblock 315 286 357 minecraft:shroomlight
fill 315 286 358 315 300 358 minecraft:polished_andesite
setblock 315 286 359 minecraft:shroomlight
fill 315 286 360 315 300 360 minecraft:polished_andesite
setblock 315 286 361 minecraft:shroomlight
fill 315 286 362 315 300 362 minecraft:polished_andesite
setblock 315 286 363 minecraft:shroomlight
fill 315 286 364 315 308 364 minecraft:stone_bricks
setblock 316 286 340 minecraft:shroomlight
fill 316 286 341 316 300 341 minecraft:polished_andesite
setblock 316 286 342 minecraft:shroomlight
fill 316 286 343 316 300 343 minecraft:polished_andesite
setblock 316 286 344 minecraft:shroomlight
fill 316 286 345 316 300 345 minecraft:polished_andesite
setblock 316 286 346 minecraft:shroomlight
setblock 316 286 352 minecraft:shroomlight
fill 316 286 353 316 300 353 minecraft:polished_andesite
setblock 316 286 354 minecraft:shroomlight
fill 316 286 355 316 300 355 minecraft:polished_andesite
setblock 316 286 356 minecraft:shroomlight
fill 316 286 357 316 300 357 minecraft:polished_andesite
setblock 316 286 358 minecraft:shroomlight
fill 316 286 359 316 300 359 minecraft:polished_andesite
setblock 316 286 360 minecraft:shroomlight
fill 316 286 361 316 300 361 minecraft:polished_andesite
setblock 316 286 362 minecraft:shroomlight
fill 316 286 363 316 300 363 minecraft:polished_andesite
setblock 316 286 364 minecraft:shroomlight
fill 317 286 340 317 300 340 minecraft:polished_andesite
setblock 317 286 341 minecraft:shroomlight
fill 317 286 342 317 300 342 minecraft:polished_andesite
setblock 317 286 343 minecraft:shroomlight
fill 317 286 344 317 300 344 minecraft:polished_andesite
setblock 317 286 345 minecraft:shroomlight
fill 317 286 346 317 300 346 minecraft:polished_andesite
fill 317 286 352 317 300 352 minecraft:polished_andesite
setblock 317 286 353 minecraft:shroomlight
fill 317 286 354 317 300 354 minecraft:polished_andesite
setblock 317 286 355 minecraft:shroomlight
fill 317 286 356 317 300 356 minecraft:polished_andesite
setblock 317 286 357 minecraft:shroomlight
fill 317 286 358 317 300 358 minecraft:polished_andesite
setblock 317 286 359 minecraft:shroomlight
fill 317 286 360 317 300 360 minecraft:polished_andesite
setblock 317 286 361 minecraft:shroomlight
fill 317 286 362 317 300 362 minecraft:polished_andesite
setblock 317 286 363 minecraft:shroomlight
setblock 318 286 340 minecraft:shroomlight
fill 318 286 341 318 300 341 minecraft:polished_andesite
setblock 318 286 342 minecraft:shroomlight
fill 318 286 343 318 300 343 minecraft:polished_andesite
setblock 318 286 344 minecraft:shroomlight
fill 318 286 345 318 300 345 minecraft:polished_andesite
setblock 318 286 346 minecraft:shroomlight
setblock 318 286 352 minecraft:shroomlight
fill 318 286 353 318 300 353 minecraft:polished_andesite
setblock 318 286 354 minecraft:shroomlight
fill 318 286 355 318 300 355 minecraft:polished_andesite
setblock 318 286 356 minecraft:shroomlight
fill 318 286 357 318 300 357 minecraft:polished_andesite
setblock 318 286 358 minecraft:shroomlight
fill 318 286 359 318 300 359 minecraft:polished_andesite
setblock 318 286 360 minecraft:shroomlight
fill 318 286 361 318 300 361 minecraft:polished_andesite
setblock 318 286 362 minecraft:shroomlight
fill 318 286 363 318 300 363 minecraft:polished_andesite
fill 318 286 364 322 286 364 minecraft:shroomlight
fill 319 286 340 319 300 340 minecraft:polished_andesite
setblock 319 286 341 minecraft:shroomlight
fill 319 286 342 319 300 342 minecraft:polished_andesite
setblock 319 286 343 minecraft:shroomlight
fill 319 286 344 319 300 344 minecraft:polished_andesite
setblock 319 286 345 minecraft:shroomlight
fill 319 286 346 319 300 346 minecraft:polished_andesite
fill 319 286 352 319 300 352 minecraft:polished_andesite
setblock 319 286 353 minecraft:shroomlight
fill 319 286 354 319 300 354 minecraft:polished_andesite
setblock 319 286 355 minecraft:shroomlight
fill 319 286 356 319 300 356 minecraft:polished_andesite
setblock 319 286 357 minecraft:shroomlight
fill 319 286 358 319 300 358 minecraft:polished_andesite
setblock 319 286 359 minecraft:shroomlight
fill 319 286 360 319 300 360 minecraft:polished_andesite
setblock 319 286 361 minecraft:shroomlight
fill 319 286 362 319 300 362 minecraft:polished_andesite
setblock 319 286 363 minecraft:shroomlight
setblock 320 286 340 minecraft:shroomlight
fill 320 286 341 320 300 341 minecraft:polished_andesite
setblock 320 286 342 minecraft:shroomlight
fill 320 286 343 320 300 343 minecraft:polished_andesite
setblock 320 286 344 minecraft:shroomlight
fill 320 286 345 320 300 345 minecraft:polished_andesite
setblock 320 286 346 minecraft:shroomlight
setblock 320 286 352 minecraft:shroomlight
fill 320 286 353 320 300 353 minecraft:polished_andesite
setblock 320 286 354 minecraft:shroomlight
fill 320 286 355 320 300 355 minecraft:polished_andesite
setblock 320 286 356 minecraft:shroomlight
fill 320 286 357 320 300 357 minecraft:polished_andesite
setblock 320 286 358 minecraft:shroomlight
fill 320 286 359 320 300 359 minecraft:polished_andesite
setblock 320 286 360 minecraft:shroomlight
fill 320 286 361 320 300 361 minecraft:polished_andesite
setblock 320 286 362 minecraft:shroomlight
fill 320 286 363 320 300 363 minecraft:polished_andesite
fill 321 286 340 321 300 340 minecraft:polished_andesite
setblock 321 286 341 minecraft:shroomlight
fill 321 286 342 321 300 342 minecraft:polished_andesite
setblock 321 286 343 minecraft:shroomlight
fill 321 286 344 321 300 344 minecraft:polished_andesite
setblock 321 286 345 minecraft:shroomlight
fill 321 286 346 321 300 346 minecraft:polished_andesite
fill 321 286 352 321 300 352 minecraft:polished_andesite
setblock 321 286 353 minecraft:shroomlight
fill 321 286 354 321 300 354 minecraft:polished_andesite
setblock 321 286 355 minecraft:shroomlight
fill 321 286 356 321 300 356 minecraft:polished_andesite
setblock 321 286 357 minecraft:shroomlight
fill 321 286 358 321 300 358 minecraft:polished_andesite
setblock 321 286 359 minecraft:shroomlight
fill 321 286 360 321 300 360 minecraft:polished_andesite
setblock 321 286 361 minecraft:shroomlight
fill 321 286 362 321 300 362 minecraft:polished_andesite
setblock 321 286 363 minecraft:shroomlight
setblock 322 286 340 minecraft:shroomlight
fill 322 286 341 322 300 341 minecraft:polished_andesite
setblock 322 286 342 minecraft:shroomlight
fill 322 286 343 322 300 343 minecraft:polished_andesite
setblock 322 286 344 minecraft:shroomlight
fill 322 286 345 322 300 345 minecraft:polished_andesite
setblock 322 286 346 minecraft:shroomlight
setblock 322 286 352 minecraft:shroomlight
fill 322 286 353 322 300 353 minecraft:polished_andesite
setblock 322 286 354 minecraft:shroomlight
fill 322 286 355 322 300 355 minecraft:polished_andesite
setblock 322 286 356 minecraft:shroomlight
fill 322 286 357 322 300 357 minecraft:polished_andesite
setblock 322 286 358 minecraft:shroomlight
fill 322 286 359 322 300 359 minecraft:polished_andesite
setblock 322 286 360 minecraft:shroomlight
fill 322 286 361 322 300 361 minecraft:polished_andesite
setblock 322 286 362 minecraft:shroomlight
fill 322 286 363 322 300 363 minecraft:polished_andesite
fill 323 286 340 323 300 340 minecraft:polished_andesite
setblock 323 286 341 minecraft:shroomlight
fill 323 286 342 323 300 342 minecraft:polished_andesite
setblock 323 286 343 minecraft:shroomlight
fill 323 286 344 323 300 344 minecraft:polished_andesite
setblock 323 286 345 minecraft:shroomlight
fill 323 286 346 323 300 346 minecraft:polished_andesite
fill 323 286 352 323 300 352 minecraft:polished_andesite
setblock 323 286 353 minecraft:shroomlight
fill 323 286 354 323 300 354 minecraft:polished_andesite
setblock 323 286 355 minecraft:shroomlight
fill 323 286 356 323 300 356 minecraft:polished_andesite
setblock 323 286 357 minecraft:shroomlight
fill 323 286 358 323 300 358 minecraft:polished_andesite
fill 323 286 359 324 286 359 minecraft:shroomlight
fill 323 286 360 323 300 360 minecraft:polished_andesite
fill 323 286 361 324 286 361 minecraft:shroomlight
fill 323 286 362 323 300 362 minecraft:polished_andesite
setblock 323 286 363 minecraft:shroomlight
fill 323 286 364 323 308 364 minecraft:stone_bricks
fill 324 286 323 324 291 326 minecraft:shroomlight
fill 324 286 335 324 291 338 minecraft:shroomlight
fill 324 286 347 324 291 350 minecraft:shroomlight
fill 324 286 360 324 292 360 minecraft:shroomlight
fill 324 286 362 324 291 362 minecraft:shroomlight
fill 283 287 325 283 288 325 minecraft:polished_andesite
fill 283 287 327 283 288 327 minecraft:polished_andesite
fill 283 287 329 283 288 329 minecraft:polished_andesite
fill 283 287 331 283 288 331 minecraft:polished_andesite
fill 283 287 333 283 288 333 minecraft:polished_andesite
fill 283 287 335 283 288 335 minecraft:polished_andesite
fill 283 287 337 283 288 337 minecraft:polished_andesite
fill 283 287 339 283 288 339 minecraft:polished_andesite
fill 283 287 341 283 288 341 minecraft:polished_andesite
fill 283 287 347 283 288 347 minecraft:polished_andesite
fill 283 287 349 283 288 349 minecraft:polished_andesite
fill 283 287 351 283 288 351 minecraft:polished_andesite
fill 283 287 353 283 288 353 minecraft:polished_andesite
fill 283 287 355 283 288 355 minecraft:polished_andesite
fill 283 287 357 283 288 357 minecraft:polished_andesite
fill 284 287 326 284 288 326 minecraft:polished_andesite
fill 284 287 328 284 288 328 minecraft:polished_andesite
fill 284 287 330 284 288 330 minecraft:polished_andesite
fill 284 287 332 284 288 332 minecraft:polished_andesite
fill 284 287 334 284 288 334 minecraft:polished_andesite
fill 284 287 336 284 288 336 minecraft:polished_andesite
fill 284 287 338 284 288 338 minecraft:polished_andesite
fill 284 287 340 284 288 340 minecraft:polished_andesite
fill 284 287 342 284 288 342 minecraft:polished_andesite
fill 284 287 348 284 288 348 minecraft:polished_andesite
fill 284 287 350 284 288 350 minecraft:polished_andesite
fill 284 287 352 284 288 352 minecraft:polished_andesite
fill 284 287 354 284 288 354 minecraft:polished_andesite
fill 284 287 356 284 288 356 minecraft:polished_andesite
fill 285 287 325 285 288 325 minecraft:polished_andesite
fill 285 287 327 285 288 327 minecraft:polished_andesite
fill 285 287 329 285 288 329 minecraft:polished_andesite
fill 285 287 331 285 288 331 minecraft:polished_andesite
fill 285 287 333 285 288 333 minecraft:polished_andesite
fill 285 287 335 285 288 335 minecraft:polished_andesite
fill 285 287 337 285 288 337 minecraft:polished_andesite
fill 285 287 339 285 288 339 minecraft:polished_andesite
fill 285 287 341 285 288 341 minecraft:polished_andesite
fill 285 287 347 285 288 347 minecraft:polished_andesite
fill 285 287 349 285 288 349 minecraft:polished_andesite
fill 285 287 351 285 288 351 minecraft:polished_andesite
fill 285 287 353 285 288 353 minecraft:polished_andesite
fill 285 287 355 285 288 355 minecraft:polished_andesite
fill 285 287 357 285 288 357 minecraft:polished_andesite
fill 286 287 326 286 288 326 minecraft:polished_andesite
fill 286 287 328 286 288 328 minecraft:polished_andesite
fill 286 287 330 286 288 330 minecraft:polished_andesite
fill 286 287 332 286 288 332 minecraft:polished_andesite
fill 286 287 334 286 288 334 minecraft:polished_andesite
fill 286 287 336 286 288 336 minecraft:polished_andesite
fill 286 287 338 286 288 338 minecraft:polished_andesite
fill 286 287 340 286 288 340 minecraft:polished_andesite
fill 286 287 342 286 288 342 minecraft:polished_andesite
fill 286 287 348 286 288 348 minecraft:polished_andesite
fill 286 287 350 286 288 350 minecraft:polished_andesite
fill 286 287 352 286 288 352 minecraft:polished_andesite
fill 286 287 354 286 288 354 minecraft:polished_andesite
fill 286 287 356 286 288 356 minecraft:polished_andesite
fill 287 287 325 287 288 325 minecraft:polished_andesite
fill 287 287 327 287 288 327 minecraft:polished_andesite
fill 287 287 329 287 288 329 minecraft:polished_andesite
fill 287 287 331 287 288 331 minecraft:polished_andesite
fill 287 287 333 287 288 333 minecraft:polished_andesite
fill 287 287 335 287 288 335 minecraft:polished_andesite
fill 287 287 337 287 288 337 minecraft:polished_andesite
fill 287 287 339 287 288 339 minecraft:polished_andesite
fill 287 287 341 287 288 341 minecraft:polished_andesite
fill 288 287 326 288 288 326 minecraft:polished_andesite
fill 288 287 328 288 288 328 minecraft:polished_andesite
fill 288 287 330 288 288 330 minecraft:polished_andesite
fill 288 287 332 288 288 332 minecraft:polished_andesite
fill 288 287 334 288 288 334 minecraft:polished_andesite
fill 288 287 336 288 288 336 minecraft:polished_andesite
fill 288 287 338 288 288 338 minecraft:polished_andesite
fill 288 287 340 288 288 340 minecraft:polished_andesite
fill 288 287 342 288 288 342 minecraft:polished_andesite
fill 289 287 325 289 288 325 minecraft:polished_andesite
fill 289 287 327 289 288 327 minecraft:polished_andesite
fill 289 287 329 289 288 329 minecraft:polished_andesite
fill 289 287 331 289 288 331 minecraft:polished_andesite
fill 289 287 333 289 288 333 minecraft:polished_andesite
fill 289 287 335 289 288 335 minecraft:polished_andesite
fill 289 287 337 289 288 337 minecraft:polished_andesite
fill 289 287 339 289 288 339 minecraft:polished_andesite
fill 289 287 341 289 288 341 minecraft:polished_andesite
setblock 293 287 325 minecraft:light[level=15]
setblock 293 287 333 minecraft:light[level=15]
setblock 293 287 341 minecraft:light[level=15]
setblock 293 287 349 minecraft:light[level=15]
setblock 293 287 357 minecraft:light[level=15]
setblock 301 287 325 minecraft:light[level=15]
setblock 301 287 333 minecraft:light[level=15]
setblock 301 287 341 minecraft:light[level=15]
setblock 301 287 349 minecraft:light[level=15]
setblock 301 287 357 minecraft:light[level=15]
setblock 309 287 325 minecraft:light[level=15]
setblock 309 287 333 minecraft:light[level=15]
setblock 309 287 341 minecraft:light[level=15]
setblock 309 287 349 minecraft:light[level=15]
setblock 309 287 357 minecraft:light[level=15]
fill 313 287 341 313 288 341 minecraft:polished_andesite
fill 313 287 343 313 288 343 minecraft:polished_andesite
fill 313 287 345 313 288 345 minecraft:polished_andesite
fill 314 287 340 314 288 340 minecraft:polished_andesite
fill 314 287 342 314 288 342 minecraft:polished_andesite
fill 314 287 344 314 288 344 minecraft:polished_andesite
fill 314 287 346 314 288 346 minecraft:polished_andesite
fill 314 287 352 314 288 352 minecraft:polished_andesite
fill 314 287 354 314 288 354 minecraft:polished_andesite
fill 314 287 356 314 288 356 minecraft:polished_andesite
fill 314 287 358 314 288 358 minecraft:polished_andesite
fill 314 287 360 314 288 360 minecraft:polished_andesite
fill 314 287 362 314 288 362 minecraft:polished_andesite
fill 314 287 364 314 288 364 minecraft:stone_bricks
fill 315 287 341 315 288 341 minecraft:polished_andesite
fill 315 287 343 315 288 343 minecraft:polished_andesite
fill 315 287 345 315 288 345 minecraft:polished_andesite
fill 315 287 353 315 288 353 minecraft:polished_andesite
fill 315 287 355 315 288 355 minecraft:polished_andesite
fill 315 287 357 315 288 357 minecraft:polished_andesite
fill 315 287 359 315 288 359 minecraft:polished_andesite
fill 315 287 361 315 288 361 minecraft:polished_andesite
fill 315 287 363 315 288 363 minecraft:polished_andesite
fill 316 287 340 316 288 340 minecraft:polished_andesite
fill 316 287 342 316 288 342 minecraft:polished_andesite
fill 316 287 344 316 288 344 minecraft:polished_andesite
fill 316 287 346 316 288 346 minecraft:polished_andesite
fill 316 287 352 316 288 352 minecraft:polished_andesite
fill 316 287 354 316 288 354 minecraft:polished_andesite
fill 316 287 356 316 288 356 minecraft:polished_andesite
fill 316 287 358 316 288 358 minecraft:polished_andesite
fill 316 287 360 316 288 360 minecraft:polished_andesite
fill 316 287 362 316 288 362 minecraft:polished_andesite
fill 316 287 364 316 288 364 minecraft:stone_bricks
setblock 317 287 325 minecraft:light[level=15]
setblock 317 287 333 minecraft:light[level=15]
fill 317 287 341 317 288 341 minecraft:polished_andesite
fill 317 287 343 317 288 343 minecraft:polished_andesite
fill 317 287 345 317 288 345 minecraft:polished_andesite
setblock 317 287 349 minecraft:light[level=15]
fill 317 287 353 317 288 353 minecraft:polished_andesite
fill 317 287 355 317 288 355 minecraft:polished_andesite
fill 317 287 357 317 288 357 minecraft:polished_andesite
fill 317 287 359 317 288 359 minecraft:polished_andesite
fill 317 287 361 317 288 361 minecraft:polished_andesite
fill 317 287 363 317 288 363 minecraft:polished_andesite
fill 318 287 340 318 288 340 minecraft:polished_andesite
fill 318 287 342 318 288 342 minecraft:polished_andesite
fill 318 287 344 318 288 344 minecraft:polished_andesite
fill 318 287 346 318 288 346 minecraft:polished_andesite
fill 318 287 352 318 288 352 minecraft:polished_andesite
fill 318 287 354 318 288 354 minecraft:polished_andesite
fill 318 287 356 318 288 356 minecraft:polished_andesite
fill 318 287 358 318 288 358 minecraft:polished_andesite
fill 318 287 360 318 288 360 minecraft:polished_andesite
fill 318 287 362 318 288 362 minecraft:polished_andesite
fill 318 287 364 321 291 364 minecraft:shroomlight
fill 319 287 341 319 288 341 minecraft:polished_andesite
fill 319 287 343 319 288 343 minecraft:polished_andesite
fill 319 287 345 319 288 345 minecraft:polished_andesite
fill 319 287 353 319 288 353 minecraft:polished_andesite
fill 319 287 355 319 288 355 minecraft:polished_andesite
fill 319 287 357 319 288 357 minecraft:polished_andesite
fill 319 287 359 319 288 359 minecraft:polished_andesite
fill 319 287 361 319 288 361 minecraft:polished_andesite
fill 319 287 363 319 288 363 minecraft:polished_andesite
fill 320 287 340 320 288 340 minecraft:polished_andesite
fill 320 287 342 320 288 342 minecraft:polished_andesite
fill 320 287 344 320 288 344 minecraft:polished_andesite
fill 320 287 346 320 288 346 minecraft:polished_andesite
fill 320 287 352 320 288 352 minecraft:polished_andesite
fill 320 287 354 320 288 354 minecraft:polished_andesite
fill 320 287 356 320 288 356 minecraft:polished_andesite
fill 320 287 358 320 288 358 minecraft:polished_andesite
fill 320 287 360 320 288 360 minecraft:polished_andesite
fill 320 287 362 320 288 362 minecraft:polished_andesite
fill 321 287 341 321 288 341 minecraft:polished_andesite
fill 321 287 343 321 288 343 minecraft:polished_andesite
fill 321 287 345 321 288 345 minecraft:polished_andesite
fill 321 287 353 321 288 353 minecraft:polished_andesite
fill 321 287 355 321 288 355 minecraft:polished_andesite
fill 321 287 357 321 288 357 minecraft:polished_andesite
fill 321 287 359 321 288 359 minecraft:polished_andesite
fill 321 287 361 321 288 361 minecraft:polished_andesite
fill 321 287 363 321 288 363 minecraft:polished_andesite
fill 322 287 340 322 288 340 minecraft:polished_andesite
fill 322 287 342 322 288 342 minecraft:polished_andesite
fill 322 287 344 322 288 344 minecraft:polished_andesite
fill 322 287 346 322 288 346 minecraft:polished_andesite
fill 322 287 352 322 288 352 minecraft:polished_andesite
fill 322 287 354 322 288 354 minecraft:polished_andesite
fill 322 287 356 322 288 356 minecraft:polished_andesite
fill 322 287 358 322 288 358 minecraft:polished_andesite
fill 322 287 360 322 288 360 minecraft:polished_andesite
fill 322 287 362 322 288 362 minecraft:polished_andesite
fill 322 287 364 322 288 364 minecraft:stone_bricks
fill 323 287 341 323 288 341 minecraft:polished_andesite
fill 323 287 343 323 288 343 minecraft:polished_andesite
fill 323 287 345 323 288 345 minecraft:polished_andesite
fill 323 287 353 323 288 353 minecraft:polished_andesite
fill 323 287 355 323 288 355 minecraft:polished_andesite
fill 323 287 357 323 288 357 minecraft:polished_andesite
fill 323 287 359 323 288 359 minecraft:polished_andesite
fill 323 287 361 323 288 361 minecraft:polished_andesite
fill 323 287 363 323 288 363 minecraft:polished_andesite
fill 324 287 359 324 291 359 minecraft:shroomlight
fill 324 287 361 324 292 361 minecraft:shroomlight
setblock 283 289 325 minecraft:shroomlight
setblock 283 289 327 minecraft:shroomlight
setblock 283 289 329 minecraft:shroomlight
setblock 283 289 331 minecraft:shroomlight
setblock 283 289 333 minecraft:shroomlight
setblock 283 289 335 minecraft:shroomlight
setblock 283 289 337 minecraft:shroomlight
setblock 283 289 339 minecraft:shroomlight
setblock 283 289 341 minecraft:shroomlight
setblock 283 289 347 minecraft:shroomlight
setblock 283 289 349 minecraft:shroomlight
setblock 283 289 351 minecraft:shroomlight
setblock 283 289 353 minecraft:shroomlight
setblock 283 289 355 minecraft:shroomlight
setblock 283 289 357 minecraft:shroomlight
setblock 284 289 326 minecraft:shroomlight
setblock 284 289 328 minecraft:shroomlight
setblock 284 289 330 minecraft:shroomlight
setblock 284 289 332 minecraft:shroomlight
setblock 284 289 334 minecraft:shroomlight
setblock 284 289 336 minecraft:shroomlight
setblock 284 289 338 minecraft:shroomlight
setblock 284 289 340 minecraft:shroomlight
setblock 284 289 342 minecraft:shroomlight
setblock 284 289 348 minecraft:shroomlight
setblock 284 289 350 minecraft:shroomlight
setblock 284 289 352 minecraft:shroomlight
setblock 284 289 354 minecraft:shroomlight
setblock 284 289 356 minecraft:shroomlight
setblock 285 289 325 minecraft:shroomlight
setblock 285 289 327 minecraft:shroomlight
setblock 285 289 329 minecraft:shroomlight
setblock 285 289 331 minecraft:shroomlight
setblock 285 289 333 minecraft:shroomlight
setblock 285 289 335 minecraft:shroomlight
setblock 285 289 337 minecraft:shroomlight
setblock 285 289 339 minecraft:shroomlight
schedule function dropper:buildpart/78_4 1t
