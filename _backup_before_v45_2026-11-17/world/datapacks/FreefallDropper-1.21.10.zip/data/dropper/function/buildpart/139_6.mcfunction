fill 367 211 598 367 214 598 minecraft:green_terracotta
setblock 368 211 586 minecraft:oak_log
fill 368 211 587 368 214 587 minecraft:green_terracotta
setblock 368 211 591 minecraft:oak_log
fill 368 211 592 368 214 592 minecraft:green_terracotta
setblock 368 211 596 minecraft:oak_log
fill 368 211 597 368 214 597 minecraft:green_terracotta
setblock 369 211 566 minecraft:green_terracotta
setblock 369 211 570 minecraft:oak_log
setblock 369 211 585 minecraft:oak_log
fill 369 211 586 369 214 586 minecraft:green_terracotta
setblock 369 211 590 minecraft:oak_log
fill 369 211 591 369 214 591 minecraft:green_terracotta
setblock 369 211 595 minecraft:oak_log
fill 369 211 596 369 214 596 minecraft:green_terracotta
setblock 370 211 564 minecraft:oak_log
fill 370 211 565 370 214 565 minecraft:green_terracotta
setblock 370 211 569 minecraft:oak_log
fill 370 211 570 370 214 570 minecraft:green_terracotta
setblock 370 211 574 minecraft:oak_log
fill 370 211 575 370 214 575 minecraft:green_terracotta
setblock 370 211 584 minecraft:oak_log
fill 370 211 585 370 214 585 minecraft:green_terracotta
setblock 370 211 589 minecraft:oak_log
fill 370 211 590 370 214 590 minecraft:green_terracotta
setblock 370 211 594 minecraft:oak_log
fill 370 211 595 370 214 595 minecraft:green_terracotta
fill 330 212 564 330 212 567 minecraft:green_terracotta
setblock 330 212 568 minecraft:oak_log
fill 330 212 569 330 212 572 minecraft:green_terracotta
setblock 330 212 573 minecraft:oak_log
fill 330 212 574 330 212 577 minecraft:green_terracotta
setblock 330 212 578 minecraft:oak_log
fill 330 212 579 330 212 582 minecraft:green_terracotta
setblock 330 212 583 minecraft:oak_log
fill 330 212 584 330 215 584 minecraft:green_terracotta
setblock 330 212 588 minecraft:oak_log
fill 330 212 589 330 215 589 minecraft:green_terracotta
setblock 330 212 593 minecraft:oak_log
fill 330 212 594 330 215 594 minecraft:green_terracotta
setblock 330 212 598 minecraft:oak_log
fill 331 212 568 331 215 568 minecraft:green_terracotta
setblock 331 212 572 minecraft:oak_log
fill 331 212 573 331 215 573 minecraft:green_terracotta
fill 331 212 575 331 213 575 minecraft:green_terracotta
setblock 331 212 587 minecraft:oak_log
fill 331 212 588 331 215 588 minecraft:green_terracotta
setblock 331 212 592 minecraft:oak_log
fill 331 212 593 331 215 593 minecraft:green_terracotta
fill 331 212 595 331 213 595 minecraft:green_terracotta
setblock 331 212 598 minecraft:oak_leaves[persistent=true]
fill 337 212 574 338 213 575 minecraft:dark_oak_log
fill 338 212 571 338 213 571 minecraft:dark_oak_log
fill 338 212 576 338 213 576 minecraft:dark_oak_log
fill 338 212 577 338 213 577 minecraft:oak_log
setblock 338 212 578 minecraft:jungle_leaves[persistent=true]
fill 338 212 579 338 213 579 minecraft:oak_log
fill 339 212 573 339 213 573 minecraft:dark_oak_log
fill 340 212 572 340 213 572 minecraft:dark_oak_log
fill 341 212 571 341 213 571 minecraft:dark_oak_log
fill 342 212 578 342 218 578 minecraft:jungle_leaves[persistent=true]
setblock 344 212 558 minecraft:green_terracotta
setblock 345 212 558 minecraft:oak_log
fill 346 212 558 349 212 558 minecraft:green_terracotta
fill 346 212 598 348 213 598 minecraft:green_terracotta
setblock 348 212 559 minecraft:green_terracotta
setblock 350 212 558 minecraft:oak_log
setblock 350 212 598 minecraft:oak_log
fill 351 212 558 351 215 558 minecraft:green_terracotta
fill 351 212 598 351 215 598 minecraft:green_terracotta
fill 357 212 575 359 213 575 minecraft:jungle_leaves[persistent=true]
fill 357 212 581 359 213 581 minecraft:jungle_leaves[persistent=true]
setblock 360 212 598 minecraft:oak_log
fill 361 212 598 361 215 598 minecraft:green_terracotta
fill 362 212 558 363 213 558 minecraft:green_terracotta
fill 362 212 597 363 214 597 minecraft:green_terracotta
fill 364 212 596 366 212 596 minecraft:green_terracotta
setblock 365 212 558 minecraft:oak_log
setblock 365 212 598 minecraft:oak_log
fill 366 212 558 366 215 558 minecraft:green_terracotta
setblock 366 212 597 minecraft:oak_log
fill 366 212 598 366 215 598 minecraft:green_terracotta
fill 367 212 589 367 212 590 minecraft:green_terracotta
setblock 367 212 591 minecraft:oak_log
fill 367 212 592 367 215 592 minecraft:green_terracotta
fill 367 212 594 367 212 595 minecraft:green_terracotta
setblock 367 212 596 minecraft:oak_log
fill 367 212 597 367 215 597 minecraft:green_terracotta
fill 368 212 586 368 215 586 minecraft:green_terracotta
setblock 368 212 590 minecraft:oak_log
fill 368 212 591 368 215 591 minecraft:green_terracotta
setblock 368 212 595 minecraft:oak_log
fill 368 212 596 368 215 596 minecraft:green_terracotta
setblock 369 212 569 minecraft:oak_log
fill 369 212 570 369 213 572 minecraft:green_terracotta
setblock 369 212 584 minecraft:oak_log
fill 369 212 585 369 215 585 minecraft:green_terracotta
setblock 369 212 589 minecraft:oak_log
fill 369 212 590 369 215 590 minecraft:green_terracotta
setblock 369 212 594 minecraft:oak_log
fill 369 212 595 369 215 595 minecraft:green_terracotta
setblock 370 212 564 minecraft:green_terracotta
setblock 370 212 568 minecraft:oak_log
fill 370 212 569 370 215 569 minecraft:green_terracotta
setblock 370 212 573 minecraft:oak_log
fill 370 212 574 370 215 574 minecraft:green_terracotta
fill 370 212 576 370 212 577 minecraft:green_terracotta
setblock 370 212 583 minecraft:oak_log
fill 370 212 584 370 215 584 minecraft:green_terracotta
setblock 370 212 588 minecraft:oak_log
fill 370 212 589 370 215 589 minecraft:green_terracotta
setblock 370 212 593 minecraft:oak_log
fill 370 212 594 370 215 594 minecraft:green_terracotta
setblock 370 212 598 minecraft:oak_log
setblock 330 213 561 minecraft:oak_leaves[persistent=true]
fill 330 213 565 330 213 566 minecraft:green_terracotta
setblock 330 213 567 minecraft:oak_log
fill 330 213 568 330 213 571 minecraft:green_terracotta
setblock 330 213 572 minecraft:oak_log
fill 330 213 573 330 213 576 minecraft:green_terracotta
setblock 330 213 577 minecraft:oak_log
fill 330 213 578 330 213 581 minecraft:green_terracotta
setblock 330 213 582 minecraft:oak_log
fill 330 213 583 330 216 583 minecraft:green_terracotta
setblock 330 213 587 minecraft:oak_log
fill 330 213 588 330 216 588 minecraft:green_terracotta
setblock 330 213 592 minecraft:oak_log
fill 330 213 593 330 216 593 minecraft:green_terracotta
setblock 330 213 597 minecraft:oak_log
fill 330 213 598 330 216 598 minecraft:green_terracotta
setblock 331 213 571 minecraft:oak_log
fill 331 213 572 331 216 572 minecraft:green_terracotta
setblock 331 213 576 minecraft:oak_log
fill 331 213 577 331 216 577 minecraft:green_terracotta
setblock 331 213 586 minecraft:oak_log
fill 331 213 587 331 215 587 minecraft:green_terracotta
setblock 331 213 591 minecraft:oak_log
fill 331 213 592 331 216 592 minecraft:green_terracotta
setblock 337 213 598 minecraft:oak_leaves[persistent=true]
fill 338 213 558 338 214 558 minecraft:oak_leaves[persistent=true]
setblock 338 213 578 minecraft:oak_log
fill 339 213 570 340 213 570 minecraft:dark_oak_log
fill 339 213 574 339 213 575 minecraft:dark_oak_log
fill 339 213 576 340 218 577 minecraft:jungle_leaves[persistent=true]
fill 339 213 579 340 218 580 minecraft:jungle_leaves[persistent=true]
fill 340 213 573 341 213 574 minecraft:dark_oak_log
fill 340 213 575 343 218 575 minecraft:jungle_leaves[persistent=true]
fill 340 213 581 343 218 581 minecraft:jungle_leaves[persistent=true]
fill 341 213 572 342 213 572 minecraft:dark_oak_log
setblock 342 213 571 minecraft:dark_oak_log
fill 342 213 573 343 217 574 minecraft:jungle_leaves[persistent=true]
fill 342 213 582 343 217 583 minecraft:jungle_leaves[persistent=true]
setblock 343 213 558 minecraft:green_terracotta
setblock 344 213 558 minecraft:oak_log
fill 344 213 573 344 217 573 minecraft:jungle_leaves[persistent=true]
fill 344 213 583 344 217 583 minecraft:jungle_leaves[persistent=true]
setblock 344 213 598 minecraft:oak_log
fill 345 213 558 348 213 558 minecraft:green_terracotta
fill 345 213 575 348 216 576 minecraft:jungle_leaves[persistent=true]
fill 345 213 580 348 216 581 minecraft:jungle_leaves[persistent=true]
fill 345 213 598 345 216 598 minecraft:green_terracotta
fill 346 213 559 347 213 559 minecraft:green_terracotta
fill 346 213 574 350 214 574 minecraft:jungle_leaves[persistent=true]
fill 346 213 582 350 214 582 minecraft:jungle_leaves[persistent=true]
fill 347 213 597 348 214 597 minecraft:green_terracotta
setblock 348 213 559 minecraft:oak_log
setblock 349 213 558 minecraft:oak_log
fill 349 213 559 349 216 559 minecraft:green_terracotta
fill 349 213 575 349 214 575 minecraft:jungle_leaves[persistent=true]
fill 349 213 581 349 214 581 minecraft:jungle_leaves[persistent=true]
setblock 349 213 598 minecraft:oak_log
fill 350 213 558 350 216 558 minecraft:green_terracotta
fill 350 213 598 350 216 598 minecraft:green_terracotta
fill 352 213 598 353 213 598 minecraft:green_terracotta
setblock 353 213 558 minecraft:green_terracotta
fill 356 213 574 358 213 574 minecraft:jungle_leaves[persistent=true]
fill 356 213 582 358 213 582 minecraft:jungle_leaves[persistent=true]
setblock 356 213 598 minecraft:oak_leaves[persistent=true]
fill 357 213 598 358 213 598 minecraft:green_terracotta
fill 358 213 576 359 213 576 minecraft:jungle_leaves[persistent=true]
fill 358 213 580 359 213 580 minecraft:jungle_leaves[persistent=true]
setblock 359 213 598 minecraft:oak_log
setblock 360 213 597 minecraft:oak_log
fill 360 213 598 360 216 598 minecraft:green_terracotta
fill 361 213 558 361 215 558 minecraft:green_terracotta
fill 361 213 597 361 216 597 minecraft:green_terracotta
fill 362 213 596 365 213 596 minecraft:green_terracotta
setblock 364 213 558 minecraft:oak_log
fill 364 213 595 366 213 595 minecraft:green_terracotta
setblock 364 213 598 minecraft:oak_log
fill 365 213 558 365 216 558 minecraft:green_terracotta
setblock 365 213 597 minecraft:oak_log
fill 365 213 598 365 216 598 minecraft:green_terracotta
setblock 366 213 596 minecraft:oak_log
fill 366 213 597 366 216 597 minecraft:green_terracotta
setblock 367 213 589 minecraft:green_terracotta
setblock 367 213 590 minecraft:oak_log
fill 367 213 591 367 216 591 minecraft:green_terracotta
setblock 367 213 594 minecraft:green_terracotta
setblock 367 213 595 minecraft:oak_log
fill 367 213 596 367 216 596 minecraft:green_terracotta
setblock 368 213 589 minecraft:oak_log
fill 368 213 590 368 216 590 minecraft:green_terracotta
setblock 368 213 594 minecraft:oak_log
fill 368 213 595 368 216 595 minecraft:green_terracotta
setblock 369 213 558 minecraft:oak_log
setblock 369 213 568 minecraft:oak_log
fill 369 213 569 369 216 569 minecraft:green_terracotta
setblock 369 213 573 minecraft:oak_log
fill 369 213 574 369 216 574 minecraft:green_terracotta
fill 369 213 584 369 216 584 minecraft:green_terracotta
setblock 369 213 588 minecraft:oak_log
fill 369 213 589 369 216 589 minecraft:green_terracotta
setblock 369 213 593 minecraft:oak_log
fill 369 213 594 369 216 594 minecraft:green_terracotta
setblock 369 213 598 minecraft:oak_log
setblock 370 213 567 minecraft:oak_log
fill 370 213 568 370 216 568 minecraft:green_terracotta
setblock 370 213 572 minecraft:oak_log
fill 370 213 573 370 216 573 minecraft:green_terracotta
setblock 370 213 576 minecraft:green_terracotta
setblock 370 213 577 minecraft:oak_log
fill 370 213 578 370 214 580 minecraft:green_terracotta
setblock 370 213 582 minecraft:oak_log
fill 370 213 583 370 216 583 minecraft:green_terracotta
setblock 370 213 587 minecraft:oak_log
fill 370 213 588 370 216 588 minecraft:green_terracotta
setblock 370 213 592 minecraft:oak_log
fill 370 213 593 370 216 593 minecraft:green_terracotta
setblock 370 213 597 minecraft:oak_log
fill 370 213 598 370 216 598 minecraft:green_terracotta
setblock 330 214 565 minecraft:green_terracotta
setblock 330 214 566 minecraft:oak_log
fill 330 214 567 330 214 570 minecraft:green_terracotta
setblock 330 214 571 minecraft:oak_log
fill 330 214 572 330 214 575 minecraft:green_terracotta
setblock 330 214 576 minecraft:oak_log
fill 330 214 577 330 214 580 minecraft:green_terracotta
setblock 330 214 581 minecraft:oak_log
fill 330 214 582 330 217 582 minecraft:green_terracotta
setblock 330 214 586 minecraft:oak_log
fill 330 214 587 330 217 587 minecraft:green_terracotta
setblock 330 214 591 minecraft:oak_log
fill 330 214 592 330 217 592 minecraft:green_terracotta
setblock 330 214 596 minecraft:oak_log
fill 330 214 597 330 217 597 minecraft:green_terracotta
setblock 331 214 570 minecraft:oak_log
fill 331 214 571 331 217 571 minecraft:green_terracotta
setblock 331 214 575 minecraft:oak_log
fill 331 214 576 331 217 576 minecraft:green_terracotta
fill 331 214 578 331 215 578 minecraft:green_terracotta
setblock 331 214 585 minecraft:oak_log
fill 331 214 586 331 215 586 minecraft:green_terracotta
setblock 331 214 590 minecraft:oak_log
fill 331 214 591 331 217 591 minecraft:green_terracotta
setblock 331 214 595 minecraft:oak_log
fill 331 214 598 331 215 598 minecraft:green_terracotta
setblock 332 214 558 minecraft:oak_leaves[persistent=true]
fill 336 214 578 338 217 578 minecraft:jungle_leaves[persistent=true]
fill 337 214 575 338 217 577 minecraft:jungle_leaves[persistent=true]
fill 337 214 579 338 217 581 minecraft:jungle_leaves[persistent=true]
fill 338 214 574 341 217 574 minecraft:jungle_leaves[persistent=true]
fill 338 214 582 341 217 582 minecraft:jungle_leaves[persistent=true]
fill 339 214 573 341 217 573 minecraft:jungle_leaves[persistent=true]
fill 339 214 575 339 217 575 minecraft:jungle_leaves[persistent=true]
fill 339 214 581 339 217 581 minecraft:jungle_leaves[persistent=true]
fill 339 214 583 341 217 583 minecraft:jungle_leaves[persistent=true]
setblock 342 214 558 minecraft:green_terracotta
fill 342 214 572 342 217 572 minecraft:jungle_leaves[persistent=true]
fill 342 214 584 342 217 584 minecraft:jungle_leaves[persistent=true]
setblock 342 214 598 minecraft:green_terracotta
setblock 343 214 558 minecraft:oak_log
setblock 343 214 598 minecraft:oak_log
fill 344 214 558 346 214 559 minecraft:green_terracotta
setblock 344 214 597 minecraft:oak_log
fill 344 214 598 344 217 598 minecraft:green_terracotta
fill 345 214 597 346 216 597 minecraft:green_terracotta
fill 346 214 598 347 214 598 minecraft:green_terracotta
setblock 347 214 558 minecraft:green_terracotta
setblock 347 214 559 minecraft:oak_log
setblock 348 214 558 minecraft:oak_log
fill 348 214 559 348 217 559 minecraft:green_terracotta
setblock 348 214 598 minecraft:oak_log
fill 349 214 558 349 217 558 minecraft:green_terracotta
setblock 349 214 597 minecraft:oak_log
fill 349 214 598 349 217 598 minecraft:green_terracotta
fill 350 214 559 350 215 559 minecraft:green_terracotta
fill 350 214 597 351 216 597 minecraft:green_terracotta
setblock 352 214 598 minecraft:green_terracotta
setblock 353 214 558 minecraft:oak_log
setblock 353 214 598 minecraft:oak_log
fill 354 214 558 354 217 558 minecraft:green_terracotta
fill 354 214 598 357 214 598 minecraft:green_terracotta
setblock 357 214 558 minecraft:oak_leaves[persistent=true]
setblock 358 214 558 minecraft:oak_log
setblock 358 214 597 minecraft:green_terracotta
setblock 358 214 598 minecraft:oak_log
fill 359 214 558 360 216 558 minecraft:green_terracotta
setblock 359 214 597 minecraft:oak_log
fill 359 214 598 359 217 598 minecraft:green_terracotta
setblock 360 214 596 minecraft:oak_log
fill 360 214 597 360 217 597 minecraft:green_terracotta
fill 361 214 596 364 214 596 minecraft:green_terracotta
setblock 362 214 558 minecraft:green_terracotta
setblock 363 214 558 minecraft:oak_log
fill 363 214 595 365 214 595 minecraft:green_terracotta
setblock 363 214 598 minecraft:oak_log
fill 364 214 558 364 217 558 minecraft:green_terracotta
setblock 364 214 597 minecraft:oak_log
fill 364 214 598 364 217 598 minecraft:green_terracotta
setblock 365 214 596 minecraft:oak_log
fill 365 214 597 365 217 597 minecraft:green_terracotta
fill 366 214 592 366 214 594 minecraft:green_terracotta
setblock 366 214 595 minecraft:oak_log
fill 366 214 596 366 217 596 minecraft:green_terracotta
fill 367 214 580 368 215 580 minecraft:oak_leaves[persistent=true]
setblock 367 214 589 minecraft:oak_log
fill 367 214 590 367 217 590 minecraft:green_terracotta
setblock 367 214 594 minecraft:oak_log
fill 367 214 595 367 217 595 minecraft:green_terracotta
setblock 368 214 558 minecraft:oak_log
fill 368 214 579 368 215 579 minecraft:oak_leaves[persistent=true]
fill 368 214 581 368 215 581 minecraft:oak_leaves[persistent=true]
setblock 368 214 588 minecraft:oak_log
fill 368 214 589 368 217 589 minecraft:green_terracotta
setblock 368 214 593 minecraft:oak_log
fill 368 214 594 368 217 594 minecraft:green_terracotta
setblock 368 214 598 minecraft:oak_log
fill 369 214 558 369 217 558 minecraft:green_terracotta
fill 369 214 568 369 215 568 minecraft:green_terracotta
fill 369 214 570 369 214 571 minecraft:green_terracotta
setblock 369 214 572 minecraft:oak_log
fill 369 214 573 369 217 573 minecraft:green_terracotta
fill 369 214 575 369 214 576 minecraft:green_terracotta
setblock 369 214 587 minecraft:oak_log
fill 369 214 588 369 217 588 minecraft:green_terracotta
setblock 369 214 592 minecraft:oak_log
fill 369 214 593 369 217 593 minecraft:green_terracotta
setblock 369 214 597 minecraft:oak_log
fill 369 214 598 369 217 598 minecraft:green_terracotta
fill 370 214 564 370 215 564 minecraft:oak_leaves[persistent=true]
setblock 370 214 566 minecraft:oak_log
fill 370 214 567 370 216 567 minecraft:green_terracotta
setblock 370 214 571 minecraft:oak_log
fill 370 214 572 370 217 572 minecraft:green_terracotta
setblock 370 214 576 minecraft:oak_log
fill 370 214 577 370 217 577 minecraft:green_terracotta
setblock 370 214 581 minecraft:oak_log
fill 370 214 582 370 217 582 minecraft:green_terracotta
setblock 370 214 586 minecraft:oak_log
fill 370 214 587 370 217 587 minecraft:green_terracotta
setblock 370 214 591 minecraft:oak_log
fill 370 214 592 370 217 592 minecraft:green_terracotta
setblock 370 214 596 minecraft:oak_log
fill 370 214 597 370 217 597 minecraft:green_terracotta
setblock 330 215 565 minecraft:oak_log
fill 330 215 566 330 215 569 minecraft:green_terracotta
setblock 330 215 570 minecraft:oak_log
fill 330 215 571 330 215 574 minecraft:green_terracotta
setblock 330 215 575 minecraft:oak_log
fill 330 215 576 330 215 579 minecraft:green_terracotta
setblock 330 215 580 minecraft:oak_log
fill 330 215 581 330 218 581 minecraft:green_terracotta
setblock 330 215 585 minecraft:oak_log
fill 330 215 586 330 218 586 minecraft:green_terracotta
setblock 330 215 590 minecraft:oak_log
fill 330 215 591 330 218 591 minecraft:green_terracotta
setblock 330 215 595 minecraft:oak_log
fill 330 215 596 331 216 596 minecraft:green_terracotta
setblock 331 215 569 minecraft:oak_log
fill 331 215 570 331 218 570 minecraft:green_terracotta
setblock 331 215 574 minecraft:oak_log
fill 331 215 575 331 218 575 minecraft:green_terracotta
setblock 331 215 579 minecraft:oak_log
setblock 331 215 589 minecraft:oak_log
fill 331 215 590 331 216 590 minecraft:green_terracotta
setblock 331 215 594 minecraft:oak_log
fill 331 215 595 331 217 595 minecraft:green_terracotta
setblock 332 215 572 minecraft:green_terracotta
setblock 332 215 573 minecraft:oak_log
fill 332 215 574 332 218 574 minecraft:green_terracotta
fill 336 215 575 336 216 577 minecraft:jungle_leaves[persistent=true]
fill 336 215 579 336 216 581 minecraft:jungle_leaves[persistent=true]
fill 337 215 574 337 216 574 minecraft:jungle_leaves[persistent=true]
fill 337 215 582 337 216 582 minecraft:jungle_leaves[persistent=true]
fill 338 215 573 338 216 573 minecraft:jungle_leaves[persistent=true]
fill 338 215 583 338 216 583 minecraft:jungle_leaves[persistent=true]
fill 339 215 572 341 216 572 minecraft:jungle_leaves[persistent=true]
fill 339 215 584 341 216 584 minecraft:jungle_leaves[persistent=true]
fill 340 215 598 341 215 598 minecraft:green_terracotta
setblock 341 215 558 minecraft:green_terracotta
fill 341 215 566 342 216 567 minecraft:oak_leaves[persistent=true]
setblock 342 215 558 minecraft:oak_log
setblock 342 215 597 minecraft:green_terracotta
setblock 342 215 598 minecraft:oak_log
fill 343 215 558 345 215 559 minecraft:green_terracotta
fill 343 215 572 345 216 572 minecraft:jungle_leaves[persistent=true]
fill 343 215 584 345 216 584 minecraft:jungle_leaves[persistent=true]
setblock 343 215 597 minecraft:oak_log
fill 343 215 598 343 218 598 minecraft:green_terracotta
fill 344 215 597 344 218 597 minecraft:green_terracotta
fill 345 215 596 347 216 596 minecraft:green_terracotta
setblock 346 215 558 minecraft:green_terracotta
setblock 346 215 559 minecraft:oak_log
fill 346 215 573 346 216 574 minecraft:jungle_leaves[persistent=true]
fill 346 215 582 346 216 583 minecraft:jungle_leaves[persistent=true]
setblock 346 215 598 minecraft:green_terracotta
setblock 347 215 558 minecraft:oak_log
fill 347 215 559 347 218 559 minecraft:green_terracotta
fill 347 215 574 347 216 574 minecraft:jungle_leaves[persistent=true]
fill 347 215 582 347 216 582 minecraft:jungle_leaves[persistent=true]
setblock 347 215 597 minecraft:green_terracotta
setblock 347 215 598 minecraft:oak_log
fill 348 215 558 348 218 558 minecraft:green_terracotta
setblock 348 215 597 minecraft:oak_log
fill 348 215 598 348 218 598 minecraft:green_terracotta
fill 349 215 597 349 218 597 minecraft:green_terracotta
setblock 352 215 558 minecraft:oak_log
setblock 352 215 597 minecraft:green_terracotta
setblock 352 215 598 minecraft:oak_log
fill 353 215 558 353 218 558 minecraft:green_terracotta
setblock 353 215 597 minecraft:oak_log
fill 353 215 598 356 215 598 minecraft:green_terracotta
fill 355 215 558 356 215 558 minecraft:green_terracotta
fill 355 215 597 357 215 597 minecraft:green_terracotta
setblock 357 215 558 minecraft:oak_log
setblock 357 215 598 minecraft:oak_log
fill 358 215 558 358 218 558 minecraft:green_terracotta
setblock 358 215 597 minecraft:oak_log
fill 358 215 598 358 218 598 minecraft:green_terracotta
setblock 359 215 596 minecraft:oak_log
fill 359 215 597 359 218 597 minecraft:green_terracotta
fill 360 215 596 363 215 596 minecraft:green_terracotta
fill 361 215 595 364 215 595 minecraft:green_terracotta
setblock 362 215 558 minecraft:oak_log
setblock 362 215 597 minecraft:green_terracotta
setblock 362 215 598 minecraft:oak_log
fill 363 215 558 363 217 559 minecraft:green_terracotta
setblock 363 215 597 minecraft:oak_log
fill 363 215 598 363 218 598 minecraft:green_terracotta
fill 364 215 559 365 215 559 minecraft:green_terracotta
fill 364 215 594 365 215 594 minecraft:green_terracotta
setblock 364 215 596 minecraft:oak_log
fill 364 215 597 364 218 597 minecraft:green_terracotta
setblock 365 215 595 minecraft:oak_log
fill 365 215 596 365 218 596 minecraft:green_terracotta
fill 366 215 591 366 215 593 minecraft:green_terracotta
setblock 366 215 594 minecraft:oak_log
fill 366 215 595 366 218 595 minecraft:green_terracotta
setblock 367 215 558 minecraft:oak_log
fill 367 215 589 367 216 589 minecraft:green_terracotta
setblock 367 215 593 minecraft:oak_log
fill 367 215 594 367 218 594 minecraft:green_terracotta
setblock 367 215 598 minecraft:oak_log
fill 368 215 558 368 218 558 minecraft:green_terracotta
setblock 368 215 587 minecraft:oak_log
fill 368 215 588 368 217 588 minecraft:green_terracotta
setblock 368 215 592 minecraft:oak_log
fill 368 215 593 368 218 593 minecraft:green_terracotta
setblock 368 215 597 minecraft:oak_log
fill 368 215 598 368 218 598 minecraft:green_terracotta
setblock 369 215 570 minecraft:green_terracotta
setblock 369 215 571 minecraft:oak_log
fill 369 215 572 369 218 572 minecraft:green_terracotta
setblock 369 215 575 minecraft:green_terracotta
setblock 369 215 576 minecraft:oak_log
fill 369 215 577 369 217 578 minecraft:green_terracotta
fill 369 215 583 369 216 583 minecraft:green_terracotta
setblock 369 215 586 minecraft:oak_log
fill 369 215 587 369 218 587 minecraft:green_terracotta
setblock 369 215 591 minecraft:oak_log
fill 369 215 592 369 218 592 minecraft:green_terracotta
setblock 369 215 596 minecraft:oak_log
fill 369 215 597 369 218 597 minecraft:green_terracotta
setblock 370 215 558 minecraft:oak_leaves[persistent=true]
setblock 370 215 566 minecraft:green_terracotta
setblock 370 215 570 minecraft:oak_log
fill 370 215 571 370 218 571 minecraft:green_terracotta
setblock 370 215 575 minecraft:oak_log
fill 370 215 576 370 218 576 minecraft:green_terracotta
fill 370 215 578 370 215 579 minecraft:green_terracotta
setblock 370 215 580 minecraft:oak_log
fill 370 215 581 370 218 581 minecraft:green_terracotta
setblock 370 215 585 minecraft:oak_log
fill 370 215 586 370 218 586 minecraft:green_terracotta
setblock 370 215 590 minecraft:oak_log
fill 370 215 591 370 218 591 minecraft:green_terracotta
setblock 370 215 595 minecraft:oak_log
fill 370 215 596 370 218 596 minecraft:green_terracotta
fill 330 216 566 330 216 568 minecraft:green_terracotta
setblock 330 216 569 minecraft:oak_log
fill 330 216 570 330 216 573 minecraft:green_terracotta
setblock 330 216 574 minecraft:oak_log
fill 330 216 575 330 216 578 minecraft:green_terracotta
setblock 330 216 579 minecraft:oak_log
fill 330 216 580 331 218 580 minecraft:green_terracotta
setblock 330 216 584 minecraft:oak_log
fill 330 216 585 330 218 585 minecraft:green_terracotta
setblock 330 216 589 minecraft:oak_log
fill 330 216 590 330 219 590 minecraft:green_terracotta
setblock 330 216 594 minecraft:oak_log
fill 330 216 595 330 219 595 minecraft:green_terracotta
fill 331 216 569 331 217 569 minecraft:green_terracotta
setblock 331 216 573 minecraft:oak_log
fill 331 216 574 331 219 574 minecraft:green_terracotta
setblock 331 216 578 minecraft:oak_log
fill 331 216 579 331 219 579 minecraft:green_terracotta
setblock 331 216 588 minecraft:oak_log
setblock 331 216 589 minecraft:green_terracotta
setblock 331 216 593 minecraft:oak_log
fill 331 216 594 331 217 594 minecraft:green_terracotta
setblock 331 216 598 minecraft:oak_log
setblock 332 216 560 minecraft:light[level=14]
setblock 332 216 568 minecraft:light[level=14]
setblock 332 216 572 minecraft:oak_log
fill 332 216 573 332 218 573 minecraft:green_terracotta
fill 332 216 575 332 217 575 minecraft:green_terracotta
setblock 332 216 576 minecraft:light[level=14]
setblock 332 216 584 minecraft:light[level=14]
setblock 332 216 592 minecraft:light[level=14]
fill 336 216 598 336 217 598 minecraft:oak_leaves[persistent=true]
fill 339 216 558 340 216 558 minecraft:green_terracotta
fill 339 216 598 340 216 598 minecraft:green_terracotta
setblock 340 216 560 minecraft:light[level=14]
setblock 340 216 568 minecraft:light[level=14]
setblock 340 216 592 minecraft:light[level=14]
setblock 341 216 558 minecraft:oak_log
setblock 341 216 597 minecraft:green_terracotta
setblock 341 216 598 minecraft:oak_log
fill 342 216 558 344 216 559 minecraft:green_terracotta
setblock 342 216 597 minecraft:oak_log
fill 342 216 598 342 219 598 minecraft:green_terracotta
setblock 343 216 596 minecraft:oak_log
fill 343 216 597 343 219 597 minecraft:green_terracotta
fill 344 216 596 344 219 596 minecraft:green_terracotta
setblock 345 216 558 minecraft:green_terracotta
setblock 345 216 559 minecraft:oak_log
fill 345 216 560 346 218 560 minecraft:green_terracotta
setblock 346 216 558 minecraft:oak_log
fill 346 216 559 346 219 559 minecraft:green_terracotta
setblock 346 216 598 minecraft:oak_log
fill 347 216 558 347 219 558 minecraft:green_terracotta
setblock 347 216 597 minecraft:oak_log
fill 347 216 598 347 219 598 minecraft:green_terracotta
setblock 348 216 560 minecraft:light[level=14]
setblock 348 216 568 minecraft:light[level=14]
setblock 348 216 584 minecraft:light[level=14]
setblock 348 216 592 minecraft:light[level=14]
setblock 348 216 596 minecraft:oak_log
fill 348 216 597 348 219 597 minecraft:green_terracotta
setblock 350 216 559 minecraft:oak_log
setblock 351 216 558 minecraft:oak_log
setblock 351 216 598 minecraft:oak_log
fill 352 216 558 352 219 558 minecraft:green_terracotta
setblock 352 216 597 minecraft:oak_log
fill 352 216 598 355 216 598 minecraft:green_terracotta
fill 353 216 597 356 216 597 minecraft:green_terracotta
setblock 355 216 558 minecraft:green_terracotta
setblock 356 216 558 minecraft:oak_log
setblock 356 216 560 minecraft:light[level=14]
setblock 356 216 568 minecraft:light[level=14]
setblock 356 216 584 minecraft:light[level=14]
setblock 356 216 592 minecraft:light[level=14]
setblock 356 216 598 minecraft:oak_log
fill 357 216 558 357 219 558 minecraft:green_terracotta
setblock 357 216 597 minecraft:oak_log
fill 357 216 598 357 219 598 minecraft:green_terracotta
setblock 358 216 596 minecraft:oak_log
fill 358 216 597 358 219 597 minecraft:green_terracotta
fill 359 216 596 362 216 596 minecraft:green_terracotta
fill 360 216 595 363 216 595 minecraft:green_terracotta
setblock 361 216 558 minecraft:oak_log
fill 361 216 559 362 218 559 minecraft:green_terracotta
setblock 361 216 598 minecraft:oak_log
fill 362 216 558 362 219 558 minecraft:green_terracotta
setblock 362 216 597 minecraft:oak_log
fill 362 216 598 362 219 598 minecraft:green_terracotta
fill 363 216 594 364 216 594 minecraft:green_terracotta
setblock 363 216 596 minecraft:oak_log
fill 363 216 597 363 219 597 minecraft:green_terracotta
setblock 364 216 559 minecraft:green_terracotta
setblock 364 216 560 minecraft:light[level=14]
setblock 364 216 568 minecraft:light[level=14]
setblock 364 216 576 minecraft:light[level=14]
setblock 364 216 584 minecraft:light[level=14]
setblock 364 216 592 minecraft:light[level=14]
setblock 364 216 595 minecraft:oak_log
fill 364 216 596 364 219 596 minecraft:green_terracotta
setblock 365 216 559 minecraft:oak_log
setblock 365 216 594 minecraft:oak_log
fill 365 216 595 365 219 595 minecraft:green_terracotta
setblock 366 216 558 minecraft:oak_log
fill 366 216 559 366 218 559 minecraft:green_terracotta
setblock 366 216 592 minecraft:green_terracotta
setblock 366 216 593 minecraft:oak_log
fill 366 216 594 366 217 594 minecraft:green_terracotta
setblock 366 216 598 minecraft:oak_log
fill 367 216 558 367 219 558 minecraft:green_terracotta
setblock 367 216 592 minecraft:oak_log
fill 367 216 593 367 219 593 minecraft:green_terracotta
setblock 367 216 597 minecraft:oak_log
fill 367 216 598 367 219 598 minecraft:green_terracotta
fill 368 216 573 368 216 574 minecraft:green_terracotta
setblock 368 216 587 minecraft:green_terracotta
setblock 368 216 591 minecraft:oak_log
fill 368 216 592 368 219 592 minecraft:green_terracotta
setblock 368 216 596 minecraft:oak_log
fill 368 216 597 368 219 597 minecraft:green_terracotta
setblock 369 216 570 minecraft:oak_log
fill 369 216 571 369 218 571 minecraft:green_terracotta
setblock 369 216 575 minecraft:oak_log
fill 369 216 576 369 219 576 minecraft:green_terracotta
setblock 369 216 579 minecraft:green_terracotta
setblock 369 216 580 minecraft:oak_log
setblock 369 216 585 minecraft:oak_log
fill 369 216 586 369 218 586 minecraft:green_terracotta
setblock 369 216 590 minecraft:oak_log
fill 369 216 591 369 219 591 minecraft:green_terracotta
setblock 369 216 595 minecraft:oak_log
fill 369 216 596 369 219 596 minecraft:green_terracotta
setblock 370 216 569 minecraft:oak_log
fill 370 216 570 370 218 570 minecraft:green_terracotta
setblock 370 216 574 minecraft:oak_log
fill 370 216 575 370 219 575 minecraft:green_terracotta
setblock 370 216 578 minecraft:green_terracotta
setblock 370 216 579 minecraft:oak_log
fill 370 216 580 370 219 580 minecraft:green_terracotta
setblock 370 216 584 minecraft:oak_log
fill 370 216 585 370 219 585 minecraft:green_terracotta
setblock 370 216 589 minecraft:oak_log
fill 370 216 590 370 219 590 minecraft:green_terracotta
setblock 370 216 594 minecraft:oak_log
fill 370 216 595 370 219 595 minecraft:green_terracotta
setblock 330 217 560 minecraft:oak_leaves[persistent=true]
fill 330 217 566 330 218 566 minecraft:oak_leaves[persistent=true]
setblock 330 217 567 minecraft:green_terracotta
setblock 330 217 568 minecraft:oak_log
fill 330 217 569 330 217 572 minecraft:green_terracotta
setblock 330 217 573 minecraft:oak_log
fill 330 217 574 330 217 577 minecraft:green_terracotta
setblock 330 217 578 minecraft:oak_log
fill 330 217 579 330 220 579 minecraft:green_terracotta
setblock 330 217 583 minecraft:oak_log
fill 330 217 584 330 219 584 minecraft:green_terracotta
setblock 330 217 588 minecraft:oak_log
fill 330 217 589 330 218 589 minecraft:green_terracotta
setblock 330 217 593 minecraft:oak_log
fill 330 217 594 330 220 594 minecraft:green_terracotta
fill 330 217 596 330 218 596 minecraft:green_terracotta
setblock 330 217 598 minecraft:oak_log
setblock 331 217 572 minecraft:oak_log
fill 331 217 573 331 220 573 minecraft:green_terracotta
setblock 331 217 577 minecraft:oak_log
fill 331 217 578 331 220 578 minecraft:green_terracotta
setblock 331 217 592 minecraft:oak_log
setblock 331 217 593 minecraft:green_terracotta
fill 331 217 598 331 218 598 minecraft:green_terracotta
setblock 332 217 572 minecraft:green_terracotta
setblock 332 217 576 minecraft:oak_log
fill 337 217 598 339 217 598 minecraft:green_terracotta
fill 338 217 558 339 217 558 minecraft:green_terracotta
fill 338 217 573 338 219 573 minecraft:oak_leaves[persistent=true]
fill 339 217 572 341 219 572 minecraft:oak_leaves[persistent=true]
setblock 340 217 558 minecraft:oak_log
setblock 340 217 597 minecraft:green_terracotta
setblock 340 217 598 minecraft:oak_log
fill 341 217 558 343 217 559 minecraft:green_terracotta
setblock 341 217 597 minecraft:oak_log
fill 341 217 598 341 220 598 minecraft:green_terracotta
setblock 342 217 596 minecraft:oak_log
fill 342 217 597 342 220 597 minecraft:green_terracotta
fill 343 217 596 343 220 596 minecraft:green_terracotta
setblock 344 217 558 minecraft:green_terracotta
setblock 344 217 559 minecraft:oak_log
fill 344 217 560 344 220 560 minecraft:green_terracotta
setblock 345 217 558 minecraft:oak_log
fill 345 217 559 345 220 559 minecraft:green_terracotta
fill 345 217 575 347 217 576 minecraft:jungle_leaves[persistent=true]
fill 345 217 580 347 217 581 minecraft:jungle_leaves[persistent=true]
fill 345 217 596 345 217 597 minecraft:green_terracotta
setblock 345 217 598 minecraft:oak_log
fill 346 217 558 346 220 558 minecraft:green_terracotta
setblock 346 217 574 minecraft:jungle_leaves[persistent=true]
setblock 346 217 582 minecraft:jungle_leaves[persistent=true]
setblock 346 217 596 minecraft:green_terracotta
setblock 346 217 597 minecraft:oak_log
fill 346 217 598 346 220 598 minecraft:green_terracotta
setblock 347 217 596 minecraft:oak_log
fill 347 217 597 347 220 597 minecraft:green_terracotta
fill 348 217 596 349 217 596 minecraft:green_terracotta
setblock 349 217 559 minecraft:oak_log
setblock 350 217 558 minecraft:oak_log
fill 350 217 559 351 217 559 minecraft:green_terracotta
setblock 350 217 597 minecraft:green_terracotta
setblock 350 217 598 minecraft:oak_log
fill 351 217 558 351 220 558 minecraft:green_terracotta
setblock 351 217 597 minecraft:oak_log
fill 351 217 598 354 217 598 minecraft:green_terracotta
fill 352 217 597 355 217 597 minecraft:green_terracotta
setblock 355 217 558 minecraft:oak_log
setblock 355 217 598 minecraft:oak_log
fill 356 217 558 356 220 558 minecraft:green_terracotta
setblock 356 217 597 minecraft:oak_log
fill 356 217 598 356 220 598 minecraft:green_terracotta
setblock 357 217 596 minecraft:oak_log
fill 357 217 597 357 220 597 minecraft:green_terracotta
fill 358 217 596 361 217 596 minecraft:green_terracotta
setblock 359 217 558 minecraft:green_terracotta
fill 359 217 595 362 217 595 minecraft:green_terracotta
setblock 360 217 558 minecraft:oak_log
fill 360 217 559 360 220 559 minecraft:green_terracotta
setblock 360 217 598 minecraft:oak_log
fill 361 217 558 361 220 558 minecraft:green_terracotta
setblock 361 217 597 minecraft:oak_log
fill 361 217 598 361 220 598 minecraft:green_terracotta
fill 362 217 594 363 217 594 minecraft:green_terracotta
setblock 362 217 596 minecraft:oak_log
fill 362 217 597 362 220 597 minecraft:green_terracotta
setblock 363 217 595 minecraft:oak_log
fill 363 217 596 363 220 596 minecraft:green_terracotta
setblock 364 217 559 minecraft:oak_log
setblock 364 217 594 minecraft:oak_log
fill 364 217 595 364 220 595 minecraft:green_terracotta
setblock 365 217 558 minecraft:oak_log
fill 365 217 559 365 219 559 minecraft:green_terracotta
fill 365 217 594 365 218 594 minecraft:green_terracotta
setblock 365 217 598 minecraft:oak_log
fill 366 217 558 366 220 558 minecraft:green_terracotta
setblock 366 217 593 minecraft:green_terracotta
setblock 366 217 597 minecraft:oak_log
fill 366 217 598 366 220 598 minecraft:green_terracotta
setblock 367 217 591 minecraft:oak_log
fill 367 217 592 367 218 592 minecraft:green_terracotta
setblock 367 217 596 minecraft:oak_log
fill 367 217 597 367 220 597 minecraft:green_terracotta
setblock 368 217 574 minecraft:green_terracotta
setblock 368 217 575 minecraft:oak_log
setblock 368 217 590 minecraft:oak_log
fill 368 217 591 368 219 591 minecraft:green_terracotta
setblock 368 217 595 minecraft:oak_log
fill 368 217 596 368 220 596 minecraft:green_terracotta
setblock 369 217 570 minecraft:green_terracotta
setblock 369 217 574 minecraft:oak_log
fill 369 217 575 369 220 575 minecraft:green_terracotta
setblock 369 217 579 minecraft:oak_log
fill 369 217 580 369 218 581 minecraft:green_terracotta
setblock 369 217 584 minecraft:oak_log
setblock 369 217 585 minecraft:green_terracotta
setblock 369 217 589 minecraft:oak_log
fill 369 217 590 369 219 590 minecraft:green_terracotta
setblock 369 217 594 minecraft:oak_log
fill 369 217 595 369 220 595 minecraft:green_terracotta
setblock 370 217 568 minecraft:oak_log
fill 370 217 569 370 218 569 minecraft:green_terracotta
setblock 370 217 573 minecraft:oak_log
fill 370 217 574 370 220 574 minecraft:green_terracotta
setblock 370 217 578 minecraft:oak_log
fill 370 217 579 370 220 579 minecraft:green_terracotta
setblock 370 217 583 minecraft:oak_log
fill 370 217 584 370 220 584 minecraft:green_terracotta
setblock 370 217 588 minecraft:oak_log
fill 370 217 589 370 220 589 minecraft:green_terracotta
setblock 370 217 593 minecraft:oak_log
fill 370 217 594 370 220 594 minecraft:green_terracotta
setblock 370 217 598 minecraft:oak_log
setblock 330 218 567 minecraft:oak_log
fill 330 218 568 330 218 571 minecraft:green_terracotta
setblock 330 218 572 minecraft:oak_log
fill 330 218 573 330 218 576 minecraft:green_terracotta
setblock 330 218 577 minecraft:oak_log
fill 330 218 578 330 221 578 minecraft:green_terracotta
setblock 330 218 582 minecraft:oak_log
fill 330 218 583 330 220 583 minecraft:green_terracotta
setblock 330 218 587 minecraft:oak_log
setblock 330 218 588 minecraft:green_terracotta
setblock 330 218 592 minecraft:oak_log
fill 330 218 593 330 219 593 minecraft:green_terracotta
setblock 330 218 597 minecraft:oak_log
fill 330 218 598 330 219 598 minecraft:green_terracotta
setblock 331 218 571 minecraft:oak_log
fill 331 218 572 331 220 572 minecraft:green_terracotta
setblock 331 218 576 minecraft:oak_log
fill 331 218 577 331 221 577 minecraft:green_terracotta
setblock 332 218 575 minecraft:oak_log
setblock 332 218 576 minecraft:green_terracotta
setblock 333 218 558 minecraft:oak_leaves[persistent=true]
fill 337 218 558 338 218 558 minecraft:green_terracotta
fill 337 218 577 338 236 579 minecraft:oak_log
fill 337 218 598 338 218 598 minecraft:green_terracotta
setblock 338 218 572 minecraft:oak_leaves[persistent=true]
fill 338 218 574 339 218 575 minecraft:oak_leaves[persistent=true]
fill 338 218 576 338 222 576 minecraft:dark_oak_log
setblock 339 218 558 minecraft:oak_log
fill 339 218 573 342 218 573 minecraft:oak_leaves[persistent=true]
setblock 339 218 597 minecraft:green_terracotta
setblock 339 218 598 minecraft:oak_log
fill 340 218 558 342 218 559 minecraft:green_terracotta
fill 340 218 574 342 218 574 minecraft:oak_leaves[persistent=true]
setblock 340 218 597 minecraft:oak_log
fill 340 218 598 340 221 598 minecraft:green_terracotta
fill 341 218 597 341 221 597 minecraft:green_terracotta
fill 342 218 596 342 219 596 minecraft:green_terracotta
setblock 343 218 558 minecraft:green_terracotta
setblock 343 218 559 minecraft:oak_log
fill 343 218 560 343 221 560 minecraft:green_terracotta
setblock 344 218 558 minecraft:oak_log
fill 344 218 559 344 221 559 minecraft:green_terracotta
fill 344 218 575 344 218 577 minecraft:jungle_leaves[persistent=true]
fill 344 218 579 344 218 581 minecraft:jungle_leaves[persistent=true]
setblock 344 218 598 minecraft:oak_log
fill 345 218 558 345 221 558 minecraft:green_terracotta
fill 345 218 576 345 218 577 minecraft:jungle_leaves[persistent=true]
fill 345 218 579 345 218 580 minecraft:jungle_leaves[persistent=true]
setblock 345 218 596 minecraft:green_terracotta
setblock 345 218 597 minecraft:oak_log
fill 345 218 598 345 221 598 minecraft:green_terracotta
setblock 346 218 596 minecraft:oak_log
fill 346 218 597 346 221 597 minecraft:green_terracotta
fill 347 218 596 348 218 596 minecraft:green_terracotta
setblock 348 218 559 minecraft:oak_log
setblock 349 218 558 minecraft:oak_log
fill 349 218 559 350 219 559 minecraft:green_terracotta
setblock 349 218 598 minecraft:oak_log
fill 350 218 558 350 221 558 minecraft:green_terracotta
setblock 350 218 597 minecraft:oak_log
fill 350 218 598 353 218 598 minecraft:green_terracotta
fill 351 218 597 354 218 597 minecraft:green_terracotta
setblock 354 218 558 minecraft:oak_log
setblock 354 218 598 minecraft:oak_log
fill 355 218 558 355 221 558 minecraft:green_terracotta
setblock 355 218 597 minecraft:oak_log
fill 355 218 598 355 221 598 minecraft:green_terracotta
setblock 356 218 596 minecraft:oak_log
fill 356 218 597 356 221 597 minecraft:green_terracotta
fill 357 218 596 360 218 596 minecraft:green_terracotta
setblock 359 218 558 minecraft:oak_log
fill 359 218 559 359 221 559 minecraft:green_terracotta
fill 359 218 595 361 218 595 minecraft:green_terracotta
setblock 359 218 598 minecraft:oak_log
fill 360 218 558 360 221 558 minecraft:green_terracotta
setblock 360 218 597 minecraft:oak_log
fill 360 218 598 360 221 598 minecraft:green_terracotta
setblock 361 218 596 minecraft:oak_log
fill 361 218 597 361 221 597 minecraft:green_terracotta
setblock 362 218 594 minecraft:green_terracotta
setblock 362 218 595 minecraft:oak_log
fill 362 218 596 362 221 596 minecraft:green_terracotta
setblock 363 218 558 minecraft:green_terracotta
setblock 363 218 559 minecraft:oak_log
setblock 363 218 594 minecraft:oak_log
fill 363 218 595 363 221 595 minecraft:green_terracotta
setblock 364 218 558 minecraft:oak_log
fill 364 218 559 364 221 559 minecraft:green_terracotta
setblock 364 218 594 minecraft:green_terracotta
setblock 364 218 598 minecraft:oak_log
fill 365 218 558 365 221 558 minecraft:green_terracotta
setblock 365 218 597 minecraft:oak_log
fill 365 218 598 365 221 598 minecraft:green_terracotta
setblock 366 218 596 minecraft:oak_log
fill 366 218 597 366 221 597 minecraft:green_terracotta
setblock 367 218 591 minecraft:green_terracotta
setblock 367 218 595 minecraft:oak_log
fill 367 218 596 367 221 596 minecraft:green_terracotta
setblock 368 218 589 minecraft:oak_log
setblock 368 218 590 minecraft:green_terracotta
setblock 368 218 594 minecraft:oak_log
fill 368 218 595 368 220 595 minecraft:green_terracotta
setblock 369 218 558 minecraft:oak_log
setblock 369 218 573 minecraft:oak_log
fill 369 218 574 369 220 574 minecraft:green_terracotta
setblock 369 218 577 minecraft:green_terracotta
setblock 369 218 578 minecraft:oak_log
fill 369 218 579 369 221 579 minecraft:green_terracotta
setblock 369 218 588 minecraft:oak_log
fill 369 218 589 369 219 589 minecraft:green_terracotta
setblock 369 218 593 minecraft:oak_log
fill 369 218 594 369 221 594 minecraft:green_terracotta
setblock 369 218 598 minecraft:oak_log
setblock 370 218 565 minecraft:oak_leaves[persistent=true]
setblock 370 218 572 minecraft:oak_log
fill 370 218 573 370 221 573 minecraft:green_terracotta
setblock 370 218 577 minecraft:oak_log
fill 370 218 578 370 221 578 minecraft:green_terracotta
setblock 370 218 582 minecraft:oak_log
fill 370 218 583 370 221 583 minecraft:green_terracotta
setblock 370 218 587 minecraft:oak_log
fill 370 218 588 370 220 588 minecraft:green_terracotta
setblock 370 218 592 minecraft:oak_log
fill 370 218 593 370 221 593 minecraft:green_terracotta
setblock 370 218 597 minecraft:oak_log
fill 370 218 598 370 221 598 minecraft:green_terracotta
fill 330 219 568 330 219 570 minecraft:green_terracotta
setblock 330 219 571 minecraft:oak_log
fill 330 219 572 330 219 575 minecraft:green_terracotta
setblock 330 219 576 minecraft:oak_log
fill 330 219 577 330 222 577 minecraft:green_terracotta
setblock 330 219 580 minecraft:green_terracotta
setblock 330 219 581 minecraft:oak_log
fill 330 219 582 330 222 582 minecraft:green_terracotta
setblock 330 219 591 minecraft:oak_log
setblock 330 219 592 minecraft:green_terracotta
setblock 330 219 596 minecraft:oak_log
fill 330 219 597 330 220 597 minecraft:green_terracotta
setblock 331 219 571 minecraft:green_terracotta
setblock 331 219 575 minecraft:oak_log
fill 331 219 576 331 222 576 minecraft:green_terracotta
fill 336 219 598 337 219 598 minecraft:green_terracotta
setblock 337 219 558 minecraft:green_terracotta
fill 337 219 575 337 222 576 minecraft:dark_oak_log
setblock 338 219 558 minecraft:oak_log
fill 338 219 574 341 219 574 minecraft:oak_leaves[persistent=true]
fill 338 219 575 338 222 575 minecraft:dark_oak_log
setblock 338 219 598 minecraft:oak_log
fill 339 219 558 341 219 559 minecraft:green_terracotta
fill 339 219 573 341 219 573 minecraft:oak_leaves[persistent=true]
fill 339 219 575 340 219 575 minecraft:oak_leaves[persistent=true]
fill 339 219 576 341 222 576 minecraft:dark_oak_log
fill 339 219 577 339 236 579 minecraft:oak_log
setblock 339 219 597 minecraft:oak_log
fill 339 219 598 339 222 598 minecraft:green_terracotta
fill 340 219 577 340 222 577 minecraft:dark_oak_log
fill 340 219 597 340 222 597 minecraft:green_terracotta
fill 341 219 575 341 222 575 minecraft:dark_oak_log
setblock 342 219 558 minecraft:green_terracotta
setblock 342 219 559 minecraft:oak_log
fill 342 219 560 342 222 560 minecraft:green_terracotta
setblock 343 219 558 minecraft:oak_log
fill 343 219 559 343 222 559 minecraft:green_terracotta
setblock 343 219 598 minecraft:oak_log
fill 344 219 558 344 222 558 minecraft:green_terracotta
setblock 344 219 597 minecraft:oak_log
fill 344 219 598 344 222 598 minecraft:green_terracotta
setblock 345 219 560 minecraft:green_terracotta
setblock 345 219 596 minecraft:oak_log
fill 345 219 597 345 222 597 minecraft:green_terracotta
setblock 346 219 560 minecraft:oak_log
fill 346 219 596 347 219 596 minecraft:green_terracotta
setblock 347 219 559 minecraft:oak_log
setblock 348 219 558 minecraft:oak_log
fill 348 219 559 348 222 559 minecraft:green_terracotta
setblock 348 219 598 minecraft:oak_log
fill 349 219 558 349 222 558 minecraft:green_terracotta
setblock 349 219 597 minecraft:oak_log
fill 349 219 598 352 219 598 minecraft:green_terracotta
fill 350 219 597 353 219 597 minecraft:green_terracotta
setblock 353 219 558 minecraft:oak_log
setblock 353 219 598 minecraft:oak_log
fill 354 219 558 354 222 558 minecraft:green_terracotta
setblock 354 219 597 minecraft:oak_log
fill 354 219 598 354 222 598 minecraft:green_terracotta
fill 355 219 597 355 222 597 minecraft:green_terracotta
fill 356 219 596 359 219 596 minecraft:green_terracotta
setblock 358 219 558 minecraft:oak_log
fill 358 219 559 358 222 559 minecraft:green_terracotta
setblock 358 219 598 minecraft:oak_log
fill 359 219 558 359 222 558 minecraft:green_terracotta
fill 359 219 595 360 219 595 minecraft:green_terracotta
setblock 359 219 597 minecraft:oak_log
fill 359 219 598 359 222 598 minecraft:green_terracotta
setblock 360 219 596 minecraft:oak_log
fill 360 219 597 360 222 597 minecraft:green_terracotta
setblock 361 219 559 minecraft:green_terracotta
setblock 361 219 595 minecraft:oak_log
fill 361 219 596 361 222 596 minecraft:green_terracotta
setblock 362 219 559 minecraft:oak_log
fill 362 219 595 362 222 595 minecraft:green_terracotta
setblock 363 219 558 minecraft:oak_log
fill 363 219 559 363 222 559 minecraft:green_terracotta
setblock 363 219 598 minecraft:oak_log
fill 364 219 558 364 222 558 minecraft:green_terracotta
setblock 364 219 597 minecraft:oak_log
fill 364 219 598 364 222 598 minecraft:green_terracotta
setblock 365 219 596 minecraft:oak_log
fill 365 219 597 365 222 597 minecraft:green_terracotta
setblock 366 219 595 minecraft:oak_log
fill 366 219 596 366 222 596 minecraft:green_terracotta
setblock 367 219 594 minecraft:oak_log
setblock 367 219 595 minecraft:green_terracotta
setblock 368 219 558 minecraft:oak_log
setblock 368 219 593 minecraft:oak_log
fill 368 219 594 368 220 594 minecraft:green_terracotta
setblock 368 219 598 minecraft:oak_log
setblock 369 219 573 minecraft:green_terracotta
setblock 369 219 577 minecraft:oak_log
fill 369 219 578 369 222 578 minecraft:green_terracotta
fill 369 219 580 369 220 580 minecraft:green_terracotta
setblock 369 219 592 minecraft:oak_log
fill 369 219 593 369 220 593 minecraft:green_terracotta
setblock 369 219 597 minecraft:oak_log
fill 369 219 598 369 222 598 minecraft:green_terracotta
setblock 370 219 559 minecraft:oak_leaves[persistent=true]
setblock 370 219 571 minecraft:oak_log
fill 370 219 572 370 220 572 minecraft:green_terracotta
setblock 370 219 576 minecraft:oak_log
fill 370 219 577 370 222 577 minecraft:green_terracotta
setblock 370 219 581 minecraft:oak_log
fill 370 219 582 370 222 582 minecraft:green_terracotta
setblock 370 219 586 minecraft:oak_log
setblock 370 219 587 minecraft:green_terracotta
setblock 370 219 591 minecraft:oak_log
fill 370 219 592 370 221 592 minecraft:green_terracotta
setblock 370 219 596 minecraft:oak_log
fill 370 219 597 370 222 597 minecraft:green_terracotta
setblock 330 220 559 minecraft:oak_leaves[persistent=true]
setblock 330 220 570 minecraft:oak_log
fill 330 220 571 330 220 574 minecraft:green_terracotta
setblock 330 220 575 minecraft:oak_log
fill 330 220 576 330 223 576 minecraft:green_terracotta
setblock 330 220 580 minecraft:oak_log
fill 330 220 581 330 223 581 minecraft:green_terracotta
setblock 330 220 584 minecraft:oak_leaves[persistent=true]
setblock 330 220 595 minecraft:oak_log
setblock 330 220 596 minecraft:green_terracotta
setblock 331 220 574 minecraft:oak_log
fill 331 220 575 331 222 575 minecraft:green_terracotta
setblock 331 220 579 minecraft:oak_log
setblock 335 220 598 minecraft:oak_leaves[persistent=true]
setblock 336 220 558 minecraft:green_terracotta
setblock 336 220 598 minecraft:green_terracotta
setblock 337 220 558 minecraft:oak_log
fill 337 220 574 341 222 574 minecraft:dark_oak_log
setblock 337 220 598 minecraft:oak_log
fill 338 220 558 341 220 558 minecraft:green_terracotta
fill 338 220 573 340 222 573 minecraft:dark_oak_log
fill 338 220 598 338 223 598 minecraft:green_terracotta
fill 339 220 559 340 220 559 minecraft:green_terracotta
fill 339 220 575 340 222 575 minecraft:dark_oak_log
fill 339 220 597 339 223 597 minecraft:green_terracotta
setblock 341 220 559 minecraft:oak_log
fill 341 220 577 341 222 577 minecraft:dark_oak_log
setblock 342 220 558 minecraft:oak_log
fill 342 220 559 342 223 559 minecraft:green_terracotta
setblock 342 220 598 minecraft:oak_log
fill 343 220 558 343 223 558 minecraft:green_terracotta
setblock 343 220 597 minecraft:oak_log
fill 343 220 598 343 223 598 minecraft:green_terracotta
setblock 344 220 596 minecraft:oak_log
fill 344 220 597 344 223 597 minecraft:green_terracotta
setblock 345 220 560 minecraft:oak_log
setblock 345 220 596 minecraft:green_terracotta
setblock 346 220 559 minecraft:oak_log
setblock 347 220 558 minecraft:oak_log
fill 347 220 559 347 223 559 minecraft:green_terracotta
setblock 347 220 598 minecraft:oak_log
fill 348 220 558 348 223 558 minecraft:green_terracotta
setblock 348 220 597 minecraft:oak_log
fill 348 220 598 351 220 598 minecraft:green_terracotta
fill 349 220 559 349 221 559 minecraft:green_terracotta
fill 349 220 597 352 220 597 minecraft:green_terracotta
setblock 352 220 558 minecraft:oak_log
setblock 352 220 598 minecraft:oak_log
fill 353 220 558 353 223 558 minecraft:green_terracotta
setblock 353 220 597 minecraft:oak_log
fill 353 220 598 353 223 598 minecraft:green_terracotta
fill 354 220 597 354 223 597 minecraft:green_terracotta
fill 356 220 596 358 220 596 minecraft:green_terracotta
setblock 357 220 558 minecraft:oak_log
setblock 357 220 598 minecraft:oak_log
fill 358 220 558 358 223 558 minecraft:green_terracotta
setblock 358 220 597 minecraft:oak_log
fill 358 220 598 358 223 598 minecraft:green_terracotta
setblock 359 220 595 minecraft:green_terracotta
setblock 359 220 596 minecraft:oak_log
fill 359 220 597 359 223 597 minecraft:green_terracotta
setblock 360 220 595 minecraft:oak_log
fill 360 220 596 360 223 596 minecraft:green_terracotta
setblock 361 220 559 minecraft:oak_log
fill 361 220 595 361 222 595 minecraft:green_terracotta
setblock 362 220 558 minecraft:oak_log
fill 362 220 559 362 223 559 minecraft:green_terracotta
setblock 362 220 598 minecraft:oak_log
fill 363 220 558 363 223 558 minecraft:green_terracotta
setblock 363 220 597 minecraft:oak_log
fill 363 220 598 363 223 598 minecraft:green_terracotta
setblock 364 220 596 minecraft:oak_log
fill 364 220 597 364 223 597 minecraft:green_terracotta
setblock 365 220 595 minecraft:oak_log
fill 365 220 596 365 222 596 minecraft:green_terracotta
setblock 366 220 595 minecraft:green_terracotta
setblock 367 220 558 minecraft:oak_log
setblock 367 220 598 minecraft:oak_log
setblock 368 220 558 minecraft:green_terracotta
setblock 368 220 597 minecraft:oak_log
fill 368 220 598 368 223 598 minecraft:green_terracotta
setblock 369 220 576 minecraft:oak_log
fill 369 220 577 369 221 577 minecraft:green_terracotta
setblock 369 220 591 minecraft:oak_log
setblock 369 220 592 minecraft:green_terracotta
setblock 369 220 596 minecraft:oak_log
fill 369 220 597 369 221 597 minecraft:green_terracotta
setblock 370 220 575 minecraft:oak_log
fill 370 220 576 370 223 576 minecraft:green_terracotta
setblock 370 220 580 minecraft:oak_log
fill 370 220 581 370 223 581 minecraft:green_terracotta
setblock 370 220 590 minecraft:oak_log
fill 370 220 591 370 221 591 minecraft:green_terracotta
setblock 370 220 595 minecraft:oak_log
fill 370 220 596 370 222 596 minecraft:green_terracotta
setblock 330 221 565 minecraft:oak_leaves[persistent=true]
fill 330 221 571 330 221 573 minecraft:green_terracotta
setblock 330 221 574 minecraft:oak_log
fill 330 221 575 330 224 575 minecraft:green_terracotta
setblock 330 221 579 minecraft:oak_log
fill 330 221 580 330 224 580 minecraft:green_terracotta
setblock 330 221 590 minecraft:oak_leaves[persistent=true]
setblock 331 221 573 minecraft:oak_log
setblock 331 221 574 minecraft:green_terracotta
setblock 331 221 578 minecraft:oak_log
setblock 331 221 579 minecraft:green_terracotta
setblock 334 221 558 minecraft:oak_leaves[persistent=true]
setblock 336 221 558 minecraft:oak_log
fill 336 221 575 336 222 576 minecraft:dark_oak_log
setblock 336 221 598 minecraft:oak_log
fill 337 221 558 340 221 558 minecraft:green_terracotta
fill 337 221 598 337 224 598 minecraft:green_terracotta
fill 338 221 559 339 221 559 minecraft:green_terracotta
setblock 340 221 559 minecraft:oak_log
fill 340 221 578 340 222 578 minecraft:dark_oak_log
setblock 341 221 558 minecraft:oak_log
fill 341 221 559 341 223 560 minecraft:green_terracotta
fill 341 221 573 341 222 573 minecraft:dark_oak_log
setblock 341 221 598 minecraft:oak_log
fill 342 221 558 342 224 558 minecraft:green_terracotta
fill 342 221 575 342 222 576 minecraft:dark_oak_log
setblock 342 221 597 minecraft:oak_log
fill 342 221 598 342 224 598 minecraft:green_terracotta
fill 343 221 597 343 224 597 minecraft:green_terracotta
setblock 344 221 560 minecraft:oak_log
setblock 345 221 559 minecraft:oak_log
setblock 346 221 558 minecraft:oak_log
fill 346 221 559 346 224 559 minecraft:green_terracotta
setblock 346 221 598 minecraft:oak_log
fill 347 221 558 347 224 558 minecraft:green_terracotta
setblock 347 221 597 minecraft:oak_log
fill 347 221 598 350 221 598 minecraft:green_terracotta
fill 348 221 597 351 221 597 minecraft:green_terracotta
setblock 351 221 558 minecraft:oak_log
setblock 351 221 598 minecraft:oak_log
fill 352 221 558 352 224 558 minecraft:green_terracotta
setblock 352 221 597 minecraft:oak_log
fill 352 221 598 352 224 598 minecraft:green_terracotta
fill 353 221 597 353 224 597 minecraft:green_terracotta
setblock 356 221 558 minecraft:oak_log
setblock 356 221 598 minecraft:oak_log
fill 357 221 558 357 223 559 minecraft:green_terracotta
setblock 357 221 596 minecraft:green_terracotta
setblock 357 221 597 minecraft:oak_log
fill 357 221 598 357 224 598 minecraft:green_terracotta
setblock 358 221 596 minecraft:oak_log
fill 358 221 597 358 224 597 minecraft:green_terracotta
fill 359 221 596 359 224 596 minecraft:green_terracotta
setblock 360 221 559 minecraft:oak_log
setblock 360 221 595 minecraft:green_terracotta
setblock 361 221 558 minecraft:oak_log
fill 361 221 559 361 224 559 minecraft:green_terracotta
setblock 361 221 598 minecraft:oak_log
fill 362 221 558 362 224 558 minecraft:green_terracotta
setblock 362 221 597 minecraft:oak_log
fill 362 221 598 362 224 598 minecraft:green_terracotta
setblock 363 221 596 minecraft:oak_log
fill 363 221 597 363 224 597 minecraft:green_terracotta
setblock 364 221 595 minecraft:oak_log
fill 364 221 596 364 223 596 minecraft:green_terracotta
setblock 366 221 558 minecraft:oak_log
setblock 366 221 598 minecraft:oak_log
fill 367 221 558 367 222 558 minecraft:green_terracotta
setblock 367 221 597 minecraft:oak_log
fill 367 221 598 367 224 598 minecraft:green_terracotta
fill 368 221 597 368 222 597 minecraft:green_terracotta
setblock 369 221 576 minecraft:green_terracotta
setblock 369 221 595 minecraft:oak_log
setblock 369 221 596 minecraft:green_terracotta
setblock 370 221 566 minecraft:oak_leaves[persistent=true]
setblock 370 221 574 minecraft:oak_log
fill 370 221 575 370 224 575 minecraft:green_terracotta
setblock 370 221 579 minecraft:oak_log
fill 370 221 580 370 224 580 minecraft:green_terracotta
setblock 370 221 594 minecraft:oak_log
fill 370 221 595 370 222 595 minecraft:green_terracotta
setblock 330 222 571 minecraft:oak_leaves[persistent=true]
setblock 330 222 572 minecraft:green_terracotta
setblock 330 222 573 minecraft:oak_log
fill 330 222 574 330 225 574 minecraft:green_terracotta
setblock 330 222 578 minecraft:oak_log
fill 330 222 579 330 225 579 minecraft:green_terracotta
setblock 330 222 596 minecraft:oak_leaves[persistent=true]
setblock 331 222 577 minecraft:oak_log
fill 331 222 578 331 225 578 minecraft:green_terracotta
setblock 335 222 558 minecraft:oak_log
fill 336 222 558 339 222 558 minecraft:green_terracotta
setblock 336 222 577 minecraft:dark_oak_log
fill 336 222 598 336 225 598 minecraft:green_terracotta
fill 337 222 559 338 222 559 minecraft:green_terracotta
fill 338 222 572 340 222 572 minecraft:dark_oak_log
setblock 339 222 559 minecraft:oak_log
setblock 340 222 558 minecraft:oak_log
fill 340 222 559 340 224 560 minecraft:green_terracotta
setblock 340 222 598 minecraft:oak_log
fill 341 222 558 341 225 558 minecraft:green_terracotta
setblock 341 222 578 minecraft:dark_oak_log
setblock 341 222 597 minecraft:oak_log
fill 341 222 598 341 225 598 minecraft:green_terracotta
setblock 342 222 574 minecraft:dark_oak_log
setblock 342 222 577 minecraft:dark_oak_log
fill 342 222 597 342 225 597 minecraft:green_terracotta
setblock 343 222 560 minecraft:oak_log
setblock 344 222 559 minecraft:oak_log
fill 344 222 560 344 225 560 minecraft:green_terracotta
setblock 345 222 558 minecraft:oak_log
fill 345 222 559 345 225 559 minecraft:green_terracotta
setblock 345 222 598 minecraft:oak_log
fill 346 222 558 346 225 558 minecraft:green_terracotta
fill 346 222 569 346 223 569 minecraft:glowstone
setblock 346 222 597 minecraft:oak_log
fill 346 222 598 349 222 598 minecraft:green_terracotta
setblock 347 222 597 minecraft:green_terracotta
setblock 350 222 558 minecraft:oak_log
setblock 350 222 598 minecraft:oak_log
fill 351 222 558 351 225 558 minecraft:green_terracotta
fill 351 222 598 351 225 598 minecraft:green_terracotta
setblock 355 222 558 minecraft:oak_log
setblock 355 222 598 minecraft:oak_log
fill 356 222 558 356 225 558 minecraft:green_terracotta
setblock 356 222 597 minecraft:oak_log
fill 356 222 598 356 225 598 minecraft:green_terracotta
setblock 357 222 596 minecraft:oak_log
fill 357 222 597 357 225 597 minecraft:green_terracotta
fill 358 222 596 358 225 596 minecraft:green_terracotta
setblock 359 222 559 minecraft:oak_log
setblock 360 222 558 minecraft:oak_log
fill 360 222 559 360 225 559 minecraft:green_terracotta
setblock 360 222 598 minecraft:oak_log
fill 361 222 558 361 225 558 minecraft:green_terracotta
setblock 361 222 597 minecraft:oak_log
fill 361 222 598 361 225 598 minecraft:green_terracotta
setblock 362 222 596 minecraft:oak_log
fill 362 222 597 362 225 597 minecraft:green_terracotta
fill 363 222 596 363 224 596 minecraft:green_terracotta
setblock 365 222 558 minecraft:oak_log
setblock 365 222 598 minecraft:oak_log
fill 366 222 558 366 225 558 minecraft:green_terracotta
setblock 366 222 597 minecraft:oak_log
fill 366 222 598 366 225 598 minecraft:green_terracotta
fill 367 222 597 367 223 597 minecraft:green_terracotta
setblock 369 222 579 minecraft:oak_log
setblock 370 222 560 minecraft:oak_leaves[persistent=true]
setblock 370 222 574 minecraft:green_terracotta
setblock 370 222 578 minecraft:oak_log
fill 370 222 579 370 225 579 minecraft:green_terracotta
setblock 370 222 583 minecraft:oak_log
setblock 370 222 585 minecraft:oak_leaves[persistent=true]
setblock 370 222 594 minecraft:green_terracotta
setblock 370 222 598 minecraft:oak_log
setblock 330 223 558 minecraft:oak_leaves[persistent=true]
fill 330 223 573 330 224 573 minecraft:green_terracotta
setblock 330 223 577 minecraft:oak_log
fill 330 223 578 330 226 578 minecraft:green_terracotta
setblock 330 223 582 minecraft:oak_log
setblock 331 223 576 minecraft:oak_log
fill 331 223 577 331 226 577 minecraft:green_terracotta
setblock 334 223 558 minecraft:oak_log
setblock 334 223 598 minecraft:oak_leaves[persistent=true]
fill 335 223 558 338 223 558 minecraft:green_terracotta
setblock 337 223 559 minecraft:green_terracotta
fill 337 223 560 338 223 563 minecraft:oak_log
setblock 338 223 559 minecraft:oak_log
setblock 339 223 558 minecraft:oak_log
fill 339 223 559 339 225 560 minecraft:green_terracotta
fill 339 223 561 339 225 563 minecraft:oak_log
fill 339 223 575 339 225 575 minecraft:oak_log
setblock 339 223 598 minecraft:oak_log
fill 340 223 558 340 226 558 minecraft:green_terracotta
setblock 340 223 597 minecraft:oak_log
fill 340 223 598 340 226 598 minecraft:green_terracotta
fill 341 223 597 341 226 597 minecraft:green_terracotta
setblock 342 223 560 minecraft:oak_log
setblock 343 223 559 minecraft:oak_log
fill 343 223 560 343 226 560 minecraft:green_terracotta
setblock 344 223 558 minecraft:oak_log
fill 344 223 559 344 226 559 minecraft:green_terracotta
setblock 344 223 598 minecraft:oak_log
fill 345 223 558 345 226 558 minecraft:green_terracotta
setblock 345 223 597 minecraft:oak_log
fill 345 223 598 348 223 598 minecraft:green_terracotta
setblock 346 223 597 minecraft:green_terracotta
setblock 348 223 559 minecraft:oak_log
setblock 349 223 558 minecraft:oak_log
setblock 349 223 598 minecraft:oak_log
fill 350 223 558 350 226 558 minecraft:green_terracotta
fill 350 223 598 350 226 598 minecraft:green_terracotta
setblock 354 223 558 minecraft:oak_log
setblock 354 223 598 minecraft:oak_log
fill 355 223 558 355 226 558 minecraft:green_terracotta
setblock 355 223 597 minecraft:oak_log
fill 355 223 598 355 226 598 minecraft:green_terracotta
fill 356 223 559 356 224 559 minecraft:green_terracotta
fill 356 223 597 356 226 597 minecraft:green_terracotta
fill 357 223 596 357 226 596 minecraft:green_terracotta
setblock 358 223 559 minecraft:oak_log
setblock 359 223 558 minecraft:oak_log
fill 359 223 559 359 226 559 minecraft:green_terracotta
setblock 359 223 598 minecraft:oak_log
fill 360 223 558 360 226 558 minecraft:green_terracotta
setblock 360 223 597 minecraft:oak_log
fill 360 223 598 360 226 598 minecraft:green_terracotta
setblock 361 223 596 minecraft:oak_log
fill 361 223 597 361 226 597 minecraft:green_terracotta
fill 362 223 596 362 225 596 minecraft:green_terracotta
setblock 363 223 559 minecraft:oak_log
setblock 364 223 558 minecraft:oak_log
setblock 364 223 598 minecraft:oak_log
fill 365 223 558 365 226 558 minecraft:green_terracotta
setblock 365 223 597 minecraft:oak_log
fill 365 223 598 365 226 598 minecraft:green_terracotta
fill 366 223 597 366 224 597 minecraft:green_terracotta
setblock 369 223 598 minecraft:oak_log
setblock 370 223 577 minecraft:oak_log
fill 370 223 578 370 226 578 minecraft:green_terracotta
setblock 370 223 582 minecraft:oak_log
fill 370 223 583 370 226 583 minecraft:green_terracotta
setblock 330 224 564 minecraft:oak_leaves[persistent=true]
setblock 330 224 576 minecraft:oak_log
fill 330 224 577 330 227 577 minecraft:green_terracotta
setblock 330 224 581 minecraft:oak_log
fill 330 224 582 330 227 582 minecraft:green_terracotta
setblock 330 224 583 minecraft:oak_leaves[persistent=true]
setblock 332 224 560 minecraft:light[level=14]
setblock 332 224 568 minecraft:light[level=14]
setblock 332 224 576 minecraft:light[level=14]
setblock 332 224 584 minecraft:light[level=14]
setblock 332 224 592 minecraft:light[level=14]
fill 334 224 558 337 224 558 minecraft:green_terracotta
setblock 336 224 559 minecraft:green_terracotta
fill 337 224 559 337 224 563 minecraft:oak_log
setblock 338 224 558 minecraft:oak_log
fill 338 224 559 338 226 560 minecraft:green_terracotta
fill 338 224 561 338 226 563 minecraft:oak_log
setblock 338 224 598 minecraft:oak_log
fill 339 224 558 339 227 558 minecraft:green_terracotta
setblock 339 224 597 minecraft:oak_log
fill 339 224 598 339 227 598 minecraft:green_terracotta
setblock 340 224 568 minecraft:light[level=14]
setblock 340 224 576 minecraft:light[level=14]
setblock 340 224 584 minecraft:light[level=14]
setblock 340 224 592 minecraft:light[level=14]
fill 340 224 597 340 227 597 minecraft:green_terracotta
setblock 341 224 559 minecraft:green_terracotta
setblock 341 224 560 minecraft:oak_log
setblock 342 224 559 minecraft:oak_log
fill 342 224 560 342 227 560 minecraft:green_terracotta
setblock 343 224 558 minecraft:oak_log
fill 343 224 559 343 227 559 minecraft:green_terracotta
setblock 343 224 598 minecraft:oak_log
fill 344 224 558 344 227 558 minecraft:green_terracotta
setblock 344 224 597 minecraft:oak_log
fill 344 224 598 347 224 598 minecraft:green_terracotta
setblock 347 224 559 minecraft:oak_log
setblock 348 224 558 minecraft:oak_log
fill 348 224 559 348 227 559 minecraft:green_terracotta
setblock 348 224 560 minecraft:light[level=14]
setblock 348 224 568 minecraft:light[level=14]
setblock 348 224 576 minecraft:light[level=14]
setblock 348 224 584 minecraft:light[level=14]
setblock 348 224 592 minecraft:light[level=14]
setblock 348 224 598 minecraft:oak_log
fill 349 224 558 349 227 558 minecraft:green_terracotta
fill 349 224 598 349 227 598 minecraft:green_terracotta
setblock 353 224 558 minecraft:oak_log
fill 353 224 589 354 225 590 minecraft:oak_leaves[persistent=true]
setblock 353 224 598 minecraft:oak_log
fill 354 224 558 354 227 558 minecraft:green_terracotta
setblock 354 224 597 minecraft:oak_log
fill 354 224 598 354 227 598 minecraft:green_terracotta
fill 355 224 559 355 225 559 minecraft:green_terracotta
fill 355 224 597 355 227 597 minecraft:green_terracotta
setblock 356 224 560 minecraft:light[level=14]
setblock 356 224 568 minecraft:light[level=14]
setblock 356 224 576 minecraft:light[level=14]
setblock 356 224 584 minecraft:light[level=14]
setblock 356 224 592 minecraft:light[level=14]
setblock 357 224 558 minecraft:green_terracotta
setblock 357 224 559 minecraft:oak_log
setblock 358 224 558 minecraft:oak_log
fill 358 224 559 358 227 559 minecraft:green_terracotta
setblock 358 224 598 minecraft:oak_log
fill 359 224 558 359 227 558 minecraft:green_terracotta
setblock 359 224 597 minecraft:oak_log
fill 359 224 598 359 227 598 minecraft:green_terracotta
setblock 360 224 596 minecraft:oak_log
fill 360 224 597 360 227 597 minecraft:green_terracotta
fill 361 224 596 361 227 596 minecraft:green_terracotta
setblock 362 224 559 minecraft:oak_log
setblock 363 224 558 minecraft:oak_log
fill 363 224 559 363 227 559 minecraft:green_terracotta
setblock 363 224 598 minecraft:oak_log
fill 364 224 558 364 227 558 minecraft:green_terracotta
setblock 364 224 560 minecraft:light[level=14]
setblock 364 224 568 minecraft:light[level=14]
setblock 364 224 576 minecraft:light[level=14]
setblock 364 224 584 minecraft:light[level=14]
setblock 364 224 592 minecraft:light[level=14]
setblock 364 224 597 minecraft:oak_log
fill 364 224 598 364 227 598 minecraft:green_terracotta
fill 365 224 597 365 225 597 minecraft:green_terracotta
setblock 368 224 598 minecraft:oak_log
fill 370 224 567 370 225 567 minecraft:oak_leaves[persistent=true]
setblock 370 224 573 minecraft:oak_leaves[persistent=true]
setblock 370 224 576 minecraft:oak_log
fill 370 224 577 370 227 577 minecraft:green_terracotta
setblock 370 224 581 minecraft:oak_log
fill 370 224 582 370 227 582 minecraft:green_terracotta
setblock 370 224 592 minecraft:oak_leaves[persistent=true]
setblock 330 225 570 minecraft:oak_leaves[persistent=true]
setblock 330 225 575 minecraft:oak_log
fill 330 225 576 330 228 576 minecraft:green_terracotta
setblock 330 225 580 minecraft:oak_log
fill 330 225 581 330 228 581 minecraft:green_terracotta
setblock 330 225 589 minecraft:oak_leaves[persistent=true]
setblock 331 225 579 minecraft:oak_log
fill 333 225 558 336 225 558 minecraft:green_terracotta
setblock 335 225 559 minecraft:green_terracotta
fill 335 225 598 335 226 598 minecraft:green_terracotta
setblock 336 225 559 minecraft:oak_log
setblock 337 225 558 minecraft:oak_log
fill 337 225 559 337 227 560 minecraft:green_terracotta
fill 337 225 561 337 227 563 minecraft:oak_log
setblock 337 225 598 minecraft:oak_log
fill 338 225 558 338 228 558 minecraft:green_terracotta
fill 338 225 598 338 228 598 minecraft:green_terracotta
fill 339 225 597 339 228 597 minecraft:green_terracotta
setblock 340 225 559 minecraft:green_terracotta
setblock 340 225 560 minecraft:oak_log
setblock 341 225 559 minecraft:oak_log
fill 341 225 560 341 228 560 minecraft:green_terracotta
setblock 342 225 558 minecraft:oak_log
fill 342 225 559 342 228 559 minecraft:green_terracotta
setblock 342 225 598 minecraft:oak_log
fill 343 225 558 343 228 558 minecraft:green_terracotta
setblock 343 225 597 minecraft:oak_log
fill 343 225 598 346 225 598 minecraft:green_terracotta
setblock 346 225 559 minecraft:oak_log
setblock 347 225 558 minecraft:oak_log
fill 347 225 559 347 228 559 minecraft:green_terracotta
setblock 347 225 598 minecraft:oak_log
fill 348 225 558 348 228 558 minecraft:green_terracotta
fill 348 225 598 348 228 598 minecraft:green_terracotta
fill 349 225 559 349 226 559 minecraft:green_terracotta
setblock 352 225 558 minecraft:oak_log
setblock 352 225 598 minecraft:oak_log
fill 353 225 558 353 227 559 minecraft:green_terracotta
setblock 353 225 597 minecraft:oak_log
fill 353 225 598 353 228 598 minecraft:green_terracotta
fill 354 225 559 354 226 559 minecraft:green_terracotta
fill 354 225 597 354 228 597 minecraft:green_terracotta
setblock 356 225 559 minecraft:oak_log
setblock 357 225 558 minecraft:oak_log
fill 357 225 559 357 228 559 minecraft:green_terracotta
setblock 357 225 598 minecraft:oak_log
fill 358 225 558 358 228 558 minecraft:green_terracotta
setblock 358 225 597 minecraft:oak_log
fill 358 225 598 358 228 598 minecraft:green_terracotta
setblock 359 225 596 minecraft:oak_log
fill 359 225 597 359 228 597 minecraft:green_terracotta
fill 360 225 596 360 228 596 minecraft:green_terracotta
setblock 361 225 559 minecraft:oak_log
setblock 362 225 558 minecraft:oak_log
fill 362 225 559 362 228 559 minecraft:green_terracotta
fill 362 225 568 363 226 569 minecraft:glowstone
setblock 362 225 598 minecraft:oak_log
fill 363 225 558 363 228 558 minecraft:green_terracotta
setblock 363 225 597 minecraft:oak_log
fill 363 225 598 363 228 598 minecraft:green_terracotta
fill 364 225 569 364 226 569 minecraft:glowstone
fill 364 225 597 364 227 597 minecraft:green_terracotta
setblock 367 225 598 minecraft:oak_log
fill 369 225 579 369 225 580 minecraft:green_terracotta
setblock 370 225 561 minecraft:oak_leaves[persistent=true]
setblock 370 225 575 minecraft:oak_log
fill 370 225 576 370 228 576 minecraft:green_terracotta
setblock 370 225 580 minecraft:oak_log
fill 370 225 581 370 228 581 minecraft:green_terracotta
setblock 370 225 584 minecraft:green_terracotta
setblock 370 225 586 minecraft:oak_leaves[persistent=true]
setblock 330 226 574 minecraft:oak_log
fill 330 226 575 330 229 575 minecraft:green_terracotta
setblock 330 226 579 minecraft:oak_log
fill 330 226 580 331 228 580 minecraft:green_terracotta
setblock 330 226 583 minecraft:green_terracotta
setblock 330 226 595 minecraft:oak_leaves[persistent=true]
setblock 331 226 558 minecraft:oak_log
setblock 331 226 578 minecraft:oak_log
fill 331 226 579 331 229 579 minecraft:green_terracotta
fill 332 226 558 335 226 558 minecraft:green_terracotta
fill 333 226 598 333 227 598 minecraft:oak_leaves[persistent=true]
setblock 334 226 559 minecraft:green_terracotta
setblock 335 226 559 minecraft:oak_log
setblock 336 226 558 minecraft:oak_log
fill 336 226 559 336 228 560 minecraft:green_terracotta
fill 336 226 561 336 228 563 minecraft:oak_log
setblock 336 226 598 minecraft:oak_log
fill 337 226 558 337 229 558 minecraft:green_terracotta
fill 337 226 575 340 228 575 minecraft:oak_leaves[persistent=true]
fill 337 226 598 337 229 598 minecraft:green_terracotta
fill 338 226 574 340 228 574 minecraft:oak_leaves[persistent=true]
fill 338 226 576 340 228 576 minecraft:oak_leaves[persistent=true]
setblock 339 226 559 minecraft:green_terracotta
setblock 339 226 560 minecraft:oak_log
fill 339 226 561 340 228 561 minecraft:green_terracotta
fill 339 226 562 339 229 563 minecraft:oak_log
setblock 340 226 559 minecraft:oak_log
fill 340 226 560 340 229 560 minecraft:green_terracotta
fill 340 226 562 340 236 562 minecraft:oak_log
fill 340 226 577 340 228 577 minecraft:oak_leaves[persistent=true]
setblock 341 226 558 minecraft:oak_log
fill 341 226 559 341 229 559 minecraft:green_terracotta
setblock 341 226 598 minecraft:oak_log
fill 342 226 558 342 229 558 minecraft:green_terracotta
setblock 342 226 597 minecraft:oak_log
fill 342 226 598 345 226 598 minecraft:green_terracotta
setblock 343 226 597 minecraft:green_terracotta
setblock 344 226 560 minecraft:oak_log
setblock 345 226 559 minecraft:oak_log
fill 345 226 560 345 229 560 minecraft:green_terracotta
setblock 346 226 558 minecraft:oak_log
fill 346 226 559 346 229 559 minecraft:green_terracotta
setblock 346 226 598 minecraft:oak_log
fill 347 226 558 347 229 558 minecraft:green_terracotta
fill 347 226 598 347 229 598 minecraft:green_terracotta
setblock 350 226 559 minecraft:oak_log
setblock 351 226 558 minecraft:oak_log
fill 351 226 559 352 228 559 minecraft:green_terracotta
setblock 351 226 598 minecraft:oak_log
fill 352 226 558 352 229 558 minecraft:green_terracotta
fill 352 226 598 352 229 598 minecraft:green_terracotta
fill 353 226 597 353 229 597 minecraft:green_terracotta
setblock 355 226 559 minecraft:oak_log
setblock 356 226 558 minecraft:oak_log
fill 356 226 559 356 229 559 minecraft:green_terracotta
setblock 356 226 598 minecraft:oak_log
fill 357 226 558 357 229 558 minecraft:green_terracotta
setblock 357 226 597 minecraft:oak_log
fill 357 226 598 357 229 598 minecraft:green_terracotta
setblock 358 226 596 minecraft:oak_log
fill 358 226 597 358 229 597 minecraft:green_terracotta
fill 359 226 596 359 229 596 minecraft:green_terracotta
setblock 360 226 559 minecraft:oak_log
setblock 361 226 558 minecraft:oak_log
fill 361 226 559 361 229 559 minecraft:green_terracotta
setblock 361 226 598 minecraft:oak_log
fill 362 226 558 362 229 558 minecraft:green_terracotta
setblock 362 226 597 minecraft:oak_log
fill 362 226 598 362 229 598 minecraft:green_terracotta
fill 363 226 597 363 228 597 minecraft:green_terracotta
fill 365 226 582 365 235 582 minecraft:iron_block
setblock 366 226 598 minecraft:oak_log
setblock 367 226 558 minecraft:oak_leaves[persistent=true]
setblock 367 226 598 minecraft:green_terracotta
fill 369 226 578 369 226 579 minecraft:green_terracotta
setblock 369 226 580 minecraft:oak_log
fill 369 226 581 369 228 582 minecraft:green_terracotta
fill 370 226 575 370 229 575 minecraft:green_terracotta
setblock 370 226 579 minecraft:oak_log
fill 370 226 580 370 229 580 minecraft:green_terracotta
setblock 370 226 584 minecraft:oak_log
fill 370 226 585 370 229 585 minecraft:green_terracotta
setblock 330 227 558 minecraft:oak_log
fill 330 227 559 330 227 562 minecraft:green_terracotta
setblock 330 227 563 minecraft:oak_log
setblock 330 227 573 minecraft:oak_log
fill 330 227 574 330 230 574 minecraft:green_terracotta
setblock 330 227 578 minecraft:oak_log
fill 330 227 579 330 230 579 minecraft:green_terracotta
setblock 330 227 583 minecraft:oak_log
fill 330 227 584 330 230 584 minecraft:green_terracotta
fill 331 227 558 334 227 558 minecraft:green_terracotta
setblock 331 227 576 minecraft:green_terracotta
setblock 331 227 577 minecraft:oak_log
fill 331 227 578 331 230 578 minecraft:green_terracotta
setblock 331 227 581 minecraft:green_terracotta
setblock 331 227 582 minecraft:oak_log
fill 332 227 559 333 227 559 minecraft:green_terracotta
setblock 334 227 559 minecraft:oak_log
fill 334 227 560 335 229 560 minecraft:green_terracotta
setblock 334 227 598 minecraft:green_terracotta
setblock 335 227 558 minecraft:oak_log
fill 335 227 559 335 230 559 minecraft:green_terracotta
setblock 335 227 598 minecraft:oak_log
fill 336 227 558 336 230 558 minecraft:green_terracotta
fill 336 227 598 336 230 598 minecraft:green_terracotta
setblock 337 227 574 minecraft:oak_leaves[persistent=true]
setblock 337 227 576 minecraft:oak_leaves[persistent=true]
setblock 338 227 559 minecraft:green_terracotta
setblock 338 227 560 minecraft:oak_log
fill 338 227 561 338 230 561 minecraft:green_terracotta
fill 338 227 562 338 228 563 minecraft:oak_log
fill 338 227 597 338 229 597 minecraft:green_terracotta
setblock 339 227 559 minecraft:oak_log
fill 339 227 560 339 230 560 minecraft:green_terracotta
setblock 339 227 573 minecraft:oak_leaves[persistent=true]
setblock 340 227 558 minecraft:oak_log
fill 340 227 559 340 230 559 minecraft:green_terracotta
setblock 340 227 598 minecraft:oak_log
fill 341 227 558 341 230 558 minecraft:green_terracotta
setblock 341 227 561 minecraft:green_terracotta
fill 341 227 575 341 227 576 minecraft:oak_leaves[persistent=true]
setblock 341 227 597 minecraft:oak_log
fill 341 227 598 344 227 598 minecraft:green_terracotta
fill 342 227 597 342 228 597 minecraft:green_terracotta
setblock 343 227 560 minecraft:oak_log
setblock 344 227 559 minecraft:oak_log
fill 344 227 560 344 230 560 minecraft:green_terracotta
setblock 345 227 558 minecraft:oak_log
fill 345 227 559 345 230 559 minecraft:green_terracotta
setblock 345 227 598 minecraft:oak_log
fill 346 227 558 346 230 558 minecraft:green_terracotta
fill 346 227 598 346 230 598 minecraft:green_terracotta
setblock 349 227 559 minecraft:oak_log
setblock 350 227 558 minecraft:oak_log
fill 350 227 559 350 230 559 minecraft:green_terracotta
setblock 350 227 598 minecraft:oak_log
fill 351 227 558 351 230 558 minecraft:green_terracotta
fill 351 227 598 351 230 598 minecraft:green_terracotta
fill 352 227 597 352 230 597 minecraft:green_terracotta
setblock 354 227 559 minecraft:oak_log
setblock 355 227 558 minecraft:oak_log
fill 355 227 559 355 230 559 minecraft:green_terracotta
setblock 355 227 598 minecraft:oak_log
fill 356 227 558 356 230 558 minecraft:green_terracotta
fill 356 227 560 357 227 560 minecraft:green_terracotta
setblock 356 227 596 minecraft:green_terracotta
setblock 356 227 597 minecraft:oak_log
fill 356 227 598 356 230 598 minecraft:green_terracotta
setblock 357 227 596 minecraft:oak_log
fill 357 227 597 357 230 597 minecraft:green_terracotta
setblock 358 227 560 minecraft:oak_log
fill 358 227 596 358 230 596 minecraft:green_terracotta
setblock 359 227 559 minecraft:oak_log
fill 359 227 560 359 230 560 minecraft:green_terracotta
setblock 360 227 558 minecraft:oak_log
fill 360 227 559 360 230 559 minecraft:green_terracotta
setblock 360 227 598 minecraft:oak_log
fill 361 227 558 361 230 558 minecraft:green_terracotta
setblock 361 227 597 minecraft:oak_log
fill 361 227 598 361 230 598 minecraft:green_terracotta
fill 362 227 597 362 230 597 minecraft:green_terracotta
fill 364 227 572 365 228 573 minecraft:glowstone
setblock 365 227 558 minecraft:oak_log
setblock 365 227 598 minecraft:oak_log
fill 366 227 598 366 228 598 minecraft:green_terracotta
setblock 369 227 578 minecraft:green_terracotta
setblock 369 227 579 minecraft:oak_log
fill 369 227 580 369 230 580 minecraft:green_terracotta
setblock 369 227 583 minecraft:green_terracotta
setblock 370 227 574 minecraft:oak_leaves[persistent=true]
setblock 370 227 578 minecraft:oak_log
fill 370 227 579 370 230 579 minecraft:green_terracotta
setblock 370 227 583 minecraft:oak_log
fill 370 227 584 370 230 584 minecraft:green_terracotta
fill 370 227 586 370 228 586 minecraft:green_terracotta
setblock 370 227 593 minecraft:oak_leaves[persistent=true]
fill 330 228 558 330 228 561 minecraft:green_terracotta
setblock 330 228 562 minecraft:oak_log
fill 330 228 563 330 228 566 minecraft:green_terracotta
setblock 330 228 569 minecraft:oak_leaves[persistent=true]
fill 330 228 573 330 231 573 minecraft:green_terracotta
setblock 330 228 577 minecraft:oak_log
fill 330 228 578 330 231 578 minecraft:green_terracotta
setblock 330 228 582 minecraft:oak_log
fill 330 228 583 331 230 583 minecraft:green_terracotta
fill 330 228 585 330 229 585 minecraft:green_terracotta
setblock 330 228 588 minecraft:oak_leaves[persistent=true]
fill 331 228 558 331 228 560 minecraft:green_terracotta
setblock 331 228 561 minecraft:oak_log
fill 331 228 562 331 230 563 minecraft:green_terracotta
setblock 331 228 576 minecraft:oak_log
fill 331 228 577 331 231 577 minecraft:green_terracotta
setblock 331 228 581 minecraft:oak_log
fill 331 228 582 331 231 582 minecraft:green_terracotta
fill 332 228 558 332 228 559 minecraft:green_terracotta
setblock 333 228 558 minecraft:green_terracotta
setblock 333 228 559 minecraft:oak_log
fill 333 228 560 333 231 560 minecraft:green_terracotta
setblock 334 228 558 minecraft:oak_log
fill 334 228 559 334 231 559 minecraft:green_terracotta
setblock 334 228 598 minecraft:oak_log
fill 335 228 558 335 231 558 minecraft:green_terracotta
setblock 335 228 561 minecraft:green_terracotta
fill 335 228 598 335 231 598 minecraft:green_terracotta
setblock 337 228 559 minecraft:green_terracotta
setblock 337 228 560 minecraft:oak_log
fill 337 228 561 337 231 561 minecraft:green_terracotta
fill 337 228 562 337 229 563 minecraft:oak_log
fill 337 228 597 337 230 597 minecraft:green_terracotta
setblock 338 228 559 minecraft:oak_log
fill 338 228 560 338 231 560 minecraft:green_terracotta
setblock 339 228 558 minecraft:oak_log
fill 339 228 559 339 231 559 minecraft:green_terracotta
fill 339 228 564 340 229 564 minecraft:glowstone
setblock 339 228 598 minecraft:oak_log
fill 340 228 558 340 231 558 minecraft:green_terracotta
setblock 340 228 597 minecraft:oak_log
fill 340 228 598 343 228 598 minecraft:green_terracotta
setblock 341 228 561 minecraft:oak_log
fill 341 228 597 341 229 597 minecraft:green_terracotta
setblock 342 228 560 minecraft:oak_log
fill 342 228 561 342 231 561 minecraft:green_terracotta
setblock 343 228 559 minecraft:oak_log
fill 343 228 560 343 231 560 minecraft:green_terracotta
setblock 344 228 558 minecraft:oak_log
fill 344 228 559 344 231 559 minecraft:green_terracotta
setblock 344 228 598 minecraft:oak_log
fill 345 228 558 345 231 558 minecraft:green_terracotta
fill 345 228 598 345 231 598 minecraft:green_terracotta
setblock 348 228 559 minecraft:oak_log
setblock 349 228 558 minecraft:oak_log
fill 349 228 559 349 231 559 minecraft:green_terracotta
setblock 349 228 598 minecraft:oak_log
fill 350 228 558 350 231 558 minecraft:green_terracotta
fill 350 228 598 350 231 598 minecraft:green_terracotta
setblock 353 228 558 minecraft:green_terracotta
setblock 353 228 559 minecraft:oak_log
setblock 354 228 558 minecraft:oak_log
fill 354 228 559 354 230 560 minecraft:green_terracotta
setblock 354 228 598 minecraft:oak_log
fill 355 228 558 355 231 558 minecraft:green_terracotta
fill 355 228 560 356 228 560 minecraft:green_terracotta
setblock 355 228 597 minecraft:oak_log
fill 355 228 598 355 231 598 minecraft:green_terracotta
setblock 356 228 596 minecraft:oak_log
fill 356 228 597 356 231 597 minecraft:green_terracotta
setblock 357 228 560 minecraft:oak_log
fill 357 228 596 357 231 596 minecraft:green_terracotta
setblock 358 228 559 minecraft:oak_log
fill 358 228 560 358 231 560 minecraft:green_terracotta
setblock 359 228 558 minecraft:oak_log
fill 359 228 559 359 231 559 minecraft:green_terracotta
setblock 359 228 598 minecraft:oak_log
fill 360 228 558 360 231 558 minecraft:green_terracotta
fill 360 228 560 360 229 560 minecraft:green_terracotta
setblock 360 228 597 minecraft:oak_log
fill 360 228 598 360 231 598 minecraft:green_terracotta
fill 361 228 597 361 231 597 minecraft:green_terracotta
setblock 363 228 559 minecraft:oak_log
setblock 364 228 558 minecraft:oak_log
setblock 364 228 598 minecraft:oak_log
fill 365 228 558 365 229 558 minecraft:green_terracotta
fill 365 228 585 365 229 585 minecraft:glowstone
fill 365 228 598 365 229 598 minecraft:green_terracotta
setblock 369 228 578 minecraft:oak_log
fill 369 228 579 369 231 579 minecraft:green_terracotta
setblock 369 228 583 minecraft:oak_log
fill 369 228 584 369 230 585 minecraft:green_terracotta
setblock 370 228 568 minecraft:oak_leaves[persistent=true]
setblock 370 228 577 minecraft:oak_log
fill 370 228 578 370 231 578 minecraft:green_terracotta
setblock 370 228 582 minecraft:oak_log
fill 370 228 583 370 231 583 minecraft:green_terracotta
setblock 370 228 587 minecraft:oak_log
fill 330 229 558 330 229 560 minecraft:green_terracotta
setblock 330 229 561 minecraft:oak_log
fill 330 229 562 330 229 565 minecraft:green_terracotta
setblock 330 229 566 minecraft:oak_log
fill 330 229 567 330 229 570 minecraft:green_terracotta
setblock 330 229 571 minecraft:oak_log
fill 330 229 572 330 232 572 minecraft:green_terracotta
setblock 330 229 576 minecraft:oak_log
fill 330 229 577 330 232 577 minecraft:green_terracotta
setblock 330 229 580 minecraft:green_terracotta
setblock 330 229 581 minecraft:oak_log
fill 330 229 582 330 232 582 minecraft:green_terracotta
setblock 330 229 586 minecraft:oak_log
setblock 330 229 594 minecraft:oak_leaves[persistent=true]
fill 331 229 558 331 229 559 minecraft:green_terracotta
setblock 331 229 560 minecraft:oak_log
fill 331 229 561 332 231 561 minecraft:green_terracotta
setblock 331 229 564 minecraft:green_terracotta
setblock 331 229 565 minecraft:oak_log
fill 331 229 566 331 232 566 minecraft:green_terracotta
fill 331 229 576 331 232 576 minecraft:green_terracotta
setblock 331 229 580 minecraft:oak_log
fill 331 229 581 331 232 581 minecraft:green_terracotta
setblock 331 229 584 minecraft:green_terracotta
setblock 332 229 558 minecraft:green_terracotta
setblock 332 229 559 minecraft:oak_log
fill 332 229 560 332 232 560 minecraft:green_terracotta
fill 332 229 562 332 229 563 minecraft:green_terracotta
setblock 332 229 564 minecraft:oak_log
fill 332 229 580 332 231 580 minecraft:green_terracotta
setblock 333 229 558 minecraft:oak_log
fill 333 229 559 333 232 559 minecraft:green_terracotta
setblock 333 229 598 minecraft:oak_log
fill 334 229 558 334 232 558 minecraft:green_terracotta
setblock 334 229 561 minecraft:green_terracotta
fill 334 229 598 334 232 598 minecraft:green_terracotta
setblock 335 229 561 minecraft:oak_log
setblock 336 229 559 minecraft:green_terracotta
setblock 336 229 560 minecraft:oak_log
fill 336 229 561 336 232 561 minecraft:green_terracotta
fill 336 229 562 336 229 563 minecraft:oak_log
setblock 337 229 559 minecraft:oak_log
fill 337 229 560 337 232 560 minecraft:green_terracotta
setblock 338 229 558 minecraft:oak_log
fill 338 229 559 338 232 559 minecraft:green_terracotta
setblock 338 229 562 minecraft:green_terracotta
fill 338 229 563 338 236 563 minecraft:oak_log
setblock 338 229 598 minecraft:oak_log
fill 339 229 558 339 232 558 minecraft:green_terracotta
setblock 339 229 561 minecraft:green_terracotta
setblock 339 229 597 minecraft:oak_log
fill 339 229 598 342 229 598 minecraft:green_terracotta
setblock 340 229 561 minecraft:oak_log
fill 340 229 597 340 230 597 minecraft:green_terracotta
setblock 341 229 560 minecraft:oak_log
fill 341 229 561 341 232 561 minecraft:green_terracotta
setblock 342 229 559 minecraft:oak_log
fill 342 229 560 342 232 560 minecraft:green_terracotta
setblock 343 229 558 minecraft:oak_log
fill 343 229 559 343 232 559 minecraft:green_terracotta
setblock 343 229 598 minecraft:oak_log
fill 344 229 558 344 232 558 minecraft:green_terracotta
fill 344 229 598 344 232 598 minecraft:green_terracotta
setblock 346 229 560 minecraft:oak_log
setblock 347 229 559 minecraft:oak_log
setblock 348 229 558 minecraft:oak_log
fill 348 229 559 348 232 559 minecraft:green_terracotta
setblock 348 229 598 minecraft:oak_log
fill 349 229 558 349 232 558 minecraft:green_terracotta
fill 349 229 598 349 232 598 minecraft:green_terracotta
setblock 351 229 559 minecraft:green_terracotta
fill 351 229 597 351 231 597 minecraft:green_terracotta
setblock 352 229 559 minecraft:oak_log
fill 352 229 560 353 231 560 minecraft:green_terracotta
setblock 353 229 558 minecraft:oak_log
fill 353 229 559 353 232 559 minecraft:green_terracotta
setblock 353 229 598 minecraft:oak_log
fill 354 229 558 354 232 558 minecraft:green_terracotta
setblock 354 229 597 minecraft:oak_log
fill 354 229 598 354 232 598 minecraft:green_terracotta
setblock 355 229 560 minecraft:green_terracotta
setblock 355 229 596 minecraft:oak_log
fill 355 229 597 355 232 597 minecraft:green_terracotta
setblock 356 229 560 minecraft:oak_log
fill 356 229 596 356 232 596 minecraft:green_terracotta
setblock 357 229 559 minecraft:oak_log
fill 357 229 560 357 232 560 minecraft:green_terracotta
setblock 358 229 558 minecraft:oak_log
fill 358 229 559 358 232 559 minecraft:green_terracotta
setblock 358 229 598 minecraft:oak_log
fill 359 229 558 359 232 558 minecraft:green_terracotta
setblock 359 229 597 minecraft:oak_log
fill 359 229 598 359 232 598 minecraft:green_terracotta
setblock 360 229 596 minecraft:oak_log
fill 360 229 597 360 232 597 minecraft:green_terracotta
setblock 362 229 559 minecraft:oak_log
setblock 363 229 558 minecraft:oak_log
setblock 363 229 559 minecraft:green_terracotta
setblock 363 229 598 minecraft:oak_log
fill 364 229 558 364 231 558 minecraft:green_terracotta
fill 364 229 598 364 230 598 minecraft:green_terracotta
setblock 368 229 582 minecraft:green_terracotta
setblock 369 229 577 minecraft:oak_log
fill 369 229 578 369 232 578 minecraft:green_terracotta
setblock 369 229 581 minecraft:green_terracotta
setblock 369 229 582 minecraft:oak_log
fill 369 229 583 369 232 583 minecraft:green_terracotta
setblock 369 229 586 minecraft:green_terracotta
fill 370 229 559 370 229 560 minecraft:green_terracotta
setblock 370 229 561 minecraft:oak_log
fill 370 229 562 370 231 563 minecraft:green_terracotta
fill 370 229 574 370 230 574 minecraft:green_terracotta
setblock 370 229 576 minecraft:oak_log
fill 370 229 577 370 232 577 minecraft:green_terracotta
setblock 370 229 581 minecraft:oak_log
fill 370 229 582 370 232 582 minecraft:green_terracotta
setblock 370 229 586 minecraft:oak_log
fill 370 229 587 370 231 588 minecraft:green_terracotta
setblock 370 229 598 minecraft:oak_leaves[persistent=true]
fill 330 230 558 330 230 559 minecraft:green_terracotta
setblock 330 230 560 minecraft:oak_log
fill 330 230 561 330 230 564 minecraft:green_terracotta
setblock 330 230 565 minecraft:oak_log
fill 330 230 566 330 230 569 minecraft:green_terracotta
setblock 330 230 570 minecraft:oak_log
fill 330 230 571 330 233 571 minecraft:green_terracotta
setblock 330 230 575 minecraft:oak_log
fill 330 230 576 330 233 576 minecraft:green_terracotta
setblock 330 230 580 minecraft:oak_log
fill 330 230 581 330 233 581 minecraft:green_terracotta
setblock 330 230 585 minecraft:oak_log
fill 330 230 586 330 232 587 minecraft:green_terracotta
setblock 331 230 558 minecraft:green_terracotta
setblock 331 230 559 minecraft:oak_log
fill 331 230 560 331 233 560 minecraft:green_terracotta
setblock 331 230 564 minecraft:oak_log
fill 331 230 565 332 232 565 minecraft:green_terracotta
fill 331 230 567 331 230 568 minecraft:green_terracotta
setblock 331 230 569 minecraft:oak_log
fill 331 230 575 331 232 575 minecraft:green_terracotta
setblock 331 230 579 minecraft:oak_log
fill 331 230 580 331 233 580 minecraft:green_terracotta
setblock 331 230 584 minecraft:oak_log
fill 331 230 585 331 233 585 minecraft:green_terracotta
setblock 332 230 558 minecraft:oak_log
fill 332 230 559 332 233 559 minecraft:green_terracotta
setblock 332 230 562 minecraft:green_terracotta
setblock 332 230 563 minecraft:oak_log
fill 332 230 564 333 232 564 minecraft:green_terracotta
fill 332 230 566 332 231 566 minecraft:green_terracotta
setblock 332 230 579 minecraft:green_terracotta
fill 332 230 581 332 230 582 minecraft:green_terracotta
setblock 332 230 598 minecraft:oak_leaves[persistent=true]
fill 333 230 558 333 233 558 minecraft:green_terracotta
setblock 333 230 561 minecraft:green_terracotta
setblock 333 230 562 minecraft:oak_log
fill 333 230 563 333 233 563 minecraft:green_terracotta
fill 333 230 598 333 233 598 minecraft:green_terracotta
setblock 334 230 560 minecraft:green_terracotta
setblock 334 230 561 minecraft:oak_log
setblock 335 230 560 minecraft:oak_log
fill 335 230 561 335 233 561 minecraft:green_terracotta
setblock 336 230 559 minecraft:oak_log
fill 336 230 560 336 233 560 minecraft:green_terracotta
fill 336 230 562 337 230 562 minecraft:green_terracotta
fill 336 230 563 337 236 563 minecraft:oak_log
setblock 337 230 558 minecraft:oak_log
fill 337 230 559 337 233 559 minecraft:green_terracotta
setblock 337 230 598 minecraft:oak_log
fill 338 230 558 338 233 558 minecraft:green_terracotta
setblock 338 230 562 minecraft:oak_log
setblock 338 230 597 minecraft:oak_log
fill 338 230 598 341 230 598 minecraft:green_terracotta
setblock 339 230 561 minecraft:oak_log
fill 339 230 562 339 231 562 minecraft:green_terracotta
fill 339 230 563 339 236 563 minecraft:oak_log
fill 339 230 597 339 231 597 minecraft:green_terracotta
setblock 340 230 560 minecraft:oak_log
fill 340 230 561 340 233 561 minecraft:green_terracotta
setblock 341 230 559 minecraft:oak_log
fill 341 230 560 341 233 560 minecraft:green_terracotta
setblock 342 230 558 minecraft:oak_log
fill 342 230 559 342 233 559 minecraft:green_terracotta
setblock 342 230 598 minecraft:oak_log
fill 343 230 558 343 233 558 minecraft:green_terracotta
fill 343 230 598 343 233 598 minecraft:green_terracotta
setblock 345 230 560 minecraft:oak_log
setblock 346 230 559 minecraft:oak_log
setblock 346 230 560 minecraft:green_terracotta
setblock 347 230 558 minecraft:oak_log
fill 347 230 559 347 233 559 minecraft:green_terracotta
setblock 347 230 598 minecraft:oak_log
fill 348 230 558 348 233 558 minecraft:green_terracotta
fill 348 230 598 348 233 598 minecraft:green_terracotta
setblock 351 230 559 minecraft:oak_log
fill 351 230 560 351 232 560 minecraft:green_terracotta
setblock 352 230 558 minecraft:oak_log
fill 352 230 559 352 233 559 minecraft:green_terracotta
setblock 352 230 598 minecraft:oak_log
fill 353 230 558 353 233 558 minecraft:green_terracotta
setblock 353 230 597 minecraft:oak_log
fill 353 230 598 353 233 598 minecraft:green_terracotta
fill 354 230 597 354 233 597 minecraft:green_terracotta
setblock 355 230 560 minecraft:oak_log
fill 355 230 596 355 232 596 minecraft:green_terracotta
setblock 356 230 559 minecraft:oak_log
fill 356 230 560 356 233 560 minecraft:green_terracotta
setblock 357 230 558 minecraft:oak_log
fill 357 230 559 357 233 559 minecraft:green_terracotta
setblock 357 230 598 minecraft:oak_log
fill 358 230 558 358 233 558 minecraft:green_terracotta
setblock 358 230 597 minecraft:oak_log
fill 358 230 598 358 233 598 minecraft:green_terracotta
setblock 359 230 596 minecraft:oak_log
fill 359 230 597 359 233 597 minecraft:green_terracotta
setblock 360 230 560 minecraft:oak_log
setblock 361 230 559 minecraft:oak_log
setblock 362 230 558 minecraft:oak_log
setblock 362 230 559 minecraft:green_terracotta
setblock 362 230 598 minecraft:oak_log
fill 363 230 558 363 231 558 minecraft:green_terracotta
fill 363 230 598 363 231 598 minecraft:green_terracotta
setblock 368 230 558 minecraft:oak_leaves[persistent=true]
setblock 368 230 581 minecraft:green_terracotta
setblock 368 230 582 minecraft:oak_log
fill 368 230 583 368 232 584 minecraft:green_terracotta
fill 369 230 577 369 231 577 minecraft:green_terracotta
setblock 369 230 581 minecraft:oak_log
fill 369 230 582 369 233 582 minecraft:green_terracotta
setblock 369 230 586 minecraft:oak_log
fill 369 230 587 369 233 587 minecraft:green_terracotta
fill 370 230 558 370 230 559 minecraft:green_terracotta
setblock 370 230 560 minecraft:oak_log
fill 370 230 561 370 233 561 minecraft:green_terracotta
setblock 370 230 564 minecraft:green_terracotta
setblock 370 230 565 minecraft:oak_log
fill 370 230 566 370 233 566 minecraft:green_terracotta
fill 370 230 573 370 231 573 minecraft:green_terracotta
setblock 370 230 575 minecraft:oak_log
fill 370 230 576 370 233 576 minecraft:green_terracotta
setblock 370 230 580 minecraft:oak_log
fill 370 230 581 370 233 581 minecraft:green_terracotta
setblock 370 230 585 minecraft:oak_log
fill 370 230 586 370 233 586 minecraft:green_terracotta
setblock 370 230 589 minecraft:green_terracotta
setblock 330 231 558 minecraft:green_terracotta
setblock 330 231 559 minecraft:oak_log
fill 330 231 560 330 231 563 minecraft:green_terracotta
setblock 330 231 564 minecraft:oak_log
fill 330 231 565 330 231 568 minecraft:green_terracotta
setblock 330 231 569 minecraft:oak_log
fill 330 231 570 331 233 570 minecraft:green_terracotta
setblock 330 231 574 minecraft:oak_log
fill 330 231 575 330 234 575 minecraft:green_terracotta
setblock 330 231 579 minecraft:oak_log
fill 330 231 580 330 234 580 minecraft:green_terracotta
setblock 330 231 583 minecraft:green_terracotta
setblock 330 231 584 minecraft:oak_log
fill 330 231 585 330 234 585 minecraft:green_terracotta
setblock 330 231 588 minecraft:green_terracotta
setblock 331 231 558 minecraft:oak_log
fill 331 231 559 331 234 559 minecraft:green_terracotta
setblock 331 231 562 minecraft:green_terracotta
setblock 331 231 563 minecraft:oak_log
fill 331 231 564 331 234 564 minecraft:green_terracotta
setblock 331 231 567 minecraft:green_terracotta
setblock 331 231 568 minecraft:oak_log
fill 331 231 569 331 234 569 minecraft:green_terracotta
fill 331 231 571 331 232 571 minecraft:green_terracotta
setblock 331 231 578 minecraft:oak_log
fill 331 231 579 331 233 579 minecraft:green_terracotta
setblock 331 231 583 minecraft:oak_log
fill 331 231 584 331 234 584 minecraft:green_terracotta
fill 331 231 586 331 232 586 minecraft:green_terracotta
fill 332 231 558 332 234 558 minecraft:green_terracotta
setblock 332 231 562 minecraft:oak_log
fill 332 231 563 332 234 563 minecraft:green_terracotta
setblock 332 231 567 minecraft:oak_log
fill 332 231 568 332 234 568 minecraft:green_terracotta
setblock 332 231 581 minecraft:green_terracotta
setblock 332 231 582 minecraft:oak_log
fill 332 231 583 332 233 583 minecraft:green_terracotta
fill 332 231 598 332 232 598 minecraft:green_terracotta
setblock 333 231 561 minecraft:oak_log
fill 333 231 562 333 234 562 minecraft:green_terracotta
setblock 333 231 565 minecraft:green_terracotta
setblock 333 231 566 minecraft:oak_log
setblock 334 231 560 minecraft:oak_log
fill 334 231 561 334 234 561 minecraft:green_terracotta
setblock 335 231 559 minecraft:oak_log
fill 335 231 560 335 234 560 minecraft:green_terracotta
fill 335 231 562 336 231 562 minecraft:green_terracotta
setblock 336 231 558 minecraft:oak_log
fill 336 231 559 336 234 559 minecraft:green_terracotta
setblock 336 231 598 minecraft:oak_log
fill 337 231 558 337 234 558 minecraft:green_terracotta
setblock 337 231 562 minecraft:oak_log
setblock 337 231 597 minecraft:oak_log
fill 337 231 598 340 231 598 minecraft:green_terracotta
setblock 338 231 561 minecraft:oak_log
fill 338 231 562 338 232 562 minecraft:green_terracotta
setblock 338 231 597 minecraft:green_terracotta
setblock 339 231 560 minecraft:oak_log
fill 339 231 561 339 233 561 minecraft:green_terracotta
setblock 340 231 559 minecraft:oak_log
fill 340 231 560 340 234 560 minecraft:green_terracotta
setblock 341 231 558 minecraft:oak_log
fill 341 231 559 341 234 559 minecraft:green_terracotta
setblock 341 231 598 minecraft:oak_log
fill 342 231 558 342 234 558 minecraft:green_terracotta
fill 342 231 598 342 233 598 minecraft:green_terracotta
setblock 344 231 560 minecraft:oak_log
setblock 345 231 559 minecraft:oak_log
setblock 345 231 560 minecraft:green_terracotta
setblock 346 231 558 minecraft:oak_log
fill 346 231 559 346 233 559 minecraft:green_terracotta
setblock 346 231 598 minecraft:oak_log
fill 347 231 558 347 234 558 minecraft:green_terracotta
fill 347 231 598 347 234 598 minecraft:green_terracotta
setblock 350 231 559 minecraft:oak_log
setblock 351 231 558 minecraft:oak_log
fill 351 231 559 351 234 559 minecraft:green_terracotta
setblock 351 231 598 minecraft:oak_log
fill 352 231 558 352 234 558 minecraft:green_terracotta
setblock 352 231 597 minecraft:oak_log
fill 352 231 598 352 234 598 minecraft:green_terracotta
fill 353 231 597 353 234 597 minecraft:green_terracotta
setblock 354 231 559 minecraft:green_terracotta
setblock 354 231 560 minecraft:oak_log
fill 354 231 596 354 232 596 minecraft:green_terracotta
setblock 355 231 559 minecraft:oak_log
fill 355 231 560 355 233 560 minecraft:green_terracotta
setblock 356 231 558 minecraft:oak_log
fill 356 231 559 356 234 559 minecraft:green_terracotta
setblock 356 231 598 minecraft:oak_log
fill 357 231 558 357 234 558 minecraft:green_terracotta
setblock 357 231 597 minecraft:oak_log
fill 357 231 598 357 234 598 minecraft:green_terracotta
setblock 358 231 596 minecraft:oak_log
fill 358 231 597 358 233 597 minecraft:green_terracotta
setblock 359 231 560 minecraft:oak_log
setblock 360 231 559 minecraft:oak_log
setblock 361 231 558 minecraft:oak_log
setblock 361 231 559 minecraft:green_terracotta
setblock 361 231 598 minecraft:oak_log
fill 362 231 558 362 232 558 minecraft:green_terracotta
fill 362 231 598 362 232 598 minecraft:green_terracotta
setblock 368 231 581 minecraft:oak_log
fill 368 231 582 368 232 582 minecraft:green_terracotta
setblock 368 231 585 minecraft:green_terracotta
setblock 369 231 580 minecraft:oak_log
fill 369 231 581 369 234 581 minecraft:green_terracotta
setblock 369 231 584 minecraft:green_terracotta
setblock 369 231 585 minecraft:oak_log
fill 369 231 586 369 234 586 minecraft:green_terracotta
fill 369 231 588 369 232 588 minecraft:green_terracotta
setblock 370 231 558 minecraft:green_terracotta
setblock 370 231 559 minecraft:oak_log
fill 370 231 560 370 234 560 minecraft:green_terracotta
setblock 370 231 564 minecraft:oak_log
fill 370 231 565 370 234 565 minecraft:green_terracotta
fill 370 231 567 370 231 568 minecraft:green_terracotta
setblock 370 231 569 minecraft:oak_log
fill 370 231 570 370 232 572 minecraft:green_terracotta
setblock 370 231 574 minecraft:oak_log
fill 370 231 575 370 234 575 minecraft:green_terracotta
setblock 370 231 579 minecraft:oak_log
fill 370 231 580 370 234 580 minecraft:green_terracotta
setblock 370 231 584 minecraft:oak_log
fill 370 231 585 370 234 585 minecraft:green_terracotta
setblock 370 231 589 minecraft:oak_log
fill 370 231 590 370 234 590 minecraft:green_terracotta
setblock 370 231 594 minecraft:oak_leaves[persistent=true]
setblock 330 232 558 minecraft:oak_log
fill 330 232 559 330 232 562 minecraft:green_terracotta
setblock 330 232 563 minecraft:oak_log
fill 330 232 564 330 232 567 minecraft:green_terracotta
setblock 330 232 568 minecraft:oak_log
fill 330 232 569 330 235 569 minecraft:green_terracotta
setblock 330 232 573 minecraft:oak_log
fill 330 232 574 330 235 574 minecraft:green_terracotta
setblock 330 232 578 minecraft:oak_log
fill 330 232 579 330 235 579 minecraft:green_terracotta
setblock 330 232 583 minecraft:oak_log
fill 330 232 584 330 235 584 minecraft:green_terracotta
setblock 330 232 588 minecraft:oak_log
fill 330 232 589 330 235 589 minecraft:green_terracotta
setblock 330 232 593 minecraft:oak_leaves[persistent=true]
fill 331 232 558 331 235 558 minecraft:green_terracotta
setblock 331 232 561 minecraft:green_terracotta
setblock 331 232 562 minecraft:oak_log
fill 331 232 563 331 235 563 minecraft:green_terracotta
setblock 331 232 567 minecraft:oak_log
fill 331 232 568 331 235 568 minecraft:green_terracotta
setblock 331 232 572 minecraft:oak_log
fill 331 232 573 331 235 573 minecraft:green_terracotta
setblock 331 232 577 minecraft:oak_log
fill 331 232 578 331 233 578 minecraft:green_terracotta
setblock 331 232 582 minecraft:oak_log
fill 331 232 583 331 235 583 minecraft:green_terracotta
setblock 331 232 587 minecraft:oak_log
setblock 332 232 561 minecraft:oak_log
fill 332 232 562 332 235 562 minecraft:green_terracotta
setblock 332 232 566 minecraft:oak_log
fill 332 232 567 333 234 567 minecraft:green_terracotta
fill 332 232 569 332 233 569 minecraft:green_terracotta
setblock 332 232 576 minecraft:light[level=14]
setblock 332 232 581 minecraft:oak_log
setblock 332 232 582 minecraft:green_terracotta
setblock 332 232 584 minecraft:green_terracotta
setblock 332 232 592 minecraft:light[level=14]
setblock 333 232 560 minecraft:oak_log
fill 333 232 561 333 235 561 minecraft:green_terracotta
setblock 333 232 565 minecraft:oak_log
fill 333 232 566 333 235 566 minecraft:green_terracotta
setblock 334 232 559 minecraft:oak_log
fill 334 232 560 334 235 560 minecraft:green_terracotta
fill 334 232 562 334 232 563 minecraft:green_terracotta
setblock 334 232 564 minecraft:oak_log
setblock 335 232 558 minecraft:oak_log
fill 335 232 559 335 235 559 minecraft:green_terracotta
setblock 335 232 562 minecraft:green_terracotta
setblock 335 232 598 minecraft:oak_log
fill 336 232 558 336 235 558 minecraft:green_terracotta
setblock 336 232 562 minecraft:oak_log
fill 336 232 598 339 232 598 minecraft:green_terracotta
setblock 337 232 561 minecraft:oak_log
fill 337 232 562 337 233 562 minecraft:green_terracotta
setblock 338 232 560 minecraft:oak_log
fill 338 232 561 338 234 561 minecraft:green_terracotta
setblock 339 232 559 minecraft:oak_log
fill 339 232 560 339 235 560 minecraft:green_terracotta
fill 339 232 562 339 236 562 minecraft:oak_log
setblock 340 232 558 minecraft:oak_log
fill 340 232 559 340 235 559 minecraft:green_terracotta
setblock 340 232 568 minecraft:light[level=14]
setblock 340 232 576 minecraft:light[level=14]
setblock 340 232 584 minecraft:light[level=14]
setblock 340 232 592 minecraft:light[level=14]
setblock 340 232 598 minecraft:oak_log
fill 341 232 558 341 235 558 minecraft:green_terracotta
fill 341 232 598 341 234 598 minecraft:green_terracotta
setblock 343 232 560 minecraft:oak_log
setblock 344 232 559 minecraft:oak_log
setblock 344 232 560 minecraft:green_terracotta
setblock 345 232 558 minecraft:oak_log
fill 345 232 559 345 233 559 minecraft:green_terracotta
setblock 345 232 598 minecraft:oak_log
fill 346 232 558 346 235 558 minecraft:green_terracotta
fill 346 232 598 346 233 598 minecraft:green_terracotta
setblock 348 232 560 minecraft:light[level=14]
setblock 348 232 568 minecraft:light[level=14]
setblock 348 232 576 minecraft:light[level=14]
setblock 348 232 584 minecraft:light[level=14]
setblock 348 232 592 minecraft:light[level=14]
setblock 349 232 559 minecraft:oak_log
setblock 350 232 558 minecraft:oak_log
fill 350 232 559 350 234 559 minecraft:green_terracotta
setblock 350 232 598 minecraft:oak_log
fill 351 232 558 351 235 558 minecraft:green_terracotta
setblock 351 232 597 minecraft:oak_log
fill 351 232 598 351 235 598 minecraft:green_terracotta
setblock 352 232 560 minecraft:green_terracotta
fill 352 232 597 352 235 597 minecraft:green_terracotta
setblock 353 232 560 minecraft:oak_log
setblock 354 232 559 minecraft:oak_log
fill 354 232 560 354 233 560 minecraft:green_terracotta
setblock 355 232 558 minecraft:oak_log
fill 355 232 559 355 235 559 minecraft:green_terracotta
setblock 355 232 598 minecraft:oak_log
fill 356 232 558 356 235 558 minecraft:green_terracotta
setblock 356 232 568 minecraft:light[level=14]
setblock 356 232 576 minecraft:light[level=14]
setblock 356 232 584 minecraft:light[level=14]
setblock 356 232 592 minecraft:light[level=14]
setblock 356 232 597 minecraft:oak_log
fill 356 232 598 356 235 598 minecraft:green_terracotta
setblock 357 232 596 minecraft:oak_log
fill 357 232 597 357 234 597 minecraft:green_terracotta
setblock 358 232 560 minecraft:oak_log
setblock 359 232 559 minecraft:oak_log
setblock 360 232 558 minecraft:oak_log
setblock 360 232 559 minecraft:green_terracotta
setblock 360 232 598 minecraft:oak_log
fill 361 232 558 361 233 558 minecraft:green_terracotta
fill 361 232 598 361 233 598 minecraft:green_terracotta
setblock 364 232 560 minecraft:light[level=14]
setblock 364 232 568 minecraft:light[level=14]
setblock 364 232 576 minecraft:light[level=14]
setblock 364 232 584 minecraft:light[level=14]
setblock 364 232 592 minecraft:light[level=14]
setblock 368 232 585 minecraft:oak_log
setblock 369 232 579 minecraft:oak_log
fill 369 232 580 369 235 580 minecraft:green_terracotta
setblock 369 232 584 minecraft:oak_log
fill 369 232 585 369 235 585 minecraft:green_terracotta
setblock 369 232 598 minecraft:oak_leaves[persistent=true]
setblock 370 232 558 minecraft:oak_log
fill 370 232 559 370 234 559 minecraft:green_terracotta
setblock 370 232 562 minecraft:green_terracotta
setblock 370 232 563 minecraft:oak_log
fill 370 232 564 370 235 564 minecraft:green_terracotta
setblock 370 232 567 minecraft:green_terracotta
setblock 370 232 568 minecraft:oak_log
fill 370 232 569 370 235 569 minecraft:green_terracotta
setblock 370 232 573 minecraft:oak_log
fill 370 232 574 370 235 574 minecraft:green_terracotta
setblock 370 232 578 minecraft:oak_log
fill 370 232 579 370 235 579 minecraft:green_terracotta
setblock 370 232 583 minecraft:oak_log
fill 370 232 584 370 235 584 minecraft:green_terracotta
setblock 370 232 587 minecraft:green_terracotta
setblock 370 232 588 minecraft:oak_log
fill 370 232 589 370 235 589 minecraft:green_terracotta
fill 370 232 591 370 233 591 minecraft:green_terracotta
fill 330 233 558 330 233 561 minecraft:green_terracotta
setblock 330 233 562 minecraft:oak_log
fill 330 233 563 330 233 566 minecraft:green_terracotta
setblock 330 233 567 minecraft:oak_log
fill 330 233 568 330 236 568 minecraft:green_terracotta
setblock 330 233 572 minecraft:oak_log
fill 330 233 573 330 236 573 minecraft:green_terracotta
setblock 330 233 577 minecraft:oak_log
fill 330 233 578 330 236 578 minecraft:green_terracotta
setblock 330 233 582 minecraft:oak_log
fill 330 233 583 330 236 583 minecraft:green_terracotta
setblock 330 233 586 minecraft:green_terracotta
setblock 330 233 587 minecraft:oak_log
fill 330 233 588 330 236 588 minecraft:green_terracotta
setblock 331 233 561 minecraft:oak_log
fill 331 233 562 331 236 562 minecraft:green_terracotta
setblock 331 233 565 minecraft:green_terracotta
setblock 331 233 566 minecraft:oak_log
fill 331 233 567 331 236 567 minecraft:green_terracotta
setblock 331 233 571 minecraft:oak_log
fill 331 233 572 331 236 572 minecraft:green_terracotta
fill 331 233 574 332 233 575 minecraft:oak_leaves[persistent=true]
setblock 331 233 577 minecraft:green_terracotta
setblock 331 233 581 minecraft:oak_log
fill 331 233 582 331 235 582 minecraft:green_terracotta
setblock 331 233 586 minecraft:oak_log
fill 331 233 587 331 236 587 minecraft:green_terracotta
setblock 331 233 598 minecraft:oak_leaves[persistent=true]
setblock 332 233 560 minecraft:oak_log
fill 332 233 561 332 236 561 minecraft:green_terracotta
setblock 332 233 564 minecraft:green_terracotta
setblock 332 233 565 minecraft:oak_log
fill 332 233 566 332 236 566 minecraft:green_terracotta
setblock 332 233 570 minecraft:oak_log
fill 332 233 571 332 235 573 minecraft:oak_leaves[persistent=true]
fill 332 233 576 340 233 576 minecraft:oak_leaves[persistent=true]
setblock 333 233 559 minecraft:oak_log
fill 333 233 560 333 236 560 minecraft:green_terracotta
setblock 333 233 564 minecraft:oak_log
fill 333 233 565 334 233 565 minecraft:green_terracotta
fill 333 233 568 333 233 570 minecraft:oak_leaves[persistent=true]
fill 333 233 575 338 233 575 minecraft:oak_leaves[persistent=true]
setblock 334 233 558 minecraft:oak_log
fill 334 233 559 334 236 559 minecraft:green_terracotta
setblock 334 233 562 minecraft:green_terracotta
setblock 334 233 563 minecraft:oak_log
fill 334 233 564 334 234 564 minecraft:green_terracotta
fill 334 233 568 337 233 569 minecraft:oak_leaves[persistent=true]
fill 334 233 577 336 233 577 minecraft:oak_leaves[persistent=true]
setblock 334 233 598 minecraft:oak_log
fill 335 233 558 335 236 558 minecraft:green_terracotta
setblock 335 233 562 minecraft:oak_log
fill 335 233 563 335 233 565 minecraft:oak_leaves[persistent=true]
fill 335 233 598 338 233 598 minecraft:green_terracotta
setblock 336 233 561 minecraft:oak_log
setblock 336 233 562 minecraft:green_terracotta
fill 336 233 564 340 233 565 minecraft:oak_leaves[persistent=true]
fill 336 233 578 336 233 580 minecraft:oak_leaves[persistent=true]
setblock 337 233 560 minecraft:oak_log
fill 337 233 561 337 234 561 minecraft:green_terracotta
fill 337 233 570 339 233 570 minecraft:oak_leaves[persistent=true]
fill 337 233 574 339 233 574 minecraft:oak_leaves[persistent=true]
fill 337 233 580 340 233 580 minecraft:oak_leaves[persistent=true]
setblock 338 233 559 minecraft:oak_log
fill 338 233 560 338 235 560 minecraft:green_terracotta
fill 338 233 562 338 236 562 minecraft:oak_log
setblock 338 233 569 minecraft:oak_leaves[persistent=true]
fill 338 233 571 339 233 573 minecraft:oak_leaves[persistent=true]
setblock 338 233 581 minecraft:oak_leaves[persistent=true]
setblock 339 233 558 minecraft:oak_log
fill 339 233 559 339 236 559 minecraft:green_terracotta
setblock 339 233 598 minecraft:oak_log
fill 340 233 558 340 236 558 minecraft:green_terracotta
fill 340 233 563 342 233 563 minecraft:oak_leaves[persistent=true]
fill 340 233 577 340 234 579 minecraft:oak_leaves[persistent=true]
fill 340 233 598 340 234 598 minecraft:green_terracotta
fill 341 233 561 342 233 562 minecraft:oak_leaves[persistent=true]
setblock 341 233 564 minecraft:oak_leaves[persistent=true]
fill 341 233 578 341 233 579 minecraft:oak_leaves[persistent=true]
setblock 342 233 560 minecraft:oak_log
setblock 343 233 559 minecraft:oak_log
setblock 344 233 558 minecraft:oak_log
setblock 344 233 559 minecraft:green_terracotta
setblock 344 233 598 minecraft:oak_log
fill 345 233 558 345 235 558 minecraft:green_terracotta
setblock 348 233 559 minecraft:oak_log
setblock 349 233 558 minecraft:oak_log
fill 349 233 559 349 234 559 minecraft:green_terracotta
setblock 349 233 598 minecraft:oak_log
fill 350 233 558 350 236 558 minecraft:green_terracotta
fill 350 233 598 350 236 598 minecraft:green_terracotta
fill 351 233 597 351 235 597 minecraft:green_terracotta
setblock 352 233 560 minecraft:oak_log
setblock 353 233 559 minecraft:oak_log
setblock 353 233 560 minecraft:green_terracotta
setblock 354 233 558 minecraft:oak_log
fill 354 233 559 354 235 559 minecraft:green_terracotta
setblock 354 233 598 minecraft:oak_log
fill 355 233 558 355 236 558 minecraft:green_terracotta
setblock 355 233 597 minecraft:oak_log
fill 355 233 598 355 236 598 minecraft:green_terracotta
fill 356 233 597 356 235 597 minecraft:green_terracotta
setblock 358 233 559 minecraft:oak_log
setblock 359 233 558 minecraft:oak_log
setblock 359 233 559 minecraft:green_terracotta
fill 359 233 563 360 233 563 minecraft:oak_leaves[persistent=true]
setblock 359 233 598 minecraft:oak_log
setblock 360 233 558 minecraft:green_terracotta
fill 360 233 561 360 233 562 minecraft:oak_leaves[persistent=true]
fill 360 233 564 360 233 565 minecraft:oak_leaves[persistent=true]
fill 360 233 598 360 234 598 minecraft:green_terracotta
fill 361 233 560 364 233 561 minecraft:oak_leaves[persistent=true]
fill 361 233 565 364 233 566 minecraft:oak_leaves[persistent=true]
fill 365 233 561 365 234 565 minecraft:oak_leaves[persistent=true]
fill 366 233 562 366 233 564 minecraft:oak_leaves[persistent=true]
setblock 368 233 583 minecraft:green_terracotta
setblock 368 233 584 minecraft:oak_log
setblock 368 233 585 minecraft:green_terracotta
setblock 369 233 558 minecraft:oak_leaves[persistent=true]
setblock 369 233 563 minecraft:oak_log
fill 369 233 564 369 234 566 minecraft:green_terracotta
setblock 369 233 578 minecraft:oak_log
fill 369 233 579 369 234 579 minecraft:green_terracotta
setblock 369 233 583 minecraft:oak_log
fill 369 233 584 369 236 584 minecraft:green_terracotta
setblock 369 233 588 minecraft:oak_log
setblock 370 233 562 minecraft:oak_log
fill 370 233 563 370 236 563 minecraft:green_terracotta
setblock 370 233 567 minecraft:oak_log
fill 370 233 568 370 236 568 minecraft:green_terracotta
fill 370 233 570 370 233 571 minecraft:green_terracotta
setblock 370 233 572 minecraft:oak_log
fill 370 233 573 370 236 573 minecraft:green_terracotta
setblock 370 233 577 minecraft:oak_log
fill 370 233 578 370 236 578 minecraft:green_terracotta
setblock 370 233 582 minecraft:oak_log
fill 370 233 583 370 236 583 minecraft:green_terracotta
setblock 370 233 587 minecraft:oak_log
fill 370 233 588 370 236 588 minecraft:green_terracotta
fill 330 234 558 330 234 560 minecraft:green_terracotta
setblock 330 234 561 minecraft:oak_log
fill 330 234 562 330 234 565 minecraft:green_terracotta
setblock 330 234 566 minecraft:oak_log
fill 330 234 567 330 236 567 minecraft:green_terracotta
setblock 330 234 570 minecraft:green_terracotta
setblock 330 234 571 minecraft:oak_log
fill 330 234 572 330 236 572 minecraft:green_terracotta
setblock 330 234 576 minecraft:oak_log
fill 330 234 577 330 236 577 minecraft:green_terracotta
setblock 330 234 581 minecraft:oak_log
fill 330 234 582 330 236 582 minecraft:green_terracotta
setblock 330 234 586 minecraft:oak_log
fill 330 234 587 330 236 587 minecraft:green_terracotta
setblock 330 234 590 minecraft:green_terracotta
setblock 331 234 560 minecraft:oak_log
fill 331 234 561 331 236 561 minecraft:green_terracotta
setblock 331 234 565 minecraft:oak_log
fill 331 234 566 331 236 566 minecraft:green_terracotta
setblock 331 234 570 minecraft:oak_log
fill 331 234 571 331 236 571 minecraft:green_terracotta
setblock 331 234 580 minecraft:oak_log
setblock 331 234 581 minecraft:green_terracotta
setblock 331 234 585 minecraft:oak_log
fill 331 234 586 331 236 586 minecraft:green_terracotta
fill 331 234 588 331 235 588 minecraft:green_terracotta
setblock 332 234 559 minecraft:oak_log
fill 332 234 560 332 236 560 minecraft:green_terracotta
setblock 332 234 564 minecraft:oak_log
fill 332 234 565 333 236 565 minecraft:green_terracotta
setblock 332 234 569 minecraft:oak_log
fill 332 234 570 332 236 570 minecraft:green_terracotta
fill 332 234 574 332 234 575 minecraft:oak_leaves[persistent=true]
setblock 333 234 558 minecraft:oak_log
fill 333 234 559 333 236 559 minecraft:green_terracotta
setblock 333 234 563 minecraft:oak_log
fill 333 234 564 333 236 564 minecraft:green_terracotta
setblock 333 234 568 minecraft:oak_log
fill 333 234 569 333 234 570 minecraft:oak_leaves[persistent=true]
fill 333 234 575 337 234 575 minecraft:oak_leaves[persistent=true]
setblock 333 234 598 minecraft:oak_log
fill 334 234 558 334 236 558 minecraft:green_terracotta
setblock 334 234 563 minecraft:green_terracotta
fill 334 234 569 337 234 569 minecraft:oak_leaves[persistent=true]
fill 334 234 576 339 234 576 minecraft:oak_leaves[persistent=true]
fill 334 234 598 337 234 598 minecraft:green_terracotta
setblock 335 234 561 minecraft:oak_log
fill 335 234 562 335 234 564 minecraft:oak_leaves[persistent=true]
setblock 335 234 568 minecraft:oak_leaves[persistent=true]
setblock 336 234 560 minecraft:oak_log
fill 336 234 561 336 235 561 minecraft:green_terracotta
fill 336 234 562 337 236 562 minecraft:oak_log
fill 336 234 564 340 234 564 minecraft:oak_leaves[persistent=true]
fill 336 234 577 336 234 579 minecraft:oak_leaves[persistent=true]
setblock 337 234 559 minecraft:oak_log
fill 337 234 560 337 236 560 minecraft:green_terracotta
fill 337 234 565 339 234 565 minecraft:oak_leaves[persistent=true]
fill 337 234 570 338 234 570 minecraft:oak_leaves[persistent=true]
fill 337 234 574 338 234 574 minecraft:oak_leaves[persistent=true]
fill 337 234 580 339 234 580 minecraft:oak_leaves[persistent=true]
setblock 338 234 558 minecraft:oak_log
fill 338 234 559 338 236 559 minecraft:green_terracotta
fill 338 234 571 338 234 573 minecraft:oak_leaves[persistent=true]
setblock 338 234 598 minecraft:oak_log
fill 339 234 558 339 236 558 minecraft:green_terracotta
fill 339 234 561 340 236 561 minecraft:oak_log
fill 339 234 598 339 235 598 minecraft:green_terracotta
fill 340 234 563 341 234 563 minecraft:oak_leaves[persistent=true]
fill 341 234 560 341 234 562 minecraft:oak_leaves[persistent=true]
setblock 342 234 559 minecraft:oak_log
setblock 343 234 558 minecraft:oak_log
setblock 343 234 559 minecraft:green_terracotta
fill 344 234 558 344 235 558 minecraft:green_terracotta
setblock 348 234 558 minecraft:oak_log
setblock 348 234 598 minecraft:oak_log
fill 349 234 558 349 236 558 minecraft:green_terracotta
fill 349 234 598 349 236 598 minecraft:green_terracotta
setblock 352 234 559 minecraft:oak_log
setblock 353 234 558 minecraft:oak_log
fill 353 234 559 353 235 559 minecraft:green_terracotta
setblock 353 234 598 minecraft:oak_log
fill 354 234 558 354 236 558 minecraft:green_terracotta
setblock 354 234 597 minecraft:oak_log
fill 354 234 598 354 236 598 minecraft:green_terracotta
fill 355 234 597 355 236 597 minecraft:green_terracotta
setblock 357 234 559 minecraft:oak_log
setblock 358 234 558 minecraft:oak_log
setblock 358 234 598 minecraft:oak_log
schedule function dropper:buildpart/139_7 1t
