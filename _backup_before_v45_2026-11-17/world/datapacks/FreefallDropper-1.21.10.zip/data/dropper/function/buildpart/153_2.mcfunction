setblock 426 250 623 minecraft:light[level=13]
setblock 426 250 631 minecraft:light[level=13]
setblock 426 250 639 minecraft:light[level=13]
fill 428 250 604 428 307 604 minecraft:white_concrete
fill 431 250 646 431 307 646 minecraft:white_concrete
fill 432 250 604 432 307 604 minecraft:white_concrete
setblock 434 250 607 minecraft:light[level=13]
setblock 434 250 615 minecraft:light[level=13]
setblock 434 250 623 minecraft:light[level=13]
setblock 434 250 631 minecraft:light[level=13]
setblock 434 250 639 minecraft:light[level=13]
fill 435 250 619 435 255 622 minecraft:green_terracotta
fill 435 250 632 435 255 635 minecraft:lime_terracotta
fill 436 250 619 436 256 619 minecraft:green_terracotta
fill 436 250 622 436 256 622 minecraft:green_terracotta
fill 436 250 632 436 256 632 minecraft:lime_terracotta
fill 436 250 635 436 256 635 minecraft:lime_terracotta
fill 437 250 604 439 255 604 minecraft:white_concrete
fill 437 250 618 437 256 618 minecraft:green_terracotta
fill 437 250 623 437 256 623 minecraft:green_terracotta
fill 437 250 631 437 256 631 minecraft:lime_terracotta
fill 437 250 636 437 256 636 minecraft:lime_terracotta
setblock 440 250 604 minecraft:light_gray_concrete
fill 440 250 617 442 256 617 minecraft:green_terracotta
fill 440 250 624 442 252 624 minecraft:green_terracotta
fill 440 250 630 442 252 630 minecraft:lime_terracotta
fill 440 250 637 442 256 637 minecraft:lime_terracotta
fill 440 250 646 440 307 646 minecraft:white_concrete
fill 441 250 604 441 307 604 minecraft:white_concrete
setblock 442 250 607 minecraft:light[level=13]
setblock 442 250 615 minecraft:light[level=13]
setblock 442 250 639 minecraft:light[level=13]
fill 446 250 604 449 255 604 minecraft:white_concrete
fill 446 250 617 448 256 617 minecraft:green_terracotta
fill 446 250 624 448 252 624 minecraft:green_terracotta
fill 446 250 630 448 252 630 minecraft:lime_terracotta
fill 446 250 637 448 256 637 minecraft:lime_terracotta
setblock 446 250 646 minecraft:light_gray_concrete
fill 447 250 646 458 255 646 minecraft:white_concrete
setblock 450 250 604 minecraft:light_gray_concrete
setblock 450 250 607 minecraft:light[level=13]
setblock 450 250 615 minecraft:light[level=13]
setblock 450 250 639 minecraft:light[level=13]
fill 451 250 604 452 307 604 minecraft:white_concrete
fill 451 250 618 451 256 618 minecraft:green_terracotta
fill 451 250 623 451 256 623 minecraft:green_terracotta
fill 451 250 631 451 256 631 minecraft:lime_terracotta
fill 451 250 636 451 256 636 minecraft:lime_terracotta
fill 452 250 619 453 255 619 minecraft:green_terracotta
fill 452 250 622 453 255 622 minecraft:green_terracotta
fill 452 250 632 453 255 632 minecraft:lime_terracotta
fill 452 250 635 453 255 635 minecraft:lime_terracotta
setblock 453 250 604 minecraft:light_gray_concrete
fill 453 250 620 453 256 621 minecraft:green_terracotta
fill 453 250 633 453 256 634 minecraft:lime_terracotta
fill 454 250 604 454 255 604 minecraft:white_concrete
setblock 455 250 604 minecraft:light_gray_concrete
fill 456 250 604 456 307 604 minecraft:white_concrete
setblock 457 250 604 minecraft:light_gray_concrete
fill 458 250 604 462 255 604 minecraft:white_concrete
setblock 458 250 607 minecraft:light[level=13]
setblock 458 250 615 minecraft:light[level=13]
setblock 458 250 623 minecraft:light[level=13]
setblock 458 250 631 minecraft:light[level=13]
setblock 458 250 639 minecraft:light[level=13]
setblock 459 250 646 minecraft:light_gray_concrete
fill 460 250 646 465 307 646 minecraft:white_concrete
setblock 463 250 604 minecraft:light_gray_concrete
fill 464 250 604 465 307 604 minecraft:white_concrete
fill 465 250 610 465 307 610 minecraft:white_concrete
fill 465 250 613 465 307 613 minecraft:white_concrete
fill 465 250 622 465 307 624 minecraft:white_concrete
setblock 465 250 625 minecraft:light_gray_concrete
fill 465 250 626 465 255 634 minecraft:white_concrete
fill 423 251 613 423 307 613 minecraft:white_concrete
fill 424 251 611 424 273 612 minecraft:quartz_block
fill 424 251 619 424 273 620 minecraft:quartz_block
fill 424 251 627 424 273 628 minecraft:quartz_block
fill 424 251 635 424 273 636 minecraft:quartz_block
fill 424 251 643 424 273 644 minecraft:quartz_block
fill 425 251 605 426 273 605 minecraft:quartz_block
fill 430 251 645 431 273 645 minecraft:quartz_block
fill 433 251 605 434 273 605 minecraft:quartz_block
fill 434 251 620 434 255 621 minecraft:green_terracotta
fill 434 251 633 434 255 634 minecraft:lime_terracotta
fill 436 251 618 436 255 618 minecraft:green_terracotta
fill 436 251 623 436 255 623 minecraft:green_terracotta
fill 436 251 631 436 255 631 minecraft:lime_terracotta
fill 436 251 636 436 255 636 minecraft:lime_terracotta
fill 437 251 629 437 252 630 minecraft:white_concrete
fill 438 251 617 439 254 617 minecraft:green_terracotta
fill 438 251 624 439 252 624 minecraft:green_terracotta
fill 438 251 629 438 252 629 minecraft:white_concrete
fill 438 251 630 439 252 630 minecraft:lime_terracotta
fill 438 251 637 439 254 637 minecraft:lime_terracotta
fill 438 251 645 439 273 645 minecraft:quartz_block
fill 440 251 604 440 307 604 minecraft:white_concrete
fill 441 251 605 442 273 605 minecraft:quartz_block
fill 443 251 646 443 307 646 minecraft:white_concrete
fill 446 251 645 447 273 645 minecraft:quartz_block
fill 446 251 646 446 307 646 minecraft:white_concrete
fill 449 251 605 450 273 605 minecraft:quartz_block
fill 449 251 617 450 254 617 minecraft:green_terracotta
fill 449 251 624 450 253 624 minecraft:green_terracotta
fill 449 251 630 450 253 630 minecraft:lime_terracotta
fill 449 251 637 450 254 637 minecraft:lime_terracotta
fill 450 251 604 450 307 604 minecraft:white_concrete
fill 452 251 618 452 255 618 minecraft:green_terracotta
fill 452 251 623 452 255 623 minecraft:green_terracotta
fill 452 251 631 452 255 631 minecraft:lime_terracotta
fill 452 251 636 452 255 636 minecraft:lime_terracotta
fill 453 251 604 453 307 604 minecraft:white_concrete
fill 454 251 620 454 255 621 minecraft:green_terracotta
fill 454 251 633 454 255 634 minecraft:lime_terracotta
fill 454 251 645 455 273 645 minecraft:quartz_block
fill 455 251 604 455 307 604 minecraft:white_concrete
fill 457 251 604 457 307 604 minecraft:white_concrete
fill 457 251 605 458 273 605 minecraft:quartz_block
fill 459 251 646 459 307 646 minecraft:white_concrete
fill 462 251 645 463 273 645 minecraft:quartz_block
fill 463 251 604 463 307 604 minecraft:white_concrete
fill 464 251 606 464 273 607 minecraft:quartz_block
fill 464 251 614 464 273 615 minecraft:quartz_block
fill 464 251 622 464 273 623 minecraft:quartz_block
fill 464 251 630 464 273 631 minecraft:quartz_block
fill 464 251 638 464 273 639 minecraft:quartz_block
fill 465 251 619 465 307 619 minecraft:white_concrete
fill 465 251 621 465 307 621 minecraft:white_concrete
fill 465 251 625 465 255 625 minecraft:white_concrete
fill 424 252 605 424 253 610 minecraft:quartz_block
fill 424 252 613 425 252 618 minecraft:quartz_block
fill 424 252 621 425 252 626 minecraft:quartz_block
fill 424 252 629 425 252 634 minecraft:quartz_block
fill 424 252 637 425 252 642 minecraft:quartz_block
fill 424 252 645 429 253 645 minecraft:quartz_block
fill 425 252 606 425 252 612 minecraft:quartz_block
fill 425 252 619 425 252 620 minecraft:quartz_block
fill 425 252 627 425 252 628 minecraft:quartz_block
fill 425 252 635 425 252 636 minecraft:quartz_block
fill 425 252 643 425 252 644 minecraft:quartz_block
fill 426 252 606 463 252 606 minecraft:quartz_block
fill 426 252 644 464 252 644 minecraft:quartz_block
fill 427 252 605 432 253 605 minecraft:quartz_block
fill 432 252 645 437 253 645 minecraft:quartz_block
fill 434 252 619 434 254 619 minecraft:green_terracotta
fill 434 252 622 434 254 622 minecraft:green_terracotta
fill 434 252 632 434 254 632 minecraft:lime_terracotta
fill 434 252 635 434 254 635 minecraft:lime_terracotta
fill 435 252 605 440 253 605 minecraft:quartz_block
fill 435 252 618 435 253 618 minecraft:green_terracotta
fill 435 252 623 435 253 623 minecraft:green_terracotta
fill 435 252 631 435 253 631 minecraft:lime_terracotta
fill 435 252 636 435 253 636 minecraft:lime_terracotta
fill 437 252 609 437 253 609 minecraft:gold_block
fill 440 252 645 445 253 645 minecraft:quartz_block
fill 443 252 605 448 253 605 minecraft:quartz_block
setblock 443 252 624 minecraft:green_terracotta
setblock 443 252 630 minecraft:lime_terracotta
setblock 445 252 624 minecraft:green_terracotta
setblock 445 252 630 minecraft:lime_terracotta
fill 448 252 645 453 253 645 minecraft:quartz_block
fill 451 252 605 456 253 605 minecraft:quartz_block
fill 453 252 618 453 253 618 minecraft:green_terracotta
fill 453 252 623 453 253 623 minecraft:green_terracotta
fill 453 252 631 453 253 631 minecraft:lime_terracotta
fill 453 252 636 453 253 636 minecraft:lime_terracotta
fill 454 252 619 454 254 619 minecraft:green_terracotta
fill 454 252 622 454 254 622 minecraft:green_terracotta
fill 454 252 632 454 254 632 minecraft:lime_terracotta
fill 454 252 635 454 254 635 minecraft:lime_terracotta
fill 456 252 645 461 253 645 minecraft:quartz_block
fill 459 252 605 464 253 605 minecraft:quartz_block
fill 463 252 607 463 252 643 minecraft:quartz_block
fill 464 252 608 464 253 613 minecraft:quartz_block
fill 464 252 616 464 253 621 minecraft:quartz_block
fill 464 252 624 464 253 629 minecraft:quartz_block
fill 464 252 632 464 253 637 minecraft:quartz_block
fill 464 252 640 464 253 643 minecraft:quartz_block
fill 464 252 645 464 253 645 minecraft:quartz_block
fill 424 253 613 424 253 618 minecraft:quartz_block
fill 424 253 621 424 253 626 minecraft:quartz_block
fill 424 253 629 424 253 634 minecraft:quartz_block
fill 424 253 637 424 253 642 minecraft:quartz_block
fill 438 253 624 438 255 624 minecraft:white_concrete
fill 438 253 630 438 255 630 minecraft:white_concrete
fill 439 253 624 441 255 624 minecraft:green_terracotta
fill 439 253 630 441 255 630 minecraft:lime_terracotta
fill 442 253 624 442 255 625 minecraft:white_concrete
fill 442 253 629 442 255 630 minecraft:white_concrete
fill 446 253 624 447 254 624 minecraft:green_terracotta
fill 446 253 630 447 254 630 minecraft:lime_terracotta
fill 448 253 624 448 255 625 minecraft:white_concrete
fill 448 253 629 448 255 630 minecraft:white_concrete
fill 451 253 624 451 255 624 minecraft:white_concrete
fill 451 253 630 451 255 630 minecraft:white_concrete
setblock 464 253 644 minecraft:quartz_block
fill 437 254 624 437 255 624 minecraft:white_concrete
fill 437 254 630 437 255 630 minecraft:white_concrete
fill 438 254 625 438 255 625 minecraft:white_concrete
fill 438 254 629 438 255 629 minecraft:white_concrete
fill 443 254 624 443 255 625 minecraft:white_concrete
fill 443 254 629 443 255 630 minecraft:white_concrete
fill 449 254 624 449 255 625 minecraft:white_concrete
fill 449 254 629 449 255 630 minecraft:white_concrete
setblock 450 254 624 minecraft:green_terracotta
setblock 450 254 630 minecraft:lime_terracotta
fill 451 254 625 451 255 625 minecraft:white_concrete
fill 451 254 629 451 255 629 minecraft:white_concrete
fill 455 254 636 456 255 636 minecraft:white_concrete
setblock 437 255 625 minecraft:white_concrete
setblock 437 255 629 minecraft:white_concrete
setblock 439 255 617 minecraft:green_terracotta
setblock 439 255 637 minecraft:lime_terracotta
fill 447 255 624 447 256 624 minecraft:green_terracotta
fill 447 255 630 447 256 630 minecraft:lime_terracotta
setblock 449 255 617 minecraft:green_terracotta
setblock 449 255 637 minecraft:lime_terracotta
fill 423 256 604 423 307 608 minecraft:white_concrete
fill 423 256 609 423 261 609 minecraft:pearlescent_froglight
fill 423 256 610 423 307 612 minecraft:white_concrete
fill 423 256 617 423 261 617 minecraft:pearlescent_froglight
fill 423 256 618 423 307 620 minecraft:white_concrete
fill 423 256 622 423 307 624 minecraft:white_concrete
fill 423 256 625 423 261 625 minecraft:pearlescent_froglight
fill 423 256 626 423 307 626 minecraft:white_concrete
fill 423 256 633 423 261 633 minecraft:pearlescent_froglight
fill 423 256 634 423 307 640 minecraft:white_concrete
fill 423 256 641 423 261 641 minecraft:pearlescent_froglight
fill 423 256 642 423 307 646 minecraft:white_concrete
fill 424 256 646 425 307 646 minecraft:white_concrete
fill 426 256 619 426 257 631 minecraft:quartz_block
fill 426 256 646 426 261 646 minecraft:pearlescent_froglight
fill 427 256 617 427 257 624 minecraft:quartz_block
fill 427 256 626 427 257 633 minecraft:quartz_block
fill 427 256 646 430 307 646 minecraft:white_concrete
fill 428 256 615 428 257 619 minecraft:quartz_block
fill 428 256 631 428 257 635 minecraft:quartz_block
fill 429 256 604 429 307 604 minecraft:white_concrete
fill 429 256 614 429 257 616 minecraft:quartz_block
fill 429 256 634 429 257 636 minecraft:quartz_block
fill 430 256 604 430 261 604 minecraft:pearlescent_froglight
fill 430 256 613 430 257 615 minecraft:quartz_block
fill 430 256 635 430 257 637 minecraft:quartz_block
fill 431 256 604 431 307 604 minecraft:white_concrete
fill 431 256 612 431 257 614 minecraft:quartz_block
fill 431 256 636 431 257 638 minecraft:quartz_block
fill 432 256 611 433 257 612 minecraft:quartz_block
fill 432 256 638 433 257 639 minecraft:quartz_block
fill 432 256 646 433 307 646 minecraft:white_concrete
fill 433 256 610 435 257 610 minecraft:quartz_block
fill 433 256 640 435 257 640 minecraft:quartz_block
fill 434 256 609 438 257 609 minecraft:quartz_block
fill 434 256 611 434 257 611 minecraft:quartz_block
fill 434 256 639 434 257 639 minecraft:quartz_block
fill 434 256 641 438 257 641 minecraft:quartz_block
fill 434 256 646 434 261 646 minecraft:pearlescent_froglight
fill 435 256 620 435 256 621 minecraft:green_terracotta
fill 435 256 633 435 256 634 minecraft:lime_terracotta
fill 435 256 646 437 307 646 minecraft:white_concrete
fill 436 256 608 443 257 608 minecraft:quartz_block
fill 436 256 642 443 257 642 minecraft:quartz_block
fill 437 256 604 437 307 604 minecraft:white_concrete
fill 438 256 604 438 261 604 minecraft:pearlescent_froglight
fill 438 256 607 450 257 607 minecraft:quartz_block
fill 438 256 643 450 257 643 minecraft:quartz_block
fill 439 256 604 439 307 604 minecraft:white_concrete
fill 440 256 624 441 256 624 minecraft:green_terracotta
fill 440 256 630 441 256 630 minecraft:lime_terracotta
fill 441 256 623 443 256 623 minecraft:green_terracotta
fill 441 256 631 443 256 631 minecraft:lime_terracotta
fill 441 256 646 441 307 646 minecraft:white_concrete
fill 442 256 646 442 261 646 minecraft:pearlescent_froglight
fill 445 256 608 452 257 608 minecraft:quartz_block
fill 445 256 623 447 256 623 minecraft:green_terracotta
fill 445 256 631 447 256 631 minecraft:lime_terracotta
fill 445 256 642 452 257 642 minecraft:quartz_block
fill 446 256 604 446 261 604 minecraft:pearlescent_froglight
fill 447 256 604 449 307 604 minecraft:white_concrete
fill 447 256 646 449 307 646 minecraft:white_concrete
setblock 448 256 624 minecraft:green_terracotta
setblock 448 256 630 minecraft:lime_terracotta
fill 450 256 609 454 257 609 minecraft:quartz_block
fill 450 256 641 454 257 641 minecraft:quartz_block
fill 450 256 646 450 261 646 minecraft:pearlescent_froglight
fill 451 256 646 457 307 646 minecraft:white_concrete
setblock 452 256 619 minecraft:green_terracotta
setblock 452 256 622 minecraft:green_terracotta
setblock 452 256 632 minecraft:lime_terracotta
setblock 452 256 635 minecraft:lime_terracotta
fill 453 256 610 455 257 610 minecraft:quartz_block
fill 453 256 640 455 257 640 minecraft:quartz_block
fill 454 256 604 454 261 604 minecraft:pearlescent_froglight
fill 454 256 611 456 257 611 minecraft:quartz_block
fill 454 256 639 456 257 639 minecraft:quartz_block
fill 455 256 612 457 257 612 minecraft:quartz_block
fill 455 256 638 457 257 638 minecraft:quartz_block
fill 457 256 613 458 257 614 minecraft:quartz_block
fill 457 256 616 458 257 617 minecraft:gold_block
fill 457 256 636 458 257 637 minecraft:quartz_block
fill 458 256 604 461 307 604 minecraft:white_concrete
fill 458 256 615 460 257 615 minecraft:quartz_block
fill 458 256 635 460 257 635 minecraft:quartz_block
fill 458 256 646 458 261 646 minecraft:pearlescent_froglight
fill 459 256 614 459 257 614 minecraft:quartz_block
fill 459 256 616 460 257 616 minecraft:quartz_block
fill 459 256 634 460 257 634 minecraft:quartz_block
fill 459 256 636 459 257 636 minecraft:quartz_block
fill 460 256 617 461 257 619 minecraft:quartz_block
fill 460 256 631 461 257 633 minecraft:quartz_block
fill 461 256 620 462 257 624 minecraft:quartz_block
fill 461 256 626 462 257 630 minecraft:quartz_block
fill 462 256 604 462 261 604 minecraft:pearlescent_froglight
fill 462 256 619 462 257 619 minecraft:quartz_block
fill 462 256 625 462 257 625 minecraft:quartz_block
fill 462 256 631 462 257 631 minecraft:quartz_block
fill 465 256 605 465 307 608 minecraft:white_concrete
fill 465 256 609 465 261 609 minecraft:pearlescent_froglight
fill 465 256 616 465 307 616 minecraft:white_concrete
fill 465 256 617 465 261 617 minecraft:pearlescent_froglight
fill 465 256 625 465 261 625 minecraft:pearlescent_froglight
fill 465 256 626 465 307 632 minecraft:white_concrete
fill 465 256 633 465 261 633 minecraft:pearlescent_froglight
fill 465 256 634 465 307 634 minecraft:white_concrete
fill 465 256 641 465 261 641 minecraft:pearlescent_froglight
fill 465 256 642 465 307 645 minecraft:white_concrete
fill 436 257 636 436 258 636 minecraft:black_concrete
fill 439 257 618 440 257 618 minecraft:green_terracotta
fill 439 257 623 442 257 623 minecraft:green_terracotta
fill 439 257 631 442 257 631 minecraft:lime_terracotta
fill 439 257 636 440 257 636 minecraft:lime_terracotta
fill 446 257 623 449 257 623 minecraft:green_terracotta
fill 446 257 631 449 257 631 minecraft:lime_terracotta
fill 448 257 618 449 257 618 minecraft:green_terracotta
fill 448 257 636 449 257 636 minecraft:lime_terracotta
setblock 426 258 607 minecraft:light[level=13]
setblock 426 258 615 minecraft:light[level=13]
setblock 426 258 623 minecraft:light[level=13]
fill 426 258 628 426 258 629 minecraft:pearlescent_froglight
setblock 426 258 631 minecraft:light[level=13]
setblock 426 258 639 minecraft:light[level=13]
setblock 434 258 607 minecraft:light[level=13]
setblock 434 258 615 minecraft:light[level=13]
setblock 434 258 623 minecraft:light[level=13]
setblock 434 258 631 minecraft:light[level=13]
setblock 434 258 639 minecraft:light[level=13]
fill 437 258 621 439 259 621 minecraft:pearlescent_froglight
fill 437 258 633 439 259 633 minecraft:pearlescent_froglight
fill 438 258 620 438 259 620 minecraft:pearlescent_froglight
fill 438 258 622 438 259 622 minecraft:pearlescent_froglight
fill 438 258 632 438 259 632 minecraft:pearlescent_froglight
fill 438 258 634 438 259 634 minecraft:pearlescent_froglight
fill 439 258 619 439 258 620 minecraft:green_terracotta
setblock 439 258 622 minecraft:green_terracotta
setblock 439 258 632 minecraft:lime_terracotta
fill 439 258 634 439 258 635 minecraft:lime_terracotta
setblock 442 258 607 minecraft:light[level=13]
setblock 442 258 615 minecraft:light[level=13]
fill 442 258 618 446 258 618 minecraft:green_terracotta
fill 442 258 636 446 258 636 minecraft:lime_terracotta
setblock 442 258 639 minecraft:light[level=13]
fill 443 258 613 443 259 613 minecraft:gold_block
fill 447 258 619 449 258 619 minecraft:green_terracotta
fill 447 258 622 449 258 622 minecraft:green_terracotta
fill 447 258 632 449 258 632 minecraft:lime_terracotta
fill 447 258 635 449 258 635 minecraft:lime_terracotta
setblock 450 258 607 minecraft:light[level=13]
setblock 450 258 615 minecraft:light[level=13]
setblock 450 258 623 minecraft:light[level=13]
setblock 450 258 631 minecraft:light[level=13]
setblock 450 258 639 minecraft:light[level=13]
setblock 458 258 607 minecraft:light[level=13]
setblock 458 258 615 minecraft:light[level=13]
setblock 458 258 623 minecraft:light[level=13]
setblock 458 258 631 minecraft:light[level=13]
setblock 458 258 639 minecraft:light[level=13]
fill 441 259 620 447 259 621 minecraft:green_terracotta
fill 441 259 633 447 259 634 minecraft:lime_terracotta
fill 423 262 609 423 269 609 minecraft:white_concrete
fill 423 262 617 423 269 617 minecraft:white_concrete
fill 423 262 625 423 269 625 minecraft:white_concrete
fill 423 262 633 423 269 633 minecraft:white_concrete
fill 423 262 641 423 269 641 minecraft:white_concrete
fill 426 262 646 426 269 646 minecraft:white_concrete
fill 430 262 604 430 269 604 minecraft:white_concrete
fill 434 262 646 434 269 646 minecraft:white_concrete
fill 438 262 604 438 269 604 minecraft:white_concrete
fill 442 262 646 442 269 646 minecraft:white_concrete
fill 443 262 633 443 263 633 minecraft:white_concrete
fill 446 262 604 446 269 604 minecraft:white_concrete
fill 450 262 646 450 269 646 minecraft:white_concrete
fill 454 262 604 454 269 604 minecraft:white_concrete
fill 458 262 646 458 269 646 minecraft:white_concrete
fill 462 262 604 462 269 604 minecraft:white_concrete
fill 465 262 609 465 269 609 minecraft:white_concrete
fill 465 262 617 465 269 617 minecraft:white_concrete
fill 465 262 625 465 269 625 minecraft:white_concrete
fill 465 262 633 465 269 633 minecraft:white_concrete
fill 465 262 641 465 269 641 minecraft:white_concrete
fill 424 266 605 424 267 610 minecraft:quartz_block
fill 424 266 613 425 266 618 minecraft:quartz_block
fill 424 266 621 425 266 626 minecraft:quartz_block
fill 424 266 629 425 266 634 minecraft:quartz_block
fill 424 266 637 425 266 642 minecraft:quartz_block
fill 424 266 645 429 267 645 minecraft:quartz_block
fill 425 266 606 425 266 612 minecraft:quartz_block
fill 425 266 619 425 266 620 minecraft:quartz_block
fill 425 266 627 425 266 628 minecraft:quartz_block
fill 425 266 635 425 266 636 minecraft:quartz_block
fill 425 266 643 425 266 644 minecraft:quartz_block
fill 426 266 606 463 266 606 minecraft:quartz_block
setblock 426 266 607 minecraft:light[level=13]
setblock 426 266 615 minecraft:light[level=13]
setblock 426 266 623 minecraft:light[level=13]
setblock 426 266 631 minecraft:light[level=13]
setblock 426 266 639 minecraft:light[level=13]
fill 426 266 644 464 266 644 minecraft:quartz_block
fill 427 266 605 432 267 605 minecraft:quartz_block
fill 432 266 645 437 267 645 minecraft:quartz_block
setblock 434 266 607 minecraft:light[level=13]
setblock 434 266 615 minecraft:light[level=13]
setblock 434 266 623 minecraft:light[level=13]
setblock 434 266 631 minecraft:light[level=13]
setblock 434 266 639 minecraft:light[level=13]
fill 435 266 605 440 267 605 minecraft:quartz_block
fill 440 266 645 445 267 645 minecraft:quartz_block
setblock 442 266 607 minecraft:light[level=13]
setblock 442 266 615 minecraft:light[level=13]
setblock 442 266 623 minecraft:light[level=13]
setblock 442 266 631 minecraft:light[level=13]
setblock 442 266 639 minecraft:light[level=13]
fill 443 266 605 448 267 605 minecraft:quartz_block
fill 448 266 645 453 267 645 minecraft:quartz_block
setblock 450 266 607 minecraft:light[level=13]
setblock 450 266 615 minecraft:light[level=13]
setblock 450 266 623 minecraft:light[level=13]
setblock 450 266 631 minecraft:light[level=13]
setblock 450 266 639 minecraft:light[level=13]
fill 451 266 605 456 267 605 minecraft:quartz_block
fill 456 266 645 461 267 645 minecraft:quartz_block
setblock 458 266 607 minecraft:light[level=13]
setblock 458 266 615 minecraft:light[level=13]
setblock 458 266 623 minecraft:light[level=13]
setblock 458 266 631 minecraft:light[level=13]
setblock 458 266 639 minecraft:light[level=13]
fill 459 266 605 464 267 605 minecraft:quartz_block
fill 463 266 607 463 266 643 minecraft:quartz_block
fill 464 266 608 464 267 613 minecraft:quartz_block
fill 464 266 616 464 267 621 minecraft:quartz_block
fill 464 266 624 464 267 629 minecraft:quartz_block
fill 464 266 632 464 267 637 minecraft:quartz_block
fill 464 266 640 464 267 643 minecraft:quartz_block
fill 464 266 645 464 267 645 minecraft:quartz_block
fill 424 267 613 424 267 618 minecraft:quartz_block
fill 424 267 621 424 267 626 minecraft:quartz_block
fill 424 267 629 424 267 634 minecraft:quartz_block
fill 424 267 637 424 267 642 minecraft:quartz_block
setblock 464 267 644 minecraft:quartz_block
fill 423 270 609 423 273 609 minecraft:pearlescent_froglight
fill 423 270 617 423 273 617 minecraft:pearlescent_froglight
fill 423 270 625 423 273 625 minecraft:pearlescent_froglight
fill 423 270 633 423 273 633 minecraft:pearlescent_froglight
fill 423 270 641 423 273 641 minecraft:pearlescent_froglight
fill 426 270 646 426 273 646 minecraft:pearlescent_froglight
fill 430 270 604 430 273 604 minecraft:pearlescent_froglight
fill 434 270 646 434 273 646 minecraft:pearlescent_froglight
fill 438 270 604 438 273 604 minecraft:pearlescent_froglight
fill 442 270 646 442 273 646 minecraft:pearlescent_froglight
fill 446 270 604 446 273 604 minecraft:pearlescent_froglight
fill 450 270 646 450 273 646 minecraft:pearlescent_froglight
fill 454 270 604 454 273 604 minecraft:pearlescent_froglight
fill 458 270 646 458 273 646 minecraft:pearlescent_froglight
fill 462 270 604 462 273 604 minecraft:pearlescent_froglight
fill 465 270 609 465 273 609 minecraft:pearlescent_froglight
fill 465 270 617 465 273 617 minecraft:pearlescent_froglight
fill 465 270 625 465 273 625 minecraft:pearlescent_froglight
fill 465 270 633 465 273 633 minecraft:pearlescent_froglight
fill 465 270 641 465 273 641 minecraft:pearlescent_froglight
fill 436 271 624 436 272 624 minecraft:gold_block
fill 423 274 609 423 283 609 minecraft:white_concrete
fill 423 274 617 423 283 617 minecraft:white_concrete
fill 423 274 625 423 283 625 minecraft:white_concrete
fill 423 274 633 423 283 633 minecraft:white_concrete
fill 423 274 641 423 283 641 minecraft:white_concrete
setblock 426 274 607 minecraft:light[level=13]
setblock 426 274 615 minecraft:light[level=13]
setblock 426 274 623 minecraft:light[level=13]
setblock 426 274 631 minecraft:light[level=13]
setblock 426 274 639 minecraft:light[level=13]
fill 426 274 646 426 283 646 minecraft:white_concrete
fill 430 274 604 430 283 604 minecraft:white_concrete
setblock 434 274 607 minecraft:light[level=13]
setblock 434 274 615 minecraft:light[level=13]
setblock 434 274 623 minecraft:light[level=13]
setblock 434 274 631 minecraft:light[level=13]
setblock 434 274 639 minecraft:light[level=13]
fill 434 274 646 434 283 646 minecraft:white_concrete
fill 438 274 604 438 283 604 minecraft:white_concrete
setblock 442 274 607 minecraft:light[level=13]
setblock 442 274 615 minecraft:light[level=13]
setblock 442 274 623 minecraft:light[level=13]
setblock 442 274 631 minecraft:light[level=13]
setblock 442 274 639 minecraft:light[level=13]
fill 442 274 646 442 283 646 minecraft:white_concrete
fill 446 274 604 446 283 604 minecraft:white_concrete
setblock 450 274 607 minecraft:light[level=13]
setblock 450 274 615 minecraft:light[level=13]
setblock 450 274 623 minecraft:light[level=13]
setblock 450 274 631 minecraft:light[level=13]
setblock 450 274 639 minecraft:light[level=13]
fill 450 274 646 450 283 646 minecraft:white_concrete
fill 454 274 604 454 283 604 minecraft:white_concrete
setblock 458 274 607 minecraft:light[level=13]
setblock 458 274 615 minecraft:light[level=13]
setblock 458 274 623 minecraft:light[level=13]
setblock 458 274 631 minecraft:light[level=13]
setblock 458 274 639 minecraft:light[level=13]
fill 458 274 646 458 283 646 minecraft:white_concrete
fill 462 274 604 462 283 604 minecraft:white_concrete
fill 465 274 609 465 283 609 minecraft:white_concrete
fill 465 274 617 465 283 617 minecraft:white_concrete
fill 465 274 625 465 283 625 minecraft:white_concrete
fill 465 274 633 465 283 633 minecraft:white_concrete
fill 465 274 641 465 283 641 minecraft:white_concrete
fill 440 278 625 442 278 627 minecraft:redstone_block
fill 442 278 630 444 278 632 minecraft:redstone_block
fill 445 278 621 447 278 623 minecraft:redstone_block
fill 450 278 626 452 278 628 minecraft:redstone_block
fill 430 279 627 439 279 627 minecraft:gold_block
fill 432 279 621 432 280 621 minecraft:gold_block
fill 432 279 633 432 280 633 minecraft:gold_block
fill 433 279 622 437 280 622 minecraft:gold_block
fill 433 279 632 437 280 632 minecraft:gold_block
fill 434 279 623 444 279 623 minecraft:gold_block
fill 434 279 626 439 279 626 minecraft:gold_block
fill 434 279 628 444 279 628 minecraft:gold_block
fill 434 279 631 441 279 631 minecraft:gold_block
fill 435 279 616 435 280 616 minecraft:gold_block
fill 435 279 638 435 280 638 minecraft:gold_block
fill 436 279 617 437 280 618 minecraft:gold_block
fill 436 279 624 456 279 624 minecraft:gold_block
fill 436 279 630 441 279 630 minecraft:gold_block
fill 436 279 636 437 280 637 minecraft:gold_block
fill 437 279 619 439 280 619 minecraft:gold_block
fill 437 279 635 439 280 635 minecraft:gold_block
fill 438 279 618 438 280 618 minecraft:gold_block
fill 438 279 620 440 279 620 minecraft:gold_block
fill 438 279 625 439 279 625 minecraft:gold_block
fill 438 279 629 454 279 629 minecraft:gold_block
fill 438 279 634 440 279 634 minecraft:gold_block
fill 438 279 636 438 280 636 minecraft:gold_block
fill 439 279 621 444 279 621 minecraft:gold_block
fill 439 279 633 453 279 633 minecraft:gold_block
fill 440 279 613 440 280 613 minecraft:gold_block
fill 440 279 622 444 279 622 minecraft:gold_block
fill 440 279 632 441 279 632 minecraft:gold_block
fill 440 279 641 440 280 641 minecraft:gold_block
fill 441 279 614 441 280 618 minecraft:gold_block
fill 441 279 636 441 280 640 minecraft:gold_block
fill 442 279 615 442 279 620 minecraft:gold_block
fill 442 279 634 442 279 639 minecraft:gold_block
fill 443 279 617 443 279 620 minecraft:gold_block
fill 443 279 625 444 279 627 minecraft:gold_block
fill 443 279 634 443 279 637 minecraft:gold_block
fill 444 279 619 450 279 620 minecraft:gold_block
fill 444 279 634 450 279 635 minecraft:gold_block
fill 445 279 615 447 279 618 minecraft:gold_block
fill 445 279 625 454 279 625 minecraft:gold_block
fill 445 279 630 452 279 632 minecraft:gold_block
fill 445 279 636 447 279 639 minecraft:gold_block
fill 446 279 611 446 280 614 minecraft:gold_block
fill 446 279 640 446 280 643 minecraft:gold_block
fill 448 279 621 452 279 623 minecraft:gold_block
fill 448 279 626 449 279 628 minecraft:gold_block
fill 449 279 617 451 279 618 minecraft:gold_block
fill 449 279 636 451 279 637 minecraft:gold_block
fill 450 279 615 451 280 616 minecraft:gold_block
fill 450 279 638 451 280 639 minecraft:gold_block
fill 451 279 614 451 280 614 minecraft:gold_block
fill 451 279 640 451 280 640 minecraft:gold_block
fill 452 279 613 452 280 613 minecraft:gold_block
fill 452 279 620 454 279 620 minecraft:gold_block
fill 452 279 634 454 279 634 minecraft:gold_block
fill 452 279 641 452 280 641 minecraft:gold_block
fill 453 279 619 455 280 619 minecraft:gold_block
fill 453 279 621 453 280 621 minecraft:gold_block
fill 453 279 623 458 279 623 minecraft:gold_block
fill 453 279 626 458 279 628 minecraft:gold_block
fill 453 279 630 456 279 631 minecraft:gold_block
fill 453 279 635 455 280 635 minecraft:gold_block
fill 454 279 618 456 280 618 minecraft:gold_block
fill 454 279 636 456 280 636 minecraft:gold_block
fill 455 279 617 456 280 617 minecraft:gold_block
fill 455 279 622 459 280 622 minecraft:gold_block
fill 455 279 632 459 280 632 minecraft:gold_block
fill 455 279 637 456 280 637 minecraft:gold_block
fill 457 279 616 457 280 616 minecraft:gold_block
fill 457 279 631 458 280 631 minecraft:gold_block
fill 457 279 638 457 280 638 minecraft:gold_block
fill 459 279 627 462 280 627 minecraft:gold_block
fill 460 279 621 460 280 621 minecraft:gold_block
fill 460 279 633 460 280 633 minecraft:gold_block
fill 424 280 605 429 280 645 minecraft:white_concrete
fill 430 280 605 431 280 626 minecraft:white_concrete
fill 430 280 627 434 280 627 minecraft:gold_block
fill 430 280 628 431 280 645 minecraft:white_concrete
fill 432 280 605 434 280 620 minecraft:white_concrete
fill 432 280 622 432 280 626 minecraft:white_concrete
fill 432 280 628 432 280 632 minecraft:white_concrete
fill 432 280 634 434 280 645 minecraft:white_concrete
fill 433 280 621 438 280 621 minecraft:white_concrete
fill 433 280 623 433 280 626 minecraft:white_concrete
fill 433 280 628 433 280 631 minecraft:white_concrete
fill 433 280 633 438 280 633 minecraft:white_concrete
fill 434 280 623 435 280 623 minecraft:gold_block
fill 434 280 624 435 280 625 minecraft:white_concrete
fill 434 280 626 438 280 626 minecraft:gold_block
fill 434 280 628 438 280 628 minecraft:gold_block
fill 434 280 629 435 280 630 minecraft:white_concrete
fill 434 280 631 435 280 631 minecraft:gold_block
fill 435 280 605 439 280 615 minecraft:white_concrete
fill 435 280 617 435 280 620 minecraft:white_concrete
fill 435 280 627 438 280 627 minecraft:white_concrete
fill 435 280 634 435 280 637 minecraft:white_concrete
fill 435 280 639 439 280 645 minecraft:white_concrete
fill 436 280 616 440 280 616 minecraft:white_concrete
fill 436 280 619 436 280 620 minecraft:white_concrete
fill 436 280 623 438 280 623 minecraft:white_concrete
fill 436 280 624 437 280 624 minecraft:gold_block
fill 436 280 625 437 280 625 minecraft:white_concrete
fill 436 280 629 437 280 629 minecraft:white_concrete
fill 436 280 630 437 280 630 minecraft:gold_block
fill 436 280 631 438 280 631 minecraft:white_concrete
fill 436 280 634 436 280 635 minecraft:white_concrete
fill 436 280 638 440 280 638 minecraft:white_concrete
setblock 437 280 620 minecraft:white_concrete
setblock 437 280 634 minecraft:white_concrete
fill 438 280 617 440 280 617 minecraft:white_concrete
setblock 438 280 620 minecraft:gold_block
fill 438 280 622 443 280 622 minecraft:white_concrete
setblock 438 280 624 minecraft:white_concrete
setblock 438 280 625 minecraft:gold_block
setblock 438 280 629 minecraft:gold_block
fill 438 280 630 440 280 630 minecraft:white_concrete
fill 438 280 632 440 280 632 minecraft:white_concrete
setblock 438 280 634 minecraft:gold_block
fill 438 280 637 440 280 637 minecraft:white_concrete
fill 439 280 618 440 280 618 minecraft:white_concrete
setblock 439 280 620 minecraft:white_concrete
setblock 439 280 621 minecraft:gold_block
fill 439 280 623 440 280 623 minecraft:gold_block
fill 439 280 624 439 280 628 minecraft:pearlescent_froglight
fill 439 280 629 440 280 629 minecraft:white_concrete
fill 439 280 631 440 280 631 minecraft:gold_block
setblock 439 280 633 minecraft:gold_block
setblock 439 280 634 minecraft:white_concrete
fill 439 280 636 440 280 636 minecraft:white_concrete
fill 440 280 605 445 280 612 minecraft:white_concrete
fill 440 280 614 440 280 615 minecraft:white_concrete
fill 440 280 619 443 280 619 minecraft:white_concrete
setblock 440 280 620 minecraft:gold_block
fill 440 280 621 441 280 621 minecraft:white_concrete
fill 440 280 624 448 280 624 minecraft:pearlescent_froglight
fill 440 280 625 442 280 627 minecraft:white_concrete
fill 440 280 628 444 280 628 minecraft:pearlescent_froglight
setblock 440 280 633 minecraft:white_concrete
setblock 440 280 634 minecraft:gold_block
fill 440 280 635 443 280 635 minecraft:white_concrete
fill 440 280 639 440 280 640 minecraft:white_concrete
fill 440 280 642 445 280 645 minecraft:white_concrete
fill 441 280 613 445 280 613 minecraft:white_concrete
setblock 441 280 620 minecraft:white_concrete
fill 441 280 623 443 280 623 minecraft:white_concrete
fill 441 280 629 441 280 633 minecraft:pearlescent_froglight
setblock 441 280 634 minecraft:white_concrete
fill 441 280 641 445 280 641 minecraft:white_concrete
fill 442 280 614 445 280 614 minecraft:white_concrete
fill 442 280 615 442 280 616 minecraft:gold_block
fill 442 280 617 442 280 618 minecraft:white_concrete
fill 442 280 620 442 280 621 minecraft:gold_block
fill 442 280 629 453 280 629 minecraft:pearlescent_froglight
fill 442 280 630 444 280 632 minecraft:white_concrete
fill 442 280 633 445 280 633 minecraft:pearlescent_froglight
setblock 442 280 634 minecraft:gold_block
fill 442 280 636 442 280 637 minecraft:white_concrete
fill 442 280 638 442 280 639 minecraft:gold_block
fill 442 280 640 445 280 640 minecraft:white_concrete
fill 443 280 615 444 280 616 minecraft:white_concrete
fill 443 280 617 443 280 618 minecraft:gold_block
fill 443 280 620 443 280 621 minecraft:white_concrete
fill 443 280 625 444 280 627 minecraft:pearlescent_froglight
fill 443 280 634 444 280 634 minecraft:white_concrete
fill 443 280 636 443 280 637 minecraft:gold_block
fill 443 280 638 444 280 639 minecraft:white_concrete
fill 444 280 617 444 280 618 minecraft:white_concrete
fill 444 280 619 445 280 619 minecraft:gold_block
fill 444 280 620 444 280 623 minecraft:pearlescent_froglight
fill 444 280 635 445 280 635 minecraft:gold_block
fill 444 280 636 444 280 637 minecraft:white_concrete
fill 445 280 615 445 280 618 minecraft:gold_block
fill 445 280 620 448 280 620 minecraft:pearlescent_froglight
fill 445 280 621 447 280 623 minecraft:white_concrete
fill 445 280 625 453 280 625 minecraft:pearlescent_froglight
fill 445 280 630 445 280 632 minecraft:pearlescent_froglight
setblock 445 280 634 minecraft:gold_block
fill 445 280 636 445 280 639 minecraft:gold_block
fill 446 280 605 464 280 610 minecraft:white_concrete
fill 446 280 615 447 280 615 minecraft:gold_block
fill 446 280 616 446 280 619 minecraft:white_concrete
fill 446 280 630 446 280 631 minecraft:pearlescent_froglight
fill 446 280 632 446 280 638 minecraft:white_concrete
fill 446 280 639 447 280 639 minecraft:gold_block
fill 446 280 644 464 280 645 minecraft:white_concrete
fill 447 280 611 450 280 614 minecraft:white_concrete
fill 447 280 616 447 280 619 minecraft:gold_block
fill 447 280 630 448 280 630 minecraft:pearlescent_froglight
fill 447 280 631 451 280 631 minecraft:white_concrete
fill 447 280 632 447 280 638 minecraft:gold_block
fill 447 280 640 450 280 643 minecraft:white_concrete
fill 448 280 615 448 280 618 minecraft:white_concrete
setblock 448 280 619 minecraft:gold_block
fill 448 280 621 448 280 623 minecraft:pearlescent_froglight
fill 448 280 626 449 280 628 minecraft:pearlescent_froglight
fill 448 280 632 449 280 634 minecraft:white_concrete
setblock 448 280 635 minecraft:gold_block
fill 448 280 636 448 280 639 minecraft:white_concrete
fill 449 280 615 449 280 616 minecraft:white_concrete
fill 449 280 617 449 280 618 minecraft:gold_block
fill 449 280 619 449 280 624 minecraft:white_concrete
fill 449 280 630 454 280 630 minecraft:white_concrete
fill 449 280 635 452 280 635 minecraft:white_concrete
fill 449 280 636 449 280 637 minecraft:gold_block
fill 449 280 638 449 280 639 minecraft:white_concrete
fill 450 280 617 450 280 619 minecraft:white_concrete
fill 450 280 620 450 280 621 minecraft:gold_block
fill 450 280 622 451 280 624 minecraft:white_concrete
fill 450 280 626 452 280 628 minecraft:white_concrete
fill 450 280 632 454 280 632 minecraft:white_concrete
fill 450 280 633 450 280 634 minecraft:gold_block
fill 450 280 636 450 280 637 minecraft:white_concrete
fill 451 280 611 451 280 613 minecraft:white_concrete
fill 451 280 617 451 280 618 minecraft:gold_block
fill 451 280 619 451 280 621 minecraft:white_concrete
fill 451 280 633 451 280 634 minecraft:white_concrete
fill 451 280 636 451 280 637 minecraft:gold_block
fill 451 280 641 451 280 643 minecraft:white_concrete
fill 452 280 611 464 280 612 minecraft:white_concrete
fill 452 280 614 452 280 619 minecraft:white_concrete
setblock 452 280 620 minecraft:gold_block
fill 452 280 621 452 280 622 minecraft:white_concrete
fill 452 280 623 453 280 623 minecraft:gold_block
fill 452 280 624 454 280 624 minecraft:white_concrete
fill 452 280 631 453 280 631 minecraft:gold_block
setblock 452 280 633 minecraft:white_concrete
setblock 452 280 634 minecraft:gold_block
fill 452 280 636 453 280 640 minecraft:white_concrete
fill 452 280 642 464 280 643 minecraft:white_concrete
fill 453 280 613 453 280 618 minecraft:white_concrete
setblock 453 280 620 minecraft:white_concrete
fill 453 280 622 454 280 622 minecraft:white_concrete
fill 453 280 626 453 280 628 minecraft:pearlescent_froglight
setblock 453 280 633 minecraft:gold_block
setblock 453 280 634 minecraft:white_concrete
fill 453 280 641 464 280 641 minecraft:white_concrete
fill 454 280 613 454 280 617 minecraft:white_concrete
setblock 454 280 620 minecraft:gold_block
fill 454 280 621 459 280 621 minecraft:white_concrete
fill 454 280 623 456 280 623 minecraft:white_concrete
fill 454 280 625 454 280 626 minecraft:gold_block
fill 454 280 627 457 280 627 minecraft:white_concrete
fill 454 280 628 454 280 629 minecraft:gold_block
fill 454 280 631 456 280 631 minecraft:white_concrete
fill 454 280 633 459 280 633 minecraft:white_concrete
setblock 454 280 634 minecraft:gold_block
fill 454 280 637 454 280 640 minecraft:white_concrete
fill 455 280 613 456 280 616 minecraft:white_concrete
fill 455 280 620 464 280 620 minecraft:white_concrete
fill 455 280 624 456 280 624 minecraft:gold_block
fill 455 280 625 464 280 625 minecraft:white_concrete
fill 455 280 626 458 280 626 minecraft:gold_block
fill 455 280 628 458 280 628 minecraft:gold_block
fill 455 280 629 464 280 629 minecraft:white_concrete
fill 455 280 630 456 280 630 minecraft:gold_block
fill 455 280 634 464 280 634 minecraft:white_concrete
fill 455 280 638 456 280 640 minecraft:white_concrete
fill 456 280 619 464 280 619 minecraft:white_concrete
fill 456 280 635 464 280 635 minecraft:white_concrete
fill 457 280 613 464 280 615 minecraft:white_concrete
fill 457 280 617 464 280 618 minecraft:white_concrete
fill 457 280 623 458 280 623 minecraft:gold_block
fill 457 280 624 464 280 624 minecraft:white_concrete
fill 457 280 630 464 280 630 minecraft:white_concrete
fill 457 280 636 464 280 637 minecraft:white_concrete
fill 457 280 639 464 280 640 minecraft:white_concrete
fill 458 280 616 464 280 616 minecraft:white_concrete
setblock 458 280 627 minecraft:gold_block
fill 458 280 638 464 280 638 minecraft:white_concrete
fill 459 280 623 464 280 623 minecraft:white_concrete
fill 459 280 626 464 280 626 minecraft:white_concrete
fill 459 280 628 464 280 628 minecraft:white_concrete
fill 459 280 631 464 280 631 minecraft:white_concrete
fill 460 280 622 464 280 622 minecraft:white_concrete
fill 460 280 632 464 280 632 minecraft:white_concrete
fill 461 280 621 464 280 621 minecraft:white_concrete
fill 461 280 633 464 280 633 minecraft:white_concrete
fill 463 280 627 464 280 627 minecraft:white_concrete
setblock 426 282 607 minecraft:light[level=13]
setblock 426 282 615 minecraft:light[level=13]
setblock 426 282 623 minecraft:light[level=13]
setblock 426 282 631 minecraft:light[level=13]
setblock 426 282 639 minecraft:light[level=13]
setblock 434 282 607 minecraft:light[level=13]
setblock 434 282 615 minecraft:light[level=13]
setblock 434 282 623 minecraft:light[level=13]
setblock 434 282 631 minecraft:light[level=13]
setblock 434 282 639 minecraft:light[level=13]
setblock 442 282 607 minecraft:light[level=13]
setblock 442 282 615 minecraft:light[level=13]
setblock 442 282 623 minecraft:light[level=13]
setblock 442 282 631 minecraft:light[level=13]
setblock 442 282 639 minecraft:light[level=13]
setblock 450 282 607 minecraft:light[level=13]
setblock 450 282 615 minecraft:light[level=13]
setblock 450 282 623 minecraft:light[level=13]
setblock 450 282 631 minecraft:light[level=13]
setblock 450 282 639 minecraft:light[level=13]
setblock 458 282 607 minecraft:light[level=13]
setblock 458 282 615 minecraft:light[level=13]
setblock 458 282 623 minecraft:light[level=13]
setblock 458 282 631 minecraft:light[level=13]
setblock 458 282 639 minecraft:light[level=13]
fill 423 284 609 423 289 609 minecraft:pearlescent_froglight
fill 423 284 617 423 289 617 minecraft:pearlescent_froglight
fill 423 284 625 423 289 625 minecraft:pearlescent_froglight
fill 423 284 633 423 289 633 minecraft:pearlescent_froglight
fill 423 284 641 423 289 641 minecraft:pearlescent_froglight
fill 424 284 611 424 300 612 minecraft:quartz_block
fill 424 284 619 424 300 620 minecraft:quartz_block
fill 424 284 627 424 300 628 minecraft:quartz_block
fill 424 284 635 424 300 636 minecraft:quartz_block
fill 424 284 643 424 300 644 minecraft:quartz_block
fill 425 284 605 426 300 605 minecraft:quartz_block
fill 426 284 646 426 289 646 minecraft:pearlescent_froglight
fill 430 284 604 430 289 604 minecraft:pearlescent_froglight
fill 430 284 645 431 300 645 minecraft:quartz_block
fill 433 284 605 434 300 605 minecraft:quartz_block
fill 434 284 646 434 289 646 minecraft:pearlescent_froglight
fill 438 284 604 438 289 604 minecraft:pearlescent_froglight
fill 438 284 645 439 300 645 minecraft:quartz_block
fill 441 284 605 442 300 605 minecraft:quartz_block
fill 442 284 646 442 289 646 minecraft:pearlescent_froglight
fill 446 284 604 446 289 604 minecraft:pearlescent_froglight
fill 446 284 645 447 300 645 minecraft:quartz_block
fill 449 284 605 450 300 605 minecraft:quartz_block
fill 450 284 646 450 289 646 minecraft:pearlescent_froglight
fill 454 284 604 454 289 604 minecraft:pearlescent_froglight
fill 454 284 645 455 300 645 minecraft:quartz_block
fill 457 284 605 458 300 605 minecraft:quartz_block
fill 458 284 646 458 289 646 minecraft:pearlescent_froglight
fill 462 284 604 462 289 604 minecraft:pearlescent_froglight
fill 462 284 645 463 300 645 minecraft:quartz_block
fill 464 284 606 464 300 607 minecraft:quartz_block
fill 464 284 614 464 300 615 minecraft:quartz_block
fill 464 284 622 464 300 623 minecraft:quartz_block
fill 464 284 630 464 300 631 minecraft:quartz_block
fill 464 284 638 464 300 639 minecraft:quartz_block
fill 465 284 609 465 289 609 minecraft:pearlescent_froglight
fill 465 284 617 465 289 617 minecraft:pearlescent_froglight
fill 465 284 625 465 289 625 minecraft:pearlescent_froglight
fill 465 284 633 465 289 633 minecraft:pearlescent_froglight
fill 465 284 641 465 289 641 minecraft:pearlescent_froglight
fill 423 290 609 423 297 609 minecraft:white_concrete
fill 423 290 617 423 297 617 minecraft:white_concrete
fill 423 290 625 423 297 625 minecraft:white_concrete
fill 423 290 633 423 297 633 minecraft:white_concrete
fill 423 290 641 423 297 641 minecraft:white_concrete
setblock 426 290 607 minecraft:light[level=13]
setblock 426 290 615 minecraft:light[level=13]
setblock 426 290 623 minecraft:light[level=13]
setblock 426 290 631 minecraft:light[level=13]
setblock 426 290 639 minecraft:light[level=13]
fill 426 290 646 426 297 646 minecraft:white_concrete
fill 430 290 604 430 297 604 minecraft:white_concrete
setblock 434 290 607 minecraft:light[level=13]
setblock 434 290 615 minecraft:light[level=13]
setblock 434 290 623 minecraft:light[level=13]
setblock 434 290 631 minecraft:light[level=13]
setblock 434 290 639 minecraft:light[level=13]
fill 434 290 646 434 297 646 minecraft:white_concrete
fill 438 290 604 438 297 604 minecraft:white_concrete
setblock 442 290 607 minecraft:light[level=13]
setblock 442 290 615 minecraft:light[level=13]
setblock 442 290 623 minecraft:light[level=13]
setblock 442 290 631 minecraft:light[level=13]
setblock 442 290 639 minecraft:light[level=13]
fill 442 290 646 442 297 646 minecraft:white_concrete
fill 446 290 604 446 297 604 minecraft:white_concrete
setblock 450 290 607 minecraft:light[level=13]
setblock 450 290 615 minecraft:light[level=13]
setblock 450 290 623 minecraft:light[level=13]
setblock 450 290 631 minecraft:light[level=13]
setblock 450 290 639 minecraft:light[level=13]
fill 450 290 646 450 297 646 minecraft:white_concrete
fill 454 290 604 454 297 604 minecraft:white_concrete
setblock 458 290 607 minecraft:light[level=13]
setblock 458 290 615 minecraft:light[level=13]
setblock 458 290 623 minecraft:light[level=13]
setblock 458 290 631 minecraft:light[level=13]
setblock 458 290 639 minecraft:light[level=13]
fill 458 290 646 458 297 646 minecraft:white_concrete
fill 462 290 604 462 297 604 minecraft:white_concrete
fill 465 290 609 465 297 609 minecraft:white_concrete
fill 465 290 617 465 297 617 minecraft:white_concrete
fill 465 290 625 465 297 625 minecraft:white_concrete
fill 465 290 633 465 297 633 minecraft:white_concrete
fill 465 290 641 465 297 641 minecraft:white_concrete
fill 428 292 623 429 293 624 minecraft:white_concrete
fill 424 294 605 424 295 610 minecraft:quartz_block
fill 424 294 613 425 294 618 minecraft:quartz_block
fill 424 294 621 425 294 626 minecraft:quartz_block
fill 424 294 629 425 294 634 minecraft:quartz_block
fill 424 294 637 425 294 642 minecraft:quartz_block
fill 424 294 645 429 295 645 minecraft:quartz_block
fill 425 294 606 425 294 612 minecraft:quartz_block
fill 425 294 619 425 294 620 minecraft:quartz_block
fill 425 294 627 425 294 628 minecraft:quartz_block
fill 425 294 635 425 294 636 minecraft:quartz_block
fill 425 294 643 425 294 644 minecraft:quartz_block
fill 426 294 606 463 294 606 minecraft:quartz_block
fill 426 294 644 464 294 644 minecraft:quartz_block
fill 427 294 605 432 295 605 minecraft:quartz_block
fill 432 294 645 437 295 645 minecraft:quartz_block
fill 435 294 605 440 295 605 minecraft:quartz_block
fill 440 294 645 445 295 645 minecraft:quartz_block
fill 443 294 605 448 295 605 minecraft:quartz_block
fill 448 294 645 453 295 645 minecraft:quartz_block
fill 451 294 605 456 295 605 minecraft:quartz_block
fill 456 294 645 461 295 645 minecraft:quartz_block
fill 459 294 605 464 295 605 minecraft:quartz_block
fill 463 294 607 463 294 643 minecraft:quartz_block
fill 464 294 608 464 295 613 minecraft:quartz_block
fill 464 294 616 464 295 621 minecraft:quartz_block
fill 464 294 624 464 295 629 minecraft:quartz_block
fill 464 294 632 464 295 637 minecraft:quartz_block
fill 464 294 640 464 295 643 minecraft:quartz_block
fill 464 294 645 464 295 645 minecraft:quartz_block
fill 424 295 613 424 295 618 minecraft:quartz_block
fill 424 295 621 424 295 626 minecraft:quartz_block
fill 424 295 629 424 295 634 minecraft:quartz_block
fill 424 295 637 424 295 642 minecraft:quartz_block
setblock 464 295 644 minecraft:quartz_block
fill 441 296 616 442 297 617 minecraft:black_concrete
fill 442 296 618 442 297 618 minecraft:black_concrete
fill 423 298 609 423 300 609 minecraft:pearlescent_froglight
fill 423 298 617 423 300 617 minecraft:pearlescent_froglight
fill 423 298 625 423 300 625 minecraft:pearlescent_froglight
fill 423 298 633 423 300 633 minecraft:pearlescent_froglight
fill 423 298 641 423 300 641 minecraft:pearlescent_froglight
setblock 426 298 607 minecraft:light[level=13]
setblock 426 298 615 minecraft:light[level=13]
setblock 426 298 623 minecraft:light[level=13]
setblock 426 298 631 minecraft:light[level=13]
setblock 426 298 639 minecraft:light[level=13]
fill 426 298 646 426 300 646 minecraft:pearlescent_froglight
fill 430 298 604 430 300 604 minecraft:pearlescent_froglight
setblock 434 298 607 minecraft:light[level=13]
setblock 434 298 615 minecraft:light[level=13]
setblock 434 298 623 minecraft:light[level=13]
setblock 434 298 631 minecraft:light[level=13]
setblock 434 298 639 minecraft:light[level=13]
fill 434 298 646 434 300 646 minecraft:pearlescent_froglight
fill 438 298 604 438 300 604 minecraft:pearlescent_froglight
fill 439 298 633 441 299 633 minecraft:white_concrete
fill 440 298 632 440 299 632 minecraft:white_concrete
fill 440 298 634 440 299 634 minecraft:white_concrete
setblock 442 298 607 minecraft:light[level=13]
setblock 442 298 615 minecraft:light[level=13]
setblock 442 298 623 minecraft:light[level=13]
setblock 442 298 631 minecraft:light[level=13]
setblock 442 298 639 minecraft:light[level=13]
fill 442 298 646 442 300 646 minecraft:pearlescent_froglight
fill 446 298 604 446 300 604 minecraft:pearlescent_froglight
setblock 450 298 607 minecraft:light[level=13]
setblock 450 298 615 minecraft:light[level=13]
setblock 450 298 623 minecraft:light[level=13]
setblock 450 298 631 minecraft:light[level=13]
setblock 450 298 639 minecraft:light[level=13]
fill 450 298 646 450 300 646 minecraft:pearlescent_froglight
fill 454 298 604 454 300 604 minecraft:pearlescent_froglight
setblock 458 298 607 minecraft:light[level=13]
setblock 458 298 615 minecraft:light[level=13]
setblock 458 298 623 minecraft:light[level=13]
setblock 458 298 631 minecraft:light[level=13]
setblock 458 298 639 minecraft:light[level=13]
fill 458 298 646 458 300 646 minecraft:pearlescent_froglight
fill 462 298 604 462 300 604 minecraft:pearlescent_froglight
fill 465 298 609 465 300 609 minecraft:pearlescent_froglight
fill 465 298 617 465 300 617 minecraft:pearlescent_froglight
fill 465 298 625 465 300 625 minecraft:pearlescent_froglight
fill 465 298 633 465 300 633 minecraft:pearlescent_froglight
fill 465 298 641 465 300 641 minecraft:pearlescent_froglight
fill 423 301 609 423 307 609 minecraft:white_concrete
fill 423 301 617 423 307 617 minecraft:white_concrete
fill 423 301 625 423 307 625 minecraft:white_concrete
fill 423 301 633 423 307 633 minecraft:white_concrete
fill 423 301 641 423 307 641 minecraft:white_concrete
fill 426 301 646 426 307 646 minecraft:white_concrete
fill 430 301 604 430 307 604 minecraft:white_concrete
fill 434 301 646 434 307 646 minecraft:white_concrete
fill 438 301 604 438 307 604 minecraft:white_concrete
fill 442 301 646 442 307 646 minecraft:white_concrete
fill 446 301 604 446 307 604 minecraft:white_concrete
fill 450 301 646 450 307 646 minecraft:white_concrete
fill 454 301 604 454 307 604 minecraft:white_concrete
fill 458 301 646 458 307 646 minecraft:white_concrete
fill 462 301 604 462 307 604 minecraft:white_concrete
fill 465 301 609 465 307 609 minecraft:white_concrete
fill 465 301 617 465 307 617 minecraft:white_concrete
fill 465 301 625 465 307 625 minecraft:white_concrete
fill 465 301 633 465 307 633 minecraft:white_concrete
fill 465 301 641 465 307 641 minecraft:white_concrete
