setblock 541 280 259 minecraft:light[level=12]
setblock 541 280 266 minecraft:light[level=12]
setblock 542 280 246 minecraft:deepslate_tiles
fill 542 280 248 542 280 249 minecraft:deepslate_tiles
setblock 542 280 252 minecraft:deepslate_tiles
fill 543 280 245 543 280 253 minecraft:polished_deepslate
setblock 543 280 270 minecraft:blue_terracotta
setblock 544 280 231 minecraft:light[level=11]
setblock 544 280 239 minecraft:light[level=11]
fill 544 280 244 545 280 254 minecraft:deepslate_tiles
setblock 544 280 263 minecraft:light[level=11]
fill 544 280 270 546 282 270 minecraft:gray_terracotta
setblock 545 280 243 minecraft:deepslate_tiles
setblock 545 280 255 minecraft:deepslate_tiles
fill 546 280 242 546 280 256 minecraft:polished_deepslate
setblock 547 280 270 minecraft:blue_terracotta
setblock 548 280 231 minecraft:light[level=12]
setblock 548 280 238 minecraft:light[level=12]
setblock 548 280 252 minecraft:light[level=12]
setblock 548 280 259 minecraft:light[level=12]
setblock 548 280 266 minecraft:light[level=12]
fill 548 280 270 553 280 270 minecraft:gray_terracotta
fill 552 280 228 554 280 228 minecraft:gray_terracotta
setblock 552 280 239 minecraft:light[level=11]
setblock 552 280 247 minecraft:light[level=11]
setblock 552 280 255 minecraft:light[level=11]
setblock 554 280 270 minecraft:blue_terracotta
setblock 555 280 228 minecraft:blue_terracotta
setblock 555 280 238 minecraft:light[level=12]
setblock 555 280 245 minecraft:light[level=12]
setblock 555 280 252 minecraft:light[level=12]
setblock 555 280 259 minecraft:light[level=12]
fill 555 280 270 556 282 270 minecraft:gray_terracotta
fill 556 280 228 556 282 228 minecraft:gray_terracotta
setblock 557 280 228 minecraft:blue_terracotta
setblock 557 280 270 minecraft:blue_terracotta
fill 558 280 228 558 282 228 minecraft:gray_terracotta
fill 558 280 270 559 281 270 minecraft:gray_terracotta
setblock 559 280 228 minecraft:blue_terracotta
fill 559 280 229 559 280 233 minecraft:gray_terracotta
setblock 559 280 234 minecraft:blue_terracotta
fill 559 280 235 559 282 243 minecraft:gray_terracotta
fill 559 280 250 559 282 250 minecraft:gray_terracotta
fill 559 280 257 559 280 260 minecraft:gray_terracotta
setblock 559 280 261 minecraft:blue_terracotta
fill 559 280 262 559 280 268 minecraft:gray_terracotta
setblock 559 280 269 minecraft:blue_terracotta
fill 517 281 232 517 282 232 minecraft:gray_terracotta
fill 517 281 235 517 283 235 minecraft:gray_terracotta
fill 517 281 244 517 282 246 minecraft:gray_terracotta
setblock 517 281 247 minecraft:blue_terracotta
fill 517 281 248 517 282 248 minecraft:gray_terracotta
setblock 517 281 249 minecraft:blue_terracotta
fill 517 281 250 517 282 250 minecraft:gray_terracotta
setblock 517 281 260 minecraft:blue_terracotta
fill 517 281 261 517 282 263 minecraft:gray_terracotta
fill 517 281 266 517 282 268 minecraft:gray_terracotta
setblock 519 281 228 minecraft:gray_terracotta
fill 519 281 231 520 283 231 minecraft:cobbled_deepslate
fill 519 281 234 520 283 234 minecraft:cobbled_deepslate
fill 519 281 263 520 283 263 minecraft:cobbled_deepslate
fill 519 281 266 520 283 266 minecraft:cobbled_deepslate
setblock 520 281 228 minecraft:white_concrete
fill 520 281 236 520 283 236 minecraft:cobbled_deepslate
fill 520 281 268 520 283 268 minecraft:cobbled_deepslate
fill 521 281 228 522 281 228 minecraft:blue_terracotta
fill 521 281 230 521 283 230 minecraft:cobbled_deepslate
fill 521 281 232 521 283 232 minecraft:cobbled_deepslate
fill 521 281 235 522 283 235 minecraft:cobbled_deepslate
fill 521 281 262 521 283 262 minecraft:cobbled_deepslate
fill 521 281 264 521 283 264 minecraft:cobbled_deepslate
fill 521 281 267 522 283 267 minecraft:cobbled_deepslate
fill 522 281 233 523 283 234 minecraft:cobbled_deepslate
fill 522 281 236 522 283 237 minecraft:cobbled_deepslate
fill 522 281 265 523 283 266 minecraft:cobbled_deepslate
fill 522 281 268 522 283 269 minecraft:cobbled_deepslate
fill 523 281 230 523 283 231 minecraft:cobbled_deepslate
fill 523 281 262 523 283 263 minecraft:cobbled_deepslate
fill 524 281 228 526 282 228 minecraft:gray_terracotta
fill 524 281 232 524 283 233 minecraft:cobbled_deepslate
fill 524 281 235 524 283 236 minecraft:cobbled_deepslate
fill 524 281 264 524 283 265 minecraft:cobbled_deepslate
fill 524 281 267 524 283 268 minecraft:cobbled_deepslate
fill 525 281 231 525 283 231 minecraft:cobbled_deepslate
fill 525 281 233 525 283 234 minecraft:cobbled_deepslate
fill 525 281 263 525 283 263 minecraft:cobbled_deepslate
fill 525 281 265 525 283 266 minecraft:cobbled_deepslate
fill 526 281 233 526 283 233 minecraft:cobbled_deepslate
fill 526 281 265 526 283 265 minecraft:cobbled_deepslate
setblock 527 281 228 minecraft:sea_lantern
fill 528 281 228 528 282 228 minecraft:gray_terracotta
fill 529 281 228 530 281 228 minecraft:blue_terracotta
fill 531 281 228 538 282 228 minecraft:gray_terracotta
fill 531 281 243 531 281 255 minecraft:dark_oak_planks
fill 532 281 242 536 281 242 minecraft:dark_oak_planks
fill 532 281 244 532 281 254 minecraft:dark_oak_planks
fill 532 281 256 544 281 256 minecraft:polished_deepslate
fill 533 281 243 535 281 243 minecraft:dark_oak_planks
fill 533 281 245 533 281 253 minecraft:dark_oak_planks
fill 533 281 255 543 281 255 minecraft:dark_oak_planks
setblock 534 281 244 minecraft:dark_oak_planks
setblock 534 281 245 minecraft:spruce_planks
setblock 534 281 246 minecraft:dark_oak_planks
setblock 534 281 247 minecraft:spruce_planks
setblock 534 281 248 minecraft:dark_oak_planks
setblock 534 281 249 minecraft:spruce_planks
fill 534 281 250 534 281 252 minecraft:dark_oak_planks
fill 534 281 254 542 281 254 minecraft:dark_oak_planks
setblock 535 281 244 minecraft:spruce_planks
setblock 535 281 245 minecraft:dark_oak_planks
fill 535 281 246 535 281 248 minecraft:ochre_froglight
setblock 535 281 249 minecraft:dark_oak_planks
setblock 535 281 250 minecraft:spruce_planks
setblock 535 281 251 minecraft:dark_oak_planks
fill 535 281 253 541 281 253 minecraft:dark_oak_planks
setblock 536 281 243 minecraft:spruce_planks
fill 536 281 244 536 281 246 minecraft:ochre_froglight
fill 536 281 248 536 281 250 minecraft:ochre_froglight
setblock 536 281 251 minecraft:spruce_planks
setblock 536 281 252 minecraft:dark_oak_planks
setblock 537 281 242 minecraft:spruce_planks
setblock 537 281 243 minecraft:dark_oak_planks
fill 537 281 244 538 281 244 minecraft:ochre_froglight
fill 537 281 250 538 281 250 minecraft:ochre_froglight
setblock 537 281 251 minecraft:dark_oak_planks
setblock 537 281 252 minecraft:spruce_planks
setblock 537 281 270 minecraft:blue_terracotta
setblock 538 281 242 minecraft:dark_oak_planks
fill 538 281 243 540 281 243 minecraft:ochre_froglight
fill 538 281 251 540 281 251 minecraft:ochre_froglight
setblock 538 281 252 minecraft:dark_oak_planks
fill 538 281 270 541 282 270 minecraft:gray_terracotta
setblock 539 281 228 minecraft:blue_terracotta
setblock 539 281 242 minecraft:spruce_planks
setblock 539 281 252 minecraft:spruce_planks
fill 540 281 228 544 281 228 minecraft:gray_terracotta
setblock 540 281 242 minecraft:dark_oak_planks
fill 540 281 244 542 281 244 minecraft:ochre_froglight
fill 540 281 250 542 281 250 minecraft:ochre_froglight
setblock 540 281 252 minecraft:dark_oak_planks
setblock 541 281 242 minecraft:spruce_planks
setblock 541 281 243 minecraft:dark_oak_planks
setblock 541 281 251 minecraft:dark_oak_planks
setblock 541 281 252 minecraft:spruce_planks
fill 542 281 242 544 281 242 minecraft:dark_oak_planks
setblock 542 281 243 minecraft:spruce_planks
fill 542 281 245 542 281 246 minecraft:ochre_froglight
fill 542 281 248 542 281 249 minecraft:ochre_froglight
setblock 542 281 251 minecraft:spruce_planks
fill 542 281 252 544 281 252 minecraft:dark_oak_planks
setblock 542 281 270 minecraft:blue_terracotta
setblock 543 281 243 minecraft:dark_oak_planks
setblock 543 281 244 minecraft:spruce_planks
setblock 543 281 245 minecraft:dark_oak_planks
fill 543 281 246 543 281 248 minecraft:ochre_froglight
setblock 543 281 249 minecraft:dark_oak_planks
setblock 543 281 250 minecraft:spruce_planks
fill 543 281 251 544 281 251 minecraft:dark_oak_planks
fill 543 281 253 544 281 253 minecraft:dark_oak_planks
fill 543 281 270 543 283 270 minecraft:gray_terracotta
setblock 544 281 244 minecraft:dark_oak_planks
setblock 544 281 245 minecraft:spruce_planks
setblock 544 281 246 minecraft:dark_oak_planks
setblock 544 281 247 minecraft:spruce_planks
setblock 544 281 248 minecraft:dark_oak_planks
setblock 544 281 249 minecraft:spruce_planks
setblock 544 281 250 minecraft:dark_oak_planks
setblock 544 281 254 minecraft:dark_oak_planks
setblock 545 281 228 minecraft:blue_terracotta
fill 545 281 243 545 281 255 minecraft:polished_deepslate
fill 546 281 228 550 282 228 minecraft:gray_terracotta
fill 547 281 270 547 282 270 minecraft:gray_terracotta
setblock 548 281 270 minecraft:blue_terracotta
fill 549 281 270 554 282 270 minecraft:gray_terracotta
setblock 551 281 228 minecraft:blue_terracotta
fill 551 281 231 552 283 231 minecraft:cobbled_deepslate
fill 551 281 234 552 283 234 minecraft:cobbled_deepslate
fill 551 281 263 552 283 263 minecraft:cobbled_deepslate
fill 551 281 266 552 283 266 minecraft:cobbled_deepslate
fill 552 281 228 552 282 228 minecraft:gray_terracotta
fill 552 281 236 552 283 236 minecraft:cobbled_deepslate
fill 552 281 268 552 283 268 minecraft:cobbled_deepslate
setblock 553 281 228 minecraft:blue_terracotta
fill 553 281 230 553 283 230 minecraft:cobbled_deepslate
fill 553 281 232 553 283 232 minecraft:cobbled_deepslate
fill 553 281 235 554 283 235 minecraft:cobbled_deepslate
fill 553 281 262 553 283 262 minecraft:cobbled_deepslate
fill 553 281 264 553 283 264 minecraft:cobbled_deepslate
fill 553 281 267 554 283 267 minecraft:cobbled_deepslate
fill 554 281 228 555 282 228 minecraft:gray_terracotta
fill 554 281 233 555 283 234 minecraft:cobbled_deepslate
fill 554 281 236 554 283 237 minecraft:cobbled_deepslate
fill 554 281 265 555 283 266 minecraft:cobbled_deepslate
fill 554 281 268 554 283 269 minecraft:cobbled_deepslate
fill 555 281 230 555 283 231 minecraft:cobbled_deepslate
fill 555 281 262 555 283 263 minecraft:cobbled_deepslate
fill 556 281 232 556 283 233 minecraft:cobbled_deepslate
fill 556 281 235 556 283 236 minecraft:cobbled_deepslate
fill 556 281 264 556 283 265 minecraft:cobbled_deepslate
fill 556 281 267 556 283 268 minecraft:cobbled_deepslate
fill 557 281 228 557 282 228 minecraft:gray_terracotta
fill 557 281 231 557 283 231 minecraft:cobbled_deepslate
fill 557 281 233 557 283 234 minecraft:cobbled_deepslate
fill 557 281 263 557 283 263 minecraft:cobbled_deepslate
fill 557 281 265 557 283 266 minecraft:cobbled_deepslate
fill 557 281 270 557 282 270 minecraft:gray_terracotta
fill 558 281 233 558 283 233 minecraft:cobbled_deepslate
fill 558 281 265 558 283 265 minecraft:cobbled_deepslate
fill 559 281 228 559 282 228 minecraft:gray_terracotta
setblock 559 281 229 minecraft:blue_terracotta
fill 559 281 230 559 282 234 minecraft:gray_terracotta
fill 559 281 244 559 282 246 minecraft:gray_terracotta
setblock 559 281 247 minecraft:blue_terracotta
fill 559 281 248 559 282 249 minecraft:gray_terracotta
fill 559 281 257 559 282 257 minecraft:gray_terracotta
setblock 559 281 258 minecraft:white_concrete
fill 559 281 259 559 282 261 minecraft:gray_terracotta
setblock 559 281 262 minecraft:sea_lantern
fill 559 281 263 559 282 265 minecraft:gray_terracotta
setblock 559 281 266 minecraft:blue_terracotta
fill 559 281 267 559 282 269 minecraft:gray_terracotta
setblock 517 282 242 minecraft:gray_terracotta
fill 517 282 247 517 283 247 minecraft:gray_terracotta
setblock 517 282 249 minecraft:gray_terracotta
setblock 517 282 260 minecraft:gray_terracotta
setblock 519 282 228 minecraft:white_concrete
fill 520 282 228 521 282 228 minecraft:gray_terracotta
setblock 522 282 228 minecraft:sea_lantern
setblock 527 282 228 minecraft:gray_terracotta
fill 529 282 228 530 282 228 minecraft:gray_terracotta
setblock 531 282 242 minecraft:iron_bars
setblock 531 282 244 minecraft:iron_bars
setblock 531 282 246 minecraft:iron_bars
setblock 531 282 248 minecraft:iron_bars
setblock 531 282 250 minecraft:iron_bars
setblock 531 282 252 minecraft:iron_bars
setblock 531 282 254 minecraft:iron_bars
setblock 532 282 255 minecraft:iron_bars
setblock 533 282 242 minecraft:iron_bars
setblock 534 282 255 minecraft:iron_bars
setblock 535 282 242 minecraft:iron_bars
setblock 536 282 255 minecraft:iron_bars
setblock 537 282 242 minecraft:iron_bars
setblock 537 282 270 minecraft:gray_terracotta
setblock 538 282 255 minecraft:iron_bars
setblock 539 282 228 minecraft:sea_lantern
setblock 539 282 242 minecraft:iron_bars
setblock 540 282 228 minecraft:gray_terracotta
setblock 540 282 255 minecraft:iron_bars
setblock 541 282 228 minecraft:sea_lantern
setblock 541 282 242 minecraft:iron_bars
fill 542 282 228 543 282 228 minecraft:gray_terracotta
setblock 542 282 255 minecraft:iron_bars
setblock 542 282 270 minecraft:gray_terracotta
setblock 543 282 242 minecraft:iron_bars
setblock 544 282 228 minecraft:white_concrete
setblock 544 282 243 minecraft:iron_bars
setblock 544 282 245 minecraft:iron_bars
setblock 544 282 247 minecraft:iron_bars
setblock 544 282 249 minecraft:iron_bars
setblock 544 282 251 minecraft:iron_bars
setblock 544 282 253 minecraft:iron_bars
setblock 544 282 255 minecraft:iron_bars
setblock 545 282 228 minecraft:gray_terracotta
setblock 548 282 270 minecraft:gray_terracotta
fill 551 282 228 551 283 228 minecraft:gray_terracotta
setblock 553 282 228 minecraft:gray_terracotta
setblock 558 282 270 minecraft:sea_lantern
setblock 559 282 229 minecraft:gray_terracotta
fill 559 282 247 559 283 247 minecraft:gray_terracotta
setblock 559 282 258 minecraft:gray_terracotta
setblock 559 282 262 minecraft:gray_terracotta
setblock 559 282 266 minecraft:gray_terracotta
setblock 559 282 270 minecraft:gray_terracotta
setblock 517 283 228 minecraft:blue_terracotta
setblock 517 283 229 minecraft:gray_terracotta
fill 517 283 230 517 292 230 minecraft:blue_terracotta
fill 517 283 232 517 293 234 minecraft:blue_terracotta
fill 517 283 236 517 283 246 minecraft:blue_terracotta
fill 517 283 248 517 283 252 minecraft:blue_terracotta
setblock 517 283 253 minecraft:gray_terracotta
fill 517 283 254 517 283 255 minecraft:blue_terracotta
setblock 517 283 256 minecraft:sea_lantern
fill 517 283 257 517 284 266 minecraft:blue_terracotta
fill 517 283 267 517 283 268 minecraft:sea_lantern
fill 517 283 269 517 283 270 minecraft:blue_terracotta
setblock 518 283 228 minecraft:gray_terracotta
fill 518 283 270 521 283 270 minecraft:blue_terracotta
fill 519 283 228 520 284 228 minecraft:blue_terracotta
setblock 521 283 228 minecraft:gray_terracotta
fill 522 283 228 536 283 228 minecraft:blue_terracotta
setblock 522 283 270 minecraft:gray_terracotta
fill 523 283 270 542 283 270 minecraft:blue_terracotta
setblock 537 283 228 minecraft:gray_terracotta
fill 538 283 228 540 283 228 minecraft:blue_terracotta
setblock 541 283 228 minecraft:gray_terracotta
fill 542 283 228 543 291 228 minecraft:blue_terracotta
setblock 544 283 228 minecraft:gray_terracotta
fill 544 283 270 550 283 270 minecraft:blue_terracotta
fill 545 283 228 550 284 228 minecraft:blue_terracotta
setblock 551 283 270 minecraft:white_concrete
fill 552 283 228 559 284 228 minecraft:blue_terracotta
fill 552 283 270 553 287 270 minecraft:blue_terracotta
setblock 554 283 270 minecraft:gray_terracotta
fill 555 283 270 559 283 270 minecraft:blue_terracotta
fill 559 283 229 559 283 233 minecraft:blue_terracotta
fill 559 283 234 559 284 234 minecraft:gray_terracotta
fill 559 283 235 559 283 246 minecraft:blue_terracotta
fill 559 283 248 559 283 258 minecraft:blue_terracotta
setblock 559 283 259 minecraft:sea_lantern
fill 559 283 260 559 285 262 minecraft:blue_terracotta
fill 559 283 263 559 283 264 minecraft:gray_terracotta
fill 559 283 265 559 295 265 minecraft:blue_terracotta
fill 559 283 266 559 284 266 minecraft:sea_lantern
fill 559 283 267 559 284 269 minecraft:blue_terracotta
setblock 517 284 228 minecraft:gray_terracotta
fill 517 284 229 517 291 229 minecraft:blue_terracotta
fill 517 284 231 517 295 231 minecraft:blue_terracotta
fill 517 284 235 517 284 245 minecraft:blue_terracotta
setblock 517 284 246 minecraft:gray_terracotta
fill 517 284 247 517 292 250 minecraft:blue_terracotta
setblock 517 284 251 minecraft:gray_terracotta
fill 517 284 252 517 284 254 minecraft:blue_terracotta
fill 517 284 255 517 285 255 minecraft:gray_terracotta
fill 517 284 256 517 291 256 minecraft:blue_terracotta
fill 517 284 267 517 284 269 minecraft:blue_terracotta
setblock 517 284 270 minecraft:gray_terracotta
fill 518 284 228 518 295 228 minecraft:blue_terracotta
fill 518 284 270 520 288 270 minecraft:blue_terracotta
fill 521 284 228 521 295 228 minecraft:blue_terracotta
setblock 521 284 270 minecraft:gray_terracotta
fill 522 284 228 523 284 228 minecraft:gray_terracotta
setblock 522 284 233 minecraft:purple_terracotta
setblock 522 284 265 minecraft:purple_terracotta
fill 522 284 270 525 292 270 minecraft:blue_terracotta
fill 524 284 228 528 284 228 minecraft:blue_terracotta
setblock 526 284 270 minecraft:gray_terracotta
fill 527 284 270 534 284 270 minecraft:blue_terracotta
setblock 529 284 228 minecraft:white_concrete
fill 530 284 228 530 290 228 minecraft:blue_terracotta
setblock 531 284 228 minecraft:sea_lantern
fill 532 284 228 538 291 228 minecraft:blue_terracotta
setblock 535 284 270 minecraft:white_concrete
fill 536 284 270 539 292 270 minecraft:blue_terracotta
setblock 539 284 228 minecraft:gray_terracotta
fill 540 284 228 541 286 228 minecraft:blue_terracotta
setblock 540 284 270 minecraft:white_concrete
fill 541 284 270 541 294 270 minecraft:blue_terracotta
setblock 542 284 270 minecraft:white_concrete
fill 543 284 270 544 295 270 minecraft:blue_terracotta
fill 544 284 228 544 293 228 minecraft:blue_terracotta
fill 545 284 270 545 285 270 minecraft:gray_terracotta
fill 546 284 270 551 284 270 minecraft:blue_terracotta
fill 551 284 228 551 295 228 minecraft:blue_terracotta
setblock 554 284 233 minecraft:purple_terracotta
setblock 554 284 265 minecraft:purple_terracotta
fill 554 284 270 557 285 270 minecraft:blue_terracotta
setblock 558 284 270 minecraft:sea_lantern
fill 559 284 229 559 291 232 minecraft:blue_terracotta
setblock 559 284 233 minecraft:gray_terracotta
fill 559 284 235 559 285 235 minecraft:gray_terracotta
fill 559 284 236 559 294 236 minecraft:blue_terracotta
setblock 559 284 237 minecraft:gray_terracotta
fill 559 284 238 559 287 239 minecraft:blue_terracotta
setblock 559 284 240 minecraft:gray_terracotta
fill 559 284 241 559 284 244 minecraft:blue_terracotta
setblock 559 284 245 minecraft:gray_terracotta
fill 559 284 246 559 291 246 minecraft:blue_terracotta
setblock 559 284 247 minecraft:sea_lantern
setblock 559 284 248 minecraft:gray_terracotta
fill 559 284 249 559 289 252 minecraft:blue_terracotta
setblock 559 284 253 minecraft:gray_terracotta
fill 559 284 254 559 284 258 minecraft:blue_terracotta
setblock 559 284 259 minecraft:gray_terracotta
fill 559 284 263 559 295 264 minecraft:blue_terracotta
setblock 559 284 270 minecraft:blue_terracotta
fill 517 285 228 517 295 228 minecraft:blue_terracotta
setblock 517 285 235 minecraft:blue_terracotta
setblock 517 285 236 minecraft:sea_lantern
fill 517 285 237 517 288 237 minecraft:blue_terracotta
setblock 517 285 238 minecraft:white_concrete
fill 517 285 239 517 293 242 minecraft:blue_terracotta
setblock 517 285 243 minecraft:gray_terracotta
fill 517 285 244 517 293 244 minecraft:blue_terracotta
setblock 517 285 245 minecraft:gray_terracotta
fill 517 285 246 517 295 246 minecraft:blue_terracotta
fill 517 285 251 517 293 251 minecraft:blue_terracotta
setblock 517 285 252 minecraft:gray_terracotta
fill 517 285 253 517 295 254 minecraft:blue_terracotta
fill 517 285 257 517 286 265 minecraft:blue_terracotta
fill 517 285 266 517 285 267 minecraft:gray_terracotta
fill 517 285 268 517 295 270 minecraft:blue_terracotta
fill 519 285 228 519 293 228 minecraft:blue_terracotta
setblock 520 285 228 minecraft:white_concrete
fill 520 285 250 520 290 250 minecraft:iron_bars
fill 521 285 270 521 295 270 minecraft:blue_terracotta
fill 522 285 228 527 288 228 minecraft:blue_terracotta
setblock 522 285 233 minecraft:polished_deepslate
setblock 522 285 265 minecraft:polished_deepslate
fill 526 285 251 528 285 253 minecraft:nether_bricks
fill 526 285 270 531 289 270 minecraft:blue_terracotta
setblock 528 285 228 minecraft:gray_terracotta
fill 529 285 228 529 295 228 minecraft:blue_terracotta
fill 531 285 228 531 293 228 minecraft:blue_terracotta
setblock 532 285 270 minecraft:gray_terracotta
fill 533 285 270 535 285 270 minecraft:blue_terracotta
fill 539 285 228 539 293 228 minecraft:blue_terracotta
fill 540 285 270 540 286 270 minecraft:blue_terracotta
fill 542 285 270 542 292 270 minecraft:blue_terracotta
fill 545 285 228 546 288 228 minecraft:blue_terracotta
fill 546 285 270 550 288 270 minecraft:blue_terracotta
setblock 547 285 228 minecraft:gray_terracotta
fill 548 285 228 550 291 228 minecraft:blue_terracotta
fill 548 285 244 550 285 246 minecraft:nether_bricks
setblock 551 285 270 minecraft:gray_terracotta
fill 552 285 228 554 292 228 minecraft:blue_terracotta
setblock 553 285 236 minecraft:iron_bars
setblock 554 285 233 minecraft:polished_deepslate
setblock 554 285 265 minecraft:polished_deepslate
setblock 555 285 228 minecraft:gray_terracotta
fill 556 285 228 556 293 228 minecraft:blue_terracotta
setblock 557 285 228 minecraft:gray_terracotta
fill 558 285 228 559 293 228 minecraft:blue_terracotta
fill 558 285 270 558 292 270 minecraft:blue_terracotta
fill 559 285 233 559 295 234 minecraft:blue_terracotta
fill 559 285 237 559 293 237 minecraft:blue_terracotta
fill 559 285 240 559 286 240 minecraft:white_concrete
setblock 559 285 241 minecraft:gray_terracotta
fill 559 285 242 559 292 245 minecraft:blue_terracotta
fill 559 285 247 559 293 248 minecraft:blue_terracotta
fill 559 285 253 559 288 257 minecraft:blue_terracotta
setblock 559 285 258 minecraft:gray_terracotta
fill 559 285 259 559 292 259 minecraft:blue_terracotta
fill 559 285 266 559 292 266 minecraft:blue_terracotta
setblock 559 285 267 minecraft:gray_terracotta
fill 559 285 268 559 286 269 minecraft:blue_terracotta
setblock 559 285 270 minecraft:gray_terracotta
setblock 517 286 235 minecraft:white_concrete
fill 517 286 236 517 295 236 minecraft:blue_terracotta
fill 517 286 238 517 292 238 minecraft:blue_terracotta
fill 517 286 243 517 288 243 minecraft:blue_terracotta
fill 517 286 245 517 295 245 minecraft:blue_terracotta
fill 517 286 252 517 293 252 minecraft:blue_terracotta
fill 517 286 255 517 290 255 minecraft:blue_terracotta
fill 517 286 266 517 293 267 minecraft:blue_terracotta
fill 520 286 228 520 289 228 minecraft:blue_terracotta
setblock 520 286 231 minecraft:light[level=12]
setblock 520 286 238 minecraft:light[level=12]
setblock 520 286 245 minecraft:light[level=12]
setblock 520 286 252 minecraft:light[level=12]
setblock 520 286 259 minecraft:light[level=12]
setblock 520 286 266 minecraft:light[level=12]
fill 521 286 233 523 287 233 minecraft:purple_terracotta
fill 521 286 265 523 287 265 minecraft:purple_terracotta
fill 522 286 232 522 287 232 minecraft:purple_terracotta
fill 522 286 234 522 287 234 minecraft:purple_terracotta
fill 522 286 264 522 287 264 minecraft:purple_terracotta
fill 522 286 266 522 287 266 minecraft:purple_terracotta
setblock 527 286 231 minecraft:light[level=12]
setblock 527 286 238 minecraft:light[level=12]
setblock 527 286 245 minecraft:light[level=12]
setblock 527 286 252 minecraft:light[level=12]
setblock 527 286 259 minecraft:light[level=12]
setblock 527 286 266 minecraft:light[level=12]
fill 528 286 228 528 294 228 minecraft:blue_terracotta
fill 532 286 270 532 294 270 minecraft:blue_terracotta
setblock 533 286 270 minecraft:sea_lantern
setblock 534 286 231 minecraft:light[level=12]
setblock 534 286 238 minecraft:light[level=12]
setblock 534 286 245 minecraft:light[level=12]
setblock 534 286 252 minecraft:light[level=12]
setblock 534 286 259 minecraft:light[level=12]
setblock 534 286 266 minecraft:light[level=12]
fill 534 286 270 535 290 270 minecraft:blue_terracotta
setblock 541 286 231 minecraft:light[level=12]
setblock 541 286 238 minecraft:light[level=12]
setblock 541 286 245 minecraft:light[level=12]
setblock 541 286 252 minecraft:light[level=12]
setblock 541 286 259 minecraft:light[level=12]
setblock 541 286 266 minecraft:light[level=12]
fill 545 286 270 545 295 270 minecraft:blue_terracotta
fill 547 286 228 547 289 228 minecraft:blue_terracotta
setblock 548 286 231 minecraft:light[level=12]
setblock 548 286 238 minecraft:light[level=12]
setblock 548 286 245 minecraft:light[level=12]
setblock 548 286 252 minecraft:light[level=12]
setblock 548 286 259 minecraft:light[level=12]
setblock 548 286 266 minecraft:light[level=12]
fill 551 286 270 551 287 270 minecraft:blue_terracotta
fill 553 286 231 553 286 232 minecraft:dark_oak_planks
fill 553 286 233 555 287 233 minecraft:purple_terracotta
fill 553 286 234 553 286 241 minecraft:dark_oak_planks
fill 553 286 265 555 287 265 minecraft:purple_terracotta
fill 554 286 231 557 286 231 minecraft:dark_oak_planks
fill 554 286 232 554 287 232 minecraft:purple_terracotta
fill 554 286 234 554 287 234 minecraft:purple_terracotta
fill 554 286 235 557 286 241 minecraft:dark_oak_planks
fill 554 286 264 554 287 264 minecraft:purple_terracotta
fill 554 286 266 554 287 266 minecraft:purple_terracotta
fill 554 286 270 555 295 270 minecraft:blue_terracotta
fill 555 286 228 555 292 228 minecraft:blue_terracotta
fill 555 286 232 557 286 232 minecraft:dark_oak_planks
fill 555 286 234 557 286 234 minecraft:dark_oak_planks
setblock 555 286 245 minecraft:light[level=12]
setblock 555 286 252 minecraft:light[level=12]
setblock 555 286 259 minecraft:light[level=12]
setblock 555 286 266 minecraft:light[level=12]
fill 556 286 233 557 286 233 minecraft:dark_oak_planks
fill 556 286 247 556 298 247 minecraft:purple_wool
setblock 556 286 270 minecraft:sea_lantern
fill 557 286 228 557 294 228 minecraft:blue_terracotta
setblock 557 286 270 minecraft:blue_terracotta
fill 559 286 235 559 291 235 minecraft:blue_terracotta
fill 559 286 241 559 292 241 minecraft:blue_terracotta
fill 559 286 258 559 295 258 minecraft:blue_terracotta
fill 559 286 260 559 291 260 minecraft:blue_terracotta
setblock 559 286 261 minecraft:sea_lantern
fill 559 286 262 559 295 262 minecraft:blue_terracotta
fill 559 286 267 559 295 267 minecraft:blue_terracotta
fill 559 286 270 559 295 270 minecraft:blue_terracotta
fill 517 287 235 517 290 235 minecraft:blue_terracotta
fill 517 287 257 517 291 264 minecraft:blue_terracotta
setblock 517 287 265 minecraft:white_concrete
setblock 521 287 232 minecraft:purple_terracotta
setblock 521 287 234 minecraft:purple_terracotta
setblock 521 287 264 minecraft:purple_terracotta
setblock 521 287 266 minecraft:purple_terracotta
setblock 522 287 242 minecraft:black_concrete
setblock 523 287 232 minecraft:purple_terracotta
setblock 523 287 234 minecraft:purple_terracotta
setblock 523 287 264 minecraft:purple_terracotta
setblock 523 287 266 minecraft:purple_terracotta
fill 533 287 270 533 293 270 minecraft:blue_terracotta
fill 540 287 228 540 293 228 minecraft:blue_terracotta
setblock 540 287 270 minecraft:white_concrete
setblock 541 287 228 minecraft:white_concrete
setblock 542 287 265 minecraft:black_concrete
fill 553 287 231 557 287 231 minecraft:stripped_dark_oak_log
setblock 553 287 232 minecraft:purple_terracotta
setblock 553 287 234 minecraft:purple_terracotta
fill 553 287 235 557 287 241 minecraft:stripped_dark_oak_log
setblock 553 287 264 minecraft:purple_terracotta
setblock 553 287 266 minecraft:purple_terracotta
setblock 555 287 232 minecraft:purple_terracotta
setblock 555 287 234 minecraft:purple_terracotta
setblock 555 287 264 minecraft:purple_terracotta
setblock 555 287 266 minecraft:purple_terracotta
fill 556 287 232 557 287 234 minecraft:stripped_dark_oak_log
fill 556 287 245 556 298 246 minecraft:purple_wool
fill 556 287 248 556 298 249 minecraft:purple_wool
fill 556 287 270 556 295 270 minecraft:blue_terracotta
setblock 557 287 270 minecraft:sea_lantern
fill 559 287 240 559 292 240 minecraft:blue_terracotta
fill 559 287 261 559 293 261 minecraft:blue_terracotta
fill 559 287 268 559 295 268 minecraft:blue_terracotta
setblock 559 287 269 minecraft:white_concrete
fill 517 288 265 517 289 265 minecraft:blue_terracotta
setblock 520 288 231 minecraft:light[level=11]
fill 520 288 233 524 288 233 minecraft:polished_deepslate
setblock 520 288 239 minecraft:light[level=11]
setblock 520 288 247 minecraft:light[level=11]
setblock 520 288 255 minecraft:light[level=11]
setblock 520 288 263 minecraft:light[level=11]
fill 520 288 265 524 288 265 minecraft:polished_deepslate
fill 521 288 232 523 288 232 minecraft:polished_deepslate
fill 521 288 234 523 288 234 minecraft:polished_deepslate
fill 521 288 264 523 288 264 minecraft:polished_deepslate
fill 521 288 266 523 288 266 minecraft:polished_deepslate
setblock 522 288 231 minecraft:polished_deepslate
setblock 522 288 235 minecraft:polished_deepslate
fill 522 288 240 522 288 241 minecraft:black_wool
fill 522 288 243 522 288 244 minecraft:black_wool
setblock 522 288 255 minecraft:black_concrete
setblock 522 288 263 minecraft:polished_deepslate
setblock 522 288 267 minecraft:polished_deepslate
setblock 528 288 231 minecraft:light[level=11]
setblock 528 288 239 minecraft:light[level=11]
setblock 528 288 247 minecraft:light[level=11]
setblock 528 288 255 minecraft:light[level=11]
setblock 528 288 263 minecraft:light[level=11]
setblock 536 288 231 minecraft:light[level=11]
setblock 536 288 239 minecraft:light[level=11]
setblock 536 288 247 minecraft:light[level=11]
setblock 536 288 255 minecraft:light[level=11]
setblock 536 288 263 minecraft:light[level=11]
fill 540 288 265 541 288 265 minecraft:black_wool
fill 540 288 270 540 292 270 minecraft:blue_terracotta
fill 541 288 228 541 291 228 minecraft:blue_terracotta
fill 543 288 265 544 288 265 minecraft:black_wool
setblock 544 288 231 minecraft:light[level=11]
setblock 544 288 239 minecraft:light[level=11]
setblock 544 288 247 minecraft:light[level=11]
setblock 544 288 255 minecraft:light[level=11]
setblock 544 288 263 minecraft:light[level=11]
setblock 551 288 270 minecraft:sea_lantern
setblock 552 288 231 minecraft:light[level=11]
fill 552 288 233 556 288 233 minecraft:polished_deepslate
setblock 552 288 239 minecraft:light[level=11]
setblock 552 288 247 minecraft:light[level=11]
setblock 552 288 255 minecraft:light[level=11]
setblock 552 288 263 minecraft:light[level=11]
fill 552 288 265 556 288 265 minecraft:polished_deepslate
fill 552 288 270 552 295 270 minecraft:blue_terracotta
setblock 553 288 231 minecraft:purple_concrete
fill 553 288 232 555 288 232 minecraft:polished_deepslate
fill 553 288 234 555 288 234 minecraft:polished_deepslate
fill 553 288 235 553 288 241 minecraft:purple_concrete
fill 553 288 264 555 288 264 minecraft:polished_deepslate
fill 553 288 266 555 288 266 minecraft:polished_deepslate
setblock 553 288 270 minecraft:sea_lantern
setblock 554 288 231 minecraft:polished_deepslate
setblock 554 288 235 minecraft:polished_deepslate
setblock 554 288 263 minecraft:polished_deepslate
setblock 554 288 267 minecraft:polished_deepslate
fill 557 288 270 557 295 270 minecraft:blue_terracotta
fill 558 288 235 558 291 237 minecraft:jack_o_lantern
fill 559 288 238 559 293 238 minecraft:blue_terracotta
setblock 559 288 239 minecraft:white_concrete
fill 559 288 269 559 290 269 minecraft:blue_terracotta
setblock 517 289 237 minecraft:white_concrete
setblock 517 289 243 minecraft:white_concrete
fill 518 289 258 524 289 258 minecraft:dark_oak_planks
setblock 518 289 270 minecraft:white_concrete
fill 519 289 270 520 295 270 minecraft:blue_terracotta
fill 520 289 232 524 290 234 minecraft:purple_terracotta
fill 520 289 256 521 290 257 minecraft:dark_oak_planks
fill 520 289 259 524 290 260 minecraft:dark_oak_planks
fill 520 289 264 524 290 266 minecraft:purple_terracotta
fill 521 289 231 523 290 231 minecraft:purple_terracotta
fill 521 289 235 523 290 235 minecraft:purple_terracotta
fill 521 289 263 523 290 263 minecraft:purple_terracotta
fill 521 289 267 523 290 267 minecraft:purple_terracotta
setblock 522 289 228 minecraft:sea_lantern
fill 522 289 253 522 289 254 minecraft:black_wool
fill 522 289 256 522 289 257 minecraft:black_wool
fill 523 289 228 527 290 228 minecraft:blue_terracotta
fill 523 289 256 524 290 257 minecraft:dark_oak_planks
setblock 525 289 268 minecraft:black_concrete
setblock 531 289 230 minecraft:black_concrete
setblock 545 289 228 minecraft:sea_lantern
fill 546 289 228 546 295 228 minecraft:blue_terracotta
fill 546 289 270 546 295 270 minecraft:blue_terracotta
setblock 547 289 270 minecraft:sea_lantern
fill 548 289 270 551 291 270 minecraft:blue_terracotta
fill 552 289 232 556 290 234 minecraft:purple_terracotta
fill 552 289 264 556 290 266 minecraft:purple_terracotta
fill 553 289 231 555 290 231 minecraft:purple_terracotta
fill 553 289 235 555 290 235 minecraft:purple_terracotta
setblock 553 289 236 minecraft:stripped_dark_oak_log
setblock 553 289 241 minecraft:stripped_dark_oak_log
fill 553 289 263 555 290 263 minecraft:purple_terracotta
fill 553 289 267 555 290 267 minecraft:purple_terracotta
fill 553 289 270 553 295 270 minecraft:blue_terracotta
setblock 555 289 253 minecraft:black_concrete
fill 559 289 239 559 292 239 minecraft:blue_terracotta
fill 559 289 253 559 291 255 minecraft:blue_terracotta
setblock 559 289 256 minecraft:white_concrete
fill 559 289 257 559 295 257 minecraft:blue_terracotta
fill 517 290 237 517 292 237 minecraft:blue_terracotta
fill 517 290 243 517 294 243 minecraft:blue_terracotta
setblock 517 290 265 minecraft:sea_lantern
fill 518 290 270 518 293 270 minecraft:blue_terracotta
setblock 520 290 228 minecraft:white_concrete
setblock 520 290 231 minecraft:purple_terracotta
setblock 520 290 235 minecraft:purple_terracotta
fill 520 290 258 524 290 258 minecraft:dark_oak_planks
setblock 520 290 263 minecraft:purple_terracotta
setblock 520 290 267 minecraft:purple_terracotta
fill 522 290 228 522 295 228 minecraft:blue_terracotta
fill 522 290 256 522 290 257 minecraft:dark_oak_planks
fill 523 290 268 524 290 268 minecraft:black_wool
setblock 524 290 231 minecraft:purple_terracotta
setblock 524 290 235 minecraft:purple_terracotta
setblock 524 290 263 minecraft:purple_terracotta
setblock 524 290 267 minecraft:purple_terracotta
fill 526 290 268 527 290 268 minecraft:black_wool
fill 526 290 270 528 291 270 minecraft:blue_terracotta
fill 529 290 230 530 290 230 minecraft:black_wool
setblock 529 290 270 minecraft:sea_lantern
fill 530 290 270 531 295 270 minecraft:blue_terracotta
fill 532 290 230 533 290 230 minecraft:black_wool
fill 545 290 228 545 293 228 minecraft:blue_terracotta
setblock 547 290 228 minecraft:white_concrete
fill 547 290 270 547 295 270 minecraft:blue_terracotta
setblock 552 290 231 minecraft:purple_terracotta
setblock 552 290 235 minecraft:purple_terracotta
setblock 552 290 263 minecraft:purple_terracotta
setblock 552 290 267 minecraft:purple_terracotta
fill 555 290 251 555 290 252 minecraft:black_wool
fill 555 290 254 555 290 255 minecraft:black_wool
setblock 556 290 231 minecraft:purple_terracotta
setblock 556 290 235 minecraft:purple_terracotta
setblock 556 290 263 minecraft:purple_terracotta
setblock 556 290 267 minecraft:purple_terracotta
fill 559 290 249 559 295 251 minecraft:blue_terracotta
setblock 559 290 252 minecraft:white_concrete
fill 559 290 256 559 292 256 minecraft:blue_terracotta
setblock 517 291 235 minecraft:white_concrete
setblock 517 291 255 minecraft:sea_lantern
fill 517 291 265 517 295 265 minecraft:blue_terracotta
fill 519 291 232 525 291 234 minecraft:polished_deepslate
fill 519 291 264 525 291 266 minecraft:polished_deepslate
fill 520 291 228 520 293 228 minecraft:blue_terracotta
fill 520 291 231 524 291 231 minecraft:polished_deepslate
fill 520 291 235 524 291 235 minecraft:polished_deepslate
fill 520 291 263 524 291 263 minecraft:polished_deepslate
fill 520 291 267 524 291 267 minecraft:polished_deepslate
fill 521 291 230 523 291 230 minecraft:polished_deepslate
fill 521 291 236 523 291 236 minecraft:polished_deepslate
fill 521 291 258 523 295 258 minecraft:stripped_dark_oak_log
fill 521 291 262 523 291 262 minecraft:polished_deepslate
fill 521 291 268 523 291 268 minecraft:polished_deepslate
setblock 523 291 228 minecraft:sea_lantern
fill 524 291 228 527 293 228 minecraft:blue_terracotta
fill 529 291 270 529 295 270 minecraft:blue_terracotta
setblock 530 291 228 minecraft:white_concrete
fill 534 291 270 534 296 270 minecraft:blue_terracotta
setblock 535 291 270 minecraft:sea_lantern
fill 547 291 228 547 295 228 minecraft:blue_terracotta
fill 551 291 232 557 291 234 minecraft:polished_deepslate
fill 551 291 264 557 291 266 minecraft:polished_deepslate
fill 552 291 231 556 291 231 minecraft:polished_deepslate
fill 552 291 235 556 291 235 minecraft:polished_deepslate
fill 552 291 263 556 291 263 minecraft:polished_deepslate
fill 552 291 267 556 291 267 minecraft:polished_deepslate
fill 553 291 230 555 291 230 minecraft:polished_deepslate
fill 553 291 236 555 291 236 minecraft:polished_deepslate
fill 553 291 262 555 291 262 minecraft:polished_deepslate
fill 553 291 268 555 291 268 minecraft:polished_deepslate
fill 559 291 252 559 295 252 minecraft:blue_terracotta
setblock 559 291 269 minecraft:white_concrete
setblock 517 292 229 minecraft:black_concrete
setblock 517 292 235 minecraft:black_concrete
fill 517 292 255 517 294 255 minecraft:blue_terracotta
fill 517 292 256 517 292 257 minecraft:black_concrete
fill 517 292 258 517 293 258 minecraft:blue_terracotta
setblock 517 292 259 minecraft:black_concrete
fill 517 292 260 517 292 261 minecraft:blue_terracotta
setblock 517 292 262 minecraft:black_concrete
fill 517 292 263 517 295 263 minecraft:blue_terracotta
setblock 517 292 264 minecraft:sea_lantern
fill 519 292 231 525 293 235 minecraft:purple_terracotta
fill 519 292 263 525 293 267 minecraft:purple_terracotta
fill 520 292 230 524 293 230 minecraft:purple_terracotta
fill 520 292 236 524 293 236 minecraft:purple_terracotta
setblock 520 292 238 minecraft:light[level=12]
setblock 520 292 245 minecraft:light[level=12]
setblock 520 292 252 minecraft:light[level=12]
setblock 520 292 259 minecraft:light[level=12]
fill 520 292 262 524 293 262 minecraft:purple_terracotta
fill 520 292 268 524 293 268 minecraft:purple_terracotta
setblock 523 292 228 minecraft:black_concrete
fill 526 292 270 527 294 270 minecraft:blue_terracotta
setblock 527 292 231 minecraft:light[level=12]
setblock 527 292 238 minecraft:light[level=12]
setblock 527 292 245 minecraft:light[level=12]
setblock 527 292 252 minecraft:light[level=12]
setblock 527 292 259 minecraft:light[level=12]
setblock 527 292 266 minecraft:light[level=12]
setblock 528 292 270 minecraft:white_concrete
fill 530 292 228 530 295 228 minecraft:blue_terracotta
fill 532 292 228 535 293 228 minecraft:blue_terracotta
setblock 534 292 231 minecraft:light[level=12]
setblock 534 292 238 minecraft:light[level=12]
setblock 534 292 245 minecraft:light[level=12]
setblock 534 292 252 minecraft:light[level=12]
setblock 534 292 259 minecraft:light[level=12]
setblock 534 292 266 minecraft:light[level=12]
fill 535 292 270 535 295 270 minecraft:blue_terracotta
fill 536 292 228 537 292 228 minecraft:sea_lantern
setblock 538 292 228 minecraft:blue_terracotta
setblock 541 292 228 minecraft:black_concrete
setblock 541 292 231 minecraft:light[level=12]
setblock 541 292 238 minecraft:light[level=12]
setblock 541 292 245 minecraft:light[level=12]
setblock 541 292 252 minecraft:light[level=12]
setblock 541 292 259 minecraft:light[level=12]
setblock 541 292 266 minecraft:light[level=12]
fill 542 292 228 542 294 228 minecraft:blue_terracotta
setblock 543 292 228 minecraft:black_concrete
setblock 548 292 228 minecraft:white_concrete
setblock 548 292 231 minecraft:light[level=12]
setblock 548 292 238 minecraft:light[level=12]
setblock 548 292 245 minecraft:light[level=12]
setblock 548 292 252 minecraft:light[level=12]
setblock 548 292 259 minecraft:light[level=12]
setblock 548 292 266 minecraft:light[level=12]
fill 548 292 270 550 295 270 minecraft:blue_terracotta
fill 549 292 228 550 295 228 minecraft:blue_terracotta
fill 551 292 231 557 293 235 minecraft:purple_terracotta
fill 551 292 263 557 293 267 minecraft:purple_terracotta
setblock 551 292 270 minecraft:black_concrete
fill 552 292 230 556 293 230 minecraft:purple_terracotta
fill 552 292 236 556 293 236 minecraft:purple_terracotta
fill 552 292 262 556 293 262 minecraft:purple_terracotta
fill 552 292 268 556 293 268 minecraft:purple_terracotta
setblock 555 292 238 minecraft:light[level=12]
setblock 555 292 245 minecraft:light[level=12]
setblock 555 292 252 minecraft:light[level=12]
setblock 555 292 259 minecraft:light[level=12]
fill 559 292 229 559 295 229 minecraft:blue_terracotta
setblock 559 292 230 minecraft:black_concrete
fill 559 292 231 559 292 232 minecraft:blue_terracotta
setblock 559 292 235 minecraft:sea_lantern
setblock 559 292 246 minecraft:sea_lantern
fill 559 292 253 559 293 253 minecraft:blue_terracotta
setblock 559 292 254 minecraft:black_concrete
fill 559 292 255 559 295 255 minecraft:blue_terracotta
setblock 559 292 260 minecraft:black_concrete
setblock 559 292 269 minecraft:blue_terracotta
fill 517 293 229 517 293 230 minecraft:white_concrete
setblock 517 293 235 minecraft:blue_terracotta
setblock 517 293 237 minecraft:white_concrete
setblock 517 293 238 minecraft:black_concrete
setblock 517 293 247 minecraft:black_concrete
fill 517 293 248 517 295 248 minecraft:blue_terracotta
setblock 517 293 249 minecraft:black_concrete
fill 517 293 250 517 295 250 minecraft:blue_terracotta
fill 517 293 256 517 295 256 minecraft:blue_terracotta
fill 517 293 257 517 294 257 minecraft:black_concrete
fill 517 293 259 517 295 260 minecraft:blue_terracotta
setblock 517 293 261 minecraft:black_concrete
fill 517 293 262 517 295 262 minecraft:blue_terracotta
fill 517 293 264 517 295 264 minecraft:blue_terracotta
fill 518 293 232 518 293 234 minecraft:purple_terracotta
fill 518 293 264 518 293 266 minecraft:purple_terracotta
setblock 520 293 254 minecraft:black_concrete
fill 521 293 229 523 293 229 minecraft:purple_terracotta
fill 521 293 237 523 293 237 minecraft:purple_terracotta
fill 521 293 261 523 293 261 minecraft:purple_terracotta
fill 521 293 269 523 293 269 minecraft:purple_terracotta
fill 522 293 270 523 295 270 minecraft:blue_terracotta
fill 523 293 228 523 295 228 minecraft:blue_terracotta
setblock 524 293 270 minecraft:black_concrete
fill 525 293 270 525 295 270 minecraft:blue_terracotta
fill 526 293 232 526 293 234 minecraft:purple_terracotta
fill 526 293 264 526 293 266 minecraft:purple_terracotta
fill 528 293 270 528 295 270 minecraft:blue_terracotta
fill 536 293 228 537 295 228 minecraft:blue_terracotta
fill 536 293 270 537 295 270 minecraft:blue_terracotta
setblock 538 293 228 minecraft:black_concrete
setblock 538 293 270 minecraft:white_concrete
fill 539 293 270 539 295 270 minecraft:blue_terracotta
fill 540 293 270 540 294 270 minecraft:black_concrete
fill 541 293 228 541 295 228 minecraft:blue_terracotta
fill 542 293 270 542 294 270 minecraft:black_concrete
fill 543 293 228 543 295 228 minecraft:blue_terracotta
fill 548 293 228 548 295 228 minecraft:blue_terracotta
fill 550 293 232 550 293 234 minecraft:purple_terracotta
fill 550 293 264 550 293 266 minecraft:purple_terracotta
fill 551 293 270 551 295 270 minecraft:blue_terracotta
setblock 552 293 228 minecraft:black_concrete
fill 553 293 228 554 293 228 minecraft:blue_terracotta
fill 553 293 229 555 293 229 minecraft:purple_terracotta
fill 553 293 237 555 293 237 minecraft:purple_terracotta
fill 553 293 261 555 293 261 minecraft:purple_terracotta
fill 553 293 269 555 293 269 minecraft:purple_terracotta
setblock 555 293 228 minecraft:black_concrete
fill 558 293 232 558 293 234 minecraft:purple_terracotta
fill 558 293 239 559 293 239 minecraft:light_gray_concrete
fill 558 293 240 559 293 243 minecraft:white_concrete
fill 558 293 264 558 293 266 minecraft:purple_terracotta
setblock 558 293 270 minecraft:black_concrete
fill 559 293 230 559 295 230 minecraft:blue_terracotta
setblock 559 293 231 minecraft:white_concrete
setblock 559 293 232 minecraft:sea_lantern
fill 559 293 235 559 295 235 minecraft:blue_terracotta
setblock 559 293 244 minecraft:black_concrete
fill 559 293 245 559 293 246 minecraft:blue_terracotta
fill 559 293 254 559 295 254 minecraft:blue_terracotta
setblock 559 293 256 minecraft:black_concrete
setblock 559 293 259 minecraft:sea_lantern
fill 559 293 260 559 295 260 minecraft:blue_terracotta
setblock 559 293 266 minecraft:black_concrete
setblock 559 293 269 minecraft:black_concrete
fill 517 294 229 517 295 230 minecraft:blue_terracotta
setblock 517 294 232 minecraft:black_concrete
fill 517 294 233 517 295 234 minecraft:blue_terracotta
setblock 517 294 235 minecraft:white_concrete
fill 517 294 237 517 295 238 minecraft:blue_terracotta
setblock 517 294 239 minecraft:black_concrete
fill 517 294 240 517 295 242 minecraft:blue_terracotta
setblock 517 294 244 minecraft:black_concrete
fill 517 294 247 517 295 247 minecraft:blue_terracotta
fill 517 294 249 517 295 249 minecraft:blue_terracotta
fill 517 294 251 517 294 252 minecraft:black_concrete
setblock 517 294 258 minecraft:sea_lantern
fill 517 294 261 517 295 261 minecraft:blue_terracotta
setblock 517 294 266 minecraft:black_concrete
fill 517 294 267 517 295 267 minecraft:blue_terracotta
fill 518 294 231 526 294 235 minecraft:polished_deepslate
fill 518 294 263 526 294 267 minecraft:polished_deepslate
setblock 518 294 270 minecraft:black_concrete
setblock 519 294 228 minecraft:sea_lantern
fill 519 294 230 525 294 230 minecraft:polished_deepslate
fill 519 294 236 525 294 236 minecraft:polished_deepslate
fill 519 294 262 525 294 262 minecraft:polished_deepslate
fill 519 294 268 525 294 268 minecraft:polished_deepslate
setblock 520 294 228 minecraft:black_concrete
fill 520 294 229 524 294 229 minecraft:polished_deepslate
fill 520 294 237 524 294 237 minecraft:polished_deepslate
fill 520 294 252 520 294 253 minecraft:black_wool
fill 520 294 255 520 294 256 minecraft:black_wool
fill 520 294 261 524 294 261 minecraft:polished_deepslate
fill 520 294 269 524 294 269 minecraft:polished_deepslate
fill 522 294 257 522 295 257 minecraft:stripped_dark_oak_log
fill 522 294 259 522 295 259 minecraft:stripped_dark_oak_log
fill 524 294 228 524 295 228 minecraft:blue_terracotta
fill 524 294 270 524 295 270 minecraft:blue_terracotta
setblock 525 294 228 minecraft:black_concrete
fill 526 294 228 527 295 228 minecraft:blue_terracotta
fill 531 294 228 532 294 228 minecraft:black_concrete
fill 533 294 228 535 295 228 minecraft:blue_terracotta
setblock 533 294 270 minecraft:sea_lantern
fill 538 294 228 538 295 228 minecraft:blue_terracotta
fill 538 294 270 538 295 270 minecraft:blue_terracotta
fill 539 294 228 540 294 228 minecraft:black_concrete
fill 544 294 228 545 294 228 minecraft:black_concrete
fill 550 294 231 558 294 235 minecraft:polished_deepslate
fill 550 294 263 558 294 267 minecraft:polished_deepslate
fill 551 294 230 557 294 230 minecraft:polished_deepslate
fill 551 294 236 557 294 236 minecraft:polished_deepslate
fill 551 294 262 557 294 262 minecraft:polished_deepslate
fill 551 294 268 557 294 268 minecraft:polished_deepslate
fill 552 294 228 552 295 228 minecraft:blue_terracotta
fill 552 294 229 556 294 229 minecraft:polished_deepslate
fill 552 294 237 556 294 237 minecraft:polished_deepslate
fill 552 294 261 556 294 261 minecraft:polished_deepslate
fill 552 294 269 556 294 269 minecraft:polished_deepslate
setblock 553 294 228 minecraft:sea_lantern
fill 554 294 228 555 295 228 minecraft:blue_terracotta
setblock 556 294 228 minecraft:black_concrete
fill 558 294 228 558 295 228 minecraft:blue_terracotta
fill 558 294 237 559 294 240 minecraft:white_concrete
fill 558 294 241 559 294 241 minecraft:light_gray_concrete
fill 558 294 242 559 294 245 minecraft:white_concrete
fill 558 294 270 558 295 270 minecraft:blue_terracotta
setblock 559 294 228 minecraft:black_concrete
fill 559 294 231 559 295 231 minecraft:blue_terracotta
setblock 559 294 232 minecraft:black_concrete
fill 559 294 246 559 294 247 minecraft:blue_terracotta
setblock 559 294 248 minecraft:black_concrete
setblock 559 294 253 minecraft:white_concrete
fill 559 294 256 559 295 256 minecraft:blue_terracotta
fill 559 294 259 559 295 259 minecraft:blue_terracotta
setblock 559 294 261 minecraft:black_concrete
fill 559 294 266 559 295 266 minecraft:blue_terracotta
setblock 559 294 269 minecraft:white_concrete
setblock 517 295 232 minecraft:blue_terracotta
setblock 517 295 235 minecraft:blue_terracotta
setblock 517 295 239 minecraft:blue_terracotta
setblock 517 295 243 minecraft:white_concrete
setblock 517 295 244 minecraft:blue_terracotta
fill 517 295 251 517 295 252 minecraft:blue_terracotta
setblock 517 295 255 minecraft:sea_lantern
fill 517 295 257 517 295 258 minecraft:blue_terracotta
setblock 517 295 266 minecraft:blue_terracotta
setblock 518 295 270 minecraft:blue_terracotta
fill 519 295 228 520 295 228 minecraft:blue_terracotta
fill 522 295 233 522 297 233 minecraft:iron_bars
fill 522 295 265 522 297 265 minecraft:iron_bars
setblock 525 295 228 minecraft:blue_terracotta
setblock 526 295 270 minecraft:white_concrete
setblock 527 295 270 minecraft:blue_terracotta
setblock 528 295 228 minecraft:white_concrete
fill 531 295 228 532 295 228 minecraft:blue_terracotta
setblock 532 295 270 minecraft:sea_lantern
setblock 533 295 270 minecraft:blue_terracotta
fill 539 295 228 540 295 228 minecraft:blue_terracotta
setblock 540 295 270 minecraft:blue_terracotta
setblock 541 295 270 minecraft:white_concrete
setblock 542 295 228 minecraft:sea_lantern
fill 542 295 270 542 296 270 minecraft:blue_terracotta
fill 544 295 228 545 295 228 minecraft:blue_terracotta
setblock 553 295 228 minecraft:blue_terracotta
fill 554 295 233 554 297 233 minecraft:iron_bars
fill 554 295 265 554 297 265 minecraft:iron_bars
setblock 556 295 228 minecraft:blue_terracotta
setblock 557 295 228 minecraft:sea_lantern
fill 558 295 236 559 296 237 minecraft:white_concrete
fill 558 295 238 559 295 238 minecraft:light_gray_concrete
fill 558 295 239 559 295 242 minecraft:white_concrete
fill 558 295 243 559 295 243 minecraft:light_gray_concrete
fill 558 295 244 559 295 246 minecraft:white_concrete
setblock 559 295 228 minecraft:blue_terracotta
setblock 559 295 232 minecraft:blue_terracotta
fill 559 295 247 559 295 248 minecraft:blue_terracotta
setblock 559 295 253 minecraft:blue_terracotta
setblock 559 295 261 minecraft:blue_terracotta
fill 559 295 269 559 296 269 minecraft:blue_terracotta
fill 517 296 228 517 296 252 minecraft:black_concrete
setblock 517 296 253 minecraft:blue_terracotta
fill 517 296 254 517 296 270 minecraft:black_concrete
fill 518 296 228 527 296 228 minecraft:black_concrete
fill 518 296 270 531 296 270 minecraft:black_concrete
setblock 520 296 231 minecraft:light[level=11]
setblock 520 296 239 minecraft:light[level=11]
setblock 520 296 247 minecraft:light[level=11]
setblock 520 296 255 minecraft:light[level=11]
setblock 520 296 263 minecraft:light[level=11]
setblock 528 296 228 minecraft:blue_terracotta
setblock 528 296 231 minecraft:light[level=11]
setblock 528 296 239 minecraft:light[level=11]
setblock 528 296 247 minecraft:light[level=11]
setblock 528 296 255 minecraft:light[level=11]
setblock 528 296 263 minecraft:light[level=11]
setblock 529 296 228 minecraft:black_concrete
setblock 530 296 228 minecraft:white_concrete
fill 531 296 228 531 308 228 minecraft:black_concrete
fill 532 296 228 533 296 228 minecraft:blue_terracotta
setblock 532 296 270 minecraft:blue_terracotta
fill 533 296 270 533 301 270 minecraft:black_concrete
fill 534 296 228 534 308 228 minecraft:black_concrete
setblock 535 296 228 minecraft:blue_terracotta
fill 535 296 270 536 297 270 minecraft:black_concrete
fill 536 296 228 539 296 228 minecraft:black_concrete
setblock 536 296 231 minecraft:light[level=11]
setblock 536 296 239 minecraft:light[level=11]
setblock 536 296 247 minecraft:light[level=11]
setblock 536 296 255 minecraft:light[level=11]
setblock 536 296 263 minecraft:light[level=11]
setblock 537 296 270 minecraft:blue_terracotta
fill 538 296 270 540 304 270 minecraft:black_concrete
setblock 540 296 228 minecraft:blue_terracotta
fill 541 296 228 541 308 228 minecraft:black_concrete
setblock 541 296 270 minecraft:sea_lantern
setblock 542 296 228 minecraft:blue_terracotta
setblock 543 296 228 minecraft:sea_lantern
fill 543 296 270 543 308 270 minecraft:black_concrete
fill 544 296 228 559 296 228 minecraft:black_concrete
setblock 544 296 231 minecraft:light[level=11]
setblock 544 296 239 minecraft:light[level=11]
setblock 544 296 247 minecraft:light[level=11]
setblock 544 296 255 minecraft:light[level=11]
setblock 544 296 263 minecraft:light[level=11]
setblock 544 296 270 minecraft:blue_terracotta
fill 545 296 270 559 296 270 minecraft:black_concrete
setblock 552 296 231 minecraft:light[level=11]
setblock 552 296 239 minecraft:light[level=11]
setblock 552 296 247 minecraft:light[level=11]
setblock 552 296 255 minecraft:light[level=11]
setblock 552 296 263 minecraft:light[level=11]
fill 558 296 238 559 297 239 minecraft:white_concrete
fill 558 296 240 559 296 240 minecraft:light_gray_concrete
fill 558 296 241 559 296 244 minecraft:white_concrete
fill 558 296 245 559 296 245 minecraft:light_gray_concrete
fill 558 296 246 559 298 246 minecraft:white_concrete
fill 559 296 229 559 297 234 minecraft:black_concrete
setblock 559 296 235 minecraft:sea_lantern
fill 559 296 247 559 297 263 minecraft:black_concrete
setblock 559 296 264 minecraft:sea_lantern
fill 559 296 265 559 308 268 minecraft:black_concrete
fill 517 297 228 517 297 236 minecraft:black_concrete
setblock 517 297 237 minecraft:blue_terracotta
fill 517 297 238 517 297 246 minecraft:black_concrete
setblock 517 297 247 minecraft:sea_lantern
fill 517 297 248 517 299 250 minecraft:black_concrete
setblock 517 297 251 minecraft:blue_terracotta
fill 517 297 252 517 297 257 minecraft:black_concrete
setblock 517 297 258 minecraft:white_concrete
fill 517 297 259 517 297 260 minecraft:black_concrete
fill 517 297 261 517 298 261 minecraft:blue_terracotta
fill 517 297 262 517 300 263 minecraft:black_concrete
setblock 517 297 264 minecraft:blue_terracotta
fill 517 297 265 517 297 268 minecraft:black_concrete
setblock 517 297 269 minecraft:blue_terracotta
fill 517 297 270 528 297 270 minecraft:black_concrete
setblock 518 297 228 minecraft:blue_terracotta
fill 519 297 228 521 297 228 minecraft:black_concrete
setblock 522 297 228 minecraft:blue_terracotta
fill 523 297 228 528 297 228 minecraft:black_concrete
fill 529 297 228 529 298 228 minecraft:blue_terracotta
setblock 529 297 270 minecraft:blue_terracotta
fill 530 297 228 530 308 228 minecraft:black_concrete
fill 530 297 270 531 308 270 minecraft:black_concrete
fill 532 297 228 533 298 228 minecraft:black_concrete
setblock 532 297 270 minecraft:sea_lantern
fill 534 297 270 534 308 270 minecraft:black_concrete
setblock 535 297 228 minecraft:black_concrete
setblock 536 297 228 minecraft:blue_terracotta
fill 537 297 228 540 308 228 minecraft:black_concrete
fill 537 297 270 537 308 270 minecraft:black_concrete
fill 541 297 270 542 300 270 minecraft:black_concrete
fill 542 297 228 547 297 228 minecraft:black_concrete
fill 544 297 270 547 297 270 minecraft:black_concrete
setblock 548 297 228 minecraft:blue_terracotta
setblock 548 297 270 minecraft:white_concrete
fill 549 297 228 550 302 228 minecraft:black_concrete
fill 549 297 270 554 297 270 minecraft:black_concrete
setblock 551 297 228 minecraft:blue_terracotta
fill 552 297 228 557 297 228 minecraft:black_concrete
setblock 555 297 270 minecraft:blue_terracotta
fill 556 297 270 558 308 270 minecraft:black_concrete
setblock 558 297 228 minecraft:blue_terracotta
fill 558 297 236 559 298 236 minecraft:white_concrete
fill 558 297 237 559 297 237 minecraft:light_gray_concrete
fill 558 297 240 559 298 241 minecraft:white_concrete
fill 558 297 242 559 297 242 minecraft:light_gray_concrete
fill 558 297 243 559 297 245 minecraft:white_concrete
fill 559 297 228 559 308 228 minecraft:black_concrete
setblock 559 297 235 minecraft:black_concrete
fill 559 297 264 559 308 264 minecraft:black_concrete
fill 559 297 269 559 308 269 minecraft:black_concrete
setblock 559 297 270 minecraft:blue_terracotta
fill 517 298 228 517 308 230 minecraft:black_concrete
setblock 517 298 231 minecraft:blue_terracotta
fill 517 298 232 517 304 238 minecraft:black_concrete
setblock 517 298 239 minecraft:blue_terracotta
fill 517 298 240 517 302 245 minecraft:black_concrete
setblock 517 298 246 minecraft:blue_terracotta
fill 517 298 247 517 301 247 minecraft:black_concrete
fill 517 298 251 517 308 253 minecraft:black_concrete
setblock 517 298 254 minecraft:blue_terracotta
fill 517 298 255 517 300 259 minecraft:black_concrete
setblock 517 298 260 minecraft:sea_lantern
fill 517 298 264 517 298 266 minecraft:black_concrete
setblock 517 298 267 minecraft:blue_terracotta
fill 517 298 268 517 308 269 minecraft:black_concrete
setblock 517 298 270 minecraft:blue_terracotta
fill 518 298 228 520 299 228 minecraft:black_concrete
fill 518 298 270 518 308 270 minecraft:black_concrete
setblock 519 298 270 minecraft:blue_terracotta
setblock 520 298 231 minecraft:light[level=12]
setblock 520 298 238 minecraft:light[level=12]
setblock 520 298 245 minecraft:light[level=12]
setblock 520 298 252 minecraft:light[level=12]
setblock 520 298 259 minecraft:light[level=12]
setblock 520 298 266 minecraft:light[level=12]
fill 520 298 270 529 298 270 minecraft:black_concrete
setblock 521 298 228 minecraft:blue_terracotta
fill 522 298 228 523 308 228 minecraft:black_concrete
setblock 524 298 228 minecraft:blue_terracotta
fill 525 298 228 525 308 228 minecraft:black_concrete
setblock 526 298 228 minecraft:blue_terracotta
fill 527 298 228 528 307 228 minecraft:black_concrete
setblock 527 298 231 minecraft:light[level=12]
setblock 527 298 238 minecraft:light[level=12]
setblock 527 298 245 minecraft:light[level=12]
setblock 527 298 252 minecraft:light[level=12]
setblock 527 298 259 minecraft:light[level=12]
setblock 527 298 266 minecraft:light[level=12]
fill 532 298 270 532 308 270 minecraft:black_concrete
setblock 534 298 231 minecraft:light[level=12]
setblock 534 298 238 minecraft:light[level=12]
setblock 534 298 245 minecraft:light[level=12]
setblock 534 298 252 minecraft:light[level=12]
setblock 534 298 259 minecraft:light[level=12]
setblock 534 298 266 minecraft:light[level=12]
setblock 535 298 228 minecraft:blue_terracotta
fill 535 298 270 535 308 270 minecraft:black_concrete
setblock 536 298 228 minecraft:sea_lantern
setblock 536 298 270 minecraft:blue_terracotta
setblock 541 298 231 minecraft:light[level=12]
setblock 541 298 238 minecraft:light[level=12]
setblock 541 298 245 minecraft:light[level=12]
setblock 541 298 252 minecraft:light[level=12]
setblock 541 298 259 minecraft:light[level=12]
setblock 541 298 266 minecraft:light[level=12]
fill 542 298 228 546 298 228 minecraft:black_concrete
fill 544 298 270 545 308 270 minecraft:black_concrete
setblock 546 298 270 minecraft:blue_terracotta
setblock 547 298 228 minecraft:blue_terracotta
fill 547 298 270 549 299 270 minecraft:black_concrete
fill 548 298 228 548 302 228 minecraft:black_concrete
setblock 548 298 231 minecraft:light[level=12]
setblock 548 298 238 minecraft:light[level=12]
setblock 548 298 245 minecraft:light[level=12]
setblock 548 298 252 minecraft:light[level=12]
setblock 548 298 259 minecraft:light[level=12]
setblock 548 298 266 minecraft:light[level=12]
setblock 550 298 270 minecraft:blue_terracotta
fill 551 298 228 551 308 228 minecraft:black_concrete
fill 551 298 270 551 308 270 minecraft:black_concrete
setblock 552 298 228 minecraft:white_concrete
setblock 552 298 270 minecraft:blue_terracotta
fill 553 298 228 558 301 228 minecraft:black_concrete
fill 553 298 270 555 304 270 minecraft:black_concrete
setblock 555 298 231 minecraft:light[level=12]
setblock 555 298 238 minecraft:light[level=12]
setblock 555 298 245 minecraft:light[level=12]
setblock 555 298 252 minecraft:light[level=12]
setblock 555 298 259 minecraft:light[level=12]
setblock 555 298 266 minecraft:light[level=12]
fill 558 298 235 559 299 235 minecraft:white_concrete
fill 558 298 237 559 299 238 minecraft:white_concrete
fill 558 298 239 559 298 239 minecraft:light_gray_concrete
fill 558 298 242 559 299 243 minecraft:white_concrete
fill 558 298 244 559 298 244 minecraft:light_gray_concrete
fill 558 298 245 559 300 245 minecraft:white_concrete
fill 558 298 247 559 299 247 minecraft:white_concrete
setblock 559 298 229 minecraft:blue_terracotta
fill 559 298 230 559 302 234 minecraft:black_concrete
fill 559 298 248 559 298 249 minecraft:blue_terracotta
fill 559 298 250 559 300 254 minecraft:black_concrete
setblock 559 298 255 minecraft:blue_terracotta
fill 559 298 256 559 308 256 minecraft:black_concrete
setblock 559 298 257 minecraft:blue_terracotta
fill 559 298 258 559 298 263 minecraft:black_concrete
fill 559 298 270 559 308 270 minecraft:black_concrete
fill 517 299 231 517 308 231 minecraft:black_concrete
fill 517 299 239 517 303 239 minecraft:black_concrete
fill 517 299 246 517 308 246 minecraft:black_concrete
fill 517 299 254 517 308 254 minecraft:black_concrete
fill 517 299 260 517 308 261 minecraft:black_concrete
fill 517 299 264 517 308 264 minecraft:black_concrete
setblock 517 299 265 minecraft:white_concrete
fill 517 299 266 517 303 267 minecraft:black_concrete
fill 517 299 270 517 308 270 minecraft:black_concrete
fill 519 299 270 527 300 270 minecraft:black_concrete
fill 521 299 228 521 308 228 minecraft:black_concrete
setblock 521 299 262 minecraft:black_concrete
fill 524 299 228 524 308 228 minecraft:black_concrete
fill 526 299 228 526 308 228 minecraft:black_concrete
setblock 528 299 270 minecraft:sea_lantern
fill 529 299 228 529 308 228 minecraft:black_concrete
fill 529 299 270 529 307 270 minecraft:black_concrete
setblock 532 299 228 minecraft:white_concrete
fill 533 299 228 533 303 228 minecraft:black_concrete
fill 535 299 228 536 304 228 minecraft:black_concrete
fill 536 299 270 536 308 270 minecraft:black_concrete
fill 542 299 228 545 308 228 minecraft:black_concrete
setblock 546 299 228 minecraft:white_concrete
fill 546 299 270 546 308 270 minecraft:black_concrete
fill 547 299 228 547 306 228 minecraft:black_concrete
fill 550 299 270 550 308 270 minecraft:black_concrete
fill 552 299 228 552 308 228 minecraft:black_concrete
fill 552 299 270 552 308 270 minecraft:black_concrete
fill 556 299 244 556 300 250 minecraft:iron_bars
fill 558 299 236 559 299 236 minecraft:light_gray_concrete
fill 558 299 239 559 300 240 minecraft:white_concrete
fill 558 299 241 559 299 241 minecraft:light_gray_concrete
fill 558 299 244 559 302 244 minecraft:white_concrete
fill 558 299 246 559 299 246 minecraft:light_gray_concrete
fill 559 299 229 559 304 229 minecraft:black_concrete
fill 559 299 248 559 305 249 minecraft:black_concrete
setblock 559 299 255 minecraft:white_concrete
fill 559 299 257 559 299 261 minecraft:black_concrete
setblock 559 299 262 minecraft:white_concrete
fill 559 299 263 559 308 263 minecraft:black_concrete
fill 517 300 248 517 308 248 minecraft:black_concrete
setblock 517 300 249 minecraft:white_concrete
fill 517 300 250 517 308 250 minecraft:black_concrete
fill 517 300 265 517 302 265 minecraft:black_concrete
fill 518 300 228 519 308 228 minecraft:black_concrete
setblock 520 300 228 minecraft:sea_lantern
fill 521 300 260 521 300 261 minecraft:black_wool
fill 521 300 263 521 300 264 minecraft:black_wool
fill 528 300 270 528 308 270 minecraft:black_concrete
setblock 532 300 228 minecraft:black_concrete
fill 546 300 228 546 306 228 minecraft:black_concrete
setblock 547 300 270 minecraft:white_concrete
fill 548 300 270 549 308 270 minecraft:black_concrete
setblock 556 300 236 minecraft:black_concrete
fill 558 300 236 559 301 237 minecraft:white_concrete
fill 558 300 238 559 300 238 minecraft:light_gray_concrete
fill 558 300 241 559 301 242 minecraft:white_concrete
fill 558 300 243 559 300 243 minecraft:light_gray_concrete
fill 558 300 246 559 302 246 minecraft:white_concrete
fill 559 300 235 559 308 235 minecraft:black_concrete
fill 559 300 247 559 308 247 minecraft:black_concrete
fill 559 300 255 559 308 255 minecraft:black_concrete
fill 559 300 257 559 308 257 minecraft:black_concrete
setblock 559 300 258 minecraft:sea_lantern
fill 559 300 259 559 308 262 minecraft:black_concrete
fill 517 301 249 517 303 249 minecraft:black_concrete
fill 517 301 255 517 308 255 minecraft:black_concrete
setblock 517 301 256 minecraft:white_concrete
fill 517 301 257 517 304 259 minecraft:black_concrete
fill 517 301 262 517 308 262 minecraft:black_concrete
setblock 517 301 263 minecraft:white_concrete
setblock 519 301 270 minecraft:sea_lantern
fill 520 301 228 520 308 228 minecraft:black_concrete
fill 520 301 270 527 303 270 minecraft:black_concrete
setblock 532 301 228 minecraft:white_concrete
fill 541 301 270 541 308 270 minecraft:black_concrete
setblock 542 301 270 minecraft:sea_lantern
fill 547 301 270 547 308 270 minecraft:black_concrete
fill 556 301 234 556 301 235 minecraft:black_wool
fill 556 301 237 556 301 238 minecraft:black_wool
fill 558 301 238 559 302 239 minecraft:white_concrete
fill 558 301 240 559 301 240 minecraft:light_gray_concrete
fill 558 301 243 559 303 243 minecraft:white_concrete
fill 558 301 245 559 301 245 minecraft:light_gray_concrete
fill 559 301 250 559 308 252 minecraft:black_concrete
setblock 559 301 253 minecraft:sea_lantern
fill 559 301 254 559 308 254 minecraft:black_concrete
fill 559 301 258 559 308 258 minecraft:black_concrete
setblock 517 302 247 minecraft:sea_lantern
fill 517 302 256 517 308 256 minecraft:black_concrete
fill 517 302 263 517 303 263 minecraft:black_concrete
fill 519 302 270 519 308 270 minecraft:black_concrete
setblock 532 302 228 minecraft:sea_lantern
setblock 533 302 270 minecraft:sea_lantern
fill 542 302 270 542 308 270 minecraft:black_concrete
fill 553 302 228 554 304 228 minecraft:black_concrete
setblock 553 302 266 minecraft:black_concrete
setblock 555 302 228 minecraft:white_concrete
fill 556 302 228 558 308 228 minecraft:black_concrete
fill 558 302 236 559 302 236 minecraft:white_concrete
fill 558 302 237 559 302 237 minecraft:light_gray_concrete
fill 558 302 240 559 303 241 minecraft:white_concrete
fill 558 302 242 559 302 242 minecraft:light_gray_concrete
fill 558 302 245 559 303 245 minecraft:white_concrete
fill 559 302 253 559 308 253 minecraft:black_concrete
fill 517 303 240 517 308 241 minecraft:black_concrete
setblock 517 303 242 minecraft:white_concrete
fill 517 303 243 517 308 245 minecraft:black_concrete
fill 517 303 247 517 308 247 minecraft:black_concrete
setblock 517 303 265 minecraft:sea_lantern
fill 532 303 228 532 308 228 minecraft:black_concrete
fill 533 303 270 533 308 270 minecraft:black_concrete
setblock 548 303 228 minecraft:sea_lantern
fill 549 303 228 549 308 228 minecraft:black_concrete
setblock 550 303 228 minecraft:sea_lantern
fill 551 303 266 552 303 266 minecraft:black_wool
fill 554 303 266 555 303 266 minecraft:black_wool
setblock 555 303 228 minecraft:black_concrete
fill 558 303 237 559 303 238 minecraft:white_concrete
fill 558 303 239 559 303 239 minecraft:light_gray_concrete
fill 558 303 242 559 303 242 minecraft:white_concrete
fill 558 303 244 559 303 244 minecraft:light_gray_concrete
fill 559 303 230 559 308 230 minecraft:black_concrete
setblock 559 303 231 minecraft:sea_lantern
fill 559 303 232 559 304 234 minecraft:black_concrete
fill 559 303 236 559 304 236 minecraft:black_concrete
fill 559 303 246 559 308 246 minecraft:black_concrete
setblock 517 304 239 minecraft:white_concrete
fill 517 304 242 517 308 242 minecraft:black_concrete
setblock 517 304 249 minecraft:white_concrete
setblock 517 304 263 minecraft:sea_lantern
setblock 517 304 265 minecraft:black_concrete
setblock 517 304 266 minecraft:sea_lantern
fill 517 304 267 517 308 267 minecraft:black_concrete
fill 520 304 270 521 306 270 minecraft:black_concrete
setblock 522 304 270 minecraft:white_concrete
fill 523 304 270 527 308 270 minecraft:black_concrete
setblock 533 304 228 minecraft:white_concrete
setblock 548 304 228 minecraft:black_concrete
fill 550 304 228 550 308 228 minecraft:black_concrete
setblock 555 304 228 minecraft:sea_lantern
fill 559 304 231 559 308 231 minecraft:black_concrete
fill 559 304 237 559 308 238 minecraft:black_concrete
fill 559 304 239 559 304 240 minecraft:white_concrete
setblock 559 304 241 minecraft:light_gray_concrete
fill 559 304 242 559 304 243 minecraft:white_concrete
fill 559 304 244 559 308 245 minecraft:black_concrete
fill 517 305 232 517 305 233 minecraft:black_concrete
setblock 517 305 234 minecraft:white_concrete
fill 517 305 235 517 306 239 minecraft:black_concrete
fill 517 305 249 517 308 249 minecraft:black_concrete
setblock 517 305 257 minecraft:sea_lantern
fill 517 305 258 517 308 259 minecraft:black_concrete
fill 517 305 263 517 308 263 minecraft:black_concrete
setblock 517 305 265 minecraft:white_concrete
fill 517 305 266 517 308 266 minecraft:black_concrete
fill 522 305 270 522 308 270 minecraft:black_concrete
fill 533 305 228 533 308 228 minecraft:black_concrete
setblock 535 305 228 minecraft:white_concrete
fill 536 305 228 536 308 228 minecraft:black_concrete
fill 538 305 270 539 308 270 minecraft:black_concrete
setblock 540 305 270 minecraft:white_concrete
setblock 548 305 228 minecraft:white_concrete
setblock 553 305 228 minecraft:sea_lantern
setblock 553 305 270 minecraft:white_concrete
fill 554 305 228 555 306 228 minecraft:black_concrete
fill 554 305 270 555 308 270 minecraft:black_concrete
setblock 559 305 229 minecraft:sea_lantern
fill 559 305 232 559 308 233 minecraft:black_concrete
setblock 559 305 234 minecraft:sea_lantern
setblock 559 305 236 minecraft:white_concrete
fill 559 305 239 559 306 243 minecraft:black_concrete
setblock 517 306 232 minecraft:sea_lantern
fill 517 306 233 517 308 234 minecraft:black_concrete
fill 517 306 257 517 308 257 minecraft:black_concrete
fill 517 306 265 517 308 265 minecraft:black_concrete
fill 535 306 228 535 308 228 minecraft:black_concrete
fill 540 306 270 540 308 270 minecraft:black_concrete
fill 548 306 228 548 307 228 minecraft:black_concrete
fill 553 306 228 553 308 228 minecraft:black_concrete
fill 553 306 270 553 308 270 minecraft:black_concrete
fill 559 306 229 559 308 229 minecraft:black_concrete
fill 559 306 234 559 308 234 minecraft:black_concrete
fill 559 306 236 559 308 236 minecraft:black_concrete
setblock 559 306 248 minecraft:white_concrete
fill 559 306 249 559 308 249 minecraft:black_concrete
fill 517 307 232 517 308 232 minecraft:black_concrete
fill 517 307 235 517 308 235 minecraft:black_concrete
setblock 517 307 236 minecraft:white_concrete
fill 517 307 237 517 307 239 minecraft:black_concrete
fill 520 307 270 520 308 270 minecraft:black_concrete
setblock 521 307 270 minecraft:sea_lantern
setblock 546 307 228 minecraft:sea_lantern
setblock 547 307 228 minecraft:white_concrete
setblock 554 307 228 minecraft:white_concrete
fill 555 307 228 555 308 228 minecraft:black_concrete
fill 559 307 239 559 308 239 minecraft:black_concrete
setblock 559 307 240 minecraft:white_concrete
fill 559 307 241 559 308 243 minecraft:black_concrete
fill 559 307 248 559 308 248 minecraft:black_concrete
setblock 517 308 236 minecraft:black_concrete
setblock 517 308 237 minecraft:white_concrete
fill 517 308 238 517 308 239 minecraft:black_concrete
setblock 521 308 270 minecraft:black_concrete
setblock 527 308 228 minecraft:black_concrete
setblock 528 308 228 minecraft:white_concrete
setblock 529 308 270 minecraft:white_concrete
fill 546 308 228 547 308 228 minecraft:black_concrete
setblock 548 308 228 minecraft:white_concrete
setblock 554 308 228 minecraft:black_concrete
setblock 559 308 240 minecraft:black_concrete
