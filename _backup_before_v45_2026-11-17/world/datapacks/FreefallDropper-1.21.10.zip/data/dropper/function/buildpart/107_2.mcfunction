setblock 520 193 435 minecraft:light[level=12]
fill 520 193 436 520 196 436 minecraft:black_concrete
fill 520 193 442 520 205 443 minecraft:black_concrete
setblock 520 193 451 minecraft:light[level=12]
fill 521 193 439 521 197 441 minecraft:black_concrete
fill 522 193 418 522 199 418 minecraft:black_concrete
setblock 522 193 456 minecraft:black_concrete
fill 525 193 419 525 198 419 minecraft:black_concrete
setblock 528 193 427 minecraft:light[level=12]
setblock 528 193 435 minecraft:light[level=12]
setblock 528 193 443 minecraft:light[level=12]
setblock 528 193 451 minecraft:light[level=12]
fill 531 193 419 531 195 419 minecraft:black_concrete
fill 531 193 457 532 193 457 minecraft:black_concrete
setblock 536 193 419 minecraft:light[level=12]
setblock 536 193 427 minecraft:light[level=12]
setblock 536 193 435 minecraft:light[level=12]
setblock 536 193 443 minecraft:light[level=12]
setblock 536 193 451 minecraft:light[level=12]
fill 538 193 457 538 195 457 minecraft:black_concrete
fill 539 193 419 539 201 419 minecraft:black_concrete
fill 542 193 420 543 199 420 minecraft:black_concrete
setblock 544 193 427 minecraft:light[level=12]
setblock 544 193 435 minecraft:light[level=12]
setblock 544 193 443 minecraft:light[level=12]
setblock 544 193 451 minecraft:light[level=12]
fill 545 193 455 545 194 455 minecraft:black_concrete
fill 550 193 420 550 194 420 minecraft:black_concrete
setblock 552 193 427 minecraft:light[level=12]
setblock 552 193 435 minecraft:light[level=12]
setblock 552 193 443 minecraft:light[level=12]
setblock 552 193 451 minecraft:light[level=12]
fill 558 193 421 558 211 421 minecraft:black_concrete
fill 558 193 436 558 195 436 minecraft:black_concrete
fill 558 193 445 558 215 448 minecraft:black_concrete
fill 558 193 451 558 216 451 minecraft:black_concrete
fill 518 194 420 518 223 421 minecraft:black_concrete
fill 518 194 433 518 197 433 minecraft:black_concrete
fill 518 194 450 518 214 450 minecraft:black_concrete
fill 518 194 455 518 194 457 minecraft:black_concrete
fill 519 194 446 519 211 447 minecraft:black_concrete
fill 520 194 444 520 207 445 minecraft:black_concrete
fill 521 194 418 521 198 418 minecraft:black_concrete
fill 521 194 438 521 196 438 minecraft:black_concrete
fill 521 194 442 521 199 443 minecraft:black_concrete
fill 523 194 419 524 197 419 minecraft:black_concrete
setblock 527 194 456 minecraft:black_concrete
setblock 531 194 457 minecraft:black_concrete
fill 538 194 419 538 199 419 minecraft:black_concrete
fill 541 194 420 541 199 420 minecraft:black_concrete
setblock 557 194 418 minecraft:black_concrete
fill 557 194 440 557 197 443 minecraft:black_concrete
fill 558 194 449 558 216 450 minecraft:black_concrete
fill 518 195 422 518 215 422 minecraft:black_concrete
fill 518 195 456 518 195 457 minecraft:black_concrete
fill 519 195 448 519 211 448 minecraft:black_concrete
fill 520 195 418 520 196 418 minecraft:black_concrete
fill 520 195 446 520 208 446 minecraft:black_concrete
fill 521 195 444 521 199 444 minecraft:black_concrete
setblock 525 195 456 minecraft:black_concrete
fill 537 195 419 537 197 419 minecraft:black_concrete
fill 540 195 420 540 199 420 minecraft:black_concrete
fill 544 195 421 545 196 421 minecraft:black_concrete
setblock 553 195 456 minecraft:black_concrete
fill 557 195 444 557 214 445 minecraft:black_concrete
fill 558 195 422 558 211 422 minecraft:black_concrete
fill 518 196 423 518 216 424 minecraft:black_concrete
fill 518 196 451 518 214 451 minecraft:black_concrete
setblock 528 196 457 minecraft:black_concrete
fill 557 196 446 557 214 446 minecraft:black_concrete
fill 558 196 423 558 212 423 minecraft:black_concrete
fill 518 197 425 518 217 425 minecraft:black_concrete
fill 519 197 421 519 199 422 minecraft:black_concrete
fill 520 197 447 520 208 447 minecraft:black_concrete
fill 521 197 445 521 198 445 minecraft:black_concrete
fill 526 197 419 528 197 419 minecraft:black_concrete
fill 546 197 420 547 197 420 minecraft:black_concrete
setblock 550 197 456 minecraft:black_concrete
fill 557 197 447 557 214 447 minecraft:black_concrete
fill 518 198 426 518 223 427 minecraft:black_concrete
fill 519 198 417 520 198 417 minecraft:black_concrete
fill 519 198 423 519 212 424 minecraft:black_concrete
fill 519 198 449 519 212 449 minecraft:black_concrete
fill 521 198 440 521 198 441 minecraft:black_concrete
setblock 524 198 419 minecraft:black_concrete
setblock 524 198 457 minecraft:black_concrete
setblock 526 198 419 minecraft:black_concrete
fill 528 198 418 529 198 418 minecraft:black_concrete
setblock 546 198 420 minecraft:black_concrete
setblock 553 198 417 minecraft:black_concrete
fill 557 198 441 557 214 443 minecraft:black_concrete
fill 557 198 448 557 214 448 minecraft:black_concrete
setblock 558 198 417 minecraft:black_concrete
setblock 518 199 419 minecraft:black_concrete
fill 518 199 428 518 222 429 minecraft:black_concrete
fill 519 199 425 519 213 425 minecraft:black_concrete
setblock 520 199 417 minecraft:black_concrete
fill 520 199 438 520 199 441 minecraft:black_concrete
setblock 521 199 441 minecraft:black_concrete
setblock 534 199 417 minecraft:black_concrete
fill 536 199 418 537 199 418 minecraft:black_concrete
setblock 547 199 419 minecraft:black_concrete
fill 557 199 449 557 215 449 minecraft:black_concrete
fill 558 199 424 558 213 424 minecraft:black_concrete
fill 518 200 430 518 222 433 minecraft:black_concrete
fill 519 200 422 519 211 422 minecraft:black_concrete
fill 519 200 426 519 214 427 minecraft:black_concrete
fill 519 200 437 519 216 437 minecraft:black_concrete
fill 520 200 439 520 200 441 minecraft:black_concrete
fill 537 200 418 537 223 418 minecraft:black_concrete
setblock 542 200 420 minecraft:black_concrete
setblock 545 200 419 minecraft:black_concrete
fill 558 200 425 558 214 425 minecraft:black_concrete
fill 517 201 416 517 204 417 minecraft:black_concrete
setblock 517 201 418 minecraft:deepslate_tiles
fill 517 201 419 517 204 420 minecraft:black_concrete
setblock 517 201 421 minecraft:deepslate_tiles
fill 517 201 423 517 204 423 minecraft:black_concrete
setblock 517 201 424 minecraft:deepslate_tiles
fill 517 201 425 517 202 427 minecraft:black_concrete
fill 517 201 437 517 204 437 minecraft:black_concrete
fill 517 201 438 517 202 438 minecraft:deepslate_tiles
fill 517 201 439 517 204 439 minecraft:black_concrete
setblock 517 201 440 minecraft:deepslate_tiles
setblock 517 201 442 minecraft:deepslate_tiles
fill 517 201 443 517 204 443 minecraft:black_concrete
setblock 517 201 444 minecraft:deepslate_tiles
fill 517 201 445 517 202 449 minecraft:black_concrete
fill 519 201 428 519 215 429 minecraft:black_concrete
setblock 520 201 419 minecraft:light[level=12]
setblock 520 201 427 minecraft:light[level=12]
setblock 520 201 435 minecraft:light[level=12]
fill 520 201 440 520 201 441 minecraft:black_concrete
setblock 520 201 451 minecraft:light[level=12]
fill 522 201 458 524 204 458 minecraft:black_concrete
fill 525 201 458 525 203 458 minecraft:deepslate_tiles
fill 526 201 458 527 204 458 minecraft:black_concrete
setblock 528 201 419 minecraft:light[level=12]
setblock 528 201 427 minecraft:light[level=12]
setblock 528 201 435 minecraft:light[level=12]
setblock 528 201 443 minecraft:light[level=12]
setblock 528 201 451 minecraft:light[level=12]
fill 535 201 458 537 204 458 minecraft:black_concrete
setblock 536 201 419 minecraft:light[level=12]
setblock 536 201 427 minecraft:light[level=12]
setblock 536 201 435 minecraft:light[level=12]
setblock 536 201 443 minecraft:light[level=12]
setblock 536 201 451 minecraft:light[level=12]
fill 538 201 458 539 201 458 minecraft:deepslate_tiles
fill 539 201 457 539 223 457 minecraft:black_concrete
fill 540 201 458 543 201 458 minecraft:black_concrete
setblock 544 201 427 minecraft:light[level=12]
setblock 544 201 435 minecraft:light[level=12]
setblock 544 201 443 minecraft:light[level=12]
setblock 544 201 451 minecraft:light[level=12]
setblock 547 201 457 minecraft:black_concrete
fill 549 201 416 550 201 416 minecraft:black_concrete
setblock 551 201 416 minecraft:deepslate_tiles
fill 551 201 458 551 204 458 minecraft:black_concrete
fill 552 201 416 553 204 416 minecraft:black_concrete
setblock 552 201 419 minecraft:light[level=12]
setblock 552 201 427 minecraft:light[level=12]
setblock 552 201 435 minecraft:light[level=12]
setblock 552 201 443 minecraft:light[level=12]
setblock 552 201 451 minecraft:light[level=12]
fill 552 201 458 553 201 458 minecraft:deepslate_tiles
fill 554 201 458 555 204 458 minecraft:black_concrete
fill 555 201 416 556 204 416 minecraft:black_concrete
setblock 556 201 458 minecraft:deepslate_tiles
setblock 557 201 416 minecraft:deepslate_tiles
fill 557 201 450 557 215 450 minecraft:black_concrete
fill 558 201 426 558 215 426 minecraft:black_concrete
fill 559 201 422 559 204 425 minecraft:black_concrete
setblock 559 201 426 minecraft:deepslate_tiles
fill 559 201 439 559 204 439 minecraft:black_concrete
fill 559 201 440 559 201 441 minecraft:deepslate_tiles
fill 559 201 442 559 204 442 minecraft:black_concrete
fill 517 202 418 517 204 418 minecraft:black_concrete
fill 517 202 421 517 204 421 minecraft:black_concrete
setblock 517 202 422 minecraft:deepslate_tiles
fill 517 202 424 517 204 424 minecraft:black_concrete
fill 517 202 440 517 204 440 minecraft:black_concrete
fill 517 202 442 517 204 442 minecraft:black_concrete
fill 517 202 444 517 204 444 minecraft:black_concrete
setblock 517 202 453 minecraft:deepslate_tiles
fill 518 202 452 518 215 452 minecraft:black_concrete
fill 519 202 430 519 216 431 minecraft:black_concrete
fill 519 202 450 519 212 450 minecraft:black_concrete
setblock 520 202 416 minecraft:deepslate_tiles
fill 520 202 424 520 210 428 minecraft:black_concrete
fill 520 202 441 520 203 441 minecraft:black_concrete
fill 520 202 448 520 209 448 minecraft:black_concrete
setblock 522 202 416 minecraft:deepslate_tiles
fill 527 202 416 528 204 416 minecraft:black_concrete
fill 528 202 458 529 204 458 minecraft:black_concrete
setblock 529 202 416 minecraft:deepslate_tiles
fill 530 202 416 533 202 416 minecraft:black_concrete
setblock 530 202 458 minecraft:deepslate_tiles
setblock 534 202 416 minecraft:deepslate_tiles
fill 535 202 416 536 202 416 minecraft:black_concrete
fill 537 202 416 538 202 416 minecraft:deepslate_tiles
fill 538 202 458 539 202 458 minecraft:black_concrete
fill 539 202 416 539 204 416 minecraft:black_concrete
setblock 540 202 458 minecraft:deepslate_tiles
fill 541 202 458 543 204 458 minecraft:black_concrete
setblock 542 202 419 minecraft:black_concrete
fill 545 202 458 548 202 458 minecraft:black_concrete
setblock 549 202 416 minecraft:deepslate_tiles
setblock 549 202 458 minecraft:deepslate_tiles
fill 550 202 416 551 204 416 minecraft:black_concrete
fill 550 202 458 550 204 458 minecraft:black_concrete
setblock 552 202 458 minecraft:deepslate_tiles
fill 553 202 458 553 204 458 minecraft:black_concrete
setblock 554 202 416 minecraft:deepslate_tiles
fill 556 202 458 556 204 458 minecraft:black_concrete
fill 557 202 416 557 204 416 minecraft:black_concrete
fill 557 202 451 557 215 451 minecraft:black_concrete
setblock 558 202 416 minecraft:deepslate_tiles
fill 558 202 427 558 216 428 minecraft:black_concrete
fill 559 202 426 559 204 426 minecraft:black_concrete
fill 559 202 428 559 202 429 minecraft:deepslate_tiles
setblock 559 202 432 minecraft:deepslate_tiles
fill 559 202 433 559 204 433 minecraft:black_concrete
setblock 559 202 435 minecraft:deepslate_tiles
fill 559 202 437 559 206 437 minecraft:black_concrete
setblock 559 202 438 minecraft:deepslate_tiles
fill 559 202 440 559 204 441 minecraft:black_concrete
fill 559 202 448 559 207 448 minecraft:black_concrete
fill 559 202 449 559 203 449 minecraft:deepslate_tiles
fill 559 202 453 559 204 454 minecraft:black_concrete
setblock 559 202 455 minecraft:deepslate_tiles
fill 559 202 456 559 205 456 minecraft:black_concrete
fill 517 203 422 517 204 422 minecraft:black_concrete
setblock 517 203 425 minecraft:deepslate_tiles
fill 517 203 426 517 204 427 minecraft:black_concrete
setblock 517 203 428 minecraft:deepslate_tiles
fill 517 203 429 517 204 429 minecraft:black_concrete
fill 517 203 438 517 204 438 minecraft:black_concrete
setblock 517 203 445 minecraft:deepslate_tiles
fill 517 203 446 517 204 449 minecraft:black_concrete
setblock 517 203 451 minecraft:deepslate_tiles
fill 517 203 452 517 204 453 minecraft:black_concrete
fill 518 203 453 518 215 453 minecraft:black_concrete
fill 519 203 421 519 210 421 minecraft:black_concrete
fill 519 203 432 519 218 436 minecraft:black_concrete
fill 519 203 451 519 212 451 minecraft:black_concrete
fill 520 203 416 520 204 416 minecraft:black_concrete
fill 520 203 423 520 209 423 minecraft:black_concrete
fill 520 203 429 520 213 430 minecraft:black_concrete
fill 520 203 458 520 204 458 minecraft:black_concrete
setblock 521 203 458 minecraft:deepslate_tiles
fill 522 203 416 522 204 416 minecraft:black_concrete
setblock 523 203 416 minecraft:deepslate_tiles
fill 524 203 416 526 204 416 minecraft:black_concrete
fill 529 203 416 530 204 416 minecraft:black_concrete
fill 530 203 458 530 204 458 minecraft:black_concrete
fill 531 203 416 532 203 416 minecraft:deepslate_tiles
fill 533 203 416 535 204 416 minecraft:black_concrete
fill 535 203 417 535 223 417 minecraft:black_concrete
fill 536 203 416 537 203 416 minecraft:deepslate_tiles
fill 538 203 416 538 204 416 minecraft:black_concrete
fill 538 203 457 538 204 458 minecraft:black_concrete
setblock 539 203 458 minecraft:deepslate_tiles
fill 540 203 458 540 204 458 minecraft:black_concrete
fill 541 203 454 541 213 454 minecraft:black_concrete
fill 545 203 458 547 204 458 minecraft:black_concrete
setblock 548 203 458 minecraft:deepslate_tiles
fill 549 203 416 549 204 416 minecraft:black_concrete
fill 549 203 458 549 204 458 minecraft:black_concrete
fill 552 203 458 552 204 458 minecraft:black_concrete
fill 554 203 416 554 204 416 minecraft:black_concrete
fill 556 203 445 556 212 448 minecraft:black_concrete
fill 557 203 452 557 215 452 minecraft:black_concrete
fill 558 203 416 558 204 416 minecraft:black_concrete
fill 558 203 429 558 223 431 minecraft:black_concrete
fill 558 203 437 558 223 437 minecraft:black_concrete
fill 558 203 455 559 204 455 minecraft:black_concrete
setblock 559 203 418 minecraft:deepslate_tiles
fill 559 203 419 559 204 420 minecraft:black_concrete
fill 559 203 428 559 204 429 minecraft:black_concrete
fill 559 203 432 559 204 432 minecraft:black_concrete
fill 559 203 435 559 204 435 minecraft:black_concrete
fill 559 203 438 559 204 438 minecraft:black_concrete
setblock 517 204 425 minecraft:black_concrete
setblock 517 204 428 minecraft:black_concrete
fill 517 204 445 517 205 445 minecraft:black_concrete
setblock 517 204 451 minecraft:black_concrete
fill 518 204 419 518 223 419 minecraft:black_concrete
fill 518 204 454 518 216 454 minecraft:black_concrete
fill 520 204 431 520 214 432 minecraft:black_concrete
fill 520 204 449 520 209 449 minecraft:black_concrete
fill 521 204 427 521 210 427 minecraft:black_concrete
setblock 521 204 458 minecraft:black_concrete
fill 523 204 416 523 205 416 minecraft:black_concrete
setblock 525 204 458 minecraft:black_concrete
fill 531 204 416 532 204 416 minecraft:black_concrete
fill 536 204 416 537 204 416 minecraft:black_concrete
fill 537 204 457 537 223 457 minecraft:black_concrete
setblock 539 204 458 minecraft:black_concrete
fill 540 204 456 543 216 456 minecraft:black_concrete
setblock 548 204 458 minecraft:black_concrete
fill 556 204 444 556 211 444 minecraft:black_concrete
fill 556 204 449 556 213 450 minecraft:black_concrete
fill 557 204 453 557 216 453 minecraft:black_concrete
fill 558 204 432 558 223 436 minecraft:black_concrete
fill 558 204 456 558 219 457 minecraft:black_concrete
fill 559 204 418 559 205 418 minecraft:black_concrete
setblock 559 204 449 minecraft:black_concrete
fill 517 205 416 517 205 444 minecraft:deepslate_tiles
fill 517 205 446 517 307 446 minecraft:deepslate_tiles
fill 517 205 447 517 206 447 minecraft:black_concrete
fill 517 205 448 517 206 452 minecraft:deepslate_tiles
setblock 517 205 453 minecraft:black_concrete
fill 517 205 454 517 307 455 minecraft:deepslate_tiles
setblock 517 205 456 minecraft:black_concrete
fill 517 205 457 517 205 458 minecraft:deepslate_tiles
fill 518 205 416 522 205 416 minecraft:deepslate_tiles
fill 518 205 455 518 217 455 minecraft:black_concrete
fill 519 205 452 519 212 452 minecraft:black_concrete
fill 519 205 458 527 205 458 minecraft:deepslate_tiles
fill 520 205 433 520 214 433 minecraft:black_concrete
fill 521 205 425 521 208 426 minecraft:black_concrete
fill 521 205 428 521 211 430 minecraft:black_concrete
fill 524 205 416 524 307 416 minecraft:deepslate_tiles
fill 525 205 416 525 206 416 minecraft:black_concrete
fill 526 205 416 540 205 416 minecraft:deepslate_tiles
setblock 528 205 458 minecraft:black_concrete
fill 529 205 458 531 205 458 minecraft:deepslate_tiles
fill 532 205 458 532 206 458 minecraft:black_concrete
fill 533 205 458 554 205 458 minecraft:deepslate_tiles
fill 534 205 417 534 223 417 minecraft:black_concrete
fill 536 205 418 536 223 418 minecraft:black_concrete
fill 536 205 457 536 223 457 minecraft:black_concrete
fill 538 205 456 538 223 457 minecraft:black_concrete
fill 539 205 456 539 223 456 minecraft:black_concrete
setblock 541 205 416 minecraft:black_concrete
fill 542 205 416 558 205 416 minecraft:deepslate_tiles
fill 544 205 456 544 215 456 minecraft:black_concrete
setblock 555 205 458 minecraft:black_concrete
fill 556 205 451 556 214 452 minecraft:black_concrete
fill 556 205 457 557 222 457 minecraft:black_concrete
fill 556 205 458 559 307 458 minecraft:deepslate_tiles
fill 557 205 425 557 212 430 minecraft:black_concrete
fill 557 205 440 557 223 440 minecraft:black_concrete
fill 557 205 454 557 216 454 minecraft:black_concrete
fill 558 205 455 558 218 455 minecraft:black_concrete
fill 559 205 417 559 307 417 minecraft:deepslate_tiles
fill 559 205 419 559 205 436 minecraft:deepslate_tiles
fill 559 205 438 559 206 447 minecraft:deepslate_tiles
fill 559 205 449 559 205 455 minecraft:deepslate_tiles
fill 559 205 457 559 307 457 minecraft:deepslate_tiles
setblock 517 206 416 minecraft:black_concrete
fill 517 206 417 517 206 438 minecraft:deepslate_tiles
setblock 517 206 439 minecraft:black_concrete
fill 517 206 440 517 307 442 minecraft:deepslate_tiles
fill 517 206 443 517 207 443 minecraft:black_concrete
fill 517 206 444 517 206 445 minecraft:deepslate_tiles
fill 517 206 453 517 307 453 minecraft:deepslate_tiles
fill 517 206 456 517 307 456 minecraft:deepslate_tiles
fill 517 206 457 517 206 458 minecraft:black_concrete
fill 518 206 416 521 307 416 minecraft:deepslate_tiles
fill 518 206 418 518 223 418 minecraft:black_concrete
fill 518 206 456 518 221 456 minecraft:black_concrete
fill 518 206 458 526 307 458 minecraft:deepslate_tiles
fill 519 206 417 521 223 417 minecraft:black_concrete
fill 519 206 453 519 212 453 minecraft:black_concrete
fill 520 206 434 520 213 435 minecraft:black_concrete
setblock 520 206 443 minecraft:black_concrete
fill 520 206 450 520 209 450 minecraft:black_concrete
fill 521 206 431 521 211 431 minecraft:black_concrete
setblock 522 206 416 minecraft:black_concrete
fill 523 206 416 523 307 416 minecraft:deepslate_tiles
fill 526 206 416 533 206 416 minecraft:deepslate_tiles
setblock 527 206 458 minecraft:black_concrete
fill 528 206 458 529 206 458 minecraft:deepslate_tiles
setblock 530 206 458 minecraft:black_concrete
fill 531 206 458 531 307 458 minecraft:deepslate_tiles
fill 533 206 417 533 223 417 minecraft:black_concrete
fill 533 206 458 546 206 458 minecraft:deepslate_tiles
setblock 534 206 416 minecraft:black_concrete
fill 535 206 416 551 206 416 minecraft:deepslate_tiles
fill 535 206 418 535 223 418 minecraft:black_concrete
fill 535 206 457 535 223 457 minecraft:black_concrete
fill 537 206 456 537 223 456 minecraft:black_concrete
fill 539 206 455 542 213 455 minecraft:black_concrete
fill 542 206 418 542 208 418 minecraft:black_concrete
fill 545 206 456 545 214 456 minecraft:black_concrete
fill 547 206 457 547 206 458 minecraft:black_concrete
fill 548 206 458 555 307 458 minecraft:deepslate_tiles
setblock 552 206 416 minecraft:black_concrete
fill 553 206 416 559 206 416 minecraft:deepslate_tiles
fill 554 206 457 555 223 457 minecraft:black_concrete
fill 555 206 448 555 211 449 minecraft:black_concrete
fill 556 206 443 556 211 443 minecraft:black_concrete
fill 556 206 453 556 214 453 minecraft:black_concrete
fill 557 206 424 557 210 424 minecraft:black_concrete
fill 557 206 431 557 222 435 minecraft:black_concrete
fill 557 206 438 557 223 439 minecraft:black_concrete
fill 557 206 455 557 216 456 minecraft:black_concrete
fill 558 206 420 558 210 420 minecraft:black_concrete
fill 559 206 418 559 307 420 minecraft:deepslate_tiles
setblock 559 206 421 minecraft:black_concrete
fill 559 206 422 559 206 436 minecraft:deepslate_tiles
fill 559 206 449 559 206 453 minecraft:deepslate_tiles
setblock 559 206 454 minecraft:black_concrete
fill 559 206 455 559 206 456 minecraft:deepslate_tiles
fill 517 207 416 517 307 422 minecraft:deepslate_tiles
setblock 517 207 423 minecraft:black_concrete
fill 517 207 424 517 307 431 minecraft:deepslate_tiles
setblock 517 207 432 minecraft:black_concrete
fill 517 207 433 517 307 439 minecraft:deepslate_tiles
fill 517 207 444 517 307 444 minecraft:deepslate_tiles
setblock 517 207 445 minecraft:black_concrete
fill 517 207 447 517 307 448 minecraft:deepslate_tiles
setblock 517 207 449 minecraft:black_concrete
fill 517 207 450 517 307 452 minecraft:deepslate_tiles
fill 517 207 457 517 307 458 minecraft:deepslate_tiles
fill 518 207 417 518 223 417 minecraft:black_concrete
fill 518 207 457 520 215 457 minecraft:black_concrete
fill 519 207 420 519 209 420 minecraft:black_concrete
fill 519 207 454 519 212 454 minecraft:black_concrete
fill 520 207 436 520 212 436 minecraft:black_concrete
fill 520 207 451 520 209 451 minecraft:black_concrete
fill 521 207 432 521 211 432 minecraft:black_concrete
fill 522 207 416 522 307 416 minecraft:deepslate_tiles
fill 522 207 417 522 212 417 minecraft:black_concrete
fill 525 207 416 526 307 416 minecraft:deepslate_tiles
setblock 527 207 416 minecraft:black_concrete
fill 527 207 458 528 307 458 minecraft:deepslate_tiles
fill 528 207 416 531 307 416 minecraft:deepslate_tiles
setblock 529 207 458 minecraft:black_concrete
fill 530 207 458 530 307 458 minecraft:deepslate_tiles
fill 532 207 416 532 207 417 minecraft:black_concrete
fill 532 207 458 537 307 458 minecraft:deepslate_tiles
setblock 533 207 416 minecraft:black_concrete
fill 533 207 457 534 223 457 minecraft:black_concrete
fill 534 207 416 534 307 416 minecraft:deepslate_tiles
fill 534 207 418 534 223 418 minecraft:black_concrete
setblock 535 207 416 minecraft:black_concrete
fill 535 207 456 536 223 456 minecraft:black_concrete
fill 536 207 416 540 307 416 minecraft:deepslate_tiles
fill 537 207 455 538 218 455 minecraft:black_concrete
fill 538 207 419 539 207 419 minecraft:black_concrete
setblock 538 207 458 minecraft:black_concrete
fill 539 207 458 547 307 458 minecraft:deepslate_tiles
setblock 541 207 416 minecraft:black_concrete
fill 542 207 416 545 307 416 minecraft:deepslate_tiles
fill 543 207 455 543 212 455 minecraft:black_concrete
setblock 546 207 416 minecraft:black_concrete
fill 547 207 416 548 307 416 minecraft:deepslate_tiles
fill 547 207 457 553 223 457 minecraft:black_concrete
setblock 549 207 416 minecraft:black_concrete
fill 550 207 416 556 307 416 minecraft:deepslate_tiles
fill 554 207 456 556 218 456 minecraft:black_concrete
fill 555 207 447 555 210 447 minecraft:black_concrete
fill 555 207 450 555 212 451 minecraft:black_concrete
fill 556 207 429 556 213 429 minecraft:black_concrete
fill 556 207 454 556 214 454 minecraft:black_concrete
setblock 557 207 416 minecraft:black_concrete
fill 557 207 423 557 209 423 minecraft:black_concrete
fill 557 207 436 557 223 437 minecraft:black_concrete
fill 558 207 416 558 307 416 minecraft:deepslate_tiles
setblock 559 207 416 minecraft:black_concrete
fill 559 207 421 559 307 427 minecraft:deepslate_tiles
setblock 559 207 428 minecraft:black_concrete
fill 559 207 429 559 307 443 minecraft:deepslate_tiles
setblock 559 207 444 minecraft:black_concrete
fill 559 207 445 559 307 445 minecraft:deepslate_tiles
setblock 559 207 446 minecraft:black_concrete
fill 559 207 447 559 307 447 minecraft:deepslate_tiles
setblock 559 207 449 minecraft:black_concrete
fill 559 207 450 559 307 455 minecraft:deepslate_tiles
setblock 559 207 456 minecraft:black_concrete
fill 517 208 423 517 307 423 minecraft:deepslate_tiles
fill 517 208 432 517 307 432 minecraft:deepslate_tiles
fill 517 208 443 517 307 443 minecraft:deepslate_tiles
fill 517 208 445 517 307 445 minecraft:deepslate_tiles
fill 517 208 449 517 307 449 minecraft:deepslate_tiles
fill 519 208 455 519 212 455 minecraft:black_concrete
fill 520 208 437 520 209 437 minecraft:black_concrete
setblock 520 208 452 minecraft:black_concrete
fill 521 208 433 521 210 433 minecraft:black_concrete
fill 521 208 457 521 213 457 minecraft:black_concrete
fill 523 208 417 523 210 417 minecraft:black_concrete
fill 527 208 416 527 307 416 minecraft:deepslate_tiles
fill 529 208 458 529 307 458 minecraft:deepslate_tiles
fill 531 208 417 532 223 417 minecraft:black_concrete
fill 532 208 416 533 307 416 minecraft:deepslate_tiles
fill 532 208 457 532 223 457 minecraft:black_concrete
fill 533 208 418 533 223 418 minecraft:black_concrete
fill 534 208 456 534 223 456 minecraft:black_concrete
fill 535 208 416 535 307 416 minecraft:deepslate_tiles
fill 535 208 455 536 222 455 minecraft:black_concrete
fill 537 208 419 538 209 419 minecraft:black_concrete
fill 538 208 454 540 213 454 minecraft:black_concrete
fill 538 208 458 538 307 458 minecraft:deepslate_tiles
fill 541 208 416 541 307 416 minecraft:deepslate_tiles
fill 544 208 455 544 211 455 minecraft:black_concrete
fill 546 208 416 546 307 416 minecraft:deepslate_tiles
fill 546 208 456 546 214 456 minecraft:black_concrete
fill 549 208 416 549 307 416 minecraft:deepslate_tiles
fill 552 208 456 553 223 456 minecraft:black_concrete
fill 555 208 446 555 209 446 minecraft:black_concrete
fill 555 208 452 555 212 452 minecraft:black_concrete
fill 555 208 455 556 214 455 minecraft:black_concrete
fill 556 208 427 556 211 428 minecraft:black_concrete
fill 556 208 430 556 215 434 minecraft:black_concrete
fill 556 208 442 556 211 442 minecraft:black_concrete
fill 557 208 416 557 307 416 minecraft:deepslate_tiles
fill 558 208 417 558 212 417 minecraft:black_concrete
fill 558 208 419 558 210 419 minecraft:black_concrete
fill 559 208 416 559 307 416 minecraft:deepslate_tiles
fill 559 208 428 559 307 428 minecraft:deepslate_tiles
fill 559 208 444 559 307 444 minecraft:deepslate_tiles
fill 559 208 446 559 307 446 minecraft:deepslate_tiles
fill 559 208 448 559 307 449 minecraft:deepslate_tiles
fill 559 208 456 559 307 456 minecraft:deepslate_tiles
fill 519 209 456 519 212 456 minecraft:black_concrete
setblock 520 209 419 minecraft:light[level=12]
setblock 520 209 443 minecraft:light[level=12]
setblock 521 209 426 minecraft:black_concrete
fill 522 209 457 522 212 457 minecraft:black_concrete
setblock 528 209 419 minecraft:light[level=12]
setblock 528 209 427 minecraft:light[level=12]
setblock 528 209 435 minecraft:light[level=12]
setblock 528 209 443 minecraft:light[level=12]
setblock 528 209 451 minecraft:light[level=12]
fill 530 209 417 530 223 417 minecraft:black_concrete
fill 531 209 457 531 223 457 minecraft:black_concrete
fill 532 209 456 533 223 456 minecraft:black_concrete
fill 534 209 455 534 223 455 minecraft:black_concrete
setblock 536 209 419 minecraft:black_concrete
setblock 536 209 427 minecraft:light[level=12]
setblock 536 209 435 minecraft:light[level=12]
setblock 536 209 443 minecraft:light[level=12]
setblock 536 209 451 minecraft:light[level=12]
fill 536 209 454 537 214 454 minecraft:black_concrete
fill 542 209 454 542 213 454 minecraft:black_concrete
setblock 544 209 419 minecraft:light[level=12]
setblock 544 209 427 minecraft:light[level=12]
setblock 544 209 435 minecraft:light[level=12]
setblock 544 209 443 minecraft:light[level=12]
setblock 544 209 451 minecraft:light[level=12]
fill 547 209 456 551 223 456 minecraft:black_concrete
setblock 552 209 419 minecraft:light[level=12]
setblock 552 209 427 minecraft:light[level=12]
setblock 552 209 435 minecraft:light[level=12]
setblock 552 209 443 minecraft:light[level=12]
setblock 552 209 451 minecraft:light[level=12]
fill 553 209 455 554 215 455 minecraft:black_concrete
fill 555 209 453 555 212 453 minecraft:black_concrete
fill 556 209 435 556 223 437 minecraft:black_concrete
fill 556 209 441 556 211 441 minecraft:black_concrete
fill 557 209 417 557 223 417 minecraft:black_concrete
fill 558 209 418 558 210 418 minecraft:black_concrete
fill 529 210 417 529 223 417 minecraft:black_concrete
fill 529 210 457 530 223 457 minecraft:black_concrete
fill 531 210 456 531 223 456 minecraft:black_concrete
fill 532 210 418 532 223 418 minecraft:black_concrete
fill 533 210 455 533 223 455 minecraft:black_concrete
fill 535 210 454 535 214 454 minecraft:black_concrete
fill 552 210 455 552 215 455 minecraft:black_concrete
fill 555 210 454 555 211 454 minecraft:black_concrete
fill 556 210 417 556 223 417 minecraft:black_concrete
fill 556 210 438 556 212 440 minecraft:black_concrete
setblock 519 211 440 minecraft:black_concrete
fill 520 211 425 520 211 428 minecraft:black_concrete
fill 528 211 417 528 223 417 minecraft:black_concrete
fill 528 211 457 528 223 457 minecraft:black_concrete
setblock 540 211 418 minecraft:black_concrete
fill 541 211 453 541 213 453 minecraft:black_concrete
fill 551 211 455 551 214 455 minecraft:black_concrete
fill 555 211 417 555 223 417 minecraft:black_concrete
fill 520 212 426 520 212 428 minecraft:black_concrete
fill 530 212 456 530 223 456 minecraft:black_concrete
fill 531 212 418 531 223 418 minecraft:black_concrete
fill 532 212 455 532 223 455 minecraft:black_concrete
fill 534 212 454 534 213 454 minecraft:black_concrete
fill 555 212 432 555 212 434 minecraft:black_concrete
setblock 556 212 428 minecraft:black_concrete
setblock 519 213 424 minecraft:black_concrete
fill 519 213 438 519 214 438 minecraft:black_concrete
setblock 520 213 428 minecraft:black_concrete
fill 527 213 417 527 223 417 minecraft:black_concrete
fill 527 213 457 527 223 457 minecraft:black_concrete
fill 538 213 418 538 214 418 minecraft:black_concrete
fill 541 213 417 541 214 417 minecraft:black_concrete
fill 554 213 417 554 223 417 minecraft:black_concrete
fill 555 213 433 555 214 434 minecraft:black_concrete
fill 556 213 438 556 223 439 minecraft:black_concrete
fill 556 213 447 556 213 448 minecraft:black_concrete
fill 557 213 426 557 213 430 minecraft:black_concrete
setblock 518 214 449 minecraft:black_concrete
setblock 520 214 430 minecraft:black_concrete
setblock 520 214 434 minecraft:black_concrete
fill 521 214 440 521 220 440 minecraft:black_concrete
fill 526 214 417 526 223 417 minecraft:black_concrete
fill 529 214 456 529 223 456 minecraft:black_concrete
fill 539 214 455 541 214 455 minecraft:black_concrete
fill 555 214 435 555 221 435 minecraft:black_concrete
setblock 556 214 450 minecraft:black_concrete
fill 557 214 427 557 214 430 minecraft:black_concrete
fill 526 215 457 526 223 457 minecraft:black_concrete
fill 530 215 418 530 223 418 minecraft:black_concrete
fill 531 215 455 531 223 455 minecraft:black_concrete
fill 539 215 455 540 215 455 minecraft:black_concrete
fill 553 215 417 553 223 417 minecraft:black_concrete
setblock 555 215 434 minecraft:black_concrete
setblock 555 215 455 minecraft:black_concrete
fill 557 215 428 557 215 430 minecraft:black_concrete
fill 557 215 441 557 223 442 minecraft:black_concrete
fill 518 216 440 518 223 440 minecraft:black_concrete
fill 518 216 457 519 223 457 minecraft:black_concrete
setblock 519 216 429 minecraft:black_concrete
fill 522 216 417 525 223 417 minecraft:black_concrete
fill 528 216 456 528 223 456 minecraft:black_concrete
fill 529 216 418 529 223 418 minecraft:black_concrete
setblock 539 216 455 minecraft:black_concrete
fill 552 216 417 552 223 417 minecraft:black_concrete
setblock 553 216 455 minecraft:black_concrete
fill 555 216 436 555 222 436 minecraft:black_concrete
fill 556 216 431 556 216 434 minecraft:black_concrete
fill 557 216 429 557 216 430 minecraft:black_concrete
fill 518 217 422 518 223 422 minecraft:black_concrete
setblock 519 217 431 minecraft:black_concrete
setblock 520 217 419 minecraft:light[level=12]
setblock 520 217 427 minecraft:light[level=12]
fill 520 217 433 520 222 433 minecraft:black_concrete
setblock 520 217 435 minecraft:light[level=12]
setblock 520 217 443 minecraft:light[level=12]
setblock 520 217 451 minecraft:light[level=12]
fill 522 217 447 523 219 448 minecraft:black_concrete
fill 525 217 457 525 223 457 minecraft:black_concrete
fill 527 217 421 528 219 422 minecraft:black_concrete
fill 528 217 418 528 223 418 minecraft:black_concrete
setblock 528 217 419 minecraft:light[level=12]
setblock 528 217 427 minecraft:light[level=12]
setblock 528 217 435 minecraft:light[level=12]
setblock 528 217 443 minecraft:light[level=12]
setblock 528 217 451 minecraft:light[level=12]
setblock 536 217 419 minecraft:light[level=12]
setblock 536 217 427 minecraft:light[level=12]
setblock 536 217 435 minecraft:light[level=12]
setblock 536 217 443 minecraft:light[level=12]
setblock 536 217 451 minecraft:light[level=12]
fill 540 217 456 542 222 456 minecraft:black_concrete
fill 541 217 418 542 219 418 minecraft:black_concrete
fill 542 217 419 542 222 419 minecraft:black_concrete
setblock 544 217 419 minecraft:light[level=12]
setblock 544 217 427 minecraft:light[level=12]
setblock 544 217 435 minecraft:light[level=12]
setblock 544 217 443 minecraft:light[level=12]
setblock 544 217 451 minecraft:light[level=12]
fill 548 217 452 549 219 453 minecraft:black_concrete
fill 550 217 417 551 223 417 minecraft:black_concrete
setblock 552 217 419 minecraft:light[level=12]
setblock 552 217 427 minecraft:light[level=12]
setblock 552 217 435 minecraft:light[level=12]
setblock 552 217 443 minecraft:light[level=12]
setblock 552 217 451 minecraft:light[level=12]
fill 553 217 426 554 219 427 minecraft:black_concrete
fill 555 217 437 555 223 437 minecraft:black_concrete
fill 556 217 432 556 219 434 minecraft:black_concrete
fill 556 217 440 556 223 441 minecraft:black_concrete
fill 557 217 430 557 219 430 minecraft:black_concrete
fill 558 217 428 558 223 428 minecraft:black_concrete
fill 558 217 442 558 223 443 minecraft:black_concrete
fill 518 218 423 518 223 423 minecraft:black_concrete
fill 520 218 434 520 222 434 minecraft:black_concrete
fill 524 218 457 524 223 457 minecraft:black_concrete
fill 526 218 418 527 223 418 minecraft:black_concrete
fill 527 218 456 527 223 456 minecraft:black_concrete
fill 530 218 455 530 223 455 minecraft:black_concrete
fill 531 218 419 533 223 419 minecraft:black_concrete
fill 541 218 419 541 222 419 minecraft:black_concrete
fill 546 218 456 546 223 456 minecraft:black_concrete
fill 549 218 417 549 223 417 minecraft:black_concrete
fill 555 218 438 555 223 438 minecraft:black_concrete
fill 558 218 417 558 223 417 minecraft:black_concrete
setblock 558 218 454 minecraft:black_concrete
fill 518 219 424 518 223 425 minecraft:black_concrete
fill 519 219 433 519 219 436 minecraft:black_concrete
fill 520 219 440 520 220 440 minecraft:black_concrete
fill 520 219 457 520 223 457 minecraft:black_concrete
fill 521 219 439 521 220 439 minecraft:black_concrete
fill 521 219 441 521 220 441 minecraft:black_concrete
fill 522 219 440 522 220 440 minecraft:black_concrete
fill 522 219 457 523 223 457 minecraft:black_concrete
fill 524 219 418 525 223 418 minecraft:black_concrete
fill 526 219 456 526 223 456 minecraft:black_concrete
fill 528 219 419 530 223 419 minecraft:black_concrete
fill 529 219 455 529 223 455 minecraft:black_concrete
fill 534 219 419 534 223 419 minecraft:black_concrete
fill 537 219 455 537 220 455 minecraft:black_concrete
fill 541 219 417 541 223 417 minecraft:black_concrete
fill 545 219 456 545 223 456 minecraft:black_concrete
fill 547 219 417 548 223 417 minecraft:black_concrete
fill 553 219 418 553 223 418 minecraft:black_concrete
fill 554 219 456 555 220 456 minecraft:black_concrete
fill 555 219 439 555 223 439 minecraft:black_concrete
fill 558 219 418 558 223 419 minecraft:black_concrete
fill 518 220 441 518 223 441 minecraft:black_concrete
fill 519 220 418 519 223 419 minecraft:black_concrete
setblock 519 220 436 minecraft:black_concrete
fill 520 220 418 523 223 418 minecraft:black_concrete
fill 521 220 433 521 223 434 minecraft:black_concrete
fill 521 220 457 521 223 457 minecraft:black_concrete
fill 522 220 447 523 221 447 minecraft:black_concrete
fill 523 220 446 523 223 446 minecraft:black_concrete
setblock 523 220 448 minecraft:black_concrete
fill 526 220 419 527 223 419 minecraft:black_concrete
fill 527 220 422 529 220 422 minecraft:black_concrete
fill 528 220 421 528 221 421 minecraft:black_concrete
fill 534 220 454 535 223 454 minecraft:black_concrete
fill 535 220 419 535 223 419 minecraft:black_concrete
fill 541 220 420 542 223 420 minecraft:black_concrete
fill 542 220 417 542 223 417 minecraft:black_concrete
fill 543 220 456 544 223 456 minecraft:black_concrete
fill 544 220 417 546 223 417 minecraft:black_concrete
fill 547 220 452 549 220 452 minecraft:black_concrete
fill 548 220 453 548 221 453 minecraft:black_concrete
fill 550 220 418 552 223 418 minecraft:black_concrete
fill 553 220 426 553 220 428 minecraft:black_concrete
fill 554 220 418 555 223 418 minecraft:black_concrete
fill 554 220 427 554 221 427 minecraft:black_concrete
fill 555 220 440 555 223 441 minecraft:black_concrete
fill 556 220 433 556 222 434 minecraft:black_concrete
fill 557 220 443 557 223 443 minecraft:black_concrete
fill 558 220 420 558 223 421 minecraft:black_concrete
fill 558 220 444 558 223 444 minecraft:black_concrete
fill 558 220 457 558 221 457 minecraft:black_concrete
fill 519 221 420 519 223 421 minecraft:black_concrete
fill 524 221 447 524 223 447 minecraft:black_concrete
fill 525 221 419 525 223 419 minecraft:black_concrete
fill 525 221 456 525 223 456 minecraft:black_concrete
fill 528 221 422 528 223 423 minecraft:black_concrete
fill 528 221 455 528 223 455 minecraft:black_concrete
fill 529 221 422 529 223 422 minecraft:black_concrete
fill 530 221 420 530 223 420 minecraft:black_concrete
fill 538 221 418 538 223 418 minecraft:black_concrete
fill 543 221 417 543 223 417 minecraft:black_concrete
fill 547 221 452 548 223 452 minecraft:black_concrete
fill 548 221 418 549 223 418 minecraft:black_concrete
fill 548 221 451 548 223 451 minecraft:black_concrete
fill 552 221 427 553 223 427 minecraft:black_concrete
fill 553 221 428 553 223 428 minecraft:black_concrete
fill 554 221 456 554 222 456 minecraft:black_concrete
fill 556 221 418 556 223 418 minecraft:black_concrete
fill 556 221 442 556 223 442 minecraft:black_concrete
fill 558 221 422 558 223 423 minecraft:black_concrete
fill 518 222 442 518 223 442 minecraft:black_concrete
fill 519 222 422 519 223 422 minecraft:black_concrete
fill 522 222 419 524 223 419 minecraft:black_concrete
fill 523 222 447 523 223 447 minecraft:black_concrete
fill 524 222 446 524 223 446 minecraft:black_concrete
fill 524 222 456 524 223 456 minecraft:black_concrete
fill 527 222 420 529 223 420 minecraft:black_concrete
fill 529 222 423 529 223 423 minecraft:black_concrete
fill 531 222 420 532 223 420 minecraft:black_concrete
fill 546 222 418 547 223 418 minecraft:black_concrete
fill 547 222 451 547 223 451 minecraft:black_concrete
fill 551 222 419 552 223 419 minecraft:black_concrete
fill 552 222 428 552 223 428 minecraft:black_concrete
fill 557 222 418 557 223 420 minecraft:black_concrete
fill 558 222 424 558 223 427 minecraft:black_concrete
fill 558 222 445 558 223 445 minecraft:black_concrete
setblock 518 223 428 minecraft:black_concrete
fill 518 223 431 518 223 433 minecraft:black_concrete
setblock 519 223 423 minecraft:black_concrete
fill 520 223 419 521 223 419 minecraft:black_concrete
fill 522 223 433 522 223 434 minecraft:black_concrete
setblock 526 223 420 minecraft:black_concrete
setblock 527 223 455 minecraft:black_concrete
fill 534 223 453 535 223 453 minecraft:black_concrete
setblock 535 223 455 minecraft:black_concrete
fill 541 223 421 542 223 421 minecraft:black_concrete
setblock 545 223 418 minecraft:black_concrete
fill 549 223 419 550 223 419 minecraft:black_concrete
setblock 553 223 419 minecraft:black_concrete
fill 554 223 440 554 223 441 minecraft:black_concrete
fill 556 223 434 557 223 434 minecraft:black_concrete
setblock 556 223 457 minecraft:black_concrete
fill 557 223 421 557 223 422 minecraft:black_concrete
fill 557 223 432 557 223 433 minecraft:black_concrete
setblock 557 223 435 minecraft:black_concrete
setblock 557 223 444 minecraft:black_concrete
setblock 520 225 419 minecraft:light[level=12]
setblock 520 225 427 minecraft:light[level=12]
setblock 520 225 435 minecraft:light[level=12]
setblock 520 225 443 minecraft:light[level=12]
setblock 520 225 451 minecraft:light[level=12]
setblock 528 225 419 minecraft:light[level=12]
setblock 528 225 427 minecraft:light[level=12]
setblock 528 225 435 minecraft:light[level=12]
setblock 528 225 443 minecraft:light[level=12]
setblock 528 225 451 minecraft:light[level=12]
setblock 536 225 419 minecraft:light[level=12]
setblock 536 225 427 minecraft:light[level=12]
setblock 536 225 435 minecraft:light[level=12]
setblock 536 225 443 minecraft:light[level=12]
setblock 536 225 451 minecraft:light[level=12]
setblock 544 225 419 minecraft:light[level=12]
setblock 544 225 427 minecraft:light[level=12]
setblock 544 225 435 minecraft:light[level=12]
setblock 544 225 443 minecraft:light[level=12]
setblock 544 225 451 minecraft:light[level=12]
setblock 552 225 419 minecraft:light[level=12]
setblock 552 225 427 minecraft:light[level=12]
setblock 552 225 435 minecraft:light[level=12]
setblock 552 225 443 minecraft:light[level=12]
setblock 552 225 451 minecraft:light[level=12]
fill 528 229 438 535 229 438 minecraft:black_concrete
fill 529 229 434 536 229 437 minecraft:black_concrete
fill 529 229 439 536 229 442 minecraft:black_concrete
fill 530 229 432 546 229 433 minecraft:black_concrete
fill 530 229 443 546 229 444 minecraft:black_concrete
fill 531 229 431 545 229 431 minecraft:black_concrete
fill 531 229 445 545 229 445 minecraft:black_concrete
fill 532 229 430 544 229 430 minecraft:black_concrete
fill 532 229 446 544 229 446 minecraft:black_concrete
fill 534 229 429 542 230 429 minecraft:black_concrete
fill 534 229 447 542 230 447 minecraft:black_concrete
fill 537 229 434 537 229 436 minecraft:black_concrete
fill 537 229 440 537 229 442 minecraft:black_concrete
fill 538 229 428 538 230 428 minecraft:black_concrete
fill 538 229 434 547 229 435 minecraft:black_concrete
fill 538 229 441 547 229 442 minecraft:black_concrete
fill 538 229 448 538 230 448 minecraft:black_concrete
fill 539 229 436 547 229 436 minecraft:black_concrete
fill 539 229 440 547 229 440 minecraft:black_concrete
fill 540 229 437 547 229 437 minecraft:black_concrete
fill 540 229 439 547 229 439 minecraft:black_concrete
fill 541 229 438 548 229 438 minecraft:black_concrete
fill 518 230 417 529 230 457 minecraft:black_concrete
fill 530 230 417 530 230 435 minecraft:black_concrete
fill 530 230 436 530 230 440 minecraft:red_concrete
fill 530 230 441 530 230 457 minecraft:black_concrete
fill 531 230 417 531 230 433 minecraft:black_concrete
fill 531 230 434 531 230 435 minecraft:red_concrete
fill 531 230 436 533 230 440 minecraft:black_concrete
fill 531 230 441 531 230 442 minecraft:red_concrete
fill 531 230 443 531 230 457 minecraft:black_concrete
fill 532 230 417 532 230 432 minecraft:black_concrete
setblock 532 230 433 minecraft:red_concrete
fill 532 230 434 534 230 435 minecraft:black_concrete
fill 532 230 441 534 230 442 minecraft:black_concrete
setblock 532 230 443 minecraft:red_concrete
fill 532 230 444 532 230 457 minecraft:black_concrete
fill 533 230 417 533 230 431 minecraft:black_concrete
setblock 533 230 432 minecraft:red_concrete
fill 533 230 433 543 230 433 minecraft:black_concrete
fill 533 230 443 543 230 443 minecraft:black_concrete
setblock 533 230 444 minecraft:red_concrete
fill 533 230 445 533 230 457 minecraft:black_concrete
fill 534 230 417 537 230 428 minecraft:black_concrete
fill 534 230 430 535 230 430 minecraft:black_concrete
fill 534 230 431 535 230 431 minecraft:red_concrete
fill 534 230 432 542 230 432 minecraft:black_concrete
fill 534 230 436 534 230 440 minecraft:red_concrete
fill 534 230 444 542 230 444 minecraft:black_concrete
fill 534 230 445 535 230 445 minecraft:red_concrete
fill 534 230 446 535 230 446 minecraft:black_concrete
fill 534 230 448 537 230 457 minecraft:black_concrete
setblock 535 230 434 minecraft:black_concrete
fill 535 230 435 535 230 436 minecraft:red_concrete
fill 535 230 437 535 230 439 minecraft:crying_obsidian
fill 535 230 440 535 230 441 minecraft:red_concrete
setblock 535 230 442 minecraft:black_concrete
fill 536 230 430 540 230 430 minecraft:red_concrete
fill 536 230 431 540 230 431 minecraft:black_concrete
fill 536 230 434 536 230 435 minecraft:red_concrete
fill 536 230 436 536 230 437 minecraft:crying_obsidian
fill 536 230 439 536 230 440 minecraft:crying_obsidian
fill 536 230 441 536 230 442 minecraft:red_concrete
fill 536 230 445 540 230 445 minecraft:black_concrete
fill 536 230 446 540 230 446 minecraft:red_concrete
fill 537 230 434 540 230 434 minecraft:red_concrete
fill 537 230 435 537 230 436 minecraft:crying_obsidian
fill 537 230 440 537 230 441 minecraft:crying_obsidian
fill 537 230 442 540 230 442 minecraft:red_concrete
fill 538 230 417 558 230 427 minecraft:black_concrete
fill 538 230 435 539 230 435 minecraft:crying_obsidian
fill 538 230 441 539 230 441 minecraft:crying_obsidian
fill 538 230 449 558 230 457 minecraft:black_concrete
fill 539 230 428 558 230 428 minecraft:black_concrete
fill 539 230 436 540 230 436 minecraft:crying_obsidian
fill 539 230 440 540 230 440 minecraft:crying_obsidian
fill 539 230 448 558 230 448 minecraft:black_concrete
fill 540 230 435 541 230 435 minecraft:red_concrete
fill 540 230 437 541 230 437 minecraft:crying_obsidian
fill 540 230 439 541 230 439 minecraft:crying_obsidian
fill 540 230 441 541 230 441 minecraft:red_concrete
fill 541 230 430 558 230 430 minecraft:black_concrete
fill 541 230 431 542 230 431 minecraft:red_concrete
fill 541 230 434 544 230 434 minecraft:black_concrete
fill 541 230 436 542 230 436 minecraft:red_concrete
setblock 541 230 438 minecraft:crying_obsidian
fill 541 230 440 542 230 440 minecraft:red_concrete
fill 541 230 442 544 230 442 minecraft:black_concrete
fill 541 230 445 542 230 445 minecraft:red_concrete
fill 541 230 446 558 230 446 minecraft:black_concrete
fill 542 230 435 544 230 435 minecraft:black_concrete
fill 542 230 437 542 230 439 minecraft:red_concrete
fill 542 230 441 544 230 441 minecraft:black_concrete
fill 543 230 429 558 230 429 minecraft:black_concrete
fill 543 230 431 558 230 431 minecraft:black_concrete
setblock 543 230 432 minecraft:red_concrete
fill 543 230 436 545 230 440 minecraft:black_concrete
setblock 543 230 444 minecraft:red_concrete
fill 543 230 445 558 230 445 minecraft:black_concrete
fill 543 230 447 558 230 447 minecraft:black_concrete
fill 544 230 432 558 230 432 minecraft:black_concrete
setblock 544 230 433 minecraft:red_concrete
setblock 544 230 443 minecraft:red_concrete
fill 544 230 444 558 230 444 minecraft:black_concrete
fill 545 230 433 558 230 433 minecraft:black_concrete
fill 545 230 434 545 230 435 minecraft:red_concrete
fill 545 230 441 545 230 442 minecraft:red_concrete
fill 545 230 443 558 230 443 minecraft:black_concrete
fill 546 230 434 558 230 435 minecraft:black_concrete
fill 546 230 436 546 230 440 minecraft:red_concrete
fill 546 230 441 558 230 442 minecraft:black_concrete
fill 547 230 436 558 230 440 minecraft:black_concrete
setblock 520 233 419 minecraft:light[level=12]
setblock 520 233 427 minecraft:light[level=12]
setblock 520 233 435 minecraft:light[level=12]
setblock 520 233 443 minecraft:light[level=12]
setblock 520 233 451 minecraft:light[level=12]
setblock 528 233 419 minecraft:light[level=12]
setblock 528 233 427 minecraft:light[level=12]
setblock 528 233 435 minecraft:light[level=12]
setblock 528 233 443 minecraft:light[level=12]
setblock 528 233 451 minecraft:light[level=12]
setblock 536 233 419 minecraft:light[level=12]
setblock 536 233 427 minecraft:light[level=12]
setblock 536 233 435 minecraft:light[level=12]
setblock 536 233 443 minecraft:light[level=12]
setblock 536 233 451 minecraft:light[level=12]
setblock 544 233 419 minecraft:light[level=12]
setblock 544 233 427 minecraft:light[level=12]
setblock 544 233 435 minecraft:light[level=12]
setblock 544 233 443 minecraft:light[level=12]
setblock 544 233 451 minecraft:light[level=12]
setblock 552 233 419 minecraft:light[level=12]
setblock 552 233 427 minecraft:light[level=12]
setblock 552 233 435 minecraft:light[level=12]
setblock 552 233 443 minecraft:light[level=12]
setblock 552 233 451 minecraft:light[level=12]
fill 518 234 417 518 243 430 minecraft:black_concrete
fill 518 234 445 518 256 453 minecraft:black_concrete
fill 519 234 417 528 234 417 minecraft:black_concrete
fill 519 234 419 519 241 428 minecraft:black_concrete
fill 519 234 448 519 245 450 minecraft:black_concrete
fill 519 234 457 530 254 457 minecraft:black_concrete
fill 520 234 418 526 234 418 minecraft:black_concrete
fill 520 234 423 520 238 425 minecraft:black_concrete
fill 521 234 456 527 243 456 minecraft:black_concrete
fill 524 234 434 525 234 435 minecraft:black_concrete
fill 526 234 444 527 234 445 minecraft:black_concrete
fill 529 234 435 531 234 436 minecraft:black_concrete
fill 530 234 425 531 234 426 minecraft:black_concrete
setblock 530 234 434 minecraft:black_concrete
fill 530 234 441 532 235 442 minecraft:black_concrete
fill 531 234 443 531 236 443 minecraft:black_concrete
fill 532 234 430 534 235 430 minecraft:black_concrete
setblock 532 234 440 minecraft:black_concrete
fill 533 234 429 534 236 429 minecraft:black_concrete
fill 533 234 431 535 234 431 minecraft:black_concrete
fill 535 234 445 537 234 445 minecraft:black_concrete
fill 535 234 450 536 234 451 minecraft:black_concrete
fill 536 234 444 537 234 444 minecraft:black_concrete
fill 536 234 446 537 236 446 minecraft:black_concrete
fill 539 234 428 540 234 430 minecraft:black_concrete
fill 540 234 423 541 234 424 minecraft:black_concrete
setblock 541 234 429 minecraft:black_concrete
fill 541 234 443 543 234 443 minecraft:black_concrete
fill 542 234 444 543 235 445 minecraft:black_concrete
fill 544 234 432 544 234 434 minecraft:black_concrete
fill 544 234 444 544 236 444 minecraft:black_concrete
fill 545 234 431 545 235 433 minecraft:black_concrete
fill 545 234 438 547 234 439 minecraft:black_concrete
fill 545 234 448 546 234 449 minecraft:black_concrete
fill 546 234 432 546 236 433 minecraft:black_concrete
setblock 546 234 440 minecraft:black_concrete
fill 549 234 429 550 234 430 minecraft:black_concrete
fill 551 234 439 552 234 440 minecraft:black_concrete
fill 557 234 422 558 243 429 minecraft:black_concrete
fill 558 234 418 558 259 421 minecraft:black_concrete
fill 558 234 430 558 252 432 minecraft:black_concrete
fill 518 235 431 518 251 431 minecraft:black_concrete
fill 518 235 444 518 243 444 minecraft:black_concrete
fill 518 235 454 518 256 457 minecraft:black_concrete
fill 519 235 417 525 236 418 minecraft:black_concrete
fill 519 235 429 519 243 429 minecraft:black_concrete
fill 519 235 446 519 242 447 minecraft:black_concrete
fill 519 235 451 519 253 454 minecraft:black_concrete
fill 520 235 422 520 237 422 minecraft:black_concrete
fill 520 235 426 520 240 427 minecraft:black_concrete
fill 520 235 448 520 242 451 minecraft:black_concrete
fill 520 235 456 520 254 456 minecraft:black_concrete
fill 522 235 455 526 242 455 minecraft:black_concrete
fill 525 235 434 526 237 435 minecraft:black_concrete
fill 526 235 417 527 237 417 minecraft:black_concrete
fill 526 235 444 528 235 444 minecraft:black_concrete
fill 527 235 445 527 236 445 minecraft:black_concrete
fill 528 235 435 530 235 436 minecraft:black_concrete
fill 528 235 456 528 242 456 minecraft:black_concrete
fill 529 235 434 529 236 434 minecraft:black_concrete
fill 529 235 442 529 238 443 minecraft:black_concrete
fill 530 235 420 530 258 420 minecraft:white_wool
fill 530 235 426 531 236 426 minecraft:black_concrete
fill 530 235 443 530 238 443 minecraft:black_concrete
setblock 531 235 425 minecraft:black_concrete
fill 531 235 427 531 239 427 minecraft:black_concrete
fill 532 235 428 532 238 429 minecraft:black_concrete
fill 533 235 428 533 238 428 minecraft:black_concrete
fill 533 235 431 534 235 431 minecraft:black_concrete
fill 535 235 446 535 236 446 minecraft:black_concrete
fill 535 235 449 536 237 450 minecraft:black_concrete
fill 536 235 445 537 235 445 minecraft:black_concrete
fill 536 235 447 537 237 447 minecraft:black_concrete
fill 539 235 427 540 235 429 minecraft:black_concrete
fill 540 235 424 541 237 425 minecraft:black_concrete
fill 541 235 428 541 236 428 minecraft:black_concrete
fill 542 235 443 543 235 443 minecraft:black_concrete
fill 543 235 446 544 238 446 minecraft:black_concrete
fill 543 235 457 543 245 457 minecraft:black_concrete
fill 544 235 432 544 235 433 minecraft:black_concrete
fill 544 235 445 544 238 445 minecraft:black_concrete
fill 545 235 447 545 235 449 minecraft:black_concrete
fill 546 235 431 547 238 431 minecraft:black_concrete
fill 546 235 438 548 235 439 minecraft:black_concrete
fill 546 235 448 546 236 448 minecraft:black_concrete
fill 547 235 432 547 238 432 minecraft:black_concrete
fill 547 235 440 547 236 440 minecraft:black_concrete
fill 548 235 430 550 235 430 minecraft:black_concrete
fill 549 235 429 549 236 429 minecraft:black_concrete
fill 550 235 439 551 237 440 minecraft:black_concrete
fill 557 235 421 557 258 421 minecraft:black_concrete
fill 557 235 430 557 248 431 minecraft:black_concrete
fill 558 235 417 558 258 417 minecraft:black_concrete
fill 558 235 433 558 253 433 minecraft:black_concrete
fill 558 235 445 558 240 451 minecraft:black_concrete
fill 518 236 432 518 252 432 minecraft:black_concrete
fill 519 236 430 519 243 431 minecraft:black_concrete
fill 519 236 445 519 241 445 minecraft:black_concrete
fill 519 236 455 519 254 456 minecraft:black_concrete
fill 520 236 428 520 240 428 minecraft:black_concrete
fill 520 236 447 520 241 447 minecraft:black_concrete
fill 520 236 452 520 247 455 minecraft:black_concrete
fill 521 236 449 521 241 451 minecraft:black_concrete
fill 521 236 455 521 249 455 minecraft:black_concrete
fill 527 236 434 528 238 435 minecraft:black_concrete
fill 527 236 444 528 239 444 minecraft:black_concrete
fill 527 236 455 527 240 455 minecraft:black_concrete
fill 528 236 436 529 236 436 minecraft:black_concrete
fill 529 236 435 530 236 435 minecraft:black_concrete
fill 530 236 441 530 236 442 minecraft:black_concrete
setblock 531 236 442 minecraft:black_concrete
fill 532 236 430 533 236 430 minecraft:black_concrete
fill 535 236 447 535 238 448 minecraft:black_concrete
setblock 536 236 445 minecraft:black_concrete
fill 536 236 448 536 239 448 minecraft:black_concrete
fill 539 236 427 540 236 428 minecraft:black_concrete
fill 540 236 426 541 239 426 minecraft:black_concrete
setblock 540 236 429 minecraft:black_concrete
fill 540 236 457 542 252 457 minecraft:black_concrete
fill 541 236 427 541 238 427 minecraft:black_concrete
fill 542 236 445 543 236 445 minecraft:black_concrete
setblock 543 236 444 minecraft:black_concrete
fill 544 236 457 545 241 457 minecraft:black_concrete
fill 545 236 431 545 236 432 minecraft:black_concrete
fill 545 236 447 545 239 448 minecraft:black_concrete
fill 546 236 439 549 236 439 minecraft:black_concrete
fill 547 236 438 548 236 438 minecraft:black_concrete
fill 548 236 430 549 239 430 minecraft:black_concrete
fill 548 236 440 549 238 440 minecraft:black_concrete
fill 556 236 425 556 240 429 minecraft:black_concrete
fill 557 236 417 557 259 417 minecraft:black_concrete
fill 557 236 432 557 250 432 minecraft:black_concrete
fill 558 236 434 558 254 435 minecraft:black_concrete
fill 558 236 452 558 257 454 minecraft:black_concrete
fill 518 237 433 518 253 434 minecraft:black_concrete
fill 518 237 443 518 241 443 minecraft:black_concrete
fill 519 237 417 524 238 418 minecraft:black_concrete
fill 519 237 432 519 245 432 minecraft:black_concrete
fill 520 237 429 520 240 430 minecraft:black_concrete
fill 520 237 446 520 239 446 minecraft:black_concrete
fill 521 237 448 521 240 448 minecraft:black_concrete
fill 521 237 452 521 243 454 minecraft:black_concrete
fill 522 237 454 525 240 454 minecraft:black_concrete
fill 525 237 417 525 241 417 minecraft:black_concrete
fill 527 237 436 528 237 436 minecraft:black_concrete
fill 527 237 443 528 239 443 minecraft:black_concrete
setblock 528 237 442 minecraft:black_concrete
setblock 529 237 435 minecraft:black_concrete
fill 529 237 444 529 239 444 minecraft:black_concrete
fill 529 237 456 529 241 456 minecraft:black_concrete
setblock 530 237 442 minecraft:black_concrete
fill 531 237 426 532 239 426 minecraft:black_concrete
fill 531 237 428 531 239 428 minecraft:black_concrete
fill 531 237 457 531 257 457 minecraft:black_concrete
fill 532 237 427 533 237 427 minecraft:black_concrete
setblock 533 237 429 minecraft:black_concrete
setblock 536 237 446 minecraft:black_concrete
fill 537 237 448 537 238 448 minecraft:black_concrete
fill 537 237 457 539 254 457 minecraft:black_concrete
fill 539 237 426 539 237 427 minecraft:black_concrete
fill 540 237 427 540 237 428 minecraft:black_concrete
fill 541 237 456 542 242 456 minecraft:black_concrete
fill 542 237 417 544 240 417 minecraft:black_concrete
setblock 543 237 445 minecraft:black_concrete
fill 543 237 447 544 237 447 minecraft:black_concrete
fill 544 237 448 544 239 448 minecraft:black_concrete
fill 545 237 446 545 239 446 minecraft:black_concrete
setblock 546 237 432 minecraft:black_concrete
fill 547 237 430 547 239 430 minecraft:black_concrete
fill 547 237 439 549 237 439 minecraft:black_concrete
fill 548 237 431 548 237 432 minecraft:black_concrete
fill 548 237 438 549 237 438 minecraft:black_concrete
fill 549 237 431 549 239 431 minecraft:black_concrete
fill 556 237 424 556 239 424 minecraft:black_concrete
fill 556 237 430 556 243 430 minecraft:black_concrete
fill 557 237 420 557 258 420 minecraft:black_concrete
fill 557 237 433 557 251 433 minecraft:black_concrete
fill 558 237 436 558 255 436 minecraft:black_concrete
fill 558 237 444 558 238 444 minecraft:black_concrete
fill 558 237 455 558 257 457 minecraft:black_concrete
fill 518 238 435 518 255 435 minecraft:black_concrete
fill 519 238 433 519 245 433 minecraft:black_concrete
fill 522 238 451 522 239 451 minecraft:black_concrete
fill 525 238 435 526 239 435 minecraft:black_concrete
fill 526 238 417 526 239 417 minecraft:black_concrete
fill 526 238 434 526 239 434 minecraft:black_concrete
fill 526 238 454 526 239 454 minecraft:black_concrete
setblock 527 238 436 minecraft:black_concrete
fill 532 238 427 532 239 427 minecraft:black_concrete
fill 532 238 457 532 257 457 minecraft:black_concrete
fill 535 238 449 536 239 449 minecraft:black_concrete
fill 535 238 457 536 255 457 minecraft:black_concrete
setblock 536 238 447 minecraft:black_concrete
fill 536 238 450 536 239 450 minecraft:black_concrete
fill 538 238 456 540 245 456 minecraft:black_concrete
setblock 539 238 426 minecraft:black_concrete
fill 540 238 424 540 239 425 minecraft:black_concrete
setblock 540 238 427 minecraft:black_concrete
fill 541 238 417 541 258 417 minecraft:black_concrete
fill 541 238 425 541 239 425 minecraft:black_concrete
fill 543 238 456 543 241 456 minecraft:black_concrete
fill 544 238 447 544 239 447 minecraft:black_concrete
setblock 545 238 417 minecraft:black_concrete
fill 546 238 457 546 239 457 minecraft:black_concrete
fill 548 238 431 548 239 431 minecraft:black_concrete
fill 548 238 439 551 238 439 minecraft:black_concrete
setblock 549 238 438 minecraft:black_concrete
fill 550 238 440 550 239 440 minecraft:black_concrete
fill 556 238 417 556 260 417 minecraft:black_concrete
fill 556 238 431 556 243 431 minecraft:black_concrete
fill 557 238 434 557 252 434 minecraft:black_concrete
fill 557 238 449 557 240 453 minecraft:black_concrete
fill 557 238 457 557 259 457 minecraft:black_concrete
fill 558 238 437 558 255 437 minecraft:black_concrete
fill 518 239 436 518 256 436 minecraft:black_concrete
fill 519 239 417 523 239 418 minecraft:black_concrete
fill 519 239 434 519 250 434 minecraft:black_concrete
fill 520 239 424 520 239 425 minecraft:black_concrete
fill 520 239 431 520 240 431 minecraft:black_concrete
fill 522 239 452 522 240 453 minecraft:black_concrete
fill 524 239 417 524 242 417 minecraft:black_concrete
fill 527 239 434 527 239 435 minecraft:black_concrete
setblock 529 239 443 minecraft:black_concrete
setblock 532 239 428 minecraft:black_concrete
fill 533 239 457 534 256 457 minecraft:black_concrete
setblock 535 239 448 minecraft:black_concrete
fill 537 239 456 537 252 456 minecraft:black_concrete
fill 540 239 417 540 258 417 minecraft:black_concrete
setblock 544 239 446 minecraft:black_concrete
setblock 544 239 456 minecraft:black_concrete
setblock 547 239 431 minecraft:black_concrete
fill 549 239 439 549 239 440 minecraft:black_concrete
fill 550 239 439 551 239 439 minecraft:black_concrete
fill 555 239 417 555 261 417 minecraft:black_concrete
fill 556 239 432 556 243 432 minecraft:black_concrete
fill 556 239 457 556 259 457 minecraft:black_concrete
fill 557 239 418 557 258 419 minecraft:black_concrete
fill 557 239 454 557 255 455 minecraft:black_concrete
fill 518 240 437 518 257 437 minecraft:black_concrete
fill 519 240 417 522 241 418 minecraft:black_concrete
fill 523 240 417 523 245 417 minecraft:black_concrete
fill 536 240 456 536 253 456 minecraft:black_concrete
fill 539 240 455 541 240 455 minecraft:black_concrete
fill 554 240 417 554 263 417 minecraft:black_concrete
fill 555 240 457 555 261 457 minecraft:black_concrete
fill 557 240 435 557 253 435 minecraft:black_concrete
fill 557 240 456 557 256 456 minecraft:black_concrete
fill 558 240 438 558 256 438 minecraft:black_concrete
fill 518 241 438 518 258 438 minecraft:black_concrete
fill 519 241 435 519 252 435 minecraft:black_concrete
setblock 520 241 419 minecraft:light[level=12]
setblock 520 241 427 minecraft:light[level=12]
setblock 520 241 430 minecraft:black_concrete
setblock 520 241 435 minecraft:light[level=12]
setblock 520 241 443 minecraft:light[level=12]
fill 522 241 454 524 241 454 minecraft:black_concrete
setblock 528 241 419 minecraft:light[level=12]
setblock 528 241 427 minecraft:light[level=12]
setblock 528 241 435 minecraft:light[level=12]
setblock 528 241 443 minecraft:light[level=12]
setblock 528 241 451 minecraft:light[level=12]
fill 535 241 456 535 253 456 minecraft:black_concrete
setblock 536 241 419 minecraft:light[level=12]
setblock 536 241 427 minecraft:light[level=12]
setblock 536 241 435 minecraft:light[level=12]
setblock 536 241 443 minecraft:light[level=12]
setblock 536 241 451 minecraft:light[level=12]
fill 539 241 417 539 258 417 minecraft:black_concrete
fill 539 241 455 540 241 455 minecraft:black_concrete
fill 542 241 417 543 242 417 minecraft:black_concrete
setblock 544 241 419 minecraft:light[level=12]
setblock 544 241 427 minecraft:light[level=12]
setblock 544 241 435 minecraft:light[level=12]
setblock 544 241 443 minecraft:light[level=12]
setblock 544 241 451 minecraft:light[level=12]
setblock 552 241 419 minecraft:light[level=12]
setblock 552 241 427 minecraft:light[level=12]
setblock 552 241 435 minecraft:light[level=12]
setblock 552 241 443 minecraft:light[level=12]
setblock 552 241 451 minecraft:light[level=12]
fill 554 241 457 554 273 457 minecraft:black_concrete
fill 556 241 426 556 241 429 minecraft:black_concrete
fill 556 241 456 556 257 456 minecraft:black_concrete
fill 557 241 450 557 242 453 minecraft:black_concrete
fill 558 241 446 558 241 451 minecraft:black_concrete
fill 519 242 417 519 242 419 minecraft:black_concrete
fill 519 242 426 519 242 428 minecraft:black_concrete
fill 520 242 417 521 242 418 minecraft:black_concrete
fill 521 242 450 521 242 451 minecraft:black_concrete
fill 522 242 417 522 254 417 minecraft:black_concrete
fill 522 242 454 523 242 454 minecraft:black_concrete
fill 544 242 457 544 243 457 minecraft:black_concrete
fill 553 242 417 553 266 417 minecraft:black_concrete
fill 556 242 418 556 258 418 minecraft:black_concrete
fill 556 242 427 556 242 429 minecraft:black_concrete
fill 558 242 447 558 242 451 minecraft:black_concrete
fill 518 243 439 518 259 439 minecraft:black_concrete
fill 519 243 417 520 243 418 minecraft:black_concrete
setblock 519 243 428 minecraft:black_concrete
setblock 519 243 447 minecraft:black_concrete
fill 520 243 449 520 243 451 minecraft:black_concrete
fill 521 243 417 521 255 417 minecraft:black_concrete
fill 522 243 454 522 243 455 minecraft:black_concrete
fill 523 243 455 525 243 455 minecraft:black_concrete
fill 541 243 456 541 244 456 minecraft:black_concrete
fill 542 243 417 542 258 417 minecraft:black_concrete
fill 553 243 457 553 273 457 minecraft:black_concrete
fill 555 243 456 555 257 456 minecraft:black_concrete
fill 557 243 451 557 244 453 minecraft:black_concrete
fill 558 243 448 558 244 451 minecraft:black_concrete
fill 518 244 417 518 244 422 minecraft:black_concrete
fill 518 244 425 518 244 430 minecraft:black_concrete
fill 518 244 440 518 260 440 minecraft:black_concrete
fill 519 244 417 519 254 418 minecraft:black_concrete
setblock 519 244 431 minecraft:black_concrete
fill 520 244 417 520 255 417 minecraft:black_concrete
fill 520 244 426 520 253 426 minecraft:black_concrete
fill 520 244 450 520 244 451 minecraft:black_concrete
fill 521 244 453 521 244 454 minecraft:black_concrete
fill 521 244 456 526 244 456 minecraft:black_concrete
fill 522 244 455 524 244 455 minecraft:black_concrete
fill 538 244 417 538 258 417 minecraft:black_concrete
fill 552 244 417 552 268 417 minecraft:black_concrete
fill 555 244 418 555 259 418 minecraft:black_concrete
fill 557 244 425 558 244 429 minecraft:black_concrete
fill 557 244 436 557 253 436 minecraft:black_concrete
fill 558 244 422 558 258 424 minecraft:black_concrete
fill 518 245 417 518 256 421 minecraft:black_concrete
fill 518 245 427 518 245 430 minecraft:black_concrete
fill 518 245 441 518 273 441 minecraft:black_concrete
fill 519 245 436 519 253 436 minecraft:black_concrete
setblock 520 245 451 minecraft:black_concrete
fill 521 245 456 525 246 456 minecraft:black_concrete
fill 522 245 455 523 245 455 minecraft:black_concrete
fill 537 245 417 537 258 417 minecraft:black_concrete
fill 551 245 417 551 269 417 minecraft:black_concrete
fill 552 245 457 552 273 457 minecraft:black_concrete
fill 554 245 418 554 260 418 minecraft:black_concrete
fill 554 245 456 554 258 456 minecraft:black_concrete
fill 557 245 427 558 245 429 minecraft:black_concrete
fill 557 245 452 557 254 453 minecraft:black_concrete
fill 558 245 425 558 255 426 minecraft:black_concrete
fill 558 245 439 558 257 439 minecraft:black_concrete
fill 558 245 449 558 257 451 minecraft:black_concrete
fill 518 246 429 518 246 430 minecraft:black_concrete
fill 518 246 442 518 272 444 minecraft:black_concrete
fill 519 246 437 519 254 437 minecraft:black_concrete
fill 519 246 449 519 253 450 minecraft:black_concrete
fill 522 246 455 522 247 455 minecraft:black_concrete
fill 534 246 456 534 254 456 minecraft:black_concrete
fill 535 246 417 536 259 417 minecraft:black_concrete
fill 538 246 456 539 249 456 minecraft:black_concrete
fill 543 246 417 543 273 417 minecraft:black_concrete
fill 550 246 417 550 270 417 minecraft:black_concrete
fill 551 246 452 551 255 452 minecraft:black_concrete
fill 551 246 457 551 273 457 minecraft:black_concrete
fill 553 246 418 553 261 418 minecraft:black_concrete
fill 556 246 455 556 254 455 minecraft:black_concrete
fill 557 246 428 558 246 429 minecraft:black_concrete
fill 558 246 427 558 253 427 minecraft:black_concrete
fill 518 247 430 518 248 430 minecraft:black_concrete
fill 519 247 438 519 255 438 minecraft:black_concrete
fill 521 247 456 524 250 456 minecraft:black_concrete
fill 533 247 456 533 254 456 minecraft:black_concrete
fill 534 247 417 534 260 417 minecraft:black_concrete
fill 544 247 417 544 273 417 minecraft:black_concrete
fill 548 247 417 549 272 417 minecraft:black_concrete
fill 550 247 457 550 273 457 minecraft:black_concrete
fill 552 247 418 552 263 418 minecraft:black_concrete
fill 553 247 456 553 258 456 minecraft:black_concrete
fill 556 247 419 556 257 419 minecraft:black_concrete
fill 557 247 422 557 258 422 minecraft:black_concrete
fill 557 247 437 557 254 437 minecraft:black_concrete
fill 558 247 428 558 252 429 minecraft:black_concrete
fill 558 247 440 558 257 440 minecraft:black_concrete
fill 518 248 422 518 256 422 minecraft:black_concrete
fill 519 248 419 519 254 419 minecraft:black_concrete
fill 519 248 439 519 256 440 minecraft:black_concrete
fill 520 248 418 520 253 418 minecraft:black_concrete
fill 520 248 453 520 249 455 minecraft:black_concrete
fill 523 248 417 523 254 417 minecraft:black_concrete
fill 532 248 417 533 260 417 minecraft:black_concrete
fill 532 248 456 532 254 456 minecraft:black_concrete
fill 537 248 418 539 256 418 minecraft:black_concrete
fill 545 248 417 547 273 417 minecraft:black_concrete
fill 549 248 457 549 273 457 minecraft:black_concrete
fill 550 248 418 551 265 418 minecraft:black_concrete
fill 552 248 456 552 258 456 minecraft:black_concrete
fill 554 248 419 555 258 419 minecraft:black_concrete
fill 555 248 455 555 254 455 minecraft:black_concrete
fill 556 248 420 556 257 420 minecraft:black_concrete
fill 556 248 454 556 253 454 minecraft:black_concrete
fill 557 248 423 557 257 423 minecraft:black_concrete
fill 557 248 438 557 255 438 minecraft:black_concrete
fill 558 248 441 558 258 442 minecraft:black_concrete
fill 519 249 426 519 253 426 minecraft:black_concrete
fill 519 249 441 519 258 443 minecraft:black_concrete
setblock 520 249 419 minecraft:light[level=12]
fill 520 249 425 520 253 425 minecraft:black_concrete
fill 520 249 427 520 253 427 minecraft:black_concrete
setblock 520 249 435 minecraft:light[level=12]
setblock 520 249 443 minecraft:light[level=12]
setblock 520 249 451 minecraft:light[level=12]
fill 521 249 426 521 253 426 minecraft:black_concrete
setblock 528 249 419 minecraft:light[level=12]
setblock 528 249 427 minecraft:light[level=12]
setblock 528 249 435 minecraft:light[level=12]
setblock 528 249 443 minecraft:light[level=12]
setblock 528 249 451 minecraft:light[level=12]
fill 531 249 417 531 269 417 minecraft:black_concrete
fill 531 249 456 531 254 456 minecraft:black_concrete
fill 534 249 418 536 258 418 minecraft:black_concrete
setblock 536 249 419 minecraft:light[level=12]
setblock 536 249 427 minecraft:light[level=12]
setblock 536 249 435 minecraft:light[level=12]
setblock 536 249 443 minecraft:light[level=12]
setblock 536 249 451 minecraft:light[level=12]
fill 540 249 418 541 256 418 minecraft:black_concrete
setblock 544 249 419 minecraft:light[level=12]
setblock 544 249 427 minecraft:light[level=12]
setblock 544 249 435 minecraft:light[level=12]
setblock 544 249 443 minecraft:light[level=12]
setblock 544 249 451 minecraft:light[level=12]
fill 548 249 418 549 268 418 minecraft:black_concrete
fill 548 249 457 548 273 457 minecraft:black_concrete
fill 551 249 456 551 258 456 minecraft:black_concrete
fill 552 249 419 553 259 419 minecraft:black_concrete
setblock 552 249 427 minecraft:light[level=12]
setblock 552 249 435 minecraft:light[level=12]
setblock 552 249 443 minecraft:light[level=12]
setblock 552 249 451 minecraft:light[level=12]
fill 554 249 455 554 255 455 minecraft:black_concrete
fill 556 249 421 556 257 421 minecraft:black_concrete
fill 557 249 424 557 256 424 minecraft:black_concrete
setblock 557 249 431 minecraft:black_concrete
fill 557 249 439 557 255 440 minecraft:black_concrete
fill 557 249 451 557 253 451 minecraft:black_concrete
fill 558 249 443 558 273 444 minecraft:black_concrete
fill 558 249 448 558 273 448 minecraft:black_concrete
fill 518 250 423 518 256 423 minecraft:black_concrete
fill 519 250 444 519 269 446 minecraft:black_concrete
fill 519 250 448 519 255 448 minecraft:black_concrete
fill 520 250 454 520 250 455 minecraft:black_concrete
fill 524 250 417 524 254 417 minecraft:black_concrete
fill 529 250 417 530 270 417 minecraft:black_concrete
fill 530 250 456 530 253 456 minecraft:black_concrete
fill 532 250 418 533 259 418 minecraft:black_concrete
fill 538 250 456 538 251 456 minecraft:black_concrete
fill 542 250 418 543 256 418 minecraft:black_concrete
fill 543 250 457 543 251 457 minecraft:black_concrete
fill 545 250 418 547 270 418 minecraft:black_concrete
fill 547 250 457 547 273 457 minecraft:black_concrete
fill 550 250 419 551 261 419 minecraft:black_concrete
fill 550 250 452 550 255 452 minecraft:black_concrete
fill 550 250 456 550 257 456 minecraft:black_concrete
fill 551 250 451 551 255 451 minecraft:black_concrete
fill 551 250 453 551 255 453 minecraft:black_concrete
fill 552 250 447 552 265 447 minecraft:white_wool
fill 552 250 452 552 255 452 minecraft:black_concrete
fill 554 250 420 555 256 420 minecraft:black_concrete
fill 556 250 422 556 256 422 minecraft:black_concrete
fill 557 250 441 557 256 441 minecraft:black_concrete
fill 558 250 445 558 273 447 minecraft:black_concrete
fill 519 251 420 519 253 420 minecraft:black_concrete
fill 519 251 425 519 253 425 minecraft:black_concrete
fill 519 251 427 519 253 427 minecraft:black_concrete
fill 519 251 447 519 257 447 minecraft:black_concrete
setblock 520 251 455 minecraft:black_concrete
fill 521 251 425 521 253 425 minecraft:black_concrete
fill 521 251 427 521 253 427 minecraft:black_concrete
fill 521 251 456 523 251 456 minecraft:black_concrete
fill 525 251 417 528 257 417 minecraft:black_concrete
fill 526 251 418 526 257 418 minecraft:black_concrete
fill 531 251 418 531 259 418 minecraft:black_concrete
fill 534 251 419 538 255 419 minecraft:black_concrete
fill 544 251 418 544 258 418 minecraft:black_concrete
fill 545 251 457 546 253 457 minecraft:black_concrete
fill 548 251 419 549 264 419 minecraft:black_concrete
fill 552 251 420 553 257 420 minecraft:black_concrete
fill 553 251 455 553 254 455 minecraft:black_concrete
fill 555 251 421 555 256 421 minecraft:black_concrete
fill 556 251 423 556 255 423 minecraft:black_concrete
fill 556 251 437 556 252 438 minecraft:black_concrete
fill 557 251 425 557 254 425 minecraft:black_concrete
fill 557 251 442 557 257 443 minecraft:black_concrete
fill 518 252 424 518 254 424 minecraft:black_concrete
fill 520 252 439 520 253 442 minecraft:black_concrete
fill 521 252 456 522 252 456 minecraft:black_concrete
fill 530 252 418 530 258 418 minecraft:black_concrete
fill 533 252 419 533 257 419 minecraft:black_concrete
fill 539 252 419 539 254 419 minecraft:black_concrete
fill 547 252 419 547 267 419 minecraft:black_concrete
fill 549 252 456 549 255 456 minecraft:black_concrete
fill 550 252 420 551 258 420 minecraft:black_concrete
fill 550 252 451 550 255 451 minecraft:black_concrete
fill 550 252 453 550 255 453 minecraft:black_concrete
fill 552 252 451 552 255 451 minecraft:black_concrete
fill 552 252 453 552 255 453 minecraft:black_concrete
fill 555 252 422 555 255 422 minecraft:black_concrete
fill 556 252 439 556 253 440 minecraft:black_concrete
fill 557 252 444 557 257 445 minecraft:black_concrete
setblock 521 253 456 minecraft:black_concrete
fill 529 253 418 529 257 418 minecraft:black_concrete
fill 532 253 419 532 257 419 minecraft:black_concrete
setblock 540 253 419 minecraft:black_concrete
fill 540 253 457 541 253 457 minecraft:black_concrete
fill 546 253 419 546 258 419 minecraft:black_concrete
fill 549 253 420 549 258 420 minecraft:black_concrete
setblock 552 253 455 minecraft:black_concrete
setblock 556 253 424 minecraft:black_concrete
fill 556 253 441 556 254 441 minecraft:black_concrete
fill 557 253 446 557 257 446 minecraft:black_concrete
setblock 518 254 434 minecraft:black_concrete
setblock 519 254 454 minecraft:black_concrete
fill 520 254 440 520 254 443 minecraft:black_concrete
fill 525 254 418 525 257 418 minecraft:black_concrete
fill 526 254 419 526 257 419 minecraft:black_concrete
fill 527 254 418 528 255 418 minecraft:black_concrete
fill 531 254 419 531 256 419 minecraft:black_concrete
fill 545 254 419 545 256 419 minecraft:black_concrete
fill 546 254 457 546 255 457 minecraft:black_concrete
fill 557 254 447 557 255 447 minecraft:black_concrete
fill 519 255 417 519 256 417 minecraft:black_concrete
fill 519 255 457 522 255 457 minecraft:black_concrete
setblock 520 255 442 minecraft:black_concrete
fill 525 255 419 525 257 419 minecraft:black_concrete
fill 527 255 419 527 257 419 minecraft:black_concrete
fill 527 255 457 530 255 457 minecraft:black_concrete
setblock 537 255 457 minecraft:black_concrete
fill 548 255 420 548 257 420 minecraft:black_concrete
setblock 549 255 452 minecraft:black_concrete
setblock 551 255 450 minecraft:black_concrete
setblock 551 255 454 minecraft:black_concrete
setblock 553 255 452 minecraft:black_concrete
setblock 557 255 453 minecraft:black_concrete
setblock 519 256 457 minecraft:black_concrete
fill 527 256 418 527 257 418 minecraft:black_concrete
fill 528 256 457 530 256 457 minecraft:black_concrete
fill 534 256 419 537 256 419 minecraft:black_concrete
setblock 535 256 457 minecraft:black_concrete
setblock 557 256 440 minecraft:black_concrete
setblock 557 256 455 minecraft:black_concrete
setblock 558 256 425 minecraft:black_concrete
fill 518 257 418 518 257 421 minecraft:black_concrete
fill 518 257 445 518 257 451 minecraft:black_concrete
setblock 518 257 457 minecraft:black_concrete
setblock 519 257 440 minecraft:black_concrete
setblock 520 257 419 minecraft:light[level=12]
setblock 520 257 427 minecraft:light[level=12]
setblock 520 257 435 minecraft:light[level=12]
setblock 520 257 443 minecraft:light[level=12]
setblock 520 257 451 minecraft:light[level=12]
setblock 524 257 418 minecraft:black_concrete
setblock 526 257 420 minecraft:black_concrete
setblock 528 257 418 minecraft:black_concrete
setblock 528 257 419 minecraft:light[level=12]
setblock 528 257 427 minecraft:light[level=12]
setblock 528 257 435 minecraft:light[level=12]
setblock 528 257 443 minecraft:light[level=12]
setblock 528 257 451 minecraft:light[level=12]
setblock 530 257 457 minecraft:black_concrete
setblock 534 257 419 minecraft:black_concrete
setblock 536 257 419 minecraft:light[level=12]
setblock 536 257 427 minecraft:light[level=12]
setblock 536 257 435 minecraft:light[level=12]
setblock 536 257 443 minecraft:light[level=12]
setblock 536 257 451 minecraft:light[level=12]
fill 537 257 418 538 257 418 minecraft:black_concrete
setblock 543 257 418 minecraft:black_concrete
setblock 544 257 419 minecraft:light[level=12]
setblock 544 257 427 minecraft:light[level=12]
setblock 544 257 435 minecraft:light[level=12]
setblock 544 257 443 minecraft:light[level=12]
setblock 544 257 451 minecraft:light[level=12]
setblock 552 257 427 minecraft:light[level=12]
setblock 552 257 435 minecraft:light[level=12]
setblock 552 257 443 minecraft:light[level=12]
setblock 552 257 451 minecraft:light[level=12]
setblock 554 257 420 minecraft:black_concrete
fill 518 258 445 518 272 450 minecraft:black_concrete
fill 528 258 417 528 259 417 minecraft:black_concrete
setblock 552 258 420 minecraft:black_concrete
setblock 557 258 445 minecraft:black_concrete
fill 558 258 449 558 273 450 minecraft:black_concrete
fill 558 258 456 558 258 457 minecraft:black_concrete
fill 519 259 442 519 259 443 minecraft:black_concrete
setblock 550 259 420 minecraft:black_concrete
setblock 554 259 419 minecraft:black_concrete
fill 558 259 422 558 259 423 minecraft:black_concrete
setblock 558 259 442 minecraft:black_concrete
setblock 519 260 443 minecraft:black_concrete
setblock 552 260 419 minecraft:black_concrete
setblock 532 261 417 minecraft:black_concrete
fill 558 261 451 558 273 451 minecraft:black_concrete
fill 518 262 451 518 273 451 minecraft:black_concrete
fill 519 262 447 519 271 447 minecraft:black_concrete
fill 546 262 457 546 273 457 minecraft:black_concrete
setblock 550 262 419 minecraft:black_concrete
fill 550 262 456 550 273 456 minecraft:black_concrete
fill 557 262 447 557 270 448 minecraft:black_concrete
fill 558 262 452 558 273 452 minecraft:black_concrete
fill 519 263 448 519 271 448 minecraft:black_concrete
fill 528 263 417 528 273 417 minecraft:black_concrete
fill 542 263 417 542 273 417 minecraft:black_concrete
fill 544 263 418 544 273 418 minecraft:black_concrete
fill 545 263 457 545 273 457 minecraft:black_concrete
fill 546 263 419 546 268 419 minecraft:black_concrete
fill 548 263 456 549 273 456 minecraft:black_concrete
fill 551 263 456 551 273 456 minecraft:black_concrete
fill 557 263 446 557 269 446 minecraft:black_concrete
fill 557 263 449 557 273 450 minecraft:black_concrete
fill 558 263 453 558 273 453 minecraft:black_concrete
fill 518 264 452 518 273 452 minecraft:black_concrete
fill 519 264 443 519 268 443 minecraft:black_concrete
fill 519 264 449 519 272 450 minecraft:black_concrete
fill 527 264 417 527 273 417 minecraft:black_concrete
fill 541 264 417 541 273 417 minecraft:black_concrete
fill 543 264 418 543 273 418 minecraft:black_concrete
fill 544 264 457 544 273 457 minecraft:black_concrete
fill 546 264 456 547 273 456 minecraft:black_concrete
fill 552 264 456 552 273 456 minecraft:black_concrete
fill 555 264 457 555 273 457 minecraft:black_concrete
fill 557 264 445 557 267 445 minecraft:black_concrete
fill 557 264 451 557 273 451 minecraft:black_concrete
fill 558 264 454 558 273 454 minecraft:black_concrete
fill 518 265 425 518 271 431 minecraft:black_concrete
fill 518 265 440 518 273 440 minecraft:black_concrete
fill 518 265 453 518 273 453 minecraft:black_concrete
fill 519 265 451 519 273 451 minecraft:black_concrete
setblock 520 265 419 minecraft:light[level=12]
setblock 520 265 427 minecraft:light[level=12]
setblock 520 265 435 minecraft:light[level=12]
setblock 520 265 443 minecraft:light[level=12]
setblock 520 265 451 minecraft:light[level=12]
fill 526 265 417 526 273 417 minecraft:black_concrete
setblock 528 265 419 minecraft:light[level=12]
setblock 528 265 427 minecraft:light[level=12]
setblock 528 265 435 minecraft:light[level=12]
setblock 528 265 443 minecraft:light[level=12]
setblock 528 265 451 minecraft:light[level=12]
setblock 536 265 419 minecraft:light[level=12]
setblock 536 265 427 minecraft:light[level=12]
setblock 536 265 435 minecraft:light[level=12]
setblock 536 265 443 minecraft:light[level=12]
setblock 536 265 451 minecraft:light[level=12]
fill 540 265 417 540 273 417 minecraft:black_concrete
fill 543 265 457 543 273 457 minecraft:black_concrete
setblock 544 265 419 minecraft:light[level=12]
setblock 544 265 427 minecraft:light[level=12]
setblock 544 265 435 minecraft:light[level=12]
setblock 544 265 443 minecraft:light[level=12]
setblock 544 265 451 minecraft:light[level=12]
fill 545 265 419 545 268 419 minecraft:black_concrete
fill 545 265 456 545 273 456 minecraft:black_concrete
fill 547 265 455 550 272 455 minecraft:black_concrete
fill 548 265 419 548 266 419 minecraft:black_concrete
setblock 552 265 419 minecraft:light[level=12]
setblock 552 265 427 minecraft:light[level=12]
setblock 552 265 435 minecraft:light[level=12]
setblock 552 265 443 minecraft:light[level=12]
setblock 552 265 451 minecraft:light[level=12]
fill 553 265 456 553 272 456 minecraft:black_concrete
fill 557 265 452 557 273 453 minecraft:black_concrete
fill 558 265 455 558 273 455 minecraft:black_concrete
fill 518 266 432 518 273 434 minecraft:black_concrete
fill 518 266 454 518 273 454 minecraft:black_concrete
fill 519 266 428 519 273 430 minecraft:black_concrete
fill 519 266 452 519 273 452 minecraft:black_concrete
fill 520 266 446 520 267 449 minecraft:black_concrete
fill 525 266 417 525 273 417 minecraft:black_concrete
fill 525 266 457 528 273 457 minecraft:black_concrete
fill 539 266 417 539 273 417 minecraft:black_concrete
fill 541 266 457 542 273 457 minecraft:black_concrete
fill 542 266 418 542 273 418 minecraft:black_concrete
fill 543 266 456 544 273 456 minecraft:black_concrete
fill 545 266 455 546 273 455 minecraft:black_concrete
fill 550 266 418 550 267 418 minecraft:black_concrete
fill 551 266 455 551 271 455 minecraft:black_concrete
fill 556 266 449 556 268 450 minecraft:black_concrete
fill 556 266 457 556 273 457 minecraft:black_concrete
fill 557 266 454 557 273 454 minecraft:black_concrete
fill 558 266 442 558 269 442 minecraft:black_concrete
fill 558 266 456 558 273 456 minecraft:black_concrete
fill 518 267 435 518 273 439 minecraft:black_concrete
fill 518 267 455 518 273 455 minecraft:black_concrete
fill 519 267 426 519 270 427 minecraft:black_concrete
fill 519 267 431 519 273 433 minecraft:black_concrete
fill 519 267 453 519 273 453 minecraft:black_concrete
fill 520 267 450 520 269 450 minecraft:black_concrete
fill 523 267 457 524 273 457 minecraft:black_concrete
fill 524 267 417 524 273 417 minecraft:black_concrete
fill 529 267 457 529 271 457 minecraft:black_concrete
fill 540 267 457 540 273 457 minecraft:black_concrete
fill 541 267 418 541 273 418 minecraft:black_concrete
fill 542 267 456 542 273 456 minecraft:black_concrete
setblock 544 267 419 minecraft:black_concrete
fill 544 267 455 544 273 455 minecraft:black_concrete
fill 546 267 454 549 270 454 minecraft:black_concrete
fill 552 267 455 552 269 455 minecraft:black_concrete
fill 554 267 456 554 271 456 minecraft:black_concrete
setblock 556 267 448 minecraft:black_concrete
fill 556 267 451 556 270 451 minecraft:black_concrete
fill 557 267 457 558 273 457 minecraft:black_concrete
fill 558 267 427 558 269 430 minecraft:black_concrete
fill 519 268 434 519 273 435 minecraft:black_concrete
fill 520 268 428 520 272 433 minecraft:black_concrete
fill 520 268 447 520 268 449 minecraft:black_concrete
fill 520 268 451 520 269 451 minecraft:black_concrete
fill 522 268 457 522 273 457 minecraft:black_concrete
fill 525 268 456 526 271 456 minecraft:black_concrete
fill 538 268 417 538 273 417 minecraft:black_concrete
fill 539 268 457 539 273 457 minecraft:black_concrete
fill 541 268 456 541 273 456 minecraft:black_concrete
fill 543 268 455 543 273 455 minecraft:black_concrete
fill 545 268 454 545 273 454 minecraft:black_concrete
fill 556 268 452 556 269 452 minecraft:black_concrete
fill 557 268 455 557 273 455 minecraft:black_concrete
fill 558 268 431 558 273 432 minecraft:black_concrete
fill 518 269 456 518 273 456 minecraft:black_concrete
fill 519 269 436 519 273 437 minecraft:black_concrete
fill 519 269 454 519 272 454 minecraft:black_concrete
setblock 520 269 427 minecraft:black_concrete
fill 520 269 434 520 273 434 minecraft:black_concrete
fill 520 269 448 520 269 449 minecraft:black_concrete
fill 520 269 457 521 273 457 minecraft:black_concrete
fill 521 269 430 521 272 431 minecraft:black_concrete
fill 523 269 417 523 273 417 minecraft:black_concrete
fill 523 269 456 524 273 456 minecraft:black_concrete
fill 537 269 417 537 273 417 minecraft:black_concrete
fill 538 269 457 538 273 457 minecraft:black_concrete
fill 540 269 456 540 273 456 minecraft:black_concrete
fill 542 269 455 542 273 455 minecraft:black_concrete
fill 544 269 454 544 273 454 minecraft:black_concrete
setblock 548 269 418 minecraft:black_concrete
setblock 555 269 456 minecraft:black_concrete
setblock 556 269 450 minecraft:black_concrete
fill 557 269 425 557 270 425 minecraft:black_concrete
fill 558 269 433 558 273 434 minecraft:black_concrete
fill 518 270 421 519 271 421 minecraft:black_concrete
fill 519 270 425 556 270 425 minecraft:black_concrete
fill 519 270 438 519 273 438 minecraft:black_concrete
fill 519 270 441 558 270 441 minecraft:black_concrete
fill 519 270 445 519 270 446 minecraft:black_concrete
fill 520 270 435 520 273 435 minecraft:black_concrete
fill 520 270 445 520 271 445 minecraft:black_concrete
fill 520 270 453 556 270 453 minecraft:black_concrete
fill 521 270 429 521 271 429 minecraft:black_concrete
fill 521 270 432 521 273 433 minecraft:black_concrete
fill 522 270 456 522 273 456 minecraft:black_concrete
fill 537 270 457 537 273 457 minecraft:black_concrete
fill 539 270 456 539 273 456 minecraft:black_concrete
fill 540 270 418 540 273 418 minecraft:black_concrete
fill 541 270 455 541 273 455 minecraft:black_concrete
fill 543 270 454 543 273 454 minecraft:black_concrete
fill 557 270 456 557 273 456 minecraft:black_concrete
fill 558 270 428 558 271 430 minecraft:black_concrete
fill 558 270 435 558 273 436 minecraft:black_concrete
setblock 519 271 425 minecraft:black_concrete
fill 519 271 427 519 273 427 minecraft:black_concrete
fill 519 271 441 524 271 441 minecraft:black_concrete
setblock 519 271 445 minecraft:black_concrete
fill 519 271 457 519 273 457 minecraft:black_concrete
fill 520 271 421 556 271 421 minecraft:black_concrete
fill 520 271 436 520 271 437 minecraft:black_concrete
fill 520 271 449 556 271 449 minecraft:black_concrete
setblock 520 271 453 minecraft:black_concrete
fill 521 271 434 521 273 434 minecraft:black_concrete
fill 521 271 437 536 271 437 minecraft:black_concrete
fill 521 271 445 557 271 445 minecraft:black_concrete
fill 522 271 417 522 273 417 minecraft:black_concrete
fill 522 271 429 545 271 429 minecraft:black_concrete
fill 522 271 433 536 271 433 minecraft:black_concrete
setblock 529 271 417 minecraft:black_concrete
fill 534 271 456 534 272 456 minecraft:white_wool
fill 542 271 433 557 271 433 minecraft:black_concrete
fill 542 271 437 551 271 437 minecraft:black_concrete
fill 545 271 418 546 272 418 minecraft:black_concrete
fill 546 271 454 548 271 454 minecraft:black_concrete
setblock 557 271 448 minecraft:black_concrete
fill 558 271 437 558 273 437 minecraft:black_concrete
fill 518 272 426 518 273 431 minecraft:black_concrete
fill 519 272 439 519 273 439 minecraft:black_concrete
fill 520 272 436 520 273 436 minecraft:black_concrete
setblock 525 272 456 minecraft:black_concrete
fill 526 272 418 526 272 456 minecraft:white_wool
fill 530 272 417 530 272 456 minecraft:white_wool
fill 534 272 417 534 272 455 minecraft:white_wool
fill 536 272 417 536 273 417 minecraft:black_concrete
fill 536 272 457 536 273 457 minecraft:black_concrete
fill 538 272 418 538 273 418 minecraft:white_wool
fill 538 272 456 538 273 456 minecraft:black_concrete
fill 540 272 455 540 273 455 minecraft:black_concrete
fill 544 272 429 558 272 429 minecraft:black_concrete
fill 546 272 419 546 272 428 minecraft:white_wool
fill 546 272 430 546 272 453 minecraft:white_wool
fill 546 272 454 547 272 454 minecraft:black_concrete
fill 549 272 437 557 272 437 minecraft:black_concrete
fill 550 272 417 550 273 417 minecraft:white_wool
fill 553 272 421 557 272 421 minecraft:black_concrete
fill 554 272 417 554 273 418 minecraft:white_wool
fill 555 272 449 556 272 449 minecraft:black_concrete
fill 558 272 430 558 273 430 minecraft:black_concrete
fill 558 272 438 558 273 439 minecraft:black_concrete
fill 518 273 442 518 273 443 minecraft:black_concrete
fill 518 273 446 518 273 450 minecraft:black_concrete
setblock 518 273 457 minecraft:black_concrete
setblock 520 273 419 minecraft:light[level=12]
setblock 520 273 427 minecraft:light[level=12]
fill 520 273 429 520 273 433 minecraft:black_concrete
setblock 520 273 437 minecraft:black_concrete
setblock 520 273 443 minecraft:light[level=12]
setblock 520 273 451 minecraft:light[level=12]
setblock 521 273 417 minecraft:black_concrete
setblock 521 273 431 minecraft:black_concrete
fill 522 273 418 522 273 445 minecraft:white_wool
fill 526 273 418 526 273 423 minecraft:white_wool
setblock 528 273 419 minecraft:light[level=12]
setblock 528 273 427 minecraft:light[level=12]
setblock 528 273 435 minecraft:light[level=12]
setblock 528 273 443 minecraft:light[level=12]
setblock 528 273 451 minecraft:light[level=12]
fill 530 273 417 530 273 429 minecraft:white_wool
fill 534 273 417 534 273 418 minecraft:white_wool
setblock 535 273 457 minecraft:black_concrete
setblock 536 273 419 minecraft:light[level=12]
setblock 536 273 427 minecraft:light[level=12]
setblock 536 273 435 minecraft:light[level=12]
setblock 536 273 443 minecraft:light[level=12]
setblock 536 273 451 minecraft:light[level=12]
fill 538 273 419 538 273 432 minecraft:white_wool
fill 538 273 438 538 273 450 minecraft:white_wool
fill 542 273 419 542 273 434 minecraft:white_wool
fill 542 273 436 542 273 444 minecraft:white_wool
setblock 544 273 419 minecraft:light[level=12]
setblock 544 273 427 minecraft:light[level=12]
setblock 544 273 435 minecraft:light[level=12]
setblock 544 273 443 minecraft:light[level=12]
setblock 544 273 451 minecraft:light[level=12]
setblock 545 273 418 minecraft:black_concrete
fill 546 273 418 546 273 427 minecraft:white_wool
fill 547 273 455 549 273 455 minecraft:black_concrete
setblock 548 273 417 minecraft:black_concrete
fill 550 273 418 550 273 445 minecraft:white_wool
setblock 552 273 419 minecraft:light[level=12]
setblock 552 273 427 minecraft:light[level=12]
setblock 552 273 435 minecraft:light[level=12]
setblock 552 273 443 minecraft:light[level=12]
setblock 552 273 451 minecraft:light[level=12]
fill 554 273 419 554 273 452 minecraft:white_wool
setblock 558 273 429 minecraft:black_concrete
fill 558 273 440 558 273 441 minecraft:black_concrete
fill 523 279 435 526 280 435 minecraft:white_wool
fill 524 279 430 524 280 433 minecraft:black_concrete
fill 524 279 434 528 280 434 minecraft:white_wool
fill 524 279 436 524 280 438 minecraft:white_wool
fill 524 279 439 528 280 440 minecraft:black_concrete
fill 525 279 428 526 280 432 minecraft:black_concrete
fill 525 279 433 530 280 433 minecraft:white_wool
fill 525 279 436 525 280 437 minecraft:white_wool
fill 525 279 438 529 280 438 minecraft:black_concrete
fill 525 279 441 527 280 442 minecraft:black_concrete
fill 526 279 426 536 280 426 minecraft:white_wool
fill 526 279 427 533 280 427 minecraft:black_concrete
fill 526 279 436 530 280 437 minecraft:black_concrete
fill 526 279 443 527 280 444 minecraft:black_concrete
fill 527 279 425 534 280 425 minecraft:white_wool
fill 527 279 428 528 280 431 minecraft:black_concrete
fill 527 279 432 536 280 432 minecraft:white_wool
fill 527 279 435 533 280 435 minecraft:black_concrete
fill 527 279 445 527 280 445 minecraft:black_concrete
fill 528 279 424 532 280 424 minecraft:white_wool
fill 528 279 441 528 280 441 minecraft:black_concrete
fill 528 279 442 530 280 446 minecraft:white_wool
fill 529 279 423 539 280 423 minecraft:black_concrete
fill 529 279 428 535 280 430 minecraft:black_concrete
fill 529 279 431 534 280 431 minecraft:white_wool
fill 529 279 434 536 279 434 minecraft:black_concrete
fill 529 279 439 529 280 439 minecraft:black_concrete
fill 529 279 440 530 280 441 minecraft:white_wool
fill 529 279 447 530 280 447 minecraft:white_wool
fill 530 279 422 538 280 422 minecraft:black_concrete
fill 530 279 438 531 280 439 minecraft:white_wool
fill 530 279 448 530 280 448 minecraft:white_wool
fill 531 279 433 535 280 433 minecraft:black_concrete
fill 531 279 436 531 280 436 minecraft:black_concrete
fill 531 279 437 533 280 437 minecraft:white_wool
fill 531 279 440 531 280 440 minecraft:white_wool
fill 531 279 441 534 280 448 minecraft:black_concrete
fill 532 279 421 536 280 421 minecraft:black_concrete
fill 532 279 436 534 280 436 minecraft:white_wool
fill 532 279 438 532 280 438 minecraft:white_wool
fill 532 279 439 534 280 440 minecraft:black_concrete
fill 532 279 449 536 280 449 minecraft:black_concrete
fill 533 279 424 539 280 424 minecraft:black_concrete
fill 533 279 438 535 280 438 minecraft:black_concrete
fill 534 279 420 535 280 420 minecraft:black_concrete
fill 534 279 427 537 280 427 minecraft:white_wool
fill 534 279 435 536 279 435 minecraft:white_wool
fill 534 279 437 536 279 437 minecraft:black_concrete
fill 534 279 450 537 280 450 minecraft:black_concrete
fill 535 279 425 540 280 425 minecraft:black_concrete
fill 535 279 431 538 280 431 minecraft:black_concrete
fill 535 279 436 536 279 436 minecraft:black_concrete
fill 535 279 439 535 280 439 minecraft:black_concrete
fill 535 279 440 536 280 445 minecraft:white_wool
fill 535 279 446 535 280 448 minecraft:black_concrete
fill 536 279 420 540 280 420 minecraft:white_wool
fill 536 279 428 538 280 428 minecraft:white_wool
fill 536 279 429 536 280 430 minecraft:black_concrete
fill 536 279 433 537 279 433 minecraft:white_wool
fill 536 279 438 536 280 439 minecraft:white_wool
fill 536 279 446 538 280 447 minecraft:white_wool
fill 536 279 448 536 280 448 minecraft:black_concrete
fill 537 279 421 541 280 421 minecraft:white_wool
fill 537 279 426 540 280 426 minecraft:black_concrete
fill 537 279 429 538 280 429 minecraft:white_wool
fill 537 279 430 537 280 430 minecraft:black_concrete
fill 537 279 432 538 279 432 minecraft:black_concrete
fill 537 279 437 537 279 438 minecraft:white_wool
fill 537 279 439 538 280 443 minecraft:black_concrete
fill 537 279 444 537 280 445 minecraft:white_wool
fill 537 279 448 539 280 449 minecraft:white_wool
fill 538 279 427 541 280 427 minecraft:black_concrete
fill 538 279 430 539 280 430 minecraft:white_wool
setblock 538 279 438 minecraft:black_concrete
fill 538 279 444 541 280 445 minecraft:black_concrete
fill 538 279 450 542 280 450 minecraft:white_wool
fill 539 279 419 539 280 419 minecraft:white_wool
fill 539 279 422 541 280 422 minecraft:white_wool
fill 539 279 428 541 280 429 minecraft:black_concrete
fill 539 279 431 539 279 432 minecraft:white_wool
fill 539 279 438 539 279 440 minecraft:white_wool
fill 539 279 441 539 280 443 minecraft:black_concrete
fill 539 279 446 545 280 447 minecraft:black_concrete
fill 539 279 451 539 280 451 minecraft:white_wool
fill 540 279 423 542 280 424 minecraft:white_wool
fill 540 279 430 540 279 432 minecraft:black_concrete
fill 540 279 438 541 279 439 minecraft:black_concrete
fill 540 279 440 540 280 442 minecraft:white_wool
fill 540 279 443 540 280 443 minecraft:black_concrete
fill 540 279 448 548 280 448 minecraft:black_concrete
fill 540 279 449 541 280 449 minecraft:white_wool
fill 541 279 420 544 280 420 minecraft:black_concrete
fill 541 279 425 543 280 426 minecraft:white_wool
fill 541 279 430 541 280 431 minecraft:black_concrete
fill 541 279 432 541 279 433 minecraft:white_wool
fill 541 279 437 542 279 437 minecraft:white_wool
fill 541 279 440 554 280 440 minecraft:black_concrete
fill 541 279 441 541 280 443 minecraft:white_wool
fill 542 279 421 546 280 422 minecraft:black_concrete
fill 542 279 427 542 280 432 minecraft:white_wool
fill 542 279 433 543 279 434 minecraft:black_concrete
fill 542 279 435 544 279 435 minecraft:white_wool
fill 542 279 436 549 279 436 minecraft:black_concrete
fill 542 279 438 551 280 438 minecraft:white_wool
fill 542 279 439 543 280 439 minecraft:black_concrete
fill 542 279 441 553 280 441 minecraft:black_concrete
fill 542 279 442 542 280 444 minecraft:white_wool
fill 542 279 445 543 280 445 minecraft:black_concrete
fill 542 279 449 546 280 449 minecraft:black_concrete
fill 543 279 423 547 280 424 minecraft:black_concrete
fill 543 279 427 543 280 430 minecraft:white_wool
fill 543 279 431 545 280 432 minecraft:black_concrete
fill 543 279 437 547 280 437 minecraft:black_concrete
fill 543 279 442 553 280 442 minecraft:black_concrete
fill 543 279 443 544 280 444 minecraft:white_wool
fill 543 279 450 544 280 450 minecraft:black_concrete
fill 544 279 425 546 280 430 minecraft:black_concrete
fill 544 279 433 544 280 433 minecraft:black_concrete
fill 544 279 434 546 280 434 minecraft:white_wool
fill 544 279 439 549 280 439 minecraft:white_wool
fill 544 279 445 551 280 445 minecraft:white_wool
fill 545 279 433 547 280 433 minecraft:white_wool
fill 545 279 435 551 280 435 minecraft:black_concrete
fill 545 279 443 552 280 443 minecraft:black_concrete
fill 545 279 444 552 280 444 minecraft:white_wool
fill 546 279 431 546 280 431 minecraft:black_concrete
fill 546 279 432 548 280 432 minecraft:white_wool
fill 546 279 446 550 280 446 minecraft:white_wool
fill 546 279 447 549 280 447 minecraft:black_concrete
fill 547 279 422 547 280 422 minecraft:black_concrete
fill 547 279 425 547 280 429 minecraft:black_concrete
fill 547 279 430 548 280 431 minecraft:white_wool
fill 547 279 434 552 280 434 minecraft:black_concrete
fill 548 279 422 548 280 429 minecraft:white_wool
fill 548 279 433 552 280 433 minecraft:black_concrete
fill 548 279 437 553 280 437 minecraft:white_wool
fill 549 279 423 549 280 430 minecraft:white_wool
fill 549 279 431 553 280 432 minecraft:black_concrete
fill 550 279 424 550 280 428 minecraft:white_wool
fill 550 279 429 553 280 430 minecraft:black_concrete
fill 550 279 436 554 280 436 minecraft:white_wool
fill 550 279 439 554 280 439 minecraft:black_concrete
fill 551 279 425 551 280 428 minecraft:black_concrete
fill 552 279 426 552 280 428 minecraft:black_concrete
fill 552 279 435 555 280 435 minecraft:white_wool
fill 552 279 438 554 280 438 minecraft:black_concrete
fill 553 279 428 553 280 428 minecraft:black_concrete
fill 553 279 433 554 280 434 minecraft:white_wool
fill 554 279 430 554 280 431 minecraft:black_concrete
fill 554 279 432 554 280 432 minecraft:white_wool
fill 554 279 437 554 280 437 minecraft:black_concrete
fill 518 280 417 522 280 457 minecraft:black_concrete
fill 523 280 417 523 280 434 minecraft:black_concrete
fill 523 280 436 523 280 457 minecraft:black_concrete
fill 524 280 417 524 280 429 minecraft:black_concrete
fill 524 280 441 524 280 457 minecraft:black_concrete
fill 525 280 417 525 280 427 minecraft:black_concrete
fill 525 280 443 525 280 457 minecraft:black_concrete
fill 526 280 417 526 280 425 minecraft:black_concrete
fill 526 280 445 526 280 457 minecraft:black_concrete
fill 527 280 417 527 280 424 minecraft:black_concrete
fill 527 280 446 527 280 457 minecraft:black_concrete
fill 528 280 417 528 280 423 minecraft:black_concrete
fill 528 280 447 528 280 457 minecraft:black_concrete
fill 529 280 417 529 280 422 minecraft:black_concrete
fill 529 280 434 535 280 434 minecraft:black_concrete
fill 529 280 448 529 280 457 minecraft:black_concrete
fill 530 280 417 531 280 421 minecraft:black_concrete
fill 530 280 449 531 280 457 minecraft:black_concrete
fill 532 280 417 533 280 420 minecraft:black_concrete
fill 532 280 450 533 280 457 minecraft:black_concrete
fill 534 280 417 538 280 419 minecraft:black_concrete
fill 534 280 435 535 280 435 minecraft:white_wool
fill 534 280 437 535 280 437 minecraft:black_concrete
fill 534 280 451 538 280 457 minecraft:black_concrete
setblock 535 280 436 minecraft:black_concrete
fill 536 280 433 536 280 437 minecraft:crying_obsidian
fill 537 280 432 537 280 433 minecraft:crying_obsidian
fill 537 280 437 537 280 438 minecraft:crying_obsidian
fill 538 280 432 541 280 432 minecraft:crying_obsidian
fill 538 280 438 541 280 438 minecraft:crying_obsidian
fill 539 280 417 558 280 418 minecraft:black_concrete
setblock 539 280 431 minecraft:white_wool
fill 539 280 439 539 280 440 minecraft:white_wool
fill 539 280 452 558 280 457 minecraft:black_concrete
fill 540 280 419 558 280 419 minecraft:black_concrete
fill 540 280 430 540 280 431 minecraft:black_concrete
fill 540 280 439 541 280 439 minecraft:black_concrete
fill 540 280 451 558 280 451 minecraft:black_concrete
fill 541 280 433 542 280 433 minecraft:crying_obsidian
fill 541 280 437 542 280 437 minecraft:crying_obsidian
fill 542 280 434 542 280 436 minecraft:crying_obsidian
fill 543 280 433 543 280 434 minecraft:black_concrete
fill 543 280 435 544 280 435 minecraft:white_wool
fill 543 280 436 549 280 436 minecraft:black_concrete
fill 545 280 420 558 280 420 minecraft:black_concrete
fill 545 280 450 558 280 450 minecraft:black_concrete
fill 547 280 421 558 280 421 minecraft:black_concrete
fill 547 280 449 558 280 449 minecraft:black_concrete
fill 549 280 422 558 280 422 minecraft:black_concrete
fill 549 280 448 558 280 448 minecraft:black_concrete
fill 550 280 423 558 280 423 minecraft:black_concrete
fill 550 280 447 558 280 447 minecraft:black_concrete
fill 551 280 424 558 280 424 minecraft:black_concrete
fill 551 280 446 558 280 446 minecraft:black_concrete
fill 552 280 425 558 280 425 minecraft:black_concrete
fill 552 280 445 558 280 445 minecraft:black_concrete
fill 553 280 426 558 280 427 minecraft:black_concrete
fill 553 280 443 558 280 444 minecraft:black_concrete
fill 554 280 428 558 280 429 minecraft:black_concrete
fill 554 280 441 558 280 442 minecraft:black_concrete
fill 555 280 430 558 280 434 minecraft:black_concrete
fill 555 280 436 558 280 440 minecraft:black_concrete
fill 556 280 435 558 280 435 minecraft:black_concrete
setblock 520 281 419 minecraft:light[level=12]
setblock 520 281 427 minecraft:light[level=12]
setblock 520 281 435 minecraft:light[level=12]
setblock 520 281 443 minecraft:light[level=12]
setblock 520 281 451 minecraft:light[level=12]
setblock 528 281 419 minecraft:light[level=12]
setblock 528 281 427 minecraft:light[level=12]
setblock 528 281 435 minecraft:light[level=12]
setblock 528 281 443 minecraft:light[level=12]
setblock 528 281 451 minecraft:light[level=12]
setblock 536 281 419 minecraft:light[level=12]
setblock 536 281 427 minecraft:light[level=12]
setblock 536 281 435 minecraft:light[level=12]
setblock 536 281 443 minecraft:light[level=12]
setblock 536 281 451 minecraft:light[level=12]
setblock 544 281 419 minecraft:light[level=12]
setblock 544 281 427 minecraft:light[level=12]
setblock 544 281 435 minecraft:light[level=12]
setblock 544 281 443 minecraft:light[level=12]
setblock 544 281 451 minecraft:light[level=12]
setblock 552 281 419 minecraft:light[level=12]
setblock 552 281 427 minecraft:light[level=12]
setblock 552 281 435 minecraft:light[level=12]
setblock 552 281 443 minecraft:light[level=12]
setblock 552 281 451 minecraft:light[level=12]
fill 518 284 417 518 284 450 minecraft:black_concrete
fill 518 284 453 518 284 457 minecraft:black_concrete
fill 519 284 417 519 284 446 minecraft:black_concrete
fill 519 284 457 524 284 457 minecraft:black_concrete
fill 520 284 417 520 284 426 minecraft:black_concrete
fill 520 284 434 520 284 442 minecraft:black_concrete
fill 521 284 417 542 284 419 minecraft:black_concrete
fill 527 284 457 558 284 457 minecraft:black_concrete
fill 532 284 423 532 295 423 minecraft:white_wool
fill 532 284 456 544 284 456 minecraft:black_concrete
fill 533 284 420 539 284 420 minecraft:black_concrete
fill 535 284 455 541 284 455 minecraft:black_concrete
fill 543 284 417 544 284 418 minecraft:black_concrete
fill 545 284 417 558 284 417 minecraft:black_concrete
fill 553 284 418 558 285 418 minecraft:black_concrete
fill 554 284 443 558 289 443 minecraft:black_concrete
fill 554 284 456 558 284 456 minecraft:black_concrete
fill 555 284 436 558 284 442 minecraft:black_concrete
fill 555 284 444 558 289 444 minecraft:black_concrete
fill 556 284 419 558 284 420 minecraft:black_concrete
fill 556 284 433 558 284 435 minecraft:black_concrete
fill 556 284 445 558 288 447 minecraft:black_concrete
fill 557 284 421 558 287 432 minecraft:black_concrete
fill 557 284 448 558 284 451 minecraft:black_concrete
fill 557 284 454 558 284 455 minecraft:black_concrete
fill 558 284 452 558 285 453 minecraft:black_concrete
fill 518 285 417 518 285 449 minecraft:black_concrete
fill 518 285 455 518 285 457 minecraft:black_concrete
fill 519 285 417 519 286 445 minecraft:black_concrete
fill 519 285 457 521 285 457 minecraft:black_concrete
fill 520 285 417 520 286 425 minecraft:black_concrete
fill 520 285 437 520 285 441 minecraft:black_concrete
fill 521 285 417 524 285 419 minecraft:black_concrete
fill 525 285 417 543 285 418 minecraft:black_concrete
fill 528 285 419 541 285 419 minecraft:black_concrete
fill 529 285 457 558 285 457 minecraft:black_concrete
fill 532 285 456 542 285 456 minecraft:black_concrete
fill 533 285 420 538 285 420 minecraft:black_concrete
fill 536 285 455 539 285 455 minecraft:black_concrete
fill 544 285 417 546 285 417 minecraft:black_concrete
fill 550 285 417 558 285 417 minecraft:black_concrete
fill 555 285 437 558 285 442 minecraft:black_concrete
fill 555 285 445 555 286 445 minecraft:black_concrete
fill 556 285 420 558 285 420 minecraft:black_concrete
fill 556 285 434 558 285 436 minecraft:black_concrete
fill 557 285 419 558 288 419 minecraft:black_concrete
fill 557 285 433 558 288 433 minecraft:black_concrete
fill 557 285 448 558 285 450 minecraft:black_concrete
fill 558 285 451 558 286 451 minecraft:black_concrete
fill 558 285 454 558 285 456 minecraft:black_concrete
fill 518 286 417 518 287 448 minecraft:black_concrete
fill 518 286 457 519 286 457 minecraft:black_concrete
fill 521 286 417 522 286 419 minecraft:black_concrete
fill 523 286 417 542 286 418 minecraft:black_concrete
fill 529 286 419 539 286 419 minecraft:black_concrete
fill 529 286 457 544 286 457 minecraft:black_concrete
fill 532 286 456 541 286 456 minecraft:black_concrete
fill 533 286 420 536 286 420 minecraft:black_concrete
fill 543 286 417 544 286 417 minecraft:black_concrete
fill 551 286 417 558 286 417 minecraft:black_concrete
fill 551 286 457 558 286 457 minecraft:black_concrete
fill 553 286 443 553 289 443 minecraft:black_concrete
fill 554 286 418 558 286 418 minecraft:black_concrete
fill 554 286 442 558 289 442 minecraft:black_concrete
fill 554 286 444 554 289 444 minecraft:black_concrete
fill 555 286 438 558 286 441 minecraft:black_concrete
fill 556 286 435 558 286 437 minecraft:black_concrete
fill 557 286 420 558 290 420 minecraft:black_concrete
fill 557 286 434 558 288 434 minecraft:black_concrete
fill 557 286 448 558 287 449 minecraft:black_concrete
fill 558 286 450 558 288 450 minecraft:black_concrete
setblock 558 286 452 minecraft:black_concrete
setblock 558 286 456 minecraft:black_concrete
fill 519 287 417 519 287 429 minecraft:black_concrete
fill 519 287 437 519 287 444 minecraft:black_concrete
fill 520 287 417 520 287 424 minecraft:black_concrete
fill 521 287 417 540 287 418 minecraft:black_concrete
fill 530 287 419 538 287 419 minecraft:black_concrete
fill 530 287 457 542 287 457 minecraft:black_concrete
fill 533 287 456 539 287 456 minecraft:black_concrete
fill 541 287 417 542 287 417 minecraft:black_concrete
fill 552 287 417 558 287 417 minecraft:black_concrete
fill 553 287 457 556 287 457 minecraft:black_concrete
fill 555 287 418 558 287 418 minecraft:black_concrete
fill 555 287 439 558 287 441 minecraft:black_concrete
fill 556 287 436 558 287 438 minecraft:black_concrete
fill 557 287 435 558 289 435 minecraft:black_concrete
fill 518 288 417 518 289 447 minecraft:black_concrete
fill 519 288 417 519 289 428 minecraft:black_concrete
fill 520 288 417 521 288 418 minecraft:black_concrete
fill 520 288 421 520 288 423 minecraft:black_concrete
fill 522 288 417 541 288 417 minecraft:black_concrete
fill 527 288 418 539 288 418 minecraft:black_concrete
fill 530 288 419 537 288 419 minecraft:black_concrete
fill 530 288 457 541 288 457 minecraft:black_concrete
fill 533 288 456 538 288 456 minecraft:black_concrete
fill 553 288 417 558 288 417 minecraft:black_concrete
fill 553 288 442 553 289 442 minecraft:black_concrete
fill 553 288 444 553 289 444 minecraft:black_concrete
fill 555 288 440 558 288 441 minecraft:black_concrete
fill 556 288 437 558 288 439 minecraft:black_concrete
fill 557 288 421 558 295 429 minecraft:black_concrete
fill 557 288 436 558 289 436 minecraft:black_concrete
fill 557 288 448 558 296 448 minecraft:black_concrete
fill 558 288 418 558 290 418 minecraft:black_concrete
fill 558 288 430 558 300 432 minecraft:black_concrete
fill 558 288 449 558 298 449 minecraft:black_concrete
fill 520 289 417 539 289 417 minecraft:black_concrete
setblock 520 289 419 minecraft:light[level=12]
setblock 520 289 427 minecraft:light[level=12]
setblock 520 289 435 minecraft:light[level=12]
setblock 520 289 443 minecraft:light[level=12]
setblock 520 289 451 minecraft:light[level=12]
fill 528 289 418 538 289 418 minecraft:black_concrete
setblock 528 289 419 minecraft:light[level=12]
setblock 528 289 427 minecraft:light[level=12]
setblock 528 289 435 minecraft:light[level=12]
setblock 528 289 443 minecraft:light[level=12]
setblock 528 289 451 minecraft:light[level=12]
fill 530 289 457 539 290 457 minecraft:black_concrete
fill 531 289 419 535 289 419 minecraft:black_concrete
fill 533 289 456 536 289 456 minecraft:black_concrete
setblock 536 289 419 minecraft:light[level=12]
setblock 536 289 427 minecraft:light[level=12]
setblock 536 289 435 minecraft:light[level=12]
setblock 536 289 443 minecraft:light[level=12]
setblock 536 289 451 minecraft:light[level=12]
setblock 544 289 419 minecraft:light[level=12]
setblock 544 289 427 minecraft:light[level=12]
setblock 544 289 435 minecraft:light[level=12]
setblock 544 289 443 minecraft:light[level=12]
setblock 544 289 451 minecraft:light[level=12]
setblock 552 289 419 minecraft:light[level=12]
setblock 552 289 427 minecraft:light[level=12]
setblock 552 289 435 minecraft:light[level=12]
setblock 552 289 443 minecraft:light[level=12]
setblock 552 289 451 minecraft:light[level=12]
fill 553 289 417 557 289 417 minecraft:black_concrete
fill 556 289 438 558 289 441 minecraft:black_concrete
fill 556 289 445 558 294 446 minecraft:black_concrete
fill 557 289 437 558 290 437 minecraft:black_concrete
fill 557 289 447 558 296 447 minecraft:black_concrete
fill 558 289 419 558 294 419 minecraft:black_concrete
fill 558 289 433 558 300 434 minecraft:black_concrete
fill 518 290 417 518 298 432 minecraft:black_concrete
fill 518 290 439 518 290 447 minecraft:black_concrete
fill 519 290 417 521 290 417 minecraft:black_concrete
fill 519 290 419 519 291 428 minecraft:black_concrete
fill 526 290 417 538 290 417 minecraft:black_concrete
fill 528 290 418 536 291 418 minecraft:black_concrete
fill 531 290 419 534 290 419 minecraft:black_concrete
fill 533 290 456 535 300 456 minecraft:black_concrete
fill 554 290 417 555 290 417 minecraft:black_concrete
fill 556 290 424 556 297 425 minecraft:black_concrete
fill 556 290 440 558 290 444 minecraft:black_concrete
fill 557 290 430 557 300 430 minecraft:black_concrete
fill 557 290 438 558 291 439 minecraft:black_concrete
fill 558 290 435 558 299 436 minecraft:black_concrete
fill 518 291 441 518 291 447 minecraft:black_concrete
fill 519 291 417 519 292 417 minecraft:black_concrete
fill 526 291 417 537 292 417 minecraft:black_concrete
fill 529 291 457 538 299 457 minecraft:black_concrete
setblock 532 291 419 minecraft:black_concrete
fill 532 291 456 532 300 456 minecraft:black_concrete
fill 556 291 423 556 295 423 minecraft:black_concrete
fill 556 291 426 556 298 427 minecraft:black_concrete
fill 556 291 441 558 291 444 minecraft:black_concrete
fill 557 291 431 557 300 431 minecraft:black_concrete
fill 557 291 440 558 293 440 minecraft:black_concrete
fill 558 291 420 558 297 420 minecraft:black_concrete
fill 558 291 437 558 296 437 minecraft:black_concrete
fill 518 292 443 518 292 448 minecraft:black_concrete
fill 519 292 420 519 293 428 minecraft:black_concrete
fill 525 292 417 525 300 417 minecraft:black_concrete
fill 528 292 418 535 292 418 minecraft:black_concrete
fill 528 292 457 528 300 457 minecraft:black_concrete
fill 531 292 456 531 300 456 minecraft:black_concrete
fill 556 292 428 556 299 429 minecraft:black_concrete
fill 556 292 442 558 292 444 minecraft:black_concrete
fill 556 292 447 556 294 447 minecraft:black_concrete
fill 557 292 432 557 300 432 minecraft:black_concrete
fill 557 292 439 558 292 439 minecraft:black_concrete
fill 557 292 441 558 293 441 minecraft:black_concrete
fill 558 292 438 558 295 438 minecraft:black_concrete
fill 558 292 450 558 298 450 minecraft:black_concrete
fill 518 293 444 518 293 449 minecraft:black_concrete
fill 519 293 429 519 299 429 minecraft:black_concrete
fill 524 293 417 524 300 417 minecraft:black_concrete
fill 526 293 417 536 294 417 minecraft:black_concrete
fill 527 293 418 534 294 418 minecraft:black_concrete
fill 527 293 457 527 300 457 minecraft:black_concrete
fill 529 293 456 530 300 456 minecraft:black_concrete
fill 536 293 456 536 299 456 minecraft:black_concrete
fill 556 293 430 556 300 430 minecraft:black_concrete
fill 556 293 443 558 293 444 minecraft:black_concrete
fill 557 293 433 557 300 433 minecraft:black_concrete
fill 557 293 442 558 294 442 minecraft:black_concrete
fill 557 293 449 557 296 449 minecraft:black_concrete
fill 558 293 439 558 295 439 minecraft:black_concrete
fill 518 294 433 518 300 433 minecraft:black_concrete
fill 518 294 445 518 294 450 minecraft:black_concrete
fill 519 294 421 519 295 428 minecraft:black_concrete
fill 523 294 417 523 300 417 minecraft:black_concrete
fill 526 294 457 526 300 457 minecraft:black_concrete
fill 528 294 456 528 300 456 minecraft:black_concrete
fill 530 294 455 534 300 455 minecraft:black_concrete
fill 552 294 417 553 297 417 minecraft:black_concrete
fill 555 294 426 555 296 428 minecraft:black_concrete
fill 556 294 431 556 300 431 minecraft:black_concrete
fill 557 294 434 557 300 434 minecraft:black_concrete
fill 557 294 443 558 295 444 minecraft:black_concrete
fill 558 294 440 558 295 441 minecraft:black_concrete
fill 558 294 451 558 298 451 minecraft:black_concrete
fill 518 295 446 518 295 451 minecraft:black_concrete
fill 519 295 417 519 297 417 minecraft:black_concrete
fill 519 295 430 519 298 430 minecraft:black_concrete
fill 522 295 417 522 300 417 minecraft:black_concrete
fill 524 295 457 525 300 457 minecraft:black_concrete
fill 526 295 417 533 296 418 minecraft:black_concrete
fill 527 295 456 527 300 456 minecraft:black_concrete
fill 529 295 455 529 300 455 minecraft:black_concrete
fill 534 295 417 535 296 417 minecraft:black_concrete
fill 535 295 455 535 298 455 minecraft:black_concrete
fill 548 295 457 553 299 457 minecraft:black_concrete
fill 551 295 417 551 299 417 minecraft:black_concrete
setblock 554 295 417 minecraft:black_concrete
fill 555 295 429 555 298 430 minecraft:black_concrete
fill 556 295 432 556 299 432 minecraft:black_concrete
fill 557 295 445 558 295 446 minecraft:black_concrete
fill 558 295 442 558 296 442 minecraft:black_concrete
fill 518 296 447 518 296 453 minecraft:black_concrete
fill 519 296 422 519 297 428 minecraft:black_concrete
fill 521 296 417 521 300 417 minecraft:black_concrete
fill 523 296 457 523 300 457 minecraft:black_concrete
fill 525 296 456 526 300 456 minecraft:black_concrete
fill 527 296 455 528 300 455 minecraft:black_concrete
fill 529 296 454 533 299 454 minecraft:black_concrete
fill 537 296 456 537 297 456 minecraft:black_concrete
fill 547 296 457 547 300 457 minecraft:black_concrete
fill 550 296 417 550 300 417 minecraft:black_concrete
fill 556 296 433 556 298 433 minecraft:black_concrete
fill 557 296 422 558 296 429 minecraft:black_concrete
fill 557 296 446 558 296 446 minecraft:black_concrete
fill 558 296 421 558 298 421 minecraft:black_concrete
fill 558 296 443 558 296 445 minecraft:black_concrete
fill 558 296 452 558 298 452 minecraft:black_concrete
fill 518 297 448 518 297 454 minecraft:black_concrete
fill 520 297 417 520 298 417 minecraft:black_concrete
setblock 520 297 419 minecraft:light[level=12]
setblock 520 297 427 minecraft:light[level=12]
setblock 520 297 435 minecraft:light[level=12]
setblock 520 297 443 minecraft:light[level=12]
setblock 520 297 451 minecraft:light[level=12]
fill 522 297 457 522 300 457 minecraft:black_concrete
fill 524 297 456 524 300 456 minecraft:black_concrete
fill 525 297 418 532 297 418 minecraft:black_concrete
fill 526 297 417 534 298 417 minecraft:black_concrete
fill 526 297 455 526 300 455 minecraft:black_concrete
setblock 528 297 419 minecraft:light[level=12]
setblock 528 297 427 minecraft:light[level=12]
setblock 528 297 435 minecraft:light[level=12]
setblock 528 297 443 minecraft:light[level=12]
setblock 528 297 451 minecraft:light[level=12]
fill 528 297 454 528 300 454 minecraft:black_concrete
setblock 536 297 419 minecraft:light[level=12]
setblock 536 297 427 minecraft:light[level=12]
setblock 536 297 435 minecraft:light[level=12]
setblock 536 297 443 minecraft:light[level=12]
setblock 536 297 451 minecraft:light[level=12]
setblock 544 297 419 minecraft:light[level=12]
setblock 544 297 427 minecraft:light[level=12]
setblock 544 297 435 minecraft:light[level=12]
setblock 544 297 443 minecraft:light[level=12]
setblock 544 297 451 minecraft:light[level=12]
fill 545 297 457 546 300 457 minecraft:black_concrete
fill 548 297 456 550 300 456 minecraft:black_concrete
fill 549 297 417 549 300 417 minecraft:black_concrete
setblock 552 297 419 minecraft:light[level=12]
setblock 552 297 427 minecraft:light[level=12]
setblock 552 297 435 minecraft:light[level=12]
setblock 552 297 443 minecraft:light[level=12]
setblock 552 297 451 minecraft:light[level=12]
fill 555 297 427 555 297 428 minecraft:black_concrete
setblock 555 297 431 minecraft:black_concrete
fill 557 297 423 558 298 429 minecraft:black_concrete
fill 558 297 422 558 299 422 minecraft:black_concrete
fill 558 297 445 558 297 448 minecraft:black_concrete
fill 518 298 449 518 298 455 minecraft:black_concrete
fill 519 298 424 519 298 428 minecraft:black_concrete
fill 521 298 457 521 300 457 minecraft:black_concrete
fill 523 298 456 523 300 456 minecraft:black_concrete
fill 525 298 418 531 298 418 minecraft:black_concrete
fill 525 298 455 525 300 455 minecraft:black_concrete
fill 527 298 454 527 300 454 minecraft:black_concrete
fill 544 298 457 544 300 457 minecraft:black_concrete
fill 547 298 456 547 300 456 minecraft:black_concrete
setblock 551 298 456 minecraft:black_concrete
setblock 552 298 417 minecraft:black_concrete
setblock 555 298 428 minecraft:black_concrete
setblock 556 298 425 minecraft:black_concrete
setblock 558 298 448 minecraft:black_concrete
fill 518 299 421 518 299 432 minecraft:black_concrete
fill 518 299 450 518 299 456 minecraft:black_concrete
fill 519 299 426 519 299 428 minecraft:black_concrete
fill 520 299 457 520 300 457 minecraft:black_concrete
fill 522 299 456 522 300 456 minecraft:black_concrete
fill 524 299 455 524 300 455 minecraft:black_concrete
fill 525 299 418 530 299 418 minecraft:black_concrete
fill 526 299 417 533 299 417 minecraft:black_concrete
fill 526 299 454 526 300 454 minecraft:black_concrete
fill 543 299 457 543 300 457 minecraft:black_concrete
fill 546 299 456 546 300 456 minecraft:black_concrete
fill 556 299 427 558 299 427 minecraft:black_concrete
fill 557 299 424 558 299 426 minecraft:black_concrete
fill 557 299 428 558 300 429 minecraft:black_concrete
fill 558 299 423 558 300 423 minecraft:black_concrete
fill 518 300 423 518 300 432 minecraft:black_concrete
fill 518 300 451 518 300 456 minecraft:black_concrete
setblock 519 300 457 minecraft:black_concrete
fill 526 300 417 529 300 418 minecraft:black_concrete
fill 529 300 454 532 300 454 minecraft:black_concrete
fill 529 300 457 537 300 457 minecraft:black_concrete
fill 530 300 417 532 300 417 minecraft:black_concrete
setblock 545 300 456 minecraft:black_concrete
fill 548 300 457 552 300 457 minecraft:black_concrete
setblock 556 300 429 minecraft:black_concrete
fill 557 300 426 558 300 427 minecraft:black_concrete
fill 558 300 424 558 300 425 minecraft:black_concrete
setblock 558 300 435 minecraft:black_concrete
