fill 523 243 270 523 245 270 minecraft:purple_terracotta
fill 527 243 228 527 245 228 minecraft:purple_terracotta
fill 527 243 270 527 245 270 minecraft:purple_terracotta
fill 531 243 228 531 245 228 minecraft:purple_terracotta
fill 531 243 270 531 245 270 minecraft:purple_terracotta
fill 535 243 228 535 245 228 minecraft:purple_terracotta
fill 535 243 270 535 245 270 minecraft:purple_terracotta
fill 539 243 228 539 245 228 minecraft:purple_terracotta
fill 539 243 270 539 245 270 minecraft:purple_terracotta
fill 541 243 246 541 277 246 minecraft:iron_bars
fill 541 243 254 541 248 254 minecraft:iron_bars
fill 543 243 228 543 244 228 minecraft:purple_terracotta
fill 543 243 270 543 245 270 minecraft:purple_terracotta
fill 547 243 228 547 245 228 minecraft:purple_terracotta
fill 547 243 270 547 245 270 minecraft:purple_terracotta
fill 551 243 228 551 245 228 minecraft:purple_terracotta
fill 551 243 270 551 245 270 minecraft:purple_terracotta
fill 555 243 228 555 245 228 minecraft:purple_terracotta
fill 555 243 270 555 245 270 minecraft:purple_terracotta
fill 557 243 257 557 243 258 minecraft:spruce_planks
fill 557 243 259 558 243 260 minecraft:dark_oak_planks
setblock 559 243 228 minecraft:purple_terracotta
fill 559 243 230 559 245 230 minecraft:purple_terracotta
fill 559 243 234 559 245 234 minecraft:purple_terracotta
fill 559 243 238 559 245 238 minecraft:purple_terracotta
fill 559 243 242 559 245 242 minecraft:purple_terracotta
fill 559 243 246 559 245 246 minecraft:purple_terracotta
fill 559 243 250 559 245 250 minecraft:purple_terracotta
fill 559 243 254 559 245 254 minecraft:purple_terracotta
fill 559 243 258 559 245 258 minecraft:purple_terracotta
fill 559 243 262 559 245 262 minecraft:purple_terracotta
fill 559 243 266 559 245 266 minecraft:purple_terracotta
fill 559 243 270 559 245 270 minecraft:purple_terracotta
setblock 517 244 228 minecraft:magenta_terracotta
setblock 517 244 232 minecraft:magenta_terracotta
setblock 517 244 236 minecraft:magenta_terracotta
setblock 517 244 240 minecraft:magenta_terracotta
setblock 517 244 244 minecraft:magenta_terracotta
setblock 517 244 248 minecraft:magenta_terracotta
setblock 517 244 252 minecraft:magenta_terracotta
setblock 517 244 256 minecraft:magenta_terracotta
setblock 517 244 260 minecraft:magenta_terracotta
setblock 517 244 263 minecraft:light_gray_terracotta
setblock 517 244 264 minecraft:magenta_terracotta
setblock 517 244 268 minecraft:magenta_terracotta
setblock 517 244 270 minecraft:magenta_terracotta
setblock 520 244 231 minecraft:light[level=12]
setblock 520 244 238 minecraft:light[level=12]
setblock 520 244 245 minecraft:light[level=12]
setblock 520 244 252 minecraft:light[level=12]
setblock 520 244 259 minecraft:light[level=12]
setblock 520 244 266 minecraft:light[level=12]
setblock 521 244 228 minecraft:magenta_terracotta
setblock 521 244 270 minecraft:magenta_terracotta
setblock 525 244 228 minecraft:magenta_terracotta
setblock 525 244 270 minecraft:magenta_terracotta
setblock 527 244 231 minecraft:light[level=12]
setblock 527 244 238 minecraft:light[level=12]
setblock 527 244 245 minecraft:light[level=12]
setblock 527 244 252 minecraft:light[level=12]
setblock 527 244 259 minecraft:light[level=12]
setblock 527 244 266 minecraft:light[level=12]
setblock 529 244 228 minecraft:magenta_terracotta
setblock 529 244 270 minecraft:magenta_terracotta
setblock 533 244 228 minecraft:magenta_terracotta
setblock 533 244 270 minecraft:magenta_terracotta
setblock 534 244 231 minecraft:light[level=12]
setblock 534 244 238 minecraft:light[level=12]
setblock 534 244 245 minecraft:light[level=12]
setblock 534 244 252 minecraft:light[level=12]
setblock 534 244 259 minecraft:light[level=12]
setblock 534 244 266 minecraft:light[level=12]
setblock 534 244 270 minecraft:gray_terracotta
setblock 537 244 228 minecraft:magenta_terracotta
setblock 537 244 270 minecraft:magenta_terracotta
setblock 541 244 228 minecraft:magenta_terracotta
setblock 541 244 231 minecraft:light[level=12]
setblock 541 244 238 minecraft:light[level=12]
setblock 541 244 245 minecraft:light[level=12]
setblock 541 244 252 minecraft:light[level=12]
setblock 541 244 259 minecraft:light[level=12]
setblock 541 244 266 minecraft:light[level=12]
setblock 541 244 270 minecraft:magenta_terracotta
setblock 545 244 228 minecraft:magenta_terracotta
setblock 545 244 270 minecraft:magenta_terracotta
setblock 548 244 231 minecraft:light[level=12]
setblock 548 244 238 minecraft:light[level=12]
setblock 548 244 245 minecraft:light[level=12]
setblock 548 244 252 minecraft:light[level=12]
setblock 548 244 259 minecraft:light[level=12]
setblock 548 244 266 minecraft:light[level=12]
setblock 549 244 228 minecraft:magenta_terracotta
setblock 549 244 270 minecraft:magenta_terracotta
setblock 553 244 228 minecraft:magenta_terracotta
setblock 553 244 270 minecraft:magenta_terracotta
setblock 555 244 231 minecraft:light[level=12]
setblock 555 244 238 minecraft:light[level=12]
setblock 555 244 245 minecraft:light[level=12]
setblock 555 244 252 minecraft:light[level=12]
setblock 555 244 259 minecraft:light[level=12]
setblock 555 244 266 minecraft:light[level=12]
setblock 557 244 228 minecraft:magenta_terracotta
fill 557 244 255 557 244 256 minecraft:spruce_planks
fill 557 244 257 558 244 258 minecraft:dark_oak_planks
setblock 557 244 270 minecraft:magenta_terracotta
setblock 559 244 228 minecraft:magenta_terracotta
setblock 559 244 232 minecraft:magenta_terracotta
setblock 559 244 236 minecraft:magenta_terracotta
setblock 559 244 240 minecraft:magenta_terracotta
setblock 559 244 244 minecraft:magenta_terracotta
setblock 559 244 248 minecraft:magenta_terracotta
setblock 559 244 252 minecraft:magenta_terracotta
setblock 559 244 256 minecraft:magenta_terracotta
setblock 559 244 260 minecraft:magenta_terracotta
setblock 559 244 264 minecraft:magenta_terracotta
setblock 559 244 268 minecraft:magenta_terracotta
fill 517 245 228 517 247 228 minecraft:purple_terracotta
fill 517 245 232 517 247 232 minecraft:purple_terracotta
fill 517 245 236 517 247 236 minecraft:purple_terracotta
fill 517 245 240 517 247 240 minecraft:purple_terracotta
fill 517 245 244 517 247 244 minecraft:purple_terracotta
fill 517 245 248 517 247 248 minecraft:purple_terracotta
fill 517 245 252 517 247 252 minecraft:purple_terracotta
fill 517 245 256 517 247 256 minecraft:purple_terracotta
fill 517 245 260 517 247 260 minecraft:purple_terracotta
fill 517 245 263 517 247 264 minecraft:purple_terracotta
fill 517 245 268 517 247 268 minecraft:purple_terracotta
setblock 517 245 270 minecraft:purple_terracotta
fill 521 245 228 521 247 228 minecraft:purple_terracotta
fill 521 245 270 521 247 270 minecraft:purple_terracotta
fill 525 245 228 525 247 228 minecraft:purple_terracotta
fill 525 245 270 525 247 270 minecraft:purple_terracotta
fill 529 245 228 529 247 228 minecraft:purple_terracotta
fill 529 245 270 529 247 270 minecraft:purple_terracotta
fill 533 245 228 533 247 228 minecraft:purple_terracotta
fill 533 245 270 534 247 270 minecraft:purple_terracotta
fill 534 245 246 534 262 246 minecraft:iron_bars
fill 534 245 254 534 250 254 minecraft:iron_bars
fill 537 245 228 537 247 228 minecraft:purple_terracotta
fill 537 245 270 537 247 270 minecraft:purple_terracotta
fill 541 245 228 541 247 228 minecraft:purple_terracotta
fill 541 245 270 541 247 270 minecraft:purple_terracotta
setblock 543 245 228 minecraft:black_terracotta
fill 545 245 228 545 247 228 minecraft:purple_terracotta
fill 545 245 270 545 247 270 minecraft:purple_terracotta
fill 549 245 228 549 247 228 minecraft:purple_terracotta
fill 549 245 270 549 247 270 minecraft:purple_terracotta
fill 553 245 228 553 247 228 minecraft:purple_terracotta
fill 553 245 270 553 247 270 minecraft:purple_terracotta
fill 557 245 228 557 247 228 minecraft:purple_terracotta
fill 557 245 253 557 245 254 minecraft:spruce_planks
fill 557 245 255 558 245 256 minecraft:dark_oak_planks
fill 557 245 270 557 247 270 minecraft:purple_terracotta
setblock 559 245 228 minecraft:purple_terracotta
fill 559 245 232 559 247 232 minecraft:purple_terracotta
fill 559 245 236 559 247 236 minecraft:purple_terracotta
fill 559 245 240 559 247 240 minecraft:purple_terracotta
fill 559 245 244 559 247 244 minecraft:purple_terracotta
fill 559 245 248 559 247 248 minecraft:purple_terracotta
fill 559 245 252 559 247 252 minecraft:purple_terracotta
fill 559 245 256 559 247 256 minecraft:purple_terracotta
fill 559 245 260 559 247 260 minecraft:purple_terracotta
fill 559 245 264 559 247 264 minecraft:purple_terracotta
fill 559 245 268 559 247 268 minecraft:purple_terracotta
setblock 517 246 230 minecraft:magenta_terracotta
setblock 517 246 234 minecraft:magenta_terracotta
setblock 517 246 238 minecraft:magenta_terracotta
setblock 517 246 242 minecraft:magenta_terracotta
setblock 517 246 246 minecraft:magenta_terracotta
setblock 517 246 250 minecraft:magenta_terracotta
setblock 517 246 254 minecraft:magenta_terracotta
setblock 517 246 258 minecraft:magenta_terracotta
setblock 517 246 262 minecraft:magenta_terracotta
setblock 517 246 266 minecraft:magenta_terracotta
setblock 517 246 270 minecraft:magenta_terracotta
setblock 519 246 228 minecraft:magenta_terracotta
setblock 519 246 270 minecraft:magenta_terracotta
setblock 523 246 228 minecraft:magenta_terracotta
setblock 523 246 270 minecraft:magenta_terracotta
setblock 527 246 228 minecraft:magenta_terracotta
setblock 527 246 270 minecraft:magenta_terracotta
setblock 531 246 228 minecraft:magenta_terracotta
setblock 531 246 270 minecraft:magenta_terracotta
setblock 535 246 228 minecraft:magenta_terracotta
setblock 535 246 270 minecraft:magenta_terracotta
setblock 539 246 228 minecraft:magenta_terracotta
setblock 539 246 270 minecraft:magenta_terracotta
setblock 543 246 228 minecraft:magenta_terracotta
setblock 543 246 270 minecraft:magenta_terracotta
setblock 547 246 228 minecraft:magenta_terracotta
setblock 547 246 270 minecraft:magenta_terracotta
setblock 551 246 228 minecraft:magenta_terracotta
setblock 551 246 270 minecraft:magenta_terracotta
setblock 555 246 228 minecraft:magenta_terracotta
setblock 555 246 270 minecraft:magenta_terracotta
fill 557 246 251 557 246 252 minecraft:spruce_planks
fill 557 246 253 558 246 254 minecraft:dark_oak_planks
setblock 559 246 228 minecraft:magenta_terracotta
setblock 559 246 230 minecraft:magenta_terracotta
setblock 559 246 234 minecraft:magenta_terracotta
setblock 559 246 238 minecraft:magenta_terracotta
setblock 559 246 242 minecraft:magenta_terracotta
setblock 559 246 246 minecraft:magenta_terracotta
setblock 559 246 250 minecraft:magenta_terracotta
setblock 559 246 254 minecraft:magenta_terracotta
setblock 559 246 258 minecraft:magenta_terracotta
setblock 559 246 262 minecraft:magenta_terracotta
setblock 559 246 266 minecraft:magenta_terracotta
setblock 559 246 270 minecraft:magenta_terracotta
fill 517 247 230 517 249 230 minecraft:purple_terracotta
fill 517 247 234 517 249 234 minecraft:purple_terracotta
fill 517 247 238 517 249 238 minecraft:purple_terracotta
fill 517 247 242 517 249 242 minecraft:purple_terracotta
fill 517 247 246 517 249 246 minecraft:purple_terracotta
fill 517 247 250 517 249 250 minecraft:purple_terracotta
fill 517 247 254 517 249 254 minecraft:purple_terracotta
fill 517 247 258 517 249 258 minecraft:purple_terracotta
fill 517 247 262 517 249 262 minecraft:purple_terracotta
fill 517 247 266 517 249 266 minecraft:purple_terracotta
setblock 517 247 270 minecraft:purple_terracotta
setblock 518 247 228 minecraft:gray_terracotta
fill 519 247 228 519 249 228 minecraft:purple_terracotta
fill 519 247 270 519 249 270 minecraft:purple_terracotta
fill 523 247 228 523 249 228 minecraft:purple_terracotta
fill 523 247 270 523 249 270 minecraft:purple_terracotta
fill 527 247 228 527 249 228 minecraft:purple_terracotta
fill 527 247 270 527 249 270 minecraft:purple_terracotta
fill 531 247 228 531 249 228 minecraft:purple_terracotta
fill 531 247 270 531 249 270 minecraft:purple_terracotta
fill 535 247 228 535 249 228 minecraft:purple_terracotta
fill 535 247 270 535 249 270 minecraft:purple_terracotta
fill 539 247 228 539 249 228 minecraft:purple_terracotta
fill 539 247 270 539 249 270 minecraft:purple_terracotta
fill 543 247 228 543 249 228 minecraft:purple_terracotta
fill 543 247 270 543 249 270 minecraft:purple_terracotta
fill 547 247 228 547 249 228 minecraft:purple_terracotta
fill 547 247 270 547 249 270 minecraft:purple_terracotta
fill 551 247 228 551 249 228 minecraft:purple_terracotta
fill 551 247 270 551 249 270 minecraft:purple_terracotta
fill 554 247 248 554 258 248 minecraft:iron_bars
fill 555 247 228 555 249 228 minecraft:purple_terracotta
fill 555 247 270 555 249 270 minecraft:purple_terracotta
fill 557 247 249 557 247 250 minecraft:spruce_planks
fill 557 247 251 558 247 252 minecraft:dark_oak_planks
setblock 559 247 228 minecraft:purple_terracotta
fill 559 247 230 559 249 230 minecraft:purple_terracotta
fill 559 247 234 559 249 234 minecraft:purple_terracotta
fill 559 247 238 559 249 238 minecraft:purple_terracotta
fill 559 247 242 559 249 242 minecraft:purple_terracotta
fill 559 247 246 559 249 246 minecraft:purple_terracotta
fill 559 247 250 559 249 250 minecraft:purple_terracotta
fill 559 247 254 559 249 254 minecraft:purple_terracotta
fill 559 247 258 559 249 258 minecraft:purple_terracotta
fill 559 247 262 559 249 262 minecraft:purple_terracotta
fill 559 247 266 559 249 266 minecraft:purple_terracotta
fill 559 247 270 559 249 270 minecraft:purple_terracotta
setblock 517 248 228 minecraft:magenta_terracotta
setblock 517 248 232 minecraft:magenta_terracotta
setblock 517 248 236 minecraft:magenta_terracotta
setblock 517 248 240 minecraft:magenta_terracotta
setblock 517 248 244 minecraft:magenta_terracotta
setblock 517 248 248 minecraft:magenta_terracotta
setblock 517 248 252 minecraft:magenta_terracotta
setblock 517 248 256 minecraft:magenta_terracotta
setblock 517 248 260 minecraft:magenta_terracotta
fill 517 248 263 517 278 263 minecraft:purple_terracotta
setblock 517 248 264 minecraft:magenta_terracotta
setblock 517 248 268 minecraft:magenta_terracotta
setblock 517 248 270 minecraft:magenta_terracotta
fill 518 248 228 518 278 228 minecraft:purple_terracotta
setblock 520 248 231 minecraft:light[level=11]
setblock 520 248 239 minecraft:light[level=11]
setblock 520 248 247 minecraft:light[level=11]
setblock 520 248 255 minecraft:light[level=11]
setblock 520 248 263 minecraft:light[level=11]
setblock 521 248 228 minecraft:magenta_terracotta
setblock 521 248 270 minecraft:magenta_terracotta
setblock 525 248 228 minecraft:magenta_terracotta
setblock 525 248 270 minecraft:magenta_terracotta
setblock 528 248 231 minecraft:light[level=11]
setblock 528 248 239 minecraft:light[level=11]
setblock 528 248 247 minecraft:light[level=11]
setblock 528 248 255 minecraft:light[level=11]
setblock 528 248 263 minecraft:light[level=11]
setblock 529 248 228 minecraft:magenta_terracotta
setblock 529 248 270 minecraft:magenta_terracotta
setblock 533 248 228 minecraft:magenta_terracotta
setblock 533 248 270 minecraft:magenta_terracotta
fill 534 248 270 534 278 270 minecraft:purple_terracotta
setblock 536 248 231 minecraft:light[level=11]
setblock 536 248 239 minecraft:light[level=11]
setblock 536 248 247 minecraft:light[level=11]
setblock 536 248 255 minecraft:light[level=11]
setblock 536 248 263 minecraft:light[level=11]
setblock 537 248 228 minecraft:magenta_terracotta
setblock 537 248 270 minecraft:magenta_terracotta
setblock 541 248 228 minecraft:magenta_terracotta
setblock 541 248 270 minecraft:magenta_terracotta
setblock 544 248 228 minecraft:black_terracotta
setblock 544 248 231 minecraft:light[level=11]
setblock 544 248 239 minecraft:light[level=11]
setblock 544 248 247 minecraft:light[level=11]
setblock 544 248 255 minecraft:light[level=11]
setblock 544 248 263 minecraft:light[level=11]
setblock 545 248 228 minecraft:magenta_terracotta
setblock 545 248 270 minecraft:magenta_terracotta
setblock 549 248 228 minecraft:magenta_terracotta
setblock 549 248 270 minecraft:magenta_terracotta
setblock 552 248 231 minecraft:light[level=11]
setblock 552 248 239 minecraft:light[level=11]
setblock 552 248 247 minecraft:light[level=11]
setblock 552 248 255 minecraft:light[level=11]
setblock 552 248 263 minecraft:light[level=11]
setblock 553 248 228 minecraft:magenta_terracotta
setblock 553 248 270 minecraft:magenta_terracotta
setblock 557 248 228 minecraft:magenta_terracotta
fill 557 248 247 557 248 248 minecraft:spruce_planks
fill 557 248 249 558 248 250 minecraft:dark_oak_planks
setblock 557 248 270 minecraft:magenta_terracotta
setblock 559 248 228 minecraft:magenta_terracotta
setblock 559 248 232 minecraft:magenta_terracotta
setblock 559 248 236 minecraft:magenta_terracotta
setblock 559 248 240 minecraft:magenta_terracotta
setblock 559 248 244 minecraft:magenta_terracotta
setblock 559 248 248 minecraft:magenta_terracotta
setblock 559 248 252 minecraft:magenta_terracotta
setblock 559 248 256 minecraft:magenta_terracotta
setblock 559 248 260 minecraft:magenta_terracotta
setblock 559 248 264 minecraft:magenta_terracotta
setblock 559 248 268 minecraft:magenta_terracotta
fill 517 249 228 517 251 228 minecraft:purple_terracotta
fill 517 249 232 517 251 232 minecraft:purple_terracotta
fill 517 249 236 517 251 236 minecraft:purple_terracotta
fill 517 249 240 517 251 240 minecraft:purple_terracotta
fill 517 249 244 517 251 244 minecraft:purple_terracotta
fill 517 249 248 517 251 248 minecraft:purple_terracotta
fill 517 249 252 517 251 252 minecraft:purple_terracotta
fill 517 249 256 517 251 256 minecraft:purple_terracotta
fill 517 249 260 517 251 260 minecraft:purple_terracotta
fill 517 249 264 517 251 264 minecraft:purple_terracotta
fill 517 249 268 517 251 268 minecraft:purple_terracotta
setblock 517 249 270 minecraft:purple_terracotta
fill 521 249 228 521 251 228 minecraft:purple_terracotta
fill 521 249 270 521 251 270 minecraft:purple_terracotta
fill 525 249 228 525 250 228 minecraft:purple_terracotta
fill 525 249 270 525 251 270 minecraft:purple_terracotta
fill 529 249 228 529 251 228 minecraft:purple_terracotta
fill 529 249 270 529 251 270 minecraft:purple_terracotta
fill 533 249 228 533 251 228 minecraft:purple_terracotta
fill 533 249 270 533 251 270 minecraft:purple_terracotta
fill 537 249 228 537 251 228 minecraft:purple_terracotta
fill 537 249 270 537 251 270 minecraft:purple_terracotta
fill 541 249 228 541 251 228 minecraft:purple_terracotta
fill 541 249 270 541 251 270 minecraft:purple_terracotta
fill 544 249 228 545 251 228 minecraft:purple_terracotta
fill 545 249 270 545 251 270 minecraft:purple_terracotta
fill 549 249 228 549 251 228 minecraft:purple_terracotta
fill 549 249 270 549 251 270 minecraft:purple_terracotta
fill 553 249 228 553 251 228 minecraft:purple_terracotta
fill 553 249 270 553 251 270 minecraft:purple_terracotta
fill 557 249 228 557 251 228 minecraft:purple_terracotta
fill 557 249 245 557 249 246 minecraft:spruce_planks
fill 557 249 247 558 249 248 minecraft:dark_oak_planks
fill 557 249 270 557 251 270 minecraft:purple_terracotta
setblock 559 249 228 minecraft:purple_terracotta
fill 559 249 232 559 251 232 minecraft:purple_terracotta
fill 559 249 236 559 251 236 minecraft:purple_terracotta
fill 559 249 240 559 251 240 minecraft:purple_terracotta
fill 559 249 244 559 251 244 minecraft:purple_terracotta
fill 559 249 248 559 251 248 minecraft:purple_terracotta
fill 559 249 252 559 251 252 minecraft:purple_terracotta
fill 559 249 256 559 251 256 minecraft:purple_terracotta
fill 559 249 260 559 251 260 minecraft:purple_terracotta
fill 559 249 264 559 251 264 minecraft:purple_terracotta
setblock 559 249 265 minecraft:gray_terracotta
fill 559 249 268 559 251 268 minecraft:purple_terracotta
setblock 517 250 230 minecraft:magenta_terracotta
setblock 517 250 234 minecraft:magenta_terracotta
setblock 517 250 238 minecraft:magenta_terracotta
setblock 517 250 242 minecraft:magenta_terracotta
setblock 517 250 246 minecraft:magenta_terracotta
setblock 517 250 250 minecraft:magenta_terracotta
setblock 517 250 254 minecraft:magenta_terracotta
setblock 517 250 258 minecraft:magenta_terracotta
setblock 517 250 262 minecraft:magenta_terracotta
setblock 517 250 266 minecraft:magenta_terracotta
setblock 517 250 270 minecraft:magenta_terracotta
setblock 519 250 228 minecraft:magenta_terracotta
setblock 519 250 270 minecraft:magenta_terracotta
setblock 520 250 231 minecraft:light[level=12]
setblock 520 250 238 minecraft:light[level=12]
setblock 520 250 245 minecraft:light[level=12]
setblock 520 250 252 minecraft:light[level=12]
setblock 520 250 259 minecraft:light[level=12]
setblock 520 250 266 minecraft:light[level=12]
setblock 523 250 228 minecraft:magenta_terracotta
setblock 523 250 270 minecraft:magenta_terracotta
setblock 527 250 228 minecraft:magenta_terracotta
setblock 527 250 231 minecraft:light[level=12]
setblock 527 250 238 minecraft:light[level=12]
setblock 527 250 245 minecraft:light[level=12]
setblock 527 250 252 minecraft:light[level=12]
setblock 527 250 259 minecraft:light[level=12]
setblock 527 250 266 minecraft:light[level=12]
setblock 527 250 270 minecraft:magenta_terracotta
setblock 531 250 228 minecraft:magenta_terracotta
setblock 531 250 270 minecraft:magenta_terracotta
setblock 534 250 231 minecraft:light[level=12]
setblock 534 250 238 minecraft:light[level=12]
setblock 534 250 245 minecraft:light[level=12]
setblock 534 250 252 minecraft:light[level=12]
setblock 534 250 259 minecraft:light[level=12]
setblock 534 250 266 minecraft:light[level=12]
setblock 535 250 228 minecraft:magenta_terracotta
setblock 535 250 270 minecraft:magenta_terracotta
setblock 539 250 228 minecraft:magenta_terracotta
setblock 539 250 270 minecraft:magenta_terracotta
setblock 541 250 231 minecraft:light[level=12]
setblock 541 250 238 minecraft:light[level=12]
setblock 541 250 245 minecraft:light[level=12]
setblock 541 250 252 minecraft:light[level=12]
setblock 541 250 259 minecraft:light[level=12]
setblock 541 250 266 minecraft:light[level=12]
setblock 543 250 228 minecraft:magenta_terracotta
setblock 543 250 270 minecraft:magenta_terracotta
setblock 547 250 228 minecraft:magenta_terracotta
setblock 547 250 270 minecraft:magenta_terracotta
setblock 548 250 231 minecraft:light[level=12]
setblock 548 250 238 minecraft:light[level=12]
setblock 548 250 245 minecraft:light[level=12]
setblock 548 250 252 minecraft:light[level=12]
setblock 548 250 259 minecraft:light[level=12]
setblock 548 250 266 minecraft:light[level=12]
setblock 551 250 228 minecraft:magenta_terracotta
setblock 551 250 270 minecraft:magenta_terracotta
setblock 555 250 228 minecraft:magenta_terracotta
setblock 555 250 231 minecraft:light[level=12]
setblock 555 250 238 minecraft:light[level=12]
setblock 555 250 245 minecraft:light[level=12]
setblock 555 250 252 minecraft:light[level=12]
setblock 555 250 259 minecraft:light[level=12]
setblock 555 250 266 minecraft:light[level=12]
setblock 555 250 270 minecraft:magenta_terracotta
fill 557 250 243 557 250 244 minecraft:spruce_planks
fill 557 250 245 558 250 246 minecraft:dark_oak_planks
setblock 559 250 228 minecraft:magenta_terracotta
setblock 559 250 230 minecraft:magenta_terracotta
setblock 559 250 234 minecraft:magenta_terracotta
setblock 559 250 238 minecraft:magenta_terracotta
setblock 559 250 242 minecraft:magenta_terracotta
setblock 559 250 246 minecraft:magenta_terracotta
setblock 559 250 250 minecraft:magenta_terracotta
setblock 559 250 254 minecraft:magenta_terracotta
setblock 559 250 258 minecraft:magenta_terracotta
setblock 559 250 262 minecraft:magenta_terracotta
fill 559 250 265 559 278 265 minecraft:purple_terracotta
setblock 559 250 266 minecraft:magenta_terracotta
setblock 559 250 270 minecraft:magenta_terracotta
fill 517 251 230 517 253 230 minecraft:purple_terracotta
fill 517 251 234 517 253 234 minecraft:purple_terracotta
fill 517 251 238 517 253 238 minecraft:purple_terracotta
fill 517 251 242 517 253 242 minecraft:purple_terracotta
fill 517 251 246 517 253 246 minecraft:purple_terracotta
fill 517 251 250 517 253 250 minecraft:purple_terracotta
fill 517 251 254 517 253 254 minecraft:purple_terracotta
fill 517 251 258 517 253 258 minecraft:purple_terracotta
fill 517 251 262 517 253 262 minecraft:purple_terracotta
fill 517 251 266 517 253 266 minecraft:purple_terracotta
setblock 517 251 270 minecraft:purple_terracotta
fill 519 251 228 519 253 228 minecraft:purple_terracotta
fill 519 251 270 519 253 270 minecraft:purple_terracotta
fill 523 251 228 523 253 228 minecraft:purple_terracotta
fill 523 251 270 523 253 270 minecraft:purple_terracotta
setblock 525 251 228 minecraft:gray_terracotta
fill 527 251 228 527 253 228 minecraft:purple_terracotta
fill 527 251 270 527 253 270 minecraft:purple_terracotta
setblock 531 251 228 minecraft:purple_terracotta
fill 531 251 270 531 253 270 minecraft:purple_terracotta
fill 535 251 228 535 253 228 minecraft:purple_terracotta
fill 535 251 270 535 253 270 minecraft:purple_terracotta
fill 539 251 228 539 253 228 minecraft:purple_terracotta
fill 539 251 270 539 253 270 minecraft:purple_terracotta
setblock 542 251 270 minecraft:black_terracotta
fill 543 251 228 543 253 228 minecraft:purple_terracotta
fill 543 251 270 543 253 270 minecraft:purple_terracotta
fill 547 251 228 547 253 228 minecraft:purple_terracotta
fill 547 251 270 547 253 270 minecraft:purple_terracotta
fill 551 251 228 551 253 228 minecraft:purple_terracotta
fill 551 251 270 551 253 270 minecraft:purple_terracotta
fill 555 251 228 555 253 228 minecraft:purple_terracotta
fill 555 251 270 555 253 270 minecraft:purple_terracotta
fill 557 251 241 557 251 242 minecraft:spruce_planks
fill 557 251 243 558 251 244 minecraft:dark_oak_planks
setblock 559 251 228 minecraft:purple_terracotta
fill 559 251 230 559 253 230 minecraft:purple_terracotta
fill 559 251 234 559 253 234 minecraft:purple_terracotta
fill 559 251 238 559 253 238 minecraft:purple_terracotta
fill 559 251 242 559 253 242 minecraft:purple_terracotta
fill 559 251 246 559 253 246 minecraft:purple_terracotta
fill 559 251 250 559 253 250 minecraft:purple_terracotta
fill 559 251 254 559 253 254 minecraft:purple_terracotta
fill 559 251 258 559 253 258 minecraft:purple_terracotta
fill 559 251 262 559 253 262 minecraft:purple_terracotta
fill 559 251 266 559 253 266 minecraft:purple_terracotta
fill 559 251 270 559 253 270 minecraft:purple_terracotta
setblock 517 252 228 minecraft:magenta_terracotta
setblock 517 252 232 minecraft:magenta_terracotta
setblock 517 252 236 minecraft:magenta_terracotta
setblock 517 252 240 minecraft:magenta_terracotta
setblock 517 252 244 minecraft:magenta_terracotta
setblock 517 252 248 minecraft:magenta_terracotta
setblock 517 252 252 minecraft:magenta_terracotta
setblock 517 252 256 minecraft:magenta_terracotta
setblock 517 252 260 minecraft:magenta_terracotta
setblock 517 252 264 minecraft:magenta_terracotta
setblock 517 252 268 minecraft:magenta_terracotta
setblock 517 252 270 minecraft:magenta_terracotta
setblock 521 252 228 minecraft:magenta_terracotta
setblock 521 252 270 minecraft:magenta_terracotta
setblock 525 252 228 minecraft:magenta_terracotta
setblock 525 252 270 minecraft:magenta_terracotta
setblock 529 252 228 minecraft:magenta_terracotta
setblock 529 252 270 minecraft:magenta_terracotta
setblock 531 252 228 minecraft:black_terracotta
setblock 533 252 228 minecraft:magenta_terracotta
setblock 533 252 270 minecraft:magenta_terracotta
setblock 537 252 228 minecraft:magenta_terracotta
setblock 537 252 270 minecraft:magenta_terracotta
setblock 541 252 228 minecraft:magenta_terracotta
setblock 541 252 270 minecraft:magenta_terracotta
fill 542 252 270 542 278 270 minecraft:purple_terracotta
fill 544 252 228 544 278 228 minecraft:purple_terracotta
setblock 545 252 228 minecraft:magenta_terracotta
setblock 545 252 270 minecraft:magenta_terracotta
setblock 549 252 228 minecraft:magenta_terracotta
setblock 549 252 270 minecraft:magenta_terracotta
setblock 553 252 228 minecraft:magenta_terracotta
setblock 553 252 270 minecraft:magenta_terracotta
setblock 557 252 228 minecraft:magenta_terracotta
fill 557 252 239 557 252 240 minecraft:spruce_planks
fill 557 252 241 558 252 242 minecraft:dark_oak_planks
setblock 557 252 270 minecraft:magenta_terracotta
setblock 559 252 228 minecraft:magenta_terracotta
setblock 559 252 232 minecraft:magenta_terracotta
setblock 559 252 236 minecraft:magenta_terracotta
setblock 559 252 240 minecraft:magenta_terracotta
setblock 559 252 244 minecraft:magenta_terracotta
setblock 559 252 248 minecraft:magenta_terracotta
setblock 559 252 252 minecraft:magenta_terracotta
setblock 559 252 256 minecraft:magenta_terracotta
setblock 559 252 260 minecraft:magenta_terracotta
setblock 559 252 264 minecraft:magenta_terracotta
setblock 559 252 268 minecraft:magenta_terracotta
fill 517 253 228 517 255 228 minecraft:purple_terracotta
fill 517 253 232 517 255 232 minecraft:purple_terracotta
fill 517 253 236 517 255 236 minecraft:purple_terracotta
fill 517 253 240 517 255 240 minecraft:purple_terracotta
fill 517 253 244 517 255 244 minecraft:purple_terracotta
fill 517 253 248 517 255 248 minecraft:purple_terracotta
fill 517 253 252 517 255 252 minecraft:purple_terracotta
fill 517 253 256 517 255 256 minecraft:purple_terracotta
fill 517 253 260 517 255 260 minecraft:purple_terracotta
fill 517 253 264 517 255 264 minecraft:purple_terracotta
fill 517 253 268 517 255 268 minecraft:purple_terracotta
setblock 517 253 270 minecraft:purple_terracotta
fill 521 253 228 521 255 228 minecraft:purple_terracotta
fill 521 253 270 521 255 270 minecraft:purple_terracotta
fill 525 253 228 525 255 228 minecraft:purple_terracotta
fill 525 253 270 525 255 270 minecraft:purple_terracotta
fill 529 253 228 529 255 228 minecraft:purple_terracotta
fill 529 253 270 529 255 270 minecraft:purple_terracotta
setblock 531 253 228 minecraft:purple_terracotta
fill 533 253 228 533 255 228 minecraft:purple_terracotta
fill 533 253 270 533 255 270 minecraft:purple_terracotta
fill 534 253 253 534 262 253 minecraft:iron_bars
fill 537 253 228 537 255 228 minecraft:purple_terracotta
fill 537 253 270 537 255 270 minecraft:purple_terracotta
fill 541 253 228 541 255 228 minecraft:purple_terracotta
fill 541 253 270 541 255 270 minecraft:purple_terracotta
fill 545 253 228 545 255 228 minecraft:purple_terracotta
fill 545 253 270 545 255 270 minecraft:purple_terracotta
fill 549 253 228 549 255 228 minecraft:purple_terracotta
fill 549 253 270 549 255 270 minecraft:purple_terracotta
fill 553 253 228 553 255 228 minecraft:purple_terracotta
fill 553 253 270 553 255 270 minecraft:purple_terracotta
fill 557 253 228 557 255 228 minecraft:purple_terracotta
fill 557 253 237 557 253 238 minecraft:spruce_planks
fill 557 253 239 558 253 240 minecraft:dark_oak_planks
fill 557 253 270 557 255 270 minecraft:purple_terracotta
setblock 559 253 228 minecraft:purple_terracotta
fill 559 253 232 559 255 232 minecraft:purple_terracotta
fill 559 253 236 559 255 236 minecraft:purple_terracotta
fill 559 253 240 559 255 240 minecraft:purple_terracotta
fill 559 253 244 559 255 244 minecraft:purple_terracotta
fill 559 253 248 559 255 248 minecraft:purple_terracotta
fill 559 253 252 559 255 252 minecraft:purple_terracotta
fill 559 253 256 559 255 256 minecraft:purple_terracotta
fill 559 253 260 559 255 260 minecraft:purple_terracotta
fill 559 253 264 559 255 264 minecraft:purple_terracotta
fill 559 253 268 559 255 268 minecraft:purple_terracotta
setblock 517 254 230 minecraft:magenta_terracotta
setblock 517 254 234 minecraft:magenta_terracotta
setblock 517 254 238 minecraft:magenta_terracotta
setblock 517 254 242 minecraft:magenta_terracotta
setblock 517 254 246 minecraft:magenta_terracotta
setblock 517 254 250 minecraft:magenta_terracotta
setblock 517 254 254 minecraft:magenta_terracotta
setblock 517 254 258 minecraft:magenta_terracotta
setblock 517 254 262 minecraft:magenta_terracotta
setblock 517 254 266 minecraft:magenta_terracotta
setblock 517 254 270 minecraft:magenta_terracotta
setblock 519 254 228 minecraft:magenta_terracotta
setblock 519 254 270 minecraft:magenta_terracotta
setblock 523 254 228 minecraft:magenta_terracotta
setblock 523 254 270 minecraft:magenta_terracotta
fill 524 254 253 524 256 254 minecraft:white_stained_glass
fill 525 254 253 525 256 253 minecraft:white_stained_glass
fill 525 254 255 525 256 255 minecraft:white_stained_glass
fill 526 254 254 526 256 254 minecraft:white_stained_glass
setblock 527 254 228 minecraft:magenta_terracotta
setblock 527 254 270 minecraft:magenta_terracotta
setblock 531 254 228 minecraft:magenta_terracotta
setblock 531 254 270 minecraft:magenta_terracotta
setblock 535 254 228 minecraft:magenta_terracotta
setblock 535 254 270 minecraft:magenta_terracotta
setblock 539 254 228 minecraft:magenta_terracotta
setblock 539 254 270 minecraft:magenta_terracotta
fill 541 254 253 541 266 253 minecraft:iron_bars
setblock 543 254 228 minecraft:magenta_terracotta
setblock 543 254 270 minecraft:magenta_terracotta
fill 546 254 253 546 256 254 minecraft:white_stained_glass
setblock 547 254 228 minecraft:magenta_terracotta
fill 547 254 252 547 256 253 minecraft:white_stained_glass
setblock 547 254 270 minecraft:magenta_terracotta
setblock 551 254 228 minecraft:magenta_terracotta
setblock 551 254 270 minecraft:magenta_terracotta
setblock 555 254 228 minecraft:magenta_terracotta
setblock 555 254 270 minecraft:magenta_terracotta
fill 557 254 235 557 254 236 minecraft:spruce_planks
fill 557 254 237 558 254 238 minecraft:dark_oak_planks
setblock 559 254 228 minecraft:magenta_terracotta
setblock 559 254 230 minecraft:magenta_terracotta
setblock 559 254 234 minecraft:magenta_terracotta
setblock 559 254 238 minecraft:magenta_terracotta
setblock 559 254 242 minecraft:magenta_terracotta
setblock 559 254 246 minecraft:magenta_terracotta
setblock 559 254 250 minecraft:magenta_terracotta
setblock 559 254 251 minecraft:black_terracotta
setblock 559 254 254 minecraft:magenta_terracotta
setblock 559 254 258 minecraft:magenta_terracotta
setblock 559 254 262 minecraft:magenta_terracotta
setblock 559 254 266 minecraft:magenta_terracotta
setblock 559 254 270 minecraft:magenta_terracotta
fill 517 255 230 517 257 230 minecraft:purple_terracotta
fill 517 255 234 517 257 234 minecraft:purple_terracotta
fill 517 255 238 517 257 238 minecraft:purple_terracotta
fill 517 255 242 517 257 242 minecraft:purple_terracotta
fill 517 255 246 517 257 246 minecraft:purple_terracotta
fill 517 255 250 517 257 250 minecraft:purple_terracotta
fill 517 255 254 517 257 254 minecraft:purple_terracotta
fill 517 255 258 517 257 258 minecraft:purple_terracotta
fill 517 255 262 517 257 262 minecraft:purple_terracotta
fill 517 255 266 517 257 266 minecraft:purple_terracotta
setblock 517 255 270 minecraft:purple_terracotta
fill 519 255 228 519 257 228 minecraft:purple_terracotta
fill 519 255 270 519 257 270 minecraft:purple_terracotta
fill 523 255 228 523 257 228 minecraft:purple_terracotta
fill 523 255 254 523 258 254 minecraft:white_stained_glass
fill 523 255 270 523 257 270 minecraft:purple_terracotta
fill 524 255 252 526 256 252 minecraft:white_stained_glass
fill 524 255 255 524 257 255 minecraft:white_stained_glass
fill 525 255 254 525 256 254 minecraft:white_stained_glass
fill 526 255 253 526 256 253 minecraft:white_stained_glass
fill 526 255 255 526 257 255 minecraft:white_stained_glass
fill 527 255 228 527 257 228 minecraft:purple_terracotta
fill 527 255 270 527 257 270 minecraft:purple_terracotta
fill 531 255 228 531 257 228 minecraft:purple_terracotta
fill 531 255 270 531 257 270 minecraft:purple_terracotta
fill 535 255 228 535 257 228 minecraft:purple_terracotta
fill 535 255 270 535 257 270 minecraft:purple_terracotta
fill 539 255 228 539 257 228 minecraft:purple_terracotta
fill 539 255 270 539 257 270 minecraft:purple_terracotta
fill 543 255 228 543 257 228 minecraft:purple_terracotta
fill 543 255 270 543 257 270 minecraft:purple_terracotta
fill 545 255 253 545 258 253 minecraft:white_stained_glass
fill 546 255 252 546 256 252 minecraft:white_stained_glass
fill 547 255 228 547 257 228 minecraft:purple_terracotta
fill 547 255 251 547 256 251 minecraft:white_stained_glass
fill 547 255 254 548 256 254 minecraft:white_stained_glass
fill 547 255 270 547 257 270 minecraft:purple_terracotta
fill 548 255 252 548 256 253 minecraft:white_stained_glass
fill 551 255 228 551 257 228 minecraft:purple_terracotta
fill 551 255 270 551 257 270 minecraft:purple_terracotta
fill 555 255 228 555 257 228 minecraft:purple_terracotta
fill 555 255 270 555 257 270 minecraft:purple_terracotta
fill 557 255 233 557 255 234 minecraft:spruce_planks
fill 557 255 235 558 255 236 minecraft:dark_oak_planks
setblock 559 255 228 minecraft:purple_terracotta
fill 559 255 230 559 257 230 minecraft:purple_terracotta
fill 559 255 234 559 257 234 minecraft:purple_terracotta
setblock 559 255 238 minecraft:purple_terracotta
fill 559 255 242 559 257 242 minecraft:purple_terracotta
fill 559 255 246 559 257 246 minecraft:purple_terracotta
fill 559 255 250 559 257 251 minecraft:purple_terracotta
fill 559 255 254 559 257 254 minecraft:purple_terracotta
fill 559 255 258 559 257 258 minecraft:purple_terracotta
fill 559 255 262 559 257 262 minecraft:purple_terracotta
fill 559 255 266 559 257 266 minecraft:purple_terracotta
fill 559 255 270 559 257 270 minecraft:purple_terracotta
setblock 517 256 228 minecraft:magenta_terracotta
setblock 517 256 232 minecraft:magenta_terracotta
setblock 517 256 236 minecraft:magenta_terracotta
setblock 517 256 240 minecraft:magenta_terracotta
setblock 517 256 244 minecraft:magenta_terracotta
setblock 517 256 248 minecraft:magenta_terracotta
setblock 517 256 252 minecraft:magenta_terracotta
setblock 517 256 256 minecraft:magenta_terracotta
setblock 517 256 260 minecraft:magenta_terracotta
setblock 517 256 264 minecraft:magenta_terracotta
setblock 517 256 268 minecraft:magenta_terracotta
setblock 517 256 270 minecraft:magenta_terracotta
setblock 520 256 231 minecraft:light[level=11]
setblock 520 256 238 minecraft:light[level=12]
setblock 520 256 239 minecraft:light[level=11]
setblock 520 256 245 minecraft:light[level=12]
setblock 520 256 247 minecraft:light[level=11]
setblock 520 256 252 minecraft:light[level=12]
setblock 520 256 255 minecraft:light[level=11]
setblock 520 256 259 minecraft:light[level=12]
setblock 520 256 263 minecraft:light[level=11]
setblock 520 256 266 minecraft:light[level=12]
setblock 521 256 228 minecraft:magenta_terracotta
setblock 521 256 270 minecraft:magenta_terracotta
fill 523 256 253 523 257 253 minecraft:white_stained_glass
setblock 525 256 228 minecraft:magenta_terracotta
setblock 525 256 270 minecraft:magenta_terracotta
setblock 527 256 231 minecraft:light[level=12]
setblock 527 256 238 minecraft:light[level=12]
setblock 527 256 245 minecraft:light[level=12]
setblock 527 256 252 minecraft:light[level=12]
fill 527 256 254 527 257 254 minecraft:white_stained_glass
setblock 527 256 259 minecraft:light[level=12]
setblock 527 256 266 minecraft:light[level=12]
setblock 528 256 231 minecraft:light[level=11]
setblock 528 256 239 minecraft:light[level=11]
setblock 528 256 247 minecraft:light[level=11]
setblock 528 256 255 minecraft:light[level=11]
setblock 528 256 263 minecraft:light[level=11]
setblock 529 256 228 minecraft:magenta_terracotta
setblock 529 256 270 minecraft:magenta_terracotta
setblock 533 256 228 minecraft:magenta_terracotta
setblock 533 256 270 minecraft:magenta_terracotta
setblock 534 256 231 minecraft:light[level=12]
setblock 534 256 238 minecraft:light[level=12]
setblock 534 256 245 minecraft:light[level=12]
setblock 534 256 252 minecraft:light[level=12]
setblock 534 256 259 minecraft:light[level=12]
setblock 534 256 266 minecraft:light[level=12]
setblock 536 256 231 minecraft:light[level=11]
setblock 536 256 239 minecraft:light[level=11]
setblock 536 256 247 minecraft:light[level=11]
setblock 536 256 255 minecraft:light[level=11]
setblock 536 256 263 minecraft:light[level=11]
setblock 537 256 228 minecraft:magenta_terracotta
setblock 537 256 270 minecraft:magenta_terracotta
setblock 541 256 228 minecraft:magenta_terracotta
setblock 541 256 231 minecraft:light[level=12]
setblock 541 256 238 minecraft:light[level=12]
setblock 541 256 245 minecraft:light[level=12]
setblock 541 256 252 minecraft:light[level=12]
setblock 541 256 259 minecraft:light[level=12]
setblock 541 256 266 minecraft:light[level=12]
setblock 541 256 270 minecraft:magenta_terracotta
setblock 544 256 231 minecraft:light[level=11]
setblock 544 256 239 minecraft:light[level=11]
setblock 544 256 247 minecraft:light[level=11]
setblock 544 256 255 minecraft:light[level=11]
setblock 544 256 263 minecraft:light[level=11]
setblock 545 256 228 minecraft:magenta_terracotta
fill 545 256 252 545 257 252 minecraft:white_stained_glass
fill 545 256 254 545 257 254 minecraft:white_stained_glass
setblock 545 256 270 minecraft:magenta_terracotta
fill 546 256 251 546 257 251 minecraft:white_stained_glass
fill 547 256 255 547 257 255 minecraft:white_stained_glass
setblock 548 256 231 minecraft:light[level=12]
setblock 548 256 238 minecraft:light[level=12]
setblock 548 256 245 minecraft:light[level=12]
setblock 548 256 259 minecraft:light[level=12]
setblock 548 256 266 minecraft:light[level=12]
setblock 549 256 228 minecraft:magenta_terracotta
fill 549 256 253 549 257 253 minecraft:white_stained_glass
setblock 549 256 270 minecraft:magenta_terracotta
setblock 552 256 231 minecraft:light[level=11]
setblock 552 256 239 minecraft:light[level=11]
setblock 552 256 247 minecraft:light[level=11]
setblock 552 256 255 minecraft:light[level=11]
setblock 552 256 263 minecraft:light[level=11]
setblock 553 256 228 minecraft:magenta_terracotta
setblock 553 256 270 minecraft:magenta_terracotta
setblock 555 256 231 minecraft:light[level=12]
setblock 555 256 238 minecraft:light[level=12]
setblock 555 256 245 minecraft:light[level=12]
setblock 555 256 252 minecraft:light[level=12]
setblock 555 256 259 minecraft:light[level=12]
setblock 555 256 266 minecraft:light[level=12]
setblock 557 256 228 minecraft:magenta_terracotta
fill 557 256 231 557 256 232 minecraft:spruce_planks
fill 557 256 233 558 256 234 minecraft:dark_oak_planks
setblock 557 256 270 minecraft:magenta_terracotta
setblock 559 256 228 minecraft:magenta_terracotta
setblock 559 256 232 minecraft:magenta_terracotta
setblock 559 256 236 minecraft:magenta_terracotta
setblock 559 256 238 minecraft:black_terracotta
setblock 559 256 240 minecraft:magenta_terracotta
setblock 559 256 244 minecraft:magenta_terracotta
setblock 559 256 248 minecraft:magenta_terracotta
setblock 559 256 252 minecraft:magenta_terracotta
setblock 559 256 256 minecraft:magenta_terracotta
setblock 559 256 260 minecraft:magenta_terracotta
setblock 559 256 264 minecraft:magenta_terracotta
setblock 559 256 268 minecraft:magenta_terracotta
fill 517 257 228 517 259 228 minecraft:purple_terracotta
fill 517 257 232 517 259 232 minecraft:purple_terracotta
fill 517 257 236 517 259 236 minecraft:purple_terracotta
fill 517 257 240 517 259 240 minecraft:purple_terracotta
fill 517 257 244 517 259 244 minecraft:purple_terracotta
fill 517 257 248 517 259 248 minecraft:purple_terracotta
fill 517 257 252 517 259 252 minecraft:purple_terracotta
setblock 517 257 253 minecraft:light_gray_terracotta
fill 517 257 256 517 259 256 minecraft:purple_terracotta
fill 517 257 260 517 259 260 minecraft:purple_terracotta
fill 517 257 264 517 259 264 minecraft:purple_terracotta
fill 517 257 268 517 259 268 minecraft:purple_terracotta
setblock 517 257 270 minecraft:purple_terracotta
fill 521 257 228 521 259 228 minecraft:purple_terracotta
fill 521 257 270 521 259 270 minecraft:purple_terracotta
setblock 524 257 252 minecraft:white_stained_glass
fill 524 257 253 526 259 254 minecraft:white_concrete
fill 525 257 228 525 259 228 minecraft:purple_terracotta
setblock 525 257 252 minecraft:black_concrete
fill 525 257 255 525 259 255 minecraft:white_concrete
fill 525 257 270 525 259 270 minecraft:purple_terracotta
setblock 526 257 252 minecraft:white_stained_glass
fill 529 257 228 529 259 228 minecraft:purple_terracotta
fill 529 257 270 529 259 270 minecraft:purple_terracotta
fill 533 257 228 533 259 228 minecraft:purple_terracotta
fill 533 257 270 533 259 270 minecraft:purple_terracotta
fill 537 257 228 537 259 228 minecraft:purple_terracotta
fill 537 257 270 537 259 270 minecraft:purple_terracotta
fill 541 257 228 541 259 228 minecraft:purple_terracotta
fill 541 257 270 541 259 270 minecraft:purple_terracotta
fill 543 257 231 547 258 235 minecraft:dark_oak_planks
fill 545 257 228 545 259 228 minecraft:purple_terracotta
fill 545 257 229 545 257 230 minecraft:dark_oak_planks
fill 545 257 270 545 259 270 minecraft:purple_terracotta
fill 546 257 252 547 259 254 minecraft:white_concrete
setblock 547 257 251 minecraft:black_concrete
setblock 548 257 252 minecraft:white_stained_glass
fill 548 257 253 548 259 253 minecraft:white_concrete
setblock 548 257 254 minecraft:white_stained_glass
fill 549 257 228 549 259 228 minecraft:purple_terracotta
fill 549 257 270 549 259 270 minecraft:purple_terracotta
fill 553 257 228 553 259 228 minecraft:purple_terracotta
fill 553 257 270 553 259 270 minecraft:purple_terracotta
fill 557 257 228 557 259 228 minecraft:purple_terracotta
setblock 557 257 230 minecraft:spruce_planks
fill 557 257 231 558 257 232 minecraft:dark_oak_planks
fill 557 257 270 557 259 270 minecraft:purple_terracotta
setblock 559 257 228 minecraft:purple_terracotta
fill 559 257 232 559 259 232 minecraft:purple_terracotta
fill 559 257 236 559 259 236 minecraft:purple_terracotta
setblock 559 257 238 minecraft:purple_terracotta
fill 559 257 240 559 259 240 minecraft:purple_terracotta
fill 559 257 244 559 259 244 minecraft:purple_terracotta
fill 559 257 248 559 259 248 minecraft:purple_terracotta
fill 559 257 252 559 259 252 minecraft:purple_terracotta
fill 559 257 256 559 259 256 minecraft:purple_terracotta
fill 559 257 260 559 259 260 minecraft:purple_terracotta
fill 559 257 264 559 259 264 minecraft:purple_terracotta
fill 559 257 268 559 259 268 minecraft:purple_terracotta
setblock 517 258 230 minecraft:magenta_terracotta
setblock 517 258 234 minecraft:magenta_terracotta
setblock 517 258 238 minecraft:magenta_terracotta
setblock 517 258 242 minecraft:magenta_terracotta
setblock 517 258 246 minecraft:gray_terracotta
setblock 517 258 250 minecraft:magenta_terracotta
fill 517 258 253 517 278 253 minecraft:purple_terracotta
setblock 517 258 254 minecraft:magenta_terracotta
setblock 517 258 258 minecraft:gray_terracotta
setblock 517 258 262 minecraft:magenta_terracotta
setblock 517 258 266 minecraft:magenta_terracotta
setblock 517 258 270 minecraft:magenta_terracotta
setblock 519 258 228 minecraft:magenta_terracotta
setblock 519 258 270 minecraft:magenta_terracotta
setblock 523 258 228 minecraft:magenta_terracotta
setblock 523 258 270 minecraft:magenta_terracotta
setblock 524 258 252 minecraft:black_concrete
setblock 524 258 255 minecraft:white_concrete
setblock 525 258 252 minecraft:white_concrete
setblock 526 258 252 minecraft:black_concrete
setblock 526 258 255 minecraft:white_concrete
setblock 527 258 228 minecraft:magenta_terracotta
setblock 527 258 270 minecraft:magenta_terracotta
setblock 531 258 228 minecraft:magenta_terracotta
setblock 531 258 270 minecraft:magenta_terracotta
setblock 535 258 228 minecraft:magenta_terracotta
setblock 535 258 270 minecraft:magenta_terracotta
setblock 539 258 228 minecraft:magenta_terracotta
setblock 539 258 270 minecraft:magenta_terracotta
setblock 543 258 228 minecraft:magenta_terracotta
setblock 543 258 270 minecraft:magenta_terracotta
setblock 547 258 228 minecraft:magenta_terracotta
setblock 547 258 251 minecraft:white_stained_glass
setblock 547 258 270 minecraft:magenta_terracotta
setblock 548 258 252 minecraft:white_concrete
setblock 548 258 254 minecraft:white_concrete
setblock 551 258 228 minecraft:magenta_terracotta
setblock 551 258 270 minecraft:magenta_terracotta
setblock 555 258 228 minecraft:magenta_terracotta
fill 555 258 230 556 258 230 minecraft:spruce_planks
setblock 555 258 270 minecraft:magenta_terracotta
fill 557 258 229 558 258 230 minecraft:dark_oak_planks
setblock 559 258 228 minecraft:magenta_terracotta
setblock 559 258 230 minecraft:magenta_terracotta
setblock 559 258 234 minecraft:magenta_terracotta
setblock 559 258 238 minecraft:magenta_terracotta
setblock 559 258 242 minecraft:magenta_terracotta
setblock 559 258 246 minecraft:magenta_terracotta
setblock 559 258 250 minecraft:magenta_terracotta
fill 559 258 251 559 267 251 minecraft:purple_terracotta
setblock 559 258 254 minecraft:magenta_terracotta
setblock 559 258 258 minecraft:magenta_terracotta
setblock 559 258 262 minecraft:magenta_terracotta
setblock 559 258 266 minecraft:magenta_terracotta
setblock 559 258 270 minecraft:magenta_terracotta
fill 517 259 230 517 261 230 minecraft:purple_terracotta
fill 517 259 234 517 261 234 minecraft:purple_terracotta
fill 517 259 238 517 261 238 minecraft:purple_terracotta
fill 517 259 242 517 261 242 minecraft:purple_terracotta
fill 517 259 246 517 261 246 minecraft:purple_terracotta
fill 517 259 250 517 261 250 minecraft:purple_terracotta
fill 517 259 254 517 261 254 minecraft:purple_terracotta
fill 517 259 258 517 261 258 minecraft:purple_terracotta
fill 517 259 262 517 261 262 minecraft:purple_terracotta
fill 517 259 266 517 261 266 minecraft:purple_terracotta
setblock 517 259 270 minecraft:purple_terracotta
fill 519 259 228 519 261 228 minecraft:purple_terracotta
fill 519 259 270 519 261 270 minecraft:purple_terracotta
fill 523 259 228 523 261 228 minecraft:purple_terracotta
fill 523 259 270 523 261 270 minecraft:purple_terracotta
fill 527 259 228 527 261 228 minecraft:purple_terracotta
fill 527 259 270 527 261 270 minecraft:purple_terracotta
fill 531 259 228 531 261 228 minecraft:purple_terracotta
fill 531 259 270 531 261 270 minecraft:purple_terracotta
fill 535 259 228 535 261 228 minecraft:purple_terracotta
fill 535 259 270 535 261 270 minecraft:purple_terracotta
fill 539 259 228 539 261 228 minecraft:purple_terracotta
fill 539 259 270 539 261 270 minecraft:purple_terracotta
fill 543 259 228 543 261 228 minecraft:purple_terracotta
fill 543 259 270 543 261 270 minecraft:purple_terracotta
fill 544 259 233 546 265 233 minecraft:purple_concrete
fill 545 259 232 545 265 232 minecraft:purple_concrete
fill 545 259 234 545 265 234 minecraft:purple_concrete
fill 547 259 228 547 261 228 minecraft:purple_terracotta
fill 547 259 270 547 261 270 minecraft:purple_terracotta
fill 551 259 228 551 261 228 minecraft:purple_terracotta
fill 551 259 255 555 260 259 minecraft:dark_oak_planks
fill 551 259 270 551 261 270 minecraft:purple_terracotta
fill 553 259 230 554 259 230 minecraft:spruce_planks
fill 555 259 228 555 261 228 minecraft:purple_terracotta
fill 555 259 229 556 259 230 minecraft:dark_oak_planks
fill 555 259 270 555 261 270 minecraft:purple_terracotta
fill 556 259 257 557 259 257 minecraft:dark_oak_planks
setblock 559 259 228 minecraft:purple_terracotta
fill 559 259 230 559 261 230 minecraft:purple_terracotta
fill 559 259 234 559 261 234 minecraft:purple_terracotta
fill 559 259 238 559 261 238 minecraft:purple_terracotta
fill 559 259 242 559 261 242 minecraft:purple_terracotta
fill 559 259 246 559 261 246 minecraft:purple_terracotta
fill 559 259 250 559 261 250 minecraft:purple_terracotta
fill 559 259 254 559 261 254 minecraft:purple_terracotta
fill 559 259 258 559 261 258 minecraft:purple_terracotta
fill 559 259 262 559 261 262 minecraft:purple_terracotta
fill 559 259 266 559 261 266 minecraft:purple_terracotta
fill 559 259 270 559 261 270 minecraft:purple_terracotta
setblock 517 260 228 minecraft:magenta_terracotta
setblock 517 260 232 minecraft:magenta_terracotta
setblock 517 260 236 minecraft:magenta_terracotta
setblock 517 260 240 minecraft:magenta_terracotta
setblock 517 260 244 minecraft:magenta_terracotta
setblock 517 260 248 minecraft:magenta_terracotta
setblock 517 260 252 minecraft:magenta_terracotta
setblock 517 260 256 minecraft:magenta_terracotta
setblock 517 260 260 minecraft:magenta_terracotta
setblock 517 260 264 minecraft:magenta_terracotta
setblock 517 260 268 minecraft:magenta_terracotta
setblock 517 260 270 minecraft:magenta_terracotta
setblock 521 260 228 minecraft:magenta_terracotta
setblock 521 260 270 minecraft:magenta_terracotta
setblock 525 260 228 minecraft:magenta_terracotta
setblock 525 260 270 minecraft:magenta_terracotta
setblock 529 260 228 minecraft:magenta_terracotta
setblock 529 260 270 minecraft:magenta_terracotta
setblock 533 260 228 minecraft:magenta_terracotta
setblock 533 260 270 minecraft:magenta_terracotta
setblock 537 260 228 minecraft:magenta_terracotta
setblock 537 260 270 minecraft:magenta_terracotta
setblock 541 260 228 minecraft:magenta_terracotta
setblock 541 260 270 minecraft:magenta_terracotta
setblock 545 260 228 minecraft:magenta_terracotta
setblock 545 260 270 minecraft:magenta_terracotta
setblock 549 260 228 minecraft:magenta_terracotta
setblock 549 260 270 minecraft:magenta_terracotta
fill 551 260 230 552 260 230 minecraft:spruce_planks
setblock 553 260 228 minecraft:magenta_terracotta
fill 553 260 229 554 260 230 minecraft:dark_oak_planks
setblock 553 260 270 minecraft:magenta_terracotta
setblock 557 260 228 minecraft:magenta_terracotta
setblock 557 260 270 minecraft:magenta_terracotta
setblock 559 260 228 minecraft:magenta_terracotta
setblock 559 260 232 minecraft:magenta_terracotta
setblock 559 260 236 minecraft:magenta_terracotta
setblock 559 260 240 minecraft:magenta_terracotta
setblock 559 260 244 minecraft:magenta_terracotta
setblock 559 260 248 minecraft:magenta_terracotta
setblock 559 260 252 minecraft:magenta_terracotta
setblock 559 260 256 minecraft:magenta_terracotta
setblock 559 260 260 minecraft:magenta_terracotta
setblock 559 260 264 minecraft:magenta_terracotta
setblock 559 260 268 minecraft:magenta_terracotta
fill 517 261 228 517 263 228 minecraft:purple_terracotta
fill 517 261 232 517 263 232 minecraft:purple_terracotta
fill 517 261 236 517 263 236 minecraft:purple_terracotta
fill 517 261 240 517 263 240 minecraft:purple_terracotta
fill 517 261 244 517 263 244 minecraft:purple_terracotta
fill 517 261 248 517 263 248 minecraft:purple_terracotta
setblock 517 261 251 minecraft:light_gray_terracotta
fill 517 261 252 517 263 252 minecraft:purple_terracotta
fill 517 261 256 517 263 256 minecraft:purple_terracotta
fill 517 261 260 517 263 260 minecraft:purple_terracotta
fill 517 261 264 517 263 264 minecraft:purple_terracotta
fill 517 261 268 517 263 268 minecraft:purple_terracotta
setblock 517 261 270 minecraft:purple_terracotta
fill 521 261 228 521 263 228 minecraft:purple_terracotta
fill 521 261 270 521 263 270 minecraft:purple_terracotta
fill 525 261 228 525 263 228 minecraft:purple_terracotta
fill 525 261 270 525 263 270 minecraft:purple_terracotta
fill 529 261 228 529 263 228 minecraft:purple_terracotta
fill 529 261 270 529 263 270 minecraft:purple_terracotta
fill 533 261 228 533 263 228 minecraft:purple_terracotta
fill 533 261 270 533 263 270 minecraft:purple_terracotta
fill 537 261 228 537 263 228 minecraft:purple_terracotta
fill 537 261 270 537 263 270 minecraft:purple_terracotta
fill 541 261 228 541 263 228 minecraft:purple_terracotta
fill 541 261 270 541 263 270 minecraft:purple_terracotta
fill 545 261 228 545 263 228 minecraft:purple_terracotta
fill 545 261 270 545 263 270 minecraft:purple_terracotta
fill 549 261 228 549 263 228 minecraft:purple_terracotta
fill 549 261 230 550 261 230 minecraft:spruce_planks
fill 549 261 270 549 263 270 minecraft:purple_terracotta
fill 551 261 229 552 261 230 minecraft:dark_oak_planks
fill 552 261 257 554 265 257 minecraft:stripped_dark_oak_log
fill 553 261 228 553 263 228 minecraft:purple_terracotta
fill 553 261 270 553 263 270 minecraft:purple_terracotta
fill 557 261 228 557 263 228 minecraft:purple_terracotta
fill 557 261 270 557 263 270 minecraft:purple_terracotta
setblock 559 261 228 minecraft:purple_terracotta
fill 559 261 232 559 263 232 minecraft:purple_terracotta
fill 559 261 236 559 263 236 minecraft:purple_terracotta
fill 559 261 240 559 263 240 minecraft:purple_terracotta
fill 559 261 244 559 263 244 minecraft:purple_terracotta
fill 559 261 248 559 263 248 minecraft:purple_terracotta
fill 559 261 252 559 263 252 minecraft:purple_terracotta
fill 559 261 256 559 263 256 minecraft:purple_terracotta
fill 559 261 260 559 263 260 minecraft:purple_terracotta
fill 559 261 264 559 263 264 minecraft:purple_terracotta
fill 559 261 268 559 263 268 minecraft:purple_terracotta
setblock 517 262 230 minecraft:magenta_terracotta
setblock 517 262 234 minecraft:magenta_terracotta
setblock 517 262 238 minecraft:magenta_terracotta
setblock 517 262 242 minecraft:magenta_terracotta
setblock 517 262 246 minecraft:magenta_terracotta
setblock 517 262 250 minecraft:magenta_terracotta
fill 517 262 251 517 278 251 minecraft:purple_terracotta
setblock 517 262 254 minecraft:magenta_terracotta
setblock 517 262 258 minecraft:magenta_terracotta
setblock 517 262 262 minecraft:magenta_terracotta
setblock 517 262 266 minecraft:magenta_terracotta
setblock 517 262 270 minecraft:magenta_terracotta
setblock 519 262 228 minecraft:magenta_terracotta
setblock 519 262 270 minecraft:magenta_terracotta
setblock 520 262 231 minecraft:light[level=12]
setblock 520 262 238 minecraft:light[level=12]
setblock 520 262 245 minecraft:light[level=12]
setblock 520 262 252 minecraft:light[level=12]
setblock 520 262 259 minecraft:light[level=12]
setblock 520 262 266 minecraft:light[level=12]
setblock 523 262 228 minecraft:magenta_terracotta
setblock 523 262 270 minecraft:magenta_terracotta
setblock 527 262 228 minecraft:magenta_terracotta
setblock 527 262 231 minecraft:light[level=12]
setblock 527 262 238 minecraft:light[level=12]
setblock 527 262 245 minecraft:light[level=12]
setblock 527 262 252 minecraft:light[level=12]
setblock 527 262 259 minecraft:light[level=12]
setblock 527 262 266 minecraft:light[level=12]
setblock 527 262 270 minecraft:magenta_terracotta
setblock 531 262 228 minecraft:magenta_terracotta
setblock 531 262 270 minecraft:magenta_terracotta
setblock 534 262 231 minecraft:light[level=12]
setblock 534 262 238 minecraft:light[level=12]
setblock 534 262 245 minecraft:light[level=12]
setblock 534 262 252 minecraft:light[level=12]
setblock 534 262 259 minecraft:light[level=12]
setblock 534 262 266 minecraft:light[level=12]
setblock 535 262 228 minecraft:magenta_terracotta
setblock 535 262 270 minecraft:magenta_terracotta
setblock 539 262 228 minecraft:magenta_terracotta
setblock 539 262 270 minecraft:magenta_terracotta
setblock 541 262 231 minecraft:light[level=12]
setblock 541 262 238 minecraft:light[level=12]
setblock 541 262 245 minecraft:light[level=12]
setblock 541 262 252 minecraft:light[level=12]
setblock 541 262 259 minecraft:light[level=12]
setblock 541 262 266 minecraft:light[level=12]
setblock 543 262 228 minecraft:magenta_terracotta
setblock 543 262 270 minecraft:magenta_terracotta
setblock 547 262 228 minecraft:magenta_terracotta
fill 547 262 230 548 262 230 minecraft:spruce_planks
setblock 547 262 270 minecraft:magenta_terracotta
setblock 548 262 231 minecraft:light[level=12]
setblock 548 262 238 minecraft:light[level=12]
setblock 548 262 245 minecraft:light[level=12]
setblock 548 262 252 minecraft:light[level=12]
setblock 548 262 259 minecraft:light[level=12]
setblock 548 262 266 minecraft:light[level=12]
fill 549 262 229 550 262 230 minecraft:dark_oak_planks
setblock 551 262 228 minecraft:magenta_terracotta
setblock 551 262 270 minecraft:magenta_terracotta
setblock 555 262 228 minecraft:magenta_terracotta
setblock 555 262 231 minecraft:light[level=12]
setblock 555 262 238 minecraft:light[level=12]
setblock 555 262 245 minecraft:light[level=12]
setblock 555 262 252 minecraft:light[level=12]
setblock 555 262 259 minecraft:light[level=12]
setblock 555 262 266 minecraft:light[level=12]
setblock 555 262 270 minecraft:magenta_terracotta
setblock 559 262 228 minecraft:magenta_terracotta
setblock 559 262 230 minecraft:magenta_terracotta
setblock 559 262 234 minecraft:magenta_terracotta
setblock 559 262 238 minecraft:magenta_terracotta
setblock 559 262 242 minecraft:magenta_terracotta
setblock 559 262 246 minecraft:magenta_terracotta
setblock 559 262 247 minecraft:light_gray_terracotta
setblock 559 262 250 minecraft:magenta_terracotta
setblock 559 262 254 minecraft:magenta_terracotta
setblock 559 262 258 minecraft:magenta_terracotta
setblock 559 262 262 minecraft:magenta_terracotta
setblock 559 262 266 minecraft:magenta_terracotta
setblock 559 262 270 minecraft:magenta_terracotta
fill 517 263 230 517 265 230 minecraft:purple_terracotta
fill 517 263 234 517 265 234 minecraft:purple_terracotta
fill 517 263 238 517 265 238 minecraft:purple_terracotta
fill 517 263 242 517 265 242 minecraft:purple_terracotta
fill 517 263 246 517 265 246 minecraft:purple_terracotta
fill 517 263 250 517 265 250 minecraft:purple_terracotta
fill 517 263 254 517 265 254 minecraft:purple_terracotta
fill 517 263 258 517 265 258 minecraft:purple_terracotta
fill 517 263 262 517 265 262 minecraft:purple_terracotta
fill 517 263 266 517 265 266 minecraft:purple_terracotta
setblock 517 263 270 minecraft:purple_terracotta
fill 519 263 228 519 265 228 minecraft:purple_terracotta
fill 519 263 270 519 265 270 minecraft:purple_terracotta
fill 523 263 228 523 265 228 minecraft:purple_terracotta
fill 523 263 270 523 265 270 minecraft:purple_terracotta
fill 527 263 228 527 264 228 minecraft:purple_terracotta
fill 527 263 270 527 265 270 minecraft:purple_terracotta
fill 531 263 228 531 265 228 minecraft:purple_terracotta
fill 531 263 270 531 265 270 minecraft:purple_terracotta
fill 535 263 228 535 265 228 minecraft:purple_terracotta
fill 535 263 270 535 265 270 minecraft:purple_terracotta
fill 539 263 228 539 265 228 minecraft:purple_terracotta
fill 539 263 270 539 265 270 minecraft:purple_terracotta
fill 543 263 228 543 265 228 minecraft:purple_terracotta
fill 543 263 270 543 265 270 minecraft:purple_terracotta
fill 545 263 230 546 263 230 minecraft:spruce_planks
fill 547 263 228 547 265 228 minecraft:purple_terracotta
fill 547 263 229 548 263 230 minecraft:dark_oak_planks
fill 547 263 270 547 265 270 minecraft:purple_terracotta
fill 551 263 228 551 265 228 minecraft:purple_terracotta
fill 551 263 270 551 265 270 minecraft:purple_terracotta
fill 555 263 228 555 265 228 minecraft:purple_terracotta
fill 555 263 270 555 265 270 minecraft:purple_terracotta
setblock 559 263 228 minecraft:purple_terracotta
setblock 559 263 230 minecraft:purple_terracotta
fill 559 263 234 559 265 234 minecraft:purple_terracotta
fill 559 263 238 559 265 238 minecraft:purple_terracotta
fill 559 263 242 559 265 242 minecraft:purple_terracotta
fill 559 263 246 559 265 247 minecraft:purple_terracotta
fill 559 263 250 559 265 250 minecraft:purple_terracotta
fill 559 263 254 559 265 254 minecraft:purple_terracotta
fill 559 263 258 559 265 258 minecraft:purple_terracotta
fill 559 263 262 559 265 262 minecraft:purple_terracotta
fill 559 263 266 559 265 266 minecraft:purple_terracotta
fill 559 263 270 559 265 270 minecraft:purple_terracotta
setblock 517 264 228 minecraft:magenta_terracotta
setblock 517 264 232 minecraft:magenta_terracotta
setblock 517 264 236 minecraft:magenta_terracotta
setblock 517 264 240 minecraft:magenta_terracotta
setblock 517 264 244 minecraft:magenta_terracotta
setblock 517 264 248 minecraft:magenta_terracotta
setblock 517 264 252 minecraft:magenta_terracotta
setblock 517 264 256 minecraft:magenta_terracotta
setblock 517 264 260 minecraft:magenta_terracotta
setblock 517 264 264 minecraft:magenta_terracotta
setblock 517 264 265 minecraft:black_terracotta
setblock 517 264 268 minecraft:magenta_terracotta
setblock 517 264 270 minecraft:magenta_terracotta
fill 518 264 239 518 264 243 minecraft:gold_block
setblock 520 264 231 minecraft:light[level=11]
setblock 520 264 239 minecraft:light[level=11]
setblock 520 264 247 minecraft:light[level=11]
setblock 520 264 255 minecraft:light[level=11]
setblock 520 264 263 minecraft:light[level=11]
setblock 521 264 228 minecraft:magenta_terracotta
setblock 521 264 270 minecraft:magenta_terracotta
setblock 525 264 228 minecraft:magenta_terracotta
setblock 525 264 270 minecraft:magenta_terracotta
setblock 528 264 231 minecraft:light[level=11]
setblock 528 264 239 minecraft:light[level=11]
setblock 528 264 247 minecraft:light[level=11]
setblock 528 264 255 minecraft:light[level=11]
setblock 528 264 263 minecraft:light[level=11]
setblock 529 264 228 minecraft:magenta_terracotta
setblock 529 264 270 minecraft:magenta_terracotta
setblock 530 264 270 minecraft:light_gray_terracotta
setblock 533 264 228 minecraft:magenta_terracotta
setblock 533 264 270 minecraft:magenta_terracotta
setblock 536 264 231 minecraft:light[level=11]
setblock 536 264 239 minecraft:light[level=11]
setblock 536 264 247 minecraft:light[level=11]
setblock 536 264 255 minecraft:light[level=11]
setblock 536 264 263 minecraft:light[level=11]
setblock 537 264 228 minecraft:magenta_terracotta
setblock 537 264 270 minecraft:magenta_terracotta
setblock 540 264 270 minecraft:black_terracotta
setblock 541 264 228 minecraft:magenta_terracotta
setblock 541 264 270 minecraft:magenta_terracotta
fill 543 264 230 544 264 230 minecraft:spruce_planks
setblock 544 264 231 minecraft:light[level=11]
setblock 544 264 239 minecraft:light[level=11]
setblock 544 264 247 minecraft:light[level=11]
setblock 544 264 255 minecraft:light[level=11]
setblock 544 264 263 minecraft:light[level=11]
setblock 545 264 228 minecraft:magenta_terracotta
fill 545 264 229 546 264 230 minecraft:dark_oak_planks
setblock 545 264 270 minecraft:magenta_terracotta
setblock 549 264 228 minecraft:magenta_terracotta
setblock 549 264 270 minecraft:magenta_terracotta
setblock 552 264 231 minecraft:light[level=11]
setblock 552 264 239 minecraft:light[level=11]
setblock 552 264 247 minecraft:light[level=11]
setblock 552 264 255 minecraft:light[level=11]
setblock 552 264 263 minecraft:light[level=11]
setblock 553 264 228 minecraft:magenta_terracotta
fill 553 264 256 553 265 256 minecraft:stripped_dark_oak_log
fill 553 264 258 553 265 258 minecraft:stripped_dark_oak_log
setblock 553 264 270 minecraft:magenta_terracotta
setblock 557 264 228 minecraft:magenta_terracotta
setblock 557 264 270 minecraft:magenta_terracotta
setblock 559 264 228 minecraft:magenta_terracotta
setblock 559 264 230 minecraft:light_gray_terracotta
setblock 559 264 232 minecraft:magenta_terracotta
setblock 559 264 236 minecraft:black_terracotta
setblock 559 264 240 minecraft:magenta_terracotta
setblock 559 264 244 minecraft:magenta_terracotta
setblock 559 264 248 minecraft:magenta_terracotta
setblock 559 264 252 minecraft:magenta_terracotta
setblock 559 264 256 minecraft:magenta_terracotta
setblock 559 264 260 minecraft:magenta_terracotta
setblock 559 264 264 minecraft:magenta_terracotta
setblock 559 264 268 minecraft:magenta_terracotta
fill 517 265 228 517 267 228 minecraft:purple_terracotta
fill 517 265 232 517 267 232 minecraft:purple_terracotta
fill 517 265 236 517 267 236 minecraft:purple_terracotta
fill 517 265 240 517 267 240 minecraft:purple_terracotta
fill 517 265 244 517 267 244 minecraft:purple_terracotta
fill 517 265 248 517 267 248 minecraft:purple_terracotta
fill 517 265 252 517 267 252 minecraft:purple_terracotta
fill 517 265 256 517 267 256 minecraft:purple_terracotta
fill 517 265 260 517 267 260 minecraft:purple_terracotta
fill 517 265 264 517 267 265 minecraft:purple_terracotta
fill 517 265 268 517 267 268 minecraft:purple_terracotta
setblock 517 265 270 minecraft:purple_terracotta
fill 518 265 239 518 270 239 minecraft:gold_block
fill 518 265 240 518 266 242 minecraft:red_terracotta
fill 518 265 243 518 270 243 minecraft:gold_block
fill 521 265 228 521 267 228 minecraft:purple_terracotta
fill 521 265 270 521 267 270 minecraft:purple_terracotta
fill 525 265 228 525 267 228 minecraft:purple_terracotta
fill 525 265 270 525 267 270 minecraft:purple_terracotta
setblock 527 265 228 minecraft:black_terracotta
fill 529 265 228 529 267 228 minecraft:purple_terracotta
fill 529 265 270 530 267 270 minecraft:purple_terracotta
fill 533 265 228 533 267 228 minecraft:purple_terracotta
fill 533 265 229 537 265 229 minecraft:gold_block
fill 533 265 270 533 267 270 minecraft:purple_terracotta
fill 537 265 228 537 267 228 minecraft:purple_terracotta
fill 537 265 270 537 267 270 minecraft:purple_terracotta
fill 540 265 270 541 267 270 minecraft:purple_terracotta
fill 541 265 228 541 267 228 minecraft:purple_terracotta
fill 541 265 230 542 265 230 minecraft:spruce_planks
fill 543 265 229 544 265 230 minecraft:dark_oak_planks
fill 545 265 228 545 267 228 minecraft:purple_terracotta
fill 545 265 270 545 267 270 minecraft:purple_terracotta
fill 549 265 228 549 267 228 minecraft:purple_terracotta
fill 549 265 270 549 267 270 minecraft:purple_terracotta
fill 553 265 228 553 267 228 minecraft:purple_terracotta
fill 553 265 270 553 267 270 minecraft:purple_terracotta
fill 557 265 228 557 267 228 minecraft:purple_terracotta
fill 557 265 270 557 267 270 minecraft:purple_terracotta
setblock 559 265 228 minecraft:purple_terracotta
setblock 559 265 230 minecraft:purple_terracotta
fill 559 265 232 559 267 232 minecraft:purple_terracotta
fill 559 265 236 559 267 236 minecraft:purple_terracotta
fill 559 265 240 559 267 240 minecraft:purple_terracotta
fill 559 265 244 559 267 244 minecraft:purple_terracotta
setblock 559 265 245 minecraft:black_terracotta
fill 559 265 248 559 267 248 minecraft:purple_terracotta
fill 559 265 252 559 267 252 minecraft:purple_terracotta
fill 559 265 256 559 267 256 minecraft:purple_terracotta
fill 559 265 260 559 267 260 minecraft:purple_terracotta
fill 559 265 264 559 267 264 minecraft:purple_terracotta
fill 559 265 268 559 267 268 minecraft:purple_terracotta
setblock 517 266 230 minecraft:magenta_terracotta
setblock 517 266 234 minecraft:magenta_terracotta
setblock 517 266 238 minecraft:magenta_terracotta
setblock 517 266 242 minecraft:magenta_terracotta
setblock 517 266 246 minecraft:magenta_terracotta
setblock 517 266 250 minecraft:magenta_terracotta
setblock 517 266 254 minecraft:magenta_terracotta
setblock 517 266 258 minecraft:magenta_terracotta
setblock 517 266 262 minecraft:magenta_terracotta
setblock 517 266 266 minecraft:magenta_terracotta
setblock 517 266 270 minecraft:magenta_terracotta
setblock 519 266 228 minecraft:magenta_terracotta
setblock 519 266 270 minecraft:magenta_terracotta
setblock 523 266 228 minecraft:magenta_terracotta
setblock 523 266 270 minecraft:magenta_terracotta
setblock 527 266 228 minecraft:magenta_terracotta
setblock 527 266 270 minecraft:magenta_terracotta
setblock 531 266 228 minecraft:magenta_terracotta
setblock 531 266 270 minecraft:magenta_terracotta
fill 533 266 229 533 269 229 minecraft:gold_block
fill 534 266 229 536 267 229 minecraft:brown_concrete
setblock 535 266 228 minecraft:magenta_terracotta
fill 535 266 246 535 277 246 minecraft:iron_bars
setblock 535 266 270 minecraft:magenta_terracotta
fill 537 266 229 537 267 229 minecraft:gold_block
setblock 539 266 228 minecraft:magenta_terracotta
fill 539 266 230 540 266 230 minecraft:spruce_planks
setblock 539 266 270 minecraft:magenta_terracotta
fill 541 266 229 542 266 230 minecraft:dark_oak_planks
setblock 543 266 228 minecraft:magenta_terracotta
setblock 543 266 270 minecraft:magenta_terracotta
setblock 547 266 228 minecraft:magenta_terracotta
setblock 547 266 270 minecraft:magenta_terracotta
setblock 551 266 228 minecraft:magenta_terracotta
setblock 551 266 270 minecraft:magenta_terracotta
setblock 554 266 228 minecraft:black_terracotta
setblock 555 266 228 minecraft:magenta_terracotta
setblock 555 266 270 minecraft:magenta_terracotta
setblock 559 266 228 minecraft:magenta_terracotta
setblock 559 266 230 minecraft:magenta_terracotta
setblock 559 266 234 minecraft:magenta_terracotta
setblock 559 266 238 minecraft:magenta_terracotta
setblock 559 266 242 minecraft:magenta_terracotta
fill 559 266 245 559 278 245 minecraft:purple_terracotta
setblock 559 266 246 minecraft:magenta_terracotta
fill 559 266 247 559 278 247 minecraft:purple_terracotta
setblock 559 266 250 minecraft:magenta_terracotta
setblock 559 266 254 minecraft:magenta_terracotta
setblock 559 266 257 minecraft:black_terracotta
setblock 559 266 258 minecraft:magenta_terracotta
setblock 559 266 262 minecraft:magenta_terracotta
setblock 559 266 266 minecraft:magenta_terracotta
setblock 559 266 270 minecraft:magenta_terracotta
fill 517 267 230 517 269 230 minecraft:purple_terracotta
fill 517 267 234 517 269 234 minecraft:purple_terracotta
fill 517 267 238 517 269 238 minecraft:purple_terracotta
fill 517 267 242 517 269 242 minecraft:purple_terracotta
fill 517 267 246 517 269 246 minecraft:purple_terracotta
fill 517 267 250 517 269 250 minecraft:purple_terracotta
fill 517 267 254 517 269 254 minecraft:purple_terracotta
fill 517 267 258 517 269 258 minecraft:purple_terracotta
fill 517 267 262 517 269 262 minecraft:purple_terracotta
fill 517 267 266 517 269 266 minecraft:purple_terracotta
setblock 517 267 270 minecraft:purple_terracotta
fill 518 267 240 518 267 242 minecraft:white_terracotta
fill 519 267 228 519 269 228 minecraft:purple_terracotta
fill 519 267 270 519 269 270 minecraft:purple_terracotta
fill 523 267 228 523 269 228 minecraft:purple_terracotta
fill 523 267 270 523 269 270 minecraft:purple_terracotta
fill 527 267 228 527 269 228 minecraft:purple_terracotta
fill 527 267 270 527 269 270 minecraft:purple_terracotta
fill 531 267 228 531 269 228 minecraft:purple_terracotta
fill 531 267 270 531 269 270 minecraft:purple_terracotta
fill 535 267 228 535 269 228 minecraft:purple_terracotta
fill 535 267 270 535 269 270 minecraft:purple_terracotta
fill 537 267 230 538 267 230 minecraft:spruce_planks
fill 539 267 228 539 269 228 minecraft:purple_terracotta
fill 539 267 229 540 267 230 minecraft:dark_oak_planks
fill 539 267 270 539 269 270 minecraft:purple_terracotta
fill 543 267 228 543 269 228 minecraft:purple_terracotta
fill 543 267 270 543 269 270 minecraft:purple_terracotta
fill 547 267 228 547 269 228 minecraft:purple_terracotta
fill 547 267 270 547 269 270 minecraft:purple_terracotta
setblock 548 267 228 minecraft:black_terracotta
fill 551 267 228 551 269 228 minecraft:purple_terracotta
fill 551 267 270 551 269 270 minecraft:purple_terracotta
fill 554 267 228 555 269 228 minecraft:purple_terracotta
fill 555 267 270 555 269 270 minecraft:purple_terracotta
setblock 559 267 228 minecraft:purple_terracotta
fill 559 267 230 559 269 230 minecraft:purple_terracotta
fill 559 267 234 559 269 234 minecraft:purple_terracotta
fill 559 267 238 559 269 238 minecraft:purple_terracotta
fill 559 267 242 559 269 242 minecraft:purple_terracotta
fill 559 267 246 559 269 246 minecraft:purple_terracotta
fill 559 267 250 559 269 250 minecraft:purple_terracotta
fill 559 267 254 559 269 254 minecraft:purple_terracotta
fill 559 267 257 559 269 258 minecraft:purple_terracotta
fill 559 267 262 559 269 262 minecraft:purple_terracotta
fill 559 267 266 559 269 266 minecraft:purple_terracotta
fill 559 267 270 559 269 270 minecraft:purple_terracotta
setblock 517 268 228 minecraft:magenta_terracotta
setblock 517 268 232 minecraft:magenta_terracotta
setblock 517 268 236 minecraft:magenta_terracotta
setblock 517 268 240 minecraft:magenta_terracotta
setblock 517 268 244 minecraft:magenta_terracotta
setblock 517 268 248 minecraft:magenta_terracotta
setblock 517 268 252 minecraft:magenta_terracotta
setblock 517 268 256 minecraft:magenta_terracotta
setblock 517 268 260 minecraft:magenta_terracotta
setblock 517 268 264 minecraft:magenta_terracotta
fill 517 268 265 517 278 265 minecraft:purple_terracotta
setblock 517 268 268 minecraft:magenta_terracotta
setblock 517 268 270 minecraft:magenta_terracotta
setblock 518 268 240 minecraft:black_concrete
fill 518 268 241 518 269 241 minecraft:white_terracotta
setblock 518 268 242 minecraft:black_concrete
setblock 520 268 231 minecraft:light[level=12]
setblock 520 268 238 minecraft:light[level=12]
setblock 520 268 245 minecraft:light[level=12]
setblock 520 268 252 minecraft:light[level=12]
setblock 520 268 259 minecraft:light[level=12]
setblock 520 268 266 minecraft:light[level=12]
setblock 521 268 228 minecraft:magenta_terracotta
setblock 521 268 270 minecraft:magenta_terracotta
setblock 525 268 228 minecraft:magenta_terracotta
setblock 525 268 270 minecraft:magenta_terracotta
setblock 527 268 231 minecraft:light[level=12]
setblock 527 268 238 minecraft:light[level=12]
setblock 527 268 245 minecraft:light[level=12]
setblock 527 268 252 minecraft:light[level=12]
setblock 527 268 259 minecraft:light[level=12]
setblock 527 268 266 minecraft:light[level=12]
setblock 529 268 228 minecraft:magenta_terracotta
setblock 529 268 270 minecraft:magenta_terracotta
fill 530 268 270 530 278 270 minecraft:purple_terracotta
setblock 533 268 228 minecraft:magenta_terracotta
setblock 533 268 270 minecraft:magenta_terracotta
fill 534 268 229 536 268 229 minecraft:pink_terracotta
setblock 534 268 231 minecraft:light[level=12]
setblock 534 268 238 minecraft:light[level=12]
setblock 534 268 245 minecraft:light[level=12]
setblock 534 268 252 minecraft:light[level=12]
setblock 534 268 259 minecraft:light[level=12]
setblock 534 268 266 minecraft:light[level=12]
fill 535 268 230 536 268 230 minecraft:spruce_planks
setblock 537 268 228 minecraft:magenta_terracotta
fill 537 268 229 538 268 230 minecraft:dark_oak_planks
setblock 537 268 270 minecraft:magenta_terracotta
fill 540 268 270 540 278 270 minecraft:purple_terracotta
setblock 541 268 228 minecraft:magenta_terracotta
setblock 541 268 231 minecraft:light[level=12]
setblock 541 268 238 minecraft:light[level=12]
setblock 541 268 245 minecraft:light[level=12]
fill 541 268 252 541 277 252 minecraft:iron_bars
setblock 541 268 259 minecraft:light[level=12]
setblock 541 268 266 minecraft:light[level=12]
setblock 541 268 270 minecraft:magenta_terracotta
setblock 545 268 228 minecraft:magenta_terracotta
setblock 545 268 270 minecraft:magenta_terracotta
fill 548 268 228 548 278 228 minecraft:purple_terracotta
setblock 548 268 231 minecraft:light[level=12]
setblock 548 268 238 minecraft:light[level=12]
setblock 548 268 245 minecraft:light[level=12]
setblock 548 268 252 minecraft:light[level=12]
setblock 548 268 259 minecraft:light[level=12]
setblock 548 268 266 minecraft:light[level=12]
setblock 549 268 228 minecraft:magenta_terracotta
setblock 549 268 270 minecraft:magenta_terracotta
setblock 553 268 228 minecraft:black_terracotta
setblock 553 268 270 minecraft:magenta_terracotta
setblock 555 268 231 minecraft:light[level=12]
setblock 555 268 238 minecraft:light[level=12]
setblock 555 268 245 minecraft:light[level=12]
setblock 555 268 252 minecraft:light[level=12]
setblock 555 268 259 minecraft:light[level=12]
setblock 555 268 266 minecraft:light[level=12]
setblock 557 268 228 minecraft:magenta_terracotta
setblock 557 268 270 minecraft:magenta_terracotta
setblock 559 268 228 minecraft:magenta_terracotta
setblock 559 268 232 minecraft:magenta_terracotta
setblock 559 268 236 minecraft:magenta_terracotta
setblock 559 268 240 minecraft:magenta_terracotta
setblock 559 268 244 minecraft:magenta_terracotta
setblock 559 268 248 minecraft:magenta_terracotta
setblock 559 268 251 minecraft:black_terracotta
setblock 559 268 252 minecraft:magenta_terracotta
setblock 559 268 256 minecraft:magenta_terracotta
setblock 559 268 260 minecraft:magenta_terracotta
setblock 559 268 264 minecraft:magenta_terracotta
setblock 559 268 268 minecraft:magenta_terracotta
fill 517 269 228 517 271 228 minecraft:purple_terracotta
fill 517 269 232 517 271 232 minecraft:purple_terracotta
fill 517 269 236 517 271 236 minecraft:purple_terracotta
fill 517 269 240 517 271 240 minecraft:purple_terracotta
fill 517 269 244 517 271 244 minecraft:purple_terracotta
fill 517 269 248 517 271 248 minecraft:purple_terracotta
fill 517 269 252 517 271 252 minecraft:purple_terracotta
fill 517 269 256 517 271 256 minecraft:purple_terracotta
fill 517 269 260 517 271 260 minecraft:purple_terracotta
fill 517 269 264 517 271 264 minecraft:purple_terracotta
fill 517 269 268 517 271 268 minecraft:purple_terracotta
setblock 517 269 270 minecraft:purple_terracotta
fill 518 269 229 518 271 229 minecraft:dark_oak_planks
fill 518 269 230 518 270 238 minecraft:deepslate_tiles
setblock 518 269 240 minecraft:white_terracotta
setblock 518 269 242 minecraft:white_terracotta
fill 518 269 244 518 270 268 minecraft:deepslate_tiles
fill 518 269 269 518 271 269 minecraft:dark_oak_planks
fill 519 269 229 532 270 229 minecraft:deepslate_tiles
fill 519 269 269 557 270 269 minecraft:deepslate_tiles
fill 521 269 228 521 271 228 minecraft:purple_terracotta
fill 521 269 270 521 271 270 minecraft:purple_terracotta
fill 525 269 228 525 271 228 minecraft:purple_terracotta
fill 525 269 270 525 271 270 minecraft:purple_terracotta
fill 529 269 228 529 271 228 minecraft:purple_terracotta
fill 529 269 270 529 271 270 minecraft:purple_terracotta
fill 533 269 228 533 271 228 minecraft:purple_terracotta
fill 533 269 230 534 269 230 minecraft:spruce_planks
fill 533 269 270 533 271 270 minecraft:purple_terracotta
setblock 534 269 229 minecraft:blue_concrete
fill 535 269 229 536 269 230 minecraft:dark_oak_planks
fill 535 269 252 535 277 252 minecraft:iron_bars
fill 537 269 228 537 271 228 minecraft:purple_terracotta
fill 537 269 229 537 271 229 minecraft:gold_block
fill 537 269 270 537 271 270 minecraft:purple_terracotta
fill 538 269 229 557 270 229 minecraft:deepslate_tiles
fill 541 269 228 541 271 228 minecraft:purple_terracotta
fill 541 269 270 541 271 270 minecraft:purple_terracotta
fill 545 269 228 545 271 228 minecraft:purple_terracotta
setblock 545 269 233 minecraft:jack_o_lantern
fill 545 269 270 545 271 270 minecraft:purple_terracotta
fill 549 269 228 549 271 228 minecraft:purple_terracotta
fill 549 269 270 549 271 270 minecraft:purple_terracotta
fill 553 269 228 553 271 228 minecraft:purple_terracotta
fill 553 269 270 553 271 270 minecraft:purple_terracotta
fill 557 269 228 557 271 228 minecraft:purple_terracotta
fill 557 269 270 557 271 270 minecraft:purple_terracotta
fill 558 269 229 558 271 229 minecraft:dark_oak_planks
fill 558 269 230 558 270 268 minecraft:deepslate_tiles
fill 558 269 269 558 271 269 minecraft:dark_oak_planks
setblock 559 269 228 minecraft:purple_terracotta
fill 559 269 232 559 271 232 minecraft:purple_terracotta
fill 559 269 236 559 271 236 minecraft:purple_terracotta
fill 559 269 240 559 271 240 minecraft:purple_terracotta
fill 559 269 244 559 271 244 minecraft:purple_terracotta
fill 559 269 248 559 271 248 minecraft:purple_terracotta
fill 559 269 251 559 271 252 minecraft:purple_terracotta
fill 559 269 256 559 271 256 minecraft:purple_terracotta
fill 559 269 260 559 271 260 minecraft:purple_terracotta
fill 559 269 264 559 271 264 minecraft:purple_terracotta
fill 559 269 268 559 271 268 minecraft:purple_terracotta
setblock 517 270 230 minecraft:magenta_terracotta
setblock 517 270 234 minecraft:magenta_terracotta
setblock 517 270 238 minecraft:magenta_terracotta
setblock 517 270 242 minecraft:magenta_terracotta
setblock 517 270 246 minecraft:magenta_terracotta
setblock 517 270 250 minecraft:magenta_terracotta
setblock 517 270 254 minecraft:magenta_terracotta
setblock 517 270 258 minecraft:magenta_terracotta
setblock 517 270 262 minecraft:magenta_terracotta
setblock 517 270 266 minecraft:magenta_terracotta
setblock 517 270 270 minecraft:magenta_terracotta
fill 518 270 240 518 270 242 minecraft:gold_block
setblock 519 270 228 minecraft:magenta_terracotta
fill 519 270 230 519 272 230 minecraft:dark_oak_planks
fill 519 270 231 519 271 267 minecraft:deepslate_tiles
fill 519 270 268 519 272 268 minecraft:dark_oak_planks
setblock 519 270 270 minecraft:magenta_terracotta
fill 520 270 230 530 270 230 minecraft:deepslate_tiles
fill 520 270 268 556 271 268 minecraft:deepslate_tiles
setblock 523 270 228 minecraft:magenta_terracotta
setblock 523 270 270 minecraft:magenta_terracotta
setblock 527 270 228 minecraft:magenta_terracotta
setblock 527 270 270 minecraft:magenta_terracotta
setblock 531 270 228 minecraft:magenta_terracotta
fill 531 270 230 532 270 230 minecraft:spruce_planks
setblock 531 270 270 minecraft:magenta_terracotta
fill 533 270 229 534 270 230 minecraft:dark_oak_planks
setblock 535 270 228 minecraft:magenta_terracotta
fill 535 270 229 536 270 229 minecraft:pink_terracotta
fill 535 270 230 556 271 230 minecraft:deepslate_tiles
setblock 535 270 270 minecraft:magenta_terracotta
setblock 539 270 228 minecraft:magenta_terracotta
setblock 539 270 270 minecraft:magenta_terracotta
setblock 543 270 228 minecraft:magenta_terracotta
setblock 543 270 270 minecraft:magenta_terracotta
setblock 547 270 228 minecraft:magenta_terracotta
setblock 547 270 270 minecraft:magenta_terracotta
setblock 551 270 228 minecraft:magenta_terracotta
setblock 551 270 270 minecraft:magenta_terracotta
fill 554 270 228 554 278 228 minecraft:purple_terracotta
setblock 555 270 228 minecraft:magenta_terracotta
setblock 555 270 270 minecraft:magenta_terracotta
fill 557 270 230 557 272 230 minecraft:dark_oak_planks
fill 557 270 231 557 271 267 minecraft:deepslate_tiles
fill 557 270 268 557 272 268 minecraft:dark_oak_planks
setblock 559 270 228 minecraft:magenta_terracotta
setblock 559 270 230 minecraft:magenta_terracotta
setblock 559 270 234 minecraft:magenta_terracotta
setblock 559 270 238 minecraft:magenta_terracotta
setblock 559 270 242 minecraft:magenta_terracotta
setblock 559 270 246 minecraft:magenta_terracotta
setblock 559 270 250 minecraft:magenta_terracotta
setblock 559 270 254 minecraft:magenta_terracotta
fill 559 270 257 559 275 257 minecraft:purple_terracotta
setblock 559 270 258 minecraft:magenta_terracotta
setblock 559 270 262 minecraft:magenta_terracotta
setblock 559 270 266 minecraft:magenta_terracotta
setblock 559 270 270 minecraft:magenta_terracotta
fill 517 271 230 517 273 230 minecraft:purple_terracotta
fill 517 271 234 517 273 234 minecraft:purple_terracotta
fill 517 271 238 517 273 238 minecraft:purple_terracotta
fill 517 271 242 517 273 242 minecraft:purple_terracotta
fill 517 271 246 517 273 246 minecraft:purple_terracotta
fill 517 271 250 517 273 250 minecraft:purple_terracotta
fill 517 271 254 517 273 254 minecraft:purple_terracotta
fill 517 271 258 517 273 258 minecraft:purple_terracotta
fill 517 271 262 517 273 262 minecraft:purple_terracotta
fill 517 271 266 517 273 266 minecraft:purple_terracotta
setblock 517 271 269 minecraft:light_gray_terracotta
setblock 517 271 270 minecraft:purple_terracotta
fill 518 271 230 518 271 268 minecraft:polished_deepslate
fill 519 271 228 519 273 228 minecraft:purple_terracotta
fill 519 271 229 530 271 229 minecraft:polished_deepslate
fill 519 271 269 557 271 269 minecraft:polished_deepslate
fill 519 271 270 519 273 270 minecraft:purple_terracotta
fill 520 271 230 528 271 230 minecraft:deepslate_tiles
fill 520 271 231 520 273 231 minecraft:dark_oak_planks
fill 520 271 232 520 272 266 minecraft:deepslate_tiles
fill 520 271 267 520 273 267 minecraft:dark_oak_planks
fill 521 271 231 555 272 231 minecraft:deepslate_tiles
fill 521 271 232 521 273 232 minecraft:dark_oak_planks
fill 521 271 233 521 271 265 minecraft:polished_deepslate
fill 521 271 266 521 273 266 minecraft:dark_oak_planks
fill 521 271 267 555 272 267 minecraft:deepslate_tiles
fill 522 271 232 554 271 232 minecraft:polished_deepslate
fill 522 271 266 554 271 266 minecraft:polished_deepslate
fill 523 271 228 523 273 228 minecraft:purple_terracotta
fill 523 271 270 523 273 270 minecraft:purple_terracotta
fill 527 271 228 527 273 228 minecraft:purple_terracotta
fill 527 271 270 527 273 270 minecraft:purple_terracotta
fill 529 271 230 530 271 230 minecraft:spruce_planks
setblock 531 271 228 minecraft:purple_terracotta
fill 531 271 229 532 271 230 minecraft:dark_oak_planks
fill 531 271 270 531 273 270 minecraft:purple_terracotta
fill 533 271 229 536 271 229 minecraft:gold_block
fill 533 271 230 534 271 230 minecraft:deepslate_tiles
fill 535 271 228 535 273 228 minecraft:purple_terracotta
fill 535 271 270 535 273 270 minecraft:purple_terracotta
fill 538 271 229 557 271 229 minecraft:polished_deepslate
fill 539 271 228 539 273 228 minecraft:purple_terracotta
fill 539 271 270 539 273 270 minecraft:purple_terracotta
fill 543 271 228 543 273 228 minecraft:purple_terracotta
fill 543 271 270 543 273 270 minecraft:purple_terracotta
fill 547 271 228 547 273 228 minecraft:purple_terracotta
fill 547 271 270 547 273 270 minecraft:purple_terracotta
fill 551 271 228 551 273 228 minecraft:purple_terracotta
fill 551 271 270 551 273 270 minecraft:purple_terracotta
fill 555 271 228 555 273 228 minecraft:purple_terracotta
fill 555 271 232 555 273 232 minecraft:dark_oak_planks
fill 555 271 233 555 271 265 minecraft:polished_deepslate
fill 555 271 266 555 273 266 minecraft:dark_oak_planks
fill 555 271 270 555 273 270 minecraft:purple_terracotta
fill 556 271 231 556 273 231 minecraft:dark_oak_planks
fill 556 271 232 556 272 266 minecraft:deepslate_tiles
fill 556 271 267 556 273 267 minecraft:dark_oak_planks
fill 558 271 230 558 271 268 minecraft:polished_deepslate
setblock 559 271 228 minecraft:purple_terracotta
fill 559 271 230 559 273 230 minecraft:purple_terracotta
fill 559 271 234 559 273 234 minecraft:purple_terracotta
fill 559 271 238 559 273 238 minecraft:purple_terracotta
setblock 559 271 242 minecraft:purple_terracotta
fill 559 271 246 559 273 246 minecraft:purple_terracotta
fill 559 271 250 559 273 250 minecraft:purple_terracotta
fill 559 271 254 559 273 254 minecraft:purple_terracotta
fill 559 271 258 559 273 258 minecraft:purple_terracotta
fill 559 271 262 559 273 262 minecraft:purple_terracotta
fill 559 271 266 559 273 266 minecraft:purple_terracotta
fill 559 271 270 559 273 270 minecraft:purple_terracotta
setblock 517 272 228 minecraft:magenta_terracotta
setblock 517 272 232 minecraft:magenta_terracotta
setblock 517 272 236 minecraft:magenta_terracotta
setblock 517 272 240 minecraft:magenta_terracotta
setblock 517 272 244 minecraft:magenta_terracotta
setblock 517 272 248 minecraft:magenta_terracotta
setblock 517 272 252 minecraft:magenta_terracotta
setblock 517 272 256 minecraft:magenta_terracotta
setblock 517 272 260 minecraft:magenta_terracotta
setblock 517 272 264 minecraft:magenta_terracotta
setblock 517 272 268 minecraft:magenta_terracotta
fill 517 272 269 517 278 269 minecraft:purple_terracotta
setblock 517 272 270 minecraft:magenta_terracotta
fill 519 272 231 519 272 267 minecraft:polished_deepslate
fill 520 272 230 526 272 230 minecraft:polished_deepslate
fill 520 272 268 556 272 268 minecraft:polished_deepslate
setblock 521 272 228 minecraft:magenta_terracotta
fill 521 272 233 521 273 265 minecraft:deepslate_tiles
setblock 521 272 270 minecraft:magenta_terracotta
fill 522 272 232 554 273 232 minecraft:deepslate_tiles
fill 522 272 233 522 274 233 minecraft:dark_oak_planks
fill 522 272 234 522 272 264 minecraft:polished_deepslate
fill 522 272 265 522 274 265 minecraft:dark_oak_planks
fill 522 272 266 554 273 266 minecraft:deepslate_tiles
fill 523 272 233 553 272 233 minecraft:polished_deepslate
fill 523 272 265 553 272 265 minecraft:polished_deepslate
setblock 525 272 228 minecraft:magenta_terracotta
setblock 525 272 270 minecraft:magenta_terracotta
fill 527 272 230 528 272 230 minecraft:spruce_planks
setblock 528 272 239 minecraft:light[level=11]
setblock 528 272 247 minecraft:light[level=11]
setblock 528 272 255 minecraft:light[level=11]
setblock 528 272 263 minecraft:light[level=11]
setblock 529 272 228 minecraft:magenta_terracotta
fill 529 272 229 530 272 230 minecraft:dark_oak_planks
setblock 529 272 270 minecraft:magenta_terracotta
setblock 531 272 228 minecraft:black_terracotta
fill 531 272 230 556 272 230 minecraft:polished_deepslate
setblock 533 272 228 minecraft:magenta_terracotta
setblock 533 272 270 minecraft:magenta_terracotta
setblock 536 272 239 minecraft:light[level=11]
setblock 536 272 247 minecraft:light[level=11]
setblock 536 272 255 minecraft:light[level=11]
setblock 536 272 263 minecraft:light[level=11]
setblock 537 272 228 minecraft:magenta_terracotta
setblock 537 272 270 minecraft:magenta_terracotta
setblock 541 272 228 minecraft:magenta_terracotta
setblock 541 272 270 minecraft:magenta_terracotta
setblock 544 272 239 minecraft:light[level=11]
setblock 544 272 247 minecraft:light[level=11]
setblock 544 272 255 minecraft:light[level=11]
setblock 544 272 263 minecraft:light[level=11]
setblock 545 272 228 minecraft:magenta_terracotta
setblock 545 272 270 minecraft:magenta_terracotta
setblock 549 272 228 minecraft:magenta_terracotta
setblock 549 272 270 minecraft:magenta_terracotta
setblock 552 272 239 minecraft:light[level=11]
setblock 552 272 247 minecraft:light[level=11]
setblock 552 272 255 minecraft:light[level=11]
setblock 552 272 263 minecraft:light[level=11]
setblock 553 272 228 minecraft:magenta_terracotta
setblock 553 272 270 minecraft:magenta_terracotta
fill 554 272 233 554 274 233 minecraft:dark_oak_planks
fill 554 272 234 554 272 264 minecraft:polished_deepslate
fill 554 272 265 554 274 265 minecraft:dark_oak_planks
fill 555 272 233 555 273 265 minecraft:deepslate_tiles
setblock 557 272 228 minecraft:magenta_terracotta
fill 557 272 231 557 272 267 minecraft:polished_deepslate
setblock 557 272 270 minecraft:magenta_terracotta
setblock 559 272 228 minecraft:magenta_terracotta
setblock 559 272 232 minecraft:magenta_terracotta
setblock 559 272 236 minecraft:magenta_terracotta
setblock 559 272 240 minecraft:magenta_terracotta
setblock 559 272 242 minecraft:black_terracotta
setblock 559 272 244 minecraft:magenta_terracotta
setblock 559 272 248 minecraft:magenta_terracotta
fill 559 272 251 559 278 251 minecraft:purple_terracotta
setblock 559 272 252 minecraft:magenta_terracotta
setblock 559 272 256 minecraft:magenta_terracotta
setblock 559 272 260 minecraft:magenta_terracotta
setblock 559 272 264 minecraft:magenta_terracotta
setblock 559 272 268 minecraft:magenta_terracotta
fill 517 273 228 517 275 228 minecraft:purple_terracotta
setblock 517 273 231 minecraft:black_terracotta
fill 517 273 232 517 275 232 minecraft:purple_terracotta
fill 517 273 236 517 275 236 minecraft:purple_terracotta
fill 517 273 240 517 275 240 minecraft:purple_terracotta
fill 517 273 244 517 275 244 minecraft:purple_terracotta
fill 517 273 248 517 275 248 minecraft:purple_terracotta
fill 517 273 252 517 275 252 minecraft:purple_terracotta
fill 517 273 256 517 275 256 minecraft:purple_terracotta
fill 517 273 260 517 275 260 minecraft:purple_terracotta
fill 517 273 264 517 275 264 minecraft:purple_terracotta
fill 517 273 268 517 275 268 minecraft:purple_terracotta
setblock 517 273 270 minecraft:purple_terracotta
fill 520 273 232 520 273 266 minecraft:polished_deepslate
fill 521 273 228 521 275 228 minecraft:purple_terracotta
fill 521 273 231 555 273 231 minecraft:polished_deepslate
fill 521 273 267 555 273 267 minecraft:polished_deepslate
setblock 521 273 270 minecraft:purple_terracotta
fill 522 273 234 522 274 264 minecraft:deepslate_tiles
fill 523 273 233 553 274 233 minecraft:deepslate_tiles
fill 523 273 234 523 275 234 minecraft:dark_oak_planks
fill 523 273 235 523 273 263 minecraft:polished_deepslate
fill 523 273 264 523 275 264 minecraft:dark_oak_planks
fill 523 273 265 553 274 265 minecraft:deepslate_tiles
fill 524 273 234 552 273 234 minecraft:polished_deepslate
fill 524 273 264 552 273 264 minecraft:polished_deepslate
fill 525 273 228 525 275 228 minecraft:purple_terracotta
fill 525 273 230 526 273 230 minecraft:spruce_planks
fill 525 273 270 525 275 270 minecraft:purple_terracotta
fill 527 273 229 528 273 230 minecraft:dark_oak_planks
fill 529 273 228 529 275 228 minecraft:purple_terracotta
fill 529 273 270 529 275 270 minecraft:purple_terracotta
setblock 531 273 228 minecraft:purple_terracotta
fill 533 273 228 533 275 228 minecraft:purple_terracotta
fill 533 273 270 533 275 270 minecraft:purple_terracotta
fill 537 273 228 537 275 228 minecraft:purple_terracotta
fill 537 273 270 537 275 270 minecraft:purple_terracotta
fill 541 273 228 541 275 228 minecraft:purple_terracotta
fill 541 273 270 541 275 270 minecraft:purple_terracotta
fill 545 273 228 545 275 228 minecraft:purple_terracotta
fill 545 273 270 545 275 270 minecraft:purple_terracotta
fill 549 273 228 549 275 228 minecraft:purple_terracotta
fill 549 273 270 549 275 270 minecraft:purple_terracotta
fill 553 273 228 553 275 228 minecraft:purple_terracotta
fill 553 273 234 553 275 234 minecraft:dark_oak_planks
fill 553 273 235 553 273 263 minecraft:polished_deepslate
fill 553 273 264 553 275 264 minecraft:dark_oak_planks
fill 553 273 270 553 275 270 minecraft:purple_terracotta
fill 554 273 234 554 274 264 minecraft:deepslate_tiles
fill 556 273 232 556 273 266 minecraft:polished_deepslate
fill 557 273 228 557 275 228 minecraft:purple_terracotta
fill 557 273 270 557 275 270 minecraft:purple_terracotta
setblock 559 273 228 minecraft:purple_terracotta
fill 559 273 232 559 275 232 minecraft:purple_terracotta
fill 559 273 236 559 275 236 minecraft:purple_terracotta
setblock 559 273 239 minecraft:gray_terracotta
fill 559 273 240 559 275 240 minecraft:purple_terracotta
setblock 559 273 242 minecraft:purple_terracotta
fill 559 273 244 559 275 244 minecraft:purple_terracotta
fill 559 273 248 559 275 248 minecraft:purple_terracotta
fill 559 273 252 559 275 252 minecraft:purple_terracotta
fill 559 273 256 559 275 256 minecraft:purple_terracotta
fill 559 273 260 559 275 260 minecraft:purple_terracotta
fill 559 273 264 559 275 264 minecraft:purple_terracotta
fill 559 273 268 559 275 268 minecraft:purple_terracotta
setblock 517 274 230 minecraft:magenta_terracotta
fill 517 274 231 517 278 231 minecraft:purple_terracotta
setblock 517 274 234 minecraft:magenta_terracotta
setblock 517 274 238 minecraft:magenta_terracotta
setblock 517 274 242 minecraft:magenta_terracotta
setblock 517 274 246 minecraft:magenta_terracotta
setblock 517 274 250 minecraft:magenta_terracotta
setblock 517 274 254 minecraft:magenta_terracotta
setblock 517 274 258 minecraft:magenta_terracotta
setblock 517 274 261 minecraft:gray_terracotta
setblock 517 274 262 minecraft:magenta_terracotta
setblock 517 274 266 minecraft:magenta_terracotta
setblock 517 274 270 minecraft:magenta_terracotta
setblock 519 274 228 minecraft:magenta_terracotta
setblock 519 274 270 minecraft:magenta_terracotta
setblock 520 274 231 minecraft:light[level=12]
setblock 520 274 238 minecraft:light[level=12]
setblock 520 274 245 minecraft:light[level=12]
setblock 520 274 252 minecraft:light[level=12]
setblock 520 274 259 minecraft:light[level=12]
setblock 520 274 266 minecraft:light[level=12]
setblock 521 274 270 minecraft:gray_terracotta
setblock 523 274 228 minecraft:magenta_terracotta
fill 523 274 230 524 274 230 minecraft:spruce_planks
fill 523 274 235 523 275 263 minecraft:deepslate_tiles
setblock 523 274 270 minecraft:magenta_terracotta
fill 524 274 234 552 275 234 minecraft:deepslate_tiles
fill 524 274 235 524 276 235 minecraft:dark_oak_planks
fill 524 274 236 524 274 262 minecraft:polished_deepslate
fill 524 274 263 524 276 263 minecraft:dark_oak_planks
fill 524 274 264 552 275 264 minecraft:deepslate_tiles
fill 525 274 229 526 274 230 minecraft:dark_oak_planks
fill 525 274 235 551 274 235 minecraft:polished_deepslate
fill 525 274 236 525 276 236 minecraft:dark_oak_planks
fill 525 274 237 525 274 261 minecraft:deepslate_tiles
fill 525 274 262 525 276 262 minecraft:dark_oak_planks
fill 525 274 263 551 274 263 minecraft:polished_deepslate
fill 526 274 236 550 274 236 minecraft:deepslate_tiles
fill 526 274 262 550 274 262 minecraft:deepslate_tiles
setblock 527 274 228 minecraft:magenta_terracotta
setblock 527 274 231 minecraft:light[level=12]
setblock 527 274 238 minecraft:light[level=12]
setblock 527 274 245 minecraft:light[level=12]
setblock 527 274 252 minecraft:light[level=12]
setblock 527 274 259 minecraft:light[level=12]
setblock 527 274 266 minecraft:light[level=12]
setblock 527 274 270 minecraft:magenta_terracotta
setblock 531 274 228 minecraft:magenta_terracotta
setblock 531 274 270 minecraft:magenta_terracotta
setblock 534 274 231 minecraft:light[level=12]
setblock 534 274 238 minecraft:light[level=12]
setblock 534 274 245 minecraft:light[level=12]
setblock 534 274 252 minecraft:light[level=12]
setblock 534 274 259 minecraft:light[level=12]
setblock 534 274 266 minecraft:light[level=12]
setblock 535 274 228 minecraft:magenta_terracotta
setblock 535 274 270 minecraft:magenta_terracotta
setblock 539 274 228 minecraft:magenta_terracotta
setblock 539 274 270 minecraft:magenta_terracotta
setblock 541 274 231 minecraft:light[level=12]
setblock 541 274 238 minecraft:light[level=12]
setblock 541 274 245 minecraft:light[level=12]
setblock 541 274 259 minecraft:light[level=12]
setblock 541 274 266 minecraft:light[level=12]
setblock 543 274 228 minecraft:magenta_terracotta
setblock 543 274 270 minecraft:magenta_terracotta
setblock 547 274 228 minecraft:magenta_terracotta
setblock 547 274 270 minecraft:magenta_terracotta
setblock 548 274 231 minecraft:light[level=12]
setblock 548 274 238 minecraft:light[level=12]
setblock 548 274 245 minecraft:light[level=12]
setblock 548 274 252 minecraft:light[level=12]
setblock 548 274 259 minecraft:light[level=12]
setblock 548 274 266 minecraft:light[level=12]
setblock 551 274 228 minecraft:magenta_terracotta
fill 551 274 236 551 276 236 minecraft:dark_oak_planks
fill 551 274 237 551 274 261 minecraft:deepslate_tiles
fill 551 274 262 551 276 262 minecraft:dark_oak_planks
setblock 551 274 270 minecraft:magenta_terracotta
fill 552 274 235 552 276 235 minecraft:dark_oak_planks
fill 552 274 236 552 274 262 minecraft:polished_deepslate
fill 552 274 263 552 276 263 minecraft:dark_oak_planks
fill 553 274 235 553 275 263 minecraft:deepslate_tiles
setblock 555 274 228 minecraft:magenta_terracotta
setblock 555 274 231 minecraft:light[level=12]
setblock 555 274 238 minecraft:light[level=12]
setblock 555 274 245 minecraft:light[level=12]
setblock 555 274 252 minecraft:light[level=12]
setblock 555 274 259 minecraft:light[level=12]
setblock 555 274 266 minecraft:light[level=12]
setblock 555 274 270 minecraft:magenta_terracotta
setblock 559 274 228 minecraft:magenta_terracotta
setblock 559 274 230 minecraft:magenta_terracotta
setblock 559 274 234 minecraft:magenta_terracotta
setblock 559 274 238 minecraft:magenta_terracotta
fill 559 274 239 559 278 239 minecraft:purple_terracotta
setblock 559 274 242 minecraft:magenta_terracotta
setblock 559 274 246 minecraft:magenta_terracotta
setblock 559 274 250 minecraft:magenta_terracotta
setblock 559 274 254 minecraft:magenta_terracotta
setblock 559 274 258 minecraft:magenta_terracotta
setblock 559 274 262 minecraft:magenta_terracotta
setblock 559 274 266 minecraft:magenta_terracotta
setblock 559 274 270 minecraft:magenta_terracotta
fill 517 275 230 517 277 230 minecraft:purple_terracotta
fill 517 275 234 517 277 234 minecraft:purple_terracotta
fill 517 275 238 517 277 238 minecraft:purple_terracotta
fill 517 275 242 517 277 242 minecraft:purple_terracotta
fill 517 275 246 517 277 246 minecraft:purple_terracotta
fill 517 275 250 517 277 250 minecraft:purple_terracotta
fill 517 275 254 517 277 254 minecraft:purple_terracotta
fill 517 275 258 517 277 258 minecraft:purple_terracotta
fill 517 275 261 517 277 262 minecraft:purple_terracotta
fill 517 275 266 517 277 266 minecraft:purple_terracotta
setblock 517 275 270 minecraft:purple_terracotta
fill 519 275 228 519 277 228 minecraft:purple_terracotta
fill 519 275 270 519 277 270 minecraft:purple_terracotta
fill 521 275 230 522 275 230 minecraft:spruce_planks
setblock 521 275 270 minecraft:purple_terracotta
fill 523 275 228 523 277 228 minecraft:purple_terracotta
fill 523 275 229 524 275 230 minecraft:dark_oak_planks
fill 523 275 270 523 277 270 minecraft:purple_terracotta
fill 524 275 236 524 276 262 minecraft:deepslate_tiles
fill 525 275 235 551 276 235 minecraft:deepslate_tiles
fill 525 275 237 525 275 261 minecraft:polished_deepslate
fill 525 275 263 551 276 263 minecraft:deepslate_tiles
fill 526 275 236 550 275 236 minecraft:polished_deepslate
fill 526 275 237 526 277 237 minecraft:dark_oak_planks
fill 526 275 238 526 275 260 minecraft:deepslate_tiles
fill 526 275 261 526 277 261 minecraft:dark_oak_planks
fill 526 275 262 550 275 262 minecraft:polished_deepslate
fill 527 275 228 527 277 228 minecraft:purple_terracotta
fill 527 275 237 549 275 237 minecraft:deepslate_tiles
fill 527 275 261 549 275 261 minecraft:deepslate_tiles
fill 527 275 270 527 277 270 minecraft:purple_terracotta
fill 531 275 228 531 277 228 minecraft:purple_terracotta
fill 531 275 270 531 277 270 minecraft:purple_terracotta
fill 535 275 228 535 277 228 minecraft:purple_terracotta
fill 535 275 270 535 277 270 minecraft:purple_terracotta
fill 539 275 228 539 277 228 minecraft:purple_terracotta
fill 539 275 270 539 277 270 minecraft:purple_terracotta
fill 543 275 228 543 277 228 minecraft:purple_terracotta
fill 543 275 270 543 277 270 minecraft:purple_terracotta
fill 547 275 228 547 277 228 minecraft:purple_terracotta
fill 547 275 270 547 277 270 minecraft:purple_terracotta
fill 550 275 237 550 277 237 minecraft:dark_oak_planks
fill 550 275 238 550 275 260 minecraft:deepslate_tiles
fill 550 275 261 550 277 261 minecraft:dark_oak_planks
fill 551 275 228 551 277 228 minecraft:purple_terracotta
fill 551 275 237 551 275 261 minecraft:polished_deepslate
fill 551 275 270 551 277 270 minecraft:purple_terracotta
fill 552 275 236 552 276 262 minecraft:deepslate_tiles
fill 555 275 228 555 277 228 minecraft:purple_terracotta
fill 555 275 270 555 277 270 minecraft:purple_terracotta
setblock 559 275 228 minecraft:purple_terracotta
fill 559 275 230 559 277 230 minecraft:purple_terracotta
fill 559 275 234 559 277 234 minecraft:purple_terracotta
fill 559 275 238 559 277 238 minecraft:purple_terracotta
fill 559 275 242 559 277 242 minecraft:purple_terracotta
fill 559 275 246 559 277 246 minecraft:purple_terracotta
fill 559 275 250 559 277 250 minecraft:purple_terracotta
fill 559 275 254 559 277 254 minecraft:purple_terracotta
setblock 559 275 255 minecraft:gray_terracotta
fill 559 275 258 559 277 258 minecraft:purple_terracotta
fill 559 275 262 559 277 262 minecraft:purple_terracotta
fill 559 275 266 559 277 266 minecraft:purple_terracotta
fill 559 275 270 559 277 270 minecraft:purple_terracotta
setblock 517 276 228 minecraft:magenta_terracotta
setblock 517 276 232 minecraft:magenta_terracotta
setblock 517 276 236 minecraft:magenta_terracotta
setblock 517 276 240 minecraft:magenta_terracotta
setblock 517 276 244 minecraft:magenta_terracotta
setblock 517 276 248 minecraft:magenta_terracotta
setblock 517 276 252 minecraft:magenta_terracotta
setblock 517 276 256 minecraft:magenta_terracotta
setblock 517 276 260 minecraft:magenta_terracotta
setblock 517 276 264 minecraft:magenta_terracotta
setblock 517 276 268 minecraft:magenta_terracotta
setblock 517 276 270 minecraft:magenta_terracotta
fill 519 276 230 520 276 230 minecraft:spruce_planks
setblock 521 276 228 minecraft:magenta_terracotta
fill 521 276 229 522 276 230 minecraft:dark_oak_planks
setblock 521 276 270 minecraft:magenta_terracotta
setblock 525 276 228 minecraft:magenta_terracotta
fill 525 276 237 525 276 261 minecraft:deepslate_tiles
setblock 525 276 270 minecraft:magenta_terracotta
fill 526 276 236 550 276 236 minecraft:deepslate_tiles
fill 526 276 238 526 276 260 minecraft:polished_deepslate
fill 526 276 262 550 276 262 minecraft:deepslate_tiles
fill 527 276 237 549 276 237 minecraft:polished_deepslate
fill 527 276 238 527 278 238 minecraft:dark_oak_planks
fill 527 276 239 527 276 259 minecraft:deepslate_tiles
fill 527 276 260 527 278 260 minecraft:dark_oak_planks
fill 527 276 261 549 276 261 minecraft:polished_deepslate
fill 528 276 238 548 276 238 minecraft:deepslate_tiles
fill 528 276 260 548 276 260 minecraft:deepslate_tiles
setblock 529 276 228 minecraft:magenta_terracotta
setblock 529 276 270 minecraft:magenta_terracotta
setblock 533 276 228 minecraft:magenta_terracotta
setblock 533 276 270 minecraft:magenta_terracotta
setblock 537 276 228 minecraft:magenta_terracotta
setblock 537 276 270 minecraft:magenta_terracotta
setblock 541 276 228 minecraft:magenta_terracotta
setblock 541 276 270 minecraft:magenta_terracotta
setblock 545 276 228 minecraft:magenta_terracotta
setblock 545 276 270 minecraft:magenta_terracotta
setblock 546 276 270 minecraft:gray_terracotta
setblock 549 276 228 minecraft:magenta_terracotta
fill 549 276 238 549 278 238 minecraft:dark_oak_planks
fill 549 276 239 549 276 259 minecraft:deepslate_tiles
fill 549 276 260 549 278 260 minecraft:dark_oak_planks
setblock 549 276 270 minecraft:magenta_terracotta
fill 550 276 238 550 276 260 minecraft:polished_deepslate
fill 551 276 237 551 276 261 minecraft:deepslate_tiles
setblock 553 276 228 minecraft:magenta_terracotta
setblock 553 276 270 minecraft:magenta_terracotta
setblock 557 276 228 minecraft:magenta_terracotta
setblock 557 276 270 minecraft:magenta_terracotta
setblock 559 276 228 minecraft:magenta_terracotta
setblock 559 276 232 minecraft:magenta_terracotta
setblock 559 276 236 minecraft:magenta_terracotta
setblock 559 276 240 minecraft:magenta_terracotta
setblock 559 276 244 minecraft:magenta_terracotta
setblock 559 276 248 minecraft:magenta_terracotta
setblock 559 276 252 minecraft:magenta_terracotta
fill 559 276 255 559 278 255 minecraft:purple_terracotta
setblock 559 276 256 minecraft:magenta_terracotta
setblock 559 276 257 minecraft:gray_terracotta
setblock 559 276 260 minecraft:magenta_terracotta
setblock 559 276 264 minecraft:magenta_terracotta
setblock 559 276 268 minecraft:magenta_terracotta
fill 517 277 228 517 278 228 minecraft:purple_terracotta
fill 517 277 232 517 278 232 minecraft:purple_terracotta
fill 517 277 236 517 278 236 minecraft:purple_terracotta
fill 517 277 240 517 278 240 minecraft:purple_terracotta
fill 517 277 244 517 278 244 minecraft:purple_terracotta
fill 517 277 248 517 278 248 minecraft:purple_terracotta
fill 517 277 252 517 278 252 minecraft:purple_terracotta
fill 517 277 256 517 278 256 minecraft:purple_terracotta
fill 517 277 260 517 278 260 minecraft:purple_terracotta
fill 517 277 264 517 278 264 minecraft:purple_terracotta
fill 517 277 268 517 278 268 minecraft:purple_terracotta
setblock 517 277 270 minecraft:purple_terracotta
fill 518 277 229 520 277 230 minecraft:dark_oak_planks
fill 521 277 228 521 278 228 minecraft:purple_terracotta
fill 521 277 270 521 278 270 minecraft:purple_terracotta
fill 525 277 228 525 278 228 minecraft:purple_terracotta
fill 525 277 270 525 278 270 minecraft:purple_terracotta
fill 526 277 238 526 277 260 minecraft:deepslate_tiles
fill 527 277 237 549 277 237 minecraft:deepslate_tiles
fill 527 277 239 527 277 259 minecraft:polished_deepslate
fill 527 277 261 549 277 261 minecraft:deepslate_tiles
fill 528 277 238 548 277 238 minecraft:polished_deepslate
fill 528 277 239 528 279 239 minecraft:dark_oak_planks
fill 528 277 240 528 277 258 minecraft:deepslate_tiles
fill 528 277 259 528 279 259 minecraft:dark_oak_planks
fill 528 277 260 548 277 260 minecraft:polished_deepslate
fill 529 277 228 529 278 228 minecraft:purple_terracotta
fill 529 277 239 547 277 239 minecraft:deepslate_tiles
fill 529 277 240 529 279 240 minecraft:dark_oak_planks
fill 529 277 241 529 278 257 minecraft:deepslate_tiles
fill 529 277 258 529 279 258 minecraft:dark_oak_planks
fill 529 277 259 547 277 259 minecraft:deepslate_tiles
fill 529 277 270 529 278 270 minecraft:purple_terracotta
fill 530 277 240 546 278 240 minecraft:deepslate_tiles
fill 530 277 258 546 278 258 minecraft:deepslate_tiles
fill 533 277 228 533 278 228 minecraft:purple_terracotta
fill 533 277 270 533 278 270 minecraft:purple_terracotta
fill 537 277 228 537 278 228 minecraft:purple_terracotta
fill 537 277 270 537 278 270 minecraft:purple_terracotta
fill 541 277 228 541 278 228 minecraft:purple_terracotta
fill 541 277 270 541 278 270 minecraft:purple_terracotta
fill 545 277 228 545 278 228 minecraft:purple_terracotta
fill 545 277 270 546 278 270 minecraft:purple_terracotta
fill 547 277 240 547 279 240 minecraft:dark_oak_planks
fill 547 277 241 548 277 257 minecraft:deepslate_tiles
fill 547 277 258 547 279 258 minecraft:dark_oak_planks
fill 548 277 239 548 279 239 minecraft:dark_oak_planks
setblock 548 277 240 minecraft:deepslate_tiles
setblock 548 277 258 minecraft:deepslate_tiles
fill 548 277 259 548 279 259 minecraft:dark_oak_planks
fill 549 277 228 549 278 228 minecraft:purple_terracotta
fill 549 277 239 549 277 259 minecraft:polished_deepslate
fill 549 277 270 549 278 270 minecraft:purple_terracotta
fill 550 277 238 550 277 260 minecraft:deepslate_tiles
setblock 550 277 270 minecraft:black_terracotta
fill 553 277 228 553 278 228 minecraft:purple_terracotta
fill 553 277 270 553 278 270 minecraft:purple_terracotta
fill 557 277 228 557 278 228 minecraft:purple_terracotta
fill 557 277 270 557 278 270 minecraft:purple_terracotta
setblock 559 277 228 minecraft:purple_terracotta
fill 559 277 232 559 278 232 minecraft:purple_terracotta
fill 559 277 236 559 278 236 minecraft:purple_terracotta
fill 559 277 240 559 278 240 minecraft:purple_terracotta
fill 559 277 244 559 278 244 minecraft:purple_terracotta
fill 559 277 248 559 278 248 minecraft:purple_terracotta
fill 559 277 252 559 278 252 minecraft:purple_terracotta
fill 559 277 256 559 278 257 minecraft:purple_terracotta
fill 559 277 260 559 278 260 minecraft:purple_terracotta
fill 559 277 264 559 278 264 minecraft:purple_terracotta
fill 559 277 268 559 278 268 minecraft:purple_terracotta
setblock 517 278 230 minecraft:magenta_terracotta
setblock 517 278 234 minecraft:magenta_terracotta
setblock 517 278 238 minecraft:magenta_terracotta
setblock 517 278 242 minecraft:magenta_terracotta
setblock 517 278 246 minecraft:magenta_terracotta
setblock 517 278 250 minecraft:magenta_terracotta
setblock 517 278 254 minecraft:magenta_terracotta
setblock 517 278 258 minecraft:magenta_terracotta
setblock 517 278 261 minecraft:purple_terracotta
setblock 517 278 262 minecraft:magenta_terracotta
setblock 517 278 266 minecraft:magenta_terracotta
setblock 517 278 270 minecraft:magenta_terracotta
setblock 519 278 228 minecraft:magenta_terracotta
setblock 519 278 270 minecraft:magenta_terracotta
setblock 523 278 228 minecraft:magenta_terracotta
setblock 523 278 270 minecraft:magenta_terracotta
setblock 527 278 228 minecraft:magenta_terracotta
fill 527 278 239 527 278 259 minecraft:deepslate_tiles
setblock 527 278 270 minecraft:magenta_terracotta
fill 528 278 238 548 278 238 minecraft:deepslate_tiles
fill 528 278 240 528 278 258 minecraft:polished_deepslate
fill 528 278 260 548 278 260 minecraft:deepslate_tiles
fill 529 278 239 547 278 239 minecraft:polished_deepslate
fill 529 278 259 547 278 259 minecraft:polished_deepslate
fill 530 278 241 530 280 241 minecraft:dark_oak_planks
fill 530 278 242 530 279 256 minecraft:deepslate_tiles
fill 530 278 257 530 280 257 minecraft:dark_oak_planks
setblock 531 278 228 minecraft:magenta_terracotta
fill 531 278 241 545 279 241 minecraft:deepslate_tiles
fill 531 278 257 545 279 257 minecraft:deepslate_tiles
setblock 531 278 270 minecraft:magenta_terracotta
setblock 535 278 228 minecraft:magenta_terracotta
setblock 535 278 270 minecraft:magenta_terracotta
setblock 539 278 228 minecraft:magenta_terracotta
setblock 539 278 270 minecraft:magenta_terracotta
setblock 543 278 228 minecraft:magenta_terracotta
setblock 543 278 270 minecraft:magenta_terracotta
fill 546 278 241 546 280 241 minecraft:dark_oak_planks
fill 546 278 242 547 278 256 minecraft:deepslate_tiles
fill 546 278 257 546 280 257 minecraft:dark_oak_planks
setblock 547 278 228 minecraft:magenta_terracotta
setblock 547 278 241 minecraft:deepslate_tiles
setblock 547 278 257 minecraft:deepslate_tiles
setblock 547 278 270 minecraft:magenta_terracotta
fill 548 278 240 548 278 258 minecraft:polished_deepslate
fill 549 278 239 549 278 259 minecraft:deepslate_tiles
setblock 550 278 270 minecraft:purple_terracotta
setblock 551 278 228 minecraft:magenta_terracotta
setblock 551 278 270 minecraft:magenta_terracotta
setblock 555 278 228 minecraft:magenta_terracotta
setblock 555 278 270 minecraft:magenta_terracotta
setblock 559 278 228 minecraft:magenta_terracotta
setblock 559 278 230 minecraft:magenta_terracotta
setblock 559 278 234 minecraft:magenta_terracotta
setblock 559 278 238 minecraft:magenta_terracotta
setblock 559 278 242 minecraft:magenta_terracotta
setblock 559 278 246 minecraft:magenta_terracotta
setblock 559 278 250 minecraft:magenta_terracotta
setblock 559 278 254 minecraft:magenta_terracotta
setblock 559 278 258 minecraft:magenta_terracotta
setblock 559 278 262 minecraft:magenta_terracotta
setblock 559 278 266 minecraft:magenta_terracotta
setblock 559 278 270 minecraft:magenta_terracotta
fill 517 279 228 518 279 228 minecraft:blue_terracotta
fill 517 279 229 517 282 230 minecraft:gray_terracotta
setblock 517 279 231 minecraft:blue_terracotta
fill 517 279 232 517 279 243 minecraft:gray_terracotta
fill 517 279 244 517 280 244 minecraft:blue_terracotta
fill 517 279 245 517 279 258 minecraft:gray_terracotta
setblock 517 279 259 minecraft:blue_terracotta
fill 517 279 260 517 280 263 minecraft:gray_terracotta
setblock 517 279 264 minecraft:blue_terracotta
fill 517 279 265 517 279 270 minecraft:gray_terracotta
fill 518 279 233 521 283 233 minecraft:cobbled_deepslate
fill 518 279 265 521 283 265 minecraft:cobbled_deepslate
fill 518 279 270 527 282 270 minecraft:gray_terracotta
fill 519 279 228 521 280 228 minecraft:gray_terracotta
fill 519 279 231 520 280 231 minecraft:ochre_froglight
fill 519 279 232 520 283 232 minecraft:cobbled_deepslate
fill 519 279 234 520 280 234 minecraft:ochre_froglight
fill 519 279 235 520 283 235 minecraft:cobbled_deepslate
fill 519 279 263 520 280 263 minecraft:ochre_froglight
fill 519 279 264 520 283 264 minecraft:cobbled_deepslate
fill 519 279 266 520 280 266 minecraft:ochre_froglight
fill 519 279 267 520 283 267 minecraft:cobbled_deepslate
fill 520 279 230 520 283 230 minecraft:cobbled_deepslate
fill 520 279 236 520 280 236 minecraft:ochre_froglight
fill 520 279 262 520 283 262 minecraft:cobbled_deepslate
fill 520 279 268 520 280 268 minecraft:ochre_froglight
fill 521 279 230 521 280 230 minecraft:ochre_froglight
fill 521 279 231 522 283 231 minecraft:cobbled_deepslate
fill 521 279 232 521 280 232 minecraft:ochre_froglight
fill 521 279 234 521 283 234 minecraft:cobbled_deepslate
fill 521 279 235 522 280 235 minecraft:ochre_froglight
fill 521 279 236 521 283 236 minecraft:cobbled_deepslate
fill 521 279 262 521 280 262 minecraft:ochre_froglight
fill 521 279 263 522 283 263 minecraft:cobbled_deepslate
fill 521 279 264 521 280 264 minecraft:ochre_froglight
fill 521 279 266 521 283 266 minecraft:cobbled_deepslate
fill 521 279 267 522 280 267 minecraft:ochre_froglight
fill 521 279 268 521 283 268 minecraft:cobbled_deepslate
setblock 522 279 228 minecraft:blue_terracotta
fill 522 279 229 522 283 230 minecraft:cobbled_deepslate
fill 522 279 232 523 283 232 minecraft:cobbled_deepslate
fill 522 279 233 523 280 234 minecraft:ochre_froglight
fill 522 279 236 522 280 237 minecraft:ochre_froglight
fill 522 279 261 522 283 262 minecraft:cobbled_deepslate
fill 522 279 264 523 283 264 minecraft:cobbled_deepslate
fill 522 279 265 523 280 266 minecraft:ochre_froglight
fill 522 279 268 522 280 269 minecraft:ochre_froglight
fill 523 279 228 523 282 228 minecraft:gray_terracotta
fill 523 279 230 523 280 231 minecraft:ochre_froglight
fill 523 279 235 523 283 236 minecraft:cobbled_deepslate
fill 523 279 262 523 280 263 minecraft:ochre_froglight
fill 523 279 267 523 283 268 minecraft:cobbled_deepslate
setblock 524 279 228 minecraft:blue_terracotta
fill 524 279 230 524 283 231 minecraft:cobbled_deepslate
fill 524 279 232 524 280 233 minecraft:ochre_froglight
fill 524 279 234 524 283 234 minecraft:cobbled_deepslate
fill 524 279 235 524 280 236 minecraft:ochre_froglight
fill 524 279 262 524 283 263 minecraft:cobbled_deepslate
fill 524 279 264 524 280 265 minecraft:ochre_froglight
fill 524 279 266 524 283 266 minecraft:cobbled_deepslate
fill 524 279 267 524 280 268 minecraft:ochre_froglight
fill 525 279 228 548 279 228 minecraft:gray_terracotta
fill 525 279 231 525 280 231 minecraft:ochre_froglight
fill 525 279 232 525 283 232 minecraft:cobbled_deepslate
fill 525 279 233 525 280 234 minecraft:ochre_froglight
fill 525 279 235 525 283 235 minecraft:cobbled_deepslate
fill 525 279 263 525 280 263 minecraft:ochre_froglight
fill 525 279 264 525 283 264 minecraft:cobbled_deepslate
fill 525 279 265 525 280 266 minecraft:ochre_froglight
fill 525 279 267 525 283 267 minecraft:cobbled_deepslate
fill 526 279 233 526 280 233 minecraft:ochre_froglight
fill 526 279 251 528 284 253 minecraft:red_nether_bricks
fill 526 279 265 526 280 265 minecraft:ochre_froglight
fill 528 279 240 528 279 250 minecraft:deepslate_tiles
fill 528 279 254 528 279 258 minecraft:deepslate_tiles
setblock 528 279 270 minecraft:blue_terracotta
fill 529 279 239 547 279 239 minecraft:deepslate_tiles
fill 529 279 241 529 279 257 minecraft:polished_deepslate
fill 529 279 259 547 279 259 minecraft:deepslate_tiles
fill 529 279 270 529 282 270 minecraft:gray_terracotta
fill 530 279 240 546 279 240 minecraft:polished_deepslate
fill 530 279 258 546 279 258 minecraft:polished_deepslate
setblock 530 279 270 minecraft:blue_terracotta
fill 531 279 242 531 281 242 minecraft:dark_oak_planks
fill 531 279 243 531 280 255 minecraft:deepslate_tiles
fill 531 279 256 531 281 256 minecraft:dark_oak_planks
fill 531 279 270 536 282 270 minecraft:gray_terracotta
fill 532 279 242 544 280 242 minecraft:deepslate_tiles
fill 532 279 243 532 281 243 minecraft:dark_oak_planks
fill 532 279 244 532 279 254 minecraft:polished_deepslate
fill 532 279 255 532 281 255 minecraft:dark_oak_planks
fill 532 279 256 544 280 256 minecraft:deepslate_tiles
fill 533 279 243 543 279 243 minecraft:polished_deepslate
fill 533 279 244 533 281 244 minecraft:dark_oak_planks
fill 533 279 245 533 279 253 minecraft:deepslate_tiles
fill 533 279 254 533 281 254 minecraft:dark_oak_planks
fill 533 279 255 543 279 255 minecraft:polished_deepslate
fill 534 279 244 538 279 244 minecraft:deepslate_tiles
fill 534 279 245 534 280 245 minecraft:dark_oak_planks
fill 534 279 246 534 280 252 minecraft:deepslate_tiles
fill 534 279 253 534 281 253 minecraft:dark_oak_planks
fill 534 279 254 542 279 254 minecraft:deepslate_tiles
fill 535 279 245 536 280 245 minecraft:deepslate_tiles
fill 535 279 246 535 280 246 minecraft:dark_oak_planks
fill 535 279 247 535 279 251 minecraft:polished_deepslate
fill 535 279 252 535 281 252 minecraft:dark_oak_planks
fill 535 279 253 541 280 253 minecraft:deepslate_tiles
setblock 536 279 246 minecraft:polished_deepslate
fill 536 279 248 536 279 250 minecraft:deepslate_tiles
fill 536 279 251 536 280 251 minecraft:dark_oak_planks
fill 536 279 252 540 279 252 minecraft:polished_deepslate
fill 537 279 250 537 280 250 minecraft:dark_oak_planks
fill 537 279 251 539 279 251 minecraft:deepslate_tiles
setblock 537 279 270 minecraft:blue_terracotta
fill 538 279 250 538 280 250 minecraft:deepslate_tiles
fill 538 279 270 559 279 270 minecraft:gray_terracotta
fill 540 279 244 542 279 244 minecraft:deepslate_tiles
setblock 540 279 250 minecraft:deepslate_tiles
fill 540 279 251 540 280 251 minecraft:dark_oak_planks
fill 541 279 250 541 279 251 minecraft:polished_deepslate
fill 541 279 252 541 280 252 minecraft:dark_oak_planks
fill 542 279 245 542 280 245 minecraft:dark_oak_planks
fill 542 279 246 543 279 246 minecraft:deepslate_tiles
fill 542 279 248 543 279 252 minecraft:deepslate_tiles
fill 542 279 253 542 281 253 minecraft:dark_oak_planks
fill 543 279 244 543 280 244 minecraft:dark_oak_planks
setblock 543 279 245 minecraft:deepslate_tiles
setblock 543 279 247 minecraft:deepslate_tiles
setblock 543 279 253 minecraft:deepslate_tiles
fill 543 279 254 543 281 254 minecraft:dark_oak_planks
fill 544 279 243 544 281 243 minecraft:dark_oak_planks
fill 544 279 244 544 279 254 minecraft:polished_deepslate
fill 544 279 255 544 281 255 minecraft:dark_oak_planks
fill 545 279 242 545 281 242 minecraft:dark_oak_planks
fill 545 279 243 546 279 255 minecraft:deepslate_tiles
fill 545 279 256 545 281 256 minecraft:dark_oak_planks
setblock 546 279 242 minecraft:deepslate_tiles
setblock 546 279 256 minecraft:deepslate_tiles
fill 547 279 241 547 279 257 minecraft:polished_deepslate
fill 548 279 240 548 279 243 minecraft:deepslate_tiles
fill 548 279 244 550 284 246 minecraft:red_nether_bricks
fill 548 279 247 548 279 258 minecraft:deepslate_tiles
setblock 549 279 228 minecraft:blue_terracotta
fill 550 279 228 551 280 228 minecraft:gray_terracotta
fill 550 279 233 553 283 233 minecraft:cobbled_deepslate
fill 550 279 265 553 283 265 minecraft:cobbled_deepslate
fill 551 279 231 552 280 231 minecraft:ochre_froglight
fill 551 279 232 552 283 232 minecraft:cobbled_deepslate
fill 551 279 234 552 280 234 minecraft:ochre_froglight
fill 551 279 235 552 283 235 minecraft:cobbled_deepslate
fill 551 279 263 552 280 263 minecraft:ochre_froglight
fill 551 279 264 552 283 264 minecraft:cobbled_deepslate
fill 551 279 266 552 280 266 minecraft:ochre_froglight
fill 551 279 267 552 283 267 minecraft:cobbled_deepslate
setblock 552 279 228 minecraft:blue_terracotta
fill 552 279 230 552 283 230 minecraft:cobbled_deepslate
fill 552 279 236 552 280 236 minecraft:ochre_froglight
fill 552 279 262 552 283 262 minecraft:cobbled_deepslate
fill 552 279 268 552 280 268 minecraft:ochre_froglight
fill 553 279 228 559 279 228 minecraft:gray_terracotta
fill 553 279 230 553 280 230 minecraft:ochre_froglight
fill 553 279 231 554 283 231 minecraft:cobbled_deepslate
fill 553 279 232 553 280 232 minecraft:ochre_froglight
fill 553 279 234 553 283 234 minecraft:cobbled_deepslate
fill 553 279 235 554 280 235 minecraft:ochre_froglight
fill 553 279 236 553 283 236 minecraft:cobbled_deepslate
fill 553 279 262 553 280 262 minecraft:ochre_froglight
fill 553 279 263 554 283 263 minecraft:cobbled_deepslate
fill 553 279 264 553 280 264 minecraft:ochre_froglight
fill 553 279 266 553 283 266 minecraft:cobbled_deepslate
fill 553 279 267 554 280 267 minecraft:ochre_froglight
fill 553 279 268 553 283 268 minecraft:cobbled_deepslate
fill 554 279 229 554 283 230 minecraft:cobbled_deepslate
fill 554 279 232 555 283 232 minecraft:cobbled_deepslate
fill 554 279 233 555 280 234 minecraft:ochre_froglight
fill 554 279 236 554 280 237 minecraft:ochre_froglight
fill 554 279 261 554 283 262 minecraft:cobbled_deepslate
fill 554 279 264 555 283 264 minecraft:cobbled_deepslate
fill 554 279 265 555 280 266 minecraft:ochre_froglight
fill 554 279 268 554 280 269 minecraft:ochre_froglight
fill 555 279 230 555 280 231 minecraft:ochre_froglight
fill 555 279 235 555 283 236 minecraft:cobbled_deepslate
fill 555 279 262 555 280 263 minecraft:ochre_froglight
fill 555 279 267 555 283 268 minecraft:cobbled_deepslate
fill 556 279 230 556 283 231 minecraft:cobbled_deepslate
fill 556 279 232 556 280 233 minecraft:ochre_froglight
fill 556 279 234 556 283 234 minecraft:cobbled_deepslate
fill 556 279 235 556 280 236 minecraft:ochre_froglight
fill 556 279 262 556 283 263 minecraft:cobbled_deepslate
fill 556 279 264 556 280 265 minecraft:ochre_froglight
fill 556 279 266 556 283 266 minecraft:cobbled_deepslate
fill 556 279 267 556 280 268 minecraft:ochre_froglight
fill 557 279 231 557 280 231 minecraft:ochre_froglight
fill 557 279 232 557 283 232 minecraft:cobbled_deepslate
fill 557 279 233 557 280 234 minecraft:ochre_froglight
fill 557 279 235 557 283 235 minecraft:cobbled_deepslate
fill 557 279 263 557 280 263 minecraft:ochre_froglight
fill 557 279 264 557 283 264 minecraft:cobbled_deepslate
fill 557 279 265 557 280 266 minecraft:ochre_froglight
fill 557 279 267 557 283 267 minecraft:cobbled_deepslate
fill 558 279 233 558 280 233 minecraft:ochre_froglight
fill 558 279 265 558 280 265 minecraft:ochre_froglight
setblock 559 279 229 minecraft:blue_terracotta
fill 559 279 230 559 279 242 minecraft:gray_terracotta
setblock 559 279 243 minecraft:blue_terracotta
fill 559 279 244 559 280 249 minecraft:gray_terracotta
setblock 559 279 250 minecraft:blue_terracotta
fill 559 279 251 559 282 256 minecraft:gray_terracotta
setblock 559 279 257 minecraft:blue_terracotta
fill 559 279 258 559 279 269 minecraft:gray_terracotta
fill 517 280 228 518 282 228 minecraft:gray_terracotta
fill 517 280 231 517 283 231 minecraft:gray_terracotta
setblock 517 280 232 minecraft:blue_terracotta
fill 517 280 233 517 282 234 minecraft:gray_terracotta
setblock 517 280 235 minecraft:blue_terracotta
fill 517 280 236 517 282 241 minecraft:gray_terracotta
fill 517 280 242 517 281 242 minecraft:blue_terracotta
fill 517 280 243 517 282 243 minecraft:gray_terracotta
fill 517 280 245 517 280 248 minecraft:gray_terracotta
fill 517 280 249 517 280 250 minecraft:blue_terracotta
fill 517 280 251 517 282 259 minecraft:gray_terracotta
fill 517 280 264 517 282 265 minecraft:gray_terracotta
fill 517 280 266 517 280 268 minecraft:blue_terracotta
fill 517 280 269 517 282 270 minecraft:gray_terracotta
setblock 520 280 238 minecraft:light[level=12]
setblock 520 280 239 minecraft:light[level=11]
setblock 520 280 245 minecraft:light[level=12]
setblock 520 280 247 minecraft:light[level=11]
setblock 520 280 252 minecraft:light[level=12]
setblock 520 280 255 minecraft:light[level=11]
setblock 520 280 259 minecraft:light[level=12]
setblock 522 280 228 minecraft:gray_terracotta
fill 524 280 228 527 280 228 minecraft:gray_terracotta
setblock 527 280 231 minecraft:light[level=12]
setblock 527 280 238 minecraft:light[level=12]
setblock 527 280 245 minecraft:light[level=12]
setblock 527 280 259 minecraft:light[level=12]
setblock 527 280 266 minecraft:light[level=12]
setblock 528 280 228 minecraft:blue_terracotta
setblock 528 280 231 minecraft:light[level=11]
setblock 528 280 239 minecraft:light[level=11]
setblock 528 280 247 minecraft:light[level=11]
setblock 528 280 255 minecraft:light[level=11]
setblock 528 280 263 minecraft:light[level=11]
fill 528 280 270 528 282 270 minecraft:gray_terracotta
fill 529 280 228 534 280 228 minecraft:gray_terracotta
fill 530 280 242 530 280 256 minecraft:polished_deepslate
fill 530 280 270 530 282 270 minecraft:gray_terracotta
fill 531 280 241 545 280 241 minecraft:polished_deepslate
fill 531 280 257 545 280 257 minecraft:polished_deepslate
fill 532 280 244 532 280 254 minecraft:deepslate_tiles
fill 533 280 243 543 280 243 minecraft:deepslate_tiles
fill 533 280 245 533 280 253 minecraft:polished_deepslate
fill 533 280 255 543 280 255 minecraft:deepslate_tiles
setblock 534 280 231 minecraft:light[level=12]
setblock 534 280 238 minecraft:light[level=12]
fill 534 280 244 538 280 244 minecraft:polished_deepslate
fill 534 280 254 542 280 254 minecraft:polished_deepslate
setblock 534 280 259 minecraft:light[level=12]
setblock 534 280 266 minecraft:light[level=12]
setblock 535 280 228 minecraft:blue_terracotta
fill 535 280 247 535 280 251 minecraft:deepslate_tiles
fill 536 280 228 549 280 228 minecraft:gray_terracotta
setblock 536 280 231 minecraft:light[level=11]
setblock 536 280 239 minecraft:light[level=11]
setblock 536 280 246 minecraft:deepslate_tiles
fill 536 280 248 536 280 250 minecraft:polished_deepslate
fill 536 280 252 540 280 252 minecraft:deepslate_tiles
setblock 536 280 263 minecraft:light[level=11]
fill 537 280 251 539 280 251 minecraft:polished_deepslate
fill 537 280 270 542 280 270 minecraft:gray_terracotta
fill 540 280 244 542 280 244 minecraft:polished_deepslate
setblock 540 280 250 minecraft:polished_deepslate
setblock 541 280 231 minecraft:light[level=12]
setblock 541 280 238 minecraft:light[level=12]
fill 541 280 250 542 280 251 minecraft:deepslate_tiles
schedule function dropper:buildpart/59_5 1t
