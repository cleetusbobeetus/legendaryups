fill 370 174 488 370 177 488 minecraft:pink_terracotta
fill 370 174 490 370 174 491 minecraft:pink_terracotta
setblock 370 174 492 minecraft:red_nether_bricks
fill 370 174 493 370 177 493 minecraft:pink_terracotta
setblock 370 174 497 minecraft:red_nether_bricks
fill 370 174 498 370 177 498 minecraft:pink_terracotta
setblock 370 174 502 minecraft:red_nether_bricks
fill 370 174 503 370 177 503 minecraft:pink_terracotta
fill 330 175 464 330 176 464 minecraft:pink_terracotta
setblock 330 175 466 minecraft:red_nether_bricks
fill 330 175 467 330 178 467 minecraft:pink_terracotta
fill 330 175 482 330 175 485 minecraft:pink_terracotta
setblock 330 175 486 minecraft:red_nether_bricks
fill 330 175 487 330 175 490 minecraft:pink_terracotta
setblock 330 175 491 minecraft:red_nether_bricks
fill 330 175 492 330 175 495 minecraft:pink_terracotta
setblock 330 175 496 minecraft:red_nether_bricks
fill 330 175 497 330 175 500 minecraft:pink_terracotta
setblock 330 175 501 minecraft:red_nether_bricks
setblock 330 175 502 minecraft:pink_terracotta
setblock 331 175 485 minecraft:red_nether_bricks
fill 331 175 486 331 175 489 minecraft:pink_terracotta
setblock 331 175 490 minecraft:red_nether_bricks
fill 331 175 491 331 178 491 minecraft:pink_terracotta
setblock 331 175 494 minecraft:pink_terracotta
setblock 332 175 466 minecraft:light[level=12]
setblock 332 175 474 minecraft:light[level=12]
setblock 332 175 482 minecraft:light[level=12]
setblock 332 175 490 minecraft:light[level=12]
setblock 332 175 498 minecraft:light[level=12]
fill 336 175 483 337 175 485 minecraft:bone_block
setblock 336 175 504 minecraft:white_concrete
setblock 337 175 482 minecraft:bone_block
setblock 339 175 464 minecraft:white_concrete
fill 340 175 464 341 175 464 minecraft:pink_terracotta
setblock 340 175 466 minecraft:light[level=12]
setblock 340 175 474 minecraft:light[level=12]
setblock 340 175 490 minecraft:light[level=12]
setblock 340 175 498 minecraft:light[level=12]
setblock 341 175 483 minecraft:bone_block
setblock 342 175 464 minecraft:red_nether_bricks
fill 342 175 465 345 175 465 minecraft:pink_terracotta
setblock 342 175 485 minecraft:bone_block
fill 343 175 464 346 175 464 minecraft:pink_terracotta
setblock 344 175 466 minecraft:pink_terracotta
fill 344 175 504 346 175 504 minecraft:pink_terracotta
setblock 345 175 466 minecraft:red_nether_bricks
setblock 346 175 465 minecraft:red_nether_bricks
fill 346 175 466 346 178 466 minecraft:pink_terracotta
setblock 347 175 464 minecraft:red_nether_bricks
fill 347 175 465 350 175 465 minecraft:pink_terracotta
setblock 347 175 504 minecraft:red_nether_bricks
fill 348 175 464 351 175 464 minecraft:pink_terracotta
setblock 348 175 474 minecraft:light[level=12]
setblock 348 175 482 minecraft:light[level=12]
setblock 348 175 490 minecraft:light[level=12]
setblock 348 175 498 minecraft:light[level=12]
setblock 350 175 466 minecraft:red_nether_bricks
setblock 351 175 465 minecraft:red_nether_bricks
fill 351 175 466 351 177 466 minecraft:pink_terracotta
setblock 352 175 464 minecraft:red_nether_bricks
fill 352 175 465 355 175 465 minecraft:pink_terracotta
setblock 352 175 484 minecraft:bone_block
fill 353 175 464 356 175 464 minecraft:pink_terracotta
setblock 356 175 465 minecraft:red_nether_bricks
setblock 356 175 466 minecraft:light[level=12]
setblock 356 175 474 minecraft:light[level=12]
setblock 356 175 482 minecraft:light[level=12]
setblock 356 175 490 minecraft:light[level=12]
setblock 356 175 498 minecraft:light[level=12]
setblock 357 175 464 minecraft:red_nether_bricks
fill 357 175 465 360 175 465 minecraft:pink_terracotta
fill 358 175 464 361 175 464 minecraft:pink_terracotta
fill 359 175 504 361 175 504 minecraft:pink_terracotta
setblock 360 175 466 minecraft:red_nether_bricks
setblock 361 175 465 minecraft:red_nether_bricks
fill 361 175 466 364 175 466 minecraft:pink_terracotta
setblock 362 175 464 minecraft:red_nether_bricks
fill 362 175 465 362 178 465 minecraft:pink_terracotta
setblock 362 175 503 minecraft:pink_terracotta
setblock 362 175 504 minecraft:red_nether_bricks
fill 363 175 464 363 178 464 minecraft:pink_terracotta
setblock 363 175 503 minecraft:red_nether_bricks
fill 363 175 504 363 178 504 minecraft:pink_terracotta
setblock 364 175 467 minecraft:red_nether_bricks
setblock 364 175 474 minecraft:light[level=12]
setblock 364 175 482 minecraft:light[level=12]
setblock 364 175 490 minecraft:light[level=12]
setblock 364 175 498 minecraft:light[level=12]
fill 364 175 503 364 178 503 minecraft:pink_terracotta
setblock 365 175 466 minecraft:red_nether_bricks
setblock 366 175 465 minecraft:red_nether_bricks
fill 366 175 466 366 178 466 minecraft:pink_terracotta
setblock 367 175 464 minecraft:red_nether_bricks
fill 367 175 465 367 178 465 minecraft:pink_terracotta
setblock 367 175 504 minecraft:red_nether_bricks
fill 368 175 464 368 178 464 minecraft:pink_terracotta
setblock 368 175 468 minecraft:red_nether_bricks
setblock 368 175 503 minecraft:red_nether_bricks
fill 368 175 504 368 178 504 minecraft:pink_terracotta
setblock 369 175 467 minecraft:red_nether_bricks
fill 369 175 468 369 178 468 minecraft:pink_terracotta
fill 369 175 470 369 176 470 minecraft:pink_terracotta
setblock 369 175 487 minecraft:red_nether_bricks
fill 369 175 488 369 175 491 minecraft:pink_terracotta
setblock 369 175 492 minecraft:red_nether_bricks
fill 369 175 493 369 178 493 minecraft:pink_terracotta
fill 369 175 495 369 176 495 minecraft:pink_terracotta
setblock 369 175 502 minecraft:red_nether_bricks
fill 369 175 503 369 178 503 minecraft:pink_terracotta
setblock 370 175 466 minecraft:red_nether_bricks
fill 370 175 467 370 178 467 minecraft:pink_terracotta
setblock 370 175 471 minecraft:red_nether_bricks
setblock 370 175 477 minecraft:white_concrete
setblock 370 175 486 minecraft:red_nether_bricks
fill 370 175 487 370 178 487 minecraft:pink_terracotta
setblock 370 175 490 minecraft:pink_terracotta
setblock 370 175 491 minecraft:red_nether_bricks
fill 370 175 492 370 178 492 minecraft:pink_terracotta
setblock 370 175 496 minecraft:red_nether_bricks
fill 370 175 497 370 178 497 minecraft:pink_terracotta
setblock 370 175 501 minecraft:red_nether_bricks
fill 370 175 502 370 178 502 minecraft:pink_terracotta
setblock 330 176 465 minecraft:red_nether_bricks
fill 330 176 466 330 178 466 minecraft:pink_terracotta
setblock 330 176 470 minecraft:red_nether_bricks
fill 330 176 471 330 179 471 minecraft:pink_terracotta
setblock 330 176 472 minecraft:white_concrete
fill 330 176 482 330 176 484 minecraft:pink_terracotta
setblock 330 176 485 minecraft:red_nether_bricks
fill 330 176 486 330 176 489 minecraft:pink_terracotta
setblock 330 176 490 minecraft:red_nether_bricks
fill 330 176 491 330 176 494 minecraft:pink_terracotta
setblock 330 176 495 minecraft:red_nether_bricks
fill 330 176 496 330 176 499 minecraft:pink_terracotta
setblock 330 176 504 minecraft:pink_terracotta
fill 331 176 485 331 176 488 minecraft:pink_terracotta
setblock 331 176 489 minecraft:red_nether_bricks
fill 331 176 490 332 178 490 minecraft:pink_terracotta
setblock 331 176 494 minecraft:red_nether_bricks
fill 332 176 489 332 179 489 minecraft:pink_terracotta
setblock 333 176 464 minecraft:white_concrete
fill 337 176 484 339 176 484 minecraft:bone_block
fill 338 176 483 339 176 483 minecraft:bone_block
fill 338 176 485 339 176 485 minecraft:bone_block
fill 339 176 464 340 176 464 minecraft:pink_terracotta
setblock 341 176 464 minecraft:red_nether_bricks
fill 341 176 465 344 176 465 minecraft:pink_terracotta
fill 342 176 464 345 176 464 minecraft:pink_terracotta
setblock 342 176 504 minecraft:white_concrete
setblock 343 176 466 minecraft:pink_terracotta
setblock 344 176 466 minecraft:red_nether_bricks
fill 344 176 504 345 176 504 minecraft:pink_terracotta
setblock 345 176 465 minecraft:red_nether_bricks
fill 345 176 466 345 179 466 minecraft:pink_terracotta
setblock 346 176 464 minecraft:red_nether_bricks
fill 346 176 465 349 176 465 minecraft:pink_terracotta
fill 346 176 467 347 176 467 minecraft:pink_terracotta
setblock 346 176 504 minecraft:red_nether_bricks
fill 347 176 464 350 176 464 minecraft:pink_terracotta
fill 347 176 504 347 177 504 minecraft:pink_terracotta
fill 348 176 504 348 177 504 minecraft:white_concrete
setblock 349 176 466 minecraft:red_nether_bricks
setblock 350 176 465 minecraft:red_nether_bricks
fill 350 176 466 350 179 466 minecraft:pink_terracotta
setblock 351 176 464 minecraft:red_nether_bricks
fill 351 176 465 354 176 465 minecraft:pink_terracotta
fill 352 176 464 355 176 464 minecraft:pink_terracotta
setblock 355 176 465 minecraft:red_nether_bricks
setblock 356 176 464 minecraft:red_nether_bricks
fill 356 176 465 359 176 465 minecraft:pink_terracotta
fill 357 176 464 360 176 464 minecraft:pink_terracotta
setblock 358 176 466 minecraft:pink_terracotta
setblock 359 176 466 minecraft:red_nether_bricks
fill 359 176 504 360 176 504 minecraft:pink_terracotta
setblock 360 176 465 minecraft:red_nether_bricks
fill 360 176 466 363 176 466 minecraft:pink_terracotta
setblock 361 176 464 minecraft:red_nether_bricks
fill 361 176 465 361 179 465 minecraft:pink_terracotta
setblock 361 176 504 minecraft:red_nether_bricks
fill 362 176 464 362 179 464 minecraft:pink_terracotta
setblock 362 176 467 minecraft:pink_terracotta
setblock 362 176 503 minecraft:red_nether_bricks
fill 362 176 504 362 179 504 minecraft:pink_terracotta
setblock 363 176 467 minecraft:red_nether_bricks
fill 363 176 503 363 179 503 minecraft:pink_terracotta
setblock 364 176 466 minecraft:red_nether_bricks
fill 364 176 467 365 178 467 minecraft:pink_terracotta
setblock 365 176 465 minecraft:red_nether_bricks
fill 365 176 466 365 179 466 minecraft:pink_terracotta
setblock 366 176 464 minecraft:red_nether_bricks
fill 366 176 465 366 179 465 minecraft:pink_terracotta
setblock 366 176 504 minecraft:red_nether_bricks
fill 367 176 464 367 179 464 minecraft:pink_terracotta
setblock 367 176 503 minecraft:red_nether_bricks
fill 367 176 504 367 179 504 minecraft:pink_terracotta
setblock 368 176 467 minecraft:red_nether_bricks
fill 368 176 468 368 178 468 minecraft:pink_terracotta
fill 368 176 489 368 176 491 minecraft:pink_terracotta
setblock 368 176 492 minecraft:red_nether_bricks
fill 368 176 493 368 179 493 minecraft:pink_terracotta
fill 368 176 503 368 179 503 minecraft:pink_terracotta
setblock 369 176 466 minecraft:red_nether_bricks
fill 369 176 467 369 179 467 minecraft:pink_terracotta
setblock 369 176 486 minecraft:red_nether_bricks
fill 369 176 487 369 176 490 minecraft:pink_terracotta
setblock 369 176 491 minecraft:red_nether_bricks
fill 369 176 492 369 179 492 minecraft:pink_terracotta
setblock 369 176 496 minecraft:red_nether_bricks
fill 369 176 497 369 178 498 minecraft:pink_terracotta
setblock 369 176 501 minecraft:red_nether_bricks
fill 369 176 502 369 178 502 minecraft:pink_terracotta
setblock 370 176 465 minecraft:red_nether_bricks
fill 370 176 466 370 179 466 minecraft:pink_terracotta
setblock 370 176 470 minecraft:red_nether_bricks
fill 370 176 471 370 178 472 minecraft:pink_terracotta
setblock 370 176 485 minecraft:red_nether_bricks
fill 370 176 486 370 179 486 minecraft:pink_terracotta
setblock 370 176 490 minecraft:red_nether_bricks
fill 370 176 491 370 179 491 minecraft:pink_terracotta
setblock 370 176 495 minecraft:red_nether_bricks
fill 370 176 496 370 179 496 minecraft:pink_terracotta
setblock 370 176 500 minecraft:red_nether_bricks
fill 370 176 501 370 179 501 minecraft:pink_terracotta
setblock 330 177 465 minecraft:pink_terracotta
setblock 330 177 468 minecraft:pink_terracotta
setblock 330 177 469 minecraft:red_nether_bricks
fill 330 177 470 330 180 470 minecraft:pink_terracotta
fill 330 177 472 330 178 472 minecraft:pink_terracotta
setblock 330 177 478 minecraft:white_concrete
fill 330 177 482 330 177 483 minecraft:pink_terracotta
setblock 330 177 484 minecraft:red_nether_bricks
fill 330 177 485 330 177 488 minecraft:pink_terracotta
setblock 330 177 489 minecraft:red_nether_bricks
fill 330 177 490 330 177 493 minecraft:pink_terracotta
setblock 330 177 494 minecraft:red_nether_bricks
fill 330 177 495 330 177 498 minecraft:pink_terracotta
setblock 330 177 499 minecraft:red_nether_bricks
setblock 330 177 503 minecraft:white_concrete
fill 331 177 485 331 177 487 minecraft:pink_terracotta
setblock 331 177 488 minecraft:red_nether_bricks
fill 331 177 489 331 180 489 minecraft:pink_terracotta
setblock 331 177 493 minecraft:red_nether_bricks
fill 331 177 494 331 179 495 minecraft:pink_terracotta
setblock 332 177 491 minecraft:pink_terracotta
setblock 339 177 464 minecraft:pink_terracotta
setblock 340 177 464 minecraft:red_nether_bricks
fill 340 177 465 343 177 465 minecraft:pink_terracotta
fill 341 177 464 344 177 464 minecraft:pink_terracotta
setblock 342 177 466 minecraft:pink_terracotta
setblock 343 177 466 minecraft:red_nether_bricks
fill 343 177 504 344 177 504 minecraft:pink_terracotta
setblock 344 177 465 minecraft:red_nether_bricks
fill 344 177 466 344 179 467 minecraft:pink_terracotta
setblock 345 177 464 minecraft:red_nether_bricks
fill 345 177 465 348 177 465 minecraft:pink_terracotta
fill 345 177 467 346 177 467 minecraft:pink_terracotta
setblock 345 177 504 minecraft:red_nether_bricks
fill 346 177 464 349 177 464 minecraft:pink_terracotta
fill 346 177 504 346 179 504 minecraft:pink_terracotta
setblock 347 177 467 minecraft:red_nether_bricks
setblock 348 177 466 minecraft:red_nether_bricks
setblock 349 177 465 minecraft:red_nether_bricks
fill 349 177 466 349 179 466 minecraft:pink_terracotta
setblock 350 177 464 minecraft:red_nether_bricks
fill 350 177 465 353 177 465 minecraft:pink_terracotta
fill 351 177 464 354 177 464 minecraft:pink_terracotta
setblock 354 177 465 minecraft:red_nether_bricks
setblock 354 177 504 minecraft:white_concrete
setblock 355 177 464 minecraft:red_nether_bricks
fill 355 177 465 358 177 465 minecraft:pink_terracotta
fill 356 177 464 359 177 464 minecraft:pink_terracotta
setblock 357 177 466 minecraft:pink_terracotta
setblock 358 177 466 minecraft:red_nether_bricks
fill 358 177 504 359 177 504 minecraft:pink_terracotta
setblock 359 177 465 minecraft:red_nether_bricks
fill 359 177 466 362 177 466 minecraft:pink_terracotta
setblock 360 177 464 minecraft:red_nether_bricks
fill 360 177 465 360 180 465 minecraft:pink_terracotta
setblock 360 177 504 minecraft:red_nether_bricks
fill 361 177 464 361 180 464 minecraft:pink_terracotta
setblock 361 177 467 minecraft:pink_terracotta
setblock 361 177 503 minecraft:red_nether_bricks
fill 361 177 504 361 180 504 minecraft:pink_terracotta
setblock 362 177 467 minecraft:red_nether_bricks
fill 362 177 503 362 180 503 minecraft:pink_terracotta
setblock 363 177 466 minecraft:red_nether_bricks
fill 363 177 467 363 180 467 minecraft:pink_terracotta
setblock 364 177 465 minecraft:red_nether_bricks
fill 364 177 466 364 180 466 minecraft:pink_terracotta
setblock 365 177 464 minecraft:red_nether_bricks
fill 365 177 465 365 180 465 minecraft:pink_terracotta
setblock 365 177 504 minecraft:red_nether_bricks
fill 366 177 464 366 180 464 minecraft:pink_terracotta
setblock 366 177 503 minecraft:red_nether_bricks
fill 366 177 504 366 180 504 minecraft:pink_terracotta
fill 367 177 503 367 180 503 minecraft:pink_terracotta
setblock 368 177 466 minecraft:red_nether_bricks
fill 368 177 467 368 178 467 minecraft:pink_terracotta
fill 368 177 489 368 177 490 minecraft:pink_terracotta
setblock 368 177 491 minecraft:red_nether_bricks
fill 368 177 492 368 180 492 minecraft:pink_terracotta
fill 368 177 494 368 177 495 minecraft:pink_terracotta
setblock 369 177 465 minecraft:red_nether_bricks
fill 369 177 466 369 179 466 minecraft:pink_terracotta
setblock 369 177 470 minecraft:red_nether_bricks
fill 369 177 471 369 179 471 minecraft:pink_terracotta
fill 369 177 486 369 177 489 minecraft:pink_terracotta
setblock 369 177 490 minecraft:red_nether_bricks
fill 369 177 491 369 180 491 minecraft:pink_terracotta
setblock 369 177 495 minecraft:red_nether_bricks
fill 369 177 496 369 180 496 minecraft:pink_terracotta
setblock 369 177 499 minecraft:pink_terracotta
setblock 369 177 500 minecraft:red_nether_bricks
fill 369 177 501 369 179 501 minecraft:pink_terracotta
setblock 370 177 464 minecraft:red_nether_bricks
fill 370 177 465 370 180 465 minecraft:pink_terracotta
setblock 370 177 469 minecraft:red_nether_bricks
fill 370 177 470 370 180 470 minecraft:pink_terracotta
setblock 370 177 484 minecraft:white_concrete
fill 370 177 485 370 179 485 minecraft:pink_terracotta
setblock 370 177 489 minecraft:red_nether_bricks
fill 370 177 490 370 180 490 minecraft:pink_terracotta
setblock 370 177 494 minecraft:red_nether_bricks
fill 370 177 495 370 180 495 minecraft:pink_terracotta
setblock 370 177 499 minecraft:red_nether_bricks
fill 370 177 500 370 180 500 minecraft:pink_terracotta
setblock 370 177 504 minecraft:red_nether_bricks
setblock 330 178 465 minecraft:white_concrete
setblock 330 178 468 minecraft:red_nether_bricks
fill 330 178 469 330 181 469 minecraft:pink_terracotta
setblock 330 178 473 minecraft:red_nether_bricks
setblock 330 178 482 minecraft:pink_terracotta
setblock 330 178 483 minecraft:red_nether_bricks
fill 330 178 484 330 178 487 minecraft:pink_terracotta
setblock 330 178 488 minecraft:red_nether_bricks
fill 330 178 489 330 178 492 minecraft:pink_terracotta
setblock 330 178 493 minecraft:red_nether_bricks
fill 330 178 494 330 178 497 minecraft:pink_terracotta
setblock 330 178 498 minecraft:red_nether_bricks
fill 330 178 499 330 181 499 minecraft:pink_terracotta
fill 331 178 485 331 178 486 minecraft:pink_terracotta
setblock 331 178 487 minecraft:red_nether_bricks
fill 331 178 488 331 181 488 minecraft:pink_terracotta
setblock 331 178 492 minecraft:red_nether_bricks
fill 331 178 493 331 181 493 minecraft:pink_terracotta
setblock 331 178 496 minecraft:pink_terracotta
setblock 332 178 491 minecraft:red_nether_bricks
fill 332 178 492 332 180 492 minecraft:pink_terracotta
fill 334 178 481 334 191 481 minecraft:iron_block
setblock 335 178 504 minecraft:white_concrete
setblock 338 178 464 minecraft:pink_terracotta
fill 338 178 496 338 179 496 minecraft:red_concrete
setblock 339 178 464 minecraft:red_nether_bricks
fill 340 178 464 342 178 465 minecraft:pink_terracotta
setblock 341 178 466 minecraft:pink_terracotta
setblock 342 178 466 minecraft:red_nether_bricks
fill 342 178 504 343 178 504 minecraft:pink_terracotta
setblock 343 178 464 minecraft:pink_terracotta
setblock 343 178 465 minecraft:red_nether_bricks
fill 343 178 466 343 180 467 minecraft:pink_terracotta
setblock 344 178 464 minecraft:red_nether_bricks
fill 344 178 465 347 178 465 minecraft:pink_terracotta
setblock 344 178 504 minecraft:red_nether_bricks
fill 345 178 464 348 178 464 minecraft:pink_terracotta
setblock 345 178 467 minecraft:pink_terracotta
fill 345 178 504 345 180 504 minecraft:pink_terracotta
setblock 346 178 467 minecraft:red_nether_bricks
setblock 347 178 466 minecraft:red_nether_bricks
fill 347 178 467 347 179 467 minecraft:pink_terracotta
setblock 348 178 465 minecraft:red_nether_bricks
fill 348 178 466 348 180 466 minecraft:pink_terracotta
setblock 349 178 464 minecraft:red_nether_bricks
fill 349 178 465 352 178 465 minecraft:pink_terracotta
fill 350 178 464 353 178 464 minecraft:pink_terracotta
setblock 353 178 465 minecraft:red_nether_bricks
setblock 354 178 464 minecraft:red_nether_bricks
fill 354 178 465 357 178 465 minecraft:pink_terracotta
fill 355 178 464 358 178 464 minecraft:pink_terracotta
setblock 357 178 466 minecraft:red_nether_bricks
fill 357 178 504 358 178 504 minecraft:pink_terracotta
setblock 358 178 465 minecraft:red_nether_bricks
fill 358 178 466 361 178 466 minecraft:pink_terracotta
setblock 359 178 464 minecraft:red_nether_bricks
fill 359 178 465 359 181 465 minecraft:pink_terracotta
setblock 359 178 504 minecraft:red_nether_bricks
fill 360 178 464 360 181 464 minecraft:pink_terracotta
setblock 360 178 467 minecraft:pink_terracotta
setblock 360 178 503 minecraft:red_nether_bricks
fill 360 178 504 360 181 504 minecraft:pink_terracotta
setblock 361 178 467 minecraft:red_nether_bricks
fill 361 178 503 361 181 503 minecraft:pink_terracotta
setblock 362 178 466 minecraft:red_nether_bricks
fill 362 178 467 362 180 467 minecraft:pink_terracotta
setblock 363 178 465 minecraft:red_nether_bricks
fill 363 178 466 363 181 466 minecraft:pink_terracotta
setblock 364 178 464 minecraft:red_nether_bricks
fill 364 178 465 364 181 465 minecraft:pink_terracotta
fill 364 178 502 365 178 502 minecraft:pink_terracotta
setblock 364 178 504 minecraft:red_nether_bricks
fill 365 178 464 365 181 464 minecraft:pink_terracotta
setblock 365 178 503 minecraft:red_nether_bricks
fill 365 178 504 365 181 504 minecraft:pink_terracotta
fill 366 178 503 366 181 503 minecraft:pink_terracotta
setblock 367 178 466 minecraft:red_nether_bricks
setblock 368 178 465 minecraft:red_nether_bricks
setblock 368 178 489 minecraft:pink_terracotta
setblock 368 178 490 minecraft:red_nether_bricks
fill 368 178 491 368 181 491 minecraft:pink_terracotta
setblock 368 178 494 minecraft:pink_terracotta
setblock 368 178 495 minecraft:red_nether_bricks
fill 368 178 496 368 181 496 minecraft:pink_terracotta
setblock 369 178 464 minecraft:red_nether_bricks
setblock 369 178 465 minecraft:pink_terracotta
setblock 369 178 469 minecraft:red_nether_bricks
fill 369 178 470 369 180 470 minecraft:pink_terracotta
fill 369 178 487 369 178 488 minecraft:pink_terracotta
setblock 369 178 489 minecraft:red_nether_bricks
fill 369 178 490 369 181 490 minecraft:pink_terracotta
setblock 369 178 494 minecraft:red_nether_bricks
fill 369 178 495 369 181 495 minecraft:pink_terracotta
setblock 369 178 499 minecraft:red_nether_bricks
fill 369 178 500 369 181 500 minecraft:pink_terracotta
setblock 369 178 504 minecraft:red_nether_bricks
fill 370 178 464 370 179 464 minecraft:pink_terracotta
setblock 370 178 468 minecraft:red_nether_bricks
fill 370 178 469 370 181 469 minecraft:pink_terracotta
setblock 370 178 473 minecraft:red_nether_bricks
setblock 370 178 478 minecraft:white_concrete
setblock 370 178 488 minecraft:red_nether_bricks
fill 370 178 489 370 181 489 minecraft:pink_terracotta
setblock 370 178 493 minecraft:red_nether_bricks
fill 370 178 494 370 181 494 minecraft:pink_terracotta
setblock 370 178 498 minecraft:red_nether_bricks
fill 370 178 499 370 181 499 minecraft:pink_terracotta
setblock 370 178 503 minecraft:red_nether_bricks
fill 370 178 504 370 180 504 minecraft:pink_terracotta
setblock 330 179 467 minecraft:red_nether_bricks
fill 330 179 468 330 180 468 minecraft:pink_terracotta
setblock 330 179 472 minecraft:red_nether_bricks
fill 330 179 473 330 180 475 minecraft:pink_terracotta
fill 330 179 483 330 179 486 minecraft:pink_terracotta
setblock 330 179 487 minecraft:red_nether_bricks
fill 330 179 488 330 179 491 minecraft:pink_terracotta
setblock 330 179 492 minecraft:red_nether_bricks
fill 330 179 493 330 179 496 minecraft:pink_terracotta
setblock 330 179 497 minecraft:red_nether_bricks
fill 330 179 498 330 182 498 minecraft:pink_terracotta
setblock 331 179 486 minecraft:red_nether_bricks
fill 331 179 487 331 180 487 minecraft:pink_terracotta
setblock 331 179 490 minecraft:pink_terracotta
setblock 331 179 491 minecraft:red_nether_bricks
fill 331 179 492 331 182 492 minecraft:pink_terracotta
setblock 331 179 496 minecraft:red_nether_bricks
setblock 332 179 490 minecraft:red_nether_bricks
fill 332 179 491 332 180 491 minecraft:pink_terracotta
setblock 334 179 464 minecraft:white_concrete
setblock 338 179 464 minecraft:red_nether_bricks
fill 339 179 464 341 179 465 minecraft:pink_terracotta
setblock 341 179 466 minecraft:red_nether_bricks
setblock 341 179 504 minecraft:white_concrete
setblock 342 179 464 minecraft:pink_terracotta
setblock 342 179 465 minecraft:red_nether_bricks
fill 342 179 466 342 180 467 minecraft:pink_terracotta
setblock 342 179 504 minecraft:pink_terracotta
setblock 343 179 464 minecraft:red_nether_bricks
fill 343 179 465 346 179 465 minecraft:pink_terracotta
setblock 343 179 504 minecraft:red_nether_bricks
fill 344 179 464 347 179 464 minecraft:pink_terracotta
fill 344 179 504 344 180 504 minecraft:pink_terracotta
setblock 345 179 467 minecraft:red_nether_bricks
setblock 346 179 466 minecraft:red_nether_bricks
fill 346 179 467 346 180 467 minecraft:pink_terracotta
setblock 347 179 465 minecraft:red_nether_bricks
fill 347 179 466 347 180 466 minecraft:pink_terracotta
setblock 348 179 464 minecraft:red_nether_bricks
fill 348 179 465 351 179 465 minecraft:pink_terracotta
fill 349 179 464 352 179 464 minecraft:pink_terracotta
setblock 352 179 465 minecraft:red_nether_bricks
setblock 353 179 464 minecraft:red_nether_bricks
fill 353 179 465 356 179 465 minecraft:pink_terracotta
fill 354 179 464 357 179 464 minecraft:pink_terracotta
setblock 356 179 466 minecraft:red_nether_bricks
setblock 357 179 465 minecraft:red_nether_bricks
fill 357 179 466 360 179 466 minecraft:pink_terracotta
setblock 357 179 504 minecraft:pink_terracotta
setblock 358 179 464 minecraft:red_nether_bricks
fill 358 179 465 358 182 465 minecraft:pink_terracotta
setblock 358 179 504 minecraft:red_nether_bricks
fill 359 179 464 359 182 464 minecraft:pink_terracotta
fill 359 179 504 359 182 504 minecraft:pink_terracotta
setblock 360 179 467 minecraft:red_nether_bricks
fill 360 179 503 360 182 503 minecraft:pink_terracotta
setblock 361 179 466 minecraft:red_nether_bricks
fill 361 179 467 361 180 467 minecraft:pink_terracotta
setblock 362 179 465 minecraft:red_nether_bricks
fill 362 179 466 362 182 466 minecraft:pink_terracotta
setblock 363 179 464 minecraft:red_nether_bricks
fill 363 179 465 363 182 465 minecraft:pink_terracotta
fill 363 179 502 364 179 502 minecraft:pink_terracotta
setblock 363 179 504 minecraft:red_nether_bricks
fill 364 179 464 364 182 464 minecraft:pink_terracotta
setblock 364 179 467 minecraft:pink_terracotta
setblock 364 179 503 minecraft:red_nether_bricks
fill 364 179 504 364 182 504 minecraft:pink_terracotta
setblock 365 179 502 minecraft:red_nether_bricks
fill 365 179 503 365 182 503 minecraft:pink_terracotta
setblock 366 179 466 minecraft:red_nether_bricks
setblock 367 179 465 minecraft:red_nether_bricks
setblock 367 179 466 minecraft:pink_terracotta
fill 367 179 492 367 179 493 minecraft:pink_terracotta
setblock 368 179 464 minecraft:red_nether_bricks
setblock 368 179 465 minecraft:pink_terracotta
setblock 368 179 489 minecraft:red_nether_bricks
fill 368 179 490 368 181 490 minecraft:pink_terracotta
setblock 368 179 494 minecraft:red_nether_bricks
fill 368 179 495 368 182 495 minecraft:pink_terracotta
fill 368 179 497 369 179 497 minecraft:pink_terracotta
setblock 368 179 504 minecraft:red_nether_bricks
fill 369 179 464 369 180 464 minecraft:pink_terracotta
setblock 369 179 468 minecraft:red_nether_bricks
fill 369 179 469 369 180 469 minecraft:pink_terracotta
setblock 369 179 487 minecraft:pink_terracotta
setblock 369 179 488 minecraft:red_nether_bricks
fill 369 179 489 369 181 489 minecraft:pink_terracotta
setblock 369 179 493 minecraft:red_nether_bricks
fill 369 179 494 369 182 494 minecraft:pink_terracotta
setblock 369 179 498 minecraft:red_nether_bricks
fill 369 179 499 369 182 499 minecraft:pink_terracotta
fill 369 179 504 369 181 504 minecraft:pink_terracotta
setblock 370 179 467 minecraft:red_nether_bricks
fill 370 179 468 370 181 468 minecraft:pink_terracotta
setblock 370 179 471 minecraft:pink_terracotta
setblock 370 179 472 minecraft:red_nether_bricks
fill 370 179 473 370 181 473 minecraft:pink_terracotta
setblock 370 179 487 minecraft:red_nether_bricks
fill 370 179 488 370 182 488 minecraft:pink_terracotta
setblock 370 179 492 minecraft:red_nether_bricks
fill 370 179 493 370 182 493 minecraft:pink_terracotta
setblock 370 179 497 minecraft:red_nether_bricks
fill 370 179 498 370 182 498 minecraft:pink_terracotta
setblock 370 179 502 minecraft:red_nether_bricks
fill 370 179 503 370 181 503 minecraft:pink_terracotta
setblock 330 180 471 minecraft:red_nether_bricks
fill 330 180 472 330 183 472 minecraft:pink_terracotta
setblock 330 180 476 minecraft:red_nether_bricks
setblock 330 180 477 minecraft:white_concrete
fill 330 180 483 330 180 485 minecraft:pink_terracotta
setblock 330 180 486 minecraft:red_nether_bricks
fill 330 180 487 330 180 490 minecraft:pink_terracotta
setblock 330 180 491 minecraft:red_nether_bricks
fill 330 180 492 330 180 495 minecraft:pink_terracotta
setblock 330 180 496 minecraft:red_nether_bricks
fill 330 180 497 330 183 497 minecraft:pink_terracotta
setblock 330 180 502 minecraft:white_concrete
setblock 331 180 490 minecraft:red_nether_bricks
fill 331 180 491 331 183 491 minecraft:pink_terracotta
setblock 331 180 494 minecraft:pink_terracotta
setblock 331 180 495 minecraft:red_nether_bricks
fill 331 180 496 331 182 496 minecraft:pink_terracotta
setblock 332 180 490 minecraft:pink_terracotta
fill 338 180 464 341 180 464 minecraft:pink_terracotta
fill 339 180 465 340 180 465 minecraft:pink_terracotta
setblock 341 180 465 minecraft:red_nether_bricks
fill 341 180 466 341 181 466 minecraft:pink_terracotta
fill 341 180 481 341 222 482 minecraft:red_nether_bricks
setblock 342 180 464 minecraft:red_nether_bricks
fill 342 180 465 345 180 465 minecraft:pink_terracotta
fill 342 180 481 342 222 481 minecraft:red_nether_bricks
setblock 342 180 504 minecraft:red_nether_bricks
fill 343 180 464 346 180 464 minecraft:pink_terracotta
fill 343 180 504 343 181 504 minecraft:pink_terracotta
setblock 344 180 466 minecraft:pink_terracotta
setblock 344 180 467 minecraft:red_nether_bricks
setblock 345 180 466 minecraft:red_nether_bricks
setblock 345 180 467 minecraft:pink_terracotta
setblock 346 180 465 minecraft:red_nether_bricks
fill 346 180 466 346 181 466 minecraft:pink_terracotta
setblock 347 180 464 minecraft:red_nether_bricks
fill 347 180 465 350 180 465 minecraft:pink_terracotta
setblock 347 180 504 minecraft:white_concrete
fill 348 180 464 351 180 464 minecraft:pink_terracotta
setblock 351 180 465 minecraft:red_nether_bricks
setblock 352 180 464 minecraft:red_nether_bricks
fill 352 180 465 355 180 465 minecraft:pink_terracotta
fill 353 180 464 356 180 464 minecraft:pink_terracotta
setblock 356 180 465 minecraft:red_nether_bricks
setblock 356 180 504 minecraft:pink_terracotta
setblock 357 180 464 minecraft:red_nether_bricks
fill 357 180 465 357 181 466 minecraft:pink_terracotta
setblock 357 180 504 minecraft:red_nether_bricks
fill 358 180 464 358 183 464 minecraft:pink_terracotta
fill 358 180 466 359 180 466 minecraft:pink_terracotta
fill 358 180 504 358 183 504 minecraft:pink_terracotta
fill 359 180 503 359 183 503 minecraft:pink_terracotta
setblock 360 180 466 minecraft:red_nether_bricks
setblock 360 180 467 minecraft:pink_terracotta
setblock 361 180 465 minecraft:red_nether_bricks
fill 361 180 466 361 182 466 minecraft:pink_terracotta
setblock 362 180 464 minecraft:red_nether_bricks
fill 362 180 465 362 183 465 minecraft:pink_terracotta
fill 362 180 502 363 180 502 minecraft:pink_terracotta
setblock 362 180 504 minecraft:red_nether_bricks
fill 363 180 464 363 183 464 minecraft:pink_terracotta
setblock 363 180 503 minecraft:red_nether_bricks
fill 363 180 504 363 183 504 minecraft:pink_terracotta
setblock 364 180 502 minecraft:red_nether_bricks
fill 364 180 503 364 183 503 minecraft:pink_terracotta
setblock 365 180 466 minecraft:red_nether_bricks
setblock 365 180 502 minecraft:pink_terracotta
setblock 366 180 465 minecraft:red_nether_bricks
setblock 366 180 466 minecraft:pink_terracotta
setblock 367 180 464 minecraft:red_nether_bricks
setblock 367 180 465 minecraft:pink_terracotta
setblock 367 180 493 minecraft:pink_terracotta
setblock 367 180 494 minecraft:red_nether_bricks
setblock 367 180 504 minecraft:red_nether_bricks
fill 368 180 464 368 181 464 minecraft:pink_terracotta
setblock 368 180 493 minecraft:red_nether_bricks
fill 368 180 494 368 183 494 minecraft:pink_terracotta
setblock 368 180 497 minecraft:pink_terracotta
setblock 368 180 498 minecraft:red_nether_bricks
setblock 368 180 503 minecraft:red_nether_bricks
fill 368 180 504 368 182 504 minecraft:pink_terracotta
setblock 369 180 488 minecraft:pink_terracotta
setblock 369 180 492 minecraft:red_nether_bricks
fill 369 180 493 369 183 493 minecraft:pink_terracotta
setblock 369 180 497 minecraft:red_nether_bricks
fill 369 180 498 369 183 498 minecraft:pink_terracotta
setblock 370 180 466 minecraft:red_nether_bricks
setblock 370 180 467 minecraft:pink_terracotta
setblock 370 180 471 minecraft:red_nether_bricks
fill 370 180 472 370 181 472 minecraft:pink_terracotta
setblock 370 180 486 minecraft:red_nether_bricks
fill 370 180 487 370 181 487 minecraft:pink_terracotta
setblock 370 180 491 minecraft:red_nether_bricks
fill 370 180 492 370 183 492 minecraft:pink_terracotta
setblock 370 180 496 minecraft:red_nether_bricks
fill 370 180 497 370 183 497 minecraft:pink_terracotta
setblock 370 180 501 minecraft:red_nether_bricks
fill 370 180 502 370 181 502 minecraft:pink_terracotta
setblock 330 181 464 minecraft:white_concrete
setblock 330 181 470 minecraft:red_nether_bricks
fill 330 181 471 330 182 471 minecraft:pink_terracotta
fill 330 181 473 330 181 474 minecraft:pink_terracotta
setblock 330 181 475 minecraft:red_nether_bricks
fill 330 181 476 330 183 477 minecraft:pink_terracotta
setblock 330 181 483 minecraft:white_concrete
setblock 330 181 484 minecraft:pink_terracotta
setblock 330 181 485 minecraft:red_nether_bricks
fill 330 181 486 330 181 489 minecraft:pink_terracotta
setblock 330 181 490 minecraft:red_nether_bricks
fill 330 181 491 330 181 494 minecraft:pink_terracotta
setblock 330 181 495 minecraft:red_nether_bricks
fill 330 181 496 330 184 496 minecraft:pink_terracotta
setblock 331 181 489 minecraft:red_nether_bricks
fill 331 181 490 331 182 490 minecraft:pink_terracotta
setblock 331 181 494 minecraft:red_nether_bricks
fill 331 181 495 331 183 495 minecraft:pink_terracotta
fill 332 181 492 332 222 493 minecraft:red_nether_bricks
fill 333 181 492 333 222 492 minecraft:red_nether_bricks
setblock 334 181 504 minecraft:white_concrete
fill 338 181 464 340 181 464 minecraft:pink_terracotta
setblock 339 181 465 minecraft:pink_terracotta
setblock 340 181 465 minecraft:red_nether_bricks
fill 340 181 481 340 182 482 minecraft:red_terracotta
setblock 341 181 464 minecraft:red_nether_bricks
fill 341 181 465 344 181 465 minecraft:pink_terracotta
fill 341 181 480 342 182 480 minecraft:red_terracotta
fill 342 181 464 345 181 464 minecraft:pink_terracotta
fill 342 181 466 343 181 466 minecraft:pink_terracotta
fill 342 181 482 342 182 482 minecraft:red_terracotta
setblock 342 181 504 minecraft:pink_terracotta
setblock 344 181 466 minecraft:red_nether_bricks
setblock 345 181 465 minecraft:red_nether_bricks
setblock 345 181 466 minecraft:pink_terracotta
setblock 346 181 464 minecraft:red_nether_bricks
fill 346 181 465 349 181 465 minecraft:pink_terracotta
fill 347 181 464 350 181 464 minecraft:pink_terracotta
setblock 351 181 464 minecraft:red_nether_bricks
fill 352 181 464 355 181 464 minecraft:pink_terracotta
setblock 353 181 504 minecraft:white_concrete
setblock 354 181 465 minecraft:pink_terracotta
setblock 355 181 465 minecraft:red_nether_bricks
setblock 356 181 464 minecraft:red_nether_bricks
fill 356 181 465 356 182 465 minecraft:pink_terracotta
setblock 356 181 504 minecraft:red_nether_bricks
fill 357 181 464 357 184 464 minecraft:pink_terracotta
fill 357 181 504 357 184 504 minecraft:pink_terracotta
setblock 358 181 466 minecraft:pink_terracotta
setblock 359 181 466 minecraft:red_nether_bricks
setblock 360 181 465 minecraft:red_nether_bricks
fill 360 181 466 360 182 466 minecraft:pink_terracotta
setblock 361 181 464 minecraft:red_nether_bricks
fill 361 181 465 361 184 465 minecraft:pink_terracotta
fill 361 181 502 362 181 502 minecraft:pink_terracotta
setblock 361 181 504 minecraft:red_nether_bricks
fill 362 181 464 362 184 464 minecraft:pink_terracotta
setblock 362 181 503 minecraft:red_nether_bricks
fill 362 181 504 362 184 504 minecraft:pink_terracotta
setblock 363 181 502 minecraft:red_nether_bricks
fill 363 181 503 363 184 503 minecraft:pink_terracotta
setblock 364 181 466 minecraft:red_nether_bricks
setblock 364 181 502 minecraft:pink_terracotta
setblock 365 181 465 minecraft:red_nether_bricks
setblock 366 181 464 minecraft:red_nether_bricks
setblock 366 181 465 minecraft:pink_terracotta
setblock 366 181 504 minecraft:red_nether_bricks
fill 367 181 464 367 182 464 minecraft:pink_terracotta
setblock 367 181 503 minecraft:red_nether_bricks
fill 367 181 504 367 183 504 minecraft:pink_terracotta
setblock 368 181 492 minecraft:red_nether_bricks
fill 368 181 493 368 183 493 minecraft:pink_terracotta
setblock 368 181 497 minecraft:red_nether_bricks
setblock 368 181 498 minecraft:pink_terracotta
setblock 369 181 491 minecraft:red_nether_bricks
fill 369 181 492 369 184 492 minecraft:pink_terracotta
setblock 369 181 496 minecraft:red_nether_bricks
fill 369 181 497 369 184 497 minecraft:pink_terracotta
setblock 370 181 470 minecraft:red_nether_bricks
setblock 370 181 471 minecraft:pink_terracotta
setblock 370 181 485 minecraft:white_concrete
setblock 370 181 490 minecraft:red_nether_bricks
fill 370 181 491 370 184 491 minecraft:pink_terracotta
setblock 370 181 495 minecraft:red_nether_bricks
fill 370 181 496 370 184 496 minecraft:pink_terracotta
setblock 370 181 500 minecraft:red_nether_bricks
fill 370 181 501 370 183 501 minecraft:pink_terracotta
setblock 330 182 470 minecraft:pink_terracotta
setblock 330 182 473 minecraft:pink_terracotta
setblock 330 182 474 minecraft:red_nether_bricks
fill 330 182 475 330 185 475 minecraft:pink_terracotta
fill 330 182 485 330 182 488 minecraft:pink_terracotta
setblock 330 182 489 minecraft:red_nether_bricks
fill 330 182 490 330 182 493 minecraft:pink_terracotta
setblock 330 182 494 minecraft:red_nether_bricks
fill 330 182 495 330 185 495 minecraft:pink_terracotta
setblock 330 182 499 minecraft:red_nether_bricks
setblock 331 182 489 minecraft:pink_terracotta
setblock 331 182 493 minecraft:red_nether_bricks
fill 331 182 494 331 183 494 minecraft:pink_terracotta
fill 332 182 491 333 183 491 minecraft:red_terracotta
fill 333 182 493 333 183 493 minecraft:red_terracotta
fill 338 182 464 339 182 464 minecraft:pink_terracotta
setblock 340 182 464 minecraft:red_nether_bricks
fill 340 182 465 343 182 465 minecraft:pink_terracotta
setblock 340 182 480 minecraft:red_terracotta
setblock 340 182 504 minecraft:white_concrete
fill 341 182 464 344 182 464 minecraft:pink_terracotta
fill 341 182 483 342 182 483 minecraft:red_terracotta
setblock 342 182 466 minecraft:pink_terracotta
setblock 343 182 466 minecraft:red_nether_bricks
setblock 343 182 481 minecraft:red_terracotta
setblock 344 182 465 minecraft:red_nether_bricks
setblock 344 182 466 minecraft:pink_terracotta
setblock 345 182 464 minecraft:red_nether_bricks
fill 345 182 465 347 182 465 minecraft:pink_terracotta
fill 346 182 464 349 182 464 minecraft:pink_terracotta
setblock 350 182 464 minecraft:red_nether_bricks
fill 351 182 464 354 182 464 minecraft:pink_terracotta
setblock 355 182 464 minecraft:red_nether_bricks
fill 356 182 464 356 185 464 minecraft:pink_terracotta
fill 356 182 504 356 185 504 minecraft:pink_terracotta
fill 357 182 465 357 183 465 minecraft:pink_terracotta
setblock 358 182 466 minecraft:red_nether_bricks
fill 358 182 503 358 184 503 minecraft:pink_terracotta
setblock 359 182 465 minecraft:red_nether_bricks
setblock 359 182 466 minecraft:pink_terracotta
setblock 360 182 464 minecraft:red_nether_bricks
fill 360 182 465 360 184 465 minecraft:pink_terracotta
setblock 360 182 504 minecraft:red_nether_bricks
fill 361 182 464 361 185 464 minecraft:pink_terracotta
setblock 361 182 502 minecraft:pink_terracotta
setblock 361 182 503 minecraft:red_nether_bricks
fill 361 182 504 361 185 504 minecraft:pink_terracotta
setblock 362 182 502 minecraft:red_nether_bricks
fill 362 182 503 362 185 503 minecraft:pink_terracotta
setblock 363 182 466 minecraft:red_nether_bricks
fill 363 182 502 363 183 502 minecraft:pink_terracotta
setblock 364 182 465 minecraft:red_nether_bricks
setblock 365 182 464 minecraft:red_nether_bricks
setblock 365 182 465 minecraft:pink_terracotta
setblock 365 182 504 minecraft:red_nether_bricks
setblock 366 182 464 minecraft:pink_terracotta
setblock 366 182 503 minecraft:red_nether_bricks
fill 366 182 504 366 184 504 minecraft:pink_terracotta
setblock 368 182 492 minecraft:pink_terracotta
setblock 368 182 496 minecraft:red_nether_bricks
setblock 368 182 497 minecraft:pink_terracotta
setblock 369 182 490 minecraft:red_nether_bricks
fill 369 182 491 369 183 491 minecraft:pink_terracotta
setblock 369 182 495 minecraft:red_nether_bricks
fill 369 182 496 369 185 496 minecraft:pink_terracotta
setblock 370 182 479 minecraft:white_concrete
setblock 370 182 489 minecraft:red_nether_bricks
fill 370 182 490 370 184 490 minecraft:pink_terracotta
setblock 370 182 494 minecraft:red_nether_bricks
fill 370 182 495 370 185 495 minecraft:pink_terracotta
setblock 370 182 499 minecraft:red_nether_bricks
fill 370 182 500 370 185 500 minecraft:pink_terracotta
fill 330 183 471 330 186 471 minecraft:white_concrete
setblock 330 183 473 minecraft:red_nether_bricks
fill 330 183 474 330 186 474 minecraft:pink_terracotta
setblock 330 183 487 minecraft:pink_terracotta
setblock 330 183 488 minecraft:red_nether_bricks
fill 330 183 489 330 183 492 minecraft:pink_terracotta
setblock 330 183 493 minecraft:red_nether_bricks
fill 330 183 494 330 186 494 minecraft:pink_terracotta
setblock 330 183 498 minecraft:red_nether_bricks
fill 331 183 472 331 186 474 minecraft:white_concrete
fill 331 183 492 331 204 492 minecraft:red_nether_bricks
setblock 331 183 493 minecraft:pink_terracotta
setblock 332 183 466 minecraft:light[level=12]
fill 332 183 473 332 186 473 minecraft:white_concrete
setblock 332 183 474 minecraft:light[level=12]
setblock 332 183 482 minecraft:light[level=12]
setblock 332 183 490 minecraft:light[level=12]
setblock 332 183 494 minecraft:red_terracotta
setblock 332 183 498 minecraft:light[level=12]
setblock 335 183 464 minecraft:white_concrete
setblock 339 183 464 minecraft:red_nether_bricks
fill 340 183 464 342 183 465 minecraft:pink_terracotta
setblock 340 183 466 minecraft:light[level=12]
setblock 340 183 474 minecraft:light[level=12]
setblock 340 183 482 minecraft:light[level=12]
setblock 340 183 490 minecraft:light[level=12]
setblock 340 183 498 minecraft:light[level=12]
setblock 343 183 464 minecraft:pink_terracotta
setblock 343 183 465 minecraft:red_nether_bricks
setblock 344 183 464 minecraft:red_nether_bricks
setblock 344 183 465 minecraft:pink_terracotta
fill 345 183 464 347 183 464 minecraft:pink_terracotta
setblock 346 183 504 minecraft:white_concrete
setblock 348 183 466 minecraft:light[level=12]
setblock 348 183 474 minecraft:light[level=12]
setblock 348 183 482 minecraft:light[level=12]
setblock 348 183 490 minecraft:light[level=12]
setblock 348 183 498 minecraft:light[level=12]
setblock 354 183 464 minecraft:red_nether_bricks
fill 355 183 464 355 186 464 minecraft:pink_terracotta
setblock 356 183 466 minecraft:light[level=12]
setblock 356 183 474 minecraft:light[level=12]
setblock 356 183 482 minecraft:light[level=12]
setblock 356 183 490 minecraft:light[level=12]
setblock 356 183 498 minecraft:light[level=12]
setblock 358 183 465 minecraft:red_nether_bricks
setblock 359 183 464 minecraft:red_nether_bricks
fill 359 183 465 359 184 465 minecraft:pink_terracotta
setblock 359 183 504 minecraft:red_nether_bricks
fill 360 183 464 360 186 464 minecraft:pink_terracotta
setblock 360 183 503 minecraft:red_nether_bricks
fill 360 183 504 360 186 504 minecraft:pink_terracotta
setblock 361 183 502 minecraft:red_nether_bricks
fill 361 183 503 361 186 503 minecraft:pink_terracotta
fill 362 183 502 362 184 502 minecraft:pink_terracotta
setblock 363 183 465 minecraft:red_nether_bricks
setblock 364 183 464 minecraft:red_nether_bricks
setblock 364 183 466 minecraft:light[level=12]
setblock 364 183 474 minecraft:light[level=12]
setblock 364 183 482 minecraft:light[level=12]
setblock 364 183 490 minecraft:light[level=12]
setblock 364 183 498 minecraft:light[level=12]
setblock 364 183 504 minecraft:red_nether_bricks
setblock 365 183 464 minecraft:pink_terracotta
setblock 365 183 503 minecraft:red_nether_bricks
fill 365 183 504 365 186 504 minecraft:pink_terracotta
setblock 368 183 495 minecraft:red_nether_bricks
setblock 368 183 496 minecraft:pink_terracotta
setblock 369 183 494 minecraft:red_nether_bricks
fill 369 183 495 369 186 495 minecraft:pink_terracotta
setblock 369 183 499 minecraft:red_nether_bricks
setblock 370 183 473 minecraft:white_concrete
setblock 370 183 489 minecraft:pink_terracotta
setblock 370 183 493 minecraft:red_nether_bricks
fill 370 183 494 370 186 494 minecraft:pink_terracotta
setblock 370 183 498 minecraft:red_nether_bricks
fill 370 183 499 370 186 499 minecraft:pink_terracotta
fill 330 184 472 330 186 472 minecraft:white_concrete
fill 330 184 473 330 185 473 minecraft:pink_terracotta
setblock 330 184 476 minecraft:pink_terracotta
setblock 330 184 477 minecraft:red_nether_bricks
fill 330 184 478 330 187 478 minecraft:pink_terracotta
setblock 330 184 482 minecraft:white_concrete
fill 330 184 489 330 184 491 minecraft:pink_terracotta
setblock 330 184 492 minecraft:red_nether_bricks
fill 330 184 493 330 186 493 minecraft:pink_terracotta
setblock 330 184 497 minecraft:red_nether_bricks
fill 330 184 498 330 185 498 minecraft:pink_terracotta
setblock 330 184 501 minecraft:white_concrete
fill 331 184 471 331 185 471 minecraft:white_concrete
fill 331 184 475 331 185 475 minecraft:white_concrete
fill 332 184 472 332 185 472 minecraft:white_concrete
fill 332 184 474 332 185 474 minecraft:white_concrete
fill 333 184 473 333 185 473 minecraft:red_concrete
fill 334 184 475 335 222 476 minecraft:red_nether_bricks
fill 339 184 464 342 184 464 minecraft:pink_terracotta
setblock 343 184 464 minecraft:red_nether_bricks
fill 344 184 464 345 184 464 minecraft:pink_terracotta
setblock 348 184 464 minecraft:white_concrete
setblock 352 184 504 minecraft:white_concrete
setblock 354 184 464 minecraft:pink_terracotta
fill 355 184 504 355 186 504 minecraft:pink_terracotta
setblock 358 184 464 minecraft:red_nether_bricks
setblock 358 184 465 minecraft:pink_terracotta
setblock 358 184 504 minecraft:red_nether_bricks
fill 359 184 464 359 187 464 minecraft:pink_terracotta
setblock 359 184 503 minecraft:red_nether_bricks
fill 359 184 504 359 187 504 minecraft:pink_terracotta
setblock 360 184 502 minecraft:red_nether_bricks
fill 360 184 503 360 187 503 minecraft:pink_terracotta
fill 361 184 502 361 187 502 minecraft:pink_terracotta
setblock 363 184 464 minecraft:red_nether_bricks
setblock 363 184 504 minecraft:red_nether_bricks
setblock 364 184 464 minecraft:pink_terracotta
setblock 364 184 503 minecraft:red_nether_bricks
fill 364 184 504 364 187 504 minecraft:pink_terracotta
fill 367 184 464 367 185 464 minecraft:white_concrete
setblock 369 184 493 minecraft:red_nether_bricks
fill 369 184 494 369 185 494 minecraft:pink_terracotta
setblock 369 184 498 minecraft:red_nether_bricks
setblock 370 184 467 minecraft:white_concrete
setblock 370 184 486 minecraft:white_concrete
setblock 370 184 492 minecraft:red_nether_bricks
fill 370 184 493 370 187 493 minecraft:pink_terracotta
setblock 370 184 497 minecraft:red_nether_bricks
fill 370 184 498 370 187 498 minecraft:pink_terracotta
setblock 330 185 476 minecraft:red_nether_bricks
fill 330 185 477 330 188 477 minecraft:pink_terracotta
setblock 330 185 488 minecraft:white_concrete
setblock 330 185 490 minecraft:pink_terracotta
setblock 330 185 491 minecraft:red_nether_bricks
fill 330 185 492 330 186 492 minecraft:pink_terracotta
setblock 330 185 496 minecraft:red_nether_bricks
fill 330 185 497 330 188 497 minecraft:pink_terracotta
fill 333 185 475 333 186 476 minecraft:red_terracotta
setblock 333 185 504 minecraft:white_concrete
fill 339 185 464 341 185 464 minecraft:pink_terracotta
setblock 342 185 464 minecraft:red_nether_bricks
fill 343 185 464 344 185 464 minecraft:pink_terracotta
setblock 357 185 464 minecraft:red_nether_bricks
setblock 357 185 503 minecraft:pink_terracotta
setblock 357 185 504 minecraft:red_nether_bricks
fill 358 185 464 358 188 464 minecraft:pink_terracotta
setblock 358 185 503 minecraft:red_nether_bricks
fill 358 185 504 358 188 504 minecraft:pink_terracotta
fill 359 185 503 359 188 503 minecraft:pink_terracotta
fill 360 185 502 360 188 502 minecraft:pink_terracotta
setblock 362 185 464 minecraft:red_nether_bricks
setblock 362 185 504 minecraft:red_nether_bricks
setblock 363 185 464 minecraft:pink_terracotta
setblock 363 185 503 minecraft:red_nether_bricks
fill 363 185 504 363 188 504 minecraft:pink_terracotta
setblock 364 185 503 minecraft:pink_terracotta
setblock 369 185 493 minecraft:pink_terracotta
setblock 369 185 497 minecraft:red_nether_bricks
fill 369 185 498 369 186 498 minecraft:pink_terracotta
setblock 370 185 480 minecraft:white_concrete
setblock 370 185 491 minecraft:red_nether_bricks
fill 370 185 492 370 188 492 minecraft:pink_terracotta
setblock 370 185 496 minecraft:red_nether_bricks
fill 370 185 497 370 188 497 minecraft:pink_terracotta
setblock 330 186 469 minecraft:white_concrete
fill 330 186 473 330 187 473 minecraft:white_concrete
setblock 330 186 475 minecraft:red_nether_bricks
fill 330 186 476 330 189 476 minecraft:pink_terracotta
setblock 330 186 479 minecraft:pink_terracotta
setblock 330 186 495 minecraft:red_nether_bricks
fill 330 186 496 330 189 496 minecraft:pink_terracotta
fill 334 186 474 335 186 474 minecraft:red_terracotta
fill 334 186 477 335 186 477 minecraft:red_terracotta
setblock 336 186 464 minecraft:white_concrete
fill 336 186 475 336 186 476 minecraft:red_terracotta
fill 339 186 464 340 186 464 minecraft:pink_terracotta
setblock 339 186 504 minecraft:white_concrete
setblock 341 186 464 minecraft:red_nether_bricks
fill 342 186 464 342 189 464 minecraft:pink_terracotta
fill 345 186 504 345 187 504 minecraft:white_concrete
fill 354 186 504 354 187 504 minecraft:pink_terracotta
setblock 356 186 464 minecraft:red_nether_bricks
setblock 356 186 503 minecraft:pink_terracotta
setblock 356 186 504 minecraft:red_nether_bricks
fill 357 186 464 357 189 464 minecraft:pink_terracotta
setblock 357 186 503 minecraft:red_nether_bricks
fill 357 186 504 357 189 504 minecraft:pink_terracotta
fill 358 186 503 358 189 503 minecraft:pink_terracotta
fill 359 186 502 359 189 502 minecraft:pink_terracotta
setblock 361 186 464 minecraft:red_nether_bricks
setblock 361 186 504 minecraft:red_nether_bricks
setblock 362 186 464 minecraft:pink_terracotta
setblock 362 186 503 minecraft:red_nether_bricks
fill 362 186 504 362 189 504 minecraft:pink_terracotta
fill 363 186 503 363 189 503 minecraft:pink_terracotta
setblock 369 186 496 minecraft:red_nether_bricks
fill 369 186 497 369 189 497 minecraft:pink_terracotta
setblock 370 186 474 minecraft:white_concrete
setblock 370 186 491 minecraft:pink_terracotta
setblock 370 186 495 minecraft:red_nether_bricks
fill 370 186 496 370 189 496 minecraft:pink_terracotta
setblock 370 186 500 minecraft:red_nether_bricks
setblock 330 187 474 minecraft:red_nether_bricks
fill 330 187 475 330 190 475 minecraft:pink_terracotta
setblock 330 187 479 minecraft:red_nether_bricks
fill 330 187 480 330 190 480 minecraft:pink_terracotta
setblock 330 187 481 minecraft:white_concrete
setblock 330 187 494 minecraft:red_nether_bricks
fill 330 187 495 330 190 495 minecraft:pink_terracotta
setblock 330 187 500 minecraft:white_concrete
setblock 339 187 464 minecraft:pink_terracotta
setblock 340 187 464 minecraft:red_nether_bricks
fill 341 187 464 341 190 464 minecraft:pink_terracotta
setblock 349 187 464 minecraft:white_concrete
setblock 351 187 504 minecraft:white_concrete
fill 353 187 504 353 188 504 minecraft:pink_terracotta
setblock 355 187 464 minecraft:red_nether_bricks
setblock 355 187 503 minecraft:pink_terracotta
setblock 355 187 504 minecraft:red_nether_bricks
fill 356 187 464 356 190 464 minecraft:pink_terracotta
setblock 356 187 503 minecraft:red_nether_bricks
fill 356 187 504 356 190 504 minecraft:pink_terracotta
setblock 357 187 502 minecraft:red_nether_bricks
fill 357 187 503 357 190 503 minecraft:pink_terracotta
fill 358 187 502 358 190 502 minecraft:pink_terracotta
setblock 360 187 464 minecraft:red_nether_bricks
setblock 360 187 504 minecraft:red_nether_bricks
fill 361 187 464 361 190 464 minecraft:pink_terracotta
setblock 361 187 503 minecraft:red_nether_bricks
fill 361 187 504 361 190 504 minecraft:pink_terracotta
fill 362 187 503 362 190 503 minecraft:pink_terracotta
setblock 365 187 504 minecraft:red_nether_bricks
setblock 369 187 496 minecraft:pink_terracotta
setblock 370 187 468 minecraft:white_concrete
setblock 370 187 487 minecraft:white_concrete
setblock 370 187 494 minecraft:red_nether_bricks
fill 370 187 495 370 190 495 minecraft:pink_terracotta
setblock 370 187 499 minecraft:red_nether_bricks
fill 370 187 500 370 189 501 minecraft:pink_terracotta
setblock 370 187 504 minecraft:white_concrete
fill 330 188 474 330 191 474 minecraft:pink_terracotta
setblock 330 188 478 minecraft:red_nether_bricks
fill 330 188 479 331 190 479 minecraft:pink_terracotta
fill 330 188 481 330 188 482 minecraft:pink_terracotta
setblock 330 188 487 minecraft:white_concrete
setblock 330 188 498 minecraft:red_nether_bricks
setblock 331 188 476 minecraft:pink_terracotta
setblock 331 188 477 minecraft:red_nether_bricks
fill 331 188 478 331 191 478 minecraft:pink_terracotta
setblock 332 188 504 minecraft:white_concrete
setblock 338 188 464 minecraft:pink_terracotta
setblock 339 188 464 minecraft:red_nether_bricks
setblock 339 188 504 minecraft:red_nether_bricks
fill 340 188 464 340 191 464 minecraft:pink_terracotta
setblock 343 188 464 minecraft:white_concrete
fill 347 188 464 347 190 464 minecraft:white_concrete
fill 352 188 504 352 189 504 minecraft:pink_terracotta
setblock 354 188 464 minecraft:red_nether_bricks
setblock 354 188 503 minecraft:pink_terracotta
setblock 354 188 504 minecraft:red_nether_bricks
fill 355 188 464 355 191 464 minecraft:pink_terracotta
setblock 355 188 503 minecraft:red_nether_bricks
fill 355 188 504 355 191 504 minecraft:pink_terracotta
setblock 356 188 502 minecraft:red_nether_bricks
fill 356 188 503 356 191 503 minecraft:pink_terracotta
fill 357 188 502 357 191 502 minecraft:pink_terracotta
setblock 359 188 464 minecraft:red_nether_bricks
setblock 359 188 504 minecraft:red_nether_bricks
fill 360 188 464 360 191 464 minecraft:pink_terracotta
setblock 360 188 503 minecraft:red_nether_bricks
fill 360 188 504 360 191 504 minecraft:pink_terracotta
setblock 361 188 502 minecraft:red_nether_bricks
fill 361 188 503 361 191 503 minecraft:pink_terracotta
fill 362 188 502 362 191 502 minecraft:pink_terracotta
setblock 364 188 504 minecraft:red_nether_bricks
fill 365 188 504 365 191 504 minecraft:pink_terracotta
setblock 368 188 464 minecraft:white_concrete
setblock 369 188 498 minecraft:pink_terracotta
setblock 370 188 481 minecraft:white_concrete
setblock 370 188 493 minecraft:red_nether_bricks
fill 370 188 494 370 191 494 minecraft:pink_terracotta
setblock 370 188 498 minecraft:red_nether_bricks
fill 370 188 499 370 191 499 minecraft:pink_terracotta
setblock 330 189 468 minecraft:white_concrete
fill 330 189 473 330 192 473 minecraft:pink_terracotta
setblock 330 189 477 minecraft:red_nether_bricks
fill 330 189 478 330 192 478 minecraft:pink_terracotta
setblock 330 189 481 minecraft:pink_terracotta
setblock 330 189 482 minecraft:red_nether_bricks
fill 330 189 483 330 191 484 minecraft:pink_terracotta
setblock 330 189 493 minecraft:white_concrete
setblock 330 189 497 minecraft:red_nether_bricks
fill 330 189 498 330 191 499 minecraft:pink_terracotta
setblock 331 189 475 minecraft:pink_terracotta
setblock 331 189 476 minecraft:red_nether_bricks
fill 331 189 477 332 191 477 minecraft:pink_terracotta
setblock 331 189 480 minecraft:pink_terracotta
setblock 331 189 481 minecraft:red_nether_bricks
fill 332 189 478 332 190 478 minecraft:pink_terracotta
fill 336 189 464 337 189 464 minecraft:pink_terracotta
fill 336 189 504 337 189 504 minecraft:pink_terracotta
setblock 338 189 464 minecraft:red_nether_bricks
setblock 338 189 504 minecraft:red_nether_bricks
fill 339 189 464 339 192 464 minecraft:pink_terracotta
fill 339 189 504 341 190 504 minecraft:pink_terracotta
fill 345 189 464 346 190 464 minecraft:white_concrete
fill 346 189 465 348 192 465 minecraft:white_concrete
fill 347 189 466 347 192 466 minecraft:white_concrete
fill 348 189 464 349 190 464 minecraft:white_concrete
fill 351 189 504 351 190 504 minecraft:pink_terracotta
setblock 352 189 464 minecraft:pink_terracotta
setblock 353 189 464 minecraft:red_nether_bricks
setblock 353 189 503 minecraft:pink_terracotta
setblock 353 189 504 minecraft:red_nether_bricks
fill 354 189 464 354 192 464 minecraft:pink_terracotta
setblock 354 189 502 minecraft:pink_terracotta
setblock 354 189 503 minecraft:red_nether_bricks
fill 354 189 504 354 192 504 minecraft:pink_terracotta
setblock 355 189 502 minecraft:red_nether_bricks
fill 355 189 503 355 192 503 minecraft:pink_terracotta
fill 356 189 502 356 192 502 minecraft:pink_terracotta
fill 357 189 501 360 189 501 minecraft:pink_terracotta
setblock 358 189 464 minecraft:red_nether_bricks
setblock 358 189 504 minecraft:red_nether_bricks
fill 359 189 464 359 192 464 minecraft:pink_terracotta
setblock 359 189 503 minecraft:red_nether_bricks
fill 359 189 504 359 192 504 minecraft:pink_terracotta
setblock 360 189 502 minecraft:red_nether_bricks
fill 360 189 503 360 192 503 minecraft:pink_terracotta
fill 361 189 502 361 192 502 minecraft:pink_terracotta
setblock 362 189 464 minecraft:white_concrete
setblock 363 189 504 minecraft:red_nether_bricks
setblock 364 189 503 minecraft:red_nether_bricks
fill 364 189 504 364 192 504 minecraft:pink_terracotta
fill 369 189 496 369 190 496 minecraft:pink_terracotta
setblock 369 189 498 minecraft:red_nether_bricks
fill 369 189 499 369 192 499 minecraft:pink_terracotta
setblock 370 189 475 minecraft:white_concrete
setblock 370 189 477 minecraft:red_nether_bricks
fill 370 189 478 370 190 480 minecraft:pink_terracotta
setblock 370 189 492 minecraft:red_nether_bricks
fill 370 189 493 370 192 493 minecraft:pink_terracotta
setblock 370 189 497 minecraft:red_nether_bricks
fill 370 189 498 370 192 498 minecraft:pink_terracotta
setblock 370 189 502 minecraft:red_nether_bricks
setblock 330 190 476 minecraft:red_nether_bricks
fill 330 190 477 330 193 477 minecraft:pink_terracotta
setblock 330 190 481 minecraft:red_nether_bricks
fill 330 190 482 331 192 482 minecraft:pink_terracotta
setblock 330 190 485 minecraft:pink_terracotta
setblock 330 190 496 minecraft:red_nether_bricks
fill 330 190 497 330 193 497 minecraft:pink_terracotta
setblock 330 190 500 minecraft:pink_terracotta
setblock 331 190 464 minecraft:white_concrete
setblock 331 190 474 minecraft:pink_terracotta
setblock 331 190 475 minecraft:red_nether_bricks
fill 331 190 476 332 192 476 minecraft:pink_terracotta
setblock 331 190 480 minecraft:red_nether_bricks
fill 331 190 481 332 192 481 minecraft:pink_terracotta
fill 331 190 483 331 191 483 minecraft:pink_terracotta
fill 332 190 475 332 193 475 minecraft:pink_terracotta
setblock 332 190 479 minecraft:red_nether_bricks
fill 332 190 480 332 193 480 minecraft:pink_terracotta
fill 334 190 504 336 190 504 minecraft:pink_terracotta
fill 335 190 464 336 190 464 minecraft:pink_terracotta
setblock 337 190 464 minecraft:red_nether_bricks
setblock 337 190 503 minecraft:pink_terracotta
setblock 337 190 504 minecraft:red_nether_bricks
fill 338 190 464 338 193 464 minecraft:pink_terracotta
setblock 338 190 503 minecraft:red_nether_bricks
fill 338 190 504 338 193 504 minecraft:pink_terracotta
fill 339 190 503 339 193 503 minecraft:pink_terracotta
setblock 342 190 464 minecraft:red_nether_bricks
setblock 342 190 504 minecraft:red_nether_bricks
fill 343 190 464 343 193 464 minecraft:pink_terracotta
fill 343 190 504 343 193 504 minecraft:pink_terracotta
setblock 344 190 504 minecraft:white_concrete
fill 345 190 465 345 191 465 minecraft:white_concrete
fill 346 190 466 346 191 466 minecraft:white_concrete
fill 347 190 467 347 191 467 minecraft:red_concrete
fill 348 190 466 348 191 466 minecraft:white_concrete
fill 348 190 504 350 191 504 minecraft:pink_terracotta
fill 349 190 465 349 191 465 minecraft:white_concrete
fill 350 190 464 351 190 464 minecraft:pink_terracotta
fill 351 190 503 352 190 503 minecraft:pink_terracotta
setblock 352 190 464 minecraft:red_nether_bricks
setblock 352 190 504 minecraft:red_nether_bricks
fill 353 190 464 353 193 464 minecraft:pink_terracotta
setblock 353 190 502 minecraft:pink_terracotta
setblock 353 190 503 minecraft:red_nether_bricks
fill 353 190 504 353 193 504 minecraft:pink_terracotta
setblock 354 190 502 minecraft:red_nether_bricks
fill 354 190 503 354 193 503 minecraft:pink_terracotta
setblock 355 190 501 minecraft:red_nether_bricks
fill 355 190 502 355 193 502 minecraft:pink_terracotta
setblock 356 190 465 minecraft:red_nether_bricks
fill 356 190 501 359 190 501 minecraft:pink_terracotta
setblock 357 190 464 minecraft:red_nether_bricks
setblock 357 190 504 minecraft:red_nether_bricks
fill 358 190 464 358 193 464 minecraft:pink_terracotta
setblock 358 190 503 minecraft:red_nether_bricks
fill 358 190 504 358 193 504 minecraft:pink_terracotta
setblock 359 190 502 minecraft:red_nether_bricks
fill 359 190 503 359 193 503 minecraft:pink_terracotta
setblock 360 190 501 minecraft:red_nether_bricks
fill 360 190 502 360 193 502 minecraft:pink_terracotta
setblock 362 190 504 minecraft:red_nether_bricks
setblock 363 190 502 minecraft:pink_terracotta
setblock 363 190 503 minecraft:red_nether_bricks
fill 363 190 504 363 193 504 minecraft:pink_terracotta
fill 364 190 503 364 193 503 minecraft:pink_terracotta
setblock 366 190 504 minecraft:pink_terracotta
setblock 369 190 497 minecraft:red_nether_bricks
fill 369 190 498 369 193 498 minecraft:pink_terracotta
fill 369 190 500 370 190 500 minecraft:pink_terracotta
setblock 369 190 504 minecraft:white_concrete
setblock 370 190 469 minecraft:white_concrete
setblock 370 190 476 minecraft:red_nether_bricks
fill 370 190 477 370 193 477 minecraft:pink_terracotta
setblock 370 190 481 minecraft:red_nether_bricks
fill 370 190 482 370 191 484 minecraft:pink_terracotta
fill 370 190 492 370 193 492 minecraft:pink_terracotta
setblock 370 190 496 minecraft:red_nether_bricks
fill 370 190 497 370 193 497 minecraft:pink_terracotta
setblock 370 190 501 minecraft:red_nether_bricks
fill 370 190 502 370 192 503 minecraft:pink_terracotta
fill 330 191 472 330 193 472 minecraft:pink_terracotta
setblock 330 191 475 minecraft:red_nether_bricks
fill 330 191 476 330 194 476 minecraft:pink_terracotta
setblock 330 191 479 minecraft:pink_terracotta
setblock 330 191 480 minecraft:red_nether_bricks
fill 330 191 481 330 194 481 minecraft:pink_terracotta
setblock 330 191 485 minecraft:red_nether_bricks
fill 330 191 486 330 193 487 minecraft:pink_terracotta
setblock 330 191 494 minecraft:pink_terracotta
setblock 330 191 495 minecraft:red_nether_bricks
fill 330 191 496 330 194 496 minecraft:pink_terracotta
setblock 330 191 500 minecraft:red_nether_bricks
fill 330 191 501 330 193 502 minecraft:pink_terracotta
setblock 331 191 473 minecraft:pink_terracotta
setblock 331 191 474 minecraft:red_nether_bricks
fill 331 191 475 331 194 475 minecraft:pink_terracotta
setblock 331 191 479 minecraft:red_nether_bricks
fill 331 191 480 331 194 480 minecraft:pink_terracotta
setblock 331 191 484 minecraft:red_nether_bricks
fill 331 191 485 331 194 485 minecraft:pink_terracotta
setblock 331 191 504 minecraft:white_concrete
setblock 332 191 466 minecraft:light[level=12]
setblock 332 191 474 minecraft:light[level=12]
setblock 332 191 478 minecraft:red_nether_bricks
fill 332 191 479 333 193 479 minecraft:pink_terracotta
setblock 332 191 482 minecraft:pink_terracotta
setblock 332 191 483 minecraft:red_nether_bricks
setblock 332 191 490 minecraft:light[level=12]
setblock 332 191 498 minecraft:light[level=12]
fill 332 191 504 335 191 504 minecraft:pink_terracotta
fill 333 191 464 335 191 464 minecraft:pink_terracotta
setblock 333 191 476 minecraft:pink_terracotta
setblock 333 191 477 minecraft:red_nether_bricks
fill 333 191 478 333 194 478 minecraft:pink_terracotta
fill 333 191 480 333 191 481 minecraft:pink_terracotta
fill 334 191 503 336 191 503 minecraft:pink_terracotta
setblock 336 191 464 minecraft:red_nether_bricks
fill 336 191 465 339 191 465 minecraft:pink_terracotta
setblock 336 191 504 minecraft:red_nether_bricks
fill 337 191 464 337 194 464 minecraft:pink_terracotta
setblock 337 191 503 minecraft:red_nether_bricks
fill 337 191 504 337 194 504 minecraft:pink_terracotta
fill 338 191 503 338 194 503 minecraft:pink_terracotta
fill 339 191 504 340 191 504 minecraft:pink_terracotta
setblock 340 191 465 minecraft:red_nether_bricks
setblock 340 191 466 minecraft:light[level=12]
setblock 340 191 474 minecraft:light[level=12]
setblock 340 191 482 minecraft:light[level=12]
setblock 340 191 490 minecraft:light[level=12]
setblock 340 191 498 minecraft:light[level=12]
fill 340 191 503 341 191 503 minecraft:pink_terracotta
setblock 341 191 464 minecraft:red_nether_bricks
setblock 341 191 504 minecraft:red_nether_bricks
fill 342 191 464 342 194 464 minecraft:pink_terracotta
fill 342 191 504 342 194 504 minecraft:pink_terracotta
fill 344 191 464 345 191 464 minecraft:pink_terracotta
fill 344 191 504 345 191 504 minecraft:pink_terracotta
setblock 346 191 464 minecraft:red_nether_bricks
setblock 346 191 504 minecraft:red_nether_bricks
fill 347 191 464 350 191 464 minecraft:pink_terracotta
fill 347 191 504 347 194 504 minecraft:pink_terracotta
setblock 348 191 474 minecraft:light[level=12]
setblock 348 191 482 minecraft:light[level=12]
setblock 348 191 490 minecraft:light[level=12]
setblock 348 191 498 minecraft:light[level=12]
fill 349 191 503 351 191 503 minecraft:pink_terracotta
setblock 351 191 464 minecraft:red_nether_bricks
setblock 351 191 504 minecraft:red_nether_bricks
fill 352 191 464 352 194 464 minecraft:pink_terracotta
setblock 352 191 502 minecraft:pink_terracotta
setblock 352 191 503 minecraft:red_nether_bricks
fill 352 191 504 352 194 504 minecraft:pink_terracotta
fill 353 191 465 354 191 465 minecraft:pink_terracotta
setblock 353 191 502 minecraft:red_nether_bricks
fill 353 191 503 353 194 503 minecraft:pink_terracotta
setblock 354 191 501 minecraft:red_nether_bricks
fill 354 191 502 354 194 502 minecraft:pink_terracotta
setblock 355 191 465 minecraft:red_nether_bricks
fill 355 191 501 358 191 501 minecraft:pink_terracotta
setblock 356 191 464 minecraft:red_nether_bricks
fill 356 191 465 358 192 465 minecraft:pink_terracotta
setblock 356 191 466 minecraft:light[level=12]
setblock 356 191 474 minecraft:light[level=12]
setblock 356 191 482 minecraft:light[level=12]
setblock 356 191 490 minecraft:light[level=12]
setblock 356 191 498 minecraft:light[level=12]
setblock 356 191 504 minecraft:red_nether_bricks
fill 357 191 464 357 194 464 minecraft:pink_terracotta
setblock 357 191 503 minecraft:red_nether_bricks
fill 357 191 504 357 194 504 minecraft:pink_terracotta
setblock 358 191 502 minecraft:red_nether_bricks
fill 358 191 503 358 194 503 minecraft:pink_terracotta
setblock 359 191 501 minecraft:red_nether_bricks
fill 359 191 502 359 194 502 minecraft:pink_terracotta
fill 360 191 501 361 193 501 minecraft:pink_terracotta
setblock 361 191 464 minecraft:red_nether_bricks
setblock 361 191 504 minecraft:red_nether_bricks
setblock 362 191 503 minecraft:red_nether_bricks
fill 362 191 504 362 194 504 minecraft:pink_terracotta
setblock 363 191 502 minecraft:red_nether_bricks
fill 363 191 503 363 194 503 minecraft:pink_terracotta
setblock 364 191 466 minecraft:light[level=12]
setblock 364 191 474 minecraft:light[level=12]
setblock 364 191 482 minecraft:light[level=12]
setblock 364 191 490 minecraft:light[level=12]
setblock 364 191 498 minecraft:light[level=12]
fill 365 191 503 365 192 503 minecraft:pink_terracotta
setblock 366 191 504 minecraft:red_nether_bricks
fill 367 191 504 370 191 504 minecraft:pink_terracotta
setblock 369 191 464 minecraft:white_concrete
setblock 369 191 496 minecraft:red_nether_bricks
fill 369 191 497 369 194 497 minecraft:pink_terracotta
setblock 369 191 500 minecraft:pink_terracotta
setblock 369 191 501 minecraft:red_nether_bricks
setblock 370 191 475 minecraft:red_nether_bricks
fill 370 191 476 370 194 476 minecraft:pink_terracotta
fill 370 191 478 370 191 479 minecraft:pink_terracotta
setblock 370 191 480 minecraft:red_nether_bricks
fill 370 191 481 370 194 481 minecraft:pink_terracotta
setblock 370 191 485 minecraft:red_nether_bricks
fill 370 191 486 370 191 489 minecraft:pink_terracotta
setblock 370 191 490 minecraft:red_nether_bricks
fill 370 191 491 370 194 491 minecraft:pink_terracotta
setblock 370 191 495 minecraft:red_nether_bricks
fill 370 191 496 370 194 496 minecraft:pink_terracotta
setblock 370 191 500 minecraft:red_nether_bricks
fill 370 191 501 370 194 501 minecraft:pink_terracotta
setblock 330 192 467 minecraft:white_concrete
fill 330 192 471 330 194 471 minecraft:pink_terracotta
setblock 330 192 474 minecraft:red_nether_bricks
fill 330 192 475 330 195 475 minecraft:pink_terracotta
setblock 330 192 479 minecraft:red_nether_bricks
fill 330 192 480 330 195 480 minecraft:pink_terracotta
setblock 330 192 483 minecraft:pink_terracotta
setblock 330 192 484 minecraft:red_nether_bricks
fill 330 192 485 330 195 485 minecraft:pink_terracotta
setblock 330 192 488 minecraft:pink_terracotta
setblock 330 192 489 minecraft:red_nether_bricks
setblock 330 192 494 minecraft:red_nether_bricks
fill 330 192 495 330 195 495 minecraft:pink_terracotta
setblock 330 192 498 minecraft:pink_terracotta
setblock 330 192 499 minecraft:red_nether_bricks
fill 330 192 500 331 194 500 minecraft:pink_terracotta
setblock 330 192 503 minecraft:pink_terracotta
setblock 330 192 504 minecraft:red_nether_bricks
setblock 331 192 473 minecraft:red_nether_bricks
fill 331 192 474 332 194 474 minecraft:pink_terracotta
setblock 331 192 477 minecraft:pink_terracotta
setblock 331 192 478 minecraft:red_nether_bricks
fill 331 192 479 331 195 479 minecraft:pink_terracotta
setblock 331 192 483 minecraft:red_nether_bricks
fill 331 192 484 332 194 484 minecraft:pink_terracotta
fill 331 192 486 331 193 486 minecraft:pink_terracotta
fill 331 192 499 331 195 499 minecraft:pink_terracotta
fill 331 192 501 331 193 501 minecraft:pink_terracotta
fill 331 192 504 334 192 504 minecraft:pink_terracotta
fill 332 192 464 334 192 464 minecraft:pink_terracotta
setblock 332 192 477 minecraft:red_nether_bricks
fill 332 192 478 332 195 478 minecraft:pink_terracotta
setblock 332 192 482 minecraft:red_nether_bricks
fill 332 192 483 332 195 483 minecraft:pink_terracotta
fill 332 192 503 335 192 503 minecraft:pink_terracotta
setblock 333 192 476 minecraft:red_nether_bricks
fill 333 192 477 333 195 477 minecraft:pink_terracotta
setblock 333 192 480 minecraft:pink_terracotta
setblock 333 192 481 minecraft:red_nether_bricks
fill 333 192 482 333 195 482 minecraft:pink_terracotta
setblock 334 192 465 minecraft:red_nether_bricks
setblock 335 192 464 minecraft:red_nether_bricks
fill 335 192 465 338 192 465 minecraft:pink_terracotta
setblock 335 192 504 minecraft:red_nether_bricks
fill 336 192 464 336 195 464 minecraft:pink_terracotta
setblock 336 192 503 minecraft:red_nether_bricks
fill 336 192 504 336 195 504 minecraft:pink_terracotta
fill 337 192 503 337 195 503 minecraft:pink_terracotta
setblock 339 192 465 minecraft:red_nether_bricks
setblock 339 192 504 minecraft:pink_terracotta
setblock 340 192 464 minecraft:red_nether_bricks
fill 340 192 465 341 194 465 minecraft:pink_terracotta
setblock 340 192 503 minecraft:pink_terracotta
setblock 340 192 504 minecraft:red_nether_bricks
fill 341 192 464 341 195 464 minecraft:pink_terracotta
setblock 341 192 503 minecraft:red_nether_bricks
fill 341 192 504 341 195 504 minecraft:pink_terracotta
fill 342 192 503 342 195 503 minecraft:pink_terracotta
setblock 344 192 464 minecraft:pink_terracotta
setblock 344 192 504 minecraft:pink_terracotta
setblock 345 192 464 minecraft:red_nether_bricks
setblock 345 192 504 minecraft:red_nether_bricks
fill 346 192 464 349 192 464 minecraft:pink_terracotta
fill 346 192 504 346 195 504 minecraft:pink_terracotta
fill 347 192 503 350 192 503 minecraft:pink_terracotta
fill 348 192 504 349 192 504 minecraft:pink_terracotta
setblock 350 192 464 minecraft:red_nether_bricks
fill 350 192 502 351 192 502 minecraft:pink_terracotta
setblock 350 192 504 minecraft:red_nether_bricks
fill 351 192 464 351 194 465 minecraft:pink_terracotta
setblock 351 192 503 minecraft:red_nether_bricks
fill 351 192 504 351 195 504 minecraft:pink_terracotta
fill 352 192 465 353 192 465 minecraft:pink_terracotta
setblock 352 192 502 minecraft:red_nether_bricks
fill 352 192 503 352 195 503 minecraft:pink_terracotta
setblock 353 192 501 minecraft:red_nether_bricks
fill 353 192 502 353 195 502 minecraft:pink_terracotta
setblock 354 192 465 minecraft:red_nether_bricks
fill 354 192 501 357 192 501 minecraft:pink_terracotta
setblock 355 192 464 minecraft:red_nether_bricks
fill 355 192 465 355 195 465 minecraft:pink_terracotta
setblock 355 192 504 minecraft:red_nether_bricks
fill 356 192 464 356 195 464 minecraft:pink_terracotta
fill 356 192 500 357 193 500 minecraft:pink_terracotta
setblock 356 192 503 minecraft:red_nether_bricks
fill 356 192 504 356 195 504 minecraft:pink_terracotta
setblock 357 192 502 minecraft:red_nether_bricks
fill 357 192 503 357 195 503 minecraft:pink_terracotta
setblock 358 192 501 minecraft:red_nether_bricks
fill 358 192 502 358 195 502 minecraft:pink_terracotta
fill 359 192 501 359 195 501 minecraft:pink_terracotta
setblock 360 192 464 minecraft:red_nether_bricks
setblock 360 192 504 minecraft:red_nether_bricks
fill 361 192 464 361 195 464 minecraft:pink_terracotta
setblock 361 192 503 minecraft:red_nether_bricks
fill 361 192 504 361 195 504 minecraft:pink_terracotta
setblock 362 192 502 minecraft:red_nether_bricks
fill 362 192 503 362 195 503 minecraft:pink_terracotta
setblock 363 192 464 minecraft:white_concrete
fill 363 192 502 363 194 502 minecraft:pink_terracotta
setblock 365 192 504 minecraft:red_nether_bricks
setblock 366 192 503 minecraft:red_nether_bricks
fill 366 192 504 369 192 504 minecraft:pink_terracotta
fill 369 192 478 369 192 479 minecraft:pink_terracotta
setblock 369 192 480 minecraft:red_nether_bricks
fill 369 192 481 369 193 483 minecraft:pink_terracotta
fill 369 192 496 369 195 496 minecraft:pink_terracotta
setblock 369 192 500 minecraft:red_nether_bricks
fill 369 192 501 369 194 502 minecraft:pink_terracotta
setblock 370 192 474 minecraft:red_nether_bricks
fill 370 192 475 370 195 475 minecraft:pink_terracotta
setblock 370 192 478 minecraft:pink_terracotta
setblock 370 192 479 minecraft:red_nether_bricks
fill 370 192 480 370 195 480 minecraft:pink_terracotta
fill 370 192 482 370 192 483 minecraft:pink_terracotta
setblock 370 192 484 minecraft:red_nether_bricks
fill 370 192 485 370 192 488 minecraft:pink_terracotta
setblock 370 192 489 minecraft:red_nether_bricks
fill 370 192 490 370 195 490 minecraft:pink_terracotta
setblock 370 192 494 minecraft:red_nether_bricks
fill 370 192 495 370 195 495 minecraft:pink_terracotta
setblock 370 192 499 minecraft:red_nether_bricks
fill 370 192 500 370 195 500 minecraft:pink_terracotta
setblock 370 192 504 minecraft:red_nether_bricks
fill 330 193 464 333 193 464 minecraft:pink_terracotta
fill 330 193 470 330 195 470 minecraft:pink_terracotta
setblock 330 193 473 minecraft:red_nether_bricks
fill 330 193 474 330 196 474 minecraft:pink_terracotta
setblock 330 193 478 minecraft:red_nether_bricks
fill 330 193 479 330 196 479 minecraft:pink_terracotta
setblock 330 193 482 minecraft:pink_terracotta
setblock 330 193 483 minecraft:red_nether_bricks
fill 330 193 484 330 196 484 minecraft:pink_terracotta
setblock 330 193 488 minecraft:red_nether_bricks
fill 330 193 489 330 193 492 minecraft:pink_terracotta
setblock 330 193 493 minecraft:red_nether_bricks
fill 330 193 494 330 195 494 minecraft:pink_terracotta
setblock 330 193 498 minecraft:red_nether_bricks
fill 330 193 499 330 196 499 minecraft:pink_terracotta
setblock 330 193 503 minecraft:red_nether_bricks
fill 330 193 504 333 193 504 minecraft:pink_terracotta
setblock 331 193 472 minecraft:red_nether_bricks
fill 331 193 473 331 196 473 minecraft:pink_terracotta
setblock 331 193 476 minecraft:pink_terracotta
setblock 331 193 477 minecraft:red_nether_bricks
fill 331 193 478 331 196 478 minecraft:pink_terracotta
setblock 331 193 481 minecraft:pink_terracotta
setblock 331 193 482 minecraft:red_nether_bricks
fill 331 193 483 331 196 483 minecraft:pink_terracotta
setblock 331 193 487 minecraft:red_nether_bricks
fill 331 193 498 331 194 498 minecraft:pink_terracotta
setblock 331 193 502 minecraft:red_nether_bricks
fill 331 193 503 334 193 503 minecraft:pink_terracotta
setblock 332 193 476 minecraft:red_nether_bricks
fill 332 193 477 332 196 477 minecraft:pink_terracotta
setblock 332 193 481 minecraft:red_nether_bricks
fill 332 193 482 332 196 482 minecraft:pink_terracotta
setblock 332 193 485 minecraft:pink_terracotta
setblock 333 193 465 minecraft:red_nether_bricks
setblock 333 193 475 minecraft:red_nether_bricks
fill 333 193 476 333 195 476 minecraft:pink_terracotta
setblock 333 193 480 minecraft:red_nether_bricks
fill 333 193 481 334 195 481 minecraft:pink_terracotta
fill 333 193 483 333 194 483 minecraft:pink_terracotta
setblock 334 193 464 minecraft:red_nether_bricks
fill 334 193 465 337 193 465 minecraft:pink_terracotta
setblock 334 193 478 minecraft:pink_terracotta
setblock 334 193 479 minecraft:red_nether_bricks
fill 334 193 480 334 195 480 minecraft:pink_terracotta
fill 334 193 502 335 193 502 minecraft:pink_terracotta
setblock 334 193 504 minecraft:red_nether_bricks
fill 335 193 464 335 196 464 minecraft:pink_terracotta
setblock 335 193 503 minecraft:red_nether_bricks
fill 335 193 504 335 196 504 minecraft:pink_terracotta
setblock 336 193 502 minecraft:red_nether_bricks
fill 336 193 503 336 196 503 minecraft:pink_terracotta
fill 337 193 502 338 194 502 minecraft:pink_terracotta
setblock 338 193 465 minecraft:red_nether_bricks
setblock 339 193 464 minecraft:red_nether_bricks
fill 339 193 465 339 196 465 minecraft:pink_terracotta
setblock 339 193 504 minecraft:red_nether_bricks
fill 340 193 464 340 196 464 minecraft:pink_terracotta
setblock 340 193 503 minecraft:red_nether_bricks
fill 340 193 504 340 196 504 minecraft:pink_terracotta
fill 341 193 503 341 196 503 minecraft:pink_terracotta
setblock 342 193 465 minecraft:pink_terracotta
fill 343 193 503 344 193 503 minecraft:pink_terracotta
setblock 344 193 464 minecraft:red_nether_bricks
setblock 344 193 504 minecraft:red_nether_bricks
fill 345 193 464 348 193 464 minecraft:pink_terracotta
setblock 345 193 503 minecraft:red_nether_bricks
fill 345 193 504 345 196 504 minecraft:pink_terracotta
fill 346 193 503 349 193 503 minecraft:pink_terracotta
setblock 348 193 504 minecraft:pink_terracotta
setblock 349 193 464 minecraft:red_nether_bricks
fill 349 193 465 350 195 465 minecraft:pink_terracotta
fill 349 193 502 350 193 502 minecraft:pink_terracotta
setblock 349 193 504 minecraft:red_nether_bricks
fill 350 193 464 350 196 464 minecraft:pink_terracotta
setblock 350 193 503 minecraft:red_nether_bricks
fill 350 193 504 350 196 504 minecraft:pink_terracotta
setblock 351 193 502 minecraft:red_nether_bricks
fill 351 193 503 351 196 503 minecraft:pink_terracotta
setblock 352 193 465 minecraft:pink_terracotta
setblock 352 193 501 minecraft:red_nether_bricks
fill 352 193 502 352 196 502 minecraft:pink_terracotta
setblock 353 193 465 minecraft:red_nether_bricks
fill 353 193 501 356 193 501 minecraft:pink_terracotta
setblock 354 193 464 minecraft:red_nether_bricks
fill 354 193 465 354 196 465 minecraft:pink_terracotta
setblock 354 193 504 minecraft:red_nether_bricks
fill 355 193 464 355 196 464 minecraft:pink_terracotta
fill 355 193 500 355 194 500 minecraft:pink_terracotta
setblock 355 193 503 minecraft:red_nether_bricks
fill 355 193 504 355 196 504 minecraft:pink_terracotta
fill 356 193 465 357 193 465 minecraft:pink_terracotta
setblock 356 193 502 minecraft:red_nether_bricks
fill 356 193 503 356 196 503 minecraft:pink_terracotta
setblock 357 193 501 minecraft:red_nether_bricks
fill 357 193 502 357 196 502 minecraft:pink_terracotta
setblock 358 193 465 minecraft:red_nether_bricks
setblock 358 193 500 minecraft:red_nether_bricks
fill 358 193 501 358 196 501 minecraft:pink_terracotta
setblock 359 193 464 minecraft:red_nether_bricks
fill 359 193 465 359 195 465 minecraft:pink_terracotta
setblock 359 193 504 minecraft:red_nether_bricks
fill 360 193 464 360 196 464 minecraft:pink_terracotta
setblock 360 193 503 minecraft:red_nether_bricks
fill 360 193 504 360 196 504 minecraft:pink_terracotta
setblock 361 193 502 minecraft:red_nether_bricks
fill 361 193 503 361 196 503 minecraft:pink_terracotta
fill 362 193 464 362 194 464 minecraft:pink_terracotta
fill 362 193 502 362 195 502 minecraft:pink_terracotta
setblock 364 193 504 minecraft:red_nether_bricks
setblock 365 193 503 minecraft:red_nether_bricks
fill 365 193 504 368 193 504 minecraft:pink_terracotta
fill 366 193 503 369 193 503 minecraft:pink_terracotta
fill 369 193 477 369 193 478 minecraft:pink_terracotta
setblock 369 193 479 minecraft:red_nether_bricks
fill 369 193 480 369 196 480 minecraft:pink_terracotta
setblock 369 193 484 minecraft:red_nether_bricks
fill 369 193 485 370 194 486 minecraft:pink_terracotta
setblock 369 193 499 minecraft:red_nether_bricks
fill 369 193 500 369 196 500 minecraft:pink_terracotta
setblock 369 193 504 minecraft:red_nether_bricks
fill 370 193 474 370 196 474 minecraft:pink_terracotta
setblock 370 193 478 minecraft:red_nether_bricks
fill 370 193 479 370 196 479 minecraft:pink_terracotta
setblock 370 193 482 minecraft:pink_terracotta
setblock 370 193 483 minecraft:red_nether_bricks
fill 370 193 484 370 196 484 minecraft:pink_terracotta
setblock 370 193 487 minecraft:pink_terracotta
setblock 370 193 488 minecraft:red_nether_bricks
fill 370 193 489 370 196 489 minecraft:pink_terracotta
setblock 370 193 493 minecraft:red_nether_bricks
fill 370 193 494 370 196 494 minecraft:pink_terracotta
setblock 370 193 498 minecraft:red_nether_bricks
fill 370 193 499 370 196 499 minecraft:pink_terracotta
setblock 370 193 502 minecraft:pink_terracotta
setblock 370 193 503 minecraft:red_nether_bricks
fill 370 193 504 370 196 504 minecraft:pink_terracotta
fill 330 194 464 330 194 466 minecraft:pink_terracotta
setblock 330 194 467 minecraft:red_nether_bricks
fill 330 194 468 330 196 469 minecraft:pink_terracotta
setblock 330 194 472 minecraft:red_nether_bricks
fill 330 194 473 330 197 473 minecraft:pink_terracotta
setblock 330 194 477 minecraft:red_nether_bricks
fill 330 194 478 330 197 478 minecraft:pink_terracotta
setblock 330 194 482 minecraft:red_nether_bricks
fill 330 194 483 330 197 483 minecraft:pink_terracotta
setblock 330 194 486 minecraft:pink_terracotta
setblock 330 194 487 minecraft:red_nether_bricks
fill 330 194 488 330 194 491 minecraft:pink_terracotta
setblock 330 194 492 minecraft:red_nether_bricks
fill 330 194 493 330 196 493 minecraft:pink_terracotta
setblock 330 194 497 minecraft:red_nether_bricks
fill 330 194 498 330 197 498 minecraft:pink_terracotta
setblock 330 194 501 minecraft:pink_terracotta
setblock 330 194 502 minecraft:red_nether_bricks
fill 330 194 503 332 194 504 minecraft:pink_terracotta
fill 331 194 464 331 194 465 minecraft:pink_terracotta
setblock 331 194 471 minecraft:red_nether_bricks
fill 331 194 472 331 197 472 minecraft:pink_terracotta
setblock 331 194 476 minecraft:red_nether_bricks
fill 331 194 477 331 197 477 minecraft:pink_terracotta
setblock 331 194 481 minecraft:red_nether_bricks
fill 331 194 482 331 197 482 minecraft:pink_terracotta
setblock 331 194 486 minecraft:red_nether_bricks
fill 331 194 487 331 196 488 minecraft:pink_terracotta
setblock 331 194 501 minecraft:red_nether_bricks
fill 331 194 502 331 197 502 minecraft:pink_terracotta
setblock 332 194 464 minecraft:pink_terracotta
setblock 332 194 465 minecraft:red_nether_bricks
fill 332 194 473 332 195 473 minecraft:pink_terracotta
setblock 332 194 475 minecraft:red_nether_bricks
fill 332 194 476 332 197 476 minecraft:pink_terracotta
setblock 332 194 479 minecraft:pink_terracotta
setblock 332 194 480 minecraft:red_nether_bricks
fill 332 194 481 332 197 481 minecraft:pink_terracotta
setblock 332 194 485 minecraft:red_nether_bricks
fill 332 194 486 332 197 486 minecraft:pink_terracotta
setblock 333 194 464 minecraft:red_nether_bricks
fill 333 194 465 336 194 465 minecraft:pink_terracotta
setblock 333 194 475 minecraft:pink_terracotta
setblock 333 194 479 minecraft:red_nether_bricks
fill 333 194 480 333 197 480 minecraft:pink_terracotta
setblock 333 194 484 minecraft:red_nether_bricks
fill 333 194 502 333 194 503 minecraft:pink_terracotta
setblock 333 194 504 minecraft:red_nether_bricks
fill 334 194 464 334 197 464 minecraft:pink_terracotta
setblock 334 194 478 minecraft:red_nether_bricks
fill 334 194 479 334 195 479 minecraft:pink_terracotta
setblock 334 194 502 minecraft:pink_terracotta
setblock 334 194 503 minecraft:red_nether_bricks
fill 334 194 504 334 197 504 minecraft:pink_terracotta
setblock 335 194 466 minecraft:pink_terracotta
fill 335 194 493 336 195 493 minecraft:pink_concrete
setblock 335 194 502 minecraft:red_nether_bricks
fill 335 194 503 335 197 503 minecraft:pink_terracotta
setblock 336 194 466 minecraft:red_nether_bricks
fill 336 194 502 336 195 502 minecraft:pink_terracotta
setblock 337 194 465 minecraft:red_nether_bricks
fill 337 194 466 338 196 466 minecraft:pink_terracotta
setblock 338 194 464 minecraft:red_nether_bricks
fill 338 194 465 338 197 465 minecraft:pink_terracotta
setblock 338 194 504 minecraft:red_nether_bricks
fill 339 194 464 339 197 464 minecraft:pink_terracotta
setblock 339 194 503 minecraft:red_nether_bricks
fill 339 194 504 339 197 504 minecraft:pink_terracotta
fill 340 194 503 340 197 503 minecraft:pink_terracotta
setblock 342 194 465 minecraft:red_nether_bricks
setblock 343 194 464 minecraft:red_nether_bricks
fill 343 194 465 343 197 465 minecraft:pink_terracotta
setblock 343 194 503 minecraft:pink_terracotta
setblock 343 194 504 minecraft:red_nether_bricks
fill 344 194 464 347 194 464 minecraft:pink_terracotta
setblock 344 194 503 minecraft:red_nether_bricks
fill 344 194 504 344 197 504 minecraft:pink_terracotta
fill 345 194 503 348 194 503 minecraft:pink_terracotta
setblock 347 194 465 minecraft:red_nether_bricks
setblock 348 194 464 minecraft:red_nether_bricks
fill 348 194 465 348 197 465 minecraft:pink_terracotta
fill 348 194 502 349 194 502 minecraft:pink_terracotta
setblock 348 194 504 minecraft:red_nether_bricks
fill 349 194 464 349 197 464 minecraft:pink_terracotta
setblock 349 194 503 minecraft:red_nether_bricks
fill 349 194 504 349 197 504 minecraft:pink_terracotta
setblock 350 194 502 minecraft:red_nether_bricks
fill 350 194 503 350 197 503 minecraft:pink_terracotta
setblock 351 194 501 minecraft:red_nether_bricks
fill 351 194 502 351 197 502 minecraft:pink_terracotta
setblock 352 194 465 minecraft:red_nether_bricks
fill 352 194 501 355 194 501 minecraft:pink_terracotta
setblock 353 194 464 minecraft:red_nether_bricks
fill 353 194 465 353 197 465 minecraft:pink_terracotta
setblock 353 194 504 minecraft:red_nether_bricks
fill 354 194 464 354 197 464 minecraft:pink_terracotta
setblock 354 194 503 minecraft:red_nether_bricks
fill 354 194 504 354 197 504 minecraft:pink_terracotta
setblock 355 194 502 minecraft:red_nether_bricks
fill 355 194 503 355 197 503 minecraft:pink_terracotta
setblock 356 194 465 minecraft:pink_terracotta
setblock 356 194 500 minecraft:pink_terracotta
setblock 356 194 501 minecraft:red_nether_bricks
fill 356 194 502 356 197 502 minecraft:pink_terracotta
setblock 357 194 465 minecraft:red_nether_bricks
setblock 357 194 500 minecraft:red_nether_bricks
fill 357 194 501 357 197 501 minecraft:pink_terracotta
setblock 358 194 464 minecraft:red_nether_bricks
fill 358 194 465 358 197 465 minecraft:pink_terracotta
setblock 358 194 504 minecraft:red_nether_bricks
fill 359 194 464 359 197 464 minecraft:pink_terracotta
setblock 359 194 503 minecraft:red_nether_bricks
fill 359 194 504 359 197 504 minecraft:pink_terracotta
setblock 360 194 501 minecraft:pink_terracotta
setblock 360 194 502 minecraft:red_nether_bricks
fill 360 194 503 360 197 503 minecraft:pink_terracotta
fill 361 194 502 361 196 502 minecraft:pink_terracotta
setblock 363 194 504 minecraft:red_nether_bricks
setblock 364 194 503 minecraft:red_nether_bricks
fill 364 194 504 367 194 504 minecraft:pink_terracotta
fill 365 194 503 368 194 503 minecraft:pink_terracotta
setblock 368 194 504 minecraft:red_nether_bricks
setblock 369 194 477 minecraft:pink_terracotta
setblock 369 194 478 minecraft:red_nether_bricks
fill 369 194 479 369 197 479 minecraft:pink_terracotta
fill 369 194 481 369 194 482 minecraft:pink_terracotta
setblock 369 194 483 minecraft:red_nether_bricks
fill 369 194 484 369 197 484 minecraft:pink_terracotta
setblock 369 194 487 minecraft:pink_terracotta
setblock 369 194 488 minecraft:red_nether_bricks
setblock 369 194 498 minecraft:red_nether_bricks
fill 369 194 499 369 196 499 minecraft:pink_terracotta
setblock 369 194 503 minecraft:red_nether_bricks
fill 369 194 504 369 197 504 minecraft:pink_terracotta
setblock 370 194 464 minecraft:white_concrete
setblock 370 194 470 minecraft:white_concrete
setblock 370 194 477 minecraft:red_nether_bricks
fill 370 194 478 370 197 478 minecraft:pink_terracotta
setblock 370 194 482 minecraft:red_nether_bricks
fill 370 194 483 370 197 483 minecraft:pink_terracotta
setblock 370 194 487 minecraft:red_nether_bricks
fill 370 194 488 370 197 488 minecraft:pink_terracotta
setblock 370 194 492 minecraft:red_nether_bricks
fill 370 194 493 370 197 493 minecraft:pink_terracotta
setblock 370 194 497 minecraft:red_nether_bricks
fill 370 194 498 370 197 498 minecraft:pink_terracotta
setblock 370 194 502 minecraft:red_nether_bricks
fill 370 194 503 370 197 503 minecraft:pink_terracotta
fill 330 195 464 330 195 465 minecraft:pink_terracotta
setblock 330 195 466 minecraft:red_nether_bricks
fill 330 195 467 331 197 467 minecraft:pink_terracotta
setblock 330 195 471 minecraft:red_nether_bricks
fill 330 195 472 330 198 472 minecraft:pink_terracotta
setblock 330 195 476 minecraft:red_nether_bricks
fill 330 195 477 330 198 477 minecraft:pink_terracotta
setblock 330 195 481 minecraft:red_nether_bricks
fill 330 195 482 330 198 482 minecraft:pink_terracotta
setblock 330 195 486 minecraft:red_nether_bricks
fill 330 195 487 330 195 490 minecraft:pink_terracotta
setblock 330 195 491 minecraft:red_nether_bricks
fill 330 195 492 330 198 492 minecraft:pink_terracotta
setblock 330 195 496 minecraft:red_nether_bricks
fill 330 195 497 330 196 497 minecraft:pink_terracotta
setblock 330 195 500 minecraft:pink_terracotta
setblock 330 195 501 minecraft:red_nether_bricks
fill 330 195 502 330 196 504 minecraft:pink_terracotta
setblock 331 195 464 minecraft:pink_terracotta
setblock 331 195 465 minecraft:red_nether_bricks
fill 331 195 466 331 198 466 minecraft:pink_terracotta
fill 331 195 468 331 195 469 minecraft:pink_terracotta
setblock 331 195 470 minecraft:red_nether_bricks
fill 331 195 471 331 198 471 minecraft:pink_terracotta
setblock 331 195 474 minecraft:pink_terracotta
setblock 331 195 475 minecraft:red_nether_bricks
fill 331 195 476 331 198 476 minecraft:pink_terracotta
setblock 331 195 480 minecraft:red_nether_bricks
fill 331 195 481 331 198 481 minecraft:pink_terracotta
setblock 331 195 484 minecraft:pink_terracotta
setblock 331 195 485 minecraft:red_nether_bricks
fill 331 195 486 331 198 486 minecraft:pink_terracotta
setblock 331 195 489 minecraft:pink_terracotta
setblock 331 195 500 minecraft:red_nether_bricks
fill 331 195 501 331 197 501 minecraft:pink_terracotta
fill 331 195 503 331 195 504 minecraft:pink_terracotta
setblock 332 195 464 minecraft:red_nether_bricks
fill 332 195 465 335 195 465 minecraft:pink_terracotta
setblock 332 195 474 minecraft:red_nether_bricks
fill 332 195 475 332 197 475 minecraft:pink_terracotta
setblock 332 195 479 minecraft:red_nether_bricks
fill 332 195 480 332 198 480 minecraft:pink_terracotta
setblock 332 195 484 minecraft:red_nether_bricks
fill 332 195 485 333 197 485 minecraft:pink_terracotta
fill 332 195 487 332 196 487 minecraft:pink_terracotta
setblock 332 195 503 minecraft:pink_terracotta
setblock 332 195 504 minecraft:red_nether_bricks
fill 333 195 464 333 198 464 minecraft:pink_terracotta
fill 333 195 466 334 195 466 minecraft:pink_terracotta
setblock 333 195 478 minecraft:red_nether_bricks
fill 333 195 479 333 197 479 minecraft:pink_terracotta
setblock 333 195 483 minecraft:red_nether_bricks
fill 333 195 484 333 198 484 minecraft:pink_terracotta
setblock 333 195 502 minecraft:pink_terracotta
setblock 333 195 503 minecraft:red_nether_bricks
fill 333 195 504 333 198 504 minecraft:pink_terracotta
setblock 334 195 482 minecraft:red_nether_bricks
setblock 334 195 502 minecraft:red_nether_bricks
fill 334 195 503 334 198 503 minecraft:pink_terracotta
setblock 335 195 466 minecraft:red_nether_bricks
fill 335 195 502 335 196 502 minecraft:pink_terracotta
setblock 336 195 465 minecraft:red_nether_bricks
fill 336 195 466 336 198 466 minecraft:pink_terracotta
setblock 337 195 464 minecraft:red_nether_bricks
fill 337 195 465 337 198 465 minecraft:pink_terracotta
setblock 337 195 502 minecraft:pink_terracotta
setblock 337 195 504 minecraft:red_nether_bricks
fill 338 195 464 338 198 464 minecraft:pink_terracotta
setblock 338 195 503 minecraft:red_nether_bricks
fill 338 195 504 338 198 504 minecraft:pink_terracotta
fill 339 195 503 339 197 503 minecraft:pink_terracotta
setblock 340 195 465 minecraft:pink_terracotta
setblock 341 195 465 minecraft:red_nether_bricks
setblock 342 195 464 minecraft:red_nether_bricks
fill 342 195 465 342 198 465 minecraft:pink_terracotta
fill 342 195 482 342 196 483 minecraft:pink_concrete
setblock 342 195 504 minecraft:red_nether_bricks
fill 343 195 464 346 195 464 minecraft:pink_terracotta
fill 343 195 482 343 196 482 minecraft:pink_concrete
setblock 343 195 503 minecraft:red_nether_bricks
fill 343 195 504 343 198 504 minecraft:pink_terracotta
fill 344 195 465 345 195 465 minecraft:pink_terracotta
fill 344 195 503 347 195 503 minecraft:pink_terracotta
setblock 346 195 465 minecraft:red_nether_bricks
setblock 347 195 464 minecraft:red_nether_bricks
fill 347 195 465 347 198 465 minecraft:pink_terracotta
setblock 347 195 504 minecraft:red_nether_bricks
fill 348 195 464 348 198 464 minecraft:pink_terracotta
setblock 348 195 502 minecraft:pink_terracotta
setblock 348 195 503 minecraft:red_nether_bricks
fill 348 195 504 348 198 504 minecraft:pink_terracotta
setblock 349 195 502 minecraft:red_nether_bricks
fill 349 195 503 349 198 503 minecraft:pink_terracotta
fill 350 195 502 350 198 502 minecraft:pink_terracotta
setblock 351 195 464 minecraft:pink_terracotta
setblock 351 195 465 minecraft:red_nether_bricks
fill 351 195 501 354 195 501 minecraft:pink_terracotta
setblock 352 195 464 minecraft:red_nether_bricks
fill 352 195 465 352 197 466 minecraft:pink_terracotta
setblock 352 195 504 minecraft:red_nether_bricks
fill 353 195 464 353 198 464 minecraft:pink_terracotta
fill 353 195 466 354 195 466 minecraft:pink_terracotta
setblock 353 195 503 minecraft:red_nether_bricks
fill 353 195 504 353 198 504 minecraft:pink_terracotta
setblock 354 195 502 minecraft:red_nether_bricks
fill 354 195 503 354 198 503 minecraft:pink_terracotta
setblock 355 195 501 minecraft:red_nether_bricks
fill 355 195 502 355 198 502 minecraft:pink_terracotta
setblock 356 195 465 minecraft:red_nether_bricks
fill 356 195 501 356 197 501 minecraft:pink_terracotta
setblock 357 195 464 minecraft:red_nether_bricks
fill 357 195 465 357 198 465 minecraft:pink_terracotta
setblock 357 195 504 minecraft:red_nether_bricks
fill 358 195 464 358 198 464 minecraft:pink_terracotta
setblock 358 195 503 minecraft:red_nether_bricks
fill 358 195 504 358 198 504 minecraft:pink_terracotta
setblock 359 195 502 minecraft:red_nether_bricks
fill 359 195 503 359 198 503 minecraft:pink_terracotta
fill 360 195 502 360 197 502 minecraft:pink_terracotta
setblock 362 195 464 minecraft:red_nether_bricks
setblock 362 195 504 minecraft:red_nether_bricks
setblock 363 195 503 minecraft:red_nether_bricks
fill 363 195 504 366 195 504 minecraft:pink_terracotta
setblock 364 195 464 minecraft:white_concrete
fill 364 195 503 367 195 503 minecraft:pink_terracotta
setblock 367 195 504 minecraft:red_nether_bricks
fill 368 195 481 368 195 482 minecraft:pink_terracotta
setblock 368 195 483 minecraft:red_nether_bricks
fill 368 195 484 368 198 484 minecraft:pink_terracotta
setblock 368 195 503 minecraft:red_nether_bricks
fill 368 195 504 368 198 504 minecraft:pink_terracotta
fill 369 195 464 370 196 464 minecraft:pink_terracotta
setblock 369 195 477 minecraft:red_nether_bricks
fill 369 195 478 369 198 478 minecraft:pink_terracotta
setblock 369 195 481 minecraft:pink_terracotta
setblock 369 195 482 minecraft:red_nether_bricks
fill 369 195 483 369 198 483 minecraft:pink_terracotta
fill 369 195 485 369 195 486 minecraft:pink_terracotta
setblock 369 195 487 minecraft:red_nether_bricks
fill 369 195 488 369 196 490 minecraft:pink_terracotta
setblock 369 195 497 minecraft:red_nether_bricks
fill 369 195 498 369 196 498 minecraft:pink_terracotta
setblock 369 195 501 minecraft:pink_terracotta
setblock 369 195 502 minecraft:red_nether_bricks
fill 369 195 503 369 198 503 minecraft:pink_terracotta
setblock 370 195 465 minecraft:pink_terracotta
setblock 370 195 476 minecraft:red_nether_bricks
fill 370 195 477 370 198 477 minecraft:pink_terracotta
setblock 370 195 481 minecraft:red_nether_bricks
fill 370 195 482 370 198 482 minecraft:pink_terracotta
setblock 370 195 485 minecraft:pink_terracotta
setblock 370 195 486 minecraft:red_nether_bricks
fill 370 195 487 370 198 487 minecraft:pink_terracotta
setblock 370 195 491 minecraft:red_nether_bricks
fill 370 195 492 370 198 492 minecraft:pink_terracotta
setblock 370 195 496 minecraft:red_nether_bricks
fill 370 195 497 370 198 497 minecraft:pink_terracotta
setblock 370 195 501 minecraft:red_nether_bricks
fill 370 195 502 370 198 502 minecraft:pink_terracotta
setblock 330 196 464 minecraft:pink_terracotta
setblock 330 196 465 minecraft:red_nether_bricks
fill 330 196 466 330 199 466 minecraft:pink_terracotta
setblock 330 196 470 minecraft:red_nether_bricks
fill 330 196 471 330 199 471 minecraft:pink_terracotta
setblock 330 196 475 minecraft:red_nether_bricks
fill 330 196 476 330 199 476 minecraft:pink_terracotta
setblock 330 196 480 minecraft:red_nether_bricks
fill 330 196 481 330 199 481 minecraft:pink_terracotta
setblock 330 196 485 minecraft:red_nether_bricks
fill 330 196 486 330 196 489 minecraft:pink_terracotta
setblock 330 196 490 minecraft:red_nether_bricks
fill 330 196 491 330 199 491 minecraft:pink_terracotta
setblock 330 196 496 minecraft:pink_terracotta
setblock 330 196 500 minecraft:red_nether_bricks
fill 330 196 501 330 199 501 minecraft:pink_terracotta
setblock 331 196 464 minecraft:red_nether_bricks
fill 331 196 465 334 196 465 minecraft:pink_terracotta
setblock 331 196 468 minecraft:pink_terracotta
setblock 331 196 469 minecraft:red_nether_bricks
fill 331 196 470 331 199 470 minecraft:pink_terracotta
setblock 331 196 474 minecraft:red_nether_bricks
fill 331 196 475 331 199 475 minecraft:pink_terracotta
setblock 331 196 479 minecraft:red_nether_bricks
fill 331 196 480 331 199 480 minecraft:pink_terracotta
setblock 331 196 484 minecraft:red_nether_bricks
fill 331 196 485 331 199 485 minecraft:pink_terracotta
setblock 331 196 489 minecraft:red_nether_bricks
setblock 331 196 500 minecraft:pink_terracotta
setblock 331 196 503 minecraft:pink_terracotta
setblock 331 196 504 minecraft:red_nether_bricks
fill 332 196 464 332 199 464 minecraft:pink_terracotta
fill 332 196 466 333 196 466 minecraft:pink_terracotta
setblock 332 196 474 minecraft:pink_terracotta
setblock 332 196 478 minecraft:red_nether_bricks
fill 332 196 479 332 199 479 minecraft:pink_terracotta
setblock 332 196 483 minecraft:red_nether_bricks
fill 332 196 484 332 199 484 minecraft:pink_terracotta
setblock 332 196 503 minecraft:red_nether_bricks
fill 332 196 504 332 199 504 minecraft:pink_terracotta
setblock 333 196 477 minecraft:red_nether_bricks
fill 333 196 478 333 197 478 minecraft:pink_terracotta
setblock 333 196 481 minecraft:pink_terracotta
setblock 333 196 482 minecraft:red_nether_bricks
fill 333 196 483 333 198 483 minecraft:pink_terracotta
fill 333 196 503 333 199 503 minecraft:pink_terracotta
setblock 334 196 466 minecraft:red_nether_bricks
setblock 334 196 502 minecraft:pink_terracotta
setblock 335 196 465 minecraft:red_nether_bricks
fill 335 196 466 335 199 466 minecraft:pink_terracotta
setblock 336 196 464 minecraft:red_nether_bricks
fill 336 196 465 336 199 465 minecraft:pink_terracotta
setblock 336 196 504 minecraft:red_nether_bricks
fill 337 196 464 337 199 464 minecraft:pink_terracotta
setblock 337 196 503 minecraft:red_nether_bricks
fill 337 196 504 337 199 504 minecraft:pink_terracotta
fill 338 196 503 338 198 503 minecraft:pink_terracotta
setblock 340 196 465 minecraft:red_nether_bricks
setblock 341 196 464 minecraft:red_nether_bricks
fill 341 196 465 341 199 465 minecraft:pink_terracotta
setblock 341 196 504 minecraft:red_nether_bricks
fill 342 196 464 345 196 464 minecraft:pink_terracotta
setblock 342 196 503 minecraft:red_nether_bricks
fill 342 196 504 342 199 504 minecraft:pink_terracotta
fill 343 196 503 346 196 503 minecraft:pink_terracotta
setblock 344 196 465 minecraft:pink_terracotta
setblock 345 196 465 minecraft:red_nether_bricks
setblock 346 196 464 minecraft:red_nether_bricks
fill 346 196 465 346 199 465 minecraft:pink_terracotta
setblock 346 196 504 minecraft:red_nether_bricks
fill 347 196 464 347 199 464 minecraft:pink_terracotta
setblock 347 196 503 minecraft:red_nether_bricks
fill 347 196 504 347 199 504 minecraft:pink_terracotta
setblock 348 196 502 minecraft:red_nether_bricks
fill 348 196 503 348 199 503 minecraft:pink_terracotta
setblock 349 196 465 minecraft:pink_terracotta
fill 349 196 502 349 199 502 minecraft:pink_terracotta
setblock 350 196 465 minecraft:red_nether_bricks
setblock 351 196 464 minecraft:red_nether_bricks
fill 351 196 465 351 198 466 minecraft:pink_terracotta
fill 351 196 501 353 196 501 minecraft:pink_terracotta
setblock 351 196 504 minecraft:red_nether_bricks
fill 352 196 464 352 199 464 minecraft:pink_terracotta
setblock 352 196 503 minecraft:red_nether_bricks
fill 352 196 504 352 199 504 minecraft:pink_terracotta
setblock 353 196 466 minecraft:pink_terracotta
setblock 353 196 502 minecraft:red_nether_bricks
fill 353 196 503 353 199 503 minecraft:pink_terracotta
setblock 354 196 466 minecraft:red_nether_bricks
setblock 354 196 501 minecraft:red_nether_bricks
fill 354 196 502 354 199 502 minecraft:pink_terracotta
setblock 355 196 465 minecraft:red_nether_bricks
fill 355 196 501 355 198 501 minecraft:pink_terracotta
setblock 356 196 464 minecraft:red_nether_bricks
fill 356 196 465 356 199 465 minecraft:pink_terracotta
setblock 356 196 504 minecraft:red_nether_bricks
fill 357 196 464 357 199 464 minecraft:pink_terracotta
setblock 357 196 503 minecraft:red_nether_bricks
fill 357 196 504 357 199 504 minecraft:pink_terracotta
setblock 358 196 502 minecraft:red_nether_bricks
fill 358 196 503 358 199 503 minecraft:pink_terracotta
fill 359 196 502 359 197 502 minecraft:pink_terracotta
setblock 361 196 464 minecraft:red_nether_bricks
setblock 361 196 504 minecraft:red_nether_bricks
setblock 362 196 464 minecraft:pink_terracotta
setblock 362 196 503 minecraft:red_nether_bricks
fill 362 196 504 365 196 504 minecraft:pink_terracotta
fill 363 196 503 366 196 503 minecraft:pink_terracotta
setblock 366 196 504 minecraft:red_nether_bricks
setblock 367 196 503 minecraft:red_nether_bricks
fill 367 196 504 367 199 504 minecraft:pink_terracotta
fill 368 196 464 368 198 464 minecraft:pink_terracotta
setblock 368 196 481 minecraft:pink_terracotta
setblock 368 196 482 minecraft:red_nether_bricks
fill 368 196 483 368 199 483 minecraft:pink_terracotta
fill 368 196 485 368 196 486 minecraft:pink_terracotta
fill 368 196 503 368 197 503 minecraft:pink_terracotta
fill 369 196 477 369 197 477 minecraft:pink_terracotta
setblock 369 196 481 minecraft:red_nether_bricks
fill 369 196 482 369 199 482 minecraft:pink_terracotta
setblock 369 196 485 minecraft:pink_terracotta
setblock 369 196 486 minecraft:red_nether_bricks
fill 369 196 487 369 199 487 minecraft:pink_terracotta
setblock 369 196 501 minecraft:red_nether_bricks
fill 369 196 502 369 198 502 minecraft:pink_terracotta
setblock 370 196 465 minecraft:red_nether_bricks
fill 370 196 466 370 199 466 minecraft:pink_terracotta
fill 370 196 473 370 197 473 minecraft:pink_terracotta
setblock 370 196 475 minecraft:red_nether_bricks
fill 370 196 476 370 199 476 minecraft:pink_terracotta
setblock 370 196 480 minecraft:red_nether_bricks
fill 370 196 481 370 199 481 minecraft:pink_terracotta
setblock 370 196 485 minecraft:red_nether_bricks
fill 370 196 486 370 199 486 minecraft:pink_terracotta
setblock 370 196 490 minecraft:red_nether_bricks
fill 370 196 491 370 199 491 minecraft:pink_terracotta
setblock 370 196 495 minecraft:red_nether_bricks
fill 370 196 496 370 199 496 minecraft:pink_terracotta
setblock 370 196 500 minecraft:red_nether_bricks
fill 370 196 501 370 199 501 minecraft:pink_terracotta
setblock 330 197 464 minecraft:red_nether_bricks
fill 330 197 465 333 197 465 minecraft:pink_terracotta
setblock 330 197 468 minecraft:pink_terracotta
setblock 330 197 469 minecraft:red_nether_bricks
fill 330 197 470 330 200 470 minecraft:pink_terracotta
setblock 330 197 474 minecraft:red_nether_bricks
fill 330 197 475 330 200 475 minecraft:pink_terracotta
setblock 330 197 479 minecraft:red_nether_bricks
fill 330 197 480 330 200 480 minecraft:pink_terracotta
setblock 330 197 484 minecraft:red_nether_bricks
fill 330 197 485 330 197 488 minecraft:pink_terracotta
setblock 330 197 489 minecraft:red_nether_bricks
fill 330 197 490 330 200 490 minecraft:pink_terracotta
setblock 330 197 497 minecraft:white_concrete
setblock 330 197 499 minecraft:red_nether_bricks
fill 330 197 500 330 198 500 minecraft:pink_terracotta
fill 330 197 502 330 197 503 minecraft:pink_terracotta
setblock 330 197 504 minecraft:red_nether_bricks
fill 331 197 464 331 200 464 minecraft:pink_terracotta
setblock 331 197 468 minecraft:red_nether_bricks
fill 331 197 469 331 200 469 minecraft:pink_terracotta
setblock 331 197 473 minecraft:red_nether_bricks
fill 331 197 474 331 200 474 minecraft:pink_terracotta
setblock 331 197 478 minecraft:red_nether_bricks
fill 331 197 479 331 200 479 minecraft:pink_terracotta
setblock 331 197 483 minecraft:red_nether_bricks
fill 331 197 484 331 200 484 minecraft:pink_terracotta
setblock 331 197 487 minecraft:pink_terracotta
setblock 331 197 488 minecraft:red_nether_bricks
fill 331 197 489 331 200 489 minecraft:pink_terracotta
setblock 331 197 503 minecraft:red_nether_bricks
fill 331 197 504 331 200 504 minecraft:pink_terracotta
setblock 332 197 466 minecraft:pink_terracotta
setblock 332 197 467 minecraft:red_nether_bricks
setblock 332 197 477 minecraft:red_nether_bricks
fill 332 197 478 332 199 478 minecraft:pink_terracotta
setblock 332 197 482 minecraft:red_nether_bricks
fill 332 197 483 332 200 483 minecraft:pink_terracotta
setblock 332 197 487 minecraft:red_nether_bricks
fill 332 197 503 332 199 503 minecraft:pink_terracotta
setblock 333 197 466 minecraft:red_nether_bricks
setblock 333 197 481 minecraft:red_nether_bricks
fill 333 197 482 333 198 482 minecraft:pink_terracotta
setblock 334 197 465 minecraft:red_nether_bricks
fill 334 197 466 334 200 466 minecraft:pink_terracotta
setblock 335 197 464 minecraft:red_nether_bricks
fill 335 197 465 335 200 465 minecraft:pink_terracotta
setblock 335 197 504 minecraft:red_nether_bricks
fill 336 197 464 336 200 464 minecraft:pink_terracotta
setblock 336 197 503 minecraft:red_nether_bricks
fill 336 197 504 336 200 504 minecraft:pink_terracotta
setblock 337 197 466 minecraft:pink_terracotta
fill 337 197 503 337 198 503 minecraft:pink_terracotta
setblock 338 197 466 minecraft:red_nether_bricks
setblock 339 197 465 minecraft:red_nether_bricks
setblock 340 197 464 minecraft:red_nether_bricks
fill 340 197 465 340 200 465 minecraft:pink_terracotta
setblock 340 197 504 minecraft:red_nether_bricks
fill 341 197 464 344 197 464 minecraft:pink_terracotta
fill 341 197 504 341 200 504 minecraft:pink_terracotta
setblock 344 197 465 minecraft:red_nether_bricks
fill 344 197 503 345 197 503 minecraft:pink_terracotta
setblock 345 197 464 minecraft:red_nether_bricks
fill 345 197 465 345 200 465 minecraft:pink_terracotta
setblock 345 197 504 minecraft:red_nether_bricks
fill 346 197 464 346 200 464 minecraft:pink_terracotta
setblock 346 197 503 minecraft:red_nether_bricks
fill 346 197 504 346 200 504 minecraft:pink_terracotta
fill 347 197 503 347 200 503 minecraft:pink_terracotta
fill 348 197 502 348 198 502 minecraft:pink_terracotta
setblock 349 197 465 minecraft:red_nether_bricks
setblock 350 197 464 minecraft:red_nether_bricks
fill 350 197 465 350 199 466 minecraft:pink_terracotta
setblock 350 197 504 minecraft:red_nether_bricks
fill 351 197 464 351 200 464 minecraft:pink_terracotta
fill 351 197 501 352 197 501 minecraft:pink_terracotta
setblock 351 197 503 minecraft:red_nether_bricks
fill 351 197 504 351 200 504 minecraft:pink_terracotta
setblock 352 197 502 minecraft:red_nether_bricks
fill 352 197 503 352 200 503 minecraft:pink_terracotta
setblock 353 197 466 minecraft:red_nether_bricks
setblock 353 197 501 minecraft:red_nether_bricks
fill 353 197 502 353 200 502 minecraft:pink_terracotta
setblock 354 197 465 minecraft:red_nether_bricks
setblock 354 197 466 minecraft:pink_terracotta
fill 354 197 501 354 198 501 minecraft:pink_terracotta
setblock 355 197 464 minecraft:red_nether_bricks
fill 355 197 465 355 200 465 minecraft:pink_terracotta
setblock 355 197 504 minecraft:red_nether_bricks
fill 356 197 464 356 200 464 minecraft:pink_terracotta
setblock 356 197 503 minecraft:red_nether_bricks
fill 356 197 504 356 200 504 minecraft:pink_terracotta
setblock 357 197 502 minecraft:red_nether_bricks
fill 357 197 503 357 200 503 minecraft:pink_terracotta
fill 358 197 502 358 198 502 minecraft:pink_terracotta
setblock 360 197 464 minecraft:red_nether_bricks
setblock 360 197 504 minecraft:red_nether_bricks
setblock 361 197 464 minecraft:pink_terracotta
setblock 361 197 503 minecraft:red_nether_bricks
fill 361 197 504 364 197 504 minecraft:pink_terracotta
fill 362 197 503 363 197 503 minecraft:pink_terracotta
setblock 365 197 504 minecraft:red_nether_bricks
fill 366 197 504 366 200 504 minecraft:pink_terracotta
setblock 367 197 503 minecraft:pink_terracotta
setblock 368 197 481 minecraft:red_nether_bricks
fill 368 197 482 368 200 482 minecraft:pink_terracotta
setblock 368 197 485 minecraft:pink_terracotta
setblock 368 197 486 minecraft:red_nether_bricks
setblock 369 197 464 minecraft:pink_terracotta
setblock 369 197 480 minecraft:red_nether_bricks
fill 369 197 481 369 200 481 minecraft:pink_terracotta
setblock 369 197 485 minecraft:red_nether_bricks
fill 369 197 486 369 200 486 minecraft:pink_terracotta
fill 369 197 488 369 197 489 minecraft:pink_terracotta
setblock 369 197 490 minecraft:red_nether_bricks
fill 369 197 491 369 200 491 minecraft:pink_terracotta
setblock 369 197 500 minecraft:red_nether_bricks
setblock 369 197 501 minecraft:pink_terracotta
setblock 370 197 464 minecraft:red_nether_bricks
fill 370 197 465 370 200 465 minecraft:pink_terracotta
fill 370 197 467 370 198 467 minecraft:pink_terracotta
setblock 370 197 471 minecraft:white_concrete
setblock 370 197 474 minecraft:red_nether_bricks
fill 370 197 475 370 200 475 minecraft:pink_terracotta
setblock 370 197 479 minecraft:red_nether_bricks
fill 370 197 480 370 200 480 minecraft:pink_terracotta
setblock 370 197 484 minecraft:red_nether_bricks
fill 370 197 485 370 200 485 minecraft:pink_terracotta
setblock 370 197 489 minecraft:red_nether_bricks
fill 370 197 490 370 200 490 minecraft:pink_terracotta
setblock 370 197 494 minecraft:red_nether_bricks
fill 370 197 495 370 200 495 minecraft:pink_terracotta
setblock 370 197 499 minecraft:red_nether_bricks
fill 370 197 500 370 200 500 minecraft:pink_terracotta
setblock 370 197 504 minecraft:red_nether_bricks
fill 330 198 464 330 200 465 minecraft:pink_terracotta
setblock 330 198 467 minecraft:pink_terracotta
setblock 330 198 468 minecraft:red_nether_bricks
fill 330 198 469 330 201 469 minecraft:pink_terracotta
setblock 330 198 473 minecraft:red_nether_bricks
fill 330 198 474 330 201 474 minecraft:pink_terracotta
setblock 330 198 478 minecraft:red_nether_bricks
fill 330 198 479 330 201 479 minecraft:pink_terracotta
setblock 330 198 483 minecraft:red_nether_bricks
fill 330 198 484 330 198 487 minecraft:pink_terracotta
setblock 330 198 488 minecraft:red_nether_bricks
fill 330 198 489 330 201 489 minecraft:pink_terracotta
setblock 330 198 499 minecraft:pink_terracotta
setblock 330 198 502 minecraft:pink_terracotta
setblock 330 198 503 minecraft:red_nether_bricks
fill 330 198 504 330 201 504 minecraft:pink_terracotta
fill 331 198 465 332 198 465 minecraft:pink_terracotta
setblock 331 198 467 minecraft:red_nether_bricks
fill 331 198 468 332 200 468 minecraft:pink_terracotta
setblock 331 198 472 minecraft:red_nether_bricks
fill 331 198 473 331 201 473 minecraft:pink_terracotta
setblock 331 198 477 minecraft:red_nether_bricks
fill 331 198 478 331 201 478 minecraft:pink_terracotta
setblock 331 198 482 minecraft:red_nether_bricks
fill 331 198 483 331 201 483 minecraft:pink_terracotta
setblock 331 198 487 minecraft:red_nether_bricks
fill 331 198 488 331 201 488 minecraft:pink_terracotta
setblock 331 198 502 minecraft:red_nether_bricks
fill 331 198 503 331 199 503 minecraft:pink_terracotta
setblock 332 198 466 minecraft:red_nether_bricks
fill 332 198 467 332 201 467 minecraft:pink_terracotta
setblock 332 198 476 minecraft:red_nether_bricks
setblock 332 198 477 minecraft:pink_terracotta
setblock 332 198 481 minecraft:red_nether_bricks
fill 332 198 482 332 201 482 minecraft:pink_terracotta
setblock 332 198 485 minecraft:pink_terracotta
setblock 332 198 486 minecraft:red_nether_bricks
fill 332 198 487 332 200 487 minecraft:pink_terracotta
setblock 333 198 465 minecraft:red_nether_bricks
fill 333 198 466 333 201 466 minecraft:pink_terracotta
setblock 333 198 480 minecraft:red_nether_bricks
setblock 333 198 481 minecraft:pink_terracotta
setblock 334 198 464 minecraft:red_nether_bricks
fill 334 198 465 334 201 465 minecraft:pink_terracotta
setblock 334 198 504 minecraft:red_nether_bricks
fill 335 198 464 335 201 464 minecraft:pink_terracotta
setblock 335 198 503 minecraft:red_nether_bricks
fill 335 198 504 335 201 504 minecraft:pink_terracotta
fill 336 198 503 336 199 503 minecraft:pink_terracotta
setblock 337 198 466 minecraft:red_nether_bricks
setblock 338 198 465 minecraft:red_nether_bricks
setblock 339 198 464 minecraft:red_nether_bricks
fill 339 198 465 339 201 465 minecraft:pink_terracotta
setblock 339 198 504 minecraft:red_nether_bricks
fill 340 198 464 343 198 464 minecraft:pink_terracotta
fill 340 198 504 340 201 504 minecraft:pink_terracotta
setblock 343 198 465 minecraft:red_nether_bricks
setblock 344 198 464 minecraft:red_nether_bricks
fill 344 198 465 344 201 465 minecraft:pink_terracotta
setblock 344 198 504 minecraft:red_nether_bricks
fill 345 198 464 345 201 464 minecraft:pink_terracotta
setblock 345 198 503 minecraft:red_nether_bricks
fill 345 198 504 345 201 504 minecraft:pink_terracotta
fill 346 198 503 346 201 503 minecraft:pink_terracotta
setblock 348 198 465 minecraft:red_nether_bricks
setblock 349 198 464 minecraft:red_nether_bricks
fill 349 198 465 349 201 465 minecraft:pink_terracotta
setblock 349 198 504 minecraft:red_nether_bricks
fill 350 198 464 350 201 464 minecraft:pink_terracotta
setblock 350 198 503 minecraft:red_nether_bricks
fill 350 198 504 350 201 504 minecraft:pink_terracotta
setblock 351 198 502 minecraft:red_nether_bricks
fill 351 198 503 351 201 503 minecraft:pink_terracotta
setblock 352 198 465 minecraft:pink_terracotta
setblock 352 198 466 minecraft:red_nether_bricks
setblock 352 198 501 minecraft:red_nether_bricks
fill 352 198 502 352 201 502 minecraft:pink_terracotta
setblock 353 198 465 minecraft:red_nether_bricks
setblock 353 198 466 minecraft:pink_terracotta
setblock 353 198 501 minecraft:pink_terracotta
setblock 354 198 464 minecraft:red_nether_bricks
fill 354 198 465 354 201 465 minecraft:pink_terracotta
setblock 354 198 504 minecraft:red_nether_bricks
fill 355 198 464 355 201 464 minecraft:pink_terracotta
setblock 355 198 503 minecraft:red_nether_bricks
fill 355 198 504 355 201 504 minecraft:pink_terracotta
setblock 356 198 502 minecraft:red_nether_bricks
fill 356 198 503 356 201 503 minecraft:pink_terracotta
setblock 357 198 502 minecraft:pink_terracotta
setblock 359 198 464 minecraft:red_nether_bricks
setblock 359 198 504 minecraft:red_nether_bricks
setblock 360 198 464 minecraft:pink_terracotta
setblock 360 198 503 minecraft:red_nether_bricks
fill 360 198 504 363 198 504 minecraft:pink_terracotta
setblock 361 198 503 minecraft:pink_terracotta
setblock 364 198 504 minecraft:red_nether_bricks
fill 365 198 504 365 199 504 minecraft:pink_terracotta
setblock 368 198 481 minecraft:pink_terracotta
setblock 368 198 485 minecraft:red_nether_bricks
fill 368 198 486 368 200 487 minecraft:pink_terracotta
setblock 369 198 464 minecraft:red_nether_bricks
setblock 369 198 479 minecraft:red_nether_bricks
fill 369 198 480 369 201 480 minecraft:pink_terracotta
setblock 369 198 484 minecraft:red_nether_bricks
fill 369 198 485 369 201 485 minecraft:pink_terracotta
setblock 369 198 488 minecraft:pink_terracotta
setblock 369 198 489 minecraft:red_nether_bricks
fill 369 198 490 369 201 490 minecraft:pink_terracotta
setblock 369 198 504 minecraft:red_nether_bricks
fill 370 198 464 370 201 464 minecraft:pink_terracotta
setblock 370 198 468 minecraft:red_nether_bricks
fill 370 198 474 370 201 474 minecraft:pink_terracotta
setblock 370 198 478 minecraft:red_nether_bricks
fill 370 198 479 370 201 479 minecraft:pink_terracotta
setblock 370 198 483 minecraft:red_nether_bricks
fill 370 198 484 370 201 484 minecraft:pink_terracotta
setblock 370 198 488 minecraft:red_nether_bricks
fill 370 198 489 370 201 489 minecraft:pink_terracotta
setblock 370 198 493 minecraft:red_nether_bricks
fill 370 198 494 370 201 494 minecraft:pink_terracotta
setblock 370 198 498 minecraft:red_nether_bricks
fill 370 198 499 370 200 499 minecraft:pink_terracotta
setblock 370 198 503 minecraft:red_nether_bricks
fill 370 198 504 370 201 504 minecraft:pink_terracotta
setblock 330 199 467 minecraft:red_nether_bricks
fill 330 199 468 330 202 468 minecraft:pink_terracotta
setblock 330 199 472 minecraft:red_nether_bricks
fill 330 199 473 330 202 473 minecraft:pink_terracotta
setblock 330 199 477 minecraft:red_nether_bricks
fill 330 199 478 330 202 478 minecraft:pink_terracotta
setblock 330 199 482 minecraft:red_nether_bricks
fill 330 199 483 330 199 486 minecraft:pink_terracotta
setblock 330 199 487 minecraft:red_nether_bricks
fill 330 199 488 330 202 488 minecraft:pink_terracotta
setblock 330 199 492 minecraft:red_nether_bricks
setblock 330 199 502 minecraft:red_nether_bricks
fill 330 199 503 330 202 503 minecraft:pink_terracotta
setblock 331 199 465 minecraft:pink_terracotta
setblock 331 199 466 minecraft:red_nether_bricks
fill 331 199 467 331 202 467 minecraft:pink_terracotta
setblock 331 199 471 minecraft:red_nether_bricks
fill 331 199 472 331 202 472 minecraft:pink_terracotta
setblock 331 199 476 minecraft:red_nether_bricks
fill 331 199 477 331 202 477 minecraft:pink_terracotta
setblock 331 199 481 minecraft:red_nether_bricks
fill 331 199 482 331 202 482 minecraft:pink_terracotta
setblock 331 199 486 minecraft:red_nether_bricks
fill 331 199 487 331 202 487 minecraft:pink_terracotta
setblock 332 199 465 minecraft:red_nether_bricks
fill 332 199 466 332 202 466 minecraft:pink_terracotta
setblock 332 199 474 minecraft:light[level=12]
setblock 332 199 480 minecraft:red_nether_bricks
fill 332 199 481 332 200 481 minecraft:pink_terracotta
setblock 332 199 485 minecraft:red_nether_bricks
fill 332 199 486 332 201 486 minecraft:pink_terracotta
setblock 332 199 490 minecraft:light[level=12]
setblock 332 199 498 minecraft:light[level=12]
setblock 333 199 464 minecraft:red_nether_bricks
fill 333 199 465 333 202 465 minecraft:pink_terracotta
setblock 333 199 504 minecraft:red_nether_bricks
fill 334 199 464 334 202 464 minecraft:pink_terracotta
setblock 334 199 503 minecraft:red_nether_bricks
fill 334 199 504 334 202 504 minecraft:pink_terracotta
setblock 335 199 503 minecraft:pink_terracotta
setblock 336 199 466 minecraft:red_nether_bricks
setblock 337 199 465 minecraft:red_nether_bricks
setblock 337 199 466 minecraft:pink_terracotta
setblock 338 199 464 minecraft:red_nether_bricks
fill 338 199 465 338 202 465 minecraft:pink_terracotta
setblock 338 199 504 minecraft:red_nether_bricks
fill 339 199 464 342 199 464 minecraft:pink_terracotta
fill 339 199 504 339 201 504 minecraft:pink_terracotta
setblock 340 199 466 minecraft:light[level=12]
setblock 340 199 474 minecraft:light[level=12]
setblock 340 199 482 minecraft:light[level=12]
setblock 340 199 490 minecraft:light[level=12]
setblock 340 199 498 minecraft:light[level=12]
setblock 342 199 465 minecraft:red_nether_bricks
setblock 343 199 464 minecraft:red_nether_bricks
fill 343 199 465 343 202 465 minecraft:pink_terracotta
setblock 343 199 504 minecraft:red_nether_bricks
fill 344 199 464 344 202 464 minecraft:pink_terracotta
fill 344 199 504 344 202 504 minecraft:pink_terracotta
setblock 345 199 503 minecraft:pink_terracotta
setblock 347 199 465 minecraft:red_nether_bricks
setblock 348 199 464 minecraft:red_nether_bricks
fill 348 199 465 348 202 465 minecraft:pink_terracotta
setblock 348 199 466 minecraft:light[level=12]
setblock 348 199 474 minecraft:light[level=12]
setblock 348 199 482 minecraft:light[level=12]
setblock 348 199 490 minecraft:light[level=12]
setblock 348 199 498 minecraft:light[level=12]
setblock 348 199 504 minecraft:red_nether_bricks
fill 349 199 464 349 202 464 minecraft:pink_terracotta
setblock 349 199 503 minecraft:red_nether_bricks
fill 349 199 504 349 202 504 minecraft:pink_terracotta
setblock 350 199 502 minecraft:red_nether_bricks
fill 350 199 503 350 202 503 minecraft:pink_terracotta
setblock 351 199 465 minecraft:pink_terracotta
setblock 351 199 466 minecraft:red_nether_bricks
fill 351 199 502 351 202 502 minecraft:pink_terracotta
setblock 352 199 465 minecraft:red_nether_bricks
fill 352 199 466 352 200 466 minecraft:pink_terracotta
setblock 353 199 464 minecraft:red_nether_bricks
fill 353 199 465 353 202 465 minecraft:pink_terracotta
setblock 353 199 504 minecraft:red_nether_bricks
fill 354 199 464 354 202 464 minecraft:pink_terracotta
setblock 354 199 503 minecraft:red_nether_bricks
fill 354 199 504 354 202 504 minecraft:pink_terracotta
setblock 355 199 502 minecraft:red_nether_bricks
fill 355 199 503 355 202 503 minecraft:pink_terracotta
setblock 356 199 466 minecraft:light[level=12]
setblock 356 199 474 minecraft:light[level=12]
setblock 356 199 482 minecraft:light[level=12]
setblock 356 199 490 minecraft:light[level=12]
setblock 356 199 498 minecraft:light[level=12]
setblock 356 199 502 minecraft:pink_terracotta
setblock 358 199 464 minecraft:red_nether_bricks
setblock 358 199 504 minecraft:red_nether_bricks
setblock 359 199 464 minecraft:pink_terracotta
setblock 359 199 503 minecraft:red_nether_bricks
fill 359 199 504 362 199 504 minecraft:pink_terracotta
setblock 363 199 504 minecraft:red_nether_bricks
setblock 364 199 466 minecraft:light[level=12]
setblock 364 199 474 minecraft:light[level=12]
setblock 364 199 482 minecraft:light[level=12]
setblock 364 199 490 minecraft:light[level=12]
setblock 364 199 498 minecraft:light[level=12]
setblock 364 199 504 minecraft:pink_terracotta
setblock 365 199 464 minecraft:white_concrete
setblock 367 199 464 minecraft:pink_terracotta
setblock 368 199 464 minecraft:red_nether_bricks
setblock 368 199 484 minecraft:red_nether_bricks
fill 368 199 485 368 202 485 minecraft:pink_terracotta
setblock 368 199 488 minecraft:pink_terracotta
setblock 368 199 504 minecraft:red_nether_bricks
fill 369 199 464 369 202 464 minecraft:pink_terracotta
setblock 369 199 478 minecraft:red_nether_bricks
fill 369 199 479 369 202 479 minecraft:pink_terracotta
setblock 369 199 483 minecraft:red_nether_bricks
fill 369 199 484 369 202 484 minecraft:pink_terracotta
setblock 369 199 488 minecraft:red_nether_bricks
fill 369 199 489 369 202 489 minecraft:pink_terracotta
fill 369 199 504 369 202 504 minecraft:pink_terracotta
setblock 370 199 467 minecraft:red_nether_bricks
fill 370 199 468 370 200 470 minecraft:pink_terracotta
fill 370 199 473 370 202 473 minecraft:pink_terracotta
setblock 370 199 477 minecraft:red_nether_bricks
fill 370 199 478 370 202 478 minecraft:pink_terracotta
setblock 370 199 482 minecraft:red_nether_bricks
fill 370 199 483 370 202 483 minecraft:pink_terracotta
setblock 370 199 487 minecraft:red_nether_bricks
fill 370 199 488 370 202 488 minecraft:pink_terracotta
setblock 370 199 492 minecraft:red_nether_bricks
fill 370 199 493 370 202 493 minecraft:pink_terracotta
setblock 370 199 497 minecraft:red_nether_bricks
setblock 370 199 498 minecraft:pink_terracotta
setblock 370 199 502 minecraft:red_nether_bricks
fill 370 199 503 370 202 503 minecraft:pink_terracotta
setblock 330 200 466 minecraft:red_nether_bricks
fill 330 200 467 330 203 467 minecraft:pink_terracotta
setblock 330 200 471 minecraft:red_nether_bricks
fill 330 200 472 330 203 472 minecraft:pink_terracotta
setblock 330 200 476 minecraft:red_nether_bricks
fill 330 200 477 330 203 477 minecraft:pink_terracotta
setblock 330 200 481 minecraft:red_nether_bricks
fill 330 200 482 330 200 485 minecraft:pink_terracotta
setblock 330 200 486 minecraft:red_nether_bricks
fill 330 200 487 330 203 487 minecraft:pink_terracotta
setblock 330 200 491 minecraft:red_nether_bricks
fill 330 200 492 330 203 492 minecraft:pink_terracotta
setblock 330 200 496 minecraft:white_concrete
setblock 330 200 501 minecraft:red_nether_bricks
fill 330 200 502 330 201 502 minecraft:pink_terracotta
setblock 331 200 465 minecraft:red_nether_bricks
fill 331 200 466 331 203 466 minecraft:pink_terracotta
setblock 331 200 470 minecraft:red_nether_bricks
fill 331 200 471 331 203 471 minecraft:pink_terracotta
setblock 331 200 475 minecraft:red_nether_bricks
fill 331 200 476 331 203 476 minecraft:pink_terracotta
setblock 331 200 480 minecraft:red_nether_bricks
fill 331 200 481 331 203 481 minecraft:pink_terracotta
setblock 331 200 485 minecraft:red_nether_bricks
fill 331 200 486 331 203 486 minecraft:pink_terracotta
setblock 332 200 464 minecraft:red_nether_bricks
fill 332 200 465 332 203 465 minecraft:pink_terracotta
setblock 332 200 469 minecraft:red_nether_bricks
setblock 332 200 480 minecraft:pink_terracotta
setblock 332 200 484 minecraft:red_nether_bricks
fill 332 200 485 332 202 485 minecraft:pink_terracotta
setblock 332 200 504 minecraft:red_nether_bricks
fill 333 200 464 333 203 464 minecraft:pink_terracotta
fill 333 200 504 333 203 504 minecraft:pink_terracotta
setblock 335 200 466 minecraft:red_nether_bricks
setblock 336 200 465 minecraft:red_nether_bricks
fill 336 200 466 336 201 466 minecraft:pink_terracotta
setblock 337 200 464 minecraft:red_nether_bricks
fill 337 200 465 337 203 465 minecraft:pink_terracotta
setblock 337 200 504 minecraft:red_nether_bricks
fill 338 200 464 341 200 464 minecraft:pink_terracotta
fill 338 200 504 338 201 504 minecraft:pink_terracotta
setblock 341 200 465 minecraft:red_nether_bricks
setblock 342 200 464 minecraft:red_nether_bricks
fill 342 200 465 342 203 465 minecraft:pink_terracotta
setblock 342 200 504 minecraft:red_nether_bricks
fill 343 200 464 343 203 464 minecraft:pink_terracotta
fill 343 200 504 343 203 504 minecraft:pink_terracotta
schedule function dropper:buildpart/115_7 1t
