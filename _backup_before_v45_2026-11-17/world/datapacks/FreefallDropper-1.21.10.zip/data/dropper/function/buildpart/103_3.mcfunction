fill 339 176 438 341 176 438 minecraft:white_concrete
fill 339 176 448 342 176 448 minecraft:white_concrete
fill 340 176 425 340 176 427 minecraft:white_concrete
fill 340 176 435 340 177 435 minecraft:white_concrete
fill 340 176 437 341 176 437 minecraft:white_concrete
fill 340 176 445 345 176 445 minecraft:white_concrete
fill 340 176 449 342 176 449 minecraft:white_concrete
fill 341 176 424 341 176 426 minecraft:white_concrete
setblock 341 176 436 minecraft:white_concrete
setblock 341 176 450 minecraft:white_concrete
fill 342 176 424 342 176 425 minecraft:white_concrete
fill 342 176 435 342 176 441 minecraft:red_concrete
fill 343 176 423 343 176 424 minecraft:white_concrete
fill 343 176 434 343 177 435 minecraft:yellow_concrete
fill 343 176 437 343 177 437 minecraft:yellow_concrete
fill 343 176 439 343 177 440 minecraft:yellow_concrete
setblock 343 176 442 minecraft:red_concrete
fill 343 176 451 348 176 451 minecraft:white_concrete
setblock 344 176 423 minecraft:white_concrete
fill 344 176 432 345 177 432 minecraft:yellow_concrete
setblock 344 176 433 minecraft:red_concrete
setblock 344 176 435 minecraft:yellow_concrete
setblock 344 176 439 minecraft:yellow_concrete
fill 344 176 442 345 177 442 minecraft:yellow_concrete
setblock 344 176 443 minecraft:red_concrete
fill 344 176 457 345 176 457 minecraft:red_concrete
fill 345 176 417 346 176 417 minecraft:red_concrete
setblock 345 176 422 minecraft:white_concrete
setblock 345 176 433 minecraft:yellow_concrete
setblock 345 176 441 minecraft:yellow_concrete
setblock 345 176 444 minecraft:red_concrete
fill 345 176 452 347 176 452 minecraft:white_concrete
fill 346 176 431 347 177 431 minecraft:yellow_concrete
setblock 346 176 432 minecraft:red_concrete
fill 346 176 443 347 177 443 minecraft:yellow_concrete
setblock 346 176 445 minecraft:red_concrete
setblock 347 176 430 minecraft:white_concrete
fill 347 176 446 348 177 446 minecraft:red_concrete
fill 348 176 430 348 176 431 minecraft:red_concrete
fill 349 176 430 349 177 430 minecraft:yellow_concrete
fill 349 176 431 352 176 431 minecraft:red_concrete
fill 349 176 444 349 177 444 minecraft:yellow_concrete
setblock 350 176 430 minecraft:red_concrete
fill 351 176 430 351 177 430 minecraft:yellow_concrete
fill 351 176 444 351 177 444 minecraft:yellow_concrete
fill 351 176 446 352 176 446 minecraft:red_concrete
fill 351 176 457 352 176 457 minecraft:red_concrete
fill 352 176 417 353 176 417 minecraft:red_concrete
setblock 352 176 430 minecraft:red_concrete
setblock 353 176 430 minecraft:white_concrete
fill 353 176 431 354 177 431 minecraft:yellow_concrete
fill 353 176 432 354 176 432 minecraft:red_concrete
fill 353 176 443 353 177 443 minecraft:yellow_concrete
setblock 353 176 445 minecraft:red_concrete
setblock 353 176 446 minecraft:white_concrete
fill 354 176 423 357 176 423 minecraft:white_concrete
fill 354 176 443 354 177 443 minecraft:red_concrete
fill 354 176 444 354 179 445 minecraft:white_concrete
setblock 355 176 422 minecraft:white_concrete
fill 355 176 431 360 176 431 minecraft:white_concrete
fill 355 176 432 355 176 433 minecraft:yellow_concrete
fill 355 176 441 360 176 442 minecraft:gray_concrete
setblock 355 176 444 minecraft:red_concrete
fill 356 176 432 356 178 432 minecraft:yellow_concrete
fill 356 176 433 356 176 434 minecraft:red_concrete
fill 356 176 435 357 176 435 minecraft:yellow_concrete
fill 356 176 439 357 176 439 minecraft:yellow_concrete
setblock 356 176 443 minecraft:red_concrete
fill 357 176 432 358 176 433 minecraft:white_concrete
fill 357 176 434 357 178 434 minecraft:yellow_concrete
setblock 357 176 436 minecraft:red_concrete
fill 357 176 437 357 177 437 minecraft:yellow_concrete
fill 357 176 438 358 176 438 minecraft:red_concrete
fill 357 176 440 357 178 440 minecraft:yellow_concrete
fill 358 176 427 362 176 427 minecraft:white_concrete
fill 358 176 436 363 176 436 minecraft:white_concrete
setblock 358 176 437 minecraft:red_concrete
setblock 358 176 439 minecraft:red_concrete
setblock 358 176 440 minecraft:white_concrete
fill 358 176 457 359 176 457 minecraft:red_concrete
fill 359 176 417 360 176 417 minecraft:red_concrete
fill 359 176 426 361 176 426 minecraft:white_concrete
fill 359 176 432 359 178 432 minecraft:white_concrete
fill 359 176 437 361 176 438 minecraft:white_concrete
setblock 359 176 450 minecraft:white_concrete
setblock 360 176 425 minecraft:white_concrete
fill 360 176 433 365 176 433 minecraft:white_concrete
setblock 360 176 449 minecraft:white_concrete
fill 361 176 432 365 176 432 minecraft:white_concrete
fill 361 176 440 365 176 442 minecraft:white_concrete
setblock 361 176 448 minecraft:white_concrete
fill 362 176 431 364 176 431 minecraft:white_concrete
fill 362 176 437 362 178 437 minecraft:white_concrete
fill 362 176 439 365 176 439 minecraft:white_concrete
setblock 362 176 447 minecraft:white_concrete
fill 363 176 430 364 176 430 minecraft:white_concrete
fill 363 176 438 365 176 438 minecraft:white_concrete
setblock 363 176 446 minecraft:white_concrete
fill 364 176 437 365 176 437 minecraft:white_concrete
setblock 365 176 436 minecraft:white_concrete
fill 365 176 457 366 176 457 minecraft:red_concrete
fill 366 176 417 367 176 417 minecraft:red_concrete
fill 370 176 420 370 176 421 minecraft:red_concrete
fill 370 176 427 370 176 428 minecraft:red_concrete
fill 370 176 434 370 176 435 minecraft:red_concrete
fill 370 176 441 370 176 442 minecraft:red_concrete
fill 370 176 448 370 176 449 minecraft:red_concrete
fill 370 176 455 370 176 456 minecraft:red_concrete
setblock 330 177 417 minecraft:red_concrete
fill 330 177 422 330 226 422 minecraft:red_concrete
setblock 330 177 424 minecraft:red_concrete
fill 330 177 429 330 226 429 minecraft:red_concrete
setblock 330 177 431 minecraft:red_concrete
fill 330 177 436 330 226 436 minecraft:red_concrete
setblock 330 177 438 minecraft:red_concrete
fill 330 177 443 330 226 443 minecraft:red_concrete
setblock 330 177 445 minecraft:red_concrete
fill 330 177 450 330 226 450 minecraft:red_concrete
setblock 330 177 452 minecraft:red_concrete
fill 330 177 457 330 226 457 minecraft:red_concrete
fill 332 177 417 332 226 417 minecraft:red_concrete
setblock 332 177 457 minecraft:red_concrete
fill 336 177 433 341 177 434 minecraft:white_concrete
setblock 337 177 417 minecraft:red_concrete
setblock 337 177 430 minecraft:white_concrete
fill 337 177 432 342 177 432 minecraft:white_concrete
fill 337 177 440 340 177 440 minecraft:white_concrete
fill 337 177 442 338 177 444 minecraft:white_concrete
fill 337 177 457 337 226 457 minecraft:red_concrete
setblock 338 177 429 minecraft:white_concrete
fill 338 177 431 342 177 431 minecraft:white_concrete
fill 338 177 439 340 177 439 minecraft:white_concrete
setblock 338 177 445 minecraft:white_concrete
fill 339 177 417 339 226 417 minecraft:red_concrete
setblock 339 177 428 minecraft:white_concrete
fill 339 177 430 343 177 430 minecraft:white_concrete
fill 339 177 438 340 177 438 minecraft:white_concrete
fill 339 177 442 341 177 442 minecraft:white_concrete
setblock 339 177 457 minecraft:red_concrete
setblock 340 177 427 minecraft:white_concrete
fill 340 177 429 345 177 429 minecraft:white_concrete
setblock 340 177 437 minecraft:white_concrete
fill 340 177 445 344 177 445 minecraft:white_concrete
fill 340 177 447 344 177 447 minecraft:white_concrete
setblock 341 177 426 minecraft:white_concrete
fill 341 177 435 341 177 436 minecraft:red_concrete
fill 341 177 437 342 179 437 minecraft:yellow_concrete
fill 341 177 438 341 177 440 minecraft:red_concrete
fill 341 177 444 343 177 444 minecraft:white_concrete
fill 341 177 448 342 177 448 minecraft:white_concrete
setblock 342 177 425 minecraft:white_concrete
fill 342 177 433 343 177 433 minecraft:red_concrete
fill 342 177 434 342 178 435 minecraft:yellow_concrete
fill 342 177 439 342 178 440 minecraft:yellow_concrete
fill 342 177 441 342 177 442 minecraft:red_concrete
setblock 342 177 443 minecraft:white_concrete
setblock 342 177 449 minecraft:white_concrete
setblock 343 177 424 minecraft:white_concrete
setblock 343 177 431 minecraft:red_concrete
fill 343 177 432 343 179 432 minecraft:yellow_concrete
fill 343 177 442 343 179 442 minecraft:yellow_concrete
setblock 343 177 443 minecraft:red_concrete
setblock 344 177 417 minecraft:red_concrete
setblock 344 177 430 minecraft:red_concrete
fill 344 177 431 344 179 431 minecraft:yellow_concrete
fill 344 177 443 344 179 443 minecraft:yellow_concrete
setblock 344 177 444 minecraft:red_concrete
fill 344 177 457 344 226 457 minecraft:red_concrete
fill 345 177 430 346 179 430 minecraft:yellow_concrete
setblock 345 177 431 minecraft:red_concrete
fill 345 177 444 346 179 444 minecraft:yellow_concrete
setblock 345 177 445 minecraft:red_concrete
fill 346 177 417 346 226 417 minecraft:red_concrete
fill 346 177 429 346 179 429 minecraft:yellow_concrete
fill 346 177 445 346 179 445 minecraft:yellow_concrete
setblock 346 177 446 minecraft:red_concrete
fill 346 177 447 348 177 447 minecraft:white_concrete
fill 346 177 451 348 177 451 minecraft:white_concrete
setblock 346 177 457 minecraft:red_concrete
fill 347 177 429 347 177 430 minecraft:red_concrete
fill 348 177 429 349 179 429 minecraft:yellow_concrete
fill 348 177 445 349 179 445 minecraft:yellow_concrete
fill 349 177 428 351 177 428 minecraft:red_concrete
fill 349 177 447 351 177 447 minecraft:red_concrete
setblock 350 177 429 minecraft:red_concrete
fill 350 177 451 354 177 451 minecraft:white_concrete
setblock 351 177 417 minecraft:red_concrete
fill 351 177 429 352 179 429 minecraft:yellow_concrete
fill 351 177 445 352 179 445 minecraft:yellow_concrete
fill 351 177 457 351 226 457 minecraft:red_concrete
fill 352 177 428 355 177 428 minecraft:white_concrete
fill 352 177 446 353 177 446 minecraft:red_concrete
setblock 352 177 447 minecraft:white_concrete
fill 353 177 417 353 226 417 minecraft:red_concrete
fill 353 177 424 357 177 424 minecraft:white_concrete
fill 353 177 429 353 177 430 minecraft:red_concrete
setblock 353 177 457 minecraft:red_concrete
setblock 354 177 423 minecraft:white_concrete
fill 354 177 429 354 179 430 minecraft:yellow_concrete
fill 355 177 430 355 179 430 minecraft:yellow_concrete
setblock 355 177 431 minecraft:red_concrete
setblock 355 177 432 minecraft:yellow_concrete
fill 355 177 442 357 177 442 minecraft:yellow_concrete
fill 355 177 444 355 179 444 minecraft:yellow_concrete
setblock 355 177 445 minecraft:red_concrete
fill 356 177 430 361 177 430 minecraft:white_concrete
fill 356 177 431 356 179 431 minecraft:yellow_concrete
fill 356 177 443 356 179 443 minecraft:yellow_concrete
setblock 356 177 444 minecraft:red_concrete
fill 357 177 428 361 177 428 minecraft:white_concrete
fill 357 177 431 360 177 431 minecraft:white_concrete
fill 357 177 432 357 179 432 minecraft:yellow_concrete
fill 357 177 433 358 177 433 minecraft:red_concrete
fill 357 177 435 358 177 435 minecraft:yellow_concrete
fill 357 177 439 358 177 439 minecraft:yellow_concrete
setblock 357 177 443 minecraft:red_concrete
setblock 358 177 417 minecraft:red_concrete
fill 358 177 427 360 177 427 minecraft:white_concrete
setblock 358 177 432 minecraft:white_concrete
fill 358 177 434 358 179 434 minecraft:yellow_concrete
fill 358 177 436 359 177 436 minecraft:red_concrete
fill 358 177 437 359 179 437 minecraft:yellow_concrete
fill 358 177 440 358 179 440 minecraft:yellow_concrete
fill 358 177 441 358 177 442 minecraft:red_concrete
fill 358 177 443 363 177 443 minecraft:white_concrete
fill 358 177 457 358 226 457 minecraft:red_concrete
setblock 359 177 426 minecraft:white_concrete
fill 359 177 434 364 177 434 minecraft:white_concrete
setblock 359 177 435 minecraft:red_concrete
fill 359 177 438 359 177 439 minecraft:red_concrete
fill 359 177 440 359 177 442 minecraft:white_concrete
fill 360 177 417 360 226 417 minecraft:red_concrete
fill 360 177 433 364 177 433 minecraft:white_concrete
fill 360 177 435 361 177 438 minecraft:white_concrete
fill 360 177 441 363 177 442 minecraft:white_concrete
setblock 360 177 457 minecraft:red_concrete
fill 361 177 432 363 177 432 minecraft:white_concrete
fill 361 177 440 364 177 440 minecraft:white_concrete
fill 362 177 431 363 177 431 minecraft:white_concrete
fill 362 177 435 363 178 436 minecraft:white_concrete
fill 362 177 439 364 177 439 minecraft:white_concrete
setblock 363 177 430 minecraft:white_concrete
fill 363 177 438 364 177 438 minecraft:white_concrete
setblock 364 177 435 minecraft:white_concrete
setblock 364 177 437 minecraft:white_concrete
setblock 364 177 441 minecraft:white_concrete
setblock 365 177 417 minecraft:red_concrete
fill 365 177 457 365 226 457 minecraft:red_concrete
fill 367 177 417 367 226 417 minecraft:red_concrete
setblock 367 177 457 minecraft:red_concrete
setblock 370 177 419 minecraft:red_concrete
fill 370 177 421 370 226 421 minecraft:red_concrete
setblock 370 177 426 minecraft:red_concrete
fill 370 177 428 370 226 428 minecraft:red_concrete
setblock 370 177 433 minecraft:red_concrete
fill 370 177 435 370 226 435 minecraft:red_concrete
setblock 370 177 440 minecraft:red_concrete
fill 370 177 442 370 226 442 minecraft:red_concrete
setblock 370 177 447 minecraft:red_concrete
fill 370 177 449 370 226 449 minecraft:red_concrete
setblock 370 177 454 minecraft:red_concrete
fill 370 177 456 370 226 456 minecraft:red_concrete
setblock 330 178 418 minecraft:red_concrete
setblock 330 178 425 minecraft:red_concrete
setblock 330 178 432 minecraft:red_concrete
setblock 330 178 439 minecraft:red_concrete
setblock 330 178 446 minecraft:red_concrete
setblock 330 178 453 minecraft:red_concrete
setblock 333 178 457 minecraft:red_concrete
setblock 336 178 417 minecraft:red_concrete
fill 337 178 435 339 178 436 minecraft:white_concrete
fill 338 178 432 340 178 434 minecraft:white_concrete
fill 338 178 439 339 178 442 minecraft:white_concrete
fill 339 178 430 341 178 431 minecraft:white_concrete
setblock 339 178 438 minecraft:white_concrete
fill 340 178 429 343 178 429 minecraft:white_concrete
fill 340 178 435 340 178 436 minecraft:red_concrete
fill 340 178 437 340 179 437 minecraft:yellow_concrete
fill 340 178 438 340 178 440 minecraft:red_concrete
fill 340 178 441 340 178 442 minecraft:white_concrete
fill 340 178 445 343 178 445 minecraft:white_concrete
setblock 340 178 457 minecraft:red_concrete
fill 341 178 428 344 178 428 minecraft:white_concrete
setblock 341 178 432 minecraft:white_concrete
fill 341 178 433 341 179 436 minecraft:yellow_concrete
fill 341 178 438 341 179 441 minecraft:yellow_concrete
setblock 341 178 442 minecraft:red_concrete
fill 341 178 444 342 178 444 minecraft:white_concrete
fill 341 178 446 344 178 446 minecraft:white_concrete
fill 342 178 427 347 178 427 minecraft:white_concrete
setblock 342 178 430 minecraft:white_concrete
fill 342 178 431 343 179 431 minecraft:yellow_concrete
setblock 342 178 432 minecraft:red_concrete
fill 342 178 433 342 179 433 minecraft:yellow_concrete
fill 342 178 441 342 179 441 minecraft:yellow_concrete
fill 342 178 443 343 179 443 minecraft:yellow_concrete
fill 342 178 447 344 178 447 minecraft:white_concrete
setblock 343 178 417 minecraft:red_concrete
fill 343 178 430 343 179 430 minecraft:yellow_concrete
setblock 343 178 434 minecraft:yellow_concrete
setblock 343 178 440 minecraft:yellow_concrete
fill 343 178 444 343 179 444 minecraft:yellow_concrete
setblock 344 178 429 minecraft:red_concrete
setblock 344 178 432 minecraft:yellow_concrete
setblock 344 178 442 minecraft:yellow_concrete
setblock 344 178 445 minecraft:red_concrete
fill 345 178 425 350 178 425 minecraft:white_concrete
fill 345 178 428 345 179 429 minecraft:yellow_concrete
fill 345 178 445 345 179 446 minecraft:yellow_concrete
fill 345 178 449 350 178 449 minecraft:white_concrete
fill 346 178 428 346 179 428 minecraft:yellow_concrete
fill 346 178 446 346 179 446 minecraft:yellow_concrete
setblock 346 178 447 minecraft:white_concrete
setblock 347 178 428 minecraft:red_concrete
setblock 347 178 447 minecraft:red_concrete
setblock 347 178 457 minecraft:red_concrete
fill 348 178 424 351 178 424 minecraft:white_concrete
fill 348 178 427 349 179 428 minecraft:yellow_concrete
fill 348 178 446 349 179 447 minecraft:yellow_concrete
fill 348 178 450 349 178 450 minecraft:white_concrete
setblock 350 178 417 minecraft:red_concrete
setblock 350 178 427 minecraft:red_concrete
setblock 350 178 447 minecraft:red_concrete
fill 351 178 427 352 179 428 minecraft:yellow_concrete
fill 351 178 446 352 179 447 minecraft:yellow_concrete
fill 351 178 450 352 178 450 minecraft:white_concrete
fill 352 178 425 355 178 425 minecraft:white_concrete
fill 352 178 449 355 178 449 minecraft:white_concrete
fill 353 178 427 356 178 427 minecraft:white_concrete
setblock 353 178 428 minecraft:red_concrete
setblock 353 178 447 minecraft:red_concrete
fill 353 178 448 357 178 448 minecraft:white_concrete
fill 354 178 428 355 179 428 minecraft:yellow_concrete
fill 354 178 439 354 179 443 minecraft:white_concrete
fill 354 178 447 358 178 447 minecraft:white_concrete
setblock 354 178 457 minecraft:red_concrete
fill 355 178 429 355 179 429 minecraft:yellow_concrete
fill 355 178 445 355 179 446 minecraft:yellow_concrete
fill 356 178 429 356 178 430 minecraft:red_concrete
fill 356 178 442 357 178 442 minecraft:yellow_concrete
setblock 356 178 445 minecraft:red_concrete
fill 356 178 446 359 178 446 minecraft:white_concrete
setblock 357 178 417 minecraft:red_concrete
fill 357 178 428 359 178 429 minecraft:white_concrete
fill 357 178 430 357 179 431 minecraft:yellow_concrete
fill 357 178 443 357 179 444 minecraft:yellow_concrete
fill 357 178 445 360 178 445 minecraft:white_concrete
setblock 358 178 427 minecraft:white_concrete
fill 358 178 430 361 178 430 minecraft:white_concrete
fill 358 178 431 358 179 431 minecraft:yellow_concrete
setblock 358 178 432 minecraft:red_concrete
fill 358 178 433 359 179 433 minecraft:yellow_concrete
fill 358 178 435 359 178 435 minecraft:yellow_concrete
fill 358 178 439 359 178 439 minecraft:yellow_concrete
fill 358 178 441 359 179 441 minecraft:yellow_concrete
fill 358 178 443 358 179 443 minecraft:yellow_concrete
fill 358 178 444 361 178 444 minecraft:white_concrete
fill 359 178 431 360 178 431 minecraft:white_concrete
fill 359 178 434 359 179 434 minecraft:yellow_concrete
fill 359 178 436 359 179 436 minecraft:yellow_concrete
fill 359 178 438 359 179 438 minecraft:yellow_concrete
fill 359 178 440 359 179 440 minecraft:yellow_concrete
setblock 359 178 442 minecraft:red_concrete
fill 359 178 443 361 178 443 minecraft:white_concrete
setblock 360 178 429 minecraft:white_concrete
fill 360 178 433 362 178 434 minecraft:white_concrete
fill 360 178 435 360 178 436 minecraft:red_concrete
fill 360 178 437 360 179 437 minecraft:yellow_concrete
fill 360 178 438 360 178 439 minecraft:red_concrete
fill 360 178 441 362 178 442 minecraft:white_concrete
fill 361 178 432 362 178 432 minecraft:white_concrete
fill 361 178 435 361 178 438 minecraft:white_concrete
fill 361 178 440 362 178 440 minecraft:white_concrete
setblock 361 178 457 minecraft:red_concrete
fill 362 178 439 363 178 439 minecraft:white_concrete
setblock 363 178 438 minecraft:white_concrete
setblock 364 178 417 minecraft:red_concrete
setblock 368 178 457 minecraft:red_concrete
setblock 370 178 418 minecraft:red_concrete
setblock 370 178 425 minecraft:red_concrete
setblock 370 178 432 minecraft:red_concrete
setblock 370 178 439 minecraft:red_concrete
setblock 370 178 446 minecraft:red_concrete
setblock 370 178 453 minecraft:red_concrete
fill 330 179 419 330 180 419 minecraft:red_concrete
fill 330 179 426 330 180 426 minecraft:red_concrete
fill 330 179 433 330 180 433 minecraft:red_concrete
fill 330 179 440 330 180 440 minecraft:red_concrete
fill 330 179 447 330 180 447 minecraft:red_concrete
fill 330 179 454 330 180 454 minecraft:red_concrete
fill 334 179 457 334 180 457 minecraft:red_concrete
fill 335 179 417 335 180 417 minecraft:red_concrete
setblock 339 179 437 minecraft:yellow_concrete
fill 340 179 433 340 179 434 minecraft:yellow_concrete
setblock 340 179 436 minecraft:yellow_concrete
setblock 340 179 438 minecraft:yellow_concrete
fill 340 179 440 340 179 441 minecraft:yellow_concrete
fill 341 179 457 341 180 457 minecraft:red_concrete
fill 342 179 417 342 180 417 minecraft:red_concrete
setblock 342 179 430 minecraft:yellow_concrete
setblock 342 179 432 minecraft:yellow_concrete
setblock 342 179 434 minecraft:yellow_concrete
setblock 342 179 440 minecraft:yellow_concrete
setblock 342 179 442 minecraft:yellow_concrete
setblock 342 179 444 minecraft:yellow_concrete
fill 344 179 428 344 179 429 minecraft:yellow_concrete
fill 344 179 445 344 179 446 minecraft:yellow_concrete
fill 347 179 427 347 179 428 minecraft:yellow_concrete
fill 347 179 446 347 179 447 minecraft:yellow_concrete
fill 348 179 457 348 180 457 minecraft:red_concrete
fill 349 179 417 349 180 417 minecraft:red_concrete
fill 353 179 427 353 179 428 minecraft:yellow_concrete
fill 353 179 446 353 179 447 minecraft:yellow_concrete
fill 355 179 457 355 180 457 minecraft:red_concrete
fill 356 179 417 356 180 417 minecraft:red_concrete
fill 356 179 428 356 179 429 minecraft:yellow_concrete
fill 356 179 445 356 179 446 minecraft:yellow_concrete
fill 357 179 442 358 179 442 minecraft:yellow_concrete
setblock 358 179 430 minecraft:yellow_concrete
setblock 358 179 432 minecraft:yellow_concrete
setblock 358 179 444 minecraft:yellow_concrete
setblock 359 179 435 minecraft:yellow_concrete
setblock 359 179 439 minecraft:yellow_concrete
fill 360 179 433 360 179 434 minecraft:yellow_concrete
setblock 360 179 436 minecraft:yellow_concrete
setblock 360 179 438 minecraft:yellow_concrete
fill 360 179 440 360 179 441 minecraft:yellow_concrete
setblock 361 179 437 minecraft:yellow_concrete
fill 362 179 457 362 180 457 minecraft:red_concrete
fill 363 179 417 363 180 417 minecraft:red_concrete
fill 369 179 457 369 180 457 minecraft:red_concrete
fill 370 179 417 370 180 417 minecraft:red_concrete
fill 370 179 424 370 180 424 minecraft:red_concrete
fill 370 179 431 370 180 431 minecraft:red_concrete
fill 370 179 438 370 180 438 minecraft:red_concrete
fill 370 179 445 370 180 445 minecraft:red_concrete
fill 370 179 452 370 180 452 minecraft:red_concrete
fill 330 180 417 330 180 418 minecraft:red_concrete
fill 330 180 420 330 180 421 minecraft:red_concrete
fill 330 180 423 330 180 425 minecraft:red_concrete
fill 330 180 427 330 180 428 minecraft:red_concrete
fill 330 180 430 330 180 432 minecraft:red_concrete
fill 330 180 434 330 180 435 minecraft:red_concrete
fill 330 180 437 330 180 439 minecraft:red_concrete
fill 330 180 441 330 180 442 minecraft:red_concrete
fill 330 180 444 330 180 446 minecraft:red_concrete
fill 330 180 448 330 180 449 minecraft:red_concrete
fill 330 180 451 330 180 453 minecraft:red_concrete
fill 330 180 455 330 180 456 minecraft:red_concrete
setblock 331 180 417 minecraft:red_concrete
fill 331 180 457 333 180 457 minecraft:red_concrete
fill 333 180 417 334 180 417 minecraft:red_concrete
fill 335 180 457 336 180 457 minecraft:red_concrete
fill 336 180 417 338 180 417 minecraft:red_concrete
fill 338 180 457 340 180 457 minecraft:red_concrete
fill 340 180 417 341 180 417 minecraft:red_concrete
fill 342 180 457 343 180 457 minecraft:red_concrete
fill 343 180 417 345 180 417 minecraft:red_concrete
fill 345 180 457 347 180 457 minecraft:red_concrete
fill 347 180 417 348 180 417 minecraft:red_concrete
fill 349 180 457 350 180 457 minecraft:red_concrete
fill 350 180 417 352 180 417 minecraft:red_concrete
fill 352 180 457 354 180 457 minecraft:red_concrete
fill 354 180 417 355 180 417 minecraft:red_concrete
fill 356 180 457 357 180 457 minecraft:red_concrete
fill 357 180 417 359 180 417 minecraft:red_concrete
fill 359 180 457 361 180 457 minecraft:red_concrete
fill 361 180 417 362 180 417 minecraft:red_concrete
fill 363 180 457 364 180 457 minecraft:red_concrete
fill 364 180 417 366 180 417 minecraft:red_concrete
fill 366 180 457 368 180 457 minecraft:red_concrete
fill 368 180 417 369 180 417 minecraft:red_concrete
fill 370 180 418 370 180 420 minecraft:red_concrete
fill 370 180 422 370 180 423 minecraft:red_concrete
fill 370 180 425 370 180 427 minecraft:red_concrete
fill 370 180 429 370 180 430 minecraft:red_concrete
fill 370 180 432 370 180 434 minecraft:red_concrete
fill 370 180 436 370 180 437 minecraft:red_concrete
fill 370 180 439 370 180 441 minecraft:red_concrete
fill 370 180 443 370 180 444 minecraft:red_concrete
fill 370 180 446 370 180 448 minecraft:red_concrete
fill 370 180 450 370 180 451 minecraft:red_concrete
fill 370 180 453 370 180 455 minecraft:red_concrete
setblock 370 180 457 minecraft:red_concrete
setblock 330 181 421 minecraft:red_concrete
setblock 330 181 428 minecraft:red_concrete
setblock 330 181 435 minecraft:red_concrete
setblock 330 181 442 minecraft:red_concrete
setblock 330 181 449 minecraft:red_concrete
setblock 330 181 456 minecraft:red_concrete
setblock 333 181 417 minecraft:red_concrete
setblock 336 181 457 minecraft:red_concrete
setblock 340 181 417 minecraft:red_concrete
setblock 343 181 457 minecraft:red_concrete
setblock 347 181 417 minecraft:red_concrete
setblock 350 181 457 minecraft:red_concrete
setblock 354 181 417 minecraft:red_concrete
setblock 357 181 457 minecraft:red_concrete
setblock 361 181 417 minecraft:red_concrete
setblock 364 181 457 minecraft:red_concrete
setblock 368 181 417 minecraft:red_concrete
setblock 370 181 422 minecraft:red_concrete
setblock 370 181 429 minecraft:red_concrete
setblock 370 181 436 minecraft:red_concrete
setblock 370 181 443 minecraft:red_concrete
setblock 370 181 450 minecraft:red_concrete
setblock 332 182 419 minecraft:light[level=12]
setblock 332 182 427 minecraft:light[level=12]
setblock 332 182 435 minecraft:light[level=12]
setblock 332 182 443 minecraft:light[level=12]
setblock 332 182 451 minecraft:light[level=12]
setblock 340 182 419 minecraft:light[level=12]
setblock 340 182 427 minecraft:light[level=12]
setblock 340 182 435 minecraft:light[level=12]
setblock 340 182 443 minecraft:light[level=12]
setblock 340 182 451 minecraft:light[level=12]
setblock 348 182 419 minecraft:light[level=12]
setblock 348 182 427 minecraft:light[level=12]
setblock 348 182 435 minecraft:light[level=12]
setblock 348 182 443 minecraft:light[level=12]
setblock 348 182 451 minecraft:light[level=12]
setblock 356 182 419 minecraft:light[level=12]
setblock 356 182 427 minecraft:light[level=12]
setblock 356 182 435 minecraft:light[level=12]
setblock 356 182 443 minecraft:light[level=12]
setblock 356 182 451 minecraft:light[level=12]
setblock 364 182 419 minecraft:light[level=12]
setblock 364 182 427 minecraft:light[level=12]
setblock 364 182 435 minecraft:light[level=12]
setblock 364 182 443 minecraft:light[level=12]
setblock 364 182 451 minecraft:light[level=12]
setblock 330 183 423 minecraft:red_concrete
setblock 330 183 430 minecraft:red_concrete
setblock 330 183 437 minecraft:red_concrete
setblock 330 183 444 minecraft:red_concrete
setblock 330 183 451 minecraft:red_concrete
setblock 331 183 417 minecraft:red_concrete
setblock 331 183 457 minecraft:red_concrete
setblock 338 183 417 minecraft:red_concrete
setblock 338 183 457 minecraft:red_concrete
setblock 345 183 417 minecraft:red_concrete
setblock 345 183 457 minecraft:red_concrete
setblock 352 183 417 minecraft:red_concrete
setblock 352 183 457 minecraft:red_concrete
setblock 359 183 417 minecraft:red_concrete
setblock 359 183 457 minecraft:red_concrete
setblock 366 183 417 minecraft:red_concrete
setblock 366 183 457 minecraft:red_concrete
setblock 370 183 420 minecraft:red_concrete
setblock 370 183 427 minecraft:red_concrete
setblock 370 183 434 minecraft:red_concrete
setblock 370 183 441 minecraft:red_concrete
setblock 370 183 448 minecraft:red_concrete
setblock 370 183 455 minecraft:red_concrete
setblock 330 184 417 minecraft:red_concrete
setblock 330 184 424 minecraft:red_concrete
setblock 330 184 431 minecraft:red_concrete
setblock 330 184 438 minecraft:red_concrete
setblock 330 184 445 minecraft:red_concrete
setblock 330 184 452 minecraft:red_concrete
setblock 332 184 457 minecraft:red_concrete
setblock 337 184 417 minecraft:red_concrete
setblock 339 184 457 minecraft:red_concrete
setblock 344 184 417 minecraft:red_concrete
setblock 346 184 457 minecraft:red_concrete
setblock 351 184 417 minecraft:red_concrete
setblock 353 184 457 minecraft:red_concrete
setblock 358 184 417 minecraft:red_concrete
setblock 360 184 457 minecraft:red_concrete
setblock 365 184 417 minecraft:red_concrete
setblock 367 184 457 minecraft:red_concrete
setblock 370 184 419 minecraft:red_concrete
setblock 370 184 426 minecraft:red_concrete
setblock 370 184 433 minecraft:red_concrete
setblock 370 184 440 minecraft:red_concrete
setblock 370 184 447 minecraft:red_concrete
setblock 370 184 454 minecraft:red_concrete
setblock 330 185 418 minecraft:red_concrete
setblock 330 185 425 minecraft:red_concrete
setblock 330 185 432 minecraft:red_concrete
setblock 330 185 439 minecraft:red_concrete
setblock 330 185 446 minecraft:red_concrete
setblock 330 185 453 minecraft:red_concrete
setblock 333 185 457 minecraft:red_concrete
setblock 336 185 417 minecraft:red_concrete
setblock 340 185 457 minecraft:red_concrete
setblock 343 185 417 minecraft:red_concrete
setblock 347 185 457 minecraft:red_concrete
setblock 350 185 417 minecraft:red_concrete
setblock 354 185 457 minecraft:red_concrete
setblock 357 185 417 minecraft:red_concrete
setblock 361 185 457 minecraft:red_concrete
setblock 364 185 417 minecraft:red_concrete
setblock 368 185 457 minecraft:red_concrete
setblock 370 185 418 minecraft:red_concrete
setblock 370 185 425 minecraft:red_concrete
setblock 370 185 432 minecraft:red_concrete
setblock 370 185 439 minecraft:red_concrete
setblock 370 185 446 minecraft:red_concrete
setblock 370 185 453 minecraft:red_concrete
setblock 330 186 419 minecraft:red_concrete
setblock 330 186 426 minecraft:red_concrete
setblock 330 186 433 minecraft:red_concrete
setblock 330 186 440 minecraft:red_concrete
setblock 330 186 447 minecraft:red_concrete
setblock 330 186 454 minecraft:red_concrete
setblock 334 186 457 minecraft:red_concrete
setblock 335 186 417 minecraft:red_concrete
setblock 341 186 457 minecraft:red_concrete
setblock 342 186 417 minecraft:red_concrete
setblock 348 186 457 minecraft:red_concrete
setblock 349 186 417 minecraft:red_concrete
setblock 355 186 457 minecraft:red_concrete
setblock 356 186 417 minecraft:red_concrete
setblock 362 186 457 minecraft:red_concrete
setblock 363 186 417 minecraft:red_concrete
setblock 369 186 457 minecraft:red_concrete
setblock 370 186 417 minecraft:red_concrete
setblock 370 186 424 minecraft:red_concrete
setblock 370 186 431 minecraft:red_concrete
setblock 370 186 438 minecraft:red_concrete
setblock 370 186 445 minecraft:red_concrete
setblock 370 186 452 minecraft:red_concrete
setblock 330 187 420 minecraft:red_concrete
setblock 330 187 427 minecraft:red_concrete
setblock 330 187 434 minecraft:red_concrete
setblock 330 187 441 minecraft:red_concrete
setblock 330 187 448 minecraft:red_concrete
setblock 330 187 455 minecraft:red_concrete
setblock 334 187 417 minecraft:red_concrete
setblock 335 187 457 minecraft:red_concrete
setblock 341 187 417 minecraft:red_concrete
setblock 342 187 457 minecraft:red_concrete
setblock 348 187 417 minecraft:red_concrete
setblock 349 187 457 minecraft:red_concrete
setblock 355 187 417 minecraft:red_concrete
setblock 356 187 457 minecraft:red_concrete
setblock 362 187 417 minecraft:red_concrete
setblock 363 187 457 minecraft:red_concrete
setblock 369 187 417 minecraft:red_concrete
setblock 370 187 423 minecraft:red_concrete
setblock 370 187 430 minecraft:red_concrete
setblock 370 187 437 minecraft:red_concrete
setblock 370 187 444 minecraft:red_concrete
setblock 370 187 451 minecraft:red_concrete
setblock 370 187 457 minecraft:red_concrete
setblock 330 188 421 minecraft:red_concrete
setblock 330 188 428 minecraft:red_concrete
setblock 330 188 435 minecraft:red_concrete
setblock 330 188 442 minecraft:red_concrete
setblock 330 188 449 minecraft:red_concrete
setblock 330 188 456 minecraft:red_concrete
setblock 333 188 417 minecraft:red_concrete
setblock 336 188 457 minecraft:red_concrete
setblock 340 188 417 minecraft:red_concrete
setblock 343 188 457 minecraft:red_concrete
setblock 347 188 417 minecraft:red_concrete
setblock 350 188 457 minecraft:red_concrete
setblock 354 188 417 minecraft:red_concrete
setblock 357 188 457 minecraft:red_concrete
setblock 361 188 417 minecraft:red_concrete
setblock 364 188 457 minecraft:red_concrete
setblock 368 188 417 minecraft:red_concrete
setblock 370 188 422 minecraft:red_concrete
setblock 370 188 429 minecraft:red_concrete
setblock 370 188 436 minecraft:red_concrete
setblock 370 188 443 minecraft:red_concrete
setblock 370 188 450 minecraft:red_concrete
fill 330 190 417 330 190 421 minecraft:red_concrete
fill 330 190 423 330 190 428 minecraft:red_concrete
fill 330 190 430 330 190 435 minecraft:red_concrete
fill 330 190 437 330 190 442 minecraft:red_concrete
fill 330 190 444 330 190 449 minecraft:red_concrete
fill 330 190 451 330 190 456 minecraft:red_concrete
setblock 331 190 417 minecraft:red_concrete
fill 331 190 457 336 190 457 minecraft:red_concrete
setblock 332 190 419 minecraft:light[level=12]
setblock 332 190 427 minecraft:light[level=12]
setblock 332 190 435 minecraft:light[level=12]
setblock 332 190 443 minecraft:light[level=12]
setblock 332 190 451 minecraft:light[level=12]
fill 333 190 417 338 190 417 minecraft:red_concrete
fill 338 190 457 343 190 457 minecraft:red_concrete
fill 340 190 417 345 190 417 minecraft:red_concrete
setblock 340 190 419 minecraft:light[level=12]
setblock 340 190 427 minecraft:light[level=12]
setblock 340 190 435 minecraft:light[level=12]
setblock 340 190 443 minecraft:light[level=12]
setblock 340 190 451 minecraft:light[level=12]
fill 345 190 457 350 190 457 minecraft:red_concrete
fill 347 190 417 352 190 417 minecraft:red_concrete
setblock 348 190 419 minecraft:light[level=12]
setblock 348 190 427 minecraft:light[level=12]
setblock 348 190 435 minecraft:light[level=12]
setblock 348 190 443 minecraft:light[level=12]
setblock 348 190 451 minecraft:light[level=12]
fill 352 190 457 357 190 457 minecraft:red_concrete
fill 354 190 417 359 190 417 minecraft:red_concrete
setblock 356 190 419 minecraft:light[level=12]
setblock 356 190 427 minecraft:light[level=12]
setblock 356 190 435 minecraft:light[level=12]
setblock 356 190 443 minecraft:light[level=12]
setblock 356 190 451 minecraft:light[level=12]
fill 359 190 457 364 190 457 minecraft:red_concrete
fill 361 190 417 366 190 417 minecraft:red_concrete
setblock 364 190 419 minecraft:light[level=12]
setblock 364 190 427 minecraft:light[level=12]
setblock 364 190 435 minecraft:light[level=12]
setblock 364 190 443 minecraft:light[level=12]
setblock 364 190 451 minecraft:light[level=12]
fill 366 190 457 370 190 457 minecraft:red_concrete
fill 368 190 417 370 190 417 minecraft:red_concrete
fill 370 190 418 370 190 420 minecraft:red_concrete
fill 370 190 422 370 190 427 minecraft:red_concrete
fill 370 190 429 370 190 434 minecraft:red_concrete
fill 370 190 436 370 190 441 minecraft:red_concrete
fill 370 190 443 370 190 448 minecraft:red_concrete
fill 370 190 450 370 190 455 minecraft:red_concrete
setblock 330 191 417 minecraft:red_concrete
setblock 330 191 424 minecraft:red_concrete
setblock 330 191 431 minecraft:red_concrete
setblock 330 191 438 minecraft:red_concrete
setblock 330 191 445 minecraft:red_concrete
setblock 330 191 452 minecraft:red_concrete
setblock 332 191 457 minecraft:red_concrete
setblock 337 191 417 minecraft:red_concrete
setblock 339 191 457 minecraft:red_concrete
setblock 344 191 417 minecraft:red_concrete
setblock 346 191 457 minecraft:red_concrete
setblock 351 191 417 minecraft:red_concrete
setblock 353 191 457 minecraft:red_concrete
setblock 358 191 417 minecraft:red_concrete
setblock 360 191 457 minecraft:red_concrete
setblock 365 191 417 minecraft:red_concrete
setblock 367 191 457 minecraft:red_concrete
setblock 370 191 419 minecraft:red_concrete
setblock 370 191 426 minecraft:red_concrete
setblock 370 191 433 minecraft:red_concrete
setblock 370 191 440 minecraft:red_concrete
setblock 370 191 447 minecraft:red_concrete
setblock 370 191 454 minecraft:red_concrete
setblock 330 192 418 minecraft:red_concrete
setblock 330 192 425 minecraft:red_concrete
setblock 330 192 432 minecraft:red_concrete
setblock 330 192 439 minecraft:red_concrete
setblock 330 192 446 minecraft:red_concrete
setblock 330 192 453 minecraft:red_concrete
setblock 333 192 457 minecraft:red_concrete
setblock 336 192 417 minecraft:red_concrete
setblock 340 192 457 minecraft:red_concrete
setblock 343 192 417 minecraft:red_concrete
setblock 347 192 457 minecraft:red_concrete
setblock 350 192 417 minecraft:red_concrete
setblock 354 192 457 minecraft:red_concrete
setblock 357 192 417 minecraft:red_concrete
setblock 361 192 457 minecraft:red_concrete
setblock 364 192 417 minecraft:red_concrete
setblock 368 192 457 minecraft:red_concrete
setblock 370 192 418 minecraft:red_concrete
setblock 370 192 425 minecraft:red_concrete
setblock 370 192 432 minecraft:red_concrete
setblock 370 192 439 minecraft:red_concrete
setblock 370 192 446 minecraft:red_concrete
setblock 370 192 453 minecraft:red_concrete
setblock 330 193 419 minecraft:red_concrete
setblock 330 193 426 minecraft:red_concrete
setblock 330 193 433 minecraft:red_concrete
setblock 330 193 440 minecraft:red_concrete
setblock 330 193 447 minecraft:red_concrete
setblock 330 193 454 minecraft:red_concrete
setblock 334 193 457 minecraft:red_concrete
setblock 335 193 417 minecraft:red_concrete
setblock 341 193 457 minecraft:red_concrete
setblock 342 193 417 minecraft:red_concrete
setblock 348 193 457 minecraft:red_concrete
setblock 349 193 417 minecraft:red_concrete
setblock 355 193 457 minecraft:red_concrete
setblock 356 193 417 minecraft:red_concrete
fill 357 193 432 358 194 432 minecraft:white_wool
setblock 362 193 457 minecraft:red_concrete
setblock 363 193 417 minecraft:red_concrete
setblock 369 193 457 minecraft:red_concrete
setblock 370 193 417 minecraft:red_concrete
setblock 370 193 424 minecraft:red_concrete
setblock 370 193 431 minecraft:red_concrete
setblock 370 193 438 minecraft:red_concrete
setblock 370 193 445 minecraft:red_concrete
setblock 370 193 452 minecraft:red_concrete
setblock 330 194 420 minecraft:red_concrete
setblock 330 194 427 minecraft:red_concrete
setblock 330 194 434 minecraft:red_concrete
setblock 330 194 441 minecraft:red_concrete
setblock 330 194 448 minecraft:red_concrete
setblock 330 194 455 minecraft:red_concrete
setblock 334 194 417 minecraft:red_concrete
setblock 335 194 457 minecraft:red_concrete
setblock 341 194 417 minecraft:red_concrete
setblock 342 194 457 minecraft:red_concrete
setblock 348 194 417 minecraft:red_concrete
setblock 349 194 457 minecraft:red_concrete
setblock 355 194 417 minecraft:red_concrete
setblock 356 194 457 minecraft:red_concrete
setblock 362 194 417 minecraft:red_concrete
setblock 363 194 457 minecraft:red_concrete
setblock 369 194 417 minecraft:red_concrete
setblock 370 194 423 minecraft:red_concrete
setblock 370 194 430 minecraft:red_concrete
setblock 370 194 437 minecraft:red_concrete
setblock 370 194 444 minecraft:red_concrete
setblock 370 194 451 minecraft:red_concrete
setblock 370 194 457 minecraft:red_concrete
setblock 330 195 421 minecraft:red_concrete
setblock 330 195 428 minecraft:red_concrete
setblock 330 195 435 minecraft:red_concrete
setblock 330 195 442 minecraft:red_concrete
setblock 330 195 449 minecraft:red_concrete
setblock 330 195 456 minecraft:red_concrete
setblock 333 195 417 minecraft:red_concrete
setblock 336 195 457 minecraft:red_concrete
setblock 340 195 417 minecraft:red_concrete
setblock 343 195 457 minecraft:red_concrete
setblock 347 195 417 minecraft:red_concrete
setblock 350 195 457 minecraft:red_concrete
setblock 354 195 417 minecraft:red_concrete
setblock 357 195 457 minecraft:red_concrete
setblock 361 195 417 minecraft:red_concrete
setblock 364 195 457 minecraft:red_concrete
setblock 368 195 417 minecraft:red_concrete
setblock 370 195 422 minecraft:red_concrete
setblock 370 195 429 minecraft:red_concrete
setblock 370 195 436 minecraft:red_concrete
setblock 370 195 443 minecraft:red_concrete
setblock 370 195 450 minecraft:red_concrete
fill 344 196 418 344 208 418 minecraft:red_wool
setblock 330 197 423 minecraft:red_concrete
setblock 330 197 430 minecraft:red_concrete
setblock 330 197 437 minecraft:red_concrete
setblock 330 197 444 minecraft:red_concrete
setblock 330 197 451 minecraft:red_concrete
setblock 331 197 417 minecraft:red_concrete
setblock 331 197 457 minecraft:red_concrete
setblock 338 197 417 minecraft:red_concrete
setblock 338 197 457 minecraft:red_concrete
fill 342 197 418 343 208 418 minecraft:red_wool
setblock 345 197 417 minecraft:red_concrete
fill 345 197 418 346 208 418 minecraft:red_wool
setblock 345 197 457 minecraft:red_concrete
setblock 352 197 417 minecraft:red_concrete
setblock 352 197 457 minecraft:red_concrete
setblock 359 197 417 minecraft:red_concrete
setblock 359 197 457 minecraft:red_concrete
setblock 366 197 417 minecraft:red_concrete
setblock 366 197 457 minecraft:red_concrete
setblock 370 197 420 minecraft:red_concrete
setblock 370 197 427 minecraft:red_concrete
setblock 370 197 434 minecraft:red_concrete
setblock 370 197 441 minecraft:red_concrete
setblock 370 197 448 minecraft:red_concrete
setblock 370 197 455 minecraft:red_concrete
setblock 330 198 417 minecraft:red_concrete
setblock 330 198 424 minecraft:red_concrete
setblock 330 198 431 minecraft:red_concrete
setblock 330 198 438 minecraft:red_concrete
setblock 330 198 445 minecraft:red_concrete
setblock 330 198 452 minecraft:red_concrete
setblock 332 198 419 minecraft:light[level=12]
setblock 332 198 427 minecraft:light[level=12]
setblock 332 198 435 minecraft:light[level=12]
setblock 332 198 443 minecraft:light[level=12]
setblock 332 198 451 minecraft:light[level=12]
setblock 332 198 457 minecraft:red_concrete
setblock 337 198 417 minecraft:red_concrete
setblock 339 198 457 minecraft:red_concrete
setblock 340 198 419 minecraft:light[level=12]
setblock 340 198 427 minecraft:light[level=12]
setblock 340 198 435 minecraft:light[level=12]
setblock 340 198 443 minecraft:light[level=12]
setblock 340 198 451 minecraft:light[level=12]
setblock 344 198 417 minecraft:red_concrete
setblock 346 198 457 minecraft:red_concrete
setblock 348 198 419 minecraft:light[level=12]
setblock 348 198 427 minecraft:light[level=12]
setblock 348 198 435 minecraft:light[level=12]
setblock 348 198 443 minecraft:light[level=12]
setblock 348 198 451 minecraft:light[level=12]
setblock 351 198 417 minecraft:red_concrete
setblock 353 198 457 minecraft:red_concrete
setblock 356 198 419 minecraft:light[level=12]
setblock 356 198 427 minecraft:light[level=12]
setblock 356 198 435 minecraft:light[level=12]
setblock 356 198 443 minecraft:light[level=12]
setblock 356 198 451 minecraft:light[level=12]
setblock 358 198 417 minecraft:red_concrete
setblock 360 198 457 minecraft:red_concrete
setblock 364 198 419 minecraft:light[level=12]
setblock 364 198 427 minecraft:light[level=12]
setblock 364 198 435 minecraft:light[level=12]
setblock 364 198 443 minecraft:light[level=12]
setblock 364 198 451 minecraft:light[level=12]
setblock 365 198 417 minecraft:red_concrete
setblock 367 198 457 minecraft:red_concrete
setblock 370 198 419 minecraft:red_concrete
setblock 370 198 426 minecraft:red_concrete
setblock 370 198 433 minecraft:red_concrete
setblock 370 198 440 minecraft:red_concrete
setblock 370 198 447 minecraft:red_concrete
setblock 370 198 454 minecraft:red_concrete
fill 330 199 418 330 200 418 minecraft:red_concrete
fill 330 199 425 330 200 425 minecraft:red_concrete
fill 330 199 432 330 200 432 minecraft:red_concrete
fill 330 199 439 330 200 439 minecraft:red_concrete
fill 330 199 446 330 200 446 minecraft:red_concrete
fill 330 199 453 330 200 453 minecraft:red_concrete
fill 333 199 457 333 200 457 minecraft:red_concrete
fill 336 199 417 336 200 417 minecraft:red_concrete
fill 340 199 457 340 200 457 minecraft:red_concrete
fill 343 199 417 343 200 417 minecraft:red_concrete
fill 347 199 457 347 200 457 minecraft:red_concrete
fill 350 199 417 350 200 417 minecraft:red_concrete
fill 354 199 457 354 200 457 minecraft:red_concrete
fill 357 199 417 357 200 417 minecraft:red_concrete
fill 361 199 457 361 200 457 minecraft:red_concrete
fill 364 199 417 364 200 417 minecraft:red_concrete
fill 368 199 457 368 200 457 minecraft:red_concrete
fill 370 199 418 370 200 418 minecraft:red_concrete
fill 370 199 425 370 200 425 minecraft:red_concrete
fill 370 199 432 370 200 432 minecraft:red_concrete
fill 370 199 439 370 200 439 minecraft:red_concrete
fill 370 199 446 370 200 446 minecraft:red_concrete
fill 370 199 453 370 200 453 minecraft:red_concrete
fill 330 200 417 331 200 417 minecraft:red_concrete
fill 330 200 419 330 200 421 minecraft:red_concrete
fill 330 200 423 330 200 424 minecraft:red_concrete
fill 330 200 426 330 200 428 minecraft:red_concrete
fill 330 200 430 330 200 431 minecraft:red_concrete
fill 330 200 433 330 200 435 minecraft:red_concrete
fill 330 200 437 330 200 438 minecraft:red_concrete
fill 330 200 440 330 200 442 minecraft:red_concrete
fill 330 200 444 330 200 445 minecraft:red_concrete
fill 330 200 447 330 200 449 minecraft:red_concrete
fill 330 200 451 330 200 452 minecraft:red_concrete
fill 330 200 454 330 200 456 minecraft:red_concrete
fill 331 200 457 332 200 457 minecraft:red_concrete
fill 333 200 417 335 200 417 minecraft:red_concrete
fill 334 200 457 336 200 457 minecraft:red_concrete
fill 337 200 417 338 200 417 minecraft:red_concrete
fill 338 200 457 339 200 457 minecraft:red_concrete
fill 340 200 417 342 200 417 minecraft:red_concrete
fill 341 200 457 343 200 457 minecraft:red_concrete
fill 344 200 417 345 200 417 minecraft:red_concrete
fill 345 200 457 346 200 457 minecraft:red_concrete
fill 347 200 417 349 200 417 minecraft:red_concrete
fill 348 200 457 350 200 457 minecraft:red_concrete
fill 351 200 417 352 200 417 minecraft:red_concrete
fill 351 200 418 352 201 420 minecraft:white_wool
fill 352 200 457 353 200 457 minecraft:red_concrete
fill 354 200 417 356 200 417 minecraft:red_concrete
fill 355 200 457 357 200 457 minecraft:red_concrete
fill 358 200 417 359 200 417 minecraft:red_concrete
fill 359 200 457 360 200 457 minecraft:red_concrete
fill 361 200 417 363 200 417 minecraft:red_concrete
fill 362 200 457 364 200 457 minecraft:red_concrete
fill 365 200 417 366 200 417 minecraft:red_concrete
fill 366 200 457 367 200 457 minecraft:red_concrete
fill 368 200 417 370 200 417 minecraft:red_concrete
fill 369 200 457 370 200 457 minecraft:red_concrete
fill 370 200 419 370 200 420 minecraft:red_concrete
fill 370 200 422 370 200 424 minecraft:red_concrete
fill 370 200 426 370 200 427 minecraft:red_concrete
fill 370 200 429 370 200 431 minecraft:red_concrete
fill 370 200 433 370 200 434 minecraft:red_concrete
fill 370 200 436 370 200 438 minecraft:red_concrete
fill 370 200 440 370 200 441 minecraft:red_concrete
fill 370 200 443 370 200 445 minecraft:red_concrete
fill 370 200 447 370 200 448 minecraft:red_concrete
fill 370 200 450 370 200 452 minecraft:red_concrete
fill 370 200 454 370 200 455 minecraft:red_concrete
setblock 330 201 420 minecraft:red_concrete
setblock 330 201 427 minecraft:red_concrete
setblock 330 201 434 minecraft:red_concrete
setblock 330 201 441 minecraft:red_concrete
setblock 330 201 448 minecraft:red_concrete
setblock 330 201 455 minecraft:red_concrete
setblock 334 201 417 minecraft:red_concrete
setblock 335 201 457 minecraft:red_concrete
setblock 341 201 417 minecraft:red_concrete
setblock 342 201 457 minecraft:red_concrete
setblock 348 201 417 minecraft:red_concrete
setblock 349 201 457 minecraft:red_concrete
setblock 355 201 417 minecraft:red_concrete
setblock 356 201 457 minecraft:red_concrete
setblock 362 201 417 minecraft:red_concrete
setblock 363 201 457 minecraft:red_concrete
setblock 369 201 417 minecraft:red_concrete
setblock 370 201 423 minecraft:red_concrete
setblock 370 201 430 minecraft:red_concrete
setblock 370 201 437 minecraft:red_concrete
setblock 370 201 444 minecraft:red_concrete
setblock 370 201 451 minecraft:red_concrete
setblock 370 201 457 minecraft:red_concrete
setblock 330 202 421 minecraft:red_concrete
setblock 330 202 428 minecraft:red_concrete
setblock 330 202 435 minecraft:red_concrete
setblock 330 202 442 minecraft:red_concrete
setblock 330 202 449 minecraft:red_concrete
setblock 330 202 456 minecraft:red_concrete
setblock 333 202 417 minecraft:red_concrete
setblock 336 202 457 minecraft:red_concrete
setblock 340 202 417 minecraft:red_concrete
setblock 343 202 457 minecraft:red_concrete
setblock 347 202 417 minecraft:red_concrete
setblock 350 202 457 minecraft:red_concrete
setblock 354 202 417 minecraft:red_concrete
setblock 357 202 457 minecraft:red_concrete
setblock 361 202 417 minecraft:red_concrete
setblock 364 202 457 minecraft:red_concrete
setblock 368 202 417 minecraft:red_concrete
setblock 370 202 422 minecraft:red_concrete
setblock 370 202 429 minecraft:red_concrete
setblock 370 202 436 minecraft:red_concrete
setblock 370 202 443 minecraft:red_concrete
setblock 370 202 450 minecraft:red_concrete
setblock 330 204 423 minecraft:red_concrete
setblock 330 204 430 minecraft:red_concrete
setblock 330 204 437 minecraft:red_concrete
setblock 330 204 444 minecraft:red_concrete
setblock 330 204 451 minecraft:red_concrete
setblock 331 204 417 minecraft:red_concrete
setblock 331 204 457 minecraft:red_concrete
setblock 338 204 417 minecraft:red_concrete
setblock 338 204 457 minecraft:red_concrete
setblock 345 204 417 minecraft:red_concrete
setblock 345 204 457 minecraft:red_concrete
setblock 352 204 417 minecraft:red_concrete
setblock 352 204 457 minecraft:red_concrete
setblock 359 204 417 minecraft:red_concrete
setblock 359 204 457 minecraft:red_concrete
setblock 366 204 417 minecraft:red_concrete
setblock 366 204 457 minecraft:red_concrete
setblock 370 204 420 minecraft:red_concrete
setblock 370 204 427 minecraft:red_concrete
setblock 370 204 434 minecraft:red_concrete
setblock 370 204 441 minecraft:red_concrete
setblock 370 204 448 minecraft:red_concrete
setblock 370 204 455 minecraft:red_concrete
setblock 330 205 417 minecraft:red_concrete
setblock 330 205 424 minecraft:red_concrete
setblock 330 205 431 minecraft:red_concrete
setblock 330 205 438 minecraft:red_concrete
setblock 330 205 445 minecraft:red_concrete
setblock 330 205 452 minecraft:red_concrete
setblock 332 205 457 minecraft:red_concrete
setblock 337 205 417 minecraft:red_concrete
setblock 339 205 457 minecraft:red_concrete
setblock 344 205 417 minecraft:red_concrete
setblock 346 205 457 minecraft:red_concrete
setblock 351 205 417 minecraft:red_concrete
setblock 353 205 457 minecraft:red_concrete
setblock 358 205 417 minecraft:red_concrete
setblock 360 205 457 minecraft:red_concrete
setblock 365 205 417 minecraft:red_concrete
setblock 367 205 457 minecraft:red_concrete
setblock 370 205 419 minecraft:red_concrete
setblock 370 205 426 minecraft:red_concrete
setblock 370 205 433 minecraft:red_concrete
setblock 370 205 440 minecraft:red_concrete
setblock 370 205 447 minecraft:red_concrete
setblock 370 205 454 minecraft:red_concrete
setblock 329 206 417 minecraft:black_concrete
fill 329 206 442 329 209 444 minecraft:purple_terracotta
setblock 329 206 445 minecraft:black_concrete
fill 329 206 446 329 209 446 minecraft:purple_terracotta
setblock 329 206 447 minecraft:black_concrete
fill 329 206 448 329 207 449 minecraft:purple_terracotta
setblock 330 206 418 minecraft:red_concrete
setblock 330 206 425 minecraft:red_concrete
setblock 330 206 432 minecraft:red_concrete
setblock 330 206 439 minecraft:red_concrete
setblock 330 206 446 minecraft:red_concrete
setblock 330 206 453 minecraft:red_concrete
setblock 332 206 419 minecraft:light[level=12]
setblock 332 206 427 minecraft:light[level=12]
setblock 332 206 435 minecraft:light[level=12]
setblock 332 206 443 minecraft:light[level=12]
setblock 332 206 451 minecraft:light[level=12]
setblock 333 206 457 minecraft:red_concrete
fill 334 206 458 341 209 458 minecraft:purple_terracotta
setblock 336 206 417 minecraft:red_concrete
setblock 340 206 419 minecraft:light[level=12]
setblock 340 206 427 minecraft:light[level=12]
setblock 340 206 435 minecraft:light[level=12]
setblock 340 206 443 minecraft:light[level=12]
setblock 340 206 451 minecraft:light[level=12]
setblock 340 206 457 minecraft:red_concrete
setblock 341 206 416 minecraft:black_concrete
setblock 342 206 458 minecraft:black_concrete
setblock 343 206 417 minecraft:red_concrete
fill 343 206 458 344 209 458 minecraft:purple_terracotta
fill 346 206 458 350 206 458 minecraft:purple_terracotta
setblock 347 206 457 minecraft:red_concrete
setblock 348 206 419 minecraft:light[level=12]
setblock 348 206 427 minecraft:light[level=12]
setblock 348 206 435 minecraft:light[level=12]
setblock 348 206 443 minecraft:light[level=12]
setblock 348 206 451 minecraft:light[level=12]
setblock 350 206 417 minecraft:red_concrete
fill 351 206 458 352 206 458 minecraft:black_concrete
fill 353 206 458 357 206 458 minecraft:purple_terracotta
setblock 354 206 457 minecraft:red_concrete
setblock 356 206 419 minecraft:light[level=12]
setblock 356 206 427 minecraft:light[level=12]
setblock 356 206 435 minecraft:light[level=12]
setblock 356 206 443 minecraft:light[level=12]
setblock 356 206 451 minecraft:light[level=12]
fill 357 206 416 361 206 416 minecraft:purple_terracotta
setblock 357 206 417 minecraft:red_concrete
fill 359 206 458 360 206 458 minecraft:purple_terracotta
setblock 361 206 457 minecraft:red_concrete
fill 361 206 458 363 206 458 minecraft:black_concrete
fill 362 206 416 362 207 416 minecraft:black_concrete
fill 363 206 416 364 209 416 minecraft:purple_terracotta
setblock 364 206 417 minecraft:red_concrete
setblock 364 206 419 minecraft:light[level=12]
setblock 364 206 427 minecraft:light[level=12]
setblock 364 206 435 minecraft:light[level=12]
setblock 364 206 443 minecraft:light[level=12]
setblock 364 206 451 minecraft:light[level=12]
fill 364 206 458 364 207 458 minecraft:purple_terracotta
setblock 368 206 457 minecraft:red_concrete
setblock 370 206 416 minecraft:black_concrete
setblock 370 206 418 minecraft:red_concrete
setblock 370 206 425 minecraft:red_concrete
setblock 370 206 432 minecraft:red_concrete
setblock 370 206 439 minecraft:red_concrete
setblock 370 206 446 minecraft:red_concrete
setblock 370 206 453 minecraft:red_concrete
fill 371 206 426 371 209 429 minecraft:purple_terracotta
setblock 371 206 430 minecraft:black_concrete
fill 371 206 431 371 207 432 minecraft:purple_terracotta
fill 371 206 434 371 209 436 minecraft:purple_terracotta
setblock 371 206 437 minecraft:black_concrete
fill 371 206 438 371 209 441 minecraft:purple_terracotta
fill 371 206 443 371 206 444 minecraft:black_concrete
fill 371 206 445 371 207 447 minecraft:purple_terracotta
fill 371 206 448 371 208 448 minecraft:black_concrete
fill 371 206 449 371 207 451 minecraft:purple_terracotta
fill 371 206 457 371 209 457 minecraft:purple_terracotta
setblock 371 206 458 minecraft:black_concrete
fill 329 207 417 329 209 417 minecraft:purple_terracotta
setblock 329 207 422 minecraft:black_concrete
setblock 329 207 429 minecraft:black_concrete
fill 329 207 430 329 209 432 minecraft:purple_terracotta
fill 329 207 445 329 209 445 minecraft:purple_terracotta
fill 329 207 447 329 209 447 minecraft:purple_terracotta
fill 329 207 452 329 207 454 minecraft:purple_terracotta
setblock 329 207 455 minecraft:black_concrete
fill 329 207 456 329 209 457 minecraft:purple_terracotta
setblock 330 207 419 minecraft:red_concrete
setblock 330 207 426 minecraft:red_concrete
setblock 330 207 433 minecraft:red_concrete
setblock 330 207 440 minecraft:red_concrete
setblock 330 207 447 minecraft:red_concrete
setblock 330 207 454 minecraft:red_concrete
setblock 334 207 457 minecraft:red_concrete
setblock 335 207 417 minecraft:red_concrete
fill 341 207 416 341 210 416 minecraft:purple_terracotta
setblock 341 207 457 minecraft:red_concrete
setblock 342 207 416 minecraft:black_concrete
setblock 342 207 417 minecraft:red_concrete
fill 342 207 458 342 210 458 minecraft:purple_terracotta
fill 343 207 416 347 207 416 minecraft:purple_terracotta
fill 346 207 458 347 209 458 minecraft:purple_terracotta
setblock 348 207 416 minecraft:black_concrete
setblock 348 207 457 minecraft:red_concrete
fill 348 207 458 348 208 458 minecraft:black_concrete
setblock 349 207 417 minecraft:red_concrete
fill 349 207 458 350 207 458 minecraft:purple_terracotta
setblock 351 207 458 minecraft:black_concrete
fill 352 207 458 353 209 458 minecraft:purple_terracotta
fill 354 207 458 354 208 458 minecraft:black_concrete
setblock 355 207 457 minecraft:red_concrete
fill 355 207 458 355 209 458 minecraft:purple_terracotta
fill 356 207 416 357 207 416 minecraft:black_concrete
setblock 356 207 417 minecraft:red_concrete
setblock 356 207 458 minecraft:black_concrete
setblock 357 207 458 minecraft:purple_terracotta
fill 358 207 416 361 207 416 minecraft:purple_terracotta
fill 359 207 458 359 209 458 minecraft:purple_terracotta
setblock 360 207 458 minecraft:black_concrete
fill 361 207 458 363 209 458 minecraft:purple_terracotta
setblock 362 207 457 minecraft:red_concrete
setblock 363 207 417 minecraft:red_concrete
setblock 369 207 457 minecraft:red_concrete
fill 370 207 416 370 209 416 minecraft:purple_terracotta
setblock 370 207 417 minecraft:red_concrete
setblock 370 207 424 minecraft:red_concrete
setblock 370 207 431 minecraft:red_concrete
setblock 370 207 438 minecraft:red_concrete
setblock 370 207 445 minecraft:red_concrete
setblock 370 207 452 minecraft:red_concrete
fill 371 207 419 371 208 419 minecraft:black_concrete
fill 371 207 430 371 209 430 minecraft:purple_terracotta
fill 371 207 437 371 209 437 minecraft:purple_terracotta
fill 371 207 443 371 209 444 minecraft:purple_terracotta
setblock 371 207 458 minecraft:purple_terracotta
setblock 329 208 416 minecraft:black_concrete
setblock 329 208 418 minecraft:black_concrete
fill 329 208 419 329 209 419 minecraft:purple_terracotta
setblock 329 208 420 minecraft:black_concrete
fill 329 208 422 329 210 422 minecraft:purple_terracotta
fill 329 208 429 329 209 429 minecraft:purple_terracotta
fill 329 208 434 329 209 435 minecraft:purple_terracotta
fill 329 208 436 329 208 437 minecraft:black_concrete
fill 329 208 448 329 208 450 minecraft:black_concrete
fill 329 208 451 329 209 451 minecraft:purple_terracotta
setblock 329 208 452 minecraft:black_concrete
fill 329 208 453 329 209 455 minecraft:purple_terracotta
fill 330 208 416 330 209 416 minecraft:purple_terracotta
setblock 330 208 420 minecraft:red_concrete
setblock 330 208 427 minecraft:red_concrete
setblock 330 208 434 minecraft:red_concrete
setblock 330 208 441 minecraft:red_concrete
setblock 330 208 448 minecraft:red_concrete
setblock 330 208 455 minecraft:red_concrete
setblock 334 208 417 minecraft:red_concrete
setblock 335 208 457 minecraft:red_concrete
setblock 341 208 417 minecraft:red_concrete
fill 342 208 416 345 209 416 minecraft:purple_terracotta
setblock 342 208 457 minecraft:red_concrete
setblock 346 208 416 minecraft:black_concrete
fill 347 208 416 348 209 416 minecraft:purple_terracotta
setblock 348 208 417 minecraft:red_concrete
setblock 349 208 457 minecraft:red_concrete
setblock 349 208 458 minecraft:black_concrete
fill 350 208 458 351 209 458 minecraft:purple_terracotta
fill 354 208 416 354 209 416 minecraft:purple_terracotta
setblock 355 208 416 minecraft:black_concrete
setblock 355 208 417 minecraft:red_concrete
fill 356 208 416 358 209 416 minecraft:purple_terracotta
setblock 356 208 457 minecraft:red_concrete
fill 356 208 458 356 209 458 minecraft:purple_terracotta
setblock 357 208 458 minecraft:black_concrete
setblock 359 208 416 minecraft:black_concrete
fill 360 208 416 360 209 416 minecraft:purple_terracotta
fill 360 208 458 360 209 458 minecraft:purple_terracotta
setblock 361 208 416 minecraft:black_concrete
fill 362 208 416 362 209 416 minecraft:purple_terracotta
setblock 362 208 417 minecraft:red_concrete
setblock 363 208 457 minecraft:red_concrete
setblock 364 208 458 minecraft:black_concrete
fill 365 208 416 366 209 416 minecraft:purple_terracotta
setblock 367 208 416 minecraft:black_concrete
fill 368 208 416 369 209 416 minecraft:purple_terracotta
setblock 369 208 417 minecraft:red_concrete
setblock 370 208 423 minecraft:red_concrete
setblock 370 208 430 minecraft:red_concrete
setblock 370 208 437 minecraft:red_concrete
setblock 370 208 444 minecraft:red_concrete
setblock 370 208 451 minecraft:red_concrete
setblock 370 208 457 minecraft:red_concrete
setblock 371 208 422 minecraft:black_concrete
setblock 371 208 424 minecraft:black_concrete
setblock 371 208 431 minecraft:black_concrete
fill 371 208 432 371 209 432 minecraft:purple_terracotta
fill 371 208 445 371 209 446 minecraft:purple_terracotta
setblock 371 208 447 minecraft:black_concrete
setblock 371 208 449 minecraft:black_concrete
fill 371 208 450 371 209 451 minecraft:purple_terracotta
setblock 371 208 458 minecraft:black_concrete
fill 329 209 416 329 210 416 minecraft:purple_terracotta
setblock 329 209 418 minecraft:purple_terracotta
setblock 329 209 420 minecraft:purple_terracotta
fill 329 209 436 329 209 437 minecraft:purple_terracotta
fill 329 209 448 329 209 450 minecraft:purple_terracotta
fill 329 209 452 329 210 452 minecraft:purple_terracotta
fill 330 209 421 330 210 421 minecraft:red_concrete
fill 330 209 428 330 210 428 minecraft:red_concrete
fill 330 209 435 330 210 435 minecraft:red_concrete
fill 330 209 442 330 210 442 minecraft:red_concrete
fill 330 209 449 330 210 449 minecraft:red_concrete
fill 330 209 456 330 210 456 minecraft:red_concrete
fill 333 209 417 333 210 417 minecraft:red_concrete
fill 336 209 457 336 210 457 minecraft:red_concrete
fill 340 209 417 340 210 417 minecraft:red_concrete
fill 341 209 418 347 210 418 minecraft:gray_concrete
fill 343 209 457 343 210 457 minecraft:red_concrete
setblock 346 209 416 minecraft:purple_terracotta
fill 347 209 417 347 210 417 minecraft:red_concrete
fill 348 209 458 349 209 458 minecraft:purple_terracotta
fill 350 209 457 350 210 457 minecraft:red_concrete
fill 354 209 417 354 210 417 minecraft:red_concrete
setblock 354 209 458 minecraft:purple_terracotta
fill 355 209 416 355 210 416 minecraft:purple_terracotta
fill 357 209 457 357 210 457 minecraft:red_concrete
fill 357 209 458 357 210 458 minecraft:purple_terracotta
setblock 359 209 416 minecraft:purple_terracotta
fill 361 209 416 361 211 416 minecraft:purple_terracotta
fill 361 209 417 361 210 417 minecraft:red_concrete
fill 364 209 457 364 210 457 minecraft:red_concrete
setblock 364 209 458 minecraft:purple_terracotta
setblock 367 209 416 minecraft:purple_terracotta
fill 368 209 417 368 210 417 minecraft:red_concrete
fill 370 209 422 370 210 422 minecraft:red_concrete
fill 370 209 429 370 210 429 minecraft:red_concrete
fill 370 209 436 370 210 436 minecraft:red_concrete
fill 370 209 443 370 210 443 minecraft:red_concrete
fill 370 209 450 370 210 450 minecraft:red_concrete
setblock 371 209 419 minecraft:purple_terracotta
setblock 371 209 422 minecraft:purple_terracotta
setblock 371 209 424 minecraft:purple_terracotta
setblock 371 209 431 minecraft:purple_terracotta
fill 371 209 447 371 209 449 minecraft:purple_terracotta
setblock 371 209 458 minecraft:purple_terracotta
fill 329 210 417 329 210 421 minecraft:black_concrete
fill 329 210 423 329 211 435 minecraft:black_concrete
setblock 329 210 436 minecraft:purple_terracotta
fill 329 210 437 329 211 451 minecraft:black_concrete
fill 329 210 453 329 307 458 minecraft:black_concrete
fill 330 210 416 337 210 416 minecraft:black_concrete
fill 330 210 417 330 210 420 minecraft:red_concrete
fill 330 210 423 330 210 427 minecraft:red_concrete
fill 330 210 430 330 210 434 minecraft:red_concrete
fill 330 210 437 330 210 441 minecraft:red_concrete
fill 330 210 444 330 210 448 minecraft:red_concrete
fill 330 210 451 330 210 455 minecraft:red_concrete
fill 330 210 458 334 210 458 minecraft:black_concrete
fill 331 210 417 331 211 417 minecraft:red_concrete
fill 331 210 457 335 210 457 minecraft:red_concrete
fill 334 210 417 338 210 417 minecraft:red_concrete
fill 335 210 458 336 210 458 minecraft:purple_terracotta
fill 337 210 458 341 211 458 minecraft:black_concrete
setblock 338 210 416 minecraft:purple_terracotta
fill 338 210 457 342 210 457 minecraft:red_concrete
fill 339 210 416 340 307 416 minecraft:black_concrete
fill 341 210 417 345 210 417 minecraft:red_concrete
fill 342 210 416 349 211 416 minecraft:black_concrete
fill 343 210 458 345 307 458 minecraft:black_concrete
fill 345 210 457 349 210 457 minecraft:red_concrete
setblock 346 210 458 minecraft:purple_terracotta
fill 347 210 458 347 307 458 minecraft:black_concrete
fill 348 210 417 352 210 417 minecraft:red_concrete
fill 348 210 458 348 211 458 minecraft:purple_terracotta
fill 349 210 458 349 307 458 minecraft:black_concrete
fill 350 210 416 352 210 416 minecraft:purple_terracotta
setblock 350 210 458 minecraft:purple_terracotta
fill 351 210 458 356 210 458 minecraft:black_concrete
fill 352 210 457 356 210 457 minecraft:red_concrete
fill 353 210 416 354 211 416 minecraft:black_concrete
fill 355 210 417 359 210 417 minecraft:red_concrete
fill 356 210 416 360 307 416 minecraft:black_concrete
fill 358 210 458 366 210 458 minecraft:black_concrete
fill 359 210 457 363 210 457 minecraft:red_concrete
setblock 362 210 416 minecraft:black_concrete
fill 362 210 417 366 210 417 minecraft:red_concrete
setblock 363 210 416 minecraft:purple_terracotta
fill 364 210 416 371 307 416 minecraft:black_concrete
fill 366 210 457 370 210 457 minecraft:red_concrete
setblock 367 210 458 minecraft:purple_terracotta
fill 368 210 458 371 211 458 minecraft:black_concrete
fill 369 210 417 370 210 417 minecraft:red_concrete
fill 370 210 418 370 210 420 minecraft:red_concrete
fill 370 210 423 370 210 427 minecraft:red_concrete
fill 370 210 430 370 210 434 minecraft:red_concrete
fill 370 210 437 370 210 441 minecraft:red_concrete
fill 370 210 444 370 210 448 minecraft:red_concrete
fill 370 210 451 370 210 455 minecraft:red_concrete
setblock 371 210 417 minecraft:purple_terracotta
fill 371 210 418 371 307 419 minecraft:black_concrete
fill 371 210 421 371 210 450 minecraft:black_concrete
setblock 371 210 451 minecraft:purple_terracotta
fill 371 210 452 371 211 452 minecraft:black_concrete
setblock 371 210 453 minecraft:purple_terracotta
fill 371 210 454 371 211 457 minecraft:black_concrete
fill 329 211 416 332 307 416 minecraft:black_concrete
setblock 329 211 417 minecraft:purple_terracotta
fill 329 211 418 329 211 422 minecraft:black_concrete
fill 329 211 436 329 307 436 minecraft:black_concrete
fill 329 211 452 329 307 452 minecraft:black_concrete
setblock 330 211 423 minecraft:red_concrete
setblock 330 211 430 minecraft:red_concrete
setblock 330 211 437 minecraft:red_concrete
setblock 330 211 444 minecraft:red_concrete
setblock 330 211 451 minecraft:red_concrete
setblock 330 211 458 minecraft:black_concrete
setblock 331 211 457 minecraft:red_concrete
setblock 331 211 458 minecraft:purple_terracotta
fill 332 211 458 336 307 458 minecraft:black_concrete
setblock 333 211 416 minecraft:purple_terracotta
fill 334 211 416 338 211 416 minecraft:black_concrete
setblock 338 211 417 minecraft:red_concrete
setblock 338 211 457 minecraft:red_concrete
setblock 341 211 416 minecraft:black_concrete
fill 342 211 458 342 307 458 minecraft:black_concrete
setblock 345 211 417 minecraft:red_concrete
setblock 345 211 457 minecraft:red_concrete
fill 346 211 458 346 307 458 minecraft:black_concrete
fill 350 211 416 352 211 416 minecraft:black_concrete
fill 350 211 458 351 307 458 minecraft:black_concrete
setblock 352 211 417 minecraft:red_concrete
setblock 352 211 457 minecraft:red_concrete
fill 352 211 458 353 211 458 minecraft:purple_terracotta
fill 354 211 458 361 307 458 minecraft:black_concrete
fill 355 211 416 355 307 416 minecraft:black_concrete
setblock 359 211 417 minecraft:red_concrete
setblock 359 211 457 minecraft:red_concrete
setblock 362 211 416 minecraft:purple_terracotta
setblock 362 211 458 minecraft:purple_terracotta
fill 363 211 416 363 307 416 minecraft:black_concrete
fill 363 211 458 367 307 458 minecraft:black_concrete
setblock 366 211 417 minecraft:red_concrete
setblock 366 211 457 minecraft:red_concrete
setblock 370 211 420 minecraft:red_concrete
setblock 370 211 427 minecraft:red_concrete
setblock 370 211 434 minecraft:red_concrete
setblock 370 211 441 minecraft:red_concrete
setblock 370 211 448 minecraft:red_concrete
setblock 370 211 455 minecraft:red_concrete
fill 371 211 417 371 307 417 minecraft:black_concrete
fill 371 211 420 371 211 432 minecraft:black_concrete
setblock 371 211 433 minecraft:purple_terracotta
fill 371 211 434 371 211 451 minecraft:black_concrete
fill 371 211 453 371 307 453 minecraft:black_concrete
fill 329 212 417 329 307 417 minecraft:black_concrete
setblock 329 212 418 minecraft:purple_terracotta
fill 329 212 419 329 307 434 minecraft:black_concrete
setblock 329 212 435 minecraft:purple_terracotta
fill 329 212 437 329 307 439 minecraft:black_concrete
fill 329 212 440 329 212 441 minecraft:purple_terracotta
fill 329 212 442 329 307 443 minecraft:black_concrete
setblock 329 212 444 minecraft:purple_terracotta
fill 329 212 445 329 307 450 minecraft:black_concrete
setblock 329 212 451 minecraft:purple_terracotta
setblock 330 212 417 minecraft:red_concrete
setblock 330 212 424 minecraft:red_concrete
setblock 330 212 431 minecraft:red_concrete
setblock 330 212 438 minecraft:red_concrete
setblock 330 212 445 minecraft:red_concrete
setblock 330 212 452 minecraft:red_concrete
setblock 330 212 458 minecraft:purple_terracotta
fill 331 212 458 331 307 458 minecraft:black_concrete
setblock 332 212 457 minecraft:red_concrete
fill 333 212 416 334 307 416 minecraft:black_concrete
setblock 335 212 416 minecraft:purple_terracotta
fill 336 212 416 337 307 416 minecraft:black_concrete
setblock 337 212 417 minecraft:red_concrete
fill 337 212 458 339 307 458 minecraft:black_concrete
setblock 338 212 416 minecraft:purple_terracotta
setblock 339 212 457 minecraft:red_concrete
setblock 340 212 458 minecraft:purple_terracotta
setblock 341 212 416 minecraft:purple_terracotta
fill 341 212 458 341 307 458 minecraft:black_concrete
fill 342 212 416 346 307 416 minecraft:black_concrete
setblock 344 212 417 minecraft:red_concrete
setblock 346 212 457 minecraft:red_concrete
setblock 347 212 416 minecraft:purple_terracotta
fill 348 212 416 349 307 416 minecraft:black_concrete
fill 348 212 458 348 307 458 minecraft:black_concrete
setblock 350 212 416 minecraft:purple_terracotta
fill 351 212 416 352 307 416 minecraft:black_concrete
setblock 351 212 417 minecraft:red_concrete
fill 352 212 458 353 307 458 minecraft:black_concrete
setblock 353 212 416 minecraft:purple_terracotta
setblock 353 212 457 minecraft:red_concrete
fill 354 212 416 354 307 416 minecraft:black_concrete
fill 355 212 430 355 213 431 minecraft:white_wool
setblock 358 212 417 minecraft:red_concrete
setblock 360 212 457 minecraft:red_concrete
fill 361 212 416 362 307 416 minecraft:black_concrete
fill 362 212 458 362 307 458 minecraft:black_concrete
setblock 365 212 417 minecraft:red_concrete
setblock 367 212 457 minecraft:red_concrete
fill 368 212 458 370 307 458 minecraft:black_concrete
setblock 370 212 419 minecraft:red_concrete
setblock 370 212 426 minecraft:red_concrete
setblock 370 212 433 minecraft:red_concrete
setblock 370 212 440 minecraft:red_concrete
setblock 370 212 447 minecraft:red_concrete
setblock 370 212 454 minecraft:red_concrete
setblock 371 212 420 minecraft:purple_terracotta
fill 371 212 421 371 307 424 minecraft:black_concrete
setblock 371 212 425 minecraft:purple_terracotta
fill 371 212 426 371 307 429 minecraft:black_concrete
setblock 371 212 430 minecraft:purple_terracotta
fill 371 212 431 371 307 440 minecraft:black_concrete
setblock 371 212 441 minecraft:purple_terracotta
fill 371 212 442 371 307 451 minecraft:black_concrete
setblock 371 212 452 minecraft:purple_terracotta
fill 371 212 454 371 307 455 minecraft:black_concrete
setblock 371 212 456 minecraft:purple_terracotta
fill 371 212 457 371 307 457 minecraft:black_concrete
setblock 371 212 458 minecraft:purple_terracotta
fill 329 213 418 329 307 418 minecraft:black_concrete
fill 329 213 435 329 307 435 minecraft:black_concrete
fill 329 213 440 329 307 441 minecraft:black_concrete
fill 329 213 444 329 307 444 minecraft:black_concrete
fill 329 213 451 329 307 451 minecraft:black_concrete
setblock 330 213 418 minecraft:red_concrete
setblock 330 213 425 minecraft:red_concrete
setblock 330 213 432 minecraft:red_concrete
setblock 330 213 439 minecraft:red_concrete
setblock 330 213 446 minecraft:red_concrete
setblock 330 213 453 minecraft:red_concrete
fill 330 213 458 330 307 458 minecraft:black_concrete
setblock 333 213 457 minecraft:red_concrete
fill 335 213 416 335 307 416 minecraft:black_concrete
setblock 336 213 417 minecraft:red_concrete
fill 338 213 416 338 307 416 minecraft:black_concrete
setblock 340 213 457 minecraft:red_concrete
fill 340 213 458 340 307 458 minecraft:black_concrete
fill 341 213 416 341 307 416 minecraft:black_concrete
setblock 343 213 417 minecraft:red_concrete
fill 347 213 416 347 307 416 minecraft:black_concrete
setblock 347 213 457 minecraft:red_concrete
fill 350 213 416 350 307 416 minecraft:black_concrete
setblock 350 213 417 minecraft:red_concrete
fill 353 213 416 353 307 416 minecraft:black_concrete
setblock 354 213 457 minecraft:red_concrete
setblock 357 213 417 minecraft:red_concrete
setblock 361 213 457 minecraft:red_concrete
setblock 364 213 417 minecraft:red_concrete
setblock 368 213 457 minecraft:red_concrete
setblock 370 213 418 minecraft:red_concrete
setblock 370 213 425 minecraft:red_concrete
setblock 370 213 432 minecraft:red_concrete
setblock 370 213 439 minecraft:red_concrete
setblock 370 213 446 minecraft:red_concrete
setblock 370 213 453 minecraft:red_concrete
fill 371 213 420 371 307 420 minecraft:black_concrete
fill 371 213 425 371 307 425 minecraft:black_concrete
fill 371 213 430 371 307 430 minecraft:black_concrete
fill 371 213 441 371 307 441 minecraft:black_concrete
fill 371 213 452 371 307 452 minecraft:black_concrete
fill 371 213 456 371 307 456 minecraft:black_concrete
fill 371 213 458 371 307 458 minecraft:black_concrete
setblock 330 214 419 minecraft:red_concrete
setblock 330 214 426 minecraft:red_concrete
setblock 330 214 433 minecraft:red_concrete
setblock 330 214 440 minecraft:red_concrete
setblock 330 214 447 minecraft:red_concrete
setblock 330 214 454 minecraft:red_concrete
setblock 332 214 419 minecraft:light[level=12]
setblock 332 214 427 minecraft:light[level=12]
setblock 332 214 435 minecraft:light[level=12]
setblock 332 214 443 minecraft:light[level=12]
setblock 332 214 451 minecraft:light[level=12]
setblock 334 214 457 minecraft:red_concrete
setblock 335 214 417 minecraft:red_concrete
setblock 340 214 419 minecraft:light[level=12]
setblock 340 214 427 minecraft:light[level=12]
setblock 340 214 435 minecraft:light[level=12]
setblock 340 214 443 minecraft:light[level=12]
setblock 340 214 451 minecraft:light[level=12]
setblock 341 214 457 minecraft:red_concrete
setblock 342 214 417 minecraft:red_concrete
setblock 348 214 419 minecraft:light[level=12]
setblock 348 214 427 minecraft:light[level=12]
setblock 348 214 435 minecraft:light[level=12]
setblock 348 214 443 minecraft:light[level=12]
setblock 348 214 451 minecraft:light[level=12]
setblock 348 214 457 minecraft:red_concrete
setblock 349 214 417 minecraft:red_concrete
setblock 355 214 457 minecraft:red_concrete
setblock 356 214 417 minecraft:red_concrete
setblock 356 214 419 minecraft:light[level=12]
setblock 356 214 427 minecraft:light[level=12]
setblock 356 214 435 minecraft:light[level=12]
setblock 356 214 443 minecraft:light[level=12]
setblock 356 214 451 minecraft:light[level=12]
setblock 362 214 457 minecraft:red_concrete
setblock 363 214 417 minecraft:red_concrete
setblock 364 214 419 minecraft:light[level=12]
setblock 364 214 427 minecraft:light[level=12]
setblock 364 214 435 minecraft:light[level=12]
setblock 364 214 443 minecraft:light[level=12]
setblock 364 214 451 minecraft:light[level=12]
setblock 369 214 457 minecraft:red_concrete
setblock 370 214 417 minecraft:red_concrete
setblock 370 214 424 minecraft:red_concrete
setblock 370 214 431 minecraft:red_concrete
setblock 370 214 438 minecraft:red_concrete
setblock 370 214 445 minecraft:red_concrete
setblock 370 214 452 minecraft:red_concrete
setblock 330 215 420 minecraft:red_concrete
setblock 330 215 427 minecraft:red_concrete
setblock 330 215 434 minecraft:red_concrete
setblock 330 215 441 minecraft:red_concrete
setblock 330 215 448 minecraft:red_concrete
setblock 330 215 455 minecraft:red_concrete
setblock 334 215 417 minecraft:red_concrete
setblock 335 215 457 minecraft:red_concrete
setblock 341 215 417 minecraft:red_concrete
setblock 342 215 457 minecraft:red_concrete
setblock 348 215 417 minecraft:red_concrete
setblock 349 215 457 minecraft:red_concrete
setblock 355 215 417 minecraft:red_concrete
setblock 356 215 457 minecraft:red_concrete
setblock 362 215 417 minecraft:red_concrete
setblock 363 215 457 minecraft:red_concrete
setblock 369 215 417 minecraft:red_concrete
setblock 370 215 423 minecraft:red_concrete
setblock 370 215 430 minecraft:red_concrete
setblock 370 215 437 minecraft:red_concrete
setblock 370 215 444 minecraft:red_concrete
setblock 370 215 451 minecraft:red_concrete
setblock 370 215 457 minecraft:red_concrete
setblock 330 216 421 minecraft:red_concrete
setblock 330 216 428 minecraft:red_concrete
setblock 330 216 435 minecraft:red_concrete
setblock 330 216 442 minecraft:red_concrete
setblock 330 216 449 minecraft:red_concrete
setblock 330 216 456 minecraft:red_concrete
setblock 333 216 417 minecraft:red_concrete
setblock 336 216 457 minecraft:red_concrete
setblock 340 216 417 minecraft:red_concrete
setblock 343 216 457 minecraft:red_concrete
setblock 347 216 417 minecraft:red_concrete
setblock 350 216 457 minecraft:red_concrete
setblock 354 216 417 minecraft:red_concrete
setblock 357 216 457 minecraft:red_concrete
setblock 361 216 417 minecraft:red_concrete
setblock 364 216 457 minecraft:red_concrete
setblock 368 216 417 minecraft:red_concrete
setblock 370 216 422 minecraft:red_concrete
setblock 370 216 429 minecraft:red_concrete
setblock 370 216 436 minecraft:red_concrete
setblock 370 216 443 minecraft:red_concrete
setblock 370 216 450 minecraft:red_concrete
setblock 330 218 423 minecraft:red_concrete
setblock 330 218 430 minecraft:red_concrete
setblock 330 218 437 minecraft:red_concrete
setblock 330 218 444 minecraft:red_concrete
setblock 330 218 451 minecraft:red_concrete
setblock 331 218 417 minecraft:red_concrete
setblock 331 218 457 minecraft:red_concrete
setblock 338 218 417 minecraft:red_concrete
setblock 338 218 457 minecraft:red_concrete
setblock 345 218 417 minecraft:red_concrete
setblock 345 218 457 minecraft:red_concrete
setblock 352 218 417 minecraft:red_concrete
setblock 352 218 457 minecraft:red_concrete
setblock 359 218 417 minecraft:red_concrete
setblock 359 218 457 minecraft:red_concrete
setblock 366 218 417 minecraft:red_concrete
setblock 366 218 457 minecraft:red_concrete
setblock 370 218 420 minecraft:red_concrete
setblock 370 218 427 minecraft:red_concrete
setblock 370 218 434 minecraft:red_concrete
setblock 370 218 441 minecraft:red_concrete
setblock 370 218 448 minecraft:red_concrete
setblock 370 218 455 minecraft:red_concrete
fill 330 219 417 330 220 417 minecraft:red_concrete
fill 330 219 424 330 220 424 minecraft:red_concrete
fill 330 219 431 330 220 431 minecraft:red_concrete
fill 330 219 438 330 220 438 minecraft:red_concrete
fill 330 219 445 330 220 445 minecraft:red_concrete
fill 330 219 452 330 220 452 minecraft:red_concrete
fill 332 219 457 332 220 457 minecraft:red_concrete
fill 337 219 417 337 220 417 minecraft:red_concrete
fill 339 219 457 339 220 457 minecraft:red_concrete
fill 344 219 417 344 220 417 minecraft:red_concrete
fill 346 219 457 346 220 457 minecraft:red_concrete
fill 351 219 417 351 220 417 minecraft:red_concrete
fill 353 219 457 353 220 457 minecraft:red_concrete
fill 358 219 417 358 220 417 minecraft:red_concrete
fill 360 219 457 360 220 457 minecraft:red_concrete
fill 365 219 417 365 220 417 minecraft:red_concrete
fill 367 219 457 367 220 457 minecraft:red_concrete
fill 370 219 419 370 220 419 minecraft:red_concrete
fill 370 219 426 370 220 426 minecraft:red_concrete
fill 370 219 433 370 220 433 minecraft:red_concrete
fill 370 219 440 370 220 440 minecraft:red_concrete
fill 370 219 447 370 220 447 minecraft:red_concrete
fill 370 219 454 370 220 454 minecraft:red_concrete
fill 330 220 418 330 220 421 minecraft:red_concrete
setblock 330 220 423 minecraft:red_concrete
fill 330 220 425 330 220 428 minecraft:red_concrete
setblock 330 220 430 minecraft:red_concrete
fill 330 220 432 330 220 435 minecraft:red_concrete
setblock 330 220 437 minecraft:red_concrete
fill 330 220 439 330 220 442 minecraft:red_concrete
setblock 330 220 444 minecraft:red_concrete
fill 330 220 446 330 220 449 minecraft:red_concrete
setblock 330 220 451 minecraft:red_concrete
fill 330 220 453 330 220 456 minecraft:red_concrete
setblock 331 220 417 minecraft:red_concrete
setblock 331 220 457 minecraft:red_concrete
fill 333 220 417 336 220 417 minecraft:red_concrete
fill 333 220 457 336 220 457 minecraft:red_concrete
setblock 338 220 417 minecraft:red_concrete
setblock 338 220 457 minecraft:red_concrete
fill 340 220 417 343 220 417 minecraft:red_concrete
fill 340 220 457 343 220 457 minecraft:red_concrete
setblock 345 220 417 minecraft:red_concrete
setblock 345 220 457 minecraft:red_concrete
fill 347 220 417 350 220 417 minecraft:red_concrete
fill 347 220 457 350 220 457 minecraft:red_concrete
setblock 352 220 417 minecraft:red_concrete
setblock 352 220 457 minecraft:red_concrete
fill 354 220 417 357 220 417 minecraft:red_concrete
fill 354 220 457 357 220 457 minecraft:red_concrete
setblock 359 220 417 minecraft:red_concrete
setblock 359 220 457 minecraft:red_concrete
fill 361 220 417 364 220 417 minecraft:red_concrete
fill 361 220 457 364 220 457 minecraft:red_concrete
setblock 366 220 417 minecraft:red_concrete
setblock 366 220 457 minecraft:red_concrete
fill 368 220 417 370 220 417 minecraft:red_concrete
fill 368 220 457 370 220 457 minecraft:red_concrete
setblock 370 220 418 minecraft:red_concrete
setblock 370 220 420 minecraft:red_concrete
fill 370 220 422 370 220 425 minecraft:red_concrete
setblock 370 220 427 minecraft:red_concrete
fill 370 220 429 370 220 432 minecraft:red_concrete
setblock 370 220 434 minecraft:red_concrete
fill 370 220 436 370 220 439 minecraft:red_concrete
setblock 370 220 441 minecraft:red_concrete
fill 370 220 443 370 220 446 minecraft:red_concrete
setblock 370 220 448 minecraft:red_concrete
fill 370 220 450 370 220 453 minecraft:red_concrete
setblock 370 220 455 minecraft:red_concrete
setblock 330 221 419 minecraft:red_concrete
setblock 330 221 426 minecraft:red_concrete
setblock 330 221 433 minecraft:red_concrete
setblock 330 221 440 minecraft:red_concrete
setblock 330 221 447 minecraft:red_concrete
setblock 330 221 454 minecraft:red_concrete
setblock 334 221 457 minecraft:red_concrete
setblock 335 221 417 minecraft:red_concrete
setblock 341 221 457 minecraft:red_concrete
setblock 342 221 417 minecraft:red_concrete
setblock 348 221 457 minecraft:red_concrete
setblock 349 221 417 minecraft:red_concrete
setblock 355 221 457 minecraft:red_concrete
setblock 356 221 417 minecraft:red_concrete
setblock 362 221 457 minecraft:red_concrete
setblock 363 221 417 minecraft:red_concrete
setblock 369 221 457 minecraft:red_concrete
setblock 370 221 417 minecraft:red_concrete
setblock 370 221 424 minecraft:red_concrete
setblock 370 221 431 minecraft:red_concrete
setblock 370 221 438 minecraft:red_concrete
setblock 370 221 445 minecraft:red_concrete
setblock 370 221 452 minecraft:red_concrete
setblock 330 222 420 minecraft:red_concrete
setblock 330 222 427 minecraft:red_concrete
setblock 330 222 434 minecraft:red_concrete
setblock 330 222 441 minecraft:red_concrete
setblock 330 222 448 minecraft:red_concrete
setblock 330 222 455 minecraft:red_concrete
setblock 332 222 419 minecraft:light[level=12]
setblock 332 222 427 minecraft:light[level=12]
setblock 332 222 435 minecraft:light[level=12]
setblock 332 222 443 minecraft:light[level=12]
setblock 332 222 451 minecraft:light[level=12]
setblock 334 222 417 minecraft:red_concrete
setblock 335 222 457 minecraft:red_concrete
setblock 340 222 419 minecraft:light[level=12]
setblock 340 222 427 minecraft:light[level=12]
setblock 340 222 435 minecraft:light[level=12]
setblock 340 222 443 minecraft:light[level=12]
setblock 340 222 451 minecraft:light[level=12]
setblock 341 222 417 minecraft:red_concrete
setblock 342 222 457 minecraft:red_concrete
setblock 348 222 417 minecraft:red_concrete
setblock 348 222 419 minecraft:light[level=12]
setblock 348 222 427 minecraft:light[level=12]
setblock 348 222 435 minecraft:light[level=12]
setblock 348 222 443 minecraft:light[level=12]
setblock 348 222 451 minecraft:light[level=12]
setblock 349 222 457 minecraft:red_concrete
setblock 355 222 417 minecraft:red_concrete
setblock 356 222 419 minecraft:light[level=12]
setblock 356 222 427 minecraft:light[level=12]
setblock 356 222 435 minecraft:light[level=12]
setblock 356 222 443 minecraft:light[level=12]
setblock 356 222 451 minecraft:light[level=12]
setblock 356 222 457 minecraft:red_concrete
setblock 362 222 417 minecraft:red_concrete
setblock 363 222 457 minecraft:red_concrete
setblock 364 222 419 minecraft:light[level=12]
setblock 364 222 427 minecraft:light[level=12]
setblock 364 222 435 minecraft:light[level=12]
setblock 364 222 443 minecraft:light[level=12]
setblock 364 222 451 minecraft:light[level=12]
setblock 369 222 417 minecraft:red_concrete
setblock 370 222 423 minecraft:red_concrete
setblock 370 222 430 minecraft:red_concrete
setblock 370 222 437 minecraft:red_concrete
setblock 370 222 444 minecraft:red_concrete
setblock 370 222 451 minecraft:red_concrete
setblock 370 222 457 minecraft:red_concrete
setblock 330 223 421 minecraft:red_concrete
setblock 330 223 428 minecraft:red_concrete
setblock 330 223 435 minecraft:red_concrete
setblock 330 223 442 minecraft:red_concrete
setblock 330 223 449 minecraft:red_concrete
setblock 330 223 456 minecraft:red_concrete
setblock 333 223 417 minecraft:red_concrete
setblock 336 223 457 minecraft:red_concrete
setblock 340 223 417 minecraft:red_concrete
setblock 343 223 457 minecraft:red_concrete
setblock 347 223 417 minecraft:red_concrete
setblock 350 223 457 minecraft:red_concrete
setblock 354 223 417 minecraft:red_concrete
setblock 357 223 457 minecraft:red_concrete
setblock 361 223 417 minecraft:red_concrete
setblock 364 223 457 minecraft:red_concrete
setblock 368 223 417 minecraft:red_concrete
setblock 370 223 422 minecraft:red_concrete
setblock 370 223 429 minecraft:red_concrete
setblock 370 223 436 minecraft:red_concrete
setblock 370 223 443 minecraft:red_concrete
setblock 370 223 450 minecraft:red_concrete
setblock 330 225 423 minecraft:red_concrete
setblock 330 225 430 minecraft:red_concrete
setblock 330 225 437 minecraft:red_concrete
setblock 330 225 444 minecraft:red_concrete
setblock 330 225 451 minecraft:red_concrete
setblock 331 225 417 minecraft:red_concrete
setblock 331 225 457 minecraft:red_concrete
setblock 338 225 417 minecraft:red_concrete
setblock 338 225 457 minecraft:red_concrete
setblock 345 225 417 minecraft:red_concrete
setblock 345 225 457 minecraft:red_concrete
setblock 352 225 417 minecraft:red_concrete
setblock 352 225 457 minecraft:red_concrete
setblock 359 225 417 minecraft:red_concrete
setblock 359 225 457 minecraft:red_concrete
setblock 366 225 417 minecraft:red_concrete
setblock 366 225 457 minecraft:red_concrete
setblock 370 225 420 minecraft:red_concrete
setblock 370 225 427 minecraft:red_concrete
setblock 370 225 434 minecraft:red_concrete
setblock 370 225 441 minecraft:red_concrete
setblock 370 225 448 minecraft:red_concrete
setblock 370 225 455 minecraft:red_concrete
setblock 330 226 417 minecraft:red_concrete
setblock 330 226 424 minecraft:red_concrete
setblock 330 226 431 minecraft:red_concrete
setblock 330 226 438 minecraft:red_concrete
setblock 330 226 445 minecraft:red_concrete
setblock 330 226 452 minecraft:red_concrete
setblock 331 226 451 minecraft:red_wool
setblock 332 226 457 minecraft:red_concrete
setblock 337 226 417 minecraft:red_concrete
setblock 339 226 457 minecraft:red_concrete
setblock 344 226 417 minecraft:red_concrete
setblock 346 226 457 minecraft:red_concrete
setblock 351 226 417 minecraft:red_concrete
setblock 353 226 457 minecraft:red_concrete
setblock 358 226 417 minecraft:red_concrete
setblock 360 226 457 minecraft:red_concrete
setblock 365 226 417 minecraft:red_concrete
setblock 367 226 457 minecraft:red_concrete
setblock 370 226 419 minecraft:red_concrete
setblock 370 226 426 minecraft:red_concrete
setblock 370 226 433 minecraft:red_concrete
setblock 370 226 440 minecraft:red_concrete
setblock 370 226 447 minecraft:red_concrete
setblock 370 226 454 minecraft:red_concrete
setblock 332 230 419 minecraft:light[level=12]
setblock 332 230 427 minecraft:light[level=12]
setblock 332 230 435 minecraft:light[level=12]
setblock 332 230 443 minecraft:light[level=12]
setblock 332 230 451 minecraft:light[level=12]
setblock 340 230 419 minecraft:light[level=12]
setblock 340 230 427 minecraft:light[level=12]
setblock 340 230 435 minecraft:light[level=12]
setblock 340 230 443 minecraft:light[level=12]
setblock 340 230 451 minecraft:light[level=12]
setblock 348 230 419 minecraft:light[level=12]
setblock 348 230 427 minecraft:light[level=12]
setblock 348 230 435 minecraft:light[level=12]
setblock 348 230 443 minecraft:light[level=12]
setblock 348 230 451 minecraft:light[level=12]
setblock 356 230 419 minecraft:light[level=12]
setblock 356 230 427 minecraft:light[level=12]
setblock 356 230 435 minecraft:light[level=12]
setblock 356 230 443 minecraft:light[level=12]
setblock 356 230 451 minecraft:light[level=12]
setblock 364 230 419 minecraft:light[level=12]
setblock 364 230 427 minecraft:light[level=12]
setblock 364 230 435 minecraft:light[level=12]
setblock 364 230 443 minecraft:light[level=12]
setblock 364 230 451 minecraft:light[level=12]
fill 344 232 440 346 234 442 minecraft:orange_concrete
fill 344 232 443 346 234 444 minecraft:yellow_concrete
fill 345 232 438 347 234 439 minecraft:orange_concrete
fill 345 232 445 347 234 446 minecraft:yellow_concrete
fill 346 232 436 348 234 437 minecraft:orange_concrete
fill 346 232 447 348 234 448 minecraft:yellow_concrete
fill 348 232 435 356 234 435 minecraft:red_concrete
fill 348 232 438 348 234 438 minecraft:orange_concrete
fill 348 232 446 348 234 446 minecraft:yellow_concrete
fill 348 232 449 356 234 449 minecraft:red_concrete
fill 349 232 436 355 234 436 minecraft:red_concrete
fill 349 232 437 349 234 437 minecraft:orange_concrete
fill 349 232 447 349 234 447 minecraft:yellow_concrete
fill 349 232 448 355 234 448 minecraft:red_concrete
fill 350 232 434 354 234 434 minecraft:red_concrete
fill 350 232 450 354 234 450 minecraft:red_concrete
fill 355 232 437 358 234 437 minecraft:yellow_concrete
fill 355 232 447 358 234 447 minecraft:orange_concrete
fill 356 232 436 358 234 436 minecraft:yellow_concrete
fill 356 232 438 359 234 438 minecraft:yellow_concrete
fill 356 232 446 359 234 446 minecraft:orange_concrete
fill 356 232 448 358 234 448 minecraft:orange_concrete
fill 357 232 439 359 234 439 minecraft:yellow_concrete
fill 357 232 445 359 234 445 minecraft:orange_concrete
fill 358 232 440 360 234 441 minecraft:yellow_concrete
fill 358 232 442 360 234 444 minecraft:orange_concrete
fill 330 233 417 343 233 457 minecraft:black_concrete
fill 344 233 417 344 233 438 minecraft:black_concrete
setblock 344 233 439 minecraft:orange_concrete
setblock 344 233 445 minecraft:yellow_concrete
fill 344 233 446 344 233 457 minecraft:black_concrete
fill 345 233 417 345 233 436 minecraft:black_concrete
setblock 345 233 437 minecraft:orange_concrete
setblock 345 233 447 minecraft:yellow_concrete
fill 345 233 448 345 233 457 minecraft:black_concrete
fill 346 233 417 346 233 435 minecraft:black_concrete
fill 346 233 449 346 233 457 minecraft:black_concrete
fill 347 233 417 348 233 434 minecraft:black_concrete
setblock 347 233 435 minecraft:orange_concrete
setblock 347 233 440 minecraft:orange_concrete
fill 347 233 441 348 233 443 minecraft:black_concrete
setblock 347 233 444 minecraft:yellow_concrete
setblock 347 233 449 minecraft:yellow_concrete
fill 347 233 450 348 233 457 minecraft:black_concrete
fill 348 233 439 349 233 440 minecraft:black_concrete
fill 348 233 444 349 233 445 minecraft:black_concrete
fill 349 233 417 370 233 433 minecraft:black_concrete
setblock 349 233 434 minecraft:red_concrete
fill 349 233 438 355 233 438 minecraft:black_concrete
fill 349 233 441 349 233 443 minecraft:jack_o_lantern
fill 349 233 446 355 233 446 minecraft:black_concrete
setblock 349 233 450 minecraft:red_concrete
fill 349 233 451 370 233 457 minecraft:black_concrete
setblock 350 233 437 minecraft:red_concrete
setblock 350 233 439 minecraft:black_concrete
fill 350 233 440 350 233 441 minecraft:jack_o_lantern
fill 350 233 443 350 233 444 minecraft:jack_o_lantern
setblock 350 233 445 minecraft:black_concrete
setblock 350 233 447 minecraft:red_concrete
fill 351 233 437 353 233 437 minecraft:black_concrete
fill 351 233 439 351 233 440 minecraft:jack_o_lantern
fill 351 233 444 351 233 445 minecraft:jack_o_lantern
fill 351 233 447 353 233 447 minecraft:black_concrete
fill 352 233 439 353 233 439 minecraft:jack_o_lantern
fill 352 233 445 353 233 445 minecraft:jack_o_lantern
fill 353 233 440 354 233 440 minecraft:jack_o_lantern
fill 353 233 444 354 233 444 minecraft:jack_o_lantern
setblock 354 233 437 minecraft:red_concrete
fill 354 233 439 356 233 439 minecraft:black_concrete
fill 354 233 441 355 233 441 minecraft:jack_o_lantern
fill 354 233 443 355 233 443 minecraft:jack_o_lantern
fill 354 233 445 356 233 445 minecraft:black_concrete
setblock 354 233 447 minecraft:red_concrete
setblock 355 233 434 minecraft:red_concrete
fill 355 233 440 356 233 440 minecraft:black_concrete
setblock 355 233 442 minecraft:jack_o_lantern
fill 355 233 444 356 233 444 minecraft:black_concrete
setblock 355 233 450 minecraft:red_concrete
fill 356 233 434 370 233 434 minecraft:black_concrete
fill 356 233 441 357 233 443 minecraft:black_concrete
fill 356 233 450 370 233 450 minecraft:black_concrete
setblock 357 233 435 minecraft:yellow_concrete
setblock 357 233 440 minecraft:yellow_concrete
setblock 357 233 444 minecraft:orange_concrete
setblock 357 233 449 minecraft:orange_concrete
fill 358 233 435 370 233 435 minecraft:black_concrete
fill 358 233 449 370 233 449 minecraft:black_concrete
fill 359 233 436 370 233 436 minecraft:black_concrete
setblock 359 233 437 minecraft:yellow_concrete
setblock 359 233 447 minecraft:orange_concrete
fill 359 233 448 370 233 448 minecraft:black_concrete
fill 360 233 437 370 233 438 minecraft:black_concrete
setblock 360 233 439 minecraft:yellow_concrete
setblock 360 233 445 minecraft:orange_concrete
fill 360 233 446 370 233 447 minecraft:black_concrete
fill 361 233 439 370 233 445 minecraft:black_concrete
fill 330 237 421 330 237 422 minecraft:red_concrete
fill 330 237 428 330 237 429 minecraft:red_concrete
fill 330 237 434 336 254 444 minecraft:red_concrete
fill 330 237 449 330 237 450 minecraft:red_concrete
fill 330 237 456 330 237 457 minecraft:red_concrete
fill 331 237 448 331 238 454 minecraft:gray_concrete
fill 332 237 417 333 237 417 minecraft:red_concrete
fill 336 237 457 337 237 457 minecraft:red_concrete
fill 339 237 417 340 237 417 minecraft:red_concrete
fill 343 237 457 344 237 457 minecraft:red_concrete
fill 346 237 417 347 237 417 minecraft:red_concrete
fill 350 237 457 351 237 457 minecraft:red_concrete
fill 353 237 417 354 237 417 minecraft:red_concrete
fill 353 237 455 357 247 455 minecraft:red_wool
fill 357 237 457 358 237 457 minecraft:red_concrete
fill 360 237 417 361 237 417 minecraft:red_concrete
fill 361 237 438 362 238 439 minecraft:yellow_wool
fill 364 237 457 365 237 457 minecraft:red_concrete
fill 367 237 417 368 237 417 minecraft:red_concrete
fill 370 237 421 370 237 422 minecraft:red_concrete
fill 370 237 428 370 237 429 minecraft:red_concrete
fill 370 237 435 370 237 436 minecraft:red_concrete
fill 370 237 442 370 237 443 minecraft:red_concrete
fill 370 237 449 370 237 450 minecraft:red_concrete
fill 370 237 456 370 273 456 minecraft:red_concrete
fill 330 238 422 330 273 422 minecraft:red_concrete
fill 330 238 429 330 273 429 minecraft:red_concrete
fill 330 238 450 330 273 450 minecraft:red_concrete
fill 330 238 457 330 273 457 minecraft:red_concrete
fill 332 238 417 332 273 417 minecraft:red_concrete
setblock 332 238 419 minecraft:light[level=12]
setblock 332 238 427 minecraft:light[level=12]
setblock 332 238 451 minecraft:light[level=12]
fill 337 238 457 337 273 457 minecraft:red_concrete
fill 339 238 417 339 273 417 minecraft:red_concrete
setblock 340 238 419 minecraft:light[level=12]
setblock 340 238 427 minecraft:light[level=12]
setblock 340 238 435 minecraft:light[level=12]
setblock 340 238 443 minecraft:light[level=12]
setblock 340 238 451 minecraft:light[level=12]
fill 344 238 457 344 273 457 minecraft:red_concrete
fill 346 238 417 346 273 417 minecraft:red_concrete
setblock 348 238 419 minecraft:light[level=12]
setblock 348 238 427 minecraft:light[level=12]
setblock 348 238 435 minecraft:light[level=12]
setblock 348 238 443 minecraft:light[level=12]
setblock 348 238 451 minecraft:light[level=12]
fill 351 238 457 351 273 457 minecraft:red_concrete
fill 353 238 417 353 273 417 minecraft:red_concrete
setblock 356 238 419 minecraft:light[level=12]
setblock 356 238 427 minecraft:light[level=12]
setblock 356 238 435 minecraft:light[level=12]
setblock 356 238 443 minecraft:light[level=12]
setblock 356 238 451 minecraft:light[level=12]
fill 358 238 457 358 273 457 minecraft:red_concrete
fill 360 238 417 360 273 417 minecraft:red_concrete
setblock 364 238 419 minecraft:light[level=12]
setblock 364 238 427 minecraft:light[level=12]
setblock 364 238 435 minecraft:light[level=12]
setblock 364 238 443 minecraft:light[level=12]
setblock 364 238 451 minecraft:light[level=12]
fill 365 238 457 365 273 457 minecraft:red_concrete
fill 367 238 417 367 273 417 minecraft:red_concrete
fill 370 238 421 370 273 421 minecraft:red_concrete
fill 370 238 428 370 273 428 minecraft:red_concrete
fill 370 238 435 370 273 435 minecraft:red_concrete
fill 370 238 442 370 273 442 minecraft:red_concrete
fill 370 238 449 370 273 449 minecraft:red_concrete
fill 330 239 423 330 240 423 minecraft:red_concrete
fill 330 239 430 330 240 430 minecraft:red_concrete
fill 330 239 451 330 240 451 minecraft:red_concrete
fill 331 239 417 331 240 417 minecraft:red_concrete
fill 331 239 457 331 240 457 minecraft:red_concrete
fill 338 239 417 338 240 417 minecraft:red_concrete
fill 338 239 457 338 240 457 minecraft:red_concrete
fill 345 239 417 345 240 417 minecraft:red_concrete
fill 345 239 457 345 240 457 minecraft:red_concrete
fill 352 239 417 352 240 417 minecraft:red_concrete
fill 352 239 457 352 240 457 minecraft:red_concrete
fill 359 239 417 359 240 417 minecraft:red_concrete
fill 359 239 422 360 240 423 minecraft:yellow_wool
fill 359 239 457 359 240 457 minecraft:red_concrete
fill 366 239 417 366 240 417 minecraft:red_concrete
fill 366 239 457 366 240 457 minecraft:red_concrete
fill 370 239 420 370 240 420 minecraft:red_concrete
fill 370 239 427 370 240 427 minecraft:red_concrete
fill 370 239 434 370 240 434 minecraft:red_concrete
fill 370 239 441 370 240 441 minecraft:red_concrete
fill 370 239 448 370 240 448 minecraft:red_concrete
fill 370 239 455 370 240 455 minecraft:red_concrete
fill 330 240 417 330 240 421 minecraft:red_concrete
fill 330 240 424 330 240 428 minecraft:red_concrete
fill 330 240 431 330 240 433 minecraft:red_concrete
fill 330 240 445 330 240 449 minecraft:red_concrete
fill 330 240 452 330 240 456 minecraft:red_concrete
fill 332 240 457 336 240 457 minecraft:red_concrete
fill 333 240 417 337 240 417 minecraft:red_concrete
fill 339 240 457 343 240 457 minecraft:red_concrete
fill 340 240 417 344 240 417 minecraft:red_concrete
fill 346 240 457 350 240 457 minecraft:red_concrete
fill 347 240 417 351 240 417 minecraft:red_concrete
fill 353 240 457 357 240 457 minecraft:red_concrete
fill 354 240 417 358 240 417 minecraft:red_concrete
fill 360 240 457 364 240 457 minecraft:red_concrete
fill 361 240 417 365 240 417 minecraft:red_concrete
fill 367 240 457 370 240 457 minecraft:red_concrete
fill 368 240 417 370 240 417 minecraft:red_concrete
fill 370 240 418 370 240 419 minecraft:red_concrete
fill 370 240 422 370 240 426 minecraft:red_concrete
fill 370 240 429 370 240 433 minecraft:red_concrete
fill 370 240 436 370 240 440 minecraft:red_concrete
fill 370 240 443 370 240 447 minecraft:red_concrete
fill 370 240 450 370 240 454 minecraft:red_concrete
setblock 330 241 418 minecraft:red_concrete
setblock 330 241 425 minecraft:red_concrete
setblock 330 241 432 minecraft:red_concrete
setblock 330 241 446 minecraft:red_concrete
setblock 330 241 453 minecraft:red_concrete
setblock 333 241 457 minecraft:red_concrete
setblock 336 241 417 minecraft:red_concrete
fill 339 241 437 340 242 437 minecraft:yellow_wool
setblock 340 241 457 minecraft:red_concrete
setblock 343 241 417 minecraft:red_concrete
setblock 347 241 457 minecraft:red_concrete
setblock 350 241 417 minecraft:red_concrete
setblock 354 241 457 minecraft:red_concrete
setblock 357 241 417 minecraft:red_concrete
setblock 361 241 457 minecraft:red_concrete
setblock 364 241 417 minecraft:red_concrete
setblock 368 241 457 minecraft:red_concrete
setblock 370 241 418 minecraft:red_concrete
setblock 370 241 425 minecraft:red_concrete
setblock 370 241 432 minecraft:red_concrete
setblock 370 241 439 minecraft:red_concrete
setblock 370 241 446 minecraft:red_concrete
setblock 370 241 453 minecraft:red_concrete
setblock 330 242 419 minecraft:red_concrete
setblock 330 242 426 minecraft:red_concrete
setblock 330 242 433 minecraft:red_concrete
setblock 330 242 447 minecraft:red_concrete
setblock 330 242 454 minecraft:red_concrete
setblock 334 242 457 minecraft:red_concrete
setblock 335 242 417 minecraft:red_concrete
setblock 341 242 457 minecraft:red_concrete
setblock 342 242 417 minecraft:red_concrete
setblock 348 242 457 minecraft:red_concrete
setblock 349 242 417 minecraft:red_concrete
setblock 355 242 457 minecraft:red_concrete
setblock 356 242 417 minecraft:red_concrete
setblock 362 242 457 minecraft:red_concrete
setblock 363 242 417 minecraft:red_concrete
fill 364 242 425 364 243 425 minecraft:yellow_wool
setblock 369 242 457 minecraft:red_concrete
setblock 370 242 417 minecraft:red_concrete
setblock 370 242 424 minecraft:red_concrete
setblock 370 242 431 minecraft:red_concrete
setblock 370 242 438 minecraft:red_concrete
setblock 370 242 445 minecraft:red_concrete
setblock 370 242 452 minecraft:red_concrete
setblock 330 243 420 minecraft:red_concrete
setblock 330 243 427 minecraft:red_concrete
setblock 330 243 448 minecraft:red_concrete
setblock 330 243 455 minecraft:red_concrete
setblock 334 243 417 minecraft:red_concrete
setblock 335 243 457 minecraft:red_concrete
setblock 341 243 417 minecraft:red_concrete
setblock 342 243 457 minecraft:red_concrete
setblock 348 243 417 minecraft:red_concrete
setblock 349 243 457 minecraft:red_concrete
setblock 355 243 417 minecraft:red_concrete
setblock 356 243 457 minecraft:red_concrete
setblock 362 243 417 minecraft:red_concrete
setblock 363 243 457 minecraft:red_concrete
setblock 369 243 417 minecraft:red_concrete
setblock 370 243 423 minecraft:red_concrete
setblock 370 243 430 minecraft:red_concrete
setblock 370 243 437 minecraft:red_concrete
setblock 370 243 444 minecraft:red_concrete
setblock 370 243 451 minecraft:red_concrete
setblock 370 243 457 minecraft:red_concrete
setblock 330 244 421 minecraft:red_concrete
setblock 330 244 428 minecraft:red_concrete
setblock 330 244 449 minecraft:red_concrete
setblock 330 244 456 minecraft:red_concrete
setblock 333 244 417 minecraft:red_concrete
setblock 336 244 457 minecraft:red_concrete
fill 337 244 450 337 245 451 minecraft:red_wool
setblock 340 244 417 minecraft:red_concrete
setblock 343 244 457 minecraft:red_concrete
setblock 347 244 417 minecraft:red_concrete
setblock 350 244 457 minecraft:red_concrete
setblock 354 244 417 minecraft:red_concrete
setblock 357 244 457 minecraft:red_concrete
setblock 361 244 417 minecraft:red_concrete
setblock 364 244 457 minecraft:red_concrete
setblock 368 244 417 minecraft:red_concrete
setblock 370 244 422 minecraft:red_concrete
setblock 370 244 429 minecraft:red_concrete
setblock 370 244 436 minecraft:red_concrete
setblock 370 244 443 minecraft:red_concrete
setblock 370 244 450 minecraft:red_concrete
setblock 330 246 423 minecraft:red_concrete
setblock 330 246 430 minecraft:red_concrete
setblock 330 246 451 minecraft:red_concrete
setblock 331 246 417 minecraft:red_concrete
fill 331 246 423 336 246 423 minecraft:black_concrete
setblock 331 246 457 minecraft:red_concrete
setblock 332 246 419 minecraft:light[level=12]
fill 332 246 421 336 247 422 minecraft:black_concrete
fill 332 246 424 336 247 425 minecraft:black_concrete
setblock 332 246 427 minecraft:light[level=12]
setblock 332 246 451 minecraft:light[level=12]
setblock 338 246 417 minecraft:red_concrete
setblock 338 246 457 minecraft:red_concrete
setblock 340 246 419 minecraft:light[level=12]
setblock 340 246 427 minecraft:light[level=12]
setblock 340 246 435 minecraft:light[level=12]
setblock 340 246 443 minecraft:light[level=12]
setblock 340 246 451 minecraft:light[level=12]
setblock 345 246 417 minecraft:red_concrete
setblock 345 246 457 minecraft:red_concrete
setblock 348 246 419 minecraft:light[level=12]
setblock 348 246 427 minecraft:light[level=12]
setblock 348 246 435 minecraft:light[level=12]
setblock 348 246 443 minecraft:light[level=12]
setblock 348 246 451 minecraft:light[level=12]
setblock 352 246 417 minecraft:red_concrete
setblock 352 246 457 minecraft:red_concrete
setblock 356 246 419 minecraft:light[level=12]
setblock 356 246 427 minecraft:light[level=12]
setblock 356 246 435 minecraft:light[level=12]
setblock 356 246 443 minecraft:light[level=12]
setblock 356 246 451 minecraft:light[level=12]
setblock 359 246 417 minecraft:red_concrete
setblock 359 246 457 minecraft:red_concrete
setblock 364 246 419 minecraft:light[level=12]
setblock 364 246 427 minecraft:light[level=12]
setblock 364 246 435 minecraft:light[level=12]
setblock 364 246 443 minecraft:light[level=12]
setblock 364 246 451 minecraft:light[level=12]
setblock 366 246 417 minecraft:red_concrete
setblock 366 246 457 minecraft:red_concrete
setblock 370 246 420 minecraft:red_concrete
setblock 370 246 427 minecraft:red_concrete
setblock 370 246 434 minecraft:red_concrete
setblock 370 246 441 minecraft:red_concrete
setblock 370 246 448 minecraft:red_concrete
setblock 370 246 455 minecraft:red_concrete
setblock 330 247 417 minecraft:red_concrete
setblock 330 247 424 minecraft:red_concrete
setblock 330 247 431 minecraft:red_concrete
setblock 330 247 445 minecraft:red_concrete
setblock 330 247 452 minecraft:red_concrete
fill 332 247 423 336 247 423 minecraft:black_concrete
setblock 332 247 457 minecraft:red_concrete
setblock 337 247 417 minecraft:red_concrete
setblock 339 247 457 minecraft:red_concrete
setblock 344 247 417 minecraft:red_concrete
setblock 346 247 457 minecraft:red_concrete
setblock 351 247 417 minecraft:red_concrete
setblock 353 247 457 minecraft:red_concrete
setblock 358 247 417 minecraft:red_concrete
setblock 360 247 457 minecraft:red_concrete
setblock 365 247 417 minecraft:red_concrete
setblock 367 247 457 minecraft:red_concrete
setblock 370 247 419 minecraft:red_concrete
setblock 370 247 426 minecraft:red_concrete
setblock 370 247 433 minecraft:red_concrete
setblock 370 247 440 minecraft:red_concrete
setblock 370 247 447 minecraft:red_concrete
setblock 370 247 454 minecraft:red_concrete
setblock 330 248 418 minecraft:red_concrete
setblock 330 248 425 minecraft:red_concrete
setblock 330 248 432 minecraft:red_concrete
setblock 330 248 446 minecraft:red_concrete
setblock 330 248 453 minecraft:red_concrete
setblock 333 248 457 minecraft:red_concrete
fill 334 248 423 334 253 423 minecraft:bone_block
setblock 336 248 417 minecraft:red_concrete
setblock 340 248 457 minecraft:red_concrete
setblock 343 248 417 minecraft:red_concrete
setblock 347 248 457 minecraft:red_concrete
setblock 350 248 417 minecraft:red_concrete
fill 352 248 455 358 249 455 minecraft:gray_concrete
setblock 354 248 457 minecraft:red_concrete
setblock 357 248 417 minecraft:red_concrete
setblock 361 248 457 minecraft:red_concrete
setblock 364 248 417 minecraft:red_concrete
setblock 368 248 457 minecraft:red_concrete
setblock 370 248 418 minecraft:red_concrete
setblock 370 248 425 minecraft:red_concrete
setblock 370 248 432 minecraft:red_concrete
setblock 370 248 439 minecraft:red_concrete
setblock 370 248 446 minecraft:red_concrete
setblock 370 248 453 minecraft:red_concrete
fill 330 249 419 330 250 419 minecraft:red_concrete
fill 330 249 426 330 250 426 minecraft:red_concrete
fill 330 249 433 330 250 433 minecraft:red_concrete
fill 330 249 447 330 250 447 minecraft:red_concrete
fill 330 249 454 330 250 454 minecraft:red_concrete
fill 332 249 422 333 252 424 minecraft:bone_block
fill 333 249 421 335 252 421 minecraft:bone_block
fill 333 249 425 335 252 425 minecraft:bone_block
fill 334 249 422 336 252 422 minecraft:bone_block
fill 334 249 424 336 252 424 minecraft:bone_block
fill 334 249 457 334 250 457 minecraft:red_concrete
fill 335 249 417 335 250 417 minecraft:red_concrete
fill 335 249 423 336 252 423 minecraft:bone_block
fill 341 249 457 341 250 457 minecraft:red_concrete
fill 342 249 417 342 250 417 minecraft:red_concrete
fill 348 249 457 348 250 457 minecraft:red_concrete
fill 349 249 417 349 250 417 minecraft:red_concrete
fill 355 249 457 355 250 457 minecraft:red_concrete
fill 356 249 417 356 250 417 minecraft:red_concrete
fill 362 249 457 362 250 457 minecraft:red_concrete
fill 363 249 417 363 250 417 minecraft:red_concrete
fill 369 249 457 369 250 457 minecraft:red_concrete
fill 370 249 417 370 250 417 minecraft:red_concrete
fill 370 249 424 370 250 424 minecraft:red_concrete
fill 370 249 431 370 250 431 minecraft:red_concrete
fill 370 249 438 370 250 438 minecraft:red_concrete
fill 370 249 445 370 250 445 minecraft:red_concrete
fill 370 249 452 370 250 452 minecraft:red_concrete
fill 330 250 417 330 250 418 minecraft:red_concrete
fill 330 250 420 330 250 421 minecraft:red_concrete
fill 330 250 423 330 250 425 minecraft:red_concrete
fill 330 250 427 330 250 428 minecraft:red_concrete
fill 330 250 430 330 250 432 minecraft:red_concrete
fill 330 250 445 330 250 446 minecraft:red_concrete
fill 330 250 448 330 250 449 minecraft:red_concrete
fill 330 250 451 330 250 453 minecraft:red_concrete
fill 330 250 455 330 250 456 minecraft:red_concrete
setblock 331 250 417 minecraft:red_concrete
fill 331 250 457 333 250 457 minecraft:red_concrete
fill 333 250 417 334 250 417 minecraft:red_concrete
fill 335 250 457 336 250 457 minecraft:red_concrete
fill 336 250 417 338 250 417 minecraft:red_concrete
fill 338 250 457 340 250 457 minecraft:red_concrete
fill 340 250 417 341 250 417 minecraft:red_concrete
fill 342 250 457 343 250 457 minecraft:red_concrete
fill 343 250 417 345 250 417 minecraft:red_concrete
fill 345 250 457 347 250 457 minecraft:red_concrete
fill 347 250 417 348 250 417 minecraft:red_concrete
fill 349 250 457 350 250 457 minecraft:red_concrete
fill 350 250 417 352 250 417 minecraft:red_concrete
fill 352 250 457 354 250 457 minecraft:red_concrete
fill 354 250 417 355 250 417 minecraft:red_concrete
fill 356 250 457 357 250 457 minecraft:red_concrete
fill 357 250 417 359 250 417 minecraft:red_concrete
fill 359 250 457 361 250 457 minecraft:red_concrete
fill 361 250 417 362 250 417 minecraft:red_concrete
fill 363 250 457 364 250 457 minecraft:red_concrete
fill 364 250 417 366 250 417 minecraft:red_concrete
fill 366 250 457 368 250 457 minecraft:red_concrete
fill 368 250 417 369 250 417 minecraft:red_concrete
fill 370 250 418 370 250 420 minecraft:red_concrete
fill 370 250 422 370 250 423 minecraft:red_concrete
fill 370 250 425 370 250 427 minecraft:red_concrete
fill 370 250 429 370 250 430 minecraft:red_concrete
fill 370 250 432 370 250 434 minecraft:red_concrete
fill 370 250 436 370 250 437 minecraft:red_concrete
fill 370 250 439 370 250 441 minecraft:red_concrete
fill 370 250 443 370 250 444 minecraft:red_concrete
fill 370 250 446 370 250 448 minecraft:red_concrete
fill 370 250 450 370 250 451 minecraft:red_concrete
fill 370 250 453 370 250 455 minecraft:red_concrete
setblock 370 250 457 minecraft:red_concrete
setblock 330 251 421 minecraft:red_concrete
setblock 330 251 428 minecraft:red_concrete
setblock 330 251 449 minecraft:red_concrete
setblock 330 251 456 minecraft:red_concrete
setblock 333 251 417 minecraft:red_concrete
setblock 336 251 457 minecraft:red_concrete
setblock 340 251 417 minecraft:red_concrete
setblock 343 251 457 minecraft:red_concrete
setblock 347 251 417 minecraft:red_concrete
setblock 350 251 457 minecraft:red_concrete
setblock 354 251 417 minecraft:red_concrete
setblock 357 251 457 minecraft:red_concrete
setblock 361 251 417 minecraft:red_concrete
fill 363 251 445 363 252 445 minecraft:white_wool
setblock 364 251 457 minecraft:red_concrete
setblock 368 251 417 minecraft:red_concrete
setblock 370 251 422 minecraft:red_concrete
setblock 370 251 429 minecraft:red_concrete
setblock 370 251 436 minecraft:red_concrete
setblock 370 251 443 minecraft:red_concrete
setblock 370 251 450 minecraft:red_concrete
setblock 330 253 423 minecraft:red_concrete
setblock 330 253 430 minecraft:red_concrete
setblock 330 253 451 minecraft:red_concrete
setblock 331 253 417 minecraft:red_concrete
setblock 331 253 457 minecraft:red_concrete
setblock 338 253 417 minecraft:red_concrete
setblock 338 253 457 minecraft:red_concrete
setblock 345 253 417 minecraft:red_concrete
setblock 345 253 457 minecraft:red_concrete
setblock 352 253 417 minecraft:red_concrete
setblock 352 253 457 minecraft:red_concrete
setblock 359 253 417 minecraft:red_concrete
setblock 359 253 457 minecraft:red_concrete
setblock 366 253 417 minecraft:red_concrete
setblock 366 253 457 minecraft:red_concrete
setblock 370 253 420 minecraft:red_concrete
setblock 370 253 427 minecraft:red_concrete
setblock 370 253 434 minecraft:red_concrete
setblock 370 253 441 minecraft:red_concrete
setblock 370 253 448 minecraft:red_concrete
setblock 370 253 455 minecraft:red_concrete
setblock 330 254 417 minecraft:red_concrete
setblock 330 254 424 minecraft:red_concrete
setblock 330 254 431 minecraft:red_concrete
setblock 330 254 445 minecraft:red_concrete
setblock 330 254 452 minecraft:red_concrete
setblock 332 254 419 minecraft:light[level=12]
setblock 332 254 427 minecraft:light[level=12]
setblock 332 254 451 minecraft:light[level=12]
setblock 332 254 457 minecraft:red_concrete
setblock 337 254 417 minecraft:red_concrete
setblock 339 254 457 minecraft:red_concrete
setblock 340 254 419 minecraft:light[level=12]
setblock 340 254 427 minecraft:light[level=12]
setblock 340 254 435 minecraft:light[level=12]
setblock 340 254 443 minecraft:light[level=12]
setblock 340 254 451 minecraft:light[level=12]
setblock 344 254 417 minecraft:red_concrete
setblock 346 254 457 minecraft:red_concrete
setblock 348 254 419 minecraft:light[level=12]
setblock 348 254 427 minecraft:light[level=12]
setblock 348 254 435 minecraft:light[level=12]
setblock 348 254 443 minecraft:light[level=12]
setblock 348 254 451 minecraft:light[level=12]
setblock 351 254 417 minecraft:red_concrete
setblock 353 254 457 minecraft:red_concrete
setblock 356 254 419 minecraft:light[level=12]
setblock 356 254 427 minecraft:light[level=12]
setblock 356 254 435 minecraft:light[level=12]
setblock 356 254 443 minecraft:light[level=12]
setblock 356 254 451 minecraft:light[level=12]
setblock 358 254 417 minecraft:red_concrete
setblock 360 254 457 minecraft:red_concrete
setblock 364 254 419 minecraft:light[level=12]
setblock 364 254 427 minecraft:light[level=12]
setblock 364 254 435 minecraft:light[level=12]
setblock 364 254 443 minecraft:light[level=12]
setblock 364 254 451 minecraft:light[level=12]
setblock 365 254 417 minecraft:red_concrete
setblock 367 254 457 minecraft:red_concrete
setblock 370 254 419 minecraft:red_concrete
setblock 370 254 426 minecraft:red_concrete
setblock 370 254 433 minecraft:red_concrete
setblock 370 254 440 minecraft:red_concrete
setblock 370 254 447 minecraft:red_concrete
setblock 370 254 454 minecraft:red_concrete
setblock 330 255 418 minecraft:red_concrete
setblock 330 255 425 minecraft:red_concrete
setblock 330 255 432 minecraft:red_concrete
fill 330 255 436 330 273 436 minecraft:red_concrete
setblock 330 255 439 minecraft:red_concrete
fill 330 255 443 330 273 443 minecraft:red_concrete
setblock 330 255 446 minecraft:red_concrete
setblock 330 255 453 minecraft:red_concrete
fill 331 255 435 335 255 443 minecraft:white_concrete
setblock 333 255 457 minecraft:red_concrete
setblock 336 255 417 minecraft:red_concrete
setblock 340 255 457 minecraft:red_concrete
setblock 343 255 417 minecraft:red_concrete
setblock 347 255 457 minecraft:red_concrete
setblock 350 255 417 minecraft:red_concrete
setblock 354 255 457 minecraft:red_concrete
setblock 357 255 417 minecraft:red_concrete
setblock 361 255 457 minecraft:red_concrete
setblock 364 255 417 minecraft:red_concrete
setblock 368 255 457 minecraft:red_concrete
setblock 370 255 418 minecraft:red_concrete
setblock 370 255 425 minecraft:red_concrete
setblock 370 255 432 minecraft:red_concrete
setblock 370 255 439 minecraft:red_concrete
setblock 370 255 446 minecraft:red_concrete
setblock 370 255 453 minecraft:red_concrete
setblock 330 256 419 minecraft:red_concrete
setblock 330 256 426 minecraft:red_concrete
setblock 330 256 433 minecraft:red_concrete
setblock 330 256 440 minecraft:red_concrete
setblock 330 256 447 minecraft:red_concrete
setblock 330 256 454 minecraft:red_concrete
fill 332 256 436 334 256 442 minecraft:white_concrete
setblock 334 256 457 minecraft:red_concrete
setblock 335 256 417 minecraft:red_concrete
setblock 341 256 457 minecraft:red_concrete
setblock 342 256 417 minecraft:red_concrete
setblock 348 256 457 minecraft:red_concrete
setblock 349 256 417 minecraft:red_concrete
setblock 355 256 457 minecraft:red_concrete
setblock 356 256 417 minecraft:red_concrete
setblock 362 256 457 minecraft:red_concrete
setblock 363 256 417 minecraft:red_concrete
setblock 369 256 457 minecraft:red_concrete
setblock 370 256 417 minecraft:red_concrete
setblock 370 256 424 minecraft:red_concrete
setblock 370 256 431 minecraft:red_concrete
setblock 370 256 438 minecraft:red_concrete
setblock 370 256 445 minecraft:red_concrete
setblock 370 256 452 minecraft:red_concrete
setblock 330 257 420 minecraft:red_concrete
setblock 330 257 427 minecraft:red_concrete
setblock 330 257 434 minecraft:red_concrete
setblock 330 257 441 minecraft:red_concrete
setblock 330 257 448 minecraft:red_concrete
setblock 330 257 455 minecraft:red_concrete
fill 333 257 437 333 257 441 minecraft:white_concrete
setblock 334 257 417 minecraft:red_concrete
setblock 335 257 457 minecraft:red_concrete
setblock 341 257 417 minecraft:red_concrete
setblock 342 257 457 minecraft:red_concrete
setblock 348 257 417 minecraft:red_concrete
setblock 349 257 457 minecraft:red_concrete
setblock 355 257 417 minecraft:red_concrete
setblock 356 257 457 minecraft:red_concrete
schedule function dropper:buildpart/103_4 1t
