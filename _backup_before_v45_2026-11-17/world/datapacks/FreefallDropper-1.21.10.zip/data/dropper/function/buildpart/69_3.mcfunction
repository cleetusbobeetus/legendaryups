setblock 426 260 294 minecraft:light[level=15]
setblock 426 260 302 minecraft:light[level=15]
setblock 426 260 310 minecraft:light[level=15]
setblock 434 260 278 minecraft:light[level=15]
setblock 434 260 286 minecraft:light[level=15]
setblock 434 260 294 minecraft:light[level=15]
setblock 434 260 302 minecraft:light[level=15]
setblock 434 260 310 minecraft:light[level=15]
setblock 442 260 278 minecraft:light[level=15]
setblock 442 260 286 minecraft:light[level=15]
setblock 442 260 302 minecraft:light[level=15]
setblock 442 260 310 minecraft:light[level=15]
setblock 450 260 278 minecraft:light[level=15]
setblock 450 260 286 minecraft:light[level=15]
setblock 450 260 294 minecraft:light[level=15]
setblock 450 260 302 minecraft:light[level=15]
setblock 450 260 310 minecraft:light[level=15]
setblock 458 260 278 minecraft:light[level=15]
setblock 458 260 286 minecraft:light[level=15]
setblock 458 260 294 minecraft:light[level=15]
setblock 458 260 302 minecraft:light[level=15]
setblock 458 260 310 minecraft:black_concrete
fill 458 260 312 458 260 313 minecraft:black_concrete
fill 459 260 309 461 260 309 minecraft:black_concrete
fill 459 260 313 462 260 314 minecraft:black_concrete
setblock 462 260 304 minecraft:black_concrete
fill 462 260 310 462 260 312 minecraft:black_concrete
fill 424 261 280 424 261 283 minecraft:gray_concrete
fill 424 261 290 424 261 293 minecraft:gray_concrete
fill 424 261 300 424 261 303 minecraft:gray_concrete
fill 424 261 310 424 261 313 minecraft:gray_concrete
fill 425 261 276 428 261 276 minecraft:gray_concrete
fill 428 261 316 431 261 316 minecraft:gray_concrete
fill 435 261 276 438 261 276 minecraft:gray_concrete
fill 438 261 316 441 261 316 minecraft:gray_concrete
fill 445 261 276 448 261 276 minecraft:gray_concrete
fill 448 261 316 451 261 316 minecraft:gray_concrete
fill 455 261 276 458 261 276 minecraft:gray_concrete
fill 458 261 316 461 261 316 minecraft:gray_concrete
fill 459 261 313 461 262 313 minecraft:gray_concrete
fill 462 261 312 462 264 312 minecraft:gray_concrete
fill 464 261 277 464 261 280 minecraft:gray_concrete
fill 464 261 287 464 261 290 minecraft:gray_concrete
fill 464 261 297 464 261 300 minecraft:gray_concrete
fill 464 261 307 464 261 310 minecraft:gray_concrete
setblock 426 262 278 minecraft:light[level=12]
setblock 426 262 285 minecraft:light[level=12]
setblock 426 262 292 minecraft:light[level=12]
setblock 426 262 299 minecraft:light[level=12]
setblock 426 262 306 minecraft:light[level=12]
setblock 426 262 313 minecraft:light[level=12]
setblock 433 262 278 minecraft:light[level=12]
setblock 433 262 285 minecraft:light[level=12]
setblock 433 262 292 minecraft:light[level=12]
setblock 433 262 299 minecraft:light[level=12]
setblock 433 262 306 minecraft:light[level=12]
setblock 433 262 313 minecraft:light[level=12]
setblock 440 262 278 minecraft:light[level=12]
setblock 440 262 285 minecraft:light[level=12]
setblock 440 262 292 minecraft:light[level=12]
setblock 440 262 299 minecraft:light[level=12]
setblock 440 262 306 minecraft:light[level=12]
setblock 440 262 313 minecraft:light[level=12]
setblock 447 262 278 minecraft:light[level=12]
setblock 447 262 285 minecraft:light[level=12]
setblock 447 262 292 minecraft:light[level=12]
setblock 447 262 299 minecraft:light[level=12]
setblock 447 262 306 minecraft:light[level=12]
setblock 447 262 313 minecraft:light[level=12]
setblock 454 262 278 minecraft:light[level=12]
setblock 454 262 285 minecraft:light[level=12]
setblock 454 262 292 minecraft:light[level=12]
setblock 454 262 299 minecraft:light[level=12]
setblock 454 262 306 minecraft:light[level=12]
setblock 454 262 313 minecraft:light[level=12]
setblock 461 262 278 minecraft:light[level=12]
setblock 461 262 285 minecraft:light[level=12]
setblock 461 262 292 minecraft:light[level=12]
setblock 461 262 299 minecraft:light[level=12]
setblock 461 262 306 minecraft:light[level=12]
fill 458 263 310 458 264 310 minecraft:magenta_concrete
fill 458 263 312 458 264 312 minecraft:magenta_concrete
fill 459 263 309 460 264 309 minecraft:magenta_concrete
fill 459 263 313 461 264 314 minecraft:magenta_concrete
fill 462 263 311 462 264 311 minecraft:magenta_concrete
fill 462 263 313 462 264 313 minecraft:magenta_concrete
setblock 424 264 278 minecraft:gray_concrete
setblock 424 264 288 minecraft:gray_concrete
setblock 424 264 298 minecraft:gray_concrete
setblock 424 264 308 minecraft:gray_concrete
setblock 426 264 316 minecraft:gray_concrete
setblock 430 264 276 minecraft:gray_concrete
setblock 436 264 316 minecraft:gray_concrete
setblock 440 264 276 minecraft:gray_concrete
setblock 446 264 316 minecraft:gray_concrete
setblock 450 264 276 minecraft:gray_concrete
setblock 456 264 316 minecraft:gray_concrete
setblock 460 264 276 minecraft:gray_concrete
setblock 464 264 282 minecraft:gray_concrete
setblock 464 264 292 minecraft:gray_concrete
setblock 464 264 302 minecraft:gray_concrete
setblock 464 264 312 minecraft:gray_concrete
setblock 439 266 295 minecraft:white_concrete
fill 439 266 296 439 278 296 minecraft:light_gray_concrete
fill 440 266 293 440 268 293 minecraft:light_gray_concrete
setblock 440 266 294 minecraft:white_concrete
fill 440 266 295 440 268 295 minecraft:light_gray_concrete
setblock 440 266 296 minecraft:white_concrete
fill 440 266 297 440 268 297 minecraft:light_gray_concrete
setblock 440 266 298 minecraft:white_concrete
fill 441 266 292 441 278 292 minecraft:light_gray_concrete
setblock 441 266 293 minecraft:white_concrete
fill 441 266 294 441 268 294 minecraft:light_gray_concrete
setblock 441 266 295 minecraft:white_concrete
fill 441 266 296 441 268 296 minecraft:light_gray_concrete
setblock 441 266 297 minecraft:white_concrete
fill 441 266 298 441 278 298 minecraft:light_gray_concrete
setblock 441 266 299 minecraft:sea_lantern
setblock 442 266 292 minecraft:white_concrete
fill 442 266 293 442 268 293 minecraft:light_gray_concrete
setblock 442 266 296 minecraft:sea_lantern
fill 442 266 297 442 268 297 minecraft:light_gray_concrete
setblock 442 266 298 minecraft:white_concrete
fill 442 266 299 442 278 299 minecraft:light_gray_concrete
fill 443 266 292 443 278 292 minecraft:light_gray_concrete
setblock 443 266 293 minecraft:sea_lantern
fill 443 266 296 443 268 296 minecraft:light_gray_concrete
setblock 443 266 297 minecraft:white_concrete
fill 443 266 298 443 278 298 minecraft:light_gray_concrete
setblock 443 266 299 minecraft:white_concrete
setblock 444 266 292 minecraft:white_concrete
fill 444 266 293 444 268 293 minecraft:light_gray_concrete
setblock 444 266 294 minecraft:white_concrete
fill 444 266 295 444 268 295 minecraft:light_gray_concrete
setblock 444 266 296 minecraft:white_concrete
fill 444 266 297 444 268 297 minecraft:light_gray_concrete
setblock 444 266 298 minecraft:white_concrete
fill 444 266 299 444 282 299 minecraft:light_gray_concrete
fill 445 266 292 445 278 292 minecraft:light_gray_concrete
setblock 445 266 293 minecraft:white_concrete
fill 445 266 294 445 278 294 minecraft:light_gray_concrete
setblock 445 266 295 minecraft:white_concrete
fill 445 266 296 445 278 296 minecraft:light_gray_concrete
setblock 445 266 297 minecraft:white_concrete
setblock 445 266 298 minecraft:sea_lantern
setblock 445 266 299 minecraft:white_concrete
fill 446 266 293 446 282 293 minecraft:light_gray_concrete
setblock 446 266 294 minecraft:white_concrete
setblock 446 266 295 minecraft:sea_lantern
setblock 446 266 296 minecraft:white_concrete
fill 446 266 297 446 282 297 minecraft:light_gray_concrete
setblock 446 266 298 minecraft:white_concrete
setblock 447 266 295 minecraft:white_concrete
fill 447 266 296 447 282 296 minecraft:light_gray_concrete
setblock 438 267 293 minecraft:white_concrete
fill 438 267 294 438 278 294 minecraft:light_gray_concrete
setblock 438 267 295 minecraft:white_concrete
fill 438 267 296 438 278 296 minecraft:light_gray_concrete
setblock 438 267 297 minecraft:white_concrete
fill 438 267 298 438 281 298 minecraft:light_gray_concrete
setblock 439 267 292 minecraft:white_concrete
fill 439 267 293 439 278 293 minecraft:light_gray_concrete
setblock 439 267 294 minecraft:white_concrete
fill 439 267 295 439 268 295 minecraft:light_gray_concrete
fill 439 267 297 439 278 297 minecraft:light_gray_concrete
setblock 439 267 298 minecraft:white_concrete
fill 439 267 299 439 281 299 minecraft:light_gray_concrete
setblock 440 267 291 minecraft:white_concrete
fill 440 267 292 440 278 292 minecraft:light_gray_concrete
fill 440 267 294 440 268 294 minecraft:light_gray_concrete
fill 440 267 296 440 268 296 minecraft:light_gray_concrete
fill 440 267 298 440 278 298 minecraft:light_gray_concrete
setblock 440 267 299 minecraft:white_concrete
fill 440 267 300 440 281 300 minecraft:light_gray_concrete
fill 441 267 291 441 278 291 minecraft:light_gray_concrete
fill 441 267 293 441 268 293 minecraft:light_gray_concrete
fill 441 267 295 441 268 295 minecraft:light_gray_concrete
fill 441 267 297 441 268 297 minecraft:light_gray_concrete
fill 441 267 299 441 278 299 minecraft:light_gray_concrete
setblock 441 267 300 minecraft:white_concrete
fill 442 267 290 442 281 290 minecraft:light_gray_concrete
setblock 442 267 291 minecraft:sea_lantern
fill 442 267 292 442 268 292 minecraft:light_gray_concrete
fill 442 267 296 442 268 296 minecraft:light_gray_concrete
fill 442 267 298 442 268 298 minecraft:light_gray_concrete
fill 442 267 300 442 281 300 minecraft:light_gray_concrete
setblock 442 267 301 minecraft:white_concrete
setblock 443 267 290 minecraft:white_concrete
fill 443 267 291 443 278 291 minecraft:light_gray_concrete
fill 443 267 293 443 268 293 minecraft:light_gray_concrete
fill 443 267 297 443 268 297 minecraft:light_gray_concrete
fill 443 267 299 443 278 299 minecraft:light_gray_concrete
setblock 443 267 300 minecraft:white_concrete
fill 443 267 301 443 281 301 minecraft:light_gray_concrete
fill 444 267 290 444 281 290 minecraft:light_gray_concrete
setblock 444 267 291 minecraft:white_concrete
fill 444 267 292 444 278 292 minecraft:light_gray_concrete
fill 444 267 294 444 268 294 minecraft:light_gray_concrete
fill 444 267 296 444 268 296 minecraft:light_gray_concrete
fill 444 267 298 446 278 298 minecraft:light_gray_concrete
fill 444 267 300 444 281 300 minecraft:light_gray_concrete
setblock 444 267 301 minecraft:white_concrete
fill 445 267 291 445 281 291 minecraft:light_gray_concrete
fill 445 267 293 445 278 293 minecraft:light_gray_concrete
fill 445 267 295 447 268 295 minecraft:light_gray_concrete
fill 445 267 297 445 278 297 minecraft:light_gray_concrete
fill 445 267 299 445 283 299 minecraft:light_gray_concrete
setblock 445 267 300 minecraft:white_concrete
setblock 446 267 291 minecraft:white_concrete
fill 446 267 292 446 281 292 minecraft:light_gray_concrete
fill 446 267 294 446 278 294 minecraft:light_gray_concrete
fill 446 267 296 446 278 296 minecraft:light_gray_concrete
setblock 446 267 299 minecraft:white_concrete
fill 446 267 300 446 281 300 minecraft:light_gray_concrete
setblock 447 267 292 minecraft:white_concrete
fill 447 267 293 447 281 293 minecraft:light_gray_concrete
setblock 447 267 294 minecraft:white_concrete
fill 447 267 297 447 281 297 minecraft:light_gray_concrete
setblock 447 267 298 minecraft:sea_lantern
fill 447 267 299 447 281 299 minecraft:light_gray_concrete
setblock 448 267 293 minecraft:white_concrete
fill 448 267 294 448 281 294 minecraft:light_gray_concrete
setblock 448 267 295 minecraft:sea_lantern
fill 448 267 296 448 281 296 minecraft:light_gray_concrete
setblock 448 267 297 minecraft:white_concrete
fill 448 267 298 448 281 298 minecraft:light_gray_concrete
setblock 426 268 278 minecraft:light[level=15]
setblock 426 268 285 minecraft:light[level=12]
setblock 426 268 286 minecraft:light[level=15]
setblock 426 268 292 minecraft:light[level=12]
setblock 426 268 294 minecraft:light[level=15]
setblock 426 268 299 minecraft:light[level=12]
setblock 426 268 302 minecraft:light[level=15]
setblock 426 268 306 minecraft:light[level=12]
setblock 426 268 310 minecraft:light[level=15]
setblock 426 268 313 minecraft:light[level=12]
setblock 433 268 278 minecraft:light[level=12]
setblock 433 268 285 minecraft:light[level=12]
setblock 433 268 292 minecraft:light[level=12]
setblock 433 268 299 minecraft:light[level=12]
setblock 433 268 306 minecraft:light[level=12]
setblock 433 268 313 minecraft:light[level=12]
setblock 434 268 278 minecraft:light[level=15]
setblock 434 268 286 minecraft:light[level=15]
setblock 434 268 294 minecraft:light[level=15]
setblock 434 268 302 minecraft:light[level=15]
setblock 434 268 310 minecraft:light[level=15]
setblock 437 268 293 minecraft:white_concrete
fill 437 268 294 437 280 294 minecraft:light_gray_concrete
setblock 437 268 295 minecraft:white_concrete
fill 437 268 296 437 280 296 minecraft:light_gray_concrete
setblock 437 268 297 minecraft:white_concrete
fill 437 268 298 437 280 298 minecraft:light_gray_concrete
fill 438 268 291 438 280 291 minecraft:light_gray_concrete
setblock 438 268 292 minecraft:white_concrete
fill 438 268 293 438 282 293 minecraft:light_gray_concrete
fill 438 268 295 438 278 295 minecraft:light_gray_concrete
fill 438 268 297 438 282 297 minecraft:light_gray_concrete
fill 438 268 299 438 280 299 minecraft:light_gray_concrete
setblock 438 268 300 minecraft:white_concrete
fill 439 268 290 439 280 290 minecraft:light_gray_concrete
setblock 439 268 291 minecraft:white_concrete
fill 439 268 292 439 278 292 minecraft:light_gray_concrete
fill 439 268 294 439 278 294 minecraft:light_gray_concrete
fill 439 268 298 439 278 298 minecraft:light_gray_concrete
fill 439 268 300 439 280 300 minecraft:light_gray_concrete
setblock 439 268 301 minecraft:white_concrete
setblock 440 268 278 minecraft:light[level=12]
setblock 440 268 285 minecraft:light[level=12]
setblock 440 268 290 minecraft:white_concrete
fill 440 268 291 440 282 291 minecraft:light_gray_concrete
fill 440 268 299 440 281 299 minecraft:light_gray_concrete
fill 440 268 301 440 280 301 minecraft:light_gray_concrete
setblock 440 268 306 minecraft:light[level=12]
setblock 440 268 313 minecraft:light[level=12]
setblock 441 268 289 minecraft:sea_lantern
fill 441 268 290 441 280 290 minecraft:light_gray_concrete
fill 441 268 300 441 282 300 minecraft:light_gray_concrete
setblock 441 268 301 minecraft:white_concrete
setblock 441 268 302 minecraft:light_gray_concrete
setblock 442 268 278 minecraft:light[level=15]
setblock 442 268 286 minecraft:light[level=15]
fill 442 268 289 442 280 289 minecraft:light_gray_concrete
fill 442 268 291 442 278 291 minecraft:light_gray_concrete
fill 442 268 301 442 282 301 minecraft:light_gray_concrete
setblock 442 268 302 minecraft:white_concrete
setblock 442 268 310 minecraft:light[level=15]
setblock 443 268 289 minecraft:white_concrete
fill 443 268 290 443 281 290 minecraft:light_gray_concrete
fill 443 268 300 443 282 300 minecraft:light_gray_concrete
fill 443 268 302 443 280 302 minecraft:light_gray_concrete
fill 444 268 289 444 280 289 minecraft:light_gray_concrete
fill 444 268 291 444 282 291 minecraft:light_gray_concrete
fill 444 268 301 444 282 301 minecraft:light_gray_concrete
setblock 444 268 302 minecraft:sea_lantern
setblock 445 268 289 minecraft:white_concrete
fill 445 268 290 445 280 290 minecraft:light_gray_concrete
fill 445 268 300 445 282 300 minecraft:light_gray_concrete
setblock 445 268 301 minecraft:white_concrete
setblock 445 268 302 minecraft:light_gray_concrete
setblock 446 268 290 minecraft:white_concrete
fill 446 268 291 446 282 291 minecraft:light_gray_concrete
fill 446 268 299 446 282 299 minecraft:light_gray_concrete
fill 446 268 301 446 280 301 minecraft:light_gray_concrete
setblock 447 268 278 minecraft:light[level=12]
setblock 447 268 285 minecraft:light[level=12]
fill 447 268 290 447 280 290 minecraft:light_gray_concrete
setblock 447 268 291 minecraft:white_concrete
fill 447 268 292 447 282 292 minecraft:light_gray_concrete
fill 447 268 294 447 282 294 minecraft:light_gray_concrete
fill 447 268 298 447 282 298 minecraft:light_gray_concrete
fill 447 268 300 447 280 300 minecraft:light_gray_concrete
setblock 447 268 301 minecraft:white_concrete
setblock 447 268 306 minecraft:light[level=12]
setblock 447 268 313 minecraft:light[level=12]
fill 448 268 291 448 280 291 minecraft:light_gray_concrete
setblock 448 268 292 minecraft:white_concrete
fill 448 268 293 448 282 293 minecraft:light_gray_concrete
fill 448 268 295 448 282 295 minecraft:light_gray_concrete
fill 448 268 297 448 281 297 minecraft:light_gray_concrete
fill 448 268 299 448 280 299 minecraft:light_gray_concrete
setblock 448 268 300 minecraft:white_concrete
setblock 449 268 293 minecraft:white_concrete
fill 449 268 294 449 280 294 minecraft:light_gray_concrete
setblock 449 268 295 minecraft:white_concrete
fill 449 268 296 449 280 296 minecraft:light_gray_concrete
setblock 449 268 297 minecraft:white_concrete
setblock 449 268 298 minecraft:sea_lantern
setblock 450 268 278 minecraft:light[level=15]
setblock 450 268 286 minecraft:light[level=15]
setblock 450 268 294 minecraft:light[level=15]
setblock 450 268 302 minecraft:light[level=15]
setblock 450 268 310 minecraft:light[level=15]
setblock 454 268 278 minecraft:light[level=12]
setblock 454 268 285 minecraft:light[level=12]
setblock 454 268 292 minecraft:light[level=12]
setblock 454 268 299 minecraft:light[level=12]
setblock 454 268 306 minecraft:light[level=12]
setblock 454 268 313 minecraft:light[level=12]
setblock 458 268 278 minecraft:light[level=15]
setblock 458 268 286 minecraft:light[level=15]
setblock 458 268 294 minecraft:light[level=15]
setblock 458 268 302 minecraft:light[level=15]
setblock 458 268 310 minecraft:light[level=15]
setblock 461 268 278 minecraft:light[level=12]
setblock 461 268 285 minecraft:light[level=12]
setblock 461 268 292 minecraft:light[level=12]
setblock 461 268 299 minecraft:light[level=12]
setblock 461 268 306 minecraft:light[level=12]
setblock 461 268 313 minecraft:light[level=12]
setblock 436 269 293 minecraft:white_concrete
fill 436 269 294 436 279 294 minecraft:light_gray_concrete
setblock 436 269 295 minecraft:white_concrete
fill 436 269 296 436 279 296 minecraft:light_gray_concrete
setblock 436 269 297 minecraft:white_concrete
setblock 436 269 298 minecraft:light_gray_concrete
fill 437 269 291 437 279 291 minecraft:light_gray_concrete
setblock 437 269 292 minecraft:white_concrete
fill 437 269 293 437 281 293 minecraft:light_gray_concrete
fill 437 269 295 437 281 295 minecraft:light_gray_concrete
fill 437 269 297 437 281 297 minecraft:light_gray_concrete
fill 437 269 299 437 279 299 minecraft:light_gray_concrete
setblock 437 269 300 minecraft:white_concrete
fill 438 269 290 438 279 290 minecraft:light_gray_concrete
fill 438 269 292 438 281 292 minecraft:light_gray_concrete
fill 438 269 300 438 281 300 minecraft:light_gray_concrete
setblock 438 269 301 minecraft:white_concrete
setblock 439 269 289 minecraft:light_gray_concrete
fill 439 269 291 439 281 291 minecraft:light_gray_concrete
fill 439 269 301 439 281 301 minecraft:light_gray_concrete
setblock 439 269 302 minecraft:white_concrete
setblock 440 269 289 minecraft:white_concrete
fill 440 269 290 440 281 290 minecraft:light_gray_concrete
fill 440 269 302 440 279 302 minecraft:light_gray_concrete
fill 441 269 289 441 279 289 minecraft:light_gray_concrete
fill 441 269 301 441 280 301 minecraft:light_gray_concrete
setblock 441 269 302 minecraft:white_concrete
setblock 442 269 288 minecraft:light_gray_concrete
fill 442 269 302 442 281 302 minecraft:light_gray_concrete
setblock 442 269 303 minecraft:sea_lantern
setblock 443 269 288 minecraft:white_concrete
fill 443 269 289 443 281 289 minecraft:light_gray_concrete
setblock 443 269 303 minecraft:light_gray_concrete
setblock 444 269 288 minecraft:light_gray_concrete
fill 444 269 302 444 281 302 minecraft:light_gray_concrete
setblock 444 269 303 minecraft:white_concrete
fill 445 269 289 445 279 289 minecraft:light_gray_concrete
fill 445 269 301 445 281 301 minecraft:light_gray_concrete
setblock 445 269 302 minecraft:white_concrete
setblock 446 269 289 minecraft:white_concrete
fill 446 269 290 446 281 290 minecraft:light_gray_concrete
fill 446 269 295 447 278 295 minecraft:light_gray_concrete
setblock 446 269 302 minecraft:sea_lantern
setblock 447 269 289 minecraft:light_gray_concrete
fill 447 269 291 447 281 291 minecraft:light_gray_concrete
fill 447 269 301 447 281 301 minecraft:light_gray_concrete
setblock 447 269 302 minecraft:white_concrete
fill 448 269 290 448 279 290 minecraft:light_gray_concrete
fill 448 269 292 448 281 292 minecraft:light_gray_concrete
fill 448 269 300 448 281 300 minecraft:light_gray_concrete
setblock 448 269 301 minecraft:white_concrete
fill 449 269 291 449 279 291 minecraft:light_gray_concrete
setblock 449 269 292 minecraft:white_concrete
fill 449 269 293 449 281 293 minecraft:light_gray_concrete
fill 449 269 295 449 281 295 minecraft:light_gray_concrete
fill 449 269 297 449 279 299 minecraft:light_gray_concrete
setblock 449 269 300 minecraft:white_concrete
setblock 450 269 293 minecraft:white_concrete
fill 450 269 294 450 279 294 minecraft:light_gray_concrete
setblock 450 269 295 minecraft:white_concrete
fill 450 269 296 450 279 296 minecraft:light_gray_concrete
setblock 450 269 297 minecraft:white_concrete
setblock 450 269 298 minecraft:light_gray_concrete
setblock 435 270 294 minecraft:light_gray_concrete
setblock 435 270 295 minecraft:white_concrete
setblock 435 270 296 minecraft:light_gray_concrete
setblock 435 270 297 minecraft:sea_lantern
setblock 436 270 291 minecraft:light_gray_concrete
setblock 436 270 292 minecraft:white_concrete
fill 436 270 293 436 278 293 minecraft:light_gray_concrete
fill 436 270 295 436 280 295 minecraft:light_gray_concrete
fill 436 270 297 436 280 297 minecraft:light_gray_concrete
setblock 436 270 298 minecraft:white_concrete
fill 436 270 299 436 278 299 minecraft:light_gray_concrete
setblock 436 270 300 minecraft:white_concrete
setblock 437 270 290 minecraft:light_gray_concrete
fill 437 270 292 437 280 292 minecraft:light_gray_concrete
fill 437 270 300 437 280 300 minecraft:light_gray_concrete
setblock 437 270 301 minecraft:white_concrete
setblock 438 270 289 minecraft:light_gray_concrete
fill 438 270 301 438 280 301 minecraft:light_gray_concrete
setblock 438 270 302 minecraft:white_concrete
setblock 439 270 289 minecraft:white_concrete
fill 439 270 302 439 278 302 minecraft:light_gray_concrete
setblock 440 270 288 minecraft:white_concrete
fill 440 270 289 440 280 289 minecraft:light_gray_concrete
setblock 440 270 303 minecraft:light_gray_concrete
fill 441 270 288 441 278 288 minecraft:light_gray_concrete
fill 441 270 302 441 280 302 minecraft:light_gray_concrete
setblock 441 270 303 minecraft:white_concrete
setblock 442 270 288 minecraft:white_concrete
fill 442 270 303 442 278 303 minecraft:light_gray_concrete
fill 443 270 288 443 278 288 minecraft:light_gray_concrete
setblock 443 270 303 minecraft:white_concrete
setblock 444 270 288 minecraft:white_concrete
setblock 444 270 303 minecraft:sea_lantern
fill 445 270 288 445 278 288 minecraft:light_gray_concrete
fill 445 270 302 447 278 302 minecraft:light_gray_concrete
setblock 445 270 303 minecraft:white_concrete
setblock 446 270 288 minecraft:white_concrete
fill 446 270 289 446 280 289 minecraft:light_gray_concrete
setblock 446 270 303 minecraft:light_gray_concrete
setblock 447 270 289 minecraft:white_concrete
setblock 448 270 289 minecraft:light_gray_concrete
fill 448 270 301 448 280 301 minecraft:light_gray_concrete
setblock 448 270 302 minecraft:sea_lantern
setblock 449 270 290 minecraft:light_gray_concrete
fill 449 270 292 449 280 292 minecraft:light_gray_concrete
fill 449 270 300 449 280 300 minecraft:light_gray_concrete
setblock 449 270 301 minecraft:white_concrete
setblock 450 270 291 minecraft:light_gray_concrete
setblock 450 270 292 minecraft:white_concrete
fill 450 270 293 450 278 293 minecraft:light_gray_concrete
fill 450 270 295 450 280 295 minecraft:light_gray_concrete
fill 450 270 297 450 280 297 minecraft:light_gray_concrete
setblock 450 270 298 minecraft:white_concrete
fill 450 270 299 450 278 299 minecraft:light_gray_concrete
setblock 450 270 300 minecraft:white_concrete
setblock 451 270 294 minecraft:light_gray_concrete
setblock 451 270 295 minecraft:white_concrete
setblock 451 270 296 minecraft:light_gray_concrete
setblock 451 270 297 minecraft:white_concrete
setblock 435 271 292 minecraft:sea_lantern
setblock 435 271 293 minecraft:light_gray_concrete
setblock 435 271 294 minecraft:white_concrete
fill 435 271 295 435 277 295 minecraft:light_gray_concrete
setblock 435 271 296 minecraft:white_concrete
fill 435 271 297 435 277 297 minecraft:light_gray_concrete
setblock 435 271 298 minecraft:white_concrete
setblock 435 271 299 minecraft:light_gray_concrete
setblock 436 271 291 minecraft:white_concrete
fill 436 271 292 436 279 292 minecraft:light_gray_concrete
fill 436 271 298 436 279 298 minecraft:light_gray_concrete
setblock 436 271 300 minecraft:sea_lantern
setblock 437 271 290 minecraft:white_concrete
fill 437 271 301 437 277 301 minecraft:light_gray_concrete
setblock 438 271 289 minecraft:white_concrete
fill 438 271 302 438 277 302 minecraft:light_gray_concrete
setblock 439 271 288 minecraft:white_concrete
fill 439 271 289 439 279 289 minecraft:light_gray_concrete
setblock 439 271 303 minecraft:light_gray_concrete
setblock 440 271 288 minecraft:sea_lantern
setblock 440 271 303 minecraft:white_concrete
setblock 441 271 287 minecraft:light_gray_concrete
fill 441 271 303 441 279 303 minecraft:light_gray_concrete
setblock 441 271 304 minecraft:white_concrete
setblock 442 271 287 minecraft:white_concrete
fill 442 271 288 442 279 288 minecraft:light_gray_concrete
setblock 442 271 304 minecraft:sea_lantern
setblock 443 271 287 minecraft:light_gray_concrete
fill 443 271 303 445 278 303 minecraft:light_gray_concrete
setblock 443 271 304 minecraft:white_concrete
setblock 444 271 287 minecraft:sea_lantern
fill 444 271 288 444 279 288 minecraft:light_gray_concrete
setblock 444 271 304 minecraft:light_gray_concrete
setblock 445 271 287 minecraft:light_gray_concrete
setblock 445 271 304 minecraft:white_concrete
fill 446 271 288 446 277 288 minecraft:light_gray_concrete
setblock 446 271 303 minecraft:sea_lantern
setblock 447 271 288 minecraft:white_concrete
fill 447 271 289 447 279 289 minecraft:light_gray_concrete
setblock 447 271 303 minecraft:light_gray_concrete
setblock 448 271 289 minecraft:white_concrete
fill 448 271 302 448 277 302 minecraft:light_gray_concrete
setblock 449 271 290 minecraft:white_concrete
fill 449 271 301 449 277 301 minecraft:light_gray_concrete
setblock 450 271 291 minecraft:sea_lantern
fill 450 271 292 450 279 292 minecraft:light_gray_concrete
fill 450 271 298 450 279 298 minecraft:light_gray_concrete
setblock 450 271 300 minecraft:light_gray_concrete
setblock 451 271 292 minecraft:white_concrete
setblock 451 271 293 minecraft:light_gray_concrete
setblock 451 271 294 minecraft:white_concrete
fill 451 271 295 451 277 295 minecraft:light_gray_concrete
setblock 451 271 296 minecraft:white_concrete
fill 451 271 297 451 277 297 minecraft:light_gray_concrete
setblock 451 271 298 minecraft:white_concrete
setblock 451 271 299 minecraft:sea_lantern
setblock 434 272 294 minecraft:white_concrete
setblock 434 272 295 minecraft:light_gray_concrete
setblock 434 272 296 minecraft:white_concrete
setblock 434 272 297 minecraft:light_gray_concrete
setblock 435 272 292 minecraft:light_gray_concrete
setblock 435 272 293 minecraft:white_concrete
fill 435 272 294 435 278 294 minecraft:light_gray_concrete
fill 435 272 296 435 278 296 minecraft:light_gray_concrete
setblock 435 272 298 minecraft:sea_lantern
setblock 435 272 299 minecraft:white_concrete
setblock 436 272 290 minecraft:white_concrete
fill 436 272 291 436 276 291 minecraft:light_gray_concrete
setblock 436 272 300 minecraft:white_concrete
setblock 436 272 301 minecraft:light_gray_concrete
setblock 437 272 289 minecraft:white_concrete
fill 437 272 290 437 278 290 minecraft:light_gray_concrete
setblock 437 272 302 minecraft:light_gray_concrete
setblock 438 272 288 minecraft:white_concrete
fill 438 272 289 438 278 289 minecraft:light_gray_concrete
setblock 438 272 303 minecraft:light_gray_concrete
fill 439 272 288 440 272 288 minecraft:light_gray_concrete
setblock 439 272 303 minecraft:white_concrete
setblock 440 272 287 minecraft:light_gray_concrete
fill 440 272 303 440 278 303 minecraft:light_gray_concrete
setblock 440 272 304 minecraft:white_concrete
setblock 441 272 287 minecraft:white_concrete
setblock 441 272 304 minecraft:light_gray_concrete
setblock 442 272 287 minecraft:light_gray_concrete
setblock 442 272 304 minecraft:white_concrete
setblock 443 272 287 minecraft:white_concrete
setblock 443 272 304 minecraft:light_gray_concrete
setblock 444 272 287 minecraft:light_gray_concrete
setblock 444 272 304 minecraft:sea_lantern
setblock 445 272 287 minecraft:white_concrete
setblock 445 272 304 minecraft:light_gray_concrete
setblock 446 272 287 minecraft:sea_lantern
fill 446 272 303 446 278 303 minecraft:light_gray_concrete
setblock 446 272 304 minecraft:white_concrete
setblock 447 272 288 minecraft:light_gray_concrete
setblock 447 272 303 minecraft:white_concrete
setblock 448 272 288 minecraft:white_concrete
fill 448 272 289 448 278 289 minecraft:light_gray_concrete
setblock 448 272 303 minecraft:sea_lantern
setblock 449 272 289 minecraft:sea_lantern
fill 449 272 290 449 278 290 minecraft:light_gray_concrete
setblock 449 272 302 minecraft:light_gray_concrete
setblock 450 272 290 minecraft:white_concrete
fill 450 272 291 450 276 291 minecraft:light_gray_concrete
setblock 450 272 300 minecraft:white_concrete
setblock 450 272 301 minecraft:light_gray_concrete
setblock 451 272 292 minecraft:light_gray_concrete
setblock 451 272 293 minecraft:white_concrete
fill 451 272 294 451 278 294 minecraft:light_gray_concrete
fill 451 272 296 451 278 296 minecraft:light_gray_concrete
fill 451 272 298 451 276 298 minecraft:light_gray_concrete
setblock 451 272 299 minecraft:white_concrete
setblock 452 272 294 minecraft:white_concrete
setblock 452 272 295 minecraft:light_gray_concrete
setblock 452 272 296 minecraft:white_concrete
setblock 452 272 297 minecraft:light_gray_concrete
setblock 434 273 293 minecraft:white_concrete
setblock 434 273 294 minecraft:light_gray_concrete
setblock 434 273 295 minecraft:white_concrete
setblock 434 273 296 minecraft:sea_lantern
setblock 434 273 297 minecraft:white_concrete
fill 434 273 298 435 273 298 minecraft:light_gray_concrete
setblock 435 273 291 minecraft:light_gray_concrete
setblock 435 273 292 minecraft:white_concrete
fill 435 273 293 435 277 293 minecraft:light_gray_concrete
setblock 435 273 299 minecraft:light_gray_concrete
setblock 435 273 300 minecraft:white_concrete
setblock 436 273 290 minecraft:sea_lantern
fill 436 273 300 436 277 300 minecraft:light_gray_concrete
setblock 436 273 301 minecraft:sea_lantern
setblock 437 273 289 minecraft:light_gray_concrete
setblock 437 273 302 minecraft:white_concrete
setblock 438 273 288 minecraft:light_gray_concrete
setblock 438 273 303 minecraft:white_concrete
setblock 439 273 288 minecraft:white_concrete
setblock 439 273 303 minecraft:sea_lantern
setblock 440 273 287 minecraft:white_concrete
fill 440 273 288 440 277 288 minecraft:light_gray_concrete
setblock 440 273 304 minecraft:light_gray_concrete
setblock 441 273 287 minecraft:light_gray_concrete
setblock 441 273 304 minecraft:white_concrete
setblock 442 273 287 minecraft:white_concrete
setblock 442 273 304 minecraft:light_gray_concrete
setblock 443 273 287 minecraft:light_gray_concrete
setblock 443 273 304 minecraft:white_concrete
setblock 444 273 287 minecraft:white_concrete
setblock 444 273 304 minecraft:light_gray_concrete
setblock 445 273 287 minecraft:light_gray_concrete
setblock 445 273 304 minecraft:white_concrete
setblock 446 273 287 minecraft:white_concrete
setblock 446 273 304 minecraft:sea_lantern
setblock 447 273 288 minecraft:white_concrete
fill 447 273 303 447 275 303 minecraft:light_gray_concrete
setblock 448 273 288 minecraft:light_gray_concrete
setblock 448 273 303 minecraft:white_concrete
setblock 449 273 289 minecraft:light_gray_concrete
setblock 449 273 302 minecraft:white_concrete
setblock 450 273 290 minecraft:light_gray_concrete
fill 450 273 300 450 277 300 minecraft:light_gray_concrete
setblock 450 273 301 minecraft:white_concrete
setblock 451 273 291 minecraft:light_gray_concrete
setblock 451 273 292 minecraft:white_concrete
fill 451 273 293 451 277 293 minecraft:light_gray_concrete
setblock 451 273 299 minecraft:light_gray_concrete
setblock 451 273 300 minecraft:sea_lantern
setblock 452 273 293 minecraft:white_concrete
setblock 452 273 294 minecraft:light_gray_concrete
setblock 452 273 295 minecraft:white_concrete
setblock 452 273 296 minecraft:light_gray_concrete
setblock 452 273 297 minecraft:sea_lantern
setblock 452 273 298 minecraft:light_gray_concrete
setblock 426 274 278 minecraft:light[level=12]
setblock 426 274 285 minecraft:light[level=12]
setblock 426 274 292 minecraft:light[level=12]
setblock 426 274 299 minecraft:light[level=12]
setblock 426 274 306 minecraft:light[level=12]
setblock 426 274 313 minecraft:light[level=12]
setblock 433 274 278 minecraft:light[level=12]
setblock 433 274 285 minecraft:light[level=12]
setblock 433 274 292 minecraft:light[level=12]
setblock 433 274 299 minecraft:light[level=12]
setblock 433 274 306 minecraft:light[level=12]
setblock 433 274 313 minecraft:light[level=12]
fill 434 274 277 436 274 279 minecraft:black_concrete
setblock 434 274 293 minecraft:light_gray_concrete
setblock 434 274 294 minecraft:white_concrete
setblock 434 274 295 minecraft:light_gray_concrete
setblock 434 274 296 minecraft:white_concrete
setblock 434 274 297 minecraft:light_gray_concrete
setblock 434 274 298 minecraft:white_concrete
setblock 435 274 291 minecraft:white_concrete
setblock 435 274 292 minecraft:light_gray_concrete
fill 435 274 298 435 276 298 minecraft:light_gray_concrete
setblock 435 274 299 minecraft:sea_lantern
setblock 435 274 300 minecraft:light_gray_concrete
setblock 436 274 290 minecraft:white_concrete
setblock 436 274 301 minecraft:light_gray_concrete
setblock 437 274 289 minecraft:white_concrete
setblock 437 274 302 minecraft:light_gray_concrete
setblock 438 274 288 minecraft:white_concrete
fill 438 274 303 439 274 303 minecraft:light_gray_concrete
setblock 439 274 287 minecraft:sea_lantern
fill 439 274 288 439 275 288 minecraft:light_gray_concrete
setblock 439 274 304 minecraft:light_gray_concrete
setblock 440 274 278 minecraft:light[level=12]
setblock 440 274 285 minecraft:light[level=12]
setblock 440 274 287 minecraft:light_gray_concrete
setblock 440 274 304 minecraft:white_concrete
setblock 440 274 306 minecraft:light[level=12]
setblock 440 274 313 minecraft:light[level=12]
setblock 441 274 287 minecraft:white_concrete
setblock 441 274 304 minecraft:light_gray_concrete
setblock 442 274 287 minecraft:light_gray_concrete
setblock 442 274 304 minecraft:white_concrete
setblock 443 274 287 minecraft:white_concrete
setblock 443 274 304 minecraft:light_gray_concrete
setblock 444 274 287 minecraft:light_gray_concrete
setblock 444 274 304 minecraft:white_concrete
setblock 445 274 287 minecraft:white_concrete
setblock 445 274 304 minecraft:light_gray_concrete
setblock 446 274 287 minecraft:light_gray_concrete
setblock 446 274 304 minecraft:white_concrete
setblock 447 274 278 minecraft:light[level=12]
setblock 447 274 285 minecraft:light[level=12]
setblock 447 274 287 minecraft:white_concrete
fill 447 274 288 447 276 288 minecraft:light_gray_concrete
setblock 447 274 304 minecraft:light_gray_concrete
setblock 447 274 306 minecraft:light[level=12]
setblock 447 274 313 minecraft:light[level=12]
setblock 448 274 288 minecraft:white_concrete
setblock 448 274 303 minecraft:light_gray_concrete
setblock 449 274 289 minecraft:white_concrete
setblock 449 274 302 minecraft:light_gray_concrete
setblock 450 274 290 minecraft:white_concrete
setblock 450 274 301 minecraft:light_gray_concrete
setblock 451 274 291 minecraft:white_concrete
setblock 451 274 292 minecraft:light_gray_concrete
setblock 451 274 299 minecraft:white_concrete
setblock 451 274 300 minecraft:light_gray_concrete
setblock 452 274 293 minecraft:light_gray_concrete
setblock 452 274 294 minecraft:white_concrete
setblock 452 274 295 minecraft:light_gray_concrete
setblock 452 274 296 minecraft:white_concrete
setblock 452 274 297 minecraft:light_gray_concrete
setblock 452 274 298 minecraft:white_concrete
setblock 454 274 278 minecraft:light[level=12]
setblock 454 274 285 minecraft:light[level=12]
setblock 454 274 292 minecraft:light[level=12]
setblock 454 274 299 minecraft:light[level=12]
setblock 454 274 306 minecraft:light[level=12]
setblock 454 274 313 minecraft:light[level=12]
setblock 461 274 278 minecraft:light[level=12]
setblock 461 274 285 minecraft:light[level=12]
setblock 461 274 292 minecraft:light[level=12]
setblock 461 274 299 minecraft:light[level=12]
setblock 461 274 306 minecraft:light[level=12]
setblock 461 274 313 minecraft:light[level=12]
fill 434 275 277 434 275 279 minecraft:black_concrete
setblock 434 275 293 minecraft:white_concrete
setblock 434 275 294 minecraft:light_gray_concrete
setblock 434 275 295 minecraft:white_concrete
setblock 434 275 296 minecraft:light_gray_concrete
setblock 434 275 297 minecraft:sea_lantern
setblock 434 275 298 minecraft:light_gray_concrete
fill 435 275 277 436 275 277 minecraft:black_concrete
fill 435 275 278 435 277 278 minecraft:gray_concrete
fill 435 275 279 436 275 279 minecraft:black_concrete
setblock 435 275 291 minecraft:light_gray_concrete
setblock 435 275 292 minecraft:white_concrete
setblock 435 275 299 minecraft:light_gray_concrete
setblock 435 275 300 minecraft:white_concrete
setblock 436 275 278 minecraft:black_concrete
setblock 436 275 290 minecraft:light_gray_concrete
setblock 436 275 301 minecraft:white_concrete
setblock 437 275 289 minecraft:light_gray_concrete
setblock 437 275 302 minecraft:white_concrete
setblock 438 275 288 minecraft:light_gray_concrete
setblock 438 275 303 minecraft:white_concrete
setblock 439 275 287 minecraft:light_gray_concrete
setblock 439 275 303 minecraft:light_gray_concrete
setblock 439 275 304 minecraft:sea_lantern
setblock 440 275 287 minecraft:white_concrete
setblock 440 275 304 minecraft:light_gray_concrete
setblock 441 275 287 minecraft:sea_lantern
setblock 441 275 304 minecraft:white_concrete
setblock 442 275 287 minecraft:white_concrete
setblock 442 275 304 minecraft:light_gray_concrete
setblock 443 275 287 minecraft:light_gray_concrete
setblock 443 275 304 minecraft:white_concrete
setblock 444 275 287 minecraft:white_concrete
setblock 444 275 304 minecraft:light_gray_concrete
setblock 445 275 287 minecraft:light_gray_concrete
setblock 445 275 304 minecraft:white_concrete
setblock 446 275 287 minecraft:white_concrete
setblock 446 275 304 minecraft:light_gray_concrete
setblock 447 275 287 minecraft:light_gray_concrete
setblock 447 275 304 minecraft:white_concrete
setblock 448 275 288 minecraft:sea_lantern
setblock 448 275 303 minecraft:white_concrete
setblock 449 275 289 minecraft:light_gray_concrete
setblock 449 275 302 minecraft:white_concrete
setblock 450 275 290 minecraft:light_gray_concrete
setblock 450 275 301 minecraft:white_concrete
setblock 451 275 291 minecraft:light_gray_concrete
setblock 451 275 292 minecraft:white_concrete
setblock 451 275 299 minecraft:light_gray_concrete
setblock 451 275 300 minecraft:white_concrete
setblock 452 275 293 minecraft:white_concrete
setblock 452 275 294 minecraft:light_gray_concrete
setblock 452 275 295 minecraft:white_concrete
setblock 452 275 296 minecraft:light_gray_concrete
setblock 452 275 297 minecraft:white_concrete
setblock 452 275 298 minecraft:sea_lantern
setblock 426 276 278 minecraft:light[level=15]
setblock 426 276 286 minecraft:light[level=15]
setblock 426 276 294 minecraft:light[level=15]
setblock 426 276 302 minecraft:light[level=15]
setblock 426 276 310 minecraft:light[level=15]
fill 434 276 277 434 278 277 minecraft:black_concrete
setblock 434 276 278 minecraft:gray_concrete
fill 434 276 279 434 278 279 minecraft:black_concrete
setblock 434 276 286 minecraft:light[level=15]
setblock 434 276 293 minecraft:light_gray_concrete
setblock 434 276 294 minecraft:white_concrete
setblock 434 276 295 minecraft:light_gray_concrete
setblock 434 276 296 minecraft:white_concrete
setblock 434 276 297 minecraft:light_gray_concrete
setblock 434 276 298 minecraft:white_concrete
setblock 434 276 302 minecraft:light[level=15]
setblock 434 276 310 minecraft:light[level=15]
setblock 435 276 277 minecraft:gray_concrete
setblock 435 276 279 minecraft:gray_concrete
setblock 435 276 291 minecraft:white_concrete
setblock 435 276 292 minecraft:light_gray_concrete
setblock 435 276 299 minecraft:white_concrete
setblock 435 276 300 minecraft:sea_lantern
fill 436 276 277 436 278 277 minecraft:black_concrete
setblock 436 276 278 minecraft:gray_concrete
fill 436 276 279 436 278 279 minecraft:black_concrete
setblock 436 276 290 minecraft:white_concrete
setblock 436 276 301 minecraft:light_gray_concrete
setblock 437 276 289 minecraft:white_concrete
setblock 437 276 302 minecraft:light_gray_concrete
setblock 438 276 288 minecraft:white_concrete
setblock 438 276 303 minecraft:light_gray_concrete
setblock 439 276 288 minecraft:sea_lantern
setblock 439 276 303 minecraft:white_concrete
setblock 440 276 287 minecraft:light_gray_concrete
setblock 440 276 304 minecraft:white_concrete
setblock 441 276 287 minecraft:white_concrete
setblock 441 276 304 minecraft:sea_lantern
setblock 442 276 278 minecraft:light[level=15]
setblock 442 276 286 minecraft:light[level=15]
setblock 442 276 287 minecraft:light_gray_concrete
setblock 442 276 304 minecraft:white_concrete
setblock 442 276 310 minecraft:light[level=15]
setblock 443 276 287 minecraft:sea_lantern
setblock 443 276 304 minecraft:light_gray_concrete
setblock 444 276 287 minecraft:light_gray_concrete
setblock 444 276 304 minecraft:white_concrete
setblock 445 276 287 minecraft:white_concrete
setblock 445 276 304 minecraft:light_gray_concrete
setblock 446 276 287 minecraft:light_gray_concrete
setblock 446 276 304 minecraft:white_concrete
setblock 447 276 303 minecraft:white_concrete
setblock 448 276 288 minecraft:white_concrete
setblock 448 276 303 minecraft:light_gray_concrete
setblock 449 276 289 minecraft:white_concrete
setblock 449 276 302 minecraft:sea_lantern
setblock 450 276 278 minecraft:light[level=15]
setblock 450 276 286 minecraft:light[level=15]
setblock 450 276 290 minecraft:white_concrete
setblock 450 276 301 minecraft:light_gray_concrete
setblock 450 276 302 minecraft:light[level=15]
setblock 450 276 310 minecraft:light[level=15]
setblock 451 276 291 minecraft:white_concrete
setblock 451 276 292 minecraft:light_gray_concrete
setblock 451 276 299 minecraft:white_concrete
setblock 451 276 300 minecraft:light_gray_concrete
setblock 452 276 293 minecraft:sea_lantern
setblock 452 276 294 minecraft:white_concrete
setblock 452 276 295 minecraft:light_gray_concrete
setblock 452 276 296 minecraft:white_concrete
setblock 452 276 297 minecraft:light_gray_concrete
setblock 452 276 298 minecraft:white_concrete
setblock 458 276 278 minecraft:light[level=15]
setblock 458 276 286 minecraft:light[level=15]
setblock 458 276 294 minecraft:light[level=15]
setblock 458 276 302 minecraft:light[level=15]
setblock 458 276 310 minecraft:light[level=15]
fill 434 277 278 434 278 278 minecraft:black_concrete
setblock 434 277 294 minecraft:light_gray_concrete
setblock 434 277 295 minecraft:white_concrete
setblock 434 277 296 minecraft:light_gray_concrete
setblock 434 277 297 minecraft:white_concrete
fill 435 277 277 435 278 277 minecraft:black_concrete
fill 435 277 279 435 278 279 minecraft:black_concrete
setblock 435 277 292 minecraft:white_concrete
setblock 435 277 298 minecraft:white_concrete
setblock 435 277 299 minecraft:light_gray_concrete
fill 436 277 278 436 278 278 minecraft:black_concrete
setblock 436 277 290 minecraft:light_gray_concrete
setblock 436 277 291 minecraft:white_concrete
setblock 436 277 301 minecraft:white_concrete
setblock 437 277 289 minecraft:sea_lantern
setblock 437 277 302 minecraft:white_concrete
setblock 438 277 288 minecraft:light_gray_concrete
setblock 438 277 303 minecraft:white_concrete
setblock 439 277 288 minecraft:white_concrete
setblock 439 277 303 minecraft:light_gray_concrete
setblock 440 277 287 minecraft:white_concrete
setblock 440 277 304 minecraft:light_gray_concrete
setblock 441 277 287 minecraft:light_gray_concrete
setblock 441 277 304 minecraft:white_concrete
setblock 442 277 287 minecraft:white_concrete
setblock 442 277 304 minecraft:light_gray_concrete
setblock 443 277 287 minecraft:light_gray_concrete
setblock 443 277 304 minecraft:sea_lantern
setblock 444 277 287 minecraft:white_concrete
setblock 444 277 304 minecraft:light_gray_concrete
setblock 445 277 287 minecraft:sea_lantern
setblock 445 277 304 minecraft:white_concrete
setblock 446 277 287 minecraft:white_concrete
setblock 446 277 304 minecraft:light_gray_concrete
setblock 447 277 288 minecraft:white_concrete
setblock 447 277 303 minecraft:sea_lantern
setblock 448 277 288 minecraft:light_gray_concrete
setblock 448 277 303 minecraft:white_concrete
setblock 449 277 289 minecraft:light_gray_concrete
setblock 449 277 302 minecraft:white_concrete
setblock 450 277 290 minecraft:light_gray_concrete
setblock 450 277 291 minecraft:white_concrete
setblock 450 277 301 minecraft:white_concrete
setblock 451 277 292 minecraft:white_concrete
setblock 451 277 298 minecraft:white_concrete
setblock 451 277 299 minecraft:light_gray_concrete
setblock 452 277 294 minecraft:light_gray_concrete
setblock 452 277 295 minecraft:white_concrete
setblock 452 277 296 minecraft:light_gray_concrete
setblock 452 277 297 minecraft:white_concrete
setblock 435 278 278 minecraft:black_concrete
setblock 435 278 292 minecraft:light_gray_concrete
setblock 435 278 293 minecraft:white_concrete
setblock 435 278 295 minecraft:white_concrete
setblock 435 278 297 minecraft:white_concrete
setblock 435 278 298 minecraft:light_gray_concrete
setblock 435 278 299 minecraft:white_concrete
setblock 436 278 291 minecraft:light_gray_concrete
setblock 436 278 300 minecraft:white_concrete
setblock 437 278 301 minecraft:white_concrete
setblock 438 278 302 minecraft:white_concrete
setblock 439 278 288 minecraft:light_gray_concrete
setblock 439 278 303 minecraft:white_concrete
setblock 440 278 288 minecraft:white_concrete
setblock 441 278 287 minecraft:white_concrete
setblock 441 278 304 minecraft:light_gray_concrete
setblock 442 278 287 minecraft:light_gray_concrete
setblock 442 278 304 minecraft:white_concrete
setblock 443 278 287 minecraft:white_concrete
setblock 443 278 304 minecraft:light_gray_concrete
setblock 444 278 287 minecraft:light_gray_concrete
setblock 444 278 304 minecraft:white_concrete
setblock 445 278 287 minecraft:white_concrete
setblock 445 278 304 minecraft:sea_lantern
setblock 446 278 288 minecraft:white_concrete
setblock 447 278 288 minecraft:light_gray_concrete
setblock 447 278 303 minecraft:white_concrete
setblock 448 278 302 minecraft:white_concrete
setblock 449 278 301 minecraft:white_concrete
setblock 450 278 291 minecraft:light_gray_concrete
setblock 450 278 300 minecraft:sea_lantern
setblock 451 278 292 minecraft:light_gray_concrete
setblock 451 278 293 minecraft:white_concrete
setblock 451 278 295 minecraft:white_concrete
setblock 451 278 297 minecraft:sea_lantern
setblock 451 278 298 minecraft:light_gray_concrete
setblock 451 278 299 minecraft:white_concrete
setblock 424 279 276 minecraft:magenta_stained_glass
fill 424 279 277 424 279 280 minecraft:black_stained_glass
setblock 424 279 281 minecraft:magenta_stained_glass
fill 424 279 282 424 279 285 minecraft:black_stained_glass
setblock 424 279 286 minecraft:magenta_stained_glass
fill 424 279 287 424 279 290 minecraft:black_stained_glass
setblock 424 279 291 minecraft:magenta_stained_glass
fill 424 279 292 424 279 295 minecraft:black_stained_glass
setblock 424 279 296 minecraft:magenta_stained_glass
fill 424 279 297 424 279 300 minecraft:black_stained_glass
setblock 424 279 301 minecraft:magenta_stained_glass
fill 424 279 302 424 279 305 minecraft:black_stained_glass
setblock 424 279 306 minecraft:magenta_stained_glass
fill 424 279 307 424 279 310 minecraft:black_stained_glass
setblock 424 279 311 minecraft:magenta_stained_glass
fill 424 279 312 424 279 315 minecraft:black_stained_glass
setblock 424 279 316 minecraft:magenta_stained_glass
fill 425 279 276 428 279 276 minecraft:black_stained_glass
setblock 425 279 277 minecraft:magenta_stained_glass
fill 425 279 278 425 279 281 minecraft:black_stained_glass
setblock 425 279 282 minecraft:magenta_stained_glass
fill 425 279 283 425 279 286 minecraft:black_stained_glass
setblock 425 279 287 minecraft:magenta_stained_glass
fill 425 279 288 425 279 291 minecraft:black_stained_glass
setblock 425 279 292 minecraft:magenta_stained_glass
fill 425 279 293 425 279 296 minecraft:black_stained_glass
setblock 425 279 297 minecraft:magenta_stained_glass
fill 425 279 298 425 279 301 minecraft:black_stained_glass
setblock 425 279 302 minecraft:magenta_stained_glass
fill 425 279 303 425 279 306 minecraft:black_stained_glass
setblock 425 279 307 minecraft:magenta_stained_glass
fill 425 279 308 425 279 311 minecraft:black_stained_glass
setblock 425 279 312 minecraft:magenta_stained_glass
fill 425 279 313 425 279 316 minecraft:black_stained_glass
fill 426 279 277 429 279 277 minecraft:black_stained_glass
setblock 426 279 278 minecraft:magenta_stained_glass
fill 426 279 279 426 279 282 minecraft:black_stained_glass
setblock 426 279 283 minecraft:magenta_stained_glass
fill 426 279 284 426 279 287 minecraft:black_stained_glass
setblock 426 279 288 minecraft:magenta_stained_glass
fill 426 279 289 426 279 292 minecraft:black_stained_glass
setblock 426 279 293 minecraft:magenta_stained_glass
fill 426 279 294 426 279 297 minecraft:black_stained_glass
setblock 426 279 298 minecraft:magenta_stained_glass
fill 426 279 299 426 279 302 minecraft:black_stained_glass
setblock 426 279 303 minecraft:magenta_stained_glass
fill 426 279 304 426 279 307 minecraft:black_stained_glass
setblock 426 279 308 minecraft:magenta_stained_glass
fill 426 279 309 426 279 312 minecraft:black_stained_glass
setblock 426 279 313 minecraft:magenta_stained_glass
fill 426 279 314 426 279 316 minecraft:black_stained_glass
fill 427 279 278 430 279 278 minecraft:black_stained_glass
setblock 427 279 279 minecraft:magenta_stained_glass
fill 427 279 280 427 279 283 minecraft:black_stained_glass
setblock 427 279 284 minecraft:magenta_stained_glass
fill 427 279 285 427 279 288 minecraft:black_stained_glass
setblock 427 279 289 minecraft:magenta_stained_glass
fill 427 279 290 427 279 293 minecraft:black_stained_glass
setblock 427 279 294 minecraft:magenta_stained_glass
fill 427 279 295 427 279 298 minecraft:black_stained_glass
setblock 427 279 299 minecraft:magenta_stained_glass
fill 427 279 300 427 279 303 minecraft:black_stained_glass
setblock 427 279 304 minecraft:magenta_stained_glass
fill 427 279 305 427 279 308 minecraft:black_stained_glass
setblock 427 279 309 minecraft:magenta_stained_glass
fill 427 279 310 427 279 313 minecraft:black_stained_glass
setblock 427 279 314 minecraft:magenta_stained_glass
fill 427 279 315 427 279 316 minecraft:black_stained_glass
fill 428 279 279 431 279 279 minecraft:black_stained_glass
setblock 428 279 280 minecraft:magenta_stained_glass
fill 428 279 281 428 279 284 minecraft:black_stained_glass
setblock 428 279 285 minecraft:magenta_stained_glass
fill 428 279 286 428 279 289 minecraft:black_stained_glass
setblock 428 279 290 minecraft:magenta_stained_glass
fill 428 279 291 428 279 294 minecraft:black_stained_glass
setblock 428 279 295 minecraft:magenta_stained_glass
fill 428 279 296 428 279 299 minecraft:black_stained_glass
setblock 428 279 300 minecraft:magenta_stained_glass
fill 428 279 301 428 279 304 minecraft:black_stained_glass
setblock 428 279 305 minecraft:magenta_stained_glass
fill 428 279 306 428 279 309 minecraft:black_stained_glass
setblock 428 279 310 minecraft:magenta_stained_glass
fill 428 279 311 428 279 314 minecraft:black_stained_glass
setblock 428 279 315 minecraft:magenta_stained_glass
setblock 428 279 316 minecraft:black_stained_glass
setblock 429 279 276 minecraft:magenta_stained_glass
fill 429 279 280 432 279 280 minecraft:black_stained_glass
setblock 429 279 281 minecraft:magenta_stained_glass
fill 429 279 282 429 279 285 minecraft:black_stained_glass
setblock 429 279 286 minecraft:magenta_stained_glass
fill 429 279 287 429 279 290 minecraft:black_stained_glass
setblock 429 279 291 minecraft:magenta_stained_glass
fill 429 279 292 429 279 295 minecraft:black_stained_glass
setblock 429 279 296 minecraft:magenta_stained_glass
fill 429 279 297 429 279 300 minecraft:black_stained_glass
setblock 429 279 301 minecraft:magenta_stained_glass
fill 429 279 302 429 279 305 minecraft:black_stained_glass
setblock 429 279 306 minecraft:magenta_stained_glass
fill 429 279 307 429 279 310 minecraft:black_stained_glass
setblock 429 279 311 minecraft:magenta_stained_glass
fill 429 279 312 429 279 315 minecraft:black_stained_glass
setblock 429 279 316 minecraft:magenta_stained_glass
fill 430 279 276 433 279 276 minecraft:black_stained_glass
setblock 430 279 277 minecraft:magenta_stained_glass
fill 430 279 281 433 279 281 minecraft:black_stained_glass
setblock 430 279 282 minecraft:magenta_stained_glass
fill 430 279 283 430 279 286 minecraft:black_stained_glass
setblock 430 279 287 minecraft:magenta_stained_glass
fill 430 279 288 430 279 291 minecraft:black_stained_glass
setblock 430 279 292 minecraft:magenta_stained_glass
fill 430 279 293 430 279 296 minecraft:black_stained_glass
setblock 430 279 297 minecraft:magenta_stained_glass
fill 430 279 298 430 279 301 minecraft:black_stained_glass
setblock 430 279 302 minecraft:magenta_stained_glass
fill 430 279 303 430 279 306 minecraft:black_stained_glass
setblock 430 279 307 minecraft:magenta_stained_glass
fill 430 279 308 430 279 311 minecraft:black_stained_glass
setblock 430 279 312 minecraft:magenta_stained_glass
fill 430 279 313 430 279 316 minecraft:black_stained_glass
fill 431 279 277 434 279 277 minecraft:black_stained_glass
setblock 431 279 278 minecraft:magenta_stained_glass
fill 431 279 282 434 279 282 minecraft:black_stained_glass
setblock 431 279 283 minecraft:magenta_stained_glass
fill 431 279 284 431 279 287 minecraft:black_stained_glass
setblock 431 279 288 minecraft:magenta_stained_glass
fill 431 279 289 431 279 292 minecraft:black_stained_glass
setblock 431 279 293 minecraft:magenta_stained_glass
fill 431 279 294 431 279 297 minecraft:black_stained_glass
setblock 431 279 298 minecraft:magenta_stained_glass
fill 431 279 299 431 279 302 minecraft:black_stained_glass
setblock 431 279 303 minecraft:magenta_stained_glass
fill 431 279 304 431 279 307 minecraft:black_stained_glass
setblock 431 279 308 minecraft:magenta_stained_glass
fill 431 279 309 431 279 312 minecraft:black_stained_glass
setblock 431 279 313 minecraft:magenta_stained_glass
fill 431 279 314 431 279 316 minecraft:black_stained_glass
fill 432 279 278 435 279 278 minecraft:black_stained_glass
setblock 432 279 279 minecraft:magenta_stained_glass
fill 432 279 283 435 279 283 minecraft:black_stained_glass
setblock 432 279 284 minecraft:magenta_stained_glass
fill 432 279 285 432 279 288 minecraft:black_stained_glass
setblock 432 279 289 minecraft:magenta_stained_glass
fill 432 279 290 432 279 293 minecraft:black_stained_glass
setblock 432 279 294 minecraft:magenta_stained_glass
fill 432 279 295 432 279 298 minecraft:black_stained_glass
setblock 432 279 299 minecraft:magenta_stained_glass
fill 432 279 300 432 279 303 minecraft:black_stained_glass
setblock 432 279 304 minecraft:magenta_stained_glass
fill 432 279 305 432 279 308 minecraft:black_stained_glass
setblock 432 279 309 minecraft:magenta_stained_glass
fill 432 279 310 432 279 313 minecraft:black_stained_glass
setblock 432 279 314 minecraft:magenta_stained_glass
fill 432 279 315 432 279 316 minecraft:black_stained_glass
fill 433 279 279 436 279 279 minecraft:black_stained_glass
setblock 433 279 280 minecraft:magenta_stained_glass
fill 433 279 284 436 279 284 minecraft:black_stained_glass
setblock 433 279 285 minecraft:magenta_stained_glass
fill 433 279 286 433 279 289 minecraft:black_stained_glass
setblock 433 279 290 minecraft:magenta_stained_glass
fill 433 279 291 433 279 294 minecraft:black_stained_glass
setblock 433 279 295 minecraft:magenta_stained_glass
fill 433 279 296 433 279 299 minecraft:black_stained_glass
setblock 433 279 300 minecraft:magenta_stained_glass
fill 433 279 301 433 279 304 minecraft:black_stained_glass
setblock 433 279 305 minecraft:magenta_stained_glass
fill 433 279 306 433 279 309 minecraft:black_stained_glass
setblock 433 279 310 minecraft:magenta_stained_glass
fill 433 279 311 433 279 314 minecraft:black_stained_glass
setblock 433 279 315 minecraft:magenta_stained_glass
setblock 433 279 316 minecraft:black_stained_glass
setblock 434 279 276 minecraft:magenta_stained_glass
fill 434 279 280 437 279 280 minecraft:black_stained_glass
setblock 434 279 281 minecraft:magenta_stained_glass
fill 434 279 285 437 279 285 minecraft:black_stained_glass
setblock 434 279 286 minecraft:magenta_stained_glass
fill 434 279 287 434 279 290 minecraft:black_stained_glass
setblock 434 279 291 minecraft:magenta_stained_glass
fill 434 279 292 434 279 295 minecraft:black_stained_glass
setblock 434 279 296 minecraft:magenta_stained_glass
fill 434 279 297 434 279 300 minecraft:black_stained_glass
setblock 434 279 301 minecraft:magenta_stained_glass
fill 434 279 302 434 279 305 minecraft:black_stained_glass
setblock 434 279 306 minecraft:magenta_stained_glass
fill 434 279 307 434 279 310 minecraft:black_stained_glass
setblock 434 279 311 minecraft:magenta_stained_glass
fill 434 279 312 434 279 315 minecraft:black_stained_glass
setblock 434 279 316 minecraft:magenta_stained_glass
fill 435 279 276 438 279 276 minecraft:black_stained_glass
setblock 435 279 277 minecraft:magenta_stained_glass
fill 435 279 281 438 279 281 minecraft:black_stained_glass
setblock 435 279 282 minecraft:magenta_stained_glass
fill 435 279 286 438 279 286 minecraft:black_stained_glass
setblock 435 279 287 minecraft:magenta_stained_glass
fill 435 279 288 435 279 291 minecraft:black_stained_glass
setblock 435 279 292 minecraft:magenta_stained_glass
setblock 435 279 293 minecraft:black_stained_glass
setblock 435 279 294 minecraft:white_concrete
setblock 435 279 295 minecraft:light_gray_concrete
setblock 435 279 296 minecraft:sea_lantern
setblock 435 279 297 minecraft:light_gray_concrete
fill 435 279 298 435 279 301 minecraft:black_stained_glass
setblock 435 279 302 minecraft:magenta_stained_glass
fill 435 279 303 435 279 306 minecraft:black_stained_glass
setblock 435 279 307 minecraft:magenta_stained_glass
fill 435 279 308 435 279 311 minecraft:black_stained_glass
setblock 435 279 312 minecraft:magenta_stained_glass
fill 435 279 313 435 279 316 minecraft:black_stained_glass
fill 436 279 277 439 279 277 minecraft:black_stained_glass
setblock 436 279 278 minecraft:magenta_stained_glass
fill 436 279 282 439 279 282 minecraft:black_stained_glass
setblock 436 279 283 minecraft:magenta_stained_glass
fill 436 279 287 439 279 287 minecraft:black_stained_glass
setblock 436 279 288 minecraft:magenta_stained_glass
fill 436 279 289 436 279 290 minecraft:black_stained_glass
setblock 436 279 291 minecraft:white_concrete
setblock 436 279 293 minecraft:sea_lantern
setblock 436 279 299 minecraft:white_concrete
setblock 436 279 300 minecraft:light_gray_concrete
fill 436 279 301 436 279 302 minecraft:black_stained_glass
setblock 436 279 303 minecraft:magenta_stained_glass
fill 436 279 304 436 279 307 minecraft:black_stained_glass
setblock 436 279 308 minecraft:magenta_stained_glass
fill 436 279 309 436 279 312 minecraft:black_stained_glass
setblock 436 279 313 minecraft:magenta_stained_glass
fill 436 279 314 436 279 316 minecraft:black_stained_glass
fill 437 279 278 440 279 278 minecraft:black_stained_glass
setblock 437 279 279 minecraft:magenta_stained_glass
fill 437 279 283 440 279 283 minecraft:black_stained_glass
setblock 437 279 284 minecraft:magenta_stained_glass
fill 437 279 288 439 279 288 minecraft:black_stained_glass
setblock 437 279 289 minecraft:magenta_stained_glass
setblock 437 279 290 minecraft:sea_lantern
setblock 437 279 301 minecraft:sea_lantern
fill 437 279 302 437 279 303 minecraft:black_stained_glass
setblock 437 279 304 minecraft:magenta_stained_glass
fill 437 279 305 437 279 308 minecraft:black_stained_glass
setblock 437 279 309 minecraft:magenta_stained_glass
fill 437 279 310 437 279 313 minecraft:black_stained_glass
setblock 437 279 314 minecraft:magenta_stained_glass
fill 437 279 315 437 279 316 minecraft:black_stained_glass
fill 438 279 279 441 279 279 minecraft:black_stained_glass
setblock 438 279 280 minecraft:magenta_stained_glass
fill 438 279 284 441 279 284 minecraft:black_stained_glass
setblock 438 279 285 minecraft:magenta_stained_glass
setblock 438 279 289 minecraft:white_concrete
fill 438 279 294 438 279 296 minecraft:pearlescent_froglight
setblock 438 279 302 minecraft:light_gray_concrete
fill 438 279 303 439 279 304 minecraft:black_stained_glass
setblock 438 279 305 minecraft:magenta_stained_glass
fill 438 279 306 438 279 309 minecraft:black_stained_glass
setblock 438 279 310 minecraft:magenta_stained_glass
fill 438 279 311 438 279 314 minecraft:black_stained_glass
setblock 438 279 315 minecraft:magenta_stained_glass
setblock 438 279 316 minecraft:black_stained_glass
setblock 439 279 276 minecraft:magenta_stained_glass
fill 439 279 280 442 279 280 minecraft:black_stained_glass
setblock 439 279 281 minecraft:magenta_stained_glass
fill 439 279 285 442 279 285 minecraft:black_stained_glass
setblock 439 279 286 minecraft:magenta_stained_glass
fill 439 279 292 439 279 294 minecraft:pearlescent_froglight
fill 439 279 296 439 279 298 minecraft:pearlescent_froglight
setblock 439 279 302 minecraft:white_concrete
fill 439 279 305 442 279 305 minecraft:black_stained_glass
setblock 439 279 306 minecraft:magenta_stained_glass
fill 439 279 307 439 279 310 minecraft:black_stained_glass
setblock 439 279 311 minecraft:magenta_stained_glass
fill 439 279 312 439 279 315 minecraft:black_stained_glass
setblock 439 279 316 minecraft:magenta_stained_glass
fill 440 279 276 443 279 276 minecraft:black_stained_glass
setblock 440 279 277 minecraft:magenta_stained_glass
fill 440 279 281 443 279 281 minecraft:black_stained_glass
setblock 440 279 282 minecraft:magenta_stained_glass
fill 440 279 286 443 279 286 minecraft:black_stained_glass
setblock 440 279 287 minecraft:magenta_stained_glass
setblock 440 279 288 minecraft:light_gray_concrete
fill 440 279 292 441 279 292 minecraft:pearlescent_froglight
fill 440 279 298 441 279 298 minecraft:pearlescent_froglight
setblock 440 279 303 minecraft:sea_lantern
fill 440 279 304 441 279 304 minecraft:black_stained_glass
fill 440 279 306 443 279 306 minecraft:black_stained_glass
setblock 440 279 307 minecraft:magenta_stained_glass
fill 440 279 308 440 279 311 minecraft:black_stained_glass
setblock 440 279 312 minecraft:magenta_stained_glass
fill 440 279 313 440 279 316 minecraft:black_stained_glass
fill 441 279 277 444 279 277 minecraft:black_stained_glass
setblock 441 279 278 minecraft:magenta_stained_glass
fill 441 279 282 444 279 282 minecraft:black_stained_glass
setblock 441 279 283 minecraft:magenta_stained_glass
fill 441 279 287 444 279 287 minecraft:black_stained_glass
setblock 441 279 288 minecraft:white_concrete
fill 441 279 291 443 279 291 minecraft:pearlescent_froglight
fill 441 279 299 443 279 299 minecraft:pearlescent_froglight
fill 441 279 307 444 279 307 minecraft:black_stained_glass
setblock 441 279 308 minecraft:magenta_stained_glass
fill 441 279 309 441 279 312 minecraft:black_stained_glass
setblock 441 279 313 minecraft:magenta_stained_glass
fill 441 279 314 441 279 316 minecraft:black_stained_glass
fill 442 279 278 445 279 278 minecraft:black_stained_glass
setblock 442 279 279 minecraft:magenta_stained_glass
fill 442 279 283 445 279 283 minecraft:black_stained_glass
setblock 442 279 284 minecraft:magenta_stained_glass
setblock 442 279 303 minecraft:white_concrete
setblock 442 279 304 minecraft:magenta_stained_glass
fill 442 279 308 445 279 308 minecraft:black_stained_glass
setblock 442 279 309 minecraft:magenta_stained_glass
fill 442 279 310 442 279 313 minecraft:black_stained_glass
setblock 442 279 314 minecraft:magenta_stained_glass
fill 442 279 315 442 279 316 minecraft:black_stained_glass
fill 443 279 279 446 279 279 minecraft:black_stained_glass
setblock 443 279 280 minecraft:magenta_stained_glass
fill 443 279 284 446 279 284 minecraft:black_stained_glass
setblock 443 279 285 minecraft:magenta_stained_glass
setblock 443 279 288 minecraft:white_concrete
fill 443 279 292 445 279 292 minecraft:pearlescent_froglight
fill 443 279 298 445 279 298 minecraft:pearlescent_froglight
setblock 443 279 303 minecraft:light_gray_concrete
fill 443 279 304 446 279 304 minecraft:black_stained_glass
setblock 443 279 305 minecraft:magenta_stained_glass
fill 443 279 309 446 279 309 minecraft:black_stained_glass
setblock 443 279 310 minecraft:magenta_stained_glass
fill 443 279 311 443 279 314 minecraft:black_stained_glass
setblock 443 279 315 minecraft:magenta_stained_glass
setblock 443 279 316 minecraft:black_stained_glass
setblock 444 279 276 minecraft:magenta_stained_glass
fill 444 279 280 447 279 280 minecraft:black_stained_glass
setblock 444 279 281 minecraft:magenta_stained_glass
fill 444 279 285 447 279 285 minecraft:black_stained_glass
setblock 444 279 286 minecraft:magenta_stained_glass
setblock 444 279 303 minecraft:white_concrete
fill 444 279 305 447 279 305 minecraft:black_stained_glass
setblock 444 279 306 minecraft:magenta_stained_glass
fill 444 279 310 447 279 310 minecraft:black_stained_glass
setblock 444 279 311 minecraft:magenta_stained_glass
fill 444 279 312 444 279 315 minecraft:black_stained_glass
setblock 444 279 316 minecraft:magenta_stained_glass
fill 445 279 276 448 279 276 minecraft:black_stained_glass
setblock 445 279 277 minecraft:magenta_stained_glass
fill 445 279 281 448 279 281 minecraft:black_stained_glass
setblock 445 279 282 minecraft:magenta_stained_glass
fill 445 279 286 448 279 286 minecraft:black_stained_glass
setblock 445 279 287 minecraft:magenta_stained_glass
setblock 445 279 288 minecraft:sea_lantern
fill 445 279 293 445 279 294 minecraft:pearlescent_froglight
fill 445 279 296 445 279 297 minecraft:pearlescent_froglight
fill 445 279 302 445 279 303 minecraft:light_gray_concrete
fill 445 279 306 448 279 306 minecraft:black_stained_glass
setblock 445 279 307 minecraft:magenta_stained_glass
fill 445 279 311 448 279 311 minecraft:black_stained_glass
setblock 445 279 312 minecraft:magenta_stained_glass
fill 445 279 313 445 279 316 minecraft:black_stained_glass
fill 446 279 277 449 279 277 minecraft:black_stained_glass
setblock 446 279 278 minecraft:magenta_stained_glass
fill 446 279 282 449 279 282 minecraft:black_stained_glass
setblock 446 279 283 minecraft:magenta_stained_glass
fill 446 279 287 449 279 287 minecraft:black_stained_glass
setblock 446 279 288 minecraft:light_gray_concrete
fill 446 279 294 446 279 296 minecraft:pearlescent_froglight
fill 446 279 298 446 282 298 minecraft:light_gray_concrete
setblock 446 279 302 minecraft:light_gray_concrete
setblock 446 279 303 minecraft:white_concrete
fill 446 279 307 449 279 307 minecraft:black_stained_glass
setblock 446 279 308 minecraft:magenta_stained_glass
fill 446 279 312 449 279 312 minecraft:black_stained_glass
setblock 446 279 313 minecraft:magenta_stained_glass
fill 446 279 314 446 279 316 minecraft:black_stained_glass
fill 447 279 278 450 279 278 minecraft:black_stained_glass
setblock 447 279 279 minecraft:magenta_stained_glass
fill 447 279 283 450 279 283 minecraft:black_stained_glass
setblock 447 279 284 minecraft:magenta_stained_glass
fill 447 279 288 450 279 288 minecraft:black_stained_glass
fill 447 279 295 447 282 295 minecraft:light_gray_concrete
setblock 447 279 302 minecraft:white_concrete
fill 447 279 303 450 279 303 minecraft:black_stained_glass
setblock 447 279 304 minecraft:magenta_stained_glass
fill 447 279 308 450 279 308 minecraft:black_stained_glass
setblock 447 279 309 minecraft:magenta_stained_glass
fill 447 279 313 450 279 313 minecraft:black_stained_glass
setblock 447 279 314 minecraft:magenta_stained_glass
fill 447 279 315 447 279 316 minecraft:black_stained_glass
fill 448 279 279 451 279 279 minecraft:black_stained_glass
setblock 448 279 280 minecraft:magenta_stained_glass
fill 448 279 284 451 279 284 minecraft:black_stained_glass
setblock 448 279 285 minecraft:magenta_stained_glass
setblock 448 279 289 minecraft:white_concrete
setblock 448 279 302 minecraft:light_gray_concrete
fill 448 279 304 451 279 304 minecraft:black_stained_glass
setblock 448 279 305 minecraft:magenta_stained_glass
fill 448 279 309 451 279 309 minecraft:black_stained_glass
setblock 448 279 310 minecraft:magenta_stained_glass
fill 448 279 314 451 279 314 minecraft:black_stained_glass
setblock 448 279 315 minecraft:magenta_stained_glass
setblock 448 279 316 minecraft:black_stained_glass
setblock 449 279 276 minecraft:magenta_stained_glass
fill 449 279 280 452 279 280 minecraft:black_stained_glass
setblock 449 279 281 minecraft:magenta_stained_glass
fill 449 279 285 452 279 285 minecraft:black_stained_glass
setblock 449 279 286 minecraft:magenta_stained_glass
fill 449 279 289 451 279 289 minecraft:black_stained_glass
setblock 449 279 290 minecraft:white_concrete
setblock 449 279 301 minecraft:light_gray_concrete
setblock 449 279 302 minecraft:black_stained_glass
fill 449 279 305 452 279 305 minecraft:black_stained_glass
setblock 449 279 306 minecraft:magenta_stained_glass
fill 449 279 310 452 279 310 minecraft:black_stained_glass
setblock 449 279 311 minecraft:magenta_stained_glass
fill 449 279 315 452 279 315 minecraft:black_stained_glass
setblock 449 279 316 minecraft:magenta_stained_glass
fill 450 279 276 453 279 276 minecraft:black_stained_glass
setblock 450 279 277 minecraft:magenta_stained_glass
fill 450 279 281 453 279 281 minecraft:black_stained_glass
setblock 450 279 282 minecraft:magenta_stained_glass
fill 450 279 286 453 279 286 minecraft:black_stained_glass
setblock 450 279 287 minecraft:magenta_stained_glass
fill 450 279 290 452 279 290 minecraft:black_stained_glass
setblock 450 279 291 minecraft:white_concrete
setblock 450 279 293 minecraft:white_concrete
setblock 450 279 299 minecraft:white_concrete
setblock 450 279 300 minecraft:light_gray_concrete
fill 450 279 301 453 279 301 minecraft:black_stained_glass
setblock 450 279 302 minecraft:magenta_stained_glass
fill 450 279 306 453 279 306 minecraft:black_stained_glass
setblock 450 279 307 minecraft:magenta_stained_glass
fill 450 279 311 453 279 311 minecraft:black_stained_glass
setblock 450 279 312 minecraft:magenta_stained_glass
fill 450 279 316 453 279 316 minecraft:black_stained_glass
fill 451 279 277 454 279 277 minecraft:black_stained_glass
setblock 451 279 278 minecraft:magenta_stained_glass
fill 451 279 282 454 279 282 minecraft:black_stained_glass
setblock 451 279 283 minecraft:magenta_stained_glass
fill 451 279 287 454 279 287 minecraft:black_stained_glass
setblock 451 279 288 minecraft:magenta_stained_glass
fill 451 279 291 453 279 292 minecraft:black_stained_glass
setblock 451 279 293 minecraft:magenta_stained_glass
setblock 451 279 294 minecraft:white_concrete
setblock 451 279 295 minecraft:light_gray_concrete
setblock 451 279 296 minecraft:white_concrete
setblock 451 279 297 minecraft:light_gray_concrete
setblock 451 279 298 minecraft:magenta_stained_glass
fill 451 279 299 451 279 300 minecraft:black_stained_glass
fill 451 279 302 454 279 302 minecraft:black_stained_glass
setblock 451 279 303 minecraft:magenta_stained_glass
fill 451 279 307 454 279 307 minecraft:black_stained_glass
setblock 451 279 308 minecraft:magenta_stained_glass
fill 451 279 312 454 279 312 minecraft:black_stained_glass
setblock 451 279 313 minecraft:magenta_stained_glass
fill 452 279 278 455 279 278 minecraft:black_stained_glass
setblock 452 279 279 minecraft:magenta_stained_glass
fill 452 279 283 455 279 283 minecraft:black_stained_glass
setblock 452 279 284 minecraft:magenta_stained_glass
fill 452 279 288 455 279 288 minecraft:black_stained_glass
setblock 452 279 289 minecraft:magenta_stained_glass
fill 452 279 293 455 279 293 minecraft:black_stained_glass
setblock 452 279 294 minecraft:magenta_stained_glass
fill 452 279 295 452 279 298 minecraft:black_stained_glass
setblock 452 279 299 minecraft:magenta_stained_glass
setblock 452 279 300 minecraft:black_stained_glass
fill 452 279 303 455 279 303 minecraft:black_stained_glass
setblock 452 279 304 minecraft:magenta_stained_glass
fill 452 279 308 455 279 308 minecraft:black_stained_glass
setblock 452 279 309 minecraft:magenta_stained_glass
fill 452 279 313 455 279 313 minecraft:black_stained_glass
setblock 452 279 314 minecraft:magenta_stained_glass
fill 453 279 279 456 279 279 minecraft:black_stained_glass
setblock 453 279 280 minecraft:magenta_stained_glass
fill 453 279 284 456 279 284 minecraft:black_stained_glass
setblock 453 279 285 minecraft:magenta_stained_glass
fill 453 279 289 456 279 289 minecraft:black_stained_glass
setblock 453 279 290 minecraft:magenta_stained_glass
fill 453 279 294 456 279 294 minecraft:black_stained_glass
setblock 453 279 295 minecraft:magenta_stained_glass
fill 453 279 296 453 279 299 minecraft:black_stained_glass
setblock 453 279 300 minecraft:magenta_stained_glass
fill 453 279 304 456 279 304 minecraft:black_stained_glass
setblock 453 279 305 minecraft:magenta_stained_glass
fill 453 279 309 456 279 309 minecraft:black_stained_glass
setblock 453 279 310 minecraft:magenta_stained_glass
fill 453 279 314 456 279 314 minecraft:black_stained_glass
setblock 453 279 315 minecraft:magenta_stained_glass
setblock 454 279 276 minecraft:magenta_stained_glass
fill 454 279 280 457 279 280 minecraft:black_stained_glass
setblock 454 279 281 minecraft:magenta_stained_glass
fill 454 279 285 457 279 285 minecraft:black_stained_glass
setblock 454 279 286 minecraft:magenta_stained_glass
fill 454 279 290 457 279 290 minecraft:black_stained_glass
setblock 454 279 291 minecraft:magenta_stained_glass
setblock 454 279 292 minecraft:black_stained_glass
fill 454 279 295 457 279 295 minecraft:black_stained_glass
setblock 454 279 296 minecraft:magenta_stained_glass
fill 454 279 297 454 279 300 minecraft:black_stained_glass
setblock 454 279 301 minecraft:magenta_stained_glass
fill 454 279 305 457 279 305 minecraft:black_stained_glass
setblock 454 279 306 minecraft:magenta_stained_glass
fill 454 279 310 457 279 310 minecraft:black_stained_glass
setblock 454 279 311 minecraft:magenta_stained_glass
fill 454 279 315 457 279 315 minecraft:black_stained_glass
setblock 454 279 316 minecraft:magenta_stained_glass
fill 455 279 276 458 279 276 minecraft:black_stained_glass
setblock 455 279 277 minecraft:magenta_stained_glass
fill 455 279 281 458 279 281 minecraft:black_stained_glass
setblock 455 279 282 minecraft:magenta_stained_glass
fill 455 279 286 458 279 286 minecraft:black_stained_glass
setblock 455 279 287 minecraft:magenta_stained_glass
fill 455 279 291 458 279 291 minecraft:black_stained_glass
setblock 455 279 292 minecraft:magenta_stained_glass
fill 455 279 296 458 279 296 minecraft:black_stained_glass
setblock 455 279 297 minecraft:magenta_stained_glass
fill 455 279 298 455 279 301 minecraft:black_stained_glass
setblock 455 279 302 minecraft:magenta_stained_glass
fill 455 279 306 458 279 306 minecraft:black_stained_glass
setblock 455 279 307 minecraft:magenta_stained_glass
fill 455 279 311 458 279 311 minecraft:black_stained_glass
setblock 455 279 312 minecraft:magenta_stained_glass
fill 455 279 316 458 279 316 minecraft:black_stained_glass
fill 456 279 277 459 279 277 minecraft:black_stained_glass
setblock 456 279 278 minecraft:magenta_stained_glass
fill 456 279 282 459 279 282 minecraft:black_stained_glass
setblock 456 279 283 minecraft:magenta_stained_glass
fill 456 279 287 459 279 287 minecraft:black_stained_glass
setblock 456 279 288 minecraft:magenta_stained_glass
fill 456 279 292 459 279 292 minecraft:black_stained_glass
setblock 456 279 293 minecraft:magenta_stained_glass
fill 456 279 297 459 279 297 minecraft:black_stained_glass
setblock 456 279 298 minecraft:magenta_stained_glass
fill 456 279 299 456 279 302 minecraft:black_stained_glass
setblock 456 279 303 minecraft:magenta_stained_glass
fill 456 279 307 459 279 307 minecraft:black_stained_glass
setblock 456 279 308 minecraft:magenta_stained_glass
fill 456 279 312 459 279 312 minecraft:black_stained_glass
setblock 456 279 313 minecraft:magenta_stained_glass
fill 457 279 278 460 279 278 minecraft:black_stained_glass
setblock 457 279 279 minecraft:magenta_stained_glass
fill 457 279 283 460 279 283 minecraft:black_stained_glass
setblock 457 279 284 minecraft:magenta_stained_glass
fill 457 279 288 460 279 288 minecraft:black_stained_glass
setblock 457 279 289 minecraft:magenta_stained_glass
fill 457 279 293 460 279 293 minecraft:black_stained_glass
setblock 457 279 294 minecraft:magenta_stained_glass
fill 457 279 298 460 279 298 minecraft:black_stained_glass
setblock 457 279 299 minecraft:magenta_stained_glass
fill 457 279 300 457 279 303 minecraft:black_stained_glass
setblock 457 279 304 minecraft:magenta_stained_glass
fill 457 279 308 460 279 308 minecraft:black_stained_glass
setblock 457 279 309 minecraft:magenta_stained_glass
fill 457 279 313 460 279 313 minecraft:black_stained_glass
setblock 457 279 314 minecraft:magenta_stained_glass
fill 458 279 279 461 279 279 minecraft:black_stained_glass
setblock 458 279 280 minecraft:magenta_stained_glass
fill 458 279 284 461 279 284 minecraft:black_stained_glass
setblock 458 279 285 minecraft:magenta_stained_glass
fill 458 279 289 461 279 289 minecraft:black_stained_glass
setblock 458 279 290 minecraft:magenta_stained_glass
fill 458 279 294 461 279 294 minecraft:black_stained_glass
setblock 458 279 295 minecraft:magenta_stained_glass
fill 458 279 299 461 279 299 minecraft:black_stained_glass
setblock 458 279 300 minecraft:magenta_stained_glass
fill 458 279 301 458 279 304 minecraft:black_stained_glass
setblock 458 279 305 minecraft:magenta_stained_glass
fill 458 279 309 461 279 309 minecraft:black_stained_glass
setblock 458 279 310 minecraft:magenta_stained_glass
fill 458 279 314 461 279 314 minecraft:black_stained_glass
setblock 458 279 315 minecraft:magenta_stained_glass
setblock 459 279 276 minecraft:magenta_stained_glass
fill 459 279 280 462 279 280 minecraft:black_stained_glass
setblock 459 279 281 minecraft:magenta_stained_glass
fill 459 279 285 462 279 285 minecraft:black_stained_glass
setblock 459 279 286 minecraft:magenta_stained_glass
fill 459 279 290 462 279 290 minecraft:black_stained_glass
setblock 459 279 291 minecraft:magenta_stained_glass
fill 459 279 295 462 279 295 minecraft:black_stained_glass
setblock 459 279 296 minecraft:magenta_stained_glass
fill 459 279 300 462 279 300 minecraft:black_stained_glass
setblock 459 279 301 minecraft:magenta_stained_glass
fill 459 279 302 459 279 305 minecraft:black_stained_glass
setblock 459 279 306 minecraft:magenta_stained_glass
fill 459 279 310 462 279 310 minecraft:black_stained_glass
setblock 459 279 311 minecraft:magenta_stained_glass
fill 459 279 315 462 279 315 minecraft:black_stained_glass
setblock 459 279 316 minecraft:magenta_stained_glass
fill 460 279 276 463 279 276 minecraft:black_stained_glass
setblock 460 279 277 minecraft:magenta_stained_glass
fill 460 279 281 463 279 281 minecraft:black_stained_glass
setblock 460 279 282 minecraft:magenta_stained_glass
fill 460 279 286 463 279 286 minecraft:black_stained_glass
setblock 460 279 287 minecraft:magenta_stained_glass
fill 460 279 291 463 279 291 minecraft:black_stained_glass
setblock 460 279 292 minecraft:magenta_stained_glass
fill 460 279 296 463 279 296 minecraft:black_stained_glass
setblock 460 279 297 minecraft:magenta_stained_glass
fill 460 279 301 463 279 301 minecraft:black_stained_glass
setblock 460 279 302 minecraft:magenta_stained_glass
fill 460 279 303 460 279 306 minecraft:black_stained_glass
setblock 460 279 307 minecraft:magenta_stained_glass
fill 460 279 311 463 279 311 minecraft:black_stained_glass
setblock 460 279 312 minecraft:magenta_stained_glass
fill 460 279 316 463 279 316 minecraft:black_stained_glass
fill 461 279 277 464 279 277 minecraft:black_stained_glass
setblock 461 279 278 minecraft:magenta_stained_glass
fill 461 279 282 464 279 282 minecraft:black_stained_glass
setblock 461 279 283 minecraft:magenta_stained_glass
fill 461 279 287 464 279 287 minecraft:black_stained_glass
setblock 461 279 288 minecraft:magenta_stained_glass
fill 461 279 292 464 279 292 minecraft:black_stained_glass
setblock 461 279 293 minecraft:magenta_stained_glass
fill 461 279 297 464 279 297 minecraft:black_stained_glass
setblock 461 279 298 minecraft:magenta_stained_glass
fill 461 279 302 464 279 302 minecraft:black_stained_glass
setblock 461 279 303 minecraft:magenta_stained_glass
fill 461 279 304 461 279 307 minecraft:black_stained_glass
setblock 461 279 308 minecraft:magenta_stained_glass
fill 461 279 312 464 279 312 minecraft:black_stained_glass
setblock 461 279 313 minecraft:magenta_stained_glass
fill 462 279 278 464 279 278 minecraft:black_stained_glass
setblock 462 279 279 minecraft:magenta_stained_glass
fill 462 279 283 464 279 283 minecraft:black_stained_glass
setblock 462 279 284 minecraft:magenta_stained_glass
fill 462 279 288 464 279 288 minecraft:black_stained_glass
setblock 462 279 289 minecraft:magenta_stained_glass
fill 462 279 293 464 279 293 minecraft:black_stained_glass
setblock 462 279 294 minecraft:magenta_stained_glass
fill 462 279 298 464 279 298 minecraft:black_stained_glass
setblock 462 279 299 minecraft:magenta_stained_glass
fill 462 279 303 464 279 303 minecraft:black_stained_glass
setblock 462 279 304 minecraft:magenta_stained_glass
fill 462 279 305 462 279 308 minecraft:black_stained_glass
setblock 462 279 309 minecraft:magenta_stained_glass
fill 462 279 313 464 279 313 minecraft:black_stained_glass
setblock 462 279 314 minecraft:magenta_stained_glass
fill 463 279 279 464 279 279 minecraft:black_stained_glass
setblock 463 279 280 minecraft:magenta_stained_glass
fill 463 279 284 464 279 284 minecraft:black_stained_glass
setblock 463 279 285 minecraft:magenta_stained_glass
fill 463 279 289 464 279 289 minecraft:black_stained_glass
setblock 463 279 290 minecraft:magenta_stained_glass
fill 463 279 294 464 279 294 minecraft:black_stained_glass
setblock 463 279 295 minecraft:magenta_stained_glass
fill 463 279 299 464 279 299 minecraft:black_stained_glass
setblock 463 279 300 minecraft:magenta_stained_glass
fill 463 279 304 464 279 304 minecraft:black_stained_glass
setblock 463 279 305 minecraft:magenta_stained_glass
fill 463 279 306 463 279 309 minecraft:black_stained_glass
setblock 463 279 310 minecraft:magenta_stained_glass
fill 463 279 314 464 279 314 minecraft:black_stained_glass
setblock 463 279 315 minecraft:magenta_stained_glass
setblock 464 279 276 minecraft:magenta_stained_glass
setblock 464 279 280 minecraft:black_stained_glass
setblock 464 279 281 minecraft:magenta_stained_glass
setblock 464 279 285 minecraft:black_stained_glass
setblock 464 279 286 minecraft:magenta_stained_glass
setblock 464 279 290 minecraft:black_stained_glass
setblock 464 279 291 minecraft:magenta_stained_glass
setblock 464 279 295 minecraft:black_stained_glass
setblock 464 279 296 minecraft:magenta_stained_glass
setblock 464 279 300 minecraft:black_stained_glass
setblock 464 279 301 minecraft:magenta_stained_glass
setblock 464 279 305 minecraft:black_stained_glass
setblock 464 279 306 minecraft:magenta_stained_glass
fill 464 279 307 464 279 310 minecraft:black_stained_glass
setblock 464 279 311 minecraft:magenta_stained_glass
setblock 464 279 315 minecraft:black_stained_glass
setblock 464 279 316 minecraft:magenta_stained_glass
setblock 426 280 278 minecraft:light[level=12]
setblock 426 280 285 minecraft:light[level=12]
setblock 426 280 292 minecraft:light[level=12]
setblock 426 280 299 minecraft:light[level=12]
setblock 426 280 306 minecraft:light[level=12]
setblock 426 280 313 minecraft:light[level=12]
setblock 433 280 278 minecraft:light[level=12]
setblock 433 280 285 minecraft:light[level=12]
setblock 433 280 292 minecraft:light[level=12]
setblock 433 280 299 minecraft:light[level=12]
setblock 433 280 306 minecraft:light[level=12]
setblock 433 280 313 minecraft:light[level=12]
setblock 436 280 293 minecraft:light_gray_concrete
setblock 436 280 294 minecraft:white_concrete
setblock 436 280 296 minecraft:white_concrete
setblock 436 280 298 minecraft:white_concrete
setblock 437 280 291 minecraft:white_concrete
setblock 437 280 299 minecraft:white_concrete
setblock 438 280 290 minecraft:white_concrete
fill 438 280 294 438 281 296 minecraft:light_gray_concrete
setblock 439 280 289 minecraft:white_concrete
fill 439 280 292 439 281 294 minecraft:light_gray_concrete
fill 439 280 296 439 281 298 minecraft:light_gray_concrete
setblock 439 280 302 minecraft:light_gray_concrete
setblock 440 280 278 minecraft:light[level=12]
setblock 440 280 285 minecraft:light[level=12]
fill 440 280 292 441 281 292 minecraft:light_gray_concrete
fill 440 280 298 441 282 298 minecraft:light_gray_concrete
setblock 440 280 302 minecraft:white_concrete
setblock 440 280 306 minecraft:light[level=12]
setblock 440 280 313 minecraft:light[level=12]
setblock 441 280 289 minecraft:white_concrete
fill 441 280 291 443 281 291 minecraft:light_gray_concrete
fill 441 280 299 443 282 299 minecraft:light_gray_concrete
setblock 442 280 288 minecraft:white_concrete
setblock 442 280 303 minecraft:sea_lantern
setblock 443 280 288 minecraft:light_gray_concrete
fill 443 280 292 445 282 292 minecraft:light_gray_concrete
fill 443 280 298 445 282 298 minecraft:light_gray_concrete
setblock 443 280 303 minecraft:white_concrete
setblock 444 280 288 minecraft:white_concrete
setblock 444 280 303 minecraft:light_gray_concrete
setblock 445 280 289 minecraft:white_concrete
fill 445 280 293 445 282 294 minecraft:light_gray_concrete
fill 445 280 296 445 282 297 minecraft:light_gray_concrete
setblock 445 280 302 minecraft:light_gray_concrete
fill 446 280 294 446 282 296 minecraft:light_gray_concrete
setblock 446 280 302 minecraft:sea_lantern
setblock 447 280 278 minecraft:light[level=12]
setblock 447 280 285 minecraft:light[level=12]
setblock 447 280 289 minecraft:white_concrete
setblock 447 280 302 minecraft:light_gray_concrete
setblock 447 280 306 minecraft:light[level=12]
setblock 447 280 313 minecraft:light[level=12]
setblock 448 280 290 minecraft:white_concrete
setblock 449 280 291 minecraft:white_concrete
fill 449 280 297 449 280 298 minecraft:light_gray_concrete
setblock 449 280 299 minecraft:white_concrete
setblock 450 280 293 minecraft:light_gray_concrete
setblock 450 280 294 minecraft:white_concrete
setblock 450 280 296 minecraft:white_concrete
setblock 450 280 298 minecraft:white_concrete
setblock 454 280 278 minecraft:light[level=12]
setblock 454 280 285 minecraft:light[level=12]
setblock 454 280 292 minecraft:light[level=12]
setblock 454 280 299 minecraft:light[level=12]
setblock 454 280 306 minecraft:light[level=12]
setblock 454 280 313 minecraft:light[level=12]
setblock 461 280 278 minecraft:light[level=12]
setblock 461 280 285 minecraft:light[level=12]
setblock 461 280 292 minecraft:light[level=12]
setblock 461 280 299 minecraft:light[level=12]
setblock 461 280 306 minecraft:light[level=12]
setblock 461 280 313 minecraft:light[level=12]
setblock 437 281 294 minecraft:white_concrete
setblock 437 281 296 minecraft:white_concrete
setblock 437 281 298 minecraft:white_concrete
setblock 438 281 291 minecraft:white_concrete
setblock 438 281 299 minecraft:sea_lantern
setblock 439 281 290 minecraft:white_concrete
setblock 439 281 300 minecraft:white_concrete
setblock 440 281 301 minecraft:white_concrete
setblock 441 281 289 minecraft:light_gray_concrete
setblock 441 281 290 minecraft:sea_lantern
setblock 441 281 301 minecraft:sea_lantern
setblock 441 281 302 minecraft:white_concrete
setblock 442 281 289 minecraft:white_concrete
setblock 443 281 302 minecraft:white_concrete
setblock 444 281 289 minecraft:white_concrete
setblock 445 281 289 minecraft:sea_lantern
setblock 445 281 290 minecraft:white_concrete
setblock 445 281 302 minecraft:white_concrete
setblock 446 281 301 minecraft:white_concrete
setblock 447 281 290 minecraft:white_concrete
setblock 447 281 300 minecraft:white_concrete
setblock 448 281 291 minecraft:sea_lantern
setblock 448 281 299 minecraft:white_concrete
setblock 449 281 294 minecraft:white_concrete
setblock 449 281 296 minecraft:white_concrete
setblock 449 281 297 minecraft:light_gray_concrete
setblock 449 281 298 minecraft:white_concrete
setblock 438 282 294 minecraft:sea_lantern
fill 438 282 295 440 282 295 minecraft:light_gray_concrete
setblock 438 282 296 minecraft:white_concrete
setblock 438 282 298 minecraft:white_concrete
setblock 439 282 292 minecraft:light_gray_concrete
setblock 439 282 293 minecraft:white_concrete
fill 439 282 294 441 282 294 minecraft:light_gray_concrete
fill 439 282 296 441 282 296 minecraft:light_gray_concrete
setblock 439 282 297 minecraft:white_concrete
setblock 439 282 298 minecraft:light_gray_concrete
setblock 439 282 299 minecraft:white_concrete
setblock 440 282 292 minecraft:white_concrete
fill 440 282 293 444 282 293 minecraft:light_gray_concrete
fill 440 282 297 444 282 297 minecraft:light_gray_concrete
setblock 440 282 299 minecraft:sea_lantern
setblock 440 282 300 minecraft:white_concrete
setblock 441 282 291 minecraft:white_concrete
fill 441 282 292 442 282 292 minecraft:light_gray_concrete
setblock 442 282 290 minecraft:white_concrete
setblock 442 282 291 minecraft:light_gray_concrete
fill 442 282 298 442 283 298 minecraft:light_gray_concrete
setblock 442 282 300 minecraft:white_concrete
setblock 443 282 290 minecraft:sea_lantern
setblock 443 282 291 minecraft:white_concrete
fill 443 282 294 444 282 294 minecraft:light_gray_concrete
fill 443 282 296 444 282 296 minecraft:light_gray_concrete
setblock 443 282 301 minecraft:sea_lantern
setblock 444 282 290 minecraft:white_concrete
fill 444 282 295 445 282 295 minecraft:light_gray_concrete
setblock 444 282 300 minecraft:white_concrete
setblock 445 282 291 minecraft:white_concrete
setblock 446 282 292 minecraft:sea_lantern
setblock 446 282 300 minecraft:white_concrete
setblock 447 282 293 minecraft:white_concrete
setblock 447 282 297 minecraft:white_concrete
setblock 447 282 299 minecraft:white_concrete
setblock 448 282 294 minecraft:white_concrete
setblock 448 282 296 minecraft:white_concrete
setblock 448 282 297 minecraft:sea_lantern
setblock 448 282 298 minecraft:white_concrete
fill 423 283 281 423 283 284 minecraft:sea_lantern
fill 423 283 291 423 283 294 minecraft:sea_lantern
fill 423 283 301 423 283 304 minecraft:sea_lantern
fill 423 283 311 423 283 314 minecraft:sea_lantern
fill 424 283 277 424 300 277 minecraft:iron_block
fill 424 283 287 424 300 287 minecraft:iron_block
fill 424 283 297 424 300 297 minecraft:iron_block
fill 424 283 307 424 300 307 minecraft:iron_block
fill 425 283 316 425 300 316 minecraft:iron_block
fill 426 283 275 429 283 275 minecraft:sea_lantern
fill 427 283 317 430 283 317 minecraft:sea_lantern
fill 431 283 276 431 300 276 minecraft:iron_block
fill 435 283 316 435 300 316 minecraft:iron_block
fill 436 283 275 439 283 275 minecraft:sea_lantern
fill 437 283 317 440 283 317 minecraft:sea_lantern
setblock 439 283 295 minecraft:light_gray_concrete
setblock 439 283 296 minecraft:white_concrete
setblock 440 283 293 minecraft:white_concrete
setblock 440 283 294 minecraft:sea_lantern
setblock 440 283 295 minecraft:white_concrete
setblock 440 283 296 minecraft:light_gray_concrete
setblock 440 283 297 minecraft:white_concrete
setblock 440 283 298 minecraft:light_gray_concrete
fill 441 283 276 441 300 276 minecraft:iron_block
setblock 441 283 292 minecraft:white_concrete
setblock 441 283 293 minecraft:light_gray_concrete
setblock 441 283 294 minecraft:white_concrete
setblock 441 283 296 minecraft:white_concrete
setblock 441 283 297 minecraft:light_gray_concrete
setblock 441 283 298 minecraft:white_concrete
setblock 441 283 299 minecraft:light_gray_concrete
setblock 442 283 292 minecraft:light_gray_concrete
setblock 442 283 293 minecraft:white_concrete
setblock 442 283 297 minecraft:white_concrete
setblock 442 283 299 minecraft:sea_lantern
setblock 443 283 292 minecraft:white_concrete
setblock 443 283 293 minecraft:light_gray_concrete
setblock 443 283 294 minecraft:white_concrete
setblock 443 283 296 minecraft:sea_lantern
setblock 443 283 297 minecraft:light_gray_concrete
setblock 443 283 298 minecraft:white_concrete
setblock 443 283 299 minecraft:light_gray_concrete
setblock 444 283 292 minecraft:light_gray_concrete
setblock 444 283 293 minecraft:sea_lantern
setblock 444 283 294 minecraft:light_gray_concrete
setblock 444 283 295 minecraft:white_concrete
setblock 444 283 296 minecraft:light_gray_concrete
setblock 444 283 297 minecraft:white_concrete
setblock 444 283 298 minecraft:light_gray_concrete
setblock 444 283 299 minecraft:white_concrete
setblock 445 283 292 minecraft:white_concrete
setblock 445 283 293 minecraft:light_gray_concrete
setblock 445 283 294 minecraft:white_concrete
setblock 445 283 295 minecraft:light_gray_concrete
setblock 445 283 296 minecraft:white_concrete
setblock 445 283 297 minecraft:light_gray_concrete
setblock 445 283 298 minecraft:white_concrete
fill 445 283 316 445 300 316 minecraft:iron_block
fill 446 283 275 449 283 275 minecraft:sea_lantern
setblock 446 283 293 minecraft:white_concrete
setblock 446 283 294 minecraft:light_gray_concrete
setblock 446 283 295 minecraft:white_concrete
setblock 446 283 296 minecraft:light_gray_concrete
setblock 446 283 297 minecraft:white_concrete
setblock 446 283 298 minecraft:sea_lantern
setblock 447 283 295 minecraft:sea_lantern
setblock 447 283 296 minecraft:white_concrete
fill 447 283 317 450 283 317 minecraft:sea_lantern
fill 451 283 276 451 300 276 minecraft:iron_block
fill 455 283 316 455 300 316 minecraft:iron_block
fill 456 283 275 459 283 275 minecraft:sea_lantern
fill 457 283 317 460 283 317 minecraft:sea_lantern
fill 461 283 276 461 300 276 minecraft:iron_block
fill 461 283 312 463 283 312 minecraft:iron_block
fill 464 283 283 464 300 283 minecraft:iron_block
fill 464 283 293 464 300 293 minecraft:iron_block
fill 464 283 303 464 300 303 minecraft:iron_block
fill 464 283 313 464 300 313 minecraft:iron_block
fill 465 283 276 465 283 279 minecraft:sea_lantern
fill 465 283 286 465 283 289 minecraft:sea_lantern
fill 465 283 296 465 283 299 minecraft:sea_lantern
fill 465 283 306 465 283 309 minecraft:sea_lantern
setblock 465 283 316 minecraft:sea_lantern
fill 423 284 281 423 291 284 minecraft:black_concrete
fill 423 284 291 423 291 294 minecraft:black_concrete
fill 423 284 301 423 291 304 minecraft:black_concrete
fill 423 284 311 423 291 314 minecraft:black_concrete
fill 426 284 275 429 291 275 minecraft:black_concrete
fill 426 284 276 426 285 278 minecraft:iron_block
setblock 426 284 286 minecraft:light[level=15]
setblock 426 284 294 minecraft:light[level=15]
setblock 426 284 302 minecraft:light[level=15]
setblock 426 284 310 minecraft:light[level=15]
fill 427 284 317 430 291 317 minecraft:black_concrete
setblock 434 284 278 minecraft:light[level=15]
setblock 434 284 286 minecraft:light[level=15]
setblock 434 284 294 minecraft:light[level=15]
setblock 434 284 302 minecraft:light[level=15]
setblock 434 284 310 minecraft:light[level=15]
fill 436 284 275 439 291 275 minecraft:black_concrete
fill 437 284 317 440 291 317 minecraft:black_concrete
setblock 442 284 278 minecraft:light[level=15]
setblock 442 284 286 minecraft:light[level=15]
setblock 442 284 302 minecraft:light[level=15]
setblock 442 284 310 minecraft:light[level=15]
fill 446 284 275 449 291 275 minecraft:black_concrete
fill 447 284 317 450 291 317 minecraft:black_concrete
setblock 450 284 278 minecraft:light[level=15]
setblock 450 284 286 minecraft:light[level=15]
setblock 450 284 294 minecraft:light[level=15]
setblock 450 284 302 minecraft:light[level=15]
setblock 450 284 310 minecraft:light[level=15]
fill 456 284 275 459 291 275 minecraft:black_concrete
fill 457 284 317 460 291 317 minecraft:black_concrete
setblock 458 284 278 minecraft:light[level=15]
setblock 458 284 286 minecraft:light[level=15]
setblock 458 284 294 minecraft:light[level=15]
setblock 458 284 302 minecraft:light[level=15]
setblock 458 284 310 minecraft:light[level=15]
fill 465 284 276 465 291 279 minecraft:black_concrete
fill 465 284 286 465 291 289 minecraft:black_concrete
fill 465 284 296 465 291 299 minecraft:black_concrete
fill 465 284 306 465 291 309 minecraft:black_concrete
fill 465 284 316 465 291 316 minecraft:black_concrete
fill 439 285 307 440 286 308 minecraft:light_blue_concrete
setblock 426 286 278 minecraft:light[level=12]
setblock 426 286 285 minecraft:light[level=12]
setblock 426 286 292 minecraft:light[level=12]
setblock 426 286 299 minecraft:light[level=12]
setblock 426 286 306 minecraft:light[level=12]
setblock 426 286 313 minecraft:light[level=12]
setblock 433 286 278 minecraft:light[level=12]
setblock 433 286 285 minecraft:light[level=12]
setblock 433 286 292 minecraft:light[level=12]
setblock 433 286 299 minecraft:light[level=12]
setblock 433 286 306 minecraft:light[level=12]
setblock 433 286 313 minecraft:light[level=12]
setblock 440 286 278 minecraft:light[level=12]
setblock 440 286 285 minecraft:light[level=12]
setblock 440 286 292 minecraft:light[level=12]
setblock 440 286 299 minecraft:light[level=12]
setblock 440 286 306 minecraft:light[level=12]
setblock 440 286 313 minecraft:light[level=12]
setblock 447 286 278 minecraft:light[level=12]
setblock 447 286 285 minecraft:light[level=12]
setblock 447 286 292 minecraft:light[level=12]
setblock 447 286 299 minecraft:light[level=12]
setblock 447 286 306 minecraft:light[level=12]
setblock 447 286 313 minecraft:light[level=12]
setblock 454 286 278 minecraft:light[level=12]
setblock 454 286 285 minecraft:light[level=12]
setblock 454 286 292 minecraft:light[level=12]
setblock 454 286 299 minecraft:light[level=12]
setblock 454 286 306 minecraft:light[level=12]
setblock 454 286 313 minecraft:light[level=12]
setblock 461 286 278 minecraft:light[level=12]
setblock 461 286 285 minecraft:light[level=12]
setblock 461 286 292 minecraft:light[level=12]
setblock 461 286 299 minecraft:light[level=12]
setblock 461 286 306 minecraft:light[level=12]
setblock 461 286 313 minecraft:light[level=12]
setblock 424 288 278 minecraft:gray_concrete
fill 424 288 280 424 288 283 minecraft:gray_concrete
setblock 424 288 288 minecraft:gray_concrete
fill 424 288 290 424 288 293 minecraft:gray_concrete
setblock 424 288 298 minecraft:gray_concrete
fill 424 288 300 424 288 303 minecraft:gray_concrete
setblock 424 288 308 minecraft:gray_concrete
fill 424 288 310 424 288 313 minecraft:gray_concrete
fill 425 288 276 428 288 276 minecraft:gray_concrete
setblock 426 288 316 minecraft:gray_concrete
fill 428 288 316 431 288 316 minecraft:gray_concrete
setblock 430 288 276 minecraft:gray_concrete
fill 435 288 276 438 288 276 minecraft:gray_concrete
setblock 436 288 316 minecraft:gray_concrete
fill 438 288 316 441 288 316 minecraft:gray_concrete
setblock 440 288 276 minecraft:gray_concrete
fill 445 288 276 448 288 276 minecraft:gray_concrete
setblock 446 288 316 minecraft:gray_concrete
fill 448 288 316 451 288 316 minecraft:gray_concrete
setblock 450 288 276 minecraft:gray_concrete
fill 455 288 276 458 288 276 minecraft:gray_concrete
setblock 456 288 316 minecraft:gray_concrete
fill 458 288 316 461 288 316 minecraft:gray_concrete
setblock 460 288 276 minecraft:gray_concrete
fill 464 288 277 464 288 280 minecraft:gray_concrete
setblock 464 288 282 minecraft:gray_concrete
fill 464 288 287 464 288 290 minecraft:gray_concrete
setblock 464 288 292 minecraft:gray_concrete
fill 464 288 297 464 288 300 minecraft:gray_concrete
setblock 464 288 302 minecraft:gray_concrete
fill 464 288 307 464 288 310 minecraft:gray_concrete
setblock 464 288 312 minecraft:gray_concrete
fill 425 289 281 425 299 281 minecraft:purple_wool
fill 425 290 279 425 299 280 minecraft:purple_wool
fill 425 290 282 425 299 283 minecraft:purple_wool
fill 423 292 281 423 292 284 minecraft:sea_lantern
fill 423 292 291 423 292 294 minecraft:sea_lantern
fill 423 292 301 423 292 304 minecraft:sea_lantern
fill 423 292 311 423 292 314 minecraft:sea_lantern
fill 426 292 275 429 292 275 minecraft:sea_lantern
setblock 426 292 278 minecraft:light[level=15]
setblock 426 292 285 minecraft:light[level=12]
setblock 426 292 286 minecraft:light[level=15]
setblock 426 292 292 minecraft:light[level=12]
setblock 426 292 294 minecraft:light[level=15]
setblock 426 292 299 minecraft:light[level=12]
setblock 426 292 302 minecraft:light[level=15]
setblock 426 292 306 minecraft:light[level=12]
setblock 426 292 310 minecraft:light[level=15]
setblock 426 292 313 minecraft:light[level=12]
fill 427 292 317 430 292 317 minecraft:sea_lantern
setblock 433 292 278 minecraft:light[level=12]
setblock 433 292 285 minecraft:light[level=12]
setblock 433 292 292 minecraft:light[level=12]
setblock 433 292 299 minecraft:light[level=12]
setblock 433 292 306 minecraft:light[level=12]
setblock 433 292 313 minecraft:light[level=12]
setblock 434 292 278 minecraft:light[level=15]
setblock 434 292 286 minecraft:light[level=15]
setblock 434 292 294 minecraft:light[level=15]
setblock 434 292 302 minecraft:light[level=15]
setblock 434 292 310 minecraft:light[level=15]
fill 436 292 275 439 292 275 minecraft:sea_lantern
fill 437 292 317 440 292 317 minecraft:sea_lantern
setblock 440 292 278 minecraft:light[level=12]
setblock 440 292 285 minecraft:light[level=12]
setblock 440 292 292 minecraft:light[level=12]
setblock 440 292 299 minecraft:light[level=12]
setblock 440 292 306 minecraft:light[level=12]
setblock 440 292 313 minecraft:light[level=12]
setblock 442 292 278 minecraft:light[level=15]
setblock 442 292 286 minecraft:light[level=15]
setblock 442 292 302 minecraft:light[level=15]
setblock 442 292 310 minecraft:light[level=15]
fill 446 292 275 449 292 275 minecraft:sea_lantern
setblock 447 292 278 minecraft:light[level=12]
setblock 447 292 285 minecraft:light[level=12]
setblock 447 292 292 minecraft:light[level=12]
setblock 447 292 299 minecraft:light[level=12]
setblock 447 292 306 minecraft:light[level=12]
setblock 447 292 313 minecraft:light[level=12]
fill 447 292 317 450 292 317 minecraft:sea_lantern
setblock 450 292 278 minecraft:light[level=15]
setblock 450 292 286 minecraft:light[level=15]
setblock 450 292 294 minecraft:light[level=15]
setblock 450 292 302 minecraft:light[level=15]
setblock 450 292 310 minecraft:light[level=15]
setblock 454 292 278 minecraft:light[level=12]
setblock 454 292 285 minecraft:light[level=12]
setblock 454 292 292 minecraft:light[level=12]
setblock 454 292 299 minecraft:light[level=12]
setblock 454 292 306 minecraft:light[level=12]
setblock 454 292 313 minecraft:light[level=12]
fill 456 292 275 459 292 275 minecraft:sea_lantern
fill 457 292 317 460 292 317 minecraft:sea_lantern
setblock 458 292 278 minecraft:light[level=15]
setblock 458 292 286 minecraft:light[level=15]
setblock 458 292 294 minecraft:light[level=15]
setblock 458 292 302 minecraft:light[level=15]
setblock 458 292 310 minecraft:light[level=15]
setblock 461 292 278 minecraft:light[level=12]
setblock 461 292 285 minecraft:light[level=12]
setblock 461 292 292 minecraft:light[level=12]
setblock 461 292 299 minecraft:light[level=12]
setblock 461 292 306 minecraft:light[level=12]
setblock 461 292 313 minecraft:light[level=12]
fill 465 292 276 465 292 279 minecraft:sea_lantern
fill 465 292 286 465 292 289 minecraft:sea_lantern
fill 465 292 296 465 292 299 minecraft:sea_lantern
fill 465 292 306 465 292 309 minecraft:sea_lantern
setblock 465 292 316 minecraft:sea_lantern
fill 423 293 281 423 308 284 minecraft:black_concrete
fill 423 293 291 423 308 294 minecraft:black_concrete
fill 423 293 301 423 308 304 minecraft:black_concrete
fill 423 293 311 423 308 314 minecraft:black_concrete
fill 426 293 275 429 308 275 minecraft:black_concrete
fill 427 293 317 430 308 317 minecraft:black_concrete
fill 436 293 275 439 308 275 minecraft:black_concrete
fill 437 293 317 440 308 317 minecraft:black_concrete
fill 446 293 275 449 308 275 minecraft:black_concrete
fill 447 293 317 450 308 317 minecraft:black_concrete
fill 449 293 283 449 294 284 minecraft:lime_concrete
fill 456 293 275 459 308 275 minecraft:black_concrete
fill 457 293 317 460 308 317 minecraft:black_concrete
fill 465 293 276 465 308 279 minecraft:black_concrete
fill 465 293 286 465 308 289 minecraft:black_concrete
fill 465 293 296 465 308 299 minecraft:black_concrete
fill 465 293 306 465 308 309 minecraft:black_concrete
fill 465 293 316 465 308 316 minecraft:black_concrete
setblock 424 294 278 minecraft:gray_concrete
setblock 424 294 288 minecraft:gray_concrete
setblock 424 294 298 minecraft:gray_concrete
setblock 424 294 308 minecraft:gray_concrete
setblock 426 294 316 minecraft:gray_concrete
setblock 430 294 276 minecraft:gray_concrete
setblock 436 294 316 minecraft:gray_concrete
setblock 440 294 276 minecraft:gray_concrete
setblock 446 294 316 minecraft:gray_concrete
setblock 450 294 276 minecraft:gray_concrete
setblock 456 294 316 minecraft:gray_concrete
setblock 460 294 276 minecraft:gray_concrete
setblock 464 294 282 minecraft:gray_concrete
setblock 464 294 292 minecraft:gray_concrete
setblock 464 294 302 minecraft:gray_concrete
setblock 464 294 312 minecraft:gray_concrete
fill 432 295 309 433 296 309 minecraft:yellow_concrete
fill 424 297 280 424 297 283 minecraft:gray_concrete
fill 424 297 290 424 297 293 minecraft:gray_concrete
fill 424 297 300 424 297 303 minecraft:gray_concrete
fill 424 297 310 424 297 313 minecraft:gray_concrete
fill 425 297 276 428 297 276 minecraft:gray_concrete
fill 428 297 316 431 297 316 minecraft:gray_concrete
fill 435 297 276 438 297 276 minecraft:gray_concrete
fill 438 297 316 441 297 316 minecraft:gray_concrete
fill 445 297 276 448 297 276 minecraft:gray_concrete
fill 448 297 316 451 297 316 minecraft:gray_concrete
fill 455 297 276 458 297 276 minecraft:gray_concrete
fill 458 297 316 461 297 316 minecraft:gray_concrete
fill 464 297 277 464 297 280 minecraft:gray_concrete
fill 464 297 287 464 297 290 minecraft:gray_concrete
fill 464 297 297 464 297 300 minecraft:gray_concrete
fill 464 297 307 464 297 310 minecraft:gray_concrete
setblock 426 298 278 minecraft:light[level=12]
setblock 426 298 285 minecraft:light[level=12]
setblock 426 298 292 minecraft:light[level=12]
setblock 426 298 299 minecraft:light[level=12]
setblock 426 298 306 minecraft:light[level=12]
setblock 426 298 313 minecraft:light[level=12]
setblock 433 298 278 minecraft:light[level=12]
setblock 433 298 285 minecraft:light[level=12]
setblock 433 298 292 minecraft:light[level=12]
setblock 433 298 299 minecraft:light[level=12]
setblock 433 298 306 minecraft:light[level=12]
setblock 433 298 313 minecraft:light[level=12]
setblock 440 298 278 minecraft:light[level=12]
setblock 440 298 285 minecraft:light[level=12]
setblock 440 298 292 minecraft:light[level=12]
setblock 440 298 299 minecraft:light[level=12]
setblock 440 298 306 minecraft:light[level=12]
setblock 440 298 313 minecraft:light[level=12]
setblock 447 298 278 minecraft:light[level=12]
setblock 447 298 285 minecraft:light[level=12]
setblock 447 298 292 minecraft:light[level=12]
setblock 447 298 299 minecraft:light[level=12]
setblock 447 298 306 minecraft:light[level=12]
setblock 447 298 313 minecraft:light[level=12]
setblock 454 298 278 minecraft:light[level=12]
setblock 454 298 285 minecraft:light[level=12]
setblock 454 298 292 minecraft:light[level=12]
setblock 454 298 299 minecraft:light[level=12]
setblock 454 298 306 minecraft:light[level=12]
setblock 454 298 313 minecraft:light[level=12]
setblock 461 298 278 minecraft:light[level=12]
setblock 461 298 285 minecraft:light[level=12]
setblock 461 298 292 minecraft:light[level=12]
setblock 461 298 299 minecraft:light[level=12]
setblock 461 298 306 minecraft:light[level=12]
setblock 461 298 313 minecraft:light[level=12]
setblock 424 300 278 minecraft:gray_concrete
setblock 424 300 288 minecraft:gray_concrete
setblock 424 300 298 minecraft:gray_concrete
setblock 424 300 308 minecraft:gray_concrete
fill 425 300 278 425 300 284 minecraft:iron_block
setblock 426 300 278 minecraft:light[level=15]
setblock 426 300 286 minecraft:light[level=15]
setblock 426 300 294 minecraft:light[level=15]
setblock 426 300 302 minecraft:light[level=15]
setblock 426 300 310 minecraft:light[level=15]
setblock 426 300 316 minecraft:gray_concrete
setblock 430 300 276 minecraft:gray_concrete
setblock 434 300 278 minecraft:light[level=15]
setblock 434 300 286 minecraft:light[level=15]
setblock 434 300 294 minecraft:light[level=15]
setblock 434 300 302 minecraft:light[level=15]
setblock 434 300 310 minecraft:light[level=15]
setblock 436 300 316 minecraft:gray_concrete
setblock 440 300 276 minecraft:gray_concrete
setblock 442 300 278 minecraft:light[level=15]
setblock 442 300 286 minecraft:light[level=15]
setblock 442 300 294 minecraft:light[level=15]
setblock 442 300 302 minecraft:light[level=15]
setblock 442 300 310 minecraft:light[level=15]
setblock 446 300 316 minecraft:gray_concrete
setblock 450 300 276 minecraft:gray_concrete
setblock 450 300 278 minecraft:light[level=15]
setblock 450 300 286 minecraft:light[level=15]
setblock 450 300 294 minecraft:light[level=15]
setblock 450 300 302 minecraft:light[level=15]
setblock 450 300 310 minecraft:light[level=15]
setblock 456 300 316 minecraft:gray_concrete
setblock 458 300 278 minecraft:light[level=15]
setblock 458 300 286 minecraft:light[level=15]
setblock 458 300 294 minecraft:light[level=15]
setblock 458 300 302 minecraft:light[level=15]
setblock 458 300 310 minecraft:light[level=15]
setblock 460 300 276 minecraft:gray_concrete
fill 461 300 282 463 300 284 minecraft:black_concrete
setblock 464 300 282 minecraft:gray_concrete
setblock 464 300 292 minecraft:gray_concrete
setblock 464 300 302 minecraft:gray_concrete
setblock 464 300 312 minecraft:gray_concrete
fill 461 301 282 461 301 284 minecraft:black_concrete
fill 462 301 282 463 301 282 minecraft:black_concrete
fill 462 301 283 462 303 283 minecraft:gray_concrete
fill 462 301 284 463 301 284 minecraft:black_concrete
setblock 463 301 283 minecraft:black_concrete
fill 461 302 282 461 303 282 minecraft:black_concrete
setblock 461 302 283 minecraft:gray_concrete
fill 461 302 284 461 303 284 minecraft:black_concrete
setblock 462 302 282 minecraft:gray_concrete
setblock 462 302 284 minecraft:gray_concrete
fill 463 302 282 463 303 282 minecraft:black_concrete
setblock 463 302 283 minecraft:gray_concrete
fill 463 302 284 463 303 284 minecraft:black_concrete
setblock 461 303 283 minecraft:black_concrete
setblock 462 303 282 minecraft:black_concrete
setblock 462 303 284 minecraft:black_concrete
setblock 463 303 283 minecraft:black_concrete
