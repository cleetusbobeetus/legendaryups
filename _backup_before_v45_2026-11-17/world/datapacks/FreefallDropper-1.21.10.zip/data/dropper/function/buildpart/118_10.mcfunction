fill 495 282 478 509 282 478 minecraft:red_terracotta
fill 495 282 480 497 282 480 minecraft:orange_terracotta
fill 495 282 492 509 282 492 minecraft:red_terracotta
fill 496 282 481 497 282 481 minecraft:orange_terracotta
fill 496 282 490 497 282 490 minecraft:orange_terracotta
fill 497 282 465 499 282 465 minecraft:terracotta
fill 497 282 479 510 282 479 minecraft:red_terracotta
fill 497 282 482 498 282 482 minecraft:orange_terracotta
setblock 497 282 489 minecraft:orange_terracotta
fill 497 282 491 509 282 491 minecraft:red_terracotta
fill 497 282 503 499 282 503 minecraft:terracotta
fill 498 282 480 510 282 481 minecraft:red_terracotta
fill 498 282 483 498 282 488 minecraft:orange_terracotta
fill 498 282 489 509 282 490 minecraft:red_terracotta
fill 499 282 482 510 282 483 minecraft:red_terracotta
fill 499 282 484 499 282 486 minecraft:orange_terracotta
fill 499 282 487 510 282 488 minecraft:red_terracotta
fill 500 282 466 501 282 466 minecraft:terracotta
fill 500 282 484 510 282 486 minecraft:red_terracotta
fill 500 282 502 501 282 502 minecraft:terracotta
setblock 502 282 467 minecraft:terracotta
setblock 502 282 501 minecraft:terracotta
fill 503 282 468 504 282 468 minecraft:terracotta
fill 503 282 500 504 282 500 minecraft:terracotta
setblock 505 282 469 minecraft:terracotta
setblock 505 282 499 minecraft:terracotta
setblock 506 282 470 minecraft:terracotta
setblock 506 282 498 minecraft:terracotta
fill 507 282 471 507 282 472 minecraft:terracotta
fill 507 282 496 507 282 497 minecraft:terracotta
setblock 508 282 473 minecraft:terracotta
setblock 508 282 495 minecraft:terracotta
fill 509 282 474 509 282 475 minecraft:terracotta
fill 509 282 493 509 282 494 minecraft:terracotta
fill 510 282 476 510 282 478 minecraft:terracotta
setblock 510 282 489 minecraft:red_terracotta
fill 510 282 490 510 282 492 minecraft:terracotta
fill 511 282 479 511 282 489 minecraft:terracotta
fill 472 283 479 472 283 489 minecraft:terracotta
fill 473 283 476 473 283 478 minecraft:terracotta
fill 473 283 479 482 283 489 minecraft:red_terracotta
fill 473 283 490 473 283 492 minecraft:terracotta
fill 474 283 474 474 283 475 minecraft:terracotta
fill 474 283 476 485 283 478 minecraft:red_terracotta
fill 474 283 490 483 283 492 minecraft:red_terracotta
fill 474 283 493 474 283 494 minecraft:terracotta
setblock 475 283 473 minecraft:terracotta
fill 475 283 474 507 283 475 minecraft:red_terracotta
fill 475 283 493 487 283 494 minecraft:red_terracotta
setblock 475 283 495 minecraft:terracotta
fill 476 283 471 476 283 472 minecraft:terracotta
fill 476 283 473 506 283 473 minecraft:red_terracotta
fill 476 283 495 506 283 495 minecraft:red_terracotta
fill 476 283 496 476 283 497 minecraft:terracotta
fill 477 283 470 477 283 471 minecraft:terracotta
fill 477 283 472 505 283 472 minecraft:red_terracotta
fill 477 283 496 505 283 496 minecraft:red_terracotta
fill 477 283 497 477 283 498 minecraft:terracotta
fill 478 283 469 478 283 470 minecraft:terracotta
fill 478 283 471 504 283 471 minecraft:red_terracotta
fill 478 283 497 504 283 497 minecraft:red_terracotta
fill 478 283 498 478 283 499 minecraft:terracotta
setblock 479 283 469 minecraft:terracotta
fill 479 283 470 503 283 470 minecraft:red_terracotta
fill 479 283 498 503 283 498 minecraft:red_terracotta
setblock 479 283 499 minecraft:terracotta
setblock 480 283 468 minecraft:terracotta
fill 480 283 469 502 283 469 minecraft:red_terracotta
fill 480 283 499 502 283 499 minecraft:red_terracotta
setblock 480 283 500 minecraft:terracotta
fill 481 283 467 482 283 467 minecraft:terracotta
fill 481 283 468 501 283 468 minecraft:red_terracotta
fill 481 283 500 501 283 500 minecraft:red_terracotta
fill 481 283 501 482 283 501 minecraft:terracotta
fill 483 283 466 485 283 466 minecraft:terracotta
fill 483 283 467 499 283 467 minecraft:red_terracotta
fill 483 283 479 483 283 481 minecraft:red_terracotta
fill 483 283 482 483 283 488 minecraft:orange_terracotta
setblock 483 283 489 minecraft:red_terracotta
fill 483 283 501 499 283 501 minecraft:red_terracotta
fill 483 283 502 485 283 502 minecraft:terracotta
setblock 484 283 479 minecraft:red_terracotta
fill 484 283 480 484 283 483 minecraft:orange_terracotta
fill 484 283 487 484 283 490 minecraft:orange_terracotta
fill 484 283 491 484 283 492 minecraft:red_terracotta
fill 485 283 479 485 283 481 minecraft:orange_terracotta
fill 485 283 489 485 283 491 minecraft:orange_terracotta
setblock 485 283 492 minecraft:red_terracotta
fill 486 283 465 496 283 465 minecraft:terracotta
fill 486 283 466 496 283 466 minecraft:red_terracotta
fill 486 283 476 486 283 477 minecraft:red_terracotta
fill 486 283 478 486 283 479 minecraft:orange_terracotta
fill 486 283 491 486 283 492 minecraft:orange_terracotta
fill 486 283 502 496 283 502 minecraft:red_terracotta
fill 486 283 503 496 283 503 minecraft:terracotta
fill 487 283 476 488 283 476 minecraft:red_terracotta
fill 487 283 477 488 283 478 minecraft:orange_terracotta
fill 487 283 492 488 283 492 minecraft:orange_terracotta
fill 488 283 493 495 283 493 minecraft:orange_terracotta
fill 488 283 494 507 283 494 minecraft:red_terracotta
fill 489 283 476 494 283 477 minecraft:orange_terracotta
fill 495 283 476 508 283 476 minecraft:red_terracotta
fill 495 283 477 496 283 478 minecraft:orange_terracotta
fill 495 283 492 496 283 492 minecraft:orange_terracotta
fill 496 283 493 507 283 493 minecraft:red_terracotta
fill 497 283 466 499 283 466 minecraft:terracotta
fill 497 283 477 508 283 477 minecraft:red_terracotta
fill 497 283 478 497 283 479 minecraft:orange_terracotta
setblock 497 283 491 minecraft:orange_terracotta
fill 497 283 492 508 283 492 minecraft:red_terracotta
fill 497 283 502 499 283 502 minecraft:terracotta
fill 498 283 478 508 283 478 minecraft:red_terracotta
fill 498 283 479 498 283 481 minecraft:orange_terracotta
fill 498 283 489 498 283 490 minecraft:orange_terracotta
fill 498 283 491 508 283 491 minecraft:red_terracotta
fill 499 283 479 509 283 479 minecraft:red_terracotta
fill 499 283 480 499 283 483 minecraft:orange_terracotta
fill 499 283 487 499 283 489 minecraft:orange_terracotta
fill 499 283 490 508 283 490 minecraft:red_terracotta
fill 500 283 467 501 283 467 minecraft:terracotta
fill 500 283 480 509 283 481 minecraft:red_terracotta
fill 500 283 482 500 283 487 minecraft:orange_terracotta
fill 500 283 488 509 283 489 minecraft:red_terracotta
fill 500 283 501 501 283 501 minecraft:terracotta
fill 501 283 482 509 283 487 minecraft:red_terracotta
setblock 502 283 468 minecraft:terracotta
setblock 502 283 500 minecraft:terracotta
fill 503 283 469 504 283 469 minecraft:terracotta
fill 503 283 499 504 283 499 minecraft:terracotta
fill 504 283 470 505 283 470 minecraft:terracotta
fill 504 283 498 505 283 498 minecraft:terracotta
fill 505 283 471 506 283 471 minecraft:terracotta
fill 505 283 497 506 283 497 minecraft:terracotta
setblock 506 283 472 minecraft:terracotta
setblock 506 283 496 minecraft:terracotta
setblock 507 283 473 minecraft:terracotta
setblock 507 283 495 minecraft:terracotta
fill 508 283 474 508 283 475 minecraft:terracotta
fill 508 283 493 508 283 494 minecraft:terracotta
fill 509 283 476 509 283 478 minecraft:terracotta
fill 509 283 490 509 283 492 minecraft:terracotta
fill 510 283 479 510 283 489 minecraft:terracotta
fill 471 284 464 471 284 466 minecraft:red_terracotta
setblock 471 284 467 minecraft:terracotta
fill 471 284 468 471 284 471 minecraft:red_terracotta
setblock 471 284 472 minecraft:terracotta
fill 471 284 473 471 284 476 minecraft:red_terracotta
setblock 471 284 477 minecraft:terracotta
fill 471 284 478 471 284 481 minecraft:red_terracotta
setblock 471 284 482 minecraft:terracotta
fill 471 284 483 471 284 486 minecraft:red_terracotta
setblock 471 284 487 minecraft:terracotta
fill 471 284 488 471 284 491 minecraft:red_terracotta
setblock 471 284 492 minecraft:terracotta
fill 471 284 493 471 284 496 minecraft:red_terracotta
setblock 471 284 497 minecraft:terracotta
fill 471 284 498 471 284 501 minecraft:red_terracotta
setblock 471 284 502 minecraft:terracotta
fill 471 284 503 471 286 504 minecraft:red_terracotta
fill 472 284 464 473 284 464 minecraft:red_terracotta
fill 472 284 467 472 284 470 minecraft:red_terracotta
setblock 472 284 471 minecraft:terracotta
fill 472 284 472 472 284 475 minecraft:red_terracotta
setblock 472 284 476 minecraft:terracotta
fill 472 284 477 472 284 480 minecraft:red_terracotta
fill 472 284 481 473 284 481 minecraft:terracotta
fill 472 284 482 472 284 485 minecraft:red_terracotta
fill 472 284 486 473 284 486 minecraft:terracotta
fill 472 284 487 472 284 490 minecraft:red_terracotta
setblock 472 284 491 minecraft:terracotta
fill 472 284 492 472 284 495 minecraft:red_terracotta
setblock 472 284 496 minecraft:terracotta
fill 472 284 497 472 284 500 minecraft:red_terracotta
setblock 472 284 501 minecraft:terracotta
fill 472 284 502 472 287 502 minecraft:red_terracotta
fill 472 284 504 473 284 504 minecraft:red_terracotta
setblock 473 284 469 minecraft:red_terracotta
setblock 473 284 470 minecraft:terracotta
fill 473 284 471 473 284 474 minecraft:red_terracotta
setblock 473 284 475 minecraft:terracotta
fill 473 284 476 473 285 478 minecraft:red_terracotta
fill 473 284 479 473 284 480 minecraft:terracotta
fill 473 284 482 473 284 485 minecraft:terracotta
fill 473 284 487 473 284 490 minecraft:terracotta
fill 473 284 491 473 284 494 minecraft:red_terracotta
setblock 473 284 495 minecraft:terracotta
fill 473 284 496 473 284 499 minecraft:red_terracotta
setblock 474 284 464 minecraft:terracotta
fill 474 284 472 474 284 473 minecraft:red_terracotta
fill 474 284 474 476 284 474 minecraft:terracotta
fill 474 284 475 474 287 475 minecraft:red_terracotta
fill 474 284 476 474 284 478 minecraft:terracotta
fill 474 284 479 480 284 489 minecraft:red_terracotta
fill 474 284 490 474 284 492 minecraft:terracotta
setblock 474 284 493 minecraft:red_terracotta
fill 474 284 494 476 284 494 minecraft:terracotta
fill 474 284 495 474 285 496 minecraft:red_terracotta
setblock 474 284 504 minecraft:terracotta
fill 475 284 475 475 284 476 minecraft:terracotta
fill 475 284 477 482 284 478 minecraft:red_terracotta
fill 475 284 490 482 284 491 minecraft:red_terracotta
fill 475 284 492 475 284 493 minecraft:terracotta
setblock 476 284 473 minecraft:terracotta
fill 476 284 475 484 284 476 minecraft:red_terracotta
fill 476 284 492 483 284 493 minecraft:red_terracotta
setblock 476 284 495 minecraft:terracotta
setblock 477 284 472 minecraft:terracotta
fill 477 284 473 488 284 474 minecraft:red_terracotta
fill 477 284 494 486 284 495 minecraft:red_terracotta
setblock 477 284 496 minecraft:terracotta
setblock 478 284 471 minecraft:terracotta
fill 478 284 472 504 284 472 minecraft:red_terracotta
fill 478 284 496 504 284 496 minecraft:red_terracotta
setblock 478 284 497 minecraft:terracotta
setblock 479 284 470 minecraft:terracotta
fill 479 284 471 503 284 471 minecraft:red_terracotta
fill 479 284 497 503 284 497 minecraft:red_terracotta
setblock 479 284 498 minecraft:terracotta
fill 480 284 469 481 284 469 minecraft:terracotta
fill 480 284 470 502 284 470 minecraft:red_terracotta
fill 480 284 498 502 284 498 minecraft:red_terracotta
fill 480 284 499 481 284 499 minecraft:terracotta
fill 481 284 468 483 284 468 minecraft:terracotta
fill 481 284 479 481 284 481 minecraft:red_terracotta
fill 481 284 482 482 284 487 minecraft:orange_terracotta
fill 481 284 488 481 284 489 minecraft:red_terracotta
fill 481 284 500 483 284 500 minecraft:terracotta
fill 482 284 469 500 284 469 minecraft:red_terracotta
setblock 482 284 479 minecraft:red_terracotta
fill 482 284 480 483 284 481 minecraft:orange_terracotta
fill 482 284 488 482 284 489 minecraft:orange_terracotta
fill 482 284 499 500 284 499 minecraft:red_terracotta
fill 483 284 467 485 284 467 minecraft:terracotta
setblock 483 284 477 minecraft:red_terracotta
fill 483 284 478 484 284 479 minecraft:orange_terracotta
fill 483 284 489 483 284 491 minecraft:orange_terracotta
fill 483 284 501 485 284 501 minecraft:terracotta
fill 484 284 468 498 284 468 minecraft:red_terracotta
fill 484 284 477 486 284 477 minecraft:orange_terracotta
fill 484 284 491 484 284 492 minecraft:orange_terracotta
setblock 484 284 493 minecraft:red_terracotta
fill 484 284 500 498 284 500 minecraft:red_terracotta
fill 485 284 475 486 284 475 minecraft:red_terracotta
fill 485 284 476 488 284 476 minecraft:orange_terracotta
setblock 485 284 478 minecraft:orange_terracotta
fill 485 284 492 485 284 493 minecraft:orange_terracotta
fill 486 284 464 488 284 464 minecraft:red_terracotta
fill 486 284 466 496 284 466 minecraft:terracotta
fill 486 284 467 496 284 467 minecraft:red_terracotta
fill 486 284 493 487 284 493 minecraft:orange_terracotta
fill 486 284 501 496 284 501 minecraft:red_terracotta
fill 486 284 502 496 284 502 minecraft:terracotta
setblock 487 284 465 minecraft:red_terracotta
fill 487 284 475 496 284 475 minecraft:orange_terracotta
fill 487 284 494 495 284 494 minecraft:orange_terracotta
fill 487 284 495 489 284 495 minecraft:red_terracotta
setblock 488 284 465 minecraft:terracotta
setblock 489 284 464 minecraft:terracotta
fill 489 284 465 492 284 465 minecraft:red_terracotta
fill 489 284 473 505 284 473 minecraft:red_terracotta
fill 489 284 474 493 284 474 minecraft:orange_terracotta
setblock 489 284 504 minecraft:terracotta
fill 490 284 464 493 284 464 minecraft:red_terracotta
fill 490 284 495 492 284 495 minecraft:orange_terracotta
fill 490 284 504 493 284 504 minecraft:red_terracotta
fill 491 284 503 494 284 503 minecraft:red_terracotta
setblock 493 284 465 minecraft:terracotta
fill 493 284 495 505 284 495 minecraft:red_terracotta
setblock 494 284 464 minecraft:terracotta
fill 494 284 465 497 284 465 minecraft:red_terracotta
fill 494 284 474 505 284 474 minecraft:red_terracotta
setblock 494 284 504 minecraft:terracotta
fill 495 284 464 498 284 464 minecraft:red_terracotta
fill 495 284 476 497 284 476 minecraft:orange_terracotta
setblock 495 284 503 minecraft:terracotta
fill 495 284 504 498 284 504 minecraft:red_terracotta
fill 496 284 493 497 284 493 minecraft:orange_terracotta
fill 496 284 494 505 284 494 minecraft:red_terracotta
fill 496 284 503 497 286 503 minecraft:red_terracotta
fill 497 284 467 499 284 467 minecraft:terracotta
fill 497 284 475 506 284 475 minecraft:red_terracotta
fill 497 284 477 498 284 477 minecraft:orange_terracotta
fill 497 284 492 498 284 492 minecraft:orange_terracotta
fill 497 284 501 499 284 501 minecraft:terracotta
setblock 498 284 465 minecraft:terracotta
fill 498 284 476 506 284 476 minecraft:red_terracotta
fill 498 284 478 499 284 478 minecraft:orange_terracotta
fill 498 284 491 499 284 491 minecraft:orange_terracotta
fill 498 284 493 506 284 493 minecraft:red_terracotta
setblock 499 284 464 minecraft:terracotta
fill 499 284 468 501 284 468 minecraft:terracotta
fill 499 284 477 507 284 477 minecraft:red_terracotta
fill 499 284 479 500 284 479 minecraft:orange_terracotta
fill 499 284 490 500 284 490 minecraft:orange_terracotta
fill 499 284 492 506 284 492 minecraft:red_terracotta
fill 499 284 500 501 284 500 minecraft:terracotta
setblock 499 284 504 minecraft:terracotta
fill 500 284 464 501 284 464 minecraft:red_terracotta
fill 500 284 478 507 284 478 minecraft:red_terracotta
fill 500 284 480 500 284 481 minecraft:orange_terracotta
fill 500 284 488 500 284 489 minecraft:orange_terracotta
fill 500 284 491 507 284 491 minecraft:red_terracotta
fill 500 284 504 503 284 504 minecraft:red_terracotta
fill 501 284 469 502 284 469 minecraft:terracotta
fill 501 284 479 508 284 480 minecraft:red_terracotta
fill 501 284 481 501 284 488 minecraft:orange_terracotta
fill 501 284 489 507 284 490 minecraft:red_terracotta
fill 501 284 499 502 284 499 minecraft:terracotta
fill 502 284 481 508 284 488 minecraft:red_terracotta
setblock 503 284 470 minecraft:terracotta
setblock 503 284 498 minecraft:terracotta
setblock 504 284 471 minecraft:terracotta
setblock 504 284 497 minecraft:terracotta
setblock 504 284 504 minecraft:terracotta
setblock 505 284 472 minecraft:terracotta
setblock 505 284 496 minecraft:terracotta
fill 505 284 504 508 284 504 minecraft:red_terracotta
fill 506 284 473 506 284 474 minecraft:terracotta
fill 506 284 494 506 284 495 minecraft:terracotta
fill 507 284 464 508 284 464 minecraft:red_terracotta
fill 507 284 474 507 284 476 minecraft:terracotta
fill 507 284 492 507 284 494 minecraft:terracotta
fill 507 284 503 509 284 503 minecraft:red_terracotta
fill 508 284 476 508 284 478 minecraft:terracotta
setblock 508 284 489 minecraft:red_terracotta
fill 508 284 490 508 284 492 minecraft:terracotta
fill 508 284 493 508 284 494 minecraft:red_terracotta
setblock 508 284 495 minecraft:terracotta
fill 508 284 496 510 284 497 minecraft:red_terracotta
setblock 509 284 464 minecraft:terracotta
fill 509 284 479 509 284 489 minecraft:terracotta
fill 509 284 490 509 284 493 minecraft:red_terracotta
setblock 509 284 494 minecraft:terracotta
fill 509 284 495 511 285 495 minecraft:red_terracotta
setblock 509 284 498 minecraft:red_terracotta
setblock 509 284 499 minecraft:terracotta
fill 509 284 500 511 284 501 minecraft:red_terracotta
setblock 509 284 504 minecraft:terracotta
fill 510 284 464 511 286 464 minecraft:red_terracotta
setblock 510 284 467 minecraft:red_terracotta
setblock 510 284 468 minecraft:terracotta
fill 510 284 469 510 284 472 minecraft:red_terracotta
setblock 510 284 473 minecraft:terracotta
fill 510 284 474 510 284 477 minecraft:red_terracotta
setblock 510 284 478 minecraft:terracotta
fill 510 284 481 510 285 481 minecraft:magma_block
fill 510 284 482 510 285 482 minecraft:shroomlight
fill 510 284 483 510 285 483 minecraft:magma_block
fill 510 284 486 510 284 487 minecraft:red_terracotta
setblock 510 284 488 minecraft:terracotta
fill 510 284 489 510 284 492 minecraft:red_terracotta
setblock 510 284 493 minecraft:terracotta
fill 510 284 494 511 286 494 minecraft:red_terracotta
setblock 510 284 498 minecraft:terracotta
fill 510 284 499 511 286 499 minecraft:red_terracotta
setblock 510 284 502 minecraft:red_terracotta
setblock 510 284 503 minecraft:terracotta
fill 510 284 504 511 286 504 minecraft:red_terracotta
fill 511 284 465 511 284 466 minecraft:red_terracotta
setblock 511 284 467 minecraft:terracotta
fill 511 284 468 511 284 471 minecraft:red_terracotta
setblock 511 284 472 minecraft:terracotta
fill 511 284 473 511 284 476 minecraft:red_terracotta
setblock 511 284 477 minecraft:terracotta
fill 511 284 478 511 284 481 minecraft:red_terracotta
setblock 511 284 482 minecraft:terracotta
fill 511 284 483 511 284 486 minecraft:red_terracotta
setblock 511 284 487 minecraft:terracotta
fill 511 284 488 511 284 491 minecraft:red_terracotta
setblock 511 284 492 minecraft:terracotta
fill 511 284 493 511 287 493 minecraft:red_terracotta
setblock 511 284 496 minecraft:red_terracotta
setblock 511 284 497 minecraft:terracotta
fill 511 284 498 511 287 498 minecraft:red_terracotta
setblock 511 284 502 minecraft:terracotta
fill 511 284 503 511 287 503 minecraft:red_terracotta
fill 471 285 464 471 285 465 minecraft:red_terracotta
setblock 471 285 466 minecraft:terracotta
fill 471 285 467 471 285 470 minecraft:red_terracotta
setblock 471 285 471 minecraft:terracotta
fill 471 285 472 471 285 475 minecraft:red_terracotta
setblock 471 285 476 minecraft:terracotta
fill 471 285 477 471 285 480 minecraft:red_terracotta
setblock 471 285 481 minecraft:terracotta
fill 471 285 482 471 285 485 minecraft:red_terracotta
setblock 471 285 486 minecraft:terracotta
fill 471 285 487 471 285 490 minecraft:red_terracotta
setblock 471 285 491 minecraft:terracotta
fill 471 285 492 471 285 495 minecraft:red_terracotta
setblock 471 285 496 minecraft:terracotta
fill 471 285 497 471 285 500 minecraft:red_terracotta
setblock 471 285 501 minecraft:terracotta
fill 471 285 502 471 288 502 minecraft:red_terracotta
setblock 472 285 464 minecraft:red_terracotta
fill 472 285 467 472 285 469 minecraft:red_terracotta
setblock 472 285 470 minecraft:terracotta
fill 472 285 471 472 285 474 minecraft:red_terracotta
setblock 472 285 475 minecraft:terracotta
fill 472 285 476 472 285 479 minecraft:red_terracotta
setblock 472 285 480 minecraft:terracotta
fill 472 285 481 472 285 484 minecraft:red_terracotta
setblock 472 285 485 minecraft:terracotta
fill 472 285 486 472 285 489 minecraft:red_terracotta
setblock 472 285 490 minecraft:terracotta
fill 472 285 491 472 285 494 minecraft:red_terracotta
setblock 472 285 495 minecraft:terracotta
fill 472 285 496 472 285 499 minecraft:red_terracotta
setblock 472 285 500 minecraft:terracotta
fill 472 285 501 472 288 501 minecraft:red_terracotta
setblock 472 285 504 minecraft:red_terracotta
setblock 473 285 464 minecraft:terracotta
setblock 473 285 466 minecraft:light[level=14]
fill 473 285 470 473 285 473 minecraft:red_terracotta
setblock 473 285 474 minecraft:terracotta
fill 473 285 475 473 288 475 minecraft:red_terracotta
fill 473 285 479 475 285 479 minecraft:terracotta
fill 473 285 480 473 285 483 minecraft:red_terracotta
fill 473 285 484 474 285 484 minecraft:terracotta
fill 473 285 485 473 285 488 minecraft:red_terracotta
fill 473 285 489 475 285 489 minecraft:terracotta
fill 473 285 490 473 285 493 minecraft:red_terracotta
setblock 473 285 494 minecraft:terracotta
fill 473 285 495 473 285 498 minecraft:red_terracotta
setblock 473 285 499 minecraft:terracotta
setblock 473 285 504 minecraft:terracotta
setblock 474 285 473 minecraft:terracotta
fill 474 285 474 474 286 474 minecraft:red_terracotta
fill 474 285 476 474 285 477 minecraft:red_terracotta
fill 474 285 480 474 285 483 minecraft:terracotta
fill 474 285 485 474 285 488 minecraft:terracotta
setblock 474 285 492 minecraft:red_terracotta
setblock 474 285 493 minecraft:terracotta
setblock 474 285 494 minecraft:red_terracotta
setblock 474 285 504 minecraft:red_terracotta
fill 475 285 477 475 285 478 minecraft:terracotta
fill 475 285 480 475 285 481 minecraft:terracotta
fill 475 285 482 478 285 486 minecraft:red_terracotta
fill 475 285 487 475 285 488 minecraft:terracotta
fill 475 285 490 475 285 491 minecraft:terracotta
fill 476 285 475 476 285 477 minecraft:terracotta
fill 476 285 478 479 285 481 minecraft:red_terracotta
fill 476 285 487 479 285 490 minecraft:red_terracotta
fill 476 285 491 476 285 493 minecraft:terracotta
fill 477 285 473 477 285 475 minecraft:terracotta
fill 477 285 476 481 285 477 minecraft:red_terracotta
fill 477 285 491 480 285 492 minecraft:red_terracotta
fill 477 285 493 477 285 495 minecraft:terracotta
fill 478 285 472 478 285 474 minecraft:terracotta
fill 478 285 475 482 285 475 minecraft:red_terracotta
fill 478 285 493 482 285 493 minecraft:red_terracotta
fill 478 285 494 478 285 496 minecraft:terracotta
fill 479 285 471 479 285 473 minecraft:terracotta
fill 479 285 474 484 285 474 minecraft:red_terracotta
setblock 479 285 482 minecraft:red_terracotta
fill 479 285 483 480 285 486 minecraft:orange_terracotta
fill 479 285 494 483 285 494 minecraft:red_terracotta
fill 479 285 495 479 285 497 minecraft:terracotta
fill 480 285 470 480 285 472 minecraft:terracotta
fill 480 285 473 486 285 473 minecraft:red_terracotta
setblock 480 285 478 minecraft:red_terracotta
fill 480 285 479 480 285 482 minecraft:orange_terracotta
fill 480 285 487 480 285 489 minecraft:orange_terracotta
setblock 480 285 490 minecraft:red_terracotta
fill 480 285 495 485 285 495 minecraft:red_terracotta
fill 480 285 496 480 285 498 minecraft:terracotta
setblock 481 285 466 minecraft:light[level=14]
fill 481 285 470 481 285 471 minecraft:terracotta
fill 481 285 472 489 285 472 minecraft:red_terracotta
fill 481 285 478 481 285 481 minecraft:orange_terracotta
setblock 481 285 482 minecraft:light[level=14]
fill 481 285 488 481 285 491 minecraft:orange_terracotta
setblock 481 285 492 minecraft:red_terracotta
fill 481 285 496 488 285 496 minecraft:red_terracotta
fill 481 285 497 481 285 498 minecraft:terracotta
fill 482 285 469 482 285 470 minecraft:terracotta
fill 482 285 471 500 285 471 minecraft:red_terracotta
fill 482 285 476 482 285 479 minecraft:orange_terracotta
fill 482 285 490 482 285 492 minecraft:orange_terracotta
fill 482 285 497 500 285 497 minecraft:red_terracotta
fill 482 285 498 482 285 499 minecraft:terracotta
fill 483 285 469 484 285 469 minecraft:terracotta
fill 483 285 470 499 285 470 minecraft:red_terracotta
fill 483 285 475 483 285 477 minecraft:orange_terracotta
fill 483 285 492 483 285 493 minecraft:orange_terracotta
fill 483 285 498 499 285 498 minecraft:red_terracotta
fill 483 285 499 484 285 499 minecraft:terracotta
fill 484 285 468 488 285 468 minecraft:terracotta
fill 484 285 475 484 285 476 minecraft:orange_terracotta
fill 484 285 493 484 285 494 minecraft:orange_terracotta
fill 484 285 500 488 285 500 minecraft:terracotta
fill 485 285 469 497 285 469 minecraft:red_terracotta
fill 485 285 474 486 285 475 minecraft:orange_terracotta
fill 485 285 494 486 285 494 minecraft:orange_terracotta
fill 485 285 499 497 285 499 minecraft:red_terracotta
fill 486 285 464 487 285 464 minecraft:red_terracotta
fill 486 285 467 496 285 467 minecraft:terracotta
fill 486 285 495 489 285 495 minecraft:orange_terracotta
fill 486 285 501 496 285 501 minecraft:terracotta
setblock 487 285 465 minecraft:terracotta
fill 487 285 473 488 285 474 minecraft:orange_terracotta
setblock 488 285 464 minecraft:terracotta
fill 488 285 465 491 285 465 minecraft:red_terracotta
setblock 488 285 504 minecraft:terracotta
fill 489 285 464 492 285 464 minecraft:red_terracotta
fill 489 285 466 490 285 466 minecraft:red_terracotta
fill 489 285 468 493 285 468 minecraft:red_terracotta
fill 489 285 473 496 285 473 minecraft:orange_terracotta
setblock 489 285 474 minecraft:light[level=14]
setblock 489 285 482 minecraft:light[level=14]
setblock 489 285 490 minecraft:light[level=14]
fill 489 285 496 494 285 496 minecraft:orange_terracotta
fill 489 285 500 493 285 500 minecraft:red_terracotta
fill 489 285 504 492 285 504 minecraft:red_terracotta
fill 490 285 472 492 285 472 minecraft:orange_terracotta
fill 490 285 503 493 285 503 minecraft:red_terracotta
setblock 491 285 466 minecraft:terracotta
setblock 492 285 465 minecraft:terracotta
fill 492 285 466 495 285 466 minecraft:red_terracotta
setblock 493 285 464 minecraft:terracotta
fill 493 285 465 496 285 465 minecraft:red_terracotta
fill 493 285 472 501 285 472 minecraft:red_terracotta
fill 493 285 495 496 285 495 minecraft:orange_terracotta
setblock 493 285 504 minecraft:terracotta
fill 494 285 464 497 285 464 minecraft:red_terracotta
fill 494 285 468 498 285 468 minecraft:terracotta
fill 494 285 474 497 285 474 minecraft:orange_terracotta
fill 494 285 500 498 285 500 minecraft:terracotta
setblock 494 285 503 minecraft:terracotta
fill 494 285 504 497 285 504 minecraft:red_terracotta
fill 495 285 496 501 285 496 minecraft:red_terracotta
fill 495 285 503 495 288 503 minecraft:red_terracotta
fill 496 285 494 498 285 494 minecraft:orange_terracotta
setblock 497 285 465 minecraft:terracotta
setblock 497 285 466 minecraft:light[level=14]
fill 497 285 473 502 285 473 minecraft:red_terracotta
fill 497 285 475 499 285 475 minecraft:orange_terracotta
setblock 497 285 482 minecraft:light[level=14]
setblock 497 285 490 minecraft:light[level=14]
fill 497 285 495 502 285 495 minecraft:red_terracotta
setblock 498 285 464 minecraft:terracotta
fill 498 285 469 500 285 469 minecraft:terracotta
fill 498 285 474 503 285 474 minecraft:red_terracotta
fill 498 285 476 500 285 476 minecraft:orange_terracotta
fill 498 285 493 499 285 493 minecraft:orange_terracotta
fill 498 285 499 500 285 499 minecraft:terracotta
setblock 498 285 504 minecraft:terracotta
setblock 499 285 464 minecraft:red_terracotta
fill 499 285 477 500 285 477 minecraft:orange_terracotta
fill 499 285 492 500 285 492 minecraft:orange_terracotta
fill 499 285 494 503 285 494 minecraft:red_terracotta
fill 499 285 504 502 285 504 minecraft:red_terracotta
fill 500 285 470 502 285 470 minecraft:terracotta
fill 500 285 475 504 285 475 minecraft:red_terracotta
fill 500 285 478 501 285 478 minecraft:orange_terracotta
fill 500 285 491 501 285 491 minecraft:orange_terracotta
fill 500 285 493 504 285 493 minecraft:red_terracotta
fill 500 285 498 502 285 498 minecraft:terracotta
fill 501 285 471 503 285 471 minecraft:terracotta
fill 501 285 476 505 285 477 minecraft:red_terracotta
fill 501 285 479 502 285 480 minecraft:orange_terracotta
fill 501 285 489 501 285 490 minecraft:orange_terracotta
fill 501 285 492 505 285 492 minecraft:red_terracotta
fill 501 285 497 503 285 497 minecraft:terracotta
fill 502 285 472 504 285 472 minecraft:terracotta
fill 502 285 478 506 285 478 minecraft:red_terracotta
fill 502 285 481 502 285 489 minecraft:orange_terracotta
fill 502 285 490 505 285 491 minecraft:red_terracotta
fill 502 285 496 504 285 496 minecraft:terracotta
fill 503 285 473 505 285 473 minecraft:terracotta
fill 503 285 479 506 285 481 minecraft:red_terracotta
fill 503 285 482 503 285 486 minecraft:orange_terracotta
fill 503 285 487 506 285 489 minecraft:red_terracotta
fill 503 285 495 505 285 495 minecraft:terracotta
setblock 503 285 504 minecraft:terracotta
fill 504 285 474 505 285 474 minecraft:terracotta
fill 504 285 482 507 285 486 minecraft:red_terracotta
fill 504 285 494 505 285 494 minecraft:terracotta
fill 504 285 504 507 285 504 minecraft:red_terracotta
setblock 505 285 466 minecraft:light[level=14]
fill 505 285 475 506 285 475 minecraft:terracotta
fill 505 285 493 506 285 493 minecraft:terracotta
setblock 505 285 498 minecraft:light[level=14]
fill 506 285 476 506 285 477 minecraft:terracotta
setblock 506 285 490 minecraft:red_terracotta
fill 506 285 491 506 285 492 minecraft:terracotta
fill 506 285 503 508 285 503 minecraft:red_terracotta
setblock 507 285 464 minecraft:red_terracotta
fill 507 285 477 507 285 481 minecraft:terracotta
fill 507 285 487 507 285 491 minecraft:terracotta
setblock 508 285 464 minecraft:terracotta
fill 508 285 479 508 285 489 minecraft:terracotta
setblock 508 285 493 minecraft:red_terracotta
setblock 508 285 494 minecraft:terracotta
fill 508 285 495 508 285 498 minecraft:red_terracotta
setblock 508 285 499 minecraft:terracotta
fill 508 285 502 509 285 502 minecraft:red_terracotta
setblock 508 285 504 minecraft:terracotta
fill 509 285 464 509 287 464 minecraft:red_terracotta
fill 509 285 489 509 285 492 minecraft:red_terracotta
setblock 509 285 493 minecraft:terracotta
fill 509 285 494 509 288 494 minecraft:red_terracotta
fill 509 285 496 509 285 497 minecraft:red_terracotta
setblock 509 285 498 minecraft:terracotta
fill 509 285 499 509 286 501 minecraft:red_terracotta
setblock 509 285 503 minecraft:terracotta
fill 509 285 504 509 288 504 minecraft:red_terracotta
fill 510 285 468 510 285 471 minecraft:red_terracotta
setblock 510 285 472 minecraft:terracotta
fill 510 285 473 510 285 476 minecraft:red_terracotta
setblock 510 285 477 minecraft:terracotta
fill 510 285 478 511 285 480 minecraft:red_terracotta
fill 510 285 485 510 285 486 minecraft:red_terracotta
setblock 510 285 487 minecraft:terracotta
fill 510 285 488 510 285 491 minecraft:red_terracotta
setblock 510 285 492 minecraft:terracotta
fill 510 285 493 510 288 493 minecraft:red_terracotta
setblock 510 285 496 minecraft:red_terracotta
setblock 510 285 497 minecraft:terracotta
fill 510 285 498 510 288 498 minecraft:red_terracotta
fill 510 285 500 510 285 501 minecraft:red_terracotta
setblock 510 285 502 minecraft:terracotta
fill 510 285 503 510 288 503 minecraft:red_terracotta
setblock 511 285 465 minecraft:red_terracotta
setblock 511 285 466 minecraft:terracotta
fill 511 285 467 511 285 470 minecraft:red_terracotta
setblock 511 285 471 minecraft:terracotta
fill 511 285 472 511 285 475 minecraft:red_terracotta
setblock 511 285 476 minecraft:terracotta
fill 511 285 477 511 288 477 minecraft:red_terracotta
setblock 511 285 481 minecraft:terracotta
fill 511 285 482 511 285 485 minecraft:red_terracotta
setblock 511 285 486 minecraft:terracotta
fill 511 285 487 511 285 490 minecraft:red_terracotta
setblock 511 285 491 minecraft:terracotta
fill 511 285 492 511 288 492 minecraft:red_terracotta
setblock 511 285 496 minecraft:terracotta
fill 511 285 497 511 288 497 minecraft:red_terracotta
setblock 511 285 500 minecraft:red_terracotta
setblock 511 285 501 minecraft:terracotta
fill 511 285 502 511 288 502 minecraft:red_terracotta
setblock 471 286 465 minecraft:terracotta
fill 471 286 466 471 286 469 minecraft:red_terracotta
setblock 471 286 470 minecraft:terracotta
fill 471 286 471 471 286 474 minecraft:red_terracotta
setblock 471 286 475 minecraft:terracotta
fill 471 286 476 471 286 479 minecraft:red_terracotta
setblock 471 286 480 minecraft:terracotta
fill 471 286 481 471 286 484 minecraft:red_terracotta
setblock 471 286 485 minecraft:terracotta
fill 471 286 486 471 286 489 minecraft:red_terracotta
setblock 471 286 490 minecraft:terracotta
fill 471 286 491 471 286 494 minecraft:red_terracotta
setblock 471 286 495 minecraft:terracotta
fill 471 286 496 471 286 499 minecraft:red_terracotta
setblock 471 286 500 minecraft:terracotta
fill 471 286 501 471 289 501 minecraft:red_terracotta
setblock 472 286 468 minecraft:red_terracotta
setblock 472 286 469 minecraft:terracotta
fill 472 286 470 472 286 473 minecraft:red_terracotta
setblock 472 286 474 minecraft:terracotta
fill 472 286 475 472 286 478 minecraft:red_terracotta
setblock 472 286 479 minecraft:terracotta
fill 472 286 480 472 286 483 minecraft:red_terracotta
setblock 472 286 484 minecraft:terracotta
fill 472 286 485 472 286 488 minecraft:red_terracotta
setblock 472 286 489 minecraft:terracotta
fill 472 286 490 472 286 493 minecraft:red_terracotta
setblock 472 286 494 minecraft:terracotta
fill 472 286 495 472 286 498 minecraft:red_terracotta
setblock 472 286 499 minecraft:terracotta
fill 472 286 500 472 289 500 minecraft:red_terracotta
setblock 472 286 504 minecraft:terracotta
fill 473 286 471 473 286 472 minecraft:red_terracotta
setblock 473 286 473 minecraft:terracotta
fill 473 286 474 473 289 474 minecraft:red_terracotta
fill 473 286 476 473 286 477 minecraft:red_terracotta
setblock 473 286 478 minecraft:terracotta
fill 473 286 479 473 286 482 minecraft:red_terracotta
setblock 473 286 483 minecraft:terracotta
setblock 473 286 487 minecraft:red_terracotta
setblock 473 286 488 minecraft:terracotta
fill 473 286 489 473 286 492 minecraft:red_terracotta
setblock 473 286 493 minecraft:terracotta
fill 473 286 494 473 286 497 minecraft:red_terracotta
setblock 473 286 498 minecraft:terracotta
setblock 473 286 499 minecraft:red_terracotta
fill 473 286 504 473 287 504 minecraft:red_terracotta
setblock 474 286 476 minecraft:red_terracotta
setblock 474 286 477 minecraft:terracotta
fill 475 286 482 477 286 486 minecraft:terracotta
fill 476 286 478 478 286 481 minecraft:terracotta
fill 476 286 487 478 286 490 minecraft:terracotta
fill 477 286 476 480 286 477 minecraft:terracotta
fill 477 286 491 479 286 492 minecraft:terracotta
fill 478 286 475 481 286 475 minecraft:terracotta
setblock 478 286 482 minecraft:terracotta
fill 478 286 483 478 286 486 minecraft:orange_terracotta
fill 478 286 493 481 286 493 minecraft:terracotta
fill 479 286 474 482 286 474 minecraft:terracotta
setblock 479 286 478 minecraft:terracotta
fill 479 286 479 479 286 482 minecraft:orange_terracotta
fill 479 286 487 479 286 489 minecraft:orange_terracotta
setblock 479 286 490 minecraft:terracotta
fill 479 286 494 482 286 494 minecraft:terracotta
fill 480 286 473 484 286 473 minecraft:terracotta
setblock 480 286 478 minecraft:orange_terracotta
fill 480 286 490 480 286 491 minecraft:orange_terracotta
setblock 480 286 492 minecraft:terracotta
fill 480 286 495 483 286 495 minecraft:terracotta
fill 481 286 472 485 286 472 minecraft:terracotta
fill 481 286 476 481 286 477 minecraft:orange_terracotta
setblock 481 286 492 minecraft:orange_terracotta
fill 481 286 496 485 286 496 minecraft:terracotta
fill 482 286 471 489 286 471 minecraft:terracotta
setblock 482 286 475 minecraft:orange_terracotta
setblock 482 286 493 minecraft:orange_terracotta
fill 482 286 497 488 286 497 minecraft:terracotta
fill 483 286 470 499 286 470 minecraft:terracotta
fill 483 286 474 484 286 474 minecraft:orange_terracotta
setblock 483 286 494 minecraft:orange_terracotta
fill 483 286 498 499 286 498 minecraft:terracotta
fill 484 286 495 485 286 495 minecraft:orange_terracotta
fill 485 286 464 486 286 464 minecraft:red_terracotta
fill 485 286 469 497 286 469 minecraft:terracotta
fill 485 286 473 486 286 473 minecraft:orange_terracotta
fill 485 286 499 497 286 499 minecraft:terracotta
fill 486 286 472 489 286 472 minecraft:orange_terracotta
fill 486 286 496 488 286 496 minecraft:orange_terracotta
setblock 487 286 464 minecraft:terracotta
fill 487 286 465 490 286 465 minecraft:red_terracotta
setblock 487 286 504 minecraft:terracotta
fill 488 286 464 491 286 464 minecraft:red_terracotta
fill 488 286 504 491 286 504 minecraft:red_terracotta
setblock 489 286 466 minecraft:red_terracotta
fill 489 286 468 493 286 468 minecraft:terracotta
fill 489 286 497 494 286 497 minecraft:orange_terracotta
fill 489 286 500 493 286 500 minecraft:terracotta
fill 489 286 503 492 286 503 minecraft:red_terracotta
setblock 490 286 466 minecraft:terracotta
fill 490 286 471 492 286 471 minecraft:orange_terracotta
setblock 491 286 465 minecraft:terracotta
fill 491 286 466 493 286 466 minecraft:red_terracotta
setblock 492 286 464 minecraft:terracotta
fill 492 286 465 495 286 465 minecraft:red_terracotta
setblock 492 286 504 minecraft:terracotta
fill 493 286 464 496 286 464 minecraft:red_terracotta
fill 493 286 471 500 286 471 minecraft:terracotta
fill 493 286 472 496 286 472 minecraft:orange_terracotta
setblock 493 286 503 minecraft:terracotta
fill 493 286 504 496 286 504 minecraft:red_terracotta
fill 494 286 503 494 289 503 minecraft:red_terracotta
fill 495 286 496 496 286 496 minecraft:orange_terracotta
fill 495 286 497 500 286 497 minecraft:terracotta
setblock 496 286 465 minecraft:terracotta
setblock 497 286 464 minecraft:terracotta
fill 497 286 472 501 286 472 minecraft:terracotta
setblock 497 286 473 minecraft:orange_terracotta
fill 497 286 495 498 286 495 minecraft:orange_terracotta
fill 497 286 496 501 286 496 minecraft:terracotta
setblock 497 286 504 minecraft:terracotta
setblock 498 286 464 minecraft:red_terracotta
fill 498 286 473 502 286 473 minecraft:terracotta
fill 498 286 474 499 286 474 minecraft:orange_terracotta
fill 498 286 504 501 286 504 minecraft:red_terracotta
setblock 499 286 494 minecraft:orange_terracotta
fill 499 286 495 502 286 495 minecraft:terracotta
fill 500 286 474 503 286 474 minecraft:terracotta
setblock 500 286 475 minecraft:orange_terracotta
setblock 500 286 493 minecraft:orange_terracotta
fill 500 286 494 503 286 494 minecraft:terracotta
fill 501 286 475 504 286 475 minecraft:terracotta
fill 501 286 476 501 286 477 minecraft:orange_terracotta
setblock 501 286 492 minecraft:orange_terracotta
fill 501 286 493 504 286 493 minecraft:terracotta
fill 502 286 476 505 286 477 minecraft:terracotta
setblock 502 286 478 minecraft:orange_terracotta
fill 502 286 490 502 286 491 minecraft:orange_terracotta
fill 502 286 492 505 286 492 minecraft:terracotta
setblock 502 286 504 minecraft:terracotta
fill 503 286 478 506 286 478 minecraft:terracotta
fill 503 286 479 503 286 481 minecraft:orange_terracotta
fill 503 286 487 503 286 489 minecraft:orange_terracotta
fill 503 286 490 505 286 491 minecraft:terracotta
fill 503 286 504 506 286 504 minecraft:red_terracotta
fill 504 286 479 506 286 481 minecraft:terracotta
fill 504 286 482 504 286 486 minecraft:orange_terracotta
fill 504 286 487 506 286 489 minecraft:terracotta
fill 505 286 482 507 286 486 minecraft:terracotta
fill 505 286 503 507 286 503 minecraft:red_terracotta
setblock 506 286 490 minecraft:terracotta
fill 507 286 502 508 286 502 minecraft:red_terracotta
setblock 507 286 504 minecraft:terracotta
setblock 508 286 464 minecraft:red_terracotta
setblock 508 286 493 minecraft:terracotta
fill 508 286 494 508 286 497 minecraft:red_terracotta
setblock 508 286 498 minecraft:terracotta
fill 508 286 499 508 288 500 minecraft:red_terracotta
setblock 508 286 503 minecraft:terracotta
fill 508 286 504 508 289 504 minecraft:red_terracotta
fill 509 286 490 509 286 491 minecraft:red_terracotta
setblock 509 286 492 minecraft:terracotta
fill 509 286 493 509 289 493 minecraft:red_terracotta
fill 509 286 495 509 286 496 minecraft:red_terracotta
setblock 509 286 497 minecraft:terracotta
fill 509 286 498 509 289 498 minecraft:red_terracotta
setblock 509 286 502 minecraft:terracotta
fill 509 286 503 509 289 503 minecraft:red_terracotta
fill 510 286 469 510 286 470 minecraft:red_terracotta
setblock 510 286 471 minecraft:terracotta
fill 510 286 472 510 286 475 minecraft:red_terracotta
setblock 510 286 476 minecraft:terracotta
fill 510 286 477 510 286 480 minecraft:red_terracotta
setblock 510 286 481 minecraft:terracotta
fill 510 286 482 510 286 485 minecraft:red_terracotta
setblock 510 286 486 minecraft:terracotta
fill 510 286 487 510 286 490 minecraft:red_terracotta
setblock 510 286 491 minecraft:terracotta
fill 510 286 492 510 289 492 minecraft:red_terracotta
setblock 510 286 495 minecraft:red_terracotta
setblock 510 286 496 minecraft:terracotta
fill 510 286 497 510 289 497 minecraft:red_terracotta
setblock 510 286 500 minecraft:red_terracotta
setblock 510 286 501 minecraft:terracotta
fill 510 286 502 510 289 502 minecraft:red_terracotta
setblock 511 286 465 minecraft:terracotta
fill 511 286 466 511 286 469 minecraft:red_terracotta
setblock 511 286 470 minecraft:terracotta
fill 511 286 471 511 286 474 minecraft:red_terracotta
setblock 511 286 475 minecraft:terracotta
fill 511 286 476 511 289 476 minecraft:red_terracotta
fill 511 286 478 511 286 479 minecraft:red_terracotta
setblock 511 286 480 minecraft:terracotta
fill 511 286 481 511 286 484 minecraft:red_terracotta
setblock 511 286 485 minecraft:terracotta
fill 511 286 486 511 286 489 minecraft:red_terracotta
setblock 511 286 490 minecraft:terracotta
fill 511 286 491 511 289 491 minecraft:red_terracotta
setblock 511 286 495 minecraft:terracotta
fill 511 286 496 511 289 496 minecraft:red_terracotta
setblock 511 286 500 minecraft:terracotta
fill 511 286 501 511 289 501 minecraft:red_terracotta
fill 471 287 466 471 287 468 minecraft:red_terracotta
setblock 471 287 469 minecraft:terracotta
fill 471 287 470 471 287 473 minecraft:red_terracotta
setblock 471 287 474 minecraft:terracotta
fill 471 287 475 471 287 478 minecraft:red_terracotta
setblock 471 287 479 minecraft:terracotta
fill 471 287 480 471 287 483 minecraft:red_terracotta
setblock 471 287 484 minecraft:terracotta
fill 471 287 485 471 287 488 minecraft:red_terracotta
setblock 471 287 489 minecraft:terracotta
fill 471 287 490 471 287 493 minecraft:red_terracotta
setblock 471 287 494 minecraft:terracotta
fill 471 287 495 471 287 498 minecraft:red_terracotta
setblock 471 287 499 minecraft:terracotta
fill 471 287 500 471 290 500 minecraft:red_terracotta
setblock 471 287 503 minecraft:red_terracotta
setblock 471 287 504 minecraft:terracotta
fill 472 287 469 472 287 472 minecraft:red_terracotta
setblock 472 287 473 minecraft:terracotta
fill 472 287 474 472 287 477 minecraft:red_terracotta
setblock 472 287 478 minecraft:terracotta
fill 472 287 479 472 287 482 minecraft:red_terracotta
setblock 472 287 483 minecraft:terracotta
fill 472 287 484 472 287 487 minecraft:red_terracotta
setblock 472 287 488 minecraft:terracotta
fill 472 287 489 472 287 492 minecraft:red_terracotta
setblock 472 287 493 minecraft:terracotta
fill 472 287 494 472 287 497 minecraft:red_terracotta
setblock 472 287 498 minecraft:terracotta
fill 472 287 499 472 290 499 minecraft:red_terracotta
fill 472 287 504 472 288 504 minecraft:red_terracotta
setblock 473 287 472 minecraft:terracotta
fill 473 287 473 473 288 473 minecraft:red_terracotta
setblock 473 287 476 minecraft:red_terracotta
setblock 473 287 477 minecraft:terracotta
fill 473 287 478 473 287 481 minecraft:red_terracotta
setblock 473 287 482 minecraft:terracotta
setblock 473 287 491 minecraft:red_terracotta
setblock 473 287 492 minecraft:terracotta
fill 473 287 493 473 287 496 minecraft:red_terracotta
setblock 473 287 497 minecraft:terracotta
setblock 473 287 498 minecraft:red_terracotta
setblock 474 287 476 minecraft:terracotta
setblock 474 287 477 minecraft:red_terracotta
setblock 485 287 464 minecraft:red_terracotta
setblock 486 287 464 minecraft:terracotta
fill 487 287 464 489 287 465 minecraft:red_terracotta
fill 487 287 504 490 287 504 minecraft:red_terracotta
fill 489 287 503 491 287 503 minecraft:red_terracotta
setblock 490 287 464 minecraft:red_terracotta
setblock 490 287 465 minecraft:terracotta
fill 490 287 466 491 287 466 minecraft:red_terracotta
setblock 491 287 464 minecraft:terracotta
fill 491 287 465 494 287 465 minecraft:red_terracotta
setblock 491 287 504 minecraft:terracotta
fill 492 287 464 495 287 464 minecraft:red_terracotta
setblock 492 287 503 minecraft:terracotta
fill 492 287 504 495 287 504 minecraft:red_terracotta
fill 493 287 503 493 290 503 minecraft:red_terracotta
setblock 495 287 465 minecraft:terracotta
setblock 496 287 464 minecraft:terracotta
setblock 496 287 503 minecraft:red_terracotta
setblock 496 287 504 minecraft:terracotta
setblock 497 287 464 minecraft:red_terracotta
fill 497 287 504 500 287 504 minecraft:red_terracotta
setblock 501 287 504 minecraft:terracotta
fill 502 287 504 505 287 504 minecraft:red_terracotta
fill 505 287 503 506 287 503 minecraft:red_terracotta
setblock 506 287 504 minecraft:terracotta
setblock 507 287 502 minecraft:red_terracotta
setblock 507 287 503 minecraft:terracotta
fill 507 287 504 507 290 504 minecraft:red_terracotta
fill 508 287 493 508 287 496 minecraft:red_terracotta
setblock 508 287 497 minecraft:terracotta
fill 508 287 498 508 290 498 minecraft:red_terracotta
setblock 508 287 502 minecraft:terracotta
fill 508 287 503 508 290 503 minecraft:red_terracotta
setblock 509 287 490 minecraft:red_terracotta
setblock 509 287 491 minecraft:terracotta
fill 509 287 492 509 289 492 minecraft:red_terracotta
setblock 509 287 495 minecraft:red_terracotta
setblock 509 287 496 minecraft:terracotta
fill 509 287 497 509 290 497 minecraft:red_terracotta
fill 509 287 499 509 287 500 minecraft:red_terracotta
setblock 509 287 501 minecraft:terracotta
fill 509 287 502 509 290 502 minecraft:red_terracotta
setblock 510 287 464 minecraft:red_terracotta
fill 510 287 471 510 287 474 minecraft:red_terracotta
setblock 510 287 475 minecraft:terracotta
fill 510 287 476 510 287 479 minecraft:red_terracotta
setblock 510 287 480 minecraft:terracotta
fill 510 287 481 510 287 484 minecraft:red_terracotta
setblock 510 287 485 minecraft:terracotta
fill 510 287 486 510 287 489 minecraft:red_terracotta
setblock 510 287 490 minecraft:terracotta
fill 510 287 491 510 290 491 minecraft:red_terracotta
setblock 510 287 494 minecraft:red_terracotta
setblock 510 287 495 minecraft:terracotta
fill 510 287 496 510 290 496 minecraft:red_terracotta
setblock 510 287 499 minecraft:red_terracotta
setblock 510 287 500 minecraft:terracotta
fill 510 287 501 510 290 501 minecraft:red_terracotta
setblock 510 287 504 minecraft:red_terracotta
setblock 511 287 464 minecraft:terracotta
fill 511 287 466 511 287 468 minecraft:red_terracotta
setblock 511 287 469 minecraft:terracotta
fill 511 287 470 511 287 473 minecraft:red_terracotta
setblock 511 287 474 minecraft:terracotta
fill 511 287 475 511 290 475 minecraft:red_terracotta
setblock 511 287 478 minecraft:red_terracotta
setblock 511 287 479 minecraft:terracotta
fill 511 287 480 511 287 483 minecraft:red_terracotta
setblock 511 287 484 minecraft:terracotta
fill 511 287 485 511 287 488 minecraft:red_terracotta
setblock 511 287 489 minecraft:terracotta
fill 511 287 490 511 290 490 minecraft:red_terracotta
setblock 511 287 494 minecraft:terracotta
fill 511 287 495 511 290 495 minecraft:red_terracotta
setblock 511 287 499 minecraft:terracotta
fill 511 287 500 511 290 500 minecraft:red_terracotta
setblock 511 287 504 minecraft:terracotta
setblock 471 288 468 minecraft:terracotta
fill 471 288 469 471 288 472 minecraft:red_terracotta
setblock 471 288 473 minecraft:terracotta
fill 471 288 474 471 288 477 minecraft:red_terracotta
setblock 471 288 478 minecraft:terracotta
fill 471 288 479 471 288 482 minecraft:red_terracotta
setblock 471 288 483 minecraft:terracotta
fill 471 288 484 471 288 487 minecraft:red_terracotta
setblock 471 288 488 minecraft:terracotta
fill 471 288 489 471 288 492 minecraft:red_terracotta
setblock 471 288 493 minecraft:terracotta
fill 471 288 494 471 288 497 minecraft:red_terracotta
setblock 471 288 498 minecraft:terracotta
fill 471 288 499 471 291 499 minecraft:red_terracotta
setblock 471 288 503 minecraft:terracotta
fill 471 288 504 471 291 504 minecraft:red_terracotta
fill 472 288 470 472 288 471 minecraft:red_terracotta
setblock 472 288 472 minecraft:terracotta
fill 472 288 473 472 288 476 minecraft:red_terracotta
setblock 472 288 477 minecraft:terracotta
fill 472 288 478 472 288 481 minecraft:red_terracotta
setblock 472 288 482 minecraft:terracotta
fill 472 288 483 472 288 486 minecraft:red_terracotta
setblock 472 288 487 minecraft:terracotta
fill 472 288 488 472 288 491 minecraft:red_terracotta
setblock 472 288 492 minecraft:terracotta
fill 472 288 493 472 288 496 minecraft:red_terracotta
setblock 472 288 497 minecraft:terracotta
fill 472 288 498 472 290 498 minecraft:red_terracotta
setblock 473 288 476 minecraft:terracotta
fill 473 288 477 473 288 480 minecraft:red_terracotta
setblock 473 288 481 minecraft:terracotta
setblock 473 288 482 minecraft:red_terracotta
fill 473 288 494 473 288 495 minecraft:red_terracotta
setblock 473 288 496 minecraft:terracotta
setblock 473 288 497 minecraft:red_terracotta
setblock 485 288 464 minecraft:terracotta
fill 486 288 464 489 288 464 minecraft:red_terracotta
fill 486 288 504 489 288 504 minecraft:red_terracotta
fill 487 288 465 488 288 465 minecraft:red_terracotta
fill 488 288 503 490 288 503 minecraft:red_terracotta
setblock 489 288 465 minecraft:terracotta
setblock 490 288 464 minecraft:terracotta
fill 490 288 465 493 288 465 minecraft:red_terracotta
setblock 490 288 504 minecraft:terracotta
fill 491 288 464 494 288 464 minecraft:red_terracotta
setblock 491 288 503 minecraft:terracotta
fill 491 288 504 494 288 504 minecraft:red_terracotta
fill 492 288 503 492 291 503 minecraft:red_terracotta
setblock 495 288 464 minecraft:terracotta
setblock 495 288 504 minecraft:terracotta
setblock 496 288 464 minecraft:red_terracotta
setblock 496 288 503 minecraft:terracotta
fill 496 288 504 499 288 504 minecraft:red_terracotta
setblock 500 288 504 minecraft:terracotta
fill 501 288 504 504 288 504 minecraft:red_terracotta
fill 504 288 503 505 288 503 minecraft:red_terracotta
setblock 505 288 504 minecraft:terracotta
setblock 506 288 502 minecraft:red_terracotta
setblock 506 288 503 minecraft:terracotta
fill 506 288 504 506 291 504 minecraft:red_terracotta
setblock 507 288 502 minecraft:terracotta
fill 507 288 503 507 291 503 minecraft:red_terracotta
fill 508 288 494 508 288 495 minecraft:red_terracotta
setblock 508 288 496 minecraft:terracotta
fill 508 288 497 508 291 497 minecraft:red_terracotta
fill 508 288 502 508 291 502 minecraft:red_terracotta
setblock 509 288 491 minecraft:red_terracotta
setblock 509 288 495 minecraft:terracotta
fill 509 288 496 509 291 496 minecraft:red_terracotta
setblock 509 288 499 minecraft:red_terracotta
setblock 509 288 500 minecraft:terracotta
fill 509 288 501 509 291 501 minecraft:red_terracotta
fill 510 288 472 510 288 473 minecraft:red_terracotta
setblock 510 288 474 minecraft:terracotta
fill 510 288 475 510 288 478 minecraft:red_terracotta
setblock 510 288 479 minecraft:terracotta
fill 510 288 480 510 288 483 minecraft:red_terracotta
setblock 510 288 484 minecraft:terracotta
fill 510 288 485 510 288 488 minecraft:red_terracotta
setblock 510 288 489 minecraft:terracotta
fill 510 288 490 510 291 490 minecraft:red_terracotta
setblock 510 288 494 minecraft:terracotta
fill 510 288 495 510 291 495 minecraft:red_terracotta
setblock 510 288 499 minecraft:terracotta
fill 510 288 500 510 291 500 minecraft:red_terracotta
setblock 510 288 504 minecraft:terracotta
fill 511 288 469 511 288 472 minecraft:red_terracotta
setblock 511 288 473 minecraft:terracotta
fill 511 288 474 511 291 474 minecraft:red_terracotta
setblock 511 288 478 minecraft:terracotta
fill 511 288 479 511 288 482 minecraft:red_terracotta
setblock 511 288 483 minecraft:terracotta
fill 511 288 484 511 288 487 minecraft:red_terracotta
setblock 511 288 488 minecraft:terracotta
fill 511 288 489 511 291 489 minecraft:red_terracotta
setblock 511 288 493 minecraft:terracotta
fill 511 288 494 511 291 494 minecraft:red_terracotta
setblock 511 288 498 minecraft:terracotta
fill 511 288 499 511 291 499 minecraft:red_terracotta
setblock 511 288 503 minecraft:terracotta
fill 511 288 504 511 291 504 minecraft:red_terracotta
fill 471 289 469 471 289 471 minecraft:red_terracotta
setblock 471 289 472 minecraft:terracotta
fill 471 289 473 471 289 476 minecraft:red_terracotta
setblock 471 289 477 minecraft:terracotta
fill 471 289 478 471 289 481 minecraft:red_terracotta
setblock 471 289 482 minecraft:terracotta
fill 471 289 483 471 289 486 minecraft:red_terracotta
setblock 471 289 487 minecraft:terracotta
fill 471 289 488 471 289 491 minecraft:red_terracotta
setblock 471 289 492 minecraft:terracotta
fill 471 289 493 471 289 496 minecraft:red_terracotta
setblock 471 289 497 minecraft:terracotta
fill 471 289 498 471 292 498 minecraft:red_terracotta
setblock 471 289 502 minecraft:terracotta
fill 471 289 503 471 292 503 minecraft:red_terracotta
setblock 472 289 471 minecraft:terracotta
fill 472 289 472 472 289 475 minecraft:red_terracotta
setblock 472 289 476 minecraft:terracotta
fill 472 289 477 472 289 480 minecraft:red_terracotta
setblock 472 289 481 minecraft:terracotta
fill 472 289 482 472 289 485 minecraft:red_terracotta
setblock 472 289 486 minecraft:terracotta
setblock 472 289 490 minecraft:red_terracotta
setblock 472 289 491 minecraft:terracotta
fill 472 289 492 472 289 495 minecraft:red_terracotta
setblock 472 289 496 minecraft:terracotta
fill 472 289 497 472 290 497 minecraft:red_terracotta
setblock 472 289 501 minecraft:terracotta
setblock 473 289 475 minecraft:terracotta
fill 473 289 476 473 289 479 minecraft:red_terracotta
setblock 473 289 480 minecraft:terracotta
fill 473 289 481 473 290 481 minecraft:red_terracotta
fill 485 289 464 488 289 464 minecraft:red_terracotta
fill 485 289 504 488 289 504 minecraft:red_terracotta
setblock 487 289 465 minecraft:red_terracotta
fill 487 289 503 489 289 503 minecraft:red_terracotta
setblock 488 289 465 minecraft:terracotta
setblock 489 289 464 minecraft:terracotta
fill 489 289 465 492 289 465 minecraft:red_terracotta
setblock 489 289 504 minecraft:terracotta
fill 490 289 464 493 289 464 minecraft:red_terracotta
setblock 490 289 503 minecraft:terracotta
fill 490 289 504 493 289 504 minecraft:red_terracotta
setblock 491 289 502 minecraft:terracotta
fill 491 289 503 491 292 503 minecraft:red_terracotta
setblock 494 289 464 minecraft:terracotta
setblock 494 289 504 minecraft:terracotta
setblock 495 289 464 minecraft:red_terracotta
setblock 495 289 503 minecraft:terracotta
fill 495 289 504 498 289 504 minecraft:red_terracotta
setblock 499 289 504 minecraft:terracotta
fill 500 289 504 503 289 504 minecraft:red_terracotta
fill 503 289 503 504 289 503 minecraft:red_terracotta
setblock 504 289 504 minecraft:terracotta
setblock 505 289 503 minecraft:terracotta
fill 505 289 504 505 292 504 minecraft:red_terracotta
setblock 506 289 502 minecraft:terracotta
fill 506 289 503 506 292 503 minecraft:red_terracotta
fill 507 289 502 507 292 502 minecraft:red_terracotta
setblock 508 289 495 minecraft:terracotta
fill 508 289 496 508 290 496 minecraft:red_terracotta
setblock 508 289 499 minecraft:red_terracotta
setblock 508 289 500 minecraft:terracotta
setblock 509 289 494 minecraft:terracotta
fill 509 289 495 509 292 495 minecraft:red_terracotta
setblock 509 289 499 minecraft:terracotta
fill 509 289 500 509 292 500 minecraft:red_terracotta
setblock 509 289 504 minecraft:terracotta
setblock 510 289 473 minecraft:terracotta
fill 510 289 474 510 289 477 minecraft:red_terracotta
setblock 510 289 478 minecraft:terracotta
fill 510 289 479 510 289 482 minecraft:red_terracotta
setblock 510 289 483 minecraft:terracotta
fill 510 289 484 510 289 487 minecraft:red_terracotta
setblock 510 289 488 minecraft:terracotta
fill 510 289 489 510 290 489 minecraft:red_terracotta
setblock 510 289 493 minecraft:terracotta
fill 510 289 494 510 292 494 minecraft:red_terracotta
setblock 510 289 498 minecraft:terracotta
fill 510 289 499 510 292 499 minecraft:red_terracotta
setblock 510 289 503 minecraft:terracotta
fill 510 289 504 510 292 504 minecraft:red_terracotta
fill 511 289 470 511 289 471 minecraft:red_terracotta
setblock 511 289 472 minecraft:terracotta
fill 511 289 473 511 291 473 minecraft:red_terracotta
setblock 511 289 477 minecraft:terracotta
fill 511 289 478 511 289 481 minecraft:red_terracotta
setblock 511 289 482 minecraft:terracotta
fill 511 289 483 511 289 486 minecraft:red_terracotta
setblock 511 289 487 minecraft:terracotta
fill 511 289 488 511 292 488 minecraft:red_terracotta
setblock 511 289 492 minecraft:terracotta
fill 511 289 493 511 292 493 minecraft:red_terracotta
setblock 511 289 497 minecraft:terracotta
fill 511 289 498 511 292 498 minecraft:red_terracotta
setblock 511 289 502 minecraft:terracotta
fill 511 289 503 511 292 503 minecraft:red_terracotta
setblock 471 290 470 minecraft:red_terracotta
setblock 471 290 471 minecraft:terracotta
fill 471 290 472 471 290 475 minecraft:red_terracotta
setblock 471 290 476 minecraft:terracotta
fill 471 290 477 471 290 480 minecraft:red_terracotta
setblock 471 290 481 minecraft:terracotta
fill 471 290 482 471 290 485 minecraft:red_terracotta
setblock 471 290 486 minecraft:terracotta
fill 471 290 487 471 290 490 minecraft:red_terracotta
setblock 471 290 491 minecraft:terracotta
fill 471 290 492 471 290 495 minecraft:red_terracotta
setblock 471 290 496 minecraft:terracotta
fill 471 290 497 471 293 497 minecraft:red_terracotta
setblock 471 290 501 minecraft:terracotta
fill 471 290 502 471 293 502 minecraft:red_terracotta
fill 472 290 472 472 290 474 minecraft:red_terracotta
setblock 472 290 475 minecraft:terracotta
fill 472 290 476 472 290 479 minecraft:red_terracotta
setblock 472 290 480 minecraft:terracotta
fill 472 290 481 472 290 484 minecraft:red_terracotta
setblock 472 290 485 minecraft:terracotta
setblock 472 290 494 minecraft:red_terracotta
setblock 472 290 495 minecraft:terracotta
setblock 472 290 496 minecraft:red_terracotta
setblock 472 290 500 minecraft:terracotta
fill 473 290 475 473 290 478 minecraft:red_terracotta
setblock 473 290 479 minecraft:terracotta
fill 473 290 480 473 293 480 minecraft:red_terracotta
fill 484 290 464 487 290 464 minecraft:red_terracotta
fill 485 290 504 487 290 504 minecraft:red_terracotta
setblock 487 290 465 minecraft:terracotta
fill 487 290 503 488 290 503 minecraft:red_terracotta
setblock 488 290 464 minecraft:terracotta
fill 488 290 465 491 290 465 minecraft:red_terracotta
setblock 488 290 504 minecraft:terracotta
fill 489 290 464 492 290 464 minecraft:red_terracotta
setblock 489 290 503 minecraft:terracotta
fill 489 290 504 492 290 504 minecraft:red_terracotta
setblock 490 290 502 minecraft:terracotta
fill 490 290 503 490 293 503 minecraft:red_terracotta
fill 491 290 502 491 293 502 minecraft:red_terracotta
setblock 493 290 464 minecraft:terracotta
setblock 493 290 504 minecraft:terracotta
fill 494 290 464 494 293 464 minecraft:red_terracotta
setblock 494 290 503 minecraft:terracotta
fill 494 290 504 497 290 504 minecraft:red_terracotta
fill 495 290 503 495 293 503 minecraft:red_terracotta
setblock 498 290 504 minecraft:terracotta
fill 499 290 504 502 290 504 minecraft:red_terracotta
setblock 503 290 503 minecraft:red_terracotta
setblock 503 290 504 minecraft:terracotta
setblock 504 290 503 minecraft:terracotta
fill 504 290 504 504 293 504 minecraft:red_terracotta
setblock 505 290 502 minecraft:terracotta
fill 505 290 503 505 293 503 minecraft:red_terracotta
fill 506 290 502 506 293 502 minecraft:red_terracotta
setblock 508 290 499 minecraft:terracotta
fill 508 290 500 508 291 500 minecraft:red_terracotta
setblock 508 290 504 minecraft:terracotta
setblock 509 290 493 minecraft:terracotta
fill 509 290 494 509 291 494 minecraft:red_terracotta
setblock 509 290 498 minecraft:terracotta
fill 509 290 499 509 293 499 minecraft:red_terracotta
setblock 509 290 503 minecraft:terracotta
fill 509 290 504 509 293 504 minecraft:red_terracotta
fill 510 290 474 510 290 476 minecraft:red_terracotta
setblock 510 290 477 minecraft:terracotta
fill 510 290 478 510 290 481 minecraft:red_terracotta
setblock 510 290 482 minecraft:terracotta
fill 510 290 483 510 290 486 minecraft:red_terracotta
setblock 510 290 488 minecraft:red_terracotta
setblock 510 290 492 minecraft:terracotta
fill 510 290 493 510 293 493 minecraft:red_terracotta
setblock 510 290 497 minecraft:terracotta
fill 510 290 498 510 293 498 minecraft:red_terracotta
setblock 510 290 502 minecraft:terracotta
fill 510 290 503 510 293 503 minecraft:red_terracotta
setblock 511 290 472 minecraft:red_terracotta
setblock 511 290 476 minecraft:terracotta
fill 511 290 477 511 290 480 minecraft:red_terracotta
setblock 511 290 481 minecraft:terracotta
fill 511 290 482 511 290 485 minecraft:red_terracotta
setblock 511 290 486 minecraft:terracotta
fill 511 290 487 511 293 487 minecraft:red_terracotta
setblock 511 290 491 minecraft:terracotta
fill 511 290 492 511 293 492 minecraft:red_terracotta
setblock 511 290 496 minecraft:terracotta
fill 511 290 497 511 293 497 minecraft:red_terracotta
setblock 511 290 501 minecraft:terracotta
fill 511 290 502 511 293 502 minecraft:red_terracotta
fill 471 291 471 471 291 474 minecraft:red_terracotta
setblock 471 291 475 minecraft:terracotta
fill 471 291 476 471 291 479 minecraft:red_terracotta
setblock 471 291 480 minecraft:terracotta
fill 471 291 481 471 291 484 minecraft:red_terracotta
setblock 471 291 485 minecraft:terracotta
fill 471 291 486 471 291 489 minecraft:red_terracotta
setblock 471 291 490 minecraft:terracotta
fill 471 291 491 471 291 494 minecraft:red_terracotta
setblock 471 291 495 minecraft:terracotta
fill 471 291 496 471 294 496 minecraft:red_terracotta
setblock 471 291 500 minecraft:terracotta
fill 471 291 501 471 294 501 minecraft:red_terracotta
setblock 472 291 473 minecraft:red_terracotta
setblock 472 291 474 minecraft:terracotta
fill 472 291 475 472 291 478 minecraft:red_terracotta
setblock 472 291 479 minecraft:terracotta
fill 472 291 480 472 291 483 minecraft:red_terracotta
setblock 472 291 484 minecraft:terracotta
setblock 473 291 477 minecraft:red_terracotta
setblock 473 291 478 minecraft:terracotta
fill 473 291 479 473 293 479 minecraft:red_terracotta
fill 484 291 464 486 291 464 minecraft:red_terracotta
fill 484 291 504 486 291 504 minecraft:red_terracotta
fill 486 291 503 487 291 503 minecraft:red_terracotta
setblock 487 291 464 minecraft:terracotta
fill 487 291 465 490 291 465 minecraft:red_terracotta
setblock 487 291 504 minecraft:terracotta
fill 488 291 464 491 291 464 minecraft:red_terracotta
setblock 488 291 503 minecraft:terracotta
fill 488 291 504 491 291 504 minecraft:red_terracotta
setblock 489 291 502 minecraft:terracotta
fill 489 291 503 489 294 503 minecraft:red_terracotta
fill 490 291 502 490 294 502 minecraft:red_terracotta
setblock 492 291 464 minecraft:terracotta
setblock 492 291 504 minecraft:terracotta
fill 493 291 464 493 294 464 minecraft:red_terracotta
setblock 493 291 503 minecraft:terracotta
fill 493 291 504 496 291 504 minecraft:red_terracotta
fill 494 291 503 494 294 503 minecraft:red_terracotta
setblock 497 291 504 minecraft:terracotta
fill 498 291 504 501 291 504 minecraft:red_terracotta
setblock 502 291 503 minecraft:red_terracotta
setblock 502 291 504 minecraft:terracotta
setblock 503 291 503 minecraft:terracotta
fill 503 291 504 503 294 504 minecraft:red_terracotta
fill 504 291 503 504 294 503 minecraft:red_terracotta
fill 505 291 502 505 294 502 minecraft:red_terracotta
setblock 507 291 504 minecraft:terracotta
setblock 508 291 498 minecraft:terracotta
fill 508 291 499 508 292 499 minecraft:red_terracotta
setblock 508 291 503 minecraft:terracotta
fill 508 291 504 508 294 504 minecraft:red_terracotta
setblock 509 291 497 minecraft:terracotta
fill 509 291 498 509 294 498 minecraft:red_terracotta
setblock 509 291 502 minecraft:terracotta
fill 509 291 503 509 294 503 minecraft:red_terracotta
setblock 510 291 475 minecraft:red_terracotta
setblock 510 291 476 minecraft:terracotta
fill 510 291 477 510 291 480 minecraft:red_terracotta
setblock 510 291 481 minecraft:terracotta
fill 510 291 482 510 291 485 minecraft:red_terracotta
setblock 510 291 486 minecraft:terracotta
setblock 510 291 491 minecraft:terracotta
fill 510 291 492 510 294 492 minecraft:red_terracotta
setblock 510 291 496 minecraft:terracotta
fill 510 291 497 510 294 497 minecraft:red_terracotta
setblock 510 291 501 minecraft:terracotta
fill 510 291 502 510 294 502 minecraft:red_terracotta
setblock 511 291 475 minecraft:terracotta
fill 511 291 476 511 291 479 minecraft:red_terracotta
setblock 511 291 480 minecraft:terracotta
fill 511 291 481 511 291 484 minecraft:red_terracotta
setblock 511 291 485 minecraft:terracotta
fill 511 291 486 511 294 486 minecraft:red_terracotta
setblock 511 291 490 minecraft:terracotta
fill 511 291 491 511 294 491 minecraft:red_terracotta
setblock 511 291 495 minecraft:terracotta
fill 511 291 496 511 294 496 minecraft:red_terracotta
setblock 511 291 500 minecraft:terracotta
fill 511 291 501 511 294 501 minecraft:red_terracotta
fill 471 292 471 471 292 473 minecraft:red_terracotta
setblock 471 292 474 minecraft:terracotta
fill 471 292 475 471 292 478 minecraft:red_terracotta
setblock 471 292 479 minecraft:terracotta
fill 471 292 480 471 292 483 minecraft:red_terracotta
setblock 471 292 484 minecraft:terracotta
fill 471 292 485 471 292 488 minecraft:red_terracotta
setblock 471 292 489 minecraft:terracotta
fill 471 292 490 471 292 493 minecraft:red_terracotta
setblock 471 292 494 minecraft:terracotta
fill 471 292 495 471 293 495 minecraft:red_terracotta
setblock 471 292 499 minecraft:terracotta
fill 471 292 500 471 295 500 minecraft:red_terracotta
setblock 471 292 504 minecraft:terracotta
fill 472 292 474 472 292 477 minecraft:red_terracotta
setblock 472 292 478 minecraft:terracotta
fill 472 292 479 472 292 482 minecraft:red_terracotta
setblock 472 292 483 minecraft:terracotta
fill 472 292 484 472 295 484 minecraft:red_terracotta
setblock 473 292 478 minecraft:red_terracotta
fill 473 292 481 502 293 481 minecraft:terracotta
fill 474 292 480 508 293 480 minecraft:terracotta
fill 483 292 464 485 292 464 minecraft:red_terracotta
fill 483 292 504 485 292 504 minecraft:red_terracotta
fill 485 292 503 486 292 503 minecraft:red_terracotta
setblock 486 292 464 minecraft:terracotta
fill 486 292 465 489 292 465 minecraft:red_terracotta
setblock 486 292 504 minecraft:terracotta
fill 487 292 464 490 292 464 minecraft:red_terracotta
setblock 487 292 503 minecraft:terracotta
fill 487 292 504 490 292 504 minecraft:red_terracotta
setblock 488 292 502 minecraft:terracotta
fill 488 292 503 488 295 503 minecraft:red_terracotta
fill 489 292 502 489 295 502 minecraft:red_terracotta
setblock 490 292 465 minecraft:terracotta
setblock 491 292 464 minecraft:terracotta
setblock 491 292 504 minecraft:terracotta
fill 492 292 464 492 295 464 minecraft:red_terracotta
setblock 492 292 503 minecraft:terracotta
fill 492 292 504 495 292 504 minecraft:red_terracotta
fill 493 292 503 493 295 503 minecraft:red_terracotta
setblock 496 292 504 minecraft:terracotta
fill 497 292 479 509 292 479 minecraft:terracotta
fill 497 292 504 500 292 504 minecraft:red_terracotta
setblock 501 292 503 minecraft:red_terracotta
setblock 501 292 504 minecraft:terracotta
setblock 502 292 503 minecraft:terracotta
fill 502 292 504 502 295 504 minecraft:red_terracotta
fill 503 292 503 503 295 503 minecraft:red_terracotta
fill 504 292 502 504 295 502 minecraft:red_terracotta
setblock 506 292 504 minecraft:terracotta
setblock 507 292 503 minecraft:terracotta
fill 507 292 504 507 295 504 minecraft:red_terracotta
setblock 508 292 502 minecraft:terracotta
fill 508 292 503 508 295 503 minecraft:red_terracotta
setblock 509 292 480 minecraft:red_terracotta
setblock 509 292 481 minecraft:terracotta
setblock 509 292 496 minecraft:terracotta
fill 509 292 497 509 295 497 minecraft:red_terracotta
setblock 509 292 501 minecraft:terracotta
fill 509 292 502 509 295 502 minecraft:red_terracotta
fill 510 292 476 510 292 479 minecraft:red_terracotta
setblock 510 292 480 minecraft:terracotta
fill 510 292 481 510 292 484 minecraft:red_terracotta
setblock 510 292 485 minecraft:terracotta
fill 510 292 486 510 294 487 minecraft:red_terracotta
setblock 510 292 491 minecraft:red_terracotta
setblock 510 292 495 minecraft:terracotta
fill 510 292 496 510 295 496 minecraft:red_terracotta
setblock 510 292 500 minecraft:terracotta
fill 510 292 501 510 295 501 minecraft:red_terracotta
setblock 511 292 474 minecraft:terracotta
fill 511 292 475 511 292 478 minecraft:red_terracotta
setblock 511 292 479 minecraft:terracotta
fill 511 292 480 511 292 483 minecraft:red_terracotta
setblock 511 292 484 minecraft:terracotta
fill 511 292 485 511 295 485 minecraft:red_terracotta
setblock 511 292 489 minecraft:terracotta
fill 511 292 490 511 295 490 minecraft:red_terracotta
setblock 511 292 494 minecraft:terracotta
fill 511 292 495 511 295 495 minecraft:red_terracotta
setblock 511 292 499 minecraft:terracotta
fill 511 292 500 511 295 500 minecraft:red_terracotta
setblock 511 292 504 minecraft:terracotta
setblock 471 293 472 minecraft:red_terracotta
setblock 471 293 473 minecraft:terracotta
fill 471 293 474 471 293 477 minecraft:red_terracotta
setblock 471 293 478 minecraft:terracotta
fill 471 293 479 471 293 482 minecraft:red_terracotta
setblock 471 293 483 minecraft:terracotta
fill 471 293 484 471 293 487 minecraft:red_terracotta
setblock 471 293 488 minecraft:terracotta
fill 471 293 489 471 296 489 minecraft:red_terracotta
setblock 471 293 494 minecraft:red_terracotta
setblock 471 293 498 minecraft:terracotta
fill 471 293 499 471 296 499 minecraft:red_terracotta
setblock 471 293 503 minecraft:terracotta
fill 471 293 504 471 296 504 minecraft:red_terracotta
fill 472 293 475 472 293 476 minecraft:red_terracotta
setblock 472 293 477 minecraft:terracotta
fill 472 293 478 472 293 481 minecraft:red_terracotta
setblock 472 293 482 minecraft:terracotta
fill 472 293 483 472 296 483 minecraft:red_terracotta
fill 472 293 485 472 294 485 minecraft:red_terracotta
setblock 473 293 466 minecraft:light[level=14]
setblock 473 293 474 minecraft:light[level=14]
setblock 473 293 482 minecraft:light[level=14]
setblock 473 293 490 minecraft:light[level=14]
setblock 473 293 498 minecraft:light[level=14]
fill 481 293 464 484 293 464 minecraft:red_terracotta
setblock 481 293 466 minecraft:light[level=14]
setblock 481 293 474 minecraft:light[level=14]
setblock 481 293 482 minecraft:light[level=14]
setblock 481 293 490 minecraft:light[level=14]
setblock 481 293 498 minecraft:light[level=14]
fill 482 293 504 484 293 504 minecraft:red_terracotta
setblock 484 293 465 minecraft:terracotta
fill 484 293 503 485 293 503 minecraft:red_terracotta
setblock 485 293 464 minecraft:terracotta
fill 485 293 465 488 293 465 minecraft:red_terracotta
setblock 485 293 504 minecraft:terracotta
fill 486 293 464 489 293 464 minecraft:red_terracotta
setblock 486 293 502 minecraft:red_terracotta
setblock 486 293 503 minecraft:terracotta
fill 486 293 504 489 293 504 minecraft:red_terracotta
setblock 487 293 502 minecraft:terracotta
fill 487 293 503 487 296 503 minecraft:red_terracotta
fill 488 293 502 488 296 502 minecraft:red_terracotta
setblock 489 293 465 minecraft:terracotta
setblock 489 293 466 minecraft:light[level=14]
setblock 489 293 474 minecraft:light[level=14]
setblock 489 293 482 minecraft:light[level=14]
setblock 489 293 490 minecraft:light[level=14]
setblock 489 293 498 minecraft:light[level=14]
setblock 490 293 464 minecraft:terracotta
fill 490 293 465 490 296 465 minecraft:red_terracotta
setblock 490 293 504 minecraft:terracotta
fill 491 293 464 491 296 464 minecraft:red_terracotta
setblock 491 293 503 minecraft:terracotta
fill 491 293 504 494 293 504 minecraft:red_terracotta
setblock 492 293 502 minecraft:terracotta
fill 492 293 503 492 296 503 minecraft:red_terracotta
setblock 495 293 504 minecraft:terracotta
setblock 496 293 503 minecraft:terracotta
fill 496 293 504 499 293 504 minecraft:red_terracotta
setblock 497 293 466 minecraft:light[level=14]
setblock 497 293 474 minecraft:light[level=14]
fill 497 293 479 508 293 479 minecraft:terracotta
setblock 497 293 482 minecraft:light[level=14]
setblock 497 293 490 minecraft:light[level=14]
setblock 497 293 498 minecraft:light[level=14]
fill 497 293 503 500 293 503 minecraft:red_terracotta
setblock 500 293 504 minecraft:terracotta
setblock 501 293 503 minecraft:terracotta
fill 501 293 504 501 296 504 minecraft:red_terracotta
setblock 502 293 502 minecraft:terracotta
fill 502 293 503 502 296 503 minecraft:red_terracotta
fill 503 293 502 503 296 502 minecraft:red_terracotta
setblock 505 293 466 minecraft:light[level=14]
setblock 505 293 474 minecraft:light[level=14]
setblock 505 293 482 minecraft:light[level=14]
setblock 505 293 490 minecraft:light[level=14]
setblock 505 293 498 minecraft:light[level=14]
setblock 505 293 504 minecraft:terracotta
fill 506 293 464 508 294 464 minecraft:red_terracotta
setblock 506 293 503 minecraft:terracotta
fill 506 293 504 506 296 504 minecraft:red_terracotta
setblock 507 293 502 minecraft:terracotta
fill 507 293 503 507 296 503 minecraft:red_terracotta
fill 508 293 502 508 296 502 minecraft:red_terracotta
setblock 509 293 479 minecraft:red_terracotta
setblock 509 293 480 minecraft:terracotta
fill 509 293 481 510 293 483 minecraft:red_terracotta
fill 509 293 496 509 294 496 minecraft:red_terracotta
setblock 509 293 500 minecraft:terracotta
fill 509 293 501 509 296 501 minecraft:red_terracotta
fill 510 293 476 510 293 478 minecraft:red_terracotta
setblock 510 293 479 minecraft:terracotta
fill 510 293 480 511 295 480 minecraft:red_terracotta
setblock 510 293 484 minecraft:terracotta
fill 510 293 485 510 296 485 minecraft:red_terracotta
setblock 510 293 488 minecraft:red_terracotta
setblock 510 293 494 minecraft:terracotta
fill 510 293 495 510 296 495 minecraft:red_terracotta
setblock 510 293 499 minecraft:terracotta
fill 510 293 500 510 296 500 minecraft:red_terracotta
setblock 510 293 504 minecraft:terracotta
fill 511 293 474 511 293 477 minecraft:red_terracotta
setblock 511 293 478 minecraft:terracotta
fill 511 293 479 511 296 479 minecraft:red_terracotta
fill 511 293 481 511 293 482 minecraft:red_terracotta
setblock 511 293 483 minecraft:terracotta
fill 511 293 484 511 296 484 minecraft:red_terracotta
setblock 511 293 488 minecraft:terracotta
fill 511 293 489 511 296 489 minecraft:red_terracotta
setblock 511 293 493 minecraft:terracotta
fill 511 293 494 511 296 494 minecraft:red_terracotta
setblock 511 293 498 minecraft:terracotta
fill 511 293 499 511 296 499 minecraft:red_terracotta
setblock 511 293 503 minecraft:terracotta
fill 511 293 504 511 296 504 minecraft:red_terracotta
setblock 471 294 472 minecraft:terracotta
fill 471 294 473 471 294 476 minecraft:red_terracotta
setblock 471 294 477 minecraft:terracotta
fill 471 294 478 471 294 481 minecraft:red_terracotta
setblock 471 294 482 minecraft:terracotta
fill 471 294 483 471 294 486 minecraft:red_terracotta
setblock 471 294 487 minecraft:terracotta
fill 471 294 488 471 297 488 minecraft:red_terracotta
setblock 471 294 497 minecraft:terracotta
fill 471 294 498 471 295 498 minecraft:red_terracotta
setblock 471 294 502 minecraft:terracotta
fill 471 294 503 471 297 503 minecraft:red_terracotta
setblock 472 294 475 minecraft:red_terracotta
setblock 472 294 476 minecraft:terracotta
fill 472 294 477 472 294 480 minecraft:red_terracotta
setblock 472 294 481 minecraft:terracotta
fill 472 294 482 472 297 482 minecraft:red_terracotta
setblock 473 294 480 minecraft:terracotta
fill 473 294 481 484 294 481 minecraft:orange_concrete
fill 480 294 464 483 294 464 minecraft:red_terracotta
fill 480 294 504 483 294 504 minecraft:red_terracotta
fill 482 294 480 508 294 480 minecraft:orange_concrete
setblock 483 294 465 minecraft:terracotta
fill 483 294 503 484 294 503 minecraft:red_terracotta
setblock 484 294 464 minecraft:terracotta
fill 484 294 465 487 294 465 minecraft:red_terracotta
setblock 484 294 504 minecraft:terracotta
fill 485 294 464 488 294 464 minecraft:red_terracotta
setblock 485 294 502 minecraft:red_terracotta
setblock 485 294 503 minecraft:terracotta
fill 485 294 504 488 294 504 minecraft:red_terracotta
setblock 486 294 502 minecraft:terracotta
fill 486 294 503 486 297 503 minecraft:red_terracotta
fill 487 294 502 487 297 502 minecraft:red_terracotta
setblock 488 294 465 minecraft:terracotta
setblock 489 294 464 minecraft:terracotta
fill 489 294 465 489 297 465 minecraft:red_terracotta
setblock 489 294 504 minecraft:terracotta
fill 490 294 464 490 297 464 minecraft:red_terracotta
setblock 490 294 503 minecraft:terracotta
fill 490 294 504 493 294 504 minecraft:red_terracotta
fill 491 294 465 491 295 465 minecraft:red_terracotta
setblock 491 294 502 minecraft:terracotta
fill 491 294 503 491 297 503 minecraft:red_terracotta
fill 492 294 502 492 297 502 minecraft:red_terracotta
setblock 494 294 464 minecraft:terracotta
setblock 494 294 504 minecraft:terracotta
setblock 495 294 503 minecraft:terracotta
fill 495 294 504 498 294 504 minecraft:red_terracotta
fill 496 294 503 499 294 503 minecraft:red_terracotta
setblock 499 294 504 minecraft:terracotta
setblock 500 294 503 minecraft:terracotta
fill 500 294 504 500 297 504 minecraft:red_terracotta
setblock 501 294 502 minecraft:terracotta
fill 501 294 503 501 297 503 minecraft:red_terracotta
fill 502 294 502 502 297 502 minecraft:red_terracotta
setblock 503 294 464 minecraft:red_terracotta
setblock 504 294 464 minecraft:terracotta
setblock 504 294 504 minecraft:terracotta
fill 505 294 464 505 297 464 minecraft:red_terracotta
fill 505 294 501 506 294 501 minecraft:red_terracotta
setblock 505 294 503 minecraft:terracotta
fill 505 294 504 505 297 504 minecraft:red_terracotta
setblock 506 294 502 minecraft:terracotta
fill 506 294 503 506 297 503 minecraft:red_terracotta
setblock 507 294 501 minecraft:terracotta
fill 507 294 502 507 297 502 minecraft:red_terracotta
setblock 509 294 464 minecraft:terracotta
setblock 509 294 479 minecraft:terracotta
fill 509 294 480 509 294 483 minecraft:red_terracotta
setblock 509 294 484 minecraft:terracotta
fill 509 294 485 509 297 485 minecraft:red_terracotta
setblock 509 294 499 minecraft:terracotta
fill 509 294 500 509 297 500 minecraft:red_terracotta
setblock 509 294 504 minecraft:terracotta
fill 510 294 476 510 294 477 minecraft:red_terracotta
setblock 510 294 478 minecraft:terracotta
fill 510 294 479 510 297 479 minecraft:red_terracotta
fill 510 294 481 510 294 482 minecraft:red_terracotta
setblock 510 294 483 minecraft:terracotta
fill 510 294 484 510 297 484 minecraft:red_terracotta
setblock 510 294 488 minecraft:terracotta
fill 510 294 489 510 296 490 minecraft:red_terracotta
setblock 510 294 493 minecraft:terracotta
fill 510 294 494 510 295 494 minecraft:red_terracotta
setblock 510 294 498 minecraft:terracotta
fill 510 294 499 510 297 499 minecraft:red_terracotta
setblock 510 294 503 minecraft:terracotta
fill 510 294 504 510 297 504 minecraft:red_terracotta
fill 511 294 474 511 294 476 minecraft:red_terracotta
setblock 511 294 477 minecraft:terracotta
fill 511 294 478 511 297 478 minecraft:red_terracotta
setblock 511 294 481 minecraft:red_terracotta
setblock 511 294 482 minecraft:terracotta
fill 511 294 483 511 297 483 minecraft:red_terracotta
setblock 511 294 487 minecraft:terracotta
fill 511 294 488 511 297 488 minecraft:red_terracotta
setblock 511 294 492 minecraft:terracotta
fill 511 294 493 511 297 493 minecraft:red_terracotta
setblock 511 294 497 minecraft:terracotta
fill 511 294 498 511 297 498 minecraft:red_terracotta
setblock 511 294 502 minecraft:terracotta
fill 511 294 503 511 297 503 minecraft:red_terracotta
fill 471 295 464 471 296 464 minecraft:red_terracotta
fill 471 295 472 471 295 475 minecraft:red_terracotta
setblock 471 295 476 minecraft:terracotta
fill 471 295 477 471 295 480 minecraft:red_terracotta
setblock 471 295 481 minecraft:terracotta
fill 471 295 482 471 295 485 minecraft:red_terracotta
setblock 471 295 486 minecraft:terracotta
fill 471 295 487 471 298 487 minecraft:red_terracotta
setblock 471 295 501 minecraft:terracotta
fill 471 295 502 471 298 502 minecraft:red_terracotta
setblock 472 295 475 minecraft:terracotta
fill 472 295 476 472 295 479 minecraft:red_terracotta
setblock 472 295 480 minecraft:terracotta
fill 472 295 481 473 297 481 minecraft:red_terracotta
setblock 472 295 485 minecraft:terracotta
setblock 472 295 504 minecraft:red_terracotta
fill 473 295 480 473 296 480 minecraft:red_terracotta
setblock 478 295 464 minecraft:terracotta
fill 479 295 464 482 295 464 minecraft:red_terracotta
fill 479 295 504 482 295 504 minecraft:red_terracotta
setblock 481 295 465 minecraft:red_terracotta
fill 481 295 503 483 295 503 minecraft:red_terracotta
setblock 482 295 465 minecraft:terracotta
setblock 483 295 464 minecraft:terracotta
fill 483 295 465 486 295 465 minecraft:red_terracotta
setblock 483 295 504 minecraft:terracotta
fill 484 295 464 487 295 464 minecraft:red_terracotta
setblock 484 295 502 minecraft:red_terracotta
setblock 484 295 503 minecraft:terracotta
fill 484 295 504 487 295 504 minecraft:red_terracotta
setblock 485 295 466 minecraft:red_terracotta
setblock 485 295 502 minecraft:terracotta
fill 485 295 503 485 298 503 minecraft:red_terracotta
setblock 486 295 466 minecraft:terracotta
fill 486 295 502 486 298 502 minecraft:red_terracotta
setblock 487 295 465 minecraft:terracotta
fill 487 295 466 488 297 466 minecraft:red_terracotta
setblock 488 295 464 minecraft:terracotta
fill 488 295 465 488 298 465 minecraft:red_terracotta
setblock 488 295 504 minecraft:terracotta
fill 489 295 464 489 298 464 minecraft:red_terracotta
setblock 489 295 503 minecraft:terracotta
fill 489 295 504 492 295 504 minecraft:red_terracotta
setblock 490 295 502 minecraft:terracotta
fill 490 295 503 490 298 503 minecraft:red_terracotta
fill 491 295 502 491 298 502 minecraft:red_terracotta
setblock 493 295 464 minecraft:terracotta
setblock 493 295 504 minecraft:terracotta
fill 494 295 464 496 296 464 minecraft:red_terracotta
setblock 494 295 503 minecraft:terracotta
fill 494 295 504 497 295 504 minecraft:red_terracotta
fill 495 295 503 498 295 503 minecraft:red_terracotta
setblock 498 295 504 minecraft:terracotta
setblock 499 295 503 minecraft:terracotta
fill 499 295 504 499 298 504 minecraft:red_terracotta
fill 500 295 464 502 295 464 minecraft:red_terracotta
setblock 500 295 502 minecraft:terracotta
fill 500 295 503 500 298 503 minecraft:red_terracotta
fill 501 295 502 501 298 502 minecraft:red_terracotta
setblock 503 295 464 minecraft:terracotta
setblock 503 295 504 minecraft:terracotta
fill 504 295 464 504 298 464 minecraft:red_terracotta
fill 504 295 501 505 295 501 minecraft:red_terracotta
setblock 504 295 503 minecraft:terracotta
fill 504 295 504 504 298 504 minecraft:red_terracotta
setblock 505 295 502 minecraft:terracotta
fill 505 295 503 505 298 503 minecraft:red_terracotta
fill 506 295 464 507 295 464 minecraft:red_terracotta
setblock 506 295 501 minecraft:terracotta
fill 506 295 502 506 298 502 minecraft:red_terracotta
fill 507 295 501 507 296 501 minecraft:red_terracotta
setblock 508 295 464 minecraft:terracotta
setblock 508 295 504 minecraft:terracotta
fill 509 295 464 510 297 464 minecraft:red_terracotta
setblock 509 295 478 minecraft:terracotta
fill 509 295 479 509 295 482 minecraft:red_terracotta
setblock 509 295 483 minecraft:terracotta
fill 509 295 484 509 298 484 minecraft:red_terracotta
fill 509 295 486 509 295 487 minecraft:red_terracotta
setblock 509 295 498 minecraft:terracotta
fill 509 295 499 509 296 499 minecraft:red_terracotta
setblock 509 295 503 minecraft:terracotta
fill 509 295 504 509 298 504 minecraft:red_terracotta
setblock 510 295 476 minecraft:red_terracotta
setblock 510 295 477 minecraft:terracotta
fill 510 295 478 510 298 478 minecraft:red_terracotta
setblock 510 295 481 minecraft:red_terracotta
setblock 510 295 482 minecraft:terracotta
fill 510 295 483 510 298 483 minecraft:red_terracotta
setblock 510 295 486 minecraft:red_terracotta
setblock 510 295 487 minecraft:terracotta
fill 510 295 488 510 298 488 minecraft:red_terracotta
setblock 510 295 491 minecraft:red_terracotta
setblock 510 295 493 minecraft:red_terracotta
setblock 510 295 497 minecraft:terracotta
fill 510 295 498 510 297 498 minecraft:red_terracotta
setblock 510 295 502 minecraft:terracotta
fill 510 295 503 510 298 503 minecraft:red_terracotta
setblock 511 295 475 minecraft:red_terracotta
setblock 511 295 476 minecraft:terracotta
fill 511 295 477 511 298 477 minecraft:red_terracotta
setblock 511 295 481 minecraft:terracotta
fill 511 295 482 511 298 482 minecraft:red_terracotta
setblock 511 295 486 minecraft:terracotta
fill 511 295 487 511 298 487 minecraft:red_terracotta
setblock 511 295 491 minecraft:terracotta
fill 511 295 492 511 298 492 minecraft:red_terracotta
setblock 511 295 496 minecraft:terracotta
fill 511 295 497 511 298 497 minecraft:red_terracotta
setblock 511 295 501 minecraft:terracotta
fill 511 295 502 511 298 502 minecraft:red_terracotta
setblock 471 296 465 minecraft:terracotta
fill 471 296 466 471 299 466 minecraft:red_terracotta
fill 471 296 472 471 296 474 minecraft:red_terracotta
setblock 471 296 475 minecraft:terracotta
fill 471 296 476 471 296 479 minecraft:red_terracotta
setblock 471 296 480 minecraft:terracotta
fill 471 296 481 471 296 484 minecraft:red_terracotta
setblock 471 296 485 minecraft:terracotta
fill 471 296 486 472 298 486 minecraft:red_terracotta
setblock 471 296 500 minecraft:terracotta
fill 471 296 501 471 298 501 minecraft:red_terracotta
setblock 472 296 464 minecraft:terracotta
fill 472 296 476 472 296 478 minecraft:red_terracotta
setblock 472 296 479 minecraft:terracotta
fill 472 296 480 472 299 480 minecraft:red_terracotta
setblock 472 296 484 minecraft:terracotta
fill 472 296 485 472 299 485 minecraft:red_terracotta
setblock 472 296 504 minecraft:terracotta
fill 473 296 464 476 296 464 minecraft:red_terracotta
setblock 477 296 464 minecraft:terracotta
setblock 477 296 504 minecraft:terracotta
fill 478 296 464 481 296 464 minecraft:red_terracotta
fill 478 296 504 481 296 504 minecraft:red_terracotta
fill 479 296 465 480 296 465 minecraft:red_terracotta
fill 480 296 503 482 296 503 minecraft:red_terracotta
setblock 481 296 465 minecraft:terracotta
setblock 482 296 464 minecraft:terracotta
fill 482 296 465 485 296 465 minecraft:red_terracotta
setblock 482 296 504 minecraft:terracotta
fill 483 296 464 486 296 464 minecraft:red_terracotta
fill 483 296 466 484 296 466 minecraft:red_terracotta
setblock 483 296 502 minecraft:red_terracotta
setblock 483 296 503 minecraft:terracotta
fill 483 296 504 486 296 504 minecraft:red_terracotta
setblock 484 296 502 minecraft:terracotta
fill 484 296 503 484 299 503 minecraft:red_terracotta
setblock 485 296 466 minecraft:terracotta
fill 485 296 502 485 299 502 minecraft:red_terracotta
setblock 486 296 465 minecraft:terracotta
fill 486 296 466 486 299 466 minecraft:red_terracotta
setblock 487 296 464 minecraft:terracotta
fill 487 296 465 487 299 465 minecraft:red_terracotta
setblock 487 296 504 minecraft:terracotta
fill 488 296 464 488 299 464 minecraft:red_terracotta
setblock 488 296 503 minecraft:terracotta
fill 488 296 504 491 296 504 minecraft:red_terracotta
setblock 489 296 502 minecraft:terracotta
fill 489 296 503 489 299 503 minecraft:red_terracotta
fill 490 296 502 490 299 502 minecraft:red_terracotta
setblock 491 296 465 minecraft:terracotta
setblock 492 296 464 minecraft:terracotta
fill 492 296 465 492 299 465 minecraft:red_terracotta
fill 492 296 469 494 297 470 minecraft:magma_block
setblock 492 296 504 minecraft:terracotta
fill 493 296 464 493 299 464 minecraft:red_terracotta
setblock 493 296 502 minecraft:red_terracotta
setblock 493 296 503 minecraft:terracotta
fill 493 296 504 496 296 504 minecraft:red_terracotta
fill 494 296 503 497 296 503 minecraft:red_terracotta
setblock 497 296 464 minecraft:terracotta
setblock 497 296 504 minecraft:terracotta
fill 498 296 464 501 296 464 minecraft:red_terracotta
setblock 498 296 502 minecraft:red_terracotta
setblock 498 296 503 minecraft:terracotta
fill 498 296 504 498 299 504 minecraft:red_terracotta
setblock 499 296 502 minecraft:terracotta
fill 499 296 503 499 299 503 minecraft:red_terracotta
fill 500 296 502 500 299 502 minecraft:red_terracotta
setblock 502 296 464 minecraft:terracotta
setblock 502 296 504 minecraft:terracotta
fill 503 296 464 503 299 464 minecraft:red_terracotta
fill 503 296 501 504 296 501 minecraft:red_terracotta
setblock 503 296 503 minecraft:terracotta
fill 503 296 504 503 299 504 minecraft:red_terracotta
setblock 504 296 502 minecraft:terracotta
fill 504 296 503 504 299 503 minecraft:red_terracotta
setblock 505 296 501 minecraft:terracotta
fill 505 296 502 505 299 502 minecraft:red_terracotta
setblock 506 296 464 minecraft:red_terracotta
fill 506 296 501 506 298 501 minecraft:red_terracotta
setblock 507 296 464 minecraft:terracotta
setblock 507 296 504 minecraft:terracotta
fill 508 296 464 508 299 464 minecraft:red_terracotta
fill 508 296 481 508 296 482 minecraft:red_terracotta
setblock 508 296 483 minecraft:terracotta
fill 508 296 484 508 298 485 minecraft:red_terracotta
setblock 508 296 503 minecraft:terracotta
fill 508 296 504 508 299 504 minecraft:red_terracotta
fill 509 296 478 509 296 481 minecraft:red_terracotta
setblock 509 296 482 minecraft:terracotta
fill 509 296 483 509 299 483 minecraft:red_terracotta
setblock 509 296 486 minecraft:red_terracotta
setblock 509 296 487 minecraft:terracotta
fill 509 296 488 509 299 488 minecraft:red_terracotta
setblock 509 296 498 minecraft:red_terracotta
setblock 509 296 502 minecraft:terracotta
fill 509 296 503 509 299 503 minecraft:red_terracotta
fill 510 296 477 510 298 477 minecraft:red_terracotta
setblock 510 296 480 minecraft:red_terracotta
setblock 510 296 481 minecraft:terracotta
fill 510 296 482 510 299 482 minecraft:red_terracotta
setblock 510 296 486 minecraft:terracotta
fill 510 296 487 510 299 487 minecraft:red_terracotta
setblock 510 296 491 minecraft:terracotta
fill 510 296 492 510 298 492 minecraft:red_terracotta
setblock 510 296 496 minecraft:terracotta
fill 510 296 497 510 297 497 minecraft:red_terracotta
setblock 510 296 501 minecraft:terracotta
fill 510 296 502 510 299 502 minecraft:red_terracotta
setblock 511 296 464 minecraft:red_terracotta
setblock 511 296 475 minecraft:terracotta
fill 511 296 476 511 299 476 minecraft:red_terracotta
setblock 511 296 480 minecraft:terracotta
fill 511 296 481 511 299 481 minecraft:red_terracotta
setblock 511 296 485 minecraft:terracotta
fill 511 296 486 511 299 486 minecraft:red_terracotta
setblock 511 296 490 minecraft:terracotta
fill 511 296 491 511 299 491 minecraft:red_terracotta
setblock 511 296 495 minecraft:terracotta
fill 511 296 496 511 298 496 minecraft:red_terracotta
setblock 511 296 500 minecraft:terracotta
fill 511 296 501 511 299 501 minecraft:red_terracotta
setblock 471 297 464 minecraft:terracotta
fill 471 297 465 471 300 465 minecraft:red_terracotta
fill 471 297 467 471 297 468 minecraft:red_terracotta
setblock 471 297 469 minecraft:terracotta
fill 471 297 470 471 297 473 minecraft:red_terracotta
setblock 471 297 474 minecraft:terracotta
fill 471 297 475 471 297 478 minecraft:red_terracotta
setblock 471 297 479 minecraft:terracotta
fill 471 297 480 471 297 483 minecraft:red_terracotta
setblock 471 297 484 minecraft:terracotta
fill 471 297 485 471 300 485 minecraft:red_terracotta
setblock 471 297 489 minecraft:terracotta
fill 471 297 490 471 300 490 minecraft:red_terracotta
setblock 471 297 500 minecraft:red_terracotta
setblock 471 297 504 minecraft:terracotta
fill 472 297 464 475 297 464 minecraft:red_terracotta
fill 472 297 476 472 297 477 minecraft:red_terracotta
setblock 472 297 478 minecraft:terracotta
fill 472 297 479 472 300 479 minecraft:red_terracotta
setblock 472 297 483 minecraft:terracotta
fill 472 297 484 472 300 484 minecraft:red_terracotta
fill 472 297 504 475 297 504 minecraft:red_terracotta
setblock 473 297 482 minecraft:terracotta
setblock 476 297 464 minecraft:terracotta
setblock 476 297 504 minecraft:terracotta
fill 477 297 464 480 297 464 minecraft:red_terracotta
fill 477 297 504 480 297 504 minecraft:red_terracotta
fill 478 297 465 479 297 465 minecraft:red_terracotta
fill 479 297 503 481 297 503 minecraft:red_terracotta
setblock 480 297 465 minecraft:terracotta
setblock 481 297 464 minecraft:terracotta
fill 481 297 465 483 297 466 minecraft:red_terracotta
setblock 481 297 504 minecraft:terracotta
fill 482 297 464 485 297 464 minecraft:red_terracotta
setblock 482 297 502 minecraft:red_terracotta
setblock 482 297 503 minecraft:terracotta
fill 482 297 504 485 297 504 minecraft:red_terracotta
setblock 483 297 502 minecraft:terracotta
fill 483 297 503 483 300 503 minecraft:red_terracotta
setblock 484 297 465 minecraft:red_terracotta
setblock 484 297 466 minecraft:terracotta
fill 484 297 502 484 300 502 minecraft:red_terracotta
setblock 485 297 465 minecraft:terracotta
fill 485 297 466 485 300 466 minecraft:red_terracotta
setblock 486 297 464 minecraft:terracotta
fill 486 297 465 486 300 465 minecraft:red_terracotta
setblock 486 297 504 minecraft:terracotta
fill 487 297 464 487 300 464 minecraft:red_terracotta
setblock 487 297 503 minecraft:terracotta
fill 487 297 504 490 297 504 minecraft:red_terracotta
setblock 488 297 502 minecraft:terracotta
fill 488 297 503 488 300 503 minecraft:red_terracotta
setblock 489 297 466 minecraft:terracotta
fill 489 297 502 489 300 502 minecraft:red_terracotta
setblock 490 297 465 minecraft:terracotta
setblock 491 297 464 minecraft:terracotta
fill 491 297 465 491 300 465 minecraft:red_terracotta
setblock 491 297 504 minecraft:terracotta
fill 492 297 464 492 300 464 minecraft:red_terracotta
setblock 492 297 503 minecraft:terracotta
fill 492 297 504 495 297 504 minecraft:red_terracotta
setblock 493 297 502 minecraft:terracotta
fill 493 297 503 496 297 503 minecraft:red_terracotta
fill 494 297 464 495 297 464 minecraft:red_terracotta
setblock 496 297 464 minecraft:terracotta
setblock 496 297 504 minecraft:terracotta
fill 497 297 464 500 297 464 minecraft:red_terracotta
setblock 497 297 502 minecraft:red_terracotta
setblock 497 297 503 minecraft:terracotta
fill 497 297 504 497 300 504 minecraft:red_terracotta
setblock 498 297 502 minecraft:terracotta
fill 498 297 503 498 300 503 minecraft:red_terracotta
fill 499 297 502 499 300 502 minecraft:red_terracotta
setblock 501 297 464 minecraft:terracotta
setblock 501 297 504 minecraft:terracotta
fill 502 297 464 502 299 465 minecraft:red_terracotta
fill 502 297 501 503 297 501 minecraft:red_terracotta
setblock 502 297 503 minecraft:terracotta
fill 502 297 504 502 300 504 minecraft:red_terracotta
fill 503 297 465 504 297 465 minecraft:red_terracotta
setblock 503 297 502 minecraft:terracotta
fill 503 297 503 503 300 503 minecraft:red_terracotta
setblock 504 297 501 minecraft:terracotta
fill 504 297 502 504 300 502 minecraft:red_terracotta
setblock 505 297 465 minecraft:terracotta
fill 505 297 501 505 298 501 minecraft:red_terracotta
setblock 506 297 464 minecraft:terracotta
fill 506 297 465 507 299 465 minecraft:red_terracotta
setblock 506 297 504 minecraft:terracotta
fill 507 297 464 507 300 464 minecraft:red_terracotta
setblock 507 297 503 minecraft:terracotta
fill 507 297 504 507 300 504 minecraft:red_terracotta
setblock 508 297 481 minecraft:red_terracotta
setblock 508 297 482 minecraft:terracotta
fill 508 297 483 508 300 483 minecraft:red_terracotta
setblock 508 297 486 minecraft:red_terracotta
setblock 508 297 502 minecraft:terracotta
fill 508 297 503 508 300 503 minecraft:red_terracotta
fill 509 297 479 509 297 480 minecraft:red_terracotta
setblock 509 297 481 minecraft:terracotta
fill 509 297 482 509 300 482 minecraft:red_terracotta
setblock 509 297 486 minecraft:terracotta
fill 509 297 487 509 300 487 minecraft:red_terracotta
fill 509 297 489 510 297 489 minecraft:red_terracotta
setblock 509 297 501 minecraft:terracotta
fill 509 297 502 509 298 502 minecraft:red_terracotta
setblock 510 297 480 minecraft:terracotta
fill 510 297 481 510 300 481 minecraft:red_terracotta
setblock 510 297 485 minecraft:terracotta
fill 510 297 486 510 300 486 minecraft:red_terracotta
setblock 510 297 490 minecraft:terracotta
fill 510 297 491 510 300 491 minecraft:red_terracotta
setblock 510 297 500 minecraft:terracotta
fill 510 297 501 510 298 501 minecraft:red_terracotta
setblock 511 297 464 minecraft:terracotta
fill 511 297 465 511 300 465 minecraft:red_terracotta
fill 511 297 475 511 298 475 minecraft:red_terracotta
setblock 511 297 479 minecraft:terracotta
fill 511 297 480 511 300 480 minecraft:red_terracotta
setblock 511 297 484 minecraft:terracotta
fill 511 297 485 511 300 485 minecraft:red_terracotta
setblock 511 297 489 minecraft:terracotta
fill 511 297 490 511 300 490 minecraft:red_terracotta
setblock 511 297 494 minecraft:terracotta
fill 511 297 495 511 298 495 minecraft:red_terracotta
setblock 511 297 499 minecraft:terracotta
fill 511 297 500 511 299 500 minecraft:red_terracotta
setblock 511 297 504 minecraft:terracotta
fill 471 298 464 474 298 464 minecraft:red_terracotta
setblock 471 298 467 minecraft:red_terracotta
setblock 471 298 468 minecraft:terracotta
fill 471 298 469 471 298 472 minecraft:red_terracotta
setblock 471 298 473 minecraft:terracotta
fill 471 298 474 471 298 477 minecraft:red_terracotta
setblock 471 298 478 minecraft:terracotta
fill 471 298 479 471 298 482 minecraft:red_terracotta
setblock 471 298 483 minecraft:terracotta
fill 471 298 484 471 300 484 minecraft:red_terracotta
setblock 471 298 488 minecraft:terracotta
fill 471 298 489 471 300 489 minecraft:red_terracotta
setblock 471 298 503 minecraft:terracotta
fill 471 298 504 474 298 504 minecraft:red_terracotta
setblock 472 298 477 minecraft:terracotta
fill 472 298 478 472 299 478 minecraft:red_terracotta
setblock 472 298 481 minecraft:red_terracotta
setblock 472 298 482 minecraft:terracotta
fill 472 298 483 472 300 483 minecraft:red_terracotta
setblock 472 298 487 minecraft:terracotta
setblock 475 298 464 minecraft:terracotta
setblock 475 298 504 minecraft:terracotta
fill 476 298 464 478 298 465 minecraft:red_terracotta
fill 476 298 504 479 298 504 minecraft:red_terracotta
setblock 479 298 464 minecraft:red_terracotta
setblock 479 298 465 minecraft:terracotta
fill 479 298 466 482 298 466 minecraft:red_terracotta
fill 479 298 503 480 298 503 minecraft:red_terracotta
setblock 480 298 464 minecraft:terracotta
fill 480 298 465 483 298 465 minecraft:red_terracotta
setblock 480 298 504 minecraft:terracotta
fill 481 298 464 484 298 464 minecraft:red_terracotta
setblock 481 298 502 minecraft:red_terracotta
setblock 481 298 503 minecraft:terracotta
fill 481 298 504 484 298 504 minecraft:red_terracotta
setblock 482 298 502 minecraft:terracotta
fill 482 298 503 482 300 503 minecraft:red_terracotta
setblock 483 298 466 minecraft:terracotta
fill 483 298 467 485 299 467 minecraft:red_terracotta
fill 483 298 502 483 300 502 minecraft:red_terracotta
setblock 484 298 465 minecraft:terracotta
fill 484 298 466 484 300 466 minecraft:red_terracotta
setblock 485 298 464 minecraft:terracotta
fill 485 298 465 485 300 465 minecraft:red_terracotta
setblock 485 298 504 minecraft:terracotta
fill 486 298 464 486 300 464 minecraft:red_terracotta
setblock 486 298 503 minecraft:terracotta
fill 486 298 504 489 298 504 minecraft:red_terracotta
setblock 487 298 466 minecraft:red_terracotta
setblock 487 298 502 minecraft:terracotta
fill 487 298 503 487 300 503 minecraft:red_terracotta
setblock 488 298 466 minecraft:terracotta
fill 488 298 502 488 300 502 minecraft:red_terracotta
setblock 489 298 465 minecraft:terracotta
fill 489 298 466 489 300 466 minecraft:red_terracotta
setblock 490 298 464 minecraft:terracotta
fill 490 298 465 490 300 465 minecraft:red_terracotta
setblock 490 298 504 minecraft:terracotta
fill 491 298 464 491 300 464 minecraft:red_terracotta
setblock 491 298 503 minecraft:terracotta
fill 491 298 504 494 298 504 minecraft:red_terracotta
setblock 492 298 502 minecraft:terracotta
fill 492 298 503 495 298 503 minecraft:red_terracotta
setblock 493 298 465 minecraft:red_terracotta
setblock 493 298 502 minecraft:red_terracotta
setblock 494 298 464 minecraft:red_terracotta
setblock 495 298 464 minecraft:terracotta
setblock 495 298 504 minecraft:terracotta
fill 496 298 464 499 298 464 minecraft:red_terracotta
setblock 496 298 503 minecraft:terracotta
fill 496 298 504 496 300 504 minecraft:red_terracotta
setblock 497 298 502 minecraft:terracotta
fill 497 298 503 497 300 503 minecraft:red_terracotta
fill 498 298 502 498 300 502 minecraft:red_terracotta
setblock 500 298 464 minecraft:terracotta
fill 500 298 465 501 300 465 minecraft:red_terracotta
setblock 500 298 504 minecraft:terracotta
fill 501 298 464 501 300 464 minecraft:red_terracotta
setblock 501 298 503 minecraft:terracotta
fill 501 298 504 501 300 504 minecraft:red_terracotta
setblock 502 298 501 minecraft:red_terracotta
setblock 502 298 502 minecraft:terracotta
fill 502 298 503 502 300 503 minecraft:red_terracotta
setblock 503 298 465 minecraft:red_terracotta
setblock 503 298 501 minecraft:terracotta
fill 503 298 502 503 300 502 minecraft:red_terracotta
setblock 504 298 465 minecraft:terracotta
fill 504 298 501 504 299 501 minecraft:red_terracotta
setblock 505 298 464 minecraft:terracotta
fill 505 298 465 505 300 465 minecraft:red_terracotta
setblock 505 298 504 minecraft:terracotta
fill 506 298 464 506 300 464 minecraft:red_terracotta
setblock 506 298 503 minecraft:terracotta
fill 506 298 504 506 300 504 minecraft:red_terracotta
setblock 507 298 502 minecraft:terracotta
fill 507 298 503 507 300 503 minecraft:red_terracotta
setblock 508 298 465 minecraft:red_terracotta
setblock 508 298 481 minecraft:terracotta
fill 508 298 482 508 300 482 minecraft:red_terracotta
setblock 508 298 486 minecraft:terracotta
fill 508 298 487 508 300 487 minecraft:red_terracotta
fill 508 298 502 508 299 502 minecraft:red_terracotta
setblock 509 298 464 minecraft:red_terracotta
setblock 509 298 479 minecraft:red_terracotta
setblock 509 298 480 minecraft:terracotta
fill 509 298 481 509 300 481 minecraft:red_terracotta
setblock 509 298 485 minecraft:terracotta
fill 509 298 486 509 300 486 minecraft:red_terracotta
setblock 509 298 489 minecraft:red_terracotta
setblock 510 298 464 minecraft:terracotta
setblock 510 298 479 minecraft:terracotta
fill 510 298 480 510 300 480 minecraft:red_terracotta
setblock 510 298 484 minecraft:terracotta
fill 510 298 485 510 300 485 minecraft:red_terracotta
setblock 510 298 489 minecraft:terracotta
fill 510 298 490 510 300 490 minecraft:red_terracotta
setblock 510 298 499 minecraft:terracotta
setblock 510 298 500 minecraft:red_terracotta
setblock 510 298 504 minecraft:terracotta
fill 511 298 464 511 300 464 minecraft:red_terracotta
setblock 511 298 478 minecraft:terracotta
fill 511 298 479 511 300 479 minecraft:red_terracotta
setblock 511 298 483 minecraft:terracotta
fill 511 298 484 511 300 484 minecraft:red_terracotta
setblock 511 298 488 minecraft:terracotta
fill 511 298 489 511 300 489 minecraft:red_terracotta
setblock 511 298 493 minecraft:terracotta
fill 511 298 494 511 299 494 minecraft:red_terracotta
setblock 511 298 498 minecraft:terracotta
fill 511 298 499 511 299 499 minecraft:red_terracotta
setblock 511 298 503 minecraft:terracotta
fill 511 298 504 511 300 504 minecraft:red_terracotta
fill 471 299 464 473 299 464 minecraft:red_terracotta
setblock 471 299 467 minecraft:terracotta
fill 471 299 468 471 299 471 minecraft:red_terracotta
setblock 471 299 472 minecraft:terracotta
fill 471 299 473 471 299 476 minecraft:red_terracotta
setblock 471 299 477 minecraft:terracotta
fill 471 299 478 471 299 481 minecraft:red_terracotta
setblock 471 299 482 minecraft:terracotta
fill 471 299 483 471 300 483 minecraft:red_terracotta
setblock 471 299 486 minecraft:red_terracotta
setblock 471 299 487 minecraft:terracotta
fill 471 299 488 471 300 488 minecraft:red_terracotta
setblock 471 299 502 minecraft:terracotta
fill 471 299 503 471 299 504 minecraft:red_terracotta
setblock 472 299 465 minecraft:red_terracotta
setblock 472 299 481 minecraft:terracotta
fill 472 299 482 472 300 482 minecraft:red_terracotta
setblock 472 299 486 minecraft:terracotta
fill 472 299 487 472 300 487 minecraft:red_terracotta
fill 472 299 504 473 299 504 minecraft:red_terracotta
setblock 473 299 465 minecraft:terracotta
setblock 474 299 464 minecraft:terracotta
fill 474 299 465 477 299 465 minecraft:red_terracotta
setblock 474 299 504 minecraft:terracotta
fill 475 299 464 478 299 464 minecraft:red_terracotta
fill 475 299 504 478 299 504 minecraft:red_terracotta
setblock 478 299 465 minecraft:terracotta
fill 478 299 466 481 299 466 minecraft:red_terracotta
fill 478 299 503 479 299 503 minecraft:red_terracotta
setblock 479 299 464 minecraft:terracotta
fill 479 299 465 482 299 465 minecraft:red_terracotta
setblock 479 299 504 minecraft:terracotta
fill 480 299 464 483 299 464 minecraft:red_terracotta
setblock 480 299 503 minecraft:terracotta
fill 480 299 504 483 299 504 minecraft:red_terracotta
setblock 481 299 467 minecraft:terracotta
setblock 481 299 502 minecraft:terracotta
fill 481 299 503 481 300 503 minecraft:red_terracotta
setblock 482 299 466 minecraft:terracotta
fill 482 299 467 482 300 467 minecraft:red_terracotta
fill 482 299 502 482 300 502 minecraft:red_terracotta
setblock 483 299 465 minecraft:terracotta
fill 483 299 466 483 300 466 minecraft:red_terracotta
setblock 484 299 464 minecraft:terracotta
fill 484 299 465 484 300 465 minecraft:red_terracotta
setblock 484 299 504 minecraft:terracotta
fill 485 299 464 485 300 464 minecraft:red_terracotta
setblock 485 299 503 minecraft:terracotta
fill 485 299 504 488 299 504 minecraft:red_terracotta
setblock 486 299 467 minecraft:terracotta
setblock 486 299 502 minecraft:terracotta
fill 486 299 503 486 300 503 minecraft:red_terracotta
setblock 487 299 466 minecraft:terracotta
fill 487 299 502 487 300 502 minecraft:red_terracotta
setblock 488 299 465 minecraft:terracotta
fill 488 299 466 488 300 466 minecraft:red_terracotta
setblock 489 299 464 minecraft:terracotta
fill 489 299 465 489 300 465 minecraft:red_terracotta
setblock 489 299 504 minecraft:terracotta
fill 490 299 464 490 300 464 minecraft:red_terracotta
setblock 490 299 503 minecraft:terracotta
fill 490 299 504 493 299 504 minecraft:red_terracotta
setblock 491 299 502 minecraft:terracotta
fill 491 299 503 494 299 503 minecraft:red_terracotta
setblock 493 299 465 minecraft:terracotta
setblock 494 299 464 minecraft:terracotta
setblock 494 299 504 minecraft:terracotta
fill 495 299 464 498 299 464 minecraft:red_terracotta
setblock 495 299 503 minecraft:terracotta
fill 495 299 504 495 300 504 minecraft:red_terracotta
fill 496 299 503 496 300 503 minecraft:red_terracotta
fill 497 299 502 497 300 502 minecraft:red_terracotta
setblock 498 299 465 minecraft:terracotta
setblock 499 299 464 minecraft:terracotta
fill 499 299 465 499 300 465 minecraft:red_terracotta
setblock 499 299 504 minecraft:terracotta
fill 500 299 464 500 300 464 minecraft:red_terracotta
setblock 500 299 503 minecraft:terracotta
fill 500 299 504 500 300 504 minecraft:red_terracotta
setblock 501 299 502 minecraft:terracotta
fill 501 299 503 501 300 503 minecraft:red_terracotta
setblock 502 299 501 minecraft:terracotta
fill 502 299 502 502 300 502 minecraft:red_terracotta
setblock 503 299 465 minecraft:terracotta
setblock 503 299 501 minecraft:red_terracotta
setblock 504 299 464 minecraft:terracotta
fill 504 299 465 504 300 465 minecraft:red_terracotta
setblock 504 299 504 minecraft:terracotta
fill 505 299 464 505 300 464 minecraft:red_terracotta
setblock 505 299 503 minecraft:terracotta
fill 505 299 504 505 300 504 minecraft:red_terracotta
setblock 506 299 502 minecraft:terracotta
fill 506 299 503 506 300 503 minecraft:red_terracotta
fill 507 299 502 507 300 502 minecraft:red_terracotta
setblock 508 299 465 minecraft:terracotta
setblock 508 299 484 minecraft:red_terracotta
setblock 508 299 485 minecraft:terracotta
fill 508 299 486 508 300 486 minecraft:red_terracotta
fill 508 299 488 508 300 488 minecraft:red_terracotta
setblock 509 299 464 minecraft:terracotta
setblock 509 299 479 minecraft:terracotta
fill 509 299 480 509 300 480 minecraft:red_terracotta
setblock 509 299 484 minecraft:terracotta
fill 509 299 485 509 300 485 minecraft:red_terracotta
setblock 509 299 489 minecraft:terracotta
setblock 509 299 490 minecraft:red_terracotta
setblock 509 299 504 minecraft:terracotta
fill 510 299 464 510 300 464 minecraft:red_terracotta
setblock 510 299 478 minecraft:terracotta
fill 510 299 479 510 300 479 minecraft:red_terracotta
setblock 510 299 483 minecraft:terracotta
fill 510 299 484 510 300 484 minecraft:red_terracotta
setblock 510 299 488 minecraft:terracotta
fill 510 299 489 510 300 489 minecraft:red_terracotta
setblock 510 299 503 minecraft:terracotta
fill 510 299 504 510 300 504 minecraft:red_terracotta
setblock 511 299 466 minecraft:red_terracotta
setblock 511 299 477 minecraft:terracotta
fill 511 299 478 511 300 478 minecraft:red_terracotta
setblock 511 299 482 minecraft:terracotta
fill 511 299 483 511 300 483 minecraft:red_terracotta
setblock 511 299 487 minecraft:terracotta
fill 511 299 488 511 300 488 minecraft:red_terracotta
setblock 511 299 492 minecraft:terracotta
fill 511 299 493 511 300 493 minecraft:red_terracotta
setblock 511 299 498 minecraft:red_terracotta
setblock 511 299 502 minecraft:terracotta
fill 511 299 503 511 300 503 minecraft:red_terracotta
fill 471 300 464 472 300 464 minecraft:red_terracotta
setblock 471 300 466 minecraft:terracotta
fill 471 300 467 471 300 470 minecraft:red_terracotta
setblock 471 300 471 minecraft:terracotta
fill 471 300 472 471 300 475 minecraft:red_terracotta
setblock 471 300 476 minecraft:terracotta
fill 471 300 477 471 300 480 minecraft:red_terracotta
setblock 471 300 481 minecraft:terracotta
setblock 471 300 482 minecraft:red_terracotta
setblock 471 300 486 minecraft:terracotta
setblock 471 300 487 minecraft:red_terracotta
fill 471 300 504 472 300 504 minecraft:red_terracotta
setblock 472 300 465 minecraft:terracotta
setblock 472 300 466 minecraft:red_terracotta
setblock 472 300 480 minecraft:terracotta
setblock 472 300 481 minecraft:red_terracotta
setblock 472 300 485 minecraft:terracotta
setblock 472 300 486 minecraft:red_terracotta
setblock 473 300 464 minecraft:terracotta
fill 473 300 465 476 300 465 minecraft:red_terracotta
setblock 473 300 504 minecraft:terracotta
fill 474 300 464 477 300 464 minecraft:red_terracotta
fill 474 300 504 477 300 504 minecraft:red_terracotta
setblock 477 300 465 minecraft:terracotta
fill 477 300 466 480 300 466 minecraft:red_terracotta
setblock 478 300 464 minecraft:terracotta
fill 478 300 465 481 300 465 minecraft:red_terracotta
setblock 478 300 503 minecraft:red_terracotta
setblock 478 300 504 minecraft:terracotta
fill 479 300 464 482 300 464 minecraft:red_terracotta
setblock 479 300 503 minecraft:terracotta
fill 479 300 504 482 300 504 minecraft:red_terracotta
setblock 480 300 467 minecraft:terracotta
setblock 480 300 503 minecraft:red_terracotta
setblock 481 300 466 minecraft:terracotta
setblock 481 300 467 minecraft:red_terracotta
setblock 481 300 502 minecraft:red_terracotta
setblock 482 300 465 minecraft:terracotta
setblock 482 300 466 minecraft:red_terracotta
setblock 483 300 464 minecraft:terracotta
setblock 483 300 465 minecraft:red_terracotta
fill 483 300 467 484 300 467 minecraft:red_terracotta
setblock 483 300 504 minecraft:terracotta
setblock 484 300 464 minecraft:red_terracotta
setblock 484 300 503 minecraft:terracotta
fill 484 300 504 487 300 504 minecraft:red_terracotta
setblock 485 300 467 minecraft:terracotta
setblock 485 300 502 minecraft:terracotta
setblock 485 300 503 minecraft:red_terracotta
setblock 486 300 466 minecraft:terracotta
setblock 486 300 467 minecraft:red_terracotta
setblock 486 300 502 minecraft:red_terracotta
setblock 487 300 465 minecraft:terracotta
setblock 487 300 466 minecraft:red_terracotta
setblock 488 300 464 minecraft:terracotta
setblock 488 300 465 minecraft:red_terracotta
setblock 488 300 504 minecraft:terracotta
setblock 489 300 464 minecraft:red_terracotta
setblock 489 300 503 minecraft:terracotta
fill 489 300 504 492 300 504 minecraft:red_terracotta
setblock 490 300 502 minecraft:terracotta
fill 490 300 503 493 300 503 minecraft:red_terracotta
setblock 492 300 465 minecraft:terracotta
setblock 493 300 464 minecraft:terracotta
setblock 493 300 465 minecraft:red_terracotta
setblock 493 300 504 minecraft:terracotta
fill 494 300 464 497 300 464 minecraft:red_terracotta
setblock 494 300 503 minecraft:terracotta
setblock 494 300 504 minecraft:red_terracotta
setblock 495 300 503 minecraft:red_terracotta
setblock 497 300 465 minecraft:terracotta
setblock 498 300 464 minecraft:terracotta
setblock 498 300 465 minecraft:red_terracotta
setblock 498 300 504 minecraft:terracotta
setblock 499 300 464 minecraft:red_terracotta
setblock 499 300 503 minecraft:terracotta
setblock 499 300 504 minecraft:red_terracotta
setblock 500 300 502 minecraft:terracotta
setblock 500 300 503 minecraft:red_terracotta
setblock 501 300 502 minecraft:red_terracotta
setblock 502 300 464 minecraft:red_terracotta
setblock 502 300 465 minecraft:terracotta
setblock 503 300 464 minecraft:terracotta
setblock 503 300 465 minecraft:red_terracotta
setblock 503 300 504 minecraft:terracotta
setblock 504 300 464 minecraft:red_terracotta
setblock 504 300 503 minecraft:terracotta
setblock 504 300 504 minecraft:red_terracotta
setblock 505 300 502 minecraft:terracotta
setblock 505 300 503 minecraft:red_terracotta
setblock 506 300 465 minecraft:red_terracotta
setblock 506 300 502 minecraft:red_terracotta
setblock 507 300 465 minecraft:terracotta
setblock 508 300 464 minecraft:terracotta
setblock 508 300 465 minecraft:red_terracotta
setblock 508 300 484 minecraft:terracotta
setblock 508 300 485 minecraft:red_terracotta
setblock 508 300 504 minecraft:terracotta
setblock 509 300 464 minecraft:red_terracotta
setblock 509 300 483 minecraft:terracotta
setblock 509 300 484 minecraft:red_terracotta
setblock 509 300 488 minecraft:terracotta
setblock 509 300 489 minecraft:red_terracotta
setblock 509 300 503 minecraft:terracotta
setblock 509 300 504 minecraft:red_terracotta
setblock 510 300 482 minecraft:terracotta
setblock 510 300 483 minecraft:red_terracotta
setblock 510 300 487 minecraft:terracotta
setblock 510 300 488 minecraft:red_terracotta
setblock 511 300 466 minecraft:terracotta
setblock 511 300 476 minecraft:terracotta
setblock 511 300 477 minecraft:red_terracotta
setblock 511 300 481 minecraft:terracotta
setblock 511 300 482 minecraft:red_terracotta
setblock 511 300 486 minecraft:terracotta
setblock 511 300 487 minecraft:red_terracotta
setblock 511 300 491 minecraft:terracotta
setblock 511 300 492 minecraft:red_terracotta
setblock 511 300 501 minecraft:terracotta
setblock 511 300 502 minecraft:red_terracotta
setblock 473 301 466 minecraft:light[level=14]
setblock 473 301 474 minecraft:light[level=14]
setblock 473 301 482 minecraft:light[level=14]
setblock 473 301 490 minecraft:light[level=14]
setblock 473 301 498 minecraft:light[level=14]
setblock 481 301 466 minecraft:light[level=14]
setblock 481 301 474 minecraft:light[level=14]
setblock 481 301 482 minecraft:light[level=14]
setblock 481 301 490 minecraft:light[level=14]
setblock 481 301 498 minecraft:light[level=14]
setblock 489 301 466 minecraft:light[level=14]
setblock 489 301 474 minecraft:light[level=14]
setblock 489 301 482 minecraft:light[level=14]
setblock 489 301 490 minecraft:light[level=14]
setblock 489 301 498 minecraft:light[level=14]
setblock 497 301 466 minecraft:light[level=14]
setblock 497 301 474 minecraft:light[level=14]
setblock 497 301 482 minecraft:light[level=14]
setblock 497 301 490 minecraft:light[level=14]
setblock 497 301 498 minecraft:light[level=14]
setblock 505 301 466 minecraft:light[level=14]
setblock 505 301 474 minecraft:light[level=14]
setblock 505 301 482 minecraft:light[level=14]
setblock 505 301 490 minecraft:light[level=14]
setblock 505 301 498 minecraft:light[level=14]
