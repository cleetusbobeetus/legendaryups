fill 393 278 301 393 278 307 minecraft:red_terracotta
setblock 394 278 301 minecraft:orange_terracotta
fill 394 278 302 416 278 307 minecraft:red_terracotta
fill 396 278 295 397 278 295 minecraft:orange_terracotta
fill 396 278 301 397 278 301 minecraft:orange_terracotta
fill 398 278 295 416 278 295 minecraft:red_terracotta
fill 398 278 296 398 278 297 minecraft:orange_terracotta
fill 398 278 299 398 278 300 minecraft:orange_terracotta
fill 398 278 301 416 278 301 minecraft:red_terracotta
fill 399 278 296 416 278 300 minecraft:red_terracotta
fill 409 278 277 410 279 277 minecraft:terracotta
fill 409 278 315 410 279 315 minecraft:terracotta
fill 411 278 278 411 279 278 minecraft:terracotta
fill 411 278 314 411 279 314 minecraft:terracotta
fill 412 278 279 412 279 279 minecraft:terracotta
fill 412 278 313 412 279 313 minecraft:terracotta
fill 413 278 280 413 279 280 minecraft:terracotta
fill 413 278 312 413 279 312 minecraft:terracotta
fill 414 278 281 414 279 281 minecraft:terracotta
fill 414 278 311 414 279 311 minecraft:terracotta
fill 415 278 282 415 279 282 minecraft:terracotta
fill 415 278 310 415 279 310 minecraft:terracotta
fill 416 278 283 416 279 284 minecraft:terracotta
fill 416 278 308 416 279 309 minecraft:terracotta
fill 417 278 285 417 279 307 minecraft:terracotta
fill 377 279 276 377 279 284 minecraft:terracotta
fill 377 279 308 377 279 316 minecraft:terracotta
fill 378 279 276 381 279 279 minecraft:terracotta
fill 378 279 285 378 280 285 minecraft:terracotta
fill 378 279 286 390 279 306 minecraft:red_terracotta
fill 378 279 307 378 280 307 minecraft:terracotta
fill 378 279 310 378 279 316 minecraft:terracotta
setblock 379 279 280 minecraft:terracotta
fill 379 279 281 379 285 281 minecraft:green_concrete
fill 379 279 282 379 279 283 minecraft:terracotta
fill 379 279 284 415 279 285 minecraft:red_terracotta
fill 379 279 307 415 279 308 minecraft:red_terracotta
setblock 379 279 309 minecraft:terracotta
fill 379 279 311 379 279 316 minecraft:terracotta
fill 380 279 282 380 280 282 minecraft:terracotta
fill 380 279 283 414 279 283 minecraft:red_terracotta
fill 380 279 309 414 279 309 minecraft:red_terracotta
fill 380 279 310 380 280 310 minecraft:terracotta
fill 380 279 312 380 279 316 minecraft:terracotta
fill 381 279 281 381 280 281 minecraft:terracotta
fill 381 279 282 413 280 282 minecraft:red_terracotta
fill 381 279 310 413 280 310 minecraft:red_terracotta
fill 381 279 311 381 280 311 minecraft:terracotta
fill 381 279 313 381 279 316 minecraft:terracotta
fill 382 279 276 382 279 278 minecraft:terracotta
fill 382 279 280 382 280 280 minecraft:terracotta
fill 382 279 281 412 280 281 minecraft:red_terracotta
fill 382 279 311 412 280 311 minecraft:red_terracotta
fill 382 279 312 382 280 312 minecraft:terracotta
fill 382 279 314 382 279 316 minecraft:terracotta
fill 383 279 276 383 279 277 minecraft:terracotta
fill 383 279 279 383 280 279 minecraft:terracotta
fill 383 279 280 411 280 280 minecraft:red_terracotta
fill 383 279 312 411 280 312 minecraft:red_terracotta
fill 383 279 313 383 280 313 minecraft:terracotta
fill 383 279 315 383 279 316 minecraft:terracotta
fill 384 279 276 385 279 276 minecraft:terracotta
setblock 384 279 278 minecraft:terracotta
fill 384 279 279 410 279 279 minecraft:red_terracotta
fill 384 279 313 410 279 313 minecraft:red_terracotta
setblock 384 279 314 minecraft:terracotta
fill 384 279 316 385 279 316 minecraft:terracotta
fill 385 279 278 409 279 278 minecraft:red_terracotta
fill 385 279 314 409 279 314 minecraft:red_terracotta
fill 386 279 277 386 280 277 minecraft:terracotta
fill 386 279 315 386 280 315 minecraft:terracotta
fill 387 279 277 407 279 277 minecraft:red_terracotta
fill 387 279 315 407 279 315 minecraft:red_terracotta
fill 391 279 286 391 279 295 minecraft:red_terracotta
setblock 391 279 296 minecraft:yellow_terracotta
fill 391 279 297 391 279 299 minecraft:shroomlight
fill 391 279 300 391 279 306 minecraft:red_terracotta
fill 392 279 286 392 279 294 minecraft:red_terracotta
fill 392 279 295 392 279 297 minecraft:shroomlight
fill 392 279 299 392 279 301 minecraft:shroomlight
fill 392 279 302 393 279 306 minecraft:red_terracotta
fill 393 279 286 416 279 293 minecraft:red_terracotta
setblock 393 279 294 minecraft:yellow_terracotta
fill 393 279 295 394 279 295 minecraft:shroomlight
fill 393 279 301 394 279 301 minecraft:shroomlight
fill 394 279 294 396 279 294 minecraft:shroomlight
fill 394 279 302 396 279 302 minecraft:shroomlight
fill 394 279 303 416 279 306 minecraft:red_terracotta
fill 396 279 295 398 279 295 minecraft:shroomlight
fill 396 279 301 398 279 301 minecraft:shroomlight
setblock 397 279 294 minecraft:yellow_terracotta
setblock 397 279 302 minecraft:yellow_terracotta
fill 398 279 294 416 279 294 minecraft:red_terracotta
fill 398 279 296 398 279 297 minecraft:shroomlight
fill 398 279 299 398 279 300 minecraft:shroomlight
fill 398 279 302 416 279 302 minecraft:red_terracotta
fill 399 279 295 416 279 295 minecraft:red_terracotta
setblock 399 279 296 minecraft:yellow_terracotta
fill 399 279 297 399 279 299 minecraft:shroomlight
setblock 399 279 300 minecraft:yellow_terracotta
fill 399 279 301 416 279 301 minecraft:red_terracotta
fill 400 279 296 416 279 300 minecraft:red_terracotta
fill 408 279 277 408 280 277 minecraft:terracotta
fill 408 279 315 408 280 315 minecraft:terracotta
fill 409 279 276 417 279 276 minecraft:terracotta
fill 409 279 316 417 279 316 minecraft:terracotta
setblock 410 279 278 minecraft:terracotta
setblock 410 279 314 minecraft:terracotta
fill 411 279 277 417 279 277 minecraft:terracotta
fill 411 279 279 411 280 279 minecraft:terracotta
fill 411 279 313 411 280 313 minecraft:terracotta
fill 411 279 315 417 279 315 minecraft:terracotta
fill 412 279 278 417 279 278 minecraft:terracotta
fill 412 279 280 412 280 280 minecraft:terracotta
fill 412 279 312 412 280 312 minecraft:terracotta
fill 412 279 314 417 279 314 minecraft:terracotta
fill 413 279 279 417 279 279 minecraft:terracotta
fill 413 279 281 413 280 281 minecraft:terracotta
fill 413 279 311 413 280 311 minecraft:terracotta
fill 413 279 313 417 279 313 minecraft:terracotta
fill 414 279 280 417 279 280 minecraft:terracotta
fill 414 279 282 414 280 282 minecraft:terracotta
fill 414 279 310 414 280 310 minecraft:terracotta
fill 414 279 312 417 279 312 minecraft:terracotta
fill 415 279 281 417 279 281 minecraft:terracotta
setblock 415 279 283 minecraft:terracotta
setblock 415 279 309 minecraft:terracotta
fill 415 279 311 417 279 311 minecraft:terracotta
fill 416 279 282 417 279 282 minecraft:terracotta
fill 416 279 285 416 280 285 minecraft:terracotta
fill 416 279 307 416 280 307 minecraft:terracotta
fill 416 279 310 417 279 310 minecraft:terracotta
fill 417 279 283 417 279 284 minecraft:terracotta
fill 417 279 308 417 279 309 minecraft:terracotta
fill 376 280 275 376 283 317 minecraft:orange_terracotta
fill 377 280 275 418 283 275 minecraft:orange_terracotta
fill 377 280 287 377 280 305 minecraft:terracotta
fill 377 280 317 418 283 317 minecraft:orange_terracotta
fill 378 280 286 378 281 286 minecraft:terracotta
fill 378 280 287 389 280 305 minecraft:red_terracotta
fill 378 280 306 378 281 306 minecraft:terracotta
setblock 379 280 278 minecraft:light[level=15]
setblock 379 280 284 minecraft:terracotta
fill 379 280 285 415 280 286 minecraft:red_terracotta
fill 379 280 306 415 280 307 minecraft:red_terracotta
setblock 379 280 308 minecraft:terracotta
setblock 379 280 310 minecraft:light[level=15]
fill 380 280 283 380 281 283 minecraft:terracotta
fill 380 280 284 414 280 284 minecraft:red_terracotta
fill 380 280 308 414 280 308 minecraft:red_terracotta
fill 380 280 309 380 281 309 minecraft:terracotta
fill 381 280 283 413 281 283 minecraft:red_terracotta
fill 381 280 309 413 281 309 minecraft:red_terracotta
fill 384 280 279 384 281 279 minecraft:terracotta
fill 384 280 313 384 281 313 minecraft:terracotta
fill 385 280 276 385 280 278 minecraft:terracotta
fill 385 280 279 409 280 279 minecraft:red_terracotta
fill 385 280 313 409 280 313 minecraft:red_terracotta
setblock 385 280 314 minecraft:terracotta
fill 386 280 276 406 280 276 minecraft:terracotta
fill 386 280 278 408 280 278 minecraft:red_terracotta
fill 386 280 314 408 280 314 minecraft:red_terracotta
fill 387 280 277 387 281 277 minecraft:terracotta
fill 387 280 315 387 281 315 minecraft:terracotta
fill 388 280 277 406 280 277 minecraft:red_terracotta
fill 388 280 315 406 280 315 minecraft:red_terracotta
fill 388 280 316 406 280 316 minecraft:terracotta
fill 390 280 287 390 280 296 minecraft:red_terracotta
fill 390 280 297 390 281 299 minecraft:orange_terracotta
fill 390 280 300 390 280 305 minecraft:red_terracotta
fill 391 280 287 391 280 294 minecraft:red_terracotta
fill 391 280 295 391 280 296 minecraft:orange_terracotta
setblock 391 280 300 minecraft:orange_terracotta
fill 391 280 301 391 280 305 minecraft:red_terracotta
fill 392 280 287 392 280 293 minecraft:red_terracotta
setblock 392 280 294 minecraft:orange_terracotta
setblock 392 280 301 minecraft:orange_terracotta
fill 392 280 302 392 280 305 minecraft:red_terracotta
fill 393 280 287 416 280 292 minecraft:red_terracotta
fill 393 280 293 398 280 293 minecraft:orange_terracotta
setblock 393 280 302 minecraft:orange_terracotta
fill 393 280 303 393 280 305 minecraft:red_terracotta
fill 394 280 303 396 281 303 minecraft:orange_terracotta
fill 394 280 304 416 280 305 minecraft:red_terracotta
setblock 395 280 294 minecraft:light[level=15]
setblock 395 280 302 minecraft:light[level=15]
fill 397 280 302 398 280 302 minecraft:orange_terracotta
fill 397 280 303 416 280 303 minecraft:red_terracotta
fill 398 280 294 399 280 294 minecraft:orange_terracotta
fill 399 280 293 416 280 293 minecraft:red_terracotta
fill 399 280 295 400 280 295 minecraft:orange_terracotta
setblock 399 280 301 minecraft:orange_terracotta
fill 399 280 302 416 280 302 minecraft:red_terracotta
fill 400 280 294 416 280 294 minecraft:red_terracotta
fill 400 280 296 400 280 300 minecraft:orange_terracotta
fill 400 280 301 416 280 301 minecraft:red_terracotta
fill 401 280 295 416 280 300 minecraft:red_terracotta
fill 407 280 277 407 281 277 minecraft:terracotta
fill 407 280 315 407 281 315 minecraft:terracotta
setblock 409 280 278 minecraft:terracotta
setblock 409 280 314 minecraft:terracotta
fill 410 280 279 410 281 279 minecraft:terracotta
fill 410 280 313 410 281 313 minecraft:terracotta
setblock 411 280 278 minecraft:light[level=15]
fill 414 280 283 414 281 283 minecraft:terracotta
fill 414 280 309 414 281 309 minecraft:terracotta
setblock 415 280 284 minecraft:terracotta
setblock 415 280 308 minecraft:terracotta
fill 416 280 286 416 281 286 minecraft:terracotta
fill 416 280 306 416 281 306 minecraft:terracotta
fill 417 280 287 417 280 305 minecraft:terracotta
fill 418 280 276 418 283 316 minecraft:orange_terracotta
fill 377 281 288 377 281 304 minecraft:terracotta
setblock 378 281 287 minecraft:terracotta
fill 378 281 288 389 281 304 minecraft:red_terracotta
setblock 378 281 305 minecraft:terracotta
setblock 379 281 285 minecraft:terracotta
fill 379 281 286 415 281 287 minecraft:red_terracotta
fill 379 281 305 415 281 306 minecraft:red_terracotta
setblock 379 281 307 minecraft:terracotta
fill 380 281 284 380 282 284 minecraft:terracotta
fill 380 281 285 414 281 285 minecraft:red_terracotta
fill 380 281 307 414 281 307 minecraft:red_terracotta
fill 380 281 308 380 282 308 minecraft:terracotta
setblock 381 281 282 minecraft:terracotta
fill 381 281 284 413 282 284 minecraft:red_terracotta
fill 381 281 308 413 282 308 minecraft:red_terracotta
setblock 381 281 310 minecraft:terracotta
setblock 382 281 281 minecraft:terracotta
fill 382 281 282 412 281 282 minecraft:red_terracotta
fill 382 281 310 412 281 310 minecraft:red_terracotta
setblock 382 281 311 minecraft:terracotta
setblock 383 281 280 minecraft:terracotta
fill 383 281 281 411 281 281 minecraft:red_terracotta
fill 383 281 311 411 281 311 minecraft:red_terracotta
setblock 383 281 312 minecraft:terracotta
fill 384 281 280 410 281 280 minecraft:red_terracotta
fill 384 281 312 410 281 312 minecraft:red_terracotta
fill 385 281 279 385 282 279 minecraft:terracotta
fill 385 281 313 385 282 313 minecraft:terracotta
fill 386 281 277 386 287 277 minecraft:green_concrete
setblock 386 281 278 minecraft:terracotta
fill 386 281 279 408 281 279 minecraft:red_terracotta
fill 386 281 313 408 281 313 minecraft:red_terracotta
setblock 386 281 314 minecraft:terracotta
fill 387 281 278 407 281 278 minecraft:red_terracotta
fill 387 281 314 407 281 314 minecraft:red_terracotta
setblock 388 281 277 minecraft:terracotta
setblock 388 281 315 minecraft:terracotta
fill 389 281 276 405 281 276 minecraft:terracotta
fill 389 281 277 405 281 277 minecraft:red_terracotta
fill 389 281 315 405 281 315 minecraft:red_terracotta
fill 389 281 316 405 281 316 minecraft:terracotta
fill 390 281 288 390 281 294 minecraft:red_terracotta
fill 390 281 295 390 281 296 minecraft:orange_terracotta
setblock 390 281 300 minecraft:orange_terracotta
fill 390 281 301 390 281 304 minecraft:red_terracotta
fill 391 281 288 391 281 293 minecraft:red_terracotta
setblock 391 281 294 minecraft:orange_terracotta
setblock 391 281 301 minecraft:orange_terracotta
fill 391 281 302 391 281 304 minecraft:red_terracotta
fill 392 281 288 392 281 292 minecraft:red_terracotta
setblock 392 281 293 minecraft:orange_terracotta
setblock 392 281 302 minecraft:orange_terracotta
fill 392 281 303 392 281 304 minecraft:red_terracotta
fill 393 281 288 416 281 291 minecraft:red_terracotta
fill 393 281 292 399 281 292 minecraft:orange_terracotta
setblock 393 281 303 minecraft:orange_terracotta
fill 393 281 304 416 281 304 minecraft:red_terracotta
fill 397 281 303 398 281 303 minecraft:orange_terracotta
fill 399 281 293 400 281 293 minecraft:orange_terracotta
setblock 399 281 302 minecraft:orange_terracotta
fill 399 281 303 416 281 303 minecraft:red_terracotta
fill 400 281 292 416 281 292 minecraft:red_terracotta
fill 400 281 294 401 281 294 minecraft:orange_terracotta
setblock 400 281 301 minecraft:orange_terracotta
fill 400 281 302 416 281 302 minecraft:red_terracotta
fill 401 281 293 416 281 293 minecraft:red_terracotta
fill 401 281 295 401 281 300 minecraft:orange_terracotta
fill 401 281 301 416 281 301 minecraft:red_terracotta
fill 402 281 294 416 281 300 minecraft:red_terracotta
setblock 406 281 277 minecraft:terracotta
setblock 406 281 315 minecraft:terracotta
setblock 408 281 278 minecraft:terracotta
setblock 408 281 314 minecraft:terracotta
fill 409 281 279 409 282 279 minecraft:terracotta
fill 409 281 313 409 282 313 minecraft:terracotta
setblock 411 281 280 minecraft:terracotta
setblock 411 281 312 minecraft:terracotta
setblock 412 281 281 minecraft:terracotta
setblock 412 281 311 minecraft:terracotta
setblock 413 281 282 minecraft:terracotta
setblock 413 281 310 minecraft:terracotta
fill 414 281 284 414 282 284 minecraft:terracotta
fill 414 281 308 414 282 308 minecraft:terracotta
setblock 415 281 285 minecraft:terracotta
setblock 415 281 307 minecraft:terracotta
setblock 416 281 287 minecraft:terracotta
setblock 416 281 305 minecraft:terracotta
fill 417 281 288 417 281 304 minecraft:terracotta
fill 377 282 290 377 282 302 minecraft:terracotta
fill 378 282 288 378 282 289 minecraft:terracotta
fill 378 282 290 388 282 302 minecraft:red_terracotta
fill 378 282 303 378 282 304 minecraft:terracotta
setblock 379 282 278 minecraft:light[level=12]
fill 379 282 282 379 284 282 minecraft:green_concrete
setblock 379 282 285 minecraft:light[level=12]
fill 379 282 286 379 282 287 minecraft:terracotta
fill 379 282 288 415 282 289 minecraft:red_terracotta
fill 379 282 303 391 282 304 minecraft:red_terracotta
fill 379 282 305 379 282 306 minecraft:terracotta
setblock 379 282 313 minecraft:light[level=12]
fill 380 282 285 380 283 285 minecraft:terracotta
fill 380 282 286 414 282 287 minecraft:red_terracotta
fill 380 282 305 414 282 306 minecraft:red_terracotta
fill 380 282 307 380 283 307 minecraft:terracotta
setblock 381 282 283 minecraft:terracotta
fill 381 282 285 413 283 285 minecraft:red_terracotta
fill 381 282 307 413 283 307 minecraft:red_terracotta
setblock 381 282 309 minecraft:terracotta
setblock 382 282 282 minecraft:terracotta
fill 382 282 283 412 282 283 minecraft:red_terracotta
fill 382 282 309 412 282 309 minecraft:red_terracotta
setblock 382 282 310 minecraft:terracotta
setblock 383 282 281 minecraft:terracotta
fill 383 282 282 411 282 282 minecraft:red_terracotta
fill 383 282 310 411 282 310 minecraft:red_terracotta
setblock 383 282 311 minecraft:terracotta
setblock 384 282 280 minecraft:terracotta
fill 384 282 281 410 282 281 minecraft:red_terracotta
fill 384 282 311 410 282 311 minecraft:red_terracotta
setblock 384 282 312 minecraft:terracotta
fill 385 282 280 409 282 280 minecraft:red_terracotta
fill 385 282 312 409 282 312 minecraft:red_terracotta
setblock 386 282 278 minecraft:light[level=12]
fill 386 282 279 386 283 279 minecraft:terracotta
fill 386 282 313 386 283 313 minecraft:terracotta
fill 387 282 278 388 282 278 minecraft:terracotta
fill 387 282 279 407 282 279 minecraft:red_terracotta
fill 387 282 313 407 282 313 minecraft:red_terracotta
fill 387 282 314 388 282 314 minecraft:terracotta
fill 389 282 277 390 282 277 minecraft:terracotta
fill 389 282 278 405 282 278 minecraft:red_terracotta
fill 389 282 290 389 282 294 minecraft:red_terracotta
fill 389 282 295 389 282 299 minecraft:yellow_terracotta
fill 389 282 300 389 282 302 minecraft:red_terracotta
fill 389 282 314 405 282 314 minecraft:red_terracotta
fill 389 282 315 390 282 315 minecraft:terracotta
fill 390 282 290 390 282 293 minecraft:red_terracotta
setblock 390 282 294 minecraft:yellow_terracotta
fill 390 282 300 390 282 301 minecraft:yellow_terracotta
setblock 390 282 302 minecraft:red_terracotta
fill 391 282 276 403 282 276 minecraft:terracotta
fill 391 282 277 403 282 277 minecraft:red_terracotta
fill 391 282 290 392 282 291 minecraft:red_terracotta
fill 391 282 292 391 282 293 minecraft:yellow_terracotta
setblock 391 282 302 minecraft:yellow_terracotta
fill 391 282 315 403 282 315 minecraft:red_terracotta
fill 391 282 316 403 282 316 minecraft:terracotta
setblock 392 282 292 minecraft:yellow_terracotta
fill 392 282 303 393 282 303 minecraft:yellow_terracotta
fill 392 282 304 393 282 304 minecraft:red_terracotta
fill 393 282 290 394 282 290 minecraft:red_terracotta
fill 393 282 291 399 282 291 minecraft:yellow_terracotta
setblock 393 282 292 minecraft:light[level=12]
setblock 393 282 299 minecraft:light[level=12]
fill 394 282 304 398 282 304 minecraft:yellow_terracotta
fill 395 282 290 396 282 290 minecraft:yellow_terracotta
fill 397 282 290 416 282 290 minecraft:red_terracotta
setblock 399 282 303 minecraft:yellow_terracotta
fill 399 282 304 415 282 304 minecraft:red_terracotta
fill 400 282 291 416 282 291 minecraft:red_terracotta
setblock 400 282 292 minecraft:yellow_terracotta
setblock 400 282 299 minecraft:light[level=12]
fill 400 282 302 401 282 302 minecraft:yellow_terracotta
fill 400 282 303 415 282 303 minecraft:red_terracotta
fill 401 282 292 416 282 292 minecraft:red_terracotta
setblock 401 282 293 minecraft:yellow_terracotta
setblock 401 282 301 minecraft:yellow_terracotta
fill 402 282 293 416 282 293 minecraft:red_terracotta
fill 402 282 294 402 282 300 minecraft:yellow_terracotta
fill 402 282 301 416 282 302 minecraft:red_terracotta
fill 403 282 294 416 282 296 minecraft:red_terracotta
fill 403 282 297 403 282 298 minecraft:yellow_terracotta
fill 403 282 299 416 282 300 minecraft:red_terracotta
fill 404 282 277 405 282 277 minecraft:terracotta
fill 404 282 297 416 282 298 minecraft:red_terracotta
fill 404 282 315 405 282 315 minecraft:terracotta
fill 406 282 278 407 282 278 minecraft:terracotta
fill 406 282 314 407 282 314 minecraft:terracotta
fill 408 282 279 408 283 279 minecraft:terracotta
fill 408 282 313 408 283 313 minecraft:terracotta
setblock 410 282 280 minecraft:terracotta
setblock 410 282 312 minecraft:terracotta
setblock 411 282 281 minecraft:terracotta
setblock 411 282 311 minecraft:terracotta
setblock 412 282 282 minecraft:terracotta
setblock 412 282 310 minecraft:terracotta
setblock 413 282 283 minecraft:terracotta
setblock 413 282 309 minecraft:terracotta
setblock 414 282 278 minecraft:light[level=12]
fill 414 282 285 414 283 285 minecraft:terracotta
fill 414 282 307 414 283 307 minecraft:terracotta
setblock 414 282 313 minecraft:light[level=12]
fill 415 282 286 415 282 287 minecraft:terracotta
fill 415 282 305 415 282 306 minecraft:terracotta
fill 416 282 288 416 282 289 minecraft:terracotta
fill 416 282 303 416 282 304 minecraft:terracotta
fill 417 282 290 417 282 302 minecraft:terracotta
fill 377 283 276 377 283 279 minecraft:red_terracotta
fill 377 283 280 378 283 280 minecraft:stripped_oak_log
fill 377 283 281 377 283 284 minecraft:red_terracotta
setblock 377 283 285 minecraft:stripped_oak_log
fill 377 283 286 377 283 289 minecraft:red_terracotta
setblock 377 283 290 minecraft:stripped_oak_log
fill 377 283 291 377 285 292 minecraft:red_terracotta
fill 377 283 293 377 283 299 minecraft:terracotta
setblock 377 283 300 minecraft:stripped_oak_log
fill 377 283 301 377 283 304 minecraft:red_terracotta
setblock 377 283 305 minecraft:stripped_oak_log
fill 377 283 306 377 283 309 minecraft:red_terracotta
setblock 377 283 310 minecraft:stripped_oak_log
fill 377 283 311 377 283 314 minecraft:red_terracotta
setblock 377 283 315 minecraft:stripped_oak_log
fill 377 283 316 380 283 316 minecraft:red_terracotta
fill 378 283 276 379 284 276 minecraft:red_terracotta
fill 378 283 286 378 283 288 minecraft:red_terracotta
fill 378 283 289 378 283 292 minecraft:terracotta
fill 378 283 293 387 283 299 minecraft:red_terracotta
fill 378 283 300 378 283 303 minecraft:terracotta
setblock 378 283 304 minecraft:stripped_oak_log
fill 378 283 305 378 283 308 minecraft:red_terracotta
setblock 378 283 309 minecraft:stripped_oak_log
fill 378 283 310 378 283 313 minecraft:red_terracotta
setblock 378 283 314 minecraft:stripped_oak_log
fill 378 283 315 381 283 315 minecraft:red_terracotta
fill 379 283 287 379 283 288 minecraft:terracotta
fill 379 283 289 389 283 292 minecraft:red_terracotta
fill 379 283 300 388 283 303 minecraft:red_terracotta
fill 379 283 304 379 283 305 minecraft:terracotta
setblock 379 283 307 minecraft:red_terracotta
setblock 379 283 308 minecraft:stripped_oak_log
fill 379 283 309 379 283 312 minecraft:red_terracotta
setblock 379 283 313 minecraft:stripped_oak_log
fill 379 283 314 380 285 314 minecraft:red_terracotta
setblock 380 283 286 minecraft:terracotta
fill 380 283 287 414 283 288 minecraft:red_terracotta
fill 380 283 304 391 283 305 minecraft:red_terracotta
setblock 380 283 306 minecraft:terracotta
fill 381 283 278 381 290 278 minecraft:brown_terracotta
setblock 381 283 284 minecraft:terracotta
fill 381 283 286 413 283 286 minecraft:red_terracotta
fill 381 283 306 413 283 306 minecraft:red_terracotta
setblock 381 283 308 minecraft:terracotta
setblock 381 283 316 minecraft:stripped_oak_log
setblock 382 283 283 minecraft:terracotta
fill 382 283 284 412 283 284 minecraft:red_terracotta
fill 382 283 308 412 283 308 minecraft:red_terracotta
setblock 382 283 309 minecraft:terracotta
setblock 382 283 315 minecraft:stripped_oak_log
fill 382 283 316 384 284 316 minecraft:red_terracotta
setblock 383 283 282 minecraft:terracotta
fill 383 283 283 411 283 283 minecraft:red_terracotta
fill 383 283 309 411 283 309 minecraft:red_terracotta
setblock 383 283 310 minecraft:terracotta
setblock 384 283 281 minecraft:terracotta
fill 384 283 282 410 283 282 minecraft:red_terracotta
fill 384 283 310 410 283 310 minecraft:red_terracotta
setblock 384 283 311 minecraft:terracotta
fill 384 283 312 384 284 315 minecraft:stripped_oak_log
setblock 385 283 280 minecraft:terracotta
fill 385 283 281 409 283 281 minecraft:red_terracotta
fill 385 283 311 409 283 311 minecraft:red_terracotta
setblock 385 283 312 minecraft:terracotta
fill 385 283 313 385 284 316 minecraft:stripped_oak_log
fill 386 283 280 408 283 280 minecraft:red_terracotta
fill 386 283 312 408 283 312 minecraft:red_terracotta
fill 386 283 314 387 283 316 minecraft:stripped_oak_log
setblock 387 283 279 minecraft:terracotta
setblock 387 283 313 minecraft:terracotta
fill 388 283 278 389 283 278 minecraft:terracotta
fill 388 283 279 406 283 279 minecraft:red_terracotta
fill 388 283 293 388 283 295 minecraft:red_terracotta
fill 388 283 296 388 284 299 minecraft:orange_terracotta
fill 388 283 313 406 283 313 minecraft:red_terracotta
fill 388 283 314 389 283 314 minecraft:terracotta
fill 388 283 315 389 283 316 minecraft:stripped_oak_log
setblock 389 283 293 minecraft:red_terracotta
fill 389 283 294 389 283 295 minecraft:orange_terracotta
fill 389 283 300 389 283 301 minecraft:orange_terracotta
fill 389 283 302 389 283 303 minecraft:red_terracotta
fill 390 283 277 393 283 277 minecraft:terracotta
fill 390 283 278 404 283 278 minecraft:red_terracotta
fill 390 283 289 390 283 291 minecraft:red_terracotta
fill 390 283 292 390 283 293 minecraft:orange_terracotta
setblock 390 283 302 minecraft:orange_terracotta
setblock 390 283 303 minecraft:red_terracotta
fill 390 283 314 404 283 314 minecraft:red_terracotta
fill 390 283 315 393 283 315 minecraft:terracotta
setblock 390 283 316 minecraft:red_terracotta
fill 391 283 289 391 283 290 minecraft:red_terracotta
fill 391 283 291 392 283 291 minecraft:orange_terracotta
setblock 391 283 303 minecraft:orange_terracotta
setblock 391 283 316 minecraft:stripped_oak_log
fill 392 283 289 394 283 289 minecraft:red_terracotta
fill 392 283 290 394 283 290 minecraft:orange_terracotta
fill 392 283 304 393 283 304 minecraft:orange_terracotta
fill 392 283 305 393 283 305 minecraft:red_terracotta
fill 392 283 316 393 285 316 minecraft:red_terracotta
fill 394 283 276 400 283 276 minecraft:terracotta
fill 394 283 277 400 283 277 minecraft:red_terracotta
fill 394 283 305 397 284 305 minecraft:orange_terracotta
fill 394 283 315 400 283 315 minecraft:red_terracotta
fill 394 283 316 400 283 316 minecraft:terracotta
fill 395 283 289 397 283 289 minecraft:orange_terracotta
fill 397 283 290 400 283 290 minecraft:orange_terracotta
fill 398 283 289 415 283 289 minecraft:red_terracotta
fill 398 283 304 399 283 304 minecraft:orange_terracotta
fill 398 283 305 414 283 305 minecraft:red_terracotta
fill 400 283 291 401 283 291 minecraft:orange_terracotta
fill 400 283 303 401 283 303 minecraft:orange_terracotta
fill 400 283 304 414 283 304 minecraft:red_terracotta
fill 401 283 277 404 283 277 minecraft:terracotta
fill 401 283 290 415 283 290 minecraft:red_terracotta
fill 401 283 292 402 283 292 minecraft:orange_terracotta
fill 401 283 315 404 283 315 minecraft:terracotta
fill 402 283 291 415 283 291 minecraft:red_terracotta
fill 402 283 293 403 283 293 minecraft:orange_terracotta
fill 402 283 301 402 283 302 minecraft:orange_terracotta
fill 402 283 303 415 283 303 minecraft:red_terracotta
fill 403 283 292 415 283 292 minecraft:red_terracotta
fill 403 283 294 403 283 296 minecraft:orange_terracotta
fill 403 283 299 403 283 301 minecraft:orange_terracotta
fill 403 283 302 415 283 302 minecraft:red_terracotta
fill 404 283 293 416 283 295 minecraft:red_terracotta
fill 404 283 296 404 283 298 minecraft:orange_terracotta
fill 404 283 299 415 283 301 minecraft:red_terracotta
fill 405 283 278 406 283 278 minecraft:terracotta
fill 405 283 296 416 283 298 minecraft:red_terracotta
fill 405 283 314 406 283 314 minecraft:terracotta
fill 406 283 276 409 283 277 minecraft:stripped_oak_log
fill 407 283 278 415 284 278 minecraft:stripped_oak_log
setblock 407 283 279 minecraft:terracotta
setblock 407 283 313 minecraft:terracotta
fill 409 283 279 415 285 279 minecraft:stripped_oak_log
setblock 409 283 280 minecraft:terracotta
setblock 409 283 312 minecraft:terracotta
setblock 410 283 276 minecraft:red_terracotta
fill 410 283 277 411 283 277 minecraft:stripped_oak_log
fill 410 283 280 415 285 280 minecraft:stripped_oak_log
setblock 410 283 281 minecraft:terracotta
setblock 410 283 311 minecraft:terracotta
setblock 410 283 316 minecraft:red_terracotta
setblock 411 283 276 minecraft:stripped_oak_log
fill 411 283 281 416 283 281 minecraft:stripped_oak_log
setblock 411 283 282 minecraft:terracotta
setblock 411 283 310 minecraft:terracotta
setblock 411 283 316 minecraft:stripped_oak_log
fill 412 283 276 414 283 277 minecraft:red_terracotta
fill 412 283 282 415 283 282 minecraft:stripped_oak_log
setblock 412 283 283 minecraft:terracotta
setblock 412 283 309 minecraft:terracotta
setblock 412 283 315 minecraft:stripped_oak_log
fill 412 283 316 415 283 316 minecraft:red_terracotta
fill 413 283 283 414 285 283 minecraft:stripped_oak_log
setblock 413 283 284 minecraft:terracotta
setblock 413 283 308 minecraft:terracotta
fill 413 283 309 413 283 314 minecraft:stripped_oak_log
fill 413 283 315 416 283 315 minecraft:red_terracotta
fill 414 283 284 414 295 284 minecraft:stripped_oak_log
setblock 414 283 286 minecraft:terracotta
setblock 414 283 306 minecraft:terracotta
fill 414 283 308 414 284 313 minecraft:stripped_oak_log
fill 414 283 314 417 283 314 minecraft:red_terracotta
setblock 415 283 276 minecraft:red_terracotta
setblock 415 283 277 minecraft:stripped_oak_log
fill 415 283 283 415 283 286 minecraft:red_terracotta
fill 415 283 287 415 283 288 minecraft:terracotta
fill 415 283 304 415 283 305 minecraft:terracotta
fill 415 283 307 415 283 308 minecraft:stripped_oak_log
fill 415 283 309 415 283 311 minecraft:red_terracotta
setblock 415 283 312 minecraft:stripped_oak_log
fill 415 283 313 417 284 313 minecraft:red_terracotta
setblock 416 283 276 minecraft:stripped_oak_log
fill 416 283 277 416 283 280 minecraft:red_terracotta
fill 416 283 282 416 283 285 minecraft:red_terracotta
setblock 416 283 286 minecraft:stripped_oak_log
fill 416 283 287 417 284 288 minecraft:red_terracotta
fill 416 283 289 416 283 292 minecraft:terracotta
setblock 416 283 299 minecraft:red_terracotta
fill 416 283 300 416 283 303 minecraft:terracotta
setblock 416 283 306 minecraft:stripped_oak_log
fill 416 283 307 416 283 310 minecraft:red_terracotta
setblock 416 283 311 minecraft:stripped_oak_log
fill 416 283 312 417 285 312 minecraft:red_terracotta
setblock 416 283 316 minecraft:stripped_oak_log
fill 417 283 276 417 283 279 minecraft:red_terracotta
setblock 417 283 280 minecraft:stripped_oak_log
fill 417 283 281 417 283 284 minecraft:red_terracotta
setblock 417 283 285 minecraft:stripped_oak_log
fill 417 283 286 417 285 286 minecraft:red_terracotta
setblock 417 283 289 minecraft:red_terracotta
setblock 417 283 290 minecraft:stripped_oak_log
fill 417 283 291 417 285 292 minecraft:red_terracotta
fill 417 283 293 417 283 299 minecraft:terracotta
fill 417 283 303 417 283 304 minecraft:red_terracotta
setblock 417 283 305 minecraft:stripped_oak_log
fill 417 283 306 417 283 309 minecraft:red_terracotta
setblock 417 283 310 minecraft:stripped_oak_log
fill 417 283 311 417 286 311 minecraft:red_terracotta
setblock 417 283 315 minecraft:stripped_oak_log
fill 417 283 316 417 286 316 minecraft:red_terracotta
fill 376 284 275 376 287 317 minecraft:red_terracotta
fill 377 284 275 377 284 278 minecraft:red_terracotta
fill 377 284 279 378 284 279 minecraft:stripped_oak_log
fill 377 284 280 377 284 283 minecraft:red_terracotta
setblock 377 284 284 minecraft:stripped_oak_log
fill 377 284 285 377 284 288 minecraft:red_terracotta
setblock 377 284 289 minecraft:stripped_oak_log
fill 377 284 290 378 286 290 minecraft:red_terracotta
setblock 377 284 293 minecraft:red_terracotta
setblock 377 284 294 minecraft:stripped_oak_log
fill 377 284 295 377 284 298 minecraft:red_terracotta
setblock 377 284 299 minecraft:stripped_oak_log
fill 377 284 300 377 284 303 minecraft:red_terracotta
setblock 377 284 304 minecraft:stripped_oak_log
fill 377 284 305 377 284 308 minecraft:red_terracotta
setblock 377 284 309 minecraft:stripped_oak_log
fill 377 284 310 377 284 313 minecraft:red_terracotta
setblock 377 284 314 minecraft:stripped_oak_log
fill 377 284 315 379 284 317 minecraft:red_terracotta
fill 378 284 275 418 287 275 minecraft:red_terracotta
fill 378 284 280 378 285 281 minecraft:stripped_oak_log
setblock 378 284 287 minecraft:red_terracotta
setblock 378 284 288 minecraft:stripped_oak_log
fill 378 284 289 378 286 289 minecraft:red_terracotta
fill 378 284 291 378 285 291 minecraft:red_terracotta
fill 378 284 292 378 284 300 minecraft:terracotta
fill 378 284 304 378 284 307 minecraft:red_terracotta
setblock 378 284 308 minecraft:stripped_oak_log
fill 378 284 309 378 284 312 minecraft:red_terracotta
setblock 378 284 313 minecraft:stripped_oak_log
fill 378 284 314 378 287 314 minecraft:red_terracotta
fill 379 284 280 379 285 280 minecraft:stripped_oak_log
fill 379 284 289 379 284 291 minecraft:terracotta
fill 379 284 292 387 284 300 minecraft:red_terracotta
fill 379 284 301 379 284 303 minecraft:terracotta
setblock 379 284 307 minecraft:stripped_oak_log
fill 379 284 308 379 284 311 minecraft:red_terracotta
setblock 379 284 312 minecraft:stripped_oak_log
fill 379 284 313 379 287 313 minecraft:red_terracotta
fill 380 284 287 380 284 288 minecraft:terracotta
fill 380 284 289 389 284 291 minecraft:red_terracotta
fill 380 284 301 388 284 303 minecraft:red_terracotta
fill 380 284 304 380 284 305 minecraft:terracotta
setblock 380 284 315 minecraft:red_terracotta
setblock 380 284 316 minecraft:stripped_oak_log
fill 380 284 317 418 287 317 minecraft:red_terracotta
fill 381 284 285 381 284 286 minecraft:terracotta
fill 381 284 287 394 284 288 minecraft:red_terracotta
fill 381 284 304 390 284 305 minecraft:red_terracotta
fill 381 284 306 381 284 307 minecraft:terracotta
setblock 381 284 314 minecraft:red_terracotta
setblock 381 284 315 minecraft:stripped_oak_log
fill 381 284 316 381 287 316 minecraft:red_terracotta
setblock 382 284 284 minecraft:terracotta
fill 382 284 285 412 284 286 minecraft:red_terracotta
fill 382 284 306 412 284 307 minecraft:red_terracotta
setblock 382 284 308 minecraft:terracotta
fill 382 284 315 382 287 315 minecraft:red_terracotta
setblock 383 284 283 minecraft:terracotta
fill 383 284 284 411 284 284 minecraft:red_terracotta
fill 383 284 308 411 284 308 minecraft:red_terracotta
setblock 383 284 309 minecraft:terracotta
setblock 384 284 282 minecraft:terracotta
fill 384 284 283 410 284 283 minecraft:red_terracotta
fill 384 284 309 410 284 309 minecraft:red_terracotta
setblock 384 284 310 minecraft:terracotta
fill 384 284 311 384 285 311 minecraft:stripped_oak_log
setblock 385 284 281 minecraft:terracotta
fill 385 284 282 409 284 282 minecraft:red_terracotta
fill 385 284 310 409 284 310 minecraft:red_terracotta
setblock 385 284 311 minecraft:terracotta
fill 385 284 312 385 285 312 minecraft:stripped_oak_log
fill 386 284 280 387 284 280 minecraft:terracotta
fill 386 284 281 408 284 281 minecraft:red_terracotta
fill 386 284 311 408 284 311 minecraft:red_terracotta
fill 386 284 312 387 284 312 minecraft:terracotta
fill 386 284 313 387 284 315 minecraft:stripped_oak_log
fill 386 284 316 389 284 316 minecraft:red_terracotta
fill 387 284 277 387 286 277 minecraft:green_concrete
fill 388 284 279 389 284 279 minecraft:terracotta
fill 388 284 280 406 284 280 minecraft:red_terracotta
fill 388 284 292 388 284 293 minecraft:red_terracotta
fill 388 284 294 388 284 295 minecraft:orange_terracotta
setblock 388 284 300 minecraft:orange_terracotta
fill 388 284 312 406 284 312 minecraft:red_terracotta
fill 388 284 313 389 284 313 minecraft:terracotta
fill 388 284 314 389 284 315 minecraft:stripped_oak_log
fill 389 284 292 389 284 293 minecraft:orange_terracotta
fill 389 284 301 389 284 302 minecraft:orange_terracotta
setblock 389 284 303 minecraft:red_terracotta
fill 390 284 278 392 284 278 minecraft:terracotta
fill 390 284 279 404 284 279 minecraft:red_terracotta
fill 390 284 289 390 284 290 minecraft:red_terracotta
setblock 390 284 291 minecraft:orange_terracotta
setblock 390 284 303 minecraft:orange_terracotta
fill 390 284 313 404 284 313 minecraft:red_terracotta
fill 390 284 314 392 284 314 minecraft:terracotta
setblock 390 284 315 minecraft:red_terracotta
setblock 390 284 316 minecraft:stripped_oak_log
setblock 391 284 289 minecraft:red_terracotta
setblock 391 284 290 minecraft:orange_terracotta
fill 391 284 304 392 284 304 minecraft:orange_terracotta
fill 391 284 305 392 284 305 minecraft:red_terracotta
setblock 391 284 315 minecraft:stripped_oak_log
fill 391 284 316 391 285 316 minecraft:red_terracotta
fill 392 284 289 394 284 289 minecraft:orange_terracotta
fill 392 284 315 392 285 315 minecraft:red_terracotta
fill 393 284 277 401 284 277 minecraft:terracotta
fill 393 284 278 401 284 278 minecraft:red_terracotta
setblock 393 284 305 minecraft:orange_terracotta
fill 393 284 314 401 284 314 minecraft:red_terracotta
fill 393 284 315 401 284 315 minecraft:terracotta
setblock 394 284 276 minecraft:red_terracotta
setblock 394 284 316 minecraft:red_terracotta
setblock 395 284 276 minecraft:stripped_oak_log
fill 395 284 287 413 284 287 minecraft:red_terracotta
fill 395 284 288 398 284 288 minecraft:orange_terracotta
setblock 395 284 316 minecraft:stripped_oak_log
fill 396 284 276 397 286 276 minecraft:red_terracotta
fill 396 284 316 399 284 316 minecraft:red_terracotta
fill 398 284 289 400 284 289 minecraft:orange_terracotta
fill 398 284 305 399 284 305 minecraft:orange_terracotta
fill 399 284 288 413 284 288 minecraft:red_terracotta
fill 400 284 304 401 284 304 minecraft:orange_terracotta
fill 400 284 305 413 284 305 minecraft:red_terracotta
fill 401 284 289 414 284 289 minecraft:red_terracotta
fill 401 284 290 402 284 290 minecraft:orange_terracotta
fill 402 284 278 404 284 278 minecraft:terracotta
fill 402 284 291 403 284 291 minecraft:orange_terracotta
setblock 402 284 303 minecraft:orange_terracotta
fill 402 284 304 413 284 304 minecraft:red_terracotta
fill 402 284 314 404 284 314 minecraft:terracotta
fill 403 284 290 414 284 290 minecraft:red_terracotta
setblock 403 284 292 minecraft:orange_terracotta
setblock 403 284 302 minecraft:orange_terracotta
fill 403 284 303 414 284 303 minecraft:red_terracotta
fill 404 284 291 414 284 292 minecraft:red_terracotta
fill 404 284 293 404 284 295 minecraft:orange_terracotta
fill 404 284 299 404 284 301 minecraft:orange_terracotta
fill 404 284 302 414 284 302 minecraft:red_terracotta
fill 405 284 279 406 284 279 minecraft:terracotta
fill 405 284 293 415 284 294 minecraft:red_terracotta
fill 405 284 295 405 284 298 minecraft:orange_terracotta
fill 405 284 299 414 284 301 minecraft:red_terracotta
fill 405 284 313 406 284 313 minecraft:terracotta
fill 406 284 276 406 285 278 minecraft:stripped_oak_log
fill 406 284 295 415 284 298 minecraft:red_terracotta
fill 407 284 276 407 284 277 minecraft:stripped_oak_log
fill 407 284 279 408 285 279 minecraft:stripped_oak_log
fill 407 284 280 408 284 280 minecraft:terracotta
fill 407 284 312 408 284 312 minecraft:terracotta
fill 408 284 276 409 284 276 minecraft:red_terracotta
fill 408 284 277 410 284 277 minecraft:stripped_oak_log
fill 409 284 280 409 285 280 minecraft:stripped_oak_log
setblock 409 284 281 minecraft:terracotta
setblock 409 284 311 minecraft:terracotta
setblock 409 284 316 minecraft:red_terracotta
setblock 410 284 276 minecraft:stripped_oak_log
fill 410 284 281 415 285 281 minecraft:stripped_oak_log
setblock 410 284 282 minecraft:terracotta
setblock 410 284 310 minecraft:terracotta
setblock 410 284 316 minecraft:stripped_oak_log
fill 411 284 276 413 284 277 minecraft:red_terracotta
fill 411 284 282 414 285 282 minecraft:stripped_oak_log
setblock 411 284 283 minecraft:terracotta
setblock 411 284 309 minecraft:terracotta
setblock 411 284 315 minecraft:stripped_oak_log
fill 411 284 316 414 284 316 minecraft:red_terracotta
fill 412 284 283 412 285 283 minecraft:stripped_oak_log
setblock 412 284 284 minecraft:terracotta
setblock 412 284 308 minecraft:terracotta
setblock 412 284 309 minecraft:brown_terracotta
fill 412 284 315 415 284 315 minecraft:red_terracotta
fill 413 284 284 413 285 284 minecraft:stripped_oak_log
fill 413 284 285 413 284 286 minecraft:terracotta
fill 413 284 306 413 284 307 minecraft:terracotta
fill 413 284 308 413 285 313 minecraft:stripped_oak_log
fill 413 284 314 416 284 314 minecraft:red_terracotta
setblock 414 284 276 minecraft:red_terracotta
setblock 414 284 277 minecraft:stripped_oak_log
fill 414 284 285 414 285 286 minecraft:stripped_oak_log
fill 414 284 287 414 284 288 minecraft:terracotta
fill 414 284 304 414 284 305 minecraft:terracotta
fill 414 284 306 415 284 306 minecraft:brown_terracotta
fill 414 284 307 415 300 307 minecraft:stripped_oak_log
setblock 415 284 276 minecraft:stripped_oak_log
fill 415 284 277 418 285 277 minecraft:red_terracotta
fill 415 284 282 415 284 285 minecraft:red_terracotta
setblock 415 284 286 minecraft:stripped_oak_log
fill 415 284 287 415 286 288 minecraft:red_terracotta
fill 415 284 289 415 284 291 minecraft:terracotta
setblock 415 284 292 minecraft:red_terracotta
fill 415 284 299 415 284 300 minecraft:red_terracotta
fill 415 284 301 415 284 303 minecraft:terracotta
fill 415 284 304 415 284 305 minecraft:brown_terracotta
fill 415 284 308 415 284 310 minecraft:red_terracotta
setblock 415 284 311 minecraft:stripped_oak_log
fill 415 284 312 415 287 312 minecraft:red_terracotta
setblock 415 284 316 minecraft:stripped_oak_log
fill 416 284 276 418 286 276 minecraft:red_terracotta
fill 416 284 278 416 284 279 minecraft:red_terracotta
setblock 416 284 280 minecraft:stripped_oak_log
fill 416 284 281 416 284 284 minecraft:red_terracotta
setblock 416 284 285 minecraft:stripped_oak_log
fill 416 284 286 416 287 286 minecraft:red_terracotta
setblock 416 284 289 minecraft:red_terracotta
setblock 416 284 290 minecraft:stripped_oak_log
fill 416 284 291 416 287 291 minecraft:red_terracotta
fill 416 284 292 416 284 300 minecraft:terracotta
fill 416 284 306 416 284 309 minecraft:red_terracotta
setblock 416 284 310 minecraft:stripped_oak_log
fill 416 284 311 416 287 311 minecraft:red_terracotta
setblock 416 284 315 minecraft:stripped_oak_log
fill 416 284 316 416 287 316 minecraft:red_terracotta
fill 417 284 278 418 284 278 minecraft:red_terracotta
setblock 417 284 279 minecraft:stripped_oak_log
fill 417 284 280 418 284 283 minecraft:red_terracotta
setblock 417 284 284 minecraft:stripped_oak_log
fill 417 284 285 418 287 285 minecraft:red_terracotta
setblock 417 284 289 minecraft:stripped_oak_log
fill 417 284 290 418 287 290 minecraft:red_terracotta
fill 417 284 293 418 284 293 minecraft:red_terracotta
setblock 417 284 294 minecraft:stripped_oak_log
fill 417 284 295 418 286 296 minecraft:red_terracotta
fill 417 284 303 418 284 303 minecraft:red_terracotta
setblock 417 284 304 minecraft:stripped_oak_log
fill 417 284 305 418 284 308 minecraft:red_terracotta
setblock 417 284 309 minecraft:stripped_oak_log
fill 417 284 310 418 287 310 minecraft:red_terracotta
setblock 417 284 314 minecraft:stripped_oak_log
fill 417 284 315 418 287 315 minecraft:red_terracotta
fill 418 284 279 418 287 279 minecraft:red_terracotta
fill 418 284 284 418 287 284 minecraft:red_terracotta
fill 418 284 286 418 287 289 minecraft:red_terracotta
fill 418 284 291 418 287 292 minecraft:red_terracotta
fill 418 284 294 418 287 294 minecraft:red_terracotta
fill 418 284 297 418 287 302 minecraft:red_terracotta
fill 418 284 304 418 287 304 minecraft:red_terracotta
fill 418 284 309 418 287 309 minecraft:red_terracotta
fill 418 284 311 418 287 314 minecraft:red_terracotta
fill 418 284 316 418 287 316 minecraft:red_terracotta
fill 377 285 275 377 285 277 minecraft:red_terracotta
setblock 377 285 278 minecraft:stripped_oak_log
fill 377 285 279 377 285 282 minecraft:red_terracotta
setblock 377 285 283 minecraft:stripped_oak_log
fill 377 285 284 377 285 287 minecraft:red_terracotta
setblock 377 285 288 minecraft:stripped_oak_log
fill 377 285 289 377 288 289 minecraft:red_terracotta
setblock 377 285 293 minecraft:stripped_oak_log
fill 377 285 294 377 285 297 minecraft:red_terracotta
setblock 377 285 298 minecraft:stripped_oak_log
fill 377 285 299 377 285 302 minecraft:red_terracotta
setblock 377 285 303 minecraft:stripped_oak_log
fill 377 285 304 377 285 307 minecraft:red_terracotta
setblock 377 285 308 minecraft:stripped_oak_log
fill 377 285 309 377 285 312 minecraft:red_terracotta
setblock 377 285 313 minecraft:stripped_oak_log
fill 377 285 314 377 286 317 minecraft:red_terracotta
setblock 378 285 276 minecraft:red_terracotta
setblock 378 285 279 minecraft:stripped_oak_log
setblock 378 285 288 minecraft:red_terracotta
setblock 378 285 292 minecraft:stripped_oak_log
fill 378 285 293 378 288 293 minecraft:red_terracotta
fill 378 285 304 378 285 306 minecraft:red_terracotta
setblock 378 285 307 minecraft:stripped_oak_log
fill 378 285 308 378 285 311 minecraft:red_terracotta
setblock 378 285 312 minecraft:stripped_oak_log
fill 378 285 313 378 288 313 minecraft:red_terracotta
fill 378 285 315 378 285 317 minecraft:red_terracotta
setblock 379 285 276 minecraft:stripped_oak_log
fill 379 285 291 379 285 301 minecraft:terracotta
fill 379 285 307 379 285 310 minecraft:red_terracotta
setblock 379 285 311 minecraft:stripped_oak_log
fill 379 285 312 379 288 312 minecraft:red_terracotta
setblock 379 285 315 minecraft:red_terracotta
setblock 379 285 316 minecraft:stripped_oak_log
fill 379 285 317 379 287 317 minecraft:red_terracotta
fill 380 285 278 380 290 278 minecraft:brown_terracotta
fill 380 285 288 380 285 290 minecraft:terracotta
fill 380 285 291 386 285 301 minecraft:red_terracotta
fill 380 285 302 380 285 304 minecraft:terracotta
setblock 380 285 315 minecraft:stripped_oak_log
fill 380 285 316 380 288 316 minecraft:red_terracotta
fill 381 285 277 381 290 277 minecraft:brown_terracotta
fill 381 285 279 381 290 279 minecraft:brown_terracotta
setblock 381 285 287 minecraft:terracotta
fill 381 285 288 389 285 290 minecraft:red_terracotta
fill 381 285 302 388 285 304 minecraft:red_terracotta
setblock 381 285 305 minecraft:terracotta
setblock 381 285 314 minecraft:stripped_oak_log
fill 381 285 315 381 288 315 minecraft:red_terracotta
fill 382 285 278 382 290 278 minecraft:brown_terracotta
fill 382 285 285 382 285 286 minecraft:terracotta
fill 382 285 287 394 285 287 minecraft:red_terracotta
fill 382 285 305 391 285 305 minecraft:red_terracotta
fill 382 285 306 382 285 307 minecraft:terracotta
fill 382 285 316 383 285 316 minecraft:red_terracotta
setblock 383 285 284 minecraft:terracotta
fill 383 285 285 411 285 286 minecraft:red_terracotta
fill 383 285 306 393 285 307 minecraft:red_terracotta
setblock 383 285 308 minecraft:terracotta
fill 383 285 315 384 285 315 minecraft:red_terracotta
setblock 384 285 283 minecraft:terracotta
fill 384 285 284 410 285 284 minecraft:red_terracotta
fill 384 285 308 410 285 308 minecraft:red_terracotta
setblock 384 285 309 minecraft:terracotta
fill 384 285 310 384 296 310 minecraft:stripped_oak_log
fill 384 285 312 384 285 314 minecraft:stripped_oak_log
setblock 384 285 316 minecraft:stripped_oak_log
setblock 385 285 282 minecraft:terracotta
fill 385 285 283 409 285 283 minecraft:red_terracotta
fill 385 285 309 409 285 309 minecraft:red_terracotta
setblock 385 285 310 minecraft:terracotta
fill 385 285 311 385 296 311 minecraft:stripped_oak_log
fill 385 285 313 386 285 315 minecraft:stripped_oak_log
fill 385 285 316 388 285 316 minecraft:red_terracotta
fill 386 285 281 387 285 281 minecraft:terracotta
fill 386 285 282 408 285 282 minecraft:red_terracotta
fill 386 285 310 408 285 310 minecraft:red_terracotta
fill 386 285 311 387 285 311 minecraft:terracotta
fill 386 285 312 387 285 312 minecraft:stripped_oak_log
fill 387 285 291 387 285 293 minecraft:red_terracotta
fill 387 285 294 387 285 299 minecraft:yellow_terracotta
fill 387 285 300 387 285 301 minecraft:red_terracotta
fill 387 285 313 388 285 314 minecraft:stripped_oak_log
fill 387 285 315 389 285 315 minecraft:red_terracotta
setblock 388 285 280 minecraft:terracotta
fill 388 285 281 406 285 281 minecraft:red_terracotta
setblock 388 285 291 minecraft:red_terracotta
fill 388 285 292 388 285 293 minecraft:yellow_terracotta
fill 388 285 300 388 285 301 minecraft:yellow_terracotta
fill 388 285 311 406 285 311 minecraft:red_terracotta
setblock 388 285 312 minecraft:terracotta
fill 389 285 279 391 285 279 minecraft:terracotta
fill 389 285 280 405 285 280 minecraft:red_terracotta
setblock 389 285 291 minecraft:yellow_terracotta
fill 389 285 302 389 285 303 minecraft:yellow_terracotta
fill 389 285 304 389 286 304 minecraft:red_terracotta
fill 389 285 312 405 285 312 minecraft:red_terracotta
fill 389 285 313 391 285 313 minecraft:terracotta
fill 389 285 314 391 285 314 minecraft:stripped_oak_log
setblock 389 285 316 minecraft:stripped_oak_log
fill 390 285 288 390 285 289 minecraft:red_terracotta
setblock 390 285 290 minecraft:yellow_terracotta
fill 390 285 304 391 285 304 minecraft:yellow_terracotta
setblock 390 285 315 minecraft:stripped_oak_log
fill 390 285 316 390 288 316 minecraft:red_terracotta
setblock 391 285 288 minecraft:red_terracotta
setblock 391 285 289 minecraft:yellow_terracotta
fill 391 285 315 391 288 315 minecraft:red_terracotta
fill 392 285 276 393 285 276 minecraft:red_terracotta
fill 392 285 278 402 285 278 minecraft:terracotta
fill 392 285 279 402 285 279 minecraft:red_terracotta
fill 392 285 288 394 285 288 minecraft:yellow_terracotta
fill 392 285 305 393 285 305 minecraft:yellow_terracotta
fill 392 285 313 402 285 313 minecraft:red_terracotta
fill 392 285 314 402 285 314 minecraft:terracotta
fill 393 285 315 394 285 315 minecraft:red_terracotta
setblock 394 285 276 minecraft:stripped_oak_log
fill 394 285 306 399 285 306 minecraft:yellow_terracotta
fill 394 285 307 411 285 307 minecraft:red_terracotta
setblock 394 285 316 minecraft:stripped_oak_log
fill 395 285 276 395 288 276 minecraft:red_terracotta
fill 395 285 287 398 285 287 minecraft:yellow_terracotta
setblock 395 285 315 minecraft:stripped_oak_log
fill 395 285 316 398 285 316 minecraft:red_terracotta
fill 396 285 315 397 287 315 minecraft:red_terracotta
setblock 398 285 276 minecraft:red_terracotta
fill 399 285 287 412 285 287 minecraft:red_terracotta
fill 399 285 288 401 285 288 minecraft:yellow_terracotta
setblock 399 285 316 minecraft:stripped_oak_log
fill 400 285 305 401 285 305 minecraft:yellow_terracotta
fill 400 285 306 411 285 306 minecraft:red_terracotta
fill 400 285 316 400 288 316 minecraft:red_terracotta
fill 401 285 289 402 285 289 minecraft:yellow_terracotta
fill 402 285 288 413 285 288 minecraft:red_terracotta
setblock 402 285 304 minecraft:yellow_terracotta
fill 402 285 305 412 285 305 minecraft:red_terracotta
fill 403 285 279 405 285 279 minecraft:terracotta
fill 403 285 289 413 285 289 minecraft:red_terracotta
setblock 403 285 290 minecraft:yellow_terracotta
setblock 403 285 303 minecraft:yellow_terracotta
fill 403 285 304 413 285 304 minecraft:red_terracotta
fill 403 285 313 405 285 313 minecraft:terracotta
fill 404 285 290 413 285 290 minecraft:red_terracotta
fill 404 285 291 404 285 292 minecraft:yellow_terracotta
setblock 404 285 302 minecraft:yellow_terracotta
fill 404 285 303 413 285 303 minecraft:red_terracotta
fill 405 285 291 414 285 291 minecraft:red_terracotta
fill 405 285 292 405 285 294 minecraft:yellow_terracotta
fill 405 285 299 405 285 301 minecraft:yellow_terracotta
fill 405 285 302 413 285 302 minecraft:red_terracotta
setblock 406 285 279 minecraft:stripped_oak_log
setblock 406 285 280 minecraft:terracotta
fill 406 285 292 414 285 294 minecraft:red_terracotta
fill 406 285 295 406 285 298 minecraft:yellow_terracotta
fill 406 285 299 414 285 301 minecraft:red_terracotta
setblock 406 285 312 minecraft:terracotta
fill 407 285 276 408 285 276 minecraft:red_terracotta
fill 407 285 277 409 285 278 minecraft:stripped_oak_log
fill 407 285 280 408 285 280 minecraft:stripped_oak_log
fill 407 285 281 408 285 281 minecraft:terracotta
fill 407 285 295 414 285 298 minecraft:red_terracotta
fill 407 285 311 408 285 311 minecraft:terracotta
fill 407 285 316 408 285 316 minecraft:red_terracotta
setblock 409 285 276 minecraft:stripped_oak_log
fill 409 285 281 409 295 281 minecraft:stripped_oak_log
setblock 409 285 282 minecraft:terracotta
setblock 409 285 310 minecraft:terracotta
setblock 409 285 315 minecraft:red_terracotta
setblock 409 285 316 minecraft:stripped_oak_log
fill 410 285 276 412 285 277 minecraft:red_terracotta
fill 410 285 278 412 285 278 minecraft:stripped_oak_log
fill 410 285 282 410 295 282 minecraft:stripped_oak_log
setblock 410 285 283 minecraft:terracotta
setblock 410 285 309 minecraft:terracotta
setblock 410 285 315 minecraft:stripped_oak_log
fill 410 285 316 413 285 316 minecraft:red_terracotta
fill 411 285 283 411 295 283 minecraft:stripped_oak_log
setblock 411 285 284 minecraft:terracotta
setblock 411 285 308 minecraft:terracotta
setblock 411 285 314 minecraft:stripped_oak_log
fill 411 285 315 414 285 315 minecraft:red_terracotta
fill 412 285 284 412 295 284 minecraft:stripped_oak_log
fill 412 285 285 412 285 286 minecraft:terracotta
fill 412 285 306 412 285 307 minecraft:terracotta
fill 412 285 314 415 285 314 minecraft:red_terracotta
setblock 413 285 276 minecraft:red_terracotta
setblock 413 285 277 minecraft:stripped_oak_log
fill 413 285 278 416 285 278 minecraft:red_terracotta
fill 413 285 285 413 285 286 minecraft:stripped_oak_log
setblock 413 285 287 minecraft:terracotta
setblock 413 285 305 minecraft:terracotta
fill 413 285 307 413 300 307 minecraft:stripped_oak_log
setblock 414 285 276 minecraft:stripped_oak_log
setblock 414 285 277 minecraft:red_terracotta
setblock 414 285 287 minecraft:red_terracotta
fill 414 285 288 414 285 290 minecraft:terracotta
fill 414 285 302 414 285 304 minecraft:terracotta
fill 414 285 308 414 285 311 minecraft:stripped_oak_log
fill 414 285 312 414 287 313 minecraft:red_terracotta
setblock 414 285 316 minecraft:stripped_oak_log
fill 415 285 276 415 288 276 minecraft:red_terracotta
fill 415 285 282 415 285 284 minecraft:red_terracotta
setblock 415 285 285 minecraft:stripped_oak_log
setblock 415 285 286 minecraft:red_terracotta
setblock 415 285 289 minecraft:red_terracotta
setblock 415 285 290 minecraft:stripped_oak_log
fill 415 285 291 415 285 301 minecraft:terracotta
fill 415 285 308 415 285 309 minecraft:red_terracotta
setblock 415 285 310 minecraft:stripped_oak_log
fill 415 285 311 415 288 311 minecraft:red_terracotta
fill 415 285 313 416 285 313 minecraft:red_terracotta
setblock 415 285 315 minecraft:stripped_oak_log
fill 415 285 316 415 288 316 minecraft:red_terracotta
setblock 416 285 279 minecraft:stripped_oak_log
fill 416 285 280 416 285 283 minecraft:red_terracotta
setblock 416 285 284 minecraft:stripped_oak_log
setblock 416 285 285 minecraft:red_terracotta
fill 416 285 287 416 285 288 minecraft:red_terracotta
setblock 416 285 289 minecraft:stripped_oak_log
fill 416 285 290 416 288 290 minecraft:red_terracotta
fill 416 285 292 416 285 293 minecraft:red_terracotta
setblock 416 285 294 minecraft:stripped_oak_log
fill 416 285 295 416 288 295 minecraft:red_terracotta
fill 416 285 306 416 285 308 minecraft:red_terracotta
setblock 416 285 309 minecraft:stripped_oak_log
fill 416 285 310 416 288 310 minecraft:red_terracotta
setblock 416 285 314 minecraft:stripped_oak_log
fill 416 285 315 416 288 315 minecraft:red_terracotta
setblock 417 285 278 minecraft:stripped_oak_log
fill 417 285 279 417 285 282 minecraft:red_terracotta
setblock 417 285 283 minecraft:stripped_oak_log
setblock 417 285 284 minecraft:red_terracotta
setblock 417 285 287 minecraft:red_terracotta
setblock 417 285 288 minecraft:stripped_oak_log
fill 417 285 289 417 288 289 minecraft:red_terracotta
setblock 417 285 293 minecraft:stripped_oak_log
fill 417 285 294 417 288 294 minecraft:red_terracotta
setblock 417 285 297 minecraft:red_terracotta
setblock 417 285 303 minecraft:stripped_oak_log
fill 417 285 304 417 285 307 minecraft:red_terracotta
setblock 417 285 308 minecraft:stripped_oak_log
fill 417 285 309 417 288 309 minecraft:red_terracotta
setblock 417 285 313 minecraft:stripped_oak_log
fill 417 285 314 417 288 314 minecraft:red_terracotta
fill 418 285 278 418 287 278 minecraft:red_terracotta
fill 418 285 280 418 287 283 minecraft:red_terracotta
fill 418 285 293 418 287 293 minecraft:red_terracotta
fill 418 285 303 418 287 303 minecraft:red_terracotta
fill 418 285 305 418 287 308 minecraft:red_terracotta
fill 377 286 275 377 286 276 minecraft:red_terracotta
setblock 377 286 277 minecraft:stripped_oak_log
fill 377 286 278 377 286 280 minecraft:red_terracotta
fill 377 286 283 377 286 286 minecraft:red_terracotta
setblock 377 286 287 minecraft:stripped_oak_log
fill 377 286 288 377 288 288 minecraft:red_terracotta
setblock 377 286 291 minecraft:red_terracotta
setblock 377 286 292 minecraft:stripped_oak_log
fill 377 286 293 377 286 296 minecraft:red_terracotta
setblock 377 286 297 minecraft:stripped_oak_log
fill 377 286 298 377 286 301 minecraft:red_terracotta
setblock 377 286 302 minecraft:stripped_oak_log
fill 377 286 303 377 286 306 minecraft:red_terracotta
setblock 377 286 307 minecraft:stripped_oak_log
fill 377 286 308 377 286 311 minecraft:red_terracotta
setblock 377 286 312 minecraft:stripped_oak_log
fill 377 286 313 377 289 313 minecraft:red_terracotta
setblock 378 286 276 minecraft:stripped_oak_log
setblock 378 286 291 minecraft:stripped_oak_log
fill 378 286 292 378 288 292 minecraft:red_terracotta
fill 378 286 294 378 286 295 minecraft:red_terracotta
fill 378 286 304 378 286 305 minecraft:red_terracotta
setblock 378 286 306 minecraft:stripped_oak_log
fill 378 286 307 378 286 310 minecraft:red_terracotta
setblock 378 286 311 minecraft:stripped_oak_log
fill 378 286 312 378 289 312 minecraft:red_terracotta
setblock 378 286 315 minecraft:red_terracotta
setblock 378 286 316 minecraft:stripped_oak_log
fill 378 286 317 378 287 317 minecraft:red_terracotta
fill 379 286 276 379 288 276 minecraft:red_terracotta
fill 379 286 308 379 286 309 minecraft:red_terracotta
setblock 379 286 310 minecraft:stripped_oak_log
fill 379 286 311 379 288 311 minecraft:red_terracotta
setblock 379 286 314 minecraft:red_terracotta
setblock 379 286 315 minecraft:stripped_oak_log
fill 379 286 316 379 289 316 minecraft:red_terracotta
fill 380 286 291 380 286 301 minecraft:terracotta
setblock 380 286 314 minecraft:stripped_oak_log
fill 380 286 315 380 289 315 minecraft:red_terracotta
fill 381 286 288 381 286 290 minecraft:terracotta
fill 381 286 291 385 286 301 minecraft:red_terracotta
fill 381 286 302 381 286 304 minecraft:terracotta
fill 381 286 314 381 287 314 minecraft:red_terracotta
fill 382 286 287 382 286 288 minecraft:terracotta
fill 382 286 289 388 286 290 minecraft:red_terracotta
fill 382 286 302 387 286 303 minecraft:red_terracotta
fill 382 286 304 382 286 305 minecraft:terracotta
setblock 382 286 316 minecraft:red_terracotta
fill 383 286 285 383 286 286 minecraft:terracotta
fill 383 286 287 389 286 288 minecraft:red_terracotta
fill 383 286 304 388 286 305 minecraft:red_terracotta
fill 383 286 306 383 286 307 minecraft:terracotta
setblock 383 286 315 minecraft:red_terracotta
setblock 383 286 316 minecraft:stripped_oak_log
fill 384 286 284 384 286 285 minecraft:terracotta
fill 384 286 286 393 286 286 minecraft:red_terracotta
fill 384 286 306 391 286 306 minecraft:red_terracotta
setblock 384 286 307 minecraft:shroomlight
setblock 384 286 308 minecraft:terracotta
setblock 384 286 309 minecraft:shroomlight
setblock 384 286 311 minecraft:shroomlight
fill 384 286 312 384 296 312 minecraft:stripped_oak_log
setblock 384 286 313 minecraft:shroomlight
fill 384 286 314 384 296 314 minecraft:stripped_oak_log
setblock 384 286 315 minecraft:shroomlight
fill 384 286 316 384 289 316 minecraft:red_terracotta
fill 385 286 283 385 286 284 minecraft:terracotta
fill 385 286 285 407 286 285 minecraft:red_terracotta
setblock 385 286 307 minecraft:red_terracotta
setblock 385 286 308 minecraft:shroomlight
setblock 385 286 309 minecraft:terracotta
setblock 385 286 310 minecraft:shroomlight
setblock 385 286 312 minecraft:shroomlight
fill 385 286 313 385 296 313 minecraft:stripped_oak_log
setblock 385 286 314 minecraft:shroomlight
fill 385 286 315 385 289 315 minecraft:red_terracotta
setblock 385 286 316 minecraft:shroomlight
fill 386 286 282 386 286 283 minecraft:terracotta
fill 386 286 284 408 286 284 minecraft:red_terracotta
fill 386 286 291 386 286 294 minecraft:red_terracotta
fill 386 286 295 386 287 298 minecraft:orange_terracotta
fill 386 286 299 386 286 301 minecraft:red_terracotta
setblock 386 286 307 minecraft:shroomlight
setblock 386 286 308 minecraft:red_terracotta
setblock 386 286 309 minecraft:shroomlight
setblock 386 286 310 minecraft:terracotta
setblock 386 286 311 minecraft:shroomlight
fill 386 286 312 386 296 312 minecraft:stripped_oak_log
setblock 386 286 313 minecraft:shroomlight
fill 386 286 314 386 296 314 minecraft:stripped_oak_log
setblock 386 286 315 minecraft:shroomlight
fill 386 286 316 386 287 316 minecraft:red_terracotta
setblock 387 286 282 minecraft:terracotta
fill 387 286 283 407 286 283 minecraft:red_terracotta
setblock 387 286 291 minecraft:red_terracotta
fill 387 286 292 387 286 294 minecraft:orange_terracotta
fill 387 286 299 387 286 301 minecraft:orange_terracotta
fill 387 286 307 387 287 307 minecraft:red_terracotta
setblock 387 286 308 minecraft:shroomlight
setblock 387 286 309 minecraft:red_terracotta
setblock 387 286 310 minecraft:shroomlight
fill 387 286 311 387 296 311 minecraft:stripped_oak_log
setblock 387 286 312 minecraft:shroomlight
fill 387 286 313 387 296 313 minecraft:stripped_oak_log
setblock 387 286 314 minecraft:shroomlight
fill 387 286 315 387 287 315 minecraft:red_terracotta
setblock 387 286 316 minecraft:shroomlight
fill 388 286 281 389 286 281 minecraft:terracotta
fill 388 286 282 406 286 282 minecraft:red_terracotta
setblock 388 286 291 minecraft:orange_terracotta
setblock 388 286 302 minecraft:orange_terracotta
setblock 388 286 303 minecraft:red_terracotta
setblock 388 286 307 minecraft:shroomlight
fill 388 286 308 388 287 308 minecraft:red_terracotta
setblock 388 286 309 minecraft:shroomlight
setblock 388 286 310 minecraft:red_terracotta
setblock 388 286 311 minecraft:shroomlight
fill 388 286 312 388 296 312 minecraft:stripped_oak_log
setblock 388 286 313 minecraft:shroomlight
setblock 388 286 314 minecraft:stripped_oak_log
setblock 388 286 315 minecraft:shroomlight
setblock 388 286 316 minecraft:stripped_oak_log
fill 389 286 280 391 286 280 minecraft:terracotta
fill 389 286 289 389 286 290 minecraft:orange_terracotta
setblock 389 286 303 minecraft:orange_terracotta
fill 389 286 305 390 286 305 minecraft:red_terracotta
fill 389 286 307 389 287 307 minecraft:red_terracotta
setblock 389 286 308 minecraft:shroomlight
setblock 389 286 309 minecraft:red_terracotta
setblock 389 286 310 minecraft:shroomlight
setblock 389 286 311 minecraft:terracotta
setblock 389 286 312 minecraft:shroomlight
fill 389 286 313 389 296 313 minecraft:stripped_oak_log
setblock 389 286 314 minecraft:shroomlight
setblock 389 286 315 minecraft:stripped_oak_log
setblock 389 286 316 minecraft:shroomlight
fill 390 286 276 392 286 276 minecraft:red_terracotta
fill 390 286 281 404 286 281 minecraft:red_terracotta
fill 390 286 287 391 286 287 minecraft:red_terracotta
fill 390 286 288 390 286 289 minecraft:orange_terracotta
setblock 390 286 304 minecraft:orange_terracotta
setblock 390 286 307 minecraft:shroomlight
fill 390 286 308 390 287 308 minecraft:red_terracotta
setblock 390 286 309 minecraft:shroomlight
setblock 390 286 310 minecraft:red_terracotta
setblock 390 286 311 minecraft:shroomlight
setblock 390 286 312 minecraft:terracotta
setblock 390 286 313 minecraft:shroomlight
setblock 390 286 314 minecraft:stripped_oak_log
setblock 390 286 315 minecraft:shroomlight
setblock 391 286 288 minecraft:orange_terracotta
setblock 391 286 305 minecraft:orange_terracotta
fill 391 286 307 391 287 307 minecraft:red_terracotta
setblock 391 286 308 minecraft:shroomlight
fill 391 286 309 391 287 309 minecraft:red_terracotta
setblock 391 286 310 minecraft:shroomlight
setblock 391 286 311 minecraft:red_terracotta
setblock 391 286 312 minecraft:shroomlight
fill 391 286 313 391 296 313 minecraft:stripped_oak_log
setblock 391 286 314 minecraft:shroomlight
setblock 391 286 316 minecraft:shroomlight
fill 392 286 279 402 286 279 minecraft:terracotta
fill 392 286 280 402 286 280 minecraft:red_terracotta
fill 392 286 287 394 286 287 minecraft:orange_terracotta
fill 392 286 306 394 286 306 minecraft:orange_terracotta
setblock 392 286 307 minecraft:shroomlight
fill 392 286 308 408 286 308 minecraft:red_terracotta
setblock 392 286 309 minecraft:shroomlight
fill 392 286 310 406 286 310 minecraft:red_terracotta
setblock 392 286 311 minecraft:shroomlight
fill 392 286 312 402 286 312 minecraft:red_terracotta
setblock 392 286 313 minecraft:shroomlight
fill 392 286 314 394 286 314 minecraft:red_terracotta
setblock 392 286 315 minecraft:shroomlight
setblock 392 286 316 minecraft:red_terracotta
setblock 393 286 276 minecraft:stripped_oak_log
fill 393 286 307 394 286 307 minecraft:red_terracotta
fill 393 286 309 407 286 309 minecraft:red_terracotta
fill 393 286 311 404 286 311 minecraft:red_terracotta
fill 393 286 313 402 286 313 minecraft:terracotta
setblock 393 286 315 minecraft:red_terracotta
setblock 393 286 316 minecraft:stripped_oak_log
fill 394 286 276 394 289 276 minecraft:red_terracotta
fill 394 286 286 399 286 286 minecraft:orange_terracotta
setblock 394 286 315 minecraft:stripped_oak_log
fill 394 286 316 397 286 316 minecraft:red_terracotta
fill 395 286 307 398 287 307 minecraft:orange_terracotta
setblock 395 286 314 minecraft:stripped_oak_log
fill 395 286 315 395 289 315 minecraft:red_terracotta
setblock 398 286 276 minecraft:stripped_oak_log
setblock 398 286 315 minecraft:red_terracotta
setblock 398 286 316 minecraft:stripped_oak_log
fill 399 286 276 399 289 276 minecraft:red_terracotta
fill 399 286 287 401 286 287 minecraft:orange_terracotta
fill 399 286 306 401 286 306 minecraft:orange_terracotta
fill 399 286 307 409 286 307 minecraft:red_terracotta
fill 399 286 316 399 289 316 minecraft:red_terracotta
fill 400 286 286 408 286 286 minecraft:red_terracotta
fill 402 286 287 407 286 287 minecraft:red_terracotta
fill 402 286 288 403 286 288 minecraft:orange_terracotta
setblock 402 286 305 minecraft:orange_terracotta
fill 402 286 306 410 286 306 minecraft:red_terracotta
fill 403 286 280 405 286 280 minecraft:terracotta
fill 403 286 289 404 286 289 minecraft:orange_terracotta
fill 403 286 304 404 286 304 minecraft:orange_terracotta
fill 403 286 305 411 286 305 minecraft:red_terracotta
fill 403 286 312 405 286 312 minecraft:terracotta
fill 404 286 288 411 286 288 minecraft:red_terracotta
fill 404 286 290 405 286 290 minecraft:orange_terracotta
fill 404 286 303 405 286 303 minecraft:orange_terracotta
fill 405 286 276 406 287 276 minecraft:red_terracotta
setblock 405 286 281 minecraft:terracotta
fill 405 286 289 412 286 289 minecraft:red_terracotta
setblock 405 286 291 minecraft:orange_terracotta
setblock 405 286 302 minecraft:orange_terracotta
fill 405 286 304 411 286 304 minecraft:red_terracotta
fill 405 286 311 406 286 311 minecraft:terracotta
setblock 406 286 277 minecraft:shroomlight
fill 406 286 278 406 292 278 minecraft:stripped_oak_log
setblock 406 286 279 minecraft:shroomlight
fill 406 286 280 406 293 280 minecraft:stripped_oak_log
setblock 406 286 281 minecraft:shroomlight
fill 406 286 290 412 286 291 minecraft:red_terracotta
fill 406 286 292 406 286 294 minecraft:orange_terracotta
fill 406 286 299 406 286 301 minecraft:orange_terracotta
fill 406 286 302 412 286 303 minecraft:red_terracotta
fill 406 286 316 407 286 316 minecraft:red_terracotta
setblock 407 286 276 minecraft:shroomlight
setblock 407 286 277 minecraft:stripped_oak_log
setblock 407 286 278 minecraft:shroomlight
fill 407 286 279 407 293 279 minecraft:stripped_oak_log
setblock 407 286 280 minecraft:shroomlight
fill 407 286 281 407 293 281 minecraft:stripped_oak_log
fill 407 286 282 408 286 282 minecraft:terracotta
fill 407 286 292 413 286 293 minecraft:red_terracotta
fill 407 286 294 407 286 299 minecraft:orange_terracotta
fill 407 286 300 413 286 301 minecraft:red_terracotta
fill 407 286 310 408 286 310 minecraft:terracotta
setblock 408 286 276 minecraft:stripped_oak_log
setblock 408 286 277 minecraft:shroomlight
fill 408 286 278 408 289 278 minecraft:stripped_oak_log
setblock 408 286 279 minecraft:shroomlight
fill 408 286 280 408 295 280 minecraft:stripped_oak_log
setblock 408 286 281 minecraft:shroomlight
setblock 408 286 283 minecraft:shroomlight
setblock 408 286 285 minecraft:shroomlight
setblock 408 286 287 minecraft:shroomlight
fill 408 286 294 413 286 299 minecraft:red_terracotta
fill 408 286 309 409 286 309 minecraft:terracotta
setblock 408 286 315 minecraft:red_terracotta
setblock 408 286 316 minecraft:stripped_oak_log
setblock 409 286 276 minecraft:shroomlight
fill 409 286 277 409 288 277 minecraft:red_terracotta
setblock 409 286 278 minecraft:shroomlight
fill 409 286 279 409 295 279 minecraft:stripped_oak_log
setblock 409 286 280 minecraft:shroomlight
setblock 409 286 282 minecraft:shroomlight
setblock 409 286 283 minecraft:terracotta
setblock 409 286 284 minecraft:shroomlight
setblock 409 286 285 minecraft:red_terracotta
setblock 409 286 286 minecraft:shroomlight
fill 409 286 287 409 287 287 minecraft:red_terracotta
fill 409 286 308 410 286 308 minecraft:terracotta
setblock 409 286 315 minecraft:stripped_oak_log
fill 409 286 316 412 286 316 minecraft:red_terracotta
fill 410 286 276 410 288 276 minecraft:red_terracotta
setblock 410 286 277 minecraft:shroomlight
fill 410 286 278 410 287 278 minecraft:stripped_oak_log
setblock 410 286 279 minecraft:shroomlight
fill 410 286 280 410 295 280 minecraft:stripped_oak_log
setblock 410 286 281 minecraft:shroomlight
setblock 410 286 283 minecraft:shroomlight
setblock 410 286 284 minecraft:terracotta
setblock 410 286 285 minecraft:shroomlight
setblock 410 286 286 minecraft:red_terracotta
setblock 410 286 287 minecraft:shroomlight
fill 410 286 307 411 286 307 minecraft:terracotta
setblock 410 286 314 minecraft:stripped_oak_log
fill 410 286 315 413 286 315 minecraft:red_terracotta
setblock 411 286 276 minecraft:shroomlight
setblock 411 286 277 minecraft:red_terracotta
setblock 411 286 278 minecraft:shroomlight
fill 411 286 279 411 295 279 minecraft:stripped_oak_log
setblock 411 286 280 minecraft:shroomlight
fill 411 286 281 411 295 281 minecraft:stripped_oak_log
setblock 411 286 282 minecraft:shroomlight
setblock 411 286 284 minecraft:shroomlight
setblock 411 286 285 minecraft:terracotta
setblock 411 286 286 minecraft:shroomlight
setblock 411 286 287 minecraft:red_terracotta
setblock 411 286 306 minecraft:terracotta
fill 411 286 314 414 286 314 minecraft:red_terracotta
setblock 412 286 276 minecraft:red_terracotta
setblock 412 286 277 minecraft:shroomlight
fill 412 286 278 412 289 278 minecraft:red_terracotta
setblock 412 286 279 minecraft:shroomlight
fill 412 286 280 412 295 280 minecraft:stripped_oak_log
setblock 412 286 281 minecraft:shroomlight
fill 412 286 282 412 295 282 minecraft:stripped_oak_log
setblock 412 286 283 minecraft:shroomlight
setblock 412 286 285 minecraft:shroomlight
fill 412 286 286 412 295 286 minecraft:stripped_oak_log
setblock 412 286 287 minecraft:shroomlight
fill 412 286 288 413 286 288 minecraft:terracotta
fill 412 286 304 412 286 305 minecraft:terracotta
fill 412 286 306 412 287 306 minecraft:stripped_oak_log
setblock 413 286 276 minecraft:stripped_oak_log
fill 413 286 277 413 289 277 minecraft:red_terracotta
setblock 413 286 278 minecraft:shroomlight
fill 413 286 279 413 295 279 minecraft:stripped_oak_log
setblock 413 286 280 minecraft:shroomlight
fill 413 286 281 413 295 281 minecraft:stripped_oak_log
setblock 413 286 282 minecraft:shroomlight
fill 413 286 283 413 295 283 minecraft:stripped_oak_log
setblock 413 286 284 minecraft:shroomlight
fill 413 286 285 413 295 285 minecraft:stripped_oak_log
setblock 413 286 286 minecraft:shroomlight
fill 413 286 287 413 295 287 minecraft:stripped_oak_log
fill 413 286 289 413 286 290 minecraft:terracotta
setblock 413 286 291 minecraft:red_terracotta
fill 413 286 302 413 286 304 minecraft:terracotta
fill 413 286 308 413 300 312 minecraft:stripped_oak_log
fill 413 286 313 413 288 313 minecraft:red_terracotta
setblock 413 286 316 minecraft:stripped_oak_log
fill 414 286 276 414 289 276 minecraft:red_terracotta
setblock 414 286 277 minecraft:shroomlight
fill 414 286 278 414 287 278 minecraft:red_terracotta
setblock 414 286 279 minecraft:shroomlight
fill 414 286 280 414 295 280 minecraft:stripped_oak_log
setblock 414 286 281 minecraft:shroomlight
fill 414 286 282 414 295 282 minecraft:stripped_oak_log
setblock 414 286 283 minecraft:shroomlight
setblock 414 286 285 minecraft:shroomlight
fill 414 286 286 414 295 286 minecraft:stripped_oak_log
setblock 414 286 287 minecraft:shroomlight
setblock 414 286 289 minecraft:red_terracotta
setblock 414 286 290 minecraft:stripped_oak_log
fill 414 286 291 414 286 301 minecraft:terracotta
fill 414 286 308 414 300 310 minecraft:stripped_oak_log
fill 414 286 311 414 287 311 minecraft:red_terracotta
setblock 414 286 315 minecraft:stripped_oak_log
fill 414 286 316 414 289 316 minecraft:red_terracotta
fill 415 286 277 415 287 277 minecraft:red_terracotta
setblock 415 286 278 minecraft:shroomlight
setblock 415 286 279 minecraft:stripped_oak_log
setblock 415 286 280 minecraft:shroomlight
fill 415 286 281 415 295 281 minecraft:stripped_oak_log
setblock 415 286 282 minecraft:shroomlight
fill 415 286 283 415 295 283 minecraft:stripped_oak_log
setblock 415 286 284 minecraft:shroomlight
setblock 415 286 285 minecraft:red_terracotta
setblock 415 286 286 minecraft:shroomlight
setblock 415 286 289 minecraft:stripped_oak_log
fill 415 286 290 415 286 293 minecraft:red_terracotta
setblock 415 286 308 minecraft:red_terracotta
setblock 415 286 309 minecraft:stripped_oak_log
fill 415 286 310 415 289 310 minecraft:red_terracotta
setblock 415 286 313 minecraft:red_terracotta
setblock 415 286 314 minecraft:stripped_oak_log
fill 415 286 315 415 289 315 minecraft:red_terracotta
setblock 416 286 277 minecraft:shroomlight
setblock 416 286 278 minecraft:stripped_oak_log
setblock 416 286 279 minecraft:shroomlight
fill 416 286 280 416 288 280 minecraft:red_terracotta
setblock 416 286 281 minecraft:shroomlight
setblock 416 286 282 minecraft:red_terracotta
setblock 416 286 283 minecraft:shroomlight
fill 416 286 284 416 287 284 minecraft:red_terracotta
setblock 416 286 285 minecraft:shroomlight
setblock 416 286 287 minecraft:shroomlight
setblock 416 286 288 minecraft:stripped_oak_log
fill 416 286 289 416 289 289 minecraft:red_terracotta
setblock 416 286 292 minecraft:red_terracotta
setblock 416 286 293 minecraft:stripped_oak_log
fill 416 286 294 416 289 294 minecraft:red_terracotta
fill 416 286 296 416 287 296 minecraft:red_terracotta
fill 416 286 306 416 286 307 minecraft:red_terracotta
setblock 416 286 308 minecraft:stripped_oak_log
fill 416 286 309 416 289 309 minecraft:red_terracotta
setblock 416 286 312 minecraft:red_terracotta
setblock 416 286 313 minecraft:stripped_oak_log
fill 416 286 314 416 289 314 minecraft:red_terracotta
setblock 417 286 277 minecraft:stripped_oak_log
setblock 417 286 278 minecraft:shroomlight
fill 417 286 279 417 288 279 minecraft:red_terracotta
setblock 417 286 280 minecraft:shroomlight
setblock 417 286 281 minecraft:red_terracotta
setblock 417 286 282 minecraft:shroomlight
fill 417 286 283 417 288 283 minecraft:red_terracotta
setblock 417 286 284 minecraft:shroomlight
setblock 417 286 286 minecraft:shroomlight
setblock 417 286 287 minecraft:stripped_oak_log
fill 417 286 288 417 289 288 minecraft:red_terracotta
setblock 417 286 291 minecraft:red_terracotta
setblock 417 286 292 minecraft:stripped_oak_log
fill 417 286 293 417 289 293 minecraft:red_terracotta
setblock 417 286 297 minecraft:stripped_oak_log
fill 417 286 298 417 289 298 minecraft:red_terracotta
fill 417 286 304 417 286 306 minecraft:red_terracotta
setblock 417 286 307 minecraft:stripped_oak_log
fill 417 286 308 417 289 308 minecraft:red_terracotta
setblock 417 286 312 minecraft:stripped_oak_log
fill 417 286 313 417 289 313 minecraft:red_terracotta
fill 418 286 277 418 287 277 minecraft:red_terracotta
setblock 377 287 275 minecraft:red_terracotta
setblock 377 287 276 minecraft:stripped_oak_log
fill 377 287 277 377 287 279 minecraft:red_terracotta
setblock 377 287 285 minecraft:red_terracotta
setblock 377 287 286 minecraft:stripped_oak_log
fill 377 287 287 377 288 287 minecraft:red_terracotta
setblock 377 287 290 minecraft:red_terracotta
setblock 377 287 291 minecraft:stripped_oak_log
fill 377 287 292 377 287 295 minecraft:red_terracotta
setblock 377 287 296 minecraft:stripped_oak_log
fill 377 287 297 377 287 300 minecraft:red_terracotta
setblock 377 287 301 minecraft:stripped_oak_log
fill 377 287 302 377 287 305 minecraft:red_terracotta
setblock 377 287 306 minecraft:stripped_oak_log
fill 377 287 307 377 287 310 minecraft:red_terracotta
setblock 377 287 311 minecraft:stripped_oak_log
fill 377 287 312 377 290 312 minecraft:red_terracotta
fill 377 287 314 377 287 315 minecraft:red_terracotta
setblock 377 287 316 minecraft:stripped_oak_log
setblock 377 287 317 minecraft:red_terracotta
fill 378 287 276 378 290 276 minecraft:red_terracotta
setblock 378 287 290 minecraft:stripped_oak_log
setblock 378 287 291 minecraft:red_terracotta
setblock 378 287 294 minecraft:red_terracotta
setblock 378 287 295 minecraft:stripped_oak_log
setblock 378 287 305 minecraft:stripped_oak_log
fill 378 287 306 378 287 309 minecraft:red_terracotta
setblock 378 287 310 minecraft:stripped_oak_log
fill 378 287 311 378 290 311 minecraft:red_terracotta
setblock 378 287 315 minecraft:stripped_oak_log
fill 378 287 316 378 290 316 minecraft:red_terracotta
setblock 379 287 309 minecraft:stripped_oak_log
fill 379 287 310 379 288 310 minecraft:red_terracotta
setblock 379 287 314 minecraft:stripped_oak_log
fill 379 287 315 379 290 315 minecraft:red_terracotta
fill 380 287 277 380 290 277 minecraft:brown_terracotta
fill 380 287 279 380 290 279 minecraft:brown_terracotta
fill 380 287 314 380 288 314 minecraft:red_terracotta
fill 381 287 291 381 287 301 minecraft:terracotta
fill 382 287 277 382 290 277 minecraft:brown_terracotta
fill 382 287 279 382 290 279 minecraft:brown_terracotta
fill 382 287 289 382 287 293 minecraft:terracotta
fill 382 287 294 385 287 298 minecraft:red_terracotta
fill 382 287 299 382 287 303 minecraft:terracotta
setblock 382 287 316 minecraft:stripped_oak_log
fill 383 287 287 383 287 290 minecraft:terracotta
fill 383 287 291 385 287 293 minecraft:red_terracotta
fill 383 287 299 385 287 301 minecraft:red_terracotta
fill 383 287 302 383 287 305 minecraft:terracotta
setblock 383 287 315 minecraft:stripped_oak_log
fill 383 287 316 383 290 316 minecraft:red_terracotta
fill 384 287 286 384 287 288 minecraft:terracotta
fill 384 287 289 387 287 290 minecraft:red_terracotta
fill 384 287 302 386 287 303 minecraft:red_terracotta
fill 384 287 304 384 287 306 minecraft:terracotta
fill 384 287 307 384 288 309 minecraft:stripped_oak_log
fill 384 287 311 384 288 311 minecraft:stripped_oak_log
fill 384 287 313 384 288 313 minecraft:stripped_oak_log
fill 384 287 315 384 288 315 minecraft:red_terracotta
fill 385 287 285 385 287 286 minecraft:terracotta
fill 385 287 287 388 287 288 minecraft:red_terracotta
fill 385 287 304 388 287 305 minecraft:red_terracotta
fill 385 287 306 385 287 307 minecraft:terracotta
fill 385 287 308 385 288 310 minecraft:stripped_oak_log
fill 385 287 312 385 288 312 minecraft:stripped_oak_log
fill 385 287 314 385 288 314 minecraft:stripped_oak_log
fill 385 287 316 385 288 316 minecraft:red_terracotta
fill 386 287 284 386 287 285 minecraft:terracotta
fill 386 287 286 391 287 286 minecraft:red_terracotta
setblock 386 287 291 minecraft:red_terracotta
fill 386 287 292 386 287 294 minecraft:orange_terracotta
fill 386 287 299 386 287 300 minecraft:orange_terracotta
setblock 386 287 301 minecraft:red_terracotta
fill 386 287 306 390 287 306 minecraft:red_terracotta
fill 386 287 307 386 287 308 minecraft:terracotta
fill 386 287 309 386 288 311 minecraft:stripped_oak_log
fill 386 287 313 386 288 313 minecraft:stripped_oak_log
fill 386 287 315 386 288 315 minecraft:red_terracotta
fill 387 287 283 387 287 284 minecraft:terracotta
fill 387 287 285 393 287 285 minecraft:red_terracotta
setblock 387 287 291 minecraft:orange_terracotta
fill 387 287 301 387 287 302 minecraft:orange_terracotta
setblock 387 287 303 minecraft:red_terracotta
fill 387 287 308 387 287 309 minecraft:terracotta
fill 387 287 310 387 288 310 minecraft:stripped_oak_log
fill 387 287 312 387 288 312 minecraft:stripped_oak_log
fill 387 287 314 387 288 314 minecraft:stripped_oak_log
setblock 387 287 316 minecraft:stripped_oak_log
fill 388 287 282 389 287 283 minecraft:terracotta
fill 388 287 284 406 287 284 minecraft:red_terracotta
fill 388 287 289 388 287 290 minecraft:orange_terracotta
setblock 388 287 303 minecraft:orange_terracotta
setblock 388 287 307 minecraft:red_terracotta
fill 388 287 309 389 287 310 minecraft:terracotta
fill 388 287 311 389 288 311 minecraft:stripped_oak_log
fill 388 287 313 388 288 313 minecraft:stripped_oak_log
setblock 388 287 314 minecraft:red_terracotta
setblock 388 287 315 minecraft:stripped_oak_log
fill 388 287 316 389 288 316 minecraft:red_terracotta
fill 389 287 276 391 287 276 minecraft:red_terracotta
setblock 389 287 287 minecraft:red_terracotta
setblock 389 287 288 minecraft:orange_terracotta
setblock 389 287 304 minecraft:orange_terracotta
setblock 389 287 305 minecraft:red_terracotta
setblock 389 287 308 minecraft:red_terracotta
fill 389 287 312 391 288 312 minecraft:stripped_oak_log
setblock 389 287 314 minecraft:stripped_oak_log
fill 389 287 315 390 288 315 minecraft:red_terracotta
fill 390 287 281 391 287 282 minecraft:terracotta
fill 390 287 283 404 287 283 minecraft:red_terracotta
fill 390 287 287 391 287 287 minecraft:orange_terracotta
setblock 390 287 305 minecraft:orange_terracotta
setblock 390 287 307 minecraft:red_terracotta
setblock 390 287 309 minecraft:red_terracotta
fill 390 287 310 391 287 311 minecraft:terracotta
fill 390 287 313 390 288 313 minecraft:stripped_oak_log
fill 390 287 314 393 287 314 minecraft:red_terracotta
fill 391 287 306 392 287 306 minecraft:orange_terracotta
fill 391 287 308 406 287 308 minecraft:red_terracotta
setblock 391 287 316 minecraft:red_terracotta
setblock 392 287 276 minecraft:stripped_oak_log
fill 392 287 280 394 287 281 minecraft:terracotta
fill 392 287 282 402 287 282 minecraft:red_terracotta
fill 392 287 286 393 287 286 minecraft:orange_terracotta
setblock 392 287 307 minecraft:red_terracotta
fill 392 287 309 402 287 310 minecraft:red_terracotta
fill 392 287 311 394 287 312 minecraft:terracotta
fill 392 287 313 392 288 313 minecraft:stripped_oak_log
setblock 392 287 315 minecraft:red_terracotta
setblock 392 287 316 minecraft:stripped_oak_log
fill 393 287 276 393 290 276 minecraft:red_terracotta
fill 393 287 307 394 287 307 minecraft:orange_terracotta
setblock 393 287 315 minecraft:stripped_oak_log
fill 393 287 316 396 287 316 minecraft:red_terracotta
fill 394 287 285 400 287 285 minecraft:orange_terracotta
setblock 394 287 314 minecraft:stripped_oak_log
fill 394 287 315 394 290 315 minecraft:red_terracotta
fill 395 287 280 402 287 280 minecraft:terracotta
fill 395 287 281 399 287 281 minecraft:red_terracotta
fill 395 287 311 399 287 311 minecraft:red_terracotta
fill 395 287 312 402 287 312 minecraft:terracotta
setblock 395 287 314 minecraft:red_terracotta
setblock 396 287 276 minecraft:red_terracotta
setblock 397 287 276 minecraft:stripped_oak_log
setblock 397 287 316 minecraft:stripped_oak_log
fill 398 287 276 398 290 276 minecraft:red_terracotta
setblock 398 287 315 minecraft:stripped_oak_log
fill 398 287 316 398 290 316 minecraft:red_terracotta
fill 399 287 307 401 287 307 minecraft:orange_terracotta
fill 400 287 276 401 287 276 minecraft:red_terracotta
fill 400 287 281 404 287 281 minecraft:terracotta
fill 400 287 286 402 287 286 minecraft:orange_terracotta
fill 400 287 298 404 300 301 minecraft:stripped_oak_log
fill 400 287 311 404 287 311 minecraft:terracotta
fill 401 287 285 407 287 285 minecraft:red_terracotta
fill 401 287 297 403 300 297 minecraft:stripped_oak_log
setblock 401 287 316 minecraft:red_terracotta
setblock 402 287 276 minecraft:stripped_oak_log
fill 402 287 287 404 287 287 minecraft:orange_terracotta
setblock 402 287 306 minecraft:orange_terracotta
fill 402 287 307 407 287 307 minecraft:red_terracotta
fill 403 287 276 404 289 276 minecraft:red_terracotta
fill 403 287 282 406 287 282 minecraft:terracotta
fill 403 287 286 408 287 286 minecraft:red_terracotta
fill 403 287 305 404 287 305 minecraft:orange_terracotta
fill 403 287 306 408 287 306 minecraft:red_terracotta
fill 403 287 309 404 287 309 minecraft:red_terracotta
fill 403 287 310 406 287 310 minecraft:terracotta
fill 404 287 288 405 287 288 minecraft:orange_terracotta
fill 404 287 316 406 287 316 minecraft:red_terracotta
fill 405 287 283 407 287 283 minecraft:terracotta
fill 405 287 287 408 287 287 minecraft:red_terracotta
fill 405 287 289 406 287 289 minecraft:orange_terracotta
setblock 405 287 304 minecraft:orange_terracotta
fill 405 287 305 409 287 305 minecraft:red_terracotta
fill 405 287 309 407 287 309 minecraft:terracotta
setblock 406 287 277 minecraft:stripped_oak_log
fill 406 287 279 406 288 279 minecraft:stripped_oak_log
fill 406 287 281 406 288 281 minecraft:stripped_oak_log
fill 406 287 288 409 287 288 minecraft:red_terracotta
fill 406 287 290 406 287 291 minecraft:orange_terracotta
fill 406 287 302 406 287 303 minecraft:orange_terracotta
fill 406 287 304 409 287 304 minecraft:red_terracotta
setblock 407 287 276 minecraft:stripped_oak_log
fill 407 287 277 408 288 277 minecraft:red_terracotta
fill 407 287 278 407 288 278 minecraft:stripped_oak_log
fill 407 287 280 407 288 280 minecraft:stripped_oak_log
fill 407 287 284 408 287 284 minecraft:terracotta
fill 407 287 289 410 287 290 minecraft:red_terracotta
fill 407 287 291 407 287 293 minecraft:orange_terracotta
fill 407 287 300 407 287 301 minecraft:orange_terracotta
fill 407 287 302 410 287 303 minecraft:red_terracotta
fill 407 287 308 408 287 308 minecraft:terracotta
setblock 407 287 315 minecraft:red_terracotta
setblock 407 287 316 minecraft:stripped_oak_log
fill 408 287 276 409 288 276 minecraft:red_terracotta
fill 408 287 279 408 288 279 minecraft:stripped_oak_log
fill 408 287 281 408 288 283 minecraft:stripped_oak_log
fill 408 287 285 409 287 285 minecraft:terracotta
fill 408 287 291 411 287 292 minecraft:red_terracotta
fill 408 287 293 408 287 299 minecraft:orange_terracotta
fill 408 287 300 411 287 301 minecraft:red_terracotta
fill 408 287 307 409 287 307 minecraft:terracotta
setblock 408 287 315 minecraft:stripped_oak_log
fill 408 287 316 411 287 316 minecraft:red_terracotta
fill 409 287 278 409 288 278 minecraft:stripped_oak_log
fill 409 287 280 409 288 280 minecraft:stripped_oak_log
fill 409 287 282 409 288 284 minecraft:stripped_oak_log
fill 409 287 286 410 287 286 minecraft:terracotta
fill 409 287 293 411 287 299 minecraft:red_terracotta
fill 409 287 306 410 287 306 minecraft:terracotta
setblock 409 287 314 minecraft:stripped_oak_log
fill 409 287 315 412 287 315 minecraft:red_terracotta
setblock 410 287 277 minecraft:red_terracotta
fill 410 287 279 410 288 279 minecraft:stripped_oak_log
fill 410 287 281 410 288 281 minecraft:stripped_oak_log
fill 410 287 283 410 288 285 minecraft:stripped_oak_log
fill 410 287 287 411 287 288 minecraft:terracotta
fill 410 287 304 411 287 305 minecraft:terracotta
fill 410 287 314 413 287 314 minecraft:red_terracotta
setblock 411 287 276 minecraft:red_terracotta
setblock 411 287 277 minecraft:stripped_oak_log
fill 411 287 278 411 288 278 minecraft:red_terracotta
fill 411 287 280 411 288 280 minecraft:stripped_oak_log
fill 411 287 282 411 288 282 minecraft:stripped_oak_log
fill 411 287 284 411 288 286 minecraft:stripped_oak_log
fill 411 287 289 412 287 290 minecraft:terracotta
fill 411 287 302 412 287 303 minecraft:terracotta
setblock 412 287 276 minecraft:stripped_oak_log
fill 412 287 277 412 288 277 minecraft:red_terracotta
fill 412 287 279 412 288 279 minecraft:stripped_oak_log
fill 412 287 281 412 288 281 minecraft:stripped_oak_log
fill 412 287 283 412 288 283 minecraft:stripped_oak_log
fill 412 287 285 412 288 285 minecraft:stripped_oak_log
fill 412 287 287 412 288 287 minecraft:stripped_oak_log
fill 412 287 291 413 287 293 minecraft:terracotta
fill 412 287 294 412 287 298 minecraft:red_terracotta
fill 412 287 299 413 287 301 minecraft:terracotta
fill 412 287 313 412 289 313 minecraft:red_terracotta
setblock 412 287 316 minecraft:stripped_oak_log
fill 413 287 276 413 290 276 minecraft:red_terracotta
fill 413 287 278 413 288 278 minecraft:red_terracotta
fill 413 287 280 413 288 280 minecraft:stripped_oak_log
fill 413 287 282 413 288 282 minecraft:stripped_oak_log
fill 413 287 284 413 288 284 minecraft:stripped_oak_log
fill 413 287 286 413 288 286 minecraft:stripped_oak_log
fill 413 287 294 413 287 298 minecraft:terracotta
setblock 413 287 315 minecraft:stripped_oak_log
fill 413 287 316 413 290 316 minecraft:red_terracotta
fill 414 287 277 414 288 277 minecraft:red_terracotta
fill 414 287 279 414 288 279 minecraft:stripped_oak_log
fill 414 287 281 414 288 281 minecraft:stripped_oak_log
fill 414 287 283 414 288 283 minecraft:stripped_oak_log
fill 414 287 285 415 288 285 minecraft:stripped_oak_log
fill 414 287 287 414 288 287 minecraft:stripped_oak_log
setblock 414 287 314 minecraft:stripped_oak_log
fill 414 287 315 414 290 315 minecraft:red_terracotta
setblock 415 287 278 minecraft:stripped_oak_log
fill 415 287 279 416 287 279 minecraft:red_terracotta
fill 415 287 280 415 288 280 minecraft:stripped_oak_log
fill 415 287 282 416 288 282 minecraft:stripped_oak_log
fill 415 287 284 415 288 284 minecraft:stripped_oak_log
fill 415 287 286 415 287 287 minecraft:red_terracotta
setblock 415 287 288 minecraft:stripped_oak_log
fill 415 287 289 415 287 292 minecraft:red_terracotta
setblock 415 287 293 minecraft:stripped_oak_log
setblock 415 287 294 minecraft:red_terracotta
fill 415 287 308 415 300 308 minecraft:stripped_oak_log
setblock 415 287 309 minecraft:red_terracotta
setblock 415 287 313 minecraft:stripped_oak_log
fill 415 287 314 415 290 314 minecraft:red_terracotta
setblock 416 287 276 minecraft:red_terracotta
setblock 416 287 277 minecraft:stripped_oak_log
fill 416 287 278 417 288 278 minecraft:red_terracotta
setblock 416 287 281 minecraft:red_terracotta
setblock 416 287 283 minecraft:red_terracotta
fill 416 287 285 416 288 285 minecraft:red_terracotta
setblock 416 287 287 minecraft:stripped_oak_log
fill 416 287 288 416 288 288 minecraft:red_terracotta
setblock 416 287 292 minecraft:stripped_oak_log
fill 416 287 293 416 289 293 minecraft:red_terracotta
fill 416 287 307 416 300 307 minecraft:stripped_oak_log
fill 416 287 308 416 288 308 minecraft:red_terracotta
setblock 416 287 312 minecraft:stripped_oak_log
fill 416 287 313 416 290 313 minecraft:red_terracotta
setblock 417 287 276 minecraft:stripped_oak_log
fill 417 287 277 417 290 277 minecraft:red_terracotta
setblock 417 287 280 minecraft:red_terracotta
setblock 417 287 281 minecraft:stripped_oak_log
fill 417 287 282 417 288 282 minecraft:red_terracotta
fill 417 287 284 417 288 284 minecraft:red_terracotta
setblock 417 287 286 minecraft:stripped_oak_log
fill 417 287 287 417 289 287 minecraft:red_terracotta
setblock 417 287 291 minecraft:stripped_oak_log
fill 417 287 292 417 290 292 minecraft:red_terracotta
fill 417 287 295 418 287 295 minecraft:red_terracotta
setblock 417 287 296 minecraft:stripped_oak_log
fill 417 287 297 417 290 297 minecraft:red_terracotta
fill 417 287 304 417 287 305 minecraft:red_terracotta
setblock 417 287 306 minecraft:stripped_oak_log
fill 417 287 307 417 289 307 minecraft:red_terracotta
setblock 417 287 311 minecraft:stripped_oak_log
fill 417 287 312 417 290 312 minecraft:red_terracotta
setblock 417 287 316 minecraft:stripped_oak_log
setblock 418 287 276 minecraft:red_terracotta
setblock 418 287 296 minecraft:red_terracotta
fill 376 288 275 376 291 317 minecraft:yellow_terracotta
fill 377 288 275 418 291 275 minecraft:yellow_terracotta
fill 377 288 276 377 288 278 minecraft:red_terracotta
setblock 377 288 290 minecraft:stripped_oak_log
fill 377 288 291 377 288 294 minecraft:red_terracotta
setblock 377 288 295 minecraft:stripped_oak_log
fill 377 288 296 377 288 299 minecraft:red_terracotta
setblock 377 288 300 minecraft:stripped_oak_log
fill 377 288 301 377 288 304 minecraft:red_terracotta
setblock 377 288 305 minecraft:stripped_oak_log
fill 377 288 306 377 288 309 minecraft:red_terracotta
setblock 377 288 310 minecraft:stripped_oak_log
fill 377 288 311 377 291 311 minecraft:red_terracotta
setblock 377 288 314 minecraft:red_terracotta
setblock 377 288 315 minecraft:stripped_oak_log
fill 377 288 316 377 291 316 minecraft:red_terracotta
fill 377 288 317 418 291 317 minecraft:yellow_terracotta
setblock 378 288 294 minecraft:stripped_oak_log
fill 378 288 295 378 288 296 minecraft:red_terracotta
fill 378 288 306 378 288 308 minecraft:red_terracotta
setblock 378 288 309 minecraft:stripped_oak_log
fill 378 288 310 378 290 310 minecraft:red_terracotta
setblock 378 288 314 minecraft:stripped_oak_log
fill 378 288 315 378 291 315 minecraft:red_terracotta
setblock 379 288 278 minecraft:light[level=15]
setblock 379 288 285 minecraft:light[level=12]
setblock 379 288 286 minecraft:light[level=15]
setblock 379 288 292 minecraft:light[level=12]
setblock 379 288 294 minecraft:light[level=15]
setblock 379 288 299 minecraft:light[level=12]
setblock 379 288 302 minecraft:light[level=15]
setblock 379 288 306 minecraft:light[level=12]
setblock 379 288 313 minecraft:stripped_oak_log
fill 379 288 314 379 289 314 minecraft:red_terracotta
setblock 381 288 316 minecraft:stripped_oak_log
fill 382 288 294 384 288 298 minecraft:terracotta
setblock 382 288 315 minecraft:stripped_oak_log
fill 382 288 316 382 291 316 minecraft:red_terracotta
fill 383 288 291 384 288 293 minecraft:terracotta
fill 383 288 299 384 288 301 minecraft:terracotta
fill 383 288 315 383 289 315 minecraft:red_terracotta
fill 384 288 289 386 288 290 minecraft:terracotta
fill 384 288 302 385 288 303 minecraft:terracotta
fill 385 288 287 387 288 288 minecraft:terracotta
fill 385 288 291 385 288 292 minecraft:terracotta
fill 385 288 293 385 288 299 minecraft:yellow_terracotta
fill 385 288 300 385 288 301 minecraft:terracotta
fill 385 288 304 387 288 305 minecraft:terracotta
fill 385 288 307 386 288 307 minecraft:stripped_oak_log
setblock 386 288 278 minecraft:light[level=12]
setblock 386 288 285 minecraft:light[level=12]
fill 386 288 286 389 288 286 minecraft:terracotta
fill 386 288 291 386 288 292 minecraft:yellow_terracotta
setblock 386 288 299 minecraft:light[level=12]
fill 386 288 300 386 288 302 minecraft:yellow_terracotta
setblock 386 288 303 minecraft:terracotta
fill 386 288 306 389 288 306 minecraft:terracotta
fill 386 288 308 387 288 308 minecraft:stripped_oak_log
setblock 386 288 316 minecraft:stripped_oak_log
setblock 387 288 278 minecraft:light[level=15]
fill 387 288 285 391 288 285 minecraft:terracotta
fill 387 288 289 387 288 290 minecraft:yellow_terracotta
setblock 387 288 294 minecraft:light[level=15]
setblock 387 288 302 minecraft:light[level=15]
setblock 387 288 303 minecraft:yellow_terracotta
fill 387 288 307 390 288 307 minecraft:terracotta
fill 387 288 309 389 288 309 minecraft:stripped_oak_log
setblock 387 288 315 minecraft:stripped_oak_log
setblock 387 288 316 minecraft:red_terracotta
fill 388 288 276 390 288 276 minecraft:red_terracotta
fill 388 288 284 393 288 284 minecraft:terracotta
setblock 388 288 287 minecraft:terracotta
setblock 388 288 288 minecraft:yellow_terracotta
setblock 388 288 304 minecraft:yellow_terracotta
setblock 388 288 305 minecraft:terracotta
fill 388 288 308 393 288 308 minecraft:terracotta
fill 388 288 310 391 288 310 minecraft:stripped_oak_log
setblock 388 288 314 minecraft:stripped_oak_log
setblock 388 288 315 minecraft:red_terracotta
setblock 389 288 287 minecraft:yellow_terracotta
setblock 389 288 305 minecraft:yellow_terracotta
fill 389 288 314 392 288 314 minecraft:red_terracotta
fill 390 288 283 404 288 283 minecraft:terracotta
fill 390 288 286 391 288 286 minecraft:yellow_terracotta
setblock 390 288 306 minecraft:yellow_terracotta
fill 390 288 309 404 288 309 minecraft:terracotta
fill 390 288 311 392 288 311 minecraft:stripped_oak_log
setblock 391 288 276 minecraft:stripped_oak_log
fill 391 288 307 393 288 307 minecraft:yellow_terracotta
setblock 391 288 316 minecraft:stripped_oak_log
fill 392 288 276 392 291 276 minecraft:red_terracotta
fill 392 288 282 402 288 282 minecraft:terracotta
fill 392 288 285 393 288 285 minecraft:yellow_terracotta
fill 392 288 310 402 288 310 minecraft:terracotta
fill 392 288 312 392 296 312 minecraft:stripped_oak_log
setblock 392 288 315 minecraft:stripped_oak_log
fill 392 288 316 395 288 316 minecraft:red_terracotta
fill 393 288 277 394 288 277 minecraft:red_terracotta
setblock 393 288 278 minecraft:light[level=12]
setblock 393 288 292 minecraft:light[level=12]
setblock 393 288 299 minecraft:light[level=12]
setblock 393 288 306 minecraft:light[level=12]
setblock 393 288 313 minecraft:light[level=12]
setblock 393 288 314 minecraft:stripped_oak_log
fill 393 288 315 393 291 315 minecraft:red_terracotta
fill 394 288 284 400 288 284 minecraft:yellow_terracotta
fill 394 288 308 400 288 308 minecraft:yellow_terracotta
setblock 394 288 314 minecraft:red_terracotta
setblock 395 288 278 minecraft:light[level=15]
fill 395 288 281 399 288 281 minecraft:terracotta
setblock 395 288 286 minecraft:light[level=15]
setblock 395 288 294 minecraft:light[level=15]
setblock 395 288 302 minecraft:light[level=15]
fill 395 288 311 399 288 311 minecraft:terracotta
setblock 396 288 276 minecraft:stripped_oak_log
setblock 396 288 315 minecraft:red_terracotta
setblock 396 288 316 minecraft:stripped_oak_log
fill 397 288 276 397 291 276 minecraft:red_terracotta
setblock 397 288 315 minecraft:stripped_oak_log
fill 397 288 316 397 291 316 minecraft:red_terracotta
fill 399 288 297 399 289 301 minecraft:brown_terracotta
setblock 400 288 276 minecraft:red_terracotta
setblock 400 288 278 minecraft:light[level=12]
setblock 400 288 285 minecraft:light[level=12]
setblock 400 288 292 minecraft:light[level=12]
fill 400 288 296 400 289 297 minecraft:brown_terracotta
fill 400 288 302 404 289 302 minecraft:brown_terracotta
setblock 400 288 306 minecraft:light[level=12]
setblock 400 288 313 minecraft:light[level=12]
setblock 401 288 276 minecraft:stripped_oak_log
fill 401 288 284 406 288 284 minecraft:terracotta
fill 401 288 285 402 288 285 minecraft:yellow_terracotta
fill 401 288 296 404 289 296 minecraft:brown_terracotta
fill 401 288 307 402 288 307 minecraft:yellow_terracotta
fill 401 288 308 406 288 308 minecraft:terracotta
setblock 401 288 316 minecraft:stripped_oak_log
fill 402 288 276 402 291 276 minecraft:red_terracotta
fill 402 288 303 402 289 303 minecraft:brown_terracotta
fill 402 288 316 405 288 316 minecraft:red_terracotta
setblock 403 288 278 minecraft:light[level=15]
fill 403 288 285 407 288 285 minecraft:terracotta
fill 403 288 286 404 288 286 minecraft:yellow_terracotta
setblock 403 288 294 minecraft:light[level=15]
fill 403 288 306 404 288 306 minecraft:yellow_terracotta
fill 403 288 307 407 288 307 minecraft:terracotta
setblock 403 288 310 minecraft:light[level=15]
fill 404 288 297 405 289 297 minecraft:brown_terracotta
setblock 405 288 276 minecraft:red_terracotta
fill 405 288 286 408 288 286 minecraft:terracotta
setblock 405 288 287 minecraft:yellow_terracotta
fill 405 288 298 405 289 301 minecraft:brown_terracotta
setblock 405 288 305 minecraft:yellow_terracotta
fill 405 288 306 408 288 306 minecraft:terracotta
setblock 406 288 276 minecraft:stripped_oak_log
setblock 406 288 277 minecraft:red_terracotta
fill 406 288 287 409 288 287 minecraft:terracotta
setblock 406 288 288 minecraft:yellow_terracotta
setblock 406 288 304 minecraft:yellow_terracotta
fill 406 288 305 409 288 305 minecraft:terracotta
setblock 406 288 315 minecraft:red_terracotta
setblock 406 288 316 minecraft:stripped_oak_log
setblock 407 288 276 minecraft:red_terracotta
fill 407 288 288 409 288 288 minecraft:terracotta
fill 407 288 289 407 288 290 minecraft:yellow_terracotta
setblock 407 288 292 minecraft:light[level=12]
setblock 407 288 299 minecraft:light[level=12]
fill 407 288 302 407 288 303 minecraft:yellow_terracotta
fill 407 288 304 409 288 304 minecraft:terracotta
fill 407 288 308 409 300 309 minecraft:stripped_oak_log
setblock 407 288 313 minecraft:light[level=12]
setblock 407 288 315 minecraft:stripped_oak_log
fill 407 288 316 410 288 316 minecraft:red_terracotta
fill 408 288 284 408 288 285 minecraft:stripped_oak_log
fill 408 288 289 410 288 290 minecraft:terracotta
fill 408 288 291 408 288 292 minecraft:yellow_terracotta
fill 408 288 300 408 288 301 minecraft:yellow_terracotta
fill 408 288 302 410 288 303 minecraft:terracotta
fill 408 288 307 410 300 307 minecraft:stripped_oak_log
fill 408 288 315 411 288 315 minecraft:red_terracotta
fill 409 288 285 409 288 286 minecraft:stripped_oak_log
fill 409 288 291 411 288 292 minecraft:terracotta
fill 409 288 293 409 288 299 minecraft:yellow_terracotta
fill 409 288 300 411 288 301 minecraft:terracotta
fill 409 288 306 409 300 306 minecraft:stripped_oak_log
fill 409 288 314 412 288 314 minecraft:red_terracotta
setblock 410 288 277 minecraft:stripped_oak_log
fill 410 288 278 410 291 278 minecraft:red_terracotta
fill 410 288 286 410 288 287 minecraft:stripped_oak_log
fill 410 288 293 411 288 299 minecraft:terracotta
fill 410 288 308 410 300 308 minecraft:stripped_oak_log
setblock 411 288 276 minecraft:stripped_oak_log
fill 411 288 277 411 291 277 minecraft:red_terracotta
fill 411 288 287 411 295 287 minecraft:stripped_oak_log
setblock 411 288 302 minecraft:light[level=15]
setblock 411 288 310 minecraft:light[level=15]
setblock 411 288 316 minecraft:stripped_oak_log
fill 412 288 276 412 291 276 minecraft:red_terracotta
fill 412 288 294 412 288 298 minecraft:terracotta
setblock 412 288 315 minecraft:stripped_oak_log
fill 412 288 316 412 291 316 minecraft:red_terracotta
setblock 413 288 314 minecraft:stripped_oak_log
fill 413 288 315 413 291 315 minecraft:red_terracotta
setblock 414 288 278 minecraft:stripped_oak_log
setblock 414 288 292 minecraft:light[level=12]
setblock 414 288 299 minecraft:light[level=12]
setblock 414 288 306 minecraft:light[level=12]
fill 414 288 311 414 300 311 minecraft:stripped_oak_log
setblock 414 288 312 minecraft:red_terracotta
setblock 414 288 313 minecraft:stripped_oak_log
fill 414 288 314 414 291 314 minecraft:red_terracotta
setblock 415 288 277 minecraft:stripped_oak_log
setblock 415 288 278 minecraft:red_terracotta
fill 415 288 279 415 295 279 minecraft:stripped_oak_log
fill 415 288 286 415 288 287 minecraft:stripped_oak_log
fill 415 288 289 415 288 291 minecraft:red_terracotta
setblock 415 288 292 minecraft:stripped_oak_log
setblock 415 288 293 minecraft:red_terracotta
fill 415 288 309 415 300 309 minecraft:stripped_oak_log
setblock 415 288 312 minecraft:stripped_oak_log
fill 415 288 313 415 291 313 minecraft:red_terracotta
setblock 416 288 276 minecraft:stripped_oak_log
setblock 416 288 277 minecraft:red_terracotta
setblock 416 288 279 minecraft:red_terracotta
setblock 416 288 281 minecraft:stripped_oak_log
fill 416 288 283 416 288 284 minecraft:stripped_oak_log
fill 416 288 286 416 295 286 minecraft:stripped_oak_log
setblock 416 288 287 minecraft:red_terracotta
setblock 416 288 291 minecraft:stripped_oak_log
fill 416 288 292 416 289 292 minecraft:red_terracotta
setblock 416 288 296 minecraft:stripped_oak_log
setblock 416 288 311 minecraft:stripped_oak_log
fill 416 288 312 416 291 312 minecraft:red_terracotta
setblock 416 288 316 minecraft:stripped_oak_log
fill 417 288 276 417 291 276 minecraft:red_terracotta
setblock 417 288 280 minecraft:stripped_oak_log
fill 417 288 281 417 289 281 minecraft:red_terracotta
fill 417 288 285 417 295 285 minecraft:stripped_oak_log
setblock 417 288 286 minecraft:red_terracotta
setblock 417 288 290 minecraft:stripped_oak_log
fill 417 288 291 417 290 291 minecraft:red_terracotta
setblock 417 288 295 minecraft:stripped_oak_log
fill 417 288 296 417 291 296 minecraft:red_terracotta
setblock 417 288 305 minecraft:stripped_oak_log
setblock 417 288 306 minecraft:red_terracotta
setblock 417 288 310 minecraft:stripped_oak_log
fill 417 288 311 417 291 311 minecraft:red_terracotta
setblock 417 288 315 minecraft:stripped_oak_log
fill 417 288 316 417 291 316 minecraft:red_terracotta
fill 418 288 276 418 291 316 minecraft:yellow_terracotta
fill 377 289 276 377 290 277 minecraft:red_terracotta
setblock 377 289 289 minecraft:stripped_oak_log
fill 377 289 290 377 289 293 minecraft:red_terracotta
setblock 377 289 294 minecraft:stripped_oak_log
fill 377 289 295 377 289 298 minecraft:red_terracotta
setblock 377 289 299 minecraft:stripped_oak_log
fill 377 289 300 377 289 303 minecraft:red_terracotta
setblock 377 289 304 minecraft:stripped_oak_log
fill 377 289 305 377 289 308 minecraft:red_terracotta
setblock 377 289 309 minecraft:stripped_oak_log
fill 377 289 310 377 292 310 minecraft:red_terracotta
setblock 377 289 314 minecraft:stripped_oak_log
fill 377 289 315 377 292 315 minecraft:red_terracotta
fill 378 289 294 378 289 295 minecraft:red_terracotta
setblock 378 289 308 minecraft:stripped_oak_log
setblock 378 289 309 minecraft:red_terracotta
setblock 378 289 313 minecraft:stripped_oak_log
fill 378 289 314 378 291 314 minecraft:red_terracotta
setblock 379 289 312 minecraft:stripped_oak_log
setblock 379 289 313 minecraft:red_terracotta
setblock 380 289 316 minecraft:stripped_oak_log
setblock 381 289 315 minecraft:stripped_oak_log
fill 381 289 316 381 292 316 minecraft:red_terracotta
fill 382 289 315 382 290 315 minecraft:red_terracotta
setblock 384 289 307 minecraft:shroomlight
fill 384 289 308 384 296 308 minecraft:stripped_oak_log
setblock 384 289 309 minecraft:shroomlight
setblock 384 289 311 minecraft:shroomlight
setblock 384 289 313 minecraft:shroomlight
setblock 384 289 315 minecraft:shroomlight
fill 385 289 307 385 296 307 minecraft:stripped_oak_log
setblock 385 289 308 minecraft:shroomlight
fill 385 289 309 385 296 309 minecraft:stripped_oak_log
setblock 385 289 310 minecraft:shroomlight
setblock 385 289 312 minecraft:shroomlight
setblock 385 289 314 minecraft:shroomlight
setblock 385 289 316 minecraft:shroomlight
setblock 386 289 307 minecraft:shroomlight
fill 386 289 308 386 296 308 minecraft:stripped_oak_log
setblock 386 289 309 minecraft:shroomlight
fill 386 289 310 386 296 310 minecraft:stripped_oak_log
setblock 386 289 311 minecraft:shroomlight
setblock 386 289 313 minecraft:shroomlight
setblock 386 289 315 minecraft:shroomlight
fill 386 289 316 386 292 316 minecraft:red_terracotta
fill 387 289 276 389 289 276 minecraft:red_terracotta
fill 387 289 307 387 296 307 minecraft:stripped_oak_log
setblock 387 289 308 minecraft:shroomlight
fill 387 289 309 387 296 309 minecraft:stripped_oak_log
setblock 387 289 310 minecraft:shroomlight
setblock 387 289 312 minecraft:shroomlight
setblock 387 289 314 minecraft:shroomlight
fill 387 289 315 387 292 315 minecraft:red_terracotta
setblock 387 289 316 minecraft:shroomlight
setblock 388 289 307 minecraft:shroomlight
fill 388 289 308 388 296 308 minecraft:stripped_oak_log
setblock 388 289 309 minecraft:shroomlight
fill 388 289 310 388 296 310 minecraft:stripped_oak_log
setblock 388 289 311 minecraft:shroomlight
setblock 388 289 313 minecraft:shroomlight
setblock 388 289 314 minecraft:red_terracotta
setblock 388 289 315 minecraft:shroomlight
fill 388 289 316 388 290 316 minecraft:red_terracotta
fill 389 289 307 389 296 307 minecraft:stripped_oak_log
setblock 389 289 308 minecraft:shroomlight
fill 389 289 309 389 296 309 minecraft:stripped_oak_log
setblock 389 289 310 minecraft:shroomlight
fill 389 289 311 389 296 311 minecraft:stripped_oak_log
setblock 389 289 312 minecraft:shroomlight
setblock 389 289 314 minecraft:shroomlight
fill 389 289 315 389 290 315 minecraft:red_terracotta
setblock 389 289 316 minecraft:shroomlight
setblock 390 289 276 minecraft:stripped_oak_log
setblock 390 289 307 minecraft:shroomlight
fill 390 289 308 390 296 308 minecraft:stripped_oak_log
setblock 390 289 309 minecraft:shroomlight
fill 390 289 310 390 296 310 minecraft:stripped_oak_log
setblock 390 289 311 minecraft:shroomlight
fill 390 289 312 390 296 312 minecraft:stripped_oak_log
setblock 390 289 313 minecraft:shroomlight
fill 390 289 314 390 290 314 minecraft:red_terracotta
setblock 390 289 315 minecraft:shroomlight
setblock 390 289 316 minecraft:stripped_oak_log
fill 391 289 276 391 292 276 minecraft:red_terracotta
fill 391 289 307 391 296 307 minecraft:stripped_oak_log
setblock 391 289 308 minecraft:shroomlight
fill 391 289 309 391 296 309 minecraft:stripped_oak_log
setblock 391 289 310 minecraft:shroomlight
fill 391 289 311 391 296 311 minecraft:stripped_oak_log
setblock 391 289 312 minecraft:shroomlight
setblock 391 289 314 minecraft:shroomlight
setblock 391 289 315 minecraft:stripped_oak_log
setblock 391 289 316 minecraft:shroomlight
fill 392 289 277 393 289 277 minecraft:red_terracotta
setblock 392 289 307 minecraft:shroomlight
fill 392 289 308 392 296 308 minecraft:stripped_oak_log
setblock 392 289 309 minecraft:shroomlight
fill 392 289 310 392 296 310 minecraft:stripped_oak_log
setblock 392 289 311 minecraft:shroomlight
setblock 392 289 313 minecraft:shroomlight
fill 392 289 314 392 296 314 minecraft:stripped_oak_log
setblock 392 289 315 minecraft:shroomlight
fill 392 289 316 394 289 316 minecraft:red_terracotta
fill 393 289 308 393 297 309 minecraft:brown_terracotta
setblock 393 289 314 minecraft:red_terracotta
setblock 394 289 277 minecraft:stripped_oak_log
setblock 395 289 276 minecraft:stripped_oak_log
setblock 395 289 316 minecraft:stripped_oak_log
fill 396 289 276 396 292 276 minecraft:red_terracotta
setblock 396 289 315 minecraft:stripped_oak_log
fill 396 289 316 396 292 316 minecraft:red_terracotta
fill 398 289 301 398 289 302 minecraft:brown_terracotta
setblock 399 289 296 minecraft:brown_terracotta
fill 399 289 302 399 289 303 minecraft:brown_terracotta
setblock 400 289 276 minecraft:stripped_oak_log
fill 400 289 295 404 289 295 minecraft:brown_terracotta
fill 400 289 303 401 289 303 minecraft:brown_terracotta
setblock 400 289 316 minecraft:stripped_oak_log
fill 401 289 276 401 292 276 minecraft:red_terracotta
fill 401 289 304 403 289 304 minecraft:brown_terracotta
fill 401 289 316 404 289 316 minecraft:red_terracotta
fill 403 289 303 405 289 303 minecraft:brown_terracotta
setblock 405 289 276 minecraft:stripped_oak_log
setblock 405 289 296 minecraft:brown_terracotta
fill 405 289 302 406 289 302 minecraft:brown_terracotta
setblock 405 289 316 minecraft:stripped_oak_log
fill 406 289 276 406 292 276 minecraft:red_terracotta
setblock 406 289 277 minecraft:shroomlight
setblock 406 289 279 minecraft:shroomlight
setblock 406 289 281 minecraft:shroomlight
fill 406 289 297 406 289 301 minecraft:brown_terracotta
fill 406 289 306 406 290 306 minecraft:brown_terracotta
fill 406 289 307 406 300 308 minecraft:stripped_oak_log
fill 406 289 309 406 290 309 minecraft:brown_terracotta
setblock 406 289 315 minecraft:stripped_oak_log
fill 406 289 316 409 289 316 minecraft:red_terracotta
setblock 407 289 276 minecraft:shroomlight
fill 407 289 277 407 290 277 minecraft:red_terracotta
setblock 407 289 278 minecraft:shroomlight
setblock 407 289 280 minecraft:shroomlight
fill 407 289 305 410 290 305 minecraft:brown_terracotta
fill 407 289 306 407 300 307 minecraft:stripped_oak_log
fill 407 289 310 409 290 310 minecraft:brown_terracotta
fill 407 289 315 410 289 315 minecraft:red_terracotta
fill 408 289 276 408 290 276 minecraft:red_terracotta
setblock 408 289 277 minecraft:shroomlight
setblock 408 289 279 minecraft:shroomlight
setblock 408 289 281 minecraft:shroomlight
fill 408 289 282 408 295 282 minecraft:stripped_oak_log
setblock 408 289 283 minecraft:shroomlight
fill 408 289 284 408 295 284 minecraft:stripped_oak_log
setblock 408 289 285 minecraft:shroomlight
fill 408 289 286 408 295 286 minecraft:stripped_oak_log
setblock 408 289 287 minecraft:shroomlight
fill 408 289 306 408 300 306 minecraft:stripped_oak_log
setblock 409 289 276 minecraft:shroomlight
setblock 409 289 277 minecraft:stripped_oak_log
setblock 409 289 278 minecraft:shroomlight
setblock 409 289 280 minecraft:shroomlight
setblock 409 289 282 minecraft:shroomlight
fill 409 289 283 409 295 283 minecraft:stripped_oak_log
setblock 409 289 284 minecraft:shroomlight
fill 409 289 285 409 295 285 minecraft:stripped_oak_log
setblock 409 289 286 minecraft:shroomlight
fill 409 289 287 409 295 287 minecraft:stripped_oak_log
fill 409 289 314 411 289 314 minecraft:red_terracotta
setblock 410 289 276 minecraft:stripped_oak_log
setblock 410 289 277 minecraft:shroomlight
setblock 410 289 279 minecraft:shroomlight
setblock 410 289 281 minecraft:shroomlight
setblock 410 289 283 minecraft:shroomlight
fill 410 289 284 410 295 284 minecraft:stripped_oak_log
setblock 410 289 285 minecraft:shroomlight
fill 410 289 286 410 295 286 minecraft:stripped_oak_log
setblock 410 289 287 minecraft:shroomlight
fill 410 289 306 410 290 306 minecraft:brown_terracotta
fill 410 289 309 410 290 309 minecraft:brown_terracotta
setblock 410 289 316 minecraft:stripped_oak_log
setblock 411 289 276 minecraft:shroomlight
setblock 411 289 278 minecraft:shroomlight
setblock 411 289 280 minecraft:shroomlight
setblock 411 289 282 minecraft:shroomlight
setblock 411 289 284 minecraft:shroomlight
fill 411 289 285 411 295 285 minecraft:stripped_oak_log
setblock 411 289 286 minecraft:shroomlight
fill 411 289 307 411 290 308 minecraft:brown_terracotta
setblock 411 289 315 minecraft:stripped_oak_log
fill 411 289 316 411 292 316 minecraft:red_terracotta
setblock 412 289 277 minecraft:shroomlight
setblock 412 289 279 minecraft:shroomlight
setblock 412 289 281 minecraft:shroomlight
setblock 412 289 283 minecraft:shroomlight
setblock 412 289 285 minecraft:shroomlight
setblock 412 289 287 minecraft:shroomlight
setblock 412 289 314 minecraft:stripped_oak_log
fill 412 289 315 412 292 315 minecraft:red_terracotta
setblock 413 289 278 minecraft:shroomlight
setblock 413 289 280 minecraft:shroomlight
setblock 413 289 282 minecraft:shroomlight
setblock 413 289 284 minecraft:shroomlight
setblock 413 289 286 minecraft:shroomlight
fill 413 289 313 413 300 313 minecraft:stripped_oak_log
fill 413 289 314 413 292 314 minecraft:red_terracotta
setblock 414 289 277 minecraft:shroomlight
fill 414 289 278 414 291 278 minecraft:red_terracotta
setblock 414 289 279 minecraft:shroomlight
setblock 414 289 281 minecraft:shroomlight
setblock 414 289 283 minecraft:shroomlight
setblock 414 289 285 minecraft:shroomlight
setblock 414 289 287 minecraft:shroomlight
fill 414 289 312 414 300 312 minecraft:stripped_oak_log
setblock 414 289 313 minecraft:red_terracotta
setblock 415 289 276 minecraft:stripped_oak_log
fill 415 289 277 415 292 277 minecraft:red_terracotta
setblock 415 289 278 minecraft:shroomlight
setblock 415 289 280 minecraft:shroomlight
setblock 415 289 282 minecraft:shroomlight
setblock 415 289 284 minecraft:shroomlight
fill 415 289 285 415 295 285 minecraft:stripped_oak_log
setblock 415 289 286 minecraft:shroomlight
fill 415 289 287 415 295 287 minecraft:stripped_oak_log
fill 415 289 311 415 300 311 minecraft:stripped_oak_log
fill 415 289 312 415 290 312 minecraft:red_terracotta
setblock 415 289 316 minecraft:stripped_oak_log
fill 416 289 276 416 292 276 minecraft:red_terracotta
setblock 416 289 277 minecraft:shroomlight
fill 416 289 278 416 290 278 minecraft:red_terracotta
setblock 416 289 279 minecraft:shroomlight
fill 416 289 280 416 295 280 minecraft:stripped_oak_log
setblock 416 289 281 minecraft:shroomlight
fill 416 289 282 416 295 282 minecraft:stripped_oak_log
setblock 416 289 283 minecraft:shroomlight
fill 416 289 284 416 295 284 minecraft:stripped_oak_log
setblock 416 289 285 minecraft:shroomlight
setblock 416 289 287 minecraft:shroomlight
setblock 416 289 290 minecraft:stripped_oak_log
setblock 416 289 291 minecraft:red_terracotta
setblock 416 289 295 minecraft:stripped_oak_log
fill 416 289 308 416 300 308 minecraft:stripped_oak_log
setblock 416 289 310 minecraft:stripped_oak_log
fill 416 289 311 416 291 311 minecraft:red_terracotta
setblock 416 289 315 minecraft:stripped_oak_log
fill 416 289 316 416 292 316 minecraft:red_terracotta
setblock 417 289 278 minecraft:shroomlight
setblock 417 289 279 minecraft:stripped_oak_log
setblock 417 289 280 minecraft:shroomlight
setblock 417 289 282 minecraft:shroomlight
fill 417 289 283 417 295 283 minecraft:stripped_oak_log
setblock 417 289 284 minecraft:shroomlight
setblock 417 289 286 minecraft:shroomlight
setblock 417 289 289 minecraft:stripped_oak_log
fill 417 289 290 417 290 290 minecraft:red_terracotta
setblock 417 289 294 minecraft:stripped_oak_log
fill 417 289 295 417 291 295 minecraft:red_terracotta
setblock 417 289 309 minecraft:stripped_oak_log
fill 417 289 310 417 292 310 minecraft:red_terracotta
setblock 417 289 314 minecraft:stripped_oak_log
fill 417 289 315 417 292 315 minecraft:red_terracotta
fill 377 290 290 377 290 292 minecraft:red_terracotta
setblock 377 290 293 minecraft:stripped_oak_log
fill 377 290 294 377 290 297 minecraft:red_terracotta
setblock 377 290 298 minecraft:stripped_oak_log
fill 377 290 299 377 290 302 minecraft:red_terracotta
setblock 377 290 303 minecraft:stripped_oak_log
fill 377 290 304 377 290 307 minecraft:red_terracotta
setblock 377 290 308 minecraft:stripped_oak_log
fill 377 290 309 377 292 309 minecraft:red_terracotta
setblock 377 290 313 minecraft:stripped_oak_log
fill 377 290 314 377 293 314 minecraft:red_terracotta
setblock 378 290 312 minecraft:stripped_oak_log
fill 378 290 313 378 291 313 minecraft:red_terracotta
setblock 379 290 316 minecraft:stripped_oak_log
setblock 380 290 315 minecraft:stripped_oak_log
fill 380 290 316 380 293 316 minecraft:red_terracotta
setblock 381 290 315 minecraft:red_terracotta
fill 384 290 307 384 291 307 minecraft:stripped_oak_log
fill 384 290 309 384 291 309 minecraft:stripped_oak_log
fill 384 290 311 384 291 311 minecraft:stripped_oak_log
fill 384 290 313 384 291 313 minecraft:stripped_oak_log
setblock 384 290 315 minecraft:red_terracotta
setblock 384 290 316 minecraft:stripped_oak_log
fill 385 290 308 385 291 308 minecraft:stripped_oak_log
fill 385 290 310 385 291 310 minecraft:stripped_oak_log
fill 385 290 312 385 291 312 minecraft:stripped_oak_log
fill 385 290 314 385 291 315 minecraft:stripped_oak_log
fill 385 290 316 385 291 316 minecraft:red_terracotta
fill 386 290 307 386 291 307 minecraft:stripped_oak_log
fill 386 290 309 386 291 309 minecraft:stripped_oak_log
fill 386 290 311 386 291 311 minecraft:stripped_oak_log
fill 386 290 313 386 291 313 minecraft:stripped_oak_log
fill 386 290 315 386 291 315 minecraft:red_terracotta
fill 387 290 276 388 290 276 minecraft:red_terracotta
fill 387 290 308 387 291 308 minecraft:stripped_oak_log
fill 387 290 310 387 291 310 minecraft:stripped_oak_log
fill 387 290 312 387 291 312 minecraft:stripped_oak_log
fill 387 290 314 389 291 314 minecraft:stripped_oak_log
fill 387 290 316 387 291 316 minecraft:red_terracotta
fill 388 290 307 388 291 307 minecraft:stripped_oak_log
fill 388 290 309 388 291 309 minecraft:stripped_oak_log
fill 388 290 311 388 291 311 minecraft:stripped_oak_log
fill 388 290 313 388 291 313 minecraft:stripped_oak_log
fill 388 290 315 388 291 315 minecraft:red_terracotta
setblock 389 290 276 minecraft:stripped_oak_log
fill 389 290 308 389 291 308 minecraft:stripped_oak_log
fill 389 290 310 389 291 310 minecraft:stripped_oak_log
fill 389 290 312 389 291 312 minecraft:stripped_oak_log
setblock 389 290 316 minecraft:stripped_oak_log
fill 390 290 276 390 293 276 minecraft:red_terracotta
fill 390 290 307 390 291 307 minecraft:stripped_oak_log
fill 390 290 309 390 291 309 minecraft:stripped_oak_log
fill 390 290 311 390 291 311 minecraft:stripped_oak_log
fill 390 290 313 390 291 313 minecraft:stripped_oak_log
setblock 390 290 315 minecraft:stripped_oak_log
fill 390 290 316 393 290 316 minecraft:red_terracotta
fill 391 290 277 392 290 277 minecraft:red_terracotta
fill 391 290 308 391 291 308 minecraft:stripped_oak_log
fill 391 290 310 391 291 310 minecraft:stripped_oak_log
fill 391 290 312 391 291 312 minecraft:stripped_oak_log
fill 391 290 314 391 291 314 minecraft:stripped_oak_log
fill 391 290 315 392 291 315 minecraft:red_terracotta
fill 392 290 307 392 291 307 minecraft:stripped_oak_log
fill 392 290 309 392 291 309 minecraft:stripped_oak_log
fill 392 290 311 392 291 311 minecraft:stripped_oak_log
fill 392 290 313 392 291 313 minecraft:stripped_oak_log
setblock 393 290 277 minecraft:stripped_oak_log
setblock 394 290 276 minecraft:stripped_oak_log
setblock 394 290 277 minecraft:red_terracotta
fill 394 290 308 394 297 308 minecraft:brown_terracotta
setblock 394 290 316 minecraft:stripped_oak_log
fill 395 290 276 395 293 276 minecraft:red_terracotta
setblock 395 290 315 minecraft:stripped_oak_log
fill 395 290 316 395 292 316 minecraft:red_terracotta
setblock 399 290 276 minecraft:stripped_oak_log
setblock 399 290 316 minecraft:stripped_oak_log
fill 400 290 276 400 293 276 minecraft:red_terracotta
setblock 403 290 276 minecraft:red_terracotta
setblock 403 290 316 minecraft:red_terracotta
setblock 404 290 276 minecraft:stripped_oak_log
setblock 404 290 316 minecraft:stripped_oak_log
fill 405 290 276 405 292 277 minecraft:red_terracotta
fill 405 290 305 405 290 309 minecraft:brown_terracotta
fill 405 290 316 408 290 316 minecraft:red_terracotta
fill 406 290 277 406 291 277 minecraft:red_terracotta
fill 406 290 279 406 291 279 minecraft:stripped_oak_log
fill 406 290 281 406 291 281 minecraft:stripped_oak_log
setblock 406 290 305 minecraft:brown_terracotta
setblock 406 290 310 minecraft:brown_terracotta
fill 406 290 315 409 290 315 minecraft:red_terracotta
fill 407 290 276 407 291 276 minecraft:red_terracotta
fill 407 290 278 407 291 278 minecraft:stripped_oak_log
fill 407 290 280 407 291 280 minecraft:stripped_oak_log
fill 407 290 304 410 290 304 minecraft:brown_terracotta
fill 407 290 311 410 290 311 minecraft:brown_terracotta
setblock 408 290 277 minecraft:stripped_oak_log
fill 408 290 278 409 291 278 minecraft:red_terracotta
fill 408 290 279 408 291 279 minecraft:stripped_oak_log
fill 408 290 281 408 291 281 minecraft:stripped_oak_log
fill 408 290 283 408 291 283 minecraft:stripped_oak_log
fill 408 290 285 408 291 285 minecraft:stripped_oak_log
fill 408 290 287 408 291 287 minecraft:stripped_oak_log
setblock 409 290 276 minecraft:stripped_oak_log
fill 409 290 277 410 291 277 minecraft:red_terracotta
fill 409 290 280 409 291 280 minecraft:stripped_oak_log
fill 409 290 282 409 291 282 minecraft:stripped_oak_log
fill 409 290 284 409 291 284 minecraft:stripped_oak_log
fill 409 290 286 409 291 286 minecraft:stripped_oak_log
fill 409 290 314 410 290 314 minecraft:red_terracotta
setblock 409 290 316 minecraft:stripped_oak_log
fill 410 290 276 411 291 276 minecraft:red_terracotta
fill 410 290 279 410 291 279 minecraft:stripped_oak_log
fill 410 290 281 410 291 281 minecraft:stripped_oak_log
fill 410 290 283 410 291 283 minecraft:stripped_oak_log
fill 410 290 285 410 291 285 minecraft:stripped_oak_log
fill 410 290 287 410 291 287 minecraft:stripped_oak_log
fill 410 290 310 411 290 310 minecraft:brown_terracotta
setblock 410 290 315 minecraft:stripped_oak_log
fill 410 290 316 410 293 316 minecraft:red_terracotta
setblock 411 290 278 minecraft:red_terracotta
fill 411 290 280 411 291 280 minecraft:stripped_oak_log
fill 411 290 282 411 291 282 minecraft:stripped_oak_log
fill 411 290 284 411 291 284 minecraft:stripped_oak_log
fill 411 290 286 411 291 286 minecraft:stripped_oak_log
fill 411 290 305 411 290 306 minecraft:brown_terracotta
setblock 411 290 309 minecraft:brown_terracotta
setblock 411 290 314 minecraft:stripped_oak_log
fill 411 290 315 411 293 315 minecraft:red_terracotta
setblock 412 290 277 minecraft:red_terracotta
fill 412 290 278 412 290 279 minecraft:stripped_oak_log
fill 412 290 281 412 291 281 minecraft:stripped_oak_log
fill 412 290 283 412 291 283 minecraft:stripped_oak_log
fill 412 290 285 412 291 285 minecraft:stripped_oak_log
fill 412 290 287 412 291 287 minecraft:stripped_oak_log
fill 412 290 307 412 290 308 minecraft:brown_terracotta
fill 412 290 314 412 293 314 minecraft:red_terracotta
setblock 413 290 277 minecraft:stripped_oak_log
fill 413 290 278 413 291 278 minecraft:red_terracotta
fill 413 290 280 413 291 280 minecraft:stripped_oak_log
fill 413 290 282 413 291 282 minecraft:stripped_oak_log
fill 413 290 284 413 291 284 minecraft:stripped_oak_log
fill 413 290 286 413 291 286 minecraft:stripped_oak_log
setblock 414 290 276 minecraft:stripped_oak_log
fill 414 290 277 414 291 277 minecraft:red_terracotta
fill 414 290 279 414 291 279 minecraft:stripped_oak_log
fill 414 290 281 414 291 281 minecraft:stripped_oak_log
fill 414 290 283 414 291 283 minecraft:stripped_oak_log
fill 414 290 285 414 291 285 minecraft:stripped_oak_log
fill 414 290 287 414 291 287 minecraft:stripped_oak_log
fill 414 290 303 416 290 305 minecraft:terracotta
fill 414 290 313 414 300 313 minecraft:stripped_oak_log
setblock 414 290 316 minecraft:stripped_oak_log
fill 415 290 276 415 293 276 minecraft:red_terracotta
fill 415 290 278 415 291 278 minecraft:stripped_oak_log
fill 415 290 280 415 291 280 minecraft:stripped_oak_log
fill 415 290 282 415 291 282 minecraft:stripped_oak_log
fill 415 290 284 415 291 284 minecraft:stripped_oak_log
fill 415 290 286 415 291 286 minecraft:stripped_oak_log
fill 415 290 310 415 300 310 minecraft:stripped_oak_log
setblock 415 290 315 minecraft:stripped_oak_log
fill 415 290 316 415 293 316 minecraft:red_terracotta
fill 416 290 277 416 291 277 minecraft:red_terracotta
fill 416 290 279 416 291 279 minecraft:stripped_oak_log
fill 416 290 281 417 291 281 minecraft:stripped_oak_log
fill 416 290 283 416 291 283 minecraft:stripped_oak_log
fill 416 290 285 416 291 285 minecraft:stripped_oak_log
fill 416 290 287 417 291 287 minecraft:stripped_oak_log
fill 416 290 309 416 300 309 minecraft:stripped_oak_log
setblock 416 290 310 minecraft:red_terracotta
setblock 416 290 314 minecraft:stripped_oak_log
fill 416 290 315 416 293 315 minecraft:red_terracotta
setblock 417 290 278 minecraft:stripped_oak_log
fill 417 290 279 417 290 280 minecraft:red_terracotta
fill 417 290 282 417 291 282 minecraft:stripped_oak_log
fill 417 290 284 417 291 284 minecraft:stripped_oak_log
fill 417 290 286 417 291 286 minecraft:stripped_oak_log
setblock 417 290 293 minecraft:stripped_oak_log
fill 417 290 294 417 291 294 minecraft:red_terracotta
fill 417 290 307 417 298 308 minecraft:stripped_oak_log
fill 417 290 309 417 291 309 minecraft:red_terracotta
schedule function dropper:buildpart/68_10 1t
