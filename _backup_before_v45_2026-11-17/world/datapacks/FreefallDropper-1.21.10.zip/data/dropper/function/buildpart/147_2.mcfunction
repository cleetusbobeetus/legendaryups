fill 178 284 632 178 300 632 minecraft:iron_block
fill 179 284 605 179 300 605 minecraft:iron_block
fill 182 284 612 182 300 612 minecraft:iron_block
fill 182 284 632 182 300 632 minecraft:iron_block
fill 182 284 642 182 300 642 minecraft:iron_block
fill 178 285 621 180 300 623 minecraft:iron_block
fill 180 285 639 181 286 641 minecraft:iron_block
fill 182 285 622 182 300 622 minecraft:iron_block
fill 182 285 640 182 286 640 minecraft:iron_block
fill 176 286 639 176 286 641 minecraft:iron_block
fill 177 286 621 177 286 623 minecraft:iron_block
fill 177 286 631 177 286 633 minecraft:iron_block
fill 177 286 638 179 286 638 minecraft:iron_block
fill 177 286 642 179 286 642 minecraft:iron_block
fill 178 286 620 180 286 620 minecraft:iron_block
fill 178 286 624 180 286 624 minecraft:iron_block
fill 178 286 631 179 286 631 minecraft:iron_block
fill 178 286 633 179 286 633 minecraft:iron_block
fill 179 286 632 181 287 632 minecraft:iron_block
fill 181 286 621 181 286 623 minecraft:iron_block
setblock 144 287 607 minecraft:light[level=14]
setblock 144 287 615 minecraft:light[level=14]
setblock 144 287 623 minecraft:light[level=14]
setblock 144 287 631 minecraft:light[level=14]
setblock 144 287 639 minecraft:light[level=14]
setblock 152 287 607 minecraft:light[level=14]
setblock 152 287 615 minecraft:light[level=14]
setblock 152 287 623 minecraft:light[level=14]
setblock 152 287 631 minecraft:light[level=14]
setblock 152 287 639 minecraft:light[level=14]
setblock 160 287 607 minecraft:light[level=14]
setblock 160 287 615 minecraft:light[level=14]
setblock 160 287 623 minecraft:light[level=14]
setblock 160 287 631 minecraft:light[level=14]
setblock 160 287 639 minecraft:light[level=14]
setblock 168 287 607 minecraft:light[level=14]
setblock 168 287 615 minecraft:light[level=14]
setblock 168 287 623 minecraft:light[level=14]
setblock 168 287 631 minecraft:light[level=14]
setblock 168 287 639 minecraft:light[level=14]
fill 174 287 607 181 288 607 minecraft:iron_block
setblock 176 287 615 minecraft:light[level=14]
setblock 176 287 623 minecraft:light[level=14]
setblock 176 287 631 minecraft:light[level=14]
setblock 176 287 639 minecraft:light[level=14]
setblock 177 287 632 minecraft:sea_lantern
fill 142 288 607 173 288 607 minecraft:iron_block
fill 142 288 609 142 288 613 minecraft:iron_block
setblock 142 288 617 minecraft:iron_block
fill 142 288 619 142 288 622 minecraft:iron_block
fill 142 288 625 147 289 625 minecraft:iron_block
setblock 142 288 627 minecraft:iron_block
fill 142 288 629 142 288 632 minecraft:iron_block
fill 142 288 637 145 289 637 minecraft:iron_block
fill 142 288 639 142 288 643 minecraft:iron_block
fill 143 288 605 146 288 605 minecraft:iron_block
fill 143 288 613 144 289 613 minecraft:iron_block
fill 143 288 619 148 289 619 minecraft:iron_block
fill 143 288 631 147 289 631 minecraft:iron_block
fill 143 288 643 146 289 643 minecraft:iron_block
setblock 144 288 645 minecraft:iron_block
fill 146 288 645 149 288 645 minecraft:iron_block
setblock 148 288 605 minecraft:iron_block
fill 153 288 605 156 288 605 minecraft:iron_block
setblock 154 288 645 minecraft:iron_block
fill 156 288 645 159 288 645 minecraft:iron_block
setblock 158 288 605 minecraft:iron_block
fill 163 288 605 166 288 605 minecraft:iron_block
setblock 164 288 645 minecraft:iron_block
fill 166 288 645 169 288 645 minecraft:iron_block
setblock 168 288 605 minecraft:iron_block
fill 173 288 605 176 288 605 minecraft:iron_block
setblock 174 288 645 minecraft:iron_block
fill 176 288 645 179 288 645 minecraft:iron_block
setblock 178 288 605 minecraft:iron_block
fill 182 288 606 182 288 609 minecraft:iron_block
setblock 182 288 611 minecraft:iron_block
fill 182 288 616 182 288 619 minecraft:iron_block
setblock 182 288 621 minecraft:iron_block
fill 182 288 626 182 288 629 minecraft:iron_block
fill 182 288 631 182 289 631 minecraft:iron_block
fill 182 288 636 182 288 639 minecraft:iron_block
setblock 182 288 641 minecraft:iron_block
fill 142 289 607 145 289 607 minecraft:iron_block
setblock 142 289 613 minecraft:iron_block
setblock 142 289 619 minecraft:iron_block
setblock 142 289 631 minecraft:iron_block
setblock 142 289 643 minecraft:iron_block
fill 145 289 613 177 289 613 minecraft:iron_block
fill 146 289 637 181 289 637 minecraft:iron_block
fill 147 289 643 182 289 643 minecraft:iron_block
fill 148 289 625 161 289 625 minecraft:iron_block
fill 148 289 631 181 289 631 minecraft:iron_block
fill 149 289 619 182 289 619 minecraft:iron_block
fill 166 289 625 182 289 625 minecraft:iron_block
fill 144 290 605 144 291 613 minecraft:iron_block
fill 150 290 605 150 291 610 minecraft:iron_block
fill 156 290 605 156 291 608 minecraft:iron_block
fill 162 290 605 162 291 619 minecraft:iron_block
fill 168 290 605 168 291 614 minecraft:iron_block
fill 171 290 613 182 290 613 minecraft:iron_block
fill 174 290 605 174 290 612 minecraft:iron_block
fill 174 290 614 174 290 645 minecraft:iron_block
fill 180 290 605 180 291 612 minecraft:iron_block
fill 180 290 614 180 291 616 minecraft:iron_block
fill 180 290 637 181 290 637 minecraft:iron_block
fill 144 291 614 144 291 645 minecraft:iron_block
fill 150 291 611 150 291 645 minecraft:iron_block
fill 156 291 609 156 291 644 minecraft:iron_block
fill 162 291 620 162 291 621 minecraft:iron_block
fill 162 291 626 162 291 645 minecraft:iron_block
fill 168 291 615 168 291 645 minecraft:iron_block
fill 174 291 605 174 291 611 minecraft:iron_block
fill 177 291 621 177 291 623 minecraft:iron_block
fill 178 291 620 180 291 620 minecraft:iron_block
fill 178 291 624 180 291 624 minecraft:iron_block
setblock 180 291 613 minecraft:iron_block
fill 180 291 617 180 291 619 minecraft:iron_block
fill 180 291 625 180 291 645 minecraft:iron_block
fill 181 291 621 181 291 623 minecraft:iron_block
fill 141 292 610 141 292 613 minecraft:sea_lantern
fill 141 292 620 141 292 623 minecraft:sea_lantern
fill 141 292 630 141 292 633 minecraft:sea_lantern
fill 141 292 640 141 292 643 minecraft:sea_lantern
fill 144 292 604 147 292 604 minecraft:sea_lantern
fill 145 292 646 148 292 646 minecraft:sea_lantern
fill 154 292 604 157 292 604 minecraft:sea_lantern
fill 155 292 646 158 292 646 minecraft:sea_lantern
fill 156 292 640 156 292 644 minecraft:iron_block
fill 164 292 604 167 292 604 minecraft:sea_lantern
fill 165 292 646 168 292 646 minecraft:sea_lantern
fill 174 292 604 177 292 604 minecraft:sea_lantern
fill 175 292 646 178 292 646 minecraft:sea_lantern
fill 176 292 639 176 292 641 minecraft:iron_block
fill 177 292 638 179 292 638 minecraft:iron_block
fill 177 292 642 179 292 642 minecraft:iron_block
fill 180 292 639 180 292 641 minecraft:iron_block
fill 183 292 605 183 292 608 minecraft:sea_lantern
fill 183 292 615 183 292 618 minecraft:sea_lantern
fill 183 292 625 183 292 628 minecraft:sea_lantern
fill 183 292 635 183 292 638 minecraft:sea_lantern
setblock 183 292 645 minecraft:sea_lantern
fill 141 293 610 141 307 613 minecraft:netherite_block
fill 141 293 620 141 307 623 minecraft:netherite_block
fill 141 293 630 141 307 633 minecraft:netherite_block
fill 141 293 640 141 307 643 minecraft:netherite_block
fill 144 293 604 147 307 604 minecraft:netherite_block
fill 145 293 646 148 307 646 minecraft:netherite_block
fill 154 293 604 157 307 604 minecraft:netherite_block
fill 155 293 646 158 307 646 minecraft:netherite_block
fill 164 293 604 167 307 604 minecraft:netherite_block
fill 165 293 646 168 307 646 minecraft:netherite_block
fill 174 293 604 177 307 604 minecraft:netherite_block
fill 175 293 646 178 307 646 minecraft:netherite_block
fill 177 293 631 177 293 633 minecraft:iron_block
fill 178 293 631 179 293 631 minecraft:iron_block
fill 178 293 633 179 293 633 minecraft:iron_block
setblock 179 293 632 minecraft:iron_block
fill 183 293 605 183 307 608 minecraft:netherite_block
fill 183 293 615 183 307 618 minecraft:netherite_block
fill 183 293 625 183 307 628 minecraft:netherite_block
fill 183 293 635 183 307 638 minecraft:netherite_block
fill 183 293 645 183 307 645 minecraft:netherite_block
setblock 142 294 607 minecraft:iron_block
setblock 142 294 617 minecraft:iron_block
setblock 142 294 627 minecraft:iron_block
setblock 142 294 637 minecraft:iron_block
setblock 144 294 645 minecraft:iron_block
setblock 148 294 605 minecraft:iron_block
setblock 154 294 645 minecraft:iron_block
setblock 158 294 605 minecraft:iron_block
setblock 164 294 645 minecraft:iron_block
setblock 168 294 605 minecraft:iron_block
setblock 174 294 645 minecraft:iron_block
setblock 178 294 605 minecraft:iron_block
setblock 182 294 611 minecraft:iron_block
setblock 182 294 621 minecraft:iron_block
setblock 182 294 631 minecraft:iron_block
setblock 182 294 641 minecraft:iron_block
setblock 144 295 607 minecraft:light[level=14]
setblock 144 295 615 minecraft:light[level=14]
setblock 144 295 623 minecraft:light[level=14]
setblock 144 295 631 minecraft:light[level=14]
setblock 144 295 639 minecraft:light[level=14]
setblock 152 295 607 minecraft:light[level=14]
setblock 152 295 615 minecraft:light[level=14]
setblock 152 295 623 minecraft:light[level=14]
setblock 152 295 631 minecraft:light[level=14]
setblock 152 295 639 minecraft:light[level=14]
setblock 160 295 607 minecraft:light[level=14]
setblock 160 295 615 minecraft:light[level=14]
setblock 160 295 623 minecraft:light[level=14]
setblock 160 295 631 minecraft:light[level=14]
setblock 160 295 639 minecraft:light[level=14]
setblock 168 295 607 minecraft:light[level=14]
setblock 168 295 615 minecraft:light[level=14]
setblock 168 295 623 minecraft:light[level=14]
setblock 168 295 631 minecraft:light[level=14]
setblock 168 295 639 minecraft:light[level=14]
setblock 176 295 607 minecraft:light[level=14]
setblock 176 295 615 minecraft:light[level=14]
setblock 176 295 623 minecraft:light[level=14]
setblock 176 295 631 minecraft:light[level=14]
setblock 176 295 639 minecraft:light[level=14]
fill 177 296 621 177 296 623 minecraft:iron_block
fill 178 296 620 180 296 620 minecraft:iron_block
fill 178 296 624 180 296 624 minecraft:iron_block
fill 181 296 621 181 296 623 minecraft:iron_block
fill 142 297 609 142 297 612 minecraft:iron_block
fill 142 297 619 142 297 622 minecraft:iron_block
fill 142 297 629 142 297 632 minecraft:iron_block
fill 142 297 639 142 297 642 minecraft:iron_block
fill 143 297 605 146 297 605 minecraft:iron_block
fill 146 297 645 149 297 645 minecraft:iron_block
fill 153 297 605 156 297 605 minecraft:iron_block
fill 156 297 645 159 297 645 minecraft:iron_block
fill 163 297 605 166 297 605 minecraft:iron_block
fill 166 297 645 169 297 645 minecraft:iron_block
fill 173 297 605 176 297 605 minecraft:iron_block
fill 176 297 645 179 297 645 minecraft:iron_block
fill 182 297 606 182 297 609 minecraft:iron_block
fill 182 297 616 182 297 619 minecraft:iron_block
fill 182 297 626 182 297 629 minecraft:iron_block
fill 182 297 636 182 297 639 minecraft:iron_block
fill 176 298 639 176 298 641 minecraft:iron_block
fill 177 298 638 179 298 638 minecraft:iron_block
fill 177 298 642 179 298 642 minecraft:iron_block
fill 180 298 639 180 298 641 minecraft:iron_block
setblock 142 300 607 minecraft:iron_block
setblock 142 300 617 minecraft:iron_block
setblock 142 300 627 minecraft:iron_block
setblock 142 300 637 minecraft:iron_block
setblock 144 300 645 minecraft:iron_block
setblock 148 300 605 minecraft:iron_block
setblock 154 300 645 minecraft:iron_block
setblock 158 300 605 minecraft:iron_block
setblock 164 300 645 minecraft:iron_block
setblock 168 300 605 minecraft:iron_block
setblock 174 300 645 minecraft:iron_block
setblock 178 300 605 minecraft:iron_block
setblock 182 300 611 minecraft:iron_block
setblock 182 300 621 minecraft:iron_block
setblock 182 300 631 minecraft:iron_block
setblock 182 300 641 minecraft:iron_block
setblock 144 303 607 minecraft:light[level=14]
setblock 144 303 615 minecraft:light[level=14]
setblock 144 303 623 minecraft:light[level=14]
setblock 144 303 631 minecraft:light[level=14]
setblock 144 303 639 minecraft:light[level=14]
setblock 152 303 607 minecraft:light[level=14]
setblock 152 303 615 minecraft:light[level=14]
setblock 152 303 623 minecraft:light[level=14]
setblock 152 303 631 minecraft:light[level=14]
setblock 152 303 639 minecraft:light[level=14]
setblock 160 303 607 minecraft:light[level=14]
setblock 160 303 615 minecraft:light[level=14]
setblock 160 303 623 minecraft:light[level=14]
setblock 160 303 631 minecraft:light[level=14]
setblock 160 303 639 minecraft:light[level=14]
setblock 168 303 607 minecraft:light[level=14]
setblock 168 303 615 minecraft:light[level=14]
setblock 168 303 623 minecraft:light[level=14]
setblock 168 303 631 minecraft:light[level=14]
setblock 168 303 639 minecraft:light[level=14]
setblock 176 303 607 minecraft:light[level=14]
setblock 176 303 615 minecraft:light[level=14]
setblock 176 303 623 minecraft:light[level=14]
setblock 176 303 631 minecraft:light[level=14]
setblock 176 303 639 minecraft:light[level=14]
