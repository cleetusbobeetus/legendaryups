setblock 354 73 598 minecraft:oak_log
fill 355 73 558 355 76 558 minecraft:green_terracotta
setblock 355 73 597 minecraft:oak_log
fill 355 73 598 355 76 598 minecraft:green_terracotta
fill 356 73 597 356 76 597 minecraft:green_terracotta
setblock 357 73 560 minecraft:oak_log
setblock 358 73 559 minecraft:oak_log
fill 358 73 560 358 76 560 minecraft:green_terracotta
setblock 359 73 558 minecraft:oak_log
fill 359 73 559 359 76 559 minecraft:green_terracotta
setblock 359 73 598 minecraft:oak_log
fill 360 73 558 360 76 558 minecraft:green_terracotta
setblock 360 73 597 minecraft:oak_log
fill 360 73 598 360 76 598 minecraft:green_terracotta
setblock 361 73 596 minecraft:oak_log
fill 361 73 597 361 76 597 minecraft:green_terracotta
setblock 362 73 560 minecraft:oak_log
fill 362 73 586 362 74 587 minecraft:dark_oak_log
setblock 362 73 595 minecraft:oak_log
fill 362 73 596 362 76 596 minecraft:green_terracotta
setblock 363 73 559 minecraft:oak_log
fill 363 73 560 363 75 560 minecraft:green_terracotta
fill 363 73 584 363 74 585 minecraft:dark_oak_log
fill 363 73 588 363 74 588 minecraft:dark_oak_log
setblock 363 73 595 minecraft:green_terracotta
setblock 364 73 558 minecraft:oak_log
fill 364 73 559 364 76 559 minecraft:green_terracotta
fill 364 73 584 366 74 584 minecraft:dark_oak_log
setblock 364 73 598 minecraft:oak_log
fill 365 73 558 365 76 558 minecraft:green_terracotta
setblock 365 73 597 minecraft:oak_log
fill 365 73 598 365 76 598 minecraft:green_terracotta
fill 366 73 588 366 74 588 minecraft:dark_oak_log
setblock 366 73 596 minecraft:oak_log
fill 366 73 597 366 76 597 minecraft:green_terracotta
fill 367 73 586 367 74 587 minecraft:dark_oak_log
fill 367 73 596 367 74 596 minecraft:green_terracotta
setblock 368 73 595 minecraft:green_terracotta
setblock 369 73 558 minecraft:oak_log
setblock 369 73 578 minecraft:oak_log
setblock 369 73 579 minecraft:green_terracotta
setblock 369 73 593 minecraft:oak_log
setblock 369 73 594 minecraft:green_terracotta
setblock 369 73 598 minecraft:oak_log
fill 370 73 558 370 74 558 minecraft:green_terracotta
setblock 370 73 577 minecraft:oak_log
fill 370 73 578 370 76 578 minecraft:green_terracotta
setblock 370 73 582 minecraft:oak_log
fill 370 73 583 370 76 583 minecraft:green_terracotta
setblock 370 73 592 minecraft:oak_log
fill 370 73 593 370 74 593 minecraft:green_terracotta
setblock 370 73 597 minecraft:oak_log
fill 370 73 598 370 76 598 minecraft:green_terracotta
setblock 330 74 565 minecraft:oak_leaves[persistent=true]
fill 330 74 573 330 74 575 minecraft:green_terracotta
setblock 330 74 576 minecraft:oak_log
fill 330 74 577 330 77 577 minecraft:green_terracotta
setblock 330 74 581 minecraft:oak_log
fill 330 74 582 330 77 582 minecraft:green_terracotta
setblock 330 74 596 minecraft:oak_log
fill 330 74 597 330 74 598 minecraft:green_terracotta
setblock 331 74 576 minecraft:green_terracotta
setblock 331 74 580 minecraft:oak_log
fill 331 74 581 331 77 581 minecraft:green_terracotta
fill 334 74 558 334 75 558 minecraft:oak_leaves[persistent=true]
fill 335 74 558 337 74 558 minecraft:green_terracotta
fill 335 74 598 337 74 598 minecraft:green_terracotta
setblock 338 74 558 minecraft:oak_log
fill 338 74 559 341 74 559 minecraft:green_terracotta
setblock 338 74 598 minecraft:oak_log
fill 339 74 558 339 77 558 minecraft:green_terracotta
setblock 339 74 597 minecraft:oak_log
fill 339 74 598 339 77 598 minecraft:green_terracotta
setblock 340 74 560 minecraft:green_terracotta
setblock 340 74 597 minecraft:green_terracotta
setblock 341 74 560 minecraft:oak_log
setblock 342 74 559 minecraft:oak_log
fill 342 74 560 342 77 560 minecraft:green_terracotta
setblock 343 74 558 minecraft:oak_log
fill 343 74 559 343 77 559 minecraft:green_terracotta
setblock 343 74 598 minecraft:oak_log
fill 344 74 558 347 74 558 minecraft:green_terracotta
setblock 344 74 597 minecraft:oak_log
fill 344 74 598 344 77 598 minecraft:green_terracotta
setblock 345 74 560 minecraft:green_terracotta
setblock 345 74 597 minecraft:green_terracotta
setblock 346 74 560 minecraft:oak_log
setblock 347 74 559 minecraft:oak_log
setblock 348 74 558 minecraft:oak_log
fill 348 74 559 348 77 559 minecraft:green_terracotta
setblock 348 74 598 minecraft:oak_log
fill 349 74 558 352 74 558 minecraft:green_terracotta
fill 349 74 598 352 74 598 minecraft:green_terracotta
setblock 352 74 559 minecraft:oak_log
setblock 353 74 558 minecraft:oak_log
fill 353 74 559 353 77 559 minecraft:green_terracotta
setblock 353 74 598 minecraft:oak_log
fill 354 74 558 354 77 558 minecraft:green_terracotta
fill 354 74 598 354 77 598 minecraft:green_terracotta
fill 355 74 597 355 76 597 minecraft:green_terracotta
setblock 357 74 559 minecraft:oak_log
fill 357 74 560 357 77 560 minecraft:green_terracotta
setblock 358 74 558 minecraft:oak_log
fill 358 74 559 358 77 559 minecraft:green_terracotta
setblock 358 74 598 minecraft:oak_log
fill 359 74 558 359 77 558 minecraft:green_terracotta
setblock 359 74 597 minecraft:oak_log
fill 359 74 598 359 77 598 minecraft:green_terracotta
setblock 360 74 596 minecraft:oak_log
fill 360 74 597 360 77 597 minecraft:green_terracotta
setblock 361 74 560 minecraft:oak_log
fill 361 74 596 361 77 596 minecraft:green_terracotta
setblock 362 74 559 minecraft:oak_log
fill 362 74 560 362 77 560 minecraft:green_terracotta
fill 362 74 584 362 74 585 minecraft:dark_oak_log
setblock 362 74 588 minecraft:dark_oak_log
setblock 363 74 558 minecraft:oak_log
fill 363 74 559 363 77 559 minecraft:green_terracotta
fill 363 74 589 366 74 589 minecraft:dark_oak_log
setblock 363 74 598 minecraft:oak_log
fill 364 74 558 364 77 558 minecraft:green_terracotta
fill 364 74 583 365 74 583 minecraft:dark_oak_log
setblock 364 74 597 minecraft:oak_log
fill 364 74 598 364 77 598 minecraft:green_terracotta
setblock 365 74 596 minecraft:oak_log
fill 365 74 597 365 77 597 minecraft:green_terracotta
setblock 366 74 596 minecraft:green_terracotta
setblock 367 74 559 minecraft:oak_log
fill 367 74 584 367 74 585 minecraft:dark_oak_log
setblock 367 74 588 minecraft:dark_oak_log
setblock 368 74 558 minecraft:oak_log
setblock 368 74 598 minecraft:oak_log
fill 369 74 558 369 75 558 minecraft:green_terracotta
setblock 369 74 597 minecraft:oak_log
fill 369 74 598 369 77 598 minecraft:green_terracotta
setblock 370 74 572 minecraft:oak_leaves[persistent=true]
setblock 370 74 576 minecraft:oak_log
fill 370 74 577 370 75 577 minecraft:green_terracotta
setblock 370 74 581 minecraft:oak_log
fill 370 74 582 370 77 582 minecraft:green_terracotta
setblock 370 74 591 minecraft:oak_leaves[persistent=true]
setblock 370 74 592 minecraft:green_terracotta
setblock 370 74 596 minecraft:oak_log
fill 370 74 597 370 76 597 minecraft:green_terracotta
setblock 330 75 571 minecraft:oak_leaves[persistent=true]
setblock 330 75 574 minecraft:green_terracotta
setblock 330 75 575 minecraft:oak_log
fill 330 75 576 330 78 576 minecraft:green_terracotta
setblock 330 75 580 minecraft:oak_log
fill 330 75 581 330 78 581 minecraft:green_terracotta
setblock 330 75 585 minecraft:oak_log
setblock 330 75 590 minecraft:oak_leaves[persistent=true]
setblock 331 75 579 minecraft:oak_log
fill 331 75 580 331 78 580 minecraft:green_terracotta
fill 335 75 558 336 75 558 minecraft:green_terracotta
setblock 336 75 598 minecraft:green_terracotta
setblock 337 75 558 minecraft:oak_log
fill 337 75 559 340 75 559 minecraft:green_terracotta
setblock 337 75 598 minecraft:oak_log
fill 338 75 558 338 78 558 minecraft:green_terracotta
fill 338 75 598 338 78 598 minecraft:green_terracotta
setblock 340 75 560 minecraft:oak_log
setblock 341 75 559 minecraft:oak_log
fill 341 75 560 341 78 560 minecraft:green_terracotta
setblock 342 75 558 minecraft:oak_log
fill 342 75 559 342 78 559 minecraft:green_terracotta
setblock 342 75 598 minecraft:oak_log
fill 343 75 558 346 75 558 minecraft:green_terracotta
fill 343 75 598 343 78 598 minecraft:green_terracotta
setblock 345 75 560 minecraft:oak_log
setblock 346 75 559 minecraft:oak_log
setblock 347 75 558 minecraft:oak_log
fill 347 75 559 347 78 559 minecraft:green_terracotta
setblock 347 75 598 minecraft:oak_log
fill 348 75 558 351 75 558 minecraft:green_terracotta
fill 348 75 598 351 75 598 minecraft:green_terracotta
setblock 351 75 559 minecraft:oak_log
setblock 352 75 558 minecraft:oak_log
fill 352 75 559 352 78 559 minecraft:green_terracotta
setblock 352 75 598 minecraft:oak_log
fill 353 75 558 353 78 558 minecraft:green_terracotta
fill 353 75 598 353 78 598 minecraft:green_terracotta
setblock 356 75 559 minecraft:oak_log
setblock 357 75 558 minecraft:oak_log
fill 357 75 559 357 78 559 minecraft:green_terracotta
setblock 357 75 598 minecraft:oak_log
fill 358 75 558 358 78 558 minecraft:green_terracotta
setblock 358 75 597 minecraft:oak_log
fill 358 75 598 358 78 598 minecraft:green_terracotta
setblock 359 75 596 minecraft:oak_log
fill 359 75 597 359 78 597 minecraft:green_terracotta
setblock 360 75 560 minecraft:oak_log
fill 360 75 596 360 77 596 minecraft:green_terracotta
setblock 361 75 559 minecraft:oak_log
fill 361 75 560 361 78 560 minecraft:green_terracotta
setblock 362 75 558 minecraft:oak_log
fill 362 75 559 362 78 559 minecraft:green_terracotta
setblock 362 75 598 minecraft:oak_log
fill 363 75 558 363 78 558 minecraft:green_terracotta
setblock 363 75 597 minecraft:oak_log
fill 363 75 598 363 78 598 minecraft:green_terracotta
setblock 364 75 596 minecraft:oak_log
fill 364 75 597 364 78 597 minecraft:green_terracotta
setblock 365 75 596 minecraft:green_terracotta
setblock 366 75 559 minecraft:oak_log
setblock 367 75 558 minecraft:oak_log
setblock 367 75 598 minecraft:oak_log
fill 368 75 558 368 76 558 minecraft:green_terracotta
setblock 368 75 597 minecraft:oak_log
fill 368 75 598 368 78 598 minecraft:green_terracotta
setblock 369 75 597 minecraft:green_terracotta
fill 370 75 560 370 76 560 minecraft:oak_leaves[persistent=true]
setblock 370 75 566 minecraft:oak_leaves[persistent=true]
setblock 370 75 580 minecraft:oak_log
fill 370 75 581 370 78 581 minecraft:green_terracotta
setblock 370 75 585 minecraft:oak_leaves[persistent=true]
setblock 370 75 595 minecraft:oak_log
fill 370 75 596 370 76 596 minecraft:green_terracotta
setblock 330 76 575 minecraft:green_terracotta
setblock 330 76 579 minecraft:oak_log
fill 330 76 580 330 79 580 minecraft:green_terracotta
setblock 330 76 584 minecraft:oak_log
setblock 330 76 596 minecraft:oak_leaves[persistent=true]
setblock 331 76 578 minecraft:oak_log
fill 331 76 579 331 79 579 minecraft:green_terracotta
setblock 335 76 558 minecraft:green_terracotta
setblock 336 76 558 minecraft:oak_log
setblock 336 76 598 minecraft:oak_log
fill 337 76 558 337 78 559 minecraft:green_terracotta
fill 337 76 598 337 79 598 minecraft:green_terracotta
fill 338 76 559 339 76 559 minecraft:green_terracotta
setblock 339 76 560 minecraft:oak_log
setblock 340 76 559 minecraft:oak_log
fill 340 76 560 340 79 560 minecraft:green_terracotta
setblock 341 76 558 minecraft:oak_log
fill 341 76 559 341 79 559 minecraft:green_terracotta
fill 341 76 588 341 77 588 minecraft:glowstone
setblock 341 76 598 minecraft:oak_log
fill 342 76 558 345 76 558 minecraft:green_terracotta
fill 342 76 598 342 79 598 minecraft:green_terracotta
setblock 344 76 560 minecraft:oak_log
setblock 345 76 559 minecraft:oak_log
setblock 346 76 558 minecraft:oak_log
fill 346 76 559 346 79 559 minecraft:green_terracotta
setblock 346 76 598 minecraft:oak_log
fill 347 76 558 350 76 558 minecraft:green_terracotta
setblock 347 76 598 minecraft:green_terracotta
setblock 350 76 559 minecraft:oak_log
setblock 351 76 558 minecraft:oak_log
fill 351 76 559 351 79 559 minecraft:green_terracotta
setblock 351 76 598 minecraft:oak_log
fill 352 76 558 352 79 558 minecraft:green_terracotta
fill 352 76 598 352 79 598 minecraft:green_terracotta
setblock 355 76 559 minecraft:oak_log
setblock 356 76 558 minecraft:oak_log
fill 356 76 559 356 78 560 minecraft:green_terracotta
setblock 356 76 598 minecraft:oak_log
fill 357 76 558 357 79 558 minecraft:green_terracotta
fill 357 76 581 358 77 582 minecraft:oak_leaves[persistent=true]
setblock 357 76 597 minecraft:oak_log
fill 357 76 598 357 79 598 minecraft:green_terracotta
fill 358 76 597 358 79 597 minecraft:green_terracotta
setblock 359 76 560 minecraft:oak_log
fill 359 76 581 359 77 581 minecraft:oak_leaves[persistent=true]
setblock 359 76 596 minecraft:green_terracotta
setblock 360 76 559 minecraft:oak_log
fill 360 76 560 360 79 560 minecraft:green_terracotta
setblock 361 76 558 minecraft:oak_log
fill 361 76 559 361 79 559 minecraft:green_terracotta
setblock 361 76 598 minecraft:oak_log
fill 362 76 558 362 79 558 minecraft:green_terracotta
setblock 362 76 597 minecraft:oak_log
fill 362 76 598 362 79 598 minecraft:green_terracotta
setblock 363 76 596 minecraft:oak_log
fill 363 76 597 363 79 597 minecraft:green_terracotta
setblock 364 76 596 minecraft:green_terracotta
setblock 365 76 559 minecraft:oak_log
setblock 366 76 558 minecraft:oak_log
setblock 366 76 598 minecraft:oak_log
fill 367 76 558 367 77 558 minecraft:green_terracotta
setblock 367 76 597 minecraft:oak_log
fill 367 76 598 367 78 598 minecraft:green_terracotta
setblock 370 76 579 minecraft:oak_log
fill 370 76 580 370 79 580 minecraft:green_terracotta
setblock 370 76 584 minecraft:oak_log
setblock 330 77 558 minecraft:oak_leaves[persistent=true]
setblock 330 77 578 minecraft:oak_log
fill 330 77 579 330 80 579 minecraft:green_terracotta
setblock 330 77 583 minecraft:oak_log
fill 330 77 584 330 79 585 minecraft:green_terracotta
setblock 331 77 578 minecraft:green_terracotta
setblock 331 77 582 minecraft:oak_log
setblock 334 77 558 minecraft:green_terracotta
setblock 334 77 598 minecraft:oak_leaves[persistent=true]
setblock 335 77 558 minecraft:oak_log
fill 336 77 558 336 79 559 minecraft:green_terracotta
setblock 338 77 559 minecraft:green_terracotta
setblock 339 77 559 minecraft:oak_log
fill 339 77 560 339 80 560 minecraft:green_terracotta
setblock 340 77 558 minecraft:oak_log
fill 340 77 559 340 80 559 minecraft:green_terracotta
setblock 340 77 598 minecraft:oak_log
fill 341 77 558 344 77 558 minecraft:green_terracotta
fill 341 77 598 341 80 598 minecraft:green_terracotta
setblock 343 77 560 minecraft:oak_log
setblock 344 77 559 minecraft:oak_log
fill 344 77 560 344 80 560 minecraft:green_terracotta
setblock 345 77 558 minecraft:oak_log
fill 345 77 559 345 80 559 minecraft:green_terracotta
fill 345 77 591 345 87 591 minecraft:iron_block
setblock 345 77 598 minecraft:oak_log
fill 346 77 558 349 77 558 minecraft:green_terracotta
setblock 349 77 559 minecraft:oak_log
setblock 350 77 558 minecraft:oak_log
fill 350 77 559 350 80 559 minecraft:green_terracotta
fill 351 77 558 351 80 558 minecraft:green_terracotta
setblock 354 77 559 minecraft:oak_log
setblock 355 77 558 minecraft:oak_log
fill 355 77 559 355 80 559 minecraft:green_terracotta
setblock 355 77 598 minecraft:oak_log
fill 356 77 558 356 80 558 minecraft:green_terracotta
setblock 356 77 597 minecraft:oak_log
fill 356 77 598 356 80 598 minecraft:green_terracotta
fill 357 77 597 357 80 597 minecraft:green_terracotta
setblock 358 77 560 minecraft:oak_log
setblock 359 77 559 minecraft:oak_log
fill 359 77 560 359 80 560 minecraft:green_terracotta
setblock 360 77 558 minecraft:oak_log
fill 360 77 559 360 80 559 minecraft:green_terracotta
setblock 360 77 598 minecraft:oak_log
fill 361 77 558 361 80 558 minecraft:green_terracotta
setblock 361 77 597 minecraft:oak_log
fill 361 77 598 361 80 598 minecraft:green_terracotta
setblock 362 77 596 minecraft:oak_log
fill 362 77 597 362 80 597 minecraft:green_terracotta
setblock 364 77 559 minecraft:oak_log
setblock 365 77 558 minecraft:oak_log
setblock 365 77 559 minecraft:green_terracotta
setblock 365 77 598 minecraft:oak_log
fill 366 77 558 366 79 558 minecraft:green_terracotta
fill 366 77 598 366 80 598 minecraft:green_terracotta
setblock 370 77 573 minecraft:oak_leaves[persistent=true]
setblock 370 77 578 minecraft:oak_log
fill 370 77 579 370 80 579 minecraft:green_terracotta
setblock 370 77 583 minecraft:oak_log
fill 370 77 584 370 79 585 minecraft:green_terracotta
setblock 370 77 592 minecraft:oak_leaves[persistent=true]
setblock 330 78 564 minecraft:oak_leaves[persistent=true]
fill 330 78 570 330 79 570 minecraft:oak_leaves[persistent=true]
setblock 330 78 577 minecraft:oak_log
fill 330 78 578 330 81 578 minecraft:green_terracotta
setblock 330 78 582 minecraft:oak_log
fill 330 78 583 330 81 583 minecraft:green_terracotta
setblock 330 78 589 minecraft:oak_leaves[persistent=true]
setblock 331 78 581 minecraft:oak_log
fill 331 78 582 331 81 582 minecraft:green_terracotta
setblock 334 78 558 minecraft:oak_log
fill 335 78 558 335 81 558 minecraft:green_terracotta
fill 335 78 583 335 79 583 minecraft:glowstone
setblock 338 78 559 minecraft:oak_log
fill 338 78 560 338 81 560 minecraft:green_terracotta
setblock 339 78 558 minecraft:oak_log
fill 339 78 559 339 81 559 minecraft:green_terracotta
setblock 339 78 598 minecraft:oak_log
fill 340 78 558 343 78 558 minecraft:green_terracotta
fill 340 78 598 340 81 598 minecraft:green_terracotta
fill 341 78 588 341 88 588 minecraft:dark_oak_log
setblock 342 78 560 minecraft:oak_log
setblock 343 78 559 minecraft:oak_log
fill 343 78 560 343 81 560 minecraft:green_terracotta
setblock 344 78 558 minecraft:oak_log
fill 344 78 559 344 81 559 minecraft:green_terracotta
fill 345 78 558 348 78 558 minecraft:green_terracotta
setblock 346 78 598 minecraft:oak_leaves[persistent=true]
setblock 348 78 559 minecraft:oak_log
setblock 349 78 558 minecraft:oak_log
fill 349 78 559 349 81 559 minecraft:green_terracotta
fill 350 78 558 350 81 558 minecraft:green_terracotta
setblock 353 78 559 minecraft:oak_log
setblock 354 78 558 minecraft:oak_log
fill 354 78 559 354 81 559 minecraft:green_terracotta
setblock 354 78 598 minecraft:oak_log
fill 355 78 558 355 81 558 minecraft:green_terracotta
fill 355 78 560 355 79 560 minecraft:green_terracotta
fill 355 78 598 355 81 598 minecraft:green_terracotta
fill 356 78 597 356 81 597 minecraft:green_terracotta
setblock 357 78 560 minecraft:oak_log
setblock 358 78 559 minecraft:oak_log
fill 358 78 560 358 81 560 minecraft:green_terracotta
setblock 359 78 558 minecraft:oak_log
fill 359 78 559 359 81 559 minecraft:green_terracotta
setblock 359 78 598 minecraft:oak_log
fill 360 78 558 360 81 558 minecraft:green_terracotta
setblock 360 78 597 minecraft:oak_log
fill 360 78 598 360 81 598 minecraft:green_terracotta
fill 361 78 597 361 81 597 minecraft:green_terracotta
setblock 363 78 559 minecraft:oak_log
setblock 364 78 558 minecraft:oak_log
setblock 364 78 559 minecraft:green_terracotta
setblock 364 78 598 minecraft:oak_log
fill 365 78 558 365 81 558 minecraft:green_terracotta
fill 365 78 598 365 81 598 minecraft:green_terracotta
setblock 370 78 567 minecraft:oak_leaves[persistent=true]
setblock 370 78 582 minecraft:oak_log
fill 370 78 583 370 81 583 minecraft:green_terracotta
setblock 370 78 586 minecraft:green_terracotta
setblock 330 79 576 minecraft:oak_log
fill 330 79 577 330 82 577 minecraft:green_terracotta
setblock 330 79 581 minecraft:oak_log
fill 330 79 582 330 82 582 minecraft:green_terracotta
setblock 330 79 586 minecraft:oak_log
setblock 330 79 595 minecraft:oak_leaves[persistent=true]
fill 331 79 578 331 80 578 minecraft:green_terracotta
setblock 331 79 580 minecraft:oak_log
fill 331 79 581 331 82 581 minecraft:green_terracotta
fill 331 79 583 331 80 583 minecraft:green_terracotta
setblock 333 79 558 minecraft:oak_log
fill 334 79 558 334 82 558 minecraft:green_terracotta
fill 335 79 559 335 80 559 minecraft:green_terracotta
setblock 337 79 558 minecraft:green_terracotta
setblock 337 79 559 minecraft:oak_log
fill 337 79 560 337 82 560 minecraft:green_terracotta
setblock 338 79 558 minecraft:oak_log
fill 338 79 559 338 82 559 minecraft:green_terracotta
setblock 338 79 598 minecraft:oak_log
fill 339 79 558 342 79 558 minecraft:green_terracotta
fill 339 79 598 339 82 598 minecraft:green_terracotta
setblock 341 79 560 minecraft:oak_log
setblock 342 79 559 minecraft:oak_log
fill 342 79 560 342 82 560 minecraft:green_terracotta
setblock 343 79 558 minecraft:oak_log
fill 343 79 559 343 82 559 minecraft:green_terracotta
fill 344 79 558 347 79 558 minecraft:green_terracotta
setblock 347 79 559 minecraft:oak_log
setblock 348 79 558 minecraft:oak_log
fill 348 79 559 348 82 559 minecraft:green_terracotta
fill 349 79 558 349 82 558 minecraft:green_terracotta
setblock 352 79 559 minecraft:oak_log
setblock 353 79 558 minecraft:oak_log
fill 353 79 559 353 82 559 minecraft:green_terracotta
setblock 353 79 598 minecraft:oak_log
fill 354 79 558 354 82 558 minecraft:green_terracotta
fill 354 79 560 354 80 560 minecraft:green_terracotta
fill 354 79 598 354 82 598 minecraft:green_terracotta
fill 355 79 597 355 82 597 minecraft:green_terracotta
setblock 356 79 559 minecraft:green_terracotta
setblock 356 79 560 minecraft:oak_log
setblock 357 79 559 minecraft:oak_log
fill 357 79 560 357 82 560 minecraft:green_terracotta
setblock 358 79 558 minecraft:oak_log
fill 358 79 559 358 82 559 minecraft:green_terracotta
setblock 358 79 598 minecraft:oak_log
fill 359 79 558 359 82 558 minecraft:green_terracotta
setblock 359 79 597 minecraft:oak_log
fill 359 79 598 359 82 598 minecraft:green_terracotta
fill 360 79 597 360 82 597 minecraft:green_terracotta
setblock 361 79 560 minecraft:oak_log
setblock 362 79 559 minecraft:oak_log
setblock 363 79 558 minecraft:oak_log
fill 363 79 559 363 81 559 minecraft:green_terracotta
setblock 363 79 598 minecraft:oak_log
fill 364 79 558 364 82 558 minecraft:green_terracotta
fill 364 79 598 364 82 598 minecraft:green_terracotta
setblock 370 79 561 minecraft:oak_leaves[persistent=true]
fill 370 79 578 370 81 578 minecraft:green_terracotta
setblock 370 79 581 minecraft:oak_log
fill 370 79 582 370 82 582 minecraft:green_terracotta
setblock 370 79 586 minecraft:oak_log
fill 370 79 587 370 82 587 minecraft:green_terracotta
fill 330 80 576 330 83 576 minecraft:green_terracotta
setblock 330 80 580 minecraft:oak_log
fill 330 80 581 330 83 581 minecraft:green_terracotta
setblock 330 80 584 minecraft:green_terracotta
setblock 330 80 585 minecraft:oak_log
fill 330 80 586 330 82 587 minecraft:green_terracotta
setblock 331 80 579 minecraft:oak_log
fill 331 80 580 331 83 580 minecraft:green_terracotta
setblock 331 80 584 minecraft:oak_log
setblock 332 80 560 minecraft:light[level=14]
setblock 332 80 568 minecraft:light[level=14]
setblock 332 80 576 minecraft:light[level=14]
setblock 332 80 584 minecraft:light[level=14]
setblock 332 80 592 minecraft:light[level=14]
fill 333 80 558 333 83 558 minecraft:green_terracotta
setblock 333 80 598 minecraft:oak_leaves[persistent=true]
fill 334 80 559 334 81 559 minecraft:green_terracotta
fill 335 80 582 335 88 583 minecraft:dark_oak_log
setblock 336 80 558 minecraft:green_terracotta
setblock 336 80 559 minecraft:oak_log
fill 336 80 560 336 83 560 minecraft:green_terracotta
setblock 337 80 558 minecraft:oak_log
fill 337 80 559 337 83 559 minecraft:green_terracotta
setblock 337 80 598 minecraft:oak_log
fill 338 80 558 341 80 558 minecraft:green_terracotta
fill 338 80 598 338 83 598 minecraft:green_terracotta
fill 339 80 585 339 81 586 minecraft:glowstone
setblock 340 80 560 minecraft:oak_log
setblock 340 80 568 minecraft:light[level=14]
setblock 340 80 576 minecraft:light[level=14]
setblock 340 80 584 minecraft:light[level=14]
setblock 340 80 592 minecraft:light[level=14]
setblock 341 80 559 minecraft:oak_log
fill 341 80 560 341 83 560 minecraft:green_terracotta
fill 341 80 587 342 88 587 minecraft:dark_oak_log
fill 341 80 589 341 88 589 minecraft:dark_oak_log
setblock 342 80 558 minecraft:oak_log
fill 342 80 559 342 83 559 minecraft:green_terracotta
fill 342 80 588 342 88 588 minecraft:dark_oak_log
fill 343 80 558 346 80 558 minecraft:green_terracotta
setblock 346 80 559 minecraft:oak_log
setblock 347 80 558 minecraft:oak_log
fill 347 80 559 347 83 559 minecraft:green_terracotta
fill 348 80 558 348 83 558 minecraft:green_terracotta
setblock 348 80 560 minecraft:light[level=14]
setblock 348 80 568 minecraft:light[level=14]
setblock 348 80 576 minecraft:light[level=14]
setblock 348 80 584 minecraft:light[level=14]
setblock 348 80 592 minecraft:light[level=14]
setblock 351 80 559 minecraft:oak_log
setblock 352 80 558 minecraft:oak_log
fill 352 80 559 352 83 559 minecraft:green_terracotta
setblock 352 80 598 minecraft:oak_log
fill 353 80 558 353 83 558 minecraft:green_terracotta
fill 353 80 560 353 81 560 minecraft:green_terracotta
fill 353 80 598 353 83 598 minecraft:green_terracotta
setblock 355 80 560 minecraft:oak_log
setblock 356 80 559 minecraft:oak_log
fill 356 80 560 356 83 560 minecraft:green_terracotta
setblock 356 80 568 minecraft:light[level=14]
setblock 356 80 576 minecraft:light[level=14]
setblock 356 80 584 minecraft:light[level=14]
setblock 356 80 592 minecraft:light[level=14]
setblock 357 80 558 minecraft:oak_log
fill 357 80 559 357 83 559 minecraft:green_terracotta
setblock 357 80 598 minecraft:oak_log
fill 358 80 558 358 83 558 minecraft:green_terracotta
setblock 358 80 597 minecraft:oak_log
fill 358 80 598 358 83 598 minecraft:green_terracotta
fill 359 80 597 359 83 597 minecraft:green_terracotta
setblock 360 80 560 minecraft:oak_log
setblock 361 80 559 minecraft:oak_log
fill 361 80 560 361 81 560 minecraft:green_terracotta
setblock 362 80 558 minecraft:oak_log
fill 362 80 559 362 83 559 minecraft:green_terracotta
setblock 362 80 598 minecraft:oak_log
fill 363 80 558 363 83 558 minecraft:green_terracotta
setblock 363 80 597 minecraft:oak_log
fill 363 80 598 363 83 598 minecraft:green_terracotta
setblock 364 80 560 minecraft:light[level=14]
setblock 364 80 568 minecraft:light[level=14]
setblock 364 80 576 minecraft:light[level=14]
setblock 364 80 584 minecraft:light[level=14]
setblock 364 80 592 minecraft:light[level=14]
setblock 367 80 558 minecraft:oak_leaves[persistent=true]
fill 369 80 582 369 81 584 minecraft:green_terracotta
setblock 370 80 574 minecraft:oak_leaves[persistent=true]
setblock 370 80 580 minecraft:oak_log
fill 370 80 581 370 83 581 minecraft:green_terracotta
setblock 370 80 584 minecraft:green_terracotta
setblock 370 80 585 minecraft:oak_log
fill 370 80 586 370 83 586 minecraft:green_terracotta
fill 370 80 588 370 81 588 minecraft:green_terracotta
fill 330 81 560 330 81 563 minecraft:green_terracotta
setblock 330 81 564 minecraft:oak_log
fill 330 81 565 330 84 565 minecraft:green_terracotta
fill 330 81 575 330 84 575 minecraft:green_terracotta
setblock 330 81 579 minecraft:oak_log
fill 330 81 580 330 84 580 minecraft:green_terracotta
setblock 330 81 584 minecraft:oak_log
fill 330 81 585 331 83 585 minecraft:green_terracotta
setblock 330 81 588 minecraft:green_terracotta
setblock 331 81 578 minecraft:oak_log
fill 331 81 579 331 84 579 minecraft:green_terracotta
setblock 331 81 583 minecraft:oak_log
fill 331 81 584 331 84 584 minecraft:green_terracotta
fill 331 81 586 331 82 586 minecraft:green_terracotta
fill 332 81 558 332 84 558 minecraft:green_terracotta
setblock 332 81 581 minecraft:green_terracotta
setblock 332 81 582 minecraft:oak_log
fill 332 81 583 332 84 583 minecraft:green_terracotta
fill 333 81 559 333 82 559 minecraft:green_terracotta
fill 334 81 583 334 88 583 minecraft:dark_oak_log
setblock 335 81 559 minecraft:oak_log
fill 335 81 560 335 84 560 minecraft:green_terracotta
setblock 336 81 558 minecraft:oak_log
fill 336 81 559 336 84 559 minecraft:green_terracotta
setblock 336 81 598 minecraft:oak_log
fill 337 81 558 340 81 558 minecraft:green_terracotta
setblock 337 81 561 minecraft:green_terracotta
fill 337 81 598 337 84 598 minecraft:green_terracotta
setblock 338 81 561 minecraft:oak_log
setblock 339 81 560 minecraft:oak_log
fill 339 81 561 340 83 561 minecraft:green_terracotta
setblock 340 81 559 minecraft:oak_log
fill 340 81 560 340 84 560 minecraft:green_terracotta
fill 340 81 587 340 88 589 minecraft:dark_oak_log
setblock 341 81 558 minecraft:oak_log
fill 341 81 559 341 84 559 minecraft:green_terracotta
setblock 341 81 598 minecraft:oak_log
fill 342 81 558 345 81 558 minecraft:green_terracotta
fill 342 81 589 342 88 589 minecraft:dark_oak_log
setblock 344 81 560 minecraft:oak_log
setblock 345 81 559 minecraft:oak_log
setblock 346 81 558 minecraft:oak_log
fill 346 81 559 346 84 559 minecraft:green_terracotta
fill 347 81 558 347 84 558 minecraft:green_terracotta
setblock 350 81 559 minecraft:oak_log
setblock 351 81 558 minecraft:oak_log
fill 351 81 559 351 84 559 minecraft:green_terracotta
setblock 351 81 598 minecraft:oak_log
fill 352 81 558 352 84 558 minecraft:green_terracotta
fill 352 81 560 352 82 560 minecraft:green_terracotta
fill 352 81 598 352 84 598 minecraft:green_terracotta
setblock 354 81 560 minecraft:oak_log
fill 354 81 597 354 83 597 minecraft:green_terracotta
setblock 355 81 559 minecraft:oak_log
fill 355 81 560 355 84 560 minecraft:green_terracotta
setblock 356 81 558 minecraft:oak_log
fill 356 81 559 356 84 559 minecraft:green_terracotta
setblock 356 81 598 minecraft:oak_log
fill 357 81 558 357 84 558 minecraft:green_terracotta
setblock 357 81 597 minecraft:oak_log
fill 357 81 598 357 84 598 minecraft:green_terracotta
fill 358 81 597 358 84 597 minecraft:green_terracotta
setblock 359 81 560 minecraft:oak_log
setblock 360 81 559 minecraft:oak_log
fill 360 81 560 360 83 560 minecraft:green_terracotta
setblock 361 81 558 minecraft:oak_log
fill 361 81 559 361 84 559 minecraft:green_terracotta
setblock 361 81 598 minecraft:oak_log
fill 362 81 558 362 84 558 minecraft:green_terracotta
setblock 362 81 597 minecraft:oak_log
fill 362 81 598 362 84 598 minecraft:green_terracotta
fill 369 81 581 369 84 581 minecraft:green_terracotta
setblock 369 81 585 minecraft:oak_log
fill 369 81 586 369 84 586 minecraft:green_terracotta
setblock 370 81 568 minecraft:oak_leaves[persistent=true]
setblock 370 81 579 minecraft:oak_log
fill 370 81 580 370 84 580 minecraft:green_terracotta
setblock 370 81 584 minecraft:oak_log
fill 370 81 585 370 84 585 minecraft:green_terracotta
setblock 370 81 589 minecraft:oak_log
fill 370 81 590 370 84 590 minecraft:green_terracotta
setblock 370 81 593 minecraft:oak_leaves[persistent=true]
fill 330 82 559 330 82 562 minecraft:green_terracotta
setblock 330 82 563 minecraft:oak_log
fill 330 82 564 331 84 564 minecraft:green_terracotta
fill 330 82 566 330 82 567 minecraft:green_terracotta
setblock 330 82 568 minecraft:oak_log
fill 330 82 569 330 85 569 minecraft:green_terracotta
fill 330 82 574 330 85 574 minecraft:green_terracotta
setblock 330 82 578 minecraft:oak_log
fill 330 82 579 330 85 579 minecraft:green_terracotta
setblock 330 82 583 minecraft:oak_log
fill 330 82 584 330 85 584 minecraft:green_terracotta
setblock 330 82 588 minecraft:oak_log
fill 330 82 589 330 85 589 minecraft:green_terracotta
setblock 330 82 594 minecraft:oak_leaves[persistent=true]
fill 331 82 558 331 85 558 minecraft:green_terracotta
setblock 331 82 561 minecraft:green_terracotta
setblock 331 82 562 minecraft:oak_log
fill 331 82 563 331 85 563 minecraft:green_terracotta
fill 331 82 565 331 82 566 minecraft:green_terracotta
setblock 331 82 577 minecraft:oak_log
fill 331 82 578 331 85 578 minecraft:green_terracotta
setblock 331 82 582 minecraft:oak_log
fill 331 82 583 331 85 583 minecraft:green_terracotta
setblock 331 82 587 minecraft:oak_log
setblock 332 82 580 minecraft:green_terracotta
setblock 332 82 581 minecraft:oak_log
fill 332 82 582 332 85 582 minecraft:green_terracotta
fill 332 82 584 332 82 585 minecraft:green_terracotta
setblock 334 82 559 minecraft:oak_log
fill 334 82 560 334 85 560 minecraft:green_terracotta
fill 334 82 582 334 88 582 minecraft:dark_oak_log
setblock 335 82 558 minecraft:oak_log
fill 335 82 559 335 85 559 minecraft:green_terracotta
fill 335 82 584 335 88 584 minecraft:dark_oak_log
fill 336 82 558 339 82 558 minecraft:green_terracotta
setblock 336 82 561 minecraft:green_terracotta
fill 336 82 582 336 88 583 minecraft:dark_oak_log
fill 336 82 598 336 85 598 minecraft:green_terracotta
setblock 337 82 561 minecraft:oak_log
setblock 338 82 560 minecraft:oak_log
fill 338 82 561 338 85 561 minecraft:green_terracotta
setblock 339 82 559 minecraft:oak_log
fill 339 82 560 339 85 560 minecraft:green_terracotta
setblock 340 82 558 minecraft:oak_log
fill 340 82 559 340 85 559 minecraft:green_terracotta
setblock 340 82 598 minecraft:oak_log
fill 341 82 558 344 82 558 minecraft:green_terracotta
setblock 341 82 561 minecraft:green_terracotta
fill 341 82 586 342 88 586 minecraft:dark_oak_log
fill 341 82 590 341 88 590 minecraft:dark_oak_log
setblock 343 82 560 minecraft:oak_log
fill 343 82 587 343 88 589 minecraft:dark_oak_log
setblock 344 82 559 minecraft:oak_log
fill 344 82 560 344 83 560 minecraft:green_terracotta
setblock 345 82 558 minecraft:oak_log
fill 345 82 559 345 85 559 minecraft:green_terracotta
setblock 345 82 598 minecraft:oak_leaves[persistent=true]
fill 346 82 558 346 85 558 minecraft:green_terracotta
setblock 349 82 559 minecraft:oak_log
setblock 350 82 558 minecraft:oak_log
fill 350 82 559 350 85 559 minecraft:green_terracotta
setblock 350 82 598 minecraft:oak_log
fill 351 82 558 351 85 558 minecraft:green_terracotta
fill 351 82 560 351 83 560 minecraft:green_terracotta
fill 351 82 598 351 85 598 minecraft:green_terracotta
setblock 353 82 560 minecraft:oak_log
fill 353 82 597 353 84 597 minecraft:green_terracotta
setblock 354 82 559 minecraft:oak_log
fill 354 82 560 354 85 560 minecraft:green_terracotta
setblock 355 82 558 minecraft:oak_log
fill 355 82 559 355 85 559 minecraft:green_terracotta
fill 355 82 561 356 82 561 minecraft:green_terracotta
setblock 355 82 598 minecraft:oak_log
fill 356 82 558 356 85 558 minecraft:green_terracotta
setblock 356 82 597 minecraft:oak_log
fill 356 82 598 356 85 598 minecraft:green_terracotta
setblock 357 82 561 minecraft:oak_log
fill 357 82 597 357 85 597 minecraft:green_terracotta
setblock 358 82 560 minecraft:oak_log
setblock 359 82 559 minecraft:oak_log
fill 359 82 560 359 84 560 minecraft:green_terracotta
setblock 360 82 558 minecraft:oak_log
fill 360 82 559 360 85 559 minecraft:green_terracotta
setblock 360 82 598 minecraft:oak_log
fill 361 82 558 361 85 558 minecraft:green_terracotta
setblock 361 82 597 minecraft:oak_log
fill 361 82 598 361 85 598 minecraft:green_terracotta
setblock 362 82 597 minecraft:green_terracotta
setblock 365 82 598 minecraft:oak_log
fill 369 82 580 369 85 580 minecraft:green_terracotta
fill 369 82 582 369 82 583 minecraft:green_terracotta
setblock 369 82 584 minecraft:oak_log
fill 369 82 585 369 85 585 minecraft:green_terracotta
fill 369 82 587 369 82 588 minecraft:green_terracotta
setblock 370 82 562 minecraft:oak_leaves[persistent=true]
setblock 370 82 577 minecraft:green_terracotta
setblock 370 82 578 minecraft:oak_log
fill 370 82 579 370 85 579 minecraft:green_terracotta
setblock 370 82 583 minecraft:oak_log
fill 370 82 584 370 85 584 minecraft:green_terracotta
setblock 370 82 588 minecraft:oak_log
fill 370 82 589 370 85 589 minecraft:green_terracotta
fill 370 82 591 370 83 591 minecraft:green_terracotta
setblock 370 82 598 minecraft:oak_leaves[persistent=true]
fill 330 83 559 330 83 561 minecraft:green_terracotta
setblock 330 83 562 minecraft:oak_log
fill 330 83 563 330 86 563 minecraft:green_terracotta
setblock 330 83 566 minecraft:green_terracotta
setblock 330 83 567 minecraft:oak_log
fill 330 83 568 331 85 568 minecraft:green_terracotta
fill 330 83 570 330 83 571 minecraft:green_terracotta
setblock 330 83 572 minecraft:oak_log
fill 330 83 573 330 86 573 minecraft:green_terracotta
setblock 330 83 577 minecraft:oak_log
fill 330 83 578 330 86 578 minecraft:green_terracotta
setblock 330 83 582 minecraft:oak_log
fill 330 83 583 330 86 583 minecraft:green_terracotta
setblock 330 83 586 minecraft:green_terracotta
setblock 330 83 587 minecraft:oak_log
fill 330 83 588 331 85 588 minecraft:green_terracotta
fill 330 83 590 330 84 590 minecraft:green_terracotta
setblock 331 83 560 minecraft:green_terracotta
setblock 331 83 561 minecraft:oak_log
fill 331 83 562 332 85 562 minecraft:green_terracotta
setblock 331 83 565 minecraft:green_terracotta
setblock 331 83 566 minecraft:oak_log
fill 331 83 567 332 85 567 minecraft:green_terracotta
fill 331 83 569 331 83 570 minecraft:green_terracotta
setblock 331 83 576 minecraft:oak_log
fill 331 83 577 331 86 577 minecraft:green_terracotta
setblock 331 83 581 minecraft:oak_log
fill 331 83 582 331 86 582 minecraft:green_terracotta
setblock 331 83 586 minecraft:oak_log
fill 331 83 587 331 86 587 minecraft:green_terracotta
setblock 332 83 559 minecraft:green_terracotta
fill 332 83 563 332 83 564 minecraft:green_terracotta
setblock 332 83 565 minecraft:oak_log
fill 332 83 566 332 86 566 minecraft:green_terracotta
setblock 332 83 579 minecraft:green_terracotta
setblock 332 83 580 minecraft:oak_log
fill 332 83 581 332 86 581 minecraft:green_terracotta
setblock 332 83 584 minecraft:green_terracotta
setblock 332 83 585 minecraft:oak_log
fill 332 83 586 332 86 586 minecraft:green_terracotta
setblock 332 83 598 minecraft:oak_leaves[persistent=true]
setblock 333 83 559 minecraft:oak_log
fill 333 83 560 333 86 560 minecraft:green_terracotta
fill 333 83 583 333 88 583 minecraft:dark_oak_log
setblock 334 83 558 minecraft:oak_log
fill 334 83 559 334 86 559 minecraft:green_terracotta
fill 334 83 581 336 88 581 minecraft:dark_oak_log
fill 334 83 584 334 88 584 minecraft:dark_oak_log
fill 335 83 558 338 83 558 minecraft:green_terracotta
setblock 335 83 561 minecraft:green_terracotta
fill 335 83 598 335 86 598 minecraft:green_terracotta
setblock 336 83 561 minecraft:oak_log
fill 336 83 584 336 88 584 minecraft:dark_oak_log
setblock 337 83 560 minecraft:oak_log
fill 337 83 561 337 86 561 minecraft:green_terracotta
setblock 338 83 559 minecraft:oak_log
fill 338 83 560 338 86 560 minecraft:green_terracotta
setblock 339 83 558 minecraft:oak_log
fill 339 83 559 339 86 559 minecraft:green_terracotta
fill 339 83 587 339 88 589 minecraft:dark_oak_log
setblock 339 83 598 minecraft:oak_log
fill 340 83 558 343 83 558 minecraft:green_terracotta
fill 340 83 586 340 88 586 minecraft:dark_oak_log
fill 340 83 590 340 88 590 minecraft:dark_oak_log
fill 340 83 598 340 84 598 minecraft:green_terracotta
setblock 341 83 561 minecraft:oak_log
setblock 342 83 560 minecraft:oak_log
fill 342 83 561 342 91 561 minecraft:oak_leaves[persistent=true]
fill 342 83 590 342 88 590 minecraft:dark_oak_log
setblock 343 83 559 minecraft:oak_log
fill 343 83 560 343 84 560 minecraft:green_terracotta
fill 343 83 586 343 88 586 minecraft:dark_oak_log
setblock 344 83 558 minecraft:oak_log
fill 344 83 559 344 86 559 minecraft:green_terracotta
fill 345 83 558 345 86 558 minecraft:green_terracotta
setblock 348 83 559 minecraft:oak_log
setblock 349 83 558 minecraft:oak_log
fill 349 83 559 349 86 559 minecraft:green_terracotta
fill 350 83 558 350 86 558 minecraft:green_terracotta
fill 350 83 560 350 84 560 minecraft:green_terracotta
fill 350 83 598 350 86 598 minecraft:green_terracotta
setblock 352 83 560 minecraft:oak_log
setblock 353 83 559 minecraft:oak_log
fill 353 83 560 353 86 560 minecraft:green_terracotta
setblock 354 83 558 minecraft:oak_log
fill 354 83 559 354 86 559 minecraft:green_terracotta
fill 354 83 561 355 83 561 minecraft:green_terracotta
setblock 354 83 598 minecraft:oak_log
fill 355 83 558 355 86 558 minecraft:green_terracotta
setblock 355 83 597 minecraft:oak_log
fill 355 83 598 355 86 598 minecraft:green_terracotta
setblock 356 83 561 minecraft:oak_log
fill 356 83 597 356 86 597 minecraft:green_terracotta
setblock 357 83 560 minecraft:oak_log
setblock 357 83 561 minecraft:green_terracotta
fill 357 83 596 358 85 596 minecraft:green_terracotta
setblock 358 83 559 minecraft:oak_log
fill 358 83 560 358 85 560 minecraft:green_terracotta
setblock 359 83 558 minecraft:oak_log
fill 359 83 559 359 86 559 minecraft:green_terracotta
setblock 359 83 598 minecraft:oak_log
fill 360 83 558 360 86 558 minecraft:green_terracotta
setblock 360 83 597 minecraft:oak_log
fill 360 83 598 360 86 598 minecraft:green_terracotta
fill 361 83 597 361 84 597 minecraft:green_terracotta
setblock 364 83 558 minecraft:oak_log
setblock 364 83 598 minecraft:oak_log
setblock 368 83 558 minecraft:oak_leaves[persistent=true]
setblock 368 83 584 minecraft:oak_log
fill 368 83 585 368 86 585 minecraft:green_terracotta
setblock 369 83 582 minecraft:green_terracotta
setblock 369 83 583 minecraft:oak_log
fill 369 83 584 369 86 584 minecraft:green_terracotta
setblock 369 83 587 minecraft:green_terracotta
setblock 369 83 588 minecraft:oak_log
fill 369 83 589 369 86 589 minecraft:green_terracotta
setblock 370 83 561 minecraft:green_terracotta
setblock 370 83 562 minecraft:oak_log
fill 370 83 563 370 83 566 minecraft:green_terracotta
setblock 370 83 577 minecraft:oak_log
fill 370 83 578 370 86 578 minecraft:green_terracotta
setblock 370 83 582 minecraft:oak_log
fill 370 83 583 370 86 583 minecraft:green_terracotta
setblock 370 83 587 minecraft:oak_log
fill 370 83 588 370 86 588 minecraft:green_terracotta
setblock 370 83 592 minecraft:oak_log
fill 330 84 558 330 84 560 minecraft:green_terracotta
setblock 330 84 561 minecraft:oak_log
fill 330 84 562 330 87 562 minecraft:green_terracotta
setblock 330 84 566 minecraft:oak_log
fill 330 84 567 330 87 567 minecraft:green_terracotta
setblock 330 84 570 minecraft:green_terracotta
setblock 330 84 571 minecraft:oak_log
fill 330 84 572 331 86 572 minecraft:green_terracotta
setblock 330 84 576 minecraft:oak_log
fill 330 84 577 330 87 577 minecraft:green_terracotta
setblock 330 84 581 minecraft:oak_log
fill 330 84 582 330 87 582 minecraft:green_terracotta
setblock 330 84 585 minecraft:green_terracotta
setblock 330 84 586 minecraft:oak_log
fill 330 84 587 330 87 587 minecraft:green_terracotta
setblock 330 84 591 minecraft:oak_log
setblock 331 84 560 minecraft:oak_log
fill 331 84 561 332 86 561 minecraft:green_terracotta
setblock 331 84 565 minecraft:oak_log
fill 331 84 566 331 87 566 minecraft:green_terracotta
setblock 331 84 569 minecraft:green_terracotta
setblock 331 84 570 minecraft:oak_log
fill 331 84 571 331 87 571 minecraft:green_terracotta
fill 331 84 573 331 84 574 minecraft:green_terracotta
setblock 331 84 575 minecraft:oak_log
fill 331 84 576 331 87 576 minecraft:green_terracotta
setblock 331 84 580 minecraft:oak_log
fill 331 84 581 331 87 581 minecraft:green_terracotta
setblock 331 84 585 minecraft:oak_log
fill 331 84 586 331 87 586 minecraft:green_terracotta
setblock 331 84 589 minecraft:green_terracotta
setblock 332 84 559 minecraft:oak_log
setblock 332 84 563 minecraft:green_terracotta
setblock 332 84 564 minecraft:oak_log
fill 332 84 565 333 86 565 minecraft:green_terracotta
setblock 332 84 568 minecraft:green_terracotta
setblock 332 84 569 minecraft:oak_log
fill 332 84 570 332 87 570 minecraft:green_terracotta
setblock 332 84 579 minecraft:oak_log
fill 332 84 580 332 86 580 minecraft:green_terracotta
setblock 332 84 584 minecraft:oak_log
fill 332 84 585 332 87 585 minecraft:green_terracotta
fill 332 84 587 332 85 587 minecraft:green_terracotta
setblock 333 84 558 minecraft:oak_log
fill 333 84 559 333 87 559 minecraft:green_terracotta
setblock 333 84 563 minecraft:oak_log
fill 333 84 564 333 87 564 minecraft:green_terracotta
fill 333 84 566 333 84 567 minecraft:green_terracotta
fill 333 84 582 333 88 582 minecraft:dark_oak_log
fill 333 84 584 333 88 584 minecraft:dark_oak_log
fill 334 84 558 337 84 558 minecraft:green_terracotta
setblock 334 84 561 minecraft:green_terracotta
fill 334 84 598 334 87 598 minecraft:green_terracotta
setblock 335 84 561 minecraft:oak_log
fill 335 84 585 335 88 585 minecraft:dark_oak_log
setblock 336 84 560 minecraft:oak_log
fill 336 84 561 336 86 561 minecraft:green_terracotta
setblock 337 84 559 minecraft:oak_log
fill 337 84 560 337 87 560 minecraft:green_terracotta
fill 337 84 582 337 88 583 minecraft:dark_oak_log
setblock 338 84 558 minecraft:oak_log
fill 338 84 559 338 87 559 minecraft:green_terracotta
setblock 338 84 598 minecraft:oak_log
fill 339 84 558 342 84 558 minecraft:green_terracotta
setblock 339 84 561 minecraft:green_terracotta
fill 339 84 586 339 88 586 minecraft:dark_oak_log
fill 339 84 590 339 88 590 minecraft:dark_oak_log
fill 339 84 598 339 85 598 minecraft:green_terracotta
setblock 340 84 561 minecraft:oak_log
fill 340 84 585 342 88 585 minecraft:dark_oak_log
setblock 341 84 560 minecraft:oak_log
setblock 342 84 559 minecraft:oak_log
fill 342 84 560 342 85 560 minecraft:green_terracotta
setblock 343 84 558 minecraft:oak_log
fill 343 84 559 343 86 559 minecraft:green_terracotta
fill 343 84 590 343 88 590 minecraft:dark_oak_log
fill 344 84 558 344 87 558 minecraft:green_terracotta
fill 344 84 587 344 88 589 minecraft:dark_oak_log
setblock 347 84 559 minecraft:oak_log
setblock 348 84 558 minecraft:oak_log
fill 348 84 559 348 87 559 minecraft:green_terracotta
fill 349 84 558 349 87 558 minecraft:green_terracotta
setblock 349 84 560 minecraft:green_terracotta
fill 349 84 598 349 87 598 minecraft:green_terracotta
setblock 351 84 560 minecraft:oak_log
setblock 352 84 559 minecraft:oak_log
fill 352 84 560 352 87 560 minecraft:green_terracotta
fill 352 84 597 352 85 597 minecraft:green_terracotta
setblock 353 84 558 minecraft:oak_log
fill 353 84 559 353 87 559 minecraft:green_terracotta
fill 353 84 561 354 84 561 minecraft:green_terracotta
setblock 353 84 598 minecraft:oak_log
fill 354 84 558 354 87 558 minecraft:green_terracotta
setblock 354 84 597 minecraft:oak_log
fill 354 84 598 354 87 598 minecraft:green_terracotta
setblock 355 84 561 minecraft:oak_log
setblock 355 84 596 minecraft:oak_log
fill 355 84 597 355 87 597 minecraft:green_terracotta
setblock 356 84 560 minecraft:oak_log
setblock 356 84 561 minecraft:green_terracotta
fill 356 84 596 356 87 596 minecraft:green_terracotta
setblock 357 84 559 minecraft:oak_log
fill 357 84 560 357 86 560 minecraft:green_terracotta
setblock 358 84 558 minecraft:oak_log
fill 358 84 559 358 86 559 minecraft:green_terracotta
setblock 358 84 598 minecraft:oak_log
fill 359 84 558 359 87 558 minecraft:green_terracotta
setblock 359 84 597 minecraft:oak_log
fill 359 84 598 359 87 598 minecraft:green_terracotta
fill 360 84 597 360 86 597 minecraft:green_terracotta
setblock 363 84 558 minecraft:oak_log
setblock 363 84 598 minecraft:oak_log
setblock 368 84 583 minecraft:oak_log
fill 368 84 584 368 87 584 minecraft:green_terracotta
fill 368 84 586 368 84 587 minecraft:green_terracotta
setblock 369 84 582 minecraft:oak_log
fill 369 84 583 369 87 583 minecraft:green_terracotta
setblock 369 84 587 minecraft:oak_log
fill 369 84 588 369 87 588 minecraft:green_terracotta
fill 369 84 590 369 85 590 minecraft:green_terracotta
setblock 370 84 560 minecraft:green_terracotta
setblock 370 84 561 minecraft:oak_log
fill 370 84 562 370 84 565 minecraft:green_terracotta
setblock 370 84 566 minecraft:oak_log
fill 370 84 567 370 85 569 minecraft:green_terracotta
setblock 370 84 575 minecraft:oak_leaves[persistent=true]
setblock 370 84 576 minecraft:oak_log
fill 370 84 577 370 87 577 minecraft:green_terracotta
setblock 370 84 581 minecraft:oak_log
fill 370 84 582 370 87 582 minecraft:green_terracotta
setblock 370 84 586 minecraft:oak_log
fill 370 84 587 370 87 587 minecraft:green_terracotta
setblock 370 84 591 minecraft:oak_log
fill 370 84 592 370 86 593 minecraft:green_terracotta
setblock 370 84 594 minecraft:oak_leaves[persistent=true]
fill 330 85 558 330 85 559 minecraft:green_terracotta
setblock 330 85 560 minecraft:oak_log
fill 330 85 561 330 88 561 minecraft:green_terracotta
setblock 330 85 564 minecraft:green_terracotta
setblock 330 85 565 minecraft:oak_log
fill 330 85 566 330 88 566 minecraft:green_terracotta
setblock 330 85 570 minecraft:oak_log
fill 330 85 571 330 88 571 minecraft:green_terracotta
setblock 330 85 575 minecraft:oak_log
fill 330 85 576 330 88 576 minecraft:green_terracotta
setblock 330 85 580 minecraft:oak_log
fill 330 85 581 330 88 581 minecraft:green_terracotta
setblock 330 85 585 minecraft:oak_log
fill 330 85 586 330 88 586 minecraft:green_terracotta
setblock 330 85 590 minecraft:oak_log
fill 330 85 591 330 87 592 minecraft:green_terracotta
setblock 331 85 559 minecraft:oak_log
fill 331 85 560 331 88 560 minecraft:green_terracotta
setblock 331 85 564 minecraft:oak_log
fill 331 85 565 331 88 565 minecraft:green_terracotta
setblock 331 85 569 minecraft:oak_log
fill 331 85 570 331 88 570 minecraft:green_terracotta
setblock 331 85 573 minecraft:green_terracotta
setblock 331 85 574 minecraft:oak_log
fill 331 85 575 331 88 575 minecraft:green_terracotta
setblock 331 85 579 minecraft:oak_log
fill 331 85 580 331 88 580 minecraft:green_terracotta
setblock 331 85 584 minecraft:oak_log
fill 331 85 585 331 88 585 minecraft:green_terracotta
setblock 331 85 589 minecraft:oak_log
fill 331 85 590 331 88 590 minecraft:green_terracotta
setblock 332 85 558 minecraft:oak_log
fill 332 85 559 332 88 559 minecraft:green_terracotta
setblock 332 85 563 minecraft:oak_log
fill 332 85 564 332 88 564 minecraft:green_terracotta
setblock 332 85 568 minecraft:oak_log
fill 332 85 569 333 87 569 minecraft:green_terracotta
fill 332 85 571 332 85 572 minecraft:green_terracotta
setblock 332 85 579 minecraft:green_terracotta
setblock 332 85 583 minecraft:oak_log
fill 332 85 584 332 88 584 minecraft:green_terracotta
setblock 332 85 588 minecraft:oak_log
fill 333 85 558 336 85 558 minecraft:green_terracotta
setblock 333 85 562 minecraft:oak_log
fill 333 85 563 333 88 563 minecraft:green_terracotta
setblock 333 85 566 minecraft:green_terracotta
setblock 333 85 567 minecraft:oak_log
fill 333 85 568 333 88 568 minecraft:green_terracotta
fill 333 85 581 333 88 581 minecraft:dark_oak_log
setblock 334 85 561 minecraft:oak_log
fill 334 85 580 336 88 580 minecraft:dark_oak_log
fill 334 85 585 334 88 585 minecraft:dark_oak_log
setblock 335 85 560 minecraft:oak_log
fill 335 85 561 335 86 561 minecraft:green_terracotta
setblock 336 85 559 minecraft:oak_log
fill 336 85 560 336 88 560 minecraft:green_terracotta
fill 336 85 585 336 88 585 minecraft:dark_oak_log
setblock 337 85 558 minecraft:oak_log
fill 337 85 559 337 88 559 minecraft:green_terracotta
fill 337 85 581 337 88 581 minecraft:dark_oak_log
fill 337 85 584 337 88 584 minecraft:dark_oak_log
setblock 337 85 598 minecraft:oak_log
fill 338 85 558 341 85 558 minecraft:green_terracotta
fill 338 85 587 338 88 589 minecraft:dark_oak_log
fill 338 85 598 338 86 598 minecraft:green_terracotta
setblock 339 85 561 minecraft:oak_log
fill 339 85 585 339 88 585 minecraft:dark_oak_log
setblock 340 85 560 minecraft:oak_log
fill 340 85 591 342 88 591 minecraft:dark_oak_log
setblock 341 85 559 minecraft:oak_log
setblock 341 85 560 minecraft:green_terracotta
setblock 342 85 558 minecraft:oak_log
fill 342 85 559 342 86 559 minecraft:green_terracotta
fill 343 85 558 343 87 558 minecraft:green_terracotta
fill 343 85 585 343 88 585 minecraft:dark_oak_log
fill 344 85 586 344 88 586 minecraft:dark_oak_log
fill 344 85 590 344 88 590 minecraft:dark_oak_log
setblock 344 85 598 minecraft:oak_leaves[persistent=true]
setblock 346 85 559 minecraft:oak_log
setblock 347 85 558 minecraft:oak_log
fill 347 85 559 347 86 559 minecraft:green_terracotta
fill 348 85 558 348 88 558 minecraft:green_terracotta
setblock 350 85 560 minecraft:oak_log
setblock 351 85 559 minecraft:oak_log
fill 351 85 560 351 87 560 minecraft:green_terracotta
fill 351 85 597 351 86 597 minecraft:green_terracotta
setblock 352 85 558 minecraft:oak_log
fill 352 85 559 352 88 559 minecraft:green_terracotta
setblock 352 85 598 minecraft:oak_log
fill 353 85 558 353 88 558 minecraft:green_terracotta
setblock 353 85 597 minecraft:oak_log
fill 353 85 598 353 88 598 minecraft:green_terracotta
setblock 354 85 561 minecraft:oak_log
setblock 354 85 596 minecraft:oak_log
fill 354 85 597 354 88 597 minecraft:green_terracotta
setblock 355 85 560 minecraft:oak_log
setblock 355 85 561 minecraft:green_terracotta
fill 355 85 596 355 88 596 minecraft:green_terracotta
setblock 356 85 559 minecraft:oak_log
fill 356 85 560 356 86 560 minecraft:green_terracotta
setblock 357 85 558 minecraft:oak_log
fill 357 85 559 357 87 559 minecraft:green_terracotta
setblock 357 85 598 minecraft:oak_log
fill 358 85 558 358 88 558 minecraft:green_terracotta
setblock 358 85 597 minecraft:oak_log
fill 358 85 598 358 88 598 minecraft:green_terracotta
fill 359 85 597 359 87 597 minecraft:green_terracotta
setblock 362 85 558 minecraft:oak_log
setblock 362 85 598 minecraft:oak_log
setblock 363 85 598 minecraft:green_terracotta
fill 368 85 583 368 86 583 minecraft:green_terracotta
setblock 368 85 586 minecraft:green_terracotta
setblock 368 85 587 minecraft:oak_log
fill 368 85 588 368 88 588 minecraft:green_terracotta
setblock 369 85 581 minecraft:oak_log
fill 369 85 582 369 88 582 minecraft:green_terracotta
setblock 369 85 586 minecraft:oak_log
fill 369 85 587 369 88 587 minecraft:green_terracotta
setblock 369 85 591 minecraft:oak_log
setblock 370 85 560 minecraft:oak_log
fill 370 85 561 370 85 564 minecraft:green_terracotta
setblock 370 85 565 minecraft:oak_log
fill 370 85 566 370 88 566 minecraft:green_terracotta
setblock 370 85 570 minecraft:oak_log
fill 370 85 571 370 85 574 minecraft:green_terracotta
setblock 370 85 575 minecraft:oak_log
fill 370 85 576 370 88 576 minecraft:green_terracotta
setblock 370 85 580 minecraft:oak_log
fill 370 85 581 370 88 581 minecraft:green_terracotta
setblock 370 85 585 minecraft:oak_log
fill 370 85 586 370 88 586 minecraft:green_terracotta
setblock 370 85 590 minecraft:oak_log
fill 370 85 591 370 88 591 minecraft:green_terracotta
setblock 370 85 594 minecraft:green_terracotta
setblock 330 86 558 minecraft:green_terracotta
setblock 330 86 559 minecraft:oak_log
fill 330 86 560 330 89 560 minecraft:green_terracotta
setblock 330 86 564 minecraft:oak_log
fill 330 86 565 330 89 565 minecraft:green_terracotta
setblock 330 86 568 minecraft:green_terracotta
setblock 330 86 569 minecraft:oak_log
fill 330 86 570 330 89 570 minecraft:green_terracotta
setblock 330 86 574 minecraft:oak_log
fill 330 86 575 330 89 575 minecraft:green_terracotta
setblock 330 86 579 minecraft:oak_log
fill 330 86 580 330 89 580 minecraft:green_terracotta
setblock 330 86 584 minecraft:oak_log
fill 330 86 585 330 89 585 minecraft:green_terracotta
setblock 330 86 588 minecraft:green_terracotta
setblock 330 86 589 minecraft:oak_log
fill 330 86 590 330 89 590 minecraft:green_terracotta
setblock 330 86 593 minecraft:oak_leaves[persistent=true]
setblock 331 86 558 minecraft:oak_log
setblock 331 86 559 minecraft:green_terracotta
setblock 331 86 562 minecraft:green_terracotta
setblock 331 86 563 minecraft:oak_log
fill 331 86 564 331 89 564 minecraft:green_terracotta
setblock 331 86 567 minecraft:green_terracotta
setblock 331 86 568 minecraft:oak_log
fill 331 86 569 331 89 569 minecraft:green_terracotta
setblock 331 86 573 minecraft:oak_log
fill 331 86 574 331 89 574 minecraft:green_terracotta
setblock 331 86 578 minecraft:oak_log
fill 331 86 579 331 88 579 minecraft:green_terracotta
setblock 331 86 583 minecraft:oak_log
fill 331 86 584 331 89 584 minecraft:green_terracotta
setblock 331 86 588 minecraft:oak_log
fill 331 86 589 331 89 589 minecraft:green_terracotta
fill 331 86 591 331 87 591 minecraft:green_terracotta
fill 332 86 558 335 86 558 minecraft:green_terracotta
setblock 332 86 562 minecraft:oak_log
fill 332 86 563 332 89 563 minecraft:green_terracotta
setblock 332 86 567 minecraft:oak_log
fill 332 86 568 332 89 568 minecraft:green_terracotta
setblock 332 86 571 minecraft:green_terracotta
setblock 332 86 572 minecraft:oak_log
fill 332 86 573 332 89 573 minecraft:green_terracotta
setblock 332 86 582 minecraft:oak_log
fill 332 86 583 332 87 583 minecraft:green_terracotta
setblock 332 86 587 minecraft:oak_log
fill 332 86 588 332 88 588 minecraft:green_terracotta
setblock 333 86 562 minecraft:green_terracotta
setblock 333 86 566 minecraft:oak_log
fill 333 86 567 334 87 567 minecraft:green_terracotta
setblock 333 86 570 minecraft:green_terracotta
fill 333 86 580 333 88 580 minecraft:dark_oak_log
fill 333 86 585 333 88 585 minecraft:dark_oak_log
setblock 334 86 560 minecraft:oak_log
setblock 334 86 561 minecraft:green_terracotta
setblock 334 86 565 minecraft:oak_log
fill 334 86 566 334 87 566 minecraft:green_terracotta
setblock 335 86 559 minecraft:oak_log
fill 335 86 560 335 88 560 minecraft:green_terracotta
setblock 336 86 558 minecraft:oak_log
fill 336 86 559 336 89 559 minecraft:green_terracotta
setblock 336 86 598 minecraft:oak_log
fill 337 86 558 340 86 558 minecraft:green_terracotta
fill 337 86 580 337 88 580 minecraft:dark_oak_log
fill 337 86 585 337 88 585 minecraft:dark_oak_log
setblock 337 86 598 minecraft:green_terracotta
setblock 338 86 561 minecraft:oak_log
fill 338 86 582 338 88 583 minecraft:dark_oak_log
fill 338 86 586 338 88 586 minecraft:dark_oak_log
fill 338 86 590 338 88 590 minecraft:dark_oak_log
setblock 339 86 560 minecraft:oak_log
fill 339 86 591 339 88 591 minecraft:dark_oak_log
setblock 340 86 559 minecraft:oak_log
setblock 340 86 560 minecraft:green_terracotta
fill 340 86 584 342 88 584 minecraft:dark_oak_log
setblock 341 86 558 minecraft:oak_log
fill 341 86 559 341 87 559 minecraft:green_terracotta
fill 342 86 558 342 88 558 minecraft:green_terracotta
fill 343 86 591 343 88 591 minecraft:dark_oak_log
fill 344 86 585 344 88 585 minecraft:dark_oak_log
fill 345 86 587 345 88 589 minecraft:dark_oak_log
setblock 346 86 558 minecraft:oak_log
setblock 346 86 559 minecraft:green_terracotta
fill 347 86 558 347 89 558 minecraft:green_terracotta
fill 348 86 598 348 88 598 minecraft:green_terracotta
setblock 350 86 559 minecraft:oak_log
setblock 350 86 560 minecraft:green_terracotta
setblock 351 86 558 minecraft:oak_log
fill 351 86 559 351 89 559 minecraft:green_terracotta
setblock 351 86 598 minecraft:oak_log
fill 352 86 558 352 89 558 minecraft:green_terracotta
setblock 352 86 597 minecraft:oak_log
fill 352 86 598 352 89 598 minecraft:green_terracotta
fill 353 86 597 353 89 597 minecraft:green_terracotta
setblock 354 86 560 minecraft:oak_log
fill 354 86 596 354 89 596 minecraft:green_terracotta
setblock 355 86 559 minecraft:oak_log
fill 355 86 560 355 87 560 minecraft:green_terracotta
setblock 356 86 558 minecraft:oak_log
fill 356 86 559 356 88 559 minecraft:green_terracotta
setblock 356 86 598 minecraft:oak_log
fill 357 86 558 357 89 558 minecraft:green_terracotta
setblock 357 86 596 minecraft:green_terracotta
setblock 357 86 597 minecraft:oak_log
fill 357 86 598 357 89 598 minecraft:green_terracotta
fill 358 86 597 358 88 597 minecraft:green_terracotta
setblock 361 86 558 minecraft:oak_log
setblock 361 86 598 minecraft:oak_log
setblock 362 86 598 minecraft:green_terracotta
setblock 368 86 586 minecraft:oak_log
fill 368 86 587 368 89 587 minecraft:green_terracotta
fill 368 86 589 368 87 589 minecraft:green_terracotta
setblock 369 86 558 minecraft:oak_leaves[persistent=true]
setblock 369 86 580 minecraft:oak_log
fill 369 86 581 369 89 581 minecraft:green_terracotta
setblock 369 86 585 minecraft:oak_log
fill 369 86 586 369 89 586 minecraft:green_terracotta
setblock 369 86 590 minecraft:oak_log
fill 369 86 591 369 88 592 minecraft:green_terracotta
setblock 369 86 598 minecraft:oak_leaves[persistent=true]
fill 370 86 560 370 86 563 minecraft:green_terracotta
setblock 370 86 564 minecraft:oak_log
fill 370 86 565 370 89 565 minecraft:green_terracotta
fill 370 86 567 370 86 568 minecraft:green_terracotta
setblock 370 86 569 minecraft:oak_log
fill 370 86 570 370 86 573 minecraft:green_terracotta
setblock 370 86 574 minecraft:oak_log
fill 370 86 575 370 89 575 minecraft:green_terracotta
setblock 370 86 579 minecraft:oak_log
fill 370 86 580 370 89 580 minecraft:green_terracotta
setblock 370 86 584 minecraft:oak_log
fill 370 86 585 370 89 585 minecraft:green_terracotta
setblock 370 86 589 minecraft:oak_log
fill 370 86 590 370 89 590 minecraft:green_terracotta
setblock 370 86 594 minecraft:oak_log
fill 370 86 595 370 89 595 minecraft:green_terracotta
setblock 330 87 558 minecraft:oak_log
fill 330 87 559 330 90 559 minecraft:green_terracotta
setblock 330 87 563 minecraft:oak_log
fill 330 87 564 330 90 564 minecraft:green_terracotta
setblock 330 87 568 minecraft:oak_log
fill 330 87 569 330 90 569 minecraft:green_terracotta
setblock 330 87 572 minecraft:green_terracotta
setblock 330 87 573 minecraft:oak_log
fill 330 87 574 330 90 574 minecraft:green_terracotta
setblock 330 87 578 minecraft:oak_log
fill 330 87 579 330 90 579 minecraft:green_terracotta
setblock 330 87 583 minecraft:oak_log
fill 330 87 584 330 90 584 minecraft:green_terracotta
setblock 330 87 588 minecraft:oak_log
fill 330 87 589 330 90 589 minecraft:green_terracotta
setblock 330 87 593 minecraft:oak_log
fill 331 87 558 334 87 558 minecraft:green_terracotta
setblock 331 87 561 minecraft:green_terracotta
setblock 331 87 562 minecraft:oak_log
fill 331 87 563 331 90 563 minecraft:green_terracotta
setblock 331 87 567 minecraft:oak_log
fill 331 87 568 331 90 568 minecraft:green_terracotta
setblock 331 87 572 minecraft:oak_log
fill 331 87 573 331 90 573 minecraft:green_terracotta
setblock 331 87 577 minecraft:oak_log
fill 331 87 578 331 88 578 minecraft:green_terracotta
setblock 331 87 582 minecraft:oak_log
fill 331 87 583 331 89 583 minecraft:green_terracotta
setblock 331 87 587 minecraft:oak_log
fill 331 87 588 331 90 588 minecraft:green_terracotta
setblock 331 87 598 minecraft:oak_leaves[persistent=true]
setblock 332 87 561 minecraft:oak_log
fill 332 87 562 332 89 562 minecraft:green_terracotta
setblock 332 87 565 minecraft:green_terracotta
setblock 332 87 566 minecraft:oak_log
fill 332 87 567 332 90 567 minecraft:green_terracotta
setblock 332 87 571 minecraft:oak_log
fill 332 87 572 332 90 572 minecraft:green_terracotta
fill 332 87 581 332 88 581 minecraft:dark_oak_log
setblock 332 87 582 minecraft:green_terracotta
setblock 332 87 586 minecraft:oak_log
fill 332 87 587 332 88 587 minecraft:green_terracotta
setblock 332 87 589 minecraft:green_terracotta
setblock 333 87 560 minecraft:oak_log
setblock 333 87 565 minecraft:oak_log
fill 333 87 566 333 90 566 minecraft:green_terracotta
setblock 333 87 570 minecraft:oak_log
fill 333 87 571 333 90 571 minecraft:green_terracotta
setblock 334 87 559 minecraft:oak_log
fill 334 87 560 334 88 560 minecraft:green_terracotta
setblock 334 87 565 minecraft:green_terracotta
fill 334 87 579 336 88 579 minecraft:dark_oak_log
fill 334 87 586 337 88 586 minecraft:dark_oak_log
setblock 335 87 558 minecraft:oak_log
fill 335 87 559 335 89 559 minecraft:green_terracotta
setblock 335 87 598 minecraft:oak_log
fill 336 87 558 339 87 558 minecraft:green_terracotta
setblock 336 87 598 minecraft:green_terracotta
fill 337 87 587 337 88 589 minecraft:dark_oak_log
fill 337 87 598 337 88 598 minecraft:oak_leaves[persistent=true]
setblock 338 87 560 minecraft:oak_log
fill 338 87 581 338 88 581 minecraft:dark_oak_log
fill 338 87 584 338 88 585 minecraft:dark_oak_log
fill 338 87 591 338 88 591 minecraft:dark_oak_log
setblock 339 87 559 minecraft:oak_log
fill 339 87 584 339 88 584 minecraft:dark_oak_log
setblock 340 87 558 minecraft:oak_log
setblock 340 87 559 minecraft:green_terracotta
fill 340 87 592 343 88 592 minecraft:dark_oak_log
fill 341 87 558 341 88 558 minecraft:green_terracotta
fill 343 87 584 343 88 584 minecraft:dark_oak_log
fill 344 87 591 344 88 591 minecraft:dark_oak_log
setblock 345 87 558 minecraft:oak_log
fill 345 87 586 345 88 586 minecraft:dark_oak_log
fill 345 87 590 345 88 590 minecraft:dark_oak_log
fill 346 87 558 346 88 558 minecraft:green_terracotta
setblock 349 87 559 minecraft:oak_log
setblock 350 87 558 minecraft:oak_log
fill 350 87 559 350 88 559 minecraft:green_terracotta
setblock 350 87 598 minecraft:oak_log
fill 351 87 558 351 90 558 minecraft:green_terracotta
setblock 351 87 597 minecraft:oak_log
fill 351 87 598 351 90 598 minecraft:green_terracotta
fill 352 87 597 352 90 597 minecraft:green_terracotta
setblock 353 87 560 minecraft:oak_log
fill 353 87 596 353 90 596 minecraft:green_terracotta
setblock 354 87 559 minecraft:oak_log
setblock 354 87 560 minecraft:green_terracotta
setblock 355 87 558 minecraft:oak_log
fill 355 87 559 355 88 559 minecraft:green_terracotta
setblock 355 87 598 minecraft:oak_log
fill 356 87 558 356 89 558 minecraft:green_terracotta
setblock 356 87 597 minecraft:oak_log
fill 356 87 598 356 90 598 minecraft:green_terracotta
fill 357 87 597 357 89 597 minecraft:green_terracotta
setblock 360 87 598 minecraft:oak_log
setblock 361 87 598 minecraft:green_terracotta
setblock 363 87 558 minecraft:oak_leaves[persistent=true]
setblock 368 87 585 minecraft:oak_log
fill 368 87 586 368 89 586 minecraft:green_terracotta
fill 369 87 565 369 87 568 minecraft:green_terracotta
setblock 369 87 569 minecraft:oak_log
setblock 369 87 580 minecraft:green_terracotta
setblock 369 87 584 minecraft:oak_log
fill 369 87 585 369 90 585 minecraft:green_terracotta
setblock 369 87 589 minecraft:oak_log
fill 369 87 590 369 90 590 minecraft:green_terracotta
fill 370 87 561 370 87 562 minecraft:green_terracotta
setblock 370 87 563 minecraft:oak_log
fill 370 87 564 370 90 564 minecraft:green_terracotta
setblock 370 87 567 minecraft:green_terracotta
setblock 370 87 568 minecraft:oak_log
fill 370 87 569 370 87 572 minecraft:green_terracotta
setblock 370 87 573 minecraft:oak_log
fill 370 87 574 370 90 574 minecraft:green_terracotta
setblock 370 87 578 minecraft:oak_log
fill 370 87 579 370 90 579 minecraft:green_terracotta
setblock 370 87 583 minecraft:oak_log
fill 370 87 584 370 90 584 minecraft:green_terracotta
setblock 370 87 588 minecraft:oak_log
fill 370 87 589 370 90 589 minecraft:green_terracotta
setblock 370 87 592 minecraft:green_terracotta
setblock 370 87 593 minecraft:oak_log
fill 370 87 594 370 90 594 minecraft:green_terracotta
setblock 330 88 562 minecraft:oak_log
fill 330 88 563 330 91 563 minecraft:green_terracotta
setblock 330 88 567 minecraft:oak_log
fill 330 88 568 330 91 568 minecraft:green_terracotta
setblock 330 88 572 minecraft:oak_log
fill 330 88 573 330 91 573 minecraft:green_terracotta
setblock 330 88 577 minecraft:oak_log
fill 330 88 578 330 91 578 minecraft:green_terracotta
setblock 330 88 582 minecraft:oak_log
fill 330 88 583 330 91 583 minecraft:green_terracotta
setblock 330 88 587 minecraft:oak_log
fill 330 88 588 330 91 588 minecraft:green_terracotta
setblock 330 88 591 minecraft:green_terracotta
setblock 330 88 592 minecraft:oak_log
fill 330 88 593 330 91 593 minecraft:green_terracotta
fill 331 88 558 333 88 558 minecraft:green_terracotta
setblock 331 88 561 minecraft:oak_log
fill 331 88 562 331 91 562 minecraft:green_terracotta
setblock 331 88 566 minecraft:oak_log
fill 331 88 567 331 91 567 minecraft:green_terracotta
setblock 331 88 571 minecraft:oak_log
fill 331 88 572 331 91 572 minecraft:green_terracotta
setblock 331 88 576 minecraft:oak_log
fill 331 88 577 331 90 577 minecraft:green_terracotta
setblock 331 88 581 minecraft:oak_log
fill 331 88 582 331 89 582 minecraft:green_terracotta
setblock 331 88 586 minecraft:oak_log
fill 331 88 587 331 91 587 minecraft:green_terracotta
setblock 331 88 591 minecraft:oak_log
setblock 332 88 560 minecraft:light[level=14]
setblock 332 88 561 minecraft:green_terracotta
setblock 332 88 565 minecraft:oak_log
fill 332 88 566 332 91 566 minecraft:green_terracotta
setblock 332 88 569 minecraft:green_terracotta
setblock 332 88 570 minecraft:oak_log
fill 332 88 571 332 91 571 minecraft:green_terracotta
setblock 332 88 574 minecraft:green_terracotta
setblock 332 88 576 minecraft:light[level=14]
setblock 332 88 580 minecraft:dark_oak_log
fill 332 88 582 332 88 583 minecraft:dark_oak_log
setblock 332 88 585 minecraft:oak_log
setblock 332 88 586 minecraft:green_terracotta
setblock 332 88 592 minecraft:light[level=14]
setblock 333 88 559 minecraft:oak_log
setblock 333 88 564 minecraft:oak_log
fill 333 88 565 333 90 565 minecraft:green_terracotta
fill 333 88 567 333 89 567 minecraft:green_terracotta
setblock 333 88 569 minecraft:oak_log
fill 333 88 570 333 91 570 minecraft:green_terracotta
setblock 333 88 579 minecraft:dark_oak_log
setblock 333 88 586 minecraft:dark_oak_log
setblock 334 88 558 minecraft:oak_log
fill 334 88 559 334 89 559 minecraft:green_terracotta
fill 335 88 558 338 88 558 minecraft:green_terracotta
setblock 337 88 579 minecraft:dark_oak_log
setblock 337 88 590 minecraft:dark_oak_log
setblock 338 88 559 minecraft:oak_log
setblock 338 88 580 minecraft:dark_oak_log
setblock 339 88 558 minecraft:oak_log
setblock 339 88 559 minecraft:green_terracotta
fill 339 88 582 339 88 583 minecraft:dark_oak_log
setblock 339 88 592 minecraft:dark_oak_log
setblock 340 88 558 minecraft:green_terracotta
setblock 340 88 560 minecraft:light[level=14]
setblock 340 88 568 minecraft:light[level=14]
setblock 340 88 576 minecraft:light[level=14]
fill 340 88 583 342 88 583 minecraft:dark_oak_log
setblock 343 88 598 minecraft:oak_leaves[persistent=true]
setblock 344 88 584 minecraft:dark_oak_log
setblock 344 88 592 minecraft:dark_oak_log
setblock 345 88 585 minecraft:dark_oak_log
setblock 345 88 591 minecraft:dark_oak_log
fill 346 88 587 346 88 589 minecraft:dark_oak_log
setblock 348 88 560 minecraft:light[level=14]
setblock 348 88 568 minecraft:light[level=14]
setblock 348 88 576 minecraft:light[level=14]
setblock 348 88 584 minecraft:light[level=14]
setblock 348 88 592 minecraft:light[level=14]
setblock 349 88 558 minecraft:oak_log
setblock 349 88 559 minecraft:green_terracotta
setblock 349 88 598 minecraft:oak_log
fill 350 88 558 350 91 558 minecraft:green_terracotta
setblock 350 88 597 minecraft:oak_log
fill 350 88 598 350 91 598 minecraft:green_terracotta
fill 351 88 597 351 91 597 minecraft:green_terracotta
setblock 353 88 559 minecraft:oak_log
setblock 354 88 558 minecraft:oak_log
fill 354 88 559 354 89 559 minecraft:green_terracotta
setblock 354 88 598 minecraft:oak_log
fill 355 88 558 355 90 558 minecraft:green_terracotta
setblock 355 88 597 minecraft:oak_log
fill 355 88 598 355 91 598 minecraft:green_terracotta
setblock 356 88 560 minecraft:light[level=14]
setblock 356 88 568 minecraft:light[level=14]
setblock 356 88 576 minecraft:light[level=14]
setblock 356 88 584 minecraft:light[level=14]
setblock 356 88 592 minecraft:light[level=14]
setblock 356 88 596 minecraft:oak_log
fill 356 88 597 356 91 597 minecraft:green_terracotta
setblock 359 88 598 minecraft:oak_log
setblock 360 88 598 minecraft:green_terracotta
setblock 362 88 598 minecraft:oak_leaves[persistent=true]
setblock 364 88 560 minecraft:light[level=14]
setblock 364 88 568 minecraft:light[level=14]
setblock 364 88 576 minecraft:light[level=14]
setblock 364 88 584 minecraft:light[level=14]
setblock 364 88 592 minecraft:light[level=14]
setblock 368 88 585 minecraft:green_terracotta
setblock 368 88 589 minecraft:oak_log
fill 369 88 566 369 88 567 minecraft:green_terracotta
setblock 369 88 568 minecraft:oak_log
fill 369 88 569 370 89 570 minecraft:green_terracotta
setblock 369 88 583 minecraft:oak_log
fill 369 88 584 369 91 584 minecraft:green_terracotta
setblock 369 88 588 minecraft:oak_log
fill 369 88 589 369 91 589 minecraft:green_terracotta
setblock 370 88 561 minecraft:green_terracotta
setblock 370 88 562 minecraft:oak_log
fill 370 88 563 370 91 563 minecraft:green_terracotta
setblock 370 88 567 minecraft:oak_log
fill 370 88 568 370 91 568 minecraft:green_terracotta
setblock 370 88 571 minecraft:green_terracotta
setblock 370 88 572 minecraft:oak_log
fill 370 88 573 370 91 573 minecraft:green_terracotta
setblock 370 88 577 minecraft:oak_log
fill 370 88 578 370 91 578 minecraft:green_terracotta
setblock 370 88 582 minecraft:oak_log
fill 370 88 583 370 91 583 minecraft:green_terracotta
setblock 370 88 587 minecraft:oak_log
fill 370 88 588 370 91 588 minecraft:green_terracotta
setblock 370 88 592 minecraft:oak_log
fill 370 88 593 370 91 593 minecraft:green_terracotta
setblock 330 89 561 minecraft:oak_log
fill 330 89 562 330 92 562 minecraft:green_terracotta
setblock 330 89 566 minecraft:oak_log
fill 330 89 567 330 92 567 minecraft:green_terracotta
setblock 330 89 571 minecraft:oak_log
fill 330 89 572 330 92 572 minecraft:green_terracotta
setblock 330 89 576 minecraft:oak_log
fill 330 89 577 330 92 577 minecraft:green_terracotta
setblock 330 89 581 minecraft:oak_log
fill 330 89 582 330 92 582 minecraft:green_terracotta
setblock 330 89 586 minecraft:oak_log
fill 330 89 587 330 92 587 minecraft:green_terracotta
setblock 330 89 591 minecraft:oak_log
fill 330 89 592 331 91 592 minecraft:green_terracotta
fill 330 89 594 330 90 594 minecraft:green_terracotta
fill 331 89 558 332 89 558 minecraft:green_terracotta
fill 331 89 561 331 90 561 minecraft:green_terracotta
setblock 331 89 565 minecraft:oak_log
fill 331 89 566 331 92 566 minecraft:green_terracotta
setblock 331 89 570 minecraft:oak_log
fill 331 89 571 331 92 571 minecraft:green_terracotta
setblock 331 89 575 minecraft:oak_log
fill 331 89 576 331 92 576 minecraft:green_terracotta
setblock 331 89 581 minecraft:green_terracotta
setblock 331 89 585 minecraft:oak_log
fill 331 89 586 331 91 586 minecraft:green_terracotta
setblock 331 89 590 minecraft:oak_log
fill 331 89 591 331 92 591 minecraft:green_terracotta
setblock 332 89 564 minecraft:oak_log
fill 332 89 565 332 92 565 minecraft:green_terracotta
setblock 332 89 569 minecraft:oak_log
fill 332 89 570 332 92 570 minecraft:green_terracotta
setblock 332 89 574 minecraft:oak_log
setblock 333 89 558 minecraft:oak_log
setblock 333 89 559 minecraft:green_terracotta
setblock 333 89 564 minecraft:green_terracotta
setblock 333 89 568 minecraft:oak_log
fill 333 89 569 333 92 569 minecraft:green_terracotta
fill 334 89 558 337 89 558 minecraft:green_terracotta
fill 335 89 582 335 91 583 minecraft:oak_log
setblock 338 89 558 minecraft:oak_log
setblock 339 89 558 minecraft:green_terracotta
fill 341 89 588 341 92 588 minecraft:oak_log
fill 345 89 591 345 95 591 minecraft:iron_block
setblock 348 89 558 minecraft:oak_log
setblock 348 89 598 minecraft:oak_log
fill 349 89 558 349 92 558 minecraft:green_terracotta
fill 349 89 598 349 92 598 minecraft:green_terracotta
fill 350 89 597 350 92 597 minecraft:green_terracotta
setblock 352 89 559 minecraft:oak_log
setblock 353 89 558 minecraft:oak_log
setblock 353 89 559 minecraft:green_terracotta
setblock 353 89 598 minecraft:oak_log
fill 354 89 558 354 91 558 minecraft:green_terracotta
setblock 354 89 597 minecraft:oak_log
fill 354 89 598 354 92 598 minecraft:green_terracotta
setblock 355 89 596 minecraft:oak_log
fill 355 89 597 355 92 597 minecraft:green_terracotta
setblock 358 89 598 minecraft:oak_log
setblock 359 89 598 minecraft:green_terracotta
setblock 368 89 588 minecraft:oak_log
setblock 368 89 589 minecraft:green_terracotta
setblock 368 89 598 minecraft:oak_leaves[persistent=true]
setblock 369 89 566 minecraft:green_terracotta
setblock 369 89 567 minecraft:oak_log
fill 369 89 568 369 92 568 minecraft:green_terracotta
setblock 369 89 571 minecraft:green_terracotta
setblock 369 89 572 minecraft:oak_log
setblock 369 89 582 minecraft:oak_log
fill 369 89 583 369 91 583 minecraft:green_terracotta
setblock 369 89 587 minecraft:oak_log
fill 369 89 588 369 92 588 minecraft:green_terracotta
setblock 369 89 591 minecraft:green_terracotta
setblock 369 89 592 minecraft:oak_log
fill 369 89 593 369 92 593 minecraft:green_terracotta
fill 370 89 562 370 90 562 minecraft:green_terracotta
setblock 370 89 566 minecraft:oak_log
fill 370 89 567 370 92 567 minecraft:green_terracotta
setblock 370 89 571 minecraft:oak_log
fill 370 89 572 370 92 572 minecraft:green_terracotta
setblock 370 89 576 minecraft:oak_log
fill 370 89 577 370 92 577 minecraft:green_terracotta
setblock 370 89 581 minecraft:oak_log
fill 370 89 582 370 92 582 minecraft:green_terracotta
setblock 370 89 586 minecraft:oak_log
fill 370 89 587 370 92 587 minecraft:green_terracotta
setblock 370 89 591 minecraft:oak_log
fill 370 89 592 370 92 592 minecraft:green_terracotta
setblock 330 90 560 minecraft:oak_log
fill 330 90 561 330 93 561 minecraft:green_terracotta
setblock 330 90 565 minecraft:oak_log
fill 330 90 566 330 93 566 minecraft:green_terracotta
setblock 330 90 570 minecraft:oak_log
fill 330 90 571 330 93 571 minecraft:green_terracotta
setblock 330 90 575 minecraft:oak_log
fill 330 90 576 330 93 576 minecraft:green_terracotta
setblock 330 90 580 minecraft:oak_log
fill 330 90 581 330 93 581 minecraft:green_terracotta
setblock 330 90 585 minecraft:oak_log
fill 330 90 586 330 93 586 minecraft:green_terracotta
setblock 330 90 590 minecraft:oak_log
fill 330 90 591 330 93 591 minecraft:green_terracotta
setblock 330 90 598 minecraft:oak_leaves[persistent=true]
setblock 331 90 558 minecraft:green_terracotta
setblock 331 90 564 minecraft:oak_log
fill 331 90 565 331 93 565 minecraft:green_terracotta
setblock 331 90 569 minecraft:oak_log
fill 331 90 570 331 93 570 minecraft:green_terracotta
setblock 331 90 574 minecraft:oak_log
fill 331 90 575 331 93 575 minecraft:green_terracotta
setblock 331 90 584 minecraft:oak_log
setblock 331 90 585 minecraft:green_terracotta
setblock 331 90 589 minecraft:oak_log
fill 331 90 590 331 93 590 minecraft:green_terracotta
setblock 332 90 558 minecraft:oak_log
setblock 332 90 563 minecraft:oak_log
fill 332 90 564 332 92 564 minecraft:green_terracotta
setblock 332 90 568 minecraft:oak_log
fill 332 90 569 332 93 569 minecraft:green_terracotta
setblock 332 90 573 minecraft:oak_log
fill 332 90 574 332 93 574 minecraft:green_terracotta
fill 333 90 558 336 90 558 minecraft:green_terracotta
setblock 333 90 567 minecraft:oak_log
fill 333 90 568 333 92 568 minecraft:green_terracotta
setblock 337 90 558 minecraft:oak_log
setblock 338 90 558 minecraft:green_terracotta
setblock 345 90 558 minecraft:oak_leaves[persistent=true]
setblock 347 90 598 minecraft:oak_log
fill 348 90 558 348 93 558 minecraft:green_terracotta
fill 348 90 598 348 93 598 minecraft:green_terracotta
setblock 352 90 558 minecraft:oak_log
fill 352 90 596 352 91 596 minecraft:green_terracotta
setblock 352 90 598 minecraft:oak_log
fill 353 90 558 353 93 558 minecraft:green_terracotta
setblock 353 90 597 minecraft:oak_log
fill 353 90 598 353 93 598 minecraft:green_terracotta
setblock 354 90 596 minecraft:oak_log
fill 354 90 597 354 93 597 minecraft:green_terracotta
setblock 357 90 598 minecraft:oak_log
setblock 358 90 598 minecraft:green_terracotta
setblock 368 90 588 minecraft:green_terracotta
setblock 369 90 566 minecraft:oak_log
fill 369 90 567 369 93 567 minecraft:green_terracotta
fill 369 90 569 369 90 570 minecraft:green_terracotta
setblock 369 90 571 minecraft:oak_log
fill 369 90 572 369 92 573 minecraft:green_terracotta
setblock 369 90 582 minecraft:green_terracotta
setblock 369 90 586 minecraft:oak_log
fill 369 90 587 369 93 587 minecraft:green_terracotta
setblock 369 90 591 minecraft:oak_log
fill 369 90 592 369 93 592 minecraft:green_terracotta
setblock 370 90 558 minecraft:oak_leaves[persistent=true]
setblock 370 90 565 minecraft:oak_log
fill 370 90 566 370 93 566 minecraft:green_terracotta
setblock 370 90 569 minecraft:green_terracotta
setblock 370 90 570 minecraft:oak_log
fill 370 90 571 370 93 571 minecraft:green_terracotta
setblock 370 90 575 minecraft:oak_log
fill 370 90 576 370 93 576 minecraft:green_terracotta
setblock 370 90 580 minecraft:oak_log
fill 370 90 581 370 93 581 minecraft:green_terracotta
setblock 370 90 585 minecraft:oak_log
fill 370 90 586 370 93 586 minecraft:green_terracotta
setblock 370 90 590 minecraft:oak_log
fill 370 90 591 370 93 591 minecraft:green_terracotta
setblock 370 90 595 minecraft:oak_log
setblock 330 91 559 minecraft:oak_log
fill 330 91 560 330 94 560 minecraft:green_terracotta
setblock 330 91 564 minecraft:oak_log
fill 330 91 565 330 94 565 minecraft:green_terracotta
setblock 330 91 569 minecraft:oak_log
fill 330 91 570 330 94 570 minecraft:green_terracotta
setblock 330 91 574 minecraft:oak_log
fill 330 91 575 330 94 575 minecraft:green_terracotta
setblock 330 91 579 minecraft:oak_log
fill 330 91 580 330 94 580 minecraft:green_terracotta
setblock 330 91 584 minecraft:oak_log
fill 330 91 585 330 94 585 minecraft:green_terracotta
setblock 330 91 589 minecraft:oak_log
fill 330 91 590 330 94 590 minecraft:green_terracotta
setblock 330 91 594 minecraft:oak_log
fill 330 91 595 330 94 595 minecraft:green_terracotta
setblock 331 91 558 minecraft:oak_log
setblock 331 91 563 minecraft:oak_log
fill 331 91 564 331 94 564 minecraft:green_terracotta
setblock 331 91 568 minecraft:oak_log
fill 331 91 569 331 94 569 minecraft:green_terracotta
setblock 331 91 573 minecraft:oak_log
fill 331 91 574 331 94 574 minecraft:green_terracotta
setblock 331 91 588 minecraft:oak_log
fill 331 91 589 331 93 589 minecraft:green_terracotta
fill 332 91 558 335 91 558 minecraft:green_terracotta
setblock 332 91 563 minecraft:green_terracotta
setblock 332 91 567 minecraft:oak_log
fill 332 91 568 332 94 568 minecraft:green_terracotta
setblock 332 91 572 minecraft:oak_log
fill 332 91 573 332 94 573 minecraft:green_terracotta
setblock 333 91 566 minecraft:oak_log
fill 333 91 567 333 92 567 minecraft:green_terracotta
setblock 333 91 571 minecraft:oak_log
setblock 336 91 558 minecraft:oak_log
setblock 336 91 598 minecraft:oak_leaves[persistent=true]
setblock 339 91 558 minecraft:oak_leaves[persistent=true]
fill 347 91 598 347 94 598 minecraft:green_terracotta
fill 349 91 597 349 93 597 minecraft:green_terracotta
setblock 351 91 558 minecraft:oak_log
fill 351 91 596 351 92 596 minecraft:green_terracotta
setblock 351 91 598 minecraft:oak_log
fill 352 91 558 352 94 558 minecraft:green_terracotta
setblock 352 91 597 minecraft:oak_log
fill 352 91 598 352 94 598 minecraft:green_terracotta
setblock 353 91 596 minecraft:oak_log
fill 353 91 597 353 94 597 minecraft:green_terracotta
fill 354 91 596 354 94 596 minecraft:green_terracotta
setblock 356 91 598 minecraft:oak_log
fill 357 91 598 357 94 598 minecraft:green_terracotta
fill 360 91 563 360 99 563 minecraft:iron_block
setblock 361 91 598 minecraft:oak_leaves[persistent=true]
setblock 364 91 558 minecraft:oak_leaves[persistent=true]
fill 369 91 566 369 94 566 minecraft:green_terracotta
setblock 369 91 569 minecraft:green_terracotta
setblock 369 91 570 minecraft:oak_log
fill 369 91 571 369 94 571 minecraft:green_terracotta
setblock 369 91 574 minecraft:green_terracotta
setblock 369 91 575 minecraft:oak_log
setblock 369 91 585 minecraft:oak_log
fill 369 91 586 369 94 586 minecraft:green_terracotta
setblock 369 91 590 minecraft:oak_log
fill 369 91 591 369 94 591 minecraft:green_terracotta
setblock 370 91 564 minecraft:oak_log
fill 370 91 565 370 94 565 minecraft:green_terracotta
setblock 370 91 569 minecraft:oak_log
fill 370 91 570 370 94 570 minecraft:green_terracotta
setblock 370 91 574 minecraft:oak_log
fill 370 91 575 370 94 575 minecraft:green_terracotta
setblock 370 91 579 minecraft:oak_log
fill 370 91 580 370 94 580 minecraft:green_terracotta
setblock 370 91 584 minecraft:oak_log
fill 370 91 585 370 94 585 minecraft:green_terracotta
setblock 370 91 589 minecraft:oak_log
fill 370 91 590 370 94 590 minecraft:green_terracotta
setblock 370 91 594 minecraft:oak_log
fill 370 91 595 370 93 596 minecraft:green_terracotta
fill 330 92 559 330 95 559 minecraft:green_terracotta
setblock 330 92 563 minecraft:oak_log
fill 330 92 564 330 95 564 minecraft:green_terracotta
setblock 330 92 568 minecraft:oak_log
fill 330 92 569 330 95 569 minecraft:green_terracotta
setblock 330 92 573 minecraft:oak_log
fill 330 92 574 330 95 574 minecraft:green_terracotta
setblock 330 92 578 minecraft:oak_log
fill 330 92 579 330 95 579 minecraft:green_terracotta
setblock 330 92 583 minecraft:oak_log
fill 330 92 584 330 95 584 minecraft:green_terracotta
setblock 330 92 588 minecraft:oak_log
fill 330 92 589 330 95 589 minecraft:green_terracotta
setblock 330 92 592 minecraft:green_terracotta
setblock 330 92 593 minecraft:oak_log
fill 330 92 594 330 95 594 minecraft:green_terracotta
fill 330 92 596 330 93 596 minecraft:green_terracotta
fill 331 92 558 334 92 558 minecraft:green_terracotta
setblock 331 92 562 minecraft:oak_log
fill 331 92 563 331 95 563 minecraft:green_terracotta
setblock 331 92 567 minecraft:oak_log
fill 331 92 568 331 95 568 minecraft:green_terracotta
setblock 331 92 572 minecraft:oak_log
fill 331 92 573 331 95 573 minecraft:green_terracotta
setblock 331 92 577 minecraft:oak_log
setblock 331 92 588 minecraft:green_terracotta
setblock 331 92 592 minecraft:oak_log
setblock 332 92 566 minecraft:oak_log
fill 332 92 567 332 95 567 minecraft:green_terracotta
setblock 332 92 571 minecraft:oak_log
fill 332 92 572 332 95 572 minecraft:green_terracotta
setblock 333 92 570 minecraft:oak_log
fill 333 92 582 336 94 583 minecraft:oak_leaves[persistent=true]
fill 334 92 581 336 94 581 minecraft:oak_leaves[persistent=true]
fill 334 92 584 336 94 584 minecraft:oak_leaves[persistent=true]
setblock 335 92 558 minecraft:oak_log
fill 340 92 587 340 94 589 minecraft:oak_leaves[persistent=true]
fill 341 92 586 341 94 587 minecraft:oak_leaves[persistent=true]
fill 341 92 589 342 94 589 minecraft:oak_leaves[persistent=true]
fill 342 92 587 342 94 588 minecraft:oak_leaves[persistent=true]
setblock 342 92 598 minecraft:oak_leaves[persistent=true]
fill 343 92 588 343 94 588 minecraft:oak_leaves[persistent=true]
fill 346 92 598 346 95 598 minecraft:green_terracotta
fill 348 92 597 348 94 597 minecraft:green_terracotta
setblock 350 92 558 minecraft:oak_log
fill 350 92 596 350 93 596 minecraft:green_terracotta
setblock 350 92 598 minecraft:oak_log
fill 351 92 558 351 95 558 minecraft:green_terracotta
setblock 351 92 597 minecraft:oak_log
fill 351 92 598 351 95 598 minecraft:green_terracotta
setblock 352 92 596 minecraft:oak_log
fill 352 92 597 352 95 597 minecraft:green_terracotta
fill 353 92 596 353 95 596 minecraft:green_terracotta
setblock 355 92 598 minecraft:oak_log
setblock 356 92 597 minecraft:oak_log
fill 356 92 598 356 95 598 minecraft:green_terracotta
setblock 358 92 558 minecraft:oak_leaves[persistent=true]
setblock 367 92 598 minecraft:oak_leaves[persistent=true]
setblock 369 92 569 minecraft:oak_log
fill 369 92 570 369 95 570 minecraft:green_terracotta
setblock 369 92 574 minecraft:oak_log
fill 369 92 575 369 93 577 minecraft:green_terracotta
setblock 369 92 584 minecraft:oak_log
fill 369 92 585 369 95 585 minecraft:green_terracotta
setblock 369 92 589 minecraft:oak_log
fill 369 92 590 369 95 590 minecraft:green_terracotta
setblock 369 92 594 minecraft:oak_log
setblock 370 92 563 minecraft:oak_log
fill 370 92 564 370 95 564 minecraft:green_terracotta
setblock 370 92 568 minecraft:oak_log
fill 370 92 569 370 95 569 minecraft:green_terracotta
setblock 370 92 573 minecraft:oak_log
fill 370 92 574 370 95 574 minecraft:green_terracotta
setblock 370 92 578 minecraft:oak_log
fill 370 92 579 370 95 579 minecraft:green_terracotta
setblock 370 92 583 minecraft:oak_log
fill 370 92 584 370 95 584 minecraft:green_terracotta
setblock 370 92 588 minecraft:oak_log
fill 370 92 589 370 95 589 minecraft:green_terracotta
setblock 370 92 593 minecraft:oak_log
fill 370 92 594 370 95 594 minecraft:green_terracotta
fill 330 93 558 333 93 558 minecraft:green_terracotta
setblock 330 93 562 minecraft:oak_log
fill 330 93 563 330 96 563 minecraft:green_terracotta
setblock 330 93 567 minecraft:oak_log
fill 330 93 568 330 96 568 minecraft:green_terracotta
setblock 330 93 572 minecraft:oak_log
fill 330 93 573 330 96 573 minecraft:green_terracotta
setblock 330 93 577 minecraft:oak_log
fill 330 93 578 330 96 578 minecraft:green_terracotta
setblock 330 93 582 minecraft:oak_log
setblock 330 93 583 minecraft:green_terracotta
setblock 330 93 587 minecraft:oak_log
fill 330 93 588 330 96 588 minecraft:green_terracotta
setblock 330 93 592 minecraft:oak_log
fill 330 93 593 331 95 593 minecraft:green_terracotta
setblock 330 93 597 minecraft:oak_log
fill 331 93 562 331 96 562 minecraft:green_terracotta
setblock 331 93 566 minecraft:oak_log
fill 331 93 567 331 96 567 minecraft:green_terracotta
setblock 331 93 571 minecraft:oak_log
fill 331 93 572 331 96 572 minecraft:green_terracotta
setblock 331 93 576 minecraft:oak_log
fill 331 93 577 331 96 577 minecraft:green_terracotta
setblock 331 93 591 minecraft:oak_log
fill 331 93 592 331 96 592 minecraft:green_terracotta
fill 331 93 598 333 93 598 minecraft:green_terracotta
setblock 332 93 565 minecraft:oak_log
fill 332 93 566 332 96 566 minecraft:green_terracotta
setblock 332 93 570 minecraft:oak_log
fill 332 93 571 332 96 571 minecraft:green_terracotta
setblock 333 93 569 minecraft:oak_log
setblock 333 93 570 minecraft:green_terracotta
setblock 333 93 584 minecraft:oak_leaves[persistent=true]
setblock 334 93 558 minecraft:oak_log
fill 335 93 558 335 96 558 minecraft:green_terracotta
fill 337 93 582 337 93 583 minecraft:oak_leaves[persistent=true]
fill 339 93 587 339 93 588 minecraft:oak_leaves[persistent=true]
setblock 340 93 586 minecraft:oak_leaves[persistent=true]
fill 341 93 588 341 94 588 minecraft:oak_leaves[persistent=true]
fill 341 93 590 342 93 590 minecraft:oak_leaves[persistent=true]
fill 341 93 593 342 94 593 minecraft:oak_leaves[persistent=true]
setblock 342 93 586 minecraft:oak_leaves[persistent=true]
setblock 343 93 587 minecraft:oak_leaves[persistent=true]
setblock 343 93 589 minecraft:oak_leaves[persistent=true]
fill 345 93 598 345 96 598 minecraft:green_terracotta
fill 347 93 558 347 94 558 minecraft:green_terracotta
fill 347 93 597 347 95 597 minecraft:green_terracotta
setblock 349 93 558 minecraft:oak_log
fill 349 93 596 349 94 596 minecraft:green_terracotta
setblock 349 93 598 minecraft:oak_log
fill 350 93 558 350 96 558 minecraft:green_terracotta
setblock 350 93 597 minecraft:oak_log
fill 350 93 598 350 96 598 minecraft:green_terracotta
setblock 351 93 596 minecraft:oak_log
fill 351 93 597 351 96 597 minecraft:green_terracotta
fill 352 93 596 352 96 596 minecraft:green_terracotta
setblock 354 93 598 minecraft:oak_log
setblock 355 93 597 minecraft:oak_log
fill 355 93 598 355 96 598 minecraft:green_terracotta
fill 356 93 597 356 96 597 minecraft:green_terracotta
fill 368 93 571 368 94 572 minecraft:green_terracotta
setblock 369 93 568 minecraft:oak_log
fill 369 93 569 369 96 569 minecraft:green_terracotta
setblock 369 93 572 minecraft:green_terracotta
setblock 369 93 573 minecraft:oak_log
fill 369 93 574 369 96 574 minecraft:green_terracotta
setblock 369 93 578 minecraft:oak_log
fill 369 93 584 369 96 584 minecraft:green_terracotta
setblock 369 93 588 minecraft:oak_log
fill 369 93 589 369 96 589 minecraft:green_terracotta
setblock 369 93 593 minecraft:oak_log
fill 369 93 594 369 96 594 minecraft:green_terracotta
setblock 370 93 559 minecraft:oak_leaves[persistent=true]
fill 370 93 563 370 96 563 minecraft:green_terracotta
setblock 370 93 567 minecraft:oak_log
fill 370 93 568 370 96 568 minecraft:green_terracotta
setblock 370 93 572 minecraft:oak_log
fill 370 93 573 370 96 573 minecraft:green_terracotta
setblock 370 93 577 minecraft:oak_log
fill 370 93 578 370 96 578 minecraft:green_terracotta
setblock 370 93 582 minecraft:oak_log
fill 370 93 583 370 96 583 minecraft:green_terracotta
setblock 370 93 587 minecraft:oak_log
fill 370 93 588 370 96 588 minecraft:green_terracotta
setblock 370 93 592 minecraft:oak_log
fill 370 93 593 370 96 593 minecraft:green_terracotta
setblock 370 93 597 minecraft:oak_log
fill 330 94 558 332 94 558 minecraft:green_terracotta
setblock 330 94 561 minecraft:oak_log
fill 330 94 562 330 97 562 minecraft:green_terracotta
setblock 330 94 566 minecraft:oak_log
fill 330 94 567 330 97 567 minecraft:green_terracotta
setblock 330 94 571 minecraft:oak_log
fill 330 94 572 330 97 572 minecraft:green_terracotta
setblock 330 94 576 minecraft:oak_log
fill 330 94 577 330 97 577 minecraft:green_terracotta
setblock 330 94 581 minecraft:oak_log
fill 330 94 582 330 97 582 minecraft:green_terracotta
setblock 330 94 586 minecraft:oak_log
fill 330 94 587 330 97 587 minecraft:green_terracotta
setblock 330 94 591 minecraft:oak_log
fill 330 94 592 330 97 592 minecraft:green_terracotta
setblock 330 94 596 minecraft:oak_log
fill 330 94 597 330 96 598 minecraft:green_terracotta
setblock 331 94 565 minecraft:oak_log
fill 331 94 566 331 97 566 minecraft:green_terracotta
setblock 331 94 570 minecraft:oak_log
fill 331 94 571 331 97 571 minecraft:green_terracotta
setblock 331 94 575 minecraft:oak_log
fill 331 94 576 331 97 576 minecraft:green_terracotta
setblock 331 94 590 minecraft:oak_log
fill 331 94 591 331 97 591 minecraft:green_terracotta
setblock 331 94 594 minecraft:green_terracotta
setblock 331 94 595 minecraft:oak_log
fill 331 94 598 332 94 598 minecraft:green_terracotta
fill 332 94 565 332 95 565 minecraft:green_terracotta
setblock 332 94 569 minecraft:oak_log
fill 332 94 570 332 97 570 minecraft:green_terracotta
setblock 332 94 574 minecraft:oak_log
fill 332 94 575 332 97 575 minecraft:green_terracotta
setblock 333 94 558 minecraft:oak_log
setblock 333 94 598 minecraft:oak_log
fill 334 94 558 334 97 558 minecraft:green_terracotta
fill 334 94 598 335 96 598 minecraft:green_terracotta
fill 340 94 558 340 95 558 minecraft:oak_leaves[persistent=true]
setblock 343 94 598 minecraft:oak_log
fill 344 94 598 344 97 598 minecraft:green_terracotta
fill 345 94 597 346 96 597 minecraft:green_terracotta
fill 346 94 558 346 95 558 minecraft:green_terracotta
fill 347 94 596 348 95 596 minecraft:green_terracotta
setblock 348 94 558 minecraft:oak_log
setblock 348 94 598 minecraft:oak_log
fill 349 94 558 349 97 558 minecraft:green_terracotta
setblock 349 94 597 minecraft:oak_log
fill 349 94 598 349 97 598 minecraft:green_terracotta
setblock 350 94 595 minecraft:green_terracotta
setblock 350 94 596 minecraft:oak_log
fill 350 94 597 350 97 597 minecraft:green_terracotta
setblock 351 94 595 minecraft:oak_log
fill 351 94 596 351 97 596 minecraft:green_terracotta
fill 352 94 595 352 97 595 minecraft:green_terracotta
setblock 353 94 558 minecraft:oak_log
setblock 353 94 598 minecraft:oak_log
setblock 354 94 597 minecraft:oak_log
fill 354 94 598 354 97 598 minecraft:green_terracotta
fill 355 94 597 355 97 597 minecraft:green_terracotta
setblock 365 94 558 minecraft:oak_leaves[persistent=true]
fill 368 94 569 368 96 570 minecraft:green_terracotta
setblock 368 94 573 minecraft:oak_log
fill 368 94 574 368 96 575 minecraft:green_terracotta
setblock 369 94 567 minecraft:oak_log
fill 369 94 568 369 97 568 minecraft:green_terracotta
setblock 369 94 572 minecraft:oak_log
fill 369 94 573 369 97 573 minecraft:green_terracotta
fill 369 94 575 369 94 576 minecraft:green_terracotta
setblock 369 94 577 minecraft:oak_log
fill 369 94 578 369 94 581 minecraft:green_terracotta
setblock 369 94 587 minecraft:oak_log
fill 369 94 588 369 97 588 minecraft:green_terracotta
setblock 369 94 592 minecraft:oak_log
fill 369 94 593 369 97 593 minecraft:green_terracotta
fill 369 94 595 370 94 595 minecraft:green_terracotta
fill 369 94 598 370 96 598 minecraft:green_terracotta
setblock 370 94 566 minecraft:oak_log
fill 370 94 567 370 97 567 minecraft:green_terracotta
setblock 370 94 571 minecraft:oak_log
fill 370 94 572 370 97 572 minecraft:green_terracotta
setblock 370 94 576 minecraft:oak_log
fill 370 94 577 370 97 577 minecraft:green_terracotta
setblock 370 94 581 minecraft:oak_log
fill 370 94 582 370 97 582 minecraft:green_terracotta
setblock 370 94 586 minecraft:oak_log
fill 370 94 587 370 97 587 minecraft:green_terracotta
setblock 370 94 591 minecraft:oak_log
fill 370 94 592 370 97 592 minecraft:green_terracotta
setblock 370 94 596 minecraft:oak_log
fill 370 94 597 370 97 597 minecraft:green_terracotta
fill 330 95 558 331 95 558 minecraft:green_terracotta
setblock 330 95 560 minecraft:oak_log
fill 330 95 561 331 97 561 minecraft:green_terracotta
setblock 330 95 565 minecraft:oak_log
fill 330 95 566 330 98 566 minecraft:green_terracotta
setblock 330 95 570 minecraft:oak_log
fill 330 95 571 330 98 571 minecraft:green_terracotta
setblock 330 95 575 minecraft:oak_log
fill 330 95 576 330 98 576 minecraft:green_terracotta
setblock 330 95 580 minecraft:oak_log
fill 330 95 581 330 98 581 minecraft:green_terracotta
fill 330 95 583 330 96 583 minecraft:green_terracotta
setblock 330 95 585 minecraft:oak_log
fill 330 95 586 330 98 586 minecraft:green_terracotta
setblock 330 95 590 minecraft:oak_log
fill 330 95 591 330 98 591 minecraft:green_terracotta
setblock 330 95 595 minecraft:oak_log
fill 330 95 596 331 97 596 minecraft:green_terracotta
setblock 331 95 564 minecraft:oak_log
fill 331 95 565 331 98 565 minecraft:green_terracotta
setblock 331 95 569 minecraft:oak_log
fill 331 95 570 331 98 570 minecraft:green_terracotta
setblock 331 95 574 minecraft:oak_log
fill 331 95 575 331 98 575 minecraft:green_terracotta
setblock 331 95 578 minecraft:green_terracotta
setblock 331 95 590 minecraft:green_terracotta
setblock 331 95 594 minecraft:oak_log
fill 331 95 595 331 98 595 minecraft:green_terracotta
fill 331 95 597 331 95 598 minecraft:green_terracotta
setblock 332 95 558 minecraft:oak_log
setblock 332 95 568 minecraft:oak_log
fill 332 95 569 332 98 569 minecraft:green_terracotta
setblock 332 95 573 minecraft:oak_log
fill 332 95 574 332 98 574 minecraft:green_terracotta
setblock 332 95 597 minecraft:green_terracotta
setblock 332 95 598 minecraft:oak_log
fill 333 95 558 333 98 558 minecraft:green_terracotta
fill 333 95 598 333 98 598 minecraft:green_terracotta
setblock 336 95 558 minecraft:green_terracotta
setblock 336 95 598 minecraft:green_terracotta
setblock 341 95 598 minecraft:green_terracotta
setblock 342 95 598 minecraft:oak_log
fill 343 95 598 343 98 598 minecraft:green_terracotta
fill 344 95 558 345 96 558 minecraft:green_terracotta
fill 344 95 597 344 98 597 minecraft:green_terracotta
fill 346 95 596 346 97 596 minecraft:green_terracotta
setblock 347 95 558 minecraft:oak_log
setblock 347 95 598 minecraft:oak_log
fill 348 95 558 348 98 558 minecraft:green_terracotta
fill 348 95 595 349 95 595 minecraft:green_terracotta
setblock 348 95 597 minecraft:oak_log
fill 348 95 598 348 98 598 minecraft:green_terracotta
setblock 349 95 596 minecraft:oak_log
fill 349 95 597 349 98 597 minecraft:green_terracotta
setblock 350 95 595 minecraft:oak_log
fill 350 95 596 350 98 596 minecraft:green_terracotta
fill 351 95 595 351 98 595 minecraft:green_terracotta
setblock 352 95 558 minecraft:oak_log
setblock 352 95 598 minecraft:oak_log
fill 353 95 558 353 98 558 minecraft:green_terracotta
fill 353 95 595 353 96 595 minecraft:green_terracotta
setblock 353 95 597 minecraft:oak_log
fill 353 95 598 353 98 598 minecraft:green_terracotta
setblock 354 95 596 minecraft:oak_log
fill 354 95 597 354 98 597 minecraft:green_terracotta
fill 355 95 596 355 98 596 minecraft:green_terracotta
setblock 357 95 598 minecraft:oak_log
fill 358 95 598 358 98 598 minecraft:green_terracotta
setblock 359 95 558 minecraft:oak_leaves[persistent=true]
setblock 360 95 598 minecraft:oak_leaves[persistent=true]
setblock 367 95 598 minecraft:oak_log
fill 368 95 568 368 98 568 minecraft:green_terracotta
setblock 368 95 571 minecraft:green_terracotta
setblock 368 95 572 minecraft:oak_log
fill 368 95 573 368 98 573 minecraft:green_terracotta
setblock 368 95 576 minecraft:green_terracotta
setblock 368 95 577 minecraft:oak_log
setblock 368 95 591 minecraft:green_terracotta
setblock 368 95 592 minecraft:oak_log
fill 368 95 598 368 98 598 minecraft:green_terracotta
setblock 369 95 565 minecraft:green_terracotta
setblock 369 95 566 minecraft:oak_log
fill 369 95 567 369 98 567 minecraft:green_terracotta
setblock 369 95 571 minecraft:oak_log
fill 369 95 572 369 98 572 minecraft:green_terracotta
setblock 369 95 575 minecraft:green_terracotta
setblock 369 95 576 minecraft:oak_log
fill 369 95 577 369 95 580 minecraft:green_terracotta
setblock 369 95 581 minecraft:oak_log
fill 369 95 582 369 97 583 minecraft:green_terracotta
setblock 369 95 586 minecraft:oak_log
fill 369 95 587 369 98 587 minecraft:green_terracotta
setblock 369 95 591 minecraft:oak_log
fill 369 95 592 369 98 592 minecraft:green_terracotta
setblock 369 95 595 minecraft:green_terracotta
setblock 369 95 596 minecraft:oak_log
fill 370 95 562 370 97 562 minecraft:green_terracotta
setblock 370 95 565 minecraft:oak_log
fill 370 95 566 370 98 566 minecraft:green_terracotta
setblock 370 95 570 minecraft:oak_log
fill 370 95 571 370 98 571 minecraft:green_terracotta
setblock 370 95 575 minecraft:oak_log
fill 370 95 576 370 98 576 minecraft:green_terracotta
setblock 370 95 580 minecraft:oak_log
fill 370 95 581 370 98 581 minecraft:green_terracotta
setblock 370 95 585 minecraft:oak_log
fill 370 95 586 370 98 586 minecraft:green_terracotta
setblock 370 95 590 minecraft:oak_log
fill 370 95 591 370 98 591 minecraft:green_terracotta
setblock 370 95 595 minecraft:oak_log
fill 370 95 596 370 98 596 minecraft:green_terracotta
setblock 330 96 558 minecraft:green_terracotta
setblock 330 96 559 minecraft:oak_log
fill 330 96 560 331 98 560 minecraft:green_terracotta
setblock 330 96 564 minecraft:oak_log
fill 330 96 565 330 99 565 minecraft:green_terracotta
setblock 330 96 569 minecraft:oak_log
fill 330 96 570 330 99 570 minecraft:green_terracotta
setblock 330 96 574 minecraft:oak_log
fill 330 96 575 330 99 575 minecraft:green_terracotta
setblock 330 96 579 minecraft:oak_log
fill 330 96 580 330 99 580 minecraft:green_terracotta
setblock 330 96 584 minecraft:oak_log
fill 330 96 585 330 98 585 minecraft:green_terracotta
setblock 330 96 589 minecraft:oak_log
fill 330 96 590 330 99 590 minecraft:green_terracotta
setblock 330 96 593 minecraft:green_terracotta
setblock 330 96 594 minecraft:oak_log
fill 330 96 595 330 99 595 minecraft:green_terracotta
setblock 331 96 558 minecraft:oak_log
fill 331 96 559 333 97 559 minecraft:green_terracotta
setblock 331 96 563 minecraft:oak_log
fill 331 96 564 331 99 564 minecraft:green_terracotta
setblock 331 96 568 minecraft:oak_log
fill 331 96 569 331 99 569 minecraft:green_terracotta
setblock 331 96 573 minecraft:oak_log
fill 331 96 574 331 99 574 minecraft:green_terracotta
setblock 331 96 578 minecraft:oak_log
fill 331 96 579 331 99 579 minecraft:green_terracotta
setblock 331 96 593 minecraft:oak_log
fill 331 96 594 331 99 594 minecraft:green_terracotta
setblock 331 96 597 minecraft:green_terracotta
setblock 331 96 598 minecraft:oak_log
fill 332 96 558 332 99 558 minecraft:green_terracotta
setblock 332 96 560 minecraft:light[level=14]
setblock 332 96 567 minecraft:oak_log
fill 332 96 568 332 99 568 minecraft:green_terracotta
setblock 332 96 572 minecraft:oak_log
fill 332 96 573 332 99 573 minecraft:green_terracotta
setblock 332 96 576 minecraft:green_terracotta
setblock 332 96 584 minecraft:light[level=14]
setblock 332 96 592 minecraft:light[level=14]
setblock 332 96 597 minecraft:oak_log
fill 332 96 598 332 99 598 minecraft:green_terracotta
fill 333 96 597 334 98 597 minecraft:green_terracotta
setblock 336 96 558 minecraft:oak_log
setblock 336 96 598 minecraft:oak_log
fill 337 96 558 338 98 558 minecraft:green_terracotta
fill 337 96 598 340 96 598 minecraft:green_terracotta
setblock 340 96 560 minecraft:light[level=14]
setblock 340 96 568 minecraft:light[level=14]
setblock 340 96 576 minecraft:light[level=14]
setblock 340 96 584 minecraft:light[level=14]
setblock 340 96 592 minecraft:light[level=14]
setblock 341 96 558 minecraft:oak_log
setblock 341 96 598 minecraft:oak_log
fill 342 96 558 343 98 558 minecraft:green_terracotta
fill 342 96 560 342 103 560 minecraft:oak_leaves[persistent=true]
setblock 342 96 597 minecraft:oak_log
fill 342 96 598 342 99 598 minecraft:green_terracotta
fill 343 96 597 343 99 597 minecraft:green_terracotta
fill 344 96 596 345 98 596 minecraft:green_terracotta
setblock 346 96 558 minecraft:oak_log
setblock 346 96 598 minecraft:oak_log
fill 347 96 558 347 99 558 minecraft:green_terracotta
fill 347 96 595 347 96 596 minecraft:green_terracotta
setblock 347 96 597 minecraft:oak_log
fill 347 96 598 347 99 598 minecraft:green_terracotta
fill 348 96 559 349 96 559 minecraft:green_terracotta
setblock 348 96 560 minecraft:light[level=14]
setblock 348 96 568 minecraft:light[level=14]
setblock 348 96 576 minecraft:light[level=14]
setblock 348 96 584 minecraft:light[level=14]
setblock 348 96 592 minecraft:light[level=14]
setblock 348 96 595 minecraft:green_terracotta
setblock 348 96 596 minecraft:oak_log
fill 348 96 597 348 99 597 minecraft:green_terracotta
setblock 349 96 595 minecraft:oak_log
fill 349 96 596 349 99 596 minecraft:green_terracotta
fill 350 96 595 350 99 595 minecraft:green_terracotta
setblock 351 96 558 minecraft:oak_log
setblock 351 96 598 minecraft:oak_log
fill 352 96 558 352 99 558 minecraft:green_terracotta
setblock 352 96 597 minecraft:oak_log
fill 352 96 598 352 99 598 minecraft:green_terracotta
setblock 353 96 596 minecraft:oak_log
fill 353 96 597 353 99 597 minecraft:green_terracotta
fill 354 96 596 354 99 596 minecraft:green_terracotta
setblock 356 96 560 minecraft:light[level=14]
setblock 356 96 568 minecraft:light[level=14]
setblock 356 96 576 minecraft:light[level=14]
setblock 356 96 584 minecraft:light[level=14]
setblock 356 96 592 minecraft:light[level=14]
setblock 356 96 598 minecraft:oak_log
setblock 357 96 597 minecraft:oak_log
fill 357 96 598 357 99 598 minecraft:green_terracotta
fill 359 96 598 359 97 598 minecraft:green_terracotta
setblock 364 96 560 minecraft:light[level=14]
setblock 364 96 568 minecraft:light[level=14]
setblock 364 96 576 minecraft:light[level=14]
setblock 364 96 584 minecraft:light[level=14]
setblock 364 96 592 minecraft:light[level=14]
fill 364 96 598 365 96 598 minecraft:green_terracotta
setblock 366 96 598 minecraft:oak_log
setblock 367 96 572 minecraft:oak_log
fill 367 96 573 367 98 574 minecraft:green_terracotta
setblock 367 96 597 minecraft:oak_log
fill 367 96 598 367 99 598 minecraft:green_terracotta
setblock 368 96 571 minecraft:oak_log
fill 368 96 572 368 99 572 minecraft:green_terracotta
setblock 368 96 576 minecraft:oak_log
fill 368 96 577 369 96 579 minecraft:green_terracotta
setblock 368 96 591 minecraft:oak_log
fill 368 96 592 368 97 594 minecraft:green_terracotta
fill 368 96 597 369 98 597 minecraft:green_terracotta
fill 369 96 558 370 96 558 minecraft:green_terracotta
setblock 369 96 565 minecraft:oak_log
fill 369 96 566 369 99 566 minecraft:green_terracotta
setblock 369 96 570 minecraft:oak_log
fill 369 96 571 369 99 571 minecraft:green_terracotta
setblock 369 96 575 minecraft:oak_log
fill 369 96 576 369 99 576 minecraft:green_terracotta
setblock 369 96 580 minecraft:oak_log
fill 369 96 581 369 99 581 minecraft:green_terracotta
setblock 369 96 585 minecraft:oak_log
fill 369 96 586 369 99 586 minecraft:green_terracotta
setblock 369 96 590 minecraft:oak_log
fill 369 96 591 369 99 591 minecraft:green_terracotta
setblock 369 96 595 minecraft:oak_log
fill 369 96 596 369 99 596 minecraft:green_terracotta
setblock 370 96 559 minecraft:oak_log
fill 370 96 560 370 98 561 minecraft:green_terracotta
setblock 370 96 564 minecraft:oak_log
fill 370 96 565 370 99 565 minecraft:green_terracotta
setblock 370 96 569 minecraft:oak_log
fill 370 96 570 370 99 570 minecraft:green_terracotta
setblock 370 96 574 minecraft:oak_log
fill 370 96 575 370 99 575 minecraft:green_terracotta
setblock 370 96 579 minecraft:oak_log
fill 370 96 580 370 99 580 minecraft:green_terracotta
setblock 370 96 584 minecraft:oak_log
fill 370 96 585 370 99 585 minecraft:green_terracotta
setblock 370 96 589 minecraft:oak_log
fill 370 96 590 370 99 590 minecraft:green_terracotta
setblock 370 96 594 minecraft:oak_log
fill 370 96 595 370 99 595 minecraft:green_terracotta
setblock 330 97 558 minecraft:oak_log
fill 330 97 559 330 100 559 minecraft:green_terracotta
setblock 330 97 563 minecraft:oak_log
fill 330 97 564 330 100 564 minecraft:green_terracotta
setblock 330 97 568 minecraft:oak_log
fill 330 97 569 330 100 569 minecraft:green_terracotta
setblock 330 97 573 minecraft:oak_log
fill 330 97 574 330 100 574 minecraft:green_terracotta
setblock 330 97 578 minecraft:oak_log
fill 330 97 579 330 100 579 minecraft:green_terracotta
setblock 330 97 583 minecraft:oak_log
fill 330 97 584 330 100 584 minecraft:green_terracotta
setblock 330 97 588 minecraft:oak_log
fill 330 97 589 330 100 589 minecraft:green_terracotta
setblock 330 97 593 minecraft:oak_log
fill 330 97 594 330 100 594 minecraft:green_terracotta
setblock 330 97 597 minecraft:green_terracotta
setblock 330 97 598 minecraft:oak_log
fill 331 97 558 331 100 558 minecraft:green_terracotta
setblock 331 97 562 minecraft:oak_log
fill 331 97 563 331 100 563 minecraft:green_terracotta
setblock 331 97 567 minecraft:oak_log
fill 331 97 568 331 100 568 minecraft:green_terracotta
setblock 331 97 572 minecraft:oak_log
fill 331 97 573 331 100 573 minecraft:green_terracotta
setblock 331 97 577 minecraft:oak_log
fill 331 97 578 331 100 578 minecraft:green_terracotta
setblock 331 97 592 minecraft:oak_log
fill 331 97 593 331 100 593 minecraft:green_terracotta
setblock 331 97 597 minecraft:oak_log
fill 331 97 598 331 100 598 minecraft:green_terracotta
setblock 332 97 566 minecraft:oak_log
fill 332 97 567 332 98 567 minecraft:green_terracotta
setblock 332 97 571 minecraft:oak_log
fill 332 97 572 332 100 572 minecraft:green_terracotta
setblock 332 97 576 minecraft:oak_log
fill 332 97 597 332 100 597 minecraft:green_terracotta
setblock 334 97 559 minecraft:oak_log
setblock 334 97 598 minecraft:green_terracotta
setblock 335 97 558 minecraft:oak_log
setblock 335 97 597 minecraft:green_terracotta
setblock 335 97 598 minecraft:oak_log
fill 336 97 558 336 100 558 minecraft:green_terracotta
fill 336 97 598 339 97 598 minecraft:green_terracotta
setblock 339 97 558 minecraft:green_terracotta
setblock 340 97 558 minecraft:oak_log
setblock 340 97 597 minecraft:green_terracotta
setblock 340 97 598 minecraft:oak_log
fill 341 97 558 341 100 558 minecraft:green_terracotta
setblock 341 97 597 minecraft:oak_log
fill 341 97 598 341 100 598 minecraft:green_terracotta
fill 342 97 597 342 100 597 minecraft:green_terracotta
fill 343 97 596 343 100 596 minecraft:green_terracotta
setblock 344 97 558 minecraft:green_terracotta
setblock 345 97 558 minecraft:oak_log
fill 345 97 559 348 97 559 minecraft:green_terracotta
fill 345 97 595 347 97 595 minecraft:green_terracotta
setblock 345 97 597 minecraft:green_terracotta
setblock 345 97 598 minecraft:oak_log
fill 346 97 558 346 100 558 minecraft:green_terracotta
setblock 346 97 597 minecraft:oak_log
fill 346 97 598 346 100 598 minecraft:green_terracotta
setblock 347 97 596 minecraft:oak_log
fill 347 97 597 347 100 597 minecraft:green_terracotta
setblock 348 97 595 minecraft:oak_log
fill 348 97 596 348 100 596 minecraft:green_terracotta
setblock 349 97 559 minecraft:oak_log
setblock 349 97 594 minecraft:oak_log
fill 349 97 595 349 100 595 minecraft:green_terracotta
setblock 350 97 558 minecraft:oak_log
fill 350 97 559 350 100 559 minecraft:green_terracotta
fill 350 97 594 350 99 594 minecraft:green_terracotta
setblock 350 97 598 minecraft:oak_log
fill 351 97 558 351 100 558 minecraft:green_terracotta
setblock 351 97 597 minecraft:oak_log
fill 351 97 598 351 100 598 minecraft:green_terracotta
setblock 352 97 596 minecraft:oak_log
fill 352 97 597 352 100 597 minecraft:green_terracotta
setblock 353 97 595 minecraft:oak_log
fill 353 97 596 353 100 596 minecraft:green_terracotta
setblock 354 97 558 minecraft:green_terracotta
setblock 355 97 598 minecraft:oak_log
setblock 356 97 597 minecraft:oak_log
fill 356 97 598 356 100 598 minecraft:green_terracotta
fill 357 97 597 357 100 597 minecraft:green_terracotta
setblock 360 97 598 minecraft:oak_log
fill 361 97 598 364 97 598 minecraft:green_terracotta
fill 364 97 597 365 97 597 minecraft:green_terracotta
setblock 365 97 598 minecraft:oak_log
setblock 366 97 558 minecraft:oak_leaves[persistent=true]
setblock 366 97 597 minecraft:oak_log
fill 366 97 598 366 100 598 minecraft:green_terracotta
fill 367 97 558 369 97 558 minecraft:green_terracotta
setblock 367 97 571 minecraft:oak_log
fill 367 97 572 367 100 572 minecraft:green_terracotta
setblock 367 97 575 minecraft:green_terracotta
setblock 367 97 576 minecraft:oak_log
fill 367 97 577 369 98 577 minecraft:green_terracotta
fill 367 97 597 367 100 597 minecraft:green_terracotta
setblock 368 97 569 minecraft:green_terracotta
setblock 368 97 570 minecraft:oak_log
fill 368 97 571 368 100 571 minecraft:green_terracotta
setblock 368 97 574 minecraft:green_terracotta
setblock 368 97 575 minecraft:oak_log
fill 368 97 576 368 100 576 minecraft:green_terracotta
fill 368 97 578 368 97 579 minecraft:green_terracotta
setblock 368 97 580 minecraft:oak_log
setblock 368 97 590 minecraft:oak_log
fill 368 97 591 368 98 591 minecraft:green_terracotta
setblock 368 97 595 minecraft:oak_log
setblock 369 97 564 minecraft:oak_log
fill 369 97 565 369 100 565 minecraft:green_terracotta
setblock 369 97 569 minecraft:oak_log
fill 369 97 570 369 100 570 minecraft:green_terracotta
setblock 369 97 574 minecraft:oak_log
fill 369 97 575 369 100 575 minecraft:green_terracotta
setblock 369 97 578 minecraft:green_terracotta
setblock 369 97 579 minecraft:oak_log
fill 369 97 580 369 100 580 minecraft:green_terracotta
setblock 369 97 584 minecraft:oak_log
fill 369 97 585 369 100 585 minecraft:green_terracotta
setblock 369 97 589 minecraft:oak_log
fill 369 97 590 369 100 590 minecraft:green_terracotta
setblock 369 97 594 minecraft:oak_log
fill 369 97 595 369 100 595 minecraft:green_terracotta
setblock 369 97 598 minecraft:green_terracotta
setblock 370 97 558 minecraft:oak_log
fill 370 97 559 370 100 559 minecraft:green_terracotta
setblock 370 97 563 minecraft:oak_log
fill 370 97 564 370 100 564 minecraft:green_terracotta
setblock 370 97 568 minecraft:oak_log
fill 370 97 569 370 100 569 minecraft:green_terracotta
setblock 370 97 573 minecraft:oak_log
fill 370 97 574 370 100 574 minecraft:green_terracotta
setblock 370 97 578 minecraft:oak_log
fill 370 97 579 370 100 579 minecraft:green_terracotta
setblock 370 97 583 minecraft:oak_log
fill 370 97 584 370 100 584 minecraft:green_terracotta
setblock 370 97 588 minecraft:oak_log
fill 370 97 589 370 100 589 minecraft:green_terracotta
setblock 370 97 593 minecraft:oak_log
fill 370 97 594 370 100 594 minecraft:green_terracotta
setblock 370 97 598 minecraft:oak_log
fill 330 98 558 330 101 558 minecraft:green_terracotta
setblock 330 98 561 minecraft:green_terracotta
setblock 330 98 562 minecraft:oak_log
fill 330 98 563 330 101 563 minecraft:green_terracotta
setblock 330 98 567 minecraft:oak_log
fill 330 98 568 330 101 568 minecraft:green_terracotta
setblock 330 98 572 minecraft:oak_log
fill 330 98 573 330 101 573 minecraft:green_terracotta
setblock 330 98 577 minecraft:oak_log
fill 330 98 578 330 101 578 minecraft:green_terracotta
setblock 330 98 582 minecraft:oak_log
fill 330 98 583 330 101 583 minecraft:green_terracotta
setblock 330 98 587 minecraft:oak_log
fill 330 98 588 330 99 588 minecraft:green_terracotta
setblock 330 98 592 minecraft:oak_log
fill 330 98 593 330 101 593 minecraft:green_terracotta
setblock 330 98 596 minecraft:green_terracotta
setblock 330 98 597 minecraft:oak_log
fill 330 98 598 330 101 598 minecraft:green_terracotta
fill 331 98 559 332 98 559 minecraft:green_terracotta
setblock 331 98 561 minecraft:oak_log
fill 331 98 562 331 101 562 minecraft:green_terracotta
setblock 331 98 566 minecraft:oak_log
fill 331 98 567 331 101 567 minecraft:green_terracotta
setblock 331 98 571 minecraft:oak_log
fill 331 98 572 331 101 572 minecraft:green_terracotta
setblock 331 98 576 minecraft:oak_log
fill 331 98 577 331 101 577 minecraft:green_terracotta
setblock 331 98 580 minecraft:green_terracotta
setblock 331 98 591 minecraft:oak_log
fill 331 98 592 331 99 592 minecraft:green_terracotta
setblock 331 98 596 minecraft:oak_log
fill 331 98 597 331 101 597 minecraft:green_terracotta
setblock 332 98 570 minecraft:oak_log
fill 332 98 571 332 100 571 minecraft:green_terracotta
setblock 332 98 575 minecraft:oak_log
fill 332 98 576 332 100 576 minecraft:green_terracotta
setblock 333 98 559 minecraft:oak_log
setblock 334 98 558 minecraft:oak_log
fill 334 98 559 335 100 559 minecraft:green_terracotta
setblock 334 98 598 minecraft:oak_log
fill 335 98 558 335 101 558 minecraft:green_terracotta
setblock 335 98 597 minecraft:oak_log
fill 335 98 598 338 98 598 minecraft:green_terracotta
fill 336 98 597 339 98 597 minecraft:green_terracotta
setblock 339 98 558 minecraft:oak_log
setblock 339 98 598 minecraft:oak_log
fill 340 98 558 340 101 558 minecraft:green_terracotta
setblock 340 98 597 minecraft:oak_log
fill 340 98 598 340 101 598 minecraft:green_terracotta
fill 341 98 597 341 101 597 minecraft:green_terracotta
fill 342 98 596 342 101 596 minecraft:green_terracotta
setblock 343 98 559 minecraft:oak_log
setblock 344 98 558 minecraft:oak_log
fill 344 98 559 347 98 559 minecraft:green_terracotta
fill 344 98 595 346 98 595 minecraft:green_terracotta
setblock 344 98 598 minecraft:oak_log
fill 345 98 558 345 101 558 minecraft:green_terracotta
setblock 345 98 597 minecraft:oak_log
fill 345 98 598 345 101 598 minecraft:green_terracotta
setblock 346 98 596 minecraft:oak_log
fill 346 98 597 346 101 597 minecraft:green_terracotta
setblock 347 98 594 minecraft:green_terracotta
setblock 347 98 595 minecraft:oak_log
fill 347 98 596 347 101 596 minecraft:green_terracotta
schedule function dropper:buildpart/139_2 1t
