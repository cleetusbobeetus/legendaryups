fill 540 77 278 540 78 278 minecraft:white_concrete
fill 540 77 280 540 78 280 minecraft:white_concrete
setblock 540 77 317 minecraft:white_concrete
setblock 542 77 275 minecraft:white_concrete
setblock 542 77 317 minecraft:white_concrete
fill 543 77 275 543 84 275 minecraft:brown_terracotta
fill 543 77 317 543 84 317 minecraft:brown_terracotta
setblock 544 77 275 minecraft:white_concrete
setblock 544 77 278 minecraft:light[level=15]
setblock 544 77 286 minecraft:light[level=15]
setblock 544 77 294 minecraft:light[level=15]
setblock 544 77 302 minecraft:light[level=15]
setblock 544 77 310 minecraft:light[level=15]
setblock 544 77 317 minecraft:white_concrete
setblock 546 77 275 minecraft:white_concrete
setblock 546 77 317 minecraft:white_concrete
fill 547 77 275 547 84 275 minecraft:brown_terracotta
fill 547 77 317 547 84 317 minecraft:brown_terracotta
setblock 548 77 275 minecraft:white_concrete
setblock 548 77 317 minecraft:white_concrete
setblock 549 77 275 minecraft:brown_terracotta
fill 549 77 309 549 78 309 minecraft:white_concrete
fill 549 77 311 549 78 311 minecraft:white_concrete
fill 549 77 313 549 78 313 minecraft:white_concrete
fill 549 77 315 549 78 315 minecraft:white_concrete
setblock 550 77 275 minecraft:white_concrete
fill 550 77 308 550 78 308 minecraft:white_concrete
fill 550 77 310 550 78 310 minecraft:white_concrete
fill 550 77 312 550 78 312 minecraft:white_concrete
fill 550 77 314 550 78 314 minecraft:white_concrete
fill 550 77 316 550 77 317 minecraft:white_concrete
fill 551 77 275 551 84 275 minecraft:brown_terracotta
fill 551 77 309 551 78 309 minecraft:white_concrete
fill 551 77 311 551 78 311 minecraft:white_concrete
fill 551 77 313 551 78 313 minecraft:white_concrete
fill 551 77 315 551 78 315 minecraft:white_concrete
fill 551 77 317 551 84 317 minecraft:brown_terracotta
setblock 552 77 275 minecraft:white_concrete
setblock 552 77 278 minecraft:light[level=15]
setblock 552 77 286 minecraft:light[level=15]
setblock 552 77 302 minecraft:light[level=15]
fill 552 77 308 552 78 308 minecraft:white_concrete
fill 552 77 310 552 78 310 minecraft:white_concrete
fill 552 77 312 552 78 312 minecraft:white_concrete
fill 552 77 314 552 78 314 minecraft:white_concrete
fill 552 77 316 552 77 317 minecraft:white_concrete
fill 553 77 309 553 78 309 minecraft:white_concrete
fill 553 77 311 553 78 311 minecraft:white_concrete
fill 553 77 313 553 78 313 minecraft:white_concrete
fill 553 77 315 553 78 315 minecraft:white_concrete
setblock 554 77 275 minecraft:white_concrete
fill 554 77 302 554 78 302 minecraft:white_concrete
fill 554 77 304 554 78 304 minecraft:white_concrete
fill 554 77 306 554 78 306 minecraft:white_concrete
fill 554 77 308 554 78 308 minecraft:white_concrete
fill 554 77 310 554 78 310 minecraft:white_concrete
fill 554 77 312 554 78 312 minecraft:white_concrete
fill 554 77 314 554 78 314 minecraft:white_concrete
fill 554 77 316 554 77 317 minecraft:white_concrete
fill 555 77 275 555 84 275 minecraft:brown_terracotta
fill 555 77 303 555 78 303 minecraft:white_concrete
fill 555 77 305 555 78 305 minecraft:white_concrete
fill 555 77 307 555 78 307 minecraft:white_concrete
fill 555 77 309 555 78 309 minecraft:white_concrete
fill 555 77 311 555 78 311 minecraft:white_concrete
fill 555 77 313 555 78 313 minecraft:white_concrete
fill 555 77 315 555 78 315 minecraft:white_concrete
fill 555 77 317 555 84 317 minecraft:brown_terracotta
setblock 556 77 275 minecraft:white_concrete
fill 556 77 302 556 78 302 minecraft:white_concrete
fill 556 77 304 556 78 304 minecraft:white_concrete
fill 556 77 306 556 78 306 minecraft:white_concrete
fill 556 77 308 556 78 308 minecraft:white_concrete
fill 556 77 310 556 78 310 minecraft:white_concrete
fill 556 77 312 556 78 312 minecraft:white_concrete
fill 556 77 314 556 78 314 minecraft:white_concrete
fill 556 77 316 556 77 317 minecraft:white_concrete
fill 557 77 303 557 78 303 minecraft:white_concrete
fill 557 77 305 557 78 305 minecraft:white_concrete
fill 557 77 307 557 78 307 minecraft:white_concrete
fill 557 77 309 557 78 309 minecraft:white_concrete
fill 557 77 311 557 78 311 minecraft:white_concrete
fill 557 77 313 557 78 313 minecraft:white_concrete
fill 557 77 315 557 78 315 minecraft:white_concrete
setblock 558 77 275 minecraft:white_concrete
fill 558 77 302 559 77 302 minecraft:white_concrete
fill 558 77 304 559 77 304 minecraft:white_concrete
fill 558 77 306 559 77 306 minecraft:white_concrete
fill 558 77 308 559 77 308 minecraft:white_concrete
fill 558 77 310 559 77 310 minecraft:white_concrete
fill 558 77 312 559 77 312 minecraft:white_concrete
fill 558 77 314 559 77 314 minecraft:white_concrete
fill 558 77 316 558 77 317 minecraft:white_concrete
setblock 559 77 275 minecraft:brown_terracotta
setblock 559 77 276 minecraft:white_concrete
fill 559 77 277 559 84 277 minecraft:brown_terracotta
setblock 559 77 278 minecraft:white_concrete
setblock 559 77 280 minecraft:white_concrete
fill 559 77 281 559 84 281 minecraft:brown_terracotta
setblock 559 77 282 minecraft:white_concrete
setblock 559 77 284 minecraft:white_concrete
fill 559 77 285 559 84 285 minecraft:brown_terracotta
setblock 559 77 286 minecraft:white_concrete
setblock 559 77 288 minecraft:white_concrete
fill 559 77 289 559 84 289 minecraft:brown_terracotta
setblock 559 77 290 minecraft:white_concrete
setblock 559 77 292 minecraft:white_concrete
fill 559 77 293 559 84 293 minecraft:brown_terracotta
setblock 559 77 294 minecraft:white_concrete
setblock 559 77 296 minecraft:white_concrete
fill 559 77 297 559 84 297 minecraft:brown_terracotta
setblock 559 77 298 minecraft:white_concrete
setblock 559 77 300 minecraft:white_concrete
fill 559 77 301 559 84 301 minecraft:brown_terracotta
fill 559 77 305 559 84 305 minecraft:brown_terracotta
fill 559 77 309 559 78 309 minecraft:brown_terracotta
setblock 559 77 311 minecraft:brown_terracotta
fill 559 77 313 559 78 313 minecraft:brown_terracotta
setblock 559 77 315 minecraft:brown_terracotta
setblock 559 77 316 minecraft:white_concrete
fill 559 77 317 559 84 317 minecraft:brown_terracotta
setblock 517 78 275 minecraft:white_concrete
fill 517 78 276 517 85 276 minecraft:brown_terracotta
fill 517 78 278 517 85 278 minecraft:brown_terracotta
setblock 517 78 279 minecraft:white_concrete
fill 517 78 280 517 85 280 minecraft:brown_terracotta
fill 517 78 282 517 85 282 minecraft:brown_terracotta
setblock 517 78 283 minecraft:white_concrete
fill 517 78 284 517 85 284 minecraft:brown_terracotta
fill 517 78 286 517 85 286 minecraft:brown_terracotta
setblock 517 78 287 minecraft:white_concrete
fill 517 78 288 517 85 288 minecraft:brown_terracotta
fill 517 78 290 517 85 290 minecraft:brown_terracotta
setblock 517 78 291 minecraft:white_concrete
fill 517 78 292 517 85 292 minecraft:brown_terracotta
fill 517 78 294 517 85 294 minecraft:brown_terracotta
setblock 517 78 295 minecraft:white_concrete
fill 517 78 296 517 85 296 minecraft:brown_terracotta
fill 517 78 298 517 85 298 minecraft:brown_terracotta
setblock 517 78 299 minecraft:white_concrete
fill 517 78 300 517 85 300 minecraft:brown_terracotta
fill 517 78 302 517 85 302 minecraft:brown_terracotta
setblock 517 78 303 minecraft:white_concrete
fill 517 78 304 517 85 304 minecraft:brown_terracotta
fill 517 78 306 517 85 306 minecraft:brown_terracotta
setblock 517 78 307 minecraft:white_concrete
fill 517 78 308 517 85 308 minecraft:brown_terracotta
fill 517 78 310 517 85 310 minecraft:brown_terracotta
setblock 517 78 311 minecraft:white_concrete
fill 517 78 312 517 85 312 minecraft:brown_terracotta
fill 517 78 314 517 85 314 minecraft:brown_terracotta
setblock 517 78 315 minecraft:white_concrete
fill 517 78 316 517 85 316 minecraft:brown_terracotta
setblock 517 78 317 minecraft:white_concrete
fill 518 78 275 518 85 275 minecraft:brown_terracotta
setblock 518 78 296 minecraft:white_concrete
setblock 518 78 298 minecraft:white_concrete
setblock 518 78 300 minecraft:white_concrete
setblock 518 78 302 minecraft:white_concrete
setblock 518 78 304 minecraft:white_concrete
setblock 518 78 306 minecraft:white_concrete
fill 518 78 317 518 85 317 minecraft:brown_terracotta
fill 520 78 275 520 85 275 minecraft:brown_terracotta
fill 520 78 317 520 85 317 minecraft:brown_terracotta
setblock 521 78 275 minecraft:white_concrete
setblock 521 78 317 minecraft:white_concrete
fill 522 78 275 522 85 275 minecraft:brown_terracotta
fill 522 78 317 522 85 317 minecraft:brown_terracotta
fill 524 78 275 524 85 275 minecraft:brown_terracotta
fill 524 78 317 524 85 317 minecraft:brown_terracotta
setblock 525 78 275 minecraft:white_concrete
setblock 525 78 317 minecraft:white_concrete
fill 526 78 275 526 85 275 minecraft:brown_terracotta
fill 526 78 317 526 85 317 minecraft:brown_terracotta
fill 528 78 275 528 85 275 minecraft:brown_terracotta
fill 528 78 317 528 85 317 minecraft:brown_terracotta
setblock 529 78 275 minecraft:white_concrete
setblock 529 78 317 minecraft:white_concrete
fill 530 78 275 530 85 275 minecraft:brown_terracotta
fill 530 78 317 530 85 317 minecraft:brown_terracotta
fill 532 78 275 532 85 275 minecraft:brown_terracotta
setblock 532 78 276 minecraft:white_concrete
fill 532 78 317 532 85 317 minecraft:brown_terracotta
setblock 533 78 275 minecraft:white_concrete
setblock 533 78 317 minecraft:white_concrete
fill 534 78 275 534 85 275 minecraft:brown_terracotta
setblock 534 78 276 minecraft:white_concrete
fill 534 78 317 534 85 317 minecraft:brown_terracotta
fill 536 78 275 536 85 275 minecraft:brown_terracotta
setblock 536 78 276 minecraft:white_concrete
fill 536 78 317 536 85 317 minecraft:brown_terracotta
setblock 537 78 275 minecraft:white_concrete
setblock 537 78 317 minecraft:white_concrete
fill 538 78 275 538 85 275 minecraft:brown_terracotta
setblock 538 78 276 minecraft:white_concrete
fill 538 78 306 540 79 306 minecraft:red_concrete
fill 538 78 317 538 85 317 minecraft:brown_terracotta
fill 539 78 305 539 79 305 minecraft:red_concrete
fill 539 78 307 539 79 307 minecraft:red_concrete
fill 540 78 275 540 85 275 minecraft:brown_terracotta
setblock 540 78 276 minecraft:white_concrete
fill 540 78 317 540 85 317 minecraft:brown_terracotta
setblock 541 78 275 minecraft:white_concrete
setblock 541 78 317 minecraft:white_concrete
fill 542 78 275 542 85 275 minecraft:brown_terracotta
fill 542 78 317 542 85 317 minecraft:brown_terracotta
fill 544 78 275 544 85 275 minecraft:brown_terracotta
fill 544 78 317 544 85 317 minecraft:brown_terracotta
setblock 545 78 275 minecraft:white_concrete
setblock 545 78 317 minecraft:white_concrete
fill 546 78 275 546 85 275 minecraft:brown_terracotta
fill 546 78 317 546 85 317 minecraft:brown_terracotta
fill 548 78 275 548 85 275 minecraft:brown_terracotta
fill 548 78 317 548 85 317 minecraft:brown_terracotta
setblock 549 78 275 minecraft:white_concrete
setblock 549 78 317 minecraft:white_concrete
fill 550 78 275 550 85 275 minecraft:brown_terracotta
setblock 550 78 316 minecraft:white_concrete
fill 550 78 317 550 85 317 minecraft:brown_terracotta
fill 552 78 275 552 85 275 minecraft:brown_terracotta
setblock 552 78 316 minecraft:white_concrete
fill 552 78 317 552 85 317 minecraft:brown_terracotta
setblock 553 78 275 minecraft:white_concrete
setblock 553 78 317 minecraft:white_concrete
fill 554 78 275 554 85 275 minecraft:brown_terracotta
setblock 554 78 316 minecraft:white_concrete
fill 554 78 317 554 85 317 minecraft:brown_terracotta
fill 556 78 275 556 85 275 minecraft:brown_terracotta
setblock 556 78 316 minecraft:white_concrete
fill 556 78 317 556 85 317 minecraft:brown_terracotta
setblock 557 78 275 minecraft:white_concrete
setblock 557 78 317 minecraft:white_concrete
fill 558 78 275 558 85 275 minecraft:brown_terracotta
setblock 558 78 302 minecraft:white_concrete
setblock 558 78 304 minecraft:white_concrete
setblock 558 78 306 minecraft:white_concrete
setblock 558 78 308 minecraft:white_concrete
setblock 558 78 310 minecraft:white_concrete
setblock 558 78 312 minecraft:white_concrete
setblock 558 78 314 minecraft:white_concrete
setblock 558 78 316 minecraft:white_concrete
fill 558 78 317 558 85 317 minecraft:brown_terracotta
setblock 559 78 275 minecraft:white_concrete
fill 559 78 276 559 85 276 minecraft:brown_terracotta
fill 559 78 278 559 85 278 minecraft:brown_terracotta
setblock 559 78 279 minecraft:white_concrete
fill 559 78 280 559 85 280 minecraft:brown_terracotta
fill 559 78 282 559 85 282 minecraft:brown_terracotta
setblock 559 78 283 minecraft:white_concrete
fill 559 78 284 559 85 284 minecraft:brown_terracotta
fill 559 78 286 559 85 286 minecraft:brown_terracotta
setblock 559 78 287 minecraft:white_concrete
fill 559 78 288 559 85 288 minecraft:brown_terracotta
fill 559 78 290 559 85 290 minecraft:brown_terracotta
setblock 559 78 291 minecraft:white_concrete
fill 559 78 292 559 85 292 minecraft:brown_terracotta
fill 559 78 294 559 85 294 minecraft:brown_terracotta
setblock 559 78 295 minecraft:white_concrete
fill 559 78 296 559 85 296 minecraft:brown_terracotta
fill 559 78 298 559 85 298 minecraft:brown_terracotta
setblock 559 78 299 minecraft:white_concrete
fill 559 78 300 559 85 300 minecraft:brown_terracotta
fill 559 78 302 559 85 302 minecraft:brown_terracotta
setblock 559 78 303 minecraft:white_concrete
fill 559 78 304 559 85 304 minecraft:brown_terracotta
fill 559 78 306 559 85 306 minecraft:brown_terracotta
setblock 559 78 307 minecraft:white_concrete
fill 559 78 308 559 85 308 minecraft:brown_terracotta
fill 559 78 310 559 85 310 minecraft:brown_terracotta
setblock 559 78 311 minecraft:white_concrete
fill 559 78 312 559 85 312 minecraft:brown_terracotta
fill 559 78 314 559 85 314 minecraft:brown_terracotta
setblock 559 78 315 minecraft:white_concrete
fill 559 78 316 559 85 316 minecraft:brown_terracotta
fill 517 79 275 517 86 275 minecraft:brown_terracotta
fill 517 79 279 517 86 279 minecraft:brown_terracotta
fill 517 79 283 517 85 283 minecraft:brown_terracotta
fill 517 79 287 517 86 287 minecraft:brown_terracotta
fill 517 79 291 517 86 291 minecraft:brown_terracotta
fill 517 79 295 517 85 295 minecraft:brown_terracotta
fill 517 79 299 517 86 299 minecraft:brown_terracotta
fill 517 79 303 517 86 303 minecraft:brown_terracotta
fill 517 79 307 517 85 307 minecraft:brown_terracotta
fill 517 79 311 517 86 311 minecraft:brown_terracotta
fill 517 79 315 517 86 315 minecraft:brown_terracotta
fill 517 79 317 517 84 317 minecraft:brown_terracotta
setblock 518 79 296 minecraft:shroomlight
setblock 518 79 298 minecraft:shroomlight
setblock 518 79 300 minecraft:shroomlight
setblock 518 79 302 minecraft:shroomlight
setblock 518 79 304 minecraft:shroomlight
setblock 518 79 306 minecraft:shroomlight
setblock 519 79 295 minecraft:shroomlight
setblock 519 79 297 minecraft:shroomlight
setblock 519 79 299 minecraft:shroomlight
setblock 519 79 301 minecraft:shroomlight
setblock 519 79 303 minecraft:shroomlight
setblock 519 79 305 minecraft:shroomlight
setblock 519 79 307 minecraft:shroomlight
setblock 520 79 278 minecraft:light[level=12]
setblock 520 79 285 minecraft:light[level=12]
setblock 520 79 292 minecraft:light[level=12]
setblock 520 79 296 minecraft:shroomlight
setblock 520 79 298 minecraft:shroomlight
setblock 520 79 300 minecraft:shroomlight
setblock 520 79 302 minecraft:shroomlight
setblock 520 79 304 minecraft:shroomlight
setblock 520 79 306 minecraft:shroomlight
setblock 520 79 313 minecraft:light[level=12]
fill 521 79 275 521 86 275 minecraft:brown_terracotta
setblock 521 79 295 minecraft:shroomlight
setblock 521 79 297 minecraft:shroomlight
setblock 521 79 299 minecraft:shroomlight
setblock 521 79 301 minecraft:shroomlight
setblock 521 79 303 minecraft:shroomlight
setblock 521 79 305 minecraft:shroomlight
setblock 521 79 307 minecraft:shroomlight
fill 521 79 317 521 86 317 minecraft:brown_terracotta
setblock 522 79 296 minecraft:shroomlight
setblock 522 79 298 minecraft:shroomlight
setblock 522 79 300 minecraft:shroomlight
setblock 522 79 302 minecraft:shroomlight
setblock 522 79 304 minecraft:shroomlight
setblock 522 79 306 minecraft:shroomlight
fill 525 79 275 525 85 275 minecraft:brown_terracotta
fill 525 79 317 525 86 317 minecraft:brown_terracotta
setblock 527 79 278 minecraft:light[level=12]
setblock 527 79 285 minecraft:light[level=12]
setblock 527 79 292 minecraft:light[level=12]
setblock 527 79 299 minecraft:light[level=12]
setblock 527 79 306 minecraft:light[level=12]
setblock 527 79 313 minecraft:light[level=12]
fill 529 79 275 529 86 275 minecraft:brown_terracotta
fill 529 79 317 529 85 317 minecraft:brown_terracotta
setblock 532 79 276 minecraft:shroomlight
setblock 532 79 278 minecraft:shroomlight
setblock 532 79 280 minecraft:shroomlight
fill 533 79 275 533 86 275 minecraft:brown_terracotta
setblock 533 79 277 minecraft:shroomlight
setblock 533 79 279 minecraft:shroomlight
setblock 533 79 281 minecraft:shroomlight
fill 533 79 317 533 86 317 minecraft:brown_terracotta
setblock 534 79 276 minecraft:shroomlight
setblock 534 79 278 minecraft:shroomlight
setblock 534 79 280 minecraft:shroomlight
setblock 534 79 285 minecraft:light[level=12]
setblock 534 79 292 minecraft:light[level=12]
setblock 534 79 299 minecraft:light[level=12]
setblock 534 79 306 minecraft:light[level=12]
setblock 534 79 313 minecraft:light[level=12]
setblock 535 79 277 minecraft:shroomlight
setblock 535 79 279 minecraft:shroomlight
setblock 535 79 281 minecraft:shroomlight
setblock 536 79 276 minecraft:shroomlight
setblock 536 79 278 minecraft:shroomlight
setblock 536 79 280 minecraft:shroomlight
fill 537 79 275 537 85 275 minecraft:brown_terracotta
setblock 537 79 277 minecraft:shroomlight
setblock 537 79 279 minecraft:shroomlight
setblock 537 79 281 minecraft:shroomlight
fill 537 79 317 537 86 317 minecraft:brown_terracotta
setblock 538 79 276 minecraft:shroomlight
setblock 538 79 278 minecraft:shroomlight
setblock 538 79 280 minecraft:shroomlight
setblock 539 79 277 minecraft:shroomlight
setblock 539 79 279 minecraft:shroomlight
setblock 539 79 281 minecraft:shroomlight
setblock 540 79 276 minecraft:shroomlight
setblock 540 79 278 minecraft:shroomlight
setblock 540 79 280 minecraft:shroomlight
fill 541 79 275 541 86 275 minecraft:brown_terracotta
setblock 541 79 278 minecraft:light[level=12]
setblock 541 79 285 minecraft:light[level=12]
setblock 541 79 292 minecraft:light[level=12]
setblock 541 79 299 minecraft:light[level=12]
setblock 541 79 306 minecraft:light[level=12]
setblock 541 79 313 minecraft:light[level=12]
fill 541 79 317 541 85 317 minecraft:brown_terracotta
fill 545 79 275 545 86 275 minecraft:brown_terracotta
fill 545 79 317 545 86 317 minecraft:brown_terracotta
setblock 548 79 278 minecraft:light[level=12]
setblock 548 79 285 minecraft:light[level=12]
setblock 548 79 292 minecraft:light[level=12]
setblock 548 79 299 minecraft:light[level=12]
setblock 548 79 306 minecraft:light[level=12]
setblock 548 79 313 minecraft:light[level=12]
fill 549 79 275 549 85 275 minecraft:brown_terracotta
setblock 549 79 309 minecraft:shroomlight
setblock 549 79 311 minecraft:shroomlight
setblock 549 79 313 minecraft:shroomlight
setblock 549 79 315 minecraft:shroomlight
fill 549 79 317 549 86 317 minecraft:brown_terracotta
setblock 550 79 308 minecraft:shroomlight
setblock 550 79 310 minecraft:shroomlight
setblock 550 79 312 minecraft:shroomlight
setblock 550 79 314 minecraft:shroomlight
setblock 550 79 316 minecraft:shroomlight
setblock 551 79 309 minecraft:shroomlight
setblock 551 79 311 minecraft:shroomlight
setblock 551 79 313 minecraft:shroomlight
setblock 551 79 315 minecraft:shroomlight
setblock 552 79 308 minecraft:shroomlight
setblock 552 79 310 minecraft:shroomlight
setblock 552 79 312 minecraft:shroomlight
setblock 552 79 314 minecraft:shroomlight
setblock 552 79 316 minecraft:shroomlight
fill 553 79 275 553 86 275 minecraft:brown_terracotta
setblock 553 79 309 minecraft:shroomlight
setblock 553 79 311 minecraft:shroomlight
setblock 553 79 313 minecraft:shroomlight
setblock 553 79 315 minecraft:shroomlight
fill 553 79 317 553 85 317 minecraft:brown_terracotta
setblock 554 79 302 minecraft:shroomlight
setblock 554 79 304 minecraft:shroomlight
setblock 554 79 306 minecraft:shroomlight
setblock 554 79 308 minecraft:shroomlight
setblock 554 79 310 minecraft:shroomlight
setblock 554 79 312 minecraft:shroomlight
setblock 554 79 314 minecraft:shroomlight
setblock 554 79 316 minecraft:shroomlight
setblock 555 79 278 minecraft:light[level=12]
setblock 555 79 285 minecraft:light[level=12]
setblock 555 79 292 minecraft:light[level=12]
setblock 555 79 299 minecraft:light[level=12]
setblock 555 79 303 minecraft:shroomlight
setblock 555 79 305 minecraft:shroomlight
setblock 555 79 307 minecraft:shroomlight
setblock 555 79 309 minecraft:shroomlight
setblock 555 79 311 minecraft:shroomlight
setblock 555 79 313 minecraft:shroomlight
setblock 555 79 315 minecraft:shroomlight
setblock 556 79 302 minecraft:shroomlight
setblock 556 79 304 minecraft:shroomlight
setblock 556 79 306 minecraft:shroomlight
setblock 556 79 308 minecraft:shroomlight
setblock 556 79 310 minecraft:shroomlight
setblock 556 79 312 minecraft:shroomlight
setblock 556 79 314 minecraft:shroomlight
setblock 556 79 316 minecraft:shroomlight
fill 557 79 275 557 86 275 minecraft:brown_terracotta
setblock 557 79 303 minecraft:shroomlight
setblock 557 79 305 minecraft:shroomlight
setblock 557 79 307 minecraft:shroomlight
setblock 557 79 309 minecraft:shroomlight
setblock 557 79 311 minecraft:shroomlight
setblock 557 79 313 minecraft:shroomlight
setblock 557 79 315 minecraft:shroomlight
fill 557 79 317 557 86 317 minecraft:brown_terracotta
setblock 558 79 302 minecraft:shroomlight
setblock 558 79 304 minecraft:shroomlight
setblock 558 79 306 minecraft:shroomlight
setblock 558 79 308 minecraft:shroomlight
setblock 558 79 310 minecraft:shroomlight
setblock 558 79 312 minecraft:shroomlight
setblock 558 79 314 minecraft:shroomlight
setblock 558 79 316 minecraft:shroomlight
fill 559 79 275 559 84 275 minecraft:brown_terracotta
fill 559 79 279 559 85 279 minecraft:brown_terracotta
fill 559 79 283 559 86 283 minecraft:brown_terracotta
fill 559 79 287 559 86 287 minecraft:brown_terracotta
fill 559 79 291 559 85 291 minecraft:brown_terracotta
fill 559 79 295 559 86 295 minecraft:brown_terracotta
fill 559 79 299 559 86 299 minecraft:brown_terracotta
fill 559 79 303 559 85 303 minecraft:brown_terracotta
fill 559 79 307 559 86 307 minecraft:brown_terracotta
setblock 559 79 309 minecraft:shroomlight
setblock 559 79 311 minecraft:shroomlight
setblock 559 79 313 minecraft:shroomlight
setblock 559 79 315 minecraft:shroomlight
fill 518 80 296 518 81 296 minecraft:white_concrete
fill 518 80 298 518 139 298 minecraft:white_concrete
fill 518 80 300 518 139 300 minecraft:white_concrete
fill 518 80 302 518 81 302 minecraft:white_concrete
fill 518 80 304 518 81 304 minecraft:white_concrete
fill 518 80 306 518 81 306 minecraft:white_concrete
fill 519 80 285 519 85 287 minecraft:white_concrete
fill 519 80 295 519 81 295 minecraft:white_concrete
fill 519 80 297 519 85 297 minecraft:white_concrete
fill 519 80 299 519 85 299 minecraft:white_concrete
fill 519 80 301 519 81 301 minecraft:white_concrete
fill 519 80 303 519 81 303 minecraft:white_concrete
fill 519 80 305 519 81 305 minecraft:white_concrete
fill 519 80 307 519 81 307 minecraft:white_concrete
fill 519 80 309 519 85 311 minecraft:white_concrete
fill 520 80 296 520 81 296 minecraft:white_concrete
fill 520 80 298 520 81 298 minecraft:white_concrete
fill 520 80 300 520 81 300 minecraft:white_concrete
fill 520 80 302 520 81 302 minecraft:white_concrete
fill 520 80 304 520 81 304 minecraft:white_concrete
fill 520 80 306 520 81 306 minecraft:white_concrete
fill 521 80 295 521 81 295 minecraft:white_concrete
fill 521 80 297 521 81 297 minecraft:white_concrete
fill 521 80 299 521 81 299 minecraft:white_concrete
fill 521 80 301 521 81 301 minecraft:white_concrete
fill 521 80 303 521 81 303 minecraft:white_concrete
fill 521 80 305 521 81 305 minecraft:white_concrete
fill 521 80 307 521 81 307 minecraft:white_concrete
fill 522 80 296 522 81 296 minecraft:white_concrete
fill 522 80 298 522 81 298 minecraft:white_concrete
fill 522 80 300 522 81 300 minecraft:white_concrete
fill 522 80 302 522 81 302 minecraft:white_concrete
fill 522 80 304 522 81 304 minecraft:white_concrete
fill 522 80 306 522 81 306 minecraft:white_concrete
fill 525 80 315 527 85 315 minecraft:white_concrete
fill 529 80 277 531 85 277 minecraft:white_concrete
fill 532 80 276 532 81 276 minecraft:white_concrete
fill 532 80 278 532 81 278 minecraft:white_concrete
fill 532 80 280 532 81 280 minecraft:white_concrete
fill 533 80 277 533 81 277 minecraft:white_concrete
fill 533 80 279 533 81 279 minecraft:white_concrete
fill 533 80 281 533 81 281 minecraft:white_concrete
fill 534 80 276 534 81 276 minecraft:white_concrete
fill 534 80 278 534 81 278 minecraft:white_concrete
fill 534 80 280 534 81 280 minecraft:white_concrete
fill 535 80 277 535 81 277 minecraft:white_concrete
fill 535 80 279 535 81 279 minecraft:white_concrete
fill 535 80 281 535 81 281 minecraft:white_concrete
fill 536 80 276 536 81 276 minecraft:white_concrete
fill 536 80 278 536 81 278 minecraft:white_concrete
fill 536 80 280 536 81 280 minecraft:white_concrete
fill 537 80 277 537 81 277 minecraft:white_concrete
fill 537 80 279 537 81 279 minecraft:white_concrete
fill 537 80 281 537 81 281 minecraft:white_concrete
fill 537 80 315 539 85 315 minecraft:white_concrete
fill 538 80 276 538 81 276 minecraft:white_concrete
fill 538 80 278 538 81 278 minecraft:white_concrete
fill 538 80 280 538 81 280 minecraft:white_concrete
fill 539 80 277 539 81 277 minecraft:white_concrete
fill 539 80 279 539 81 279 minecraft:white_concrete
fill 539 80 281 539 81 281 minecraft:white_concrete
fill 540 80 276 540 81 276 minecraft:white_concrete
fill 540 80 278 540 81 278 minecraft:white_concrete
fill 540 80 280 540 81 280 minecraft:white_concrete
fill 541 80 277 543 85 277 minecraft:white_concrete
fill 545 80 306 546 81 308 minecraft:white_concrete
setblock 549 80 309 minecraft:white_concrete
setblock 549 80 311 minecraft:white_concrete
setblock 549 80 313 minecraft:white_concrete
fill 549 80 315 549 85 315 minecraft:white_concrete
setblock 550 80 308 minecraft:white_concrete
setblock 550 80 310 minecraft:white_concrete
setblock 550 80 312 minecraft:white_concrete
setblock 550 80 314 minecraft:white_concrete
fill 550 80 316 550 139 316 minecraft:white_concrete
setblock 551 80 309 minecraft:white_concrete
setblock 551 80 311 minecraft:white_concrete
setblock 551 80 313 minecraft:white_concrete
fill 551 80 315 551 85 315 minecraft:white_concrete
setblock 552 80 308 minecraft:white_concrete
setblock 552 80 310 minecraft:white_concrete
setblock 552 80 312 minecraft:white_concrete
setblock 552 80 314 minecraft:white_concrete
setblock 552 80 316 minecraft:white_concrete
fill 553 80 277 555 85 277 minecraft:white_concrete
setblock 553 80 309 minecraft:white_concrete
setblock 553 80 311 minecraft:white_concrete
setblock 553 80 313 minecraft:white_concrete
setblock 553 80 315 minecraft:white_concrete
fill 554 80 302 554 81 302 minecraft:white_concrete
fill 554 80 304 554 81 304 minecraft:white_concrete
fill 554 80 306 554 81 306 minecraft:white_concrete
fill 554 80 308 554 81 308 minecraft:white_concrete
fill 554 80 310 554 81 310 minecraft:white_concrete
fill 554 80 312 554 81 312 minecraft:white_concrete
setblock 554 80 314 minecraft:white_concrete
setblock 554 80 316 minecraft:white_concrete
fill 555 80 303 555 81 303 minecraft:white_concrete
fill 555 80 305 555 81 305 minecraft:white_concrete
fill 555 80 307 555 81 307 minecraft:white_concrete
fill 555 80 309 555 81 309 minecraft:white_concrete
fill 555 80 311 555 81 311 minecraft:white_concrete
setblock 555 80 313 minecraft:white_concrete
setblock 555 80 315 minecraft:white_concrete
fill 556 80 302 556 81 302 minecraft:white_concrete
fill 556 80 304 556 81 304 minecraft:white_concrete
fill 556 80 306 556 81 306 minecraft:white_concrete
fill 556 80 308 556 81 308 minecraft:white_concrete
fill 556 80 310 556 81 310 minecraft:white_concrete
fill 556 80 312 556 81 312 minecraft:white_concrete
setblock 556 80 314 minecraft:white_concrete
setblock 556 80 316 minecraft:white_concrete
fill 557 80 285 557 85 287 minecraft:white_concrete
fill 557 80 297 557 85 299 minecraft:white_concrete
fill 557 80 303 557 81 303 minecraft:white_concrete
fill 557 80 305 557 81 305 minecraft:white_concrete
fill 557 80 307 557 81 307 minecraft:white_concrete
fill 557 80 309 557 81 309 minecraft:white_concrete
fill 557 80 311 557 81 311 minecraft:white_concrete
setblock 557 80 313 minecraft:white_concrete
setblock 557 80 315 minecraft:white_concrete
fill 558 80 302 558 81 302 minecraft:white_concrete
fill 558 80 304 558 81 304 minecraft:white_concrete
fill 558 80 306 558 81 306 minecraft:white_concrete
fill 558 80 308 558 81 308 minecraft:white_concrete
fill 558 80 310 558 81 310 minecraft:white_concrete
fill 558 80 312 558 81 312 minecraft:white_concrete
setblock 558 80 314 minecraft:white_concrete
setblock 558 80 316 minecraft:white_concrete
fill 559 80 309 559 84 309 minecraft:brown_terracotta
fill 559 80 311 559 86 311 minecraft:brown_terracotta
fill 559 80 313 559 84 313 minecraft:brown_terracotta
fill 559 80 315 559 85 315 minecraft:brown_terracotta
fill 520 81 312 520 81 314 minecraft:brown_terracotta
setblock 521 81 311 minecraft:brown_terracotta
fill 521 81 315 523 81 315 minecraft:brown_terracotta
fill 523 81 311 524 81 311 minecraft:brown_terracotta
fill 524 81 312 524 81 314 minecraft:brown_terracotta
fill 550 81 309 553 81 314 minecraft:red_concrete
fill 552 81 315 558 81 315 minecraft:red_concrete
fill 554 81 313 558 82 314 minecraft:red_concrete
fill 519 82 296 521 82 296 minecraft:red_concrete
fill 519 82 300 521 82 306 minecraft:red_concrete
fill 520 82 297 521 82 299 minecraft:red_concrete
setblock 532 82 276 minecraft:shroomlight
setblock 532 82 278 minecraft:shroomlight
setblock 532 82 280 minecraft:shroomlight
setblock 533 82 277 minecraft:shroomlight
setblock 533 82 279 minecraft:shroomlight
setblock 533 82 281 minecraft:shroomlight
setblock 534 82 276 minecraft:shroomlight
setblock 534 82 278 minecraft:shroomlight
setblock 534 82 280 minecraft:shroomlight
setblock 535 82 277 minecraft:shroomlight
setblock 535 82 279 minecraft:shroomlight
setblock 535 82 281 minecraft:shroomlight
setblock 536 82 276 minecraft:shroomlight
setblock 536 82 278 minecraft:shroomlight
setblock 536 82 280 minecraft:shroomlight
setblock 537 82 277 minecraft:shroomlight
setblock 537 82 279 minecraft:shroomlight
setblock 537 82 281 minecraft:shroomlight
setblock 538 82 276 minecraft:shroomlight
setblock 538 82 278 minecraft:shroomlight
setblock 538 82 280 minecraft:shroomlight
setblock 539 82 277 minecraft:shroomlight
setblock 539 82 279 minecraft:shroomlight
setblock 539 82 281 minecraft:shroomlight
setblock 540 82 276 minecraft:shroomlight
setblock 540 82 278 minecraft:shroomlight
setblock 540 82 280 minecraft:shroomlight
fill 551 82 310 553 82 314 minecraft:red_concrete
setblock 554 82 302 minecraft:shroomlight
setblock 554 82 304 minecraft:shroomlight
setblock 554 82 306 minecraft:shroomlight
setblock 554 82 308 minecraft:shroomlight
setblock 554 82 310 minecraft:shroomlight
setblock 554 82 312 minecraft:shroomlight
setblock 555 82 303 minecraft:shroomlight
setblock 555 82 305 minecraft:shroomlight
setblock 555 82 307 minecraft:shroomlight
setblock 555 82 309 minecraft:shroomlight
setblock 555 82 311 minecraft:shroomlight
setblock 556 82 302 minecraft:shroomlight
setblock 556 82 304 minecraft:shroomlight
setblock 556 82 306 minecraft:shroomlight
setblock 556 82 308 minecraft:shroomlight
setblock 556 82 310 minecraft:shroomlight
setblock 556 82 312 minecraft:shroomlight
setblock 557 82 303 minecraft:shroomlight
setblock 557 82 305 minecraft:shroomlight
setblock 557 82 307 minecraft:shroomlight
setblock 557 82 309 minecraft:shroomlight
setblock 557 82 311 minecraft:shroomlight
setblock 558 82 302 minecraft:shroomlight
setblock 558 82 304 minecraft:shroomlight
setblock 558 82 306 minecraft:shroomlight
setblock 558 82 308 minecraft:shroomlight
setblock 558 82 310 minecraft:shroomlight
setblock 558 82 312 minecraft:shroomlight
fill 520 83 297 520 83 305 minecraft:red_concrete
fill 532 83 276 532 84 276 minecraft:white_concrete
fill 532 83 278 532 84 278 minecraft:white_concrete
fill 532 83 280 532 84 280 minecraft:white_concrete
fill 533 83 277 533 84 277 minecraft:white_concrete
fill 533 83 279 533 84 279 minecraft:white_concrete
fill 533 83 281 533 84 281 minecraft:white_concrete
fill 534 83 276 534 84 276 minecraft:white_concrete
fill 534 83 278 534 84 278 minecraft:white_concrete
fill 534 83 280 534 84 280 minecraft:white_concrete
fill 535 83 277 535 84 277 minecraft:white_concrete
fill 535 83 279 535 84 279 minecraft:white_concrete
fill 535 83 281 535 84 281 minecraft:white_concrete
fill 536 83 276 536 84 276 minecraft:white_concrete
fill 536 83 278 536 84 278 minecraft:white_concrete
fill 536 83 280 536 84 280 minecraft:white_concrete
fill 537 83 277 537 84 277 minecraft:white_concrete
fill 537 83 279 537 84 279 minecraft:white_concrete
fill 537 83 281 537 84 281 minecraft:white_concrete
fill 538 83 276 538 84 276 minecraft:white_concrete
fill 538 83 278 538 84 278 minecraft:white_concrete
fill 538 83 280 538 84 280 minecraft:white_concrete
fill 539 83 277 539 84 277 minecraft:white_concrete
fill 539 83 279 539 84 279 minecraft:white_concrete
fill 539 83 281 539 84 281 minecraft:white_concrete
fill 540 83 276 540 84 276 minecraft:white_concrete
fill 540 83 278 540 84 278 minecraft:white_concrete
fill 540 83 280 540 84 280 minecraft:white_concrete
fill 550 83 294 552 84 294 minecraft:lime_concrete
fill 551 83 293 551 84 293 minecraft:lime_concrete
fill 551 83 295 551 84 295 minecraft:lime_concrete
fill 552 83 311 553 83 313 minecraft:red_concrete
fill 554 83 302 554 84 302 minecraft:white_concrete
fill 554 83 304 554 84 304 minecraft:white_concrete
fill 554 83 306 554 84 306 minecraft:white_concrete
fill 554 83 308 554 84 308 minecraft:white_concrete
fill 554 83 310 554 84 310 minecraft:white_concrete
fill 554 83 312 554 84 312 minecraft:white_concrete
fill 554 83 313 558 83 313 minecraft:red_concrete
fill 555 83 303 555 84 303 minecraft:white_concrete
fill 555 83 305 555 84 305 minecraft:white_concrete
fill 555 83 307 555 84 307 minecraft:white_concrete
fill 555 83 309 555 84 309 minecraft:white_concrete
fill 555 83 311 555 84 311 minecraft:white_concrete
fill 556 83 302 556 84 302 minecraft:white_concrete
fill 556 83 304 556 84 304 minecraft:white_concrete
fill 556 83 306 556 84 306 minecraft:white_concrete
fill 556 83 308 556 84 308 minecraft:white_concrete
fill 556 83 310 556 84 310 minecraft:white_concrete
fill 556 83 312 556 84 312 minecraft:white_concrete
fill 557 83 303 557 84 303 minecraft:white_concrete
fill 557 83 305 557 84 305 minecraft:white_concrete
fill 557 83 307 557 84 307 minecraft:white_concrete
fill 557 83 309 557 84 309 minecraft:white_concrete
fill 557 83 311 557 84 311 minecraft:white_concrete
fill 558 83 302 558 84 302 minecraft:white_concrete
fill 558 83 304 558 84 304 minecraft:white_concrete
fill 558 83 306 558 84 306 minecraft:white_concrete
fill 558 83 308 558 84 308 minecraft:white_concrete
fill 558 83 310 558 84 310 minecraft:white_concrete
fill 558 83 312 558 84 312 minecraft:white_concrete
fill 519 84 300 521 84 304 minecraft:red_concrete
fill 520 84 298 521 84 299 minecraft:red_concrete
fill 546 84 282 547 85 283 minecraft:lime_concrete
setblock 553 84 312 minecraft:red_concrete
setblock 517 85 277 minecraft:white_concrete
setblock 517 85 281 minecraft:white_concrete
setblock 517 85 285 minecraft:white_concrete
setblock 517 85 289 minecraft:white_concrete
setblock 517 85 293 minecraft:white_concrete
setblock 517 85 297 minecraft:white_concrete
setblock 517 85 301 minecraft:white_concrete
setblock 517 85 305 minecraft:white_concrete
setblock 517 85 309 minecraft:white_concrete
setblock 517 85 313 minecraft:white_concrete
setblock 517 85 317 minecraft:white_concrete
fill 518 85 279 518 85 284 minecraft:brown_terracotta
fill 518 85 291 518 85 296 minecraft:brown_terracotta
fill 518 85 301 522 85 302 minecraft:red_concrete
fill 518 85 303 518 85 308 minecraft:brown_terracotta
fill 518 85 315 518 85 316 minecraft:brown_terracotta
setblock 519 85 275 minecraft:white_concrete
fill 519 85 300 522 85 300 minecraft:red_concrete
fill 519 85 303 522 85 303 minecraft:red_concrete
fill 519 85 316 522 85 316 minecraft:brown_terracotta
setblock 519 85 317 minecraft:white_concrete
setblock 520 85 278 minecraft:light[level=15]
setblock 520 85 285 minecraft:light[level=12]
setblock 520 85 286 minecraft:light[level=15]
setblock 520 85 292 minecraft:light[level=12]
setblock 520 85 294 minecraft:light[level=15]
fill 520 85 299 522 85 299 minecraft:red_concrete
setblock 520 85 306 minecraft:light[level=12]
setblock 520 85 310 minecraft:light[level=15]
setblock 520 85 313 minecraft:light[level=12]
fill 522 85 276 527 85 276 minecraft:brown_terracotta
setblock 523 85 275 minecraft:white_concrete
setblock 523 85 317 minecraft:white_concrete
setblock 527 85 275 minecraft:white_concrete
setblock 527 85 278 minecraft:light[level=12]
setblock 527 85 285 minecraft:light[level=12]
setblock 527 85 292 minecraft:light[level=12]
setblock 527 85 299 minecraft:light[level=12]
setblock 527 85 306 minecraft:light[level=12]
setblock 527 85 313 minecraft:light[level=12]
setblock 527 85 317 minecraft:white_concrete
setblock 528 85 278 minecraft:light[level=15]
setblock 528 85 286 minecraft:light[level=15]
setblock 528 85 294 minecraft:light[level=15]
setblock 528 85 302 minecraft:light[level=15]
setblock 528 85 310 minecraft:light[level=15]
fill 529 85 316 534 85 316 minecraft:brown_terracotta
setblock 531 85 275 minecraft:white_concrete
setblock 531 85 317 minecraft:white_concrete
setblock 532 85 276 minecraft:shroomlight
setblock 532 85 278 minecraft:shroomlight
setblock 532 85 280 minecraft:shroomlight
setblock 533 85 277 minecraft:shroomlight
setblock 533 85 279 minecraft:shroomlight
setblock 533 85 281 minecraft:shroomlight
setblock 534 85 276 minecraft:shroomlight
setblock 534 85 278 minecraft:shroomlight
setblock 534 85 280 minecraft:shroomlight
setblock 534 85 285 minecraft:light[level=12]
setblock 534 85 292 minecraft:light[level=12]
setblock 534 85 299 minecraft:light[level=12]
setblock 534 85 306 minecraft:light[level=12]
setblock 534 85 313 minecraft:light[level=12]
setblock 535 85 275 minecraft:white_concrete
setblock 535 85 276 minecraft:brown_terracotta
setblock 535 85 277 minecraft:shroomlight
setblock 535 85 279 minecraft:shroomlight
setblock 535 85 281 minecraft:shroomlight
setblock 535 85 317 minecraft:white_concrete
setblock 536 85 276 minecraft:shroomlight
setblock 536 85 278 minecraft:shroomlight
setblock 536 85 280 minecraft:shroomlight
setblock 536 85 286 minecraft:light[level=15]
setblock 536 85 294 minecraft:light[level=15]
setblock 536 85 302 minecraft:light[level=15]
setblock 536 85 310 minecraft:light[level=15]
setblock 537 85 276 minecraft:brown_terracotta
setblock 537 85 277 minecraft:shroomlight
setblock 537 85 279 minecraft:shroomlight
setblock 537 85 281 minecraft:shroomlight
setblock 538 85 276 minecraft:shroomlight
setblock 538 85 278 minecraft:shroomlight
setblock 538 85 280 minecraft:shroomlight
setblock 539 85 275 minecraft:white_concrete
setblock 539 85 276 minecraft:brown_terracotta
setblock 539 85 277 minecraft:shroomlight
setblock 539 85 279 minecraft:shroomlight
setblock 539 85 281 minecraft:shroomlight
setblock 539 85 317 minecraft:white_concrete
setblock 540 85 276 minecraft:shroomlight
setblock 540 85 278 minecraft:shroomlight
setblock 540 85 280 minecraft:shroomlight
setblock 541 85 278 minecraft:light[level=12]
setblock 541 85 285 minecraft:light[level=12]
setblock 541 85 292 minecraft:light[level=12]
setblock 541 85 299 minecraft:light[level=12]
setblock 541 85 306 minecraft:light[level=12]
setblock 541 85 313 minecraft:light[level=12]
fill 541 85 316 546 85 316 minecraft:brown_terracotta
setblock 543 85 275 minecraft:white_concrete
setblock 543 85 317 minecraft:white_concrete
setblock 544 85 278 minecraft:light[level=15]
setblock 544 85 286 minecraft:light[level=15]
setblock 544 85 294 minecraft:light[level=15]
setblock 544 85 302 minecraft:light[level=15]
setblock 544 85 310 minecraft:light[level=15]
fill 546 85 276 551 85 276 minecraft:brown_terracotta
setblock 547 85 275 minecraft:white_concrete
setblock 547 85 317 minecraft:white_concrete
setblock 548 85 278 minecraft:light[level=12]
setblock 548 85 285 minecraft:light[level=12]
setblock 548 85 292 minecraft:light[level=12]
setblock 548 85 299 minecraft:light[level=12]
setblock 548 85 306 minecraft:light[level=12]
setblock 548 85 313 minecraft:light[level=12]
setblock 551 85 275 minecraft:white_concrete
setblock 551 85 317 minecraft:white_concrete
setblock 552 85 278 minecraft:light[level=15]
setblock 552 85 286 minecraft:light[level=15]
setblock 552 85 294 minecraft:light[level=15]
setblock 552 85 302 minecraft:light[level=15]
setblock 552 85 310 minecraft:light[level=15]
fill 553 85 316 558 85 316 minecraft:brown_terracotta
setblock 554 85 302 minecraft:shroomlight
setblock 554 85 304 minecraft:shroomlight
setblock 554 85 306 minecraft:shroomlight
setblock 554 85 308 minecraft:shroomlight
setblock 554 85 310 minecraft:shroomlight
setblock 554 85 312 minecraft:shroomlight
setblock 555 85 275 minecraft:white_concrete
setblock 555 85 278 minecraft:light[level=12]
setblock 555 85 285 minecraft:light[level=12]
setblock 555 85 292 minecraft:light[level=12]
setblock 555 85 299 minecraft:light[level=12]
setblock 555 85 303 minecraft:shroomlight
setblock 555 85 305 minecraft:shroomlight
setblock 555 85 307 minecraft:shroomlight
setblock 555 85 309 minecraft:shroomlight
setblock 555 85 311 minecraft:shroomlight
setblock 555 85 313 minecraft:light[level=12]
setblock 555 85 317 minecraft:white_concrete
setblock 556 85 302 minecraft:shroomlight
setblock 556 85 304 minecraft:shroomlight
setblock 556 85 306 minecraft:shroomlight
setblock 556 85 308 minecraft:shroomlight
setblock 556 85 310 minecraft:shroomlight
setblock 556 85 312 minecraft:shroomlight
setblock 557 85 303 minecraft:shroomlight
setblock 557 85 305 minecraft:shroomlight
setblock 557 85 307 minecraft:shroomlight
setblock 557 85 309 minecraft:shroomlight
setblock 557 85 311 minecraft:shroomlight
fill 558 85 276 558 85 281 minecraft:brown_terracotta
fill 558 85 288 558 85 293 minecraft:brown_terracotta
fill 558 85 300 558 85 301 minecraft:brown_terracotta
setblock 558 85 302 minecraft:shroomlight
setblock 558 85 303 minecraft:brown_terracotta
setblock 558 85 304 minecraft:shroomlight
setblock 558 85 305 minecraft:brown_terracotta
setblock 558 85 306 minecraft:shroomlight
setblock 558 85 308 minecraft:shroomlight
setblock 558 85 310 minecraft:shroomlight
setblock 558 85 312 minecraft:shroomlight
fill 558 85 313 558 85 315 minecraft:brown_terracotta
setblock 559 85 275 minecraft:white_concrete
setblock 559 85 277 minecraft:white_concrete
setblock 559 85 281 minecraft:white_concrete
setblock 559 85 285 minecraft:white_concrete
setblock 559 85 289 minecraft:white_concrete
setblock 559 85 293 minecraft:white_concrete
setblock 559 85 297 minecraft:white_concrete
setblock 559 85 301 minecraft:white_concrete
setblock 559 85 305 minecraft:white_concrete
setblock 559 85 309 minecraft:white_concrete
setblock 559 85 313 minecraft:white_concrete
setblock 559 85 317 minecraft:white_concrete
setblock 517 86 276 minecraft:white_concrete
fill 517 86 277 517 93 277 minecraft:brown_terracotta
setblock 517 86 278 minecraft:white_concrete
setblock 517 86 280 minecraft:white_concrete
fill 517 86 281 517 91 284 minecraft:shroomlight
fill 517 86 285 517 93 285 minecraft:brown_terracotta
setblock 517 86 286 minecraft:white_concrete
setblock 517 86 288 minecraft:white_concrete
fill 517 86 289 517 93 289 minecraft:brown_terracotta
setblock 517 86 290 minecraft:white_concrete
setblock 517 86 292 minecraft:white_concrete
fill 517 86 293 517 91 296 minecraft:shroomlight
fill 517 86 297 517 93 297 minecraft:brown_terracotta
setblock 517 86 298 minecraft:white_concrete
setblock 517 86 300 minecraft:white_concrete
fill 517 86 301 517 93 301 minecraft:brown_terracotta
setblock 517 86 302 minecraft:white_concrete
setblock 517 86 304 minecraft:white_concrete
fill 517 86 305 517 91 308 minecraft:shroomlight
fill 517 86 309 517 93 309 minecraft:brown_terracotta
setblock 517 86 310 minecraft:white_concrete
setblock 517 86 312 minecraft:white_concrete
fill 517 86 313 517 93 313 minecraft:brown_terracotta
setblock 517 86 314 minecraft:white_concrete
setblock 517 86 316 minecraft:white_concrete
fill 517 86 317 520 91 317 minecraft:shroomlight
setblock 518 86 275 minecraft:white_concrete
fill 519 86 275 519 93 275 minecraft:brown_terracotta
setblock 520 86 275 minecraft:white_concrete
setblock 522 86 275 minecraft:white_concrete
setblock 522 86 317 minecraft:white_concrete
fill 523 86 275 523 93 275 minecraft:brown_terracotta
fill 523 86 317 523 93 317 minecraft:brown_terracotta
fill 524 86 275 527 91 275 minecraft:shroomlight
setblock 524 86 317 minecraft:white_concrete
setblock 526 86 317 minecraft:white_concrete
fill 527 86 317 527 93 317 minecraft:brown_terracotta
setblock 528 86 275 minecraft:white_concrete
setblock 528 86 317 minecraft:white_concrete
fill 529 86 317 532 91 317 minecraft:shroomlight
setblock 530 86 275 minecraft:white_concrete
fill 531 86 275 531 93 275 minecraft:brown_terracotta
fill 532 86 275 532 86 276 minecraft:white_concrete
fill 532 86 278 532 87 278 minecraft:white_concrete
fill 532 86 280 532 87 280 minecraft:white_concrete
fill 533 86 277 533 87 277 minecraft:white_concrete
fill 533 86 279 533 87 279 minecraft:white_concrete
fill 533 86 281 533 87 281 minecraft:white_concrete
fill 534 86 275 534 86 276 minecraft:white_concrete
fill 534 86 278 534 87 278 minecraft:white_concrete
fill 534 86 280 534 87 280 minecraft:white_concrete
setblock 534 86 317 minecraft:white_concrete
fill 535 86 275 535 93 275 minecraft:brown_terracotta
fill 535 86 276 535 87 277 minecraft:white_concrete
fill 535 86 279 535 87 279 minecraft:white_concrete
fill 535 86 281 535 87 281 minecraft:white_concrete
fill 535 86 317 535 93 317 minecraft:brown_terracotta
fill 536 86 275 539 91 275 minecraft:shroomlight
fill 536 86 276 540 87 276 minecraft:white_concrete
fill 536 86 278 536 87 278 minecraft:white_concrete
fill 536 86 280 536 87 280 minecraft:white_concrete
setblock 536 86 317 minecraft:white_concrete
fill 537 86 277 537 87 277 minecraft:white_concrete
fill 537 86 279 537 87 279 minecraft:white_concrete
fill 537 86 281 537 87 281 minecraft:white_concrete
fill 538 86 278 538 87 278 minecraft:white_concrete
fill 538 86 280 538 87 280 minecraft:white_concrete
setblock 538 86 317 minecraft:white_concrete
fill 539 86 277 539 87 277 minecraft:white_concrete
fill 539 86 279 539 87 279 minecraft:white_concrete
fill 539 86 281 539 87 281 minecraft:white_concrete
fill 539 86 317 539 93 317 minecraft:brown_terracotta
setblock 540 86 275 minecraft:white_concrete
fill 540 86 278 540 87 278 minecraft:white_concrete
fill 540 86 280 540 87 280 minecraft:white_concrete
setblock 540 86 317 minecraft:white_concrete
fill 541 86 317 544 91 317 minecraft:shroomlight
setblock 542 86 275 minecraft:white_concrete
fill 543 86 275 543 93 275 minecraft:brown_terracotta
setblock 544 86 275 minecraft:white_concrete
fill 544 86 311 544 87 311 minecraft:white_concrete
setblock 546 86 275 minecraft:white_concrete
setblock 546 86 317 minecraft:white_concrete
fill 547 86 275 547 93 275 minecraft:brown_terracotta
fill 547 86 317 547 93 317 minecraft:brown_terracotta
fill 548 86 275 551 91 275 minecraft:shroomlight
setblock 548 86 317 minecraft:white_concrete
setblock 550 86 317 minecraft:white_concrete
fill 551 86 317 551 93 317 minecraft:brown_terracotta
setblock 552 86 275 minecraft:white_concrete
setblock 552 86 317 minecraft:white_concrete
fill 553 86 317 556 91 317 minecraft:shroomlight
setblock 554 86 275 minecraft:white_concrete
fill 554 86 302 554 87 302 minecraft:white_concrete
fill 554 86 304 554 87 304 minecraft:white_concrete
fill 554 86 306 554 87 306 minecraft:white_concrete
fill 554 86 308 554 87 308 minecraft:white_concrete
fill 554 86 310 554 87 310 minecraft:white_concrete
fill 554 86 312 554 87 312 minecraft:white_concrete
fill 555 86 275 555 93 275 minecraft:brown_terracotta
fill 555 86 303 555 87 303 minecraft:white_concrete
fill 555 86 305 555 87 305 minecraft:white_concrete
fill 555 86 307 555 87 307 minecraft:white_concrete
fill 555 86 309 555 87 309 minecraft:white_concrete
fill 555 86 311 555 87 311 minecraft:white_concrete
setblock 556 86 275 minecraft:white_concrete
fill 556 86 302 556 87 302 minecraft:white_concrete
fill 556 86 304 556 87 304 minecraft:white_concrete
fill 556 86 306 556 87 306 minecraft:white_concrete
fill 556 86 308 556 87 308 minecraft:white_concrete
fill 556 86 310 556 87 310 minecraft:white_concrete
fill 556 86 312 556 87 312 minecraft:white_concrete
fill 557 86 303 558 87 303 minecraft:white_concrete
fill 557 86 305 558 87 305 minecraft:white_concrete
fill 557 86 307 557 87 307 minecraft:white_concrete
fill 557 86 309 557 87 309 minecraft:white_concrete
fill 557 86 311 557 87 311 minecraft:white_concrete
setblock 558 86 275 minecraft:white_concrete
fill 558 86 302 558 87 302 minecraft:white_concrete
fill 558 86 304 559 86 304 minecraft:white_concrete
fill 558 86 306 559 86 306 minecraft:white_concrete
fill 558 86 308 559 86 308 minecraft:white_concrete
fill 558 86 310 559 86 310 minecraft:white_concrete
fill 558 86 312 558 87 312 minecraft:white_concrete
setblock 558 86 317 minecraft:white_concrete
setblock 559 86 275 minecraft:brown_terracotta
fill 559 86 276 559 91 279 minecraft:shroomlight
setblock 559 86 280 minecraft:white_concrete
fill 559 86 281 559 93 281 minecraft:brown_terracotta
setblock 559 86 282 minecraft:white_concrete
setblock 559 86 284 minecraft:white_concrete
fill 559 86 285 559 93 285 minecraft:brown_terracotta
setblock 559 86 286 minecraft:white_concrete
fill 559 86 288 559 91 291 minecraft:shroomlight
setblock 559 86 292 minecraft:white_concrete
fill 559 86 293 559 93 293 minecraft:brown_terracotta
setblock 559 86 294 minecraft:white_concrete
setblock 559 86 296 minecraft:white_concrete
fill 559 86 297 559 93 297 minecraft:brown_terracotta
setblock 559 86 298 minecraft:white_concrete
fill 559 86 300 559 91 303 minecraft:shroomlight
fill 559 86 305 559 93 305 minecraft:brown_terracotta
fill 559 86 309 559 93 309 minecraft:brown_terracotta
fill 559 86 312 559 91 315 minecraft:shroomlight
setblock 559 86 316 minecraft:white_concrete
fill 559 86 317 559 93 317 minecraft:brown_terracotta
setblock 517 87 275 minecraft:white_concrete
fill 517 87 276 517 94 276 minecraft:brown_terracotta
fill 517 87 278 517 94 278 minecraft:brown_terracotta
setblock 517 87 279 minecraft:white_concrete
fill 517 87 280 517 94 280 minecraft:brown_terracotta
fill 517 87 286 517 94 286 minecraft:brown_terracotta
setblock 517 87 287 minecraft:white_concrete
fill 517 87 288 517 94 288 minecraft:brown_terracotta
fill 517 87 290 517 94 290 minecraft:brown_terracotta
setblock 517 87 291 minecraft:white_concrete
fill 517 87 292 517 94 292 minecraft:brown_terracotta
fill 517 87 298 517 94 298 minecraft:brown_terracotta
setblock 517 87 299 minecraft:white_concrete
fill 517 87 300 517 94 300 minecraft:brown_terracotta
fill 517 87 302 517 94 302 minecraft:brown_terracotta
setblock 517 87 303 minecraft:white_concrete
fill 517 87 304 517 94 304 minecraft:brown_terracotta
fill 517 87 310 517 94 310 minecraft:brown_terracotta
setblock 517 87 311 minecraft:white_concrete
fill 517 87 312 517 94 312 minecraft:brown_terracotta
fill 517 87 314 517 94 314 minecraft:brown_terracotta
setblock 517 87 315 minecraft:white_concrete
fill 517 87 316 517 94 316 minecraft:brown_terracotta
fill 518 87 275 518 94 275 minecraft:brown_terracotta
fill 520 87 275 520 94 275 minecraft:brown_terracotta
setblock 521 87 275 minecraft:white_concrete
setblock 521 87 317 minecraft:white_concrete
fill 522 87 275 522 94 275 minecraft:brown_terracotta
fill 522 87 317 522 94 317 minecraft:brown_terracotta
fill 524 87 317 524 94 317 minecraft:brown_terracotta
setblock 525 87 317 minecraft:white_concrete
fill 526 87 317 526 94 317 minecraft:brown_terracotta
fill 528 87 275 528 94 275 minecraft:brown_terracotta
fill 528 87 317 528 94 317 minecraft:brown_terracotta
setblock 529 87 275 minecraft:white_concrete
fill 530 87 275 530 94 275 minecraft:brown_terracotta
fill 532 87 275 532 94 275 minecraft:brown_terracotta
fill 532 87 276 532 139 276 minecraft:white_concrete
setblock 533 87 275 minecraft:white_concrete
setblock 533 87 317 minecraft:white_concrete
fill 534 87 275 534 94 275 minecraft:brown_terracotta
setblock 534 87 276 minecraft:white_concrete
fill 534 87 317 534 94 317 minecraft:brown_terracotta
fill 536 87 317 536 94 317 minecraft:brown_terracotta
setblock 537 87 317 minecraft:white_concrete
fill 538 87 317 538 94 317 minecraft:brown_terracotta
fill 540 87 275 540 94 275 minecraft:brown_terracotta
fill 540 87 317 540 94 317 minecraft:brown_terracotta
setblock 541 87 275 minecraft:white_concrete
fill 542 87 275 542 94 275 minecraft:brown_terracotta
fill 544 87 275 544 94 275 minecraft:brown_terracotta
setblock 545 87 275 minecraft:white_concrete
setblock 545 87 317 minecraft:white_concrete
fill 546 87 275 546 94 275 minecraft:brown_terracotta
fill 546 87 317 546 94 317 minecraft:brown_terracotta
fill 548 87 317 548 94 317 minecraft:brown_terracotta
setblock 549 87 317 minecraft:white_concrete
fill 550 87 317 550 94 317 minecraft:brown_terracotta
fill 552 87 275 552 94 275 minecraft:brown_terracotta
fill 552 87 317 552 94 317 minecraft:brown_terracotta
setblock 553 87 275 minecraft:white_concrete
fill 554 87 275 554 94 275 minecraft:brown_terracotta
fill 556 87 275 556 94 275 minecraft:brown_terracotta
setblock 557 87 275 minecraft:white_concrete
setblock 557 87 317 minecraft:white_concrete
fill 558 87 275 558 94 275 minecraft:brown_terracotta
setblock 558 87 304 minecraft:white_concrete
setblock 558 87 306 minecraft:white_concrete
setblock 558 87 308 minecraft:white_concrete
setblock 558 87 310 minecraft:white_concrete
fill 558 87 317 558 94 317 minecraft:brown_terracotta
setblock 559 87 275 minecraft:white_concrete
fill 559 87 280 559 94 280 minecraft:brown_terracotta
fill 559 87 282 559 94 282 minecraft:brown_terracotta
setblock 559 87 283 minecraft:white_concrete
fill 559 87 284 559 94 284 minecraft:brown_terracotta
fill 559 87 286 559 94 286 minecraft:brown_terracotta
setblock 559 87 287 minecraft:white_concrete
fill 559 87 292 559 94 292 minecraft:brown_terracotta
fill 559 87 294 559 94 294 minecraft:brown_terracotta
setblock 559 87 295 minecraft:white_concrete
fill 559 87 296 559 94 296 minecraft:brown_terracotta
fill 559 87 298 559 94 298 minecraft:brown_terracotta
setblock 559 87 299 minecraft:white_concrete
fill 559 87 304 559 94 304 minecraft:brown_terracotta
fill 559 87 306 559 94 306 minecraft:brown_terracotta
setblock 559 87 307 minecraft:white_concrete
fill 559 87 308 559 94 308 minecraft:brown_terracotta
fill 559 87 310 559 94 310 minecraft:brown_terracotta
setblock 559 87 311 minecraft:white_concrete
fill 559 87 316 559 94 316 minecraft:brown_terracotta
fill 517 88 275 517 95 275 minecraft:brown_terracotta
fill 517 88 279 517 95 279 minecraft:brown_terracotta
fill 517 88 287 517 95 287 minecraft:brown_terracotta
fill 517 88 291 517 95 291 minecraft:brown_terracotta
fill 517 88 299 517 95 299 minecraft:brown_terracotta
fill 517 88 303 517 95 303 minecraft:brown_terracotta
fill 517 88 311 517 95 311 minecraft:brown_terracotta
fill 517 88 315 517 95 315 minecraft:brown_terracotta
fill 521 88 275 521 95 275 minecraft:brown_terracotta
fill 521 88 317 521 95 317 minecraft:brown_terracotta
fill 525 88 317 525 95 317 minecraft:brown_terracotta
fill 529 88 275 529 95 275 minecraft:brown_terracotta
fill 533 88 275 533 95 275 minecraft:brown_terracotta
fill 533 88 277 539 88 280 minecraft:red_concrete
fill 533 88 317 533 95 317 minecraft:brown_terracotta
fill 537 88 317 537 95 317 minecraft:brown_terracotta
fill 541 88 275 541 95 275 minecraft:brown_terracotta
fill 545 88 275 545 95 275 minecraft:brown_terracotta
fill 545 88 317 545 95 317 minecraft:brown_terracotta
fill 549 88 317 549 95 317 minecraft:brown_terracotta
fill 553 88 275 553 95 275 minecraft:brown_terracotta
setblock 554 88 302 minecraft:shroomlight
setblock 554 88 304 minecraft:shroomlight
setblock 554 88 306 minecraft:shroomlight
setblock 554 88 308 minecraft:shroomlight
setblock 554 88 310 minecraft:shroomlight
setblock 554 88 312 minecraft:shroomlight
setblock 555 88 303 minecraft:shroomlight
setblock 555 88 305 minecraft:shroomlight
setblock 555 88 307 minecraft:shroomlight
setblock 555 88 309 minecraft:shroomlight
setblock 555 88 311 minecraft:shroomlight
setblock 556 88 302 minecraft:shroomlight
setblock 556 88 304 minecraft:shroomlight
setblock 556 88 306 minecraft:shroomlight
setblock 556 88 308 minecraft:shroomlight
setblock 556 88 310 minecraft:shroomlight
setblock 556 88 312 minecraft:shroomlight
fill 557 88 275 557 95 275 minecraft:brown_terracotta
setblock 557 88 303 minecraft:shroomlight
setblock 557 88 305 minecraft:shroomlight
setblock 557 88 307 minecraft:shroomlight
setblock 557 88 309 minecraft:shroomlight
setblock 557 88 311 minecraft:shroomlight
fill 557 88 317 557 95 317 minecraft:brown_terracotta
setblock 558 88 302 minecraft:shroomlight
fill 558 88 303 558 91 303 minecraft:white_concrete
setblock 558 88 304 minecraft:shroomlight
fill 558 88 305 558 91 305 minecraft:white_concrete
setblock 558 88 306 minecraft:shroomlight
setblock 558 88 308 minecraft:shroomlight
setblock 558 88 310 minecraft:shroomlight
setblock 558 88 312 minecraft:shroomlight
fill 559 88 275 559 93 275 minecraft:brown_terracotta
fill 559 88 283 559 95 283 minecraft:brown_terracotta
fill 559 88 287 559 95 287 minecraft:brown_terracotta
fill 559 88 295 559 95 295 minecraft:brown_terracotta
fill 559 88 299 559 95 299 minecraft:brown_terracotta
fill 559 88 307 559 95 307 minecraft:brown_terracotta
fill 559 88 311 559 95 311 minecraft:brown_terracotta
fill 520 89 312 520 89 314 minecraft:brown_terracotta
setblock 521 89 311 minecraft:brown_terracotta
fill 521 89 315 523 89 315 minecraft:brown_terracotta
fill 523 89 311 524 89 311 minecraft:brown_terracotta
fill 524 89 312 524 89 314 minecraft:brown_terracotta
fill 534 89 278 538 89 279 minecraft:red_concrete
fill 554 89 302 554 91 302 minecraft:white_concrete
fill 554 89 304 554 91 304 minecraft:white_concrete
fill 554 89 306 554 91 306 minecraft:white_concrete
fill 554 89 308 554 91 308 minecraft:white_concrete
fill 554 89 310 554 91 310 minecraft:white_concrete
fill 554 89 312 554 91 312 minecraft:white_concrete
fill 555 89 303 555 91 303 minecraft:white_concrete
fill 555 89 305 555 91 305 minecraft:white_concrete
fill 555 89 307 555 91 307 minecraft:white_concrete
fill 555 89 309 555 91 309 minecraft:white_concrete
fill 555 89 311 555 91 311 minecraft:white_concrete
fill 556 89 302 556 91 302 minecraft:white_concrete
fill 556 89 304 556 91 304 minecraft:white_concrete
fill 556 89 306 556 91 306 minecraft:white_concrete
fill 556 89 308 556 91 308 minecraft:white_concrete
fill 556 89 310 556 91 310 minecraft:white_concrete
fill 556 89 312 556 91 312 minecraft:white_concrete
fill 557 89 303 557 91 303 minecraft:white_concrete
fill 557 89 305 557 91 305 minecraft:white_concrete
fill 557 89 307 557 91 307 minecraft:white_concrete
fill 557 89 309 557 91 309 minecraft:white_concrete
fill 557 89 311 557 91 311 minecraft:white_concrete
fill 558 89 302 558 91 302 minecraft:white_concrete
fill 558 89 304 558 91 304 minecraft:white_concrete
fill 558 89 306 558 91 306 minecraft:white_concrete
fill 558 89 308 558 139 308 minecraft:white_concrete
fill 558 89 310 558 139 310 minecraft:white_concrete
fill 558 89 312 558 91 312 minecraft:white_concrete
fill 531 90 303 531 91 303 minecraft:lime_concrete
fill 535 90 278 537 90 279 minecraft:red_concrete
fill 537 90 306 537 91 307 minecraft:red_concrete
fill 547 90 298 547 91 299 minecraft:white_concrete
setblock 520 91 278 minecraft:light[level=12]
setblock 520 91 285 minecraft:light[level=12]
setblock 520 91 292 minecraft:light[level=12]
setblock 520 91 299 minecraft:light[level=12]
setblock 520 91 306 minecraft:light[level=12]
setblock 520 91 313 minecraft:light[level=12]
setblock 527 91 278 minecraft:light[level=12]
setblock 527 91 285 minecraft:light[level=12]
setblock 527 91 292 minecraft:light[level=12]
setblock 527 91 299 minecraft:light[level=12]
setblock 527 91 306 minecraft:light[level=12]
setblock 527 91 313 minecraft:light[level=12]
setblock 534 91 278 minecraft:light[level=12]
setblock 534 91 285 minecraft:light[level=12]
setblock 534 91 292 minecraft:light[level=12]
setblock 534 91 299 minecraft:light[level=12]
setblock 534 91 306 minecraft:light[level=12]
setblock 534 91 313 minecraft:light[level=12]
fill 536 91 277 536 91 280 minecraft:red_concrete
setblock 541 91 278 minecraft:light[level=12]
setblock 541 91 285 minecraft:light[level=12]
setblock 541 91 292 minecraft:light[level=12]
setblock 541 91 299 minecraft:light[level=12]
setblock 541 91 306 minecraft:light[level=12]
setblock 541 91 313 minecraft:light[level=12]
setblock 548 91 278 minecraft:light[level=12]
setblock 548 91 285 minecraft:light[level=12]
setblock 548 91 292 minecraft:light[level=12]
setblock 548 91 299 minecraft:light[level=12]
setblock 548 91 306 minecraft:light[level=12]
setblock 548 91 313 minecraft:light[level=12]
setblock 555 91 278 minecraft:light[level=12]
setblock 555 91 285 minecraft:light[level=12]
setblock 555 91 292 minecraft:light[level=12]
setblock 555 91 299 minecraft:light[level=12]
setblock 555 91 313 minecraft:light[level=12]
fill 517 92 281 517 93 281 minecraft:brown_terracotta
fill 517 92 282 517 92 283 minecraft:shroomlight
fill 517 92 284 517 94 284 minecraft:brown_terracotta
fill 517 92 293 517 93 293 minecraft:brown_terracotta
fill 517 92 294 517 92 295 minecraft:shroomlight
fill 517 92 296 517 94 296 minecraft:brown_terracotta
fill 517 92 305 517 93 305 minecraft:brown_terracotta
fill 517 92 306 517 92 307 minecraft:shroomlight
fill 517 92 308 517 94 308 minecraft:brown_terracotta
fill 517 92 317 517 93 317 minecraft:brown_terracotta
fill 518 92 317 519 92 317 minecraft:shroomlight
fill 520 92 317 520 94 317 minecraft:brown_terracotta
fill 524 92 275 524 94 275 minecraft:brown_terracotta
fill 525 92 275 526 92 275 minecraft:shroomlight
fill 527 92 275 527 93 275 minecraft:brown_terracotta
fill 529 92 317 529 95 317 minecraft:brown_terracotta
fill 530 92 317 531 92 317 minecraft:shroomlight
fill 532 92 317 532 94 317 minecraft:brown_terracotta
fill 536 92 275 536 94 275 minecraft:brown_terracotta
fill 537 92 275 538 92 275 minecraft:shroomlight
fill 539 92 275 539 93 275 minecraft:brown_terracotta
fill 541 92 317 541 95 317 minecraft:brown_terracotta
fill 542 92 317 543 92 317 minecraft:shroomlight
fill 544 92 317 544 94 317 minecraft:brown_terracotta
fill 548 92 275 548 94 275 minecraft:brown_terracotta
fill 549 92 275 550 92 275 minecraft:shroomlight
fill 551 92 275 551 93 275 minecraft:brown_terracotta
fill 553 92 317 553 95 317 minecraft:brown_terracotta
fill 554 92 317 555 92 317 minecraft:shroomlight
fill 555 92 303 557 92 311 minecraft:red_concrete
fill 556 92 312 556 93 312 minecraft:red_wool
fill 556 92 317 556 94 317 minecraft:brown_terracotta
fill 559 92 276 559 94 276 minecraft:brown_terracotta
fill 559 92 277 559 92 278 minecraft:shroomlight
fill 559 92 279 559 95 279 minecraft:brown_terracotta
fill 559 92 288 559 94 288 minecraft:brown_terracotta
fill 559 92 289 559 92 290 minecraft:shroomlight
fill 559 92 291 559 95 291 minecraft:brown_terracotta
fill 559 92 300 559 94 300 minecraft:brown_terracotta
fill 559 92 301 559 92 302 minecraft:shroomlight
fill 559 92 303 559 95 303 minecraft:brown_terracotta
fill 559 92 312 559 94 312 minecraft:brown_terracotta
fill 559 92 313 559 92 314 minecraft:shroomlight
fill 559 92 315 559 95 315 minecraft:brown_terracotta
fill 517 93 282 517 94 283 minecraft:brown_terracotta
fill 517 93 294 517 94 295 minecraft:brown_terracotta
fill 517 93 306 517 94 307 minecraft:brown_terracotta
fill 518 93 317 519 93 317 minecraft:brown_terracotta
setblock 520 93 278 minecraft:light[level=15]
setblock 520 93 286 minecraft:light[level=15]
setblock 520 93 294 minecraft:light[level=15]
setblock 520 93 302 minecraft:light[level=15]
setblock 520 93 310 minecraft:light[level=15]
fill 525 93 275 526 94 275 minecraft:brown_terracotta
setblock 528 93 278 minecraft:light[level=15]
setblock 528 93 286 minecraft:light[level=15]
setblock 528 93 294 minecraft:light[level=15]
setblock 528 93 302 minecraft:light[level=15]
setblock 528 93 310 minecraft:light[level=15]
fill 530 93 317 531 93 317 minecraft:brown_terracotta
setblock 536 93 278 minecraft:light[level=15]
setblock 536 93 286 minecraft:light[level=15]
setblock 536 93 294 minecraft:light[level=15]
setblock 536 93 302 minecraft:light[level=15]
setblock 536 93 310 minecraft:light[level=15]
fill 537 93 275 538 94 275 minecraft:brown_terracotta
fill 542 93 317 543 93 317 minecraft:brown_terracotta
setblock 544 93 278 minecraft:light[level=15]
setblock 544 93 286 minecraft:light[level=15]
setblock 544 93 294 minecraft:light[level=15]
setblock 544 93 302 minecraft:light[level=15]
setblock 544 93 310 minecraft:light[level=15]
fill 549 93 275 550 94 275 minecraft:brown_terracotta
setblock 552 93 278 minecraft:light[level=15]
setblock 552 93 286 minecraft:light[level=15]
setblock 552 93 294 minecraft:light[level=15]
setblock 552 93 302 minecraft:light[level=15]
setblock 552 93 310 minecraft:light[level=15]
fill 554 93 317 555 93 317 minecraft:brown_terracotta
fill 556 93 304 556 93 310 minecraft:red_concrete
setblock 556 93 311 minecraft:red_wool
fill 559 93 277 559 93 278 minecraft:brown_terracotta
fill 559 93 289 559 93 290 minecraft:brown_terracotta
fill 559 93 301 559 93 302 minecraft:brown_terracotta
fill 559 93 313 559 93 314 minecraft:brown_terracotta
setblock 517 94 277 minecraft:white_concrete
setblock 517 94 281 minecraft:white_concrete
setblock 517 94 285 minecraft:white_concrete
setblock 517 94 289 minecraft:white_concrete
setblock 517 94 293 minecraft:white_concrete
setblock 517 94 297 minecraft:white_concrete
setblock 517 94 301 minecraft:white_concrete
setblock 517 94 305 minecraft:white_concrete
setblock 517 94 309 minecraft:white_concrete
setblock 517 94 313 minecraft:white_concrete
setblock 517 94 317 minecraft:white_concrete
setblock 518 94 317 minecraft:brown_terracotta
setblock 519 94 275 minecraft:white_concrete
setblock 519 94 317 minecraft:white_concrete
setblock 523 94 275 minecraft:white_concrete
setblock 523 94 317 minecraft:white_concrete
setblock 527 94 275 minecraft:white_concrete
setblock 527 94 317 minecraft:white_concrete
setblock 530 94 317 minecraft:brown_terracotta
setblock 531 94 275 minecraft:white_concrete
setblock 531 94 317 minecraft:white_concrete
setblock 535 94 275 minecraft:white_concrete
setblock 535 94 317 minecraft:white_concrete
setblock 539 94 275 minecraft:white_concrete
setblock 539 94 317 minecraft:white_concrete
setblock 542 94 317 minecraft:brown_terracotta
setblock 543 94 275 minecraft:white_concrete
setblock 543 94 317 minecraft:white_concrete
setblock 547 94 275 minecraft:white_concrete
setblock 547 94 317 minecraft:white_concrete
setblock 551 94 275 minecraft:white_concrete
setblock 551 94 317 minecraft:white_concrete
setblock 554 94 317 minecraft:brown_terracotta
setblock 555 94 275 minecraft:white_concrete
fill 555 94 305 557 94 309 minecraft:red_concrete
setblock 555 94 317 minecraft:white_concrete
fill 556 94 310 556 95 313 minecraft:iron_block
setblock 559 94 275 minecraft:white_concrete
setblock 559 94 277 minecraft:white_concrete
setblock 559 94 278 minecraft:brown_terracotta
setblock 559 94 281 minecraft:white_concrete
setblock 559 94 285 minecraft:white_concrete
setblock 559 94 289 minecraft:white_concrete
setblock 559 94 290 minecraft:brown_terracotta
setblock 559 94 293 minecraft:white_concrete
setblock 559 94 297 minecraft:white_concrete
setblock 559 94 301 minecraft:white_concrete
setblock 559 94 302 minecraft:brown_terracotta
setblock 559 94 305 minecraft:white_concrete
setblock 559 94 309 minecraft:white_concrete
setblock 559 94 313 minecraft:white_concrete
setblock 559 94 314 minecraft:brown_terracotta
setblock 559 94 317 minecraft:white_concrete
setblock 517 95 276 minecraft:white_concrete
fill 517 95 277 517 102 277 minecraft:brown_terracotta
setblock 517 95 278 minecraft:white_concrete
setblock 517 95 280 minecraft:white_concrete
fill 517 95 281 517 102 281 minecraft:brown_terracotta
setblock 517 95 282 minecraft:white_concrete
setblock 517 95 283 minecraft:brown_terracotta
setblock 517 95 284 minecraft:white_concrete
fill 517 95 285 517 102 285 minecraft:brown_terracotta
setblock 517 95 286 minecraft:white_concrete
setblock 517 95 288 minecraft:white_concrete
fill 517 95 289 517 102 289 minecraft:brown_terracotta
setblock 517 95 290 minecraft:white_concrete
setblock 517 95 292 minecraft:white_concrete
fill 517 95 293 517 102 293 minecraft:brown_terracotta
setblock 517 95 294 minecraft:white_concrete
setblock 517 95 295 minecraft:brown_terracotta
setblock 517 95 296 minecraft:white_concrete
fill 517 95 297 517 102 297 minecraft:brown_terracotta
setblock 517 95 298 minecraft:white_concrete
setblock 517 95 300 minecraft:white_concrete
fill 517 95 301 517 102 301 minecraft:brown_terracotta
setblock 517 95 302 minecraft:white_concrete
setblock 517 95 304 minecraft:white_concrete
fill 517 95 305 517 102 305 minecraft:brown_terracotta
setblock 517 95 306 minecraft:white_concrete
setblock 517 95 307 minecraft:brown_terracotta
setblock 517 95 308 minecraft:white_concrete
fill 517 95 309 517 102 309 minecraft:brown_terracotta
setblock 517 95 310 minecraft:white_concrete
setblock 517 95 312 minecraft:white_concrete
fill 517 95 313 517 102 313 minecraft:brown_terracotta
setblock 517 95 314 minecraft:white_concrete
setblock 517 95 316 minecraft:white_concrete
setblock 517 95 317 minecraft:brown_terracotta
setblock 518 95 275 minecraft:white_concrete
setblock 518 95 317 minecraft:white_concrete
fill 519 95 275 519 102 275 minecraft:brown_terracotta
fill 519 95 317 519 102 317 minecraft:brown_terracotta
setblock 520 95 275 minecraft:white_concrete
setblock 520 95 317 minecraft:white_concrete
setblock 522 95 275 minecraft:white_concrete
setblock 522 95 317 minecraft:white_concrete
fill 523 95 275 523 102 275 minecraft:brown_terracotta
fill 523 95 317 523 102 317 minecraft:brown_terracotta
setblock 524 95 275 minecraft:white_concrete
setblock 524 95 317 minecraft:white_concrete
setblock 525 95 275 minecraft:brown_terracotta
setblock 526 95 275 minecraft:white_concrete
setblock 526 95 317 minecraft:white_concrete
fill 527 95 275 527 102 275 minecraft:brown_terracotta
fill 527 95 317 527 102 317 minecraft:brown_terracotta
setblock 528 95 275 minecraft:white_concrete
setblock 528 95 317 minecraft:white_concrete
setblock 530 95 275 minecraft:white_concrete
setblock 530 95 317 minecraft:white_concrete
fill 531 95 275 531 102 275 minecraft:brown_terracotta
fill 531 95 317 531 102 317 minecraft:brown_terracotta
setblock 532 95 275 minecraft:white_concrete
setblock 532 95 317 minecraft:white_concrete
setblock 534 95 275 minecraft:white_concrete
setblock 534 95 317 minecraft:white_concrete
fill 535 95 275 535 102 275 minecraft:brown_terracotta
fill 535 95 317 535 102 317 minecraft:brown_terracotta
setblock 536 95 275 minecraft:white_concrete
setblock 536 95 317 minecraft:white_concrete
setblock 537 95 275 minecraft:brown_terracotta
setblock 538 95 275 minecraft:white_concrete
setblock 538 95 317 minecraft:white_concrete
fill 539 95 275 539 102 275 minecraft:brown_terracotta
fill 539 95 317 539 102 317 minecraft:brown_terracotta
setblock 540 95 275 minecraft:white_concrete
setblock 540 95 317 minecraft:white_concrete
setblock 542 95 275 minecraft:white_concrete
setblock 542 95 317 minecraft:white_concrete
fill 543 95 275 543 102 275 minecraft:brown_terracotta
fill 543 95 317 543 102 317 minecraft:brown_terracotta
setblock 544 95 275 minecraft:white_concrete
setblock 544 95 317 minecraft:white_concrete
setblock 546 95 275 minecraft:white_concrete
setblock 546 95 317 minecraft:white_concrete
fill 547 95 275 547 102 275 minecraft:brown_terracotta
fill 547 95 317 547 102 317 minecraft:brown_terracotta
setblock 548 95 275 minecraft:white_concrete
setblock 548 95 317 minecraft:white_concrete
setblock 549 95 275 minecraft:brown_terracotta
setblock 550 95 275 minecraft:white_concrete
setblock 550 95 317 minecraft:white_concrete
fill 551 95 275 551 102 275 minecraft:brown_terracotta
fill 551 95 297 555 108 299 minecraft:red_concrete
fill 551 95 317 551 102 317 minecraft:brown_terracotta
setblock 552 95 275 minecraft:white_concrete
fill 552 95 296 554 108 296 minecraft:red_concrete
fill 552 95 300 554 108 300 minecraft:red_concrete
setblock 552 95 317 minecraft:white_concrete
setblock 554 95 275 minecraft:white_concrete
fill 554 95 306 557 95 308 minecraft:red_concrete
setblock 554 95 317 minecraft:white_concrete
fill 555 95 275 555 102 275 minecraft:brown_terracotta
fill 555 95 317 555 102 317 minecraft:brown_terracotta
setblock 556 95 275 minecraft:white_concrete
setblock 556 95 309 minecraft:iron_block
setblock 556 95 317 minecraft:white_concrete
setblock 558 95 275 minecraft:white_concrete
fill 558 95 306 558 95 307 minecraft:red_concrete
setblock 558 95 317 minecraft:white_concrete
setblock 559 95 275 minecraft:brown_terracotta
setblock 559 95 276 minecraft:white_concrete
fill 559 95 277 559 102 277 minecraft:brown_terracotta
setblock 559 95 278 minecraft:white_concrete
setblock 559 95 280 minecraft:white_concrete
fill 559 95 281 559 102 281 minecraft:brown_terracotta
setblock 559 95 282 minecraft:white_concrete
setblock 559 95 284 minecraft:white_concrete
fill 559 95 285 559 102 285 minecraft:brown_terracotta
setblock 559 95 286 minecraft:white_concrete
setblock 559 95 288 minecraft:white_concrete
fill 559 95 289 559 102 289 minecraft:brown_terracotta
setblock 559 95 290 minecraft:white_concrete
setblock 559 95 292 minecraft:white_concrete
fill 559 95 293 559 102 293 minecraft:brown_terracotta
setblock 559 95 294 minecraft:white_concrete
setblock 559 95 296 minecraft:white_concrete
fill 559 95 297 559 102 297 minecraft:brown_terracotta
setblock 559 95 298 minecraft:white_concrete
setblock 559 95 300 minecraft:white_concrete
fill 559 95 301 559 102 301 minecraft:brown_terracotta
setblock 559 95 302 minecraft:white_concrete
setblock 559 95 304 minecraft:white_concrete
fill 559 95 305 559 102 305 minecraft:brown_terracotta
setblock 559 95 306 minecraft:white_concrete
setblock 559 95 308 minecraft:white_concrete
fill 559 95 309 559 102 309 minecraft:brown_terracotta
setblock 559 95 310 minecraft:white_concrete
setblock 559 95 312 minecraft:white_concrete
fill 559 95 313 559 102 313 minecraft:brown_terracotta
setblock 559 95 314 minecraft:white_concrete
setblock 559 95 316 minecraft:white_concrete
fill 559 95 317 559 102 317 minecraft:brown_terracotta
setblock 517 96 275 minecraft:white_concrete
fill 517 96 276 517 103 276 minecraft:brown_terracotta
fill 517 96 278 517 103 278 minecraft:brown_terracotta
setblock 517 96 279 minecraft:white_concrete
fill 517 96 280 517 103 280 minecraft:brown_terracotta
fill 517 96 282 517 103 282 minecraft:brown_terracotta
setblock 517 96 283 minecraft:white_concrete
fill 517 96 284 517 103 284 minecraft:brown_terracotta
fill 517 96 286 517 103 286 minecraft:brown_terracotta
setblock 517 96 287 minecraft:white_concrete
fill 517 96 288 517 103 288 minecraft:brown_terracotta
fill 517 96 290 517 103 290 minecraft:brown_terracotta
setblock 517 96 291 minecraft:white_concrete
fill 517 96 292 517 103 292 minecraft:brown_terracotta
fill 517 96 294 517 103 294 minecraft:brown_terracotta
setblock 517 96 295 minecraft:white_concrete
fill 517 96 296 517 103 296 minecraft:brown_terracotta
fill 517 96 298 517 103 298 minecraft:brown_terracotta
setblock 517 96 299 minecraft:white_concrete
fill 517 96 300 517 103 300 minecraft:brown_terracotta
fill 517 96 302 517 103 302 minecraft:brown_terracotta
setblock 517 96 303 minecraft:white_concrete
fill 517 96 304 517 103 304 minecraft:brown_terracotta
fill 517 96 306 517 103 306 minecraft:brown_terracotta
setblock 517 96 307 minecraft:white_concrete
fill 517 96 308 517 103 308 minecraft:brown_terracotta
fill 517 96 310 517 103 310 minecraft:brown_terracotta
setblock 517 96 311 minecraft:white_concrete
fill 517 96 312 517 103 312 minecraft:brown_terracotta
fill 517 96 314 517 103 314 minecraft:brown_terracotta
setblock 517 96 315 minecraft:white_concrete
fill 517 96 316 517 103 316 minecraft:brown_terracotta
setblock 517 96 317 minecraft:white_concrete
fill 518 96 275 518 103 275 minecraft:brown_terracotta
fill 518 96 317 518 103 317 minecraft:brown_terracotta
fill 520 96 275 520 103 275 minecraft:brown_terracotta
fill 520 96 317 520 103 317 minecraft:brown_terracotta
setblock 521 96 275 minecraft:white_concrete
setblock 521 96 317 minecraft:white_concrete
fill 522 96 275 522 103 275 minecraft:brown_terracotta
fill 522 96 317 522 103 317 minecraft:brown_terracotta
fill 524 96 275 524 103 275 minecraft:brown_terracotta
fill 524 96 317 524 103 317 minecraft:brown_terracotta
setblock 525 96 275 minecraft:white_concrete
setblock 525 96 317 minecraft:white_concrete
fill 526 96 275 526 103 275 minecraft:brown_terracotta
fill 526 96 317 526 103 317 minecraft:brown_terracotta
fill 528 96 275 528 103 275 minecraft:brown_terracotta
fill 528 96 317 528 103 317 minecraft:brown_terracotta
setblock 529 96 275 minecraft:white_concrete
setblock 529 96 317 minecraft:white_concrete
fill 530 96 275 530 103 275 minecraft:brown_terracotta
fill 530 96 317 530 103 317 minecraft:brown_terracotta
fill 532 96 275 532 103 275 minecraft:brown_terracotta
fill 532 96 317 532 103 317 minecraft:brown_terracotta
setblock 533 96 275 minecraft:white_concrete
setblock 533 96 317 minecraft:white_concrete
fill 534 96 275 534 103 275 minecraft:brown_terracotta
fill 534 96 317 534 103 317 minecraft:brown_terracotta
fill 536 96 275 536 103 275 minecraft:brown_terracotta
fill 536 96 317 536 103 317 minecraft:brown_terracotta
setblock 537 96 275 minecraft:white_concrete
setblock 537 96 317 minecraft:white_concrete
fill 538 96 275 538 103 275 minecraft:brown_terracotta
fill 538 96 317 538 103 317 minecraft:brown_terracotta
fill 540 96 275 540 103 275 minecraft:brown_terracotta
fill 540 96 317 540 103 317 minecraft:brown_terracotta
setblock 541 96 275 minecraft:white_concrete
setblock 541 96 317 minecraft:white_concrete
fill 542 96 275 542 103 275 minecraft:brown_terracotta
fill 542 96 317 542 103 317 minecraft:brown_terracotta
fill 544 96 275 544 103 275 minecraft:brown_terracotta
fill 544 96 317 544 103 317 minecraft:brown_terracotta
setblock 545 96 275 minecraft:white_concrete
setblock 545 96 317 minecraft:white_concrete
fill 546 96 275 546 103 275 minecraft:brown_terracotta
fill 546 96 317 546 103 317 minecraft:brown_terracotta
fill 547 96 290 547 97 290 minecraft:shroomlight
fill 548 96 275 548 103 275 minecraft:brown_terracotta
fill 548 96 317 548 103 317 minecraft:brown_terracotta
setblock 549 96 275 minecraft:white_concrete
fill 549 96 297 550 107 299 minecraft:red_concrete
setblock 549 96 317 minecraft:white_concrete
fill 550 96 275 550 103 275 minecraft:brown_terracotta
fill 550 96 295 551 107 296 minecraft:red_concrete
fill 550 96 300 551 107 301 minecraft:red_concrete
fill 550 96 317 550 103 317 minecraft:brown_terracotta
fill 552 96 275 552 103 275 minecraft:brown_terracotta
fill 552 96 294 554 107 295 minecraft:red_concrete
fill 552 96 301 554 107 302 minecraft:red_concrete
fill 552 96 317 552 103 317 minecraft:brown_terracotta
setblock 553 96 275 minecraft:white_concrete
setblock 553 96 317 minecraft:white_concrete
fill 554 96 275 554 103 275 minecraft:brown_terracotta
fill 554 96 317 554 103 317 minecraft:brown_terracotta
fill 555 96 295 556 107 296 minecraft:red_concrete
fill 555 96 300 556 107 301 minecraft:red_concrete
fill 556 96 275 556 103 275 minecraft:brown_terracotta
fill 556 96 297 557 99 299 minecraft:red_concrete
fill 556 96 317 556 103 317 minecraft:brown_terracotta
setblock 557 96 275 minecraft:white_concrete
setblock 557 96 317 minecraft:white_concrete
fill 558 96 275 558 103 275 minecraft:brown_terracotta
fill 558 96 317 558 103 317 minecraft:brown_terracotta
setblock 559 96 275 minecraft:white_concrete
fill 559 96 276 559 103 276 minecraft:brown_terracotta
fill 559 96 278 559 103 278 minecraft:brown_terracotta
setblock 559 96 279 minecraft:white_concrete
fill 559 96 280 559 103 280 minecraft:brown_terracotta
fill 559 96 282 559 103 282 minecraft:brown_terracotta
setblock 559 96 283 minecraft:white_concrete
fill 559 96 284 559 103 284 minecraft:brown_terracotta
fill 559 96 286 559 103 286 minecraft:brown_terracotta
setblock 559 96 287 minecraft:white_concrete
fill 559 96 288 559 103 288 minecraft:brown_terracotta
fill 559 96 290 559 103 290 minecraft:brown_terracotta
setblock 559 96 291 minecraft:white_concrete
fill 559 96 292 559 103 292 minecraft:brown_terracotta
fill 559 96 294 559 103 294 minecraft:brown_terracotta
setblock 559 96 295 minecraft:white_concrete
fill 559 96 296 559 103 296 minecraft:brown_terracotta
fill 559 96 298 559 103 298 minecraft:brown_terracotta
setblock 559 96 299 minecraft:white_concrete
fill 559 96 300 559 103 300 minecraft:brown_terracotta
fill 559 96 302 559 103 302 minecraft:brown_terracotta
setblock 559 96 303 minecraft:white_concrete
fill 559 96 304 559 103 304 minecraft:brown_terracotta
fill 559 96 306 559 103 306 minecraft:brown_terracotta
setblock 559 96 307 minecraft:white_concrete
fill 559 96 308 559 103 308 minecraft:brown_terracotta
fill 559 96 310 559 103 310 minecraft:brown_terracotta
setblock 559 96 311 minecraft:white_concrete
fill 559 96 312 559 103 312 minecraft:brown_terracotta
fill 559 96 314 559 103 314 minecraft:brown_terracotta
setblock 559 96 315 minecraft:white_concrete
fill 559 96 316 559 103 316 minecraft:brown_terracotta
fill 517 97 275 517 104 275 minecraft:brown_terracotta
fill 517 97 279 517 104 279 minecraft:brown_terracotta
fill 517 97 283 517 104 283 minecraft:brown_terracotta
fill 517 97 287 517 104 287 minecraft:brown_terracotta
fill 517 97 291 517 104 291 minecraft:brown_terracotta
fill 517 97 295 517 104 295 minecraft:brown_terracotta
fill 517 97 299 517 104 299 minecraft:brown_terracotta
fill 517 97 303 517 104 303 minecraft:brown_terracotta
fill 517 97 307 517 104 307 minecraft:brown_terracotta
fill 517 97 311 517 104 311 minecraft:brown_terracotta
fill 517 97 315 517 104 315 minecraft:brown_terracotta
fill 517 97 317 517 102 317 minecraft:brown_terracotta
setblock 520 97 278 minecraft:light[level=12]
setblock 520 97 285 minecraft:light[level=12]
setblock 520 97 292 minecraft:light[level=12]
setblock 520 97 299 minecraft:light[level=12]
setblock 520 97 306 minecraft:light[level=12]
fill 520 97 312 520 97 314 minecraft:brown_terracotta
fill 521 97 275 521 104 275 minecraft:brown_terracotta
setblock 521 97 311 minecraft:brown_terracotta
fill 521 97 315 523 97 315 minecraft:brown_terracotta
fill 521 97 317 521 104 317 minecraft:brown_terracotta
fill 523 97 311 524 97 311 minecraft:brown_terracotta
fill 524 97 312 524 97 314 minecraft:brown_terracotta
fill 525 97 275 525 104 275 minecraft:brown_terracotta
fill 525 97 317 525 104 317 minecraft:brown_terracotta
setblock 527 97 278 minecraft:light[level=12]
setblock 527 97 285 minecraft:light[level=12]
setblock 527 97 292 minecraft:light[level=12]
setblock 527 97 299 minecraft:light[level=12]
setblock 527 97 306 minecraft:light[level=12]
setblock 527 97 313 minecraft:light[level=12]
fill 529 97 275 529 104 275 minecraft:brown_terracotta
fill 529 97 317 529 104 317 minecraft:brown_terracotta
fill 533 97 275 533 104 275 minecraft:brown_terracotta
fill 533 97 317 533 104 317 minecraft:brown_terracotta
setblock 534 97 278 minecraft:light[level=12]
setblock 534 97 285 minecraft:light[level=12]
setblock 534 97 292 minecraft:light[level=12]
setblock 534 97 299 minecraft:light[level=12]
setblock 534 97 306 minecraft:light[level=12]
setblock 534 97 313 minecraft:light[level=12]
fill 537 97 275 537 104 275 minecraft:brown_terracotta
fill 537 97 317 537 104 317 minecraft:brown_terracotta
fill 541 97 275 541 104 275 minecraft:brown_terracotta
setblock 541 97 278 minecraft:light[level=12]
setblock 541 97 285 minecraft:light[level=12]
setblock 541 97 292 minecraft:light[level=12]
setblock 541 97 299 minecraft:light[level=12]
setblock 541 97 306 minecraft:light[level=12]
setblock 541 97 313 minecraft:light[level=12]
fill 541 97 317 541 104 317 minecraft:brown_terracotta
fill 545 97 275 545 104 275 minecraft:brown_terracotta
fill 545 97 317 545 104 317 minecraft:brown_terracotta
setblock 548 97 278 minecraft:light[level=12]
setblock 548 97 285 minecraft:light[level=12]
setblock 548 97 292 minecraft:light[level=12]
fill 548 97 297 548 106 299 minecraft:red_concrete
setblock 548 97 306 minecraft:light[level=12]
setblock 548 97 313 minecraft:light[level=12]
fill 549 97 275 549 104 275 minecraft:brown_terracotta
fill 549 97 295 549 106 296 minecraft:red_concrete
fill 549 97 300 549 106 301 minecraft:red_concrete
fill 549 97 317 549 104 317 minecraft:brown_terracotta
fill 550 97 294 551 106 294 minecraft:red_concrete
fill 550 97 302 551 106 302 minecraft:red_concrete
fill 552 97 293 554 106 293 minecraft:red_concrete
fill 552 97 303 554 106 303 minecraft:red_concrete
fill 553 97 275 553 104 275 minecraft:brown_terracotta
fill 553 97 317 553 104 317 minecraft:brown_terracotta
setblock 555 97 278 minecraft:light[level=12]
setblock 555 97 285 minecraft:light[level=12]
setblock 555 97 292 minecraft:light[level=12]
fill 555 97 294 556 106 294 minecraft:red_concrete
fill 555 97 302 556 106 302 minecraft:red_concrete
setblock 555 97 306 minecraft:light[level=12]
setblock 555 97 313 minecraft:light[level=12]
fill 557 97 275 557 104 275 minecraft:brown_terracotta
fill 557 97 295 557 106 296 minecraft:red_concrete
fill 557 97 300 557 106 301 minecraft:red_concrete
fill 557 97 317 557 104 317 minecraft:brown_terracotta
fill 558 97 299 558 106 299 minecraft:red_concrete
fill 559 97 275 559 102 275 minecraft:brown_terracotta
fill 559 97 279 559 104 279 minecraft:brown_terracotta
fill 559 97 283 559 104 283 minecraft:brown_terracotta
fill 559 97 287 559 104 287 minecraft:brown_terracotta
fill 559 97 291 559 104 291 minecraft:brown_terracotta
fill 559 97 295 559 104 295 minecraft:brown_terracotta
fill 559 97 299 559 104 299 minecraft:brown_terracotta
fill 559 97 303 559 104 303 minecraft:brown_terracotta
fill 559 97 307 559 104 307 minecraft:brown_terracotta
fill 559 97 311 559 104 311 minecraft:brown_terracotta
fill 559 97 315 559 104 315 minecraft:brown_terracotta
fill 537 98 305 538 99 306 minecraft:red_concrete
fill 547 98 290 548 100 290 minecraft:brown_terracotta
fill 547 98 298 547 105 298 minecraft:red_concrete
fill 548 98 295 548 105 296 minecraft:red_concrete
fill 548 98 300 548 105 301 minecraft:red_concrete
fill 549 98 294 549 105 294 minecraft:red_concrete
fill 549 98 302 549 105 302 minecraft:red_concrete
fill 550 98 293 551 105 293 minecraft:red_concrete
fill 550 98 303 551 105 303 minecraft:red_concrete
fill 553 98 292 553 105 292 minecraft:red_concrete
fill 553 98 304 553 105 304 minecraft:red_concrete
fill 555 98 293 556 105 293 minecraft:red_concrete
fill 555 98 303 556 105 303 minecraft:red_concrete
fill 557 98 294 557 105 294 minecraft:red_concrete
fill 557 98 302 557 105 302 minecraft:red_concrete
fill 558 98 295 558 105 295 minecraft:red_concrete
fill 558 98 300 558 104 301 minecraft:red_concrete
fill 533 99 278 537 99 282 minecraft:orange_terracotta
fill 547 99 289 548 105 289 minecraft:brown_terracotta
fill 547 99 296 547 104 297 minecraft:red_concrete
fill 547 99 299 547 104 300 minecraft:red_concrete
fill 548 99 294 548 104 294 minecraft:red_concrete
fill 548 99 302 548 104 302 minecraft:red_concrete
fill 549 99 293 549 104 293 minecraft:red_concrete
fill 549 99 303 549 104 303 minecraft:red_concrete
fill 551 99 292 552 104 292 minecraft:red_concrete
fill 551 99 304 552 104 304 minecraft:red_concrete
fill 554 99 292 555 104 292 minecraft:red_concrete
fill 554 99 304 555 104 304 minecraft:red_concrete
fill 557 99 293 557 104 293 minecraft:red_concrete
fill 557 99 303 557 104 303 minecraft:red_concrete
fill 558 99 294 558 104 294 minecraft:red_concrete
fill 558 99 302 558 104 302 minecraft:red_concrete
fill 519 100 285 519 105 287 minecraft:white_concrete
fill 519 100 297 519 105 299 minecraft:white_concrete
fill 519 100 309 519 105 311 minecraft:white_concrete
fill 525 100 315 527 105 315 minecraft:white_concrete
fill 529 100 277 531 105 277 minecraft:white_concrete
fill 533 100 278 534 103 282 minecraft:orange_terracotta
fill 535 100 278 537 103 279 minecraft:orange_terracotta
fill 535 100 280 535 101 280 minecraft:ochre_froglight
fill 535 100 281 537 103 282 minecraft:orange_terracotta
fill 536 100 280 537 103 280 minecraft:orange_terracotta
fill 537 100 315 539 105 315 minecraft:white_concrete
fill 541 100 277 543 105 277 minecraft:white_concrete
fill 546 100 290 546 105 290 minecraft:brown_terracotta
fill 547 100 291 548 100 291 minecraft:brown_terracotta
fill 547 100 295 547 103 295 minecraft:red_concrete
fill 547 100 301 547 103 301 minecraft:red_concrete
fill 549 100 315 551 105 315 minecraft:white_concrete
fill 550 100 292 550 103 292 minecraft:red_concrete
fill 550 100 304 550 103 304 minecraft:red_concrete
fill 553 100 277 555 105 277 minecraft:white_concrete
fill 556 100 292 556 103 292 minecraft:red_concrete
fill 556 100 297 556 107 299 minecraft:red_concrete
fill 556 100 304 556 103 304 minecraft:red_concrete
fill 557 100 285 557 105 287 minecraft:white_concrete
fill 557 100 297 557 105 299 minecraft:white_concrete
fill 557 100 309 557 105 311 minecraft:white_concrete
setblock 520 101 278 minecraft:light[level=15]
setblock 520 101 286 minecraft:light[level=15]
setblock 520 101 294 minecraft:light[level=15]
setblock 520 101 302 minecraft:light[level=15]
setblock 520 101 310 minecraft:light[level=15]
setblock 528 101 278 minecraft:light[level=15]
setblock 528 101 286 minecraft:light[level=15]
setblock 528 101 294 minecraft:light[level=15]
setblock 528 101 302 minecraft:light[level=15]
setblock 528 101 310 minecraft:light[level=15]
setblock 536 101 286 minecraft:light[level=15]
setblock 536 101 294 minecraft:light[level=15]
setblock 536 101 302 minecraft:light[level=15]
setblock 536 101 310 minecraft:light[level=15]
fill 543 101 297 544 102 299 minecraft:shroomlight
setblock 544 101 278 minecraft:light[level=15]
setblock 544 101 286 minecraft:light[level=15]
fill 544 101 294 544 102 296 minecraft:shroomlight
fill 544 101 300 544 102 302 minecraft:shroomlight
setblock 544 101 310 minecraft:light[level=15]
fill 545 101 292 545 102 294 minecraft:shroomlight
fill 545 101 302 545 102 304 minecraft:shroomlight
fill 546 101 289 546 105 289 minecraft:brown_terracotta
fill 546 101 291 546 102 292 minecraft:shroomlight
fill 546 101 304 546 102 305 minecraft:shroomlight
fill 547 101 288 548 105 288 minecraft:brown_terracotta
fill 547 101 290 547 102 291 minecraft:shroomlight
fill 547 101 305 547 102 306 minecraft:shroomlight
fill 548 101 290 549 102 290 minecraft:shroomlight
fill 548 101 291 549 105 291 minecraft:brown_terracotta
fill 548 101 306 549 102 306 minecraft:shroomlight
fill 549 101 289 557 102 289 minecraft:shroomlight
fill 549 101 307 557 102 307 minecraft:shroomlight
setblock 552 101 278 minecraft:light[level=15]
setblock 552 101 286 minecraft:light[level=15]
fill 552 101 288 554 102 288 minecraft:shroomlight
fill 552 101 308 554 102 308 minecraft:shroomlight
setblock 552 101 310 minecraft:light[level=15]
fill 557 101 290 558 102 290 minecraft:shroomlight
fill 557 101 306 558 102 306 minecraft:shroomlight
fill 535 102 280 535 103 280 minecraft:orange_terracotta
fill 545 102 290 545 105 290 minecraft:brown_terracotta
fill 546 102 288 546 105 288 minecraft:brown_terracotta
fill 547 102 292 548 105 292 minecraft:brown_terracotta
fill 549 102 288 549 105 288 minecraft:brown_terracotta
setblock 517 103 277 minecraft:white_concrete
setblock 517 103 281 minecraft:white_concrete
setblock 517 103 285 minecraft:white_concrete
setblock 517 103 289 minecraft:white_concrete
setblock 517 103 293 minecraft:white_concrete
setblock 517 103 297 minecraft:white_concrete
setblock 517 103 301 minecraft:white_concrete
setblock 517 103 305 minecraft:white_concrete
setblock 517 103 309 minecraft:white_concrete
setblock 517 103 313 minecraft:white_concrete
setblock 517 103 317 minecraft:white_concrete
setblock 519 103 275 minecraft:white_concrete
setblock 519 103 317 minecraft:white_concrete
setblock 520 103 278 minecraft:light[level=12]
setblock 520 103 285 minecraft:light[level=12]
setblock 520 103 292 minecraft:light[level=12]
setblock 520 103 299 minecraft:light[level=12]
setblock 520 103 306 minecraft:light[level=12]
setblock 520 103 313 minecraft:light[level=12]
fill 522 103 305 522 104 306 minecraft:white_concrete
setblock 523 103 275 minecraft:white_concrete
setblock 523 103 317 minecraft:white_concrete
setblock 527 103 275 minecraft:white_concrete
setblock 527 103 278 minecraft:light[level=12]
setblock 527 103 285 minecraft:light[level=12]
setblock 527 103 292 minecraft:light[level=12]
setblock 527 103 299 minecraft:light[level=12]
setblock 527 103 306 minecraft:light[level=12]
setblock 527 103 313 minecraft:light[level=12]
setblock 527 103 317 minecraft:white_concrete
setblock 531 103 275 minecraft:white_concrete
setblock 531 103 317 minecraft:white_concrete
setblock 534 103 285 minecraft:light[level=12]
setblock 534 103 292 minecraft:light[level=12]
setblock 534 103 299 minecraft:light[level=12]
setblock 534 103 306 minecraft:light[level=12]
setblock 534 103 313 minecraft:light[level=12]
setblock 535 103 275 minecraft:white_concrete
setblock 535 103 317 minecraft:white_concrete
setblock 539 103 275 minecraft:white_concrete
setblock 539 103 317 minecraft:white_concrete
setblock 541 103 278 minecraft:light[level=12]
setblock 541 103 285 minecraft:light[level=12]
setblock 541 103 292 minecraft:light[level=12]
setblock 541 103 299 minecraft:light[level=12]
setblock 541 103 306 minecraft:light[level=12]
setblock 541 103 313 minecraft:light[level=12]
setblock 543 103 275 minecraft:white_concrete
setblock 543 103 317 minecraft:white_concrete
fill 545 103 289 545 105 289 minecraft:brown_terracotta
fill 545 103 291 547 105 291 minecraft:brown_terracotta
fill 546 103 292 546 105 292 minecraft:brown_terracotta
setblock 547 103 275 minecraft:white_concrete
fill 547 103 287 547 105 287 minecraft:brown_terracotta
fill 547 103 290 550 105 290 minecraft:brown_terracotta
setblock 547 103 317 minecraft:white_concrete
setblock 548 103 278 minecraft:light[level=12]
setblock 548 103 285 minecraft:light[level=12]
setblock 548 103 306 minecraft:light[level=12]
setblock 548 103 313 minecraft:light[level=12]
fill 549 103 289 550 105 289 minecraft:brown_terracotta
fill 549 103 292 549 105 292 minecraft:brown_terracotta
fill 550 103 291 550 105 291 minecraft:brown_terracotta
setblock 551 103 275 minecraft:white_concrete
setblock 551 103 317 minecraft:white_concrete
setblock 555 103 275 minecraft:white_concrete
setblock 555 103 278 minecraft:light[level=12]
setblock 555 103 285 minecraft:light[level=12]
setblock 555 103 306 minecraft:light[level=12]
setblock 555 103 313 minecraft:light[level=12]
setblock 555 103 317 minecraft:white_concrete
setblock 559 103 275 minecraft:white_concrete
setblock 559 103 277 minecraft:white_concrete
setblock 559 103 281 minecraft:white_concrete
setblock 559 103 285 minecraft:white_concrete
setblock 559 103 289 minecraft:white_concrete
setblock 559 103 293 minecraft:white_concrete
setblock 559 103 297 minecraft:white_concrete
setblock 559 103 301 minecraft:white_concrete
setblock 559 103 305 minecraft:white_concrete
setblock 559 103 309 minecraft:white_concrete
setblock 559 103 313 minecraft:white_concrete
setblock 559 103 317 minecraft:white_concrete
setblock 517 104 276 minecraft:white_concrete
fill 517 104 277 517 111 277 minecraft:brown_terracotta
setblock 517 104 278 minecraft:white_concrete
setblock 517 104 280 minecraft:white_concrete
fill 517 104 281 517 105 281 minecraft:brown_terracotta
setblock 517 104 282 minecraft:white_concrete
setblock 517 104 284 minecraft:white_concrete
fill 517 104 285 517 111 285 minecraft:brown_terracotta
setblock 517 104 286 minecraft:white_concrete
setblock 517 104 288 minecraft:white_concrete
fill 517 104 289 517 111 289 minecraft:brown_terracotta
setblock 517 104 290 minecraft:white_concrete
setblock 517 104 292 minecraft:white_concrete
fill 517 104 293 517 105 293 minecraft:brown_terracotta
setblock 517 104 294 minecraft:white_concrete
setblock 517 104 296 minecraft:white_concrete
fill 517 104 297 517 111 297 minecraft:brown_terracotta
setblock 517 104 298 minecraft:white_concrete
setblock 517 104 300 minecraft:white_concrete
fill 517 104 301 517 111 301 minecraft:brown_terracotta
setblock 517 104 302 minecraft:white_concrete
setblock 517 104 304 minecraft:white_concrete
fill 517 104 305 517 105 305 minecraft:brown_terracotta
setblock 517 104 306 minecraft:white_concrete
setblock 517 104 308 minecraft:white_concrete
fill 517 104 309 517 111 309 minecraft:brown_terracotta
setblock 517 104 310 minecraft:white_concrete
setblock 517 104 312 minecraft:white_concrete
fill 517 104 313 517 111 313 minecraft:brown_terracotta
setblock 517 104 314 minecraft:white_concrete
setblock 517 104 316 minecraft:white_concrete
setblock 517 104 317 minecraft:brown_terracotta
setblock 518 104 275 minecraft:white_concrete
setblock 518 104 317 minecraft:white_concrete
fill 519 104 275 519 111 275 minecraft:brown_terracotta
fill 519 104 317 519 105 317 minecraft:brown_terracotta
setblock 520 104 275 minecraft:white_concrete
setblock 520 104 317 minecraft:white_concrete
fill 521 104 312 521 104 314 minecraft:white_concrete
setblock 522 104 275 minecraft:white_concrete
fill 522 104 278 522 105 278 minecraft:brown_terracotta
fill 522 104 287 522 105 287 minecraft:brown_terracotta
fill 522 104 312 522 105 312 minecraft:brown_terracotta
fill 522 104 313 523 139 314 minecraft:white_concrete
setblock 522 104 317 minecraft:white_concrete
fill 523 104 275 523 111 275 minecraft:brown_terracotta
fill 523 104 312 523 110 312 minecraft:white_concrete
fill 523 104 317 523 111 317 minecraft:brown_terracotta
setblock 524 104 275 minecraft:white_concrete
setblock 524 104 317 minecraft:white_concrete
setblock 526 104 275 minecraft:white_concrete
setblock 526 104 317 minecraft:white_concrete
fill 527 104 275 527 105 275 minecraft:brown_terracotta
fill 527 104 317 527 111 317 minecraft:brown_terracotta
setblock 528 104 275 minecraft:white_concrete
setblock 528 104 317 minecraft:white_concrete
setblock 530 104 275 minecraft:white_concrete
fill 530 104 280 530 105 280 minecraft:brown_terracotta
setblock 530 104 317 minecraft:white_concrete
fill 531 104 275 531 111 275 minecraft:brown_terracotta
fill 531 104 317 531 105 317 minecraft:brown_terracotta
setblock 532 104 275 minecraft:white_concrete
setblock 532 104 317 minecraft:white_concrete
fill 533 104 278 537 104 282 minecraft:white_concrete
setblock 534 104 275 minecraft:white_concrete
setblock 534 104 317 minecraft:white_concrete
fill 535 104 275 535 111 275 minecraft:brown_terracotta
fill 535 104 317 535 111 317 minecraft:brown_terracotta
setblock 536 104 275 minecraft:white_concrete
setblock 536 104 317 minecraft:white_concrete
setblock 538 104 275 minecraft:white_concrete
setblock 538 104 317 minecraft:white_concrete
fill 539 104 275 539 105 275 minecraft:brown_terracotta
fill 539 104 317 539 111 317 minecraft:brown_terracotta
setblock 540 104 275 minecraft:white_concrete
setblock 540 104 317 minecraft:white_concrete
setblock 542 104 275 minecraft:white_concrete
setblock 542 104 317 minecraft:white_concrete
fill 543 104 275 543 111 275 minecraft:brown_terracotta
fill 543 104 317 543 105 317 minecraft:brown_terracotta
setblock 544 104 275 minecraft:white_concrete
setblock 544 104 317 minecraft:white_concrete
fill 545 104 288 545 105 288 minecraft:brown_terracotta
fill 545 104 292 545 105 292 minecraft:brown_terracotta
setblock 546 104 275 minecraft:white_concrete
fill 546 104 287 546 105 287 minecraft:brown_terracotta
fill 546 104 311 546 105 311 minecraft:brown_terracotta
setblock 546 104 317 minecraft:white_concrete
fill 547 104 275 547 111 275 minecraft:brown_terracotta
fill 547 104 293 548 105 293 minecraft:brown_terracotta
fill 547 104 317 547 111 317 minecraft:brown_terracotta
setblock 548 104 275 minecraft:white_concrete
fill 548 104 287 549 105 287 minecraft:brown_terracotta
setblock 548 104 317 minecraft:white_concrete
setblock 550 104 275 minecraft:white_concrete
fill 550 104 288 550 105 288 minecraft:brown_terracotta
fill 550 104 292 550 105 292 minecraft:brown_terracotta
setblock 550 104 317 minecraft:white_concrete
fill 551 104 275 551 105 275 minecraft:brown_terracotta
fill 551 104 317 551 111 317 minecraft:brown_terracotta
setblock 552 104 275 minecraft:white_concrete
setblock 552 104 317 minecraft:white_concrete
fill 553 104 283 553 105 283 minecraft:brown_terracotta
setblock 554 104 275 minecraft:white_concrete
setblock 554 104 317 minecraft:white_concrete
fill 555 104 275 555 111 275 minecraft:brown_terracotta
fill 555 104 317 555 105 317 minecraft:brown_terracotta
setblock 556 104 275 minecraft:white_concrete
setblock 556 104 317 minecraft:white_concrete
setblock 558 104 275 minecraft:white_concrete
setblock 558 104 317 minecraft:white_concrete
setblock 559 104 275 minecraft:brown_terracotta
setblock 559 104 276 minecraft:white_concrete
fill 559 104 277 559 105 277 minecraft:brown_terracotta
setblock 559 104 278 minecraft:white_concrete
setblock 559 104 280 minecraft:white_concrete
fill 559 104 281 559 111 281 minecraft:brown_terracotta
setblock 559 104 282 minecraft:white_concrete
setblock 559 104 284 minecraft:white_concrete
fill 559 104 285 559 111 285 minecraft:brown_terracotta
setblock 559 104 286 minecraft:white_concrete
setblock 559 104 288 minecraft:white_concrete
fill 559 104 289 559 105 289 minecraft:brown_terracotta
setblock 559 104 290 minecraft:white_concrete
setblock 559 104 292 minecraft:white_concrete
fill 559 104 293 559 111 293 minecraft:brown_terracotta
setblock 559 104 294 minecraft:white_concrete
setblock 559 104 296 minecraft:white_concrete
fill 559 104 297 559 111 297 minecraft:brown_terracotta
setblock 559 104 298 minecraft:white_concrete
setblock 559 104 300 minecraft:white_concrete
fill 559 104 301 559 105 301 minecraft:brown_terracotta
setblock 559 104 302 minecraft:white_concrete
setblock 559 104 304 minecraft:white_concrete
fill 559 104 305 559 111 305 minecraft:brown_terracotta
setblock 559 104 306 minecraft:white_concrete
setblock 559 104 308 minecraft:white_concrete
fill 559 104 309 559 111 309 minecraft:brown_terracotta
setblock 559 104 310 minecraft:white_concrete
setblock 559 104 312 minecraft:white_concrete
fill 559 104 313 559 105 313 minecraft:brown_terracotta
setblock 559 104 314 minecraft:white_concrete
setblock 559 104 316 minecraft:white_concrete
fill 559 104 317 559 111 317 minecraft:brown_terracotta
setblock 517 105 275 minecraft:white_concrete
fill 517 105 276 517 112 276 minecraft:brown_terracotta
fill 517 105 278 517 112 278 minecraft:brown_terracotta
setblock 517 105 279 minecraft:white_concrete
fill 517 105 280 518 105 280 minecraft:brown_terracotta
fill 517 105 282 518 105 282 minecraft:brown_terracotta
setblock 517 105 283 minecraft:white_concrete
fill 517 105 284 518 105 284 minecraft:brown_terracotta
fill 517 105 286 517 112 286 minecraft:brown_terracotta
setblock 517 105 287 minecraft:white_concrete
fill 517 105 288 517 112 288 minecraft:brown_terracotta
fill 517 105 290 517 112 290 minecraft:brown_terracotta
setblock 517 105 291 minecraft:white_concrete
fill 517 105 292 518 105 292 minecraft:brown_terracotta
fill 517 105 294 518 105 294 minecraft:brown_terracotta
setblock 517 105 295 minecraft:white_concrete
fill 517 105 296 518 105 296 minecraft:brown_terracotta
fill 517 105 298 517 112 298 minecraft:brown_terracotta
setblock 517 105 299 minecraft:white_concrete
fill 517 105 300 517 112 300 minecraft:brown_terracotta
fill 517 105 302 517 112 302 minecraft:brown_terracotta
setblock 517 105 303 minecraft:white_concrete
fill 517 105 304 518 105 304 minecraft:brown_terracotta
fill 517 105 306 518 105 306 minecraft:brown_terracotta
setblock 517 105 307 minecraft:white_concrete
fill 517 105 308 518 105 308 minecraft:brown_terracotta
fill 517 105 310 517 112 310 minecraft:brown_terracotta
setblock 517 105 311 minecraft:white_concrete
fill 517 105 312 517 112 312 minecraft:brown_terracotta
fill 517 105 314 517 112 314 minecraft:brown_terracotta
setblock 517 105 315 minecraft:white_concrete
fill 517 105 316 522 105 316 minecraft:brown_terracotta
setblock 517 105 317 minecraft:white_concrete
fill 518 105 275 518 112 275 minecraft:brown_terracotta
setblock 518 105 279 minecraft:brown_terracotta
setblock 518 105 281 minecraft:brown_terracotta
setblock 518 105 283 minecraft:brown_terracotta
setblock 518 105 291 minecraft:brown_terracotta
setblock 518 105 293 minecraft:brown_terracotta
setblock 518 105 295 minecraft:brown_terracotta
setblock 518 105 303 minecraft:brown_terracotta
setblock 518 105 305 minecraft:brown_terracotta
setblock 518 105 307 minecraft:brown_terracotta
setblock 518 105 315 minecraft:brown_terracotta
setblock 518 105 317 minecraft:brown_terracotta
fill 520 105 275 520 112 275 minecraft:brown_terracotta
fill 520 105 312 520 105 314 minecraft:brown_terracotta
setblock 520 105 317 minecraft:brown_terracotta
setblock 521 105 275 minecraft:white_concrete
fill 521 105 278 521 106 278 minecraft:brown_terracotta
fill 521 105 287 521 106 287 minecraft:brown_terracotta
fill 521 105 311 521 105 312 minecraft:brown_terracotta
fill 521 105 313 521 139 314 minecraft:white_concrete
fill 521 105 315 523 105 315 minecraft:brown_terracotta
setblock 521 105 317 minecraft:white_concrete
fill 522 105 275 522 105 276 minecraft:brown_terracotta
fill 522 105 317 522 112 317 minecraft:brown_terracotta
fill 523 105 276 527 105 276 minecraft:brown_terracotta
fill 523 105 311 524 105 311 minecraft:brown_terracotta
setblock 524 105 275 minecraft:brown_terracotta
fill 524 105 312 524 105 314 minecraft:brown_terracotta
fill 524 105 317 524 112 317 minecraft:brown_terracotta
setblock 525 105 275 minecraft:white_concrete
setblock 525 105 317 minecraft:white_concrete
setblock 526 105 275 minecraft:brown_terracotta
fill 526 105 317 526 112 317 minecraft:brown_terracotta
fill 528 105 275 528 112 275 minecraft:brown_terracotta
fill 528 105 317 528 112 317 minecraft:brown_terracotta
setblock 529 105 275 minecraft:white_concrete
fill 529 105 316 534 105 316 minecraft:brown_terracotta
setblock 529 105 317 minecraft:white_concrete
fill 530 105 275 530 112 275 minecraft:brown_terracotta
fill 530 105 279 530 106 279 minecraft:brown_terracotta
setblock 530 105 317 minecraft:brown_terracotta
fill 532 105 275 532 112 275 minecraft:brown_terracotta
setblock 532 105 317 minecraft:brown_terracotta
setblock 533 105 275 minecraft:white_concrete
setblock 533 105 317 minecraft:white_concrete
fill 534 105 275 534 105 276 minecraft:brown_terracotta
fill 534 105 278 536 105 282 minecraft:white_concrete
fill 534 105 317 534 112 317 minecraft:brown_terracotta
fill 535 105 276 539 105 276 minecraft:brown_terracotta
setblock 536 105 275 minecraft:brown_terracotta
fill 536 105 317 536 112 317 minecraft:brown_terracotta
setblock 537 105 275 minecraft:white_concrete
setblock 537 105 317 minecraft:white_concrete
setblock 538 105 275 minecraft:brown_terracotta
fill 538 105 317 538 112 317 minecraft:brown_terracotta
fill 540 105 275 540 112 275 minecraft:brown_terracotta
fill 540 105 317 540 112 317 minecraft:brown_terracotta
setblock 541 105 275 minecraft:white_concrete
fill 541 105 316 546 105 316 minecraft:brown_terracotta
setblock 541 105 317 minecraft:white_concrete
fill 542 105 275 542 112 275 minecraft:brown_terracotta
setblock 542 105 317 minecraft:brown_terracotta
fill 544 105 275 544 112 275 minecraft:brown_terracotta
fill 544 105 289 544 105 291 minecraft:brown_terracotta
setblock 544 105 317 minecraft:brown_terracotta
setblock 545 105 275 minecraft:white_concrete
setblock 545 105 287 minecraft:brown_terracotta
setblock 545 105 317 minecraft:white_concrete
fill 546 105 275 546 105 276 minecraft:brown_terracotta
setblock 546 105 293 minecraft:brown_terracotta
fill 546 105 312 546 106 312 minecraft:brown_terracotta
fill 546 105 317 546 112 317 minecraft:brown_terracotta
fill 547 105 276 551 105 276 minecraft:brown_terracotta
setblock 548 105 275 minecraft:brown_terracotta
fill 548 105 317 548 112 317 minecraft:brown_terracotta
setblock 549 105 275 minecraft:white_concrete
setblock 549 105 293 minecraft:brown_terracotta
setblock 549 105 317 minecraft:white_concrete
setblock 550 105 275 minecraft:brown_terracotta
setblock 550 105 287 minecraft:brown_terracotta
fill 550 105 317 550 112 317 minecraft:brown_terracotta
fill 551 105 289 551 105 291 minecraft:brown_terracotta
fill 552 105 275 552 112 275 minecraft:brown_terracotta
fill 552 105 317 552 112 317 minecraft:brown_terracotta
setblock 553 105 275 minecraft:white_concrete
fill 553 105 316 559 105 316 minecraft:brown_terracotta
setblock 553 105 317 minecraft:white_concrete
fill 554 105 275 554 112 275 minecraft:brown_terracotta
fill 554 105 283 554 106 283 minecraft:brown_terracotta
setblock 554 105 317 minecraft:brown_terracotta
fill 556 105 275 556 112 275 minecraft:brown_terracotta
setblock 556 105 317 minecraft:brown_terracotta
setblock 557 105 275 minecraft:white_concrete
setblock 557 105 317 minecraft:white_concrete
fill 558 105 275 558 105 281 minecraft:brown_terracotta
fill 558 105 288 558 105 293 minecraft:brown_terracotta
fill 558 105 300 558 105 305 minecraft:brown_terracotta
fill 558 105 312 558 105 315 minecraft:brown_terracotta
fill 558 105 317 558 112 317 minecraft:brown_terracotta
setblock 559 105 275 minecraft:white_concrete
setblock 559 105 276 minecraft:brown_terracotta
setblock 559 105 278 minecraft:brown_terracotta
setblock 559 105 279 minecraft:white_concrete
fill 559 105 280 559 112 280 minecraft:brown_terracotta
fill 559 105 282 559 112 282 minecraft:brown_terracotta
setblock 559 105 283 minecraft:white_concrete
fill 559 105 284 559 112 284 minecraft:brown_terracotta
fill 559 105 286 559 112 286 minecraft:brown_terracotta
setblock 559 105 287 minecraft:white_concrete
setblock 559 105 288 minecraft:brown_terracotta
setblock 559 105 290 minecraft:brown_terracotta
setblock 559 105 291 minecraft:white_concrete
fill 559 105 292 559 112 292 minecraft:brown_terracotta
fill 559 105 294 559 112 294 minecraft:brown_terracotta
setblock 559 105 295 minecraft:white_concrete
fill 559 105 296 559 112 296 minecraft:brown_terracotta
fill 559 105 298 559 112 298 minecraft:brown_terracotta
setblock 559 105 299 minecraft:white_concrete
setblock 559 105 300 minecraft:brown_terracotta
setblock 559 105 302 minecraft:brown_terracotta
setblock 559 105 303 minecraft:white_concrete
fill 559 105 304 559 112 304 minecraft:brown_terracotta
fill 559 105 306 559 112 306 minecraft:brown_terracotta
setblock 559 105 307 minecraft:white_concrete
fill 559 105 308 559 112 308 minecraft:brown_terracotta
fill 559 105 310 559 112 310 minecraft:brown_terracotta
setblock 559 105 311 minecraft:white_concrete
setblock 559 105 312 minecraft:brown_terracotta
setblock 559 105 314 minecraft:brown_terracotta
setblock 559 105 315 minecraft:white_concrete
fill 517 106 275 517 113 275 minecraft:brown_terracotta
fill 517 106 279 517 112 280 minecraft:brown_terracotta
fill 517 106 281 517 111 284 minecraft:shroomlight
fill 517 106 287 517 113 287 minecraft:brown_terracotta
fill 517 106 291 517 112 292 minecraft:brown_terracotta
fill 517 106 293 517 111 296 minecraft:shroomlight
fill 517 106 299 517 113 299 minecraft:brown_terracotta
fill 517 106 303 517 112 304 minecraft:brown_terracotta
fill 517 106 305 517 111 308 minecraft:shroomlight
fill 517 106 311 517 113 311 minecraft:brown_terracotta
fill 517 106 315 517 112 316 minecraft:brown_terracotta
fill 517 106 317 520 111 317 minecraft:shroomlight
fill 520 106 278 520 107 278 minecraft:brown_terracotta
fill 520 106 287 520 107 287 minecraft:brown_terracotta
fill 520 106 312 521 106 312 minecraft:brown_terracotta
fill 521 106 275 522 112 275 minecraft:brown_terracotta
fill 521 106 317 521 113 317 minecraft:brown_terracotta
fill 522 106 312 522 108 312 minecraft:white_concrete
fill 524 106 275 527 111 275 minecraft:shroomlight
fill 525 106 317 525 113 317 minecraft:brown_terracotta
fill 526 106 280 526 109 280 minecraft:iron_block
fill 529 106 275 529 113 275 minecraft:brown_terracotta
fill 529 106 317 532 111 317 minecraft:shroomlight
fill 530 106 278 530 107 278 minecraft:brown_terracotta
fill 533 106 275 534 112 275 minecraft:brown_terracotta
fill 533 106 317 533 113 317 minecraft:brown_terracotta
fill 535 106 278 535 106 282 minecraft:white_concrete
fill 536 106 275 539 111 275 minecraft:shroomlight
fill 537 106 317 537 113 317 minecraft:brown_terracotta
fill 541 106 275 541 113 275 minecraft:brown_terracotta
fill 541 106 317 544 111 317 minecraft:shroomlight
fill 545 106 275 546 112 275 minecraft:brown_terracotta
fill 545 106 317 545 113 317 minecraft:brown_terracotta
fill 546 106 313 546 107 313 minecraft:brown_terracotta
fill 547 106 290 548 108 290 minecraft:white_concrete
fill 548 106 275 551 111 275 minecraft:shroomlight
fill 549 106 317 549 113 317 minecraft:brown_terracotta
fill 553 106 275 553 113 275 minecraft:brown_terracotta
fill 553 106 317 556 111 317 minecraft:shroomlight
fill 555 106 283 555 107 283 minecraft:brown_terracotta
fill 557 106 275 559 111 275 minecraft:brown_terracotta
fill 557 106 297 557 107 299 minecraft:red_concrete
fill 557 106 317 557 113 317 minecraft:brown_terracotta
fill 559 106 276 559 111 279 minecraft:shroomlight
fill 559 106 283 559 113 283 minecraft:brown_terracotta
fill 559 106 287 559 113 287 minecraft:brown_terracotta
fill 559 106 288 559 111 291 minecraft:shroomlight
fill 559 106 295 559 113 295 minecraft:brown_terracotta
fill 559 106 299 559 113 299 minecraft:brown_terracotta
fill 559 106 300 559 111 303 minecraft:shroomlight
fill 559 106 307 559 113 307 minecraft:brown_terracotta
fill 559 106 311 559 113 311 minecraft:brown_terracotta
fill 559 106 312 559 111 315 minecraft:shroomlight
fill 559 106 316 559 112 316 minecraft:brown_terracotta
fill 519 107 278 519 108 278 minecraft:brown_terracotta
fill 519 107 287 519 108 287 minecraft:brown_terracotta
fill 519 107 312 520 107 312 minecraft:brown_terracotta
fill 521 107 312 521 139 312 minecraft:white_concrete
fill 530 107 277 530 108 277 minecraft:brown_terracotta
fill 546 107 314 546 108 314 minecraft:brown_terracotta
fill 555 107 294 556 107 294 minecraft:brown_terracotta
fill 556 107 283 556 108 283 minecraft:brown_terracotta
fill 518 108 278 518 109 278 minecraft:brown_terracotta
setblock 519 108 312 minecraft:brown_terracotta
fill 520 108 288 524 108 292 minecraft:orange_terracotta
fill 546 108 315 546 109 315 minecraft:brown_terracotta
fill 550 108 276 554 108 280 minecraft:orange_terracotta
fill 555 108 276 556 139 276 minecraft:white_concrete
fill 556 108 294 557 108 294 minecraft:brown_terracotta
fill 557 108 283 557 109 283 minecraft:brown_terracotta
setblock 520 109 278 minecraft:light[level=15]
setblock 520 109 285 minecraft:light[level=12]
setblock 520 109 286 minecraft:light[level=15]
fill 520 109 288 521 112 292 minecraft:orange_terracotta
setblock 520 109 294 minecraft:light[level=15]
setblock 520 109 299 minecraft:light[level=12]
setblock 520 109 302 minecraft:light[level=15]
setblock 520 109 306 minecraft:light[level=12]
setblock 520 109 310 minecraft:light[level=15]
setblock 520 109 313 minecraft:light[level=12]
setblock 522 109 282 minecraft:shroomlight
fill 522 109 288 524 112 289 minecraft:orange_terracotta
fill 522 109 290 522 110 290 minecraft:ochre_froglight
fill 522 109 291 524 112 292 minecraft:orange_terracotta
setblock 522 109 294 minecraft:shroomlight
setblock 522 109 300 minecraft:shroomlight
setblock 522 109 306 minecraft:shroomlight
setblock 522 109 312 minecraft:shroomlight
fill 523 109 290 524 112 290 minecraft:orange_terracotta
setblock 524 109 280 minecraft:shroomlight
setblock 527 109 278 minecraft:light[level=12]
setblock 527 109 285 minecraft:light[level=12]
setblock 527 109 292 minecraft:light[level=12]
setblock 527 109 299 minecraft:light[level=12]
setblock 527 109 306 minecraft:light[level=12]
setblock 527 109 313 minecraft:light[level=12]
setblock 528 109 278 minecraft:light[level=15]
setblock 528 109 286 minecraft:light[level=15]
setblock 528 109 294 minecraft:light[level=15]
setblock 528 109 302 minecraft:light[level=15]
setblock 528 109 310 minecraft:light[level=15]
setblock 528 109 312 minecraft:shroomlight
setblock 530 109 280 minecraft:shroomlight
setblock 534 109 278 minecraft:light[level=12]
setblock 534 109 285 minecraft:light[level=12]
setblock 534 109 292 minecraft:light[level=12]
setblock 534 109 299 minecraft:light[level=12]
setblock 534 109 306 minecraft:light[level=12]
setblock 534 109 312 minecraft:shroomlight
setblock 534 109 313 minecraft:light[level=12]
setblock 536 109 278 minecraft:light[level=15]
setblock 536 109 280 minecraft:shroomlight
setblock 536 109 286 minecraft:light[level=15]
setblock 536 109 294 minecraft:light[level=15]
setblock 536 109 302 minecraft:light[level=15]
setblock 536 109 310 minecraft:light[level=15]
setblock 540 109 312 minecraft:shroomlight
setblock 541 109 278 minecraft:light[level=12]
setblock 541 109 285 minecraft:light[level=12]
setblock 541 109 292 minecraft:light[level=12]
setblock 541 109 299 minecraft:light[level=12]
setblock 541 109 306 minecraft:light[level=12]
setblock 541 109 313 minecraft:light[level=12]
setblock 542 109 280 minecraft:shroomlight
setblock 544 109 278 minecraft:light[level=15]
setblock 544 109 286 minecraft:light[level=15]
setblock 544 109 294 minecraft:light[level=15]
setblock 544 109 302 minecraft:light[level=15]
setblock 544 109 310 minecraft:light[level=15]
fill 546 109 289 549 111 291 minecraft:spruce_leaves[persistent=true]
setblock 546 109 312 minecraft:shroomlight
fill 547 109 288 548 111 288 minecraft:spruce_leaves[persistent=true]
setblock 548 109 278 minecraft:light[level=12]
setblock 548 109 280 minecraft:shroomlight
setblock 548 109 285 minecraft:light[level=12]
setblock 548 109 292 minecraft:light[level=12]
setblock 548 109 299 minecraft:light[level=12]
setblock 548 109 306 minecraft:light[level=12]
setblock 548 109 313 minecraft:light[level=12]
fill 550 109 276 551 112 280 minecraft:orange_terracotta
fill 552 109 276 554 112 277 minecraft:orange_terracotta
fill 552 109 278 552 110 278 minecraft:ochre_froglight
fill 552 109 279 554 112 280 minecraft:orange_terracotta
setblock 552 109 286 minecraft:light[level=15]
setblock 552 109 294 minecraft:light[level=15]
setblock 552 109 302 minecraft:light[level=15]
setblock 552 109 310 minecraft:light[level=15]
setblock 552 109 312 minecraft:shroomlight
fill 553 109 278 554 112 278 minecraft:orange_terracotta
setblock 554 109 286 minecraft:shroomlight
setblock 554 109 292 minecraft:shroomlight
setblock 554 109 298 minecraft:shroomlight
setblock 554 109 304 minecraft:shroomlight
setblock 554 109 310 minecraft:shroomlight
setblock 555 109 278 minecraft:light[level=12]
setblock 555 109 285 minecraft:light[level=12]
setblock 555 109 292 minecraft:light[level=12]
setblock 555 109 299 minecraft:light[level=12]
setblock 555 109 306 minecraft:light[level=12]
setblock 555 109 313 minecraft:light[level=12]
setblock 557 109 294 minecraft:brown_terracotta
fill 518 110 277 522 110 285 minecraft:white_concrete
fill 518 110 289 519 110 297 minecraft:white_concrete
fill 518 110 301 522 110 309 minecraft:white_concrete
fill 518 110 313 520 110 316 minecraft:white_concrete
fill 519 110 286 519 110 288 minecraft:white_concrete
fill 519 110 298 522 110 300 minecraft:white_concrete
fill 519 110 310 520 110 312 minecraft:white_concrete
fill 520 110 286 522 110 287 minecraft:white_concrete
fill 520 110 293 522 110 297 minecraft:white_concrete
fill 521 110 276 529 110 276 minecraft:white_concrete
fill 521 110 310 521 110 311 minecraft:white_concrete
fill 521 110 315 523 110 316 minecraft:white_concrete
setblock 522 110 310 minecraft:white_concrete
setblock 522 110 312 minecraft:white_concrete
fill 523 110 277 549 110 280 minecraft:white_concrete
fill 524 110 312 558 110 315 minecraft:white_concrete
fill 527 110 316 535 110 316 minecraft:white_concrete
fill 533 110 276 541 110 276 minecraft:white_concrete
fill 538 110 284 539 111 285 minecraft:lime_concrete
fill 539 110 316 547 110 316 minecraft:white_concrete
fill 545 110 276 549 110 276 minecraft:white_concrete
setblock 546 110 288 minecraft:spruce_leaves[persistent=true]
fill 547 110 292 548 110 292 minecraft:spruce_leaves[persistent=true]
fill 551 110 316 558 110 316 minecraft:white_concrete
fill 554 110 281 557 110 311 minecraft:white_concrete
fill 555 110 277 558 110 280 minecraft:white_concrete
fill 557 110 276 558 110 276 minecraft:white_concrete
fill 558 110 281 558 110 283 minecraft:white_concrete
fill 558 110 287 558 110 295 minecraft:white_concrete
fill 558 110 299 558 110 307 minecraft:white_concrete
setblock 558 110 311 minecraft:white_concrete
fill 522 111 276 529 111 279 minecraft:white_concrete
fill 522 111 280 522 111 287 minecraft:red_concrete
fill 522 111 290 522 112 290 minecraft:orange_terracotta
fill 522 111 293 522 111 312 minecraft:red_concrete
fill 523 111 280 549 111 280 minecraft:red_concrete
fill 523 111 312 554 111 312 minecraft:red_concrete
fill 530 111 277 530 111 279 minecraft:white_concrete
fill 552 111 278 552 112 278 minecraft:orange_terracotta
fill 554 111 281 554 111 283 minecraft:red_concrete
fill 554 111 284 558 111 288 minecraft:orange_terracotta
fill 554 111 289 554 111 311 minecraft:red_concrete
setblock 517 112 277 minecraft:white_concrete
setblock 517 112 281 minecraft:white_concrete
fill 517 112 282 517 112 283 minecraft:shroomlight
setblock 517 112 284 minecraft:brown_terracotta
setblock 517 112 285 minecraft:white_concrete
setblock 517 112 289 minecraft:white_concrete
setblock 517 112 293 minecraft:white_concrete
fill 517 112 294 517 112 295 minecraft:shroomlight
setblock 517 112 296 minecraft:brown_terracotta
setblock 517 112 297 minecraft:white_concrete
setblock 517 112 301 minecraft:white_concrete
setblock 517 112 305 minecraft:white_concrete
fill 517 112 306 517 112 307 minecraft:shroomlight
setblock 517 112 308 minecraft:brown_terracotta
setblock 517 112 309 minecraft:white_concrete
setblock 517 112 313 minecraft:white_concrete
schedule function dropper:buildpart/71_2 1t
