setblock 330 54 492 minecraft:red_nether_bricks
fill 330 54 493 330 57 493 minecraft:pink_terracotta
setblock 330 54 496 minecraft:white_concrete
fill 331 54 464 331 54 465 minecraft:pink_terracotta
setblock 331 54 466 minecraft:red_nether_bricks
fill 331 54 467 331 57 467 minecraft:pink_terracotta
setblock 331 54 471 minecraft:red_nether_bricks
fill 331 54 472 331 57 472 minecraft:pink_terracotta
setblock 331 54 476 minecraft:red_nether_bricks
fill 331 54 477 331 57 477 minecraft:pink_terracotta
setblock 331 54 481 minecraft:red_nether_bricks
fill 331 54 482 331 57 482 minecraft:pink_terracotta
setblock 331 54 486 minecraft:red_nether_bricks
fill 331 54 487 331 57 487 minecraft:pink_terracotta
setblock 331 54 491 minecraft:red_nether_bricks
fill 331 54 492 331 57 492 minecraft:pink_terracotta
setblock 332 54 464 minecraft:pink_terracotta
setblock 332 54 465 minecraft:red_nether_bricks
fill 332 54 466 332 57 466 minecraft:pink_terracotta
setblock 332 54 470 minecraft:red_nether_bricks
setblock 332 54 485 minecraft:red_nether_bricks
fill 332 54 486 332 56 486 minecraft:pink_terracotta
setblock 332 54 490 minecraft:red_nether_bricks
setblock 333 54 464 minecraft:red_nether_bricks
fill 333 54 465 333 57 465 minecraft:pink_terracotta
setblock 333 54 504 minecraft:red_nether_bricks
fill 334 54 464 334 57 464 minecraft:pink_terracotta
setblock 337 54 465 minecraft:red_nether_bricks
setblock 338 54 464 minecraft:red_nether_bricks
setblock 338 54 465 minecraft:pink_terracotta
fill 339 54 464 339 57 464 minecraft:pink_terracotta
setblock 342 54 465 minecraft:red_nether_bricks
setblock 343 54 464 minecraft:red_nether_bricks
fill 343 54 465 343 57 465 minecraft:pink_terracotta
fill 344 54 464 344 57 464 minecraft:pink_terracotta
setblock 346 54 466 minecraft:red_nether_bricks
setblock 347 54 465 minecraft:red_nether_bricks
fill 347 54 466 347 57 466 minecraft:pink_terracotta
setblock 348 54 464 minecraft:red_nether_bricks
fill 348 54 465 348 57 465 minecraft:pink_terracotta
setblock 348 54 504 minecraft:red_nether_bricks
fill 349 54 464 349 57 464 minecraft:pink_terracotta
setblock 349 54 503 minecraft:red_nether_bricks
fill 349 54 504 349 57 504 minecraft:pink_terracotta
setblock 350 54 466 minecraft:pink_terracotta
fill 350 54 503 350 57 503 minecraft:pink_terracotta
setblock 351 54 466 minecraft:red_nether_bricks
setblock 352 54 465 minecraft:red_nether_bricks
fill 352 54 466 352 57 466 minecraft:pink_terracotta
setblock 353 54 464 minecraft:red_nether_bricks
fill 353 54 465 353 57 465 minecraft:pink_terracotta
setblock 353 54 504 minecraft:red_nether_bricks
fill 354 54 464 354 57 464 minecraft:pink_terracotta
setblock 354 54 503 minecraft:red_nether_bricks
fill 354 54 504 354 57 504 minecraft:pink_terracotta
fill 355 54 503 356 54 503 minecraft:pink_terracotta
setblock 358 54 464 minecraft:red_nether_bricks
setblock 358 54 504 minecraft:red_nether_bricks
setblock 359 54 464 minecraft:pink_terracotta
setblock 359 54 504 minecraft:pink_terracotta
setblock 368 54 464 minecraft:red_nether_bricks
setblock 368 54 484 minecraft:red_nether_bricks
fill 368 54 485 368 57 485 minecraft:pink_terracotta
setblock 368 54 489 minecraft:red_nether_bricks
fill 368 54 490 368 57 490 minecraft:pink_terracotta
fill 368 54 492 368 55 492 minecraft:pink_terracotta
setblock 368 54 504 minecraft:red_nether_bricks
fill 369 54 464 369 57 464 minecraft:pink_terracotta
setblock 369 54 483 minecraft:red_nether_bricks
fill 369 54 484 369 57 484 minecraft:pink_terracotta
setblock 369 54 488 minecraft:red_nether_bricks
fill 369 54 489 369 57 489 minecraft:pink_terracotta
setblock 369 54 493 minecraft:red_nether_bricks
fill 369 54 494 369 57 494 minecraft:pink_terracotta
fill 369 54 504 369 57 504 minecraft:pink_terracotta
setblock 370 54 467 minecraft:red_nether_bricks
fill 370 54 468 370 57 468 minecraft:pink_terracotta
setblock 370 54 472 minecraft:red_nether_bricks
fill 370 54 473 370 56 474 minecraft:pink_terracotta
setblock 370 54 476 minecraft:pink_terracotta
setblock 370 54 477 minecraft:red_nether_bricks
fill 370 54 478 370 57 478 minecraft:pink_terracotta
setblock 370 54 482 minecraft:red_nether_bricks
fill 370 54 483 370 57 483 minecraft:pink_terracotta
setblock 370 54 487 minecraft:red_nether_bricks
fill 370 54 488 370 57 488 minecraft:pink_terracotta
setblock 370 54 492 minecraft:red_nether_bricks
fill 370 54 493 370 57 493 minecraft:pink_terracotta
setblock 370 54 497 minecraft:red_nether_bricks
fill 370 54 498 370 57 498 minecraft:pink_terracotta
setblock 370 54 502 minecraft:red_nether_bricks
fill 370 54 503 370 56 503 minecraft:pink_terracotta
fill 330 55 464 330 55 465 minecraft:pink_terracotta
setblock 330 55 466 minecraft:red_nether_bricks
fill 330 55 467 330 58 467 minecraft:pink_terracotta
setblock 330 55 471 minecraft:red_nether_bricks
fill 330 55 472 330 58 472 minecraft:pink_terracotta
setblock 330 55 476 minecraft:red_nether_bricks
fill 330 55 477 330 58 477 minecraft:pink_terracotta
setblock 330 55 481 minecraft:red_nether_bricks
fill 330 55 482 330 58 482 minecraft:pink_terracotta
setblock 330 55 486 minecraft:red_nether_bricks
fill 330 55 487 330 58 487 minecraft:pink_terracotta
setblock 330 55 491 minecraft:red_nether_bricks
fill 330 55 492 330 58 492 minecraft:pink_terracotta
setblock 330 55 502 minecraft:white_concrete
setblock 331 55 464 minecraft:pink_terracotta
setblock 331 55 465 minecraft:red_nether_bricks
fill 331 55 466 331 58 466 minecraft:pink_terracotta
setblock 331 55 470 minecraft:red_nether_bricks
fill 331 55 471 331 58 471 minecraft:pink_terracotta
setblock 331 55 475 minecraft:red_nether_bricks
fill 331 55 476 331 58 476 minecraft:pink_terracotta
setblock 331 55 480 minecraft:red_nether_bricks
fill 331 55 481 331 58 481 minecraft:pink_terracotta
setblock 331 55 485 minecraft:red_nether_bricks
fill 331 55 486 331 58 486 minecraft:pink_terracotta
setblock 331 55 490 minecraft:red_nether_bricks
fill 331 55 491 331 58 491 minecraft:pink_terracotta
setblock 332 55 464 minecraft:red_nether_bricks
fill 332 55 465 332 58 465 minecraft:pink_terracotta
setblock 332 55 469 minecraft:red_nether_bricks
fill 332 55 470 332 58 470 minecraft:pink_terracotta
setblock 332 55 474 minecraft:light[level=12]
setblock 332 55 482 minecraft:light[level=12]
setblock 332 55 484 minecraft:red_nether_bricks
setblock 332 55 485 minecraft:pink_terracotta
setblock 332 55 489 minecraft:red_nether_bricks
setblock 332 55 490 minecraft:light[level=12]
setblock 332 55 498 minecraft:light[level=12]
fill 333 55 464 333 58 464 minecraft:pink_terracotta
setblock 336 55 465 minecraft:red_nether_bricks
setblock 337 55 464 minecraft:red_nether_bricks
setblock 337 55 465 minecraft:pink_terracotta
fill 338 55 464 338 58 464 minecraft:pink_terracotta
setblock 340 55 466 minecraft:light[level=12]
setblock 340 55 474 minecraft:light[level=12]
setblock 340 55 482 minecraft:light[level=12]
setblock 340 55 490 minecraft:light[level=12]
setblock 340 55 498 minecraft:light[level=12]
setblock 342 55 464 minecraft:red_nether_bricks
fill 342 55 465 342 58 465 minecraft:pink_terracotta
fill 343 55 464 343 58 464 minecraft:pink_terracotta
setblock 345 55 465 minecraft:pink_terracotta
setblock 345 55 466 minecraft:red_nether_bricks
setblock 346 55 465 minecraft:red_nether_bricks
fill 346 55 466 346 58 466 minecraft:pink_terracotta
setblock 347 55 464 minecraft:red_nether_bricks
fill 347 55 465 347 58 465 minecraft:pink_terracotta
setblock 347 55 504 minecraft:red_nether_bricks
fill 348 55 464 348 58 464 minecraft:pink_terracotta
setblock 348 55 474 minecraft:light[level=12]
setblock 348 55 482 minecraft:light[level=12]
setblock 348 55 490 minecraft:light[level=12]
setblock 348 55 498 minecraft:light[level=12]
setblock 348 55 503 minecraft:red_nether_bricks
fill 348 55 504 348 58 504 minecraft:pink_terracotta
fill 349 55 503 349 58 503 minecraft:pink_terracotta
setblock 350 55 466 minecraft:red_nether_bricks
setblock 351 55 465 minecraft:red_nether_bricks
fill 351 55 466 351 58 466 minecraft:pink_terracotta
setblock 352 55 464 minecraft:red_nether_bricks
fill 352 55 465 352 58 465 minecraft:pink_terracotta
setblock 352 55 504 minecraft:red_nether_bricks
fill 353 55 464 353 58 464 minecraft:pink_terracotta
setblock 353 55 503 minecraft:red_nether_bricks
fill 353 55 504 353 58 504 minecraft:pink_terracotta
setblock 354 55 503 minecraft:pink_terracotta
setblock 356 55 466 minecraft:light[level=12]
setblock 356 55 474 minecraft:light[level=12]
setblock 356 55 482 minecraft:light[level=12]
setblock 356 55 490 minecraft:light[level=12]
setblock 356 55 498 minecraft:light[level=12]
setblock 357 55 464 minecraft:red_nether_bricks
setblock 357 55 504 minecraft:red_nether_bricks
setblock 358 55 464 minecraft:pink_terracotta
setblock 358 55 504 minecraft:pink_terracotta
setblock 364 55 466 minecraft:light[level=12]
setblock 364 55 474 minecraft:light[level=12]
setblock 364 55 482 minecraft:light[level=12]
setblock 364 55 490 minecraft:light[level=12]
setblock 364 55 498 minecraft:light[level=12]
setblock 367 55 464 minecraft:red_nether_bricks
setblock 367 55 504 minecraft:red_nether_bricks
fill 368 55 464 368 58 464 minecraft:pink_terracotta
setblock 368 55 488 minecraft:red_nether_bricks
fill 368 55 489 368 58 489 minecraft:pink_terracotta
setblock 368 55 493 minecraft:red_nether_bricks
fill 368 55 504 368 58 504 minecraft:pink_terracotta
setblock 369 55 467 minecraft:red_nether_bricks
fill 369 55 468 369 58 468 minecraft:pink_terracotta
setblock 369 55 482 minecraft:red_nether_bricks
fill 369 55 483 369 58 483 minecraft:pink_terracotta
setblock 369 55 487 minecraft:red_nether_bricks
fill 369 55 488 369 58 488 minecraft:pink_terracotta
setblock 369 55 492 minecraft:red_nether_bricks
fill 369 55 493 369 58 493 minecraft:pink_terracotta
setblock 370 55 466 minecraft:red_nether_bricks
fill 370 55 467 370 58 467 minecraft:pink_terracotta
setblock 370 55 470 minecraft:pink_terracotta
setblock 370 55 471 minecraft:red_nether_bricks
fill 370 55 472 370 58 472 minecraft:pink_terracotta
setblock 370 55 475 minecraft:pink_terracotta
setblock 370 55 476 minecraft:red_nether_bricks
fill 370 55 477 370 58 477 minecraft:pink_terracotta
setblock 370 55 481 minecraft:red_nether_bricks
fill 370 55 482 370 58 482 minecraft:pink_terracotta
setblock 370 55 486 minecraft:red_nether_bricks
fill 370 55 487 370 58 487 minecraft:pink_terracotta
setblock 370 55 491 minecraft:red_nether_bricks
fill 370 55 492 370 58 492 minecraft:pink_terracotta
setblock 370 55 496 minecraft:red_nether_bricks
fill 370 55 497 370 58 497 minecraft:pink_terracotta
setblock 370 55 501 minecraft:red_nether_bricks
setblock 370 55 502 minecraft:pink_terracotta
setblock 330 56 464 minecraft:pink_terracotta
setblock 330 56 465 minecraft:red_nether_bricks
fill 330 56 466 330 59 466 minecraft:pink_terracotta
setblock 330 56 470 minecraft:red_nether_bricks
fill 330 56 471 330 59 471 minecraft:pink_terracotta
setblock 330 56 475 minecraft:red_nether_bricks
fill 330 56 476 330 59 476 minecraft:pink_terracotta
setblock 330 56 480 minecraft:red_nether_bricks
fill 330 56 481 330 59 481 minecraft:pink_terracotta
setblock 330 56 485 minecraft:red_nether_bricks
fill 330 56 486 330 59 486 minecraft:pink_terracotta
setblock 330 56 490 minecraft:red_nether_bricks
fill 330 56 491 330 59 491 minecraft:pink_terracotta
setblock 330 56 495 minecraft:red_nether_bricks
setblock 331 56 464 minecraft:red_nether_bricks
fill 331 56 465 331 59 465 minecraft:pink_terracotta
setblock 331 56 469 minecraft:red_nether_bricks
fill 331 56 470 331 59 470 minecraft:pink_terracotta
setblock 331 56 474 minecraft:red_nether_bricks
fill 331 56 475 331 59 475 minecraft:pink_terracotta
setblock 331 56 479 minecraft:red_nether_bricks
fill 331 56 480 331 59 480 minecraft:pink_terracotta
setblock 331 56 484 minecraft:red_nether_bricks
fill 331 56 485 331 59 485 minecraft:pink_terracotta
setblock 331 56 489 minecraft:red_nether_bricks
fill 331 56 490 331 59 490 minecraft:pink_terracotta
setblock 331 56 493 minecraft:pink_terracotta
fill 332 56 464 332 59 464 minecraft:pink_terracotta
setblock 332 56 468 minecraft:red_nether_bricks
fill 332 56 469 332 59 469 minecraft:pink_terracotta
fill 332 56 471 332 57 471 minecraft:pink_terracotta
setblock 332 56 488 minecraft:red_nether_bricks
setblock 334 56 504 minecraft:white_concrete
setblock 335 56 465 minecraft:red_nether_bricks
setblock 336 56 464 minecraft:red_nether_bricks
setblock 336 56 465 minecraft:pink_terracotta
fill 337 56 464 337 59 464 minecraft:pink_terracotta
setblock 341 56 464 minecraft:red_nether_bricks
fill 342 56 464 342 59 464 minecraft:pink_terracotta
setblock 345 56 465 minecraft:red_nether_bricks
fill 345 56 466 345 59 466 minecraft:pink_terracotta
setblock 346 56 464 minecraft:red_nether_bricks
fill 346 56 465 346 59 465 minecraft:pink_terracotta
setblock 346 56 504 minecraft:red_nether_bricks
fill 347 56 464 347 59 464 minecraft:pink_terracotta
fill 347 56 504 347 59 504 minecraft:pink_terracotta
fill 348 56 503 348 59 503 minecraft:pink_terracotta
setblock 349 56 466 minecraft:red_nether_bricks
setblock 350 56 465 minecraft:red_nether_bricks
fill 350 56 466 350 59 466 minecraft:pink_terracotta
setblock 351 56 464 minecraft:red_nether_bricks
fill 351 56 465 351 59 465 minecraft:pink_terracotta
setblock 351 56 504 minecraft:red_nether_bricks
fill 352 56 464 352 59 464 minecraft:pink_terracotta
setblock 352 56 503 minecraft:red_nether_bricks
fill 352 56 504 352 59 504 minecraft:pink_terracotta
setblock 353 56 503 minecraft:pink_terracotta
setblock 355 56 465 minecraft:red_nether_bricks
setblock 356 56 464 minecraft:red_nether_bricks
setblock 356 56 504 minecraft:red_nether_bricks
setblock 357 56 464 minecraft:pink_terracotta
setblock 357 56 504 minecraft:pink_terracotta
setblock 359 56 504 minecraft:white_concrete
setblock 360 56 464 minecraft:white_concrete
setblock 366 56 464 minecraft:red_nether_bricks
fill 367 56 464 367 59 464 minecraft:pink_terracotta
fill 367 56 504 367 59 504 minecraft:pink_terracotta
setblock 368 56 487 minecraft:red_nether_bricks
fill 368 56 488 368 59 488 minecraft:pink_terracotta
setblock 368 56 492 minecraft:red_nether_bricks
fill 368 56 493 368 59 493 minecraft:pink_terracotta
setblock 369 56 466 minecraft:red_nether_bricks
fill 369 56 467 369 59 467 minecraft:pink_terracotta
fill 369 56 469 369 56 470 minecraft:pink_terracotta
setblock 369 56 481 minecraft:red_nether_bricks
fill 369 56 482 369 59 482 minecraft:pink_terracotta
setblock 369 56 486 minecraft:red_nether_bricks
fill 369 56 487 369 59 487 minecraft:pink_terracotta
setblock 369 56 491 minecraft:red_nether_bricks
fill 369 56 492 369 59 492 minecraft:pink_terracotta
setblock 369 56 496 minecraft:red_nether_bricks
setblock 370 56 465 minecraft:red_nether_bricks
fill 370 56 466 370 59 466 minecraft:pink_terracotta
setblock 370 56 470 minecraft:red_nether_bricks
fill 370 56 471 370 59 471 minecraft:pink_terracotta
setblock 370 56 475 minecraft:red_nether_bricks
fill 370 56 476 370 59 476 minecraft:pink_terracotta
setblock 370 56 480 minecraft:red_nether_bricks
fill 370 56 481 370 59 481 minecraft:pink_terracotta
setblock 370 56 485 minecraft:red_nether_bricks
fill 370 56 486 370 59 486 minecraft:pink_terracotta
setblock 370 56 490 minecraft:red_nether_bricks
fill 370 56 491 370 59 491 minecraft:pink_terracotta
setblock 370 56 495 minecraft:red_nether_bricks
fill 370 56 496 370 59 496 minecraft:pink_terracotta
setblock 330 57 464 minecraft:red_nether_bricks
fill 330 57 465 330 60 465 minecraft:pink_terracotta
setblock 330 57 469 minecraft:red_nether_bricks
fill 330 57 470 330 60 470 minecraft:pink_terracotta
setblock 330 57 474 minecraft:red_nether_bricks
fill 330 57 475 330 60 475 minecraft:pink_terracotta
setblock 330 57 479 minecraft:red_nether_bricks
fill 330 57 480 330 60 480 minecraft:pink_terracotta
setblock 330 57 484 minecraft:red_nether_bricks
fill 330 57 485 330 60 485 minecraft:pink_terracotta
setblock 330 57 489 minecraft:red_nether_bricks
fill 330 57 490 330 60 490 minecraft:pink_terracotta
setblock 330 57 494 minecraft:red_nether_bricks
fill 330 57 495 330 59 496 minecraft:pink_terracotta
fill 331 57 464 331 60 464 minecraft:pink_terracotta
setblock 331 57 468 minecraft:red_nether_bricks
fill 331 57 469 331 60 469 minecraft:pink_terracotta
setblock 331 57 473 minecraft:red_nether_bricks
fill 331 57 474 331 60 474 minecraft:pink_terracotta
setblock 331 57 478 minecraft:red_nether_bricks
fill 331 57 479 331 60 479 minecraft:pink_terracotta
setblock 331 57 483 minecraft:red_nether_bricks
fill 331 57 484 331 60 484 minecraft:pink_terracotta
setblock 331 57 488 minecraft:red_nether_bricks
fill 331 57 489 331 60 489 minecraft:pink_terracotta
setblock 331 57 493 minecraft:red_nether_bricks
setblock 332 57 467 minecraft:red_nether_bricks
fill 332 57 468 332 60 468 minecraft:pink_terracotta
setblock 332 57 472 minecraft:red_nether_bricks
setblock 334 57 465 minecraft:red_nether_bricks
setblock 335 57 464 minecraft:red_nether_bricks
setblock 335 57 465 minecraft:pink_terracotta
fill 336 57 464 336 60 464 minecraft:pink_terracotta
setblock 340 57 464 minecraft:red_nether_bricks
setblock 340 57 504 minecraft:white_concrete
fill 341 57 464 341 59 465 minecraft:pink_terracotta
setblock 344 57 465 minecraft:red_nether_bricks
fill 344 57 466 344 60 466 minecraft:pink_terracotta
setblock 345 57 464 minecraft:red_nether_bricks
fill 345 57 465 345 60 465 minecraft:pink_terracotta
setblock 345 57 504 minecraft:red_nether_bricks
fill 346 57 464 346 60 464 minecraft:pink_terracotta
fill 346 57 504 346 60 504 minecraft:pink_terracotta
setblock 348 57 466 minecraft:red_nether_bricks
setblock 349 57 465 minecraft:red_nether_bricks
fill 349 57 466 349 60 466 minecraft:pink_terracotta
setblock 350 57 464 minecraft:red_nether_bricks
fill 350 57 465 350 60 465 minecraft:pink_terracotta
setblock 350 57 504 minecraft:red_nether_bricks
fill 351 57 464 351 60 464 minecraft:pink_terracotta
setblock 351 57 503 minecraft:red_nether_bricks
fill 351 57 504 351 60 504 minecraft:pink_terracotta
fill 352 57 503 352 60 503 minecraft:pink_terracotta
setblock 354 57 465 minecraft:red_nether_bricks
setblock 355 57 464 minecraft:red_nether_bricks
setblock 355 57 504 minecraft:red_nether_bricks
setblock 356 57 464 minecraft:pink_terracotta
setblock 356 57 504 minecraft:pink_terracotta
setblock 365 57 504 minecraft:white_concrete
fill 366 57 464 366 60 464 minecraft:pink_terracotta
fill 367 57 489 367 57 491 minecraft:pink_terracotta
setblock 368 57 486 minecraft:red_nether_bricks
fill 368 57 487 368 60 487 minecraft:pink_terracotta
setblock 368 57 491 minecraft:red_nether_bricks
fill 368 57 492 368 60 492 minecraft:pink_terracotta
fill 368 57 494 368 58 494 minecraft:pink_terracotta
fill 369 57 466 369 60 466 minecraft:pink_terracotta
setblock 369 57 469 minecraft:pink_terracotta
setblock 369 57 470 minecraft:red_nether_bricks
fill 369 57 471 369 58 473 minecraft:pink_terracotta
fill 369 57 481 369 60 481 minecraft:pink_terracotta
setblock 369 57 485 minecraft:red_nether_bricks
fill 369 57 486 369 60 486 minecraft:pink_terracotta
setblock 369 57 490 minecraft:red_nether_bricks
fill 369 57 491 369 60 491 minecraft:pink_terracotta
setblock 369 57 495 minecraft:red_nether_bricks
fill 369 57 496 369 59 497 minecraft:pink_terracotta
setblock 370 57 464 minecraft:red_nether_bricks
fill 370 57 465 370 60 465 minecraft:pink_terracotta
setblock 370 57 469 minecraft:red_nether_bricks
fill 370 57 470 370 60 470 minecraft:pink_terracotta
setblock 370 57 473 minecraft:pink_terracotta
setblock 370 57 474 minecraft:red_nether_bricks
fill 370 57 475 370 60 475 minecraft:pink_terracotta
setblock 370 57 479 minecraft:red_nether_bricks
fill 370 57 480 370 60 480 minecraft:pink_terracotta
setblock 370 57 484 minecraft:red_nether_bricks
fill 370 57 485 370 60 485 minecraft:pink_terracotta
setblock 370 57 489 minecraft:red_nether_bricks
fill 370 57 490 370 60 490 minecraft:pink_terracotta
setblock 370 57 494 minecraft:red_nether_bricks
fill 370 57 495 370 60 495 minecraft:pink_terracotta
setblock 370 57 499 minecraft:red_nether_bricks
fill 330 58 464 330 61 464 minecraft:pink_terracotta
setblock 330 58 468 minecraft:red_nether_bricks
fill 330 58 469 330 61 469 minecraft:pink_terracotta
setblock 330 58 473 minecraft:red_nether_bricks
fill 330 58 474 330 61 474 minecraft:pink_terracotta
setblock 330 58 478 minecraft:red_nether_bricks
fill 330 58 479 330 61 479 minecraft:pink_terracotta
setblock 330 58 483 minecraft:red_nether_bricks
fill 330 58 484 330 61 484 minecraft:pink_terracotta
setblock 330 58 488 minecraft:red_nether_bricks
fill 330 58 489 330 61 489 minecraft:pink_terracotta
setblock 330 58 493 minecraft:red_nether_bricks
fill 330 58 494 330 61 494 minecraft:pink_terracotta
setblock 330 58 497 minecraft:pink_terracotta
setblock 330 58 501 minecraft:white_concrete
setblock 331 58 467 minecraft:red_nether_bricks
fill 331 58 468 331 61 468 minecraft:pink_terracotta
setblock 331 58 472 minecraft:red_nether_bricks
fill 331 58 473 332 60 473 minecraft:pink_terracotta
setblock 331 58 477 minecraft:red_nether_bricks
fill 331 58 478 331 61 478 minecraft:pink_terracotta
setblock 331 58 482 minecraft:red_nether_bricks
fill 331 58 483 331 59 483 minecraft:pink_terracotta
setblock 331 58 487 minecraft:red_nether_bricks
fill 331 58 488 331 61 488 minecraft:pink_terracotta
setblock 331 58 492 minecraft:red_nether_bricks
fill 331 58 493 331 61 493 minecraft:pink_terracotta
fill 332 58 467 332 61 467 minecraft:pink_terracotta
setblock 332 58 471 minecraft:red_nether_bricks
fill 332 58 472 332 61 472 minecraft:pink_terracotta
setblock 333 58 465 minecraft:red_nether_bricks
setblock 334 58 464 minecraft:red_nether_bricks
fill 334 58 465 334 60 465 minecraft:pink_terracotta
fill 335 58 464 335 61 464 minecraft:pink_terracotta
setblock 339 58 464 minecraft:red_nether_bricks
fill 340 58 464 340 61 464 minecraft:pink_terracotta
setblock 343 58 465 minecraft:red_nether_bricks
setblock 344 58 464 minecraft:red_nether_bricks
fill 344 58 465 344 61 465 minecraft:pink_terracotta
setblock 344 58 504 minecraft:red_nether_bricks
fill 345 58 464 345 61 464 minecraft:pink_terracotta
fill 345 58 504 345 61 504 minecraft:pink_terracotta
setblock 347 58 466 minecraft:red_nether_bricks
fill 347 58 503 347 60 503 minecraft:pink_terracotta
setblock 348 58 465 minecraft:red_nether_bricks
fill 348 58 466 348 60 467 minecraft:pink_terracotta
setblock 349 58 464 minecraft:red_nether_bricks
fill 349 58 465 349 61 465 minecraft:pink_terracotta
setblock 349 58 504 minecraft:red_nether_bricks
fill 350 58 464 350 61 464 minecraft:pink_terracotta
setblock 350 58 503 minecraft:red_nether_bricks
fill 350 58 504 350 61 504 minecraft:pink_terracotta
fill 351 58 503 351 61 503 minecraft:pink_terracotta
fill 352 58 466 352 82 466 minecraft:red_nether_bricks
setblock 353 58 465 minecraft:red_nether_bricks
setblock 354 58 464 minecraft:red_nether_bricks
setblock 354 58 504 minecraft:red_nether_bricks
setblock 355 58 464 minecraft:pink_terracotta
fill 355 58 504 355 59 504 minecraft:pink_terracotta
fill 367 58 488 367 58 490 minecraft:pink_terracotta
setblock 367 58 491 minecraft:red_nether_bricks
fill 367 58 492 367 61 492 minecraft:pink_terracotta
setblock 368 58 484 minecraft:pink_terracotta
setblock 368 58 485 minecraft:red_nether_bricks
fill 368 58 486 368 61 486 minecraft:pink_terracotta
setblock 368 58 490 minecraft:red_nether_bricks
fill 368 58 491 368 61 491 minecraft:pink_terracotta
setblock 368 58 495 minecraft:red_nether_bricks
setblock 369 58 464 minecraft:red_nether_bricks
setblock 369 58 469 minecraft:red_nether_bricks
fill 369 58 470 369 61 470 minecraft:pink_terracotta
setblock 369 58 474 minecraft:red_nether_bricks
fill 369 58 475 369 60 476 minecraft:pink_terracotta
fill 369 58 480 369 61 480 minecraft:pink_terracotta
setblock 369 58 484 minecraft:red_nether_bricks
fill 369 58 485 369 61 485 minecraft:pink_terracotta
setblock 369 58 489 minecraft:red_nether_bricks
fill 369 58 490 369 61 490 minecraft:pink_terracotta
setblock 369 58 494 minecraft:red_nether_bricks
fill 369 58 495 369 61 495 minecraft:pink_terracotta
setblock 369 58 504 minecraft:red_nether_bricks
fill 370 58 464 370 61 464 minecraft:pink_terracotta
setblock 370 58 468 minecraft:red_nether_bricks
fill 370 58 469 370 61 469 minecraft:pink_terracotta
setblock 370 58 473 minecraft:red_nether_bricks
fill 370 58 474 370 61 474 minecraft:pink_terracotta
setblock 370 58 478 minecraft:red_nether_bricks
fill 370 58 479 370 61 479 minecraft:pink_terracotta
setblock 370 58 483 minecraft:red_nether_bricks
fill 370 58 484 370 61 484 minecraft:pink_terracotta
setblock 370 58 488 minecraft:red_nether_bricks
fill 370 58 489 370 61 489 minecraft:pink_terracotta
setblock 370 58 493 minecraft:red_nether_bricks
fill 370 58 494 370 61 494 minecraft:pink_terracotta
setblock 370 58 498 minecraft:red_nether_bricks
fill 370 58 499 370 60 500 minecraft:pink_terracotta
setblock 330 59 467 minecraft:red_nether_bricks
fill 330 59 468 330 62 468 minecraft:pink_terracotta
setblock 330 59 472 minecraft:red_nether_bricks
fill 330 59 473 330 62 473 minecraft:pink_terracotta
setblock 330 59 477 minecraft:red_nether_bricks
fill 330 59 478 330 62 478 minecraft:pink_terracotta
setblock 330 59 482 minecraft:red_nether_bricks
fill 330 59 483 330 62 483 minecraft:pink_terracotta
setblock 330 59 487 minecraft:red_nether_bricks
fill 330 59 488 330 62 488 minecraft:pink_terracotta
setblock 330 59 492 minecraft:red_nether_bricks
fill 330 59 493 330 62 493 minecraft:pink_terracotta
setblock 330 59 497 minecraft:red_nether_bricks
setblock 331 59 466 minecraft:red_nether_bricks
fill 331 59 467 331 62 467 minecraft:pink_terracotta
setblock 331 59 471 minecraft:red_nether_bricks
fill 331 59 472 331 62 472 minecraft:pink_terracotta
setblock 331 59 476 minecraft:red_nether_bricks
fill 331 59 477 331 62 477 minecraft:pink_terracotta
setblock 331 59 482 minecraft:pink_terracotta
setblock 331 59 486 minecraft:red_nether_bricks
fill 331 59 487 331 61 487 minecraft:pink_terracotta
setblock 331 59 491 minecraft:red_nether_bricks
fill 331 59 492 331 62 492 minecraft:pink_terracotta
fill 331 59 494 331 60 494 minecraft:pink_terracotta
setblock 332 59 465 minecraft:red_nether_bricks
setblock 332 59 470 minecraft:red_nether_bricks
fill 332 59 471 332 62 471 minecraft:pink_terracotta
setblock 332 59 474 minecraft:pink_terracotta
setblock 333 59 464 minecraft:red_nether_bricks
fill 333 59 465 333 61 465 minecraft:pink_terracotta
setblock 333 59 504 minecraft:white_concrete
fill 334 59 464 334 62 464 minecraft:pink_terracotta
setblock 338 59 464 minecraft:red_nether_bricks
fill 339 59 464 339 62 464 minecraft:pink_terracotta
fill 340 59 465 340 60 465 minecraft:pink_terracotta
setblock 342 59 465 minecraft:red_nether_bricks
setblock 343 59 464 minecraft:red_nether_bricks
fill 343 59 465 343 61 466 minecraft:pink_terracotta
setblock 343 59 504 minecraft:red_nether_bricks
fill 344 59 464 344 62 464 minecraft:pink_terracotta
fill 344 59 504 344 62 504 minecraft:pink_terracotta
setblock 346 59 466 minecraft:red_nether_bricks
fill 346 59 467 347 61 467 minecraft:pink_terracotta
fill 346 59 503 346 61 503 minecraft:pink_terracotta
setblock 347 59 465 minecraft:red_nether_bricks
fill 347 59 466 347 62 466 minecraft:pink_terracotta
setblock 348 59 464 minecraft:red_nether_bricks
fill 348 59 465 348 62 465 minecraft:pink_terracotta
setblock 348 59 504 minecraft:red_nether_bricks
fill 349 59 464 349 62 464 minecraft:pink_terracotta
setblock 349 59 503 minecraft:red_nether_bricks
fill 349 59 504 349 62 504 minecraft:pink_terracotta
fill 350 59 503 350 62 503 minecraft:pink_terracotta
fill 351 59 466 351 82 466 minecraft:red_nether_bricks
setblock 352 59 465 minecraft:red_nether_bricks
setblock 353 59 464 minecraft:red_nether_bricks
setblock 353 59 465 minecraft:pink_terracotta
setblock 353 59 504 minecraft:red_nether_bricks
fill 354 59 464 354 60 464 minecraft:pink_terracotta
fill 354 59 504 354 62 504 minecraft:pink_terracotta
setblock 358 59 504 minecraft:white_concrete
fill 365 59 464 365 61 464 minecraft:pink_terracotta
fill 366 59 504 366 60 504 minecraft:pink_terracotta
fill 367 59 487 367 59 489 minecraft:pink_terracotta
setblock 367 59 490 minecraft:red_nether_bricks
fill 367 59 491 367 62 491 minecraft:pink_terracotta
fill 367 59 493 367 59 494 minecraft:pink_terracotta
setblock 368 59 464 minecraft:red_nether_bricks
fill 368 59 470 368 60 472 minecraft:pink_terracotta
setblock 368 59 484 minecraft:red_nether_bricks
fill 368 59 485 368 62 485 minecraft:pink_terracotta
setblock 368 59 489 minecraft:red_nether_bricks
fill 368 59 490 368 62 490 minecraft:pink_terracotta
setblock 368 59 494 minecraft:red_nether_bricks
fill 368 59 495 368 61 496 minecraft:pink_terracotta
setblock 368 59 504 minecraft:red_nether_bricks
fill 369 59 464 369 62 464 minecraft:pink_terracotta
setblock 369 59 468 minecraft:red_nether_bricks
fill 369 59 469 369 62 469 minecraft:pink_terracotta
fill 369 59 471 369 59 472 minecraft:pink_terracotta
setblock 369 59 473 minecraft:red_nether_bricks
fill 369 59 474 369 62 474 minecraft:pink_terracotta
setblock 369 59 477 minecraft:pink_terracotta
setblock 369 59 478 minecraft:red_nether_bricks
fill 369 59 479 369 62 479 minecraft:pink_terracotta
setblock 369 59 483 minecraft:red_nether_bricks
fill 369 59 484 369 62 484 minecraft:pink_terracotta
setblock 369 59 488 minecraft:red_nether_bricks
fill 369 59 489 369 62 489 minecraft:pink_terracotta
setblock 369 59 493 minecraft:red_nether_bricks
fill 369 59 494 369 62 494 minecraft:pink_terracotta
setblock 369 59 498 minecraft:red_nether_bricks
setblock 370 59 467 minecraft:red_nether_bricks
fill 370 59 468 370 62 468 minecraft:pink_terracotta
setblock 370 59 472 minecraft:red_nether_bricks
fill 370 59 473 370 62 473 minecraft:pink_terracotta
setblock 370 59 477 minecraft:red_nether_bricks
fill 370 59 478 370 62 478 minecraft:pink_terracotta
setblock 370 59 482 minecraft:red_nether_bricks
fill 370 59 483 370 62 483 minecraft:pink_terracotta
setblock 370 59 487 minecraft:red_nether_bricks
fill 370 59 488 370 62 488 minecraft:pink_terracotta
setblock 370 59 492 minecraft:red_nether_bricks
fill 370 59 493 370 62 493 minecraft:pink_terracotta
setblock 370 59 497 minecraft:red_nether_bricks
fill 370 59 498 370 62 498 minecraft:pink_terracotta
setblock 330 60 466 minecraft:red_nether_bricks
fill 330 60 467 330 63 467 minecraft:pink_terracotta
setblock 330 60 471 minecraft:red_nether_bricks
fill 330 60 472 330 63 472 minecraft:pink_terracotta
setblock 330 60 476 minecraft:red_nether_bricks
fill 330 60 477 330 63 477 minecraft:pink_terracotta
setblock 330 60 481 minecraft:red_nether_bricks
fill 330 60 482 330 63 482 minecraft:pink_terracotta
setblock 330 60 486 minecraft:red_nether_bricks
fill 330 60 487 330 63 487 minecraft:pink_terracotta
setblock 330 60 491 minecraft:red_nether_bricks
fill 330 60 492 330 63 492 minecraft:pink_terracotta
setblock 330 60 495 minecraft:pink_terracotta
setblock 330 60 496 minecraft:red_nether_bricks
fill 330 60 497 330 62 498 minecraft:pink_terracotta
setblock 331 60 465 minecraft:red_nether_bricks
fill 331 60 466 331 63 466 minecraft:pink_terracotta
setblock 331 60 470 minecraft:red_nether_bricks
fill 331 60 471 331 63 471 minecraft:pink_terracotta
setblock 331 60 475 minecraft:red_nether_bricks
fill 331 60 476 331 63 476 minecraft:pink_terracotta
setblock 331 60 480 minecraft:red_nether_bricks
setblock 331 60 485 minecraft:red_nether_bricks
fill 331 60 486 331 61 486 minecraft:pink_terracotta
setblock 331 60 490 minecraft:red_nether_bricks
fill 331 60 491 331 63 491 minecraft:pink_terracotta
setblock 331 60 495 minecraft:red_nether_bricks
setblock 332 60 464 minecraft:red_nether_bricks
fill 332 60 465 332 62 465 minecraft:pink_terracotta
setblock 332 60 469 minecraft:red_nether_bricks
fill 332 60 470 332 63 470 minecraft:pink_terracotta
setblock 332 60 474 minecraft:red_nether_bricks
fill 332 60 475 332 63 475 minecraft:pink_terracotta
fill 333 60 464 333 63 464 minecraft:pink_terracotta
setblock 337 60 464 minecraft:red_nether_bricks
fill 338 60 464 338 63 464 minecraft:pink_terracotta
setblock 339 60 504 minecraft:white_concrete
setblock 341 60 464 minecraft:pink_terracotta
setblock 341 60 465 minecraft:red_nether_bricks
fill 341 60 492 342 61 493 minecraft:red_concrete
setblock 342 60 464 minecraft:red_nether_bricks
fill 342 60 465 342 62 466 minecraft:pink_terracotta
setblock 342 60 504 minecraft:red_nether_bricks
fill 343 60 464 343 63 464 minecraft:pink_terracotta
fill 343 60 504 343 63 504 minecraft:pink_terracotta
setblock 345 60 466 minecraft:red_nether_bricks
fill 345 60 467 345 62 467 minecraft:pink_terracotta
fill 345 60 503 345 62 503 minecraft:pink_terracotta
setblock 346 60 465 minecraft:red_nether_bricks
fill 346 60 466 346 63 466 minecraft:pink_terracotta
setblock 347 60 464 minecraft:red_nether_bricks
fill 347 60 465 347 63 465 minecraft:pink_terracotta
setblock 347 60 504 minecraft:red_nether_bricks
fill 348 60 464 348 63 464 minecraft:pink_terracotta
setblock 348 60 503 minecraft:red_nether_bricks
fill 348 60 504 348 63 504 minecraft:pink_terracotta
fill 349 60 503 349 63 503 minecraft:pink_terracotta
setblock 350 60 466 minecraft:red_nether_bricks
setblock 351 60 465 minecraft:red_nether_bricks
setblock 352 60 464 minecraft:red_nether_bricks
setblock 352 60 465 minecraft:pink_terracotta
setblock 352 60 504 minecraft:red_nether_bricks
fill 353 60 464 353 61 464 minecraft:pink_terracotta
fill 353 60 504 353 63 504 minecraft:pink_terracotta
setblock 361 60 464 minecraft:white_concrete
setblock 364 60 504 minecraft:white_concrete
fill 365 60 504 365 61 504 minecraft:pink_terracotta
setblock 367 60 464 minecraft:red_nether_bricks
fill 367 60 487 367 60 488 minecraft:pink_terracotta
setblock 367 60 489 minecraft:red_nether_bricks
fill 367 60 490 367 63 490 minecraft:pink_terracotta
setblock 367 60 493 minecraft:pink_terracotta
setblock 367 60 494 minecraft:red_nether_bricks
fill 367 60 495 367 63 495 minecraft:pink_terracotta
setblock 367 60 504 minecraft:red_nether_bricks
fill 368 60 464 368 63 464 minecraft:pink_terracotta
fill 368 60 469 368 63 469 minecraft:pink_terracotta
setblock 368 60 473 minecraft:red_nether_bricks
fill 368 60 474 368 62 475 minecraft:pink_terracotta
fill 368 60 484 368 63 484 minecraft:pink_terracotta
setblock 368 60 488 minecraft:red_nether_bricks
fill 368 60 489 368 63 489 minecraft:pink_terracotta
setblock 368 60 493 minecraft:red_nether_bricks
fill 368 60 494 368 63 494 minecraft:pink_terracotta
setblock 368 60 497 minecraft:pink_terracotta
fill 368 60 504 369 60 504 minecraft:pink_terracotta
setblock 369 60 467 minecraft:red_nether_bricks
fill 369 60 468 369 63 468 minecraft:pink_terracotta
setblock 369 60 471 minecraft:pink_terracotta
setblock 369 60 472 minecraft:red_nether_bricks
fill 369 60 473 369 63 473 minecraft:pink_terracotta
setblock 369 60 477 minecraft:red_nether_bricks
fill 369 60 478 369 63 478 minecraft:pink_terracotta
setblock 369 60 482 minecraft:red_nether_bricks
fill 369 60 483 369 63 483 minecraft:pink_terracotta
setblock 369 60 487 minecraft:red_nether_bricks
fill 369 60 488 369 63 488 minecraft:pink_terracotta
setblock 369 60 492 minecraft:red_nether_bricks
fill 369 60 493 369 63 493 minecraft:pink_terracotta
setblock 369 60 496 minecraft:pink_terracotta
setblock 369 60 497 minecraft:red_nether_bricks
fill 369 60 498 369 62 499 minecraft:pink_terracotta
setblock 370 60 466 minecraft:red_nether_bricks
fill 370 60 467 370 63 467 minecraft:pink_terracotta
setblock 370 60 471 minecraft:red_nether_bricks
fill 370 60 472 370 63 472 minecraft:pink_terracotta
setblock 370 60 476 minecraft:red_nether_bricks
fill 370 60 477 370 63 477 minecraft:pink_terracotta
setblock 370 60 481 minecraft:red_nether_bricks
fill 370 60 482 370 63 482 minecraft:pink_terracotta
setblock 370 60 486 minecraft:red_nether_bricks
fill 370 60 487 370 63 487 minecraft:pink_terracotta
setblock 370 60 491 minecraft:red_nether_bricks
fill 370 60 492 370 63 492 minecraft:pink_terracotta
setblock 370 60 496 minecraft:red_nether_bricks
fill 370 60 497 370 63 497 minecraft:pink_terracotta
setblock 370 60 501 minecraft:red_nether_bricks
setblock 330 61 465 minecraft:red_nether_bricks
fill 330 61 466 330 64 466 minecraft:pink_terracotta
setblock 330 61 470 minecraft:red_nether_bricks
fill 330 61 471 330 64 471 minecraft:pink_terracotta
setblock 330 61 475 minecraft:red_nether_bricks
fill 330 61 476 330 64 476 minecraft:pink_terracotta
setblock 330 61 480 minecraft:red_nether_bricks
fill 330 61 481 330 64 481 minecraft:pink_terracotta
setblock 330 61 485 minecraft:red_nether_bricks
fill 330 61 486 330 64 486 minecraft:pink_terracotta
setblock 330 61 490 minecraft:red_nether_bricks
fill 330 61 491 330 64 491 minecraft:pink_terracotta
setblock 330 61 495 minecraft:red_nether_bricks
fill 330 61 496 330 64 496 minecraft:pink_terracotta
setblock 330 61 499 minecraft:pink_terracotta
setblock 330 61 500 minecraft:white_concrete
setblock 331 61 464 minecraft:red_nether_bricks
fill 331 61 465 331 63 465 minecraft:pink_terracotta
setblock 331 61 469 minecraft:red_nether_bricks
fill 331 61 470 331 64 470 minecraft:pink_terracotta
setblock 331 61 473 minecraft:pink_terracotta
setblock 331 61 474 minecraft:red_nether_bricks
fill 331 61 475 331 64 475 minecraft:pink_terracotta
setblock 331 61 479 minecraft:red_nether_bricks
fill 331 61 480 331 63 480 minecraft:pink_terracotta
setblock 331 61 489 minecraft:red_nether_bricks
fill 331 61 490 331 62 490 minecraft:pink_terracotta
setblock 331 61 494 minecraft:red_nether_bricks
fill 331 61 495 331 63 495 minecraft:pink_terracotta
fill 332 61 464 332 64 464 minecraft:pink_terracotta
setblock 332 61 468 minecraft:red_nether_bricks
fill 332 61 469 332 63 469 minecraft:pink_terracotta
setblock 332 61 473 minecraft:red_nether_bricks
fill 332 61 474 332 64 474 minecraft:pink_terracotta
fill 332 61 476 332 62 476 minecraft:pink_terracotta
setblock 336 61 464 minecraft:red_nether_bricks
fill 337 61 464 337 64 464 minecraft:pink_terracotta
setblock 339 61 465 minecraft:pink_terracotta
setblock 340 61 465 minecraft:red_nether_bricks
setblock 341 61 464 minecraft:red_nether_bricks
fill 341 61 465 341 64 465 minecraft:pink_terracotta
setblock 341 61 504 minecraft:red_nether_bricks
fill 342 61 464 342 64 464 minecraft:pink_terracotta
fill 342 61 504 342 64 504 minecraft:pink_terracotta
setblock 344 61 466 minecraft:red_nether_bricks
fill 344 61 503 344 63 503 minecraft:pink_terracotta
setblock 345 61 465 minecraft:red_nether_bricks
fill 345 61 466 345 64 466 minecraft:pink_terracotta
setblock 346 61 464 minecraft:red_nether_bricks
fill 346 61 465 346 64 465 minecraft:pink_terracotta
setblock 346 61 504 minecraft:red_nether_bricks
fill 347 61 464 347 64 464 minecraft:pink_terracotta
setblock 347 61 503 minecraft:red_nether_bricks
fill 347 61 504 347 64 504 minecraft:pink_terracotta
setblock 348 61 466 minecraft:pink_terracotta
setblock 348 61 502 minecraft:red_nether_bricks
fill 348 61 503 348 64 503 minecraft:pink_terracotta
setblock 349 61 466 minecraft:red_nether_bricks
setblock 350 61 465 minecraft:red_nether_bricks
setblock 350 61 466 minecraft:pink_terracotta
setblock 351 61 464 minecraft:red_nether_bricks
fill 351 61 465 351 62 465 minecraft:pink_terracotta
setblock 351 61 504 minecraft:red_nether_bricks
fill 352 61 464 352 63 464 minecraft:pink_terracotta
setblock 352 61 503 minecraft:red_nether_bricks
fill 352 61 504 352 64 504 minecraft:pink_terracotta
setblock 355 61 464 minecraft:white_concrete
fill 364 61 464 364 62 464 minecraft:pink_terracotta
fill 364 61 504 364 62 504 minecraft:pink_terracotta
setblock 366 61 464 minecraft:red_nether_bricks
fill 366 61 492 366 62 492 minecraft:pink_terracotta
setblock 366 61 504 minecraft:red_nether_bricks
fill 367 61 464 367 64 464 minecraft:pink_terracotta
setblock 367 61 487 minecraft:pink_terracotta
setblock 367 61 488 minecraft:red_nether_bricks
fill 367 61 489 367 63 489 minecraft:pink_terracotta
setblock 367 61 493 minecraft:red_nether_bricks
fill 367 61 494 367 64 494 minecraft:pink_terracotta
fill 367 61 496 367 62 496 minecraft:pink_terracotta
fill 367 61 504 368 63 504 minecraft:pink_terracotta
fill 368 61 468 368 62 468 minecraft:pink_terracotta
fill 368 61 470 368 61 471 minecraft:pink_terracotta
setblock 368 61 472 minecraft:red_nether_bricks
fill 368 61 473 368 64 473 minecraft:pink_terracotta
setblock 368 61 476 minecraft:pink_terracotta
setblock 368 61 477 minecraft:red_nether_bricks
fill 368 61 478 368 64 478 minecraft:pink_terracotta
fill 368 61 483 368 63 483 minecraft:pink_terracotta
setblock 368 61 487 minecraft:red_nether_bricks
fill 368 61 488 368 64 488 minecraft:pink_terracotta
setblock 368 61 492 minecraft:red_nether_bricks
fill 368 61 493 368 64 493 minecraft:pink_terracotta
setblock 368 61 497 minecraft:red_nether_bricks
fill 368 61 498 368 64 498 minecraft:pink_terracotta
setblock 369 61 466 minecraft:red_nether_bricks
fill 369 61 467 369 63 467 minecraft:pink_terracotta
setblock 369 61 471 minecraft:red_nether_bricks
fill 369 61 472 369 64 472 minecraft:pink_terracotta
setblock 369 61 475 minecraft:pink_terracotta
setblock 369 61 476 minecraft:red_nether_bricks
fill 369 61 477 369 64 477 minecraft:pink_terracotta
setblock 369 61 481 minecraft:red_nether_bricks
fill 369 61 482 369 64 482 minecraft:pink_terracotta
setblock 369 61 486 minecraft:red_nether_bricks
fill 369 61 487 369 64 487 minecraft:pink_terracotta
setblock 369 61 491 minecraft:red_nether_bricks
fill 369 61 492 369 64 492 minecraft:pink_terracotta
setblock 369 61 496 minecraft:red_nether_bricks
fill 369 61 497 369 64 497 minecraft:pink_terracotta
setblock 370 61 465 minecraft:red_nether_bricks
fill 370 61 466 370 64 466 minecraft:pink_terracotta
setblock 370 61 470 minecraft:red_nether_bricks
fill 370 61 471 370 64 471 minecraft:pink_terracotta
setblock 370 61 475 minecraft:red_nether_bricks
fill 370 61 476 370 64 476 minecraft:pink_terracotta
setblock 370 61 480 minecraft:red_nether_bricks
fill 370 61 481 370 64 481 minecraft:pink_terracotta
setblock 370 61 485 minecraft:red_nether_bricks
fill 370 61 486 370 64 486 minecraft:pink_terracotta
setblock 370 61 490 minecraft:red_nether_bricks
fill 370 61 491 370 64 491 minecraft:pink_terracotta
setblock 370 61 495 minecraft:red_nether_bricks
fill 370 61 496 370 64 496 minecraft:pink_terracotta
setblock 370 61 499 minecraft:pink_terracotta
setblock 370 61 500 minecraft:red_nether_bricks
fill 370 61 501 370 64 501 minecraft:pink_terracotta
setblock 370 61 504 minecraft:white_concrete
setblock 330 62 464 minecraft:red_nether_bricks
fill 330 62 465 330 65 465 minecraft:pink_terracotta
setblock 330 62 469 minecraft:red_nether_bricks
fill 330 62 470 330 65 470 minecraft:pink_terracotta
setblock 330 62 474 minecraft:red_nether_bricks
fill 330 62 475 330 65 475 minecraft:pink_terracotta
setblock 330 62 479 minecraft:red_nether_bricks
fill 330 62 480 330 65 480 minecraft:pink_terracotta
setblock 330 62 484 minecraft:red_nether_bricks
fill 330 62 485 330 64 485 minecraft:pink_terracotta
setblock 330 62 489 minecraft:red_nether_bricks
fill 330 62 490 330 65 490 minecraft:pink_terracotta
setblock 330 62 494 minecraft:red_nether_bricks
fill 330 62 495 330 65 495 minecraft:pink_terracotta
setblock 330 62 499 minecraft:red_nether_bricks
fill 330 62 500 330 65 500 minecraft:pink_terracotta
fill 331 62 464 331 65 464 minecraft:pink_terracotta
setblock 331 62 468 minecraft:red_nether_bricks
fill 331 62 469 331 65 469 minecraft:pink_terracotta
setblock 331 62 473 minecraft:red_nether_bricks
fill 331 62 474 331 65 474 minecraft:pink_terracotta
setblock 331 62 478 minecraft:red_nether_bricks
fill 331 62 479 331 65 479 minecraft:pink_terracotta
setblock 331 62 489 minecraft:pink_terracotta
setblock 331 62 493 minecraft:red_nether_bricks
fill 331 62 494 331 63 494 minecraft:pink_terracotta
fill 332 62 468 332 63 468 minecraft:pink_terracotta
setblock 332 62 472 minecraft:red_nether_bricks
fill 332 62 473 332 65 473 minecraft:pink_terracotta
setblock 332 62 504 minecraft:white_concrete
setblock 335 62 464 minecraft:red_nether_bricks
fill 336 62 464 336 64 464 minecraft:pink_terracotta
setblock 339 62 465 minecraft:red_nether_bricks
setblock 340 62 464 minecraft:red_nether_bricks
fill 340 62 465 340 65 465 minecraft:pink_terracotta
fill 341 62 464 341 65 464 minecraft:pink_terracotta
fill 341 62 504 341 65 504 minecraft:pink_terracotta
setblock 343 62 465 minecraft:pink_terracotta
setblock 343 62 466 minecraft:red_nether_bricks
fill 343 62 503 343 64 503 minecraft:pink_terracotta
setblock 344 62 465 minecraft:red_nether_bricks
fill 344 62 466 344 64 466 minecraft:pink_terracotta
setblock 345 62 464 minecraft:red_nether_bricks
fill 345 62 465 345 65 465 minecraft:pink_terracotta
setblock 345 62 504 minecraft:red_nether_bricks
fill 346 62 464 346 65 464 minecraft:pink_terracotta
setblock 346 62 502 minecraft:pink_terracotta
setblock 346 62 503 minecraft:red_nether_bricks
fill 346 62 504 346 65 504 minecraft:pink_terracotta
setblock 347 62 502 minecraft:red_nether_bricks
fill 347 62 503 347 65 503 minecraft:pink_terracotta
setblock 348 62 466 minecraft:red_nether_bricks
fill 348 62 502 349 64 502 minecraft:pink_terracotta
setblock 349 62 465 minecraft:red_nether_bricks
setblock 349 62 466 minecraft:pink_terracotta
setblock 350 62 464 minecraft:red_nether_bricks
fill 350 62 465 350 63 465 minecraft:pink_terracotta
setblock 350 62 504 minecraft:red_nether_bricks
fill 351 62 464 351 64 464 minecraft:pink_terracotta
setblock 351 62 503 minecraft:red_nether_bricks
fill 351 62 504 351 65 504 minecraft:pink_terracotta
setblock 352 62 503 minecraft:pink_terracotta
fill 363 62 504 363 63 504 minecraft:pink_terracotta
setblock 365 62 464 minecraft:red_nether_bricks
setblock 365 62 504 minecraft:red_nether_bricks
fill 366 62 464 366 64 464 minecraft:pink_terracotta
setblock 366 62 491 minecraft:pink_terracotta
setblock 366 62 493 minecraft:red_nether_bricks
fill 366 62 504 366 65 504 minecraft:pink_terracotta
setblock 367 62 472 minecraft:red_nether_bricks
fill 367 62 473 367 64 474 minecraft:pink_terracotta
setblock 367 62 487 minecraft:red_nether_bricks
fill 367 62 488 367 63 488 minecraft:pink_terracotta
setblock 367 62 492 minecraft:red_nether_bricks
fill 367 62 493 367 65 493 minecraft:pink_terracotta
setblock 368 62 470 minecraft:pink_terracotta
setblock 368 62 471 minecraft:red_nether_bricks
fill 368 62 472 368 65 472 minecraft:pink_terracotta
setblock 368 62 476 minecraft:red_nether_bricks
fill 368 62 477 368 65 477 minecraft:pink_terracotta
fill 368 62 479 368 62 480 minecraft:pink_terracotta
setblock 368 62 481 minecraft:red_nether_bricks
fill 368 62 482 368 64 482 minecraft:pink_terracotta
setblock 368 62 486 minecraft:red_nether_bricks
fill 368 62 487 368 64 487 minecraft:pink_terracotta
setblock 368 62 491 minecraft:red_nether_bricks
fill 368 62 492 368 65 492 minecraft:pink_terracotta
setblock 368 62 495 minecraft:pink_terracotta
setblock 368 62 496 minecraft:red_nether_bricks
fill 368 62 497 368 65 497 minecraft:pink_terracotta
setblock 369 62 466 minecraft:pink_terracotta
setblock 369 62 470 minecraft:red_nether_bricks
fill 369 62 471 369 65 471 minecraft:pink_terracotta
setblock 369 62 475 minecraft:red_nether_bricks
fill 369 62 476 369 65 476 minecraft:pink_terracotta
setblock 369 62 480 minecraft:red_nether_bricks
fill 369 62 481 369 65 481 minecraft:pink_terracotta
setblock 369 62 485 minecraft:red_nether_bricks
fill 369 62 486 369 65 486 minecraft:pink_terracotta
setblock 369 62 490 minecraft:red_nether_bricks
fill 369 62 491 369 65 491 minecraft:pink_terracotta
setblock 369 62 495 minecraft:red_nether_bricks
fill 369 62 496 369 65 496 minecraft:pink_terracotta
setblock 369 62 500 minecraft:red_nether_bricks
setblock 370 62 464 minecraft:red_nether_bricks
fill 370 62 465 370 63 465 minecraft:pink_terracotta
setblock 370 62 469 minecraft:red_nether_bricks
fill 370 62 470 370 65 470 minecraft:pink_terracotta
setblock 370 62 474 minecraft:red_nether_bricks
fill 370 62 475 370 65 475 minecraft:pink_terracotta
setblock 370 62 479 minecraft:red_nether_bricks
fill 370 62 480 370 65 480 minecraft:pink_terracotta
setblock 370 62 484 minecraft:red_nether_bricks
fill 370 62 485 370 65 485 minecraft:pink_terracotta
setblock 370 62 489 minecraft:red_nether_bricks
fill 370 62 490 370 65 490 minecraft:pink_terracotta
setblock 370 62 494 minecraft:red_nether_bricks
fill 370 62 495 370 65 495 minecraft:pink_terracotta
setblock 370 62 499 minecraft:red_nether_bricks
fill 370 62 500 370 65 500 minecraft:pink_terracotta
fill 330 63 464 330 65 464 minecraft:pink_terracotta
setblock 330 63 468 minecraft:red_nether_bricks
fill 330 63 469 330 66 469 minecraft:pink_terracotta
setblock 330 63 473 minecraft:red_nether_bricks
fill 330 63 474 330 66 474 minecraft:pink_terracotta
setblock 330 63 478 minecraft:red_nether_bricks
fill 330 63 479 330 66 479 minecraft:pink_terracotta
setblock 330 63 483 minecraft:red_nether_bricks
fill 330 63 484 330 64 484 minecraft:pink_terracotta
setblock 330 63 488 minecraft:red_nether_bricks
fill 330 63 489 330 64 489 minecraft:pink_terracotta
setblock 330 63 493 minecraft:red_nether_bricks
fill 330 63 494 330 66 494 minecraft:pink_terracotta
setblock 330 63 497 minecraft:pink_terracotta
setblock 330 63 498 minecraft:red_nether_bricks
fill 330 63 499 330 66 499 minecraft:pink_terracotta
setblock 331 63 467 minecraft:red_nether_bricks
fill 331 63 468 331 65 468 minecraft:pink_terracotta
setblock 331 63 472 minecraft:red_nether_bricks
fill 331 63 473 331 66 473 minecraft:pink_terracotta
setblock 331 63 477 minecraft:red_nether_bricks
fill 331 63 478 331 66 478 minecraft:pink_terracotta
setblock 331 63 492 minecraft:red_nether_bricks
setblock 331 63 493 minecraft:pink_terracotta
setblock 332 63 466 minecraft:light[level=12]
setblock 332 63 471 minecraft:red_nether_bricks
fill 332 63 472 332 65 472 minecraft:pink_terracotta
setblock 332 63 476 minecraft:red_nether_bricks
setblock 332 63 482 minecraft:light[level=12]
setblock 332 63 490 minecraft:light[level=12]
setblock 332 63 498 minecraft:light[level=12]
setblock 334 63 464 minecraft:red_nether_bricks
setblock 335 63 464 minecraft:pink_terracotta
setblock 338 63 504 minecraft:white_concrete
setblock 339 63 464 minecraft:red_nether_bricks
setblock 339 63 465 minecraft:pink_terracotta
fill 340 63 464 340 66 464 minecraft:pink_terracotta
setblock 340 63 466 minecraft:light[level=12]
setblock 340 63 474 minecraft:light[level=12]
setblock 340 63 482 minecraft:light[level=12]
setblock 340 63 490 minecraft:light[level=12]
setblock 340 63 498 minecraft:light[level=12]
fill 340 63 504 340 66 504 minecraft:pink_terracotta
setblock 342 63 465 minecraft:pink_terracotta
setblock 342 63 466 minecraft:red_nether_bricks
fill 342 63 503 342 65 503 minecraft:pink_terracotta
setblock 343 63 465 minecraft:red_nether_bricks
fill 343 63 466 343 64 466 minecraft:pink_terracotta
setblock 344 63 464 minecraft:red_nether_bricks
fill 344 63 465 344 66 465 minecraft:pink_terracotta
fill 344 63 502 345 63 502 minecraft:pink_terracotta
setblock 344 63 504 minecraft:red_nether_bricks
fill 345 63 464 345 66 464 minecraft:pink_terracotta
setblock 345 63 503 minecraft:red_nether_bricks
fill 345 63 504 345 66 504 minecraft:pink_terracotta
setblock 346 63 502 minecraft:red_nether_bricks
fill 346 63 503 346 66 503 minecraft:pink_terracotta
setblock 347 63 466 minecraft:red_nether_bricks
fill 347 63 502 347 66 502 minecraft:pink_terracotta
setblock 348 63 465 minecraft:red_nether_bricks
setblock 348 63 466 minecraft:pink_terracotta
setblock 348 63 474 minecraft:light[level=12]
setblock 348 63 482 minecraft:light[level=12]
setblock 348 63 490 minecraft:light[level=12]
setblock 348 63 498 minecraft:light[level=12]
setblock 349 63 464 minecraft:red_nether_bricks
fill 349 63 465 349 64 465 minecraft:pink_terracotta
setblock 349 63 504 minecraft:red_nether_bricks
fill 350 63 464 350 64 464 minecraft:pink_terracotta
setblock 350 63 503 minecraft:red_nether_bricks
fill 350 63 504 350 66 504 minecraft:pink_terracotta
fill 351 63 503 351 64 503 minecraft:pink_terracotta
setblock 354 63 504 minecraft:red_nether_bricks
setblock 356 63 466 minecraft:light[level=12]
setblock 356 63 474 minecraft:light[level=12]
setblock 356 63 482 minecraft:light[level=12]
setblock 356 63 490 minecraft:light[level=12]
setblock 356 63 498 minecraft:light[level=12]
setblock 357 63 504 minecraft:white_concrete
setblock 362 63 464 minecraft:white_concrete
fill 362 63 504 362 64 504 minecraft:pink_terracotta
setblock 364 63 464 minecraft:red_nether_bricks
setblock 364 63 466 minecraft:light[level=12]
fill 364 63 469 364 82 469 minecraft:iron_block
setblock 364 63 474 minecraft:light[level=12]
setblock 364 63 482 minecraft:light[level=12]
setblock 364 63 490 minecraft:light[level=12]
setblock 364 63 498 minecraft:light[level=12]
setblock 364 63 504 minecraft:red_nether_bricks
fill 365 63 464 365 64 464 minecraft:pink_terracotta
fill 365 63 504 365 66 504 minecraft:pink_terracotta
setblock 366 63 493 minecraft:pink_terracotta
fill 367 63 472 367 64 472 minecraft:pink_terracotta
setblock 367 63 475 minecraft:pink_terracotta
setblock 367 63 476 minecraft:red_nether_bricks
setblock 367 63 491 minecraft:red_nether_bricks
fill 367 63 492 367 65 492 minecraft:pink_terracotta
setblock 367 63 496 minecraft:red_nether_bricks
setblock 367 63 497 minecraft:pink_terracotta
setblock 368 63 470 minecraft:red_nether_bricks
fill 368 63 471 368 65 471 minecraft:pink_terracotta
setblock 368 63 474 minecraft:pink_terracotta
setblock 368 63 475 minecraft:red_nether_bricks
fill 368 63 476 368 66 476 minecraft:pink_terracotta
setblock 368 63 479 minecraft:pink_terracotta
setblock 368 63 480 minecraft:red_nether_bricks
fill 368 63 481 368 65 481 minecraft:pink_terracotta
setblock 368 63 485 minecraft:red_nether_bricks
fill 368 63 486 368 64 486 minecraft:pink_terracotta
setblock 368 63 490 minecraft:red_nether_bricks
fill 368 63 491 368 65 491 minecraft:pink_terracotta
setblock 368 63 495 minecraft:red_nether_bricks
fill 368 63 496 368 66 496 minecraft:pink_terracotta
setblock 369 63 464 minecraft:red_nether_bricks
setblock 369 63 469 minecraft:red_nether_bricks
fill 369 63 470 369 66 470 minecraft:pink_terracotta
setblock 369 63 474 minecraft:red_nether_bricks
fill 369 63 475 369 66 475 minecraft:pink_terracotta
setblock 369 63 479 minecraft:red_nether_bricks
fill 369 63 480 369 66 480 minecraft:pink_terracotta
setblock 369 63 484 minecraft:red_nether_bricks
fill 369 63 485 369 65 485 minecraft:pink_terracotta
setblock 369 63 489 minecraft:red_nether_bricks
fill 369 63 490 369 66 490 minecraft:pink_terracotta
setblock 369 63 494 minecraft:red_nether_bricks
fill 369 63 495 369 66 495 minecraft:pink_terracotta
setblock 369 63 498 minecraft:pink_terracotta
setblock 369 63 499 minecraft:red_nether_bricks
fill 369 63 500 369 64 500 minecraft:pink_terracotta
setblock 370 63 468 minecraft:red_nether_bricks
fill 370 63 469 370 66 469 minecraft:pink_terracotta
setblock 370 63 473 minecraft:red_nether_bricks
fill 370 63 474 370 66 474 minecraft:pink_terracotta
setblock 370 63 478 minecraft:red_nether_bricks
fill 370 63 479 370 66 479 minecraft:pink_terracotta
setblock 370 63 483 minecraft:red_nether_bricks
fill 370 63 484 370 66 484 minecraft:pink_terracotta
setblock 370 63 488 minecraft:red_nether_bricks
fill 370 63 489 370 66 489 minecraft:pink_terracotta
setblock 370 63 493 minecraft:red_nether_bricks
fill 370 63 494 370 66 494 minecraft:pink_terracotta
setblock 370 63 498 minecraft:red_nether_bricks
fill 370 63 499 370 66 499 minecraft:pink_terracotta
setblock 330 64 467 minecraft:red_nether_bricks
fill 330 64 468 330 67 468 minecraft:pink_terracotta
setblock 330 64 472 minecraft:red_nether_bricks
fill 330 64 473 330 67 473 minecraft:pink_terracotta
setblock 330 64 477 minecraft:red_nether_bricks
fill 330 64 478 330 67 478 minecraft:pink_terracotta
setblock 330 64 482 minecraft:red_nether_bricks
fill 330 64 483 330 65 483 minecraft:pink_terracotta
setblock 330 64 487 minecraft:red_nether_bricks
setblock 330 64 488 minecraft:pink_terracotta
setblock 330 64 492 minecraft:red_nether_bricks
fill 330 64 493 330 66 493 minecraft:pink_terracotta
setblock 330 64 497 minecraft:red_nether_bricks
fill 330 64 498 330 67 498 minecraft:pink_terracotta
setblock 331 64 466 minecraft:red_nether_bricks
setblock 331 64 467 minecraft:pink_terracotta
setblock 331 64 471 minecraft:red_nether_bricks
fill 331 64 472 331 67 472 minecraft:pink_terracotta
setblock 331 64 476 minecraft:red_nether_bricks
fill 331 64 477 331 67 477 minecraft:pink_terracotta
setblock 332 64 470 minecraft:red_nether_bricks
fill 332 64 471 332 65 471 minecraft:pink_terracotta
setblock 332 64 475 minecraft:red_nether_bricks
setblock 332 64 476 minecraft:pink_terracotta
setblock 333 64 464 minecraft:red_nether_bricks
setblock 338 64 464 minecraft:red_nether_bricks
fill 339 64 464 339 67 464 minecraft:pink_terracotta
fill 339 64 504 339 67 504 minecraft:pink_terracotta
fill 341 64 503 341 66 503 minecraft:pink_terracotta
setblock 342 64 465 minecraft:red_nether_bricks
setblock 342 64 466 minecraft:pink_terracotta
setblock 343 64 464 minecraft:red_nether_bricks
fill 343 64 465 343 67 465 minecraft:pink_terracotta
fill 343 64 502 344 64 502 minecraft:pink_terracotta
setblock 343 64 504 minecraft:red_nether_bricks
fill 344 64 464 344 67 464 minecraft:pink_terracotta
setblock 344 64 503 minecraft:red_nether_bricks
fill 344 64 504 344 67 504 minecraft:pink_terracotta
setblock 345 64 502 minecraft:red_nether_bricks
fill 345 64 503 345 67 503 minecraft:pink_terracotta
setblock 346 64 466 minecraft:red_nether_bricks
fill 346 64 502 346 67 502 minecraft:pink_terracotta
setblock 347 64 465 minecraft:red_nether_bricks
setblock 348 64 464 minecraft:red_nether_bricks
setblock 348 64 465 minecraft:pink_terracotta
setblock 348 64 504 minecraft:red_nether_bricks
fill 349 64 464 349 65 464 minecraft:pink_terracotta
setblock 349 64 503 minecraft:red_nether_bricks
fill 349 64 504 349 67 504 minecraft:pink_terracotta
fill 350 64 503 350 66 503 minecraft:pink_terracotta
setblock 353 64 504 minecraft:red_nether_bricks
setblock 356 64 464 minecraft:white_concrete
fill 361 64 504 361 65 504 minecraft:pink_terracotta
setblock 363 64 504 minecraft:red_nether_bricks
fill 364 64 504 364 67 504 minecraft:pink_terracotta
setblock 367 64 475 minecraft:red_nether_bricks
fill 367 64 476 367 66 477 minecraft:pink_terracotta
setblock 367 64 490 minecraft:red_nether_bricks
setblock 367 64 491 minecraft:pink_terracotta
setblock 367 64 495 minecraft:red_nether_bricks
setblock 367 64 496 minecraft:pink_terracotta
setblock 367 64 504 minecraft:pink_terracotta
setblock 368 64 464 minecraft:red_nether_bricks
setblock 368 64 470 minecraft:pink_terracotta
setblock 368 64 474 minecraft:red_nether_bricks
fill 368 64 475 368 67 475 minecraft:pink_terracotta
setblock 368 64 479 minecraft:red_nether_bricks
fill 368 64 480 368 67 480 minecraft:pink_terracotta
setblock 368 64 489 minecraft:red_nether_bricks
fill 368 64 490 368 65 490 minecraft:pink_terracotta
setblock 368 64 494 minecraft:red_nether_bricks
fill 368 64 495 368 66 495 minecraft:pink_terracotta
setblock 369 64 468 minecraft:red_nether_bricks
fill 369 64 469 369 65 469 minecraft:pink_terracotta
setblock 369 64 473 minecraft:red_nether_bricks
fill 369 64 474 369 67 474 minecraft:pink_terracotta
setblock 369 64 478 minecraft:red_nether_bricks
fill 369 64 479 369 67 479 minecraft:pink_terracotta
setblock 369 64 483 minecraft:red_nether_bricks
fill 369 64 484 369 65 484 minecraft:pink_terracotta
setblock 369 64 488 minecraft:red_nether_bricks
fill 369 64 489 369 65 489 minecraft:pink_terracotta
setblock 369 64 493 minecraft:red_nether_bricks
fill 369 64 494 369 67 494 minecraft:pink_terracotta
setblock 369 64 498 minecraft:red_nether_bricks
fill 369 64 499 369 65 499 minecraft:pink_terracotta
setblock 370 64 467 minecraft:red_nether_bricks
fill 370 64 468 370 66 468 minecraft:pink_terracotta
setblock 370 64 472 minecraft:red_nether_bricks
fill 370 64 473 370 67 473 minecraft:pink_terracotta
setblock 370 64 477 minecraft:red_nether_bricks
fill 370 64 478 370 67 478 minecraft:pink_terracotta
setblock 370 64 482 minecraft:red_nether_bricks
fill 370 64 483 370 67 483 minecraft:pink_terracotta
setblock 370 64 487 minecraft:red_nether_bricks
fill 370 64 488 370 66 488 minecraft:pink_terracotta
setblock 370 64 492 minecraft:red_nether_bricks
fill 370 64 493 370 67 493 minecraft:pink_terracotta
setblock 370 64 497 minecraft:red_nether_bricks
fill 370 64 498 370 67 498 minecraft:pink_terracotta
setblock 330 65 466 minecraft:red_nether_bricks
fill 330 65 467 330 67 467 minecraft:pink_terracotta
setblock 330 65 471 minecraft:red_nether_bricks
fill 330 65 472 330 68 472 minecraft:pink_terracotta
setblock 330 65 476 minecraft:red_nether_bricks
fill 330 65 477 330 68 477 minecraft:pink_terracotta
setblock 330 65 481 minecraft:red_nether_bricks
fill 330 65 482 330 66 482 minecraft:pink_terracotta
setblock 330 65 491 minecraft:red_nether_bricks
setblock 330 65 492 minecraft:pink_terracotta
setblock 330 65 496 minecraft:red_nether_bricks
fill 330 65 497 330 67 497 minecraft:pink_terracotta
setblock 331 65 470 minecraft:red_nether_bricks
fill 331 65 471 331 67 471 minecraft:pink_terracotta
setblock 331 65 475 minecraft:red_nether_bricks
fill 331 65 476 331 68 476 minecraft:pink_terracotta
setblock 332 65 474 minecraft:red_nether_bricks
setblock 332 65 475 minecraft:pink_terracotta
setblock 337 65 464 minecraft:red_nether_bricks
fill 338 65 464 338 68 464 minecraft:pink_terracotta
setblock 341 65 465 minecraft:red_nether_bricks
setblock 342 65 464 minecraft:red_nether_bricks
fill 342 65 465 342 67 465 minecraft:pink_terracotta
setblock 342 65 504 minecraft:red_nether_bricks
fill 343 65 464 343 68 464 minecraft:pink_terracotta
setblock 343 65 502 minecraft:pink_terracotta
setblock 343 65 503 minecraft:red_nether_bricks
fill 343 65 504 343 68 504 minecraft:pink_terracotta
setblock 344 65 502 minecraft:red_nether_bricks
fill 344 65 503 344 68 503 minecraft:pink_terracotta
fill 345 65 502 345 68 502 minecraft:pink_terracotta
setblock 346 65 465 minecraft:red_nether_bricks
setblock 347 65 464 minecraft:red_nether_bricks
setblock 347 65 465 minecraft:pink_terracotta
setblock 347 65 504 minecraft:red_nether_bricks
fill 348 65 464 348 66 464 minecraft:pink_terracotta
setblock 348 65 502 minecraft:pink_terracotta
setblock 348 65 503 minecraft:red_nether_bricks
fill 348 65 504 348 68 504 minecraft:pink_terracotta
fill 349 65 503 349 68 503 minecraft:pink_terracotta
setblock 350 65 464 minecraft:white_concrete
setblock 352 65 504 minecraft:red_nether_bricks
setblock 362 65 504 minecraft:red_nether_bricks
fill 363 65 504 363 68 504 minecraft:pink_terracotta
setblock 367 65 473 minecraft:pink_terracotta
setblock 367 65 474 minecraft:red_nether_bricks
fill 367 65 475 367 66 475 minecraft:pink_terracotta
setblock 367 65 494 minecraft:red_nether_bricks
setblock 367 65 495 minecraft:pink_terracotta
setblock 367 65 504 minecraft:red_nether_bricks
setblock 368 65 473 minecraft:red_nether_bricks
fill 368 65 474 368 68 474 minecraft:pink_terracotta
setblock 368 65 478 minecraft:red_nether_bricks
fill 368 65 479 368 68 479 minecraft:pink_terracotta
setblock 368 65 489 minecraft:pink_terracotta
setblock 368 65 493 minecraft:red_nether_bricks
fill 368 65 494 368 66 494 minecraft:pink_terracotta
setblock 368 65 498 minecraft:red_nether_bricks
fill 369 65 464 369 66 464 minecraft:white_concrete
setblock 369 65 472 minecraft:red_nether_bricks
fill 369 65 473 369 68 473 minecraft:pink_terracotta
setblock 369 65 477 minecraft:red_nether_bricks
fill 369 65 478 369 68 478 minecraft:pink_terracotta
setblock 369 65 482 minecraft:red_nether_bricks
fill 369 65 483 369 66 483 minecraft:pink_terracotta
setblock 369 65 487 minecraft:red_nether_bricks
setblock 369 65 488 minecraft:pink_terracotta
setblock 369 65 492 minecraft:red_nether_bricks
fill 369 65 493 369 66 493 minecraft:pink_terracotta
setblock 369 65 497 minecraft:red_nether_bricks
fill 369 65 498 369 66 498 minecraft:pink_terracotta
setblock 369 65 504 minecraft:white_concrete
setblock 370 65 467 minecraft:pink_terracotta
setblock 370 65 471 minecraft:red_nether_bricks
fill 370 65 472 370 68 472 minecraft:pink_terracotta
setblock 370 65 476 minecraft:red_nether_bricks
fill 370 65 477 370 68 477 minecraft:pink_terracotta
setblock 370 65 481 minecraft:red_nether_bricks
fill 370 65 482 370 68 482 minecraft:pink_terracotta
setblock 370 65 486 minecraft:red_nether_bricks
fill 370 65 487 370 66 487 minecraft:pink_terracotta
setblock 370 65 491 minecraft:red_nether_bricks
fill 370 65 492 370 67 492 minecraft:pink_terracotta
setblock 370 65 496 minecraft:red_nether_bricks
fill 370 65 497 370 68 497 minecraft:pink_terracotta
setblock 370 65 501 minecraft:red_nether_bricks
setblock 330 66 465 minecraft:red_nether_bricks
setblock 330 66 466 minecraft:pink_terracotta
setblock 330 66 470 minecraft:red_nether_bricks
fill 330 66 471 330 69 471 minecraft:pink_terracotta
setblock 330 66 475 minecraft:red_nether_bricks
fill 330 66 476 330 69 476 minecraft:pink_terracotta
setblock 330 66 480 minecraft:red_nether_bricks
fill 330 66 481 330 67 481 minecraft:pink_terracotta
setblock 330 66 486 minecraft:white_concrete
setblock 330 66 495 minecraft:red_nether_bricks
setblock 330 66 496 minecraft:pink_terracotta
setblock 331 66 469 minecraft:red_nether_bricks
setblock 331 66 470 minecraft:pink_terracotta
setblock 331 66 474 minecraft:red_nether_bricks
fill 331 66 475 331 68 475 minecraft:pink_terracotta
setblock 331 66 504 minecraft:white_concrete
fill 338 66 504 338 68 504 minecraft:pink_terracotta
fill 340 66 503 340 67 503 minecraft:pink_terracotta
setblock 341 66 464 minecraft:red_nether_bricks
fill 341 66 465 341 67 465 minecraft:pink_terracotta
setblock 341 66 504 minecraft:red_nether_bricks
fill 342 66 464 342 69 464 minecraft:pink_terracotta
setblock 342 66 502 minecraft:pink_terracotta
setblock 342 66 503 minecraft:red_nether_bricks
fill 342 66 504 342 69 504 minecraft:pink_terracotta
setblock 343 66 502 minecraft:red_nether_bricks
fill 343 66 503 343 69 503 minecraft:pink_terracotta
fill 344 66 502 344 69 502 minecraft:pink_terracotta
setblock 345 66 465 minecraft:red_nether_bricks
setblock 346 66 464 minecraft:red_nether_bricks
setblock 346 66 465 minecraft:pink_terracotta
setblock 346 66 504 minecraft:red_nether_bricks
fill 347 66 464 347 67 464 minecraft:pink_terracotta
setblock 347 66 503 minecraft:red_nether_bricks
fill 347 66 504 347 69 504 minecraft:pink_terracotta
setblock 348 66 502 minecraft:red_nether_bricks
fill 348 66 503 348 69 503 minecraft:pink_terracotta
setblock 351 66 504 minecraft:red_nether_bricks
setblock 352 66 504 minecraft:pink_terracotta
setblock 356 66 504 minecraft:white_concrete
setblock 361 66 504 minecraft:red_nether_bricks
fill 362 66 504 362 69 504 minecraft:pink_terracotta
setblock 363 66 464 minecraft:white_concrete
setblock 366 66 504 minecraft:red_nether_bricks
setblock 368 66 472 minecraft:red_nether_bricks
fill 368 66 473 368 67 473 minecraft:pink_terracotta
setblock 368 66 477 minecraft:red_nether_bricks
fill 368 66 478 368 69 478 minecraft:pink_terracotta
setblock 368 66 493 minecraft:pink_terracotta
setblock 369 66 471 minecraft:red_nether_bricks
fill 369 66 472 369 68 472 minecraft:pink_terracotta
setblock 369 66 476 minecraft:red_nether_bricks
fill 369 66 477 369 69 477 minecraft:pink_terracotta
setblock 369 66 481 minecraft:red_nether_bricks
fill 369 66 482 369 67 482 minecraft:pink_terracotta
setblock 369 66 491 minecraft:red_nether_bricks
setblock 369 66 492 minecraft:pink_terracotta
setblock 369 66 496 minecraft:red_nether_bricks
fill 369 66 497 369 67 497 minecraft:pink_terracotta
setblock 370 66 470 minecraft:red_nether_bricks
fill 370 66 471 370 69 471 minecraft:pink_terracotta
setblock 370 66 475 minecraft:red_nether_bricks
fill 370 66 476 370 69 476 minecraft:pink_terracotta
setblock 370 66 480 minecraft:red_nether_bricks
fill 370 66 481 370 69 481 minecraft:pink_terracotta
setblock 370 66 485 minecraft:red_nether_bricks
setblock 370 66 486 minecraft:pink_terracotta
setblock 370 66 490 minecraft:red_nether_bricks
fill 370 66 491 370 67 491 minecraft:pink_terracotta
setblock 370 66 495 minecraft:red_nether_bricks
fill 370 66 496 370 68 496 minecraft:pink_terracotta
setblock 370 66 500 minecraft:red_nether_bricks
fill 370 66 501 370 67 501 minecraft:white_concrete
setblock 330 67 469 minecraft:red_nether_bricks
fill 330 67 470 330 69 470 minecraft:pink_terracotta
setblock 330 67 474 minecraft:red_nether_bricks
fill 330 67 475 330 70 475 minecraft:pink_terracotta
setblock 330 67 479 minecraft:red_nether_bricks
fill 330 67 480 330 70 480 minecraft:pink_terracotta
setblock 330 67 492 minecraft:white_concrete
setblock 331 67 473 minecraft:red_nether_bricks
fill 331 67 474 331 68 474 minecraft:pink_terracotta
setblock 331 67 478 minecraft:red_nether_bricks
setblock 337 67 504 minecraft:white_concrete
setblock 340 67 464 minecraft:red_nether_bricks
setblock 340 67 504 minecraft:red_nether_bricks
fill 341 67 464 341 70 464 minecraft:pink_terracotta
setblock 341 67 503 minecraft:red_nether_bricks
fill 341 67 504 341 70 504 minecraft:pink_terracotta
setblock 342 67 502 minecraft:red_nether_bricks
fill 342 67 503 342 70 503 minecraft:pink_terracotta
fill 343 67 502 343 70 502 minecraft:pink_terracotta
setblock 344 67 465 minecraft:red_nether_bricks
setblock 345 67 464 minecraft:red_nether_bricks
setblock 345 67 504 minecraft:red_nether_bricks
fill 346 67 464 346 69 464 minecraft:pink_terracotta
setblock 346 67 503 minecraft:red_nether_bricks
fill 346 67 504 346 70 504 minecraft:pink_terracotta
setblock 347 67 502 minecraft:red_nether_bricks
fill 347 67 503 347 70 503 minecraft:pink_terracotta
setblock 350 67 504 minecraft:red_nether_bricks
setblock 351 67 504 minecraft:pink_terracotta
setblock 357 67 464 minecraft:white_concrete
fill 361 67 504 361 70 504 minecraft:pink_terracotta
setblock 365 67 504 minecraft:red_nether_bricks
setblock 368 67 476 minecraft:red_nether_bricks
fill 368 67 477 368 70 477 minecraft:pink_terracotta
setblock 369 67 471 minecraft:pink_terracotta
setblock 369 67 475 minecraft:red_nether_bricks
fill 369 67 476 369 70 476 minecraft:pink_terracotta
setblock 369 67 480 minecraft:red_nether_bricks
fill 369 67 481 369 70 481 minecraft:pink_terracotta
setblock 369 67 495 minecraft:red_nether_bricks
setblock 369 67 496 minecraft:pink_terracotta
setblock 370 67 469 minecraft:red_nether_bricks
fill 370 67 470 370 68 470 minecraft:pink_terracotta
setblock 370 67 474 minecraft:red_nether_bricks
fill 370 67 475 370 70 475 minecraft:pink_terracotta
setblock 370 67 479 minecraft:red_nether_bricks
fill 370 67 480 370 70 480 minecraft:pink_terracotta
setblock 370 67 484 minecraft:red_nether_bricks
setblock 370 67 494 minecraft:red_nether_bricks
fill 370 67 495 370 68 495 minecraft:pink_terracotta
setblock 370 67 499 minecraft:red_nether_bricks
setblock 330 68 469 minecraft:pink_terracotta
setblock 330 68 473 minecraft:red_nether_bricks
fill 330 68 474 330 71 474 minecraft:pink_terracotta
setblock 330 68 478 minecraft:red_nether_bricks
fill 330 68 479 330 71 479 minecraft:pink_terracotta
setblock 330 68 498 minecraft:white_concrete
setblock 331 68 473 minecraft:pink_terracotta
setblock 331 68 477 minecraft:red_nether_bricks
setblock 332 68 464 minecraft:white_concrete
fill 337 68 504 337 69 504 minecraft:pink_terracotta
setblock 339 68 464 minecraft:red_nether_bricks
setblock 339 68 503 minecraft:pink_terracotta
setblock 339 68 504 minecraft:red_nether_bricks
fill 340 68 464 340 71 464 minecraft:pink_terracotta
setblock 340 68 503 minecraft:red_nether_bricks
fill 340 68 504 340 71 504 minecraft:pink_terracotta
setblock 341 68 502 minecraft:red_nether_bricks
fill 341 68 503 341 71 503 minecraft:pink_terracotta
fill 342 68 502 342 71 502 minecraft:pink_terracotta
setblock 344 68 464 minecraft:red_nether_bricks
setblock 344 68 504 minecraft:red_nether_bricks
fill 345 68 464 345 71 464 minecraft:pink_terracotta
setblock 345 68 503 minecraft:red_nether_bricks
fill 345 68 504 345 71 504 minecraft:pink_terracotta
setblock 346 68 502 minecraft:red_nether_bricks
fill 346 68 503 346 71 503 minecraft:pink_terracotta
setblock 347 68 502 minecraft:pink_terracotta
setblock 349 68 504 minecraft:red_nether_bricks
fill 350 68 504 350 71 504 minecraft:pink_terracotta
setblock 351 68 464 minecraft:white_concrete
fill 360 68 504 360 71 504 minecraft:pink_terracotta
setblock 364 68 504 minecraft:red_nether_bricks
setblock 368 68 475 minecraft:red_nether_bricks
fill 368 68 476 368 69 476 minecraft:pink_terracotta
setblock 368 68 504 minecraft:white_concrete
setblock 369 68 474 minecraft:red_nether_bricks
fill 369 68 475 369 71 475 minecraft:pink_terracotta
setblock 369 68 479 minecraft:red_nether_bricks
fill 369 68 480 369 71 480 minecraft:pink_terracotta
setblock 370 68 473 minecraft:red_nether_bricks
fill 370 68 474 370 71 474 minecraft:pink_terracotta
setblock 370 68 478 minecraft:red_nether_bricks
fill 370 68 479 370 71 479 minecraft:pink_terracotta
setblock 370 68 483 minecraft:red_nether_bricks
setblock 370 68 489 minecraft:white_concrete
setblock 370 68 498 minecraft:red_nether_bricks
setblock 330 69 472 minecraft:red_nether_bricks
fill 330 69 473 330 71 473 minecraft:pink_terracotta
setblock 330 69 477 minecraft:red_nether_bricks
fill 330 69 478 330 72 478 minecraft:pink_terracotta
setblock 330 69 485 minecraft:white_concrete
setblock 330 69 504 minecraft:white_concrete
fill 333 69 464 333 71 464 minecraft:white_concrete
fill 336 69 504 336 70 504 minecraft:pink_terracotta
setblock 337 69 464 minecraft:pink_terracotta
setblock 338 69 464 minecraft:red_nether_bricks
setblock 338 69 503 minecraft:pink_terracotta
setblock 338 69 504 minecraft:red_nether_bricks
fill 339 69 464 339 72 464 minecraft:pink_terracotta
setblock 339 69 503 minecraft:red_nether_bricks
fill 339 69 504 339 72 504 minecraft:pink_terracotta
setblock 340 69 502 minecraft:red_nether_bricks
fill 340 69 503 340 72 503 minecraft:pink_terracotta
fill 341 69 502 341 72 502 minecraft:pink_terracotta
setblock 343 69 464 minecraft:red_nether_bricks
setblock 343 69 504 minecraft:red_nether_bricks
fill 344 69 464 344 72 464 minecraft:pink_terracotta
setblock 344 69 503 minecraft:red_nether_bricks
fill 344 69 504 344 72 504 minecraft:pink_terracotta
setblock 345 69 502 minecraft:red_nether_bricks
fill 345 69 503 345 72 503 minecraft:pink_terracotta
fill 346 69 502 346 72 502 minecraft:pink_terracotta
setblock 348 69 504 minecraft:red_nether_bricks
fill 349 69 504 349 72 504 minecraft:pink_terracotta
setblock 355 69 504 minecraft:white_concrete
fill 359 69 504 359 72 504 minecraft:pink_terracotta
setblock 363 69 504 minecraft:red_nether_bricks
fill 364 69 504 364 72 504 minecraft:pink_terracotta
setblock 368 69 479 minecraft:red_nether_bricks
setblock 369 69 473 minecraft:red_nether_bricks
fill 369 69 474 369 70 474 minecraft:pink_terracotta
setblock 369 69 478 minecraft:red_nether_bricks
fill 369 69 479 369 72 479 minecraft:pink_terracotta
setblock 370 69 464 minecraft:white_concrete
setblock 370 69 472 minecraft:red_nether_bricks
fill 370 69 473 370 72 473 minecraft:pink_terracotta
setblock 370 69 477 minecraft:red_nether_bricks
fill 370 69 478 370 72 478 minecraft:pink_terracotta
setblock 370 69 482 minecraft:red_nether_bricks
fill 370 69 483 370 72 483 minecraft:pink_terracotta
setblock 330 70 466 minecraft:white_concrete
setblock 330 70 472 minecraft:pink_terracotta
setblock 330 70 476 minecraft:red_nether_bricks
fill 330 70 477 330 73 477 minecraft:pink_terracotta
setblock 330 70 491 minecraft:white_concrete
fill 331 70 464 332 72 464 minecraft:white_concrete
fill 332 70 465 334 73 465 minecraft:white_concrete
fill 333 70 466 333 73 466 minecraft:white_concrete
fill 334 70 464 335 70 464 minecraft:white_concrete
fill 335 70 504 335 71 504 minecraft:pink_terracotta
setblock 337 70 464 minecraft:red_nether_bricks
setblock 337 70 503 minecraft:pink_terracotta
setblock 337 70 504 minecraft:red_nether_bricks
fill 338 70 464 338 73 464 minecraft:pink_terracotta
setblock 338 70 503 minecraft:red_nether_bricks
fill 338 70 504 338 73 504 minecraft:pink_terracotta
setblock 339 70 502 minecraft:red_nether_bricks
fill 339 70 503 339 73 503 minecraft:pink_terracotta
fill 340 70 502 340 73 502 minecraft:pink_terracotta
setblock 342 70 464 minecraft:red_nether_bricks
setblock 342 70 504 minecraft:red_nether_bricks
fill 343 70 464 343 73 464 minecraft:pink_terracotta
fill 343 70 501 343 71 501 minecraft:pink_terracotta
setblock 343 70 503 minecraft:red_nether_bricks
fill 343 70 504 343 73 504 minecraft:pink_terracotta
setblock 344 70 502 minecraft:red_nether_bricks
fill 344 70 503 344 73 503 minecraft:pink_terracotta
fill 345 70 502 345 73 502 minecraft:pink_terracotta
setblock 347 70 504 minecraft:red_nether_bricks
setblock 348 70 503 minecraft:red_nether_bricks
fill 348 70 504 348 73 504 minecraft:pink_terracotta
fill 358 70 504 358 73 504 minecraft:pink_terracotta
setblock 362 70 504 minecraft:red_nether_bricks
fill 363 70 504 363 73 504 minecraft:pink_terracotta
setblock 364 70 464 minecraft:white_concrete
setblock 368 70 478 minecraft:red_nether_bricks
setblock 369 70 477 minecraft:red_nether_bricks
fill 369 70 478 369 73 478 minecraft:pink_terracotta
setblock 370 70 472 minecraft:pink_terracotta
setblock 370 70 476 minecraft:red_nether_bricks
fill 370 70 477 370 73 477 minecraft:pink_terracotta
setblock 370 70 481 minecraft:red_nether_bricks
fill 370 70 482 370 73 482 minecraft:pink_terracotta
setblock 370 70 502 minecraft:white_concrete
setblock 330 71 472 minecraft:white_concrete
setblock 330 71 475 minecraft:red_nether_bricks
fill 330 71 476 330 74 476 minecraft:pink_terracotta
setblock 330 71 480 minecraft:red_nether_bricks
setblock 330 71 497 minecraft:white_concrete
fill 331 71 465 331 72 465 minecraft:white_concrete
fill 332 71 466 332 72 466 minecraft:white_concrete
setblock 332 71 474 minecraft:light[level=12]
setblock 332 71 482 minecraft:light[level=12]
setblock 332 71 490 minecraft:light[level=12]
setblock 332 71 498 minecraft:light[level=12]
fill 333 71 467 333 72 467 minecraft:red_concrete
setblock 334 71 464 minecraft:white_concrete
fill 334 71 466 334 72 466 minecraft:white_concrete
fill 334 71 504 334 72 504 minecraft:pink_terracotta
setblock 335 71 464 minecraft:pink_terracotta
fill 335 71 465 335 72 465 minecraft:white_concrete
setblock 336 71 464 minecraft:red_nether_bricks
setblock 336 71 503 minecraft:pink_terracotta
setblock 336 71 504 minecraft:red_nether_bricks
fill 337 71 464 337 74 464 minecraft:pink_terracotta
setblock 337 71 503 minecraft:red_nether_bricks
fill 337 71 504 337 74 504 minecraft:pink_terracotta
setblock 338 71 502 minecraft:red_nether_bricks
fill 338 71 503 338 74 503 minecraft:pink_terracotta
fill 339 71 502 339 74 502 minecraft:pink_terracotta
setblock 340 71 466 minecraft:light[level=12]
setblock 340 71 474 minecraft:light[level=12]
setblock 340 71 482 minecraft:light[level=12]
setblock 340 71 490 minecraft:light[level=12]
setblock 340 71 498 minecraft:light[level=12]
setblock 341 71 464 minecraft:red_nether_bricks
fill 341 71 501 342 72 501 minecraft:pink_terracotta
setblock 341 71 504 minecraft:red_nether_bricks
fill 342 71 464 342 74 464 minecraft:pink_terracotta
setblock 342 71 503 minecraft:red_nether_bricks
fill 342 71 504 342 74 504 minecraft:pink_terracotta
setblock 343 71 502 minecraft:red_nether_bricks
fill 343 71 503 343 74 503 minecraft:pink_terracotta
fill 344 71 502 344 74 502 minecraft:pink_terracotta
setblock 346 71 504 minecraft:red_nether_bricks
setblock 347 71 503 minecraft:red_nether_bricks
fill 347 71 504 347 74 504 minecraft:pink_terracotta
setblock 348 71 466 minecraft:light[level=12]
setblock 348 71 474 minecraft:light[level=12]
setblock 348 71 482 minecraft:light[level=12]
setblock 348 71 490 minecraft:light[level=12]
setblock 348 71 498 minecraft:light[level=12]
fill 348 71 503 348 74 503 minecraft:pink_terracotta
setblock 356 71 466 minecraft:light[level=12]
setblock 356 71 474 minecraft:light[level=12]
setblock 356 71 482 minecraft:light[level=12]
setblock 356 71 490 minecraft:light[level=12]
setblock 356 71 498 minecraft:light[level=12]
setblock 356 71 504 minecraft:red_nether_bricks
fill 357 71 504 357 74 504 minecraft:pink_terracotta
setblock 358 71 464 minecraft:white_concrete
fill 359 71 503 361 71 503 minecraft:pink_terracotta
setblock 361 71 504 minecraft:red_nether_bricks
setblock 362 71 503 minecraft:red_nether_bricks
fill 362 71 504 362 74 504 minecraft:pink_terracotta
setblock 364 71 466 minecraft:light[level=12]
setblock 364 71 474 minecraft:light[level=12]
setblock 364 71 482 minecraft:light[level=12]
setblock 364 71 490 minecraft:light[level=12]
setblock 364 71 498 minecraft:light[level=12]
setblock 365 71 504 minecraft:pink_terracotta
setblock 367 71 504 minecraft:white_concrete
setblock 369 71 476 minecraft:red_nether_bricks
fill 369 71 477 369 74 477 minecraft:pink_terracotta
setblock 369 71 481 minecraft:red_nether_bricks
setblock 370 71 471 minecraft:white_concrete
setblock 370 71 475 minecraft:red_nether_bricks
fill 370 71 476 370 74 476 minecraft:pink_terracotta
setblock 370 71 480 minecraft:red_nether_bricks
fill 370 71 481 370 74 481 minecraft:pink_terracotta
setblock 370 71 496 minecraft:white_concrete
setblock 330 72 474 minecraft:red_nether_bricks
fill 330 72 475 330 75 475 minecraft:pink_terracotta
setblock 330 72 479 minecraft:red_nether_bricks
fill 330 72 480 330 75 480 minecraft:pink_terracotta
setblock 330 72 503 minecraft:white_concrete
fill 332 72 504 333 73 504 minecraft:pink_terracotta
fill 333 72 464 334 72 464 minecraft:pink_terracotta
setblock 335 72 464 minecraft:red_nether_bricks
setblock 335 72 503 minecraft:pink_terracotta
setblock 335 72 504 minecraft:red_nether_bricks
fill 336 72 464 336 75 464 minecraft:pink_terracotta
setblock 336 72 503 minecraft:red_nether_bricks
fill 336 72 504 336 75 504 minecraft:pink_terracotta
setblock 337 72 502 minecraft:red_nether_bricks
fill 337 72 503 337 75 503 minecraft:pink_terracotta
setblock 338 72 465 minecraft:pink_terracotta
fill 338 72 502 338 75 502 minecraft:pink_terracotta
setblock 339 72 465 minecraft:red_nether_bricks
setblock 340 72 464 minecraft:red_nether_bricks
fill 340 72 465 341 74 465 minecraft:pink_terracotta
fill 340 72 501 340 74 501 minecraft:pink_terracotta
setblock 340 72 504 minecraft:red_nether_bricks
fill 341 72 464 341 75 464 minecraft:pink_terracotta
setblock 341 72 503 minecraft:red_nether_bricks
fill 341 72 504 341 75 504 minecraft:pink_terracotta
setblock 342 72 502 minecraft:red_nether_bricks
fill 342 72 503 342 75 503 minecraft:pink_terracotta
setblock 343 72 501 minecraft:red_nether_bricks
fill 343 72 502 343 75 502 minecraft:pink_terracotta
fill 344 72 501 344 75 501 minecraft:pink_terracotta
setblock 345 72 464 minecraft:red_nether_bricks
setblock 345 72 504 minecraft:red_nether_bricks
setblock 346 72 503 minecraft:red_nether_bricks
fill 346 72 504 346 75 504 minecraft:pink_terracotta
fill 347 72 503 347 75 503 minecraft:pink_terracotta
setblock 350 72 504 minecraft:red_nether_bricks
fill 351 72 504 354 72 504 minecraft:pink_terracotta
setblock 352 72 464 minecraft:white_concrete
setblock 355 72 504 minecraft:red_nether_bricks
fill 356 72 504 356 75 504 minecraft:pink_terracotta
fill 357 72 503 360 72 503 minecraft:pink_terracotta
setblock 360 72 504 minecraft:red_nether_bricks
setblock 361 72 503 minecraft:red_nether_bricks
fill 361 72 504 361 75 504 minecraft:pink_terracotta
fill 362 72 503 363 74 503 minecraft:pink_terracotta
setblock 365 72 504 minecraft:red_nether_bricks
fill 369 72 476 369 75 476 minecraft:pink_terracotta
setblock 369 72 480 minecraft:red_nether_bricks
fill 369 72 481 369 75 481 minecraft:pink_terracotta
setblock 370 72 465 minecraft:white_concrete
setblock 370 72 474 minecraft:red_nether_bricks
fill 370 72 475 370 75 475 minecraft:pink_terracotta
setblock 370 72 479 minecraft:red_nether_bricks
fill 370 72 480 370 75 480 minecraft:pink_terracotta
setblock 370 72 490 minecraft:white_concrete
fill 330 73 464 333 73 464 minecraft:pink_terracotta
setblock 330 73 465 minecraft:white_concrete
setblock 330 73 478 minecraft:red_nether_bricks
fill 330 73 479 330 76 479 minecraft:pink_terracotta
fill 330 73 481 330 74 481 minecraft:pink_terracotta
setblock 330 73 484 minecraft:white_concrete
fill 330 73 501 330 73 502 minecraft:pink_terracotta
setblock 330 73 503 minecraft:red_nether_bricks
fill 330 73 504 331 75 504 minecraft:pink_terracotta
setblock 334 73 464 minecraft:red_nether_bricks
setblock 334 73 503 minecraft:pink_terracotta
setblock 334 73 504 minecraft:red_nether_bricks
fill 335 73 464 335 76 464 minecraft:pink_terracotta
setblock 335 73 503 minecraft:red_nether_bricks
fill 335 73 504 335 76 504 minecraft:pink_terracotta
fill 336 73 465 337 73 465 minecraft:pink_terracotta
setblock 336 73 502 minecraft:red_nether_bricks
fill 336 73 503 336 76 503 minecraft:pink_terracotta
fill 337 73 502 337 76 502 minecraft:pink_terracotta
setblock 338 73 465 minecraft:red_nether_bricks
fill 338 73 501 339 75 501 minecraft:pink_terracotta
setblock 339 73 464 minecraft:red_nether_bricks
fill 339 73 465 339 76 465 minecraft:pink_terracotta
setblock 339 73 504 minecraft:red_nether_bricks
fill 340 73 464 340 76 464 minecraft:pink_terracotta
setblock 340 73 503 minecraft:red_nether_bricks
fill 340 73 504 340 76 504 minecraft:pink_terracotta
setblock 341 73 501 minecraft:pink_terracotta
setblock 341 73 502 minecraft:red_nether_bricks
fill 341 73 503 341 76 503 minecraft:pink_terracotta
setblock 342 73 465 minecraft:pink_terracotta
setblock 342 73 501 minecraft:red_nether_bricks
fill 342 73 502 342 76 502 minecraft:pink_terracotta
fill 343 73 501 343 76 501 minecraft:pink_terracotta
setblock 344 73 464 minecraft:red_nether_bricks
setblock 344 73 504 minecraft:red_nether_bricks
fill 345 73 464 345 76 464 minecraft:pink_terracotta
setblock 345 73 503 minecraft:red_nether_bricks
fill 345 73 504 345 76 504 minecraft:pink_terracotta
setblock 346 73 464 minecraft:white_concrete
setblock 346 73 502 minecraft:red_nether_bricks
fill 346 73 503 346 76 503 minecraft:pink_terracotta
fill 347 73 502 347 75 502 minecraft:pink_terracotta
setblock 349 73 503 minecraft:pink_terracotta
setblock 349 73 504 minecraft:red_nether_bricks
fill 350 73 504 353 73 504 minecraft:pink_terracotta
setblock 354 73 504 minecraft:red_nether_bricks
setblock 355 73 503 minecraft:red_nether_bricks
fill 355 73 504 355 76 504 minecraft:pink_terracotta
fill 356 73 503 359 73 503 minecraft:pink_terracotta
setblock 359 73 464 minecraft:red_nether_bricks
setblock 359 73 504 minecraft:red_nether_bricks
fill 360 73 464 363 73 464 minecraft:pink_terracotta
setblock 360 73 503 minecraft:red_nether_bricks
fill 360 73 504 360 76 504 minecraft:pink_terracotta
fill 361 73 503 361 76 503 minecraft:pink_terracotta
setblock 364 73 464 minecraft:red_nether_bricks
setblock 364 73 504 minecraft:red_nether_bricks
setblock 365 73 464 minecraft:white_concrete
fill 365 73 504 366 75 504 minecraft:pink_terracotta
setblock 369 73 479 minecraft:red_nether_bricks
fill 369 73 480 369 76 480 minecraft:pink_terracotta
fill 369 73 482 369 74 482 minecraft:pink_terracotta
setblock 370 73 473 minecraft:red_nether_bricks
fill 370 73 474 370 76 474 minecraft:pink_terracotta
setblock 370 73 478 minecraft:red_nether_bricks
fill 370 73 479 370 76 479 minecraft:pink_terracotta
setblock 370 73 483 minecraft:red_nether_bricks
fill 370 73 484 370 76 484 minecraft:pink_terracotta
setblock 370 73 503 minecraft:white_concrete
fill 330 74 464 330 74 466 minecraft:pink_terracotta
setblock 330 74 471 minecraft:white_concrete
setblock 330 74 477 minecraft:red_nether_bricks
fill 330 74 478 330 77 478 minecraft:pink_terracotta
setblock 330 74 482 minecraft:red_nether_bricks
setblock 330 74 490 minecraft:white_concrete
fill 330 74 500 330 74 501 minecraft:pink_terracotta
setblock 330 74 502 minecraft:red_nether_bricks
fill 330 74 503 330 77 503 minecraft:pink_terracotta
fill 331 74 464 332 74 464 minecraft:pink_terracotta
fill 332 74 503 332 74 504 minecraft:pink_terracotta
setblock 333 74 464 minecraft:red_nether_bricks
setblock 333 74 503 minecraft:pink_terracotta
setblock 333 74 504 minecraft:red_nether_bricks
fill 334 74 464 334 76 465 minecraft:pink_terracotta
setblock 334 74 503 minecraft:red_nether_bricks
fill 334 74 504 334 77 504 minecraft:pink_terracotta
fill 335 74 465 336 74 465 minecraft:pink_terracotta
setblock 335 74 502 minecraft:red_nether_bricks
fill 335 74 503 335 77 503 minecraft:pink_terracotta
fill 336 74 502 336 77 502 minecraft:pink_terracotta
setblock 337 74 465 minecraft:red_nether_bricks
fill 337 74 501 337 77 501 minecraft:pink_terracotta
setblock 338 74 464 minecraft:red_nether_bricks
fill 338 74 465 338 77 465 minecraft:pink_terracotta
setblock 338 74 504 minecraft:red_nether_bricks
fill 339 74 464 339 77 464 minecraft:pink_terracotta
setblock 339 74 503 minecraft:red_nether_bricks
fill 339 74 504 339 77 504 minecraft:pink_terracotta
setblock 340 74 502 minecraft:red_nether_bricks
fill 340 74 503 340 77 503 minecraft:pink_terracotta
setblock 341 74 501 minecraft:red_nether_bricks
fill 341 74 502 341 77 502 minecraft:pink_terracotta
setblock 342 74 465 minecraft:red_nether_bricks
fill 342 74 501 342 77 501 minecraft:pink_terracotta
setblock 343 74 464 minecraft:red_nether_bricks
fill 343 74 465 343 77 465 minecraft:pink_terracotta
setblock 343 74 504 minecraft:red_nether_bricks
fill 344 74 464 344 77 464 minecraft:pink_terracotta
setblock 344 74 503 minecraft:red_nether_bricks
fill 344 74 504 344 77 504 minecraft:pink_terracotta
setblock 345 74 502 minecraft:red_nether_bricks
fill 345 74 503 345 77 503 minecraft:pink_terracotta
fill 346 74 464 346 75 464 minecraft:pink_terracotta
fill 346 74 502 346 77 502 minecraft:pink_terracotta
setblock 348 74 504 minecraft:red_nether_bricks
setblock 349 74 503 minecraft:red_nether_bricks
fill 349 74 504 352 74 504 minecraft:pink_terracotta
fill 350 74 503 353 74 503 minecraft:pink_terracotta
setblock 353 74 504 minecraft:red_nether_bricks
setblock 354 74 503 minecraft:red_nether_bricks
fill 354 74 504 354 77 504 minecraft:pink_terracotta
fill 355 74 503 358 74 503 minecraft:pink_terracotta
setblock 357 74 464 minecraft:pink_terracotta
fill 357 74 502 359 74 502 minecraft:pink_terracotta
setblock 358 74 464 minecraft:red_nether_bricks
setblock 358 74 504 minecraft:red_nether_bricks
fill 359 74 464 362 74 464 minecraft:pink_terracotta
setblock 359 74 503 minecraft:red_nether_bricks
fill 359 74 504 359 77 504 minecraft:pink_terracotta
setblock 360 74 502 minecraft:red_nether_bricks
fill 360 74 503 360 77 503 minecraft:pink_terracotta
fill 361 74 502 361 76 502 minecraft:pink_terracotta
setblock 363 74 464 minecraft:red_nether_bricks
setblock 363 74 504 minecraft:red_nether_bricks
fill 364 74 464 366 75 464 minecraft:pink_terracotta
setblock 364 74 503 minecraft:red_nether_bricks
fill 364 74 504 364 77 504 minecraft:pink_terracotta
setblock 369 74 478 minecraft:red_nether_bricks
fill 369 74 479 369 77 479 minecraft:pink_terracotta
setblock 369 74 483 minecraft:red_nether_bricks
fill 370 74 473 370 77 473 minecraft:pink_terracotta
setblock 370 74 477 minecraft:red_nether_bricks
fill 370 74 478 370 77 478 minecraft:pink_terracotta
setblock 370 74 482 minecraft:red_nether_bricks
fill 370 74 483 370 77 483 minecraft:pink_terracotta
fill 370 74 485 370 75 485 minecraft:pink_terracotta
setblock 370 74 497 minecraft:white_concrete
fill 330 75 464 330 75 465 minecraft:pink_terracotta
setblock 330 75 466 minecraft:red_nether_bricks
fill 330 75 467 330 78 467 minecraft:pink_terracotta
setblock 330 75 476 minecraft:red_nether_bricks
fill 330 75 477 330 77 477 minecraft:pink_terracotta
setblock 330 75 481 minecraft:red_nether_bricks
fill 330 75 482 330 77 483 minecraft:pink_terracotta
setblock 330 75 496 minecraft:white_concrete
setblock 330 75 500 minecraft:pink_terracotta
setblock 330 75 501 minecraft:red_nether_bricks
fill 330 75 502 331 77 502 minecraft:pink_terracotta
setblock 331 75 464 minecraft:pink_terracotta
fill 331 75 503 332 75 503 minecraft:pink_terracotta
setblock 332 75 464 minecraft:red_nether_bricks
fill 332 75 465 333 77 465 minecraft:pink_terracotta
setblock 332 75 504 minecraft:red_nether_bricks
fill 333 75 464 333 78 464 minecraft:pink_terracotta
setblock 333 75 503 minecraft:red_nether_bricks
fill 333 75 504 333 78 504 minecraft:pink_terracotta
setblock 334 75 502 minecraft:red_nether_bricks
fill 334 75 503 334 78 503 minecraft:pink_terracotta
setblock 335 75 465 minecraft:pink_terracotta
fill 335 75 502 335 78 502 minecraft:pink_terracotta
setblock 336 75 465 minecraft:red_nether_bricks
fill 336 75 501 336 78 501 minecraft:pink_terracotta
setblock 337 75 464 minecraft:red_nether_bricks
fill 337 75 465 337 78 465 minecraft:pink_terracotta
setblock 337 75 504 minecraft:red_nether_bricks
fill 338 75 464 338 78 464 minecraft:pink_terracotta
fill 338 75 466 338 76 466 minecraft:pink_terracotta
setblock 338 75 503 minecraft:red_nether_bricks
fill 338 75 504 338 78 504 minecraft:pink_terracotta
setblock 339 75 502 minecraft:red_nether_bricks
fill 339 75 503 339 78 503 minecraft:pink_terracotta
setblock 340 75 465 minecraft:pink_terracotta
setblock 340 75 501 minecraft:red_nether_bricks
fill 340 75 502 340 78 502 minecraft:pink_terracotta
setblock 341 75 465 minecraft:red_nether_bricks
fill 341 75 501 341 78 501 minecraft:pink_terracotta
setblock 342 75 464 minecraft:red_nether_bricks
fill 342 75 465 342 78 465 minecraft:pink_terracotta
setblock 342 75 504 minecraft:red_nether_bricks
fill 343 75 464 343 78 464 minecraft:pink_terracotta
setblock 343 75 503 minecraft:red_nether_bricks
fill 343 75 504 343 78 504 minecraft:pink_terracotta
setblock 344 75 502 minecraft:red_nether_bricks
fill 344 75 503 344 78 503 minecraft:pink_terracotta
fill 345 75 502 345 78 502 minecraft:pink_terracotta
setblock 347 75 504 minecraft:red_nether_bricks
setblock 348 75 503 minecraft:red_nether_bricks
fill 348 75 504 351 75 504 minecraft:pink_terracotta
fill 349 75 503 352 75 503 minecraft:pink_terracotta
fill 352 75 494 352 76 494 minecraft:red_concrete
setblock 352 75 504 minecraft:red_nether_bricks
setblock 353 75 464 minecraft:white_concrete
setblock 353 75 503 minecraft:red_nether_bricks
fill 353 75 504 353 78 504 minecraft:pink_terracotta
fill 354 75 503 357 75 503 minecraft:pink_terracotta
fill 355 75 464 356 75 464 minecraft:pink_terracotta
fill 356 75 502 358 75 502 minecraft:pink_terracotta
setblock 357 75 464 minecraft:red_nether_bricks
setblock 357 75 504 minecraft:red_nether_bricks
fill 358 75 464 361 75 464 minecraft:pink_terracotta
setblock 358 75 503 minecraft:red_nether_bricks
fill 358 75 504 358 78 504 minecraft:pink_terracotta
setblock 359 75 502 minecraft:red_nether_bricks
fill 359 75 503 359 78 503 minecraft:pink_terracotta
setblock 360 75 465 minecraft:pink_terracotta
fill 360 75 502 360 77 502 minecraft:pink_terracotta
setblock 361 75 465 minecraft:red_nether_bricks
setblock 362 75 464 minecraft:red_nether_bricks
setblock 362 75 503 minecraft:pink_terracotta
setblock 362 75 504 minecraft:red_nether_bricks
fill 363 75 464 363 78 464 minecraft:pink_terracotta
setblock 363 75 503 minecraft:red_nether_bricks
fill 363 75 504 363 78 504 minecraft:pink_terracotta
fill 364 75 503 364 76 503 minecraft:pink_terracotta
setblock 367 75 464 minecraft:red_nether_bricks
setblock 367 75 504 minecraft:red_nether_bricks
fill 368 75 464 370 76 464 minecraft:pink_terracotta
setblock 369 75 477 minecraft:red_nether_bricks
fill 369 75 478 369 78 478 minecraft:pink_terracotta
setblock 369 75 482 minecraft:red_nether_bricks
fill 369 75 483 369 78 483 minecraft:pink_terracotta
setblock 370 75 465 minecraft:pink_terracotta
setblock 370 75 466 minecraft:white_concrete
setblock 370 75 472 minecraft:white_concrete
setblock 370 75 476 minecraft:red_nether_bricks
fill 370 75 477 370 78 477 minecraft:pink_terracotta
setblock 370 75 481 minecraft:red_nether_bricks
fill 370 75 482 370 78 482 minecraft:pink_terracotta
setblock 370 75 491 minecraft:white_concrete
setblock 330 76 464 minecraft:pink_terracotta
setblock 330 76 465 minecraft:red_nether_bricks
fill 330 76 466 331 78 466 minecraft:pink_terracotta
fill 330 76 468 330 76 469 minecraft:pink_terracotta
setblock 330 76 476 minecraft:pink_terracotta
setblock 330 76 480 minecraft:red_nether_bricks
fill 330 76 481 330 79 481 minecraft:pink_terracotta
setblock 330 76 484 minecraft:pink_terracotta
setblock 330 76 499 minecraft:pink_terracotta
setblock 330 76 500 minecraft:red_nether_bricks
fill 330 76 501 331 78 501 minecraft:pink_terracotta
setblock 330 76 504 minecraft:pink_terracotta
setblock 331 76 464 minecraft:red_nether_bricks
fill 331 76 465 331 79 465 minecraft:pink_terracotta
setblock 331 76 503 minecraft:pink_terracotta
setblock 331 76 504 minecraft:red_nether_bricks
fill 332 76 464 332 79 464 minecraft:pink_terracotta
setblock 332 76 503 minecraft:red_nether_bricks
fill 332 76 504 332 79 504 minecraft:pink_terracotta
setblock 333 76 502 minecraft:red_nether_bricks
fill 333 76 503 333 79 503 minecraft:pink_terracotta
fill 334 76 502 334 79 502 minecraft:pink_terracotta
setblock 335 76 465 minecraft:red_nether_bricks
fill 335 76 466 337 77 466 minecraft:pink_terracotta
setblock 336 76 464 minecraft:red_nether_bricks
fill 336 76 465 336 79 465 minecraft:pink_terracotta
setblock 336 76 504 minecraft:red_nether_bricks
fill 337 76 464 337 79 464 minecraft:pink_terracotta
setblock 337 76 503 minecraft:red_nether_bricks
fill 337 76 504 337 79 504 minecraft:pink_terracotta
setblock 338 76 501 minecraft:pink_terracotta
setblock 338 76 502 minecraft:red_nether_bricks
fill 338 76 503 338 79 503 minecraft:pink_terracotta
setblock 339 76 466 minecraft:red_nether_bricks
setblock 339 76 501 minecraft:red_nether_bricks
fill 339 76 502 339 79 502 minecraft:pink_terracotta
setblock 340 76 465 minecraft:red_nether_bricks
fill 340 76 466 340 79 466 minecraft:pink_terracotta
fill 340 76 501 340 79 501 minecraft:pink_terracotta
setblock 341 76 464 minecraft:red_nether_bricks
fill 341 76 465 341 79 465 minecraft:pink_terracotta
setblock 341 76 504 minecraft:red_nether_bricks
fill 342 76 464 342 79 464 minecraft:pink_terracotta
setblock 342 76 503 minecraft:red_nether_bricks
fill 342 76 504 342 79 504 minecraft:pink_terracotta
setblock 343 76 502 minecraft:red_nether_bricks
fill 343 76 503 343 79 503 minecraft:pink_terracotta
fill 344 76 502 344 78 502 minecraft:pink_terracotta
setblock 346 76 464 minecraft:red_nether_bricks
setblock 346 76 504 minecraft:red_nether_bricks
fill 347 76 464 347 79 464 minecraft:pink_terracotta
setblock 347 76 503 minecraft:red_nether_bricks
fill 347 76 504 350 76 504 minecraft:pink_terracotta
fill 348 76 503 351 76 503 minecraft:pink_terracotta
setblock 351 76 504 minecraft:red_nether_bricks
setblock 352 76 503 minecraft:red_nether_bricks
fill 352 76 504 352 79 504 minecraft:pink_terracotta
fill 353 76 464 355 76 464 minecraft:pink_terracotta
fill 353 76 503 356 76 503 minecraft:pink_terracotta
fill 355 76 502 357 76 502 minecraft:pink_terracotta
setblock 356 76 464 minecraft:red_nether_bricks
setblock 356 76 504 minecraft:red_nether_bricks
fill 357 76 464 359 76 465 minecraft:pink_terracotta
setblock 357 76 503 minecraft:red_nether_bricks
fill 357 76 504 357 79 504 minecraft:pink_terracotta
setblock 358 76 502 minecraft:red_nether_bricks
fill 358 76 503 358 79 503 minecraft:pink_terracotta
fill 359 76 502 359 78 502 minecraft:pink_terracotta
setblock 360 76 464 minecraft:pink_terracotta
setblock 360 76 465 minecraft:red_nether_bricks
setblock 361 76 464 minecraft:red_nether_bricks
fill 361 76 465 363 77 465 minecraft:pink_terracotta
setblock 361 76 504 minecraft:red_nether_bricks
fill 362 76 464 362 79 464 minecraft:pink_terracotta
setblock 362 76 503 minecraft:red_nether_bricks
fill 362 76 504 362 79 504 minecraft:pink_terracotta
fill 363 76 503 363 78 503 minecraft:pink_terracotta
fill 364 76 464 365 76 464 minecraft:pink_terracotta
setblock 365 76 504 minecraft:pink_terracotta
setblock 366 76 464 minecraft:red_nether_bricks
setblock 366 76 504 minecraft:red_nether_bricks
fill 367 76 464 367 79 464 minecraft:pink_terracotta
fill 367 76 504 370 76 504 minecraft:pink_terracotta
fill 369 76 477 369 77 477 minecraft:pink_terracotta
setblock 369 76 481 minecraft:red_nether_bricks
fill 369 76 482 369 79 482 minecraft:pink_terracotta
fill 369 76 484 369 77 484 minecraft:pink_terracotta
setblock 370 76 465 minecraft:red_nether_bricks
fill 370 76 466 370 77 468 minecraft:pink_terracotta
fill 370 76 472 370 78 472 minecraft:pink_terracotta
setblock 370 76 475 minecraft:red_nether_bricks
fill 370 76 476 370 79 476 minecraft:pink_terracotta
setblock 370 76 480 minecraft:red_nether_bricks
fill 370 76 481 370 79 481 minecraft:pink_terracotta
setblock 370 76 485 minecraft:red_nether_bricks
fill 370 76 486 370 79 486 minecraft:pink_terracotta
fill 370 76 502 370 77 503 minecraft:pink_terracotta
setblock 330 77 464 minecraft:red_nether_bricks
fill 330 77 465 330 80 465 minecraft:pink_terracotta
setblock 330 77 468 minecraft:pink_terracotta
setblock 330 77 469 minecraft:red_nether_bricks
fill 330 77 470 330 80 470 minecraft:pink_terracotta
setblock 330 77 479 minecraft:red_nether_bricks
fill 330 77 480 330 79 480 minecraft:pink_terracotta
setblock 330 77 484 minecraft:red_nether_bricks
fill 330 77 485 330 80 485 minecraft:pink_terracotta
setblock 330 77 489 minecraft:white_concrete
setblock 330 77 499 minecraft:red_nether_bricks
fill 330 77 500 330 80 500 minecraft:pink_terracotta
setblock 330 77 504 minecraft:red_nether_bricks
fill 331 77 464 331 80 464 minecraft:pink_terracotta
setblock 331 77 467 minecraft:pink_terracotta
setblock 331 77 503 minecraft:red_nether_bricks
fill 331 77 504 331 80 504 minecraft:pink_terracotta
setblock 332 77 502 minecraft:red_nether_bricks
fill 332 77 503 332 80 503 minecraft:pink_terracotta
setblock 333 77 466 minecraft:red_nether_bricks
fill 333 77 502 333 80 502 minecraft:pink_terracotta
setblock 334 77 464 minecraft:pink_terracotta
setblock 334 77 465 minecraft:red_nether_bricks
fill 334 77 466 334 80 466 minecraft:pink_terracotta
setblock 335 77 464 minecraft:red_nether_bricks
fill 335 77 465 335 80 465 minecraft:pink_terracotta
fill 335 77 501 335 78 501 minecraft:pink_terracotta
setblock 335 77 504 minecraft:red_nether_bricks
fill 336 77 464 336 80 464 minecraft:pink_terracotta
setblock 336 77 503 minecraft:red_nether_bricks
fill 336 77 504 336 80 504 minecraft:pink_terracotta
setblock 337 77 502 minecraft:red_nether_bricks
fill 337 77 503 337 80 503 minecraft:pink_terracotta
setblock 338 77 466 minecraft:red_nether_bricks
setblock 338 77 501 minecraft:red_nether_bricks
fill 338 77 502 338 80 502 minecraft:pink_terracotta
setblock 339 77 465 minecraft:red_nether_bricks
fill 339 77 466 339 80 466 minecraft:pink_terracotta
fill 339 77 501 339 79 501 minecraft:pink_terracotta
setblock 340 77 464 minecraft:red_nether_bricks
fill 340 77 465 340 80 465 minecraft:pink_terracotta
setblock 340 77 504 minecraft:red_nether_bricks
fill 341 77 464 341 80 464 minecraft:pink_terracotta
setblock 341 77 503 minecraft:red_nether_bricks
fill 341 77 504 341 80 504 minecraft:pink_terracotta
setblock 342 77 502 minecraft:red_nether_bricks
fill 342 77 503 342 80 503 minecraft:pink_terracotta
setblock 343 77 501 minecraft:red_nether_bricks
fill 343 77 502 343 79 502 minecraft:pink_terracotta
setblock 345 77 464 minecraft:red_nether_bricks
setblock 345 77 504 minecraft:red_nether_bricks
fill 346 77 464 346 80 464 minecraft:pink_terracotta
setblock 346 77 503 minecraft:red_nether_bricks
fill 346 77 504 349 77 504 minecraft:pink_terracotta
fill 347 77 503 350 77 503 minecraft:pink_terracotta
setblock 350 77 504 minecraft:red_nether_bricks
fill 351 77 464 354 77 464 minecraft:pink_terracotta
setblock 351 77 503 minecraft:red_nether_bricks
fill 351 77 504 351 80 504 minecraft:pink_terracotta
fill 352 77 503 355 77 503 minecraft:pink_terracotta
fill 354 77 502 356 77 502 minecraft:pink_terracotta
setblock 355 77 464 minecraft:red_nether_bricks
setblock 355 77 504 minecraft:red_nether_bricks
fill 356 77 464 358 77 465 minecraft:pink_terracotta
setblock 356 77 503 minecraft:red_nether_bricks
fill 356 77 504 356 80 504 minecraft:pink_terracotta
setblock 357 77 502 minecraft:red_nether_bricks
fill 357 77 503 357 80 503 minecraft:pink_terracotta
fill 358 77 502 358 78 502 minecraft:pink_terracotta
setblock 359 77 464 minecraft:pink_terracotta
setblock 359 77 465 minecraft:red_nether_bricks
setblock 360 77 464 minecraft:red_nether_bricks
fill 360 77 465 360 80 465 minecraft:pink_terracotta
setblock 360 77 504 minecraft:red_nether_bricks
fill 361 77 464 361 80 464 minecraft:pink_terracotta
setblock 361 77 503 minecraft:red_nether_bricks
fill 361 77 504 361 80 504 minecraft:pink_terracotta
fill 362 77 503 362 78 503 minecraft:pink_terracotta
setblock 364 77 464 minecraft:pink_terracotta
setblock 364 77 465 minecraft:red_nether_bricks
setblock 365 77 464 minecraft:red_nether_bricks
setblock 365 77 504 minecraft:red_nether_bricks
fill 366 77 464 366 80 464 minecraft:pink_terracotta
fill 366 77 504 369 77 504 minecraft:pink_terracotta
fill 368 77 464 369 77 464 minecraft:pink_terracotta
setblock 369 77 480 minecraft:red_nether_bricks
fill 369 77 481 369 79 481 minecraft:pink_terracotta
setblock 370 77 464 minecraft:red_nether_bricks
fill 370 77 465 370 80 465 minecraft:pink_terracotta
setblock 370 77 469 minecraft:red_nether_bricks
fill 370 77 470 370 79 471 minecraft:pink_terracotta
setblock 370 77 474 minecraft:red_nether_bricks
fill 370 77 475 370 80 475 minecraft:pink_terracotta
setblock 370 77 479 minecraft:red_nether_bricks
fill 370 77 480 370 80 480 minecraft:pink_terracotta
setblock 370 77 484 minecraft:red_nether_bricks
fill 370 77 485 370 80 485 minecraft:pink_terracotta
fill 370 77 487 370 78 487 minecraft:pink_terracotta
setblock 370 77 498 minecraft:white_concrete
setblock 370 77 504 minecraft:red_nether_bricks
fill 330 78 464 330 81 464 minecraft:pink_terracotta
setblock 330 78 468 minecraft:red_nether_bricks
fill 330 78 469 330 81 469 minecraft:pink_terracotta
fill 330 78 476 330 79 476 minecraft:white_concrete
setblock 330 78 478 minecraft:red_nether_bricks
setblock 330 78 479 minecraft:pink_terracotta
setblock 330 78 482 minecraft:pink_terracotta
setblock 330 78 483 minecraft:red_nether_bricks
fill 330 78 484 330 81 484 minecraft:pink_terracotta
fill 330 78 486 330 79 486 minecraft:pink_terracotta
setblock 330 78 495 minecraft:white_concrete
setblock 330 78 499 minecraft:pink_terracotta
setblock 330 78 502 minecraft:pink_terracotta
setblock 330 78 503 minecraft:red_nether_bricks
fill 330 78 504 330 81 504 minecraft:pink_terracotta
setblock 331 78 467 minecraft:red_nether_bricks
fill 331 78 468 331 81 468 minecraft:pink_terracotta
setblock 331 78 502 minecraft:red_nether_bricks
fill 331 78 503 331 81 503 minecraft:pink_terracotta
setblock 332 78 465 minecraft:pink_terracotta
setblock 332 78 466 minecraft:red_nether_bricks
fill 332 78 502 332 80 502 minecraft:pink_terracotta
setblock 333 78 465 minecraft:red_nether_bricks
fill 333 78 466 333 81 466 minecraft:pink_terracotta
setblock 334 78 464 minecraft:red_nether_bricks
fill 334 78 465 334 81 465 minecraft:pink_terracotta
setblock 334 78 504 minecraft:red_nether_bricks
fill 335 78 464 335 81 464 minecraft:pink_terracotta
fill 335 78 466 336 78 466 minecraft:pink_terracotta
setblock 335 78 503 minecraft:red_nether_bricks
fill 335 78 504 335 81 504 minecraft:pink_terracotta
setblock 336 78 502 minecraft:red_nether_bricks
fill 336 78 503 336 81 503 minecraft:pink_terracotta
setblock 337 78 466 minecraft:red_nether_bricks
setblock 337 78 501 minecraft:red_nether_bricks
fill 337 78 502 337 81 502 minecraft:pink_terracotta
setblock 338 78 465 minecraft:red_nether_bricks
fill 338 78 466 338 81 466 minecraft:pink_terracotta
fill 338 78 501 338 79 501 minecraft:pink_terracotta
setblock 339 78 464 minecraft:red_nether_bricks
fill 339 78 465 339 81 465 minecraft:pink_terracotta
setblock 339 78 504 minecraft:red_nether_bricks
fill 340 78 464 340 81 464 minecraft:pink_terracotta
setblock 340 78 503 minecraft:red_nether_bricks
fill 340 78 504 340 81 504 minecraft:pink_terracotta
setblock 341 78 502 minecraft:red_nether_bricks
fill 341 78 503 341 81 503 minecraft:pink_terracotta
fill 342 78 502 342 80 502 minecraft:pink_terracotta
setblock 343 78 465 minecraft:red_nether_bricks
setblock 344 78 464 minecraft:red_nether_bricks
setblock 344 78 504 minecraft:red_nether_bricks
fill 345 78 464 345 80 464 minecraft:pink_terracotta
setblock 345 78 503 minecraft:red_nether_bricks
fill 345 78 504 348 78 504 minecraft:pink_terracotta
fill 346 78 503 349 78 503 minecraft:pink_terracotta
setblock 348 78 464 minecraft:pink_terracotta
setblock 349 78 464 minecraft:red_nether_bricks
setblock 349 78 504 minecraft:red_nether_bricks
fill 350 78 464 353 78 464 minecraft:pink_terracotta
setblock 350 78 503 minecraft:red_nether_bricks
fill 350 78 504 350 81 504 minecraft:pink_terracotta
fill 351 78 503 354 78 503 minecraft:pink_terracotta
setblock 354 78 464 minecraft:red_nether_bricks
setblock 354 78 504 minecraft:red_nether_bricks
fill 355 78 464 357 78 465 minecraft:pink_terracotta
setblock 355 78 502 minecraft:pink_terracotta
setblock 355 78 503 minecraft:red_nether_bricks
fill 355 78 504 355 81 504 minecraft:pink_terracotta
setblock 356 78 502 minecraft:red_nether_bricks
fill 356 78 503 356 81 503 minecraft:pink_terracotta
setblock 357 78 502 minecraft:pink_terracotta
setblock 358 78 464 minecraft:pink_terracotta
setblock 358 78 465 minecraft:red_nether_bricks
setblock 359 78 464 minecraft:red_nether_bricks
fill 359 78 465 359 81 465 minecraft:pink_terracotta
setblock 359 78 504 minecraft:red_nether_bricks
fill 360 78 464 360 81 464 minecraft:pink_terracotta
setblock 360 78 503 minecraft:red_nether_bricks
fill 360 78 504 360 81 504 minecraft:pink_terracotta
fill 361 78 465 362 78 465 minecraft:pink_terracotta
fill 361 78 503 361 79 503 minecraft:pink_terracotta
setblock 363 78 465 minecraft:red_nether_bricks
setblock 364 78 464 minecraft:red_nether_bricks
fill 364 78 465 366 79 465 minecraft:pink_terracotta
setblock 364 78 504 minecraft:red_nether_bricks
fill 365 78 464 365 81 464 minecraft:pink_terracotta
fill 365 78 504 368 78 504 minecraft:pink_terracotta
setblock 368 78 464 minecraft:pink_terracotta
setblock 368 78 465 minecraft:red_nether_bricks
setblock 369 78 464 minecraft:red_nether_bricks
fill 369 78 465 369 80 466 minecraft:pink_terracotta
setblock 369 78 479 minecraft:red_nether_bricks
fill 369 78 480 369 79 480 minecraft:pink_terracotta
setblock 369 78 484 minecraft:red_nether_bricks
setblock 369 78 485 minecraft:pink_terracotta
setblock 369 78 504 minecraft:red_nether_bricks
fill 370 78 464 370 81 464 minecraft:pink_terracotta
fill 370 78 466 370 78 467 minecraft:pink_terracotta
setblock 370 78 468 minecraft:red_nether_bricks
fill 370 78 469 370 81 469 minecraft:pink_terracotta
setblock 370 78 473 minecraft:red_nether_bricks
fill 370 78 474 370 80 474 minecraft:pink_terracotta
setblock 370 78 478 minecraft:red_nether_bricks
fill 370 78 479 370 81 479 minecraft:pink_terracotta
setblock 370 78 483 minecraft:red_nether_bricks
fill 370 78 484 370 81 484 minecraft:pink_terracotta
setblock 370 78 492 minecraft:white_concrete
setblock 370 78 502 minecraft:pink_terracotta
setblock 370 78 503 minecraft:red_nether_bricks
fill 370 78 504 370 81 504 minecraft:pink_terracotta
setblock 330 79 466 minecraft:pink_terracotta
setblock 330 79 467 minecraft:red_nether_bricks
fill 330 79 468 330 82 468 minecraft:pink_terracotta
setblock 330 79 471 minecraft:pink_terracotta
setblock 330 79 482 minecraft:red_nether_bricks
fill 330 79 483 330 81 483 minecraft:pink_terracotta
setblock 330 79 501 minecraft:pink_terracotta
setblock 330 79 502 minecraft:red_nether_bricks
fill 330 79 503 330 82 503 minecraft:pink_terracotta
setblock 331 79 466 minecraft:red_nether_bricks
fill 331 79 467 331 82 467 minecraft:pink_terracotta
setblock 331 79 501 minecraft:red_nether_bricks
fill 331 79 502 331 82 502 minecraft:pink_terracotta
setblock 332 79 465 minecraft:red_nether_bricks
fill 332 79 466 332 82 466 minecraft:pink_terracotta
setblock 332 79 474 minecraft:light[level=12]
setblock 332 79 482 minecraft:light[level=12]
setblock 332 79 490 minecraft:light[level=12]
setblock 332 79 498 minecraft:light[level=12]
setblock 333 79 464 minecraft:red_nether_bricks
fill 333 79 465 333 82 465 minecraft:pink_terracotta
setblock 333 79 504 minecraft:red_nether_bricks
fill 334 79 464 334 82 464 minecraft:pink_terracotta
setblock 334 79 503 minecraft:red_nether_bricks
fill 334 79 504 334 82 504 minecraft:pink_terracotta
setblock 335 79 466 minecraft:pink_terracotta
setblock 335 79 502 minecraft:red_nether_bricks
fill 335 79 503 335 82 503 minecraft:pink_terracotta
setblock 336 79 466 minecraft:red_nether_bricks
setblock 336 79 501 minecraft:red_nether_bricks
fill 336 79 502 336 82 502 minecraft:pink_terracotta
setblock 337 79 465 minecraft:red_nether_bricks
fill 337 79 466 337 82 466 minecraft:pink_terracotta
fill 337 79 501 337 80 501 minecraft:pink_terracotta
setblock 338 79 464 minecraft:red_nether_bricks
fill 338 79 465 338 82 465 minecraft:pink_terracotta
setblock 338 79 504 minecraft:red_nether_bricks
fill 339 79 464 339 82 464 minecraft:pink_terracotta
setblock 339 79 503 minecraft:red_nether_bricks
fill 339 79 504 339 82 504 minecraft:pink_terracotta
setblock 340 79 474 minecraft:light[level=12]
setblock 340 79 482 minecraft:light[level=12]
setblock 340 79 490 minecraft:light[level=12]
setblock 340 79 498 minecraft:light[level=12]
setblock 340 79 502 minecraft:red_nether_bricks
fill 340 79 503 340 82 503 minecraft:pink_terracotta
fill 341 79 502 341 80 502 minecraft:pink_terracotta
setblock 342 79 465 minecraft:red_nether_bricks
setblock 343 79 464 minecraft:red_nether_bricks
setblock 343 79 465 minecraft:pink_terracotta
setblock 343 79 504 minecraft:red_nether_bricks
fill 344 79 464 344 81 464 minecraft:pink_terracotta
setblock 344 79 503 minecraft:red_nether_bricks
fill 344 79 504 347 79 504 minecraft:pink_terracotta
fill 345 79 503 348 79 503 minecraft:pink_terracotta
setblock 348 79 464 minecraft:red_nether_bricks
setblock 348 79 466 minecraft:light[level=12]
setblock 348 79 474 minecraft:light[level=12]
setblock 348 79 482 minecraft:light[level=12]
setblock 348 79 490 minecraft:light[level=12]
setblock 348 79 498 minecraft:light[level=12]
setblock 348 79 504 minecraft:red_nether_bricks
fill 349 79 464 352 79 464 minecraft:pink_terracotta
setblock 349 79 503 minecraft:red_nether_bricks
fill 349 79 504 349 82 504 minecraft:pink_terracotta
fill 350 79 466 350 80 468 minecraft:white_concrete
fill 350 79 503 353 79 503 minecraft:pink_terracotta
fill 351 79 465 353 79 465 minecraft:white_concrete
fill 351 79 469 353 79 469 minecraft:white_concrete
setblock 353 79 464 minecraft:red_nether_bricks
fill 353 79 466 354 79 466 minecraft:white_concrete
fill 353 79 468 354 79 468 minecraft:white_concrete
setblock 353 79 504 minecraft:red_nether_bricks
fill 354 79 464 356 79 465 minecraft:pink_terracotta
setblock 354 79 467 minecraft:white_concrete
setblock 354 79 503 minecraft:red_nether_bricks
fill 354 79 504 354 82 504 minecraft:pink_terracotta
fill 355 79 503 355 81 503 minecraft:pink_terracotta
setblock 356 79 466 minecraft:light[level=12]
setblock 356 79 474 minecraft:light[level=12]
setblock 356 79 482 minecraft:light[level=12]
setblock 356 79 490 minecraft:light[level=12]
setblock 356 79 498 minecraft:light[level=12]
setblock 357 79 464 minecraft:pink_terracotta
setblock 357 79 465 minecraft:red_nether_bricks
setblock 358 79 464 minecraft:red_nether_bricks
fill 358 79 465 358 82 465 minecraft:pink_terracotta
fill 358 79 479 358 79 481 minecraft:white_concrete
setblock 358 79 504 minecraft:red_nether_bricks
fill 359 79 464 359 82 464 minecraft:pink_terracotta
fill 359 79 479 360 80 479 minecraft:white_concrete
fill 359 79 482 360 79 482 minecraft:white_concrete
setblock 359 79 503 minecraft:red_nether_bricks
fill 359 79 504 359 82 504 minecraft:pink_terracotta
fill 360 79 481 360 81 481 minecraft:white_concrete
fill 360 79 503 360 80 503 minecraft:pink_terracotta
setblock 361 79 465 minecraft:pink_terracotta
setblock 361 79 480 minecraft:white_concrete
setblock 362 79 465 minecraft:red_nether_bricks
setblock 363 79 464 minecraft:red_nether_bricks
fill 363 79 465 363 81 465 minecraft:pink_terracotta
setblock 363 79 504 minecraft:red_nether_bricks
fill 364 79 464 364 82 464 minecraft:pink_terracotta
setblock 364 79 466 minecraft:light[level=12]
setblock 364 79 474 minecraft:light[level=12]
setblock 364 79 482 minecraft:light[level=12]
setblock 364 79 490 minecraft:light[level=12]
setblock 364 79 498 minecraft:light[level=12]
fill 364 79 504 367 79 504 minecraft:pink_terracotta
setblock 367 79 465 minecraft:red_nether_bricks
setblock 368 79 464 minecraft:red_nether_bricks
fill 368 79 465 368 82 465 minecraft:pink_terracotta
setblock 368 79 504 minecraft:red_nether_bricks
fill 369 79 464 369 82 464 minecraft:pink_terracotta
setblock 369 79 467 minecraft:pink_terracotta
setblock 369 79 483 minecraft:red_nether_bricks
setblock 369 79 484 minecraft:pink_terracotta
fill 369 79 504 369 81 504 minecraft:pink_terracotta
setblock 370 79 466 minecraft:pink_terracotta
setblock 370 79 467 minecraft:red_nether_bricks
fill 370 79 468 370 82 468 minecraft:pink_terracotta
setblock 370 79 472 minecraft:red_nether_bricks
fill 370 79 473 370 82 473 minecraft:pink_terracotta
setblock 370 79 477 minecraft:red_nether_bricks
fill 370 79 478 370 81 478 minecraft:pink_terracotta
setblock 370 79 482 minecraft:red_nether_bricks
fill 370 79 483 370 82 483 minecraft:pink_terracotta
setblock 370 79 487 minecraft:red_nether_bricks
fill 370 79 488 370 82 488 minecraft:pink_terracotta
setblock 370 79 502 minecraft:red_nether_bricks
fill 370 79 503 370 81 503 minecraft:pink_terracotta
setblock 330 80 466 minecraft:red_nether_bricks
fill 330 80 467 330 82 467 minecraft:pink_terracotta
setblock 330 80 471 minecraft:red_nether_bricks
setblock 330 80 481 minecraft:red_nether_bricks
setblock 330 80 482 minecraft:pink_terracotta
setblock 330 80 486 minecraft:red_nether_bricks
fill 330 80 487 330 82 487 minecraft:pink_terracotta
setblock 330 80 488 minecraft:white_concrete
setblock 330 80 501 minecraft:red_nether_bricks
fill 330 80 502 330 82 502 minecraft:pink_terracotta
setblock 331 80 465 minecraft:red_nether_bricks
fill 331 80 466 331 82 466 minecraft:pink_terracotta
setblock 331 80 469 minecraft:pink_terracotta
setblock 331 80 501 minecraft:pink_terracotta
setblock 332 80 464 minecraft:red_nether_bricks
fill 332 80 465 332 82 465 minecraft:pink_terracotta
fill 332 80 467 332 81 467 minecraft:pink_terracotta
setblock 332 80 504 minecraft:red_nether_bricks
fill 333 80 464 333 82 464 minecraft:pink_terracotta
setblock 333 80 503 minecraft:red_nether_bricks
fill 333 80 504 333 82 504 minecraft:pink_terracotta
setblock 334 80 502 minecraft:red_nether_bricks
fill 334 80 503 334 82 503 minecraft:pink_terracotta
setblock 335 80 466 minecraft:red_nether_bricks
fill 335 80 502 335 82 502 minecraft:pink_terracotta
setblock 336 80 465 minecraft:red_nether_bricks
fill 336 80 466 336 82 466 minecraft:pink_terracotta
setblock 337 80 464 minecraft:red_nether_bricks
fill 337 80 465 337 82 465 minecraft:pink_terracotta
setblock 337 80 504 minecraft:red_nether_bricks
fill 338 80 464 338 82 464 minecraft:pink_terracotta
setblock 338 80 503 minecraft:red_nether_bricks
fill 338 80 504 338 82 504 minecraft:pink_terracotta
setblock 339 80 502 minecraft:red_nether_bricks
fill 339 80 503 339 82 503 minecraft:pink_terracotta
fill 340 80 502 340 81 502 minecraft:pink_terracotta
setblock 341 80 465 minecraft:red_nether_bricks
setblock 342 80 464 minecraft:red_nether_bricks
setblock 342 80 465 minecraft:pink_terracotta
setblock 342 80 504 minecraft:red_nether_bricks
fill 343 80 464 343 82 464 minecraft:pink_terracotta
setblock 343 80 503 minecraft:red_nether_bricks
fill 343 80 504 346 80 504 minecraft:pink_terracotta
fill 344 80 503 345 80 503 minecraft:pink_terracotta
setblock 347 80 504 minecraft:red_nether_bricks
fill 348 80 504 348 81 504 minecraft:pink_terracotta
fill 349 80 464 351 80 464 minecraft:pink_terracotta
fill 351 80 469 352 80 469 minecraft:white_concrete
fill 351 80 503 352 80 503 minecraft:pink_terracotta
setblock 352 80 464 minecraft:red_nether_bricks
setblock 352 80 465 minecraft:white_concrete
setblock 352 80 504 minecraft:red_nether_bricks
fill 353 80 464 355 80 465 minecraft:pink_terracotta
fill 353 80 466 353 81 466 minecraft:white_concrete
fill 353 80 468 353 81 468 minecraft:white_concrete
setblock 353 80 503 minecraft:red_nether_bricks
fill 353 80 504 353 82 504 minecraft:pink_terracotta
fill 354 80 503 354 81 503 minecraft:pink_terracotta
setblock 356 80 464 minecraft:pink_terracotta
setblock 356 80 465 minecraft:red_nether_bricks
setblock 357 80 464 minecraft:red_nether_bricks
fill 357 80 465 357 82 465 minecraft:pink_terracotta
setblock 357 80 504 minecraft:red_nether_bricks
fill 358 80 464 358 82 464 minecraft:pink_terracotta
fill 358 80 480 358 80 481 minecraft:white_concrete
setblock 358 80 503 minecraft:red_nether_bricks
fill 358 80 504 358 82 504 minecraft:pink_terracotta
setblock 359 80 503 minecraft:pink_terracotta
setblock 361 80 465 minecraft:red_nether_bricks
setblock 362 80 464 minecraft:red_nether_bricks
fill 362 80 465 362 82 465 minecraft:pink_terracotta
setblock 362 80 504 minecraft:red_nether_bricks
fill 363 80 464 363 82 464 minecraft:pink_terracotta
fill 363 80 504 364 80 504 minecraft:pink_terracotta
fill 364 80 465 365 80 465 minecraft:pink_terracotta
setblock 366 80 465 minecraft:red_nether_bricks
setblock 367 80 464 minecraft:red_nether_bricks
fill 367 80 465 367 82 465 minecraft:pink_terracotta
fill 368 80 464 368 82 464 minecraft:pink_terracotta
setblock 369 80 467 minecraft:red_nether_bricks
fill 369 80 468 369 82 468 minecraft:pink_terracotta
setblock 369 80 483 minecraft:pink_terracotta
setblock 370 80 466 minecraft:red_nether_bricks
fill 370 80 467 370 82 467 minecraft:pink_terracotta
setblock 370 80 470 minecraft:pink_terracotta
setblock 370 80 471 minecraft:red_nether_bricks
fill 370 80 472 370 82 472 minecraft:pink_terracotta
setblock 370 80 476 minecraft:red_nether_bricks
setblock 370 80 477 minecraft:pink_terracotta
setblock 370 80 481 minecraft:red_nether_bricks
fill 370 80 482 370 82 482 minecraft:pink_terracotta
setblock 370 80 486 minecraft:red_nether_bricks
fill 370 80 487 370 82 487 minecraft:pink_terracotta
setblock 330 81 465 minecraft:red_nether_bricks
fill 330 81 466 330 82 466 minecraft:pink_terracotta
setblock 330 81 470 minecraft:red_nether_bricks
fill 330 81 471 330 82 471 minecraft:pink_terracotta
setblock 330 81 485 minecraft:red_nether_bricks
fill 330 81 486 330 82 486 minecraft:pink_terracotta
fill 330 81 488 330 82 488 minecraft:pink_terracotta
setblock 330 81 494 minecraft:white_concrete
setblock 330 81 500 minecraft:red_nether_bricks
fill 330 81 501 330 82 501 minecraft:pink_terracotta
setblock 331 81 464 minecraft:red_nether_bricks
fill 331 81 465 331 82 465 minecraft:pink_terracotta
setblock 331 81 469 minecraft:red_nether_bricks
setblock 331 81 504 minecraft:red_nether_bricks
fill 332 81 464 332 82 464 minecraft:pink_terracotta
setblock 332 81 503 minecraft:red_nether_bricks
fill 332 81 504 332 82 504 minecraft:pink_terracotta
setblock 333 81 502 minecraft:red_nether_bricks
fill 333 81 503 333 82 503 minecraft:pink_terracotta
setblock 334 81 466 minecraft:red_nether_bricks
fill 334 81 502 334 82 502 minecraft:pink_terracotta
setblock 335 81 465 minecraft:red_nether_bricks
fill 335 81 466 335 82 466 minecraft:pink_terracotta
setblock 336 81 464 minecraft:red_nether_bricks
fill 336 81 465 336 82 465 minecraft:pink_terracotta
setblock 336 81 504 minecraft:red_nether_bricks
fill 337 81 464 337 82 464 minecraft:pink_terracotta
setblock 337 81 503 minecraft:red_nether_bricks
fill 337 81 504 337 82 504 minecraft:pink_terracotta
setblock 338 81 502 minecraft:red_nether_bricks
fill 338 81 503 338 82 503 minecraft:pink_terracotta
setblock 339 81 502 minecraft:pink_terracotta
setblock 340 81 465 minecraft:red_nether_bricks
setblock 341 81 464 minecraft:red_nether_bricks
setblock 341 81 465 minecraft:pink_terracotta
setblock 341 81 504 minecraft:red_nether_bricks
fill 342 81 464 342 82 464 minecraft:pink_terracotta
setblock 342 81 503 minecraft:red_nether_bricks
fill 342 81 504 345 81 504 minecraft:pink_terracotta
setblock 343 81 503 minecraft:pink_terracotta
schedule function dropper:buildpart/115_3 1t
