setblock 48 148 515 minecraft:crying_obsidian
fill 48 148 516 48 159 516 minecraft:polished_blackstone_bricks
setblock 48 148 531 minecraft:crying_obsidian
setblock 48 148 533 minecraft:crying_obsidian
setblock 48 148 535 minecraft:crying_obsidian
setblock 48 148 537 minecraft:crying_obsidian
fill 48 148 538 48 158 538 minecraft:polished_blackstone_bricks
setblock 48 148 539 minecraft:crying_obsidian
fill 48 148 540 48 158 540 minecraft:polished_blackstone_bricks
setblock 48 148 541 minecraft:crying_obsidian
fill 48 148 542 48 158 542 minecraft:polished_blackstone_bricks
setblock 48 148 543 minecraft:crying_obsidian
setblock 49 148 510 minecraft:crying_obsidian
setblock 49 148 512 minecraft:crying_obsidian
setblock 49 148 514 minecraft:crying_obsidian
setblock 49 148 516 minecraft:crying_obsidian
setblock 49 148 532 minecraft:crying_obsidian
setblock 49 148 534 minecraft:crying_obsidian
setblock 49 148 536 minecraft:crying_obsidian
setblock 49 148 538 minecraft:crying_obsidian
setblock 49 148 540 minecraft:crying_obsidian
setblock 49 148 542 minecraft:crying_obsidian
setblock 50 148 511 minecraft:crying_obsidian
setblock 50 148 513 minecraft:crying_obsidian
setblock 50 148 515 minecraft:crying_obsidian
setblock 50 148 531 minecraft:crying_obsidian
setblock 50 148 533 minecraft:crying_obsidian
setblock 50 148 535 minecraft:crying_obsidian
setblock 50 148 537 minecraft:crying_obsidian
setblock 50 148 539 minecraft:crying_obsidian
setblock 50 148 541 minecraft:crying_obsidian
setblock 50 148 543 minecraft:crying_obsidian
setblock 51 148 510 minecraft:crying_obsidian
setblock 51 148 512 minecraft:crying_obsidian
setblock 51 148 514 minecraft:crying_obsidian
setblock 51 148 516 minecraft:crying_obsidian
setblock 51 148 532 minecraft:crying_obsidian
setblock 51 148 534 minecraft:crying_obsidian
setblock 51 148 536 minecraft:crying_obsidian
setblock 51 148 538 minecraft:crying_obsidian
setblock 51 148 540 minecraft:crying_obsidian
setblock 51 148 542 minecraft:crying_obsidian
fill 52 148 510 53 192 510 minecraft:polished_blackstone_bricks
setblock 52 148 511 minecraft:crying_obsidian
setblock 52 148 513 minecraft:crying_obsidian
setblock 52 148 515 minecraft:crying_obsidian
setblock 52 148 531 minecraft:crying_obsidian
setblock 52 148 533 minecraft:crying_obsidian
setblock 52 148 535 minecraft:crying_obsidian
setblock 52 148 537 minecraft:crying_obsidian
setblock 52 148 539 minecraft:crying_obsidian
setblock 52 148 541 minecraft:crying_obsidian
setblock 52 148 543 minecraft:crying_obsidian
setblock 53 148 532 minecraft:crying_obsidian
setblock 53 148 534 minecraft:crying_obsidian
setblock 53 148 536 minecraft:crying_obsidian
setblock 53 148 538 minecraft:crying_obsidian
setblock 53 148 540 minecraft:crying_obsidian
setblock 53 148 542 minecraft:crying_obsidian
setblock 54 148 531 minecraft:crying_obsidian
setblock 54 148 533 minecraft:crying_obsidian
setblock 54 148 535 minecraft:crying_obsidian
setblock 54 148 537 minecraft:crying_obsidian
setblock 54 148 539 minecraft:crying_obsidian
setblock 54 148 541 minecraft:crying_obsidian
setblock 54 148 543 minecraft:crying_obsidian
setblock 55 148 532 minecraft:crying_obsidian
setblock 55 148 534 minecraft:crying_obsidian
setblock 55 148 536 minecraft:crying_obsidian
setblock 55 148 538 minecraft:crying_obsidian
setblock 55 148 540 minecraft:crying_obsidian
setblock 55 148 542 minecraft:crying_obsidian
setblock 56 148 531 minecraft:crying_obsidian
setblock 56 148 533 minecraft:crying_obsidian
setblock 56 148 535 minecraft:crying_obsidian
setblock 56 148 537 minecraft:crying_obsidian
setblock 56 148 539 minecraft:crying_obsidian
setblock 56 148 541 minecraft:crying_obsidian
setblock 56 148 543 minecraft:crying_obsidian
setblock 57 148 532 minecraft:crying_obsidian
setblock 57 148 534 minecraft:crying_obsidian
setblock 57 148 536 minecraft:crying_obsidian
setblock 57 148 538 minecraft:crying_obsidian
setblock 57 148 540 minecraft:crying_obsidian
setblock 57 148 542 minecraft:crying_obsidian
fill 48 149 511 48 150 511 minecraft:polished_blackstone_bricks
fill 48 149 513 48 150 513 minecraft:polished_blackstone_bricks
fill 48 149 515 48 150 515 minecraft:polished_blackstone_bricks
fill 48 149 531 48 150 531 minecraft:polished_blackstone_bricks
fill 48 149 533 48 150 533 minecraft:polished_blackstone_bricks
fill 48 149 535 48 150 535 minecraft:polished_blackstone_bricks
fill 48 149 537 48 150 537 minecraft:polished_blackstone_bricks
fill 48 149 539 48 150 539 minecraft:polished_blackstone_bricks
fill 48 149 541 48 150 541 minecraft:polished_blackstone_bricks
fill 48 149 543 48 150 543 minecraft:polished_blackstone_bricks
fill 49 149 510 49 150 510 minecraft:polished_blackstone_bricks
fill 49 149 512 49 150 512 minecraft:polished_blackstone_bricks
fill 49 149 514 49 150 514 minecraft:polished_blackstone_bricks
fill 49 149 516 49 150 516 minecraft:polished_blackstone_bricks
fill 49 149 532 49 150 532 minecraft:polished_blackstone_bricks
fill 49 149 534 49 150 534 minecraft:polished_blackstone_bricks
fill 49 149 536 49 150 536 minecraft:polished_blackstone_bricks
fill 49 149 538 49 150 538 minecraft:polished_blackstone_bricks
fill 49 149 540 49 150 540 minecraft:polished_blackstone_bricks
fill 49 149 542 49 150 542 minecraft:polished_blackstone_bricks
fill 50 149 511 50 150 511 minecraft:polished_blackstone_bricks
fill 50 149 513 50 150 513 minecraft:polished_blackstone_bricks
fill 50 149 515 50 150 515 minecraft:polished_blackstone_bricks
fill 50 149 531 50 150 531 minecraft:polished_blackstone_bricks
fill 50 149 533 50 150 533 minecraft:polished_blackstone_bricks
fill 50 149 535 50 150 535 minecraft:polished_blackstone_bricks
fill 50 149 537 50 150 537 minecraft:polished_blackstone_bricks
fill 50 149 539 50 150 539 minecraft:polished_blackstone_bricks
fill 50 149 541 50 150 541 minecraft:polished_blackstone_bricks
fill 50 149 543 50 150 543 minecraft:polished_blackstone_bricks
fill 51 149 510 51 150 510 minecraft:polished_blackstone_bricks
fill 51 149 512 51 150 512 minecraft:polished_blackstone_bricks
fill 51 149 514 51 150 514 minecraft:polished_blackstone_bricks
fill 51 149 516 51 150 516 minecraft:polished_blackstone_bricks
fill 51 149 532 51 150 532 minecraft:polished_blackstone_bricks
fill 51 149 534 51 150 534 minecraft:polished_blackstone_bricks
fill 51 149 536 51 150 536 minecraft:polished_blackstone_bricks
fill 51 149 538 51 150 538 minecraft:polished_blackstone_bricks
fill 51 149 540 51 150 540 minecraft:polished_blackstone_bricks
fill 51 149 542 51 150 542 minecraft:polished_blackstone_bricks
fill 52 149 511 52 150 511 minecraft:polished_blackstone_bricks
fill 52 149 513 52 150 513 minecraft:polished_blackstone_bricks
fill 52 149 515 52 150 515 minecraft:polished_blackstone_bricks
fill 52 149 531 52 150 531 minecraft:polished_blackstone_bricks
fill 52 149 533 52 150 533 minecraft:polished_blackstone_bricks
fill 52 149 535 52 150 535 minecraft:polished_blackstone_bricks
fill 52 149 537 52 150 537 minecraft:polished_blackstone_bricks
fill 52 149 539 52 150 539 minecraft:polished_blackstone_bricks
fill 52 149 541 52 150 541 minecraft:polished_blackstone_bricks
fill 52 149 543 52 150 543 minecraft:polished_blackstone_bricks
fill 53 149 532 53 150 532 minecraft:polished_blackstone_bricks
fill 53 149 534 53 150 534 minecraft:polished_blackstone_bricks
fill 53 149 536 53 150 536 minecraft:polished_blackstone_bricks
fill 53 149 538 53 150 538 minecraft:polished_blackstone_bricks
fill 53 149 540 53 150 540 minecraft:polished_blackstone_bricks
fill 53 149 542 53 150 542 minecraft:polished_blackstone_bricks
fill 54 149 531 54 150 531 minecraft:polished_blackstone_bricks
fill 54 149 533 54 150 533 minecraft:polished_blackstone_bricks
fill 54 149 535 54 150 535 minecraft:polished_blackstone_bricks
fill 54 149 537 54 150 537 minecraft:polished_blackstone_bricks
fill 54 149 539 54 150 539 minecraft:polished_blackstone_bricks
fill 54 149 541 54 150 541 minecraft:polished_blackstone_bricks
fill 54 149 543 54 150 543 minecraft:polished_blackstone_bricks
fill 55 149 532 55 150 532 minecraft:polished_blackstone_bricks
fill 55 149 534 55 150 534 minecraft:polished_blackstone_bricks
fill 55 149 536 55 150 536 minecraft:polished_blackstone_bricks
fill 55 149 538 55 150 538 minecraft:polished_blackstone_bricks
fill 55 149 540 55 150 540 minecraft:polished_blackstone_bricks
fill 55 149 542 55 150 542 minecraft:polished_blackstone_bricks
fill 56 149 531 56 150 531 minecraft:polished_blackstone_bricks
fill 56 149 533 56 150 533 minecraft:polished_blackstone_bricks
fill 56 149 535 56 150 535 minecraft:polished_blackstone_bricks
fill 56 149 537 56 150 537 minecraft:polished_blackstone_bricks
fill 56 149 539 56 150 539 minecraft:polished_blackstone_bricks
fill 56 149 541 56 150 541 minecraft:polished_blackstone_bricks
fill 56 149 543 56 150 543 minecraft:polished_blackstone_bricks
fill 57 149 532 57 150 532 minecraft:polished_blackstone_bricks
fill 57 149 534 57 150 534 minecraft:polished_blackstone_bricks
fill 57 149 536 57 150 536 minecraft:polished_blackstone_bricks
fill 57 149 538 57 150 538 minecraft:polished_blackstone_bricks
fill 57 149 540 57 150 540 minecraft:polished_blackstone_bricks
fill 57 149 542 57 150 542 minecraft:polished_blackstone_bricks
fill 81 150 545 81 150 547 minecraft:blackstone
setblock 82 150 548 minecraft:blackstone
fill 83 150 544 84 150 544 minecraft:blackstone
fill 84 150 548 85 150 548 minecraft:blackstone
fill 85 150 545 85 150 547 minecraft:blackstone
setblock 48 151 511 minecraft:crying_obsidian
setblock 48 151 513 minecraft:crying_obsidian
setblock 48 151 515 minecraft:crying_obsidian
setblock 48 151 531 minecraft:crying_obsidian
setblock 48 151 533 minecraft:crying_obsidian
setblock 48 151 535 minecraft:crying_obsidian
setblock 48 151 537 minecraft:crying_obsidian
setblock 48 151 539 minecraft:crying_obsidian
setblock 48 151 541 minecraft:crying_obsidian
setblock 48 151 543 minecraft:crying_obsidian
setblock 49 151 510 minecraft:crying_obsidian
setblock 49 151 512 minecraft:crying_obsidian
setblock 49 151 514 minecraft:crying_obsidian
setblock 49 151 516 minecraft:crying_obsidian
setblock 49 151 532 minecraft:crying_obsidian
setblock 49 151 534 minecraft:crying_obsidian
setblock 49 151 536 minecraft:crying_obsidian
setblock 49 151 538 minecraft:crying_obsidian
setblock 49 151 540 minecraft:crying_obsidian
setblock 49 151 542 minecraft:crying_obsidian
setblock 50 151 511 minecraft:crying_obsidian
setblock 50 151 513 minecraft:crying_obsidian
setblock 50 151 515 minecraft:crying_obsidian
setblock 50 151 531 minecraft:crying_obsidian
setblock 50 151 533 minecraft:crying_obsidian
setblock 50 151 535 minecraft:crying_obsidian
setblock 50 151 537 minecraft:crying_obsidian
setblock 50 151 539 minecraft:crying_obsidian
setblock 50 151 541 minecraft:crying_obsidian
setblock 50 151 543 minecraft:crying_obsidian
setblock 51 151 510 minecraft:crying_obsidian
setblock 51 151 512 minecraft:crying_obsidian
setblock 51 151 514 minecraft:crying_obsidian
setblock 51 151 516 minecraft:crying_obsidian
setblock 51 151 532 minecraft:crying_obsidian
setblock 51 151 534 minecraft:crying_obsidian
setblock 51 151 536 minecraft:crying_obsidian
setblock 51 151 538 minecraft:crying_obsidian
setblock 51 151 540 minecraft:crying_obsidian
setblock 51 151 542 minecraft:crying_obsidian
setblock 52 151 511 minecraft:crying_obsidian
setblock 52 151 513 minecraft:crying_obsidian
setblock 52 151 515 minecraft:crying_obsidian
setblock 52 151 531 minecraft:crying_obsidian
setblock 52 151 533 minecraft:crying_obsidian
setblock 52 151 535 minecraft:crying_obsidian
setblock 52 151 537 minecraft:crying_obsidian
setblock 52 151 539 minecraft:crying_obsidian
setblock 52 151 541 minecraft:crying_obsidian
setblock 52 151 543 minecraft:crying_obsidian
setblock 53 151 532 minecraft:crying_obsidian
setblock 53 151 534 minecraft:crying_obsidian
setblock 53 151 536 minecraft:crying_obsidian
setblock 53 151 538 minecraft:crying_obsidian
setblock 53 151 540 minecraft:crying_obsidian
setblock 53 151 542 minecraft:crying_obsidian
setblock 54 151 531 minecraft:crying_obsidian
setblock 54 151 533 minecraft:crying_obsidian
setblock 54 151 535 minecraft:crying_obsidian
setblock 54 151 537 minecraft:crying_obsidian
setblock 54 151 539 minecraft:crying_obsidian
setblock 54 151 541 minecraft:crying_obsidian
setblock 54 151 543 minecraft:crying_obsidian
setblock 55 151 532 minecraft:crying_obsidian
setblock 55 151 534 minecraft:crying_obsidian
setblock 55 151 536 minecraft:crying_obsidian
setblock 55 151 538 minecraft:crying_obsidian
setblock 55 151 540 minecraft:crying_obsidian
setblock 55 151 542 minecraft:crying_obsidian
setblock 56 151 531 minecraft:crying_obsidian
setblock 56 151 533 minecraft:crying_obsidian
setblock 56 151 535 minecraft:crying_obsidian
setblock 56 151 537 minecraft:crying_obsidian
setblock 56 151 539 minecraft:crying_obsidian
setblock 56 151 541 minecraft:crying_obsidian
setblock 56 151 543 minecraft:crying_obsidian
setblock 57 151 532 minecraft:crying_obsidian
setblock 57 151 534 minecraft:crying_obsidian
setblock 57 151 536 minecraft:crying_obsidian
setblock 57 151 538 minecraft:crying_obsidian
setblock 57 151 540 minecraft:crying_obsidian
setblock 57 151 542 minecraft:crying_obsidian
setblock 83 151 524 minecraft:crying_obsidian
fill 47 152 516 47 165 516 minecraft:polished_blackstone_bricks
fill 47 152 517 47 152 518 minecraft:crying_obsidian
fill 47 152 519 47 165 519 minecraft:polished_blackstone_bricks
fill 47 152 528 47 165 528 minecraft:polished_blackstone_bricks
fill 47 152 529 47 152 530 minecraft:crying_obsidian
fill 47 152 531 48 153 531 minecraft:polished_blackstone_bricks
fill 47 152 540 47 165 540 minecraft:polished_blackstone_bricks
fill 47 152 541 47 152 542 minecraft:crying_obsidian
fill 47 152 543 48 153 543 minecraft:polished_blackstone_bricks
fill 47 152 552 47 165 552 minecraft:polished_blackstone_bricks
fill 48 152 511 48 153 511 minecraft:polished_blackstone_bricks
fill 48 152 513 48 153 513 minecraft:polished_blackstone_bricks
fill 48 152 515 48 153 515 minecraft:polished_blackstone_bricks
fill 48 152 533 48 153 533 minecraft:polished_blackstone_bricks
fill 48 152 535 48 153 535 minecraft:polished_blackstone_bricks
fill 48 152 537 48 153 537 minecraft:polished_blackstone_bricks
fill 48 152 539 48 153 539 minecraft:polished_blackstone_bricks
fill 48 152 541 48 153 541 minecraft:polished_blackstone_bricks
fill 48 152 552 49 152 552 minecraft:crying_obsidian
fill 49 152 510 49 153 510 minecraft:polished_blackstone_bricks
fill 49 152 512 49 153 512 minecraft:polished_blackstone_bricks
fill 49 152 514 49 153 514 minecraft:polished_blackstone_bricks
fill 49 152 516 49 153 516 minecraft:polished_blackstone_bricks
fill 49 152 532 49 153 532 minecraft:polished_blackstone_bricks
fill 49 152 534 49 153 534 minecraft:polished_blackstone_bricks
fill 49 152 536 49 153 536 minecraft:polished_blackstone_bricks
fill 49 152 538 49 153 538 minecraft:polished_blackstone_bricks
fill 49 152 540 49 153 540 minecraft:polished_blackstone_bricks
fill 49 152 542 49 153 542 minecraft:polished_blackstone_bricks
fill 50 152 511 50 153 511 minecraft:polished_blackstone_bricks
fill 50 152 513 50 153 513 minecraft:polished_blackstone_bricks
fill 50 152 515 50 153 515 minecraft:polished_blackstone_bricks
fill 50 152 531 50 153 531 minecraft:polished_blackstone_bricks
fill 50 152 533 50 153 533 minecraft:polished_blackstone_bricks
fill 50 152 535 50 153 535 minecraft:polished_blackstone_bricks
fill 50 152 537 50 153 537 minecraft:polished_blackstone_bricks
fill 50 152 539 50 153 539 minecraft:polished_blackstone_bricks
fill 50 152 541 50 153 541 minecraft:polished_blackstone_bricks
fill 50 152 543 50 153 543 minecraft:polished_blackstone_bricks
fill 50 152 552 50 165 552 minecraft:polished_blackstone_bricks
fill 51 152 510 51 153 510 minecraft:polished_blackstone_bricks
fill 51 152 512 51 153 512 minecraft:polished_blackstone_bricks
fill 51 152 514 51 153 514 minecraft:polished_blackstone_bricks
fill 51 152 516 51 153 516 minecraft:polished_blackstone_bricks
fill 51 152 532 51 153 532 minecraft:polished_blackstone_bricks
fill 51 152 534 51 153 534 minecraft:polished_blackstone_bricks
fill 51 152 536 51 153 536 minecraft:polished_blackstone_bricks
fill 51 152 538 51 153 538 minecraft:polished_blackstone_bricks
fill 51 152 540 51 153 540 minecraft:polished_blackstone_bricks
fill 51 152 542 51 153 542 minecraft:polished_blackstone_bricks
fill 52 152 511 52 153 511 minecraft:polished_blackstone_bricks
fill 52 152 513 52 153 513 minecraft:polished_blackstone_bricks
fill 52 152 515 52 153 515 minecraft:polished_blackstone_bricks
fill 52 152 531 52 153 531 minecraft:polished_blackstone_bricks
fill 52 152 533 52 153 533 minecraft:polished_blackstone_bricks
fill 52 152 535 52 153 535 minecraft:polished_blackstone_bricks
fill 52 152 537 52 153 537 minecraft:polished_blackstone_bricks
fill 52 152 539 52 153 539 minecraft:polished_blackstone_bricks
fill 52 152 541 52 153 541 minecraft:polished_blackstone_bricks
fill 52 152 543 52 153 543 minecraft:polished_blackstone_bricks
fill 53 152 532 53 153 532 minecraft:polished_blackstone_bricks
fill 53 152 534 53 153 534 minecraft:polished_blackstone_bricks
fill 53 152 536 53 153 536 minecraft:polished_blackstone_bricks
fill 53 152 538 53 153 538 minecraft:polished_blackstone_bricks
fill 53 152 540 53 153 540 minecraft:polished_blackstone_bricks
fill 53 152 542 53 153 542 minecraft:polished_blackstone_bricks
fill 54 152 510 54 165 510 minecraft:polished_blackstone_bricks
fill 54 152 531 54 153 531 minecraft:polished_blackstone_bricks
fill 54 152 533 54 153 533 minecraft:polished_blackstone_bricks
fill 54 152 535 54 153 535 minecraft:polished_blackstone_bricks
fill 54 152 537 54 153 537 minecraft:polished_blackstone_bricks
fill 54 152 539 54 153 539 minecraft:polished_blackstone_bricks
fill 54 152 541 54 153 541 minecraft:polished_blackstone_bricks
fill 54 152 543 54 153 543 minecraft:polished_blackstone_bricks
fill 55 152 510 56 152 510 minecraft:crying_obsidian
fill 55 152 532 55 153 532 minecraft:polished_blackstone_bricks
fill 55 152 534 55 153 534 minecraft:polished_blackstone_bricks
fill 55 152 536 55 153 536 minecraft:polished_blackstone_bricks
fill 55 152 538 55 153 538 minecraft:polished_blackstone_bricks
fill 55 152 540 55 153 540 minecraft:polished_blackstone_bricks
fill 55 152 542 55 153 542 minecraft:polished_blackstone_bricks
fill 56 152 531 56 153 531 minecraft:polished_blackstone_bricks
fill 56 152 533 56 153 533 minecraft:polished_blackstone_bricks
fill 56 152 535 56 153 535 minecraft:polished_blackstone_bricks
fill 56 152 537 56 153 537 minecraft:polished_blackstone_bricks
fill 56 152 539 56 153 539 minecraft:polished_blackstone_bricks
fill 56 152 541 56 153 541 minecraft:polished_blackstone_bricks
fill 56 152 543 56 153 543 minecraft:polished_blackstone_bricks
fill 57 152 510 57 165 510 minecraft:polished_blackstone_bricks
fill 57 152 532 57 153 532 minecraft:polished_blackstone_bricks
fill 57 152 534 57 153 534 minecraft:polished_blackstone_bricks
fill 57 152 536 57 153 536 minecraft:polished_blackstone_bricks
fill 57 152 538 57 153 538 minecraft:polished_blackstone_bricks
fill 57 152 540 57 153 540 minecraft:polished_blackstone_bricks
fill 57 152 542 57 153 542 minecraft:polished_blackstone_bricks
fill 59 152 552 59 165 552 minecraft:polished_blackstone_bricks
fill 60 152 552 61 152 552 minecraft:crying_obsidian
fill 62 152 552 62 165 552 minecraft:polished_blackstone_bricks
fill 66 152 510 66 165 510 minecraft:polished_blackstone_bricks
fill 67 152 510 68 152 510 minecraft:crying_obsidian
fill 69 152 510 69 165 510 minecraft:polished_blackstone_bricks
fill 71 152 552 71 165 552 minecraft:polished_blackstone_bricks
fill 72 152 552 73 152 552 minecraft:crying_obsidian
fill 74 152 552 74 165 552 minecraft:polished_blackstone_bricks
fill 78 152 510 78 165 510 minecraft:polished_blackstone_bricks
fill 79 152 510 80 152 510 minecraft:crying_obsidian
fill 81 152 510 81 165 510 minecraft:polished_blackstone_bricks
fill 83 152 552 83 165 552 minecraft:polished_blackstone_bricks
fill 84 152 552 85 152 552 minecraft:crying_obsidian
fill 86 152 552 86 165 552 minecraft:polished_blackstone_bricks
fill 89 152 511 89 165 511 minecraft:polished_blackstone_bricks
fill 89 152 512 89 152 513 minecraft:crying_obsidian
fill 89 152 514 89 165 514 minecraft:polished_blackstone_bricks
fill 89 152 523 89 165 523 minecraft:polished_blackstone_bricks
fill 89 152 524 89 152 525 minecraft:crying_obsidian
fill 89 152 526 89 165 526 minecraft:polished_blackstone_bricks
fill 89 152 535 89 165 535 minecraft:polished_blackstone_bricks
fill 89 152 536 89 152 537 minecraft:crying_obsidian
fill 89 152 538 89 165 538 minecraft:polished_blackstone_bricks
fill 89 152 547 89 165 547 minecraft:polished_blackstone_bricks
fill 89 152 548 89 152 549 minecraft:crying_obsidian
fill 89 152 550 89 165 550 minecraft:polished_blackstone_bricks
fill 47 153 517 47 165 518 minecraft:polished_blackstone_bricks
fill 47 153 529 47 165 530 minecraft:polished_blackstone_bricks
fill 47 153 541 47 165 542 minecraft:polished_blackstone_bricks
fill 48 153 552 49 165 552 minecraft:polished_blackstone_bricks
fill 55 153 510 56 165 510 minecraft:polished_blackstone_bricks
fill 60 153 552 61 165 552 minecraft:polished_blackstone_bricks
fill 67 153 510 68 165 510 minecraft:polished_blackstone_bricks
fill 72 153 552 73 165 552 minecraft:polished_blackstone_bricks
fill 79 153 510 80 165 510 minecraft:polished_blackstone_bricks
fill 84 153 552 85 165 552 minecraft:polished_blackstone_bricks
fill 89 153 512 89 165 513 minecraft:polished_blackstone_bricks
fill 89 153 524 89 165 525 minecraft:polished_blackstone_bricks
fill 89 153 536 89 165 537 minecraft:polished_blackstone_bricks
fill 89 153 548 89 165 549 minecraft:polished_blackstone_bricks
fill 47 154 531 47 165 531 minecraft:polished_blackstone_bricks
fill 47 154 543 47 165 543 minecraft:polished_blackstone_bricks
setblock 48 154 511 minecraft:crying_obsidian
setblock 48 154 513 minecraft:crying_obsidian
setblock 48 154 515 minecraft:crying_obsidian
setblock 48 154 531 minecraft:crying_obsidian
setblock 48 154 533 minecraft:crying_obsidian
setblock 48 154 535 minecraft:crying_obsidian
setblock 48 154 537 minecraft:crying_obsidian
setblock 48 154 539 minecraft:crying_obsidian
setblock 48 154 541 minecraft:crying_obsidian
setblock 48 154 543 minecraft:crying_obsidian
setblock 49 154 510 minecraft:crying_obsidian
setblock 49 154 512 minecraft:crying_obsidian
setblock 49 154 514 minecraft:crying_obsidian
setblock 49 154 516 minecraft:crying_obsidian
setblock 49 154 532 minecraft:crying_obsidian
setblock 49 154 534 minecraft:crying_obsidian
setblock 49 154 536 minecraft:crying_obsidian
setblock 49 154 538 minecraft:crying_obsidian
setblock 49 154 540 minecraft:crying_obsidian
setblock 49 154 542 minecraft:crying_obsidian
setblock 50 154 511 minecraft:crying_obsidian
setblock 50 154 513 minecraft:crying_obsidian
setblock 50 154 515 minecraft:crying_obsidian
setblock 50 154 521 minecraft:light[level=11]
setblock 50 154 529 minecraft:light[level=11]
setblock 50 154 531 minecraft:crying_obsidian
setblock 50 154 533 minecraft:crying_obsidian
setblock 50 154 535 minecraft:crying_obsidian
setblock 50 154 537 minecraft:crying_obsidian
setblock 50 154 539 minecraft:crying_obsidian
setblock 50 154 541 minecraft:crying_obsidian
setblock 50 154 543 minecraft:crying_obsidian
setblock 50 154 545 minecraft:light[level=11]
setblock 51 154 510 minecraft:crying_obsidian
setblock 51 154 512 minecraft:crying_obsidian
setblock 51 154 514 minecraft:crying_obsidian
setblock 51 154 516 minecraft:crying_obsidian
setblock 51 154 532 minecraft:crying_obsidian
setblock 51 154 534 minecraft:crying_obsidian
setblock 51 154 536 minecraft:crying_obsidian
setblock 51 154 538 minecraft:crying_obsidian
setblock 51 154 540 minecraft:crying_obsidian
setblock 51 154 542 minecraft:crying_obsidian
setblock 52 154 511 minecraft:crying_obsidian
setblock 52 154 513 minecraft:crying_obsidian
setblock 52 154 515 minecraft:crying_obsidian
setblock 52 154 531 minecraft:crying_obsidian
setblock 52 154 533 minecraft:crying_obsidian
setblock 52 154 535 minecraft:crying_obsidian
setblock 52 154 537 minecraft:crying_obsidian
setblock 52 154 539 minecraft:crying_obsidian
setblock 52 154 541 minecraft:crying_obsidian
setblock 52 154 543 minecraft:crying_obsidian
setblock 53 154 532 minecraft:crying_obsidian
setblock 53 154 534 minecraft:crying_obsidian
setblock 53 154 536 minecraft:crying_obsidian
setblock 53 154 538 minecraft:crying_obsidian
setblock 53 154 540 minecraft:crying_obsidian
setblock 53 154 542 minecraft:crying_obsidian
setblock 54 154 531 minecraft:crying_obsidian
setblock 54 154 533 minecraft:crying_obsidian
setblock 54 154 535 minecraft:crying_obsidian
setblock 54 154 537 minecraft:crying_obsidian
setblock 54 154 539 minecraft:crying_obsidian
setblock 54 154 541 minecraft:crying_obsidian
setblock 54 154 543 minecraft:crying_obsidian
setblock 55 154 532 minecraft:crying_obsidian
setblock 55 154 534 minecraft:crying_obsidian
setblock 55 154 536 minecraft:crying_obsidian
setblock 55 154 538 minecraft:crying_obsidian
setblock 55 154 540 minecraft:crying_obsidian
setblock 55 154 542 minecraft:crying_obsidian
setblock 56 154 531 minecraft:crying_obsidian
setblock 56 154 533 minecraft:crying_obsidian
setblock 56 154 535 minecraft:crying_obsidian
setblock 56 154 537 minecraft:crying_obsidian
setblock 56 154 539 minecraft:crying_obsidian
setblock 56 154 541 minecraft:crying_obsidian
setblock 56 154 543 minecraft:crying_obsidian
setblock 57 154 532 minecraft:crying_obsidian
setblock 57 154 534 minecraft:crying_obsidian
setblock 57 154 536 minecraft:crying_obsidian
setblock 57 154 538 minecraft:crying_obsidian
setblock 57 154 540 minecraft:crying_obsidian
setblock 57 154 542 minecraft:crying_obsidian
setblock 58 154 513 minecraft:light[level=11]
setblock 58 154 521 minecraft:light[level=11]
setblock 58 154 529 minecraft:light[level=11]
setblock 58 154 537 minecraft:light[level=11]
setblock 58 154 545 minecraft:light[level=11]
setblock 66 154 513 minecraft:light[level=11]
setblock 66 154 521 minecraft:light[level=11]
setblock 66 154 529 minecraft:light[level=11]
setblock 66 154 537 minecraft:light[level=11]
setblock 66 154 545 minecraft:light[level=11]
setblock 74 154 513 minecraft:light[level=11]
setblock 74 154 521 minecraft:light[level=11]
setblock 74 154 529 minecraft:light[level=11]
setblock 74 154 537 minecraft:light[level=11]
setblock 74 154 545 minecraft:light[level=11]
setblock 82 154 513 minecraft:light[level=11]
setblock 82 154 521 minecraft:light[level=11]
setblock 82 154 529 minecraft:light[level=11]
setblock 82 154 537 minecraft:light[level=11]
fill 48 155 511 48 156 511 minecraft:polished_blackstone_bricks
fill 48 155 513 48 156 513 minecraft:polished_blackstone_bricks
fill 48 155 515 48 156 515 minecraft:polished_blackstone_bricks
fill 48 155 531 48 156 531 minecraft:polished_blackstone_bricks
fill 48 155 533 48 156 533 minecraft:polished_blackstone_bricks
fill 48 155 535 48 156 535 minecraft:polished_blackstone_bricks
fill 48 155 537 48 156 537 minecraft:polished_blackstone_bricks
fill 48 155 539 48 156 539 minecraft:polished_blackstone_bricks
fill 48 155 541 48 156 541 minecraft:polished_blackstone_bricks
fill 48 155 543 48 156 543 minecraft:polished_blackstone_bricks
fill 49 155 510 49 156 510 minecraft:polished_blackstone_bricks
fill 49 155 512 49 156 512 minecraft:polished_blackstone_bricks
fill 49 155 514 49 156 514 minecraft:polished_blackstone_bricks
fill 49 155 516 49 156 516 minecraft:polished_blackstone_bricks
fill 49 155 532 49 156 532 minecraft:polished_blackstone_bricks
fill 49 155 534 49 156 534 minecraft:polished_blackstone_bricks
fill 49 155 536 49 156 536 minecraft:polished_blackstone_bricks
fill 49 155 538 49 156 538 minecraft:polished_blackstone_bricks
fill 49 155 540 49 156 540 minecraft:polished_blackstone_bricks
fill 49 155 542 49 156 542 minecraft:polished_blackstone_bricks
fill 50 155 511 50 156 511 minecraft:polished_blackstone_bricks
fill 50 155 513 50 156 513 minecraft:polished_blackstone_bricks
fill 50 155 515 50 156 515 minecraft:polished_blackstone_bricks
fill 50 155 531 50 156 531 minecraft:polished_blackstone_bricks
fill 50 155 533 50 156 533 minecraft:polished_blackstone_bricks
fill 50 155 535 50 156 535 minecraft:polished_blackstone_bricks
fill 50 155 537 50 156 537 minecraft:polished_blackstone_bricks
fill 50 155 539 50 156 539 minecraft:polished_blackstone_bricks
fill 50 155 541 50 156 541 minecraft:polished_blackstone_bricks
fill 50 155 543 50 156 543 minecraft:polished_blackstone_bricks
fill 51 155 510 51 156 510 minecraft:polished_blackstone_bricks
fill 51 155 512 51 156 512 minecraft:polished_blackstone_bricks
fill 51 155 514 51 156 514 minecraft:polished_blackstone_bricks
fill 51 155 516 51 156 516 minecraft:polished_blackstone_bricks
fill 51 155 532 51 156 532 minecraft:polished_blackstone_bricks
fill 51 155 534 51 156 534 minecraft:polished_blackstone_bricks
fill 51 155 536 51 156 536 minecraft:polished_blackstone_bricks
fill 51 155 538 51 156 538 minecraft:polished_blackstone_bricks
fill 51 155 540 51 156 540 minecraft:polished_blackstone_bricks
fill 51 155 542 51 156 542 minecraft:polished_blackstone_bricks
fill 52 155 511 52 156 511 minecraft:polished_blackstone_bricks
fill 52 155 513 52 156 513 minecraft:polished_blackstone_bricks
fill 52 155 515 52 156 515 minecraft:polished_blackstone_bricks
fill 52 155 531 52 156 531 minecraft:polished_blackstone_bricks
fill 52 155 533 52 156 533 minecraft:polished_blackstone_bricks
fill 52 155 535 52 156 535 minecraft:polished_blackstone_bricks
fill 52 155 537 52 156 537 minecraft:polished_blackstone_bricks
fill 52 155 539 52 156 539 minecraft:polished_blackstone_bricks
fill 52 155 541 52 156 541 minecraft:polished_blackstone_bricks
fill 52 155 543 52 156 543 minecraft:polished_blackstone_bricks
fill 53 155 532 53 156 532 minecraft:polished_blackstone_bricks
fill 53 155 534 53 156 534 minecraft:polished_blackstone_bricks
fill 53 155 536 53 156 536 minecraft:polished_blackstone_bricks
fill 53 155 538 53 156 538 minecraft:polished_blackstone_bricks
fill 53 155 540 53 156 540 minecraft:polished_blackstone_bricks
fill 53 155 542 53 156 542 minecraft:polished_blackstone_bricks
fill 54 155 531 54 156 531 minecraft:polished_blackstone_bricks
fill 54 155 533 54 156 533 minecraft:polished_blackstone_bricks
fill 54 155 535 54 156 535 minecraft:polished_blackstone_bricks
fill 54 155 537 54 156 537 minecraft:polished_blackstone_bricks
fill 54 155 539 54 156 539 minecraft:polished_blackstone_bricks
fill 54 155 541 54 156 541 minecraft:polished_blackstone_bricks
fill 54 155 543 54 156 543 minecraft:polished_blackstone_bricks
fill 55 155 532 55 156 532 minecraft:polished_blackstone_bricks
fill 55 155 534 55 156 534 minecraft:polished_blackstone_bricks
fill 55 155 536 55 156 536 minecraft:polished_blackstone_bricks
fill 55 155 538 55 156 538 minecraft:polished_blackstone_bricks
fill 55 155 540 55 156 540 minecraft:polished_blackstone_bricks
fill 55 155 542 55 156 542 minecraft:polished_blackstone_bricks
fill 56 155 531 56 156 531 minecraft:polished_blackstone_bricks
fill 56 155 533 56 156 533 minecraft:polished_blackstone_bricks
fill 56 155 535 56 156 535 minecraft:polished_blackstone_bricks
fill 56 155 537 56 156 537 minecraft:polished_blackstone_bricks
fill 56 155 539 56 156 539 minecraft:polished_blackstone_bricks
fill 56 155 541 56 156 541 minecraft:polished_blackstone_bricks
fill 56 155 543 56 156 543 minecraft:polished_blackstone_bricks
fill 57 155 532 57 156 532 minecraft:polished_blackstone_bricks
fill 57 155 534 57 156 534 minecraft:polished_blackstone_bricks
fill 57 155 536 57 156 536 minecraft:polished_blackstone_bricks
fill 57 155 538 57 156 538 minecraft:polished_blackstone_bricks
fill 57 155 540 57 156 540 minecraft:polished_blackstone_bricks
fill 57 155 542 57 156 542 minecraft:polished_blackstone_bricks
setblock 48 157 511 minecraft:crying_obsidian
setblock 48 157 513 minecraft:crying_obsidian
setblock 48 157 515 minecraft:crying_obsidian
setblock 48 157 531 minecraft:crying_obsidian
setblock 48 157 533 minecraft:crying_obsidian
setblock 48 157 535 minecraft:crying_obsidian
setblock 48 157 537 minecraft:crying_obsidian
setblock 48 157 539 minecraft:crying_obsidian
setblock 48 157 541 minecraft:crying_obsidian
setblock 48 157 543 minecraft:crying_obsidian
setblock 49 157 510 minecraft:crying_obsidian
setblock 49 157 512 minecraft:crying_obsidian
setblock 49 157 514 minecraft:crying_obsidian
setblock 49 157 516 minecraft:crying_obsidian
setblock 49 157 532 minecraft:crying_obsidian
setblock 49 157 534 minecraft:crying_obsidian
setblock 49 157 536 minecraft:crying_obsidian
setblock 49 157 538 minecraft:crying_obsidian
setblock 49 157 540 minecraft:crying_obsidian
setblock 49 157 542 minecraft:crying_obsidian
setblock 50 157 511 minecraft:crying_obsidian
setblock 50 157 513 minecraft:crying_obsidian
setblock 50 157 515 minecraft:crying_obsidian
setblock 50 157 531 minecraft:crying_obsidian
setblock 50 157 533 minecraft:crying_obsidian
setblock 50 157 535 minecraft:crying_obsidian
setblock 50 157 537 minecraft:crying_obsidian
setblock 50 157 539 minecraft:crying_obsidian
setblock 50 157 541 minecraft:crying_obsidian
setblock 50 157 543 minecraft:crying_obsidian
setblock 51 157 510 minecraft:crying_obsidian
setblock 51 157 512 minecraft:crying_obsidian
setblock 51 157 514 minecraft:crying_obsidian
setblock 51 157 516 minecraft:crying_obsidian
setblock 51 157 532 minecraft:crying_obsidian
setblock 51 157 534 minecraft:crying_obsidian
setblock 51 157 536 minecraft:crying_obsidian
setblock 51 157 538 minecraft:crying_obsidian
setblock 51 157 540 minecraft:crying_obsidian
setblock 51 157 542 minecraft:crying_obsidian
setblock 52 157 511 minecraft:crying_obsidian
setblock 52 157 513 minecraft:crying_obsidian
setblock 52 157 515 minecraft:crying_obsidian
setblock 52 157 531 minecraft:crying_obsidian
setblock 52 157 533 minecraft:crying_obsidian
setblock 52 157 535 minecraft:crying_obsidian
setblock 52 157 537 minecraft:crying_obsidian
setblock 52 157 539 minecraft:crying_obsidian
setblock 52 157 541 minecraft:crying_obsidian
setblock 52 157 543 minecraft:crying_obsidian
setblock 53 157 532 minecraft:crying_obsidian
setblock 53 157 534 minecraft:crying_obsidian
setblock 53 157 536 minecraft:crying_obsidian
setblock 53 157 538 minecraft:crying_obsidian
setblock 53 157 540 minecraft:crying_obsidian
setblock 53 157 542 minecraft:crying_obsidian
setblock 54 157 531 minecraft:crying_obsidian
setblock 54 157 533 minecraft:crying_obsidian
setblock 54 157 535 minecraft:crying_obsidian
setblock 54 157 537 minecraft:crying_obsidian
setblock 54 157 539 minecraft:crying_obsidian
setblock 54 157 541 minecraft:crying_obsidian
setblock 54 157 543 minecraft:crying_obsidian
setblock 55 157 532 minecraft:crying_obsidian
setblock 55 157 534 minecraft:crying_obsidian
setblock 55 157 536 minecraft:crying_obsidian
setblock 55 157 538 minecraft:crying_obsidian
setblock 55 157 540 minecraft:crying_obsidian
setblock 55 157 542 minecraft:crying_obsidian
setblock 56 157 531 minecraft:crying_obsidian
setblock 56 157 533 minecraft:crying_obsidian
setblock 56 157 535 minecraft:crying_obsidian
setblock 56 157 537 minecraft:crying_obsidian
setblock 56 157 539 minecraft:crying_obsidian
setblock 56 157 541 minecraft:crying_obsidian
setblock 56 157 543 minecraft:crying_obsidian
setblock 57 157 532 minecraft:crying_obsidian
setblock 57 157 534 minecraft:crying_obsidian
setblock 57 157 536 minecraft:crying_obsidian
setblock 57 157 538 minecraft:crying_obsidian
setblock 57 157 540 minecraft:crying_obsidian
setblock 57 157 542 minecraft:crying_obsidian
fill 48 158 511 48 181 511 minecraft:polished_blackstone_bricks
fill 48 158 513 48 159 513 minecraft:polished_blackstone_bricks
fill 48 158 515 48 159 515 minecraft:polished_blackstone_bricks
setblock 48 158 531 minecraft:polished_blackstone_bricks
fill 48 158 533 48 181 533 minecraft:polished_blackstone_bricks
fill 48 158 535 48 181 535 minecraft:polished_blackstone_bricks
setblock 48 158 537 minecraft:polished_blackstone_bricks
setblock 48 158 539 minecraft:polished_blackstone_bricks
setblock 48 158 541 minecraft:polished_blackstone_bricks
setblock 48 158 543 minecraft:polished_blackstone_bricks
fill 49 158 510 49 192 510 minecraft:polished_blackstone_bricks
fill 49 158 512 49 159 512 minecraft:polished_blackstone_bricks
fill 49 158 514 49 159 514 minecraft:polished_blackstone_bricks
fill 49 158 516 49 159 516 minecraft:polished_blackstone_bricks
setblock 49 158 532 minecraft:polished_blackstone_bricks
setblock 49 158 534 minecraft:polished_blackstone_bricks
setblock 49 158 536 minecraft:polished_blackstone_bricks
setblock 49 158 538 minecraft:polished_blackstone_bricks
setblock 49 158 540 minecraft:polished_blackstone_bricks
setblock 49 158 542 minecraft:polished_blackstone_bricks
fill 50 158 511 50 181 511 minecraft:polished_blackstone_bricks
fill 50 158 513 50 159 513 minecraft:polished_blackstone_bricks
fill 50 158 515 50 159 515 minecraft:polished_blackstone_bricks
setblock 50 158 531 minecraft:polished_blackstone_bricks
setblock 50 158 533 minecraft:polished_blackstone_bricks
setblock 50 158 535 minecraft:polished_blackstone_bricks
setblock 50 158 537 minecraft:polished_blackstone_bricks
setblock 50 158 539 minecraft:polished_blackstone_bricks
setblock 50 158 541 minecraft:polished_blackstone_bricks
setblock 50 158 543 minecraft:polished_blackstone_bricks
fill 51 158 510 51 192 510 minecraft:polished_blackstone_bricks
fill 51 158 512 51 159 512 minecraft:polished_blackstone_bricks
fill 51 158 514 51 159 514 minecraft:polished_blackstone_bricks
fill 51 158 516 51 159 516 minecraft:polished_blackstone_bricks
setblock 51 158 532 minecraft:polished_blackstone_bricks
setblock 51 158 534 minecraft:polished_blackstone_bricks
setblock 51 158 536 minecraft:polished_blackstone_bricks
setblock 51 158 538 minecraft:polished_blackstone_bricks
setblock 51 158 540 minecraft:polished_blackstone_bricks
setblock 51 158 542 minecraft:polished_blackstone_bricks
fill 52 158 511 52 159 511 minecraft:polished_blackstone_bricks
fill 52 158 513 52 159 513 minecraft:polished_blackstone_bricks
fill 52 158 515 52 159 515 minecraft:polished_blackstone_bricks
setblock 52 158 531 minecraft:polished_blackstone_bricks
setblock 52 158 533 minecraft:polished_blackstone_bricks
setblock 52 158 535 minecraft:polished_blackstone_bricks
setblock 52 158 537 minecraft:polished_blackstone_bricks
setblock 52 158 539 minecraft:polished_blackstone_bricks
setblock 52 158 541 minecraft:polished_blackstone_bricks
setblock 52 158 543 minecraft:polished_blackstone_bricks
setblock 53 158 532 minecraft:polished_blackstone_bricks
setblock 53 158 534 minecraft:polished_blackstone_bricks
setblock 53 158 536 minecraft:polished_blackstone_bricks
setblock 53 158 538 minecraft:polished_blackstone_bricks
setblock 53 158 540 minecraft:polished_blackstone_bricks
setblock 53 158 542 minecraft:polished_blackstone_bricks
setblock 54 158 531 minecraft:polished_blackstone_bricks
setblock 54 158 533 minecraft:polished_blackstone_bricks
setblock 54 158 535 minecraft:polished_blackstone_bricks
setblock 54 158 537 minecraft:polished_blackstone_bricks
setblock 54 158 539 minecraft:polished_blackstone_bricks
setblock 54 158 541 minecraft:polished_blackstone_bricks
setblock 54 158 543 minecraft:polished_blackstone_bricks
setblock 55 158 532 minecraft:polished_blackstone_bricks
setblock 55 158 534 minecraft:polished_blackstone_bricks
setblock 55 158 536 minecraft:polished_blackstone_bricks
setblock 55 158 538 minecraft:polished_blackstone_bricks
setblock 55 158 540 minecraft:polished_blackstone_bricks
setblock 55 158 542 minecraft:polished_blackstone_bricks
setblock 56 158 531 minecraft:polished_blackstone_bricks
setblock 56 158 533 minecraft:polished_blackstone_bricks
setblock 56 158 535 minecraft:polished_blackstone_bricks
setblock 56 158 537 minecraft:polished_blackstone_bricks
setblock 56 158 539 minecraft:polished_blackstone_bricks
setblock 56 158 541 minecraft:polished_blackstone_bricks
setblock 56 158 543 minecraft:polished_blackstone_bricks
setblock 57 158 532 minecraft:polished_blackstone_bricks
setblock 57 158 534 minecraft:polished_blackstone_bricks
setblock 57 158 536 minecraft:polished_blackstone_bricks
setblock 57 158 538 minecraft:polished_blackstone_bricks
setblock 57 158 540 minecraft:polished_blackstone_bricks
setblock 57 158 542 minecraft:polished_blackstone_bricks
fill 81 158 545 81 158 547 minecraft:blackstone
setblock 82 158 548 minecraft:blackstone
fill 83 158 544 84 158 544 minecraft:blackstone
fill 84 158 548 85 158 548 minecraft:blackstone
fill 85 158 545 85 158 547 minecraft:blackstone
fill 49 159 532 56 159 542 minecraft:purple_stained_glass
fill 49 160 512 51 160 515 minecraft:purple_stained_glass
fill 49 160 520 49 165 522 minecraft:polished_blackstone_bricks
fill 49 160 532 49 165 534 minecraft:polished_blackstone_bricks
fill 49 160 544 49 165 546 minecraft:polished_blackstone_bricks
fill 50 160 533 55 160 541 minecraft:purple_stained_glass
setblock 51 160 511 minecraft:purple_stained_glass
fill 55 160 550 57 165 550 minecraft:polished_blackstone_bricks
fill 59 160 512 61 165 512 minecraft:polished_blackstone_bricks
fill 67 160 550 69 165 550 minecraft:polished_blackstone_bricks
fill 71 160 512 73 165 512 minecraft:polished_blackstone_bricks
fill 79 160 550 81 165 550 minecraft:polished_blackstone_bricks
fill 83 160 512 85 165 512 minecraft:polished_blackstone_bricks
fill 87 160 520 87 165 522 minecraft:polished_blackstone_bricks
fill 87 160 532 87 165 534 minecraft:polished_blackstone_bricks
fill 87 160 544 87 165 546 minecraft:polished_blackstone_bricks
fill 50 161 512 50 161 514 minecraft:purple_stained_glass
fill 51 161 534 54 161 540 minecraft:purple_stained_glass
fill 49 162 513 51 163 513 minecraft:purple_stained_glass
setblock 50 162 521 minecraft:light[level=11]
setblock 50 162 529 minecraft:light[level=11]
setblock 50 162 537 minecraft:light[level=11]
setblock 50 162 545 minecraft:light[level=11]
fill 52 162 535 53 162 539 minecraft:purple_stained_glass
fill 55 162 513 59 163 517 minecraft:blackstone
fill 57 162 511 57 162 512 minecraft:blackstone
setblock 58 162 521 minecraft:light[level=11]
setblock 58 162 529 minecraft:light[level=11]
setblock 58 162 537 minecraft:light[level=11]
setblock 58 162 545 minecraft:light[level=11]
setblock 66 162 513 minecraft:light[level=11]
setblock 66 162 521 minecraft:light[level=11]
setblock 66 162 529 minecraft:light[level=11]
setblock 66 162 537 minecraft:light[level=11]
setblock 66 162 545 minecraft:light[level=11]
setblock 74 162 513 minecraft:light[level=11]
setblock 74 162 521 minecraft:light[level=11]
setblock 74 162 529 minecraft:light[level=11]
setblock 74 162 537 minecraft:light[level=11]
setblock 74 162 545 minecraft:light[level=11]
setblock 82 162 513 minecraft:light[level=11]
setblock 82 162 521 minecraft:light[level=11]
setblock 82 162 529 minecraft:light[level=11]
setblock 82 162 537 minecraft:light[level=11]
fill 48 163 512 48 163 514 minecraft:purple_stained_glass
fill 49 163 512 52 163 512 minecraft:purple_stained_glass
fill 49 163 514 52 163 514 minecraft:purple_stained_glass
setblock 52 163 513 minecraft:purple_stained_glass
fill 56 164 515 58 171 515 minecraft:purple_stained_glass
fill 57 164 514 57 171 514 minecraft:purple_stained_glass
fill 57 164 516 57 171 516 minecraft:purple_stained_glass
fill 48 165 514 48 165 519 minecraft:blackstone
fill 48 165 526 48 165 531 minecraft:blackstone
fill 48 165 538 48 165 543 minecraft:blackstone
fill 48 165 550 48 165 551 minecraft:blackstone
fill 49 165 551 52 165 551 minecraft:blackstone
fill 52 165 511 57 165 511 minecraft:blackstone
fill 59 165 551 64 165 551 minecraft:blackstone
fill 64 165 511 69 165 511 minecraft:blackstone
fill 71 165 551 76 165 551 minecraft:blackstone
fill 76 165 511 81 165 511 minecraft:blackstone
fill 83 165 551 88 165 551 minecraft:blackstone
fill 88 165 511 88 165 516 minecraft:blackstone
fill 88 165 523 88 165 528 minecraft:blackstone
fill 88 165 535 88 165 540 minecraft:blackstone
fill 88 165 547 88 165 550 minecraft:blackstone
fill 47 166 516 47 171 519 minecraft:crying_obsidian
fill 47 166 528 47 171 531 minecraft:crying_obsidian
fill 47 166 540 47 171 543 minecraft:crying_obsidian
fill 47 166 552 50 171 552 minecraft:crying_obsidian
fill 54 166 510 57 171 510 minecraft:crying_obsidian
fill 59 166 552 62 171 552 minecraft:crying_obsidian
fill 66 166 510 69 171 510 minecraft:crying_obsidian
fill 71 166 552 74 171 552 minecraft:crying_obsidian
fill 78 166 510 81 171 510 minecraft:crying_obsidian
fill 81 166 545 81 166 547 minecraft:blackstone
setblock 82 166 548 minecraft:blackstone
fill 83 166 544 84 166 544 minecraft:blackstone
fill 83 166 552 86 171 552 minecraft:crying_obsidian
fill 84 166 548 85 166 548 minecraft:blackstone
fill 85 166 545 85 166 547 minecraft:blackstone
fill 89 166 511 89 171 514 minecraft:crying_obsidian
fill 89 166 523 89 171 526 minecraft:crying_obsidian
fill 89 166 535 89 171 538 minecraft:crying_obsidian
fill 89 166 547 89 171 550 minecraft:crying_obsidian
setblock 50 170 513 minecraft:light[level=11]
setblock 50 170 521 minecraft:light[level=11]
setblock 50 170 529 minecraft:light[level=11]
setblock 50 170 537 minecraft:light[level=11]
setblock 50 170 545 minecraft:light[level=11]
setblock 58 170 513 minecraft:light[level=11]
setblock 58 170 521 minecraft:light[level=11]
setblock 58 170 529 minecraft:light[level=11]
setblock 58 170 537 minecraft:light[level=11]
setblock 58 170 545 minecraft:light[level=11]
setblock 66 170 513 minecraft:light[level=11]
setblock 66 170 521 minecraft:light[level=11]
setblock 66 170 529 minecraft:light[level=11]
setblock 66 170 537 minecraft:light[level=11]
setblock 66 170 545 minecraft:light[level=11]
setblock 74 170 513 minecraft:light[level=11]
setblock 74 170 521 minecraft:light[level=11]
setblock 74 170 529 minecraft:light[level=11]
setblock 74 170 537 minecraft:light[level=11]
setblock 74 170 545 minecraft:light[level=11]
setblock 82 170 513 minecraft:light[level=11]
setblock 82 170 521 minecraft:light[level=11]
setblock 82 170 529 minecraft:light[level=11]
setblock 82 170 537 minecraft:light[level=11]
fill 47 172 516 47 205 516 minecraft:polished_blackstone_bricks
fill 47 172 517 47 172 518 minecraft:crying_obsidian
fill 47 172 519 47 205 519 minecraft:polished_blackstone_bricks
fill 47 172 528 47 205 528 minecraft:polished_blackstone_bricks
fill 47 172 529 47 172 530 minecraft:crying_obsidian
fill 47 172 531 47 205 531 minecraft:polished_blackstone_bricks
fill 47 172 540 47 205 540 minecraft:polished_blackstone_bricks
fill 47 172 541 47 172 542 minecraft:crying_obsidian
fill 47 172 543 47 205 543 minecraft:polished_blackstone_bricks
fill 47 172 552 47 205 552 minecraft:polished_blackstone_bricks
fill 48 172 552 49 172 552 minecraft:crying_obsidian
fill 50 172 552 50 205 552 minecraft:polished_blackstone_bricks
fill 54 172 510 54 205 510 minecraft:polished_blackstone_bricks
fill 55 172 510 56 172 510 minecraft:crying_obsidian
fill 57 172 510 57 205 510 minecraft:polished_blackstone_bricks
fill 59 172 552 59 205 552 minecraft:polished_blackstone_bricks
fill 60 172 552 61 172 552 minecraft:crying_obsidian
fill 62 172 552 62 205 552 minecraft:polished_blackstone_bricks
fill 66 172 510 66 205 510 minecraft:polished_blackstone_bricks
fill 67 172 510 68 172 510 minecraft:crying_obsidian
fill 69 172 510 69 205 510 minecraft:polished_blackstone_bricks
fill 71 172 552 71 186 552 minecraft:polished_blackstone_bricks
fill 72 172 552 73 172 552 minecraft:crying_obsidian
fill 74 172 552 74 205 552 minecraft:polished_blackstone_bricks
fill 78 172 510 78 205 510 minecraft:polished_blackstone_bricks
fill 79 172 510 80 172 510 minecraft:crying_obsidian
fill 81 172 510 81 205 510 minecraft:polished_blackstone_bricks
fill 83 172 552 83 205 552 minecraft:polished_blackstone_bricks
fill 84 172 552 85 172 552 minecraft:crying_obsidian
fill 86 172 552 86 205 552 minecraft:polished_blackstone_bricks
fill 89 172 511 89 205 511 minecraft:polished_blackstone_bricks
fill 89 172 512 89 172 513 minecraft:crying_obsidian
fill 89 172 514 89 205 514 minecraft:polished_blackstone_bricks
fill 89 172 523 89 205 523 minecraft:polished_blackstone_bricks
fill 89 172 524 89 172 525 minecraft:crying_obsidian
fill 89 172 526 89 205 526 minecraft:polished_blackstone_bricks
fill 89 172 535 89 205 535 minecraft:polished_blackstone_bricks
fill 89 172 536 89 172 537 minecraft:crying_obsidian
fill 89 172 538 89 205 538 minecraft:polished_blackstone_bricks
fill 89 172 547 89 205 547 minecraft:polished_blackstone_bricks
fill 89 172 548 89 172 549 minecraft:crying_obsidian
fill 89 172 550 89 205 550 minecraft:polished_blackstone_bricks
fill 47 173 517 47 191 518 minecraft:polished_blackstone_bricks
fill 47 173 529 47 191 530 minecraft:polished_blackstone_bricks
fill 47 173 541 47 191 542 minecraft:polished_blackstone_bricks
fill 48 173 552 49 191 552 minecraft:polished_blackstone_bricks
fill 55 173 510 56 191 510 minecraft:polished_blackstone_bricks
fill 60 173 552 61 191 552 minecraft:polished_blackstone_bricks
fill 67 173 510 68 191 510 minecraft:polished_blackstone_bricks
fill 72 173 552 73 191 552 minecraft:polished_blackstone_bricks
fill 79 173 510 80 191 510 minecraft:polished_blackstone_bricks
fill 84 173 552 85 191 552 minecraft:polished_blackstone_bricks
fill 89 173 512 89 191 513 minecraft:polished_blackstone_bricks
fill 89 173 524 89 191 525 minecraft:polished_blackstone_bricks
fill 89 173 536 89 191 537 minecraft:polished_blackstone_bricks
fill 89 173 548 89 191 549 minecraft:polished_blackstone_bricks
setblock 57 174 515 minecraft:crying_obsidian
fill 81 174 545 81 174 547 minecraft:blackstone
setblock 82 174 548 minecraft:blackstone
fill 83 174 544 84 174 544 minecraft:blackstone
fill 84 174 548 85 174 548 minecraft:blackstone
fill 85 174 545 85 174 547 minecraft:blackstone
setblock 50 178 513 minecraft:light[level=11]
setblock 50 178 521 minecraft:light[level=11]
setblock 50 178 529 minecraft:light[level=11]
setblock 50 178 537 minecraft:light[level=11]
setblock 50 178 545 minecraft:light[level=11]
setblock 58 178 513 minecraft:light[level=11]
setblock 58 178 521 minecraft:light[level=11]
setblock 58 178 529 minecraft:light[level=11]
setblock 58 178 537 minecraft:light[level=11]
setblock 58 178 545 minecraft:light[level=11]
setblock 66 178 513 minecraft:light[level=11]
setblock 66 178 521 minecraft:light[level=11]
setblock 66 178 529 minecraft:light[level=11]
setblock 66 178 537 minecraft:light[level=11]
setblock 66 178 545 minecraft:light[level=11]
setblock 74 178 513 minecraft:light[level=11]
setblock 74 178 521 minecraft:light[level=11]
setblock 74 178 529 minecraft:light[level=11]
setblock 74 178 537 minecraft:light[level=11]
setblock 74 178 545 minecraft:light[level=11]
setblock 82 178 513 minecraft:light[level=11]
setblock 82 178 521 minecraft:light[level=11]
setblock 82 178 529 minecraft:light[level=11]
setblock 82 178 537 minecraft:light[level=11]
fill 49 180 520 49 181 522 minecraft:polished_blackstone_bricks
fill 49 180 532 49 181 534 minecraft:polished_blackstone_bricks
fill 49 180 544 49 181 546 minecraft:polished_blackstone_bricks
fill 55 180 550 57 181 550 minecraft:polished_blackstone_bricks
fill 59 180 512 61 181 512 minecraft:polished_blackstone_bricks
fill 67 180 550 69 181 550 minecraft:polished_blackstone_bricks
fill 71 180 512 73 181 512 minecraft:polished_blackstone_bricks
fill 79 180 550 81 181 550 minecraft:polished_blackstone_bricks
fill 81 180 546 81 181 547 minecraft:purple_stained_glass
fill 82 180 548 82 181 548 minecraft:purple_stained_glass
fill 83 180 512 85 181 512 minecraft:polished_blackstone_bricks
fill 83 180 544 83 181 544 minecraft:purple_stained_glass
fill 84 180 548 84 181 548 minecraft:purple_stained_glass
fill 85 180 545 85 181 547 minecraft:purple_stained_glass
fill 87 180 520 87 181 522 minecraft:polished_blackstone_bricks
fill 87 180 532 87 181 534 minecraft:polished_blackstone_bricks
fill 87 180 544 87 181 546 minecraft:polished_blackstone_bricks
setblock 50 186 513 minecraft:light[level=11]
setblock 50 186 521 minecraft:light[level=11]
setblock 50 186 529 minecraft:light[level=11]
setblock 50 186 537 minecraft:light[level=11]
setblock 50 186 545 minecraft:light[level=11]
setblock 58 186 513 minecraft:light[level=11]
setblock 58 186 521 minecraft:light[level=11]
setblock 58 186 529 minecraft:light[level=11]
setblock 58 186 537 minecraft:light[level=11]
setblock 58 186 545 minecraft:light[level=11]
fill 62 186 539 64 186 541 minecraft:redstone_block
setblock 66 186 513 minecraft:light[level=11]
setblock 66 186 521 minecraft:light[level=11]
setblock 66 186 529 minecraft:light[level=11]
setblock 66 186 537 minecraft:light[level=11]
setblock 66 186 545 minecraft:light[level=11]
fill 70 186 543 72 186 545 minecraft:redstone_block
fill 71 186 536 73 186 538 minecraft:redstone_block
setblock 74 186 513 minecraft:light[level=11]
setblock 74 186 521 minecraft:light[level=11]
setblock 74 186 529 minecraft:light[level=11]
setblock 74 186 537 minecraft:light[level=11]
setblock 74 186 545 minecraft:light[level=11]
setblock 82 186 513 minecraft:light[level=11]
setblock 82 186 521 minecraft:light[level=11]
setblock 82 186 529 minecraft:light[level=11]
setblock 82 186 537 minecraft:light[level=11]
setblock 82 186 545 minecraft:light[level=11]
fill 50 187 537 61 187 543 minecraft:polished_blackstone
fill 62 187 537 70 187 538 minecraft:polished_blackstone
fill 62 187 542 69 187 543 minecraft:polished_blackstone
fill 64 187 552 64 218 552 minecraft:polished_blackstone_bricks
fill 65 187 522 70 187 536 minecraft:polished_blackstone
fill 65 187 539 66 187 541 minecraft:polished_blackstone
fill 65 187 544 69 187 552 minecraft:polished_blackstone
fill 70 187 539 86 187 542 minecraft:polished_blackstone
fill 70 187 546 71 187 552 minecraft:polished_blackstone
fill 71 187 522 71 187 535 minecraft:polished_blackstone
fill 73 187 543 86 187 543 minecraft:polished_blackstone
fill 74 187 537 86 187 538 minecraft:polished_blackstone
fill 48 188 511 49 188 551 minecraft:blackstone
fill 50 188 511 64 188 536 minecraft:blackstone
fill 50 188 537 69 188 537 minecraft:gold_block
fill 50 188 538 60 188 542 minecraft:polished_blackstone
fill 50 188 543 68 188 543 minecraft:gold_block
fill 50 188 544 64 188 551 minecraft:blackstone
fill 61 188 538 61 188 542 minecraft:crying_obsidian
fill 62 188 538 70 188 538 minecraft:crying_obsidian
fill 62 188 539 64 188 541 minecraft:blackstone
fill 62 188 542 73 188 542 minecraft:crying_obsidian
fill 65 188 511 88 188 521 minecraft:blackstone
fill 65 188 522 65 188 536 minecraft:gold_block
fill 65 188 539 66 188 541 minecraft:crying_obsidian
fill 65 188 544 65 188 552 minecraft:gold_block
fill 66 188 522 69 188 536 minecraft:polished_blackstone
fill 66 188 544 68 188 552 minecraft:polished_blackstone
fill 69 188 543 69 188 546 minecraft:crying_obsidian
fill 69 188 547 70 188 552 minecraft:polished_blackstone
fill 70 188 522 70 188 534 minecraft:polished_blackstone
fill 70 188 535 70 188 537 minecraft:crying_obsidian
fill 70 188 539 70 188 541 minecraft:crying_obsidian
fill 70 188 543 72 188 545 minecraft:blackstone
fill 70 188 546 73 188 546 minecraft:crying_obsidian
fill 71 188 522 71 188 534 minecraft:gold_block
fill 71 188 535 74 188 535 minecraft:crying_obsidian
fill 71 188 536 73 188 538 minecraft:blackstone
fill 71 188 539 74 188 539 minecraft:crying_obsidian
fill 71 188 540 71 188 541 minecraft:gold_block
fill 71 188 547 71 188 552 minecraft:gold_block
fill 72 188 522 88 188 534 minecraft:blackstone
fill 72 188 540 86 188 541 minecraft:polished_blackstone
fill 72 188 547 88 188 551 minecraft:blackstone
fill 73 188 543 73 188 545 minecraft:crying_obsidian
fill 74 188 536 74 188 538 minecraft:crying_obsidian
fill 74 188 542 86 188 542 minecraft:polished_blackstone
fill 74 188 543 86 188 543 minecraft:gold_block
fill 74 188 544 88 188 546 minecraft:blackstone
fill 75 188 535 88 188 536 minecraft:blackstone
fill 75 188 537 86 188 537 minecraft:gold_block
fill 75 188 538 86 188 539 minecraft:polished_blackstone
fill 87 188 537 88 188 543 minecraft:blackstone
fill 65 189 552 71 205 552 minecraft:polished_blackstone_bricks
fill 47 192 517 47 192 518 minecraft:crying_obsidian
fill 47 192 529 47 192 530 minecraft:crying_obsidian
fill 47 192 541 47 192 542 minecraft:crying_obsidian
fill 48 192 511 48 192 523 minecraft:polished_blackstone_bricks
fill 48 192 533 48 232 535 minecraft:polished_blackstone_bricks
fill 48 192 545 48 232 547 minecraft:polished_blackstone_bricks
fill 48 192 552 49 192 552 minecraft:crying_obsidian
fill 49 192 511 53 192 520 minecraft:polished_blackstone_bricks
fill 54 192 551 56 232 551 minecraft:polished_blackstone_bricks
fill 55 192 510 56 192 510 minecraft:crying_obsidian
fill 57 192 537 57 195 543 minecraft:iron_block
fill 58 192 535 58 195 536 minecraft:iron_block
fill 58 192 544 58 195 545 minecraft:iron_block
fill 59 192 533 59 195 534 minecraft:iron_block
fill 59 192 546 59 195 547 minecraft:iron_block
fill 60 192 511 62 232 511 minecraft:polished_blackstone_bricks
fill 60 192 532 60 192 533 minecraft:iron_block
fill 60 192 541 65 192 546 minecraft:polished_blackstone_bricks
fill 60 192 547 60 192 548 minecraft:iron_block
fill 60 192 549 60 192 551 minecraft:polished_blackstone_bricks
fill 60 192 552 61 192 552 minecraft:crying_obsidian
fill 61 192 531 61 195 532 minecraft:iron_block
fill 61 192 547 68 192 547 minecraft:polished_blackstone_bricks
fill 61 192 548 61 195 549 minecraft:iron_block
fill 61 192 550 62 192 551 minecraft:polished_blackstone_bricks
fill 62 192 531 62 195 531 minecraft:iron_block
fill 62 192 548 68 192 548 minecraft:polished_blackstone_bricks
fill 62 192 549 62 195 549 minecraft:iron_block
fill 63 192 530 64 195 530 minecraft:iron_block
fill 63 192 549 68 192 549 minecraft:polished_blackstone_bricks
fill 63 192 550 64 195 550 minecraft:iron_block
fill 63 192 551 64 192 551 minecraft:polished_blackstone_bricks
fill 65 192 529 71 195 529 minecraft:iron_block
fill 65 192 550 68 192 550 minecraft:polished_blackstone_bricks
fill 65 192 551 71 195 551 minecraft:iron_block
fill 66 192 542 66 192 546 minecraft:polished_blackstone_bricks
fill 67 192 510 68 192 510 minecraft:crying_obsidian
fill 67 192 543 68 192 546 minecraft:polished_blackstone_bricks
fill 72 192 511 74 232 511 minecraft:polished_blackstone_bricks
fill 72 192 530 73 195 530 minecraft:iron_block
fill 72 192 550 73 195 550 minecraft:iron_block
fill 72 192 552 73 192 552 minecraft:crying_obsidian
fill 74 192 531 75 195 531 minecraft:iron_block
fill 74 192 549 75 195 549 minecraft:iron_block
fill 75 192 532 76 192 532 minecraft:iron_block
fill 75 192 548 76 192 548 minecraft:iron_block
fill 76 192 533 77 195 533 minecraft:iron_block
fill 76 192 547 77 195 547 minecraft:iron_block
fill 77 192 534 77 195 534 minecraft:iron_block
fill 77 192 546 77 195 546 minecraft:iron_block
fill 78 192 535 78 195 536 minecraft:iron_block
fill 78 192 544 78 195 545 minecraft:iron_block
fill 78 192 551 80 232 551 minecraft:polished_blackstone_bricks
fill 79 192 510 80 192 510 minecraft:crying_obsidian
fill 79 192 537 79 195 543 minecraft:iron_block
fill 82 192 515 82 192 517 minecraft:blackstone
fill 83 192 514 85 192 514 minecraft:blackstone
fill 83 192 515 85 232 517 minecraft:polished_blackstone_bricks
fill 83 192 518 85 192 518 minecraft:blackstone
fill 83 192 536 88 192 544 minecraft:polished_blackstone_bricks
fill 84 192 511 86 232 511 minecraft:polished_blackstone_bricks
fill 84 192 552 85 192 552 minecraft:crying_obsidian
fill 86 192 515 86 192 517 minecraft:blackstone
fill 88 192 519 88 232 521 minecraft:polished_blackstone_bricks
fill 88 192 531 88 232 533 minecraft:polished_blackstone_bricks
fill 88 192 545 88 232 545 minecraft:polished_blackstone_bricks
fill 89 192 512 89 192 513 minecraft:crying_obsidian
fill 89 192 524 89 192 525 minecraft:crying_obsidian
fill 89 192 536 89 192 537 minecraft:crying_obsidian
fill 89 192 548 89 192 549 minecraft:crying_obsidian
fill 47 193 517 47 205 518 minecraft:polished_blackstone_bricks
fill 47 193 529 47 205 530 minecraft:polished_blackstone_bricks
fill 47 193 541 47 205 542 minecraft:polished_blackstone_bricks
setblock 48 193 511 minecraft:crying_obsidian
fill 48 193 512 48 207 512 minecraft:polished_blackstone_bricks
setblock 48 193 513 minecraft:crying_obsidian
fill 48 193 514 48 204 514 minecraft:polished_blackstone_bricks
setblock 48 193 515 minecraft:crying_obsidian
fill 48 193 516 48 204 516 minecraft:polished_blackstone_bricks
setblock 48 193 517 minecraft:crying_obsidian
fill 48 193 518 48 204 518 minecraft:polished_blackstone_bricks
setblock 48 193 519 minecraft:crying_obsidian
fill 48 193 520 48 207 523 minecraft:polished_blackstone_bricks
fill 48 193 552 49 205 552 minecraft:polished_blackstone_bricks
setblock 49 193 510 minecraft:crying_obsidian
fill 49 193 511 49 232 511 minecraft:polished_blackstone_bricks
setblock 49 193 512 minecraft:crying_obsidian
fill 49 193 513 49 207 513 minecraft:polished_blackstone_bricks
setblock 49 193 514 minecraft:crying_obsidian
fill 49 193 515 49 207 515 minecraft:polished_blackstone_bricks
setblock 49 193 516 minecraft:crying_obsidian
fill 49 193 517 49 207 517 minecraft:polished_blackstone_bricks
setblock 49 193 518 minecraft:crying_obsidian
fill 49 193 519 49 207 519 minecraft:polished_blackstone_bricks
setblock 49 193 520 minecraft:crying_obsidian
setblock 50 193 511 minecraft:crying_obsidian
fill 50 193 512 50 207 512 minecraft:polished_blackstone_bricks
setblock 50 193 513 minecraft:crying_obsidian
fill 50 193 514 50 207 514 minecraft:polished_blackstone_bricks
setblock 50 193 515 minecraft:crying_obsidian
fill 50 193 516 50 207 516 minecraft:polished_blackstone_bricks
setblock 50 193 517 minecraft:crying_obsidian
fill 50 193 518 50 207 518 minecraft:polished_blackstone_bricks
setblock 50 193 519 minecraft:crying_obsidian
fill 50 193 520 50 207 520 minecraft:polished_blackstone_bricks
setblock 51 193 510 minecraft:crying_obsidian
fill 51 193 511 51 207 511 minecraft:polished_blackstone_bricks
setblock 51 193 512 minecraft:crying_obsidian
fill 51 193 513 51 207 513 minecraft:polished_blackstone_bricks
setblock 51 193 514 minecraft:crying_obsidian
fill 51 193 515 51 207 515 minecraft:polished_blackstone_bricks
setblock 51 193 516 minecraft:crying_obsidian
fill 51 193 517 51 207 517 minecraft:polished_blackstone_bricks
setblock 51 193 518 minecraft:crying_obsidian
fill 51 193 519 51 207 519 minecraft:polished_blackstone_bricks
setblock 51 193 520 minecraft:crying_obsidian
fill 52 193 510 52 218 510 minecraft:polished_blackstone_bricks
setblock 52 193 511 minecraft:crying_obsidian
fill 52 193 512 52 207 512 minecraft:polished_blackstone_bricks
setblock 52 193 513 minecraft:crying_obsidian
fill 52 193 514 52 207 514 minecraft:polished_blackstone_bricks
setblock 52 193 515 minecraft:crying_obsidian
fill 52 193 516 52 207 516 minecraft:polished_blackstone_bricks
setblock 52 193 517 minecraft:crying_obsidian
fill 52 193 518 52 207 518 minecraft:polished_blackstone_bricks
setblock 52 193 519 minecraft:crying_obsidian
fill 52 193 520 52 207 520 minecraft:polished_blackstone_bricks
setblock 53 193 510 minecraft:crying_obsidian
fill 53 193 511 53 204 511 minecraft:polished_blackstone_bricks
setblock 53 193 512 minecraft:crying_obsidian
fill 53 193 513 53 207 513 minecraft:polished_blackstone_bricks
setblock 53 193 514 minecraft:crying_obsidian
fill 53 193 515 53 207 515 minecraft:polished_blackstone_bricks
setblock 53 193 516 minecraft:crying_obsidian
fill 53 193 517 53 207 517 minecraft:polished_blackstone_bricks
setblock 53 193 518 minecraft:crying_obsidian
fill 53 193 519 53 207 519 minecraft:polished_blackstone_bricks
setblock 53 193 520 minecraft:crying_obsidian
fill 55 193 510 56 205 510 minecraft:polished_blackstone_bricks
fill 56 193 537 56 193 543 minecraft:iron_block
fill 57 193 535 57 194 536 minecraft:iron_block
fill 57 193 544 57 194 545 minecraft:iron_block
fill 58 193 533 58 194 534 minecraft:iron_block
fill 58 193 537 58 194 543 minecraft:iron_block
fill 58 193 546 58 194 547 minecraft:iron_block
fill 59 193 532 59 194 532 minecraft:iron_block
fill 59 193 535 59 194 537 minecraft:iron_block
fill 59 193 543 59 194 545 minecraft:iron_block
fill 59 193 548 59 194 548 minecraft:iron_block
fill 60 193 531 60 194 531 minecraft:iron_block
fill 60 193 532 60 194 532 minecraft:light_gray_concrete
fill 60 193 533 60 194 534 minecraft:iron_block
setblock 60 193 541 minecraft:crying_obsidian
fill 60 193 542 60 203 542 minecraft:polished_blackstone_bricks
setblock 60 193 543 minecraft:crying_obsidian
fill 60 193 544 60 203 544 minecraft:polished_blackstone_bricks
setblock 60 193 545 minecraft:crying_obsidian
fill 60 193 546 60 194 547 minecraft:iron_block
fill 60 193 548 60 194 548 minecraft:light_gray_concrete
fill 60 193 549 60 194 549 minecraft:iron_block
fill 60 193 550 60 203 550 minecraft:polished_blackstone_bricks
setblock 60 193 551 minecraft:crying_obsidian
fill 60 193 552 61 205 552 minecraft:polished_blackstone_bricks
fill 61 193 530 62 194 530 minecraft:iron_block
fill 61 193 533 61 194 533 minecraft:light_gray_concrete
fill 61 193 541 61 203 541 minecraft:polished_blackstone_bricks
setblock 61 193 542 minecraft:crying_obsidian
fill 61 193 543 61 203 543 minecraft:polished_blackstone_bricks
setblock 61 193 544 minecraft:crying_obsidian
fill 61 193 545 61 203 545 minecraft:polished_blackstone_bricks
setblock 61 193 546 minecraft:crying_obsidian
fill 61 193 547 61 194 547 minecraft:light_gray_concrete
fill 61 193 550 62 194 550 minecraft:iron_block
fill 61 193 551 61 203 551 minecraft:polished_blackstone_bricks
fill 62 193 532 62 194 532 minecraft:iron_block
fill 62 193 534 62 194 534 minecraft:light_gray_concrete
setblock 62 193 541 minecraft:crying_obsidian
fill 62 193 542 62 203 542 minecraft:polished_blackstone_bricks
setblock 62 193 543 minecraft:crying_obsidian
fill 62 193 544 62 203 544 minecraft:polished_blackstone_bricks
setblock 62 193 545 minecraft:crying_obsidian
fill 62 193 546 62 194 546 minecraft:light_gray_concrete
setblock 62 193 547 minecraft:crying_obsidian
fill 62 193 548 62 194 548 minecraft:iron_block
setblock 62 193 551 minecraft:crying_obsidian
fill 63 193 529 64 194 529 minecraft:iron_block
fill 63 193 531 65 194 531 minecraft:iron_block
fill 63 193 535 63 194 535 minecraft:light_gray_concrete
fill 63 193 541 63 203 541 minecraft:polished_blackstone_bricks
setblock 63 193 542 minecraft:crying_obsidian
fill 63 193 543 63 203 543 minecraft:polished_blackstone_bricks
setblock 63 193 544 minecraft:crying_obsidian
fill 63 193 545 63 194 545 minecraft:light_gray_concrete
setblock 63 193 546 minecraft:crying_obsidian
fill 63 193 547 63 203 547 minecraft:polished_blackstone_bricks
setblock 63 193 548 minecraft:crying_obsidian
fill 63 193 549 65 194 549 minecraft:iron_block
fill 63 193 551 64 194 551 minecraft:iron_block
fill 64 193 536 64 194 536 minecraft:light_gray_concrete
fill 64 193 539 65 194 541 minecraft:white_concrete
fill 64 193 542 64 203 542 minecraft:polished_blackstone_bricks
setblock 64 193 543 minecraft:crying_obsidian
fill 64 193 544 64 194 544 minecraft:light_gray_concrete
setblock 64 193 545 minecraft:crying_obsidian
fill 64 193 546 64 203 546 minecraft:polished_blackstone_bricks
setblock 64 193 547 minecraft:crying_obsidian
fill 64 193 548 64 203 548 minecraft:polished_blackstone_bricks
fill 65 193 528 71 194 528 minecraft:iron_block
fill 65 193 530 71 194 530 minecraft:iron_block
fill 65 193 537 65 194 537 minecraft:light_gray_concrete
fill 65 193 538 65 194 538 minecraft:white_concrete
fill 65 193 542 65 194 542 minecraft:white_concrete
fill 65 193 543 65 194 543 minecraft:light_gray_concrete
setblock 65 193 544 minecraft:crying_obsidian
fill 65 193 545 65 203 545 minecraft:polished_blackstone_bricks
setblock 65 193 546 minecraft:crying_obsidian
fill 65 193 547 65 203 547 minecraft:polished_blackstone_bricks
setblock 65 193 548 minecraft:crying_obsidian
fill 65 193 550 71 194 550 minecraft:iron_block
fill 66 193 537 70 194 537 minecraft:white_concrete
fill 66 193 542 66 203 542 minecraft:polished_blackstone_bricks
fill 66 193 543 70 194 543 minecraft:white_concrete
fill 66 193 544 66 203 544 minecraft:polished_blackstone_bricks
setblock 66 193 545 minecraft:crying_obsidian
fill 66 193 546 66 203 546 minecraft:polished_blackstone_bricks
setblock 66 193 547 minecraft:crying_obsidian
fill 66 193 548 66 203 548 minecraft:polished_blackstone_bricks
setblock 66 193 549 minecraft:crying_obsidian
fill 67 193 510 68 205 510 minecraft:polished_blackstone_bricks
fill 67 193 536 69 194 536 minecraft:white_concrete
fill 67 193 544 69 194 544 minecraft:white_concrete
fill 67 193 545 67 203 545 minecraft:polished_blackstone_bricks
setblock 67 193 546 minecraft:crying_obsidian
fill 67 193 547 67 203 547 minecraft:polished_blackstone_bricks
setblock 67 193 548 minecraft:crying_obsidian
fill 67 193 549 67 203 549 minecraft:polished_blackstone_bricks
setblock 68 193 545 minecraft:crying_obsidian
fill 68 193 546 68 203 546 minecraft:polished_blackstone_bricks
setblock 68 193 547 minecraft:crying_obsidian
fill 68 193 548 68 203 548 minecraft:polished_blackstone_bricks
setblock 68 193 549 minecraft:crying_obsidian
fill 71 193 531 73 194 531 minecraft:iron_block
fill 71 193 537 71 194 537 minecraft:light_gray_concrete
fill 71 193 538 71 194 542 minecraft:white_concrete
fill 71 193 543 71 194 543 minecraft:light_gray_concrete
fill 71 193 549 73 194 549 minecraft:iron_block
fill 72 193 529 73 194 529 minecraft:iron_block
fill 72 193 536 72 194 536 minecraft:light_gray_concrete
fill 72 193 539 72 194 541 minecraft:white_concrete
fill 72 193 544 72 194 544 minecraft:light_gray_concrete
fill 72 193 551 73 194 551 minecraft:iron_block
fill 72 193 552 73 205 552 minecraft:polished_blackstone_bricks
fill 73 193 535 73 194 535 minecraft:light_gray_concrete
fill 73 193 545 73 194 545 minecraft:light_gray_concrete
fill 74 193 530 75 194 530 minecraft:iron_block
fill 74 193 532 75 194 532 minecraft:iron_block
fill 74 193 534 74 194 534 minecraft:light_gray_concrete
fill 74 193 546 74 194 546 minecraft:light_gray_concrete
fill 74 193 548 75 194 548 minecraft:iron_block
fill 74 193 550 75 194 550 minecraft:iron_block
fill 75 193 533 75 194 533 minecraft:light_gray_concrete
fill 75 193 547 75 194 547 minecraft:light_gray_concrete
fill 76 193 531 76 194 531 minecraft:iron_block
fill 76 193 532 76 194 532 minecraft:light_gray_concrete
fill 76 193 534 76 194 534 minecraft:iron_block
fill 76 193 546 76 194 546 minecraft:iron_block
fill 76 193 548 76 194 548 minecraft:light_gray_concrete
fill 76 193 549 76 194 549 minecraft:iron_block
fill 77 193 532 77 194 532 minecraft:iron_block
fill 77 193 535 77 194 537 minecraft:iron_block
fill 77 193 543 77 194 545 minecraft:iron_block
fill 77 193 548 77 194 548 minecraft:iron_block
fill 78 193 533 78 194 534 minecraft:iron_block
fill 78 193 537 78 194 543 minecraft:iron_block
fill 78 193 546 78 194 547 minecraft:iron_block
fill 79 193 510 80 205 510 minecraft:polished_blackstone_bricks
fill 79 193 535 79 194 536 minecraft:iron_block
fill 79 193 544 79 194 545 minecraft:iron_block
fill 80 193 537 80 193 543 minecraft:iron_block
setblock 83 193 536 minecraft:crying_obsidian
setblock 83 193 537 minecraft:polished_blackstone_bricks
setblock 83 193 538 minecraft:crying_obsidian
setblock 83 193 539 minecraft:polished_blackstone_bricks
setblock 83 193 540 minecraft:crying_obsidian
setblock 83 193 541 minecraft:polished_blackstone_bricks
setblock 83 193 542 minecraft:crying_obsidian
setblock 83 193 543 minecraft:polished_blackstone_bricks
setblock 83 193 544 minecraft:crying_obsidian
fill 84 193 536 84 213 536 minecraft:polished_blackstone_bricks
setblock 84 193 537 minecraft:crying_obsidian
setblock 84 193 538 minecraft:polished_blackstone_bricks
setblock 84 193 539 minecraft:crying_obsidian
setblock 84 193 540 minecraft:polished_blackstone_bricks
setblock 84 193 541 minecraft:crying_obsidian
setblock 84 193 542 minecraft:polished_blackstone_bricks
setblock 84 193 543 minecraft:crying_obsidian
fill 84 193 544 84 213 544 minecraft:polished_blackstone_bricks
fill 84 193 552 85 205 552 minecraft:polished_blackstone_bricks
setblock 85 193 536 minecraft:crying_obsidian
fill 85 193 537 85 213 537 minecraft:polished_blackstone_bricks
setblock 85 193 538 minecraft:crying_obsidian
fill 85 193 539 85 213 539 minecraft:polished_blackstone_bricks
setblock 85 193 540 minecraft:crying_obsidian
fill 85 193 541 85 213 541 minecraft:polished_blackstone_bricks
setblock 85 193 542 minecraft:crying_obsidian
fill 85 193 543 85 213 543 minecraft:polished_blackstone_bricks
setblock 85 193 544 minecraft:crying_obsidian
fill 86 193 536 86 213 536 minecraft:polished_blackstone_bricks
setblock 86 193 537 minecraft:crying_obsidian
fill 86 193 538 86 213 538 minecraft:polished_blackstone_bricks
setblock 86 193 539 minecraft:crying_obsidian
fill 86 193 540 86 213 540 minecraft:polished_blackstone_bricks
setblock 86 193 541 minecraft:crying_obsidian
fill 86 193 542 86 213 542 minecraft:polished_blackstone_bricks
setblock 86 193 543 minecraft:crying_obsidian
fill 86 193 544 86 213 544 minecraft:polished_blackstone_bricks
setblock 87 193 536 minecraft:crying_obsidian
fill 87 193 537 87 213 537 minecraft:polished_blackstone_bricks
setblock 87 193 538 minecraft:crying_obsidian
fill 87 193 539 87 213 539 minecraft:polished_blackstone_bricks
setblock 87 193 540 minecraft:crying_obsidian
fill 87 193 541 87 213 541 minecraft:polished_blackstone_bricks
setblock 87 193 542 minecraft:crying_obsidian
fill 87 193 543 87 213 543 minecraft:polished_blackstone_bricks
setblock 87 193 544 minecraft:crying_obsidian
fill 88 193 536 89 204 536 minecraft:polished_blackstone_bricks
setblock 88 193 537 minecraft:crying_obsidian
fill 88 193 538 88 204 538 minecraft:polished_blackstone_bricks
setblock 88 193 539 minecraft:crying_obsidian
fill 88 193 540 88 204 540 minecraft:polished_blackstone_bricks
setblock 88 193 541 minecraft:crying_obsidian
fill 88 193 542 88 213 542 minecraft:polished_blackstone_bricks
setblock 88 193 543 minecraft:crying_obsidian
fill 88 193 544 88 232 544 minecraft:polished_blackstone_bricks
fill 89 193 512 89 205 513 minecraft:polished_blackstone_bricks
fill 89 193 524 89 205 525 minecraft:polished_blackstone_bricks
fill 89 193 537 89 205 537 minecraft:polished_blackstone_bricks
fill 89 193 548 89 205 549 minecraft:polished_blackstone_bricks
fill 48 194 511 48 195 511 minecraft:polished_blackstone_bricks
fill 48 194 513 48 195 513 minecraft:polished_blackstone_bricks
fill 48 194 515 48 195 515 minecraft:polished_blackstone_bricks
fill 48 194 517 48 195 517 minecraft:polished_blackstone_bricks
fill 48 194 519 48 195 519 minecraft:polished_blackstone_bricks
fill 49 194 510 49 195 510 minecraft:polished_blackstone_bricks
fill 49 194 512 49 195 512 minecraft:polished_blackstone_bricks
fill 49 194 514 49 195 514 minecraft:polished_blackstone_bricks
fill 49 194 516 49 195 516 minecraft:polished_blackstone_bricks
fill 49 194 518 49 195 518 minecraft:polished_blackstone_bricks
fill 49 194 520 49 195 520 minecraft:polished_blackstone_bricks
fill 50 194 511 50 195 511 minecraft:polished_blackstone_bricks
fill 50 194 513 50 195 513 minecraft:polished_blackstone_bricks
fill 50 194 515 50 195 515 minecraft:polished_blackstone_bricks
fill 50 194 517 50 195 517 minecraft:polished_blackstone_bricks
fill 50 194 519 50 195 519 minecraft:polished_blackstone_bricks
setblock 50 194 521 minecraft:light[level=11]
setblock 50 194 529 minecraft:light[level=11]
setblock 50 194 537 minecraft:light[level=11]
setblock 50 194 545 minecraft:light[level=11]
fill 51 194 510 51 195 510 minecraft:polished_blackstone_bricks
fill 51 194 512 51 195 512 minecraft:polished_blackstone_bricks
fill 51 194 514 51 195 514 minecraft:polished_blackstone_bricks
fill 51 194 516 51 195 516 minecraft:polished_blackstone_bricks
fill 51 194 518 51 195 518 minecraft:polished_blackstone_bricks
fill 51 194 520 51 195 520 minecraft:polished_blackstone_bricks
fill 52 194 511 52 195 511 minecraft:polished_blackstone_bricks
fill 52 194 513 52 195 513 minecraft:polished_blackstone_bricks
fill 52 194 515 52 195 515 minecraft:polished_blackstone_bricks
fill 52 194 517 52 195 517 minecraft:polished_blackstone_bricks
fill 52 194 519 52 195 519 minecraft:polished_blackstone_bricks
fill 52 194 537 56 194 543 minecraft:blue_stained_glass
fill 53 194 510 53 195 510 minecraft:polished_blackstone_bricks
fill 53 194 512 53 195 512 minecraft:polished_blackstone_bricks
fill 53 194 514 53 195 514 minecraft:polished_blackstone_bricks
fill 53 194 516 53 195 516 minecraft:polished_blackstone_bricks
fill 53 194 518 53 195 518 minecraft:polished_blackstone_bricks
fill 53 194 520 53 195 520 minecraft:polished_blackstone_bricks
setblock 58 194 513 minecraft:light[level=11]
setblock 58 194 521 minecraft:light[level=11]
setblock 58 194 529 minecraft:light[level=11]
fill 60 194 541 60 195 541 minecraft:polished_blackstone_bricks
fill 60 194 543 60 195 543 minecraft:polished_blackstone_bricks
fill 60 194 545 60 195 545 minecraft:polished_blackstone_bricks
fill 60 194 551 60 195 551 minecraft:polished_blackstone_bricks
fill 61 194 542 61 195 542 minecraft:polished_blackstone_bricks
fill 61 194 544 61 195 544 minecraft:polished_blackstone_bricks
fill 61 194 546 61 195 546 minecraft:polished_blackstone_bricks
fill 62 194 541 62 195 541 minecraft:polished_blackstone_bricks
fill 62 194 543 62 195 543 minecraft:polished_blackstone_bricks
fill 62 194 545 62 195 545 minecraft:polished_blackstone_bricks
fill 62 194 547 62 195 547 minecraft:polished_blackstone_bricks
fill 62 194 551 62 195 551 minecraft:polished_blackstone_bricks
fill 63 194 542 63 195 542 minecraft:polished_blackstone_bricks
fill 63 194 544 63 195 544 minecraft:polished_blackstone_bricks
fill 63 194 546 63 195 546 minecraft:polished_blackstone_bricks
fill 63 194 548 63 195 548 minecraft:polished_blackstone_bricks
fill 64 194 543 64 195 543 minecraft:polished_blackstone_bricks
fill 64 194 545 64 195 545 minecraft:polished_blackstone_bricks
fill 64 194 547 64 195 547 minecraft:polished_blackstone_bricks
fill 65 194 544 65 195 544 minecraft:polished_blackstone_bricks
fill 65 194 546 65 195 546 minecraft:polished_blackstone_bricks
fill 65 194 548 65 195 548 minecraft:polished_blackstone_bricks
setblock 66 194 513 minecraft:light[level=11]
setblock 66 194 521 minecraft:light[level=11]
fill 66 194 545 66 195 545 minecraft:polished_blackstone_bricks
fill 66 194 547 66 195 547 minecraft:polished_blackstone_bricks
fill 66 194 549 66 195 549 minecraft:polished_blackstone_bricks
fill 67 194 546 67 195 546 minecraft:polished_blackstone_bricks
fill 67 194 548 67 195 548 minecraft:polished_blackstone_bricks
fill 68 194 545 68 195 545 minecraft:polished_blackstone_bricks
fill 68 194 547 68 195 547 minecraft:polished_blackstone_bricks
fill 68 194 549 68 195 549 minecraft:polished_blackstone_bricks
setblock 74 194 513 minecraft:light[level=11]
setblock 74 194 521 minecraft:light[level=11]
setblock 74 194 529 minecraft:light[level=11]
setblock 74 194 537 minecraft:light[level=11]
setblock 74 194 545 minecraft:light[level=11]
fill 80 194 537 84 194 543 minecraft:blue_stained_glass
setblock 82 194 513 minecraft:light[level=11]
setblock 82 194 521 minecraft:light[level=11]
setblock 82 194 529 minecraft:light[level=11]
setblock 82 194 545 minecraft:light[level=11]
fill 83 194 536 83 195 536 minecraft:polished_blackstone_bricks
fill 83 194 544 83 195 544 minecraft:polished_blackstone_bricks
fill 85 194 536 85 195 536 minecraft:polished_blackstone_bricks
fill 85 194 538 85 195 538 minecraft:polished_blackstone_bricks
fill 85 194 540 85 195 540 minecraft:polished_blackstone_bricks
fill 85 194 542 85 195 542 minecraft:polished_blackstone_bricks
fill 85 194 544 85 195 544 minecraft:polished_blackstone_bricks
fill 86 194 537 86 195 537 minecraft:polished_blackstone_bricks
fill 86 194 539 86 195 539 minecraft:polished_blackstone_bricks
fill 86 194 541 86 195 541 minecraft:polished_blackstone_bricks
fill 86 194 543 86 195 543 minecraft:polished_blackstone_bricks
fill 87 194 536 87 195 536 minecraft:polished_blackstone_bricks
fill 87 194 538 87 195 538 minecraft:polished_blackstone_bricks
fill 87 194 540 87 195 540 minecraft:polished_blackstone_bricks
fill 87 194 542 87 195 542 minecraft:polished_blackstone_bricks
fill 87 194 544 87 195 544 minecraft:polished_blackstone_bricks
fill 88 194 537 88 195 537 minecraft:polished_blackstone_bricks
fill 88 194 539 88 195 539 minecraft:polished_blackstone_bricks
fill 88 194 541 88 195 541 minecraft:polished_blackstone_bricks
fill 88 194 543 88 195 543 minecraft:polished_blackstone_bricks
fill 60 195 532 60 195 533 minecraft:iron_block
fill 60 195 546 60 203 546 minecraft:polished_blackstone_bricks
fill 60 195 547 60 195 548 minecraft:iron_block
setblock 60 195 549 minecraft:polished_blackstone_bricks
fill 61 195 547 61 203 547 minecraft:polished_blackstone_bricks
fill 61 195 550 62 195 550 minecraft:polished_blackstone_bricks
fill 62 195 546 62 203 546 minecraft:polished_blackstone_bricks
fill 62 195 548 62 203 548 minecraft:polished_blackstone_bricks
fill 63 195 545 63 203 545 minecraft:polished_blackstone_bricks
fill 63 195 549 65 195 549 minecraft:polished_blackstone_bricks
fill 63 195 551 64 195 551 minecraft:polished_blackstone_bricks
fill 64 195 541 65 195 541 minecraft:polished_blackstone_bricks
fill 64 195 544 64 203 544 minecraft:polished_blackstone_bricks
fill 65 195 542 65 195 543 minecraft:polished_blackstone_bricks
fill 65 195 550 68 195 550 minecraft:polished_blackstone_bricks
fill 66 195 543 68 195 543 minecraft:polished_blackstone_bricks
fill 67 195 544 68 195 544 minecraft:polished_blackstone_bricks
fill 75 195 532 76 195 532 minecraft:iron_block
fill 75 195 548 76 195 548 minecraft:iron_block
fill 83 195 537 84 195 543 minecraft:polished_blackstone_bricks
setblock 48 196 511 minecraft:crying_obsidian
setblock 48 196 513 minecraft:crying_obsidian
setblock 48 196 515 minecraft:crying_obsidian
setblock 48 196 517 minecraft:crying_obsidian
setblock 48 196 519 minecraft:crying_obsidian
setblock 49 196 510 minecraft:crying_obsidian
setblock 49 196 512 minecraft:crying_obsidian
setblock 49 196 514 minecraft:crying_obsidian
setblock 49 196 516 minecraft:crying_obsidian
setblock 49 196 518 minecraft:crying_obsidian
setblock 49 196 520 minecraft:crying_obsidian
setblock 50 196 511 minecraft:crying_obsidian
setblock 50 196 513 minecraft:crying_obsidian
setblock 50 196 515 minecraft:crying_obsidian
setblock 50 196 517 minecraft:crying_obsidian
setblock 50 196 519 minecraft:crying_obsidian
setblock 51 196 510 minecraft:crying_obsidian
setblock 51 196 512 minecraft:crying_obsidian
setblock 51 196 514 minecraft:crying_obsidian
setblock 51 196 516 minecraft:crying_obsidian
setblock 51 196 518 minecraft:crying_obsidian
setblock 51 196 520 minecraft:crying_obsidian
setblock 52 196 511 minecraft:crying_obsidian
setblock 52 196 513 minecraft:crying_obsidian
setblock 52 196 515 minecraft:crying_obsidian
setblock 52 196 517 minecraft:crying_obsidian
setblock 52 196 519 minecraft:crying_obsidian
setblock 53 196 510 minecraft:crying_obsidian
setblock 53 196 512 minecraft:crying_obsidian
setblock 53 196 514 minecraft:crying_obsidian
setblock 53 196 516 minecraft:crying_obsidian
setblock 53 196 518 minecraft:crying_obsidian
setblock 53 196 520 minecraft:crying_obsidian
setblock 60 196 541 minecraft:crying_obsidian
setblock 60 196 543 minecraft:crying_obsidian
setblock 60 196 545 minecraft:crying_obsidian
setblock 60 196 547 minecraft:crying_obsidian
fill 60 196 548 60 203 548 minecraft:polished_blackstone_bricks
setblock 60 196 549 minecraft:crying_obsidian
setblock 60 196 551 minecraft:crying_obsidian
setblock 61 196 542 minecraft:crying_obsidian
setblock 61 196 544 minecraft:crying_obsidian
setblock 61 196 546 minecraft:crying_obsidian
setblock 61 196 548 minecraft:crying_obsidian
fill 61 196 549 61 203 549 minecraft:polished_blackstone_bricks
setblock 61 196 550 minecraft:crying_obsidian
setblock 62 196 541 minecraft:crying_obsidian
setblock 62 196 543 minecraft:crying_obsidian
setblock 62 196 545 minecraft:crying_obsidian
setblock 62 196 547 minecraft:crying_obsidian
setblock 62 196 549 minecraft:crying_obsidian
fill 62 196 550 62 203 550 minecraft:polished_blackstone_bricks
setblock 62 196 551 minecraft:crying_obsidian
setblock 63 196 542 minecraft:crying_obsidian
setblock 63 196 544 minecraft:crying_obsidian
setblock 63 196 546 minecraft:crying_obsidian
setblock 63 196 548 minecraft:crying_obsidian
fill 63 196 549 63 203 549 minecraft:polished_blackstone_bricks
setblock 63 196 550 minecraft:crying_obsidian
fill 63 196 551 63 203 551 minecraft:polished_blackstone_bricks
setblock 64 196 541 minecraft:crying_obsidian
setblock 64 196 543 minecraft:crying_obsidian
setblock 64 196 545 minecraft:crying_obsidian
setblock 64 196 547 minecraft:crying_obsidian
setblock 64 196 549 minecraft:crying_obsidian
fill 64 196 550 64 203 550 minecraft:polished_blackstone_bricks
setblock 64 196 551 minecraft:crying_obsidian
fill 65 196 541 65 203 541 minecraft:polished_blackstone_bricks
setblock 65 196 542 minecraft:crying_obsidian
fill 65 196 543 65 203 543 minecraft:polished_blackstone_bricks
setblock 65 196 544 minecraft:crying_obsidian
setblock 65 196 546 minecraft:crying_obsidian
setblock 65 196 548 minecraft:crying_obsidian
fill 65 196 549 65 203 549 minecraft:polished_blackstone_bricks
setblock 65 196 550 minecraft:crying_obsidian
fill 65 196 551 65 203 551 minecraft:polished_blackstone_bricks
setblock 66 196 543 minecraft:crying_obsidian
setblock 66 196 545 minecraft:crying_obsidian
setblock 66 196 547 minecraft:crying_obsidian
setblock 66 196 549 minecraft:crying_obsidian
fill 66 196 550 66 203 550 minecraft:polished_blackstone_bricks
setblock 66 196 551 minecraft:crying_obsidian
fill 67 196 543 67 203 543 minecraft:polished_blackstone_bricks
setblock 67 196 544 minecraft:crying_obsidian
setblock 67 196 546 minecraft:crying_obsidian
setblock 67 196 548 minecraft:crying_obsidian
setblock 67 196 550 minecraft:crying_obsidian
fill 67 196 551 67 232 551 minecraft:polished_blackstone_bricks
setblock 68 196 543 minecraft:crying_obsidian
fill 68 196 544 68 203 544 minecraft:polished_blackstone_bricks
setblock 68 196 545 minecraft:crying_obsidian
setblock 68 196 547 minecraft:crying_obsidian
setblock 68 196 549 minecraft:crying_obsidian
fill 68 196 550 68 205 550 minecraft:polished_blackstone_bricks
setblock 68 196 551 minecraft:crying_obsidian
fill 69 196 544 72 197 548 minecraft:blackstone
fill 70 196 549 70 196 550 minecraft:blackstone
setblock 83 196 536 minecraft:crying_obsidian
fill 83 196 537 83 213 537 minecraft:polished_blackstone_bricks
setblock 83 196 538 minecraft:crying_obsidian
fill 83 196 539 83 213 539 minecraft:polished_blackstone_bricks
setblock 83 196 540 minecraft:crying_obsidian
fill 83 196 541 83 213 541 minecraft:polished_blackstone_bricks
setblock 83 196 542 minecraft:crying_obsidian
fill 83 196 543 83 213 543 minecraft:polished_blackstone_bricks
setblock 83 196 544 minecraft:crying_obsidian
setblock 84 196 537 minecraft:crying_obsidian
fill 84 196 538 84 213 538 minecraft:polished_blackstone_bricks
setblock 84 196 539 minecraft:crying_obsidian
fill 84 196 540 84 213 540 minecraft:polished_blackstone_bricks
setblock 84 196 541 minecraft:crying_obsidian
fill 84 196 542 84 213 542 minecraft:polished_blackstone_bricks
setblock 84 196 543 minecraft:crying_obsidian
setblock 85 196 536 minecraft:crying_obsidian
setblock 85 196 538 minecraft:crying_obsidian
setblock 85 196 540 minecraft:crying_obsidian
setblock 85 196 542 minecraft:crying_obsidian
setblock 85 196 544 minecraft:crying_obsidian
setblock 86 196 537 minecraft:crying_obsidian
setblock 86 196 539 minecraft:crying_obsidian
setblock 86 196 541 minecraft:crying_obsidian
setblock 86 196 543 minecraft:crying_obsidian
setblock 87 196 536 minecraft:crying_obsidian
setblock 87 196 538 minecraft:crying_obsidian
setblock 87 196 540 minecraft:crying_obsidian
setblock 87 196 542 minecraft:crying_obsidian
setblock 87 196 544 minecraft:crying_obsidian
setblock 88 196 537 minecraft:crying_obsidian
setblock 88 196 539 minecraft:crying_obsidian
setblock 88 196 541 minecraft:crying_obsidian
setblock 88 196 543 minecraft:crying_obsidian
fill 48 197 511 48 198 511 minecraft:polished_blackstone_bricks
fill 48 197 513 48 198 513 minecraft:polished_blackstone_bricks
fill 48 197 515 48 198 515 minecraft:polished_blackstone_bricks
fill 48 197 517 48 198 517 minecraft:polished_blackstone_bricks
fill 48 197 519 48 198 519 minecraft:polished_blackstone_bricks
fill 49 197 510 49 198 510 minecraft:polished_blackstone_bricks
fill 49 197 512 49 198 512 minecraft:polished_blackstone_bricks
fill 49 197 514 49 198 514 minecraft:polished_blackstone_bricks
fill 49 197 516 49 198 516 minecraft:polished_blackstone_bricks
fill 49 197 518 49 198 518 minecraft:polished_blackstone_bricks
fill 49 197 520 49 198 520 minecraft:polished_blackstone_bricks
fill 50 197 511 50 198 511 minecraft:polished_blackstone_bricks
fill 50 197 513 50 198 513 minecraft:polished_blackstone_bricks
fill 50 197 515 50 198 515 minecraft:polished_blackstone_bricks
fill 50 197 517 50 198 517 minecraft:polished_blackstone_bricks
fill 50 197 519 50 198 519 minecraft:polished_blackstone_bricks
fill 51 197 510 51 198 510 minecraft:polished_blackstone_bricks
fill 51 197 512 51 198 512 minecraft:polished_blackstone_bricks
fill 51 197 514 51 198 514 minecraft:polished_blackstone_bricks
fill 51 197 516 51 198 516 minecraft:polished_blackstone_bricks
fill 51 197 518 51 198 518 minecraft:polished_blackstone_bricks
fill 51 197 520 51 198 520 minecraft:polished_blackstone_bricks
fill 52 197 511 52 198 511 minecraft:polished_blackstone_bricks
fill 52 197 513 52 198 513 minecraft:polished_blackstone_bricks
fill 52 197 515 52 198 515 minecraft:polished_blackstone_bricks
fill 52 197 517 52 198 517 minecraft:polished_blackstone_bricks
fill 52 197 519 52 198 519 minecraft:polished_blackstone_bricks
fill 53 197 510 53 198 510 minecraft:polished_blackstone_bricks
fill 53 197 512 53 198 512 minecraft:polished_blackstone_bricks
fill 53 197 514 53 198 514 minecraft:polished_blackstone_bricks
fill 53 197 516 53 198 516 minecraft:polished_blackstone_bricks
fill 53 197 518 53 198 518 minecraft:polished_blackstone_bricks
fill 53 197 520 53 198 520 minecraft:polished_blackstone_bricks
fill 60 197 541 60 198 541 minecraft:polished_blackstone_bricks
fill 60 197 543 60 198 543 minecraft:polished_blackstone_bricks
fill 60 197 545 60 198 545 minecraft:polished_blackstone_bricks
fill 60 197 547 60 198 547 minecraft:polished_blackstone_bricks
fill 60 197 549 60 198 549 minecraft:polished_blackstone_bricks
fill 60 197 551 60 198 551 minecraft:polished_blackstone_bricks
fill 61 197 542 61 198 542 minecraft:polished_blackstone_bricks
fill 61 197 544 61 198 544 minecraft:polished_blackstone_bricks
fill 61 197 546 61 198 546 minecraft:polished_blackstone_bricks
fill 61 197 548 61 198 548 minecraft:polished_blackstone_bricks
fill 61 197 550 61 198 550 minecraft:polished_blackstone_bricks
fill 62 197 541 62 198 541 minecraft:polished_blackstone_bricks
fill 62 197 543 62 198 543 minecraft:polished_blackstone_bricks
fill 62 197 545 62 198 545 minecraft:polished_blackstone_bricks
fill 62 197 547 62 198 547 minecraft:polished_blackstone_bricks
fill 62 197 549 62 198 549 minecraft:polished_blackstone_bricks
fill 62 197 551 62 198 551 minecraft:polished_blackstone_bricks
fill 63 197 542 63 198 542 minecraft:polished_blackstone_bricks
fill 63 197 544 63 198 544 minecraft:polished_blackstone_bricks
fill 63 197 546 63 198 546 minecraft:polished_blackstone_bricks
fill 63 197 548 63 198 548 minecraft:polished_blackstone_bricks
fill 63 197 550 63 198 550 minecraft:polished_blackstone_bricks
fill 64 197 541 64 198 541 minecraft:polished_blackstone_bricks
fill 64 197 543 64 198 543 minecraft:polished_blackstone_bricks
fill 64 197 545 64 198 545 minecraft:polished_blackstone_bricks
fill 64 197 547 64 198 547 minecraft:polished_blackstone_bricks
fill 64 197 549 64 198 549 minecraft:polished_blackstone_bricks
fill 64 197 551 64 198 551 minecraft:polished_blackstone_bricks
fill 65 197 542 65 198 542 minecraft:polished_blackstone_bricks
fill 65 197 544 65 198 544 minecraft:polished_blackstone_bricks
fill 65 197 546 65 198 546 minecraft:polished_blackstone_bricks
fill 65 197 548 65 198 548 minecraft:polished_blackstone_bricks
fill 65 197 550 65 198 550 minecraft:polished_blackstone_bricks
fill 66 197 543 66 198 543 minecraft:polished_blackstone_bricks
fill 66 197 545 66 198 545 minecraft:polished_blackstone_bricks
fill 66 197 547 66 198 547 minecraft:polished_blackstone_bricks
fill 66 197 549 66 198 549 minecraft:polished_blackstone_bricks
fill 66 197 551 66 198 551 minecraft:polished_blackstone_bricks
fill 67 197 544 67 198 544 minecraft:polished_blackstone_bricks
fill 67 197 546 67 198 546 minecraft:polished_blackstone_bricks
fill 67 197 548 67 198 548 minecraft:polished_blackstone_bricks
fill 67 197 550 67 198 550 minecraft:polished_blackstone_bricks
fill 68 197 543 68 198 543 minecraft:polished_blackstone_bricks
fill 68 197 545 68 198 545 minecraft:polished_blackstone_bricks
fill 68 197 547 68 198 547 minecraft:polished_blackstone_bricks
fill 68 197 549 68 198 549 minecraft:polished_blackstone_bricks
fill 68 197 551 68 198 551 minecraft:polished_blackstone_bricks
fill 83 197 536 83 198 536 minecraft:polished_blackstone_bricks
fill 83 197 538 83 198 538 minecraft:polished_blackstone_bricks
fill 83 197 540 83 198 540 minecraft:polished_blackstone_bricks
fill 83 197 542 83 198 542 minecraft:polished_blackstone_bricks
fill 83 197 544 83 198 544 minecraft:polished_blackstone_bricks
fill 84 197 537 84 198 537 minecraft:polished_blackstone_bricks
fill 84 197 539 84 198 539 minecraft:polished_blackstone_bricks
fill 84 197 541 84 198 541 minecraft:polished_blackstone_bricks
fill 84 197 543 84 198 543 minecraft:polished_blackstone_bricks
fill 85 197 536 85 198 536 minecraft:polished_blackstone_bricks
fill 85 197 538 85 198 538 minecraft:polished_blackstone_bricks
fill 85 197 540 85 198 540 minecraft:polished_blackstone_bricks
fill 85 197 542 85 198 542 minecraft:polished_blackstone_bricks
fill 85 197 544 85 198 544 minecraft:polished_blackstone_bricks
fill 86 197 537 86 198 537 minecraft:polished_blackstone_bricks
fill 86 197 539 86 198 539 minecraft:polished_blackstone_bricks
fill 86 197 541 86 198 541 minecraft:polished_blackstone_bricks
fill 86 197 543 86 198 543 minecraft:polished_blackstone_bricks
fill 87 197 536 87 198 536 minecraft:polished_blackstone_bricks
fill 87 197 538 87 198 538 minecraft:polished_blackstone_bricks
fill 87 197 540 87 198 540 minecraft:polished_blackstone_bricks
fill 87 197 542 87 198 542 minecraft:polished_blackstone_bricks
fill 87 197 544 87 198 544 minecraft:polished_blackstone_bricks
fill 88 197 537 88 198 537 minecraft:polished_blackstone_bricks
fill 88 197 539 88 198 539 minecraft:polished_blackstone_bricks
fill 88 197 541 88 198 541 minecraft:polished_blackstone_bricks
fill 88 197 543 88 198 543 minecraft:polished_blackstone_bricks
fill 69 198 546 71 207 546 minecraft:purple_stained_glass
fill 70 198 545 70 207 545 minecraft:purple_stained_glass
fill 70 198 547 70 207 547 minecraft:purple_stained_glass
setblock 48 199 511 minecraft:crying_obsidian
setblock 48 199 513 minecraft:crying_obsidian
setblock 48 199 515 minecraft:crying_obsidian
setblock 48 199 517 minecraft:crying_obsidian
setblock 48 199 519 minecraft:crying_obsidian
setblock 49 199 510 minecraft:crying_obsidian
setblock 49 199 512 minecraft:crying_obsidian
setblock 49 199 514 minecraft:crying_obsidian
setblock 49 199 516 minecraft:crying_obsidian
setblock 49 199 518 minecraft:crying_obsidian
setblock 49 199 520 minecraft:crying_obsidian
setblock 50 199 511 minecraft:crying_obsidian
setblock 50 199 513 minecraft:crying_obsidian
setblock 50 199 515 minecraft:crying_obsidian
setblock 50 199 517 minecraft:crying_obsidian
setblock 50 199 519 minecraft:crying_obsidian
setblock 51 199 510 minecraft:crying_obsidian
setblock 51 199 512 minecraft:crying_obsidian
setblock 51 199 514 minecraft:crying_obsidian
setblock 51 199 516 minecraft:crying_obsidian
setblock 51 199 518 minecraft:crying_obsidian
setblock 51 199 520 minecraft:crying_obsidian
setblock 52 199 511 minecraft:crying_obsidian
setblock 52 199 513 minecraft:crying_obsidian
setblock 52 199 515 minecraft:crying_obsidian
setblock 52 199 517 minecraft:crying_obsidian
setblock 52 199 519 minecraft:crying_obsidian
setblock 53 199 510 minecraft:crying_obsidian
setblock 53 199 512 minecraft:crying_obsidian
setblock 53 199 514 minecraft:crying_obsidian
setblock 53 199 516 minecraft:crying_obsidian
setblock 53 199 518 minecraft:crying_obsidian
setblock 53 199 520 minecraft:crying_obsidian
setblock 60 199 541 minecraft:crying_obsidian
setblock 60 199 543 minecraft:crying_obsidian
setblock 60 199 545 minecraft:crying_obsidian
setblock 60 199 547 minecraft:crying_obsidian
setblock 60 199 549 minecraft:crying_obsidian
setblock 60 199 551 minecraft:crying_obsidian
setblock 61 199 542 minecraft:crying_obsidian
setblock 61 199 544 minecraft:crying_obsidian
setblock 61 199 546 minecraft:crying_obsidian
setblock 61 199 548 minecraft:crying_obsidian
setblock 61 199 550 minecraft:crying_obsidian
setblock 62 199 541 minecraft:crying_obsidian
setblock 62 199 543 minecraft:crying_obsidian
setblock 62 199 545 minecraft:crying_obsidian
setblock 62 199 547 minecraft:crying_obsidian
setblock 62 199 549 minecraft:crying_obsidian
setblock 62 199 551 minecraft:crying_obsidian
setblock 63 199 542 minecraft:crying_obsidian
setblock 63 199 544 minecraft:crying_obsidian
setblock 63 199 546 minecraft:crying_obsidian
setblock 63 199 548 minecraft:crying_obsidian
setblock 63 199 550 minecraft:crying_obsidian
setblock 64 199 541 minecraft:crying_obsidian
setblock 64 199 543 minecraft:crying_obsidian
setblock 64 199 545 minecraft:crying_obsidian
setblock 64 199 547 minecraft:crying_obsidian
setblock 64 199 549 minecraft:crying_obsidian
setblock 64 199 551 minecraft:crying_obsidian
setblock 65 199 542 minecraft:crying_obsidian
setblock 65 199 544 minecraft:crying_obsidian
setblock 65 199 546 minecraft:crying_obsidian
setblock 65 199 548 minecraft:crying_obsidian
setblock 65 199 550 minecraft:crying_obsidian
setblock 66 199 543 minecraft:crying_obsidian
setblock 66 199 545 minecraft:crying_obsidian
setblock 66 199 547 minecraft:crying_obsidian
setblock 66 199 549 minecraft:crying_obsidian
setblock 66 199 551 minecraft:crying_obsidian
setblock 67 199 544 minecraft:crying_obsidian
setblock 67 199 546 minecraft:crying_obsidian
setblock 67 199 548 minecraft:crying_obsidian
setblock 67 199 550 minecraft:crying_obsidian
setblock 68 199 543 minecraft:crying_obsidian
setblock 68 199 545 minecraft:crying_obsidian
setblock 68 199 547 minecraft:crying_obsidian
setblock 68 199 549 minecraft:crying_obsidian
setblock 68 199 551 minecraft:crying_obsidian
setblock 83 199 536 minecraft:crying_obsidian
setblock 83 199 538 minecraft:crying_obsidian
setblock 83 199 540 minecraft:crying_obsidian
setblock 83 199 542 minecraft:crying_obsidian
setblock 83 199 544 minecraft:crying_obsidian
setblock 84 199 537 minecraft:crying_obsidian
setblock 84 199 539 minecraft:crying_obsidian
setblock 84 199 541 minecraft:crying_obsidian
setblock 84 199 543 minecraft:crying_obsidian
setblock 85 199 536 minecraft:crying_obsidian
setblock 85 199 538 minecraft:crying_obsidian
setblock 85 199 540 minecraft:crying_obsidian
setblock 85 199 542 minecraft:crying_obsidian
setblock 85 199 544 minecraft:crying_obsidian
setblock 86 199 537 minecraft:crying_obsidian
setblock 86 199 539 minecraft:crying_obsidian
setblock 86 199 541 minecraft:crying_obsidian
setblock 86 199 543 minecraft:crying_obsidian
setblock 87 199 536 minecraft:crying_obsidian
setblock 87 199 538 minecraft:crying_obsidian
setblock 87 199 540 minecraft:crying_obsidian
setblock 87 199 542 minecraft:crying_obsidian
setblock 87 199 544 minecraft:crying_obsidian
setblock 88 199 537 minecraft:crying_obsidian
setblock 88 199 539 minecraft:crying_obsidian
setblock 88 199 541 minecraft:crying_obsidian
setblock 88 199 543 minecraft:crying_obsidian
fill 48 200 511 48 201 511 minecraft:polished_blackstone_bricks
fill 48 200 513 48 201 513 minecraft:polished_blackstone_bricks
fill 48 200 515 48 201 515 minecraft:polished_blackstone_bricks
fill 48 200 517 48 201 517 minecraft:polished_blackstone_bricks
fill 48 200 519 48 201 519 minecraft:polished_blackstone_bricks
fill 49 200 510 49 201 510 minecraft:polished_blackstone_bricks
fill 49 200 512 49 201 512 minecraft:polished_blackstone_bricks
fill 49 200 514 49 201 514 minecraft:polished_blackstone_bricks
fill 49 200 516 49 201 516 minecraft:polished_blackstone_bricks
fill 49 200 518 49 201 518 minecraft:polished_blackstone_bricks
fill 49 200 520 49 201 522 minecraft:polished_blackstone_bricks
fill 49 200 532 49 205 534 minecraft:polished_blackstone_bricks
fill 49 200 544 49 205 546 minecraft:polished_blackstone_bricks
fill 50 200 511 50 201 511 minecraft:polished_blackstone_bricks
fill 50 200 513 50 201 513 minecraft:polished_blackstone_bricks
fill 50 200 515 50 201 515 minecraft:polished_blackstone_bricks
fill 50 200 517 50 201 517 minecraft:polished_blackstone_bricks
fill 50 200 519 50 201 519 minecraft:polished_blackstone_bricks
fill 51 200 510 51 201 510 minecraft:polished_blackstone_bricks
fill 51 200 512 51 201 512 minecraft:polished_blackstone_bricks
fill 51 200 514 51 201 514 minecraft:polished_blackstone_bricks
fill 51 200 516 51 201 516 minecraft:polished_blackstone_bricks
fill 51 200 518 51 201 518 minecraft:polished_blackstone_bricks
fill 51 200 520 51 201 520 minecraft:polished_blackstone_bricks
fill 52 200 511 52 201 511 minecraft:polished_blackstone_bricks
fill 52 200 513 52 201 513 minecraft:polished_blackstone_bricks
fill 52 200 515 52 201 515 minecraft:polished_blackstone_bricks
fill 52 200 517 52 201 517 minecraft:polished_blackstone_bricks
fill 52 200 519 52 201 519 minecraft:polished_blackstone_bricks
fill 53 200 510 53 201 510 minecraft:polished_blackstone_bricks
fill 53 200 512 53 201 512 minecraft:polished_blackstone_bricks
fill 53 200 514 53 201 514 minecraft:polished_blackstone_bricks
fill 53 200 516 53 201 516 minecraft:polished_blackstone_bricks
fill 53 200 518 53 201 518 minecraft:polished_blackstone_bricks
fill 53 200 520 53 201 520 minecraft:polished_blackstone_bricks
fill 55 200 550 57 205 550 minecraft:polished_blackstone_bricks
fill 59 200 512 61 205 512 minecraft:polished_blackstone_bricks
fill 60 200 541 60 201 541 minecraft:polished_blackstone_bricks
fill 60 200 543 60 201 543 minecraft:polished_blackstone_bricks
fill 60 200 545 60 201 545 minecraft:polished_blackstone_bricks
fill 60 200 547 60 201 547 minecraft:polished_blackstone_bricks
fill 60 200 549 60 201 549 minecraft:polished_blackstone_bricks
fill 60 200 551 60 201 551 minecraft:polished_blackstone_bricks
fill 61 200 542 61 201 542 minecraft:polished_blackstone_bricks
fill 61 200 544 61 201 544 minecraft:polished_blackstone_bricks
fill 61 200 546 61 201 546 minecraft:polished_blackstone_bricks
fill 61 200 548 61 201 548 minecraft:polished_blackstone_bricks
fill 61 200 550 61 201 550 minecraft:polished_blackstone_bricks
fill 62 200 541 62 201 541 minecraft:polished_blackstone_bricks
fill 62 200 543 62 201 543 minecraft:polished_blackstone_bricks
fill 62 200 545 62 201 545 minecraft:polished_blackstone_bricks
fill 62 200 547 62 201 547 minecraft:polished_blackstone_bricks
fill 62 200 549 62 201 549 minecraft:polished_blackstone_bricks
fill 62 200 551 62 201 551 minecraft:polished_blackstone_bricks
fill 63 200 542 63 201 542 minecraft:polished_blackstone_bricks
fill 63 200 544 63 201 544 minecraft:polished_blackstone_bricks
fill 63 200 546 63 201 546 minecraft:polished_blackstone_bricks
fill 63 200 548 63 201 548 minecraft:polished_blackstone_bricks
fill 63 200 550 63 201 550 minecraft:polished_blackstone_bricks
fill 64 200 541 64 201 541 minecraft:polished_blackstone_bricks
fill 64 200 543 64 201 543 minecraft:polished_blackstone_bricks
fill 64 200 545 64 201 545 minecraft:polished_blackstone_bricks
fill 64 200 547 64 201 547 minecraft:polished_blackstone_bricks
fill 64 200 549 64 201 549 minecraft:polished_blackstone_bricks
fill 64 200 551 64 201 551 minecraft:polished_blackstone_bricks
fill 65 200 542 65 201 542 minecraft:polished_blackstone_bricks
fill 65 200 544 65 201 544 minecraft:polished_blackstone_bricks
fill 65 200 546 65 201 546 minecraft:polished_blackstone_bricks
fill 65 200 548 65 201 548 minecraft:polished_blackstone_bricks
fill 65 200 550 65 201 550 minecraft:polished_blackstone_bricks
fill 66 200 543 66 201 543 minecraft:polished_blackstone_bricks
fill 66 200 545 66 201 545 minecraft:polished_blackstone_bricks
fill 66 200 547 66 201 547 minecraft:polished_blackstone_bricks
fill 66 200 549 66 201 549 minecraft:polished_blackstone_bricks
fill 66 200 551 66 201 551 minecraft:polished_blackstone_bricks
fill 67 200 544 67 201 544 minecraft:polished_blackstone_bricks
fill 67 200 546 67 201 546 minecraft:polished_blackstone_bricks
fill 67 200 548 67 201 548 minecraft:polished_blackstone_bricks
fill 67 200 550 67 201 550 minecraft:polished_blackstone_bricks
fill 68 200 543 68 201 543 minecraft:polished_blackstone_bricks
fill 68 200 545 68 201 545 minecraft:polished_blackstone_bricks
fill 68 200 547 68 201 547 minecraft:polished_blackstone_bricks
fill 68 200 549 68 201 549 minecraft:polished_blackstone_bricks
fill 68 200 551 68 201 551 minecraft:polished_blackstone_bricks
fill 69 200 550 69 205 550 minecraft:polished_blackstone_bricks
fill 71 200 512 73 205 512 minecraft:polished_blackstone_bricks
fill 79 200 550 81 205 550 minecraft:polished_blackstone_bricks
fill 82 200 515 82 200 517 minecraft:blackstone
fill 83 200 512 85 205 512 minecraft:polished_blackstone_bricks
fill 83 200 514 85 200 514 minecraft:blackstone
fill 83 200 518 85 200 518 minecraft:blackstone
fill 83 200 536 83 201 536 minecraft:polished_blackstone_bricks
fill 83 200 538 83 201 538 minecraft:polished_blackstone_bricks
fill 83 200 540 83 201 540 minecraft:polished_blackstone_bricks
fill 83 200 542 83 201 542 minecraft:polished_blackstone_bricks
fill 83 200 544 83 201 544 minecraft:polished_blackstone_bricks
fill 84 200 537 84 201 537 minecraft:polished_blackstone_bricks
fill 84 200 539 84 201 539 minecraft:polished_blackstone_bricks
fill 84 200 541 84 201 541 minecraft:polished_blackstone_bricks
fill 84 200 543 84 201 543 minecraft:polished_blackstone_bricks
fill 85 200 536 85 201 536 minecraft:polished_blackstone_bricks
fill 85 200 538 85 201 538 minecraft:polished_blackstone_bricks
fill 85 200 540 85 201 540 minecraft:polished_blackstone_bricks
fill 85 200 542 85 201 542 minecraft:polished_blackstone_bricks
fill 85 200 544 85 201 544 minecraft:polished_blackstone_bricks
fill 86 200 515 86 200 517 minecraft:blackstone
fill 86 200 537 86 201 537 minecraft:polished_blackstone_bricks
fill 86 200 539 86 201 539 minecraft:polished_blackstone_bricks
fill 86 200 541 86 201 541 minecraft:polished_blackstone_bricks
fill 86 200 543 86 201 543 minecraft:polished_blackstone_bricks
fill 87 200 520 87 205 522 minecraft:polished_blackstone_bricks
fill 87 200 532 87 205 534 minecraft:polished_blackstone_bricks
fill 87 200 536 87 201 536 minecraft:polished_blackstone_bricks
fill 87 200 538 87 201 538 minecraft:polished_blackstone_bricks
fill 87 200 540 87 201 540 minecraft:polished_blackstone_bricks
fill 87 200 542 87 201 542 minecraft:polished_blackstone_bricks
fill 87 200 544 87 201 546 minecraft:polished_blackstone_bricks
fill 88 200 537 88 201 537 minecraft:polished_blackstone_bricks
fill 88 200 539 88 201 539 minecraft:polished_blackstone_bricks
fill 88 200 541 88 201 541 minecraft:polished_blackstone_bricks
fill 88 200 543 88 201 543 minecraft:polished_blackstone_bricks
setblock 67 201 542 minecraft:polished_blackstone_bricks
setblock 48 202 511 minecraft:crying_obsidian
setblock 48 202 513 minecraft:crying_obsidian
setblock 48 202 515 minecraft:crying_obsidian
setblock 48 202 517 minecraft:crying_obsidian
setblock 48 202 519 minecraft:crying_obsidian
setblock 49 202 510 minecraft:crying_obsidian
setblock 49 202 512 minecraft:crying_obsidian
setblock 49 202 514 minecraft:crying_obsidian
setblock 49 202 516 minecraft:crying_obsidian
setblock 49 202 518 minecraft:crying_obsidian
setblock 49 202 520 minecraft:crying_obsidian
fill 49 202 521 49 205 522 minecraft:polished_blackstone_bricks
setblock 50 202 511 minecraft:crying_obsidian
setblock 50 202 513 minecraft:crying_obsidian
setblock 50 202 515 minecraft:crying_obsidian
setblock 50 202 517 minecraft:crying_obsidian
setblock 50 202 519 minecraft:crying_obsidian
setblock 50 202 521 minecraft:light[level=11]
setblock 50 202 529 minecraft:light[level=11]
setblock 50 202 537 minecraft:light[level=11]
setblock 50 202 545 minecraft:light[level=11]
setblock 51 202 510 minecraft:crying_obsidian
setblock 51 202 512 minecraft:crying_obsidian
setblock 51 202 514 minecraft:crying_obsidian
setblock 51 202 516 minecraft:crying_obsidian
setblock 51 202 518 minecraft:crying_obsidian
setblock 51 202 520 minecraft:crying_obsidian
setblock 52 202 511 minecraft:crying_obsidian
setblock 52 202 513 minecraft:crying_obsidian
setblock 52 202 515 minecraft:crying_obsidian
setblock 52 202 517 minecraft:crying_obsidian
setblock 52 202 519 minecraft:crying_obsidian
setblock 53 202 510 minecraft:crying_obsidian
setblock 53 202 512 minecraft:crying_obsidian
setblock 53 202 514 minecraft:crying_obsidian
setblock 53 202 516 minecraft:crying_obsidian
setblock 53 202 518 minecraft:crying_obsidian
setblock 53 202 520 minecraft:crying_obsidian
setblock 58 202 513 minecraft:light[level=11]
setblock 58 202 521 minecraft:light[level=11]
setblock 58 202 529 minecraft:light[level=11]
setblock 58 202 537 minecraft:light[level=11]
setblock 58 202 545 minecraft:light[level=11]
setblock 60 202 541 minecraft:crying_obsidian
setblock 60 202 543 minecraft:crying_obsidian
setblock 60 202 545 minecraft:crying_obsidian
setblock 60 202 547 minecraft:crying_obsidian
setblock 60 202 549 minecraft:crying_obsidian
setblock 60 202 551 minecraft:crying_obsidian
setblock 61 202 542 minecraft:crying_obsidian
setblock 61 202 544 minecraft:crying_obsidian
setblock 61 202 546 minecraft:crying_obsidian
setblock 61 202 548 minecraft:crying_obsidian
setblock 61 202 550 minecraft:crying_obsidian
setblock 62 202 541 minecraft:crying_obsidian
setblock 62 202 543 minecraft:crying_obsidian
setblock 62 202 545 minecraft:crying_obsidian
setblock 62 202 547 minecraft:crying_obsidian
setblock 62 202 549 minecraft:crying_obsidian
setblock 62 202 551 minecraft:crying_obsidian
setblock 63 202 542 minecraft:crying_obsidian
setblock 63 202 544 minecraft:crying_obsidian
setblock 63 202 546 minecraft:crying_obsidian
setblock 63 202 548 minecraft:crying_obsidian
setblock 63 202 550 minecraft:crying_obsidian
setblock 64 202 541 minecraft:crying_obsidian
setblock 64 202 543 minecraft:crying_obsidian
setblock 64 202 545 minecraft:crying_obsidian
setblock 64 202 547 minecraft:crying_obsidian
setblock 64 202 549 minecraft:crying_obsidian
setblock 64 202 551 minecraft:crying_obsidian
setblock 65 202 542 minecraft:crying_obsidian
setblock 65 202 544 minecraft:crying_obsidian
setblock 65 202 546 minecraft:crying_obsidian
setblock 65 202 548 minecraft:crying_obsidian
setblock 65 202 550 minecraft:crying_obsidian
setblock 66 202 513 minecraft:light[level=11]
setblock 66 202 521 minecraft:light[level=11]
setblock 66 202 529 minecraft:light[level=11]
setblock 66 202 537 minecraft:light[level=11]
setblock 66 202 543 minecraft:crying_obsidian
setblock 66 202 545 minecraft:crying_obsidian
setblock 66 202 547 minecraft:crying_obsidian
setblock 66 202 549 minecraft:crying_obsidian
setblock 66 202 551 minecraft:crying_obsidian
setblock 67 202 542 minecraft:crying_obsidian
setblock 67 202 544 minecraft:crying_obsidian
setblock 67 202 546 minecraft:crying_obsidian
setblock 67 202 548 minecraft:crying_obsidian
setblock 67 202 550 minecraft:crying_obsidian
setblock 68 202 543 minecraft:crying_obsidian
setblock 68 202 545 minecraft:crying_obsidian
setblock 68 202 547 minecraft:crying_obsidian
setblock 68 202 549 minecraft:crying_obsidian
setblock 68 202 551 minecraft:crying_obsidian
setblock 74 202 513 minecraft:light[level=11]
setblock 74 202 521 minecraft:light[level=11]
setblock 74 202 529 minecraft:light[level=11]
setblock 74 202 537 minecraft:light[level=11]
setblock 74 202 545 minecraft:light[level=11]
setblock 82 202 513 minecraft:light[level=11]
setblock 82 202 521 minecraft:light[level=11]
setblock 82 202 529 minecraft:light[level=11]
setblock 82 202 537 minecraft:light[level=11]
setblock 82 202 545 minecraft:light[level=11]
setblock 83 202 536 minecraft:crying_obsidian
setblock 83 202 538 minecraft:crying_obsidian
setblock 83 202 540 minecraft:crying_obsidian
setblock 83 202 542 minecraft:crying_obsidian
setblock 83 202 544 minecraft:crying_obsidian
setblock 84 202 537 minecraft:crying_obsidian
setblock 84 202 539 minecraft:crying_obsidian
setblock 84 202 541 minecraft:crying_obsidian
setblock 84 202 543 minecraft:crying_obsidian
setblock 85 202 536 minecraft:crying_obsidian
setblock 85 202 538 minecraft:crying_obsidian
setblock 85 202 540 minecraft:crying_obsidian
setblock 85 202 542 minecraft:crying_obsidian
setblock 85 202 544 minecraft:crying_obsidian
setblock 86 202 537 minecraft:crying_obsidian
setblock 86 202 539 minecraft:crying_obsidian
setblock 86 202 541 minecraft:crying_obsidian
setblock 86 202 543 minecraft:crying_obsidian
setblock 87 202 536 minecraft:crying_obsidian
setblock 87 202 538 minecraft:crying_obsidian
setblock 87 202 540 minecraft:crying_obsidian
setblock 87 202 542 minecraft:crying_obsidian
setblock 87 202 544 minecraft:crying_obsidian
fill 87 202 545 87 205 546 minecraft:polished_blackstone_bricks
setblock 88 202 537 minecraft:crying_obsidian
setblock 88 202 539 minecraft:crying_obsidian
setblock 88 202 541 minecraft:crying_obsidian
setblock 88 202 543 minecraft:crying_obsidian
fill 48 203 511 48 204 511 minecraft:polished_blackstone_bricks
fill 48 203 513 48 204 513 minecraft:polished_blackstone_bricks
fill 48 203 515 48 204 515 minecraft:polished_blackstone_bricks
fill 48 203 517 48 204 517 minecraft:polished_blackstone_bricks
fill 48 203 519 48 204 519 minecraft:polished_blackstone_bricks
fill 49 203 510 49 204 510 minecraft:polished_blackstone_bricks
fill 49 203 512 49 204 512 minecraft:polished_blackstone_bricks
fill 49 203 514 49 204 514 minecraft:polished_blackstone_bricks
fill 49 203 516 49 204 516 minecraft:polished_blackstone_bricks
fill 49 203 518 49 204 518 minecraft:polished_blackstone_bricks
fill 49 203 520 49 204 520 minecraft:polished_blackstone_bricks
fill 50 203 511 50 204 511 minecraft:polished_blackstone_bricks
fill 50 203 513 50 204 513 minecraft:polished_blackstone_bricks
fill 50 203 515 50 204 515 minecraft:polished_blackstone_bricks
fill 50 203 517 50 204 517 minecraft:polished_blackstone_bricks
fill 50 203 519 50 204 519 minecraft:polished_blackstone_bricks
fill 51 203 510 51 204 510 minecraft:polished_blackstone_bricks
fill 51 203 512 51 204 512 minecraft:polished_blackstone_bricks
fill 51 203 514 51 204 514 minecraft:polished_blackstone_bricks
fill 51 203 516 51 204 516 minecraft:polished_blackstone_bricks
fill 51 203 518 51 204 518 minecraft:polished_blackstone_bricks
fill 51 203 520 51 204 520 minecraft:polished_blackstone_bricks
fill 52 203 511 52 204 511 minecraft:polished_blackstone_bricks
fill 52 203 513 52 204 513 minecraft:polished_blackstone_bricks
fill 52 203 515 52 204 515 minecraft:polished_blackstone_bricks
fill 52 203 517 52 204 517 minecraft:polished_blackstone_bricks
fill 52 203 519 52 204 519 minecraft:polished_blackstone_bricks
fill 53 203 510 53 204 510 minecraft:polished_blackstone_bricks
fill 53 203 512 53 204 512 minecraft:polished_blackstone_bricks
fill 53 203 514 53 204 514 minecraft:polished_blackstone_bricks
fill 53 203 516 53 204 516 minecraft:polished_blackstone_bricks
fill 53 203 518 53 204 518 minecraft:polished_blackstone_bricks
fill 53 203 520 53 204 520 minecraft:polished_blackstone_bricks
setblock 60 203 541 minecraft:polished_blackstone_bricks
setblock 60 203 543 minecraft:polished_blackstone_bricks
setblock 60 203 545 minecraft:polished_blackstone_bricks
setblock 60 203 547 minecraft:polished_blackstone_bricks
setblock 60 203 549 minecraft:polished_blackstone_bricks
setblock 60 203 551 minecraft:polished_blackstone_bricks
setblock 61 203 542 minecraft:polished_blackstone_bricks
setblock 61 203 544 minecraft:polished_blackstone_bricks
setblock 61 203 546 minecraft:polished_blackstone_bricks
setblock 61 203 548 minecraft:polished_blackstone_bricks
setblock 61 203 550 minecraft:polished_blackstone_bricks
setblock 62 203 541 minecraft:polished_blackstone_bricks
setblock 62 203 543 minecraft:polished_blackstone_bricks
setblock 62 203 545 minecraft:polished_blackstone_bricks
setblock 62 203 547 minecraft:polished_blackstone_bricks
setblock 62 203 549 minecraft:polished_blackstone_bricks
setblock 62 203 551 minecraft:polished_blackstone_bricks
setblock 63 203 542 minecraft:polished_blackstone_bricks
setblock 63 203 544 minecraft:polished_blackstone_bricks
setblock 63 203 546 minecraft:polished_blackstone_bricks
setblock 63 203 548 minecraft:polished_blackstone_bricks
setblock 63 203 550 minecraft:polished_blackstone_bricks
setblock 64 203 541 minecraft:polished_blackstone_bricks
setblock 64 203 543 minecraft:polished_blackstone_bricks
setblock 64 203 545 minecraft:polished_blackstone_bricks
setblock 64 203 547 minecraft:polished_blackstone_bricks
setblock 64 203 549 minecraft:polished_blackstone_bricks
setblock 64 203 551 minecraft:polished_blackstone_bricks
setblock 65 203 542 minecraft:polished_blackstone_bricks
setblock 65 203 544 minecraft:polished_blackstone_bricks
setblock 65 203 546 minecraft:polished_blackstone_bricks
setblock 65 203 548 minecraft:polished_blackstone_bricks
setblock 65 203 550 minecraft:polished_blackstone_bricks
setblock 66 203 543 minecraft:polished_blackstone_bricks
setblock 66 203 545 minecraft:polished_blackstone_bricks
setblock 66 203 547 minecraft:polished_blackstone_bricks
setblock 66 203 549 minecraft:polished_blackstone_bricks
fill 66 203 551 66 232 551 minecraft:polished_blackstone_bricks
setblock 67 203 542 minecraft:polished_blackstone_bricks
setblock 67 203 544 minecraft:polished_blackstone_bricks
setblock 67 203 546 minecraft:polished_blackstone_bricks
setblock 67 203 548 minecraft:polished_blackstone_bricks
fill 67 203 550 67 205 550 minecraft:polished_blackstone_bricks
setblock 68 203 543 minecraft:polished_blackstone_bricks
setblock 68 203 545 minecraft:polished_blackstone_bricks
setblock 68 203 547 minecraft:polished_blackstone_bricks
setblock 68 203 549 minecraft:polished_blackstone_bricks
fill 68 203 551 68 232 551 minecraft:polished_blackstone_bricks
fill 83 203 536 83 204 536 minecraft:polished_blackstone_bricks
fill 83 203 538 83 204 538 minecraft:polished_blackstone_bricks
fill 83 203 540 83 204 540 minecraft:polished_blackstone_bricks
fill 83 203 542 83 204 542 minecraft:polished_blackstone_bricks
fill 83 203 544 83 204 544 minecraft:polished_blackstone_bricks
fill 84 203 537 84 204 537 minecraft:polished_blackstone_bricks
fill 84 203 539 84 204 539 minecraft:polished_blackstone_bricks
fill 84 203 541 84 204 541 minecraft:polished_blackstone_bricks
fill 84 203 543 84 204 543 minecraft:polished_blackstone_bricks
fill 85 203 536 85 204 536 minecraft:polished_blackstone_bricks
fill 85 203 538 85 204 538 minecraft:polished_blackstone_bricks
fill 85 203 540 85 204 540 minecraft:polished_blackstone_bricks
fill 85 203 542 85 204 542 minecraft:polished_blackstone_bricks
fill 85 203 544 85 204 544 minecraft:polished_blackstone_bricks
fill 86 203 537 86 204 537 minecraft:polished_blackstone_bricks
fill 86 203 539 86 204 539 minecraft:polished_blackstone_bricks
fill 86 203 541 86 204 541 minecraft:polished_blackstone_bricks
fill 86 203 543 86 204 543 minecraft:polished_blackstone_bricks
fill 87 203 536 87 204 536 minecraft:polished_blackstone_bricks
fill 87 203 538 87 204 538 minecraft:polished_blackstone_bricks
fill 87 203 540 87 204 540 minecraft:polished_blackstone_bricks
fill 87 203 542 87 204 542 minecraft:polished_blackstone_bricks
fill 87 203 544 87 204 544 minecraft:polished_blackstone_bricks
fill 88 203 537 88 204 537 minecraft:polished_blackstone_bricks
fill 88 203 539 88 204 539 minecraft:polished_blackstone_bricks
fill 88 203 541 88 204 541 minecraft:polished_blackstone_bricks
fill 88 203 543 88 204 543 minecraft:polished_blackstone_bricks
fill 61 204 542 66 204 550 minecraft:purple_stained_glass
fill 67 204 542 67 204 549 minecraft:purple_stained_glass
setblock 48 205 511 minecraft:crying_obsidian
setblock 48 205 513 minecraft:crying_obsidian
setblock 48 205 514 minecraft:blackstone
setblock 48 205 515 minecraft:crying_obsidian
setblock 48 205 516 minecraft:blackstone
setblock 48 205 517 minecraft:crying_obsidian
setblock 48 205 518 minecraft:blackstone
setblock 48 205 519 minecraft:crying_obsidian
fill 48 205 526 48 205 531 minecraft:blackstone
fill 48 205 538 48 205 543 minecraft:blackstone
fill 48 205 550 48 205 551 minecraft:blackstone
setblock 49 205 510 minecraft:crying_obsidian
setblock 49 205 512 minecraft:crying_obsidian
setblock 49 205 514 minecraft:crying_obsidian
setblock 49 205 516 minecraft:crying_obsidian
setblock 49 205 518 minecraft:crying_obsidian
setblock 49 205 520 minecraft:crying_obsidian
fill 49 205 551 52 205 551 minecraft:blackstone
setblock 50 205 511 minecraft:crying_obsidian
setblock 50 205 513 minecraft:crying_obsidian
setblock 50 205 515 minecraft:crying_obsidian
setblock 50 205 517 minecraft:crying_obsidian
setblock 50 205 519 minecraft:crying_obsidian
setblock 51 205 510 minecraft:crying_obsidian
setblock 51 205 512 minecraft:crying_obsidian
setblock 51 205 514 minecraft:crying_obsidian
setblock 51 205 516 minecraft:crying_obsidian
setblock 51 205 518 minecraft:crying_obsidian
setblock 51 205 520 minecraft:crying_obsidian
setblock 52 205 511 minecraft:crying_obsidian
setblock 52 205 513 minecraft:crying_obsidian
setblock 52 205 515 minecraft:crying_obsidian
setblock 52 205 517 minecraft:crying_obsidian
setblock 52 205 519 minecraft:crying_obsidian
setblock 53 205 510 minecraft:crying_obsidian
fill 53 205 511 57 205 511 minecraft:blackstone
setblock 53 205 512 minecraft:crying_obsidian
setblock 53 205 514 minecraft:crying_obsidian
setblock 53 205 516 minecraft:crying_obsidian
setblock 53 205 518 minecraft:crying_obsidian
setblock 53 205 520 minecraft:crying_obsidian
fill 59 205 551 64 205 551 minecraft:blackstone
fill 62 205 543 66 205 549 minecraft:purple_stained_glass
fill 64 205 511 69 205 511 minecraft:blackstone
fill 71 205 551 76 205 551 minecraft:blackstone
fill 76 205 511 81 205 511 minecraft:blackstone
setblock 83 205 536 minecraft:crying_obsidian
setblock 83 205 538 minecraft:crying_obsidian
setblock 83 205 540 minecraft:crying_obsidian
setblock 83 205 542 minecraft:crying_obsidian
setblock 83 205 544 minecraft:crying_obsidian
fill 83 205 551 88 205 551 minecraft:blackstone
setblock 84 205 537 minecraft:crying_obsidian
setblock 84 205 539 minecraft:crying_obsidian
setblock 84 205 541 minecraft:crying_obsidian
setblock 84 205 543 minecraft:crying_obsidian
setblock 85 205 536 minecraft:crying_obsidian
setblock 85 205 538 minecraft:crying_obsidian
setblock 85 205 540 minecraft:crying_obsidian
setblock 85 205 542 minecraft:crying_obsidian
setblock 85 205 544 minecraft:crying_obsidian
setblock 86 205 537 minecraft:crying_obsidian
setblock 86 205 539 minecraft:crying_obsidian
setblock 86 205 541 minecraft:crying_obsidian
setblock 86 205 543 minecraft:crying_obsidian
setblock 87 205 536 minecraft:crying_obsidian
setblock 87 205 538 minecraft:crying_obsidian
setblock 87 205 540 minecraft:crying_obsidian
setblock 87 205 542 minecraft:crying_obsidian
setblock 87 205 544 minecraft:crying_obsidian
fill 88 205 511 88 205 516 minecraft:blackstone
fill 88 205 523 88 205 528 minecraft:blackstone
fill 88 205 535 88 205 536 minecraft:blackstone
setblock 88 205 537 minecraft:crying_obsidian
setblock 88 205 538 minecraft:blackstone
setblock 88 205 539 minecraft:crying_obsidian
setblock 88 205 540 minecraft:blackstone
setblock 88 205 541 minecraft:crying_obsidian
setblock 88 205 543 minecraft:crying_obsidian
fill 88 205 547 88 205 550 minecraft:blackstone
setblock 89 205 536 minecraft:polished_blackstone_bricks
fill 47 206 516 47 211 519 minecraft:crying_obsidian
fill 47 206 528 47 211 531 minecraft:crying_obsidian
fill 47 206 540 47 211 543 minecraft:crying_obsidian
fill 47 206 552 50 211 552 minecraft:crying_obsidian
fill 48 206 511 48 232 511 minecraft:polished_blackstone_bricks
fill 48 206 513 48 207 519 minecraft:polished_blackstone_bricks
fill 49 206 510 49 218 510 minecraft:polished_blackstone_bricks
fill 49 206 512 49 207 512 minecraft:polished_blackstone_bricks
fill 49 206 514 49 207 514 minecraft:polished_blackstone_bricks
fill 49 206 516 49 207 516 minecraft:polished_blackstone_bricks
fill 49 206 518 49 207 518 minecraft:polished_blackstone_bricks
fill 49 206 520 49 207 520 minecraft:polished_blackstone_bricks
fill 50 206 511 50 232 511 minecraft:polished_blackstone_bricks
fill 50 206 513 50 207 513 minecraft:polished_blackstone_bricks
fill 50 206 515 50 207 515 minecraft:polished_blackstone_bricks
fill 50 206 517 50 207 517 minecraft:polished_blackstone_bricks
fill 50 206 519 50 207 519 minecraft:polished_blackstone_bricks
fill 51 206 510 51 218 510 minecraft:polished_blackstone_bricks
fill 51 206 512 51 207 512 minecraft:polished_blackstone_bricks
fill 51 206 514 51 207 514 minecraft:polished_blackstone_bricks
fill 51 206 516 51 207 516 minecraft:polished_blackstone_bricks
fill 51 206 518 51 207 518 minecraft:polished_blackstone_bricks
fill 51 206 520 51 207 520 minecraft:polished_blackstone_bricks
fill 52 206 511 53 207 511 minecraft:polished_blackstone_bricks
fill 52 206 513 52 207 513 minecraft:polished_blackstone_bricks
fill 52 206 515 52 207 515 minecraft:polished_blackstone_bricks
fill 52 206 517 52 207 517 minecraft:polished_blackstone_bricks
fill 52 206 519 52 207 519 minecraft:polished_blackstone_bricks
fill 53 206 510 53 218 510 minecraft:polished_blackstone_bricks
fill 53 206 512 53 207 512 minecraft:polished_blackstone_bricks
fill 53 206 514 53 207 514 minecraft:polished_blackstone_bricks
fill 53 206 516 53 207 516 minecraft:polished_blackstone_bricks
fill 53 206 518 53 207 518 minecraft:polished_blackstone_bricks
fill 53 206 520 53 207 520 minecraft:polished_blackstone_bricks
fill 54 206 510 57 211 510 minecraft:crying_obsidian
fill 59 206 552 62 211 552 minecraft:crying_obsidian
fill 63 206 544 65 206 548 minecraft:purple_stained_glass
fill 65 206 552 70 214 552 minecraft:polished_blackstone_bricks
fill 66 206 510 69 211 510 minecraft:crying_obsidian
fill 71 206 552 74 211 552 minecraft:crying_obsidian
fill 78 206 510 81 211 510 minecraft:crying_obsidian
fill 83 206 536 83 207 536 minecraft:polished_blackstone_bricks
fill 83 206 538 83 207 538 minecraft:polished_blackstone_bricks
fill 83 206 540 83 207 540 minecraft:polished_blackstone_bricks
fill 83 206 542 83 207 542 minecraft:polished_blackstone_bricks
fill 83 206 544 83 207 544 minecraft:polished_blackstone_bricks
fill 83 206 552 86 211 552 minecraft:crying_obsidian
fill 84 206 537 84 207 537 minecraft:polished_blackstone_bricks
fill 84 206 539 84 207 539 minecraft:polished_blackstone_bricks
fill 84 206 541 84 207 541 minecraft:polished_blackstone_bricks
fill 84 206 543 84 207 543 minecraft:polished_blackstone_bricks
fill 85 206 536 85 207 536 minecraft:polished_blackstone_bricks
fill 85 206 538 85 207 538 minecraft:polished_blackstone_bricks
fill 85 206 540 85 207 540 minecraft:polished_blackstone_bricks
fill 85 206 542 85 207 542 minecraft:polished_blackstone_bricks
fill 85 206 544 85 207 544 minecraft:polished_blackstone_bricks
fill 86 206 537 86 207 537 minecraft:polished_blackstone_bricks
fill 86 206 539 86 207 539 minecraft:polished_blackstone_bricks
fill 86 206 541 86 207 541 minecraft:polished_blackstone_bricks
fill 86 206 543 86 207 543 minecraft:polished_blackstone_bricks
fill 87 206 536 88 207 536 minecraft:polished_blackstone_bricks
fill 87 206 538 88 207 538 minecraft:polished_blackstone_bricks
fill 87 206 540 88 207 540 minecraft:polished_blackstone_bricks
fill 87 206 542 87 207 542 minecraft:polished_blackstone_bricks
fill 87 206 544 87 207 544 minecraft:polished_blackstone_bricks
fill 88 206 537 88 207 537 minecraft:polished_blackstone_bricks
fill 88 206 539 88 207 539 minecraft:polished_blackstone_bricks
fill 88 206 541 88 207 541 minecraft:polished_blackstone_bricks
fill 88 206 543 88 207 543 minecraft:polished_blackstone_bricks
fill 89 206 511 89 211 514 minecraft:crying_obsidian
fill 89 206 523 89 211 526 minecraft:crying_obsidian
fill 89 206 535 89 211 538 minecraft:crying_obsidian
fill 89 206 547 89 211 550 minecraft:crying_obsidian
fill 64 207 545 64 207 547 minecraft:purple_stained_glass
fill 48 208 521 48 232 523 minecraft:polished_blackstone_bricks
fill 49 208 512 52 208 519 minecraft:purple_stained_glass
fill 51 208 511 52 208 511 minecraft:purple_stained_glass
setblock 70 208 546 minecraft:crying_obsidian
fill 82 208 515 82 208 517 minecraft:blackstone
fill 83 208 514 85 208 514 minecraft:blackstone
fill 83 208 518 85 208 518 minecraft:blackstone
setblock 83 208 536 minecraft:crying_obsidian
setblock 83 208 538 minecraft:crying_obsidian
setblock 83 208 540 minecraft:crying_obsidian
setblock 83 208 542 minecraft:crying_obsidian
setblock 83 208 544 minecraft:crying_obsidian
setblock 84 208 537 minecraft:crying_obsidian
setblock 84 208 539 minecraft:crying_obsidian
setblock 84 208 541 minecraft:crying_obsidian
setblock 84 208 543 minecraft:crying_obsidian
setblock 85 208 536 minecraft:crying_obsidian
setblock 85 208 538 minecraft:crying_obsidian
setblock 85 208 540 minecraft:crying_obsidian
setblock 85 208 542 minecraft:crying_obsidian
setblock 85 208 544 minecraft:crying_obsidian
fill 86 208 515 86 208 517 minecraft:blackstone
setblock 86 208 537 minecraft:crying_obsidian
setblock 86 208 539 minecraft:crying_obsidian
setblock 86 208 541 minecraft:crying_obsidian
setblock 86 208 543 minecraft:crying_obsidian
setblock 87 208 536 minecraft:crying_obsidian
setblock 87 208 538 minecraft:crying_obsidian
setblock 87 208 540 minecraft:crying_obsidian
setblock 87 208 542 minecraft:crying_obsidian
setblock 87 208 544 minecraft:crying_obsidian
fill 88 208 536 88 213 536 minecraft:polished_blackstone_bricks
setblock 88 208 537 minecraft:crying_obsidian
fill 88 208 538 88 213 538 minecraft:polished_blackstone_bricks
setblock 88 208 539 minecraft:crying_obsidian
fill 88 208 540 88 213 540 minecraft:polished_blackstone_bricks
setblock 88 208 541 minecraft:crying_obsidian
setblock 88 208 543 minecraft:crying_obsidian
fill 50 209 512 51 209 518 minecraft:purple_stained_glass
fill 83 209 536 83 210 536 minecraft:polished_blackstone_bricks
fill 83 209 538 83 210 538 minecraft:polished_blackstone_bricks
fill 83 209 540 83 210 540 minecraft:polished_blackstone_bricks
fill 83 209 542 83 210 542 minecraft:polished_blackstone_bricks
fill 83 209 544 83 210 544 minecraft:polished_blackstone_bricks
fill 84 209 537 84 210 537 minecraft:polished_blackstone_bricks
fill 84 209 539 84 210 539 minecraft:polished_blackstone_bricks
fill 84 209 541 84 210 541 minecraft:polished_blackstone_bricks
fill 84 209 543 84 210 543 minecraft:polished_blackstone_bricks
fill 85 209 536 85 210 536 minecraft:polished_blackstone_bricks
fill 85 209 538 85 210 538 minecraft:polished_blackstone_bricks
fill 85 209 540 85 210 540 minecraft:polished_blackstone_bricks
fill 85 209 542 85 210 542 minecraft:polished_blackstone_bricks
fill 85 209 544 85 210 544 minecraft:polished_blackstone_bricks
fill 86 209 537 86 210 537 minecraft:polished_blackstone_bricks
fill 86 209 539 86 210 539 minecraft:polished_blackstone_bricks
fill 86 209 541 86 210 541 minecraft:polished_blackstone_bricks
fill 86 209 543 86 210 543 minecraft:polished_blackstone_bricks
fill 87 209 536 87 210 536 minecraft:polished_blackstone_bricks
fill 87 209 538 87 210 538 minecraft:polished_blackstone_bricks
fill 87 209 540 87 210 540 minecraft:polished_blackstone_bricks
fill 87 209 542 87 210 542 minecraft:polished_blackstone_bricks
fill 87 209 544 87 210 544 minecraft:polished_blackstone_bricks
fill 88 209 537 88 210 537 minecraft:polished_blackstone_bricks
fill 88 209 539 88 210 539 minecraft:polished_blackstone_bricks
fill 88 209 541 88 210 541 minecraft:polished_blackstone_bricks
fill 88 209 543 88 210 543 minecraft:polished_blackstone_bricks
fill 50 210 513 51 210 517 minecraft:purple_stained_glass
setblock 50 210 521 minecraft:light[level=11]
setblock 50 210 529 minecraft:light[level=11]
setblock 50 210 537 minecraft:light[level=11]
setblock 50 210 545 minecraft:light[level=11]
setblock 58 210 513 minecraft:light[level=11]
setblock 58 210 521 minecraft:light[level=11]
setblock 58 210 529 minecraft:light[level=11]
setblock 58 210 537 minecraft:light[level=11]
setblock 58 210 545 minecraft:light[level=11]
setblock 66 210 513 minecraft:light[level=11]
setblock 66 210 521 minecraft:light[level=11]
setblock 66 210 529 minecraft:light[level=11]
setblock 66 210 537 minecraft:light[level=11]
setblock 66 210 545 minecraft:light[level=11]
setblock 74 210 513 minecraft:light[level=11]
setblock 74 210 521 minecraft:light[level=11]
setblock 74 210 529 minecraft:light[level=11]
setblock 74 210 537 minecraft:light[level=11]
setblock 74 210 545 minecraft:light[level=11]
setblock 82 210 513 minecraft:light[level=11]
setblock 82 210 521 minecraft:light[level=11]
setblock 82 210 529 minecraft:light[level=11]
setblock 82 210 537 minecraft:light[level=11]
setblock 82 210 545 minecraft:light[level=11]
fill 86 210 532 86 221 532 minecraft:purple_wool
fill 49 211 514 52 211 516 minecraft:purple_stained_glass
setblock 83 211 536 minecraft:crying_obsidian
setblock 83 211 538 minecraft:crying_obsidian
setblock 83 211 540 minecraft:crying_obsidian
setblock 83 211 542 minecraft:crying_obsidian
setblock 83 211 544 minecraft:crying_obsidian
setblock 84 211 537 minecraft:crying_obsidian
setblock 84 211 539 minecraft:crying_obsidian
setblock 84 211 541 minecraft:crying_obsidian
setblock 84 211 543 minecraft:crying_obsidian
setblock 85 211 536 minecraft:crying_obsidian
setblock 85 211 538 minecraft:crying_obsidian
setblock 85 211 540 minecraft:crying_obsidian
setblock 85 211 542 minecraft:crying_obsidian
setblock 85 211 544 minecraft:crying_obsidian
fill 86 211 530 86 221 531 minecraft:purple_wool
fill 86 211 533 86 221 534 minecraft:purple_wool
setblock 86 211 537 minecraft:crying_obsidian
setblock 86 211 539 minecraft:crying_obsidian
setblock 86 211 541 minecraft:crying_obsidian
setblock 86 211 543 minecraft:crying_obsidian
setblock 87 211 536 minecraft:crying_obsidian
setblock 87 211 538 minecraft:crying_obsidian
setblock 87 211 540 minecraft:crying_obsidian
setblock 87 211 542 minecraft:crying_obsidian
setblock 87 211 544 minecraft:crying_obsidian
setblock 88 211 537 minecraft:crying_obsidian
setblock 88 211 539 minecraft:crying_obsidian
setblock 88 211 541 minecraft:crying_obsidian
setblock 88 211 543 minecraft:crying_obsidian
fill 47 212 516 47 218 516 minecraft:polished_blackstone_bricks
fill 47 212 517 47 212 518 minecraft:crying_obsidian
fill 47 212 519 47 214 519 minecraft:polished_blackstone_bricks
fill 47 212 528 47 218 528 minecraft:polished_blackstone_bricks
fill 47 212 529 47 212 530 minecraft:crying_obsidian
fill 47 212 531 47 218 531 minecraft:polished_blackstone_bricks
fill 47 212 540 47 216 540 minecraft:polished_blackstone_bricks
schedule function dropper:buildpart/121_2 1t
