fill 136 252 338 136 308 338 minecraft:stone
setblock 136 252 359 minecraft:raw_iron_block
fill 136 252 360 136 281 360 minecraft:stone
fill 94 253 331 94 308 331 minecraft:stone
fill 94 253 336 94 296 336 minecraft:stone
fill 94 253 345 94 308 345 minecraft:stone
fill 94 253 363 94 282 363 minecraft:stone
setblock 95 253 337 minecraft:stripped_spruce_log
fill 95 253 338 95 256 338 minecraft:stone
fill 95 253 340 95 253 341 minecraft:stone
setblock 95 253 342 minecraft:stripped_spruce_log
fill 95 253 343 95 256 343 minecraft:stone
setblock 95 253 347 minecraft:stripped_spruce_log
setblock 96 253 340 minecraft:stone
setblock 96 253 341 minecraft:stripped_spruce_log
fill 96 253 342 96 256 342 minecraft:stone
fill 97 253 323 98 253 323 minecraft:stone
setblock 97 253 325 minecraft:light[level=12]
setblock 97 253 332 minecraft:light[level=12]
setblock 97 253 339 minecraft:light[level=12]
setblock 97 253 346 minecraft:light[level=12]
setblock 97 253 353 minecraft:light[level=12]
setblock 97 253 360 minecraft:light[level=12]
setblock 99 253 323 minecraft:stripped_spruce_log
setblock 99 253 363 minecraft:stripped_spruce_log
fill 100 253 323 102 253 324 minecraft:stone
fill 100 253 363 100 256 363 minecraft:stone
setblock 102 253 325 minecraft:stripped_spruce_log
fill 102 253 339 111 254 339 minecraft:stripped_spruce_log
fill 102 253 362 104 253 362 minecraft:stone
setblock 103 253 323 minecraft:stone
setblock 103 253 324 minecraft:stripped_spruce_log
fill 103 253 325 103 256 325 minecraft:stone
setblock 104 253 323 minecraft:stripped_spruce_log
fill 104 253 324 107 253 324 minecraft:stone
setblock 104 253 332 minecraft:light[level=12]
setblock 104 253 346 minecraft:light[level=12]
setblock 104 253 353 minecraft:light[level=12]
setblock 104 253 360 minecraft:light[level=12]
setblock 104 253 363 minecraft:stripped_spruce_log
fill 105 253 323 108 253 323 minecraft:stone
setblock 105 253 362 minecraft:stripped_spruce_log
fill 105 253 363 108 253 363 minecraft:stone
fill 106 253 338 111 253 338 minecraft:stripped_spruce_log
fill 106 253 362 109 253 362 minecraft:stone
setblock 107 253 325 minecraft:stripped_spruce_log
setblock 108 253 324 minecraft:stripped_spruce_log
fill 108 253 325 108 254 325 minecraft:stone
setblock 109 253 323 minecraft:stripped_spruce_log
fill 109 253 324 112 253 324 minecraft:stone
setblock 109 253 363 minecraft:stripped_spruce_log
fill 110 253 323 110 256 323 minecraft:stone
fill 110 253 362 110 255 362 minecraft:stripped_spruce_log
fill 110 253 363 113 253 363 minecraft:stone
setblock 111 253 325 minecraft:light[level=12]
setblock 111 253 332 minecraft:light[level=12]
setblock 111 253 346 minecraft:light[level=12]
setblock 111 253 353 minecraft:light[level=12]
setblock 111 253 360 minecraft:light[level=12]
setblock 113 253 323 minecraft:stone
setblock 113 253 324 minecraft:stripped_spruce_log
setblock 114 253 323 minecraft:stripped_spruce_log
setblock 114 253 363 minecraft:stripped_spruce_log
fill 115 253 323 115 256 323 minecraft:stone
fill 115 253 363 118 253 363 minecraft:stone
fill 116 253 362 119 253 362 minecraft:stone
setblock 117 253 324 minecraft:stone
setblock 118 253 323 minecraft:stone
setblock 118 253 324 minecraft:stripped_spruce_log
setblock 118 253 325 minecraft:light[level=12]
setblock 118 253 332 minecraft:light[level=12]
setblock 118 253 339 minecraft:light[level=12]
setblock 118 253 346 minecraft:light[level=12]
setblock 118 253 353 minecraft:light[level=12]
setblock 118 253 360 minecraft:light[level=12]
setblock 119 253 323 minecraft:stripped_spruce_log
fill 119 253 324 122 253 324 minecraft:stone
fill 119 253 338 125 253 339 minecraft:stripped_spruce_log
setblock 119 253 363 minecraft:stripped_spruce_log
fill 120 253 323 120 256 323 minecraft:stone
setblock 120 253 361 minecraft:stone
setblock 120 253 362 minecraft:stripped_spruce_log
fill 120 253 363 123 253 363 minecraft:stone
setblock 121 253 361 minecraft:stripped_spruce_log
fill 121 253 362 124 253 362 minecraft:stone
fill 122 253 334 135 253 334 minecraft:stripped_spruce_log
fill 122 253 361 122 256 361 minecraft:stone
setblock 123 253 323 minecraft:stone
setblock 123 253 324 minecraft:stripped_spruce_log
setblock 124 253 323 minecraft:stripped_spruce_log
fill 124 253 324 124 256 324 minecraft:stone
fill 124 253 336 124 256 336 minecraft:cobbled_deepslate
setblock 124 253 363 minecraft:stripped_spruce_log
fill 125 253 323 128 253 323 minecraft:stone
setblock 125 253 325 minecraft:light[level=12]
setblock 125 253 332 minecraft:light[level=12]
setblock 125 253 346 minecraft:light[level=12]
setblock 125 253 353 minecraft:light[level=12]
setblock 125 253 360 minecraft:light[level=12]
setblock 125 253 362 minecraft:stripped_spruce_log
fill 125 253 363 128 253 363 minecraft:stone
fill 126 253 324 127 253 324 minecraft:stone
setblock 126 253 338 minecraft:stripped_spruce_log
setblock 126 253 361 minecraft:stripped_spruce_log
fill 126 253 362 129 253 362 minecraft:stone
fill 127 253 335 127 256 337 minecraft:cobbled_deepslate
fill 127 253 361 127 254 361 minecraft:stone
fill 128 253 338 134 253 338 minecraft:stripped_dark_oak_log
setblock 129 253 323 minecraft:stripped_spruce_log
setblock 129 253 363 minecraft:stripped_spruce_log
setblock 130 253 323 minecraft:stone
fill 130 253 362 130 255 362 minecraft:stripped_spruce_log
fill 130 253 363 133 253 363 minecraft:stone
setblock 131 253 362 minecraft:stone
setblock 132 253 325 minecraft:light[level=12]
setblock 132 253 332 minecraft:light[level=12]
setblock 132 253 339 minecraft:light[level=12]
setblock 132 253 346 minecraft:light[level=12]
setblock 132 253 353 minecraft:light[level=12]
setblock 132 253 360 minecraft:light[level=12]
setblock 134 253 343 minecraft:stripped_spruce_log
fill 134 253 344 135 255 344 minecraft:stone
setblock 134 253 363 minecraft:stripped_spruce_log
fill 135 253 339 135 253 341 minecraft:stone
setblock 135 253 342 minecraft:stripped_spruce_log
fill 135 253 343 135 256 343 minecraft:stone
fill 135 253 345 135 253 346 minecraft:stone
setblock 135 253 347 minecraft:stripped_spruce_log
fill 135 253 348 135 256 348 minecraft:stone
fill 136 253 330 136 266 332 minecraft:stone
setblock 136 253 333 minecraft:raw_iron_block
fill 136 253 334 136 253 336 minecraft:stone
fill 136 253 359 136 308 359 minecraft:stone
fill 94 254 346 94 308 346 minecraft:stone
fill 95 254 327 134 255 327 minecraft:stripped_spruce_log
fill 95 254 334 127 254 334 minecraft:stripped_spruce_log
setblock 95 254 340 minecraft:stone
setblock 95 254 341 minecraft:stripped_spruce_log
fill 95 254 342 95 257 342 minecraft:stone
setblock 95 254 346 minecraft:stripped_spruce_log
fill 95 254 347 95 257 347 minecraft:stone
fill 95 254 348 134 255 348 minecraft:stripped_spruce_log
fill 95 254 355 110 254 355 minecraft:stripped_spruce_log
fill 95 254 362 101 254 362 minecraft:stripped_spruce_log
fill 96 254 339 96 254 340 minecraft:stripped_spruce_log
fill 96 254 341 96 257 341 minecraft:stone
setblock 96 254 344 minecraft:stone
setblock 96 254 345 minecraft:stripped_spruce_log
setblock 97 254 323 minecraft:stone
fill 97 254 325 97 258 325 minecraft:stripped_spruce_log
fill 97 254 338 101 254 339 minecraft:stripped_spruce_log
fill 97 254 341 97 255 341 minecraft:stripped_spruce_log
setblock 98 254 323 minecraft:stripped_spruce_log
fill 99 254 323 101 254 324 minecraft:stone
fill 99 254 363 99 257 363 minecraft:stone
fill 100 254 322 100 308 322 minecraft:stone
setblock 101 254 322 minecraft:raw_gold_block
fill 102 254 322 102 254 323 minecraft:stone
setblock 102 254 324 minecraft:stripped_spruce_log
fill 102 254 325 102 257 325 minecraft:stone
fill 102 254 338 110 254 338 minecraft:stripped_spruce_log
fill 102 254 362 102 254 363 minecraft:stone
setblock 102 254 364 minecraft:gold_block
setblock 103 254 323 minecraft:stripped_spruce_log
fill 103 254 324 106 254 324 minecraft:stone
setblock 103 254 362 minecraft:stone
setblock 103 254 363 minecraft:stripped_spruce_log
fill 103 254 364 103 297 364 minecraft:stone
fill 104 254 323 107 254 323 minecraft:stone
setblock 104 254 362 minecraft:stripped_spruce_log
fill 104 254 363 107 254 363 minecraft:stone
fill 105 254 362 108 254 362 minecraft:stone
setblock 106 254 325 minecraft:stripped_spruce_log
fill 107 254 322 110 264 322 minecraft:stone
setblock 107 254 324 minecraft:stripped_spruce_log
fill 107 254 325 107 257 325 minecraft:stone
setblock 108 254 323 minecraft:stripped_spruce_log
fill 108 254 324 111 254 324 minecraft:stone
setblock 108 254 363 minecraft:stripped_spruce_log
fill 109 254 323 109 257 323 minecraft:stone
fill 109 254 362 109 255 362 minecraft:stripped_spruce_log
fill 109 254 363 112 254 363 minecraft:stone
setblock 111 254 322 minecraft:gold_block
fill 111 254 362 116 254 362 minecraft:stripped_spruce_log
setblock 112 254 324 minecraft:stripped_spruce_log
setblock 113 254 323 minecraft:stripped_spruce_log
setblock 113 254 363 minecraft:stripped_spruce_log
fill 114 254 323 114 257 323 minecraft:stone
fill 114 254 363 117 254 363 minecraft:stone
setblock 117 254 324 minecraft:stripped_spruce_log
fill 117 254 362 118 254 362 minecraft:stone
setblock 118 254 323 minecraft:stripped_spruce_log
fill 118 254 324 121 254 324 minecraft:stone
setblock 118 254 363 minecraft:stripped_spruce_log
fill 119 254 323 119 257 323 minecraft:stone
fill 119 254 338 121 254 339 minecraft:stripped_dark_oak_log
setblock 119 254 362 minecraft:stripped_spruce_log
fill 119 254 363 122 254 363 minecraft:stone
setblock 120 254 361 minecraft:stripped_spruce_log
fill 120 254 362 123 254 362 minecraft:stone
fill 121 254 361 121 257 361 minecraft:stone
setblock 122 254 324 minecraft:stripped_spruce_log
fill 122 254 338 124 254 338 minecraft:stripped_dark_oak_log
setblock 123 254 323 minecraft:stripped_spruce_log
fill 123 254 324 123 257 324 minecraft:stone
setblock 123 254 363 minecraft:stripped_spruce_log
fill 124 254 323 127 254 323 minecraft:stone
fill 124 254 335 124 256 335 minecraft:cobbled_deepslate
fill 124 254 337 124 256 337 minecraft:cobbled_deepslate
setblock 124 254 362 minecraft:stripped_spruce_log
fill 124 254 363 127 254 363 minecraft:stone
fill 125 254 338 126 256 338 minecraft:cobbled_deepslate
setblock 125 254 361 minecraft:stripped_spruce_log
fill 125 254 362 128 254 362 minecraft:stone
setblock 126 254 324 minecraft:stone
setblock 126 254 361 minecraft:stone
setblock 128 254 323 minecraft:stripped_spruce_log
setblock 128 254 363 minecraft:stripped_spruce_log
fill 129 254 323 129 255 323 minecraft:stone
fill 129 254 362 129 255 362 minecraft:stripped_spruce_log
fill 129 254 363 132 254 363 minecraft:stone
fill 131 254 362 134 255 362 minecraft:stripped_spruce_log
setblock 135 254 340 minecraft:stone
setblock 135 254 341 minecraft:stripped_spruce_log
fill 135 254 342 135 257 342 minecraft:stone
setblock 135 254 345 minecraft:stone
setblock 135 254 346 minecraft:stripped_spruce_log
fill 135 254 347 135 257 347 minecraft:stone
fill 135 254 349 135 255 349 minecraft:stone
fill 136 254 333 136 261 335 minecraft:stone
setblock 136 254 336 minecraft:raw_gold_block
fill 95 255 334 97 255 334 minecraft:stripped_spruce_log
setblock 95 255 340 minecraft:stripped_spruce_log
fill 95 255 341 95 258 341 minecraft:stone
setblock 95 255 344 minecraft:stone
setblock 95 255 345 minecraft:stripped_spruce_log
fill 95 255 346 95 258 346 minecraft:stone
fill 95 255 355 98 255 355 minecraft:stripped_spruce_log
fill 95 255 362 98 255 362 minecraft:stripped_spruce_log
setblock 96 255 323 minecraft:stone
fill 96 255 339 101 255 339 minecraft:stripped_spruce_log
setblock 96 255 344 minecraft:stripped_spruce_log
fill 96 255 345 96 258 345 minecraft:stone
setblock 97 255 323 minecraft:stripped_spruce_log
fill 98 255 323 100 255 324 minecraft:stone
fill 98 255 341 111 255 341 minecraft:stripped_spruce_log
fill 99 255 350 99 255 362 minecraft:iron_bars
fill 100 255 355 135 255 355 minecraft:stripped_spruce_log
fill 100 255 362 103 255 362 minecraft:stripped_spruce_log
fill 101 255 322 101 255 323 minecraft:stone
setblock 101 255 324 minecraft:stripped_spruce_log
fill 101 255 325 101 258 325 minecraft:stone
fill 102 255 322 102 308 322 minecraft:stone
setblock 102 255 323 minecraft:stripped_spruce_log
fill 102 255 324 105 255 324 minecraft:stone
fill 102 255 339 111 255 339 minecraft:stripped_dark_oak_log
setblock 102 255 363 minecraft:stripped_spruce_log
fill 102 255 364 102 263 364 minecraft:stone
fill 103 255 323 106 255 323 minecraft:stone
fill 103 255 363 106 255 363 minecraft:stone
fill 104 255 362 106 255 362 minecraft:stone
setblock 105 255 325 minecraft:stripped_spruce_log
setblock 106 255 324 minecraft:stripped_spruce_log
fill 106 255 325 106 258 325 minecraft:stone
setblock 107 255 323 minecraft:stripped_spruce_log
fill 107 255 324 110 255 324 minecraft:stone
fill 107 255 362 107 255 363 minecraft:stripped_spruce_log
fill 108 255 323 108 258 323 minecraft:stone
setblock 108 255 362 minecraft:stripped_spruce_log
fill 108 255 363 111 255 363 minecraft:stone
fill 111 255 322 112 255 322 minecraft:stone
setblock 111 255 324 minecraft:stripped_spruce_log
fill 111 255 362 112 255 362 minecraft:stripped_spruce_log
setblock 112 255 323 minecraft:stripped_spruce_log
fill 112 255 324 112 258 324 minecraft:stone
setblock 112 255 363 minecraft:stripped_spruce_log
fill 113 255 323 113 258 323 minecraft:stone
fill 113 255 356 113 256 362 minecraft:iron_bars
fill 113 255 363 116 255 363 minecraft:stone
fill 114 255 362 116 255 362 minecraft:stripped_spruce_log
setblock 116 255 324 minecraft:stripped_spruce_log
fill 116 255 364 118 258 364 minecraft:stone
fill 117 255 322 117 282 322 minecraft:stone
setblock 117 255 323 minecraft:stripped_spruce_log
fill 117 255 324 120 255 324 minecraft:stone
setblock 117 255 362 minecraft:stone
setblock 117 255 363 minecraft:stripped_spruce_log
fill 118 255 323 118 258 323 minecraft:stone
fill 118 255 341 126 255 341 minecraft:stripped_spruce_log
setblock 118 255 362 minecraft:stripped_spruce_log
fill 118 255 363 121 255 363 minecraft:stone
fill 119 255 362 122 255 362 minecraft:stone
setblock 119 255 364 minecraft:diamond_block
fill 121 255 322 121 255 323 minecraft:stone
setblock 121 255 324 minecraft:stripped_spruce_log
fill 122 255 322 122 279 322 minecraft:stone
setblock 122 255 323 minecraft:stripped_spruce_log
fill 122 255 324 122 258 324 minecraft:stone
setblock 122 255 363 minecraft:stripped_spruce_log
fill 123 255 323 126 255 323 minecraft:stone
fill 123 255 336 123 256 336 minecraft:cobbled_deepslate
setblock 123 255 362 minecraft:stripped_spruce_log
fill 123 255 363 126 255 363 minecraft:stone
fill 124 255 334 127 256 334 minecraft:cobbled_deepslate
fill 124 255 338 124 256 338 minecraft:cobbled_deepslate
setblock 124 255 361 minecraft:stripped_spruce_log
fill 124 255 362 127 255 362 minecraft:stone
setblock 125 255 361 minecraft:stone
setblock 126 255 324 minecraft:stripped_spruce_log
setblock 127 255 323 minecraft:stripped_spruce_log
fill 127 255 338 127 256 338 minecraft:cobbled_deepslate
setblock 127 255 363 minecraft:stripped_spruce_log
fill 128 255 323 128 258 323 minecraft:stone
fill 128 255 335 128 256 337 minecraft:cobbled_deepslate
setblock 128 255 362 minecraft:stripped_spruce_log
fill 128 255 363 131 255 363 minecraft:stone
setblock 134 255 345 minecraft:stone
setblock 135 255 340 minecraft:stripped_spruce_log
fill 135 255 341 135 258 341 minecraft:stone
setblock 135 255 345 minecraft:stripped_spruce_log
fill 135 255 346 135 258 346 minecraft:stone
fill 136 255 336 136 300 336 minecraft:stone
setblock 136 255 351 minecraft:raw_iron_block
setblock 95 256 323 minecraft:stone
setblock 95 256 324 minecraft:stripped_spruce_log
fill 95 256 325 95 258 326 minecraft:stone
setblock 95 256 339 minecraft:stripped_spruce_log
fill 95 256 340 95 259 340 minecraft:stone
setblock 95 256 344 minecraft:stripped_spruce_log
fill 95 256 345 95 259 345 minecraft:stone
setblock 95 256 348 minecraft:stone
setblock 96 256 323 minecraft:stripped_spruce_log
fill 96 256 339 98 256 339 minecraft:stripped_dark_oak_log
setblock 96 256 343 minecraft:stripped_spruce_log
fill 96 256 344 96 259 344 minecraft:stone
fill 96 256 346 96 257 346 minecraft:stone
fill 97 256 323 100 256 323 minecraft:stone
fill 98 256 324 99 256 324 minecraft:stone
setblock 98 256 364 minecraft:raw_iron_block
fill 99 256 325 99 256 355 minecraft:iron_bars
fill 99 256 364 101 259 364 minecraft:stone
setblock 100 256 324 minecraft:stripped_spruce_log
fill 100 256 325 100 259 325 minecraft:stone
setblock 100 256 339 minecraft:stripped_dark_oak_log
fill 101 256 322 101 262 322 minecraft:stone
setblock 101 256 323 minecraft:stripped_spruce_log
fill 101 256 324 104 256 324 minecraft:stone
setblock 101 256 363 minecraft:stripped_spruce_log
fill 102 256 323 105 256 323 minecraft:stone
fill 102 256 363 105 256 363 minecraft:stone
setblock 104 256 325 minecraft:stripped_spruce_log
setblock 105 256 324 minecraft:stripped_spruce_log
fill 105 256 325 105 259 325 minecraft:stone
setblock 106 256 323 minecraft:stripped_spruce_log
fill 106 256 324 109 256 324 minecraft:stone
fill 106 256 326 106 257 326 minecraft:iron_bars
setblock 106 256 363 minecraft:stripped_spruce_log
fill 107 256 323 107 259 323 minecraft:stone
fill 107 256 363 110 256 363 minecraft:stone
setblock 110 256 324 minecraft:stripped_spruce_log
setblock 111 256 322 minecraft:gold_block
setblock 111 256 323 minecraft:stripped_spruce_log
fill 111 256 324 111 259 324 minecraft:stone
setblock 111 256 363 minecraft:stripped_spruce_log
fill 112 256 322 112 259 323 minecraft:stone
fill 112 256 363 115 256 363 minecraft:stone
fill 113 256 324 113 256 335 minecraft:iron_bars
fill 113 256 343 113 256 355 minecraft:iron_bars
setblock 115 256 324 minecraft:stripped_spruce_log
setblock 116 256 323 minecraft:stripped_spruce_log
fill 116 256 324 119 256 324 minecraft:stone
setblock 116 256 363 minecraft:stripped_spruce_log
fill 117 256 323 117 259 323 minecraft:stone
setblock 117 256 362 minecraft:stripped_spruce_log
fill 117 256 363 120 256 363 minecraft:stone
fill 118 256 362 121 256 362 minecraft:stone
fill 119 256 364 119 260 364 minecraft:stone
setblock 120 256 324 minecraft:stripped_spruce_log
fill 120 256 325 120 257 346 minecraft:iron_bars
setblock 121 256 322 minecraft:diamond_block
setblock 121 256 323 minecraft:stripped_spruce_log
fill 121 256 324 121 259 324 minecraft:stone
fill 121 256 341 134 256 341 minecraft:stripped_spruce_log
setblock 121 256 363 minecraft:stripped_spruce_log
fill 122 256 323 125 256 323 minecraft:stone
setblock 122 256 362 minecraft:stripped_spruce_log
fill 122 256 363 125 256 363 minecraft:stone
setblock 123 256 335 minecraft:cobbled_deepslate
setblock 123 256 337 minecraft:cobbled_deepslate
setblock 123 256 361 minecraft:stripped_spruce_log
fill 123 256 362 126 256 362 minecraft:stone
setblock 124 256 361 minecraft:stone
setblock 125 256 324 minecraft:stripped_spruce_log
fill 125 256 333 126 256 333 minecraft:cobbled_deepslate
setblock 126 256 323 minecraft:stripped_spruce_log
setblock 126 256 324 minecraft:stone
setblock 126 256 339 minecraft:cobbled_deepslate
setblock 126 256 363 minecraft:stripped_spruce_log
fill 127 256 323 127 259 323 minecraft:stone
fill 127 256 324 127 257 328 minecraft:iron_bars
setblock 127 256 362 minecraft:stripped_spruce_log
fill 127 256 363 130 256 363 minecraft:stone
setblock 128 256 334 minecraft:cobbled_deepslate
fill 134 256 323 134 256 340 minecraft:iron_bars
fill 134 256 342 134 256 343 minecraft:iron_bars
setblock 134 256 344 minecraft:stone
setblock 134 256 345 minecraft:stripped_spruce_log
fill 134 256 346 134 259 346 minecraft:stone
fill 134 256 347 134 256 363 minecraft:iron_bars
fill 135 256 340 135 259 340 minecraft:stone
setblock 135 256 344 minecraft:stripped_spruce_log
fill 135 256 345 135 259 345 minecraft:stone
setblock 135 256 349 minecraft:stripped_spruce_log
fill 135 256 350 135 259 350 minecraft:stone
fill 136 256 351 136 308 351 minecraft:stone
setblock 136 256 358 minecraft:raw_iron_block
fill 94 257 324 95 260 324 minecraft:stone
setblock 94 257 325 minecraft:raw_gold_block
fill 94 257 326 94 263 330 minecraft:stone
setblock 95 257 323 minecraft:stripped_spruce_log
setblock 95 257 327 minecraft:stone
setblock 95 257 328 minecraft:stripped_spruce_log
fill 95 257 329 95 260 329 minecraft:stone
setblock 95 257 338 minecraft:stripped_spruce_log
fill 95 257 339 95 260 339 minecraft:stone
setblock 95 257 343 minecraft:stripped_spruce_log
fill 95 257 344 95 260 344 minecraft:stone
setblock 95 257 348 minecraft:stripped_spruce_log
fill 95 257 349 95 260 349 minecraft:stone
fill 96 257 323 99 257 323 minecraft:stone
fill 96 257 325 96 257 326 minecraft:stone
setblock 96 257 342 minecraft:stripped_spruce_log
fill 96 257 343 96 259 343 minecraft:stone
setblock 96 257 347 minecraft:stripped_spruce_log
fill 97 257 324 98 257 324 minecraft:stone
fill 98 257 363 98 258 364 minecraft:stone
setblock 99 257 324 minecraft:stripped_spruce_log
fill 99 257 325 99 260 325 minecraft:stone
setblock 100 257 323 minecraft:stripped_spruce_log
fill 100 257 324 103 257 324 minecraft:stone
setblock 100 257 363 minecraft:stripped_spruce_log
fill 101 257 323 104 257 323 minecraft:stone
fill 101 257 363 104 257 363 minecraft:stone
setblock 102 257 326 minecraft:stripped_spruce_log
setblock 103 257 325 minecraft:stripped_spruce_log
fill 103 257 326 104 259 326 minecraft:stone
setblock 104 257 324 minecraft:stripped_spruce_log
fill 104 257 325 104 260 325 minecraft:stone
setblock 105 257 323 minecraft:stripped_spruce_log
fill 105 257 324 108 257 324 minecraft:stone
setblock 105 257 363 minecraft:stripped_spruce_log
fill 106 257 323 106 260 323 minecraft:stone
fill 106 257 327 106 257 361 minecraft:iron_bars
fill 106 257 363 109 257 363 minecraft:stone
setblock 109 257 324 minecraft:stripped_spruce_log
setblock 110 257 323 minecraft:stripped_spruce_log
fill 110 257 324 110 260 324 minecraft:stone
setblock 110 257 363 minecraft:stripped_spruce_log
fill 111 257 322 111 260 323 minecraft:stone
fill 111 257 363 114 257 363 minecraft:stone
setblock 113 257 324 minecraft:stone
fill 113 257 325 113 257 326 minecraft:iron_bars
setblock 114 257 324 minecraft:stripped_spruce_log
setblock 115 257 323 minecraft:stripped_spruce_log
fill 115 257 324 118 257 324 minecraft:stone
setblock 115 257 363 minecraft:stripped_spruce_log
fill 116 257 323 116 260 323 minecraft:stone
fill 116 257 363 119 257 363 minecraft:stone
fill 117 257 362 120 257 362 minecraft:stone
setblock 119 257 324 minecraft:stripped_spruce_log
setblock 120 257 323 minecraft:stripped_spruce_log
fill 120 257 324 120 260 324 minecraft:stone
fill 120 257 347 120 257 361 minecraft:iron_bars
setblock 120 257 363 minecraft:stripped_spruce_log
fill 121 257 322 121 258 323 minecraft:stone
fill 121 257 325 121 258 325 minecraft:stone
setblock 121 257 362 minecraft:stripped_spruce_log
fill 121 257 363 124 257 363 minecraft:stone
fill 122 257 323 124 257 323 minecraft:stone
setblock 122 257 361 minecraft:stripped_spruce_log
fill 122 257 362 125 257 362 minecraft:stone
setblock 123 257 361 minecraft:stone
setblock 124 257 324 minecraft:stripped_spruce_log
setblock 125 257 323 minecraft:stripped_spruce_log
fill 125 257 324 125 260 324 minecraft:stone
fill 125 257 335 126 257 337 minecraft:raw_gold_block
setblock 125 257 363 minecraft:stripped_spruce_log
fill 126 257 323 126 260 323 minecraft:stone
setblock 126 257 362 minecraft:stripped_spruce_log
fill 126 257 363 129 257 363 minecraft:stone
fill 127 257 329 127 257 362 minecraft:iron_bars
fill 132 257 344 133 258 344 minecraft:iron_bars
fill 134 257 323 134 257 331 minecraft:iron_bars
setblock 134 257 343 minecraft:stone
setblock 134 257 344 minecraft:stripped_spruce_log
fill 134 257 345 134 260 345 minecraft:stone
fill 134 257 347 134 257 348 minecraft:stone
setblock 135 257 343 minecraft:stripped_spruce_log
fill 135 257 344 135 260 344 minecraft:stone
setblock 135 257 348 minecraft:stripped_spruce_log
fill 135 257 349 135 260 349 minecraft:stone
fill 135 257 351 135 258 351 minecraft:stone
setblock 136 257 354 minecraft:gold_block
fill 136 257 355 136 280 358 minecraft:stone
fill 94 258 325 94 308 325 minecraft:stone
setblock 94 258 344 minecraft:gold_block
fill 94 258 358 94 261 360 minecraft:stone
setblock 94 258 361 minecraft:diamond_block
fill 94 258 362 94 264 362 minecraft:stone
fill 95 258 323 98 258 323 minecraft:stone
setblock 95 258 327 minecraft:stripped_spruce_log
fill 95 258 328 96 260 328 minecraft:stone
fill 95 258 330 95 258 331 minecraft:stone
setblock 95 258 332 minecraft:stripped_spruce_log
fill 95 258 333 95 261 333 minecraft:stone
setblock 95 258 337 minecraft:stripped_spruce_log
fill 95 258 338 95 261 338 minecraft:stone
setblock 95 258 342 minecraft:stripped_spruce_log
fill 95 258 343 95 261 343 minecraft:stone
setblock 95 258 347 minecraft:stripped_spruce_log
fill 95 258 348 96 260 348 minecraft:stone
fill 95 258 350 95 259 350 minecraft:stone
fill 96 258 324 96 258 325 minecraft:stone
setblock 96 258 326 minecraft:stripped_spruce_log
fill 96 258 327 97 260 327 minecraft:stone
fill 96 258 329 96 258 330 minecraft:stone
setblock 96 258 341 minecraft:stripped_spruce_log
fill 96 258 342 96 261 342 minecraft:stone
setblock 96 258 346 minecraft:stripped_spruce_log
fill 96 258 347 96 261 347 minecraft:stone
setblock 97 258 324 minecraft:stone
fill 97 258 326 97 261 326 minecraft:stone
setblock 98 258 324 minecraft:stripped_spruce_log
fill 98 258 325 98 261 325 minecraft:stone
setblock 99 258 323 minecraft:stripped_spruce_log
fill 99 258 324 102 258 324 minecraft:stone
setblock 99 258 363 minecraft:stripped_spruce_log
fill 100 258 323 103 258 323 minecraft:stone
setblock 100 258 326 minecraft:stone
fill 100 258 363 103 258 363 minecraft:stone
setblock 101 258 326 minecraft:stripped_spruce_log
setblock 102 258 325 minecraft:stripped_spruce_log
fill 102 258 326 102 261 326 minecraft:stone
setblock 103 258 324 minecraft:stripped_spruce_log
fill 103 258 325 103 261 325 minecraft:stone
setblock 104 258 323 minecraft:stripped_spruce_log
fill 104 258 324 107 258 324 minecraft:stone
setblock 104 258 363 minecraft:stripped_spruce_log
fill 105 258 323 105 261 323 minecraft:stone
fill 105 258 363 108 258 363 minecraft:stone
fill 106 258 355 106 258 362 minecraft:iron_bars
setblock 107 258 325 minecraft:stripped_spruce_log
setblock 108 258 324 minecraft:stripped_spruce_log
fill 108 258 325 108 261 325 minecraft:stone
setblock 109 258 323 minecraft:stripped_spruce_log
fill 109 258 324 109 261 324 minecraft:stone
setblock 109 258 363 minecraft:stripped_spruce_log
fill 110 258 323 110 261 323 minecraft:stone
fill 110 258 363 113 258 363 minecraft:stone
setblock 113 258 324 minecraft:stripped_spruce_log
setblock 114 258 323 minecraft:stripped_spruce_log
fill 114 258 324 117 258 324 minecraft:stone
setblock 114 258 363 minecraft:stripped_spruce_log
fill 115 258 323 115 261 323 minecraft:stone
fill 115 258 363 118 258 363 minecraft:stone
fill 116 258 362 119 258 362 minecraft:stone
setblock 118 258 324 minecraft:stripped_spruce_log
fill 118 258 325 120 259 325 minecraft:stone
setblock 119 258 323 minecraft:stripped_spruce_log
fill 119 258 324 119 261 324 minecraft:stone
setblock 119 258 363 minecraft:stripped_spruce_log
fill 120 258 323 120 261 323 minecraft:stone
setblock 120 258 361 minecraft:stone
setblock 120 258 362 minecraft:stripped_spruce_log
fill 120 258 363 123 258 363 minecraft:stone
setblock 121 258 361 minecraft:stripped_spruce_log
fill 121 258 362 124 258 362 minecraft:stone
fill 122 258 323 123 258 323 minecraft:stone
setblock 122 258 325 minecraft:stripped_spruce_log
fill 122 258 361 122 259 361 minecraft:stone
setblock 123 258 324 minecraft:stripped_spruce_log
setblock 124 258 323 minecraft:stripped_spruce_log
fill 124 258 324 124 261 324 minecraft:stone
setblock 124 258 363 minecraft:stripped_spruce_log
fill 125 258 323 125 261 323 minecraft:stone
fill 125 258 336 126 259 336 minecraft:raw_gold_block
setblock 125 258 362 minecraft:stripped_spruce_log
fill 125 258 363 128 258 363 minecraft:stone
setblock 126 258 335 minecraft:raw_gold_block
setblock 126 258 362 minecraft:stone
setblock 134 258 343 minecraft:stripped_spruce_log
fill 134 258 344 134 261 344 minecraft:stone
setblock 134 258 347 minecraft:stone
setblock 134 258 348 minecraft:stripped_spruce_log
fill 134 258 349 134 261 349 minecraft:stone
fill 135 258 339 135 260 339 minecraft:stone
setblock 135 258 342 minecraft:stripped_spruce_log
fill 135 258 343 135 261 343 minecraft:stone
setblock 135 258 347 minecraft:stripped_spruce_log
fill 135 258 348 135 261 348 minecraft:stone
setblock 135 258 352 minecraft:stripped_spruce_log
fill 136 258 354 136 260 354 minecraft:stone
fill 94 259 344 94 308 344 minecraft:stone
fill 94 259 361 94 308 361 minecraft:stone
fill 94 259 364 95 291 364 minecraft:stone
fill 95 259 323 97 259 323 minecraft:stone
setblock 95 259 325 minecraft:stone
setblock 95 259 326 minecraft:stripped_spruce_log
fill 95 259 327 95 262 327 minecraft:stone
setblock 95 259 330 minecraft:stone
setblock 95 259 331 minecraft:stripped_spruce_log
fill 95 259 332 96 261 332 minecraft:stone
fill 95 259 334 95 259 335 minecraft:stone
setblock 95 259 336 minecraft:stripped_spruce_log
fill 95 259 337 95 262 337 minecraft:stone
setblock 95 259 341 minecraft:stripped_spruce_log
fill 95 259 342 95 262 342 minecraft:stone
setblock 95 259 346 minecraft:stripped_spruce_log
fill 95 259 347 95 262 347 minecraft:stone
setblock 95 259 351 minecraft:stripped_spruce_log
setblock 96 259 324 minecraft:stone
setblock 96 259 325 minecraft:stripped_spruce_log
fill 96 259 326 96 262 326 minecraft:stone
setblock 96 259 329 minecraft:stone
setblock 96 259 330 minecraft:stripped_spruce_log
fill 96 259 331 96 262 331 minecraft:stone
fill 96 259 333 96 260 333 minecraft:stone
setblock 96 259 340 minecraft:stripped_spruce_log
fill 96 259 341 96 262 341 minecraft:stone
setblock 96 259 345 minecraft:stripped_spruce_log
fill 96 259 346 97 261 346 minecraft:stone
setblock 96 259 349 minecraft:stone
setblock 96 259 364 minecraft:gold_block
setblock 97 259 324 minecraft:stripped_spruce_log
fill 97 259 325 97 262 325 minecraft:stone
setblock 97 259 328 minecraft:stone
setblock 97 259 329 minecraft:stripped_spruce_log
fill 97 259 330 97 262 330 minecraft:stone
setblock 97 259 332 minecraft:light[level=12]
setblock 97 259 333 minecraft:light[level=15]
setblock 97 259 339 minecraft:light[level=12]
setblock 97 259 341 minecraft:light[level=15]
setblock 97 259 344 minecraft:stripped_spruce_log
fill 97 259 345 97 262 345 minecraft:stone
setblock 97 259 349 minecraft:light[level=15]
setblock 97 259 353 minecraft:light[level=12]
setblock 97 259 357 minecraft:light[level=15]
setblock 97 259 360 minecraft:light[level=12]
setblock 97 259 363 minecraft:stone
setblock 98 259 323 minecraft:stripped_spruce_log
fill 98 259 324 101 259 324 minecraft:stone
fill 98 259 326 98 259 327 minecraft:stone
setblock 98 259 363 minecraft:stripped_spruce_log
fill 98 259 364 98 301 364 minecraft:stone
fill 99 259 323 102 259 323 minecraft:stone
setblock 99 259 326 minecraft:stone
fill 99 259 363 102 259 363 minecraft:stone
setblock 100 259 326 minecraft:stripped_spruce_log
setblock 101 259 325 minecraft:stripped_spruce_log
fill 101 259 326 101 262 326 minecraft:stone
setblock 102 259 324 minecraft:stripped_spruce_log
fill 102 259 325 102 262 325 minecraft:stone
setblock 103 259 323 minecraft:stripped_spruce_log
fill 103 259 324 106 259 324 minecraft:stone
setblock 103 259 363 minecraft:stripped_spruce_log
fill 104 259 323 104 262 323 minecraft:stone
setblock 104 259 332 minecraft:light[level=12]
setblock 104 259 339 minecraft:light[level=12]
setblock 104 259 346 minecraft:light[level=12]
setblock 104 259 353 minecraft:light[level=12]
setblock 104 259 360 minecraft:light[level=12]
fill 104 259 363 107 259 363 minecraft:stone
setblock 105 259 326 minecraft:stripped_spruce_log
setblock 105 259 333 minecraft:light[level=15]
setblock 105 259 341 minecraft:light[level=15]
setblock 105 259 349 minecraft:light[level=15]
setblock 105 259 357 minecraft:light[level=15]
setblock 106 259 325 minecraft:stripped_spruce_log
setblock 107 259 324 minecraft:stripped_spruce_log
fill 107 259 325 107 262 325 minecraft:stone
setblock 108 259 323 minecraft:stripped_spruce_log
fill 108 259 324 108 262 324 minecraft:stone
setblock 108 259 363 minecraft:stripped_spruce_log
fill 109 259 323 109 262 323 minecraft:stone
fill 109 259 363 112 259 363 minecraft:stone
setblock 111 259 325 minecraft:light[level=12]
setblock 111 259 332 minecraft:light[level=12]
setblock 111 259 339 minecraft:light[level=12]
setblock 111 259 346 minecraft:light[level=12]
setblock 111 259 353 minecraft:light[level=12]
setblock 111 259 360 minecraft:light[level=12]
setblock 112 259 324 minecraft:stripped_spruce_log
fill 112 259 360 112 260 362 minecraft:iron_bars
setblock 113 259 323 minecraft:stripped_spruce_log
fill 113 259 324 116 259 324 minecraft:stone
setblock 113 259 325 minecraft:light[level=15]
setblock 113 259 333 minecraft:light[level=15]
setblock 113 259 341 minecraft:light[level=15]
setblock 113 259 349 minecraft:light[level=15]
setblock 113 259 357 minecraft:light[level=15]
setblock 113 259 363 minecraft:stripped_spruce_log
fill 114 259 323 114 262 323 minecraft:stone
fill 114 259 363 117 259 363 minecraft:stone
fill 116 259 362 118 259 362 minecraft:stone
setblock 116 259 364 minecraft:raw_gold_block
setblock 117 259 324 minecraft:stripped_spruce_log
fill 117 259 325 117 262 325 minecraft:stone
fill 117 259 364 118 282 364 minecraft:stone
setblock 118 259 322 minecraft:raw_gold_block
setblock 118 259 323 minecraft:stripped_spruce_log
fill 118 259 324 118 262 324 minecraft:stone
setblock 118 259 332 minecraft:light[level=12]
setblock 118 259 339 minecraft:light[level=12]
setblock 118 259 346 minecraft:light[level=12]
setblock 118 259 353 minecraft:light[level=12]
setblock 118 259 360 minecraft:light[level=12]
setblock 118 259 363 minecraft:stripped_spruce_log
fill 119 259 322 119 262 323 minecraft:stone
setblock 119 259 362 minecraft:stripped_spruce_log
fill 119 259 363 122 259 363 minecraft:stone
fill 120 259 322 120 276 322 minecraft:stone
setblock 120 259 361 minecraft:stripped_spruce_log
fill 120 259 362 123 259 362 minecraft:stone
setblock 121 259 322 minecraft:raw_gold_block
fill 121 259 323 122 259 323 minecraft:stone
setblock 121 259 325 minecraft:stripped_spruce_log
setblock 121 259 333 minecraft:light[level=15]
setblock 121 259 341 minecraft:light[level=15]
setblock 121 259 349 minecraft:light[level=15]
setblock 121 259 357 minecraft:light[level=15]
fill 121 259 361 121 261 361 minecraft:stone
setblock 122 259 324 minecraft:stripped_spruce_log
fill 122 259 325 122 261 325 minecraft:stone
setblock 123 259 323 minecraft:stripped_spruce_log
fill 123 259 324 123 262 324 minecraft:stone
setblock 123 259 363 minecraft:stripped_spruce_log
fill 124 259 323 124 262 323 minecraft:stone
setblock 124 259 362 minecraft:stripped_spruce_log
fill 124 259 363 127 259 363 minecraft:stone
setblock 125 259 325 minecraft:light[level=12]
setblock 125 259 332 minecraft:light[level=12]
setblock 125 259 339 minecraft:light[level=12]
setblock 125 259 346 minecraft:light[level=12]
setblock 125 259 353 minecraft:light[level=12]
setblock 125 259 360 minecraft:light[level=12]
fill 125 259 362 125 260 362 minecraft:stone
setblock 128 259 363 minecraft:stripped_spruce_log
setblock 129 259 325 minecraft:light[level=15]
setblock 129 259 333 minecraft:light[level=15]
setblock 129 259 341 minecraft:light[level=15]
setblock 129 259 349 minecraft:light[level=15]
setblock 129 259 357 minecraft:light[level=15]
setblock 132 259 325 minecraft:light[level=12]
setblock 132 259 332 minecraft:light[level=12]
setblock 132 259 339 minecraft:light[level=12]
setblock 132 259 346 minecraft:light[level=12]
setblock 132 259 353 minecraft:light[level=12]
setblock 132 259 360 minecraft:light[level=12]
setblock 134 259 342 minecraft:stripped_spruce_log
setblock 134 259 343 minecraft:stone
setblock 134 259 347 minecraft:stripped_spruce_log
fill 134 259 348 134 262 348 minecraft:stone
fill 134 259 350 134 259 351 minecraft:stone
fill 135 259 323 135 259 325 minecraft:stone
setblock 135 259 326 minecraft:stripped_spruce_log
fill 135 259 327 135 259 330 minecraft:stone
fill 135 259 338 135 261 338 minecraft:stone
setblock 135 259 341 minecraft:stripped_spruce_log
fill 135 259 342 135 262 342 minecraft:stone
setblock 135 259 346 minecraft:stripped_spruce_log
fill 135 259 347 135 262 347 minecraft:stone
setblock 135 259 351 minecraft:stripped_spruce_log
fill 135 259 352 135 261 353 minecraft:stone
fill 95 260 323 96 260 323 minecraft:stone
setblock 95 260 325 minecraft:stripped_spruce_log
fill 95 260 326 95 263 326 minecraft:stone
setblock 95 260 330 minecraft:stripped_spruce_log
fill 95 260 331 95 263 331 minecraft:stone
setblock 95 260 334 minecraft:stone
setblock 95 260 335 minecraft:stripped_spruce_log
fill 95 260 336 96 262 336 minecraft:stone
setblock 95 260 340 minecraft:stripped_spruce_log
fill 95 260 341 95 263 341 minecraft:stone
setblock 95 260 345 minecraft:stripped_spruce_log
fill 95 260 346 95 263 346 minecraft:stone
setblock 95 260 350 minecraft:stripped_spruce_log
fill 95 260 351 95 261 353 minecraft:stone
fill 96 260 324 96 263 324 minecraft:spruce_log
fill 96 260 325 96 263 325 minecraft:stone
setblock 96 260 329 minecraft:stripped_spruce_log
fill 96 260 330 96 263 330 minecraft:stone
setblock 96 260 334 minecraft:stripped_spruce_log
fill 96 260 335 96 263 335 minecraft:stone
fill 96 260 337 96 260 338 minecraft:stone
setblock 96 260 339 minecraft:stripped_spruce_log
fill 96 260 340 96 263 340 minecraft:stone
fill 96 260 343 96 263 343 minecraft:spruce_log
setblock 96 260 344 minecraft:stripped_spruce_log
fill 96 260 345 96 263 345 minecraft:stone
setblock 96 260 349 minecraft:stripped_spruce_log
fill 96 260 350 96 262 351 minecraft:stone
fill 96 260 362 96 263 362 minecraft:spruce_log
fill 96 260 364 96 288 364 minecraft:stone
setblock 97 260 323 minecraft:stripped_spruce_log
fill 97 260 324 100 260 324 minecraft:stone
setblock 97 260 328 minecraft:stripped_spruce_log
fill 97 260 329 98 262 329 minecraft:stone
fill 97 260 331 97 260 332 minecraft:stone
setblock 97 260 343 minecraft:stripped_spruce_log
fill 97 260 344 97 262 344 minecraft:stone
setblock 97 260 347 minecraft:stone
setblock 97 260 348 minecraft:stripped_spruce_log
setblock 97 260 363 minecraft:stripped_spruce_log
fill 98 260 323 101 260 323 minecraft:stone
setblock 98 260 326 minecraft:stone
setblock 98 260 327 minecraft:stripped_spruce_log
fill 98 260 328 98 263 328 minecraft:stone
fill 98 260 330 98 261 330 minecraft:stone
fill 98 260 363 101 260 363 minecraft:stone
setblock 99 260 326 minecraft:stripped_spruce_log
setblock 99 260 364 minecraft:raw_iron_block
setblock 100 260 325 minecraft:stripped_spruce_log
fill 100 260 326 100 263 326 minecraft:stone
fill 100 260 364 101 265 364 minecraft:stone
setblock 101 260 324 minecraft:stripped_spruce_log
fill 101 260 325 101 263 325 minecraft:stone
fill 101 260 327 101 261 327 minecraft:stone
setblock 102 260 323 minecraft:stripped_spruce_log
fill 102 260 324 105 260 324 minecraft:stone
setblock 102 260 363 minecraft:stripped_spruce_log
fill 103 260 323 103 263 323 minecraft:stone
setblock 103 260 326 minecraft:stone
fill 103 260 363 106 260 363 minecraft:stone
setblock 104 260 326 minecraft:stripped_spruce_log
setblock 105 260 325 minecraft:stripped_spruce_log
fill 105 260 326 105 261 326 minecraft:stone
setblock 106 260 324 minecraft:stripped_spruce_log
fill 106 260 325 106 263 325 minecraft:stone
setblock 107 260 323 minecraft:stripped_spruce_log
fill 107 260 324 107 263 324 minecraft:stone
setblock 107 260 363 minecraft:stripped_spruce_log
fill 108 260 323 108 263 323 minecraft:stone
fill 108 260 363 111 260 363 minecraft:stone
setblock 111 260 324 minecraft:stripped_spruce_log
fill 112 260 322 112 308 322 minecraft:stone
setblock 112 260 323 minecraft:stripped_spruce_log
fill 112 260 324 114 261 324 minecraft:stone
setblock 112 260 363 minecraft:stripped_spruce_log
fill 113 260 323 113 263 323 minecraft:stone
fill 113 260 363 116 260 363 minecraft:stone
fill 115 260 324 115 263 324 minecraft:spruce_log
setblock 115 260 325 minecraft:stripped_spruce_log
fill 115 260 362 115 263 362 minecraft:spruce_log
setblock 116 260 324 minecraft:stripped_spruce_log
fill 116 260 325 116 263 325 minecraft:stone
fill 116 260 362 117 260 362 minecraft:stone
fill 116 260 364 116 308 364 minecraft:stone
setblock 117 260 323 minecraft:stripped_spruce_log
fill 117 260 324 117 263 324 minecraft:stone
setblock 117 260 363 minecraft:stripped_spruce_log
fill 118 260 322 118 263 323 minecraft:stone
fill 118 260 325 119 260 325 minecraft:stone
setblock 118 260 362 minecraft:stripped_spruce_log
fill 118 260 363 121 260 363 minecraft:stone
setblock 119 260 361 minecraft:stripped_spruce_log
fill 119 260 362 122 260 362 minecraft:stone
setblock 120 260 325 minecraft:stripped_spruce_log
fill 120 260 361 120 263 361 minecraft:stone
fill 121 260 322 121 260 323 minecraft:stone
setblock 121 260 324 minecraft:stripped_spruce_log
fill 121 260 325 121 262 325 minecraft:stone
setblock 122 260 323 minecraft:stripped_spruce_log
fill 122 260 324 122 263 324 minecraft:stone
setblock 122 260 363 minecraft:stripped_spruce_log
fill 123 260 323 123 263 323 minecraft:stone
setblock 123 260 362 minecraft:stripped_spruce_log
fill 123 260 363 126 260 363 minecraft:stone
fill 124 260 362 124 261 362 minecraft:stone
setblock 126 260 336 minecraft:raw_gold_block
setblock 127 260 323 minecraft:stripped_spruce_log
setblock 127 260 363 minecraft:stripped_spruce_log
setblock 131 260 322 minecraft:raw_gold_block
setblock 133 260 346 minecraft:stone
setblock 133 260 347 minecraft:stripped_spruce_log
fill 133 260 348 133 262 349 minecraft:stone
fill 134 260 324 134 263 324 minecraft:spruce_log
fill 134 260 342 134 263 342 minecraft:stone
fill 134 260 343 134 263 343 minecraft:spruce_log
setblock 134 260 346 minecraft:stripped_spruce_log
fill 134 260 347 134 263 347 minecraft:stone
setblock 134 260 350 minecraft:stone
setblock 134 260 351 minecraft:stripped_spruce_log
fill 134 260 352 134 263 352 minecraft:stone
fill 134 260 362 134 263 362 minecraft:spruce_log
fill 135 260 323 135 260 324 minecraft:stone
setblock 135 260 325 minecraft:stripped_spruce_log
fill 135 260 326 135 260 329 minecraft:stone
setblock 135 260 330 minecraft:stripped_spruce_log
fill 135 260 331 135 260 334 minecraft:stone
setblock 135 260 335 minecraft:stripped_spruce_log
fill 135 260 336 135 262 337 minecraft:stone
setblock 135 260 340 minecraft:stripped_spruce_log
fill 135 260 341 135 263 341 minecraft:stone
setblock 135 260 345 minecraft:stripped_spruce_log
fill 135 260 346 135 263 346 minecraft:stone
setblock 135 260 350 minecraft:stripped_spruce_log
fill 135 260 351 135 263 351 minecraft:stone
setblock 135 260 354 minecraft:stone
setblock 135 260 355 minecraft:stripped_spruce_log
fill 94 261 324 94 308 324 minecraft:stone
setblock 95 261 323 minecraft:stone
setblock 95 261 324 minecraft:stripped_spruce_log
fill 95 261 325 95 264 325 minecraft:stone
setblock 95 261 328 minecraft:stone
setblock 95 261 329 minecraft:stripped_spruce_log
fill 95 261 330 95 264 330 minecraft:stone
setblock 95 261 334 minecraft:stripped_spruce_log
fill 95 261 335 95 264 335 minecraft:stone
setblock 95 261 339 minecraft:stripped_spruce_log
fill 95 261 340 95 264 340 minecraft:stone
setblock 95 261 344 minecraft:stripped_spruce_log
fill 95 261 345 95 264 345 minecraft:stone
setblock 95 261 348 minecraft:stone
setblock 95 261 349 minecraft:stripped_spruce_log
fill 95 261 350 95 264 350 minecraft:stone
setblock 95 261 354 minecraft:stripped_spruce_log
setblock 96 261 323 minecraft:stripped_spruce_log
setblock 96 261 327 minecraft:stone
setblock 96 261 328 minecraft:stripped_spruce_log
fill 96 261 329 96 264 329 minecraft:stone
setblock 96 261 333 minecraft:stripped_spruce_log
fill 96 261 334 97 263 334 minecraft:stone
setblock 96 261 337 minecraft:stone
setblock 96 261 338 minecraft:stripped_spruce_log
fill 96 261 339 96 264 339 minecraft:stone
fill 96 261 344 96 264 344 minecraft:stone
setblock 96 261 348 minecraft:stripped_spruce_log
fill 96 261 349 97 263 349 minecraft:stone
setblock 96 261 352 minecraft:stone
setblock 96 261 363 minecraft:stripped_spruce_log
fill 97 261 323 99 261 324 minecraft:stone
setblock 97 261 327 minecraft:stripped_spruce_log
fill 97 261 328 97 264 328 minecraft:stone
setblock 97 261 331 minecraft:stone
setblock 97 261 332 minecraft:stripped_spruce_log
fill 97 261 333 97 264 333 minecraft:stone
setblock 97 261 343 minecraft:stone
setblock 97 261 347 minecraft:stripped_spruce_log
fill 97 261 348 97 264 348 minecraft:stone
fill 97 261 363 100 261 363 minecraft:stone
setblock 98 261 326 minecraft:stripped_spruce_log
fill 98 261 327 100 262 327 minecraft:stone
setblock 98 261 331 minecraft:stripped_spruce_log
fill 98 261 332 98 264 332 minecraft:stone
setblock 99 261 325 minecraft:stripped_spruce_log
fill 99 261 326 99 264 326 minecraft:stone
fill 99 261 328 99 261 329 minecraft:stone
fill 99 261 364 99 308 364 minecraft:stone
setblock 100 261 323 minecraft:stone
setblock 100 261 324 minecraft:stripped_spruce_log
fill 100 261 325 100 264 325 minecraft:stone
setblock 101 261 323 minecraft:stripped_spruce_log
fill 101 261 324 104 261 324 minecraft:stone
setblock 101 261 363 minecraft:stripped_spruce_log
fill 102 261 323 102 264 323 minecraft:stone
setblock 102 261 327 minecraft:stripped_spruce_log
fill 102 261 363 105 261 363 minecraft:stone
setblock 103 261 326 minecraft:stripped_spruce_log
setblock 104 261 325 minecraft:stripped_spruce_log
fill 104 261 326 104 263 326 minecraft:stone
setblock 105 261 324 minecraft:stripped_spruce_log
fill 105 261 325 105 264 325 minecraft:stone
setblock 106 261 323 minecraft:stripped_spruce_log
fill 106 261 324 106 264 324 minecraft:stone
setblock 106 261 363 minecraft:stripped_spruce_log
fill 107 261 323 107 264 323 minecraft:stone
fill 107 261 363 110 261 363 minecraft:stone
setblock 110 261 324 minecraft:stripped_spruce_log
fill 111 261 322 111 308 322 minecraft:stone
setblock 111 261 323 minecraft:stripped_spruce_log
fill 111 261 324 111 264 324 minecraft:stone
setblock 111 261 363 minecraft:stripped_spruce_log
fill 112 261 323 112 264 323 minecraft:stone
fill 112 261 363 115 261 363 minecraft:stone
setblock 114 261 325 minecraft:stripped_spruce_log
fill 114 261 362 114 263 362 minecraft:stone
fill 115 261 325 115 264 325 minecraft:stone
setblock 116 261 323 minecraft:stripped_spruce_log
fill 116 261 324 116 264 324 minecraft:stone
setblock 116 261 362 minecraft:stone
setblock 116 261 363 minecraft:stripped_spruce_log
fill 117 261 323 117 264 323 minecraft:stone
setblock 117 261 362 minecraft:stripped_spruce_log
fill 117 261 363 120 261 363 minecraft:stone
setblock 118 261 325 minecraft:stone
setblock 118 261 361 minecraft:stripped_spruce_log
fill 118 261 362 121 261 362 minecraft:stone
setblock 119 261 325 minecraft:stripped_spruce_log
fill 119 261 361 119 263 361 minecraft:stone
setblock 119 261 364 minecraft:raw_gold_block
setblock 120 261 324 minecraft:stripped_spruce_log
fill 120 261 325 120 263 325 minecraft:stone
fill 121 261 322 121 266 322 minecraft:stone
setblock 121 261 323 minecraft:stripped_spruce_log
fill 121 261 324 121 264 324 minecraft:stone
setblock 121 261 363 minecraft:stripped_spruce_log
fill 122 261 323 122 264 323 minecraft:stone
setblock 122 261 362 minecraft:stripped_spruce_log
fill 122 261 363 125 261 363 minecraft:stone
fill 123 261 362 123 262 362 minecraft:stone
setblock 126 261 323 minecraft:stripped_spruce_log
setblock 126 261 363 minecraft:stripped_spruce_log
fill 131 261 322 131 271 322 minecraft:stone
setblock 133 261 345 minecraft:stone
setblock 133 261 346 minecraft:stripped_spruce_log
fill 133 261 347 133 264 347 minecraft:stone
setblock 133 261 350 minecraft:stone
fill 134 261 323 135 261 323 minecraft:stone
fill 134 261 327 134 261 329 minecraft:stone
fill 134 261 341 134 264 341 minecraft:stone
setblock 134 261 345 minecraft:stripped_spruce_log
fill 134 261 346 134 264 346 minecraft:stone
setblock 134 261 350 minecraft:stripped_spruce_log
fill 134 261 351 134 264 351 minecraft:stone
fill 134 261 353 134 262 353 minecraft:stone
setblock 135 261 324 minecraft:stripped_spruce_log
fill 135 261 325 135 261 328 minecraft:stone
setblock 135 261 329 minecraft:stripped_spruce_log
fill 135 261 330 135 261 333 minecraft:stone
setblock 135 261 334 minecraft:stripped_spruce_log
fill 135 261 335 135 264 335 minecraft:stone
setblock 135 261 339 minecraft:stripped_spruce_log
fill 135 261 340 135 264 340 minecraft:stone
setblock 135 261 344 minecraft:stripped_spruce_log
fill 135 261 345 135 264 345 minecraft:stone
setblock 135 261 349 minecraft:stripped_spruce_log
fill 135 261 350 135 264 350 minecraft:stone
setblock 135 261 354 minecraft:stripped_spruce_log
fill 135 261 355 135 263 356 minecraft:stone
fill 136 261 324 136 272 325 minecraft:stone
setblock 136 261 326 minecraft:diamond_block
fill 136 261 327 136 276 329 minecraft:stone
setblock 136 261 354 minecraft:gold_block
fill 94 262 332 95 262 332 minecraft:stone
setblock 94 262 333 minecraft:raw_iron_block
fill 94 262 358 94 285 359 minecraft:stone
setblock 94 262 360 minecraft:raw_gold_block
setblock 95 262 323 minecraft:stripped_spruce_log
fill 95 262 324 95 265 324 minecraft:stone
setblock 95 262 328 minecraft:stripped_spruce_log
fill 95 262 329 95 265 329 minecraft:stone
setblock 95 262 333 minecraft:stripped_spruce_log
fill 95 262 334 95 265 334 minecraft:stone
setblock 95 262 338 minecraft:stripped_spruce_log
fill 95 262 339 95 265 339 minecraft:stone
setblock 95 262 343 minecraft:stripped_spruce_log
fill 95 262 344 95 265 344 minecraft:stone
setblock 95 262 348 minecraft:stripped_spruce_log
fill 95 262 349 95 265 349 minecraft:stone
fill 95 262 351 95 262 352 minecraft:stone
setblock 95 262 353 minecraft:stripped_spruce_log
fill 95 262 354 95 264 355 minecraft:stone
fill 96 262 323 99 262 323 minecraft:stone
setblock 96 262 327 minecraft:stripped_spruce_log
fill 96 262 328 96 265 328 minecraft:stone
setblock 96 262 332 minecraft:stripped_spruce_log
fill 96 262 333 96 265 333 minecraft:stone
setblock 96 262 337 minecraft:stripped_spruce_log
fill 96 262 338 96 265 338 minecraft:stone
setblock 96 262 342 minecraft:stripped_spruce_log
setblock 96 262 346 minecraft:stone
setblock 96 262 347 minecraft:stripped_spruce_log
fill 96 262 348 96 265 348 minecraft:stone
setblock 96 262 352 minecraft:stripped_spruce_log
fill 96 262 353 96 265 353 minecraft:stone
fill 96 262 363 99 262 363 minecraft:stone
fill 97 262 324 98 262 324 minecraft:stone
setblock 97 262 326 minecraft:stripped_spruce_log
fill 97 262 327 97 265 327 minecraft:stone
setblock 97 262 331 minecraft:stripped_spruce_log
fill 97 262 332 97 265 332 minecraft:stone
setblock 97 262 335 minecraft:stone
setblock 97 262 336 minecraft:stripped_spruce_log
setblock 97 262 346 minecraft:stripped_spruce_log
fill 97 262 347 97 264 347 minecraft:stone
setblock 97 262 350 minecraft:stone
setblock 97 262 351 minecraft:stripped_spruce_log
setblock 98 262 325 minecraft:stripped_spruce_log
fill 98 262 326 98 265 326 minecraft:stone
setblock 98 262 330 minecraft:stripped_spruce_log
fill 98 262 331 98 265 331 minecraft:stone
fill 98 262 333 98 263 333 minecraft:stone
setblock 99 262 324 minecraft:stripped_spruce_log
fill 99 262 325 99 265 325 minecraft:stone
setblock 99 262 328 minecraft:stone
setblock 99 262 329 minecraft:stripped_spruce_log
fill 99 262 330 99 265 330 minecraft:stone
setblock 100 262 323 minecraft:stripped_spruce_log
fill 100 262 324 103 262 324 minecraft:stone
setblock 100 262 363 minecraft:stripped_spruce_log
fill 101 262 323 101 265 323 minecraft:stone
setblock 101 262 327 minecraft:stripped_spruce_log
fill 101 262 363 104 262 363 minecraft:stone
setblock 102 262 326 minecraft:stripped_spruce_log
setblock 102 262 327 minecraft:stone
setblock 103 262 325 minecraft:stripped_spruce_log
fill 103 262 326 103 263 326 minecraft:stone
setblock 104 262 324 minecraft:stripped_spruce_log
fill 104 262 325 104 264 325 minecraft:stone
setblock 105 262 323 minecraft:stripped_spruce_log
fill 105 262 324 105 265 324 minecraft:stone
setblock 105 262 363 minecraft:stripped_spruce_log
fill 106 262 323 106 265 323 minecraft:stone
fill 106 262 363 109 262 363 minecraft:stone
setblock 109 262 324 minecraft:stripped_spruce_log
setblock 110 262 323 minecraft:stripped_spruce_log
fill 110 262 324 110 264 324 minecraft:stone
setblock 110 262 363 minecraft:stripped_spruce_log
fill 111 262 323 111 265 323 minecraft:stone
fill 111 262 363 114 262 363 minecraft:stone
fill 112 262 324 113 262 324 minecraft:stone
setblock 114 262 324 minecraft:stripped_spruce_log
fill 114 262 325 114 263 325 minecraft:stone
setblock 115 262 323 minecraft:stripped_spruce_log
setblock 115 262 363 minecraft:stripped_spruce_log
fill 116 262 323 116 265 323 minecraft:stone
setblock 116 262 362 minecraft:stripped_spruce_log
fill 116 262 363 119 262 363 minecraft:stone
fill 117 262 362 120 262 362 minecraft:stone
setblock 118 262 325 minecraft:stripped_spruce_log
fill 118 262 361 118 264 361 minecraft:stone
setblock 119 262 324 minecraft:stripped_spruce_log
fill 119 262 325 119 264 325 minecraft:stone
fill 119 262 364 119 308 364 minecraft:stone
setblock 120 262 323 minecraft:stripped_spruce_log
fill 120 262 324 120 265 324 minecraft:stone
setblock 120 262 363 minecraft:stripped_spruce_log
fill 121 262 323 121 265 323 minecraft:stone
setblock 121 262 362 minecraft:stripped_spruce_log
fill 121 262 363 124 262 363 minecraft:stone
fill 122 262 362 122 263 362 minecraft:stone
setblock 124 262 324 minecraft:stripped_spruce_log
setblock 125 262 323 minecraft:stripped_spruce_log
setblock 125 262 363 minecraft:stripped_spruce_log
setblock 126 262 323 minecraft:stone
setblock 126 262 363 minecraft:stone
fill 127 262 364 128 299 364 minecraft:stone
setblock 128 262 322 minecraft:gold_block
fill 129 262 322 129 305 322 minecraft:stone
setblock 129 262 364 minecraft:raw_gold_block
fill 130 262 364 133 308 364 minecraft:stone
setblock 133 262 345 minecraft:stripped_spruce_log
fill 133 262 346 133 264 346 minecraft:stone
setblock 133 262 350 minecraft:stripped_spruce_log
fill 133 262 351 133 265 351 minecraft:stone
setblock 134 262 323 minecraft:stone
fill 134 262 326 134 262 328 minecraft:stone
setblock 134 262 329 minecraft:stripped_spruce_log
fill 134 262 330 134 262 333 minecraft:stone
setblock 134 262 344 minecraft:stripped_spruce_log
fill 134 262 345 134 265 345 minecraft:stone
setblock 134 262 349 minecraft:stripped_spruce_log
fill 134 262 350 134 265 350 minecraft:stone
setblock 134 262 354 minecraft:stripped_spruce_log
setblock 135 262 323 minecraft:stripped_spruce_log
fill 135 262 324 135 262 327 minecraft:stone
setblock 135 262 328 minecraft:stripped_spruce_log
fill 135 262 329 135 262 332 minecraft:stone
setblock 135 262 333 minecraft:stripped_spruce_log
fill 135 262 334 136 265 334 minecraft:stone
setblock 135 262 338 minecraft:stripped_spruce_log
fill 135 262 339 135 265 339 minecraft:stone
setblock 135 262 343 minecraft:stripped_spruce_log
fill 135 262 344 135 265 344 minecraft:stone
setblock 135 262 348 minecraft:stripped_spruce_log
fill 135 262 349 135 265 349 minecraft:stone
setblock 135 262 352 minecraft:stone
setblock 135 262 353 minecraft:stripped_spruce_log
fill 135 262 354 136 265 354 minecraft:stone
setblock 135 262 357 minecraft:stone
fill 136 262 326 136 272 326 minecraft:stone
setblock 136 262 333 minecraft:raw_gold_block
fill 136 262 335 136 308 335 minecraft:stone
setblock 136 262 353 minecraft:raw_iron_block
fill 94 263 332 94 308 333 minecraft:stone
fill 94 263 360 94 272 360 minecraft:stone
fill 95 263 323 98 263 323 minecraft:stone
setblock 95 263 327 minecraft:stripped_spruce_log
fill 95 263 328 95 265 328 minecraft:stone
setblock 95 263 332 minecraft:stripped_spruce_log
fill 95 263 333 95 265 333 minecraft:stone
setblock 95 263 336 minecraft:stone
setblock 95 263 337 minecraft:stripped_spruce_log
fill 95 263 338 95 265 338 minecraft:stone
setblock 95 263 342 minecraft:stripped_spruce_log
fill 95 263 343 95 265 343 minecraft:stone
setblock 95 263 347 minecraft:stripped_spruce_log
fill 95 263 348 95 265 348 minecraft:stone
setblock 95 263 351 minecraft:stone
setblock 95 263 352 minecraft:stripped_spruce_log
fill 95 263 353 95 265 353 minecraft:stone
setblock 95 263 356 minecraft:stone
setblock 96 263 326 minecraft:stripped_spruce_log
fill 96 263 327 96 265 327 minecraft:stone
setblock 96 263 331 minecraft:stripped_spruce_log
fill 96 263 332 96 265 332 minecraft:stone
setblock 96 263 336 minecraft:stripped_spruce_log
fill 96 263 337 96 265 337 minecraft:stone
setblock 96 263 341 minecraft:stripped_spruce_log
fill 96 263 342 96 264 342 minecraft:stone
setblock 96 263 346 minecraft:stripped_spruce_log
fill 96 263 347 96 265 347 minecraft:stone
setblock 96 263 350 minecraft:stone
setblock 96 263 351 minecraft:stripped_spruce_log
fill 96 263 352 96 265 352 minecraft:stone
fill 96 263 354 96 264 354 minecraft:stone
fill 96 263 363 98 263 363 minecraft:stone
setblock 97 263 324 minecraft:stone
setblock 97 263 325 minecraft:stripped_spruce_log
fill 97 263 326 97 266 326 minecraft:stone
setblock 97 263 329 minecraft:stone
setblock 97 263 330 minecraft:stripped_spruce_log
fill 97 263 331 97 266 331 minecraft:stone
setblock 97 263 335 minecraft:stripped_spruce_log
fill 97 263 336 97 266 336 minecraft:stone
setblock 97 263 345 minecraft:stripped_spruce_log
setblock 97 263 346 minecraft:stone
setblock 97 263 350 minecraft:stripped_spruce_log
fill 97 263 351 97 265 351 minecraft:stone
setblock 98 263 324 minecraft:stripped_spruce_log
fill 98 263 325 98 266 325 minecraft:stone
fill 98 263 327 99 263 327 minecraft:stone
setblock 98 263 329 minecraft:stripped_spruce_log
fill 98 263 330 98 266 330 minecraft:stone
setblock 98 263 334 minecraft:stripped_spruce_log
setblock 99 263 323 minecraft:stripped_spruce_log
fill 99 263 324 102 263 324 minecraft:stone
setblock 99 263 328 minecraft:stripped_spruce_log
fill 99 263 329 99 265 329 minecraft:stone
fill 99 263 331 99 264 331 minecraft:stone
setblock 99 263 363 minecraft:stripped_spruce_log
fill 100 263 323 100 265 323 minecraft:stone
setblock 100 263 327 minecraft:stripped_spruce_log
fill 100 263 363 103 263 363 minecraft:stone
setblock 101 263 322 minecraft:raw_iron_block
setblock 101 263 326 minecraft:stripped_spruce_log
setblock 101 263 327 minecraft:stone
setblock 102 263 325 minecraft:stripped_spruce_log
fill 102 263 326 102 264 326 minecraft:stone
setblock 103 263 324 minecraft:stripped_spruce_log
fill 103 263 325 103 265 325 minecraft:stone
setblock 104 263 323 minecraft:stripped_spruce_log
fill 104 263 324 104 265 324 minecraft:stone
setblock 104 263 363 minecraft:stripped_spruce_log
fill 105 263 323 105 265 323 minecraft:stone
fill 105 263 363 108 263 363 minecraft:stone
setblock 108 263 324 minecraft:stripped_spruce_log
setblock 109 263 323 minecraft:stripped_spruce_log
fill 109 263 324 109 264 324 minecraft:stone
setblock 109 263 363 minecraft:stripped_spruce_log
fill 110 263 323 110 265 323 minecraft:stone
fill 110 263 363 113 263 363 minecraft:stone
setblock 112 263 324 minecraft:stone
setblock 113 263 324 minecraft:stripped_spruce_log
setblock 114 263 323 minecraft:stripped_spruce_log
fill 114 263 324 114 265 324 minecraft:stone
setblock 114 263 363 minecraft:stripped_spruce_log
fill 115 263 323 115 265 323 minecraft:stone
fill 115 263 363 118 263 363 minecraft:stone
fill 116 263 362 119 263 362 minecraft:stone
setblock 117 263 325 minecraft:stripped_spruce_log
fill 117 263 361 117 264 361 minecraft:stone
setblock 118 263 324 minecraft:stripped_spruce_log
fill 118 263 325 118 264 325 minecraft:stone
fill 119 263 322 119 308 322 minecraft:stone
setblock 119 263 323 minecraft:stripped_spruce_log
fill 119 263 324 119 265 324 minecraft:stone
setblock 119 263 363 minecraft:stripped_spruce_log
fill 120 263 323 120 265 323 minecraft:stone
setblock 120 263 362 minecraft:stripped_spruce_log
fill 120 263 363 123 263 363 minecraft:stone
fill 121 263 362 121 264 362 minecraft:stone
setblock 123 263 324 minecraft:stripped_spruce_log
setblock 124 263 323 minecraft:stripped_spruce_log
setblock 124 263 363 minecraft:stripped_spruce_log
setblock 125 263 363 minecraft:stone
setblock 125 263 364 minecraft:raw_iron_block
fill 128 263 322 128 265 322 minecraft:stone
fill 129 263 364 129 308 364 minecraft:stone
setblock 133 263 345 minecraft:stone
setblock 133 263 348 minecraft:stone
setblock 133 263 349 minecraft:stripped_spruce_log
fill 133 263 350 133 266 350 minecraft:stone
fill 133 263 352 133 264 352 minecraft:stone
setblock 134 263 323 minecraft:stripped_spruce_log
fill 134 263 325 134 263 327 minecraft:stone
setblock 134 263 328 minecraft:stripped_spruce_log
fill 134 263 329 134 263 332 minecraft:stone
setblock 134 263 333 minecraft:stripped_spruce_log
fill 134 263 334 134 264 336 minecraft:stone
fill 134 263 340 134 265 340 minecraft:stone
fill 134 263 344 134 265 344 minecraft:stone
setblock 134 263 348 minecraft:stripped_spruce_log
fill 134 263 349 134 265 349 minecraft:stone
setblock 134 263 353 minecraft:stripped_spruce_log
fill 134 263 354 134 265 355 minecraft:stone
fill 135 263 323 135 263 326 minecraft:stone
setblock 135 263 327 minecraft:stripped_spruce_log
fill 135 263 328 135 263 331 minecraft:stone
setblock 135 263 332 minecraft:stripped_spruce_log
fill 135 263 333 136 265 333 minecraft:stone
setblock 135 263 336 minecraft:stone
setblock 135 263 337 minecraft:stripped_spruce_log
fill 135 263 338 135 265 338 minecraft:stone
setblock 135 263 342 minecraft:stripped_spruce_log
fill 135 263 343 135 265 343 minecraft:stone
setblock 135 263 347 minecraft:stripped_spruce_log
fill 135 263 348 135 265 348 minecraft:stone
setblock 135 263 352 minecraft:stripped_spruce_log
fill 135 263 353 136 265 353 minecraft:stone
setblock 135 263 357 minecraft:stripped_spruce_log
fill 135 263 358 135 265 358 minecraft:stone
fill 94 264 326 94 308 326 minecraft:stone
setblock 94 264 327 minecraft:gold_block
fill 94 264 328 94 275 330 minecraft:stone
setblock 94 264 356 minecraft:raw_gold_block
fill 94 264 357 95 265 357 minecraft:stone
fill 95 264 323 97 264 323 minecraft:stone
setblock 95 264 326 minecraft:stripped_spruce_log
fill 95 264 327 95 265 327 minecraft:stone
setblock 95 264 331 minecraft:stripped_spruce_log
fill 95 264 332 95 265 332 minecraft:stone
setblock 95 264 336 minecraft:stripped_spruce_log
fill 95 264 337 95 265 337 minecraft:stone
setblock 95 264 341 minecraft:stripped_spruce_log
fill 95 264 342 95 265 342 minecraft:stone
setblock 95 264 346 minecraft:stripped_spruce_log
fill 95 264 347 95 265 347 minecraft:stone
setblock 95 264 351 minecraft:stripped_spruce_log
fill 95 264 352 95 265 352 minecraft:stone
setblock 95 264 356 minecraft:stripped_spruce_log
setblock 96 264 324 minecraft:glowstone
setblock 96 264 325 minecraft:stripped_spruce_log
fill 96 264 326 96 265 326 minecraft:stone
setblock 96 264 330 minecraft:stripped_spruce_log
fill 96 264 331 96 265 331 minecraft:stone
setblock 96 264 334 minecraft:stone
setblock 96 264 335 minecraft:stripped_spruce_log
fill 96 264 336 96 265 336 minecraft:stone
setblock 96 264 340 minecraft:stripped_spruce_log
fill 96 264 341 96 265 341 minecraft:stone
setblock 96 264 343 minecraft:glowstone
setblock 96 264 345 minecraft:stripped_spruce_log
fill 96 264 346 96 265 346 minecraft:stone
setblock 96 264 349 minecraft:stone
setblock 96 264 350 minecraft:stripped_spruce_log
fill 96 264 351 96 265 351 minecraft:stone
setblock 96 264 355 minecraft:stripped_spruce_log
setblock 96 264 362 minecraft:glowstone
fill 96 264 363 97 264 363 minecraft:stone
setblock 97 264 324 minecraft:stripped_spruce_log
fill 97 264 325 97 267 325 minecraft:stone
setblock 97 264 329 minecraft:stripped_spruce_log
fill 97 264 330 97 267 330 minecraft:stone
setblock 97 264 334 minecraft:stripped_spruce_log
fill 97 264 335 97 267 335 minecraft:stone
setblock 97 264 337 minecraft:stone
setblock 97 264 349 minecraft:stripped_spruce_log
fill 97 264 350 97 265 350 minecraft:stone
setblock 97 264 352 minecraft:stone
setblock 98 264 323 minecraft:stripped_spruce_log
fill 98 264 324 101 264 324 minecraft:stone
setblock 98 264 327 minecraft:stone
setblock 98 264 328 minecraft:stripped_spruce_log
fill 98 264 329 98 267 329 minecraft:stone
setblock 98 264 333 minecraft:stripped_spruce_log
fill 98 264 334 98 265 334 minecraft:stone
setblock 98 264 363 minecraft:stripped_spruce_log
fill 99 264 323 99 265 323 minecraft:stone
setblock 99 264 327 minecraft:stripped_spruce_log
setblock 99 264 328 minecraft:stone
fill 99 264 363 102 264 363 minecraft:stone
setblock 100 264 326 minecraft:stripped_spruce_log
setblock 100 264 327 minecraft:stone
fill 101 264 322 101 272 322 minecraft:stone
setblock 101 264 325 minecraft:stripped_spruce_log
fill 101 264 326 101 265 326 minecraft:stone
setblock 102 264 324 minecraft:stripped_spruce_log
fill 102 264 325 102 265 325 minecraft:stone
setblock 102 264 364 minecraft:diamond_block
setblock 103 264 323 minecraft:stripped_spruce_log
fill 103 264 324 103 265 324 minecraft:stone
setblock 103 264 363 minecraft:stripped_spruce_log
fill 104 264 323 104 265 323 minecraft:stone
fill 104 264 363 105 264 363 minecraft:stone
setblock 107 264 324 minecraft:stripped_spruce_log
setblock 108 264 323 minecraft:stripped_spruce_log
setblock 108 264 324 minecraft:stone
fill 109 264 323 109 265 323 minecraft:stone
fill 110 264 363 112 264 363 minecraft:stone
setblock 112 264 324 minecraft:stripped_spruce_log
setblock 113 264 323 minecraft:stripped_spruce_log
fill 113 264 324 113 265 324 minecraft:stone
setblock 113 264 363 minecraft:stripped_spruce_log
fill 114 264 323 114 265 323 minecraft:stone
setblock 114 264 362 minecraft:stripped_spruce_log
fill 114 264 363 117 264 363 minecraft:stone
setblock 115 264 324 minecraft:glowstone
setblock 115 264 362 minecraft:glowstone
setblock 116 264 325 minecraft:stripped_spruce_log
fill 116 264 362 118 264 362 minecraft:stone
setblock 117 264 324 minecraft:stripped_spruce_log
setblock 117 264 325 minecraft:stone
fill 118 264 322 118 294 322 minecraft:stone
setblock 118 264 323 minecraft:stripped_spruce_log
fill 118 264 324 118 265 324 minecraft:stone
setblock 118 264 363 minecraft:stripped_spruce_log
fill 119 264 323 119 265 323 minecraft:stone
setblock 119 264 362 minecraft:stripped_spruce_log
fill 119 264 363 122 264 363 minecraft:stone
fill 120 264 362 120 265 362 minecraft:stone
setblock 123 264 323 minecraft:stripped_spruce_log
setblock 123 264 363 minecraft:stripped_spruce_log
setblock 124 264 363 minecraft:stone
fill 125 264 364 125 281 364 minecraft:stone
setblock 133 264 348 minecraft:stripped_spruce_log
fill 133 264 349 133 266 349 minecraft:stone
fill 134 264 323 135 265 323 minecraft:stone
setblock 134 264 324 minecraft:glowstone
fill 134 264 325 134 264 326 minecraft:stone
setblock 134 264 327 minecraft:stripped_spruce_log
fill 134 264 328 134 264 331 minecraft:stone
setblock 134 264 332 minecraft:stripped_spruce_log
fill 134 264 333 134 265 333 minecraft:stone
setblock 134 264 337 minecraft:stripped_spruce_log
fill 134 264 338 134 265 339 minecraft:stone
setblock 134 264 342 minecraft:stripped_spruce_log
setblock 134 264 343 minecraft:glowstone
setblock 134 264 347 minecraft:stripped_spruce_log
fill 134 264 348 134 265 348 minecraft:stone
setblock 134 264 352 minecraft:stripped_spruce_log
fill 134 264 353 134 265 353 minecraft:stone
setblock 134 264 362 minecraft:glowstone
fill 135 264 324 135 264 325 minecraft:stone
setblock 135 264 326 minecraft:stripped_spruce_log
fill 135 264 327 135 264 330 minecraft:stone
setblock 135 264 331 minecraft:stripped_spruce_log
fill 135 264 332 135 265 332 minecraft:stone
setblock 135 264 336 minecraft:stripped_spruce_log
fill 135 264 337 135 265 337 minecraft:stone
setblock 135 264 341 minecraft:stripped_spruce_log
fill 135 264 342 135 265 342 minecraft:stone
setblock 135 264 346 minecraft:stripped_spruce_log
fill 135 264 347 135 265 347 minecraft:stone
setblock 135 264 351 minecraft:stripped_spruce_log
fill 135 264 352 135 265 352 minecraft:stone
setblock 135 264 355 minecraft:stone
setblock 135 264 356 minecraft:stripped_spruce_log
fill 135 264 357 135 265 357 minecraft:stone
fill 94 265 327 94 308 327 minecraft:stone
fill 94 265 356 95 265 356 minecraft:stone
setblock 94 265 362 minecraft:gold_block
fill 95 265 323 96 265 323 minecraft:stone
setblock 95 265 325 minecraft:stripped_spruce_log
setblock 95 265 326 minecraft:stone
setblock 95 265 330 minecraft:stripped_spruce_log
setblock 95 265 331 minecraft:stone
setblock 95 265 335 minecraft:stripped_spruce_log
setblock 95 265 336 minecraft:stone
setblock 95 265 340 minecraft:stripped_spruce_log
setblock 95 265 341 minecraft:stone
setblock 95 265 345 minecraft:stripped_spruce_log
setblock 95 265 346 minecraft:stone
setblock 95 265 350 minecraft:stripped_spruce_log
setblock 95 265 351 minecraft:stone
setblock 95 265 354 minecraft:stone
setblock 95 265 355 minecraft:stripped_spruce_log
setblock 95 265 358 minecraft:stone
fill 96 265 324 96 266 324 minecraft:spruce_log
setblock 96 265 325 minecraft:stone
setblock 96 265 329 minecraft:stripped_spruce_log
setblock 96 265 330 minecraft:stone
setblock 96 265 334 minecraft:stripped_spruce_log
setblock 96 265 335 minecraft:stone
setblock 96 265 339 minecraft:stripped_spruce_log
setblock 96 265 340 minecraft:stone
fill 96 265 343 96 266 343 minecraft:spruce_log
setblock 96 265 344 minecraft:stripped_spruce_log
setblock 96 265 345 minecraft:stone
setblock 96 265 349 minecraft:stripped_spruce_log
setblock 96 265 350 minecraft:stone
setblock 96 265 354 minecraft:stripped_spruce_log
setblock 96 265 355 minecraft:stone
fill 96 265 362 96 266 362 minecraft:spruce_log
setblock 96 265 363 minecraft:stone
setblock 97 265 323 minecraft:stripped_spruce_log
fill 97 265 324 100 265 324 minecraft:stone
setblock 97 265 328 minecraft:stripped_spruce_log
fill 97 265 329 97 267 329 minecraft:stone
setblock 97 265 333 minecraft:stripped_spruce_log
fill 97 265 334 97 267 334 minecraft:stone
setblock 97 265 339 minecraft:light[level=12]
fill 97 265 344 97 266 344 minecraft:iron_bars
setblock 97 265 346 minecraft:light[level=12]
setblock 97 265 353 minecraft:light[level=12]
setblock 97 265 360 minecraft:light[level=12]
setblock 97 265 363 minecraft:stripped_spruce_log
setblock 98 265 323 minecraft:stone
setblock 98 265 327 minecraft:stripped_spruce_log
fill 98 265 328 98 267 328 minecraft:stone
setblock 98 265 332 minecraft:stripped_spruce_log
fill 98 265 333 98 267 333 minecraft:stone
fill 98 265 363 101 265 363 minecraft:stone
setblock 99 265 326 minecraft:stripped_spruce_log
setblock 100 265 325 minecraft:stripped_spruce_log
setblock 100 265 326 minecraft:stone
setblock 101 265 324 minecraft:stripped_spruce_log
fill 101 265 325 101 266 325 minecraft:stone
setblock 102 265 323 minecraft:stripped_spruce_log
setblock 102 265 324 minecraft:stone
setblock 102 265 363 minecraft:stripped_spruce_log
fill 102 265 364 102 308 364 minecraft:stone
setblock 103 265 323 minecraft:stone
setblock 103 265 363 minecraft:stone
setblock 104 265 325 minecraft:light[level=12]
setblock 104 265 332 minecraft:light[level=12]
setblock 104 265 339 minecraft:light[level=12]
setblock 104 265 346 minecraft:light[level=12]
setblock 104 265 353 minecraft:light[level=12]
setblock 104 265 360 minecraft:light[level=12]
fill 107 265 322 107 308 322 minecraft:stone
setblock 107 265 323 minecraft:stripped_spruce_log
setblock 108 265 322 minecraft:raw_iron_block
setblock 108 265 323 minecraft:stone
fill 109 265 322 110 272 322 minecraft:stone
fill 110 265 363 111 265 363 minecraft:stone
setblock 111 265 325 minecraft:light[level=12]
setblock 111 265 332 minecraft:light[level=12]
setblock 111 265 339 minecraft:light[level=12]
setblock 111 265 346 minecraft:light[level=12]
setblock 111 265 353 minecraft:light[level=12]
setblock 111 265 360 minecraft:light[level=12]
setblock 112 265 323 minecraft:stripped_spruce_log
setblock 112 265 363 minecraft:stripped_spruce_log
setblock 113 265 323 minecraft:stone
fill 113 265 363 116 265 363 minecraft:stone
setblock 114 265 362 minecraft:stone
fill 115 265 324 115 266 324 minecraft:spruce_log
fill 115 265 362 115 266 362 minecraft:spruce_log
setblock 116 265 324 minecraft:stripped_spruce_log
fill 116 265 362 117 265 362 minecraft:stone
setblock 117 265 323 minecraft:stripped_spruce_log
setblock 117 265 324 minecraft:stone
setblock 117 265 363 minecraft:stripped_spruce_log
setblock 118 265 323 minecraft:stone
setblock 118 265 325 minecraft:light[level=12]
setblock 118 265 332 minecraft:light[level=12]
setblock 118 265 339 minecraft:light[level=12]
setblock 118 265 346 minecraft:light[level=12]
setblock 118 265 353 minecraft:light[level=12]
setblock 118 265 360 minecraft:light[level=12]
setblock 118 265 362 minecraft:stripped_spruce_log
fill 118 265 363 121 265 363 minecraft:stone
setblock 119 265 362 minecraft:stone
setblock 122 265 323 minecraft:stripped_spruce_log
setblock 122 265 363 minecraft:stripped_spruce_log
setblock 125 265 325 minecraft:light[level=12]
setblock 125 265 332 minecraft:light[level=12]
setblock 125 265 339 minecraft:light[level=12]
setblock 125 265 346 minecraft:light[level=12]
setblock 125 265 353 minecraft:light[level=12]
setblock 125 265 360 minecraft:light[level=12]
setblock 132 265 325 minecraft:light[level=12]
setblock 132 265 332 minecraft:light[level=12]
setblock 132 265 339 minecraft:light[level=12]
setblock 132 265 346 minecraft:light[level=12]
setblock 132 265 353 minecraft:light[level=12]
setblock 132 265 360 minecraft:light[level=12]
setblock 133 265 331 minecraft:stone
setblock 133 265 347 minecraft:stripped_spruce_log
fill 133 265 348 133 266 348 minecraft:stone
setblock 133 265 352 minecraft:stripped_spruce_log
fill 134 265 324 134 266 324 minecraft:spruce_log
setblock 134 265 326 minecraft:stripped_spruce_log
fill 134 265 327 134 265 330 minecraft:stone
setblock 134 265 331 minecraft:stripped_spruce_log
setblock 134 265 332 minecraft:stone
fill 134 265 334 134 265 335 minecraft:stone
setblock 134 265 336 minecraft:stripped_spruce_log
setblock 134 265 337 minecraft:stone
setblock 134 265 341 minecraft:stripped_spruce_log
setblock 134 265 342 minecraft:stone
fill 134 265 343 134 266 343 minecraft:spruce_log
setblock 134 265 346 minecraft:stripped_spruce_log
setblock 134 265 347 minecraft:stone
setblock 134 265 351 minecraft:stripped_spruce_log
setblock 134 265 352 minecraft:stone
fill 134 265 362 134 266 362 minecraft:spruce_log
fill 134 265 364 134 308 364 minecraft:stone
setblock 135 265 324 minecraft:stone
setblock 135 265 325 minecraft:stripped_spruce_log
fill 135 265 326 135 265 329 minecraft:stone
setblock 135 265 330 minecraft:stripped_spruce_log
setblock 135 265 331 minecraft:stone
setblock 135 265 335 minecraft:stripped_spruce_log
setblock 135 265 336 minecraft:stone
setblock 135 265 340 minecraft:stripped_spruce_log
setblock 135 265 341 minecraft:stone
setblock 135 265 345 minecraft:stripped_spruce_log
setblock 135 265 346 minecraft:stone
setblock 135 265 350 minecraft:stripped_spruce_log
setblock 135 265 351 minecraft:stone
setblock 135 265 355 minecraft:stripped_spruce_log
setblock 135 265 356 minecraft:stone
setblock 135 265 364 minecraft:gold_block
fill 94 266 356 94 271 357 minecraft:stone
fill 94 266 362 94 308 362 minecraft:stone
fill 95 266 323 95 266 363 minecraft:spruce_planks
fill 96 266 323 135 266 323 minecraft:spruce_planks
fill 96 266 325 96 266 342 minecraft:spruce_planks
fill 96 266 344 96 266 361 minecraft:spruce_planks
fill 96 266 363 135 266 363 minecraft:spruce_planks
fill 97 266 324 114 266 324 minecraft:spruce_planks
setblock 97 266 327 minecraft:stripped_spruce_log
fill 97 266 328 97 267 328 minecraft:stone
setblock 97 266 332 minecraft:stripped_spruce_log
fill 97 266 333 97 267 333 minecraft:stone
fill 97 266 362 114 266 362 minecraft:spruce_planks
setblock 98 266 326 minecraft:stripped_spruce_log
setblock 98 266 327 minecraft:stone
setblock 98 266 331 minecraft:stripped_spruce_log
fill 98 266 332 98 267 332 minecraft:stone
setblock 99 266 325 minecraft:stripped_spruce_log
setblock 99 266 326 minecraft:stone
setblock 100 266 325 minecraft:stone
fill 100 266 364 100 286 364 minecraft:stone
setblock 101 266 364 minecraft:raw_gold_block
fill 108 266 322 108 299 322 minecraft:stone
fill 116 266 324 133 266 324 minecraft:spruce_planks
fill 116 266 362 133 266 362 minecraft:spruce_planks
setblock 128 266 322 minecraft:raw_iron_block
setblock 133 266 330 minecraft:stone
setblock 133 266 331 minecraft:stripped_spruce_log
fill 133 266 332 133 267 333 minecraft:stone
setblock 133 266 351 minecraft:stripped_spruce_log
setblock 133 266 352 minecraft:stone
fill 134 266 325 135 266 342 minecraft:spruce_planks
fill 134 266 344 135 266 361 minecraft:spruce_planks
setblock 135 266 324 minecraft:spruce_planks
setblock 135 266 343 minecraft:spruce_planks
setblock 135 266 362 minecraft:spruce_planks
fill 135 266 364 135 308 364 minecraft:stone
fill 136 266 333 136 268 334 minecraft:stone
fill 136 266 353 136 290 354 minecraft:stone
setblock 95 267 323 minecraft:stripped_spruce_log
fill 95 267 324 95 267 327 minecraft:stone
setblock 95 267 328 minecraft:stripped_spruce_log
fill 95 267 329 95 267 332 minecraft:stone
setblock 95 267 333 minecraft:stripped_spruce_log
fill 95 267 334 95 267 337 minecraft:stone
setblock 95 267 338 minecraft:stripped_spruce_log
fill 95 267 339 95 267 342 minecraft:stone
setblock 95 267 343 minecraft:stripped_spruce_log
fill 95 267 344 95 267 347 minecraft:stone
setblock 95 267 348 minecraft:stripped_spruce_log
fill 95 267 349 95 267 352 minecraft:stone
setblock 95 267 353 minecraft:stripped_spruce_log
fill 95 267 354 95 267 357 minecraft:stone
setblock 95 267 358 minecraft:stripped_spruce_log
setblock 95 267 359 minecraft:stone
fill 96 267 323 96 267 326 minecraft:stone
setblock 96 267 327 minecraft:stripped_spruce_log
fill 96 267 328 96 267 331 minecraft:stone
setblock 96 267 332 minecraft:stripped_spruce_log
fill 96 267 333 96 267 336 minecraft:stone
setblock 96 267 337 minecraft:stripped_spruce_log
fill 96 267 338 96 267 339 minecraft:stone
fill 96 267 349 96 267 351 minecraft:stone
setblock 96 267 352 minecraft:stripped_spruce_log
fill 96 267 353 96 267 356 minecraft:stone
fill 96 267 363 99 267 363 minecraft:stone
fill 97 267 323 98 267 324 minecraft:stone
setblock 97 267 326 minecraft:stripped_spruce_log
setblock 97 267 327 minecraft:stone
setblock 97 267 331 minecraft:stripped_spruce_log
setblock 97 267 332 minecraft:stone
setblock 97 267 336 minecraft:stripped_spruce_log
setblock 97 267 341 minecraft:light[level=15]
setblock 97 267 349 minecraft:light[level=15]
setblock 97 267 357 minecraft:light[level=15]
setblock 98 267 325 minecraft:stripped_spruce_log
setblock 98 267 330 minecraft:stripped_spruce_log
setblock 98 267 331 minecraft:stone
setblock 99 267 323 minecraft:stone
setblock 99 267 324 minecraft:stripped_spruce_log
setblock 99 267 325 minecraft:stone
setblock 100 267 323 minecraft:stripped_spruce_log
fill 100 267 324 101 267 324 minecraft:stone
setblock 100 267 363 minecraft:stripped_spruce_log
fill 101 267 323 104 267 323 minecraft:stone
fill 101 267 364 101 276 364 minecraft:stone
setblock 105 267 325 minecraft:light[level=15]
setblock 105 267 333 minecraft:light[level=15]
setblock 105 267 341 minecraft:light[level=15]
setblock 105 267 349 minecraft:light[level=15]
setblock 105 267 357 minecraft:light[level=15]
fill 111 267 363 114 267 363 minecraft:stone
fill 112 267 323 114 267 323 minecraft:stone
setblock 113 267 325 minecraft:light[level=15]
setblock 113 267 333 minecraft:light[level=15]
setblock 113 267 341 minecraft:light[level=15]
setblock 113 267 349 minecraft:light[level=15]
setblock 113 267 357 minecraft:light[level=15]
fill 114 267 362 115 267 362 minecraft:stone
setblock 115 267 323 minecraft:stripped_spruce_log
setblock 115 267 363 minecraft:stripped_spruce_log
fill 116 267 323 118 267 323 minecraft:stone
setblock 116 267 362 minecraft:stripped_spruce_log
fill 116 267 363 119 267 363 minecraft:stone
fill 117 267 362 118 267 362 minecraft:stone
setblock 120 267 363 minecraft:stripped_spruce_log
setblock 121 267 322 minecraft:diamond_block
setblock 121 267 325 minecraft:light[level=15]
setblock 121 267 333 minecraft:light[level=15]
setblock 121 267 341 minecraft:light[level=15]
setblock 121 267 349 minecraft:light[level=15]
setblock 121 267 357 minecraft:light[level=15]
setblock 128 267 322 minecraft:stone
setblock 129 267 325 minecraft:light[level=15]
setblock 129 267 333 minecraft:light[level=15]
setblock 129 267 341 minecraft:light[level=15]
setblock 129 267 349 minecraft:light[level=15]
setblock 129 267 357 minecraft:light[level=15]
setblock 133 267 330 minecraft:stripped_spruce_log
fill 133 267 331 136 267 331 minecraft:stone
setblock 133 267 334 minecraft:stone
setblock 133 267 335 minecraft:stripped_spruce_log
fill 133 267 351 135 267 351 minecraft:stone
fill 134 267 327 134 267 328 minecraft:stone
setblock 134 267 329 minecraft:stripped_spruce_log
fill 134 267 330 135 267 330 minecraft:stone
fill 134 267 332 134 267 333 minecraft:stone
setblock 134 267 334 minecraft:stripped_spruce_log
fill 134 267 335 134 267 338 minecraft:stone
setblock 134 267 339 minecraft:stripped_spruce_log
fill 134 267 340 134 267 343 minecraft:stone
setblock 134 267 344 minecraft:stripped_spruce_log
fill 134 267 345 134 267 348 minecraft:stone
setblock 134 267 349 minecraft:stripped_spruce_log
fill 134 267 350 135 267 350 minecraft:stone
fill 134 267 352 134 267 353 minecraft:stone
setblock 134 267 354 minecraft:stripped_spruce_log
fill 134 267 355 135 267 356 minecraft:stone
setblock 135 267 323 minecraft:stripped_spruce_log
fill 135 267 324 135 267 327 minecraft:stone
setblock 135 267 328 minecraft:stripped_spruce_log
setblock 135 267 329 minecraft:stone
fill 135 267 332 136 267 332 minecraft:stone
setblock 135 267 333 minecraft:stripped_spruce_log
fill 135 267 334 135 267 337 minecraft:stone
setblock 135 267 338 minecraft:stripped_spruce_log
fill 135 267 339 135 267 342 minecraft:stone
setblock 135 267 343 minecraft:stripped_spruce_log
fill 135 267 344 135 267 347 minecraft:stone
setblock 135 267 348 minecraft:stripped_spruce_log
setblock 135 267 349 minecraft:stone
setblock 135 267 352 minecraft:stone
setblock 135 267 353 minecraft:stripped_spruce_log
setblock 135 267 354 minecraft:stone
setblock 135 267 357 minecraft:stone
setblock 135 267 358 minecraft:stripped_spruce_log
setblock 135 267 359 minecraft:stone
setblock 136 267 330 minecraft:raw_iron_block
fill 121 268 322 121 308 322 minecraft:stone
setblock 128 268 322 minecraft:raw_gold_block
fill 136 268 330 136 277 332 minecraft:stone
setblock 136 268 352 minecraft:raw_gold_block
setblock 128 269 322 minecraft:stone
setblock 136 269 333 minecraft:diamond_block
fill 136 269 334 136 300 334 minecraft:stone
fill 136 269 352 136 281 352 minecraft:stone
setblock 128 270 322 minecraft:raw_gold_block
fill 136 270 333 136 308 333 minecraft:stone
fill 95 271 322 95 308 322 minecraft:stone
setblock 96 271 322 minecraft:raw_iron_block
setblock 97 271 325 minecraft:light[level=12]
setblock 97 271 332 minecraft:light[level=12]
setblock 97 271 339 minecraft:light[level=12]
setblock 97 271 346 minecraft:light[level=12]
setblock 97 271 353 minecraft:light[level=12]
setblock 97 271 360 minecraft:light[level=12]
setblock 104 271 325 minecraft:light[level=12]
setblock 104 271 332 minecraft:light[level=12]
setblock 104 271 339 minecraft:light[level=12]
setblock 104 271 346 minecraft:light[level=12]
setblock 104 271 353 minecraft:light[level=12]
setblock 104 271 360 minecraft:light[level=12]
fill 109 271 364 110 282 364 minecraft:stone
setblock 111 271 325 minecraft:light[level=12]
setblock 111 271 332 minecraft:light[level=12]
setblock 111 271 339 minecraft:light[level=12]
setblock 111 271 346 minecraft:light[level=12]
setblock 111 271 353 minecraft:light[level=12]
setblock 111 271 360 minecraft:light[level=12]
setblock 111 271 364 minecraft:diamond_block
fill 112 271 364 112 284 364 minecraft:stone
setblock 118 271 325 minecraft:light[level=12]
setblock 118 271 332 minecraft:light[level=12]
setblock 118 271 339 minecraft:light[level=12]
setblock 118 271 346 minecraft:light[level=12]
setblock 118 271 353 minecraft:light[level=12]
setblock 118 271 360 minecraft:light[level=12]
setblock 122 271 364 minecraft:diamond_block
fill 123 271 364 123 308 364 minecraft:stone
setblock 125 271 325 minecraft:light[level=12]
setblock 125 271 332 minecraft:light[level=12]
setblock 125 271 339 minecraft:light[level=12]
setblock 125 271 346 minecraft:light[level=12]
setblock 125 271 353 minecraft:light[level=12]
setblock 125 271 360 minecraft:light[level=12]
fill 128 271 322 128 289 322 minecraft:stone
setblock 132 271 325 minecraft:light[level=12]
setblock 132 271 332 minecraft:light[level=12]
setblock 132 271 339 minecraft:light[level=12]
setblock 132 271 346 minecraft:light[level=12]
setblock 132 271 353 minecraft:light[level=12]
setblock 132 271 360 minecraft:light[level=12]
setblock 134 271 322 minecraft:raw_iron_block
setblock 136 271 323 minecraft:raw_iron_block
fill 94 272 337 94 285 339 minecraft:stone
setblock 94 272 340 minecraft:raw_iron_block
fill 94 272 341 94 308 341 minecraft:stone
setblock 94 272 356 minecraft:gold_block
fill 94 272 357 94 308 357 minecraft:stone
fill 96 272 322 96 284 322 minecraft:stone
fill 111 272 364 111 292 364 minecraft:stone
fill 122 272 364 122 288 364 minecraft:stone
setblock 131 272 322 minecraft:diamond_block
fill 134 272 322 134 288 322 minecraft:stone
fill 136 272 323 136 308 323 minecraft:stone
fill 94 273 340 94 308 340 minecraft:stone
fill 94 273 356 94 308 356 minecraft:stone
setblock 94 273 360 minecraft:raw_gold_block
fill 95 273 327 110 273 359 minecraft:andesite
fill 96 273 326 134 273 326 minecraft:andesite
fill 96 273 360 134 273 360 minecraft:andesite
fill 97 273 325 133 273 325 minecraft:andesite
fill 97 273 361 133 273 361 minecraft:andesite
fill 98 273 324 132 273 324 minecraft:andesite
fill 98 273 362 132 273 362 minecraft:andesite
fill 99 273 323 131 273 323 minecraft:andesite
fill 99 273 363 131 273 363 minecraft:andesite
setblock 101 273 322 minecraft:raw_iron_block
fill 109 273 322 109 308 322 minecraft:stone
setblock 110 273 322 minecraft:raw_gold_block
fill 111 273 327 111 273 339 minecraft:andesite
fill 111 273 341 111 273 359 minecraft:andesite
fill 112 273 327 113 273 337 minecraft:andesite
fill 112 273 343 113 273 359 minecraft:andesite
fill 114 273 327 135 273 336 minecraft:andesite
fill 114 273 344 135 273 359 minecraft:andesite
fill 115 273 337 135 273 337 minecraft:andesite
fill 115 273 343 135 273 343 minecraft:andesite
fill 117 273 338 135 273 339 minecraft:andesite
fill 117 273 341 135 273 342 minecraft:andesite
fill 118 273 340 135 273 340 minecraft:andesite
fill 131 273 322 131 308 322 minecraft:stone
fill 136 273 324 136 293 324 minecraft:stone
setblock 136 273 325 minecraft:gold_block
setblock 136 273 326 minecraft:raw_gold_block
fill 94 274 360 94 308 360 minecraft:stone
fill 95 274 328 95 274 358 minecraft:andesite
fill 96 274 327 96 275 327 minecraft:andesite
fill 96 274 328 110 274 358 minecraft:stone
fill 96 274 359 96 275 359 minecraft:andesite
fill 97 274 326 97 275 326 minecraft:andesite
fill 97 274 327 133 275 327 minecraft:stone
fill 97 274 359 133 275 359 minecraft:stone
fill 97 274 360 97 275 360 minecraft:andesite
fill 98 274 325 98 275 325 minecraft:andesite
fill 98 274 326 132 275 326 minecraft:stone
fill 98 274 360 132 275 360 minecraft:stone
fill 98 274 361 98 275 361 minecraft:andesite
fill 99 274 324 99 275 324 minecraft:andesite
fill 99 274 325 131 275 325 minecraft:stone
fill 99 274 361 131 275 361 minecraft:stone
fill 99 274 362 99 275 362 minecraft:andesite
fill 100 274 323 130 274 323 minecraft:andesite
fill 100 274 324 130 274 324 minecraft:stone
fill 100 274 362 130 274 362 minecraft:stone
fill 100 274 363 130 274 363 minecraft:andesite
fill 101 274 322 101 308 322 minecraft:stone
fill 110 274 322 110 308 322 minecraft:stone
fill 111 274 328 111 277 339 minecraft:stone
fill 111 274 341 111 277 358 minecraft:stone
fill 112 274 328 113 277 337 minecraft:stone
fill 112 274 343 113 277 358 minecraft:stone
fill 114 274 328 134 274 336 minecraft:stone
fill 114 274 344 134 274 358 minecraft:stone
fill 115 274 337 134 277 337 minecraft:stone
fill 115 274 343 134 277 343 minecraft:stone
fill 117 274 338 134 277 339 minecraft:stone
fill 117 274 341 134 277 342 minecraft:stone
fill 118 274 340 134 278 340 minecraft:stone
fill 123 274 322 126 276 322 minecraft:stone
setblock 127 274 322 minecraft:diamond_block
fill 131 274 324 131 275 324 minecraft:andesite
fill 131 274 362 131 275 362 minecraft:andesite
fill 132 274 325 132 275 325 minecraft:andesite
fill 132 274 361 132 275 361 minecraft:andesite
fill 133 274 326 133 275 326 minecraft:andesite
fill 133 274 360 133 275 360 minecraft:andesite
fill 134 274 327 134 275 327 minecraft:andesite
fill 134 274 359 134 275 359 minecraft:andesite
fill 135 274 328 135 274 358 minecraft:andesite
fill 136 274 325 136 308 326 minecraft:stone
fill 95 275 329 95 276 357 minecraft:andesite
fill 96 275 328 96 276 328 minecraft:andesite
fill 96 275 329 110 276 357 minecraft:stone
fill 96 275 358 96 276 358 minecraft:andesite
setblock 97 275 325 minecraft:light[level=15]
fill 97 275 328 110 276 328 minecraft:stone
fill 97 275 358 110 276 358 minecraft:stone
fill 100 275 324 100 276 324 minecraft:andesite
fill 100 275 362 100 276 362 minecraft:andesite
fill 101 275 323 129 276 323 minecraft:andesite
fill 101 275 324 129 276 324 minecraft:stone
fill 101 275 362 129 276 362 minecraft:stone
fill 101 275 363 129 276 363 minecraft:andesite
fill 114 275 328 133 276 336 minecraft:stone
fill 114 275 344 133 276 358 minecraft:stone
fill 127 275 322 127 288 322 minecraft:stone
fill 130 275 324 130 276 324 minecraft:andesite
fill 130 275 362 130 276 362 minecraft:andesite
fill 134 275 328 134 276 328 minecraft:andesite
fill 134 275 329 134 276 336 minecraft:stone
fill 134 275 344 134 276 357 minecraft:stone
fill 134 275 358 134 276 358 minecraft:andesite
fill 135 275 329 135 276 357 minecraft:andesite
fill 94 276 328 94 308 329 minecraft:stone
setblock 94 276 330 minecraft:gold_block
fill 96 276 324 96 279 324 minecraft:spruce_log
fill 96 276 362 96 279 362 minecraft:spruce_log
setblock 97 276 327 minecraft:andesite
setblock 97 276 359 minecraft:andesite
fill 98 276 326 98 277 326 minecraft:andesite
fill 98 276 327 132 276 327 minecraft:stone
fill 98 276 359 132 276 359 minecraft:stone
fill 98 276 360 98 277 360 minecraft:andesite
setblock 99 276 325 minecraft:andesite
fill 99 276 326 131 276 326 minecraft:stone
fill 99 276 360 131 276 360 minecraft:stone
setblock 99 276 361 minecraft:andesite
fill 100 276 325 130 276 325 minecraft:stone
fill 100 276 361 130 276 361 minecraft:stone
setblock 131 276 325 minecraft:andesite
setblock 131 276 361 minecraft:andesite
fill 132 276 326 132 277 326 minecraft:andesite
fill 132 276 360 132 277 360 minecraft:andesite
setblock 133 276 327 minecraft:andesite
setblock 133 276 359 minecraft:andesite
fill 134 276 324 134 279 324 minecraft:spruce_log
fill 134 276 362 134 279 362 minecraft:spruce_log
fill 94 277 330 94 308 330 minecraft:stone
fill 95 277 330 95 277 356 minecraft:andesite
fill 96 277 329 96 278 329 minecraft:andesite
fill 96 277 330 110 277 356 minecraft:stone
fill 96 277 357 96 278 357 minecraft:andesite
setblock 97 277 322 minecraft:raw_gold_block
setblock 97 277 325 minecraft:light[level=12]
fill 97 277 328 97 278 328 minecraft:andesite
fill 97 277 329 110 278 329 minecraft:stone
fill 97 277 357 110 278 357 minecraft:stone
fill 97 277 358 97 278 358 minecraft:andesite
setblock 97 277 360 minecraft:light[level=12]
fill 98 277 327 98 278 327 minecraft:andesite
fill 98 277 328 110 278 328 minecraft:stone
fill 98 277 358 110 278 358 minecraft:stone
fill 98 277 359 98 278 359 minecraft:andesite
fill 99 277 326 99 278 326 minecraft:andesite
fill 99 277 327 131 278 327 minecraft:stone
fill 99 277 359 131 278 359 minecraft:stone
fill 99 277 360 99 278 360 minecraft:andesite
fill 100 277 325 100 278 325 minecraft:andesite
fill 100 277 326 130 278 326 minecraft:stone
fill 100 277 360 130 278 360 minecraft:stone
fill 100 277 361 100 278 361 minecraft:andesite
fill 101 277 324 101 278 324 minecraft:andesite
fill 101 277 325 129 278 325 minecraft:stone
fill 101 277 361 129 278 361 minecraft:stone
fill 101 277 362 101 278 362 minecraft:andesite
setblock 101 277 364 minecraft:raw_iron_block
fill 102 277 323 128 277 323 minecraft:andesite
fill 102 277 324 128 277 324 minecraft:stone
fill 102 277 362 128 277 362 minecraft:stone
fill 102 277 363 128 277 363 minecraft:andesite
setblock 113 277 322 minecraft:diamond_block
fill 114 277 322 116 277 322 minecraft:stone
fill 114 277 328 132 278 336 minecraft:stone
fill 114 277 344 132 278 358 minecraft:stone
setblock 120 277 322 minecraft:diamond_block
fill 123 277 322 124 278 322 minecraft:stone
setblock 125 277 322 minecraft:raw_gold_block
fill 126 277 322 126 287 322 minecraft:stone
fill 129 277 324 129 278 324 minecraft:andesite
fill 129 277 362 129 278 362 minecraft:andesite
fill 130 277 325 130 278 325 minecraft:andesite
fill 130 277 361 130 278 361 minecraft:andesite
fill 131 277 326 131 278 326 minecraft:andesite
fill 131 277 360 131 278 360 minecraft:andesite
setblock 132 277 325 minecraft:light[level=12]
fill 132 277 327 132 278 327 minecraft:andesite
fill 132 277 359 132 278 359 minecraft:andesite
fill 133 277 328 133 278 328 minecraft:andesite
fill 133 277 329 133 278 336 minecraft:stone
fill 133 277 344 133 278 357 minecraft:stone
fill 133 277 358 133 278 358 minecraft:andesite
fill 134 277 329 134 278 329 minecraft:andesite
fill 134 277 330 134 277 336 minecraft:stone
fill 134 277 344 134 277 356 minecraft:stone
fill 134 277 357 134 278 357 minecraft:andesite
fill 135 277 330 135 277 356 minecraft:andesite
fill 136 277 327 136 284 327 minecraft:stone
setblock 136 277 328 minecraft:diamond_block
fill 136 277 329 136 308 329 minecraft:stone
fill 136 277 348 136 308 349 minecraft:stone
setblock 136 277 350 minecraft:gold_block
fill 95 278 331 95 278 355 minecraft:andesite
fill 96 278 330 96 279 330 minecraft:andesite
fill 96 278 331 110 278 355 minecraft:stone
fill 96 278 356 96 279 356 minecraft:andesite
fill 97 278 322 97 279 322 minecraft:stone
fill 97 278 330 113 279 330 minecraft:stone
fill 97 278 356 113 279 356 minecraft:stone
fill 101 278 364 101 308 364 minecraft:stone
fill 102 278 324 102 279 324 minecraft:andesite
fill 102 278 362 102 279 362 minecraft:andesite
fill 103 278 323 127 278 323 minecraft:andesite
fill 103 278 324 127 278 324 minecraft:stone
fill 103 278 362 127 278 362 minecraft:stone
fill 103 278 363 127 278 363 minecraft:andesite
fill 111 278 328 113 287 329 minecraft:stone
fill 111 278 331 111 278 338 minecraft:stone
setblock 111 278 339 minecraft:cobbled_deepslate
fill 111 278 341 111 278 342 minecraft:cobbled_deepslate
fill 111 278 343 111 278 355 minecraft:stone
fill 111 278 357 113 287 358 minecraft:stone
fill 112 278 331 112 278 337 minecraft:stone
fill 112 278 343 113 278 343 minecraft:cobbled_deepslate
fill 112 278 344 113 278 355 minecraft:stone
fill 113 278 322 113 308 322 minecraft:stone
fill 113 278 331 113 278 336 minecraft:stone
setblock 113 278 337 minecraft:cobbled_deepslate
setblock 114 278 322 minecraft:gold_block
fill 115 278 322 116 278 322 minecraft:stone
setblock 115 278 337 minecraft:cobbled_deepslate
fill 115 278 343 116 278 343 minecraft:cobbled_deepslate
fill 116 278 337 134 278 337 minecraft:stone
fill 117 278 338 134 278 338 minecraft:stone
setblock 117 278 339 minecraft:cobbled_deepslate
fill 117 278 341 117 278 342 minecraft:cobbled_deepslate
fill 117 278 343 134 278 343 minecraft:stone
fill 118 278 339 134 278 339 minecraft:stone
fill 118 278 341 134 278 342 minecraft:stone
fill 120 278 322 120 308 322 minecraft:stone
fill 125 278 322 125 280 322 minecraft:stone
fill 128 278 324 128 279 324 minecraft:andesite
fill 128 278 362 128 279 362 minecraft:andesite
fill 134 278 330 134 279 330 minecraft:andesite
fill 134 278 331 134 278 336 minecraft:stone
fill 134 278 344 134 278 355 minecraft:stone
fill 134 278 356 134 279 356 minecraft:andesite
fill 135 278 331 135 278 355 minecraft:andesite
fill 136 278 328 136 308 328 minecraft:stone
fill 136 278 330 136 282 331 minecraft:stone
setblock 136 278 332 minecraft:raw_gold_block
fill 136 278 350 136 308 350 minecraft:stone
fill 95 279 323 95 279 331 minecraft:stone
fill 95 279 332 95 279 354 minecraft:andesite
fill 95 279 355 95 279 363 minecraft:stone
fill 96 279 323 103 279 323 minecraft:stone
fill 96 279 325 96 279 329 minecraft:stone
fill 96 279 331 96 280 331 minecraft:andesite
fill 96 279 332 109 279 354 minecraft:stone
fill 96 279 355 96 280 355 minecraft:andesite
fill 96 279 357 96 279 361 minecraft:stone
fill 96 279 363 103 279 363 minecraft:stone
fill 97 279 324 97 279 328 minecraft:stone
setblock 97 279 329 minecraft:andesite
fill 97 279 331 133 280 331 minecraft:stone
fill 97 279 355 133 280 355 minecraft:stone
setblock 97 279 357 minecraft:andesite
fill 97 279 358 97 279 362 minecraft:stone
fill 98 279 324 98 279 327 minecraft:stone
setblock 98 279 328 minecraft:andesite
fill 98 279 329 110 279 329 minecraft:stone
fill 98 279 357 110 279 357 minecraft:stone
setblock 98 279 358 minecraft:andesite
fill 98 279 359 98 279 362 minecraft:stone
fill 99 279 324 99 279 326 minecraft:stone
fill 99 279 327 99 280 327 minecraft:andesite
fill 99 279 328 110 279 328 minecraft:stone
fill 99 279 358 110 279 358 minecraft:stone
fill 99 279 359 99 280 359 minecraft:andesite
fill 99 279 360 99 279 362 minecraft:stone
fill 100 279 324 100 279 325 minecraft:stone
setblock 100 279 326 minecraft:andesite
fill 100 279 327 130 279 327 minecraft:stone
fill 100 279 359 130 279 359 minecraft:stone
setblock 100 279 360 minecraft:andesite
fill 100 279 361 100 279 362 minecraft:stone
setblock 101 279 324 minecraft:stone
setblock 101 279 325 minecraft:andesite
fill 101 279 326 129 279 326 minecraft:stone
fill 101 279 360 129 279 360 minecraft:stone
setblock 101 279 361 minecraft:andesite
setblock 101 279 362 minecraft:stone
fill 102 279 325 128 279 325 minecraft:stone
fill 102 279 361 128 279 361 minecraft:stone
fill 103 279 324 103 280 324 minecraft:andesite
fill 103 279 362 103 280 362 minecraft:andesite
fill 104 279 323 126 279 323 minecraft:andesite
fill 104 279 324 126 279 324 minecraft:stone
fill 104 279 362 126 279 362 minecraft:stone
fill 104 279 363 126 279 363 minecraft:andesite
fill 110 279 332 110 279 338 minecraft:stone
fill 110 279 339 110 279 341 minecraft:glowstone
setblock 110 279 342 minecraft:spruce_planks
fill 110 279 343 110 279 354 minecraft:stone
fill 111 279 332 112 279 336 minecraft:stone
fill 111 279 337 111 279 339 minecraft:glowstone
fill 111 279 341 111 279 343 minecraft:glowstone
fill 111 279 344 111 279 354 minecraft:stone
fill 112 279 337 113 279 337 minecraft:glowstone
fill 112 279 343 113 279 343 minecraft:glowstone
setblock 112 279 344 minecraft:spruce_planks
fill 112 279 345 134 279 354 minecraft:stone
fill 113 279 332 134 279 335 minecraft:stone
fill 113 279 336 115 279 336 minecraft:glowstone
fill 113 279 344 115 279 344 minecraft:glowstone
fill 114 279 322 114 308 322 minecraft:stone
fill 114 279 328 131 279 330 minecraft:stone
fill 114 279 356 131 279 358 minecraft:stone
setblock 115 279 322 minecraft:raw_iron_block
fill 115 279 337 117 279 337 minecraft:glowstone
fill 115 279 343 117 279 343 minecraft:glowstone
fill 116 279 322 116 308 322 minecraft:stone
fill 116 279 336 134 279 336 minecraft:stone
setblock 116 279 344 minecraft:spruce_planks
fill 117 279 338 117 279 339 minecraft:glowstone
fill 117 279 341 117 279 342 minecraft:glowstone
fill 117 279 344 134 279 344 minecraft:stone
fill 118 279 337 134 279 338 minecraft:stone
fill 118 279 339 118 279 341 minecraft:glowstone
setblock 118 279 342 minecraft:spruce_planks
fill 118 279 343 134 279 343 minecraft:stone
fill 119 279 339 134 279 342 minecraft:stone
setblock 123 279 322 minecraft:raw_iron_block
fill 124 279 322 124 308 322 minecraft:stone
fill 127 279 323 135 279 323 minecraft:stone
fill 127 279 324 127 280 324 minecraft:andesite
fill 127 279 362 127 280 362 minecraft:andesite
fill 127 279 363 135 279 363 minecraft:stone
fill 129 279 324 133 279 324 minecraft:stone
setblock 129 279 325 minecraft:andesite
setblock 129 279 361 minecraft:andesite
fill 129 279 362 133 279 362 minecraft:stone
fill 130 279 325 135 279 325 minecraft:stone
setblock 130 279 326 minecraft:andesite
setblock 130 279 360 minecraft:andesite
fill 130 279 361 135 279 361 minecraft:stone
fill 131 279 326 135 279 326 minecraft:stone
fill 131 279 327 131 280 327 minecraft:andesite
fill 131 279 359 131 280 359 minecraft:andesite
fill 131 279 360 135 279 360 minecraft:stone
fill 132 279 327 135 279 327 minecraft:stone
setblock 132 279 328 minecraft:andesite
fill 132 279 329 132 279 330 minecraft:stone
fill 132 279 356 132 279 357 minecraft:stone
setblock 132 279 358 minecraft:andesite
fill 132 279 359 135 279 359 minecraft:stone
fill 133 279 328 135 279 328 minecraft:stone
setblock 133 279 329 minecraft:andesite
setblock 133 279 330 minecraft:stone
setblock 133 279 356 minecraft:stone
setblock 133 279 357 minecraft:andesite
fill 133 279 358 135 279 358 minecraft:stone
fill 134 279 329 135 279 329 minecraft:stone
fill 134 279 331 134 280 331 minecraft:andesite
fill 134 279 355 134 280 355 minecraft:andesite
fill 134 279 357 135 279 357 minecraft:stone
setblock 135 279 324 minecraft:stone
fill 135 279 330 135 279 331 minecraft:stone
fill 135 279 332 135 279 354 minecraft:andesite
fill 135 279 355 135 279 356 minecraft:stone
setblock 135 279 362 minecraft:stone
fill 136 279 332 136 308 332 minecraft:stone
fill 95 280 333 95 280 353 minecraft:andesite
setblock 96 280 324 minecraft:glowstone
fill 96 280 332 96 281 332 minecraft:andesite
fill 96 280 333 108 280 353 minecraft:stone
fill 96 280 354 96 281 354 minecraft:andesite
setblock 96 280 362 minecraft:glowstone
setblock 97 280 322 minecraft:gold_block
setblock 97 280 330 minecraft:andesite
fill 97 280 332 133 281 332 minecraft:stone
fill 97 280 354 133 281 354 minecraft:stone
setblock 97 280 356 minecraft:andesite
fill 98 280 329 98 281 329 minecraft:andesite
fill 98 280 330 132 280 330 minecraft:stone
fill 98 280 356 132 280 356 minecraft:stone
fill 98 280 357 98 281 357 minecraft:andesite
fill 99 280 328 99 281 328 minecraft:andesite
fill 99 280 329 110 281 329 minecraft:stone
fill 99 280 357 110 281 357 minecraft:stone
fill 99 280 358 99 281 358 minecraft:andesite
fill 100 280 327 100 281 327 minecraft:andesite
fill 100 280 328 110 281 328 minecraft:stone
fill 100 280 358 110 281 358 minecraft:stone
fill 100 280 359 100 281 359 minecraft:andesite
fill 101 280 326 101 281 326 minecraft:andesite
fill 101 280 327 129 281 327 minecraft:stone
fill 101 280 359 129 281 359 minecraft:stone
fill 101 280 360 101 281 360 minecraft:andesite
setblock 102 280 325 minecraft:andesite
fill 102 280 326 128 280 326 minecraft:stone
fill 102 280 360 128 280 360 minecraft:stone
setblock 102 280 361 minecraft:andesite
fill 103 280 325 127 280 325 minecraft:stone
fill 103 280 361 127 280 361 minecraft:stone
fill 104 280 324 104 281 324 minecraft:andesite
fill 104 280 362 104 281 362 minecraft:andesite
fill 105 280 323 125 280 323 minecraft:andesite
fill 105 280 324 125 280 324 minecraft:stone
fill 105 280 362 125 280 362 minecraft:stone
fill 105 280 363 125 280 363 minecraft:andesite
setblock 106 280 322 minecraft:gold_block
fill 109 280 333 109 280 338 minecraft:stone
fill 109 280 339 109 281 341 minecraft:cobbled_deepslate
fill 109 280 342 109 280 353 minecraft:stone
fill 110 280 333 110 280 337 minecraft:stone
setblock 110 280 338 minecraft:cobbled_deepslate
fill 110 280 342 110 280 343 minecraft:cobbled_deepslate
fill 110 280 344 110 280 353 minecraft:stone
fill 111 280 333 111 280 336 minecraft:stone
setblock 111 280 337 minecraft:cobbled_deepslate
setblock 111 280 344 minecraft:cobbled_deepslate
fill 111 280 345 111 280 353 minecraft:stone
fill 112 280 333 134 280 335 minecraft:stone
fill 112 280 336 116 280 336 minecraft:cobbled_deepslate
fill 112 280 345 117 280 345 minecraft:cobbled_deepslate
fill 112 280 346 134 280 353 minecraft:stone
fill 114 280 328 130 281 329 minecraft:stone
fill 114 280 357 130 281 358 minecraft:stone
fill 115 280 322 115 300 322 minecraft:stone
fill 117 280 336 134 280 336 minecraft:stone
setblock 117 280 337 minecraft:cobbled_deepslate
fill 117 280 344 118 280 344 minecraft:cobbled_deepslate
fill 118 280 337 134 280 337 minecraft:stone
setblock 118 280 338 minecraft:cobbled_deepslate
setblock 118 280 343 minecraft:cobbled_deepslate
fill 118 280 345 134 280 345 minecraft:stone
fill 119 280 338 134 280 338 minecraft:stone
fill 119 280 339 119 280 342 minecraft:cobbled_deepslate
fill 119 280 343 134 280 344 minecraft:stone
fill 120 280 339 134 280 342 minecraft:stone
setblock 122 280 322 minecraft:raw_gold_block
fill 123 280 322 123 308 322 minecraft:stone
fill 126 280 324 126 281 324 minecraft:andesite
fill 126 280 362 126 281 362 minecraft:andesite
setblock 128 280 325 minecraft:andesite
setblock 128 280 361 minecraft:andesite
fill 129 280 326 129 281 326 minecraft:andesite
fill 129 280 360 129 281 360 minecraft:andesite
fill 130 280 327 130 281 327 minecraft:andesite
fill 130 280 359 130 281 359 minecraft:andesite
fill 131 280 328 131 281 328 minecraft:andesite
fill 131 280 329 131 281 329 minecraft:stone
fill 131 280 357 131 281 357 minecraft:stone
fill 131 280 358 131 281 358 minecraft:andesite
fill 132 280 329 132 281 329 minecraft:andesite
fill 132 280 357 132 281 357 minecraft:andesite
setblock 133 280 330 minecraft:andesite
setblock 133 280 356 minecraft:andesite
setblock 134 280 324 minecraft:glowstone
fill 134 280 332 134 281 332 minecraft:andesite
fill 134 280 354 134 281 354 minecraft:andesite
setblock 134 280 362 minecraft:glowstone
fill 135 280 333 135 280 353 minecraft:andesite
fill 136 280 339 136 288 339 minecraft:stone
setblock 136 280 340 minecraft:gold_block
fill 136 280 341 136 289 342 minecraft:stone
fill 95 281 334 95 281 352 minecraft:andesite
fill 96 281 324 96 282 324 minecraft:spruce_log
fill 96 281 333 96 282 333 minecraft:andesite
fill 96 281 334 108 281 352 minecraft:stone
fill 96 281 353 96 282 353 minecraft:andesite
fill 96 281 362 96 282 362 minecraft:spruce_log
fill 97 281 322 97 308 322 minecraft:stone
setblock 97 281 331 minecraft:andesite
fill 97 281 333 133 282 333 minecraft:stone
fill 97 281 353 133 282 353 minecraft:stone
setblock 97 281 355 minecraft:andesite
fill 98 281 330 98 282 330 minecraft:andesite
fill 98 281 331 132 281 331 minecraft:stone
fill 98 281 355 132 281 355 minecraft:stone
fill 98 281 356 98 282 356 minecraft:andesite
fill 99 281 330 131 282 330 minecraft:stone
fill 99 281 356 131 282 356 minecraft:stone
fill 102 281 326 102 282 326 minecraft:andesite
fill 102 281 360 102 282 360 minecraft:andesite
setblock 103 281 325 minecraft:andesite
fill 103 281 326 127 281 326 minecraft:stone
fill 103 281 360 127 281 360 minecraft:stone
setblock 103 281 361 minecraft:andesite
fill 104 281 325 126 281 325 minecraft:stone
fill 104 281 361 126 281 361 minecraft:stone
fill 105 281 324 105 282 324 minecraft:andesite
fill 105 281 362 105 282 362 minecraft:andesite
fill 106 281 322 106 291 322 minecraft:stone
fill 106 281 323 124 281 323 minecraft:andesite
fill 106 281 324 124 281 324 minecraft:stone
fill 106 281 362 124 281 362 minecraft:stone
fill 106 281 363 124 281 363 minecraft:andesite
fill 109 281 334 109 281 337 minecraft:stone
setblock 109 281 338 minecraft:cobbled_deepslate
fill 109 281 342 109 281 343 minecraft:cobbled_deepslate
fill 109 281 344 109 281 352 minecraft:stone
fill 110 281 334 110 281 336 minecraft:stone
setblock 110 281 337 minecraft:cobbled_deepslate
fill 110 281 344 110 281 345 minecraft:cobbled_deepslate
fill 110 281 346 111 281 352 minecraft:stone
fill 111 281 334 111 281 335 minecraft:stone
setblock 111 281 336 minecraft:cobbled_deepslate
setblock 111 281 345 minecraft:cobbled_deepslate
fill 112 281 334 134 281 334 minecraft:stone
fill 112 281 335 116 281 335 minecraft:cobbled_deepslate
fill 112 281 346 117 281 346 minecraft:cobbled_deepslate
fill 112 281 347 134 281 352 minecraft:stone
fill 117 281 335 134 281 335 minecraft:stone
setblock 117 281 336 minecraft:cobbled_deepslate
fill 118 281 336 134 281 336 minecraft:stone
setblock 118 281 337 minecraft:cobbled_deepslate
setblock 118 281 345 minecraft:cobbled_deepslate
fill 118 281 346 134 281 346 minecraft:stone
fill 119 281 337 134 281 337 minecraft:stone
setblock 119 281 338 minecraft:cobbled_deepslate
fill 119 281 343 119 281 344 minecraft:cobbled_deepslate
fill 119 281 345 134 281 345 minecraft:stone
fill 120 281 338 134 281 338 minecraft:stone
fill 120 281 339 120 281 342 minecraft:cobbled_deepslate
fill 120 281 343 134 281 344 minecraft:stone
fill 121 281 339 134 281 342 minecraft:stone
fill 122 281 322 122 308 322 minecraft:stone
setblock 125 281 322 minecraft:gold_block
fill 125 281 324 125 282 324 minecraft:andesite
fill 125 281 362 125 282 362 minecraft:andesite
setblock 127 281 325 minecraft:andesite
setblock 127 281 361 minecraft:andesite
fill 128 281 326 128 282 326 minecraft:andesite
fill 128 281 360 128 282 360 minecraft:andesite
fill 132 281 330 132 282 330 minecraft:andesite
fill 132 281 356 132 282 356 minecraft:andesite
setblock 133 281 331 minecraft:andesite
setblock 133 281 355 minecraft:andesite
fill 134 281 324 134 282 324 minecraft:spruce_log
fill 134 281 333 134 282 333 minecraft:andesite
fill 134 281 353 134 282 353 minecraft:andesite
fill 134 281 362 134 282 362 minecraft:spruce_log
fill 135 281 334 135 281 352 minecraft:andesite
fill 136 281 340 136 308 340 minecraft:stone
fill 136 281 355 136 306 356 minecraft:stone
setblock 136 281 357 minecraft:raw_gold_block
fill 136 281 358 136 308 358 minecraft:stone
fill 95 282 323 95 282 334 minecraft:spruce_planks
fill 95 282 335 95 282 351 minecraft:andesite
fill 95 282 352 95 282 363 minecraft:spruce_planks
fill 96 282 323 106 282 323 minecraft:spruce_planks
fill 96 282 325 96 282 332 minecraft:spruce_planks
setblock 96 282 334 minecraft:andesite
fill 96 282 335 107 282 351 minecraft:stone
setblock 96 282 352 minecraft:andesite
fill 96 282 354 96 282 361 minecraft:spruce_planks
fill 96 282 363 106 282 363 minecraft:spruce_planks
fill 97 282 324 104 282 324 minecraft:spruce_planks
setblock 97 282 332 minecraft:andesite
fill 97 282 334 113 282 334 minecraft:stone
fill 97 282 352 133 282 352 minecraft:stone
setblock 97 282 354 minecraft:andesite
fill 97 282 362 104 282 362 minecraft:spruce_planks
fill 98 282 331 98 283 331 minecraft:andesite
fill 98 282 332 132 282 332 minecraft:stone
fill 98 282 354 132 282 354 minecraft:stone
fill 98 282 355 98 283 355 minecraft:andesite
setblock 99 282 329 minecraft:andesite
fill 99 282 331 131 283 331 minecraft:stone
fill 99 282 355 131 283 355 minecraft:stone
setblock 99 282 357 minecraft:andesite
setblock 100 282 328 minecraft:andesite
fill 100 282 329 110 282 329 minecraft:stone
fill 100 282 357 110 282 357 minecraft:stone
setblock 100 282 358 minecraft:andesite
setblock 101 282 327 minecraft:andesite
fill 101 282 328 110 282 328 minecraft:stone
fill 101 282 358 110 282 358 minecraft:stone
setblock 101 282 359 minecraft:andesite
fill 102 282 327 128 282 327 minecraft:stone
fill 102 282 359 128 282 359 minecraft:stone
fill 103 282 326 103 283 326 minecraft:andesite
fill 103 282 360 103 283 360 minecraft:andesite
setblock 104 282 325 minecraft:andesite
fill 104 282 326 126 282 326 minecraft:stone
fill 104 282 360 126 282 360 minecraft:stone
setblock 104 282 361 minecraft:andesite
fill 105 282 325 125 282 325 minecraft:stone
fill 105 282 361 125 282 361 minecraft:stone
setblock 106 282 324 minecraft:andesite
setblock 106 282 362 minecraft:andesite
fill 107 282 323 123 282 323 minecraft:andesite
fill 107 282 324 123 282 324 minecraft:stone
fill 107 282 362 123 282 362 minecraft:stone
fill 107 282 363 123 282 363 minecraft:andesite
fill 108 282 335 108 282 338 minecraft:stone
fill 108 282 339 108 282 343 minecraft:spruce_planks
fill 108 282 344 108 282 351 minecraft:stone
fill 109 282 335 109 283 336 minecraft:stone
fill 109 282 337 109 282 338 minecraft:spruce_planks
fill 109 282 344 109 282 345 minecraft:spruce_planks
fill 109 282 346 109 282 351 minecraft:stone
fill 110 282 335 110 283 335 minecraft:stone
setblock 110 282 336 minecraft:spruce_planks
fill 110 282 346 111 282 346 minecraft:spruce_planks
fill 110 282 347 110 282 351 minecraft:stone
fill 111 282 335 113 282 335 minecraft:spruce_planks
fill 111 282 347 118 282 347 minecraft:spruce_planks
fill 111 282 348 113 282 351 minecraft:stone
fill 114 282 328 129 282 329 minecraft:stone
fill 114 282 334 115 282 334 minecraft:spruce_planks
fill 114 282 348 115 282 348 minecraft:spruce_planks
fill 114 282 349 134 282 351 minecraft:stone
fill 114 282 357 129 282 358 minecraft:stone
fill 116 282 334 133 282 334 minecraft:stone
fill 116 282 335 117 282 335 minecraft:spruce_planks
fill 116 282 348 134 282 348 minecraft:stone
fill 118 282 335 134 282 335 minecraft:stone
setblock 118 282 336 minecraft:spruce_planks
fill 118 282 346 119 282 346 minecraft:spruce_planks
fill 119 282 336 134 282 336 minecraft:stone
setblock 119 282 337 minecraft:spruce_planks
fill 119 282 345 120 282 345 minecraft:spruce_planks
fill 119 282 347 134 282 347 minecraft:stone
fill 120 282 337 134 282 337 minecraft:stone
fill 120 282 338 120 282 339 minecraft:spruce_planks
fill 120 282 343 120 282 344 minecraft:spruce_planks
fill 120 282 346 134 282 346 minecraft:stone
fill 121 282 338 134 282 339 minecraft:stone
fill 121 282 340 121 282 342 minecraft:spruce_planks
fill 121 282 343 134 282 345 minecraft:stone
fill 122 282 340 134 282 342 minecraft:stone
fill 124 282 323 135 282 323 minecraft:spruce_planks
setblock 124 282 324 minecraft:andesite
setblock 124 282 362 minecraft:andesite
fill 124 282 363 135 282 363 minecraft:spruce_planks
fill 125 282 322 125 308 322 minecraft:stone
setblock 125 282 364 minecraft:diamond_block
fill 126 282 324 133 282 324 minecraft:spruce_planks
setblock 126 282 325 minecraft:andesite
setblock 126 282 361 minecraft:andesite
fill 126 282 362 133 282 362 minecraft:spruce_planks
fill 127 282 326 127 283 326 minecraft:andesite
fill 127 282 360 127 283 360 minecraft:andesite
setblock 129 282 327 minecraft:andesite
setblock 129 282 359 minecraft:andesite
setblock 130 282 328 minecraft:andesite
setblock 130 282 329 minecraft:stone
setblock 130 282 357 minecraft:stone
setblock 130 282 358 minecraft:andesite
setblock 131 282 329 minecraft:andesite
setblock 131 282 357 minecraft:andesite
fill 132 282 331 132 283 331 minecraft:andesite
fill 132 282 355 132 283 355 minecraft:andesite
setblock 133 282 332 minecraft:andesite
setblock 133 282 354 minecraft:andesite
fill 134 282 325 135 282 332 minecraft:spruce_planks
setblock 134 282 334 minecraft:andesite
setblock 134 282 352 minecraft:andesite
fill 134 282 354 135 282 361 minecraft:spruce_planks
setblock 135 282 324 minecraft:spruce_planks
fill 135 282 333 135 282 334 minecraft:spruce_planks
fill 135 282 335 135 282 351 minecraft:andesite
fill 135 282 352 135 282 353 minecraft:spruce_planks
setblock 135 282 362 minecraft:spruce_planks
setblock 136 282 352 minecraft:gold_block
fill 136 282 357 136 301 357 minecraft:stone
setblock 136 282 360 minecraft:raw_iron_block
fill 94 283 352 94 285 354 minecraft:stone
setblock 94 283 355 minecraft:gold_block
setblock 94 283 363 minecraft:raw_iron_block
fill 95 283 323 95 283 326 minecraft:stone
fill 95 283 337 95 283 349 minecraft:andesite
schedule function dropper:buildpart/74_9 1t
