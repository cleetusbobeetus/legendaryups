setblock 558 61 350 minecraft:stripped_dark_oak_log
setblock 558 61 357 minecraft:stripped_dark_oak_log
setblock 558 61 363 minecraft:stripped_dark_oak_log
setblock 518 62 327 minecraft:stripped_dark_oak_log
setblock 518 62 334 minecraft:stripped_dark_oak_log
setblock 518 62 341 minecraft:stripped_dark_oak_log
setblock 518 62 348 minecraft:stripped_dark_oak_log
setblock 518 62 355 minecraft:stripped_dark_oak_log
setblock 518 62 362 minecraft:stripped_dark_oak_log
setblock 521 62 323 minecraft:stripped_dark_oak_log
setblock 524 62 363 minecraft:stripped_dark_oak_log
setblock 528 62 323 minecraft:stripped_dark_oak_log
setblock 531 62 363 minecraft:stripped_dark_oak_log
setblock 535 62 323 minecraft:stripped_dark_oak_log
setblock 538 62 363 minecraft:stripped_dark_oak_log
setblock 542 62 323 minecraft:stripped_dark_oak_log
setblock 545 62 363 minecraft:stripped_dark_oak_log
setblock 549 62 323 minecraft:stripped_dark_oak_log
setblock 552 62 363 minecraft:stripped_dark_oak_log
setblock 556 62 323 minecraft:stripped_dark_oak_log
setblock 558 62 328 minecraft:stripped_dark_oak_log
setblock 558 62 335 minecraft:stripped_dark_oak_log
setblock 558 62 342 minecraft:stripped_dark_oak_log
setblock 558 62 349 minecraft:stripped_dark_oak_log
setblock 558 62 356 minecraft:stripped_dark_oak_log
setblock 518 64 329 minecraft:stripped_dark_oak_log
setblock 518 64 336 minecraft:stripped_dark_oak_log
setblock 518 64 343 minecraft:stripped_dark_oak_log
setblock 518 64 350 minecraft:stripped_dark_oak_log
setblock 518 64 357 minecraft:stripped_dark_oak_log
setblock 519 64 323 minecraft:stripped_dark_oak_log
setblock 519 64 363 minecraft:stripped_dark_oak_log
setblock 526 64 323 minecraft:stripped_dark_oak_log
setblock 526 64 363 minecraft:stripped_dark_oak_log
setblock 533 64 323 minecraft:stripped_dark_oak_log
setblock 533 64 363 minecraft:stripped_dark_oak_log
fill 536 64 357 536 72 357 minecraft:red_concrete
setblock 540 64 323 minecraft:stripped_dark_oak_log
setblock 540 64 363 minecraft:stripped_dark_oak_log
fill 544 64 357 544 72 357 minecraft:red_concrete
setblock 547 64 323 minecraft:stripped_dark_oak_log
setblock 547 64 363 minecraft:stripped_dark_oak_log
setblock 554 64 323 minecraft:stripped_dark_oak_log
setblock 554 64 363 minecraft:stripped_dark_oak_log
setblock 558 64 326 minecraft:stripped_dark_oak_log
setblock 558 64 333 minecraft:stripped_dark_oak_log
setblock 558 64 340 minecraft:stripped_dark_oak_log
setblock 558 64 347 minecraft:stripped_dark_oak_log
setblock 558 64 354 minecraft:stripped_dark_oak_log
setblock 558 64 361 minecraft:stripped_dark_oak_log
setblock 518 65 323 minecraft:stripped_dark_oak_log
setblock 518 65 330 minecraft:stripped_dark_oak_log
setblock 518 65 337 minecraft:stripped_dark_oak_log
setblock 518 65 344 minecraft:stripped_dark_oak_log
setblock 518 65 351 minecraft:stripped_dark_oak_log
setblock 518 65 358 minecraft:stripped_dark_oak_log
setblock 520 65 363 minecraft:stripped_dark_oak_log
setblock 525 65 323 minecraft:stripped_dark_oak_log
setblock 527 65 363 minecraft:stripped_dark_oak_log
setblock 532 65 323 minecraft:stripped_dark_oak_log
setblock 534 65 363 minecraft:stripped_dark_oak_log
setblock 539 65 323 minecraft:stripped_dark_oak_log
setblock 541 65 363 minecraft:stripped_dark_oak_log
setblock 546 65 323 minecraft:stripped_dark_oak_log
setblock 548 65 363 minecraft:stripped_dark_oak_log
setblock 553 65 323 minecraft:stripped_dark_oak_log
setblock 555 65 363 minecraft:stripped_dark_oak_log
setblock 558 65 325 minecraft:stripped_dark_oak_log
setblock 558 65 332 minecraft:stripped_dark_oak_log
setblock 558 65 339 minecraft:stripped_dark_oak_log
setblock 558 65 346 minecraft:stripped_dark_oak_log
setblock 558 65 353 minecraft:stripped_dark_oak_log
setblock 558 65 360 minecraft:stripped_dark_oak_log
setblock 518 66 324 minecraft:stripped_dark_oak_log
setblock 518 66 331 minecraft:stripped_dark_oak_log
setblock 518 66 338 minecraft:stripped_dark_oak_log
setblock 518 66 345 minecraft:stripped_dark_oak_log
setblock 518 66 352 minecraft:stripped_dark_oak_log
setblock 518 66 359 minecraft:stripped_dark_oak_log
setblock 521 66 363 minecraft:stripped_dark_oak_log
setblock 524 66 323 minecraft:stripped_dark_oak_log
setblock 528 66 363 minecraft:stripped_dark_oak_log
setblock 531 66 323 minecraft:stripped_dark_oak_log
setblock 535 66 363 minecraft:stripped_dark_oak_log
setblock 538 66 323 minecraft:stripped_dark_oak_log
setblock 542 66 363 minecraft:stripped_dark_oak_log
setblock 545 66 323 minecraft:stripped_dark_oak_log
setblock 549 66 363 minecraft:stripped_dark_oak_log
setblock 552 66 323 minecraft:stripped_dark_oak_log
setblock 556 66 363 minecraft:stripped_dark_oak_log
setblock 558 66 324 minecraft:stripped_dark_oak_log
setblock 558 66 331 minecraft:stripped_dark_oak_log
setblock 558 66 338 minecraft:stripped_dark_oak_log
setblock 558 66 345 minecraft:stripped_dark_oak_log
setblock 558 66 352 minecraft:stripped_dark_oak_log
setblock 558 66 359 minecraft:stripped_dark_oak_log
setblock 518 67 325 minecraft:stripped_dark_oak_log
setblock 518 67 332 minecraft:stripped_dark_oak_log
setblock 518 67 339 minecraft:stripped_dark_oak_log
setblock 518 67 346 minecraft:stripped_dark_oak_log
setblock 518 67 353 minecraft:stripped_dark_oak_log
setblock 518 67 360 minecraft:stripped_dark_oak_log
setblock 522 67 363 minecraft:stripped_dark_oak_log
setblock 523 67 323 minecraft:stripped_dark_oak_log
setblock 529 67 363 minecraft:stripped_dark_oak_log
setblock 530 67 323 minecraft:stripped_dark_oak_log
setblock 536 67 363 minecraft:stripped_dark_oak_log
setblock 537 67 323 minecraft:stripped_dark_oak_log
setblock 543 67 363 minecraft:stripped_dark_oak_log
setblock 544 67 323 minecraft:stripped_dark_oak_log
setblock 550 67 363 minecraft:stripped_dark_oak_log
setblock 551 67 323 minecraft:stripped_dark_oak_log
setblock 557 67 363 minecraft:stripped_dark_oak_log
setblock 558 67 323 minecraft:stripped_dark_oak_log
setblock 558 67 330 minecraft:stripped_dark_oak_log
setblock 558 67 337 minecraft:stripped_dark_oak_log
setblock 558 67 344 minecraft:stripped_dark_oak_log
setblock 558 67 351 minecraft:stripped_dark_oak_log
setblock 558 67 358 minecraft:stripped_dark_oak_log
setblock 518 68 326 minecraft:stripped_dark_oak_log
setblock 518 68 333 minecraft:stripped_dark_oak_log
setblock 518 68 340 minecraft:stripped_dark_oak_log
setblock 518 68 347 minecraft:stripped_dark_oak_log
setblock 518 68 354 minecraft:stripped_dark_oak_log
setblock 518 68 361 minecraft:stripped_dark_oak_log
setblock 520 68 325 minecraft:light[level=14]
setblock 520 68 333 minecraft:light[level=14]
setblock 520 68 341 minecraft:light[level=14]
setblock 520 68 349 minecraft:light[level=14]
setblock 520 68 357 minecraft:light[level=14]
setblock 522 68 323 minecraft:stripped_dark_oak_log
setblock 523 68 363 minecraft:stripped_dark_oak_log
setblock 528 68 325 minecraft:light[level=14]
setblock 528 68 333 minecraft:light[level=14]
setblock 528 68 341 minecraft:light[level=14]
setblock 528 68 349 minecraft:light[level=14]
setblock 528 68 357 minecraft:light[level=14]
setblock 529 68 323 minecraft:stripped_dark_oak_log
setblock 530 68 363 minecraft:stripped_dark_oak_log
setblock 536 68 323 minecraft:stripped_dark_oak_log
setblock 536 68 325 minecraft:light[level=14]
setblock 536 68 333 minecraft:light[level=14]
setblock 536 68 341 minecraft:light[level=14]
setblock 536 68 349 minecraft:light[level=14]
setblock 537 68 363 minecraft:stripped_dark_oak_log
setblock 543 68 323 minecraft:stripped_dark_oak_log
setblock 544 68 325 minecraft:light[level=14]
setblock 544 68 333 minecraft:light[level=14]
setblock 544 68 341 minecraft:light[level=14]
setblock 544 68 349 minecraft:light[level=14]
setblock 544 68 363 minecraft:stripped_dark_oak_log
setblock 550 68 323 minecraft:stripped_dark_oak_log
setblock 551 68 363 minecraft:stripped_dark_oak_log
setblock 552 68 325 minecraft:light[level=14]
setblock 552 68 333 minecraft:light[level=14]
setblock 552 68 341 minecraft:light[level=14]
setblock 552 68 349 minecraft:light[level=14]
setblock 552 68 357 minecraft:light[level=14]
setblock 557 68 323 minecraft:stripped_dark_oak_log
setblock 558 68 329 minecraft:stripped_dark_oak_log
setblock 558 68 336 minecraft:stripped_dark_oak_log
setblock 558 68 343 minecraft:stripped_dark_oak_log
setblock 558 68 350 minecraft:stripped_dark_oak_log
setblock 558 68 357 minecraft:stripped_dark_oak_log
setblock 558 68 363 minecraft:stripped_dark_oak_log
fill 518 69 327 518 70 327 minecraft:stripped_dark_oak_log
fill 518 69 334 518 70 334 minecraft:stripped_dark_oak_log
fill 518 69 341 518 70 341 minecraft:stripped_dark_oak_log
fill 518 69 348 518 70 348 minecraft:stripped_dark_oak_log
fill 518 69 355 518 70 355 minecraft:stripped_dark_oak_log
fill 518 69 362 518 70 362 minecraft:stripped_dark_oak_log
fill 521 69 323 521 70 323 minecraft:stripped_dark_oak_log
fill 524 69 363 524 70 363 minecraft:stripped_dark_oak_log
fill 528 69 323 528 70 323 minecraft:stripped_dark_oak_log
fill 531 69 363 531 70 363 minecraft:stripped_dark_oak_log
fill 535 69 323 535 70 323 minecraft:stripped_dark_oak_log
fill 538 69 363 538 70 363 minecraft:stripped_dark_oak_log
fill 542 69 323 542 70 323 minecraft:stripped_dark_oak_log
fill 545 69 363 545 70 363 minecraft:stripped_dark_oak_log
fill 549 69 323 549 70 323 minecraft:stripped_dark_oak_log
fill 552 69 363 552 70 363 minecraft:stripped_dark_oak_log
fill 556 69 323 556 70 323 minecraft:stripped_dark_oak_log
fill 558 69 328 558 70 328 minecraft:stripped_dark_oak_log
fill 558 69 335 558 70 335 minecraft:stripped_dark_oak_log
fill 558 69 342 558 70 342 minecraft:stripped_dark_oak_log
fill 558 69 349 558 70 349 minecraft:stripped_dark_oak_log
fill 558 69 356 558 70 356 minecraft:stripped_dark_oak_log
fill 518 70 323 518 70 326 minecraft:stripped_dark_oak_log
fill 518 70 329 518 70 333 minecraft:stripped_dark_oak_log
fill 518 70 336 518 70 340 minecraft:stripped_dark_oak_log
fill 518 70 343 518 70 347 minecraft:stripped_dark_oak_log
fill 518 70 350 518 70 354 minecraft:stripped_dark_oak_log
fill 518 70 357 518 70 361 minecraft:stripped_dark_oak_log
fill 519 70 323 519 71 323 minecraft:stripped_dark_oak_log
fill 519 70 363 523 70 363 minecraft:stripped_dark_oak_log
fill 522 70 323 526 70 323 minecraft:stripped_dark_oak_log
fill 526 70 363 530 70 363 minecraft:stripped_dark_oak_log
fill 529 70 323 533 70 323 minecraft:stripped_dark_oak_log
fill 533 70 363 537 70 363 minecraft:stripped_dark_oak_log
fill 535 70 357 535 71 357 minecraft:red_concrete
fill 536 70 323 540 70 323 minecraft:stripped_dark_oak_log
fill 537 70 357 543 71 357 minecraft:red_concrete
fill 540 70 363 544 70 363 minecraft:stripped_dark_oak_log
fill 543 70 323 547 70 323 minecraft:stripped_dark_oak_log
fill 545 70 357 545 71 357 minecraft:red_concrete
fill 547 70 363 551 70 363 minecraft:stripped_dark_oak_log
fill 550 70 323 554 70 323 minecraft:stripped_dark_oak_log
fill 554 70 363 558 70 363 minecraft:stripped_dark_oak_log
fill 557 70 323 558 70 323 minecraft:stripped_dark_oak_log
fill 558 70 324 558 70 326 minecraft:stripped_dark_oak_log
fill 558 70 329 558 70 333 minecraft:stripped_dark_oak_log
fill 558 70 336 558 70 340 minecraft:stripped_dark_oak_log
fill 558 70 343 558 70 347 minecraft:stripped_dark_oak_log
fill 558 70 350 558 70 354 minecraft:stripped_dark_oak_log
fill 558 70 357 558 70 361 minecraft:stripped_dark_oak_log
setblock 518 71 329 minecraft:stripped_dark_oak_log
setblock 518 71 336 minecraft:stripped_dark_oak_log
setblock 518 71 343 minecraft:stripped_dark_oak_log
setblock 518 71 350 minecraft:stripped_dark_oak_log
setblock 518 71 357 minecraft:stripped_dark_oak_log
setblock 519 71 363 minecraft:stripped_dark_oak_log
setblock 526 71 323 minecraft:stripped_dark_oak_log
setblock 526 71 363 minecraft:stripped_dark_oak_log
setblock 533 71 323 minecraft:stripped_dark_oak_log
setblock 533 71 363 minecraft:stripped_dark_oak_log
setblock 540 71 323 minecraft:stripped_dark_oak_log
setblock 540 71 363 minecraft:stripped_dark_oak_log
setblock 547 71 323 minecraft:stripped_dark_oak_log
setblock 547 71 363 minecraft:stripped_dark_oak_log
setblock 554 71 323 minecraft:stripped_dark_oak_log
setblock 554 71 363 minecraft:stripped_dark_oak_log
setblock 558 71 326 minecraft:stripped_dark_oak_log
setblock 558 71 333 minecraft:stripped_dark_oak_log
setblock 558 71 340 minecraft:stripped_dark_oak_log
setblock 558 71 347 minecraft:stripped_dark_oak_log
setblock 558 71 354 minecraft:stripped_dark_oak_log
setblock 558 71 361 minecraft:stripped_dark_oak_log
setblock 518 72 323 minecraft:stripped_dark_oak_log
setblock 518 72 330 minecraft:stripped_dark_oak_log
setblock 518 72 337 minecraft:stripped_dark_oak_log
setblock 518 72 344 minecraft:stripped_dark_oak_log
setblock 518 72 351 minecraft:stripped_dark_oak_log
setblock 518 72 358 minecraft:stripped_dark_oak_log
setblock 520 72 363 minecraft:stripped_dark_oak_log
setblock 525 72 323 minecraft:stripped_dark_oak_log
setblock 527 72 363 minecraft:stripped_dark_oak_log
setblock 532 72 323 minecraft:stripped_dark_oak_log
fill 534 72 357 535 72 357 minecraft:black_concrete
setblock 534 72 363 minecraft:stripped_dark_oak_log
fill 537 72 357 543 72 357 minecraft:black_concrete
fill 538 72 361 544 72 361 minecraft:iron_bars
setblock 539 72 323 minecraft:stripped_dark_oak_log
setblock 541 72 363 minecraft:stripped_dark_oak_log
fill 545 72 357 546 72 357 minecraft:black_concrete
setblock 546 72 323 minecraft:stripped_dark_oak_log
setblock 548 72 363 minecraft:stripped_dark_oak_log
setblock 553 72 323 minecraft:stripped_dark_oak_log
setblock 555 72 363 minecraft:stripped_dark_oak_log
setblock 558 72 325 minecraft:stripped_dark_oak_log
setblock 558 72 332 minecraft:stripped_dark_oak_log
setblock 558 72 339 minecraft:stripped_dark_oak_log
setblock 558 72 346 minecraft:stripped_dark_oak_log
setblock 558 72 353 minecraft:stripped_dark_oak_log
setblock 558 72 360 minecraft:stripped_dark_oak_log
setblock 520 76 325 minecraft:light[level=14]
setblock 520 76 333 minecraft:light[level=14]
setblock 520 76 341 minecraft:light[level=14]
setblock 520 76 349 minecraft:light[level=14]
setblock 520 76 357 minecraft:light[level=14]
setblock 528 76 325 minecraft:light[level=14]
setblock 528 76 333 minecraft:light[level=14]
setblock 528 76 341 minecraft:light[level=14]
setblock 528 76 349 minecraft:light[level=14]
setblock 528 76 357 minecraft:light[level=14]
setblock 536 76 325 minecraft:light[level=14]
setblock 536 76 333 minecraft:light[level=14]
setblock 536 76 341 minecraft:light[level=14]
setblock 536 76 349 minecraft:light[level=14]
setblock 536 76 357 minecraft:light[level=14]
setblock 544 76 325 minecraft:light[level=14]
setblock 544 76 333 minecraft:light[level=14]
setblock 544 76 341 minecraft:light[level=14]
setblock 544 76 349 minecraft:light[level=14]
setblock 544 76 357 minecraft:light[level=14]
setblock 552 76 325 minecraft:light[level=14]
setblock 552 76 333 minecraft:light[level=14]
setblock 552 76 341 minecraft:light[level=14]
setblock 552 76 349 minecraft:light[level=14]
setblock 552 76 357 minecraft:light[level=14]
fill 523 78 342 528 79 342 minecraft:dark_oak_planks
fill 524 78 337 528 79 341 minecraft:dark_oak_planks
fill 524 78 343 527 79 347 minecraft:dark_oak_planks
fill 525 78 335 525 79 335 minecraft:red_concrete
fill 525 78 336 541 79 336 minecraft:dark_oak_planks
fill 525 78 348 527 79 349 minecraft:dark_oak_planks
fill 526 78 333 526 79 334 minecraft:red_concrete
fill 526 78 335 541 79 335 minecraft:dark_oak_planks
fill 526 78 350 527 79 351 minecraft:dark_oak_planks
fill 527 78 332 528 79 333 minecraft:red_concrete
fill 527 78 334 540 79 334 minecraft:dark_oak_planks
fill 527 78 352 528 79 352 minecraft:dark_oak_planks
fill 528 78 331 543 79 331 minecraft:red_concrete
fill 528 78 343 531 79 351 minecraft:red_concrete
fill 528 78 353 528 79 353 minecraft:dark_oak_planks
fill 529 78 330 541 79 330 minecraft:red_concrete
fill 529 78 332 530 79 332 minecraft:red_concrete
fill 529 78 333 539 79 333 minecraft:dark_oak_planks
fill 529 78 337 529 79 340 minecraft:dark_oak_planks
fill 529 78 341 532 79 342 minecraft:red_concrete
fill 529 78 352 532 79 353 minecraft:red_concrete
fill 529 78 354 529 79 354 minecraft:dark_oak_planks
fill 530 78 329 540 79 329 minecraft:red_concrete
fill 530 78 337 530 79 339 minecraft:dark_oak_planks
fill 530 78 340 536 79 340 minecraft:red_concrete
fill 530 78 354 534 79 355 minecraft:red_concrete
fill 531 78 332 537 79 332 minecraft:dark_oak_planks
fill 531 78 337 532 79 338 minecraft:dark_oak_planks
fill 531 78 339 537 79 339 minecraft:red_concrete
fill 532 78 328 537 79 328 minecraft:red_concrete
fill 532 78 343 535 79 350 minecraft:dark_oak_planks
fill 532 78 351 532 79 351 minecraft:red_concrete
fill 532 78 356 536 79 356 minecraft:red_concrete
fill 533 78 337 542 79 337 minecraft:dark_oak_planks
fill 533 78 338 537 79 338 minecraft:red_concrete
fill 533 78 341 533 79 341 minecraft:red_concrete
fill 533 78 342 535 79 342 minecraft:dark_oak_planks
fill 533 78 351 541 79 352 minecraft:dark_oak_planks
fill 533 78 353 533 79 353 minecraft:red_concrete
fill 534 78 327 544 79 327 minecraft:dark_oak_planks
fill 534 78 341 535 79 341 minecraft:dark_oak_planks
fill 534 78 353 550 79 353 minecraft:dark_oak_planks
fill 534 78 357 539 79 357 minecraft:red_concrete
fill 535 78 354 549 79 354 minecraft:dark_oak_planks
fill 535 78 355 535 79 355 minecraft:red_concrete
fill 536 78 341 536 79 343 minecraft:shroomlight
fill 536 78 344 536 79 350 minecraft:dark_oak_planks
fill 536 78 355 548 79 355 minecraft:dark_oak_planks
fill 537 78 340 537 79 341 minecraft:shroomlight
fill 537 78 343 537 79 344 minecraft:shroomlight
fill 537 78 345 537 79 347 minecraft:red_concrete
fill 537 78 348 537 79 350 minecraft:dark_oak_planks
fill 537 78 356 546 79 356 minecraft:dark_oak_planks
fill 538 78 328 546 79 328 minecraft:dark_oak_planks
fill 538 78 332 543 79 332 minecraft:red_concrete
fill 538 78 338 542 79 338 minecraft:dark_oak_planks
fill 538 78 339 538 79 340 minecraft:shroomlight
fill 538 78 344 538 79 345 minecraft:shroomlight
fill 538 78 346 539 79 349 minecraft:red_concrete
fill 538 78 350 539 79 350 minecraft:dark_oak_planks
fill 539 78 326 539 79 326 minecraft:dark_oak_planks
fill 539 78 339 540 79 339 minecraft:shroomlight
fill 539 78 345 540 79 345 minecraft:shroomlight
fill 539 78 358 539 79 358 minecraft:red_concrete
fill 540 78 333 544 79 333 minecraft:red_concrete
fill 540 78 340 541 79 340 minecraft:shroomlight
fill 540 78 344 541 79 344 minecraft:shroomlight
fill 540 78 346 547 79 346 minecraft:dark_oak_planks
fill 540 78 347 540 79 350 minecraft:red_concrete
fill 540 78 357 544 79 357 minecraft:dark_oak_planks
fill 541 78 329 548 79 329 minecraft:dark_oak_planks
fill 541 78 334 545 79 334 minecraft:red_concrete
fill 541 78 339 542 79 339 minecraft:dark_oak_planks
fill 541 78 341 542 79 341 minecraft:shroomlight
fill 541 78 343 542 79 343 minecraft:shroomlight
fill 541 78 345 549 79 345 minecraft:dark_oak_planks
fill 541 78 347 546 79 347 minecraft:dark_oak_planks
fill 541 78 348 548 79 350 minecraft:red_concrete
fill 542 78 330 549 79 330 minecraft:dark_oak_planks
fill 542 78 335 545 79 336 minecraft:red_concrete
fill 542 78 340 542 79 340 minecraft:dark_oak_planks
fill 542 78 342 542 79 342 minecraft:shroomlight
fill 542 78 344 549 79 344 minecraft:dark_oak_planks
fill 542 78 351 546 79 351 minecraft:red_concrete
fill 542 78 352 551 79 352 minecraft:dark_oak_planks
fill 543 78 337 544 79 342 minecraft:red_concrete
fill 543 78 343 550 79 343 minecraft:dark_oak_planks
fill 544 78 331 550 79 332 minecraft:dark_oak_planks
fill 545 78 333 551 79 333 minecraft:dark_oak_planks
fill 545 78 337 545 79 340 minecraft:red_concrete
fill 545 78 341 551 79 342 minecraft:dark_oak_planks
fill 546 78 334 551 79 340 minecraft:dark_oak_planks
fill 547 78 347 552 79 347 minecraft:red_concrete
fill 547 78 351 552 79 351 minecraft:dark_oak_planks
fill 548 78 346 553 79 346 minecraft:red_concrete
fill 549 78 348 550 79 349 minecraft:red_concrete
fill 549 78 350 552 79 350 minecraft:dark_oak_planks
fill 550 78 344 554 79 345 minecraft:red_concrete
fill 551 78 332 551 79 332 minecraft:dark_oak_planks
fill 551 78 343 554 79 343 minecraft:red_concrete
fill 551 78 348 551 79 348 minecraft:red_concrete
fill 551 78 349 553 79 349 minecraft:dark_oak_planks
fill 552 78 333 552 79 334 minecraft:red_concrete
fill 552 78 335 552 79 338 minecraft:dark_oak_planks
fill 552 78 339 554 79 342 minecraft:red_concrete
fill 552 78 348 553 79 348 minecraft:dark_oak_planks
fill 553 78 335 553 79 338 minecraft:red_concrete
fill 553 78 347 554 79 347 minecraft:dark_oak_planks
fill 554 78 337 554 79 338 minecraft:red_concrete
fill 554 78 346 554 79 346 minecraft:dark_oak_planks
fill 555 78 342 555 79 342 minecraft:red_concrete
fill 518 79 323 522 79 363 minecraft:dark_oak_planks
fill 523 79 323 523 79 341 minecraft:dark_oak_planks
fill 523 79 343 523 79 363 minecraft:dark_oak_planks
fill 524 79 323 524 79 336 minecraft:dark_oak_planks
fill 524 79 348 524 79 363 minecraft:dark_oak_planks
fill 525 79 323 525 79 334 minecraft:dark_oak_planks
fill 525 79 350 525 79 363 minecraft:dark_oak_planks
fill 526 79 323 526 79 332 minecraft:dark_oak_planks
fill 526 79 352 526 79 363 minecraft:dark_oak_planks
fill 527 79 323 527 79 331 minecraft:dark_oak_planks
fill 527 79 353 527 79 363 minecraft:dark_oak_planks
fill 528 79 323 528 79 330 minecraft:dark_oak_planks
fill 528 79 354 528 79 363 minecraft:dark_oak_planks
fill 529 79 323 529 79 329 minecraft:dark_oak_planks
fill 529 79 355 529 79 363 minecraft:dark_oak_planks
fill 530 79 323 531 79 328 minecraft:dark_oak_planks
fill 530 79 356 531 79 363 minecraft:dark_oak_planks
fill 532 79 323 533 79 327 minecraft:dark_oak_planks
fill 532 79 357 533 79 363 minecraft:dark_oak_planks
fill 534 79 323 538 79 326 minecraft:dark_oak_planks
fill 534 79 358 538 79 363 minecraft:dark_oak_planks
fill 539 79 323 558 79 325 minecraft:dark_oak_planks
fill 539 79 359 558 79 363 minecraft:dark_oak_planks
fill 540 79 326 558 79 326 minecraft:dark_oak_planks
fill 540 79 358 558 79 358 minecraft:dark_oak_planks
fill 545 79 327 558 79 327 minecraft:dark_oak_planks
fill 545 79 357 558 79 357 minecraft:dark_oak_planks
fill 547 79 328 558 79 328 minecraft:dark_oak_planks
fill 547 79 356 558 79 356 minecraft:dark_oak_planks
fill 549 79 329 558 79 329 minecraft:dark_oak_planks
fill 549 79 355 558 79 355 minecraft:dark_oak_planks
fill 550 79 330 558 79 330 minecraft:dark_oak_planks
fill 550 79 354 558 79 354 minecraft:dark_oak_planks
fill 551 79 331 558 79 331 minecraft:dark_oak_planks
fill 551 79 353 558 79 353 minecraft:dark_oak_planks
fill 552 79 332 558 79 332 minecraft:dark_oak_planks
fill 552 79 352 558 79 352 minecraft:dark_oak_planks
fill 553 79 333 558 79 334 minecraft:dark_oak_planks
fill 553 79 350 558 79 351 minecraft:dark_oak_planks
fill 554 79 335 558 79 336 minecraft:dark_oak_planks
fill 554 79 348 558 79 349 minecraft:dark_oak_planks
fill 555 79 337 558 79 341 minecraft:dark_oak_planks
fill 555 79 343 558 79 347 minecraft:dark_oak_planks
fill 556 79 342 558 79 342 minecraft:dark_oak_planks
fill 518 83 327 518 83 328 minecraft:stripped_dark_oak_log
fill 518 83 334 518 83 335 minecraft:stripped_dark_oak_log
fill 518 83 341 518 83 342 minecraft:stripped_dark_oak_log
fill 518 83 348 518 83 349 minecraft:stripped_dark_oak_log
fill 518 83 355 518 83 356 minecraft:stripped_dark_oak_log
fill 518 83 362 518 83 363 minecraft:stripped_dark_oak_log
fill 520 83 323 521 83 323 minecraft:stripped_dark_oak_log
fill 524 83 363 525 83 363 minecraft:stripped_dark_oak_log
fill 527 83 323 528 83 323 minecraft:stripped_dark_oak_log
fill 531 83 363 532 83 363 minecraft:stripped_dark_oak_log
fill 534 83 323 535 83 323 minecraft:stripped_dark_oak_log
fill 538 83 363 539 83 363 minecraft:stripped_dark_oak_log
fill 541 83 323 542 83 323 minecraft:stripped_dark_oak_log
fill 545 83 363 546 83 363 minecraft:stripped_dark_oak_log
fill 548 83 323 549 83 323 minecraft:stripped_dark_oak_log
fill 551 83 324 558 84 332 minecraft:stripped_dark_oak_log
fill 552 83 363 553 83 363 minecraft:stripped_dark_oak_log
fill 553 83 349 558 84 359 minecraft:stripped_dark_oak_log
fill 555 83 323 556 83 323 minecraft:stripped_dark_oak_log
fill 558 83 334 558 83 335 minecraft:stripped_dark_oak_log
fill 558 83 341 558 83 342 minecraft:stripped_dark_oak_log
fill 558 83 348 558 150 348 minecraft:stripped_dark_oak_log
fill 558 83 362 558 150 362 minecraft:stripped_dark_oak_log
fill 518 84 328 518 150 328 minecraft:stripped_dark_oak_log
fill 518 84 335 518 150 335 minecraft:stripped_dark_oak_log
fill 518 84 342 518 150 342 minecraft:stripped_dark_oak_log
fill 518 84 349 518 150 349 minecraft:stripped_dark_oak_log
fill 518 84 356 518 150 356 minecraft:stripped_dark_oak_log
fill 518 84 363 518 150 363 minecraft:stripped_dark_oak_log
fill 520 84 323 520 150 323 minecraft:stripped_dark_oak_log
setblock 520 84 325 minecraft:light[level=14]
setblock 520 84 333 minecraft:light[level=14]
setblock 520 84 341 minecraft:light[level=14]
setblock 520 84 349 minecraft:light[level=14]
setblock 520 84 357 minecraft:light[level=14]
fill 525 84 363 525 150 363 minecraft:stripped_dark_oak_log
fill 527 84 323 527 150 323 minecraft:stripped_dark_oak_log
setblock 528 84 325 minecraft:light[level=14]
setblock 528 84 333 minecraft:light[level=14]
setblock 528 84 341 minecraft:light[level=14]
setblock 528 84 349 minecraft:light[level=14]
setblock 528 84 357 minecraft:light[level=14]
fill 532 84 363 532 150 363 minecraft:stripped_dark_oak_log
fill 534 84 323 534 150 323 minecraft:stripped_dark_oak_log
setblock 536 84 325 minecraft:light[level=14]
setblock 536 84 333 minecraft:light[level=14]
setblock 536 84 341 minecraft:light[level=14]
setblock 536 84 349 minecraft:light[level=14]
setblock 536 84 357 minecraft:light[level=14]
fill 539 84 363 539 150 363 minecraft:stripped_dark_oak_log
fill 541 84 323 541 150 323 minecraft:stripped_dark_oak_log
setblock 544 84 325 minecraft:light[level=14]
setblock 544 84 333 minecraft:light[level=14]
setblock 544 84 341 minecraft:light[level=14]
setblock 544 84 349 minecraft:light[level=14]
setblock 544 84 357 minecraft:light[level=14]
fill 546 84 363 546 150 363 minecraft:stripped_dark_oak_log
fill 548 84 323 548 150 323 minecraft:stripped_dark_oak_log
setblock 552 84 333 minecraft:light[level=14]
setblock 552 84 341 minecraft:light[level=14]
setblock 552 84 349 minecraft:light[level=14]
setblock 552 84 357 minecraft:light[level=14]
fill 553 84 363 553 150 363 minecraft:stripped_dark_oak_log
fill 555 84 323 555 150 323 minecraft:stripped_dark_oak_log
fill 556 84 335 556 97 335 minecraft:red_wool
fill 558 84 334 558 150 334 minecraft:stripped_dark_oak_log
fill 558 84 341 558 150 341 minecraft:stripped_dark_oak_log
setblock 518 85 329 minecraft:stripped_dark_oak_log
setblock 518 85 336 minecraft:stripped_dark_oak_log
setblock 518 85 343 minecraft:stripped_dark_oak_log
setblock 518 85 350 minecraft:stripped_dark_oak_log
setblock 518 85 357 minecraft:stripped_dark_oak_log
setblock 519 85 323 minecraft:stripped_dark_oak_log
setblock 519 85 363 minecraft:stripped_dark_oak_log
setblock 526 85 323 minecraft:stripped_dark_oak_log
setblock 526 85 363 minecraft:stripped_dark_oak_log
setblock 533 85 323 minecraft:stripped_dark_oak_log
setblock 533 85 363 minecraft:stripped_dark_oak_log
setblock 540 85 323 minecraft:stripped_dark_oak_log
setblock 540 85 363 minecraft:stripped_dark_oak_log
setblock 547 85 323 minecraft:stripped_dark_oak_log
setblock 547 85 363 minecraft:stripped_dark_oak_log
setblock 551 85 324 minecraft:shroomlight
fill 551 85 325 551 95 325 minecraft:stripped_dark_oak_log
setblock 551 85 326 minecraft:shroomlight
fill 551 85 327 551 95 327 minecraft:stripped_dark_oak_log
setblock 551 85 328 minecraft:shroomlight
fill 551 85 329 551 95 329 minecraft:stripped_dark_oak_log
setblock 551 85 330 minecraft:shroomlight
fill 551 85 331 551 95 331 minecraft:stripped_dark_oak_log
setblock 551 85 332 minecraft:shroomlight
fill 552 85 324 552 95 324 minecraft:stripped_dark_oak_log
setblock 552 85 325 minecraft:shroomlight
fill 552 85 326 552 95 326 minecraft:stripped_dark_oak_log
setblock 552 85 327 minecraft:shroomlight
fill 552 85 328 552 95 328 minecraft:stripped_dark_oak_log
setblock 552 85 329 minecraft:shroomlight
fill 552 85 330 552 95 330 minecraft:stripped_dark_oak_log
setblock 552 85 331 minecraft:shroomlight
fill 552 85 332 552 95 332 minecraft:stripped_dark_oak_log
setblock 553 85 324 minecraft:shroomlight
fill 553 85 325 553 95 325 minecraft:stripped_dark_oak_log
setblock 553 85 326 minecraft:shroomlight
fill 553 85 327 553 95 327 minecraft:stripped_dark_oak_log
setblock 553 85 328 minecraft:shroomlight
fill 553 85 329 553 95 329 minecraft:stripped_dark_oak_log
setblock 553 85 330 minecraft:shroomlight
fill 553 85 331 553 95 331 minecraft:stripped_dark_oak_log
setblock 553 85 332 minecraft:shroomlight
fill 553 85 349 553 101 349 minecraft:stripped_dark_oak_log
setblock 553 85 350 minecraft:shroomlight
fill 553 85 351 553 101 351 minecraft:stripped_dark_oak_log
setblock 553 85 352 minecraft:shroomlight
fill 553 85 353 553 101 353 minecraft:stripped_dark_oak_log
setblock 553 85 354 minecraft:shroomlight
fill 553 85 355 553 101 355 minecraft:stripped_dark_oak_log
setblock 553 85 356 minecraft:shroomlight
fill 553 85 357 553 101 357 minecraft:stripped_dark_oak_log
setblock 553 85 358 minecraft:shroomlight
fill 553 85 359 553 101 359 minecraft:stripped_dark_oak_log
fill 554 85 323 554 85 324 minecraft:stripped_dark_oak_log
setblock 554 85 325 minecraft:shroomlight
fill 554 85 326 554 95 326 minecraft:stripped_dark_oak_log
setblock 554 85 327 minecraft:shroomlight
fill 554 85 328 554 95 328 minecraft:stripped_dark_oak_log
setblock 554 85 329 minecraft:shroomlight
fill 554 85 330 554 95 330 minecraft:stripped_dark_oak_log
setblock 554 85 331 minecraft:shroomlight
fill 554 85 332 554 95 332 minecraft:stripped_dark_oak_log
setblock 554 85 349 minecraft:shroomlight
fill 554 85 350 554 101 350 minecraft:stripped_dark_oak_log
setblock 554 85 351 minecraft:shroomlight
fill 554 85 352 554 101 352 minecraft:stripped_dark_oak_log
setblock 554 85 353 minecraft:shroomlight
fill 554 85 354 554 101 354 minecraft:stripped_dark_oak_log
setblock 554 85 355 minecraft:shroomlight
fill 554 85 356 554 101 356 minecraft:stripped_dark_oak_log
setblock 554 85 357 minecraft:shroomlight
fill 554 85 358 554 101 358 minecraft:stripped_dark_oak_log
setblock 554 85 359 minecraft:shroomlight
setblock 554 85 363 minecraft:stripped_dark_oak_log
setblock 555 85 324 minecraft:shroomlight
fill 555 85 325 555 95 325 minecraft:stripped_dark_oak_log
setblock 555 85 326 minecraft:shroomlight
fill 555 85 327 555 95 327 minecraft:stripped_dark_oak_log
setblock 555 85 328 minecraft:shroomlight
fill 555 85 329 555 95 329 minecraft:stripped_dark_oak_log
setblock 555 85 330 minecraft:shroomlight
fill 555 85 331 555 95 331 minecraft:stripped_dark_oak_log
setblock 555 85 332 minecraft:shroomlight
fill 555 85 349 555 101 349 minecraft:stripped_dark_oak_log
setblock 555 85 350 minecraft:shroomlight
fill 555 85 351 555 101 351 minecraft:stripped_dark_oak_log
setblock 555 85 352 minecraft:shroomlight
fill 555 85 353 555 101 353 minecraft:stripped_dark_oak_log
setblock 555 85 354 minecraft:shroomlight
fill 555 85 355 555 101 355 minecraft:stripped_dark_oak_log
setblock 555 85 356 minecraft:shroomlight
fill 555 85 357 555 101 357 minecraft:stripped_dark_oak_log
setblock 555 85 358 minecraft:shroomlight
fill 555 85 359 555 101 359 minecraft:stripped_dark_oak_log
fill 556 85 324 556 95 324 minecraft:stripped_dark_oak_log
setblock 556 85 325 minecraft:shroomlight
fill 556 85 326 556 95 326 minecraft:stripped_dark_oak_log
setblock 556 85 327 minecraft:shroomlight
fill 556 85 328 556 95 328 minecraft:stripped_dark_oak_log
setblock 556 85 329 minecraft:shroomlight
fill 556 85 330 556 95 330 minecraft:stripped_dark_oak_log
setblock 556 85 331 minecraft:shroomlight
fill 556 85 332 556 95 332 minecraft:stripped_dark_oak_log
fill 556 85 333 556 97 334 minecraft:red_wool
fill 556 85 336 556 97 337 minecraft:red_wool
setblock 556 85 349 minecraft:shroomlight
fill 556 85 350 556 101 350 minecraft:stripped_dark_oak_log
setblock 556 85 351 minecraft:shroomlight
fill 556 85 352 556 101 352 minecraft:stripped_dark_oak_log
setblock 556 85 353 minecraft:shroomlight
fill 556 85 354 556 101 354 minecraft:stripped_dark_oak_log
setblock 556 85 355 minecraft:shroomlight
fill 556 85 356 556 101 356 minecraft:stripped_dark_oak_log
setblock 556 85 357 minecraft:shroomlight
fill 556 85 358 556 101 358 minecraft:stripped_dark_oak_log
setblock 556 85 359 minecraft:shroomlight
setblock 557 85 324 minecraft:shroomlight
fill 557 85 325 557 95 325 minecraft:stripped_dark_oak_log
setblock 557 85 326 minecraft:shroomlight
fill 557 85 327 557 95 327 minecraft:stripped_dark_oak_log
setblock 557 85 328 minecraft:shroomlight
fill 557 85 329 557 95 329 minecraft:stripped_dark_oak_log
setblock 557 85 330 minecraft:shroomlight
fill 557 85 331 557 95 331 minecraft:stripped_dark_oak_log
setblock 557 85 332 minecraft:shroomlight
fill 557 85 349 557 101 349 minecraft:stripped_dark_oak_log
setblock 557 85 350 minecraft:shroomlight
fill 557 85 351 557 101 351 minecraft:stripped_dark_oak_log
setblock 557 85 352 minecraft:shroomlight
fill 557 85 353 557 101 353 minecraft:stripped_dark_oak_log
setblock 557 85 354 minecraft:shroomlight
fill 557 85 355 557 101 355 minecraft:stripped_dark_oak_log
setblock 557 85 356 minecraft:shroomlight
fill 557 85 357 557 101 357 minecraft:stripped_dark_oak_log
setblock 557 85 358 minecraft:shroomlight
fill 557 85 359 557 101 359 minecraft:stripped_dark_oak_log
fill 558 85 324 558 95 324 minecraft:stripped_dark_oak_log
setblock 558 85 325 minecraft:shroomlight
fill 558 85 326 558 95 326 minecraft:stripped_dark_oak_log
setblock 558 85 327 minecraft:shroomlight
fill 558 85 328 558 95 328 minecraft:stripped_dark_oak_log
setblock 558 85 329 minecraft:shroomlight
fill 558 85 330 558 95 330 minecraft:stripped_dark_oak_log
setblock 558 85 331 minecraft:shroomlight
fill 558 85 332 558 85 333 minecraft:stripped_dark_oak_log
setblock 558 85 340 minecraft:stripped_dark_oak_log
setblock 558 85 347 minecraft:stripped_dark_oak_log
setblock 558 85 349 minecraft:shroomlight
fill 558 85 350 558 101 350 minecraft:stripped_dark_oak_log
setblock 558 85 351 minecraft:shroomlight
fill 558 85 352 558 101 352 minecraft:stripped_dark_oak_log
setblock 558 85 353 minecraft:shroomlight
fill 558 85 354 558 101 354 minecraft:stripped_dark_oak_log
setblock 558 85 355 minecraft:shroomlight
fill 558 85 356 558 101 356 minecraft:stripped_dark_oak_log
setblock 558 85 357 minecraft:shroomlight
fill 558 85 358 558 102 358 minecraft:stripped_dark_oak_log
setblock 558 85 359 minecraft:shroomlight
setblock 558 85 361 minecraft:stripped_dark_oak_log
setblock 518 86 323 minecraft:stripped_dark_oak_log
setblock 518 86 330 minecraft:stripped_dark_oak_log
setblock 518 86 337 minecraft:stripped_dark_oak_log
setblock 518 86 344 minecraft:stripped_dark_oak_log
setblock 518 86 351 minecraft:stripped_dark_oak_log
setblock 518 86 358 minecraft:stripped_dark_oak_log
setblock 520 86 363 minecraft:stripped_dark_oak_log
setblock 525 86 323 minecraft:stripped_dark_oak_log
setblock 527 86 363 minecraft:stripped_dark_oak_log
setblock 532 86 323 minecraft:stripped_dark_oak_log
setblock 534 86 363 minecraft:stripped_dark_oak_log
setblock 539 86 323 minecraft:stripped_dark_oak_log
setblock 541 86 363 minecraft:stripped_dark_oak_log
setblock 546 86 323 minecraft:stripped_dark_oak_log
setblock 548 86 363 minecraft:stripped_dark_oak_log
fill 551 86 324 551 87 324 minecraft:stripped_dark_oak_log
fill 551 86 326 551 87 326 minecraft:stripped_dark_oak_log
fill 551 86 328 551 87 328 minecraft:stripped_dark_oak_log
fill 551 86 330 551 87 330 minecraft:stripped_dark_oak_log
fill 551 86 332 551 87 332 minecraft:stripped_dark_oak_log
fill 552 86 325 552 87 325 minecraft:stripped_dark_oak_log
fill 552 86 327 552 87 327 minecraft:stripped_dark_oak_log
fill 552 86 329 552 87 329 minecraft:stripped_dark_oak_log
fill 552 86 331 552 87 331 minecraft:stripped_dark_oak_log
fill 553 86 323 553 86 324 minecraft:stripped_dark_oak_log
fill 553 86 326 553 87 326 minecraft:stripped_dark_oak_log
fill 553 86 328 553 87 328 minecraft:stripped_dark_oak_log
fill 553 86 330 553 87 330 minecraft:stripped_dark_oak_log
fill 553 86 332 553 87 332 minecraft:stripped_dark_oak_log
fill 553 86 350 553 87 350 minecraft:stripped_dark_oak_log
fill 553 86 352 553 87 352 minecraft:stripped_dark_oak_log
fill 553 86 354 553 87 354 minecraft:stripped_dark_oak_log
fill 553 86 356 553 87 356 minecraft:stripped_dark_oak_log
fill 553 86 358 553 87 358 minecraft:stripped_dark_oak_log
fill 554 86 324 554 87 325 minecraft:stripped_dark_oak_log
fill 554 86 327 554 87 327 minecraft:stripped_dark_oak_log
fill 554 86 329 554 87 329 minecraft:stripped_dark_oak_log
fill 554 86 331 554 87 331 minecraft:stripped_dark_oak_log
fill 554 86 349 554 87 349 minecraft:stripped_dark_oak_log
fill 554 86 351 554 87 351 minecraft:stripped_dark_oak_log
fill 554 86 353 554 87 353 minecraft:stripped_dark_oak_log
fill 554 86 355 554 87 355 minecraft:stripped_dark_oak_log
fill 554 86 357 554 87 357 minecraft:stripped_dark_oak_log
fill 554 86 359 554 87 359 minecraft:stripped_dark_oak_log
fill 555 86 324 555 87 324 minecraft:stripped_dark_oak_log
fill 555 86 326 555 87 326 minecraft:stripped_dark_oak_log
fill 555 86 328 555 87 328 minecraft:stripped_dark_oak_log
fill 555 86 330 555 87 330 minecraft:stripped_dark_oak_log
fill 555 86 332 555 87 332 minecraft:stripped_dark_oak_log
fill 555 86 350 555 87 350 minecraft:stripped_dark_oak_log
fill 555 86 352 555 87 352 minecraft:stripped_dark_oak_log
fill 555 86 354 555 87 354 minecraft:stripped_dark_oak_log
fill 555 86 356 555 87 356 minecraft:stripped_dark_oak_log
fill 555 86 358 555 87 358 minecraft:stripped_dark_oak_log
setblock 555 86 363 minecraft:stripped_dark_oak_log
fill 556 86 325 556 87 325 minecraft:stripped_dark_oak_log
fill 556 86 327 556 87 327 minecraft:stripped_dark_oak_log
fill 556 86 329 556 87 329 minecraft:stripped_dark_oak_log
fill 556 86 331 556 87 331 minecraft:stripped_dark_oak_log
fill 556 86 349 556 87 349 minecraft:stripped_dark_oak_log
fill 556 86 351 556 87 351 minecraft:stripped_dark_oak_log
fill 556 86 353 556 87 353 minecraft:stripped_dark_oak_log
fill 556 86 355 556 87 355 minecraft:stripped_dark_oak_log
fill 556 86 357 556 87 357 minecraft:stripped_dark_oak_log
fill 556 86 359 556 87 359 minecraft:stripped_dark_oak_log
fill 557 86 324 557 87 324 minecraft:stripped_dark_oak_log
fill 557 86 326 557 87 326 minecraft:stripped_dark_oak_log
fill 557 86 328 557 87 328 minecraft:stripped_dark_oak_log
fill 557 86 330 557 87 330 minecraft:stripped_dark_oak_log
fill 557 86 332 558 87 332 minecraft:stripped_dark_oak_log
fill 557 86 350 557 87 350 minecraft:stripped_dark_oak_log
fill 557 86 352 557 87 352 minecraft:stripped_dark_oak_log
fill 557 86 354 557 87 354 minecraft:stripped_dark_oak_log
fill 557 86 356 557 87 356 minecraft:stripped_dark_oak_log
fill 557 86 358 557 87 358 minecraft:stripped_dark_oak_log
fill 558 86 325 558 87 325 minecraft:stripped_dark_oak_log
fill 558 86 327 558 87 327 minecraft:stripped_dark_oak_log
fill 558 86 329 558 87 329 minecraft:stripped_dark_oak_log
fill 558 86 331 558 87 331 minecraft:stripped_dark_oak_log
setblock 558 86 339 minecraft:stripped_dark_oak_log
setblock 558 86 346 minecraft:stripped_dark_oak_log
fill 558 86 349 558 87 349 minecraft:stripped_dark_oak_log
fill 558 86 351 558 87 351 minecraft:stripped_dark_oak_log
fill 558 86 353 558 87 353 minecraft:stripped_dark_oak_log
fill 558 86 355 558 87 355 minecraft:stripped_dark_oak_log
fill 558 86 357 558 87 357 minecraft:stripped_dark_oak_log
fill 558 86 359 558 86 360 minecraft:stripped_dark_oak_log
setblock 518 87 324 minecraft:stripped_dark_oak_log
setblock 518 87 331 minecraft:stripped_dark_oak_log
setblock 518 87 338 minecraft:stripped_dark_oak_log
setblock 518 87 345 minecraft:stripped_dark_oak_log
setblock 518 87 352 minecraft:stripped_dark_oak_log
setblock 518 87 359 minecraft:stripped_dark_oak_log
setblock 521 87 363 minecraft:stripped_dark_oak_log
setblock 524 87 323 minecraft:stripped_dark_oak_log
setblock 528 87 363 minecraft:stripped_dark_oak_log
setblock 531 87 323 minecraft:stripped_dark_oak_log
setblock 535 87 363 minecraft:stripped_dark_oak_log
setblock 538 87 323 minecraft:stripped_dark_oak_log
setblock 542 87 363 minecraft:stripped_dark_oak_log
setblock 545 87 323 minecraft:stripped_dark_oak_log
setblock 549 87 363 minecraft:stripped_dark_oak_log
setblock 552 87 323 minecraft:stripped_dark_oak_log
setblock 553 87 324 minecraft:stripped_dark_oak_log
setblock 556 87 363 minecraft:stripped_dark_oak_log
setblock 558 87 338 minecraft:stripped_dark_oak_log
setblock 558 87 345 minecraft:stripped_dark_oak_log
setblock 558 87 359 minecraft:stripped_dark_oak_log
setblock 518 88 325 minecraft:stripped_dark_oak_log
setblock 518 88 332 minecraft:stripped_dark_oak_log
setblock 518 88 339 minecraft:stripped_dark_oak_log
setblock 518 88 346 minecraft:stripped_dark_oak_log
setblock 518 88 353 minecraft:stripped_dark_oak_log
setblock 518 88 360 minecraft:stripped_dark_oak_log
setblock 522 88 363 minecraft:stripped_dark_oak_log
setblock 523 88 323 minecraft:stripped_dark_oak_log
setblock 529 88 363 minecraft:stripped_dark_oak_log
setblock 530 88 323 minecraft:stripped_dark_oak_log
setblock 536 88 363 minecraft:stripped_dark_oak_log
setblock 537 88 323 minecraft:stripped_dark_oak_log
setblock 543 88 363 minecraft:stripped_dark_oak_log
setblock 544 88 323 minecraft:stripped_dark_oak_log
setblock 550 88 363 minecraft:stripped_dark_oak_log
setblock 551 88 323 minecraft:stripped_dark_oak_log
setblock 551 88 324 minecraft:shroomlight
setblock 551 88 326 minecraft:shroomlight
setblock 551 88 328 minecraft:shroomlight
setblock 551 88 330 minecraft:shroomlight
setblock 551 88 332 minecraft:shroomlight
setblock 552 88 325 minecraft:shroomlight
setblock 552 88 327 minecraft:shroomlight
setblock 552 88 329 minecraft:shroomlight
setblock 552 88 331 minecraft:shroomlight
setblock 553 88 324 minecraft:shroomlight
setblock 553 88 326 minecraft:shroomlight
setblock 553 88 328 minecraft:shroomlight
setblock 553 88 330 minecraft:shroomlight
setblock 553 88 332 minecraft:shroomlight
setblock 553 88 350 minecraft:shroomlight
setblock 553 88 352 minecraft:shroomlight
setblock 553 88 354 minecraft:shroomlight
setblock 553 88 356 minecraft:shroomlight
setblock 553 88 358 minecraft:shroomlight
fill 554 88 324 554 95 324 minecraft:stripped_dark_oak_log
setblock 554 88 325 minecraft:shroomlight
setblock 554 88 327 minecraft:shroomlight
setblock 554 88 329 minecraft:shroomlight
setblock 554 88 331 minecraft:shroomlight
setblock 554 88 349 minecraft:shroomlight
setblock 554 88 351 minecraft:shroomlight
setblock 554 88 353 minecraft:shroomlight
setblock 554 88 355 minecraft:shroomlight
setblock 554 88 357 minecraft:shroomlight
setblock 554 88 359 minecraft:shroomlight
setblock 555 88 324 minecraft:shroomlight
setblock 555 88 326 minecraft:shroomlight
setblock 555 88 328 minecraft:shroomlight
setblock 555 88 330 minecraft:shroomlight
setblock 555 88 332 minecraft:shroomlight
setblock 555 88 350 minecraft:shroomlight
setblock 555 88 352 minecraft:shroomlight
setblock 555 88 354 minecraft:shroomlight
setblock 555 88 356 minecraft:shroomlight
setblock 555 88 358 minecraft:shroomlight
setblock 556 88 325 minecraft:shroomlight
setblock 556 88 327 minecraft:shroomlight
setblock 556 88 329 minecraft:shroomlight
setblock 556 88 331 minecraft:shroomlight
setblock 556 88 349 minecraft:shroomlight
setblock 556 88 351 minecraft:shroomlight
setblock 556 88 353 minecraft:shroomlight
setblock 556 88 355 minecraft:shroomlight
setblock 556 88 357 minecraft:shroomlight
setblock 556 88 359 minecraft:shroomlight
setblock 557 88 324 minecraft:shroomlight
setblock 557 88 326 minecraft:shroomlight
setblock 557 88 328 minecraft:shroomlight
setblock 557 88 330 minecraft:shroomlight
setblock 557 88 332 minecraft:shroomlight
setblock 557 88 350 minecraft:shroomlight
setblock 557 88 352 minecraft:shroomlight
setblock 557 88 354 minecraft:shroomlight
setblock 557 88 356 minecraft:shroomlight
setblock 557 88 358 minecraft:shroomlight
setblock 557 88 363 minecraft:stripped_dark_oak_log
setblock 558 88 323 minecraft:stripped_dark_oak_log
setblock 558 88 325 minecraft:shroomlight
setblock 558 88 327 minecraft:shroomlight
setblock 558 88 329 minecraft:shroomlight
setblock 558 88 331 minecraft:shroomlight
fill 558 88 332 558 95 332 minecraft:stripped_dark_oak_log
setblock 558 88 337 minecraft:stripped_dark_oak_log
setblock 558 88 344 minecraft:stripped_dark_oak_log
setblock 558 88 349 minecraft:shroomlight
setblock 558 88 351 minecraft:shroomlight
setblock 558 88 353 minecraft:shroomlight
setblock 558 88 355 minecraft:shroomlight
setblock 558 88 357 minecraft:shroomlight
setblock 558 88 359 minecraft:shroomlight
fill 518 89 326 518 90 326 minecraft:stripped_dark_oak_log
fill 518 89 333 518 90 333 minecraft:stripped_dark_oak_log
fill 518 89 340 518 90 340 minecraft:stripped_dark_oak_log
fill 518 89 347 518 90 347 minecraft:stripped_dark_oak_log
fill 518 89 354 518 90 354 minecraft:stripped_dark_oak_log
fill 518 89 361 518 90 361 minecraft:stripped_dark_oak_log
fill 522 89 323 522 90 323 minecraft:stripped_dark_oak_log
fill 523 89 363 523 90 363 minecraft:stripped_dark_oak_log
fill 529 89 323 529 90 323 minecraft:stripped_dark_oak_log
fill 530 89 363 530 90 363 minecraft:stripped_dark_oak_log
fill 536 89 323 536 90 323 minecraft:stripped_dark_oak_log
fill 537 89 363 537 90 363 minecraft:stripped_dark_oak_log
fill 543 89 323 543 90 323 minecraft:stripped_dark_oak_log
fill 544 89 363 544 90 363 minecraft:stripped_dark_oak_log
fill 550 89 323 550 90 323 minecraft:stripped_dark_oak_log
fill 551 89 324 551 90 324 minecraft:stripped_dark_oak_log
fill 551 89 326 551 90 326 minecraft:stripped_dark_oak_log
fill 551 89 328 551 90 328 minecraft:stripped_dark_oak_log
fill 551 89 330 551 90 330 minecraft:stripped_dark_oak_log
fill 551 89 332 551 90 332 minecraft:stripped_dark_oak_log
fill 551 89 363 551 90 363 minecraft:stripped_dark_oak_log
fill 552 89 325 552 90 325 minecraft:stripped_dark_oak_log
fill 552 89 327 552 90 327 minecraft:stripped_dark_oak_log
fill 552 89 329 552 90 329 minecraft:stripped_dark_oak_log
fill 552 89 331 552 90 331 minecraft:stripped_dark_oak_log
fill 553 89 324 553 90 324 minecraft:stripped_dark_oak_log
fill 553 89 326 553 90 326 minecraft:stripped_dark_oak_log
fill 553 89 328 553 90 328 minecraft:stripped_dark_oak_log
fill 553 89 330 553 90 330 minecraft:stripped_dark_oak_log
fill 553 89 332 553 90 332 minecraft:stripped_dark_oak_log
fill 553 89 350 553 90 350 minecraft:stripped_dark_oak_log
fill 553 89 352 553 90 352 minecraft:stripped_dark_oak_log
fill 553 89 354 553 90 354 minecraft:stripped_dark_oak_log
fill 553 89 356 553 90 356 minecraft:stripped_dark_oak_log
fill 553 89 358 553 90 358 minecraft:stripped_dark_oak_log
fill 554 89 325 554 90 325 minecraft:stripped_dark_oak_log
fill 554 89 327 554 90 327 minecraft:stripped_dark_oak_log
fill 554 89 329 554 90 329 minecraft:stripped_dark_oak_log
fill 554 89 331 554 90 331 minecraft:stripped_dark_oak_log
fill 554 89 349 554 90 349 minecraft:stripped_dark_oak_log
fill 554 89 351 554 90 351 minecraft:stripped_dark_oak_log
fill 554 89 353 554 90 353 minecraft:stripped_dark_oak_log
fill 554 89 355 554 90 355 minecraft:stripped_dark_oak_log
fill 554 89 357 554 90 357 minecraft:stripped_dark_oak_log
fill 554 89 359 554 90 359 minecraft:stripped_dark_oak_log
fill 555 89 324 555 90 324 minecraft:stripped_dark_oak_log
fill 555 89 326 555 90 326 minecraft:stripped_dark_oak_log
fill 555 89 328 555 90 328 minecraft:stripped_dark_oak_log
fill 555 89 330 555 90 330 minecraft:stripped_dark_oak_log
fill 555 89 332 555 90 332 minecraft:stripped_dark_oak_log
fill 555 89 350 555 90 350 minecraft:stripped_dark_oak_log
fill 555 89 352 555 90 352 minecraft:stripped_dark_oak_log
fill 555 89 354 555 90 354 minecraft:stripped_dark_oak_log
fill 555 89 356 555 90 356 minecraft:stripped_dark_oak_log
fill 555 89 358 555 90 358 minecraft:stripped_dark_oak_log
fill 556 89 325 556 90 325 minecraft:stripped_dark_oak_log
fill 556 89 327 556 90 327 minecraft:stripped_dark_oak_log
fill 556 89 329 556 90 329 minecraft:stripped_dark_oak_log
fill 556 89 331 556 90 331 minecraft:stripped_dark_oak_log
fill 556 89 349 556 90 349 minecraft:stripped_dark_oak_log
fill 556 89 351 556 90 351 minecraft:stripped_dark_oak_log
fill 556 89 353 556 90 353 minecraft:stripped_dark_oak_log
fill 556 89 355 556 90 355 minecraft:stripped_dark_oak_log
fill 556 89 357 556 90 357 minecraft:stripped_dark_oak_log
fill 556 89 359 556 90 359 minecraft:stripped_dark_oak_log
fill 557 89 323 557 90 324 minecraft:stripped_dark_oak_log
fill 557 89 326 557 90 326 minecraft:stripped_dark_oak_log
fill 557 89 328 557 90 328 minecraft:stripped_dark_oak_log
fill 557 89 330 557 90 330 minecraft:stripped_dark_oak_log
fill 557 89 332 557 90 332 minecraft:stripped_dark_oak_log
fill 557 89 350 557 90 350 minecraft:stripped_dark_oak_log
fill 557 89 352 557 90 352 minecraft:stripped_dark_oak_log
fill 557 89 354 557 90 354 minecraft:stripped_dark_oak_log
fill 557 89 356 557 90 356 minecraft:stripped_dark_oak_log
fill 557 89 358 557 90 358 minecraft:stripped_dark_oak_log
fill 558 89 325 558 90 325 minecraft:stripped_dark_oak_log
fill 558 89 327 558 90 327 minecraft:stripped_dark_oak_log
fill 558 89 329 558 90 329 minecraft:stripped_dark_oak_log
fill 558 89 331 558 90 331 minecraft:stripped_dark_oak_log
fill 558 89 336 558 90 336 minecraft:stripped_dark_oak_log
fill 558 89 343 558 90 343 minecraft:stripped_dark_oak_log
fill 558 89 349 558 90 349 minecraft:stripped_dark_oak_log
fill 558 89 351 558 90 351 minecraft:stripped_dark_oak_log
fill 558 89 353 558 90 353 minecraft:stripped_dark_oak_log
fill 558 89 355 558 90 355 minecraft:stripped_dark_oak_log
fill 558 89 357 558 90 357 minecraft:stripped_dark_oak_log
fill 558 89 359 558 90 359 minecraft:stripped_dark_oak_log
fill 558 89 363 558 90 363 minecraft:stripped_dark_oak_log
fill 517 90 322 517 90 323 minecraft:brown_terracotta
setblock 517 90 324 minecraft:light_gray_terracotta
fill 517 90 325 517 93 331 minecraft:brown_terracotta
fill 517 90 332 517 92 332 minecraft:light_gray_terracotta
fill 517 90 333 517 93 334 minecraft:brown_terracotta
setblock 517 90 335 minecraft:light_gray_terracotta
fill 517 90 336 517 91 337 minecraft:brown_terracotta
setblock 517 90 338 minecraft:light_gray_terracotta
fill 517 90 339 517 91 350 minecraft:brown_terracotta
fill 517 90 351 517 90 352 minecraft:light_gray_terracotta
fill 517 90 353 517 93 355 minecraft:brown_terracotta
setblock 517 90 356 minecraft:light_gray_terracotta
fill 517 90 357 517 90 364 minecraft:brown_terracotta
fill 518 90 322 519 93 322 minecraft:brown_terracotta
fill 518 90 323 518 90 325 minecraft:stripped_dark_oak_log
setblock 518 90 327 minecraft:stripped_dark_oak_log
fill 518 90 329 518 90 332 minecraft:stripped_dark_oak_log
setblock 518 90 334 minecraft:stripped_dark_oak_log
fill 518 90 336 518 90 339 minecraft:stripped_dark_oak_log
setblock 518 90 341 minecraft:stripped_dark_oak_log
fill 518 90 343 518 90 346 minecraft:stripped_dark_oak_log
setblock 518 90 348 minecraft:stripped_dark_oak_log
fill 518 90 350 518 90 353 minecraft:stripped_dark_oak_log
setblock 518 90 355 minecraft:stripped_dark_oak_log
fill 518 90 357 518 90 360 minecraft:stripped_dark_oak_log
setblock 518 90 362 minecraft:stripped_dark_oak_log
fill 518 90 364 527 90 364 minecraft:brown_terracotta
setblock 519 90 323 minecraft:stripped_dark_oak_log
fill 519 90 363 522 90 363 minecraft:stripped_dark_oak_log
setblock 520 90 322 minecraft:light_gray_terracotta
fill 521 90 322 536 91 322 minecraft:brown_terracotta
setblock 521 90 323 minecraft:stripped_dark_oak_log
fill 523 90 323 526 90 323 minecraft:stripped_dark_oak_log
setblock 524 90 363 minecraft:stripped_dark_oak_log
fill 526 90 363 529 90 363 minecraft:stripped_dark_oak_log
setblock 528 90 323 minecraft:stripped_dark_oak_log
setblock 528 90 364 minecraft:light_gray_terracotta
fill 529 90 364 531 93 364 minecraft:brown_terracotta
fill 530 90 323 533 90 323 minecraft:stripped_dark_oak_log
setblock 531 90 363 minecraft:stripped_dark_oak_log
setblock 532 90 364 minecraft:light_gray_terracotta
fill 533 90 363 536 90 363 minecraft:stripped_dark_oak_log
fill 533 90 364 534 91 364 minecraft:brown_terracotta
setblock 535 90 323 minecraft:stripped_dark_oak_log
setblock 535 90 364 minecraft:light_gray_terracotta
fill 536 90 364 538 93 364 minecraft:brown_terracotta
setblock 537 90 322 minecraft:light_gray_terracotta
fill 537 90 323 540 90 323 minecraft:stripped_dark_oak_log
fill 538 90 322 540 93 322 minecraft:brown_terracotta
setblock 538 90 363 minecraft:stripped_dark_oak_log
setblock 539 90 364 minecraft:light_gray_terracotta
fill 540 90 363 543 90 363 minecraft:stripped_dark_oak_log
fill 540 90 364 544 90 364 minecraft:brown_terracotta
fill 541 90 322 542 90 322 minecraft:light_gray_terracotta
setblock 542 90 323 minecraft:stripped_dark_oak_log
fill 543 90 322 550 90 322 minecraft:brown_terracotta
fill 544 90 323 547 90 323 minecraft:stripped_dark_oak_log
setblock 545 90 363 minecraft:stripped_dark_oak_log
setblock 545 90 364 minecraft:light_gray_terracotta
fill 546 90 364 559 90 364 minecraft:brown_terracotta
fill 547 90 363 550 90 363 minecraft:stripped_dark_oak_log
setblock 549 90 323 minecraft:stripped_dark_oak_log
setblock 551 90 322 minecraft:light_gray_terracotta
fill 551 90 323 554 90 323 minecraft:stripped_dark_oak_log
fill 552 90 322 558 90 322 minecraft:brown_terracotta
setblock 552 90 363 minecraft:stripped_dark_oak_log
fill 554 90 363 557 90 363 minecraft:stripped_dark_oak_log
setblock 556 90 323 minecraft:stripped_dark_oak_log
setblock 558 90 323 minecraft:stripped_dark_oak_log
setblock 558 90 333 minecraft:stripped_dark_oak_log
setblock 558 90 335 minecraft:stripped_dark_oak_log
fill 558 90 337 558 90 340 minecraft:stripped_dark_oak_log
setblock 558 90 342 minecraft:stripped_dark_oak_log
fill 558 90 344 558 90 347 minecraft:stripped_dark_oak_log
fill 558 90 360 558 90 361 minecraft:stripped_dark_oak_log
fill 559 90 322 559 90 323 minecraft:light_gray_terracotta
fill 559 90 324 559 90 333 minecraft:brown_terracotta
setblock 559 90 334 minecraft:light_gray_terracotta
fill 559 90 335 559 93 338 minecraft:brown_terracotta
setblock 559 90 339 minecraft:light_gray_terracotta
fill 559 90 340 559 93 342 minecraft:brown_terracotta
setblock 559 90 343 minecraft:light_gray_terracotta
fill 559 90 344 559 90 347 minecraft:brown_terracotta
fill 559 90 348 559 91 348 minecraft:light_gray_terracotta
fill 559 90 349 559 90 356 minecraft:brown_terracotta
setblock 559 90 357 minecraft:light_gray_terracotta
fill 559 90 358 559 93 363 minecraft:brown_terracotta
setblock 517 91 322 minecraft:light_gray_terracotta
fill 517 91 323 517 91 324 minecraft:brown_terracotta
fill 517 91 335 517 93 335 minecraft:brown_terracotta
setblock 517 91 338 minecraft:brown_terracotta
setblock 517 91 351 minecraft:light_gray_terracotta
fill 517 91 352 517 93 352 minecraft:brown_terracotta
fill 517 91 356 517 91 361 minecraft:brown_terracotta
setblock 517 91 362 minecraft:light_gray_terracotta
fill 517 91 363 517 91 364 minecraft:brown_terracotta
fill 518 91 364 519 93 364 minecraft:brown_terracotta
fill 520 91 322 520 93 322 minecraft:brown_terracotta
setblock 520 91 364 minecraft:light_gray_terracotta
setblock 521 91 364 minecraft:brown_terracotta
setblock 522 91 364 minecraft:light_gray_terracotta
fill 523 91 364 525 93 364 minecraft:brown_terracotta
fill 526 91 364 526 92 364 minecraft:light_gray_terracotta
fill 527 91 364 528 93 364 minecraft:brown_terracotta
setblock 532 91 364 minecraft:brown_terracotta
fill 535 91 364 535 93 364 minecraft:brown_terracotta
fill 537 91 322 537 93 322 minecraft:brown_terracotta
fill 539 91 364 541 93 364 minecraft:brown_terracotta
fill 541 91 322 547 91 322 minecraft:brown_terracotta
setblock 542 91 364 minecraft:light_gray_terracotta
fill 543 91 364 548 93 364 minecraft:brown_terracotta
setblock 548 91 322 minecraft:light_gray_terracotta
fill 549 91 322 557 91 322 minecraft:brown_terracotta
setblock 549 91 364 minecraft:light_gray_terracotta
fill 550 91 364 551 93 364 minecraft:brown_terracotta
setblock 551 91 324 minecraft:shroomlight
setblock 551 91 326 minecraft:shroomlight
setblock 551 91 328 minecraft:shroomlight
setblock 551 91 330 minecraft:shroomlight
setblock 551 91 332 minecraft:shroomlight
setblock 552 91 325 minecraft:shroomlight
setblock 552 91 327 minecraft:shroomlight
setblock 552 91 329 minecraft:shroomlight
setblock 552 91 331 minecraft:shroomlight
setblock 552 91 364 minecraft:light_gray_terracotta
setblock 553 91 324 minecraft:shroomlight
setblock 553 91 326 minecraft:shroomlight
setblock 553 91 328 minecraft:shroomlight
setblock 553 91 330 minecraft:shroomlight
setblock 553 91 332 minecraft:shroomlight
setblock 553 91 350 minecraft:shroomlight
setblock 553 91 352 minecraft:shroomlight
setblock 553 91 354 minecraft:shroomlight
setblock 553 91 356 minecraft:shroomlight
setblock 553 91 358 minecraft:shroomlight
fill 553 91 364 555 93 364 minecraft:brown_terracotta
setblock 554 91 325 minecraft:shroomlight
setblock 554 91 327 minecraft:shroomlight
setblock 554 91 329 minecraft:shroomlight
setblock 554 91 331 minecraft:shroomlight
setblock 554 91 349 minecraft:shroomlight
setblock 554 91 351 minecraft:shroomlight
setblock 554 91 353 minecraft:shroomlight
setblock 554 91 355 minecraft:shroomlight
setblock 554 91 357 minecraft:shroomlight
setblock 554 91 359 minecraft:shroomlight
setblock 555 91 324 minecraft:shroomlight
setblock 555 91 326 minecraft:shroomlight
setblock 555 91 328 minecraft:shroomlight
setblock 555 91 330 minecraft:shroomlight
setblock 555 91 332 minecraft:shroomlight
setblock 555 91 350 minecraft:shroomlight
setblock 555 91 352 minecraft:shroomlight
setblock 555 91 354 minecraft:shroomlight
setblock 555 91 356 minecraft:shroomlight
setblock 555 91 358 minecraft:shroomlight
setblock 556 91 325 minecraft:shroomlight
setblock 556 91 327 minecraft:shroomlight
setblock 556 91 329 minecraft:shroomlight
setblock 556 91 331 minecraft:shroomlight
setblock 556 91 349 minecraft:shroomlight
setblock 556 91 351 minecraft:shroomlight
setblock 556 91 353 minecraft:shroomlight
setblock 556 91 355 minecraft:shroomlight
setblock 556 91 357 minecraft:shroomlight
setblock 556 91 359 minecraft:shroomlight
setblock 556 91 364 minecraft:light_gray_terracotta
setblock 557 91 324 minecraft:shroomlight
setblock 557 91 326 minecraft:shroomlight
setblock 557 91 328 minecraft:shroomlight
setblock 557 91 330 minecraft:shroomlight
setblock 557 91 332 minecraft:shroomlight
setblock 557 91 350 minecraft:shroomlight
setblock 557 91 352 minecraft:shroomlight
setblock 557 91 354 minecraft:shroomlight
setblock 557 91 356 minecraft:shroomlight
setblock 557 91 358 minecraft:shroomlight
fill 557 91 364 559 93 364 minecraft:brown_terracotta
setblock 558 91 322 minecraft:light_gray_terracotta
setblock 558 91 325 minecraft:shroomlight
setblock 558 91 327 minecraft:shroomlight
setblock 558 91 329 minecraft:shroomlight
setblock 558 91 331 minecraft:shroomlight
setblock 558 91 349 minecraft:shroomlight
setblock 558 91 351 minecraft:shroomlight
setblock 558 91 353 minecraft:shroomlight
setblock 558 91 355 minecraft:shroomlight
setblock 558 91 357 minecraft:shroomlight
setblock 558 91 359 minecraft:shroomlight
fill 559 91 322 559 91 329 minecraft:brown_terracotta
fill 559 91 330 559 91 331 minecraft:light_gray_terracotta
fill 559 91 332 559 93 332 minecraft:brown_terracotta
setblock 559 91 333 minecraft:light_gray_terracotta
fill 559 91 334 559 93 334 minecraft:brown_terracotta
fill 559 91 339 559 93 339 minecraft:brown_terracotta
fill 559 91 343 559 94 343 minecraft:brown_terracotta
setblock 559 91 344 minecraft:light_gray_terracotta
fill 559 91 345 559 93 347 minecraft:brown_terracotta
setblock 559 91 349 minecraft:light_gray_terracotta
fill 559 91 350 559 91 354 minecraft:brown_terracotta
setblock 559 91 355 minecraft:light_gray_terracotta
fill 559 91 356 559 93 357 minecraft:brown_terracotta
fill 517 92 322 517 93 322 minecraft:brown_terracotta
setblock 517 92 323 minecraft:light_gray_terracotta
fill 517 92 324 517 93 324 minecraft:brown_terracotta
fill 517 92 336 517 93 336 minecraft:brown_terracotta
fill 517 92 337 517 92 338 minecraft:light_gray_terracotta
fill 517 92 339 517 93 339 minecraft:brown_terracotta
setblock 517 92 340 minecraft:light_gray_terracotta
fill 517 92 341 517 93 351 minecraft:brown_terracotta
fill 517 92 356 517 93 357 minecraft:brown_terracotta
setblock 517 92 358 minecraft:light_gray_terracotta
fill 517 92 359 517 93 359 minecraft:brown_terracotta
setblock 517 92 360 minecraft:light_gray_terracotta
fill 517 92 361 517 93 363 minecraft:brown_terracotta
setblock 517 92 364 minecraft:light_gray_terracotta
setblock 518 92 329 minecraft:stripped_dark_oak_log
setblock 518 92 336 minecraft:stripped_dark_oak_log
setblock 518 92 343 minecraft:stripped_dark_oak_log
setblock 518 92 350 minecraft:stripped_dark_oak_log
setblock 518 92 357 minecraft:stripped_dark_oak_log
setblock 519 92 323 minecraft:stripped_dark_oak_log
setblock 519 92 363 minecraft:stripped_dark_oak_log
setblock 520 92 325 minecraft:light[level=14]
setblock 520 92 333 minecraft:light[level=14]
setblock 520 92 341 minecraft:light[level=14]
setblock 520 92 349 minecraft:light[level=14]
setblock 520 92 357 minecraft:light[level=14]
fill 520 92 364 520 93 364 minecraft:brown_terracotta
setblock 521 92 322 minecraft:light_gray_terracotta
setblock 521 92 364 minecraft:light_gray_terracotta
fill 522 92 322 525 93 322 minecraft:brown_terracotta
fill 522 92 364 522 93 364 minecraft:brown_terracotta
fill 526 92 322 527 92 322 minecraft:light_gray_terracotta
setblock 526 92 323 minecraft:stripped_dark_oak_log
setblock 526 92 363 minecraft:stripped_dark_oak_log
fill 528 92 322 536 93 322 minecraft:brown_terracotta
setblock 528 92 325 minecraft:light[level=14]
setblock 528 92 333 minecraft:light[level=14]
setblock 528 92 341 minecraft:light[level=14]
setblock 528 92 349 minecraft:light[level=14]
setblock 528 92 357 minecraft:light[level=14]
fill 532 92 364 533 92 364 minecraft:light_gray_terracotta
setblock 533 92 323 minecraft:stripped_dark_oak_log
setblock 533 92 363 minecraft:stripped_dark_oak_log
fill 534 92 364 534 93 364 minecraft:brown_terracotta
setblock 536 92 325 minecraft:light[level=14]
setblock 536 92 333 minecraft:light[level=14]
setblock 536 92 341 minecraft:light[level=14]
setblock 536 92 349 minecraft:light[level=14]
setblock 536 92 357 minecraft:light[level=14]
setblock 540 92 323 minecraft:stripped_dark_oak_log
setblock 540 92 363 minecraft:stripped_dark_oak_log
fill 541 92 322 543 93 322 minecraft:brown_terracotta
fill 542 92 364 542 93 364 minecraft:brown_terracotta
setblock 544 92 322 minecraft:light_gray_terracotta
setblock 544 92 325 minecraft:light[level=14]
setblock 544 92 333 minecraft:light[level=14]
setblock 544 92 341 minecraft:light[level=14]
setblock 544 92 349 minecraft:light[level=14]
setblock 544 92 357 minecraft:light[level=14]
fill 545 92 322 553 93 322 minecraft:brown_terracotta
setblock 547 92 323 minecraft:stripped_dark_oak_log
setblock 547 92 363 minecraft:stripped_dark_oak_log
fill 549 92 364 549 93 364 minecraft:brown_terracotta
fill 551 92 324 551 93 324 minecraft:stripped_dark_oak_log
fill 551 92 326 551 93 326 minecraft:stripped_dark_oak_log
fill 551 92 328 551 93 328 minecraft:stripped_dark_oak_log
fill 551 92 330 551 93 330 minecraft:stripped_dark_oak_log
fill 551 92 332 551 93 332 minecraft:stripped_dark_oak_log
fill 552 92 325 552 93 325 minecraft:stripped_dark_oak_log
fill 552 92 327 552 93 327 minecraft:stripped_dark_oak_log
fill 552 92 329 552 93 329 minecraft:stripped_dark_oak_log
fill 552 92 331 552 93 331 minecraft:stripped_dark_oak_log
setblock 552 92 333 minecraft:light[level=14]
setblock 552 92 341 minecraft:light[level=14]
setblock 552 92 349 minecraft:light[level=14]
setblock 552 92 357 minecraft:light[level=14]
fill 552 92 364 552 93 364 minecraft:brown_terracotta
fill 553 92 324 553 93 324 minecraft:stripped_dark_oak_log
fill 553 92 326 553 93 326 minecraft:stripped_dark_oak_log
fill 553 92 328 553 93 328 minecraft:stripped_dark_oak_log
fill 553 92 330 553 93 330 minecraft:stripped_dark_oak_log
fill 553 92 332 553 93 332 minecraft:stripped_dark_oak_log
fill 553 92 350 553 93 350 minecraft:stripped_dark_oak_log
fill 553 92 352 553 93 352 minecraft:stripped_dark_oak_log
fill 553 92 354 553 93 354 minecraft:stripped_dark_oak_log
fill 553 92 356 553 93 356 minecraft:stripped_dark_oak_log
fill 553 92 358 553 93 358 minecraft:stripped_dark_oak_log
setblock 554 92 322 minecraft:light_gray_terracotta
setblock 554 92 323 minecraft:stripped_dark_oak_log
fill 554 92 325 554 93 325 minecraft:stripped_dark_oak_log
fill 554 92 327 554 93 327 minecraft:stripped_dark_oak_log
fill 554 92 329 554 93 329 minecraft:stripped_dark_oak_log
fill 554 92 331 554 93 331 minecraft:stripped_dark_oak_log
fill 554 92 349 554 93 349 minecraft:stripped_dark_oak_log
fill 554 92 351 554 93 351 minecraft:stripped_dark_oak_log
fill 554 92 353 554 93 353 minecraft:stripped_dark_oak_log
fill 554 92 355 554 93 355 minecraft:stripped_dark_oak_log
fill 554 92 357 554 93 357 minecraft:stripped_dark_oak_log
fill 554 92 359 554 93 359 minecraft:stripped_dark_oak_log
setblock 554 92 363 minecraft:stripped_dark_oak_log
fill 555 92 322 558 93 322 minecraft:brown_terracotta
fill 555 92 324 555 93 324 minecraft:stripped_dark_oak_log
fill 555 92 326 555 93 326 minecraft:stripped_dark_oak_log
fill 555 92 328 555 93 328 minecraft:stripped_dark_oak_log
fill 555 92 330 555 93 330 minecraft:stripped_dark_oak_log
fill 555 92 332 555 93 332 minecraft:stripped_dark_oak_log
fill 555 92 350 555 93 350 minecraft:stripped_dark_oak_log
fill 555 92 352 555 93 352 minecraft:stripped_dark_oak_log
fill 555 92 354 555 93 354 minecraft:stripped_dark_oak_log
fill 555 92 356 555 93 356 minecraft:stripped_dark_oak_log
fill 555 92 358 555 93 358 minecraft:stripped_dark_oak_log
fill 556 92 325 556 93 325 minecraft:stripped_dark_oak_log
fill 556 92 327 556 93 327 minecraft:stripped_dark_oak_log
fill 556 92 329 556 93 329 minecraft:stripped_dark_oak_log
fill 556 92 331 556 93 331 minecraft:stripped_dark_oak_log
fill 556 92 349 556 93 349 minecraft:stripped_dark_oak_log
fill 556 92 351 556 93 351 minecraft:stripped_dark_oak_log
fill 556 92 353 556 93 353 minecraft:stripped_dark_oak_log
fill 556 92 355 556 93 355 minecraft:stripped_dark_oak_log
fill 556 92 357 556 93 357 minecraft:stripped_dark_oak_log
fill 556 92 359 556 93 359 minecraft:stripped_dark_oak_log
fill 556 92 364 556 93 364 minecraft:brown_terracotta
fill 557 92 324 557 93 324 minecraft:stripped_dark_oak_log
fill 557 92 326 557 93 326 minecraft:stripped_dark_oak_log
fill 557 92 328 557 93 328 minecraft:stripped_dark_oak_log
fill 557 92 330 557 93 330 minecraft:stripped_dark_oak_log
fill 557 92 332 557 93 332 minecraft:stripped_dark_oak_log
fill 557 92 350 557 93 350 minecraft:stripped_dark_oak_log
fill 557 92 352 557 93 352 minecraft:stripped_dark_oak_log
fill 557 92 354 557 93 354 minecraft:stripped_dark_oak_log
fill 557 92 356 557 93 356 minecraft:stripped_dark_oak_log
fill 557 92 358 557 93 358 minecraft:stripped_dark_oak_log
fill 558 92 325 558 93 325 minecraft:stripped_dark_oak_log
fill 558 92 327 558 93 327 minecraft:stripped_dark_oak_log
fill 558 92 329 558 93 329 minecraft:stripped_dark_oak_log
fill 558 92 331 558 93 331 minecraft:stripped_dark_oak_log
setblock 558 92 333 minecraft:stripped_dark_oak_log
setblock 558 92 340 minecraft:stripped_dark_oak_log
setblock 558 92 347 minecraft:stripped_dark_oak_log
fill 558 92 349 558 93 349 minecraft:stripped_dark_oak_log
fill 558 92 351 558 93 351 minecraft:stripped_dark_oak_log
fill 558 92 353 558 93 353 minecraft:stripped_dark_oak_log
fill 558 92 355 558 93 355 minecraft:stripped_dark_oak_log
fill 558 92 357 558 93 357 minecraft:stripped_dark_oak_log
fill 558 92 359 558 93 359 minecraft:stripped_dark_oak_log
setblock 558 92 361 minecraft:stripped_dark_oak_log
setblock 559 92 322 minecraft:light_gray_terracotta
fill 559 92 323 559 93 331 minecraft:brown_terracotta
fill 559 92 333 559 93 333 minecraft:brown_terracotta
fill 559 92 344 559 93 344 minecraft:brown_terracotta
fill 559 92 348 559 93 352 minecraft:brown_terracotta
setblock 559 92 353 minecraft:light_gray_terracotta
fill 559 92 354 559 93 355 minecraft:brown_terracotta
setblock 517 93 323 minecraft:brown_terracotta
setblock 517 93 332 minecraft:brown_terracotta
fill 517 93 337 517 93 338 minecraft:brown_terracotta
setblock 517 93 340 minecraft:brown_terracotta
setblock 517 93 358 minecraft:brown_terracotta
setblock 517 93 360 minecraft:brown_terracotta
setblock 517 93 364 minecraft:brown_terracotta
setblock 518 93 323 minecraft:stripped_dark_oak_log
setblock 518 93 330 minecraft:stripped_dark_oak_log
setblock 518 93 337 minecraft:stripped_dark_oak_log
setblock 518 93 344 minecraft:stripped_dark_oak_log
setblock 518 93 351 minecraft:stripped_dark_oak_log
setblock 518 93 358 minecraft:stripped_dark_oak_log
setblock 520 93 363 minecraft:stripped_dark_oak_log
fill 521 93 322 521 94 322 minecraft:brown_terracotta
setblock 521 93 364 minecraft:brown_terracotta
setblock 525 93 323 minecraft:stripped_dark_oak_log
fill 526 93 322 527 93 322 minecraft:brown_terracotta
fill 526 93 364 526 94 364 minecraft:brown_terracotta
setblock 527 93 363 minecraft:stripped_dark_oak_log
setblock 532 93 323 minecraft:stripped_dark_oak_log
fill 532 93 364 533 93 364 minecraft:brown_terracotta
setblock 534 93 363 minecraft:stripped_dark_oak_log
fill 538 93 323 538 93 325 minecraft:iron_bars
setblock 539 93 323 minecraft:stripped_dark_oak_log
setblock 541 93 363 minecraft:stripped_dark_oak_log
setblock 544 93 322 minecraft:brown_terracotta
setblock 546 93 323 minecraft:stripped_dark_oak_log
setblock 548 93 363 minecraft:stripped_dark_oak_log
setblock 553 93 323 minecraft:stripped_dark_oak_log
setblock 554 93 322 minecraft:brown_terracotta
setblock 555 93 363 minecraft:stripped_dark_oak_log
setblock 558 93 339 minecraft:stripped_dark_oak_log
setblock 558 93 346 minecraft:stripped_dark_oak_log
setblock 558 93 360 minecraft:stripped_dark_oak_log
setblock 559 93 322 minecraft:brown_terracotta
setblock 559 93 353 minecraft:brown_terracotta
fill 517 94 322 517 94 330 minecraft:light_gray_terracotta
setblock 517 94 331 minecraft:brown_terracotta
fill 517 94 332 517 94 343 minecraft:light_gray_terracotta
setblock 517 94 344 minecraft:brown_terracotta
fill 517 94 345 517 94 364 minecraft:light_gray_terracotta
setblock 518 94 322 minecraft:brown_terracotta
setblock 518 94 324 minecraft:stripped_dark_oak_log
setblock 518 94 331 minecraft:stripped_dark_oak_log
setblock 518 94 338 minecraft:stripped_dark_oak_log
setblock 518 94 345 minecraft:stripped_dark_oak_log
setblock 518 94 352 minecraft:stripped_dark_oak_log
setblock 518 94 359 minecraft:stripped_dark_oak_log
fill 518 94 364 525 94 364 minecraft:light_gray_terracotta
fill 519 94 322 520 197 322 minecraft:light_gray_terracotta
setblock 521 94 363 minecraft:stripped_dark_oak_log
fill 522 94 322 522 198 322 minecraft:light_gray_terracotta
fill 523 94 322 524 94 322 minecraft:brown_terracotta
setblock 524 94 323 minecraft:stripped_dark_oak_log
fill 525 94 322 542 94 322 minecraft:light_gray_terracotta
fill 527 94 364 532 95 364 minecraft:light_gray_terracotta
setblock 528 94 363 minecraft:stripped_dark_oak_log
setblock 531 94 323 minecraft:stripped_dark_oak_log
setblock 533 94 364 minecraft:brown_terracotta
fill 534 94 364 543 95 364 minecraft:light_gray_terracotta
setblock 535 94 363 minecraft:stripped_dark_oak_log
setblock 538 94 323 minecraft:stripped_dark_oak_log
fill 538 94 324 538 94 325 minecraft:iron_bars
setblock 542 94 363 minecraft:stripped_dark_oak_log
setblock 543 94 322 minecraft:brown_terracotta
fill 544 94 322 554 95 322 minecraft:light_gray_terracotta
setblock 544 94 364 minecraft:brown_terracotta
setblock 545 94 323 minecraft:stripped_dark_oak_log
fill 545 94 364 556 95 364 minecraft:light_gray_terracotta
setblock 549 94 363 minecraft:stripped_dark_oak_log
setblock 551 94 324 minecraft:shroomlight
setblock 551 94 326 minecraft:shroomlight
setblock 551 94 328 minecraft:shroomlight
setblock 551 94 330 minecraft:shroomlight
setblock 551 94 332 minecraft:shroomlight
setblock 552 94 323 minecraft:stripped_dark_oak_log
setblock 552 94 325 minecraft:shroomlight
setblock 552 94 327 minecraft:shroomlight
setblock 552 94 329 minecraft:shroomlight
setblock 552 94 331 minecraft:shroomlight
setblock 553 94 324 minecraft:shroomlight
setblock 553 94 326 minecraft:shroomlight
setblock 553 94 328 minecraft:shroomlight
setblock 553 94 330 minecraft:shroomlight
setblock 553 94 332 minecraft:shroomlight
setblock 553 94 350 minecraft:shroomlight
setblock 553 94 352 minecraft:shroomlight
setblock 553 94 354 minecraft:shroomlight
setblock 553 94 356 minecraft:shroomlight
setblock 553 94 358 minecraft:shroomlight
setblock 554 94 325 minecraft:shroomlight
setblock 554 94 327 minecraft:shroomlight
setblock 554 94 329 minecraft:shroomlight
setblock 554 94 331 minecraft:shroomlight
setblock 554 94 349 minecraft:shroomlight
setblock 554 94 351 minecraft:shroomlight
setblock 554 94 353 minecraft:shroomlight
setblock 554 94 355 minecraft:shroomlight
setblock 554 94 357 minecraft:shroomlight
setblock 554 94 359 minecraft:shroomlight
setblock 555 94 322 minecraft:brown_terracotta
setblock 555 94 324 minecraft:shroomlight
setblock 555 94 326 minecraft:shroomlight
setblock 555 94 328 minecraft:shroomlight
setblock 555 94 330 minecraft:shroomlight
setblock 555 94 332 minecraft:shroomlight
setblock 555 94 350 minecraft:shroomlight
setblock 555 94 352 minecraft:shroomlight
setblock 555 94 354 minecraft:shroomlight
setblock 555 94 356 minecraft:shroomlight
setblock 555 94 358 minecraft:shroomlight
fill 556 94 322 559 95 322 minecraft:light_gray_terracotta
setblock 556 94 325 minecraft:shroomlight
setblock 556 94 327 minecraft:shroomlight
setblock 556 94 329 minecraft:shroomlight
setblock 556 94 331 minecraft:shroomlight
setblock 556 94 349 minecraft:shroomlight
setblock 556 94 351 minecraft:shroomlight
setblock 556 94 353 minecraft:shroomlight
setblock 556 94 355 minecraft:shroomlight
setblock 556 94 357 minecraft:shroomlight
setblock 556 94 359 minecraft:shroomlight
setblock 556 94 363 minecraft:stripped_dark_oak_log
setblock 557 94 324 minecraft:shroomlight
setblock 557 94 326 minecraft:shroomlight
setblock 557 94 328 minecraft:shroomlight
setblock 557 94 330 minecraft:shroomlight
setblock 557 94 332 minecraft:shroomlight
setblock 557 94 350 minecraft:shroomlight
setblock 557 94 352 minecraft:shroomlight
setblock 557 94 354 minecraft:shroomlight
setblock 557 94 356 minecraft:shroomlight
setblock 557 94 358 minecraft:shroomlight
setblock 557 94 364 minecraft:brown_terracotta
setblock 558 94 325 minecraft:shroomlight
setblock 558 94 327 minecraft:shroomlight
setblock 558 94 329 minecraft:shroomlight
setblock 558 94 331 minecraft:shroomlight
setblock 558 94 338 minecraft:stripped_dark_oak_log
setblock 558 94 345 minecraft:stripped_dark_oak_log
setblock 558 94 349 minecraft:shroomlight
setblock 558 94 351 minecraft:shroomlight
setblock 558 94 353 minecraft:shroomlight
setblock 558 94 355 minecraft:shroomlight
setblock 558 94 357 minecraft:shroomlight
setblock 558 94 359 minecraft:shroomlight
fill 558 94 364 559 196 364 minecraft:light_gray_terracotta
fill 559 94 323 559 95 329 minecraft:light_gray_terracotta
setblock 559 94 330 minecraft:brown_terracotta
fill 559 94 331 559 94 334 minecraft:light_gray_terracotta
fill 559 94 335 559 94 336 minecraft:brown_terracotta
fill 559 94 337 559 95 342 minecraft:light_gray_terracotta
fill 559 94 344 559 94 346 minecraft:light_gray_terracotta
setblock 559 94 347 minecraft:brown_terracotta
fill 559 94 348 559 95 349 minecraft:light_gray_terracotta
setblock 559 94 350 minecraft:brown_terracotta
fill 559 94 351 559 94 363 minecraft:light_gray_terracotta
fill 517 95 322 517 200 324 minecraft:light_gray_terracotta
fill 517 95 325 517 96 325 minecraft:brown_terracotta
fill 517 95 326 517 95 328 minecraft:light_gray_terracotta
setblock 517 95 329 minecraft:brown_terracotta
fill 517 95 330 517 95 336 minecraft:light_gray_terracotta
setblock 517 95 337 minecraft:brown_terracotta
fill 517 95 338 517 95 349 minecraft:light_gray_terracotta
setblock 517 95 350 minecraft:brown_terracotta
fill 517 95 351 517 95 356 minecraft:light_gray_terracotta
setblock 517 95 357 minecraft:brown_terracotta
fill 517 95 358 517 197 364 minecraft:light_gray_terracotta
fill 518 95 322 518 201 322 minecraft:light_gray_terracotta
setblock 518 95 325 minecraft:stripped_dark_oak_log
setblock 518 95 332 minecraft:stripped_dark_oak_log
setblock 518 95 339 minecraft:stripped_dark_oak_log
setblock 518 95 346 minecraft:stripped_dark_oak_log
setblock 518 95 353 minecraft:stripped_dark_oak_log
setblock 518 95 360 minecraft:stripped_dark_oak_log
setblock 518 95 364 minecraft:brown_terracotta
fill 519 95 364 526 197 364 minecraft:light_gray_terracotta
fill 521 95 322 521 200 322 minecraft:light_gray_terracotta
setblock 522 95 363 minecraft:stripped_dark_oak_log
fill 523 95 322 535 196 322 minecraft:light_gray_terracotta
setblock 523 95 323 minecraft:stripped_dark_oak_log
setblock 529 95 363 minecraft:stripped_dark_oak_log
setblock 530 95 323 minecraft:stripped_dark_oak_log
fill 533 95 364 533 200 364 minecraft:light_gray_terracotta
fill 536 95 322 537 95 322 minecraft:brown_terracotta
setblock 536 95 363 minecraft:stripped_dark_oak_log
setblock 537 95 323 minecraft:stripped_dark_oak_log
fill 538 95 322 541 196 322 minecraft:light_gray_terracotta
setblock 542 95 322 minecraft:brown_terracotta
fill 543 95 322 543 196 322 minecraft:light_gray_terracotta
setblock 543 95 363 minecraft:stripped_dark_oak_log
setblock 544 95 323 minecraft:stripped_dark_oak_log
fill 544 95 364 544 200 364 minecraft:light_gray_terracotta
setblock 550 95 363 minecraft:stripped_dark_oak_log
fill 551 95 323 551 95 324 minecraft:stripped_dark_oak_log
setblock 551 95 326 minecraft:stripped_dark_oak_log
setblock 551 95 328 minecraft:stripped_dark_oak_log
setblock 551 95 330 minecraft:stripped_dark_oak_log
setblock 551 95 332 minecraft:stripped_dark_oak_log
setblock 552 95 325 minecraft:stripped_dark_oak_log
setblock 552 95 327 minecraft:stripped_dark_oak_log
setblock 552 95 329 minecraft:stripped_dark_oak_log
setblock 552 95 331 minecraft:stripped_dark_oak_log
setblock 553 95 324 minecraft:stripped_dark_oak_log
setblock 553 95 326 minecraft:stripped_dark_oak_log
setblock 553 95 328 minecraft:stripped_dark_oak_log
setblock 553 95 330 minecraft:stripped_dark_oak_log
setblock 553 95 332 minecraft:stripped_dark_oak_log
fill 553 95 350 553 96 350 minecraft:stripped_dark_oak_log
fill 553 95 352 553 96 352 minecraft:stripped_dark_oak_log
fill 553 95 354 553 96 354 minecraft:stripped_dark_oak_log
fill 553 95 356 553 96 356 minecraft:stripped_dark_oak_log
fill 553 95 358 553 96 358 minecraft:stripped_dark_oak_log
setblock 554 95 325 minecraft:stripped_dark_oak_log
setblock 554 95 327 minecraft:stripped_dark_oak_log
setblock 554 95 329 minecraft:stripped_dark_oak_log
setblock 554 95 331 minecraft:stripped_dark_oak_log
fill 554 95 349 554 96 349 minecraft:stripped_dark_oak_log
fill 554 95 351 554 96 351 minecraft:stripped_dark_oak_log
fill 554 95 353 554 96 353 minecraft:stripped_dark_oak_log
fill 554 95 355 554 96 355 minecraft:stripped_dark_oak_log
fill 554 95 357 554 96 357 minecraft:stripped_dark_oak_log
fill 554 95 359 554 96 359 minecraft:stripped_dark_oak_log
fill 555 95 322 555 200 322 minecraft:light_gray_terracotta
setblock 555 95 324 minecraft:stripped_dark_oak_log
setblock 555 95 326 minecraft:stripped_dark_oak_log
setblock 555 95 328 minecraft:stripped_dark_oak_log
setblock 555 95 330 minecraft:stripped_dark_oak_log
setblock 555 95 332 minecraft:stripped_dark_oak_log
fill 555 95 350 555 96 350 minecraft:stripped_dark_oak_log
fill 555 95 352 555 96 352 minecraft:stripped_dark_oak_log
fill 555 95 354 555 96 354 minecraft:stripped_dark_oak_log
fill 555 95 356 555 96 356 minecraft:stripped_dark_oak_log
fill 555 95 358 555 96 358 minecraft:stripped_dark_oak_log
setblock 556 95 325 minecraft:stripped_dark_oak_log
setblock 556 95 327 minecraft:stripped_dark_oak_log
setblock 556 95 329 minecraft:stripped_dark_oak_log
setblock 556 95 331 minecraft:stripped_dark_oak_log
fill 556 95 349 556 96 349 minecraft:stripped_dark_oak_log
fill 556 95 351 556 96 351 minecraft:stripped_dark_oak_log
fill 556 95 353 556 96 353 minecraft:stripped_dark_oak_log
fill 556 95 355 556 96 355 minecraft:stripped_dark_oak_log
fill 556 95 357 556 96 357 minecraft:stripped_dark_oak_log
fill 556 95 359 556 96 359 minecraft:stripped_dark_oak_log
setblock 557 95 324 minecraft:stripped_dark_oak_log
setblock 557 95 326 minecraft:stripped_dark_oak_log
setblock 557 95 328 minecraft:stripped_dark_oak_log
setblock 557 95 330 minecraft:stripped_dark_oak_log
setblock 557 95 332 minecraft:stripped_dark_oak_log
fill 557 95 350 557 96 350 minecraft:stripped_dark_oak_log
fill 557 95 352 557 96 352 minecraft:stripped_dark_oak_log
fill 557 95 354 557 96 354 minecraft:stripped_dark_oak_log
fill 557 95 356 557 96 356 minecraft:stripped_dark_oak_log
fill 557 95 358 557 96 358 minecraft:stripped_dark_oak_log
setblock 557 95 363 minecraft:stripped_dark_oak_log
fill 557 95 364 557 200 364 minecraft:light_gray_terracotta
setblock 558 95 323 minecraft:stripped_dark_oak_log
setblock 558 95 325 minecraft:stripped_dark_oak_log
fill 558 95 327 558 150 327 minecraft:stripped_dark_oak_log
fill 558 95 329 558 96 329 minecraft:stripped_dark_oak_log
setblock 558 95 331 minecraft:stripped_dark_oak_log
setblock 558 95 337 minecraft:stripped_dark_oak_log
setblock 558 95 344 minecraft:stripped_dark_oak_log
fill 558 95 349 558 96 349 minecraft:stripped_dark_oak_log
fill 558 95 351 558 96 351 minecraft:stripped_dark_oak_log
fill 558 95 353 558 96 353 minecraft:stripped_dark_oak_log
fill 558 95 355 558 96 355 minecraft:stripped_dark_oak_log
fill 558 95 357 558 96 357 minecraft:stripped_dark_oak_log
fill 558 95 359 558 96 359 minecraft:stripped_dark_oak_log
fill 559 95 330 559 196 333 minecraft:light_gray_terracotta
setblock 559 95 334 minecraft:brown_terracotta
fill 559 95 335 559 200 335 minecraft:light_gray_terracotta
setblock 559 95 336 minecraft:brown_terracotta
fill 559 95 343 559 200 343 minecraft:light_gray_terracotta
fill 559 95 344 559 95 345 minecraft:brown_terracotta
fill 559 95 346 559 197 347 minecraft:light_gray_terracotta
fill 559 95 350 559 198 353 minecraft:light_gray_terracotta
setblock 559 95 354 minecraft:brown_terracotta
fill 559 95 355 559 196 363 minecraft:light_gray_terracotta
fill 517 96 326 517 197 327 minecraft:light_gray_terracotta
setblock 517 96 328 minecraft:brown_terracotta
fill 517 96 329 517 196 335 minecraft:light_gray_terracotta
setblock 517 96 336 minecraft:brown_terracotta
fill 517 96 337 517 196 340 minecraft:light_gray_terracotta
setblock 517 96 341 minecraft:brown_terracotta
fill 517 96 342 517 196 347 minecraft:light_gray_terracotta
setblock 517 96 348 minecraft:brown_terracotta
fill 517 96 349 517 200 354 minecraft:light_gray_terracotta
setblock 517 96 355 minecraft:brown_terracotta
fill 517 96 356 517 196 357 minecraft:light_gray_terracotta
setblock 518 96 326 minecraft:stripped_dark_oak_log
setblock 518 96 333 minecraft:stripped_dark_oak_log
setblock 518 96 340 minecraft:stripped_dark_oak_log
setblock 518 96 347 minecraft:stripped_dark_oak_log
setblock 518 96 354 minecraft:stripped_dark_oak_log
setblock 518 96 361 minecraft:stripped_dark_oak_log
fill 518 96 364 518 197 364 minecraft:light_gray_terracotta
setblock 522 96 323 minecraft:stripped_dark_oak_log
setblock 523 96 363 minecraft:stripped_dark_oak_log
fill 527 96 364 531 196 364 minecraft:light_gray_terracotta
setblock 529 96 323 minecraft:stripped_dark_oak_log
setblock 530 96 363 minecraft:stripped_dark_oak_log
setblock 532 96 364 minecraft:brown_terracotta
fill 534 96 364 538 197 364 minecraft:light_gray_terracotta
fill 536 96 322 537 197 322 minecraft:light_gray_terracotta
setblock 536 96 323 minecraft:stripped_dark_oak_log
setblock 537 96 363 minecraft:stripped_dark_oak_log
setblock 539 96 364 minecraft:brown_terracotta
fill 540 96 364 543 196 364 minecraft:light_gray_terracotta
fill 542 96 322 542 200 322 minecraft:light_gray_terracotta
setblock 543 96 323 minecraft:stripped_dark_oak_log
fill 544 96 322 549 196 322 minecraft:light_gray_terracotta
setblock 544 96 363 minecraft:stripped_dark_oak_log
fill 545 96 364 555 196 364 minecraft:light_gray_terracotta
setblock 550 96 322 minecraft:brown_terracotta
setblock 550 96 323 minecraft:stripped_dark_oak_log
fill 551 96 322 552 196 322 minecraft:light_gray_terracotta
setblock 551 96 363 minecraft:stripped_dark_oak_log
fill 552 96 325 557 96 331 minecraft:red_concrete
setblock 553 96 322 minecraft:brown_terracotta
fill 554 96 322 554 200 322 minecraft:light_gray_terracotta
fill 556 96 322 558 197 322 minecraft:light_gray_terracotta
setblock 556 96 364 minecraft:brown_terracotta
setblock 557 96 323 minecraft:stripped_dark_oak_log
setblock 558 96 336 minecraft:stripped_dark_oak_log
setblock 558 96 343 minecraft:stripped_dark_oak_log
setblock 558 96 363 minecraft:stripped_dark_oak_log
fill 559 96 322 559 96 323 minecraft:brown_terracotta
fill 559 96 324 559 196 329 minecraft:light_gray_terracotta
fill 559 96 334 559 200 334 minecraft:light_gray_terracotta
fill 559 96 336 559 200 336 minecraft:light_gray_terracotta
setblock 559 96 337 minecraft:brown_terracotta
fill 559 96 338 559 200 342 minecraft:light_gray_terracotta
fill 559 96 344 559 196 345 minecraft:light_gray_terracotta
setblock 559 96 348 minecraft:brown_terracotta
fill 559 96 349 559 200 349 minecraft:light_gray_terracotta
fill 559 96 354 559 201 354 minecraft:light_gray_terracotta
fill 517 97 325 517 200 325 minecraft:light_gray_terracotta
fill 517 97 328 517 200 328 minecraft:light_gray_terracotta
fill 517 97 336 517 200 336 minecraft:light_gray_terracotta
fill 517 97 341 517 198 341 minecraft:light_gray_terracotta
fill 517 97 348 517 200 348 minecraft:light_gray_terracotta
fill 517 97 355 517 196 355 minecraft:light_gray_terracotta
setblock 518 97 327 minecraft:stripped_dark_oak_log
setblock 518 97 334 minecraft:stripped_dark_oak_log
setblock 518 97 341 minecraft:stripped_dark_oak_log
setblock 518 97 348 minecraft:stripped_dark_oak_log
setblock 518 97 355 minecraft:stripped_dark_oak_log
setblock 518 97 362 minecraft:stripped_dark_oak_log
setblock 521 97 323 minecraft:stripped_dark_oak_log
setblock 524 97 363 minecraft:stripped_dark_oak_log
setblock 528 97 323 minecraft:stripped_dark_oak_log
setblock 531 97 363 minecraft:stripped_dark_oak_log
fill 532 97 364 532 197 364 minecraft:light_gray_terracotta
setblock 535 97 323 minecraft:stripped_dark_oak_log
setblock 538 97 363 minecraft:stripped_dark_oak_log
fill 539 97 364 539 196 364 minecraft:light_gray_terracotta
setblock 542 97 323 minecraft:stripped_dark_oak_log
setblock 545 97 363 minecraft:stripped_dark_oak_log
setblock 549 97 323 minecraft:stripped_dark_oak_log
fill 550 97 322 550 201 322 minecraft:light_gray_terracotta
setblock 552 97 363 minecraft:stripped_dark_oak_log
fill 553 97 322 553 201 322 minecraft:light_gray_terracotta
fill 553 97 326 556 97 330 minecraft:red_concrete
setblock 553 97 350 minecraft:shroomlight
setblock 553 97 352 minecraft:shroomlight
setblock 553 97 354 minecraft:shroomlight
setblock 553 97 356 minecraft:shroomlight
setblock 553 97 358 minecraft:shroomlight
setblock 554 97 349 minecraft:shroomlight
setblock 554 97 351 minecraft:shroomlight
setblock 554 97 353 minecraft:shroomlight
setblock 554 97 355 minecraft:shroomlight
setblock 554 97 357 minecraft:shroomlight
setblock 554 97 359 minecraft:shroomlight
setblock 555 97 350 minecraft:shroomlight
setblock 555 97 352 minecraft:shroomlight
setblock 555 97 354 minecraft:shroomlight
setblock 555 97 356 minecraft:shroomlight
setblock 555 97 358 minecraft:shroomlight
setblock 556 97 323 minecraft:stripped_dark_oak_log
setblock 556 97 349 minecraft:shroomlight
setblock 556 97 351 minecraft:shroomlight
setblock 556 97 353 minecraft:shroomlight
setblock 556 97 355 minecraft:shroomlight
setblock 556 97 357 minecraft:shroomlight
setblock 556 97 359 minecraft:shroomlight
fill 556 97 364 556 196 364 minecraft:light_gray_terracotta
setblock 557 97 350 minecraft:shroomlight
setblock 557 97 352 minecraft:shroomlight
setblock 557 97 354 minecraft:shroomlight
setblock 557 97 356 minecraft:shroomlight
setblock 557 97 358 minecraft:shroomlight
setblock 558 97 328 minecraft:stripped_dark_oak_log
setblock 558 97 335 minecraft:stripped_dark_oak_log
setblock 558 97 342 minecraft:stripped_dark_oak_log
setblock 558 97 349 minecraft:shroomlight
setblock 558 97 351 minecraft:shroomlight
setblock 558 97 353 minecraft:shroomlight
setblock 558 97 355 minecraft:shroomlight
setblock 558 97 357 minecraft:shroomlight
setblock 558 97 359 minecraft:shroomlight
fill 559 97 322 559 196 323 minecraft:light_gray_terracotta
fill 559 97 337 559 200 337 minecraft:light_gray_terracotta
fill 559 97 348 559 198 348 minecraft:light_gray_terracotta
fill 553 98 350 553 99 350 minecraft:stripped_dark_oak_log
fill 553 98 352 553 99 352 minecraft:stripped_dark_oak_log
fill 553 98 354 553 99 354 minecraft:stripped_dark_oak_log
fill 553 98 356 553 99 356 minecraft:stripped_dark_oak_log
fill 553 98 358 553 99 358 minecraft:stripped_dark_oak_log
fill 554 98 327 555 98 329 minecraft:red_concrete
fill 554 98 349 554 99 349 minecraft:stripped_dark_oak_log
fill 554 98 351 554 99 351 minecraft:stripped_dark_oak_log
fill 554 98 353 554 99 353 minecraft:stripped_dark_oak_log
fill 554 98 355 554 99 355 minecraft:stripped_dark_oak_log
fill 554 98 357 554 99 357 minecraft:stripped_dark_oak_log
fill 554 98 359 554 99 359 minecraft:stripped_dark_oak_log
fill 555 98 350 555 99 350 minecraft:stripped_dark_oak_log
fill 555 98 352 555 99 352 minecraft:stripped_dark_oak_log
fill 555 98 354 555 99 354 minecraft:stripped_dark_oak_log
fill 555 98 356 555 99 356 minecraft:stripped_dark_oak_log
fill 555 98 358 555 99 358 minecraft:stripped_dark_oak_log
fill 556 98 332 556 99 338 minecraft:iron_bars
fill 556 98 349 556 99 349 minecraft:stripped_dark_oak_log
fill 556 98 351 556 99 351 minecraft:stripped_dark_oak_log
fill 556 98 353 556 99 353 minecraft:stripped_dark_oak_log
fill 556 98 355 556 99 355 minecraft:stripped_dark_oak_log
fill 556 98 357 556 99 357 minecraft:stripped_dark_oak_log
fill 556 98 359 556 99 359 minecraft:stripped_dark_oak_log
fill 557 98 350 557 99 350 minecraft:stripped_dark_oak_log
fill 557 98 352 557 99 352 minecraft:stripped_dark_oak_log
fill 557 98 354 557 99 354 minecraft:stripped_dark_oak_log
fill 557 98 356 557 99 356 minecraft:stripped_dark_oak_log
fill 557 98 358 557 99 358 minecraft:stripped_dark_oak_log
fill 558 98 349 558 99 349 minecraft:stripped_dark_oak_log
fill 558 98 351 558 99 351 minecraft:stripped_dark_oak_log
fill 558 98 353 558 99 353 minecraft:stripped_dark_oak_log
fill 558 98 355 558 99 355 minecraft:stripped_dark_oak_log
fill 558 98 357 558 99 357 minecraft:stripped_dark_oak_log
fill 558 98 359 558 99 359 minecraft:stripped_dark_oak_log
fill 518 99 329 518 100 329 minecraft:stripped_dark_oak_log
fill 518 99 336 518 100 336 minecraft:stripped_dark_oak_log
fill 518 99 343 518 100 343 minecraft:stripped_dark_oak_log
fill 518 99 350 518 100 350 minecraft:stripped_dark_oak_log
fill 518 99 357 518 100 357 minecraft:stripped_dark_oak_log
fill 519 99 323 519 100 323 minecraft:stripped_dark_oak_log
fill 519 99 363 519 100 363 minecraft:stripped_dark_oak_log
fill 526 99 323 526 100 323 minecraft:stripped_dark_oak_log
fill 526 99 363 526 100 363 minecraft:stripped_dark_oak_log
fill 533 99 323 533 100 323 minecraft:stripped_dark_oak_log
fill 533 99 363 533 100 363 minecraft:stripped_dark_oak_log
fill 540 99 323 540 100 323 minecraft:stripped_dark_oak_log
fill 540 99 363 540 100 363 minecraft:stripped_dark_oak_log
fill 547 99 323 547 100 323 minecraft:stripped_dark_oak_log
fill 547 99 363 547 100 363 minecraft:stripped_dark_oak_log
fill 554 99 323 554 100 323 minecraft:stripped_dark_oak_log
fill 554 99 328 555 99 328 minecraft:red_concrete
fill 554 99 363 554 100 363 minecraft:stripped_dark_oak_log
fill 558 99 326 558 100 326 minecraft:stripped_dark_oak_log
fill 558 99 333 558 100 333 minecraft:stripped_dark_oak_log
fill 558 99 340 558 100 340 minecraft:stripped_dark_oak_log
fill 558 99 347 558 100 347 minecraft:stripped_dark_oak_log
fill 558 99 361 558 100 361 minecraft:stripped_dark_oak_log
fill 518 100 323 518 100 327 minecraft:stripped_dark_oak_log
fill 518 100 330 518 100 334 minecraft:stripped_dark_oak_log
fill 518 100 337 518 100 341 minecraft:stripped_dark_oak_log
fill 518 100 344 518 100 348 minecraft:stripped_dark_oak_log
fill 518 100 351 518 100 355 minecraft:stripped_dark_oak_log
fill 518 100 358 518 100 362 minecraft:stripped_dark_oak_log
setblock 520 100 325 minecraft:light[level=14]
setblock 520 100 333 minecraft:light[level=14]
setblock 520 100 341 minecraft:light[level=14]
setblock 520 100 349 minecraft:light[level=14]
setblock 520 100 357 minecraft:light[level=14]
fill 520 100 363 524 100 363 minecraft:stripped_dark_oak_log
fill 521 100 323 525 100 323 minecraft:stripped_dark_oak_log
fill 527 100 363 531 100 363 minecraft:stripped_dark_oak_log
fill 528 100 323 532 100 323 minecraft:stripped_dark_oak_log
setblock 528 100 325 minecraft:light[level=14]
setblock 528 100 333 minecraft:light[level=14]
setblock 528 100 341 minecraft:light[level=14]
setblock 528 100 349 minecraft:light[level=14]
setblock 528 100 357 minecraft:light[level=14]
fill 534 100 363 538 100 363 minecraft:stripped_dark_oak_log
fill 535 100 323 539 100 323 minecraft:stripped_dark_oak_log
setblock 536 100 325 minecraft:light[level=14]
setblock 536 100 333 minecraft:light[level=14]
setblock 536 100 341 minecraft:light[level=14]
setblock 536 100 349 minecraft:light[level=14]
setblock 536 100 357 minecraft:light[level=14]
fill 541 100 363 545 100 363 minecraft:stripped_dark_oak_log
fill 542 100 323 546 100 323 minecraft:stripped_dark_oak_log
setblock 544 100 325 minecraft:light[level=14]
setblock 544 100 333 minecraft:light[level=14]
setblock 544 100 341 minecraft:light[level=14]
setblock 544 100 349 minecraft:light[level=14]
setblock 544 100 357 minecraft:light[level=14]
fill 548 100 363 552 100 363 minecraft:stripped_dark_oak_log
fill 549 100 323 553 100 323 minecraft:stripped_dark_oak_log
setblock 552 100 325 minecraft:light[level=14]
setblock 552 100 333 minecraft:light[level=14]
setblock 552 100 341 minecraft:light[level=14]
setblock 552 100 349 minecraft:light[level=14]
setblock 552 100 357 minecraft:light[level=14]
setblock 553 100 350 minecraft:shroomlight
setblock 553 100 352 minecraft:shroomlight
setblock 553 100 354 minecraft:shroomlight
setblock 553 100 356 minecraft:shroomlight
setblock 553 100 358 minecraft:shroomlight
setblock 554 100 349 minecraft:shroomlight
setblock 554 100 351 minecraft:shroomlight
setblock 554 100 353 minecraft:shroomlight
setblock 554 100 355 minecraft:shroomlight
setblock 554 100 357 minecraft:shroomlight
setblock 554 100 359 minecraft:shroomlight
setblock 555 100 350 minecraft:shroomlight
setblock 555 100 352 minecraft:shroomlight
setblock 555 100 354 minecraft:shroomlight
setblock 555 100 356 minecraft:shroomlight
setblock 555 100 358 minecraft:shroomlight
fill 555 100 363 558 100 363 minecraft:stripped_dark_oak_log
fill 556 100 323 558 100 323 minecraft:stripped_dark_oak_log
setblock 556 100 349 minecraft:shroomlight
setblock 556 100 351 minecraft:shroomlight
setblock 556 100 353 minecraft:shroomlight
setblock 556 100 355 minecraft:shroomlight
setblock 556 100 357 minecraft:shroomlight
setblock 556 100 359 minecraft:shroomlight
setblock 557 100 350 minecraft:shroomlight
setblock 557 100 352 minecraft:shroomlight
setblock 557 100 354 minecraft:shroomlight
setblock 557 100 356 minecraft:shroomlight
setblock 557 100 358 minecraft:shroomlight
fill 558 100 324 558 100 325 minecraft:stripped_dark_oak_log
fill 558 100 328 558 100 332 minecraft:stripped_dark_oak_log
fill 558 100 335 558 100 339 minecraft:stripped_dark_oak_log
fill 558 100 342 558 100 346 minecraft:stripped_dark_oak_log
setblock 558 100 349 minecraft:shroomlight
setblock 558 100 351 minecraft:shroomlight
setblock 558 100 353 minecraft:shroomlight
setblock 558 100 355 minecraft:shroomlight
setblock 558 100 357 minecraft:shroomlight
setblock 558 100 359 minecraft:shroomlight
setblock 558 100 360 minecraft:stripped_dark_oak_log
setblock 518 101 324 minecraft:stripped_dark_oak_log
setblock 518 101 331 minecraft:stripped_dark_oak_log
setblock 518 101 338 minecraft:stripped_dark_oak_log
setblock 518 101 345 minecraft:stripped_dark_oak_log
setblock 518 101 352 minecraft:stripped_dark_oak_log
setblock 518 101 359 minecraft:stripped_dark_oak_log
setblock 521 101 363 minecraft:stripped_dark_oak_log
setblock 524 101 323 minecraft:stripped_dark_oak_log
fill 525 101 361 525 115 361 minecraft:red_wool
setblock 528 101 363 minecraft:stripped_dark_oak_log
setblock 531 101 323 minecraft:stripped_dark_oak_log
setblock 535 101 363 minecraft:stripped_dark_oak_log
setblock 538 101 323 minecraft:stripped_dark_oak_log
setblock 542 101 363 minecraft:stripped_dark_oak_log
setblock 545 101 323 minecraft:stripped_dark_oak_log
setblock 549 101 363 minecraft:stripped_dark_oak_log
setblock 552 101 323 minecraft:stripped_dark_oak_log
setblock 553 101 350 minecraft:stripped_dark_oak_log
setblock 553 101 352 minecraft:stripped_dark_oak_log
setblock 553 101 354 minecraft:stripped_dark_oak_log
setblock 553 101 356 minecraft:stripped_dark_oak_log
setblock 553 101 358 minecraft:stripped_dark_oak_log
setblock 554 101 349 minecraft:stripped_dark_oak_log
setblock 554 101 351 minecraft:stripped_dark_oak_log
setblock 554 101 353 minecraft:stripped_dark_oak_log
setblock 554 101 355 minecraft:stripped_dark_oak_log
setblock 554 101 357 minecraft:stripped_dark_oak_log
setblock 554 101 359 minecraft:stripped_dark_oak_log
setblock 555 101 350 minecraft:stripped_dark_oak_log
setblock 555 101 352 minecraft:stripped_dark_oak_log
setblock 555 101 354 minecraft:stripped_dark_oak_log
setblock 555 101 356 minecraft:stripped_dark_oak_log
setblock 555 101 358 minecraft:stripped_dark_oak_log
setblock 556 101 349 minecraft:stripped_dark_oak_log
setblock 556 101 351 minecraft:stripped_dark_oak_log
setblock 556 101 353 minecraft:stripped_dark_oak_log
setblock 556 101 355 minecraft:stripped_dark_oak_log
setblock 556 101 357 minecraft:stripped_dark_oak_log
setblock 556 101 359 minecraft:stripped_dark_oak_log
setblock 556 101 363 minecraft:stripped_dark_oak_log
setblock 557 101 350 minecraft:stripped_dark_oak_log
setblock 557 101 352 minecraft:stripped_dark_oak_log
setblock 557 101 354 minecraft:stripped_dark_oak_log
setblock 557 101 356 minecraft:stripped_dark_oak_log
setblock 557 101 358 minecraft:stripped_dark_oak_log
setblock 558 101 324 minecraft:stripped_dark_oak_log
setblock 558 101 331 minecraft:stripped_dark_oak_log
setblock 558 101 338 minecraft:stripped_dark_oak_log
setblock 558 101 345 minecraft:stripped_dark_oak_log
setblock 558 101 349 minecraft:stripped_dark_oak_log
fill 558 101 351 558 102 351 minecraft:stripped_dark_oak_log
setblock 558 101 353 minecraft:stripped_dark_oak_log
fill 558 101 355 558 150 355 minecraft:stripped_dark_oak_log
setblock 558 101 357 minecraft:stripped_dark_oak_log
setblock 558 101 359 minecraft:stripped_dark_oak_log
setblock 518 102 325 minecraft:stripped_dark_oak_log
setblock 518 102 332 minecraft:stripped_dark_oak_log
setblock 518 102 339 minecraft:stripped_dark_oak_log
setblock 518 102 346 minecraft:stripped_dark_oak_log
setblock 518 102 353 minecraft:stripped_dark_oak_log
setblock 518 102 360 minecraft:stripped_dark_oak_log
setblock 522 102 363 minecraft:stripped_dark_oak_log
setblock 523 102 323 minecraft:stripped_dark_oak_log
fill 523 102 361 524 115 361 minecraft:red_wool
fill 526 102 361 527 115 361 minecraft:red_wool
setblock 529 102 363 minecraft:stripped_dark_oak_log
setblock 530 102 323 minecraft:stripped_dark_oak_log
setblock 536 102 363 minecraft:stripped_dark_oak_log
setblock 537 102 323 minecraft:stripped_dark_oak_log
setblock 543 102 363 minecraft:stripped_dark_oak_log
setblock 544 102 323 minecraft:stripped_dark_oak_log
setblock 550 102 363 minecraft:stripped_dark_oak_log
setblock 551 102 323 minecraft:stripped_dark_oak_log
fill 554 102 350 557 102 358 minecraft:red_concrete
setblock 557 102 363 minecraft:stripped_dark_oak_log
setblock 558 102 323 minecraft:stripped_dark_oak_log
setblock 558 102 330 minecraft:stripped_dark_oak_log
setblock 558 102 337 minecraft:stripped_dark_oak_log
setblock 558 102 344 minecraft:stripped_dark_oak_log
setblock 518 103 326 minecraft:stripped_dark_oak_log
setblock 518 103 333 minecraft:stripped_dark_oak_log
setblock 518 103 340 minecraft:stripped_dark_oak_log
setblock 518 103 347 minecraft:stripped_dark_oak_log
setblock 518 103 354 minecraft:stripped_dark_oak_log
setblock 518 103 361 minecraft:stripped_dark_oak_log
setblock 522 103 323 minecraft:stripped_dark_oak_log
setblock 523 103 363 minecraft:stripped_dark_oak_log
setblock 529 103 323 minecraft:stripped_dark_oak_log
setblock 530 103 363 minecraft:stripped_dark_oak_log
setblock 536 103 323 minecraft:stripped_dark_oak_log
setblock 537 103 363 minecraft:stripped_dark_oak_log
setblock 543 103 323 minecraft:stripped_dark_oak_log
setblock 544 103 363 minecraft:stripped_dark_oak_log
setblock 550 103 323 minecraft:stripped_dark_oak_log
setblock 551 103 363 minecraft:stripped_dark_oak_log
fill 555 103 351 556 103 357 minecraft:red_concrete
setblock 557 103 323 minecraft:stripped_dark_oak_log
setblock 558 103 329 minecraft:stripped_dark_oak_log
setblock 558 103 336 minecraft:stripped_dark_oak_log
setblock 558 103 343 minecraft:stripped_dark_oak_log
setblock 558 103 350 minecraft:stripped_dark_oak_log
setblock 558 103 357 minecraft:stripped_dark_oak_log
setblock 558 103 363 minecraft:stripped_dark_oak_log
setblock 518 104 327 minecraft:stripped_dark_oak_log
setblock 518 104 334 minecraft:stripped_dark_oak_log
setblock 518 104 341 minecraft:stripped_dark_oak_log
setblock 518 104 348 minecraft:stripped_dark_oak_log
setblock 518 104 355 minecraft:stripped_dark_oak_log
setblock 518 104 362 minecraft:stripped_dark_oak_log
setblock 521 104 323 minecraft:stripped_dark_oak_log
setblock 524 104 363 minecraft:stripped_dark_oak_log
setblock 528 104 323 minecraft:stripped_dark_oak_log
setblock 531 104 363 minecraft:stripped_dark_oak_log
setblock 535 104 323 minecraft:stripped_dark_oak_log
setblock 538 104 363 minecraft:stripped_dark_oak_log
setblock 542 104 323 minecraft:stripped_dark_oak_log
setblock 545 104 363 minecraft:stripped_dark_oak_log
setblock 549 104 323 minecraft:stripped_dark_oak_log
setblock 552 104 363 minecraft:stripped_dark_oak_log
fill 555 104 352 556 104 356 minecraft:red_concrete
setblock 556 104 323 minecraft:stripped_dark_oak_log
setblock 558 104 328 minecraft:stripped_dark_oak_log
setblock 558 104 335 minecraft:stripped_dark_oak_log
setblock 558 104 342 minecraft:stripped_dark_oak_log
setblock 558 104 349 minecraft:stripped_dark_oak_log
setblock 558 104 356 minecraft:stripped_dark_oak_log
fill 518 105 336 520 105 336 minecraft:iron_bars
fill 525 105 360 525 106 360 minecraft:iron_bars
fill 525 105 362 525 106 362 minecraft:iron_bars
fill 554 105 353 557 105 355 minecraft:red_concrete
setblock 518 106 329 minecraft:stripped_dark_oak_log
setblock 518 106 336 minecraft:stripped_dark_oak_log
setblock 518 106 343 minecraft:stripped_dark_oak_log
setblock 518 106 350 minecraft:stripped_dark_oak_log
setblock 518 106 357 minecraft:stripped_dark_oak_log
setblock 519 106 323 minecraft:stripped_dark_oak_log
fill 519 106 336 520 106 336 minecraft:iron_bars
setblock 519 106 363 minecraft:stripped_dark_oak_log
setblock 526 106 323 minecraft:stripped_dark_oak_log
setblock 526 106 363 minecraft:stripped_dark_oak_log
setblock 533 106 323 minecraft:stripped_dark_oak_log
setblock 533 106 363 minecraft:stripped_dark_oak_log
setblock 540 106 323 minecraft:stripped_dark_oak_log
setblock 540 106 363 minecraft:stripped_dark_oak_log
setblock 547 106 323 minecraft:stripped_dark_oak_log
setblock 547 106 363 minecraft:stripped_dark_oak_log
setblock 554 106 323 minecraft:stripped_dark_oak_log
setblock 554 106 363 minecraft:stripped_dark_oak_log
setblock 558 106 326 minecraft:stripped_dark_oak_log
setblock 558 106 333 minecraft:stripped_dark_oak_log
setblock 558 106 340 minecraft:stripped_dark_oak_log
setblock 558 106 347 minecraft:stripped_dark_oak_log
setblock 558 106 354 minecraft:stripped_dark_oak_log
setblock 558 106 361 minecraft:stripped_dark_oak_log
setblock 518 107 323 minecraft:stripped_dark_oak_log
setblock 518 107 330 minecraft:stripped_dark_oak_log
setblock 518 107 337 minecraft:stripped_dark_oak_log
setblock 518 107 344 minecraft:stripped_dark_oak_log
setblock 518 107 351 minecraft:stripped_dark_oak_log
setblock 518 107 358 minecraft:stripped_dark_oak_log
setblock 520 107 363 minecraft:stripped_dark_oak_log
setblock 525 107 323 minecraft:stripped_dark_oak_log
setblock 527 107 363 minecraft:stripped_dark_oak_log
setblock 532 107 323 minecraft:stripped_dark_oak_log
setblock 534 107 363 minecraft:stripped_dark_oak_log
setblock 539 107 323 minecraft:stripped_dark_oak_log
setblock 541 107 363 minecraft:stripped_dark_oak_log
setblock 546 107 323 minecraft:stripped_dark_oak_log
setblock 548 107 363 minecraft:stripped_dark_oak_log
setblock 553 107 323 minecraft:stripped_dark_oak_log
setblock 555 107 363 minecraft:stripped_dark_oak_log
setblock 558 107 325 minecraft:stripped_dark_oak_log
setblock 558 107 332 minecraft:stripped_dark_oak_log
setblock 558 107 339 minecraft:stripped_dark_oak_log
setblock 558 107 346 minecraft:stripped_dark_oak_log
setblock 558 107 353 minecraft:stripped_dark_oak_log
setblock 558 107 360 minecraft:stripped_dark_oak_log
setblock 518 108 324 minecraft:stripped_dark_oak_log
setblock 518 108 331 minecraft:stripped_dark_oak_log
setblock 518 108 338 minecraft:stripped_dark_oak_log
setblock 518 108 345 minecraft:stripped_dark_oak_log
setblock 518 108 352 minecraft:stripped_dark_oak_log
setblock 518 108 359 minecraft:stripped_dark_oak_log
setblock 520 108 325 minecraft:light[level=14]
setblock 520 108 333 minecraft:light[level=14]
setblock 520 108 341 minecraft:light[level=14]
setblock 520 108 349 minecraft:light[level=14]
setblock 520 108 357 minecraft:light[level=14]
setblock 521 108 363 minecraft:stripped_dark_oak_log
setblock 524 108 323 minecraft:stripped_dark_oak_log
setblock 528 108 325 minecraft:light[level=14]
setblock 528 108 333 minecraft:light[level=14]
setblock 528 108 341 minecraft:light[level=14]
setblock 528 108 349 minecraft:light[level=14]
setblock 528 108 357 minecraft:light[level=14]
setblock 528 108 363 minecraft:stripped_dark_oak_log
setblock 531 108 323 minecraft:stripped_dark_oak_log
setblock 535 108 363 minecraft:stripped_dark_oak_log
setblock 536 108 325 minecraft:light[level=14]
setblock 536 108 333 minecraft:light[level=14]
setblock 536 108 349 minecraft:light[level=14]
setblock 536 108 357 minecraft:light[level=14]
setblock 538 108 323 minecraft:stripped_dark_oak_log
setblock 542 108 363 minecraft:stripped_dark_oak_log
setblock 544 108 325 minecraft:light[level=14]
setblock 544 108 333 minecraft:light[level=14]
setblock 544 108 341 minecraft:light[level=14]
setblock 544 108 349 minecraft:light[level=14]
setblock 544 108 357 minecraft:light[level=14]
setblock 545 108 323 minecraft:stripped_dark_oak_log
setblock 549 108 363 minecraft:stripped_dark_oak_log
setblock 552 108 323 minecraft:stripped_dark_oak_log
setblock 552 108 325 minecraft:light[level=14]
setblock 552 108 333 minecraft:light[level=14]
setblock 552 108 341 minecraft:light[level=14]
setblock 552 108 349 minecraft:light[level=14]
setblock 552 108 357 minecraft:light[level=14]
setblock 556 108 363 minecraft:stripped_dark_oak_log
setblock 558 108 324 minecraft:stripped_dark_oak_log
setblock 558 108 331 minecraft:stripped_dark_oak_log
setblock 558 108 338 minecraft:stripped_dark_oak_log
setblock 558 108 345 minecraft:stripped_dark_oak_log
setblock 558 108 352 minecraft:stripped_dark_oak_log
setblock 558 108 359 minecraft:stripped_dark_oak_log
fill 518 109 325 518 110 325 minecraft:stripped_dark_oak_log
fill 518 109 332 518 110 332 minecraft:stripped_dark_oak_log
fill 518 109 339 518 110 339 minecraft:stripped_dark_oak_log
fill 518 109 346 518 110 346 minecraft:stripped_dark_oak_log
fill 518 109 353 518 110 353 minecraft:stripped_dark_oak_log
fill 518 109 360 518 110 360 minecraft:stripped_dark_oak_log
fill 522 109 363 522 110 363 minecraft:stripped_dark_oak_log
fill 523 109 323 523 110 323 minecraft:stripped_dark_oak_log
fill 529 109 363 529 110 363 minecraft:stripped_dark_oak_log
fill 530 109 323 530 110 323 minecraft:stripped_dark_oak_log
fill 536 109 363 536 110 363 minecraft:stripped_dark_oak_log
fill 537 109 323 537 110 323 minecraft:stripped_dark_oak_log
fill 543 109 363 543 110 363 minecraft:stripped_dark_oak_log
fill 544 109 323 544 110 323 minecraft:stripped_dark_oak_log
fill 550 109 363 550 110 363 minecraft:stripped_dark_oak_log
fill 551 109 323 551 110 323 minecraft:stripped_dark_oak_log
fill 557 109 363 557 110 363 minecraft:stripped_dark_oak_log
fill 558 109 323 558 110 323 minecraft:stripped_dark_oak_log
fill 558 109 330 558 110 330 minecraft:stripped_dark_oak_log
fill 558 109 337 558 110 337 minecraft:stripped_dark_oak_log
fill 558 109 344 558 110 344 minecraft:stripped_dark_oak_log
fill 558 109 351 558 110 351 minecraft:stripped_dark_oak_log
fill 558 109 358 558 110 358 minecraft:stripped_dark_oak_log
fill 518 110 323 518 110 324 minecraft:stripped_dark_oak_log
fill 518 110 326 518 110 327 minecraft:stripped_dark_oak_log
fill 518 110 329 518 110 331 minecraft:stripped_dark_oak_log
fill 518 110 333 518 110 334 minecraft:stripped_dark_oak_log
fill 518 110 336 518 110 338 minecraft:stripped_dark_oak_log
fill 518 110 340 518 110 341 minecraft:stripped_dark_oak_log
fill 518 110 343 518 110 345 minecraft:stripped_dark_oak_log
fill 518 110 347 518 110 348 minecraft:stripped_dark_oak_log
fill 518 110 350 518 110 352 minecraft:stripped_dark_oak_log
fill 518 110 354 518 110 355 minecraft:stripped_dark_oak_log
fill 518 110 357 518 110 359 minecraft:stripped_dark_oak_log
fill 518 110 361 518 110 362 minecraft:stripped_dark_oak_log
setblock 519 110 323 minecraft:stripped_dark_oak_log
fill 519 110 363 521 110 363 minecraft:stripped_dark_oak_log
fill 521 110 323 522 110 323 minecraft:stripped_dark_oak_log
fill 523 110 363 524 110 363 minecraft:stripped_dark_oak_log
fill 524 110 323 526 110 323 minecraft:stripped_dark_oak_log
fill 526 110 363 528 110 363 minecraft:stripped_dark_oak_log
fill 528 110 323 529 110 323 minecraft:stripped_dark_oak_log
fill 530 110 363 531 110 363 minecraft:stripped_dark_oak_log
fill 531 110 323 533 110 323 minecraft:stripped_dark_oak_log
fill 533 110 363 535 110 363 minecraft:stripped_dark_oak_log
fill 535 110 323 536 110 323 minecraft:stripped_dark_oak_log
fill 537 110 363 538 110 363 minecraft:stripped_dark_oak_log
fill 538 110 323 540 110 323 minecraft:stripped_dark_oak_log
fill 540 110 363 542 110 363 minecraft:stripped_dark_oak_log
fill 542 110 323 543 110 323 minecraft:stripped_dark_oak_log
fill 544 110 363 545 110 363 minecraft:stripped_dark_oak_log
fill 545 110 323 547 110 323 minecraft:stripped_dark_oak_log
fill 547 110 363 549 110 363 minecraft:stripped_dark_oak_log
fill 549 110 323 550 110 323 minecraft:stripped_dark_oak_log
fill 551 110 363 552 110 363 minecraft:stripped_dark_oak_log
fill 552 110 323 554 110 323 minecraft:stripped_dark_oak_log
fill 554 110 363 556 110 363 minecraft:stripped_dark_oak_log
fill 556 110 323 557 110 323 minecraft:stripped_dark_oak_log
fill 558 110 324 558 110 326 minecraft:stripped_dark_oak_log
fill 558 110 328 558 110 329 minecraft:stripped_dark_oak_log
fill 558 110 331 558 110 333 minecraft:stripped_dark_oak_log
fill 558 110 335 558 110 336 minecraft:stripped_dark_oak_log
fill 558 110 338 558 110 340 minecraft:stripped_dark_oak_log
fill 558 110 342 558 110 343 minecraft:stripped_dark_oak_log
fill 558 110 345 558 110 347 minecraft:stripped_dark_oak_log
fill 558 110 349 558 110 350 minecraft:stripped_dark_oak_log
fill 558 110 352 558 110 354 minecraft:stripped_dark_oak_log
fill 558 110 356 558 110 357 minecraft:stripped_dark_oak_log
fill 558 110 359 558 110 361 minecraft:stripped_dark_oak_log
setblock 558 110 363 minecraft:stripped_dark_oak_log
setblock 518 111 327 minecraft:stripped_dark_oak_log
setblock 518 111 334 minecraft:stripped_dark_oak_log
setblock 518 111 341 minecraft:stripped_dark_oak_log
setblock 518 111 348 minecraft:stripped_dark_oak_log
setblock 518 111 355 minecraft:stripped_dark_oak_log
setblock 518 111 362 minecraft:stripped_dark_oak_log
setblock 521 111 323 minecraft:stripped_dark_oak_log
setblock 524 111 363 minecraft:stripped_dark_oak_log
setblock 528 111 323 minecraft:stripped_dark_oak_log
setblock 531 111 363 minecraft:stripped_dark_oak_log
setblock 535 111 323 minecraft:stripped_dark_oak_log
setblock 538 111 363 minecraft:stripped_dark_oak_log
setblock 542 111 323 minecraft:stripped_dark_oak_log
setblock 545 111 363 minecraft:stripped_dark_oak_log
setblock 549 111 323 minecraft:stripped_dark_oak_log
setblock 552 111 363 minecraft:stripped_dark_oak_log
setblock 556 111 323 minecraft:stripped_dark_oak_log
setblock 558 111 328 minecraft:stripped_dark_oak_log
setblock 558 111 335 minecraft:stripped_dark_oak_log
setblock 558 111 342 minecraft:stripped_dark_oak_log
setblock 558 111 349 minecraft:stripped_dark_oak_log
setblock 558 111 356 minecraft:stripped_dark_oak_log
setblock 518 113 329 minecraft:stripped_dark_oak_log
setblock 518 113 336 minecraft:stripped_dark_oak_log
setblock 518 113 343 minecraft:stripped_dark_oak_log
setblock 518 113 350 minecraft:stripped_dark_oak_log
setblock 518 113 357 minecraft:stripped_dark_oak_log
setblock 519 113 323 minecraft:stripped_dark_oak_log
setblock 519 113 363 minecraft:stripped_dark_oak_log
setblock 526 113 323 minecraft:stripped_dark_oak_log
setblock 526 113 363 minecraft:stripped_dark_oak_log
fill 528 113 358 528 114 359 minecraft:cherry_leaves[persistent=true]
setblock 533 113 323 minecraft:stripped_dark_oak_log
setblock 533 113 363 minecraft:stripped_dark_oak_log
setblock 540 113 323 minecraft:stripped_dark_oak_log
setblock 540 113 363 minecraft:stripped_dark_oak_log
setblock 547 113 323 minecraft:stripped_dark_oak_log
setblock 547 113 363 minecraft:stripped_dark_oak_log
setblock 554 113 323 minecraft:stripped_dark_oak_log
setblock 554 113 363 minecraft:stripped_dark_oak_log
setblock 558 113 326 minecraft:stripped_dark_oak_log
setblock 558 113 333 minecraft:stripped_dark_oak_log
setblock 558 113 340 minecraft:stripped_dark_oak_log
setblock 558 113 347 minecraft:stripped_dark_oak_log
setblock 558 113 354 minecraft:stripped_dark_oak_log
setblock 558 113 361 minecraft:stripped_dark_oak_log
setblock 518 114 323 minecraft:stripped_dark_oak_log
setblock 518 114 330 minecraft:stripped_dark_oak_log
setblock 518 114 337 minecraft:stripped_dark_oak_log
setblock 518 114 344 minecraft:stripped_dark_oak_log
setblock 518 114 351 minecraft:stripped_dark_oak_log
setblock 518 114 358 minecraft:stripped_dark_oak_log
setblock 520 114 363 minecraft:stripped_dark_oak_log
setblock 525 114 323 minecraft:stripped_dark_oak_log
setblock 527 114 363 minecraft:stripped_dark_oak_log
setblock 532 114 323 minecraft:stripped_dark_oak_log
setblock 534 114 363 minecraft:stripped_dark_oak_log
setblock 539 114 323 minecraft:stripped_dark_oak_log
setblock 541 114 363 minecraft:stripped_dark_oak_log
setblock 546 114 323 minecraft:stripped_dark_oak_log
setblock 548 114 363 minecraft:stripped_dark_oak_log
setblock 553 114 323 minecraft:stripped_dark_oak_log
setblock 555 114 363 minecraft:stripped_dark_oak_log
setblock 558 114 325 minecraft:stripped_dark_oak_log
setblock 558 114 332 minecraft:stripped_dark_oak_log
setblock 558 114 339 minecraft:stripped_dark_oak_log
setblock 558 114 346 minecraft:stripped_dark_oak_log
setblock 558 114 353 minecraft:stripped_dark_oak_log
setblock 558 114 360 minecraft:stripped_dark_oak_log
setblock 518 115 324 minecraft:stripped_dark_oak_log
setblock 518 115 331 minecraft:stripped_dark_oak_log
setblock 518 115 338 minecraft:stripped_dark_oak_log
setblock 518 115 345 minecraft:stripped_dark_oak_log
setblock 518 115 352 minecraft:stripped_dark_oak_log
setblock 518 115 359 minecraft:stripped_dark_oak_log
setblock 521 115 363 minecraft:stripped_dark_oak_log
setblock 524 115 323 minecraft:stripped_dark_oak_log
setblock 528 115 363 minecraft:stripped_dark_oak_log
setblock 531 115 323 minecraft:stripped_dark_oak_log
setblock 535 115 363 minecraft:stripped_dark_oak_log
setblock 538 115 323 minecraft:stripped_dark_oak_log
setblock 542 115 363 minecraft:stripped_dark_oak_log
setblock 545 115 323 minecraft:stripped_dark_oak_log
setblock 549 115 363 minecraft:stripped_dark_oak_log
setblock 552 115 323 minecraft:stripped_dark_oak_log
setblock 556 115 363 minecraft:stripped_dark_oak_log
setblock 558 115 324 minecraft:stripped_dark_oak_log
setblock 558 115 331 minecraft:stripped_dark_oak_log
setblock 558 115 338 minecraft:stripped_dark_oak_log
setblock 558 115 345 minecraft:stripped_dark_oak_log
setblock 558 115 352 minecraft:stripped_dark_oak_log
setblock 558 115 359 minecraft:stripped_dark_oak_log
setblock 518 116 325 minecraft:stripped_dark_oak_log
setblock 518 116 332 minecraft:stripped_dark_oak_log
setblock 518 116 339 minecraft:stripped_dark_oak_log
setblock 518 116 346 minecraft:stripped_dark_oak_log
setblock 518 116 353 minecraft:stripped_dark_oak_log
setblock 518 116 360 minecraft:stripped_dark_oak_log
setblock 520 116 325 minecraft:light[level=14]
setblock 520 116 333 minecraft:light[level=14]
setblock 520 116 341 minecraft:light[level=14]
setblock 520 116 349 minecraft:light[level=14]
setblock 520 116 357 minecraft:light[level=14]
fill 522 116 361 528 117 361 minecraft:iron_bars
setblock 522 116 363 minecraft:stripped_dark_oak_log
setblock 523 116 323 minecraft:stripped_dark_oak_log
setblock 528 116 325 minecraft:light[level=14]
setblock 528 116 333 minecraft:light[level=14]
setblock 528 116 341 minecraft:light[level=14]
setblock 528 116 349 minecraft:light[level=14]
setblock 528 116 357 minecraft:light[level=14]
setblock 529 116 363 minecraft:stripped_dark_oak_log
setblock 530 116 323 minecraft:stripped_dark_oak_log
setblock 536 116 325 minecraft:light[level=14]
setblock 536 116 333 minecraft:light[level=14]
setblock 536 116 349 minecraft:light[level=14]
setblock 536 116 357 minecraft:light[level=14]
setblock 536 116 363 minecraft:stripped_dark_oak_log
setblock 537 116 323 minecraft:stripped_dark_oak_log
setblock 543 116 363 minecraft:stripped_dark_oak_log
setblock 544 116 323 minecraft:stripped_dark_oak_log
setblock 544 116 325 minecraft:light[level=14]
setblock 544 116 333 minecraft:light[level=14]
setblock 544 116 341 minecraft:light[level=14]
setblock 544 116 349 minecraft:light[level=14]
setblock 544 116 357 minecraft:light[level=14]
setblock 550 116 363 minecraft:stripped_dark_oak_log
setblock 551 116 323 minecraft:stripped_dark_oak_log
setblock 552 116 325 minecraft:light[level=14]
setblock 552 116 333 minecraft:light[level=14]
setblock 552 116 341 minecraft:light[level=14]
setblock 552 116 349 minecraft:light[level=14]
setblock 552 116 357 minecraft:light[level=14]
setblock 557 116 363 minecraft:stripped_dark_oak_log
setblock 558 116 323 minecraft:stripped_dark_oak_log
setblock 558 116 330 minecraft:stripped_dark_oak_log
setblock 558 116 337 minecraft:stripped_dark_oak_log
setblock 558 116 344 minecraft:stripped_dark_oak_log
setblock 558 116 351 minecraft:stripped_dark_oak_log
setblock 558 116 358 minecraft:stripped_dark_oak_log
setblock 518 117 326 minecraft:stripped_dark_oak_log
setblock 518 117 333 minecraft:stripped_dark_oak_log
setblock 518 117 340 minecraft:stripped_dark_oak_log
setblock 518 117 347 minecraft:stripped_dark_oak_log
setblock 518 117 354 minecraft:stripped_dark_oak_log
setblock 518 117 361 minecraft:stripped_dark_oak_log
setblock 522 117 323 minecraft:stripped_dark_oak_log
setblock 523 117 363 minecraft:stripped_dark_oak_log
setblock 529 117 323 minecraft:stripped_dark_oak_log
setblock 530 117 363 minecraft:stripped_dark_oak_log
setblock 536 117 323 minecraft:stripped_dark_oak_log
setblock 537 117 363 minecraft:stripped_dark_oak_log
setblock 543 117 323 minecraft:stripped_dark_oak_log
setblock 544 117 363 minecraft:stripped_dark_oak_log
setblock 550 117 323 minecraft:stripped_dark_oak_log
setblock 551 117 363 minecraft:stripped_dark_oak_log
setblock 557 117 323 minecraft:stripped_dark_oak_log
setblock 558 117 329 minecraft:stripped_dark_oak_log
setblock 558 117 336 minecraft:stripped_dark_oak_log
setblock 558 117 343 minecraft:stripped_dark_oak_log
setblock 558 117 350 minecraft:stripped_dark_oak_log
setblock 558 117 357 minecraft:stripped_dark_oak_log
setblock 558 117 363 minecraft:stripped_dark_oak_log
setblock 518 118 327 minecraft:stripped_dark_oak_log
setblock 518 118 334 minecraft:stripped_dark_oak_log
setblock 518 118 341 minecraft:stripped_dark_oak_log
setblock 518 118 348 minecraft:stripped_dark_oak_log
setblock 518 118 355 minecraft:stripped_dark_oak_log
setblock 518 118 362 minecraft:stripped_dark_oak_log
setblock 521 118 323 minecraft:stripped_dark_oak_log
setblock 524 118 363 minecraft:stripped_dark_oak_log
setblock 528 118 323 minecraft:stripped_dark_oak_log
setblock 531 118 363 minecraft:stripped_dark_oak_log
setblock 535 118 323 minecraft:stripped_dark_oak_log
setblock 538 118 363 minecraft:stripped_dark_oak_log
setblock 542 118 323 minecraft:stripped_dark_oak_log
setblock 545 118 363 minecraft:stripped_dark_oak_log
fill 547 118 334 548 119 335 minecraft:pink_wool
setblock 549 118 323 minecraft:stripped_dark_oak_log
setblock 552 118 363 minecraft:stripped_dark_oak_log
setblock 556 118 323 minecraft:stripped_dark_oak_log
setblock 558 118 328 minecraft:stripped_dark_oak_log
setblock 558 118 335 minecraft:stripped_dark_oak_log
setblock 558 118 342 minecraft:stripped_dark_oak_log
setblock 558 118 349 minecraft:stripped_dark_oak_log
setblock 558 118 356 minecraft:stripped_dark_oak_log
fill 519 119 332 519 132 332 minecraft:red_wool
fill 518 120 323 518 120 327 minecraft:stripped_dark_oak_log
fill 518 120 329 518 120 334 minecraft:stripped_dark_oak_log
fill 518 120 336 518 120 341 minecraft:stripped_dark_oak_log
fill 518 120 343 518 120 348 minecraft:stripped_dark_oak_log
fill 518 120 350 518 120 355 minecraft:stripped_dark_oak_log
fill 518 120 357 518 120 362 minecraft:stripped_dark_oak_log
setblock 519 120 323 minecraft:stripped_dark_oak_log
fill 519 120 330 519 132 331 minecraft:red_wool
fill 519 120 333 519 132 334 minecraft:red_wool
fill 519 120 363 524 120 363 minecraft:stripped_dark_oak_log
fill 521 120 323 526 120 323 minecraft:stripped_dark_oak_log
fill 526 120 363 531 120 363 minecraft:stripped_dark_oak_log
fill 528 120 323 533 120 323 minecraft:stripped_dark_oak_log
fill 533 120 363 538 120 363 minecraft:stripped_dark_oak_log
fill 535 120 323 540 120 323 minecraft:stripped_dark_oak_log
fill 540 120 363 545 120 363 minecraft:stripped_dark_oak_log
fill 542 120 323 547 120 323 minecraft:stripped_dark_oak_log
fill 547 120 363 552 120 363 minecraft:stripped_dark_oak_log
fill 549 120 323 554 120 323 minecraft:stripped_dark_oak_log
fill 554 120 363 558 120 363 minecraft:stripped_dark_oak_log
fill 556 120 323 558 120 323 minecraft:stripped_dark_oak_log
fill 558 120 324 558 120 326 minecraft:stripped_dark_oak_log
fill 558 120 328 558 120 333 minecraft:stripped_dark_oak_log
fill 558 120 335 558 120 340 minecraft:stripped_dark_oak_log
fill 558 120 342 558 120 347 minecraft:stripped_dark_oak_log
fill 558 120 349 558 120 354 minecraft:stripped_dark_oak_log
fill 558 120 356 558 120 361 minecraft:stripped_dark_oak_log
setblock 518 121 323 minecraft:stripped_dark_oak_log
setblock 518 121 330 minecraft:stripped_dark_oak_log
setblock 518 121 337 minecraft:stripped_dark_oak_log
setblock 518 121 344 minecraft:stripped_dark_oak_log
setblock 518 121 351 minecraft:stripped_dark_oak_log
setblock 518 121 358 minecraft:stripped_dark_oak_log
setblock 520 121 363 minecraft:stripped_dark_oak_log
setblock 525 121 323 minecraft:stripped_dark_oak_log
setblock 527 121 363 minecraft:stripped_dark_oak_log
setblock 532 121 323 minecraft:stripped_dark_oak_log
setblock 534 121 363 minecraft:stripped_dark_oak_log
setblock 539 121 323 minecraft:stripped_dark_oak_log
setblock 541 121 363 minecraft:stripped_dark_oak_log
setblock 546 121 323 minecraft:stripped_dark_oak_log
setblock 548 121 363 minecraft:stripped_dark_oak_log
setblock 553 121 323 minecraft:stripped_dark_oak_log
setblock 555 121 363 minecraft:stripped_dark_oak_log
setblock 558 121 325 minecraft:stripped_dark_oak_log
setblock 558 121 332 minecraft:stripped_dark_oak_log
setblock 558 121 339 minecraft:stripped_dark_oak_log
setblock 558 121 346 minecraft:stripped_dark_oak_log
setblock 558 121 353 minecraft:stripped_dark_oak_log
setblock 558 121 360 minecraft:stripped_dark_oak_log
setblock 518 122 324 minecraft:stripped_dark_oak_log
setblock 518 122 331 minecraft:stripped_dark_oak_log
setblock 518 122 338 minecraft:stripped_dark_oak_log
setblock 518 122 345 minecraft:stripped_dark_oak_log
setblock 518 122 352 minecraft:stripped_dark_oak_log
setblock 518 122 359 minecraft:stripped_dark_oak_log
setblock 521 122 363 minecraft:stripped_dark_oak_log
setblock 524 122 323 minecraft:stripped_dark_oak_log
setblock 528 122 363 minecraft:stripped_dark_oak_log
setblock 531 122 323 minecraft:stripped_dark_oak_log
setblock 535 122 363 minecraft:stripped_dark_oak_log
setblock 538 122 323 minecraft:stripped_dark_oak_log
setblock 542 122 363 minecraft:stripped_dark_oak_log
setblock 545 122 323 minecraft:stripped_dark_oak_log
setblock 549 122 363 minecraft:stripped_dark_oak_log
setblock 552 122 323 minecraft:stripped_dark_oak_log
setblock 556 122 363 minecraft:stripped_dark_oak_log
setblock 558 122 324 minecraft:stripped_dark_oak_log
setblock 558 122 331 minecraft:stripped_dark_oak_log
setblock 558 122 338 minecraft:stripped_dark_oak_log
setblock 558 122 345 minecraft:stripped_dark_oak_log
setblock 558 122 352 minecraft:stripped_dark_oak_log
setblock 558 122 359 minecraft:stripped_dark_oak_log
setblock 518 123 325 minecraft:stripped_dark_oak_log
setblock 518 123 332 minecraft:stripped_dark_oak_log
setblock 518 123 339 minecraft:stripped_dark_oak_log
setblock 518 123 346 minecraft:stripped_dark_oak_log
setblock 518 123 353 minecraft:stripped_dark_oak_log
setblock 518 123 360 minecraft:stripped_dark_oak_log
setblock 522 123 363 minecraft:stripped_dark_oak_log
setblock 523 123 323 minecraft:stripped_dark_oak_log
setblock 529 123 363 minecraft:stripped_dark_oak_log
setblock 530 123 323 minecraft:stripped_dark_oak_log
setblock 536 123 363 minecraft:stripped_dark_oak_log
setblock 537 123 323 minecraft:stripped_dark_oak_log
setblock 543 123 363 minecraft:stripped_dark_oak_log
setblock 544 123 323 minecraft:stripped_dark_oak_log
setblock 550 123 363 minecraft:stripped_dark_oak_log
setblock 551 123 323 minecraft:stripped_dark_oak_log
setblock 557 123 363 minecraft:stripped_dark_oak_log
setblock 558 123 323 minecraft:stripped_dark_oak_log
setblock 558 123 330 minecraft:stripped_dark_oak_log
setblock 558 123 337 minecraft:stripped_dark_oak_log
setblock 558 123 344 minecraft:stripped_dark_oak_log
setblock 558 123 351 minecraft:stripped_dark_oak_log
setblock 558 123 358 minecraft:stripped_dark_oak_log
setblock 518 124 326 minecraft:stripped_dark_oak_log
setblock 518 124 333 minecraft:stripped_dark_oak_log
setblock 518 124 340 minecraft:stripped_dark_oak_log
setblock 518 124 347 minecraft:stripped_dark_oak_log
setblock 518 124 354 minecraft:stripped_dark_oak_log
setblock 518 124 361 minecraft:stripped_dark_oak_log
setblock 520 124 325 minecraft:light[level=14]
setblock 520 124 333 minecraft:light[level=14]
setblock 520 124 341 minecraft:light[level=14]
setblock 520 124 349 minecraft:light[level=14]
setblock 520 124 357 minecraft:light[level=14]
setblock 522 124 323 minecraft:stripped_dark_oak_log
setblock 523 124 363 minecraft:stripped_dark_oak_log
setblock 528 124 325 minecraft:light[level=14]
setblock 528 124 333 minecraft:light[level=14]
setblock 528 124 341 minecraft:light[level=14]
setblock 528 124 349 minecraft:light[level=14]
setblock 528 124 357 minecraft:light[level=14]
setblock 529 124 323 minecraft:stripped_dark_oak_log
setblock 530 124 363 minecraft:stripped_dark_oak_log
setblock 536 124 323 minecraft:stripped_dark_oak_log
setblock 536 124 325 minecraft:light[level=14]
setblock 536 124 333 minecraft:light[level=14]
setblock 536 124 349 minecraft:light[level=14]
setblock 536 124 357 minecraft:light[level=14]
setblock 537 124 363 minecraft:stripped_dark_oak_log
setblock 543 124 323 minecraft:stripped_dark_oak_log
setblock 544 124 325 minecraft:light[level=14]
setblock 544 124 333 minecraft:light[level=14]
setblock 544 124 341 minecraft:light[level=14]
setblock 544 124 349 minecraft:light[level=14]
setblock 544 124 357 minecraft:light[level=14]
setblock 544 124 363 minecraft:stripped_dark_oak_log
setblock 550 124 323 minecraft:stripped_dark_oak_log
setblock 551 124 363 minecraft:stripped_dark_oak_log
setblock 552 124 325 minecraft:light[level=14]
setblock 552 124 333 minecraft:light[level=14]
setblock 552 124 341 minecraft:light[level=14]
setblock 552 124 349 minecraft:light[level=14]
setblock 552 124 357 minecraft:light[level=14]
setblock 557 124 323 minecraft:stripped_dark_oak_log
setblock 558 124 329 minecraft:stripped_dark_oak_log
setblock 558 124 336 minecraft:stripped_dark_oak_log
setblock 558 124 343 minecraft:stripped_dark_oak_log
setblock 558 124 350 minecraft:stripped_dark_oak_log
setblock 558 124 357 minecraft:stripped_dark_oak_log
setblock 558 124 363 minecraft:stripped_dark_oak_log
setblock 518 125 327 minecraft:stripped_dark_oak_log
setblock 518 125 334 minecraft:stripped_dark_oak_log
setblock 518 125 341 minecraft:stripped_dark_oak_log
setblock 518 125 348 minecraft:stripped_dark_oak_log
setblock 518 125 355 minecraft:stripped_dark_oak_log
setblock 518 125 362 minecraft:stripped_dark_oak_log
setblock 521 125 323 minecraft:stripped_dark_oak_log
setblock 524 125 363 minecraft:stripped_dark_oak_log
setblock 528 125 323 minecraft:stripped_dark_oak_log
setblock 531 125 363 minecraft:stripped_dark_oak_log
setblock 535 125 323 minecraft:stripped_dark_oak_log
setblock 538 125 363 minecraft:stripped_dark_oak_log
setblock 542 125 323 minecraft:stripped_dark_oak_log
setblock 545 125 363 minecraft:stripped_dark_oak_log
setblock 549 125 323 minecraft:stripped_dark_oak_log
setblock 552 125 363 minecraft:stripped_dark_oak_log
setblock 556 125 323 minecraft:stripped_dark_oak_log
setblock 558 125 328 minecraft:stripped_dark_oak_log
setblock 558 125 335 minecraft:stripped_dark_oak_log
schedule function dropper:buildpart/83_2 1t
