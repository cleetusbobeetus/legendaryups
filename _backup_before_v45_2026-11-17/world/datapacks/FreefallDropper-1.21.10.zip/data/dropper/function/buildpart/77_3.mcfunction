setblock 259 135 325 minecraft:light[level=12]
setblock 259 135 332 minecraft:light[level=12]
setblock 259 135 339 minecraft:light[level=12]
setblock 259 135 346 minecraft:light[level=12]
setblock 259 135 353 minecraft:light[level=12]
setblock 259 135 360 minecraft:light[level=12]
fill 259 135 363 259 138 363 minecraft:moss_block
setblock 263 135 323 minecraft:mushroom_stem
setblock 263 135 363 minecraft:mushroom_stem
fill 264 135 323 265 137 323 minecraft:moss_block
fill 264 135 363 267 135 363 minecraft:moss_block
setblock 266 135 325 minecraft:light[level=12]
setblock 266 135 332 minecraft:light[level=12]
setblock 266 135 339 minecraft:light[level=12]
setblock 266 135 346 minecraft:light[level=12]
setblock 266 135 353 minecraft:light[level=12]
setblock 266 135 360 minecraft:light[level=12]
setblock 267 135 323 minecraft:moss_block
setblock 268 135 323 minecraft:mushroom_stem
setblock 268 135 363 minecraft:mushroom_stem
setblock 268 135 364 minecraft:shroomlight
fill 269 135 323 269 138 323 minecraft:moss_block
setblock 269 135 362 minecraft:mushroom_stem
fill 269 135 363 269 138 363 minecraft:moss_block
fill 269 135 364 270 135 364 minecraft:brown_terracotta
fill 270 135 362 270 138 362 minecraft:moss_block
setblock 273 135 323 minecraft:mushroom_stem
fill 273 135 324 273 138 324 minecraft:moss_block
setblock 273 135 325 minecraft:light[level=12]
setblock 273 135 332 minecraft:light[level=12]
setblock 273 135 339 minecraft:light[level=12]
setblock 273 135 353 minecraft:light[level=12]
setblock 273 135 360 minecraft:light[level=12]
setblock 273 135 363 minecraft:mushroom_stem
fill 274 135 323 274 138 323 minecraft:moss_block
setblock 274 135 357 minecraft:mushroom_stem
fill 274 135 358 274 138 358 minecraft:moss_block
setblock 274 135 362 minecraft:mushroom_stem
fill 274 135 363 274 138 363 minecraft:moss_block
setblock 275 135 337 minecraft:moss_block
setblock 275 135 356 minecraft:mushroom_stem
fill 275 135 357 275 138 357 minecraft:moss_block
setblock 275 135 361 minecraft:mushroom_stem
fill 275 135 362 275 138 362 minecraft:moss_block
setblock 276 135 325 minecraft:mushroom_stem
fill 276 135 326 276 138 326 minecraft:moss_block
setblock 276 135 335 minecraft:mushroom_stem
fill 276 135 336 276 138 336 minecraft:moss_block
setblock 276 135 340 minecraft:mushroom_stem
fill 276 135 341 276 138 341 minecraft:moss_block
setblock 276 135 345 minecraft:mushroom_stem
fill 276 135 346 276 138 346 minecraft:moss_block
setblock 276 135 349 minecraft:red_mushroom_block
fill 276 135 351 276 138 351 minecraft:moss_block
setblock 276 135 355 minecraft:mushroom_stem
fill 276 135 356 276 138 356 minecraft:moss_block
setblock 276 135 360 minecraft:mushroom_stem
fill 276 135 361 276 138 361 minecraft:moss_block
setblock 236 136 324 minecraft:mushroom_stem
setblock 236 136 334 minecraft:mushroom_stem
fill 236 136 335 236 139 335 minecraft:moss_block
setblock 236 136 339 minecraft:mushroom_stem
fill 236 136 340 236 136 343 minecraft:moss_block
setblock 236 136 344 minecraft:mushroom_stem
fill 236 136 345 236 139 345 minecraft:moss_block
setblock 236 136 349 minecraft:mushroom_stem
fill 236 136 350 236 139 350 minecraft:moss_block
setblock 236 136 354 minecraft:mushroom_stem
fill 236 136 355 236 139 355 minecraft:moss_block
setblock 236 136 359 minecraft:mushroom_stem
fill 236 136 360 236 139 360 minecraft:moss_block
setblock 237 136 323 minecraft:mushroom_stem
setblock 237 136 338 minecraft:mushroom_stem
fill 237 136 339 237 139 339 minecraft:moss_block
setblock 237 136 343 minecraft:mushroom_stem
fill 237 136 344 237 139 344 minecraft:moss_block
setblock 237 136 353 minecraft:mushroom_stem
fill 237 136 354 237 137 354 minecraft:moss_block
setblock 237 136 358 minecraft:mushroom_stem
fill 237 136 359 237 139 359 minecraft:moss_block
setblock 237 136 363 minecraft:mushroom_stem
setblock 238 136 358 minecraft:moss_block
setblock 238 136 362 minecraft:mushroom_stem
fill 238 136 363 238 139 363 minecraft:moss_block
fill 239 136 362 239 139 362 minecraft:moss_block
setblock 242 136 363 minecraft:mushroom_stem
setblock 246 136 323 minecraft:red_mushroom_block
setblock 248 136 322 minecraft:shroomlight
setblock 251 136 363 minecraft:moss_block
setblock 252 136 323 minecraft:mushroom_stem
setblock 252 136 363 minecraft:mushroom_stem
fill 253 136 323 253 139 323 minecraft:moss_block
fill 253 136 363 253 139 363 minecraft:moss_block
fill 254 136 362 254 139 362 minecraft:moss_block
setblock 255 136 324 minecraft:moss_block
setblock 256 136 324 minecraft:mushroom_stem
setblock 257 136 323 minecraft:mushroom_stem
fill 257 136 324 257 139 324 minecraft:moss_block
setblock 257 136 363 minecraft:mushroom_stem
fill 258 136 323 258 139 323 minecraft:moss_block
setblock 258 136 362 minecraft:mushroom_stem
fill 258 136 363 258 139 363 minecraft:moss_block
setblock 262 136 323 minecraft:mushroom_stem
setblock 262 136 363 minecraft:mushroom_stem
fill 263 136 323 263 139 323 minecraft:moss_block
fill 263 136 363 266 136 363 minecraft:moss_block
setblock 266 136 323 minecraft:moss_block
setblock 267 136 323 minecraft:mushroom_stem
setblock 267 136 363 minecraft:mushroom_stem
fill 268 136 323 268 139 323 minecraft:moss_block
fill 268 136 363 268 139 363 minecraft:moss_block
fill 268 136 364 268 147 364 minecraft:brown_terracotta
fill 269 136 362 269 139 362 minecraft:moss_block
setblock 269 136 364 minecraft:red_mushroom_block
fill 270 136 364 270 144 364 minecraft:brown_terracotta
fill 271 136 361 271 138 361 minecraft:moss_block
setblock 272 136 323 minecraft:mushroom_stem
fill 272 136 324 272 139 324 minecraft:moss_block
setblock 272 136 363 minecraft:mushroom_stem
fill 273 136 323 273 139 323 minecraft:moss_block
setblock 273 136 362 minecraft:mushroom_stem
fill 273 136 363 273 139 363 minecraft:moss_block
fill 273 136 364 273 147 364 minecraft:brown_terracotta
setblock 274 136 361 minecraft:mushroom_stem
fill 274 136 362 274 139 362 minecraft:moss_block
setblock 274 136 364 minecraft:shroomlight
setblock 275 136 340 minecraft:mushroom_stem
fill 275 136 341 275 139 341 minecraft:moss_block
setblock 275 136 355 minecraft:mushroom_stem
fill 275 136 356 275 139 356 minecraft:moss_block
setblock 275 136 360 minecraft:mushroom_stem
fill 275 136 361 275 139 361 minecraft:moss_block
setblock 276 136 324 minecraft:mushroom_stem
fill 276 136 325 276 139 325 minecraft:moss_block
setblock 276 136 334 minecraft:mushroom_stem
fill 276 136 335 276 137 335 minecraft:moss_block
setblock 276 136 339 minecraft:mushroom_stem
fill 276 136 340 276 139 340 minecraft:moss_block
setblock 276 136 344 minecraft:mushroom_stem
fill 276 136 345 276 139 345 minecraft:moss_block
fill 276 136 347 276 137 347 minecraft:moss_block
setblock 276 136 354 minecraft:mushroom_stem
fill 276 136 355 276 139 355 minecraft:moss_block
setblock 276 136 359 minecraft:mushroom_stem
fill 276 136 360 276 139 360 minecraft:moss_block
setblock 236 137 323 minecraft:mushroom_stem
fill 236 137 324 236 140 324 minecraft:moss_block
setblock 236 137 330 minecraft:red_mushroom_block
setblock 236 137 338 minecraft:mushroom_stem
fill 236 137 339 236 137 342 minecraft:moss_block
setblock 236 137 343 minecraft:mushroom_stem
fill 236 137 344 236 140 344 minecraft:moss_block
setblock 236 137 348 minecraft:mushroom_stem
fill 236 137 349 236 140 349 minecraft:moss_block
setblock 236 137 353 minecraft:mushroom_stem
fill 236 137 354 236 140 354 minecraft:moss_block
setblock 236 137 358 minecraft:mushroom_stem
fill 236 137 359 236 140 359 minecraft:moss_block
setblock 236 137 363 minecraft:mushroom_stem
fill 237 137 323 238 139 323 minecraft:moss_block
setblock 237 137 337 minecraft:mushroom_stem
fill 237 137 338 237 140 338 minecraft:moss_block
setblock 237 137 342 minecraft:mushroom_stem
fill 237 137 343 237 140 343 minecraft:moss_block
setblock 237 137 347 minecraft:mushroom_stem
fill 237 137 348 237 140 348 minecraft:moss_block
setblock 237 137 353 minecraft:moss_block
setblock 237 137 357 minecraft:mushroom_stem
fill 237 137 358 237 140 358 minecraft:moss_block
setblock 237 137 362 minecraft:mushroom_stem
fill 237 137 363 237 140 363 minecraft:moss_block
setblock 238 137 361 minecraft:mushroom_stem
fill 238 137 362 238 140 362 minecraft:moss_block
setblock 240 137 323 minecraft:red_mushroom_block
setblock 241 137 363 minecraft:mushroom_stem
fill 242 137 342 244 139 344 minecraft:red_mushroom_block
fill 243 137 345 244 139 345 minecraft:red_mushroom_block
fill 245 137 343 245 139 344 minecraft:red_mushroom_block
setblock 247 137 363 minecraft:red_mushroom_block
fill 248 137 322 249 147 322 minecraft:brown_terracotta
setblock 250 137 322 minecraft:red_mushroom_block
setblock 250 137 363 minecraft:moss_block
fill 251 137 322 255 147 322 minecraft:brown_terracotta
setblock 251 137 323 minecraft:mushroom_stem
setblock 251 137 363 minecraft:mushroom_stem
fill 252 137 323 252 140 323 minecraft:moss_block
fill 252 137 363 252 140 363 minecraft:moss_block
fill 253 137 362 253 140 362 minecraft:moss_block
setblock 254 137 324 minecraft:moss_block
setblock 255 137 324 minecraft:mushroom_stem
setblock 256 137 323 minecraft:mushroom_stem
fill 256 137 324 256 140 324 minecraft:moss_block
setblock 256 137 363 minecraft:mushroom_stem
fill 257 137 323 257 140 323 minecraft:moss_block
setblock 257 137 362 minecraft:mushroom_stem
fill 257 137 363 257 140 363 minecraft:moss_block
fill 258 137 362 258 140 362 minecraft:moss_block
setblock 259 137 324 minecraft:moss_block
setblock 261 137 323 minecraft:mushroom_stem
setblock 261 137 363 minecraft:mushroom_stem
fill 262 137 323 262 140 323 minecraft:moss_block
fill 262 137 363 265 137 363 minecraft:moss_block
setblock 266 137 323 minecraft:mushroom_stem
setblock 266 137 363 minecraft:mushroom_stem
fill 267 137 323 267 140 323 minecraft:moss_block
fill 267 137 363 267 140 363 minecraft:moss_block
fill 268 137 362 268 140 362 minecraft:moss_block
fill 269 137 364 269 145 364 minecraft:brown_terracotta
setblock 270 137 324 minecraft:mushroom_stem
setblock 271 137 323 minecraft:mushroom_stem
fill 271 137 324 271 140 324 minecraft:moss_block
setblock 271 137 363 minecraft:mushroom_stem
fill 272 137 323 272 140 323 minecraft:moss_block
setblock 272 137 362 minecraft:mushroom_stem
fill 272 137 363 272 140 363 minecraft:moss_block
setblock 273 137 361 minecraft:mushroom_stem
fill 273 137 362 273 140 362 minecraft:moss_block
setblock 274 137 360 minecraft:mushroom_stem
fill 274 137 361 274 140 361 minecraft:moss_block
fill 274 137 364 274 147 364 minecraft:brown_terracotta
setblock 275 137 324 minecraft:mushroom_stem
fill 275 137 325 275 140 325 minecraft:moss_block
setblock 275 137 339 minecraft:mushroom_stem
fill 275 137 340 275 140 340 minecraft:moss_block
fill 275 137 342 275 137 343 minecraft:moss_block
fill 275 137 355 275 140 355 minecraft:moss_block
setblock 275 137 359 minecraft:mushroom_stem
fill 275 137 360 275 140 360 minecraft:moss_block
setblock 276 137 323 minecraft:mushroom_stem
fill 276 137 324 276 140 324 minecraft:moss_block
setblock 276 137 331 minecraft:red_mushroom_block
setblock 276 137 338 minecraft:mushroom_stem
fill 276 137 339 276 140 339 minecraft:moss_block
setblock 276 137 343 minecraft:mushroom_stem
fill 276 137 344 276 140 344 minecraft:moss_block
setblock 276 137 348 minecraft:mushroom_stem
fill 276 137 349 276 139 350 minecraft:moss_block
setblock 276 137 353 minecraft:mushroom_stem
fill 276 137 354 276 140 354 minecraft:moss_block
setblock 276 137 358 minecraft:mushroom_stem
fill 276 137 359 276 140 359 minecraft:moss_block
setblock 276 137 363 minecraft:mushroom_stem
fill 236 138 323 236 141 323 minecraft:moss_block
fill 236 138 325 236 139 325 minecraft:moss_block
setblock 236 138 337 minecraft:mushroom_stem
fill 236 138 338 236 138 341 minecraft:moss_block
setblock 236 138 342 minecraft:mushroom_stem
fill 236 138 343 236 141 343 minecraft:moss_block
setblock 236 138 347 minecraft:mushroom_stem
fill 236 138 348 236 141 348 minecraft:moss_block
setblock 236 138 352 minecraft:mushroom_stem
fill 236 138 353 236 141 353 minecraft:moss_block
setblock 236 138 357 minecraft:mushroom_stem
fill 236 138 358 236 141 358 minecraft:moss_block
setblock 236 138 362 minecraft:mushroom_stem
fill 236 138 363 236 141 363 minecraft:moss_block
setblock 237 138 341 minecraft:mushroom_stem
fill 237 138 342 238 140 342 minecraft:moss_block
setblock 237 138 346 minecraft:mushroom_stem
fill 237 138 347 237 141 347 minecraft:moss_block
fill 237 138 349 237 139 349 minecraft:moss_block
setblock 237 138 356 minecraft:mushroom_stem
fill 237 138 357 237 140 357 minecraft:moss_block
setblock 237 138 361 minecraft:mushroom_stem
fill 237 138 362 237 141 362 minecraft:moss_block
fill 238 138 343 238 139 343 minecraft:moss_block
setblock 240 138 363 minecraft:mushroom_stem
fill 241 138 363 241 141 363 minecraft:moss_block
setblock 242 138 345 minecraft:red_mushroom_block
setblock 245 138 342 minecraft:red_mushroom_block
setblock 245 138 345 minecraft:red_mushroom_block
setblock 249 138 323 minecraft:moss_block
setblock 249 138 363 minecraft:moss_block
fill 250 138 322 250 147 322 minecraft:brown_terracotta
setblock 250 138 323 minecraft:mushroom_stem
setblock 250 138 363 minecraft:mushroom_stem
fill 251 138 323 251 141 323 minecraft:moss_block
fill 251 138 363 251 141 363 minecraft:moss_block
fill 252 138 324 253 138 324 minecraft:moss_block
fill 252 138 362 252 141 362 minecraft:moss_block
setblock 254 138 324 minecraft:mushroom_stem
setblock 255 138 323 minecraft:mushroom_stem
fill 255 138 324 255 141 324 minecraft:moss_block
setblock 255 138 363 minecraft:mushroom_stem
fill 256 138 323 256 141 323 minecraft:moss_block
setblock 256 138 362 minecraft:mushroom_stem
fill 256 138 363 256 141 363 minecraft:moss_block
fill 257 138 362 257 141 362 minecraft:moss_block
setblock 259 138 324 minecraft:mushroom_stem
setblock 260 138 323 minecraft:mushroom_stem
fill 260 138 324 260 141 324 minecraft:moss_block
setblock 260 138 363 minecraft:mushroom_stem
fill 261 138 323 261 141 323 minecraft:moss_block
fill 261 138 363 264 138 363 minecraft:moss_block
setblock 264 138 323 minecraft:moss_block
setblock 265 138 323 minecraft:mushroom_stem
setblock 265 138 363 minecraft:mushroom_stem
fill 266 138 323 266 141 323 minecraft:moss_block
fill 266 138 363 266 141 363 minecraft:moss_block
fill 267 138 362 267 141 362 minecraft:moss_block
setblock 269 138 324 minecraft:mushroom_stem
setblock 270 138 323 minecraft:mushroom_stem
fill 270 138 324 270 141 324 minecraft:moss_block
fill 270 138 361 270 139 361 minecraft:moss_block
setblock 270 138 363 minecraft:mushroom_stem
fill 271 138 323 271 141 323 minecraft:moss_block
setblock 271 138 362 minecraft:mushroom_stem
fill 271 138 363 271 141 363 minecraft:moss_block
setblock 272 138 361 minecraft:mushroom_stem
fill 272 138 362 272 141 362 minecraft:moss_block
fill 273 138 361 273 141 361 minecraft:moss_block
setblock 274 138 324 minecraft:mushroom_stem
setblock 274 138 359 minecraft:mushroom_stem
fill 274 138 360 274 141 360 minecraft:moss_block
setblock 275 138 323 minecraft:mushroom_stem
fill 275 138 324 275 141 324 minecraft:moss_block
fill 275 138 339 275 141 339 minecraft:moss_block
setblock 275 138 342 minecraft:moss_block
setblock 275 138 343 minecraft:mushroom_stem
fill 275 138 344 275 140 345 minecraft:moss_block
setblock 275 138 346 minecraft:mushroom_stem
setblock 275 138 358 minecraft:mushroom_stem
fill 275 138 359 275 141 359 minecraft:moss_block
setblock 275 138 363 minecraft:mushroom_stem
fill 276 138 323 276 141 323 minecraft:moss_block
setblock 276 138 327 minecraft:mushroom_stem
setblock 276 138 337 minecraft:mushroom_stem
fill 276 138 338 276 141 338 minecraft:moss_block
setblock 276 138 342 minecraft:mushroom_stem
fill 276 138 343 276 141 343 minecraft:moss_block
setblock 276 138 347 minecraft:mushroom_stem
fill 276 138 348 276 141 348 minecraft:moss_block
setblock 276 138 352 minecraft:mushroom_stem
fill 276 138 353 276 141 353 minecraft:moss_block
setblock 276 138 357 minecraft:mushroom_stem
fill 276 138 358 276 141 358 minecraft:moss_block
setblock 276 138 362 minecraft:mushroom_stem
fill 276 138 363 276 141 363 minecraft:moss_block
fill 235 139 334 235 145 335 minecraft:brown_terracotta
setblock 235 139 336 minecraft:red_mushroom_block
fill 235 139 337 235 147 337 minecraft:brown_terracotta
setblock 236 139 336 minecraft:mushroom_stem
fill 236 139 337 236 139 340 minecraft:moss_block
setblock 236 139 341 minecraft:mushroom_stem
fill 236 139 342 236 142 342 minecraft:moss_block
setblock 236 139 346 minecraft:mushroom_stem
fill 236 139 347 236 142 347 minecraft:moss_block
setblock 236 139 351 minecraft:mushroom_stem
fill 236 139 352 236 142 352 minecraft:moss_block
setblock 236 139 356 minecraft:mushroom_stem
fill 236 139 357 236 142 357 minecraft:moss_block
setblock 236 139 361 minecraft:mushroom_stem
fill 236 139 362 236 142 362 minecraft:moss_block
setblock 237 139 340 minecraft:mushroom_stem
fill 237 139 341 238 141 341 minecraft:moss_block
setblock 237 139 345 minecraft:mushroom_stem
fill 237 139 346 237 142 346 minecraft:moss_block
setblock 237 139 350 minecraft:mushroom_stem
fill 237 139 351 237 142 351 minecraft:moss_block
setblock 237 139 356 minecraft:moss_block
setblock 237 139 360 minecraft:mushroom_stem
fill 237 139 361 237 142 361 minecraft:moss_block
setblock 238 139 344 minecraft:mushroom_stem
fill 238 139 345 238 142 345 minecraft:moss_block
setblock 239 139 363 minecraft:mushroom_stem
fill 240 139 363 240 142 363 minecraft:moss_block
setblock 248 139 323 minecraft:moss_block
setblock 248 139 363 minecraft:moss_block
setblock 249 139 323 minecraft:mushroom_stem
setblock 249 139 363 minecraft:mushroom_stem
fill 250 139 323 250 141 324 minecraft:moss_block
fill 250 139 363 250 142 363 minecraft:moss_block
setblock 250 139 364 minecraft:shroomlight
fill 251 139 324 252 139 324 minecraft:moss_block
fill 251 139 362 251 142 362 minecraft:moss_block
fill 251 139 364 252 147 364 minecraft:brown_terracotta
setblock 253 139 324 minecraft:mushroom_stem
setblock 254 139 323 minecraft:mushroom_stem
fill 254 139 324 254 141 325 minecraft:moss_block
setblock 254 139 363 minecraft:mushroom_stem
fill 255 139 323 255 142 323 minecraft:moss_block
fill 255 139 325 256 139 325 minecraft:moss_block
setblock 255 139 362 minecraft:mushroom_stem
fill 255 139 363 255 142 363 minecraft:moss_block
fill 256 139 362 256 142 362 minecraft:moss_block
setblock 258 139 324 minecraft:mushroom_stem
setblock 259 139 323 minecraft:mushroom_stem
fill 259 139 324 259 142 324 minecraft:moss_block
setblock 259 139 363 minecraft:mushroom_stem
fill 260 139 323 260 142 323 minecraft:moss_block
fill 260 139 363 263 139 363 minecraft:moss_block
fill 261 139 324 262 139 324 minecraft:moss_block
setblock 264 139 323 minecraft:mushroom_stem
setblock 264 139 363 minecraft:mushroom_stem
fill 265 139 323 265 142 323 minecraft:moss_block
fill 265 139 363 265 142 363 minecraft:moss_block
fill 266 139 324 267 139 324 minecraft:moss_block
fill 266 139 362 266 142 362 minecraft:moss_block
setblock 268 139 324 minecraft:mushroom_stem
setblock 269 139 323 minecraft:mushroom_stem
fill 269 139 324 269 142 324 minecraft:moss_block
setblock 269 139 363 minecraft:mushroom_stem
fill 270 139 323 270 142 323 minecraft:moss_block
setblock 270 139 362 minecraft:mushroom_stem
fill 270 139 363 270 142 363 minecraft:moss_block
setblock 271 139 361 minecraft:mushroom_stem
fill 271 139 362 271 142 362 minecraft:moss_block
fill 272 139 361 272 142 361 minecraft:moss_block
setblock 273 139 324 minecraft:mushroom_stem
fill 273 139 360 273 142 360 minecraft:moss_block
setblock 274 139 323 minecraft:mushroom_stem
fill 274 139 324 274 142 324 minecraft:moss_block
setblock 274 139 358 minecraft:mushroom_stem
fill 274 139 359 274 142 359 minecraft:moss_block
setblock 274 139 363 minecraft:mushroom_stem
fill 275 139 323 275 142 323 minecraft:moss_block
setblock 275 139 326 minecraft:moss_block
setblock 275 139 342 minecraft:mushroom_stem
fill 275 139 343 275 142 343 minecraft:moss_block
setblock 275 139 346 minecraft:moss_block
fill 275 139 348 275 142 348 minecraft:moss_block
fill 275 139 354 275 141 354 minecraft:moss_block
setblock 275 139 357 minecraft:mushroom_stem
fill 275 139 358 275 142 358 minecraft:moss_block
setblock 275 139 362 minecraft:mushroom_stem
fill 275 139 363 275 142 363 minecraft:moss_block
setblock 276 139 326 minecraft:mushroom_stem
fill 276 139 327 276 141 328 minecraft:moss_block
setblock 276 139 336 minecraft:mushroom_stem
fill 276 139 337 276 141 337 minecraft:moss_block
setblock 276 139 341 minecraft:mushroom_stem
fill 276 139 342 276 142 342 minecraft:moss_block
setblock 276 139 346 minecraft:mushroom_stem
fill 276 139 347 276 142 347 minecraft:moss_block
setblock 276 139 351 minecraft:mushroom_stem
fill 276 139 352 276 142 352 minecraft:moss_block
setblock 276 139 356 minecraft:mushroom_stem
fill 276 139 357 276 142 357 minecraft:moss_block
setblock 276 139 361 minecraft:mushroom_stem
fill 276 139 362 276 142 362 minecraft:moss_block
fill 235 140 336 235 143 336 minecraft:brown_terracotta
setblock 236 140 325 minecraft:mushroom_stem
fill 236 140 326 236 143 326 minecraft:moss_block
setblock 236 140 329 minecraft:red_mushroom_block
setblock 236 140 335 minecraft:mushroom_stem
fill 236 140 336 236 140 339 minecraft:moss_block
setblock 236 140 340 minecraft:mushroom_stem
fill 236 140 341 236 143 341 minecraft:moss_block
setblock 236 140 345 minecraft:mushroom_stem
fill 236 140 346 236 143 346 minecraft:moss_block
setblock 236 140 350 minecraft:mushroom_stem
fill 236 140 351 236 143 351 minecraft:moss_block
setblock 236 140 355 minecraft:mushroom_stem
fill 236 140 356 236 143 356 minecraft:moss_block
setblock 236 140 360 minecraft:mushroom_stem
fill 236 140 361 236 143 361 minecraft:moss_block
setblock 237 140 323 minecraft:moss_block
setblock 237 140 339 minecraft:mushroom_stem
fill 237 140 340 237 143 340 minecraft:moss_block
setblock 237 140 344 minecraft:mushroom_stem
fill 237 140 345 237 143 345 minecraft:moss_block
setblock 237 140 349 minecraft:mushroom_stem
fill 237 140 350 237 143 350 minecraft:moss_block
fill 237 140 352 237 141 352 minecraft:moss_block
setblock 237 140 359 minecraft:mushroom_stem
fill 237 140 360 237 142 360 minecraft:moss_block
setblock 238 140 323 minecraft:mushroom_stem
setblock 238 140 343 minecraft:mushroom_stem
fill 238 140 344 238 143 344 minecraft:moss_block
fill 238 140 346 238 141 346 minecraft:moss_block
setblock 238 140 363 minecraft:mushroom_stem
fill 239 140 323 239 143 323 minecraft:moss_block
fill 239 140 363 239 143 363 minecraft:moss_block
fill 244 140 324 244 143 324 minecraft:red_mushroom_block
fill 244 140 356 245 143 360 minecraft:red_mushroom_block
fill 246 140 323 247 140 323 minecraft:moss_block
fill 246 140 356 248 143 357 minecraft:red_mushroom_block
setblock 246 140 358 minecraft:mushroom_stem
fill 246 140 359 248 143 360 minecraft:red_mushroom_block
setblock 246 140 363 minecraft:red_mushroom_block
fill 247 140 358 248 143 358 minecraft:red_mushroom_block
setblock 247 140 363 minecraft:moss_block
setblock 248 140 323 minecraft:mushroom_stem
setblock 248 140 363 minecraft:mushroom_stem
fill 249 140 323 249 142 324 minecraft:moss_block
fill 249 140 363 249 143 363 minecraft:moss_block
fill 250 140 362 250 143 362 minecraft:moss_block
fill 250 140 364 250 147 364 minecraft:brown_terracotta
setblock 251 140 324 minecraft:moss_block
setblock 252 140 324 minecraft:mushroom_stem
fill 252 140 325 253 142 325 minecraft:moss_block
setblock 253 140 323 minecraft:mushroom_stem
fill 253 140 324 253 143 324 minecraft:moss_block
setblock 253 140 363 minecraft:mushroom_stem
fill 254 140 323 254 143 323 minecraft:moss_block
setblock 254 140 362 minecraft:mushroom_stem
fill 254 140 363 254 143 363 minecraft:moss_block
setblock 255 140 325 minecraft:moss_block
fill 255 140 362 255 143 362 minecraft:moss_block
setblock 256 140 325 minecraft:mushroom_stem
setblock 257 140 324 minecraft:mushroom_stem
fill 257 140 325 258 142 325 minecraft:moss_block
setblock 258 140 323 minecraft:mushroom_stem
fill 258 140 324 258 143 324 minecraft:moss_block
setblock 258 140 363 minecraft:mushroom_stem
fill 259 140 323 259 143 323 minecraft:moss_block
fill 259 140 363 262 140 363 minecraft:moss_block
setblock 261 140 324 minecraft:moss_block
setblock 262 140 324 minecraft:mushroom_stem
setblock 263 140 323 minecraft:mushroom_stem
fill 263 140 324 266 140 324 minecraft:moss_block
setblock 263 140 363 minecraft:mushroom_stem
fill 264 140 323 264 143 323 minecraft:moss_block
fill 264 140 363 264 143 363 minecraft:moss_block
fill 265 140 362 265 143 362 minecraft:moss_block
setblock 267 140 324 minecraft:mushroom_stem
setblock 268 140 323 minecraft:mushroom_stem
fill 268 140 324 268 143 324 minecraft:moss_block
setblock 268 140 363 minecraft:mushroom_stem
fill 269 140 323 269 143 323 minecraft:moss_block
setblock 269 140 361 minecraft:moss_block
setblock 269 140 362 minecraft:mushroom_stem
fill 269 140 363 269 143 363 minecraft:moss_block
setblock 270 140 325 minecraft:moss_block
setblock 270 140 361 minecraft:mushroom_stem
fill 270 140 362 270 143 362 minecraft:moss_block
setblock 271 140 325 minecraft:mushroom_stem
fill 271 140 361 271 143 361 minecraft:moss_block
setblock 272 140 324 minecraft:mushroom_stem
fill 272 140 325 274 141 325 minecraft:moss_block
setblock 273 140 323 minecraft:mushroom_stem
fill 273 140 324 273 143 324 minecraft:moss_block
setblock 273 140 363 minecraft:mushroom_stem
fill 274 140 323 274 143 323 minecraft:moss_block
setblock 274 140 357 minecraft:mushroom_stem
fill 274 140 358 274 143 358 minecraft:moss_block
setblock 274 140 362 minecraft:mushroom_stem
fill 274 140 363 274 143 363 minecraft:moss_block
setblock 275 140 326 minecraft:mushroom_stem
fill 275 140 327 275 143 327 minecraft:moss_block
setblock 275 140 341 minecraft:mushroom_stem
fill 275 140 342 275 143 342 minecraft:moss_block
setblock 275 140 346 minecraft:mushroom_stem
fill 275 140 347 275 143 347 minecraft:moss_block
fill 275 140 349 275 140 350 minecraft:moss_block
setblock 275 140 351 minecraft:mushroom_stem
fill 275 140 352 275 142 353 minecraft:moss_block
setblock 275 140 356 minecraft:mushroom_stem
fill 275 140 357 275 143 357 minecraft:moss_block
setblock 275 140 361 minecraft:mushroom_stem
fill 275 140 362 275 143 362 minecraft:moss_block
setblock 276 140 325 minecraft:mushroom_stem
fill 276 140 326 276 143 326 minecraft:moss_block
setblock 276 140 340 minecraft:mushroom_stem
fill 276 140 341 276 143 341 minecraft:moss_block
setblock 276 140 345 minecraft:mushroom_stem
fill 276 140 346 276 143 346 minecraft:moss_block
setblock 276 140 349 minecraft:moss_block
setblock 276 140 350 minecraft:mushroom_stem
fill 276 140 351 276 143 351 minecraft:moss_block
setblock 276 140 355 minecraft:mushroom_stem
fill 276 140 356 276 143 356 minecraft:moss_block
setblock 276 140 360 minecraft:mushroom_stem
fill 276 140 361 276 143 361 minecraft:moss_block
setblock 236 141 324 minecraft:mushroom_stem
fill 236 141 325 236 144 325 minecraft:moss_block
fill 236 141 327 236 142 327 minecraft:moss_block
setblock 236 141 335 minecraft:red_mushroom_block
fill 236 141 336 236 141 338 minecraft:moss_block
setblock 236 141 339 minecraft:mushroom_stem
fill 236 141 340 236 144 340 minecraft:moss_block
setblock 236 141 344 minecraft:mushroom_stem
fill 236 141 345 236 144 345 minecraft:moss_block
setblock 236 141 349 minecraft:mushroom_stem
fill 236 141 350 236 144 350 minecraft:moss_block
setblock 236 141 354 minecraft:mushroom_stem
fill 236 141 355 236 144 355 minecraft:moss_block
setblock 236 141 359 minecraft:mushroom_stem
fill 236 141 360 236 144 360 minecraft:moss_block
setblock 237 141 323 minecraft:mushroom_stem
setblock 237 141 338 minecraft:mushroom_stem
fill 237 141 339 237 143 339 minecraft:moss_block
setblock 237 141 342 minecraft:moss_block
setblock 237 141 343 minecraft:mushroom_stem
fill 237 141 344 237 144 344 minecraft:moss_block
setblock 237 141 348 minecraft:mushroom_stem
fill 237 141 349 237 144 349 minecraft:moss_block
setblock 237 141 358 minecraft:mushroom_stem
setblock 237 141 359 minecraft:moss_block
setblock 237 141 363 minecraft:mushroom_stem
fill 238 141 323 238 144 323 minecraft:moss_block
setblock 238 141 325 minecraft:light[level=15]
setblock 238 141 332 minecraft:light[level=12]
setblock 238 141 333 minecraft:light[level=15]
setblock 238 141 339 minecraft:light[level=12]
setblock 238 141 342 minecraft:mushroom_stem
fill 238 141 343 238 144 343 minecraft:moss_block
setblock 238 141 347 minecraft:mushroom_stem
setblock 238 141 349 minecraft:light[level=15]
setblock 238 141 353 minecraft:light[level=12]
setblock 238 141 357 minecraft:light[level=15]
setblock 238 141 360 minecraft:light[level=12]
setblock 238 141 362 minecraft:mushroom_stem
fill 238 141 363 238 144 363 minecraft:moss_block
setblock 241 141 323 minecraft:red_mushroom_block
fill 243 141 357 243 142 359 minecraft:red_mushroom_block
fill 245 141 323 246 141 323 minecraft:moss_block
setblock 245 141 325 minecraft:light[level=12]
setblock 245 141 332 minecraft:light[level=12]
setblock 245 141 339 minecraft:light[level=12]
setblock 245 141 346 minecraft:light[level=12]
setblock 245 141 353 minecraft:light[level=12]
fill 245 141 355 247 142 355 minecraft:red_mushroom_block
fill 245 141 361 247 142 361 minecraft:red_mushroom_block
setblock 246 141 325 minecraft:light[level=15]
setblock 246 141 333 minecraft:light[level=15]
setblock 246 141 341 minecraft:light[level=15]
setblock 246 141 349 minecraft:light[level=15]
fill 246 141 358 246 144 358 minecraft:red_mushroom_block
setblock 246 141 363 minecraft:moss_block
setblock 247 141 323 minecraft:mushroom_stem
fill 247 141 324 248 143 324 minecraft:moss_block
setblock 247 141 363 minecraft:mushroom_stem
fill 248 141 323 248 144 323 minecraft:moss_block
fill 248 141 363 248 144 363 minecraft:moss_block
fill 249 141 357 249 142 359 minecraft:red_mushroom_block
setblock 250 141 325 minecraft:mushroom_stem
setblock 251 141 324 minecraft:mushroom_stem
fill 251 141 325 251 144 325 minecraft:moss_block
setblock 252 141 323 minecraft:mushroom_stem
fill 252 141 324 252 144 324 minecraft:moss_block
setblock 252 141 332 minecraft:light[level=12]
setblock 252 141 339 minecraft:light[level=12]
setblock 252 141 346 minecraft:light[level=12]
setblock 252 141 353 minecraft:light[level=12]
setblock 252 141 360 minecraft:light[level=12]
setblock 252 141 363 minecraft:mushroom_stem
fill 253 141 323 253 144 323 minecraft:moss_block
setblock 253 141 362 minecraft:mushroom_stem
fill 253 141 363 253 144 363 minecraft:moss_block
setblock 254 141 333 minecraft:light[level=15]
setblock 254 141 341 minecraft:light[level=15]
setblock 254 141 349 minecraft:light[level=15]
setblock 254 141 357 minecraft:light[level=15]
fill 254 141 362 254 144 362 minecraft:moss_block
setblock 255 141 325 minecraft:mushroom_stem
setblock 256 141 324 minecraft:mushroom_stem
fill 256 141 325 256 144 325 minecraft:moss_block
setblock 257 141 323 minecraft:mushroom_stem
fill 257 141 324 257 144 324 minecraft:moss_block
setblock 257 141 363 minecraft:mushroom_stem
fill 258 141 323 258 144 323 minecraft:moss_block
setblock 258 141 362 minecraft:mushroom_stem
fill 258 141 363 261 141 363 minecraft:moss_block
setblock 259 141 325 minecraft:moss_block
setblock 259 141 332 minecraft:light[level=12]
setblock 259 141 339 minecraft:light[level=12]
setblock 259 141 346 minecraft:light[level=12]
setblock 259 141 353 minecraft:light[level=12]
setblock 259 141 360 minecraft:light[level=12]
setblock 261 141 324 minecraft:mushroom_stem
setblock 262 141 323 minecraft:mushroom_stem
fill 262 141 324 265 141 324 minecraft:moss_block
setblock 262 141 325 minecraft:light[level=15]
setblock 262 141 333 minecraft:light[level=15]
setblock 262 141 341 minecraft:light[level=15]
setblock 262 141 349 minecraft:light[level=15]
setblock 262 141 357 minecraft:light[level=15]
setblock 262 141 363 minecraft:mushroom_stem
fill 263 141 323 263 144 323 minecraft:moss_block
fill 263 141 363 263 144 363 minecraft:moss_block
setblock 266 141 324 minecraft:mushroom_stem
setblock 266 141 325 minecraft:light[level=12]
setblock 266 141 332 minecraft:light[level=12]
setblock 266 141 339 minecraft:light[level=12]
setblock 266 141 346 minecraft:light[level=12]
setblock 266 141 353 minecraft:light[level=12]
setblock 266 141 360 minecraft:light[level=12]
setblock 267 141 323 minecraft:mushroom_stem
fill 267 141 324 267 143 325 minecraft:moss_block
setblock 267 141 363 minecraft:mushroom_stem
fill 268 141 323 268 144 323 minecraft:moss_block
fill 268 141 325 269 141 325 minecraft:moss_block
setblock 268 141 361 minecraft:moss_block
setblock 268 141 362 minecraft:mushroom_stem
fill 268 141 363 268 144 363 minecraft:moss_block
setblock 269 141 361 minecraft:mushroom_stem
fill 269 141 362 269 144 362 minecraft:moss_block
setblock 270 141 325 minecraft:mushroom_stem
setblock 270 141 333 minecraft:light[level=15]
setblock 270 141 341 minecraft:light[level=15]
setblock 270 141 349 minecraft:light[level=15]
setblock 270 141 357 minecraft:light[level=15]
fill 270 141 361 270 144 361 minecraft:moss_block
setblock 271 141 324 minecraft:mushroom_stem
fill 271 141 325 271 144 325 minecraft:moss_block
setblock 272 141 323 minecraft:mushroom_stem
fill 272 141 324 272 144 324 minecraft:moss_block
fill 272 141 360 272 142 360 minecraft:moss_block
setblock 272 141 363 minecraft:mushroom_stem
fill 273 141 323 273 144 323 minecraft:moss_block
setblock 273 141 332 minecraft:light[level=12]
setblock 273 141 339 minecraft:light[level=12]
setblock 273 141 353 minecraft:light[level=12]
setblock 273 141 362 minecraft:mushroom_stem
fill 273 141 363 273 144 363 minecraft:moss_block
setblock 274 141 326 minecraft:mushroom_stem
fill 274 141 342 274 141 345 minecraft:moss_block
fill 274 141 347 274 144 347 minecraft:moss_block
fill 274 141 357 274 143 357 minecraft:moss_block
setblock 274 141 361 minecraft:mushroom_stem
fill 274 141 362 274 144 362 minecraft:moss_block
setblock 275 141 325 minecraft:mushroom_stem
fill 275 141 326 275 144 326 minecraft:moss_block
setblock 275 141 340 minecraft:mushroom_stem
fill 275 141 341 275 144 341 minecraft:moss_block
setblock 275 141 344 minecraft:moss_block
setblock 275 141 345 minecraft:mushroom_stem
fill 275 141 346 275 144 346 minecraft:moss_block
setblock 275 141 349 minecraft:moss_block
setblock 275 141 350 minecraft:mushroom_stem
fill 275 141 351 275 144 351 minecraft:moss_block
setblock 275 141 355 minecraft:mushroom_stem
fill 275 141 356 275 144 356 minecraft:moss_block
setblock 275 141 360 minecraft:mushroom_stem
fill 275 141 361 275 144 361 minecraft:moss_block
setblock 276 141 324 minecraft:mushroom_stem
fill 276 141 325 276 144 325 minecraft:moss_block
setblock 276 141 329 minecraft:mushroom_stem
setblock 276 141 332 minecraft:red_mushroom_block
setblock 276 141 339 minecraft:mushroom_stem
fill 276 141 340 276 144 340 minecraft:moss_block
setblock 276 141 344 minecraft:mushroom_stem
fill 276 141 345 276 144 345 minecraft:moss_block
setblock 276 141 349 minecraft:mushroom_stem
fill 276 141 350 276 144 350 minecraft:moss_block
setblock 276 141 354 minecraft:mushroom_stem
fill 276 141 355 276 144 355 minecraft:moss_block
setblock 276 141 359 minecraft:mushroom_stem
fill 276 141 360 276 144 360 minecraft:moss_block
setblock 236 142 323 minecraft:mushroom_stem
fill 236 142 324 236 145 324 minecraft:moss_block
setblock 236 142 328 minecraft:mushroom_stem
fill 236 142 336 236 142 337 minecraft:moss_block
setblock 236 142 338 minecraft:mushroom_stem
fill 236 142 339 236 145 339 minecraft:moss_block
setblock 236 142 343 minecraft:mushroom_stem
fill 236 142 344 236 145 344 minecraft:moss_block
setblock 236 142 348 minecraft:mushroom_stem
fill 236 142 349 236 145 349 minecraft:moss_block
setblock 236 142 353 minecraft:mushroom_stem
fill 236 142 354 236 145 354 minecraft:moss_block
setblock 236 142 358 minecraft:mushroom_stem
fill 236 142 359 236 145 359 minecraft:moss_block
setblock 236 142 363 minecraft:mushroom_stem
setblock 236 142 364 minecraft:shroomlight
fill 237 142 323 237 145 323 minecraft:moss_block
setblock 237 142 341 minecraft:moss_block
setblock 237 142 342 minecraft:mushroom_stem
fill 237 142 343 237 145 343 minecraft:moss_block
setblock 237 142 347 minecraft:mushroom_stem
fill 237 142 348 238 144 348 minecraft:moss_block
setblock 237 142 352 minecraft:mushroom_stem
setblock 237 142 362 minecraft:mushroom_stem
fill 237 142 363 237 145 363 minecraft:moss_block
setblock 238 142 341 minecraft:mushroom_stem
fill 238 142 342 238 143 342 minecraft:moss_block
setblock 238 142 346 minecraft:mushroom_stem
fill 238 142 347 238 145 347 minecraft:moss_block
setblock 239 142 351 minecraft:shroomlight
setblock 240 142 323 minecraft:moss_block
setblock 241 142 363 minecraft:mushroom_stem
fill 242 142 323 245 142 323 minecraft:moss_block
fill 245 142 349 245 148 349 minecraft:mushroom_stem
setblock 245 142 363 minecraft:moss_block
setblock 246 142 323 minecraft:mushroom_stem
fill 246 142 324 246 145 324 minecraft:moss_block
setblock 246 142 363 minecraft:mushroom_stem
fill 247 142 323 247 145 323 minecraft:moss_block
fill 247 142 363 247 145 363 minecraft:moss_block
setblock 248 142 325 minecraft:moss_block
setblock 249 142 325 minecraft:mushroom_stem
fill 249 142 362 249 144 362 minecraft:moss_block
setblock 250 142 323 minecraft:moss_block
setblock 250 142 324 minecraft:mushroom_stem
fill 250 142 325 250 145 325 minecraft:moss_block
setblock 251 142 323 minecraft:mushroom_stem
fill 251 142 324 251 145 324 minecraft:moss_block
fill 251 142 326 252 142 326 minecraft:moss_block
setblock 251 142 363 minecraft:mushroom_stem
fill 252 142 323 252 145 323 minecraft:moss_block
setblock 252 142 362 minecraft:mushroom_stem
fill 252 142 363 252 145 363 minecraft:moss_block
setblock 253 142 326 minecraft:mushroom_stem
fill 253 142 362 253 144 362 minecraft:moss_block
setblock 254 142 324 minecraft:moss_block
setblock 254 142 325 minecraft:mushroom_stem
fill 254 142 326 255 144 326 minecraft:moss_block
setblock 255 142 324 minecraft:mushroom_stem
fill 255 142 325 255 145 325 minecraft:moss_block
setblock 256 142 323 minecraft:mushroom_stem
fill 256 142 324 256 145 324 minecraft:moss_block
setblock 256 142 363 minecraft:mushroom_stem
fill 257 142 323 257 145 323 minecraft:moss_block
setblock 257 142 362 minecraft:mushroom_stem
fill 257 142 363 260 142 363 minecraft:moss_block
setblock 259 142 325 minecraft:mushroom_stem
setblock 260 142 324 minecraft:mushroom_stem
fill 260 142 325 260 145 325 minecraft:moss_block
setblock 261 142 323 minecraft:mushroom_stem
fill 261 142 324 264 142 324 minecraft:moss_block
setblock 261 142 363 minecraft:mushroom_stem
fill 262 142 323 262 145 323 minecraft:moss_block
fill 262 142 363 262 145 363 minecraft:moss_block
fill 264 142 362 264 144 362 minecraft:moss_block
setblock 265 142 324 minecraft:mushroom_stem
fill 265 142 325 266 144 325 minecraft:moss_block
setblock 266 142 323 minecraft:mushroom_stem
fill 266 142 324 266 145 324 minecraft:moss_block
setblock 266 142 363 minecraft:mushroom_stem
fill 267 142 323 267 145 323 minecraft:moss_block
setblock 267 142 362 minecraft:mushroom_stem
fill 267 142 363 267 145 363 minecraft:moss_block
setblock 268 142 325 minecraft:moss_block
setblock 268 142 361 minecraft:mushroom_stem
fill 268 142 362 268 145 362 minecraft:moss_block
setblock 269 142 325 minecraft:mushroom_stem
fill 269 142 361 269 145 361 minecraft:moss_block
setblock 270 142 324 minecraft:mushroom_stem
fill 270 142 325 270 145 325 minecraft:moss_block
setblock 271 142 323 minecraft:mushroom_stem
fill 271 142 324 271 145 324 minecraft:moss_block
setblock 271 142 363 minecraft:mushroom_stem
fill 272 142 323 272 145 323 minecraft:moss_block
fill 272 142 325 273 142 325 minecraft:moss_block
setblock 272 142 362 minecraft:mushroom_stem
fill 272 142 363 272 145 363 minecraft:moss_block
setblock 273 142 361 minecraft:mushroom_stem
fill 273 142 362 273 145 362 minecraft:moss_block
setblock 274 142 325 minecraft:mushroom_stem
fill 274 142 326 274 145 326 minecraft:moss_block
fill 274 142 342 274 142 344 minecraft:moss_block
setblock 274 142 345 minecraft:mushroom_stem
fill 274 142 346 274 145 346 minecraft:moss_block
fill 274 142 348 274 142 349 minecraft:moss_block
setblock 274 142 350 minecraft:mushroom_stem
setblock 274 142 360 minecraft:mushroom_stem
fill 274 142 361 274 145 361 minecraft:moss_block
setblock 275 142 324 minecraft:mushroom_stem
fill 275 142 325 275 145 325 minecraft:moss_block
setblock 275 142 328 minecraft:moss_block
fill 275 142 340 275 143 340 minecraft:moss_block
setblock 275 142 344 minecraft:mushroom_stem
fill 275 142 345 275 145 345 minecraft:moss_block
setblock 275 142 349 minecraft:mushroom_stem
fill 275 142 350 275 145 350 minecraft:moss_block
setblock 275 142 354 minecraft:mushroom_stem
fill 275 142 355 275 145 355 minecraft:moss_block
setblock 275 142 359 minecraft:mushroom_stem
fill 275 142 360 275 145 360 minecraft:moss_block
setblock 276 142 323 minecraft:mushroom_stem
fill 276 142 324 276 145 324 minecraft:moss_block
setblock 276 142 327 minecraft:moss_block
setblock 276 142 328 minecraft:mushroom_stem
fill 276 142 329 276 145 329 minecraft:moss_block
setblock 276 142 338 minecraft:mushroom_stem
fill 276 142 339 276 144 339 minecraft:moss_block
setblock 276 142 343 minecraft:mushroom_stem
fill 276 142 344 276 145 344 minecraft:moss_block
setblock 276 142 348 minecraft:mushroom_stem
fill 276 142 349 276 145 349 minecraft:moss_block
setblock 276 142 353 minecraft:mushroom_stem
fill 276 142 354 276 145 354 minecraft:moss_block
setblock 276 142 358 minecraft:mushroom_stem
fill 276 142 359 276 145 359 minecraft:moss_block
setblock 276 142 363 minecraft:mushroom_stem
setblock 236 143 322 minecraft:red_mushroom_block
fill 236 143 323 236 146 323 minecraft:moss_block
setblock 236 143 327 minecraft:mushroom_stem
fill 236 143 328 236 145 329 minecraft:moss_block
setblock 236 143 336 minecraft:moss_block
setblock 236 143 337 minecraft:mushroom_stem
fill 236 143 338 236 145 338 minecraft:moss_block
setblock 236 143 342 minecraft:mushroom_stem
fill 236 143 343 236 146 343 minecraft:moss_block
setblock 236 143 347 minecraft:mushroom_stem
fill 236 143 348 236 146 348 minecraft:moss_block
setblock 236 143 352 minecraft:mushroom_stem
fill 236 143 353 236 146 353 minecraft:moss_block
setblock 236 143 357 minecraft:mushroom_stem
fill 236 143 358 236 145 358 minecraft:moss_block
setblock 236 143 362 minecraft:mushroom_stem
fill 236 143 363 236 145 363 minecraft:moss_block
fill 236 143 364 236 149 364 minecraft:brown_terracotta
fill 237 143 322 237 145 322 minecraft:brown_terracotta
setblock 237 143 341 minecraft:mushroom_stem
fill 237 143 342 237 146 342 minecraft:moss_block
setblock 237 143 346 minecraft:mushroom_stem
fill 237 143 347 237 146 347 minecraft:moss_block
setblock 237 143 351 minecraft:mushroom_stem
fill 237 143 352 237 146 352 minecraft:moss_block
setblock 237 143 362 minecraft:moss_block
setblock 238 143 345 minecraft:mushroom_stem
fill 238 143 346 238 146 346 minecraft:moss_block
setblock 238 143 349 minecraft:moss_block
fill 239 143 351 239 147 351 minecraft:mushroom_stem
setblock 240 143 323 minecraft:mushroom_stem
setblock 240 143 363 minecraft:mushroom_stem
fill 241 143 323 244 143 323 minecraft:moss_block
setblock 245 143 323 minecraft:mushroom_stem
fill 245 143 324 245 146 324 minecraft:moss_block
setblock 245 143 363 minecraft:mushroom_stem
fill 246 143 322 246 147 322 minecraft:brown_terracotta
fill 246 143 323 246 146 323 minecraft:moss_block
fill 246 143 363 246 146 363 minecraft:moss_block
setblock 247 143 322 minecraft:shroomlight
setblock 247 143 325 minecraft:moss_block
setblock 248 143 325 minecraft:mushroom_stem
setblock 249 143 323 minecraft:moss_block
setblock 249 143 324 minecraft:mushroom_stem
fill 249 143 325 249 146 325 minecraft:moss_block
setblock 250 143 323 minecraft:mushroom_stem
fill 250 143 324 250 146 324 minecraft:moss_block
fill 250 143 326 251 143 326 minecraft:moss_block
setblock 250 143 363 minecraft:mushroom_stem
fill 251 143 323 251 146 323 minecraft:moss_block
setblock 251 143 362 minecraft:mushroom_stem
fill 251 143 363 251 146 363 minecraft:moss_block
setblock 252 143 325 minecraft:moss_block
setblock 252 143 326 minecraft:mushroom_stem
fill 252 143 362 252 145 362 minecraft:moss_block
setblock 253 143 325 minecraft:mushroom_stem
fill 253 143 326 253 146 326 minecraft:moss_block
setblock 254 143 324 minecraft:mushroom_stem
fill 254 143 325 254 146 325 minecraft:moss_block
setblock 255 143 323 minecraft:mushroom_stem
fill 255 143 324 255 146 324 minecraft:moss_block
setblock 255 143 363 minecraft:mushroom_stem
fill 256 143 323 256 146 323 minecraft:moss_block
setblock 256 143 326 minecraft:moss_block
setblock 256 143 362 minecraft:mushroom_stem
fill 256 143 363 259 143 363 minecraft:moss_block
setblock 257 143 325 minecraft:moss_block
setblock 258 143 325 minecraft:mushroom_stem
setblock 259 143 324 minecraft:mushroom_stem
fill 259 143 325 259 146 325 minecraft:moss_block
setblock 260 143 323 minecraft:mushroom_stem
fill 260 143 324 263 143 324 minecraft:moss_block
setblock 260 143 363 minecraft:mushroom_stem
fill 261 143 323 261 146 323 minecraft:moss_block
fill 261 143 325 262 143 325 minecraft:moss_block
fill 261 143 363 261 146 363 minecraft:moss_block
setblock 263 143 325 minecraft:mushroom_stem
setblock 264 143 324 minecraft:mushroom_stem
fill 264 143 325 264 146 325 minecraft:moss_block
setblock 265 143 323 minecraft:mushroom_stem
fill 265 143 324 265 146 324 minecraft:moss_block
setblock 265 143 363 minecraft:mushroom_stem
fill 266 143 323 266 146 323 minecraft:moss_block
setblock 266 143 362 minecraft:mushroom_stem
fill 266 143 363 266 146 363 minecraft:moss_block
setblock 267 143 361 minecraft:mushroom_stem
fill 267 143 362 267 146 362 minecraft:moss_block
setblock 268 143 325 minecraft:mushroom_stem
fill 268 143 361 268 146 361 minecraft:moss_block
setblock 269 143 324 minecraft:mushroom_stem
fill 269 143 325 269 146 325 minecraft:moss_block
setblock 270 143 323 minecraft:mushroom_stem
fill 270 143 324 270 146 324 minecraft:moss_block
fill 270 143 326 270 144 326 minecraft:moss_block
setblock 270 143 363 minecraft:mushroom_stem
fill 271 143 323 271 146 323 minecraft:moss_block
setblock 271 143 362 minecraft:mushroom_stem
fill 271 143 363 271 146 363 minecraft:moss_block
setblock 272 143 325 minecraft:moss_block
setblock 272 143 361 minecraft:mushroom_stem
fill 272 143 362 272 146 362 minecraft:moss_block
setblock 273 143 325 minecraft:mushroom_stem
fill 273 143 361 273 145 361 minecraft:moss_block
setblock 274 143 324 minecraft:mushroom_stem
fill 274 143 325 274 145 325 minecraft:moss_block
fill 274 143 342 274 143 343 minecraft:moss_block
setblock 274 143 344 minecraft:mushroom_stem
fill 274 143 345 274 146 345 minecraft:moss_block
setblock 274 143 348 minecraft:moss_block
setblock 274 143 349 minecraft:mushroom_stem
fill 274 143 350 274 144 352 minecraft:moss_block
setblock 274 143 359 minecraft:mushroom_stem
fill 274 143 360 274 144 360 minecraft:moss_block
setblock 275 143 323 minecraft:mushroom_stem
fill 275 143 324 275 146 324 minecraft:moss_block
setblock 275 143 328 minecraft:mushroom_stem
setblock 275 143 343 minecraft:mushroom_stem
fill 275 143 344 275 146 344 minecraft:moss_block
setblock 275 143 348 minecraft:mushroom_stem
fill 275 143 349 275 146 349 minecraft:moss_block
setblock 275 143 352 minecraft:moss_block
setblock 275 143 353 minecraft:mushroom_stem
fill 275 143 354 275 146 354 minecraft:moss_block
setblock 275 143 358 minecraft:mushroom_stem
fill 275 143 359 275 145 359 minecraft:moss_block
setblock 275 143 363 minecraft:mushroom_stem
fill 276 143 323 276 146 323 minecraft:moss_block
setblock 276 143 327 minecraft:mushroom_stem
fill 276 143 328 276 146 328 minecraft:moss_block
setblock 276 143 338 minecraft:moss_block
setblock 276 143 342 minecraft:mushroom_stem
fill 276 143 343 276 146 343 minecraft:moss_block
setblock 276 143 347 minecraft:mushroom_stem
fill 276 143 348 276 146 348 minecraft:moss_block
setblock 276 143 352 minecraft:mushroom_stem
fill 276 143 353 276 146 353 minecraft:moss_block
setblock 276 143 357 minecraft:mushroom_stem
fill 276 143 358 276 146 358 minecraft:moss_block
setblock 276 143 362 minecraft:mushroom_stem
fill 276 143 363 276 146 363 minecraft:moss_block
setblock 277 143 358 minecraft:red_mushroom_block
setblock 235 144 336 minecraft:green_terracotta
setblock 235 144 349 minecraft:green_terracotta
fill 235 144 357 235 146 357 minecraft:green_terracotta
fill 235 144 358 235 148 358 minecraft:brown_terracotta
fill 236 144 322 236 147 322 minecraft:brown_terracotta
setblock 236 144 326 minecraft:mushroom_stem
fill 236 144 327 236 147 327 minecraft:moss_block
setblock 236 144 337 minecraft:moss_block
setblock 236 144 341 minecraft:mushroom_stem
fill 236 144 342 236 147 342 minecraft:moss_block
setblock 236 144 346 minecraft:mushroom_stem
fill 236 144 347 236 147 347 minecraft:moss_block
setblock 236 144 351 minecraft:mushroom_stem
fill 236 144 352 236 147 352 minecraft:moss_block
setblock 236 144 356 minecraft:mushroom_stem
fill 236 144 357 236 145 357 minecraft:moss_block
setblock 236 144 361 minecraft:mushroom_stem
fill 236 144 362 236 145 362 minecraft:moss_block
setblock 237 144 340 minecraft:mushroom_stem
fill 237 144 341 237 145 341 minecraft:moss_block
setblock 237 144 345 minecraft:mushroom_stem
fill 237 144 346 237 147 346 minecraft:moss_block
setblock 237 144 350 minecraft:mushroom_stem
fill 237 144 351 237 147 351 minecraft:moss_block
setblock 238 144 344 minecraft:mushroom_stem
fill 238 144 345 238 145 345 minecraft:moss_block
setblock 238 144 349 minecraft:mushroom_stem
setblock 239 144 323 minecraft:mushroom_stem
fill 240 144 323 243 144 323 minecraft:moss_block
setblock 241 144 364 minecraft:green_terracotta
setblock 242 144 322 minecraft:red_mushroom_block
fill 242 144 364 242 147 364 minecraft:brown_terracotta
fill 243 144 322 244 147 322 minecraft:brown_terracotta
setblock 244 144 323 minecraft:mushroom_stem
fill 244 144 324 244 147 324 minecraft:moss_block
fill 245 144 323 245 147 323 minecraft:moss_block
fill 245 144 363 245 145 363 minecraft:moss_block
setblock 247 144 322 minecraft:green_terracotta
setblock 247 144 324 minecraft:moss_block
setblock 247 144 325 minecraft:mushroom_stem
setblock 248 144 324 minecraft:mushroom_stem
fill 248 144 325 248 147 325 minecraft:moss_block
setblock 249 144 323 minecraft:mushroom_stem
fill 249 144 324 249 147 324 minecraft:moss_block
fill 249 144 326 250 144 326 minecraft:moss_block
setblock 249 144 363 minecraft:mushroom_stem
fill 250 144 323 250 147 323 minecraft:moss_block
setblock 250 144 362 minecraft:mushroom_stem
fill 250 144 363 250 147 363 minecraft:moss_block
setblock 251 144 326 minecraft:mushroom_stem
fill 251 144 362 251 145 362 minecraft:moss_block
setblock 252 144 325 minecraft:mushroom_stem
fill 252 144 326 252 147 326 minecraft:moss_block
setblock 253 144 324 minecraft:mushroom_stem
fill 253 144 325 253 147 325 minecraft:moss_block
setblock 254 144 323 minecraft:mushroom_stem
fill 254 144 324 254 147 324 minecraft:moss_block
setblock 254 144 363 minecraft:mushroom_stem
fill 255 144 323 255 147 323 minecraft:moss_block
setblock 255 144 362 minecraft:mushroom_stem
fill 255 144 363 258 144 363 minecraft:moss_block
setblock 255 144 364 minecraft:green_terracotta
setblock 256 144 326 minecraft:mushroom_stem
setblock 257 144 325 minecraft:mushroom_stem
setblock 258 144 322 minecraft:green_terracotta
setblock 258 144 324 minecraft:mushroom_stem
fill 258 144 325 258 146 325 minecraft:moss_block
setblock 259 144 323 minecraft:mushroom_stem
fill 259 144 324 262 144 324 minecraft:moss_block
setblock 259 144 363 minecraft:mushroom_stem
fill 260 144 323 260 147 323 minecraft:moss_block
fill 260 144 363 260 146 363 minecraft:moss_block
setblock 261 144 325 minecraft:moss_block
setblock 262 144 325 minecraft:mushroom_stem
setblock 263 144 324 minecraft:mushroom_stem
fill 263 144 325 263 147 325 minecraft:moss_block
setblock 264 144 322 minecraft:green_terracotta
setblock 264 144 323 minecraft:mushroom_stem
fill 264 144 324 264 147 324 minecraft:moss_block
setblock 264 144 363 minecraft:mushroom_stem
fill 265 144 322 265 148 322 minecraft:brown_terracotta
fill 265 144 323 265 147 323 minecraft:moss_block
setblock 265 144 362 minecraft:mushroom_stem
fill 265 144 363 265 147 363 minecraft:moss_block
setblock 266 144 322 minecraft:green_terracotta
fill 266 144 362 266 147 362 minecraft:moss_block
setblock 266 144 364 minecraft:green_terracotta
fill 267 144 322 268 147 322 minecraft:brown_terracotta
setblock 267 144 324 minecraft:moss_block
setblock 267 144 325 minecraft:mushroom_stem
setblock 267 144 361 minecraft:moss_block
setblock 268 144 324 minecraft:mushroom_stem
fill 268 144 325 268 147 325 minecraft:moss_block
setblock 269 144 323 minecraft:mushroom_stem
fill 269 144 324 269 147 324 minecraft:moss_block
fill 269 144 326 269 145 326 minecraft:moss_block
setblock 269 144 363 minecraft:mushroom_stem
fill 270 144 323 270 147 323 minecraft:moss_block
setblock 270 144 362 minecraft:mushroom_stem
fill 270 144 363 270 147 363 minecraft:moss_block
setblock 271 144 326 minecraft:mushroom_stem
setblock 271 144 361 minecraft:mushroom_stem
fill 271 144 362 271 147 362 minecraft:moss_block
setblock 272 144 322 minecraft:green_terracotta
setblock 272 144 325 minecraft:mushroom_stem
fill 272 144 361 272 146 361 minecraft:moss_block
setblock 273 144 324 minecraft:mushroom_stem
fill 273 144 325 273 146 325 minecraft:moss_block
setblock 274 144 323 minecraft:mushroom_stem
fill 274 144 324 274 147 324 minecraft:moss_block
setblock 274 144 343 minecraft:mushroom_stem
fill 274 144 344 274 145 344 minecraft:moss_block
setblock 274 144 348 minecraft:mushroom_stem
fill 274 144 349 274 147 349 minecraft:moss_block
setblock 274 144 353 minecraft:mushroom_stem
setblock 274 144 359 minecraft:moss_block
setblock 274 144 363 minecraft:mushroom_stem
fill 275 144 323 275 147 323 minecraft:moss_block
setblock 275 144 327 minecraft:mushroom_stem
fill 275 144 328 275 145 328 minecraft:moss_block
setblock 275 144 342 minecraft:mushroom_stem
fill 275 144 343 275 146 343 minecraft:moss_block
setblock 275 144 347 minecraft:mushroom_stem
fill 275 144 348 275 147 348 minecraft:moss_block
setblock 275 144 352 minecraft:mushroom_stem
fill 275 144 353 275 147 353 minecraft:moss_block
setblock 275 144 357 minecraft:mushroom_stem
fill 275 144 358 275 145 358 minecraft:moss_block
setblock 275 144 362 minecraft:mushroom_stem
fill 275 144 363 275 147 363 minecraft:moss_block
setblock 276 144 326 minecraft:mushroom_stem
fill 276 144 327 276 147 327 minecraft:moss_block
setblock 276 144 333 minecraft:red_mushroom_block
setblock 276 144 341 minecraft:mushroom_stem
fill 276 144 342 276 147 342 minecraft:moss_block
setblock 276 144 346 minecraft:mushroom_stem
fill 276 144 347 276 147 347 minecraft:moss_block
setblock 276 144 351 minecraft:mushroom_stem
fill 276 144 352 276 147 352 minecraft:moss_block
setblock 276 144 356 minecraft:mushroom_stem
fill 276 144 357 276 147 357 minecraft:moss_block
setblock 276 144 361 minecraft:mushroom_stem
fill 276 144 362 276 147 362 minecraft:moss_block
setblock 276 144 364 minecraft:green_terracotta
fill 277 144 323 277 147 323 minecraft:brown_terracotta
setblock 277 144 324 minecraft:green_terracotta
fill 277 144 325 277 147 326 minecraft:brown_terracotta
setblock 277 144 332 minecraft:green_terracotta
setblock 277 144 334 minecraft:green_terracotta
fill 277 144 339 277 145 339 minecraft:green_terracotta
fill 277 144 340 277 144 345 minecraft:brown_terracotta
setblock 277 144 347 minecraft:green_terracotta
fill 277 144 348 277 147 349 minecraft:brown_terracotta
setblock 277 144 350 minecraft:green_terracotta
fill 277 144 351 277 147 351 minecraft:brown_terracotta
setblock 277 144 358 minecraft:brown_terracotta
fill 235 145 331 235 147 331 minecraft:brown_terracotta
setblock 235 145 332 minecraft:green_terracotta
fill 235 145 336 235 147 336 minecraft:brown_terracotta
fill 235 145 339 235 147 342 minecraft:brown_terracotta
setblock 235 145 343 minecraft:red_mushroom_block
setblock 235 145 344 minecraft:brown_terracotta
fill 235 145 349 235 147 349 minecraft:brown_terracotta
setblock 235 145 350 minecraft:green_terracotta
setblock 235 145 353 minecraft:green_terracotta
fill 235 145 354 235 147 354 minecraft:brown_terracotta
setblock 235 145 355 minecraft:green_terracotta
fill 235 145 360 235 145 363 minecraft:brown_terracotta
fill 235 145 364 235 146 364 minecraft:green_terracotta
setblock 236 145 325 minecraft:mushroom_stem
fill 236 145 326 236 147 326 minecraft:moss_block
setblock 236 145 334 minecraft:red_mushroom_block
setblock 236 145 340 minecraft:mushroom_stem
fill 236 145 341 236 147 341 minecraft:moss_block
setblock 236 145 345 minecraft:mushroom_stem
fill 236 145 346 236 148 346 minecraft:moss_block
setblock 236 145 350 minecraft:mushroom_stem
fill 236 145 351 236 148 351 minecraft:moss_block
setblock 236 145 355 minecraft:mushroom_stem
setblock 236 145 356 minecraft:moss_block
setblock 236 145 360 minecraft:mushroom_stem
setblock 236 145 361 minecraft:moss_block
setblock 237 145 344 minecraft:mushroom_stem
fill 237 145 345 237 148 345 minecraft:moss_block
setblock 237 145 348 minecraft:moss_block
setblock 237 145 349 minecraft:mushroom_stem
fill 237 145 350 237 147 350 minecraft:moss_block
setblock 238 145 323 minecraft:mushroom_stem
setblock 238 145 344 minecraft:moss_block
setblock 238 145 348 minecraft:mushroom_stem
fill 241 145 323 242 145 323 minecraft:moss_block
fill 241 145 364 241 147 364 minecraft:brown_terracotta
fill 242 145 322 242 149 322 minecraft:brown_terracotta
fill 242 145 349 243 145 351 minecraft:red_mushroom_block
setblock 243 145 323 minecraft:mushroom_stem
fill 243 145 347 244 145 348 minecraft:red_mushroom_block
fill 243 145 352 248 145 352 minecraft:red_mushroom_block
fill 244 145 323 244 148 323 minecraft:moss_block
setblock 244 145 346 minecraft:red_mushroom_block
fill 244 145 351 244 147 351 minecraft:red_mushroom_block
fill 244 145 353 247 145 353 minecraft:red_mushroom_block
setblock 246 145 325 minecraft:mushroom_stem
fill 247 145 322 247 148 322 minecraft:brown_terracotta
setblock 247 145 324 minecraft:mushroom_stem
fill 247 145 325 247 148 325 minecraft:moss_block
setblock 248 145 323 minecraft:mushroom_stem
fill 248 145 324 248 148 324 minecraft:moss_block
fill 248 145 326 249 145 326 minecraft:moss_block
fill 248 145 351 249 145 351 minecraft:red_mushroom_block
setblock 248 145 363 minecraft:mushroom_stem
fill 249 145 323 249 148 323 minecraft:moss_block
fill 249 145 363 249 148 363 minecraft:moss_block
setblock 250 145 326 minecraft:mushroom_stem
setblock 250 145 362 minecraft:moss_block
setblock 251 145 325 minecraft:mushroom_stem
fill 251 145 326 251 148 326 minecraft:moss_block
setblock 252 145 324 minecraft:mushroom_stem
fill 252 145 325 252 148 325 minecraft:moss_block
setblock 253 145 323 minecraft:mushroom_stem
fill 253 145 324 253 148 324 minecraft:moss_block
setblock 253 145 363 minecraft:mushroom_stem
fill 254 145 323 254 148 323 minecraft:moss_block
setblock 254 145 326 minecraft:moss_block
fill 254 145 354 255 145 358 minecraft:red_mushroom_block
fill 254 145 363 257 145 363 minecraft:moss_block
setblock 255 145 326 minecraft:mushroom_stem
fill 255 145 353 261 145 353 minecraft:red_mushroom_block
fill 255 145 359 261 145 359 minecraft:red_mushroom_block
setblock 255 145 364 minecraft:brown_terracotta
setblock 256 145 322 minecraft:green_terracotta
setblock 256 145 325 minecraft:mushroom_stem
fill 256 145 352 259 145 352 minecraft:red_mushroom_block
fill 256 145 354 256 147 354 minecraft:red_mushroom_block
fill 256 145 358 256 147 358 minecraft:red_mushroom_block
fill 256 145 360 259 145 360 minecraft:red_mushroom_block
fill 256 145 364 257 145 364 minecraft:green_terracotta
setblock 257 145 324 minecraft:mushroom_stem
fill 257 145 325 257 147 325 minecraft:moss_block
fill 258 145 322 258 147 322 minecraft:brown_terracotta
setblock 258 145 323 minecraft:mushroom_stem
fill 258 145 324 261 145 324 minecraft:moss_block
setblock 258 145 363 minecraft:mushroom_stem
fill 259 145 323 259 148 323 minecraft:moss_block
fill 259 145 354 261 145 354 minecraft:red_mushroom_block
fill 259 145 363 259 146 363 minecraft:moss_block
fill 260 145 355 262 145 355 minecraft:red_mushroom_block
fill 260 145 357 261 145 358 minecraft:red_mushroom_block
setblock 261 145 325 minecraft:mushroom_stem
fill 261 145 343 262 145 345 minecraft:red_mushroom_block
fill 261 145 356 262 145 356 minecraft:red_mushroom_block
setblock 261 145 364 minecraft:green_terracotta
setblock 262 145 324 minecraft:mushroom_stem
fill 262 145 325 262 146 325 minecraft:moss_block
fill 262 145 342 266 145 342 minecraft:red_mushroom_block
fill 262 145 346 265 145 346 minecraft:red_mushroom_block
setblock 262 145 357 minecraft:red_mushroom_block
setblock 263 145 322 minecraft:green_terracotta
setblock 263 145 323 minecraft:mushroom_stem
fill 263 145 324 263 148 324 minecraft:moss_block
fill 263 145 341 265 145 341 minecraft:red_mushroom_block
setblock 263 145 363 minecraft:mushroom_stem
fill 264 145 322 264 147 322 minecraft:brown_terracotta
fill 264 145 323 264 148 323 minecraft:moss_block
setblock 264 145 362 minecraft:mushroom_stem
fill 264 145 363 264 148 363 minecraft:moss_block
setblock 265 145 325 minecraft:moss_block
fill 265 145 345 266 145 345 minecraft:red_mushroom_block
fill 265 145 362 265 148 362 minecraft:moss_block
fill 266 145 322 266 148 322 minecraft:brown_terracotta
setblock 266 145 325 minecraft:mushroom_stem
fill 266 145 343 266 146 344 minecraft:red_mushroom_block
fill 266 145 364 266 147 364 minecraft:brown_terracotta
setblock 267 145 324 minecraft:mushroom_stem
fill 267 145 325 267 148 325 minecraft:moss_block
setblock 268 145 323 minecraft:mushroom_stem
fill 268 145 324 268 148 324 minecraft:moss_block
fill 268 145 326 268 146 326 minecraft:moss_block
setblock 268 145 363 minecraft:mushroom_stem
fill 269 145 323 269 148 323 minecraft:moss_block
setblock 269 145 362 minecraft:mushroom_stem
fill 269 145 363 269 148 363 minecraft:moss_block
setblock 270 145 326 minecraft:mushroom_stem
fill 270 145 345 271 145 348 minecraft:red_mushroom_block
setblock 270 145 361 minecraft:mushroom_stem
fill 270 145 362 270 148 362 minecraft:moss_block
setblock 270 145 364 minecraft:green_terracotta
setblock 271 145 325 minecraft:mushroom_stem
setblock 271 145 326 minecraft:moss_block
fill 271 145 344 273 146 344 minecraft:red_mushroom_block
fill 271 145 349 273 145 349 minecraft:red_mushroom_block
fill 271 145 361 271 146 361 minecraft:moss_block
fill 272 145 322 272 148 322 minecraft:brown_terracotta
setblock 272 145 324 minecraft:mushroom_stem
fill 272 145 325 272 147 325 minecraft:moss_block
fill 272 145 343 274 145 343 minecraft:red_mushroom_block
fill 272 145 350 273 145 350 minecraft:red_mushroom_block
setblock 273 145 323 minecraft:mushroom_stem
fill 273 145 324 273 148 324 minecraft:moss_block
setblock 273 145 363 minecraft:mushroom_stem
fill 274 145 323 274 148 323 minecraft:moss_block
setblock 274 145 347 minecraft:mushroom_stem
fill 274 145 348 274 148 348 minecraft:moss_block
fill 274 145 350 274 145 351 minecraft:moss_block
setblock 274 145 352 minecraft:mushroom_stem
setblock 274 145 353 minecraft:moss_block
setblock 274 145 362 minecraft:mushroom_stem
fill 274 145 363 274 148 363 minecraft:moss_block
setblock 275 145 322 minecraft:green_terracotta
setblock 275 145 326 minecraft:mushroom_stem
fill 275 145 327 275 146 327 minecraft:moss_block
setblock 275 145 342 minecraft:moss_block
setblock 275 145 346 minecraft:mushroom_stem
fill 275 145 347 275 148 347 minecraft:moss_block
setblock 275 145 351 minecraft:mushroom_stem
fill 275 145 352 275 148 352 minecraft:moss_block
setblock 275 145 356 minecraft:mushroom_stem
setblock 275 145 357 minecraft:moss_block
setblock 275 145 361 minecraft:mushroom_stem
fill 275 145 362 275 146 362 minecraft:moss_block
setblock 275 145 364 minecraft:shroomlight
fill 276 145 322 277 147 322 minecraft:brown_terracotta
setblock 276 145 325 minecraft:mushroom_stem
fill 276 145 326 276 147 326 minecraft:moss_block
setblock 276 145 340 minecraft:mushroom_stem
fill 276 145 341 276 146 341 minecraft:moss_block
setblock 276 145 345 minecraft:mushroom_stem
fill 276 145 346 276 148 346 minecraft:moss_block
setblock 276 145 350 minecraft:mushroom_stem
fill 276 145 351 276 148 351 minecraft:moss_block
setblock 276 145 355 minecraft:mushroom_stem
fill 276 145 356 276 148 356 minecraft:moss_block
setblock 276 145 360 minecraft:mushroom_stem
fill 276 145 361 276 147 361 minecraft:moss_block
fill 276 145 364 276 147 364 minecraft:brown_terracotta
setblock 277 145 324 minecraft:brown_terracotta
setblock 277 145 327 minecraft:red_mushroom_block
setblock 277 145 332 minecraft:brown_terracotta
fill 277 145 334 277 147 334 minecraft:brown_terracotta
setblock 277 145 335 minecraft:green_terracotta
setblock 277 145 340 minecraft:green_terracotta
fill 277 145 341 277 147 342 minecraft:brown_terracotta
setblock 277 145 343 minecraft:green_terracotta
fill 277 145 344 277 147 345 minecraft:brown_terracotta
setblock 277 145 346 minecraft:green_terracotta
setblock 277 145 347 minecraft:brown_terracotta
fill 277 145 350 277 147 350 minecraft:brown_terracotta
setblock 277 145 356 minecraft:green_terracotta
fill 277 145 357 277 147 357 minecraft:brown_terracotta
setblock 277 145 358 minecraft:green_terracotta
setblock 277 145 361 minecraft:red_mushroom_block
setblock 235 146 327 minecraft:green_terracotta
fill 235 146 332 235 147 332 minecraft:brown_terracotta
fill 235 146 334 235 146 335 minecraft:green_terracotta
fill 235 146 343 235 147 343 minecraft:brown_terracotta
setblock 235 146 344 minecraft:green_terracotta
fill 235 146 350 235 147 350 minecraft:brown_terracotta
fill 235 146 353 235 147 353 minecraft:brown_terracotta
fill 235 146 355 235 147 355 minecraft:brown_terracotta
setblock 235 146 359 minecraft:green_terracotta
fill 235 146 360 235 147 360 minecraft:brown_terracotta
setblock 235 146 361 minecraft:green_terracotta
fill 235 146 362 235 147 362 minecraft:brown_terracotta
setblock 235 146 363 minecraft:green_terracotta
setblock 236 146 324 minecraft:mushroom_stem
fill 236 146 325 236 147 325 minecraft:moss_block
setblock 236 146 328 minecraft:moss_block
setblock 236 146 329 minecraft:mushroom_stem
setblock 236 146 339 minecraft:mushroom_stem
fill 236 146 340 236 147 340 minecraft:moss_block
setblock 236 146 344 minecraft:mushroom_stem
fill 236 146 345 236 148 345 minecraft:moss_block
setblock 236 146 349 minecraft:mushroom_stem
fill 236 146 350 236 148 350 minecraft:moss_block
setblock 236 146 354 minecraft:mushroom_stem
setblock 236 146 355 minecraft:moss_block
fill 237 146 322 238 146 322 minecraft:green_terracotta
setblock 237 146 343 minecraft:mushroom_stem
fill 237 146 344 237 147 344 minecraft:moss_block
setblock 237 146 348 minecraft:mushroom_stem
fill 237 146 349 237 148 349 minecraft:moss_block
setblock 238 146 347 minecraft:mushroom_stem
setblock 238 146 348 minecraft:moss_block
setblock 238 146 363 minecraft:red_mushroom_block
setblock 241 146 322 minecraft:green_terracotta
setblock 242 146 323 minecraft:mushroom_stem
fill 243 146 323 243 148 323 minecraft:moss_block
fill 243 146 348 243 146 351 minecraft:red_mushroom_block
fill 244 146 347 244 146 348 minecraft:red_mushroom_block
fill 244 146 352 248 146 352 minecraft:red_mushroom_block
setblock 245 146 364 minecraft:green_terracotta
setblock 246 146 324 minecraft:mushroom_stem
fill 246 146 325 246 148 325 minecraft:moss_block
setblock 247 146 323 minecraft:mushroom_stem
fill 247 146 324 247 148 324 minecraft:moss_block
setblock 247 146 363 minecraft:mushroom_stem
fill 248 146 323 248 148 323 minecraft:moss_block
setblock 248 146 326 minecraft:moss_block
fill 248 146 351 248 147 351 minecraft:red_mushroom_block
fill 248 146 363 248 148 363 minecraft:moss_block
setblock 249 146 326 minecraft:mushroom_stem
setblock 250 146 325 minecraft:mushroom_stem
fill 250 146 326 250 148 326 minecraft:moss_block
setblock 251 146 324 minecraft:mushroom_stem
fill 251 146 325 251 148 325 minecraft:moss_block
setblock 252 146 323 minecraft:mushroom_stem
fill 252 146 324 252 148 324 minecraft:moss_block
setblock 252 146 363 minecraft:mushroom_stem
fill 253 146 323 253 148 323 minecraft:moss_block
fill 253 146 363 256 146 363 minecraft:moss_block
setblock 254 146 326 minecraft:mushroom_stem
setblock 255 146 325 minecraft:mushroom_stem
fill 255 146 354 255 146 358 minecraft:red_mushroom_block
setblock 255 146 364 minecraft:green_terracotta
fill 256 146 322 256 147 322 minecraft:brown_terracotta
setblock 256 146 324 minecraft:mushroom_stem
fill 256 146 325 256 147 325 minecraft:moss_block
fill 256 146 353 259 146 353 minecraft:red_mushroom_block
fill 256 146 359 260 146 359 minecraft:red_mushroom_block
fill 256 146 364 256 147 364 minecraft:brown_terracotta
setblock 257 146 323 minecraft:mushroom_stem
fill 257 146 324 260 146 324 minecraft:moss_block
setblock 257 146 363 minecraft:mushroom_stem
setblock 257 146 364 minecraft:green_terracotta
fill 258 146 323 258 148 323 minecraft:moss_block
setblock 258 146 363 minecraft:moss_block
fill 259 146 354 260 147 354 minecraft:red_mushroom_block
fill 260 146 355 261 146 355 minecraft:red_mushroom_block
fill 260 146 357 260 147 358 minecraft:red_mushroom_block
setblock 260 146 364 minecraft:shroomlight
setblock 261 146 324 minecraft:mushroom_stem
fill 261 146 356 261 146 357 minecraft:red_mushroom_block
fill 261 146 364 261 147 364 minecraft:brown_terracotta
setblock 262 146 323 minecraft:mushroom_stem
fill 262 146 324 262 148 324 minecraft:moss_block
fill 262 146 342 262 146 345 minecraft:red_mushroom_block
setblock 262 146 363 minecraft:mushroom_stem
setblock 263 146 322 minecraft:brown_terracotta
fill 263 146 323 263 148 323 minecraft:moss_block
fill 263 146 342 265 146 342 minecraft:red_mushroom_block
fill 263 146 346 264 146 346 minecraft:red_mushroom_block
fill 263 146 363 263 148 363 minecraft:moss_block
setblock 265 146 325 minecraft:mushroom_stem
fill 265 146 345 265 147 345 minecraft:red_mushroom_block
setblock 265 146 364 minecraft:green_terracotta
setblock 266 146 324 minecraft:mushroom_stem
fill 266 146 325 266 148 325 minecraft:moss_block
setblock 267 146 323 minecraft:mushroom_stem
fill 267 146 324 267 148 324 minecraft:moss_block
setblock 267 146 363 minecraft:mushroom_stem
fill 268 146 323 268 148 323 minecraft:moss_block
setblock 268 146 362 minecraft:mushroom_stem
fill 268 146 363 268 148 363 minecraft:moss_block
setblock 269 146 326 minecraft:mushroom_stem
setblock 269 146 361 minecraft:mushroom_stem
fill 269 146 362 269 148 362 minecraft:moss_block
setblock 269 146 364 minecraft:green_terracotta
setblock 270 146 325 minecraft:mushroom_stem
fill 270 146 346 271 146 347 minecraft:red_mushroom_block
fill 270 146 361 270 147 361 minecraft:moss_block
fill 270 146 364 270 147 364 minecraft:brown_terracotta
setblock 271 146 324 minecraft:mushroom_stem
fill 271 146 325 271 148 325 minecraft:moss_block
fill 271 146 345 271 147 345 minecraft:red_mushroom_block
setblock 271 146 348 minecraft:red_mushroom_block
setblock 272 146 323 minecraft:mushroom_stem
fill 272 146 324 272 148 324 minecraft:moss_block
fill 272 146 349 273 146 349 minecraft:red_mushroom_block
setblock 272 146 363 minecraft:mushroom_stem
fill 273 146 323 273 148 323 minecraft:moss_block
setblock 273 146 343 minecraft:red_mushroom_block
setblock 273 146 362 minecraft:mushroom_stem
fill 273 146 363 273 148 363 minecraft:moss_block
fill 274 146 344 274 147 344 minecraft:red_mushroom_block
setblock 274 146 346 minecraft:mushroom_stem
fill 274 146 347 274 147 347 minecraft:moss_block
setblock 274 146 350 minecraft:moss_block
setblock 274 146 351 minecraft:mushroom_stem
fill 274 146 352 274 147 352 minecraft:moss_block
fill 274 146 362 274 147 362 minecraft:moss_block
fill 275 146 322 275 148 322 minecraft:brown_terracotta
setblock 275 146 325 minecraft:mushroom_stem
setblock 275 146 326 minecraft:moss_block
setblock 275 146 345 minecraft:mushroom_stem
fill 275 146 346 275 148 346 minecraft:moss_block
setblock 275 146 350 minecraft:mushroom_stem
fill 275 146 351 275 148 351 minecraft:moss_block
setblock 275 146 355 minecraft:mushroom_stem
setblock 275 146 356 minecraft:moss_block
setblock 275 146 360 minecraft:mushroom_stem
setblock 275 146 361 minecraft:moss_block
fill 275 146 364 275 147 364 minecraft:brown_terracotta
setblock 276 146 324 minecraft:mushroom_stem
fill 276 146 325 276 147 325 minecraft:moss_block
setblock 276 146 329 minecraft:mushroom_stem
setblock 276 146 340 minecraft:red_mushroom_block
setblock 276 146 344 minecraft:mushroom_stem
fill 276 146 345 276 148 345 minecraft:moss_block
setblock 276 146 349 minecraft:mushroom_stem
fill 276 146 350 276 148 350 minecraft:moss_block
setblock 276 146 354 minecraft:mushroom_stem
fill 276 146 355 276 148 355 minecraft:moss_block
setblock 276 146 359 minecraft:mushroom_stem
fill 276 146 360 276 147 360 minecraft:moss_block
setblock 277 146 324 minecraft:green_terracotta
fill 277 146 327 277 148 327 minecraft:brown_terracotta
setblock 277 146 332 minecraft:green_terracotta
fill 277 146 335 277 148 335 minecraft:brown_terracotta
fill 277 146 339 277 147 340 minecraft:brown_terracotta
fill 277 146 343 277 147 343 minecraft:brown_terracotta
fill 277 146 346 277 147 346 minecraft:brown_terracotta
setblock 277 146 347 minecraft:red_mushroom_block
fill 277 146 356 277 147 356 minecraft:brown_terracotta
fill 277 146 358 277 147 358 minecraft:brown_terracotta
setblock 277 146 359 minecraft:green_terracotta
fill 277 146 361 277 148 361 minecraft:brown_terracotta
setblock 235 147 327 minecraft:brown_terracotta
fill 235 147 334 235 147 335 minecraft:brown_terracotta
setblock 235 147 344 minecraft:brown_terracotta
setblock 235 147 357 minecraft:brown_terracotta
setblock 235 147 359 minecraft:brown_terracotta
setblock 235 147 361 minecraft:brown_terracotta
fill 235 147 363 235 147 364 minecraft:brown_terracotta
setblock 236 147 328 minecraft:mushroom_stem
setblock 236 147 329 minecraft:moss_block
setblock 236 147 343 minecraft:mushroom_stem
fill 236 147 344 236 148 344 minecraft:moss_block
setblock 236 147 348 minecraft:mushroom_stem
fill 236 147 349 236 148 349 minecraft:moss_block
setblock 236 147 353 minecraft:mushroom_stem
fill 236 147 354 236 148 354 minecraft:moss_block
fill 237 147 322 238 147 322 minecraft:brown_terracotta
setblock 237 147 343 minecraft:moss_block
setblock 237 147 347 minecraft:mushroom_stem
fill 237 147 348 237 148 348 minecraft:moss_block
setblock 238 147 325 minecraft:light[level=12]
setblock 238 147 332 minecraft:light[level=12]
setblock 238 147 339 minecraft:light[level=12]
setblock 238 147 346 minecraft:light[level=12]
setblock 238 147 353 minecraft:light[level=12]
setblock 238 147 360 minecraft:light[level=12]
setblock 241 147 322 minecraft:brown_terracotta
setblock 243 147 350 minecraft:red_mushroom_block
setblock 244 147 348 minecraft:red_mushroom_block
setblock 244 147 363 minecraft:red_mushroom_block
setblock 245 147 324 minecraft:mushroom_stem
setblock 245 147 325 minecraft:light[level=12]
setblock 245 147 332 minecraft:light[level=12]
setblock 245 147 339 minecraft:light[level=12]
setblock 245 147 346 minecraft:light[level=12]
fill 245 147 352 247 147 352 minecraft:red_mushroom_block
setblock 245 147 353 minecraft:light[level=12]
setblock 245 147 360 minecraft:light[level=12]
setblock 245 147 364 minecraft:brown_terracotta
setblock 246 147 323 minecraft:mushroom_stem
fill 246 147 324 246 148 324 minecraft:moss_block
fill 246 147 350 246 148 350 minecraft:mushroom_stem
fill 247 147 323 247 148 323 minecraft:moss_block
setblock 247 147 363 minecraft:moss_block
setblock 248 147 326 minecraft:mushroom_stem
setblock 249 147 325 minecraft:mushroom_stem
fill 249 147 326 249 148 326 minecraft:moss_block
setblock 250 147 324 minecraft:mushroom_stem
fill 250 147 325 250 148 325 minecraft:moss_block
setblock 251 147 323 minecraft:mushroom_stem
fill 251 147 324 251 148 324 minecraft:moss_block
setblock 251 147 363 minecraft:mushroom_stem
fill 252 147 323 252 148 323 minecraft:moss_block
setblock 252 147 332 minecraft:light[level=12]
setblock 252 147 339 minecraft:light[level=12]
setblock 252 147 346 minecraft:light[level=12]
setblock 252 147 353 minecraft:light[level=12]
setblock 252 147 360 minecraft:light[level=12]
fill 252 147 363 255 147 363 minecraft:moss_block
setblock 253 147 326 minecraft:mushroom_stem
setblock 254 147 325 minecraft:mushroom_stem
setblock 255 147 324 minecraft:mushroom_stem
fill 255 147 325 255 148 325 minecraft:moss_block
fill 255 147 355 255 147 357 minecraft:red_mushroom_block
setblock 255 147 364 minecraft:brown_terracotta
setblock 256 147 323 minecraft:mushroom_stem
fill 256 147 324 259 147 324 minecraft:moss_block
fill 257 147 323 257 148 323 minecraft:moss_block
setblock 257 147 364 minecraft:brown_terracotta
setblock 258 147 353 minecraft:red_mushroom_block
setblock 258 147 359 minecraft:red_mushroom_block
setblock 259 147 325 minecraft:light[level=12]
setblock 259 147 332 minecraft:light[level=12]
setblock 259 147 339 minecraft:light[level=12]
setblock 259 147 346 minecraft:light[level=12]
setblock 259 147 353 minecraft:light[level=12]
setblock 259 147 360 minecraft:light[level=12]
setblock 260 147 324 minecraft:mushroom_stem
setblock 260 147 355 minecraft:red_mushroom_block
fill 260 147 364 260 149 364 minecraft:brown_terracotta
setblock 261 147 323 minecraft:mushroom_stem
fill 261 147 324 261 148 324 minecraft:moss_block
setblock 261 147 363 minecraft:mushroom_stem
fill 262 147 323 262 148 323 minecraft:moss_block
fill 262 147 343 262 147 344 minecraft:red_mushroom_block
fill 262 147 363 262 148 363 minecraft:moss_block
setblock 263 147 322 minecraft:red_mushroom_block
fill 263 147 342 264 147 342 minecraft:red_mushroom_block
setblock 264 147 325 minecraft:mushroom_stem
setblock 265 147 324 minecraft:mushroom_stem
fill 265 147 325 265 148 325 minecraft:moss_block
setblock 265 147 364 minecraft:brown_terracotta
setblock 266 147 323 minecraft:mushroom_stem
fill 266 147 324 266 148 324 minecraft:moss_block
setblock 266 147 332 minecraft:light[level=12]
setblock 266 147 339 minecraft:light[level=12]
setblock 266 147 346 minecraft:light[level=12]
setblock 266 147 353 minecraft:light[level=12]
setblock 266 147 360 minecraft:light[level=12]
setblock 266 147 363 minecraft:mushroom_stem
fill 267 147 323 267 148 323 minecraft:moss_block
setblock 267 147 362 minecraft:mushroom_stem
fill 267 147 363 267 148 363 minecraft:moss_block
fill 268 147 362 268 148 362 minecraft:moss_block
setblock 269 147 325 minecraft:mushroom_stem
setblock 269 147 361 minecraft:moss_block
setblock 269 147 364 minecraft:brown_terracotta
setblock 270 147 324 minecraft:mushroom_stem
fill 270 147 325 270 148 325 minecraft:moss_block
setblock 271 147 323 minecraft:mushroom_stem
fill 271 147 324 271 148 324 minecraft:moss_block
fill 271 147 346 271 147 347 minecraft:red_mushroom_block
setblock 271 147 363 minecraft:mushroom_stem
fill 272 147 323 272 148 323 minecraft:moss_block
fill 272 147 344 273 147 344 minecraft:red_mushroom_block
setblock 272 147 362 minecraft:mushroom_stem
fill 272 147 363 272 148 363 minecraft:moss_block
setblock 273 147 322 minecraft:red_mushroom_block
setblock 273 147 325 minecraft:light[level=12]
setblock 273 147 332 minecraft:light[level=12]
setblock 273 147 339 minecraft:light[level=12]
setblock 273 147 349 minecraft:red_mushroom_block
setblock 273 147 353 minecraft:light[level=12]
setblock 273 147 360 minecraft:light[level=12]
setblock 273 147 362 minecraft:moss_block
fill 274 147 345 274 148 345 minecraft:mushroom_stem
setblock 274 147 346 minecraft:moss_block
setblock 274 147 350 minecraft:mushroom_stem
fill 274 147 351 274 148 351 minecraft:moss_block
setblock 275 147 344 minecraft:mushroom_stem
setblock 275 147 345 minecraft:moss_block
setblock 275 147 349 minecraft:mushroom_stem
fill 275 147 350 275 148 350 minecraft:moss_block
setblock 275 147 354 minecraft:mushroom_stem
setblock 275 147 355 minecraft:moss_block
setblock 276 147 323 minecraft:mushroom_stem
setblock 276 147 324 minecraft:moss_block
setblock 276 147 328 minecraft:mushroom_stem
setblock 276 147 334 minecraft:red_mushroom_block
setblock 276 147 343 minecraft:mushroom_stem
fill 276 147 344 276 148 344 minecraft:moss_block
setblock 276 147 348 minecraft:mushroom_stem
fill 276 147 349 276 148 349 minecraft:moss_block
setblock 276 147 353 minecraft:mushroom_stem
fill 276 147 354 276 148 354 minecraft:moss_block
setblock 276 147 358 minecraft:mushroom_stem
setblock 276 147 359 minecraft:moss_block
setblock 276 147 363 minecraft:mushroom_stem
setblock 277 147 324 minecraft:brown_terracotta
setblock 277 147 332 minecraft:brown_terracotta
setblock 277 147 347 minecraft:brown_terracotta
setblock 277 147 359 minecraft:brown_terracotta
fill 235 148 322 235 148 357 minecraft:green_terracotta
fill 235 148 359 235 148 364 minecraft:green_terracotta
fill 236 148 322 241 149 322 minecraft:green_terracotta
setblock 236 148 333 minecraft:red_mushroom_block
setblock 236 148 342 minecraft:mushroom_stem
setblock 236 148 343 minecraft:moss_block
setblock 236 148 347 minecraft:mushroom_stem
setblock 236 148 348 minecraft:moss_block
setblock 236 148 352 minecraft:mushroom_stem
setblock 236 148 353 minecraft:moss_block
setblock 236 148 358 minecraft:red_mushroom_block
setblock 237 148 323 minecraft:red_mushroom_block
setblock 237 148 346 minecraft:mushroom_stem
setblock 237 148 347 minecraft:moss_block
fill 237 148 350 241 148 352 minecraft:red_mushroom_block
setblock 237 148 364 minecraft:brown_terracotta
fill 238 148 349 240 148 349 minecraft:red_mushroom_block
fill 238 148 353 240 148 353 minecraft:red_mushroom_block
fill 238 148 364 253 149 364 minecraft:green_terracotta
fill 243 148 322 246 148 322 minecraft:green_terracotta
setblock 244 148 324 minecraft:mushroom_stem
setblock 245 148 323 minecraft:mushroom_stem
setblock 245 148 324 minecraft:moss_block
setblock 246 148 323 minecraft:moss_block
fill 248 148 322 248 228 322 minecraft:green_terracotta
setblock 248 148 325 minecraft:mushroom_stem
setblock 248 148 326 minecraft:moss_block
fill 249 148 322 249 149 322 minecraft:brown_terracotta
setblock 249 148 324 minecraft:mushroom_stem
setblock 249 148 325 minecraft:moss_block
fill 250 148 322 262 148 322 minecraft:green_terracotta
setblock 250 148 323 minecraft:mushroom_stem
setblock 250 148 324 minecraft:moss_block
setblock 250 148 363 minecraft:mushroom_stem
setblock 251 148 323 minecraft:moss_block
fill 251 148 363 252 148 363 minecraft:moss_block
setblock 252 148 326 minecraft:mushroom_stem
setblock 253 148 325 minecraft:mushroom_stem
setblock 254 148 324 minecraft:mushroom_stem
setblock 254 148 325 minecraft:moss_block
setblock 255 148 323 minecraft:mushroom_stem
fill 255 148 324 258 148 324 minecraft:moss_block
fill 255 148 364 259 148 364 minecraft:green_terracotta
setblock 256 148 323 minecraft:moss_block
setblock 259 148 324 minecraft:mushroom_stem
setblock 260 148 323 minecraft:mushroom_stem
setblock 260 148 324 minecraft:moss_block
setblock 261 148 323 minecraft:moss_block
fill 261 148 364 276 148 364 minecraft:green_terracotta
setblock 263 148 322 minecraft:brown_terracotta
fill 264 148 322 264 168 322 minecraft:green_terracotta
setblock 264 148 324 minecraft:mushroom_stem
setblock 264 148 325 minecraft:moss_block
setblock 265 148 323 minecraft:mushroom_stem
setblock 265 148 324 minecraft:moss_block
setblock 265 148 363 minecraft:mushroom_stem
setblock 266 148 323 minecraft:moss_block
setblock 266 148 362 minecraft:mushroom_stem
setblock 266 148 363 minecraft:moss_block
fill 267 148 322 271 163 322 minecraft:green_terracotta
setblock 267 148 362 minecraft:moss_block
setblock 268 148 325 minecraft:mushroom_stem
setblock 269 148 324 minecraft:mushroom_stem
setblock 269 148 325 minecraft:moss_block
setblock 270 148 323 minecraft:mushroom_stem
setblock 270 148 324 minecraft:moss_block
setblock 270 148 363 minecraft:mushroom_stem
setblock 271 148 323 minecraft:moss_block
setblock 271 148 362 minecraft:mushroom_stem
setblock 271 148 363 minecraft:moss_block
setblock 272 148 362 minecraft:moss_block
fill 273 148 322 274 148 322 minecraft:green_terracotta
fill 274 148 346 274 148 347 minecraft:mushroom_stem
setblock 274 148 349 minecraft:mushroom_stem
setblock 274 148 350 minecraft:moss_block
setblock 275 148 323 minecraft:mushroom_stem
setblock 275 148 345 minecraft:mushroom_stem
setblock 275 148 348 minecraft:mushroom_stem
setblock 275 148 349 minecraft:moss_block
setblock 275 148 353 minecraft:mushroom_stem
setblock 275 148 354 minecraft:moss_block
setblock 275 148 363 minecraft:mushroom_stem
fill 276 148 322 277 228 322 minecraft:green_terracotta
setblock 276 148 328 minecraft:red_mushroom_block
setblock 276 148 347 minecraft:mushroom_stem
setblock 276 148 348 minecraft:moss_block
setblock 276 148 352 minecraft:mushroom_stem
setblock 276 148 353 minecraft:moss_block
fill 277 148 323 277 149 326 minecraft:green_terracotta
fill 277 148 329 277 148 334 minecraft:green_terracotta
fill 277 148 336 277 209 338 minecraft:green_terracotta
setblock 277 148 339 minecraft:brown_terracotta
fill 277 148 340 277 228 340 minecraft:green_terracotta
setblock 277 148 341 minecraft:brown_terracotta
fill 277 148 342 277 161 348 minecraft:green_terracotta
setblock 277 148 349 minecraft:brown_terracotta
fill 277 148 350 277 148 360 minecraft:green_terracotta
fill 277 148 362 277 199 363 minecraft:green_terracotta
fill 235 149 322 235 224 322 minecraft:green_terracotta
setblock 235 149 323 minecraft:brown_terracotta
fill 235 149 324 235 199 329 minecraft:green_terracotta
setblock 235 149 330 minecraft:brown_terracotta
fill 235 149 331 235 149 342 minecraft:green_terracotta
setblock 235 149 343 minecraft:brown_terracotta
fill 235 149 344 235 149 349 minecraft:green_terracotta
fill 235 149 350 235 149 351 minecraft:brown_terracotta
fill 235 149 352 235 149 363 minecraft:green_terracotta
setblock 235 149 364 minecraft:brown_terracotta
fill 237 149 364 237 214 364 minecraft:green_terracotta
setblock 238 149 325 minecraft:light[level=15]
setblock 238 149 333 minecraft:light[level=15]
setblock 238 149 341 minecraft:light[level=15]
setblock 238 149 349 minecraft:light[level=15]
setblock 238 149 357 minecraft:light[level=15]
fill 243 149 322 245 226 322 minecraft:green_terracotta
setblock 246 149 322 minecraft:brown_terracotta
setblock 246 149 325 minecraft:light[level=15]
setblock 246 149 333 minecraft:light[level=15]
setblock 246 149 341 minecraft:light[level=15]
setblock 246 149 349 minecraft:light[level=15]
setblock 246 149 357 minecraft:light[level=15]
fill 247 149 322 247 158 322 minecraft:green_terracotta
fill 250 149 322 255 150 322 minecraft:green_terracotta
setblock 254 149 325 minecraft:light[level=15]
setblock 254 149 333 minecraft:light[level=15]
setblock 254 149 341 minecraft:light[level=15]
setblock 254 149 349 minecraft:light[level=15]
setblock 254 149 357 minecraft:light[level=15]
setblock 255 149 364 minecraft:brown_terracotta
setblock 256 149 322 minecraft:brown_terracotta
fill 256 149 364 259 169 364 minecraft:green_terracotta
fill 257 149 322 260 149 322 minecraft:green_terracotta
setblock 261 149 322 minecraft:brown_terracotta
fill 261 149 364 270 152 364 minecraft:green_terracotta
fill 262 149 322 263 225 322 minecraft:green_terracotta
setblock 262 149 325 minecraft:light[level=15]
setblock 262 149 333 minecraft:light[level=15]
setblock 262 149 341 minecraft:light[level=15]
setblock 262 149 349 minecraft:light[level=15]
setblock 262 149 357 minecraft:light[level=15]
fill 265 149 322 266 196 322 minecraft:green_terracotta
setblock 270 149 325 minecraft:light[level=15]
setblock 270 149 333 minecraft:light[level=15]
setblock 270 149 341 minecraft:light[level=15]
setblock 270 149 349 minecraft:light[level=15]
setblock 270 149 357 minecraft:light[level=15]
setblock 271 149 364 minecraft:brown_terracotta
fill 272 149 322 273 149 322 minecraft:green_terracotta
fill 272 149 364 277 159 364 minecraft:green_terracotta
fill 274 149 322 274 150 322 minecraft:brown_terracotta
fill 275 149 322 275 178 322 minecraft:green_terracotta
fill 277 149 327 277 192 328 minecraft:green_terracotta
setblock 277 149 329 minecraft:brown_terracotta
fill 277 149 330 277 228 330 minecraft:green_terracotta
setblock 277 149 331 minecraft:brown_terracotta
fill 277 149 332 277 149 334 minecraft:green_terracotta
setblock 277 149 335 minecraft:red_mushroom_block
fill 277 149 339 277 228 339 minecraft:green_terracotta
fill 277 149 341 277 191 341 minecraft:green_terracotta
fill 277 149 349 277 175 352 minecraft:green_terracotta
fill 277 149 353 277 150 353 minecraft:brown_terracotta
fill 277 149 354 277 154 358 minecraft:green_terracotta
setblock 277 149 359 minecraft:brown_terracotta
fill 277 149 360 277 225 361 minecraft:green_terracotta
fill 235 150 323 235 186 323 minecraft:green_terracotta
fill 235 150 330 235 158 334 minecraft:green_terracotta
fill 235 150 335 235 150 336 minecraft:brown_terracotta
fill 235 150 337 235 156 343 minecraft:green_terracotta
setblock 235 150 344 minecraft:brown_terracotta
fill 235 150 345 235 164 360 minecraft:green_terracotta
setblock 235 150 361 minecraft:brown_terracotta
fill 235 150 362 235 151 364 minecraft:green_terracotta
fill 236 150 322 236 225 322 minecraft:green_terracotta
fill 236 150 364 236 224 364 minecraft:green_terracotta
setblock 237 150 322 minecraft:brown_terracotta
fill 238 150 322 242 163 322 minecraft:green_terracotta
fill 238 150 364 239 155 364 minecraft:green_terracotta
setblock 240 150 364 minecraft:brown_terracotta
fill 241 150 364 242 194 364 minecraft:green_terracotta
setblock 243 150 364 minecraft:brown_terracotta
fill 244 150 364 248 156 364 minecraft:green_terracotta
fill 246 150 322 246 229 322 minecraft:green_terracotta
fill 249 150 322 249 228 322 minecraft:green_terracotta
setblock 249 150 364 minecraft:brown_terracotta
fill 250 150 364 255 153 364 minecraft:green_terracotta
setblock 251 150 327 minecraft:shroomlight
fill 256 150 322 259 168 322 minecraft:green_terracotta
setblock 260 150 322 minecraft:brown_terracotta
fill 260 150 364 260 162 364 minecraft:green_terracotta
fill 261 150 322 261 228 322 minecraft:green_terracotta
fill 271 150 364 271 198 364 minecraft:green_terracotta
fill 272 150 322 272 226 322 minecraft:green_terracotta
setblock 273 150 322 minecraft:brown_terracotta
fill 277 150 323 277 223 324 minecraft:green_terracotta
setblock 277 150 325 minecraft:brown_terracotta
fill 277 150 326 277 156 326 minecraft:green_terracotta
fill 277 150 329 277 224 329 minecraft:green_terracotta
fill 277 150 331 277 225 333 minecraft:green_terracotta
setblock 277 150 334 minecraft:brown_terracotta
fill 277 150 335 277 228 335 minecraft:green_terracotta
fill 277 150 359 277 228 359 minecraft:green_terracotta
fill 235 151 335 235 158 336 minecraft:green_terracotta
fill 235 151 344 235 211 344 minecraft:green_terracotta
fill 235 151 361 235 222 361 minecraft:green_terracotta
fill 237 151 322 237 215 322 minecraft:green_terracotta
fill 240 151 364 240 154 364 minecraft:green_terracotta
fill 243 151 364 243 225 364 minecraft:green_terracotta
fill 249 151 364 249 207 364 minecraft:green_terracotta
fill 250 151 322 252 224 322 minecraft:green_terracotta
fill 251 151 327 251 153 327 minecraft:mushroom_stem
setblock 253 151 322 minecraft:red_mushroom_block
fill 254 151 322 255 192 322 minecraft:green_terracotta
fill 260 151 322 260 167 322 minecraft:green_terracotta
fill 273 151 322 274 182 322 minecraft:green_terracotta
fill 277 151 325 277 192 325 minecraft:green_terracotta
fill 277 151 334 277 196 334 minecraft:green_terracotta
fill 277 151 353 277 228 353 minecraft:green_terracotta
setblock 235 152 362 minecraft:red_mushroom_block
fill 235 152 363 235 207 364 minecraft:green_terracotta
fill 253 152 322 253 172 322 minecraft:green_terracotta
fill 235 153 362 235 155 362 minecraft:green_terracotta
setblock 238 153 325 minecraft:light[level=12]
setblock 238 153 332 minecraft:light[level=12]
setblock 238 153 339 minecraft:light[level=12]
setblock 238 153 346 minecraft:light[level=12]
setblock 238 153 353 minecraft:light[level=12]
setblock 238 153 360 minecraft:light[level=12]
setblock 245 153 325 minecraft:light[level=12]
setblock 245 153 332 minecraft:light[level=12]
setblock 245 153 339 minecraft:light[level=12]
setblock 245 153 346 minecraft:light[level=12]
setblock 245 153 353 minecraft:light[level=12]
setblock 245 153 360 minecraft:light[level=12]
setblock 252 153 325 minecraft:light[level=12]
setblock 252 153 332 minecraft:light[level=12]
setblock 252 153 339 minecraft:light[level=12]
setblock 252 153 346 minecraft:light[level=12]
setblock 252 153 353 minecraft:light[level=12]
setblock 252 153 360 minecraft:light[level=12]
setblock 259 153 325 minecraft:light[level=12]
setblock 259 153 332 minecraft:light[level=12]
setblock 259 153 339 minecraft:light[level=12]
setblock 259 153 346 minecraft:light[level=12]
setblock 259 153 353 minecraft:light[level=12]
setblock 259 153 360 minecraft:light[level=12]
fill 261 153 364 266 161 364 minecraft:green_terracotta
setblock 266 153 325 minecraft:light[level=12]
setblock 266 153 332 minecraft:light[level=12]
setblock 266 153 339 minecraft:light[level=12]
setblock 266 153 346 minecraft:light[level=12]
setblock 266 153 353 minecraft:light[level=12]
setblock 266 153 360 minecraft:light[level=12]
setblock 267 153 364 minecraft:red_mushroom_block
fill 268 153 364 270 225 364 minecraft:green_terracotta
setblock 273 153 325 minecraft:light[level=12]
setblock 273 153 332 minecraft:light[level=12]
setblock 273 153 339 minecraft:light[level=12]
setblock 273 153 346 minecraft:light[level=12]
setblock 273 153 353 minecraft:light[level=12]
setblock 273 153 360 minecraft:light[level=12]
fill 236 154 323 237 155 323 minecraft:moss_block
fill 236 154 324 236 155 324 minecraft:green_wool
fill 236 154 325 236 155 328 minecraft:moss_block
fill 236 154 329 236 155 329 minecraft:green_wool
fill 236 154 330 236 155 333 minecraft:moss_block
fill 236 154 334 236 155 334 minecraft:green_wool
fill 236 154 335 236 155 338 minecraft:moss_block
fill 236 154 339 236 155 339 minecraft:green_wool
fill 236 154 340 236 155 343 minecraft:moss_block
fill 236 154 344 236 155 344 minecraft:green_wool
fill 236 154 345 236 155 348 minecraft:moss_block
fill 236 154 349 236 155 349 minecraft:green_wool
fill 236 154 350 236 155 353 minecraft:moss_block
fill 236 154 354 236 155 354 minecraft:green_wool
fill 236 154 355 236 155 358 minecraft:moss_block
fill 236 154 359 236 155 359 minecraft:green_wool
fill 236 154 360 236 155 363 minecraft:moss_block
fill 237 154 324 238 155 325 minecraft:moss_block
fill 237 154 326 237 155 326 minecraft:green_wool
fill 237 154 327 237 155 330 minecraft:moss_block
fill 237 154 331 237 155 331 minecraft:green_wool
fill 237 154 332 237 155 335 minecraft:moss_block
fill 237 154 336 237 155 336 minecraft:green_wool
fill 237 154 337 237 155 340 minecraft:moss_block
fill 237 154 341 237 155 341 minecraft:green_wool
fill 237 154 342 237 155 345 minecraft:moss_block
fill 237 154 346 237 155 346 minecraft:green_wool
fill 237 154 347 237 155 350 minecraft:moss_block
fill 237 154 351 237 155 351 minecraft:green_wool
fill 237 154 352 237 155 355 minecraft:moss_block
fill 237 154 356 237 155 356 minecraft:green_wool
fill 237 154 357 237 155 360 minecraft:moss_block
fill 237 154 361 237 155 361 minecraft:green_wool
fill 237 154 362 237 155 363 minecraft:moss_block
fill 238 154 323 238 155 323 minecraft:green_wool
fill 238 154 326 239 155 327 minecraft:moss_block
fill 238 154 328 238 155 328 minecraft:green_wool
fill 238 154 329 238 155 332 minecraft:moss_block
fill 238 154 333 238 155 333 minecraft:green_wool
fill 238 154 334 238 155 337 minecraft:moss_block
fill 238 154 338 238 155 338 minecraft:green_wool
fill 238 154 339 238 155 342 minecraft:moss_block
fill 238 154 343 238 155 343 minecraft:green_wool
fill 238 154 344 238 155 347 minecraft:moss_block
fill 238 154 348 238 155 348 minecraft:green_wool
fill 238 154 349 238 155 352 minecraft:moss_block
fill 238 154 353 238 155 353 minecraft:green_wool
fill 238 154 354 238 155 357 minecraft:moss_block
fill 238 154 358 238 155 358 minecraft:green_wool
fill 238 154 359 238 155 362 minecraft:moss_block
fill 238 154 363 238 155 363 minecraft:green_wool
fill 239 154 323 240 155 324 minecraft:moss_block
fill 239 154 325 239 155 325 minecraft:green_wool
fill 239 154 328 240 155 329 minecraft:moss_block
fill 239 154 330 239 155 330 minecraft:green_wool
fill 239 154 331 239 155 334 minecraft:moss_block
fill 239 154 335 239 155 335 minecraft:green_wool
fill 239 154 336 239 155 339 minecraft:moss_block
fill 239 154 340 239 155 340 minecraft:green_wool
fill 239 154 341 239 155 344 minecraft:moss_block
fill 239 154 345 239 155 345 minecraft:green_wool
fill 239 154 346 239 155 349 minecraft:moss_block
fill 239 154 350 239 155 350 minecraft:green_wool
fill 239 154 351 239 155 354 minecraft:moss_block
fill 239 154 355 239 155 355 minecraft:green_wool
fill 239 154 356 239 155 359 minecraft:moss_block
fill 239 154 360 239 155 360 minecraft:green_wool
fill 239 154 361 239 155 363 minecraft:moss_block
fill 240 154 325 241 155 326 minecraft:moss_block
fill 240 154 327 240 155 327 minecraft:green_wool
fill 240 154 330 241 155 331 minecraft:moss_block
fill 240 154 332 240 155 332 minecraft:green_wool
fill 240 154 333 240 155 336 minecraft:moss_block
fill 240 154 337 240 155 337 minecraft:green_wool
fill 240 154 338 240 155 341 minecraft:moss_block
fill 240 154 342 240 155 342 minecraft:green_wool
fill 240 154 343 240 155 346 minecraft:moss_block
fill 240 154 347 240 155 347 minecraft:green_wool
fill 240 154 348 240 155 351 minecraft:moss_block
fill 240 154 352 240 155 352 minecraft:green_wool
fill 240 154 353 240 155 356 minecraft:moss_block
fill 240 154 357 240 155 357 minecraft:green_wool
fill 240 154 358 240 155 361 minecraft:moss_block
fill 240 154 362 240 155 362 minecraft:green_wool
fill 240 154 363 242 155 363 minecraft:moss_block
fill 241 154 323 242 155 323 minecraft:moss_block
fill 241 154 324 241 155 324 minecraft:green_wool
fill 241 154 327 242 155 328 minecraft:moss_block
fill 241 154 329 241 155 329 minecraft:green_wool
fill 241 154 332 242 155 333 minecraft:moss_block
fill 241 154 334 241 155 334 minecraft:green_wool
fill 241 154 335 241 155 338 minecraft:moss_block
fill 241 154 339 241 155 339 minecraft:green_wool
fill 241 154 340 241 155 343 minecraft:moss_block
fill 241 154 344 241 155 344 minecraft:green_wool
fill 241 154 345 241 155 348 minecraft:moss_block
fill 241 154 349 241 155 349 minecraft:green_wool
fill 241 154 350 241 155 353 minecraft:moss_block
fill 241 154 354 241 155 354 minecraft:green_wool
fill 241 154 355 241 155 358 minecraft:moss_block
fill 241 154 359 241 155 359 minecraft:green_wool
fill 241 154 360 241 155 362 minecraft:moss_block
fill 242 154 324 243 155 325 minecraft:moss_block
fill 242 154 326 242 155 326 minecraft:green_wool
fill 242 154 329 243 155 330 minecraft:moss_block
fill 242 154 331 242 155 331 minecraft:green_wool
fill 242 154 334 243 155 335 minecraft:moss_block
fill 242 154 336 242 155 336 minecraft:green_wool
fill 242 154 337 242 155 340 minecraft:moss_block
fill 242 154 341 242 155 341 minecraft:green_wool
fill 242 154 342 242 155 345 minecraft:moss_block
fill 242 154 346 242 155 346 minecraft:green_wool
fill 242 154 347 242 155 350 minecraft:moss_block
fill 242 154 351 242 155 351 minecraft:green_wool
fill 242 154 352 242 155 355 minecraft:moss_block
fill 242 154 356 242 155 356 minecraft:green_wool
fill 242 154 357 242 155 360 minecraft:moss_block
fill 242 154 361 242 155 361 minecraft:green_wool
fill 242 154 362 244 155 362 minecraft:moss_block
fill 243 154 323 243 155 323 minecraft:green_wool
fill 243 154 326 244 155 327 minecraft:moss_block
fill 243 154 328 243 155 328 minecraft:green_wool
fill 243 154 331 244 155 332 minecraft:moss_block
fill 243 154 333 243 155 333 minecraft:green_wool
fill 243 154 336 244 155 337 minecraft:moss_block
fill 243 154 338 243 155 338 minecraft:green_wool
fill 243 154 339 243 155 342 minecraft:moss_block
fill 243 154 343 243 155 343 minecraft:green_wool
fill 243 154 344 243 155 347 minecraft:moss_block
fill 243 154 348 243 155 348 minecraft:green_wool
fill 243 154 349 243 155 352 minecraft:moss_block
fill 243 154 353 243 155 353 minecraft:green_wool
fill 243 154 354 243 155 357 minecraft:moss_block
fill 243 154 358 243 155 358 minecraft:green_wool
fill 243 154 359 243 155 361 minecraft:moss_block
fill 243 154 363 243 155 363 minecraft:green_wool
fill 244 154 323 245 155 324 minecraft:moss_block
fill 244 154 325 244 155 325 minecraft:green_wool
fill 244 154 328 245 155 329 minecraft:moss_block
fill 244 154 330 244 155 330 minecraft:green_wool
fill 244 154 333 245 155 334 minecraft:moss_block
fill 244 154 335 244 155 335 minecraft:green_wool
fill 244 154 338 245 155 339 minecraft:moss_block
fill 244 154 340 244 155 340 minecraft:green_wool
fill 244 154 341 244 155 344 minecraft:moss_block
fill 244 154 345 244 155 345 minecraft:green_wool
fill 244 154 346 244 155 349 minecraft:moss_block
fill 244 154 350 244 155 350 minecraft:green_wool
fill 244 154 351 244 155 354 minecraft:moss_block
fill 244 154 355 244 155 355 minecraft:green_wool
fill 244 154 356 244 155 359 minecraft:moss_block
fill 244 154 360 244 155 360 minecraft:green_wool
fill 244 154 361 246 155 361 minecraft:moss_block
fill 244 154 363 247 155 363 minecraft:moss_block
fill 245 154 325 246 155 326 minecraft:moss_block
fill 245 154 327 245 155 327 minecraft:green_wool
fill 245 154 330 246 155 331 minecraft:moss_block
fill 245 154 332 245 155 332 minecraft:green_wool
fill 245 154 335 246 155 336 minecraft:moss_block
fill 245 154 337 245 155 337 minecraft:green_wool
fill 245 154 340 246 155 341 minecraft:moss_block
fill 245 154 342 245 155 342 minecraft:green_wool
fill 245 154 343 245 154 346 minecraft:moss_block
setblock 245 154 347 minecraft:green_wool
fill 245 154 348 245 154 351 minecraft:moss_block
fill 245 154 352 245 155 352 minecraft:green_wool
fill 245 154 353 245 155 356 minecraft:moss_block
fill 245 154 357 245 155 357 minecraft:green_wool
fill 245 154 358 245 155 360 minecraft:moss_block
fill 245 154 362 245 155 362 minecraft:green_wool
fill 246 154 323 247 155 323 minecraft:moss_block
fill 246 154 324 246 155 324 minecraft:green_wool
fill 246 154 327 247 155 328 minecraft:moss_block
fill 246 154 329 246 155 329 minecraft:green_wool
fill 246 154 332 247 155 333 minecraft:moss_block
fill 246 154 334 246 155 334 minecraft:green_wool
fill 246 154 337 247 155 338 minecraft:moss_block
fill 246 154 339 246 155 339 minecraft:green_wool
fill 246 154 342 247 155 343 minecraft:moss_block
setblock 246 154 344 minecraft:green_wool
setblock 246 154 345 minecraft:moss_block
setblock 246 154 349 minecraft:green_wool
fill 246 154 350 246 154 353 minecraft:moss_block
fill 246 154 354 246 155 354 minecraft:green_wool
fill 246 154 355 246 155 358 minecraft:moss_block
fill 246 154 359 246 155 359 minecraft:green_wool
fill 246 154 360 248 155 360 minecraft:moss_block
fill 246 154 362 249 155 362 minecraft:moss_block
fill 247 154 324 248 155 325 minecraft:moss_block
fill 247 154 326 247 155 326 minecraft:green_wool
fill 247 154 329 248 155 330 minecraft:moss_block
fill 247 154 331 247 155 331 minecraft:green_wool
fill 247 154 334 248 155 335 minecraft:moss_block
fill 247 154 336 247 155 336 minecraft:green_wool
fill 247 154 339 248 155 340 minecraft:moss_block
fill 247 154 341 247 155 341 minecraft:green_wool
fill 247 154 344 250 154 344 minecraft:moss_block
fill 247 154 350 248 154 350 minecraft:moss_block
fill 247 154 351 247 155 351 minecraft:green_wool
fill 247 154 352 247 155 355 minecraft:moss_block
fill 247 154 356 247 155 356 minecraft:green_wool
fill 247 154 357 247 155 359 minecraft:moss_block
fill 247 154 361 247 155 361 minecraft:green_wool
fill 248 154 323 248 155 323 minecraft:green_wool
fill 248 154 326 249 155 327 minecraft:moss_block
fill 248 154 328 248 155 328 minecraft:green_wool
fill 248 154 331 249 155 332 minecraft:moss_block
fill 248 154 333 248 155 333 minecraft:green_wool
fill 248 154 336 249 155 337 minecraft:moss_block
fill 248 154 338 248 155 338 minecraft:green_wool
fill 248 154 341 249 155 342 minecraft:moss_block
fill 248 154 343 248 155 343 minecraft:green_wool
fill 248 154 351 249 155 352 minecraft:moss_block
fill 248 154 353 248 155 353 minecraft:green_wool
fill 248 154 354 248 155 357 minecraft:moss_block
fill 248 154 358 248 155 358 minecraft:green_wool
fill 248 154 359 250 155 359 minecraft:moss_block
fill 248 154 361 251 155 361 minecraft:moss_block
fill 248 154 363 248 155 363 minecraft:green_wool
fill 249 154 323 250 155 324 minecraft:moss_block
fill 249 154 325 249 155 325 minecraft:green_wool
fill 249 154 328 250 155 329 minecraft:moss_block
fill 249 154 330 249 155 330 minecraft:green_wool
fill 249 154 333 250 155 334 minecraft:moss_block
fill 249 154 335 249 155 335 minecraft:green_wool
fill 249 154 338 250 155 339 minecraft:moss_block
fill 249 154 340 249 155 340 minecraft:green_wool
fill 249 154 343 252 155 343 minecraft:moss_block
setblock 249 154 350 minecraft:green_wool
fill 249 154 353 250 155 354 minecraft:moss_block
fill 249 154 355 249 155 355 minecraft:green_wool
fill 249 154 356 249 155 358 minecraft:moss_block
fill 249 154 360 249 155 360 minecraft:green_wool
fill 249 154 363 252 155 363 minecraft:moss_block
fill 250 154 325 251 155 326 minecraft:moss_block
fill 250 154 327 250 155 327 minecraft:green_wool
fill 250 154 330 251 155 331 minecraft:moss_block
fill 250 154 332 250 155 332 minecraft:green_wool
fill 250 154 335 251 155 336 minecraft:moss_block
fill 250 154 337 250 155 337 minecraft:green_wool
fill 250 154 340 251 155 341 minecraft:moss_block
fill 250 154 342 250 155 342 minecraft:green_wool
fill 250 154 345 253 154 345 minecraft:moss_block
fill 250 154 349 250 154 351 minecraft:moss_block
fill 250 154 352 250 155 352 minecraft:green_wool
fill 250 154 355 251 155 356 minecraft:moss_block
fill 250 154 357 250 155 357 minecraft:green_wool
fill 250 154 358 252 155 358 minecraft:moss_block
fill 250 154 360 253 155 360 minecraft:moss_block
fill 250 154 362 250 155 362 minecraft:green_wool
fill 250 154 364 251 218 364 minecraft:green_terracotta
fill 251 154 323 252 155 323 minecraft:moss_block
fill 251 154 324 251 155 324 minecraft:green_wool
fill 251 154 327 252 155 328 minecraft:moss_block
fill 251 154 329 251 155 329 minecraft:green_wool
fill 251 154 332 252 155 333 minecraft:moss_block
fill 251 154 334 251 155 334 minecraft:green_wool
fill 251 154 337 252 155 338 minecraft:moss_block
fill 251 154 339 251 155 339 minecraft:green_wool
fill 251 154 342 254 155 342 minecraft:moss_block
fill 251 154 344 251 155 344 minecraft:green_wool
fill 251 154 346 251 154 348 minecraft:moss_block
setblock 251 154 349 minecraft:green_wool
fill 251 154 350 251 155 353 minecraft:moss_block
fill 251 154 354 251 155 354 minecraft:green_wool
fill 251 154 357 254 155 357 minecraft:moss_block
fill 251 154 359 251 155 359 minecraft:green_wool
fill 251 154 362 254 155 362 minecraft:moss_block
fill 252 154 324 253 155 325 minecraft:moss_block
fill 252 154 326 252 155 326 minecraft:green_wool
fill 252 154 329 253 155 330 minecraft:moss_block
fill 252 154 331 252 155 331 minecraft:green_wool
fill 252 154 334 253 155 335 minecraft:moss_block
fill 252 154 336 252 155 336 minecraft:green_wool
fill 252 154 339 253 155 340 minecraft:moss_block
fill 252 154 341 252 155 341 minecraft:green_wool
fill 252 154 344 255 155 344 minecraft:moss_block
fill 252 154 346 252 155 346 minecraft:green_wool
fill 252 154 347 252 155 350 minecraft:moss_block
fill 252 154 351 252 155 351 minecraft:green_wool
fill 252 154 352 252 155 355 minecraft:moss_block
fill 252 154 356 252 155 356 minecraft:green_wool
fill 252 154 359 255 155 359 minecraft:moss_block
fill 252 154 361 252 155 361 minecraft:green_wool
setblock 252 154 364 minecraft:red_mushroom_block
fill 253 154 323 253 155 323 minecraft:green_wool
fill 253 154 326 254 155 327 minecraft:moss_block
fill 253 154 328 253 155 328 minecraft:green_wool
fill 253 154 331 254 155 332 minecraft:moss_block
fill 253 154 333 253 155 333 minecraft:green_wool
fill 253 154 336 254 155 337 minecraft:moss_block
fill 253 154 338 253 155 338 minecraft:green_wool
fill 253 154 341 256 155 341 minecraft:moss_block
fill 253 154 343 253 155 343 minecraft:green_wool
fill 253 154 346 254 155 347 minecraft:moss_block
fill 253 154 348 253 155 348 minecraft:green_wool
fill 253 154 349 253 155 352 minecraft:moss_block
fill 253 154 353 253 155 353 minecraft:green_wool
fill 253 154 354 253 155 356 minecraft:moss_block
fill 253 154 358 253 155 358 minecraft:green_wool
fill 253 154 361 256 155 361 minecraft:moss_block
fill 253 154 363 253 155 363 minecraft:green_wool
fill 253 154 364 255 155 364 minecraft:green_terracotta
fill 254 154 323 255 155 324 minecraft:moss_block
fill 254 154 325 254 155 325 minecraft:green_wool
fill 254 154 328 255 155 329 minecraft:moss_block
fill 254 154 330 254 155 330 minecraft:green_wool
fill 254 154 333 255 155 334 minecraft:moss_block
fill 254 154 335 254 155 335 minecraft:green_wool
fill 254 154 338 255 155 339 minecraft:moss_block
fill 254 154 340 254 155 340 minecraft:green_wool
fill 254 154 343 257 155 343 minecraft:moss_block
fill 254 154 345 254 155 345 minecraft:green_wool
fill 254 154 348 255 155 349 minecraft:moss_block
fill 254 154 350 254 155 350 minecraft:green_wool
fill 254 154 351 254 155 354 minecraft:moss_block
fill 254 154 355 254 155 355 minecraft:green_wool
fill 254 154 356 256 155 356 minecraft:moss_block
fill 254 154 358 257 155 358 minecraft:moss_block
fill 254 154 360 254 155 360 minecraft:green_wool
fill 254 154 363 257 155 363 minecraft:moss_block
fill 255 154 325 256 155 326 minecraft:moss_block
fill 255 154 327 255 155 327 minecraft:green_wool
fill 255 154 330 256 155 331 minecraft:moss_block
fill 255 154 332 255 155 332 minecraft:green_wool
fill 255 154 335 256 155 336 minecraft:moss_block
fill 255 154 337 255 155 337 minecraft:green_wool
fill 255 154 340 258 155 340 minecraft:moss_block
fill 255 154 342 255 155 342 minecraft:green_wool
fill 255 154 345 256 155 346 minecraft:moss_block
fill 255 154 347 255 155 347 minecraft:green_wool
fill 255 154 350 256 155 351 minecraft:moss_block
fill 255 154 352 255 155 352 minecraft:green_wool
fill 255 154 353 255 155 355 minecraft:moss_block
fill 255 154 357 255 155 357 minecraft:green_wool
fill 255 154 360 258 155 360 minecraft:moss_block
fill 255 154 362 255 155 362 minecraft:green_wool
fill 256 154 323 257 155 323 minecraft:moss_block
fill 256 154 324 256 155 324 minecraft:green_wool
fill 256 154 327 257 155 328 minecraft:moss_block
fill 256 154 329 256 155 329 minecraft:green_wool
fill 256 154 332 257 155 333 minecraft:moss_block
fill 256 154 334 256 155 334 minecraft:green_wool
fill 256 154 337 257 155 338 minecraft:moss_block
fill 256 154 339 256 155 339 minecraft:green_wool
fill 256 154 342 259 155 342 minecraft:moss_block
fill 256 154 344 256 155 344 minecraft:green_wool
fill 256 154 347 257 155 348 minecraft:moss_block
fill 256 154 349 256 155 349 minecraft:green_wool
fill 256 154 352 257 155 353 minecraft:moss_block
fill 256 154 354 256 155 354 minecraft:green_wool
fill 256 154 355 258 155 355 minecraft:moss_block
fill 256 154 357 259 155 357 minecraft:moss_block
fill 256 154 359 256 155 359 minecraft:green_wool
fill 256 154 362 259 155 362 minecraft:moss_block
fill 257 154 324 258 155 325 minecraft:moss_block
fill 257 154 326 257 155 326 minecraft:green_wool
fill 257 154 329 258 155 330 minecraft:moss_block
fill 257 154 331 257 155 331 minecraft:green_wool
fill 257 154 334 258 155 335 minecraft:moss_block
fill 257 154 336 257 155 336 minecraft:green_wool
fill 257 154 339 260 155 339 minecraft:moss_block
fill 257 154 341 257 155 341 minecraft:green_wool
fill 257 154 344 258 155 345 minecraft:moss_block
fill 257 154 346 257 155 346 minecraft:green_wool
fill 257 154 349 258 155 350 minecraft:moss_block
fill 257 154 351 257 155 351 minecraft:green_wool
fill 257 154 354 260 155 354 minecraft:moss_block
fill 257 154 356 257 155 356 minecraft:green_wool
fill 257 154 359 260 155 359 minecraft:moss_block
fill 257 154 361 257 155 361 minecraft:green_wool
fill 258 154 323 258 155 323 minecraft:green_wool
fill 258 154 326 259 155 327 minecraft:moss_block
fill 258 154 328 258 155 328 minecraft:green_wool
fill 258 154 331 259 155 332 minecraft:moss_block
fill 258 154 333 258 155 333 minecraft:green_wool
fill 258 154 336 259 155 337 minecraft:moss_block
fill 258 154 338 258 155 338 minecraft:green_wool
fill 258 154 341 261 155 341 minecraft:moss_block
fill 258 154 343 258 155 343 minecraft:green_wool
fill 258 154 346 259 155 347 minecraft:moss_block
fill 258 154 348 258 155 348 minecraft:green_wool
fill 258 154 351 259 155 352 minecraft:moss_block
fill 258 154 353 258 155 353 minecraft:green_wool
fill 258 154 356 261 155 356 minecraft:moss_block
fill 258 154 358 258 155 358 minecraft:green_wool
fill 258 154 361 261 155 361 minecraft:moss_block
fill 258 154 363 258 155 363 minecraft:green_wool
fill 259 154 323 260 155 324 minecraft:moss_block
fill 259 154 325 259 155 325 minecraft:green_wool
fill 259 154 328 260 155 329 minecraft:moss_block
fill 259 154 330 259 155 330 minecraft:green_wool
fill 259 154 333 260 155 334 minecraft:moss_block
fill 259 154 335 259 155 335 minecraft:green_wool
fill 259 154 338 262 155 338 minecraft:moss_block
fill 259 154 340 259 155 340 minecraft:green_wool
fill 259 154 343 260 155 344 minecraft:moss_block
fill 259 154 345 259 155 345 minecraft:green_wool
fill 259 154 348 260 155 349 minecraft:moss_block
fill 259 154 350 259 155 350 minecraft:green_wool
fill 259 154 353 262 155 353 minecraft:moss_block
fill 259 154 355 259 155 355 minecraft:green_wool
fill 259 154 358 262 155 358 minecraft:moss_block
fill 259 154 360 259 155 360 minecraft:green_wool
fill 259 154 363 262 155 363 minecraft:moss_block
fill 260 154 325 261 155 326 minecraft:moss_block
fill 260 154 327 260 155 327 minecraft:green_wool
fill 260 154 330 261 155 331 minecraft:moss_block
fill 260 154 332 260 155 332 minecraft:green_wool
fill 260 154 335 261 155 336 minecraft:moss_block
fill 260 154 337 260 155 337 minecraft:green_wool
fill 260 154 340 263 155 340 minecraft:moss_block
fill 260 154 342 260 155 342 minecraft:green_wool
fill 260 154 345 261 155 346 minecraft:moss_block
fill 260 154 347 260 155 347 minecraft:green_wool
fill 260 154 350 261 155 351 minecraft:moss_block
fill 260 154 352 260 155 352 minecraft:green_wool
fill 260 154 355 263 155 355 minecraft:moss_block
fill 260 154 357 260 155 357 minecraft:green_wool
fill 260 154 360 263 155 360 minecraft:moss_block
fill 260 154 362 260 155 362 minecraft:green_wool
fill 261 154 323 262 155 323 minecraft:moss_block
fill 261 154 324 261 155 324 minecraft:green_wool
fill 261 154 327 262 155 328 minecraft:moss_block
fill 261 154 329 261 155 329 minecraft:green_wool
fill 261 154 332 262 155 333 minecraft:moss_block
fill 261 154 334 261 155 334 minecraft:green_wool
fill 261 154 337 264 155 337 minecraft:moss_block
fill 261 154 339 261 155 339 minecraft:green_wool
fill 261 154 342 262 155 343 minecraft:moss_block
fill 261 154 344 261 155 344 minecraft:green_wool
fill 261 154 347 262 155 348 minecraft:moss_block
fill 261 154 349 261 155 349 minecraft:green_wool
fill 261 154 352 264 155 352 minecraft:moss_block
fill 261 154 354 261 155 354 minecraft:green_wool
fill 261 154 357 264 155 357 minecraft:moss_block
fill 261 154 359 261 155 359 minecraft:green_wool
fill 261 154 362 264 155 362 minecraft:moss_block
fill 262 154 324 263 155 325 minecraft:moss_block
fill 262 154 326 262 155 326 minecraft:green_wool
fill 262 154 329 263 155 330 minecraft:moss_block
fill 262 154 331 262 155 331 minecraft:green_wool
fill 262 154 334 263 155 335 minecraft:moss_block
fill 262 154 336 262 155 336 minecraft:green_wool
fill 262 154 339 265 155 339 minecraft:moss_block
fill 262 154 341 262 155 341 minecraft:green_wool
fill 262 154 344 263 155 345 minecraft:moss_block
fill 262 154 346 262 155 346 minecraft:green_wool
fill 262 154 349 263 155 350 minecraft:moss_block
fill 262 154 351 262 155 351 minecraft:green_wool
fill 262 154 354 265 155 354 minecraft:moss_block
fill 262 154 356 262 155 356 minecraft:green_wool
fill 262 154 359 265 155 359 minecraft:moss_block
fill 262 154 361 262 155 361 minecraft:green_wool
fill 263 154 323 263 155 323 minecraft:green_wool
fill 263 154 326 264 155 327 minecraft:moss_block
fill 263 154 328 263 155 328 minecraft:green_wool
fill 263 154 331 264 155 332 minecraft:moss_block
fill 263 154 333 263 155 333 minecraft:green_wool
fill 263 154 336 266 155 336 minecraft:moss_block
fill 263 154 338 263 155 338 minecraft:green_wool
fill 263 154 341 264 155 342 minecraft:moss_block
fill 263 154 343 263 155 343 minecraft:green_wool
fill 263 154 346 264 155 347 minecraft:moss_block
fill 263 154 348 263 155 348 minecraft:green_wool
fill 263 154 351 266 155 351 minecraft:moss_block
fill 263 154 353 263 155 353 minecraft:green_wool
fill 263 154 356 266 155 356 minecraft:moss_block
fill 263 154 358 263 155 358 minecraft:green_wool
fill 263 154 361 266 155 361 minecraft:moss_block
fill 263 154 363 263 155 363 minecraft:green_wool
fill 264 154 323 265 155 324 minecraft:moss_block
fill 264 154 325 264 155 325 minecraft:green_wool
fill 264 154 328 265 155 329 minecraft:moss_block
fill 264 154 330 264 155 330 minecraft:green_wool
fill 264 154 333 265 155 334 minecraft:moss_block
fill 264 154 335 264 155 335 minecraft:green_wool
fill 264 154 338 267 155 338 minecraft:moss_block
fill 264 154 340 264 155 340 minecraft:green_wool
fill 264 154 343 265 155 344 minecraft:moss_block
fill 264 154 345 264 155 345 minecraft:green_wool
fill 264 154 348 265 155 349 minecraft:moss_block
fill 264 154 350 264 155 350 minecraft:green_wool
fill 264 154 353 267 155 353 minecraft:moss_block
fill 264 154 355 264 155 355 minecraft:green_wool
fill 264 154 358 267 155 358 minecraft:moss_block
fill 264 154 360 264 155 360 minecraft:green_wool
fill 264 154 363 267 155 363 minecraft:moss_block
fill 265 154 325 266 155 326 minecraft:moss_block
fill 265 154 327 265 155 327 minecraft:green_wool
fill 265 154 330 266 155 331 minecraft:moss_block
fill 265 154 332 265 155 332 minecraft:green_wool
fill 265 154 335 268 155 335 minecraft:moss_block
fill 265 154 337 265 155 337 minecraft:green_wool
fill 265 154 340 266 155 341 minecraft:moss_block
fill 265 154 342 265 155 342 minecraft:green_wool
fill 265 154 345 266 155 346 minecraft:moss_block
fill 265 154 347 265 155 347 minecraft:green_wool
fill 265 154 350 268 155 350 minecraft:moss_block
fill 265 154 352 265 155 352 minecraft:green_wool
fill 265 154 355 268 155 355 minecraft:moss_block
fill 265 154 357 265 155 357 minecraft:green_wool
fill 265 154 360 268 155 360 minecraft:moss_block
fill 265 154 362 265 155 362 minecraft:green_wool
fill 266 154 323 267 155 323 minecraft:moss_block
fill 266 154 324 266 155 324 minecraft:green_wool
fill 266 154 327 267 155 328 minecraft:moss_block
fill 266 154 329 266 155 329 minecraft:green_wool
fill 266 154 332 267 155 333 minecraft:moss_block
fill 266 154 334 266 155 334 minecraft:green_wool
fill 266 154 337 269 155 337 minecraft:moss_block
fill 266 154 339 266 155 339 minecraft:green_wool
fill 266 154 342 267 155 343 minecraft:moss_block
fill 266 154 344 266 155 344 minecraft:green_wool
fill 266 154 347 267 155 348 minecraft:moss_block
fill 266 154 349 266 155 349 minecraft:green_wool
fill 266 154 352 269 155 352 minecraft:moss_block
fill 266 154 354 266 155 354 minecraft:green_wool
fill 266 154 357 269 155 357 minecraft:moss_block
fill 266 154 359 266 155 359 minecraft:green_wool
fill 266 154 362 269 155 362 minecraft:moss_block
fill 267 154 324 268 155 325 minecraft:moss_block
fill 267 154 326 267 155 326 minecraft:green_wool
fill 267 154 329 268 155 330 minecraft:moss_block
fill 267 154 331 267 155 331 minecraft:green_wool
fill 267 154 334 270 155 334 minecraft:moss_block
fill 267 154 336 267 155 336 minecraft:green_wool
fill 267 154 339 268 155 340 minecraft:moss_block
fill 267 154 341 267 155 341 minecraft:green_wool
fill 267 154 344 268 155 345 minecraft:moss_block
fill 267 154 346 267 155 346 minecraft:green_wool
fill 267 154 349 270 155 349 minecraft:moss_block
fill 267 154 351 267 155 351 minecraft:green_wool
fill 267 154 354 270 155 354 minecraft:moss_block
fill 267 154 356 267 155 356 minecraft:green_wool
fill 267 154 359 270 155 359 minecraft:moss_block
fill 267 154 361 267 155 361 minecraft:green_wool
fill 267 154 364 267 229 364 minecraft:green_terracotta
fill 268 154 323 268 155 323 minecraft:green_wool
fill 268 154 326 269 155 327 minecraft:moss_block
fill 268 154 328 268 155 328 minecraft:green_wool
fill 268 154 331 269 155 332 minecraft:moss_block
fill 268 154 333 268 155 333 minecraft:green_wool
fill 268 154 336 271 155 336 minecraft:moss_block
fill 268 154 338 268 155 338 minecraft:green_wool
fill 268 154 341 269 155 342 minecraft:moss_block
fill 268 154 343 268 155 343 minecraft:green_wool
fill 268 154 346 269 155 347 minecraft:moss_block
fill 268 154 348 268 155 348 minecraft:green_wool
fill 268 154 351 271 155 351 minecraft:moss_block
fill 268 154 353 268 155 353 minecraft:green_wool
fill 268 154 356 271 155 356 minecraft:moss_block
fill 268 154 358 268 155 358 minecraft:green_wool
fill 268 154 361 271 155 361 minecraft:moss_block
fill 268 154 363 268 155 363 minecraft:green_wool
fill 269 154 323 270 155 324 minecraft:moss_block
fill 269 154 325 269 155 325 minecraft:green_wool
schedule function dropper:buildpart/77_4 1t
