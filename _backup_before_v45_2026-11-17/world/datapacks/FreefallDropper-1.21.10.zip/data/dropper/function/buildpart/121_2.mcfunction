fill 47 212 541 47 212 542 minecraft:crying_obsidian
fill 47 212 543 47 218 543 minecraft:polished_blackstone_bricks
fill 47 212 552 47 218 552 minecraft:polished_blackstone_bricks
fill 48 212 552 49 212 552 minecraft:crying_obsidian
fill 50 212 552 50 218 552 minecraft:polished_blackstone_bricks
fill 54 212 510 54 216 510 minecraft:polished_blackstone_bricks
fill 55 212 510 56 212 510 minecraft:crying_obsidian
fill 57 212 510 57 218 510 minecraft:polished_blackstone_bricks
fill 59 212 552 59 215 552 minecraft:polished_blackstone_bricks
fill 60 212 552 61 212 552 minecraft:crying_obsidian
fill 62 212 552 62 218 552 minecraft:polished_blackstone_bricks
fill 66 212 510 66 218 510 minecraft:polished_blackstone_bricks
fill 67 212 510 68 212 510 minecraft:crying_obsidian
fill 69 212 510 69 215 510 minecraft:polished_blackstone_bricks
fill 71 212 552 71 220 552 minecraft:polished_blackstone_bricks
fill 72 212 552 73 212 552 minecraft:crying_obsidian
fill 74 212 552 74 215 552 minecraft:polished_blackstone_bricks
fill 78 212 510 78 214 510 minecraft:polished_blackstone_bricks
fill 79 212 510 80 212 510 minecraft:crying_obsidian
fill 81 212 510 81 219 510 minecraft:polished_blackstone_bricks
fill 83 212 536 83 213 536 minecraft:polished_blackstone_bricks
fill 83 212 538 83 213 538 minecraft:polished_blackstone_bricks
fill 83 212 540 83 213 540 minecraft:polished_blackstone_bricks
fill 83 212 542 83 213 542 minecraft:polished_blackstone_bricks
fill 83 212 544 83 213 544 minecraft:polished_blackstone_bricks
fill 83 212 552 83 218 552 minecraft:polished_blackstone_bricks
fill 84 212 537 84 213 537 minecraft:polished_blackstone_bricks
fill 84 212 539 84 213 539 minecraft:polished_blackstone_bricks
fill 84 212 541 84 213 541 minecraft:polished_blackstone_bricks
fill 84 212 543 84 213 543 minecraft:polished_blackstone_bricks
fill 84 212 552 85 212 552 minecraft:crying_obsidian
fill 85 212 536 85 213 536 minecraft:polished_blackstone_bricks
fill 85 212 538 85 213 538 minecraft:polished_blackstone_bricks
fill 85 212 540 85 213 540 minecraft:polished_blackstone_bricks
fill 85 212 542 85 213 542 minecraft:polished_blackstone_bricks
fill 85 212 544 85 213 544 minecraft:polished_blackstone_bricks
fill 86 212 537 86 213 537 minecraft:polished_blackstone_bricks
fill 86 212 539 86 213 539 minecraft:polished_blackstone_bricks
fill 86 212 541 86 213 541 minecraft:polished_blackstone_bricks
fill 86 212 543 86 213 543 minecraft:polished_blackstone_bricks
fill 86 212 552 86 218 552 minecraft:polished_blackstone_bricks
fill 87 212 536 87 213 536 minecraft:polished_blackstone_bricks
fill 87 212 538 87 213 538 minecraft:polished_blackstone_bricks
fill 87 212 540 87 213 540 minecraft:polished_blackstone_bricks
fill 87 212 542 87 213 542 minecraft:polished_blackstone_bricks
fill 87 212 544 87 213 544 minecraft:polished_blackstone_bricks
fill 88 212 537 88 213 537 minecraft:polished_blackstone_bricks
fill 88 212 539 88 213 539 minecraft:polished_blackstone_bricks
fill 88 212 541 88 213 541 minecraft:polished_blackstone_bricks
fill 88 212 543 88 232 543 minecraft:polished_blackstone_bricks
fill 89 212 511 89 218 511 minecraft:polished_blackstone_bricks
fill 89 212 512 89 212 513 minecraft:crying_obsidian
fill 89 212 514 89 218 514 minecraft:polished_blackstone_bricks
fill 89 212 523 89 218 523 minecraft:polished_blackstone_bricks
fill 89 212 524 89 212 525 minecraft:crying_obsidian
fill 89 212 526 89 218 526 minecraft:polished_blackstone_bricks
fill 89 212 535 89 216 535 minecraft:polished_blackstone_bricks
fill 89 212 536 89 212 537 minecraft:crying_obsidian
fill 89 212 538 89 218 538 minecraft:polished_blackstone_bricks
fill 89 212 547 89 214 547 minecraft:polished_blackstone_bricks
fill 89 212 548 89 212 549 minecraft:crying_obsidian
fill 89 212 550 89 215 550 minecraft:polished_blackstone_bricks
fill 47 213 517 47 214 518 minecraft:polished_blackstone_bricks
fill 47 213 529 47 218 530 minecraft:polished_blackstone_bricks
fill 47 213 541 47 218 542 minecraft:polished_blackstone_bricks
fill 48 213 552 49 218 552 minecraft:polished_blackstone_bricks
fill 55 213 510 56 215 510 minecraft:polished_blackstone_bricks
fill 60 213 552 61 218 552 minecraft:polished_blackstone_bricks
fill 67 213 510 68 216 510 minecraft:polished_blackstone_bricks
fill 72 213 552 73 214 552 minecraft:polished_blackstone_bricks
fill 79 213 510 80 215 510 minecraft:polished_blackstone_bricks
fill 84 213 552 85 214 552 minecraft:polished_blackstone_bricks
fill 89 213 512 89 218 513 minecraft:polished_blackstone_bricks
fill 89 213 524 89 218 525 minecraft:polished_blackstone_bricks
fill 89 213 536 89 218 537 minecraft:polished_blackstone_bricks
fill 89 213 548 89 214 549 minecraft:polished_blackstone_bricks
fill 84 214 537 87 214 543 minecraft:purple_stained_glass
setblock 47 215 512 minecraft:blackstone
fill 47 215 513 47 218 513 minecraft:polished_blackstone_bricks
setblock 47 215 514 minecraft:blackstone
fill 47 215 515 47 218 515 minecraft:polished_blackstone_bricks
setblock 47 215 517 minecraft:blackstone
fill 47 215 518 47 218 518 minecraft:polished_blackstone_bricks
setblock 47 215 519 minecraft:blackstone
setblock 47 215 532 minecraft:blackstone
fill 47 215 546 47 215 550 minecraft:polished_blackstone_bricks
setblock 47 215 551 minecraft:blackstone
fill 52 215 552 52 219 552 minecraft:polished_blackstone_bricks
setblock 53 215 552 minecraft:blackstone
setblock 65 215 552 minecraft:blackstone
fill 66 215 552 66 218 552 minecraft:polished_blackstone_bricks
setblock 67 215 552 minecraft:blackstone
fill 68 215 552 70 216 552 minecraft:polished_blackstone_bricks
fill 72 215 552 72 218 552 minecraft:polished_blackstone_bricks
fill 73 215 552 73 216 552 minecraft:blackstone
setblock 75 215 510 minecraft:blackstone
setblock 76 215 510 minecraft:polished_blackstone_bricks
setblock 76 215 552 minecraft:polished_blackstone_bricks
setblock 77 215 552 minecraft:blackstone
setblock 78 215 510 minecraft:blackstone
setblock 84 215 552 minecraft:blackstone
fill 85 215 538 86 215 542 minecraft:purple_stained_glass
setblock 85 215 552 minecraft:polished_blackstone_bricks
fill 89 215 520 89 218 520 minecraft:polished_blackstone_bricks
setblock 89 215 521 minecraft:blackstone
fill 89 215 522 89 218 522 minecraft:polished_blackstone_bricks
fill 89 215 527 89 215 528 minecraft:blackstone
fill 89 215 544 89 215 545 minecraft:blackstone
fill 89 215 546 89 218 546 minecraft:polished_blackstone_bricks
setblock 89 215 547 minecraft:blackstone
fill 89 215 548 89 218 548 minecraft:polished_blackstone_bricks
setblock 89 215 549 minecraft:blackstone
setblock 47 216 510 minecraft:blackstone
fill 47 216 511 47 218 512 minecraft:polished_blackstone_bricks
setblock 47 216 514 minecraft:polished_blackstone_bricks
fill 47 216 517 47 219 517 minecraft:polished_blackstone_bricks
fill 47 216 519 47 220 519 minecraft:polished_blackstone_bricks
setblock 47 216 532 minecraft:polished_blackstone_bricks
fill 47 216 534 47 217 534 minecraft:blackstone
fill 47 216 535 47 218 536 minecraft:polished_blackstone_bricks
setblock 47 216 537 minecraft:blackstone
fill 47 216 538 47 218 539 minecraft:polished_blackstone_bricks
fill 47 216 546 47 216 547 minecraft:polished_blackstone_bricks
fill 47 216 548 47 216 549 minecraft:blackstone
fill 47 216 550 47 216 551 minecraft:polished_blackstone_bricks
fill 53 216 552 53 218 552 minecraft:polished_blackstone_bricks
fill 55 216 510 55 218 510 minecraft:polished_blackstone_bricks
setblock 56 216 510 minecraft:blackstone
fill 58 216 510 58 219 510 minecraft:polished_blackstone_bricks
setblock 59 216 510 minecraft:blackstone
setblock 59 216 552 minecraft:blackstone
fill 60 216 510 60 218 510 minecraft:polished_blackstone_bricks
fill 61 216 510 62 216 510 minecraft:blackstone
fill 63 216 510 63 218 510 minecraft:polished_blackstone_bricks
setblock 63 216 552 minecraft:blackstone
setblock 64 216 510 minecraft:blackstone
fill 65 216 510 65 218 510 minecraft:polished_blackstone_bricks
fill 65 216 552 65 218 552 minecraft:polished_blackstone_bricks
fill 67 216 552 67 218 552 minecraft:polished_blackstone_bricks
setblock 69 216 510 minecraft:blackstone
setblock 74 216 552 minecraft:blackstone
fill 75 216 510 75 218 510 minecraft:polished_blackstone_bricks
setblock 76 216 510 minecraft:blackstone
setblock 76 216 552 minecraft:blackstone
fill 77 216 552 77 218 552 minecraft:polished_blackstone_bricks
fill 78 216 510 79 216 510 minecraft:polished_blackstone_bricks
setblock 80 216 510 minecraft:blackstone
fill 82 216 515 82 216 517 minecraft:blackstone
fill 83 216 514 85 216 514 minecraft:blackstone
fill 83 216 518 85 216 518 minecraft:blackstone
setblock 84 216 552 minecraft:polished_blackstone_bricks
fill 85 216 539 86 216 541 minecraft:purple_stained_glass
setblock 85 216 552 minecraft:blackstone
fill 86 216 515 86 216 517 minecraft:blackstone
fill 89 216 521 89 218 521 minecraft:polished_blackstone_bricks
fill 89 216 527 89 218 528 minecraft:polished_blackstone_bricks
setblock 89 216 540 minecraft:blackstone
fill 89 216 544 89 216 545 minecraft:polished_blackstone_bricks
setblock 89 216 547 minecraft:polished_blackstone_bricks
fill 89 216 549 89 218 549 minecraft:polished_blackstone_bricks
fill 89 216 550 89 216 551 minecraft:blackstone
fill 47 217 510 47 218 510 minecraft:polished_blackstone_bricks
setblock 47 217 514 minecraft:blackstone
setblock 47 217 526 minecraft:blackstone
setblock 47 217 532 minecraft:blackstone
fill 47 217 537 47 218 537 minecraft:polished_blackstone_bricks
setblock 47 217 540 minecraft:blackstone
fill 47 217 546 47 218 546 minecraft:polished_blackstone_bricks
fill 47 217 547 47 217 548 minecraft:blackstone
fill 47 217 549 47 218 550 minecraft:polished_blackstone_bricks
setblock 47 217 551 minecraft:blackstone
setblock 50 217 510 minecraft:blackstone
setblock 54 217 510 minecraft:blackstone
setblock 55 217 552 minecraft:blackstone
fill 56 217 510 56 218 510 minecraft:polished_blackstone_bricks
fill 59 217 510 59 218 510 minecraft:polished_blackstone_bricks
fill 59 217 552 59 218 552 minecraft:polished_blackstone_bricks
fill 61 217 510 62 218 510 minecraft:polished_blackstone_bricks
fill 63 217 552 63 219 552 minecraft:polished_blackstone_bricks
fill 64 217 510 64 219 510 minecraft:polished_blackstone_bricks
fill 67 217 510 67 218 510 minecraft:polished_blackstone_bricks
setblock 68 217 510 minecraft:blackstone
setblock 68 217 552 minecraft:blackstone
fill 69 217 510 69 218 510 minecraft:polished_blackstone_bricks
fill 69 217 552 70 218 552 minecraft:polished_blackstone_bricks
setblock 70 217 510 minecraft:blackstone
fill 71 217 510 74 218 510 minecraft:polished_blackstone_bricks
fill 73 217 552 74 218 552 minecraft:polished_blackstone_bricks
fill 76 217 510 76 218 510 minecraft:polished_blackstone_bricks
fill 76 217 552 76 218 552 minecraft:polished_blackstone_bricks
setblock 77 217 510 minecraft:blackstone
fill 78 217 510 78 218 510 minecraft:polished_blackstone_bricks
setblock 79 217 510 minecraft:blackstone
fill 80 217 510 80 218 510 minecraft:polished_blackstone_bricks
fill 84 217 540 87 217 540 minecraft:purple_stained_glass
setblock 84 217 552 minecraft:blackstone
fill 85 217 552 85 218 552 minecraft:polished_blackstone_bricks
fill 88 217 552 88 218 552 minecraft:polished_blackstone_bricks
setblock 89 217 517 minecraft:blackstone
setblock 89 217 529 minecraft:blackstone
fill 89 217 531 89 218 531 minecraft:polished_blackstone_bricks
setblock 89 217 532 minecraft:blackstone
fill 89 217 533 89 218 533 minecraft:polished_blackstone_bricks
setblock 89 217 535 minecraft:blackstone
fill 89 217 540 89 218 540 minecraft:polished_blackstone_bricks
fill 89 217 544 89 218 544 minecraft:polished_blackstone_bricks
setblock 89 217 545 minecraft:blackstone
setblock 89 217 547 minecraft:blackstone
fill 89 217 550 89 218 551 minecraft:polished_blackstone_bricks
setblock 89 217 552 minecraft:blackstone
setblock 47 218 514 minecraft:polished_blackstone_bricks
setblock 47 218 526 minecraft:polished_blackstone_bricks
setblock 47 218 532 minecraft:polished_blackstone_bricks
setblock 47 218 534 minecraft:polished_blackstone_bricks
setblock 47 218 540 minecraft:polished_blackstone_bricks
fill 47 218 547 47 218 548 minecraft:polished_blackstone_bricks
setblock 47 218 551 minecraft:polished_blackstone_bricks
setblock 50 218 510 minecraft:polished_blackstone_bricks
setblock 50 218 513 minecraft:light[level=11]
setblock 50 218 521 minecraft:light[level=11]
setblock 50 218 529 minecraft:light[level=11]
setblock 50 218 537 minecraft:light[level=11]
setblock 50 218 545 minecraft:light[level=11]
setblock 54 218 510 minecraft:polished_blackstone_bricks
setblock 55 218 552 minecraft:polished_blackstone_bricks
setblock 58 218 513 minecraft:light[level=11]
setblock 58 218 521 minecraft:light[level=11]
setblock 58 218 529 minecraft:light[level=11]
setblock 58 218 537 minecraft:light[level=11]
setblock 58 218 545 minecraft:light[level=11]
setblock 66 218 513 minecraft:light[level=11]
setblock 66 218 521 minecraft:light[level=11]
setblock 66 218 529 minecraft:light[level=11]
setblock 66 218 537 minecraft:light[level=11]
setblock 66 218 545 minecraft:light[level=11]
setblock 68 218 510 minecraft:polished_blackstone_bricks
setblock 68 218 552 minecraft:polished_blackstone_bricks
setblock 70 218 510 minecraft:polished_blackstone_bricks
setblock 74 218 513 minecraft:light[level=11]
setblock 74 218 521 minecraft:light[level=11]
setblock 74 218 529 minecraft:light[level=11]
setblock 74 218 537 minecraft:light[level=11]
setblock 74 218 545 minecraft:light[level=11]
fill 77 218 510 77 219 510 minecraft:polished_blackstone_bricks
setblock 79 218 510 minecraft:polished_blackstone_bricks
fill 81 218 549 81 231 549 minecraft:purple_wool
setblock 82 218 513 minecraft:light[level=11]
setblock 82 218 521 minecraft:light[level=11]
setblock 82 218 529 minecraft:light[level=11]
setblock 82 218 537 minecraft:light[level=11]
setblock 82 218 545 minecraft:light[level=11]
setblock 84 218 552 minecraft:polished_blackstone_bricks
fill 89 218 517 89 219 517 minecraft:polished_blackstone_bricks
setblock 89 218 529 minecraft:polished_blackstone_bricks
setblock 89 218 532 minecraft:polished_blackstone_bricks
setblock 89 218 535 minecraft:polished_blackstone_bricks
setblock 89 218 545 minecraft:polished_blackstone_bricks
setblock 89 218 547 minecraft:polished_blackstone_bricks
setblock 89 218 552 minecraft:polished_blackstone_bricks
fill 47 219 510 47 219 516 minecraft:blackstone
fill 47 219 518 47 225 518 minecraft:blackstone
fill 47 219 520 47 307 522 minecraft:blackstone
fill 47 219 524 47 307 526 minecraft:blackstone
fill 47 219 528 47 219 540 minecraft:blackstone
setblock 47 219 541 minecraft:polished_blackstone_bricks
fill 47 219 542 47 219 552 minecraft:blackstone
fill 48 219 510 57 219 510 minecraft:blackstone
fill 48 219 552 51 225 552 minecraft:blackstone
fill 53 219 552 59 219 552 minecraft:blackstone
fill 59 219 510 63 307 510 minecraft:blackstone
fill 60 219 552 60 221 552 minecraft:polished_blackstone_bricks
fill 61 219 552 62 225 552 minecraft:blackstone
fill 64 219 552 70 219 552 minecraft:blackstone
fill 65 219 510 76 219 510 minecraft:blackstone
fill 72 219 552 73 225 552 minecraft:blackstone
setblock 74 219 552 minecraft:polished_blackstone_bricks
fill 75 219 552 78 219 552 minecraft:blackstone
fill 78 219 510 80 220 510 minecraft:blackstone
fill 79 219 549 80 231 549 minecraft:purple_wool
setblock 79 219 552 minecraft:polished_blackstone_bricks
fill 80 219 552 80 307 552 minecraft:blackstone
setblock 81 219 552 minecraft:polished_blackstone_bricks
fill 82 219 510 89 307 510 minecraft:blackstone
fill 82 219 549 83 231 549 minecraft:purple_wool
fill 82 219 552 89 225 552 minecraft:blackstone
setblock 89 219 511 minecraft:blackstone
setblock 89 219 512 minecraft:polished_blackstone_bricks
fill 89 219 513 89 225 516 minecraft:blackstone
fill 89 219 518 89 219 542 minecraft:blackstone
fill 89 219 544 89 225 549 minecraft:blackstone
fill 89 219 550 89 220 550 minecraft:polished_blackstone_bricks
fill 89 219 551 89 307 551 minecraft:blackstone
fill 47 220 510 47 307 513 minecraft:blackstone
setblock 47 220 514 minecraft:polished_blackstone_bricks
fill 47 220 515 47 225 517 minecraft:blackstone
fill 47 220 523 47 307 523 minecraft:blackstone
fill 47 220 527 47 225 534 minecraft:blackstone
setblock 47 220 535 minecraft:polished_blackstone_bricks
fill 47 220 536 47 307 539 minecraft:blackstone
setblock 47 220 540 minecraft:polished_blackstone_bricks
fill 47 220 541 47 220 551 minecraft:blackstone
setblock 47 220 552 minecraft:polished_blackstone_bricks
fill 48 220 510 53 220 510 minecraft:blackstone
fill 49 220 520 49 225 522 minecraft:polished_blackstone_bricks
fill 49 220 532 49 225 534 minecraft:polished_blackstone_bricks
fill 49 220 544 49 225 546 minecraft:polished_blackstone_bricks
fill 52 220 552 57 307 552 minecraft:blackstone
setblock 54 220 510 minecraft:polished_blackstone_bricks
fill 55 220 510 58 225 510 minecraft:blackstone
fill 55 220 550 57 225 550 minecraft:polished_blackstone_bricks
setblock 58 220 552 minecraft:polished_blackstone_bricks
fill 59 220 512 61 225 512 minecraft:polished_blackstone_bricks
fill 59 220 552 59 225 552 minecraft:blackstone
fill 63 220 552 68 220 552 minecraft:blackstone
fill 64 220 510 72 225 510 minecraft:blackstone
fill 67 220 550 69 225 550 minecraft:polished_blackstone_bricks
setblock 69 220 552 minecraft:polished_blackstone_bricks
fill 70 220 552 70 307 552 minecraft:blackstone
fill 71 220 512 73 226 512 minecraft:polished_blackstone_bricks
setblock 73 220 510 minecraft:polished_blackstone_bricks
fill 74 220 510 77 220 510 minecraft:blackstone
fill 74 220 552 74 225 552 minecraft:blackstone
setblock 75 220 552 minecraft:polished_blackstone_bricks
fill 76 220 552 79 307 552 minecraft:blackstone
fill 79 220 550 81 225 550 minecraft:polished_blackstone_bricks
fill 81 220 510 81 225 510 minecraft:blackstone
fill 81 220 552 81 307 552 minecraft:blackstone
fill 83 220 512 85 225 512 minecraft:polished_blackstone_bricks
fill 87 220 520 87 225 522 minecraft:polished_blackstone_bricks
fill 87 220 532 87 225 534 minecraft:polished_blackstone_bricks
fill 87 220 544 87 225 546 minecraft:polished_blackstone_bricks
setblock 89 220 511 minecraft:polished_blackstone_bricks
fill 89 220 512 89 225 512 minecraft:blackstone
fill 89 220 517 89 220 525 minecraft:blackstone
setblock 89 220 526 minecraft:polished_blackstone_bricks
fill 89 220 527 89 225 536 minecraft:blackstone
setblock 89 220 537 minecraft:polished_blackstone_bricks
fill 89 220 538 89 225 543 minecraft:blackstone
fill 47 221 514 47 307 514 minecraft:blackstone
fill 47 221 519 47 225 519 minecraft:blackstone
fill 47 221 535 47 307 535 minecraft:blackstone
fill 47 221 540 47 225 543 minecraft:blackstone
setblock 47 221 544 minecraft:polished_blackstone_bricks
fill 47 221 545 47 307 546 minecraft:blackstone
setblock 47 221 547 minecraft:polished_blackstone_bricks
fill 47 221 548 47 307 550 minecraft:blackstone
setblock 47 221 551 minecraft:polished_blackstone_bricks
fill 47 221 552 47 225 552 minecraft:blackstone
fill 48 221 510 52 307 510 minecraft:blackstone
setblock 53 221 510 minecraft:polished_blackstone_bricks
fill 54 221 510 54 225 510 minecraft:blackstone
fill 58 221 552 58 307 552 minecraft:blackstone
setblock 63 221 552 minecraft:polished_blackstone_bricks
fill 64 221 552 69 307 552 minecraft:blackstone
fill 71 221 552 71 225 552 minecraft:blackstone
fill 73 221 510 76 307 510 minecraft:blackstone
fill 75 221 552 75 307 552 minecraft:blackstone
fill 77 221 510 79 221 510 minecraft:polished_blackstone_bricks
fill 80 221 510 80 225 510 minecraft:blackstone
fill 89 221 511 89 225 511 minecraft:blackstone
fill 89 221 517 89 307 520 minecraft:blackstone
setblock 89 221 521 minecraft:polished_blackstone_bricks
fill 89 221 522 89 225 526 minecraft:blackstone
fill 89 221 537 89 225 537 minecraft:blackstone
fill 89 221 550 89 225 550 minecraft:blackstone
fill 47 222 544 47 307 544 minecraft:blackstone
fill 47 222 547 47 307 547 minecraft:blackstone
fill 47 222 551 47 307 551 minecraft:blackstone
fill 53 222 510 53 307 510 minecraft:blackstone
fill 60 222 552 60 225 552 minecraft:blackstone
fill 63 222 552 63 307 552 minecraft:blackstone
fill 77 222 510 79 225 510 minecraft:blackstone
fill 86 222 529 86 223 535 minecraft:iron_bars
fill 89 222 521 89 307 521 minecraft:blackstone
fill 71 224 511 71 225 511 minecraft:polished_blackstone_bricks
fill 71 224 550 73 224 551 minecraft:polished_blackstone_bricks
fill 82 224 515 82 224 517 minecraft:blackstone
fill 83 224 514 85 224 514 minecraft:blackstone
fill 83 224 518 85 224 518 minecraft:blackstone
fill 86 224 515 86 224 517 minecraft:blackstone
fill 48 225 514 48 225 519 minecraft:blackstone
fill 48 225 526 48 225 531 minecraft:blackstone
fill 48 225 538 48 225 543 minecraft:blackstone
fill 48 225 550 48 225 551 minecraft:blackstone
fill 49 225 551 52 225 551 minecraft:blackstone
fill 52 225 511 57 225 511 minecraft:blackstone
fill 59 225 551 64 225 551 minecraft:blackstone
fill 64 225 511 69 225 511 minecraft:blackstone
fill 71 225 549 73 225 550 minecraft:polished_blackstone_bricks
fill 71 225 551 76 225 551 minecraft:blackstone
fill 72 225 513 72 228 513 minecraft:polished_blackstone_bricks
fill 72 225 548 72 228 548 minecraft:polished_blackstone_bricks
fill 76 225 511 81 225 511 minecraft:blackstone
fill 83 225 551 88 225 551 minecraft:blackstone
fill 88 225 511 88 225 516 minecraft:blackstone
fill 88 225 523 88 225 528 minecraft:blackstone
fill 88 225 535 88 225 540 minecraft:blackstone
fill 88 225 547 88 225 550 minecraft:blackstone
fill 47 226 515 47 307 515 minecraft:blackstone
fill 47 226 516 47 231 519 minecraft:crying_obsidian
fill 47 226 527 47 307 527 minecraft:blackstone
fill 47 226 528 47 231 531 minecraft:crying_obsidian
fill 47 226 532 47 307 534 minecraft:blackstone
fill 47 226 540 47 231 543 minecraft:crying_obsidian
fill 47 226 552 50 231 552 minecraft:crying_obsidian
setblock 50 226 513 minecraft:light[level=11]
setblock 50 226 521 minecraft:light[level=11]
setblock 50 226 529 minecraft:light[level=11]
setblock 50 226 537 minecraft:light[level=11]
setblock 50 226 545 minecraft:light[level=11]
fill 51 226 552 51 307 552 minecraft:blackstone
fill 54 226 510 57 231 510 minecraft:crying_obsidian
fill 58 226 510 58 307 510 minecraft:blackstone
setblock 58 226 513 minecraft:light[level=11]
setblock 58 226 521 minecraft:light[level=11]
setblock 58 226 529 minecraft:light[level=11]
setblock 58 226 537 minecraft:light[level=11]
setblock 58 226 545 minecraft:light[level=11]
fill 59 226 552 62 231 552 minecraft:crying_obsidian
fill 64 226 510 65 307 510 minecraft:blackstone
fill 66 226 510 69 231 510 minecraft:crying_obsidian
setblock 66 226 513 minecraft:light[level=11]
setblock 66 226 521 minecraft:light[level=11]
setblock 66 226 529 minecraft:light[level=11]
setblock 66 226 537 minecraft:light[level=11]
setblock 66 226 545 minecraft:light[level=11]
fill 70 226 510 72 307 510 minecraft:blackstone
fill 71 226 513 71 227 513 minecraft:polished_blackstone_bricks
fill 71 226 548 71 226 549 minecraft:polished_blackstone_bricks
fill 71 226 552 74 231 552 minecraft:crying_obsidian
fill 72 226 514 72 228 514 minecraft:polished_blackstone_bricks
fill 72 226 547 72 228 547 minecraft:polished_blackstone_bricks
fill 72 226 549 72 226 550 minecraft:polished_blackstone_bricks
setblock 72 226 551 minecraft:purple_stained_glass
fill 73 226 513 73 227 513 minecraft:polished_blackstone_bricks
fill 73 226 548 73 226 549 minecraft:polished_blackstone_bricks
setblock 74 226 513 minecraft:light[level=11]
setblock 74 226 521 minecraft:light[level=11]
setblock 74 226 529 minecraft:light[level=11]
setblock 74 226 537 minecraft:light[level=11]
setblock 74 226 545 minecraft:light[level=11]
fill 77 226 510 77 307 510 minecraft:blackstone
fill 78 226 510 81 231 510 minecraft:crying_obsidian
setblock 82 226 513 minecraft:light[level=11]
setblock 82 226 521 minecraft:light[level=11]
setblock 82 226 529 minecraft:light[level=11]
setblock 82 226 537 minecraft:light[level=11]
setblock 82 226 545 minecraft:light[level=11]
fill 82 226 552 82 307 552 minecraft:blackstone
fill 83 226 552 86 231 552 minecraft:crying_obsidian
fill 87 226 552 89 307 552 minecraft:blackstone
fill 89 226 511 89 231 514 minecraft:crying_obsidian
fill 89 226 515 89 307 516 minecraft:blackstone
fill 89 226 522 89 307 522 minecraft:blackstone
fill 89 226 523 89 231 526 minecraft:crying_obsidian
fill 89 226 527 89 307 534 minecraft:blackstone
fill 89 226 535 89 231 538 minecraft:crying_obsidian
fill 89 226 539 89 307 546 minecraft:blackstone
fill 89 226 547 89 231 550 minecraft:crying_obsidian
fill 71 227 514 71 228 515 minecraft:polished_blackstone_bricks
fill 71 227 546 71 227 548 minecraft:polished_blackstone_bricks
setblock 72 227 512 minecraft:polished_blackstone_bricks
fill 72 227 515 73 228 515 minecraft:polished_blackstone_bricks
fill 72 227 546 73 228 546 minecraft:polished_blackstone_bricks
setblock 72 227 549 minecraft:polished_blackstone_bricks
setblock 72 227 550 minecraft:purple_stained_glass
fill 73 227 514 73 228 514 minecraft:polished_blackstone_bricks
fill 73 227 547 73 227 548 minecraft:polished_blackstone_bricks
fill 71 228 516 73 229 516 minecraft:polished_blackstone_bricks
fill 71 228 545 71 228 547 minecraft:polished_blackstone_bricks
setblock 72 228 512 minecraft:purple_stained_glass
fill 72 228 517 72 230 517 minecraft:polished_blackstone_bricks
fill 72 228 544 72 230 545 minecraft:polished_blackstone_bricks
setblock 72 228 549 minecraft:purple_stained_glass
fill 73 228 545 73 229 545 minecraft:polished_blackstone_bricks
setblock 73 228 547 minecraft:polished_blackstone_bricks
fill 71 229 517 71 230 517 minecraft:polished_blackstone_bricks
fill 71 229 544 71 229 545 minecraft:polished_blackstone_bricks
setblock 72 229 514 minecraft:purple_stained_glass
setblock 72 229 515 minecraft:polished_blackstone_bricks
fill 72 229 518 72 231 518 minecraft:polished_blackstone_bricks
fill 72 229 543 72 231 543 minecraft:polished_blackstone_bricks
setblock 72 229 546 minecraft:polished_blackstone_bricks
setblock 72 229 547 minecraft:purple_stained_glass
fill 73 229 517 73 230 517 minecraft:polished_blackstone_bricks
fill 73 229 544 73 230 544 minecraft:polished_blackstone_bricks
fill 71 230 518 71 230 519 minecraft:polished_blackstone_bricks
fill 71 230 542 71 230 544 minecraft:polished_blackstone_bricks
setblock 72 230 515 minecraft:purple_stained_glass
setblock 72 230 516 minecraft:polished_blackstone_bricks
fill 72 230 519 72 232 520 minecraft:polished_blackstone_bricks
fill 72 230 541 72 232 542 minecraft:polished_blackstone_bricks
setblock 72 230 546 minecraft:purple_stained_glass
fill 73 230 518 73 230 519 minecraft:polished_blackstone_bricks
fill 73 230 542 73 230 543 minecraft:polished_blackstone_bricks
fill 71 231 519 71 231 521 minecraft:polished_blackstone_bricks
fill 71 231 540 71 231 542 minecraft:polished_blackstone_bricks
setblock 72 231 517 minecraft:purple_stained_glass
fill 72 231 521 72 232 522 minecraft:polished_blackstone_bricks
fill 72 231 539 72 232 540 minecraft:polished_blackstone_bricks
setblock 72 231 544 minecraft:purple_stained_glass
fill 73 231 519 73 231 521 minecraft:polished_blackstone_bricks
fill 73 231 540 73 231 542 minecraft:polished_blackstone_bricks
fill 82 231 515 82 232 517 minecraft:purple_stained_glass
fill 83 231 514 85 232 514 minecraft:purple_stained_glass
fill 83 231 518 85 232 518 minecraft:purple_stained_glass
fill 86 231 515 86 232 517 minecraft:purple_stained_glass
fill 47 232 516 47 245 516 minecraft:blackstone
fill 47 232 517 47 232 518 minecraft:crying_obsidian
fill 47 232 519 47 245 519 minecraft:blackstone
fill 47 232 528 47 245 528 minecraft:blackstone
fill 47 232 529 47 232 530 minecraft:crying_obsidian
fill 47 232 531 47 245 531 minecraft:blackstone
fill 47 232 540 47 245 540 minecraft:blackstone
fill 47 232 541 47 232 542 minecraft:crying_obsidian
fill 47 232 543 47 245 543 minecraft:blackstone
fill 47 232 552 47 245 552 minecraft:blackstone
fill 48 232 552 49 232 552 minecraft:crying_obsidian
fill 50 232 552 50 245 552 minecraft:blackstone
fill 54 232 510 54 245 510 minecraft:blackstone
fill 55 232 510 56 232 510 minecraft:crying_obsidian
fill 57 232 510 57 245 510 minecraft:blackstone
fill 59 232 552 59 245 552 minecraft:blackstone
fill 60 232 552 61 232 552 minecraft:crying_obsidian
setblock 61 232 549 minecraft:purple_wool
fill 62 232 552 62 245 552 minecraft:blackstone
fill 66 232 510 66 245 510 minecraft:blackstone
fill 67 232 510 68 232 510 minecraft:crying_obsidian
fill 69 232 510 69 245 510 minecraft:blackstone
fill 71 232 520 71 232 523 minecraft:polished_blackstone_bricks
fill 71 232 538 71 232 541 minecraft:polished_blackstone_bricks
fill 71 232 552 71 245 552 minecraft:blackstone
setblock 72 232 518 minecraft:purple_stained_glass
fill 72 232 523 72 232 524 minecraft:polished_blackstone_bricks
fill 72 232 537 72 232 538 minecraft:polished_blackstone_bricks
setblock 72 232 543 minecraft:purple_stained_glass
fill 72 232 552 73 232 552 minecraft:crying_obsidian
fill 73 232 520 73 232 523 minecraft:polished_blackstone_bricks
fill 73 232 538 73 232 541 minecraft:polished_blackstone_bricks
fill 74 232 552 74 245 552 minecraft:blackstone
fill 78 232 510 78 245 510 minecraft:blackstone
fill 78 232 549 84 232 549 minecraft:iron_bars
fill 79 232 510 80 232 510 minecraft:crying_obsidian
fill 81 232 510 81 245 510 minecraft:blackstone
fill 83 232 552 83 245 552 minecraft:blackstone
fill 84 232 552 85 232 552 minecraft:crying_obsidian
fill 86 232 552 86 245 552 minecraft:blackstone
fill 89 232 511 89 245 511 minecraft:blackstone
fill 89 232 512 89 232 513 minecraft:crying_obsidian
fill 89 232 514 89 245 514 minecraft:blackstone
fill 89 232 523 89 245 523 minecraft:blackstone
fill 89 232 524 89 232 525 minecraft:crying_obsidian
fill 89 232 526 89 245 526 minecraft:blackstone
fill 89 232 535 89 245 535 minecraft:blackstone
fill 89 232 536 89 232 537 minecraft:crying_obsidian
fill 89 232 538 89 245 538 minecraft:blackstone
fill 89 232 547 89 245 547 minecraft:blackstone
fill 89 232 548 89 232 549 minecraft:crying_obsidian
fill 89 232 550 89 245 550 minecraft:blackstone
fill 47 233 517 47 245 518 minecraft:blackstone
fill 47 233 529 47 245 530 minecraft:blackstone
fill 47 233 541 47 245 542 minecraft:blackstone
fill 48 233 552 49 245 552 minecraft:blackstone
fill 55 233 510 56 245 510 minecraft:blackstone
fill 60 233 552 61 245 552 minecraft:blackstone
fill 67 233 510 68 245 510 minecraft:blackstone
fill 72 233 552 73 245 552 minecraft:blackstone
fill 79 233 510 80 245 510 minecraft:blackstone
fill 84 233 552 85 245 552 minecraft:blackstone
fill 89 233 512 89 245 513 minecraft:blackstone
fill 89 233 524 89 245 525 minecraft:blackstone
fill 89 233 536 89 245 537 minecraft:blackstone
fill 89 233 548 89 245 549 minecraft:blackstone
setblock 50 234 513 minecraft:light[level=11]
setblock 50 234 521 minecraft:light[level=11]
setblock 50 234 529 minecraft:light[level=11]
setblock 50 234 537 minecraft:light[level=11]
setblock 50 234 545 minecraft:light[level=11]
setblock 58 234 513 minecraft:light[level=11]
setblock 58 234 521 minecraft:light[level=11]
setblock 58 234 529 minecraft:light[level=11]
setblock 58 234 537 minecraft:light[level=11]
setblock 58 234 545 minecraft:light[level=11]
setblock 66 234 513 minecraft:light[level=11]
setblock 66 234 521 minecraft:light[level=11]
setblock 66 234 529 minecraft:light[level=11]
setblock 66 234 537 minecraft:light[level=11]
setblock 66 234 545 minecraft:light[level=11]
setblock 74 234 513 minecraft:light[level=11]
setblock 74 234 521 minecraft:light[level=11]
setblock 74 234 529 minecraft:light[level=11]
setblock 74 234 537 minecraft:light[level=11]
setblock 74 234 545 minecraft:light[level=11]
setblock 82 234 513 minecraft:light[level=11]
setblock 82 234 521 minecraft:light[level=11]
setblock 82 234 529 minecraft:light[level=11]
setblock 82 234 537 minecraft:light[level=11]
setblock 82 234 545 minecraft:light[level=11]
fill 53 238 537 65 238 537 minecraft:purple_stained_glass
fill 56 238 536 66 238 536 minecraft:purple_stained_glass
fill 56 238 538 66 238 538 minecraft:purple_stained_glass
fill 57 238 529 59 239 530 minecraft:purple_stained_glass
fill 57 238 544 59 239 545 minecraft:purple_stained_glass
fill 58 238 531 78 238 531 minecraft:purple_stained_glass
fill 58 238 543 78 238 543 minecraft:purple_stained_glass
fill 59 238 532 77 238 532 minecraft:purple_stained_glass
fill 59 238 535 67 238 535 minecraft:purple_stained_glass
fill 59 238 539 67 238 539 minecraft:purple_stained_glass
fill 59 238 542 77 238 542 minecraft:purple_stained_glass
fill 60 238 530 61 239 530 minecraft:purple_stained_glass
fill 60 238 533 76 238 533 minecraft:purple_stained_glass
fill 60 238 541 76 238 541 minecraft:purple_stained_glass
fill 60 238 544 61 239 544 minecraft:purple_stained_glass
fill 61 238 534 75 238 534 minecraft:purple_stained_glass
fill 61 238 540 75 238 540 minecraft:purple_stained_glass
fill 64 238 524 64 239 530 minecraft:purple_stained_glass
fill 64 238 544 64 239 550 minecraft:purple_stained_glass
fill 65 238 525 65 238 530 minecraft:purple_stained_glass
fill 65 238 544 65 238 549 minecraft:purple_stained_glass
fill 66 238 526 66 238 530 minecraft:purple_stained_glass
fill 66 238 544 66 238 548 minecraft:purple_stained_glass
fill 67 238 528 67 238 530 minecraft:purple_stained_glass
fill 67 238 544 67 238 546 minecraft:purple_stained_glass
fill 69 238 528 72 238 530 minecraft:purple_stained_glass
fill 69 238 535 77 238 535 minecraft:purple_stained_glass
fill 69 238 539 77 238 539 minecraft:purple_stained_glass
fill 69 238 544 72 238 546 minecraft:purple_stained_glass
fill 70 238 526 72 239 527 minecraft:purple_stained_glass
fill 70 238 536 80 238 536 minecraft:purple_stained_glass
fill 70 238 538 80 238 538 minecraft:purple_stained_glass
fill 70 238 547 72 239 548 minecraft:purple_stained_glass
fill 71 238 525 72 239 525 minecraft:purple_stained_glass
fill 71 238 537 83 238 537 minecraft:purple_stained_glass
fill 71 238 549 72 239 549 minecraft:purple_stained_glass
fill 72 238 524 72 239 524 minecraft:purple_stained_glass
fill 72 238 550 72 239 550 minecraft:purple_stained_glass
fill 75 238 530 79 239 530 minecraft:purple_stained_glass
fill 75 238 544 79 239 544 minecraft:purple_stained_glass
fill 77 238 529 79 239 529 minecraft:purple_stained_glass
fill 77 238 545 79 239 545 minecraft:purple_stained_glass
fill 48 239 511 52 239 551 minecraft:polished_blackstone
fill 53 239 511 55 239 536 minecraft:polished_blackstone
fill 53 239 537 57 239 537 minecraft:purple_stained_glass
fill 53 239 538 55 239 551 minecraft:polished_blackstone
fill 56 239 511 56 239 535 minecraft:polished_blackstone
fill 56 239 536 59 239 536 minecraft:purple_stained_glass
fill 56 239 538 59 239 538 minecraft:purple_stained_glass
fill 56 239 539 56 239 551 minecraft:polished_blackstone
fill 57 239 511 63 239 528 minecraft:polished_blackstone
fill 57 239 531 57 239 535 minecraft:polished_blackstone
fill 57 239 539 57 239 543 minecraft:polished_blackstone
fill 57 239 546 63 239 551 minecraft:polished_blackstone
fill 58 239 531 59 239 531 minecraft:purple_stained_glass
fill 58 239 532 58 239 535 minecraft:polished_blackstone
fill 58 239 537 63 239 537 minecraft:magenta_stained_glass
fill 58 239 539 58 239 542 minecraft:polished_blackstone
fill 58 239 543 59 239 543 minecraft:purple_stained_glass
fill 59 239 532 60 239 532 minecraft:purple_stained_glass
fill 59 239 533 59 239 534 minecraft:polished_blackstone
fill 59 239 535 62 239 535 minecraft:purple_stained_glass
fill 59 239 539 62 239 539 minecraft:purple_stained_glass
fill 59 239 540 59 239 541 minecraft:polished_blackstone
fill 59 239 542 60 239 542 minecraft:purple_stained_glass
fill 60 239 529 63 239 529 minecraft:polished_blackstone
setblock 60 239 531 minecraft:magenta_stained_glass
setblock 60 239 533 minecraft:purple_stained_glass
setblock 60 239 534 minecraft:polished_blackstone
fill 60 239 536 64 239 536 minecraft:magenta_stained_glass
fill 60 239 538 64 239 538 minecraft:magenta_stained_glass
setblock 60 239 540 minecraft:polished_blackstone
setblock 60 239 541 minecraft:purple_stained_glass
setblock 60 239 543 minecraft:magenta_stained_glass
fill 60 239 545 63 239 545 minecraft:polished_blackstone
fill 61 239 531 64 239 531 minecraft:purple_stained_glass
fill 61 239 532 63 239 533 minecraft:magenta_stained_glass
setblock 61 239 534 minecraft:purple_stained_glass
setblock 61 239 540 minecraft:purple_stained_glass
fill 61 239 541 63 239 542 minecraft:magenta_stained_glass
fill 61 239 543 64 239 543 minecraft:purple_stained_glass
fill 62 239 530 63 239 530 minecraft:polished_blackstone
fill 62 239 534 65 239 534 minecraft:magenta_stained_glass
fill 62 239 540 65 239 540 minecraft:magenta_stained_glass
fill 62 239 544 63 239 544 minecraft:polished_blackstone
fill 63 239 535 64 239 535 minecraft:magenta_stained_glass
fill 63 239 539 64 239 539 minecraft:magenta_stained_glass
fill 64 239 511 88 239 523 minecraft:polished_blackstone
setblock 64 239 532 minecraft:purple_stained_glass
fill 64 239 533 67 239 533 minecraft:magenta_stained_glass
fill 64 239 537 65 239 537 minecraft:crying_obsidian
fill 64 239 541 67 239 541 minecraft:magenta_stained_glass
setblock 64 239 542 minecraft:purple_stained_glass
fill 64 239 551 88 239 551 minecraft:polished_blackstone
fill 65 239 524 71 239 524 minecraft:polished_blackstone
fill 65 239 525 65 239 527 minecraft:purple_stained_glass
fill 65 239 528 65 239 532 minecraft:magenta_stained_glass
fill 65 239 535 66 239 536 minecraft:crying_obsidian
fill 65 239 538 66 239 539 minecraft:crying_obsidian
fill 65 239 542 65 239 546 minecraft:magenta_stained_glass
fill 65 239 547 65 239 549 minecraft:purple_stained_glass
fill 65 239 550 71 239 550 minecraft:polished_blackstone
fill 66 239 525 70 239 525 minecraft:polished_blackstone
fill 66 239 526 66 239 528 minecraft:purple_stained_glass
fill 66 239 529 66 239 532 minecraft:magenta_stained_glass
fill 66 239 534 70 239 534 minecraft:crying_obsidian
fill 66 239 540 70 239 540 minecraft:crying_obsidian
fill 66 239 542 66 239 545 minecraft:magenta_stained_glass
fill 66 239 546 66 239 548 minecraft:purple_stained_glass
fill 66 239 549 70 239 549 minecraft:polished_blackstone
fill 67 239 526 69 239 527 minecraft:polished_blackstone
fill 67 239 528 67 239 529 minecraft:purple_stained_glass
fill 67 239 530 67 239 532 minecraft:magenta_stained_glass
setblock 67 239 535 minecraft:crying_obsidian
setblock 67 239 539 minecraft:crying_obsidian
fill 67 239 542 67 239 544 minecraft:magenta_stained_glass
fill 67 239 545 67 239 546 minecraft:purple_stained_glass
fill 67 239 547 69 239 548 minecraft:polished_blackstone
fill 68 239 528 68 239 530 minecraft:polished_blackstone
fill 68 239 531 68 239 532 minecraft:purple_stained_glass
setblock 68 239 533 minecraft:crying_obsidian
setblock 68 239 541 minecraft:crying_obsidian
fill 68 239 542 68 239 543 minecraft:purple_stained_glass
fill 68 239 544 68 239 546 minecraft:polished_blackstone
fill 69 239 528 69 239 529 minecraft:purple_stained_glass
fill 69 239 530 71 239 533 minecraft:magenta_stained_glass
fill 69 239 535 71 239 535 minecraft:crying_obsidian
fill 69 239 539 71 239 539 minecraft:crying_obsidian
fill 69 239 541 71 239 544 minecraft:magenta_stained_glass
fill 69 239 545 69 239 546 minecraft:purple_stained_glass
setblock 70 239 528 minecraft:purple_stained_glass
fill 70 239 529 71 239 529 minecraft:magenta_stained_glass
fill 70 239 536 71 239 536 minecraft:crying_obsidian
fill 70 239 538 71 239 538 minecraft:crying_obsidian
fill 70 239 545 71 239 545 minecraft:magenta_stained_glass
setblock 70 239 546 minecraft:purple_stained_glass
setblock 71 239 528 minecraft:magenta_stained_glass
fill 71 239 534 74 239 534 minecraft:magenta_stained_glass
fill 71 239 537 72 239 537 minecraft:crying_obsidian
fill 71 239 540 74 239 540 minecraft:magenta_stained_glass
setblock 71 239 546 minecraft:magenta_stained_glass
fill 72 239 528 72 239 532 minecraft:purple_stained_glass
fill 72 239 533 75 239 533 minecraft:magenta_stained_glass
fill 72 239 535 73 239 536 minecraft:magenta_stained_glass
fill 72 239 538 73 239 539 minecraft:magenta_stained_glass
fill 72 239 541 75 239 541 minecraft:magenta_stained_glass
fill 72 239 542 72 239 546 minecraft:purple_stained_glass
fill 73 239 524 74 239 530 minecraft:polished_blackstone
fill 73 239 531 75 239 531 minecraft:purple_stained_glass
fill 73 239 532 75 239 532 minecraft:magenta_stained_glass
fill 73 239 537 78 239 537 minecraft:magenta_stained_glass
fill 73 239 542 75 239 542 minecraft:magenta_stained_glass
fill 73 239 543 75 239 543 minecraft:purple_stained_glass
fill 73 239 544 74 239 550 minecraft:polished_blackstone
fill 74 239 535 77 239 535 minecraft:purple_stained_glass
fill 74 239 536 76 239 536 minecraft:magenta_stained_glass
fill 74 239 538 76 239 538 minecraft:magenta_stained_glass
fill 74 239 539 77 239 539 minecraft:purple_stained_glass
fill 75 239 524 76 239 529 minecraft:polished_blackstone
setblock 75 239 534 minecraft:purple_stained_glass
setblock 75 239 540 minecraft:purple_stained_glass
fill 75 239 545 76 239 550 minecraft:polished_blackstone
setblock 76 239 531 minecraft:magenta_stained_glass
fill 76 239 532 76 239 533 minecraft:purple_stained_glass
fill 76 239 534 88 239 534 minecraft:polished_blackstone
fill 76 239 540 88 239 540 minecraft:polished_blackstone
fill 76 239 541 76 239 542 minecraft:purple_stained_glass
setblock 76 239 543 minecraft:magenta_stained_glass
fill 77 239 524 88 239 528 minecraft:polished_blackstone
fill 77 239 531 77 239 532 minecraft:purple_stained_glass
fill 77 239 533 88 239 533 minecraft:polished_blackstone
fill 77 239 536 80 239 536 minecraft:purple_stained_glass
fill 77 239 538 80 239 538 minecraft:purple_stained_glass
fill 77 239 541 88 239 541 minecraft:polished_blackstone
fill 77 239 542 77 239 543 minecraft:purple_stained_glass
fill 77 239 546 88 239 550 minecraft:polished_blackstone
setblock 78 239 531 minecraft:purple_stained_glass
fill 78 239 532 88 239 532 minecraft:polished_blackstone
fill 78 239 535 88 239 535 minecraft:polished_blackstone
fill 78 239 539 88 239 539 minecraft:polished_blackstone
fill 78 239 542 88 239 542 minecraft:polished_blackstone
setblock 78 239 543 minecraft:purple_stained_glass
fill 79 239 531 88 239 531 minecraft:polished_blackstone
fill 79 239 537 83 239 537 minecraft:purple_stained_glass
fill 79 239 543 88 239 543 minecraft:polished_blackstone
fill 80 239 529 88 239 530 minecraft:polished_blackstone
fill 80 239 544 88 239 545 minecraft:polished_blackstone
fill 81 239 536 88 239 536 minecraft:polished_blackstone
fill 81 239 538 88 239 538 minecraft:polished_blackstone
fill 84 239 537 88 239 537 minecraft:polished_blackstone
setblock 50 242 513 minecraft:light[level=11]
setblock 50 242 521 minecraft:light[level=11]
setblock 50 242 529 minecraft:light[level=11]
setblock 50 242 537 minecraft:light[level=11]
setblock 50 242 545 minecraft:light[level=11]
setblock 58 242 513 minecraft:light[level=11]
setblock 58 242 521 minecraft:light[level=11]
setblock 58 242 529 minecraft:light[level=11]
setblock 58 242 537 minecraft:light[level=11]
setblock 58 242 545 minecraft:light[level=11]
setblock 66 242 513 minecraft:light[level=11]
setblock 66 242 521 minecraft:light[level=11]
setblock 66 242 529 minecraft:light[level=11]
setblock 66 242 537 minecraft:light[level=11]
setblock 66 242 545 minecraft:light[level=11]
setblock 74 242 513 minecraft:light[level=11]
setblock 74 242 521 minecraft:light[level=11]
setblock 74 242 529 minecraft:light[level=11]
setblock 74 242 537 minecraft:light[level=11]
setblock 74 242 545 minecraft:light[level=11]
setblock 82 242 513 minecraft:light[level=11]
setblock 82 242 521 minecraft:light[level=11]
setblock 82 242 529 minecraft:light[level=11]
setblock 82 242 537 minecraft:light[level=11]
setblock 82 242 545 minecraft:light[level=11]
fill 48 243 511 50 273 511 minecraft:polished_blackstone_bricks
fill 48 243 521 48 273 523 minecraft:polished_blackstone_bricks
fill 48 243 533 48 273 535 minecraft:polished_blackstone_bricks
fill 48 243 545 48 273 547 minecraft:polished_blackstone_bricks
fill 49 243 520 49 245 522 minecraft:polished_blackstone_bricks
fill 49 243 532 49 245 534 minecraft:polished_blackstone_bricks
fill 49 243 544 49 245 546 minecraft:polished_blackstone_bricks
fill 54 243 551 56 273 551 minecraft:polished_blackstone_bricks
fill 55 243 550 57 245 550 minecraft:polished_blackstone_bricks
fill 59 243 512 61 245 512 minecraft:polished_blackstone_bricks
fill 59 243 549 63 243 549 minecraft:purple_wool
fill 60 243 511 62 273 511 minecraft:polished_blackstone_bricks
fill 66 243 551 68 273 551 minecraft:polished_blackstone_bricks
fill 67 243 550 69 245 550 minecraft:polished_blackstone_bricks
fill 71 243 512 73 245 512 minecraft:polished_blackstone_bricks
fill 72 243 511 74 273 511 minecraft:polished_blackstone_bricks
fill 78 243 551 80 273 551 minecraft:polished_blackstone_bricks
fill 79 243 550 81 245 550 minecraft:polished_blackstone_bricks
fill 83 243 512 85 245 512 minecraft:polished_blackstone_bricks
fill 84 243 511 86 273 511 minecraft:polished_blackstone_bricks
fill 87 243 520 87 245 522 minecraft:polished_blackstone_bricks
fill 87 243 532 87 245 534 minecraft:polished_blackstone_bricks
fill 87 243 544 87 245 546 minecraft:polished_blackstone_bricks
fill 88 243 519 88 273 521 minecraft:polished_blackstone_bricks
fill 88 243 531 88 273 533 minecraft:polished_blackstone_bricks
fill 88 243 543 88 273 545 minecraft:polished_blackstone_bricks
fill 58 244 549 64 245 549 minecraft:iron_bars
fill 48 245 514 48 245 519 minecraft:blackstone
fill 48 245 526 48 245 531 minecraft:blackstone
fill 48 245 538 48 245 543 minecraft:blackstone
fill 48 245 550 48 245 551 minecraft:blackstone
fill 49 245 551 52 245 551 minecraft:blackstone
fill 52 245 511 57 245 511 minecraft:blackstone
fill 59 245 551 64 245 551 minecraft:blackstone
fill 64 245 511 69 245 511 minecraft:blackstone
fill 71 245 551 76 245 551 minecraft:blackstone
fill 76 245 511 81 245 511 minecraft:blackstone
fill 83 245 551 88 245 551 minecraft:blackstone
fill 88 245 511 88 245 516 minecraft:blackstone
fill 88 245 523 88 245 528 minecraft:blackstone
fill 88 245 535 88 245 540 minecraft:blackstone
fill 88 245 547 88 245 550 minecraft:blackstone
fill 47 246 516 47 251 519 minecraft:crying_obsidian
fill 47 246 528 47 251 531 minecraft:crying_obsidian
fill 47 246 540 47 251 543 minecraft:crying_obsidian
fill 47 246 552 50 251 552 minecraft:crying_obsidian
fill 54 246 510 57 251 510 minecraft:crying_obsidian
fill 59 246 552 62 251 552 minecraft:crying_obsidian
fill 66 246 510 69 251 510 minecraft:crying_obsidian
fill 71 246 552 74 251 552 minecraft:crying_obsidian
fill 78 246 510 81 251 510 minecraft:crying_obsidian
fill 83 246 552 86 251 552 minecraft:crying_obsidian
fill 89 246 511 89 251 514 minecraft:crying_obsidian
fill 89 246 523 89 251 526 minecraft:crying_obsidian
fill 89 246 535 89 251 538 minecraft:crying_obsidian
fill 89 246 547 89 251 550 minecraft:crying_obsidian
setblock 50 250 513 minecraft:light[level=11]
setblock 50 250 521 minecraft:light[level=11]
setblock 50 250 529 minecraft:light[level=11]
setblock 50 250 537 minecraft:light[level=11]
setblock 50 250 545 minecraft:light[level=11]
setblock 58 250 513 minecraft:light[level=11]
setblock 58 250 521 minecraft:light[level=11]
setblock 58 250 529 minecraft:light[level=11]
setblock 58 250 537 minecraft:light[level=11]
setblock 58 250 545 minecraft:light[level=11]
setblock 66 250 513 minecraft:light[level=11]
setblock 66 250 521 minecraft:light[level=11]
setblock 66 250 529 minecraft:light[level=11]
setblock 66 250 537 minecraft:light[level=11]
setblock 66 250 545 minecraft:light[level=11]
setblock 74 250 513 minecraft:light[level=11]
setblock 74 250 521 minecraft:light[level=11]
setblock 74 250 529 minecraft:light[level=11]
setblock 74 250 537 minecraft:light[level=11]
setblock 74 250 545 minecraft:light[level=11]
setblock 82 250 513 minecraft:light[level=11]
setblock 82 250 521 minecraft:light[level=11]
setblock 82 250 529 minecraft:light[level=11]
setblock 82 250 537 minecraft:light[level=11]
setblock 82 250 545 minecraft:light[level=11]
fill 47 252 516 47 265 516 minecraft:blackstone
fill 47 252 517 47 252 518 minecraft:crying_obsidian
fill 47 252 519 47 265 519 minecraft:blackstone
fill 47 252 528 47 265 528 minecraft:blackstone
fill 47 252 529 47 252 530 minecraft:crying_obsidian
fill 47 252 531 47 265 531 minecraft:blackstone
fill 47 252 540 47 265 540 minecraft:blackstone
fill 47 252 541 47 252 542 minecraft:crying_obsidian
fill 47 252 543 47 265 543 minecraft:blackstone
fill 47 252 552 47 265 552 minecraft:blackstone
fill 48 252 552 49 252 552 minecraft:crying_obsidian
fill 50 252 552 50 265 552 minecraft:blackstone
fill 54 252 510 54 265 510 minecraft:blackstone
fill 55 252 510 56 252 510 minecraft:crying_obsidian
fill 57 252 510 57 265 510 minecraft:blackstone
fill 59 252 552 59 265 552 minecraft:blackstone
fill 60 252 552 61 252 552 minecraft:crying_obsidian
fill 62 252 552 62 265 552 minecraft:blackstone
fill 66 252 510 66 265 510 minecraft:blackstone
fill 67 252 510 68 252 510 minecraft:crying_obsidian
fill 69 252 510 69 265 510 minecraft:blackstone
fill 71 252 552 71 265 552 minecraft:blackstone
fill 72 252 552 73 252 552 minecraft:crying_obsidian
fill 74 252 552 74 265 552 minecraft:blackstone
fill 78 252 510 78 265 510 minecraft:blackstone
fill 79 252 510 80 252 510 minecraft:crying_obsidian
fill 81 252 510 81 265 510 minecraft:blackstone
fill 83 252 552 83 265 552 minecraft:blackstone
fill 84 252 552 85 252 552 minecraft:crying_obsidian
fill 86 252 552 86 265 552 minecraft:blackstone
fill 89 252 511 89 265 511 minecraft:blackstone
fill 89 252 512 89 252 513 minecraft:crying_obsidian
fill 89 252 514 89 265 514 minecraft:blackstone
fill 89 252 523 89 265 523 minecraft:blackstone
fill 89 252 524 89 252 525 minecraft:crying_obsidian
fill 89 252 526 89 265 526 minecraft:blackstone
fill 89 252 535 89 265 535 minecraft:blackstone
fill 89 252 536 89 252 537 minecraft:crying_obsidian
fill 89 252 538 89 265 538 minecraft:blackstone
fill 89 252 547 89 265 547 minecraft:blackstone
fill 89 252 548 89 252 549 minecraft:crying_obsidian
fill 89 252 550 89 265 550 minecraft:blackstone
fill 47 253 517 47 265 518 minecraft:blackstone
fill 47 253 529 47 265 530 minecraft:blackstone
fill 47 253 541 47 265 542 minecraft:blackstone
fill 48 253 552 49 265 552 minecraft:blackstone
fill 55 253 510 56 265 510 minecraft:blackstone
fill 60 253 552 61 265 552 minecraft:blackstone
fill 67 253 510 68 265 510 minecraft:blackstone
fill 72 253 552 73 265 552 minecraft:blackstone
fill 79 253 510 80 265 510 minecraft:blackstone
fill 84 253 552 85 265 552 minecraft:blackstone
fill 86 253 543 86 265 543 minecraft:purple_wool
fill 89 253 512 89 265 513 minecraft:blackstone
fill 89 253 524 89 265 525 minecraft:blackstone
fill 89 253 536 89 265 537 minecraft:blackstone
fill 89 253 548 89 265 549 minecraft:blackstone
fill 86 254 541 86 265 542 minecraft:purple_wool
fill 86 254 544 86 265 545 minecraft:purple_wool
setblock 50 258 513 minecraft:light[level=11]
setblock 50 258 521 minecraft:light[level=11]
setblock 50 258 529 minecraft:light[level=11]
setblock 50 258 537 minecraft:light[level=11]
setblock 50 258 545 minecraft:light[level=11]
setblock 58 258 513 minecraft:light[level=11]
setblock 58 258 521 minecraft:light[level=11]
setblock 58 258 529 minecraft:light[level=11]
setblock 58 258 537 minecraft:light[level=11]
setblock 58 258 545 minecraft:light[level=11]
setblock 66 258 513 minecraft:light[level=11]
setblock 66 258 521 minecraft:light[level=11]
setblock 66 258 529 minecraft:light[level=11]
setblock 66 258 537 minecraft:light[level=11]
setblock 66 258 545 minecraft:light[level=11]
setblock 74 258 513 minecraft:light[level=11]
setblock 74 258 521 minecraft:light[level=11]
setblock 74 258 529 minecraft:light[level=11]
setblock 74 258 537 minecraft:light[level=11]
setblock 74 258 545 minecraft:light[level=11]
setblock 82 258 513 minecraft:light[level=11]
setblock 82 258 521 minecraft:light[level=11]
setblock 82 258 529 minecraft:light[level=11]
setblock 82 258 537 minecraft:light[level=11]
setblock 82 258 545 minecraft:light[level=11]
fill 49 260 520 49 265 522 minecraft:polished_blackstone_bricks
fill 49 260 532 49 265 534 minecraft:polished_blackstone_bricks
fill 49 260 544 49 265 546 minecraft:polished_blackstone_bricks
fill 55 260 550 57 265 550 minecraft:polished_blackstone_bricks
fill 59 260 512 61 265 512 minecraft:polished_blackstone_bricks
fill 67 260 550 69 265 550 minecraft:polished_blackstone_bricks
fill 71 260 512 73 265 512 minecraft:polished_blackstone_bricks
fill 79 260 550 81 265 550 minecraft:polished_blackstone_bricks
fill 83 260 512 85 265 512 minecraft:polished_blackstone_bricks
fill 87 260 520 87 265 522 minecraft:polished_blackstone_bricks
fill 87 260 532 87 265 534 minecraft:polished_blackstone_bricks
fill 87 260 544 87 265 546 minecraft:polished_blackstone_bricks
fill 48 265 514 48 265 519 minecraft:blackstone
fill 48 265 526 48 265 531 minecraft:blackstone
fill 48 265 538 48 265 543 minecraft:blackstone
fill 48 265 550 48 265 551 minecraft:blackstone
fill 49 265 551 52 265 551 minecraft:blackstone
fill 52 265 511 57 265 511 minecraft:blackstone
fill 59 265 551 64 265 551 minecraft:blackstone
fill 64 265 511 69 265 511 minecraft:blackstone
fill 71 265 551 76 265 551 minecraft:blackstone
fill 76 265 511 81 265 511 minecraft:blackstone
fill 83 265 551 88 265 551 minecraft:blackstone
fill 88 265 511 88 265 516 minecraft:blackstone
fill 88 265 523 88 265 528 minecraft:blackstone
fill 88 265 535 88 265 540 minecraft:blackstone
fill 88 265 547 88 265 550 minecraft:blackstone
fill 47 266 516 47 271 519 minecraft:crying_obsidian
fill 47 266 528 47 271 531 minecraft:crying_obsidian
fill 47 266 540 47 271 543 minecraft:crying_obsidian
fill 47 266 552 50 271 552 minecraft:crying_obsidian
setblock 50 266 513 minecraft:light[level=11]
setblock 50 266 521 minecraft:light[level=11]
setblock 50 266 529 minecraft:light[level=11]
setblock 50 266 537 minecraft:light[level=11]
setblock 50 266 545 minecraft:light[level=11]
fill 54 266 510 57 271 510 minecraft:crying_obsidian
setblock 58 266 513 minecraft:light[level=11]
setblock 58 266 521 minecraft:light[level=11]
setblock 58 266 529 minecraft:light[level=11]
setblock 58 266 537 minecraft:light[level=11]
setblock 58 266 545 minecraft:light[level=11]
fill 59 266 552 62 271 552 minecraft:crying_obsidian
fill 66 266 510 69 271 510 minecraft:crying_obsidian
setblock 66 266 513 minecraft:light[level=11]
setblock 66 266 521 minecraft:light[level=11]
setblock 66 266 529 minecraft:light[level=11]
setblock 66 266 537 minecraft:light[level=11]
setblock 66 266 545 minecraft:light[level=11]
fill 71 266 552 74 271 552 minecraft:crying_obsidian
setblock 74 266 513 minecraft:light[level=11]
setblock 74 266 521 minecraft:light[level=11]
setblock 74 266 529 minecraft:light[level=11]
setblock 74 266 537 minecraft:light[level=11]
setblock 74 266 545 minecraft:light[level=11]
fill 78 266 510 81 271 510 minecraft:crying_obsidian
setblock 82 266 513 minecraft:light[level=11]
setblock 82 266 521 minecraft:light[level=11]
setblock 82 266 529 minecraft:light[level=11]
setblock 82 266 537 minecraft:light[level=11]
setblock 82 266 545 minecraft:light[level=11]
fill 83 266 552 86 271 552 minecraft:crying_obsidian
fill 86 266 540 86 267 546 minecraft:iron_bars
fill 89 266 511 89 271 514 minecraft:crying_obsidian
fill 89 266 523 89 271 526 minecraft:crying_obsidian
fill 89 266 535 89 271 538 minecraft:crying_obsidian
fill 89 266 547 89 271 550 minecraft:crying_obsidian
fill 47 272 516 47 285 516 minecraft:blackstone
fill 47 272 517 47 272 518 minecraft:crying_obsidian
fill 47 272 519 47 285 519 minecraft:blackstone
fill 47 272 528 47 285 528 minecraft:blackstone
fill 47 272 529 47 272 530 minecraft:crying_obsidian
fill 47 272 531 47 285 531 minecraft:blackstone
fill 47 272 540 47 285 540 minecraft:blackstone
fill 47 272 541 47 272 542 minecraft:crying_obsidian
fill 47 272 543 47 285 543 minecraft:blackstone
fill 47 272 552 47 285 552 minecraft:blackstone
fill 48 272 552 49 272 552 minecraft:crying_obsidian
fill 50 272 552 50 285 552 minecraft:blackstone
fill 54 272 510 54 285 510 minecraft:blackstone
fill 55 272 510 56 272 510 minecraft:crying_obsidian
fill 57 272 510 57 285 510 minecraft:blackstone
fill 59 272 552 59 285 552 minecraft:blackstone
fill 60 272 552 61 272 552 minecraft:crying_obsidian
fill 62 272 552 62 285 552 minecraft:blackstone
fill 66 272 510 66 285 510 minecraft:blackstone
fill 67 272 510 68 272 510 minecraft:crying_obsidian
fill 69 272 510 69 285 510 minecraft:blackstone
fill 71 272 552 71 285 552 minecraft:blackstone
fill 72 272 552 73 272 552 minecraft:crying_obsidian
fill 74 272 552 74 285 552 minecraft:blackstone
fill 78 272 510 78 285 510 minecraft:blackstone
fill 79 272 510 80 272 510 minecraft:crying_obsidian
fill 81 272 510 81 285 510 minecraft:blackstone
fill 83 272 552 83 285 552 minecraft:blackstone
fill 84 272 552 85 272 552 minecraft:crying_obsidian
fill 86 272 552 86 285 552 minecraft:blackstone
fill 89 272 511 89 285 511 minecraft:blackstone
fill 89 272 512 89 272 513 minecraft:crying_obsidian
fill 89 272 514 89 285 514 minecraft:blackstone
fill 89 272 523 89 285 523 minecraft:blackstone
fill 89 272 524 89 272 525 minecraft:crying_obsidian
fill 89 272 526 89 285 526 minecraft:blackstone
fill 89 272 535 89 285 535 minecraft:blackstone
fill 89 272 536 89 272 537 minecraft:crying_obsidian
fill 89 272 538 89 285 538 minecraft:blackstone
fill 89 272 547 89 285 547 minecraft:blackstone
fill 89 272 548 89 272 549 minecraft:crying_obsidian
fill 89 272 550 89 285 550 minecraft:blackstone
fill 47 273 517 47 285 518 minecraft:blackstone
fill 47 273 529 47 285 530 minecraft:blackstone
fill 47 273 541 47 285 542 minecraft:blackstone
fill 48 273 552 49 285 552 minecraft:blackstone
fill 55 273 510 56 285 510 minecraft:blackstone
fill 60 273 552 61 285 552 minecraft:blackstone
fill 67 273 510 68 285 510 minecraft:blackstone
fill 72 273 552 73 285 552 minecraft:blackstone
fill 79 273 510 80 285 510 minecraft:blackstone
fill 84 273 552 85 285 552 minecraft:blackstone
fill 89 273 512 89 285 513 minecraft:blackstone
fill 89 273 524 89 285 525 minecraft:blackstone
fill 89 273 536 89 285 537 minecraft:blackstone
fill 89 273 548 89 285 549 minecraft:blackstone
setblock 50 274 513 minecraft:light[level=11]
setblock 50 274 521 minecraft:light[level=11]
setblock 50 274 529 minecraft:light[level=11]
setblock 50 274 537 minecraft:light[level=11]
setblock 50 274 545 minecraft:light[level=11]
setblock 58 274 513 minecraft:light[level=11]
setblock 58 274 521 minecraft:light[level=11]
setblock 58 274 529 minecraft:light[level=11]
setblock 58 274 537 minecraft:light[level=11]
setblock 58 274 545 minecraft:light[level=11]
setblock 66 274 513 minecraft:light[level=11]
setblock 66 274 521 minecraft:light[level=11]
setblock 66 274 529 minecraft:light[level=11]
setblock 66 274 537 minecraft:light[level=11]
setblock 66 274 545 minecraft:light[level=11]
setblock 74 274 513 minecraft:light[level=11]
setblock 74 274 521 minecraft:light[level=11]
setblock 74 274 529 minecraft:light[level=11]
setblock 74 274 537 minecraft:light[level=11]
setblock 74 274 545 minecraft:light[level=11]
setblock 82 274 513 minecraft:light[level=11]
setblock 82 274 521 minecraft:light[level=11]
setblock 82 274 529 minecraft:light[level=11]
setblock 82 274 537 minecraft:light[level=11]
setblock 82 274 545 minecraft:light[level=11]
fill 48 279 511 65 279 551 minecraft:blackstone
fill 66 279 511 66 279 532 minecraft:blackstone
fill 66 279 533 66 280 533 minecraft:crying_obsidian
fill 66 279 535 66 280 535 minecraft:crying_obsidian
fill 66 279 536 66 279 551 minecraft:blackstone
fill 67 279 511 88 279 531 minecraft:blackstone
fill 67 279 532 67 280 532 minecraft:crying_obsidian
fill 67 279 536 67 280 536 minecraft:crying_obsidian
fill 67 279 537 88 279 551 minecraft:blackstone
fill 69 279 532 69 280 532 minecraft:crying_obsidian
fill 69 279 536 69 280 536 minecraft:crying_obsidian
fill 70 279 532 88 279 532 minecraft:blackstone
fill 70 279 533 70 280 533 minecraft:crying_obsidian
fill 70 279 535 70 280 535 minecraft:crying_obsidian
fill 70 279 536 88 279 536 minecraft:blackstone
fill 71 279 533 88 279 535 minecraft:blackstone
fill 48 280 511 48 292 551 minecraft:blackstone
fill 49 280 511 88 285 511 minecraft:blackstone
fill 49 280 512 64 281 550 minecraft:polished_blackstone_bricks
fill 49 280 551 88 292 551 minecraft:blackstone
fill 65 280 512 65 280 532 minecraft:polished_blackstone_bricks
fill 65 280 533 65 281 535 minecraft:crying_obsidian
fill 65 280 536 65 281 550 minecraft:polished_blackstone_bricks
fill 66 280 512 66 280 531 minecraft:polished_blackstone_bricks
setblock 66 280 532 minecraft:crying_obsidian
fill 66 280 536 66 281 536 minecraft:crying_obsidian
fill 66 280 537 66 281 550 minecraft:polished_blackstone_bricks
fill 67 280 512 87 280 530 minecraft:polished_blackstone_bricks
fill 67 280 531 69 280 531 minecraft:crying_obsidian
fill 67 280 537 69 283 537 minecraft:crying_obsidian
fill 67 280 538 87 283 550 minecraft:polished_blackstone_bricks
fill 70 280 531 87 280 531 minecraft:polished_blackstone_bricks
setblock 70 280 532 minecraft:crying_obsidian
fill 70 280 536 70 281 536 minecraft:crying_obsidian
fill 70 280 537 87 281 537 minecraft:polished_blackstone_bricks
fill 71 280 532 87 280 532 minecraft:polished_blackstone_bricks
fill 71 280 533 71 281 535 minecraft:crying_obsidian
fill 71 280 536 87 281 536 minecraft:polished_blackstone_bricks
fill 72 280 533 87 281 535 minecraft:polished_blackstone_bricks
fill 88 280 512 88 292 550 minecraft:blackstone
fill 65 281 512 65 281 531 minecraft:polished_blackstone_bricks
fill 65 281 532 65 282 532 minecraft:crying_obsidian
fill 66 281 512 66 281 530 minecraft:polished_blackstone_bricks
setblock 66 281 531 minecraft:crying_obsidian
fill 67 281 512 87 282 529 minecraft:polished_blackstone_bricks
fill 67 281 530 69 282 530 minecraft:crying_obsidian
fill 70 281 530 87 281 530 minecraft:polished_blackstone_bricks
setblock 70 281 531 minecraft:crying_obsidian
fill 71 281 531 87 281 531 minecraft:polished_blackstone_bricks
fill 71 281 532 71 282 532 minecraft:crying_obsidian
fill 72 281 532 87 282 532 minecraft:polished_blackstone_bricks
fill 49 282 512 63 283 550 minecraft:polished_blackstone_bricks
fill 64 282 512 64 282 532 minecraft:polished_blackstone_bricks
fill 64 282 533 64 283 534 minecraft:crying_obsidian
fill 64 282 535 64 282 550 minecraft:polished_blackstone_bricks
fill 65 282 512 65 282 530 minecraft:polished_blackstone_bricks
setblock 65 282 531 minecraft:crying_obsidian
fill 65 282 535 65 282 536 minecraft:crying_obsidian
fill 65 282 537 65 284 550 minecraft:polished_blackstone_bricks
fill 66 282 512 66 283 529 minecraft:polished_blackstone_bricks
fill 66 282 530 66 283 530 minecraft:crying_obsidian
fill 66 282 537 66 285 537 minecraft:crying_obsidian
fill 66 282 538 66 285 550 minecraft:polished_blackstone_bricks
fill 70 282 530 70 283 530 minecraft:crying_obsidian
fill 70 282 537 70 285 537 minecraft:crying_obsidian
fill 71 282 530 87 282 530 minecraft:polished_blackstone_bricks
setblock 71 282 531 minecraft:crying_obsidian
fill 71 282 535 71 282 536 minecraft:crying_obsidian
fill 71 282 537 87 284 537 minecraft:polished_blackstone_bricks
fill 72 282 531 87 282 531 minecraft:polished_blackstone_bricks
fill 72 282 533 72 283 534 minecraft:crying_obsidian
fill 72 282 535 87 282 536 minecraft:polished_blackstone_bricks
fill 73 282 533 87 283 534 minecraft:polished_blackstone_bricks
fill 64 283 512 64 284 530 minecraft:polished_blackstone_bricks
fill 64 283 531 64 283 532 minecraft:crying_obsidian
fill 64 283 535 64 284 535 minecraft:crying_obsidian
fill 64 283 536 64 284 550 minecraft:polished_blackstone_bricks
fill 65 283 512 65 284 529 minecraft:polished_blackstone_bricks
fill 65 283 530 65 284 530 minecraft:crying_obsidian
fill 65 283 536 65 284 536 minecraft:crying_obsidian
fill 67 283 512 87 283 528 minecraft:polished_blackstone_bricks
fill 67 283 529 69 283 529 minecraft:crying_obsidian
fill 70 283 529 87 283 529 minecraft:polished_blackstone_bricks
fill 71 283 530 71 284 530 minecraft:crying_obsidian
fill 71 283 536 71 284 536 minecraft:crying_obsidian
fill 72 283 530 87 284 530 minecraft:polished_blackstone_bricks
fill 72 283 531 72 283 532 minecraft:crying_obsidian
fill 72 283 535 72 284 535 minecraft:crying_obsidian
fill 72 283 536 87 284 536 minecraft:polished_blackstone_bricks
fill 73 283 531 87 283 532 minecraft:polished_blackstone_bricks
fill 73 283 535 87 284 535 minecraft:polished_blackstone_bricks
fill 49 284 512 62 285 550 minecraft:polished_blackstone_bricks
fill 63 284 512 63 284 531 minecraft:polished_blackstone_bricks
fill 63 284 532 63 285 534 minecraft:crying_obsidian
fill 63 284 535 63 284 550 minecraft:polished_blackstone_bricks
setblock 64 284 531 minecraft:crying_obsidian
fill 66 284 512 66 284 528 minecraft:polished_blackstone_bricks
setblock 66 284 529 minecraft:crying_obsidian
fill 67 284 512 87 285 527 minecraft:polished_blackstone_bricks
fill 67 284 528 69 285 528 minecraft:crying_obsidian
fill 67 284 538 69 287 538 minecraft:crying_obsidian
fill 67 284 539 87 287 550 minecraft:polished_blackstone_bricks
fill 70 284 528 87 284 528 minecraft:polished_blackstone_bricks
setblock 70 284 529 minecraft:crying_obsidian
fill 70 284 538 87 285 538 minecraft:polished_blackstone_bricks
fill 71 284 529 87 284 529 minecraft:polished_blackstone_bricks
setblock 72 284 531 minecraft:crying_obsidian
fill 73 284 531 87 284 531 minecraft:polished_blackstone_bricks
fill 73 284 532 73 285 534 minecraft:crying_obsidian
fill 74 284 532 87 285 534 minecraft:polished_blackstone_bricks
fill 63 285 512 63 285 530 minecraft:polished_blackstone_bricks
fill 63 285 531 63 286 531 minecraft:crying_obsidian
fill 63 285 535 63 287 535 minecraft:crying_obsidian
fill 63 285 536 63 286 550 minecraft:polished_blackstone_bricks
fill 64 285 512 64 285 529 minecraft:polished_blackstone_bricks
setblock 64 285 530 minecraft:crying_obsidian
fill 64 285 536 64 286 536 minecraft:crying_obsidian
fill 64 285 537 64 286 550 minecraft:polished_blackstone_bricks
fill 65 285 512 65 285 528 minecraft:polished_blackstone_bricks
setblock 65 285 529 minecraft:crying_obsidian
fill 65 285 537 65 287 537 minecraft:crying_obsidian
fill 65 285 538 65 287 550 minecraft:polished_blackstone_bricks
fill 66 285 512 66 285 527 minecraft:polished_blackstone_bricks
setblock 66 285 528 minecraft:crying_obsidian
setblock 70 285 528 minecraft:crying_obsidian
fill 71 285 528 87 285 528 minecraft:polished_blackstone_bricks
setblock 71 285 529 minecraft:crying_obsidian
fill 71 285 537 71 287 537 minecraft:crying_obsidian
fill 72 285 529 87 285 529 minecraft:polished_blackstone_bricks
setblock 72 285 530 minecraft:crying_obsidian
fill 72 285 536 72 286 536 minecraft:crying_obsidian
fill 72 285 537 87 286 537 minecraft:polished_blackstone_bricks
fill 73 285 530 87 285 530 minecraft:polished_blackstone_bricks
fill 73 285 531 73 286 531 minecraft:crying_obsidian
fill 73 285 535 73 287 535 minecraft:crying_obsidian
fill 73 285 536 87 286 536 minecraft:polished_blackstone_bricks
fill 74 285 531 87 286 531 minecraft:polished_blackstone_bricks
fill 74 285 535 87 287 535 minecraft:polished_blackstone_bricks
fill 47 286 516 47 291 519 minecraft:crying_obsidian
fill 47 286 528 47 291 531 minecraft:crying_obsidian
fill 47 286 540 47 291 543 minecraft:crying_obsidian
fill 47 286 552 50 291 552 minecraft:crying_obsidian
fill 49 286 511 75 292 511 minecraft:blackstone
fill 49 286 512 61 288 550 minecraft:polished_blackstone_bricks
fill 54 286 510 57 291 510 minecraft:crying_obsidian
fill 59 286 552 62 291 552 minecraft:crying_obsidian
fill 62 286 512 62 286 531 minecraft:polished_blackstone_bricks
fill 62 286 532 62 288 533 minecraft:crying_obsidian
fill 62 286 534 62 286 550 minecraft:polished_blackstone_bricks
fill 63 286 512 63 286 529 minecraft:polished_blackstone_bricks
setblock 63 286 530 minecraft:crying_obsidian
setblock 63 286 534 minecraft:crying_obsidian
fill 64 286 512 64 286 528 minecraft:polished_blackstone_bricks
setblock 64 286 529 minecraft:crying_obsidian
fill 65 286 512 65 286 527 minecraft:polished_blackstone_bricks
setblock 65 286 528 minecraft:crying_obsidian
fill 66 286 510 69 291 510 minecraft:crying_obsidian
fill 66 286 512 75 286 526 minecraft:polished_blackstone_bricks
fill 66 286 527 70 286 527 minecraft:crying_obsidian
fill 66 286 538 66 289 538 minecraft:crying_obsidian
fill 66 286 539 66 289 550 minecraft:polished_blackstone_bricks
fill 70 286 538 70 289 538 minecraft:crying_obsidian
fill 71 286 527 87 286 527 minecraft:polished_blackstone_bricks
setblock 71 286 528 minecraft:crying_obsidian
fill 71 286 538 87 287 538 minecraft:polished_blackstone_bricks
fill 71 286 552 74 291 552 minecraft:crying_obsidian
fill 72 286 528 87 286 528 minecraft:polished_blackstone_bricks
setblock 72 286 529 minecraft:crying_obsidian
fill 73 286 529 87 286 529 minecraft:polished_blackstone_bricks
setblock 73 286 530 minecraft:crying_obsidian
setblock 73 286 534 minecraft:crying_obsidian
fill 74 286 530 87 286 530 minecraft:polished_blackstone_bricks
fill 74 286 532 74 288 533 minecraft:crying_obsidian
fill 74 286 534 87 286 534 minecraft:polished_blackstone_bricks
fill 75 286 532 87 288 533 minecraft:polished_blackstone_bricks
setblock 76 286 511 minecraft:crying_obsidian
fill 76 286 512 76 291 512 minecraft:polished_blackstone_bricks
setblock 76 286 513 minecraft:crying_obsidian
fill 76 286 514 76 291 514 minecraft:polished_blackstone_bricks
setblock 76 286 515 minecraft:crying_obsidian
fill 76 286 516 76 291 516 minecraft:polished_blackstone_bricks
setblock 76 286 517 minecraft:crying_obsidian
fill 76 286 518 76 291 518 minecraft:polished_blackstone_bricks
setblock 76 286 519 minecraft:crying_obsidian
fill 76 286 520 76 291 526 minecraft:polished_blackstone_bricks
fill 77 286 511 77 292 511 minecraft:blackstone
setblock 77 286 512 minecraft:crying_obsidian
fill 77 286 513 77 291 513 minecraft:polished_blackstone_bricks
setblock 77 286 514 minecraft:crying_obsidian
fill 77 286 515 77 291 515 minecraft:polished_blackstone_bricks
setblock 77 286 516 minecraft:crying_obsidian
fill 77 286 517 77 291 517 minecraft:polished_blackstone_bricks
setblock 77 286 518 minecraft:crying_obsidian
fill 77 286 519 77 291 519 minecraft:polished_blackstone_bricks
setblock 77 286 520 minecraft:crying_obsidian
fill 77 286 521 87 291 526 minecraft:polished_blackstone_bricks
fill 78 286 510 78 286 511 minecraft:crying_obsidian
fill 78 286 512 78 291 512 minecraft:polished_blackstone_bricks
setblock 78 286 513 minecraft:crying_obsidian
fill 78 286 514 78 291 514 minecraft:polished_blackstone_bricks
setblock 78 286 515 minecraft:crying_obsidian
fill 78 286 516 78 291 516 minecraft:polished_blackstone_bricks
setblock 78 286 517 minecraft:crying_obsidian
fill 78 286 518 78 291 518 minecraft:polished_blackstone_bricks
setblock 78 286 519 minecraft:crying_obsidian
fill 78 286 520 78 291 520 minecraft:polished_blackstone_bricks
fill 79 286 510 81 291 510 minecraft:crying_obsidian
fill 79 286 511 79 292 511 minecraft:blackstone
setblock 79 286 512 minecraft:crying_obsidian
fill 79 286 513 79 291 513 minecraft:polished_blackstone_bricks
setblock 79 286 514 minecraft:crying_obsidian
fill 79 286 515 79 291 515 minecraft:polished_blackstone_bricks
setblock 79 286 516 minecraft:crying_obsidian
fill 79 286 517 79 291 517 minecraft:polished_blackstone_bricks
setblock 79 286 518 minecraft:crying_obsidian
fill 79 286 519 79 291 519 minecraft:polished_blackstone_bricks
setblock 79 286 520 minecraft:crying_obsidian
setblock 80 286 511 minecraft:crying_obsidian
fill 80 286 512 80 291 512 minecraft:polished_blackstone_bricks
setblock 80 286 513 minecraft:crying_obsidian
fill 80 286 514 80 291 514 minecraft:polished_blackstone_bricks
setblock 80 286 515 minecraft:crying_obsidian
fill 80 286 516 80 291 516 minecraft:polished_blackstone_bricks
setblock 80 286 517 minecraft:crying_obsidian
fill 80 286 518 80 291 518 minecraft:polished_blackstone_bricks
setblock 80 286 519 minecraft:crying_obsidian
fill 80 286 520 80 291 520 minecraft:polished_blackstone_bricks
fill 81 286 511 81 292 511 minecraft:blackstone
setblock 81 286 512 minecraft:crying_obsidian
fill 81 286 513 81 291 513 minecraft:polished_blackstone_bricks
setblock 81 286 514 minecraft:crying_obsidian
fill 81 286 515 81 291 515 minecraft:polished_blackstone_bricks
setblock 81 286 516 minecraft:crying_obsidian
fill 81 286 517 81 291 517 minecraft:polished_blackstone_bricks
setblock 81 286 518 minecraft:crying_obsidian
fill 81 286 519 81 291 519 minecraft:polished_blackstone_bricks
setblock 81 286 520 minecraft:crying_obsidian
setblock 82 286 511 minecraft:crying_obsidian
fill 82 286 512 82 291 512 minecraft:polished_blackstone_bricks
setblock 82 286 513 minecraft:crying_obsidian
fill 82 286 514 82 291 514 minecraft:polished_blackstone_bricks
setblock 82 286 515 minecraft:crying_obsidian
fill 82 286 516 82 291 516 minecraft:polished_blackstone_bricks
setblock 82 286 517 minecraft:crying_obsidian
fill 82 286 518 82 291 518 minecraft:polished_blackstone_bricks
setblock 82 286 519 minecraft:crying_obsidian
fill 82 286 520 82 291 520 minecraft:polished_blackstone_bricks
fill 83 286 511 83 292 511 minecraft:blackstone
setblock 83 286 512 minecraft:crying_obsidian
fill 83 286 513 83 291 513 minecraft:polished_blackstone_bricks
setblock 83 286 514 minecraft:crying_obsidian
fill 83 286 515 83 291 515 minecraft:polished_blackstone_bricks
setblock 83 286 516 minecraft:crying_obsidian
fill 83 286 517 83 291 517 minecraft:polished_blackstone_bricks
setblock 83 286 518 minecraft:crying_obsidian
fill 83 286 519 83 291 519 minecraft:polished_blackstone_bricks
setblock 83 286 520 minecraft:crying_obsidian
fill 83 286 552 86 291 552 minecraft:crying_obsidian
setblock 84 286 511 minecraft:crying_obsidian
fill 84 286 512 87 291 512 minecraft:polished_blackstone_bricks
setblock 84 286 513 minecraft:crying_obsidian
fill 84 286 514 87 291 514 minecraft:polished_blackstone_bricks
setblock 84 286 515 minecraft:crying_obsidian
fill 84 286 516 87 291 516 minecraft:polished_blackstone_bricks
setblock 84 286 517 minecraft:crying_obsidian
fill 84 286 518 87 291 518 minecraft:polished_blackstone_bricks
setblock 84 286 519 minecraft:crying_obsidian
fill 84 286 520 87 291 520 minecraft:polished_blackstone_bricks
fill 85 286 511 88 292 511 minecraft:blackstone
fill 85 286 513 87 291 513 minecraft:polished_blackstone_bricks
fill 85 286 515 87 291 515 minecraft:polished_blackstone_bricks
fill 85 286 517 87 291 517 minecraft:polished_blackstone_bricks
fill 85 286 519 87 291 519 minecraft:polished_blackstone_bricks
fill 89 286 511 89 291 514 minecraft:crying_obsidian
fill 89 286 523 89 291 526 minecraft:crying_obsidian
fill 89 286 535 89 291 538 minecraft:crying_obsidian
fill 89 286 547 89 291 550 minecraft:crying_obsidian
fill 62 287 512 62 287 529 minecraft:polished_blackstone_bricks
fill 62 287 530 62 288 531 minecraft:crying_obsidian
fill 62 287 534 62 288 534 minecraft:crying_obsidian
fill 62 287 535 62 287 550 minecraft:polished_blackstone_bricks
fill 63 287 512 63 287 528 minecraft:polished_blackstone_bricks
setblock 63 287 529 minecraft:crying_obsidian
fill 63 287 536 63 289 536 minecraft:crying_obsidian
fill 63 287 537 63 289 550 minecraft:polished_blackstone_bricks
fill 64 287 512 64 287 527 minecraft:polished_blackstone_bricks
setblock 64 287 528 minecraft:crying_obsidian
fill 64 287 537 64 289 537 minecraft:crying_obsidian
fill 64 287 538 64 289 550 minecraft:polished_blackstone_bricks
fill 65 287 512 66 287 526 minecraft:polished_blackstone_bricks
fill 65 287 527 66 287 527 minecraft:crying_obsidian
fill 67 287 512 75 288 525 minecraft:polished_blackstone_bricks
fill 67 287 526 69 288 526 minecraft:crying_obsidian
fill 70 287 526 75 287 526 minecraft:polished_blackstone_bricks
fill 70 287 527 71 287 527 minecraft:crying_obsidian
fill 72 287 527 87 287 527 minecraft:polished_blackstone_bricks
setblock 72 287 528 minecraft:crying_obsidian
fill 72 287 537 72 289 537 minecraft:crying_obsidian
fill 73 287 528 87 287 528 minecraft:polished_blackstone_bricks
setblock 73 287 529 minecraft:crying_obsidian
fill 73 287 536 73 289 536 minecraft:crying_obsidian
fill 73 287 537 87 289 537 minecraft:polished_blackstone_bricks
fill 74 287 529 87 287 529 minecraft:polished_blackstone_bricks
fill 74 287 530 74 288 531 minecraft:crying_obsidian
fill 74 287 534 74 288 534 minecraft:crying_obsidian
fill 74 287 536 87 289 536 minecraft:polished_blackstone_bricks
fill 75 287 530 87 288 531 minecraft:polished_blackstone_bricks
fill 75 287 534 87 288 534 minecraft:polished_blackstone_bricks
fill 76 287 511 76 288 511 minecraft:blackstone
fill 76 287 513 76 288 513 minecraft:polished_blackstone_bricks
fill 76 287 515 76 288 515 minecraft:polished_blackstone_bricks
fill 76 287 517 76 288 517 minecraft:polished_blackstone_bricks
fill 76 287 519 76 288 519 minecraft:polished_blackstone_bricks
fill 77 287 512 77 288 512 minecraft:polished_blackstone_bricks
fill 77 287 514 77 288 514 minecraft:polished_blackstone_bricks
fill 77 287 516 77 288 516 minecraft:polished_blackstone_bricks
fill 77 287 518 77 288 518 minecraft:polished_blackstone_bricks
fill 77 287 520 77 288 520 minecraft:polished_blackstone_bricks
fill 78 287 510 78 291 510 minecraft:crying_obsidian
fill 78 287 511 78 288 511 minecraft:blackstone
fill 78 287 513 78 288 513 minecraft:polished_blackstone_bricks
fill 78 287 515 78 288 515 minecraft:polished_blackstone_bricks
fill 78 287 517 78 288 517 minecraft:polished_blackstone_bricks
fill 78 287 519 78 288 519 minecraft:polished_blackstone_bricks
fill 79 287 512 79 288 512 minecraft:polished_blackstone_bricks
fill 79 287 514 79 288 514 minecraft:polished_blackstone_bricks
fill 79 287 516 79 288 516 minecraft:polished_blackstone_bricks
fill 79 287 518 79 288 518 minecraft:polished_blackstone_bricks
fill 79 287 520 79 288 520 minecraft:polished_blackstone_bricks
fill 80 287 511 80 288 511 minecraft:blackstone
fill 80 287 513 80 288 513 minecraft:polished_blackstone_bricks
fill 80 287 515 80 288 515 minecraft:polished_blackstone_bricks
fill 80 287 517 80 288 517 minecraft:polished_blackstone_bricks
fill 80 287 519 80 288 519 minecraft:polished_blackstone_bricks
fill 81 287 512 81 288 512 minecraft:polished_blackstone_bricks
fill 81 287 514 81 288 514 minecraft:polished_blackstone_bricks
fill 81 287 516 81 288 516 minecraft:polished_blackstone_bricks
fill 81 287 518 81 288 518 minecraft:polished_blackstone_bricks
fill 81 287 520 81 288 520 minecraft:polished_blackstone_bricks
fill 82 287 511 82 288 511 minecraft:blackstone
fill 82 287 513 82 288 513 minecraft:polished_blackstone_bricks
fill 82 287 515 82 288 515 minecraft:polished_blackstone_bricks
fill 82 287 517 82 288 517 minecraft:polished_blackstone_bricks
fill 82 287 519 82 288 519 minecraft:polished_blackstone_bricks
fill 83 287 512 83 288 512 minecraft:polished_blackstone_bricks
fill 83 287 514 83 288 514 minecraft:polished_blackstone_bricks
fill 83 287 516 83 288 516 minecraft:polished_blackstone_bricks
fill 83 287 518 83 288 518 minecraft:polished_blackstone_bricks
fill 83 287 520 83 288 520 minecraft:polished_blackstone_bricks
fill 84 287 511 84 288 511 minecraft:blackstone
fill 84 287 513 84 288 513 minecraft:polished_blackstone_bricks
fill 84 287 515 84 288 515 minecraft:polished_blackstone_bricks
fill 84 287 517 84 288 517 minecraft:polished_blackstone_bricks
fill 84 287 519 84 288 519 minecraft:polished_blackstone_bricks
fill 62 288 512 62 288 528 minecraft:polished_blackstone_bricks
fill 62 288 529 62 289 529 minecraft:crying_obsidian
fill 62 288 535 62 290 535 minecraft:crying_obsidian
fill 62 288 536 62 289 550 minecraft:polished_blackstone_bricks
fill 63 288 512 63 288 527 minecraft:polished_blackstone_bricks
setblock 63 288 528 minecraft:crying_obsidian
fill 64 288 512 64 288 526 minecraft:polished_blackstone_bricks
setblock 64 288 527 minecraft:crying_obsidian
fill 65 288 512 66 288 525 minecraft:polished_blackstone_bricks
fill 65 288 526 66 288 526 minecraft:crying_obsidian
fill 65 288 538 65 290 538 minecraft:crying_obsidian
fill 65 288 539 65 290 550 minecraft:polished_blackstone_bricks
setblock 67 288 538 minecraft:crying_obsidian
fill 67 288 539 67 288 550 minecraft:polished_blackstone_bricks
fill 68 288 539 68 292 539 minecraft:crying_obsidian
fill 68 288 540 87 291 550 minecraft:polished_blackstone_bricks
setblock 69 288 538 minecraft:crying_obsidian
fill 69 288 539 87 288 539 minecraft:polished_blackstone_bricks
fill 70 288 526 71 288 526 minecraft:crying_obsidian
fill 71 288 538 71 290 538 minecraft:crying_obsidian
fill 72 288 526 75 288 526 minecraft:polished_blackstone_bricks
setblock 72 288 527 minecraft:crying_obsidian
fill 72 288 538 87 289 538 minecraft:polished_blackstone_bricks
fill 73 288 527 87 288 527 minecraft:polished_blackstone_bricks
setblock 73 288 528 minecraft:crying_obsidian
fill 74 288 528 87 288 528 minecraft:polished_blackstone_bricks
fill 74 288 529 74 289 529 minecraft:crying_obsidian
fill 74 288 535 74 290 535 minecraft:crying_obsidian
fill 75 288 529 87 289 529 minecraft:polished_blackstone_bricks
fill 75 288 535 87 290 535 minecraft:polished_blackstone_bricks
fill 49 289 512 60 290 550 minecraft:polished_blackstone_bricks
fill 61 289 512 61 289 529 minecraft:polished_blackstone_bricks
fill 61 289 530 61 290 534 minecraft:crying_obsidian
fill 61 289 535 61 290 550 minecraft:polished_blackstone_bricks
fill 62 289 512 62 289 527 minecraft:polished_blackstone_bricks
fill 62 289 528 62 290 528 minecraft:crying_obsidian
fill 63 289 512 63 289 526 minecraft:polished_blackstone_bricks
setblock 63 289 527 minecraft:crying_obsidian
fill 64 289 512 65 289 525 minecraft:polished_blackstone_bricks
fill 64 289 526 65 289 526 minecraft:crying_obsidian
fill 66 289 512 75 289 524 minecraft:polished_blackstone_bricks
fill 66 289 525 70 289 525 minecraft:crying_obsidian
fill 67 289 539 67 292 539 minecraft:crying_obsidian
fill 67 289 540 67 291 550 minecraft:polished_blackstone_bricks
fill 69 289 539 69 292 539 minecraft:crying_obsidian
fill 70 289 539 87 289 539 minecraft:polished_blackstone_bricks
fill 71 289 525 75 289 525 minecraft:polished_blackstone_bricks
fill 71 289 526 72 289 526 minecraft:crying_obsidian
fill 73 289 526 75 289 526 minecraft:polished_blackstone_bricks
setblock 73 289 527 minecraft:crying_obsidian
fill 74 289 527 87 289 527 minecraft:polished_blackstone_bricks
fill 74 289 528 74 290 528 minecraft:crying_obsidian
fill 75 289 528 87 290 528 minecraft:polished_blackstone_bricks
fill 75 289 530 75 290 534 minecraft:crying_obsidian
setblock 76 289 511 minecraft:crying_obsidian
setblock 76 289 513 minecraft:crying_obsidian
setblock 76 289 515 minecraft:crying_obsidian
setblock 76 289 517 minecraft:crying_obsidian
setblock 76 289 519 minecraft:crying_obsidian
fill 76 289 530 87 290 534 minecraft:polished_blackstone_bricks
setblock 77 289 512 minecraft:crying_obsidian
setblock 77 289 514 minecraft:crying_obsidian
setblock 77 289 516 minecraft:crying_obsidian
setblock 77 289 518 minecraft:crying_obsidian
setblock 77 289 520 minecraft:crying_obsidian
setblock 78 289 511 minecraft:crying_obsidian
setblock 78 289 513 minecraft:crying_obsidian
setblock 78 289 515 minecraft:crying_obsidian
setblock 78 289 517 minecraft:crying_obsidian
setblock 78 289 519 minecraft:crying_obsidian
setblock 79 289 512 minecraft:crying_obsidian
setblock 79 289 514 minecraft:crying_obsidian
setblock 79 289 516 minecraft:crying_obsidian
setblock 79 289 518 minecraft:crying_obsidian
setblock 79 289 520 minecraft:crying_obsidian
setblock 80 289 511 minecraft:crying_obsidian
setblock 80 289 513 minecraft:crying_obsidian
setblock 80 289 515 minecraft:crying_obsidian
setblock 80 289 517 minecraft:crying_obsidian
setblock 80 289 519 minecraft:crying_obsidian
setblock 81 289 512 minecraft:crying_obsidian
setblock 81 289 514 minecraft:crying_obsidian
setblock 81 289 516 minecraft:crying_obsidian
setblock 81 289 518 minecraft:crying_obsidian
setblock 81 289 520 minecraft:crying_obsidian
setblock 82 289 511 minecraft:crying_obsidian
setblock 82 289 513 minecraft:crying_obsidian
setblock 82 289 515 minecraft:crying_obsidian
setblock 82 289 517 minecraft:crying_obsidian
setblock 82 289 519 minecraft:crying_obsidian
setblock 83 289 512 minecraft:crying_obsidian
setblock 83 289 514 minecraft:crying_obsidian
setblock 83 289 516 minecraft:crying_obsidian
setblock 83 289 518 minecraft:crying_obsidian
setblock 83 289 520 minecraft:crying_obsidian
setblock 84 289 511 minecraft:crying_obsidian
setblock 84 289 513 minecraft:crying_obsidian
setblock 84 289 515 minecraft:crying_obsidian
setblock 84 289 517 minecraft:crying_obsidian
setblock 84 289 519 minecraft:crying_obsidian
fill 61 290 512 61 290 528 minecraft:polished_blackstone_bricks
fill 61 290 529 61 291 529 minecraft:crying_obsidian
fill 62 290 512 62 290 526 minecraft:polished_blackstone_bricks
fill 62 290 527 62 291 527 minecraft:crying_obsidian
fill 62 290 536 62 291 536 minecraft:crying_obsidian
fill 62 290 537 62 291 550 minecraft:polished_blackstone_bricks
fill 63 290 512 63 290 525 minecraft:polished_blackstone_bricks
setblock 63 290 526 minecraft:crying_obsidian
fill 63 290 537 63 291 537 minecraft:crying_obsidian
fill 63 290 538 63 291 550 minecraft:polished_blackstone_bricks
fill 64 290 512 65 290 524 minecraft:polished_blackstone_bricks
fill 64 290 525 65 290 525 minecraft:crying_obsidian
fill 64 290 538 64 292 538 minecraft:crying_obsidian
fill 64 290 539 64 291 550 minecraft:polished_blackstone_bricks
fill 66 290 512 75 291 523 minecraft:polished_blackstone_bricks
fill 66 290 524 70 291 524 minecraft:crying_obsidian
setblock 66 290 529 minecraft:light[level=11]
setblock 66 290 537 minecraft:light[level=11]
fill 66 290 539 66 292 539 minecraft:crying_obsidian
fill 66 290 540 66 291 550 minecraft:polished_blackstone_bricks
fill 70 290 539 70 292 539 minecraft:crying_obsidian
fill 71 290 524 75 290 524 minecraft:polished_blackstone_bricks
fill 71 290 525 72 290 525 minecraft:crying_obsidian
fill 71 290 539 87 290 539 minecraft:polished_blackstone_bricks
fill 72 290 538 72 292 538 minecraft:crying_obsidian
fill 73 290 525 75 290 525 minecraft:polished_blackstone_bricks
setblock 73 290 526 minecraft:crying_obsidian
fill 73 290 537 73 291 537 minecraft:crying_obsidian
fill 73 290 538 87 291 538 minecraft:polished_blackstone_bricks
fill 74 290 526 75 290 526 minecraft:polished_blackstone_bricks
fill 74 290 527 74 291 527 minecraft:crying_obsidian
setblock 74 290 529 minecraft:light[level=11]
fill 74 290 536 74 291 536 minecraft:crying_obsidian
fill 74 290 537 87 291 537 minecraft:polished_blackstone_bricks
fill 75 290 527 87 291 527 minecraft:polished_blackstone_bricks
fill 75 290 529 75 291 529 minecraft:crying_obsidian
fill 75 290 536 87 291 536 minecraft:polished_blackstone_bricks
fill 76 290 511 76 291 511 minecraft:blackstone
fill 76 290 513 76 291 513 minecraft:polished_blackstone_bricks
fill 76 290 515 76 291 515 minecraft:polished_blackstone_bricks
fill 76 290 517 76 291 517 minecraft:polished_blackstone_bricks
fill 76 290 519 76 291 519 minecraft:polished_blackstone_bricks
fill 76 290 529 87 291 529 minecraft:polished_blackstone_bricks
fill 77 290 512 77 291 512 minecraft:polished_blackstone_bricks
fill 77 290 514 77 291 514 minecraft:polished_blackstone_bricks
fill 77 290 516 77 291 516 minecraft:polished_blackstone_bricks
fill 77 290 518 77 291 518 minecraft:polished_blackstone_bricks
fill 77 290 520 77 291 520 minecraft:polished_blackstone_bricks
fill 78 290 511 78 291 511 minecraft:blackstone
fill 78 290 513 78 291 513 minecraft:polished_blackstone_bricks
fill 78 290 515 78 291 515 minecraft:polished_blackstone_bricks
fill 78 290 517 78 291 517 minecraft:polished_blackstone_bricks
fill 78 290 519 78 291 519 minecraft:polished_blackstone_bricks
fill 79 290 512 79 291 512 minecraft:polished_blackstone_bricks
fill 79 290 514 79 291 514 minecraft:polished_blackstone_bricks
fill 79 290 516 79 291 516 minecraft:polished_blackstone_bricks
fill 79 290 518 79 291 518 minecraft:polished_blackstone_bricks
fill 79 290 520 79 291 520 minecraft:polished_blackstone_bricks
fill 80 290 511 80 291 511 minecraft:blackstone
fill 80 290 513 80 291 513 minecraft:polished_blackstone_bricks
fill 80 290 515 80 291 515 minecraft:polished_blackstone_bricks
fill 80 290 517 80 291 517 minecraft:polished_blackstone_bricks
fill 80 290 519 80 291 519 minecraft:polished_blackstone_bricks
fill 81 290 512 81 291 512 minecraft:polished_blackstone_bricks
fill 81 290 514 81 291 514 minecraft:polished_blackstone_bricks
fill 81 290 516 81 291 516 minecraft:polished_blackstone_bricks
fill 81 290 518 81 291 518 minecraft:polished_blackstone_bricks
fill 81 290 520 81 291 520 minecraft:polished_blackstone_bricks
fill 82 290 511 82 291 511 minecraft:blackstone
fill 82 290 513 82 291 513 minecraft:polished_blackstone_bricks
fill 82 290 515 82 291 515 minecraft:polished_blackstone_bricks
fill 82 290 517 82 291 517 minecraft:polished_blackstone_bricks
fill 82 290 519 82 291 519 minecraft:polished_blackstone_bricks
fill 83 290 512 83 291 512 minecraft:polished_blackstone_bricks
fill 83 290 514 83 291 514 minecraft:polished_blackstone_bricks
fill 83 290 516 83 291 516 minecraft:polished_blackstone_bricks
fill 83 290 518 83 291 518 minecraft:polished_blackstone_bricks
fill 83 290 520 83 291 520 minecraft:polished_blackstone_bricks
fill 84 290 511 84 291 511 minecraft:blackstone
fill 84 290 513 84 291 513 minecraft:polished_blackstone_bricks
fill 84 290 515 84 291 515 minecraft:polished_blackstone_bricks
fill 84 290 517 84 291 517 minecraft:polished_blackstone_bricks
fill 84 290 519 84 291 519 minecraft:polished_blackstone_bricks
fill 49 291 512 59 291 550 minecraft:polished_blackstone_bricks
fill 60 291 512 60 291 529 minecraft:polished_blackstone_bricks
fill 60 291 530 60 292 533 minecraft:crying_obsidian
fill 60 291 534 60 291 550 minecraft:polished_blackstone_bricks
fill 61 291 512 61 291 527 minecraft:polished_blackstone_bricks
setblock 61 291 528 minecraft:crying_obsidian
fill 61 291 534 61 291 535 minecraft:crying_obsidian
fill 61 291 536 61 291 550 minecraft:polished_blackstone_bricks
fill 62 291 512 62 291 525 minecraft:polished_blackstone_bricks
fill 62 291 526 62 292 526 minecraft:crying_obsidian
fill 63 291 512 64 291 524 minecraft:polished_blackstone_bricks
fill 63 291 525 64 291 525 minecraft:crying_obsidian
fill 65 291 512 65 291 523 minecraft:polished_blackstone_bricks
setblock 65 291 524 minecraft:crying_obsidian
fill 65 291 539 65 292 539 minecraft:crying_obsidian
fill 65 291 540 65 291 550 minecraft:polished_blackstone_bricks
setblock 71 291 524 minecraft:crying_obsidian
fill 71 291 539 71 292 539 minecraft:crying_obsidian
fill 72 291 524 75 291 524 minecraft:polished_blackstone_bricks
fill 72 291 525 73 291 525 minecraft:crying_obsidian
fill 72 291 539 87 291 539 minecraft:polished_blackstone_bricks
fill 74 291 525 75 291 525 minecraft:polished_blackstone_bricks
fill 74 291 526 74 292 526 minecraft:crying_obsidian
setblock 75 291 526 minecraft:polished_blackstone_bricks
setblock 75 291 528 minecraft:crying_obsidian
fill 75 291 534 75 291 535 minecraft:crying_obsidian
fill 76 291 528 87 291 528 minecraft:polished_blackstone_bricks
fill 76 291 530 76 292 533 minecraft:crying_obsidian
fill 76 291 534 87 291 535 minecraft:polished_blackstone_bricks
fill 77 291 530 87 291 533 minecraft:polished_blackstone_bricks
fill 47 292 516 47 307 516 minecraft:blackstone
fill 47 292 517 47 292 518 minecraft:crying_obsidian
fill 47 292 519 47 307 519 minecraft:blackstone
fill 47 292 528 47 307 528 minecraft:blackstone
fill 47 292 529 47 292 530 minecraft:crying_obsidian
fill 47 292 531 47 307 531 minecraft:blackstone
fill 47 292 540 47 307 540 minecraft:blackstone
fill 47 292 541 47 292 542 minecraft:crying_obsidian
fill 47 292 543 47 307 543 minecraft:blackstone
fill 47 292 552 47 307 552 minecraft:blackstone
fill 48 292 552 49 292 552 minecraft:crying_obsidian
fill 49 292 512 59 292 550 minecraft:blackstone
fill 50 292 552 50 307 552 minecraft:blackstone
fill 54 292 510 54 307 510 minecraft:blackstone
fill 55 292 510 56 292 510 minecraft:crying_obsidian
fill 57 292 510 57 307 510 minecraft:blackstone
fill 59 292 552 59 307 552 minecraft:blackstone
fill 60 292 512 60 292 527 minecraft:blackstone
fill 60 292 528 60 292 529 minecraft:crying_obsidian
setblock 60 292 534 minecraft:crying_obsidian
fill 60 292 535 60 292 550 minecraft:blackstone
fill 60 292 552 61 292 552 minecraft:crying_obsidian
fill 61 292 512 61 292 526 minecraft:blackstone
setblock 61 292 527 minecraft:crying_obsidian
fill 61 292 535 61 292 536 minecraft:crying_obsidian
fill 61 292 537 61 292 550 minecraft:blackstone
fill 62 292 512 62 292 525 minecraft:blackstone
setblock 62 292 537 minecraft:crying_obsidian
fill 62 292 538 62 292 550 minecraft:blackstone
fill 62 292 552 62 307 552 minecraft:blackstone
fill 63 292 512 63 292 524 minecraft:blackstone
setblock 63 292 525 minecraft:crying_obsidian
setblock 63 292 538 minecraft:crying_obsidian
fill 63 292 539 64 292 550 minecraft:blackstone
fill 64 292 512 64 292 523 minecraft:blackstone
setblock 64 292 524 minecraft:crying_obsidian
fill 65 292 512 75 292 522 minecraft:blackstone
fill 65 292 523 71 292 523 minecraft:crying_obsidian
fill 65 292 540 87 292 550 minecraft:blackstone
fill 66 292 510 66 307 510 minecraft:blackstone
fill 67 292 510 68 292 510 minecraft:crying_obsidian
fill 69 292 510 69 307 510 minecraft:blackstone
fill 71 292 552 71 307 552 minecraft:blackstone
fill 72 292 523 87 292 523 minecraft:blackstone
setblock 72 292 524 minecraft:crying_obsidian
fill 72 292 539 87 292 539 minecraft:blackstone
fill 72 292 552 73 292 552 minecraft:crying_obsidian
fill 73 292 524 87 292 524 minecraft:blackstone
setblock 73 292 525 minecraft:crying_obsidian
setblock 73 292 538 minecraft:crying_obsidian
fill 74 292 525 87 292 525 minecraft:blackstone
setblock 74 292 537 minecraft:crying_obsidian
fill 74 292 538 87 292 538 minecraft:blackstone
fill 74 292 552 74 307 552 minecraft:blackstone
fill 75 292 526 87 292 526 minecraft:blackstone
setblock 75 292 527 minecraft:crying_obsidian
fill 75 292 535 75 292 536 minecraft:crying_obsidian
fill 75 292 537 87 292 537 minecraft:blackstone
setblock 76 292 511 minecraft:crying_obsidian
setblock 76 292 512 minecraft:blackstone
setblock 76 292 513 minecraft:crying_obsidian
setblock 76 292 514 minecraft:blackstone
setblock 76 292 515 minecraft:crying_obsidian
setblock 76 292 516 minecraft:blackstone
setblock 76 292 517 minecraft:crying_obsidian
setblock 76 292 518 minecraft:blackstone
setblock 76 292 519 minecraft:crying_obsidian
fill 76 292 520 76 292 522 minecraft:blackstone
fill 76 292 527 87 292 527 minecraft:blackstone
fill 76 292 528 76 292 529 minecraft:crying_obsidian
setblock 76 292 534 minecraft:crying_obsidian
fill 76 292 535 87 292 536 minecraft:blackstone
setblock 77 292 512 minecraft:crying_obsidian
setblock 77 292 513 minecraft:blackstone
setblock 77 292 514 minecraft:crying_obsidian
setblock 77 292 515 minecraft:blackstone
setblock 77 292 516 minecraft:crying_obsidian
setblock 77 292 517 minecraft:blackstone
setblock 77 292 518 minecraft:crying_obsidian
setblock 77 292 519 minecraft:blackstone
setblock 77 292 520 minecraft:crying_obsidian
fill 77 292 521 87 292 522 minecraft:blackstone
fill 77 292 528 87 292 534 minecraft:blackstone
fill 78 292 510 78 307 510 minecraft:blackstone
setblock 78 292 511 minecraft:crying_obsidian
setblock 78 292 512 minecraft:blackstone
setblock 78 292 513 minecraft:crying_obsidian
setblock 78 292 514 minecraft:blackstone
setblock 78 292 515 minecraft:crying_obsidian
setblock 78 292 516 minecraft:blackstone
setblock 78 292 517 minecraft:crying_obsidian
setblock 78 292 518 minecraft:blackstone
setblock 78 292 519 minecraft:crying_obsidian
setblock 78 292 520 minecraft:blackstone
fill 79 292 510 80 292 510 minecraft:crying_obsidian
setblock 79 292 512 minecraft:crying_obsidian
setblock 79 292 513 minecraft:blackstone
setblock 79 292 514 minecraft:crying_obsidian
setblock 79 292 515 minecraft:blackstone
setblock 79 292 516 minecraft:crying_obsidian
setblock 79 292 517 minecraft:blackstone
setblock 79 292 518 minecraft:crying_obsidian
setblock 79 292 519 minecraft:blackstone
setblock 79 292 520 minecraft:crying_obsidian
setblock 80 292 511 minecraft:crying_obsidian
setblock 80 292 512 minecraft:blackstone
setblock 80 292 513 minecraft:crying_obsidian
setblock 80 292 514 minecraft:blackstone
setblock 80 292 515 minecraft:crying_obsidian
setblock 80 292 516 minecraft:blackstone
setblock 80 292 517 minecraft:crying_obsidian
setblock 80 292 518 minecraft:blackstone
setblock 80 292 519 minecraft:crying_obsidian
setblock 80 292 520 minecraft:blackstone
fill 81 292 510 81 307 510 minecraft:blackstone
setblock 81 292 512 minecraft:crying_obsidian
setblock 81 292 513 minecraft:blackstone
setblock 81 292 514 minecraft:crying_obsidian
setblock 81 292 515 minecraft:blackstone
setblock 81 292 516 minecraft:crying_obsidian
setblock 81 292 517 minecraft:blackstone
setblock 81 292 518 minecraft:crying_obsidian
setblock 81 292 519 minecraft:blackstone
setblock 81 292 520 minecraft:crying_obsidian
setblock 82 292 511 minecraft:crying_obsidian
setblock 82 292 512 minecraft:blackstone
setblock 82 292 513 minecraft:crying_obsidian
setblock 82 292 514 minecraft:blackstone
setblock 82 292 515 minecraft:crying_obsidian
setblock 82 292 516 minecraft:blackstone
setblock 82 292 517 minecraft:crying_obsidian
setblock 82 292 518 minecraft:blackstone
setblock 82 292 519 minecraft:crying_obsidian
setblock 82 292 520 minecraft:blackstone
setblock 83 292 512 minecraft:crying_obsidian
setblock 83 292 513 minecraft:blackstone
setblock 83 292 514 minecraft:crying_obsidian
setblock 83 292 515 minecraft:blackstone
setblock 83 292 516 minecraft:crying_obsidian
setblock 83 292 517 minecraft:blackstone
setblock 83 292 518 minecraft:crying_obsidian
setblock 83 292 519 minecraft:blackstone
setblock 83 292 520 minecraft:crying_obsidian
fill 83 292 552 83 307 552 minecraft:blackstone
setblock 84 292 511 minecraft:crying_obsidian
fill 84 292 512 87 292 512 minecraft:blackstone
setblock 84 292 513 minecraft:crying_obsidian
fill 84 292 514 87 292 514 minecraft:blackstone
setblock 84 292 515 minecraft:crying_obsidian
fill 84 292 516 87 292 516 minecraft:blackstone
setblock 84 292 517 minecraft:crying_obsidian
fill 84 292 518 87 292 518 minecraft:blackstone
setblock 84 292 519 minecraft:crying_obsidian
fill 84 292 520 87 292 520 minecraft:blackstone
fill 84 292 552 85 292 552 minecraft:crying_obsidian
fill 85 292 513 87 292 513 minecraft:blackstone
fill 85 292 515 87 292 515 minecraft:blackstone
fill 85 292 517 87 292 517 minecraft:blackstone
fill 85 292 519 87 292 519 minecraft:blackstone
fill 86 292 552 86 307 552 minecraft:blackstone
fill 89 292 511 89 307 511 minecraft:blackstone
fill 89 292 512 89 292 513 minecraft:crying_obsidian
fill 89 292 514 89 307 514 minecraft:blackstone
fill 89 292 523 89 307 523 minecraft:blackstone
fill 89 292 524 89 292 525 minecraft:crying_obsidian
fill 89 292 526 89 307 526 minecraft:blackstone
fill 89 292 535 89 307 535 minecraft:blackstone
fill 89 292 536 89 292 537 minecraft:crying_obsidian
fill 89 292 538 89 307 538 minecraft:blackstone
fill 89 292 547 89 307 547 minecraft:blackstone
fill 89 292 548 89 292 549 minecraft:crying_obsidian
fill 89 292 550 89 307 550 minecraft:blackstone
fill 47 293 517 47 307 518 minecraft:blackstone
fill 47 293 529 47 307 530 minecraft:blackstone
fill 47 293 541 47 307 542 minecraft:blackstone
fill 48 293 511 50 300 511 minecraft:polished_blackstone_bricks
fill 48 293 521 48 300 523 minecraft:polished_blackstone_bricks
fill 48 293 533 48 300 535 minecraft:polished_blackstone_bricks
fill 48 293 545 48 300 547 minecraft:polished_blackstone_bricks
fill 48 293 552 49 307 552 minecraft:blackstone
fill 50 293 514 52 300 516 minecraft:polished_blackstone_bricks
fill 51 293 526 53 295 526 minecraft:purple_stained_glass
fill 52 293 525 52 295 525 minecraft:purple_stained_glass
fill 52 293 527 52 295 527 minecraft:purple_stained_glass
fill 53 293 515 53 300 515 minecraft:polished_blackstone_bricks
fill 54 293 551 56 300 551 minecraft:polished_blackstone_bricks
fill 55 293 510 56 307 510 minecraft:blackstone
fill 60 293 511 62 300 511 minecraft:polished_blackstone_bricks
fill 60 293 552 61 307 552 minecraft:blackstone
fill 63 293 512 67 293 512 minecraft:purple_wool
fill 66 293 511 68 294 511 minecraft:polished_blackstone_bricks
fill 66 293 550 68 294 551 minecraft:polished_blackstone_bricks
fill 67 293 510 68 307 510 minecraft:blackstone
fill 72 293 511 74 300 511 minecraft:polished_blackstone_bricks
fill 72 293 552 73 307 552 minecraft:blackstone
fill 76 293 511 84 294 520 minecraft:polished_blackstone_bricks
fill 78 293 551 80 300 551 minecraft:polished_blackstone_bricks
fill 79 293 510 80 307 510 minecraft:blackstone
fill 84 293 546 86 300 548 minecraft:polished_blackstone_bricks
fill 84 293 552 85 307 552 minecraft:blackstone
fill 85 293 511 86 300 511 minecraft:polished_blackstone_bricks
fill 85 293 545 85 300 545 minecraft:polished_blackstone_bricks
fill 88 293 519 88 300 521 minecraft:polished_blackstone_bricks
fill 88 293 531 88 300 533 minecraft:polished_blackstone_bricks
fill 88 293 543 88 300 545 minecraft:polished_blackstone_bricks
fill 89 293 512 89 307 513 minecraft:blackstone
fill 89 293 524 89 307 525 minecraft:blackstone
fill 89 293 536 89 307 537 minecraft:blackstone
fill 89 293 548 89 307 549 minecraft:blackstone
fill 63 294 512 65 294 512 minecraft:purple_wool
fill 66 294 512 68 295 512 minecraft:polished_blackstone_bricks
fill 66 294 549 68 295 549 minecraft:polished_blackstone_bricks
fill 67 294 513 67 297 513 minecraft:polished_blackstone_bricks
fill 67 294 548 67 297 548 minecraft:polished_blackstone_bricks
fill 62 295 512 65 296 512 minecraft:iron_bars
fill 66 295 513 66 296 513 minecraft:polished_blackstone_bricks
fill 66 295 548 66 296 548 minecraft:polished_blackstone_bricks
fill 66 295 551 68 300 551 minecraft:polished_blackstone_bricks
setblock 67 295 511 minecraft:polished_blackstone_bricks
fill 67 295 514 67 297 514 minecraft:polished_blackstone_bricks
fill 67 295 547 67 297 547 minecraft:polished_blackstone_bricks
setblock 67 295 550 minecraft:polished_blackstone_bricks
fill 68 295 513 68 296 513 minecraft:polished_blackstone_bricks
fill 68 295 548 68 296 548 minecraft:polished_blackstone_bricks
setblock 76 295 511 minecraft:crying_obsidian
fill 76 295 512 76 300 512 minecraft:polished_blackstone_bricks
setblock 76 295 513 minecraft:crying_obsidian
fill 76 295 514 76 300 514 minecraft:polished_blackstone_bricks
setblock 76 295 515 minecraft:crying_obsidian
fill 76 295 516 76 300 516 minecraft:polished_blackstone_bricks
setblock 76 295 517 minecraft:crying_obsidian
fill 76 295 518 76 300 518 minecraft:polished_blackstone_bricks
setblock 76 295 519 minecraft:crying_obsidian
fill 76 295 520 76 300 520 minecraft:polished_blackstone_bricks
fill 77 295 511 77 300 511 minecraft:polished_blackstone_bricks
setblock 77 295 512 minecraft:crying_obsidian
fill 77 295 513 77 300 513 minecraft:polished_blackstone_bricks
setblock 77 295 514 minecraft:crying_obsidian
fill 77 295 515 77 300 515 minecraft:polished_blackstone_bricks
setblock 77 295 516 minecraft:crying_obsidian
fill 77 295 517 77 300 517 minecraft:polished_blackstone_bricks
setblock 77 295 518 minecraft:crying_obsidian
fill 77 295 519 77 300 519 minecraft:polished_blackstone_bricks
setblock 77 295 520 minecraft:crying_obsidian
setblock 78 295 511 minecraft:crying_obsidian
fill 78 295 512 78 300 512 minecraft:polished_blackstone_bricks
setblock 78 295 513 minecraft:crying_obsidian
fill 78 295 514 78 300 514 minecraft:polished_blackstone_bricks
setblock 78 295 515 minecraft:crying_obsidian
fill 78 295 516 78 300 516 minecraft:polished_blackstone_bricks
setblock 78 295 517 minecraft:crying_obsidian
fill 78 295 518 78 300 518 minecraft:polished_blackstone_bricks
setblock 78 295 519 minecraft:crying_obsidian
fill 78 295 520 78 300 520 minecraft:polished_blackstone_bricks
fill 79 295 511 79 300 511 minecraft:polished_blackstone_bricks
setblock 79 295 512 minecraft:crying_obsidian
fill 79 295 513 79 300 513 minecraft:polished_blackstone_bricks
setblock 79 295 514 minecraft:crying_obsidian
fill 79 295 515 79 300 515 minecraft:polished_blackstone_bricks
setblock 79 295 516 minecraft:crying_obsidian
fill 79 295 517 79 300 517 minecraft:polished_blackstone_bricks
setblock 79 295 518 minecraft:crying_obsidian
fill 79 295 519 79 300 519 minecraft:polished_blackstone_bricks
setblock 79 295 520 minecraft:crying_obsidian
setblock 80 295 511 minecraft:crying_obsidian
fill 80 295 512 80 300 512 minecraft:polished_blackstone_bricks
setblock 80 295 513 minecraft:crying_obsidian
fill 80 295 514 80 300 514 minecraft:polished_blackstone_bricks
setblock 80 295 515 minecraft:crying_obsidian
fill 80 295 516 80 300 516 minecraft:polished_blackstone_bricks
setblock 80 295 517 minecraft:crying_obsidian
fill 80 295 518 80 300 518 minecraft:polished_blackstone_bricks
setblock 80 295 519 minecraft:crying_obsidian
fill 80 295 520 80 300 520 minecraft:polished_blackstone_bricks
fill 81 295 511 81 300 511 minecraft:polished_blackstone_bricks
setblock 81 295 512 minecraft:crying_obsidian
fill 81 295 513 81 300 513 minecraft:polished_blackstone_bricks
setblock 81 295 514 minecraft:crying_obsidian
fill 81 295 515 81 300 515 minecraft:polished_blackstone_bricks
setblock 81 295 516 minecraft:crying_obsidian
fill 81 295 517 81 300 517 minecraft:polished_blackstone_bricks
setblock 81 295 518 minecraft:crying_obsidian
fill 81 295 519 81 300 519 minecraft:polished_blackstone_bricks
setblock 81 295 520 minecraft:crying_obsidian
setblock 82 295 511 minecraft:crying_obsidian
fill 82 295 512 82 300 512 minecraft:polished_blackstone_bricks
setblock 82 295 513 minecraft:crying_obsidian
fill 82 295 514 82 300 514 minecraft:polished_blackstone_bricks
setblock 82 295 515 minecraft:crying_obsidian
fill 82 295 516 82 300 516 minecraft:polished_blackstone_bricks
setblock 82 295 517 minecraft:crying_obsidian
fill 82 295 518 82 300 518 minecraft:polished_blackstone_bricks
setblock 82 295 519 minecraft:crying_obsidian
fill 82 295 520 82 300 520 minecraft:polished_blackstone_bricks
fill 83 295 511 83 300 511 minecraft:polished_blackstone_bricks
setblock 83 295 512 minecraft:crying_obsidian
fill 83 295 513 83 300 513 minecraft:polished_blackstone_bricks
setblock 83 295 514 minecraft:crying_obsidian
fill 83 295 515 83 300 515 minecraft:polished_blackstone_bricks
setblock 83 295 516 minecraft:crying_obsidian
fill 83 295 517 83 300 517 minecraft:polished_blackstone_bricks
setblock 83 295 518 minecraft:crying_obsidian
fill 83 295 519 83 300 519 minecraft:polished_blackstone_bricks
setblock 83 295 520 minecraft:crying_obsidian
setblock 84 295 511 minecraft:crying_obsidian
fill 84 295 512 84 300 512 minecraft:polished_blackstone_bricks
setblock 84 295 513 minecraft:crying_obsidian
fill 84 295 514 84 300 514 minecraft:polished_blackstone_bricks
setblock 84 295 515 minecraft:crying_obsidian
fill 84 295 516 84 300 516 minecraft:polished_blackstone_bricks
setblock 84 295 517 minecraft:crying_obsidian
fill 84 295 518 84 300 518 minecraft:polished_blackstone_bricks
setblock 84 295 519 minecraft:crying_obsidian
fill 84 295 520 84 300 520 minecraft:polished_blackstone_bricks
setblock 66 296 512 minecraft:iron_bars
fill 66 296 514 66 297 515 minecraft:polished_blackstone_bricks
fill 66 296 546 66 297 547 minecraft:polished_blackstone_bricks
setblock 67 296 511 minecraft:purple_stained_glass
setblock 67 296 512 minecraft:polished_blackstone_bricks
fill 67 296 515 68 297 515 minecraft:polished_blackstone_bricks
fill 67 296 546 68 297 546 minecraft:polished_blackstone_bricks
setblock 67 296 549 minecraft:polished_blackstone_bricks
setblock 67 296 550 minecraft:purple_stained_glass
setblock 68 296 512 minecraft:iron_bars
fill 68 296 514 68 297 514 minecraft:polished_blackstone_bricks
fill 68 296 547 68 297 547 minecraft:polished_blackstone_bricks
fill 76 296 511 76 297 511 minecraft:polished_blackstone_bricks
fill 76 296 513 76 297 513 minecraft:polished_blackstone_bricks
fill 76 296 515 76 297 515 minecraft:polished_blackstone_bricks
fill 76 296 517 76 297 517 minecraft:polished_blackstone_bricks
fill 76 296 519 76 297 519 minecraft:polished_blackstone_bricks
fill 77 296 512 77 297 512 minecraft:polished_blackstone_bricks
fill 77 296 514 77 297 514 minecraft:polished_blackstone_bricks
fill 77 296 516 77 297 516 minecraft:polished_blackstone_bricks
fill 77 296 518 77 297 518 minecraft:polished_blackstone_bricks
fill 77 296 520 77 297 520 minecraft:polished_blackstone_bricks
fill 78 296 511 78 297 511 minecraft:polished_blackstone_bricks
fill 78 296 513 78 297 513 minecraft:polished_blackstone_bricks
fill 78 296 515 78 297 515 minecraft:polished_blackstone_bricks
fill 78 296 517 78 297 517 minecraft:polished_blackstone_bricks
fill 78 296 519 78 297 519 minecraft:polished_blackstone_bricks
fill 79 296 512 79 297 512 minecraft:polished_blackstone_bricks
fill 79 296 514 79 297 514 minecraft:polished_blackstone_bricks
fill 79 296 516 79 297 516 minecraft:polished_blackstone_bricks
fill 79 296 518 79 297 518 minecraft:polished_blackstone_bricks
fill 79 296 520 79 297 520 minecraft:polished_blackstone_bricks
fill 80 296 511 80 297 511 minecraft:polished_blackstone_bricks
fill 80 296 513 80 297 513 minecraft:polished_blackstone_bricks
fill 80 296 515 80 297 515 minecraft:polished_blackstone_bricks
fill 80 296 517 80 297 517 minecraft:polished_blackstone_bricks
fill 80 296 519 80 297 519 minecraft:polished_blackstone_bricks
fill 81 296 512 81 297 512 minecraft:polished_blackstone_bricks
fill 81 296 514 81 297 514 minecraft:polished_blackstone_bricks
fill 81 296 516 81 297 516 minecraft:polished_blackstone_bricks
fill 81 296 518 81 297 518 minecraft:polished_blackstone_bricks
fill 81 296 520 81 297 520 minecraft:polished_blackstone_bricks
fill 82 296 511 82 297 511 minecraft:polished_blackstone_bricks
fill 82 296 513 82 297 513 minecraft:polished_blackstone_bricks
fill 82 296 515 82 297 515 minecraft:polished_blackstone_bricks
fill 82 296 517 82 297 517 minecraft:polished_blackstone_bricks
fill 82 296 519 82 297 519 minecraft:polished_blackstone_bricks
fill 83 296 512 83 297 512 minecraft:polished_blackstone_bricks
fill 83 296 514 83 297 514 minecraft:polished_blackstone_bricks
fill 83 296 516 83 297 516 minecraft:polished_blackstone_bricks
fill 83 296 518 83 297 518 minecraft:polished_blackstone_bricks
fill 83 296 520 83 297 520 minecraft:polished_blackstone_bricks
fill 84 296 511 84 297 511 minecraft:polished_blackstone_bricks
fill 84 296 513 84 297 513 minecraft:polished_blackstone_bricks
fill 84 296 515 84 297 515 minecraft:polished_blackstone_bricks
fill 84 296 517 84 297 517 minecraft:polished_blackstone_bricks
fill 84 296 519 84 297 519 minecraft:polished_blackstone_bricks
fill 48 297 519 48 298 520 minecraft:polished_blackstone_bricks
fill 66 297 516 68 298 516 minecraft:polished_blackstone_bricks
fill 66 297 545 68 298 545 minecraft:polished_blackstone_bricks
setblock 67 297 512 minecraft:purple_stained_glass
fill 67 297 517 67 299 517 minecraft:polished_blackstone_bricks
fill 67 297 544 67 299 544 minecraft:polished_blackstone_bricks
setblock 67 297 549 minecraft:purple_stained_glass
fill 87 297 519 87 298 521 minecraft:polished_blackstone_bricks
fill 49 298 519 49 299 521 minecraft:polished_blackstone_bricks
setblock 50 298 513 minecraft:light[level=11]
fill 50 298 520 50 300 520 minecraft:polished_blackstone_bricks
setblock 50 298 521 minecraft:light[level=11]
setblock 50 298 529 minecraft:light[level=11]
setblock 50 298 537 minecraft:light[level=11]
setblock 50 298 545 minecraft:light[level=11]
setblock 58 298 513 minecraft:light[level=11]
setblock 58 298 521 minecraft:light[level=11]
setblock 58 298 529 minecraft:light[level=11]
setblock 58 298 537 minecraft:light[level=11]
setblock 58 298 545 minecraft:light[level=11]
setblock 66 298 513 minecraft:light[level=11]
fill 66 298 517 66 299 517 minecraft:polished_blackstone_bricks
setblock 66 298 521 minecraft:light[level=11]
setblock 66 298 529 minecraft:light[level=11]
setblock 66 298 537 minecraft:light[level=11]
fill 66 298 544 66 299 544 minecraft:polished_blackstone_bricks
setblock 67 298 514 minecraft:purple_stained_glass
setblock 67 298 515 minecraft:polished_blackstone_bricks
fill 67 298 518 67 300 518 minecraft:polished_blackstone_bricks
fill 67 298 543 67 300 543 minecraft:polished_blackstone_bricks
setblock 67 298 546 minecraft:polished_blackstone_bricks
setblock 67 298 547 minecraft:purple_stained_glass
fill 68 298 517 68 299 517 minecraft:polished_blackstone_bricks
fill 68 298 544 68 299 544 minecraft:polished_blackstone_bricks
setblock 74 298 513 minecraft:light[level=11]
setblock 74 298 521 minecraft:light[level=11]
setblock 74 298 529 minecraft:light[level=11]
setblock 74 298 537 minecraft:light[level=11]
setblock 74 298 545 minecraft:light[level=11]
setblock 76 298 511 minecraft:crying_obsidian
setblock 76 298 513 minecraft:crying_obsidian
setblock 76 298 515 minecraft:crying_obsidian
setblock 76 298 517 minecraft:crying_obsidian
setblock 76 298 519 minecraft:crying_obsidian
setblock 77 298 512 minecraft:crying_obsidian
setblock 77 298 514 minecraft:crying_obsidian
setblock 77 298 516 minecraft:crying_obsidian
setblock 77 298 518 minecraft:crying_obsidian
setblock 77 298 520 minecraft:crying_obsidian
setblock 78 298 511 minecraft:crying_obsidian
setblock 78 298 513 minecraft:crying_obsidian
setblock 78 298 515 minecraft:crying_obsidian
setblock 78 298 517 minecraft:crying_obsidian
setblock 78 298 519 minecraft:crying_obsidian
setblock 79 298 512 minecraft:crying_obsidian
setblock 79 298 514 minecraft:crying_obsidian
setblock 79 298 516 minecraft:crying_obsidian
setblock 79 298 518 minecraft:crying_obsidian
setblock 79 298 520 minecraft:crying_obsidian
setblock 80 298 511 minecraft:crying_obsidian
setblock 80 298 513 minecraft:crying_obsidian
setblock 80 298 515 minecraft:crying_obsidian
setblock 80 298 517 minecraft:crying_obsidian
setblock 80 298 519 minecraft:crying_obsidian
setblock 81 298 512 minecraft:crying_obsidian
setblock 81 298 514 minecraft:crying_obsidian
setblock 81 298 516 minecraft:crying_obsidian
setblock 81 298 518 minecraft:crying_obsidian
setblock 81 298 520 minecraft:crying_obsidian
setblock 82 298 511 minecraft:crying_obsidian
setblock 82 298 513 minecraft:crying_obsidian
setblock 82 298 515 minecraft:crying_obsidian
setblock 82 298 517 minecraft:crying_obsidian
setblock 82 298 519 minecraft:crying_obsidian
setblock 82 298 521 minecraft:light[level=11]
setblock 82 298 529 minecraft:light[level=11]
setblock 82 298 537 minecraft:light[level=11]
setblock 82 298 545 minecraft:light[level=11]
setblock 83 298 512 minecraft:crying_obsidian
setblock 83 298 514 minecraft:crying_obsidian
setblock 83 298 516 minecraft:crying_obsidian
setblock 83 298 518 minecraft:crying_obsidian
setblock 83 298 520 minecraft:crying_obsidian
setblock 84 298 511 minecraft:crying_obsidian
setblock 84 298 513 minecraft:crying_obsidian
setblock 84 298 515 minecraft:crying_obsidian
setblock 84 298 517 minecraft:crying_obsidian
setblock 84 298 519 minecraft:crying_obsidian
fill 85 298 520 86 300 520 minecraft:polished_blackstone_bricks
fill 86 298 519 86 299 519 minecraft:polished_blackstone_bricks
fill 86 298 521 86 299 521 minecraft:polished_blackstone_bricks
setblock 48 299 520 minecraft:polished_blackstone_bricks
fill 48 299 543 54 299 543 minecraft:blackstone
fill 49 299 514 49 300 515 minecraft:purple_stained_glass
fill 50 299 513 52 300 513 minecraft:purple_stained_glass
fill 50 299 519 50 300 519 minecraft:polished_blackstone_bricks
fill 50 299 521 50 300 521 minecraft:polished_blackstone_bricks
fill 50 299 541 54 300 542 minecraft:blackstone
fill 50 299 544 54 300 545 minecraft:blackstone
fill 51 299 517 52 300 517 minecraft:purple_stained_glass
fill 51 299 520 51 300 520 minecraft:polished_blackstone_bricks
setblock 52 299 526 minecraft:crying_obsidian
fill 53 299 514 53 300 514 minecraft:purple_stained_glass
fill 53 299 516 53 300 516 minecraft:purple_stained_glass
fill 66 299 518 66 299 519 minecraft:polished_blackstone_bricks
fill 66 299 542 66 299 543 minecraft:polished_blackstone_bricks
setblock 67 299 515 minecraft:purple_stained_glass
setblock 67 299 516 minecraft:polished_blackstone_bricks
fill 67 299 519 67 300 520 minecraft:polished_blackstone_bricks
fill 67 299 541 67 300 542 minecraft:polished_blackstone_bricks
setblock 67 299 545 minecraft:polished_blackstone_bricks
setblock 67 299 546 minecraft:purple_stained_glass
fill 68 299 518 68 299 519 minecraft:polished_blackstone_bricks
fill 68 299 542 68 299 543 minecraft:polished_blackstone_bricks
fill 76 299 511 76 300 511 minecraft:polished_blackstone_bricks
fill 76 299 513 76 300 513 minecraft:polished_blackstone_bricks
fill 76 299 515 76 300 515 minecraft:polished_blackstone_bricks
fill 76 299 517 76 300 517 minecraft:polished_blackstone_bricks
fill 76 299 519 76 300 519 minecraft:polished_blackstone_bricks
fill 77 299 512 77 300 512 minecraft:polished_blackstone_bricks
fill 77 299 514 77 300 514 minecraft:polished_blackstone_bricks
fill 77 299 516 77 300 516 minecraft:polished_blackstone_bricks
fill 77 299 518 77 300 518 minecraft:polished_blackstone_bricks
fill 77 299 520 77 300 520 minecraft:polished_blackstone_bricks
fill 78 299 511 78 300 511 minecraft:polished_blackstone_bricks
fill 78 299 513 78 300 513 minecraft:polished_blackstone_bricks
fill 78 299 515 78 300 515 minecraft:polished_blackstone_bricks
fill 78 299 517 78 300 517 minecraft:polished_blackstone_bricks
fill 78 299 519 78 300 519 minecraft:polished_blackstone_bricks
fill 79 299 512 79 300 512 minecraft:polished_blackstone_bricks
fill 79 299 514 79 300 514 minecraft:polished_blackstone_bricks
fill 79 299 516 79 300 516 minecraft:polished_blackstone_bricks
fill 79 299 518 79 300 518 minecraft:polished_blackstone_bricks
fill 79 299 520 79 300 520 minecraft:polished_blackstone_bricks
fill 80 299 511 80 300 511 minecraft:polished_blackstone_bricks
fill 80 299 513 80 300 513 minecraft:polished_blackstone_bricks
fill 80 299 515 80 300 515 minecraft:polished_blackstone_bricks
fill 80 299 517 80 300 517 minecraft:polished_blackstone_bricks
fill 80 299 519 80 300 519 minecraft:polished_blackstone_bricks
fill 81 299 512 81 300 512 minecraft:polished_blackstone_bricks
fill 81 299 514 81 300 514 minecraft:polished_blackstone_bricks
fill 81 299 516 81 300 516 minecraft:polished_blackstone_bricks
fill 81 299 518 81 300 518 minecraft:polished_blackstone_bricks
fill 81 299 520 81 300 520 minecraft:polished_blackstone_bricks
fill 82 299 511 82 300 511 minecraft:polished_blackstone_bricks
fill 82 299 513 82 300 513 minecraft:polished_blackstone_bricks
fill 82 299 515 82 300 515 minecraft:polished_blackstone_bricks
fill 82 299 517 82 300 517 minecraft:polished_blackstone_bricks
fill 82 299 519 82 300 519 minecraft:polished_blackstone_bricks
fill 83 299 512 83 300 512 minecraft:polished_blackstone_bricks
fill 83 299 514 83 300 514 minecraft:polished_blackstone_bricks
fill 83 299 516 83 300 516 minecraft:polished_blackstone_bricks
fill 83 299 518 83 300 518 minecraft:polished_blackstone_bricks
fill 83 299 520 83 300 520 minecraft:polished_blackstone_bricks
fill 83 299 546 83 300 548 minecraft:purple_stained_glass
fill 84 299 511 84 300 511 minecraft:polished_blackstone_bricks
fill 84 299 513 84 300 513 minecraft:polished_blackstone_bricks
fill 84 299 515 84 300 515 minecraft:polished_blackstone_bricks
fill 84 299 517 84 300 517 minecraft:polished_blackstone_bricks
fill 84 299 519 85 300 519 minecraft:polished_blackstone_bricks
fill 84 299 545 84 300 545 minecraft:purple_stained_glass
fill 85 299 521 85 300 521 minecraft:polished_blackstone_bricks
fill 85 299 549 85 300 549 minecraft:purple_stained_glass
fill 86 299 545 86 300 545 minecraft:purple_stained_glass
fill 87 299 520 87 300 520 minecraft:polished_blackstone_bricks
fill 87 299 546 87 299 548 minecraft:purple_stained_glass
setblock 48 300 520 minecraft:purple_stained_glass
fill 49 300 520 49 300 522 minecraft:polished_blackstone_bricks
fill 49 300 532 49 300 534 minecraft:polished_blackstone_bricks
fill 49 300 544 49 300 546 minecraft:polished_blackstone_bricks
fill 50 300 543 54 300 543 minecraft:blackstone
setblock 51 300 519 minecraft:polished_blackstone_bricks
setblock 51 300 521 minecraft:polished_blackstone_bricks
setblock 52 300 520 minecraft:polished_blackstone_bricks
fill 55 300 550 57 300 550 minecraft:polished_blackstone_bricks
fill 59 300 512 61 300 512 minecraft:polished_blackstone_bricks
fill 66 300 519 66 300 521 minecraft:polished_blackstone_bricks
fill 66 300 540 66 300 542 minecraft:polished_blackstone_bricks
setblock 67 300 517 minecraft:purple_stained_glass
fill 67 300 521 67 300 522 minecraft:polished_blackstone_bricks
fill 67 300 539 67 300 540 minecraft:polished_blackstone_bricks
setblock 67 300 544 minecraft:purple_stained_glass
fill 67 300 550 69 300 550 minecraft:polished_blackstone_bricks
fill 68 300 519 68 300 521 minecraft:polished_blackstone_bricks
fill 68 300 540 68 300 542 minecraft:polished_blackstone_bricks
fill 71 300 512 73 300 512 minecraft:polished_blackstone_bricks
fill 79 300 550 81 300 550 minecraft:polished_blackstone_bricks
setblock 84 300 521 minecraft:polished_blackstone_bricks
setblock 85 300 512 minecraft:polished_blackstone_bricks
fill 87 300 521 87 300 522 minecraft:polished_blackstone_bricks
fill 87 300 532 87 300 534 minecraft:polished_blackstone_bricks
fill 87 300 544 87 300 546 minecraft:polished_blackstone_bricks
fill 87 300 547 87 300 548 minecraft:purple_stained_glass
