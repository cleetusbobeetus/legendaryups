setblock 130 44 549 minecraft:smooth_basalt
fill 130 44 550 130 47 550 minecraft:blackstone
fill 131 44 549 131 45 549 minecraft:blackstone
setblock 133 44 511 minecraft:smooth_basalt
setblock 133 44 551 minecraft:smooth_basalt
setblock 134 44 511 minecraft:blackstone
setblock 134 44 530 minecraft:smooth_basalt
fill 134 44 531 134 47 531 minecraft:blackstone
setblock 134 44 535 minecraft:smooth_basalt
setblock 134 44 536 minecraft:blackstone
setblock 134 44 550 minecraft:smooth_basalt
fill 134 44 551 134 46 551 minecraft:blackstone
setblock 135 44 529 minecraft:smooth_basalt
fill 135 44 530 135 47 530 minecraft:blackstone
setblock 135 44 534 minecraft:smooth_basalt
fill 135 44 535 135 47 535 minecraft:blackstone
setblock 135 44 539 minecraft:smooth_basalt
setblock 135 44 544 minecraft:smooth_basalt
setblock 135 44 545 minecraft:blackstone
setblock 135 44 549 minecraft:smooth_basalt
fill 135 44 550 135 45 550 minecraft:blackstone
setblock 95 45 528 minecraft:smooth_basalt
fill 95 45 529 95 48 529 minecraft:blackstone
setblock 95 45 533 minecraft:smooth_basalt
fill 95 45 534 95 48 534 minecraft:blackstone
setblock 96 45 527 minecraft:smooth_basalt
setblock 96 45 528 minecraft:blackstone
setblock 96 45 532 minecraft:smooth_basalt
setblock 96 45 533 minecraft:blackstone
fill 100 45 511 100 46 511 minecraft:blackstone
setblock 102 45 511 minecraft:smooth_basalt
setblock 102 45 551 minecraft:smooth_basalt
fill 103 45 511 103 48 511 minecraft:blackstone
fill 103 45 551 103 48 551 minecraft:blackstone
setblock 105 45 513 minecraft:smooth_basalt
setblock 106 45 512 minecraft:smooth_basalt
fill 106 45 513 106 48 513 minecraft:blackstone
setblock 107 45 511 minecraft:smooth_basalt
fill 107 45 512 107 48 512 minecraft:blackstone
setblock 107 45 551 minecraft:smooth_basalt
fill 108 45 511 108 48 511 minecraft:blackstone
setblock 108 45 550 minecraft:smooth_basalt
fill 108 45 551 111 45 551 minecraft:blackstone
fill 109 45 550 109 47 550 minecraft:blackstone
setblock 110 45 513 minecraft:smooth_basalt
setblock 111 45 512 minecraft:smooth_basalt
fill 111 45 513 111 48 513 minecraft:blackstone
setblock 112 45 511 minecraft:smooth_basalt
fill 112 45 512 112 48 512 minecraft:blackstone
setblock 112 45 551 minecraft:smooth_basalt
fill 113 45 511 116 45 511 minecraft:blackstone
setblock 113 45 550 minecraft:smooth_basalt
fill 113 45 551 116 45 551 minecraft:blackstone
setblock 116 45 512 minecraft:smooth_basalt
setblock 117 45 511 minecraft:smooth_basalt
setblock 117 45 551 minecraft:smooth_basalt
fill 118 45 511 118 48 511 minecraft:blackstone
fill 118 45 551 118 48 551 minecraft:blackstone
setblock 122 45 511 minecraft:smooth_basalt
fill 122 45 512 125 45 512 minecraft:blackstone
setblock 122 45 551 minecraft:smooth_basalt
fill 123 45 511 123 48 511 minecraft:blackstone
setblock 123 45 550 minecraft:smooth_basalt
fill 123 45 551 123 48 551 minecraft:blackstone
setblock 124 45 549 minecraft:smooth_basalt
fill 124 45 550 124 48 550 minecraft:blackstone
fill 125 45 549 125 48 549 minecraft:blackstone
setblock 126 45 512 minecraft:smooth_basalt
setblock 127 45 511 minecraft:smooth_basalt
fill 127 45 512 127 48 512 minecraft:blackstone
setblock 127 45 551 minecraft:smooth_basalt
fill 128 45 511 128 48 511 minecraft:blackstone
setblock 128 45 550 minecraft:smooth_basalt
fill 128 45 551 128 48 551 minecraft:blackstone
setblock 129 45 549 minecraft:smooth_basalt
fill 129 45 550 129 48 550 minecraft:blackstone
setblock 130 45 549 minecraft:blackstone
setblock 132 45 511 minecraft:smooth_basalt
setblock 132 45 551 minecraft:smooth_basalt
fill 133 45 511 133 46 511 minecraft:blackstone
setblock 133 45 550 minecraft:smooth_basalt
fill 133 45 551 133 47 551 minecraft:blackstone
setblock 134 45 529 minecraft:smooth_basalt
fill 134 45 530 134 46 530 minecraft:blackstone
setblock 134 45 534 minecraft:smooth_basalt
fill 134 45 535 134 48 535 minecraft:blackstone
setblock 135 45 528 minecraft:smooth_basalt
fill 135 45 529 135 48 529 minecraft:blackstone
setblock 135 45 533 minecraft:smooth_basalt
fill 135 45 534 135 48 534 minecraft:blackstone
setblock 135 45 538 minecraft:smooth_basalt
setblock 135 45 548 minecraft:smooth_basalt
setblock 135 45 549 minecraft:blackstone
setblock 95 46 527 minecraft:smooth_basalt
fill 95 46 528 95 49 528 minecraft:blackstone
setblock 95 46 532 minecraft:smooth_basalt
fill 95 46 533 95 49 533 minecraft:blackstone
setblock 96 46 531 minecraft:smooth_basalt
setblock 96 46 532 minecraft:blackstone
setblock 101 46 511 minecraft:smooth_basalt
fill 102 46 511 102 48 512 minecraft:blackstone
fill 102 46 551 102 49 551 minecraft:blackstone
setblock 104 46 513 minecraft:smooth_basalt
setblock 105 46 512 minecraft:smooth_basalt
fill 105 46 513 105 49 513 minecraft:blackstone
setblock 106 46 511 minecraft:smooth_basalt
fill 106 46 512 106 49 512 minecraft:blackstone
setblock 106 46 551 minecraft:smooth_basalt
fill 107 46 511 107 49 511 minecraft:blackstone
setblock 107 46 550 minecraft:smooth_basalt
fill 107 46 551 110 46 551 minecraft:blackstone
fill 108 46 550 108 48 550 minecraft:blackstone
setblock 109 46 513 minecraft:smooth_basalt
setblock 110 46 512 minecraft:smooth_basalt
fill 110 46 513 110 49 513 minecraft:blackstone
setblock 111 46 511 minecraft:smooth_basalt
fill 111 46 512 111 49 512 minecraft:blackstone
setblock 111 46 551 minecraft:smooth_basalt
fill 112 46 511 115 46 511 minecraft:blackstone
fill 112 46 551 115 46 551 minecraft:blackstone
setblock 115 46 512 minecraft:smooth_basalt
setblock 116 46 511 minecraft:smooth_basalt
setblock 116 46 551 minecraft:smooth_basalt
fill 117 46 511 117 49 511 minecraft:blackstone
fill 117 46 551 117 49 551 minecraft:blackstone
setblock 121 46 511 minecraft:smooth_basalt
fill 121 46 512 124 46 512 minecraft:blackstone
setblock 121 46 551 minecraft:smooth_basalt
fill 122 46 511 122 49 511 minecraft:blackstone
setblock 122 46 550 minecraft:smooth_basalt
fill 122 46 551 122 49 551 minecraft:blackstone
fill 123 46 550 123 49 550 minecraft:blackstone
setblock 124 46 549 minecraft:blackstone
setblock 125 46 512 minecraft:smooth_basalt
setblock 126 46 511 minecraft:smooth_basalt
fill 126 46 512 126 49 512 minecraft:blackstone
setblock 126 46 551 minecraft:smooth_basalt
fill 127 46 511 127 49 511 minecraft:blackstone
setblock 127 46 550 minecraft:smooth_basalt
fill 127 46 551 127 49 551 minecraft:blackstone
setblock 128 46 549 minecraft:smooth_basalt
fill 128 46 550 128 49 550 minecraft:blackstone
setblock 129 46 549 minecraft:blackstone
setblock 130 46 512 minecraft:smooth_basalt
setblock 131 46 511 minecraft:smooth_basalt
setblock 131 46 551 minecraft:smooth_basalt
fill 132 46 511 132 48 511 minecraft:blackstone
setblock 132 46 550 minecraft:smooth_basalt
fill 132 46 551 132 49 551 minecraft:blackstone
setblock 134 46 533 minecraft:smooth_basalt
fill 134 46 534 134 49 534 minecraft:blackstone
setblock 135 46 528 minecraft:blackstone
setblock 135 46 532 minecraft:smooth_basalt
fill 135 46 533 135 49 533 minecraft:blackstone
setblock 135 46 537 minecraft:smooth_basalt
fill 135 46 538 135 49 538 minecraft:blackstone
setblock 95 47 527 minecraft:blackstone
setblock 95 47 531 minecraft:smooth_basalt
fill 95 47 532 95 50 532 minecraft:blackstone
setblock 95 47 536 minecraft:smooth_basalt
setblock 99 47 511 minecraft:blackstone
setblock 100 47 511 minecraft:smooth_basalt
fill 101 47 511 101 49 512 minecraft:blackstone
setblock 103 47 513 minecraft:smooth_basalt
setblock 104 47 512 minecraft:smooth_basalt
fill 104 47 513 104 50 513 minecraft:blackstone
setblock 105 47 511 minecraft:smooth_basalt
fill 105 47 512 105 50 512 minecraft:blackstone
setblock 105 47 551 minecraft:smooth_basalt
fill 106 47 511 106 50 511 minecraft:blackstone
setblock 106 47 550 minecraft:smooth_basalt
fill 106 47 551 109 47 551 minecraft:blackstone
fill 107 47 550 107 48 550 minecraft:blackstone
setblock 108 47 513 minecraft:smooth_basalt
setblock 109 47 512 minecraft:smooth_basalt
fill 109 47 513 109 50 513 minecraft:blackstone
setblock 110 47 511 minecraft:smooth_basalt
fill 110 47 512 110 50 512 minecraft:blackstone
setblock 110 47 551 minecraft:smooth_basalt
fill 111 47 511 114 47 511 minecraft:blackstone
fill 111 47 551 114 47 551 minecraft:blackstone
setblock 114 47 512 minecraft:smooth_basalt
setblock 115 47 511 minecraft:smooth_basalt
fill 115 47 512 115 50 512 minecraft:blackstone
setblock 115 47 551 minecraft:smooth_basalt
fill 116 47 511 116 50 511 minecraft:blackstone
fill 116 47 551 116 50 551 minecraft:blackstone
setblock 120 47 511 minecraft:smooth_basalt
fill 120 47 512 123 47 512 minecraft:blackstone
setblock 120 47 551 minecraft:smooth_basalt
fill 121 47 511 121 50 511 minecraft:blackstone
setblock 121 47 550 minecraft:smooth_basalt
fill 121 47 551 121 50 551 minecraft:blackstone
fill 122 47 550 122 50 550 minecraft:blackstone
setblock 124 47 512 minecraft:smooth_basalt
setblock 125 47 511 minecraft:smooth_basalt
fill 125 47 512 125 50 512 minecraft:blackstone
setblock 125 47 551 minecraft:smooth_basalt
fill 126 47 511 126 50 511 minecraft:blackstone
setblock 126 47 550 minecraft:smooth_basalt
fill 126 47 551 126 50 551 minecraft:blackstone
setblock 127 47 549 minecraft:smooth_basalt
fill 127 47 550 127 50 550 minecraft:blackstone
setblock 128 47 549 minecraft:blackstone
setblock 129 47 512 minecraft:smooth_basalt
setblock 130 47 511 minecraft:smooth_basalt
setblock 130 47 551 minecraft:smooth_basalt
fill 131 47 511 131 50 511 minecraft:blackstone
setblock 131 47 550 minecraft:smooth_basalt
fill 131 47 551 131 50 551 minecraft:blackstone
setblock 134 47 532 minecraft:smooth_basalt
fill 134 47 533 134 50 533 minecraft:blackstone
setblock 135 47 531 minecraft:smooth_basalt
fill 135 47 532 135 50 532 minecraft:blackstone
setblock 135 47 536 minecraft:smooth_basalt
fill 135 47 537 135 50 537 minecraft:blackstone
setblock 95 48 530 minecraft:smooth_basalt
fill 95 48 531 95 51 531 minecraft:blackstone
setblock 95 48 535 minecraft:smooth_basalt
fill 95 48 536 95 51 536 minecraft:blackstone
setblock 97 48 513 minecraft:light[level=12]
setblock 97 48 521 minecraft:light[level=12]
setblock 97 48 529 minecraft:light[level=12]
setblock 97 48 537 minecraft:light[level=12]
setblock 98 48 511 minecraft:blackstone
setblock 99 48 511 minecraft:smooth_basalt
fill 100 48 511 100 50 512 minecraft:blackstone
setblock 102 48 513 minecraft:smooth_basalt
setblock 103 48 512 minecraft:smooth_basalt
fill 103 48 513 103 51 513 minecraft:blackstone
setblock 104 48 511 minecraft:smooth_basalt
fill 104 48 512 104 51 512 minecraft:blackstone
setblock 104 48 551 minecraft:smooth_basalt
fill 105 48 511 105 51 511 minecraft:blackstone
setblock 105 48 521 minecraft:light[level=12]
setblock 105 48 529 minecraft:light[level=12]
setblock 105 48 537 minecraft:light[level=12]
setblock 105 48 545 minecraft:light[level=12]
fill 105 48 551 108 48 551 minecraft:blackstone
setblock 106 48 514 minecraft:smooth_basalt
setblock 107 48 513 minecraft:smooth_basalt
fill 107 48 514 107 51 514 minecraft:blackstone
setblock 108 48 512 minecraft:smooth_basalt
fill 108 48 513 108 51 513 minecraft:blackstone
setblock 109 48 511 minecraft:smooth_basalt
fill 109 48 512 109 51 512 minecraft:blackstone
setblock 109 48 551 minecraft:smooth_basalt
fill 110 48 511 113 48 511 minecraft:blackstone
fill 110 48 551 113 48 551 minecraft:blackstone
setblock 113 48 512 minecraft:smooth_basalt
setblock 113 48 513 minecraft:light[level=12]
setblock 113 48 521 minecraft:light[level=12]
setblock 113 48 529 minecraft:light[level=12]
setblock 113 48 537 minecraft:light[level=12]
setblock 113 48 545 minecraft:light[level=12]
setblock 114 48 511 minecraft:smooth_basalt
fill 114 48 512 114 51 512 minecraft:blackstone
setblock 114 48 551 minecraft:smooth_basalt
fill 115 48 511 115 51 511 minecraft:blackstone
fill 115 48 551 115 51 551 minecraft:blackstone
setblock 119 48 511 minecraft:smooth_basalt
fill 119 48 512 122 48 512 minecraft:blackstone
setblock 119 48 551 minecraft:smooth_basalt
fill 120 48 511 120 51 511 minecraft:blackstone
setblock 120 48 550 minecraft:smooth_basalt
fill 120 48 551 120 51 551 minecraft:blackstone
setblock 121 48 513 minecraft:light[level=12]
setblock 121 48 521 minecraft:light[level=12]
setblock 121 48 529 minecraft:light[level=12]
setblock 121 48 537 minecraft:light[level=12]
setblock 121 48 545 minecraft:light[level=12]
fill 121 48 550 121 51 550 minecraft:blackstone
setblock 123 48 512 minecraft:smooth_basalt
setblock 124 48 511 minecraft:smooth_basalt
fill 124 48 512 124 51 512 minecraft:blackstone
setblock 124 48 551 minecraft:smooth_basalt
fill 125 48 511 125 51 511 minecraft:blackstone
setblock 125 48 550 minecraft:smooth_basalt
fill 125 48 551 125 51 551 minecraft:blackstone
setblock 126 48 549 minecraft:smooth_basalt
fill 126 48 550 126 51 550 minecraft:blackstone
setblock 128 48 512 minecraft:smooth_basalt
setblock 129 48 511 minecraft:smooth_basalt
fill 129 48 512 129 50 512 minecraft:blackstone
setblock 129 48 513 minecraft:light[level=12]
setblock 129 48 521 minecraft:light[level=12]
setblock 129 48 529 minecraft:light[level=12]
setblock 129 48 537 minecraft:light[level=12]
setblock 129 48 545 minecraft:light[level=12]
setblock 129 48 551 minecraft:smooth_basalt
fill 130 48 511 130 51 511 minecraft:blackstone
setblock 130 48 550 minecraft:smooth_basalt
fill 130 48 551 130 51 551 minecraft:blackstone
fill 134 48 532 134 51 532 minecraft:blackstone
setblock 134 48 536 minecraft:smooth_basalt
setblock 135 48 530 minecraft:smooth_basalt
fill 135 48 531 135 51 531 minecraft:blackstone
setblock 135 48 535 minecraft:smooth_basalt
fill 135 48 536 135 51 536 minecraft:blackstone
setblock 135 48 539 minecraft:blackstone
setblock 95 49 529 minecraft:smooth_basalt
fill 95 49 530 95 52 530 minecraft:blackstone
setblock 95 49 534 minecraft:smooth_basalt
fill 95 49 535 95 52 535 minecraft:blackstone
fill 95 49 537 95 50 537 minecraft:blackstone
setblock 97 49 511 minecraft:blackstone
setblock 98 49 511 minecraft:smooth_basalt
fill 99 49 511 99 51 512 minecraft:blackstone
setblock 101 49 513 minecraft:smooth_basalt
setblock 102 49 511 minecraft:blackstone
setblock 102 49 512 minecraft:smooth_basalt
fill 102 49 513 102 52 513 minecraft:blackstone
setblock 103 49 511 minecraft:smooth_basalt
fill 103 49 512 103 52 512 minecraft:blackstone
setblock 103 49 551 minecraft:smooth_basalt
fill 104 49 511 104 52 511 minecraft:blackstone
setblock 104 49 514 minecraft:blackstone
fill 104 49 551 107 49 551 minecraft:blackstone
setblock 105 49 514 minecraft:smooth_basalt
setblock 106 49 513 minecraft:smooth_basalt
fill 106 49 514 106 52 514 minecraft:blackstone
setblock 107 49 512 minecraft:smooth_basalt
fill 107 49 513 107 52 513 minecraft:blackstone
setblock 108 49 511 minecraft:smooth_basalt
fill 108 49 512 108 52 512 minecraft:blackstone
fill 108 49 514 108 50 514 minecraft:blackstone
setblock 108 49 551 minecraft:smooth_basalt
fill 109 49 511 112 49 511 minecraft:blackstone
fill 109 49 551 112 49 551 minecraft:blackstone
setblock 111 49 513 minecraft:smooth_basalt
setblock 112 49 512 minecraft:smooth_basalt
setblock 113 49 511 minecraft:smooth_basalt
fill 113 49 512 113 52 512 minecraft:blackstone
setblock 113 49 551 minecraft:smooth_basalt
fill 114 49 511 114 52 511 minecraft:blackstone
fill 114 49 551 114 52 551 minecraft:blackstone
setblock 116 49 512 minecraft:blackstone
setblock 117 49 512 minecraft:smooth_basalt
setblock 118 49 511 minecraft:smooth_basalt
fill 118 49 512 121 49 512 minecraft:blackstone
setblock 118 49 551 minecraft:smooth_basalt
fill 119 49 511 119 52 511 minecraft:blackstone
fill 119 49 551 119 52 551 minecraft:blackstone
fill 120 49 550 120 52 550 minecraft:blackstone
setblock 122 49 512 minecraft:smooth_basalt
setblock 123 49 511 minecraft:smooth_basalt
fill 123 49 512 123 52 512 minecraft:blackstone
setblock 123 49 551 minecraft:smooth_basalt
fill 124 49 511 124 52 511 minecraft:blackstone
setblock 124 49 550 minecraft:smooth_basalt
fill 124 49 551 124 52 551 minecraft:blackstone
setblock 125 49 549 minecraft:smooth_basalt
fill 125 49 550 125 52 550 minecraft:blackstone
setblock 127 49 512 minecraft:smooth_basalt
setblock 128 49 511 minecraft:smooth_basalt
fill 128 49 512 128 52 512 minecraft:blackstone
setblock 128 49 551 minecraft:smooth_basalt
fill 129 49 511 129 52 511 minecraft:blackstone
setblock 129 49 550 minecraft:smooth_basalt
fill 129 49 551 129 52 551 minecraft:blackstone
setblock 134 49 535 minecraft:smooth_basalt
fill 134 49 536 134 51 537 minecraft:blackstone
setblock 135 49 529 minecraft:smooth_basalt
fill 135 49 530 135 52 530 minecraft:blackstone
setblock 135 49 534 minecraft:smooth_basalt
fill 135 49 535 135 52 535 minecraft:blackstone
setblock 135 49 539 minecraft:smooth_basalt
setblock 95 50 512 minecraft:blackstone
setblock 95 50 513 minecraft:smooth_basalt
fill 95 50 514 95 50 517 minecraft:blackstone
setblock 95 50 528 minecraft:smooth_basalt
fill 95 50 529 95 53 529 minecraft:blackstone
setblock 95 50 533 minecraft:smooth_basalt
fill 95 50 534 96 52 534 minecraft:blackstone
setblock 95 50 538 minecraft:smooth_basalt
setblock 96 50 511 minecraft:blackstone
setblock 96 50 532 minecraft:smooth_basalt
fill 96 50 533 96 53 533 minecraft:blackstone
setblock 97 50 511 minecraft:smooth_basalt
fill 98 50 511 98 52 512 minecraft:blackstone
setblock 100 50 513 minecraft:smooth_basalt
setblock 101 50 511 minecraft:blackstone
setblock 101 50 512 minecraft:smooth_basalt
fill 101 50 513 101 53 513 minecraft:blackstone
setblock 101 50 551 minecraft:blackstone
setblock 102 50 511 minecraft:smooth_basalt
fill 102 50 512 102 53 512 minecraft:blackstone
fill 102 50 514 103 50 514 minecraft:blackstone
setblock 102 50 551 minecraft:smooth_basalt
fill 103 50 511 103 53 511 minecraft:blackstone
fill 103 50 551 106 50 551 minecraft:blackstone
setblock 104 50 514 minecraft:smooth_basalt
setblock 105 50 513 minecraft:smooth_basalt
fill 105 50 514 105 53 514 minecraft:blackstone
setblock 106 50 512 minecraft:smooth_basalt
fill 106 50 513 106 53 513 minecraft:blackstone
fill 106 50 550 106 51 550 minecraft:blackstone
setblock 107 50 511 minecraft:smooth_basalt
fill 107 50 512 107 53 512 minecraft:blackstone
setblock 107 50 551 minecraft:smooth_basalt
fill 108 50 511 111 50 511 minecraft:blackstone
fill 108 50 551 111 50 551 minecraft:blackstone
setblock 110 50 513 minecraft:smooth_basalt
setblock 111 50 512 minecraft:smooth_basalt
fill 111 50 513 111 53 513 minecraft:blackstone
setblock 112 50 511 minecraft:smooth_basalt
fill 112 50 512 112 53 512 minecraft:blackstone
setblock 112 50 551 minecraft:smooth_basalt
fill 113 50 511 113 53 511 minecraft:blackstone
fill 113 50 551 113 53 551 minecraft:blackstone
setblock 116 50 512 minecraft:smooth_basalt
setblock 117 50 511 minecraft:smooth_basalt
fill 117 50 512 120 50 512 minecraft:blackstone
setblock 117 50 551 minecraft:smooth_basalt
fill 118 50 511 118 53 511 minecraft:blackstone
fill 118 50 551 118 53 551 minecraft:blackstone
setblock 121 50 512 minecraft:smooth_basalt
setblock 122 50 511 minecraft:smooth_basalt
fill 122 50 512 122 52 513 minecraft:blackstone
setblock 122 50 551 minecraft:smooth_basalt
fill 123 50 511 123 53 511 minecraft:blackstone
fill 123 50 513 124 50 513 minecraft:blackstone
setblock 123 50 550 minecraft:smooth_basalt
fill 123 50 551 123 53 551 minecraft:blackstone
fill 124 50 550 124 53 550 minecraft:blackstone
setblock 125 50 513 minecraft:smooth_basalt
setblock 126 50 512 minecraft:smooth_basalt
setblock 127 50 511 minecraft:smooth_basalt
fill 127 50 512 127 53 512 minecraft:blackstone
setblock 127 50 551 minecraft:smooth_basalt
fill 128 50 511 128 53 511 minecraft:blackstone
setblock 128 50 550 minecraft:smooth_basalt
fill 128 50 551 128 53 551 minecraft:blackstone
setblock 129 50 550 minecraft:blackstone
setblock 134 50 534 minecraft:smooth_basalt
fill 134 50 535 134 53 535 minecraft:blackstone
setblock 134 50 538 minecraft:blackstone
fill 135 50 529 135 53 529 minecraft:blackstone
setblock 135 50 533 minecraft:smooth_basalt
fill 135 50 534 135 53 534 minecraft:blackstone
setblock 135 50 538 minecraft:smooth_basalt
fill 135 50 539 135 52 540 minecraft:blackstone
setblock 95 51 511 minecraft:blackstone
setblock 95 51 512 minecraft:smooth_basalt
fill 95 51 513 95 51 516 minecraft:blackstone
setblock 95 51 517 minecraft:smooth_basalt
fill 95 51 518 95 52 520 minecraft:blackstone
fill 95 51 528 95 54 528 minecraft:blackstone
setblock 95 51 532 minecraft:smooth_basalt
fill 95 51 533 95 54 533 minecraft:blackstone
setblock 95 51 537 minecraft:smooth_basalt
fill 95 51 538 95 53 539 minecraft:blackstone
setblock 96 51 511 minecraft:smooth_basalt
fill 96 51 514 96 51 515 minecraft:blackstone
setblock 96 51 516 minecraft:smooth_basalt
fill 96 51 532 96 54 532 minecraft:blackstone
setblock 96 51 535 minecraft:blackstone
setblock 96 51 536 minecraft:smooth_basalt
fill 97 51 511 97 53 512 minecraft:blackstone
setblock 99 51 513 minecraft:smooth_basalt
setblock 100 51 511 minecraft:blackstone
setblock 100 51 512 minecraft:smooth_basalt
fill 100 51 513 100 54 513 minecraft:blackstone
setblock 100 51 551 minecraft:blackstone
setblock 101 51 511 minecraft:smooth_basalt
fill 101 51 512 101 54 512 minecraft:blackstone
fill 101 51 514 102 51 514 minecraft:blackstone
setblock 101 51 551 minecraft:smooth_basalt
fill 102 51 511 102 54 511 minecraft:blackstone
fill 102 51 551 105 51 551 minecraft:blackstone
setblock 103 51 514 minecraft:smooth_basalt
setblock 104 51 513 minecraft:smooth_basalt
fill 104 51 514 104 54 514 minecraft:blackstone
setblock 105 51 512 minecraft:smooth_basalt
fill 105 51 513 105 54 513 minecraft:blackstone
fill 105 51 550 105 52 550 minecraft:blackstone
setblock 106 51 511 minecraft:smooth_basalt
fill 106 51 512 106 54 512 minecraft:blackstone
setblock 106 51 551 minecraft:smooth_basalt
fill 107 51 511 110 51 511 minecraft:blackstone
fill 107 51 551 110 51 551 minecraft:blackstone
setblock 108 51 514 minecraft:smooth_basalt
setblock 109 51 513 minecraft:smooth_basalt
fill 109 51 514 109 52 514 minecraft:blackstone
setblock 110 51 512 minecraft:smooth_basalt
fill 110 51 513 110 54 513 minecraft:blackstone
setblock 111 51 511 minecraft:smooth_basalt
fill 111 51 512 111 54 512 minecraft:blackstone
setblock 111 51 551 minecraft:smooth_basalt
fill 112 51 511 112 54 511 minecraft:blackstone
fill 112 51 551 112 54 551 minecraft:blackstone
setblock 115 51 512 minecraft:smooth_basalt
setblock 116 51 511 minecraft:smooth_basalt
fill 116 51 512 119 51 512 minecraft:blackstone
setblock 116 51 551 minecraft:smooth_basalt
fill 117 51 511 117 54 511 minecraft:blackstone
fill 117 51 551 117 54 551 minecraft:blackstone
fill 119 51 550 119 53 550 minecraft:blackstone
setblock 120 51 512 minecraft:smooth_basalt
setblock 121 51 511 minecraft:smooth_basalt
fill 121 51 512 121 53 513 minecraft:blackstone
setblock 121 51 551 minecraft:smooth_basalt
fill 122 51 511 122 54 511 minecraft:blackstone
setblock 122 51 550 minecraft:smooth_basalt
fill 122 51 551 122 54 551 minecraft:blackstone
setblock 123 51 513 minecraft:blackstone
fill 123 51 550 123 54 550 minecraft:blackstone
setblock 124 51 513 minecraft:smooth_basalt
fill 124 51 549 124 53 549 minecraft:blackstone
setblock 125 51 512 minecraft:smooth_basalt
fill 125 51 513 126 52 513 minecraft:blackstone
setblock 126 51 511 minecraft:smooth_basalt
fill 126 51 512 126 54 512 minecraft:blackstone
setblock 126 51 551 minecraft:smooth_basalt
fill 127 51 511 127 54 511 minecraft:blackstone
setblock 127 51 550 minecraft:smooth_basalt
fill 127 51 551 127 54 551 minecraft:blackstone
fill 128 51 550 128 52 550 minecraft:blackstone
setblock 131 51 511 minecraft:smooth_basalt
setblock 131 51 551 minecraft:smooth_basalt
setblock 134 51 533 minecraft:smooth_basalt
fill 134 51 534 134 54 534 minecraft:blackstone
setblock 134 51 538 minecraft:smooth_basalt
fill 134 51 539 134 54 539 minecraft:blackstone
setblock 135 51 532 minecraft:smooth_basalt
fill 135 51 533 135 54 533 minecraft:blackstone
setblock 135 51 537 minecraft:smooth_basalt
fill 135 51 538 135 54 538 minecraft:blackstone
setblock 135 51 541 minecraft:blackstone
setblock 95 52 511 minecraft:smooth_basalt
fill 95 52 512 95 52 515 minecraft:blackstone
setblock 95 52 516 minecraft:smooth_basalt
fill 95 52 517 96 54 517 minecraft:blackstone
setblock 95 52 521 minecraft:smooth_basalt
fill 95 52 522 95 54 523 minecraft:blackstone
fill 95 52 527 95 55 527 minecraft:blackstone
setblock 95 52 531 minecraft:smooth_basalt
fill 95 52 532 95 55 532 minecraft:blackstone
setblock 95 52 536 minecraft:smooth_basalt
fill 95 52 537 96 54 537 minecraft:blackstone
setblock 95 52 540 minecraft:blackstone
fill 96 52 511 96 55 511 minecraft:blackstone
fill 96 52 513 96 52 514 minecraft:blackstone
setblock 96 52 515 minecraft:smooth_basalt
fill 96 52 516 96 55 516 minecraft:blackstone
fill 96 52 518 96 52 519 minecraft:blackstone
setblock 96 52 535 minecraft:smooth_basalt
fill 96 52 536 96 55 536 minecraft:blackstone
setblock 98 52 513 minecraft:smooth_basalt
setblock 99 52 511 minecraft:blackstone
setblock 99 52 512 minecraft:smooth_basalt
fill 99 52 513 99 55 513 minecraft:blackstone
setblock 100 52 511 minecraft:smooth_basalt
fill 100 52 512 100 55 512 minecraft:blackstone
fill 100 52 514 101 52 514 minecraft:blackstone
setblock 100 52 551 minecraft:smooth_basalt
fill 101 52 511 101 55 511 minecraft:blackstone
fill 101 52 551 104 52 551 minecraft:blackstone
setblock 102 52 514 minecraft:smooth_basalt
setblock 103 52 513 minecraft:smooth_basalt
fill 103 52 514 103 54 515 minecraft:blackstone
setblock 104 52 512 minecraft:smooth_basalt
fill 104 52 513 104 55 513 minecraft:blackstone
fill 104 52 515 105 52 515 minecraft:blackstone
fill 104 52 550 104 53 550 minecraft:blackstone
setblock 105 52 511 minecraft:smooth_basalt
fill 105 52 512 105 55 512 minecraft:blackstone
setblock 105 52 551 minecraft:smooth_basalt
fill 106 52 511 109 52 511 minecraft:blackstone
setblock 106 52 550 minecraft:smooth_basalt
fill 106 52 551 109 52 551 minecraft:blackstone
setblock 107 52 514 minecraft:smooth_basalt
setblock 108 52 513 minecraft:smooth_basalt
fill 108 52 514 108 54 514 minecraft:blackstone
setblock 109 52 512 minecraft:smooth_basalt
fill 109 52 513 109 55 513 minecraft:blackstone
setblock 110 52 511 minecraft:smooth_basalt
fill 110 52 512 110 55 512 minecraft:blackstone
setblock 110 52 551 minecraft:smooth_basalt
fill 111 52 511 111 55 511 minecraft:blackstone
fill 111 52 551 111 55 551 minecraft:blackstone
setblock 114 52 512 minecraft:smooth_basalt
setblock 115 52 511 minecraft:smooth_basalt
fill 115 52 512 118 52 512 minecraft:blackstone
setblock 115 52 551 minecraft:smooth_basalt
fill 116 52 511 116 55 511 minecraft:blackstone
fill 116 52 551 116 55 551 minecraft:blackstone
fill 118 52 550 118 54 550 minecraft:blackstone
setblock 119 52 512 minecraft:smooth_basalt
fill 119 52 513 120 54 513 minecraft:blackstone
setblock 120 52 511 minecraft:smooth_basalt
fill 120 52 512 120 55 512 minecraft:blackstone
setblock 120 52 551 minecraft:smooth_basalt
fill 121 52 511 121 55 511 minecraft:blackstone
setblock 121 52 550 minecraft:smooth_basalt
fill 121 52 551 121 55 551 minecraft:blackstone
fill 122 52 550 122 55 550 minecraft:blackstone
setblock 123 52 513 minecraft:smooth_basalt
fill 123 52 549 123 54 549 minecraft:blackstone
setblock 124 52 512 minecraft:smooth_basalt
fill 124 52 513 124 54 513 minecraft:blackstone
setblock 125 52 511 minecraft:smooth_basalt
fill 125 52 512 125 55 512 minecraft:blackstone
setblock 125 52 551 minecraft:smooth_basalt
fill 126 52 511 126 55 511 minecraft:blackstone
setblock 126 52 550 minecraft:smooth_basalt
fill 126 52 551 126 55 551 minecraft:blackstone
fill 127 52 550 127 53 550 minecraft:blackstone
setblock 130 52 511 minecraft:smooth_basalt
setblock 130 52 551 minecraft:smooth_basalt
fill 133 52 535 133 52 537 minecraft:blackstone
setblock 134 52 532 minecraft:smooth_basalt
fill 134 52 533 134 55 533 minecraft:blackstone
setblock 134 52 536 minecraft:blackstone
setblock 134 52 537 minecraft:smooth_basalt
fill 134 52 538 134 55 538 minecraft:blackstone
fill 134 52 540 134 53 540 minecraft:blackstone
fill 135 52 514 135 52 515 minecraft:blackstone
setblock 135 52 516 minecraft:smooth_basalt
fill 135 52 517 135 55 517 minecraft:blackstone
setblock 135 52 531 minecraft:smooth_basalt
fill 135 52 532 135 55 532 minecraft:blackstone
setblock 135 52 536 minecraft:smooth_basalt
fill 135 52 537 135 55 537 minecraft:blackstone
setblock 135 52 541 minecraft:smooth_basalt
fill 135 52 542 135 55 542 minecraft:blackstone
fill 95 53 511 95 53 514 minecraft:blackstone
setblock 95 53 515 minecraft:smooth_basalt
fill 95 53 516 95 56 516 minecraft:blackstone
fill 95 53 518 95 53 519 minecraft:blackstone
setblock 95 53 520 minecraft:smooth_basalt
fill 95 53 521 96 55 521 minecraft:blackstone
setblock 95 53 524 minecraft:blackstone
setblock 95 53 525 minecraft:smooth_basalt
fill 95 53 526 95 56 526 minecraft:blackstone
setblock 95 53 530 minecraft:smooth_basalt
fill 95 53 531 95 56 531 minecraft:blackstone
setblock 95 53 534 minecraft:blackstone
setblock 95 53 535 minecraft:smooth_basalt
fill 95 53 536 95 56 536 minecraft:blackstone
setblock 95 53 540 minecraft:smooth_basalt
fill 96 53 512 96 53 513 minecraft:blackstone
setblock 96 53 514 minecraft:smooth_basalt
fill 96 53 515 97 55 515 minecraft:blackstone
setblock 96 53 518 minecraft:blackstone
setblock 96 53 519 minecraft:smooth_basalt
fill 96 53 520 96 56 520 minecraft:blackstone
fill 96 53 522 96 54 522 minecraft:blackstone
setblock 96 53 534 minecraft:smooth_basalt
fill 96 53 535 96 56 535 minecraft:blackstone
setblock 96 53 538 minecraft:blackstone
fill 97 53 514 97 56 514 minecraft:blackstone
fill 97 53 516 97 53 517 minecraft:blackstone
setblock 97 53 518 minecraft:smooth_basalt
fill 97 53 519 97 56 519 minecraft:blackstone
setblock 98 53 511 minecraft:blackstone
setblock 98 53 512 minecraft:smooth_basalt
fill 98 53 513 98 56 513 minecraft:blackstone
setblock 99 53 511 minecraft:smooth_basalt
fill 99 53 512 99 56 512 minecraft:blackstone
fill 99 53 514 100 53 514 minecraft:blackstone
setblock 99 53 551 minecraft:smooth_basalt
fill 100 53 511 100 56 511 minecraft:blackstone
fill 100 53 551 103 53 551 minecraft:blackstone
setblock 101 53 514 minecraft:smooth_basalt
fill 101 53 515 102 55 515 minecraft:blackstone
setblock 102 53 513 minecraft:smooth_basalt
fill 102 53 514 102 56 514 minecraft:blackstone
setblock 103 53 512 minecraft:smooth_basalt
fill 103 53 513 103 56 513 minecraft:blackstone
setblock 104 53 511 minecraft:smooth_basalt
fill 104 53 512 104 56 512 minecraft:blackstone
setblock 104 53 515 minecraft:blackstone
setblock 104 53 551 minecraft:smooth_basalt
fill 105 53 511 108 53 511 minecraft:blackstone
setblock 105 53 515 minecraft:smooth_basalt
setblock 105 53 550 minecraft:smooth_basalt
fill 105 53 551 108 53 551 minecraft:blackstone
setblock 106 53 514 minecraft:smooth_basalt
setblock 106 53 550 minecraft:blackstone
setblock 107 53 513 minecraft:smooth_basalt
fill 107 53 514 107 55 514 minecraft:blackstone
setblock 108 53 512 minecraft:smooth_basalt
fill 108 53 513 108 55 513 minecraft:blackstone
setblock 109 53 511 minecraft:smooth_basalt
fill 109 53 512 109 56 512 minecraft:blackstone
setblock 109 53 551 minecraft:smooth_basalt
fill 110 53 511 110 56 511 minecraft:blackstone
fill 110 53 551 110 55 551 minecraft:blackstone
setblock 113 53 512 minecraft:smooth_basalt
setblock 114 53 511 minecraft:smooth_basalt
fill 114 53 512 117 53 512 minecraft:blackstone
setblock 114 53 551 minecraft:smooth_basalt
fill 115 53 511 115 56 511 minecraft:blackstone
fill 115 53 551 115 56 551 minecraft:blackstone
setblock 118 53 512 minecraft:smooth_basalt
setblock 119 53 511 minecraft:smooth_basalt
fill 119 53 512 119 56 512 minecraft:blackstone
setblock 119 53 551 minecraft:smooth_basalt
fill 120 53 511 120 56 511 minecraft:blackstone
setblock 120 53 550 minecraft:smooth_basalt
fill 120 53 551 120 56 551 minecraft:blackstone
fill 121 53 550 121 56 550 minecraft:blackstone
setblock 122 53 512 minecraft:blackstone
setblock 122 53 513 minecraft:smooth_basalt
fill 122 53 549 122 55 549 minecraft:blackstone
setblock 123 53 512 minecraft:smooth_basalt
fill 123 53 513 123 55 513 minecraft:blackstone
setblock 124 53 511 minecraft:smooth_basalt
fill 124 53 512 124 56 512 minecraft:blackstone
setblock 124 53 551 minecraft:smooth_basalt
fill 125 53 511 125 56 511 minecraft:blackstone
setblock 125 53 513 minecraft:blackstone
setblock 125 53 550 minecraft:smooth_basalt
fill 125 53 551 125 56 551 minecraft:blackstone
fill 126 53 550 126 54 550 minecraft:blackstone
setblock 128 53 512 minecraft:smooth_basalt
setblock 129 53 511 minecraft:smooth_basalt
setblock 129 53 551 minecraft:smooth_basalt
setblock 130 53 511 minecraft:blackstone
fill 133 53 535 133 53 536 minecraft:blackstone
setblock 133 53 537 minecraft:smooth_basalt
fill 133 53 538 133 55 538 minecraft:blackstone
fill 134 53 532 134 54 532 minecraft:blackstone
setblock 134 53 536 minecraft:smooth_basalt
fill 134 53 537 134 56 537 minecraft:blackstone
setblock 134 53 541 minecraft:smooth_basalt
fill 135 53 513 135 53 514 minecraft:blackstone
setblock 135 53 515 minecraft:smooth_basalt
fill 135 53 516 135 56 516 minecraft:blackstone
fill 135 53 518 135 53 519 minecraft:blackstone
setblock 135 53 520 minecraft:smooth_basalt
fill 135 53 528 135 54 528 minecraft:blackstone
setblock 135 53 530 minecraft:smooth_basalt
fill 135 53 531 135 56 531 minecraft:blackstone
setblock 135 53 535 minecraft:smooth_basalt
fill 135 53 536 135 56 536 minecraft:blackstone
setblock 135 53 539 minecraft:blackstone
setblock 135 53 540 minecraft:smooth_basalt
fill 135 53 541 135 56 541 minecraft:blackstone
fill 135 53 543 135 54 543 minecraft:blackstone
fill 95 54 511 95 54 513 minecraft:blackstone
setblock 95 54 514 minecraft:smooth_basalt
fill 95 54 515 95 57 515 minecraft:blackstone
setblock 95 54 518 minecraft:blackstone
setblock 95 54 519 minecraft:smooth_basalt
fill 95 54 520 95 57 520 minecraft:blackstone
setblock 95 54 524 minecraft:smooth_basalt
fill 95 54 525 95 57 525 minecraft:blackstone
setblock 95 54 529 minecraft:smooth_basalt
fill 95 54 530 95 56 530 minecraft:blackstone
setblock 95 54 534 minecraft:smooth_basalt
fill 95 54 535 95 57 535 minecraft:blackstone
setblock 95 54 538 minecraft:blackstone
setblock 95 54 539 minecraft:smooth_basalt
fill 95 54 540 95 56 541 minecraft:blackstone
setblock 96 54 512 minecraft:blackstone
setblock 96 54 513 minecraft:smooth_basalt
fill 96 54 514 96 57 514 minecraft:blackstone
setblock 96 54 518 minecraft:smooth_basalt
fill 96 54 519 96 57 519 minecraft:blackstone
setblock 96 54 523 minecraft:smooth_basalt
setblock 96 54 533 minecraft:smooth_basalt
fill 96 54 534 96 55 534 minecraft:blackstone
setblock 96 54 538 minecraft:smooth_basalt
fill 96 54 539 96 57 539 minecraft:blackstone
setblock 97 54 511 minecraft:blackstone
setblock 97 54 512 minecraft:smooth_basalt
fill 97 54 513 97 56 513 minecraft:blackstone
setblock 97 54 516 minecraft:blackstone
setblock 97 54 517 minecraft:smooth_basalt
fill 97 54 518 98 56 518 minecraft:blackstone
fill 97 54 520 97 54 521 minecraft:blackstone
setblock 98 54 511 minecraft:smooth_basalt
fill 98 54 512 98 57 512 minecraft:blackstone
setblock 98 54 515 minecraft:blackstone
setblock 98 54 516 minecraft:smooth_basalt
fill 98 54 517 98 57 517 minecraft:blackstone
fill 99 54 511 99 57 511 minecraft:blackstone
setblock 99 54 514 minecraft:blackstone
fill 99 54 551 102 54 551 minecraft:blackstone
setblock 100 54 514 minecraft:smooth_basalt
setblock 101 54 513 minecraft:smooth_basalt
fill 101 54 514 101 57 514 minecraft:blackstone
setblock 102 54 512 minecraft:smooth_basalt
fill 102 54 513 102 57 513 minecraft:blackstone
setblock 103 54 511 minecraft:smooth_basalt
fill 103 54 512 103 57 512 minecraft:blackstone
setblock 103 54 551 minecraft:smooth_basalt
fill 104 54 511 107 54 511 minecraft:blackstone
setblock 104 54 515 minecraft:smooth_basalt
setblock 104 54 550 minecraft:smooth_basalt
fill 104 54 551 107 54 551 minecraft:blackstone
setblock 105 54 514 minecraft:smooth_basalt
setblock 105 54 515 minecraft:blackstone
setblock 106 54 513 minecraft:smooth_basalt
fill 106 54 514 106 55 514 minecraft:blackstone
fill 106 54 531 108 55 531 minecraft:gilded_blackstone
setblock 107 54 512 minecraft:smooth_basalt
fill 107 54 513 107 56 513 minecraft:blackstone
fill 107 54 530 107 55 530 minecraft:gilded_blackstone
fill 107 54 532 107 55 532 minecraft:gilded_blackstone
setblock 108 54 511 minecraft:smooth_basalt
fill 108 54 512 108 57 512 minecraft:blackstone
setblock 108 54 551 minecraft:smooth_basalt
fill 109 54 511 109 57 511 minecraft:blackstone
fill 109 54 551 109 56 551 minecraft:blackstone
setblock 112 54 512 minecraft:smooth_basalt
setblock 113 54 511 minecraft:smooth_basalt
fill 113 54 512 116 54 512 minecraft:blackstone
setblock 113 54 551 minecraft:smooth_basalt
fill 114 54 511 114 57 511 minecraft:blackstone
fill 114 54 551 114 57 551 minecraft:blackstone
setblock 117 54 512 minecraft:smooth_basalt
setblock 118 54 511 minecraft:smooth_basalt
fill 118 54 512 118 57 512 minecraft:blackstone
setblock 118 54 551 minecraft:smooth_basalt
fill 119 54 511 119 57 511 minecraft:blackstone
setblock 119 54 550 minecraft:smooth_basalt
fill 119 54 551 119 57 551 minecraft:blackstone
fill 120 54 550 120 57 550 minecraft:blackstone
setblock 121 54 512 minecraft:blackstone
setblock 121 54 513 minecraft:smooth_basalt
setblock 121 54 549 minecraft:blackstone
setblock 122 54 512 minecraft:smooth_basalt
fill 122 54 513 122 55 513 minecraft:blackstone
setblock 123 54 511 minecraft:smooth_basalt
fill 123 54 512 123 56 512 minecraft:blackstone
setblock 123 54 551 minecraft:smooth_basalt
fill 124 54 511 124 57 511 minecraft:blackstone
setblock 124 54 550 minecraft:smooth_basalt
fill 124 54 551 124 57 551 minecraft:blackstone
fill 125 54 550 125 55 550 minecraft:blackstone
setblock 127 54 512 minecraft:smooth_basalt
setblock 128 54 511 minecraft:smooth_basalt
setblock 128 54 551 minecraft:smooth_basalt
setblock 129 54 511 minecraft:blackstone
setblock 133 54 536 minecraft:smooth_basalt
fill 133 54 537 133 55 537 minecraft:blackstone
setblock 134 54 535 minecraft:smooth_basalt
fill 134 54 536 134 57 536 minecraft:blackstone
setblock 134 54 540 minecraft:smooth_basalt
fill 134 54 541 134 57 541 minecraft:blackstone
setblock 135 54 513 minecraft:blackstone
setblock 135 54 514 minecraft:smooth_basalt
fill 135 54 515 135 57 515 minecraft:blackstone
setblock 135 54 518 minecraft:blackstone
setblock 135 54 519 minecraft:smooth_basalt
fill 135 54 520 135 54 523 minecraft:blackstone
setblock 135 54 529 minecraft:smooth_basalt
fill 135 54 530 135 57 530 minecraft:blackstone
setblock 135 54 534 minecraft:smooth_basalt
fill 135 54 535 135 57 535 minecraft:blackstone
setblock 135 54 539 minecraft:smooth_basalt
fill 135 54 540 135 57 540 minecraft:blackstone
fill 95 55 511 95 55 512 minecraft:blackstone
setblock 95 55 513 minecraft:smooth_basalt
fill 95 55 514 95 58 514 minecraft:blackstone
setblock 95 55 517 minecraft:blackstone
setblock 95 55 518 minecraft:smooth_basalt
fill 95 55 519 95 58 519 minecraft:blackstone
setblock 95 55 522 minecraft:blackstone
setblock 95 55 523 minecraft:smooth_basalt
fill 95 55 524 96 57 524 minecraft:blackstone
setblock 95 55 528 minecraft:smooth_basalt
fill 95 55 529 95 57 529 minecraft:blackstone
setblock 95 55 533 minecraft:smooth_basalt
fill 95 55 534 95 57 534 minecraft:blackstone
setblock 95 55 537 minecraft:blackstone
setblock 95 55 538 minecraft:smooth_basalt
fill 95 55 539 95 58 539 minecraft:blackstone
setblock 95 55 542 minecraft:blackstone
setblock 96 55 512 minecraft:smooth_basalt
fill 96 55 513 96 58 513 minecraft:blackstone
setblock 96 55 517 minecraft:smooth_basalt
fill 96 55 518 96 58 518 minecraft:blackstone
setblock 96 55 522 minecraft:smooth_basalt
fill 96 55 523 96 58 523 minecraft:blackstone
setblock 96 55 533 minecraft:blackstone
setblock 96 55 537 minecraft:smooth_basalt
fill 96 55 538 96 57 538 minecraft:blackstone
setblock 97 55 511 minecraft:smooth_basalt
fill 97 55 512 97 58 512 minecraft:blackstone
setblock 97 55 516 minecraft:smooth_basalt
fill 97 55 517 97 58 517 minecraft:blackstone
setblock 97 55 520 minecraft:blackstone
setblock 97 55 521 minecraft:smooth_basalt
fill 97 55 522 97 58 522 minecraft:blackstone
fill 98 55 511 98 58 511 minecraft:blackstone
setblock 98 55 514 minecraft:blackstone
setblock 98 55 515 minecraft:smooth_basalt
fill 98 55 516 98 58 516 minecraft:blackstone
setblock 98 55 519 minecraft:blackstone
setblock 98 55 520 minecraft:smooth_basalt
setblock 99 55 514 minecraft:smooth_basalt
fill 99 55 551 101 55 551 minecraft:blackstone
setblock 100 55 513 minecraft:smooth_basalt
fill 100 55 514 100 57 514 minecraft:blackstone
setblock 101 55 512 minecraft:smooth_basalt
fill 101 55 513 101 58 513 minecraft:blackstone
setblock 102 55 511 minecraft:smooth_basalt
fill 102 55 512 102 58 512 minecraft:blackstone
setblock 102 55 551 minecraft:smooth_basalt
fill 103 55 511 106 55 511 minecraft:blackstone
setblock 103 55 514 minecraft:blackstone
setblock 103 55 515 minecraft:smooth_basalt
fill 103 55 551 106 55 551 minecraft:blackstone
setblock 104 55 514 minecraft:smooth_basalt
setblock 104 55 515 minecraft:blackstone
setblock 105 55 513 minecraft:smooth_basalt
fill 105 55 514 105 56 514 minecraft:blackstone
setblock 106 55 512 minecraft:smooth_basalt
fill 106 55 513 106 57 513 minecraft:blackstone
setblock 107 55 511 minecraft:smooth_basalt
fill 107 55 512 107 57 512 minecraft:blackstone
setblock 107 55 551 minecraft:smooth_basalt
fill 108 55 511 108 58 511 minecraft:blackstone
fill 108 55 551 108 56 551 minecraft:blackstone
setblock 111 55 512 minecraft:smooth_basalt
setblock 112 55 511 minecraft:smooth_basalt
fill 112 55 512 115 55 512 minecraft:blackstone
setblock 112 55 551 minecraft:smooth_basalt
fill 113 55 511 113 57 511 minecraft:blackstone
fill 113 55 551 113 56 551 minecraft:blackstone
setblock 116 55 512 minecraft:smooth_basalt
setblock 117 55 511 minecraft:smooth_basalt
fill 117 55 512 117 56 512 minecraft:blackstone
setblock 117 55 550 minecraft:blackstone
setblock 117 55 551 minecraft:smooth_basalt
fill 118 55 511 118 58 511 minecraft:blackstone
setblock 118 55 550 minecraft:smooth_basalt
fill 118 55 551 118 58 551 minecraft:blackstone
fill 119 55 550 119 58 550 minecraft:blackstone
setblock 120 55 513 minecraft:smooth_basalt
setblock 121 55 512 minecraft:smooth_basalt
setblock 121 55 513 minecraft:blackstone
setblock 122 55 511 minecraft:smooth_basalt
fill 122 55 512 122 57 512 minecraft:blackstone
setblock 122 55 551 minecraft:smooth_basalt
fill 123 55 511 123 57 511 minecraft:blackstone
setblock 123 55 550 minecraft:smooth_basalt
fill 123 55 551 123 58 551 minecraft:blackstone
fill 124 55 550 124 56 550 minecraft:blackstone
setblock 127 55 511 minecraft:smooth_basalt
setblock 127 55 551 minecraft:smooth_basalt
setblock 134 55 534 minecraft:smooth_basalt
fill 134 55 535 134 57 535 minecraft:blackstone
setblock 134 55 539 minecraft:smooth_basalt
fill 134 55 540 134 58 540 minecraft:blackstone
setblock 135 55 513 minecraft:smooth_basalt
fill 135 55 514 135 57 514 minecraft:blackstone
setblock 135 55 518 minecraft:smooth_basalt
fill 135 55 519 135 55 522 minecraft:blackstone
setblock 135 55 523 minecraft:smooth_basalt
fill 135 55 524 135 55 527 minecraft:blackstone
setblock 135 55 528 minecraft:smooth_basalt
fill 135 55 529 135 58 529 minecraft:blackstone
setblock 135 55 533 minecraft:smooth_basalt
fill 135 55 534 135 58 534 minecraft:blackstone
setblock 135 55 538 minecraft:smooth_basalt
fill 135 55 539 135 58 539 minecraft:blackstone
setblock 135 55 543 minecraft:smooth_basalt
fill 135 55 544 135 58 544 minecraft:blackstone
setblock 95 56 511 minecraft:blackstone
setblock 95 56 512 minecraft:smooth_basalt
fill 95 56 513 95 59 513 minecraft:blackstone
setblock 95 56 517 minecraft:smooth_basalt
fill 95 56 518 95 59 518 minecraft:blackstone
setblock 95 56 521 minecraft:blackstone
setblock 95 56 522 minecraft:smooth_basalt
fill 95 56 523 95 59 523 minecraft:blackstone
setblock 95 56 527 minecraft:smooth_basalt
fill 95 56 528 95 59 528 minecraft:blackstone
setblock 95 56 532 minecraft:smooth_basalt
fill 95 56 533 95 57 533 minecraft:blackstone
setblock 95 56 537 minecraft:smooth_basalt
fill 95 56 538 95 59 538 minecraft:blackstone
setblock 95 56 542 minecraft:smooth_basalt
setblock 96 56 511 minecraft:smooth_basalt
fill 96 56 512 96 57 512 minecraft:blackstone
setblock 96 56 515 minecraft:blackstone
setblock 96 56 516 minecraft:smooth_basalt
fill 96 56 517 96 59 517 minecraft:blackstone
setblock 96 56 521 minecraft:smooth_basalt
fill 96 56 522 96 59 522 minecraft:blackstone
setblock 96 56 525 minecraft:blackstone
setblock 96 56 536 minecraft:smooth_basalt
fill 96 56 537 96 57 537 minecraft:blackstone
setblock 96 56 540 minecraft:blackstone
fill 97 56 511 97 59 511 minecraft:blackstone
setblock 97 56 515 minecraft:smooth_basalt
fill 97 56 516 97 59 516 minecraft:blackstone
setblock 97 56 520 minecraft:smooth_basalt
fill 97 56 521 98 58 521 minecraft:blackstone
fill 97 56 523 97 57 523 minecraft:blackstone
setblock 97 56 529 minecraft:light[level=12]
setblock 97 56 537 minecraft:light[level=12]
fill 98 56 515 98 57 515 minecraft:blackstone
setblock 98 56 519 minecraft:smooth_basalt
fill 98 56 520 98 59 520 minecraft:blackstone
setblock 99 56 513 minecraft:smooth_basalt
fill 99 56 514 99 57 514 minecraft:blackstone
fill 99 56 526 99 57 526 minecraft:gilded_blackstone
fill 99 56 551 100 56 551 minecraft:blackstone
setblock 100 56 512 minecraft:smooth_basalt
fill 100 56 513 100 59 513 minecraft:blackstone
setblock 101 56 511 minecraft:smooth_basalt
fill 101 56 512 101 59 512 minecraft:blackstone
setblock 101 56 515 minecraft:blackstone
setblock 101 56 551 minecraft:smooth_basalt
fill 102 56 511 105 56 511 minecraft:blackstone
setblock 102 56 515 minecraft:smooth_basalt
fill 102 56 551 105 56 551 minecraft:blackstone
setblock 103 56 514 minecraft:smooth_basalt
setblock 104 56 513 minecraft:smooth_basalt
setblock 104 56 514 minecraft:blackstone
setblock 105 56 512 minecraft:smooth_basalt
fill 105 56 513 105 57 513 minecraft:blackstone
setblock 105 56 521 minecraft:light[level=12]
setblock 105 56 529 minecraft:light[level=12]
setblock 105 56 537 minecraft:light[level=12]
setblock 105 56 545 minecraft:light[level=12]
setblock 106 56 511 minecraft:smooth_basalt
fill 106 56 512 106 58 512 minecraft:blackstone
setblock 106 56 551 minecraft:smooth_basalt
fill 107 56 511 107 58 511 minecraft:blackstone
fill 107 56 551 107 57 551 minecraft:blackstone
setblock 110 56 512 minecraft:smooth_basalt
setblock 111 56 511 minecraft:smooth_basalt
setblock 112 56 511 minecraft:blackstone
setblock 113 56 513 minecraft:light[level=12]
setblock 113 56 521 minecraft:light[level=12]
setblock 113 56 529 minecraft:light[level=12]
setblock 113 56 537 minecraft:light[level=12]
setblock 113 56 545 minecraft:light[level=12]
setblock 116 56 511 minecraft:smooth_basalt
setblock 116 56 551 minecraft:smooth_basalt
fill 117 56 511 117 59 511 minecraft:blackstone
setblock 117 56 550 minecraft:smooth_basalt
fill 117 56 551 117 59 551 minecraft:blackstone
fill 118 56 550 118 59 550 minecraft:blackstone
setblock 120 56 512 minecraft:smooth_basalt
setblock 121 56 511 minecraft:smooth_basalt
fill 121 56 512 121 57 512 minecraft:blackstone
setblock 121 56 513 minecraft:light[level=12]
setblock 121 56 521 minecraft:light[level=12]
setblock 121 56 529 minecraft:light[level=12]
setblock 121 56 537 minecraft:light[level=12]
setblock 121 56 545 minecraft:light[level=12]
setblock 121 56 551 minecraft:smooth_basalt
fill 122 56 511 122 58 511 minecraft:blackstone
setblock 122 56 550 minecraft:smooth_basalt
fill 122 56 551 122 59 551 minecraft:blackstone
fill 123 56 550 123 57 550 minecraft:blackstone
setblock 126 56 511 minecraft:smooth_basalt
setblock 126 56 551 minecraft:smooth_basalt
setblock 129 56 513 minecraft:light[level=12]
setblock 129 56 521 minecraft:light[level=12]
setblock 129 56 529 minecraft:light[level=12]
setblock 129 56 537 minecraft:light[level=12]
setblock 129 56 545 minecraft:light[level=12]
setblock 134 56 533 minecraft:smooth_basalt
setblock 134 56 534 minecraft:blackstone
setblock 134 56 538 minecraft:smooth_basalt
fill 134 56 539 134 59 539 minecraft:blackstone
setblock 134 56 542 minecraft:blackstone
setblock 135 56 517 minecraft:smooth_basalt
fill 135 56 518 135 56 521 minecraft:blackstone
setblock 135 56 522 minecraft:smooth_basalt
fill 135 56 523 135 56 526 minecraft:blackstone
setblock 135 56 527 minecraft:smooth_basalt
fill 135 56 528 135 59 528 minecraft:blackstone
setblock 135 56 532 minecraft:smooth_basalt
fill 135 56 533 135 59 533 minecraft:blackstone
setblock 135 56 537 minecraft:smooth_basalt
fill 135 56 538 135 59 538 minecraft:blackstone
setblock 135 56 542 minecraft:smooth_basalt
fill 135 56 543 135 59 543 minecraft:blackstone
setblock 95 57 511 minecraft:smooth_basalt
fill 95 57 512 95 60 512 minecraft:blackstone
setblock 95 57 516 minecraft:smooth_basalt
fill 95 57 517 95 60 517 minecraft:blackstone
setblock 95 57 521 minecraft:smooth_basalt
fill 95 57 522 95 60 522 minecraft:blackstone
setblock 95 57 526 minecraft:smooth_basalt
fill 95 57 527 95 60 527 minecraft:blackstone
setblock 95 57 532 minecraft:blackstone
setblock 95 57 536 minecraft:smooth_basalt
fill 95 57 537 95 59 537 minecraft:blackstone
setblock 95 57 540 minecraft:blackstone
setblock 95 57 541 minecraft:smooth_basalt
fill 95 57 542 95 59 543 minecraft:blackstone
fill 95 57 544 95 59 544 minecraft:smooth_basalt
fill 96 57 511 96 60 511 minecraft:blackstone
setblock 96 57 515 minecraft:smooth_basalt
fill 96 57 516 96 60 516 minecraft:blackstone
setblock 96 57 520 minecraft:smooth_basalt
fill 96 57 521 96 60 521 minecraft:blackstone
setblock 96 57 525 minecraft:smooth_basalt
setblock 97 57 514 minecraft:smooth_basalt
fill 97 57 515 97 60 515 minecraft:blackstone
setblock 97 57 518 minecraft:blackstone
setblock 97 57 519 minecraft:smooth_basalt
fill 97 57 520 97 60 520 minecraft:blackstone
setblock 98 57 513 minecraft:smooth_basalt
setblock 98 57 518 minecraft:smooth_basalt
fill 98 57 519 98 60 519 minecraft:blackstone
setblock 99 57 512 minecraft:smooth_basalt
fill 99 57 513 99 59 513 minecraft:blackstone
setblock 99 57 551 minecraft:blackstone
setblock 100 57 511 minecraft:smooth_basalt
fill 100 57 512 100 60 512 minecraft:blackstone
setblock 100 57 551 minecraft:smooth_basalt
fill 101 57 511 104 57 511 minecraft:blackstone
fill 101 57 551 104 57 551 minecraft:blackstone
setblock 102 57 514 minecraft:smooth_basalt
setblock 103 57 513 minecraft:smooth_basalt
setblock 103 57 514 minecraft:blackstone
setblock 104 57 512 minecraft:smooth_basalt
fill 104 57 513 104 58 513 minecraft:blackstone
setblock 105 57 511 minecraft:smooth_basalt
fill 105 57 512 105 58 512 minecraft:blackstone
setblock 105 57 551 minecraft:smooth_basalt
fill 106 57 511 106 59 511 minecraft:blackstone
setblock 106 57 551 minecraft:blackstone
setblock 110 57 511 minecraft:smooth_basalt
setblock 111 57 511 minecraft:blackstone
setblock 115 57 511 minecraft:smooth_basalt
setblock 115 57 551 minecraft:smooth_basalt
fill 116 57 511 116 58 511 minecraft:blackstone
fill 116 57 551 116 60 551 minecraft:blackstone
setblock 117 57 550 minecraft:blackstone
setblock 119 57 512 minecraft:smooth_basalt
setblock 120 57 511 minecraft:smooth_basalt
setblock 120 57 512 minecraft:blackstone
setblock 120 57 551 minecraft:smooth_basalt
fill 121 57 511 121 58 511 minecraft:blackstone
setblock 121 57 550 minecraft:smooth_basalt
fill 121 57 551 121 60 551 minecraft:blackstone
fill 122 57 550 122 58 550 minecraft:blackstone
setblock 125 57 551 minecraft:smooth_basalt
fill 134 57 519 135 57 520 minecraft:blackstone
setblock 134 57 537 minecraft:smooth_basalt
fill 134 57 538 134 59 538 minecraft:blackstone
setblock 134 57 542 minecraft:smooth_basalt
setblock 135 57 516 minecraft:smooth_basalt
fill 135 57 517 135 59 518 minecraft:blackstone
setblock 135 57 521 minecraft:smooth_basalt
fill 135 57 522 135 57 525 minecraft:blackstone
setblock 135 57 526 minecraft:smooth_basalt
fill 135 57 527 135 60 527 minecraft:blackstone
setblock 135 57 531 minecraft:smooth_basalt
fill 135 57 532 135 60 532 minecraft:blackstone
setblock 135 57 536 minecraft:smooth_basalt
fill 135 57 537 135 60 537 minecraft:blackstone
setblock 135 57 541 minecraft:smooth_basalt
fill 135 57 542 135 60 542 minecraft:blackstone
setblock 95 58 511 minecraft:blackstone
setblock 95 58 515 minecraft:smooth_basalt
fill 95 58 516 95 61 516 minecraft:blackstone
setblock 95 58 520 minecraft:smooth_basalt
fill 95 58 521 95 61 521 minecraft:blackstone
setblock 95 58 524 minecraft:blackstone
setblock 95 58 525 minecraft:smooth_basalt
fill 95 58 526 95 61 526 minecraft:blackstone
setblock 95 58 535 minecraft:smooth_basalt
setblock 95 58 536 minecraft:blackstone
setblock 95 58 540 minecraft:smooth_basalt
fill 95 58 541 95 61 541 minecraft:blackstone
setblock 96 58 514 minecraft:smooth_basalt
fill 96 58 515 96 61 515 minecraft:blackstone
setblock 96 58 519 minecraft:smooth_basalt
fill 96 58 520 96 61 520 minecraft:blackstone
setblock 96 58 524 minecraft:smooth_basalt
fill 96 58 525 96 61 525 minecraft:blackstone
setblock 97 58 514 minecraft:blackstone
setblock 97 58 518 minecraft:smooth_basalt
fill 97 58 519 97 61 519 minecraft:blackstone
setblock 97 58 523 minecraft:smooth_basalt
setblock 98 58 512 minecraft:smooth_basalt
setblock 98 58 513 minecraft:blackstone
setblock 98 58 517 minecraft:smooth_basalt
fill 98 58 518 98 60 518 minecraft:blackstone
setblock 99 58 511 minecraft:smooth_basalt
fill 99 58 512 99 61 512 minecraft:blackstone
setblock 99 58 551 minecraft:smooth_basalt
fill 100 58 511 103 58 511 minecraft:blackstone
fill 100 58 551 103 58 551 minecraft:blackstone
setblock 102 58 513 minecraft:smooth_basalt
setblock 103 58 512 minecraft:smooth_basalt
setblock 103 58 513 minecraft:blackstone
setblock 104 58 511 minecraft:smooth_basalt
fill 104 58 512 104 59 512 minecraft:blackstone
setblock 104 58 551 minecraft:smooth_basalt
fill 105 58 511 105 60 511 minecraft:blackstone
setblock 105 58 551 minecraft:blackstone
fill 115 58 551 115 61 551 minecraft:blackstone
setblock 119 58 511 minecraft:smooth_basalt
setblock 119 58 551 minecraft:smooth_basalt
fill 120 58 511 120 59 511 minecraft:blackstone
setblock 120 58 550 minecraft:smooth_basalt
fill 120 58 551 120 61 551 minecraft:blackstone
fill 121 58 550 121 59 550 minecraft:blackstone
setblock 124 58 551 minecraft:smooth_basalt
fill 134 58 519 134 58 520 minecraft:blackstone
setblock 134 58 521 minecraft:smooth_basalt
fill 134 58 522 135 60 522 minecraft:blackstone
setblock 134 58 536 minecraft:smooth_basalt
setblock 134 58 537 minecraft:blackstone
setblock 134 58 541 minecraft:smooth_basalt
setblock 135 58 515 minecraft:smooth_basalt
fill 135 58 516 135 61 516 minecraft:blackstone
setblock 135 58 519 minecraft:blackstone
setblock 135 58 520 minecraft:smooth_basalt
fill 135 58 521 135 61 521 minecraft:blackstone
fill 135 58 523 135 58 524 minecraft:blackstone
setblock 135 58 525 minecraft:smooth_basalt
fill 135 58 526 135 61 526 minecraft:blackstone
setblock 135 58 530 minecraft:smooth_basalt
fill 135 58 531 135 61 531 minecraft:blackstone
setblock 135 58 535 minecraft:smooth_basalt
fill 135 58 536 135 61 536 minecraft:blackstone
setblock 135 58 540 minecraft:smooth_basalt
fill 135 58 541 135 61 541 minecraft:blackstone
setblock 95 59 514 minecraft:smooth_basalt
fill 95 59 515 95 62 515 minecraft:blackstone
setblock 95 59 519 minecraft:smooth_basalt
fill 95 59 520 95 62 520 minecraft:blackstone
setblock 95 59 524 minecraft:smooth_basalt
fill 95 59 525 95 62 525 minecraft:blackstone
setblock 95 59 539 minecraft:smooth_basalt
fill 95 59 540 95 62 540 minecraft:blackstone
setblock 96 59 513 minecraft:smooth_basalt
fill 96 59 514 96 62 514 minecraft:blackstone
setblock 96 59 518 minecraft:smooth_basalt
fill 96 59 519 96 62 519 minecraft:blackstone
setblock 96 59 523 minecraft:smooth_basalt
fill 96 59 524 97 61 524 minecraft:blackstone
fill 96 59 526 96 60 526 minecraft:blackstone
setblock 97 59 512 minecraft:smooth_basalt
setblock 97 59 517 minecraft:smooth_basalt
fill 97 59 518 97 62 518 minecraft:blackstone
setblock 97 59 521 minecraft:blackstone
setblock 97 59 522 minecraft:smooth_basalt
fill 97 59 523 97 62 523 minecraft:blackstone
setblock 98 59 511 minecraft:smooth_basalt
fill 98 59 512 98 62 512 minecraft:blackstone
setblock 98 59 517 minecraft:blackstone
setblock 98 59 521 minecraft:smooth_basalt
fill 99 59 511 102 59 511 minecraft:blackstone
fill 99 59 551 102 59 551 minecraft:blackstone
setblock 101 59 513 minecraft:smooth_basalt
setblock 102 59 512 minecraft:smooth_basalt
setblock 103 59 511 minecraft:smooth_basalt
setblock 103 59 512 minecraft:blackstone
setblock 103 59 551 minecraft:smooth_basalt
fill 104 59 511 104 61 511 minecraft:blackstone
setblock 104 59 551 minecraft:blackstone
setblock 118 59 511 minecraft:smooth_basalt
setblock 118 59 551 minecraft:smooth_basalt
setblock 119 59 511 minecraft:blackstone
setblock 119 59 550 minecraft:smooth_basalt
fill 119 59 551 119 62 551 minecraft:blackstone
fill 120 59 550 120 62 550 minecraft:blackstone
setblock 123 59 551 minecraft:smooth_basalt
setblock 134 59 519 minecraft:blackstone
setblock 134 59 520 minecraft:smooth_basalt
fill 134 59 521 134 62 521 minecraft:blackstone
fill 134 59 523 135 59 523 minecraft:blackstone
setblock 134 59 540 minecraft:smooth_basalt
setblock 134 59 541 minecraft:blackstone
fill 135 59 515 135 62 515 minecraft:blackstone
setblock 135 59 519 minecraft:smooth_basalt
fill 135 59 520 135 62 520 minecraft:blackstone
setblock 135 59 524 minecraft:smooth_basalt
fill 135 59 525 135 62 525 minecraft:blackstone
setblock 135 59 529 minecraft:smooth_basalt
fill 135 59 530 135 62 530 minecraft:blackstone
setblock 135 59 534 minecraft:smooth_basalt
fill 135 59 535 135 62 535 minecraft:blackstone
setblock 135 59 539 minecraft:smooth_basalt
fill 135 59 540 135 62 540 minecraft:blackstone
setblock 135 59 544 minecraft:smooth_basalt
fill 135 59 545 135 62 545 minecraft:blackstone
setblock 95 60 513 minecraft:smooth_basalt
fill 95 60 514 95 63 514 minecraft:blackstone
setblock 95 60 518 minecraft:smooth_basalt
fill 95 60 519 95 63 519 minecraft:blackstone
setblock 95 60 523 minecraft:smooth_basalt
fill 95 60 524 95 63 524 minecraft:blackstone
setblock 95 60 528 minecraft:smooth_basalt
setblock 95 60 538 minecraft:smooth_basalt
fill 95 60 539 95 63 539 minecraft:blackstone
setblock 95 60 542 minecraft:blackstone
setblock 95 60 543 minecraft:smooth_basalt
fill 95 60 544 95 63 544 minecraft:blackstone
setblock 96 60 517 minecraft:smooth_basalt
fill 96 60 518 96 63 518 minecraft:blackstone
setblock 96 60 522 minecraft:smooth_basalt
fill 96 60 523 96 63 523 minecraft:blackstone
setblock 97 60 511 minecraft:smooth_basalt
setblock 97 60 516 minecraft:smooth_basalt
fill 97 60 517 97 63 517 minecraft:blackstone
setblock 97 60 521 minecraft:smooth_basalt
fill 97 60 522 97 63 522 minecraft:blackstone
fill 98 60 511 101 60 511 minecraft:blackstone
setblock 98 60 520 minecraft:smooth_basalt
fill 98 60 521 98 63 521 minecraft:blackstone
fill 99 60 551 101 60 551 minecraft:blackstone
setblock 101 60 512 minecraft:smooth_basalt
setblock 102 60 511 minecraft:smooth_basalt
setblock 102 60 512 minecraft:blackstone
setblock 102 60 551 minecraft:smooth_basalt
fill 103 60 511 103 63 511 minecraft:blackstone
fill 103 60 551 103 63 551 minecraft:blackstone
fill 114 60 551 114 62 551 minecraft:blackstone
setblock 117 60 550 minecraft:blackstone
setblock 117 60 551 minecraft:smooth_basalt
setblock 118 60 550 minecraft:smooth_basalt
fill 118 60 551 118 63 551 minecraft:blackstone
fill 119 60 550 119 63 550 minecraft:blackstone
setblock 122 60 551 minecraft:smooth_basalt
setblock 134 60 519 minecraft:smooth_basalt
fill 134 60 520 134 63 520 minecraft:blackstone
setblock 134 60 523 minecraft:blackstone
setblock 134 60 524 minecraft:smooth_basalt
setblock 135 60 517 minecraft:blackstone
setblock 135 60 518 minecraft:smooth_basalt
fill 135 60 519 135 63 519 minecraft:blackstone
setblock 135 60 523 minecraft:smooth_basalt
fill 135 60 524 135 63 524 minecraft:blackstone
setblock 135 60 528 minecraft:smooth_basalt
fill 135 60 529 135 63 529 minecraft:blackstone
setblock 135 60 533 minecraft:smooth_basalt
fill 135 60 534 135 63 534 minecraft:blackstone
setblock 135 60 538 minecraft:smooth_basalt
fill 135 60 539 135 63 539 minecraft:blackstone
setblock 135 60 543 minecraft:smooth_basalt
fill 135 60 544 135 63 544 minecraft:blackstone
setblock 95 61 512 minecraft:smooth_basalt
fill 95 61 513 95 64 513 minecraft:blackstone
setblock 95 61 517 minecraft:smooth_basalt
fill 95 61 518 95 64 518 minecraft:blackstone
setblock 95 61 522 minecraft:smooth_basalt
fill 95 61 523 95 64 523 minecraft:blackstone
setblock 95 61 527 minecraft:smooth_basalt
fill 95 61 528 95 64 528 minecraft:blackstone
setblock 95 61 542 minecraft:smooth_basalt
fill 95 61 543 95 64 543 minecraft:blackstone
fill 95 61 545 95 61 546 minecraft:blackstone
setblock 96 61 511 minecraft:smooth_basalt
setblock 96 61 516 minecraft:smooth_basalt
fill 96 61 517 96 64 517 minecraft:blackstone
setblock 96 61 521 minecraft:smooth_basalt
fill 96 61 522 96 64 522 minecraft:blackstone
setblock 96 61 526 minecraft:smooth_basalt
fill 97 61 511 100 61 511 minecraft:blackstone
fill 97 61 516 97 64 516 minecraft:blackstone
setblock 97 61 520 minecraft:smooth_basalt
fill 97 61 521 97 64 521 minecraft:blackstone
setblock 98 61 519 minecraft:smooth_basalt
fill 98 61 520 98 62 520 minecraft:blackstone
fill 98 61 551 100 61 551 minecraft:blackstone
setblock 100 61 512 minecraft:smooth_basalt
setblock 101 61 511 minecraft:smooth_basalt
setblock 101 61 512 minecraft:blackstone
setblock 101 61 551 minecraft:smooth_basalt
fill 102 61 511 102 64 511 minecraft:blackstone
fill 102 61 551 102 64 551 minecraft:blackstone
setblock 116 61 550 minecraft:blackstone
setblock 116 61 551 minecraft:smooth_basalt
setblock 117 61 550 minecraft:smooth_basalt
fill 117 61 551 117 64 551 minecraft:blackstone
fill 118 61 550 118 64 550 minecraft:blackstone
setblock 121 61 551 minecraft:smooth_basalt
fill 122 61 551 122 64 551 minecraft:blackstone
fill 134 61 519 134 64 519 minecraft:blackstone
setblock 134 61 522 minecraft:blackstone
setblock 134 61 523 minecraft:smooth_basalt
fill 134 61 524 134 62 526 minecraft:blackstone
setblock 135 61 517 minecraft:smooth_basalt
fill 135 61 518 135 64 518 minecraft:blackstone
setblock 135 61 522 minecraft:smooth_basalt
fill 135 61 523 135 64 523 minecraft:blackstone
setblock 135 61 527 minecraft:smooth_basalt
fill 135 61 528 135 64 528 minecraft:blackstone
setblock 135 61 532 minecraft:smooth_basalt
fill 135 61 533 135 64 533 minecraft:blackstone
setblock 135 61 537 minecraft:smooth_basalt
fill 135 61 538 135 64 538 minecraft:blackstone
setblock 135 61 542 minecraft:smooth_basalt
fill 135 61 543 135 64 543 minecraft:blackstone
setblock 135 61 546 minecraft:blackstone
setblock 95 62 511 minecraft:smooth_basalt
fill 95 62 512 95 65 512 minecraft:blackstone
setblock 95 62 516 minecraft:smooth_basalt
fill 95 62 517 95 65 517 minecraft:blackstone
setblock 95 62 521 minecraft:smooth_basalt
fill 95 62 522 95 65 522 minecraft:blackstone
setblock 95 62 526 minecraft:smooth_basalt
fill 95 62 527 96 64 527 minecraft:blackstone
fill 95 62 529 95 63 529 minecraft:blackstone
setblock 95 62 541 minecraft:smooth_basalt
fill 95 62 542 95 65 542 minecraft:blackstone
setblock 95 62 545 minecraft:blackstone
setblock 95 62 546 minecraft:smooth_basalt
fill 95 62 547 95 64 548 minecraft:blackstone
fill 96 62 511 99 62 511 minecraft:blackstone
setblock 96 62 515 minecraft:smooth_basalt
fill 96 62 516 96 65 516 minecraft:blackstone
setblock 96 62 520 minecraft:smooth_basalt
fill 96 62 521 96 65 521 minecraft:blackstone
setblock 96 62 524 minecraft:blackstone
setblock 96 62 525 minecraft:smooth_basalt
fill 96 62 526 96 65 526 minecraft:blackstone
setblock 97 62 519 minecraft:smooth_basalt
fill 97 62 520 97 65 520 minecraft:blackstone
setblock 97 62 524 minecraft:smooth_basalt
fill 97 62 525 97 65 525 minecraft:blackstone
fill 97 62 551 99 62 551 minecraft:blackstone
setblock 99 62 512 minecraft:smooth_basalt
setblock 100 62 511 minecraft:smooth_basalt
fill 100 62 512 100 65 512 minecraft:blackstone
setblock 100 62 551 minecraft:smooth_basalt
fill 101 62 511 101 65 511 minecraft:blackstone
fill 101 62 551 101 65 551 minecraft:blackstone
fill 113 62 551 113 63 551 minecraft:blackstone
setblock 115 62 550 minecraft:blackstone
setblock 115 62 551 minecraft:smooth_basalt
setblock 116 62 550 minecraft:smooth_basalt
fill 116 62 551 116 65 551 minecraft:blackstone
fill 117 62 550 117 65 550 minecraft:blackstone
setblock 120 62 551 minecraft:smooth_basalt
fill 121 62 551 121 65 551 minecraft:blackstone
fill 134 62 518 134 65 518 minecraft:blackstone
setblock 134 62 522 minecraft:smooth_basalt
fill 134 62 523 134 65 523 minecraft:blackstone
setblock 134 62 527 minecraft:smooth_basalt
setblock 135 62 516 minecraft:smooth_basalt
fill 135 62 517 135 65 517 minecraft:blackstone
setblock 135 62 521 minecraft:smooth_basalt
fill 135 62 522 135 65 522 minecraft:blackstone
setblock 135 62 526 minecraft:smooth_basalt
fill 135 62 527 135 65 527 minecraft:blackstone
setblock 135 62 531 minecraft:smooth_basalt
fill 135 62 532 135 65 532 minecraft:blackstone
setblock 135 62 536 minecraft:smooth_basalt
fill 135 62 537 135 65 537 minecraft:blackstone
setblock 135 62 541 minecraft:smooth_basalt
fill 135 62 542 135 65 542 minecraft:blackstone
setblock 135 62 546 minecraft:smooth_basalt
fill 135 62 547 135 65 547 minecraft:blackstone
fill 95 63 511 98 63 511 minecraft:blackstone
setblock 95 63 515 minecraft:smooth_basalt
fill 95 63 516 95 66 516 minecraft:blackstone
setblock 95 63 520 minecraft:smooth_basalt
fill 95 63 521 95 66 521 minecraft:blackstone
setblock 95 63 525 minecraft:smooth_basalt
fill 95 63 526 95 66 526 minecraft:blackstone
setblock 95 63 530 minecraft:smooth_basalt
setblock 95 63 540 minecraft:smooth_basalt
fill 95 63 541 95 66 541 minecraft:blackstone
setblock 95 63 545 minecraft:smooth_basalt
fill 95 63 546 96 65 546 minecraft:blackstone
setblock 95 63 549 minecraft:blackstone
setblock 95 63 550 minecraft:smooth_basalt
setblock 96 63 513 minecraft:blackstone
setblock 96 63 514 minecraft:smooth_basalt
fill 96 63 515 96 66 515 minecraft:blackstone
setblock 96 63 519 minecraft:smooth_basalt
fill 96 63 520 96 66 520 minecraft:blackstone
setblock 96 63 524 minecraft:smooth_basalt
fill 96 63 525 96 66 525 minecraft:blackstone
setblock 96 63 528 minecraft:blackstone
setblock 96 63 543 minecraft:blackstone
setblock 96 63 544 minecraft:smooth_basalt
fill 96 63 545 96 66 545 minecraft:blackstone
fill 96 63 547 96 64 547 minecraft:blackstone
fill 96 63 551 98 63 551 minecraft:blackstone
setblock 97 63 512 minecraft:blackstone
setblock 97 63 518 minecraft:smooth_basalt
fill 97 63 519 97 66 519 minecraft:blackstone
setblock 97 63 523 minecraft:smooth_basalt
fill 97 63 524 97 66 524 minecraft:blackstone
fill 97 63 526 97 64 526 minecraft:blackstone
setblock 98 63 512 minecraft:smooth_basalt
fill 98 63 530 99 64 531 minecraft:gold_block
setblock 99 63 511 minecraft:smooth_basalt
fill 99 63 512 99 66 512 minecraft:blackstone
fill 99 63 529 99 64 529 minecraft:gold_block
setblock 99 63 550 minecraft:blackstone
setblock 99 63 551 minecraft:smooth_basalt
fill 100 63 511 100 66 511 minecraft:blackstone
fill 100 63 551 100 66 551 minecraft:blackstone
setblock 104 63 551 minecraft:smooth_basalt
fill 111 63 551 112 64 551 minecraft:blackstone
fill 113 63 550 114 63 550 minecraft:blackstone
setblock 114 63 551 minecraft:smooth_basalt
setblock 115 63 550 minecraft:smooth_basalt
fill 115 63 551 115 66 551 minecraft:blackstone
setblock 116 63 549 minecraft:smooth_basalt
fill 116 63 550 116 66 550 minecraft:blackstone
fill 117 63 549 119 64 549 minecraft:blackstone
setblock 119 63 551 minecraft:smooth_basalt
setblock 120 63 550 minecraft:smooth_basalt
fill 120 63 551 120 66 551 minecraft:blackstone
fill 133 63 523 133 65 524 minecraft:blackstone
setblock 134 63 521 minecraft:smooth_basalt
fill 134 63 522 134 66 522 minecraft:blackstone
fill 134 63 524 134 63 525 minecraft:blackstone
setblock 134 63 526 minecraft:smooth_basalt
fill 134 63 527 134 64 529 minecraft:blackstone
setblock 135 63 515 minecraft:smooth_basalt
fill 135 63 516 135 66 516 minecraft:blackstone
setblock 135 63 520 minecraft:smooth_basalt
fill 135 63 521 135 66 521 minecraft:blackstone
setblock 135 63 525 minecraft:smooth_basalt
fill 135 63 526 135 66 526 minecraft:blackstone
setblock 135 63 530 minecraft:smooth_basalt
fill 135 63 531 135 66 531 minecraft:blackstone
setblock 135 63 535 minecraft:smooth_basalt
fill 135 63 536 135 66 536 minecraft:blackstone
setblock 135 63 540 minecraft:smooth_basalt
fill 135 63 541 135 66 541 minecraft:blackstone
setblock 135 63 545 minecraft:smooth_basalt
fill 135 63 546 135 66 546 minecraft:blackstone
fill 135 63 548 135 64 548 minecraft:blackstone
fill 95 64 511 97 64 511 minecraft:blackstone
setblock 95 64 514 minecraft:smooth_basalt
fill 95 64 515 95 67 515 minecraft:blackstone
setblock 95 64 519 minecraft:smooth_basalt
fill 95 64 520 95 67 520 minecraft:blackstone
setblock 95 64 524 minecraft:smooth_basalt
fill 95 64 525 95 67 525 minecraft:blackstone
setblock 95 64 529 minecraft:smooth_basalt
fill 95 64 530 95 66 531 minecraft:blackstone
setblock 95 64 539 minecraft:smooth_basalt
fill 95 64 540 95 67 540 minecraft:blackstone
setblock 95 64 544 minecraft:smooth_basalt
fill 95 64 545 95 67 545 minecraft:blackstone
setblock 95 64 549 minecraft:smooth_basalt
fill 95 64 550 97 64 551 minecraft:blackstone
setblock 96 64 512 minecraft:blackstone
setblock 96 64 513 minecraft:smooth_basalt
fill 96 64 514 96 67 514 minecraft:blackstone
setblock 96 64 518 minecraft:smooth_basalt
fill 96 64 519 96 67 519 minecraft:blackstone
setblock 96 64 523 minecraft:smooth_basalt
fill 96 64 524 96 67 524 minecraft:blackstone
setblock 96 64 528 minecraft:smooth_basalt
fill 96 64 529 96 67 529 minecraft:blackstone
setblock 96 64 542 minecraft:blackstone
setblock 96 64 543 minecraft:smooth_basalt
fill 96 64 544 96 67 544 minecraft:blackstone
setblock 96 64 548 minecraft:smooth_basalt
fill 96 64 549 96 67 549 minecraft:blackstone
setblock 97 64 512 minecraft:smooth_basalt
setblock 97 64 513 minecraft:light[level=12]
setblock 97 64 517 minecraft:smooth_basalt
fill 97 64 518 97 67 518 minecraft:blackstone
setblock 97 64 522 minecraft:smooth_basalt
fill 97 64 523 97 67 523 minecraft:blackstone
setblock 97 64 529 minecraft:light[level=12]
setblock 97 64 537 minecraft:light[level=12]
setblock 98 64 511 minecraft:smooth_basalt
fill 98 64 512 98 67 512 minecraft:blackstone
setblock 98 64 521 minecraft:smooth_basalt
fill 98 64 522 98 65 522 minecraft:blackstone
setblock 98 64 550 minecraft:blackstone
setblock 98 64 551 minecraft:smooth_basalt
fill 99 64 511 99 67 511 minecraft:blackstone
setblock 99 64 550 minecraft:smooth_basalt
fill 99 64 551 99 67 551 minecraft:blackstone
fill 100 64 550 102 65 550 minecraft:blackstone
setblock 103 64 511 minecraft:smooth_basalt
setblock 103 64 551 minecraft:smooth_basalt
fill 104 64 551 107 64 551 minecraft:blackstone
setblock 105 64 513 minecraft:light[level=12]
setblock 105 64 521 minecraft:light[level=12]
setblock 105 64 529 minecraft:light[level=12]
setblock 105 64 537 minecraft:light[level=12]
setblock 105 64 545 minecraft:light[level=12]
setblock 108 64 551 minecraft:smooth_basalt
fill 109 64 551 110 66 551 minecraft:blackstone
fill 111 64 550 113 64 550 minecraft:blackstone
setblock 113 64 513 minecraft:light[level=12]
setblock 113 64 521 minecraft:light[level=12]
setblock 113 64 529 minecraft:light[level=12]
setblock 113 64 537 minecraft:light[level=12]
setblock 113 64 545 minecraft:light[level=12]
setblock 113 64 551 minecraft:smooth_basalt
setblock 114 64 549 minecraft:blackstone
setblock 114 64 550 minecraft:smooth_basalt
fill 114 64 551 114 67 551 minecraft:blackstone
setblock 115 64 549 minecraft:smooth_basalt
fill 115 64 550 115 67 550 minecraft:blackstone
fill 116 64 549 116 67 549 minecraft:blackstone
setblock 118 64 551 minecraft:smooth_basalt
setblock 119 64 550 minecraft:smooth_basalt
fill 119 64 551 119 67 551 minecraft:blackstone
fill 120 64 550 121 66 550 minecraft:blackstone
setblock 121 64 513 minecraft:light[level=12]
setblock 121 64 521 minecraft:light[level=12]
setblock 121 64 529 minecraft:light[level=12]
setblock 121 64 537 minecraft:light[level=12]
setblock 121 64 545 minecraft:light[level=12]
setblock 129 64 513 minecraft:light[level=12]
setblock 129 64 521 minecraft:light[level=12]
setblock 129 64 529 minecraft:light[level=12]
setblock 129 64 537 minecraft:light[level=12]
setblock 129 64 545 minecraft:light[level=12]
setblock 133 64 521 minecraft:smooth_basalt
fill 133 64 522 133 67 522 minecraft:blackstone
setblock 133 64 525 minecraft:blackstone
setblock 133 64 526 minecraft:smooth_basalt
fill 133 64 527 133 67 527 minecraft:blackstone
setblock 134 64 520 minecraft:smooth_basalt
fill 134 64 521 134 67 521 minecraft:blackstone
setblock 134 64 524 minecraft:blackstone
setblock 134 64 525 minecraft:smooth_basalt
fill 134 64 526 134 67 526 minecraft:blackstone
setblock 134 64 530 minecraft:smooth_basalt
fill 134 64 542 134 64 544 minecraft:blackstone
setblock 134 64 545 minecraft:smooth_basalt
setblock 135 64 514 minecraft:smooth_basalt
fill 135 64 515 135 67 515 minecraft:blackstone
setblock 135 64 519 minecraft:smooth_basalt
fill 135 64 520 135 67 520 minecraft:blackstone
setblock 135 64 524 minecraft:smooth_basalt
fill 135 64 525 135 67 525 minecraft:blackstone
setblock 135 64 529 minecraft:smooth_basalt
fill 135 64 530 135 67 530 minecraft:blackstone
setblock 135 64 534 minecraft:smooth_basalt
fill 135 64 535 135 67 535 minecraft:blackstone
setblock 135 64 539 minecraft:smooth_basalt
fill 135 64 540 135 67 540 minecraft:blackstone
setblock 135 64 544 minecraft:smooth_basalt
fill 135 64 545 135 67 545 minecraft:blackstone
setblock 135 64 549 minecraft:smooth_basalt
fill 135 64 550 135 67 550 minecraft:blackstone
fill 95 65 511 96 65 511 minecraft:blackstone
setblock 95 65 513 minecraft:smooth_basalt
fill 95 65 514 95 68 514 minecraft:blackstone
setblock 95 65 518 minecraft:smooth_basalt
fill 95 65 519 95 68 519 minecraft:blackstone
setblock 95 65 523 minecraft:smooth_basalt
fill 95 65 524 95 68 524 minecraft:blackstone
setblock 95 65 527 minecraft:blackstone
setblock 95 65 528 minecraft:smooth_basalt
fill 95 65 529 95 68 529 minecraft:blackstone
setblock 95 65 532 minecraft:blackstone
fill 95 65 539 95 68 539 minecraft:blackstone
setblock 95 65 543 minecraft:smooth_basalt
fill 95 65 544 95 68 544 minecraft:blackstone
setblock 95 65 547 minecraft:blackstone
setblock 95 65 548 minecraft:smooth_basalt
fill 95 65 549 95 66 551 minecraft:blackstone
setblock 96 65 512 minecraft:smooth_basalt
fill 96 65 513 96 68 513 minecraft:blackstone
setblock 96 65 517 minecraft:smooth_basalt
fill 96 65 518 96 68 518 minecraft:blackstone
setblock 96 65 522 minecraft:smooth_basalt
fill 96 65 523 96 68 523 minecraft:blackstone
setblock 96 65 527 minecraft:smooth_basalt
fill 96 65 528 96 68 528 minecraft:blackstone
fill 96 65 530 96 66 530 minecraft:blackstone
setblock 96 65 542 minecraft:smooth_basalt
fill 96 65 543 96 68 543 minecraft:blackstone
setblock 96 65 547 minecraft:smooth_basalt
fill 96 65 548 97 67 548 minecraft:blackstone
fill 96 65 550 96 65 551 minecraft:blackstone
setblock 97 65 511 minecraft:smooth_basalt
fill 97 65 512 97 68 512 minecraft:blackstone
setblock 97 65 516 minecraft:smooth_basalt
fill 97 65 517 97 67 517 minecraft:blackstone
setblock 97 65 521 minecraft:smooth_basalt
fill 97 65 522 97 68 522 minecraft:blackstone
setblock 97 65 526 minecraft:smooth_basalt
fill 97 65 527 97 68 527 minecraft:blackstone
setblock 97 65 545 minecraft:blackstone
setblock 97 65 546 minecraft:smooth_basalt
fill 97 65 547 97 68 547 minecraft:blackstone
fill 97 65 549 97 65 550 minecraft:blackstone
setblock 97 65 551 minecraft:smooth_basalt
fill 98 65 511 98 68 511 minecraft:blackstone
setblock 98 65 549 minecraft:blackstone
setblock 98 65 550 minecraft:smooth_basalt
fill 98 65 551 98 68 551 minecraft:blackstone
setblock 99 65 549 minecraft:smooth_basalt
fill 99 65 550 99 68 550 minecraft:blackstone
setblock 102 65 511 minecraft:smooth_basalt
setblock 102 65 551 minecraft:smooth_basalt
fill 103 65 511 103 68 511 minecraft:blackstone
setblock 103 65 550 minecraft:smooth_basalt
fill 103 65 551 106 65 551 minecraft:blackstone
setblock 107 65 551 minecraft:smooth_basalt
fill 108 65 551 108 68 551 minecraft:blackstone
fill 109 65 550 112 65 550 minecraft:blackstone
setblock 111 65 551 minecraft:blackstone
fill 112 65 549 113 65 549 minecraft:blackstone
setblock 112 65 551 minecraft:smooth_basalt
setblock 113 65 550 minecraft:smooth_basalt
fill 113 65 551 113 68 551 minecraft:blackstone
fill 114 65 511 116 65 511 minecraft:blackstone
setblock 114 65 548 minecraft:blackstone
setblock 114 65 549 minecraft:smooth_basalt
fill 114 65 550 114 68 550 minecraft:blackstone
setblock 115 65 548 minecraft:smooth_basalt
fill 115 65 549 115 68 549 minecraft:blackstone
fill 116 65 548 118 66 548 minecraft:blackstone
setblock 117 65 511 minecraft:smooth_basalt
fill 117 65 549 118 65 549 minecraft:blackstone
setblock 117 65 551 minecraft:smooth_basalt
setblock 118 65 550 minecraft:smooth_basalt
fill 118 65 551 118 68 551 minecraft:blackstone
setblock 119 65 549 minecraft:smooth_basalt
fill 119 65 550 119 68 550 minecraft:blackstone
fill 120 65 549 120 68 549 minecraft:blackstone
setblock 122 65 551 minecraft:smooth_basalt
fill 125 65 528 127 66 528 minecraft:gilded_blackstone
fill 126 65 527 127 66 527 minecraft:gilded_blackstone
setblock 133 65 520 minecraft:smooth_basalt
fill 133 65 521 133 68 521 minecraft:blackstone
setblock 133 65 525 minecraft:smooth_basalt
fill 133 65 526 133 68 526 minecraft:blackstone
fill 133 65 528 134 65 528 minecraft:blackstone
fill 134 65 517 134 66 517 minecraft:blackstone
setblock 134 65 519 minecraft:smooth_basalt
fill 134 65 520 134 68 520 minecraft:blackstone
setblock 134 65 524 minecraft:smooth_basalt
fill 134 65 525 134 68 525 minecraft:blackstone
fill 134 65 527 134 66 527 minecraft:blackstone
setblock 134 65 529 minecraft:smooth_basalt
fill 134 65 530 134 66 532 minecraft:blackstone
fill 134 65 541 134 65 543 minecraft:blackstone
setblock 134 65 544 minecraft:smooth_basalt
fill 134 65 545 134 66 547 minecraft:blackstone
fill 134 65 551 135 66 551 minecraft:blackstone
fill 135 65 511 135 65 512 minecraft:blackstone
setblock 135 65 513 minecraft:smooth_basalt
fill 135 65 514 135 68 514 minecraft:blackstone
setblock 135 65 518 minecraft:smooth_basalt
fill 135 65 519 135 68 519 minecraft:blackstone
setblock 135 65 523 minecraft:smooth_basalt
fill 135 65 524 135 68 524 minecraft:blackstone
setblock 135 65 528 minecraft:smooth_basalt
fill 135 65 529 135 68 529 minecraft:blackstone
setblock 135 65 533 minecraft:smooth_basalt
fill 135 65 534 135 68 534 minecraft:blackstone
setblock 135 65 538 minecraft:smooth_basalt
fill 135 65 539 135 68 539 minecraft:blackstone
setblock 135 65 543 minecraft:smooth_basalt
fill 135 65 544 135 68 544 minecraft:blackstone
setblock 135 65 548 minecraft:smooth_basalt
fill 135 65 549 135 68 549 minecraft:blackstone
setblock 95 66 511 minecraft:blackstone
setblock 95 66 512 minecraft:smooth_basalt
fill 95 66 513 95 69 513 minecraft:blackstone
setblock 95 66 517 minecraft:smooth_basalt
fill 95 66 518 95 69 518 minecraft:blackstone
setblock 95 66 522 minecraft:smooth_basalt
fill 95 66 523 95 69 523 minecraft:blackstone
setblock 95 66 527 minecraft:smooth_basalt
fill 95 66 528 95 69 528 minecraft:blackstone
setblock 95 66 532 minecraft:smooth_basalt
fill 95 66 533 95 68 534 minecraft:blackstone
setblock 95 66 542 minecraft:smooth_basalt
fill 95 66 543 95 69 543 minecraft:blackstone
setblock 95 66 546 minecraft:blackstone
setblock 95 66 547 minecraft:smooth_basalt
fill 95 66 548 95 69 548 minecraft:blackstone
setblock 96 66 511 minecraft:smooth_basalt
fill 96 66 512 96 69 512 minecraft:blackstone
setblock 96 66 516 minecraft:smooth_basalt
fill 96 66 517 96 69 517 minecraft:blackstone
setblock 96 66 521 minecraft:smooth_basalt
fill 96 66 522 96 69 522 minecraft:blackstone
setblock 96 66 526 minecraft:smooth_basalt
fill 96 66 527 96 69 527 minecraft:blackstone
fill 96 66 542 96 68 542 minecraft:blackstone
setblock 96 66 546 minecraft:smooth_basalt
fill 96 66 547 96 69 547 minecraft:blackstone
setblock 96 66 550 minecraft:blackstone
setblock 96 66 551 minecraft:smooth_basalt
fill 97 66 511 97 69 511 minecraft:blackstone
fill 97 66 516 97 67 516 minecraft:blackstone
setblock 97 66 520 minecraft:smooth_basalt
fill 97 66 521 97 69 521 minecraft:blackstone
setblock 97 66 525 minecraft:smooth_basalt
fill 97 66 526 97 69 526 minecraft:blackstone
fill 97 66 528 97 67 528 minecraft:blackstone
setblock 97 66 544 minecraft:blackstone
setblock 97 66 545 minecraft:smooth_basalt
fill 97 66 546 97 69 546 minecraft:blackstone
setblock 97 66 549 minecraft:blackstone
setblock 97 66 550 minecraft:smooth_basalt
fill 97 66 551 97 69 551 minecraft:blackstone
setblock 98 66 549 minecraft:smooth_basalt
fill 98 66 550 98 69 550 minecraft:blackstone
fill 99 66 549 101 67 549 minecraft:blackstone
setblock 100 66 512 minecraft:smooth_basalt
fill 100 66 550 101 66 550 minecraft:blackstone
setblock 101 66 511 minecraft:smooth_basalt
setblock 101 66 551 minecraft:smooth_basalt
fill 102 66 511 102 69 511 minecraft:blackstone
setblock 102 66 550 minecraft:smooth_basalt
fill 102 66 551 105 66 551 minecraft:blackstone
fill 103 66 550 106 66 550 minecraft:blackstone
fill 104 66 511 104 67 511 minecraft:blackstone
setblock 106 66 551 minecraft:smooth_basalt
setblock 107 66 550 minecraft:smooth_basalt
fill 107 66 551 107 69 551 minecraft:blackstone
fill 108 66 550 111 66 550 minecraft:blackstone
fill 110 66 549 112 66 549 minecraft:blackstone
setblock 111 66 511 minecraft:smooth_basalt
setblock 111 66 551 minecraft:smooth_basalt
fill 112 66 511 115 66 511 minecraft:blackstone
fill 112 66 548 113 66 548 minecraft:blackstone
setblock 112 66 550 minecraft:smooth_basalt
fill 112 66 551 112 69 551 minecraft:blackstone
setblock 113 66 549 minecraft:smooth_basalt
fill 113 66 550 113 69 550 minecraft:blackstone
setblock 114 66 548 minecraft:smooth_basalt
fill 114 66 549 114 69 549 minecraft:blackstone
fill 115 66 548 115 69 548 minecraft:blackstone
setblock 116 66 511 minecraft:smooth_basalt
setblock 116 66 551 minecraft:smooth_basalt
fill 117 66 511 118 68 511 minecraft:blackstone
setblock 117 66 549 minecraft:blackstone
setblock 117 66 550 minecraft:smooth_basalt
fill 117 66 551 117 69 551 minecraft:blackstone
setblock 118 66 549 minecraft:smooth_basalt
fill 118 66 550 118 69 550 minecraft:blackstone
setblock 119 66 548 minecraft:smooth_basalt
fill 119 66 549 119 69 549 minecraft:blackstone
setblock 121 66 551 minecraft:smooth_basalt
fill 122 66 551 123 68 551 minecraft:blackstone
setblock 132 66 524 minecraft:blackstone
setblock 132 66 525 minecraft:smooth_basalt
fill 132 66 526 132 69 526 minecraft:blackstone
fill 132 66 551 133 68 551 minecraft:blackstone
fill 133 66 511 135 66 511 minecraft:blackstone
fill 133 66 520 133 69 520 minecraft:blackstone
setblock 133 66 523 minecraft:blackstone
setblock 133 66 524 minecraft:smooth_basalt
fill 133 66 525 133 69 525 minecraft:blackstone
setblock 133 66 528 minecraft:blackstone
setblock 133 66 529 minecraft:smooth_basalt
fill 133 66 530 133 69 530 minecraft:blackstone
fill 134 66 516 134 67 516 minecraft:blackstone
setblock 134 66 518 minecraft:smooth_basalt
fill 134 66 519 134 69 519 minecraft:blackstone
setblock 134 66 523 minecraft:smooth_basalt
fill 134 66 524 134 69 524 minecraft:blackstone
setblock 134 66 528 minecraft:smooth_basalt
fill 134 66 529 134 69 529 minecraft:blackstone
setblock 134 66 533 minecraft:smooth_basalt
fill 134 66 541 134 66 542 minecraft:blackstone
setblock 134 66 543 minecraft:smooth_basalt
fill 134 66 544 134 69 544 minecraft:blackstone
setblock 134 66 548 minecraft:smooth_basalt
fill 134 66 549 134 69 549 minecraft:blackstone
setblock 135 66 512 minecraft:smooth_basalt
fill 135 66 513 135 69 513 minecraft:blackstone
setblock 135 66 517 minecraft:smooth_basalt
fill 135 66 518 135 69 518 minecraft:blackstone
setblock 135 66 522 minecraft:smooth_basalt
fill 135 66 523 135 69 523 minecraft:blackstone
setblock 135 66 527 minecraft:smooth_basalt
fill 135 66 528 135 69 528 minecraft:blackstone
setblock 135 66 532 minecraft:smooth_basalt
fill 135 66 533 135 69 533 minecraft:blackstone
setblock 135 66 537 minecraft:smooth_basalt
fill 135 66 538 135 69 538 minecraft:blackstone
setblock 135 66 542 minecraft:smooth_basalt
fill 135 66 543 135 69 543 minecraft:blackstone
setblock 135 66 547 minecraft:smooth_basalt
fill 135 66 548 135 69 548 minecraft:blackstone
setblock 95 67 511 minecraft:smooth_basalt
fill 95 67 512 95 70 512 minecraft:blackstone
setblock 95 67 516 minecraft:smooth_basalt
fill 95 67 517 95 70 517 minecraft:blackstone
setblock 95 67 521 minecraft:smooth_basalt
fill 95 67 522 95 70 522 minecraft:blackstone
setblock 95 67 526 minecraft:smooth_basalt
fill 95 67 527 95 70 527 minecraft:blackstone
setblock 95 67 530 minecraft:blackstone
setblock 95 67 531 minecraft:smooth_basalt
fill 95 67 532 95 70 532 minecraft:blackstone
setblock 95 67 535 minecraft:blackstone
fill 95 67 538 95 69 538 minecraft:blackstone
setblock 95 67 541 minecraft:smooth_basalt
fill 95 67 542 95 70 542 minecraft:blackstone
setblock 95 67 546 minecraft:smooth_basalt
fill 95 67 547 95 70 547 minecraft:blackstone
fill 95 67 549 95 67 550 minecraft:blackstone
setblock 95 67 551 minecraft:smooth_basalt
fill 96 67 511 96 70 511 minecraft:blackstone
setblock 96 67 515 minecraft:smooth_basalt
fill 96 67 516 96 70 516 minecraft:blackstone
setblock 96 67 520 minecraft:smooth_basalt
fill 96 67 521 96 70 521 minecraft:blackstone
setblock 96 67 525 minecraft:smooth_basalt
fill 96 67 526 96 70 526 minecraft:blackstone
setblock 96 67 530 minecraft:smooth_basalt
fill 96 67 531 96 70 531 minecraft:blackstone
setblock 96 67 545 minecraft:smooth_basalt
fill 96 67 546 96 70 546 minecraft:blackstone
setblock 96 67 550 minecraft:smooth_basalt
fill 96 67 551 96 70 551 minecraft:blackstone
setblock 97 67 513 minecraft:blackstone
setblock 97 67 519 minecraft:smooth_basalt
fill 97 67 520 97 69 520 minecraft:blackstone
setblock 97 67 524 minecraft:smooth_basalt
fill 97 67 525 97 70 525 minecraft:blackstone
fill 97 67 544 97 77 544 minecraft:smooth_basalt
fill 97 67 545 97 69 545 minecraft:blackstone
setblock 97 67 549 minecraft:smooth_basalt
fill 97 67 550 97 70 550 minecraft:blackstone
fill 98 67 549 98 70 549 minecraft:blackstone
setblock 99 67 512 minecraft:smooth_basalt
setblock 100 67 511 minecraft:smooth_basalt
fill 100 67 512 101 69 512 minecraft:blackstone
setblock 100 67 550 minecraft:blackstone
setblock 100 67 551 minecraft:smooth_basalt
fill 101 67 511 101 70 511 minecraft:blackstone
setblock 101 67 550 minecraft:smooth_basalt
fill 101 67 551 104 67 551 minecraft:blackstone
setblock 102 67 549 minecraft:smooth_basalt
fill 102 67 550 105 67 550 minecraft:blackstone
setblock 105 67 511 minecraft:smooth_basalt
setblock 105 67 551 minecraft:smooth_basalt
setblock 106 67 550 minecraft:smooth_basalt
fill 106 67 551 106 70 551 minecraft:blackstone
fill 107 67 550 110 67 550 minecraft:blackstone
fill 108 67 549 111 67 549 minecraft:blackstone
setblock 109 67 511 minecraft:blackstone
setblock 109 67 551 minecraft:blackstone
setblock 110 67 511 minecraft:smooth_basalt
setblock 110 67 551 minecraft:smooth_basalt
fill 111 67 511 114 67 511 minecraft:blackstone
fill 111 67 548 112 67 548 minecraft:blackstone
setblock 111 67 550 minecraft:smooth_basalt
fill 111 67 551 111 70 551 minecraft:blackstone
setblock 112 67 549 minecraft:smooth_basalt
fill 112 67 550 112 70 550 minecraft:blackstone
setblock 113 67 548 minecraft:smooth_basalt
fill 113 67 549 113 70 549 minecraft:blackstone
setblock 114 67 547 minecraft:smooth_basalt
fill 114 67 548 114 70 548 minecraft:blackstone
setblock 115 67 511 minecraft:smooth_basalt
fill 115 67 547 116 68 547 minecraft:blackstone
setblock 115 67 551 minecraft:smooth_basalt
fill 116 67 511 116 70 511 minecraft:blackstone
fill 116 67 548 117 67 548 minecraft:blackstone
setblock 116 67 550 minecraft:smooth_basalt
fill 116 67 551 116 70 551 minecraft:blackstone
setblock 117 67 549 minecraft:smooth_basalt
fill 117 67 550 117 70 550 minecraft:blackstone
setblock 118 67 548 minecraft:smooth_basalt
fill 118 67 549 118 70 549 minecraft:blackstone
setblock 119 67 511 minecraft:blackstone
fill 119 67 548 119 68 548 minecraft:blackstone
setblock 120 67 550 minecraft:blackstone
setblock 120 67 551 minecraft:smooth_basalt
setblock 121 67 550 minecraft:smooth_basalt
fill 121 67 551 121 70 551 minecraft:blackstone
fill 122 67 550 122 68 550 minecraft:blackstone
fill 131 67 551 131 70 551 minecraft:blackstone
fill 132 67 511 134 67 511 minecraft:blackstone
setblock 132 67 523 minecraft:blackstone
setblock 132 67 524 minecraft:smooth_basalt
fill 132 67 525 132 70 525 minecraft:blackstone
fill 132 67 527 132 67 528 minecraft:blackstone
fill 133 67 519 133 70 519 minecraft:blackstone
setblock 133 67 523 minecraft:smooth_basalt
fill 133 67 524 133 70 524 minecraft:blackstone
setblock 133 67 528 minecraft:smooth_basalt
fill 133 67 529 133 70 529 minecraft:blackstone
fill 133 67 531 134 67 531 minecraft:blackstone
fill 133 67 550 134 68 550 minecraft:blackstone
setblock 134 67 512 minecraft:smooth_basalt
fill 134 67 514 134 68 515 minecraft:blackstone
setblock 134 67 517 minecraft:smooth_basalt
fill 134 67 518 134 70 518 minecraft:blackstone
setblock 134 67 522 minecraft:smooth_basalt
fill 134 67 523 134 70 523 minecraft:blackstone
setblock 134 67 527 minecraft:smooth_basalt
fill 134 67 528 134 70 528 minecraft:blackstone
fill 134 67 530 134 68 530 minecraft:blackstone
setblock 134 67 532 minecraft:smooth_basalt
fill 134 67 533 134 68 535 minecraft:blackstone
setblock 134 67 541 minecraft:blackstone
setblock 134 67 542 minecraft:smooth_basalt
fill 134 67 543 134 69 543 minecraft:blackstone
fill 134 67 545 134 67 546 minecraft:blackstone
setblock 134 67 547 minecraft:smooth_basalt
fill 134 67 548 134 70 548 minecraft:blackstone
setblock 134 67 551 minecraft:blackstone
setblock 135 67 511 minecraft:smooth_basalt
fill 135 67 512 135 70 512 minecraft:blackstone
setblock 135 67 516 minecraft:smooth_basalt
fill 135 67 517 135 70 517 minecraft:blackstone
setblock 135 67 521 minecraft:smooth_basalt
fill 135 67 522 135 70 522 minecraft:blackstone
setblock 135 67 526 minecraft:smooth_basalt
fill 135 67 527 135 70 527 minecraft:blackstone
setblock 135 67 531 minecraft:smooth_basalt
fill 135 67 532 135 70 532 minecraft:blackstone
setblock 135 67 536 minecraft:smooth_basalt
fill 135 67 537 135 70 537 minecraft:blackstone
setblock 135 67 541 minecraft:smooth_basalt
fill 135 67 542 135 70 542 minecraft:blackstone
setblock 135 67 546 minecraft:smooth_basalt
fill 135 67 547 135 70 547 minecraft:blackstone
setblock 135 67 551 minecraft:smooth_basalt
fill 95 68 511 95 71 511 minecraft:blackstone
setblock 95 68 515 minecraft:smooth_basalt
fill 95 68 516 95 71 516 minecraft:blackstone
setblock 95 68 520 minecraft:smooth_basalt
fill 95 68 521 95 71 521 minecraft:blackstone
setblock 95 68 525 minecraft:smooth_basalt
fill 95 68 526 95 71 526 minecraft:blackstone
setblock 95 68 530 minecraft:smooth_basalt
fill 95 68 531 95 71 531 minecraft:blackstone
setblock 95 68 535 minecraft:smooth_basalt
fill 95 68 536 95 69 537 minecraft:blackstone
setblock 95 68 540 minecraft:smooth_basalt
fill 95 68 541 95 71 541 minecraft:blackstone
setblock 95 68 545 minecraft:smooth_basalt
fill 95 68 546 95 71 546 minecraft:blackstone
setblock 95 68 549 minecraft:blackstone
setblock 95 68 550 minecraft:smooth_basalt
fill 95 68 551 95 71 551 minecraft:blackstone
setblock 96 68 514 minecraft:smooth_basalt
fill 96 68 515 96 71 515 minecraft:blackstone
setblock 96 68 519 minecraft:smooth_basalt
fill 96 68 520 96 71 520 minecraft:blackstone
setblock 96 68 524 minecraft:smooth_basalt
fill 96 68 525 96 71 525 minecraft:blackstone
setblock 96 68 529 minecraft:smooth_basalt
fill 96 68 530 96 71 530 minecraft:blackstone
fill 96 68 532 96 69 532 minecraft:blackstone
setblock 96 68 544 minecraft:smooth_basalt
fill 96 68 545 96 71 545 minecraft:blackstone
setblock 96 68 548 minecraft:blackstone
setblock 96 68 549 minecraft:smooth_basalt
fill 96 68 550 96 71 550 minecraft:blackstone
setblock 97 68 513 minecraft:smooth_basalt
fill 97 68 514 97 69 514 minecraft:blackstone
setblock 97 68 518 minecraft:smooth_basalt
setblock 97 68 519 minecraft:blackstone
setblock 97 68 523 minecraft:smooth_basalt
fill 97 68 524 97 70 524 minecraft:blackstone
setblock 97 68 528 minecraft:smooth_basalt
fill 97 68 529 97 69 529 minecraft:blackstone
setblock 97 68 548 minecraft:smooth_basalt
fill 97 68 549 97 71 549 minecraft:blackstone
setblock 98 68 512 minecraft:smooth_basalt
setblock 99 68 511 minecraft:smooth_basalt
fill 99 68 512 99 71 512 minecraft:blackstone
fill 99 68 549 100 68 549 minecraft:blackstone
setblock 99 68 551 minecraft:smooth_basalt
fill 100 68 511 100 71 511 minecraft:blackstone
setblock 100 68 550 minecraft:smooth_basalt
fill 100 68 551 103 68 551 minecraft:blackstone
setblock 101 68 549 minecraft:smooth_basalt
fill 101 68 550 104 68 550 minecraft:blackstone
fill 102 68 549 105 68 549 minecraft:blackstone
setblock 104 68 511 minecraft:smooth_basalt
setblock 104 68 551 minecraft:smooth_basalt
fill 105 68 511 108 68 511 minecraft:blackstone
setblock 105 68 550 minecraft:smooth_basalt
fill 105 68 551 105 71 551 minecraft:blackstone
setblock 106 68 549 minecraft:smooth_basalt
fill 106 68 550 109 68 550 minecraft:blackstone
fill 107 68 549 110 68 549 minecraft:blackstone
setblock 109 68 511 minecraft:smooth_basalt
setblock 109 68 551 minecraft:smooth_basalt
fill 110 68 511 113 68 511 minecraft:blackstone
fill 110 68 548 111 68 548 minecraft:blackstone
setblock 110 68 550 minecraft:smooth_basalt
fill 110 68 551 110 71 551 minecraft:blackstone
setblock 111 68 549 minecraft:smooth_basalt
fill 111 68 550 111 71 550 minecraft:blackstone
setblock 112 68 548 minecraft:smooth_basalt
fill 112 68 549 112 71 549 minecraft:blackstone
setblock 113 68 547 minecraft:smooth_basalt
fill 113 68 548 113 71 548 minecraft:blackstone
setblock 114 68 511 minecraft:smooth_basalt
fill 114 68 547 114 69 547 minecraft:blackstone
setblock 114 68 551 minecraft:smooth_basalt
fill 115 68 511 115 71 511 minecraft:blackstone
setblock 115 68 550 minecraft:smooth_basalt
fill 115 68 551 115 71 551 minecraft:blackstone
setblock 116 68 548 minecraft:blackstone
setblock 116 68 549 minecraft:smooth_basalt
fill 116 68 550 116 71 550 minecraft:blackstone
setblock 117 68 548 minecraft:smooth_basalt
fill 117 68 549 117 71 549 minecraft:blackstone
fill 118 68 548 118 69 548 minecraft:blackstone
setblock 119 68 511 minecraft:smooth_basalt
setblock 119 68 551 minecraft:smooth_basalt
setblock 120 68 550 minecraft:smooth_basalt
fill 120 68 551 120 71 551 minecraft:blackstone
fill 121 68 550 121 70 550 minecraft:blackstone
setblock 124 68 551 minecraft:smooth_basalt
setblock 129 68 551 minecraft:smooth_basalt
fill 130 68 551 130 71 551 minecraft:blackstone
fill 131 68 511 133 68 511 minecraft:blackstone
fill 131 68 550 132 70 550 minecraft:blackstone
setblock 132 68 522 minecraft:blackstone
setblock 132 68 523 minecraft:smooth_basalt
fill 132 68 524 132 71 524 minecraft:blackstone
setblock 132 68 527 minecraft:blackstone
setblock 132 68 528 minecraft:smooth_basalt
fill 132 68 529 132 71 529 minecraft:blackstone
setblock 133 68 512 minecraft:smooth_basalt
setblock 133 68 522 minecraft:smooth_basalt
fill 133 68 523 133 71 523 minecraft:blackstone
setblock 133 68 527 minecraft:smooth_basalt
fill 133 68 528 133 71 528 minecraft:blackstone
setblock 133 68 531 minecraft:blackstone
setblock 133 68 532 minecraft:smooth_basalt
setblock 134 68 511 minecraft:smooth_basalt
fill 134 68 512 134 70 513 minecraft:blackstone
setblock 134 68 516 minecraft:smooth_basalt
fill 134 68 517 134 71 517 minecraft:blackstone
setblock 134 68 521 minecraft:smooth_basalt
fill 134 68 522 134 71 522 minecraft:blackstone
setblock 134 68 526 minecraft:smooth_basalt
fill 134 68 527 134 71 527 minecraft:blackstone
setblock 134 68 531 minecraft:smooth_basalt
fill 134 68 532 134 71 532 minecraft:blackstone
setblock 134 68 541 minecraft:smooth_basalt
fill 134 68 542 134 69 542 minecraft:blackstone
setblock 134 68 545 minecraft:blackstone
setblock 134 68 546 minecraft:smooth_basalt
fill 134 68 547 134 71 547 minecraft:blackstone
setblock 134 68 551 minecraft:smooth_basalt
fill 135 68 511 135 71 511 minecraft:blackstone
setblock 135 68 515 minecraft:smooth_basalt
fill 135 68 516 135 71 516 minecraft:blackstone
setblock 135 68 520 minecraft:smooth_basalt
fill 135 68 521 135 71 521 minecraft:blackstone
setblock 135 68 525 minecraft:smooth_basalt
fill 135 68 526 135 71 526 minecraft:blackstone
setblock 135 68 530 minecraft:smooth_basalt
fill 135 68 531 135 71 531 minecraft:blackstone
setblock 135 68 535 minecraft:smooth_basalt
fill 135 68 536 135 71 536 minecraft:blackstone
setblock 135 68 540 minecraft:smooth_basalt
fill 135 68 541 135 71 541 minecraft:blackstone
setblock 135 68 545 minecraft:smooth_basalt
fill 135 68 546 135 71 546 minecraft:blackstone
setblock 135 68 550 minecraft:smooth_basalt
fill 135 68 551 135 71 551 minecraft:blackstone
setblock 95 69 514 minecraft:smooth_basalt
fill 95 69 515 95 72 515 minecraft:blackstone
setblock 95 69 519 minecraft:smooth_basalt
fill 95 69 520 95 72 520 minecraft:blackstone
setblock 95 69 524 minecraft:smooth_basalt
fill 95 69 525 95 72 525 minecraft:blackstone
setblock 95 69 529 minecraft:smooth_basalt
fill 95 69 530 95 72 530 minecraft:blackstone
setblock 95 69 533 minecraft:blackstone
setblock 95 69 534 minecraft:smooth_basalt
fill 95 69 535 95 72 535 minecraft:blackstone
setblock 95 69 539 minecraft:smooth_basalt
fill 95 69 540 95 70 540 minecraft:blackstone
setblock 95 69 544 minecraft:smooth_basalt
fill 95 69 545 95 72 545 minecraft:blackstone
setblock 95 69 549 minecraft:smooth_basalt
fill 95 69 550 95 72 550 minecraft:blackstone
setblock 96 69 513 minecraft:smooth_basalt
fill 96 69 514 96 72 514 minecraft:blackstone
setblock 96 69 518 minecraft:smooth_basalt
fill 96 69 519 96 71 519 minecraft:blackstone
setblock 96 69 523 minecraft:smooth_basalt
fill 96 69 524 96 72 524 minecraft:blackstone
setblock 96 69 528 minecraft:smooth_basalt
fill 96 69 529 96 72 529 minecraft:blackstone
fill 96 69 542 96 69 543 minecraft:smooth_basalt
fill 96 69 544 96 71 544 minecraft:blackstone
setblock 96 69 548 minecraft:smooth_basalt
fill 96 69 549 96 72 549 minecraft:blackstone
setblock 97 69 512 minecraft:smooth_basalt
fill 97 69 513 97 71 513 minecraft:blackstone
setblock 97 69 522 minecraft:smooth_basalt
fill 97 69 523 97 70 523 minecraft:blackstone
setblock 97 69 527 minecraft:smooth_basalt
fill 97 69 528 97 70 528 minecraft:blackstone
setblock 97 69 547 minecraft:smooth_basalt
fill 97 69 548 97 72 548 minecraft:blackstone
setblock 98 69 511 minecraft:smooth_basalt
fill 98 69 512 98 72 512 minecraft:blackstone
setblock 98 69 551 minecraft:smooth_basalt
fill 99 69 511 99 72 511 minecraft:blackstone
setblock 99 69 549 minecraft:blackstone
setblock 99 69 550 minecraft:smooth_basalt
fill 99 69 551 102 69 551 minecraft:blackstone
setblock 100 69 549 minecraft:smooth_basalt
fill 100 69 550 103 69 550 minecraft:blackstone
fill 101 69 549 104 69 549 minecraft:blackstone
setblock 103 69 511 minecraft:smooth_basalt
setblock 103 69 551 minecraft:smooth_basalt
fill 104 69 511 107 69 511 minecraft:blackstone
setblock 104 69 550 minecraft:smooth_basalt
fill 104 69 551 104 72 551 minecraft:blackstone
setblock 105 69 549 minecraft:smooth_basalt
fill 105 69 550 108 69 550 minecraft:blackstone
fill 106 69 549 109 69 549 minecraft:blackstone
setblock 108 69 511 minecraft:smooth_basalt
setblock 108 69 551 minecraft:smooth_basalt
fill 109 69 511 112 69 511 minecraft:blackstone
fill 109 69 548 110 69 548 minecraft:blackstone
setblock 109 69 550 minecraft:smooth_basalt
fill 109 69 551 109 72 551 minecraft:blackstone
setblock 110 69 549 minecraft:smooth_basalt
fill 110 69 550 110 72 550 minecraft:blackstone
setblock 111 69 548 minecraft:smooth_basalt
fill 111 69 549 111 72 549 minecraft:blackstone
fill 112 69 548 112 72 548 minecraft:blackstone
setblock 113 69 511 minecraft:smooth_basalt
setblock 113 69 547 minecraft:blackstone
setblock 113 69 551 minecraft:smooth_basalt
fill 114 69 511 114 71 512 minecraft:blackstone
setblock 114 69 550 minecraft:smooth_basalt
fill 114 69 551 114 72 551 minecraft:blackstone
setblock 115 69 547 minecraft:blackstone
setblock 115 69 549 minecraft:smooth_basalt
fill 115 69 550 115 72 550 minecraft:blackstone
setblock 116 69 548 minecraft:smooth_basalt
fill 116 69 549 116 72 549 minecraft:blackstone
setblock 117 69 511 minecraft:blackstone
fill 117 69 548 117 70 548 minecraft:blackstone
setblock 118 69 511 minecraft:smooth_basalt
setblock 118 69 551 minecraft:smooth_basalt
fill 119 69 511 119 70 511 minecraft:blackstone
setblock 119 69 550 minecraft:smooth_basalt
fill 119 69 551 119 72 551 minecraft:blackstone
setblock 120 69 549 minecraft:smooth_basalt
fill 120 69 550 120 71 550 minecraft:blackstone
setblock 122 69 551 minecraft:blackstone
setblock 123 69 551 minecraft:smooth_basalt
fill 124 69 551 124 70 551 minecraft:blackstone
setblock 127 69 551 minecraft:blackstone
setblock 128 69 551 minecraft:smooth_basalt
fill 129 69 511 132 69 511 minecraft:blackstone
fill 129 69 551 129 72 551 minecraft:blackstone
fill 130 69 550 130 72 550 minecraft:blackstone
setblock 132 69 512 minecraft:smooth_basalt
setblock 132 69 522 minecraft:smooth_basalt
fill 132 69 523 132 71 523 minecraft:blackstone
setblock 132 69 527 minecraft:smooth_basalt
fill 132 69 528 132 72 528 minecraft:blackstone
fill 132 69 530 132 70 530 minecraft:blackstone
setblock 132 69 551 minecraft:blackstone
setblock 133 69 511 minecraft:smooth_basalt
fill 133 69 512 133 72 512 minecraft:blackstone
setblock 133 69 521 minecraft:smooth_basalt
fill 133 69 522 133 72 522 minecraft:blackstone
setblock 133 69 526 minecraft:smooth_basalt
fill 133 69 527 133 72 527 minecraft:blackstone
setblock 133 69 531 minecraft:smooth_basalt
fill 133 69 532 133 71 533 minecraft:blackstone
fill 133 69 548 133 69 550 minecraft:blackstone
setblock 133 69 551 minecraft:smooth_basalt
fill 134 69 511 134 72 511 minecraft:blackstone
setblock 134 69 514 minecraft:blackstone
setblock 134 69 515 minecraft:smooth_basalt
fill 134 69 516 134 72 516 minecraft:blackstone
setblock 134 69 520 minecraft:smooth_basalt
fill 134 69 521 134 72 521 minecraft:blackstone
setblock 134 69 525 minecraft:smooth_basalt
fill 134 69 526 134 72 526 minecraft:blackstone
setblock 134 69 530 minecraft:smooth_basalt
fill 134 69 531 134 72 531 minecraft:blackstone
fill 134 69 533 134 69 534 minecraft:blackstone
setblock 134 69 535 minecraft:smooth_basalt
fill 134 69 536 134 70 536 minecraft:blackstone
setblock 134 69 545 minecraft:smooth_basalt
fill 134 69 546 134 71 546 minecraft:blackstone
setblock 134 69 550 minecraft:smooth_basalt
fill 134 69 551 134 72 551 minecraft:blackstone
setblock 135 69 514 minecraft:smooth_basalt
fill 135 69 515 135 72 515 minecraft:blackstone
setblock 135 69 519 minecraft:smooth_basalt
fill 135 69 520 135 72 520 minecraft:blackstone
setblock 135 69 524 minecraft:smooth_basalt
fill 135 69 525 135 72 525 minecraft:blackstone
setblock 135 69 529 minecraft:smooth_basalt
fill 135 69 530 135 72 530 minecraft:blackstone
setblock 135 69 534 minecraft:smooth_basalt
fill 135 69 535 135 72 535 minecraft:blackstone
setblock 135 69 539 minecraft:smooth_basalt
fill 135 69 540 135 70 540 minecraft:blackstone
setblock 135 69 544 minecraft:smooth_basalt
fill 135 69 545 135 72 545 minecraft:blackstone
setblock 135 69 549 minecraft:smooth_basalt
fill 135 69 550 135 72 550 minecraft:blackstone
setblock 95 70 513 minecraft:smooth_basalt
fill 95 70 514 95 73 514 minecraft:blackstone
setblock 95 70 518 minecraft:smooth_basalt
fill 95 70 519 95 73 519 minecraft:blackstone
setblock 95 70 523 minecraft:smooth_basalt
fill 95 70 524 95 73 524 minecraft:blackstone
setblock 95 70 528 minecraft:smooth_basalt
fill 95 70 529 95 73 529 minecraft:blackstone
setblock 95 70 533 minecraft:smooth_basalt
fill 95 70 534 95 73 534 minecraft:blackstone
fill 95 70 536 95 71 536 minecraft:blackstone
setblock 95 70 543 minecraft:smooth_basalt
fill 95 70 544 95 73 544 minecraft:blackstone
setblock 95 70 548 minecraft:smooth_basalt
fill 95 70 549 95 73 549 minecraft:blackstone
setblock 96 70 512 minecraft:smooth_basalt
fill 96 70 513 96 73 513 minecraft:blackstone
setblock 96 70 517 minecraft:smooth_basalt
fill 96 70 518 96 71 518 minecraft:blackstone
setblock 96 70 522 minecraft:smooth_basalt
fill 96 70 523 96 72 523 minecraft:blackstone
setblock 96 70 527 minecraft:smooth_basalt
fill 96 70 528 96 73 528 minecraft:blackstone
setblock 96 70 532 minecraft:smooth_basalt
fill 96 70 542 96 77 542 minecraft:smooth_basalt
setblock 96 70 543 minecraft:blackstone
setblock 96 70 547 minecraft:smooth_basalt
fill 96 70 548 96 73 548 minecraft:blackstone
setblock 97 70 511 minecraft:smooth_basalt
fill 97 70 512 97 73 512 minecraft:blackstone
setblock 97 70 526 minecraft:smooth_basalt
setblock 97 70 527 minecraft:blackstone
fill 97 70 545 97 70 546 minecraft:smooth_basalt
fill 97 70 547 97 71 547 minecraft:blackstone
setblock 97 70 551 minecraft:smooth_basalt
fill 98 70 511 98 73 511 minecraft:blackstone
setblock 98 70 550 minecraft:smooth_basalt
fill 98 70 551 101 70 551 minecraft:blackstone
setblock 99 70 549 minecraft:smooth_basalt
fill 99 70 550 102 70 550 minecraft:blackstone
setblock 100 70 512 minecraft:blackstone
fill 100 70 549 103 70 549 minecraft:blackstone
setblock 101 70 512 minecraft:smooth_basalt
setblock 102 70 511 minecraft:smooth_basalt
setblock 102 70 551 minecraft:smooth_basalt
fill 103 70 511 106 70 511 minecraft:blackstone
setblock 103 70 550 minecraft:smooth_basalt
fill 103 70 551 103 73 551 minecraft:blackstone
setblock 104 70 549 minecraft:smooth_basalt
fill 104 70 550 107 70 550 minecraft:blackstone
fill 105 70 549 108 70 549 minecraft:blackstone
setblock 107 70 511 minecraft:smooth_basalt
setblock 107 70 551 minecraft:smooth_basalt
fill 108 70 511 111 70 511 minecraft:blackstone
setblock 108 70 550 minecraft:smooth_basalt
fill 108 70 551 108 73 551 minecraft:blackstone
setblock 109 70 548 minecraft:blackstone
setblock 109 70 549 minecraft:smooth_basalt
fill 109 70 550 109 73 550 minecraft:blackstone
setblock 110 70 548 minecraft:smooth_basalt
fill 110 70 549 110 73 549 minecraft:blackstone
fill 111 70 548 111 72 548 minecraft:blackstone
setblock 112 70 511 minecraft:smooth_basalt
fill 112 70 512 113 72 512 minecraft:blackstone
setblock 112 70 551 minecraft:smooth_basalt
fill 113 70 511 113 73 511 minecraft:blackstone
setblock 113 70 550 minecraft:smooth_basalt
fill 113 70 551 113 73 551 minecraft:blackstone
setblock 114 70 549 minecraft:smooth_basalt
fill 114 70 550 114 73 550 minecraft:blackstone
setblock 115 70 548 minecraft:smooth_basalt
fill 115 70 549 115 73 549 minecraft:blackstone
fill 116 70 548 116 71 548 minecraft:blackstone
setblock 117 70 511 minecraft:smooth_basalt
setblock 117 70 551 minecraft:smooth_basalt
fill 118 70 511 118 72 511 minecraft:blackstone
setblock 118 70 550 minecraft:smooth_basalt
fill 118 70 551 118 73 551 minecraft:blackstone
setblock 119 70 549 minecraft:smooth_basalt
fill 119 70 550 119 72 550 minecraft:blackstone
setblock 122 70 551 minecraft:smooth_basalt
fill 123 70 551 123 71 551 minecraft:blackstone
setblock 126 70 551 minecraft:blackstone
setblock 127 70 551 minecraft:smooth_basalt
fill 128 70 551 128 73 551 minecraft:blackstone
fill 129 70 511 131 70 511 minecraft:blackstone
setblock 131 70 512 minecraft:smooth_basalt
setblock 132 70 511 minecraft:smooth_basalt
fill 132 70 512 132 73 512 minecraft:blackstone
setblock 132 70 526 minecraft:smooth_basalt
fill 132 70 527 132 73 527 minecraft:blackstone
setblock 132 70 531 minecraft:smooth_basalt
setblock 132 70 551 minecraft:smooth_basalt
fill 133 70 511 133 73 511 minecraft:blackstone
setblock 133 70 520 minecraft:smooth_basalt
fill 133 70 521 133 72 521 minecraft:blackstone
setblock 133 70 525 minecraft:smooth_basalt
fill 133 70 526 133 73 526 minecraft:blackstone
setblock 133 70 530 minecraft:smooth_basalt
fill 133 70 531 133 73 531 minecraft:blackstone
fill 133 70 548 133 70 549 minecraft:blackstone
setblock 133 70 550 minecraft:smooth_basalt
fill 133 70 551 133 73 551 minecraft:blackstone
setblock 134 70 514 minecraft:smooth_basalt
fill 134 70 515 134 73 515 minecraft:blackstone
setblock 134 70 519 minecraft:smooth_basalt
fill 134 70 520 134 73 520 minecraft:blackstone
setblock 134 70 524 minecraft:smooth_basalt
fill 134 70 525 134 73 525 minecraft:blackstone
setblock 134 70 529 minecraft:smooth_basalt
fill 134 70 530 134 73 530 minecraft:blackstone
setblock 134 70 533 minecraft:blackstone
setblock 134 70 534 minecraft:smooth_basalt
fill 134 70 535 134 73 535 minecraft:blackstone
setblock 134 70 544 minecraft:smooth_basalt
fill 134 70 545 134 71 545 minecraft:blackstone
setblock 134 70 549 minecraft:smooth_basalt
fill 134 70 550 134 73 550 minecraft:blackstone
setblock 135 70 513 minecraft:smooth_basalt
fill 135 70 514 135 73 514 minecraft:blackstone
setblock 135 70 518 minecraft:smooth_basalt
fill 135 70 519 135 73 519 minecraft:blackstone
setblock 135 70 523 minecraft:smooth_basalt
fill 135 70 524 135 73 524 minecraft:blackstone
setblock 135 70 528 minecraft:smooth_basalt
fill 135 70 529 135 73 529 minecraft:blackstone
setblock 135 70 533 minecraft:smooth_basalt
fill 135 70 534 135 73 534 minecraft:blackstone
setblock 135 70 538 minecraft:smooth_basalt
fill 135 70 539 135 71 539 minecraft:blackstone
setblock 135 70 543 minecraft:smooth_basalt
fill 135 70 544 135 72 544 minecraft:blackstone
setblock 135 70 548 minecraft:smooth_basalt
fill 135 70 549 135 73 549 minecraft:blackstone
setblock 95 71 512 minecraft:smooth_basalt
fill 95 71 513 95 74 513 minecraft:blackstone
setblock 95 71 517 minecraft:smooth_basalt
fill 95 71 518 95 74 518 minecraft:blackstone
setblock 95 71 522 minecraft:smooth_basalt
fill 95 71 523 95 74 523 minecraft:blackstone
setblock 95 71 527 minecraft:smooth_basalt
fill 95 71 528 95 74 528 minecraft:blackstone
setblock 95 71 532 minecraft:smooth_basalt
fill 95 71 533 95 74 533 minecraft:blackstone
setblock 95 71 542 minecraft:smooth_basalt
fill 95 71 543 95 72 543 minecraft:blackstone
setblock 95 71 547 minecraft:smooth_basalt
fill 95 71 548 95 74 548 minecraft:blackstone
setblock 96 71 511 minecraft:smooth_basalt
fill 96 71 512 96 74 512 minecraft:blackstone
setblock 96 71 516 minecraft:smooth_basalt
setblock 96 71 517 minecraft:blackstone
setblock 96 71 521 minecraft:smooth_basalt
setblock 96 71 522 minecraft:blackstone
setblock 96 71 526 minecraft:smooth_basalt
fill 96 71 527 96 73 527 minecraft:blackstone
setblock 96 71 531 minecraft:smooth_basalt
setblock 96 71 532 minecraft:blackstone
fill 96 71 543 96 77 543 minecraft:smooth_basalt
setblock 96 71 546 minecraft:smooth_basalt
fill 96 71 547 96 73 547 minecraft:blackstone
setblock 96 71 551 minecraft:smooth_basalt
fill 97 71 511 97 74 511 minecraft:blackstone
fill 97 71 545 97 77 545 minecraft:smooth_basalt
setblock 97 71 550 minecraft:smooth_basalt
fill 97 71 551 100 71 551 minecraft:blackstone
setblock 98 71 549 minecraft:smooth_basalt
fill 98 71 550 101 71 550 minecraft:blackstone
fill 99 71 549 101 71 549 minecraft:blackstone
setblock 100 71 512 minecraft:smooth_basalt
setblock 101 71 511 minecraft:smooth_basalt
setblock 101 71 551 minecraft:smooth_basalt
fill 102 71 511 105 71 511 minecraft:blackstone
setblock 102 71 550 minecraft:smooth_basalt
fill 102 71 551 102 74 551 minecraft:blackstone
fill 103 71 550 106 71 550 minecraft:blackstone
fill 105 71 549 107 71 549 minecraft:blackstone
setblock 106 71 511 minecraft:smooth_basalt
setblock 106 71 551 minecraft:smooth_basalt
fill 107 71 511 110 71 511 minecraft:blackstone
setblock 107 71 550 minecraft:smooth_basalt
fill 107 71 551 107 74 551 minecraft:blackstone
setblock 108 71 549 minecraft:smooth_basalt
fill 108 71 550 108 74 550 minecraft:blackstone
setblock 109 71 548 minecraft:smooth_basalt
fill 109 71 549 109 74 549 minecraft:blackstone
fill 110 71 548 110 72 548 minecraft:blackstone
setblock 111 71 511 minecraft:smooth_basalt
fill 111 71 512 111 74 512 minecraft:blackstone
setblock 111 71 551 minecraft:smooth_basalt
fill 112 71 511 112 74 511 minecraft:blackstone
setblock 112 71 550 minecraft:smooth_basalt
fill 112 71 551 112 74 551 minecraft:blackstone
setblock 113 71 549 minecraft:smooth_basalt
fill 113 71 550 113 74 550 minecraft:blackstone
setblock 114 71 548 minecraft:smooth_basalt
fill 114 71 549 114 74 549 minecraft:blackstone
setblock 115 71 548 minecraft:blackstone
setblock 116 71 511 minecraft:smooth_basalt
schedule function dropper:buildpart/122_3 1t
