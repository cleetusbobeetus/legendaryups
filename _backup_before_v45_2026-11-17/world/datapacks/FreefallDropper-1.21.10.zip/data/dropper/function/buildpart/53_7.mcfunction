fill 274 245 245 274 246 245 minecraft:gray_concrete
fill 274 245 247 274 246 247 minecraft:gray_concrete
fill 274 245 249 274 246 249 minecraft:gray_concrete
fill 275 245 242 275 246 242 minecraft:gray_concrete
fill 275 245 244 275 246 244 minecraft:gray_concrete
fill 275 245 246 275 246 246 minecraft:gray_concrete
fill 275 245 248 275 246 248 minecraft:gray_concrete
fill 276 245 241 276 246 241 minecraft:gray_concrete
fill 276 245 243 276 246 243 minecraft:gray_concrete
fill 276 245 245 276 246 245 minecraft:gray_concrete
fill 276 245 247 276 246 247 minecraft:gray_concrete
fill 276 245 249 276 246 249 minecraft:gray_concrete
fill 277 245 231 277 308 231 minecraft:black_concrete
setblock 277 245 248 minecraft:sea_lantern
setblock 235 246 237 minecraft:sea_lantern
setblock 235 246 250 minecraft:verdant_froglight
setblock 235 246 267 minecraft:purple_concrete
setblock 235 246 268 minecraft:cyan_concrete
fill 236 246 243 236 247 243 minecraft:black_concrete
fill 236 246 245 236 247 245 minecraft:black_concrete
fill 236 246 247 236 247 247 minecraft:black_concrete
fill 236 246 249 236 247 249 minecraft:black_concrete
fill 236 246 251 236 247 251 minecraft:black_concrete
fill 236 246 253 236 247 253 minecraft:black_concrete
fill 237 246 242 237 247 242 minecraft:black_concrete
fill 237 246 255 237 247 255 minecraft:black_concrete
fill 239 246 242 239 247 242 minecraft:black_concrete
fill 239 246 255 239 247 255 minecraft:black_concrete
fill 240 246 228 240 307 228 minecraft:black_concrete
fill 241 246 243 241 247 243 minecraft:black_concrete
fill 241 246 245 241 247 245 minecraft:black_concrete
fill 241 246 247 241 247 247 minecraft:black_concrete
fill 241 246 249 241 247 249 minecraft:black_concrete
fill 241 246 251 241 247 251 minecraft:black_concrete
fill 241 246 253 241 247 253 minecraft:black_concrete
fill 249 246 265 249 247 265 minecraft:gray_concrete
fill 249 246 267 249 247 267 minecraft:gray_concrete
fill 250 246 264 250 247 264 minecraft:gray_concrete
fill 250 246 269 250 247 269 minecraft:gray_concrete
fill 252 246 264 252 247 264 minecraft:gray_concrete
fill 252 246 269 252 247 269 minecraft:gray_concrete
fill 254 246 264 254 247 264 minecraft:gray_concrete
fill 254 246 269 254 247 269 minecraft:gray_concrete
fill 256 246 264 256 247 264 minecraft:gray_concrete
fill 256 246 269 256 247 269 minecraft:gray_concrete
fill 258 246 264 258 247 264 minecraft:gray_concrete
fill 258 246 269 258 247 269 minecraft:gray_concrete
fill 260 246 264 260 247 264 minecraft:gray_concrete
fill 260 246 269 260 247 269 minecraft:gray_concrete
fill 262 246 265 262 247 265 minecraft:gray_concrete
fill 262 246 267 262 247 267 minecraft:gray_concrete
setblock 271 246 228 minecraft:blue_concrete
fill 277 246 248 277 256 248 minecraft:black_concrete
fill 235 247 237 235 283 237 minecraft:black_concrete
fill 235 247 250 235 260 250 minecraft:black_concrete
fill 235 247 267 235 256 268 minecraft:black_concrete
setblock 237 247 228 minecraft:magenta_concrete
setblock 238 247 231 minecraft:light[level=12]
setblock 238 247 238 minecraft:light[level=12]
setblock 238 247 259 minecraft:light[level=12]
setblock 238 247 266 minecraft:light[level=12]
setblock 238 247 270 minecraft:ochre_froglight
setblock 241 247 270 minecraft:blue_concrete
setblock 243 247 228 minecraft:verdant_froglight
setblock 245 247 231 minecraft:light[level=12]
setblock 245 247 238 minecraft:light[level=12]
setblock 245 247 245 minecraft:light[level=12]
setblock 245 247 252 minecraft:light[level=12]
setblock 245 247 259 minecraft:light[level=12]
setblock 245 247 266 minecraft:light[level=12]
setblock 252 247 231 minecraft:light[level=12]
setblock 252 247 238 minecraft:light[level=12]
setblock 252 247 245 minecraft:light[level=12]
setblock 252 247 252 minecraft:light[level=12]
setblock 252 247 259 minecraft:light[level=12]
setblock 259 247 231 minecraft:light[level=12]
setblock 259 247 238 minecraft:light[level=12]
setblock 259 247 245 minecraft:light[level=12]
setblock 259 247 252 minecraft:light[level=12]
setblock 259 247 259 minecraft:light[level=12]
fill 263 247 237 263 248 239 minecraft:cyan_stained_glass
fill 265 247 235 267 248 235 minecraft:cyan_stained_glass
fill 265 247 241 267 248 241 minecraft:cyan_stained_glass
setblock 266 247 231 minecraft:light[level=12]
setblock 266 247 238 minecraft:light[level=12]
setblock 266 247 245 minecraft:light[level=12]
setblock 266 247 252 minecraft:light[level=12]
setblock 266 247 259 minecraft:light[level=12]
setblock 266 247 266 minecraft:light[level=12]
setblock 268 247 241 minecraft:sea_lantern
setblock 268 247 243 minecraft:sea_lantern
setblock 268 247 245 minecraft:sea_lantern
setblock 268 247 247 minecraft:sea_lantern
setblock 268 247 249 minecraft:sea_lantern
fill 269 247 237 269 248 239 minecraft:cyan_stained_glass
setblock 269 247 242 minecraft:sea_lantern
setblock 269 247 244 minecraft:sea_lantern
setblock 269 247 246 minecraft:sea_lantern
setblock 269 247 248 minecraft:sea_lantern
setblock 270 247 241 minecraft:sea_lantern
setblock 270 247 243 minecraft:sea_lantern
setblock 270 247 245 minecraft:sea_lantern
setblock 270 247 247 minecraft:sea_lantern
setblock 270 247 249 minecraft:sea_lantern
fill 271 247 228 271 270 228 minecraft:black_concrete
setblock 271 247 242 minecraft:sea_lantern
setblock 271 247 244 minecraft:sea_lantern
setblock 271 247 246 minecraft:sea_lantern
setblock 271 247 248 minecraft:sea_lantern
setblock 272 247 241 minecraft:sea_lantern
setblock 272 247 243 minecraft:sea_lantern
setblock 272 247 245 minecraft:sea_lantern
setblock 272 247 247 minecraft:sea_lantern
setblock 272 247 249 minecraft:sea_lantern
setblock 273 247 231 minecraft:light[level=12]
setblock 273 247 238 minecraft:light[level=12]
setblock 273 247 242 minecraft:sea_lantern
setblock 273 247 244 minecraft:sea_lantern
setblock 273 247 246 minecraft:sea_lantern
setblock 273 247 248 minecraft:sea_lantern
setblock 273 247 252 minecraft:light[level=12]
setblock 273 247 259 minecraft:light[level=12]
setblock 273 247 266 minecraft:light[level=12]
setblock 274 247 241 minecraft:sea_lantern
setblock 274 247 243 minecraft:sea_lantern
setblock 274 247 245 minecraft:sea_lantern
setblock 274 247 247 minecraft:sea_lantern
setblock 274 247 249 minecraft:sea_lantern
setblock 275 247 242 minecraft:sea_lantern
setblock 275 247 244 minecraft:sea_lantern
setblock 275 247 246 minecraft:sea_lantern
setblock 275 247 248 minecraft:sea_lantern
setblock 276 247 241 minecraft:sea_lantern
setblock 276 247 243 minecraft:sea_lantern
setblock 276 247 245 minecraft:sea_lantern
setblock 276 247 247 minecraft:sea_lantern
setblock 276 247 249 minecraft:sea_lantern
setblock 277 247 243 minecraft:ochre_froglight
setblock 277 247 253 minecraft:verdant_froglight
setblock 235 248 245 minecraft:sea_lantern
setblock 236 248 243 minecraft:light_blue_stained_glass
setblock 236 248 245 minecraft:magenta_stained_glass
setblock 236 248 247 minecraft:ochre_froglight
setblock 236 248 249 minecraft:black_stained_glass
setblock 236 248 251 minecraft:pearlescent_froglight
setblock 236 248 253 minecraft:sea_lantern
fill 237 248 228 237 308 228 minecraft:black_concrete
setblock 237 248 242 minecraft:cyan_stained_glass
setblock 237 248 255 minecraft:sea_lantern
setblock 238 248 231 minecraft:light[level=15]
setblock 238 248 239 minecraft:light[level=15]
setblock 238 248 263 minecraft:light[level=15]
fill 238 248 265 239 249 269 minecraft:gray_concrete
fill 238 248 270 238 308 270 minecraft:black_concrete
setblock 239 248 242 minecraft:sea_lantern
setblock 239 248 255 minecraft:black_stained_glass
fill 239 248 256 239 249 264 minecraft:gray_concrete
fill 240 248 256 240 249 262 minecraft:gray_concrete
fill 241 248 237 242 249 241 minecraft:gray_concrete
setblock 241 248 243 minecraft:ochre_froglight
setblock 241 248 245 minecraft:pearlescent_froglight
setblock 241 248 247 minecraft:magenta_stained_glass
setblock 241 248 249 minecraft:black_stained_glass
setblock 241 248 251 minecraft:gray_concrete
setblock 241 248 253 minecraft:cyan_stained_glass
fill 241 248 270 241 288 270 minecraft:black_concrete
fill 242 248 229 242 249 236 minecraft:gray_concrete
fill 242 248 242 242 249 243 minecraft:gray_concrete
fill 243 248 228 243 270 228 minecraft:black_concrete
fill 243 248 229 243 249 234 minecraft:gray_concrete
setblock 246 248 231 minecraft:light[level=15]
setblock 246 248 239 minecraft:light[level=15]
setblock 246 248 247 minecraft:light[level=15]
setblock 246 248 255 minecraft:light[level=15]
setblock 246 248 263 minecraft:light[level=15]
setblock 249 248 265 minecraft:sea_lantern
setblock 249 248 267 minecraft:ochre_froglight
setblock 250 248 264 minecraft:cyan_stained_glass
setblock 250 248 269 minecraft:cyan_stained_glass
setblock 252 248 264 minecraft:magenta_stained_glass
setblock 252 248 269 minecraft:sea_lantern
setblock 254 248 231 minecraft:light[level=15]
setblock 254 248 239 minecraft:light[level=15]
setblock 254 248 247 minecraft:light[level=15]
setblock 254 248 255 minecraft:light[level=15]
setblock 254 248 263 minecraft:light[level=15]
setblock 254 248 264 minecraft:ochre_froglight
setblock 254 248 269 minecraft:ochre_froglight
setblock 256 248 264 minecraft:magenta_stained_glass
setblock 256 248 269 minecraft:black_stained_glass
setblock 258 248 264 minecraft:light_blue_stained_glass
setblock 258 248 269 minecraft:light_blue_stained_glass
setblock 260 248 264 minecraft:cyan_stained_glass
setblock 260 248 269 minecraft:ochre_froglight
setblock 262 248 231 minecraft:light[level=15]
setblock 262 248 239 minecraft:light[level=15]
setblock 262 248 247 minecraft:light[level=15]
setblock 262 248 255 minecraft:light[level=15]
setblock 262 248 263 minecraft:light[level=15]
setblock 262 248 265 minecraft:black_stained_glass
setblock 262 248 267 minecraft:magenta_stained_glass
fill 264 248 236 264 248 237 minecraft:cyan_stained_glass
fill 264 248 239 264 248 240 minecraft:cyan_stained_glass
fill 265 248 236 265 249 236 minecraft:cyan_stained_glass
fill 265 248 240 265 249 240 minecraft:cyan_stained_glass
fill 267 248 236 268 248 236 minecraft:cyan_stained_glass
fill 267 248 240 268 248 240 minecraft:cyan_stained_glass
fill 268 248 237 268 249 237 minecraft:cyan_stained_glass
fill 268 248 239 268 249 239 minecraft:cyan_stained_glass
fill 268 248 241 268 249 241 minecraft:gray_concrete
fill 268 248 243 268 249 243 minecraft:gray_concrete
fill 268 248 245 268 249 245 minecraft:gray_concrete
fill 268 248 247 268 249 247 minecraft:gray_concrete
fill 268 248 249 268 249 249 minecraft:gray_concrete
fill 269 248 242 269 249 242 minecraft:gray_concrete
fill 269 248 244 269 249 244 minecraft:gray_concrete
fill 269 248 246 269 249 246 minecraft:gray_concrete
fill 269 248 248 269 249 248 minecraft:gray_concrete
setblock 270 248 231 minecraft:light[level=15]
setblock 270 248 239 minecraft:light[level=15]
fill 270 248 241 270 249 241 minecraft:gray_concrete
fill 270 248 243 270 249 243 minecraft:gray_concrete
fill 270 248 245 270 249 245 minecraft:gray_concrete
fill 270 248 247 270 249 247 minecraft:gray_concrete
fill 270 248 249 270 249 249 minecraft:gray_concrete
setblock 270 248 255 minecraft:light[level=15]
setblock 270 248 263 minecraft:light[level=15]
fill 271 248 242 271 249 242 minecraft:gray_concrete
fill 271 248 244 271 249 244 minecraft:gray_concrete
fill 271 248 246 271 249 246 minecraft:gray_concrete
fill 271 248 248 271 249 248 minecraft:gray_concrete
fill 272 248 241 272 249 241 minecraft:gray_concrete
fill 272 248 243 272 249 243 minecraft:gray_concrete
fill 272 248 245 272 249 245 minecraft:gray_concrete
fill 272 248 247 272 249 247 minecraft:gray_concrete
fill 272 248 249 272 249 249 minecraft:gray_concrete
fill 273 248 242 273 249 242 minecraft:gray_concrete
fill 273 248 244 273 249 244 minecraft:gray_concrete
fill 273 248 246 273 249 246 minecraft:gray_concrete
fill 273 248 248 273 249 248 minecraft:gray_concrete
fill 274 248 241 274 249 241 minecraft:gray_concrete
fill 274 248 243 274 249 243 minecraft:gray_concrete
fill 274 248 245 274 249 245 minecraft:gray_concrete
fill 274 248 247 274 249 247 minecraft:gray_concrete
fill 274 248 249 274 249 249 minecraft:gray_concrete
fill 275 248 242 275 249 242 minecraft:gray_concrete
fill 275 248 244 275 249 244 minecraft:gray_concrete
fill 275 248 246 275 249 246 minecraft:gray_concrete
fill 275 248 248 275 249 248 minecraft:gray_concrete
fill 276 248 241 276 249 241 minecraft:gray_concrete
fill 276 248 243 276 249 243 minecraft:gray_concrete
fill 276 248 245 276 249 245 minecraft:gray_concrete
fill 276 248 247 276 249 247 minecraft:gray_concrete
fill 276 248 249 276 249 249 minecraft:gray_concrete
fill 277 248 243 277 259 243 minecraft:black_concrete
fill 277 248 253 277 278 253 minecraft:black_concrete
fill 235 249 245 236 250 245 minecraft:black_concrete
fill 236 249 243 236 250 243 minecraft:black_concrete
fill 236 249 247 236 250 247 minecraft:black_concrete
fill 236 249 249 236 250 249 minecraft:black_concrete
fill 236 249 251 236 250 251 minecraft:black_concrete
fill 236 249 253 236 250 253 minecraft:black_concrete
fill 237 249 242 237 250 242 minecraft:black_concrete
fill 237 249 255 237 250 255 minecraft:black_concrete
fill 239 249 242 239 250 242 minecraft:black_concrete
fill 239 249 255 239 250 255 minecraft:black_concrete
fill 241 249 243 241 250 243 minecraft:black_concrete
fill 241 249 245 241 250 245 minecraft:black_concrete
fill 241 249 247 241 250 247 minecraft:black_concrete
fill 241 249 249 241 250 249 minecraft:black_concrete
fill 241 249 251 241 250 251 minecraft:black_concrete
fill 241 249 253 241 250 253 minecraft:black_concrete
setblock 247 249 228 minecraft:cyan_concrete
fill 249 249 265 249 250 265 minecraft:gray_concrete
fill 249 249 267 249 250 267 minecraft:gray_concrete
fill 250 249 264 250 250 264 minecraft:gray_concrete
fill 250 249 269 250 250 269 minecraft:gray_concrete
fill 252 249 264 252 250 264 minecraft:gray_concrete
fill 252 249 269 252 250 269 minecraft:gray_concrete
fill 254 249 264 254 250 264 minecraft:gray_concrete
fill 254 249 269 254 250 269 minecraft:gray_concrete
fill 256 249 264 256 250 264 minecraft:gray_concrete
fill 256 249 269 256 250 269 minecraft:gray_concrete
fill 258 249 264 258 250 264 minecraft:gray_concrete
fill 258 249 269 258 250 269 minecraft:gray_concrete
fill 260 249 264 260 250 264 minecraft:gray_concrete
fill 260 249 269 260 250 269 minecraft:gray_concrete
fill 262 249 265 262 250 265 minecraft:gray_concrete
fill 262 249 267 262 250 267 minecraft:gray_concrete
fill 264 249 237 267 249 239 minecraft:cyan_stained_glass
fill 266 249 236 267 249 236 minecraft:cyan_stained_glass
fill 266 249 240 267 249 240 minecraft:cyan_stained_glass
setblock 268 249 238 minecraft:cyan_stained_glass
fill 238 250 268 239 250 268 minecraft:magenta_concrete
fill 239 250 259 239 250 267 minecraft:magenta_concrete
fill 240 250 256 240 250 259 minecraft:magenta_concrete
fill 241 250 240 241 250 241 minecraft:magenta_concrete
fill 242 250 231 242 250 240 minecraft:magenta_concrete
fill 243 250 229 243 250 231 minecraft:magenta_concrete
fill 247 250 228 247 276 228 minecraft:black_concrete
setblock 265 250 270 minecraft:cyan_concrete
setblock 268 250 241 minecraft:sea_lantern
setblock 268 250 243 minecraft:sea_lantern
setblock 268 250 245 minecraft:sea_lantern
setblock 268 250 247 minecraft:sea_lantern
setblock 268 250 249 minecraft:sea_lantern
setblock 269 250 242 minecraft:sea_lantern
setblock 269 250 244 minecraft:sea_lantern
setblock 269 250 246 minecraft:sea_lantern
setblock 269 250 248 minecraft:sea_lantern
setblock 270 250 241 minecraft:sea_lantern
setblock 270 250 243 minecraft:sea_lantern
setblock 270 250 245 minecraft:sea_lantern
setblock 270 250 247 minecraft:sea_lantern
setblock 270 250 249 minecraft:sea_lantern
setblock 271 250 242 minecraft:sea_lantern
setblock 271 250 244 minecraft:sea_lantern
setblock 271 250 246 minecraft:sea_lantern
setblock 271 250 248 minecraft:sea_lantern
setblock 272 250 241 minecraft:sea_lantern
setblock 272 250 243 minecraft:sea_lantern
setblock 272 250 245 minecraft:sea_lantern
setblock 272 250 247 minecraft:sea_lantern
setblock 272 250 249 minecraft:sea_lantern
setblock 273 250 242 minecraft:sea_lantern
setblock 273 250 244 minecraft:sea_lantern
setblock 273 250 246 minecraft:sea_lantern
setblock 273 250 248 minecraft:sea_lantern
setblock 274 250 241 minecraft:sea_lantern
setblock 274 250 243 minecraft:sea_lantern
setblock 274 250 245 minecraft:sea_lantern
setblock 274 250 247 minecraft:sea_lantern
setblock 274 250 249 minecraft:sea_lantern
setblock 275 250 242 minecraft:sea_lantern
setblock 275 250 244 minecraft:sea_lantern
setblock 275 250 246 minecraft:sea_lantern
setblock 275 250 248 minecraft:sea_lantern
setblock 276 250 241 minecraft:sea_lantern
setblock 276 250 243 minecraft:sea_lantern
setblock 276 250 245 minecraft:sea_lantern
setblock 276 250 247 minecraft:sea_lantern
setblock 276 250 249 minecraft:sea_lantern
setblock 277 250 250 minecraft:sea_lantern
setblock 277 250 261 minecraft:blue_concrete
setblock 235 251 232 minecraft:cyan_concrete
fill 235 251 245 235 308 245 minecraft:black_concrete
setblock 235 251 259 minecraft:blue_concrete
setblock 236 251 243 minecraft:magenta_stained_glass
setblock 236 251 245 minecraft:cyan_stained_glass
setblock 236 251 247 minecraft:black_stained_glass
setblock 236 251 249 minecraft:light_blue_stained_glass
setblock 236 251 251 minecraft:black_stained_glass
setblock 236 251 253 minecraft:ochre_froglight
setblock 237 251 242 minecraft:black_stained_glass
setblock 237 251 255 minecraft:pearlescent_froglight
setblock 239 251 242 minecraft:magenta_stained_glass
setblock 239 251 255 minecraft:pearlescent_froglight
setblock 241 251 243 minecraft:black_stained_glass
setblock 241 251 245 minecraft:sea_lantern
setblock 241 251 247 minecraft:pearlescent_froglight
setblock 241 251 249 minecraft:light_blue_stained_glass
setblock 241 251 251 minecraft:black_stained_glass
setblock 241 251 253 minecraft:black_stained_glass
setblock 249 251 265 minecraft:magenta_stained_glass
setblock 249 251 267 minecraft:black_stained_glass
setblock 250 251 264 minecraft:cyan_stained_glass
setblock 250 251 269 minecraft:black_stained_glass
setblock 251 251 228 minecraft:verdant_froglight
setblock 252 251 264 minecraft:black_stained_glass
setblock 252 251 269 minecraft:sea_lantern
setblock 254 251 264 minecraft:pearlescent_froglight
setblock 254 251 269 minecraft:ochre_froglight
setblock 256 251 264 minecraft:cyan_stained_glass
setblock 256 251 269 minecraft:black_stained_glass
setblock 258 251 264 minecraft:black_stained_glass
setblock 258 251 269 minecraft:black_stained_glass
setblock 260 251 264 minecraft:cyan_stained_glass
setblock 260 251 269 minecraft:black_stained_glass
setblock 262 251 265 minecraft:light_blue_stained_glass
setblock 262 251 267 minecraft:sea_lantern
setblock 264 251 228 minecraft:magenta_concrete
fill 265 251 270 265 308 270 minecraft:black_concrete
fill 268 251 241 268 253 241 minecraft:gray_concrete
fill 268 251 243 268 253 243 minecraft:gray_concrete
fill 268 251 245 268 253 245 minecraft:gray_concrete
fill 268 251 247 268 253 247 minecraft:gray_concrete
fill 268 251 249 268 253 249 minecraft:gray_concrete
setblock 268 251 270 minecraft:verdant_froglight
fill 269 251 242 269 253 242 minecraft:gray_concrete
fill 269 251 244 269 253 244 minecraft:gray_concrete
fill 269 251 246 269 253 246 minecraft:gray_concrete
fill 269 251 248 269 253 248 minecraft:gray_concrete
fill 270 251 241 270 253 241 minecraft:gray_concrete
fill 270 251 243 270 253 243 minecraft:gray_concrete
fill 270 251 245 270 253 245 minecraft:gray_concrete
fill 270 251 247 270 253 247 minecraft:gray_concrete
fill 270 251 249 270 253 249 minecraft:gray_concrete
fill 271 251 242 271 253 242 minecraft:gray_concrete
fill 271 251 244 271 253 244 minecraft:gray_concrete
fill 271 251 246 271 253 246 minecraft:gray_concrete
fill 271 251 248 271 253 248 minecraft:gray_concrete
fill 272 251 241 272 253 241 minecraft:gray_concrete
fill 272 251 243 272 253 243 minecraft:gray_concrete
fill 272 251 245 272 253 245 minecraft:gray_concrete
fill 272 251 247 272 253 247 minecraft:gray_concrete
fill 272 251 249 272 253 249 minecraft:gray_concrete
fill 273 251 242 273 253 242 minecraft:gray_concrete
fill 273 251 244 273 253 244 minecraft:gray_concrete
fill 273 251 246 273 253 246 minecraft:gray_concrete
fill 273 251 248 273 253 248 minecraft:gray_concrete
fill 274 251 241 274 253 241 minecraft:gray_concrete
fill 274 251 243 274 253 243 minecraft:gray_concrete
fill 274 251 245 274 253 245 minecraft:gray_concrete
fill 274 251 247 274 253 247 minecraft:gray_concrete
fill 274 251 249 274 253 249 minecraft:gray_concrete
fill 275 251 242 275 253 242 minecraft:gray_concrete
fill 275 251 244 275 253 244 minecraft:gray_concrete
fill 275 251 246 275 253 246 minecraft:gray_concrete
fill 275 251 248 275 253 248 minecraft:gray_concrete
fill 276 251 241 276 253 241 minecraft:gray_concrete
fill 276 251 243 276 253 243 minecraft:gray_concrete
fill 276 251 245 276 253 245 minecraft:gray_concrete
fill 276 251 247 276 253 247 minecraft:gray_concrete
fill 276 251 249 276 253 249 minecraft:gray_concrete
fill 277 251 250 277 266 250 minecraft:black_concrete
fill 277 251 261 277 308 261 minecraft:black_concrete
fill 235 252 232 235 289 232 minecraft:black_concrete
setblock 235 252 246 minecraft:purple_concrete
fill 235 252 259 235 254 259 minecraft:black_concrete
fill 236 252 243 236 253 243 minecraft:black_concrete
fill 236 252 245 236 253 245 minecraft:black_concrete
fill 236 252 247 236 253 247 minecraft:black_concrete
fill 236 252 249 236 253 249 minecraft:black_concrete
fill 236 252 251 236 253 251 minecraft:black_concrete
fill 236 252 253 236 253 253 minecraft:black_concrete
fill 237 252 242 237 253 242 minecraft:black_concrete
fill 237 252 255 237 253 255 minecraft:black_concrete
fill 239 252 242 239 253 242 minecraft:black_concrete
fill 239 252 255 239 253 255 minecraft:black_concrete
fill 241 252 243 241 253 243 minecraft:black_concrete
fill 241 252 245 241 253 245 minecraft:black_concrete
fill 241 252 247 241 253 247 minecraft:black_concrete
fill 241 252 249 241 253 249 minecraft:black_concrete
fill 241 252 251 241 253 251 minecraft:black_concrete
fill 241 252 253 241 253 253 minecraft:black_concrete
fill 249 252 265 249 253 265 minecraft:gray_concrete
fill 249 252 267 249 253 267 minecraft:gray_concrete
fill 250 252 264 250 253 264 minecraft:gray_concrete
fill 250 252 269 250 253 269 minecraft:gray_concrete
fill 251 252 228 251 308 228 minecraft:black_concrete
fill 252 252 264 252 253 264 minecraft:gray_concrete
fill 252 252 269 252 253 269 minecraft:gray_concrete
fill 254 252 264 254 253 264 minecraft:gray_concrete
fill 254 252 269 254 253 269 minecraft:gray_concrete
fill 256 252 264 256 253 264 minecraft:gray_concrete
fill 256 252 269 256 253 269 minecraft:gray_concrete
setblock 257 252 270 minecraft:ochre_froglight
fill 258 252 264 258 253 264 minecraft:gray_concrete
fill 258 252 269 258 253 269 minecraft:gray_concrete
setblock 259 252 270 minecraft:sea_lantern
fill 260 252 264 260 253 264 minecraft:gray_concrete
fill 260 252 269 260 253 269 minecraft:gray_concrete
fill 262 252 265 262 253 265 minecraft:gray_concrete
fill 262 252 267 262 253 267 minecraft:gray_concrete
fill 264 252 228 264 257 228 minecraft:black_concrete
fill 268 252 270 268 257 270 minecraft:black_concrete
setblock 277 252 229 minecraft:purple_concrete
fill 235 253 246 235 274 246 minecraft:black_concrete
setblock 238 253 231 minecraft:light[level=12]
setblock 238 253 238 minecraft:light[level=12]
setblock 238 253 259 minecraft:light[level=12]
setblock 238 253 266 minecraft:light[level=12]
setblock 245 253 231 minecraft:light[level=12]
setblock 245 253 238 minecraft:light[level=12]
setblock 245 253 245 minecraft:light[level=12]
setblock 245 253 252 minecraft:light[level=12]
setblock 245 253 259 minecraft:light[level=12]
setblock 245 253 266 minecraft:light[level=12]
setblock 252 253 231 minecraft:light[level=12]
setblock 252 253 238 minecraft:light[level=12]
setblock 252 253 245 minecraft:light[level=12]
setblock 252 253 252 minecraft:light[level=12]
setblock 252 253 259 minecraft:light[level=12]
setblock 257 253 228 minecraft:blue_concrete
fill 257 253 270 257 265 270 minecraft:black_concrete
setblock 259 253 231 minecraft:light[level=12]
setblock 259 253 238 minecraft:light[level=12]
setblock 259 253 245 minecraft:light[level=12]
setblock 259 253 252 minecraft:light[level=12]
setblock 259 253 259 minecraft:light[level=12]
fill 259 253 270 259 266 270 minecraft:black_concrete
setblock 266 253 231 minecraft:light[level=12]
setblock 266 253 238 minecraft:light[level=12]
setblock 266 253 245 minecraft:light[level=12]
setblock 266 253 252 minecraft:light[level=12]
setblock 266 253 259 minecraft:light[level=12]
setblock 266 253 266 minecraft:light[level=12]
setblock 273 253 231 minecraft:light[level=12]
setblock 273 253 238 minecraft:light[level=12]
setblock 273 253 252 minecraft:light[level=12]
setblock 273 253 259 minecraft:light[level=12]
setblock 273 253 266 minecraft:light[level=12]
fill 277 253 229 277 308 229 minecraft:black_concrete
setblock 236 254 243 minecraft:black_stained_glass
setblock 236 254 245 minecraft:light_blue_stained_glass
setblock 236 254 247 minecraft:ochre_froglight
setblock 236 254 249 minecraft:black_stained_glass
setblock 236 254 251 minecraft:black_stained_glass
setblock 236 254 253 minecraft:black_stained_glass
setblock 237 254 242 minecraft:sea_lantern
setblock 237 254 255 minecraft:black_stained_glass
setblock 239 254 242 minecraft:ochre_froglight
setblock 239 254 255 minecraft:ochre_froglight
setblock 241 254 243 minecraft:black_stained_glass
setblock 241 254 245 minecraft:magenta_stained_glass
setblock 241 254 247 minecraft:black_stained_glass
setblock 241 254 249 minecraft:black_stained_glass
setblock 241 254 251 minecraft:black_stained_glass
setblock 241 254 253 minecraft:light_blue_stained_glass
setblock 249 254 265 minecraft:black_stained_glass
setblock 249 254 267 minecraft:ochre_froglight
setblock 250 254 264 minecraft:light_blue_stained_glass
setblock 250 254 269 minecraft:ochre_froglight
setblock 252 254 264 minecraft:cyan_stained_glass
setblock 252 254 269 minecraft:pearlescent_froglight
setblock 254 254 264 minecraft:light_blue_stained_glass
setblock 254 254 269 minecraft:black_stained_glass
setblock 255 254 270 minecraft:sea_lantern
setblock 256 254 264 minecraft:black_stained_glass
setblock 256 254 269 minecraft:black_stained_glass
fill 257 254 228 257 256 228 minecraft:black_concrete
setblock 258 254 264 minecraft:cyan_stained_glass
setblock 258 254 269 minecraft:black_stained_glass
setblock 260 254 264 minecraft:black_stained_glass
setblock 260 254 269 minecraft:sea_lantern
setblock 262 254 228 minecraft:magenta_concrete
setblock 262 254 265 minecraft:ochre_froglight
setblock 262 254 267 minecraft:light_blue_stained_glass
setblock 235 255 259 minecraft:magenta_concrete
fill 236 255 243 236 256 243 minecraft:black_concrete
fill 236 255 245 236 256 245 minecraft:black_concrete
fill 236 255 247 236 256 247 minecraft:black_concrete
fill 236 255 249 236 256 249 minecraft:black_concrete
fill 236 255 251 236 256 251 minecraft:black_concrete
fill 236 255 253 236 256 253 minecraft:black_concrete
fill 237 255 242 237 256 242 minecraft:black_concrete
fill 237 255 255 237 256 255 minecraft:black_concrete
setblock 238 255 231 minecraft:light[level=15]
setblock 238 255 239 minecraft:light[level=15]
setblock 238 255 263 minecraft:light[level=15]
fill 239 255 242 239 256 242 minecraft:black_concrete
fill 239 255 255 239 256 255 minecraft:black_concrete
fill 241 255 243 241 256 243 minecraft:black_concrete
fill 241 255 245 241 256 245 minecraft:black_concrete
fill 241 255 247 241 256 247 minecraft:black_concrete
fill 241 255 249 241 256 249 minecraft:black_concrete
fill 241 255 251 241 256 251 minecraft:black_concrete
fill 241 255 253 241 256 253 minecraft:black_concrete
setblock 246 255 231 minecraft:light[level=15]
setblock 246 255 239 minecraft:light[level=15]
setblock 246 255 247 minecraft:light[level=15]
setblock 246 255 255 minecraft:light[level=15]
setblock 246 255 263 minecraft:light[level=15]
fill 249 255 265 249 256 265 minecraft:gray_concrete
fill 249 255 267 249 256 267 minecraft:gray_concrete
fill 250 255 264 250 256 264 minecraft:gray_concrete
fill 250 255 269 250 256 269 minecraft:gray_concrete
fill 252 255 264 252 256 264 minecraft:gray_concrete
fill 252 255 269 252 256 269 minecraft:gray_concrete
setblock 254 255 231 minecraft:light[level=15]
setblock 254 255 239 minecraft:light[level=15]
setblock 254 255 247 minecraft:light[level=15]
setblock 254 255 255 minecraft:light[level=15]
setblock 254 255 263 minecraft:light[level=15]
fill 254 255 264 254 256 264 minecraft:gray_concrete
fill 254 255 269 254 256 269 minecraft:gray_concrete
fill 255 255 270 255 308 270 minecraft:black_concrete
fill 256 255 264 256 256 264 minecraft:gray_concrete
fill 256 255 269 256 256 269 minecraft:gray_concrete
fill 258 255 264 258 256 264 minecraft:gray_concrete
fill 258 255 269 258 256 269 minecraft:gray_concrete
fill 260 255 264 260 256 264 minecraft:gray_concrete
fill 260 255 269 260 256 269 minecraft:gray_concrete
fill 262 255 228 262 296 228 minecraft:black_concrete
setblock 262 255 231 minecraft:light[level=15]
setblock 262 255 239 minecraft:light[level=15]
setblock 262 255 247 minecraft:light[level=15]
setblock 262 255 255 minecraft:light[level=15]
setblock 262 255 263 minecraft:light[level=15]
fill 262 255 265 262 256 265 minecraft:gray_concrete
fill 262 255 267 262 256 267 minecraft:gray_concrete
setblock 270 255 231 minecraft:light[level=15]
setblock 270 255 239 minecraft:light[level=15]
setblock 270 255 247 minecraft:light[level=15]
setblock 270 255 255 minecraft:light[level=15]
setblock 270 255 263 minecraft:light[level=15]
setblock 277 255 247 minecraft:blue_concrete
setblock 277 255 265 minecraft:pearlescent_froglight
fill 235 256 259 235 308 259 minecraft:black_concrete
setblock 269 256 270 minecraft:pearlescent_froglight
setblock 277 256 245 minecraft:purple_concrete
fill 277 256 247 277 305 247 minecraft:black_concrete
fill 277 256 265 277 273 265 minecraft:black_concrete
fill 235 257 267 235 288 267 minecraft:black_concrete
setblock 235 257 268 minecraft:purple_concrete
setblock 236 257 243 minecraft:black_stained_glass
setblock 236 257 245 minecraft:black_stained_glass
setblock 236 257 247 minecraft:light_blue_stained_glass
setblock 236 257 249 minecraft:pearlescent_froglight
setblock 236 257 251 minecraft:sea_lantern
setblock 236 257 253 minecraft:light_blue_stained_glass
setblock 237 257 242 minecraft:black_stained_glass
setblock 237 257 255 minecraft:black_stained_glass
setblock 239 257 242 minecraft:black_stained_glass
setblock 239 257 255 minecraft:sea_lantern
setblock 241 257 243 minecraft:black_stained_glass
setblock 241 257 245 minecraft:black_stained_glass
setblock 241 257 247 minecraft:sea_lantern
setblock 241 257 249 minecraft:black_stained_glass
setblock 241 257 251 minecraft:magenta_stained_glass
setblock 241 257 253 minecraft:ochre_froglight
setblock 249 257 265 minecraft:black_stained_glass
setblock 249 257 267 minecraft:pearlescent_froglight
setblock 250 257 264 minecraft:pearlescent_froglight
setblock 250 257 269 minecraft:magenta_stained_glass
setblock 252 257 264 minecraft:black_stained_glass
setblock 252 257 269 minecraft:sea_lantern
setblock 254 257 228 minecraft:magenta_concrete
setblock 254 257 264 minecraft:ochre_froglight
setblock 254 257 269 minecraft:ochre_froglight
setblock 256 257 264 minecraft:pearlescent_froglight
setblock 256 257 269 minecraft:black_stained_glass
setblock 257 257 228 minecraft:magenta_concrete
setblock 258 257 264 minecraft:magenta_stained_glass
setblock 258 257 269 minecraft:ochre_froglight
setblock 260 257 264 minecraft:black_stained_glass
setblock 260 257 269 minecraft:black_stained_glass
setblock 262 257 265 minecraft:sea_lantern
setblock 262 257 267 minecraft:pearlescent_froglight
setblock 267 257 270 minecraft:cyan_concrete
fill 269 257 270 269 270 270 minecraft:black_concrete
fill 277 257 245 277 308 245 minecraft:black_concrete
setblock 277 257 248 minecraft:blue_concrete
fill 235 258 268 235 307 268 minecraft:black_concrete
fill 236 258 243 236 259 243 minecraft:black_concrete
fill 236 258 245 236 259 245 minecraft:black_concrete
fill 236 258 247 236 259 247 minecraft:black_concrete
fill 236 258 249 236 259 249 minecraft:black_concrete
fill 236 258 251 236 259 251 minecraft:black_concrete
fill 236 258 253 236 259 253 minecraft:black_concrete
fill 237 258 242 237 259 242 minecraft:black_concrete
fill 237 258 255 237 259 255 minecraft:black_concrete
fill 239 258 242 239 259 242 minecraft:black_concrete
fill 239 258 255 239 259 255 minecraft:black_concrete
fill 241 258 243 241 259 243 minecraft:black_concrete
fill 241 258 245 241 259 245 minecraft:black_concrete
fill 241 258 247 241 259 247 minecraft:black_concrete
fill 241 258 249 241 259 249 minecraft:black_concrete
fill 241 258 251 241 259 251 minecraft:black_concrete
fill 241 258 253 241 259 253 minecraft:black_concrete
fill 249 258 265 249 259 265 minecraft:gray_concrete
fill 249 258 267 249 259 267 minecraft:gray_concrete
fill 250 258 264 250 259 264 minecraft:gray_concrete
fill 250 258 269 250 259 269 minecraft:gray_concrete
fill 252 258 264 252 259 264 minecraft:gray_concrete
fill 252 258 269 252 259 269 minecraft:gray_concrete
fill 254 258 228 254 308 228 minecraft:black_concrete
fill 254 258 264 254 259 264 minecraft:gray_concrete
fill 254 258 269 254 259 269 minecraft:gray_concrete
fill 256 258 264 256 259 264 minecraft:gray_concrete
fill 256 258 269 256 259 269 minecraft:gray_concrete
fill 257 258 228 257 308 228 minecraft:black_concrete
fill 258 258 264 258 259 264 minecraft:gray_concrete
fill 258 258 269 258 259 269 minecraft:gray_concrete
fill 260 258 264 260 259 264 minecraft:gray_concrete
fill 260 258 269 260 259 269 minecraft:gray_concrete
fill 262 258 265 262 259 265 minecraft:gray_concrete
fill 262 258 267 262 259 267 minecraft:gray_concrete
setblock 264 258 228 minecraft:magenta_concrete
fill 267 258 270 267 273 270 minecraft:black_concrete
setblock 268 258 270 minecraft:magenta_concrete
fill 277 258 248 277 308 248 minecraft:black_concrete
setblock 238 259 231 minecraft:light[level=12]
setblock 238 259 238 minecraft:light[level=12]
setblock 238 259 259 minecraft:light[level=12]
setblock 238 259 266 minecraft:light[level=12]
fill 243 259 258 247 259 260 minecraft:cyan_stained_glass
fill 244 259 257 246 259 257 minecraft:cyan_stained_glass
fill 244 259 261 246 259 261 minecraft:cyan_stained_glass
setblock 245 259 231 minecraft:light[level=12]
setblock 245 259 238 minecraft:light[level=12]
setblock 245 259 245 minecraft:light[level=12]
setblock 245 259 252 minecraft:light[level=12]
setblock 245 259 266 minecraft:light[level=12]
setblock 249 259 263 minecraft:sea_lantern
setblock 252 259 231 minecraft:light[level=12]
setblock 252 259 238 minecraft:light[level=12]
setblock 252 259 245 minecraft:light[level=12]
setblock 252 259 252 minecraft:light[level=12]
setblock 252 259 259 minecraft:light[level=12]
setblock 259 259 231 minecraft:light[level=12]
setblock 259 259 238 minecraft:light[level=12]
setblock 259 259 245 minecraft:light[level=12]
setblock 259 259 252 minecraft:light[level=12]
setblock 259 259 259 minecraft:light[level=12]
fill 264 259 228 264 299 228 minecraft:black_concrete
setblock 266 259 231 minecraft:light[level=12]
setblock 266 259 238 minecraft:light[level=12]
setblock 266 259 245 minecraft:light[level=12]
setblock 266 259 252 minecraft:light[level=12]
setblock 266 259 259 minecraft:light[level=12]
setblock 266 259 266 minecraft:light[level=12]
fill 268 259 270 268 308 270 minecraft:black_concrete
setblock 273 259 231 minecraft:light[level=12]
setblock 273 259 238 minecraft:light[level=12]
setblock 273 259 245 minecraft:light[level=12]
setblock 273 259 252 minecraft:light[level=12]
setblock 273 259 259 minecraft:light[level=12]
setblock 273 259 266 minecraft:light[level=12]
setblock 277 259 233 minecraft:purple_concrete
setblock 236 260 243 minecraft:light_blue_stained_glass
setblock 236 260 245 minecraft:light_blue_stained_glass
setblock 236 260 247 minecraft:black_stained_glass
setblock 236 260 249 minecraft:cyan_stained_glass
setblock 236 260 251 minecraft:magenta_stained_glass
setblock 236 260 253 minecraft:ochre_froglight
setblock 237 260 242 minecraft:magenta_stained_glass
setblock 237 260 255 minecraft:magenta_stained_glass
setblock 239 260 242 minecraft:cyan_stained_glass
setblock 239 260 255 minecraft:black_stained_glass
setblock 241 260 243 minecraft:cyan_stained_glass
setblock 241 260 245 minecraft:black_stained_glass
setblock 241 260 247 minecraft:black_stained_glass
setblock 241 260 249 minecraft:black_stained_glass
setblock 241 260 251 minecraft:black_stained_glass
setblock 241 260 253 minecraft:ochre_froglight
fill 242 260 258 242 261 260 minecraft:cyan_stained_glass
fill 243 260 257 243 260 258 minecraft:cyan_stained_glass
fill 243 260 260 243 260 261 minecraft:cyan_stained_glass
setblock 243 260 270 minecraft:magenta_concrete
fill 244 260 256 244 260 257 minecraft:cyan_stained_glass
fill 244 260 261 244 260 262 minecraft:cyan_stained_glass
setblock 245 260 228 minecraft:magenta_concrete
fill 245 260 256 246 261 256 minecraft:cyan_stained_glass
fill 245 260 262 246 261 262 minecraft:cyan_stained_glass
fill 246 260 257 247 260 257 minecraft:cyan_stained_glass
fill 246 260 261 247 260 261 minecraft:cyan_stained_glass
fill 247 260 258 248 260 258 minecraft:cyan_stained_glass
fill 247 260 260 248 260 260 minecraft:cyan_stained_glass
fill 247 260 263 251 260 263 minecraft:white_concrete
fill 248 260 259 248 261 259 minecraft:cyan_stained_glass
fill 248 260 262 250 260 262 minecraft:white_concrete
fill 248 260 264 250 260 264 minecraft:white_concrete
setblock 249 260 265 minecraft:ochre_froglight
setblock 249 260 267 minecraft:sea_lantern
setblock 250 260 269 minecraft:sea_lantern
setblock 252 260 264 minecraft:pearlescent_froglight
setblock 252 260 269 minecraft:sea_lantern
setblock 254 260 264 minecraft:cyan_stained_glass
setblock 254 260 269 minecraft:black_stained_glass
setblock 256 260 264 minecraft:light_blue_stained_glass
setblock 256 260 269 minecraft:black_stained_glass
setblock 258 260 264 minecraft:black_stained_glass
setblock 258 260 269 minecraft:magenta_stained_glass
setblock 260 260 264 minecraft:cyan_stained_glass
setblock 260 260 269 minecraft:pearlescent_froglight
setblock 262 260 265 minecraft:ochre_froglight
setblock 262 260 267 minecraft:sea_lantern
fill 277 260 233 277 308 233 minecraft:black_concrete
setblock 277 260 243 minecraft:purple_concrete
setblock 235 261 250 minecraft:blue_concrete
fill 236 261 243 236 262 243 minecraft:black_concrete
fill 236 261 245 236 262 245 minecraft:black_concrete
fill 236 261 247 236 262 247 minecraft:black_concrete
fill 236 261 249 236 262 249 minecraft:black_concrete
fill 236 261 251 236 262 251 minecraft:black_concrete
fill 236 261 253 236 262 253 minecraft:black_concrete
fill 237 261 242 237 262 242 minecraft:black_concrete
fill 237 261 255 237 262 255 minecraft:black_concrete
fill 239 261 242 239 262 242 minecraft:black_concrete
fill 239 261 255 239 262 255 minecraft:black_concrete
fill 241 261 243 241 262 243 minecraft:black_concrete
fill 241 261 245 241 262 245 minecraft:black_concrete
fill 241 261 247 241 262 247 minecraft:black_concrete
fill 241 261 249 241 262 249 minecraft:black_concrete
fill 241 261 251 241 262 251 minecraft:black_concrete
fill 241 261 253 241 262 253 minecraft:black_concrete
fill 242 261 257 242 264 257 minecraft:cyan_stained_glass
fill 242 261 261 242 264 261 minecraft:cyan_stained_glass
fill 243 261 256 244 261 256 minecraft:cyan_stained_glass
fill 243 261 262 244 261 262 minecraft:cyan_stained_glass
fill 243 261 270 243 294 270 minecraft:black_concrete
fill 245 261 228 245 308 228 minecraft:black_concrete
fill 247 261 256 247 264 256 minecraft:cyan_stained_glass
fill 247 261 262 247 264 262 minecraft:cyan_stained_glass
fill 248 261 257 248 261 258 minecraft:cyan_stained_glass
fill 248 261 260 248 261 261 minecraft:cyan_stained_glass
fill 248 261 263 250 261 263 minecraft:light_blue_stained_glass
fill 249 261 264 249 262 265 minecraft:gray_concrete
fill 249 261 267 249 262 267 minecraft:gray_concrete
fill 250 261 264 250 262 264 minecraft:gray_concrete
fill 250 261 269 250 262 269 minecraft:gray_concrete
fill 252 261 264 252 262 264 minecraft:gray_concrete
fill 252 261 269 252 262 269 minecraft:gray_concrete
fill 254 261 264 254 262 264 minecraft:gray_concrete
fill 254 261 269 254 262 269 minecraft:gray_concrete
fill 256 261 264 256 262 264 minecraft:gray_concrete
fill 256 261 269 256 262 269 minecraft:gray_concrete
fill 258 261 264 258 262 264 minecraft:gray_concrete
fill 258 261 269 258 262 269 minecraft:gray_concrete
fill 260 261 264 260 262 264 minecraft:gray_concrete
fill 260 261 269 260 262 269 minecraft:gray_concrete
fill 262 261 265 262 262 265 minecraft:gray_concrete
fill 262 261 267 262 262 267 minecraft:gray_concrete
fill 277 261 243 277 308 243 minecraft:black_concrete
setblock 277 261 255 minecraft:purple_concrete
fill 235 262 250 235 270 250 minecraft:black_concrete
setblock 238 262 231 minecraft:light[level=15]
setblock 238 262 239 minecraft:light[level=15]
setblock 238 262 263 minecraft:light[level=15]
fill 241 262 258 241 263 260 minecraft:cyan_stained_glass
fill 243 262 256 243 264 256 minecraft:cyan_stained_glass
fill 243 262 262 243 264 262 minecraft:cyan_stained_glass
fill 244 262 255 246 263 255 minecraft:cyan_stained_glass
fill 244 262 259 246 263 259 minecraft:pearlescent_froglight
fill 244 262 263 246 263 263 minecraft:cyan_stained_glass
fill 245 262 258 245 263 258 minecraft:pearlescent_froglight
fill 245 262 260 245 263 260 minecraft:pearlescent_froglight
setblock 246 262 231 minecraft:light[level=15]
setblock 246 262 239 minecraft:light[level=15]
setblock 246 262 247 minecraft:light[level=15]
fill 248 262 257 248 264 257 minecraft:cyan_stained_glass
fill 248 262 261 248 264 261 minecraft:cyan_stained_glass
fill 249 262 258 249 263 260 minecraft:cyan_stained_glass
setblock 254 262 231 minecraft:light[level=15]
setblock 254 262 239 minecraft:light[level=15]
setblock 254 262 247 minecraft:light[level=15]
setblock 254 262 255 minecraft:light[level=15]
setblock 254 262 263 minecraft:light[level=15]
setblock 262 262 231 minecraft:light[level=15]
setblock 262 262 239 minecraft:light[level=15]
setblock 262 262 247 minecraft:light[level=15]
setblock 262 262 255 minecraft:light[level=15]
setblock 262 262 263 minecraft:light[level=15]
setblock 270 262 231 minecraft:light[level=15]
setblock 270 262 239 minecraft:light[level=15]
setblock 270 262 247 minecraft:light[level=15]
setblock 270 262 255 minecraft:light[level=15]
setblock 270 262 263 minecraft:light[level=15]
fill 277 262 255 277 297 255 minecraft:black_concrete
setblock 235 263 234 minecraft:ochre_froglight
setblock 236 263 243 minecraft:light_blue_stained_glass
setblock 236 263 245 minecraft:ochre_froglight
setblock 236 263 247 minecraft:cyan_stained_glass
setblock 236 263 249 minecraft:black_stained_glass
setblock 236 263 251 minecraft:black_stained_glass
setblock 236 263 253 minecraft:cyan_stained_glass
setblock 237 263 242 minecraft:cyan_stained_glass
setblock 237 263 255 minecraft:black_stained_glass
setblock 239 263 242 minecraft:black_stained_glass
setblock 239 263 255 minecraft:ochre_froglight
setblock 241 263 243 minecraft:sea_lantern
setblock 241 263 245 minecraft:sea_lantern
setblock 241 263 247 minecraft:black_stained_glass
setblock 241 263 249 minecraft:sea_lantern
setblock 241 263 251 minecraft:light_blue_stained_glass
setblock 241 263 253 minecraft:ochre_froglight
fill 249 263 264 249 282 264 minecraft:gray_concrete
setblock 249 263 265 minecraft:cyan_stained_glass
setblock 249 263 267 minecraft:cyan_stained_glass
setblock 250 263 264 minecraft:black_stained_glass
setblock 250 263 269 minecraft:light_blue_stained_glass
setblock 252 263 264 minecraft:black_stained_glass
setblock 252 263 269 minecraft:pearlescent_froglight
setblock 254 263 264 minecraft:pearlescent_froglight
setblock 254 263 269 minecraft:pearlescent_froglight
setblock 256 263 264 minecraft:black_stained_glass
setblock 256 263 269 minecraft:pearlescent_froglight
setblock 258 263 264 minecraft:light_blue_stained_glass
setblock 258 263 269 minecraft:magenta_stained_glass
setblock 260 263 264 minecraft:ochre_froglight
setblock 260 263 269 minecraft:black_stained_glass
setblock 260 263 270 minecraft:purple_concrete
setblock 262 263 265 minecraft:sea_lantern
setblock 262 263 267 minecraft:cyan_stained_glass
fill 235 264 234 235 293 234 minecraft:black_concrete
setblock 235 264 240 minecraft:blue_concrete
fill 236 264 243 236 265 243 minecraft:black_concrete
fill 236 264 245 236 265 245 minecraft:black_concrete
fill 236 264 247 236 265 247 minecraft:black_concrete
fill 236 264 249 236 265 249 minecraft:black_concrete
fill 236 264 251 236 265 251 minecraft:black_concrete
fill 236 264 253 236 265 253 minecraft:black_concrete
fill 237 264 242 237 265 242 minecraft:black_concrete
fill 237 264 255 237 265 255 minecraft:black_concrete
fill 239 264 242 239 265 242 minecraft:black_concrete
fill 239 264 255 239 265 255 minecraft:black_concrete
fill 241 264 243 241 265 243 minecraft:black_concrete
fill 241 264 245 241 265 245 minecraft:black_concrete
fill 241 264 247 241 265 247 minecraft:black_concrete
fill 241 264 249 241 265 249 minecraft:black_concrete
fill 241 264 251 241 265 251 minecraft:black_concrete
fill 241 264 253 241 265 253 minecraft:black_concrete
fill 242 264 258 242 265 260 minecraft:cyan_stained_glass
fill 244 264 256 246 265 256 minecraft:cyan_stained_glass
fill 244 264 262 246 265 262 minecraft:cyan_stained_glass
fill 248 264 258 248 265 260 minecraft:cyan_stained_glass
fill 249 264 265 249 265 265 minecraft:gray_concrete
fill 249 264 267 249 265 267 minecraft:gray_concrete
fill 250 264 264 250 265 264 minecraft:gray_concrete
fill 250 264 269 250 265 269 minecraft:gray_concrete
fill 252 264 264 252 265 264 minecraft:gray_concrete
fill 252 264 269 252 265 269 minecraft:gray_concrete
fill 254 264 264 254 265 264 minecraft:gray_concrete
fill 254 264 269 254 265 269 minecraft:gray_concrete
fill 256 264 264 256 265 264 minecraft:gray_concrete
fill 256 264 269 256 265 269 minecraft:gray_concrete
fill 258 264 264 258 265 264 minecraft:gray_concrete
fill 258 264 269 258 265 269 minecraft:gray_concrete
fill 260 264 264 260 265 264 minecraft:gray_concrete
fill 260 264 269 260 265 269 minecraft:gray_concrete
fill 260 264 270 260 273 270 minecraft:black_concrete
fill 262 264 265 262 265 265 minecraft:gray_concrete
fill 262 264 267 262 265 267 minecraft:gray_concrete
setblock 269 264 253 minecraft:sea_lantern
fill 235 265 240 235 308 240 minecraft:black_concrete
setblock 235 265 258 minecraft:magenta_concrete
setblock 238 265 231 minecraft:light[level=12]
setblock 238 265 238 minecraft:light[level=12]
setblock 238 265 259 minecraft:light[level=12]
setblock 238 265 266 minecraft:light[level=12]
fill 243 265 257 243 265 258 minecraft:cyan_stained_glass
fill 243 265 260 243 265 261 minecraft:cyan_stained_glass
fill 244 265 257 244 266 257 minecraft:cyan_stained_glass
fill 244 265 261 244 266 261 minecraft:cyan_stained_glass
setblock 245 265 231 minecraft:light[level=12]
setblock 245 265 238 minecraft:light[level=12]
setblock 245 265 245 minecraft:light[level=12]
setblock 245 265 252 minecraft:light[level=12]
setblock 245 265 259 minecraft:light[level=12]
setblock 245 265 266 minecraft:light[level=12]
fill 246 265 257 247 265 257 minecraft:cyan_stained_glass
fill 246 265 261 247 265 261 minecraft:cyan_stained_glass
fill 247 265 258 247 266 258 minecraft:cyan_stained_glass
fill 247 265 260 247 266 260 minecraft:cyan_stained_glass
setblock 252 265 231 minecraft:light[level=12]
setblock 252 265 238 minecraft:light[level=12]
setblock 252 265 245 minecraft:light[level=12]
setblock 252 265 252 minecraft:light[level=12]
setblock 252 265 259 minecraft:light[level=12]
setblock 259 265 231 minecraft:light[level=12]
setblock 259 265 238 minecraft:light[level=12]
setblock 259 265 245 minecraft:light[level=12]
setblock 259 265 252 minecraft:light[level=12]
setblock 259 265 259 minecraft:light[level=12]
setblock 266 265 231 minecraft:light[level=12]
setblock 266 265 238 minecraft:light[level=12]
setblock 266 265 245 minecraft:light[level=12]
setblock 266 265 252 minecraft:light[level=12]
setblock 266 265 259 minecraft:light[level=12]
setblock 266 265 266 minecraft:light[level=12]
fill 268 265 252 270 265 254 minecraft:white_concrete
setblock 269 265 251 minecraft:white_concrete
setblock 269 265 255 minecraft:white_concrete
setblock 273 265 231 minecraft:light[level=12]
setblock 273 265 238 minecraft:light[level=12]
setblock 273 265 245 minecraft:light[level=12]
setblock 273 265 252 minecraft:light[level=12]
setblock 273 265 259 minecraft:light[level=12]
setblock 273 265 266 minecraft:light[level=12]
setblock 277 265 244 minecraft:verdant_froglight
setblock 235 266 251 minecraft:verdant_froglight
fill 235 266 258 235 308 258 minecraft:black_concrete
setblock 236 266 243 minecraft:cyan_stained_glass
setblock 236 266 245 minecraft:magenta_stained_glass
setblock 236 266 247 minecraft:pearlescent_froglight
setblock 236 266 249 minecraft:black_stained_glass
setblock 236 266 251 minecraft:black_stained_glass
setblock 236 266 253 minecraft:ochre_froglight
setblock 237 266 242 minecraft:pearlescent_froglight
setblock 237 266 255 minecraft:magenta_stained_glass
setblock 239 266 242 minecraft:pearlescent_froglight
setblock 239 266 255 minecraft:ochre_froglight
setblock 241 266 243 minecraft:ochre_froglight
setblock 241 266 245 minecraft:pearlescent_froglight
setblock 241 266 247 minecraft:light_blue_stained_glass
setblock 241 266 249 minecraft:magenta_stained_glass
setblock 241 266 251 minecraft:black_stained_glass
setblock 241 266 253 minecraft:sea_lantern
fill 243 266 258 246 266 260 minecraft:cyan_stained_glass
fill 245 266 257 246 266 257 minecraft:cyan_stained_glass
fill 245 266 261 246 266 261 minecraft:cyan_stained_glass
setblock 247 266 259 minecraft:cyan_stained_glass
setblock 249 266 265 minecraft:cyan_stained_glass
setblock 249 266 267 minecraft:light_blue_stained_glass
setblock 250 266 264 minecraft:cyan_stained_glass
setblock 250 266 269 minecraft:black_stained_glass
setblock 252 266 264 minecraft:pearlescent_froglight
setblock 252 266 269 minecraft:light_blue_stained_glass
setblock 254 266 264 minecraft:light_blue_stained_glass
setblock 254 266 269 minecraft:pearlescent_froglight
setblock 256 266 264 minecraft:cyan_stained_glass
setblock 256 266 269 minecraft:ochre_froglight
setblock 257 266 270 minecraft:blue_concrete
setblock 258 266 264 minecraft:black_stained_glass
setblock 258 266 269 minecraft:cyan_stained_glass
setblock 260 266 264 minecraft:magenta_stained_glass
setblock 260 266 269 minecraft:black_stained_glass
setblock 262 266 265 minecraft:black_stained_glass
setblock 262 266 267 minecraft:black_stained_glass
fill 269 266 252 269 266 254 minecraft:light_blue_stained_glass
setblock 272 266 228 minecraft:magenta_concrete
fill 277 266 244 277 308 244 minecraft:black_concrete
setblock 235 267 248 minecraft:ochre_froglight
fill 235 267 251 236 268 251 minecraft:black_concrete
setblock 235 267 255 minecraft:blue_concrete
fill 236 267 243 236 268 243 minecraft:black_concrete
fill 236 267 245 236 268 245 minecraft:black_concrete
fill 236 267 247 236 268 247 minecraft:black_concrete
fill 236 267 249 236 268 249 minecraft:black_concrete
fill 236 267 253 236 268 253 minecraft:black_concrete
fill 237 267 242 237 268 242 minecraft:black_concrete
fill 237 267 255 237 268 255 minecraft:black_concrete
fill 239 267 242 239 268 242 minecraft:black_concrete
fill 239 267 255 239 268 255 minecraft:black_concrete
fill 241 267 243 241 268 243 minecraft:black_concrete
fill 241 267 245 241 268 245 minecraft:black_concrete
fill 241 267 247 241 268 247 minecraft:black_concrete
fill 241 267 249 241 268 249 minecraft:black_concrete
fill 241 267 251 241 268 251 minecraft:black_concrete
fill 241 267 253 241 268 253 minecraft:black_concrete
fill 249 267 265 249 268 265 minecraft:gray_concrete
fill 249 267 267 249 268 267 minecraft:gray_concrete
fill 250 267 264 250 268 264 minecraft:gray_concrete
fill 250 267 269 250 268 269 minecraft:gray_concrete
fill 252 267 264 252 268 264 minecraft:gray_concrete
fill 252 267 269 252 268 269 minecraft:gray_concrete
fill 254 267 264 254 268 264 minecraft:gray_concrete
fill 254 267 269 254 268 269 minecraft:gray_concrete
fill 256 267 264 256 268 264 minecraft:gray_concrete
fill 256 267 269 256 268 269 minecraft:gray_concrete
fill 257 267 270 257 283 270 minecraft:black_concrete
fill 258 267 264 258 268 264 minecraft:gray_concrete
fill 258 267 269 258 268 269 minecraft:gray_concrete
setblock 259 267 270 minecraft:magenta_concrete
fill 260 267 264 260 268 264 minecraft:gray_concrete
fill 260 267 269 260 268 269 minecraft:gray_concrete
fill 262 267 265 262 268 265 minecraft:gray_concrete
fill 262 267 267 262 268 267 minecraft:gray_concrete
setblock 268 267 228 minecraft:magenta_concrete
fill 272 267 228 272 298 228 minecraft:black_concrete
setblock 277 267 250 minecraft:magenta_concrete
setblock 277 267 266 minecraft:pearlescent_froglight
fill 235 268 248 235 308 248 minecraft:black_concrete
fill 235 268 255 235 308 255 minecraft:black_concrete
fill 259 268 270 259 308 270 minecraft:black_concrete
fill 268 268 228 268 296 228 minecraft:black_concrete
fill 277 268 250 277 271 250 minecraft:black_concrete
fill 277 268 266 277 308 266 minecraft:black_concrete
fill 235 269 251 235 307 251 minecraft:black_concrete
setblock 236 269 243 minecraft:black_stained_glass
setblock 236 269 245 minecraft:pearlescent_froglight
setblock 236 269 247 minecraft:cyan_stained_glass
setblock 236 269 249 minecraft:black_stained_glass
setblock 236 269 251 minecraft:black_stained_glass
setblock 236 269 253 minecraft:cyan_stained_glass
setblock 237 269 242 minecraft:black_stained_glass
setblock 237 269 255 minecraft:black_stained_glass
setblock 238 269 231 minecraft:light[level=15]
setblock 238 269 239 minecraft:light[level=15]
setblock 238 269 263 minecraft:light[level=15]
setblock 239 269 242 minecraft:black_stained_glass
setblock 239 269 255 minecraft:black_stained_glass
setblock 241 269 243 minecraft:cyan_stained_glass
setblock 241 269 245 minecraft:cyan_stained_glass
setblock 241 269 247 minecraft:light_blue_stained_glass
setblock 241 269 249 minecraft:sea_lantern
setblock 241 269 251 minecraft:light_blue_stained_glass
setblock 241 269 253 minecraft:black_stained_glass
setblock 246 269 231 minecraft:light[level=15]
setblock 246 269 239 minecraft:light[level=15]
setblock 246 269 247 minecraft:light[level=15]
setblock 246 269 255 minecraft:light[level=15]
setblock 246 269 263 minecraft:light[level=15]
setblock 249 269 265 minecraft:black_stained_glass
setblock 249 269 267 minecraft:black_stained_glass
setblock 250 269 264 minecraft:cyan_stained_glass
setblock 250 269 269 minecraft:black_stained_glass
setblock 252 269 264 minecraft:cyan_stained_glass
setblock 252 269 269 minecraft:light_blue_stained_glass
setblock 254 269 231 minecraft:light[level=15]
setblock 254 269 239 minecraft:light[level=15]
setblock 254 269 247 minecraft:light[level=15]
setblock 254 269 255 minecraft:light[level=15]
setblock 254 269 263 minecraft:light[level=15]
setblock 254 269 264 minecraft:black_stained_glass
setblock 254 269 269 minecraft:cyan_stained_glass
setblock 256 269 264 minecraft:black_stained_glass
setblock 256 269 269 minecraft:black_stained_glass
setblock 258 269 264 minecraft:sea_lantern
setblock 258 269 269 minecraft:ochre_froglight
setblock 260 269 264 minecraft:cyan_stained_glass
setblock 260 269 269 minecraft:ochre_froglight
setblock 262 269 231 minecraft:light[level=15]
setblock 262 269 239 minecraft:light[level=15]
setblock 262 269 247 minecraft:light[level=15]
setblock 262 269 255 minecraft:light[level=15]
setblock 262 269 263 minecraft:light[level=15]
setblock 262 269 265 minecraft:light_blue_stained_glass
setblock 262 269 267 minecraft:black_stained_glass
setblock 270 269 231 minecraft:light[level=15]
setblock 270 269 239 minecraft:light[level=15]
setblock 270 269 247 minecraft:light[level=15]
setblock 270 269 255 minecraft:light[level=15]
setblock 270 269 263 minecraft:light[level=15]
fill 236 270 243 236 271 243 minecraft:black_concrete
fill 236 270 245 236 271 245 minecraft:black_concrete
fill 236 270 247 236 271 247 minecraft:black_concrete
fill 236 270 249 236 271 249 minecraft:black_concrete
fill 236 270 251 236 271 251 minecraft:black_concrete
fill 236 270 253 236 271 253 minecraft:black_concrete
fill 237 270 242 237 271 242 minecraft:black_concrete
fill 237 270 255 237 271 255 minecraft:black_concrete
fill 239 270 242 239 271 242 minecraft:black_concrete
fill 239 270 255 239 271 255 minecraft:black_concrete
fill 241 270 243 241 271 243 minecraft:black_concrete
fill 241 270 245 241 271 245 minecraft:black_concrete
fill 241 270 247 241 271 247 minecraft:black_concrete
fill 241 270 249 241 271 249 minecraft:black_concrete
fill 241 270 251 241 271 251 minecraft:black_concrete
fill 241 270 253 241 271 253 minecraft:black_concrete
fill 249 270 265 249 271 265 minecraft:gray_concrete
fill 249 270 267 249 271 267 minecraft:gray_concrete
fill 250 270 264 250 271 264 minecraft:gray_concrete
fill 250 270 269 250 271 269 minecraft:gray_concrete
fill 252 270 264 252 271 264 minecraft:gray_concrete
fill 252 270 269 252 271 269 minecraft:gray_concrete
fill 254 270 264 254 271 264 minecraft:gray_concrete
fill 254 270 269 254 271 269 minecraft:gray_concrete
fill 256 270 264 256 271 264 minecraft:gray_concrete
fill 256 270 269 256 271 269 minecraft:gray_concrete
fill 258 270 264 258 271 264 minecraft:gray_concrete
fill 258 270 269 258 271 269 minecraft:gray_concrete
fill 260 270 264 260 271 264 minecraft:gray_concrete
fill 260 270 269 260 271 269 minecraft:gray_concrete
fill 262 270 265 262 271 265 minecraft:gray_concrete
fill 262 270 267 262 271 267 minecraft:gray_concrete
setblock 277 270 241 minecraft:magenta_concrete
setblock 277 270 268 minecraft:magenta_concrete
setblock 235 271 250 minecraft:cyan_concrete
setblock 238 271 231 minecraft:light[level=12]
setblock 238 271 238 minecraft:light[level=12]
setblock 238 271 259 minecraft:light[level=12]
setblock 238 271 266 minecraft:light[level=12]
setblock 243 271 228 minecraft:verdant_froglight
setblock 245 271 231 minecraft:light[level=12]
setblock 245 271 238 minecraft:light[level=12]
setblock 245 271 245 minecraft:light[level=12]
setblock 245 271 252 minecraft:light[level=12]
setblock 245 271 259 minecraft:light[level=12]
setblock 245 271 266 minecraft:light[level=12]
setblock 252 271 231 minecraft:light[level=12]
setblock 252 271 238 minecraft:light[level=12]
setblock 252 271 245 minecraft:light[level=12]
setblock 252 271 252 minecraft:light[level=12]
setblock 252 271 259 minecraft:light[level=12]
setblock 259 271 231 minecraft:light[level=12]
setblock 259 271 238 minecraft:light[level=12]
setblock 259 271 245 minecraft:light[level=12]
setblock 259 271 252 minecraft:light[level=12]
setblock 259 271 259 minecraft:light[level=12]
setblock 266 271 231 minecraft:light[level=12]
setblock 266 271 238 minecraft:light[level=12]
setblock 266 271 245 minecraft:light[level=12]
setblock 266 271 252 minecraft:light[level=12]
setblock 266 271 259 minecraft:light[level=12]
setblock 266 271 266 minecraft:light[level=12]
setblock 269 271 270 minecraft:pearlescent_froglight
setblock 271 271 228 minecraft:cyan_concrete
setblock 273 271 231 minecraft:light[level=12]
setblock 273 271 238 minecraft:light[level=12]
setblock 273 271 245 minecraft:light[level=12]
setblock 273 271 252 minecraft:light[level=12]
setblock 273 271 259 minecraft:light[level=12]
setblock 273 271 266 minecraft:light[level=12]
setblock 274 271 228 minecraft:blue_concrete
fill 277 271 241 277 286 241 minecraft:black_concrete
fill 277 271 268 277 308 268 minecraft:black_concrete
setblock 235 272 231 minecraft:pearlescent_froglight
fill 235 272 250 235 308 250 minecraft:black_concrete
setblock 236 272 243 minecraft:black_stained_glass
setblock 236 272 245 minecraft:pearlescent_froglight
setblock 236 272 247 minecraft:sea_lantern
setblock 236 272 249 minecraft:black_stained_glass
setblock 236 272 251 minecraft:sea_lantern
setblock 236 272 253 minecraft:light_blue_stained_glass
setblock 237 272 242 minecraft:magenta_stained_glass
setblock 237 272 255 minecraft:magenta_stained_glass
setblock 239 272 242 minecraft:black_stained_glass
setblock 239 272 255 minecraft:ochre_froglight
setblock 241 272 243 minecraft:magenta_stained_glass
setblock 241 272 245 minecraft:sea_lantern
setblock 241 272 247 minecraft:light_blue_stained_glass
setblock 241 272 249 minecraft:black_stained_glass
setblock 241 272 251 minecraft:ochre_froglight
setblock 241 272 253 minecraft:sea_lantern
fill 243 272 228 243 308 228 minecraft:black_concrete
setblock 249 272 265 minecraft:black_stained_glass
setblock 249 272 267 minecraft:magenta_stained_glass
setblock 250 272 264 minecraft:light_blue_stained_glass
setblock 250 272 269 minecraft:black_stained_glass
setblock 252 272 228 minecraft:ochre_froglight
setblock 252 272 264 minecraft:light_blue_stained_glass
setblock 252 272 269 minecraft:sea_lantern
setblock 254 272 264 minecraft:cyan_stained_glass
setblock 254 272 269 minecraft:black_stained_glass
setblock 256 272 264 minecraft:light_blue_stained_glass
setblock 256 272 269 minecraft:black_stained_glass
setblock 258 272 264 minecraft:cyan_stained_glass
setblock 258 272 269 minecraft:black_stained_glass
setblock 260 272 264 minecraft:black_stained_glass
setblock 260 272 269 minecraft:black_stained_glass
setblock 262 272 265 minecraft:light_blue_stained_glass
setblock 262 272 267 minecraft:cyan_stained_glass
fill 269 272 270 269 278 270 minecraft:black_concrete
fill 271 272 228 271 298 228 minecraft:black_concrete
fill 274 272 228 274 308 228 minecraft:black_concrete
setblock 277 272 250 minecraft:blue_concrete
fill 235 273 231 235 308 231 minecraft:black_concrete
fill 236 273 243 236 274 243 minecraft:black_concrete
fill 236 273 245 236 274 245 minecraft:black_concrete
fill 236 273 247 236 274 247 minecraft:black_concrete
fill 236 273 249 236 274 249 minecraft:black_concrete
fill 236 273 251 236 274 251 minecraft:black_concrete
fill 236 273 253 236 274 253 minecraft:black_concrete
fill 237 273 242 237 274 242 minecraft:black_concrete
fill 237 273 255 237 274 255 minecraft:black_concrete
fill 239 273 242 239 274 242 minecraft:black_concrete
fill 239 273 255 239 274 255 minecraft:black_concrete
fill 241 273 243 241 274 243 minecraft:black_concrete
fill 241 273 245 241 274 245 minecraft:black_concrete
fill 241 273 247 241 274 247 minecraft:black_concrete
fill 241 273 249 241 274 249 minecraft:black_concrete
fill 241 273 251 241 274 251 minecraft:black_concrete
fill 241 273 253 241 274 253 minecraft:black_concrete
fill 249 273 265 249 274 265 minecraft:gray_concrete
fill 249 273 267 249 274 267 minecraft:gray_concrete
fill 250 273 264 250 274 264 minecraft:gray_concrete
fill 250 273 269 250 274 269 minecraft:gray_concrete
fill 252 273 228 252 275 228 minecraft:black_concrete
fill 252 273 264 252 274 264 minecraft:gray_concrete
fill 252 273 269 252 274 269 minecraft:gray_concrete
setblock 253 273 270 minecraft:ochre_froglight
fill 254 273 264 254 274 264 minecraft:gray_concrete
fill 254 273 269 254 274 269 minecraft:gray_concrete
fill 256 273 264 256 274 264 minecraft:gray_concrete
fill 256 273 269 256 274 269 minecraft:gray_concrete
fill 258 273 264 258 274 264 minecraft:gray_concrete
fill 258 273 269 258 274 269 minecraft:gray_concrete
fill 260 273 264 260 274 264 minecraft:gray_concrete
fill 260 273 269 260 274 269 minecraft:gray_concrete
fill 262 273 265 262 274 265 minecraft:gray_concrete
fill 262 273 267 262 274 267 minecraft:gray_concrete
fill 277 273 250 277 308 250 minecraft:black_concrete
fill 250 274 243 251 274 244 minecraft:sea_lantern
fill 250 274 254 251 274 255 minecraft:sea_lantern
fill 253 274 270 253 282 270 minecraft:black_concrete
setblock 260 274 270 minecraft:verdant_froglight
fill 261 274 243 262 274 244 minecraft:sea_lantern
fill 261 274 254 262 274 255 minecraft:sea_lantern
setblock 267 274 270 minecraft:pearlescent_froglight
setblock 277 274 265 minecraft:verdant_froglight
setblock 235 275 246 minecraft:sea_lantern
setblock 236 275 243 minecraft:cyan_stained_glass
setblock 236 275 245 minecraft:black_stained_glass
setblock 236 275 247 minecraft:sea_lantern
setblock 236 275 249 minecraft:pearlescent_froglight
setblock 236 275 251 minecraft:light_blue_stained_glass
setblock 236 275 253 minecraft:black_stained_glass
setblock 237 275 242 minecraft:ochre_froglight
setblock 237 275 255 minecraft:black_stained_glass
setblock 239 275 242 minecraft:black_stained_glass
setblock 239 275 255 minecraft:black_stained_glass
setblock 239 275 270 minecraft:sea_lantern
setblock 241 275 243 minecraft:sea_lantern
setblock 241 275 245 minecraft:black_stained_glass
setblock 241 275 247 minecraft:pearlescent_froglight
setblock 241 275 249 minecraft:light_blue_stained_glass
setblock 241 275 251 minecraft:black_stained_glass
setblock 241 275 253 minecraft:black_stained_glass
fill 249 275 243 251 277 244 minecraft:gray_concrete
fill 249 275 254 251 277 255 minecraft:gray_concrete
setblock 249 275 265 minecraft:magenta_stained_glass
setblock 249 275 267 minecraft:cyan_stained_glass
fill 250 275 242 251 277 242 minecraft:gray_concrete
fill 250 275 256 251 277 256 minecraft:gray_concrete
setblock 250 275 264 minecraft:pearlescent_froglight
setblock 250 275 269 minecraft:pearlescent_froglight
setblock 252 275 264 minecraft:light_blue_stained_glass
setblock 252 275 269 minecraft:light_blue_stained_glass
setblock 254 275 264 minecraft:black_stained_glass
setblock 254 275 269 minecraft:black_stained_glass
setblock 256 275 264 minecraft:black_stained_glass
setblock 256 275 269 minecraft:black_stained_glass
setblock 258 275 264 minecraft:ochre_froglight
setblock 258 275 269 minecraft:magenta_stained_glass
setblock 260 275 264 minecraft:ochre_froglight
setblock 260 275 269 minecraft:pearlescent_froglight
fill 260 275 270 260 308 270 minecraft:black_concrete
fill 261 275 242 262 277 244 minecraft:gray_concrete
fill 261 275 254 262 277 256 minecraft:gray_concrete
setblock 262 275 265 minecraft:light_blue_stained_glass
setblock 262 275 267 minecraft:sea_lantern
fill 263 275 243 263 277 244 minecraft:gray_concrete
fill 263 275 254 263 277 255 minecraft:gray_concrete
fill 267 275 270 267 276 270 minecraft:black_concrete
fill 277 275 265 277 308 265 minecraft:black_concrete
setblock 235 276 239 minecraft:cyan_concrete
fill 235 276 246 235 308 246 minecraft:black_concrete
fill 236 276 243 236 277 243 minecraft:black_concrete
fill 236 276 245 236 277 245 minecraft:black_concrete
fill 236 276 247 236 277 247 minecraft:black_concrete
fill 236 276 249 236 277 249 minecraft:black_concrete
fill 236 276 251 236 277 251 minecraft:black_concrete
fill 236 276 253 236 277 253 minecraft:black_concrete
fill 237 276 242 237 277 242 minecraft:black_concrete
fill 237 276 255 237 277 255 minecraft:black_concrete
setblock 238 276 231 minecraft:light[level=15]
setblock 238 276 239 minecraft:light[level=15]
setblock 238 276 263 minecraft:light[level=15]
fill 239 276 242 239 277 242 minecraft:black_concrete
fill 239 276 255 239 277 255 minecraft:black_concrete
fill 239 276 270 239 308 270 minecraft:black_concrete
fill 241 276 243 241 277 243 minecraft:black_concrete
fill 241 276 245 241 277 245 minecraft:black_concrete
fill 241 276 247 241 277 247 minecraft:black_concrete
fill 241 276 249 241 277 249 minecraft:black_concrete
fill 241 276 251 241 277 251 minecraft:black_concrete
fill 241 276 253 241 277 253 minecraft:black_concrete
setblock 246 276 231 minecraft:light[level=15]
setblock 246 276 239 minecraft:light[level=15]
setblock 246 276 247 minecraft:light[level=15]
setblock 246 276 255 minecraft:light[level=15]
setblock 246 276 263 minecraft:light[level=15]
fill 249 276 265 249 277 265 minecraft:gray_concrete
fill 249 276 267 249 277 267 minecraft:gray_concrete
fill 250 276 264 250 277 264 minecraft:gray_concrete
fill 250 276 269 250 277 269 minecraft:gray_concrete
setblock 252 276 228 minecraft:ochre_froglight
fill 252 276 264 252 277 264 minecraft:gray_concrete
fill 252 276 269 252 277 269 minecraft:gray_concrete
setblock 254 276 231 minecraft:light[level=15]
setblock 254 276 239 minecraft:light[level=15]
setblock 254 276 247 minecraft:light[level=15]
setblock 254 276 255 minecraft:light[level=15]
setblock 254 276 263 minecraft:light[level=15]
fill 254 276 264 254 277 264 minecraft:gray_concrete
fill 254 276 269 254 277 269 minecraft:gray_concrete
fill 256 276 264 256 277 264 minecraft:gray_concrete
fill 256 276 269 256 277 269 minecraft:gray_concrete
fill 258 276 264 258 277 264 minecraft:gray_concrete
fill 258 276 269 258 277 269 minecraft:gray_concrete
fill 260 276 264 260 277 264 minecraft:gray_concrete
fill 260 276 269 260 277 269 minecraft:gray_concrete
setblock 262 276 231 minecraft:light[level=15]
setblock 262 276 239 minecraft:light[level=15]
setblock 262 276 247 minecraft:light[level=15]
setblock 262 276 263 minecraft:light[level=15]
fill 262 276 265 262 277 265 minecraft:gray_concrete
fill 262 276 267 262 277 267 minecraft:gray_concrete
setblock 270 276 231 minecraft:light[level=15]
setblock 270 276 239 minecraft:light[level=15]
setblock 270 276 247 minecraft:light[level=15]
setblock 270 276 255 minecraft:light[level=15]
setblock 270 276 263 minecraft:light[level=15]
setblock 277 276 230 minecraft:pearlescent_froglight
setblock 277 276 258 minecraft:blue_concrete
setblock 235 277 239 minecraft:blue_concrete
setblock 235 277 241 minecraft:magenta_concrete
setblock 238 277 231 minecraft:light[level=12]
setblock 238 277 238 minecraft:light[level=12]
setblock 238 277 259 minecraft:light[level=12]
setblock 238 277 266 minecraft:light[level=12]
setblock 245 277 231 minecraft:light[level=12]
setblock 245 277 238 minecraft:light[level=12]
setblock 245 277 245 minecraft:light[level=12]
setblock 245 277 252 minecraft:light[level=12]
setblock 245 277 259 minecraft:light[level=12]
setblock 245 277 266 minecraft:light[level=12]
setblock 247 277 228 minecraft:verdant_froglight
setblock 252 277 228 minecraft:black_concrete
setblock 252 277 231 minecraft:light[level=12]
setblock 252 277 238 minecraft:light[level=12]
setblock 252 277 245 minecraft:light[level=12]
setblock 252 277 259 minecraft:light[level=12]
setblock 259 277 231 minecraft:light[level=12]
setblock 259 277 238 minecraft:light[level=12]
setblock 259 277 245 minecraft:light[level=12]
setblock 259 277 252 minecraft:light[level=12]
setblock 259 277 259 minecraft:light[level=12]
setblock 266 277 231 minecraft:light[level=12]
setblock 266 277 238 minecraft:light[level=12]
setblock 266 277 245 minecraft:light[level=12]
setblock 266 277 252 minecraft:light[level=12]
setblock 266 277 259 minecraft:light[level=12]
setblock 266 277 266 minecraft:light[level=12]
setblock 267 277 270 minecraft:verdant_froglight
setblock 273 277 231 minecraft:light[level=12]
setblock 273 277 238 minecraft:light[level=12]
setblock 273 277 245 minecraft:light[level=12]
setblock 273 277 252 minecraft:light[level=12]
setblock 273 277 259 minecraft:light[level=12]
setblock 273 277 266 minecraft:light[level=12]
fill 277 277 230 277 308 230 minecraft:black_concrete
fill 277 277 258 277 285 258 minecraft:black_concrete
setblock 277 277 259 minecraft:blue_concrete
fill 235 278 239 235 308 239 minecraft:black_concrete
fill 235 278 241 235 308 241 minecraft:black_concrete
fill 236 278 242 236 278 255 minecraft:pearlescent_froglight
fill 237 278 242 241 278 242 minecraft:pearlescent_froglight
fill 237 278 255 241 278 255 minecraft:pearlescent_froglight
fill 238 278 248 238 286 248 minecraft:iron_bars
fill 241 278 243 241 278 254 minecraft:pearlescent_froglight
fill 246 278 246 246 278 252 minecraft:sea_lantern
fill 247 278 228 247 282 228 minecraft:black_concrete
fill 247 278 244 247 278 246 minecraft:sea_lantern
fill 247 278 247 249 278 251 minecraft:black_concrete
fill 247 278 252 247 278 254 minecraft:sea_lantern
fill 248 278 243 248 278 244 minecraft:sea_lantern
fill 248 278 245 251 278 246 minecraft:black_concrete
fill 248 278 252 251 278 253 minecraft:black_concrete
fill 248 278 254 248 278 255 minecraft:sea_lantern
setblock 249 278 242 minecraft:sea_lantern
fill 249 278 243 263 278 244 minecraft:black_concrete
fill 249 278 254 263 278 255 minecraft:black_concrete
setblock 249 278 256 minecraft:sea_lantern
setblock 249 278 265 minecraft:sea_lantern
setblock 249 278 267 minecraft:ochre_froglight
fill 250 278 241 251 278 241 minecraft:sea_lantern
fill 250 278 242 262 278 242 minecraft:black_concrete
setblock 250 278 247 minecraft:black_concrete
setblock 250 278 251 minecraft:black_concrete
fill 250 278 256 262 278 256 minecraft:black_concrete
fill 250 278 257 251 278 257 minecraft:sea_lantern
setblock 250 278 264 minecraft:ochre_froglight
setblock 250 278 269 minecraft:light_blue_stained_glass
fill 251 278 240 253 278 240 minecraft:sea_lantern
fill 251 278 258 253 278 258 minecraft:sea_lantern
setblock 252 278 228 minecraft:cyan_concrete
fill 252 278 241 260 278 241 minecraft:black_concrete
fill 252 278 245 264 278 245 minecraft:black_concrete
fill 252 278 253 264 278 253 minecraft:black_concrete
fill 252 278 257 260 278 257 minecraft:black_concrete
setblock 252 278 264 minecraft:sea_lantern
setblock 252 278 269 minecraft:black_stained_glass
fill 253 278 239 259 278 239 minecraft:sea_lantern
fill 253 278 259 259 278 259 minecraft:sea_lantern
fill 254 278 240 258 278 240 minecraft:black_concrete
fill 254 278 258 258 278 258 minecraft:black_concrete
setblock 254 278 264 minecraft:pearlescent_froglight
setblock 254 278 269 minecraft:cyan_stained_glass
fill 255 278 246 264 278 246 minecraft:black_concrete
fill 255 278 252 264 278 252 minecraft:black_concrete
fill 256 278 247 265 278 247 minecraft:black_concrete
fill 256 278 251 265 278 251 minecraft:black_concrete
setblock 256 278 264 minecraft:ochre_froglight
setblock 256 278 269 minecraft:black_stained_glass
fill 257 278 248 265 278 250 minecraft:black_concrete
setblock 258 278 264 minecraft:black_stained_glass
setblock 258 278 269 minecraft:black_stained_glass
fill 259 278 240 261 278 240 minecraft:sea_lantern
fill 259 278 258 261 278 258 minecraft:sea_lantern
setblock 260 278 264 minecraft:cyan_stained_glass
setblock 260 278 269 minecraft:cyan_stained_glass
fill 261 278 241 262 278 241 minecraft:sea_lantern
fill 261 278 257 262 278 257 minecraft:sea_lantern
setblock 262 278 265 minecraft:ochre_froglight
setblock 262 278 267 minecraft:pearlescent_froglight
setblock 263 278 242 minecraft:sea_lantern
setblock 263 278 256 minecraft:sea_lantern
fill 264 278 243 264 278 244 minecraft:sea_lantern
fill 264 278 254 264 278 255 minecraft:sea_lantern
fill 265 278 244 265 278 246 minecraft:sea_lantern
fill 265 278 252 265 278 254 minecraft:sea_lantern
fill 266 278 246 266 278 252 minecraft:sea_lantern
fill 267 278 270 267 303 270 minecraft:black_concrete
setblock 274 278 270 minecraft:cyan_concrete
fill 277 278 259 277 304 259 minecraft:black_concrete
fill 246 279 246 246 279 252 minecraft:pearlescent_froglight
fill 247 279 244 247 279 245 minecraft:pearlescent_froglight
setblock 247 279 246 minecraft:gray_stained_glass
fill 247 279 247 247 279 250 minecraft:black_stained_glass
setblock 247 279 251 minecraft:gray_stained_glass
fill 247 279 252 247 279 254 minecraft:pearlescent_froglight
fill 248 279 243 248 279 244 minecraft:pearlescent_froglight
setblock 248 279 245 minecraft:black_stained_glass
fill 248 279 246 248 279 252 minecraft:magenta_concrete
setblock 248 279 253 minecraft:black_stained_glass
fill 248 279 254 249 279 254 minecraft:gray_stained_glass
setblock 248 279 255 minecraft:pearlescent_froglight
setblock 249 279 242 minecraft:pearlescent_froglight
fill 249 279 243 249 279 244 minecraft:black_stained_glass
fill 249 279 245 249 279 246 minecraft:magenta_concrete
fill 249 279 247 249 279 251 minecraft:sea_lantern
fill 249 279 252 249 279 253 minecraft:magenta_concrete
fill 249 279 255 250 279 255 minecraft:black_stained_glass
setblock 249 279 256 minecraft:pearlescent_froglight
fill 249 279 265 249 280 265 minecraft:gray_concrete
fill 249 279 267 249 280 267 minecraft:gray_concrete
fill 250 279 241 251 279 241 minecraft:pearlescent_froglight
fill 250 279 242 250 279 243 minecraft:black_stained_glass
fill 250 279 244 250 279 245 minecraft:magenta_concrete
fill 250 279 246 250 279 247 minecraft:sea_lantern
fill 250 279 251 250 279 252 minecraft:sea_lantern
fill 250 279 253 250 279 254 minecraft:magenta_concrete
fill 250 279 256 251 279 256 minecraft:black_stained_glass
fill 250 279 257 251 279 257 minecraft:pearlescent_froglight
fill 250 279 264 250 280 264 minecraft:gray_concrete
fill 250 279 269 250 280 269 minecraft:gray_concrete
fill 251 279 240 252 279 240 minecraft:pearlescent_froglight
setblock 251 279 242 minecraft:black_stained_glass
fill 251 279 243 252 279 244 minecraft:magenta_concrete
fill 251 279 245 251 279 246 minecraft:sea_lantern
fill 251 279 252 251 279 253 minecraft:sea_lantern
fill 251 279 254 252 279 255 minecraft:magenta_concrete
fill 251 279 258 253 279 258 minecraft:pearlescent_froglight
fill 252 279 228 252 308 228 minecraft:black_concrete
fill 252 279 241 253 279 242 minecraft:gray_stained_glass
fill 252 279 245 255 279 245 minecraft:sea_lantern
fill 252 279 253 255 279 253 minecraft:sea_lantern
fill 252 279 256 253 279 256 minecraft:gray_stained_glass
fill 252 279 257 260 279 257 minecraft:black_stained_glass
fill 252 279 264 252 280 264 minecraft:gray_concrete
fill 252 279 269 252 280 269 minecraft:gray_concrete
fill 253 279 239 259 279 239 minecraft:pearlescent_froglight
setblock 253 279 240 minecraft:gray_stained_glass
fill 253 279 243 259 279 243 minecraft:black_stained_glass
fill 253 279 244 256 279 244 minecraft:magenta_concrete
fill 253 279 254 256 279 254 minecraft:magenta_concrete
fill 253 279 255 259 279 255 minecraft:black_stained_glass
fill 253 279 259 259 279 259 minecraft:pearlescent_froglight
fill 254 279 240 255 279 241 minecraft:black_stained_glass
fill 254 279 242 255 279 242 minecraft:magenta_concrete
fill 254 279 256 255 279 256 minecraft:magenta_concrete
fill 254 279 258 255 279 258 minecraft:gray_stained_glass
fill 254 279 264 254 280 264 minecraft:gray_concrete
fill 254 279 269 254 280 269 minecraft:gray_concrete
fill 255 279 246 256 279 246 minecraft:sea_lantern
fill 255 279 252 256 279 252 minecraft:sea_lantern
fill 256 279 240 257 279 242 minecraft:gray_stained_glass
fill 256 279 245 257 279 245 minecraft:magenta_concrete
fill 256 279 247 257 279 247 minecraft:sea_lantern
fill 256 279 251 257 279 251 minecraft:sea_lantern
fill 256 279 253 257 279 253 minecraft:magenta_concrete
fill 256 279 256 257 279 256 minecraft:gray_stained_glass
fill 256 279 258 257 279 258 minecraft:black_stained_glass
fill 256 279 264 256 280 264 minecraft:gray_concrete
fill 256 279 269 256 280 269 minecraft:gray_concrete
setblock 257 279 244 minecraft:cyan_concrete
fill 257 279 246 258 279 246 minecraft:magenta_concrete
fill 257 279 248 257 279 250 minecraft:sea_lantern
fill 257 279 252 258 279 252 minecraft:magenta_concrete
setblock 257 279 254 minecraft:gray_stained_glass
fill 258 279 240 258 279 241 minecraft:black_stained_glass
fill 258 279 242 259 279 242 minecraft:magenta_concrete
fill 258 279 244 259 279 244 minecraft:gray_stained_glass
setblock 258 279 245 minecraft:black_stained_glass
fill 258 279 247 258 279 251 minecraft:magenta_concrete
fill 258 279 253 259 279 253 minecraft:gray_stained_glass
setblock 258 279 254 minecraft:cyan_concrete
fill 258 279 256 259 279 256 minecraft:magenta_concrete
fill 258 279 258 259 279 258 minecraft:gray_stained_glass
fill 258 279 264 258 280 264 minecraft:gray_concrete
fill 258 279 269 258 280 269 minecraft:gray_concrete
setblock 259 279 228 minecraft:cyan_concrete
fill 259 279 240 261 279 240 minecraft:pearlescent_froglight
setblock 259 279 241 minecraft:black_stained_glass
setblock 259 279 245 minecraft:cyan_concrete
setblock 259 279 246 minecraft:gray_stained_glass
fill 259 279 247 259 279 250 minecraft:black_stained_glass
setblock 259 279 251 minecraft:gray_stained_glass
setblock 259 279 252 minecraft:black_stained_glass
setblock 259 279 254 minecraft:black_stained_glass
fill 260 279 241 261 279 242 minecraft:gray_stained_glass
fill 260 279 243 261 279 243 minecraft:magenta_concrete
fill 260 279 244 260 279 245 minecraft:black_stained_glass
setblock 260 279 246 minecraft:cyan_concrete
fill 260 279 247 261 279 249 minecraft:gray_stained_glass
fill 260 279 250 260 279 251 minecraft:black_stained_glass
setblock 260 279 252 minecraft:cyan_concrete
fill 260 279 253 261 279 253 minecraft:black_stained_glass
fill 260 279 254 261 279 254 minecraft:gray_stained_glass
fill 260 279 255 261 279 255 minecraft:magenta_concrete
fill 260 279 256 261 279 256 minecraft:gray_stained_glass
fill 260 279 258 261 279 258 minecraft:pearlescent_froglight
fill 260 279 264 260 280 264 minecraft:gray_concrete
fill 260 279 269 260 280 269 minecraft:gray_concrete
setblock 261 279 244 minecraft:magenta_concrete
fill 261 279 245 261 279 246 minecraft:black_stained_glass
fill 261 279 250 261 279 251 minecraft:cyan_concrete
fill 261 279 252 262 279 252 minecraft:black_stained_glass
fill 261 279 257 262 279 257 minecraft:pearlescent_froglight
setblock 262 279 241 minecraft:pearlescent_froglight
fill 262 279 242 262 279 243 minecraft:black_stained_glass
fill 262 279 244 263 279 244 minecraft:gray_stained_glass
setblock 262 279 245 minecraft:magenta_concrete
fill 262 279 246 263 279 246 minecraft:gray_stained_glass
fill 262 279 247 262 279 250 minecraft:black_stained_glass
fill 262 279 251 263 279 251 minecraft:gray_stained_glass
fill 262 279 253 263 279 253 minecraft:gray_stained_glass
setblock 262 279 254 minecraft:magenta_concrete
fill 262 279 255 262 279 256 minecraft:black_stained_glass
fill 262 279 265 262 280 265 minecraft:gray_concrete
fill 262 279 267 262 280 267 minecraft:gray_concrete
setblock 263 279 242 minecraft:pearlescent_froglight
setblock 263 279 243 minecraft:black_stained_glass
fill 263 279 245 264 279 245 minecraft:black_stained_glass
fill 263 279 247 263 279 248 minecraft:magenta_concrete
setblock 263 279 249 minecraft:black_stained_glass
setblock 263 279 250 minecraft:magenta_concrete
setblock 263 279 252 minecraft:magenta_concrete
fill 263 279 254 263 279 255 minecraft:black_stained_glass
setblock 263 279 256 minecraft:pearlescent_froglight
fill 264 279 243 264 279 244 minecraft:pearlescent_froglight
setblock 264 279 246 minecraft:black_stained_glass
fill 264 279 247 265 279 249 minecraft:gray_stained_glass
fill 264 279 250 264 279 253 minecraft:black_stained_glass
setblock 264 279 254 minecraft:gray_stained_glass
setblock 264 279 255 minecraft:pearlescent_froglight
fill 265 279 244 265 279 246 minecraft:pearlescent_froglight
fill 265 279 250 265 279 251 minecraft:black_stained_glass
fill 265 279 252 265 279 254 minecraft:pearlescent_froglight
fill 266 279 246 266 279 252 minecraft:pearlescent_froglight
setblock 269 279 270 minecraft:verdant_froglight
fill 274 279 270 274 308 270 minecraft:black_concrete
setblock 277 279 253 minecraft:blue_concrete
setblock 235 280 266 minecraft:cyan_concrete
setblock 238 280 228 minecraft:blue_concrete
fill 259 280 228 259 308 228 minecraft:black_concrete
fill 269 280 270 269 308 270 minecraft:black_concrete
setblock 276 280 228 minecraft:blue_concrete
fill 277 280 253 277 308 253 minecraft:black_concrete
setblock 277 280 254 minecraft:sea_lantern
setblock 235 281 236 minecraft:magenta_concrete
setblock 235 281 254 minecraft:cyan_concrete
setblock 235 281 262 minecraft:blue_concrete
fill 235 281 266 235 308 266 minecraft:black_concrete
setblock 238 281 228 minecraft:black_concrete
setblock 249 281 265 minecraft:ochre_froglight
setblock 249 281 267 minecraft:black_stained_glass
setblock 250 281 264 minecraft:cyan_stained_glass
setblock 250 281 269 minecraft:cyan_stained_glass
setblock 252 281 264 minecraft:black_stained_glass
setblock 252 281 269 minecraft:black_stained_glass
setblock 254 281 264 minecraft:magenta_stained_glass
setblock 254 281 269 minecraft:black_stained_glass
setblock 256 281 264 minecraft:light_blue_stained_glass
setblock 256 281 269 minecraft:ochre_froglight
setblock 258 281 264 minecraft:black_stained_glass
setblock 258 281 269 minecraft:cyan_stained_glass
setblock 260 281 264 minecraft:black_stained_glass
setblock 260 281 269 minecraft:sea_lantern
setblock 262 281 265 minecraft:black_stained_glass
setblock 262 281 267 minecraft:black_stained_glass
fill 276 281 228 276 308 228 minecraft:black_concrete
setblock 277 281 240 minecraft:blue_concrete
setblock 277 281 251 minecraft:ochre_froglight
fill 277 281 254 277 283 254 minecraft:black_concrete
fill 235 282 236 235 308 236 minecraft:black_concrete
fill 235 282 254 235 308 254 minecraft:black_concrete
fill 235 282 262 235 308 262 minecraft:black_concrete
setblock 238 282 228 minecraft:sea_lantern
setblock 249 282 265 minecraft:gray_concrete
setblock 249 282 267 minecraft:gray_concrete
setblock 250 282 264 minecraft:gray_concrete
setblock 250 282 269 minecraft:gray_concrete
setblock 252 282 264 minecraft:gray_concrete
setblock 252 282 269 minecraft:gray_concrete
setblock 254 282 264 minecraft:gray_concrete
setblock 254 282 269 minecraft:gray_concrete
setblock 256 282 264 minecraft:gray_concrete
setblock 256 282 269 minecraft:gray_concrete
setblock 258 282 264 minecraft:gray_concrete
setblock 258 282 269 minecraft:gray_concrete
setblock 260 282 264 minecraft:gray_concrete
setblock 260 282 269 minecraft:gray_concrete
setblock 262 282 265 minecraft:gray_concrete
setblock 262 282 267 minecraft:gray_concrete
fill 277 282 240 277 287 240 minecraft:black_concrete
fill 277 282 251 277 298 251 minecraft:black_concrete
setblock 235 283 249 minecraft:sea_lantern
fill 236 283 244 237 285 252 minecraft:gray_concrete
fill 238 283 228 238 308 228 minecraft:black_concrete
setblock 238 283 231 minecraft:light[level=15]
setblock 238 283 238 minecraft:light[level=12]
setblock 238 283 239 minecraft:light[level=15]
fill 238 283 244 240 285 247 minecraft:gray_concrete
fill 238 283 249 240 285 252 minecraft:gray_concrete
setblock 238 283 255 minecraft:light[level=15]
setblock 238 283 259 minecraft:light[level=12]
setblock 238 283 263 minecraft:light[level=15]
setblock 238 283 266 minecraft:light[level=12]
fill 239 283 248 240 285 248 minecraft:gray_concrete
setblock 245 283 231 minecraft:light[level=12]
setblock 245 283 238 minecraft:light[level=12]
setblock 245 283 245 minecraft:light[level=12]
setblock 245 283 252 minecraft:light[level=12]
setblock 245 283 259 minecraft:light[level=12]
setblock 245 283 266 minecraft:light[level=12]
setblock 246 283 231 minecraft:light[level=15]
setblock 246 283 239 minecraft:light[level=15]
setblock 246 283 247 minecraft:light[level=15]
setblock 246 283 255 minecraft:light[level=15]
setblock 246 283 263 minecraft:light[level=15]
setblock 247 283 228 minecraft:ochre_froglight
fill 249 283 264 262 283 269 minecraft:black_concrete
setblock 252 283 231 minecraft:light[level=12]
setblock 252 283 238 minecraft:light[level=12]
setblock 252 283 245 minecraft:light[level=12]
setblock 252 283 252 minecraft:light[level=12]
setblock 252 283 259 minecraft:light[level=12]
setblock 253 283 270 minecraft:pearlescent_froglight
setblock 254 283 231 minecraft:light[level=15]
setblock 254 283 239 minecraft:light[level=15]
setblock 254 283 247 minecraft:light[level=15]
setblock 254 283 255 minecraft:light[level=15]
setblock 254 283 263 minecraft:light[level=15]
setblock 259 283 231 minecraft:light[level=12]
setblock 259 283 238 minecraft:light[level=12]
setblock 259 283 245 minecraft:light[level=12]
setblock 259 283 252 minecraft:light[level=12]
setblock 259 283 259 minecraft:light[level=12]
setblock 261 283 270 minecraft:sea_lantern
setblock 262 283 231 minecraft:light[level=15]
setblock 262 283 239 minecraft:light[level=15]
setblock 262 283 247 minecraft:light[level=15]
setblock 262 283 255 minecraft:light[level=15]
setblock 262 283 263 minecraft:light[level=15]
setblock 266 283 231 minecraft:light[level=12]
setblock 266 283 238 minecraft:light[level=12]
setblock 266 283 245 minecraft:light[level=12]
setblock 266 283 252 minecraft:light[level=12]
setblock 266 283 259 minecraft:light[level=12]
setblock 266 283 266 minecraft:light[level=12]
setblock 270 283 231 minecraft:light[level=15]
setblock 270 283 239 minecraft:light[level=15]
setblock 270 283 247 minecraft:light[level=15]
setblock 270 283 255 minecraft:light[level=15]
setblock 270 283 263 minecraft:light[level=15]
setblock 273 283 231 minecraft:light[level=12]
setblock 273 283 238 minecraft:light[level=12]
setblock 273 283 245 minecraft:light[level=12]
setblock 273 283 252 minecraft:light[level=12]
setblock 273 283 259 minecraft:light[level=12]
setblock 273 283 266 minecraft:light[level=12]
setblock 276 283 270 minecraft:purple_concrete
fill 235 284 229 235 286 229 minecraft:black_concrete
setblock 235 284 230 minecraft:purple_concrete
setblock 235 284 237 minecraft:sea_lantern
fill 235 284 249 235 308 249 minecraft:black_concrete
fill 247 284 228 247 295 228 minecraft:black_concrete
fill 249 284 264 249 284 269 minecraft:verdant_froglight
fill 250 284 264 262 284 264 minecraft:verdant_froglight
fill 250 284 269 262 284 269 minecraft:verdant_froglight
fill 253 284 270 253 299 270 minecraft:black_concrete
setblock 257 284 270 minecraft:sea_lantern
fill 261 284 270 261 308 270 minecraft:black_concrete
fill 262 284 265 262 284 268 minecraft:verdant_froglight
fill 276 284 270 276 308 270 minecraft:black_concrete
setblock 277 284 254 minecraft:cyan_concrete
fill 235 285 230 235 308 230 minecraft:black_concrete
fill 235 285 237 235 308 237 minecraft:black_concrete
fill 257 285 270 257 308 270 minecraft:black_concrete
setblock 258 285 270 minecraft:purple_concrete
setblock 273 285 228 minecraft:sea_lantern
fill 277 285 254 277 308 254 minecraft:black_concrete
setblock 235 286 238 minecraft:sea_lantern
fill 236 286 244 236 300 244 minecraft:gray_concrete
setblock 236 286 245 minecraft:sea_lantern
fill 236 286 246 236 300 246 minecraft:gray_concrete
setblock 236 286 247 minecraft:sea_lantern
fill 236 286 248 236 300 248 minecraft:gray_concrete
setblock 236 286 249 minecraft:sea_lantern
fill 236 286 250 236 300 250 minecraft:gray_concrete
setblock 236 286 251 minecraft:sea_lantern
fill 236 286 252 236 300 252 minecraft:gray_concrete
setblock 237 286 244 minecraft:sea_lantern
fill 237 286 245 237 300 245 minecraft:gray_concrete
setblock 237 286 246 minecraft:sea_lantern
fill 237 286 247 237 300 247 minecraft:gray_concrete
setblock 237 286 248 minecraft:sea_lantern
fill 237 286 249 237 300 249 minecraft:gray_concrete
setblock 237 286 250 minecraft:sea_lantern
fill 237 286 251 237 300 251 minecraft:gray_concrete
setblock 237 286 252 minecraft:sea_lantern
fill 238 286 244 238 300 244 minecraft:gray_concrete
setblock 238 286 245 minecraft:sea_lantern
fill 238 286 246 238 300 246 minecraft:gray_concrete
setblock 238 286 247 minecraft:sea_lantern
setblock 238 286 249 minecraft:sea_lantern
fill 238 286 250 238 300 250 minecraft:gray_concrete
setblock 238 286 251 minecraft:sea_lantern
fill 238 286 252 238 300 252 minecraft:gray_concrete
setblock 239 286 244 minecraft:sea_lantern
fill 239 286 245 239 300 245 minecraft:gray_concrete
setblock 239 286 246 minecraft:sea_lantern
fill 239 286 247 239 300 247 minecraft:gray_concrete
setblock 239 286 248 minecraft:sea_lantern
fill 239 286 249 239 300 249 minecraft:gray_concrete
setblock 239 286 250 minecraft:sea_lantern
fill 239 286 251 239 300 251 minecraft:gray_concrete
setblock 239 286 252 minecraft:sea_lantern
fill 240 286 244 240 300 244 minecraft:gray_concrete
setblock 240 286 245 minecraft:sea_lantern
fill 240 286 246 240 300 246 minecraft:gray_concrete
setblock 240 286 247 minecraft:sea_lantern
fill 240 286 248 240 300 248 minecraft:gray_concrete
setblock 240 286 249 minecraft:sea_lantern
fill 240 286 250 240 300 250 minecraft:gray_concrete
setblock 240 286 251 minecraft:sea_lantern
fill 240 286 252 240 300 252 minecraft:gray_concrete
fill 258 286 270 258 308 270 minecraft:black_concrete
fill 273 286 228 273 308 228 minecraft:black_concrete
setblock 277 286 258 minecraft:ochre_froglight
setblock 235 287 229 minecraft:sea_lantern
fill 235 287 238 235 308 238 minecraft:black_concrete
fill 236 287 245 236 288 245 minecraft:gray_concrete
fill 236 287 247 236 288 247 minecraft:gray_concrete
fill 236 287 249 236 288 249 minecraft:gray_concrete
fill 236 287 251 236 288 251 minecraft:gray_concrete
fill 237 287 244 237 288 244 minecraft:gray_concrete
fill 237 287 246 237 288 246 minecraft:gray_concrete
fill 237 287 248 239 288 248 minecraft:gray_concrete
fill 237 287 250 237 288 250 minecraft:gray_concrete
fill 237 287 252 237 288 252 minecraft:gray_concrete
fill 238 287 245 238 288 245 minecraft:gray_concrete
fill 238 287 247 238 288 247 minecraft:gray_concrete
fill 238 287 249 238 288 249 minecraft:gray_concrete
fill 238 287 251 238 288 251 minecraft:gray_concrete
fill 239 287 244 239 288 244 minecraft:gray_concrete
fill 239 287 246 239 288 246 minecraft:gray_concrete
fill 239 287 250 239 288 250 minecraft:gray_concrete
fill 239 287 252 239 288 252 minecraft:gray_concrete
fill 240 287 245 240 288 245 minecraft:gray_concrete
fill 240 287 247 240 288 247 minecraft:gray_concrete
fill 240 287 249 240 288 249 minecraft:gray_concrete
fill 240 287 251 240 288 251 minecraft:gray_concrete
setblock 277 287 241 minecraft:ochre_froglight
fill 277 287 258 277 308 258 minecraft:black_concrete
fill 235 288 229 235 308 229 minecraft:black_concrete
setblock 277 288 240 minecraft:pearlescent_froglight
fill 277 288 241 277 308 241 minecraft:black_concrete
setblock 235 289 267 minecraft:pearlescent_froglight
setblock 236 289 245 minecraft:sea_lantern
setblock 236 289 247 minecraft:sea_lantern
setblock 236 289 249 minecraft:sea_lantern
setblock 236 289 251 minecraft:sea_lantern
setblock 237 289 244 minecraft:sea_lantern
setblock 237 289 246 minecraft:sea_lantern
setblock 237 289 248 minecraft:sea_lantern
setblock 237 289 250 minecraft:sea_lantern
setblock 237 289 252 minecraft:sea_lantern
setblock 238 289 231 minecraft:light[level=12]
setblock 238 289 238 minecraft:light[level=12]
setblock 238 289 245 minecraft:sea_lantern
setblock 238 289 247 minecraft:sea_lantern
setblock 238 289 248 minecraft:redstone_block
setblock 238 289 249 minecraft:sea_lantern
setblock 238 289 251 minecraft:sea_lantern
setblock 238 289 259 minecraft:light[level=12]
setblock 238 289 266 minecraft:light[level=12]
setblock 239 289 244 minecraft:sea_lantern
setblock 239 289 246 minecraft:sea_lantern
setblock 239 289 248 minecraft:sea_lantern
setblock 239 289 250 minecraft:sea_lantern
setblock 239 289 252 minecraft:sea_lantern
setblock 240 289 245 minecraft:sea_lantern
setblock 240 289 247 minecraft:sea_lantern
setblock 240 289 249 minecraft:sea_lantern
setblock 240 289 251 minecraft:sea_lantern
setblock 241 289 270 minecraft:sea_lantern
setblock 244 289 270 minecraft:cyan_concrete
setblock 245 289 231 minecraft:light[level=12]
setblock 245 289 238 minecraft:light[level=12]
setblock 245 289 245 minecraft:light[level=12]
setblock 245 289 252 minecraft:light[level=12]
setblock 245 289 259 minecraft:light[level=12]
setblock 245 289 266 minecraft:light[level=12]
setblock 252 289 231 minecraft:light[level=12]
setblock 252 289 238 minecraft:light[level=12]
setblock 252 289 245 minecraft:light[level=12]
setblock 252 289 252 minecraft:light[level=12]
setblock 252 289 259 minecraft:light[level=12]
setblock 252 289 266 minecraft:light[level=12]
setblock 259 289 231 minecraft:light[level=12]
setblock 259 289 238 minecraft:light[level=12]
setblock 259 289 245 minecraft:light[level=12]
setblock 259 289 252 minecraft:light[level=12]
setblock 259 289 259 minecraft:light[level=12]
setblock 259 289 266 minecraft:light[level=12]
setblock 260 289 228 minecraft:ochre_froglight
setblock 266 289 231 minecraft:light[level=12]
setblock 266 289 238 minecraft:light[level=12]
setblock 266 289 245 minecraft:light[level=12]
setblock 266 289 252 minecraft:light[level=12]
setblock 266 289 259 minecraft:light[level=12]
setblock 266 289 266 minecraft:light[level=12]
setblock 273 289 231 minecraft:light[level=12]
setblock 273 289 238 minecraft:light[level=12]
setblock 273 289 245 minecraft:light[level=12]
setblock 273 289 252 minecraft:light[level=12]
setblock 273 289 259 minecraft:light[level=12]
setblock 273 289 266 minecraft:light[level=12]
fill 277 289 240 277 308 240 minecraft:black_concrete
setblock 235 290 232 minecraft:magenta_concrete
fill 235 290 267 235 308 267 minecraft:black_concrete
fill 236 290 245 236 291 245 minecraft:gray_concrete
fill 236 290 247 236 291 247 minecraft:gray_concrete
fill 236 290 249 236 291 249 minecraft:gray_concrete
fill 236 290 251 236 291 251 minecraft:gray_concrete
fill 237 290 244 237 291 244 minecraft:gray_concrete
fill 237 290 246 237 291 246 minecraft:gray_concrete
fill 237 290 248 239 291 248 minecraft:gray_concrete
fill 237 290 250 237 291 250 minecraft:gray_concrete
fill 237 290 252 237 291 252 minecraft:gray_concrete
setblock 238 290 231 minecraft:light[level=15]
setblock 238 290 239 minecraft:light[level=15]
fill 238 290 245 238 291 245 minecraft:gray_concrete
fill 238 290 247 238 291 247 minecraft:gray_concrete
fill 238 290 249 238 291 249 minecraft:gray_concrete
fill 238 290 251 238 291 251 minecraft:gray_concrete
setblock 238 290 255 minecraft:light[level=15]
setblock 238 290 263 minecraft:light[level=15]
fill 239 290 244 239 291 244 minecraft:gray_concrete
fill 239 290 246 239 291 246 minecraft:gray_concrete
fill 239 290 250 239 291 250 minecraft:gray_concrete
fill 239 290 252 239 291 252 minecraft:gray_concrete
fill 240 290 245 240 291 245 minecraft:gray_concrete
fill 240 290 247 240 291 247 minecraft:gray_concrete
fill 240 290 249 240 291 249 minecraft:gray_concrete
fill 240 290 251 240 291 251 minecraft:gray_concrete
fill 241 290 270 241 308 270 minecraft:black_concrete
fill 244 290 270 244 308 270 minecraft:black_concrete
setblock 246 290 231 minecraft:light[level=15]
setblock 246 290 239 minecraft:light[level=15]
setblock 246 290 247 minecraft:light[level=15]
setblock 246 290 255 minecraft:light[level=15]
setblock 246 290 263 minecraft:light[level=15]
setblock 254 290 231 minecraft:light[level=15]
setblock 254 290 239 minecraft:light[level=15]
setblock 254 290 247 minecraft:light[level=15]
setblock 254 290 255 minecraft:light[level=15]
setblock 254 290 263 minecraft:light[level=15]
fill 260 290 228 260 308 228 minecraft:black_concrete
setblock 262 290 231 minecraft:light[level=15]
setblock 262 290 239 minecraft:light[level=15]
setblock 262 290 247 minecraft:light[level=15]
setblock 262 290 255 minecraft:light[level=15]
setblock 262 290 263 minecraft:light[level=15]
setblock 270 290 231 minecraft:light[level=15]
setblock 270 290 239 minecraft:light[level=15]
setblock 270 290 247 minecraft:light[level=15]
setblock 270 290 255 minecraft:light[level=15]
setblock 270 290 263 minecraft:light[level=15]
fill 235 291 232 235 308 232 minecraft:black_concrete
setblock 246 291 228 minecraft:blue_concrete
setblock 235 292 252 minecraft:verdant_froglight
setblock 236 292 245 minecraft:sea_lantern
setblock 236 292 247 minecraft:sea_lantern
setblock 236 292 249 minecraft:sea_lantern
setblock 236 292 251 minecraft:sea_lantern
setblock 237 292 244 minecraft:sea_lantern
setblock 237 292 246 minecraft:sea_lantern
setblock 237 292 248 minecraft:sea_lantern
setblock 237 292 250 minecraft:sea_lantern
setblock 237 292 252 minecraft:sea_lantern
setblock 238 292 245 minecraft:sea_lantern
setblock 238 292 247 minecraft:sea_lantern
fill 238 292 248 238 300 248 minecraft:gray_concrete
setblock 238 292 249 minecraft:sea_lantern
setblock 238 292 251 minecraft:sea_lantern
setblock 239 292 244 minecraft:sea_lantern
setblock 239 292 246 minecraft:sea_lantern
setblock 239 292 248 minecraft:sea_lantern
setblock 239 292 250 minecraft:sea_lantern
setblock 239 292 252 minecraft:sea_lantern
setblock 240 292 245 minecraft:sea_lantern
setblock 240 292 247 minecraft:sea_lantern
setblock 240 292 249 minecraft:sea_lantern
setblock 240 292 251 minecraft:sea_lantern
fill 246 292 228 246 308 228 minecraft:black_concrete
fill 235 293 252 235 308 252 minecraft:black_concrete
fill 236 293 245 236 294 245 minecraft:gray_concrete
fill 236 293 247 236 294 247 minecraft:gray_concrete
fill 236 293 249 236 294 249 minecraft:gray_concrete
fill 236 293 251 236 294 251 minecraft:gray_concrete
fill 237 293 244 237 294 244 minecraft:gray_concrete
fill 237 293 246 237 294 246 minecraft:gray_concrete
fill 237 293 248 237 294 248 minecraft:gray_concrete
fill 237 293 250 237 294 250 minecraft:gray_concrete
fill 237 293 252 237 294 252 minecraft:gray_concrete
fill 238 293 245 238 294 245 minecraft:gray_concrete
fill 238 293 247 238 294 247 minecraft:gray_concrete
fill 238 293 249 238 294 249 minecraft:gray_concrete
fill 238 293 251 238 294 251 minecraft:gray_concrete
fill 239 293 244 239 294 244 minecraft:gray_concrete
fill 239 293 246 239 294 246 minecraft:gray_concrete
fill 239 293 248 239 294 248 minecraft:gray_concrete
fill 239 293 250 239 294 250 minecraft:gray_concrete
fill 239 293 252 239 294 252 minecraft:gray_concrete
fill 240 293 245 240 294 245 minecraft:gray_concrete
fill 240 293 247 240 294 247 minecraft:gray_concrete
fill 240 293 249 240 294 249 minecraft:gray_concrete
fill 240 293 251 240 294 251 minecraft:gray_concrete
setblock 235 294 234 minecraft:pearlescent_froglight
setblock 246 294 270 minecraft:sea_lantern
setblock 252 294 270 minecraft:magenta_concrete
setblock 277 294 237 minecraft:ochre_froglight
setblock 277 294 257 minecraft:purple_concrete
setblock 277 294 267 minecraft:blue_concrete
fill 235 295 234 235 305 234 minecraft:black_concrete
setblock 236 295 245 minecraft:sea_lantern
setblock 236 295 247 minecraft:sea_lantern
setblock 236 295 249 minecraft:sea_lantern
setblock 236 295 251 minecraft:sea_lantern
setblock 237 295 244 minecraft:sea_lantern
setblock 237 295 246 minecraft:sea_lantern
setblock 237 295 248 minecraft:sea_lantern
setblock 237 295 250 minecraft:sea_lantern
setblock 237 295 252 minecraft:sea_lantern
setblock 238 295 231 minecraft:light[level=12]
setblock 238 295 238 minecraft:light[level=12]
setblock 238 295 245 minecraft:sea_lantern
setblock 238 295 247 minecraft:sea_lantern
setblock 238 295 249 minecraft:sea_lantern
setblock 238 295 251 minecraft:sea_lantern
setblock 238 295 259 minecraft:light[level=12]
setblock 238 295 266 minecraft:light[level=12]
setblock 239 295 244 minecraft:sea_lantern
setblock 239 295 246 minecraft:sea_lantern
setblock 239 295 248 minecraft:sea_lantern
setblock 239 295 250 minecraft:sea_lantern
setblock 239 295 252 minecraft:sea_lantern
setblock 240 295 245 minecraft:sea_lantern
setblock 240 295 247 minecraft:sea_lantern
setblock 240 295 249 minecraft:sea_lantern
setblock 240 295 251 minecraft:sea_lantern
setblock 243 295 270 minecraft:purple_concrete
setblock 245 295 231 minecraft:light[level=12]
setblock 245 295 238 minecraft:light[level=12]
setblock 245 295 245 minecraft:light[level=12]
setblock 245 295 252 minecraft:light[level=12]
setblock 245 295 259 minecraft:light[level=12]
setblock 245 295 266 minecraft:light[level=12]
fill 246 295 270 246 308 270 minecraft:black_concrete
setblock 252 295 231 minecraft:light[level=12]
setblock 252 295 238 minecraft:light[level=12]
setblock 252 295 245 minecraft:light[level=12]
setblock 252 295 252 minecraft:light[level=12]
setblock 252 295 259 minecraft:light[level=12]
setblock 252 295 266 minecraft:light[level=12]
fill 252 295 270 252 308 270 minecraft:black_concrete
setblock 259 295 231 minecraft:light[level=12]
setblock 259 295 238 minecraft:light[level=12]
setblock 259 295 245 minecraft:light[level=12]
setblock 259 295 252 minecraft:light[level=12]
setblock 259 295 259 minecraft:light[level=12]
setblock 259 295 266 minecraft:light[level=12]
setblock 266 295 231 minecraft:light[level=12]
setblock 266 295 238 minecraft:light[level=12]
setblock 266 295 245 minecraft:light[level=12]
setblock 266 295 252 minecraft:light[level=12]
setblock 266 295 259 minecraft:light[level=12]
setblock 266 295 266 minecraft:light[level=12]
setblock 273 295 231 minecraft:light[level=12]
setblock 273 295 238 minecraft:light[level=12]
setblock 273 295 245 minecraft:light[level=12]
setblock 273 295 252 minecraft:light[level=12]
setblock 273 295 259 minecraft:light[level=12]
setblock 273 295 266 minecraft:light[level=12]
fill 277 295 237 277 308 237 minecraft:black_concrete
fill 277 295 257 277 308 257 minecraft:black_concrete
fill 277 295 267 277 308 267 minecraft:black_concrete
fill 236 296 245 236 297 245 minecraft:gray_concrete
fill 236 296 247 236 297 247 minecraft:gray_concrete
fill 236 296 249 236 297 249 minecraft:gray_concrete
fill 236 296 251 236 297 251 minecraft:gray_concrete
fill 237 296 244 237 297 244 minecraft:gray_concrete
fill 237 296 246 237 297 246 minecraft:gray_concrete
fill 237 296 248 237 297 248 minecraft:gray_concrete
fill 237 296 250 237 297 250 minecraft:gray_concrete
fill 237 296 252 237 297 252 minecraft:gray_concrete
fill 238 296 245 238 297 245 minecraft:gray_concrete
fill 238 296 247 238 297 247 minecraft:gray_concrete
fill 238 296 249 238 297 249 minecraft:gray_concrete
fill 238 296 251 238 297 251 minecraft:gray_concrete
fill 239 296 244 239 297 244 minecraft:gray_concrete
fill 239 296 246 239 297 246 minecraft:gray_concrete
fill 239 296 248 239 297 248 minecraft:gray_concrete
fill 239 296 250 239 297 250 minecraft:gray_concrete
fill 239 296 252 239 297 252 minecraft:gray_concrete
fill 240 296 245 240 297 245 minecraft:gray_concrete
fill 240 296 247 240 297 247 minecraft:gray_concrete
fill 240 296 249 240 297 249 minecraft:gray_concrete
fill 240 296 251 240 297 251 minecraft:gray_concrete
fill 243 296 270 243 308 270 minecraft:black_concrete
setblock 247 296 228 minecraft:verdant_froglight
setblock 277 296 264 minecraft:sea_lantern
fill 237 297 229 237 298 231 minecraft:iron_block
setblock 238 297 231 minecraft:light[level=15]
setblock 238 297 239 minecraft:light[level=15]
setblock 238 297 255 minecraft:light[level=15]
setblock 238 297 263 minecraft:light[level=15]
setblock 246 297 231 minecraft:light[level=15]
setblock 246 297 239 minecraft:light[level=15]
setblock 246 297 247 minecraft:light[level=15]
setblock 246 297 255 minecraft:light[level=15]
setblock 246 297 263 minecraft:light[level=15]
fill 247 297 228 247 308 228 minecraft:black_concrete
setblock 254 297 231 minecraft:light[level=15]
setblock 254 297 239 minecraft:light[level=15]
setblock 254 297 247 minecraft:light[level=15]
setblock 254 297 255 minecraft:light[level=15]
setblock 254 297 263 minecraft:light[level=15]
setblock 262 297 228 minecraft:sea_lantern
setblock 262 297 231 minecraft:light[level=15]
setblock 262 297 239 minecraft:light[level=15]
setblock 262 297 247 minecraft:light[level=15]
setblock 262 297 255 minecraft:light[level=15]
setblock 262 297 263 minecraft:light[level=15]
setblock 268 297 228 minecraft:pearlescent_froglight
setblock 270 297 231 minecraft:light[level=15]
setblock 270 297 239 minecraft:light[level=15]
setblock 270 297 247 minecraft:light[level=15]
setblock 270 297 255 minecraft:light[level=15]
setblock 270 297 263 minecraft:light[level=15]
setblock 272 297 270 minecraft:pearlescent_froglight
fill 277 297 264 277 308 264 minecraft:black_concrete
setblock 236 298 245 minecraft:sea_lantern
setblock 236 298 247 minecraft:sea_lantern
setblock 236 298 249 minecraft:sea_lantern
setblock 236 298 251 minecraft:sea_lantern
setblock 237 298 244 minecraft:sea_lantern
setblock 237 298 246 minecraft:sea_lantern
setblock 237 298 248 minecraft:sea_lantern
setblock 237 298 250 minecraft:sea_lantern
setblock 237 298 252 minecraft:sea_lantern
setblock 238 298 245 minecraft:sea_lantern
setblock 238 298 247 minecraft:sea_lantern
setblock 238 298 249 minecraft:sea_lantern
setblock 238 298 251 minecraft:sea_lantern
setblock 239 298 244 minecraft:sea_lantern
setblock 239 298 246 minecraft:sea_lantern
setblock 239 298 248 minecraft:sea_lantern
setblock 239 298 250 minecraft:sea_lantern
setblock 239 298 252 minecraft:sea_lantern
setblock 240 298 245 minecraft:sea_lantern
setblock 240 298 247 minecraft:sea_lantern
setblock 240 298 249 minecraft:sea_lantern
setblock 240 298 251 minecraft:sea_lantern
fill 262 298 228 262 308 228 minecraft:black_concrete
fill 268 298 228 268 308 228 minecraft:black_concrete
fill 272 298 270 272 301 270 minecraft:black_concrete
setblock 277 298 255 minecraft:sea_lantern
fill 236 299 245 236 300 245 minecraft:gray_concrete
fill 236 299 247 236 300 247 minecraft:gray_concrete
fill 236 299 249 236 300 249 minecraft:gray_concrete
fill 236 299 251 236 300 251 minecraft:gray_concrete
fill 237 299 244 237 300 244 minecraft:gray_concrete
fill 237 299 246 237 300 246 minecraft:gray_concrete
fill 237 299 248 237 300 248 minecraft:gray_concrete
fill 237 299 250 237 300 250 minecraft:gray_concrete
fill 237 299 252 237 300 252 minecraft:gray_concrete
fill 238 299 245 238 300 245 minecraft:gray_concrete
fill 238 299 247 238 300 247 minecraft:gray_concrete
fill 238 299 249 238 300 249 minecraft:gray_concrete
fill 238 299 251 238 300 251 minecraft:gray_concrete
fill 239 299 244 239 300 244 minecraft:gray_concrete
fill 239 299 246 239 300 246 minecraft:gray_concrete
fill 239 299 248 239 300 248 minecraft:gray_concrete
fill 239 299 250 239 300 250 minecraft:gray_concrete
fill 239 299 252 239 300 252 minecraft:gray_concrete
fill 240 299 245 240 300 245 minecraft:gray_concrete
fill 240 299 247 240 300 247 minecraft:gray_concrete
fill 240 299 249 240 300 249 minecraft:gray_concrete
fill 240 299 251 240 300 251 minecraft:gray_concrete
setblock 266 299 270 minecraft:verdant_froglight
setblock 271 299 228 minecraft:purple_concrete
setblock 272 299 228 minecraft:cyan_concrete
setblock 277 299 251 minecraft:magenta_concrete
fill 277 299 255 277 308 255 minecraft:black_concrete
setblock 253 300 270 minecraft:verdant_froglight
setblock 254 300 270 minecraft:pearlescent_froglight
setblock 264 300 228 minecraft:blue_concrete
fill 266 300 270 266 308 270 minecraft:black_concrete
fill 271 300 228 272 308 228 minecraft:black_concrete
fill 277 300 251 277 308 251 minecraft:black_concrete
setblock 235 301 264 minecraft:ochre_froglight
setblock 238 301 231 minecraft:light[level=12]
setblock 238 301 238 minecraft:light[level=12]
setblock 238 301 245 minecraft:light[level=12]
setblock 238 301 252 minecraft:light[level=12]
setblock 238 301 259 minecraft:light[level=12]
setblock 238 301 266 minecraft:light[level=12]
setblock 245 301 231 minecraft:light[level=12]
setblock 245 301 238 minecraft:light[level=12]
setblock 245 301 245 minecraft:light[level=12]
setblock 245 301 252 minecraft:light[level=12]
setblock 245 301 259 minecraft:light[level=12]
setblock 245 301 266 minecraft:light[level=12]
setblock 252 301 231 minecraft:light[level=12]
setblock 252 301 238 minecraft:light[level=12]
setblock 252 301 245 minecraft:light[level=12]
setblock 252 301 252 minecraft:light[level=12]
setblock 252 301 259 minecraft:light[level=12]
setblock 252 301 266 minecraft:light[level=12]
fill 253 301 270 254 308 270 minecraft:black_concrete
setblock 259 301 231 minecraft:light[level=12]
setblock 259 301 238 minecraft:light[level=12]
setblock 259 301 245 minecraft:light[level=12]
setblock 259 301 252 minecraft:light[level=12]
setblock 259 301 259 minecraft:light[level=12]
setblock 259 301 266 minecraft:light[level=12]
fill 264 301 228 264 308 228 minecraft:black_concrete
setblock 266 301 231 minecraft:light[level=12]
setblock 266 301 238 minecraft:light[level=12]
setblock 266 301 245 minecraft:light[level=12]
setblock 266 301 252 minecraft:light[level=12]
setblock 266 301 259 minecraft:light[level=12]
setblock 266 301 266 minecraft:light[level=12]
setblock 273 301 231 minecraft:light[level=12]
setblock 273 301 238 minecraft:light[level=12]
setblock 273 301 245 minecraft:light[level=12]
setblock 273 301 252 minecraft:light[level=12]
setblock 273 301 259 minecraft:light[level=12]
setblock 273 301 266 minecraft:light[level=12]
fill 235 302 264 235 308 264 minecraft:black_concrete
setblock 272 302 270 minecraft:magenta_concrete
setblock 256 303 270 minecraft:pearlescent_froglight
fill 272 303 270 272 308 270 minecraft:black_concrete
fill 256 304 270 256 308 270 minecraft:black_concrete
setblock 267 304 270 minecraft:pearlescent_froglight
setblock 235 305 253 minecraft:ochre_froglight
setblock 240 305 270 minecraft:pearlescent_froglight
fill 267 305 270 267 308 270 minecraft:black_concrete
setblock 277 305 259 minecraft:purple_concrete
setblock 235 306 234 minecraft:verdant_froglight
fill 235 306 253 235 308 253 minecraft:black_concrete
setblock 235 306 257 minecraft:cyan_concrete
fill 240 306 270 240 308 270 minecraft:black_concrete
setblock 277 306 247 minecraft:magenta_concrete
fill 277 306 259 277 308 259 minecraft:black_concrete
fill 235 307 234 235 308 234 minecraft:black_concrete
fill 235 307 257 235 308 257 minecraft:black_concrete
fill 277 307 247 277 308 247 minecraft:black_concrete
setblock 235 308 251 minecraft:purple_concrete
setblock 235 308 268 minecraft:magenta_concrete
setblock 240 308 228 minecraft:purple_concrete
