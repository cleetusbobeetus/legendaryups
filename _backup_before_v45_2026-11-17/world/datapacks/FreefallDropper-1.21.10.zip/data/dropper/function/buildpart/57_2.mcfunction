setblock 433 174 259 minecraft:light[level=12]
setblock 433 174 266 minecraft:light[level=12]
setblock 440 174 231 minecraft:light[level=12]
setblock 440 174 238 minecraft:light[level=12]
setblock 440 174 245 minecraft:light[level=12]
setblock 440 174 252 minecraft:light[level=12]
setblock 440 174 259 minecraft:light[level=12]
setblock 440 174 266 minecraft:light[level=12]
fill 442 174 270 442 228 270 minecraft:black_concrete
setblock 447 174 231 minecraft:light[level=12]
setblock 447 174 238 minecraft:light[level=12]
setblock 447 174 245 minecraft:light[level=12]
setblock 447 174 252 minecraft:light[level=12]
setblock 447 174 259 minecraft:light[level=12]
setblock 447 174 266 minecraft:light[level=12]
fill 448 174 228 448 181 228 minecraft:black_concrete
setblock 450 174 270 minecraft:purple_terracotta
setblock 454 174 231 minecraft:light[level=12]
setblock 454 174 238 minecraft:light[level=12]
setblock 454 174 245 minecraft:light[level=12]
setblock 454 174 252 minecraft:light[level=12]
setblock 454 174 259 minecraft:light[level=12]
setblock 454 174 266 minecraft:light[level=12]
fill 456 174 248 456 175 249 minecraft:gray_concrete
fill 456 174 252 456 175 252 minecraft:gray_concrete
fill 457 174 247 457 175 247 minecraft:gray_concrete
fill 457 174 253 457 175 253 minecraft:gray_concrete
fill 458 174 246 459 175 246 minecraft:gray_concrete
fill 458 174 254 458 175 254 minecraft:gray_concrete
setblock 461 174 231 minecraft:light[level=12]
setblock 461 174 238 minecraft:light[level=12]
setblock 461 174 245 minecraft:light[level=12]
setblock 461 174 259 minecraft:light[level=12]
setblock 461 174 266 minecraft:light[level=12]
setblock 461 174 270 minecraft:magenta_terracotta
fill 462 174 246 462 175 246 minecraft:gray_concrete
fill 462 174 254 462 175 254 minecraft:gray_concrete
setblock 464 174 228 minecraft:white_concrete
fill 464 174 248 464 175 248 minecraft:gray_concrete
fill 464 174 252 464 175 252 minecraft:gray_concrete
fill 465 174 269 465 195 269 minecraft:black_concrete
fill 423 175 231 423 192 231 minecraft:black_concrete
setblock 423 175 236 minecraft:white_concrete
setblock 437 175 228 minecraft:white_concrete
fill 450 175 270 450 208 270 minecraft:black_concrete
setblock 452 175 228 minecraft:white_concrete
fill 455 175 250 455 175 251 minecraft:gray_concrete
setblock 456 175 247 minecraft:gray_concrete
setblock 456 175 253 minecraft:gray_concrete
setblock 457 175 246 minecraft:gray_concrete
setblock 457 175 254 minecraft:gray_concrete
fill 459 175 255 461 175 255 minecraft:gray_concrete
fill 460 175 245 461 175 245 minecraft:gray_concrete
fill 461 175 270 461 224 270 minecraft:black_concrete
setblock 463 175 246 minecraft:gray_concrete
setblock 463 175 254 minecraft:gray_concrete
fill 464 175 228 464 232 228 minecraft:black_concrete
setblock 464 175 247 minecraft:gray_concrete
setblock 464 175 253 minecraft:gray_concrete
setblock 465 175 230 minecraft:ochre_froglight
fill 423 176 236 423 179 236 minecraft:black_concrete
setblock 423 176 253 minecraft:white_concrete
fill 437 176 228 437 202 228 minecraft:black_concrete
setblock 439 176 270 minecraft:ochre_froglight
fill 450 176 263 450 177 263 minecraft:pearlescent_froglight
fill 452 176 228 452 230 228 minecraft:black_concrete
fill 459 176 250 461 176 250 minecraft:pearlescent_froglight
setblock 460 176 249 minecraft:pearlescent_froglight
fill 460 176 251 461 176 251 minecraft:pearlescent_froglight
fill 465 176 230 465 208 230 minecraft:black_concrete
fill 423 177 253 423 289 253 minecraft:black_concrete
setblock 426 177 231 minecraft:light[level=15]
setblock 426 177 239 minecraft:light[level=15]
setblock 426 177 247 minecraft:light[level=15]
setblock 426 177 255 minecraft:light[level=15]
setblock 426 177 263 minecraft:light[level=15]
setblock 434 177 231 minecraft:light[level=15]
setblock 434 177 239 minecraft:light[level=15]
setblock 434 177 247 minecraft:light[level=15]
setblock 434 177 255 minecraft:light[level=15]
setblock 434 177 263 minecraft:light[level=15]
fill 437 177 260 438 178 260 minecraft:gray_concrete
fill 438 177 259 438 178 259 minecraft:gray_concrete
fill 439 177 270 439 186 270 minecraft:black_concrete
setblock 442 177 231 minecraft:light[level=15]
setblock 442 177 239 minecraft:light[level=15]
setblock 442 177 247 minecraft:light[level=15]
setblock 442 177 255 minecraft:light[level=15]
setblock 442 177 263 minecraft:light[level=15]
setblock 450 177 231 minecraft:light[level=15]
setblock 450 177 239 minecraft:light[level=15]
setblock 450 177 247 minecraft:light[level=15]
setblock 450 177 255 minecraft:light[level=15]
setblock 458 177 231 minecraft:light[level=15]
setblock 458 177 239 minecraft:light[level=15]
setblock 458 177 247 minecraft:light[level=15]
setblock 458 177 255 minecraft:light[level=15]
setblock 458 177 263 minecraft:light[level=15]
fill 460 177 250 460 177 251 minecraft:pearlescent_froglight
setblock 461 177 250 minecraft:pearlescent_froglight
setblock 465 177 254 minecraft:purple_terracotta
setblock 465 177 257 minecraft:sea_lantern
setblock 427 178 228 minecraft:sea_lantern
fill 450 178 263 450 186 263 minecraft:gray_concrete
fill 460 178 250 460 180 250 minecraft:pearlescent_froglight
fill 465 178 234 465 179 234 minecraft:white_concrete
fill 465 178 254 465 308 254 minecraft:black_concrete
fill 465 178 257 465 196 257 minecraft:black_concrete
fill 465 178 264 465 201 264 minecraft:black_concrete
setblock 465 178 265 minecraft:purple_terracotta
setblock 424 179 228 minecraft:purple_terracotta
fill 427 179 228 427 203 228 minecraft:black_concrete
setblock 428 179 270 minecraft:magenta_terracotta
setblock 444 179 228 minecraft:ochre_froglight
setblock 451 179 270 minecraft:white_concrete
setblock 465 179 250 minecraft:pearlescent_froglight
fill 465 179 265 465 182 265 minecraft:black_concrete
setblock 423 180 236 minecraft:pearlescent_froglight
setblock 423 180 254 minecraft:white_concrete
setblock 423 180 260 minecraft:sea_lantern
setblock 423 180 265 minecraft:pearlescent_froglight
setblock 423 180 269 minecraft:magenta_terracotta
fill 424 180 228 424 209 228 minecraft:black_concrete
setblock 425 180 228 minecraft:white_concrete
setblock 426 180 231 minecraft:light[level=12]
setblock 426 180 238 minecraft:light[level=12]
setblock 426 180 245 minecraft:light[level=12]
setblock 426 180 252 minecraft:light[level=12]
setblock 426 180 259 minecraft:light[level=12]
setblock 426 180 266 minecraft:light[level=12]
fill 428 180 270 428 201 270 minecraft:black_concrete
setblock 430 180 270 minecraft:ochre_froglight
setblock 433 180 231 minecraft:light[level=12]
setblock 433 180 238 minecraft:light[level=12]
setblock 433 180 245 minecraft:light[level=12]
setblock 433 180 252 minecraft:light[level=12]
setblock 433 180 259 minecraft:light[level=12]
setblock 433 180 266 minecraft:light[level=12]
setblock 440 180 231 minecraft:light[level=12]
setblock 440 180 238 minecraft:light[level=12]
setblock 440 180 245 minecraft:light[level=12]
setblock 440 180 252 minecraft:light[level=12]
setblock 440 180 259 minecraft:light[level=12]
setblock 440 180 266 minecraft:light[level=12]
fill 444 180 228 444 194 228 minecraft:black_concrete
setblock 447 180 231 minecraft:light[level=12]
setblock 447 180 238 minecraft:light[level=12]
setblock 447 180 245 minecraft:light[level=12]
setblock 447 180 252 minecraft:light[level=12]
setblock 447 180 259 minecraft:light[level=12]
setblock 447 180 266 minecraft:light[level=12]
fill 450 180 262 450 186 262 minecraft:gray_concrete
fill 450 180 264 450 186 264 minecraft:gray_concrete
fill 451 180 263 451 186 263 minecraft:gray_concrete
fill 451 180 270 451 216 270 minecraft:black_concrete
setblock 454 180 231 minecraft:light[level=12]
setblock 454 180 238 minecraft:light[level=12]
setblock 454 180 245 minecraft:light[level=12]
setblock 454 180 252 minecraft:light[level=12]
setblock 454 180 259 minecraft:light[level=12]
setblock 454 180 266 minecraft:light[level=12]
setblock 454 180 270 minecraft:pearlescent_froglight
setblock 461 180 231 minecraft:light[level=12]
setblock 461 180 238 minecraft:light[level=12]
setblock 461 180 245 minecraft:light[level=12]
setblock 461 180 252 minecraft:light[level=12]
setblock 461 180 259 minecraft:light[level=12]
setblock 461 180 266 minecraft:light[level=12]
fill 465 180 234 465 228 234 minecraft:black_concrete
setblock 465 180 245 minecraft:sea_lantern
setblock 465 180 250 minecraft:black_concrete
setblock 465 180 256 minecraft:white_concrete
setblock 423 181 236 minecraft:black_concrete
fill 423 181 254 423 250 254 minecraft:black_concrete
fill 423 181 260 423 203 260 minecraft:black_concrete
fill 423 181 265 423 201 265 minecraft:black_concrete
setblock 423 181 269 minecraft:black_concrete
fill 425 181 228 425 209 228 minecraft:black_concrete
fill 430 181 270 430 219 270 minecraft:black_concrete
setblock 437 181 270 minecraft:pearlescent_froglight
setblock 439 181 228 minecraft:sea_lantern
setblock 447 181 270 minecraft:sea_lantern
fill 449 181 262 449 186 264 minecraft:gray_concrete
setblock 449 181 270 minecraft:sea_lantern
fill 451 181 262 451 186 262 minecraft:gray_concrete
fill 451 181 264 451 186 264 minecraft:gray_concrete
setblock 454 181 270 minecraft:purple_concrete
fill 465 181 245 465 215 245 minecraft:black_concrete
setblock 465 181 250 minecraft:white_concrete
fill 465 181 256 465 217 256 minecraft:black_concrete
setblock 423 182 236 minecraft:sea_lantern
setblock 423 182 269 minecraft:white_concrete
fill 424 182 241 430 182 241 minecraft:gray_concrete
fill 426 182 239 430 183 240 minecraft:gray_concrete
fill 426 182 242 430 183 243 minecraft:gray_concrete
fill 437 182 270 437 185 270 minecraft:black_concrete
fill 439 182 228 439 196 228 minecraft:black_concrete
fill 447 182 270 447 214 270 minecraft:black_concrete
setblock 448 182 228 minecraft:blue_concrete
fill 449 182 270 449 191 270 minecraft:black_concrete
fill 450 182 261 450 186 261 minecraft:gray_concrete
fill 450 182 265 450 186 265 minecraft:gray_concrete
fill 452 182 263 452 186 263 minecraft:gray_concrete
fill 454 182 270 454 239 270 minecraft:black_concrete
setblock 462 182 270 minecraft:magenta_terracotta
fill 465 182 250 465 184 250 minecraft:black_concrete
fill 423 183 236 423 208 236 minecraft:black_concrete
fill 423 183 269 423 224 269 minecraft:black_concrete
fill 424 183 261 430 183 261 minecraft:gray_concrete
fill 426 183 241 430 183 241 minecraft:gray_concrete
fill 426 183 259 430 184 260 minecraft:gray_concrete
fill 426 183 262 430 184 263 minecraft:gray_concrete
fill 448 183 228 448 219 228 minecraft:black_concrete
fill 448 183 262 448 186 264 minecraft:gray_concrete
fill 449 183 261 449 186 261 minecraft:gray_concrete
fill 449 183 265 449 186 265 minecraft:gray_concrete
fill 451 183 261 451 186 261 minecraft:gray_concrete
fill 451 183 265 451 186 265 minecraft:gray_concrete
fill 452 183 262 452 186 262 minecraft:gray_concrete
fill 452 183 264 452 186 264 minecraft:gray_concrete
setblock 453 183 228 minecraft:sea_lantern
setblock 459 183 228 minecraft:pearlescent_froglight
fill 462 183 270 462 308 270 minecraft:black_concrete
setblock 465 183 238 minecraft:ochre_froglight
setblock 465 183 247 minecraft:white_concrete
setblock 465 183 265 minecraft:purple_concrete
fill 425 184 261 425 185 261 minecraft:orange_concrete
setblock 425 184 270 minecraft:magenta_terracotta
setblock 426 184 231 minecraft:light[level=15]
setblock 426 184 239 minecraft:light[level=15]
setblock 426 184 247 minecraft:light[level=15]
setblock 426 184 255 minecraft:light[level=15]
fill 426 184 261 430 184 261 minecraft:gray_concrete
fill 428 184 258 428 185 258 minecraft:orange_concrete
fill 428 184 264 428 185 264 minecraft:orange_concrete
fill 431 184 261 431 185 261 minecraft:orange_concrete
setblock 434 184 231 minecraft:light[level=15]
setblock 434 184 239 minecraft:light[level=15]
setblock 434 184 247 minecraft:light[level=15]
setblock 434 184 255 minecraft:light[level=15]
setblock 434 184 263 minecraft:light[level=15]
setblock 442 184 231 minecraft:light[level=15]
setblock 442 184 239 minecraft:light[level=15]
setblock 442 184 247 minecraft:light[level=15]
setblock 442 184 255 minecraft:light[level=15]
setblock 442 184 263 minecraft:light[level=15]
fill 448 184 261 448 186 261 minecraft:gray_concrete
fill 448 184 265 448 186 265 minecraft:gray_concrete
setblock 450 184 231 minecraft:light[level=15]
setblock 450 184 239 minecraft:light[level=15]
setblock 450 184 247 minecraft:light[level=15]
setblock 450 184 255 minecraft:light[level=15]
fill 450 184 260 450 186 260 minecraft:gray_concrete
fill 452 184 261 452 186 261 minecraft:gray_concrete
fill 452 184 265 452 186 265 minecraft:gray_concrete
fill 453 184 228 453 241 228 minecraft:black_concrete
fill 453 184 263 453 186 263 minecraft:gray_concrete
setblock 458 184 231 minecraft:light[level=15]
setblock 458 184 239 minecraft:light[level=15]
setblock 458 184 247 minecraft:light[level=15]
setblock 458 184 255 minecraft:light[level=15]
setblock 458 184 263 minecraft:light[level=15]
fill 459 184 228 459 191 228 minecraft:black_concrete
fill 465 184 238 465 239 238 minecraft:black_concrete
fill 465 184 247 465 202 247 minecraft:black_concrete
setblock 465 184 253 minecraft:ochre_froglight
fill 465 184 265 465 236 265 minecraft:black_concrete
setblock 423 185 235 minecraft:purple_concrete
setblock 423 185 252 minecraft:magenta_terracotta
fill 425 185 270 425 251 270 minecraft:black_concrete
fill 427 185 260 429 193 262 minecraft:light_gray_concrete
fill 428 185 241 428 192 241 minecraft:orange_concrete
setblock 432 185 228 minecraft:pearlescent_froglight
setblock 438 185 228 minecraft:sea_lantern
fill 447 185 262 447 186 264 minecraft:gray_concrete
fill 449 185 260 449 186 260 minecraft:gray_concrete
fill 449 185 266 451 186 266 minecraft:gray_concrete
fill 451 185 260 451 186 260 minecraft:gray_concrete
fill 453 185 261 453 186 262 minecraft:gray_concrete
fill 453 185 264 453 186 264 minecraft:gray_concrete
setblock 453 185 270 minecraft:white_concrete
setblock 455 185 270 minecraft:ochre_froglight
setblock 465 185 248 minecraft:ochre_froglight
setblock 465 185 250 minecraft:purple_concrete
fill 465 185 253 465 231 253 minecraft:black_concrete
fill 423 186 235 423 195 235 minecraft:black_concrete
fill 423 186 252 423 242 252 minecraft:black_concrete
setblock 426 186 231 minecraft:light[level=12]
setblock 426 186 238 minecraft:light[level=12]
fill 426 186 240 427 191 242 minecraft:orange_concrete
setblock 426 186 245 minecraft:light[level=12]
setblock 426 186 252 minecraft:light[level=12]
setblock 426 186 259 minecraft:light[level=12]
fill 426 186 261 426 187 261 minecraft:orange_concrete
setblock 426 186 266 minecraft:light[level=12]
fill 427 186 239 429 191 239 minecraft:orange_concrete
fill 427 186 243 429 191 243 minecraft:orange_concrete
fill 428 186 240 430 191 240 minecraft:orange_concrete
fill 428 186 242 430 191 242 minecraft:orange_concrete
fill 428 186 259 428 187 259 minecraft:orange_concrete
fill 428 186 263 428 187 263 minecraft:orange_concrete
fill 429 186 241 430 191 241 minecraft:orange_concrete
fill 430 186 261 430 187 261 minecraft:orange_concrete
fill 432 186 228 432 193 228 minecraft:black_concrete
setblock 433 186 231 minecraft:light[level=12]
setblock 433 186 238 minecraft:light[level=12]
setblock 433 186 245 minecraft:light[level=12]
setblock 433 186 252 minecraft:light[level=12]
setblock 433 186 259 minecraft:light[level=12]
setblock 433 186 266 minecraft:light[level=12]
setblock 433 186 270 minecraft:purple_terracotta
setblock 437 186 270 minecraft:sea_lantern
fill 438 186 228 438 189 228 minecraft:black_concrete
setblock 440 186 231 minecraft:light[level=12]
setblock 440 186 238 minecraft:light[level=12]
setblock 440 186 245 minecraft:light[level=12]
setblock 440 186 252 minecraft:light[level=12]
setblock 440 186 259 minecraft:light[level=12]
setblock 440 186 266 minecraft:light[level=12]
setblock 443 186 270 minecraft:white_concrete
setblock 447 186 231 minecraft:light[level=12]
setblock 447 186 238 minecraft:light[level=12]
setblock 447 186 245 minecraft:light[level=12]
setblock 447 186 252 minecraft:light[level=12]
setblock 447 186 259 minecraft:light[level=12]
setblock 447 186 261 minecraft:gray_concrete
setblock 447 186 265 minecraft:gray_concrete
setblock 447 186 266 minecraft:light[level=12]
setblock 448 186 260 minecraft:gray_concrete
setblock 448 186 266 minecraft:gray_concrete
setblock 452 186 260 minecraft:gray_concrete
setblock 452 186 266 minecraft:gray_concrete
setblock 453 186 265 minecraft:gray_concrete
setblock 453 186 270 minecraft:black_concrete
setblock 454 186 231 minecraft:light[level=12]
setblock 454 186 238 minecraft:light[level=12]
setblock 454 186 245 minecraft:light[level=12]
setblock 454 186 252 minecraft:light[level=12]
setblock 454 186 259 minecraft:light[level=12]
setblock 454 186 263 minecraft:gray_concrete
setblock 454 186 266 minecraft:light[level=12]
fill 455 186 270 455 257 270 minecraft:black_concrete
setblock 461 186 231 minecraft:light[level=12]
setblock 461 186 238 minecraft:light[level=12]
setblock 461 186 245 minecraft:light[level=12]
setblock 461 186 252 minecraft:light[level=12]
setblock 461 186 259 minecraft:light[level=12]
setblock 461 186 266 minecraft:light[level=12]
setblock 465 186 246 minecraft:sea_lantern
fill 465 186 248 465 242 248 minecraft:black_concrete
fill 465 186 250 465 254 250 minecraft:black_concrete
fill 465 186 261 465 213 261 minecraft:black_concrete
setblock 465 186 262 minecraft:blue_concrete
setblock 423 187 268 minecraft:white_concrete
fill 425 187 240 425 190 242 minecraft:orange_concrete
fill 426 187 239 426 190 239 minecraft:orange_concrete
fill 426 187 243 426 190 243 minecraft:orange_concrete
fill 427 187 238 429 190 238 minecraft:orange_concrete
fill 427 187 244 429 190 244 minecraft:orange_concrete
fill 430 187 239 430 190 239 minecraft:orange_concrete
fill 430 187 243 430 190 243 minecraft:orange_concrete
fill 431 187 240 431 190 242 minecraft:orange_concrete
fill 433 187 270 433 276 270 minecraft:black_concrete
setblock 434 187 270 minecraft:sea_lantern
fill 437 187 270 437 253 270 minecraft:black_concrete
setblock 439 187 270 minecraft:sea_lantern
fill 443 187 270 443 208 270 minecraft:black_concrete
fill 449 187 263 451 187 263 minecraft:pearlescent_froglight
fill 450 187 262 451 187 262 minecraft:pearlescent_froglight
fill 450 187 264 450 188 264 minecraft:pearlescent_froglight
setblock 453 187 270 minecraft:pearlescent_froglight
setblock 456 187 228 minecraft:sea_lantern
fill 457 187 228 457 196 228 minecraft:black_concrete
fill 465 187 246 465 285 246 minecraft:black_concrete
fill 465 187 262 465 190 262 minecraft:black_concrete
setblock 465 187 263 minecraft:pearlescent_froglight
fill 423 188 268 423 285 268 minecraft:black_concrete
fill 434 188 270 434 211 270 minecraft:black_concrete
setblock 436 188 270 minecraft:magenta_terracotta
fill 439 188 270 439 218 270 minecraft:black_concrete
fill 450 188 262 450 188 263 minecraft:pearlescent_froglight
setblock 451 188 263 minecraft:pearlescent_froglight
fill 453 188 270 453 190 270 minecraft:black_concrete
fill 456 188 228 456 232 228 minecraft:black_concrete
setblock 456 188 270 minecraft:pearlescent_froglight
fill 465 188 263 465 190 263 minecraft:black_concrete
setblock 423 189 267 minecraft:purple_terracotta
setblock 436 189 228 minecraft:sea_lantern
fill 436 189 270 436 208 270 minecraft:black_concrete
setblock 443 189 228 minecraft:pearlescent_froglight
fill 450 189 263 450 191 263 minecraft:pearlescent_froglight
fill 456 189 270 456 253 270 minecraft:black_concrete
setblock 465 189 237 minecraft:pearlescent_froglight
setblock 465 189 244 minecraft:white_concrete
fill 423 190 267 423 233 267 minecraft:black_concrete
fill 436 190 228 436 202 228 minecraft:black_concrete
setblock 438 190 228 minecraft:pearlescent_froglight
fill 443 190 228 443 232 228 minecraft:black_concrete
setblock 444 190 270 minecraft:pearlescent_froglight
fill 445 190 270 445 196 270 minecraft:black_concrete
setblock 458 190 270 minecraft:pearlescent_froglight
fill 465 190 237 465 197 237 minecraft:black_concrete
fill 465 190 244 465 263 244 minecraft:black_concrete
setblock 423 191 262 minecraft:pearlescent_froglight
setblock 426 191 231 minecraft:light[level=15]
setblock 426 191 239 minecraft:light[level=15]
setblock 426 191 247 minecraft:light[level=15]
setblock 426 191 255 minecraft:light[level=15]
setblock 426 191 263 minecraft:light[level=15]
setblock 428 191 228 minecraft:white_concrete
setblock 434 191 231 minecraft:light[level=15]
setblock 434 191 239 minecraft:light[level=15]
setblock 434 191 247 minecraft:light[level=15]
setblock 434 191 255 minecraft:light[level=15]
setblock 434 191 263 minecraft:light[level=15]
fill 438 191 228 438 215 228 minecraft:black_concrete
fill 438 191 258 438 192 258 minecraft:gray_concrete
setblock 442 191 231 minecraft:light[level=15]
setblock 442 191 239 minecraft:light[level=15]
setblock 442 191 247 minecraft:light[level=15]
setblock 442 191 255 minecraft:light[level=15]
setblock 442 191 263 minecraft:light[level=15]
fill 444 191 240 444 193 240 minecraft:tuff
setblock 444 191 270 minecraft:blue_concrete
setblock 450 191 231 minecraft:light[level=15]
setblock 450 191 239 minecraft:light[level=15]
setblock 450 191 247 minecraft:light[level=15]
setblock 450 191 255 minecraft:light[level=15]
setblock 453 191 270 minecraft:sea_lantern
setblock 455 191 228 minecraft:sea_lantern
setblock 458 191 231 minecraft:light[level=15]
setblock 458 191 239 minecraft:light[level=15]
setblock 458 191 247 minecraft:light[level=15]
setblock 458 191 255 minecraft:light[level=15]
setblock 458 191 263 minecraft:light[level=15]
fill 458 191 270 458 220 270 minecraft:black_concrete
setblock 465 191 262 minecraft:pearlescent_froglight
setblock 465 191 263 minecraft:sea_lantern
setblock 423 192 250 minecraft:pearlescent_froglight
fill 423 192 262 423 247 262 minecraft:black_concrete
setblock 426 192 231 minecraft:light[level=12]
setblock 426 192 238 minecraft:light[level=12]
setblock 426 192 245 minecraft:light[level=12]
setblock 426 192 252 minecraft:light[level=12]
setblock 426 192 259 minecraft:light[level=12]
setblock 426 192 266 minecraft:light[level=12]
fill 428 192 228 428 197 228 minecraft:black_concrete
setblock 429 192 228 minecraft:white_concrete
setblock 433 192 231 minecraft:light[level=12]
setblock 433 192 238 minecraft:light[level=12]
setblock 433 192 245 minecraft:light[level=12]
setblock 433 192 252 minecraft:light[level=12]
setblock 433 192 259 minecraft:light[level=12]
setblock 433 192 266 minecraft:light[level=12]
setblock 440 192 231 minecraft:light[level=12]
setblock 440 192 238 minecraft:light[level=12]
setblock 440 192 245 minecraft:light[level=12]
setblock 440 192 252 minecraft:light[level=12]
setblock 440 192 259 minecraft:light[level=12]
setblock 440 192 266 minecraft:light[level=12]
fill 444 192 239 445 193 239 minecraft:tuff
fill 444 192 241 445 192 241 minecraft:tuff
fill 444 192 270 444 199 270 minecraft:black_concrete
fill 445 192 240 445 193 240 minecraft:tuff
setblock 446 192 228 minecraft:purple_concrete
setblock 447 192 231 minecraft:light[level=12]
setblock 447 192 238 minecraft:light[level=12]
setblock 447 192 245 minecraft:light[level=12]
setblock 447 192 252 minecraft:light[level=12]
setblock 447 192 259 minecraft:light[level=12]
setblock 447 192 266 minecraft:light[level=12]
setblock 449 192 270 minecraft:white_concrete
fill 453 192 270 453 203 270 minecraft:black_concrete
setblock 454 192 231 minecraft:light[level=12]
setblock 454 192 238 minecraft:light[level=12]
setblock 454 192 245 minecraft:light[level=12]
setblock 454 192 252 minecraft:light[level=12]
setblock 454 192 259 minecraft:light[level=12]
setblock 454 192 266 minecraft:light[level=12]
fill 455 192 228 455 213 228 minecraft:black_concrete
setblock 459 192 228 minecraft:ochre_froglight
setblock 461 192 231 minecraft:light[level=12]
setblock 461 192 238 minecraft:light[level=12]
setblock 461 192 245 minecraft:light[level=12]
setblock 461 192 252 minecraft:light[level=12]
setblock 461 192 259 minecraft:light[level=12]
setblock 461 192 266 minecraft:light[level=12]
fill 465 192 262 465 201 263 minecraft:black_concrete
setblock 423 193 231 minecraft:sea_lantern
setblock 423 193 232 minecraft:pearlescent_froglight
fill 423 193 250 423 220 250 minecraft:black_concrete
fill 429 193 228 429 273 228 minecraft:black_concrete
setblock 430 193 228 minecraft:white_concrete
setblock 443 193 239 minecraft:tuff
setblock 446 193 228 minecraft:ochre_froglight
fill 449 193 270 449 202 270 minecraft:black_concrete
fill 459 193 228 459 213 228 minecraft:black_concrete
setblock 463 193 228 minecraft:blue_concrete
setblock 465 193 255 minecraft:pearlescent_froglight
fill 423 194 231 423 223 232 minecraft:black_concrete
setblock 427 194 270 minecraft:pearlescent_froglight
fill 430 194 228 430 308 228 minecraft:black_concrete
setblock 432 194 228 minecraft:pearlescent_froglight
fill 446 194 228 446 225 228 minecraft:black_concrete
setblock 459 194 270 minecraft:sea_lantern
fill 463 194 228 463 210 228 minecraft:black_concrete
setblock 465 194 229 minecraft:sea_lantern
setblock 465 194 235 minecraft:pearlescent_froglight
fill 465 194 255 465 213 255 minecraft:black_concrete
setblock 423 195 245 minecraft:white_concrete
setblock 426 195 270 minecraft:sea_lantern
fill 427 195 270 427 242 270 minecraft:black_concrete
fill 432 195 228 432 196 228 minecraft:black_concrete
setblock 444 195 228 minecraft:pearlescent_froglight
fill 459 195 270 459 213 270 minecraft:black_concrete
fill 465 195 229 465 214 229 minecraft:black_concrete
fill 465 195 235 465 206 235 minecraft:black_concrete
setblock 465 195 251 minecraft:ochre_froglight
setblock 423 196 235 minecraft:purple_concrete
fill 423 196 245 423 212 245 minecraft:black_concrete
setblock 423 196 257 minecraft:sea_lantern
fill 426 196 270 426 220 270 minecraft:black_concrete
fill 444 196 228 444 211 228 minecraft:black_concrete
fill 465 196 251 465 308 251 minecraft:black_concrete
setblock 465 196 269 minecraft:sea_lantern
fill 423 197 235 423 198 235 minecraft:black_concrete
setblock 423 197 247 minecraft:sea_lantern
fill 423 197 257 423 198 257 minecraft:black_concrete
setblock 432 197 228 minecraft:blue_concrete
setblock 439 197 228 minecraft:pearlescent_froglight
fill 442 197 247 442 198 248 minecraft:tuff
fill 443 197 248 443 198 248 minecraft:tuff
setblock 444 197 249 minecraft:tuff
setblock 445 197 270 minecraft:sea_lantern
setblock 447 197 228 minecraft:ochre_froglight
setblock 452 197 270 minecraft:ochre_froglight
setblock 457 197 228 minecraft:white_concrete
setblock 465 197 243 minecraft:white_concrete
setblock 465 197 257 minecraft:magenta_terracotta
fill 465 197 269 465 202 269 minecraft:black_concrete
fill 423 198 247 423 251 247 minecraft:black_concrete
setblock 423 198 261 minecraft:pearlescent_froglight
setblock 426 198 231 minecraft:light[level=15]
setblock 426 198 238 minecraft:light[level=12]
setblock 426 198 239 minecraft:light[level=15]
setblock 426 198 245 minecraft:light[level=12]
setblock 426 198 247 minecraft:light[level=15]
setblock 426 198 252 minecraft:light[level=12]
setblock 426 198 255 minecraft:light[level=15]
setblock 426 198 259 minecraft:light[level=12]
setblock 426 198 263 minecraft:light[level=15]
setblock 426 198 266 minecraft:light[level=12]
setblock 428 198 228 minecraft:blue_concrete
fill 432 198 228 432 204 228 minecraft:black_concrete
setblock 433 198 231 minecraft:light[level=12]
setblock 433 198 238 minecraft:light[level=12]
setblock 433 198 245 minecraft:light[level=12]
setblock 433 198 252 minecraft:light[level=12]
setblock 433 198 259 minecraft:light[level=12]
setblock 433 198 266 minecraft:light[level=12]
setblock 434 198 231 minecraft:light[level=15]
setblock 434 198 239 minecraft:light[level=15]
setblock 434 198 247 minecraft:light[level=15]
setblock 434 198 255 minecraft:light[level=15]
setblock 434 198 263 minecraft:light[level=15]
fill 439 198 228 439 207 228 minecraft:black_concrete
fill 439 198 247 441 198 248 minecraft:tuff
setblock 440 198 231 minecraft:light[level=12]
setblock 440 198 238 minecraft:light[level=12]
setblock 440 198 245 minecraft:light[level=12]
fill 440 198 246 447 198 246 minecraft:tuff
fill 440 198 249 441 198 250 minecraft:tuff
setblock 440 198 252 minecraft:light[level=12]
setblock 440 198 259 minecraft:light[level=12]
setblock 440 198 266 minecraft:light[level=12]
fill 441 198 245 446 198 245 minecraft:tuff
setblock 442 198 231 minecraft:light[level=15]
setblock 442 198 239 minecraft:light[level=15]
setblock 442 198 255 minecraft:light[level=15]
setblock 442 198 263 minecraft:light[level=15]
fill 443 198 244 444 198 244 minecraft:tuff
fill 443 198 247 447 198 247 minecraft:tuff
fill 445 198 248 448 198 248 minecraft:tuff
fill 445 198 270 445 224 270 minecraft:black_concrete
fill 447 198 228 447 235 228 minecraft:black_concrete
setblock 447 198 231 minecraft:light[level=12]
setblock 447 198 238 minecraft:light[level=12]
setblock 447 198 245 minecraft:light[level=12]
fill 447 198 249 449 198 250 minecraft:tuff
fill 447 198 252 448 198 253 minecraft:tuff
setblock 447 198 259 minecraft:light[level=12]
setblock 447 198 266 minecraft:light[level=12]
fill 448 198 251 449 198 251 minecraft:tuff
fill 449 198 252 449 201 252 minecraft:tuff
setblock 450 198 231 minecraft:light[level=15]
setblock 450 198 239 minecraft:light[level=15]
setblock 450 198 247 minecraft:light[level=15]
setblock 450 198 255 minecraft:light[level=15]
setblock 450 198 263 minecraft:light[level=15]
fill 452 198 270 452 204 270 minecraft:black_concrete
setblock 454 198 228 minecraft:sea_lantern
setblock 454 198 231 minecraft:light[level=12]
setblock 454 198 238 minecraft:light[level=12]
setblock 454 198 245 minecraft:light[level=12]
setblock 454 198 252 minecraft:light[level=12]
setblock 454 198 259 minecraft:light[level=12]
setblock 454 198 266 minecraft:light[level=12]
fill 457 198 228 457 208 228 minecraft:black_concrete
setblock 458 198 231 minecraft:light[level=15]
setblock 458 198 239 minecraft:light[level=15]
setblock 458 198 247 minecraft:light[level=15]
setblock 458 198 255 minecraft:light[level=15]
setblock 458 198 263 minecraft:light[level=15]
setblock 461 198 231 minecraft:light[level=12]
setblock 461 198 238 minecraft:light[level=12]
setblock 461 198 245 minecraft:light[level=12]
setblock 461 198 252 minecraft:light[level=12]
setblock 461 198 259 minecraft:light[level=12]
setblock 461 198 266 minecraft:light[level=12]
setblock 465 198 237 minecraft:ochre_froglight
fill 465 198 243 465 249 243 minecraft:black_concrete
fill 465 198 257 465 205 257 minecraft:black_concrete
setblock 465 198 266 minecraft:white_concrete
setblock 423 199 235 minecraft:ochre_froglight
setblock 423 199 257 minecraft:white_concrete
fill 423 199 261 423 204 261 minecraft:black_concrete
setblock 428 199 228 minecraft:ochre_froglight
fill 437 199 247 438 199 248 minecraft:tuff
setblock 438 199 246 minecraft:cobbled_deepslate
fill 438 199 249 440 199 249 minecraft:tuff
setblock 438 199 250 minecraft:andesite
fill 438 199 251 438 199 253 minecraft:tuff
fill 439 199 245 440 199 246 minecraft:tuff
setblock 439 199 247 minecraft:andesite
setblock 439 199 248 minecraft:cobbled_deepslate
fill 439 199 250 439 201 250 minecraft:tuff
setblock 439 199 251 minecraft:andesite
fill 439 199 252 439 199 254 minecraft:tuff
fill 440 199 228 440 218 228 minecraft:black_concrete
setblock 440 199 244 minecraft:andesite
fill 440 199 247 442 199 247 minecraft:tuff
setblock 440 199 248 minecraft:andesite
fill 440 199 250 440 212 252 minecraft:obsidian
fill 440 199 253 440 199 254 minecraft:tuff
setblock 441 199 228 minecraft:white_concrete
setblock 441 199 243 minecraft:cobbled_deepslate
fill 441 199 244 443 199 244 minecraft:tuff
setblock 441 199 245 minecraft:andesite
setblock 441 199 246 minecraft:tuff
fill 441 199 248 441 212 250 minecraft:obsidian
fill 441 199 252 441 212 254 minecraft:obsidian
setblock 442 199 242 minecraft:andesite
setblock 442 199 243 minecraft:tuff
setblock 442 199 245 minecraft:cobbled_deepslate
setblock 442 199 246 minecraft:andesite
fill 442 199 248 443 212 248 minecraft:obsidian
fill 442 199 254 443 212 254 minecraft:obsidian
fill 443 199 242 444 200 242 minecraft:tuff
setblock 443 199 243 minecraft:andesite
fill 443 199 245 444 199 246 minecraft:tuff
fill 443 199 247 445 212 247 minecraft:obsidian
fill 444 199 243 446 199 243 minecraft:tuff
setblock 444 199 244 minecraft:andesite
setblock 445 199 242 minecraft:cobbled_deepslate
fill 445 199 244 445 201 244 minecraft:tuff
setblock 445 199 245 minecraft:andesite
setblock 445 199 246 minecraft:tuff
fill 445 199 248 447 212 248 minecraft:obsidian
fill 445 199 254 445 212 255 minecraft:obsidian
setblock 446 199 242 minecraft:andesite
setblock 446 199 244 minecraft:cobbled_deepslate
fill 446 199 245 448 199 245 minecraft:tuff
setblock 446 199 246 minecraft:andesite
setblock 446 199 247 minecraft:tuff
fill 446 199 254 447 212 254 minecraft:obsidian
setblock 446 199 255 minecraft:tuff
setblock 447 199 243 minecraft:andesite
setblock 447 199 244 minecraft:tuff
setblock 447 199 246 minecraft:cobbled_deepslate
setblock 447 199 247 minecraft:andesite
fill 447 199 249 447 212 250 minecraft:obsidian
fill 447 199 252 447 212 253 minecraft:obsidian
setblock 447 199 255 minecraft:cobbled_deepslate
setblock 448 199 244 minecraft:andesite
fill 448 199 246 449 199 247 minecraft:tuff
setblock 448 199 248 minecraft:cobbled_deepslate
setblock 448 199 249 minecraft:tuff
fill 448 199 250 448 212 252 minecraft:obsidian
fill 448 199 253 448 199 255 minecraft:tuff
fill 449 199 248 450 200 248 minecraft:tuff
setblock 449 199 249 minecraft:andesite
setblock 449 199 250 minecraft:cobbled_deepslate
fill 449 199 251 450 199 251 minecraft:tuff
setblock 449 199 253 minecraft:andesite
setblock 449 199 254 minecraft:tuff
fill 450 199 249 451 199 249 minecraft:tuff
setblock 450 199 250 minecraft:andesite
setblock 450 199 252 minecraft:cobbled_deepslate
fill 450 199 253 451 200 253 minecraft:tuff
setblock 450 199 254 minecraft:andesite
fill 451 199 250 451 201 250 minecraft:tuff
setblock 451 199 251 minecraft:andesite
setblock 451 199 252 minecraft:tuff
fill 454 199 228 454 203 228 minecraft:black_concrete
setblock 458 199 228 minecraft:sea_lantern
fill 465 199 237 465 209 237 minecraft:black_concrete
fill 465 199 266 465 308 266 minecraft:black_concrete
fill 423 200 235 423 214 235 minecraft:black_concrete
fill 423 200 257 423 273 257 minecraft:black_concrete
fill 428 200 228 428 211 228 minecraft:black_concrete
setblock 429 200 270 minecraft:blue_concrete
setblock 434 200 228 minecraft:pearlescent_froglight
setblock 435 200 228 minecraft:purple_terracotta
fill 436 200 247 437 200 247 minecraft:tuff
setblock 436 200 248 minecraft:cobbled_deepslate
setblock 436 200 249 minecraft:andesite
fill 436 200 250 436 200 252 minecraft:tuff
setblock 436 200 253 minecraft:andesite
setblock 437 200 246 minecraft:andesite
fill 437 200 248 438 200 249 minecraft:tuff
setblock 437 200 250 minecraft:cobbled_deepslate
fill 437 200 251 437 200 253 minecraft:tuff
setblock 437 200 254 minecraft:andesite
fill 438 200 245 438 201 246 minecraft:tuff
setblock 438 200 247 minecraft:andesite
fill 438 200 250 438 202 250 minecraft:tuff
setblock 438 200 251 minecraft:andesite
setblock 438 200 252 minecraft:cobbled_deepslate
fill 438 200 253 438 201 254 minecraft:tuff
setblock 438 200 255 minecraft:andesite
fill 439 200 243 441 200 243 minecraft:tuff
setblock 439 200 244 minecraft:andesite
setblock 439 200 245 minecraft:cobbled_deepslate
fill 439 200 246 439 201 247 minecraft:tuff
setblock 439 200 248 minecraft:andesite
setblock 439 200 249 minecraft:tuff
setblock 439 200 251 minecraft:tuff
setblock 439 200 252 minecraft:andesite
setblock 439 200 253 minecraft:tuff
setblock 439 200 254 minecraft:cobbled_deepslate
fill 439 200 255 441 200 255 minecraft:tuff
setblock 439 200 256 minecraft:andesite
setblock 440 200 242 minecraft:tuff
fill 440 200 244 442 200 244 minecraft:tuff
setblock 440 200 245 minecraft:andesite
setblock 440 200 246 minecraft:tuff
setblock 440 200 247 minecraft:cobbled_deepslate
fill 440 200 248 440 202 248 minecraft:tuff
setblock 440 200 249 minecraft:andesite
setblock 440 200 253 minecraft:andesite
setblock 440 200 254 minecraft:tuff
setblock 440 200 256 minecraft:cobbled_deepslate
fill 441 200 228 441 207 228 minecraft:black_concrete
setblock 441 200 242 minecraft:andesite
fill 441 200 245 443 200 245 minecraft:tuff
setblock 441 200 246 minecraft:andesite
setblock 441 200 247 minecraft:tuff
fill 441 200 256 442 200 256 minecraft:tuff
fill 442 200 241 443 200 241 minecraft:tuff
setblock 442 200 242 minecraft:cobbled_deepslate
setblock 442 200 243 minecraft:andesite
fill 442 200 246 443 201 246 minecraft:tuff
setblock 442 200 247 minecraft:andesite
setblock 442 200 255 minecraft:andesite
setblock 443 200 240 minecraft:andesite
fill 443 200 243 445 200 243 minecraft:tuff
setblock 443 200 244 minecraft:cobbled_deepslate
fill 443 200 255 444 212 255 minecraft:obsidian
setblock 443 200 256 minecraft:andesite
fill 444 200 240 446 200 240 minecraft:tuff
setblock 444 200 241 minecraft:andesite
fill 444 200 244 444 202 244 minecraft:tuff
setblock 444 200 245 minecraft:andesite
setblock 444 200 246 minecraft:cobbled_deepslate
fill 444 200 256 446 200 256 minecraft:tuff
setblock 444 200 270 minecraft:blue_concrete
fill 445 200 241 445 202 241 minecraft:tuff
setblock 445 200 242 minecraft:andesite
fill 445 200 245 447 200 245 minecraft:tuff
setblock 445 200 246 minecraft:andesite
setblock 446 200 241 minecraft:cobbled_deepslate
fill 446 200 242 448 200 242 minecraft:tuff
setblock 446 200 243 minecraft:andesite
setblock 446 200 244 minecraft:tuff
fill 446 200 246 448 200 246 minecraft:tuff
setblock 446 200 247 minecraft:andesite
setblock 446 200 255 minecraft:andesite
setblock 447 200 241 minecraft:tuff
setblock 447 200 243 minecraft:cobbled_deepslate
setblock 447 200 244 minecraft:andesite
fill 447 200 247 448 201 247 minecraft:tuff
fill 447 200 255 449 200 255 minecraft:tuff
setblock 447 200 256 minecraft:andesite
fill 448 200 243 449 200 244 minecraft:tuff
setblock 448 200 245 minecraft:cobbled_deepslate
fill 448 200 248 448 201 248 minecraft:tuff
setblock 448 200 249 minecraft:andesite
setblock 448 200 253 minecraft:andesite
setblock 448 200 254 minecraft:cobbled_deepslate
fill 448 200 256 448 202 256 minecraft:tuff
fill 449 200 245 450 201 245 minecraft:tuff
setblock 449 200 246 minecraft:andesite
setblock 449 200 247 minecraft:cobbled_deepslate
fill 449 200 249 449 202 249 minecraft:tuff
setblock 449 200 250 minecraft:andesite
setblock 449 200 251 minecraft:tuff
setblock 449 200 253 minecraft:tuff
setblock 449 200 254 minecraft:andesite
setblock 449 200 256 minecraft:cobbled_deepslate
setblock 450 200 246 minecraft:tuff
setblock 450 200 247 minecraft:andesite
setblock 450 200 249 minecraft:cobbled_deepslate
fill 450 200 250 450 202 250 minecraft:tuff
setblock 450 200 251 minecraft:andesite
setblock 450 200 252 minecraft:tuff
fill 450 200 254 452 200 254 minecraft:tuff
setblock 450 200 255 minecraft:andesite
fill 451 200 247 451 202 247 minecraft:tuff
setblock 451 200 248 minecraft:andesite
setblock 451 200 249 minecraft:tuff
setblock 451 200 251 minecraft:cobbled_deepslate
setblock 451 200 252 minecraft:andesite
fill 451 200 255 451 202 255 minecraft:tuff
setblock 452 200 249 minecraft:andesite
fill 452 200 250 452 200 252 minecraft:tuff
setblock 452 200 253 minecraft:cobbled_deepslate
fill 458 200 228 458 206 228 minecraft:black_concrete
setblock 423 201 248 minecraft:white_concrete
setblock 423 201 249 minecraft:ochre_froglight
fill 429 201 270 429 216 270 minecraft:black_concrete
fill 434 201 228 435 201 228 minecraft:black_concrete
fill 435 201 247 436 201 248 minecraft:tuff
setblock 435 201 249 minecraft:andesite
fill 435 201 250 435 201 251 minecraft:tuff
setblock 435 201 252 minecraft:cobbled_deepslate
setblock 435 201 253 minecraft:andesite
setblock 436 201 245 minecraft:cobbled_deepslate
setblock 436 201 246 minecraft:andesite
fill 436 201 249 437 202 249 minecraft:tuff
setblock 436 201 250 minecraft:andesite
fill 436 201 251 436 201 253 minecraft:tuff
setblock 436 201 254 minecraft:cobbled_deepslate
setblock 436 201 255 minecraft:tuff
fill 437 201 244 437 201 246 minecraft:tuff
setblock 437 201 247 minecraft:cobbled_deepslate
setblock 437 201 248 minecraft:tuff
fill 437 201 250 437 202 250 minecraft:tuff
setblock 437 201 251 minecraft:andesite
fill 437 201 252 437 201 254 minecraft:tuff
setblock 437 201 255 minecraft:andesite
setblock 437 201 256 minecraft:cobbled_deepslate
fill 438 201 243 440 201 243 minecraft:tuff
setblock 438 201 244 minecraft:andesite
fill 438 201 247 438 203 247 minecraft:tuff
setblock 438 201 248 minecraft:andesite
setblock 438 201 249 minecraft:cobbled_deepslate
fill 438 201 251 438 203 251 minecraft:tuff
setblock 438 201 252 minecraft:andesite
fill 438 201 255 440 201 255 minecraft:tuff
setblock 438 201 256 minecraft:andesite
setblock 439 201 242 minecraft:cobbled_deepslate
fill 439 201 244 439 203 244 minecraft:tuff
setblock 439 201 245 minecraft:andesite
setblock 439 201 248 minecraft:tuff
setblock 439 201 249 minecraft:andesite
setblock 439 201 251 minecraft:cobbled_deepslate
fill 439 201 252 439 203 252 minecraft:tuff
setblock 439 201 253 minecraft:andesite
setblock 439 201 254 minecraft:tuff
fill 439 201 256 441 201 256 minecraft:tuff
setblock 439 201 257 minecraft:andesite
fill 440 201 241 442 201 241 minecraft:tuff
setblock 440 201 242 minecraft:andesite
setblock 440 201 244 minecraft:cobbled_deepslate
fill 440 201 245 442 201 245 minecraft:tuff
setblock 440 201 246 minecraft:andesite
setblock 440 201 247 minecraft:tuff
fill 440 201 249 440 203 249 minecraft:tuff
setblock 440 201 253 minecraft:cobbled_deepslate
setblock 440 201 254 minecraft:andesite
fill 440 201 257 441 202 257 minecraft:tuff
setblock 441 201 240 minecraft:tuff
fill 441 201 242 443 201 242 minecraft:tuff
setblock 441 201 243 minecraft:andesite
setblock 441 201 244 minecraft:tuff
setblock 441 201 246 minecraft:cobbled_deepslate
setblock 441 201 247 minecraft:andesite
setblock 441 201 255 minecraft:cobbled_deepslate
setblock 442 201 240 minecraft:andesite
fill 442 201 243 443 202 243 minecraft:tuff
setblock 442 201 244 minecraft:andesite
fill 442 201 247 442 203 247 minecraft:tuff
fill 442 201 255 442 203 255 minecraft:tuff
setblock 442 201 256 minecraft:andesite
setblock 442 201 257 minecraft:cobbled_deepslate
fill 443 201 240 445 201 240 minecraft:tuff
setblock 443 201 241 minecraft:cobbled_deepslate
fill 443 201 244 443 202 244 minecraft:tuff
setblock 443 201 245 minecraft:andesite
fill 443 201 256 445 201 256 minecraft:tuff
setblock 443 201 257 minecraft:andesite
setblock 444 201 239 minecraft:tuff
fill 444 201 241 444 203 241 minecraft:tuff
setblock 444 201 242 minecraft:andesite
setblock 444 201 243 minecraft:cobbled_deepslate
fill 444 201 245 444 203 245 minecraft:tuff
setblock 444 201 246 minecraft:andesite
fill 444 201 257 446 201 257 minecraft:tuff
setblock 444 201 270 minecraft:black_concrete
setblock 445 201 239 minecraft:andesite
fill 445 201 242 447 201 242 minecraft:tuff
setblock 445 201 243 minecraft:andesite
setblock 445 201 245 minecraft:cobbled_deepslate
fill 445 201 246 447 201 246 minecraft:tuff
setblock 446 201 240 minecraft:andesite
setblock 446 201 241 minecraft:tuff
fill 446 201 243 448 201 243 minecraft:tuff
setblock 446 201 244 minecraft:andesite
setblock 446 201 245 minecraft:tuff
setblock 446 201 247 minecraft:cobbled_deepslate
fill 446 201 255 448 201 255 minecraft:tuff
setblock 446 201 256 minecraft:cobbled_deepslate
setblock 447 201 240 minecraft:cobbled_deepslate
setblock 447 201 241 minecraft:andesite
fill 447 201 244 448 202 244 minecraft:tuff
setblock 447 201 245 minecraft:andesite
fill 447 201 256 447 203 256 minecraft:tuff
setblock 447 201 257 minecraft:andesite
fill 448 201 240 448 202 241 minecraft:tuff
setblock 448 201 242 minecraft:cobbled_deepslate
fill 448 201 245 448 202 245 minecraft:tuff
setblock 448 201 246 minecraft:andesite
fill 448 201 249 448 203 249 minecraft:tuff
fill 448 201 253 448 203 253 minecraft:tuff
setblock 448 201 254 minecraft:andesite
fill 448 201 257 449 201 257 minecraft:tuff
fill 449 201 241 449 201 242 minecraft:tuff
setblock 449 201 243 minecraft:andesite
setblock 449 201 244 minecraft:cobbled_deepslate
fill 449 201 246 449 203 246 minecraft:tuff
setblock 449 201 247 minecraft:andesite
setblock 449 201 248 minecraft:tuff
setblock 449 201 250 minecraft:tuff
setblock 449 201 251 minecraft:andesite
setblock 449 201 253 minecraft:cobbled_deepslate
fill 449 201 254 451 201 254 minecraft:tuff
setblock 449 201 255 minecraft:andesite
setblock 449 201 256 minecraft:tuff
setblock 450 201 243 minecraft:tuff
setblock 450 201 244 minecraft:andesite
setblock 450 201 246 minecraft:cobbled_deepslate
fill 450 201 247 450 203 247 minecraft:tuff
setblock 450 201 248 minecraft:andesite
setblock 450 201 249 minecraft:tuff
fill 450 201 251 452 201 251 minecraft:tuff
setblock 450 201 252 minecraft:andesite
setblock 450 201 253 minecraft:tuff
setblock 450 201 255 minecraft:cobbled_deepslate
setblock 450 201 256 minecraft:andesite
fill 451 201 244 451 203 244 minecraft:tuff
setblock 451 201 245 minecraft:andesite
setblock 451 201 246 minecraft:tuff
setblock 451 201 248 minecraft:cobbled_deepslate
setblock 451 201 249 minecraft:andesite
fill 451 201 252 452 202 252 minecraft:tuff
setblock 451 201 253 minecraft:andesite
fill 451 201 256 451 203 256 minecraft:tuff
setblock 452 201 246 minecraft:andesite
fill 452 201 247 452 201 249 minecraft:tuff
setblock 452 201 250 minecraft:cobbled_deepslate
fill 452 201 253 453 202 253 minecraft:tuff
setblock 452 201 254 minecraft:andesite
setblock 452 201 255 minecraft:tuff
fill 453 201 248 453 201 250 minecraft:tuff
setblock 453 201 251 minecraft:andesite
setblock 453 201 252 minecraft:cobbled_deepslate
fill 453 201 254 453 203 254 minecraft:tuff
fill 423 202 248 423 246 249 minecraft:black_concrete
setblock 423 202 251 minecraft:purple_concrete
setblock 423 202 265 minecraft:white_concrete
setblock 428 202 270 minecraft:pearlescent_froglight
fill 434 202 228 434 292 228 minecraft:black_concrete
setblock 434 202 247 minecraft:cobbled_deepslate
fill 434 202 248 436 202 248 minecraft:tuff
fill 434 202 250 434 202 252 minecraft:tuff
setblock 435 202 228 minecraft:ochre_froglight
fill 435 202 245 437 202 245 minecraft:tuff
setblock 435 202 246 minecraft:andesite
setblock 435 202 247 minecraft:tuff
setblock 435 202 249 minecraft:cobbled_deepslate
setblock 435 202 250 minecraft:andesite
fill 435 202 251 435 202 253 minecraft:tuff
setblock 435 202 254 minecraft:andesite
setblock 435 202 255 minecraft:tuff
setblock 436 202 244 minecraft:tuff
fill 436 202 246 437 203 246 minecraft:tuff
setblock 436 202 247 minecraft:andesite
fill 436 202 250 436 204 250 minecraft:tuff
setblock 436 202 251 minecraft:cobbled_deepslate
fill 436 202 252 436 202 254 minecraft:tuff
setblock 436 202 255 minecraft:andesite
setblock 436 202 256 minecraft:tuff
fill 437 202 243 439 202 243 minecraft:tuff
setblock 437 202 244 minecraft:cobbled_deepslate
fill 437 202 247 437 203 247 minecraft:tuff
setblock 437 202 248 minecraft:andesite
fill 437 202 251 437 204 251 minecraft:tuff
setblock 437 202 252 minecraft:andesite
setblock 437 202 253 minecraft:cobbled_deepslate
fill 437 202 254 437 203 255 minecraft:tuff
setblock 437 202 256 minecraft:andesite
setblock 437 202 257 minecraft:tuff
setblock 438 202 242 minecraft:tuff
fill 438 202 244 438 204 244 minecraft:tuff
setblock 438 202 245 minecraft:andesite
setblock 438 202 246 minecraft:cobbled_deepslate
fill 438 202 248 438 204 248 minecraft:tuff
setblock 438 202 249 minecraft:andesite
setblock 438 202 252 minecraft:tuff
setblock 438 202 253 minecraft:andesite
setblock 438 202 254 minecraft:tuff
setblock 438 202 255 minecraft:cobbled_deepslate
fill 438 202 256 440 202 256 minecraft:tuff
setblock 438 202 257 minecraft:andesite
fill 439 202 241 439 204 241 minecraft:tuff
setblock 439 202 242 minecraft:andesite
fill 439 202 245 441 202 245 minecraft:tuff
setblock 439 202 246 minecraft:andesite
setblock 439 202 247 minecraft:tuff
setblock 439 202 248 minecraft:cobbled_deepslate
fill 439 202 249 439 204 249 minecraft:tuff
setblock 439 202 250 minecraft:andesite
setblock 439 202 251 minecraft:tuff
fill 439 202 253 440 203 253 minecraft:tuff
setblock 439 202 254 minecraft:andesite
setblock 439 202 255 minecraft:tuff
setblock 439 202 257 minecraft:cobbled_deepslate
setblock 439 202 258 minecraft:andesite
setblock 440 202 240 minecraft:tuff
setblock 440 202 241 minecraft:cobbled_deepslate
fill 440 202 242 442 202 242 minecraft:tuff
setblock 440 202 243 minecraft:andesite
setblock 440 202 244 minecraft:tuff
fill 440 202 246 442 202 246 minecraft:tuff
setblock 440 202 247 minecraft:andesite
fill 440 202 254 440 204 254 minecraft:tuff
setblock 440 202 255 minecraft:andesite
fill 440 202 258 442 202 258 minecraft:tuff
setblock 441 202 240 minecraft:andesite
setblock 441 202 241 minecraft:tuff
setblock 441 202 243 minecraft:cobbled_deepslate
setblock 441 202 244 minecraft:andesite
fill 441 202 247 441 204 247 minecraft:tuff
fill 441 202 255 441 203 255 minecraft:tuff
setblock 441 202 256 minecraft:andesite
fill 442 202 239 443 202 240 minecraft:tuff
setblock 442 202 241 minecraft:andesite
fill 442 202 244 442 204 244 minecraft:tuff
setblock 442 202 245 minecraft:cobbled_deepslate
fill 442 202 256 442 204 256 minecraft:tuff
setblock 442 202 257 minecraft:andesite
fill 443 202 241 443 203 241 minecraft:tuff
setblock 443 202 242 minecraft:andesite
fill 443 202 245 443 204 245 minecraft:tuff
setblock 443 202 246 minecraft:andesite
setblock 443 202 256 minecraft:cobbled_deepslate
fill 443 202 257 445 202 257 minecraft:tuff
setblock 443 202 258 minecraft:andesite
setblock 444 202 239 minecraft:andesite
setblock 444 202 240 minecraft:cobbled_deepslate
fill 444 202 242 444 204 242 minecraft:tuff
setblock 444 202 243 minecraft:andesite
fill 444 202 246 446 202 246 minecraft:tuff
setblock 444 202 256 minecraft:tuff
setblock 444 202 258 minecraft:cobbled_deepslate
setblock 444 202 270 minecraft:ochre_froglight
fill 445 202 239 447 202 239 minecraft:tuff
setblock 445 202 240 minecraft:andesite
setblock 445 202 242 minecraft:cobbled_deepslate
fill 445 202 243 447 202 243 minecraft:tuff
setblock 445 202 244 minecraft:andesite
setblock 445 202 245 minecraft:tuff
setblock 445 202 256 minecraft:andesite
fill 445 202 258 446 202 258 minecraft:tuff
fill 446 202 240 447 203 240 minecraft:tuff
setblock 446 202 241 minecraft:andesite
setblock 446 202 242 minecraft:tuff
setblock 446 202 244 minecraft:cobbled_deepslate
setblock 446 202 245 minecraft:andesite
fill 446 202 247 447 202 247 minecraft:tuff
fill 446 202 255 446 203 256 minecraft:tuff
setblock 446 202 257 minecraft:andesite
fill 447 202 241 447 204 241 minecraft:tuff
setblock 447 202 242 minecraft:andesite
fill 447 202 245 447 204 245 minecraft:tuff
setblock 447 202 246 minecraft:cobbled_deepslate
setblock 447 202 255 minecraft:cobbled_deepslate
fill 447 202 257 447 204 257 minecraft:tuff
setblock 447 202 258 minecraft:andesite
fill 448 202 242 450 202 242 minecraft:tuff
setblock 448 202 243 minecraft:andesite
fill 448 202 246 448 204 246 minecraft:tuff
setblock 448 202 247 minecraft:andesite
setblock 448 202 248 minecraft:cobbled_deepslate
fill 448 202 254 450 202 254 minecraft:tuff
setblock 448 202 255 minecraft:andesite
setblock 448 202 257 minecraft:cobbled_deepslate
fill 448 202 258 449 203 258 minecraft:tuff
setblock 449 202 240 minecraft:andesite
setblock 449 202 241 minecraft:cobbled_deepslate
fill 449 202 243 449 204 243 minecraft:tuff
setblock 449 202 244 minecraft:andesite
setblock 449 202 245 minecraft:tuff
setblock 449 202 247 minecraft:tuff
setblock 449 202 248 minecraft:andesite
setblock 449 202 250 minecraft:cobbled_deepslate
fill 449 202 251 451 202 251 minecraft:tuff
setblock 449 202 252 minecraft:andesite
setblock 449 202 253 minecraft:tuff
fill 449 202 255 450 203 255 minecraft:tuff
setblock 449 202 256 minecraft:andesite
setblock 449 202 257 minecraft:tuff
setblock 450 202 241 minecraft:andesite
setblock 450 202 243 minecraft:cobbled_deepslate
fill 450 202 244 450 204 244 minecraft:tuff
setblock 450 202 245 minecraft:andesite
setblock 450 202 246 minecraft:tuff
fill 450 202 248 452 202 248 minecraft:tuff
setblock 450 202 249 minecraft:andesite
setblock 450 202 252 minecraft:cobbled_deepslate
setblock 450 202 253 minecraft:andesite
fill 450 202 256 450 204 256 minecraft:tuff
setblock 450 202 257 minecraft:andesite
setblock 451 202 243 minecraft:tuff
setblock 451 202 245 minecraft:cobbled_deepslate
setblock 451 202 246 minecraft:andesite
fill 451 202 249 452 203 249 minecraft:tuff
setblock 451 202 250 minecraft:andesite
fill 451 202 253 451 204 253 minecraft:tuff
setblock 451 202 254 minecraft:cobbled_deepslate
fill 451 202 257 451 203 257 minecraft:tuff
fill 452 202 244 452 202 246 minecraft:tuff
setblock 452 202 247 minecraft:cobbled_deepslate
fill 452 202 250 454 202 250 minecraft:tuff
setblock 452 202 251 minecraft:andesite
fill 452 202 254 452 204 254 minecraft:tuff
setblock 452 202 255 minecraft:andesite
setblock 452 202 256 minecraft:cobbled_deepslate
fill 453 202 246 453 202 247 minecraft:tuff
setblock 453 202 248 minecraft:andesite
setblock 453 202 249 minecraft:cobbled_deepslate
fill 453 202 251 453 204 251 minecraft:tuff
setblock 453 202 252 minecraft:andesite
setblock 453 202 255 minecraft:tuff
setblock 454 202 249 minecraft:andesite
setblock 454 202 251 minecraft:cobbled_deepslate
fill 454 202 252 454 204 252 minecraft:tuff
setblock 454 202 253 minecraft:andesite
fill 460 202 250 462 204 252 minecraft:gold_block
setblock 464 202 270 minecraft:sea_lantern
setblock 465 202 232 minecraft:pearlescent_froglight
setblock 465 202 262 minecraft:ochre_froglight
fill 465 202 263 465 276 263 minecraft:black_concrete
setblock 465 202 264 minecraft:pearlescent_froglight
setblock 423 203 239 minecraft:blue_concrete
fill 423 203 251 423 230 251 minecraft:black_concrete
fill 423 203 265 423 208 265 minecraft:black_concrete
fill 428 203 270 428 218 270 minecraft:black_concrete
setblock 433 203 228 minecraft:magenta_terracotta
setblock 434 203 246 minecraft:andesite
fill 434 203 247 434 203 249 minecraft:tuff
setblock 434 203 250 minecraft:andesite
fill 434 203 251 434 203 252 minecraft:tuff
setblock 434 203 253 minecraft:cobbled_deepslate
setblock 434 203 254 minecraft:andesite
fill 435 203 228 435 209 228 minecraft:black_concrete
fill 435 203 244 435 203 245 minecraft:tuff
setblock 435 203 246 minecraft:cobbled_deepslate
setblock 435 203 247 minecraft:andesite
fill 435 203 248 435 203 250 minecraft:tuff
setblock 435 203 251 minecraft:andesite
fill 435 203 252 435 203 254 minecraft:tuff
setblock 435 203 255 minecraft:cobbled_deepslate
fill 436 203 228 437 203 228 minecraft:white_concrete
fill 436 203 243 437 204 243 minecraft:tuff
setblock 436 203 244 minecraft:andesite
setblock 436 203 245 minecraft:tuff
fill 436 203 247 436 205 247 minecraft:tuff
setblock 436 203 248 minecraft:cobbled_deepslate
setblock 436 203 249 minecraft:tuff
fill 436 203 251 436 204 251 minecraft:tuff
setblock 436 203 252 minecraft:andesite
fill 436 203 253 436 203 255 minecraft:tuff
setblock 436 203 256 minecraft:andesite
setblock 436 203 257 minecraft:cobbled_deepslate
setblock 437 203 242 minecraft:tuff
fill 437 203 244 437 204 244 minecraft:tuff
setblock 437 203 245 minecraft:andesite
fill 437 203 248 437 205 248 minecraft:tuff
setblock 437 203 249 minecraft:andesite
setblock 437 203 250 minecraft:cobbled_deepslate
fill 437 203 252 437 205 252 minecraft:tuff
setblock 437 203 253 minecraft:andesite
fill 437 203 256 439 203 256 minecraft:tuff
setblock 437 203 257 minecraft:andesite
fill 438 203 241 438 205 241 minecraft:tuff
setblock 438 203 242 minecraft:andesite
setblock 438 203 243 minecraft:cobbled_deepslate
fill 438 203 245 438 205 245 minecraft:tuff
setblock 438 203 246 minecraft:andesite
setblock 438 203 249 minecraft:tuff
setblock 438 203 250 minecraft:andesite
setblock 438 203 252 minecraft:cobbled_deepslate
fill 438 203 253 438 205 253 minecraft:tuff
setblock 438 203 254 minecraft:andesite
setblock 438 203 255 minecraft:tuff
fill 438 203 257 440 203 257 minecraft:tuff
setblock 438 203 258 minecraft:andesite
setblock 439 203 240 minecraft:tuff
fill 439 203 242 441 203 242 minecraft:tuff
setblock 439 203 243 minecraft:andesite
setblock 439 203 245 minecraft:cobbled_deepslate
fill 439 203 246 441 203 246 minecraft:tuff
setblock 439 203 247 minecraft:andesite
setblock 439 203 248 minecraft:tuff
fill 439 203 250 439 205 250 minecraft:tuff
setblock 439 203 251 minecraft:andesite
setblock 439 203 254 minecraft:cobbled_deepslate
setblock 439 203 255 minecraft:andesite
fill 439 203 258 440 204 258 minecraft:tuff
setblock 440 203 240 minecraft:andesite
setblock 440 203 241 minecraft:tuff
fill 440 203 243 442 203 243 minecraft:tuff
setblock 440 203 244 minecraft:andesite
setblock 440 203 245 minecraft:tuff
setblock 440 203 247 minecraft:cobbled_deepslate
setblock 440 203 248 minecraft:andesite
fill 440 203 255 440 205 255 minecraft:tuff
setblock 440 203 256 minecraft:cobbled_deepslate
fill 440 203 259 442 203 259 minecraft:tuff
fill 441 203 239 442 203 239 minecraft:tuff
setblock 441 203 240 minecraft:cobbled_deepslate
setblock 441 203 241 minecraft:andesite
fill 441 203 244 441 205 244 minecraft:tuff
setblock 441 203 245 minecraft:andesite
fill 441 203 256 441 205 256 minecraft:tuff
setblock 441 203 257 minecraft:andesite
setblock 441 203 258 minecraft:cobbled_deepslate
fill 442 203 240 442 204 241 minecraft:tuff
setblock 442 203 242 minecraft:cobbled_deepslate
fill 442 203 245 442 204 245 minecraft:tuff
setblock 442 203 246 minecraft:andesite
fill 442 203 257 444 203 257 minecraft:tuff
setblock 442 203 258 minecraft:andesite
setblock 443 203 239 minecraft:andesite
setblock 443 203 240 minecraft:tuff
fill 443 203 242 443 205 242 minecraft:tuff
setblock 443 203 243 minecraft:andesite
setblock 443 203 244 minecraft:cobbled_deepslate
fill 443 203 246 443 205 246 minecraft:tuff
setblock 443 203 256 minecraft:tuff
fill 443 203 258 445 203 258 minecraft:tuff
setblock 443 203 259 minecraft:andesite
fill 444 203 239 444 205 239 minecraft:tuff
setblock 444 203 240 minecraft:andesite
fill 444 203 243 446 203 243 minecraft:tuff
setblock 444 203 244 minecraft:andesite
setblock 444 203 246 minecraft:cobbled_deepslate
setblock 444 203 256 minecraft:andesite
fill 444 203 259 445 204 259 minecraft:tuff
fill 444 203 270 444 231 270 minecraft:black_concrete
setblock 445 203 239 minecraft:cobbled_deepslate
fill 445 203 240 445 205 240 minecraft:tuff
setblock 445 203 241 minecraft:andesite
setblock 445 203 242 minecraft:tuff
fill 445 203 244 447 203 244 minecraft:tuff
setblock 445 203 245 minecraft:andesite
setblock 445 203 246 minecraft:tuff
fill 445 203 256 445 205 256 minecraft:tuff
setblock 445 203 257 minecraft:cobbled_deepslate
setblock 446 203 239 minecraft:tuff
setblock 446 203 241 minecraft:cobbled_deepslate
setblock 446 203 242 minecraft:andesite
fill 446 203 245 446 205 245 minecraft:tuff
setblock 446 203 246 minecraft:andesite
setblock 446 203 247 minecraft:tuff
fill 446 203 257 446 205 257 minecraft:tuff
setblock 446 203 258 minecraft:andesite
setblock 446 203 259 minecraft:cobbled_deepslate
setblock 447 203 239 minecraft:andesite
fill 447 203 242 449 203 242 minecraft:tuff
setblock 447 203 243 minecraft:cobbled_deepslate
fill 447 203 246 447 204 246 minecraft:tuff
setblock 447 203 247 minecraft:andesite
setblock 447 203 255 minecraft:andesite
setblock 447 203 258 minecraft:tuff
setblock 447 203 259 minecraft:andesite
fill 448 203 239 448 204 239 minecraft:tuff
setblock 448 203 240 minecraft:andesite
setblock 448 203 241 minecraft:tuff
fill 448 203 243 448 205 243 minecraft:tuff
setblock 448 203 244 minecraft:andesite
setblock 448 203 245 minecraft:cobbled_deepslate
fill 448 203 247 448 205 247 minecraft:tuff
setblock 448 203 248 minecraft:andesite
setblock 448 203 254 minecraft:cobbled_deepslate
fill 448 203 255 448 205 255 minecraft:tuff
setblock 448 203 256 minecraft:andesite
setblock 448 203 257 minecraft:tuff
fill 449 203 240 449 205 240 minecraft:tuff
setblock 449 203 241 minecraft:andesite
setblock 449 203 244 minecraft:tuff
setblock 449 203 245 minecraft:andesite
setblock 449 203 247 minecraft:cobbled_deepslate
fill 449 203 248 451 203 248 minecraft:tuff
setblock 449 203 249 minecraft:andesite
fill 449 203 250 449 203 252 minecraft:tuff
setblock 449 203 253 minecraft:andesite
setblock 449 203 254 minecraft:tuff
setblock 449 203 256 minecraft:cobbled_deepslate
setblock 449 203 257 minecraft:andesite
setblock 449 203 270 minecraft:pearlescent_froglight
fill 450 203 241 450 205 241 minecraft:tuff
setblock 450 203 242 minecraft:andesite
setblock 450 203 243 minecraft:tuff
fill 450 203 245 452 203 245 minecraft:tuff
setblock 450 203 246 minecraft:andesite
setblock 450 203 249 minecraft:cobbled_deepslate
setblock 450 203 250 minecraft:andesite
fill 450 203 251 450 203 253 minecraft:tuff
setblock 450 203 254 minecraft:andesite
fill 450 203 257 450 205 257 minecraft:tuff
setblock 450 203 258 minecraft:cobbled_deepslate
setblock 451 203 242 minecraft:cobbled_deepslate
setblock 451 203 243 minecraft:andesite
fill 451 203 246 452 204 246 minecraft:tuff
setblock 451 203 247 minecraft:andesite
fill 451 203 250 453 203 250 minecraft:tuff
setblock 451 203 251 minecraft:cobbled_deepslate
setblock 451 203 252 minecraft:tuff
fill 451 203 254 451 204 254 minecraft:tuff
setblock 451 203 255 minecraft:andesite
fill 452 203 243 452 205 243 minecraft:tuff
setblock 452 203 244 minecraft:cobbled_deepslate
fill 452 203 247 454 203 247 minecraft:tuff
setblock 452 203 248 minecraft:andesite
fill 452 203 251 452 205 251 minecraft:tuff
setblock 452 203 252 minecraft:andesite
setblock 452 203 253 minecraft:cobbled_deepslate
fill 452 203 255 452 205 255 minecraft:tuff
setblock 452 203 256 minecraft:andesite
fill 453 203 244 453 205 244 minecraft:tuff
setblock 453 203 245 minecraft:andesite
setblock 453 203 246 minecraft:cobbled_deepslate
fill 453 203 248 453 205 248 minecraft:tuff
setblock 453 203 249 minecraft:andesite
setblock 453 203 252 minecraft:tuff
setblock 453 203 253 minecraft:andesite
setblock 453 203 255 minecraft:cobbled_deepslate
setblock 454 203 248 minecraft:cobbled_deepslate
fill 454 203 249 454 205 249 minecraft:tuff
setblock 454 203 250 minecraft:andesite
setblock 454 203 251 minecraft:tuff
fill 454 203 253 454 205 253 minecraft:tuff
fill 460 203 245 462 203 249 minecraft:blue_stained_glass
fill 460 203 253 462 203 257 minecraft:blue_stained_glass
fill 464 203 270 464 236 270 minecraft:black_concrete
fill 465 203 232 465 255 232 minecraft:black_concrete
setblock 465 203 236 minecraft:sea_lantern
setblock 465 203 247 minecraft:white_concrete
fill 465 203 262 465 210 262 minecraft:black_concrete
fill 465 203 264 465 232 264 minecraft:black_concrete
setblock 465 203 269 minecraft:purple_concrete
fill 423 204 239 423 308 239 minecraft:black_concrete
setblock 423 204 260 minecraft:blue_concrete
setblock 424 204 270 minecraft:sea_lantern
setblock 426 204 231 minecraft:light[level=12]
setblock 426 204 238 minecraft:light[level=12]
setblock 426 204 245 minecraft:light[level=12]
setblock 426 204 252 minecraft:light[level=12]
setblock 426 204 259 minecraft:light[level=12]
setblock 426 204 266 minecraft:light[level=12]
setblock 427 204 228 minecraft:sea_lantern
fill 433 204 228 433 286 228 minecraft:black_concrete
setblock 433 204 231 minecraft:light[level=12]
setblock 433 204 238 minecraft:light[level=12]
setblock 433 204 245 minecraft:light[level=12]
setblock 433 204 248 minecraft:cobbled_deepslate
setblock 433 204 250 minecraft:andesite
setblock 433 204 252 minecraft:light[level=12]
setblock 433 204 259 minecraft:light[level=12]
setblock 433 204 266 minecraft:light[level=12]
fill 434 204 245 435 204 246 minecraft:tuff
setblock 434 204 247 minecraft:andesite
fill 434 204 248 434 204 249 minecraft:tuff
setblock 434 204 250 minecraft:cobbled_deepslate
setblock 434 204 251 minecraft:andesite
fill 434 204 252 434 204 254 minecraft:tuff
setblock 435 204 244 minecraft:andesite
fill 435 204 247 435 206 247 minecraft:tuff
setblock 435 204 248 minecraft:andesite
fill 435 204 249 435 204 251 minecraft:tuff
setblock 435 204 252 minecraft:cobbled_deepslate
fill 435 204 253 435 204 255 minecraft:tuff
setblock 435 204 256 minecraft:andesite
fill 436 204 228 437 212 228 minecraft:black_concrete
setblock 436 204 242 minecraft:tuff
fill 436 204 244 436 206 244 minecraft:tuff
setblock 436 204 245 minecraft:cobbled_deepslate
setblock 436 204 246 minecraft:tuff
fill 436 204 248 436 205 248 minecraft:tuff
setblock 436 204 249 minecraft:andesite
fill 436 204 252 436 206 252 minecraft:tuff
setblock 436 204 253 minecraft:andesite
setblock 436 204 254 minecraft:cobbled_deepslate
fill 436 204 255 436 205 256 minecraft:tuff
setblock 436 204 257 minecraft:andesite
fill 437 204 241 437 205 241 minecraft:tuff
setblock 437 204 242 minecraft:andesite
fill 437 204 245 437 206 245 minecraft:tuff
setblock 437 204 246 minecraft:andesite
setblock 437 204 247 minecraft:cobbled_deepslate
fill 437 204 249 437 206 249 minecraft:tuff
setblock 437 204 250 minecraft:andesite
setblock 437 204 253 minecraft:tuff
setblock 437 204 254 minecraft:andesite
setblock 437 204 255 minecraft:tuff
setblock 437 204 256 minecraft:cobbled_deepslate
fill 437 204 257 439 204 257 minecraft:tuff
setblock 437 204 258 minecraft:andesite
fill 438 204 242 438 206 242 minecraft:tuff
setblock 438 204 243 minecraft:andesite
fill 438 204 246 440 204 246 minecraft:tuff
setblock 438 204 247 minecraft:andesite
setblock 438 204 249 minecraft:cobbled_deepslate
fill 438 204 250 438 206 250 minecraft:tuff
setblock 438 204 251 minecraft:andesite
setblock 438 204 252 minecraft:tuff
fill 438 204 254 439 205 254 minecraft:tuff
setblock 438 204 255 minecraft:andesite
setblock 438 204 256 minecraft:tuff
setblock 438 204 258 minecraft:cobbled_deepslate
setblock 439 204 240 minecraft:andesite
setblock 439 204 242 minecraft:cobbled_deepslate
fill 439 204 243 441 204 243 minecraft:tuff
setblock 439 204 244 minecraft:andesite
setblock 439 204 245 minecraft:tuff
fill 439 204 247 440 205 247 minecraft:tuff
setblock 439 204 248 minecraft:andesite
setblock 439 204 251 minecraft:cobbled_deepslate
setblock 439 204 252 minecraft:andesite
setblock 439 204 253 minecraft:tuff
fill 439 204 255 439 206 255 minecraft:tuff
setblock 439 204 256 minecraft:andesite
fill 439 204 259 441 204 259 minecraft:tuff
setblock 440 204 231 minecraft:light[level=12]
setblock 440 204 238 minecraft:light[level=12]
fill 440 204 239 441 204 240 minecraft:tuff
setblock 440 204 241 minecraft:andesite
setblock 440 204 242 minecraft:tuff
setblock 440 204 244 minecraft:cobbled_deepslate
setblock 440 204 245 minecraft:andesite
fill 440 204 248 440 206 248 minecraft:tuff
setblock 440 204 249 minecraft:andesite
setblock 440 204 253 minecraft:cobbled_deepslate
fill 440 204 256 440 205 256 minecraft:tuff
setblock 440 204 257 minecraft:andesite
setblock 440 204 266 minecraft:light[level=12]
fill 441 204 241 441 206 241 minecraft:tuff
setblock 441 204 242 minecraft:andesite
fill 441 204 245 441 206 245 minecraft:tuff
setblock 441 204 246 minecraft:cobbled_deepslate
setblock 441 204 255 minecraft:cobbled_deepslate
fill 441 204 257 441 206 257 minecraft:tuff
setblock 441 204 258 minecraft:andesite
fill 441 204 260 442 204 260 minecraft:tuff
setblock 442 204 239 minecraft:cobbled_deepslate
fill 442 204 242 442 205 242 minecraft:tuff
setblock 442 204 243 minecraft:andesite
fill 442 204 246 442 206 246 minecraft:tuff
setblock 442 204 247 minecraft:andesite
setblock 442 204 255 minecraft:andesite
setblock 442 204 257 minecraft:cobbled_deepslate
fill 442 204 258 444 204 258 minecraft:tuff
setblock 442 204 259 minecraft:andesite
fill 443 204 238 443 204 239 minecraft:tuff
setblock 443 204 240 minecraft:andesite
setblock 443 204 241 minecraft:cobbled_deepslate
fill 443 204 243 443 206 243 minecraft:tuff
setblock 443 204 244 minecraft:andesite
setblock 443 204 256 minecraft:andesite
setblock 443 204 257 minecraft:tuff
setblock 443 204 259 minecraft:cobbled_deepslate
setblock 443 204 260 minecraft:andesite
setblock 444 204 238 minecraft:tuff
setblock 444 204 240 minecraft:tuff
setblock 444 204 241 minecraft:andesite
setblock 444 204 243 minecraft:cobbled_deepslate
fill 444 204 244 446 204 244 minecraft:tuff
setblock 444 204 245 minecraft:andesite
setblock 444 204 246 minecraft:tuff
fill 444 204 256 444 206 256 minecraft:tuff
setblock 444 204 257 minecraft:andesite
fill 444 204 260 446 204 260 minecraft:tuff
setblock 445 204 238 minecraft:andesite
setblock 445 204 239 minecraft:tuff
fill 445 204 241 446 205 241 minecraft:tuff
setblock 445 204 242 minecraft:andesite
setblock 445 204 243 minecraft:tuff
setblock 445 204 245 minecraft:cobbled_deepslate
setblock 445 204 246 minecraft:andesite
fill 445 204 257 445 205 257 minecraft:tuff
setblock 445 204 258 minecraft:andesite
setblock 446 204 238 minecraft:cobbled_deepslate
setblock 446 204 239 minecraft:andesite
setblock 446 204 240 minecraft:tuff
fill 446 204 242 447 205 242 minecraft:tuff
setblock 446 204 243 minecraft:andesite
fill 446 204 246 446 206 246 minecraft:tuff
setblock 446 204 247 minecraft:cobbled_deepslate
setblock 446 204 255 minecraft:andesite
setblock 446 204 256 minecraft:cobbled_deepslate
fill 446 204 258 446 206 258 minecraft:tuff
setblock 446 204 259 minecraft:andesite
setblock 447 204 231 minecraft:light[level=12]
setblock 447 204 238 minecraft:light[level=12]
fill 447 204 239 447 206 239 minecraft:tuff
setblock 447 204 240 minecraft:cobbled_deepslate
fill 447 204 243 447 205 243 minecraft:tuff
setblock 447 204 244 minecraft:andesite
fill 447 204 247 447 206 247 minecraft:tuff
setblock 447 204 255 minecraft:tuff
setblock 447 204 256 minecraft:andesite
setblock 447 204 258 minecraft:cobbled_deepslate
fill 447 204 259 448 205 259 minecraft:tuff
setblock 447 204 266 minecraft:light[level=12]
fill 448 204 240 448 206 240 minecraft:tuff
setblock 448 204 241 minecraft:andesite
setblock 448 204 242 minecraft:cobbled_deepslate
fill 448 204 244 448 206 244 minecraft:tuff
setblock 448 204 245 minecraft:andesite
fill 448 204 248 450 204 248 minecraft:tuff
setblock 448 204 249 minecraft:andesite
setblock 448 204 253 minecraft:andesite
setblock 448 204 254 minecraft:tuff
fill 448 204 256 449 205 256 minecraft:tuff
setblock 448 204 257 minecraft:andesite
setblock 448 204 258 minecraft:tuff
setblock 449 204 239 minecraft:tuff
setblock 449 204 241 minecraft:tuff
setblock 449 204 242 minecraft:andesite
setblock 449 204 244 minecraft:cobbled_deepslate
fill 449 204 245 451 204 245 minecraft:tuff
setblock 449 204 246 minecraft:andesite
setblock 449 204 247 minecraft:tuff
fill 449 204 249 451 204 249 minecraft:tuff
setblock 449 204 250 minecraft:andesite
fill 449 204 251 449 204 252 minecraft:tuff
setblock 449 204 253 minecraft:cobbled_deepslate
setblock 449 204 254 minecraft:andesite
setblock 449 204 255 minecraft:tuff
fill 449 204 257 449 206 257 minecraft:tuff
setblock 449 204 258 minecraft:andesite
fill 449 204 270 449 308 270 minecraft:black_concrete
setblock 450 204 228 minecraft:white_concrete
setblock 450 204 240 minecraft:tuff
fill 450 204 242 452 204 242 minecraft:tuff
setblock 450 204 243 minecraft:andesite
setblock 450 204 246 minecraft:cobbled_deepslate
setblock 450 204 247 minecraft:andesite
fill 450 204 250 451 205 250 minecraft:tuff
setblock 450 204 251 minecraft:andesite
fill 450 204 252 450 204 254 minecraft:tuff
setblock 450 204 255 minecraft:cobbled_deepslate
fill 450 204 258 450 205 258 minecraft:tuff
setblock 451 204 241 minecraft:tuff
fill 451 204 243 451 206 243 minecraft:tuff
setblock 451 204 244 minecraft:andesite
fill 451 204 247 453 204 247 minecraft:tuff
setblock 451 204 248 minecraft:cobbled_deepslate
fill 451 204 251 451 205 251 minecraft:tuff
setblock 451 204 252 minecraft:andesite
fill 451 204 255 451 206 255 minecraft:tuff
setblock 451 204 256 minecraft:andesite
setblock 451 204 257 minecraft:cobbled_deepslate
fill 452 204 244 452 205 244 minecraft:tuff
setblock 452 204 245 minecraft:andesite
fill 452 204 248 452 206 248 minecraft:tuff
setblock 452 204 249 minecraft:andesite
setblock 452 204 250 minecraft:cobbled_deepslate
fill 452 204 252 452 206 252 minecraft:tuff
setblock 452 204 253 minecraft:andesite
setblock 452 204 256 minecraft:tuff
setblock 453 204 243 minecraft:cobbled_deepslate
fill 453 204 245 453 206 245 minecraft:tuff
setblock 453 204 246 minecraft:andesite
setblock 453 204 249 minecraft:tuff
setblock 453 204 250 minecraft:andesite
setblock 453 204 252 minecraft:cobbled_deepslate
fill 453 204 253 453 206 253 minecraft:tuff
setblock 453 204 254 minecraft:andesite
setblock 453 204 255 minecraft:tuff
setblock 453 204 270 minecraft:ochre_froglight
setblock 454 204 228 minecraft:white_concrete
setblock 454 204 231 minecraft:light[level=12]
setblock 454 204 238 minecraft:light[level=12]
setblock 454 204 245 minecraft:cobbled_deepslate
fill 454 204 246 454 206 246 minecraft:tuff
setblock 454 204 247 minecraft:andesite
setblock 454 204 248 minecraft:tuff
fill 454 204 250 454 206 250 minecraft:tuff
setblock 454 204 251 minecraft:andesite
setblock 454 204 259 minecraft:light[level=12]
setblock 454 204 266 minecraft:light[level=12]
setblock 455 204 249 minecraft:tuff
setblock 461 204 231 minecraft:light[level=12]
setblock 461 204 238 minecraft:light[level=12]
setblock 461 204 245 minecraft:light[level=12]
setblock 461 204 259 minecraft:light[level=12]
setblock 461 204 266 minecraft:light[level=12]
fill 465 204 236 465 227 236 minecraft:black_concrete
fill 465 204 247 465 216 247 minecraft:black_concrete
setblock 465 204 259 minecraft:magenta_terracotta
fill 465 204 269 465 205 269 minecraft:black_concrete
fill 423 205 260 423 247 260 minecraft:black_concrete
setblock 423 205 261 minecraft:pearlescent_froglight
fill 424 205 270 424 230 270 minecraft:black_concrete
setblock 426 205 231 minecraft:light[level=15]
setblock 426 205 239 minecraft:light[level=15]
setblock 426 205 247 minecraft:light[level=15]
setblock 426 205 255 minecraft:light[level=15]
setblock 426 205 263 minecraft:light[level=15]
fill 427 205 228 427 211 228 minecraft:black_concrete
setblock 432 205 228 minecraft:ochre_froglight
fill 433 205 249 434 205 250 minecraft:tuff
setblock 433 205 251 minecraft:andesite
setblock 433 205 252 minecraft:tuff
setblock 434 205 231 minecraft:light[level=15]
setblock 434 205 239 minecraft:light[level=15]
fill 434 205 245 434 205 246 minecraft:tuff
setblock 434 205 247 minecraft:cobbled_deepslate
setblock 434 205 248 minecraft:andesite
fill 434 205 251 435 206 251 minecraft:tuff
setblock 434 205 252 minecraft:andesite
fill 434 205 253 434 205 254 minecraft:tuff
setblock 434 205 255 minecraft:light[level=15]
setblock 434 205 263 minecraft:light[level=15]
fill 435 205 243 435 206 244 minecraft:tuff
setblock 435 205 245 minecraft:andesite
setblock 435 205 246 minecraft:tuff
fill 435 205 248 435 207 248 minecraft:tuff
setblock 435 205 249 minecraft:cobbled_deepslate
setblock 435 205 250 minecraft:tuff
fill 435 205 252 435 206 252 minecraft:tuff
setblock 435 205 253 minecraft:andesite
fill 435 205 254 435 205 256 minecraft:tuff
setblock 436 205 242 minecraft:cobbled_deepslate
setblock 436 205 243 minecraft:tuff
fill 436 205 245 436 206 245 minecraft:tuff
setblock 436 205 246 minecraft:andesite
fill 436 205 249 436 207 249 minecraft:tuff
setblock 436 205 250 minecraft:andesite
setblock 436 205 251 minecraft:cobbled_deepslate
fill 436 205 253 436 207 253 minecraft:tuff
setblock 436 205 254 minecraft:andesite
fill 436 205 257 438 205 257 minecraft:tuff
fill 437 205 242 437 207 242 minecraft:tuff
setblock 437 205 243 minecraft:andesite
setblock 437 205 244 minecraft:cobbled_deepslate
fill 437 205 246 437 207 246 minecraft:tuff
setblock 437 205 247 minecraft:andesite
setblock 437 205 250 minecraft:tuff
setblock 437 205 251 minecraft:andesite
setblock 437 205 253 minecraft:cobbled_deepslate
fill 437 205 254 437 207 254 minecraft:tuff
setblock 437 205 255 minecraft:andesite
setblock 437 205 256 minecraft:tuff
fill 437 205 258 439 205 258 minecraft:tuff
setblock 438 205 240 minecraft:andesite
fill 438 205 243 440 205 243 minecraft:tuff
setblock 438 205 244 minecraft:andesite
setblock 438 205 246 minecraft:cobbled_deepslate
fill 438 205 247 438 207 247 minecraft:tuff
setblock 438 205 248 minecraft:andesite
setblock 438 205 249 minecraft:tuff
fill 438 205 251 439 206 251 minecraft:tuff
setblock 438 205 252 minecraft:andesite
setblock 438 205 255 minecraft:cobbled_deepslate
setblock 438 205 256 minecraft:andesite
fill 438 205 259 439 206 259 minecraft:tuff
fill 439 205 240 441 205 240 minecraft:tuff
setblock 439 205 241 minecraft:andesite
setblock 439 205 242 minecraft:tuff
fill 439 205 244 440 206 244 minecraft:tuff
setblock 439 205 245 minecraft:andesite
setblock 439 205 246 minecraft:tuff
setblock 439 205 248 minecraft:cobbled_deepslate
setblock 439 205 249 minecraft:andesite
fill 439 205 252 439 207 252 minecraft:tuff
setblock 439 205 253 minecraft:andesite
fill 439 205 256 439 207 256 minecraft:tuff
setblock 439 205 257 minecraft:cobbled_deepslate
setblock 440 205 239 minecraft:tuff
setblock 440 205 241 minecraft:cobbled_deepslate
setblock 440 205 242 minecraft:andesite
fill 440 205 245 440 207 245 minecraft:tuff
setblock 440 205 246 minecraft:andesite
fill 440 205 249 440 207 249 minecraft:tuff
fill 440 205 253 440 206 253 minecraft:tuff
setblock 440 205 254 minecraft:andesite
fill 440 205 257 440 207 257 minecraft:tuff
setblock 440 205 258 minecraft:andesite
setblock 440 205 259 minecraft:cobbled_deepslate
fill 440 205 260 441 205 260 minecraft:tuff
setblock 441 205 239 minecraft:andesite
fill 441 205 242 441 207 242 minecraft:tuff
setblock 441 205 243 minecraft:cobbled_deepslate
fill 441 205 246 441 206 246 minecraft:tuff
setblock 441 205 247 minecraft:andesite
setblock 441 205 255 minecraft:andesite
fill 441 205 258 443 205 258 minecraft:tuff
setblock 441 205 259 minecraft:andesite
setblock 442 205 231 minecraft:light[level=15]
fill 442 205 239 443 206 239 minecraft:tuff
setblock 442 205 240 minecraft:andesite
setblock 442 205 241 minecraft:tuff
fill 442 205 243 442 207 243 minecraft:tuff
setblock 442 205 244 minecraft:andesite
setblock 442 205 245 minecraft:cobbled_deepslate
fill 442 205 247 442 207 247 minecraft:tuff
fill 442 205 255 442 207 255 minecraft:tuff
setblock 442 205 256 minecraft:andesite
setblock 442 205 257 minecraft:tuff
fill 442 205 259 444 205 259 minecraft:tuff
setblock 442 205 260 minecraft:andesite
setblock 442 205 263 minecraft:light[level=15]
setblock 443 205 238 minecraft:cobbled_deepslate
fill 443 205 240 443 207 240 minecraft:tuff
setblock 443 205 241 minecraft:andesite
fill 443 205 244 445 205 244 minecraft:tuff
setblock 443 205 245 minecraft:andesite
setblock 443 205 256 minecraft:cobbled_deepslate
setblock 443 205 257 minecraft:andesite
fill 443 205 260 444 206 260 minecraft:tuff
setblock 444 205 238 minecraft:andesite
setblock 444 205 240 minecraft:cobbled_deepslate
fill 444 205 241 444 207 241 minecraft:tuff
setblock 444 205 242 minecraft:andesite
setblock 444 205 243 minecraft:tuff
fill 444 205 245 445 206 245 minecraft:tuff
setblock 444 205 246 minecraft:andesite
fill 444 205 257 444 207 257 minecraft:tuff
setblock 444 205 258 minecraft:cobbled_deepslate
fill 445 205 238 446 205 238 minecraft:tuff
setblock 445 205 239 minecraft:andesite
setblock 445 205 242 minecraft:cobbled_deepslate
setblock 445 205 243 minecraft:andesite
fill 445 205 246 445 207 246 minecraft:tuff
fill 445 205 258 445 207 258 minecraft:tuff
setblock 445 205 259 minecraft:andesite
setblock 445 205 260 minecraft:cobbled_deepslate
fill 446 205 239 446 207 239 minecraft:tuff
setblock 446 205 240 minecraft:andesite
fill 446 205 243 446 207 243 minecraft:tuff
setblock 446 205 244 minecraft:cobbled_deepslate
fill 446 205 247 446 206 247 minecraft:tuff
fill 446 205 255 446 207 255 minecraft:tuff
setblock 446 205 256 minecraft:andesite
setblock 446 205 259 minecraft:tuff
setblock 446 205 260 minecraft:andesite
fill 447 205 240 447 206 240 minecraft:tuff
setblock 447 205 241 minecraft:andesite
fill 447 205 244 447 207 244 minecraft:tuff
setblock 447 205 245 minecraft:andesite
setblock 447 205 246 minecraft:cobbled_deepslate
setblock 447 205 255 minecraft:cobbled_deepslate
fill 447 205 256 447 207 256 minecraft:tuff
setblock 447 205 257 minecraft:andesite
setblock 447 205 258 minecraft:tuff
fill 447 205 260 447 207 260 minecraft:tuff
setblock 448 205 239 minecraft:cobbled_deepslate
fill 448 205 241 448 207 241 minecraft:tuff
setblock 448 205 242 minecraft:andesite
fill 448 205 245 450 205 245 minecraft:tuff
setblock 448 205 246 minecraft:andesite
setblock 448 205 248 minecraft:cobbled_deepslate
fill 448 205 249 450 205 249 minecraft:tuff
fill 448 205 253 450 205 253 minecraft:tuff
setblock 448 205 254 minecraft:andesite
setblock 448 205 257 minecraft:cobbled_deepslate
setblock 448 205 258 minecraft:andesite
setblock 449 205 239 minecraft:andesite
setblock 449 205 241 minecraft:cobbled_deepslate
fill 449 205 242 451 205 242 minecraft:tuff
setblock 449 205 243 minecraft:andesite
setblock 449 205 244 minecraft:tuff
fill 449 205 246 451 205 246 minecraft:tuff
setblock 449 205 247 minecraft:andesite
setblock 449 205 248 minecraft:tuff
setblock 449 205 250 minecraft:cobbled_deepslate
setblock 449 205 251 minecraft:andesite
setblock 449 205 252 minecraft:tuff
fill 449 205 254 450 206 254 minecraft:tuff
setblock 449 205 255 minecraft:andesite
fill 449 205 258 449 207 258 minecraft:tuff
setblock 449 205 259 minecraft:cobbled_deepslate
fill 450 205 228 450 223 228 minecraft:black_concrete
setblock 450 205 231 minecraft:light[level=15]
setblock 450 205 239 minecraft:light[level=15]
setblock 450 205 240 minecraft:andesite
setblock 450 205 243 minecraft:cobbled_deepslate
setblock 450 205 244 minecraft:andesite
fill 450 205 247 451 206 247 minecraft:tuff
setblock 450 205 248 minecraft:andesite
fill 450 205 251 450 207 251 minecraft:tuff
setblock 450 205 252 minecraft:cobbled_deepslate
fill 450 205 255 450 206 255 minecraft:tuff
setblock 450 205 256 minecraft:andesite
setblock 450 205 263 minecraft:light[level=15]
setblock 451 205 241 minecraft:andesite
fill 451 205 244 451 207 244 minecraft:tuff
setblock 451 205 245 minecraft:cobbled_deepslate
fill 451 205 248 451 206 248 minecraft:tuff
setblock 451 205 249 minecraft:andesite
fill 451 205 252 451 207 252 minecraft:tuff
setblock 451 205 253 minecraft:andesite
setblock 451 205 254 minecraft:cobbled_deepslate
fill 451 205 256 451 207 256 minecraft:tuff
setblock 451 205 257 minecraft:andesite
fill 452 205 241 452 206 241 minecraft:tuff
setblock 452 205 242 minecraft:andesite
fill 452 205 245 452 207 245 minecraft:tuff
setblock 452 205 246 minecraft:andesite
setblock 452 205 247 minecraft:cobbled_deepslate
fill 452 205 249 452 207 249 minecraft:tuff
setblock 452 205 250 minecraft:andesite
setblock 452 205 253 minecraft:tuff
setblock 452 205 254 minecraft:andesite
setblock 452 205 256 minecraft:cobbled_deepslate
setblock 452 205 270 minecraft:pearlescent_froglight
fill 453 205 242 453 207 242 minecraft:tuff
setblock 453 205 243 minecraft:andesite
setblock 453 205 246 minecraft:tuff
setblock 453 205 247 minecraft:andesite
setblock 453 205 249 minecraft:cobbled_deepslate
fill 453 205 250 453 207 250 minecraft:tuff
setblock 453 205 251 minecraft:andesite
setblock 453 205 252 minecraft:tuff
fill 453 205 254 453 206 254 minecraft:tuff
setblock 453 205 255 minecraft:andesite
fill 453 205 270 453 215 270 minecraft:black_concrete
fill 454 205 228 454 255 228 minecraft:black_concrete
setblock 454 205 244 minecraft:andesite
setblock 454 205 245 minecraft:tuff
fill 454 205 247 455 206 247 minecraft:tuff
setblock 454 205 248 minecraft:andesite
setblock 454 205 251 minecraft:cobbled_deepslate
setblock 454 205 252 minecraft:andesite
fill 455 205 248 455 207 248 minecraft:tuff
setblock 455 205 249 minecraft:andesite
setblock 455 205 250 minecraft:tuff
setblock 458 205 231 minecraft:light[level=15]
setblock 458 205 239 minecraft:light[level=15]
setblock 458 205 247 minecraft:light[level=15]
setblock 458 205 255 minecraft:light[level=15]
setblock 458 205 263 minecraft:light[level=15]
fill 461 205 251 461 206 251 minecraft:iron_bars
fill 465 205 259 465 223 259 minecraft:black_concrete
setblock 465 205 260 minecraft:white_concrete
fill 423 206 261 423 256 261 minecraft:black_concrete
fill 432 206 228 432 207 228 minecraft:black_concrete
fill 433 206 249 433 206 250 minecraft:tuff
setblock 433 206 251 minecraft:cobbled_deepslate
setblock 433 206 252 minecraft:andesite
setblock 434 206 245 minecraft:andesite
fill 434 206 246 434 206 248 minecraft:tuff
setblock 434 206 249 minecraft:andesite
setblock 434 206 250 minecraft:tuff
fill 434 206 252 434 208 252 minecraft:tuff
setblock 434 206 253 minecraft:cobbled_deepslate
setblock 434 206 254 minecraft:tuff
fill 435 206 245 435 208 245 minecraft:tuff
setblock 435 206 246 minecraft:cobbled_deepslate
fill 435 206 249 435 207 249 minecraft:tuff
setblock 435 206 250 minecraft:andesite
fill 435 206 253 435 208 253 minecraft:tuff
setblock 435 206 254 minecraft:andesite
setblock 435 206 255 minecraft:cobbled_deepslate
fill 435 206 256 436 206 256 minecraft:tuff
fill 436 206 242 436 207 242 minecraft:tuff
setblock 436 206 243 minecraft:andesite
fill 436 206 246 436 208 246 minecraft:tuff
setblock 436 206 247 minecraft:andesite
setblock 436 206 248 minecraft:cobbled_deepslate
fill 436 206 250 436 208 250 minecraft:tuff
setblock 436 206 251 minecraft:andesite
setblock 436 206 254 minecraft:tuff
setblock 436 206 255 minecraft:andesite
setblock 436 206 257 minecraft:cobbled_deepslate
setblock 437 206 241 minecraft:cobbled_deepslate
fill 437 206 243 437 208 243 minecraft:tuff
setblock 437 206 244 minecraft:andesite
setblock 437 206 247 minecraft:tuff
setblock 437 206 248 minecraft:andesite
setblock 437 206 250 minecraft:cobbled_deepslate
fill 437 206 251 437 208 251 minecraft:tuff
setblock 437 206 252 minecraft:andesite
setblock 437 206 253 minecraft:tuff
fill 437 206 255 438 207 255 minecraft:tuff
setblock 437 206 256 minecraft:andesite
fill 437 206 257 437 206 258 minecraft:tuff
fill 438 206 240 440 206 240 minecraft:tuff
setblock 438 206 241 minecraft:andesite
setblock 438 206 243 minecraft:cobbled_deepslate
fill 438 206 244 438 208 244 minecraft:tuff
setblock 438 206 245 minecraft:andesite
setblock 438 206 246 minecraft:tuff
fill 438 206 248 439 207 248 minecraft:tuff
setblock 438 206 249 minecraft:andesite
setblock 438 206 252 minecraft:cobbled_deepslate
setblock 438 206 253 minecraft:andesite
setblock 438 206 254 minecraft:tuff
fill 438 206 256 438 208 256 minecraft:tuff
setblock 438 206 257 minecraft:andesite
setblock 438 206 258 minecraft:tuff
setblock 439 206 239 minecraft:tuff
fill 439 206 241 440 207 241 minecraft:tuff
setblock 439 206 242 minecraft:andesite
setblock 439 206 243 minecraft:tuff
setblock 439 206 245 minecraft:cobbled_deepslate
setblock 439 206 246 minecraft:andesite
setblock 439 206 247 minecraft:tuff
fill 439 206 249 439 208 249 minecraft:tuff
setblock 439 206 250 minecraft:andesite
fill 439 206 253 439 208 253 minecraft:tuff
setblock 439 206 254 minecraft:cobbled_deepslate
fill 439 206 257 439 207 257 minecraft:tuff
setblock 439 206 258 minecraft:andesite
setblock 440 206 239 minecraft:andesite
fill 440 206 242 440 208 242 minecraft:tuff
setblock 440 206 243 minecraft:andesite
fill 440 206 246 440 208 246 minecraft:tuff
setblock 440 206 247 minecraft:cobbled_deepslate
fill 440 206 254 440 208 254 minecraft:tuff
setblock 440 206 255 minecraft:andesite
setblock 440 206 256 minecraft:cobbled_deepslate
fill 440 206 258 440 208 258 minecraft:tuff
setblock 440 206 259 minecraft:andesite
setblock 440 206 260 minecraft:tuff
fill 441 206 239 441 208 239 minecraft:tuff
setblock 441 206 240 minecraft:cobbled_deepslate
fill 441 206 243 441 207 243 minecraft:tuff
setblock 441 206 244 minecraft:andesite
fill 441 206 247 441 208 247 minecraft:tuff
setblock 441 206 255 minecraft:tuff
setblock 441 206 256 minecraft:andesite
setblock 441 206 258 minecraft:cobbled_deepslate
fill 441 206 259 443 206 259 minecraft:tuff
setblock 441 206 260 minecraft:andesite
fill 442 206 240 442 208 240 minecraft:tuff
setblock 442 206 241 minecraft:andesite
setblock 442 206 242 minecraft:cobbled_deepslate
fill 442 206 244 442 208 244 minecraft:tuff
setblock 442 206 245 minecraft:andesite
fill 442 206 256 443 207 256 minecraft:tuff
setblock 442 206 257 minecraft:andesite
setblock 442 206 258 minecraft:tuff
setblock 442 206 260 minecraft:cobbled_deepslate
setblock 443 206 241 minecraft:tuff
setblock 443 206 242 minecraft:andesite
setblock 443 206 244 minecraft:cobbled_deepslate
fill 443 206 245 443 208 245 minecraft:tuff
setblock 443 206 246 minecraft:andesite
fill 443 206 257 443 208 257 minecraft:tuff
setblock 443 206 258 minecraft:andesite
setblock 444 206 238 minecraft:tuff
setblock 444 206 239 minecraft:andesite
setblock 444 206 240 minecraft:tuff
fill 444 206 242 446 206 242 minecraft:tuff
setblock 444 206 243 minecraft:andesite
setblock 444 206 244 minecraft:tuff
setblock 444 206 246 minecraft:cobbled_deepslate
fill 444 206 258 444 207 258 minecraft:tuff
setblock 444 206 259 minecraft:andesite
setblock 445 206 239 minecraft:cobbled_deepslate
setblock 445 206 240 minecraft:andesite
setblock 445 206 241 minecraft:tuff
fill 445 206 243 445 208 243 minecraft:tuff
setblock 445 206 244 minecraft:andesite
setblock 445 206 256 minecraft:andesite
setblock 445 206 257 minecraft:cobbled_deepslate
fill 445 206 259 445 208 259 minecraft:tuff
setblock 445 206 260 minecraft:andesite
fill 446 206 240 446 208 240 minecraft:tuff
setblock 446 206 241 minecraft:cobbled_deepslate
fill 446 206 244 446 207 244 minecraft:tuff
setblock 446 206 245 minecraft:andesite
setblock 446 206 256 minecraft:tuff
setblock 446 206 257 minecraft:andesite
setblock 446 206 259 minecraft:cobbled_deepslate
fill 446 206 260 446 208 260 minecraft:tuff
fill 447 206 241 447 208 241 minecraft:tuff
setblock 447 206 242 minecraft:andesite
setblock 447 206 243 minecraft:cobbled_deepslate
fill 447 206 245 447 208 245 minecraft:tuff
setblock 447 206 246 minecraft:andesite
setblock 447 206 255 minecraft:tuff
fill 447 206 257 448 207 257 minecraft:tuff
setblock 447 206 258 minecraft:andesite
setblock 447 206 259 minecraft:tuff
setblock 448 206 239 minecraft:andesite
fill 448 206 242 450 206 242 minecraft:tuff
setblock 448 206 243 minecraft:andesite
setblock 448 206 245 minecraft:cobbled_deepslate
fill 448 206 246 450 206 246 minecraft:tuff
setblock 448 206 247 minecraft:andesite
fill 448 206 248 448 206 249 minecraft:tuff
fill 448 206 253 449 206 253 minecraft:tuff
setblock 448 206 254 minecraft:cobbled_deepslate
setblock 448 206 255 minecraft:andesite
setblock 448 206 256 minecraft:tuff
fill 448 206 258 448 208 258 minecraft:tuff
setblock 448 206 259 minecraft:andesite
setblock 449 206 239 minecraft:tuff
setblock 449 206 240 minecraft:andesite
setblock 449 206 241 minecraft:tuff
fill 449 206 243 450 207 243 minecraft:tuff
setblock 449 206 244 minecraft:andesite
setblock 449 206 245 minecraft:tuff
setblock 449 206 247 minecraft:cobbled_deepslate
setblock 449 206 248 minecraft:andesite
fill 449 206 249 449 206 251 minecraft:tuff
setblock 449 206 252 minecraft:andesite
fill 449 206 255 449 208 255 minecraft:tuff
setblock 449 206 256 minecraft:cobbled_deepslate
setblock 449 206 259 minecraft:tuff
setblock 450 206 240 minecraft:cobbled_deepslate
setblock 450 206 241 minecraft:andesite
fill 450 206 244 450 208 244 minecraft:tuff
setblock 450 206 245 minecraft:andesite
fill 450 206 248 450 208 248 minecraft:tuff
setblock 450 206 249 minecraft:cobbled_deepslate
setblock 450 206 250 minecraft:tuff
fill 450 206 252 450 207 252 minecraft:tuff
setblock 450 206 253 minecraft:andesite
fill 450 206 256 450 208 256 minecraft:tuff
setblock 450 206 257 minecraft:andesite
setblock 450 206 258 minecraft:cobbled_deepslate
fill 451 206 240 451 207 241 minecraft:tuff
setblock 451 206 242 minecraft:cobbled_deepslate
fill 451 206 245 451 207 245 minecraft:tuff
setblock 451 206 246 minecraft:andesite
fill 451 206 249 451 208 249 minecraft:tuff
setblock 451 206 250 minecraft:andesite
setblock 451 206 251 minecraft:cobbled_deepslate
fill 451 206 253 451 208 253 minecraft:tuff
setblock 451 206 254 minecraft:andesite
setblock 451 206 257 minecraft:tuff
fill 452 206 242 452 208 242 minecraft:tuff
setblock 452 206 243 minecraft:andesite
setblock 452 206 244 minecraft:cobbled_deepslate
fill 452 206 246 452 208 246 minecraft:tuff
setblock 452 206 247 minecraft:andesite
setblock 452 206 250 minecraft:tuff
setblock 452 206 251 minecraft:andesite
setblock 452 206 253 minecraft:cobbled_deepslate
fill 452 206 254 452 208 254 minecraft:tuff
setblock 452 206 255 minecraft:andesite
setblock 452 206 256 minecraft:tuff
fill 452 206 270 452 220 270 minecraft:black_concrete
fill 453 206 243 454 206 243 minecraft:tuff
setblock 453 206 244 minecraft:andesite
setblock 453 206 246 minecraft:cobbled_deepslate
fill 453 206 247 453 208 247 minecraft:tuff
setblock 453 206 248 minecraft:andesite
setblock 453 206 249 minecraft:tuff
fill 453 206 251 454 207 251 minecraft:tuff
setblock 453 206 252 minecraft:andesite
fill 454 206 244 454 208 244 minecraft:tuff
setblock 454 206 245 minecraft:andesite
setblock 454 206 248 minecraft:cobbled_deepslate
setblock 454 206 249 minecraft:andesite
setblock 454 206 252 minecraft:tuff
setblock 455 206 246 minecraft:andesite
fill 455 206 249 455 207 249 minecraft:tuff
setblock 455 206 250 minecraft:cobbled_deepslate
setblock 465 206 257 minecraft:white_concrete
fill 465 206 260 465 294 260 minecraft:black_concrete
setblock 465 206 269 minecraft:pearlescent_froglight
setblock 423 207 238 minecraft:ochre_froglight
setblock 432 207 270 minecraft:ochre_froglight
setblock 433 207 249 minecraft:andesite
fill 433 207 250 433 207 251 minecraft:tuff
setblock 434 207 245 minecraft:tuff
setblock 434 207 246 minecraft:andesite
fill 434 207 247 434 207 249 minecraft:tuff
setblock 434 207 250 minecraft:cobbled_deepslate
setblock 434 207 251 minecraft:tuff
fill 434 207 253 434 208 253 minecraft:tuff
setblock 435 207 243 minecraft:cobbled_deepslate
setblock 435 207 244 minecraft:tuff
fill 435 207 246 435 208 246 minecraft:tuff
setblock 435 207 247 minecraft:andesite
fill 435 207 250 435 209 250 minecraft:tuff
setblock 435 207 251 minecraft:andesite
setblock 435 207 252 minecraft:cobbled_deepslate
fill 435 207 254 435 208 254 minecraft:tuff
setblock 435 207 255 minecraft:andesite
fill 436 207 243 436 209 243 minecraft:tuff
setblock 436 207 244 minecraft:andesite
setblock 436 207 245 minecraft:cobbled_deepslate
fill 436 207 247 436 209 247 minecraft:tuff
setblock 436 207 248 minecraft:andesite
setblock 436 207 251 minecraft:tuff
setblock 436 207 252 minecraft:andesite
setblock 436 207 254 minecraft:cobbled_deepslate
fill 436 207 255 436 209 255 minecraft:tuff
setblock 436 207 256 minecraft:andesite
setblock 437 207 241 minecraft:andesite
setblock 437 207 244 minecraft:tuff
setblock 437 207 245 minecraft:andesite
setblock 437 207 247 minecraft:cobbled_deepslate
fill 437 207 248 437 209 248 minecraft:tuff
setblock 437 207 249 minecraft:andesite
setblock 437 207 250 minecraft:tuff
fill 437 207 252 438 208 252 minecraft:tuff
setblock 437 207 253 minecraft:andesite
setblock 437 207 256 minecraft:cobbled_deepslate
setblock 437 207 257 minecraft:andesite
setblock 438 207 240 minecraft:cobbled_deepslate
fill 438 207 241 438 209 241 minecraft:tuff
setblock 438 207 242 minecraft:andesite
setblock 438 207 243 minecraft:tuff
fill 438 207 245 439 208 245 minecraft:tuff
setblock 438 207 246 minecraft:andesite
setblock 438 207 249 minecraft:cobbled_deepslate
setblock 438 207 250 minecraft:andesite
setblock 438 207 251 minecraft:tuff
fill 438 207 253 438 209 253 minecraft:tuff
setblock 438 207 254 minecraft:andesite
fill 438 207 257 438 209 257 minecraft:tuff
setblock 438 207 258 minecraft:cobbled_deepslate
setblock 439 207 240 minecraft:tuff
setblock 439 207 242 minecraft:cobbled_deepslate
setblock 439 207 243 minecraft:andesite
setblock 439 207 244 minecraft:tuff
fill 439 207 246 439 209 246 minecraft:tuff
setblock 439 207 247 minecraft:andesite
fill 439 207 250 439 209 250 minecraft:tuff
setblock 439 207 251 minecraft:cobbled_deepslate
fill 439 207 254 439 208 254 minecraft:tuff
setblock 439 207 255 minecraft:andesite
fill 439 207 258 439 209 258 minecraft:tuff
setblock 439 207 259 minecraft:andesite
fill 440 207 239 440 208 239 minecraft:tuff
setblock 440 207 240 minecraft:andesite
fill 440 207 243 440 209 243 minecraft:tuff
setblock 440 207 244 minecraft:cobbled_deepslate
fill 440 207 247 440 208 247 minecraft:tuff
setblock 440 207 248 minecraft:andesite
setblock 440 207 253 minecraft:cobbled_deepslate
fill 440 207 255 440 209 255 minecraft:tuff
setblock 440 207 256 minecraft:andesite
fill 440 207 259 442 207 259 minecraft:tuff
setblock 440 207 260 minecraft:andesite
fill 441 207 240 441 208 240 minecraft:tuff
setblock 441 207 241 minecraft:andesite
fill 441 207 244 441 209 244 minecraft:tuff
setblock 441 207 245 minecraft:andesite
setblock 441 207 246 minecraft:cobbled_deepslate
setblock 441 207 255 minecraft:cobbled_deepslate
fill 441 207 256 441 209 256 minecraft:tuff
setblock 441 207 257 minecraft:andesite
setblock 441 207 258 minecraft:tuff
fill 441 207 260 443 207 260 minecraft:tuff
setblock 442 207 239 minecraft:cobbled_deepslate
fill 442 207 241 442 209 241 minecraft:tuff
setblock 442 207 242 minecraft:andesite
setblock 442 207 245 minecraft:tuff
setblock 442 207 246 minecraft:andesite
setblock 442 207 257 minecraft:cobbled_deepslate
setblock 442 207 258 minecraft:andesite
setblock 443 207 239 minecraft:andesite
setblock 443 207 241 minecraft:cobbled_deepslate
fill 443 207 242 445 207 242 minecraft:tuff
setblock 443 207 243 minecraft:andesite
setblock 443 207 244 minecraft:tuff
fill 443 207 246 444 208 246 minecraft:tuff
fill 443 207 258 443 209 258 minecraft:tuff
setblock 443 207 259 minecraft:cobbled_deepslate
fill 444 207 239 445 208 239 minecraft:tuff
setblock 444 207 240 minecraft:andesite
setblock 444 207 243 minecraft:cobbled_deepslate
setblock 444 207 244 minecraft:andesite
setblock 444 207 245 minecraft:tuff
setblock 444 207 256 minecraft:andesite
fill 444 207 259 444 209 259 minecraft:tuff
setblock 444 207 260 minecraft:andesite
fill 445 207 240 445 209 240 minecraft:tuff
setblock 445 207 241 minecraft:andesite
fill 445 207 244 445 209 244 minecraft:tuff
setblock 445 207 245 minecraft:cobbled_deepslate
fill 445 207 256 445 209 256 minecraft:tuff
setblock 445 207 257 minecraft:andesite
setblock 445 207 260 minecraft:tuff
fill 446 207 241 446 208 241 minecraft:tuff
setblock 446 207 242 minecraft:andesite
fill 446 207 245 446 209 245 minecraft:tuff
setblock 446 207 246 minecraft:andesite
setblock 446 207 247 minecraft:cobbled_deepslate
setblock 446 207 256 minecraft:cobbled_deepslate
fill 446 207 257 446 209 257 minecraft:tuff
setblock 446 207 258 minecraft:andesite
setblock 446 207 259 minecraft:tuff
setblock 447 207 239 minecraft:andesite
setblock 447 207 240 minecraft:cobbled_deepslate
fill 447 207 242 447 209 242 minecraft:tuff
setblock 447 207 243 minecraft:andesite
fill 447 207 246 449 207 246 minecraft:tuff
setblock 447 207 247 minecraft:andesite
setblock 447 207 255 minecraft:andesite
setblock 447 207 258 minecraft:cobbled_deepslate
setblock 447 207 259 minecraft:andesite
setblock 448 207 239 minecraft:tuff
setblock 448 207 240 minecraft:andesite
setblock 448 207 242 minecraft:cobbled_deepslate
fill 448 207 243 448 209 243 minecraft:tuff
setblock 448 207 244 minecraft:andesite
setblock 448 207 245 minecraft:tuff
fill 448 207 247 450 207 247 minecraft:tuff
setblock 448 207 248 minecraft:andesite
setblock 448 207 249 minecraft:tuff
fill 448 207 253 448 207 255 minecraft:tuff
setblock 448 207 256 minecraft:andesite
fill 448 207 259 448 208 259 minecraft:tuff
fill 449 207 240 450 208 240 minecraft:tuff
setblock 449 207 241 minecraft:andesite
setblock 449 207 242 minecraft:tuff
setblock 449 207 244 minecraft:cobbled_deepslate
setblock 449 207 245 minecraft:andesite
fill 449 207 248 449 209 248 minecraft:tuff
setblock 449 207 249 minecraft:andesite
fill 449 207 250 449 207 252 minecraft:tuff
setblock 449 207 253 minecraft:cobbled_deepslate
setblock 449 207 254 minecraft:tuff
fill 449 207 256 449 208 256 minecraft:tuff
setblock 449 207 257 minecraft:andesite
fill 450 207 241 450 209 241 minecraft:tuff
setblock 450 207 242 minecraft:andesite
fill 450 207 245 450 209 245 minecraft:tuff
setblock 450 207 246 minecraft:cobbled_deepslate
fill 450 207 249 450 208 249 minecraft:tuff
setblock 450 207 250 minecraft:andesite
fill 450 207 253 450 209 253 minecraft:tuff
setblock 450 207 254 minecraft:andesite
setblock 450 207 255 minecraft:cobbled_deepslate
fill 450 207 257 450 208 257 minecraft:tuff
fill 451 207 242 451 208 242 minecraft:tuff
setblock 451 207 243 minecraft:andesite
fill 451 207 246 451 209 246 minecraft:tuff
setblock 451 207 247 minecraft:andesite
setblock 451 207 248 minecraft:cobbled_deepslate
fill 451 207 250 451 209 250 minecraft:tuff
setblock 451 207 251 minecraft:andesite
setblock 451 207 254 minecraft:tuff
setblock 451 207 255 minecraft:andesite
setblock 452 207 241 minecraft:cobbled_deepslate
fill 452 207 243 452 209 243 minecraft:tuff
setblock 452 207 244 minecraft:andesite
setblock 452 207 247 minecraft:tuff
setblock 452 207 248 minecraft:andesite
setblock 452 207 250 minecraft:cobbled_deepslate
fill 452 207 251 452 209 251 minecraft:tuff
setblock 452 207 252 minecraft:andesite
setblock 452 207 253 minecraft:tuff
setblock 452 207 255 minecraft:tuff
setblock 453 207 243 minecraft:cobbled_deepslate
fill 453 207 244 453 209 244 minecraft:tuff
setblock 453 207 245 minecraft:andesite
setblock 453 207 246 minecraft:tuff
fill 453 207 248 454 208 248 minecraft:tuff
setblock 453 207 249 minecraft:andesite
setblock 453 207 252 minecraft:cobbled_deepslate
setblock 453 207 253 minecraft:andesite
setblock 454 207 243 minecraft:tuff
setblock 454 207 245 minecraft:cobbled_deepslate
setblock 454 207 246 minecraft:andesite
setblock 454 207 247 minecraft:tuff
fill 454 207 249 454 209 249 minecraft:tuff
setblock 454 207 250 minecraft:andesite
fill 455 207 246 455 208 246 minecraft:tuff
setblock 455 207 247 minecraft:cobbled_deepslate
setblock 458 207 228 minecraft:sea_lantern
setblock 465 207 235 minecraft:pearlescent_froglight
fill 465 207 257 465 267 257 minecraft:black_concrete
fill 465 207 269 465 244 269 minecraft:black_concrete
fill 423 208 238 423 264 238 minecraft:black_concrete
setblock 423 208 242 minecraft:white_concrete
setblock 423 208 255 minecraft:ochre_froglight
setblock 432 208 228 minecraft:white_concrete
fill 432 208 270 432 209 270 minecraft:black_concrete
fill 433 208 249 434 208 249 minecraft:tuff
setblock 433 208 250 minecraft:andesite
fill 434 208 250 434 209 250 minecraft:tuff
setblock 434 208 251 minecraft:andesite
setblock 435 208 243 minecraft:tuff
setblock 435 208 244 minecraft:andesite
fill 435 208 247 435 209 247 minecraft:tuff
setblock 435 208 248 minecraft:andesite
setblock 435 208 249 minecraft:cobbled_deepslate
fill 435 208 251 435 210 251 minecraft:tuff
setblock 435 208 252 minecraft:andesite
setblock 436 208 242 minecraft:cobbled_deepslate
fill 436 208 244 436 210 244 minecraft:tuff
setblock 436 208 245 minecraft:andesite
setblock 436 208 248 minecraft:tuff
setblock 436 208 249 minecraft:andesite
setblock 436 208 251 minecraft:cobbled_deepslate
fill 436 208 252 436 210 252 minecraft:tuff
setblock 436 208 253 minecraft:andesite
setblock 436 208 254 minecraft:tuff
fill 436 208 256 437 208 256 minecraft:tuff
setblock 437 208 241 minecraft:tuff
setblock 437 208 242 minecraft:andesite
setblock 437 208 244 minecraft:cobbled_deepslate
fill 437 208 245 437 210 245 minecraft:tuff
setblock 437 208 246 minecraft:andesite
setblock 437 208 247 minecraft:tuff
fill 437 208 249 438 209 249 minecraft:tuff
setblock 437 208 250 minecraft:andesite
setblock 437 208 253 minecraft:cobbled_deepslate
setblock 437 208 254 minecraft:andesite
setblock 437 208 255 minecraft:tuff
setblock 437 208 257 minecraft:tuff
setblock 438 208 240 minecraft:tuff
fill 438 208 242 439 209 242 minecraft:tuff
setblock 438 208 243 minecraft:andesite
setblock 438 208 246 minecraft:cobbled_deepslate
setblock 438 208 247 minecraft:andesite
setblock 438 208 248 minecraft:tuff
fill 438 208 250 438 210 250 minecraft:tuff
setblock 438 208 251 minecraft:andesite
fill 438 208 254 438 210 254 minecraft:tuff
setblock 438 208 255 minecraft:cobbled_deepslate
setblock 438 208 258 minecraft:tuff
setblock 439 208 228 minecraft:ochre_froglight
setblock 439 208 240 minecraft:andesite
setblock 439 208 241 minecraft:tuff
fill 439 208 243 439 210 243 minecraft:tuff
setblock 439 208 244 minecraft:andesite
fill 439 208 247 439 210 247 minecraft:tuff
setblock 439 208 248 minecraft:cobbled_deepslate
fill 439 208 251 439 209 251 minecraft:tuff
setblock 439 208 252 minecraft:andesite
fill 439 208 255 439 210 255 minecraft:tuff
setblock 439 208 256 minecraft:andesite
setblock 439 208 257 minecraft:cobbled_deepslate
setblock 439 208 259 minecraft:tuff
fill 440 208 240 440 209 240 minecraft:tuff
setblock 440 208 241 minecraft:cobbled_deepslate
fill 440 208 244 440 209 244 minecraft:tuff
setblock 440 208 245 minecraft:andesite
fill 440 208 248 440 210 248 minecraft:tuff
setblock 440 208 249 minecraft:andesite
setblock 440 208 253 minecraft:andesite
setblock 440 208 256 minecraft:tuff
setblock 440 208 257 minecraft:andesite
setblock 440 208 259 minecraft:cobbled_deepslate
setblock 441 208 228 minecraft:sea_lantern
fill 441 208 241 441 210 241 minecraft:tuff
setblock 441 208 242 minecraft:andesite
setblock 441 208 243 minecraft:cobbled_deepslate
fill 441 208 245 441 210 245 minecraft:tuff
setblock 441 208 246 minecraft:andesite
setblock 441 208 255 minecraft:tuff
fill 441 208 257 442 209 257 minecraft:tuff
setblock 441 208 258 minecraft:andesite
fill 441 208 259 441 208 260 minecraft:tuff
setblock 442 208 239 minecraft:andesite
fill 442 208 242 444 208 242 minecraft:tuff
setblock 442 208 243 minecraft:andesite
setblock 442 208 245 minecraft:cobbled_deepslate
fill 442 208 246 442 210 246 minecraft:tuff
setblock 442 208 247 minecraft:andesite
setblock 442 208 255 minecraft:andesite
setblock 442 208 256 minecraft:tuff
fill 442 208 258 442 210 258 minecraft:tuff
setblock 442 208 259 minecraft:andesite
setblock 442 208 260 minecraft:tuff
fill 443 208 239 443 209 239 minecraft:tuff
setblock 443 208 240 minecraft:andesite
setblock 443 208 241 minecraft:tuff
fill 443 208 243 444 209 243 minecraft:tuff
setblock 443 208 244 minecraft:andesite
setblock 443 208 256 minecraft:cobbled_deepslate
fill 443 208 259 443 209 259 minecraft:tuff
setblock 443 208 260 minecraft:andesite
setblock 444 208 240 minecraft:cobbled_deepslate
setblock 444 208 241 minecraft:andesite
fill 444 208 244 444 210 244 minecraft:tuff
setblock 444 208 245 minecraft:andesite
fill 444 208 256 444 210 256 minecraft:tuff
setblock 444 208 257 minecraft:andesite
setblock 444 208 258 minecraft:cobbled_deepslate
setblock 444 208 260 minecraft:tuff
fill 445 208 241 445 210 241 minecraft:tuff
setblock 445 208 242 minecraft:cobbled_deepslate
fill 445 208 245 445 209 245 minecraft:tuff
setblock 445 208 246 minecraft:andesite
setblock 445 208 257 minecraft:tuff
setblock 445 208 258 minecraft:andesite
setblock 445 208 260 minecraft:cobbled_deepslate
setblock 446 208 239 minecraft:andesite
fill 446 208 242 446 210 242 minecraft:tuff
setblock 446 208 243 minecraft:andesite
setblock 446 208 244 minecraft:cobbled_deepslate
fill 446 208 246 446 210 246 minecraft:tuff
setblock 446 208 247 minecraft:andesite
setblock 446 208 255 minecraft:andesite
setblock 446 208 256 minecraft:tuff
fill 446 208 258 447 209 258 minecraft:tuff
setblock 446 208 259 minecraft:andesite
setblock 447 208 239 minecraft:tuff
setblock 447 208 240 minecraft:andesite
setblock 447 208 243 minecraft:tuff
setblock 447 208 244 minecraft:andesite
setblock 447 208 246 minecraft:cobbled_deepslate
fill 447 208 247 449 208 247 minecraft:tuff
setblock 447 208 255 minecraft:cobbled_deepslate
setblock 447 208 256 minecraft:andesite
setblock 447 208 257 minecraft:tuff
setblock 447 208 259 minecraft:tuff
fill 448 208 240 448 209 240 minecraft:tuff
setblock 448 208 241 minecraft:andesite
setblock 448 208 242 minecraft:tuff
fill 448 208 244 449 209 244 minecraft:tuff
setblock 448 208 245 minecraft:andesite
setblock 448 208 246 minecraft:tuff
setblock 448 208 248 minecraft:cobbled_deepslate
setblock 448 208 249 minecraft:andesite
setblock 448 208 253 minecraft:andesite
fill 448 208 254 448 208 256 minecraft:tuff
setblock 448 208 257 minecraft:cobbled_deepslate
setblock 449 208 241 minecraft:cobbled_deepslate
setblock 449 208 242 minecraft:andesite
setblock 449 208 243 minecraft:tuff
fill 449 208 245 449 210 245 minecraft:tuff
setblock 449 208 246 minecraft:andesite
fill 449 208 249 449 210 249 minecraft:tuff
setblock 449 208 250 minecraft:cobbled_deepslate
fill 449 208 251 449 208 253 minecraft:tuff
setblock 449 208 254 minecraft:andesite
fill 449 208 257 449 209 257 minecraft:tuff
setblock 449 208 258 minecraft:andesite
fill 450 208 242 450 210 242 minecraft:tuff
setblock 450 208 243 minecraft:cobbled_deepslate
fill 450 208 246 450 209 246 minecraft:tuff
setblock 450 208 247 minecraft:andesite
fill 450 208 250 450 210 250 minecraft:tuff
setblock 450 208 251 minecraft:andesite
setblock 450 208 252 minecraft:cobbled_deepslate
fill 450 208 254 450 210 254 minecraft:tuff
setblock 450 208 255 minecraft:andesite
setblock 451 208 241 minecraft:tuff
fill 451 208 243 451 210 243 minecraft:tuff
setblock 451 208 244 minecraft:andesite
setblock 451 208 245 minecraft:cobbled_deepslate
fill 451 208 247 451 210 247 minecraft:tuff
setblock 451 208 248 minecraft:andesite
setblock 451 208 251 minecraft:tuff
setblock 451 208 252 minecraft:andesite
setblock 451 208 254 minecraft:cobbled_deepslate
setblock 451 208 255 minecraft:tuff
setblock 452 208 241 minecraft:andesite
setblock 452 208 244 minecraft:tuff
setblock 452 208 245 minecraft:andesite
setblock 452 208 247 minecraft:cobbled_deepslate
fill 452 208 248 452 210 248 minecraft:tuff
setblock 452 208 249 minecraft:andesite
setblock 452 208 250 minecraft:tuff
fill 452 208 252 453 208 252 minecraft:tuff
setblock 452 208 253 minecraft:andesite
setblock 453 208 242 minecraft:andesite
setblock 453 208 243 minecraft:tuff
fill 453 208 245 454 209 245 minecraft:tuff
setblock 453 208 246 minecraft:andesite
setblock 453 208 249 minecraft:cobbled_deepslate
setblock 453 208 250 minecraft:andesite
setblock 453 208 251 minecraft:tuff
setblock 454 208 243 minecraft:andesite
fill 454 208 246 454 209 246 minecraft:tuff
setblock 454 208 247 minecraft:andesite
setblock 454 208 250 minecraft:tuff
setblock 455 208 247 minecraft:tuff
fill 458 208 228 458 225 228 minecraft:black_concrete
setblock 461 208 228 minecraft:ochre_froglight
fill 465 208 235 465 290 235 minecraft:black_concrete
setblock 423 209 236 minecraft:ochre_froglight
fill 423 209 242 423 214 242 minecraft:black_concrete
fill 423 209 255 423 213 255 minecraft:black_concrete
schedule function dropper:buildpart/57_3 1t
