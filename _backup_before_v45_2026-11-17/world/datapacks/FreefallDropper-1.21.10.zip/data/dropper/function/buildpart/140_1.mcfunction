fill 376 92 567 376 97 568 minecraft:black_concrete
setblock 376 92 569 minecraft:purple_concrete
fill 376 92 571 376 97 571 minecraft:black_concrete
fill 376 92 577 376 93 578 minecraft:purple_concrete
fill 376 92 579 376 97 580 minecraft:black_concrete
fill 376 92 588 376 97 588 minecraft:black_concrete
fill 376 92 589 376 92 590 minecraft:purple_concrete
fill 376 92 591 376 97 592 minecraft:black_concrete
fill 376 92 597 376 93 598 minecraft:purple_concrete
fill 376 92 599 377 97 599 minecraft:black_concrete
fill 377 92 557 378 97 557 minecraft:black_concrete
setblock 378 92 599 minecraft:purple_concrete
fill 379 92 557 380 92 557 minecraft:purple_concrete
setblock 379 92 560 minecraft:light[level=12]
setblock 379 92 568 minecraft:light[level=12]
setblock 379 92 576 minecraft:light[level=12]
setblock 379 92 584 minecraft:light[level=12]
setblock 379 92 592 minecraft:light[level=12]
fill 381 92 557 381 97 557 minecraft:black_concrete
fill 381 92 575 382 99 576 minecraft:obsidian
fill 386 92 599 387 93 599 minecraft:purple_concrete
setblock 387 92 560 minecraft:light[level=12]
setblock 387 92 568 minecraft:light[level=12]
setblock 387 92 576 minecraft:light[level=12]
setblock 387 92 584 minecraft:light[level=12]
setblock 387 92 592 minecraft:light[level=12]
fill 388 92 599 389 97 599 minecraft:black_concrete
fill 389 92 557 390 97 557 minecraft:black_concrete
fill 391 92 557 392 93 557 minecraft:purple_concrete
setblock 395 92 560 minecraft:light[level=12]
setblock 395 92 568 minecraft:light[level=12]
setblock 395 92 576 minecraft:light[level=12]
setblock 395 92 584 minecraft:light[level=12]
setblock 395 92 592 minecraft:light[level=12]
fill 395 92 599 395 93 599 minecraft:purple_concrete
fill 397 92 599 397 97 599 minecraft:black_concrete
fill 398 92 557 398 97 557 minecraft:black_concrete
fill 398 92 599 399 92 599 minecraft:purple_concrete
setblock 400 92 557 minecraft:purple_concrete
fill 400 92 599 400 97 599 minecraft:black_concrete
fill 401 92 557 402 97 557 minecraft:black_concrete
fill 403 92 557 403 93 557 minecraft:purple_concrete
setblock 403 92 560 minecraft:light[level=12]
setblock 403 92 568 minecraft:light[level=12]
setblock 403 92 576 minecraft:light[level=12]
setblock 403 92 584 minecraft:light[level=12]
setblock 403 92 592 minecraft:light[level=12]
fill 406 92 599 407 93 599 minecraft:purple_concrete
fill 408 92 599 409 97 599 minecraft:black_concrete
fill 409 92 557 410 97 557 minecraft:black_concrete
fill 411 92 557 412 92 557 minecraft:purple_concrete
setblock 411 92 560 minecraft:light[level=12]
setblock 411 92 568 minecraft:light[level=12]
setblock 411 92 576 minecraft:light[level=12]
setblock 411 92 584 minecraft:light[level=12]
setblock 411 92 592 minecraft:light[level=12]
fill 417 92 599 417 93 599 minecraft:black_concrete
fill 418 92 560 418 97 561 minecraft:black_concrete
fill 418 92 562 418 93 563 minecraft:purple_concrete
fill 418 92 569 418 97 569 minecraft:black_concrete
fill 418 92 570 418 92 571 minecraft:purple_concrete
fill 418 92 572 418 97 572 minecraft:black_concrete
fill 418 92 574 418 93 574 minecraft:purple_concrete
setblock 418 92 575 minecraft:black_concrete
fill 418 92 580 418 97 581 minecraft:black_concrete
fill 418 92 582 418 93 583 minecraft:purple_concrete
fill 418 92 589 418 94 589 minecraft:black_concrete
setblock 418 92 591 minecraft:purple_concrete
fill 418 92 592 418 97 593 minecraft:black_concrete
fill 418 92 594 418 93 595 minecraft:purple_concrete
fill 418 92 599 418 93 599 minecraft:purple_concrete
setblock 376 93 557 minecraft:purple_concrete
fill 376 93 558 376 96 558 minecraft:black_concrete
setblock 376 93 565 minecraft:purple_concrete
fill 376 93 569 376 96 569 minecraft:black_concrete
fill 376 93 585 376 93 586 minecraft:purple_concrete
setblock 376 93 589 minecraft:purple_concrete
fill 376 93 590 376 96 590 minecraft:black_concrete
fill 378 93 599 378 96 599 minecraft:black_concrete
fill 379 93 557 379 96 557 minecraft:black_concrete
setblock 380 93 557 minecraft:purple_concrete
fill 383 93 557 384 93 557 minecraft:purple_concrete
setblock 383 93 599 minecraft:purple_concrete
setblock 394 93 599 minecraft:purple_concrete
fill 398 93 599 399 96 599 minecraft:black_concrete
fill 400 93 557 400 96 557 minecraft:black_concrete
setblock 404 93 557 minecraft:purple_concrete
fill 411 93 557 411 96 557 minecraft:black_concrete
setblock 412 93 557 minecraft:purple_concrete
fill 414 93 599 415 93 599 minecraft:purple_concrete
setblock 415 93 557 minecraft:purple_concrete
fill 418 93 570 418 96 571 minecraft:black_concrete
setblock 418 93 575 minecraft:purple_concrete
setblock 418 93 586 minecraft:purple_concrete
fill 418 93 587 418 95 587 minecraft:black_concrete
fill 418 93 591 418 96 591 minecraft:black_concrete
fill 376 94 557 376 99 557 minecraft:black_concrete
fill 376 94 563 376 95 564 minecraft:purple_concrete
fill 376 94 565 376 99 566 minecraft:black_concrete
fill 376 94 575 376 94 576 minecraft:purple_concrete
fill 376 94 577 376 99 578 minecraft:black_concrete
fill 376 94 584 376 95 584 minecraft:purple_concrete
fill 376 94 585 376 99 586 minecraft:black_concrete
setblock 376 94 587 minecraft:purple_concrete
fill 376 94 589 376 99 589 minecraft:black_concrete
fill 376 94 595 376 95 596 minecraft:purple_concrete
fill 376 94 597 376 99 598 minecraft:black_concrete
fill 380 94 557 380 99 557 minecraft:black_concrete
fill 380 94 575 380 99 576 minecraft:obsidian
fill 381 94 574 382 99 574 minecraft:obsidian
fill 381 94 577 382 99 577 minecraft:obsidian
setblock 382 94 557 minecraft:purple_concrete
fill 383 94 557 384 99 557 minecraft:black_concrete
fill 383 94 575 383 99 576 minecraft:obsidian
fill 383 94 599 383 99 599 minecraft:black_concrete
fill 384 94 599 385 94 599 minecraft:purple_concrete
fill 385 94 557 385 95 557 minecraft:purple_concrete
fill 386 94 599 387 99 599 minecraft:black_concrete
fill 391 94 557 392 99 557 minecraft:black_concrete
fill 392 94 599 393 95 599 minecraft:purple_concrete
fill 393 94 557 394 94 557 minecraft:purple_concrete
fill 394 94 599 395 99 599 minecraft:black_concrete
setblock 396 94 599 minecraft:purple_concrete
fill 403 94 557 404 99 557 minecraft:black_concrete
fill 404 94 599 405 95 599 minecraft:purple_concrete
fill 405 94 557 406 95 557 minecraft:purple_concrete
fill 406 94 599 407 99 599 minecraft:black_concrete
fill 412 94 557 412 99 557 minecraft:black_concrete
fill 413 94 557 414 94 557 minecraft:purple_concrete
fill 413 94 599 413 95 599 minecraft:purple_concrete
fill 414 94 599 415 95 599 minecraft:black_concrete
fill 415 94 557 415 99 557 minecraft:black_concrete
fill 416 94 599 417 94 599 minecraft:purple_concrete
fill 417 94 557 417 95 557 minecraft:purple_concrete
fill 418 94 562 418 99 563 minecraft:black_concrete
fill 418 94 564 418 95 565 minecraft:purple_concrete
setblock 418 94 573 minecraft:purple_concrete
fill 418 94 574 418 99 575 minecraft:black_concrete
fill 418 94 576 418 95 577 minecraft:purple_concrete
fill 418 94 582 418 99 583 minecraft:black_concrete
fill 418 94 584 418 94 585 minecraft:purple_concrete
fill 418 94 586 418 95 586 minecraft:black_concrete
fill 418 94 594 418 99 595 minecraft:black_concrete
fill 418 94 596 418 95 597 minecraft:purple_concrete
fill 418 94 599 418 99 599 minecraft:black_concrete
setblock 376 95 572 minecraft:purple_concrete
setblock 376 95 575 minecraft:purple_concrete
fill 376 95 576 376 98 576 minecraft:black_concrete
setblock 376 95 583 minecraft:purple_concrete
fill 376 95 587 376 98 587 minecraft:black_concrete
fill 380 95 574 380 99 574 minecraft:obsidian
fill 380 95 577 380 99 577 minecraft:obsidian
fill 380 95 599 381 95 599 minecraft:purple_concrete
fill 382 95 557 382 98 557 minecraft:black_concrete
fill 383 95 574 383 99 574 minecraft:obsidian
fill 383 95 577 383 99 577 minecraft:obsidian
setblock 384 95 599 minecraft:purple_concrete
fill 385 95 599 385 98 599 minecraft:black_concrete
setblock 386 95 557 minecraft:purple_concrete
fill 393 95 557 393 98 557 minecraft:black_concrete
setblock 394 95 557 minecraft:purple_concrete
fill 396 95 599 396 98 599 minecraft:black_concrete
setblock 397 95 557 minecraft:purple_concrete
setblock 401 95 599 minecraft:purple_concrete
setblock 412 95 599 minecraft:purple_concrete
fill 413 95 557 414 98 557 minecraft:black_concrete
fill 416 95 599 417 97 599 minecraft:black_concrete
setblock 418 95 557 minecraft:purple_concrete
setblock 418 95 568 minecraft:purple_concrete
fill 418 95 573 418 98 573 minecraft:black_concrete
fill 418 95 584 418 98 584 minecraft:black_concrete
setblock 418 95 585 minecraft:purple_concrete
fill 418 95 588 418 95 589 minecraft:purple_concrete
fill 376 96 561 376 97 562 minecraft:purple_concrete
fill 376 96 563 376 101 564 minecraft:black_concrete
fill 376 96 570 376 97 570 minecraft:purple_concrete
fill 376 96 572 376 101 572 minecraft:black_concrete
fill 376 96 573 376 96 574 minecraft:purple_concrete
fill 376 96 575 376 101 575 minecraft:black_concrete
fill 376 96 581 376 97 582 minecraft:purple_concrete
fill 376 96 583 376 101 584 minecraft:black_concrete
fill 376 96 593 376 96 594 minecraft:purple_concrete
fill 376 96 595 376 101 596 minecraft:black_concrete
fill 377 96 558 379 96 558 minecraft:obsidian
fill 377 96 560 377 96 562 minecraft:obsidian
fill 377 96 564 377 96 566 minecraft:obsidian
fill 377 96 568 377 96 570 minecraft:obsidian
fill 377 96 572 377 96 574 minecraft:obsidian
fill 377 96 576 377 96 578 minecraft:obsidian
fill 377 96 580 377 96 582 minecraft:obsidian
fill 377 96 584 377 96 586 minecraft:obsidian
fill 377 96 588 377 96 590 minecraft:obsidian
fill 377 96 592 377 96 594 minecraft:obsidian
fill 377 96 596 377 96 598 minecraft:obsidian
fill 379 96 575 379 99 576 minecraft:obsidian
fill 379 96 598 381 96 598 minecraft:obsidian
fill 379 96 599 379 97 599 minecraft:purple_concrete
fill 380 96 599 381 101 599 minecraft:black_concrete
fill 381 96 558 383 96 558 minecraft:obsidian
fill 381 96 573 382 99 573 minecraft:obsidian
fill 381 96 578 382 99 578 minecraft:obsidian
setblock 382 96 599 minecraft:purple_concrete
fill 383 96 598 385 96 598 minecraft:obsidian
fill 384 96 575 384 99 576 minecraft:obsidian
fill 384 96 599 384 101 599 minecraft:black_concrete
fill 385 96 557 386 101 557 minecraft:black_concrete
fill 385 96 558 387 96 558 minecraft:obsidian
fill 387 96 557 388 97 557 minecraft:purple_concrete
fill 387 96 598 389 96 598 minecraft:obsidian
fill 389 96 558 391 96 558 minecraft:obsidian
fill 390 96 599 391 97 599 minecraft:purple_concrete
fill 391 96 598 393 96 598 minecraft:obsidian
fill 392 96 599 393 101 599 minecraft:black_concrete
fill 393 96 558 395 96 558 minecraft:obsidian
fill 394 96 557 394 101 557 minecraft:black_concrete
fill 395 96 557 396 96 557 minecraft:purple_concrete
fill 395 96 598 397 96 598 minecraft:obsidian
fill 397 96 557 397 101 557 minecraft:black_concrete
fill 397 96 558 399 96 558 minecraft:obsidian
fill 399 96 557 399 97 557 minecraft:purple_concrete
fill 399 96 598 401 96 598 minecraft:obsidian
fill 401 96 558 403 96 558 minecraft:obsidian
fill 401 96 599 401 101 599 minecraft:black_concrete
fill 402 96 599 403 96 599 minecraft:purple_concrete
fill 403 96 598 405 96 598 minecraft:obsidian
fill 404 96 599 405 98 599 minecraft:black_concrete
fill 405 96 557 406 101 557 minecraft:black_concrete
fill 405 96 558 407 96 558 minecraft:obsidian
fill 407 96 557 408 97 557 minecraft:purple_concrete
fill 407 96 598 409 96 598 minecraft:obsidian
fill 409 96 558 411 96 558 minecraft:obsidian
fill 410 96 599 411 97 599 minecraft:purple_concrete
fill 411 96 598 413 96 598 minecraft:obsidian
fill 412 96 599 413 101 599 minecraft:black_concrete
fill 413 96 558 415 96 558 minecraft:obsidian
setblock 414 96 599 minecraft:purple_concrete
fill 415 96 598 417 96 598 minecraft:obsidian
fill 415 96 599 415 99 599 minecraft:black_concrete
setblock 416 96 557 minecraft:purple_concrete
fill 417 96 557 418 101 557 minecraft:black_concrete
fill 417 96 558 417 96 560 minecraft:obsidian
fill 417 96 562 417 96 564 minecraft:obsidian
fill 417 96 566 417 96 568 minecraft:obsidian
fill 417 96 570 417 96 572 minecraft:obsidian
fill 417 96 574 417 96 576 minecraft:obsidian
fill 417 96 578 417 96 580 minecraft:obsidian
fill 417 96 582 417 96 584 minecraft:obsidian
fill 417 96 586 417 96 588 minecraft:obsidian
fill 417 96 590 417 96 592 minecraft:obsidian
fill 417 96 594 417 96 596 minecraft:obsidian
fill 418 96 558 418 97 559 minecraft:purple_concrete
fill 418 96 564 418 101 565 minecraft:black_concrete
fill 418 96 566 418 96 567 minecraft:purple_concrete
fill 418 96 568 418 101 568 minecraft:black_concrete
fill 418 96 576 418 101 577 minecraft:black_concrete
fill 418 96 578 418 97 579 minecraft:purple_concrete
fill 418 96 585 418 101 585 minecraft:black_concrete
fill 418 96 586 418 96 587 minecraft:purple_concrete
fill 418 96 588 418 97 589 minecraft:black_concrete
fill 418 96 590 418 97 590 minecraft:purple_concrete
fill 418 96 596 418 101 597 minecraft:black_concrete
fill 418 96 598 418 97 598 minecraft:purple_concrete
setblock 376 97 558 minecraft:purple_concrete
setblock 376 97 569 minecraft:purple_concrete
fill 376 97 573 376 100 574 minecraft:black_concrete
setblock 376 97 590 minecraft:purple_concrete
setblock 376 97 593 minecraft:purple_concrete
fill 376 97 594 376 100 594 minecraft:black_concrete
setblock 378 97 599 minecraft:purple_concrete
setblock 379 97 557 minecraft:purple_concrete
fill 379 97 574 379 99 574 minecraft:obsidian
fill 379 97 577 379 99 577 minecraft:obsidian
fill 380 97 573 380 99 573 minecraft:obsidian
fill 380 97 578 380 99 578 minecraft:obsidian
fill 382 97 599 382 100 599 minecraft:black_concrete
fill 383 97 573 383 99 573 minecraft:obsidian
fill 383 97 578 383 99 578 minecraft:obsidian
fill 384 97 574 384 99 574 minecraft:obsidian
fill 384 97 577 384 99 577 minecraft:obsidian
fill 395 97 557 396 100 557 minecraft:black_concrete
fill 398 97 599 399 97 599 minecraft:purple_concrete
setblock 400 97 557 minecraft:purple_concrete
setblock 402 97 599 minecraft:purple_concrete
fill 403 97 599 403 100 599 minecraft:black_concrete
setblock 411 97 557 minecraft:purple_concrete
fill 414 97 599 414 99 599 minecraft:black_concrete
fill 416 97 557 416 100 557 minecraft:black_concrete
fill 418 97 566 418 100 566 minecraft:black_concrete
setblock 418 97 567 minecraft:purple_concrete
fill 418 97 570 418 97 571 minecraft:purple_concrete
fill 418 97 586 418 99 587 minecraft:black_concrete
setblock 418 97 591 minecraft:purple_concrete
fill 376 98 558 376 103 558 minecraft:black_concrete
fill 376 98 559 376 98 560 minecraft:purple_concrete
fill 376 98 561 376 103 562 minecraft:black_concrete
fill 376 98 567 376 99 568 minecraft:purple_concrete
fill 376 98 569 376 103 570 minecraft:black_concrete
setblock 376 98 571 minecraft:purple_concrete
fill 376 98 579 376 99 580 minecraft:purple_concrete
fill 376 98 581 376 103 582 minecraft:black_concrete
fill 376 98 588 376 99 588 minecraft:purple_concrete
fill 376 98 590 376 103 590 minecraft:black_concrete
fill 376 98 591 376 98 592 minecraft:purple_concrete
fill 376 98 593 376 103 593 minecraft:black_concrete
fill 376 98 599 377 99 599 minecraft:purple_concrete
fill 377 98 557 378 98 557 minecraft:purple_concrete
fill 378 98 574 378 99 577 minecraft:obsidian
fill 378 98 599 379 103 599 minecraft:black_concrete
fill 379 98 557 379 103 557 minecraft:black_concrete
fill 379 98 573 379 99 573 minecraft:obsidian
fill 379 98 578 379 99 578 minecraft:obsidian
fill 381 98 557 381 99 557 minecraft:purple_concrete
fill 381 98 572 382 99 572 minecraft:obsidian
fill 381 98 579 382 99 579 minecraft:obsidian
fill 384 98 573 384 99 573 minecraft:obsidian
fill 384 98 578 384 99 578 minecraft:obsidian
fill 385 98 575 385 99 576 minecraft:obsidian
fill 387 98 557 388 103 557 minecraft:black_concrete
fill 388 98 599 389 98 599 minecraft:purple_concrete
fill 389 98 557 390 99 557 minecraft:purple_concrete
fill 390 98 599 391 103 599 minecraft:black_concrete
fill 397 98 599 397 99 599 minecraft:purple_concrete
setblock 398 98 557 minecraft:purple_concrete
fill 398 98 599 399 103 599 minecraft:black_concrete
fill 399 98 557 400 103 557 minecraft:black_concrete
setblock 400 98 599 minecraft:purple_concrete
fill 401 98 557 402 99 557 minecraft:purple_concrete
fill 402 98 599 402 100 599 minecraft:black_concrete
fill 407 98 557 408 103 557 minecraft:black_concrete
fill 408 98 599 409 99 599 minecraft:purple_concrete
fill 409 98 557 410 98 557 minecraft:purple_concrete
fill 410 98 599 411 103 599 minecraft:black_concrete
fill 411 98 557 411 103 557 minecraft:black_concrete
setblock 416 98 599 minecraft:black_concrete
fill 417 98 599 417 99 599 minecraft:purple_concrete
fill 418 98 558 418 103 559 minecraft:black_concrete
fill 418 98 560 418 99 561 minecraft:purple_concrete
fill 418 98 567 418 103 567 minecraft:black_concrete
setblock 418 98 569 minecraft:purple_concrete
fill 418 98 570 418 103 571 minecraft:black_concrete
fill 418 98 572 418 99 572 minecraft:purple_concrete
fill 418 98 578 418 103 579 minecraft:black_concrete
fill 418 98 580 418 98 581 minecraft:purple_concrete
fill 418 98 588 418 101 588 minecraft:black_concrete
setblock 418 98 589 minecraft:purple_concrete
fill 418 98 590 418 103 591 minecraft:black_concrete
fill 418 98 592 418 99 593 minecraft:purple_concrete
fill 418 98 598 418 100 598 minecraft:black_concrete
setblock 376 99 559 minecraft:purple_concrete
fill 376 99 560 376 102 560 minecraft:black_concrete
fill 376 99 571 376 102 571 minecraft:black_concrete
setblock 376 99 576 minecraft:purple_concrete
setblock 376 99 587 minecraft:purple_concrete
fill 376 99 591 376 102 592 minecraft:black_concrete
fill 377 99 557 378 102 557 minecraft:black_concrete
setblock 378 99 578 minecraft:obsidian
setblock 380 99 572 minecraft:obsidian
setblock 380 99 579 minecraft:obsidian
setblock 382 99 557 minecraft:purple_concrete
setblock 383 99 572 minecraft:obsidian
setblock 383 99 579 minecraft:obsidian
setblock 385 99 574 minecraft:obsidian
setblock 385 99 577 minecraft:obsidian
setblock 385 99 599 minecraft:purple_concrete
setblock 388 99 599 minecraft:purple_concrete
fill 389 99 599 389 102 599 minecraft:black_concrete
setblock 393 99 557 minecraft:purple_concrete
setblock 396 99 599 minecraft:purple_concrete
fill 398 99 557 398 102 557 minecraft:black_concrete
fill 400 99 599 400 102 599 minecraft:black_concrete
fill 404 99 599 404 101 599 minecraft:black_concrete
setblock 405 99 599 minecraft:purple_concrete
fill 409 99 557 409 102 557 minecraft:black_concrete
setblock 410 99 557 minecraft:purple_concrete
fill 413 99 557 414 99 557 minecraft:purple_concrete
setblock 416 99 599 minecraft:purple_concrete
fill 418 99 569 418 102 569 minecraft:black_concrete
setblock 418 99 573 minecraft:purple_concrete
fill 418 99 580 418 102 580 minecraft:black_concrete
setblock 418 99 581 minecraft:purple_concrete
setblock 418 99 584 minecraft:purple_concrete
fill 418 99 589 418 101 589 minecraft:black_concrete
setblock 376 100 557 minecraft:purple_concrete
fill 376 100 559 376 105 559 minecraft:black_concrete
fill 376 100 565 376 101 566 minecraft:purple_concrete
fill 376 100 567 376 105 568 minecraft:black_concrete
fill 376 100 576 376 105 576 minecraft:black_concrete
fill 376 100 577 376 100 578 minecraft:purple_concrete
fill 376 100 579 376 105 580 minecraft:black_concrete
fill 376 100 585 376 101 586 minecraft:purple_concrete
fill 376 100 587 376 105 588 minecraft:black_concrete
setblock 376 100 589 minecraft:purple_concrete
fill 376 100 597 376 101 598 minecraft:purple_concrete
fill 376 100 599 377 105 599 minecraft:black_concrete
setblock 379 100 560 minecraft:light[level=12]
setblock 379 100 568 minecraft:light[level=12]
setblock 379 100 576 minecraft:light[level=12]
setblock 379 100 584 minecraft:light[level=12]
setblock 379 100 592 minecraft:light[level=12]
setblock 380 100 557 minecraft:purple_concrete
fill 381 100 557 382 105 557 minecraft:black_concrete
fill 381 100 575 382 101 576 minecraft:amethyst_block
fill 383 100 557 384 101 557 minecraft:purple_concrete
fill 383 100 599 383 101 599 minecraft:purple_concrete
fill 385 100 599 385 105 599 minecraft:black_concrete
fill 386 100 599 387 100 599 minecraft:purple_concrete
setblock 387 100 560 minecraft:light[level=12]
setblock 387 100 568 minecraft:light[level=12]
setblock 387 100 576 minecraft:light[level=12]
setblock 387 100 584 minecraft:light[level=12]
setblock 387 100 592 minecraft:light[level=12]
fill 388 100 599 388 105 599 minecraft:black_concrete
fill 389 100 557 390 105 557 minecraft:black_concrete
fill 391 100 557 392 100 557 minecraft:purple_concrete
fill 393 100 557 393 105 557 minecraft:black_concrete
fill 394 100 599 395 101 599 minecraft:purple_concrete
setblock 395 100 560 minecraft:light[level=12]
setblock 395 100 568 minecraft:light[level=12]
setblock 395 100 576 minecraft:light[level=12]
setblock 395 100 584 minecraft:light[level=12]
setblock 395 100 592 minecraft:light[level=12]
fill 396 100 599 397 105 599 minecraft:black_concrete
fill 401 100 557 402 105 557 minecraft:black_concrete
fill 403 100 557 404 101 557 minecraft:purple_concrete
setblock 403 100 560 minecraft:light[level=12]
setblock 403 100 568 minecraft:light[level=12]
setblock 403 100 576 minecraft:light[level=12]
setblock 403 100 584 minecraft:light[level=12]
setblock 403 100 592 minecraft:light[level=12]
fill 405 100 599 405 101 599 minecraft:black_concrete
fill 406 100 599 407 100 599 minecraft:purple_concrete
fill 408 100 599 409 105 599 minecraft:black_concrete
fill 410 100 557 410 105 557 minecraft:black_concrete
setblock 411 100 560 minecraft:light[level=12]
setblock 411 100 568 minecraft:light[level=12]
setblock 411 100 576 minecraft:light[level=12]
setblock 411 100 584 minecraft:light[level=12]
setblock 411 100 592 minecraft:light[level=12]
setblock 412 100 557 minecraft:purple_concrete
fill 413 100 557 414 105 557 minecraft:black_concrete
fill 414 100 599 415 101 599 minecraft:purple_concrete
fill 415 100 557 415 101 557 minecraft:purple_concrete
fill 416 100 599 417 105 599 minecraft:black_concrete
fill 418 100 560 418 105 561 minecraft:black_concrete
fill 418 100 562 418 100 563 minecraft:purple_concrete
fill 418 100 572 418 105 573 minecraft:black_concrete
fill 418 100 574 418 101 575 minecraft:purple_concrete
fill 418 100 581 418 105 581 minecraft:black_concrete
fill 418 100 582 418 100 583 minecraft:purple_concrete
fill 418 100 584 418 105 584 minecraft:black_concrete
fill 418 100 586 418 101 586 minecraft:purple_concrete
setblock 418 100 587 minecraft:black_concrete
fill 418 100 592 418 105 593 minecraft:black_concrete
fill 418 100 594 418 101 595 minecraft:purple_concrete
setblock 418 100 599 minecraft:purple_concrete
fill 376 101 557 376 104 557 minecraft:black_concrete
fill 376 101 573 376 101 574 minecraft:purple_concrete
setblock 376 101 577 minecraft:purple_concrete
fill 376 101 578 376 104 578 minecraft:black_concrete
fill 376 101 589 376 104 589 minecraft:black_concrete
setblock 376 101 594 minecraft:purple_concrete
fill 380 101 557 380 104 557 minecraft:black_concrete
setblock 382 101 599 minecraft:purple_concrete
fill 386 101 599 387 104 599 minecraft:black_concrete
fill 390 101 585 390 102 585 minecraft:amethyst_block
fill 391 101 557 391 104 557 minecraft:black_concrete
setblock 392 101 557 minecraft:purple_concrete
fill 395 101 557 396 101 557 minecraft:purple_concrete
fill 402 101 599 403 101 599 minecraft:purple_concrete
setblock 406 101 599 minecraft:purple_concrete
fill 407 101 599 407 104 599 minecraft:black_concrete
fill 412 101 557 412 104 557 minecraft:black_concrete
setblock 416 101 557 minecraft:purple_concrete
fill 418 101 562 418 104 562 minecraft:black_concrete
setblock 418 101 563 minecraft:purple_concrete
setblock 418 101 566 minecraft:purple_concrete
fill 418 101 582 418 104 583 minecraft:black_concrete
setblock 418 101 587 minecraft:purple_concrete
setblock 418 101 598 minecraft:purple_concrete
fill 418 101 599 418 104 599 minecraft:black_concrete
fill 376 102 563 376 102 564 minecraft:purple_concrete
fill 376 102 565 376 107 566 minecraft:black_concrete
fill 376 102 572 376 103 572 minecraft:purple_concrete
fill 376 102 573 376 107 574 minecraft:black_concrete
setblock 376 102 575 minecraft:purple_concrete
fill 376 102 577 376 107 577 minecraft:black_concrete
fill 376 102 583 376 103 584 minecraft:purple_concrete
fill 376 102 585 376 107 586 minecraft:black_concrete
fill 376 102 594 376 107 594 minecraft:black_concrete
fill 376 102 595 376 102 596 minecraft:purple_concrete
fill 376 102 597 376 107 598 minecraft:black_concrete
fill 377 102 558 379 102 558 minecraft:obsidian
fill 377 102 560 377 102 562 minecraft:obsidian
fill 377 102 564 377 102 566 minecraft:obsidian
fill 377 102 568 377 102 570 minecraft:obsidian
fill 377 102 572 377 102 574 minecraft:obsidian
fill 377 102 576 377 102 578 minecraft:obsidian
fill 377 102 580 377 102 582 minecraft:obsidian
fill 377 102 584 377 102 586 minecraft:obsidian
fill 377 102 588 377 102 590 minecraft:obsidian
fill 377 102 592 377 102 594 minecraft:obsidian
fill 377 102 596 377 102 598 minecraft:obsidian
fill 379 102 598 381 102 598 minecraft:obsidian
fill 380 102 599 381 103 599 minecraft:purple_concrete
fill 381 102 558 383 102 558 minecraft:obsidian
fill 381 102 575 381 102 576 minecraft:amethyst_block
setblock 382 102 576 minecraft:amethyst_block
fill 382 102 599 383 107 599 minecraft:black_concrete
fill 383 102 557 384 107 557 minecraft:black_concrete
fill 383 102 598 385 102 598 minecraft:obsidian
setblock 384 102 599 minecraft:purple_concrete
fill 385 102 557 386 103 557 minecraft:purple_concrete
fill 385 102 558 387 102 558 minecraft:obsidian
fill 387 102 598 389 102 598 minecraft:obsidian
fill 389 102 558 391 102 558 minecraft:obsidian
fill 391 102 598 393 102 598 minecraft:obsidian
fill 392 102 557 392 107 557 minecraft:black_concrete
fill 392 102 599 393 103 599 minecraft:purple_concrete
fill 393 102 558 395 102 558 minecraft:obsidian
setblock 394 102 557 minecraft:purple_concrete
fill 394 102 599 395 107 599 minecraft:black_concrete
fill 395 102 557 396 107 557 minecraft:black_concrete
fill 395 102 598 397 102 598 minecraft:obsidian
fill 397 102 557 397 103 557 minecraft:purple_concrete
fill 397 102 558 399 102 558 minecraft:obsidian
fill 399 102 598 401 102 598 minecraft:obsidian
fill 401 102 558 403 102 558 minecraft:obsidian
fill 401 102 599 401 103 599 minecraft:purple_concrete
fill 402 102 599 403 103 599 minecraft:black_concrete
fill 403 102 557 404 107 557 minecraft:black_concrete
fill 403 102 598 405 102 598 minecraft:obsidian
fill 404 102 599 405 102 599 minecraft:purple_concrete
fill 405 102 557 406 102 557 minecraft:purple_concrete
fill 405 102 558 407 102 558 minecraft:obsidian
fill 406 102 599 406 107 599 minecraft:black_concrete
fill 407 102 598 409 102 598 minecraft:obsidian
fill 409 102 558 411 102 558 minecraft:obsidian
fill 411 102 598 413 102 598 minecraft:obsidian
fill 412 102 599 413 103 599 minecraft:purple_concrete
fill 413 102 558 415 102 558 minecraft:obsidian
fill 414 102 599 415 107 599 minecraft:black_concrete
fill 415 102 557 416 107 557 minecraft:black_concrete
fill 415 102 598 417 102 598 minecraft:obsidian
fill 417 102 557 418 103 557 minecraft:purple_concrete
fill 417 102 558 417 102 560 minecraft:obsidian
fill 417 102 562 417 102 564 minecraft:obsidian
fill 417 102 566 417 102 568 minecraft:obsidian
fill 417 102 570 417 102 572 minecraft:obsidian
fill 417 102 574 417 102 576 minecraft:obsidian
fill 417 102 578 417 102 580 minecraft:obsidian
fill 417 102 582 417 102 584 minecraft:obsidian
fill 417 102 586 417 102 588 minecraft:obsidian
fill 417 102 590 417 102 592 minecraft:obsidian
fill 417 102 594 417 102 596 minecraft:obsidian
fill 418 102 563 418 107 563 minecraft:black_concrete
fill 418 102 564 418 102 565 minecraft:purple_concrete
fill 418 102 566 418 107 566 minecraft:black_concrete
fill 418 102 568 418 103 568 minecraft:purple_concrete
fill 418 102 574 418 107 575 minecraft:black_concrete
fill 418 102 576 418 103 577 minecraft:purple_concrete
setblock 418 102 585 minecraft:purple_concrete
fill 418 102 586 418 107 587 minecraft:black_concrete
fill 418 102 588 418 103 589 minecraft:purple_concrete
fill 418 102 594 418 107 595 minecraft:black_concrete
fill 418 102 596 418 102 597 minecraft:purple_concrete
fill 418 102 598 418 103 598 minecraft:black_concrete
setblock 376 103 560 minecraft:purple_concrete
setblock 376 103 563 minecraft:purple_concrete
fill 376 103 564 376 106 564 minecraft:black_concrete
setblock 376 103 571 minecraft:purple_concrete
fill 376 103 575 376 106 575 minecraft:black_concrete
fill 376 103 591 376 103 592 minecraft:purple_concrete
setblock 376 103 595 minecraft:purple_concrete
fill 376 103 596 376 106 596 minecraft:black_concrete
fill 377 103 557 378 103 557 minecraft:purple_concrete
fill 384 103 599 384 106 599 minecraft:black_concrete
setblock 389 103 599 minecraft:purple_concrete
fill 394 103 557 394 106 557 minecraft:black_concrete
setblock 398 103 557 minecraft:purple_concrete
setblock 400 103 599 minecraft:purple_concrete
fill 404 103 599 405 105 599 minecraft:black_concrete
fill 405 103 557 405 106 557 minecraft:black_concrete
setblock 406 103 557 minecraft:purple_concrete
setblock 409 103 557 minecraft:purple_concrete
fill 418 103 564 418 106 565 minecraft:black_concrete
setblock 418 103 569 minecraft:purple_concrete
setblock 418 103 580 minecraft:purple_concrete
fill 418 103 585 418 106 585 minecraft:black_concrete
fill 418 103 596 418 106 596 minecraft:black_concrete
setblock 418 103 597 minecraft:purple_concrete
fill 376 104 558 376 105 558 minecraft:purple_concrete
fill 376 104 560 376 109 560 minecraft:black_concrete
fill 376 104 561 376 104 562 minecraft:purple_concrete
fill 376 104 563 376 109 563 minecraft:black_concrete
fill 376 104 569 376 105 570 minecraft:purple_concrete
fill 376 104 571 376 109 572 minecraft:black_concrete
fill 376 104 581 376 104 582 minecraft:purple_concrete
fill 376 104 583 376 109 584 minecraft:black_concrete
fill 376 104 590 376 105 590 minecraft:purple_concrete
fill 376 104 591 376 109 592 minecraft:black_concrete
setblock 376 104 593 minecraft:purple_concrete
fill 376 104 595 376 109 595 minecraft:black_concrete
fill 377 104 557 378 109 557 minecraft:black_concrete
fill 378 104 599 379 105 599 minecraft:purple_concrete
fill 379 104 557 379 105 557 minecraft:purple_concrete
fill 380 104 599 381 109 599 minecraft:black_concrete
fill 385 104 557 386 109 557 minecraft:black_concrete
fill 386 104 586 386 105 586 minecraft:amethyst_block
fill 387 104 557 388 104 557 minecraft:purple_concrete
fill 389 104 599 389 109 599 minecraft:black_concrete
fill 390 104 599 391 104 599 minecraft:purple_concrete
fill 392 104 599 393 106 599 minecraft:black_concrete
fill 397 104 557 398 109 557 minecraft:black_concrete
fill 398 104 599 399 105 599 minecraft:purple_concrete
fill 399 104 557 400 105 557 minecraft:purple_concrete
fill 400 104 599 401 109 599 minecraft:black_concrete
setblock 402 104 599 minecraft:purple_concrete
fill 403 104 599 403 107 599 minecraft:black_concrete
fill 406 104 557 406 109 557 minecraft:black_concrete
fill 407 104 557 408 104 557 minecraft:purple_concrete
fill 409 104 557 409 109 557 minecraft:black_concrete
fill 410 104 599 411 105 599 minecraft:purple_concrete
fill 411 104 557 411 105 557 minecraft:purple_concrete
fill 412 104 599 413 109 599 minecraft:black_concrete
fill 417 104 557 418 109 557 minecraft:black_concrete
fill 418 104 558 418 105 559 minecraft:purple_concrete
setblock 418 104 567 minecraft:purple_concrete
fill 418 104 568 418 109 569 minecraft:black_concrete
fill 418 104 570 418 105 571 minecraft:purple_concrete
fill 418 104 576 418 109 577 minecraft:black_concrete
fill 418 104 578 418 104 579 minecraft:purple_concrete
fill 418 104 580 418 109 580 minecraft:black_concrete
fill 418 104 588 418 109 589 minecraft:black_concrete
fill 418 104 590 418 105 591 minecraft:purple_concrete
fill 418 104 597 418 109 597 minecraft:black_concrete
setblock 418 104 598 minecraft:purple_concrete
setblock 376 105 557 minecraft:purple_concrete
fill 376 105 561 376 108 562 minecraft:black_concrete
setblock 376 105 578 minecraft:purple_concrete
setblock 376 105 581 minecraft:purple_concrete
fill 376 105 582 376 108 582 minecraft:black_concrete
setblock 376 105 589 minecraft:purple_concrete
fill 376 105 593 376 108 593 minecraft:black_concrete
setblock 380 105 557 minecraft:purple_concrete
fill 386 105 599 387 105 599 minecraft:purple_concrete
fill 387 105 557 387 108 557 minecraft:black_concrete
setblock 388 105 557 minecraft:purple_concrete
setblock 390 105 599 minecraft:purple_concrete
setblock 391 105 557 minecraft:purple_concrete
fill 391 105 599 391 108 599 minecraft:black_concrete
fill 402 105 599 402 107 599 minecraft:black_concrete
fill 407 105 557 408 108 557 minecraft:black_concrete
setblock 407 105 599 minecraft:purple_concrete
setblock 412 105 557 minecraft:purple_concrete
setblock 418 105 562 minecraft:purple_concrete
fill 418 105 567 418 108 567 minecraft:black_concrete
fill 418 105 578 418 108 578 minecraft:black_concrete
setblock 418 105 579 minecraft:purple_concrete
fill 418 105 582 418 105 583 minecraft:purple_concrete
fill 418 105 598 418 107 598 minecraft:black_concrete
setblock 418 105 599 minecraft:purple_concrete
fill 376 106 557 376 111 558 minecraft:black_concrete
setblock 376 106 559 minecraft:purple_concrete
fill 376 106 567 376 107 568 minecraft:purple_concrete
fill 376 106 569 376 111 570 minecraft:black_concrete
fill 376 106 576 376 107 576 minecraft:purple_concrete
fill 376 106 578 376 111 578 minecraft:black_concrete
fill 376 106 579 376 106 580 minecraft:purple_concrete
fill 376 106 581 376 111 581 minecraft:black_concrete
fill 376 106 587 376 107 588 minecraft:purple_concrete
fill 376 106 589 376 111 590 minecraft:black_concrete
fill 376 106 599 377 106 599 minecraft:purple_concrete
fill 378 106 599 379 111 599 minecraft:black_concrete
fill 379 106 557 380 111 557 minecraft:black_concrete
fill 381 106 557 382 107 557 minecraft:purple_concrete
fill 385 106 599 385 107 599 minecraft:purple_concrete
fill 386 106 599 387 111 599 minecraft:black_concrete
fill 388 106 557 388 111 557 minecraft:black_concrete
fill 388 106 572 389 107 573 minecraft:amethyst_block
setblock 388 106 599 minecraft:purple_concrete
fill 389 106 557 390 106 557 minecraft:purple_concrete
fill 390 106 599 390 108 599 minecraft:black_concrete
fill 391 106 557 391 111 557 minecraft:black_concrete
fill 393 106 557 393 107 557 minecraft:purple_concrete
fill 396 106 599 397 107 599 minecraft:purple_concrete
fill 398 106 599 399 111 599 minecraft:black_concrete
fill 399 106 557 400 111 557 minecraft:black_concrete
fill 401 106 557 402 107 557 minecraft:purple_concrete
setblock 404 106 599 minecraft:black_concrete
fill 405 106 599 405 107 599 minecraft:purple_concrete
fill 407 106 599 407 111 599 minecraft:black_concrete
fill 408 106 599 409 106 599 minecraft:purple_concrete
setblock 410 106 557 minecraft:purple_concrete
fill 410 106 599 411 108 599 minecraft:black_concrete
fill 411 106 557 412 111 557 minecraft:black_concrete
fill 413 106 557 414 107 557 minecraft:purple_concrete
fill 416 106 599 417 107 599 minecraft:purple_concrete
fill 418 106 558 418 111 559 minecraft:black_concrete
fill 418 106 560 418 106 561 minecraft:purple_concrete
fill 418 106 562 418 111 562 minecraft:black_concrete
fill 418 106 570 418 111 571 minecraft:black_concrete
fill 418 106 572 418 107 573 minecraft:purple_concrete
fill 418 106 579 418 111 579 minecraft:black_concrete
setblock 418 106 581 minecraft:purple_concrete
fill 418 106 582 418 111 583 minecraft:black_concrete
fill 418 106 584 418 107 584 minecraft:purple_concrete
fill 418 106 590 418 111 591 minecraft:black_concrete
fill 418 106 592 418 106 593 minecraft:purple_concrete
fill 418 106 599 418 111 599 minecraft:black_concrete
fill 376 107 559 376 110 559 minecraft:black_concrete
setblock 376 107 564 minecraft:purple_concrete
setblock 376 107 575 minecraft:purple_concrete
fill 376 107 579 376 110 580 minecraft:black_concrete
setblock 376 107 596 minecraft:purple_concrete
setblock 376 107 599 minecraft:purple_concrete
fill 377 107 599 377 110 599 minecraft:black_concrete
setblock 384 107 599 minecraft:purple_concrete
fill 388 107 599 388 110 599 minecraft:black_concrete
fill 389 107 557 390 110 557 minecraft:black_concrete
fill 392 107 599 392 109 599 minecraft:black_concrete
setblock 393 107 599 minecraft:purple_concrete
setblock 394 107 557 minecraft:purple_concrete
fill 397 107 563 398 108 563 minecraft:amethyst_block
setblock 404 107 599 minecraft:purple_concrete
setblock 405 107 557 minecraft:purple_concrete
setblock 408 107 599 minecraft:purple_concrete
fill 409 107 599 409 110 599 minecraft:black_concrete
fill 410 107 557 410 110 557 minecraft:black_concrete
fill 418 107 560 418 110 560 minecraft:black_concrete
setblock 418 107 561 minecraft:purple_concrete
fill 418 107 564 418 107 565 minecraft:purple_concrete
fill 418 107 581 418 110 581 minecraft:black_concrete
setblock 418 107 585 minecraft:purple_concrete
fill 418 107 592 418 110 592 minecraft:black_concrete
setblock 418 107 593 minecraft:purple_concrete
setblock 418 107 596 minecraft:purple_concrete
fill 376 108 564 376 113 564 minecraft:black_concrete
fill 376 108 565 376 108 566 minecraft:purple_concrete
fill 376 108 567 376 113 568 minecraft:black_concrete
fill 376 108 573 376 109 574 minecraft:purple_concrete
fill 376 108 575 376 113 576 minecraft:black_concrete
setblock 376 108 577 minecraft:purple_concrete
fill 376 108 585 376 109 586 minecraft:purple_concrete
fill 376 108 587 376 113 588 minecraft:black_concrete
fill 376 108 594 376 109 594 minecraft:purple_concrete
fill 376 108 596 376 113 596 minecraft:black_concrete
fill 376 108 597 376 108 598 minecraft:purple_concrete
fill 376 108 599 376 113 599 minecraft:black_concrete
fill 377 108 558 379 108 558 minecraft:obsidian
fill 377 108 560 377 108 562 minecraft:obsidian
fill 377 108 564 377 108 566 minecraft:obsidian
fill 377 108 568 377 108 570 minecraft:obsidian
fill 377 108 572 377 108 574 minecraft:obsidian
fill 377 108 576 377 108 578 minecraft:obsidian
fill 377 108 580 377 108 582 minecraft:obsidian
fill 377 108 584 377 108 586 minecraft:obsidian
fill 377 108 588 377 108 590 minecraft:obsidian
fill 377 108 592 377 108 594 minecraft:obsidian
fill 377 108 596 377 108 598 minecraft:obsidian
setblock 379 108 560 minecraft:light[level=12]
setblock 379 108 568 minecraft:light[level=12]
setblock 379 108 576 minecraft:light[level=12]
setblock 379 108 584 minecraft:light[level=12]
setblock 379 108 592 minecraft:light[level=12]
fill 379 108 598 381 108 598 minecraft:obsidian
fill 381 108 557 382 113 557 minecraft:black_concrete
fill 381 108 558 383 108 558 minecraft:obsidian
fill 382 108 599 383 109 599 minecraft:purple_concrete
fill 383 108 557 384 109 557 minecraft:purple_concrete
fill 383 108 598 385 108 598 minecraft:obsidian
fill 384 108 599 385 113 599 minecraft:black_concrete
fill 385 108 558 387 108 558 minecraft:obsidian
setblock 387 108 560 minecraft:light[level=12]
setblock 387 108 568 minecraft:light[level=12]
setblock 387 108 576 minecraft:light[level=12]
setblock 387 108 584 minecraft:light[level=12]
setblock 387 108 592 minecraft:light[level=12]
fill 387 108 598 389 108 598 minecraft:obsidian
fill 389 108 558 391 108 558 minecraft:obsidian
fill 391 108 598 393 108 598 minecraft:obsidian
setblock 392 108 557 minecraft:purple_concrete
fill 393 108 557 394 113 557 minecraft:black_concrete
fill 393 108 558 395 108 558 minecraft:obsidian
fill 393 108 599 393 109 599 minecraft:black_concrete
fill 394 108 599 395 108 599 minecraft:purple_concrete
fill 395 108 557 396 109 557 minecraft:purple_concrete
setblock 395 108 560 minecraft:light[level=12]
setblock 395 108 568 minecraft:light[level=12]
setblock 395 108 576 minecraft:light[level=12]
setblock 395 108 584 minecraft:light[level=12]
setblock 395 108 592 minecraft:light[level=12]
fill 395 108 598 397 108 598 minecraft:obsidian
fill 396 108 599 397 113 599 minecraft:black_concrete
fill 397 108 558 399 108 558 minecraft:obsidian
fill 399 108 598 401 108 598 minecraft:obsidian
fill 401 108 557 402 113 557 minecraft:black_concrete
fill 401 108 558 403 108 558 minecraft:obsidian
fill 402 108 599 403 109 599 minecraft:purple_concrete
fill 403 108 557 404 108 557 minecraft:purple_concrete
setblock 403 108 560 minecraft:light[level=12]
setblock 403 108 568 minecraft:light[level=12]
setblock 403 108 576 minecraft:light[level=12]
setblock 403 108 584 minecraft:light[level=12]
setblock 403 108 592 minecraft:light[level=12]
fill 403 108 598 405 108 598 minecraft:obsidian
fill 404 108 599 405 113 599 minecraft:black_concrete
fill 405 108 557 405 113 557 minecraft:black_concrete
fill 405 108 558 407 108 558 minecraft:obsidian
setblock 406 108 599 minecraft:purple_concrete
fill 407 108 598 409 108 598 minecraft:obsidian
fill 408 108 599 408 110 599 minecraft:black_concrete
fill 409 108 558 411 108 558 minecraft:obsidian
setblock 411 108 560 minecraft:light[level=12]
setblock 411 108 568 minecraft:light[level=12]
setblock 411 108 576 minecraft:light[level=12]
setblock 411 108 584 minecraft:light[level=12]
setblock 411 108 592 minecraft:light[level=12]
fill 411 108 598 413 108 598 minecraft:obsidian
fill 413 108 557 414 113 557 minecraft:black_concrete
fill 413 108 558 415 108 558 minecraft:obsidian
fill 414 108 599 415 109 599 minecraft:purple_concrete
fill 415 108 557 416 109 557 minecraft:purple_concrete
fill 415 108 598 417 108 598 minecraft:obsidian
fill 416 108 599 417 113 599 minecraft:black_concrete
fill 417 108 558 417 108 560 minecraft:obsidian
fill 417 108 562 417 108 564 minecraft:obsidian
fill 417 108 566 417 108 568 minecraft:obsidian
fill 417 108 570 417 108 572 minecraft:obsidian
fill 417 108 574 417 108 576 minecraft:obsidian
fill 417 108 578 417 108 580 minecraft:obsidian
fill 417 108 582 417 108 584 minecraft:obsidian
fill 417 108 586 417 108 588 minecraft:obsidian
fill 417 108 590 417 108 592 minecraft:obsidian
fill 417 108 594 417 108 596 minecraft:obsidian
fill 418 108 561 418 113 561 minecraft:black_concrete
setblock 418 108 563 minecraft:purple_concrete
fill 418 108 564 418 113 565 minecraft:black_concrete
fill 418 108 566 418 109 566 minecraft:purple_concrete
fill 418 108 572 418 113 573 minecraft:black_concrete
fill 418 108 574 418 108 575 minecraft:purple_concrete
fill 418 108 584 418 113 585 minecraft:black_concrete
fill 418 108 586 418 109 587 minecraft:purple_concrete
fill 418 108 593 418 113 593 minecraft:black_concrete
fill 418 108 594 418 108 595 minecraft:purple_concrete
fill 418 108 596 418 113 596 minecraft:black_concrete
fill 418 108 598 418 109 598 minecraft:purple_concrete
fill 376 109 561 376 109 562 minecraft:purple_concrete
setblock 376 109 565 minecraft:purple_concrete
fill 376 109 566 376 112 566 minecraft:black_concrete
fill 376 109 577 376 112 577 minecraft:black_concrete
setblock 376 109 582 minecraft:purple_concrete
setblock 376 109 593 minecraft:purple_concrete
fill 376 109 597 376 112 598 minecraft:black_concrete
setblock 387 109 557 minecraft:purple_concrete
fill 390 109 599 391 109 599 minecraft:purple_concrete
fill 392 109 557 392 112 557 minecraft:black_concrete
setblock 394 109 599 minecraft:purple_concrete
fill 395 109 599 395 112 599 minecraft:black_concrete
fill 403 109 557 403 112 557 minecraft:black_concrete
setblock 404 109 557 minecraft:purple_concrete
fill 406 109 599 406 112 599 minecraft:black_concrete
fill 407 109 557 408 109 557 minecraft:purple_concrete
fill 410 109 599 410 111 599 minecraft:black_concrete
setblock 411 109 599 minecraft:purple_concrete
fill 418 109 563 418 112 563 minecraft:black_concrete
setblock 418 109 567 minecraft:purple_concrete
fill 418 109 574 418 112 574 minecraft:black_concrete
setblock 418 109 575 minecraft:purple_concrete
setblock 418 109 578 minecraft:purple_concrete
fill 418 109 594 418 112 595 minecraft:black_concrete
fill 376 110 560 376 111 560 minecraft:purple_concrete
fill 376 110 561 376 115 562 minecraft:black_concrete
setblock 376 110 563 minecraft:purple_concrete
fill 376 110 565 376 115 565 minecraft:black_concrete
fill 376 110 571 376 111 572 minecraft:purple_concrete
fill 376 110 573 376 115 574 minecraft:black_concrete
fill 376 110 582 376 115 582 minecraft:black_concrete
fill 376 110 583 376 110 584 minecraft:purple_concrete
fill 376 110 585 376 115 586 minecraft:black_concrete
fill 376 110 591 376 111 592 minecraft:purple_concrete
fill 376 110 593 376 115 594 minecraft:black_concrete
setblock 376 110 595 minecraft:purple_concrete
fill 377 110 557 378 111 557 minecraft:purple_concrete
fill 380 110 599 381 111 599 minecraft:purple_concrete
fill 382 110 599 383 115 599 minecraft:black_concrete
fill 383 110 557 384 115 557 minecraft:black_concrete
fill 385 110 557 386 110 557 minecraft:purple_concrete
fill 387 110 557 387 115 557 minecraft:black_concrete
fill 389 110 599 389 111 599 minecraft:purple_concrete
fill 390 110 599 391 111 599 minecraft:black_concrete
fill 392 110 599 393 110 599 minecraft:purple_concrete
fill 394 110 599 394 115 599 minecraft:black_concrete
fill 395 110 557 396 115 557 minecraft:black_concrete
fill 397 110 557 398 111 557 minecraft:purple_concrete
fill 400 110 599 401 111 599 minecraft:purple_concrete
fill 402 110 599 403 115 599 minecraft:black_concrete
fill 404 110 557 404 115 557 minecraft:black_concrete
setblock 406 110 557 minecraft:purple_concrete
fill 407 110 557 408 115 557 minecraft:black_concrete
fill 409 110 557 409 111 557 minecraft:purple_concrete
fill 411 110 599 411 111 599 minecraft:black_concrete
fill 412 110 599 413 110 599 minecraft:purple_concrete
fill 414 110 599 415 115 599 minecraft:black_concrete
fill 415 110 557 416 115 557 minecraft:black_concrete
fill 417 110 557 418 110 557 minecraft:purple_concrete
fill 418 110 566 418 115 567 minecraft:black_concrete
fill 418 110 568 418 111 569 minecraft:purple_concrete
fill 418 110 575 418 115 575 minecraft:black_concrete
fill 418 110 576 418 110 577 minecraft:purple_concrete
fill 418 110 578 418 115 578 minecraft:black_concrete
fill 418 110 580 418 111 580 minecraft:purple_concrete
fill 418 110 586 418 115 587 minecraft:black_concrete
fill 418 110 588 418 111 589 minecraft:purple_concrete
setblock 418 110 597 minecraft:purple_concrete
fill 418 110 598 418 115 598 minecraft:black_concrete
setblock 376 111 559 minecraft:purple_concrete
fill 376 111 563 376 114 563 minecraft:black_concrete
fill 376 111 579 376 111 580 minecraft:purple_concrete
setblock 376 111 583 minecraft:purple_concrete
fill 376 111 584 376 114 584 minecraft:black_concrete
fill 376 111 595 376 114 595 minecraft:black_concrete
setblock 377 111 599 minecraft:purple_concrete
fill 385 111 557 385 114 557 minecraft:black_concrete
setblock 386 111 557 minecraft:purple_concrete
setblock 388 111 599 minecraft:purple_concrete
fill 389 111 557 390 111 557 minecraft:purple_concrete
fill 392 111 599 393 113 599 minecraft:black_concrete
fill 406 111 557 406 114 557 minecraft:black_concrete
fill 408 111 599 409 111 599 minecraft:purple_concrete
setblock 410 111 557 minecraft:purple_concrete
setblock 412 111 599 minecraft:purple_concrete
fill 413 111 599 413 114 599 minecraft:black_concrete
fill 417 111 557 417 114 557 minecraft:black_concrete
setblock 418 111 557 minecraft:purple_concrete
setblock 418 111 560 minecraft:purple_concrete
fill 418 111 576 418 114 577 minecraft:black_concrete
setblock 418 111 581 minecraft:purple_concrete
setblock 418 111 592 minecraft:purple_concrete
fill 418 111 597 418 114 597 minecraft:black_concrete
fill 376 112 557 376 113 558 minecraft:purple_concrete
fill 376 112 559 376 117 560 minecraft:black_concrete
fill 376 112 569 376 112 570 minecraft:purple_concrete
fill 376 112 571 376 117 572 minecraft:black_concrete
fill 376 112 578 376 113 578 minecraft:purple_concrete
fill 376 112 579 376 117 580 minecraft:black_concrete
setblock 376 112 581 minecraft:purple_concrete
fill 376 112 583 376 117 583 minecraft:black_concrete
fill 376 112 589 376 113 590 minecraft:purple_concrete
fill 376 112 591 376 117 592 minecraft:black_concrete
fill 377 112 557 378 117 557 minecraft:black_concrete
fill 377 112 599 377 117 599 minecraft:black_concrete
fill 378 112 599 379 112 599 minecraft:purple_concrete
fill 379 112 557 380 113 557 minecraft:purple_concrete
fill 380 112 599 381 114 599 minecraft:black_concrete
fill 386 112 557 386 117 557 minecraft:black_concrete
fill 386 112 599 387 113 599 minecraft:purple_concrete
setblock 388 112 557 minecraft:purple_concrete
fill 388 112 599 389 117 599 minecraft:black_concrete
fill 389 112 557 390 117 557 minecraft:black_concrete
setblock 390 112 599 minecraft:purple_concrete
fill 391 112 557 391 113 557 minecraft:purple_concrete
fill 391 112 599 391 115 599 minecraft:black_concrete
fill 397 112 557 398 117 557 minecraft:black_concrete
fill 398 112 599 399 113 599 minecraft:purple_concrete
fill 399 112 557 400 112 557 minecraft:purple_concrete
fill 400 112 599 401 117 599 minecraft:black_concrete
fill 407 112 599 407 113 599 minecraft:purple_concrete
fill 408 112 599 409 113 599 minecraft:black_concrete
fill 409 112 557 410 117 557 minecraft:black_concrete
fill 410 112 599 411 112 599 minecraft:purple_concrete
fill 411 112 557 412 113 557 minecraft:purple_concrete
fill 412 112 599 412 117 599 minecraft:black_concrete
fill 418 112 557 418 117 557 minecraft:black_concrete
fill 418 112 558 418 112 559 minecraft:purple_concrete
fill 418 112 560 418 117 560 minecraft:black_concrete
fill 418 112 562 418 113 562 minecraft:purple_concrete
fill 418 112 568 418 117 569 minecraft:black_concrete
fill 418 112 570 418 113 571 minecraft:purple_concrete
setblock 418 112 579 minecraft:purple_concrete
fill 418 112 580 418 117 581 minecraft:black_concrete
fill 418 112 582 418 113 583 minecraft:purple_concrete
fill 418 112 588 418 117 589 minecraft:black_concrete
fill 418 112 590 418 112 591 minecraft:purple_concrete
fill 418 112 592 418 117 592 minecraft:black_concrete
fill 418 112 599 418 113 599 minecraft:purple_concrete
setblock 376 113 566 minecraft:purple_concrete
setblock 376 113 569 minecraft:purple_concrete
fill 376 113 570 376 116 570 minecraft:black_concrete
setblock 376 113 577 minecraft:purple_concrete
fill 376 113 581 376 116 581 minecraft:black_concrete
fill 376 113 597 376 113 598 minecraft:purple_concrete
setblock 378 113 599 minecraft:purple_concrete
fill 379 113 599 379 116 599 minecraft:black_concrete
fill 388 113 557 388 116 557 minecraft:black_concrete
fill 390 113 599 390 115 599 minecraft:black_concrete
setblock 392 113 557 minecraft:purple_concrete
setblock 395 113 599 minecraft:purple_concrete
fill 399 113 557 399 116 557 minecraft:black_concrete
setblock 400 113 557 minecraft:purple_concrete
setblock 403 113 557 minecraft:purple_concrete
setblock 406 113 599 minecraft:purple_concrete
fill 410 113 599 411 115 599 minecraft:black_concrete
fill 418 113 558 418 116 559 minecraft:black_concrete
setblock 418 113 563 minecraft:purple_concrete
setblock 418 113 574 minecraft:purple_concrete
fill 418 113 579 418 116 579 minecraft:black_concrete
fill 418 113 590 418 116 590 minecraft:black_concrete
setblock 418 113 591 minecraft:purple_concrete
fill 418 113 594 418 113 595 minecraft:purple_concrete
fill 376 114 557 376 127 558 minecraft:black_concrete
fill 376 114 564 376 115 564 minecraft:purple_concrete
fill 376 114 566 376 130 566 minecraft:black_concrete
fill 376 114 567 376 114 568 minecraft:purple_concrete
fill 376 114 569 376 130 569 minecraft:black_concrete
fill 376 114 575 376 115 576 minecraft:purple_concrete
fill 376 114 577 376 130 578 minecraft:black_concrete
fill 376 114 587 376 114 588 minecraft:purple_concrete
fill 376 114 589 376 127 590 minecraft:black_concrete
fill 376 114 596 376 115 596 minecraft:purple_concrete
fill 376 114 597 376 130 598 minecraft:black_concrete
setblock 376 114 599 minecraft:purple_concrete
fill 377 114 558 379 114 558 minecraft:obsidian
fill 377 114 560 377 114 562 minecraft:obsidian
fill 377 114 564 377 114 566 minecraft:obsidian
fill 377 114 568 377 114 570 minecraft:obsidian
fill 377 114 572 377 114 574 minecraft:obsidian
fill 377 114 576 377 114 578 minecraft:obsidian
fill 377 114 580 377 114 582 minecraft:obsidian
fill 377 114 584 377 114 586 minecraft:obsidian
fill 377 114 588 377 114 590 minecraft:obsidian
fill 377 114 592 377 114 594 minecraft:obsidian
fill 377 114 596 377 114 598 minecraft:obsidian
fill 378 114 599 378 116 599 minecraft:black_concrete
fill 379 114 557 380 130 557 minecraft:black_concrete
fill 379 114 598 381 114 598 minecraft:obsidian
fill 381 114 557 382 114 557 minecraft:purple_concrete
fill 381 114 558 383 114 558 minecraft:obsidian
fill 382 114 575 383 115 575 minecraft:amethyst_block
fill 383 114 598 385 114 598 minecraft:obsidian
fill 384 114 599 385 115 599 minecraft:purple_concrete
fill 385 114 558 387 114 558 minecraft:obsidian
fill 386 114 599 387 127 599 minecraft:black_concrete
fill 387 114 598 389 114 598 minecraft:obsidian
fill 389 114 558 391 114 558 minecraft:obsidian
fill 391 114 557 392 130 557 minecraft:black_concrete
fill 391 114 598 393 114 598 minecraft:obsidian
setblock 392 114 599 minecraft:black_concrete
fill 393 114 557 394 115 557 minecraft:purple_concrete
fill 393 114 558 395 114 558 minecraft:obsidian
fill 393 114 599 393 115 599 minecraft:purple_concrete
fill 395 114 598 397 114 598 minecraft:obsidian
fill 395 114 599 395 128 599 minecraft:black_concrete
fill 396 114 599 397 114 599 minecraft:purple_concrete
fill 397 114 558 399 114 558 minecraft:obsidian
fill 398 114 599 399 116 599 minecraft:black_concrete
fill 399 114 598 401 114 598 minecraft:obsidian
fill 400 114 557 400 130 557 minecraft:black_concrete
fill 401 114 557 402 114 557 minecraft:purple_concrete
fill 401 114 558 403 114 558 minecraft:obsidian
fill 403 114 557 403 130 557 minecraft:black_concrete
fill 403 114 598 405 114 598 minecraft:obsidian
fill 404 114 599 405 115 599 minecraft:purple_concrete
fill 405 114 557 405 115 557 minecraft:purple_concrete
fill 405 114 558 407 114 558 minecraft:obsidian
fill 406 114 599 407 130 599 minecraft:black_concrete
fill 407 114 598 409 114 598 minecraft:obsidian
setblock 408 114 599 minecraft:purple_concrete
fill 409 114 558 411 114 558 minecraft:obsidian
fill 409 114 599 409 117 599 minecraft:black_concrete
fill 411 114 557 412 127 557 minecraft:black_concrete
fill 411 114 598 413 114 598 minecraft:obsidian
fill 413 114 557 414 115 557 minecraft:purple_concrete
fill 413 114 558 415 114 558 minecraft:obsidian
fill 415 114 598 417 114 598 minecraft:obsidian
fill 416 114 599 417 114 599 minecraft:purple_concrete
fill 417 114 558 417 114 560 minecraft:obsidian
fill 417 114 562 417 114 564 minecraft:obsidian
fill 417 114 566 417 114 568 minecraft:obsidian
fill 417 114 570 417 114 572 minecraft:obsidian
fill 417 114 574 417 114 576 minecraft:obsidian
fill 417 114 578 417 114 580 minecraft:obsidian
fill 417 114 582 417 114 584 minecraft:obsidian
fill 417 114 586 417 114 588 minecraft:obsidian
fill 417 114 590 417 114 592 minecraft:obsidian
fill 417 114 594 417 114 596 minecraft:obsidian
setblock 418 114 561 minecraft:purple_concrete
fill 418 114 562 418 130 563 minecraft:black_concrete
fill 418 114 564 418 115 565 minecraft:purple_concrete
fill 418 114 570 418 126 571 minecraft:black_concrete
fill 418 114 572 418 114 573 minecraft:purple_concrete
fill 418 114 574 418 130 574 minecraft:black_concrete
fill 418 114 582 418 127 583 minecraft:black_concrete
fill 418 114 584 418 115 585 minecraft:purple_concrete
fill 418 114 591 418 131 591 minecraft:black_concrete
setblock 418 114 593 minecraft:purple_concrete
fill 418 114 594 418 130 595 minecraft:black_concrete
fill 418 114 596 418 115 596 minecraft:purple_concrete
fill 418 114 599 418 127 599 minecraft:black_concrete
setblock 376 115 563 minecraft:purple_concrete
fill 376 115 567 376 118 568 minecraft:black_concrete
setblock 376 115 584 minecraft:purple_concrete
setblock 376 115 587 minecraft:purple_concrete
fill 376 115 588 376 118 588 minecraft:black_concrete
setblock 376 115 595 minecraft:purple_concrete
fill 376 115 599 376 118 599 minecraft:black_concrete
fill 380 115 599 380 117 599 minecraft:black_concrete
fill 381 115 557 381 118 557 minecraft:black_concrete
setblock 381 115 599 minecraft:purple_concrete
setblock 382 115 557 minecraft:purple_concrete
setblock 385 115 557 minecraft:purple_concrete
setblock 392 115 599 minecraft:purple_concrete
setblock 396 115 599 minecraft:purple_concrete
fill 397 115 599 397 118 599 minecraft:black_concrete
fill 401 115 557 402 118 557 minecraft:black_concrete
setblock 406 115 557 minecraft:purple_concrete
fill 408 115 599 408 117 599 minecraft:black_concrete
setblock 413 115 599 minecraft:purple_concrete
setblock 416 115 599 minecraft:purple_concrete
setblock 417 115 557 minecraft:purple_concrete
fill 417 115 599 417 118 599 minecraft:black_concrete
fill 418 115 561 418 118 561 minecraft:black_concrete
fill 418 115 572 418 118 572 minecraft:black_concrete
setblock 418 115 573 minecraft:purple_concrete
fill 418 115 576 418 115 577 minecraft:purple_concrete
fill 418 115 593 418 118 593 minecraft:black_concrete
setblock 418 115 597 minecraft:purple_concrete
fill 376 116 561 376 117 562 minecraft:purple_concrete
fill 376 116 563 376 129 564 minecraft:black_concrete
setblock 376 116 565 minecraft:purple_concrete
fill 376 116 573 376 117 574 minecraft:purple_concrete
fill 376 116 575 376 129 576 minecraft:black_concrete
fill 376 116 582 376 117 582 minecraft:purple_concrete
fill 376 116 584 376 128 584 minecraft:black_concrete
fill 376 116 585 376 116 586 minecraft:purple_concrete
fill 376 116 587 376 130 587 minecraft:black_concrete
fill 376 116 593 376 117 594 minecraft:purple_concrete
fill 376 116 595 376 129 596 minecraft:black_concrete
setblock 379 116 560 minecraft:light[level=12]
setblock 379 116 568 minecraft:light[level=12]
setblock 379 116 576 minecraft:light[level=12]
setblock 379 116 584 minecraft:light[level=12]
setblock 379 116 592 minecraft:light[level=12]
fill 381 116 599 381 117 599 minecraft:black_concrete
fill 382 116 557 382 131 557 minecraft:black_concrete
fill 382 116 599 383 116 599 minecraft:purple_concrete
fill 383 116 557 384 116 557 minecraft:purple_concrete
fill 384 116 599 385 127 599 minecraft:black_concrete
fill 385 116 557 385 127 557 minecraft:black_concrete
fill 387 116 557 387 117 557 minecraft:purple_concrete
setblock 387 116 560 minecraft:light[level=12]
setblock 387 116 568 minecraft:light[level=12]
setblock 387 116 576 minecraft:light[level=12]
setblock 387 116 584 minecraft:light[level=12]
setblock 387 116 592 minecraft:light[level=12]
fill 390 116 599 391 117 599 minecraft:purple_concrete
fill 392 116 599 393 127 599 minecraft:black_concrete
fill 393 116 557 394 129 557 minecraft:black_concrete
setblock 394 116 599 minecraft:purple_concrete
fill 395 116 557 396 117 557 minecraft:purple_concrete
setblock 395 116 560 minecraft:light[level=12]
setblock 395 116 568 minecraft:light[level=12]
setblock 395 116 576 minecraft:light[level=12]
setblock 395 116 584 minecraft:light[level=12]
setblock 395 116 592 minecraft:light[level=12]
fill 396 116 599 396 118 599 minecraft:black_concrete
fill 402 116 599 403 117 599 minecraft:purple_concrete
setblock 403 116 560 minecraft:light[level=12]
setblock 403 116 568 minecraft:light[level=12]
setblock 403 116 576 minecraft:light[level=12]
setblock 403 116 584 minecraft:light[level=12]
setblock 403 116 592 minecraft:light[level=12]
setblock 404 116 557 minecraft:purple_concrete
fill 404 116 599 405 128 599 minecraft:black_concrete
fill 405 116 557 406 129 557 minecraft:black_concrete
fill 407 116 557 408 117 557 minecraft:purple_concrete
setblock 410 116 599 minecraft:black_concrete
setblock 411 116 560 minecraft:light[level=12]
setblock 411 116 568 minecraft:light[level=12]
setblock 411 116 576 minecraft:light[level=12]
setblock 411 116 584 minecraft:light[level=12]
setblock 411 116 592 minecraft:light[level=12]
fill 411 116 599 411 117 599 minecraft:purple_concrete
fill 413 116 557 414 126 557 minecraft:black_concrete
fill 413 116 599 413 127 599 minecraft:black_concrete
fill 414 116 599 415 116 599 minecraft:purple_concrete
fill 415 116 557 416 116 557 minecraft:purple_concrete
fill 416 116 599 416 132 599 minecraft:black_concrete
fill 417 116 557 417 129 557 minecraft:black_concrete
fill 418 116 564 418 129 565 minecraft:black_concrete
fill 418 116 566 418 117 567 minecraft:purple_concrete
fill 418 116 573 418 126 573 minecraft:black_concrete
setblock 418 116 575 minecraft:purple_concrete
fill 418 116 576 418 128 577 minecraft:black_concrete
fill 418 116 578 418 117 578 minecraft:purple_concrete
fill 418 116 584 418 129 585 minecraft:black_concrete
fill 418 116 586 418 116 587 minecraft:purple_concrete
fill 418 116 596 418 129 597 minecraft:black_concrete
fill 418 116 598 418 117 598 minecraft:purple_concrete
fill 376 117 565 376 130 565 minecraft:black_concrete
setblock 376 117 570 minecraft:purple_concrete
setblock 376 117 581 minecraft:purple_concrete
fill 376 117 585 376 130 586 minecraft:black_concrete
fill 378 117 599 379 117 599 minecraft:purple_concrete
setblock 382 117 599 minecraft:purple_concrete
fill 383 117 557 384 127 557 minecraft:black_concrete
fill 383 117 599 383 130 599 minecraft:black_concrete
setblock 388 117 557 minecraft:purple_concrete
fill 394 117 599 394 130 599 minecraft:black_concrete
fill 398 117 599 398 130 599 minecraft:black_concrete
setblock 399 117 557 minecraft:purple_concrete
setblock 399 117 599 minecraft:purple_concrete
fill 404 117 557 404 131 557 minecraft:black_concrete
fill 410 117 581 410 118 582 minecraft:amethyst_block
setblock 410 117 599 minecraft:purple_concrete
fill 414 117 599 415 130 599 minecraft:black_concrete
fill 415 117 557 415 130 557 minecraft:black_concrete
setblock 416 117 557 minecraft:purple_concrete
fill 418 117 558 418 117 559 minecraft:purple_concrete
fill 418 117 575 418 130 575 minecraft:black_concrete
setblock 418 117 579 minecraft:purple_concrete
fill 418 117 586 418 130 586 minecraft:black_concrete
setblock 418 117 587 minecraft:purple_concrete
setblock 418 117 590 minecraft:purple_concrete
fill 376 118 559 376 119 560 minecraft:purple_concrete
fill 376 118 561 376 130 562 minecraft:black_concrete
fill 376 118 570 376 130 570 minecraft:black_concrete
fill 376 118 571 376 118 572 minecraft:purple_concrete
fill 376 118 573 376 127 574 minecraft:black_concrete
fill 376 118 579 376 119 580 minecraft:purple_concrete
fill 376 118 581 376 130 582 minecraft:black_concrete
setblock 376 118 583 minecraft:purple_concrete
fill 376 118 591 376 119 592 minecraft:purple_concrete
fill 376 118 593 376 130 594 minecraft:black_concrete
fill 377 118 557 378 119 557 minecraft:purple_concrete
fill 377 118 599 377 119 599 minecraft:purple_concrete
fill 378 118 599 379 126 599 minecraft:black_concrete
fill 380 118 599 381 118 599 minecraft:purple_concrete
fill 382 118 599 382 131 599 minecraft:black_concrete
setblock 386 118 557 minecraft:purple_concrete
fill 387 118 557 388 130 557 minecraft:black_concrete
fill 388 118 599 389 119 599 minecraft:purple_concrete
fill 389 118 557 390 119 557 minecraft:purple_concrete
fill 390 118 599 391 130 599 minecraft:black_concrete
fill 395 118 557 396 130 557 minecraft:black_concrete
fill 397 118 557 398 118 557 minecraft:purple_concrete
fill 399 118 557 399 131 557 minecraft:black_concrete
fill 399 118 599 399 126 599 minecraft:black_concrete
fill 400 118 599 401 118 599 minecraft:purple_concrete
fill 402 118 599 403 126 599 minecraft:black_concrete
fill 407 118 557 408 127 557 minecraft:black_concrete
fill 408 118 599 409 119 599 minecraft:purple_concrete
fill 409 118 557 410 119 557 minecraft:purple_concrete
fill 410 118 599 411 130 599 minecraft:black_concrete
setblock 412 118 599 minecraft:purple_concrete
fill 416 118 557 416 127 557 minecraft:black_concrete
setblock 418 118 557 minecraft:purple_concrete
fill 418 118 558 418 130 559 minecraft:black_concrete
fill 418 118 560 418 119 560 minecraft:purple_concrete
fill 418 118 566 418 130 567 minecraft:black_concrete
fill 418 118 568 418 118 569 minecraft:purple_concrete
fill 418 118 578 418 127 579 minecraft:black_concrete
fill 418 118 580 418 119 581 minecraft:purple_concrete
fill 418 118 587 418 126 587 minecraft:black_concrete
fill 418 118 588 418 118 589 minecraft:purple_concrete
fill 418 118 590 418 130 590 minecraft:black_concrete
fill 418 118 592 418 119 592 minecraft:purple_concrete
fill 418 118 598 418 126 598 minecraft:black_concrete
fill 376 119 567 376 119 568 minecraft:purple_concrete
setblock 376 119 571 minecraft:purple_concrete
fill 376 119 572 376 129 572 minecraft:black_concrete
fill 376 119 583 376 127 583 minecraft:black_concrete
setblock 376 119 588 minecraft:purple_concrete
setblock 376 119 599 minecraft:purple_concrete
fill 380 119 599 381 128 599 minecraft:black_concrete
setblock 381 119 557 minecraft:purple_concrete
fill 386 119 557 386 126 557 minecraft:black_concrete
fill 396 119 599 397 119 599 minecraft:purple_concrete
fill 397 119 557 397 129 557 minecraft:black_concrete
setblock 398 119 557 minecraft:purple_concrete
setblock 400 119 599 minecraft:purple_concrete
fill 401 119 557 402 119 557 minecraft:purple_concrete
fill 401 119 599 401 129 599 minecraft:black_concrete
fill 412 119 599 412 129 599 minecraft:black_concrete
setblock 417 119 599 minecraft:purple_concrete
fill 418 119 557 418 126 557 minecraft:black_concrete
setblock 418 119 561 minecraft:purple_concrete
fill 418 119 568 418 129 568 minecraft:black_concrete
setblock 418 119 569 minecraft:purple_concrete
setblock 418 119 572 minecraft:purple_concrete
fill 418 119 588 418 127 589 minecraft:black_concrete
setblock 418 119 593 minecraft:purple_concrete
fill 376 120 559 376 127 560 minecraft:black_concrete
fill 376 120 567 376 130 568 minecraft:black_concrete
fill 376 120 571 376 130 571 minecraft:black_concrete
fill 376 120 579 376 130 580 minecraft:black_concrete
fill 376 120 588 376 130 588 minecraft:black_concrete
fill 376 120 591 376 129 592 minecraft:black_concrete
fill 376 120 599 377 126 599 minecraft:black_concrete
fill 377 120 557 378 127 557 minecraft:black_concrete
fill 381 120 557 381 130 557 minecraft:black_concrete
fill 388 120 599 389 130 599 minecraft:black_concrete
fill 389 120 557 390 130 557 minecraft:black_concrete
fill 395 120 577 396 120 579 minecraft:crying_obsidian
fill 396 120 576 398 120 576 minecraft:crying_obsidian
fill 396 120 580 398 120 580 minecraft:crying_obsidian
fill 396 120 599 397 130 599 minecraft:black_concrete
setblock 397 120 577 minecraft:crying_obsidian
fill 397 120 579 399 120 579 minecraft:crying_obsidian
fill 398 120 557 398 127 557 minecraft:black_concrete
fill 400 120 599 400 130 599 minecraft:black_concrete
fill 401 120 557 402 126 557 minecraft:black_concrete
fill 408 120 599 409 127 599 minecraft:black_concrete
fill 409 120 557 410 126 557 minecraft:black_concrete
fill 417 120 599 417 130 599 minecraft:black_concrete
fill 418 120 560 418 128 561 minecraft:black_concrete
fill 418 120 569 418 130 569 minecraft:black_concrete
fill 418 120 572 418 130 572 minecraft:black_concrete
fill 418 120 580 418 126 581 minecraft:black_concrete
fill 418 120 592 418 126 593 minecraft:black_concrete
fill 394 121 576 394 121 580 minecraft:crying_obsidian
fill 395 121 575 395 121 576 minecraft:crying_obsidian
fill 395 121 577 396 123 579 minecraft:magenta_concrete
fill 395 121 580 395 121 581 minecraft:crying_obsidian
fill 396 121 575 399 121 575 minecraft:crying_obsidian
fill 396 121 576 398 125 576 minecraft:magenta_concrete
fill 396 121 580 398 125 580 minecraft:magenta_concrete
fill 396 121 581 399 121 581 minecraft:crying_obsidian
fill 397 121 577 397 123 577 minecraft:magenta_concrete
fill 397 121 579 399 123 579 minecraft:magenta_concrete
fill 399 121 576 400 121 576 minecraft:crying_obsidian
fill 399 121 580 400 121 580 minecraft:crying_obsidian
fill 400 121 577 400 121 579 minecraft:crying_obsidian
fill 393 122 576 393 122 580 minecraft:crying_obsidian
setblock 394 122 575 minecraft:crying_obsidian
fill 394 122 576 394 125 580 minecraft:magenta_concrete
setblock 394 122 581 minecraft:crying_obsidian
fill 395 122 574 399 122 574 minecraft:crying_obsidian
fill 395 122 575 395 125 576 minecraft:magenta_concrete
fill 395 122 580 395 123 581 minecraft:magenta_concrete
fill 395 122 582 399 122 582 minecraft:crying_obsidian
fill 396 122 575 399 125 575 minecraft:magenta_concrete
fill 396 122 581 399 123 581 minecraft:magenta_concrete
fill 399 122 576 400 123 576 minecraft:magenta_concrete
fill 399 122 580 400 125 580 minecraft:magenta_concrete
setblock 400 122 575 minecraft:crying_obsidian
fill 400 122 577 400 125 579 minecraft:magenta_concrete
setblock 400 122 581 minecraft:crying_obsidian
fill 401 122 576 401 122 580 minecraft:crying_obsidian
fill 392 123 576 392 123 580 minecraft:crying_obsidian
fill 393 123 575 393 124 575 minecraft:crying_obsidian
fill 393 123 576 393 123 580 minecraft:magenta_concrete
setblock 393 123 581 minecraft:crying_obsidian
fill 394 123 574 394 124 574 minecraft:crying_obsidian
fill 394 123 575 394 125 575 minecraft:magenta_concrete
setblock 394 123 581 minecraft:magenta_concrete
setblock 394 123 582 minecraft:crying_obsidian
fill 395 123 573 399 128 573 minecraft:crying_obsidian
fill 395 123 574 399 125 574 minecraft:magenta_concrete
fill 395 123 582 399 123 582 minecraft:magenta_concrete
fill 395 123 583 399 123 583 minecraft:crying_obsidian
setblock 400 123 574 minecraft:crying_obsidian
setblock 400 123 575 minecraft:magenta_concrete
setblock 400 123 581 minecraft:magenta_concrete
setblock 400 123 582 minecraft:crying_obsidian
setblock 401 123 575 minecraft:crying_obsidian
fill 401 123 576 401 123 580 minecraft:magenta_concrete
setblock 401 123 581 minecraft:crying_obsidian
fill 402 123 576 402 123 580 minecraft:crying_obsidian
setblock 379 124 560 minecraft:light[level=12]
setblock 379 124 568 minecraft:light[level=12]
setblock 379 124 576 minecraft:light[level=12]
setblock 379 124 584 minecraft:light[level=12]
setblock 379 124 592 minecraft:light[level=12]
setblock 387 124 560 minecraft:light[level=12]
setblock 387 124 568 minecraft:light[level=12]
setblock 387 124 576 minecraft:light[level=12]
setblock 387 124 584 minecraft:light[level=12]
setblock 387 124 592 minecraft:light[level=12]
fill 391 124 576 393 124 578 minecraft:redstone_block
fill 392 124 579 392 128 580 minecraft:crying_obsidian
fill 393 124 574 393 127 574 minecraft:crying_obsidian
fill 393 124 579 393 125 580 minecraft:magenta_concrete
fill 393 124 581 395 124 583 minecraft:redstone_block
setblock 395 124 560 minecraft:light[level=12]
setblock 395 124 568 minecraft:light[level=12]
fill 395 124 577 395 125 580 minecraft:magenta_concrete
setblock 395 124 584 minecraft:light[level=12]
setblock 395 124 592 minecraft:light[level=12]
fill 396 124 581 398 125 582 minecraft:magenta_concrete
fill 396 124 583 398 128 583 minecraft:crying_obsidian
fill 399 124 576 399 125 576 minecraft:magenta_concrete
fill 399 124 579 399 125 579 minecraft:magenta_concrete
fill 399 124 581 401 124 583 minecraft:redstone_block
fill 400 124 574 402 124 576 minecraft:redstone_block
fill 401 124 577 401 125 580 minecraft:magenta_concrete
fill 402 124 577 402 128 580 minecraft:crying_obsidian
setblock 403 124 560 minecraft:light[level=12]
setblock 403 124 568 minecraft:light[level=12]
setblock 403 124 576 minecraft:light[level=12]
setblock 403 124 584 minecraft:light[level=12]
setblock 403 124 592 minecraft:light[level=12]
setblock 411 124 560 minecraft:light[level=12]
setblock 411 124 568 minecraft:light[level=12]
setblock 411 124 576 minecraft:light[level=12]
setblock 411 124 584 minecraft:light[level=12]
setblock 411 124 592 minecraft:light[level=12]
fill 392 125 575 392 126 575 minecraft:crying_obsidian
fill 392 125 581 392 126 581 minecraft:crying_obsidian
setblock 393 125 575 minecraft:magenta_concrete
fill 394 125 573 394 126 573 minecraft:crying_obsidian
fill 394 125 574 394 126 574 minecraft:magenta_concrete
fill 399 125 577 399 125 578 minecraft:magenta_concrete
fill 400 125 573 400 126 573 minecraft:crying_obsidian
fill 402 125 581 402 126 581 minecraft:crying_obsidian
fill 377 126 558 389 126 598 minecraft:obsidian
fill 390 126 558 392 126 574 minecraft:obsidian
fill 390 126 575 390 126 579 minecraft:crying_obsidian
fill 390 126 580 391 126 598 minecraft:obsidian
setblock 391 126 575 minecraft:crying_obsidian
fill 391 126 576 393 126 578 minecraft:obsidian
setblock 391 126 579 minecraft:crying_obsidian
fill 392 126 582 392 126 584 minecraft:crying_obsidian
fill 392 126 585 417 126 598 minecraft:obsidian
fill 393 126 558 393 126 573 minecraft:obsidian
fill 393 126 575 394 126 575 minecraft:crying_obsidian
fill 393 126 579 395 126 580 minecraft:crying_obsidian
fill 393 126 581 395 126 583 minecraft:obsidian
fill 393 126 584 396 126 584 minecraft:crying_obsidian
fill 394 126 558 417 126 572 minecraft:obsidian
fill 394 126 576 395 126 578 minecraft:crying_obsidian
fill 395 126 574 398 128 575 minecraft:magenta_concrete
fill 396 126 576 399 126 576 minecraft:crying_obsidian
fill 396 126 580 396 126 582 minecraft:crying_obsidian
fill 397 126 580 401 126 580 minecraft:crying_obsidian
fill 397 126 581 397 128 582 minecraft:magenta_concrete
setblock 397 126 584 minecraft:obsidian
fill 398 126 581 398 126 582 minecraft:crying_obsidian
fill 398 126 584 402 126 584 minecraft:crying_obsidian
fill 399 126 574 399 126 575 minecraft:crying_obsidian
fill 399 126 577 399 126 579 minecraft:crying_obsidian
fill 399 126 581 401 126 583 minecraft:obsidian
fill 400 126 574 402 126 576 minecraft:obsidian
fill 400 126 577 401 126 577 minecraft:crying_obsidian
fill 400 126 578 401 128 579 minecraft:magenta_concrete
fill 401 126 573 403 126 573 minecraft:crying_obsidian
fill 402 126 582 402 126 583 minecraft:crying_obsidian
fill 403 126 574 403 126 577 minecraft:crying_obsidian
fill 403 126 578 417 126 584 minecraft:obsidian
fill 404 126 573 417 126 577 minecraft:obsidian
setblock 376 127 599 minecraft:purple_terracotta
fill 377 127 599 377 130 599 minecraft:black_concrete
fill 378 127 599 378 128 599 minecraft:purple_terracotta
fill 379 127 599 379 130 599 minecraft:black_concrete
setblock 386 127 557 minecraft:purple_terracotta
fill 392 127 576 392 128 578 minecraft:crying_obsidian
fill 393 127 575 393 128 575 minecraft:crying_obsidian
fill 393 127 576 395 128 580 minecraft:magenta_concrete
fill 393 127 581 393 127 582 minecraft:crying_obsidian
fill 394 127 574 394 128 574 minecraft:crying_obsidian
fill 394 127 575 394 128 575 minecraft:magenta_concrete
fill 394 127 581 396 128 581 minecraft:magenta_concrete
fill 394 127 582 394 128 582 minecraft:crying_obsidian
fill 395 127 582 396 128 582 minecraft:magenta_concrete
fill 395 127 583 395 128 583 minecraft:crying_obsidian
fill 396 127 576 401 128 576 minecraft:magenta_concrete
fill 396 127 580 401 128 580 minecraft:magenta_concrete
fill 398 127 581 399 128 582 minecraft:magenta_concrete
fill 399 127 574 399 128 575 minecraft:magenta_concrete
fill 399 127 579 399 130 579 minecraft:magenta_concrete
fill 399 127 583 399 128 583 minecraft:crying_obsidian
setblock 399 127 599 minecraft:purple_terracotta
fill 400 127 574 401 127 574 minecraft:crying_obsidian
fill 400 127 575 400 128 575 minecraft:magenta_concrete
fill 400 127 577 401 128 577 minecraft:magenta_concrete
fill 400 127 581 400 128 581 minecraft:magenta_concrete
fill 400 127 582 401 127 582 minecraft:crying_obsidian
setblock 401 127 557 minecraft:purple_terracotta
fill 401 127 575 401 128 575 minecraft:crying_obsidian
fill 401 127 581 401 128 581 minecraft:crying_obsidian
fill 402 127 557 402 130 557 minecraft:black_concrete
fill 402 127 576 402 128 576 minecraft:crying_obsidian
fill 402 127 599 402 131 599 minecraft:black_concrete
setblock 403 127 599 minecraft:purple_terracotta
fill 409 127 557 409 128 557 minecraft:purple_terracotta
fill 410 127 557 410 130 557 minecraft:black_concrete
fill 413 127 557 413 128 557 minecraft:purple_terracotta
setblock 414 127 557 minecraft:black_concrete
setblock 418 127 557 minecraft:purple_terracotta
fill 418 127 570 418 131 570 minecraft:black_concrete
setblock 418 127 571 minecraft:purple_terracotta
setblock 418 127 573 minecraft:purple_terracotta
fill 418 127 580 418 130 580 minecraft:black_concrete
setblock 418 127 581 minecraft:purple_terracotta
setblock 418 127 587 minecraft:purple_terracotta
fill 418 127 592 418 130 592 minecraft:black_concrete
setblock 418 127 593 minecraft:purple_terracotta
setblock 418 127 598 minecraft:purple_terracotta
fill 376 128 557 377 128 557 minecraft:black_concrete
fill 376 128 558 376 129 558 minecraft:purple_terracotta
fill 376 128 559 376 131 559 minecraft:black_concrete
setblock 376 128 560 minecraft:purple_terracotta
setblock 376 128 573 minecraft:purple_terracotta
fill 376 128 574 376 130 574 minecraft:black_concrete
setblock 376 128 583 minecraft:purple_terracotta
setblock 376 128 589 minecraft:purple_terracotta
fill 376 128 590 376 130 590 minecraft:black_concrete
fill 376 128 599 376 130 599 minecraft:black_concrete
setblock 378 128 557 minecraft:purple_terracotta
setblock 383 128 557 minecraft:purple_terracotta
setblock 384 128 557 minecraft:black_concrete
setblock 384 128 599 minecraft:purple_terracotta
fill 385 128 557 385 129 557 minecraft:purple_terracotta
fill 385 128 599 385 130 599 minecraft:black_concrete
fill 386 128 557 386 129 557 minecraft:black_concrete
setblock 386 128 599 minecraft:purple_terracotta
fill 387 128 599 387 130 599 minecraft:black_concrete
fill 392 128 599 392 129 599 minecraft:black_concrete
setblock 393 128 581 minecraft:crying_obsidian
setblock 393 128 599 minecraft:purple_terracotta
setblock 398 128 557 minecraft:purple_terracotta
fill 399 128 599 399 130 599 minecraft:black_concrete
setblock 400 128 574 minecraft:crying_obsidian
setblock 400 128 582 minecraft:crying_obsidian
fill 401 128 557 401 130 557 minecraft:black_concrete
setblock 403 128 599 minecraft:black_concrete
setblock 407 128 557 minecraft:purple_terracotta
fill 408 128 557 408 130 557 minecraft:black_concrete
fill 408 128 599 408 130 599 minecraft:black_concrete
setblock 409 128 599 minecraft:purple_terracotta
fill 411 128 557 411 130 557 minecraft:black_concrete
setblock 412 128 557 minecraft:purple_terracotta
setblock 413 128 599 minecraft:purple_terracotta
setblock 414 128 557 minecraft:purple_terracotta
setblock 416 128 557 minecraft:purple_terracotta
fill 418 128 557 418 129 557 minecraft:black_concrete
setblock 418 128 571 minecraft:black_concrete
fill 418 128 573 418 130 573 minecraft:black_concrete
fill 418 128 578 418 130 578 minecraft:black_concrete
setblock 418 128 579 minecraft:purple_terracotta
fill 418 128 581 418 131 581 minecraft:black_concrete
setblock 418 128 582 minecraft:purple_terracotta
fill 418 128 583 418 130 583 minecraft:black_concrete
fill 418 128 587 418 130 587 minecraft:black_concrete
fill 418 128 588 418 128 589 minecraft:purple_terracotta
setblock 418 128 593 minecraft:black_concrete
fill 418 128 598 418 130 598 minecraft:black_concrete
setblock 418 128 599 minecraft:purple_terracotta
setblock 376 129 557 minecraft:purple_terracotta
fill 376 129 560 376 130 560 minecraft:black_concrete
fill 376 129 573 376 130 573 minecraft:black_concrete
setblock 376 129 583 minecraft:black_concrete
setblock 376 129 584 minecraft:purple_terracotta
fill 376 129 589 376 130 589 minecraft:black_concrete
fill 377 129 557 378 130 557 minecraft:black_concrete
fill 378 129 599 378 130 599 minecraft:black_concrete
setblock 380 129 599 minecraft:black_concrete
setblock 381 129 599 minecraft:purple_terracotta
fill 383 129 557 383 130 557 minecraft:black_concrete
setblock 384 129 557 minecraft:purple_terracotta
setblock 384 129 599 minecraft:black_concrete
fill 386 129 599 386 130 599 minecraft:black_concrete
fill 393 129 576 393 129 580 minecraft:crying_obsidian
setblock 393 129 599 minecraft:black_concrete
setblock 394 129 575 minecraft:crying_obsidian
fill 394 129 576 396 129 580 minecraft:magenta_concrete
setblock 394 129 581 minecraft:crying_obsidian
fill 395 129 574 399 129 574 minecraft:crying_obsidian
fill 395 129 575 399 129 575 minecraft:magenta_concrete
fill 395 129 581 399 129 581 minecraft:magenta_concrete
fill 395 129 582 399 129 582 minecraft:crying_obsidian
setblock 395 129 599 minecraft:purple_terracotta
fill 397 129 576 397 130 577 minecraft:magenta_concrete
fill 397 129 579 398 130 580 minecraft:magenta_concrete
fill 398 129 557 398 130 557 minecraft:black_concrete
fill 398 129 576 400 129 576 minecraft:magenta_concrete
fill 399 129 580 400 129 580 minecraft:magenta_concrete
setblock 400 129 575 minecraft:crying_obsidian
fill 400 129 577 400 129 579 minecraft:magenta_concrete
setblock 400 129 581 minecraft:crying_obsidian
fill 401 129 576 401 129 580 minecraft:crying_obsidian
setblock 403 129 599 minecraft:purple_terracotta
setblock 404 129 599 minecraft:black_concrete
setblock 405 129 599 minecraft:purple_terracotta
fill 407 129 557 407 130 557 minecraft:black_concrete
fill 409 129 557 409 130 557 minecraft:black_concrete
fill 409 129 599 409 130 599 minecraft:black_concrete
fill 412 129 557 414 130 557 minecraft:black_concrete
setblock 413 129 599 minecraft:black_concrete
fill 416 129 557 416 131 557 minecraft:black_concrete
fill 418 129 560 418 130 560 minecraft:black_concrete
setblock 418 129 561 minecraft:purple_terracotta
setblock 418 129 571 minecraft:purple_terracotta
setblock 418 129 576 minecraft:purple_terracotta
setblock 418 129 577 minecraft:black_concrete
fill 418 129 579 418 130 579 minecraft:black_concrete
fill 418 129 582 418 130 582 minecraft:black_concrete
fill 418 129 588 418 129 589 minecraft:black_concrete
setblock 418 129 593 minecraft:purple_terracotta
fill 418 129 599 418 131 599 minecraft:black_concrete
fill 376 130 557 376 130 558 minecraft:black_concrete
fill 376 130 563 376 130 564 minecraft:purple_concrete
fill 376 130 572 376 131 572 minecraft:purple_concrete
setblock 376 130 575 minecraft:purple_concrete
fill 376 130 576 376 131 576 minecraft:black_concrete
fill 376 130 583 376 131 584 minecraft:purple_concrete
setblock 376 130 591 minecraft:black_concrete
fill 376 130 592 376 131 592 minecraft:purple_concrete
fill 376 130 595 376 130 596 minecraft:purple_concrete
fill 380 130 599 381 131 599 minecraft:purple_concrete
setblock 384 130 557 minecraft:black_concrete
setblock 384 130 599 minecraft:purple_concrete
fill 385 130 557 386 131 557 minecraft:purple_concrete
fill 392 130 599 393 130 599 minecraft:purple_concrete
setblock 393 130 557 minecraft:black_concrete
setblock 394 130 557 minecraft:purple_concrete
fill 394 130 576 394 130 580 minecraft:crying_obsidian
fill 395 130 575 395 130 576 minecraft:crying_obsidian
fill 395 130 577 396 130 579 minecraft:magenta_concrete
fill 395 130 580 395 130 581 minecraft:crying_obsidian
setblock 395 130 599 minecraft:black_concrete
fill 396 130 575 399 130 575 minecraft:crying_obsidian
setblock 396 130 576 minecraft:magenta_concrete
setblock 396 130 580 minecraft:magenta_concrete
fill 396 130 581 399 130 581 minecraft:crying_obsidian
fill 397 130 557 397 131 557 minecraft:purple_concrete
setblock 398 130 576 minecraft:magenta_concrete
fill 399 130 576 400 130 576 minecraft:crying_obsidian
fill 399 130 580 400 130 580 minecraft:crying_obsidian
fill 400 130 577 400 130 579 minecraft:crying_obsidian
fill 401 130 599 401 131 599 minecraft:purple_concrete
setblock 403 130 599 minecraft:black_concrete
setblock 404 130 599 minecraft:purple_concrete
fill 405 130 557 406 130 557 minecraft:purple_concrete
setblock 405 130 599 minecraft:black_concrete
fill 407 130 568 412 131 569 minecraft:black_concrete
fill 408 130 567 411 131 567 minecraft:black_concrete
fill 408 130 570 412 132 571 minecraft:black_concrete
fill 409 130 572 411 131 572 minecraft:black_concrete
fill 412 130 599 413 131 599 minecraft:purple_concrete
fill 417 130 557 418 131 557 minecraft:purple_concrete
setblock 418 130 561 minecraft:black_concrete
fill 418 130 564 418 130 565 minecraft:purple_concrete
fill 418 130 568 418 131 568 minecraft:purple_concrete
setblock 418 130 571 minecraft:black_concrete
fill 418 130 576 418 131 577 minecraft:purple_concrete
setblock 418 130 584 minecraft:black_concrete
setblock 418 130 585 minecraft:purple_concrete
fill 418 130 588 418 131 589 minecraft:purple_concrete
setblock 418 130 593 minecraft:black_concrete
fill 418 130 596 418 130 597 minecraft:purple_concrete
fill 376 131 557 376 131 558 minecraft:purple_terracotta
setblock 376 131 560 minecraft:purple_concrete
fill 376 131 561 376 131 562 minecraft:purple_terracotta
setblock 376 131 563 minecraft:purple_concrete
fill 376 131 564 376 131 570 minecraft:purple_terracotta
setblock 376 131 571 minecraft:purple_concrete
fill 376 131 573 376 131 575 minecraft:purple_terracotta
fill 376 131 577 376 132 577 minecraft:purple_terracotta
setblock 376 131 578 minecraft:black_concrete
fill 376 131 579 376 133 579 minecraft:purple_terracotta
setblock 376 131 580 minecraft:purple_concrete
fill 376 131 581 376 131 582 minecraft:purple_terracotta
fill 376 131 585 376 131 590 minecraft:purple_terracotta
setblock 376 131 591 minecraft:purple_concrete
fill 376 131 593 376 131 594 minecraft:purple_terracotta
setblock 376 131 595 minecraft:purple_concrete
fill 376 131 596 376 134 597 minecraft:purple_terracotta
setblock 376 131 598 minecraft:black_concrete
fill 376 131 599 379 131 599 minecraft:purple_terracotta
fill 377 131 557 378 131 557 minecraft:purple_concrete
fill 379 131 557 381 131 557 minecraft:purple_terracotta
fill 383 131 557 384 135 557 minecraft:purple_terracotta
fill 383 131 599 388 131 599 minecraft:purple_terracotta
fill 387 131 557 396 131 557 minecraft:purple_terracotta
setblock 389 131 599 minecraft:purple_concrete
fill 390 131 599 391 131 599 minecraft:purple_terracotta
setblock 392 131 599 minecraft:purple_concrete
fill 393 131 599 399 131 599 minecraft:purple_terracotta
fill 395 131 577 397 131 579 minecraft:crying_obsidian
fill 396 131 576 398 131 576 minecraft:crying_obsidian
fill 396 131 580 398 131 580 minecraft:crying_obsidian
setblock 398 131 557 minecraft:purple_concrete
fill 398 131 579 399 131 579 minecraft:crying_obsidian
fill 400 131 557 403 131 557 minecraft:purple_terracotta
setblock 400 131 599 minecraft:purple_concrete
fill 402 131 585 403 132 586 minecraft:amethyst_block
fill 403 131 599 411 131 599 minecraft:purple_terracotta
fill 405 131 557 405 132 557 minecraft:purple_terracotta
setblock 406 131 557 minecraft:purple_concrete
fill 407 131 557 408 131 557 minecraft:purple_terracotta
fill 407 131 566 407 131 567 minecraft:black_concrete
fill 407 131 570 407 133 570 minecraft:black_concrete
fill 408 131 566 410 131 566 minecraft:black_concrete
setblock 409 131 557 minecraft:purple_concrete
fill 410 131 557 411 131 557 minecraft:purple_terracotta
setblock 412 131 557 minecraft:black_concrete
fill 413 131 557 415 132 557 minecraft:purple_terracotta
setblock 414 131 599 minecraft:purple_terracotta
setblock 415 131 599 minecraft:black_concrete
fill 417 131 599 417 132 599 minecraft:purple_terracotta
fill 418 131 558 418 131 567 minecraft:purple_terracotta
setblock 418 131 569 minecraft:purple_concrete
fill 418 131 571 418 131 575 minecraft:purple_terracotta
fill 418 131 578 418 131 579 minecraft:purple_terracotta
setblock 418 131 580 minecraft:purple_concrete
fill 418 131 582 418 131 584 minecraft:purple_terracotta
setblock 418 131 585 minecraft:black_concrete
fill 418 131 586 418 135 587 minecraft:purple_terracotta
setblock 418 131 590 minecraft:purple_terracotta
fill 418 131 592 418 131 596 minecraft:purple_terracotta
setblock 418 131 597 minecraft:purple_concrete
fill 418 131 598 418 135 598 minecraft:purple_terracotta
fill 376 132 557 378 132 557 minecraft:purple_terracotta
fill 376 132 558 376 133 558 minecraft:purple_concrete
fill 376 132 559 376 133 560 minecraft:purple_terracotta
fill 376 132 561 376 132 562 minecraft:purple_concrete
fill 376 132 563 376 132 568 minecraft:purple_terracotta
fill 376 132 569 376 133 570 minecraft:purple_concrete
fill 376 132 571 376 135 573 minecraft:purple_terracotta
fill 376 132 574 376 132 575 minecraft:black_concrete
fill 376 132 576 376 133 576 minecraft:purple_terracotta
setblock 376 132 578 minecraft:purple_terracotta
fill 376 132 580 376 133 580 minecraft:purple_terracotta
fill 376 132 581 376 132 582 minecraft:purple_concrete
setblock 376 132 583 minecraft:black_concrete
fill 376 132 584 376 132 588 minecraft:purple_terracotta
fill 376 132 589 376 133 590 minecraft:purple_concrete
fill 376 132 591 376 137 592 minecraft:purple_terracotta
setblock 376 132 593 minecraft:purple_concrete
fill 376 132 594 376 134 595 minecraft:purple_terracotta
fill 376 132 598 376 132 599 minecraft:purple_terracotta
fill 377 132 558 379 132 558 minecraft:obsidian
fill 377 132 560 377 132 562 minecraft:obsidian
fill 377 132 564 377 132 566 minecraft:obsidian
fill 377 132 568 377 132 570 minecraft:obsidian
fill 377 132 572 377 132 574 minecraft:obsidian
fill 377 132 576 377 132 578 minecraft:obsidian
fill 377 132 580 377 132 582 minecraft:obsidian
fill 377 132 584 377 132 586 minecraft:obsidian
fill 377 132 588 377 132 590 minecraft:obsidian
fill 377 132 592 377 132 594 minecraft:obsidian
fill 377 132 596 377 132 598 minecraft:obsidian
fill 377 132 599 377 133 599 minecraft:purple_terracotta
fill 378 132 599 379 133 599 minecraft:purple_concrete
fill 379 132 557 379 133 557 minecraft:purple_concrete
setblock 379 132 560 minecraft:light[level=12]
setblock 379 132 568 minecraft:light[level=12]
setblock 379 132 576 minecraft:light[level=12]
setblock 379 132 584 minecraft:light[level=12]
setblock 379 132 592 minecraft:light[level=12]
fill 379 132 598 381 132 598 minecraft:obsidian
setblock 380 132 557 minecraft:black_concrete
fill 380 132 599 380 137 599 minecraft:purple_terracotta
fill 381 132 557 382 133 557 minecraft:purple_terracotta
fill 381 132 558 383 132 558 minecraft:obsidian
setblock 381 132 599 minecraft:black_concrete
fill 382 132 599 383 135 599 minecraft:purple_terracotta
fill 383 132 598 385 132 598 minecraft:obsidian
fill 384 132 599 385 132 599 minecraft:black_concrete
fill 385 132 557 386 137 557 minecraft:purple_terracotta
fill 385 132 558 387 132 558 minecraft:obsidian
setblock 386 132 599 minecraft:purple_terracotta
fill 387 132 557 388 132 557 minecraft:purple_concrete
setblock 387 132 560 minecraft:light[level=12]
setblock 387 132 568 minecraft:light[level=12]
setblock 387 132 576 minecraft:light[level=12]
setblock 387 132 584 minecraft:light[level=12]
setblock 387 132 592 minecraft:light[level=12]
fill 387 132 598 389 132 598 minecraft:obsidian
fill 387 132 599 387 133 599 minecraft:purple_concrete
fill 388 132 599 389 133 599 minecraft:purple_terracotta
fill 389 132 557 398 132 557 minecraft:purple_terracotta
fill 389 132 558 391 132 558 minecraft:obsidian
fill 390 132 599 391 132 599 minecraft:purple_concrete
fill 391 132 598 393 132 598 minecraft:obsidian
fill 392 132 599 397 132 599 minecraft:purple_terracotta
fill 393 132 558 395 132 558 minecraft:obsidian
setblock 395 132 560 minecraft:light[level=12]
setblock 395 132 568 minecraft:light[level=12]
setblock 395 132 576 minecraft:light[level=12]
setblock 395 132 584 minecraft:light[level=12]
setblock 395 132 592 minecraft:light[level=12]
fill 395 132 598 397 132 598 minecraft:obsidian
fill 397 132 558 399 132 558 minecraft:obsidian
fill 398 132 599 399 133 599 minecraft:purple_concrete
fill 399 132 557 400 133 557 minecraft:purple_concrete
fill 399 132 598 401 132 598 minecraft:obsidian
fill 400 132 599 406 132 599 minecraft:purple_terracotta
fill 401 132 557 404 132 557 minecraft:purple_terracotta
fill 401 132 558 403 132 558 minecraft:obsidian
setblock 403 132 560 minecraft:light[level=12]
setblock 403 132 568 minecraft:light[level=12]
setblock 403 132 576 minecraft:light[level=12]
setblock 403 132 584 minecraft:light[level=12]
setblock 403 132 592 minecraft:light[level=12]
fill 403 132 598 405 132 598 minecraft:obsidian
fill 405 132 558 407 132 558 minecraft:obsidian
fill 406 132 557 406 137 557 minecraft:purple_terracotta
fill 406 132 565 408 136 567 minecraft:purple_concrete
fill 406 132 568 406 132 569 minecraft:black_concrete
fill 407 132 557 408 132 557 minecraft:purple_concrete
fill 407 132 568 407 136 568 minecraft:purple_concrete
fill 407 132 569 412 132 569 minecraft:black_concrete
fill 407 132 598 409 132 598 minecraft:obsidian
setblock 407 132 599 minecraft:black_concrete
fill 408 132 568 411 132 568 minecraft:black_concrete
fill 408 132 599 409 133 599 minecraft:purple_terracotta
fill 409 132 557 410 133 557 minecraft:purple_terracotta
fill 409 132 558 411 132 558 minecraft:obsidian
fill 409 132 565 409 132 567 minecraft:black_concrete
fill 410 132 566 410 134 567 minecraft:black_concrete
setblock 410 132 572 minecraft:black_concrete
fill 410 132 599 411 132 599 minecraft:purple_concrete
fill 411 132 557 411 133 557 minecraft:purple_concrete
setblock 411 132 560 minecraft:light[level=12]
fill 411 132 567 411 133 567 minecraft:black_concrete
setblock 411 132 576 minecraft:light[level=12]
setblock 411 132 584 minecraft:light[level=12]
setblock 411 132 592 minecraft:light[level=12]
fill 411 132 598 413 132 598 minecraft:obsidian
setblock 412 132 557 minecraft:purple_terracotta
setblock 412 132 599 minecraft:black_concrete
fill 413 132 558 415 132 558 minecraft:obsidian
fill 413 132 599 413 137 599 minecraft:purple_terracotta
fill 414 132 599 414 133 599 minecraft:black_concrete
fill 415 132 598 417 132 598 minecraft:obsidian
fill 415 132 599 415 135 599 minecraft:purple_terracotta
fill 416 132 557 418 132 557 minecraft:purple_terracotta
fill 417 132 558 417 132 560 minecraft:obsidian
fill 417 132 562 417 132 564 minecraft:obsidian
fill 417 132 566 417 132 568 minecraft:obsidian
fill 417 132 570 417 132 572 minecraft:obsidian
fill 417 132 574 417 132 576 minecraft:obsidian
fill 417 132 578 417 132 580 minecraft:obsidian
fill 417 132 582 417 132 584 minecraft:obsidian
fill 417 132 586 417 132 588 minecraft:obsidian
fill 417 132 590 417 132 592 minecraft:obsidian
fill 417 132 594 417 132 596 minecraft:obsidian
fill 418 132 558 418 133 559 minecraft:purple_concrete
fill 418 132 560 418 132 566 minecraft:purple_terracotta
setblock 418 132 567 minecraft:purple_concrete
fill 418 132 568 418 132 569 minecraft:purple_terracotta
fill 418 132 570 418 133 571 minecraft:purple_concrete
fill 418 132 572 418 133 577 minecraft:purple_terracotta
fill 418 132 578 418 132 579 minecraft:purple_concrete
setblock 418 132 580 minecraft:black_concrete
fill 418 132 581 418 133 581 minecraft:purple_terracotta
setblock 418 132 582 minecraft:black_concrete
fill 418 132 583 418 132 585 minecraft:purple_terracotta
fill 418 132 588 418 137 589 minecraft:purple_terracotta
fill 418 132 590 418 133 591 minecraft:purple_concrete
fill 418 132 592 418 133 594 minecraft:purple_terracotta
setblock 418 132 595 minecraft:black_concrete
fill 418 132 596 418 134 597 minecraft:purple_terracotta
setblock 418 132 599 minecraft:purple_terracotta
setblock 376 133 557 minecraft:purple_concrete
fill 376 133 561 376 136 561 minecraft:purple_terracotta
setblock 376 133 562 minecraft:black_concrete
fill 376 133 563 376 134 564 minecraft:purple_terracotta
fill 376 133 565 376 133 566 minecraft:black_concrete
fill 376 133 567 376 133 568 minecraft:purple_terracotta
fill 376 133 574 376 134 575 minecraft:purple_terracotta
fill 376 133 577 376 133 578 minecraft:purple_concrete
setblock 376 133 581 minecraft:purple_concrete
fill 376 133 582 376 136 584 minecraft:purple_terracotta
setblock 376 133 585 minecraft:black_concrete
fill 376 133 586 376 133 588 minecraft:purple_terracotta
fill 376 133 593 376 136 593 minecraft:purple_terracotta
setblock 376 133 598 minecraft:purple_concrete
setblock 376 133 599 minecraft:purple_terracotta
fill 377 133 557 378 137 557 minecraft:purple_terracotta
setblock 380 133 557 minecraft:purple_concrete
fill 381 133 599 381 137 599 minecraft:purple_terracotta
fill 384 133 599 385 133 599 minecraft:purple_terracotta
setblock 386 133 599 minecraft:purple_concrete
fill 387 133 557 387 136 557 minecraft:purple_terracotta
setblock 388 133 557 minecraft:purple_concrete
fill 389 133 557 390 133 557 minecraft:purple_terracotta
fill 390 133 599 395 134 599 minecraft:purple_terracotta
setblock 391 133 557 minecraft:purple_concrete
fill 392 133 557 398 133 557 minecraft:purple_terracotta
setblock 396 133 599 minecraft:black_concrete
setblock 397 133 599 minecraft:purple_terracotta
fill 400 133 599 400 137 599 minecraft:purple_terracotta
fill 401 133 557 402 133 557 minecraft:purple_terracotta
setblock 401 133 599 minecraft:black_concrete
fill 402 133 599 406 133 599 minecraft:purple_terracotta
fill 403 133 557 405 133 557 minecraft:black_concrete
fill 405 133 564 405 137 567 minecraft:purple_concrete
fill 406 133 564 408 136 564 minecraft:purple_concrete
fill 406 133 568 406 136 568 minecraft:purple_concrete
fill 406 133 569 411 133 569 minecraft:black_concrete
fill 407 133 557 408 136 557 minecraft:purple_terracotta
setblock 407 133 599 minecraft:purple_concrete
fill 408 133 568 408 136 568 minecraft:purple_concrete
fill 408 133 570 411 133 570 minecraft:black_concrete
fill 409 133 565 409 135 567 minecraft:purple_concrete
fill 409 133 568 411 133 568 minecraft:black_concrete
fill 409 133 571 410 133 571 minecraft:black_concrete
setblock 410 133 599 minecraft:purple_concrete
fill 411 133 599 412 136 599 minecraft:purple_terracotta
setblock 412 133 557 minecraft:purple_concrete
fill 413 133 557 414 133 557 minecraft:purple_terracotta
fill 415 133 557 416 133 557 minecraft:black_concrete
setblock 416 133 599 minecraft:purple_terracotta
fill 417 133 557 417 137 557 minecraft:purple_terracotta
setblock 417 133 599 minecraft:black_concrete
setblock 418 133 557 minecraft:black_concrete
fill 418 133 560 418 133 561 minecraft:purple_terracotta
setblock 418 133 562 minecraft:purple_concrete
fill 418 133 563 418 134 567 minecraft:purple_terracotta
setblock 418 133 568 minecraft:black_concrete
fill 418 133 569 418 137 569 minecraft:purple_terracotta
fill 418 133 578 418 136 578 minecraft:purple_terracotta
setblock 418 133 579 minecraft:purple_concrete
fill 418 133 580 418 137 580 minecraft:purple_terracotta
fill 418 133 582 418 133 583 minecraft:purple_concrete
fill 418 133 584 418 133 585 minecraft:purple_terracotta
fill 418 133 595 418 135 595 minecraft:purple_terracotta
setblock 418 133 599 minecraft:purple_concrete
fill 376 134 557 376 139 558 minecraft:purple_terracotta
setblock 376 134 559 minecraft:purple_concrete
fill 376 134 560 376 137 560 minecraft:purple_terracotta
fill 376 134 562 376 136 562 minecraft:purple_terracotta
fill 376 134 565 376 135 566 minecraft:purple_terracotta
fill 376 134 567 376 135 568 minecraft:purple_concrete
fill 376 134 569 376 139 570 minecraft:purple_terracotta
fill 376 134 576 376 135 576 minecraft:purple_concrete
fill 376 134 577 376 135 578 minecraft:purple_terracotta
fill 376 134 579 376 134 580 minecraft:purple_concrete
fill 376 134 581 376 139 581 minecraft:purple_terracotta
fill 376 134 585 376 135 586 minecraft:purple_terracotta
fill 376 134 587 376 135 588 minecraft:purple_concrete
fill 376 134 589 376 139 590 minecraft:purple_terracotta
fill 376 134 598 376 135 598 minecraft:purple_terracotta
fill 376 134 599 377 134 599 minecraft:purple_concrete
fill 378 134 599 379 139 599 minecraft:purple_terracotta
fill 379 134 557 380 139 557 minecraft:purple_terracotta
fill 381 134 557 382 135 557 minecraft:purple_concrete
fill 384 134 599 385 135 599 minecraft:purple_concrete
fill 386 134 599 387 139 599 minecraft:purple_terracotta
fill 388 134 557 388 139 557 minecraft:purple_terracotta
setblock 388 134 599 minecraft:purple_concrete
fill 389 134 557 390 134 557 minecraft:purple_concrete
fill 389 134 599 389 137 599 minecraft:purple_terracotta
fill 391 134 557 392 135 557 minecraft:purple_terracotta
fill 393 134 557 393 135 557 minecraft:purple_concrete
fill 394 134 557 400 134 557 minecraft:purple_terracotta
fill 396 134 599 397 135 599 minecraft:purple_concrete
fill 398 134 599 399 139 599 minecraft:purple_terracotta
fill 401 134 557 402 135 557 minecraft:purple_concrete
fill 401 134 599 404 134 599 minecraft:purple_terracotta
fill 403 134 557 405 134 557 minecraft:purple_terracotta
fill 404 134 564 404 137 567 minecraft:purple_concrete
fill 405 134 563 406 138 563 minecraft:purple_concrete
fill 405 134 568 405 135 568 minecraft:purple_concrete
fill 405 134 599 405 135 599 minecraft:purple_concrete
fill 406 134 569 410 134 569 minecraft:black_concrete
fill 406 134 599 407 135 599 minecraft:purple_terracotta
fill 408 134 570 409 134 570 minecraft:black_concrete
fill 408 134 599 409 134 599 minecraft:purple_concrete
fill 409 134 557 409 137 557 minecraft:purple_terracotta
setblock 409 134 568 minecraft:purple_concrete
setblock 410 134 557 minecraft:purple_concrete
setblock 410 134 568 minecraft:black_concrete
fill 410 134 599 410 139 599 minecraft:purple_terracotta
fill 411 134 557 412 139 557 minecraft:purple_terracotta
fill 413 134 557 414 135 557 minecraft:purple_concrete
fill 414 134 599 414 135 599 minecraft:purple_terracotta
fill 415 134 557 416 135 557 minecraft:purple_terracotta
fill 416 134 599 417 135 599 minecraft:purple_concrete
fill 418 134 557 418 137 559 minecraft:purple_terracotta
fill 418 134 560 418 134 561 minecraft:purple_concrete
fill 418 134 562 418 139 562 minecraft:purple_terracotta
fill 418 134 568 418 137 568 minecraft:purple_terracotta
fill 418 134 570 418 139 571 minecraft:purple_terracotta
fill 418 134 572 418 135 573 minecraft:purple_concrete
fill 418 134 574 418 135 577 minecraft:purple_terracotta
fill 418 134 579 418 139 579 minecraft:purple_terracotta
setblock 418 134 581 minecraft:purple_concrete
fill 418 134 582 418 139 583 minecraft:purple_terracotta
fill 418 134 584 418 135 584 minecraft:purple_concrete
setblock 418 134 585 minecraft:purple_terracotta
fill 418 134 590 418 139 591 minecraft:purple_terracotta
fill 418 134 592 418 134 593 minecraft:purple_concrete
fill 418 134 594 418 135 594 minecraft:purple_terracotta
fill 418 134 599 418 139 599 minecraft:purple_terracotta
fill 376 135 559 376 138 559 minecraft:purple_terracotta
fill 376 135 563 376 137 563 minecraft:purple_terracotta
setblock 376 135 564 minecraft:purple_concrete
setblock 376 135 574 minecraft:purple_terracotta
setblock 376 135 575 minecraft:purple_concrete
fill 376 135 579 376 137 580 minecraft:purple_terracotta
setblock 376 135 594 minecraft:purple_terracotta
fill 376 135 595 376 135 596 minecraft:purple_concrete
setblock 376 135 597 minecraft:purple_terracotta
setblock 376 135 599 minecraft:purple_concrete
fill 377 135 599 377 138 599 minecraft:purple_terracotta
fill 388 135 599 388 138 599 minecraft:purple_terracotta
fill 389 135 557 390 138 557 minecraft:purple_terracotta
fill 390 135 599 392 136 599 minecraft:purple_terracotta
setblock 393 135 599 minecraft:purple_concrete
setblock 394 135 557 minecraft:purple_concrete
fill 394 135 599 395 135 599 minecraft:purple_terracotta
fill 395 135 557 400 135 557 minecraft:purple_terracotta
fill 401 135 599 403 135 599 minecraft:purple_terracotta
fill 402 135 564 403 141 564 minecraft:purple_concrete
fill 403 135 557 404 135 557 minecraft:purple_terracotta
fill 403 135 563 404 140 563 minecraft:purple_concrete
fill 403 135 565 403 139 566 minecraft:purple_concrete
setblock 404 135 599 minecraft:purple_concrete
setblock 405 135 557 minecraft:purple_concrete
fill 407 135 563 407 136 563 minecraft:purple_concrete
fill 407 135 569 408 135 569 minecraft:black_concrete
fill 408 135 599 409 138 599 minecraft:purple_terracotta
setblock 409 135 568 minecraft:black_concrete
fill 410 135 557 410 138 557 minecraft:purple_terracotta
fill 418 135 560 418 138 560 minecraft:purple_terracotta
setblock 418 135 561 minecraft:purple_concrete
setblock 418 135 563 minecraft:purple_terracotta
fill 418 135 564 418 135 565 minecraft:purple_concrete
fill 418 135 566 418 135 567 minecraft:purple_terracotta
fill 418 135 581 418 138 581 minecraft:purple_terracotta
setblock 418 135 585 minecraft:purple_concrete
fill 418 135 592 418 138 592 minecraft:purple_terracotta
setblock 418 135 593 minecraft:purple_concrete
setblock 418 135 596 minecraft:purple_concrete
fill 418 135 597 418 137 597 minecraft:purple_terracotta
fill 376 136 564 376 141 564 minecraft:purple_terracotta
fill 376 136 565 376 136 566 minecraft:purple_concrete
fill 376 136 567 376 138 568 minecraft:purple_terracotta
fill 376 136 571 376 137 572 minecraft:purple_terracotta
fill 376 136 573 376 137 574 minecraft:purple_concrete
fill 376 136 575 376 141 576 minecraft:purple_terracotta
setblock 376 136 577 minecraft:purple_concrete
fill 376 136 578 376 139 578 minecraft:purple_terracotta
fill 376 136 585 376 137 586 minecraft:purple_concrete
fill 376 136 587 376 141 588 minecraft:purple_terracotta
fill 376 136 594 376 137 594 minecraft:purple_concrete
fill 376 136 595 376 137 596 minecraft:purple_terracotta
fill 376 136 597 376 136 598 minecraft:purple_concrete
fill 376 136 599 376 141 599 minecraft:purple_terracotta
fill 381 136 557 382 141 557 minecraft:purple_terracotta
fill 382 136 583 382 137 583 minecraft:amethyst_block
fill 382 136 599 383 137 599 minecraft:purple_concrete
fill 383 136 557 384 137 557 minecraft:purple_concrete
fill 384 136 599 385 141 599 minecraft:purple_terracotta
fill 391 136 557 391 139 557 minecraft:purple_terracotta
setblock 392 136 557 minecraft:purple_concrete
fill 393 136 557 394 141 557 minecraft:purple_terracotta
fill 393 136 599 393 141 599 minecraft:purple_terracotta
fill 394 136 599 395 136 599 minecraft:purple_concrete
fill 395 136 557 396 137 557 minecraft:purple_concrete
fill 396 136 599 397 141 599 minecraft:purple_terracotta
fill 397 136 557 402 137 557 minecraft:purple_terracotta
fill 401 136 563 401 139 564 minecraft:purple_concrete
fill 401 136 599 401 137 599 minecraft:purple_terracotta
fill 402 136 562 402 141 563 minecraft:purple_concrete
fill 402 136 565 402 139 566 minecraft:purple_concrete
fill 402 136 599 403 137 599 minecraft:purple_concrete
fill 403 136 557 404 136 557 minecraft:purple_concrete
fill 403 136 562 405 138 562 minecraft:purple_concrete
fill 404 136 599 405 141 599 minecraft:purple_terracotta
fill 405 136 557 405 141 557 minecraft:purple_terracotta
setblock 406 136 599 minecraft:purple_concrete
fill 407 136 599 407 139 599 minecraft:purple_terracotta
setblock 409 136 566 minecraft:purple_concrete
fill 413 136 557 414 141 557 minecraft:purple_terracotta
fill 414 136 599 415 137 599 minecraft:purple_concrete
fill 415 136 557 416 137 557 minecraft:purple_concrete
fill 416 136 599 417 141 599 minecraft:purple_terracotta
fill 418 136 561 418 141 561 minecraft:purple_terracotta
setblock 418 136 563 minecraft:purple_concrete
fill 418 136 564 418 141 565 minecraft:purple_terracotta
fill 418 136 566 418 137 566 minecraft:purple_concrete
setblock 418 136 567 minecraft:purple_terracotta
fill 418 136 572 418 141 573 minecraft:purple_terracotta
fill 418 136 574 418 136 575 minecraft:purple_concrete
fill 418 136 576 418 137 577 minecraft:purple_terracotta
fill 418 136 584 418 141 585 minecraft:purple_terracotta
fill 418 136 586 418 137 587 minecraft:purple_concrete
fill 418 136 593 418 141 593 minecraft:purple_terracotta
fill 418 136 594 418 136 595 minecraft:purple_concrete
fill 418 136 596 418 141 596 minecraft:purple_terracotta
fill 418 136 598 418 137 598 minecraft:purple_concrete
fill 376 137 561 376 137 562 minecraft:purple_concrete
setblock 376 137 565 minecraft:purple_concrete
fill 376 137 566 376 140 566 minecraft:purple_terracotta
fill 376 137 577 376 139 577 minecraft:purple_terracotta
setblock 376 137 582 minecraft:purple_concrete
fill 376 137 583 376 137 584 minecraft:purple_terracotta
setblock 376 137 593 minecraft:purple_concrete
fill 376 137 597 376 139 598 minecraft:purple_terracotta
setblock 387 137 557 minecraft:purple_concrete
fill 390 137 599 391 137 599 minecraft:purple_concrete
fill 392 137 557 392 140 557 minecraft:purple_terracotta
setblock 392 137 599 minecraft:purple_terracotta
setblock 394 137 599 minecraft:purple_concrete
fill 395 137 599 395 140 599 minecraft:purple_terracotta
fill 400 137 563 400 138 564 minecraft:purple_concrete
fill 401 137 562 401 139 562 minecraft:purple_concrete
fill 401 137 565 401 141 565 minecraft:purple_concrete
fill 403 137 557 403 140 557 minecraft:purple_terracotta
setblock 404 137 557 minecraft:purple_concrete
fill 406 137 564 407 137 567 minecraft:purple_concrete
fill 406 137 599 406 140 599 minecraft:purple_terracotta
fill 407 137 557 408 137 557 minecraft:purple_concrete
setblock 411 137 599 minecraft:purple_concrete
setblock 412 137 599 minecraft:purple_terracotta
fill 418 137 563 418 140 563 minecraft:purple_terracotta
setblock 418 137 567 minecraft:purple_concrete
fill 418 137 574 418 140 574 minecraft:purple_terracotta
setblock 418 137 575 minecraft:purple_concrete
setblock 418 137 578 minecraft:purple_concrete
fill 418 137 594 418 140 595 minecraft:purple_terracotta
fill 376 138 560 376 139 560 minecraft:purple_concrete
fill 376 138 561 376 143 562 minecraft:purple_terracotta
setblock 376 138 563 minecraft:purple_concrete
fill 376 138 565 376 140 565 minecraft:purple_terracotta
fill 376 138 571 376 139 572 minecraft:purple_concrete
fill 376 138 573 376 143 574 minecraft:purple_terracotta
setblock 376 138 579 minecraft:purple_terracotta
fill 376 138 580 376 139 580 minecraft:purple_concrete
fill 376 138 582 376 143 582 minecraft:purple_terracotta
fill 376 138 583 376 138 584 minecraft:purple_concrete
fill 376 138 585 376 140 586 minecraft:purple_terracotta
fill 376 138 591 376 139 592 minecraft:purple_concrete
fill 376 138 593 376 143 594 minecraft:purple_terracotta
setblock 376 138 595 minecraft:purple_concrete
fill 376 138 596 376 141 596 minecraft:purple_terracotta
fill 377 138 557 378 139 557 minecraft:purple_concrete
fill 377 138 558 379 138 558 minecraft:obsidian
fill 377 138 560 377 138 562 minecraft:obsidian
fill 377 138 564 377 138 566 minecraft:obsidian
fill 377 138 568 377 138 570 minecraft:obsidian
fill 377 138 572 377 138 574 minecraft:obsidian
fill 377 138 576 377 138 578 minecraft:obsidian
fill 377 138 580 377 138 582 minecraft:obsidian
fill 377 138 584 377 138 586 minecraft:obsidian
fill 377 138 588 377 138 590 minecraft:obsidian
fill 377 138 592 377 138 594 minecraft:obsidian
fill 377 138 596 377 138 598 minecraft:obsidian
fill 379 138 598 381 138 598 minecraft:obsidian
fill 380 138 599 381 138 599 minecraft:purple_concrete
fill 381 138 558 383 138 558 minecraft:obsidian
fill 381 138 584 381 139 585 minecraft:obsidian
fill 382 138 583 382 145 584 minecraft:obsidian
fill 382 138 599 383 143 599 minecraft:purple_terracotta
fill 383 138 557 384 143 557 minecraft:purple_terracotta
fill 383 138 598 385 138 598 minecraft:obsidian
fill 385 138 557 386 138 557 minecraft:purple_concrete
fill 385 138 558 387 138 558 minecraft:obsidian
fill 387 138 557 387 143 557 minecraft:purple_terracotta
fill 387 138 598 389 138 598 minecraft:obsidian
fill 389 138 558 391 138 558 minecraft:obsidian
fill 389 138 599 389 139 599 minecraft:purple_concrete
fill 390 138 599 391 143 599 minecraft:purple_terracotta
fill 391 138 598 393 138 598 minecraft:obsidian
setblock 392 138 599 minecraft:purple_concrete
fill 393 138 558 395 138 558 minecraft:obsidian
fill 394 138 599 394 143 599 minecraft:purple_terracotta
fill 395 138 557 396 143 557 minecraft:purple_terracotta
fill 395 138 598 397 138 598 minecraft:obsidian
fill 397 138 557 398 139 557 minecraft:purple_concrete
fill 397 138 558 399 138 558 minecraft:obsidian
fill 399 138 557 402 139 557 minecraft:purple_terracotta
fill 399 138 562 399 138 564 minecraft:purple_concrete
fill 399 138 598 401 138 598 minecraft:obsidian
fill 400 138 561 400 138 562 minecraft:purple_concrete
fill 400 138 565 400 142 565 minecraft:purple_concrete
fill 400 138 599 401 139 599 minecraft:purple_concrete
fill 401 138 558 403 138 558 minecraft:obsidian
fill 401 138 561 403 139 561 minecraft:purple_concrete
fill 401 138 566 401 139 566 minecraft:purple_concrete
fill 402 138 599 403 143 599 minecraft:purple_terracotta
fill 403 138 598 405 138 598 minecraft:obsidian
fill 404 138 557 404 143 557 minecraft:purple_terracotta
fill 404 138 564 406 138 566 minecraft:purple_concrete
fill 405 138 558 407 138 558 minecraft:obsidian
setblock 406 138 557 minecraft:purple_concrete
fill 407 138 557 408 143 557 minecraft:purple_terracotta
fill 407 138 566 407 140 567 minecraft:amethyst_block
fill 407 138 598 409 138 598 minecraft:obsidian
fill 409 138 557 409 139 557 minecraft:purple_concrete
fill 409 138 558 411 138 558 minecraft:obsidian
fill 411 138 598 413 138 598 minecraft:obsidian
fill 411 138 599 411 143 599 minecraft:purple_terracotta
fill 412 138 599 413 138 599 minecraft:purple_concrete
fill 413 138 558 415 138 558 minecraft:obsidian
fill 414 138 599 415 143 599 minecraft:purple_terracotta
fill 415 138 557 416 143 557 minecraft:purple_terracotta
fill 415 138 598 417 138 598 minecraft:obsidian
fill 417 138 557 418 138 557 minecraft:purple_concrete
fill 417 138 558 417 138 560 minecraft:obsidian
fill 417 138 562 417 138 564 minecraft:obsidian
fill 417 138 566 417 138 568 minecraft:obsidian
fill 417 138 570 417 138 572 minecraft:obsidian
fill 417 138 574 417 138 576 minecraft:obsidian
fill 417 138 578 417 138 580 minecraft:obsidian
fill 417 138 582 417 138 584 minecraft:obsidian
fill 417 138 586 417 138 588 minecraft:obsidian
fill 417 138 590 417 138 592 minecraft:obsidian
fill 417 138 594 417 138 596 minecraft:obsidian
fill 418 138 558 418 139 559 minecraft:purple_terracotta
fill 418 138 566 418 143 567 minecraft:purple_terracotta
fill 418 138 568 418 139 569 minecraft:purple_concrete
fill 418 138 575 418 143 575 minecraft:purple_terracotta
fill 418 138 576 418 138 577 minecraft:purple_concrete
fill 418 138 578 418 143 578 minecraft:purple_terracotta
fill 418 138 580 418 139 580 minecraft:purple_concrete
fill 418 138 586 418 143 587 minecraft:purple_terracotta
fill 418 138 588 418 139 589 minecraft:purple_concrete
setblock 418 138 597 minecraft:purple_concrete
fill 418 138 598 418 143 598 minecraft:purple_terracotta
setblock 376 139 559 minecraft:purple_concrete
fill 376 139 563 376 142 563 minecraft:purple_terracotta
fill 376 139 567 376 141 567 minecraft:purple_terracotta
setblock 376 139 568 minecraft:purple_concrete
setblock 376 139 579 minecraft:purple_concrete
setblock 376 139 583 minecraft:purple_concrete
fill 376 139 584 376 142 584 minecraft:purple_terracotta
fill 376 139 595 376 141 595 minecraft:purple_terracotta
setblock 377 139 599 minecraft:purple_concrete
setblock 380 139 599 minecraft:purple_concrete
fill 381 139 599 381 142 599 minecraft:purple_terracotta
fill 385 139 557 385 142 557 minecraft:purple_terracotta
setblock 386 139 557 minecraft:purple_concrete
setblock 388 139 599 minecraft:purple_concrete
fill 389 139 557 390 139 557 minecraft:purple_concrete
fill 392 139 599 392 142 599 minecraft:purple_terracotta
fill 398 139 561 400 139 561 minecraft:purple_concrete
fill 398 139 562 399 144 564 minecraft:black_concrete
setblock 399 139 565 minecraft:purple_concrete
fill 400 139 562 400 143 563 minecraft:black_concrete
setblock 400 139 564 minecraft:purple_concrete
fill 403 139 562 404 139 562 minecraft:purple_concrete
fill 404 139 564 404 139 566 minecraft:purple_concrete
fill 405 139 563 405 139 565 minecraft:purple_concrete
fill 406 139 557 406 142 557 minecraft:purple_terracotta
fill 408 139 599 409 139 599 minecraft:purple_concrete
setblock 410 139 557 minecraft:purple_concrete
setblock 412 139 599 minecraft:purple_concrete
fill 413 139 599 413 142 599 minecraft:purple_terracotta
fill 417 139 557 417 142 557 minecraft:purple_terracotta
setblock 418 139 557 minecraft:purple_concrete
setblock 418 139 560 minecraft:purple_concrete
fill 418 139 576 418 142 577 minecraft:purple_terracotta
setblock 418 139 581 minecraft:purple_concrete
setblock 418 139 592 minecraft:purple_concrete
fill 418 139 597 418 142 597 minecraft:purple_terracotta
fill 376 140 557 376 141 558 minecraft:purple_concrete
fill 376 140 559 376 145 560 minecraft:purple_terracotta
fill 376 140 568 376 141 568 minecraft:purple_terracotta
fill 376 140 569 376 140 570 minecraft:purple_concrete
fill 376 140 571 376 145 572 minecraft:purple_terracotta
fill 376 140 577 376 141 578 minecraft:purple_concrete
fill 376 140 579 376 145 580 minecraft:purple_terracotta
setblock 376 140 581 minecraft:purple_concrete
fill 376 140 583 376 142 583 minecraft:purple_terracotta
fill 376 140 589 376 141 590 minecraft:purple_concrete
fill 376 140 591 376 145 592 minecraft:purple_terracotta
setblock 376 140 597 minecraft:purple_terracotta
fill 376 140 598 376 141 598 minecraft:purple_concrete
fill 377 140 557 378 145 557 minecraft:purple_terracotta
fill 377 140 599 377 145 599 minecraft:purple_terracotta
fill 378 140 599 379 140 599 minecraft:purple_concrete
fill 379 140 557 380 141 557 minecraft:purple_concrete
setblock 379 140 560 minecraft:light[level=12]
setblock 379 140 568 minecraft:light[level=12]
setblock 379 140 576 minecraft:light[level=12]
setblock 379 140 584 minecraft:light[level=12]
setblock 379 140 592 minecraft:light[level=12]
fill 380 140 599 380 145 599 minecraft:purple_terracotta
fill 383 140 583 383 145 584 minecraft:obsidian
fill 386 140 557 386 145 557 minecraft:purple_terracotta
fill 386 140 599 387 141 599 minecraft:purple_concrete
setblock 387 140 560 minecraft:light[level=12]
setblock 387 140 568 minecraft:light[level=12]
setblock 387 140 576 minecraft:light[level=12]
setblock 387 140 584 minecraft:light[level=12]
setblock 387 140 592 minecraft:light[level=12]
setblock 388 140 557 minecraft:purple_concrete
fill 388 140 599 389 145 599 minecraft:purple_terracotta
fill 389 140 557 390 145 557 minecraft:purple_terracotta
fill 391 140 557 391 141 557 minecraft:purple_concrete
setblock 395 140 560 minecraft:light[level=12]
setblock 395 140 568 minecraft:light[level=12]
setblock 395 140 576 minecraft:light[level=12]
setblock 395 140 584 minecraft:light[level=12]
setblock 395 140 592 minecraft:light[level=12]
fill 396 140 562 397 142 563 minecraft:black_concrete
fill 397 140 557 398 145 557 minecraft:purple_terracotta
fill 397 140 561 400 143 561 minecraft:black_concrete
fill 397 140 564 397 145 564 minecraft:black_concrete
setblock 398 140 565 minecraft:purple_concrete
fill 398 140 599 399 140 599 minecraft:purple_concrete
fill 399 140 557 400 140 557 minecraft:purple_concrete
fill 399 140 565 399 142 565 minecraft:black_concrete
fill 400 140 564 400 143 564 minecraft:black_concrete
fill 400 140 599 401 145 599 minecraft:purple_terracotta
fill 401 140 557 402 141 557 minecraft:purple_terracotta
fill 401 140 561 402 140 561 minecraft:purple_concrete
fill 401 140 562 401 142 563 minecraft:black_concrete
setblock 401 140 564 minecraft:purple_concrete
fill 402 140 565 404 140 565 minecraft:purple_concrete
setblock 403 140 560 minecraft:light[level=12]
setblock 403 140 562 minecraft:purple_concrete
setblock 403 140 568 minecraft:light[level=12]
setblock 403 140 576 minecraft:light[level=12]
setblock 403 140 584 minecraft:light[level=12]
setblock 403 140 592 minecraft:light[level=12]
setblock 404 140 564 minecraft:purple_concrete
fill 407 140 599 407 141 599 minecraft:purple_concrete
fill 408 140 599 409 145 599 minecraft:purple_terracotta
fill 409 140 557 410 145 557 minecraft:purple_terracotta
setblock 410 140 599 minecraft:purple_concrete
fill 411 140 557 412 141 557 minecraft:purple_concrete
setblock 411 140 560 minecraft:light[level=12]
setblock 411 140 568 minecraft:light[level=12]
setblock 411 140 576 minecraft:light[level=12]
setblock 411 140 584 minecraft:light[level=12]
setblock 411 140 592 minecraft:light[level=12]
fill 412 140 599 412 145 599 minecraft:purple_terracotta
fill 418 140 557 418 145 557 minecraft:purple_terracotta
fill 418 140 558 418 140 559 minecraft:purple_concrete
fill 418 140 560 418 145 560 minecraft:purple_terracotta
fill 418 140 562 418 141 562 minecraft:purple_concrete
fill 418 140 568 418 145 569 minecraft:purple_terracotta
fill 418 140 570 418 141 571 minecraft:purple_concrete
setblock 418 140 579 minecraft:purple_concrete
fill 418 140 580 418 145 581 minecraft:purple_terracotta
fill 418 140 582 418 141 583 minecraft:purple_concrete
fill 418 140 588 418 145 589 minecraft:purple_terracotta
fill 418 140 590 418 140 591 minecraft:purple_concrete
fill 418 140 592 418 145 592 minecraft:purple_terracotta
fill 418 140 599 418 141 599 minecraft:purple_concrete
fill 376 141 565 376 141 566 minecraft:purple_concrete
setblock 376 141 569 minecraft:purple_concrete
fill 376 141 570 376 144 570 minecraft:purple_terracotta
fill 376 141 581 376 144 581 minecraft:purple_terracotta
fill 376 141 585 376 143 585 minecraft:purple_terracotta
setblock 376 141 586 minecraft:purple_concrete
setblock 376 141 597 minecraft:purple_concrete
fill 378 141 599 379 144 599 minecraft:purple_terracotta
fill 381 141 583 381 145 584 minecraft:obsidian
fill 382 141 582 382 145 582 minecraft:obsidian
fill 382 141 585 382 145 585 minecraft:obsidian
fill 388 141 557 388 144 557 minecraft:purple_terracotta
setblock 392 141 557 minecraft:purple_concrete
fill 395 141 562 395 142 564 minecraft:black_concrete
setblock 395 141 599 minecraft:purple_concrete
fill 396 141 561 396 144 561 minecraft:black_concrete
fill 396 141 564 396 143 564 minecraft:black_concrete
fill 397 141 565 398 143 565 minecraft:black_concrete
fill 398 141 560 399 142 560 minecraft:black_concrete
setblock 398 141 599 minecraft:purple_concrete
fill 399 141 557 399 144 557 minecraft:purple_terracotta
fill 399 141 599 399 144 599 minecraft:purple_terracotta
setblock 400 141 557 minecraft:purple_concrete
fill 401 141 561 401 142 561 minecraft:purple_concrete
setblock 401 141 564 minecraft:black_concrete
setblock 402 141 565 minecraft:purple_concrete
setblock 403 141 557 minecraft:purple_concrete
setblock 403 141 563 minecraft:purple_concrete
setblock 406 141 599 minecraft:purple_concrete
fill 410 141 599 410 144 599 minecraft:purple_terracotta
fill 418 141 558 418 144 559 minecraft:purple_terracotta
setblock 418 141 563 minecraft:purple_concrete
setblock 418 141 574 minecraft:purple_concrete
fill 418 141 579 418 144 579 minecraft:purple_terracotta
fill 418 141 590 418 144 590 minecraft:purple_terracotta
setblock 418 141 591 minecraft:purple_concrete
fill 418 141 594 418 141 595 minecraft:purple_concrete
fill 376 142 557 376 147 558 minecraft:purple_terracotta
fill 376 142 564 376 143 564 minecraft:purple_concrete
fill 376 142 565 376 143 566 minecraft:purple_terracotta
fill 376 142 567 376 142 568 minecraft:purple_concrete
fill 376 142 569 376 147 569 minecraft:purple_terracotta
fill 376 142 575 376 143 576 minecraft:purple_concrete
fill 376 142 577 376 147 578 minecraft:purple_terracotta
fill 376 142 586 376 143 586 minecraft:purple_terracotta
fill 376 142 587 376 142 588 minecraft:purple_concrete
fill 376 142 589 376 147 590 minecraft:purple_terracotta
fill 376 142 595 376 143 596 minecraft:purple_concrete
fill 376 142 597 376 147 598 minecraft:purple_terracotta
setblock 376 142 599 minecraft:purple_concrete
fill 379 142 557 380 147 557 minecraft:purple_terracotta
fill 381 142 557 382 142 557 minecraft:purple_concrete
fill 381 142 582 381 145 582 minecraft:obsidian
fill 381 142 585 381 145 585 minecraft:obsidian
fill 383 142 582 383 145 582 minecraft:obsidian
fill 383 142 585 383 145 585 minecraft:obsidian
fill 384 142 583 384 145 584 minecraft:obsidian
fill 384 142 599 385 143 599 minecraft:purple_concrete
fill 386 142 599 387 147 599 minecraft:purple_terracotta
fill 391 142 557 392 147 557 minecraft:purple_terracotta
fill 393 142 557 394 143 557 minecraft:purple_concrete
fill 393 142 599 393 143 599 minecraft:purple_concrete
fill 394 142 562 394 142 564 minecraft:black_concrete
fill 395 142 561 395 143 561 minecraft:black_concrete
fill 395 142 599 395 147 599 minecraft:purple_terracotta
fill 396 142 565 396 145 565 minecraft:black_concrete
fill 396 142 599 397 142 599 minecraft:purple_concrete
fill 397 142 560 397 143 560 minecraft:black_concrete
fill 398 142 599 398 147 599 minecraft:purple_terracotta
fill 400 142 557 400 147 557 minecraft:purple_terracotta
fill 401 142 557 402 142 557 minecraft:purple_concrete
setblock 401 142 564 minecraft:purple_concrete
setblock 402 142 563 minecraft:purple_concrete
fill 403 142 557 403 147 557 minecraft:purple_terracotta
fill 404 142 599 405 143 599 minecraft:purple_concrete
fill 405 142 557 405 143 557 minecraft:purple_concrete
fill 406 142 599 407 147 599 minecraft:purple_terracotta
fill 411 142 557 412 147 557 minecraft:purple_terracotta
fill 413 142 557 414 143 557 minecraft:purple_concrete
fill 416 142 599 417 142 599 minecraft:purple_concrete
setblock 418 142 561 minecraft:purple_concrete
fill 418 142 562 418 147 563 minecraft:purple_terracotta
fill 418 142 564 418 143 565 minecraft:purple_concrete
fill 418 142 570 418 147 571 minecraft:purple_terracotta
fill 418 142 572 418 142 573 minecraft:purple_concrete
fill 418 142 574 418 147 574 minecraft:purple_terracotta
fill 418 142 582 418 147 583 minecraft:purple_terracotta
fill 418 142 584 418 143 585 minecraft:purple_concrete
fill 418 142 591 418 147 591 minecraft:purple_terracotta
setblock 418 142 593 minecraft:purple_concrete
fill 418 142 594 418 147 595 minecraft:purple_terracotta
fill 418 142 596 418 143 596 minecraft:purple_concrete
fill 418 142 599 418 147 599 minecraft:purple_terracotta
setblock 376 143 563 minecraft:purple_concrete
fill 376 143 567 376 145 568 minecraft:purple_terracotta
fill 376 143 583 376 143 584 minecraft:purple_concrete
setblock 376 143 587 minecraft:purple_concrete
fill 376 143 588 376 146 588 minecraft:purple_terracotta
fill 376 143 599 376 146 599 minecraft:purple_terracotta
fill 380 143 583 380 145 584 minecraft:obsidian
fill 381 143 557 381 146 557 minecraft:purple_terracotta
setblock 381 143 599 minecraft:purple_concrete
setblock 382 143 557 minecraft:purple_concrete
fill 384 143 582 384 145 582 minecraft:obsidian
setblock 385 143 557 minecraft:purple_concrete
fill 392 143 563 396 146 563 minecraft:purple_concrete
setblock 392 143 599 minecraft:purple_concrete
fill 393 143 561 394 147 562 minecraft:purple_concrete
fill 393 143 564 395 147 564 minecraft:purple_concrete
fill 394 143 565 395 143 565 minecraft:black_concrete
fill 395 143 562 395 147 562 minecraft:purple_concrete
fill 396 143 560 396 144 560 minecraft:black_concrete
fill 396 143 562 397 143 562 minecraft:black_concrete
fill 396 143 599 397 146 599 minecraft:purple_terracotta
fill 397 143 563 397 146 563 minecraft:black_concrete
fill 401 143 557 402 146 557 minecraft:purple_terracotta
setblock 406 143 557 minecraft:purple_concrete
setblock 413 143 599 minecraft:purple_concrete
setblock 416 143 599 minecraft:purple_concrete
setblock 417 143 557 minecraft:purple_concrete
fill 417 143 599 417 146 599 minecraft:purple_terracotta
fill 418 143 561 418 146 561 minecraft:purple_terracotta
fill 418 143 572 418 146 572 minecraft:purple_terracotta
setblock 418 143 573 minecraft:purple_concrete
fill 418 143 576 418 143 577 minecraft:purple_concrete
fill 418 143 593 418 146 593 minecraft:purple_terracotta
setblock 418 143 597 minecraft:purple_concrete
fill 376 144 561 376 145 562 minecraft:purple_concrete
fill 376 144 563 376 149 564 minecraft:purple_terracotta
setblock 376 144 565 minecraft:purple_concrete
fill 376 144 566 376 147 566 minecraft:purple_terracotta
fill 376 144 573 376 145 574 minecraft:purple_concrete
fill 376 144 575 376 149 576 minecraft:purple_terracotta
fill 376 144 582 376 145 582 minecraft:purple_concrete
fill 376 144 583 376 145 584 minecraft:purple_terracotta
fill 376 144 585 376 144 586 minecraft:purple_concrete
fill 376 144 587 376 149 587 minecraft:purple_terracotta
fill 376 144 593 376 145 594 minecraft:purple_concrete
fill 376 144 595 376 149 596 minecraft:purple_terracotta
fill 377 144 558 379 144 558 minecraft:obsidian
fill 377 144 560 377 144 562 minecraft:obsidian
fill 377 144 564 377 144 566 minecraft:obsidian
fill 377 144 568 377 144 570 minecraft:obsidian
fill 377 144 572 377 144 574 minecraft:obsidian
fill 377 144 576 377 144 578 minecraft:obsidian
fill 377 144 580 377 144 582 minecraft:obsidian
fill 377 144 584 377 144 586 minecraft:obsidian
fill 377 144 588 377 144 590 minecraft:obsidian
fill 377 144 592 377 144 594 minecraft:obsidian
fill 377 144 596 377 144 598 minecraft:obsidian
fill 379 144 598 381 144 598 minecraft:obsidian
fill 380 144 582 380 145 582 minecraft:obsidian
fill 380 144 585 380 145 585 minecraft:obsidian
fill 381 144 558 383 144 558 minecraft:obsidian
fill 381 144 581 383 145 581 minecraft:obsidian
fill 381 144 586 383 145 586 minecraft:obsidian
fill 381 144 599 381 149 599 minecraft:purple_terracotta
fill 382 144 557 382 149 557 minecraft:purple_terracotta
fill 382 144 599 383 144 599 minecraft:purple_concrete
fill 383 144 557 384 144 557 minecraft:purple_concrete
fill 383 144 598 385 144 598 minecraft:obsidian
fill 384 144 585 384 145 585 minecraft:obsidian
fill 384 144 599 385 149 599 minecraft:purple_terracotta
fill 385 144 557 385 149 557 minecraft:purple_terracotta
schedule function dropper:buildpart/140_2 1t
