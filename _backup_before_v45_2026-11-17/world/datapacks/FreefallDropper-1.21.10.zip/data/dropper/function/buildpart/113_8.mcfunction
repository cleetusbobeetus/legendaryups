setblock 249 243 465 minecraft:bone_block
setblock 249 243 466 minecraft:brown_terracotta
fill 249 243 502 251 243 502 minecraft:brown_terracotta
setblock 250 243 464 minecraft:bone_block
fill 250 243 465 250 245 465 minecraft:brown_terracotta
setblock 250 243 504 minecraft:bone_block
fill 251 243 464 254 243 464 minecraft:brown_terracotta
setblock 251 243 503 minecraft:bone_block
fill 251 243 504 251 246 504 minecraft:brown_terracotta
setblock 252 243 502 minecraft:bone_block
fill 252 243 503 252 246 503 minecraft:brown_terracotta
setblock 254 243 466 minecraft:light[level=12]
setblock 254 243 474 minecraft:light[level=12]
setblock 254 243 482 minecraft:light[level=12]
setblock 254 243 490 minecraft:light[level=12]
setblock 254 243 498 minecraft:light[level=12]
setblock 255 243 464 minecraft:bone_block
setblock 255 243 503 minecraft:brown_terracotta
setblock 255 243 504 minecraft:bone_block
fill 256 243 504 256 246 504 minecraft:brown_terracotta
setblock 260 243 504 minecraft:bone_block
fill 261 243 504 264 243 504 minecraft:brown_terracotta
setblock 262 243 466 minecraft:light[level=12]
setblock 262 243 474 minecraft:light[level=12]
setblock 262 243 482 minecraft:light[level=12]
setblock 262 243 485 minecraft:bone_block
setblock 262 243 490 minecraft:light[level=12]
setblock 262 243 498 minecraft:light[level=12]
fill 263 243 503 265 243 503 minecraft:brown_terracotta
fill 264 243 483 266 243 483 minecraft:bone_block
fill 264 243 489 266 243 489 minecraft:bone_block
fill 265 243 502 266 243 502 minecraft:brown_terracotta
setblock 265 243 504 minecraft:bone_block
setblock 266 243 503 minecraft:bone_block
fill 266 243 504 269 243 504 minecraft:brown_terracotta
setblock 267 243 485 minecraft:bone_block
setblock 267 243 487 minecraft:bone_block
setblock 267 243 502 minecraft:bone_block
fill 267 243 503 267 246 503 minecraft:brown_terracotta
fill 268 243 502 268 246 502 minecraft:brown_terracotta
setblock 270 243 466 minecraft:light[level=12]
setblock 270 243 474 minecraft:light[level=12]
setblock 270 243 482 minecraft:light[level=12]
setblock 270 243 490 minecraft:light[level=12]
setblock 270 243 498 minecraft:light[level=12]
setblock 270 243 504 minecraft:bone_block
setblock 271 243 503 minecraft:bone_block
fill 271 243 504 271 246 504 minecraft:brown_terracotta
fill 272 243 503 272 244 503 minecraft:brown_terracotta
setblock 273 243 496 minecraft:bone_block
setblock 273 243 497 minecraft:brown_terracotta
setblock 274 243 495 minecraft:bone_block
fill 274 243 496 274 244 496 minecraft:brown_terracotta
setblock 275 243 473 minecraft:brown_terracotta
setblock 275 243 474 minecraft:bone_block
fill 275 243 475 275 244 475 minecraft:brown_terracotta
fill 275 243 477 275 243 478 minecraft:brown_terracotta
setblock 275 243 479 minecraft:bone_block
fill 275 243 480 275 244 481 minecraft:brown_terracotta
setblock 275 243 489 minecraft:bone_block
setblock 275 243 490 minecraft:brown_terracotta
setblock 275 243 494 minecraft:bone_block
fill 275 243 495 275 244 495 minecraft:brown_terracotta
setblock 275 243 499 minecraft:bone_block
setblock 275 243 500 minecraft:brown_terracotta
setblock 276 243 473 minecraft:bone_block
fill 276 243 474 276 246 474 minecraft:brown_terracotta
setblock 276 243 477 minecraft:brown_terracotta
setblock 276 243 478 minecraft:bone_block
fill 276 243 479 276 246 479 minecraft:brown_terracotta
fill 276 243 481 276 243 482 minecraft:brown_terracotta
setblock 276 243 483 minecraft:bone_block
fill 276 243 484 276 245 484 minecraft:brown_terracotta
setblock 276 243 488 minecraft:bone_block
fill 276 243 489 276 244 489 minecraft:brown_terracotta
setblock 276 243 493 minecraft:bone_block
fill 276 243 494 276 245 494 minecraft:brown_terracotta
setblock 276 243 498 minecraft:bone_block
fill 276 243 499 276 246 499 minecraft:brown_terracotta
fill 236 244 470 236 244 471 minecraft:brown_terracotta
setblock 236 244 472 minecraft:bone_block
fill 236 244 473 236 244 476 minecraft:brown_terracotta
setblock 236 244 477 minecraft:bone_block
fill 236 244 478 236 244 481 minecraft:brown_terracotta
setblock 236 244 482 minecraft:bone_block
setblock 236 244 483 minecraft:brown_terracotta
setblock 236 244 497 minecraft:bone_block
setblock 237 244 472 minecraft:brown_terracotta
setblock 237 244 476 minecraft:bone_block
fill 237 244 477 237 247 477 minecraft:brown_terracotta
setblock 243 244 464 minecraft:brown_terracotta
setblock 244 244 464 minecraft:bone_block
fill 244 244 468 244 245 468 minecraft:bone_block
setblock 244 244 504 minecraft:bone_block
fill 245 244 464 247 244 465 minecraft:brown_terracotta
fill 245 244 504 248 244 504 minecraft:brown_terracotta
fill 246 244 503 246 247 503 minecraft:brown_terracotta
setblock 248 244 464 minecraft:brown_terracotta
setblock 248 244 465 minecraft:bone_block
setblock 249 244 464 minecraft:bone_block
fill 249 244 465 249 247 465 minecraft:brown_terracotta
fill 249 244 502 250 244 502 minecraft:brown_terracotta
setblock 249 244 504 minecraft:bone_block
fill 250 244 464 253 244 464 minecraft:brown_terracotta
setblock 250 244 503 minecraft:bone_block
fill 250 244 504 250 247 504 minecraft:brown_terracotta
setblock 251 244 502 minecraft:bone_block
fill 251 244 503 251 247 503 minecraft:brown_terracotta
setblock 254 244 464 minecraft:bone_block
setblock 254 244 504 minecraft:bone_block
setblock 255 244 503 minecraft:bone_block
fill 255 244 504 255 247 504 minecraft:brown_terracotta
setblock 259 244 504 minecraft:bone_block
fill 260 244 504 263 244 504 minecraft:brown_terracotta
fill 262 244 503 264 244 503 minecraft:brown_terracotta
fill 263 244 485 265 244 487 minecraft:bone_block
setblock 264 244 504 minecraft:bone_block
setblock 265 244 502 minecraft:brown_terracotta
setblock 265 244 503 minecraft:bone_block
fill 265 244 504 268 244 504 minecraft:brown_terracotta
fill 266 244 486 266 244 487 minecraft:bone_block
setblock 266 244 502 minecraft:bone_block
fill 266 244 503 266 247 503 minecraft:brown_terracotta
fill 267 244 502 267 247 502 minecraft:brown_terracotta
setblock 269 244 504 minecraft:bone_block
setblock 270 244 503 minecraft:bone_block
fill 270 244 504 270 247 504 minecraft:brown_terracotta
fill 271 244 503 271 245 503 minecraft:brown_terracotta
setblock 274 244 495 minecraft:brown_terracotta
setblock 275 244 474 minecraft:brown_terracotta
setblock 275 244 477 minecraft:brown_terracotta
setblock 275 244 478 minecraft:bone_block
fill 275 244 479 275 247 479 minecraft:brown_terracotta
setblock 275 244 493 minecraft:bone_block
setblock 275 244 494 minecraft:brown_terracotta
setblock 275 244 498 minecraft:bone_block
setblock 275 244 499 minecraft:brown_terracotta
setblock 276 244 472 minecraft:bone_block
fill 276 244 473 276 245 473 minecraft:brown_terracotta
setblock 276 244 477 minecraft:bone_block
fill 276 244 478 276 247 478 minecraft:brown_terracotta
setblock 276 244 481 minecraft:brown_terracotta
setblock 276 244 482 minecraft:bone_block
fill 276 244 483 276 247 483 minecraft:brown_terracotta
setblock 276 244 488 minecraft:brown_terracotta
setblock 276 244 492 minecraft:bone_block
fill 276 244 493 276 245 493 minecraft:brown_terracotta
setblock 276 244 497 minecraft:bone_block
fill 276 244 498 276 246 498 minecraft:brown_terracotta
setblock 236 245 471 minecraft:bone_block
fill 236 245 472 236 245 475 minecraft:brown_terracotta
setblock 236 245 476 minecraft:bone_block
fill 236 245 477 236 245 480 minecraft:brown_terracotta
setblock 236 245 481 minecraft:bone_block
fill 236 245 482 236 248 482 minecraft:brown_terracotta
setblock 237 245 475 minecraft:bone_block
fill 237 245 476 237 247 476 minecraft:brown_terracotta
setblock 243 245 464 minecraft:bone_block
fill 244 245 464 247 245 464 minecraft:brown_terracotta
fill 244 245 504 247 245 504 minecraft:brown_terracotta
fill 245 245 468 246 246 468 minecraft:bone_block
fill 245 245 503 245 248 503 minecraft:brown_terracotta
setblock 246 245 465 minecraft:brown_terracotta
setblock 247 245 465 minecraft:bone_block
setblock 248 245 464 minecraft:bone_block
fill 248 245 465 248 248 465 minecraft:brown_terracotta
fill 248 245 502 249 245 502 minecraft:brown_terracotta
setblock 248 245 504 minecraft:bone_block
fill 249 245 464 252 245 464 minecraft:brown_terracotta
setblock 249 245 503 minecraft:bone_block
fill 249 245 504 249 248 504 minecraft:brown_terracotta
setblock 250 245 502 minecraft:bone_block
fill 250 245 503 250 248 503 minecraft:brown_terracotta
setblock 251 245 502 minecraft:brown_terracotta
setblock 253 245 464 minecraft:bone_block
setblock 253 245 504 minecraft:bone_block
setblock 254 245 503 minecraft:bone_block
fill 254 245 504 254 248 504 minecraft:brown_terracotta
setblock 258 245 504 minecraft:bone_block
fill 259 245 504 262 245 504 minecraft:brown_terracotta
fill 262 245 503 263 245 503 minecraft:brown_terracotta
setblock 263 245 504 minecraft:bone_block
setblock 264 245 502 minecraft:brown_terracotta
setblock 264 245 503 minecraft:bone_block
fill 264 245 504 267 245 504 minecraft:brown_terracotta
setblock 265 245 502 minecraft:bone_block
fill 265 245 503 265 248 503 minecraft:brown_terracotta
fill 266 245 502 266 248 502 minecraft:brown_terracotta
setblock 268 245 504 minecraft:bone_block
setblock 269 245 503 minecraft:bone_block
fill 269 245 504 269 248 504 minecraft:brown_terracotta
fill 270 245 503 270 248 503 minecraft:brown_terracotta
setblock 275 245 476 minecraft:brown_terracotta
setblock 275 245 477 minecraft:bone_block
fill 275 245 478 275 247 478 minecraft:brown_terracotta
fill 275 245 480 275 246 480 minecraft:brown_terracotta
setblock 275 245 497 minecraft:bone_block
setblock 276 245 476 minecraft:bone_block
fill 276 245 477 276 248 477 minecraft:brown_terracotta
setblock 276 245 481 minecraft:bone_block
fill 276 245 482 276 248 482 minecraft:brown_terracotta
setblock 276 245 492 minecraft:brown_terracotta
setblock 276 245 496 minecraft:bone_block
fill 276 245 497 276 246 497 minecraft:brown_terracotta
fill 236 246 472 236 246 474 minecraft:brown_terracotta
setblock 236 246 475 minecraft:bone_block
fill 236 246 476 236 246 479 minecraft:brown_terracotta
setblock 236 246 480 minecraft:bone_block
fill 236 246 481 236 249 481 minecraft:brown_terracotta
setblock 237 246 475 minecraft:brown_terracotta
setblock 237 246 479 minecraft:bone_block
fill 243 246 464 246 246 464 minecraft:brown_terracotta
fill 243 246 504 246 246 504 minecraft:brown_terracotta
setblock 245 246 465 minecraft:brown_terracotta
setblock 246 246 465 minecraft:bone_block
fill 246 246 467 248 247 467 minecraft:bone_block
fill 246 246 469 248 247 469 minecraft:bone_block
setblock 247 246 464 minecraft:bone_block
fill 247 246 465 247 249 465 minecraft:brown_terracotta
fill 247 246 468 247 247 468 minecraft:bone_block
fill 247 246 502 248 246 502 minecraft:brown_terracotta
setblock 247 246 504 minecraft:bone_block
fill 248 246 464 251 246 464 minecraft:brown_terracotta
setblock 248 246 503 minecraft:bone_block
fill 248 246 504 248 249 504 minecraft:brown_terracotta
setblock 249 246 502 minecraft:bone_block
fill 249 246 503 249 249 503 minecraft:brown_terracotta
fill 250 246 502 250 249 502 minecraft:brown_terracotta
setblock 252 246 464 minecraft:bone_block
setblock 252 246 504 minecraft:bone_block
setblock 253 246 464 minecraft:brown_terracotta
setblock 253 246 503 minecraft:bone_block
fill 253 246 504 253 249 504 minecraft:brown_terracotta
fill 254 246 503 254 249 503 minecraft:brown_terracotta
setblock 257 246 504 minecraft:bone_block
fill 258 246 504 261 246 504 minecraft:brown_terracotta
fill 261 246 503 262 246 503 minecraft:brown_terracotta
setblock 262 246 504 minecraft:bone_block
setblock 263 246 503 minecraft:bone_block
fill 263 246 504 266 246 504 minecraft:brown_terracotta
setblock 264 246 502 minecraft:bone_block
fill 264 246 503 264 249 503 minecraft:brown_terracotta
fill 265 246 502 265 249 502 minecraft:brown_terracotta
setblock 267 246 504 minecraft:bone_block
setblock 268 246 503 minecraft:bone_block
fill 268 246 504 268 249 504 minecraft:brown_terracotta
setblock 269 246 502 minecraft:bone_block
fill 269 246 503 269 249 503 minecraft:brown_terracotta
setblock 272 246 504 minecraft:bone_block
setblock 275 246 477 minecraft:brown_terracotta
setblock 276 246 475 minecraft:bone_block
fill 276 246 476 276 249 476 minecraft:brown_terracotta
setblock 276 246 480 minecraft:bone_block
fill 276 246 481 276 249 481 minecraft:brown_terracotta
setblock 276 246 496 minecraft:brown_terracotta
setblock 236 247 473 minecraft:brown_terracotta
setblock 236 247 474 minecraft:bone_block
fill 236 247 475 236 247 478 minecraft:brown_terracotta
setblock 236 247 479 minecraft:bone_block
fill 236 247 480 236 250 480 minecraft:brown_terracotta
setblock 237 247 478 minecraft:bone_block
fill 242 247 464 245 247 464 minecraft:brown_terracotta
fill 242 247 504 245 247 504 minecraft:brown_terracotta
fill 244 247 503 244 249 503 minecraft:brown_terracotta
setblock 245 247 465 minecraft:bone_block
setblock 246 247 464 minecraft:bone_block
fill 246 247 465 246 250 465 minecraft:brown_terracotta
fill 246 247 502 247 247 502 minecraft:brown_terracotta
setblock 246 247 504 minecraft:bone_block
fill 247 247 464 250 247 464 minecraft:brown_terracotta
setblock 247 247 503 minecraft:bone_block
fill 247 247 504 247 250 504 minecraft:brown_terracotta
setblock 248 247 502 minecraft:bone_block
fill 248 247 503 248 250 503 minecraft:brown_terracotta
fill 249 247 502 249 250 502 minecraft:brown_terracotta
setblock 251 247 464 minecraft:bone_block
setblock 251 247 504 minecraft:bone_block
fill 252 247 464 252 250 464 minecraft:brown_terracotta
setblock 252 247 503 minecraft:bone_block
fill 252 247 504 252 250 504 minecraft:brown_terracotta
fill 253 247 503 253 250 503 minecraft:brown_terracotta
setblock 256 247 504 minecraft:bone_block
fill 257 247 504 260 247 504 minecraft:brown_terracotta
fill 260 247 503 261 247 503 minecraft:brown_terracotta
setblock 261 247 504 minecraft:bone_block
setblock 262 247 503 minecraft:bone_block
fill 262 247 504 265 247 504 minecraft:brown_terracotta
setblock 263 247 502 minecraft:bone_block
fill 263 247 503 263 250 503 minecraft:brown_terracotta
fill 264 247 502 264 250 502 minecraft:brown_terracotta
setblock 266 247 504 minecraft:bone_block
setblock 267 247 503 minecraft:bone_block
fill 267 247 504 267 250 504 minecraft:brown_terracotta
setblock 268 247 502 minecraft:bone_block
fill 268 247 503 268 250 503 minecraft:brown_terracotta
setblock 271 247 504 minecraft:bone_block
fill 272 247 484 272 248 484 minecraft:bone_block
setblock 275 247 480 minecraft:bone_block
fill 276 247 475 276 248 475 minecraft:brown_terracotta
setblock 276 247 479 minecraft:bone_block
fill 276 247 480 276 250 480 minecraft:brown_terracotta
fill 236 248 474 236 248 477 minecraft:brown_terracotta
setblock 236 248 478 minecraft:bone_block
fill 236 248 479 236 251 479 minecraft:brown_terracotta
fill 237 248 478 237 251 478 minecraft:brown_terracotta
fill 238 248 499 238 252 499 minecraft:bone_block
fill 239 248 498 239 252 498 minecraft:bone_block
fill 239 248 500 239 252 500 minecraft:bone_block
fill 240 248 499 240 252 499 minecraft:bone_block
fill 241 248 464 244 248 464 minecraft:brown_terracotta
fill 241 248 504 244 248 504 minecraft:brown_terracotta
fill 243 248 503 243 250 503 minecraft:brown_terracotta
setblock 244 248 465 minecraft:bone_block
setblock 245 248 464 minecraft:bone_block
fill 245 248 465 245 251 465 minecraft:brown_terracotta
fill 245 248 502 246 248 502 minecraft:brown_terracotta
setblock 245 248 504 minecraft:bone_block
fill 246 248 464 249 248 464 minecraft:brown_terracotta
setblock 246 248 503 minecraft:bone_block
fill 246 248 504 246 251 504 minecraft:brown_terracotta
setblock 247 248 502 minecraft:bone_block
fill 247 248 503 247 251 503 minecraft:brown_terracotta
fill 248 248 502 248 251 502 minecraft:brown_terracotta
setblock 249 248 465 minecraft:bone_block
setblock 250 248 464 minecraft:bone_block
setblock 250 248 504 minecraft:bone_block
fill 251 248 464 251 251 464 minecraft:brown_terracotta
setblock 251 248 503 minecraft:bone_block
fill 251 248 504 251 251 504 minecraft:brown_terracotta
fill 252 248 503 252 251 503 minecraft:brown_terracotta
setblock 255 248 504 minecraft:bone_block
fill 256 248 504 259 248 504 minecraft:brown_terracotta
fill 259 248 503 260 248 503 minecraft:brown_terracotta
setblock 260 248 504 minecraft:bone_block
setblock 261 248 503 minecraft:bone_block
fill 261 248 504 264 248 504 minecraft:brown_terracotta
setblock 262 248 502 minecraft:bone_block
fill 262 248 503 262 251 503 minecraft:brown_terracotta
fill 263 248 502 263 251 502 minecraft:brown_terracotta
setblock 265 248 504 minecraft:bone_block
setblock 266 248 503 minecraft:bone_block
fill 266 248 504 266 251 504 minecraft:brown_terracotta
setblock 267 248 502 minecraft:bone_block
fill 267 248 503 267 251 503 minecraft:brown_terracotta
fill 268 248 502 268 251 502 minecraft:brown_terracotta
setblock 270 248 504 minecraft:bone_block
fill 271 248 504 271 251 504 minecraft:brown_terracotta
setblock 275 248 479 minecraft:bone_block
fill 275 248 480 275 251 480 minecraft:brown_terracotta
setblock 276 248 478 minecraft:bone_block
fill 276 248 479 276 251 479 minecraft:brown_terracotta
setblock 276 248 483 minecraft:bone_block
fill 276 248 484 276 251 484 minecraft:brown_terracotta
fill 236 249 474 236 249 476 minecraft:brown_terracotta
setblock 236 249 477 minecraft:bone_block
fill 236 249 478 236 252 478 minecraft:brown_terracotta
setblock 236 249 482 minecraft:bone_block
fill 236 249 483 236 252 483 minecraft:brown_terracotta
fill 237 249 479 237 250 479 minecraft:brown_terracotta
fill 240 249 464 243 249 464 minecraft:brown_terracotta
fill 240 249 504 243 249 504 minecraft:brown_terracotta
fill 242 249 503 242 251 503 minecraft:brown_terracotta
setblock 243 249 465 minecraft:bone_block
setblock 244 249 464 minecraft:bone_block
fill 244 249 465 244 252 465 minecraft:brown_terracotta
fill 244 249 502 245 249 502 minecraft:brown_terracotta
setblock 244 249 504 minecraft:bone_block
fill 245 249 464 248 249 464 minecraft:brown_terracotta
setblock 245 249 503 minecraft:bone_block
fill 245 249 504 245 252 504 minecraft:brown_terracotta
setblock 246 249 502 minecraft:bone_block
fill 246 249 503 246 252 503 minecraft:brown_terracotta
fill 247 249 502 247 252 502 minecraft:brown_terracotta
setblock 248 249 465 minecraft:bone_block
setblock 249 249 464 minecraft:bone_block
fill 249 249 465 249 252 465 minecraft:brown_terracotta
setblock 249 249 504 minecraft:bone_block
fill 250 249 464 250 252 464 minecraft:brown_terracotta
setblock 250 249 503 minecraft:bone_block
fill 250 249 504 250 252 504 minecraft:brown_terracotta
fill 251 249 503 251 252 503 minecraft:brown_terracotta
setblock 254 249 504 minecraft:bone_block
setblock 255 249 503 minecraft:bone_block
fill 255 249 504 258 249 504 minecraft:brown_terracotta
fill 256 249 497 260 250 501 minecraft:soul_soil
fill 256 249 503 259 249 503 minecraft:brown_terracotta
setblock 258 249 502 minecraft:soul_soil
setblock 259 249 504 minecraft:bone_block
setblock 260 249 503 minecraft:bone_block
fill 260 249 504 263 249 504 minecraft:brown_terracotta
setblock 261 249 502 minecraft:bone_block
fill 261 249 503 261 252 503 minecraft:brown_terracotta
fill 262 249 502 262 252 502 minecraft:brown_terracotta
setblock 264 249 504 minecraft:bone_block
fill 265 249 464 265 252 464 minecraft:brown_terracotta
setblock 265 249 503 minecraft:bone_block
fill 265 249 504 265 252 504 minecraft:brown_terracotta
setblock 266 249 502 minecraft:bone_block
fill 266 249 503 266 252 503 minecraft:brown_terracotta
fill 267 249 502 267 252 502 minecraft:brown_terracotta
setblock 269 249 504 minecraft:bone_block
setblock 270 249 503 minecraft:bone_block
fill 270 249 504 270 252 504 minecraft:brown_terracotta
fill 275 249 479 275 252 479 minecraft:brown_terracotta
fill 275 249 481 275 250 481 minecraft:brown_terracotta
setblock 276 249 477 minecraft:bone_block
fill 276 249 478 276 252 478 minecraft:brown_terracotta
setblock 276 249 482 minecraft:bone_block
fill 276 249 483 276 252 483 minecraft:brown_terracotta
fill 236 250 474 236 250 475 minecraft:brown_terracotta
setblock 236 250 476 minecraft:bone_block
fill 236 250 477 236 253 477 minecraft:brown_terracotta
setblock 236 250 481 minecraft:bone_block
fill 236 250 482 236 253 482 minecraft:brown_terracotta
setblock 237 250 480 minecraft:bone_block
setblock 238 250 464 minecraft:bone_block
fill 238 250 498 238 252 498 minecraft:bone_block
fill 238 250 500 238 252 500 minecraft:bone_block
fill 239 250 464 242 250 464 minecraft:brown_terracotta
fill 239 250 504 242 250 504 minecraft:brown_terracotta
fill 240 250 498 240 252 498 minecraft:bone_block
fill 240 250 500 240 252 500 minecraft:bone_block
setblock 241 250 465 minecraft:brown_terracotta
fill 241 250 503 241 252 503 minecraft:brown_terracotta
setblock 242 250 465 minecraft:bone_block
setblock 243 250 464 minecraft:bone_block
fill 243 250 465 243 253 465 minecraft:brown_terracotta
fill 243 250 502 244 250 502 minecraft:brown_terracotta
setblock 243 250 504 minecraft:bone_block
fill 244 250 464 247 250 464 minecraft:brown_terracotta
setblock 244 250 503 minecraft:bone_block
fill 244 250 504 244 253 504 minecraft:brown_terracotta
setblock 245 250 502 minecraft:bone_block
fill 245 250 503 245 253 503 minecraft:brown_terracotta
fill 246 250 502 246 253 502 minecraft:brown_terracotta
setblock 247 250 465 minecraft:bone_block
setblock 248 250 464 minecraft:bone_block
fill 248 250 465 248 253 465 minecraft:brown_terracotta
setblock 248 250 504 minecraft:bone_block
fill 249 250 464 249 253 464 minecraft:brown_terracotta
setblock 249 250 503 minecraft:bone_block
fill 249 250 504 249 253 504 minecraft:brown_terracotta
setblock 250 250 502 minecraft:bone_block
fill 250 250 503 250 253 503 minecraft:brown_terracotta
fill 251 250 502 251 253 502 minecraft:brown_terracotta
setblock 253 250 464 minecraft:bone_block
setblock 253 250 504 minecraft:bone_block
setblock 254 250 503 minecraft:bone_block
fill 254 250 504 257 250 504 minecraft:brown_terracotta
fill 255 250 503 258 250 503 minecraft:brown_terracotta
setblock 258 250 504 minecraft:bone_block
setblock 259 250 503 minecraft:bone_block
fill 259 250 504 262 250 504 minecraft:brown_terracotta
setblock 260 250 502 minecraft:bone_block
fill 260 250 503 260 253 503 minecraft:brown_terracotta
fill 261 250 502 261 253 502 minecraft:brown_terracotta
setblock 262 250 464 minecraft:brown_terracotta
setblock 263 250 464 minecraft:bone_block
setblock 263 250 504 minecraft:bone_block
fill 264 250 464 264 253 464 minecraft:brown_terracotta
setblock 264 250 503 minecraft:bone_block
fill 264 250 504 264 253 504 minecraft:brown_terracotta
setblock 265 250 502 minecraft:bone_block
fill 265 250 503 265 253 503 minecraft:brown_terracotta
fill 266 250 464 267 250 464 minecraft:brown_terracotta
fill 266 250 502 266 253 502 minecraft:brown_terracotta
setblock 268 250 504 minecraft:bone_block
setblock 269 250 503 minecraft:bone_block
fill 269 250 504 269 253 504 minecraft:brown_terracotta
fill 270 250 503 270 252 503 minecraft:brown_terracotta
fill 275 250 478 275 253 478 minecraft:brown_terracotta
setblock 275 250 482 minecraft:bone_block
fill 275 250 483 275 253 483 minecraft:brown_terracotta
setblock 276 250 475 minecraft:brown_terracotta
setblock 276 250 476 minecraft:bone_block
fill 276 250 477 276 253 477 minecraft:brown_terracotta
setblock 276 250 481 minecraft:bone_block
fill 276 250 482 276 253 482 minecraft:brown_terracotta
setblock 276 250 485 minecraft:brown_terracotta
setblock 236 251 464 minecraft:brown_terracotta
setblock 236 251 474 minecraft:brown_terracotta
setblock 236 251 475 minecraft:bone_block
fill 236 251 476 236 254 476 minecraft:brown_terracotta
setblock 236 251 480 minecraft:bone_block
fill 236 251 481 237 253 481 minecraft:brown_terracotta
setblock 236 251 484 minecraft:brown_terracotta
setblock 237 251 464 minecraft:bone_block
fill 237 251 477 237 252 477 minecraft:brown_terracotta
setblock 237 251 479 minecraft:bone_block
fill 237 251 480 237 254 480 minecraft:brown_terracotta
setblock 237 251 504 minecraft:bone_block
fill 238 251 464 241 251 464 minecraft:brown_terracotta
setblock 238 251 466 minecraft:light[level=12]
setblock 238 251 474 minecraft:light[level=12]
setblock 238 251 482 minecraft:light[level=12]
setblock 238 251 490 minecraft:light[level=12]
fill 238 251 504 241 251 504 minecraft:brown_terracotta
fill 239 251 465 240 251 465 minecraft:brown_terracotta
fill 240 251 503 240 253 503 minecraft:brown_terracotta
setblock 241 251 465 minecraft:bone_block
setblock 242 251 464 minecraft:bone_block
fill 242 251 465 242 254 465 minecraft:brown_terracotta
fill 242 251 502 243 251 502 minecraft:brown_terracotta
setblock 242 251 504 minecraft:bone_block
fill 243 251 464 246 251 464 minecraft:brown_terracotta
fill 243 251 466 244 251 466 minecraft:brown_terracotta
setblock 243 251 503 minecraft:bone_block
fill 243 251 504 243 254 504 minecraft:brown_terracotta
setblock 244 251 502 minecraft:bone_block
fill 244 251 503 244 254 503 minecraft:brown_terracotta
setblock 245 251 466 minecraft:bone_block
fill 245 251 502 245 254 502 minecraft:brown_terracotta
setblock 246 251 465 minecraft:bone_block
fill 246 251 466 246 254 466 minecraft:brown_terracotta
setblock 246 251 474 minecraft:light[level=12]
setblock 246 251 482 minecraft:light[level=12]
setblock 246 251 490 minecraft:light[level=12]
setblock 246 251 498 minecraft:light[level=12]
setblock 247 251 464 minecraft:bone_block
fill 247 251 465 247 254 465 minecraft:brown_terracotta
setblock 247 251 504 minecraft:bone_block
fill 248 251 464 248 254 464 minecraft:brown_terracotta
setblock 248 251 503 minecraft:bone_block
fill 248 251 504 248 254 504 minecraft:brown_terracotta
setblock 249 251 502 minecraft:bone_block
fill 249 251 503 249 254 503 minecraft:brown_terracotta
setblock 250 251 465 minecraft:brown_terracotta
fill 250 251 502 250 254 502 minecraft:brown_terracotta
setblock 252 251 464 minecraft:bone_block
setblock 252 251 504 minecraft:bone_block
fill 253 251 464 253 254 464 minecraft:brown_terracotta
setblock 253 251 503 minecraft:bone_block
fill 253 251 504 256 251 504 minecraft:brown_terracotta
setblock 254 251 466 minecraft:light[level=12]
setblock 254 251 474 minecraft:light[level=12]
setblock 254 251 482 minecraft:light[level=12]
setblock 254 251 490 minecraft:light[level=12]
fill 254 251 498 256 252 498 minecraft:bone_block
fill 254 251 500 256 252 500 minecraft:bone_block
fill 254 251 503 257 251 503 minecraft:brown_terracotta
fill 255 251 499 255 252 499 minecraft:bone_block
setblock 257 251 504 minecraft:bone_block
setblock 258 251 503 minecraft:bone_block
fill 258 251 504 261 251 504 minecraft:brown_terracotta
fill 259 251 464 261 251 464 minecraft:brown_terracotta
setblock 259 251 502 minecraft:bone_block
fill 259 251 503 259 254 503 minecraft:brown_terracotta
fill 260 251 502 260 254 502 minecraft:brown_terracotta
setblock 262 251 464 minecraft:bone_block
setblock 262 251 466 minecraft:light[level=12]
setblock 262 251 474 minecraft:light[level=12]
setblock 262 251 482 minecraft:light[level=12]
setblock 262 251 490 minecraft:light[level=12]
setblock 262 251 498 minecraft:light[level=12]
setblock 262 251 504 minecraft:bone_block
fill 263 251 464 263 254 464 minecraft:brown_terracotta
fill 263 251 501 264 251 501 minecraft:brown_terracotta
setblock 263 251 503 minecraft:bone_block
fill 263 251 504 263 254 504 minecraft:brown_terracotta
setblock 264 251 502 minecraft:bone_block
fill 264 251 503 264 254 503 minecraft:brown_terracotta
setblock 265 251 501 minecraft:bone_block
fill 265 251 502 265 254 502 minecraft:brown_terracotta
setblock 266 251 464 minecraft:brown_terracotta
setblock 267 251 464 minecraft:bone_block
setblock 267 251 504 minecraft:bone_block
fill 268 251 464 268 254 464 minecraft:brown_terracotta
setblock 268 251 503 minecraft:bone_block
fill 268 251 504 268 254 504 minecraft:brown_terracotta
fill 269 251 503 269 254 503 minecraft:brown_terracotta
setblock 270 251 466 minecraft:light[level=12]
setblock 270 251 474 minecraft:light[level=12]
setblock 270 251 482 minecraft:light[level=12]
setblock 270 251 490 minecraft:light[level=12]
setblock 270 251 498 minecraft:light[level=12]
setblock 272 251 504 minecraft:bone_block
setblock 275 251 481 minecraft:bone_block
fill 275 251 482 275 254 482 minecraft:brown_terracotta
fill 275 251 484 275 252 484 minecraft:brown_terracotta
setblock 276 251 475 minecraft:bone_block
fill 276 251 476 276 254 476 minecraft:brown_terracotta
setblock 276 251 480 minecraft:bone_block
fill 276 251 481 276 254 481 minecraft:brown_terracotta
setblock 276 251 485 minecraft:bone_block
fill 276 251 486 276 254 486 minecraft:brown_terracotta
setblock 236 252 464 minecraft:bone_block
fill 236 252 465 236 252 468 minecraft:brown_terracotta
setblock 236 252 473 minecraft:brown_terracotta
setblock 236 252 474 minecraft:bone_block
fill 236 252 475 236 255 475 minecraft:brown_terracotta
setblock 236 252 479 minecraft:bone_block
fill 236 252 480 236 255 480 minecraft:brown_terracotta
setblock 236 252 484 minecraft:bone_block
fill 236 252 485 236 255 485 minecraft:brown_terracotta
fill 236 252 502 236 252 503 minecraft:brown_terracotta
setblock 236 252 504 minecraft:bone_block
fill 237 252 464 240 252 464 minecraft:brown_terracotta
setblock 237 252 478 minecraft:bone_block
fill 237 252 479 237 255 479 minecraft:brown_terracotta
setblock 237 252 482 minecraft:brown_terracotta
setblock 237 252 483 minecraft:bone_block
fill 237 252 504 240 252 504 minecraft:brown_terracotta
fill 238 252 465 239 252 465 minecraft:brown_terracotta
fill 238 252 503 239 254 503 minecraft:brown_terracotta
setblock 240 252 465 minecraft:bone_block
setblock 241 252 464 minecraft:bone_block
fill 241 252 465 241 254 466 minecraft:brown_terracotta
fill 241 252 502 242 252 502 minecraft:brown_terracotta
setblock 241 252 504 minecraft:bone_block
fill 242 252 464 245 252 464 minecraft:brown_terracotta
fill 242 252 466 243 252 466 minecraft:brown_terracotta
setblock 242 252 503 minecraft:bone_block
fill 242 252 504 242 255 504 minecraft:brown_terracotta
setblock 243 252 502 minecraft:bone_block
fill 243 252 503 243 255 503 minecraft:brown_terracotta
setblock 244 252 466 minecraft:bone_block
fill 244 252 502 244 255 502 minecraft:brown_terracotta
setblock 245 252 465 minecraft:bone_block
fill 245 252 466 245 255 466 minecraft:brown_terracotta
setblock 246 252 464 minecraft:bone_block
fill 246 252 465 246 255 465 minecraft:brown_terracotta
setblock 246 252 504 minecraft:bone_block
fill 247 252 464 247 255 464 minecraft:brown_terracotta
fill 247 252 466 247 253 466 minecraft:brown_terracotta
setblock 247 252 503 minecraft:bone_block
fill 247 252 504 247 255 504 minecraft:brown_terracotta
setblock 248 252 502 minecraft:bone_block
fill 248 252 503 248 255 503 minecraft:brown_terracotta
fill 249 252 502 249 255 502 minecraft:brown_terracotta
setblock 250 252 465 minecraft:bone_block
setblock 251 252 464 minecraft:bone_block
setblock 251 252 504 minecraft:bone_block
fill 252 252 464 252 255 464 minecraft:brown_terracotta
setblock 252 252 503 minecraft:bone_block
fill 252 252 504 255 252 504 minecraft:brown_terracotta
fill 253 252 503 256 252 503 minecraft:brown_terracotta
fill 254 252 464 255 252 464 minecraft:brown_terracotta
setblock 256 252 464 minecraft:bone_block
fill 256 252 499 257 253 499 minecraft:bone_block
setblock 256 252 504 minecraft:bone_block
fill 257 252 464 260 252 464 minecraft:brown_terracotta
setblock 257 252 502 minecraft:brown_terracotta
setblock 257 252 503 minecraft:bone_block
fill 257 252 504 260 252 504 minecraft:brown_terracotta
setblock 258 252 502 minecraft:bone_block
fill 258 252 503 258 255 503 minecraft:brown_terracotta
fill 259 252 502 259 255 502 minecraft:brown_terracotta
setblock 261 252 464 minecraft:bone_block
setblock 261 252 504 minecraft:bone_block
fill 262 252 464 262 255 464 minecraft:brown_terracotta
fill 262 252 501 263 252 501 minecraft:brown_terracotta
setblock 262 252 503 minecraft:bone_block
fill 262 252 504 262 255 504 minecraft:brown_terracotta
setblock 263 252 502 minecraft:bone_block
fill 263 252 503 263 255 503 minecraft:brown_terracotta
setblock 264 252 501 minecraft:bone_block
fill 264 252 502 264 255 502 minecraft:brown_terracotta
setblock 265 252 501 minecraft:brown_terracotta
setblock 266 252 464 minecraft:bone_block
setblock 266 252 504 minecraft:bone_block
fill 267 252 464 267 255 464 minecraft:brown_terracotta
setblock 267 252 503 minecraft:bone_block
fill 267 252 504 267 255 504 minecraft:brown_terracotta
setblock 268 252 502 minecraft:bone_block
fill 268 252 503 268 255 503 minecraft:brown_terracotta
fill 269 252 464 269 253 464 minecraft:brown_terracotta
setblock 271 252 504 minecraft:bone_block
fill 272 252 504 272 255 504 minecraft:brown_terracotta
setblock 275 252 480 minecraft:bone_block
fill 275 252 481 275 255 481 minecraft:brown_terracotta
setblock 275 252 485 minecraft:bone_block
fill 276 252 475 276 255 475 minecraft:brown_terracotta
setblock 276 252 479 minecraft:bone_block
fill 276 252 480 276 255 480 minecraft:brown_terracotta
setblock 276 252 484 minecraft:bone_block
fill 276 252 485 276 255 485 minecraft:brown_terracotta
fill 276 252 487 276 252 488 minecraft:brown_terracotta
fill 236 253 464 236 253 467 minecraft:brown_terracotta
setblock 236 253 468 minecraft:bone_block
fill 236 253 469 236 253 472 minecraft:brown_terracotta
setblock 236 253 473 minecraft:bone_block
fill 236 253 474 236 256 474 minecraft:brown_terracotta
setblock 236 253 478 minecraft:bone_block
fill 236 253 479 236 256 479 minecraft:brown_terracotta
setblock 236 253 483 minecraft:bone_block
fill 236 253 484 237 255 484 minecraft:brown_terracotta
fill 236 253 486 236 254 486 minecraft:brown_terracotta
fill 236 253 501 236 253 502 minecraft:brown_terracotta
setblock 236 253 503 minecraft:bone_block
fill 236 253 504 239 253 504 minecraft:brown_terracotta
fill 237 253 464 237 253 466 minecraft:brown_terracotta
setblock 237 253 467 minecraft:bone_block
setblock 237 253 477 minecraft:bone_block
fill 237 253 478 237 256 478 minecraft:brown_terracotta
setblock 237 253 482 minecraft:bone_block
fill 237 253 483 237 256 483 minecraft:brown_terracotta
fill 237 253 503 237 256 503 minecraft:brown_terracotta
fill 238 253 464 238 253 465 minecraft:brown_terracotta
setblock 239 253 464 minecraft:brown_terracotta
setblock 239 253 465 minecraft:bone_block
fill 239 253 466 240 255 466 minecraft:brown_terracotta
setblock 240 253 464 minecraft:bone_block
fill 240 253 465 240 256 465 minecraft:brown_terracotta
fill 240 253 502 241 253 502 minecraft:brown_terracotta
setblock 240 253 504 minecraft:bone_block
fill 241 253 464 244 253 464 minecraft:brown_terracotta
setblock 241 253 503 minecraft:bone_block
fill 241 253 504 241 256 504 minecraft:brown_terracotta
setblock 242 253 466 minecraft:brown_terracotta
setblock 242 253 502 minecraft:bone_block
fill 242 253 503 242 256 503 minecraft:brown_terracotta
setblock 243 253 466 minecraft:bone_block
fill 243 253 502 243 256 502 minecraft:brown_terracotta
setblock 244 253 465 minecraft:bone_block
fill 244 253 466 244 256 466 minecraft:brown_terracotta
setblock 245 253 464 minecraft:bone_block
fill 245 253 465 245 256 465 minecraft:brown_terracotta
setblock 245 253 501 minecraft:brown_terracotta
setblock 245 253 504 minecraft:bone_block
fill 246 253 464 246 256 464 minecraft:brown_terracotta
setblock 246 253 503 minecraft:bone_block
fill 246 253 504 246 256 504 minecraft:brown_terracotta
setblock 247 253 502 minecraft:bone_block
fill 247 253 503 247 256 503 minecraft:brown_terracotta
fill 248 253 502 248 256 502 minecraft:brown_terracotta
setblock 249 253 465 minecraft:bone_block
setblock 250 253 464 minecraft:bone_block
fill 250 253 465 250 256 465 minecraft:brown_terracotta
setblock 250 253 504 minecraft:bone_block
fill 251 253 464 251 256 464 minecraft:brown_terracotta
setblock 251 253 503 minecraft:bone_block
fill 251 253 504 254 253 504 minecraft:brown_terracotta
setblock 252 253 502 minecraft:bone_block
fill 252 253 503 255 253 503 minecraft:brown_terracotta
setblock 254 253 464 minecraft:brown_terracotta
setblock 255 253 464 minecraft:bone_block
setblock 255 253 504 minecraft:bone_block
fill 256 253 464 259 253 464 minecraft:brown_terracotta
setblock 256 253 502 minecraft:brown_terracotta
setblock 256 253 503 minecraft:bone_block
fill 256 253 504 259 253 504 minecraft:brown_terracotta
setblock 257 253 502 minecraft:bone_block
fill 257 253 503 257 256 503 minecraft:brown_terracotta
fill 258 253 499 258 254 499 minecraft:bone_block
fill 258 253 502 258 256 502 minecraft:brown_terracotta
setblock 260 253 464 minecraft:bone_block
setblock 260 253 504 minecraft:bone_block
fill 261 253 464 261 255 465 minecraft:brown_terracotta
fill 261 253 501 262 253 501 minecraft:brown_terracotta
setblock 261 253 503 minecraft:bone_block
fill 261 253 504 261 256 504 minecraft:brown_terracotta
fill 262 253 465 263 253 465 minecraft:brown_terracotta
setblock 262 253 502 minecraft:bone_block
fill 262 253 503 262 256 503 minecraft:brown_terracotta
setblock 263 253 501 minecraft:bone_block
fill 263 253 502 263 256 502 minecraft:brown_terracotta
setblock 264 253 465 minecraft:bone_block
fill 264 253 501 264 254 501 minecraft:brown_terracotta
setblock 265 253 464 minecraft:bone_block
fill 265 253 465 266 255 465 minecraft:brown_terracotta
setblock 265 253 504 minecraft:bone_block
fill 266 253 464 266 256 464 minecraft:brown_terracotta
setblock 266 253 503 minecraft:bone_block
fill 266 253 504 266 256 504 minecraft:brown_terracotta
setblock 267 253 502 minecraft:bone_block
fill 267 253 503 267 256 503 minecraft:brown_terracotta
setblock 270 253 464 minecraft:bone_block
setblock 270 253 504 minecraft:bone_block
fill 271 253 504 271 255 504 minecraft:brown_terracotta
fill 274 253 482 274 254 483 minecraft:brown_terracotta
setblock 275 253 479 minecraft:bone_block
fill 275 253 480 275 256 480 minecraft:brown_terracotta
setblock 275 253 484 minecraft:bone_block
fill 275 253 485 275 255 486 minecraft:brown_terracotta
fill 276 253 464 276 256 464 minecraft:brown_terracotta
fill 276 253 474 276 256 474 minecraft:brown_terracotta
setblock 276 253 478 minecraft:bone_block
fill 276 253 479 276 256 479 minecraft:brown_terracotta
setblock 276 253 483 minecraft:bone_block
fill 276 253 484 276 256 484 minecraft:brown_terracotta
setblock 276 253 487 minecraft:brown_terracotta
setblock 276 253 488 minecraft:bone_block
fill 276 253 489 276 256 489 minecraft:brown_terracotta
setblock 276 253 503 minecraft:bone_block
fill 276 253 504 276 256 504 minecraft:brown_terracotta
fill 236 254 464 236 254 466 minecraft:brown_terracotta
setblock 236 254 467 minecraft:bone_block
fill 236 254 468 236 254 471 minecraft:brown_terracotta
setblock 236 254 472 minecraft:bone_block
fill 236 254 473 236 257 473 minecraft:brown_terracotta
setblock 236 254 477 minecraft:bone_block
fill 236 254 478 236 257 478 minecraft:brown_terracotta
setblock 236 254 481 minecraft:brown_terracotta
setblock 236 254 482 minecraft:bone_block
fill 236 254 483 236 257 483 minecraft:brown_terracotta
setblock 236 254 487 minecraft:bone_block
setblock 236 254 501 minecraft:brown_terracotta
setblock 236 254 502 minecraft:bone_block
fill 236 254 503 236 256 504 minecraft:brown_terracotta
fill 237 254 464 237 254 465 minecraft:brown_terracotta
setblock 237 254 466 minecraft:bone_block
fill 237 254 467 237 255 469 minecraft:brown_terracotta
setblock 237 254 476 minecraft:bone_block
fill 237 254 477 237 256 477 minecraft:brown_terracotta
setblock 237 254 481 minecraft:bone_block
fill 237 254 482 237 257 482 minecraft:brown_terracotta
setblock 237 254 485 minecraft:brown_terracotta
fill 237 254 502 237 257 502 minecraft:brown_terracotta
fill 237 254 504 238 254 504 minecraft:brown_terracotta
setblock 238 254 464 minecraft:brown_terracotta
setblock 238 254 465 minecraft:bone_block
fill 238 254 466 238 256 467 minecraft:brown_terracotta
setblock 239 254 464 minecraft:bone_block
fill 239 254 465 239 257 465 minecraft:brown_terracotta
setblock 239 254 504 minecraft:bone_block
fill 240 254 464 243 254 464 minecraft:brown_terracotta
setblock 240 254 502 minecraft:brown_terracotta
setblock 240 254 503 minecraft:bone_block
fill 240 254 504 240 257 504 minecraft:brown_terracotta
setblock 241 254 502 minecraft:bone_block
fill 241 254 503 241 257 503 minecraft:brown_terracotta
setblock 242 254 466 minecraft:bone_block
fill 242 254 467 243 256 467 minecraft:brown_terracotta
fill 242 254 502 242 257 502 minecraft:brown_terracotta
setblock 243 254 465 minecraft:bone_block
fill 243 254 466 243 257 466 minecraft:brown_terracotta
setblock 244 254 464 minecraft:bone_block
fill 244 254 465 244 257 465 minecraft:brown_terracotta
setblock 244 254 504 minecraft:bone_block
fill 245 254 464 245 257 464 minecraft:brown_terracotta
setblock 245 254 503 minecraft:bone_block
fill 245 254 504 245 257 504 minecraft:brown_terracotta
setblock 246 254 502 minecraft:bone_block
fill 246 254 503 246 257 503 minecraft:brown_terracotta
setblock 247 254 466 minecraft:bone_block
fill 247 254 502 247 256 502 minecraft:brown_terracotta
setblock 248 254 465 minecraft:bone_block
setblock 249 254 464 minecraft:bone_block
fill 249 254 465 249 257 465 minecraft:brown_terracotta
setblock 249 254 504 minecraft:bone_block
fill 250 254 464 250 257 464 minecraft:brown_terracotta
setblock 250 254 503 minecraft:bone_block
fill 250 254 504 253 254 504 minecraft:brown_terracotta
fill 251 254 465 251 255 465 minecraft:brown_terracotta
setblock 251 254 502 minecraft:bone_block
fill 251 254 503 254 254 503 minecraft:brown_terracotta
setblock 254 254 464 minecraft:bone_block
setblock 254 254 504 minecraft:bone_block
fill 255 254 464 258 254 464 minecraft:brown_terracotta
setblock 255 254 502 minecraft:brown_terracotta
setblock 255 254 503 minecraft:bone_block
fill 255 254 504 258 254 504 minecraft:brown_terracotta
setblock 256 254 502 minecraft:bone_block
fill 256 254 503 256 257 503 minecraft:brown_terracotta
fill 257 254 502 257 257 502 minecraft:brown_terracotta
setblock 259 254 464 minecraft:bone_block
fill 259 254 465 260 256 465 minecraft:brown_terracotta
fill 259 254 499 260 255 499 minecraft:bone_block
setblock 259 254 504 minecraft:bone_block
fill 260 254 464 260 257 464 minecraft:brown_terracotta
setblock 260 254 503 minecraft:bone_block
fill 260 254 504 260 257 504 minecraft:brown_terracotta
setblock 261 254 501 minecraft:brown_terracotta
setblock 261 254 502 minecraft:bone_block
fill 261 254 503 261 257 503 minecraft:brown_terracotta
setblock 262 254 465 minecraft:brown_terracotta
setblock 262 254 501 minecraft:bone_block
fill 262 254 502 262 257 502 minecraft:brown_terracotta
setblock 263 254 465 minecraft:bone_block
setblock 263 254 501 minecraft:brown_terracotta
setblock 264 254 464 minecraft:bone_block
fill 264 254 465 264 257 465 minecraft:brown_terracotta
setblock 264 254 504 minecraft:bone_block
fill 265 254 464 265 257 464 minecraft:brown_terracotta
setblock 265 254 503 minecraft:bone_block
fill 265 254 504 265 257 504 minecraft:brown_terracotta
setblock 266 254 502 minecraft:bone_block
fill 266 254 503 266 257 503 minecraft:brown_terracotta
setblock 267 254 502 minecraft:brown_terracotta
setblock 269 254 464 minecraft:bone_block
setblock 269 254 504 minecraft:bone_block
fill 270 254 464 273 254 464 minecraft:brown_terracotta
fill 270 254 504 270 256 504 minecraft:brown_terracotta
setblock 273 254 504 minecraft:brown_terracotta
setblock 274 254 464 minecraft:bone_block
setblock 274 254 481 minecraft:brown_terracotta
setblock 274 254 484 minecraft:bone_block
setblock 274 254 504 minecraft:bone_block
fill 275 254 464 275 257 464 minecraft:brown_terracotta
setblock 275 254 478 minecraft:bone_block
fill 275 254 479 275 257 479 minecraft:brown_terracotta
setblock 275 254 483 minecraft:bone_block
fill 275 254 484 275 257 484 minecraft:brown_terracotta
setblock 275 254 487 minecraft:brown_terracotta
fill 275 254 504 275 257 504 minecraft:brown_terracotta
fill 276 254 465 276 254 466 minecraft:brown_terracotta
setblock 276 254 467 minecraft:bone_block
fill 276 254 468 276 257 468 minecraft:brown_terracotta
fill 276 254 473 276 257 473 minecraft:brown_terracotta
setblock 276 254 477 minecraft:bone_block
fill 276 254 478 276 257 478 minecraft:brown_terracotta
setblock 276 254 482 minecraft:bone_block
fill 276 254 483 276 257 483 minecraft:brown_terracotta
setblock 276 254 487 minecraft:bone_block
fill 276 254 488 276 257 488 minecraft:brown_terracotta
setblock 276 254 502 minecraft:bone_block
fill 276 254 503 276 257 503 minecraft:brown_terracotta
fill 236 255 464 236 255 465 minecraft:brown_terracotta
setblock 236 255 466 minecraft:bone_block
fill 236 255 467 236 255 470 minecraft:brown_terracotta
setblock 236 255 471 minecraft:bone_block
fill 236 255 472 236 258 472 minecraft:brown_terracotta
setblock 236 255 476 minecraft:bone_block
fill 236 255 477 236 258 477 minecraft:brown_terracotta
setblock 236 255 481 minecraft:bone_block
fill 236 255 482 236 258 482 minecraft:brown_terracotta
setblock 236 255 486 minecraft:bone_block
fill 236 255 487 236 257 488 minecraft:brown_terracotta
setblock 236 255 501 minecraft:bone_block
fill 236 255 502 236 258 502 minecraft:brown_terracotta
setblock 237 255 464 minecraft:brown_terracotta
setblock 237 255 465 minecraft:bone_block
fill 237 255 466 237 258 466 minecraft:brown_terracotta
setblock 237 255 470 minecraft:bone_block
fill 237 255 471 237 258 471 minecraft:brown_terracotta
setblock 237 255 480 minecraft:bone_block
fill 237 255 481 237 258 481 minecraft:brown_terracotta
setblock 237 255 485 minecraft:bone_block
fill 237 255 486 237 258 486 minecraft:brown_terracotta
setblock 237 255 504 minecraft:brown_terracotta
setblock 238 255 464 minecraft:bone_block
fill 238 255 465 238 258 465 minecraft:brown_terracotta
setblock 238 255 468 minecraft:brown_terracotta
setblock 238 255 482 minecraft:brown_terracotta
setblock 238 255 503 minecraft:brown_terracotta
setblock 238 255 504 minecraft:bone_block
fill 239 255 464 242 255 464 minecraft:brown_terracotta
setblock 239 255 502 minecraft:brown_terracotta
setblock 239 255 503 minecraft:bone_block
fill 239 255 504 239 258 504 minecraft:brown_terracotta
setblock 240 255 467 minecraft:bone_block
setblock 240 255 502 minecraft:bone_block
fill 240 255 503 240 258 503 minecraft:brown_terracotta
setblock 241 255 465 minecraft:brown_terracotta
setblock 241 255 466 minecraft:bone_block
fill 241 255 467 241 258 467 minecraft:brown_terracotta
fill 241 255 502 241 258 502 minecraft:brown_terracotta
setblock 242 255 465 minecraft:bone_block
fill 242 255 466 242 258 466 minecraft:brown_terracotta
setblock 243 255 464 minecraft:bone_block
fill 243 255 465 243 258 465 minecraft:brown_terracotta
setblock 243 255 504 minecraft:bone_block
fill 244 255 464 244 258 464 minecraft:brown_terracotta
setblock 244 255 467 minecraft:brown_terracotta
setblock 244 255 503 minecraft:bone_block
fill 244 255 504 244 258 504 minecraft:brown_terracotta
setblock 245 255 502 minecraft:bone_block
fill 245 255 503 245 258 503 minecraft:brown_terracotta
setblock 246 255 466 minecraft:bone_block
fill 246 255 502 246 257 502 minecraft:brown_terracotta
setblock 247 255 465 minecraft:bone_block
fill 247 255 466 247 257 466 minecraft:brown_terracotta
setblock 248 255 464 minecraft:bone_block
fill 248 255 465 248 258 465 minecraft:brown_terracotta
setblock 248 255 504 minecraft:bone_block
fill 249 255 464 249 258 464 minecraft:brown_terracotta
setblock 249 255 503 minecraft:bone_block
fill 249 255 504 252 255 504 minecraft:brown_terracotta
setblock 250 255 502 minecraft:bone_block
fill 250 255 503 253 255 503 minecraft:brown_terracotta
setblock 253 255 464 minecraft:bone_block
setblock 253 255 504 minecraft:bone_block
fill 254 255 464 257 255 464 minecraft:brown_terracotta
setblock 254 255 503 minecraft:bone_block
fill 254 255 504 257 255 504 minecraft:brown_terracotta
fill 255 255 503 255 258 503 minecraft:brown_terracotta
fill 256 255 502 256 256 502 minecraft:brown_terracotta
setblock 257 255 465 minecraft:bone_block
setblock 258 255 464 minecraft:bone_block
fill 258 255 465 258 258 465 minecraft:brown_terracotta
setblock 258 255 504 minecraft:bone_block
fill 259 255 464 259 258 464 minecraft:brown_terracotta
setblock 259 255 503 minecraft:bone_block
fill 259 255 504 259 258 504 minecraft:brown_terracotta
fill 260 255 498 262 256 498 minecraft:bone_block
fill 260 255 500 262 256 500 minecraft:bone_block
setblock 260 255 502 minecraft:bone_block
fill 260 255 503 260 258 503 minecraft:brown_terracotta
fill 261 255 499 261 256 499 minecraft:bone_block
setblock 261 255 501 minecraft:bone_block
fill 261 255 502 261 258 502 minecraft:brown_terracotta
setblock 262 255 465 minecraft:bone_block
setblock 262 255 501 minecraft:brown_terracotta
setblock 263 255 464 minecraft:bone_block
fill 263 255 465 263 258 465 minecraft:brown_terracotta
setblock 263 255 504 minecraft:bone_block
fill 264 255 464 264 258 464 minecraft:brown_terracotta
setblock 264 255 503 minecraft:bone_block
fill 264 255 504 264 258 504 minecraft:brown_terracotta
setblock 265 255 502 minecraft:bone_block
fill 265 255 503 265 257 503 minecraft:brown_terracotta
setblock 266 255 502 minecraft:brown_terracotta
setblock 267 255 465 minecraft:bone_block
setblock 268 255 464 minecraft:bone_block
setblock 268 255 504 minecraft:bone_block
fill 269 255 464 272 255 464 minecraft:brown_terracotta
fill 269 255 504 269 257 504 minecraft:brown_terracotta
setblock 273 255 464 minecraft:bone_block
fill 274 255 464 274 258 464 minecraft:brown_terracotta
setblock 274 255 482 minecraft:brown_terracotta
setblock 274 255 483 minecraft:bone_block
fill 274 255 484 274 256 485 minecraft:brown_terracotta
setblock 274 255 504 minecraft:brown_terracotta
fill 275 255 478 275 256 478 minecraft:brown_terracotta
setblock 275 255 482 minecraft:bone_block
fill 275 255 483 275 258 483 minecraft:brown_terracotta
setblock 275 255 487 minecraft:bone_block
fill 275 255 488 275 258 488 minecraft:brown_terracotta
setblock 276 255 465 minecraft:brown_terracotta
setblock 276 255 466 minecraft:bone_block
fill 276 255 467 276 258 467 minecraft:brown_terracotta
fill 276 255 469 276 255 470 minecraft:brown_terracotta
setblock 276 255 471 minecraft:bone_block
fill 276 255 472 276 258 472 minecraft:brown_terracotta
setblock 276 255 476 minecraft:bone_block
fill 276 255 477 276 258 477 minecraft:brown_terracotta
setblock 276 255 481 minecraft:bone_block
fill 276 255 482 276 258 482 minecraft:brown_terracotta
setblock 276 255 486 minecraft:bone_block
fill 276 255 487 276 258 487 minecraft:brown_terracotta
setblock 276 255 490 minecraft:brown_terracotta
setblock 276 255 502 minecraft:brown_terracotta
setblock 236 256 464 minecraft:brown_terracotta
setblock 236 256 465 minecraft:bone_block
fill 236 256 466 236 256 469 minecraft:brown_terracotta
setblock 236 256 470 minecraft:bone_block
fill 236 256 471 236 259 471 minecraft:brown_terracotta
setblock 236 256 475 minecraft:bone_block
fill 236 256 476 236 259 476 minecraft:brown_terracotta
setblock 236 256 480 minecraft:bone_block
fill 236 256 481 236 259 481 minecraft:brown_terracotta
setblock 236 256 484 minecraft:brown_terracotta
setblock 236 256 485 minecraft:bone_block
fill 236 256 486 236 259 486 minecraft:brown_terracotta
setblock 236 256 489 minecraft:brown_terracotta
fill 236 256 501 236 258 501 minecraft:brown_terracotta
setblock 237 256 464 minecraft:bone_block
fill 237 256 465 237 259 465 minecraft:brown_terracotta
fill 237 256 467 237 256 468 minecraft:brown_terracotta
setblock 237 256 469 minecraft:bone_block
fill 237 256 470 237 259 470 minecraft:brown_terracotta
fill 237 256 472 237 257 472 minecraft:brown_terracotta
setblock 237 256 479 minecraft:bone_block
fill 237 256 480 237 257 480 minecraft:brown_terracotta
setblock 237 256 484 minecraft:bone_block
fill 237 256 485 237 259 485 minecraft:brown_terracotta
fill 237 256 487 237 257 487 minecraft:brown_terracotta
setblock 237 256 504 minecraft:bone_block
fill 238 256 464 241 256 464 minecraft:brown_terracotta
setblock 238 256 468 minecraft:bone_block
fill 238 256 469 238 259 469 minecraft:brown_terracotta
setblock 238 256 503 minecraft:bone_block
fill 238 256 504 238 259 504 minecraft:brown_terracotta
setblock 239 256 466 minecraft:brown_terracotta
setblock 239 256 467 minecraft:bone_block
setblock 239 256 502 minecraft:bone_block
fill 239 256 503 239 259 503 minecraft:brown_terracotta
setblock 240 256 466 minecraft:bone_block
fill 240 256 467 240 259 467 minecraft:brown_terracotta
fill 240 256 502 240 258 502 minecraft:brown_terracotta
setblock 241 256 465 minecraft:bone_block
fill 241 256 466 241 259 466 minecraft:brown_terracotta
setblock 242 256 464 minecraft:bone_block
fill 242 256 465 242 259 465 minecraft:brown_terracotta
setblock 242 256 504 minecraft:bone_block
fill 243 256 464 243 259 464 minecraft:brown_terracotta
setblock 243 256 503 minecraft:bone_block
fill 243 256 504 243 259 504 minecraft:brown_terracotta
setblock 244 256 467 minecraft:bone_block
setblock 244 256 502 minecraft:bone_block
fill 244 256 503 244 259 503 minecraft:brown_terracotta
setblock 245 256 466 minecraft:bone_block
fill 245 256 502 245 257 502 minecraft:brown_terracotta
setblock 246 256 465 minecraft:bone_block
fill 246 256 466 246 258 466 minecraft:brown_terracotta
setblock 247 256 464 minecraft:bone_block
fill 247 256 465 247 259 465 minecraft:brown_terracotta
setblock 247 256 504 minecraft:bone_block
fill 248 256 464 248 259 464 minecraft:brown_terracotta
setblock 248 256 503 minecraft:bone_block
fill 248 256 504 251 256 504 minecraft:brown_terracotta
fill 249 256 503 252 256 503 minecraft:brown_terracotta
setblock 251 256 465 minecraft:bone_block
setblock 252 256 464 minecraft:bone_block
setblock 252 256 504 minecraft:bone_block
fill 253 256 464 256 256 464 minecraft:brown_terracotta
setblock 253 256 503 minecraft:bone_block
fill 253 256 504 256 256 504 minecraft:brown_terracotta
fill 254 256 503 254 258 503 minecraft:brown_terracotta
setblock 256 256 465 minecraft:bone_block
setblock 257 256 464 minecraft:bone_block
fill 257 256 465 257 259 465 minecraft:brown_terracotta
setblock 257 256 504 minecraft:bone_block
fill 258 256 464 258 259 464 minecraft:brown_terracotta
setblock 258 256 503 minecraft:bone_block
fill 258 256 504 258 259 504 minecraft:brown_terracotta
setblock 259 256 502 minecraft:bone_block
fill 259 256 503 259 259 503 minecraft:brown_terracotta
fill 260 256 502 260 258 502 minecraft:brown_terracotta
setblock 261 256 464 minecraft:brown_terracotta
setblock 261 256 465 minecraft:bone_block
setblock 262 256 464 minecraft:bone_block
fill 262 256 465 262 259 465 minecraft:brown_terracotta
setblock 262 256 504 minecraft:bone_block
fill 263 256 464 263 259 464 minecraft:brown_terracotta
setblock 263 256 503 minecraft:bone_block
fill 263 256 504 263 259 504 minecraft:brown_terracotta
setblock 264 256 502 minecraft:bone_block
fill 264 256 503 264 258 503 minecraft:brown_terracotta
setblock 265 256 465 minecraft:brown_terracotta
setblock 265 256 502 minecraft:brown_terracotta
setblock 266 256 465 minecraft:bone_block
setblock 267 256 464 minecraft:bone_block
setblock 267 256 465 minecraft:brown_terracotta
setblock 267 256 504 minecraft:bone_block
fill 268 256 464 271 256 464 minecraft:brown_terracotta
fill 268 256 504 268 257 504 minecraft:brown_terracotta
setblock 272 256 464 minecraft:bone_block
fill 273 256 464 273 259 464 minecraft:brown_terracotta
setblock 274 256 482 minecraft:bone_block
setblock 274 256 483 minecraft:brown_terracotta
setblock 275 256 465 minecraft:brown_terracotta
setblock 275 256 481 minecraft:bone_block
fill 275 256 482 275 259 482 minecraft:brown_terracotta
setblock 275 256 485 minecraft:brown_terracotta
setblock 275 256 486 minecraft:bone_block
fill 275 256 487 275 259 487 minecraft:brown_terracotta
setblock 276 256 465 minecraft:bone_block
fill 276 256 466 276 259 466 minecraft:brown_terracotta
setblock 276 256 469 minecraft:brown_terracotta
setblock 276 256 470 minecraft:bone_block
fill 276 256 471 276 259 471 minecraft:brown_terracotta
setblock 276 256 475 minecraft:bone_block
fill 276 256 476 276 259 476 minecraft:brown_terracotta
setblock 276 256 480 minecraft:bone_block
fill 276 256 481 276 259 481 minecraft:brown_terracotta
setblock 276 256 485 minecraft:bone_block
fill 276 256 486 276 259 486 minecraft:brown_terracotta
setblock 276 256 490 minecraft:bone_block
fill 276 256 491 276 259 491 minecraft:brown_terracotta
setblock 236 257 464 minecraft:bone_block
fill 236 257 465 236 257 468 minecraft:brown_terracotta
setblock 236 257 469 minecraft:bone_block
fill 236 257 470 236 260 470 minecraft:brown_terracotta
setblock 236 257 474 minecraft:bone_block
fill 236 257 475 236 260 475 minecraft:brown_terracotta
setblock 236 257 479 minecraft:bone_block
fill 236 257 480 236 259 480 minecraft:brown_terracotta
setblock 236 257 484 minecraft:bone_block
fill 236 257 485 236 260 485 minecraft:brown_terracotta
setblock 236 257 489 minecraft:bone_block
setblock 236 257 503 minecraft:brown_terracotta
setblock 236 257 504 minecraft:bone_block
fill 237 257 464 240 257 464 minecraft:brown_terracotta
setblock 237 257 467 minecraft:brown_terracotta
setblock 237 257 468 minecraft:bone_block
fill 237 257 469 237 260 469 minecraft:brown_terracotta
setblock 237 257 473 minecraft:bone_block
setblock 237 257 479 minecraft:brown_terracotta
setblock 237 257 483 minecraft:bone_block
fill 237 257 484 237 259 484 minecraft:brown_terracotta
setblock 237 257 503 minecraft:bone_block
fill 237 257 504 237 260 504 minecraft:brown_terracotta
setblock 238 257 466 minecraft:brown_terracotta
setblock 238 257 467 minecraft:bone_block
fill 238 257 468 239 259 468 minecraft:brown_terracotta
fill 238 257 470 238 258 470 minecraft:brown_terracotta
fill 238 257 503 238 260 503 minecraft:brown_terracotta
setblock 239 257 466 minecraft:bone_block
fill 239 257 467 239 260 467 minecraft:brown_terracotta
setblock 239 257 502 minecraft:brown_terracotta
setblock 240 257 465 minecraft:bone_block
fill 240 257 466 240 260 466 minecraft:brown_terracotta
setblock 241 257 464 minecraft:bone_block
fill 241 257 465 241 260 465 minecraft:brown_terracotta
setblock 241 257 504 minecraft:bone_block
fill 242 257 464 242 260 464 minecraft:brown_terracotta
setblock 242 257 467 minecraft:brown_terracotta
setblock 242 257 503 minecraft:bone_block
fill 242 257 504 242 260 504 minecraft:brown_terracotta
setblock 243 257 467 minecraft:bone_block
setblock 243 257 502 minecraft:bone_block
fill 243 257 503 243 260 503 minecraft:brown_terracotta
setblock 244 257 466 minecraft:bone_block
setblock 244 257 467 minecraft:brown_terracotta
fill 244 257 502 244 258 502 minecraft:brown_terracotta
setblock 245 257 465 minecraft:bone_block
fill 245 257 466 245 259 466 minecraft:brown_terracotta
setblock 246 257 464 minecraft:bone_block
fill 246 257 465 246 260 465 minecraft:brown_terracotta
setblock 246 257 504 minecraft:bone_block
fill 247 257 464 247 260 464 minecraft:brown_terracotta
fill 247 257 502 247 264 502 minecraft:soul_soil
setblock 247 257 503 minecraft:bone_block
fill 247 257 504 250 257 504 minecraft:brown_terracotta
fill 248 257 503 251 257 503 minecraft:brown_terracotta
setblock 250 257 465 minecraft:bone_block
setblock 251 257 464 minecraft:bone_block
setblock 251 257 504 minecraft:bone_block
fill 252 257 464 255 257 464 minecraft:brown_terracotta
setblock 252 257 503 minecraft:bone_block
fill 252 257 504 255 257 504 minecraft:brown_terracotta
fill 253 257 503 253 258 503 minecraft:brown_terracotta
setblock 256 257 464 minecraft:bone_block
fill 256 257 465 256 259 465 minecraft:brown_terracotta
setblock 256 257 504 minecraft:bone_block
fill 257 257 464 257 260 464 minecraft:brown_terracotta
setblock 257 257 503 minecraft:bone_block
fill 257 257 504 257 260 504 minecraft:brown_terracotta
setblock 258 257 502 minecraft:bone_block
fill 258 257 503 258 260 503 minecraft:brown_terracotta
setblock 259 257 465 minecraft:brown_terracotta
fill 259 257 502 259 258 502 minecraft:brown_terracotta
setblock 260 257 465 minecraft:bone_block
setblock 261 257 464 minecraft:bone_block
fill 261 257 465 261 260 465 minecraft:brown_terracotta
setblock 261 257 504 minecraft:bone_block
fill 262 257 464 262 260 464 minecraft:brown_terracotta
setblock 262 257 503 minecraft:bone_block
fill 262 257 504 262 260 504 minecraft:brown_terracotta
setblock 263 257 502 minecraft:bone_block
fill 263 257 503 263 259 503 minecraft:brown_terracotta
setblock 265 257 465 minecraft:bone_block
setblock 266 257 464 minecraft:bone_block
setblock 266 257 465 minecraft:brown_terracotta
setblock 266 257 504 minecraft:bone_block
fill 267 257 464 270 257 464 minecraft:brown_terracotta
fill 267 257 504 267 258 504 minecraft:brown_terracotta
setblock 271 257 464 minecraft:bone_block
fill 272 257 464 272 259 464 minecraft:brown_terracotta
setblock 274 257 484 minecraft:brown_terracotta
setblock 275 257 465 minecraft:bone_block
fill 275 257 466 275 259 467 minecraft:brown_terracotta
setblock 275 257 480 minecraft:bone_block
fill 275 257 481 275 259 481 minecraft:brown_terracotta
setblock 275 257 485 minecraft:bone_block
fill 275 257 486 275 260 486 minecraft:brown_terracotta
setblock 276 257 464 minecraft:bone_block
fill 276 257 465 276 260 465 minecraft:brown_terracotta
setblock 276 257 469 minecraft:bone_block
fill 276 257 470 276 260 470 minecraft:brown_terracotta
setblock 276 257 474 minecraft:bone_block
fill 276 257 475 276 260 475 minecraft:brown_terracotta
setblock 276 257 479 minecraft:bone_block
fill 276 257 480 276 260 480 minecraft:brown_terracotta
setblock 276 257 484 minecraft:bone_block
fill 276 257 485 276 260 485 minecraft:brown_terracotta
setblock 276 257 489 minecraft:bone_block
fill 276 257 490 276 260 490 minecraft:brown_terracotta
setblock 276 257 504 minecraft:bone_block
fill 236 258 464 236 258 467 minecraft:brown_terracotta
setblock 236 258 468 minecraft:bone_block
fill 236 258 469 236 261 469 minecraft:brown_terracotta
setblock 236 258 473 minecraft:bone_block
fill 236 258 474 236 261 474 minecraft:brown_terracotta
setblock 236 258 478 minecraft:bone_block
fill 236 258 479 236 259 479 minecraft:brown_terracotta
setblock 236 258 483 minecraft:bone_block
fill 236 258 484 236 261 484 minecraft:brown_terracotta
setblock 236 258 487 minecraft:brown_terracotta
setblock 236 258 488 minecraft:bone_block
fill 236 258 489 236 260 490 minecraft:brown_terracotta
setblock 236 258 503 minecraft:bone_block
fill 236 258 504 236 261 504 minecraft:brown_terracotta
fill 237 258 464 239 258 464 minecraft:brown_terracotta
setblock 237 258 467 minecraft:bone_block
fill 237 258 468 237 261 468 minecraft:brown_terracotta
setblock 237 258 472 minecraft:bone_block
fill 237 258 473 237 261 473 minecraft:brown_terracotta
setblock 237 258 482 minecraft:bone_block
fill 237 258 483 237 259 483 minecraft:brown_terracotta
setblock 237 258 487 minecraft:bone_block
fill 237 258 488 237 261 488 minecraft:brown_terracotta
fill 237 258 503 237 260 503 minecraft:brown_terracotta
setblock 238 258 466 minecraft:bone_block
fill 238 258 467 238 261 467 minecraft:brown_terracotta
setblock 239 258 465 minecraft:bone_block
fill 239 258 466 239 261 466 minecraft:brown_terracotta
setblock 240 258 464 minecraft:bone_block
fill 240 258 465 240 261 465 minecraft:brown_terracotta
setblock 240 258 504 minecraft:bone_block
fill 241 258 464 241 261 464 minecraft:brown_terracotta
setblock 241 258 503 minecraft:bone_block
fill 241 258 504 241 261 504 minecraft:brown_terracotta
setblock 242 258 467 minecraft:bone_block
setblock 242 258 502 minecraft:bone_block
fill 242 258 503 242 261 503 minecraft:brown_terracotta
setblock 243 258 466 minecraft:bone_block
setblock 243 258 467 minecraft:brown_terracotta
setblock 243 258 502 minecraft:brown_terracotta
setblock 244 258 465 minecraft:bone_block
fill 244 258 466 244 260 466 minecraft:brown_terracotta
setblock 245 258 464 minecraft:bone_block
fill 245 258 465 245 261 465 minecraft:brown_terracotta
setblock 245 258 504 minecraft:bone_block
fill 246 258 464 246 261 464 minecraft:brown_terracotta
setblock 246 258 503 minecraft:bone_block
fill 246 258 504 249 258 504 minecraft:brown_terracotta
fill 247 258 503 250 258 503 minecraft:brown_terracotta
setblock 249 258 465 minecraft:bone_block
setblock 250 258 464 minecraft:bone_block
setblock 250 258 504 minecraft:bone_block
fill 251 258 464 254 258 464 minecraft:brown_terracotta
setblock 251 258 503 minecraft:bone_block
fill 251 258 504 254 258 504 minecraft:brown_terracotta
setblock 252 258 503 minecraft:brown_terracotta
fill 254 258 493 254 259 494 minecraft:soul_soil
setblock 255 258 464 minecraft:bone_block
setblock 255 258 504 minecraft:bone_block
fill 256 258 464 256 261 464 minecraft:brown_terracotta
setblock 256 258 503 minecraft:bone_block
fill 256 258 504 256 261 504 minecraft:brown_terracotta
fill 257 258 503 257 260 503 minecraft:brown_terracotta
setblock 259 258 465 minecraft:bone_block
setblock 260 258 464 minecraft:bone_block
fill 260 258 465 260 261 465 minecraft:brown_terracotta
setblock 260 258 504 minecraft:bone_block
fill 261 258 464 261 261 464 minecraft:brown_terracotta
setblock 261 258 503 minecraft:bone_block
fill 261 258 504 261 261 504 minecraft:brown_terracotta
fill 262 258 503 262 259 503 minecraft:brown_terracotta
setblock 264 258 465 minecraft:bone_block
setblock 265 258 464 minecraft:bone_block
setblock 265 258 465 minecraft:brown_terracotta
setblock 265 258 504 minecraft:bone_block
fill 266 258 464 269 258 464 minecraft:brown_terracotta
setblock 266 258 504 minecraft:brown_terracotta
setblock 270 258 464 minecraft:bone_block
setblock 271 258 464 minecraft:brown_terracotta
setblock 275 258 464 minecraft:bone_block
fill 275 258 465 275 261 465 minecraft:brown_terracotta
setblock 275 258 468 minecraft:brown_terracotta
setblock 275 258 469 minecraft:bone_block
setblock 275 258 480 minecraft:brown_terracotta
setblock 275 258 484 minecraft:bone_block
fill 275 258 485 275 261 485 minecraft:brown_terracotta
setblock 275 258 489 minecraft:bone_block
fill 276 258 464 276 261 464 minecraft:brown_terracotta
setblock 276 258 468 minecraft:bone_block
fill 276 258 469 276 261 469 minecraft:brown_terracotta
setblock 276 258 473 minecraft:bone_block
fill 276 258 474 276 261 474 minecraft:brown_terracotta
setblock 276 258 478 minecraft:bone_block
fill 276 258 479 276 261 479 minecraft:brown_terracotta
setblock 276 258 483 minecraft:bone_block
fill 276 258 484 276 261 484 minecraft:brown_terracotta
setblock 276 258 488 minecraft:bone_block
fill 276 258 489 276 261 489 minecraft:brown_terracotta
fill 276 258 504 276 259 504 minecraft:brown_terracotta
fill 236 259 464 236 259 466 minecraft:brown_terracotta
setblock 236 259 467 minecraft:bone_block
fill 236 259 468 236 262 468 minecraft:brown_terracotta
setblock 236 259 472 minecraft:bone_block
fill 236 259 473 236 262 473 minecraft:brown_terracotta
setblock 236 259 477 minecraft:bone_block
setblock 236 259 478 minecraft:brown_terracotta
setblock 236 259 482 minecraft:bone_block
fill 236 259 483 236 261 483 minecraft:brown_terracotta
setblock 236 259 487 minecraft:bone_block
fill 236 259 488 236 262 488 minecraft:brown_terracotta
setblock 236 259 491 minecraft:brown_terracotta
setblock 236 259 502 minecraft:bone_block
fill 236 259 503 236 262 503 minecraft:brown_terracotta
fill 237 259 464 238 259 464 minecraft:brown_terracotta
setblock 237 259 466 minecraft:bone_block
fill 237 259 467 237 262 467 minecraft:brown_terracotta
setblock 237 259 471 minecraft:bone_block
fill 237 259 472 237 262 472 minecraft:brown_terracotta
setblock 237 259 486 minecraft:bone_block
fill 237 259 487 237 260 487 minecraft:brown_terracotta
setblock 238 259 465 minecraft:bone_block
fill 238 259 466 238 262 466 minecraft:brown_terracotta
setblock 238 259 470 minecraft:bone_block
setblock 238 259 474 minecraft:light[level=12]
setblock 238 259 482 minecraft:light[level=12]
setblock 238 259 490 minecraft:light[level=12]
setblock 238 259 498 minecraft:light[level=12]
setblock 239 259 464 minecraft:bone_block
fill 239 259 465 239 262 465 minecraft:brown_terracotta
setblock 239 259 504 minecraft:bone_block
fill 240 259 464 240 262 464 minecraft:brown_terracotta
setblock 240 259 503 minecraft:bone_block
fill 240 259 504 240 262 504 minecraft:brown_terracotta
setblock 241 259 467 minecraft:bone_block
fill 241 259 503 241 262 503 minecraft:brown_terracotta
setblock 242 259 466 minecraft:bone_block
setblock 242 259 467 minecraft:brown_terracotta
setblock 243 259 465 minecraft:bone_block
fill 243 259 466 243 261 466 minecraft:brown_terracotta
setblock 244 259 464 minecraft:bone_block
fill 244 259 465 244 262 465 minecraft:brown_terracotta
setblock 244 259 504 minecraft:bone_block
fill 245 259 464 245 262 464 minecraft:brown_terracotta
setblock 245 259 503 minecraft:bone_block
fill 245 259 504 248 259 504 minecraft:brown_terracotta
setblock 246 259 466 minecraft:light[level=12]
setblock 246 259 474 minecraft:light[level=12]
setblock 246 259 482 minecraft:light[level=12]
setblock 246 259 490 minecraft:light[level=12]
setblock 246 259 498 minecraft:light[level=12]
fill 246 259 503 247 259 503 minecraft:brown_terracotta
setblock 248 259 465 minecraft:bone_block
setblock 249 259 464 minecraft:bone_block
setblock 249 259 504 minecraft:bone_block
fill 250 259 464 253 259 464 minecraft:brown_terracotta
fill 250 259 504 253 259 504 minecraft:brown_terracotta
setblock 254 259 464 minecraft:bone_block
setblock 254 259 466 minecraft:light[level=12]
setblock 254 259 474 minecraft:light[level=12]
setblock 254 259 482 minecraft:light[level=12]
setblock 254 259 490 minecraft:light[level=12]
setblock 254 259 498 minecraft:light[level=12]
setblock 254 259 504 minecraft:bone_block
fill 255 259 464 255 262 464 minecraft:brown_terracotta
setblock 255 259 503 minecraft:bone_block
fill 255 259 504 255 262 504 minecraft:brown_terracotta
fill 256 259 503 256 260 503 minecraft:brown_terracotta
setblock 258 259 465 minecraft:bone_block
setblock 259 259 464 minecraft:bone_block
fill 259 259 465 259 261 465 minecraft:brown_terracotta
setblock 259 259 504 minecraft:bone_block
fill 260 259 464 260 262 464 minecraft:brown_terracotta
setblock 260 259 503 minecraft:bone_block
fill 260 259 504 260 262 504 minecraft:brown_terracotta
fill 261 259 503 261 260 503 minecraft:brown_terracotta
setblock 262 259 466 minecraft:light[level=12]
setblock 262 259 474 minecraft:light[level=12]
setblock 262 259 482 minecraft:light[level=12]
setblock 262 259 490 minecraft:light[level=12]
setblock 262 259 498 minecraft:light[level=12]
setblock 263 259 465 minecraft:bone_block
setblock 264 259 464 minecraft:bone_block
setblock 264 259 465 minecraft:brown_terracotta
setblock 264 259 504 minecraft:bone_block
fill 265 259 464 267 259 464 minecraft:brown_terracotta
setblock 265 259 504 minecraft:brown_terracotta
setblock 270 259 466 minecraft:light[level=12]
setblock 270 259 474 minecraft:light[level=12]
setblock 270 259 482 minecraft:light[level=12]
setblock 270 259 490 minecraft:light[level=12]
setblock 270 259 498 minecraft:light[level=12]
setblock 274 259 464 minecraft:bone_block
fill 274 259 465 274 262 465 minecraft:brown_terracotta
fill 275 259 464 275 262 464 minecraft:brown_terracotta
setblock 275 259 468 minecraft:bone_block
fill 275 259 469 275 261 470 minecraft:brown_terracotta
setblock 275 259 483 minecraft:bone_block
fill 275 259 484 275 261 484 minecraft:brown_terracotta
setblock 275 259 488 minecraft:bone_block
fill 275 259 489 275 262 489 minecraft:brown_terracotta
setblock 276 259 467 minecraft:bone_block
fill 276 259 468 276 262 468 minecraft:brown_terracotta
setblock 276 259 472 minecraft:bone_block
fill 276 259 473 276 262 473 minecraft:brown_terracotta
setblock 276 259 477 minecraft:bone_block
fill 276 259 478 276 262 478 minecraft:brown_terracotta
setblock 276 259 482 minecraft:bone_block
fill 276 259 483 276 262 483 minecraft:brown_terracotta
setblock 276 259 487 minecraft:bone_block
fill 276 259 488 276 262 488 minecraft:brown_terracotta
setblock 276 259 492 minecraft:bone_block
fill 236 260 464 236 260 465 minecraft:brown_terracotta
setblock 236 260 466 minecraft:bone_block
fill 236 260 467 236 263 467 minecraft:brown_terracotta
setblock 236 260 471 minecraft:bone_block
fill 236 260 472 236 263 472 minecraft:brown_terracotta
setblock 236 260 476 minecraft:bone_block
setblock 236 260 481 minecraft:bone_block
setblock 236 260 482 minecraft:brown_terracotta
setblock 236 260 486 minecraft:bone_block
fill 236 260 487 236 263 487 minecraft:brown_terracotta
setblock 236 260 491 minecraft:bone_block
fill 236 260 502 236 263 502 minecraft:brown_terracotta
setblock 237 260 464 minecraft:brown_terracotta
setblock 237 260 465 minecraft:bone_block
fill 237 260 466 237 263 466 minecraft:brown_terracotta
setblock 237 260 470 minecraft:bone_block
fill 237 260 471 237 263 471 minecraft:brown_terracotta
setblock 237 260 486 minecraft:brown_terracotta
setblock 238 260 464 minecraft:bone_block
fill 238 260 465 238 263 465 minecraft:brown_terracotta
setblock 238 260 468 minecraft:brown_terracotta
setblock 238 260 469 minecraft:bone_block
fill 238 260 470 238 263 470 minecraft:brown_terracotta
setblock 238 260 504 minecraft:bone_block
fill 239 260 464 239 263 464 minecraft:brown_terracotta
setblock 239 260 468 minecraft:bone_block
setblock 239 260 503 minecraft:bone_block
fill 239 260 504 239 263 504 minecraft:brown_terracotta
setblock 240 260 467 minecraft:bone_block
fill 240 260 503 240 263 503 minecraft:brown_terracotta
setblock 241 260 466 minecraft:bone_block
setblock 241 260 467 minecraft:brown_terracotta
setblock 242 260 465 minecraft:bone_block
fill 242 260 466 242 263 466 minecraft:brown_terracotta
setblock 243 260 464 minecraft:bone_block
fill 243 260 465 243 263 465 minecraft:brown_terracotta
setblock 243 260 504 minecraft:bone_block
fill 244 260 464 244 263 464 minecraft:brown_terracotta
setblock 244 260 503 minecraft:bone_block
fill 244 260 504 247 260 504 minecraft:brown_terracotta
setblock 245 260 503 minecraft:brown_terracotta
setblock 247 260 465 minecraft:bone_block
setblock 248 260 464 minecraft:bone_block
setblock 248 260 504 minecraft:bone_block
fill 249 260 464 252 260 464 minecraft:brown_terracotta
fill 249 260 504 252 260 504 minecraft:brown_terracotta
setblock 253 260 464 minecraft:bone_block
setblock 253 260 504 minecraft:bone_block
fill 254 260 464 254 263 464 minecraft:brown_terracotta
fill 254 260 504 254 263 504 minecraft:brown_terracotta
setblock 257 260 465 minecraft:bone_block
setblock 258 260 464 minecraft:bone_block
fill 258 260 465 258 261 465 minecraft:brown_terracotta
setblock 258 260 504 minecraft:bone_block
fill 259 260 464 259 263 464 minecraft:brown_terracotta
setblock 259 260 503 minecraft:bone_block
fill 259 260 504 259 263 504 minecraft:brown_terracotta
setblock 260 260 503 minecraft:brown_terracotta
setblock 262 260 465 minecraft:bone_block
setblock 263 260 464 minecraft:bone_block
setblock 263 260 504 minecraft:bone_block
fill 264 260 464 265 260 464 minecraft:brown_terracotta
setblock 264 260 504 minecraft:brown_terracotta
setblock 273 260 464 minecraft:bone_block
fill 274 260 464 274 263 464 minecraft:brown_terracotta
setblock 275 260 466 minecraft:brown_terracotta
setblock 275 260 467 minecraft:bone_block
fill 275 260 468 275 263 468 minecraft:brown_terracotta
setblock 275 260 471 minecraft:brown_terracotta
setblock 275 260 482 minecraft:bone_block
setblock 275 260 483 minecraft:brown_terracotta
setblock 275 260 487 minecraft:bone_block
fill 275 260 488 275 263 488 minecraft:brown_terracotta
setblock 276 260 466 minecraft:bone_block
fill 276 260 467 276 263 467 minecraft:brown_terracotta
setblock 276 260 471 minecraft:bone_block
fill 276 260 472 276 263 472 minecraft:brown_terracotta
setblock 276 260 476 minecraft:bone_block
fill 276 260 477 276 263 477 minecraft:brown_terracotta
setblock 276 260 481 minecraft:bone_block
fill 276 260 482 276 263 482 minecraft:brown_terracotta
setblock 276 260 486 minecraft:bone_block
fill 276 260 487 276 263 487 minecraft:brown_terracotta
setblock 276 260 491 minecraft:bone_block
fill 276 260 492 276 263 492 minecraft:brown_terracotta
setblock 236 261 464 minecraft:brown_terracotta
setblock 236 261 465 minecraft:bone_block
fill 236 261 466 236 264 466 minecraft:brown_terracotta
setblock 236 261 470 minecraft:bone_block
fill 236 261 471 236 264 471 minecraft:brown_terracotta
setblock 236 261 475 minecraft:bone_block
setblock 236 261 485 minecraft:bone_block
fill 236 261 486 236 264 486 minecraft:brown_terracotta
setblock 236 261 489 minecraft:brown_terracotta
setblock 236 261 490 minecraft:bone_block
fill 236 261 491 236 263 492 minecraft:brown_terracotta
setblock 237 261 464 minecraft:bone_block
fill 237 261 465 237 264 465 minecraft:brown_terracotta
setblock 237 261 469 minecraft:bone_block
fill 237 261 470 237 264 470 minecraft:brown_terracotta
setblock 237 261 504 minecraft:bone_block
fill 238 261 464 238 264 464 minecraft:brown_terracotta
setblock 238 261 468 minecraft:bone_block
fill 238 261 469 238 264 469 minecraft:brown_terracotta
fill 238 261 471 238 262 471 minecraft:brown_terracotta
setblock 238 261 503 minecraft:bone_block
fill 238 261 504 238 264 504 minecraft:brown_terracotta
setblock 239 261 467 minecraft:bone_block
fill 239 261 468 239 262 468 minecraft:brown_terracotta
fill 239 261 503 239 264 503 minecraft:brown_terracotta
setblock 240 261 466 minecraft:bone_block
setblock 240 261 467 minecraft:brown_terracotta
setblock 241 261 465 minecraft:bone_block
fill 241 261 466 241 264 466 minecraft:brown_terracotta
setblock 242 261 464 minecraft:bone_block
fill 242 261 465 242 264 465 minecraft:brown_terracotta
setblock 242 261 504 minecraft:bone_block
fill 243 261 464 243 264 464 minecraft:brown_terracotta
setblock 243 261 503 minecraft:bone_block
fill 243 261 504 246 261 504 minecraft:brown_terracotta
setblock 246 261 465 minecraft:bone_block
setblock 247 261 464 minecraft:bone_block
setblock 247 261 504 minecraft:bone_block
fill 248 261 464 249 261 464 minecraft:brown_terracotta
setblock 248 261 504 minecraft:brown_terracotta
setblock 252 261 504 minecraft:bone_block
setblock 253 261 464 minecraft:brown_terracotta
fill 253 261 504 253 262 504 minecraft:brown_terracotta
setblock 257 261 464 minecraft:bone_block
setblock 257 261 504 minecraft:bone_block
fill 258 261 464 258 264 464 minecraft:brown_terracotta
fill 258 261 504 258 264 504 minecraft:brown_terracotta
setblock 261 261 465 minecraft:bone_block
setblock 262 261 464 minecraft:bone_block
setblock 262 261 504 minecraft:bone_block
fill 263 261 464 264 261 464 minecraft:brown_terracotta
fill 273 261 464 273 264 464 minecraft:brown_terracotta
setblock 275 261 466 minecraft:bone_block
fill 275 261 467 275 264 467 minecraft:brown_terracotta
setblock 275 261 471 minecraft:bone_block
fill 275 261 472 275 264 472 minecraft:brown_terracotta
setblock 275 261 486 minecraft:bone_block
fill 275 261 487 275 264 487 minecraft:brown_terracotta
setblock 276 261 465 minecraft:bone_block
fill 276 261 466 276 264 466 minecraft:brown_terracotta
setblock 276 261 470 minecraft:bone_block
fill 276 261 471 276 264 471 minecraft:brown_terracotta
setblock 276 261 475 minecraft:bone_block
fill 276 261 476 276 264 476 minecraft:brown_terracotta
setblock 276 261 480 minecraft:bone_block
fill 276 261 481 276 264 481 minecraft:brown_terracotta
setblock 276 261 485 minecraft:bone_block
fill 276 261 486 276 264 486 minecraft:brown_terracotta
setblock 276 261 490 minecraft:bone_block
fill 276 261 491 276 264 491 minecraft:brown_terracotta
setblock 236 262 464 minecraft:bone_block
fill 236 262 465 236 265 465 minecraft:brown_terracotta
setblock 236 262 469 minecraft:bone_block
fill 236 262 470 236 265 470 minecraft:brown_terracotta
setblock 236 262 474 minecraft:bone_block
fill 236 262 475 236 264 476 minecraft:brown_terracotta
setblock 236 262 484 minecraft:bone_block
fill 236 262 485 236 265 485 minecraft:brown_terracotta
setblock 236 262 489 minecraft:bone_block
fill 236 262 490 236 265 490 minecraft:brown_terracotta
setblock 236 262 493 minecraft:brown_terracotta
setblock 236 262 504 minecraft:bone_block
fill 237 262 464 237 265 464 minecraft:brown_terracotta
setblock 237 262 468 minecraft:bone_block
fill 237 262 469 237 265 469 minecraft:brown_terracotta
setblock 237 262 473 minecraft:bone_block
fill 237 262 489 237 265 489 minecraft:brown_terracotta
fill 237 262 504 237 265 504 minecraft:brown_terracotta
setblock 238 262 467 minecraft:bone_block
fill 238 262 468 238 265 468 minecraft:brown_terracotta
setblock 238 262 503 minecraft:brown_terracotta
setblock 239 262 466 minecraft:bone_block
fill 239 262 467 239 263 467 minecraft:brown_terracotta
setblock 240 262 465 minecraft:bone_block
fill 240 262 466 240 265 466 minecraft:brown_terracotta
setblock 241 262 464 minecraft:bone_block
fill 241 262 465 241 265 465 minecraft:brown_terracotta
setblock 241 262 504 minecraft:bone_block
fill 242 262 464 242 265 464 minecraft:brown_terracotta
fill 242 262 504 245 262 504 minecraft:brown_terracotta
setblock 246 262 464 minecraft:bone_block
fill 246 262 502 246 264 502 minecraft:soul_soil
setblock 246 262 504 minecraft:bone_block
setblock 247 262 464 minecraft:brown_terracotta
fill 247 262 501 247 264 501 minecraft:soul_soil
fill 247 262 503 247 264 503 minecraft:soul_soil
fill 248 262 502 248 264 502 minecraft:soul_soil
setblock 256 262 464 minecraft:bone_block
setblock 256 262 504 minecraft:bone_block
fill 257 262 464 257 265 464 minecraft:brown_terracotta
fill 257 262 504 257 265 504 minecraft:brown_terracotta
setblock 261 262 464 minecraft:bone_block
setblock 261 262 504 minecraft:bone_block
fill 262 262 464 263 262 464 minecraft:brown_terracotta
setblock 275 262 465 minecraft:bone_block
fill 275 262 466 275 265 466 minecraft:brown_terracotta
setblock 275 262 469 minecraft:brown_terracotta
setblock 275 262 470 minecraft:bone_block
fill 275 262 471 275 265 471 minecraft:brown_terracotta
fill 275 262 473 275 263 473 minecraft:brown_terracotta
setblock 275 262 485 minecraft:bone_block
fill 275 262 486 275 265 486 minecraft:brown_terracotta
setblock 276 262 464 minecraft:bone_block
fill 276 262 465 276 265 465 minecraft:brown_terracotta
setblock 276 262 469 minecraft:bone_block
fill 276 262 470 276 265 470 minecraft:brown_terracotta
setblock 276 262 474 minecraft:bone_block
fill 276 262 475 276 265 475 minecraft:brown_terracotta
setblock 276 262 479 minecraft:bone_block
fill 276 262 480 276 265 480 minecraft:brown_terracotta
setblock 276 262 484 minecraft:bone_block
fill 276 262 485 276 265 485 minecraft:brown_terracotta
setblock 276 262 489 minecraft:bone_block
fill 276 262 490 276 265 490 minecraft:brown_terracotta
setblock 276 262 493 minecraft:brown_terracotta
fill 236 263 464 236 266 464 minecraft:brown_terracotta
setblock 236 263 468 minecraft:bone_block
fill 236 263 469 236 266 469 minecraft:brown_terracotta
setblock 236 263 473 minecraft:bone_block
fill 236 263 474 237 265 474 minecraft:brown_terracotta
setblock 236 263 484 minecraft:brown_terracotta
setblock 236 263 488 minecraft:bone_block
fill 236 263 489 236 266 489 minecraft:brown_terracotta
setblock 236 263 493 minecraft:bone_block
fill 236 263 494 236 265 495 minecraft:brown_terracotta
setblock 236 263 503 minecraft:bone_block
fill 236 263 504 236 266 504 minecraft:brown_terracotta
setblock 237 263 467 minecraft:bone_block
fill 237 263 468 237 266 468 minecraft:brown_terracotta
setblock 237 263 472 minecraft:bone_block
fill 237 263 473 237 266 473 minecraft:brown_terracotta
fill 237 263 488 237 266 488 minecraft:brown_terracotta
fill 237 263 490 237 263 491 minecraft:brown_terracotta
setblock 237 263 492 minecraft:bone_block
setblock 238 263 466 minecraft:bone_block
fill 238 263 467 238 266 467 minecraft:brown_terracotta
setblock 238 263 471 minecraft:bone_block
setblock 239 263 465 minecraft:bone_block
fill 239 263 466 239 266 466 minecraft:brown_terracotta
setblock 240 263 464 minecraft:bone_block
fill 240 263 465 240 266 465 minecraft:brown_terracotta
setblock 240 263 504 minecraft:bone_block
fill 241 263 464 241 266 464 minecraft:brown_terracotta
fill 241 263 504 244 263 504 minecraft:brown_terracotta
setblock 244 263 465 minecraft:bone_block
setblock 245 263 464 minecraft:bone_block
setblock 245 263 504 minecraft:bone_block
setblock 246 263 464 minecraft:brown_terracotta
setblock 255 263 464 minecraft:bone_block
setblock 255 263 504 minecraft:bone_block
fill 256 263 464 256 266 464 minecraft:brown_terracotta
fill 256 263 504 256 266 504 minecraft:brown_terracotta
setblock 260 263 464 minecraft:bone_block
setblock 260 263 504 minecraft:bone_block
setblock 261 263 464 minecraft:brown_terracotta
setblock 274 263 465 minecraft:bone_block
fill 274 263 468 274 263 469 minecraft:brown_terracotta
setblock 275 263 464 minecraft:bone_block
fill 275 263 465 275 266 465 minecraft:brown_terracotta
setblock 275 263 469 minecraft:bone_block
fill 275 263 470 275 266 470 minecraft:brown_terracotta
setblock 275 263 474 minecraft:bone_block
fill 275 263 475 275 266 475 minecraft:brown_terracotta
setblock 275 263 489 minecraft:bone_block
fill 275 263 490 275 266 490 minecraft:brown_terracotta
fill 276 263 464 276 266 464 minecraft:brown_terracotta
setblock 276 263 468 minecraft:bone_block
fill 276 263 469 276 266 469 minecraft:brown_terracotta
setblock 276 263 473 minecraft:bone_block
fill 276 263 474 276 266 474 minecraft:brown_terracotta
setblock 276 263 478 minecraft:bone_block
fill 276 263 479 276 266 479 minecraft:brown_terracotta
setblock 276 263 483 minecraft:bone_block
fill 276 263 484 276 266 484 minecraft:brown_terracotta
setblock 276 263 488 minecraft:bone_block
fill 276 263 489 276 266 489 minecraft:brown_terracotta
setblock 276 263 493 minecraft:bone_block
fill 276 263 494 276 266 494 minecraft:brown_terracotta
setblock 236 264 467 minecraft:bone_block
fill 236 264 468 236 267 468 minecraft:brown_terracotta
setblock 236 264 472 minecraft:bone_block
fill 236 264 473 236 267 473 minecraft:brown_terracotta
setblock 236 264 477 minecraft:bone_block
setblock 236 264 487 minecraft:bone_block
fill 236 264 488 236 267 488 minecraft:brown_terracotta
setblock 236 264 491 minecraft:brown_terracotta
setblock 236 264 492 minecraft:bone_block
fill 236 264 493 237 266 493 minecraft:brown_terracotta
setblock 236 264 496 minecraft:brown_terracotta
setblock 236 264 497 minecraft:bone_block
fill 236 264 498 236 264 501 minecraft:brown_terracotta
setblock 236 264 502 minecraft:bone_block
fill 236 264 503 236 267 503 minecraft:brown_terracotta
setblock 237 264 466 minecraft:bone_block
fill 237 264 467 237 267 467 minecraft:brown_terracotta
setblock 237 264 471 minecraft:bone_block
fill 237 264 472 238 266 472 minecraft:brown_terracotta
setblock 237 264 490 minecraft:brown_terracotta
setblock 237 264 491 minecraft:bone_block
fill 237 264 492 237 267 492 minecraft:brown_terracotta
fill 237 264 494 237 265 494 minecraft:brown_terracotta
setblock 238 264 465 minecraft:bone_block
fill 238 264 466 238 267 466 minecraft:brown_terracotta
setblock 238 264 470 minecraft:bone_block
fill 238 264 471 238 267 471 minecraft:brown_terracotta
fill 238 264 503 238 265 503 minecraft:brown_terracotta
setblock 239 264 464 minecraft:bone_block
fill 239 264 465 239 267 465 minecraft:brown_terracotta
setblock 239 264 504 minecraft:bone_block
fill 240 264 464 240 267 464 minecraft:brown_terracotta
fill 240 264 504 243 264 504 minecraft:brown_terracotta
setblock 243 264 465 minecraft:bone_block
setblock 244 264 464 minecraft:bone_block
setblock 244 264 504 minecraft:bone_block
setblock 245 264 464 minecraft:brown_terracotta
setblock 254 264 464 minecraft:bone_block
setblock 254 264 504 minecraft:bone_block
fill 255 264 464 255 267 464 minecraft:brown_terracotta
fill 255 264 504 255 267 504 minecraft:brown_terracotta
setblock 259 264 464 minecraft:bone_block
setblock 259 264 504 minecraft:bone_block
fill 260 264 464 260 265 464 minecraft:brown_terracotta
fill 272 264 464 272 265 464 minecraft:brown_terracotta
setblock 273 264 465 minecraft:bone_block
setblock 274 264 464 minecraft:bone_block
fill 274 264 465 274 267 465 minecraft:brown_terracotta
fill 274 264 467 274 264 468 minecraft:brown_terracotta
setblock 274 264 469 minecraft:bone_block
fill 274 264 470 274 265 472 minecraft:brown_terracotta
fill 275 264 464 275 267 464 minecraft:brown_terracotta
setblock 275 264 468 minecraft:bone_block
fill 275 264 469 275 267 469 minecraft:brown_terracotta
setblock 275 264 473 minecraft:bone_block
fill 275 264 474 275 267 474 minecraft:brown_terracotta
fill 275 264 476 275 265 476 minecraft:brown_terracotta
setblock 275 264 488 minecraft:bone_block
fill 275 264 489 275 267 489 minecraft:brown_terracotta
fill 275 264 491 275 265 491 minecraft:brown_terracotta
setblock 276 264 467 minecraft:bone_block
fill 276 264 468 276 267 468 minecraft:brown_terracotta
setblock 276 264 472 minecraft:bone_block
fill 276 264 473 276 267 473 minecraft:brown_terracotta
setblock 276 264 477 minecraft:bone_block
fill 276 264 478 276 267 478 minecraft:brown_terracotta
setblock 276 264 482 minecraft:bone_block
fill 276 264 483 276 267 483 minecraft:brown_terracotta
setblock 276 264 487 minecraft:bone_block
fill 276 264 488 276 267 488 minecraft:brown_terracotta
setblock 276 264 492 minecraft:bone_block
fill 276 264 493 276 267 493 minecraft:brown_terracotta
fill 276 264 495 276 265 495 minecraft:brown_terracotta
setblock 236 265 466 minecraft:bone_block
fill 236 265 467 236 268 467 minecraft:brown_terracotta
setblock 236 265 471 minecraft:bone_block
fill 236 265 472 236 268 472 minecraft:brown_terracotta
setblock 236 265 475 minecraft:brown_terracotta
setblock 236 265 476 minecraft:bone_block
fill 236 265 477 236 267 478 minecraft:brown_terracotta
setblock 236 265 486 minecraft:bone_block
fill 236 265 487 236 268 487 minecraft:brown_terracotta
setblock 236 265 491 minecraft:bone_block
fill 236 265 492 236 268 492 minecraft:brown_terracotta
setblock 236 265 496 minecraft:bone_block
fill 236 265 497 236 265 500 minecraft:brown_terracotta
setblock 236 265 501 minecraft:bone_block
fill 236 265 502 236 268 502 minecraft:brown_terracotta
setblock 237 265 465 minecraft:bone_block
fill 237 265 466 237 268 466 minecraft:brown_terracotta
setblock 237 265 470 minecraft:bone_block
fill 237 265 471 237 268 471 minecraft:brown_terracotta
setblock 237 265 475 minecraft:bone_block
setblock 237 265 490 minecraft:bone_block
fill 237 265 491 237 268 491 minecraft:brown_terracotta
setblock 237 265 495 minecraft:bone_block
fill 237 265 496 237 267 497 minecraft:brown_terracotta
fill 237 265 503 237 266 503 minecraft:brown_terracotta
setblock 238 265 464 minecraft:bone_block
fill 238 265 465 238 268 465 minecraft:brown_terracotta
setblock 238 265 469 minecraft:bone_block
fill 238 265 470 238 268 470 minecraft:brown_terracotta
setblock 238 265 504 minecraft:bone_block
fill 239 265 464 239 268 464 minecraft:brown_terracotta
setblock 239 265 503 minecraft:bone_block
fill 239 265 504 242 265 504 minecraft:brown_terracotta
setblock 242 265 465 minecraft:bone_block
setblock 243 265 464 minecraft:bone_block
setblock 243 265 504 minecraft:bone_block
setblock 244 265 464 minecraft:brown_terracotta
setblock 253 265 504 minecraft:bone_block
fill 254 265 464 254 268 464 minecraft:brown_terracotta
fill 254 265 504 254 268 504 minecraft:brown_terracotta
setblock 258 265 464 minecraft:bone_block
setblock 258 265 504 minecraft:bone_block
fill 259 265 464 259 267 464 minecraft:brown_terracotta
setblock 273 265 464 minecraft:bone_block
fill 273 265 465 273 268 465 minecraft:brown_terracotta
fill 274 265 464 274 268 464 minecraft:brown_terracotta
fill 274 265 466 274 265 467 minecraft:brown_terracotta
setblock 274 265 468 minecraft:bone_block
fill 274 265 469 274 268 469 minecraft:brown_terracotta
setblock 274 265 473 minecraft:bone_block
fill 274 265 474 274 268 474 minecraft:brown_terracotta
setblock 275 265 467 minecraft:bone_block
fill 275 265 468 275 268 468 minecraft:brown_terracotta
setblock 275 265 472 minecraft:bone_block
fill 275 265 473 275 268 473 minecraft:brown_terracotta
setblock 275 265 477 minecraft:bone_block
fill 275 265 478 275 268 478 minecraft:brown_terracotta
setblock 275 265 487 minecraft:bone_block
fill 275 265 488 275 268 488 minecraft:brown_terracotta
setblock 275 265 492 minecraft:bone_block
fill 275 265 493 275 268 493 minecraft:brown_terracotta
setblock 276 265 466 minecraft:bone_block
fill 276 265 467 276 268 467 minecraft:brown_terracotta
setblock 276 265 471 minecraft:bone_block
fill 276 265 472 276 268 472 minecraft:brown_terracotta
setblock 276 265 476 minecraft:bone_block
fill 276 265 477 276 268 477 minecraft:brown_terracotta
setblock 276 265 481 minecraft:bone_block
fill 276 265 482 276 268 482 minecraft:brown_terracotta
setblock 276 265 486 minecraft:bone_block
fill 276 265 487 276 268 487 minecraft:brown_terracotta
setblock 276 265 491 minecraft:bone_block
fill 276 265 492 276 268 492 minecraft:brown_terracotta
setblock 276 265 496 minecraft:bone_block
fill 276 265 497 276 268 497 minecraft:brown_terracotta
setblock 236 266 465 minecraft:bone_block
fill 236 266 466 236 269 466 minecraft:brown_terracotta
setblock 236 266 470 minecraft:bone_block
fill 236 266 471 236 269 471 minecraft:brown_terracotta
setblock 236 266 474 minecraft:brown_terracotta
setblock 236 266 475 minecraft:bone_block
fill 236 266 476 237 268 476 minecraft:brown_terracotta
setblock 236 266 479 minecraft:brown_terracotta
setblock 236 266 485 minecraft:bone_block
fill 236 266 486 236 269 486 minecraft:brown_terracotta
setblock 236 266 490 minecraft:bone_block
fill 236 266 491 236 269 491 minecraft:brown_terracotta
setblock 236 266 494 minecraft:brown_terracotta
setblock 236 266 495 minecraft:bone_block
fill 236 266 496 236 266 499 minecraft:brown_terracotta
setblock 236 266 500 minecraft:bone_block
fill 236 266 501 237 268 501 minecraft:brown_terracotta
setblock 237 266 464 minecraft:bone_block
fill 237 266 465 237 269 465 minecraft:brown_terracotta
setblock 237 266 469 minecraft:bone_block
fill 237 266 470 237 269 470 minecraft:brown_terracotta
setblock 237 266 474 minecraft:bone_block
fill 237 266 475 237 269 475 minecraft:brown_terracotta
setblock 237 266 489 minecraft:bone_block
fill 237 266 490 237 269 490 minecraft:brown_terracotta
setblock 237 266 494 minecraft:bone_block
fill 237 266 495 237 269 495 minecraft:brown_terracotta
setblock 237 266 498 minecraft:brown_terracotta
setblock 237 266 499 minecraft:bone_block
fill 237 266 500 237 269 500 minecraft:brown_terracotta
fill 237 266 502 237 267 502 minecraft:brown_terracotta
setblock 237 266 504 minecraft:bone_block
fill 238 266 464 238 269 464 minecraft:brown_terracotta
setblock 238 266 468 minecraft:bone_block
fill 238 266 469 238 269 469 minecraft:brown_terracotta
setblock 238 266 473 minecraft:bone_block
setblock 238 266 492 minecraft:brown_terracotta
setblock 238 266 493 minecraft:bone_block
fill 238 266 494 238 269 494 minecraft:brown_terracotta
setblock 238 266 503 minecraft:bone_block
fill 238 266 504 241 266 504 minecraft:brown_terracotta
fill 239 266 503 239 269 503 minecraft:brown_terracotta
setblock 240 266 466 minecraft:bone_block
setblock 241 266 465 minecraft:bone_block
setblock 242 266 464 minecraft:bone_block
setblock 242 266 465 minecraft:brown_terracotta
setblock 242 266 504 minecraft:bone_block
fill 243 266 464 243 267 464 minecraft:brown_terracotta
fill 243 266 504 243 269 504 minecraft:brown_terracotta
setblock 252 266 504 minecraft:bone_block
fill 253 266 464 253 269 464 minecraft:brown_terracotta
fill 253 266 504 253 269 504 minecraft:brown_terracotta
setblock 257 266 464 minecraft:bone_block
setblock 257 266 504 minecraft:bone_block
fill 258 266 464 258 268 464 minecraft:brown_terracotta
fill 258 266 504 258 269 504 minecraft:brown_terracotta
setblock 271 266 464 minecraft:brown_terracotta
setblock 272 266 464 minecraft:bone_block
fill 272 266 465 272 269 465 minecraft:brown_terracotta
fill 273 266 464 273 269 464 minecraft:brown_terracotta
fill 273 266 470 274 266 471 minecraft:brown_terracotta
setblock 274 266 466 minecraft:brown_terracotta
setblock 274 266 467 minecraft:bone_block
fill 274 266 468 274 269 468 minecraft:brown_terracotta
setblock 274 266 472 minecraft:bone_block
fill 274 266 473 274 269 473 minecraft:brown_terracotta
fill 274 266 475 274 266 476 minecraft:brown_terracotta
setblock 275 266 466 minecraft:bone_block
fill 275 266 467 275 269 467 minecraft:brown_terracotta
setblock 275 266 471 minecraft:bone_block
fill 275 266 472 275 269 472 minecraft:brown_terracotta
setblock 275 266 476 minecraft:bone_block
fill 275 266 477 275 269 477 minecraft:brown_terracotta
fill 275 266 479 275 267 479 minecraft:brown_terracotta
setblock 275 266 486 minecraft:bone_block
fill 275 266 487 275 269 487 minecraft:brown_terracotta
setblock 275 266 491 minecraft:bone_block
fill 275 266 492 275 269 492 minecraft:brown_terracotta
fill 275 266 494 275 266 495 minecraft:brown_terracotta
setblock 276 266 465 minecraft:bone_block
fill 276 266 466 276 269 466 minecraft:brown_terracotta
setblock 276 266 470 minecraft:bone_block
fill 276 266 471 276 269 471 minecraft:brown_terracotta
setblock 276 266 475 minecraft:bone_block
fill 276 266 476 276 269 476 minecraft:brown_terracotta
setblock 276 266 480 minecraft:bone_block
fill 276 266 481 276 269 481 minecraft:brown_terracotta
setblock 276 266 485 minecraft:bone_block
fill 276 266 486 276 269 486 minecraft:brown_terracotta
setblock 276 266 490 minecraft:bone_block
fill 276 266 491 276 269 491 minecraft:brown_terracotta
setblock 276 266 495 minecraft:bone_block
fill 276 266 496 276 269 496 minecraft:brown_terracotta
fill 276 266 498 276 266 499 minecraft:brown_terracotta
fill 276 266 503 276 266 504 minecraft:brown_terracotta
setblock 236 267 464 minecraft:bone_block
fill 236 267 465 236 270 465 minecraft:brown_terracotta
setblock 236 267 469 minecraft:bone_block
fill 236 267 470 236 270 470 minecraft:brown_terracotta
setblock 236 267 474 minecraft:bone_block
fill 236 267 475 236 270 475 minecraft:brown_terracotta
setblock 236 267 479 minecraft:bone_block
fill 236 267 480 236 270 480 minecraft:brown_terracotta
setblock 236 267 484 minecraft:bone_block
fill 236 267 485 236 269 485 minecraft:brown_terracotta
setblock 236 267 489 minecraft:bone_block
fill 236 267 490 236 270 490 minecraft:brown_terracotta
setblock 236 267 493 minecraft:brown_terracotta
setblock 236 267 494 minecraft:bone_block
fill 236 267 495 236 267 498 minecraft:brown_terracotta
setblock 236 267 499 minecraft:bone_block
fill 236 267 500 236 270 500 minecraft:brown_terracotta
setblock 236 267 504 minecraft:bone_block
fill 237 267 464 237 270 464 minecraft:brown_terracotta
setblock 237 267 468 minecraft:bone_block
fill 237 267 469 237 270 469 minecraft:brown_terracotta
setblock 237 267 472 minecraft:brown_terracotta
setblock 237 267 473 minecraft:bone_block
fill 237 267 474 238 269 474 minecraft:brown_terracotta
setblock 237 267 488 minecraft:bone_block
fill 237 267 489 237 270 489 minecraft:brown_terracotta
setblock 237 267 493 minecraft:bone_block
fill 237 267 494 237 270 494 minecraft:brown_terracotta
setblock 237 267 498 minecraft:bone_block
fill 237 267 499 237 270 499 minecraft:brown_terracotta
setblock 237 267 503 minecraft:bone_block
fill 237 267 504 240 267 504 minecraft:brown_terracotta
setblock 238 267 467 minecraft:bone_block
fill 238 267 468 238 269 468 minecraft:brown_terracotta
setblock 238 267 472 minecraft:bone_block
fill 238 267 473 238 270 473 minecraft:brown_terracotta
setblock 238 267 482 minecraft:light[level=12]
setblock 238 267 490 minecraft:light[level=12]
setblock 238 267 491 minecraft:brown_terracotta
setblock 238 267 492 minecraft:bone_block
fill 238 267 493 238 270 493 minecraft:brown_terracotta
fill 238 267 495 238 267 496 minecraft:brown_terracotta
setblock 238 267 497 minecraft:bone_block
setblock 238 267 498 minecraft:light[level=12]
fill 238 267 503 238 270 503 minecraft:brown_terracotta
setblock 239 267 466 minecraft:bone_block
setblock 240 267 465 minecraft:bone_block
fill 240 267 503 240 268 503 minecraft:brown_terracotta
setblock 241 267 464 minecraft:bone_block
setblock 241 267 465 minecraft:brown_terracotta
setblock 241 267 504 minecraft:bone_block
fill 242 267 464 242 269 464 minecraft:brown_terracotta
fill 242 267 504 242 270 504 minecraft:brown_terracotta
setblock 246 267 466 minecraft:light[level=12]
setblock 246 267 474 minecraft:light[level=12]
setblock 246 267 482 minecraft:light[level=12]
setblock 246 267 490 minecraft:light[level=12]
setblock 246 267 498 minecraft:light[level=12]
setblock 251 267 504 minecraft:bone_block
fill 252 267 504 252 270 504 minecraft:brown_terracotta
setblock 254 267 466 minecraft:light[level=12]
setblock 254 267 474 minecraft:light[level=12]
setblock 254 267 482 minecraft:light[level=12]
setblock 254 267 490 minecraft:light[level=12]
setblock 254 267 498 minecraft:light[level=12]
setblock 256 267 464 minecraft:bone_block
setblock 256 267 504 minecraft:bone_block
fill 257 267 464 257 269 464 minecraft:brown_terracotta
fill 257 267 504 257 270 504 minecraft:brown_terracotta
setblock 262 267 466 minecraft:light[level=12]
setblock 262 267 474 minecraft:light[level=12]
setblock 262 267 482 minecraft:light[level=12]
setblock 262 267 490 minecraft:light[level=12]
setblock 262 267 498 minecraft:light[level=12]
setblock 270 267 466 minecraft:light[level=12]
setblock 270 267 474 minecraft:light[level=12]
setblock 270 267 482 minecraft:light[level=12]
setblock 270 267 490 minecraft:light[level=12]
setblock 270 267 498 minecraft:light[level=12]
setblock 271 267 464 minecraft:bone_block
fill 272 267 464 272 270 464 minecraft:brown_terracotta
setblock 273 267 466 minecraft:brown_terracotta
fill 273 267 468 273 267 471 minecraft:brown_terracotta
setblock 273 267 472 minecraft:bone_block
fill 273 267 473 273 269 474 minecraft:brown_terracotta
setblock 274 267 466 minecraft:bone_block
fill 274 267 467 274 270 467 minecraft:brown_terracotta
setblock 274 267 470 minecraft:brown_terracotta
setblock 274 267 471 minecraft:bone_block
fill 274 267 472 274 270 472 minecraft:brown_terracotta
setblock 274 267 475 minecraft:brown_terracotta
setblock 274 267 476 minecraft:bone_block
fill 274 267 477 274 270 477 minecraft:brown_terracotta
setblock 275 267 465 minecraft:bone_block
fill 275 267 466 275 270 466 minecraft:brown_terracotta
setblock 275 267 470 minecraft:bone_block
fill 275 267 471 275 270 471 minecraft:brown_terracotta
setblock 275 267 475 minecraft:bone_block
fill 275 267 476 275 270 476 minecraft:brown_terracotta
setblock 275 267 480 minecraft:bone_block
fill 275 267 481 275 270 481 minecraft:brown_terracotta
fill 275 267 486 275 268 486 minecraft:brown_terracotta
setblock 275 267 490 minecraft:bone_block
fill 275 267 491 275 270 491 minecraft:brown_terracotta
setblock 275 267 494 minecraft:brown_terracotta
setblock 275 267 495 minecraft:bone_block
fill 275 267 496 275 270 496 minecraft:brown_terracotta
setblock 275 267 504 minecraft:brown_terracotta
setblock 276 267 464 minecraft:bone_block
fill 276 267 465 276 270 465 minecraft:brown_terracotta
setblock 276 267 469 minecraft:bone_block
fill 276 267 470 276 270 470 minecraft:brown_terracotta
setblock 276 267 474 minecraft:bone_block
fill 276 267 475 276 270 475 minecraft:brown_terracotta
setblock 276 267 479 minecraft:bone_block
fill 276 267 480 276 270 480 minecraft:brown_terracotta
setblock 276 267 484 minecraft:bone_block
fill 276 267 485 276 270 485 minecraft:brown_terracotta
setblock 276 267 489 minecraft:bone_block
fill 276 267 490 276 270 490 minecraft:brown_terracotta
setblock 276 267 494 minecraft:bone_block
fill 276 267 495 276 270 495 minecraft:brown_terracotta
setblock 276 267 498 minecraft:brown_terracotta
setblock 276 267 499 minecraft:bone_block
fill 276 267 500 276 267 503 minecraft:brown_terracotta
setblock 276 267 504 minecraft:bone_block
fill 236 268 464 236 271 464 minecraft:brown_terracotta
setblock 236 268 468 minecraft:bone_block
fill 236 268 469 236 271 469 minecraft:brown_terracotta
setblock 236 268 473 minecraft:bone_block
fill 236 268 474 236 271 474 minecraft:brown_terracotta
setblock 236 268 477 minecraft:brown_terracotta
setblock 236 268 478 minecraft:bone_block
fill 236 268 479 236 271 479 minecraft:brown_terracotta
fill 236 268 481 236 269 481 minecraft:brown_terracotta
fill 236 268 484 236 269 484 minecraft:brown_terracotta
setblock 236 268 488 minecraft:bone_block
fill 236 268 489 236 271 489 minecraft:brown_terracotta
setblock 236 268 493 minecraft:bone_block
fill 236 268 494 236 268 497 minecraft:brown_terracotta
setblock 236 268 498 minecraft:bone_block
fill 236 268 499 236 271 499 minecraft:brown_terracotta
setblock 236 268 503 minecraft:bone_block
fill 236 268 504 239 268 504 minecraft:brown_terracotta
setblock 237 268 467 minecraft:bone_block
fill 237 268 468 237 271 468 minecraft:brown_terracotta
setblock 237 268 472 minecraft:bone_block
fill 237 268 473 237 271 473 minecraft:brown_terracotta
setblock 237 268 477 minecraft:bone_block
setblock 237 268 488 minecraft:brown_terracotta
setblock 237 268 492 minecraft:bone_block
fill 237 268 493 237 271 493 minecraft:brown_terracotta
setblock 237 268 496 minecraft:brown_terracotta
setblock 237 268 497 minecraft:bone_block
fill 237 268 498 238 270 498 minecraft:brown_terracotta
setblock 237 268 502 minecraft:bone_block
fill 237 268 503 237 271 503 minecraft:brown_terracotta
setblock 238 268 466 minecraft:bone_block
fill 238 268 467 238 269 467 minecraft:brown_terracotta
setblock 238 268 471 minecraft:bone_block
fill 238 268 472 238 270 472 minecraft:brown_terracotta
setblock 238 268 491 minecraft:bone_block
fill 238 268 492 238 270 492 minecraft:brown_terracotta
setblock 238 268 495 minecraft:brown_terracotta
setblock 238 268 496 minecraft:bone_block
fill 238 268 497 238 271 497 minecraft:brown_terracotta
fill 238 268 499 238 269 499 minecraft:brown_terracotta
setblock 239 268 465 minecraft:bone_block
setblock 239 268 466 minecraft:brown_terracotta
setblock 240 268 464 minecraft:bone_block
fill 240 268 465 240 269 465 minecraft:brown_terracotta
setblock 240 268 504 minecraft:bone_block
fill 241 268 464 241 270 464 minecraft:brown_terracotta
fill 241 268 504 241 271 504 minecraft:brown_terracotta
setblock 250 268 504 minecraft:bone_block
fill 251 268 504 251 271 504 minecraft:brown_terracotta
fill 252 268 464 252 270 464 minecraft:brown_terracotta
setblock 255 268 464 minecraft:bone_block
setblock 255 268 504 minecraft:bone_block
fill 256 268 464 256 270 464 minecraft:brown_terracotta
fill 256 268 504 256 271 504 minecraft:brown_terracotta
setblock 270 268 464 minecraft:bone_block
fill 271 268 464 271 270 465 minecraft:brown_terracotta
setblock 272 268 466 minecraft:brown_terracotta
setblock 273 268 466 minecraft:bone_block
fill 273 268 468 273 268 470 minecraft:brown_terracotta
setblock 273 268 471 minecraft:bone_block
fill 273 268 472 273 271 472 minecraft:brown_terracotta
setblock 273 268 475 minecraft:brown_terracotta
setblock 274 268 465 minecraft:bone_block
fill 274 268 466 274 271 466 minecraft:brown_terracotta
setblock 274 268 470 minecraft:bone_block
fill 274 268 471 274 271 471 minecraft:brown_terracotta
setblock 274 268 475 minecraft:bone_block
fill 274 268 476 274 271 476 minecraft:brown_terracotta
fill 274 268 478 274 269 478 minecraft:brown_terracotta
setblock 274 268 504 minecraft:brown_terracotta
setblock 275 268 464 minecraft:bone_block
fill 275 268 465 275 271 465 minecraft:brown_terracotta
setblock 275 268 469 minecraft:bone_block
fill 275 268 470 275 271 470 minecraft:brown_terracotta
setblock 275 268 474 minecraft:bone_block
fill 275 268 475 275 271 475 minecraft:brown_terracotta
setblock 275 268 479 minecraft:bone_block
fill 275 268 480 275 271 480 minecraft:brown_terracotta
fill 275 268 482 275 269 482 minecraft:brown_terracotta
setblock 275 268 489 minecraft:bone_block
fill 275 268 490 275 271 490 minecraft:brown_terracotta
setblock 275 268 494 minecraft:bone_block
fill 275 268 495 275 271 495 minecraft:brown_terracotta
fill 275 268 497 275 268 498 minecraft:brown_terracotta
setblock 275 268 499 minecraft:bone_block
setblock 275 268 504 minecraft:bone_block
fill 276 268 464 276 271 464 minecraft:brown_terracotta
setblock 276 268 468 minecraft:bone_block
fill 276 268 469 276 271 469 minecraft:brown_terracotta
setblock 276 268 473 minecraft:bone_block
fill 276 268 474 276 271 474 minecraft:brown_terracotta
setblock 276 268 478 minecraft:bone_block
fill 276 268 479 276 271 479 minecraft:brown_terracotta
setblock 276 268 483 minecraft:bone_block
fill 276 268 484 276 271 484 minecraft:brown_terracotta
setblock 276 268 488 minecraft:bone_block
fill 276 268 489 276 271 489 minecraft:brown_terracotta
setblock 276 268 493 minecraft:bone_block
fill 276 268 494 276 271 494 minecraft:brown_terracotta
setblock 276 268 498 minecraft:bone_block
fill 276 268 499 276 268 502 minecraft:brown_terracotta
setblock 276 268 503 minecraft:bone_block
fill 276 268 504 276 271 504 minecraft:brown_terracotta
setblock 236 269 467 minecraft:bone_block
fill 236 269 468 236 272 468 minecraft:brown_terracotta
setblock 236 269 472 minecraft:bone_block
fill 236 269 473 236 272 473 minecraft:brown_terracotta
setblock 236 269 476 minecraft:brown_terracotta
setblock 236 269 477 minecraft:bone_block
fill 236 269 478 237 271 478 minecraft:brown_terracotta
setblock 236 269 482 minecraft:bone_block
setblock 236 269 487 minecraft:bone_block
fill 236 269 488 236 272 488 minecraft:brown_terracotta
setblock 236 269 492 minecraft:bone_block
fill 236 269 493 236 269 496 minecraft:brown_terracotta
setblock 236 269 497 minecraft:bone_block
fill 236 269 498 236 272 498 minecraft:brown_terracotta
setblock 236 269 501 minecraft:brown_terracotta
setblock 236 269 502 minecraft:bone_block
fill 236 269 503 236 271 504 minecraft:brown_terracotta
setblock 237 269 466 minecraft:bone_block
fill 237 269 467 237 272 467 minecraft:brown_terracotta
setblock 237 269 471 minecraft:bone_block
fill 237 269 472 237 272 472 minecraft:brown_terracotta
setblock 237 269 476 minecraft:bone_block
fill 237 269 477 237 272 477 minecraft:brown_terracotta
setblock 237 269 491 minecraft:bone_block
fill 237 269 492 237 272 492 minecraft:brown_terracotta
setblock 237 269 496 minecraft:bone_block
fill 237 269 497 237 272 497 minecraft:brown_terracotta
setblock 237 269 501 minecraft:bone_block
fill 237 269 502 237 272 502 minecraft:brown_terracotta
fill 237 269 504 238 269 504 minecraft:brown_terracotta
setblock 238 269 465 minecraft:bone_block
setblock 238 269 466 minecraft:brown_terracotta
setblock 238 269 470 minecraft:bone_block
fill 238 269 471 238 270 471 minecraft:brown_terracotta
setblock 238 269 491 minecraft:brown_terracotta
setblock 238 269 495 minecraft:bone_block
fill 238 269 496 238 272 496 minecraft:brown_terracotta
setblock 238 269 500 minecraft:bone_block
fill 238 269 501 238 272 501 minecraft:brown_terracotta
setblock 239 269 464 minecraft:bone_block
fill 239 269 465 239 270 465 minecraft:brown_terracotta
setblock 239 269 504 minecraft:bone_block
fill 240 269 464 240 271 464 minecraft:brown_terracotta
setblock 240 269 503 minecraft:bone_block
fill 240 269 504 240 272 504 minecraft:brown_terracotta
setblock 248 269 504 minecraft:brown_terracotta
setblock 249 269 504 minecraft:bone_block
fill 250 269 504 250 272 504 minecraft:brown_terracotta
fill 252 269 503 254 269 503 minecraft:brown_terracotta
setblock 254 269 464 minecraft:bone_block
setblock 254 269 504 minecraft:bone_block
fill 255 269 464 255 270 464 minecraft:brown_terracotta
setblock 255 269 503 minecraft:bone_block
fill 255 269 504 255 272 504 minecraft:brown_terracotta
fill 261 269 500 261 270 502 minecraft:bone_block
fill 262 269 501 262 270 502 minecraft:bone_block
fill 270 269 464 270 272 464 minecraft:brown_terracotta
setblock 272 269 466 minecraft:bone_block
setblock 273 269 465 minecraft:bone_block
fill 273 269 466 273 272 466 minecraft:brown_terracotta
fill 273 269 468 273 269 469 minecraft:brown_terracotta
setblock 273 269 470 minecraft:bone_block
fill 273 269 471 273 272 471 minecraft:brown_terracotta
setblock 273 269 475 minecraft:bone_block
fill 273 269 476 273 272 476 minecraft:brown_terracotta
setblock 273 269 504 minecraft:brown_terracotta
setblock 274 269 464 minecraft:bone_block
fill 274 269 465 274 272 465 minecraft:brown_terracotta
setblock 274 269 469 minecraft:bone_block
fill 274 269 470 274 272 470 minecraft:brown_terracotta
setblock 274 269 474 minecraft:bone_block
fill 274 269 475 274 272 475 minecraft:brown_terracotta
setblock 274 269 479 minecraft:bone_block
fill 274 269 492 274 269 493 minecraft:brown_terracotta
setblock 274 269 494 minecraft:bone_block
fill 274 269 495 274 272 495 minecraft:brown_terracotta
setblock 274 269 504 minecraft:bone_block
fill 275 269 464 275 272 464 minecraft:brown_terracotta
setblock 275 269 468 minecraft:bone_block
fill 275 269 469 275 272 469 minecraft:brown_terracotta
setblock 275 269 473 minecraft:bone_block
fill 275 269 474 275 272 474 minecraft:brown_terracotta
setblock 275 269 478 minecraft:bone_block
fill 275 269 479 275 272 479 minecraft:brown_terracotta
setblock 275 269 488 minecraft:bone_block
fill 275 269 489 275 270 489 minecraft:brown_terracotta
setblock 275 269 493 minecraft:bone_block
fill 275 269 494 275 272 494 minecraft:brown_terracotta
setblock 275 269 497 minecraft:brown_terracotta
setblock 275 269 498 minecraft:bone_block
fill 275 269 499 276 269 501 minecraft:brown_terracotta
fill 275 269 504 275 272 504 minecraft:brown_terracotta
setblock 276 269 467 minecraft:bone_block
fill 276 269 468 276 272 468 minecraft:brown_terracotta
setblock 276 269 472 minecraft:bone_block
fill 276 269 473 276 272 473 minecraft:brown_terracotta
setblock 276 269 477 minecraft:bone_block
fill 276 269 478 276 272 478 minecraft:brown_terracotta
setblock 276 269 482 minecraft:bone_block
fill 276 269 483 276 272 483 minecraft:brown_terracotta
setblock 276 269 487 minecraft:bone_block
fill 276 269 488 276 271 488 minecraft:brown_terracotta
setblock 276 269 492 minecraft:bone_block
fill 276 269 493 276 272 493 minecraft:brown_terracotta
setblock 276 269 497 minecraft:bone_block
fill 276 269 498 276 272 498 minecraft:brown_terracotta
setblock 276 269 502 minecraft:bone_block
fill 276 269 503 276 272 503 minecraft:brown_terracotta
setblock 236 270 466 minecraft:bone_block
fill 236 270 467 236 273 467 minecraft:brown_terracotta
setblock 236 270 471 minecraft:bone_block
fill 236 270 472 236 273 472 minecraft:brown_terracotta
setblock 236 270 476 minecraft:bone_block
fill 236 270 477 236 273 477 minecraft:brown_terracotta
setblock 236 270 481 minecraft:bone_block
setblock 236 270 482 minecraft:brown_terracotta
setblock 236 270 486 minecraft:bone_block
fill 236 270 487 236 271 487 minecraft:brown_terracotta
setblock 236 270 491 minecraft:bone_block
fill 236 270 492 236 270 495 minecraft:brown_terracotta
setblock 236 270 496 minecraft:bone_block
fill 236 270 497 236 273 497 minecraft:brown_terracotta
setblock 236 270 501 minecraft:bone_block
fill 236 270 502 236 273 502 minecraft:brown_terracotta
setblock 237 270 465 minecraft:bone_block
fill 237 270 466 237 271 466 minecraft:brown_terracotta
setblock 237 270 470 minecraft:bone_block
fill 237 270 471 237 272 471 minecraft:brown_terracotta
setblock 237 270 474 minecraft:brown_terracotta
setblock 237 270 475 minecraft:bone_block
fill 237 270 476 237 273 476 minecraft:brown_terracotta
setblock 237 270 490 minecraft:bone_block
fill 237 270 491 237 272 491 minecraft:brown_terracotta
setblock 237 270 495 minecraft:bone_block
fill 237 270 496 237 273 496 minecraft:brown_terracotta
setblock 237 270 500 minecraft:bone_block
fill 237 270 501 237 273 501 minecraft:brown_terracotta
setblock 237 270 504 minecraft:brown_terracotta
setblock 238 270 464 minecraft:bone_block
setblock 238 270 465 minecraft:brown_terracotta
setblock 238 270 469 minecraft:bone_block
setblock 238 270 470 minecraft:brown_terracotta
setblock 238 270 474 minecraft:bone_block
setblock 238 270 494 minecraft:bone_block
fill 238 270 495 238 273 495 minecraft:brown_terracotta
setblock 238 270 499 minecraft:bone_block
fill 238 270 500 238 273 500 minecraft:brown_terracotta
setblock 238 270 504 minecraft:bone_block
fill 239 270 464 239 272 464 minecraft:brown_terracotta
setblock 239 270 503 minecraft:bone_block
fill 239 270 504 239 273 504 minecraft:brown_terracotta
fill 240 270 503 240 271 503 minecraft:brown_terracotta
setblock 243 270 504 minecraft:bone_block
setblock 247 270 504 minecraft:brown_terracotta
setblock 248 270 504 minecraft:bone_block
fill 249 270 504 249 273 504 minecraft:brown_terracotta
fill 251 270 503 253 270 503 minecraft:brown_terracotta
setblock 253 270 464 minecraft:bone_block
setblock 253 270 504 minecraft:bone_block
fill 254 270 464 254 271 464 minecraft:brown_terracotta
setblock 254 270 503 minecraft:bone_block
fill 254 270 504 254 273 504 minecraft:brown_terracotta
fill 255 270 503 255 271 503 minecraft:brown_terracotta
fill 269 270 464 269 273 464 minecraft:brown_terracotta
setblock 272 270 465 minecraft:bone_block
fill 272 270 466 272 271 466 minecraft:brown_terracotta
fill 272 270 472 272 270 473 minecraft:brown_terracotta
setblock 272 270 504 minecraft:brown_terracotta
setblock 273 270 464 minecraft:bone_block
fill 273 270 465 273 273 465 minecraft:brown_terracotta
setblock 273 270 468 minecraft:brown_terracotta
setblock 273 270 469 minecraft:bone_block
fill 273 270 470 273 272 470 minecraft:brown_terracotta
setblock 273 270 473 minecraft:brown_terracotta
setblock 273 270 474 minecraft:bone_block
fill 273 270 475 273 273 475 minecraft:brown_terracotta
fill 273 270 477 273 271 477 minecraft:brown_terracotta
setblock 273 270 504 minecraft:bone_block
fill 274 270 464 274 273 464 minecraft:brown_terracotta
setblock 274 270 468 minecraft:bone_block
fill 274 270 469 274 273 469 minecraft:brown_terracotta
setblock 274 270 473 minecraft:bone_block
fill 274 270 474 274 273 474 minecraft:brown_terracotta
setblock 274 270 478 minecraft:bone_block
fill 274 270 479 274 273 479 minecraft:brown_terracotta
setblock 274 270 493 minecraft:bone_block
fill 274 270 494 274 271 494 minecraft:brown_terracotta
fill 274 270 496 274 270 497 minecraft:brown_terracotta
fill 274 270 504 274 273 504 minecraft:brown_terracotta
setblock 275 270 467 minecraft:bone_block
fill 275 270 468 275 273 468 minecraft:brown_terracotta
setblock 275 270 472 minecraft:bone_block
fill 275 270 473 275 273 473 minecraft:brown_terracotta
setblock 275 270 477 minecraft:bone_block
fill 275 270 478 275 273 478 minecraft:brown_terracotta
setblock 275 270 482 minecraft:bone_block
setblock 275 270 488 minecraft:brown_terracotta
setblock 275 270 492 minecraft:bone_block
fill 275 270 493 275 273 493 minecraft:brown_terracotta
setblock 275 270 497 minecraft:bone_block
fill 275 270 498 275 270 501 minecraft:brown_terracotta
setblock 275 270 502 minecraft:bone_block
fill 275 270 503 275 273 503 minecraft:brown_terracotta
setblock 276 270 466 minecraft:bone_block
fill 276 270 467 276 273 467 minecraft:brown_terracotta
setblock 276 270 471 minecraft:bone_block
fill 276 270 472 276 273 472 minecraft:brown_terracotta
setblock 276 270 476 minecraft:bone_block
fill 276 270 477 276 273 477 minecraft:brown_terracotta
setblock 276 270 481 minecraft:bone_block
fill 276 270 482 276 273 482 minecraft:brown_terracotta
setblock 276 270 486 minecraft:bone_block
fill 276 270 487 276 271 487 minecraft:brown_terracotta
setblock 276 270 491 minecraft:bone_block
fill 276 270 492 276 273 492 minecraft:brown_terracotta
setblock 276 270 496 minecraft:bone_block
fill 276 270 497 276 273 497 minecraft:brown_terracotta
fill 276 270 499 276 270 500 minecraft:brown_terracotta
setblock 276 270 501 minecraft:bone_block
fill 276 270 502 276 273 502 minecraft:brown_terracotta
setblock 236 271 465 minecraft:bone_block
fill 236 271 466 236 273 466 minecraft:brown_terracotta
setblock 236 271 470 minecraft:bone_block
fill 236 271 471 236 273 471 minecraft:brown_terracotta
setblock 236 271 475 minecraft:bone_block
fill 236 271 476 236 273 476 minecraft:brown_terracotta
setblock 236 271 480 minecraft:bone_block
fill 236 271 481 236 272 481 minecraft:brown_terracotta
setblock 236 271 490 minecraft:bone_block
fill 236 271 491 236 271 494 minecraft:brown_terracotta
setblock 236 271 495 minecraft:bone_block
fill 236 271 496 236 273 496 minecraft:brown_terracotta
setblock 236 271 500 minecraft:bone_block
fill 236 271 501 236 273 501 minecraft:brown_terracotta
setblock 237 271 464 minecraft:bone_block
setblock 237 271 465 minecraft:brown_terracotta
setblock 237 271 469 minecraft:bone_block
fill 237 271 470 237 272 470 minecraft:brown_terracotta
setblock 237 271 474 minecraft:bone_block
fill 237 271 475 237 273 475 minecraft:brown_terracotta
setblock 237 271 490 minecraft:brown_terracotta
setblock 237 271 494 minecraft:bone_block
fill 237 271 495 237 273 495 minecraft:brown_terracotta
setblock 237 271 498 minecraft:brown_terracotta
setblock 237 271 499 minecraft:bone_block
fill 237 271 500 237 273 500 minecraft:brown_terracotta
setblock 237 271 504 minecraft:bone_block
fill 238 271 464 238 272 464 minecraft:brown_terracotta
setblock 238 271 493 minecraft:bone_block
fill 238 271 494 238 272 494 minecraft:brown_terracotta
setblock 238 271 498 minecraft:bone_block
fill 238 271 499 238 273 499 minecraft:brown_terracotta
setblock 238 271 503 minecraft:bone_block
fill 238 271 504 238 273 504 minecraft:brown_terracotta
fill 239 271 503 239 273 503 minecraft:brown_terracotta
setblock 242 271 504 minecraft:bone_block
setblock 243 271 504 minecraft:brown_terracotta
setblock 247 271 504 minecraft:bone_block
fill 248 271 504 248 273 504 minecraft:brown_terracotta
fill 250 271 503 252 271 503 minecraft:brown_terracotta
setblock 252 271 504 minecraft:bone_block
setblock 253 271 464 minecraft:brown_terracotta
setblock 253 271 503 minecraft:bone_block
fill 253 271 504 253 273 504 minecraft:brown_terracotta
fill 254 271 503 254 273 503 minecraft:brown_terracotta
setblock 257 271 504 minecraft:bone_block
setblock 271 271 464 minecraft:brown_terracotta
setblock 271 271 465 minecraft:bone_block
setblock 271 271 504 minecraft:brown_terracotta
setblock 272 271 464 minecraft:bone_block
fill 272 271 465 272 273 465 minecraft:brown_terracotta
setblock 272 271 473 minecraft:brown_terracotta
setblock 272 271 474 minecraft:bone_block
schedule function dropper:buildpart/113_9 1t
