fill 539 207 270 539 209 270 minecraft:purple_terracotta
fill 543 207 228 543 209 228 minecraft:purple_terracotta
fill 543 207 270 543 209 270 minecraft:purple_terracotta
fill 547 207 228 547 209 228 minecraft:purple_terracotta
fill 547 207 270 547 209 270 minecraft:purple_terracotta
fill 551 207 228 551 209 228 minecraft:purple_terracotta
fill 551 207 270 551 209 270 minecraft:purple_terracotta
fill 555 207 228 555 209 228 minecraft:purple_terracotta
fill 555 207 270 555 209 270 minecraft:purple_terracotta
setblock 559 207 228 minecraft:purple_terracotta
fill 559 207 230 559 209 230 minecraft:purple_terracotta
fill 559 207 234 559 209 234 minecraft:purple_terracotta
fill 559 207 238 559 209 238 minecraft:purple_terracotta
fill 559 207 242 559 209 242 minecraft:purple_terracotta
fill 559 207 246 559 209 246 minecraft:purple_terracotta
fill 559 207 250 559 209 250 minecraft:purple_terracotta
fill 559 207 254 559 209 254 minecraft:purple_terracotta
setblock 559 207 256 minecraft:purple_terracotta
fill 559 207 258 559 209 258 minecraft:purple_terracotta
fill 559 207 262 559 209 262 minecraft:purple_terracotta
fill 559 207 266 559 209 266 minecraft:purple_terracotta
fill 559 207 270 559 209 270 minecraft:purple_terracotta
setblock 517 208 228 minecraft:magenta_terracotta
setblock 517 208 232 minecraft:magenta_terracotta
setblock 517 208 236 minecraft:magenta_terracotta
setblock 517 208 240 minecraft:magenta_terracotta
setblock 517 208 244 minecraft:magenta_terracotta
setblock 517 208 248 minecraft:magenta_terracotta
setblock 517 208 252 minecraft:magenta_terracotta
setblock 517 208 256 minecraft:magenta_terracotta
setblock 517 208 260 minecraft:magenta_terracotta
setblock 517 208 264 minecraft:magenta_terracotta
setblock 517 208 268 minecraft:magenta_terracotta
setblock 517 208 270 minecraft:magenta_terracotta
fill 518 208 246 519 208 247 minecraft:dark_oak_planks
fill 519 208 248 519 208 249 minecraft:spruce_planks
setblock 520 208 231 minecraft:light[level=11]
setblock 520 208 238 minecraft:light[level=12]
setblock 520 208 239 minecraft:light[level=11]
setblock 520 208 245 minecraft:light[level=12]
setblock 520 208 247 minecraft:light[level=11]
setblock 520 208 252 minecraft:light[level=12]
setblock 520 208 255 minecraft:light[level=11]
setblock 520 208 259 minecraft:light[level=12]
setblock 520 208 263 minecraft:light[level=11]
setblock 520 208 266 minecraft:light[level=12]
setblock 521 208 228 minecraft:magenta_terracotta
setblock 521 208 270 minecraft:magenta_terracotta
setblock 525 208 228 minecraft:magenta_terracotta
setblock 525 208 270 minecraft:magenta_terracotta
setblock 527 208 231 minecraft:light[level=12]
setblock 527 208 238 minecraft:light[level=12]
setblock 527 208 245 minecraft:light[level=12]
setblock 527 208 252 minecraft:light[level=12]
setblock 527 208 259 minecraft:light[level=12]
setblock 527 208 266 minecraft:light[level=12]
setblock 528 208 231 minecraft:light[level=11]
setblock 528 208 239 minecraft:light[level=11]
setblock 528 208 247 minecraft:light[level=11]
setblock 528 208 255 minecraft:light[level=11]
setblock 528 208 263 minecraft:light[level=11]
setblock 529 208 228 minecraft:magenta_terracotta
setblock 529 208 270 minecraft:magenta_terracotta
setblock 533 208 228 minecraft:magenta_terracotta
setblock 533 208 270 minecraft:magenta_terracotta
setblock 534 208 231 minecraft:light[level=12]
setblock 534 208 238 minecraft:light[level=12]
setblock 534 208 245 minecraft:light[level=12]
setblock 534 208 252 minecraft:light[level=12]
setblock 534 208 259 minecraft:light[level=12]
setblock 534 208 266 minecraft:light[level=12]
setblock 536 208 231 minecraft:light[level=11]
setblock 536 208 239 minecraft:light[level=11]
setblock 536 208 247 minecraft:light[level=11]
setblock 536 208 255 minecraft:light[level=11]
setblock 536 208 263 minecraft:light[level=11]
setblock 537 208 228 minecraft:magenta_terracotta
setblock 537 208 270 minecraft:magenta_terracotta
setblock 541 208 228 minecraft:magenta_terracotta
setblock 541 208 231 minecraft:light[level=12]
setblock 541 208 238 minecraft:light[level=12]
setblock 541 208 245 minecraft:light[level=12]
setblock 541 208 252 minecraft:light[level=12]
setblock 541 208 259 minecraft:light[level=12]
setblock 541 208 266 minecraft:light[level=12]
setblock 541 208 270 minecraft:magenta_terracotta
setblock 544 208 231 minecraft:light[level=11]
setblock 544 208 239 minecraft:light[level=11]
setblock 544 208 247 minecraft:light[level=11]
setblock 544 208 255 minecraft:light[level=11]
setblock 544 208 263 minecraft:light[level=11]
setblock 545 208 228 minecraft:magenta_terracotta
setblock 545 208 270 minecraft:magenta_terracotta
setblock 548 208 231 minecraft:light[level=12]
setblock 548 208 238 minecraft:light[level=12]
setblock 548 208 245 minecraft:light[level=12]
setblock 548 208 252 minecraft:light[level=12]
setblock 548 208 259 minecraft:light[level=12]
setblock 548 208 266 minecraft:light[level=12]
setblock 549 208 228 minecraft:magenta_terracotta
setblock 549 208 270 minecraft:magenta_terracotta
setblock 552 208 231 minecraft:light[level=11]
setblock 552 208 239 minecraft:light[level=11]
setblock 552 208 247 minecraft:light[level=11]
setblock 552 208 255 minecraft:light[level=11]
setblock 552 208 263 minecraft:light[level=11]
setblock 553 208 228 minecraft:black_terracotta
setblock 553 208 270 minecraft:magenta_terracotta
setblock 555 208 231 minecraft:light[level=12]
setblock 555 208 238 minecraft:light[level=12]
setblock 555 208 245 minecraft:light[level=12]
setblock 555 208 252 minecraft:light[level=12]
setblock 555 208 259 minecraft:light[level=12]
setblock 555 208 266 minecraft:light[level=12]
setblock 557 208 228 minecraft:magenta_terracotta
setblock 557 208 270 minecraft:magenta_terracotta
setblock 559 208 228 minecraft:magenta_terracotta
setblock 559 208 232 minecraft:magenta_terracotta
setblock 559 208 236 minecraft:magenta_terracotta
setblock 559 208 240 minecraft:magenta_terracotta
setblock 559 208 244 minecraft:magenta_terracotta
setblock 559 208 248 minecraft:magenta_terracotta
setblock 559 208 252 minecraft:magenta_terracotta
setblock 559 208 256 minecraft:magenta_terracotta
setblock 559 208 260 minecraft:magenta_terracotta
setblock 559 208 264 minecraft:magenta_terracotta
setblock 559 208 268 minecraft:magenta_terracotta
fill 517 209 228 517 211 228 minecraft:purple_terracotta
fill 517 209 232 517 211 232 minecraft:purple_terracotta
fill 517 209 236 517 211 236 minecraft:purple_terracotta
fill 517 209 240 517 211 240 minecraft:purple_terracotta
fill 517 209 244 517 211 244 minecraft:purple_terracotta
fill 517 209 248 517 211 248 minecraft:purple_terracotta
fill 517 209 252 517 211 252 minecraft:purple_terracotta
fill 517 209 256 517 211 256 minecraft:purple_terracotta
fill 517 209 260 517 211 260 minecraft:purple_terracotta
fill 517 209 264 517 211 264 minecraft:purple_terracotta
fill 517 209 268 517 211 268 minecraft:purple_terracotta
setblock 517 209 270 minecraft:purple_terracotta
fill 518 209 241 518 209 245 minecraft:gold_block
fill 518 209 248 519 209 249 minecraft:dark_oak_planks
fill 519 209 250 519 209 251 minecraft:spruce_planks
fill 521 209 228 521 211 228 minecraft:purple_terracotta
fill 521 209 270 521 211 270 minecraft:purple_terracotta
setblock 524 209 270 minecraft:light_gray_terracotta
fill 525 209 228 525 211 228 minecraft:purple_terracotta
fill 525 209 270 525 211 270 minecraft:purple_terracotta
fill 529 209 228 529 211 228 minecraft:purple_terracotta
fill 529 209 270 529 211 270 minecraft:purple_terracotta
fill 533 209 228 533 211 228 minecraft:purple_terracotta
fill 533 209 270 533 211 270 minecraft:purple_terracotta
fill 537 209 228 537 211 228 minecraft:purple_terracotta
fill 537 209 270 537 211 270 minecraft:purple_terracotta
fill 541 209 228 541 211 228 minecraft:purple_terracotta
fill 541 209 270 541 211 270 minecraft:purple_terracotta
fill 545 209 228 545 211 228 minecraft:purple_terracotta
fill 545 209 270 545 211 270 minecraft:purple_terracotta
fill 549 209 228 549 211 228 minecraft:purple_terracotta
fill 549 209 270 549 211 270 minecraft:purple_terracotta
fill 553 209 228 553 211 228 minecraft:purple_terracotta
fill 553 209 270 553 211 270 minecraft:purple_terracotta
fill 557 209 228 557 211 228 minecraft:purple_terracotta
fill 557 209 270 557 211 270 minecraft:purple_terracotta
setblock 559 209 228 minecraft:purple_terracotta
fill 559 209 232 559 211 232 minecraft:purple_terracotta
fill 559 209 236 559 211 236 minecraft:purple_terracotta
fill 559 209 240 559 211 240 minecraft:purple_terracotta
fill 559 209 244 559 211 244 minecraft:purple_terracotta
fill 559 209 248 559 211 248 minecraft:purple_terracotta
fill 559 209 252 559 211 252 minecraft:purple_terracotta
fill 559 209 256 559 211 256 minecraft:purple_terracotta
fill 559 209 260 559 211 260 minecraft:purple_terracotta
fill 559 209 264 559 211 264 minecraft:purple_terracotta
fill 559 209 268 559 211 268 minecraft:purple_terracotta
setblock 517 210 230 minecraft:magenta_terracotta
setblock 517 210 234 minecraft:magenta_terracotta
setblock 517 210 238 minecraft:magenta_terracotta
setblock 517 210 242 minecraft:magenta_terracotta
setblock 517 210 246 minecraft:magenta_terracotta
setblock 517 210 250 minecraft:magenta_terracotta
setblock 517 210 254 minecraft:magenta_terracotta
setblock 517 210 258 minecraft:magenta_terracotta
setblock 517 210 262 minecraft:magenta_terracotta
setblock 517 210 266 minecraft:magenta_terracotta
setblock 517 210 270 minecraft:magenta_terracotta
fill 518 210 241 518 212 241 minecraft:gold_block
fill 518 210 242 518 211 244 minecraft:black_concrete
fill 518 210 245 518 212 245 minecraft:gold_block
fill 518 210 250 519 210 251 minecraft:dark_oak_planks
setblock 519 210 228 minecraft:magenta_terracotta
fill 519 210 252 519 210 253 minecraft:spruce_planks
setblock 519 210 270 minecraft:magenta_terracotta
setblock 523 210 228 minecraft:magenta_terracotta
setblock 523 210 270 minecraft:magenta_terracotta
fill 524 210 270 524 212 270 minecraft:purple_terracotta
setblock 527 210 228 minecraft:magenta_terracotta
setblock 527 210 270 minecraft:magenta_terracotta
setblock 531 210 228 minecraft:magenta_terracotta
setblock 531 210 270 minecraft:magenta_terracotta
setblock 535 210 228 minecraft:magenta_terracotta
setblock 535 210 270 minecraft:magenta_terracotta
setblock 539 210 228 minecraft:magenta_terracotta
setblock 539 210 270 minecraft:magenta_terracotta
setblock 543 210 228 minecraft:magenta_terracotta
setblock 543 210 270 minecraft:magenta_terracotta
setblock 547 210 228 minecraft:magenta_terracotta
setblock 547 210 270 minecraft:magenta_terracotta
setblock 551 210 228 minecraft:magenta_terracotta
setblock 551 210 270 minecraft:magenta_terracotta
setblock 555 210 228 minecraft:magenta_terracotta
setblock 555 210 270 minecraft:magenta_terracotta
setblock 559 210 228 minecraft:magenta_terracotta
setblock 559 210 230 minecraft:magenta_terracotta
setblock 559 210 234 minecraft:magenta_terracotta
setblock 559 210 238 minecraft:magenta_terracotta
setblock 559 210 242 minecraft:magenta_terracotta
setblock 559 210 246 minecraft:magenta_terracotta
setblock 559 210 250 minecraft:magenta_terracotta
setblock 559 210 254 minecraft:magenta_terracotta
setblock 559 210 258 minecraft:magenta_terracotta
setblock 559 210 262 minecraft:magenta_terracotta
setblock 559 210 266 minecraft:magenta_terracotta
setblock 559 210 270 minecraft:magenta_terracotta
fill 517 211 230 517 212 230 minecraft:purple_terracotta
fill 517 211 234 517 212 234 minecraft:purple_terracotta
fill 517 211 238 517 212 238 minecraft:purple_terracotta
fill 517 211 242 517 212 242 minecraft:purple_terracotta
fill 517 211 246 517 212 246 minecraft:purple_terracotta
fill 517 211 250 517 212 250 minecraft:purple_terracotta
fill 517 211 254 517 212 254 minecraft:purple_terracotta
fill 517 211 258 517 212 258 minecraft:purple_terracotta
fill 517 211 262 517 212 262 minecraft:purple_terracotta
fill 517 211 266 517 212 266 minecraft:purple_terracotta
setblock 517 211 270 minecraft:purple_terracotta
fill 518 211 252 519 213 253 minecraft:dark_oak_planks
fill 519 211 228 519 212 228 minecraft:purple_terracotta
fill 519 211 254 519 211 255 minecraft:spruce_planks
fill 519 211 270 519 212 270 minecraft:purple_terracotta
fill 523 211 228 523 212 228 minecraft:purple_terracotta
fill 523 211 270 523 212 270 minecraft:purple_terracotta
fill 527 211 228 527 212 228 minecraft:purple_terracotta
fill 527 211 270 527 212 270 minecraft:purple_terracotta
fill 531 211 228 531 212 228 minecraft:purple_terracotta
fill 531 211 270 531 212 270 minecraft:purple_terracotta
fill 535 211 228 535 212 228 minecraft:purple_terracotta
fill 535 211 270 535 212 270 minecraft:purple_terracotta
fill 539 211 228 539 212 228 minecraft:purple_terracotta
fill 539 211 270 539 212 270 minecraft:purple_terracotta
fill 543 211 228 543 212 228 minecraft:purple_terracotta
fill 543 211 270 543 212 270 minecraft:purple_terracotta
fill 547 211 228 547 212 228 minecraft:purple_terracotta
fill 547 211 270 547 212 270 minecraft:purple_terracotta
fill 551 211 228 551 212 228 minecraft:purple_terracotta
fill 551 211 270 551 212 270 minecraft:purple_terracotta
fill 555 211 228 555 212 228 minecraft:purple_terracotta
fill 555 211 270 555 212 270 minecraft:purple_terracotta
setblock 559 211 228 minecraft:purple_terracotta
fill 559 211 230 559 212 230 minecraft:purple_terracotta
fill 559 211 234 559 212 234 minecraft:purple_terracotta
fill 559 211 238 559 212 238 minecraft:purple_terracotta
fill 559 211 242 559 212 242 minecraft:purple_terracotta
fill 559 211 246 559 212 246 minecraft:purple_terracotta
fill 559 211 250 559 212 250 minecraft:purple_terracotta
fill 559 211 254 559 212 254 minecraft:purple_terracotta
fill 559 211 258 559 212 258 minecraft:purple_terracotta
fill 559 211 262 559 212 262 minecraft:purple_terracotta
fill 559 211 266 559 212 266 minecraft:purple_terracotta
fill 559 211 270 559 212 270 minecraft:purple_terracotta
setblock 517 212 228 minecraft:magenta_terracotta
setblock 517 212 232 minecraft:magenta_terracotta
setblock 517 212 236 minecraft:magenta_terracotta
setblock 517 212 240 minecraft:magenta_terracotta
setblock 517 212 244 minecraft:magenta_terracotta
setblock 517 212 248 minecraft:magenta_terracotta
setblock 517 212 252 minecraft:magenta_terracotta
setblock 517 212 256 minecraft:magenta_terracotta
setblock 517 212 260 minecraft:magenta_terracotta
setblock 517 212 264 minecraft:magenta_terracotta
setblock 517 212 268 minecraft:magenta_terracotta
setblock 517 212 270 minecraft:magenta_terracotta
fill 518 212 229 558 212 240 minecraft:dark_oak_planks
fill 518 212 242 518 212 244 minecraft:light_gray_concrete
fill 518 212 246 529 212 251 minecraft:dark_oak_planks
fill 518 212 254 518 213 269 minecraft:dark_oak_planks
fill 519 212 241 532 212 245 minecraft:dark_oak_planks
fill 519 212 254 530 213 255 minecraft:dark_oak_planks
fill 519 212 256 519 212 257 minecraft:spruce_planks
fill 519 212 258 534 213 269 minecraft:dark_oak_planks
fill 520 212 252 529 213 253 minecraft:dark_oak_planks
fill 520 212 256 531 213 257 minecraft:dark_oak_planks
setblock 521 212 228 minecraft:magenta_terracotta
setblock 521 212 270 minecraft:magenta_terracotta
setblock 525 212 228 minecraft:magenta_terracotta
setblock 525 212 270 minecraft:magenta_terracotta
setblock 529 212 228 minecraft:magenta_terracotta
setblock 529 212 270 minecraft:magenta_terracotta
fill 530 212 246 530 212 248 minecraft:dark_oak_planks
fill 530 212 249 533 212 253 minecraft:gold_block
setblock 531 212 246 minecraft:dark_oak_planks
fill 531 212 247 536 212 248 minecraft:gold_block
fill 531 212 254 536 212 255 minecraft:gold_block
fill 532 212 246 542 212 246 minecraft:gold_block
fill 532 212 256 542 212 256 minecraft:gold_block
fill 532 212 257 532 214 257 minecraft:dark_oak_planks
setblock 533 212 228 minecraft:magenta_terracotta
fill 533 212 241 534 212 244 minecraft:dark_oak_planks
fill 533 212 245 541 212 245 minecraft:gold_block
fill 533 212 257 541 212 257 minecraft:gold_block
setblock 533 212 270 minecraft:magenta_terracotta
fill 534 212 249 534 212 250 minecraft:gold_block
fill 534 212 252 534 212 253 minecraft:gold_block
fill 535 212 241 558 212 243 minecraft:dark_oak_planks
fill 535 212 244 539 213 244 minecraft:gold_block
fill 535 212 258 539 212 258 minecraft:gold_block
fill 535 212 259 558 213 269 minecraft:dark_oak_planks
setblock 537 212 228 minecraft:magenta_terracotta
fill 537 212 247 543 212 247 minecraft:gold_block
fill 537 212 255 543 212 255 minecraft:gold_block
setblock 537 212 270 minecraft:magenta_terracotta
fill 538 212 248 543 212 248 minecraft:gold_block
fill 538 212 254 543 212 254 minecraft:gold_block
fill 540 212 244 558 212 244 minecraft:dark_oak_planks
fill 540 212 249 544 212 250 minecraft:gold_block
fill 540 212 252 544 212 253 minecraft:gold_block
fill 540 212 258 558 213 258 minecraft:dark_oak_planks
setblock 541 212 228 minecraft:magenta_terracotta
fill 541 212 251 544 212 251 minecraft:gold_block
setblock 541 212 270 minecraft:magenta_terracotta
fill 542 212 245 558 212 245 minecraft:dark_oak_planks
fill 542 212 257 558 212 257 minecraft:dark_oak_planks
fill 543 212 246 558 212 246 minecraft:dark_oak_planks
fill 543 212 256 558 212 256 minecraft:dark_oak_planks
fill 544 212 247 558 212 248 minecraft:dark_oak_planks
fill 544 212 254 558 212 255 minecraft:dark_oak_planks
setblock 545 212 228 minecraft:magenta_terracotta
fill 545 212 249 558 212 253 minecraft:dark_oak_planks
setblock 545 212 270 minecraft:magenta_terracotta
setblock 549 212 228 minecraft:magenta_terracotta
setblock 549 212 270 minecraft:magenta_terracotta
setblock 553 212 228 minecraft:magenta_terracotta
setblock 553 212 270 minecraft:magenta_terracotta
setblock 557 212 228 minecraft:magenta_terracotta
setblock 557 212 270 minecraft:magenta_terracotta
setblock 559 212 228 minecraft:magenta_terracotta
setblock 559 212 232 minecraft:magenta_terracotta
setblock 559 212 236 minecraft:magenta_terracotta
setblock 559 212 240 minecraft:magenta_terracotta
setblock 559 212 244 minecraft:magenta_terracotta
setblock 559 212 248 minecraft:magenta_terracotta
setblock 559 212 252 minecraft:magenta_terracotta
setblock 559 212 256 minecraft:magenta_terracotta
setblock 559 212 260 minecraft:magenta_terracotta
setblock 559 212 264 minecraft:magenta_terracotta
setblock 559 212 268 minecraft:magenta_terracotta
fill 517 213 228 517 213 270 minecraft:dark_oak_planks
fill 518 213 228 528 213 251 minecraft:dark_oak_planks
fill 518 213 270 559 213 270 minecraft:dark_oak_planks
fill 519 213 256 519 213 257 minecraft:dark_oak_planks
fill 529 213 228 529 213 247 minecraft:dark_oak_planks
fill 529 213 248 529 213 250 minecraft:spruce_planks
fill 529 213 251 529 214 251 minecraft:dark_oak_planks
fill 530 213 228 530 213 244 minecraft:dark_oak_planks
fill 530 213 245 530 213 248 minecraft:spruce_planks
fill 530 213 249 531 213 249 minecraft:gold_block
fill 530 213 250 530 213 253 minecraft:spruce_planks
fill 531 213 228 531 213 243 minecraft:dark_oak_planks
fill 531 213 244 531 213 245 minecraft:spruce_planks
fill 531 213 246 531 213 248 minecraft:gold_block
setblock 531 213 250 minecraft:yellow_stained_glass
setblock 531 213 251 minecraft:gold_block
setblock 531 213 252 minecraft:yellow_stained_glass
fill 531 213 253 531 213 254 minecraft:spruce_planks
fill 531 213 255 531 214 255 minecraft:dark_oak_planks
fill 532 213 228 532 213 242 minecraft:dark_oak_planks
setblock 532 213 243 minecraft:spruce_planks
fill 532 213 245 532 213 246 minecraft:gold_block
setblock 532 213 247 minecraft:yellow_stained_glass
setblock 532 213 248 minecraft:gold_block
setblock 532 213 249 minecraft:yellow_stained_glass
setblock 532 213 250 minecraft:gold_block
setblock 532 213 251 minecraft:yellow_stained_glass
setblock 532 213 252 minecraft:gold_block
setblock 532 213 253 minecraft:yellow_stained_glass
setblock 532 213 254 minecraft:gold_block
setblock 532 213 255 minecraft:spruce_planks
setblock 532 213 256 minecraft:dark_oak_planks
fill 533 213 228 533 213 241 minecraft:dark_oak_planks
fill 533 213 242 534 213 242 minecraft:spruce_planks
fill 533 213 244 534 213 245 minecraft:gold_block
setblock 533 213 246 minecraft:yellow_stained_glass
setblock 533 213 247 minecraft:gold_block
setblock 533 213 248 minecraft:yellow_stained_glass
setblock 533 213 249 minecraft:gold_block
fill 533 213 250 533 213 252 minecraft:ochre_froglight
setblock 533 213 253 minecraft:gold_block
setblock 533 213 254 minecraft:yellow_stained_glass
setblock 533 213 255 minecraft:gold_block
fill 533 213 256 534 213 256 minecraft:spruce_planks
fill 533 213 257 533 214 257 minecraft:dark_oak_planks
fill 534 213 228 536 213 240 minecraft:dark_oak_planks
fill 534 213 241 537 213 241 minecraft:spruce_planks
fill 534 213 243 540 213 243 minecraft:gold_block
setblock 534 213 246 minecraft:gold_block
setblock 534 213 247 minecraft:yellow_stained_glass
setblock 534 213 248 minecraft:ochre_froglight
fill 534 213 249 534 213 250 minecraft:pearlescent_froglight
fill 534 213 252 534 213 253 minecraft:pearlescent_froglight
setblock 534 213 254 minecraft:ochre_froglight
setblock 534 213 255 minecraft:yellow_stained_glass
fill 534 213 257 537 213 257 minecraft:spruce_planks
setblock 535 213 245 minecraft:gold_block
setblock 535 213 246 minecraft:yellow_stained_glass
setblock 535 213 247 minecraft:gold_block
fill 535 213 248 536 213 248 minecraft:pearlescent_froglight
fill 535 213 254 536 213 254 minecraft:pearlescent_froglight
setblock 535 213 255 minecraft:gold_block
setblock 535 213 256 minecraft:yellow_stained_glass
fill 535 213 258 536 221 258 minecraft:dark_oak_planks
setblock 536 213 245 minecraft:yellow_stained_glass
setblock 536 213 246 minecraft:gold_block
fill 536 213 247 538 213 247 minecraft:ochre_froglight
fill 536 213 255 538 213 255 minecraft:ochre_froglight
setblock 536 213 256 minecraft:gold_block
fill 537 213 228 559 213 239 minecraft:dark_oak_planks
fill 537 213 240 539 213 240 minecraft:spruce_planks
setblock 537 213 245 minecraft:gold_block
setblock 537 213 246 minecraft:yellow_stained_glass
setblock 537 213 256 minecraft:yellow_stained_glass
fill 537 213 258 539 213 258 minecraft:spruce_planks
setblock 538 213 245 minecraft:yellow_stained_glass
setblock 538 213 246 minecraft:gold_block
fill 538 213 248 539 213 248 minecraft:pearlescent_froglight
fill 538 213 254 539 213 254 minecraft:pearlescent_froglight
setblock 538 213 256 minecraft:gold_block
setblock 538 213 257 minecraft:yellow_stained_glass
fill 539 213 241 542 213 241 minecraft:spruce_planks
fill 539 213 245 543 213 245 minecraft:gold_block
setblock 539 213 246 minecraft:yellow_stained_glass
setblock 539 213 247 minecraft:gold_block
setblock 539 213 255 minecraft:gold_block
setblock 539 213 256 minecraft:yellow_stained_glass
fill 539 213 257 542 213 257 minecraft:spruce_planks
fill 540 213 240 559 213 240 minecraft:dark_oak_planks
fill 540 213 244 541 213 244 minecraft:gold_block
setblock 540 213 246 minecraft:gold_block
setblock 540 213 247 minecraft:yellow_stained_glass
setblock 540 213 248 minecraft:ochre_froglight
fill 540 213 249 540 213 250 minecraft:pearlescent_froglight
fill 540 213 252 540 213 253 minecraft:pearlescent_froglight
setblock 540 213 254 minecraft:ochre_froglight
setblock 540 213 255 minecraft:yellow_stained_glass
setblock 540 213 256 minecraft:gold_block
setblock 541 213 246 minecraft:yellow_stained_glass
setblock 541 213 247 minecraft:gold_block
setblock 541 213 248 minecraft:yellow_stained_glass
setblock 541 213 249 minecraft:gold_block
fill 541 213 250 541 213 252 minecraft:ochre_froglight
setblock 541 213 253 minecraft:gold_block
setblock 541 213 254 minecraft:yellow_stained_glass
setblock 541 213 255 minecraft:gold_block
setblock 541 213 256 minecraft:yellow_stained_glass
fill 542 213 242 543 213 242 minecraft:spruce_planks
fill 542 213 246 543 213 246 minecraft:gold_block
setblock 542 213 247 minecraft:yellow_stained_glass
fill 542 213 248 545 213 248 minecraft:gold_block
setblock 542 213 249 minecraft:yellow_stained_glass
setblock 542 213 250 minecraft:gold_block
setblock 542 213 251 minecraft:yellow_stained_glass
setblock 542 213 252 minecraft:gold_block
setblock 542 213 253 minecraft:yellow_stained_glass
fill 542 213 254 544 213 254 minecraft:gold_block
setblock 542 213 255 minecraft:yellow_stained_glass
fill 542 213 256 543 213 256 minecraft:spruce_planks
fill 543 213 241 559 213 241 minecraft:dark_oak_planks
fill 543 213 247 544 213 247 minecraft:gold_block
fill 543 213 249 545 213 249 minecraft:gold_block
setblock 543 213 250 minecraft:yellow_stained_glass
fill 543 213 251 545 213 251 minecraft:gold_block
setblock 543 213 252 minecraft:yellow_stained_glass
fill 543 213 253 544 213 253 minecraft:gold_block
setblock 543 213 255 minecraft:gold_block
fill 543 213 257 559 213 257 minecraft:dark_oak_planks
fill 544 213 242 559 213 242 minecraft:dark_oak_planks
setblock 544 213 243 minecraft:spruce_planks
fill 544 213 250 545 213 250 minecraft:gold_block
fill 544 213 252 545 213 252 minecraft:gold_block
setblock 544 213 255 minecraft:spruce_planks
fill 544 213 256 559 213 256 minecraft:dark_oak_planks
fill 545 213 243 559 213 243 minecraft:dark_oak_planks
fill 545 213 244 545 213 245 minecraft:spruce_planks
fill 545 213 253 545 213 254 minecraft:spruce_planks
fill 545 213 255 559 213 255 minecraft:dark_oak_planks
fill 546 213 244 559 213 244 minecraft:dark_oak_planks
fill 546 213 245 546 213 248 minecraft:spruce_planks
fill 546 213 250 546 213 253 minecraft:spruce_planks
fill 546 213 254 559 213 254 minecraft:dark_oak_planks
fill 547 213 245 559 213 247 minecraft:dark_oak_planks
fill 547 213 248 547 213 250 minecraft:spruce_planks
fill 547 213 251 559 213 253 minecraft:dark_oak_planks
fill 548 213 248 559 213 250 minecraft:dark_oak_planks
fill 559 213 258 559 213 269 minecraft:dark_oak_planks
fill 517 214 228 517 215 229 minecraft:purple_terracotta
setblock 517 214 230 minecraft:magenta_terracotta
fill 517 214 231 517 215 233 minecraft:purple_terracotta
setblock 517 214 234 minecraft:magenta_terracotta
fill 517 214 235 517 215 237 minecraft:purple_terracotta
setblock 517 214 238 minecraft:magenta_terracotta
fill 517 214 239 517 215 241 minecraft:purple_terracotta
setblock 517 214 242 minecraft:magenta_terracotta
fill 517 214 243 517 215 245 minecraft:purple_terracotta
setblock 517 214 246 minecraft:magenta_terracotta
fill 517 214 247 517 215 249 minecraft:purple_terracotta
setblock 517 214 250 minecraft:magenta_terracotta
fill 517 214 251 517 215 253 minecraft:purple_terracotta
setblock 517 214 254 minecraft:magenta_terracotta
fill 517 214 255 517 215 257 minecraft:purple_terracotta
setblock 517 214 258 minecraft:magenta_terracotta
fill 517 214 259 517 215 261 minecraft:purple_terracotta
setblock 517 214 262 minecraft:magenta_terracotta
fill 517 214 263 517 214 265 minecraft:purple_terracotta
setblock 517 214 266 minecraft:magenta_terracotta
fill 517 214 267 517 215 269 minecraft:purple_terracotta
setblock 517 214 270 minecraft:magenta_terracotta
fill 518 214 228 518 232 228 minecraft:purple_terracotta
fill 518 214 241 518 215 241 minecraft:gold_block
fill 518 214 242 518 214 244 minecraft:light_gray_concrete
fill 518 214 245 518 215 245 minecraft:gold_block
fill 518 214 258 519 214 259 minecraft:dark_oak_planks
fill 518 214 270 518 278 270 minecraft:purple_terracotta
setblock 519 214 228 minecraft:magenta_terracotta
fill 519 214 260 519 214 261 minecraft:spruce_planks
setblock 519 214 270 minecraft:magenta_terracotta
fill 520 214 228 522 215 228 minecraft:purple_terracotta
setblock 520 214 231 minecraft:light[level=12]
setblock 520 214 238 minecraft:light[level=12]
setblock 520 214 245 minecraft:light[level=12]
setblock 520 214 252 minecraft:light[level=12]
setblock 520 214 259 minecraft:light[level=12]
setblock 520 214 266 minecraft:light[level=12]
fill 520 214 270 522 215 270 minecraft:purple_terracotta
setblock 523 214 228 minecraft:magenta_terracotta
setblock 523 214 270 minecraft:magenta_terracotta
fill 524 214 228 526 215 228 minecraft:purple_terracotta
fill 524 214 270 526 215 270 minecraft:purple_terracotta
fill 525 214 251 525 215 252 minecraft:cobblestone
setblock 527 214 228 minecraft:magenta_terracotta
setblock 527 214 231 minecraft:light[level=12]
setblock 527 214 238 minecraft:light[level=12]
fill 527 214 244 527 215 245 minecraft:cobblestone
setblock 527 214 252 minecraft:light[level=12]
fill 527 214 259 527 215 260 minecraft:cobblestone
setblock 527 214 266 minecraft:light[level=12]
setblock 527 214 270 minecraft:magenta_terracotta
fill 528 214 228 530 215 228 minecraft:purple_terracotta
fill 528 214 244 528 215 258 minecraft:dark_oak_planks
fill 528 214 270 530 215 270 minecraft:purple_terracotta
fill 529 214 244 531 214 250 minecraft:dark_oak_planks
fill 529 214 252 530 214 258 minecraft:dark_oak_planks
fill 530 214 243 531 214 243 minecraft:dark_oak_planks
fill 530 214 251 531 214 251 minecraft:dark_oak_planks
setblock 531 214 228 minecraft:magenta_terracotta
fill 531 214 252 531 214 254 minecraft:dark_oak_planks
fill 531 214 256 531 214 258 minecraft:dark_oak_planks
setblock 531 214 270 minecraft:magenta_terracotta
fill 532 214 228 534 215 228 minecraft:purple_terracotta
fill 532 214 241 533 214 241 minecraft:dark_oak_planks
fill 532 214 244 546 214 245 minecraft:dark_oak_planks
fill 532 214 258 534 215 258 minecraft:dark_oak_planks
fill 532 214 270 534 215 270 minecraft:purple_terracotta
setblock 534 214 231 minecraft:light[level=12]
setblock 534 214 238 minecraft:light[level=12]
fill 534 214 240 534 215 241 minecraft:cobblestone
fill 534 214 257 546 214 257 minecraft:dark_oak_planks
setblock 534 214 259 minecraft:light[level=12]
fill 534 214 263 534 215 264 minecraft:cobblestone
setblock 534 214 266 minecraft:light[level=12]
setblock 535 214 228 minecraft:magenta_terracotta
setblock 535 214 240 minecraft:dark_oak_planks
setblock 535 214 270 minecraft:magenta_terracotta
fill 536 214 228 538 215 228 minecraft:purple_terracotta
fill 536 214 270 538 215 270 minecraft:purple_terracotta
setblock 537 214 240 minecraft:dark_oak_planks
fill 537 214 243 537 215 243 minecraft:white_concrete
fill 537 214 258 546 215 258 minecraft:dark_oak_planks
fill 537 214 259 537 215 259 minecraft:white_concrete
setblock 538 214 259 minecraft:dark_oak_planks
setblock 539 214 228 minecraft:magenta_terracotta
setblock 539 214 240 minecraft:dark_oak_planks
setblock 539 214 270 minecraft:magenta_terracotta
fill 540 214 228 542 215 228 minecraft:purple_terracotta
fill 540 214 270 542 215 270 minecraft:purple_terracotta
setblock 541 214 231 minecraft:light[level=12]
setblock 541 214 238 minecraft:light[level=12]
fill 541 214 240 541 215 241 minecraft:cobblestone
setblock 541 214 259 minecraft:light[level=12]
fill 541 214 263 541 215 264 minecraft:cobblestone
setblock 541 214 266 minecraft:light[level=12]
setblock 542 214 240 minecraft:dark_oak_planks
setblock 543 214 228 minecraft:magenta_terracotta
fill 543 214 246 546 214 256 minecraft:dark_oak_planks
setblock 543 214 270 minecraft:magenta_terracotta
fill 544 214 228 546 215 228 minecraft:purple_terracotta
setblock 544 214 241 minecraft:dark_oak_planks
fill 544 214 270 546 215 270 minecraft:purple_terracotta
fill 545 214 243 546 214 243 minecraft:dark_oak_planks
setblock 547 214 228 minecraft:magenta_terracotta
setblock 547 214 245 minecraft:dark_oak_planks
setblock 547 214 247 minecraft:dark_oak_planks
setblock 547 214 250 minecraft:dark_oak_planks
setblock 547 214 252 minecraft:dark_oak_planks
setblock 547 214 270 minecraft:magenta_terracotta
fill 548 214 228 550 215 228 minecraft:purple_terracotta
setblock 548 214 231 minecraft:light[level=12]
setblock 548 214 238 minecraft:light[level=12]
fill 548 214 244 548 215 245 minecraft:cobblestone
setblock 548 214 249 minecraft:dark_oak_planks
setblock 548 214 252 minecraft:light[level=12]
fill 548 214 259 548 215 260 minecraft:cobblestone
setblock 548 214 266 minecraft:light[level=12]
fill 548 214 270 550 215 270 minecraft:purple_terracotta
fill 550 214 251 550 215 252 minecraft:cobblestone
setblock 551 214 228 minecraft:magenta_terracotta
setblock 551 214 270 minecraft:magenta_terracotta
fill 552 214 228 554 215 228 minecraft:purple_terracotta
fill 552 214 270 554 215 270 minecraft:purple_terracotta
setblock 555 214 228 minecraft:magenta_terracotta
setblock 555 214 231 minecraft:light[level=12]
setblock 555 214 238 minecraft:light[level=12]
setblock 555 214 245 minecraft:light[level=12]
setblock 555 214 252 minecraft:light[level=12]
setblock 555 214 259 minecraft:light[level=12]
setblock 555 214 266 minecraft:light[level=12]
setblock 555 214 270 minecraft:magenta_terracotta
fill 556 214 228 558 215 228 minecraft:purple_terracotta
fill 556 214 270 558 215 270 minecraft:purple_terracotta
setblock 559 214 228 minecraft:magenta_terracotta
fill 559 214 229 559 278 229 minecraft:purple_terracotta
setblock 559 214 230 minecraft:magenta_terracotta
fill 559 214 231 559 215 233 minecraft:purple_terracotta
setblock 559 214 234 minecraft:magenta_terracotta
fill 559 214 235 559 215 237 minecraft:purple_terracotta
setblock 559 214 238 minecraft:magenta_terracotta
fill 559 214 239 559 215 241 minecraft:purple_terracotta
setblock 559 214 242 minecraft:magenta_terracotta
fill 559 214 243 559 215 245 minecraft:purple_terracotta
setblock 559 214 246 minecraft:magenta_terracotta
fill 559 214 247 559 215 249 minecraft:purple_terracotta
setblock 559 214 250 minecraft:magenta_terracotta
fill 559 214 251 559 215 253 minecraft:purple_terracotta
setblock 559 214 254 minecraft:magenta_terracotta
fill 559 214 255 559 215 257 minecraft:purple_terracotta
setblock 559 214 258 minecraft:magenta_terracotta
fill 559 214 259 559 215 261 minecraft:purple_terracotta
setblock 559 214 262 minecraft:magenta_terracotta
fill 559 214 263 559 215 265 minecraft:purple_terracotta
setblock 559 214 266 minecraft:magenta_terracotta
fill 559 214 267 559 215 269 minecraft:purple_terracotta
setblock 559 214 270 minecraft:magenta_terracotta
fill 517 215 230 517 217 230 minecraft:purple_terracotta
fill 517 215 234 517 217 234 minecraft:purple_terracotta
fill 517 215 238 517 217 238 minecraft:purple_terracotta
fill 517 215 242 517 217 242 minecraft:purple_terracotta
fill 517 215 246 517 217 246 minecraft:purple_terracotta
fill 517 215 250 517 217 250 minecraft:purple_terracotta
fill 517 215 254 517 217 254 minecraft:purple_terracotta
fill 517 215 258 517 217 258 minecraft:purple_terracotta
fill 517 215 262 517 217 263 minecraft:purple_terracotta
setblock 517 215 264 minecraft:black_terracotta
fill 517 215 265 517 217 266 minecraft:purple_terracotta
setblock 517 215 270 minecraft:purple_terracotta
fill 518 215 242 518 215 244 minecraft:gold_block
fill 518 215 260 519 215 261 minecraft:dark_oak_planks
fill 519 215 228 519 217 228 minecraft:purple_terracotta
fill 519 215 262 519 215 263 minecraft:spruce_planks
fill 519 215 270 519 217 270 minecraft:purple_terracotta
fill 523 215 228 523 217 228 minecraft:purple_terracotta
fill 523 215 270 523 217 270 minecraft:purple_terracotta
fill 527 215 228 527 217 228 minecraft:purple_terracotta
fill 527 215 270 527 217 270 minecraft:purple_terracotta
fill 529 215 244 546 215 244 minecraft:dark_oak_planks
setblock 529 215 251 minecraft:white_concrete
fill 529 215 258 531 215 258 minecraft:dark_oak_planks
setblock 530 215 247 minecraft:white_concrete
setblock 530 215 255 minecraft:white_concrete
fill 531 215 228 531 217 228 minecraft:purple_terracotta
fill 531 215 270 531 217 270 minecraft:purple_terracotta
fill 535 215 228 535 217 228 minecraft:purple_terracotta
fill 535 215 239 535 217 240 minecraft:white_stained_glass
fill 535 215 270 535 217 270 minecraft:purple_terracotta
fill 536 215 238 536 217 239 minecraft:white_stained_glass
fill 539 215 228 539 217 228 minecraft:purple_terracotta
fill 539 215 270 539 217 270 minecraft:purple_terracotta
fill 543 215 228 543 217 228 minecraft:purple_terracotta
fill 543 215 270 543 217 270 minecraft:purple_terracotta
setblock 544 215 247 minecraft:white_concrete
setblock 544 215 255 minecraft:white_concrete
setblock 545 215 251 minecraft:white_concrete
fill 546 215 245 546 215 257 minecraft:dark_oak_planks
fill 547 215 228 547 217 228 minecraft:purple_terracotta
fill 547 215 270 547 217 270 minecraft:purple_terracotta
fill 551 215 228 551 217 228 minecraft:purple_terracotta
fill 551 215 270 551 217 270 minecraft:purple_terracotta
fill 555 215 228 555 217 228 minecraft:purple_terracotta
fill 555 215 270 555 217 270 minecraft:purple_terracotta
setblock 559 215 228 minecraft:purple_terracotta
fill 559 215 230 559 217 230 minecraft:purple_terracotta
fill 559 215 234 559 217 234 minecraft:purple_terracotta
fill 559 215 238 559 217 238 minecraft:purple_terracotta
fill 559 215 242 559 217 242 minecraft:purple_terracotta
fill 559 215 246 559 217 246 minecraft:purple_terracotta
fill 559 215 250 559 217 250 minecraft:purple_terracotta
fill 559 215 254 559 217 254 minecraft:purple_terracotta
fill 559 215 258 559 217 258 minecraft:purple_terracotta
fill 559 215 262 559 217 262 minecraft:purple_terracotta
fill 559 215 266 559 217 266 minecraft:purple_terracotta
fill 559 215 270 559 217 270 minecraft:purple_terracotta
setblock 517 216 228 minecraft:magenta_terracotta
fill 517 216 229 517 278 229 minecraft:purple_terracotta
fill 517 216 231 517 272 231 minecraft:purple_terracotta
setblock 517 216 232 minecraft:magenta_terracotta
fill 517 216 233 517 278 233 minecraft:purple_terracotta
fill 517 216 235 517 278 235 minecraft:purple_terracotta
setblock 517 216 236 minecraft:magenta_terracotta
fill 517 216 237 517 278 237 minecraft:purple_terracotta
fill 517 216 239 517 278 239 minecraft:purple_terracotta
setblock 517 216 240 minecraft:magenta_terracotta
fill 517 216 241 517 278 241 minecraft:purple_terracotta
fill 517 216 243 517 228 243 minecraft:purple_terracotta
setblock 517 216 244 minecraft:magenta_terracotta
fill 517 216 245 517 278 245 minecraft:purple_terracotta
fill 517 216 247 517 278 247 minecraft:purple_terracotta
setblock 517 216 248 minecraft:magenta_terracotta
setblock 517 216 249 minecraft:purple_terracotta
fill 517 216 251 517 260 251 minecraft:purple_terracotta
setblock 517 216 252 minecraft:magenta_terracotta
fill 517 216 253 517 256 253 minecraft:purple_terracotta
fill 517 216 255 517 278 255 minecraft:purple_terracotta
setblock 517 216 256 minecraft:magenta_terracotta
fill 517 216 257 517 278 257 minecraft:purple_terracotta
fill 517 216 259 517 278 259 minecraft:purple_terracotta
setblock 517 216 260 minecraft:magenta_terracotta
fill 517 216 261 517 273 261 minecraft:purple_terracotta
setblock 517 216 264 minecraft:magenta_terracotta
fill 517 216 267 517 278 267 minecraft:purple_terracotta
setblock 517 216 268 minecraft:magenta_terracotta
fill 517 216 269 517 270 269 minecraft:purple_terracotta
setblock 517 216 270 minecraft:magenta_terracotta
fill 518 216 262 519 216 263 minecraft:dark_oak_planks
fill 519 216 264 519 216 265 minecraft:spruce_planks
fill 520 216 228 520 278 228 minecraft:purple_terracotta
setblock 520 216 231 minecraft:light[level=11]
setblock 520 216 239 minecraft:light[level=11]
setblock 520 216 247 minecraft:light[level=11]
setblock 520 216 255 minecraft:light[level=11]
setblock 520 216 263 minecraft:light[level=11]
fill 520 216 270 520 227 270 minecraft:purple_terracotta
setblock 521 216 228 minecraft:magenta_terracotta
setblock 521 216 270 minecraft:magenta_terracotta
fill 522 216 228 522 278 228 minecraft:purple_terracotta
fill 522 216 270 522 278 270 minecraft:purple_terracotta
fill 524 216 228 524 278 228 minecraft:purple_terracotta
fill 524 216 270 524 278 270 minecraft:purple_terracotta
setblock 525 216 228 minecraft:magenta_terracotta
setblock 525 216 270 minecraft:magenta_terracotta
fill 526 216 228 526 278 228 minecraft:purple_terracotta
fill 526 216 270 526 278 270 minecraft:purple_terracotta
fill 528 216 228 528 278 228 minecraft:purple_terracotta
setblock 528 216 231 minecraft:light[level=11]
setblock 528 216 239 minecraft:light[level=11]
fill 528 216 244 528 221 245 minecraft:dark_oak_planks
setblock 528 216 246 minecraft:ochre_froglight
fill 528 216 247 528 221 248 minecraft:dark_oak_planks
setblock 528 216 249 minecraft:ochre_froglight
fill 528 216 250 528 221 251 minecraft:dark_oak_planks
setblock 528 216 252 minecraft:ochre_froglight
fill 528 216 253 528 221 254 minecraft:dark_oak_planks
setblock 528 216 255 minecraft:ochre_froglight
fill 528 216 256 528 221 257 minecraft:dark_oak_planks
setblock 528 216 258 minecraft:ochre_froglight
setblock 528 216 263 minecraft:light[level=11]
fill 528 216 270 528 278 270 minecraft:purple_terracotta
setblock 529 216 228 minecraft:magenta_terracotta
fill 529 216 244 529 221 244 minecraft:dark_oak_planks
setblock 529 216 251 minecraft:ochre_froglight
fill 529 216 258 530 221 258 minecraft:dark_oak_planks
setblock 529 216 270 minecraft:magenta_terracotta
fill 530 216 228 530 278 228 minecraft:purple_terracotta
setblock 530 216 244 minecraft:ochre_froglight
setblock 530 216 247 minecraft:ochre_froglight
setblock 530 216 255 minecraft:ochre_froglight
fill 530 216 270 530 221 270 minecraft:purple_terracotta
fill 531 216 244 532 221 244 minecraft:dark_oak_planks
setblock 531 216 258 minecraft:ochre_froglight
fill 532 216 228 532 278 228 minecraft:purple_terracotta
fill 532 216 258 533 221 258 minecraft:dark_oak_planks
fill 532 216 270 532 226 270 minecraft:purple_terracotta
setblock 533 216 228 minecraft:magenta_terracotta
setblock 533 216 244 minecraft:ochre_froglight
setblock 533 216 270 minecraft:magenta_terracotta
fill 534 216 228 534 278 228 minecraft:purple_terracotta
fill 534 216 239 534 218 240 minecraft:white_stained_glass
fill 534 216 244 535 221 244 minecraft:dark_oak_planks
setblock 534 216 258 minecraft:ochre_froglight
fill 534 216 270 534 217 270 minecraft:purple_terracotta
fill 535 216 238 535 217 238 minecraft:white_stained_glass
fill 535 216 241 536 218 241 minecraft:white_stained_glass
fill 536 216 228 536 278 228 minecraft:purple_terracotta
setblock 536 216 231 minecraft:light[level=11]
fill 536 216 240 537 217 240 minecraft:white_stained_glass
setblock 536 216 244 minecraft:ochre_froglight
setblock 536 216 263 minecraft:light[level=11]
fill 536 216 270 536 278 270 minecraft:purple_terracotta
setblock 537 216 228 minecraft:magenta_terracotta
fill 537 216 238 537 217 239 minecraft:white_stained_glass
setblock 537 216 243 minecraft:ochre_froglight
fill 537 216 244 538 221 244 minecraft:dark_oak_planks
fill 537 216 258 537 216 259 minecraft:ochre_froglight
setblock 537 216 270 minecraft:magenta_terracotta
fill 538 216 228 538 278 228 minecraft:purple_terracotta
fill 538 216 258 539 221 258 minecraft:dark_oak_planks
fill 538 216 270 538 278 270 minecraft:purple_terracotta
setblock 539 216 244 minecraft:ochre_froglight
fill 540 216 228 540 278 228 minecraft:purple_terracotta
fill 540 216 244 541 221 244 minecraft:dark_oak_planks
setblock 540 216 258 minecraft:ochre_froglight
fill 540 216 270 540 263 270 minecraft:purple_terracotta
setblock 541 216 228 minecraft:magenta_terracotta
fill 541 216 258 542 221 258 minecraft:dark_oak_planks
setblock 541 216 270 minecraft:magenta_terracotta
fill 542 216 228 542 278 228 minecraft:purple_terracotta
setblock 542 216 244 minecraft:ochre_froglight
fill 542 216 270 542 250 270 minecraft:purple_terracotta
fill 543 216 244 544 221 244 minecraft:dark_oak_planks
setblock 543 216 258 minecraft:ochre_froglight
fill 544 216 228 544 247 228 minecraft:purple_terracotta
setblock 544 216 231 minecraft:light[level=11]
setblock 544 216 239 minecraft:light[level=11]
setblock 544 216 247 minecraft:ochre_froglight
setblock 544 216 255 minecraft:ochre_froglight
fill 544 216 258 545 221 258 minecraft:dark_oak_planks
setblock 544 216 263 minecraft:light[level=11]
fill 544 216 270 544 278 270 minecraft:purple_terracotta
setblock 545 216 228 minecraft:magenta_terracotta
setblock 545 216 244 minecraft:ochre_froglight
setblock 545 216 251 minecraft:ochre_froglight
setblock 545 216 270 minecraft:magenta_terracotta
fill 546 216 228 546 278 228 minecraft:purple_terracotta
fill 546 216 244 546 221 245 minecraft:dark_oak_planks
setblock 546 216 246 minecraft:ochre_froglight
fill 546 216 247 546 221 248 minecraft:dark_oak_planks
setblock 546 216 249 minecraft:ochre_froglight
fill 546 216 250 546 221 251 minecraft:dark_oak_planks
setblock 546 216 252 minecraft:ochre_froglight
fill 546 216 253 546 221 254 minecraft:dark_oak_planks
setblock 546 216 255 minecraft:ochre_froglight
fill 546 216 256 546 221 257 minecraft:dark_oak_planks
setblock 546 216 258 minecraft:ochre_froglight
fill 546 216 270 546 275 270 minecraft:purple_terracotta
fill 548 216 228 548 266 228 minecraft:purple_terracotta
fill 548 216 270 548 278 270 minecraft:purple_terracotta
setblock 549 216 228 minecraft:magenta_terracotta
setblock 549 216 270 minecraft:magenta_terracotta
fill 550 216 228 550 278 228 minecraft:purple_terracotta
fill 550 216 270 550 276 270 minecraft:purple_terracotta
fill 552 216 228 552 226 228 minecraft:purple_terracotta
setblock 552 216 231 minecraft:light[level=11]
setblock 552 216 239 minecraft:light[level=11]
setblock 552 216 247 minecraft:light[level=11]
setblock 552 216 255 minecraft:light[level=11]
setblock 552 216 263 minecraft:light[level=11]
fill 552 216 270 552 278 270 minecraft:purple_terracotta
setblock 553 216 228 minecraft:magenta_terracotta
setblock 553 216 270 minecraft:magenta_terracotta
fill 554 216 228 554 265 228 minecraft:purple_terracotta
fill 554 216 270 554 278 270 minecraft:purple_terracotta
fill 556 216 228 556 278 228 minecraft:purple_terracotta
fill 556 216 270 556 278 270 minecraft:purple_terracotta
setblock 557 216 228 minecraft:magenta_terracotta
setblock 557 216 270 minecraft:magenta_terracotta
fill 558 216 228 558 278 228 minecraft:purple_terracotta
fill 558 216 270 558 278 270 minecraft:purple_terracotta
setblock 559 216 228 minecraft:magenta_terracotta
fill 559 216 231 559 278 231 minecraft:purple_terracotta
setblock 559 216 232 minecraft:magenta_terracotta
fill 559 216 233 559 278 233 minecraft:purple_terracotta
fill 559 216 235 559 278 235 minecraft:purple_terracotta
setblock 559 216 236 minecraft:magenta_terracotta
fill 559 216 237 559 278 237 minecraft:purple_terracotta
fill 559 216 239 559 272 239 minecraft:purple_terracotta
setblock 559 216 240 minecraft:magenta_terracotta
fill 559 216 241 559 278 241 minecraft:purple_terracotta
setblock 559 216 243 minecraft:purple_terracotta
setblock 559 216 244 minecraft:magenta_terracotta
fill 559 216 245 559 230 245 minecraft:purple_terracotta
fill 559 216 247 559 261 247 minecraft:purple_terracotta
setblock 559 216 248 minecraft:magenta_terracotta
setblock 559 216 249 minecraft:gray_terracotta
fill 559 216 251 559 218 251 minecraft:purple_terracotta
setblock 559 216 252 minecraft:magenta_terracotta
fill 559 216 253 559 278 253 minecraft:purple_terracotta
fill 559 216 255 559 274 255 minecraft:purple_terracotta
setblock 559 216 256 minecraft:magenta_terracotta
fill 559 216 257 559 265 257 minecraft:purple_terracotta
fill 559 216 259 559 278 259 minecraft:purple_terracotta
setblock 559 216 260 minecraft:magenta_terracotta
fill 559 216 261 559 217 261 minecraft:purple_terracotta
fill 559 216 263 559 278 263 minecraft:purple_terracotta
setblock 559 216 264 minecraft:magenta_terracotta
fill 559 216 265 559 248 265 minecraft:purple_terracotta
fill 559 216 267 559 278 267 minecraft:purple_terracotta
setblock 559 216 268 minecraft:magenta_terracotta
fill 559 216 269 559 278 269 minecraft:purple_terracotta
fill 517 217 228 517 219 228 minecraft:purple_terracotta
fill 517 217 232 517 219 232 minecraft:purple_terracotta
fill 517 217 236 517 219 236 minecraft:purple_terracotta
fill 517 217 240 517 219 240 minecraft:purple_terracotta
fill 517 217 244 517 219 244 minecraft:purple_terracotta
fill 517 217 248 517 219 248 minecraft:purple_terracotta
setblock 517 217 249 minecraft:black_terracotta
fill 517 217 252 517 219 252 minecraft:purple_terracotta
fill 517 217 256 517 219 256 minecraft:purple_terracotta
fill 517 217 260 517 219 260 minecraft:purple_terracotta
fill 517 217 264 517 219 264 minecraft:purple_terracotta
fill 517 217 268 517 219 268 minecraft:purple_terracotta
setblock 517 217 270 minecraft:purple_terracotta
fill 518 217 264 519 217 265 minecraft:dark_oak_planks
fill 519 217 266 519 217 267 minecraft:spruce_planks
fill 521 217 228 521 219 228 minecraft:purple_terracotta
fill 521 217 259 521 224 259 minecraft:iron_bars
fill 521 217 270 521 219 270 minecraft:purple_terracotta
fill 525 217 228 525 219 228 minecraft:purple_terracotta
fill 525 217 270 525 219 270 minecraft:purple_terracotta
fill 528 217 246 528 219 246 minecraft:dark_oak_planks
fill 528 217 249 528 219 249 minecraft:dark_oak_planks
fill 528 217 252 528 219 252 minecraft:dark_oak_planks
fill 528 217 255 528 219 255 minecraft:dark_oak_planks
fill 528 217 258 528 219 258 minecraft:dark_oak_planks
fill 529 217 228 529 219 228 minecraft:purple_terracotta
fill 529 217 270 529 219 270 minecraft:purple_terracotta
fill 530 217 244 530 219 244 minecraft:dark_oak_planks
fill 531 217 258 531 219 258 minecraft:dark_oak_planks
fill 533 217 228 533 219 228 minecraft:purple_terracotta
fill 533 217 244 533 219 244 minecraft:dark_oak_planks
fill 533 217 270 533 219 270 minecraft:purple_terracotta
fill 534 217 238 534 218 238 minecraft:white_stained_glass
fill 534 217 258 534 219 258 minecraft:dark_oak_planks
fill 536 217 244 536 219 244 minecraft:dark_oak_planks
fill 537 217 228 537 219 228 minecraft:purple_terracotta
fill 537 217 258 537 219 258 minecraft:dark_oak_planks
fill 537 217 270 537 219 270 minecraft:purple_terracotta
fill 539 217 244 539 219 244 minecraft:dark_oak_planks
fill 540 217 258 540 219 258 minecraft:dark_oak_planks
fill 541 217 228 541 219 228 minecraft:purple_terracotta
fill 541 217 270 541 219 270 minecraft:purple_terracotta
fill 542 217 244 542 219 244 minecraft:dark_oak_planks
fill 543 217 258 543 219 258 minecraft:dark_oak_planks
fill 545 217 228 545 219 228 minecraft:purple_terracotta
fill 545 217 244 545 219 244 minecraft:dark_oak_planks
fill 545 217 270 545 219 270 minecraft:purple_terracotta
fill 546 217 246 546 219 246 minecraft:dark_oak_planks
fill 546 217 249 546 219 249 minecraft:dark_oak_planks
fill 546 217 252 546 219 252 minecraft:dark_oak_planks
fill 546 217 255 546 219 255 minecraft:dark_oak_planks
fill 546 217 258 546 219 258 minecraft:dark_oak_planks
fill 549 217 228 549 219 228 minecraft:purple_terracotta
fill 549 217 270 549 219 270 minecraft:purple_terracotta
fill 553 217 228 553 219 228 minecraft:purple_terracotta
fill 553 217 270 553 219 270 minecraft:purple_terracotta
fill 557 217 228 557 219 228 minecraft:purple_terracotta
fill 557 217 270 557 219 270 minecraft:purple_terracotta
setblock 559 217 228 minecraft:purple_terracotta
fill 559 217 232 559 219 232 minecraft:purple_terracotta
fill 559 217 236 559 219 236 minecraft:purple_terracotta
fill 559 217 240 559 219 240 minecraft:purple_terracotta
setblock 559 217 243 minecraft:light_gray_terracotta
fill 559 217 244 559 219 244 minecraft:purple_terracotta
fill 559 217 248 559 219 249 minecraft:purple_terracotta
fill 559 217 252 559 219 252 minecraft:purple_terracotta
fill 559 217 256 559 219 256 minecraft:purple_terracotta
fill 559 217 260 559 219 260 minecraft:purple_terracotta
fill 559 217 264 559 219 264 minecraft:purple_terracotta
fill 559 217 268 559 219 268 minecraft:purple_terracotta
setblock 517 218 230 minecraft:magenta_terracotta
setblock 517 218 234 minecraft:magenta_terracotta
setblock 517 218 238 minecraft:magenta_terracotta
setblock 517 218 242 minecraft:magenta_terracotta
setblock 517 218 246 minecraft:magenta_terracotta
setblock 517 218 249 minecraft:purple_terracotta
setblock 517 218 250 minecraft:magenta_terracotta
setblock 517 218 254 minecraft:magenta_terracotta
setblock 517 218 258 minecraft:magenta_terracotta
setblock 517 218 262 minecraft:magenta_terracotta
fill 517 218 263 517 243 263 minecraft:purple_terracotta
fill 517 218 265 517 263 265 minecraft:purple_terracotta
setblock 517 218 266 minecraft:magenta_terracotta
setblock 517 218 270 minecraft:magenta_terracotta
fill 518 218 266 519 218 267 minecraft:dark_oak_planks
setblock 519 218 228 minecraft:magenta_terracotta
setblock 519 218 268 minecraft:spruce_planks
setblock 519 218 270 minecraft:magenta_terracotta
setblock 523 218 228 minecraft:magenta_terracotta
setblock 523 218 270 minecraft:magenta_terracotta
setblock 527 218 228 minecraft:magenta_terracotta
setblock 527 218 270 minecraft:magenta_terracotta
setblock 531 218 228 minecraft:magenta_terracotta
setblock 531 218 270 minecraft:magenta_terracotta
setblock 534 218 270 minecraft:gray_terracotta
setblock 535 218 228 minecraft:magenta_terracotta
fill 535 218 238 536 218 240 minecraft:white_concrete
setblock 535 218 270 minecraft:magenta_terracotta
fill 537 218 238 537 219 238 minecraft:white_stained_glass
fill 537 218 239 537 220 239 minecraft:white_concrete
setblock 537 218 240 minecraft:white_stained_glass
setblock 539 218 228 minecraft:magenta_terracotta
setblock 539 218 270 minecraft:magenta_terracotta
setblock 543 218 228 minecraft:magenta_terracotta
setblock 543 218 270 minecraft:magenta_terracotta
setblock 547 218 228 minecraft:magenta_terracotta
setblock 547 218 270 minecraft:magenta_terracotta
setblock 551 218 228 minecraft:magenta_terracotta
setblock 551 218 270 minecraft:magenta_terracotta
setblock 555 218 228 minecraft:magenta_terracotta
setblock 555 218 270 minecraft:magenta_terracotta
setblock 559 218 228 minecraft:magenta_terracotta
setblock 559 218 230 minecraft:magenta_terracotta
setblock 559 218 234 minecraft:magenta_terracotta
setblock 559 218 238 minecraft:magenta_terracotta
setblock 559 218 242 minecraft:magenta_terracotta
fill 559 218 243 559 278 243 minecraft:purple_terracotta
setblock 559 218 246 minecraft:magenta_terracotta
setblock 559 218 250 minecraft:magenta_terracotta
setblock 559 218 254 minecraft:magenta_terracotta
setblock 559 218 258 minecraft:magenta_terracotta
setblock 559 218 261 minecraft:black_terracotta
setblock 559 218 262 minecraft:magenta_terracotta
setblock 559 218 266 minecraft:magenta_terracotta
setblock 559 218 270 minecraft:magenta_terracotta
fill 517 219 230 517 221 230 minecraft:purple_terracotta
fill 517 219 234 517 221 234 minecraft:purple_terracotta
fill 517 219 238 517 221 238 minecraft:purple_terracotta
fill 517 219 242 517 221 242 minecraft:purple_terracotta
fill 517 219 246 517 221 246 minecraft:purple_terracotta
setblock 517 219 249 minecraft:light_gray_terracotta
fill 517 219 250 517 221 250 minecraft:purple_terracotta
fill 517 219 254 517 221 254 minecraft:purple_terracotta
fill 517 219 258 517 221 258 minecraft:purple_terracotta
fill 517 219 262 517 221 262 minecraft:purple_terracotta
fill 517 219 266 517 221 266 minecraft:purple_terracotta
setblock 517 219 270 minecraft:purple_terracotta
fill 518 219 268 519 219 269 minecraft:dark_oak_planks
fill 519 219 228 519 221 228 minecraft:purple_terracotta
fill 519 219 270 519 221 270 minecraft:purple_terracotta
fill 520 219 268 521 219 268 minecraft:spruce_planks
fill 523 219 228 523 221 228 minecraft:purple_terracotta
fill 523 219 270 523 221 270 minecraft:purple_terracotta
fill 527 219 228 527 221 228 minecraft:purple_terracotta
fill 527 219 270 527 221 270 minecraft:purple_terracotta
fill 531 219 228 531 221 228 minecraft:purple_terracotta
fill 531 219 270 531 221 270 minecraft:purple_terracotta
fill 534 219 239 536 219 240 minecraft:white_concrete
fill 534 219 270 535 221 270 minecraft:purple_terracotta
fill 535 219 228 535 221 228 minecraft:purple_terracotta
fill 535 219 238 536 219 238 minecraft:black_concrete
setblock 535 219 241 minecraft:white_stained_glass
setblock 536 219 241 minecraft:white_concrete
setblock 537 219 240 minecraft:white_concrete
fill 539 219 228 539 221 228 minecraft:purple_terracotta
fill 539 219 270 539 221 270 minecraft:purple_terracotta
fill 543 219 228 543 221 228 minecraft:purple_terracotta
fill 543 219 270 543 221 270 minecraft:purple_terracotta
fill 547 219 228 547 221 228 minecraft:purple_terracotta
fill 547 219 270 547 221 270 minecraft:purple_terracotta
fill 551 219 228 551 221 228 minecraft:purple_terracotta
fill 551 219 270 551 221 270 minecraft:purple_terracotta
fill 555 219 228 555 221 228 minecraft:purple_terracotta
fill 555 219 270 555 221 270 minecraft:purple_terracotta
setblock 559 219 228 minecraft:purple_terracotta
fill 559 219 230 559 221 230 minecraft:purple_terracotta
fill 559 219 234 559 221 234 minecraft:purple_terracotta
fill 559 219 238 559 221 238 minecraft:purple_terracotta
fill 559 219 242 559 221 242 minecraft:purple_terracotta
fill 559 219 246 559 221 246 minecraft:purple_terracotta
fill 559 219 250 559 221 250 minecraft:purple_terracotta
setblock 559 219 251 minecraft:light_gray_terracotta
fill 559 219 254 559 221 254 minecraft:purple_terracotta
fill 559 219 258 559 221 258 minecraft:purple_terracotta
fill 559 219 261 559 221 262 minecraft:purple_terracotta
fill 559 219 266 559 221 266 minecraft:purple_terracotta
fill 559 219 270 559 221 270 minecraft:purple_terracotta
setblock 517 220 228 minecraft:magenta_terracotta
setblock 517 220 232 minecraft:magenta_terracotta
setblock 517 220 236 minecraft:magenta_terracotta
setblock 517 220 240 minecraft:magenta_terracotta
setblock 517 220 244 minecraft:magenta_terracotta
setblock 517 220 248 minecraft:magenta_terracotta
fill 517 220 249 517 278 249 minecraft:purple_terracotta
setblock 517 220 252 minecraft:magenta_terracotta
setblock 517 220 256 minecraft:magenta_terracotta
setblock 517 220 260 minecraft:magenta_terracotta
setblock 517 220 264 minecraft:magenta_terracotta
setblock 517 220 268 minecraft:magenta_terracotta
setblock 517 220 270 minecraft:magenta_terracotta
setblock 520 220 231 minecraft:light[level=12]
setblock 520 220 238 minecraft:light[level=12]
setblock 520 220 245 minecraft:light[level=12]
setblock 520 220 252 minecraft:light[level=12]
setblock 520 220 259 minecraft:light[level=12]
setblock 520 220 266 minecraft:light[level=12]
fill 520 220 268 521 220 269 minecraft:dark_oak_planks
setblock 521 220 228 minecraft:magenta_terracotta
setblock 521 220 270 minecraft:magenta_terracotta
fill 522 220 268 523 220 268 minecraft:spruce_planks
setblock 525 220 228 minecraft:magenta_terracotta
setblock 525 220 270 minecraft:magenta_terracotta
setblock 527 220 231 minecraft:light[level=12]
setblock 527 220 238 minecraft:light[level=12]
setblock 527 220 245 minecraft:light[level=12]
setblock 527 220 252 minecraft:light[level=12]
setblock 527 220 259 minecraft:light[level=12]
setblock 527 220 266 minecraft:light[level=12]
setblock 528 220 246 minecraft:ochre_froglight
setblock 528 220 249 minecraft:ochre_froglight
setblock 528 220 252 minecraft:ochre_froglight
setblock 528 220 255 minecraft:ochre_froglight
setblock 528 220 258 minecraft:ochre_froglight
setblock 529 220 228 minecraft:magenta_terracotta
setblock 529 220 270 minecraft:magenta_terracotta
setblock 530 220 244 minecraft:ochre_froglight
setblock 531 220 258 minecraft:ochre_froglight
setblock 533 220 228 minecraft:magenta_terracotta
setblock 533 220 244 minecraft:ochre_froglight
setblock 533 220 270 minecraft:magenta_terracotta
setblock 534 220 231 minecraft:light[level=12]
setblock 534 220 238 minecraft:light[level=12]
setblock 534 220 245 minecraft:light[level=12]
setblock 534 220 258 minecraft:ochre_froglight
setblock 534 220 259 minecraft:light[level=12]
setblock 534 220 266 minecraft:light[level=12]
fill 535 220 238 536 220 240 minecraft:white_concrete
setblock 536 220 244 minecraft:ochre_froglight
setblock 537 220 228 minecraft:magenta_terracotta
setblock 537 220 258 minecraft:ochre_froglight
setblock 537 220 270 minecraft:black_terracotta
setblock 539 220 244 minecraft:ochre_froglight
setblock 540 220 258 minecraft:ochre_froglight
setblock 541 220 228 minecraft:magenta_terracotta
setblock 541 220 231 minecraft:light[level=12]
setblock 541 220 238 minecraft:light[level=12]
setblock 541 220 245 minecraft:light[level=12]
setblock 541 220 259 minecraft:light[level=12]
setblock 541 220 266 minecraft:light[level=12]
setblock 541 220 270 minecraft:magenta_terracotta
setblock 542 220 244 minecraft:ochre_froglight
setblock 543 220 258 minecraft:ochre_froglight
setblock 545 220 228 minecraft:magenta_terracotta
setblock 545 220 244 minecraft:ochre_froglight
setblock 545 220 270 minecraft:magenta_terracotta
setblock 546 220 246 minecraft:ochre_froglight
setblock 546 220 249 minecraft:ochre_froglight
setblock 546 220 252 minecraft:ochre_froglight
setblock 546 220 255 minecraft:ochre_froglight
setblock 546 220 258 minecraft:ochre_froglight
setblock 548 220 231 minecraft:light[level=12]
setblock 548 220 238 minecraft:light[level=12]
setblock 548 220 245 minecraft:light[level=12]
setblock 548 220 252 minecraft:light[level=12]
setblock 548 220 259 minecraft:light[level=12]
setblock 548 220 266 minecraft:light[level=12]
setblock 549 220 228 minecraft:magenta_terracotta
setblock 549 220 270 minecraft:magenta_terracotta
setblock 553 220 228 minecraft:magenta_terracotta
setblock 553 220 270 minecraft:magenta_terracotta
setblock 555 220 231 minecraft:light[level=12]
setblock 555 220 238 minecraft:light[level=12]
setblock 555 220 245 minecraft:light[level=12]
setblock 555 220 252 minecraft:light[level=12]
setblock 555 220 259 minecraft:light[level=12]
setblock 555 220 266 minecraft:light[level=12]
setblock 557 220 228 minecraft:magenta_terracotta
setblock 557 220 270 minecraft:magenta_terracotta
setblock 559 220 228 minecraft:magenta_terracotta
setblock 559 220 232 minecraft:magenta_terracotta
setblock 559 220 236 minecraft:magenta_terracotta
setblock 559 220 240 minecraft:magenta_terracotta
setblock 559 220 244 minecraft:magenta_terracotta
setblock 559 220 248 minecraft:magenta_terracotta
fill 559 220 249 559 278 249 minecraft:purple_terracotta
fill 559 220 251 559 253 251 minecraft:purple_terracotta
setblock 559 220 252 minecraft:magenta_terracotta
setblock 559 220 256 minecraft:magenta_terracotta
setblock 559 220 260 minecraft:magenta_terracotta
setblock 559 220 264 minecraft:magenta_terracotta
setblock 559 220 268 minecraft:magenta_terracotta
fill 517 221 228 517 223 228 minecraft:purple_terracotta
fill 517 221 232 517 223 232 minecraft:purple_terracotta
fill 517 221 236 517 223 236 minecraft:purple_terracotta
fill 517 221 240 517 223 240 minecraft:purple_terracotta
fill 517 221 244 517 223 244 minecraft:purple_terracotta
fill 517 221 248 517 223 248 minecraft:purple_terracotta
fill 517 221 252 517 223 252 minecraft:purple_terracotta
fill 517 221 256 517 223 256 minecraft:purple_terracotta
fill 517 221 260 517 223 260 minecraft:purple_terracotta
fill 517 221 264 517 223 264 minecraft:purple_terracotta
fill 517 221 268 517 223 268 minecraft:purple_terracotta
setblock 517 221 270 minecraft:purple_terracotta
fill 521 221 228 521 223 228 minecraft:purple_terracotta
fill 521 221 270 521 223 270 minecraft:purple_terracotta
fill 522 221 268 523 221 269 minecraft:dark_oak_planks
fill 524 221 268 525 221 268 minecraft:spruce_planks
fill 525 221 228 525 223 228 minecraft:purple_terracotta
fill 525 221 270 525 223 270 minecraft:purple_terracotta
fill 528 221 246 531 221 246 minecraft:dark_oak_planks
fill 528 221 249 531 221 249 minecraft:dark_oak_planks
fill 528 221 252 531 221 252 minecraft:dark_oak_planks
fill 528 221 255 531 221 255 minecraft:dark_oak_planks
setblock 528 221 258 minecraft:dark_oak_planks
fill 529 221 228 529 223 228 minecraft:purple_terracotta
fill 529 221 245 545 221 245 minecraft:dark_oak_planks
fill 529 221 247 531 221 248 minecraft:dark_oak_planks
fill 529 221 250 531 221 251 minecraft:dark_oak_planks
fill 529 221 253 531 221 254 minecraft:dark_oak_planks
fill 529 221 256 531 221 257 minecraft:dark_oak_planks
fill 529 221 270 529 223 270 minecraft:purple_terracotta
setblock 530 221 244 minecraft:dark_oak_planks
setblock 531 221 258 minecraft:dark_oak_planks
fill 532 221 257 545 221 257 minecraft:dark_oak_planks
fill 533 221 228 533 223 228 minecraft:purple_terracotta
setblock 533 221 244 minecraft:dark_oak_planks
fill 533 221 270 533 223 270 minecraft:purple_terracotta
setblock 534 221 258 minecraft:dark_oak_planks
setblock 536 221 244 minecraft:dark_oak_planks
fill 537 221 228 537 223 228 minecraft:purple_terracotta
setblock 537 221 258 minecraft:dark_oak_planks
fill 537 221 270 537 223 270 minecraft:purple_terracotta
setblock 539 221 244 minecraft:dark_oak_planks
setblock 540 221 258 minecraft:dark_oak_planks
fill 541 221 228 541 223 228 minecraft:purple_terracotta
fill 541 221 270 541 223 270 minecraft:purple_terracotta
setblock 542 221 244 minecraft:dark_oak_planks
fill 543 221 246 545 221 256 minecraft:dark_oak_planks
setblock 543 221 258 minecraft:dark_oak_planks
fill 545 221 228 545 223 228 minecraft:purple_terracotta
setblock 545 221 244 minecraft:dark_oak_planks
fill 545 221 270 545 223 270 minecraft:purple_terracotta
setblock 546 221 246 minecraft:dark_oak_planks
setblock 546 221 249 minecraft:dark_oak_planks
setblock 546 221 252 minecraft:dark_oak_planks
setblock 546 221 255 minecraft:dark_oak_planks
setblock 546 221 258 minecraft:dark_oak_planks
fill 549 221 228 549 223 228 minecraft:purple_terracotta
fill 549 221 270 549 223 270 minecraft:purple_terracotta
fill 553 221 228 553 223 228 minecraft:purple_terracotta
fill 553 221 270 553 223 270 minecraft:purple_terracotta
fill 557 221 228 557 223 228 minecraft:purple_terracotta
fill 557 221 270 557 223 270 minecraft:purple_terracotta
setblock 559 221 228 minecraft:purple_terracotta
fill 559 221 232 559 223 232 minecraft:purple_terracotta
fill 559 221 236 559 223 236 minecraft:purple_terracotta
fill 559 221 240 559 223 240 minecraft:purple_terracotta
fill 559 221 244 559 223 244 minecraft:purple_terracotta
fill 559 221 248 559 223 248 minecraft:purple_terracotta
fill 559 221 252 559 223 252 minecraft:purple_terracotta
fill 559 221 256 559 223 256 minecraft:purple_terracotta
fill 559 221 260 559 223 260 minecraft:purple_terracotta
fill 559 221 264 559 223 264 minecraft:purple_terracotta
fill 559 221 268 559 223 268 minecraft:purple_terracotta
setblock 517 222 230 minecraft:magenta_terracotta
setblock 517 222 234 minecraft:magenta_terracotta
setblock 517 222 238 minecraft:magenta_terracotta
setblock 517 222 242 minecraft:magenta_terracotta
setblock 517 222 246 minecraft:magenta_terracotta
setblock 517 222 250 minecraft:magenta_terracotta
setblock 517 222 254 minecraft:magenta_terracotta
setblock 517 222 258 minecraft:magenta_terracotta
setblock 517 222 262 minecraft:magenta_terracotta
setblock 517 222 266 minecraft:magenta_terracotta
setblock 517 222 270 minecraft:magenta_terracotta
setblock 519 222 228 minecraft:magenta_terracotta
setblock 519 222 270 minecraft:magenta_terracotta
setblock 523 222 228 minecraft:magenta_terracotta
setblock 523 222 270 minecraft:magenta_terracotta
fill 524 222 268 525 222 269 minecraft:dark_oak_planks
fill 526 222 268 527 222 268 minecraft:spruce_planks
setblock 527 222 228 minecraft:magenta_terracotta
setblock 527 222 270 minecraft:magenta_terracotta
fill 528 222 244 531 222 258 minecraft:deepslate_tiles
setblock 530 222 270 minecraft:black_terracotta
setblock 531 222 228 minecraft:magenta_terracotta
setblock 531 222 270 minecraft:magenta_terracotta
fill 532 222 244 546 222 245 minecraft:deepslate_tiles
fill 532 222 257 546 222 258 minecraft:deepslate_tiles
fill 534 222 270 534 243 270 minecraft:purple_terracotta
setblock 535 222 228 minecraft:magenta_terracotta
setblock 535 222 270 minecraft:magenta_terracotta
setblock 539 222 228 minecraft:magenta_terracotta
setblock 539 222 270 minecraft:magenta_terracotta
setblock 543 222 228 minecraft:magenta_terracotta
fill 543 222 246 546 222 256 minecraft:deepslate_tiles
setblock 543 222 270 minecraft:magenta_terracotta
setblock 547 222 228 minecraft:magenta_terracotta
setblock 547 222 270 minecraft:magenta_terracotta
setblock 551 222 228 minecraft:magenta_terracotta
setblock 551 222 270 minecraft:magenta_terracotta
setblock 555 222 228 minecraft:magenta_terracotta
setblock 555 222 270 minecraft:magenta_terracotta
setblock 559 222 228 minecraft:magenta_terracotta
setblock 559 222 230 minecraft:magenta_terracotta
setblock 559 222 234 minecraft:magenta_terracotta
setblock 559 222 238 minecraft:magenta_terracotta
setblock 559 222 242 minecraft:magenta_terracotta
setblock 559 222 246 minecraft:magenta_terracotta
setblock 559 222 250 minecraft:magenta_terracotta
setblock 559 222 254 minecraft:magenta_terracotta
setblock 559 222 258 minecraft:magenta_terracotta
fill 559 222 261 559 278 261 minecraft:purple_terracotta
setblock 559 222 262 minecraft:magenta_terracotta
setblock 559 222 266 minecraft:magenta_terracotta
setblock 559 222 270 minecraft:magenta_terracotta
fill 517 223 230 517 225 230 minecraft:purple_terracotta
fill 517 223 234 517 225 234 minecraft:purple_terracotta
fill 517 223 238 517 225 238 minecraft:purple_terracotta
fill 517 223 242 517 225 242 minecraft:purple_terracotta
fill 517 223 246 517 225 246 minecraft:purple_terracotta
fill 517 223 250 517 225 250 minecraft:purple_terracotta
fill 517 223 254 517 225 254 minecraft:purple_terracotta
fill 517 223 258 517 225 258 minecraft:purple_terracotta
setblock 517 223 262 minecraft:black_terracotta
fill 517 223 266 517 225 266 minecraft:purple_terracotta
setblock 517 223 270 minecraft:purple_terracotta
fill 519 223 228 519 225 228 minecraft:purple_terracotta
fill 519 223 270 519 225 270 minecraft:purple_terracotta
fill 523 223 228 523 225 228 minecraft:purple_terracotta
fill 523 223 270 523 225 270 minecraft:purple_terracotta
fill 526 223 268 527 223 269 minecraft:dark_oak_planks
fill 527 223 228 527 225 228 minecraft:purple_terracotta
fill 527 223 270 527 225 270 minecraft:purple_terracotta
fill 528 223 268 529 223 268 minecraft:spruce_planks
fill 529 223 245 531 223 257 minecraft:deepslate_tiles
fill 530 223 270 531 225 270 minecraft:purple_terracotta
fill 531 223 228 531 225 228 minecraft:purple_terracotta
fill 532 223 245 545 223 245 minecraft:deepslate_tiles
fill 532 223 257 545 223 257 minecraft:deepslate_tiles
fill 535 223 228 535 225 228 minecraft:purple_terracotta
fill 535 223 270 535 225 270 minecraft:purple_terracotta
fill 539 223 228 539 225 228 minecraft:purple_terracotta
fill 539 223 270 539 225 270 minecraft:purple_terracotta
fill 543 223 228 543 225 228 minecraft:purple_terracotta
fill 543 223 246 545 223 256 minecraft:deepslate_tiles
fill 543 223 270 543 225 270 minecraft:purple_terracotta
fill 547 223 228 547 225 228 minecraft:purple_terracotta
fill 547 223 270 547 225 270 minecraft:purple_terracotta
fill 551 223 228 551 225 228 minecraft:purple_terracotta
fill 551 223 270 551 225 270 minecraft:purple_terracotta
fill 555 223 228 555 225 228 minecraft:purple_terracotta
fill 555 223 270 555 225 270 minecraft:purple_terracotta
setblock 559 223 228 minecraft:purple_terracotta
fill 559 223 230 559 225 230 minecraft:purple_terracotta
fill 559 223 234 559 225 234 minecraft:purple_terracotta
fill 559 223 238 559 225 238 minecraft:purple_terracotta
fill 559 223 242 559 225 242 minecraft:purple_terracotta
fill 559 223 246 559 225 246 minecraft:purple_terracotta
fill 559 223 250 559 225 250 minecraft:purple_terracotta
fill 559 223 254 559 225 254 minecraft:purple_terracotta
fill 559 223 258 559 225 258 minecraft:purple_terracotta
fill 559 223 262 559 225 262 minecraft:purple_terracotta
fill 559 223 266 559 225 266 minecraft:purple_terracotta
fill 559 223 270 559 225 270 minecraft:purple_terracotta
setblock 517 224 228 minecraft:magenta_terracotta
setblock 517 224 232 minecraft:magenta_terracotta
setblock 517 224 236 minecraft:black_terracotta
setblock 517 224 240 minecraft:magenta_terracotta
setblock 517 224 244 minecraft:magenta_terracotta
setblock 517 224 248 minecraft:magenta_terracotta
setblock 517 224 252 minecraft:magenta_terracotta
setblock 517 224 256 minecraft:magenta_terracotta
setblock 517 224 260 minecraft:magenta_terracotta
fill 517 224 262 517 225 262 minecraft:purple_terracotta
setblock 517 224 264 minecraft:magenta_terracotta
setblock 517 224 268 minecraft:magenta_terracotta
setblock 517 224 270 minecraft:magenta_terracotta
setblock 520 224 231 minecraft:light[level=11]
setblock 520 224 239 minecraft:light[level=11]
setblock 520 224 247 minecraft:light[level=11]
setblock 520 224 255 minecraft:light[level=11]
setblock 520 224 263 minecraft:light[level=11]
setblock 521 224 228 minecraft:magenta_terracotta
setblock 521 224 270 minecraft:magenta_terracotta
setblock 525 224 228 minecraft:magenta_terracotta
setblock 525 224 270 minecraft:magenta_terracotta
setblock 528 224 231 minecraft:light[level=11]
setblock 528 224 239 minecraft:light[level=11]
setblock 528 224 247 minecraft:light[level=11]
setblock 528 224 255 minecraft:light[level=11]
setblock 528 224 263 minecraft:light[level=11]
fill 528 224 268 529 224 269 minecraft:dark_oak_planks
setblock 529 224 228 minecraft:magenta_terracotta
setblock 529 224 270 minecraft:magenta_terracotta
fill 530 224 246 531 224 256 minecraft:deepslate_tiles
fill 530 224 268 531 224 268 minecraft:spruce_planks
setblock 533 224 228 minecraft:magenta_terracotta
setblock 533 224 270 minecraft:magenta_terracotta
setblock 536 224 231 minecraft:light[level=11]
setblock 536 224 239 minecraft:light[level=11]
setblock 536 224 263 minecraft:light[level=11]
setblock 537 224 228 minecraft:magenta_terracotta
setblock 537 224 270 minecraft:magenta_terracotta
setblock 541 224 228 minecraft:magenta_terracotta
setblock 541 224 270 minecraft:magenta_terracotta
fill 543 224 246 544 224 256 minecraft:deepslate_tiles
setblock 544 224 231 minecraft:light[level=11]
setblock 544 224 239 minecraft:light[level=11]
setblock 544 224 263 minecraft:light[level=11]
setblock 545 224 228 minecraft:magenta_terracotta
setblock 545 224 270 minecraft:magenta_terracotta
setblock 549 224 228 minecraft:magenta_terracotta
setblock 549 224 270 minecraft:magenta_terracotta
setblock 552 224 231 minecraft:light[level=11]
setblock 552 224 239 minecraft:light[level=11]
setblock 552 224 247 minecraft:light[level=11]
setblock 552 224 255 minecraft:light[level=11]
setblock 552 224 263 minecraft:light[level=11]
setblock 553 224 228 minecraft:magenta_terracotta
setblock 553 224 270 minecraft:magenta_terracotta
setblock 557 224 228 minecraft:magenta_terracotta
setblock 557 224 270 minecraft:magenta_terracotta
setblock 559 224 228 minecraft:magenta_terracotta
setblock 559 224 232 minecraft:magenta_terracotta
setblock 559 224 236 minecraft:magenta_terracotta
setblock 559 224 240 minecraft:magenta_terracotta
setblock 559 224 244 minecraft:magenta_terracotta
setblock 559 224 248 minecraft:magenta_terracotta
setblock 559 224 252 minecraft:magenta_terracotta
setblock 559 224 256 minecraft:magenta_terracotta
setblock 559 224 260 minecraft:magenta_terracotta
setblock 559 224 264 minecraft:magenta_terracotta
setblock 559 224 268 minecraft:magenta_terracotta
fill 517 225 228 517 227 228 minecraft:purple_terracotta
fill 517 225 232 517 227 232 minecraft:purple_terracotta
fill 517 225 236 517 227 236 minecraft:purple_terracotta
fill 517 225 240 517 227 240 minecraft:purple_terracotta
fill 517 225 244 517 227 244 minecraft:purple_terracotta
fill 517 225 248 517 227 248 minecraft:purple_terracotta
fill 517 225 252 517 227 252 minecraft:purple_terracotta
fill 517 225 256 517 227 256 minecraft:purple_terracotta
fill 517 225 260 517 227 260 minecraft:purple_terracotta
fill 517 225 264 517 227 264 minecraft:purple_terracotta
fill 517 225 268 517 227 268 minecraft:purple_terracotta
setblock 517 225 270 minecraft:purple_terracotta
fill 521 225 228 521 227 228 minecraft:purple_terracotta
fill 521 225 270 521 227 270 minecraft:purple_terracotta
fill 525 225 228 525 227 228 minecraft:purple_terracotta
fill 525 225 270 525 227 270 minecraft:purple_terracotta
fill 529 225 228 529 227 228 minecraft:purple_terracotta
fill 529 225 270 529 227 270 minecraft:purple_terracotta
fill 530 225 268 531 225 269 minecraft:dark_oak_planks
fill 531 225 247 531 225 255 minecraft:deepslate_tiles
fill 532 225 268 533 225 268 minecraft:spruce_planks
fill 533 225 228 533 227 228 minecraft:purple_terracotta
fill 533 225 270 533 227 270 minecraft:purple_terracotta
fill 537 225 228 537 227 228 minecraft:purple_terracotta
fill 537 225 270 537 227 270 minecraft:purple_terracotta
fill 541 225 228 541 227 228 minecraft:purple_terracotta
fill 541 225 270 541 227 270 minecraft:purple_terracotta
fill 543 225 247 543 225 255 minecraft:deepslate_tiles
fill 545 225 228 545 227 228 minecraft:purple_terracotta
fill 545 225 270 545 227 270 minecraft:purple_terracotta
fill 549 225 228 549 227 228 minecraft:purple_terracotta
fill 549 225 270 549 227 270 minecraft:purple_terracotta
fill 553 225 228 553 227 228 minecraft:purple_terracotta
fill 553 225 270 553 227 270 minecraft:purple_terracotta
fill 557 225 228 557 227 228 minecraft:purple_terracotta
fill 557 225 270 557 227 270 minecraft:purple_terracotta
setblock 559 225 228 minecraft:purple_terracotta
fill 559 225 232 559 227 232 minecraft:purple_terracotta
fill 559 225 236 559 227 236 minecraft:purple_terracotta
fill 559 225 240 559 227 240 minecraft:purple_terracotta
fill 559 225 244 559 227 244 minecraft:purple_terracotta
fill 559 225 248 559 227 248 minecraft:purple_terracotta
fill 559 225 252 559 227 252 minecraft:purple_terracotta
fill 559 225 256 559 227 256 minecraft:purple_terracotta
fill 559 225 260 559 227 260 minecraft:purple_terracotta
fill 559 225 264 559 227 264 minecraft:purple_terracotta
fill 559 225 268 559 227 268 minecraft:purple_terracotta
setblock 517 226 230 minecraft:magenta_terracotta
setblock 517 226 234 minecraft:magenta_terracotta
setblock 517 226 238 minecraft:magenta_terracotta
setblock 517 226 242 minecraft:magenta_terracotta
setblock 517 226 246 minecraft:magenta_terracotta
setblock 517 226 250 minecraft:magenta_terracotta
setblock 517 226 254 minecraft:magenta_terracotta
setblock 517 226 258 minecraft:magenta_terracotta
setblock 517 226 262 minecraft:magenta_terracotta
setblock 517 226 266 minecraft:magenta_terracotta
setblock 517 226 270 minecraft:magenta_terracotta
setblock 519 226 228 minecraft:magenta_terracotta
setblock 519 226 270 minecraft:magenta_terracotta
setblock 520 226 231 minecraft:light[level=12]
setblock 520 226 238 minecraft:light[level=12]
setblock 520 226 245 minecraft:light[level=12]
setblock 520 226 252 minecraft:light[level=12]
setblock 520 226 259 minecraft:light[level=12]
setblock 520 226 266 minecraft:light[level=12]
setblock 523 226 228 minecraft:magenta_terracotta
setblock 523 226 270 minecraft:magenta_terracotta
setblock 527 226 228 minecraft:magenta_terracotta
setblock 527 226 231 minecraft:light[level=12]
setblock 527 226 238 minecraft:light[level=12]
setblock 527 226 245 minecraft:light[level=12]
setblock 527 226 252 minecraft:light[level=12]
setblock 527 226 259 minecraft:light[level=12]
setblock 527 226 266 minecraft:light[level=12]
setblock 527 226 270 minecraft:magenta_terracotta
fill 530 226 270 530 263 270 minecraft:purple_terracotta
setblock 531 226 228 minecraft:magenta_terracotta
setblock 531 226 270 minecraft:magenta_terracotta
fill 532 226 268 533 226 269 minecraft:dark_oak_planks
setblock 534 226 231 minecraft:light[level=12]
setblock 534 226 238 minecraft:light[level=12]
setblock 534 226 245 minecraft:light[level=12]
setblock 534 226 259 minecraft:light[level=12]
setblock 534 226 266 minecraft:light[level=12]
fill 534 226 268 535 226 268 minecraft:spruce_planks
setblock 535 226 228 minecraft:magenta_terracotta
setblock 535 226 270 minecraft:magenta_terracotta
setblock 539 226 228 minecraft:magenta_terracotta
setblock 539 226 270 minecraft:magenta_terracotta
setblock 541 226 231 minecraft:light[level=12]
setblock 541 226 238 minecraft:light[level=12]
setblock 541 226 245 minecraft:light[level=12]
setblock 541 226 259 minecraft:light[level=12]
setblock 541 226 266 minecraft:light[level=12]
setblock 543 226 228 minecraft:magenta_terracotta
setblock 543 226 270 minecraft:magenta_terracotta
setblock 547 226 228 minecraft:magenta_terracotta
setblock 547 226 270 minecraft:magenta_terracotta
setblock 548 226 231 minecraft:light[level=12]
setblock 548 226 238 minecraft:light[level=12]
setblock 548 226 245 minecraft:light[level=12]
setblock 548 226 252 minecraft:light[level=12]
setblock 548 226 259 minecraft:light[level=12]
setblock 548 226 266 minecraft:light[level=12]
setblock 551 226 228 minecraft:magenta_terracotta
setblock 551 226 270 minecraft:magenta_terracotta
setblock 555 226 228 minecraft:magenta_terracotta
setblock 555 226 231 minecraft:light[level=12]
setblock 555 226 238 minecraft:light[level=12]
setblock 555 226 245 minecraft:light[level=12]
setblock 555 226 252 minecraft:light[level=12]
setblock 555 226 259 minecraft:light[level=12]
setblock 555 226 266 minecraft:light[level=12]
setblock 555 226 270 minecraft:magenta_terracotta
setblock 559 226 228 minecraft:magenta_terracotta
setblock 559 226 230 minecraft:magenta_terracotta
setblock 559 226 234 minecraft:magenta_terracotta
setblock 559 226 238 minecraft:gray_terracotta
setblock 559 226 242 minecraft:magenta_terracotta
setblock 559 226 246 minecraft:magenta_terracotta
setblock 559 226 250 minecraft:magenta_terracotta
setblock 559 226 254 minecraft:magenta_terracotta
setblock 559 226 258 minecraft:magenta_terracotta
setblock 559 226 262 minecraft:magenta_terracotta
setblock 559 226 266 minecraft:magenta_terracotta
setblock 559 226 270 minecraft:magenta_terracotta
fill 517 227 230 517 229 230 minecraft:purple_terracotta
fill 517 227 234 517 229 234 minecraft:purple_terracotta
fill 517 227 238 517 229 238 minecraft:purple_terracotta
fill 517 227 242 517 229 242 minecraft:purple_terracotta
fill 517 227 246 517 229 246 minecraft:purple_terracotta
fill 517 227 250 517 229 250 minecraft:purple_terracotta
fill 517 227 254 517 229 254 minecraft:purple_terracotta
fill 517 227 258 517 229 258 minecraft:purple_terracotta
fill 517 227 262 517 229 262 minecraft:purple_terracotta
fill 517 227 266 517 229 266 minecraft:purple_terracotta
setblock 517 227 270 minecraft:purple_terracotta
fill 519 227 228 519 229 228 minecraft:purple_terracotta
fill 519 227 270 519 229 270 minecraft:purple_terracotta
fill 523 227 228 523 229 228 minecraft:purple_terracotta
fill 523 227 270 523 229 270 minecraft:purple_terracotta
fill 527 227 228 527 229 228 minecraft:purple_terracotta
fill 527 227 270 527 229 270 minecraft:purple_terracotta
fill 529 227 269 533 227 269 minecraft:gold_block
fill 531 227 228 531 229 228 minecraft:purple_terracotta
fill 531 227 270 531 229 270 minecraft:purple_terracotta
setblock 532 227 270 minecraft:light_gray_terracotta
fill 534 227 268 535 227 269 minecraft:dark_oak_planks
fill 535 227 228 535 229 228 minecraft:purple_terracotta
fill 535 227 270 535 229 270 minecraft:purple_terracotta
fill 536 227 268 537 227 268 minecraft:spruce_planks
fill 539 227 228 539 229 228 minecraft:purple_terracotta
fill 539 227 229 543 227 229 minecraft:gold_block
fill 539 227 270 539 229 270 minecraft:purple_terracotta
fill 543 227 228 543 229 228 minecraft:purple_terracotta
fill 543 227 270 543 229 270 minecraft:purple_terracotta
fill 547 227 228 547 229 228 minecraft:purple_terracotta
fill 547 227 270 547 229 270 minecraft:purple_terracotta
fill 551 227 228 551 229 228 minecraft:purple_terracotta
fill 551 227 270 551 229 270 minecraft:purple_terracotta
setblock 552 227 228 minecraft:black_terracotta
fill 555 227 228 555 229 228 minecraft:purple_terracotta
fill 555 227 270 555 229 270 minecraft:purple_terracotta
setblock 559 227 228 minecraft:purple_terracotta
fill 559 227 230 559 229 230 minecraft:purple_terracotta
fill 559 227 234 559 229 234 minecraft:purple_terracotta
fill 559 227 238 559 229 238 minecraft:purple_terracotta
fill 559 227 242 559 229 242 minecraft:purple_terracotta
fill 559 227 246 559 229 246 minecraft:purple_terracotta
fill 559 227 250 559 229 250 minecraft:purple_terracotta
fill 559 227 254 559 229 254 minecraft:purple_terracotta
fill 559 227 258 559 229 258 minecraft:purple_terracotta
fill 559 227 262 559 229 262 minecraft:purple_terracotta
fill 559 227 266 559 229 266 minecraft:purple_terracotta
fill 559 227 270 559 229 270 minecraft:purple_terracotta
setblock 517 228 228 minecraft:magenta_terracotta
setblock 517 228 232 minecraft:magenta_terracotta
setblock 517 228 236 minecraft:magenta_terracotta
setblock 517 228 240 minecraft:magenta_terracotta
setblock 517 228 244 minecraft:magenta_terracotta
setblock 517 228 248 minecraft:magenta_terracotta
setblock 517 228 252 minecraft:magenta_terracotta
setblock 517 228 256 minecraft:magenta_terracotta
setblock 517 228 260 minecraft:magenta_terracotta
setblock 517 228 264 minecraft:magenta_terracotta
setblock 517 228 268 minecraft:magenta_terracotta
setblock 517 228 270 minecraft:magenta_terracotta
setblock 520 228 270 minecraft:light_gray_terracotta
setblock 521 228 228 minecraft:magenta_terracotta
setblock 521 228 270 minecraft:magenta_terracotta
setblock 525 228 228 minecraft:magenta_terracotta
setblock 525 228 270 minecraft:magenta_terracotta
setblock 529 228 228 minecraft:magenta_terracotta
fill 529 228 269 529 233 269 minecraft:gold_block
setblock 529 228 270 minecraft:magenta_terracotta
fill 530 228 269 532 229 269 minecraft:brown_concrete
fill 532 228 270 532 278 270 minecraft:purple_terracotta
setblock 533 228 228 minecraft:magenta_terracotta
fill 533 228 269 533 233 269 minecraft:gold_block
setblock 533 228 270 minecraft:magenta_terracotta
fill 536 228 268 537 228 269 minecraft:dark_oak_planks
setblock 537 228 228 minecraft:magenta_terracotta
setblock 537 228 270 minecraft:magenta_terracotta
fill 538 228 268 539 228 268 minecraft:spruce_planks
fill 539 228 229 539 233 229 minecraft:gold_block
fill 540 228 229 542 229 229 minecraft:red_terracotta
setblock 541 228 228 minecraft:magenta_terracotta
setblock 541 228 270 minecraft:magenta_terracotta
fill 543 228 229 543 233 229 minecraft:gold_block
setblock 545 228 228 minecraft:magenta_terracotta
setblock 545 228 270 minecraft:magenta_terracotta
setblock 549 228 228 minecraft:magenta_terracotta
setblock 549 228 270 minecraft:magenta_terracotta
fill 552 228 228 552 278 228 minecraft:purple_terracotta
setblock 553 228 228 minecraft:magenta_terracotta
setblock 553 228 270 minecraft:magenta_terracotta
setblock 557 228 228 minecraft:magenta_terracotta
setblock 557 228 270 minecraft:magenta_terracotta
setblock 559 228 228 minecraft:magenta_terracotta
setblock 559 228 232 minecraft:magenta_terracotta
setblock 559 228 236 minecraft:magenta_terracotta
setblock 559 228 240 minecraft:magenta_terracotta
setblock 559 228 244 minecraft:magenta_terracotta
setblock 559 228 248 minecraft:magenta_terracotta
setblock 559 228 252 minecraft:magenta_terracotta
setblock 559 228 256 minecraft:magenta_terracotta
setblock 559 228 260 minecraft:magenta_terracotta
setblock 559 228 264 minecraft:magenta_terracotta
setblock 559 228 268 minecraft:magenta_terracotta
fill 517 229 228 517 231 228 minecraft:purple_terracotta
fill 517 229 232 517 231 232 minecraft:purple_terracotta
fill 517 229 236 517 231 236 minecraft:purple_terracotta
fill 517 229 240 517 231 240 minecraft:purple_terracotta
setblock 517 229 243 minecraft:light_gray_terracotta
fill 517 229 244 517 231 244 minecraft:purple_terracotta
fill 517 229 248 517 231 248 minecraft:purple_terracotta
fill 517 229 252 517 231 252 minecraft:purple_terracotta
fill 517 229 256 517 231 256 minecraft:purple_terracotta
fill 517 229 260 517 231 260 minecraft:purple_terracotta
fill 517 229 264 517 231 264 minecraft:purple_terracotta
fill 517 229 268 517 231 268 minecraft:purple_terracotta
setblock 517 229 270 minecraft:purple_terracotta
fill 520 229 270 521 231 270 minecraft:purple_terracotta
fill 521 229 228 521 231 228 minecraft:purple_terracotta
fill 525 229 228 525 231 228 minecraft:purple_terracotta
fill 525 229 270 525 231 270 minecraft:purple_terracotta
fill 526 229 231 530 230 235 minecraft:dark_oak_planks
fill 528 229 229 528 229 230 minecraft:dark_oak_planks
fill 529 229 228 529 231 228 minecraft:purple_terracotta
fill 529 229 270 529 231 270 minecraft:purple_terracotta
fill 533 229 228 533 231 228 minecraft:purple_terracotta
fill 533 229 270 533 231 270 minecraft:purple_terracotta
fill 537 229 228 537 231 228 minecraft:purple_terracotta
fill 537 229 270 537 231 270 minecraft:purple_terracotta
fill 538 229 268 539 229 269 minecraft:dark_oak_planks
fill 540 229 268 541 229 268 minecraft:spruce_planks
fill 541 229 228 541 231 228 minecraft:purple_terracotta
fill 541 229 270 541 231 270 minecraft:purple_terracotta
fill 545 229 228 545 231 228 minecraft:purple_terracotta
fill 545 229 270 545 231 270 minecraft:purple_terracotta
fill 549 229 228 549 231 228 minecraft:purple_terracotta
fill 549 229 270 549 231 270 minecraft:purple_terracotta
fill 553 229 228 553 231 228 minecraft:purple_terracotta
fill 553 229 270 553 231 270 minecraft:purple_terracotta
fill 557 229 228 557 231 228 minecraft:purple_terracotta
fill 557 229 270 557 231 270 minecraft:purple_terracotta
setblock 559 229 228 minecraft:purple_terracotta
fill 559 229 232 559 231 232 minecraft:purple_terracotta
fill 559 229 236 559 231 236 minecraft:purple_terracotta
fill 559 229 240 559 231 240 minecraft:purple_terracotta
fill 559 229 244 559 231 244 minecraft:purple_terracotta
fill 559 229 248 559 231 248 minecraft:purple_terracotta
fill 559 229 252 559 231 252 minecraft:purple_terracotta
fill 559 229 256 559 231 256 minecraft:purple_terracotta
fill 559 229 260 559 231 260 minecraft:purple_terracotta
fill 559 229 264 559 231 264 minecraft:purple_terracotta
fill 559 229 268 559 231 268 minecraft:purple_terracotta
setblock 517 230 230 minecraft:magenta_terracotta
setblock 517 230 234 minecraft:magenta_terracotta
setblock 517 230 238 minecraft:magenta_terracotta
setblock 517 230 242 minecraft:magenta_terracotta
fill 517 230 243 517 237 243 minecraft:purple_terracotta
setblock 517 230 246 minecraft:magenta_terracotta
setblock 517 230 250 minecraft:magenta_terracotta
setblock 517 230 254 minecraft:magenta_terracotta
setblock 517 230 258 minecraft:magenta_terracotta
setblock 517 230 262 minecraft:magenta_terracotta
setblock 517 230 266 minecraft:magenta_terracotta
setblock 517 230 270 minecraft:magenta_terracotta
setblock 519 230 228 minecraft:magenta_terracotta
setblock 519 230 270 minecraft:magenta_terracotta
setblock 523 230 228 minecraft:magenta_terracotta
setblock 523 230 270 minecraft:magenta_terracotta
setblock 527 230 228 minecraft:magenta_terracotta
setblock 527 230 270 minecraft:magenta_terracotta
fill 530 230 269 532 230 269 minecraft:pink_terracotta
setblock 531 230 228 minecraft:magenta_terracotta
setblock 531 230 270 minecraft:magenta_terracotta
fill 533 230 246 533 241 246 minecraft:iron_bars
fill 533 230 255 533 235 255 minecraft:iron_bars
setblock 535 230 228 minecraft:magenta_terracotta
setblock 535 230 270 minecraft:magenta_terracotta
setblock 539 230 228 minecraft:magenta_terracotta
setblock 539 230 270 minecraft:magenta_terracotta
fill 540 230 229 542 230 229 minecraft:white_terracotta
fill 540 230 268 541 230 269 minecraft:dark_oak_planks
fill 542 230 246 542 235 246 minecraft:iron_bars
fill 542 230 255 542 232 255 minecraft:iron_bars
fill 542 230 268 543 230 268 minecraft:spruce_planks
setblock 543 230 228 minecraft:magenta_terracotta
setblock 543 230 270 minecraft:magenta_terracotta
setblock 547 230 228 minecraft:magenta_terracotta
setblock 547 230 270 minecraft:magenta_terracotta
setblock 551 230 228 minecraft:magenta_terracotta
setblock 551 230 270 minecraft:magenta_terracotta
setblock 555 230 228 minecraft:magenta_terracotta
setblock 555 230 270 minecraft:magenta_terracotta
setblock 559 230 228 minecraft:magenta_terracotta
setblock 559 230 230 minecraft:magenta_terracotta
setblock 559 230 234 minecraft:magenta_terracotta
setblock 559 230 238 minecraft:magenta_terracotta
setblock 559 230 242 minecraft:magenta_terracotta
setblock 559 230 246 minecraft:magenta_terracotta
setblock 559 230 250 minecraft:magenta_terracotta
setblock 559 230 254 minecraft:magenta_terracotta
setblock 559 230 258 minecraft:magenta_terracotta
setblock 559 230 262 minecraft:magenta_terracotta
setblock 559 230 266 minecraft:magenta_terracotta
setblock 559 230 270 minecraft:magenta_terracotta
fill 517 231 230 517 233 230 minecraft:purple_terracotta
fill 517 231 234 517 233 234 minecraft:purple_terracotta
fill 517 231 238 517 233 238 minecraft:purple_terracotta
fill 517 231 242 517 233 242 minecraft:purple_terracotta
fill 517 231 246 517 233 246 minecraft:purple_terracotta
fill 517 231 250 517 232 250 minecraft:purple_terracotta
fill 517 231 254 517 233 254 minecraft:purple_terracotta
fill 517 231 258 517 233 258 minecraft:purple_terracotta
fill 517 231 262 517 233 262 minecraft:purple_terracotta
fill 517 231 266 517 233 266 minecraft:purple_terracotta
setblock 517 231 270 minecraft:purple_terracotta
fill 519 231 228 519 233 228 minecraft:purple_terracotta
fill 519 231 270 519 233 270 minecraft:purple_terracotta
fill 523 231 228 523 233 228 minecraft:purple_terracotta
fill 523 231 270 523 233 270 minecraft:purple_terracotta
fill 527 231 228 527 233 228 minecraft:purple_terracotta
fill 527 231 233 529 231 233 minecraft:purple_concrete
fill 527 231 270 527 233 270 minecraft:purple_terracotta
setblock 528 231 232 minecraft:purple_concrete
setblock 528 231 234 minecraft:purple_concrete
setblock 530 231 269 minecraft:blue_concrete
fill 531 231 228 531 233 228 minecraft:purple_terracotta
fill 531 231 269 531 232 269 minecraft:pink_terracotta
fill 531 231 270 531 233 270 minecraft:purple_terracotta
setblock 532 231 269 minecraft:blue_concrete
fill 535 231 228 535 233 228 minecraft:purple_terracotta
fill 535 231 270 535 233 270 minecraft:purple_terracotta
fill 539 231 228 539 233 228 minecraft:purple_terracotta
fill 539 231 270 539 233 270 minecraft:purple_terracotta
setblock 540 231 229 minecraft:black_concrete
fill 541 231 229 541 232 229 minecraft:white_terracotta
setblock 542 231 229 minecraft:black_concrete
fill 542 231 268 543 231 269 minecraft:dark_oak_planks
fill 543 231 228 543 233 228 minecraft:purple_terracotta
fill 543 231 270 543 233 270 minecraft:purple_terracotta
fill 544 231 268 545 231 268 minecraft:spruce_planks
fill 547 231 228 547 233 228 minecraft:purple_terracotta
fill 547 231 270 547 233 270 minecraft:purple_terracotta
fill 551 231 228 551 233 228 minecraft:purple_terracotta
fill 551 231 270 551 233 270 minecraft:purple_terracotta
fill 555 231 228 555 233 228 minecraft:purple_terracotta
fill 555 231 270 555 233 270 minecraft:purple_terracotta
fill 558 231 257 558 231 261 minecraft:gold_block
setblock 559 231 228 minecraft:purple_terracotta
fill 559 231 230 559 233 230 minecraft:purple_terracotta
setblock 559 231 234 minecraft:purple_terracotta
fill 559 231 238 559 233 238 minecraft:purple_terracotta
fill 559 231 242 559 233 242 minecraft:purple_terracotta
setblock 559 231 245 minecraft:light_gray_terracotta
fill 559 231 246 559 233 246 minecraft:purple_terracotta
fill 559 231 250 559 233 250 minecraft:purple_terracotta
fill 559 231 254 559 233 254 minecraft:purple_terracotta
fill 559 231 258 559 233 258 minecraft:purple_terracotta
fill 559 231 262 559 233 262 minecraft:purple_terracotta
fill 559 231 266 559 233 266 minecraft:purple_terracotta
fill 559 231 270 559 233 270 minecraft:purple_terracotta
setblock 517 232 228 minecraft:magenta_terracotta
setblock 517 232 232 minecraft:magenta_terracotta
setblock 517 232 236 minecraft:magenta_terracotta
setblock 517 232 240 minecraft:magenta_terracotta
setblock 517 232 244 minecraft:magenta_terracotta
setblock 517 232 248 minecraft:magenta_terracotta
setblock 517 232 252 minecraft:magenta_terracotta
setblock 517 232 256 minecraft:magenta_terracotta
setblock 517 232 260 minecraft:magenta_terracotta
setblock 517 232 264 minecraft:magenta_terracotta
setblock 517 232 268 minecraft:magenta_terracotta
setblock 517 232 270 minecraft:magenta_terracotta
setblock 520 232 231 minecraft:light[level=11]
setblock 520 232 238 minecraft:light[level=12]
setblock 520 232 239 minecraft:light[level=11]
setblock 520 232 245 minecraft:light[level=12]
setblock 520 232 247 minecraft:light[level=11]
setblock 520 232 252 minecraft:light[level=12]
setblock 520 232 255 minecraft:light[level=11]
setblock 520 232 259 minecraft:light[level=12]
setblock 520 232 263 minecraft:light[level=11]
setblock 520 232 266 minecraft:light[level=12]
fill 520 232 270 520 278 270 minecraft:purple_terracotta
setblock 521 232 228 minecraft:magenta_terracotta
setblock 521 232 270 minecraft:magenta_terracotta
setblock 525 232 228 minecraft:magenta_terracotta
setblock 525 232 270 minecraft:magenta_terracotta
fill 527 232 231 531 233 235 minecraft:dark_oak_planks
setblock 527 232 238 minecraft:light[level=12]
setblock 527 232 245 minecraft:light[level=12]
setblock 527 232 252 minecraft:light[level=12]
setblock 527 232 259 minecraft:light[level=12]
setblock 527 232 266 minecraft:light[level=12]
setblock 528 232 239 minecraft:light[level=11]
setblock 528 232 247 minecraft:light[level=11]
setblock 528 232 255 minecraft:light[level=11]
setblock 528 232 263 minecraft:light[level=11]
setblock 529 232 228 minecraft:magenta_terracotta
fill 529 232 229 529 232 230 minecraft:dark_oak_planks
setblock 529 232 270 minecraft:magenta_terracotta
setblock 530 232 269 minecraft:pink_terracotta
setblock 532 232 269 minecraft:pink_terracotta
setblock 533 232 228 minecraft:magenta_terracotta
setblock 533 232 270 minecraft:magenta_terracotta
setblock 534 232 231 minecraft:light[level=12]
setblock 534 232 238 minecraft:light[level=12]
setblock 534 232 245 minecraft:light[level=12]
setblock 534 232 252 minecraft:light[level=12]
setblock 534 232 259 minecraft:light[level=12]
setblock 534 232 266 minecraft:light[level=12]
setblock 536 232 231 minecraft:light[level=11]
setblock 536 232 239 minecraft:light[level=11]
setblock 536 232 247 minecraft:light[level=11]
setblock 536 232 255 minecraft:light[level=11]
setblock 536 232 263 minecraft:light[level=11]
setblock 537 232 228 minecraft:magenta_terracotta
setblock 537 232 270 minecraft:magenta_terracotta
setblock 540 232 229 minecraft:white_terracotta
setblock 541 232 228 minecraft:magenta_terracotta
setblock 541 232 231 minecraft:light[level=12]
setblock 541 232 238 minecraft:light[level=12]
setblock 541 232 245 minecraft:light[level=12]
setblock 541 232 252 minecraft:light[level=12]
setblock 541 232 259 minecraft:light[level=12]
setblock 541 232 266 minecraft:light[level=12]
setblock 541 232 270 minecraft:magenta_terracotta
setblock 542 232 229 minecraft:white_terracotta
setblock 544 232 231 minecraft:light[level=11]
setblock 544 232 239 minecraft:light[level=11]
setblock 544 232 247 minecraft:light[level=11]
setblock 544 232 255 minecraft:light[level=11]
setblock 544 232 263 minecraft:light[level=11]
fill 544 232 268 545 232 269 minecraft:dark_oak_planks
setblock 545 232 228 minecraft:magenta_terracotta
setblock 545 232 270 minecraft:magenta_terracotta
fill 546 232 268 547 232 268 minecraft:spruce_planks
setblock 548 232 231 minecraft:light[level=12]
setblock 548 232 238 minecraft:light[level=12]
setblock 548 232 245 minecraft:light[level=12]
setblock 548 232 252 minecraft:light[level=12]
setblock 548 232 259 minecraft:light[level=12]
setblock 548 232 266 minecraft:light[level=12]
setblock 549 232 228 minecraft:magenta_terracotta
setblock 549 232 270 minecraft:magenta_terracotta
setblock 552 232 231 minecraft:light[level=11]
setblock 552 232 239 minecraft:light[level=11]
setblock 552 232 247 minecraft:light[level=11]
setblock 552 232 255 minecraft:light[level=11]
setblock 552 232 263 minecraft:light[level=11]
setblock 553 232 228 minecraft:magenta_terracotta
setblock 553 232 270 minecraft:magenta_terracotta
setblock 555 232 231 minecraft:light[level=12]
setblock 555 232 238 minecraft:light[level=12]
setblock 555 232 245 minecraft:light[level=12]
setblock 555 232 252 minecraft:light[level=12]
setblock 555 232 259 minecraft:light[level=12]
setblock 555 232 266 minecraft:light[level=12]
setblock 557 232 228 minecraft:magenta_terracotta
setblock 557 232 270 minecraft:magenta_terracotta
fill 558 232 248 558 232 252 minecraft:gold_block
fill 558 232 257 558 237 257 minecraft:gold_block
fill 558 232 258 558 233 260 minecraft:red_terracotta
fill 558 232 261 558 237 261 minecraft:gold_block
setblock 559 232 228 minecraft:magenta_terracotta
setblock 559 232 232 minecraft:magenta_terracotta
setblock 559 232 234 minecraft:gray_terracotta
setblock 559 232 236 minecraft:magenta_terracotta
setblock 559 232 240 minecraft:magenta_terracotta
setblock 559 232 244 minecraft:magenta_terracotta
fill 559 232 245 559 264 245 minecraft:purple_terracotta
setblock 559 232 248 minecraft:magenta_terracotta
setblock 559 232 252 minecraft:magenta_terracotta
setblock 559 232 256 minecraft:magenta_terracotta
setblock 559 232 260 minecraft:magenta_terracotta
setblock 559 232 264 minecraft:magenta_terracotta
setblock 559 232 268 minecraft:magenta_terracotta
fill 517 233 228 517 235 228 minecraft:purple_terracotta
fill 517 233 232 517 235 232 minecraft:purple_terracotta
fill 517 233 236 517 235 236 minecraft:purple_terracotta
fill 517 233 240 517 235 240 minecraft:purple_terracotta
fill 517 233 244 517 235 244 minecraft:purple_terracotta
fill 517 233 248 517 235 248 minecraft:purple_terracotta
setblock 517 233 250 minecraft:light_gray_terracotta
fill 517 233 252 517 235 252 minecraft:purple_terracotta
fill 517 233 256 517 235 256 minecraft:purple_terracotta
fill 517 233 260 517 235 260 minecraft:purple_terracotta
fill 517 233 264 517 235 264 minecraft:purple_terracotta
fill 517 233 268 517 235 268 minecraft:purple_terracotta
setblock 517 233 270 minecraft:purple_terracotta
setblock 518 233 228 minecraft:gray_terracotta
fill 521 233 228 521 235 228 minecraft:purple_terracotta
fill 521 233 270 521 235 270 minecraft:purple_terracotta
fill 525 233 228 525 235 228 minecraft:purple_terracotta
fill 525 233 270 525 235 270 minecraft:purple_terracotta
fill 529 233 228 529 235 228 minecraft:purple_terracotta
fill 529 233 270 529 235 270 minecraft:purple_terracotta
fill 530 233 269 532 233 269 minecraft:gold_block
fill 533 233 228 533 235 228 minecraft:purple_terracotta
fill 533 233 270 533 235 270 minecraft:purple_terracotta
fill 537 233 228 537 235 228 minecraft:purple_terracotta
fill 537 233 270 537 235 270 minecraft:purple_terracotta
fill 540 233 229 542 233 229 minecraft:gold_block
fill 541 233 228 541 235 228 minecraft:purple_terracotta
fill 541 233 270 541 235 270 minecraft:purple_terracotta
fill 545 233 228 545 235 228 minecraft:purple_terracotta
fill 545 233 270 545 235 270 minecraft:purple_terracotta
fill 546 233 268 547 233 269 minecraft:dark_oak_planks
fill 548 233 268 549 233 268 minecraft:spruce_planks
fill 549 233 228 549 235 228 minecraft:purple_terracotta
fill 549 233 270 549 235 270 minecraft:purple_terracotta
fill 553 233 228 553 235 228 minecraft:purple_terracotta
fill 553 233 270 553 235 270 minecraft:purple_terracotta
fill 557 233 228 557 235 228 minecraft:purple_terracotta
fill 557 233 270 557 235 270 minecraft:purple_terracotta
fill 558 233 248 558 238 248 minecraft:gold_block
fill 558 233 249 558 234 251 minecraft:brown_concrete
fill 558 233 252 558 238 252 minecraft:gold_block
setblock 559 233 228 minecraft:purple_terracotta
fill 559 233 232 559 235 232 minecraft:purple_terracotta
setblock 559 233 234 minecraft:purple_terracotta
fill 559 233 236 559 235 236 minecraft:purple_terracotta
fill 559 233 240 559 235 240 minecraft:purple_terracotta
fill 559 233 244 559 235 244 minecraft:purple_terracotta
fill 559 233 248 559 235 248 minecraft:purple_terracotta
fill 559 233 252 559 235 252 minecraft:purple_terracotta
fill 559 233 256 559 235 256 minecraft:purple_terracotta
fill 559 233 260 559 235 260 minecraft:purple_terracotta
fill 559 233 264 559 235 264 minecraft:purple_terracotta
fill 559 233 268 559 235 268 minecraft:purple_terracotta
setblock 517 234 230 minecraft:magenta_terracotta
setblock 517 234 234 minecraft:magenta_terracotta
setblock 517 234 238 minecraft:magenta_terracotta
setblock 517 234 242 minecraft:magenta_terracotta
setblock 517 234 246 minecraft:magenta_terracotta
setblock 517 234 250 minecraft:magenta_terracotta
setblock 517 234 254 minecraft:magenta_terracotta
setblock 517 234 258 minecraft:magenta_terracotta
setblock 517 234 262 minecraft:magenta_terracotta
setblock 517 234 266 minecraft:magenta_terracotta
setblock 517 234 270 minecraft:magenta_terracotta
fill 518 234 228 518 246 228 minecraft:purple_terracotta
setblock 519 234 228 minecraft:magenta_terracotta
setblock 519 234 270 minecraft:magenta_terracotta
setblock 523 234 228 minecraft:magenta_terracotta
setblock 523 234 270 minecraft:magenta_terracotta
setblock 527 234 228 minecraft:magenta_terracotta
fill 527 234 233 527 240 233 minecraft:purple_concrete
setblock 527 234 270 minecraft:magenta_terracotta
fill 528 234 232 528 240 232 minecraft:purple_concrete
fill 528 234 233 530 238 233 minecraft:stripped_dark_oak_log
fill 528 234 234 528 240 234 minecraft:purple_concrete
setblock 531 234 228 minecraft:magenta_terracotta
setblock 531 234 270 minecraft:magenta_terracotta
setblock 535 234 228 minecraft:magenta_terracotta
setblock 535 234 270 minecraft:magenta_terracotta
setblock 539 234 228 minecraft:magenta_terracotta
setblock 539 234 270 minecraft:magenta_terracotta
setblock 543 234 228 minecraft:magenta_terracotta
setblock 543 234 270 minecraft:magenta_terracotta
setblock 547 234 228 minecraft:magenta_terracotta
setblock 547 234 270 minecraft:magenta_terracotta
fill 548 234 268 549 234 269 minecraft:dark_oak_planks
fill 550 234 268 551 234 268 minecraft:spruce_planks
setblock 551 234 228 minecraft:magenta_terracotta
setblock 551 234 270 minecraft:magenta_terracotta
fill 553 234 250 553 253 250 minecraft:iron_bars
setblock 555 234 228 minecraft:magenta_terracotta
setblock 555 234 270 minecraft:magenta_terracotta
fill 558 234 258 558 234 260 minecraft:white_terracotta
setblock 559 234 228 minecraft:magenta_terracotta
setblock 559 234 230 minecraft:magenta_terracotta
setblock 559 234 234 minecraft:magenta_terracotta
setblock 559 234 238 minecraft:magenta_terracotta
setblock 559 234 242 minecraft:magenta_terracotta
setblock 559 234 246 minecraft:magenta_terracotta
setblock 559 234 250 minecraft:magenta_terracotta
setblock 559 234 254 minecraft:magenta_terracotta
setblock 559 234 258 minecraft:magenta_terracotta
setblock 559 234 262 minecraft:magenta_terracotta
setblock 559 234 266 minecraft:magenta_terracotta
setblock 559 234 270 minecraft:magenta_terracotta
fill 517 235 230 517 237 230 minecraft:purple_terracotta
fill 517 235 234 517 237 234 minecraft:purple_terracotta
fill 517 235 238 517 237 238 minecraft:purple_terracotta
fill 517 235 242 517 237 242 minecraft:purple_terracotta
fill 517 235 246 517 237 246 minecraft:purple_terracotta
fill 517 235 250 517 237 250 minecraft:purple_terracotta
fill 517 235 254 517 237 254 minecraft:purple_terracotta
fill 517 235 258 517 237 258 minecraft:purple_terracotta
fill 517 235 262 517 237 262 minecraft:purple_terracotta
fill 517 235 266 517 237 266 minecraft:purple_terracotta
setblock 517 235 270 minecraft:purple_terracotta
fill 519 235 228 519 237 228 minecraft:purple_terracotta
fill 519 235 270 519 237 270 minecraft:purple_terracotta
fill 523 235 228 523 237 228 minecraft:purple_terracotta
fill 523 235 270 523 237 270 minecraft:purple_terracotta
fill 527 235 228 527 237 228 minecraft:purple_terracotta
fill 527 235 270 527 237 270 minecraft:purple_terracotta
fill 531 235 228 531 237 228 minecraft:purple_terracotta
fill 531 235 270 531 237 270 minecraft:purple_terracotta
fill 535 235 228 535 237 228 minecraft:purple_terracotta
fill 535 235 270 535 237 270 minecraft:purple_terracotta
fill 539 235 228 539 237 228 minecraft:purple_terracotta
fill 539 235 270 539 237 270 minecraft:purple_terracotta
fill 543 235 228 543 237 228 minecraft:purple_terracotta
fill 543 235 270 543 237 270 minecraft:purple_terracotta
fill 547 235 228 547 237 228 minecraft:purple_terracotta
fill 547 235 270 547 237 270 minecraft:purple_terracotta
fill 550 235 268 551 235 269 minecraft:dark_oak_planks
fill 551 235 228 551 237 228 minecraft:purple_terracotta
fill 551 235 270 551 237 270 minecraft:purple_terracotta
fill 552 235 268 553 235 268 minecraft:spruce_planks
fill 555 235 228 555 237 228 minecraft:purple_terracotta
fill 555 235 270 555 237 270 minecraft:purple_terracotta
fill 558 235 249 558 235 251 minecraft:pink_terracotta
setblock 558 235 258 minecraft:black_concrete
fill 558 235 259 558 236 259 minecraft:white_terracotta
setblock 558 235 260 minecraft:black_concrete
setblock 559 235 228 minecraft:purple_terracotta
fill 559 235 230 559 237 230 minecraft:purple_terracotta
fill 559 235 234 559 237 234 minecraft:purple_terracotta
fill 559 235 238 559 237 238 minecraft:purple_terracotta
fill 559 235 242 559 237 242 minecraft:purple_terracotta
fill 559 235 246 559 237 246 minecraft:purple_terracotta
fill 559 235 250 559 237 250 minecraft:purple_terracotta
fill 559 235 254 559 237 254 minecraft:purple_terracotta
fill 559 235 258 559 237 258 minecraft:purple_terracotta
fill 559 235 262 559 237 262 minecraft:purple_terracotta
fill 559 235 266 559 237 266 minecraft:purple_terracotta
fill 559 235 270 559 237 270 minecraft:purple_terracotta
setblock 517 236 228 minecraft:magenta_terracotta
setblock 517 236 232 minecraft:magenta_terracotta
setblock 517 236 236 minecraft:magenta_terracotta
setblock 517 236 240 minecraft:magenta_terracotta
setblock 517 236 244 minecraft:magenta_terracotta
setblock 517 236 248 minecraft:magenta_terracotta
setblock 517 236 252 minecraft:magenta_terracotta
setblock 517 236 256 minecraft:magenta_terracotta
setblock 517 236 260 minecraft:magenta_terracotta
setblock 517 236 264 minecraft:magenta_terracotta
setblock 517 236 268 minecraft:magenta_terracotta
setblock 517 236 270 minecraft:magenta_terracotta
setblock 521 236 228 minecraft:magenta_terracotta
setblock 521 236 270 minecraft:magenta_terracotta
setblock 525 236 228 minecraft:magenta_terracotta
setblock 525 236 270 minecraft:magenta_terracotta
setblock 529 236 228 minecraft:magenta_terracotta
setblock 529 236 270 minecraft:magenta_terracotta
setblock 533 236 228 minecraft:magenta_terracotta
setblock 533 236 270 minecraft:magenta_terracotta
setblock 537 236 228 minecraft:magenta_terracotta
setblock 537 236 270 minecraft:magenta_terracotta
setblock 541 236 228 minecraft:magenta_terracotta
setblock 541 236 270 minecraft:magenta_terracotta
setblock 545 236 228 minecraft:magenta_terracotta
setblock 545 236 270 minecraft:magenta_terracotta
setblock 549 236 228 minecraft:magenta_terracotta
setblock 549 236 270 minecraft:magenta_terracotta
fill 552 236 268 553 236 269 minecraft:dark_oak_planks
setblock 553 236 228 minecraft:magenta_terracotta
setblock 553 236 270 minecraft:magenta_terracotta
fill 554 236 268 555 236 268 minecraft:spruce_planks
setblock 557 236 228 minecraft:magenta_terracotta
setblock 557 236 270 minecraft:magenta_terracotta
setblock 558 236 249 minecraft:blue_concrete
fill 558 236 250 558 237 250 minecraft:pink_terracotta
setblock 558 236 251 minecraft:blue_concrete
setblock 558 236 258 minecraft:white_terracotta
setblock 558 236 260 minecraft:white_terracotta
setblock 559 236 228 minecraft:magenta_terracotta
setblock 559 236 232 minecraft:magenta_terracotta
setblock 559 236 236 minecraft:magenta_terracotta
setblock 559 236 240 minecraft:magenta_terracotta
setblock 559 236 244 minecraft:magenta_terracotta
setblock 559 236 248 minecraft:magenta_terracotta
setblock 559 236 252 minecraft:magenta_terracotta
setblock 559 236 256 minecraft:magenta_terracotta
setblock 559 236 260 minecraft:magenta_terracotta
setblock 559 236 264 minecraft:magenta_terracotta
setblock 559 236 268 minecraft:magenta_terracotta
fill 517 237 228 517 239 228 minecraft:purple_terracotta
fill 517 237 232 517 239 232 minecraft:purple_terracotta
fill 517 237 236 517 239 236 minecraft:purple_terracotta
fill 517 237 240 517 239 240 minecraft:purple_terracotta
fill 517 237 244 517 239 244 minecraft:purple_terracotta
fill 517 237 248 517 239 248 minecraft:purple_terracotta
fill 517 237 252 517 239 252 minecraft:purple_terracotta
fill 517 237 256 517 239 256 minecraft:purple_terracotta
fill 517 237 260 517 239 260 minecraft:purple_terracotta
fill 517 237 264 517 239 264 minecraft:purple_terracotta
fill 517 237 268 517 239 268 minecraft:purple_terracotta
setblock 517 237 270 minecraft:purple_terracotta
fill 521 237 228 521 239 228 minecraft:purple_terracotta
fill 521 237 270 521 239 270 minecraft:purple_terracotta
fill 525 237 228 525 239 228 minecraft:purple_terracotta
fill 525 237 270 525 239 270 minecraft:purple_terracotta
fill 529 237 228 529 239 228 minecraft:purple_terracotta
fill 529 237 232 529 238 232 minecraft:stripped_dark_oak_log
fill 529 237 234 529 238 234 minecraft:stripped_dark_oak_log
fill 529 237 270 529 239 270 minecraft:purple_terracotta
fill 533 237 228 533 239 228 minecraft:purple_terracotta
fill 533 237 270 533 239 270 minecraft:purple_terracotta
fill 537 237 228 537 239 228 minecraft:purple_terracotta
fill 537 237 270 537 239 270 minecraft:purple_terracotta
fill 541 237 228 541 239 228 minecraft:purple_terracotta
fill 541 237 270 541 239 270 minecraft:purple_terracotta
fill 545 237 228 545 239 228 minecraft:purple_terracotta
fill 545 237 270 545 239 270 minecraft:purple_terracotta
fill 549 237 228 549 239 228 minecraft:purple_terracotta
fill 549 237 270 549 239 270 minecraft:purple_terracotta
fill 553 237 228 553 239 228 minecraft:purple_terracotta
fill 553 237 270 553 239 270 minecraft:purple_terracotta
fill 554 237 268 555 237 269 minecraft:dark_oak_planks
fill 556 237 268 557 237 268 minecraft:spruce_planks
fill 557 237 228 557 239 228 minecraft:purple_terracotta
fill 557 237 270 557 239 270 minecraft:purple_terracotta
setblock 558 237 249 minecraft:pink_terracotta
setblock 558 237 251 minecraft:pink_terracotta
fill 558 237 258 558 237 260 minecraft:gold_block
setblock 559 237 228 minecraft:purple_terracotta
fill 559 237 232 559 239 232 minecraft:purple_terracotta
fill 559 237 236 559 239 236 minecraft:purple_terracotta
fill 559 237 240 559 239 240 minecraft:purple_terracotta
fill 559 237 244 559 239 244 minecraft:purple_terracotta
fill 559 237 248 559 239 248 minecraft:purple_terracotta
fill 559 237 252 559 239 252 minecraft:purple_terracotta
fill 559 237 256 559 239 256 minecraft:purple_terracotta
fill 559 237 260 559 239 260 minecraft:purple_terracotta
fill 559 237 264 559 239 264 minecraft:purple_terracotta
fill 559 237 268 559 239 268 minecraft:purple_terracotta
setblock 517 238 230 minecraft:magenta_terracotta
setblock 517 238 234 minecraft:magenta_terracotta
setblock 517 238 238 minecraft:magenta_terracotta
setblock 517 238 242 minecraft:magenta_terracotta
setblock 517 238 243 minecraft:gray_terracotta
setblock 517 238 246 minecraft:magenta_terracotta
setblock 517 238 250 minecraft:magenta_terracotta
setblock 517 238 254 minecraft:magenta_terracotta
setblock 517 238 258 minecraft:magenta_terracotta
setblock 517 238 262 minecraft:magenta_terracotta
setblock 517 238 266 minecraft:magenta_terracotta
setblock 517 238 270 minecraft:magenta_terracotta
setblock 519 238 228 minecraft:magenta_terracotta
setblock 519 238 270 minecraft:magenta_terracotta
setblock 520 238 231 minecraft:light[level=12]
setblock 520 238 238 minecraft:light[level=12]
setblock 520 238 245 minecraft:light[level=12]
setblock 520 238 252 minecraft:light[level=12]
setblock 520 238 259 minecraft:light[level=12]
setblock 520 238 266 minecraft:light[level=12]
setblock 523 238 228 minecraft:magenta_terracotta
setblock 523 238 270 minecraft:magenta_terracotta
setblock 527 238 228 minecraft:magenta_terracotta
setblock 527 238 231 minecraft:light[level=12]
setblock 527 238 238 minecraft:light[level=12]
setblock 527 238 245 minecraft:light[level=12]
setblock 527 238 252 minecraft:light[level=12]
setblock 527 238 259 minecraft:light[level=12]
setblock 527 238 266 minecraft:light[level=12]
setblock 527 238 270 minecraft:magenta_terracotta
setblock 531 238 228 minecraft:magenta_terracotta
setblock 531 238 270 minecraft:magenta_terracotta
fill 533 238 254 533 241 254 minecraft:iron_bars
setblock 534 238 231 minecraft:light[level=12]
setblock 534 238 238 minecraft:light[level=12]
setblock 534 238 245 minecraft:light[level=12]
setblock 534 238 252 minecraft:light[level=12]
setblock 534 238 259 minecraft:light[level=12]
setblock 534 238 266 minecraft:light[level=12]
setblock 535 238 228 minecraft:magenta_terracotta
setblock 535 238 270 minecraft:magenta_terracotta
setblock 539 238 228 minecraft:magenta_terracotta
setblock 539 238 270 minecraft:light_gray_terracotta
setblock 541 238 231 minecraft:light[level=12]
setblock 541 238 238 minecraft:light[level=12]
setblock 541 238 245 minecraft:light[level=12]
setblock 541 238 252 minecraft:light[level=12]
setblock 541 238 259 minecraft:light[level=12]
setblock 541 238 266 minecraft:light[level=12]
setblock 543 238 228 minecraft:magenta_terracotta
setblock 543 238 270 minecraft:magenta_terracotta
setblock 547 238 228 minecraft:magenta_terracotta
setblock 547 238 270 minecraft:magenta_terracotta
setblock 548 238 231 minecraft:light[level=12]
setblock 548 238 238 minecraft:light[level=12]
setblock 548 238 245 minecraft:light[level=12]
setblock 548 238 252 minecraft:light[level=12]
setblock 548 238 259 minecraft:light[level=12]
setblock 548 238 266 minecraft:light[level=12]
setblock 551 238 228 minecraft:magenta_terracotta
setblock 551 238 270 minecraft:magenta_terracotta
setblock 555 238 228 minecraft:magenta_terracotta
setblock 555 238 231 minecraft:light[level=12]
setblock 555 238 238 minecraft:light[level=12]
setblock 555 238 245 minecraft:light[level=12]
setblock 555 238 252 minecraft:light[level=12]
setblock 555 238 259 minecraft:light[level=12]
setblock 555 238 266 minecraft:light[level=12]
setblock 555 238 270 minecraft:magenta_terracotta
fill 556 238 268 558 238 269 minecraft:dark_oak_planks
setblock 557 238 267 minecraft:spruce_planks
fill 558 238 249 558 238 251 minecraft:gold_block
setblock 559 238 228 minecraft:magenta_terracotta
setblock 559 238 230 minecraft:magenta_terracotta
setblock 559 238 234 minecraft:magenta_terracotta
setblock 559 238 238 minecraft:magenta_terracotta
setblock 559 238 242 minecraft:magenta_terracotta
setblock 559 238 246 minecraft:magenta_terracotta
setblock 559 238 250 minecraft:magenta_terracotta
setblock 559 238 254 minecraft:magenta_terracotta
setblock 559 238 258 minecraft:magenta_terracotta
setblock 559 238 262 minecraft:magenta_terracotta
setblock 559 238 266 minecraft:magenta_terracotta
setblock 559 238 270 minecraft:magenta_terracotta
fill 517 239 230 517 241 230 minecraft:purple_terracotta
fill 517 239 234 517 241 234 minecraft:purple_terracotta
fill 517 239 238 517 241 238 minecraft:purple_terracotta
fill 517 239 242 517 241 243 minecraft:purple_terracotta
fill 517 239 246 517 241 246 minecraft:purple_terracotta
fill 517 239 250 517 241 250 minecraft:purple_terracotta
fill 517 239 254 517 241 254 minecraft:purple_terracotta
fill 517 239 258 517 241 258 minecraft:purple_terracotta
fill 517 239 262 517 241 262 minecraft:purple_terracotta
fill 517 239 266 517 241 266 minecraft:purple_terracotta
setblock 517 239 270 minecraft:purple_terracotta
fill 519 239 228 519 241 228 minecraft:purple_terracotta
fill 519 239 270 519 241 270 minecraft:purple_terracotta
fill 523 239 228 523 241 228 minecraft:purple_terracotta
fill 523 239 270 523 241 270 minecraft:purple_terracotta
fill 527 239 228 527 241 228 minecraft:purple_terracotta
fill 527 239 270 527 241 270 minecraft:purple_terracotta
fill 528 239 233 529 240 233 minecraft:purple_concrete
fill 531 239 228 531 241 228 minecraft:purple_terracotta
fill 531 239 270 531 241 270 minecraft:purple_terracotta
fill 535 239 228 535 241 228 minecraft:purple_terracotta
fill 535 239 270 535 241 270 minecraft:purple_terracotta
fill 539 239 228 539 241 228 minecraft:purple_terracotta
fill 539 239 270 539 241 270 minecraft:purple_terracotta
fill 543 239 228 543 241 228 minecraft:purple_terracotta
fill 543 239 270 543 241 270 minecraft:purple_terracotta
fill 547 239 228 547 241 228 minecraft:purple_terracotta
fill 547 239 270 547 241 270 minecraft:purple_terracotta
fill 551 239 228 551 241 228 minecraft:purple_terracotta
fill 551 239 270 551 241 270 minecraft:purple_terracotta
fill 555 239 228 555 241 228 minecraft:purple_terracotta
fill 555 239 270 555 241 270 minecraft:purple_terracotta
fill 557 239 265 557 239 266 minecraft:spruce_planks
fill 557 239 267 558 239 269 minecraft:dark_oak_planks
setblock 559 239 228 minecraft:purple_terracotta
fill 559 239 230 559 241 230 minecraft:purple_terracotta
fill 559 239 234 559 241 234 minecraft:purple_terracotta
fill 559 239 238 559 241 238 minecraft:purple_terracotta
fill 559 239 242 559 241 242 minecraft:purple_terracotta
fill 559 239 246 559 241 246 minecraft:purple_terracotta
fill 559 239 250 559 241 250 minecraft:purple_terracotta
fill 559 239 254 559 241 254 minecraft:purple_terracotta
fill 559 239 258 559 241 258 minecraft:purple_terracotta
fill 559 239 262 559 241 262 minecraft:purple_terracotta
fill 559 239 266 559 241 266 minecraft:purple_terracotta
fill 559 239 270 559 241 270 minecraft:purple_terracotta
setblock 517 240 228 minecraft:magenta_terracotta
setblock 517 240 232 minecraft:magenta_terracotta
setblock 517 240 236 minecraft:magenta_terracotta
setblock 517 240 240 minecraft:magenta_terracotta
setblock 517 240 244 minecraft:magenta_terracotta
setblock 517 240 248 minecraft:magenta_terracotta
setblock 517 240 252 minecraft:magenta_terracotta
setblock 517 240 256 minecraft:magenta_terracotta
setblock 517 240 260 minecraft:magenta_terracotta
setblock 517 240 264 minecraft:magenta_terracotta
setblock 517 240 268 minecraft:magenta_terracotta
setblock 517 240 270 minecraft:magenta_terracotta
setblock 520 240 231 minecraft:light[level=11]
setblock 520 240 239 minecraft:light[level=11]
setblock 520 240 247 minecraft:light[level=11]
setblock 520 240 255 minecraft:light[level=11]
setblock 520 240 263 minecraft:light[level=11]
setblock 521 240 228 minecraft:magenta_terracotta
setblock 521 240 270 minecraft:magenta_terracotta
setblock 525 240 228 minecraft:magenta_terracotta
setblock 525 240 270 minecraft:magenta_terracotta
setblock 528 240 231 minecraft:light[level=11]
setblock 528 240 239 minecraft:light[level=11]
setblock 528 240 247 minecraft:light[level=11]
setblock 528 240 255 minecraft:light[level=11]
setblock 528 240 263 minecraft:light[level=11]
setblock 529 240 228 minecraft:magenta_terracotta
setblock 529 240 270 minecraft:magenta_terracotta
setblock 533 240 228 minecraft:magenta_terracotta
setblock 533 240 270 minecraft:magenta_terracotta
setblock 536 240 231 minecraft:light[level=11]
setblock 536 240 239 minecraft:light[level=11]
setblock 536 240 247 minecraft:light[level=11]
setblock 536 240 255 minecraft:light[level=11]
setblock 536 240 263 minecraft:light[level=11]
setblock 537 240 228 minecraft:magenta_terracotta
setblock 537 240 270 minecraft:magenta_terracotta
setblock 541 240 228 minecraft:magenta_terracotta
setblock 541 240 270 minecraft:magenta_terracotta
setblock 544 240 231 minecraft:light[level=11]
setblock 544 240 239 minecraft:light[level=11]
setblock 544 240 247 minecraft:light[level=11]
setblock 544 240 255 minecraft:light[level=11]
setblock 544 240 263 minecraft:light[level=11]
setblock 545 240 228 minecraft:magenta_terracotta
setblock 545 240 270 minecraft:magenta_terracotta
setblock 549 240 228 minecraft:magenta_terracotta
setblock 549 240 270 minecraft:magenta_terracotta
setblock 552 240 231 minecraft:light[level=11]
setblock 552 240 239 minecraft:light[level=11]
setblock 552 240 247 minecraft:light[level=11]
setblock 552 240 255 minecraft:light[level=11]
setblock 552 240 263 minecraft:light[level=11]
setblock 553 240 228 minecraft:magenta_terracotta
setblock 553 240 270 minecraft:magenta_terracotta
setblock 557 240 228 minecraft:magenta_terracotta
fill 557 240 263 557 240 264 minecraft:spruce_planks
fill 557 240 265 558 240 266 minecraft:dark_oak_planks
setblock 557 240 270 minecraft:magenta_terracotta
setblock 559 240 228 minecraft:magenta_terracotta
setblock 559 240 232 minecraft:magenta_terracotta
setblock 559 240 236 minecraft:magenta_terracotta
setblock 559 240 240 minecraft:magenta_terracotta
setblock 559 240 244 minecraft:magenta_terracotta
setblock 559 240 248 minecraft:magenta_terracotta
setblock 559 240 252 minecraft:magenta_terracotta
setblock 559 240 256 minecraft:magenta_terracotta
setblock 559 240 260 minecraft:magenta_terracotta
setblock 559 240 264 minecraft:magenta_terracotta
setblock 559 240 268 minecraft:magenta_terracotta
fill 517 241 228 517 243 228 minecraft:purple_terracotta
fill 517 241 232 517 243 232 minecraft:purple_terracotta
fill 517 241 236 517 243 236 minecraft:purple_terracotta
fill 517 241 240 517 243 240 minecraft:purple_terracotta
fill 517 241 244 517 243 244 minecraft:purple_terracotta
fill 517 241 248 517 243 248 minecraft:purple_terracotta
fill 517 241 252 517 243 252 minecraft:purple_terracotta
fill 517 241 256 517 243 256 minecraft:purple_terracotta
fill 517 241 260 517 243 260 minecraft:purple_terracotta
fill 517 241 264 517 243 264 minecraft:purple_terracotta
fill 517 241 268 517 243 268 minecraft:purple_terracotta
setblock 517 241 270 minecraft:purple_terracotta
fill 521 241 228 521 243 228 minecraft:purple_terracotta
fill 521 241 270 521 243 270 minecraft:purple_terracotta
fill 525 241 228 525 243 228 minecraft:purple_terracotta
setblock 525 241 270 minecraft:gray_terracotta
setblock 528 241 233 minecraft:jack_o_lantern
fill 529 241 228 529 243 228 minecraft:purple_terracotta
fill 529 241 270 529 243 270 minecraft:purple_terracotta
fill 533 241 228 533 243 228 minecraft:purple_terracotta
fill 533 241 270 533 243 270 minecraft:purple_terracotta
fill 537 241 228 537 243 228 minecraft:purple_terracotta
fill 537 241 270 537 243 270 minecraft:purple_terracotta
fill 541 241 228 541 243 228 minecraft:purple_terracotta
fill 541 241 270 541 243 270 minecraft:purple_terracotta
fill 545 241 228 545 243 228 minecraft:purple_terracotta
fill 545 241 270 545 243 270 minecraft:purple_terracotta
fill 549 241 228 549 243 228 minecraft:purple_terracotta
fill 549 241 270 549 243 270 minecraft:purple_terracotta
fill 553 241 228 553 243 228 minecraft:purple_terracotta
fill 553 241 270 553 243 270 minecraft:purple_terracotta
fill 556 241 256 556 253 256 minecraft:iron_bars
fill 557 241 228 557 243 228 minecraft:purple_terracotta
fill 557 241 261 557 241 262 minecraft:spruce_planks
fill 557 241 263 558 241 264 minecraft:dark_oak_planks
fill 557 241 270 557 243 270 minecraft:purple_terracotta
setblock 559 241 228 minecraft:purple_terracotta
fill 559 241 232 559 243 232 minecraft:purple_terracotta
fill 559 241 236 559 243 236 minecraft:purple_terracotta
fill 559 241 240 559 243 240 minecraft:purple_terracotta
fill 559 241 244 559 243 244 minecraft:purple_terracotta
fill 559 241 248 559 243 248 minecraft:purple_terracotta
fill 559 241 252 559 243 252 minecraft:purple_terracotta
fill 559 241 256 559 243 256 minecraft:purple_terracotta
fill 559 241 260 559 243 260 minecraft:purple_terracotta
fill 559 241 264 559 243 264 minecraft:purple_terracotta
fill 559 241 268 559 243 268 minecraft:purple_terracotta
setblock 517 242 230 minecraft:magenta_terracotta
setblock 517 242 234 minecraft:magenta_terracotta
setblock 517 242 238 minecraft:magenta_terracotta
setblock 517 242 242 minecraft:magenta_terracotta
fill 517 242 243 517 278 243 minecraft:purple_terracotta
setblock 517 242 246 minecraft:magenta_terracotta
setblock 517 242 250 minecraft:magenta_terracotta
setblock 517 242 254 minecraft:magenta_terracotta
setblock 517 242 258 minecraft:magenta_terracotta
setblock 517 242 262 minecraft:magenta_terracotta
setblock 517 242 266 minecraft:magenta_terracotta
setblock 517 242 270 minecraft:magenta_terracotta
setblock 519 242 228 minecraft:magenta_terracotta
setblock 519 242 270 minecraft:magenta_terracotta
setblock 523 242 228 minecraft:magenta_terracotta
setblock 523 242 270 minecraft:magenta_terracotta
fill 525 242 270 525 243 270 minecraft:purple_terracotta
setblock 527 242 228 minecraft:magenta_terracotta
setblock 527 242 270 minecraft:magenta_terracotta
setblock 531 242 228 minecraft:magenta_terracotta
setblock 531 242 270 minecraft:magenta_terracotta
setblock 535 242 228 minecraft:magenta_terracotta
setblock 535 242 270 minecraft:magenta_terracotta
setblock 539 242 228 minecraft:magenta_terracotta
setblock 539 242 270 minecraft:magenta_terracotta
setblock 543 242 228 minecraft:magenta_terracotta
setblock 543 242 270 minecraft:magenta_terracotta
setblock 547 242 228 minecraft:magenta_terracotta
setblock 547 242 270 minecraft:magenta_terracotta
setblock 551 242 228 minecraft:magenta_terracotta
setblock 551 242 270 minecraft:magenta_terracotta
setblock 555 242 228 minecraft:magenta_terracotta
setblock 555 242 270 minecraft:magenta_terracotta
fill 557 242 259 557 242 260 minecraft:spruce_planks
fill 557 242 261 558 242 262 minecraft:dark_oak_planks
setblock 559 242 228 minecraft:magenta_terracotta
setblock 559 242 230 minecraft:magenta_terracotta
setblock 559 242 234 minecraft:magenta_terracotta
setblock 559 242 238 minecraft:magenta_terracotta
setblock 559 242 242 minecraft:magenta_terracotta
setblock 559 242 246 minecraft:magenta_terracotta
setblock 559 242 250 minecraft:magenta_terracotta
setblock 559 242 254 minecraft:magenta_terracotta
setblock 559 242 258 minecraft:magenta_terracotta
setblock 559 242 262 minecraft:magenta_terracotta
setblock 559 242 266 minecraft:magenta_terracotta
setblock 559 242 270 minecraft:magenta_terracotta
fill 517 243 230 517 245 230 minecraft:purple_terracotta
fill 517 243 234 517 245 234 minecraft:purple_terracotta
fill 517 243 238 517 245 238 minecraft:purple_terracotta
fill 517 243 242 517 245 242 minecraft:purple_terracotta
fill 517 243 246 517 245 246 minecraft:purple_terracotta
fill 517 243 250 517 245 250 minecraft:purple_terracotta
fill 517 243 254 517 245 254 minecraft:purple_terracotta
fill 517 243 258 517 245 258 minecraft:purple_terracotta
fill 517 243 262 517 245 262 minecraft:purple_terracotta
fill 517 243 266 517 245 266 minecraft:purple_terracotta
setblock 517 243 270 minecraft:purple_terracotta
fill 519 243 228 519 245 228 minecraft:purple_terracotta
fill 519 243 270 519 245 270 minecraft:purple_terracotta
fill 523 243 228 523 245 228 minecraft:purple_terracotta
schedule function dropper:buildpart/59_4 1t
