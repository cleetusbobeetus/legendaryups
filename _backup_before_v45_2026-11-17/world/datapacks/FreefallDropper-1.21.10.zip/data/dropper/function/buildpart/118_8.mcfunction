fill 481 233 497 481 242 497 minecraft:basalt
fill 482 233 470 482 240 470 minecraft:basalt
fill 482 233 500 482 240 500 minecraft:basalt
fill 483 233 472 483 242 472 minecraft:basalt
fill 483 233 498 483 242 498 minecraft:basalt
setblock 484 233 471 minecraft:magma_block
setblock 484 233 505 minecraft:red_terracotta
fill 485 233 466 485 236 466 minecraft:basalt
fill 485 233 469 485 240 469 minecraft:basalt
fill 485 233 471 487 242 471 minecraft:basalt
fill 485 233 499 487 233 499 minecraft:basalt
fill 485 233 502 485 238 502 minecraft:basalt
fill 485 233 505 487 307 505 minecraft:orange_terracotta
fill 487 233 463 487 234 463 minecraft:red_terracotta
fill 488 233 463 494 233 463 minecraft:orange_terracotta
fill 488 233 465 488 236 465 minecraft:basalt
fill 488 233 468 488 239 468 minecraft:basalt
fill 488 233 501 488 240 501 minecraft:basalt
fill 488 233 504 488 237 504 minecraft:basalt
fill 491 233 464 495 233 464 minecraft:basalt
fill 491 233 467 491 238 467 minecraft:basalt
fill 491 233 470 491 240 471 minecraft:basalt
fill 491 233 499 491 240 500 minecraft:basalt
fill 491 233 503 491 238 503 minecraft:basalt
fill 491 233 505 493 307 505 minecraft:orange_terracotta
fill 492 233 471 492 242 471 minecraft:basalt
fill 492 233 499 494 240 499 minecraft:basalt
setblock 493 233 471 minecraft:magma_block
fill 494 233 466 501 233 466 minecraft:basalt
fill 494 233 469 494 239 469 minecraft:basalt
fill 494 233 502 494 238 502 minecraft:basalt
setblock 494 233 505 minecraft:red_terracotta
setblock 495 233 472 minecraft:basalt
fill 495 233 498 495 242 498 minecraft:basalt
fill 495 233 505 496 307 505 minecraft:orange_terracotta
setblock 496 233 464 minecraft:magma_block
fill 497 233 464 497 233 465 minecraft:basalt
fill 497 233 468 504 233 468 minecraft:basalt
fill 497 233 471 497 240 471 minecraft:basalt
fill 497 233 473 497 242 473 minecraft:basalt
fill 497 233 497 497 240 498 minecraft:basalt
fill 497 233 501 497 238 501 minecraft:basalt
fill 497 233 504 501 233 504 minecraft:basalt
setblock 497 233 505 minecraft:red_terracotta
fill 498 233 465 499 233 465 minecraft:basalt
fill 498 233 474 498 242 474 minecraft:basalt
fill 498 233 496 498 242 496 minecraft:basalt
fill 498 233 505 498 307 505 minecraft:orange_terracotta
setblock 499 233 475 minecraft:magma_block
fill 499 233 495 499 242 495 minecraft:basalt
setblock 499 233 505 minecraft:red_terracotta
fill 500 233 467 502 233 467 minecraft:basalt
fill 500 233 470 504 234 470 minecraft:basalt
fill 500 233 473 500 240 473 minecraft:basalt
fill 500 233 476 500 242 476 minecraft:basalt
fill 500 233 494 500 242 494 minecraft:basalt
fill 500 233 497 500 240 497 minecraft:basalt
fill 500 233 500 504 234 500 minecraft:basalt
fill 500 233 503 502 233 503 minecraft:basalt
fill 500 233 505 507 233 505 minecraft:orange_terracotta
fill 501 233 477 501 242 477 minecraft:basalt
fill 501 233 493 510 233 493 minecraft:basalt
fill 502 233 479 502 242 479 minecraft:basalt
fill 502 233 491 502 242 491 minecraft:basalt
setblock 502 233 492 minecraft:magma_block
fill 503 233 469 505 233 469 minecraft:basalt
fill 503 233 472 507 233 472 minecraft:basalt
fill 503 233 475 509 233 475 minecraft:basalt
fill 503 233 478 510 233 478 minecraft:basalt
fill 503 233 481 503 242 483 minecraft:basalt
fill 503 233 487 503 240 490 minecraft:basalt
fill 503 233 496 507 234 496 minecraft:basalt
fill 503 233 499 506 233 499 minecraft:basalt
fill 503 233 502 504 233 502 minecraft:basalt
setblock 505 233 470 minecraft:magma_block
setblock 505 233 500 minecraft:magma_block
fill 506 233 470 506 233 471 minecraft:basalt
fill 506 233 474 508 233 474 minecraft:basalt
fill 506 233 477 510 233 477 minecraft:basalt
fill 506 233 480 510 234 480 minecraft:basalt
fill 506 233 483 510 234 483 minecraft:basalt
fill 506 233 486 510 234 486 minecraft:basalt
fill 506 233 489 510 234 489 minecraft:basalt
fill 506 233 492 510 233 492 minecraft:basalt
fill 506 233 495 509 233 495 minecraft:basalt
fill 506 233 498 507 233 498 minecraft:basalt
setblock 506 233 500 minecraft:basalt
setblock 508 233 496 minecraft:magma_block
setblock 508 233 505 minecraft:red_terracotta
setblock 509 233 476 minecraft:basalt
fill 509 233 479 510 233 479 minecraft:basalt
fill 509 233 482 509 235 482 minecraft:basalt
fill 509 233 485 509 236 485 minecraft:basalt
fill 509 233 488 509 235 488 minecraft:basalt
fill 509 233 491 510 233 491 minecraft:basalt
setblock 509 233 494 minecraft:basalt
setblock 511 233 480 minecraft:magma_block
setblock 511 233 483 minecraft:magma_block
setblock 511 233 486 minecraft:magma_block
setblock 511 233 489 minecraft:magma_block
fill 512 233 463 512 307 463 minecraft:orange_terracotta
fill 512 233 466 512 307 466 minecraft:orange_terracotta
setblock 512 233 471 minecraft:orange_terracotta
fill 512 233 476 512 307 478 minecraft:orange_terracotta
setblock 512 233 479 minecraft:red_terracotta
fill 512 233 480 512 307 480 minecraft:orange_terracotta
fill 512 233 484 512 307 489 minecraft:orange_terracotta
setblock 512 233 490 minecraft:red_terracotta
fill 512 233 491 512 307 495 minecraft:orange_terracotta
fill 512 233 496 512 234 496 minecraft:red_terracotta
fill 512 233 497 512 233 502 minecraft:orange_terracotta
setblock 512 233 503 minecraft:red_terracotta
fill 512 233 504 512 307 504 minecraft:orange_terracotta
setblock 470 234 463 minecraft:red_terracotta
fill 470 234 464 470 307 466 minecraft:orange_terracotta
setblock 470 234 467 minecraft:red_terracotta
fill 470 234 468 470 307 468 minecraft:orange_terracotta
setblock 470 234 469 minecraft:red_terracotta
fill 470 234 470 470 307 476 minecraft:orange_terracotta
fill 470 234 480 470 307 486 minecraft:orange_terracotta
setblock 470 234 487 minecraft:red_terracotta
fill 470 234 488 470 307 489 minecraft:orange_terracotta
fill 470 234 501 470 307 501 minecraft:orange_terracotta
setblock 470 234 502 minecraft:red_terracotta
fill 470 234 503 470 307 505 minecraft:orange_terracotta
fill 471 234 463 474 307 463 minecraft:orange_terracotta
fill 471 234 473 472 234 473 minecraft:basalt
setblock 471 234 474 minecraft:magma_block
fill 471 234 475 472 234 497 minecraft:basalt
setblock 472 234 472 minecraft:basalt
fill 472 234 474 472 235 474 minecraft:basalt
setblock 472 234 498 minecraft:basalt
fill 473 234 505 473 307 505 minecraft:orange_terracotta
setblock 474 234 470 minecraft:magma_block
setblock 474 234 500 minecraft:magma_block
fill 475 234 470 481 235 470 minecraft:basalt
fill 475 234 480 476 241 480 minecraft:basalt
fill 475 234 483 475 241 486 minecraft:basalt
fill 475 234 489 476 234 489 minecraft:basalt
fill 475 234 500 479 234 501 minecraft:basalt
setblock 475 234 505 minecraft:red_terracotta
fill 476 234 468 479 234 468 minecraft:basalt
fill 476 234 481 476 243 481 minecraft:basalt
fill 476 234 490 476 243 490 minecraft:basalt
setblock 476 234 502 minecraft:basalt
fill 476 234 505 481 307 505 minecraft:orange_terracotta
fill 477 234 467 479 234 467 minecraft:basalt
setblock 477 234 478 minecraft:magma_block
fill 477 234 492 477 243 492 minecraft:basalt
fill 477 234 503 482 234 503 minecraft:basalt
fill 478 234 463 478 307 463 minecraft:orange_terracotta
fill 478 234 476 478 241 477 minecraft:basalt
fill 478 234 493 478 241 494 minecraft:basalt
setblock 479 234 476 minecraft:basalt
setblock 479 234 494 minecraft:basalt
setblock 479 234 504 minecraft:basalt
fill 480 234 475 480 243 475 minecraft:basalt
setblock 480 234 495 minecraft:magma_block
fill 480 234 500 481 238 500 minecraft:basalt
setblock 480 234 504 minecraft:magma_block
fill 481 234 465 487 234 465 minecraft:basalt
fill 481 234 474 481 243 474 minecraft:basalt
fill 481 234 496 481 243 496 minecraft:basalt
fill 481 234 504 487 235 504 minecraft:basalt
fill 482 234 473 482 243 473 minecraft:basalt
fill 482 234 497 482 243 497 minecraft:basalt
setblock 482 234 505 minecraft:red_terracotta
fill 483 234 505 484 307 505 minecraft:orange_terracotta
fill 484 234 464 491 234 464 minecraft:basalt
fill 484 234 471 484 241 472 minecraft:basalt
fill 484 234 498 485 234 498 minecraft:basalt
fill 485 234 472 485 243 472 minecraft:basalt
fill 485 234 499 485 242 499 minecraft:basalt
setblock 486 234 499 minecraft:magma_block
fill 487 234 499 490 241 499 minecraft:basalt
fill 488 234 463 490 307 463 minecraft:orange_terracotta
fill 488 234 471 488 242 471 minecraft:basalt
setblock 488 234 505 minecraft:red_terracotta
setblock 489 234 471 minecraft:magma_block
fill 489 234 505 490 307 505 minecraft:orange_terracotta
fill 490 234 471 490 242 471 minecraft:basalt
setblock 491 234 463 minecraft:red_terracotta
fill 492 234 463 504 307 463 minecraft:orange_terracotta
setblock 492 234 464 minecraft:magma_block
fill 493 234 464 494 234 464 minecraft:basalt
fill 493 234 471 493 241 472 minecraft:basalt
fill 493 234 498 494 243 498 minecraft:basalt
fill 494 234 466 499 234 466 minecraft:basalt
fill 494 234 472 494 243 472 minecraft:basalt
fill 494 234 505 494 307 505 minecraft:orange_terracotta
setblock 495 234 472 minecraft:magma_block
fill 496 234 473 496 243 473 minecraft:basalt
fill 496 234 497 496 243 497 minecraft:basalt
setblock 497 234 465 minecraft:basalt
fill 497 234 468 502 234 468 minecraft:basalt
fill 497 234 474 497 243 474 minecraft:basalt
fill 497 234 496 497 243 496 minecraft:basalt
fill 497 234 504 497 235 504 minecraft:basalt
fill 497 234 505 497 307 505 minecraft:orange_terracotta
fill 498 234 475 499 241 475 minecraft:basalt
setblock 498 234 495 minecraft:magma_block
fill 498 234 501 503 234 501 minecraft:basalt
setblock 498 234 504 minecraft:magma_block
fill 499 234 476 499 243 476 minecraft:basalt
fill 499 234 494 499 243 494 minecraft:basalt
setblock 499 234 504 minecraft:basalt
fill 499 234 505 500 307 505 minecraft:orange_terracotta
setblock 500 234 467 minecraft:basalt
fill 500 234 477 500 243 477 minecraft:basalt
fill 500 234 493 509 234 493 minecraft:basalt
setblock 500 234 503 minecraft:basalt
setblock 501 234 467 minecraft:magma_block
fill 501 234 473 507 234 473 minecraft:basalt
fill 501 234 478 501 243 478 minecraft:basalt
fill 501 234 492 502 241 492 minecraft:basalt
fill 501 234 497 507 234 497 minecraft:basalt
setblock 501 234 503 minecraft:magma_block
setblock 501 234 505 minecraft:red_terracotta
fill 502 234 480 502 241 481 minecraft:basalt
fill 502 234 489 502 243 490 minecraft:basalt
fill 502 234 505 503 307 505 minecraft:orange_terracotta
setblock 503 234 469 minecraft:basalt
fill 503 234 472 506 234 472 minecraft:basalt
fill 503 234 475 508 234 475 minecraft:basalt
fill 503 234 478 509 234 478 minecraft:basalt
fill 503 234 484 503 242 486 minecraft:basalt
fill 503 234 499 505 234 499 minecraft:basalt
setblock 504 234 505 minecraft:red_terracotta
setblock 505 234 463 minecraft:red_terracotta
fill 505 234 505 509 307 505 minecraft:orange_terracotta
fill 506 234 463 511 307 463 minecraft:orange_terracotta
fill 506 234 474 506 235 474 minecraft:basalt
fill 506 234 477 509 234 477 minecraft:basalt
fill 506 234 492 509 234 492 minecraft:basalt
fill 506 234 495 508 234 495 minecraft:basalt
setblock 506 234 498 minecraft:basalt
setblock 507 234 474 minecraft:magma_block
fill 509 234 479 509 235 479 minecraft:basalt
fill 509 234 481 510 234 481 minecraft:basalt
fill 509 234 484 510 234 484 minecraft:basalt
fill 509 234 487 510 234 487 minecraft:basalt
fill 509 234 490 509 234 491 minecraft:basalt
setblock 510 234 482 minecraft:magma_block
setblock 510 234 485 minecraft:magma_block
setblock 510 234 488 minecraft:magma_block
setblock 510 234 490 minecraft:basalt
setblock 510 234 505 minecraft:red_terracotta
fill 511 234 505 512 307 505 minecraft:orange_terracotta
setblock 512 234 471 minecraft:red_terracotta
fill 512 234 479 512 307 479 minecraft:orange_terracotta
fill 512 234 483 512 307 483 minecraft:orange_terracotta
fill 512 234 490 512 307 490 minecraft:orange_terracotta
setblock 512 234 497 minecraft:red_terracotta
fill 512 234 498 512 307 503 minecraft:orange_terracotta
fill 470 235 463 470 307 463 minecraft:orange_terracotta
fill 470 235 467 470 307 467 minecraft:orange_terracotta
fill 470 235 469 470 307 469 minecraft:orange_terracotta
fill 470 235 487 470 307 487 minecraft:orange_terracotta
fill 470 235 494 470 307 494 minecraft:orange_terracotta
fill 470 235 502 470 307 502 minecraft:orange_terracotta
fill 471 235 474 471 236 474 minecraft:red_terracotta
fill 471 235 475 472 235 495 minecraft:basalt
setblock 472 235 464 minecraft:red_terracotta
setblock 472 235 473 minecraft:basalt
fill 472 235 496 472 235 497 minecraft:basalt
setblock 472 235 504 minecraft:red_terracotta
setblock 473 235 464 minecraft:terracotta
setblock 473 235 472 minecraft:magma_block
fill 473 235 498 475 235 498 minecraft:basalt
setblock 473 235 504 minecraft:terracotta
fill 474 235 464 477 235 464 minecraft:red_terracotta
fill 474 235 471 475 235 472 minecraft:basalt
fill 474 235 499 475 235 499 minecraft:basalt
fill 474 235 504 477 235 504 minecraft:red_terracotta
fill 475 235 465 476 235 465 minecraft:red_terracotta
fill 475 235 489 475 241 489 minecraft:basalt
fill 475 235 500 479 235 500 minecraft:basalt
fill 475 235 503 478 235 503 minecraft:red_terracotta
fill 475 235 505 475 307 505 minecraft:orange_terracotta
setblock 476 235 469 minecraft:basalt
fill 476 235 482 476 243 482 minecraft:basalt
setblock 476 235 483 minecraft:magma_block
fill 476 235 484 476 244 485 minecraft:basalt
setblock 476 235 486 minecraft:magma_block
fill 476 235 487 476 243 488 minecraft:basalt
setblock 476 235 489 minecraft:magma_block
setblock 476 235 501 minecraft:magma_block
setblock 477 235 465 minecraft:terracotta
fill 477 235 468 479 235 468 minecraft:basalt
fill 477 235 478 477 242 480 minecraft:basalt
fill 477 235 490 477 243 491 minecraft:basalt
fill 477 235 501 479 236 501 minecraft:basalt
setblock 478 235 464 minecraft:terracotta
fill 478 235 465 481 235 465 minecraft:red_terracotta
fill 478 235 478 478 244 478 minecraft:basalt
fill 478 235 492 478 244 492 minecraft:basalt
setblock 478 235 504 minecraft:terracotta
fill 479 235 464 482 235 464 minecraft:red_terracotta
setblock 479 235 467 minecraft:magma_block
setblock 479 235 476 minecraft:magma_block
setblock 479 235 494 minecraft:magma_block
setblock 479 235 503 minecraft:magma_block
fill 479 235 504 480 237 504 minecraft:red_terracotta
fill 480 235 495 480 242 495 minecraft:basalt
fill 480 235 503 482 235 503 minecraft:basalt
setblock 481 235 466 minecraft:basalt
setblock 482 235 465 minecraft:terracotta
setblock 482 235 466 minecraft:magma_block
fill 482 235 474 482 244 474 minecraft:basalt
setblock 482 235 496 minecraft:magma_block
fill 482 235 505 482 307 505 minecraft:orange_terracotta
setblock 483 235 464 minecraft:terracotta
fill 483 235 465 484 235 466 minecraft:basalt
fill 483 235 473 484 235 473 minecraft:basalt
fill 483 235 497 484 235 497 minecraft:basalt
fill 484 235 464 487 235 464 minecraft:red_terracotta
fill 484 235 498 484 241 498 minecraft:basalt
setblock 485 235 465 minecraft:magma_block
setblock 485 235 498 minecraft:magma_block
fill 486 235 465 487 235 465 minecraft:basalt
fill 486 235 472 490 235 472 minecraft:basalt
fill 486 235 498 486 242 499 minecraft:basalt
fill 487 235 463 487 307 463 minecraft:orange_terracotta
fill 487 235 498 492 235 498 minecraft:basalt
fill 488 235 505 488 307 505 minecraft:orange_terracotta
fill 489 235 465 493 235 465 minecraft:basalt
fill 489 235 471 489 242 471 minecraft:basalt
fill 491 235 463 491 307 463 minecraft:orange_terracotta
setblock 491 235 472 minecraft:magma_block
fill 492 235 472 492 243 472 minecraft:basalt
fill 494 235 464 497 235 464 minecraft:red_terracotta
setblock 494 235 465 minecraft:magma_block
fill 494 235 466 497 235 466 minecraft:basalt
fill 494 235 473 495 243 473 minecraft:basalt
fill 494 235 497 495 243 497 minecraft:basalt
setblock 495 235 465 minecraft:basalt
fill 495 235 472 495 242 472 minecraft:basalt
fill 495 235 502 499 236 502 minecraft:basalt
fill 496 235 474 496 244 474 minecraft:basalt
fill 496 235 496 496 244 496 minecraft:basalt
fill 497 235 468 501 235 468 minecraft:basalt
setblock 498 235 464 minecraft:terracotta
fill 498 235 471 504 235 471 minecraft:basalt
fill 498 235 495 498 242 495 minecraft:basalt
fill 498 235 501 502 235 501 minecraft:basalt
setblock 498 235 504 minecraft:terracotta
fill 499 235 464 501 236 464 minecraft:red_terracotta
fill 499 235 504 502 235 504 minecraft:red_terracotta
fill 500 235 470 503 235 470 minecraft:basalt
setblock 500 235 478 minecraft:magma_block
fill 500 235 492 500 244 492 minecraft:basalt
setblock 500 235 493 minecraft:magma_block
fill 500 235 500 503 235 500 minecraft:basalt
setblock 500 235 502 minecraft:magma_block
fill 500 235 503 503 235 503 minecraft:red_terracotta
fill 501 235 473 505 236 473 minecraft:basalt
fill 501 235 476 507 235 476 minecraft:basalt
fill 501 235 479 501 242 480 minecraft:basalt
fill 501 235 490 501 242 491 minecraft:basalt
fill 501 235 493 507 235 494 minecraft:basalt
fill 501 235 497 505 236 497 minecraft:basalt
setblock 501 235 502 minecraft:basalt
fill 501 235 505 501 307 505 minecraft:orange_terracotta
fill 502 235 482 502 235 488 minecraft:basalt
setblock 502 235 502 minecraft:red_terracotta
fill 503 235 472 505 235 472 minecraft:basalt
fill 503 235 475 507 235 475 minecraft:basalt
fill 503 235 478 508 235 478 minecraft:basalt
fill 503 235 496 506 235 496 minecraft:basalt
fill 503 235 499 504 235 499 minecraft:basalt
setblock 503 235 504 minecraft:terracotta
fill 504 235 504 505 237 504 minecraft:red_terracotta
fill 504 235 505 504 307 505 minecraft:orange_terracotta
fill 505 235 463 505 307 463 minecraft:orange_terracotta
setblock 506 235 473 minecraft:magma_block
fill 506 235 477 508 235 477 minecraft:basalt
fill 506 235 480 509 235 480 minecraft:basalt
fill 506 235 483 509 235 483 minecraft:basalt
fill 506 235 486 509 236 486 minecraft:basalt
fill 506 235 489 509 235 489 minecraft:basalt
fill 506 235 492 508 235 492 minecraft:basalt
fill 506 235 495 507 235 495 minecraft:basalt
setblock 506 235 497 minecraft:magma_block
setblock 508 235 493 minecraft:basalt
setblock 509 235 481 minecraft:magma_block
setblock 509 235 484 minecraft:magma_block
setblock 509 235 487 minecraft:magma_block
setblock 509 235 490 minecraft:magma_block
setblock 509 235 491 minecraft:basalt
fill 510 235 479 510 235 481 minecraft:red_terracotta
setblock 510 235 482 minecraft:terracotta
fill 510 235 483 511 237 483 minecraft:red_terracotta
fill 510 235 505 510 307 505 minecraft:orange_terracotta
setblock 511 235 476 minecraft:terracotta
fill 511 235 477 511 235 480 minecraft:red_terracotta
setblock 511 235 481 minecraft:terracotta
fill 511 235 482 511 238 482 minecraft:red_terracotta
fill 511 235 484 511 235 485 minecraft:red_terracotta
setblock 511 235 486 minecraft:terracotta
fill 512 235 471 512 307 471 minecraft:orange_terracotta
fill 512 235 496 512 307 497 minecraft:orange_terracotta
setblock 471 236 464 minecraft:red_terracotta
setblock 471 236 465 minecraft:terracotta
fill 471 236 466 471 239 466 minecraft:red_terracotta
fill 471 236 473 471 237 473 minecraft:red_terracotta
setblock 471 236 475 minecraft:terracotta
fill 471 236 476 471 239 476 minecraft:red_terracotta
fill 471 236 477 472 236 493 minecraft:basalt
fill 471 236 503 471 236 504 minecraft:red_terracotta
setblock 472 236 464 minecraft:terracotta
fill 472 236 475 472 236 476 minecraft:basalt
setblock 472 236 494 minecraft:basalt
setblock 472 236 495 minecraft:magma_block
setblock 472 236 504 minecraft:terracotta
fill 473 236 464 475 236 465 minecraft:red_terracotta
fill 473 236 504 476 236 504 minecraft:red_terracotta
fill 474 236 472 475 236 472 minecraft:basalt
fill 474 236 498 475 236 498 minecraft:basalt
fill 474 236 503 477 236 503 minecraft:red_terracotta
setblock 475 236 471 minecraft:basalt
setblock 475 236 499 minecraft:basalt
setblock 476 236 464 minecraft:red_terracotta
setblock 476 236 465 minecraft:terracotta
fill 476 236 466 479 236 466 minecraft:red_terracotta
fill 476 236 470 481 236 470 minecraft:basalt
fill 476 236 483 476 243 483 minecraft:basalt
fill 476 236 486 476 243 486 minecraft:basalt
fill 476 236 489 477 243 489 minecraft:basalt
fill 476 236 500 479 236 500 minecraft:basalt
fill 476 236 502 478 236 502 minecraft:red_terracotta
setblock 477 236 464 minecraft:terracotta
fill 477 236 465 480 236 465 minecraft:red_terracotta
setblock 477 236 469 minecraft:basalt
fill 477 236 481 477 244 482 minecraft:basalt
fill 477 236 488 477 244 488 minecraft:basalt
setblock 477 236 504 minecraft:terracotta
fill 478 236 464 481 236 464 minecraft:red_terracotta
setblock 478 236 469 minecraft:magma_block
fill 478 236 479 478 244 479 minecraft:basalt
fill 478 236 491 478 244 491 minecraft:basalt
setblock 478 236 503 minecraft:terracotta
fill 478 236 504 478 239 504 minecraft:red_terracotta
fill 479 236 468 479 236 469 minecraft:basalt
fill 479 236 476 479 243 478 minecraft:basalt
fill 479 236 492 479 243 494 minecraft:basalt
fill 479 236 502 484 236 502 minecraft:basalt
fill 479 236 503 480 238 503 minecraft:red_terracotta
setblock 480 236 466 minecraft:terracotta
fill 480 236 469 484 237 469 minecraft:basalt
fill 480 236 476 480 244 476 minecraft:basalt
fill 480 236 494 480 244 494 minecraft:basalt
setblock 481 236 465 minecraft:terracotta
fill 481 236 467 482 236 467 minecraft:basalt
fill 481 236 475 482 243 475 minecraft:basalt
setblock 481 236 495 minecraft:magma_block
fill 481 236 503 482 236 503 minecraft:basalt
setblock 481 236 504 minecraft:red_terracotta
setblock 482 236 464 minecraft:terracotta
fill 482 236 465 483 238 465 minecraft:red_terracotta
fill 482 236 495 482 243 496 minecraft:basalt
setblock 482 236 504 minecraft:terracotta
fill 483 236 464 486 236 464 minecraft:red_terracotta
fill 483 236 466 484 236 466 minecraft:basalt
fill 483 236 473 483 242 474 minecraft:basalt
fill 483 236 496 483 242 497 minecraft:basalt
fill 483 236 504 487 236 504 minecraft:basalt
setblock 484 236 473 minecraft:magma_block
setblock 484 236 497 minecraft:magma_block
fill 485 236 473 486 244 473 minecraft:basalt
fill 485 236 497 485 243 498 minecraft:basalt
setblock 486 236 466 minecraft:basalt
fill 486 236 472 486 242 472 minecraft:basalt
fill 486 236 497 486 244 497 minecraft:basalt
setblock 487 236 464 minecraft:terracotta
setblock 487 236 466 minecraft:magma_block
setblock 487 236 472 minecraft:magma_block
fill 487 236 498 489 242 498 minecraft:basalt
fill 488 236 464 491 236 464 minecraft:red_terracotta
fill 488 236 466 495 236 466 minecraft:basalt
fill 488 236 472 491 243 472 minecraft:basalt
setblock 489 236 465 minecraft:basalt
fill 489 236 504 495 236 504 minecraft:basalt
setblock 490 236 465 minecraft:magma_block
setblock 490 236 498 minecraft:magma_block
fill 491 236 498 492 243 498 minecraft:basalt
setblock 492 236 464 minecraft:terracotta
fill 492 236 467 497 236 467 minecraft:basalt
fill 492 236 473 492 244 473 minecraft:basalt
fill 492 236 497 492 244 497 minecraft:basalt
fill 492 236 503 497 236 503 minecraft:basalt
fill 493 236 464 496 236 464 minecraft:red_terracotta
setblock 493 236 473 minecraft:magma_block
setblock 493 236 497 minecraft:magma_block
fill 495 236 469 501 236 469 minecraft:basalt
fill 495 236 474 495 244 474 minecraft:basalt
fill 495 236 496 495 244 496 minecraft:basalt
setblock 496 236 475 minecraft:magma_block
fill 496 236 495 497 244 495 minecraft:basalt
setblock 496 236 504 minecraft:red_terracotta
setblock 497 236 464 minecraft:terracotta
fill 497 236 468 498 236 468 minecraft:basalt
fill 497 236 475 497 244 475 minecraft:basalt
setblock 497 236 504 minecraft:terracotta
fill 498 236 464 498 239 464 minecraft:red_terracotta
fill 498 236 471 503 236 471 minecraft:basalt
fill 498 236 476 498 244 476 minecraft:basalt
fill 498 236 494 498 244 494 minecraft:basalt
fill 498 236 501 501 236 501 minecraft:basalt
setblock 498 236 503 minecraft:terracotta
fill 498 236 504 501 236 504 minecraft:red_terracotta
setblock 499 236 468 minecraft:magma_block
setblock 499 236 477 minecraft:magma_block
fill 499 236 478 500 243 478 minecraft:basalt
setblock 499 236 492 minecraft:magma_block
fill 499 236 493 507 236 493 minecraft:basalt
fill 499 236 503 502 236 503 minecraft:red_terracotta
fill 500 236 470 501 236 470 minecraft:basalt
fill 500 236 479 500 244 479 minecraft:basalt
fill 500 236 491 500 244 491 minecraft:basalt
fill 500 236 498 504 236 498 minecraft:basalt
fill 500 236 500 501 236 500 minecraft:basalt
fill 500 236 502 501 238 502 minecraft:red_terracotta
fill 501 236 476 506 236 476 minecraft:basalt
fill 501 236 481 501 244 482 minecraft:basalt
fill 501 236 488 501 244 489 minecraft:basalt
fill 501 236 494 506 236 494 minecraft:basalt
setblock 502 236 464 minecraft:terracotta
setblock 502 236 470 minecraft:magma_block
fill 502 236 482 502 243 484 minecraft:basalt
setblock 502 236 485 minecraft:magma_block
fill 502 236 486 502 243 488 minecraft:basalt
setblock 502 236 500 minecraft:magma_block
setblock 502 236 504 minecraft:terracotta
fill 503 236 472 504 236 472 minecraft:basalt
fill 503 236 475 506 236 475 minecraft:basalt
fill 503 236 478 507 236 478 minecraft:basalt
fill 503 236 496 504 237 496 minecraft:basalt
setblock 503 236 499 minecraft:basalt
setblock 503 236 503 minecraft:terracotta
fill 503 236 504 503 239 504 minecraft:red_terracotta
setblock 505 236 496 minecraft:magma_block
fill 506 236 477 507 236 477 minecraft:basalt
fill 506 236 480 507 237 480 minecraft:basalt
fill 506 236 483 507 238 483 minecraft:basalt
fill 506 236 489 507 237 489 minecraft:basalt
fill 506 236 492 507 236 492 minecraft:basalt
setblock 506 236 495 minecraft:basalt
setblock 508 236 480 minecraft:magma_block
setblock 508 236 483 minecraft:magma_block
setblock 508 236 489 minecraft:magma_block
setblock 509 236 484 minecraft:basalt
fill 510 236 479 510 236 480 minecraft:red_terracotta
setblock 510 236 481 minecraft:terracotta
fill 510 236 482 510 239 482 minecraft:red_terracotta
fill 510 236 484 511 236 484 minecraft:red_terracotta
setblock 511 236 475 minecraft:terracotta
fill 511 236 476 511 236 479 minecraft:red_terracotta
setblock 511 236 480 minecraft:terracotta
fill 511 236 481 511 239 481 minecraft:red_terracotta
setblock 511 236 485 minecraft:terracotta
fill 511 236 486 511 238 487 minecraft:red_terracotta
setblock 471 237 464 minecraft:terracotta
fill 471 237 465 474 237 465 minecraft:red_terracotta
fill 471 237 467 471 237 468 minecraft:red_terracotta
setblock 471 237 469 minecraft:terracotta
fill 471 237 470 471 238 472 minecraft:red_terracotta
setblock 471 237 474 minecraft:terracotta
fill 471 237 475 471 240 475 minecraft:red_terracotta
fill 471 237 477 471 237 478 minecraft:red_terracotta
setblock 471 237 479 minecraft:magma_block
fill 471 237 480 472 237 481 minecraft:basalt
setblock 471 237 482 minecraft:magma_block
fill 471 237 483 472 238 487 minecraft:basalt
setblock 471 237 488 minecraft:magma_block
fill 471 237 489 472 237 490 minecraft:basalt
setblock 471 237 491 minecraft:magma_block
fill 471 237 501 471 237 503 minecraft:red_terracotta
setblock 471 237 504 minecraft:terracotta
fill 472 237 464 475 237 464 minecraft:red_terracotta
fill 472 237 466 472 237 467 minecraft:red_terracotta
fill 472 237 476 472 238 476 minecraft:red_terracotta
fill 472 237 477 472 237 479 minecraft:basalt
fill 472 237 482 472 238 482 minecraft:basalt
fill 472 237 488 472 238 488 minecraft:basalt
fill 472 237 491 472 237 493 minecraft:basalt
fill 472 237 504 475 237 504 minecraft:red_terracotta
setblock 473 237 466 minecraft:light[level=14]
setblock 473 237 474 minecraft:light[level=14]
fill 473 237 475 475 237 475 minecraft:basalt
fill 473 237 495 475 237 495 minecraft:basalt
setblock 473 237 498 minecraft:light[level=14]
fill 473 237 503 476 237 503 minecraft:red_terracotta
setblock 474 237 466 minecraft:terracotta
fill 474 237 474 475 237 474 minecraft:basalt
setblock 474 237 496 minecraft:magma_block
setblock 475 237 465 minecraft:terracotta
fill 475 237 466 478 237 466 minecraft:red_terracotta
fill 475 237 472 475 237 473 minecraft:basalt
fill 475 237 496 475 237 498 minecraft:basalt
fill 475 237 502 477 237 502 minecraft:red_terracotta
setblock 476 237 464 minecraft:terracotta
fill 476 237 465 479 237 465 minecraft:red_terracotta
setblock 476 237 471 minecraft:basalt
fill 476 237 473 480 237 473 minecraft:basalt
fill 476 237 497 480 237 497 minecraft:basalt
setblock 476 237 504 minecraft:terracotta
fill 477 237 464 480 237 464 minecraft:red_terracotta
setblock 477 237 471 minecraft:magma_block
setblock 477 237 483 minecraft:magma_block
fill 477 237 484 477 245 485 minecraft:basalt
setblock 477 237 486 minecraft:magma_block
fill 477 237 487 477 245 487 minecraft:basalt
setblock 477 237 503 minecraft:terracotta
fill 477 237 504 477 240 504 minecraft:red_terracotta
fill 478 237 470 478 237 471 minecraft:basalt
fill 478 237 480 478 244 481 minecraft:basalt
fill 478 237 489 478 244 490 minecraft:basalt
fill 478 237 500 479 237 500 minecraft:basalt
setblock 478 237 502 minecraft:terracotta
fill 478 237 503 478 240 503 minecraft:red_terracotta
setblock 479 237 466 minecraft:terracotta
fill 479 237 469 479 237 470 minecraft:basalt
fill 479 237 479 479 245 479 minecraft:basalt
fill 479 237 491 479 245 491 minecraft:basalt
setblock 479 237 501 minecraft:basalt
fill 479 237 502 480 239 502 minecraft:red_terracotta
setblock 480 237 465 minecraft:terracotta
fill 480 237 466 481 239 466 minecraft:red_terracotta
fill 480 237 470 481 238 470 minecraft:basalt
fill 480 237 477 480 245 477 minecraft:basalt
fill 480 237 493 480 245 493 minecraft:basalt
setblock 481 237 464 minecraft:terracotta
fill 481 237 465 481 240 465 minecraft:red_terracotta
fill 481 237 468 487 237 468 minecraft:basalt
fill 481 237 476 481 245 476 minecraft:basalt
setblock 481 237 482 minecraft:light[level=14]
setblock 481 237 490 minecraft:light[level=14]
fill 481 237 494 481 244 495 minecraft:basalt
fill 481 237 502 484 237 502 minecraft:basalt
setblock 481 237 503 minecraft:red_terracotta
setblock 481 237 504 minecraft:terracotta
fill 482 237 464 485 237 464 minecraft:red_terracotta
setblock 482 237 503 minecraft:terracotta
fill 482 237 504 485 237 504 minecraft:red_terracotta
setblock 483 237 475 minecraft:magma_block
fill 483 237 495 483 245 495 minecraft:basalt
setblock 484 237 465 minecraft:red_terracotta
fill 484 237 473 484 244 474 minecraft:basalt
fill 484 237 496 484 244 497 minecraft:basalt
fill 485 237 474 485 245 474 minecraft:basalt
fill 485 237 496 485 245 496 minecraft:basalt
setblock 486 237 464 minecraft:terracotta
setblock 486 237 504 minecraft:terracotta
fill 487 237 464 490 237 464 minecraft:red_terracotta
fill 487 237 466 491 237 466 minecraft:basalt
fill 487 237 472 487 243 473 minecraft:basalt
fill 487 237 497 488 245 497 minecraft:basalt
setblock 487 237 504 minecraft:basalt
fill 488 237 473 488 245 473 minecraft:basalt
setblock 489 237 473 minecraft:magma_block
setblock 489 237 474 minecraft:light[level=14]
setblock 489 237 482 minecraft:light[level=14]
setblock 489 237 490 minecraft:light[level=14]
setblock 489 237 497 minecraft:magma_block
fill 489 237 504 491 237 504 minecraft:basalt
fill 490 237 473 491 245 473 minecraft:basalt
fill 490 237 497 490 244 498 minecraft:basalt
setblock 491 237 464 minecraft:terracotta
fill 491 237 497 491 245 497 minecraft:basalt
fill 492 237 464 495 237 464 minecraft:red_terracotta
fill 492 237 467 495 237 467 minecraft:basalt
fill 492 237 503 495 237 503 minecraft:basalt
fill 492 237 504 495 237 504 minecraft:red_terracotta
fill 493 237 473 493 244 474 minecraft:basalt
fill 493 237 496 493 244 497 minecraft:basalt
fill 494 237 474 494 245 474 minecraft:basalt
fill 494 237 496 494 245 496 minecraft:basalt
fill 495 237 469 499 237 469 minecraft:basalt
fill 495 237 475 496 244 475 minecraft:basalt
setblock 495 237 495 minecraft:magma_block
fill 495 237 499 500 238 499 minecraft:basalt
fill 495 237 502 497 237 502 minecraft:basalt
setblock 496 237 464 minecraft:terracotta
fill 496 237 465 498 238 465 minecraft:red_terracotta
setblock 496 237 503 minecraft:red_terracotta
setblock 496 237 504 minecraft:terracotta
fill 497 237 464 497 240 464 minecraft:red_terracotta
setblock 497 237 466 minecraft:light[level=14]
setblock 497 237 468 minecraft:basalt
fill 497 237 476 497 245 476 minecraft:basalt
setblock 497 237 482 minecraft:light[level=14]
setblock 497 237 490 minecraft:light[level=14]
fill 497 237 494 497 245 494 minecraft:basalt
setblock 497 237 503 minecraft:terracotta
fill 497 237 504 500 237 504 minecraft:red_terracotta
fill 498 237 471 502 237 471 minecraft:basalt
fill 498 237 477 499 244 477 minecraft:basalt
fill 498 237 493 506 237 493 minecraft:basalt
fill 498 237 501 499 237 501 minecraft:basalt
setblock 498 237 502 minecraft:terracotta
fill 498 237 503 501 237 503 minecraft:red_terracotta
fill 499 237 464 500 237 464 minecraft:red_terracotta
fill 499 237 474 503 238 474 minecraft:basalt
fill 499 237 479 499 245 479 minecraft:basalt
fill 499 237 491 499 244 492 minecraft:basalt
fill 499 237 502 499 240 502 minecraft:red_terracotta
setblock 500 237 470 minecraft:basalt
fill 500 237 480 500 245 481 minecraft:basalt
fill 500 237 489 500 237 490 minecraft:basalt
fill 500 237 498 503 237 498 minecraft:basalt
setblock 500 237 500 minecraft:basalt
setblock 501 237 464 minecraft:terracotta
fill 501 237 473 503 237 473 minecraft:basalt
fill 501 237 476 505 237 476 minecraft:basalt
fill 501 237 483 501 245 483 minecraft:basalt
setblock 501 237 484 minecraft:magma_block
fill 501 237 485 501 245 486 minecraft:basalt
setblock 501 237 487 minecraft:magma_block
fill 501 237 494 505 237 494 minecraft:basalt
fill 501 237 497 503 237 497 minecraft:basalt
setblock 501 237 499 minecraft:magma_block
setblock 501 237 504 minecraft:terracotta
fill 502 237 464 503 239 464 minecraft:red_terracotta
fill 502 237 485 502 244 485 minecraft:basalt
setblock 502 237 499 minecraft:basalt
setblock 502 237 503 minecraft:terracotta
fill 502 237 504 502 240 504 minecraft:red_terracotta
setblock 503 237 472 minecraft:basalt
fill 503 237 475 505 237 475 minecraft:basalt
fill 503 237 478 506 237 478 minecraft:basalt
fill 503 237 503 503 238 503 minecraft:red_terracotta
setblock 504 237 474 minecraft:magma_block
setblock 505 237 466 minecraft:light[level=14]
setblock 505 237 474 minecraft:light[level=14]
setblock 505 237 498 minecraft:light[level=14]
setblock 506 237 477 minecraft:basalt
fill 506 237 479 506 238 479 minecraft:basalt
fill 506 237 481 506 237 482 minecraft:basalt
fill 506 237 486 506 239 488 minecraft:basalt
fill 506 237 490 506 237 492 minecraft:basalt
setblock 507 237 479 minecraft:magma_block
setblock 507 237 481 minecraft:basalt
setblock 507 237 482 minecraft:magma_block
fill 507 237 486 508 237 487 minecraft:basalt
setblock 507 237 488 minecraft:magma_block
setblock 507 237 490 minecraft:basalt
setblock 507 237 491 minecraft:magma_block
setblock 508 237 483 minecraft:basalt
fill 510 237 478 510 237 479 minecraft:red_terracotta
setblock 510 237 480 minecraft:terracotta
fill 510 237 481 510 240 481 minecraft:red_terracotta
setblock 510 237 484 minecraft:red_terracotta
setblock 510 237 485 minecraft:terracotta
fill 510 237 486 510 240 486 minecraft:red_terracotta
fill 511 237 475 511 237 478 minecraft:red_terracotta
setblock 511 237 479 minecraft:terracotta
fill 511 237 480 511 240 480 minecraft:red_terracotta
setblock 511 237 484 minecraft:terracotta
fill 511 237 485 511 240 485 minecraft:red_terracotta
setblock 511 237 488 minecraft:red_terracotta
fill 471 238 464 473 238 465 minecraft:red_terracotta
setblock 471 238 467 minecraft:red_terracotta
setblock 471 238 468 minecraft:terracotta
fill 471 238 469 472 240 469 minecraft:red_terracotta
setblock 471 238 473 minecraft:terracotta
fill 471 238 474 471 241 474 minecraft:red_terracotta
setblock 471 238 477 minecraft:red_terracotta
setblock 471 238 478 minecraft:terracotta
fill 471 238 479 471 239 481 minecraft:red_terracotta
setblock 471 238 482 minecraft:basalt
setblock 471 238 488 minecraft:basalt
fill 471 238 501 471 238 502 minecraft:red_terracotta
setblock 471 238 503 minecraft:terracotta
fill 471 238 504 474 238 504 minecraft:red_terracotta
setblock 472 238 466 minecraft:red_terracotta
setblock 472 238 467 minecraft:terracotta
fill 472 238 468 472 241 468 minecraft:red_terracotta
fill 472 238 470 472 239 470 minecraft:red_terracotta
fill 472 238 475 472 239 475 minecraft:red_terracotta
setblock 472 238 477 minecraft:terracotta
fill 472 238 478 472 241 478 minecraft:red_terracotta
fill 472 238 479 472 238 481 minecraft:basalt
fill 472 238 489 472 238 491 minecraft:basalt
setblock 472 238 502 minecraft:terracotta
fill 472 238 503 475 238 503 minecraft:red_terracotta
setblock 473 238 466 minecraft:terracotta
fill 473 238 467 473 241 467 minecraft:red_terracotta
setblock 473 238 477 minecraft:magma_block
fill 473 238 478 475 238 478 minecraft:basalt
setblock 473 238 492 minecraft:magma_block
fill 473 238 493 475 238 493 minecraft:basalt
setblock 474 238 464 minecraft:red_terracotta
setblock 474 238 465 minecraft:terracotta
fill 474 238 466 477 238 466 minecraft:red_terracotta
fill 474 238 475 475 238 475 minecraft:basalt
fill 474 238 477 475 239 477 minecraft:basalt
fill 474 238 492 475 239 492 minecraft:basalt
fill 474 238 495 475 238 495 minecraft:basalt
setblock 475 238 464 minecraft:terracotta
fill 475 238 465 478 238 465 minecraft:red_terracotta
setblock 475 238 474 minecraft:basalt
setblock 475 238 496 minecraft:basalt
fill 475 238 502 476 238 502 minecraft:red_terracotta
setblock 475 238 504 minecraft:terracotta
fill 476 238 464 479 238 464 minecraft:red_terracotta
setblock 476 238 473 minecraft:magma_block
setblock 476 238 497 minecraft:magma_block
setblock 476 238 503 minecraft:terracotta
fill 476 238 504 476 241 504 minecraft:red_terracotta
fill 477 238 473 480 239 473 minecraft:basalt
fill 477 238 483 478 238 483 minecraft:basalt
fill 477 238 486 478 238 486 minecraft:basalt
fill 477 238 497 478 238 498 minecraft:basalt
setblock 477 238 502 minecraft:terracotta
fill 477 238 503 477 241 503 minecraft:red_terracotta
setblock 478 238 466 minecraft:terracotta
setblock 478 238 471 minecraft:basalt
fill 478 238 482 478 245 482 minecraft:basalt
fill 478 238 484 478 246 485 minecraft:basalt
fill 478 238 487 478 245 488 minecraft:basalt
fill 478 238 499 484 238 499 minecraft:basalt
fill 478 238 502 478 241 502 minecraft:red_terracotta
setblock 479 238 465 minecraft:terracotta
fill 479 238 466 479 241 466 minecraft:red_terracotta
setblock 479 238 470 minecraft:basalt
fill 479 238 480 479 246 480 minecraft:basalt
setblock 479 238 490 minecraft:magma_block
fill 479 238 497 480 241 497 minecraft:basalt
setblock 479 238 500 minecraft:basalt
setblock 479 238 504 minecraft:red_terracotta
setblock 480 238 464 minecraft:terracotta
fill 480 238 465 480 241 465 minecraft:red_terracotta
fill 480 238 478 480 245 478 minecraft:basalt
fill 480 238 492 480 245 492 minecraft:basalt
setblock 480 238 504 minecraft:terracotta
fill 481 238 464 484 238 464 minecraft:red_terracotta
fill 481 238 469 484 238 469 minecraft:basalt
fill 481 238 477 481 244 477 minecraft:basalt
fill 481 238 493 481 245 493 minecraft:basalt
setblock 481 238 501 minecraft:basalt
setblock 481 238 502 minecraft:red_terracotta
setblock 481 238 503 minecraft:terracotta
fill 481 238 504 484 238 504 minecraft:red_terracotta
fill 482 238 476 482 245 476 minecraft:basalt
fill 482 238 494 482 245 494 minecraft:basalt
setblock 482 238 501 minecraft:magma_block
setblock 482 238 502 minecraft:terracotta
fill 482 238 503 485 238 503 minecraft:red_terracotta
fill 483 238 468 487 238 468 minecraft:basalt
fill 483 238 475 484 238 475 minecraft:basalt
fill 483 238 501 484 238 502 minecraft:basalt
setblock 484 238 465 minecraft:terracotta
fill 484 238 495 484 246 495 minecraft:basalt
setblock 485 238 464 minecraft:terracotta
fill 485 238 465 485 241 465 minecraft:red_terracotta
fill 485 238 501 487 240 501 minecraft:basalt
setblock 485 238 504 minecraft:terracotta
fill 486 238 464 489 238 464 minecraft:red_terracotta
fill 486 238 467 490 238 467 minecraft:basalt
fill 486 238 474 490 238 474 minecraft:basalt
fill 486 238 496 487 245 496 minecraft:basalt
fill 486 238 503 490 238 503 minecraft:basalt
fill 486 238 504 489 238 504 minecraft:red_terracotta
setblock 488 238 496 minecraft:magma_block
fill 489 238 468 495 238 468 minecraft:basalt
fill 489 238 473 489 245 473 minecraft:basalt
fill 489 238 496 489 245 497 minecraft:basalt
setblock 490 238 464 minecraft:terracotta
fill 490 238 496 492 245 496 minecraft:basalt
setblock 490 238 504 minecraft:terracotta
fill 491 238 464 494 238 464 minecraft:red_terracotta
setblock 491 238 474 minecraft:magma_block
fill 491 238 504 494 238 504 minecraft:red_terracotta
setblock 492 238 467 minecraft:basalt
fill 492 238 474 492 245 474 minecraft:basalt
setblock 492 238 503 minecraft:basalt
setblock 493 238 465 minecraft:red_terracotta
fill 493 238 503 495 238 503 minecraft:red_terracotta
setblock 494 238 465 minecraft:terracotta
fill 494 238 475 494 246 475 minecraft:basalt
fill 494 238 495 495 245 495 minecraft:basalt
setblock 495 238 464 minecraft:terracotta
fill 495 238 465 495 241 465 minecraft:red_terracotta
fill 495 238 469 496 238 469 minecraft:basalt
setblock 495 238 502 minecraft:basalt
setblock 495 238 504 minecraft:terracotta
fill 496 238 464 496 241 464 minecraft:red_terracotta
fill 496 238 472 501 238 472 minecraft:basalt
fill 496 238 476 496 245 476 minecraft:basalt
fill 496 238 494 496 245 494 minecraft:basalt
setblock 496 238 502 minecraft:red_terracotta
setblock 496 238 503 minecraft:terracotta
fill 496 238 504 499 238 504 minecraft:red_terracotta
setblock 497 238 469 minecraft:magma_block
fill 497 238 477 497 245 477 minecraft:basalt
setblock 497 238 493 minecraft:magma_block
setblock 497 238 502 minecraft:terracotta
fill 497 238 503 500 238 503 minecraft:red_terracotta
fill 498 238 471 499 239 471 minecraft:basalt
fill 498 238 478 498 245 478 minecraft:basalt
fill 498 238 492 498 245 493 minecraft:basalt
setblock 498 238 501 minecraft:terracotta
fill 498 238 502 498 241 502 minecraft:red_terracotta
setblock 499 238 464 minecraft:red_terracotta
setblock 499 238 465 minecraft:terracotta
fill 499 238 480 499 246 480 minecraft:basalt
fill 499 238 490 500 245 490 minecraft:basalt
fill 499 238 493 505 238 493 minecraft:basalt
setblock 500 238 464 minecraft:terracotta
setblock 500 238 471 minecraft:magma_block
fill 500 238 482 500 245 482 minecraft:basalt
setblock 500 238 483 minecraft:magma_block
fill 500 238 484 500 246 485 minecraft:basalt
setblock 500 238 486 minecraft:magma_block
fill 500 238 487 500 245 488 minecraft:basalt
setblock 500 238 489 minecraft:magma_block
fill 500 238 495 504 238 495 minecraft:basalt
fill 500 238 498 501 238 498 minecraft:basalt
setblock 500 238 504 minecraft:terracotta
fill 501 238 464 501 241 464 minecraft:red_terracotta
fill 501 238 473 502 238 473 minecraft:basalt
fill 501 238 476 504 238 476 minecraft:basalt
fill 501 238 484 501 245 484 minecraft:basalt
fill 501 238 487 501 245 487 minecraft:basalt
fill 501 238 494 504 238 494 minecraft:basalt
fill 501 238 497 502 238 497 minecraft:basalt
setblock 501 238 503 minecraft:terracotta
fill 501 238 504 501 241 504 minecraft:red_terracotta
fill 502 238 503 502 240 503 minecraft:red_terracotta
fill 503 238 475 504 238 475 minecraft:basalt
fill 503 238 478 505 238 478 minecraft:basalt
setblock 503 238 496 minecraft:basalt
setblock 504 238 504 minecraft:red_terracotta
setblock 505 238 504 minecraft:terracotta
setblock 506 238 480 minecraft:basalt
setblock 506 238 481 minecraft:magma_block
fill 506 238 482 507 238 482 minecraft:basalt
fill 506 238 484 507 238 485 minecraft:basalt
setblock 506 238 489 minecraft:basalt
setblock 506 238 490 minecraft:magma_block
setblock 506 238 491 minecraft:basalt
fill 506 238 504 506 239 504 minecraft:red_terracotta
fill 507 238 486 507 238 488 minecraft:basalt
fill 509 238 482 509 239 483 minecraft:red_terracotta
setblock 510 238 464 minecraft:terracotta
setblock 510 238 478 minecraft:red_terracotta
setblock 510 238 479 minecraft:terracotta
fill 510 238 480 510 241 480 minecraft:red_terracotta
setblock 510 238 483 minecraft:red_terracotta
setblock 510 238 484 minecraft:terracotta
fill 510 238 485 510 241 485 minecraft:red_terracotta
fill 510 238 487 510 239 487 minecraft:red_terracotta
setblock 510 238 504 minecraft:terracotta
fill 511 238 464 511 238 467 minecraft:red_terracotta
setblock 511 238 473 minecraft:terracotta
fill 511 238 474 511 238 477 minecraft:red_terracotta
setblock 511 238 478 minecraft:terracotta
fill 511 238 479 511 241 479 minecraft:red_terracotta
setblock 511 238 483 minecraft:terracotta
fill 511 238 484 511 241 484 minecraft:red_terracotta
setblock 511 238 488 minecraft:terracotta
fill 511 238 489 511 240 490 minecraft:red_terracotta
setblock 511 238 502 minecraft:red_terracotta
setblock 511 238 503 minecraft:terracotta
fill 511 238 504 511 241 504 minecraft:red_terracotta
fill 471 239 464 472 239 465 minecraft:red_terracotta
setblock 471 239 467 minecraft:terracotta
fill 471 239 468 471 242 468 minecraft:red_terracotta
fill 471 239 470 471 239 471 minecraft:red_terracotta
setblock 471 239 472 minecraft:terracotta
fill 471 239 473 472 241 473 minecraft:red_terracotta
setblock 471 239 477 minecraft:terracotta
fill 471 239 478 471 242 478 minecraft:red_terracotta
setblock 471 239 482 minecraft:terracotta
fill 471 239 483 471 239 486 minecraft:red_terracotta
setblock 471 239 487 minecraft:terracotta
fill 471 239 488 471 241 489 minecraft:red_terracotta
fill 471 239 500 471 239 501 minecraft:red_terracotta
setblock 471 239 502 minecraft:terracotta
fill 471 239 503 473 239 504 minecraft:red_terracotta
setblock 472 239 466 minecraft:terracotta
fill 472 239 467 472 242 467 minecraft:red_terracotta
setblock 472 239 471 minecraft:terracotta
fill 472 239 472 472 242 472 minecraft:red_terracotta
fill 472 239 474 472 240 474 minecraft:red_terracotta
setblock 472 239 476 minecraft:terracotta
fill 472 239 477 472 242 477 minecraft:red_terracotta
fill 472 239 479 472 239 480 minecraft:red_terracotta
setblock 472 239 481 minecraft:terracotta
setblock 472 239 482 minecraft:magma_block
fill 472 239 483 472 239 484 minecraft:basalt
setblock 472 239 485 minecraft:magma_block
fill 472 239 486 472 239 487 minecraft:basalt
setblock 472 239 488 minecraft:magma_block
fill 472 239 502 472 242 502 minecraft:red_terracotta
setblock 473 239 464 minecraft:red_terracotta
setblock 473 239 465 minecraft:terracotta
fill 473 239 466 476 239 466 minecraft:red_terracotta
fill 473 239 468 473 239 469 minecraft:red_terracotta
setblock 474 239 464 minecraft:terracotta
fill 474 239 465 477 239 465 minecraft:red_terracotta
fill 474 239 467 475 239 467 minecraft:red_terracotta
fill 474 239 478 475 240 478 minecraft:basalt
fill 474 239 493 475 239 493 minecraft:basalt
fill 474 239 502 474 239 503 minecraft:red_terracotta
setblock 474 239 504 minecraft:terracotta
fill 475 239 464 478 239 464 minecraft:red_terracotta
setblock 475 239 475 minecraft:magma_block
fill 475 239 476 477 239 476 minecraft:basalt
fill 475 239 494 475 239 495 minecraft:basalt
setblock 475 239 502 minecraft:red_terracotta
setblock 475 239 503 minecraft:terracotta
fill 475 239 504 475 242 504 minecraft:red_terracotta
setblock 476 239 467 minecraft:terracotta
fill 476 239 494 477 240 494 minecraft:basalt
setblock 476 239 502 minecraft:terracotta
fill 476 239 503 476 242 503 minecraft:red_terracotta
setblock 477 239 466 minecraft:terracotta
fill 477 239 467 478 241 467 minecraft:red_terracotta
fill 477 239 483 477 245 483 minecraft:basalt
fill 477 239 486 477 245 486 minecraft:basalt
fill 477 239 497 478 239 497 minecraft:basalt
fill 477 239 502 477 242 502 minecraft:red_terracotta
setblock 478 239 465 minecraft:terracotta
fill 478 239 466 478 242 466 minecraft:red_terracotta
fill 478 239 472 482 239 472 minecraft:basalt
setblock 478 239 483 minecraft:magma_block
setblock 478 239 486 minecraft:magma_block
setblock 478 239 498 minecraft:magma_block
setblock 479 239 464 minecraft:terracotta
fill 479 239 465 479 242 465 minecraft:red_terracotta
fill 479 239 481 479 246 482 minecraft:basalt
fill 479 239 488 479 246 490 minecraft:basalt
fill 479 239 499 484 239 499 minecraft:basalt
setblock 479 239 503 minecraft:red_terracotta
setblock 479 239 504 minecraft:terracotta
fill 480 239 464 483 239 464 minecraft:red_terracotta
fill 480 239 479 480 245 479 minecraft:basalt
fill 480 239 491 480 245 491 minecraft:basalt
setblock 480 239 503 minecraft:terracotta
fill 480 239 504 483 239 504 minecraft:red_terracotta
setblock 481 239 470 minecraft:magma_block
fill 481 239 478 481 246 478 minecraft:basalt
fill 481 239 492 481 246 492 minecraft:basalt
setblock 481 239 500 minecraft:magma_block
setblock 481 239 502 minecraft:terracotta
fill 481 239 503 484 239 503 minecraft:red_terracotta
setblock 482 239 465 minecraft:red_terracotta
fill 482 239 477 482 246 477 minecraft:basalt
fill 482 239 493 482 246 493 minecraft:basalt
fill 482 239 502 483 239 502 minecraft:red_terracotta
setblock 483 239 465 minecraft:terracotta
setblock 483 239 469 minecraft:basalt
fill 483 239 475 483 245 476 minecraft:basalt
fill 483 239 494 483 246 494 minecraft:basalt
fill 483 239 501 484 239 501 minecraft:basalt
setblock 484 239 464 minecraft:terracotta
fill 484 239 465 484 242 465 minecraft:red_terracotta
setblock 484 239 469 minecraft:magma_block
setblock 484 239 475 minecraft:magma_block
setblock 484 239 504 minecraft:terracotta
fill 485 239 464 488 239 464 minecraft:red_terracotta
fill 485 239 475 486 246 475 minecraft:basalt
fill 485 239 495 486 245 495 minecraft:basalt
setblock 485 239 503 minecraft:terracotta
fill 485 239 504 488 239 504 minecraft:red_terracotta
fill 486 239 468 486 239 469 minecraft:basalt
fill 486 239 474 486 245 474 minecraft:basalt
fill 486 239 502 492 239 502 minecraft:basalt
fill 486 239 503 489 239 503 minecraft:red_terracotta
setblock 487 239 468 minecraft:magma_block
fill 487 239 469 492 239 469 minecraft:basalt
setblock 487 239 474 minecraft:magma_block
fill 488 239 474 491 246 474 minecraft:basalt
fill 488 239 496 488 246 496 minecraft:basalt
setblock 489 239 464 minecraft:terracotta
fill 489 239 468 492 239 468 minecraft:basalt
fill 489 239 501 495 239 501 minecraft:basalt
setblock 489 239 504 minecraft:terracotta
fill 490 239 464 493 239 464 minecraft:red_terracotta
setblock 490 239 503 minecraft:terracotta
fill 490 239 504 493 239 504 minecraft:red_terracotta
fill 491 239 465 492 239 465 minecraft:red_terracotta
fill 491 239 503 494 239 503 minecraft:red_terracotta
fill 492 239 470 497 239 470 minecraft:basalt
fill 492 239 475 492 245 475 minecraft:basalt
fill 492 239 495 493 239 495 minecraft:basalt
fill 492 239 500 497 239 500 minecraft:basalt
setblock 493 239 465 minecraft:terracotta
setblock 493 239 469 minecraft:magma_block
setblock 493 239 475 minecraft:magma_block
fill 493 239 502 495 239 502 minecraft:red_terracotta
setblock 494 239 464 minecraft:terracotta
fill 494 239 465 494 242 465 minecraft:red_terracotta
setblock 494 239 504 minecraft:terracotta
fill 495 239 464 495 242 464 minecraft:red_terracotta
setblock 495 239 469 minecraft:basalt
fill 495 239 476 495 246 476 minecraft:basalt
fill 495 239 494 495 246 494 minecraft:basalt
fill 495 239 499 499 239 499 minecraft:basalt
setblock 495 239 503 minecraft:terracotta
fill 495 239 504 498 239 504 minecraft:red_terracotta
fill 496 239 465 497 239 465 minecraft:red_terracotta
fill 496 239 472 500 239 472 minecraft:basalt
setblock 496 239 477 minecraft:magma_block
fill 496 239 493 497 245 493 minecraft:basalt
setblock 496 239 501 minecraft:red_terracotta
setblock 496 239 502 minecraft:terracotta
fill 496 239 503 499 239 503 minecraft:red_terracotta
fill 497 239 478 497 246 478 minecraft:basalt
fill 497 239 492 497 246 492 minecraft:basalt
setblock 497 239 501 minecraft:terracotta
fill 497 239 502 497 242 502 minecraft:red_terracotta
setblock 498 239 465 minecraft:terracotta
fill 498 239 479 498 245 479 minecraft:basalt
fill 498 239 491 498 245 491 minecraft:basalt
setblock 499 239 464 minecraft:terracotta
fill 499 239 465 500 241 465 minecraft:red_terracotta
fill 499 239 474 502 239 474 minecraft:basalt
fill 499 239 481 499 246 481 minecraft:basalt
setblock 499 239 482 minecraft:magma_block
setblock 499 239 488 minecraft:magma_block
fill 499 239 489 500 245 489 minecraft:basalt
fill 499 239 493 504 239 493 minecraft:basalt
fill 499 239 496 501 240 496 minecraft:basalt
setblock 499 239 504 minecraft:terracotta
fill 500 239 464 500 242 464 minecraft:red_terracotta
fill 500 239 483 500 246 483 minecraft:basalt
fill 500 239 486 500 246 486 minecraft:basalt
fill 500 239 495 503 239 495 minecraft:basalt
setblock 500 239 498 minecraft:basalt
setblock 500 239 502 minecraft:red_terracotta
setblock 500 239 503 minecraft:terracotta
fill 500 239 504 500 242 504 minecraft:red_terracotta
setblock 501 239 473 minecraft:basalt
fill 501 239 476 503 239 476 minecraft:basalt
fill 501 239 494 503 239 494 minecraft:basalt
setblock 501 239 497 minecraft:basalt
fill 501 239 503 501 241 503 minecraft:red_terracotta
setblock 502 239 496 minecraft:magma_block
setblock 503 239 475 minecraft:basalt
fill 503 239 477 504 239 480 minecraft:basalt
fill 503 239 491 504 239 492 minecraft:basalt
setblock 504 239 464 minecraft:terracotta
fill 504 239 481 504 240 490 minecraft:basalt
setblock 504 239 504 minecraft:terracotta
setblock 505 239 479 minecraft:basalt
setblock 505 239 480 minecraft:magma_block
fill 505 239 481 505 240 488 minecraft:basalt
setblock 505 239 489 minecraft:magma_block
fill 505 239 490 505 239 491 minecraft:basalt
fill 505 239 504 505 240 504 minecraft:red_terracotta
fill 506 239 482 506 239 485 minecraft:basalt
setblock 508 239 464 minecraft:red_terracotta
setblock 509 239 464 minecraft:terracotta
fill 509 239 481 509 241 481 minecraft:red_terracotta
setblock 509 239 484 minecraft:terracotta
fill 509 239 485 509 242 485 minecraft:red_terracotta
setblock 509 239 504 minecraft:terracotta
fill 510 239 464 511 241 464 minecraft:red_terracotta
setblock 510 239 477 minecraft:red_terracotta
setblock 510 239 478 minecraft:terracotta
fill 510 239 479 510 242 479 minecraft:red_terracotta
setblock 510 239 483 minecraft:terracotta
fill 510 239 484 510 242 484 minecraft:red_terracotta
setblock 510 239 488 minecraft:terracotta
fill 510 239 504 510 242 504 minecraft:red_terracotta
fill 511 239 465 511 239 466 minecraft:red_terracotta
setblock 511 239 467 minecraft:terracotta
fill 511 239 468 511 239 471 minecraft:red_terracotta
setblock 511 239 472 minecraft:terracotta
fill 511 239 473 511 239 476 minecraft:red_terracotta
setblock 511 239 477 minecraft:terracotta
fill 511 239 478 511 242 478 minecraft:red_terracotta
setblock 511 239 482 minecraft:terracotta
fill 511 239 483 511 242 483 minecraft:red_terracotta
setblock 511 239 486 minecraft:red_terracotta
setblock 511 239 487 minecraft:terracotta
fill 511 239 488 511 242 488 minecraft:red_terracotta
setblock 511 239 491 minecraft:red_terracotta
setblock 511 239 501 minecraft:red_terracotta
setblock 511 239 502 minecraft:terracotta
fill 511 239 503 511 242 503 minecraft:red_terracotta
fill 471 240 464 471 240 465 minecraft:red_terracotta
setblock 471 240 466 minecraft:terracotta
fill 471 240 467 471 243 467 minecraft:red_terracotta
setblock 471 240 470 minecraft:red_terracotta
setblock 471 240 471 minecraft:terracotta
fill 471 240 472 471 243 472 minecraft:red_terracotta
setblock 471 240 476 minecraft:terracotta
fill 471 240 477 471 243 477 minecraft:red_terracotta
fill 471 240 479 471 240 480 minecraft:red_terracotta
setblock 471 240 481 minecraft:terracotta
fill 471 240 482 471 240 485 minecraft:red_terracotta
setblock 471 240 486 minecraft:terracotta
fill 471 240 487 472 242 487 minecraft:red_terracotta
setblock 471 240 490 minecraft:red_terracotta
setblock 471 240 500 minecraft:red_terracotta
setblock 471 240 501 minecraft:terracotta
fill 471 240 502 471 241 504 minecraft:red_terracotta
setblock 472 240 464 minecraft:red_terracotta
setblock 472 240 465 minecraft:terracotta
fill 472 240 466 475 240 466 minecraft:red_terracotta
setblock 472 240 470 minecraft:terracotta
fill 472 240 471 472 243 471 minecraft:red_terracotta
setblock 472 240 475 minecraft:terracotta
fill 472 240 476 472 243 476 minecraft:red_terracotta
setblock 472 240 479 minecraft:red_terracotta
setblock 472 240 480 minecraft:terracotta
fill 472 240 481 472 240 484 minecraft:red_terracotta
setblock 472 240 485 minecraft:terracotta
fill 472 240 486 472 243 486 minecraft:red_terracotta
fill 472 240 488 472 241 488 minecraft:red_terracotta
fill 472 240 501 472 242 501 minecraft:red_terracotta
fill 472 240 503 472 240 504 minecraft:red_terracotta
setblock 473 240 464 minecraft:terracotta
fill 473 240 465 476 240 465 minecraft:red_terracotta
setblock 473 240 468 minecraft:red_terracotta
setblock 473 240 469 minecraft:terracotta
fill 473 240 470 473 243 470 minecraft:red_terracotta
setblock 473 240 479 minecraft:terracotta
fill 473 240 480 473 241 480 minecraft:red_terracotta
fill 473 240 481 474 240 481 minecraft:basalt
fill 473 240 489 474 240 489 minecraft:basalt
setblock 473 240 503 minecraft:red_terracotta
setblock 473 240 504 minecraft:terracotta
fill 474 240 464 477 240 464 minecraft:red_terracotta
setblock 474 240 467 minecraft:red_terracotta
setblock 474 240 468 minecraft:terracotta
setblock 474 240 480 minecraft:magma_block
setblock 474 240 490 minecraft:basalt
setblock 474 240 492 minecraft:magma_block
setblock 474 240 502 minecraft:red_terracotta
setblock 474 240 503 minecraft:terracotta
fill 474 240 504 474 243 504 minecraft:red_terracotta
setblock 475 240 467 minecraft:terracotta
setblock 475 240 477 minecraft:basalt
fill 475 240 492 475 240 493 minecraft:basalt
setblock 475 240 502 minecraft:terracotta
fill 475 240 503 475 243 503 minecraft:red_terracotta
setblock 476 240 466 minecraft:terracotta
fill 476 240 467 476 243 467 minecraft:red_terracotta
fill 476 240 476 477 240 476 minecraft:basalt
fill 476 240 502 476 243 502 minecraft:red_terracotta
setblock 477 240 465 minecraft:terracotta
fill 477 240 466 477 243 466 minecraft:red_terracotta
fill 477 240 474 478 240 474 minecraft:basalt
setblock 478 240 464 minecraft:terracotta
fill 478 240 465 478 243 465 minecraft:red_terracotta
fill 478 240 473 480 240 473 minecraft:basalt
fill 478 240 483 479 246 483 minecraft:basalt
fill 478 240 486 479 240 486 minecraft:basalt
setblock 478 240 497 minecraft:basalt
setblock 478 240 504 minecraft:terracotta
fill 479 240 464 482 240 464 minecraft:red_terracotta
setblock 479 240 472 minecraft:basalt
fill 479 240 484 479 246 485 minecraft:basalt
fill 479 240 487 479 246 487 minecraft:basalt
setblock 479 240 502 minecraft:red_terracotta
setblock 479 240 503 minecraft:terracotta
fill 479 240 504 482 240 504 minecraft:red_terracotta
setblock 480 240 466 minecraft:red_terracotta
setblock 480 240 472 minecraft:magma_block
fill 480 240 480 480 247 480 minecraft:basalt
setblock 480 240 481 minecraft:magma_block
fill 480 240 489 480 247 489 minecraft:basalt
setblock 480 240 490 minecraft:magma_block
setblock 480 240 502 minecraft:terracotta
fill 480 240 503 483 240 503 minecraft:red_terracotta
setblock 481 240 466 minecraft:terracotta
fill 481 240 471 482 240 472 minecraft:basalt
fill 481 240 479 481 247 479 minecraft:basalt
fill 481 240 491 481 247 491 minecraft:basalt
fill 481 240 499 484 240 499 minecraft:basalt
fill 481 240 502 482 240 502 minecraft:red_terracotta
setblock 482 240 465 minecraft:terracotta
setblock 482 240 466 minecraft:red_terracotta
fill 482 240 478 482 247 478 minecraft:basalt
fill 482 240 492 482 246 492 minecraft:basalt
setblock 483 240 464 minecraft:terracotta
fill 483 240 465 483 243 465 minecraft:red_terracotta
fill 483 240 471 483 241 471 minecraft:basalt
setblock 483 240 477 minecraft:magma_block
fill 483 240 493 483 247 493 minecraft:basalt
setblock 483 240 504 minecraft:terracotta
fill 484 240 464 487 240 464 minecraft:red_terracotta
fill 484 240 475 484 246 476 minecraft:basalt
fill 484 240 494 485 246 494 minecraft:basalt
setblock 484 240 503 minecraft:terracotta
fill 484 240 504 487 240 504 minecraft:red_terracotta
fill 485 240 476 485 246 476 minecraft:basalt
fill 485 240 503 488 240 503 minecraft:red_terracotta
setblock 486 240 465 minecraft:red_terracotta
fill 486 240 469 488 240 469 minecraft:basalt
setblock 487 240 465 minecraft:terracotta
fill 487 240 474 487 246 475 minecraft:basalt
fill 487 240 495 491 240 495 minecraft:basalt
setblock 488 240 464 minecraft:terracotta
fill 488 240 465 491 240 465 minecraft:red_terracotta
fill 488 240 475 488 246 475 minecraft:basalt
setblock 488 240 504 minecraft:terracotta
fill 489 240 464 492 240 464 minecraft:red_terracotta
setblock 489 240 469 minecraft:magma_block
setblock 489 240 475 minecraft:magma_block
fill 489 240 501 491 240 501 minecraft:basalt
setblock 489 240 502 minecraft:red_terracotta
setblock 489 240 503 minecraft:terracotta
fill 489 240 504 492 240 504 minecraft:red_terracotta
fill 490 240 469 493 240 469 minecraft:basalt
fill 490 240 475 491 247 475 minecraft:basalt
setblock 490 240 502 minecraft:terracotta
fill 490 240 503 493 240 503 minecraft:red_terracotta
fill 491 240 502 494 240 502 minecraft:red_terracotta
setblock 492 240 465 minecraft:terracotta
fill 492 240 470 494 240 470 minecraft:basalt
setblock 492 240 495 minecraft:magma_block
fill 492 240 500 494 240 500 minecraft:basalt
setblock 492 240 501 minecraft:magma_block
setblock 493 240 464 minecraft:terracotta
fill 493 240 465 493 243 465 minecraft:red_terracotta
fill 493 240 475 493 246 476 minecraft:basalt
fill 493 240 494 493 246 495 minecraft:basalt
setblock 493 240 501 minecraft:basalt
setblock 493 240 504 minecraft:terracotta
fill 494 240 464 494 243 464 minecraft:red_terracotta
fill 494 240 476 494 246 476 minecraft:basalt
fill 494 240 494 494 246 494 minecraft:basalt
setblock 494 240 503 minecraft:terracotta
fill 494 240 504 497 240 504 minecraft:red_terracotta
setblock 495 240 470 minecraft:magma_block
fill 495 240 477 496 246 477 minecraft:basalt
fill 495 240 493 495 247 493 minecraft:basalt
fill 495 240 499 497 240 499 minecraft:basalt
setblock 495 240 500 minecraft:magma_block
setblock 495 240 501 minecraft:red_terracotta
setblock 495 240 502 minecraft:terracotta
fill 495 240 503 498 240 503 minecraft:red_terracotta
setblock 496 240 465 minecraft:red_terracotta
setblock 496 240 470 minecraft:basalt
fill 496 240 472 497 241 472 minecraft:basalt
fill 496 240 478 496 247 478 minecraft:basalt
fill 496 240 492 496 247 492 minecraft:basalt
setblock 496 240 500 minecraft:basalt
fill 496 240 502 496 242 502 minecraft:red_terracotta
setblock 497 240 465 minecraft:terracotta
fill 497 240 479 497 247 479 minecraft:basalt
fill 497 240 491 497 247 491 minecraft:basalt
setblock 498 240 464 minecraft:terracotta
fill 498 240 465 498 243 465 minecraft:red_terracotta
setblock 498 240 472 minecraft:magma_block
fill 498 240 480 498 247 480 minecraft:basalt
setblock 498 240 481 minecraft:magma_block
fill 498 240 489 498 247 489 minecraft:basalt
setblock 498 240 490 minecraft:magma_block
setblock 498 240 504 minecraft:terracotta
fill 499 240 464 499 243 464 minecraft:red_terracotta
setblock 499 240 472 minecraft:basalt
fill 499 240 474 500 241 474 minecraft:basalt
fill 499 240 482 499 246 488 minecraft:basalt
fill 499 240 493 503 240 493 minecraft:basalt
setblock 499 240 503 minecraft:terracotta
fill 499 240 504 499 243 504 minecraft:red_terracotta
fill 500 240 495 502 240 495 minecraft:basalt
fill 500 240 503 500 242 503 minecraft:red_terracotta
setblock 501 240 474 minecraft:magma_block
fill 501 240 476 502 240 476 minecraft:basalt
fill 501 240 494 502 240 494 minecraft:basalt
setblock 502 240 464 minecraft:red_terracotta
setblock 503 240 464 minecraft:terracotta
fill 503 240 477 503 240 480 minecraft:basalt
fill 503 240 491 503 241 492 minecraft:basalt
setblock 503 240 504 minecraft:terracotta
fill 504 240 464 507 240 464 minecraft:red_terracotta
setblock 504 240 478 minecraft:basalt
setblock 504 240 479 minecraft:magma_block
setblock 504 240 480 minecraft:basalt
setblock 504 240 491 minecraft:magma_block
setblock 504 240 492 minecraft:basalt
fill 504 240 504 504 241 504 minecraft:red_terracotta
setblock 505 240 489 minecraft:basalt
setblock 508 240 464 minecraft:terracotta
setblock 508 240 504 minecraft:terracotta
fill 509 240 464 509 243 464 minecraft:red_terracotta
setblock 509 240 482 minecraft:red_terracotta
setblock 509 240 483 minecraft:terracotta
fill 509 240 484 509 243 484 minecraft:red_terracotta
fill 509 240 486 509 241 486 minecraft:red_terracotta
fill 509 240 504 509 242 504 minecraft:red_terracotta
fill 510 240 465 510 240 466 minecraft:red_terracotta
setblock 510 240 477 minecraft:terracotta
fill 510 240 478 510 243 478 minecraft:red_terracotta
setblock 510 240 482 minecraft:terracotta
fill 510 240 483 510 243 483 minecraft:red_terracotta
setblock 510 240 487 minecraft:terracotta
fill 510 240 488 510 242 489 minecraft:red_terracotta
setblock 511 240 465 minecraft:red_terracotta
setblock 511 240 466 minecraft:terracotta
fill 511 240 467 511 240 470 minecraft:red_terracotta
setblock 511 240 471 minecraft:terracotta
fill 511 240 472 511 240 475 minecraft:red_terracotta
setblock 511 240 476 minecraft:terracotta
fill 511 240 477 511 243 477 minecraft:red_terracotta
setblock 511 240 481 minecraft:terracotta
fill 511 240 482 511 243 482 minecraft:red_terracotta
setblock 511 240 486 minecraft:terracotta
fill 511 240 487 511 243 487 minecraft:red_terracotta
setblock 511 240 491 minecraft:terracotta
fill 511 240 492 511 243 492 minecraft:red_terracotta
setblock 511 240 501 minecraft:terracotta
fill 511 240 502 511 243 502 minecraft:red_terracotta
setblock 471 241 464 minecraft:red_terracotta
setblock 471 241 465 minecraft:terracotta
fill 471 241 466 474 241 466 minecraft:red_terracotta
setblock 471 241 469 minecraft:red_terracotta
setblock 471 241 470 minecraft:terracotta
fill 471 241 471 471 244 471 minecraft:red_terracotta
setblock 471 241 475 minecraft:terracotta
fill 471 241 476 471 244 476 minecraft:red_terracotta
setblock 471 241 479 minecraft:red_terracotta
setblock 471 241 480 minecraft:terracotta
fill 471 241 481 471 241 484 minecraft:red_terracotta
setblock 471 241 485 minecraft:terracotta
fill 471 241 486 471 244 486 minecraft:red_terracotta
setblock 471 241 490 minecraft:terracotta
fill 471 241 491 471 244 491 minecraft:red_terracotta
setblock 471 241 500 minecraft:terracotta
fill 471 241 501 471 244 501 minecraft:red_terracotta
setblock 472 241 464 minecraft:terracotta
fill 472 241 465 475 241 465 minecraft:red_terracotta
setblock 472 241 469 minecraft:terracotta
fill 472 241 470 472 244 470 minecraft:red_terracotta
setblock 472 241 474 minecraft:terracotta
fill 472 241 475 472 244 475 minecraft:red_terracotta
setblock 472 241 479 minecraft:terracotta
fill 472 241 480 472 241 483 minecraft:red_terracotta
setblock 472 241 484 minecraft:terracotta
fill 472 241 485 473 243 485 minecraft:red_terracotta
setblock 472 241 489 minecraft:terracotta
setblock 472 241 503 minecraft:red_terracotta
setblock 472 241 504 minecraft:terracotta
fill 473 241 464 476 241 464 minecraft:red_terracotta
setblock 473 241 468 minecraft:terracotta
fill 473 241 469 474 243 469 minecraft:red_terracotta
fill 473 241 471 473 242 471 minecraft:red_terracotta
fill 473 241 481 473 241 482 minecraft:red_terracotta
setblock 473 241 483 minecraft:terracotta
fill 473 241 484 473 242 484 minecraft:red_terracotta
fill 473 241 486 473 242 486 minecraft:red_terracotta
setblock 473 241 502 minecraft:red_terracotta
setblock 473 241 503 minecraft:terracotta
fill 473 241 504 473 244 504 minecraft:red_terracotta
setblock 474 241 467 minecraft:terracotta
fill 474 241 468 474 244 468 minecraft:red_terracotta
setblock 474 241 481 minecraft:basalt
fill 474 241 483 474 241 484 minecraft:basalt
fill 474 241 486 474 241 487 minecraft:basalt
setblock 474 241 489 minecraft:basalt
setblock 474 241 502 minecraft:terracotta
fill 474 241 503 474 244 503 minecraft:red_terracotta
setblock 475 241 466 minecraft:terracotta
fill 475 241 467 475 244 467 minecraft:red_terracotta
fill 475 241 478 475 241 479 minecraft:basalt
fill 475 241 491 475 241 492 minecraft:basalt
fill 475 241 502 475 243 502 minecraft:red_terracotta
setblock 476 241 465 minecraft:terracotta
fill 476 241 466 476 244 466 minecraft:red_terracotta
setblock 476 241 493 minecraft:magma_block
setblock 477 241 464 minecraft:terracotta
fill 477 241 465 477 244 465 minecraft:red_terracotta
setblock 477 241 476 minecraft:basalt
fill 477 241 493 477 241 495 minecraft:basalt
setblock 477 241 504 minecraft:terracotta
fill 478 241 464 481 241 464 minecraft:red_terracotta
setblock 478 241 474 minecraft:basalt
fill 478 241 486 478 246 486 minecraft:basalt
fill 478 241 495 478 241 496 minecraft:basalt
setblock 478 241 503 minecraft:terracotta
fill 478 241 504 481 241 504 minecraft:red_terracotta
fill 479 241 473 480 241 473 minecraft:basalt
setblock 479 241 474 minecraft:magma_block
fill 479 241 475 479 242 475 minecraft:basalt
setblock 479 241 486 minecraft:magma_block
setblock 479 241 496 minecraft:basalt
setblock 479 241 502 minecraft:terracotta
fill 479 241 503 482 241 503 minecraft:red_terracotta
setblock 480 241 466 minecraft:terracotta
fill 480 241 481 480 247 483 minecraft:basalt
fill 480 241 487 480 247 488 minecraft:basalt
fill 480 241 490 481 247 490 minecraft:basalt
fill 480 241 502 481 241 502 minecraft:red_terracotta
setblock 481 241 465 minecraft:terracotta
fill 481 241 466 481 242 466 minecraft:red_terracotta
fill 481 241 472 482 241 472 minecraft:basalt
fill 481 241 480 481 247 480 minecraft:basalt
fill 481 241 498 482 241 498 minecraft:basalt
setblock 482 241 464 minecraft:terracotta
fill 482 241 465 482 244 465 minecraft:red_terracotta
setblock 482 241 471 minecraft:basalt
setblock 482 241 479 minecraft:magma_block
setblock 482 241 491 minecraft:magma_block
fill 482 241 499 484 241 499 minecraft:basalt
setblock 482 241 504 minecraft:terracotta
fill 483 241 464 486 241 464 minecraft:red_terracotta
fill 483 241 477 483 247 478 minecraft:basalt
fill 483 241 492 483 247 492 minecraft:basalt
setblock 483 241 503 minecraft:terracotta
fill 483 241 504 486 241 504 minecraft:red_terracotta
fill 484 241 477 484 247 477 minecraft:basalt
fill 484 241 493 484 247 493 minecraft:basalt
fill 484 241 503 487 241 503 minecraft:red_terracotta
fill 485 241 470 490 241 470 minecraft:basalt
fill 485 241 500 490 241 500 minecraft:basalt
setblock 486 241 465 minecraft:terracotta
fill 486 241 476 487 241 476 minecraft:basalt
fill 486 241 494 487 241 494 minecraft:basalt
setblock 487 241 464 minecraft:terracotta
fill 487 241 465 490 241 465 minecraft:red_terracotta
fill 487 241 495 487 247 495 minecraft:basalt
setblock 487 241 504 minecraft:terracotta
fill 488 241 464 491 241 464 minecraft:red_terracotta
setblock 488 241 495 minecraft:magma_block
setblock 488 241 503 minecraft:terracotta
fill 488 241 504 491 241 504 minecraft:red_terracotta
fill 489 241 475 489 247 475 minecraft:basalt
fill 489 241 495 492 246 495 minecraft:basalt
fill 489 241 503 492 241 503 minecraft:red_terracotta
fill 490 241 502 493 241 502 minecraft:red_terracotta
setblock 491 241 465 minecraft:terracotta
setblock 491 241 470 minecraft:magma_block
fill 491 241 471 491 242 471 minecraft:basalt
setblock 491 241 476 minecraft:magma_block
setblock 491 241 494 minecraft:magma_block
fill 491 241 499 493 242 499 minecraft:basalt
setblock 491 241 500 minecraft:magma_block
setblock 492 241 464 minecraft:terracotta
fill 492 241 465 492 244 465 minecraft:red_terracotta
fill 492 241 470 493 241 470 minecraft:basalt
fill 492 241 476 492 247 476 minecraft:basalt
fill 492 241 494 492 247 494 minecraft:basalt
fill 492 241 500 493 241 500 minecraft:basalt
setblock 492 241 504 minecraft:terracotta
fill 493 241 464 493 244 464 minecraft:red_terracotta
setblock 493 241 503 minecraft:terracotta
fill 493 241 504 496 241 504 minecraft:red_terracotta
fill 494 241 477 494 247 477 minecraft:basalt
setblock 494 241 493 minecraft:magma_block
setblock 494 241 499 minecraft:magma_block
setblock 494 241 502 minecraft:terracotta
fill 494 241 503 497 241 503 minecraft:red_terracotta
setblock 495 241 466 minecraft:terracotta
fill 495 241 478 495 247 478 minecraft:basalt
fill 495 241 492 495 247 492 minecraft:basalt
fill 495 241 499 496 241 499 minecraft:basalt
fill 495 241 502 495 243 502 minecraft:red_terracotta
setblock 496 241 465 minecraft:terracotta
fill 496 241 479 496 247 479 minecraft:basalt
fill 496 241 491 496 247 491 minecraft:basalt
setblock 497 241 464 minecraft:terracotta
fill 497 241 465 497 244 465 minecraft:red_terracotta
setblock 497 241 480 minecraft:magma_block
fill 497 241 490 498 246 490 minecraft:basalt
fill 497 241 497 499 241 497 minecraft:basalt
setblock 497 241 498 minecraft:magma_block
setblock 497 241 504 minecraft:terracotta
fill 498 241 464 498 244 464 minecraft:red_terracotta
fill 498 241 481 498 247 483 minecraft:basalt
fill 498 241 487 498 247 488 minecraft:basalt
setblock 498 241 503 minecraft:terracotta
fill 498 241 504 498 244 504 minecraft:red_terracotta
fill 499 241 493 502 241 493 minecraft:basalt
fill 499 241 496 500 241 496 minecraft:basalt
fill 499 241 503 499 242 503 minecraft:red_terracotta
fill 500 241 475 501 241 475 minecraft:basalt
fill 500 241 495 501 241 495 minecraft:basalt
setblock 501 241 476 minecraft:basalt
setblock 501 241 494 minecraft:basalt
setblock 502 241 464 minecraft:terracotta
setblock 502 241 504 minecraft:terracotta
fill 503 241 464 506 241 464 minecraft:red_terracotta
setblock 503 241 478 minecraft:magma_block
fill 503 241 479 503 241 480 minecraft:basalt
fill 503 241 487 504 241 489 minecraft:basalt
setblock 503 241 490 minecraft:magma_block
setblock 503 241 504 minecraft:red_terracotta
fill 504 241 481 504 241 486 minecraft:basalt
setblock 507 241 464 minecraft:terracotta
fill 508 241 464 508 244 464 minecraft:red_terracotta
setblock 508 241 504 minecraft:red_terracotta
fill 509 241 465 510 241 465 minecraft:red_terracotta
setblock 509 241 482 minecraft:terracotta
fill 509 241 483 509 243 483 minecraft:red_terracotta
setblock 509 241 487 minecraft:terracotta
setblock 510 241 466 minecraft:terracotta
fill 510 241 467 511 241 469 minecraft:red_terracotta
fill 510 241 477 510 243 477 minecraft:red_terracotta
setblock 510 241 481 minecraft:terracotta
fill 510 241 482 510 244 482 minecraft:red_terracotta
setblock 510 241 486 minecraft:terracotta
fill 510 241 487 510 244 487 minecraft:red_terracotta
setblock 510 241 490 minecraft:red_terracotta
setblock 511 241 465 minecraft:terracotta
fill 511 241 466 511 244 466 minecraft:red_terracotta
setblock 511 241 470 minecraft:terracotta
fill 511 241 471 511 241 474 minecraft:red_terracotta
setblock 511 241 475 minecraft:terracotta
fill 511 241 476 511 244 476 minecraft:red_terracotta
setblock 511 241 480 minecraft:terracotta
fill 511 241 481 511 244 481 minecraft:red_terracotta
setblock 511 241 485 minecraft:terracotta
fill 511 241 486 511 244 486 minecraft:red_terracotta
setblock 511 241 489 minecraft:red_terracotta
setblock 511 241 490 minecraft:terracotta
fill 511 241 491 511 244 491 minecraft:red_terracotta
setblock 511 241 501 minecraft:red_terracotta
setblock 471 242 464 minecraft:terracotta
fill 471 242 465 473 242 466 minecraft:red_terracotta
setblock 471 242 469 minecraft:terracotta
fill 471 242 470 471 245 470 minecraft:red_terracotta
setblock 471 242 473 minecraft:red_terracotta
setblock 471 242 474 minecraft:terracotta
fill 471 242 475 471 245 475 minecraft:red_terracotta
setblock 471 242 479 minecraft:terracotta
fill 471 242 480 471 242 483 minecraft:red_terracotta
setblock 471 242 484 minecraft:terracotta
fill 471 242 485 471 245 485 minecraft:red_terracotta
setblock 471 242 488 minecraft:red_terracotta
setblock 471 242 489 minecraft:terracotta
fill 471 242 490 472 244 490 minecraft:red_terracotta
fill 471 242 492 471 243 492 minecraft:red_terracotta
fill 471 242 500 471 244 500 minecraft:red_terracotta
fill 471 242 502 471 242 503 minecraft:red_terracotta
setblock 471 242 504 minecraft:terracotta
fill 472 242 464 475 242 464 minecraft:red_terracotta
setblock 472 242 468 minecraft:terracotta
fill 472 242 469 472 245 469 minecraft:red_terracotta
setblock 472 242 473 minecraft:terracotta
fill 472 242 474 472 245 474 minecraft:red_terracotta
setblock 472 242 478 minecraft:terracotta
fill 472 242 479 472 242 482 minecraft:red_terracotta
setblock 472 242 483 minecraft:terracotta
fill 472 242 484 472 245 484 minecraft:red_terracotta
setblock 472 242 488 minecraft:terracotta
fill 472 242 489 472 245 489 minecraft:red_terracotta
setblock 472 242 503 minecraft:terracotta
fill 472 242 504 472 245 504 minecraft:red_terracotta
setblock 473 242 467 minecraft:terracotta
fill 473 242 468 473 245 468 minecraft:red_terracotta
setblock 473 242 472 minecraft:terracotta
setblock 473 242 482 minecraft:terracotta
setblock 473 242 483 minecraft:red_terracotta
setblock 473 242 487 minecraft:terracotta
fill 473 242 503 473 245 503 minecraft:red_terracotta
setblock 474 242 465 minecraft:red_terracotta
setblock 474 242 466 minecraft:terracotta
fill 474 242 467 474 245 467 minecraft:red_terracotta
setblock 474 242 502 minecraft:red_terracotta
setblock 475 242 465 minecraft:terracotta
fill 475 242 466 475 245 466 minecraft:red_terracotta
setblock 475 242 483 minecraft:magma_block
fill 475 242 484 475 242 485 minecraft:basalt
setblock 475 242 486 minecraft:magma_block
setblock 475 242 489 minecraft:magma_block
setblock 476 242 464 minecraft:terracotta
fill 476 242 465 476 245 465 minecraft:red_terracotta
fill 476 242 480 476 243 480 minecraft:basalt
setblock 476 242 504 minecraft:terracotta
fill 477 242 464 480 242 464 minecraft:red_terracotta
setblock 477 242 467 minecraft:red_terracotta
fill 477 242 493 478 242 493 minecraft:basalt
setblock 477 242 503 minecraft:terracotta
fill 477 242 504 480 242 504 minecraft:red_terracotta
setblock 478 242 467 minecraft:terracotta
setblock 478 242 476 minecraft:magma_block
fill 478 242 477 478 243 477 minecraft:basalt
setblock 478 242 494 minecraft:magma_block
setblock 478 242 502 minecraft:terracotta
fill 478 242 503 481 242 503 minecraft:red_terracotta
setblock 479 242 466 minecraft:terracotta
fill 479 242 486 480 247 486 minecraft:basalt
setblock 479 242 502 minecraft:red_terracotta
setblock 480 242 465 minecraft:terracotta
fill 480 242 466 480 243 466 minecraft:red_terracotta
fill 480 242 484 480 247 485 minecraft:basalt
setblock 481 242 464 minecraft:terracotta
fill 481 242 465 481 245 465 minecraft:red_terracotta
setblock 481 242 481 minecraft:magma_block
fill 481 242 482 481 247 482 minecraft:basalt
fill 481 242 488 481 247 489 minecraft:basalt
setblock 481 242 504 minecraft:terracotta
fill 482 242 464 485 242 464 minecraft:red_terracotta
setblock 482 242 472 minecraft:basalt
fill 482 242 479 482 246 480 minecraft:basalt
fill 482 242 490 482 247 491 minecraft:basalt
setblock 482 242 498 minecraft:basalt
setblock 482 242 503 minecraft:terracotta
fill 482 242 504 485 242 504 minecraft:red_terracotta
setblock 483 242 479 minecraft:basalt
setblock 483 242 491 minecraft:basalt
fill 483 242 503 486 242 503 minecraft:red_terracotta
fill 484 242 472 484 243 472 minecraft:basalt
fill 484 242 478 484 247 478 minecraft:basalt
setblock 484 242 492 minecraft:magma_block
setblock 484 242 498 minecraft:magma_block
setblock 485 242 465 minecraft:terracotta
fill 485 242 477 486 247 477 minecraft:basalt
fill 485 242 493 486 242 493 minecraft:basalt
setblock 486 242 464 minecraft:terracotta
fill 486 242 465 489 242 465 minecraft:red_terracotta
fill 486 242 476 486 247 476 minecraft:basalt
fill 486 242 494 486 247 494 minecraft:basalt
setblock 486 242 504 minecraft:terracotta
fill 487 242 464 490 242 464 minecraft:red_terracotta
setblock 487 242 476 minecraft:magma_block
setblock 487 242 494 minecraft:magma_block
fill 487 242 499 489 242 499 minecraft:basalt
setblock 487 242 503 minecraft:terracotta
fill 487 242 504 490 242 504 minecraft:red_terracotta
fill 488 242 476 491 247 476 minecraft:basalt
fill 488 242 494 488 247 495 minecraft:basalt
fill 488 242 503 491 242 503 minecraft:red_terracotta
fill 489 242 494 491 247 494 minecraft:basalt
setblock 490 242 465 minecraft:terracotta
setblock 490 242 499 minecraft:magma_block
fill 490 242 502 492 242 502 minecraft:red_terracotta
setblock 491 242 464 minecraft:terracotta
fill 491 242 465 491 245 465 minecraft:red_terracotta
setblock 491 242 504 minecraft:terracotta
fill 492 242 464 492 245 464 minecraft:red_terracotta
fill 492 242 477 492 247 477 minecraft:basalt
fill 492 242 493 494 247 493 minecraft:basalt
setblock 492 242 503 minecraft:terracotta
fill 492 242 504 495 242 504 minecraft:red_terracotta
setblock 493 242 471 minecraft:magma_block
fill 493 242 472 493 243 472 minecraft:basalt
setblock 493 242 477 minecraft:magma_block
setblock 493 242 502 minecraft:terracotta
fill 493 242 503 496 242 503 minecraft:red_terracotta
setblock 494 242 466 minecraft:terracotta
fill 494 242 478 494 247 478 minecraft:basalt
fill 494 242 492 494 247 492 minecraft:basalt
fill 494 242 502 494 243 502 minecraft:red_terracotta
setblock 495 242 465 minecraft:terracotta
setblock 495 242 466 minecraft:red_terracotta
fill 495 242 479 495 247 479 minecraft:basalt
fill 495 242 491 495 247 491 minecraft:basalt
setblock 496 242 464 minecraft:terracotta
fill 496 242 465 496 245 465 minecraft:red_terracotta
setblock 496 242 472 minecraft:basalt
fill 496 242 480 497 247 480 minecraft:basalt
fill 496 242 490 496 247 490 minecraft:basalt
setblock 496 242 504 minecraft:terracotta
fill 497 242 464 497 245 464 minecraft:red_terracotta
fill 497 242 481 497 246 482 minecraft:basalt
fill 497 242 488 497 247 489 minecraft:basalt
setblock 497 242 497 minecraft:basalt
setblock 497 242 503 minecraft:terracotta
fill 497 242 504 497 245 504 minecraft:red_terracotta
fill 498 242 475 498 243 475 minecraft:basalt
fill 498 242 484 498 247 486 minecraft:basalt
fill 498 242 503 498 243 503 minecraft:red_terracotta
setblock 499 242 465 minecraft:red_terracotta
setblock 499 242 475 minecraft:magma_block
fill 499 242 493 501 242 493 minecraft:basalt
setblock 500 242 465 minecraft:terracotta
setblock 501 242 464 minecraft:terracotta
fill 501 242 492 501 243 492 minecraft:basalt
setblock 501 242 504 minecraft:terracotta
fill 502 242 464 505 242 464 minecraft:red_terracotta
setblock 502 242 478 minecraft:basalt
setblock 502 242 480 minecraft:magma_block
fill 502 242 481 502 243 481 minecraft:basalt
setblock 502 242 492 minecraft:magma_block
setblock 502 242 504 minecraft:red_terracotta
fill 503 242 487 503 242 489 minecraft:basalt
setblock 506 242 464 minecraft:terracotta
fill 507 242 464 507 245 464 minecraft:red_terracotta
fill 508 242 465 509 242 465 minecraft:red_terracotta
setblock 509 242 482 minecraft:red_terracotta
setblock 509 242 486 minecraft:terracotta
fill 509 242 487 509 244 487 minecraft:red_terracotta
setblock 510 242 464 minecraft:red_terracotta
setblock 510 242 465 minecraft:terracotta
fill 510 242 466 510 242 469 minecraft:red_terracotta
setblock 510 242 470 minecraft:terracotta
fill 510 242 471 511 243 472 minecraft:red_terracotta
setblock 510 242 480 minecraft:terracotta
fill 510 242 481 510 245 481 minecraft:red_terracotta
setblock 510 242 485 minecraft:terracotta
fill 510 242 486 510 245 486 minecraft:red_terracotta
setblock 510 242 490 minecraft:terracotta
setblock 511 242 464 minecraft:terracotta
fill 511 242 465 511 245 465 minecraft:red_terracotta
fill 511 242 467 511 242 468 minecraft:red_terracotta
setblock 511 242 469 minecraft:terracotta
fill 511 242 470 511 245 470 minecraft:red_terracotta
setblock 511 242 473 minecraft:red_terracotta
setblock 511 242 474 minecraft:terracotta
fill 511 242 475 511 245 475 minecraft:red_terracotta
setblock 511 242 479 minecraft:terracotta
fill 511 242 480 511 245 480 minecraft:red_terracotta
setblock 511 242 484 minecraft:terracotta
fill 511 242 485 511 245 485 minecraft:red_terracotta
setblock 511 242 489 minecraft:terracotta
fill 511 242 490 511 245 490 minecraft:red_terracotta
setblock 511 242 493 minecraft:red_terracotta
setblock 511 242 504 minecraft:terracotta
fill 471 243 464 472 243 466 minecraft:red_terracotta
setblock 471 243 468 minecraft:terracotta
fill 471 243 469 471 246 469 minecraft:red_terracotta
setblock 471 243 473 minecraft:terracotta
fill 471 243 474 471 246 474 minecraft:red_terracotta
setblock 471 243 478 minecraft:terracotta
fill 471 243 479 471 243 482 minecraft:red_terracotta
setblock 471 243 483 minecraft:terracotta
fill 471 243 484 471 246 484 minecraft:red_terracotta
setblock 471 243 487 minecraft:red_terracotta
setblock 471 243 488 minecraft:terracotta
fill 471 243 489 471 246 489 minecraft:red_terracotta
setblock 471 243 493 minecraft:terracotta
setblock 471 243 502 minecraft:red_terracotta
setblock 471 243 503 minecraft:terracotta
fill 471 243 504 471 246 504 minecraft:red_terracotta
setblock 472 243 467 minecraft:terracotta
fill 472 243 468 472 246 468 minecraft:red_terracotta
setblock 472 243 472 minecraft:terracotta
fill 472 243 473 472 246 473 minecraft:red_terracotta
fill 472 243 478 472 243 481 minecraft:red_terracotta
setblock 472 243 482 minecraft:terracotta
fill 472 243 483 472 244 483 minecraft:red_terracotta
setblock 472 243 487 minecraft:terracotta
fill 472 243 488 472 246 488 minecraft:red_terracotta
setblock 472 243 502 minecraft:terracotta
fill 472 243 503 472 246 503 minecraft:red_terracotta
fill 473 243 464 473 243 465 minecraft:red_terracotta
setblock 473 243 466 minecraft:terracotta
fill 473 243 467 473 246 467 minecraft:red_terracotta
setblock 473 243 471 minecraft:terracotta
fill 473 243 472 473 244 472 minecraft:red_terracotta
setblock 473 243 486 minecraft:terracotta
setblock 474 243 464 minecraft:red_terracotta
setblock 474 243 465 minecraft:terracotta
fill 474 243 466 474 246 466 minecraft:red_terracotta
setblock 475 243 464 minecraft:terracotta
fill 475 243 465 475 246 465 minecraft:red_terracotta
setblock 475 243 504 minecraft:terracotta
fill 476 243 464 479 243 464 minecraft:red_terracotta
setblock 476 243 503 minecraft:terracotta
fill 476 243 504 479 243 504 minecraft:red_terracotta
setblock 477 243 467 minecraft:terracotta
setblock 477 243 478 minecraft:magma_block
fill 477 243 479 477 243 480 minecraft:basalt
fill 477 243 503 480 243 503 minecraft:red_terracotta
setblock 478 243 466 minecraft:terracotta
setblock 478 243 493 minecraft:basalt
setblock 479 243 465 minecraft:terracotta
fill 479 243 466 479 244 466 minecraft:red_terracotta
setblock 480 243 464 minecraft:terracotta
fill 480 243 465 480 245 465 minecraft:red_terracotta
setblock 480 243 495 minecraft:magma_block
setblock 480 243 504 minecraft:terracotta
fill 481 243 464 484 243 464 minecraft:red_terracotta
fill 481 243 481 482 247 481 minecraft:basalt
fill 481 243 483 481 247 487 minecraft:basalt
setblock 481 243 503 minecraft:terracotta
fill 481 243 504 484 243 504 minecraft:red_terracotta
fill 482 243 489 482 246 489 minecraft:basalt
fill 482 243 503 483 243 503 minecraft:red_terracotta
setblock 483 243 473 minecraft:magma_block
fill 483 243 474 483 244 474 minecraft:basalt
setblock 483 243 479 minecraft:magma_block
setblock 483 243 491 minecraft:magma_block
fill 483 243 496 483 244 496 minecraft:basalt
setblock 483 243 497 minecraft:magma_block
setblock 484 243 465 minecraft:terracotta
fill 484 243 492 485 247 492 minecraft:basalt
setblock 484 243 498 minecraft:basalt
setblock 485 243 464 minecraft:terracotta
fill 485 243 465 488 243 465 minecraft:red_terracotta
fill 485 243 478 485 247 478 minecraft:basalt
fill 485 243 493 485 247 493 minecraft:basalt
setblock 485 243 503 minecraft:red_terracotta
setblock 485 243 504 minecraft:terracotta
fill 486 243 464 489 243 464 minecraft:red_terracotta
setblock 486 243 472 minecraft:magma_block
setblock 486 243 493 minecraft:magma_block
fill 486 243 498 488 243 498 minecraft:basalt
setblock 486 243 503 minecraft:terracotta
fill 486 243 504 489 243 504 minecraft:red_terracotta
fill 487 243 476 487 247 477 minecraft:basalt
fill 487 243 493 487 247 494 minecraft:basalt
fill 487 243 503 490 243 503 minecraft:red_terracotta
fill 488 243 477 488 247 477 minecraft:basalt
fill 488 243 493 491 246 493 minecraft:basalt
setblock 489 243 465 minecraft:terracotta
setblock 489 243 477 minecraft:magma_block
setblock 489 243 498 minecraft:magma_block
setblock 490 243 464 minecraft:terracotta
fill 490 243 465 490 246 465 minecraft:red_terracotta
fill 490 243 477 491 246 477 minecraft:basalt
setblock 490 243 504 minecraft:terracotta
fill 491 243 464 491 246 464 minecraft:red_terracotta
setblock 491 243 503 minecraft:terracotta
fill 491 243 504 494 243 504 minecraft:red_terracotta
setblock 492 243 502 minecraft:terracotta
fill 492 243 503 495 243 503 minecraft:red_terracotta
fill 493 243 477 493 247 478 minecraft:basalt
fill 493 243 492 493 247 492 minecraft:basalt
setblock 493 243 502 minecraft:red_terracotta
setblock 494 243 465 minecraft:terracotta
setblock 495 243 464 minecraft:terracotta
fill 495 243 465 495 245 465 minecraft:red_terracotta
setblock 495 243 504 minecraft:terracotta
fill 496 243 464 496 246 464 minecraft:red_terracotta
fill 496 243 481 496 247 481 minecraft:basalt
fill 496 243 489 496 247 489 minecraft:basalt
setblock 496 243 503 minecraft:terracotta
fill 496 243 504 496 246 504 minecraft:red_terracotta
fill 497 243 483 497 243 487 minecraft:basalt
setblock 497 243 503 minecraft:red_terracotta
setblock 498 243 495 minecraft:magma_block
setblock 499 243 465 minecraft:terracotta
fill 499 243 493 500 243 493 minecraft:basalt
setblock 500 243 464 minecraft:terracotta
setblock 500 243 504 minecraft:terracotta
fill 501 243 464 503 243 464 minecraft:red_terracotta
setblock 501 243 479 minecraft:magma_block
fill 501 243 480 502 243 480 minecraft:basalt
fill 501 243 490 501 244 490 minecraft:basalt
setblock 501 243 491 minecraft:magma_block
setblock 501 243 504 minecraft:red_terracotta
setblock 505 243 464 minecraft:terracotta
fill 506 243 464 506 244 464 minecraft:red_terracotta
setblock 508 243 465 minecraft:red_terracotta
setblock 509 243 465 minecraft:terracotta
setblock 509 243 485 minecraft:terracotta
fill 509 243 486 509 244 486 minecraft:red_terracotta
setblock 510 243 464 minecraft:terracotta
fill 510 243 465 510 243 468 minecraft:red_terracotta
setblock 510 243 469 minecraft:terracotta
fill 510 243 470 510 246 470 minecraft:red_terracotta
setblock 510 243 473 minecraft:red_terracotta
setblock 510 243 479 minecraft:terracotta
fill 510 243 480 510 245 480 minecraft:red_terracotta
setblock 510 243 484 minecraft:terracotta
fill 510 243 485 510 246 485 minecraft:red_terracotta
setblock 510 243 488 minecraft:red_terracotta
setblock 510 243 489 minecraft:terracotta
fill 510 243 490 510 246 490 minecraft:red_terracotta
setblock 510 243 504 minecraft:terracotta
fill 511 243 464 511 246 464 minecraft:red_terracotta
setblock 511 243 467 minecraft:red_terracotta
setblock 511 243 468 minecraft:terracotta
fill 511 243 469 511 246 469 minecraft:red_terracotta
setblock 511 243 473 minecraft:terracotta
fill 511 243 474 511 246 474 minecraft:red_terracotta
setblock 511 243 478 minecraft:terracotta
fill 511 243 479 511 246 479 minecraft:red_terracotta
setblock 511 243 483 minecraft:terracotta
fill 511 243 484 511 246 484 minecraft:red_terracotta
setblock 511 243 488 minecraft:terracotta
fill 511 243 489 511 246 489 minecraft:red_terracotta
setblock 511 243 493 minecraft:terracotta
setblock 511 243 503 minecraft:terracotta
fill 511 243 504 511 246 504 minecraft:red_terracotta
fill 471 244 464 471 244 466 minecraft:red_terracotta
setblock 471 244 467 minecraft:terracotta
fill 471 244 468 471 247 468 minecraft:red_terracotta
setblock 471 244 472 minecraft:terracotta
fill 471 244 473 471 247 473 minecraft:red_terracotta
setblock 471 244 477 minecraft:terracotta
fill 471 244 478 471 244 481 minecraft:red_terracotta
setblock 471 244 482 minecraft:terracotta
fill 471 244 483 471 247 483 minecraft:red_terracotta
setblock 471 244 487 minecraft:terracotta
fill 471 244 488 471 247 488 minecraft:red_terracotta
setblock 471 244 492 minecraft:terracotta
fill 471 244 493 471 247 493 minecraft:red_terracotta
setblock 471 244 502 minecraft:terracotta
fill 471 244 503 471 247 503 minecraft:red_terracotta
fill 472 244 464 472 244 465 minecraft:red_terracotta
setblock 472 244 466 minecraft:terracotta
fill 472 244 467 472 247 467 minecraft:red_terracotta
setblock 472 244 471 minecraft:terracotta
fill 472 244 472 472 247 472 minecraft:red_terracotta
setblock 472 244 482 minecraft:red_terracotta
setblock 472 244 485 minecraft:red_terracotta
setblock 472 244 486 minecraft:terracotta
fill 472 244 487 472 246 487 minecraft:red_terracotta
setblock 472 244 502 minecraft:red_terracotta
setblock 473 244 464 minecraft:red_terracotta
setblock 473 244 465 minecraft:terracotta
fill 473 244 466 473 247 466 minecraft:red_terracotta
setblock 473 244 469 minecraft:red_terracotta
setblock 473 244 470 minecraft:terracotta
fill 473 244 471 473 247 471 minecraft:red_terracotta
setblock 474 244 464 minecraft:terracotta
fill 474 244 465 474 247 465 minecraft:red_terracotta
setblock 474 244 469 minecraft:terracotta
setblock 474 244 504 minecraft:terracotta
fill 475 244 464 478 244 464 minecraft:red_terracotta
setblock 475 244 503 minecraft:terracotta
fill 475 244 504 478 244 504 minecraft:red_terracotta
setblock 476 244 467 minecraft:terracotta
setblock 476 244 486 minecraft:magma_block
fill 476 244 503 479 244 503 minecraft:red_terracotta
setblock 477 244 466 minecraft:terracotta
setblock 477 244 467 minecraft:red_terracotta
setblock 477 244 480 minecraft:basalt
fill 477 244 489 477 244 490 minecraft:basalt
setblock 478 244 465 minecraft:terracotta
fill 478 244 466 478 245 466 minecraft:red_terracotta
setblock 479 244 464 minecraft:terracotta
fill 479 244 465 479 246 465 minecraft:red_terracotta
fill 479 244 477 479 244 478 minecraft:basalt
fill 479 244 492 479 244 493 minecraft:basalt
setblock 479 244 504 minecraft:terracotta
fill 480 244 464 483 244 464 minecraft:red_terracotta
setblock 480 244 503 minecraft:terracotta
fill 480 244 504 483 244 504 minecraft:red_terracotta
setblock 481 244 475 minecraft:basalt
setblock 482 244 475 minecraft:magma_block
fill 482 244 482 482 246 483 minecraft:basalt
setblock 482 244 487 minecraft:magma_block
fill 482 244 488 482 247 488 minecraft:basalt
setblock 482 244 495 minecraft:basalt
setblock 482 244 496 minecraft:magma_block
fill 483 244 479 483 247 481 minecraft:basalt
fill 483 244 489 483 247 491 minecraft:basalt
setblock 484 244 464 minecraft:terracotta
fill 484 244 479 485 246 479 minecraft:basalt
fill 484 244 491 485 246 491 minecraft:basalt
setblock 484 244 504 minecraft:terracotta
fill 485 244 464 488 244 464 minecraft:red_terracotta
setblock 485 244 497 minecraft:basalt
fill 485 244 504 488 244 504 minecraft:red_terracotta
fill 486 244 478 487 244 478 minecraft:basalt
fill 486 244 492 486 247 493 minecraft:basalt
fill 487 244 473 487 245 473 minecraft:basalt
fill 487 244 492 487 247 492 minecraft:basalt
setblock 488 244 465 minecraft:terracotta
fill 488 244 472 490 244 472 minecraft:basalt
fill 488 244 498 489 244 498 minecraft:basalt
fill 488 244 503 489 244 503 minecraft:red_terracotta
setblock 489 244 464 minecraft:terracotta
fill 489 244 465 489 245 465 minecraft:red_terracotta
fill 489 244 477 489 247 477 minecraft:basalt
setblock 489 244 504 minecraft:terracotta
fill 490 244 464 490 247 464 minecraft:red_terracotta
setblock 490 244 503 minecraft:terracotta
fill 490 244 504 493 244 504 minecraft:red_terracotta
setblock 491 244 478 minecraft:magma_block
fill 491 244 492 492 246 492 minecraft:basalt
fill 491 244 503 494 244 503 minecraft:red_terracotta
fill 492 244 478 492 247 478 minecraft:basalt
setblock 493 244 465 minecraft:terracotta
fill 493 244 479 494 244 479 minecraft:basalt
fill 493 244 491 494 244 491 minecraft:basalt
setblock 494 244 464 minecraft:terracotta
fill 494 244 465 494 246 465 minecraft:red_terracotta
setblock 494 244 473 minecraft:basalt
setblock 494 244 497 minecraft:basalt
setblock 494 244 504 minecraft:terracotta
fill 495 244 464 495 247 464 minecraft:red_terracotta
fill 495 244 480 495 247 481 minecraft:basalt
fill 495 244 489 495 247 490 minecraft:basalt
setblock 495 244 503 minecraft:terracotta
fill 495 244 504 495 247 504 minecraft:red_terracotta
fill 496 244 482 496 247 483 minecraft:basalt
fill 496 244 487 496 244 488 minecraft:basalt
setblock 496 244 503 minecraft:red_terracotta
fill 497 244 483 497 246 484 minecraft:basalt
setblock 497 244 485 minecraft:magma_block
fill 497 244 486 497 246 487 minecraft:basalt
setblock 499 244 464 minecraft:terracotta
setblock 499 244 478 minecraft:basalt
setblock 499 244 493 minecraft:basalt
setblock 499 244 504 minecraft:terracotta
setblock 500 244 464 minecraft:red_terracotta
setblock 500 244 478 minecraft:magma_block
setblock 501 244 480 minecraft:basalt
setblock 502 244 484 minecraft:basalt
setblock 502 244 486 minecraft:basalt
setblock 508 244 465 minecraft:terracotta
setblock 509 244 464 minecraft:terracotta
fill 509 244 465 510 246 465 minecraft:red_terracotta
setblock 509 244 484 minecraft:terracotta
setblock 509 244 485 minecraft:red_terracotta
fill 510 244 464 510 247 464 minecraft:red_terracotta
fill 510 244 466 510 244 467 minecraft:red_terracotta
setblock 510 244 468 minecraft:terracotta
fill 510 244 469 510 247 469 minecraft:red_terracotta
fill 510 244 471 510 244 472 minecraft:red_terracotta
setblock 510 244 473 minecraft:terracotta
fill 510 244 474 510 247 474 minecraft:red_terracotta
setblock 510 244 478 minecraft:terracotta
setblock 510 244 479 minecraft:red_terracotta
setblock 510 244 483 minecraft:terracotta
fill 510 244 484 510 247 484 minecraft:red_terracotta
setblock 510 244 488 minecraft:terracotta
fill 510 244 489 510 247 489 minecraft:red_terracotta
fill 510 244 491 510 245 491 minecraft:red_terracotta
setblock 510 244 504 minecraft:red_terracotta
setblock 511 244 467 minecraft:terracotta
fill 511 244 468 511 247 468 minecraft:red_terracotta
setblock 511 244 471 minecraft:red_terracotta
setblock 511 244 472 minecraft:terracotta
fill 511 244 473 511 247 473 minecraft:red_terracotta
setblock 511 244 477 minecraft:terracotta
fill 511 244 478 511 247 478 minecraft:red_terracotta
setblock 511 244 482 minecraft:terracotta
fill 511 244 483 511 247 483 minecraft:red_terracotta
setblock 511 244 487 minecraft:terracotta
fill 511 244 488 511 247 488 minecraft:red_terracotta
setblock 511 244 492 minecraft:terracotta
fill 511 244 493 511 247 493 minecraft:red_terracotta
setblock 511 244 503 minecraft:red_terracotta
fill 471 245 464 471 245 465 minecraft:red_terracotta
setblock 471 245 466 minecraft:terracotta
fill 471 245 467 471 248 467 minecraft:red_terracotta
setblock 471 245 471 minecraft:terracotta
fill 471 245 472 471 248 472 minecraft:red_terracotta
setblock 471 245 476 minecraft:terracotta
fill 471 245 477 471 245 480 minecraft:red_terracotta
setblock 471 245 481 minecraft:terracotta
fill 471 245 482 471 246 482 minecraft:red_terracotta
setblock 471 245 486 minecraft:terracotta
fill 471 245 487 471 248 487 minecraft:red_terracotta
setblock 471 245 490 minecraft:red_terracotta
setblock 471 245 491 minecraft:terracotta
fill 471 245 492 471 248 492 minecraft:red_terracotta
fill 471 245 494 471 246 494 minecraft:red_terracotta
setblock 471 245 501 minecraft:terracotta
fill 471 245 502 471 248 502 minecraft:red_terracotta
setblock 472 245 464 minecraft:red_terracotta
setblock 472 245 465 minecraft:terracotta
fill 472 245 466 472 248 466 minecraft:red_terracotta
setblock 472 245 470 minecraft:terracotta
fill 472 245 471 472 248 471 minecraft:red_terracotta
setblock 472 245 485 minecraft:terracotta
fill 472 245 486 472 246 486 minecraft:red_terracotta
setblock 472 245 490 minecraft:terracotta
fill 472 245 491 472 248 491 minecraft:red_terracotta
setblock 473 245 464 minecraft:terracotta
fill 473 245 465 473 248 465 minecraft:red_terracotta
setblock 473 245 469 minecraft:terracotta
fill 473 245 470 473 248 470 minecraft:red_terracotta
setblock 473 245 474 minecraft:light[level=14]
setblock 473 245 482 minecraft:light[level=14]
setblock 473 245 490 minecraft:light[level=14]
setblock 473 245 498 minecraft:light[level=14]
setblock 473 245 504 minecraft:terracotta
fill 474 245 464 477 245 464 minecraft:red_terracotta
setblock 474 245 468 minecraft:terracotta
setblock 474 245 469 minecraft:red_terracotta
setblock 474 245 503 minecraft:terracotta
fill 474 245 504 477 245 504 minecraft:red_terracotta
setblock 475 245 467 minecraft:terracotta
fill 475 245 503 478 245 503 minecraft:red_terracotta
setblock 476 245 466 minecraft:terracotta
setblock 476 245 467 minecraft:red_terracotta
setblock 477 245 465 minecraft:terracotta
fill 477 245 466 477 246 466 minecraft:red_terracotta
setblock 478 245 464 minecraft:terracotta
fill 478 245 465 478 247 465 minecraft:red_terracotta
setblock 478 245 480 minecraft:basalt
setblock 478 245 481 minecraft:magma_block
setblock 478 245 489 minecraft:basalt
setblock 478 245 490 minecraft:magma_block
setblock 478 245 504 minecraft:terracotta
fill 479 245 464 482 245 464 minecraft:red_terracotta
fill 479 245 504 482 245 504 minecraft:red_terracotta
setblock 481 245 466 minecraft:light[level=14]
setblock 481 245 474 minecraft:light[level=14]
setblock 481 245 477 minecraft:magma_block
setblock 481 245 494 minecraft:basalt
setblock 481 245 498 minecraft:light[level=14]
fill 482 245 484 482 246 487 minecraft:basalt
setblock 483 245 464 minecraft:terracotta
fill 483 245 482 483 247 482 minecraft:basalt
fill 483 245 488 483 247 488 minecraft:basalt
setblock 483 245 504 minecraft:terracotta
fill 484 245 464 487 245 464 minecraft:red_terracotta
setblock 484 245 474 minecraft:basalt
fill 484 245 480 484 247 480 minecraft:basalt
fill 484 245 490 484 247 490 minecraft:basalt
setblock 484 245 496 minecraft:basalt
fill 484 245 504 487 245 504 minecraft:red_terracotta
fill 485 245 497 486 273 497 minecraft:terracotta
fill 486 245 478 486 247 479 minecraft:basalt
fill 486 245 491 486 247 491 minecraft:basalt
setblock 487 245 478 minecraft:magma_block
setblock 488 245 464 minecraft:terracotta
fill 488 245 478 491 246 478 minecraft:basalt
fill 488 245 492 489 247 492 minecraft:basalt
setblock 488 245 504 minecraft:terracotta
fill 489 245 464 489 248 464 minecraft:red_terracotta
setblock 489 245 466 minecraft:light[level=14]
setblock 489 245 482 minecraft:light[level=14]
setblock 489 245 490 minecraft:light[level=14]
setblock 489 245 498 minecraft:light[level=14]
setblock 489 245 503 minecraft:terracotta
fill 489 245 504 492 245 504 minecraft:red_terracotta
setblock 490 245 492 minecraft:magma_block
setblock 490 245 497 minecraft:basalt
fill 490 245 503 493 245 503 minecraft:red_terracotta
setblock 492 245 465 minecraft:terracotta
fill 492 245 479 492 247 479 minecraft:basalt
fill 492 245 491 492 247 491 minecraft:basalt
setblock 493 245 464 minecraft:terracotta
fill 493 245 465 493 246 465 minecraft:red_terracotta
setblock 493 245 474 minecraft:basalt
setblock 493 245 479 minecraft:magma_block
setblock 493 245 491 minecraft:magma_block
setblock 493 245 496 minecraft:basalt
setblock 493 245 504 minecraft:terracotta
fill 494 245 464 494 248 464 minecraft:red_terracotta
fill 494 245 479 494 246 480 minecraft:basalt
fill 494 245 490 494 246 491 minecraft:basalt
setblock 494 245 503 minecraft:terracotta
fill 494 245 504 494 247 504 minecraft:red_terracotta
setblock 495 245 475 minecraft:basalt
fill 495 245 482 495 247 482 minecraft:basalt
fill 495 245 488 496 247 488 minecraft:basalt
setblock 495 245 503 minecraft:red_terracotta
setblock 496 245 484 minecraft:magma_block
fill 496 245 485 496 247 486 minecraft:basalt
setblock 496 245 487 minecraft:magma_block
setblock 497 245 466 minecraft:light[level=14]
setblock 497 245 474 minecraft:light[level=14]
fill 497 245 485 497 247 485 minecraft:basalt
setblock 497 245 498 minecraft:light[level=14]
setblock 498 245 464 minecraft:terracotta
setblock 498 245 477 minecraft:basalt
setblock 499 245 464 minecraft:red_terracotta
setblock 499 245 491 minecraft:basalt
setblock 505 245 466 minecraft:light[level=14]
setblock 505 245 474 minecraft:light[level=14]
setblock 505 245 482 minecraft:light[level=14]
setblock 505 245 490 minecraft:light[level=14]
setblock 505 245 498 minecraft:light[level=14]
setblock 508 245 464 minecraft:terracotta
fill 508 245 465 508 248 465 minecraft:red_terracotta
fill 509 245 464 509 248 464 minecraft:red_terracotta
setblock 510 245 466 minecraft:red_terracotta
setblock 510 245 467 minecraft:terracotta
fill 510 245 468 510 248 468 minecraft:red_terracotta
setblock 510 245 471 minecraft:red_terracotta
setblock 510 245 472 minecraft:terracotta
fill 510 245 473 510 248 473 minecraft:red_terracotta
fill 510 245 475 510 246 475 minecraft:red_terracotta
setblock 510 245 482 minecraft:terracotta
fill 510 245 483 510 247 483 minecraft:red_terracotta
setblock 510 245 487 minecraft:terracotta
fill 510 245 488 510 248 488 minecraft:red_terracotta
setblock 511 245 466 minecraft:terracotta
fill 511 245 467 511 248 467 minecraft:red_terracotta
setblock 511 245 471 minecraft:terracotta
fill 511 245 472 511 248 472 minecraft:red_terracotta
setblock 511 245 476 minecraft:terracotta
fill 511 245 477 511 248 477 minecraft:red_terracotta
setblock 511 245 481 minecraft:terracotta
fill 511 245 482 511 248 482 minecraft:red_terracotta
setblock 511 245 486 minecraft:terracotta
fill 511 245 487 511 248 487 minecraft:red_terracotta
setblock 511 245 491 minecraft:terracotta
fill 511 245 492 511 248 492 minecraft:red_terracotta
fill 511 245 494 511 246 494 minecraft:red_terracotta
setblock 471 246 464 minecraft:red_terracotta
setblock 471 246 465 minecraft:terracotta
fill 471 246 466 471 249 466 minecraft:red_terracotta
setblock 471 246 470 minecraft:terracotta
fill 471 246 471 471 249 471 minecraft:red_terracotta
setblock 471 246 475 minecraft:terracotta
fill 471 246 476 471 246 479 minecraft:red_terracotta
setblock 471 246 480 minecraft:terracotta
setblock 471 246 481 minecraft:red_terracotta
setblock 471 246 485 minecraft:terracotta
fill 471 246 486 471 249 486 minecraft:red_terracotta
setblock 471 246 490 minecraft:terracotta
fill 471 246 491 471 249 491 minecraft:red_terracotta
fill 471 246 501 471 249 501 minecraft:red_terracotta
setblock 472 246 464 minecraft:terracotta
fill 472 246 465 472 249 465 minecraft:red_terracotta
setblock 472 246 469 minecraft:terracotta
fill 472 246 470 472 249 470 minecraft:red_terracotta
setblock 472 246 474 minecraft:terracotta
setblock 472 246 489 minecraft:terracotta
fill 472 246 490 472 249 490 minecraft:red_terracotta
setblock 472 246 504 minecraft:terracotta
fill 473 246 464 476 246 464 minecraft:red_terracotta
setblock 473 246 468 minecraft:terracotta
fill 473 246 469 473 249 469 minecraft:red_terracotta
setblock 473 246 503 minecraft:terracotta
fill 473 246 504 476 246 504 minecraft:red_terracotta
setblock 474 246 467 minecraft:terracotta
setblock 474 246 468 minecraft:red_terracotta
fill 474 246 503 475 246 503 minecraft:red_terracotta
setblock 475 246 466 minecraft:terracotta
setblock 476 246 465 minecraft:terracotta
fill 476 246 466 476 247 466 minecraft:red_terracotta
setblock 477 246 464 minecraft:terracotta
fill 477 246 465 477 248 465 minecraft:red_terracotta
setblock 477 246 504 minecraft:terracotta
fill 478 246 464 481 246 464 minecraft:red_terracotta
setblock 478 246 487 minecraft:basalt
fill 478 246 504 481 246 504 minecraft:red_terracotta
setblock 480 246 479 minecraft:magma_block
setblock 480 246 491 minecraft:magma_block
setblock 482 246 464 minecraft:terracotta
fill 483 246 464 486 246 464 minecraft:red_terracotta
setblock 483 246 476 minecraft:basalt
fill 483 246 483 483 247 483 minecraft:basalt
fill 483 246 484 483 247 484 minecraft:magma_block
fill 483 246 485 483 246 486 minecraft:basalt
setblock 483 246 487 minecraft:magma_block
fill 483 246 495 483 247 496 minecraft:brown_terracotta
fill 484 246 481 484 247 481 minecraft:basalt
fill 484 246 489 484 247 489 minecraft:basalt
fill 484 246 496 486 273 496 minecraft:terracotta
fill 484 246 497 484 247 497 minecraft:brown_terracotta
fill 485 246 480 485 247 480 minecraft:basalt
fill 485 246 490 485 247 490 minecraft:basalt
setblock 485 246 495 minecraft:basalt
fill 485 246 498 486 247 498 minecraft:brown_terracotta
fill 485 246 504 486 246 504 minecraft:red_terracotta
setblock 486 246 495 minecraft:magma_block
setblock 487 246 464 minecraft:terracotta
fill 487 246 478 487 247 479 minecraft:basalt
fill 487 246 491 488 246 491 minecraft:basalt
setblock 487 246 496 minecraft:basalt
fill 487 246 497 487 247 497 minecraft:brown_terracotta
setblock 487 246 504 minecraft:terracotta
fill 488 246 464 488 249 464 minecraft:red_terracotta
setblock 488 246 479 minecraft:basalt
fill 488 246 504 491 246 504 minecraft:red_terracotta
fill 489 246 479 489 247 479 minecraft:magma_block
fill 489 246 491 489 247 491 minecraft:magma_block
fill 489 246 496 491 246 496 minecraft:basalt
fill 490 246 479 491 246 479 minecraft:basalt
fill 490 246 491 490 246 492 minecraft:basalt
setblock 491 246 465 minecraft:terracotta
fill 491 246 491 491 247 491 minecraft:basalt
fill 491 246 503 492 246 503 minecraft:red_terracotta
setblock 492 246 464 minecraft:terracotta
setblock 492 246 465 minecraft:red_terracotta
setblock 492 246 475 minecraft:magma_block
setblock 492 246 504 minecraft:terracotta
fill 493 246 464 493 249 464 minecraft:red_terracotta
fill 493 246 479 493 247 480 minecraft:basalt
fill 493 246 490 493 247 491 minecraft:basalt
fill 493 246 504 493 248 504 minecraft:red_terracotta
fill 494 246 481 494 247 481 minecraft:basalt
fill 494 246 489 494 247 489 minecraft:basalt
setblock 494 246 495 minecraft:basalt
setblock 495 246 483 minecraft:magma_block
fill 495 246 484 495 246 485 minecraft:basalt
fill 495 246 486 495 247 486 minecraft:magma_block
fill 495 246 487 496 247 487 minecraft:basalt
fill 496 246 484 496 247 484 minecraft:basalt
setblock 496 246 493 minecraft:basalt
setblock 497 246 464 minecraft:terracotta
setblock 498 246 479 minecraft:magma_block
setblock 498 246 491 minecraft:magma_block
fill 499 246 489 499 246 490 minecraft:basalt
setblock 500 246 487 minecraft:basalt
setblock 507 246 464 minecraft:terracotta
fill 508 246 464 508 249 464 minecraft:red_terracotta
setblock 509 246 467 minecraft:terracotta
fill 509 246 468 509 248 469 minecraft:red_terracotta
setblock 510 246 466 minecraft:terracotta
fill 510 246 467 510 249 467 minecraft:red_terracotta
setblock 510 246 471 minecraft:terracotta
fill 510 246 472 510 249 472 minecraft:red_terracotta
setblock 510 246 482 minecraft:red_terracotta
setblock 510 246 486 minecraft:terracotta
fill 510 246 487 510 249 487 minecraft:red_terracotta
setblock 510 246 491 minecraft:terracotta
setblock 511 246 465 minecraft:terracotta
fill 511 246 466 511 249 466 minecraft:red_terracotta
setblock 511 246 470 minecraft:terracotta
fill 511 246 471 511 249 471 minecraft:red_terracotta
setblock 511 246 475 minecraft:terracotta
fill 511 246 476 511 249 476 minecraft:red_terracotta
setblock 511 246 480 minecraft:terracotta
fill 511 246 481 511 249 481 minecraft:red_terracotta
setblock 511 246 485 minecraft:terracotta
fill 511 246 486 511 249 486 minecraft:red_terracotta
setblock 511 246 490 minecraft:terracotta
fill 511 246 491 511 249 491 minecraft:red_terracotta
setblock 471 247 464 minecraft:terracotta
fill 471 247 465 471 250 465 minecraft:red_terracotta
setblock 471 247 469 minecraft:terracotta
fill 471 247 470 471 250 470 minecraft:red_terracotta
setblock 471 247 474 minecraft:terracotta
fill 471 247 475 471 248 477 minecraft:red_terracotta
setblock 471 247 484 minecraft:terracotta
fill 471 247 485 471 249 485 minecraft:red_terracotta
setblock 471 247 489 minecraft:terracotta
fill 471 247 490 471 250 490 minecraft:red_terracotta
setblock 471 247 494 minecraft:terracotta
fill 471 247 495 471 249 496 minecraft:red_terracotta
setblock 471 247 504 minecraft:terracotta
fill 472 247 464 475 247 464 minecraft:red_terracotta
setblock 472 247 468 minecraft:terracotta
fill 472 247 469 472 250 469 minecraft:red_terracotta
setblock 472 247 473 minecraft:terracotta
fill 472 247 474 472 250 474 minecraft:red_terracotta
setblock 472 247 488 minecraft:terracotta
fill 472 247 489 472 250 489 minecraft:red_terracotta
fill 472 247 504 475 247 504 minecraft:red_terracotta
setblock 473 247 467 minecraft:terracotta
fill 473 247 468 473 250 468 minecraft:red_terracotta
setblock 474 247 466 minecraft:terracotta
setblock 475 247 465 minecraft:terracotta
fill 475 247 466 475 248 466 minecraft:red_terracotta
setblock 476 247 464 minecraft:terracotta
fill 476 247 465 476 249 465 minecraft:red_terracotta
setblock 476 247 504 minecraft:terracotta
fill 477 247 464 480 247 464 minecraft:red_terracotta
fill 477 247 485 478 248 486 minecraft:magma_block
fill 477 247 504 479 247 504 minecraft:red_terracotta
setblock 479 247 483 minecraft:basalt
setblock 479 247 484 minecraft:magma_block
setblock 479 247 485 minecraft:basalt
setblock 479 247 487 minecraft:magma_block
setblock 481 247 464 minecraft:terracotta
setblock 482 247 479 minecraft:basalt
setblock 482 247 480 minecraft:magma_block
setblock 482 247 482 minecraft:basalt
setblock 482 247 483 minecraft:magma_block
fill 482 247 484 482 247 485 minecraft:basalt
fill 482 247 486 484 247 486 minecraft:magma_block
fill 482 247 487 483 247 487 minecraft:basalt
setblock 482 247 489 minecraft:magma_block
setblock 482 247 492 minecraft:magma_block
fill 482 247 493 482 247 497 minecraft:brown_terracotta
setblock 483 247 485 minecraft:magma_block
setblock 483 247 494 minecraft:brown_terracotta
fill 483 247 497 483 247 498 minecraft:brown_terracotta
setblock 484 247 476 minecraft:basalt
setblock 484 247 479 minecraft:basalt
fill 484 247 482 484 247 484 minecraft:magma_block
fill 484 247 487 484 247 488 minecraft:magma_block
setblock 484 247 491 minecraft:basalt
setblock 484 247 494 minecraft:basalt
fill 484 247 495 486 273 495 minecraft:terracotta
setblock 484 247 498 minecraft:brown_terracotta
setblock 485 247 476 minecraft:magma_block
setblock 485 247 479 minecraft:magma_block
setblock 485 247 481 minecraft:magma_block
setblock 485 247 489 minecraft:magma_block
setblock 485 247 491 minecraft:magma_block
setblock 485 247 494 minecraft:magma_block
fill 485 247 499 486 247 499 minecraft:brown_terracotta
fill 486 247 480 488 247 480 minecraft:magma_block
fill 486 247 490 488 247 490 minecraft:magma_block
setblock 486 247 504 minecraft:terracotta
fill 487 247 464 487 248 464 minecraft:red_terracotta
setblock 487 247 475 minecraft:basalt
setblock 487 247 491 minecraft:basalt
fill 487 247 496 487 273 496 minecraft:terracotta
fill 487 247 498 488 247 498 minecraft:brown_terracotta
fill 487 247 504 490 247 504 minecraft:red_terracotta
setblock 488 247 475 minecraft:magma_block
fill 488 247 478 488 247 479 minecraft:magma_block
setblock 488 247 491 minecraft:magma_block
setblock 488 247 493 minecraft:magma_block
fill 488 247 496 489 247 497 minecraft:brown_terracotta
fill 489 247 478 491 247 478 minecraft:basalt
fill 489 247 493 491 247 493 minecraft:basalt
fill 489 247 495 490 247 495 minecraft:basalt
setblock 490 247 477 minecraft:basalt
fill 490 247 479 490 247 480 minecraft:magma_block
fill 490 247 490 490 247 491 minecraft:magma_block
setblock 490 247 492 minecraft:basalt
setblock 491 247 464 minecraft:terracotta
setblock 491 247 477 minecraft:magma_block
setblock 491 247 479 minecraft:basalt
fill 491 247 480 492 247 480 minecraft:magma_block
fill 491 247 490 492 247 490 minecraft:magma_block
setblock 491 247 492 minecraft:magma_block
setblock 491 247 495 minecraft:magma_block
setblock 491 247 504 minecraft:terracotta
fill 492 247 464 492 250 464 minecraft:red_terracotta
setblock 492 247 492 minecraft:basalt
fill 492 247 504 492 250 504 minecraft:red_terracotta
setblock 493 247 476 minecraft:basalt
setblock 493 247 481 minecraft:magma_block
setblock 493 247 489 minecraft:magma_block
setblock 493 247 494 minecraft:basalt
setblock 494 247 476 minecraft:magma_block
setblock 494 247 479 minecraft:magma_block
setblock 494 247 480 minecraft:basalt
fill 494 247 482 494 247 484 minecraft:magma_block
fill 494 247 486 494 247 488 minecraft:magma_block
setblock 494 247 490 minecraft:basalt
setblock 494 247 491 minecraft:magma_block
setblock 494 247 494 minecraft:magma_block
setblock 495 247 477 minecraft:basalt
setblock 495 247 483 minecraft:basalt
schedule function dropper:buildpart/118_9 1t
