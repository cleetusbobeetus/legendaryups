setblock 403 182 349 minecraft:light[level=13]
setblock 403 182 357 minecraft:light[level=13]
fill 403 182 363 403 184 363 minecraft:gray_concrete
setblock 404 182 362 minecraft:gray_concrete
fill 405 182 364 405 184 364 minecraft:gray_wool
setblock 406 182 324 minecraft:polished_deepslate
setblock 407 182 322 minecraft:light_blue_stained_glass
setblock 407 182 323 minecraft:polished_deepslate
fill 407 182 324 407 184 324 minecraft:gray_concrete
setblock 407 182 325 minecraft:light[level=12]
setblock 407 182 332 minecraft:light[level=12]
setblock 407 182 339 minecraft:light[level=12]
setblock 407 182 346 minecraft:light[level=12]
setblock 407 182 353 minecraft:light[level=12]
setblock 407 182 360 minecraft:light[level=12]
setblock 407 182 363 minecraft:polished_deepslate
setblock 407 182 364 minecraft:black_concrete
fill 408 182 323 408 184 323 minecraft:gray_concrete
setblock 408 182 362 minecraft:polished_deepslate
fill 408 182 363 408 184 363 minecraft:gray_concrete
fill 409 182 362 409 183 362 minecraft:gray_concrete
setblock 410 182 325 minecraft:polished_deepslate
setblock 411 182 324 minecraft:polished_deepslate
setblock 411 182 325 minecraft:gray_concrete
setblock 411 182 333 minecraft:light[level=13]
setblock 411 182 341 minecraft:light[level=13]
setblock 411 182 349 minecraft:light[level=13]
setblock 411 182 357 minecraft:light[level=13]
setblock 411 182 364 minecraft:black_concrete
setblock 412 182 322 minecraft:black_concrete
setblock 412 182 323 minecraft:polished_deepslate
fill 412 182 324 412 183 324 minecraft:gray_concrete
setblock 412 182 363 minecraft:polished_deepslate
fill 413 182 322 413 184 322 minecraft:gray_wool
fill 413 182 323 413 184 323 minecraft:gray_concrete
fill 413 182 363 413 183 363 minecraft:gray_concrete
setblock 414 182 325 minecraft:light[level=12]
setblock 414 182 332 minecraft:light[level=12]
setblock 414 182 339 minecraft:light[level=12]
setblock 414 182 346 minecraft:polished_deepslate
setblock 414 182 347 minecraft:gray_concrete
setblock 414 182 353 minecraft:light[level=12]
setblock 414 182 360 minecraft:light[level=12]
setblock 415 182 345 minecraft:polished_deepslate
fill 415 182 346 415 183 346 minecraft:gray_concrete
setblock 415 182 350 minecraft:polished_deepslate
fill 415 182 351 415 183 351 minecraft:gray_concrete
fill 415 182 364 415 184 364 minecraft:gray_wool
setblock 416 182 322 minecraft:light_blue_stained_glass
setblock 416 182 328 minecraft:gray_concrete
setblock 416 182 329 minecraft:polished_deepslate
setblock 416 182 344 minecraft:polished_deepslate
fill 416 182 345 416 184 345 minecraft:gray_concrete
setblock 416 182 349 minecraft:polished_deepslate
fill 416 182 350 416 184 350 minecraft:gray_concrete
setblock 417 182 323 minecraft:polished_deepslate
fill 417 182 324 417 183 324 minecraft:gray_concrete
setblock 417 182 328 minecraft:polished_deepslate
fill 417 182 329 417 184 329 minecraft:gray_concrete
fill 417 182 331 417 182 332 minecraft:gray_concrete
setblock 417 182 333 minecraft:polished_deepslate
fill 417 182 334 417 184 334 minecraft:gray_concrete
setblock 417 182 338 minecraft:polished_deepslate
fill 417 182 339 417 183 339 minecraft:gray_concrete
setblock 417 182 343 minecraft:polished_deepslate
fill 417 182 344 417 184 344 minecraft:gray_concrete
setblock 417 182 348 minecraft:polished_deepslate
fill 417 182 349 417 184 349 minecraft:gray_concrete
setblock 417 182 353 minecraft:polished_deepslate
fill 417 182 354 417 183 354 minecraft:gray_concrete
setblock 418 182 324 minecraft:gray_wool
fill 418 182 332 418 184 333 minecraft:gray_wool
setblock 418 182 334 minecraft:black_concrete
fill 418 182 335 418 184 335 minecraft:gray_wool
setblock 418 182 338 minecraft:black_concrete
setblock 418 182 343 minecraft:black_concrete
setblock 418 182 348 minecraft:black_concrete
fill 418 182 353 418 184 353 minecraft:gray_wool
fill 418 182 356 418 185 356 minecraft:gray_wool
setblock 418 182 360 minecraft:black_concrete
fill 418 182 361 418 184 362 minecraft:gray_wool
fill 418 182 363 418 182 364 minecraft:black_concrete
fill 376 183 332 376 184 333 minecraft:gray_wool
setblock 376 183 334 minecraft:black_concrete
fill 376 183 335 376 184 335 minecraft:gray_wool
setblock 376 183 338 minecraft:black_concrete
setblock 376 183 340 minecraft:black_concrete
setblock 376 183 344 minecraft:black_concrete
fill 376 183 345 376 184 345 minecraft:gray_wool
fill 376 183 349 376 184 350 minecraft:gray_wool
fill 376 183 356 376 184 356 minecraft:gray_wool
fill 376 183 362 376 183 363 minecraft:black_concrete
fill 377 183 323 377 183 326 minecraft:gray_concrete
setblock 377 183 327 minecraft:polished_deepslate
fill 377 183 328 377 184 328 minecraft:gray_concrete
setblock 377 183 332 minecraft:polished_deepslate
fill 377 183 333 377 184 333 minecraft:gray_concrete
setblock 377 183 342 minecraft:polished_deepslate
setblock 377 183 343 minecraft:gray_concrete
setblock 377 183 347 minecraft:polished_deepslate
fill 377 183 348 377 184 348 minecraft:gray_concrete
fill 377 183 364 377 185 364 minecraft:gray_wool
setblock 378 183 326 minecraft:polished_deepslate
fill 378 183 327 378 184 327 minecraft:gray_concrete
setblock 378 183 331 minecraft:polished_deepslate
fill 378 183 332 378 184 332 minecraft:gray_concrete
setblock 379 183 327 minecraft:light_blue_stained_glass
setblock 379 183 364 minecraft:black_concrete
fill 380 183 322 381 184 322 minecraft:gray_wool
setblock 380 183 324 minecraft:polished_deepslate
setblock 381 183 323 minecraft:polished_deepslate
fill 381 183 324 381 184 324 minecraft:gray_concrete
fill 381 183 326 382 183 326 minecraft:light_blue_stained_glass
fill 381 183 364 382 184 364 minecraft:gray_wool
fill 382 183 323 382 184 323 minecraft:gray_concrete
fill 383 183 322 383 184 322 minecraft:gray_wool
setblock 384 183 325 minecraft:polished_deepslate
fill 384 183 326 387 183 326 minecraft:gray_concrete
setblock 385 183 324 minecraft:polished_deepslate
fill 385 183 325 385 184 325 minecraft:gray_concrete
fill 386 183 322 386 185 322 minecraft:gray_wool
setblock 386 183 323 minecraft:polished_deepslate
fill 386 183 324 386 184 324 minecraft:gray_concrete
setblock 386 183 363 minecraft:polished_deepslate
fill 387 183 323 387 184 323 minecraft:gray_concrete
setblock 387 183 327 minecraft:polished_deepslate
setblock 387 183 362 minecraft:polished_deepslate
fill 387 183 363 390 183 363 minecraft:gray_concrete
setblock 388 183 326 minecraft:polished_deepslate
setblock 388 183 327 minecraft:gray_concrete
fill 388 183 362 388 184 362 minecraft:gray_concrete
fill 389 183 322 389 184 322 minecraft:gray_wool
setblock 389 183 325 minecraft:polished_deepslate
fill 389 183 326 389 184 326 minecraft:gray_concrete
setblock 390 183 324 minecraft:polished_deepslate
fill 390 183 325 390 184 325 minecraft:gray_concrete
fill 390 183 364 390 184 364 minecraft:gray_wool
fill 391 183 322 391 184 322 minecraft:gray_wool
setblock 391 183 323 minecraft:polished_deepslate
fill 391 183 324 391 184 324 minecraft:gray_concrete
setblock 391 183 363 minecraft:polished_deepslate
fill 392 183 323 392 184 323 minecraft:gray_concrete
setblock 392 183 362 minecraft:polished_deepslate
fill 392 183 363 392 184 363 minecraft:gray_concrete
setblock 393 183 362 minecraft:gray_concrete
fill 393 183 364 393 184 364 minecraft:gray_wool
setblock 394 183 325 minecraft:polished_deepslate
setblock 395 183 324 minecraft:polished_deepslate
fill 395 183 364 395 184 364 minecraft:gray_wool
setblock 396 183 323 minecraft:polished_deepslate
setblock 396 183 324 minecraft:gray_concrete
setblock 396 183 363 minecraft:polished_deepslate
fill 397 183 323 397 184 323 minecraft:gray_concrete
fill 397 183 363 397 184 363 minecraft:gray_concrete
fill 398 183 322 398 184 322 minecraft:gray_wool
setblock 401 183 323 minecraft:polished_deepslate
setblock 401 183 363 minecraft:polished_deepslate
fill 402 183 323 402 184 323 minecraft:gray_concrete
fill 402 183 363 402 184 363 minecraft:gray_concrete
setblock 405 183 324 minecraft:polished_deepslate
setblock 406 183 323 minecraft:polished_deepslate
fill 406 183 324 406 184 324 minecraft:gray_concrete
setblock 406 183 363 minecraft:polished_deepslate
fill 407 183 322 407 184 322 minecraft:gray_wool
fill 407 183 323 407 184 323 minecraft:gray_concrete
setblock 407 183 362 minecraft:polished_deepslate
fill 407 183 363 407 184 363 minecraft:gray_concrete
fill 407 183 364 407 184 364 minecraft:gray_wool
fill 408 183 324 409 183 324 minecraft:gray_concrete
setblock 408 183 362 minecraft:gray_concrete
setblock 410 183 324 minecraft:polished_deepslate
setblock 411 183 323 minecraft:polished_deepslate
setblock 411 183 324 minecraft:gray_concrete
setblock 411 183 363 minecraft:polished_deepslate
fill 411 183 364 411 184 364 minecraft:gray_wool
fill 412 183 322 412 184 322 minecraft:gray_wool
fill 412 183 323 412 184 323 minecraft:gray_concrete
setblock 412 183 363 minecraft:gray_concrete
setblock 415 183 345 minecraft:gray_concrete
setblock 415 183 349 minecraft:polished_deepslate
fill 415 183 350 415 184 350 minecraft:gray_concrete
fill 416 183 322 416 184 322 minecraft:gray_wool
setblock 416 183 328 minecraft:polished_deepslate
setblock 416 183 329 minecraft:gray_concrete
setblock 416 183 343 minecraft:polished_deepslate
fill 416 183 344 416 184 344 minecraft:gray_concrete
setblock 416 183 348 minecraft:polished_deepslate
fill 416 183 349 416 184 349 minecraft:gray_concrete
setblock 417 183 322 minecraft:black_concrete
setblock 417 183 327 minecraft:polished_deepslate
fill 417 183 328 417 184 328 minecraft:gray_concrete
setblock 417 183 331 minecraft:gray_concrete
setblock 417 183 332 minecraft:polished_deepslate
fill 417 183 333 417 184 333 minecraft:gray_concrete
setblock 417 183 342 minecraft:polished_deepslate
fill 417 183 343 417 184 343 minecraft:gray_concrete
setblock 417 183 347 minecraft:polished_deepslate
fill 417 183 348 417 184 348 minecraft:gray_concrete
setblock 417 183 352 minecraft:polished_deepslate
fill 417 183 353 417 184 353 minecraft:gray_concrete
fill 418 183 323 418 183 324 minecraft:black_concrete
setblock 418 183 326 minecraft:black_concrete
fill 418 183 334 418 184 334 minecraft:gray_wool
fill 418 183 338 418 184 338 minecraft:gray_wool
fill 418 183 343 418 184 343 minecraft:gray_wool
fill 418 183 348 418 184 348 minecraft:gray_wool
setblock 418 183 350 minecraft:black_concrete
fill 418 183 360 418 184 360 minecraft:gray_wool
setblock 418 183 363 minecraft:black_concrete
fill 418 183 364 418 184 364 minecraft:gray_wool
fill 376 184 334 376 185 334 minecraft:gray_wool
setblock 376 184 338 minecraft:gray_wool
setblock 376 184 340 minecraft:gray_wool
setblock 376 184 344 minecraft:gray_wool
fill 376 184 362 376 184 363 minecraft:gray_wool
fill 377 184 323 377 184 325 minecraft:gray_concrete
setblock 377 184 326 minecraft:polished_deepslate
setblock 377 184 327 minecraft:gray_concrete
setblock 377 184 331 minecraft:polished_deepslate
setblock 377 184 332 minecraft:gray_concrete
setblock 377 184 346 minecraft:polished_deepslate
setblock 377 184 347 minecraft:gray_concrete
fill 378 184 324 379 184 324 minecraft:light_blue_stained_glass
setblock 378 184 325 minecraft:polished_deepslate
setblock 378 184 326 minecraft:gray_concrete
setblock 378 184 330 minecraft:polished_deepslate
setblock 378 184 331 minecraft:gray_concrete
setblock 379 184 364 minecraft:gray_wool
setblock 380 184 323 minecraft:polished_deepslate
setblock 380 184 324 minecraft:gray_concrete
setblock 381 184 323 minecraft:gray_concrete
fill 381 184 325 381 184 326 minecraft:light_blue_stained_glass
setblock 383 184 325 minecraft:polished_deepslate
setblock 384 184 324 minecraft:polished_deepslate
fill 384 184 325 384 184 326 minecraft:gray_concrete
setblock 385 184 323 minecraft:polished_deepslate
setblock 385 184 324 minecraft:gray_concrete
fill 385 184 326 386 184 326 minecraft:gray_concrete
setblock 385 184 363 minecraft:polished_deepslate
setblock 386 184 323 minecraft:gray_concrete
setblock 386 184 362 minecraft:polished_deepslate
fill 386 184 363 389 184 363 minecraft:gray_concrete
setblock 387 184 326 minecraft:polished_deepslate
setblock 387 184 362 minecraft:gray_concrete
setblock 388 184 325 minecraft:polished_deepslate
setblock 388 184 326 minecraft:gray_concrete
setblock 389 184 324 minecraft:polished_deepslate
setblock 389 184 325 minecraft:gray_concrete
setblock 390 184 323 minecraft:polished_deepslate
setblock 390 184 324 minecraft:gray_concrete
setblock 390 184 363 minecraft:polished_deepslate
setblock 391 184 323 minecraft:gray_concrete
setblock 391 184 362 minecraft:polished_deepslate
setblock 391 184 363 minecraft:gray_concrete
setblock 392 184 362 minecraft:gray_concrete
setblock 393 184 325 minecraft:polished_deepslate
setblock 394 184 324 minecraft:polished_deepslate
setblock 395 184 323 minecraft:polished_deepslate
setblock 395 184 324 minecraft:gray_concrete
setblock 395 184 363 minecraft:polished_deepslate
setblock 396 184 323 minecraft:gray_concrete
setblock 396 184 363 minecraft:gray_concrete
setblock 401 184 363 minecraft:gray_concrete
setblock 405 184 323 minecraft:polished_deepslate
setblock 405 184 363 minecraft:polished_deepslate
setblock 406 184 323 minecraft:gray_concrete
setblock 406 184 363 minecraft:gray_concrete
setblock 408 184 324 minecraft:gray_concrete
setblock 409 184 324 minecraft:polished_deepslate
setblock 410 184 323 minecraft:polished_deepslate
setblock 410 184 324 minecraft:gray_concrete
setblock 410 184 363 minecraft:polished_deepslate
setblock 411 184 323 minecraft:gray_concrete
setblock 411 184 363 minecraft:gray_concrete
setblock 415 184 348 minecraft:polished_deepslate
setblock 415 184 349 minecraft:gray_concrete
setblock 416 184 347 minecraft:polished_deepslate
setblock 416 184 348 minecraft:gray_concrete
setblock 416 184 352 minecraft:polished_deepslate
setblock 417 184 322 minecraft:gray_wool
setblock 417 184 326 minecraft:polished_deepslate
setblock 417 184 327 minecraft:gray_concrete
setblock 417 184 331 minecraft:polished_deepslate
setblock 417 184 332 minecraft:gray_concrete
setblock 417 184 341 minecraft:polished_deepslate
setblock 417 184 342 minecraft:gray_concrete
setblock 417 184 346 minecraft:polished_deepslate
setblock 417 184 347 minecraft:gray_concrete
setblock 417 184 351 minecraft:polished_deepslate
setblock 417 184 352 minecraft:gray_concrete
fill 418 184 323 418 184 324 minecraft:gray_wool
fill 418 184 326 418 185 326 minecraft:gray_wool
setblock 418 184 350 minecraft:gray_wool
setblock 418 184 363 minecraft:gray_wool
fill 376 185 323 376 246 323 minecraft:black_concrete
setblock 376 185 324 minecraft:light_blue_stained_glass
fill 376 185 325 376 185 333 minecraft:black_concrete
fill 376 185 335 376 185 346 minecraft:black_concrete
setblock 376 185 347 minecraft:gray_wool
fill 376 185 348 376 186 351 minecraft:black_concrete
setblock 376 185 352 minecraft:gray_wool
fill 376 185 353 376 185 360 minecraft:black_concrete
setblock 376 185 361 minecraft:gray_wool
fill 376 185 362 376 186 364 minecraft:black_concrete
fill 377 185 322 385 191 322 minecraft:black_concrete
fill 378 185 364 380 187 364 minecraft:black_concrete
setblock 381 185 364 minecraft:gray_wool
fill 382 185 364 395 185 364 minecraft:black_concrete
setblock 387 185 322 minecraft:light_blue_stained_glass
fill 388 185 322 389 243 322 minecraft:black_concrete
fill 391 185 322 399 186 322 minecraft:black_concrete
fill 397 185 364 398 185 364 minecraft:black_concrete
fill 401 185 364 407 185 364 minecraft:black_concrete
fill 402 185 322 418 185 322 minecraft:black_concrete
fill 409 185 364 418 185 364 minecraft:black_concrete
fill 418 185 323 418 185 325 minecraft:black_concrete
fill 418 185 327 418 204 330 minecraft:black_concrete
fill 418 185 332 418 185 335 minecraft:black_concrete
fill 418 185 337 418 185 350 minecraft:black_concrete
fill 418 185 352 418 243 355 minecraft:black_concrete
fill 418 185 357 418 186 363 minecraft:black_concrete
fill 376 186 322 376 244 322 minecraft:black_concrete
fill 376 186 324 376 186 331 minecraft:black_concrete
setblock 376 186 332 minecraft:gray_wool
fill 376 186 333 376 212 334 minecraft:black_concrete
setblock 376 186 335 minecraft:gray_wool
fill 376 186 336 376 189 339 minecraft:black_concrete
setblock 376 186 340 minecraft:gray_wool
fill 376 186 341 376 216 347 minecraft:black_concrete
fill 376 186 352 376 211 357 minecraft:black_concrete
setblock 376 186 358 minecraft:light_blue_stained_glass
fill 376 186 359 376 246 361 minecraft:black_concrete
fill 377 186 364 377 246 364 minecraft:black_concrete
fill 381 186 364 387 196 364 minecraft:black_concrete
fill 386 186 322 387 243 322 minecraft:black_concrete
setblock 388 186 364 minecraft:light_blue_stained_glass
fill 389 186 364 389 244 364 minecraft:black_concrete
fill 390 186 322 390 242 322 minecraft:black_concrete
setblock 390 186 364 minecraft:gray_wool
fill 391 186 364 393 193 364 minecraft:black_concrete
setblock 394 186 364 minecraft:gray_wool
fill 395 186 364 396 210 364 minecraft:black_concrete
fill 397 186 364 398 186 364 minecraft:gray_wool
fill 399 186 364 400 246 364 minecraft:black_concrete
fill 400 186 322 402 186 322 minecraft:black_concrete
fill 401 186 364 401 187 364 minecraft:gray_wool
fill 402 186 364 402 243 364 minecraft:black_concrete
fill 403 186 322 404 186 322 minecraft:gray_wool
setblock 403 186 364 minecraft:gray_wool
fill 404 186 364 408 186 364 minecraft:black_concrete
fill 405 186 322 415 186 322 minecraft:black_concrete
fill 409 186 364 409 187 364 minecraft:gray_wool
fill 410 186 364 414 240 364 minecraft:black_concrete
setblock 415 186 364 minecraft:gray_wool
setblock 416 186 322 minecraft:gray_wool
fill 416 186 364 418 244 364 minecraft:black_concrete
fill 417 186 322 417 246 322 minecraft:black_concrete
setblock 418 186 322 minecraft:gray_wool
fill 418 186 323 418 193 323 minecraft:black_concrete
setblock 418 186 324 minecraft:light_blue_stained_glass
fill 418 186 325 418 234 326 minecraft:black_concrete
fill 418 186 332 418 246 332 minecraft:black_concrete
setblock 418 186 333 minecraft:gray_wool
fill 418 186 334 418 190 335 minecraft:black_concrete
fill 418 186 337 418 186 347 minecraft:black_concrete
setblock 418 186 348 minecraft:gray_wool
fill 418 186 349 418 186 351 minecraft:black_concrete
fill 418 186 356 418 246 356 minecraft:black_concrete
fill 376 187 324 376 226 327 minecraft:black_concrete
setblock 376 187 328 minecraft:light_blue_stained_glass
fill 376 187 329 376 246 329 minecraft:black_concrete
fill 376 187 330 376 187 331 minecraft:gray_wool
fill 376 187 332 376 246 332 minecraft:black_concrete
fill 376 187 335 376 246 335 minecraft:black_concrete
fill 376 187 340 376 242 340 minecraft:black_concrete
fill 376 187 348 376 246 348 minecraft:black_concrete
setblock 376 187 349 minecraft:gray_wool
fill 376 187 350 376 244 350 minecraft:black_concrete
setblock 376 187 351 minecraft:gray_wool
fill 376 187 358 376 247 358 minecraft:black_concrete
setblock 376 187 362 minecraft:gray_wool
fill 376 187 363 376 246 364 minecraft:black_concrete
setblock 388 187 364 minecraft:gray_wool
fill 390 187 364 390 246 364 minecraft:black_concrete
fill 391 187 322 391 210 322 minecraft:black_concrete
setblock 392 187 322 minecraft:gray_wool
fill 393 187 322 394 239 322 minecraft:black_concrete
fill 394 187 364 394 246 364 minecraft:black_concrete
setblock 395 187 322 minecraft:gray_wool
fill 396 187 322 396 246 322 minecraft:black_concrete
setblock 397 187 322 minecraft:gray_wool
fill 397 187 364 398 208 364 minecraft:black_concrete
fill 398 187 322 400 233 322 minecraft:black_concrete
setblock 401 187 322 minecraft:gray_wool
fill 402 187 322 404 232 322 minecraft:black_concrete
fill 403 187 364 404 246 364 minecraft:black_concrete
setblock 405 187 322 minecraft:gray_wool
setblock 405 187 364 minecraft:gray_wool
fill 406 187 322 416 204 322 minecraft:black_concrete
fill 406 187 364 408 189 364 minecraft:black_concrete
fill 415 187 364 415 190 364 minecraft:black_concrete
fill 418 187 322 418 244 322 minecraft:black_concrete
fill 418 187 324 418 219 324 minecraft:black_concrete
fill 418 187 331 418 246 331 minecraft:black_concrete
fill 418 187 333 418 224 333 minecraft:black_concrete
fill 418 187 336 418 225 340 minecraft:black_concrete
setblock 418 187 341 minecraft:gray_wool
fill 418 187 342 418 187 350 minecraft:black_concrete
setblock 418 187 351 minecraft:gray_wool
setblock 418 187 357 minecraft:gray_wool
fill 418 187 358 418 204 362 minecraft:black_concrete
setblock 418 187 363 minecraft:gray_wool
fill 376 188 328 376 204 328 minecraft:black_concrete
fill 376 188 330 376 229 331 minecraft:black_concrete
fill 376 188 349 376 243 349 minecraft:black_concrete
fill 376 188 351 376 246 351 minecraft:black_concrete
fill 376 188 362 376 242 362 minecraft:black_concrete
fill 378 188 364 379 207 364 minecraft:black_concrete
setblock 379 188 325 minecraft:light[level=12]
setblock 379 188 332 minecraft:light[level=12]
setblock 379 188 339 minecraft:light[level=12]
setblock 379 188 346 minecraft:light[level=12]
setblock 379 188 353 minecraft:light[level=12]
setblock 379 188 360 minecraft:light[level=12]
setblock 380 188 364 minecraft:light_blue_stained_glass
setblock 386 188 325 minecraft:light[level=12]
setblock 386 188 332 minecraft:light[level=12]
setblock 386 188 339 minecraft:light[level=12]
setblock 386 188 346 minecraft:light[level=12]
setblock 386 188 353 minecraft:light[level=12]
setblock 386 188 360 minecraft:light[level=12]
fill 388 188 364 388 206 364 minecraft:black_concrete
fill 392 188 322 392 246 322 minecraft:black_concrete
setblock 393 188 325 minecraft:light[level=12]
setblock 393 188 332 minecraft:light[level=12]
setblock 393 188 339 minecraft:light[level=12]
setblock 393 188 346 minecraft:light[level=12]
setblock 393 188 353 minecraft:light[level=12]
setblock 393 188 360 minecraft:light[level=12]
fill 395 188 322 395 203 322 minecraft:black_concrete
fill 397 188 322 397 209 322 minecraft:black_concrete
setblock 400 188 325 minecraft:light[level=12]
setblock 400 188 332 minecraft:light[level=12]
setblock 400 188 339 minecraft:light[level=12]
setblock 400 188 346 minecraft:light[level=12]
setblock 400 188 353 minecraft:light[level=12]
setblock 400 188 360 minecraft:light[level=12]
fill 401 188 322 401 246 322 minecraft:black_concrete
fill 401 188 364 401 247 364 minecraft:black_concrete
fill 405 188 322 405 246 322 minecraft:black_concrete
fill 405 188 364 405 217 364 minecraft:black_concrete
setblock 407 188 325 minecraft:light[level=12]
setblock 407 188 332 minecraft:light[level=12]
setblock 407 188 339 minecraft:light[level=12]
setblock 407 188 346 minecraft:light[level=12]
setblock 407 188 353 minecraft:light[level=12]
setblock 407 188 360 minecraft:light[level=12]
fill 409 188 364 409 205 364 minecraft:black_concrete
setblock 414 188 325 minecraft:light[level=12]
setblock 414 188 332 minecraft:light[level=12]
setblock 414 188 339 minecraft:light[level=12]
setblock 414 188 346 minecraft:light[level=12]
setblock 414 188 353 minecraft:light[level=12]
setblock 414 188 360 minecraft:light[level=12]
fill 418 188 341 418 196 345 minecraft:black_concrete
setblock 418 188 346 minecraft:light_blue_stained_glass
fill 418 188 347 418 195 351 minecraft:black_concrete
fill 418 188 357 418 246 357 minecraft:black_concrete
fill 418 188 363 418 246 363 minecraft:black_concrete
fill 380 189 364 380 226 364 minecraft:black_concrete
fill 418 189 346 418 246 346 minecraft:black_concrete
fill 376 190 336 376 243 337 minecraft:black_concrete
fill 376 190 338 376 190 339 minecraft:light_blue_stained_glass
setblock 377 190 336 minecraft:yellow_concrete
setblock 379 190 325 minecraft:light[level=13]
setblock 379 190 333 minecraft:light[level=13]
setblock 379 190 341 minecraft:light[level=13]
setblock 379 190 349 minecraft:light[level=13]
setblock 379 190 357 minecraft:light[level=13]
fill 385 190 335 385 192 337 minecraft:iron_block
fill 385 190 338 390 190 338 minecraft:yellow_stained_glass
fill 385 190 339 385 192 341 minecraft:iron_block
fill 386 190 333 386 192 334 minecraft:iron_block
fill 386 190 335 390 190 337 minecraft:yellow_stained_glass
fill 386 190 339 390 190 341 minecraft:yellow_stained_glass
fill 386 190 342 386 192 343 minecraft:iron_block
setblock 387 190 325 minecraft:light[level=13]
fill 387 190 332 387 192 332 minecraft:iron_block
fill 387 190 333 399 191 334 minecraft:yellow_stained_glass
fill 387 190 342 399 191 343 minecraft:yellow_stained_glass
fill 387 190 344 387 192 344 minecraft:iron_block
setblock 387 190 349 minecraft:light[level=13]
setblock 387 190 357 minecraft:light[level=13]
fill 388 190 331 389 191 331 minecraft:iron_block
fill 388 190 332 398 191 332 minecraft:yellow_stained_glass
fill 388 190 344 398 191 344 minecraft:yellow_stained_glass
fill 388 190 345 389 191 345 minecraft:iron_block
fill 390 190 330 392 192 330 minecraft:iron_block
fill 390 190 331 396 191 331 minecraft:yellow_stained_glass
fill 390 190 345 396 191 345 minecraft:yellow_stained_glass
fill 390 190 346 392 192 346 minecraft:iron_block
fill 391 190 335 391 190 336 minecraft:yellow_stained_glass
fill 391 190 340 391 190 341 minecraft:yellow_stained_glass
fill 392 190 335 400 190 335 minecraft:yellow_stained_glass
fill 392 190 341 400 190 341 minecraft:yellow_stained_glass
fill 393 190 330 393 191 330 minecraft:yellow_stained_glass
fill 393 190 346 393 191 346 minecraft:yellow_stained_glass
fill 394 190 330 396 192 330 minecraft:iron_block
fill 394 190 346 396 192 346 minecraft:iron_block
setblock 395 190 325 minecraft:light[level=13]
fill 395 190 336 400 190 336 minecraft:yellow_stained_glass
fill 395 190 340 400 190 340 minecraft:yellow_stained_glass
setblock 395 190 349 minecraft:light[level=13]
setblock 395 190 357 minecraft:light[level=13]
fill 396 190 337 400 190 339 minecraft:yellow_stained_glass
fill 397 190 331 398 191 331 minecraft:iron_block
fill 397 190 345 398 191 345 minecraft:iron_block
fill 399 190 332 399 192 332 minecraft:iron_block
fill 399 190 344 399 192 344 minecraft:iron_block
fill 400 190 333 400 192 334 minecraft:iron_block
fill 400 190 342 400 192 343 minecraft:iron_block
fill 401 190 335 401 192 337 minecraft:iron_block
fill 401 190 338 401 191 338 minecraft:yellow_stained_glass
fill 401 190 339 401 192 341 minecraft:iron_block
setblock 403 190 325 minecraft:light[level=13]
setblock 403 190 333 minecraft:light[level=13]
setblock 403 190 341 minecraft:light[level=13]
setblock 403 190 349 minecraft:light[level=13]
setblock 403 190 357 minecraft:light[level=13]
fill 406 190 364 407 227 364 minecraft:black_concrete
setblock 408 190 364 minecraft:light_blue_stained_glass
setblock 411 190 325 minecraft:light[level=13]
setblock 411 190 333 minecraft:light[level=13]
setblock 411 190 341 minecraft:light[level=13]
setblock 411 190 349 minecraft:light[level=13]
setblock 411 190 357 minecraft:light[level=13]
fill 376 191 338 376 213 339 minecraft:black_concrete
fill 377 191 323 384 191 334 minecraft:gray_wool
setblock 377 191 335 minecraft:yellow_concrete
fill 377 191 336 383 191 363 minecraft:gray_wool
fill 378 191 335 384 191 335 minecraft:gray_wool
setblock 384 191 336 minecraft:gray_wool
fill 384 191 337 384 191 339 minecraft:iron_block
fill 384 191 340 384 191 363 minecraft:gray_wool
fill 385 191 323 385 191 333 minecraft:gray_wool
setblock 385 191 334 minecraft:iron_block
fill 385 191 338 389 191 338 minecraft:yellow_stained_glass
setblock 385 191 342 minecraft:iron_block
fill 385 191 343 385 191 363 minecraft:gray_wool
fill 386 191 323 386 191 332 minecraft:gray_wool
fill 386 191 335 389 191 337 minecraft:yellow_stained_glass
fill 386 191 339 389 191 341 minecraft:yellow_stained_glass
fill 386 191 344 386 191 363 minecraft:gray_wool
fill 387 191 323 387 191 331 minecraft:gray_wool
fill 387 191 345 387 191 363 minecraft:gray_wool
fill 388 191 323 388 191 330 minecraft:gray_wool
fill 388 191 346 388 191 363 minecraft:gray_wool
fill 389 191 323 391 191 329 minecraft:gray_wool
setblock 389 191 330 minecraft:iron_block
setblock 389 191 346 minecraft:iron_block
fill 389 191 347 391 191 363 minecraft:gray_wool
setblock 390 191 335 minecraft:yellow_stained_glass
fill 390 191 336 390 193 336 minecraft:quartz_block
fill 390 191 337 390 191 339 minecraft:shroomlight
fill 390 191 340 390 193 340 minecraft:quartz_block
setblock 390 191 341 minecraft:yellow_stained_glass
fill 391 191 335 391 193 335 minecraft:quartz_block
setblock 391 191 336 minecraft:shroomlight
setblock 391 191 340 minecraft:shroomlight
fill 391 191 341 391 193 341 minecraft:quartz_block
fill 392 191 323 417 191 328 minecraft:gray_wool
fill 392 191 329 394 191 329 minecraft:iron_block
fill 392 191 335 394 191 335 minecraft:shroomlight
fill 392 191 341 394 191 341 minecraft:shroomlight
fill 392 191 347 394 191 347 minecraft:iron_block
fill 392 191 348 417 191 363 minecraft:gray_wool
fill 395 191 329 417 191 329 minecraft:gray_wool
fill 395 191 335 395 193 335 minecraft:quartz_block
setblock 395 191 336 minecraft:shroomlight
setblock 395 191 340 minecraft:shroomlight
fill 395 191 341 395 193 341 minecraft:quartz_block
fill 395 191 347 417 191 347 minecraft:gray_wool
fill 396 191 335 400 191 335 minecraft:yellow_stained_glass
fill 396 191 336 396 193 336 minecraft:quartz_block
fill 396 191 337 396 191 339 minecraft:shroomlight
fill 396 191 340 396 193 340 minecraft:quartz_block
fill 396 191 341 400 191 341 minecraft:yellow_stained_glass
setblock 397 191 330 minecraft:iron_block
fill 397 191 336 400 191 340 minecraft:yellow_stained_glass
setblock 397 191 346 minecraft:iron_block
fill 398 191 330 417 191 330 minecraft:gray_wool
fill 398 191 346 417 191 346 minecraft:gray_wool
fill 399 191 331 417 191 331 minecraft:gray_wool
fill 399 191 345 417 191 345 minecraft:gray_wool
fill 400 191 332 417 191 332 minecraft:gray_wool
fill 400 191 344 417 191 344 minecraft:gray_wool
fill 401 191 333 417 191 333 minecraft:gray_wool
setblock 401 191 334 minecraft:iron_block
setblock 401 191 342 minecraft:iron_block
fill 401 191 343 417 191 343 minecraft:gray_wool
fill 402 191 334 417 191 336 minecraft:gray_wool
fill 402 191 337 402 191 339 minecraft:iron_block
fill 402 191 340 417 191 342 minecraft:gray_wool
fill 403 191 337 417 191 339 minecraft:gray_wool
fill 408 191 364 408 243 364 minecraft:black_concrete
setblock 415 191 364 minecraft:light_blue_stained_glass
setblock 418 191 334 minecraft:light_blue_stained_glass
fill 418 191 335 418 243 335 minecraft:black_concrete
fill 377 192 322 382 206 322 minecraft:black_concrete
setblock 377 192 336 minecraft:yellow_concrete
setblock 383 192 322 minecraft:light_blue_stained_glass
fill 384 192 322 385 243 322 minecraft:black_concrete
fill 385 192 338 385 193 338 minecraft:iron_bars
setblock 386 192 335 minecraft:iron_block
setblock 386 192 341 minecraft:iron_block
setblock 387 192 333 minecraft:iron_block
fill 387 192 338 388 192 338 minecraft:red_nether_bricks
setblock 387 192 343 minecraft:iron_block
fill 388 192 331 388 192 332 minecraft:iron_block
fill 388 192 336 389 192 337 minecraft:red_nether_bricks
fill 388 192 339 389 192 340 minecraft:red_nether_bricks
fill 388 192 344 388 192 345 minecraft:iron_block
fill 389 192 331 389 195 331 minecraft:iron_bars
fill 389 192 335 390 195 335 minecraft:red_nether_bricks
fill 389 192 338 390 192 338 minecraft:quartz_block
fill 389 192 341 390 195 341 minecraft:red_nether_bricks
fill 389 192 345 389 195 345 minecraft:iron_bars
setblock 390 192 331 minecraft:iron_block
fill 390 192 334 392 192 334 minecraft:red_nether_bricks
setblock 390 192 337 minecraft:red_nether_bricks
setblock 390 192 339 minecraft:red_nether_bricks
fill 390 192 342 392 192 342 minecraft:red_nether_bricks
setblock 390 192 345 minecraft:iron_block
setblock 392 192 335 minecraft:red_nether_bricks
setblock 392 192 341 minecraft:red_nether_bricks
setblock 393 192 330 minecraft:iron_block
fill 393 192 334 393 192 335 minecraft:quartz_block
fill 393 192 341 393 192 342 minecraft:quartz_block
setblock 393 192 346 minecraft:iron_block
fill 394 192 334 394 192 335 minecraft:red_nether_bricks
fill 394 192 341 394 192 342 minecraft:red_nether_bricks
fill 395 192 334 396 192 334 minecraft:red_nether_bricks
fill 395 192 342 396 192 342 minecraft:red_nether_bricks
setblock 396 192 331 minecraft:iron_block
fill 396 192 335 397 194 335 minecraft:red_nether_bricks
fill 396 192 337 398 192 337 minecraft:red_nether_bricks
fill 396 192 338 397 192 338 minecraft:quartz_block
fill 396 192 339 398 192 339 minecraft:red_nether_bricks
fill 396 192 341 397 194 341 minecraft:red_nether_bricks
setblock 396 192 345 minecraft:iron_block
fill 397 192 331 397 195 331 minecraft:iron_bars
fill 397 192 336 398 192 336 minecraft:red_nether_bricks
fill 397 192 340 398 192 340 minecraft:red_nether_bricks
fill 397 192 345 397 195 345 minecraft:iron_bars
fill 398 192 331 398 192 332 minecraft:iron_block
fill 398 192 338 399 192 338 minecraft:red_nether_bricks
fill 398 192 344 398 192 345 minecraft:iron_block
setblock 399 192 333 minecraft:iron_block
setblock 399 192 343 minecraft:iron_block
setblock 400 192 335 minecraft:iron_block
setblock 400 192 341 minecraft:iron_block
setblock 401 192 338 minecraft:iron_bars
fill 415 192 364 415 247 364 minecraft:black_concrete
fill 418 192 334 418 243 334 minecraft:black_concrete
setblock 377 193 337 minecraft:ochre_froglight
fill 383 193 322 383 242 322 minecraft:black_concrete
fill 386 193 336 387 201 340 minecraft:red_nether_bricks
fill 387 193 335 388 201 335 minecraft:red_nether_bricks
fill 387 193 341 388 201 341 minecraft:red_nether_bricks
fill 388 193 334 390 198 334 minecraft:red_nether_bricks
fill 388 193 336 388 198 337 minecraft:red_nether_bricks
fill 388 193 338 389 193 338 minecraft:quartz_block
fill 388 193 339 388 198 340 minecraft:red_nether_bricks
fill 388 193 342 390 198 342 minecraft:red_nether_bricks
fill 389 193 333 392 198 333 minecraft:red_nether_bricks
setblock 389 193 336 minecraft:quartz_block
fill 389 193 337 389 195 337 minecraft:red_nether_bricks
fill 389 193 339 389 195 339 minecraft:red_nether_bricks
setblock 389 193 340 minecraft:quartz_block
fill 389 193 343 392 198 343 minecraft:red_nether_bricks
setblock 391 193 334 minecraft:quartz_block
setblock 391 193 342 minecraft:quartz_block
fill 392 193 332 394 201 332 minecraft:red_nether_bricks
fill 392 193 334 392 195 334 minecraft:red_nether_bricks
fill 392 193 342 392 195 342 minecraft:red_nether_bricks
fill 392 193 344 394 201 344 minecraft:red_nether_bricks
fill 393 193 333 393 193 334 minecraft:quartz_block
fill 393 193 342 393 193 343 minecraft:quartz_block
fill 394 193 333 394 195 334 minecraft:red_nether_bricks
fill 394 193 342 394 195 343 minecraft:red_nether_bricks
fill 395 193 333 397 199 333 minecraft:red_nether_bricks
setblock 395 193 334 minecraft:quartz_block
setblock 395 193 342 minecraft:quartz_block
fill 395 193 343 397 199 343 minecraft:red_nether_bricks
fill 396 193 334 398 198 334 minecraft:red_nether_bricks
fill 396 193 342 398 198 342 minecraft:red_nether_bricks
setblock 397 193 336 minecraft:quartz_block
setblock 397 193 337 minecraft:red_nether_bricks
fill 397 193 338 398 193 338 minecraft:quartz_block
setblock 397 193 339 minecraft:red_nether_bricks
setblock 397 193 340 minecraft:quartz_block
fill 398 193 335 398 193 336 minecraft:red_nether_bricks
fill 398 193 337 404 198 337 minecraft:nether_bricks
fill 398 193 339 404 198 339 minecraft:nether_bricks
fill 398 193 340 398 193 341 minecraft:red_nether_bricks
setblock 399 193 335 minecraft:red_nether_bricks
fill 399 193 336 403 199 336 minecraft:nether_bricks
fill 399 193 338 404 199 338 minecraft:nether_bricks
fill 399 193 340 403 199 340 minecraft:nether_bricks
setblock 399 193 341 minecraft:red_nether_bricks
setblock 377 194 338 minecraft:yellow_concrete
setblock 379 194 325 minecraft:light[level=12]
setblock 379 194 332 minecraft:light[level=12]
setblock 379 194 339 minecraft:light[level=12]
setblock 379 194 346 minecraft:light[level=12]
setblock 379 194 353 minecraft:light[level=12]
setblock 379 194 360 minecraft:light[level=12]
fill 385 194 336 385 201 340 minecraft:red_nether_bricks
setblock 386 194 325 minecraft:light[level=12]
setblock 386 194 332 minecraft:light[level=12]
fill 386 194 335 386 202 335 minecraft:red_nether_bricks
fill 386 194 341 386 202 341 minecraft:red_nether_bricks
setblock 386 194 346 minecraft:light[level=12]
setblock 386 194 353 minecraft:light[level=12]
setblock 386 194 360 minecraft:light[level=12]
fill 387 194 334 387 202 334 minecraft:red_nether_bricks
fill 387 194 342 387 202 342 minecraft:red_nether_bricks
fill 388 194 333 388 202 333 minecraft:red_nether_bricks
fill 388 194 338 389 195 338 minecraft:red_nether_bricks
fill 388 194 343 388 202 343 minecraft:red_nether_bricks
fill 389 194 332 391 201 332 minecraft:red_nether_bricks
fill 389 194 336 389 196 336 minecraft:red_nether_bricks
fill 389 194 340 389 196 340 minecraft:red_nether_bricks
fill 389 194 344 391 201 344 minecraft:red_nether_bricks
fill 391 194 334 391 196 334 minecraft:red_nether_bricks
fill 391 194 342 391 196 342 minecraft:red_nether_bricks
fill 391 194 364 392 214 364 minecraft:black_concrete
setblock 393 194 325 minecraft:light[level=12]
fill 393 194 333 393 195 334 minecraft:red_nether_bricks
fill 393 194 342 393 195 343 minecraft:red_nether_bricks
setblock 393 194 346 minecraft:light[level=12]
setblock 393 194 353 minecraft:light[level=12]
setblock 393 194 360 minecraft:light[level=12]
fill 393 194 364 393 195 364 minecraft:light_blue_stained_glass
fill 395 194 332 397 201 332 minecraft:red_nether_bricks
fill 395 194 334 395 196 334 minecraft:red_nether_bricks
fill 395 194 342 395 196 342 minecraft:red_nether_bricks
fill 395 194 344 397 201 344 minecraft:red_nether_bricks
fill 397 194 336 397 195 340 minecraft:nether_bricks
fill 398 194 333 398 202 333 minecraft:red_nether_bricks
fill 398 194 335 398 198 336 minecraft:nether_bricks
fill 398 194 338 398 198 338 minecraft:nether_bricks
fill 398 194 340 398 198 341 minecraft:nether_bricks
fill 398 194 343 398 202 343 minecraft:red_nether_bricks
setblock 399 194 334 minecraft:red_nether_bricks
fill 399 194 335 404 198 335 minecraft:nether_bricks
fill 399 194 341 404 198 341 minecraft:nether_bricks
setblock 399 194 342 minecraft:red_nether_bricks
setblock 400 194 325 minecraft:light[level=12]
setblock 400 194 332 minecraft:light[level=12]
setblock 400 194 346 minecraft:light[level=12]
setblock 400 194 353 minecraft:light[level=12]
setblock 400 194 360 minecraft:light[level=12]
fill 404 194 336 405 196 336 minecraft:nether_bricks
fill 404 194 340 405 196 340 minecraft:nether_bricks
fill 405 194 337 405 198 339 minecraft:nether_bricks
fill 406 194 338 406 198 338 minecraft:nether_bricks
setblock 407 194 325 minecraft:light[level=12]
setblock 407 194 332 minecraft:light[level=12]
setblock 407 194 339 minecraft:light[level=12]
setblock 407 194 346 minecraft:light[level=12]
setblock 407 194 353 minecraft:light[level=12]
setblock 407 194 360 minecraft:light[level=12]
setblock 414 194 325 minecraft:light[level=12]
setblock 414 194 332 minecraft:light[level=12]
setblock 414 194 339 minecraft:light[level=12]
setblock 414 194 346 minecraft:light[level=12]
setblock 414 194 353 minecraft:light[level=12]
setblock 414 194 360 minecraft:light[level=12]
setblock 418 194 323 minecraft:light_blue_stained_glass
fill 377 195 323 377 195 324 minecraft:gray_concrete
setblock 377 195 325 minecraft:polished_deepslate
fill 377 195 326 377 195 329 minecraft:gray_concrete
setblock 377 195 330 minecraft:polished_deepslate
fill 377 195 331 377 195 334 minecraft:gray_concrete
setblock 377 195 335 minecraft:polished_deepslate
fill 377 195 336 379 195 336 minecraft:gray_concrete
setblock 377 195 337 minecraft:yellow_concrete
fill 377 195 338 377 195 339 minecraft:gray_concrete
setblock 377 195 340 minecraft:polished_deepslate
fill 377 195 341 377 197 342 minecraft:gray_concrete
fill 377 195 352 377 195 354 minecraft:gray_concrete
setblock 377 195 355 minecraft:polished_deepslate
fill 377 195 356 377 195 359 minecraft:gray_concrete
setblock 377 195 360 minecraft:polished_deepslate
fill 377 195 361 378 195 363 minecraft:gray_concrete
setblock 378 195 323 minecraft:gray_concrete
setblock 378 195 324 minecraft:polished_deepslate
fill 378 195 325 378 195 328 minecraft:gray_concrete
setblock 378 195 329 minecraft:polished_deepslate
fill 378 195 330 378 195 333 minecraft:gray_concrete
setblock 378 195 334 minecraft:polished_deepslate
fill 378 195 335 379 197 335 minecraft:gray_concrete
fill 378 195 337 378 195 338 minecraft:gray_concrete
setblock 378 195 339 minecraft:polished_deepslate
fill 378 195 340 378 198 340 minecraft:gray_concrete
setblock 378 195 354 minecraft:polished_deepslate
fill 378 195 355 378 195 358 minecraft:gray_concrete
setblock 378 195 359 minecraft:polished_deepslate
fill 378 195 360 381 195 360 minecraft:gray_concrete
setblock 379 195 323 minecraft:polished_deepslate
fill 379 195 324 382 195 324 minecraft:gray_concrete
fill 379 195 329 379 195 332 minecraft:gray_concrete
setblock 379 195 333 minecraft:polished_deepslate
fill 379 195 334 379 198 334 minecraft:gray_concrete
setblock 379 195 337 minecraft:gray_concrete
setblock 379 195 338 minecraft:polished_deepslate
fill 379 195 355 379 195 357 minecraft:gray_concrete
setblock 379 195 358 minecraft:polished_deepslate
fill 379 195 359 380 197 359 minecraft:gray_concrete
fill 379 195 361 379 195 362 minecraft:gray_concrete
setblock 379 195 363 minecraft:polished_deepslate
fill 380 195 323 383 195 323 minecraft:gray_concrete
fill 380 195 358 380 198 358 minecraft:gray_concrete
setblock 380 195 361 minecraft:gray_concrete
setblock 380 195 362 minecraft:polished_deepslate
fill 380 195 363 383 195 363 minecraft:gray_concrete
setblock 381 195 325 minecraft:gray_concrete
fill 381 195 348 385 200 351 minecraft:black_concrete
setblock 381 195 361 minecraft:polished_deepslate
fill 381 195 362 384 195 362 minecraft:gray_concrete
fill 382 195 347 384 200 347 minecraft:black_concrete
fill 382 195 352 384 200 352 minecraft:black_concrete
setblock 382 195 360 minecraft:polished_deepslate
fill 382 195 361 385 195 361 minecraft:gray_concrete
setblock 383 195 324 minecraft:polished_deepslate
fill 383 195 360 386 195 360 minecraft:gray_concrete
setblock 384 195 323 minecraft:polished_deepslate
fill 384 195 324 385 197 324 minecraft:gray_concrete
fill 384 195 337 384 200 339 minecraft:red_nether_bricks
setblock 384 195 363 minecraft:polished_deepslate
fill 385 195 323 388 195 323 minecraft:gray_concrete
fill 385 195 335 385 201 335 minecraft:red_nether_bricks
fill 385 195 341 385 201 341 minecraft:red_nether_bricks
setblock 385 195 362 minecraft:polished_deepslate
fill 385 195 363 388 195 363 minecraft:gray_concrete
fill 386 195 334 386 201 334 minecraft:red_nether_bricks
fill 386 195 342 386 201 342 minecraft:red_nether_bricks
setblock 386 195 361 minecraft:polished_deepslate
fill 386 195 362 389 195 362 minecraft:gray_concrete
fill 387 195 333 387 201 333 minecraft:red_nether_bricks
fill 387 195 343 387 201 343 minecraft:red_nether_bricks
fill 387 195 361 389 196 361 minecraft:gray_concrete
fill 388 195 332 388 200 332 minecraft:red_nether_bricks
fill 388 195 344 388 200 344 minecraft:red_nether_bricks
setblock 389 195 363 minecraft:polished_deepslate
fill 390 195 331 396 199 331 minecraft:red_nether_bricks
fill 390 195 345 396 199 345 minecraft:red_nether_bricks
setblock 390 195 362 minecraft:polished_deepslate
fill 390 195 363 393 195 363 minecraft:gray_concrete
fill 391 195 362 394 195 362 minecraft:gray_concrete
setblock 394 195 363 minecraft:polished_deepslate
setblock 395 195 362 minecraft:polished_deepslate
fill 395 195 363 398 195 363 minecraft:gray_concrete
setblock 396 195 335 minecraft:red_nether_bricks
setblock 396 195 341 minecraft:red_nether_bricks
fill 396 195 362 399 195 362 minecraft:gray_concrete
fill 397 195 335 397 197 335 minecraft:nether_bricks
fill 397 195 341 397 197 341 minecraft:nether_bricks
fill 397 195 361 400 195 361 minecraft:gray_concrete
fill 398 195 332 398 200 332 minecraft:red_nether_bricks
fill 398 195 344 398 200 344 minecraft:red_nether_bricks
fill 399 195 333 399 201 333 minecraft:red_nether_bricks
fill 399 195 334 403 197 334 minecraft:nether_bricks
fill 399 195 342 403 197 342 minecraft:nether_bricks
fill 399 195 343 399 201 343 minecraft:red_nether_bricks
setblock 399 195 363 minecraft:polished_deepslate
fill 400 195 323 403 195 323 minecraft:gray_concrete
fill 400 195 360 401 195 360 minecraft:gray_concrete
setblock 400 195 362 minecraft:polished_deepslate
fill 400 195 363 403 195 363 minecraft:gray_concrete
setblock 401 195 361 minecraft:polished_deepslate
fill 401 195 362 404 195 362 minecraft:gray_concrete
setblock 402 195 360 minecraft:polished_deepslate
fill 402 195 361 404 196 361 minecraft:gray_concrete
setblock 404 195 323 minecraft:polished_deepslate
setblock 404 195 363 minecraft:polished_deepslate
fill 405 195 335 405 197 335 minecraft:nether_bricks
fill 405 195 341 405 197 341 minecraft:nether_bricks
setblock 405 195 362 minecraft:polished_deepslate
fill 405 195 363 407 196 363 minecraft:gray_concrete
fill 406 195 336 406 197 337 minecraft:nether_bricks
fill 406 195 339 406 197 340 minecraft:nether_bricks
fill 406 195 362 406 196 362 minecraft:gray_concrete
fill 415 195 333 415 195 336 minecraft:gray_concrete
setblock 415 195 337 minecraft:polished_deepslate
fill 415 195 338 417 196 338 minecraft:gray_concrete
fill 416 195 329 416 195 330 minecraft:gray_concrete
setblock 416 195 331 minecraft:polished_deepslate
fill 416 195 332 416 195 335 minecraft:gray_concrete
setblock 416 195 336 minecraft:polished_deepslate
fill 416 195 337 417 197 337 minecraft:gray_concrete
fill 416 195 339 416 195 340 minecraft:gray_concrete
setblock 416 195 341 minecraft:polished_deepslate
fill 417 195 323 417 195 324 minecraft:gray_concrete
setblock 417 195 325 minecraft:polished_deepslate
fill 417 195 326 417 195 329 minecraft:gray_concrete
setblock 417 195 330 minecraft:polished_deepslate
fill 417 195 331 417 195 334 minecraft:gray_concrete
setblock 417 195 335 minecraft:polished_deepslate
fill 417 195 336 417 198 336 minecraft:gray_concrete
setblock 417 195 339 minecraft:gray_concrete
setblock 417 195 340 minecraft:polished_deepslate
fill 417 195 341 417 195 344 minecraft:gray_concrete
setblock 417 195 345 minecraft:polished_deepslate
fill 417 195 352 417 195 354 minecraft:gray_concrete
setblock 417 195 355 minecraft:polished_deepslate
fill 417 195 356 417 195 359 minecraft:gray_concrete
setblock 417 195 360 minecraft:polished_deepslate
fill 417 195 361 417 196 363 minecraft:gray_concrete
fill 418 195 323 418 243 323 minecraft:black_concrete
setblock 377 196 323 minecraft:gray_concrete
setblock 377 196 324 minecraft:polished_deepslate
fill 377 196 325 377 196 328 minecraft:gray_concrete
setblock 377 196 329 minecraft:polished_deepslate
fill 377 196 330 377 196 333 minecraft:gray_concrete
setblock 377 196 334 minecraft:polished_deepslate
setblock 377 196 335 minecraft:gray_concrete
setblock 377 196 336 minecraft:yellow_concrete
fill 377 196 337 377 196 338 minecraft:gray_concrete
setblock 377 196 339 minecraft:polished_deepslate
fill 377 196 340 377 199 340 minecraft:gray_concrete
setblock 377 196 343 minecraft:gray_concrete
fill 377 196 352 377 196 353 minecraft:gray_concrete
setblock 377 196 354 minecraft:polished_deepslate
fill 377 196 355 377 196 358 minecraft:gray_concrete
setblock 377 196 359 minecraft:polished_deepslate
fill 377 196 360 377 196 363 minecraft:gray_concrete
setblock 378 196 323 minecraft:polished_deepslate
fill 378 196 324 378 196 327 minecraft:gray_concrete
setblock 378 196 328 minecraft:polished_deepslate
fill 378 196 329 378 196 332 minecraft:gray_concrete
setblock 378 196 333 minecraft:polished_deepslate
fill 378 196 334 378 199 334 minecraft:gray_concrete
fill 378 196 336 378 196 337 minecraft:gray_concrete
setblock 378 196 338 minecraft:polished_deepslate
fill 378 196 339 379 198 339 minecraft:gray_concrete
fill 378 196 341 378 197 341 minecraft:gray_concrete
fill 378 196 354 378 196 357 minecraft:gray_concrete
setblock 378 196 358 minecraft:polished_deepslate
fill 378 196 359 378 196 362 minecraft:gray_concrete
setblock 378 196 363 minecraft:polished_deepslate
fill 379 196 323 381 196 324 minecraft:gray_concrete
fill 379 196 329 379 196 331 minecraft:gray_concrete
setblock 379 196 332 minecraft:polished_deepslate
fill 379 196 333 379 198 333 minecraft:gray_concrete
setblock 379 196 336 minecraft:gray_concrete
setblock 379 196 337 minecraft:polished_deepslate
fill 379 196 338 379 199 338 minecraft:gray_concrete
fill 379 196 355 379 196 356 minecraft:gray_concrete
setblock 379 196 357 minecraft:polished_deepslate
fill 379 196 358 379 199 358 minecraft:gray_concrete
fill 379 196 360 379 196 361 minecraft:gray_concrete
setblock 379 196 362 minecraft:polished_deepslate
fill 379 196 363 382 196 363 minecraft:gray_concrete
setblock 380 196 325 minecraft:gray_concrete
fill 380 196 349 380 200 351 minecraft:black_concrete
fill 380 196 357 380 197 357 minecraft:gray_concrete
setblock 380 196 360 minecraft:gray_concrete
setblock 380 196 361 minecraft:polished_deepslate
fill 380 196 362 383 196 362 minecraft:gray_concrete
setblock 381 196 325 minecraft:polished_deepslate
fill 381 196 347 381 200 347 minecraft:black_concrete
fill 381 196 352 381 200 352 minecraft:black_concrete
setblock 381 196 360 minecraft:polished_deepslate
fill 381 196 361 384 196 361 minecraft:gray_concrete
setblock 382 196 323 minecraft:gray_concrete
setblock 382 196 324 minecraft:polished_deepslate
fill 382 196 360 385 196 360 minecraft:gray_concrete
setblock 383 196 323 minecraft:polished_deepslate
fill 383 196 324 383 199 324 minecraft:gray_concrete
setblock 383 196 363 minecraft:polished_deepslate
fill 384 196 323 387 196 323 minecraft:gray_concrete
fill 384 196 336 384 200 336 minecraft:red_nether_bricks
fill 384 196 340 384 200 340 minecraft:red_nether_bricks
setblock 384 196 362 minecraft:polished_deepslate
fill 384 196 363 387 196 363 minecraft:gray_concrete
fill 385 196 334 385 200 334 minecraft:red_nether_bricks
fill 385 196 342 385 200 342 minecraft:red_nether_bricks
fill 385 196 347 385 200 347 minecraft:black_concrete
fill 385 196 352 385 200 352 minecraft:black_concrete
setblock 385 196 361 minecraft:polished_deepslate
fill 385 196 362 388 196 362 minecraft:gray_concrete
fill 386 196 333 386 200 333 minecraft:red_nether_bricks
fill 386 196 343 386 200 343 minecraft:red_nether_bricks
fill 386 196 348 386 200 351 minecraft:black_concrete
setblock 386 196 360 minecraft:polished_deepslate
fill 386 196 361 386 199 361 minecraft:gray_concrete
fill 387 196 332 387 199 332 minecraft:red_nether_bricks
fill 387 196 344 387 199 344 minecraft:red_nether_bricks
setblock 388 196 323 minecraft:polished_deepslate
fill 388 196 338 388 198 338 minecraft:red_nether_bricks
setblock 388 196 363 minecraft:polished_deepslate
fill 389 196 331 389 199 331 minecraft:red_nether_bricks
fill 389 196 335 389 198 335 minecraft:red_nether_bricks
fill 389 196 341 389 198 341 minecraft:red_nether_bricks
fill 389 196 345 389 199 345 minecraft:red_nether_bricks
setblock 389 196 362 minecraft:polished_deepslate
fill 389 196 363 392 196 363 minecraft:gray_concrete
setblock 390 196 361 minecraft:polished_deepslate
fill 390 196 362 393 196 362 minecraft:gray_concrete
fill 393 196 333 394 198 333 minecraft:red_nether_bricks
fill 393 196 343 394 198 343 minecraft:red_nether_bricks
setblock 393 196 363 minecraft:polished_deepslate
fill 393 196 364 393 201 364 minecraft:black_concrete
setblock 394 196 362 minecraft:polished_deepslate
fill 394 196 363 397 196 363 minecraft:gray_concrete
setblock 395 196 361 minecraft:polished_deepslate
fill 395 196 362 398 196 362 minecraft:gray_concrete
fill 396 196 361 399 196 361 minecraft:gray_concrete
fill 397 196 331 397 199 331 minecraft:red_nether_bricks
setblock 397 196 336 minecraft:nether_bricks
setblock 397 196 340 minecraft:nether_bricks
fill 397 196 345 397 199 345 minecraft:red_nether_bricks
fill 398 196 360 400 196 360 minecraft:gray_concrete
setblock 398 196 363 minecraft:polished_deepslate
fill 399 196 323 402 196 323 minecraft:gray_concrete
fill 399 196 332 399 199 332 minecraft:red_nether_bricks
fill 399 196 344 399 199 344 minecraft:red_nether_bricks
setblock 399 196 362 minecraft:polished_deepslate
fill 399 196 363 402 196 363 minecraft:gray_concrete
fill 400 196 333 400 200 333 minecraft:red_nether_bricks
fill 400 196 343 400 200 343 minecraft:red_nether_bricks
setblock 400 196 361 minecraft:polished_deepslate
fill 400 196 362 403 196 362 minecraft:gray_concrete
setblock 401 196 360 minecraft:polished_deepslate
fill 401 196 361 401 199 361 minecraft:gray_concrete
fill 402 196 360 402 197 360 minecraft:gray_concrete
setblock 403 196 323 minecraft:polished_deepslate
setblock 403 196 363 minecraft:polished_deepslate
fill 404 196 323 404 198 323 minecraft:gray_concrete
setblock 404 196 362 minecraft:polished_deepslate
fill 404 196 363 404 199 363 minecraft:gray_concrete
fill 405 196 362 405 198 362 minecraft:gray_concrete
fill 415 196 333 415 196 335 minecraft:gray_concrete
setblock 415 196 336 minecraft:polished_deepslate
fill 415 196 337 415 199 337 minecraft:gray_concrete
fill 415 196 339 416 196 339 minecraft:gray_concrete
fill 416 196 323 417 196 323 minecraft:gray_concrete
setblock 416 196 329 minecraft:gray_concrete
setblock 416 196 330 minecraft:polished_deepslate
fill 416 196 331 416 196 334 minecraft:gray_concrete
setblock 416 196 335 minecraft:polished_deepslate
fill 416 196 336 416 199 336 minecraft:gray_concrete
setblock 416 196 340 minecraft:polished_deepslate
fill 416 196 341 417 197 342 minecraft:gray_concrete
fill 416 196 363 416 197 363 minecraft:gray_concrete
setblock 417 196 324 minecraft:polished_deepslate
fill 417 196 325 417 196 328 minecraft:gray_concrete
setblock 417 196 329 minecraft:polished_deepslate
fill 417 196 330 417 196 333 minecraft:gray_concrete
setblock 417 196 334 minecraft:polished_deepslate
fill 417 196 335 417 199 335 minecraft:gray_concrete
setblock 417 196 339 minecraft:polished_deepslate
fill 417 196 340 417 199 340 minecraft:gray_concrete
setblock 417 196 343 minecraft:gray_concrete
setblock 417 196 344 minecraft:polished_deepslate
fill 417 196 345 417 199 345 minecraft:gray_concrete
fill 417 196 352 417 196 353 minecraft:gray_concrete
setblock 417 196 354 minecraft:polished_deepslate
fill 417 196 355 417 196 358 minecraft:gray_concrete
setblock 417 196 359 minecraft:polished_deepslate
fill 417 196 360 417 199 360 minecraft:gray_concrete
fill 418 196 347 418 242 349 minecraft:black_concrete
setblock 418 196 350 minecraft:light_blue_stained_glass
fill 418 196 351 418 242 351 minecraft:black_concrete
setblock 377 197 323 minecraft:polished_deepslate
fill 377 197 324 377 197 327 minecraft:gray_concrete
setblock 377 197 328 minecraft:polished_deepslate
fill 377 197 329 377 197 332 minecraft:gray_concrete
setblock 377 197 333 minecraft:polished_deepslate
fill 377 197 334 377 200 334 minecraft:gray_concrete
setblock 377 197 335 minecraft:yellow_concrete
fill 377 197 336 377 197 337 minecraft:gray_concrete
setblock 377 197 338 minecraft:polished_deepslate
fill 377 197 339 377 200 339 minecraft:gray_concrete
setblock 377 197 343 minecraft:polished_deepslate
fill 377 197 344 377 200 344 minecraft:gray_concrete
setblock 377 197 352 minecraft:gray_concrete
setblock 377 197 353 minecraft:polished_deepslate
fill 377 197 354 377 197 357 minecraft:gray_concrete
setblock 377 197 358 minecraft:polished_deepslate
fill 377 197 359 377 197 362 minecraft:gray_concrete
setblock 377 197 363 minecraft:polished_deepslate
fill 378 197 323 378 197 326 minecraft:gray_concrete
setblock 378 197 327 minecraft:polished_deepslate
fill 378 197 328 378 197 331 minecraft:gray_concrete
setblock 378 197 332 minecraft:polished_deepslate
fill 378 197 333 378 200 333 minecraft:gray_concrete
setblock 378 197 336 minecraft:gray_concrete
setblock 378 197 337 minecraft:polished_deepslate
fill 378 197 338 378 200 338 minecraft:gray_concrete
setblock 378 197 342 minecraft:polished_deepslate
fill 378 197 354 378 197 356 minecraft:gray_concrete
setblock 378 197 357 minecraft:polished_deepslate
fill 378 197 358 378 197 361 minecraft:gray_concrete
setblock 378 197 362 minecraft:polished_deepslate
fill 378 197 363 381 197 363 minecraft:gray_concrete
fill 379 197 323 380 197 324 minecraft:gray_concrete
setblock 379 197 331 minecraft:polished_deepslate
setblock 379 197 332 minecraft:gray_concrete
setblock 379 197 336 minecraft:polished_deepslate
fill 379 197 337 379 199 337 minecraft:gray_concrete
setblock 379 197 355 minecraft:gray_concrete
setblock 379 197 356 minecraft:polished_deepslate
fill 379 197 357 379 200 357 minecraft:gray_concrete
setblock 379 197 360 minecraft:gray_concrete
setblock 379 197 361 minecraft:polished_deepslate
fill 379 197 362 382 197 362 minecraft:gray_concrete
setblock 380 197 325 minecraft:polished_deepslate
fill 380 197 348 380 200 348 minecraft:black_concrete
setblock 380 197 360 minecraft:polished_deepslate
fill 380 197 361 383 197 361 minecraft:gray_concrete
setblock 381 197 323 minecraft:gray_concrete
setblock 381 197 324 minecraft:polished_deepslate
setblock 381 197 325 minecraft:gray_concrete
fill 381 197 346 384 200 346 minecraft:black_concrete
fill 381 197 360 384 197 360 minecraft:gray_concrete
fill 381 197 364 385 242 364 minecraft:black_concrete
setblock 382 197 323 minecraft:polished_deepslate
fill 382 197 324 382 200 324 minecraft:gray_concrete
fill 382 197 345 384 198 345 minecraft:white_wool
fill 382 197 353 384 200 353 minecraft:black_concrete
setblock 382 197 363 minecraft:polished_deepslate
fill 383 197 323 386 197 323 minecraft:gray_concrete
fill 383 197 344 383 198 344 minecraft:white_wool
setblock 383 197 362 minecraft:polished_deepslate
fill 383 197 363 386 197 363 minecraft:gray_concrete
fill 384 197 335 384 199 335 minecraft:red_nether_bricks
fill 384 197 341 384 199 341 minecraft:red_nether_bricks
setblock 384 197 361 minecraft:polished_deepslate
fill 384 197 362 387 197 362 minecraft:gray_concrete
setblock 385 197 360 minecraft:polished_deepslate
fill 385 197 361 385 200 361 minecraft:gray_concrete
fill 386 197 352 386 200 352 minecraft:black_concrete
setblock 386 197 360 minecraft:gray_concrete
setblock 386 197 364 minecraft:light_blue_stained_glass
setblock 387 197 323 minecraft:polished_deepslate
fill 387 197 361 388 197 361 minecraft:gray_concrete
setblock 387 197 363 minecraft:polished_deepslate
fill 387 197 364 387 237 364 minecraft:black_concrete
setblock 388 197 323 minecraft:gray_concrete
setblock 388 197 362 minecraft:polished_deepslate
fill 388 197 363 391 197 363 minecraft:gray_concrete
setblock 389 197 361 minecraft:polished_deepslate
fill 389 197 362 392 197 362 minecraft:gray_concrete
setblock 392 197 363 minecraft:polished_deepslate
setblock 393 197 362 minecraft:polished_deepslate
fill 393 197 363 396 197 363 minecraft:gray_concrete
setblock 394 197 361 minecraft:polished_deepslate
fill 394 197 362 397 197 362 minecraft:gray_concrete
fill 395 197 361 398 197 361 minecraft:gray_concrete
setblock 397 197 363 minecraft:polished_deepslate
fill 398 197 323 401 197 323 minecraft:gray_concrete
fill 398 197 360 399 197 360 minecraft:gray_concrete
setblock 398 197 362 minecraft:polished_deepslate
fill 398 197 363 401 197 363 minecraft:gray_concrete
setblock 399 197 361 minecraft:polished_deepslate
fill 399 197 362 402 197 362 minecraft:gray_concrete
setblock 400 197 360 minecraft:polished_deepslate
fill 400 197 361 400 200 361 minecraft:gray_concrete
fill 401 197 360 401 198 360 minecraft:gray_concrete
setblock 402 197 323 minecraft:polished_deepslate
fill 402 197 361 403 197 361 minecraft:gray_concrete
setblock 402 197 363 minecraft:polished_deepslate
fill 403 197 323 403 200 323 minecraft:gray_concrete
setblock 403 197 362 minecraft:polished_deepslate
fill 403 197 363 403 200 363 minecraft:gray_concrete
fill 404 197 336 404 199 336 minecraft:nether_bricks
fill 404 197 340 404 199 340 minecraft:nether_bricks
setblock 404 197 361 minecraft:polished_deepslate
fill 404 197 362 404 199 362 minecraft:gray_concrete
fill 405 197 336 405 198 336 minecraft:black_concrete
fill 405 197 340 405 198 340 minecraft:black_concrete
fill 405 197 363 406 197 363 minecraft:gray_concrete
setblock 407 197 363 minecraft:polished_deepslate
fill 408 197 341 409 198 342 minecraft:gray_wool
fill 409 197 340 409 198 340 minecraft:gray_wool
fill 413 197 324 413 202 324 minecraft:black_concrete
fill 415 197 323 416 197 323 minecraft:gray_concrete
fill 415 197 333 415 197 334 minecraft:gray_concrete
setblock 415 197 335 minecraft:polished_deepslate
fill 415 197 336 415 200 336 minecraft:gray_concrete
fill 415 197 338 415 197 339 minecraft:gray_concrete
setblock 415 197 340 minecraft:polished_deepslate
fill 415 197 363 415 198 363 minecraft:gray_concrete
setblock 416 197 329 minecraft:polished_deepslate
fill 416 197 330 416 197 333 minecraft:gray_concrete
setblock 416 197 334 minecraft:polished_deepslate
fill 416 197 335 416 200 335 minecraft:gray_concrete
setblock 416 197 338 minecraft:gray_concrete
setblock 416 197 339 minecraft:polished_deepslate
fill 416 197 340 416 200 340 minecraft:gray_concrete
setblock 416 197 343 minecraft:gray_concrete
setblock 417 197 323 minecraft:polished_deepslate
fill 417 197 324 417 197 327 minecraft:gray_concrete
setblock 417 197 328 minecraft:polished_deepslate
fill 417 197 329 417 197 332 minecraft:gray_concrete
setblock 417 197 333 minecraft:polished_deepslate
fill 417 197 334 417 200 334 minecraft:gray_concrete
setblock 417 197 338 minecraft:polished_deepslate
fill 417 197 339 417 200 339 minecraft:gray_concrete
setblock 417 197 343 minecraft:polished_deepslate
fill 417 197 344 417 200 344 minecraft:gray_concrete
fill 417 197 346 417 198 346 minecraft:gray_concrete
setblock 417 197 353 minecraft:polished_deepslate
fill 417 197 354 417 197 357 minecraft:gray_concrete
setblock 417 197 358 minecraft:polished_deepslate
fill 417 197 359 417 200 359 minecraft:gray_concrete
fill 417 197 361 417 197 362 minecraft:gray_concrete
setblock 417 197 363 minecraft:polished_deepslate
fill 418 197 341 418 201 343 minecraft:black_concrete
setblock 418 197 344 minecraft:light_blue_stained_glass
fill 418 197 345 418 243 345 minecraft:black_concrete
fill 418 197 350 418 247 350 minecraft:black_concrete
fill 377 198 323 377 198 326 minecraft:gray_concrete
setblock 377 198 327 minecraft:polished_deepslate
fill 377 198 328 377 198 331 minecraft:gray_concrete
setblock 377 198 332 minecraft:polished_deepslate
fill 377 198 333 377 201 333 minecraft:gray_concrete
fill 377 198 335 378 198 335 minecraft:gray_concrete
setblock 377 198 336 minecraft:ochre_froglight
setblock 377 198 337 minecraft:polished_deepslate
fill 377 198 338 377 199 338 minecraft:gray_concrete
setblock 377 198 341 minecraft:gray_concrete
setblock 377 198 342 minecraft:polished_deepslate
fill 377 198 343 377 201 343 minecraft:gray_concrete
fill 377 198 353 377 198 356 minecraft:gray_concrete
setblock 377 198 357 minecraft:polished_deepslate
fill 377 198 358 377 198 361 minecraft:gray_concrete
setblock 377 198 362 minecraft:polished_deepslate
fill 377 198 363 380 198 363 minecraft:gray_concrete
fill 378 198 323 378 198 325 minecraft:gray_concrete
setblock 378 198 326 minecraft:polished_deepslate
fill 378 198 327 378 198 330 minecraft:gray_concrete
setblock 378 198 331 minecraft:polished_deepslate
fill 378 198 332 378 199 332 minecraft:gray_concrete
setblock 378 198 336 minecraft:polished_deepslate
fill 378 198 337 378 201 337 minecraft:gray_concrete
setblock 378 198 341 minecraft:polished_deepslate
fill 378 198 342 378 201 342 minecraft:gray_concrete
fill 378 198 354 378 198 355 minecraft:gray_concrete
setblock 378 198 356 minecraft:polished_deepslate
fill 378 198 357 378 198 360 minecraft:gray_concrete
setblock 378 198 361 minecraft:polished_deepslate
fill 378 198 362 381 198 362 minecraft:gray_concrete
fill 379 198 323 379 198 324 minecraft:gray_concrete
setblock 379 198 325 minecraft:light[level=13]
setblock 379 198 335 minecraft:polished_deepslate
fill 379 198 336 379 199 336 minecraft:gray_concrete
setblock 379 198 341 minecraft:light[level=13]
fill 379 198 348 379 200 351 minecraft:black_concrete
fill 379 198 356 379 199 356 minecraft:gray_concrete
setblock 379 198 359 minecraft:gray_concrete
setblock 379 198 360 minecraft:polished_deepslate
fill 379 198 361 382 198 361 minecraft:gray_concrete
setblock 380 198 323 minecraft:gray_concrete
setblock 380 198 324 minecraft:polished_deepslate
fill 380 198 347 380 200 347 minecraft:black_concrete
fill 380 198 352 380 200 352 minecraft:black_concrete
setblock 380 198 359 minecraft:polished_deepslate
fill 380 198 360 383 198 360 minecraft:gray_concrete
setblock 381 198 323 minecraft:polished_deepslate
fill 381 198 324 381 201 324 minecraft:gray_concrete
fill 381 198 353 381 200 353 minecraft:black_concrete
setblock 381 198 363 minecraft:polished_deepslate
fill 382 198 323 385 198 323 minecraft:gray_concrete
setblock 382 198 362 minecraft:polished_deepslate
fill 382 198 363 385 198 363 minecraft:gray_concrete
setblock 383 198 361 minecraft:polished_deepslate
fill 383 198 362 386 198 362 minecraft:gray_concrete
setblock 384 198 324 minecraft:gray_concrete
setblock 384 198 360 minecraft:polished_deepslate
fill 384 198 361 384 201 361 minecraft:gray_concrete
fill 385 198 346 385 200 346 minecraft:black_concrete
fill 385 198 353 385 200 353 minecraft:black_concrete
setblock 385 198 360 minecraft:gray_concrete
setblock 386 198 323 minecraft:polished_deepslate
fill 386 198 347 386 200 347 minecraft:black_concrete
setblock 386 198 363 minecraft:polished_deepslate
fill 386 198 364 386 209 364 minecraft:black_concrete
fill 387 198 323 387 199 323 minecraft:gray_concrete
setblock 387 198 325 minecraft:light[level=13]
fill 387 198 348 387 200 351 minecraft:black_concrete
setblock 387 198 357 minecraft:light[level=13]
setblock 387 198 361 minecraft:gray_concrete
setblock 387 198 362 minecraft:polished_deepslate
fill 387 198 363 390 198 363 minecraft:gray_concrete
setblock 388 198 361 minecraft:polished_deepslate
fill 388 198 362 391 198 362 minecraft:gray_concrete
setblock 389 198 361 minecraft:gray_concrete
setblock 391 198 363 minecraft:polished_deepslate
setblock 392 198 362 minecraft:polished_deepslate
fill 392 198 363 395 198 363 minecraft:gray_concrete
fill 393 198 362 396 198 362 minecraft:gray_concrete
fill 394 198 361 397 198 361 minecraft:gray_concrete
setblock 395 198 325 minecraft:light[level=13]
setblock 395 198 349 minecraft:light[level=13]
setblock 395 198 357 minecraft:light[level=13]
setblock 396 198 363 minecraft:polished_deepslate
fill 397 198 323 400 198 323 minecraft:gray_concrete
setblock 397 198 335 minecraft:red_nether_bricks
setblock 397 198 341 minecraft:red_nether_bricks
setblock 397 198 362 minecraft:polished_deepslate
fill 397 198 363 400 198 363 minecraft:gray_concrete
setblock 398 198 360 minecraft:gray_concrete
setblock 398 198 361 minecraft:polished_deepslate
fill 398 198 362 401 198 362 minecraft:gray_concrete
fill 399 198 334 401 200 334 minecraft:red_nether_bricks
fill 399 198 342 401 200 342 minecraft:red_nether_bricks
setblock 399 198 360 minecraft:polished_deepslate
fill 399 198 361 399 201 361 minecraft:gray_concrete
setblock 400 198 360 minecraft:gray_concrete
setblock 401 198 323 minecraft:polished_deepslate
setblock 401 198 363 minecraft:polished_deepslate
fill 402 198 323 402 201 323 minecraft:gray_concrete
setblock 402 198 361 minecraft:gray_concrete
setblock 402 198 362 minecraft:polished_deepslate
fill 402 198 363 402 201 363 minecraft:gray_concrete
setblock 403 198 325 minecraft:light[level=13]
setblock 403 198 333 minecraft:light[level=13]
setblock 403 198 349 minecraft:light[level=13]
setblock 403 198 357 minecraft:light[level=13]
setblock 403 198 361 minecraft:polished_deepslate
fill 403 198 362 403 200 362 minecraft:gray_concrete
setblock 405 198 363 minecraft:gray_concrete
setblock 406 198 337 minecraft:nether_bricks
setblock 406 198 339 minecraft:nether_bricks
setblock 406 198 363 minecraft:polished_deepslate
setblock 407 198 363 minecraft:gray_concrete
setblock 411 198 325 minecraft:light[level=13]
setblock 411 198 333 minecraft:light[level=13]
setblock 411 198 341 minecraft:light[level=13]
setblock 411 198 349 minecraft:light[level=13]
setblock 411 198 357 minecraft:light[level=13]
fill 414 198 323 415 198 323 minecraft:gray_concrete
fill 414 198 363 414 199 363 minecraft:gray_concrete
setblock 415 198 334 minecraft:polished_deepslate
fill 415 198 335 415 199 335 minecraft:gray_concrete
setblock 415 198 338 minecraft:gray_concrete
setblock 415 198 339 minecraft:polished_deepslate
fill 415 198 340 415 201 340 minecraft:gray_concrete
setblock 416 198 323 minecraft:polished_deepslate
fill 416 198 329 416 198 332 minecraft:gray_concrete
setblock 416 198 333 minecraft:polished_deepslate
fill 416 198 334 416 201 334 minecraft:gray_concrete
setblock 416 198 337 minecraft:gray_concrete
setblock 416 198 338 minecraft:polished_deepslate
fill 416 198 339 416 201 339 minecraft:gray_concrete
fill 416 198 341 416 198 342 minecraft:gray_concrete
setblock 416 198 343 minecraft:polished_deepslate
fill 416 198 359 416 198 362 minecraft:gray_concrete
setblock 416 198 363 minecraft:polished_deepslate
fill 417 198 323 417 198 326 minecraft:gray_concrete
setblock 417 198 327 minecraft:polished_deepslate
fill 417 198 328 417 198 331 minecraft:gray_concrete
setblock 417 198 332 minecraft:polished_deepslate
fill 417 198 333 417 201 333 minecraft:gray_concrete
setblock 417 198 337 minecraft:polished_deepslate
fill 417 198 338 417 201 338 minecraft:gray_concrete
setblock 417 198 341 minecraft:gray_concrete
setblock 417 198 342 minecraft:polished_deepslate
fill 417 198 343 417 201 343 minecraft:gray_concrete
fill 417 198 354 417 198 356 minecraft:gray_concrete
setblock 417 198 357 minecraft:polished_deepslate
fill 417 198 358 417 201 358 minecraft:gray_concrete
setblock 417 198 361 minecraft:gray_concrete
setblock 417 198 362 minecraft:polished_deepslate
fill 417 198 363 417 201 363 minecraft:gray_concrete
fill 418 198 344 418 246 344 minecraft:black_concrete
fill 377 199 323 377 199 325 minecraft:gray_concrete
setblock 377 199 326 minecraft:polished_deepslate
fill 377 199 327 377 199 330 minecraft:gray_concrete
setblock 377 199 331 minecraft:polished_deepslate
fill 377 199 332 377 202 332 minecraft:gray_concrete
setblock 377 199 335 minecraft:gray_concrete
setblock 377 199 336 minecraft:polished_deepslate
setblock 377 199 337 minecraft:yellow_concrete
setblock 377 199 341 minecraft:polished_deepslate
fill 377 199 342 377 202 342 minecraft:gray_concrete
setblock 377 199 345 minecraft:gray_concrete
fill 377 199 353 377 199 355 minecraft:gray_concrete
setblock 377 199 356 minecraft:polished_deepslate
fill 377 199 357 377 199 360 minecraft:gray_concrete
setblock 377 199 361 minecraft:polished_deepslate
fill 377 199 362 379 199 363 minecraft:gray_concrete
fill 378 199 323 378 199 324 minecraft:gray_concrete
setblock 378 199 325 minecraft:polished_deepslate
fill 378 199 326 378 199 329 minecraft:gray_concrete
setblock 378 199 330 minecraft:polished_deepslate
setblock 378 199 331 minecraft:gray_concrete
setblock 378 199 335 minecraft:polished_deepslate
fill 378 199 336 378 201 336 minecraft:gray_concrete
setblock 378 199 339 minecraft:gray_concrete
setblock 378 199 340 minecraft:polished_deepslate
fill 378 199 341 378 202 341 minecraft:gray_concrete
setblock 378 199 355 minecraft:polished_deepslate
fill 378 199 356 378 199 359 minecraft:gray_concrete
setblock 378 199 360 minecraft:polished_deepslate
fill 378 199 361 381 199 361 minecraft:gray_concrete
setblock 379 199 323 minecraft:gray_concrete
setblock 379 199 324 minecraft:polished_deepslate
setblock 379 199 339 minecraft:polished_deepslate
fill 379 199 347 379 200 347 minecraft:black_concrete
fill 379 199 352 379 200 352 minecraft:black_concrete
setblock 379 199 359 minecraft:polished_deepslate
fill 379 199 360 382 199 360 minecraft:gray_concrete
setblock 380 199 323 minecraft:polished_deepslate
fill 380 199 324 380 202 324 minecraft:gray_concrete
fill 380 199 346 380 200 346 minecraft:black_concrete
fill 380 199 353 380 200 353 minecraft:black_concrete
setblock 380 199 358 minecraft:polished_deepslate
fill 380 199 359 380 200 359 minecraft:gray_concrete
setblock 380 199 362 minecraft:gray_concrete
setblock 380 199 363 minecraft:polished_deepslate
fill 381 199 323 384 199 323 minecraft:gray_concrete
setblock 381 199 362 minecraft:polished_deepslate
fill 381 199 363 384 199 363 minecraft:gray_concrete
fill 382 199 345 384 200 345 minecraft:black_concrete
fill 382 199 354 385 200 354 minecraft:black_concrete
setblock 382 199 361 minecraft:polished_deepslate
fill 382 199 362 385 199 362 minecraft:gray_concrete
setblock 383 199 360 minecraft:polished_deepslate
fill 383 199 361 383 202 361 minecraft:gray_concrete
setblock 384 199 360 minecraft:gray_concrete
setblock 385 199 323 minecraft:polished_deepslate
setblock 385 199 363 minecraft:polished_deepslate
fill 386 199 323 386 200 323 minecraft:gray_concrete
fill 386 199 346 386 200 346 minecraft:black_concrete
fill 386 199 353 386 200 353 minecraft:black_concrete
setblock 386 199 362 minecraft:polished_deepslate
fill 386 199 363 389 199 363 minecraft:gray_concrete
fill 387 199 347 387 200 347 minecraft:black_concrete
fill 387 199 352 387 200 352 minecraft:black_concrete
setblock 387 199 361 minecraft:polished_deepslate
fill 387 199 362 390 199 362 minecraft:gray_concrete
fill 388 199 334 389 200 334 minecraft:red_nether_bricks
setblock 388 199 336 minecraft:red_nether_bricks
setblock 388 199 340 minecraft:red_nether_bricks
fill 388 199 342 389 200 342 minecraft:red_nether_bricks
fill 389 199 333 391 199 333 minecraft:red_nether_bricks
fill 389 199 343 391 199 343 minecraft:red_nether_bricks
setblock 390 199 363 minecraft:polished_deepslate
setblock 391 199 362 minecraft:polished_deepslate
fill 391 199 363 394 199 363 minecraft:gray_concrete
fill 392 199 362 395 199 362 minecraft:gray_concrete
fill 394 199 361 396 199 361 minecraft:gray_concrete
setblock 395 199 363 minecraft:polished_deepslate
setblock 396 199 362 minecraft:polished_deepslate
fill 396 199 363 399 199 363 minecraft:gray_concrete
fill 397 199 323 399 199 323 minecraft:gray_concrete
fill 397 199 334 398 200 334 minecraft:red_nether_bricks
fill 397 199 342 398 200 342 minecraft:red_nether_bricks
setblock 397 199 361 minecraft:polished_deepslate
fill 397 199 362 400 199 362 minecraft:gray_concrete
fill 398 199 335 399 201 335 minecraft:red_nether_bricks
setblock 398 199 336 minecraft:nether_bricks
setblock 398 199 340 minecraft:nether_bricks
fill 398 199 341 399 201 341 minecraft:red_nether_bricks
fill 398 199 361 398 202 361 minecraft:gray_concrete
fill 399 199 337 404 199 337 minecraft:nether_bricks
fill 399 199 339 404 199 339 minecraft:nether_bricks
setblock 400 199 323 minecraft:polished_deepslate
fill 400 199 335 402 199 335 minecraft:nether_bricks
fill 400 199 341 402 199 341 minecraft:nether_bricks
setblock 400 199 363 minecraft:polished_deepslate
fill 401 199 323 401 202 323 minecraft:gray_concrete
setblock 401 199 362 minecraft:polished_deepslate
fill 401 199 363 401 202 363 minecraft:gray_concrete
setblock 402 199 361 minecraft:polished_deepslate
fill 402 199 362 402 201 362 minecraft:gray_concrete
setblock 405 199 338 minecraft:nether_bricks
setblock 405 199 363 minecraft:polished_deepslate
setblock 406 199 363 minecraft:gray_concrete
setblock 414 199 323 minecraft:gray_concrete
setblock 415 199 323 minecraft:polished_deepslate
setblock 415 199 338 minecraft:polished_deepslate
fill 415 199 339 415 202 339 minecraft:gray_concrete
setblock 415 199 363 minecraft:polished_deepslate
fill 416 199 323 417 200 324 minecraft:gray_concrete
fill 416 199 330 416 199 331 minecraft:gray_concrete
setblock 416 199 332 minecraft:polished_deepslate
fill 416 199 333 416 202 333 minecraft:gray_concrete
setblock 416 199 337 minecraft:polished_deepslate
fill 416 199 338 416 202 338 minecraft:gray_concrete
setblock 416 199 341 minecraft:gray_concrete
setblock 416 199 342 minecraft:polished_deepslate
fill 416 199 343 416 202 343 minecraft:gray_concrete
fill 416 199 360 416 199 361 minecraft:gray_concrete
setblock 416 199 362 minecraft:polished_deepslate
fill 416 199 363 416 202 363 minecraft:gray_concrete
setblock 417 199 325 minecraft:gray_concrete
setblock 417 199 326 minecraft:polished_deepslate
fill 417 199 327 417 199 330 minecraft:gray_concrete
setblock 417 199 331 minecraft:polished_deepslate
fill 417 199 332 417 202 332 minecraft:gray_concrete
setblock 417 199 336 minecraft:polished_deepslate
fill 417 199 337 417 202 337 minecraft:gray_concrete
setblock 417 199 341 minecraft:polished_deepslate
fill 417 199 342 417 202 342 minecraft:gray_concrete
setblock 417 199 346 minecraft:polished_deepslate
setblock 417 199 355 minecraft:gray_concrete
setblock 417 199 356 minecraft:polished_deepslate
fill 417 199 357 417 202 357 minecraft:gray_concrete
setblock 417 199 361 minecraft:polished_deepslate
fill 417 199 362 417 202 362 minecraft:gray_concrete
fill 377 200 323 377 200 324 minecraft:gray_concrete
setblock 377 200 325 minecraft:polished_deepslate
fill 377 200 326 377 200 329 minecraft:gray_concrete
setblock 377 200 330 minecraft:polished_deepslate
fill 377 200 331 377 203 331 minecraft:gray_concrete
setblock 377 200 335 minecraft:polished_deepslate
fill 377 200 336 377 200 337 minecraft:gray_concrete
setblock 377 200 338 minecraft:yellow_concrete
setblock 377 200 340 minecraft:polished_deepslate
fill 377 200 341 377 203 341 minecraft:gray_concrete
setblock 377 200 345 minecraft:polished_deepslate
setblock 377 200 354 minecraft:gray_concrete
setblock 377 200 355 minecraft:polished_deepslate
fill 377 200 356 377 200 359 minecraft:gray_concrete
setblock 377 200 360 minecraft:polished_deepslate
fill 377 200 361 378 200 363 minecraft:gray_concrete
setblock 378 200 323 minecraft:gray_concrete
setblock 378 200 324 minecraft:polished_deepslate
fill 378 200 325 378 200 328 minecraft:gray_concrete
setblock 378 200 334 minecraft:polished_deepslate
fill 378 200 335 378 201 335 minecraft:gray_concrete
setblock 378 200 339 minecraft:polished_deepslate
fill 378 200 340 378 203 340 minecraft:gray_concrete
fill 378 200 348 378 200 351 minecraft:black_concrete
fill 378 200 355 378 200 358 minecraft:gray_concrete
setblock 378 200 359 minecraft:polished_deepslate
fill 378 200 360 381 200 360 minecraft:gray_concrete
setblock 379 200 323 minecraft:polished_deepslate
fill 379 200 324 379 203 324 minecraft:gray_concrete
setblock 379 200 325 minecraft:light[level=12]
setblock 379 200 332 minecraft:light[level=12]
setblock 379 200 339 minecraft:light[level=12]
setblock 379 200 346 minecraft:light[level=12]
setblock 379 200 353 minecraft:black_concrete
setblock 379 200 358 minecraft:polished_deepslate
fill 379 200 359 379 203 359 minecraft:gray_concrete
fill 379 200 361 379 200 362 minecraft:gray_concrete
setblock 379 200 363 minecraft:polished_deepslate
fill 380 200 323 383 200 323 minecraft:gray_concrete
setblock 380 200 361 minecraft:gray_concrete
setblock 380 200 362 minecraft:polished_deepslate
fill 380 200 363 383 200 363 minecraft:gray_concrete
setblock 381 200 345 minecraft:black_concrete
setblock 381 200 354 minecraft:black_concrete
setblock 381 200 361 minecraft:polished_deepslate
fill 381 200 362 384 200 362 minecraft:gray_concrete
setblock 382 200 360 minecraft:polished_deepslate
fill 382 200 361 382 203 361 minecraft:gray_concrete
setblock 383 200 324 minecraft:polished_deepslate
setblock 384 200 323 minecraft:polished_deepslate
setblock 384 200 363 minecraft:polished_deepslate
fill 385 200 323 385 203 323 minecraft:gray_concrete
setblock 385 200 345 minecraft:black_concrete
fill 385 200 356 386 201 356 minecraft:light_gray_wool
setblock 385 200 362 minecraft:polished_deepslate
fill 385 200 363 388 200 363 minecraft:gray_concrete
setblock 386 200 325 minecraft:light[level=12]
setblock 386 200 332 minecraft:light[level=12]
setblock 386 200 354 minecraft:black_concrete
setblock 386 200 360 minecraft:light[level=12]
setblock 386 200 361 minecraft:polished_deepslate
fill 386 200 362 389 200 362 minecraft:gray_concrete
setblock 387 200 346 minecraft:black_concrete
setblock 387 200 353 minecraft:black_concrete
fill 388 200 348 388 200 351 minecraft:black_concrete
fill 389 200 333 390 201 333 minecraft:red_nether_bricks
fill 389 200 343 390 201 343 minecraft:red_nether_bricks
setblock 389 200 363 minecraft:polished_deepslate
setblock 390 200 331 minecraft:red_nether_bricks
setblock 390 200 345 minecraft:red_nether_bricks
setblock 390 200 362 minecraft:polished_deepslate
fill 390 200 363 393 200 363 minecraft:gray_concrete
setblock 391 200 331 minecraft:black_concrete
setblock 391 200 345 minecraft:black_concrete
fill 391 200 362 394 200 362 minecraft:gray_concrete
fill 392 200 331 396 200 331 minecraft:red_nether_bricks
fill 392 200 345 396 200 345 minecraft:red_nether_bricks
setblock 393 200 325 minecraft:light[level=12]
setblock 393 200 346 minecraft:light[level=12]
setblock 393 200 353 minecraft:light[level=12]
setblock 393 200 360 minecraft:light[level=12]
setblock 394 200 363 minecraft:polished_deepslate
setblock 395 200 361 minecraft:gray_concrete
setblock 395 200 362 minecraft:polished_deepslate
fill 395 200 363 398 200 363 minecraft:gray_concrete
fill 396 200 323 398 200 323 minecraft:gray_concrete
fill 396 200 333 397 200 333 minecraft:red_nether_bricks
fill 396 200 343 397 200 343 minecraft:red_nether_bricks
setblock 396 200 361 minecraft:polished_deepslate
fill 396 200 362 399 200 362 minecraft:gray_concrete
fill 397 200 361 397 202 361 minecraft:gray_concrete
setblock 399 200 323 minecraft:polished_deepslate
fill 399 200 336 399 201 340 minecraft:red_nether_bricks
setblock 399 200 363 minecraft:polished_deepslate
fill 400 200 323 400 203 323 minecraft:gray_concrete
setblock 400 200 325 minecraft:light[level=12]
setblock 400 200 332 minecraft:light[level=12]
fill 400 200 335 401 201 337 minecraft:red_nether_bricks
fill 400 200 338 402 200 338 minecraft:nether_bricks
fill 400 200 339 401 201 341 minecraft:red_nether_bricks
setblock 400 200 346 minecraft:light[level=12]
setblock 400 200 353 minecraft:light[level=12]
setblock 400 200 360 minecraft:light[level=12]
setblock 400 200 362 minecraft:polished_deepslate
fill 400 200 363 400 203 363 minecraft:gray_concrete
setblock 401 200 361 minecraft:polished_deepslate
fill 401 200 362 401 202 362 minecraft:gray_concrete
fill 402 200 336 402 200 337 minecraft:red_nether_bricks
fill 402 200 339 402 200 340 minecraft:red_nether_bricks
setblock 404 200 363 minecraft:polished_deepslate
setblock 405 200 363 minecraft:gray_concrete
setblock 407 200 325 minecraft:light[level=12]
setblock 407 200 332 minecraft:light[level=12]
setblock 407 200 339 minecraft:light[level=12]
setblock 407 200 346 minecraft:light[level=12]
setblock 407 200 353 minecraft:light[level=12]
setblock 407 200 360 minecraft:light[level=12]
fill 412 200 324 412 202 324 minecraft:black_concrete
setblock 413 200 323 minecraft:gray_concrete
fill 413 200 325 413 202 325 minecraft:black_concrete
setblock 414 200 323 minecraft:polished_deepslate
fill 414 200 324 414 201 324 minecraft:black_concrete
setblock 414 200 325 minecraft:light[level=12]
setblock 414 200 332 minecraft:light[level=12]
setblock 414 200 339 minecraft:light[level=12]
setblock 414 200 346 minecraft:light[level=12]
setblock 414 200 353 minecraft:light[level=12]
setblock 414 200 360 minecraft:light[level=12]
setblock 414 200 363 minecraft:polished_deepslate
fill 415 200 323 415 203 323 minecraft:gray_concrete
setblock 415 200 337 minecraft:polished_deepslate
fill 415 200 338 415 201 338 minecraft:gray_concrete
fill 415 200 363 415 203 363 minecraft:gray_concrete
setblock 416 200 325 minecraft:gray_concrete
setblock 416 200 331 minecraft:polished_deepslate
fill 416 200 332 416 201 332 minecraft:gray_concrete
setblock 416 200 336 minecraft:polished_deepslate
fill 416 200 337 416 203 337 minecraft:gray_concrete
setblock 416 200 341 minecraft:polished_deepslate
fill 416 200 342 416 203 342 minecraft:gray_concrete
setblock 416 200 360 minecraft:gray_concrete
setblock 416 200 361 minecraft:polished_deepslate
fill 416 200 362 416 203 362 minecraft:gray_concrete
setblock 417 200 325 minecraft:polished_deepslate
fill 417 200 326 417 200 329 minecraft:gray_concrete
setblock 417 200 330 minecraft:polished_deepslate
fill 417 200 331 417 203 331 minecraft:gray_concrete
setblock 417 200 335 minecraft:polished_deepslate
fill 417 200 336 417 203 336 minecraft:gray_concrete
setblock 417 200 340 minecraft:polished_deepslate
fill 417 200 341 417 203 341 minecraft:gray_concrete
setblock 417 200 345 minecraft:polished_deepslate
fill 417 200 346 417 203 346 minecraft:gray_concrete
setblock 417 200 356 minecraft:gray_concrete
setblock 417 200 360 minecraft:polished_deepslate
fill 417 200 361 417 203 361 minecraft:gray_concrete
setblock 377 201 323 minecraft:gray_concrete
setblock 377 201 324 minecraft:polished_deepslate
fill 377 201 325 377 201 328 minecraft:gray_concrete
setblock 377 201 329 minecraft:polished_deepslate
fill 377 201 330 377 204 330 minecraft:gray_concrete
setblock 377 201 334 minecraft:polished_deepslate
fill 377 201 335 377 201 336 minecraft:gray_concrete
setblock 377 201 337 minecraft:yellow_concrete
setblock 377 201 338 minecraft:gray_concrete
setblock 377 201 339 minecraft:polished_deepslate
fill 377 201 340 377 204 340 minecraft:gray_concrete
setblock 377 201 344 minecraft:polished_deepslate
fill 377 201 345 377 204 345 minecraft:gray_concrete
setblock 377 201 354 minecraft:polished_deepslate
fill 377 201 355 377 201 358 minecraft:gray_concrete
setblock 377 201 359 minecraft:polished_deepslate
fill 377 201 360 377 201 363 minecraft:gray_concrete
setblock 378 201 323 minecraft:polished_deepslate
fill 378 201 324 378 201 327 minecraft:gray_concrete
fill 378 201 328 380 203 328 minecraft:light_blue_stained_glass
setblock 378 201 338 minecraft:polished_deepslate
fill 378 201 339 378 202 339 minecraft:gray_concrete
fill 378 201 356 378 201 357 minecraft:gray_concrete
setblock 378 201 358 minecraft:polished_deepslate
fill 378 201 359 378 201 362 minecraft:gray_concrete
setblock 378 201 363 minecraft:polished_deepslate
fill 379 201 323 382 201 323 minecraft:gray_concrete
setblock 379 201 358 minecraft:gray_concrete
fill 379 201 360 379 201 361 minecraft:gray_concrete
setblock 379 201 362 minecraft:polished_deepslate
fill 379 201 363 382 201 363 minecraft:gray_concrete
setblock 380 201 360 minecraft:gray_concrete
setblock 380 201 361 minecraft:polished_deepslate
fill 380 201 362 383 201 362 minecraft:gray_concrete
fill 381 201 346 381 207 346 minecraft:black_concrete
fill 381 201 361 381 204 361 minecraft:gray_concrete
setblock 382 201 324 minecraft:polished_deepslate
fill 382 201 349 384 201 350 minecraft:light_blue_stained_glass
setblock 383 201 323 minecraft:polished_deepslate
setblock 383 201 363 minecraft:polished_deepslate
fill 384 201 323 384 204 323 minecraft:gray_concrete
setblock 384 201 362 minecraft:polished_deepslate
fill 384 201 363 387 201 363 minecraft:gray_concrete
setblock 385 201 361 minecraft:polished_deepslate
fill 385 201 362 388 201 362 minecraft:gray_concrete
fill 388 201 330 391 201 330 minecraft:black_concrete
fill 388 201 334 388 202 334 minecraft:red_nether_bricks
fill 388 201 342 388 202 342 minecraft:red_nether_bricks
fill 388 201 346 391 201 346 minecraft:black_concrete
setblock 388 201 363 minecraft:polished_deepslate
setblock 389 201 362 minecraft:polished_deepslate
fill 389 201 363 392 201 363 minecraft:gray_concrete
fill 390 201 362 393 201 362 minecraft:gray_concrete
fill 392 201 331 394 201 331 minecraft:red_nether_bricks
fill 392 201 345 394 201 345 minecraft:red_nether_bricks
setblock 393 201 363 minecraft:polished_deepslate
setblock 394 201 362 minecraft:polished_deepslate
fill 394 201 363 397 201 363 minecraft:gray_concrete
setblock 395 201 361 minecraft:polished_deepslate
fill 395 201 362 398 201 362 minecraft:gray_concrete
fill 396 201 323 397 201 323 minecraft:gray_concrete
setblock 396 201 333 minecraft:shroomlight
setblock 396 201 343 minecraft:shroomlight
setblock 396 201 361 minecraft:gray_concrete
setblock 397 201 333 minecraft:red_nether_bricks
setblock 397 201 343 minecraft:red_nether_bricks
setblock 398 201 323 minecraft:polished_deepslate
fill 398 201 334 400 201 334 minecraft:red_nether_bricks
fill 398 201 342 400 201 342 minecraft:red_nether_bricks
setblock 398 201 363 minecraft:polished_deepslate
fill 399 201 323 399 204 323 minecraft:gray_concrete
setblock 399 201 362 minecraft:polished_deepslate
fill 399 201 363 399 204 363 minecraft:gray_concrete
fill 400 201 338 401 202 338 minecraft:red_nether_bricks
setblock 400 201 361 minecraft:polished_deepslate
fill 400 201 362 400 204 362 minecraft:gray_concrete
setblock 403 201 363 minecraft:polished_deepslate
fill 404 201 363 404 202 363 minecraft:gray_concrete
setblock 412 201 323 minecraft:black_concrete
fill 412 201 325 412 202 325 minecraft:black_concrete
setblock 413 201 323 minecraft:polished_deepslate
setblock 413 201 363 minecraft:polished_deepslate
fill 414 201 323 414 204 323 minecraft:gray_concrete
fill 414 201 325 414 202 325 minecraft:black_concrete
fill 414 201 363 414 204 363 minecraft:gray_concrete
fill 415 201 324 416 201 324 minecraft:gray_concrete
setblock 415 201 337 minecraft:gray_concrete
fill 416 201 323 417 201 323 minecraft:gray_concrete
setblock 416 201 325 minecraft:polished_deepslate
fill 416 201 326 417 203 326 minecraft:gray_concrete
setblock 416 201 335 minecraft:polished_deepslate
fill 416 201 336 416 204 336 minecraft:gray_concrete
setblock 416 201 340 minecraft:polished_deepslate
fill 416 201 341 416 204 341 minecraft:gray_concrete
setblock 416 201 344 minecraft:gray_concrete
fill 416 201 361 416 204 361 minecraft:gray_concrete
setblock 417 201 324 minecraft:polished_deepslate
fill 417 201 325 417 204 325 minecraft:gray_concrete
fill 417 201 327 417 201 328 minecraft:gray_concrete
setblock 417 201 329 minecraft:polished_deepslate
fill 417 201 330 417 204 330 minecraft:gray_concrete
setblock 417 201 334 minecraft:polished_deepslate
fill 417 201 335 417 204 335 minecraft:gray_concrete
setblock 417 201 339 minecraft:polished_deepslate
fill 417 201 340 417 204 340 minecraft:gray_concrete
setblock 417 201 344 minecraft:polished_deepslate
fill 417 201 345 417 204 345 minecraft:gray_concrete
setblock 417 201 359 minecraft:polished_deepslate
fill 417 201 360 417 204 360 minecraft:gray_concrete
setblock 377 202 323 minecraft:polished_deepslate
fill 377 202 324 377 202 327 minecraft:gray_concrete
setblock 377 202 328 minecraft:polished_deepslate
fill 377 202 329 377 205 329 minecraft:gray_concrete
setblock 377 202 333 minecraft:polished_deepslate
fill 377 202 334 377 202 335 minecraft:gray_concrete
setblock 377 202 336 minecraft:yellow_concrete
setblock 377 202 337 minecraft:gray_concrete
setblock 377 202 338 minecraft:polished_deepslate
fill 377 202 339 377 205 339 minecraft:gray_concrete
setblock 377 202 343 minecraft:polished_deepslate
fill 377 202 344 377 205 344 minecraft:gray_concrete
fill 377 202 346 377 203 346 minecraft:gray_concrete
fill 377 202 355 377 202 357 minecraft:gray_concrete
setblock 377 202 358 minecraft:polished_deepslate
fill 377 202 359 377 202 362 minecraft:gray_concrete
setblock 377 202 363 minecraft:polished_deepslate
fill 378 202 323 378 202 326 minecraft:gray_concrete
setblock 378 202 327 minecraft:polished_deepslate
fill 378 202 329 381 203 329 minecraft:light_blue_stained_glass
setblock 378 202 338 minecraft:gray_concrete
setblock 378 202 342 minecraft:polished_deepslate
fill 378 202 343 378 205 343 minecraft:gray_concrete
setblock 378 202 357 minecraft:polished_deepslate
fill 378 202 358 378 202 361 minecraft:gray_concrete
setblock 378 202 362 minecraft:polished_deepslate
fill 378 202 363 381 202 363 minecraft:gray_concrete
fill 379 202 323 381 202 323 minecraft:gray_concrete
fill 379 202 327 381 203 327 minecraft:light_blue_stained_glass
setblock 379 202 360 minecraft:gray_concrete
setblock 379 202 361 minecraft:polished_deepslate
fill 379 202 362 382 202 362 minecraft:gray_concrete
fill 380 202 361 380 205 361 minecraft:gray_concrete
setblock 381 202 324 minecraft:polished_deepslate
fill 381 202 328 384 203 328 minecraft:light_blue_stained_glass
setblock 382 202 323 minecraft:polished_deepslate
fill 382 202 324 382 204 324 minecraft:gray_concrete
setblock 382 202 363 minecraft:polished_deepslate
fill 383 202 323 383 205 323 minecraft:gray_concrete
fill 383 202 349 383 202 350 minecraft:light_blue_stained_glass
setblock 383 202 362 minecraft:polished_deepslate
fill 383 202 363 386 202 363 minecraft:gray_concrete
fill 384 202 362 387 202 362 minecraft:gray_concrete
fill 385 202 328 387 202 328 minecraft:black_concrete
fill 385 202 338 386 202 338 minecraft:red_nether_bricks
fill 385 202 348 387 202 348 minecraft:black_concrete
fill 386 202 329 390 202 329 minecraft:black_concrete
fill 386 202 336 387 202 337 minecraft:red_nether_bricks
fill 386 202 339 387 202 340 minecraft:red_nether_bricks
fill 386 202 347 390 202 347 minecraft:black_concrete
setblock 387 202 335 minecraft:red_nether_bricks
setblock 387 202 341 minecraft:red_nether_bricks
fill 387 202 358 387 212 358 minecraft:black_concrete
setblock 387 202 363 minecraft:polished_deepslate
setblock 388 202 362 minecraft:polished_deepslate
fill 388 202 363 391 202 363 minecraft:gray_concrete
fill 389 202 330 390 203 330 minecraft:white_wool
setblock 389 202 333 minecraft:red_nether_bricks
setblock 389 202 343 minecraft:red_nether_bricks
setblock 391 202 330 minecraft:black_concrete
fill 391 202 332 392 202 332 minecraft:red_nether_bricks
fill 391 202 344 392 202 344 minecraft:red_nether_bricks
setblock 391 202 346 minecraft:black_concrete
fill 391 202 362 392 202 362 minecraft:gray_concrete
setblock 392 202 363 minecraft:polished_deepslate
setblock 393 202 362 minecraft:polished_deepslate
fill 393 202 363 396 202 363 minecraft:gray_concrete
setblock 393 202 364 minecraft:light_blue_stained_glass
fill 394 202 332 395 202 332 minecraft:red_nether_bricks
fill 394 202 344 395 202 344 minecraft:red_nether_bricks
fill 394 202 362 397 202 362 minecraft:gray_concrete
fill 395 202 323 396 202 323 minecraft:gray_concrete
setblock 397 202 323 minecraft:polished_deepslate
setblock 397 202 333 minecraft:shroomlight
setblock 397 202 343 minecraft:shroomlight
setblock 397 202 363 minecraft:polished_deepslate
fill 398 202 323 398 205 323 minecraft:gray_concrete
fill 398 202 334 399 202 334 minecraft:red_nether_bricks
fill 398 202 342 399 202 342 minecraft:red_nether_bricks
setblock 398 202 362 minecraft:polished_deepslate
fill 398 202 363 398 205 363 minecraft:gray_concrete
fill 399 202 335 400 202 337 minecraft:red_nether_bricks
fill 399 202 339 400 202 341 minecraft:red_nether_bricks
fill 399 202 343 401 203 346 minecraft:polished_deepslate
fill 399 202 362 399 205 362 minecraft:gray_concrete
setblock 402 202 323 minecraft:polished_deepslate
fill 402 202 344 402 231 344 minecraft:polished_deepslate
setblock 402 202 363 minecraft:polished_deepslate
fill 403 202 363 403 203 363 minecraft:gray_concrete
setblock 411 202 324 minecraft:black_concrete
setblock 412 202 323 minecraft:polished_deepslate
fill 413 202 323 413 205 323 minecraft:gray_concrete
setblock 413 202 326 minecraft:black_concrete
fill 413 202 363 413 205 363 minecraft:gray_concrete
fill 414 202 324 415 202 324 minecraft:gray_concrete
fill 415 202 362 415 204 362 minecraft:gray_concrete
setblock 416 202 323 minecraft:gray_concrete
setblock 416 202 324 minecraft:polished_deepslate
fill 416 202 325 416 205 325 minecraft:gray_concrete
fill 416 202 327 416 202 328 minecraft:gray_concrete
setblock 416 202 334 minecraft:polished_deepslate
fill 416 202 335 416 205 335 minecraft:gray_concrete
setblock 416 202 339 minecraft:polished_deepslate
fill 416 202 340 416 205 340 minecraft:gray_concrete
setblock 416 202 344 minecraft:polished_deepslate
setblock 417 202 323 minecraft:polished_deepslate
fill 417 202 324 417 205 324 minecraft:gray_concrete
setblock 417 202 327 minecraft:gray_concrete
setblock 417 202 328 minecraft:polished_deepslate
fill 417 202 329 417 205 329 minecraft:gray_concrete
setblock 417 202 333 minecraft:polished_deepslate
fill 417 202 334 417 205 334 minecraft:gray_concrete
setblock 417 202 338 minecraft:polished_deepslate
fill 417 202 339 417 205 339 minecraft:gray_concrete
setblock 417 202 343 minecraft:polished_deepslate
fill 417 202 344 417 205 344 minecraft:gray_concrete
setblock 417 202 347 minecraft:gray_concrete
setblock 417 202 358 minecraft:polished_deepslate
fill 417 202 359 417 205 359 minecraft:gray_concrete
setblock 417 202 363 minecraft:polished_deepslate
setblock 418 202 341 minecraft:light_blue_stained_glass
fill 418 202 342 418 246 343 minecraft:black_concrete
fill 377 203 323 377 203 326 minecraft:gray_concrete
setblock 377 203 327 minecraft:polished_deepslate
fill 377 203 328 377 206 328 minecraft:gray_concrete
setblock 377 203 332 minecraft:polished_deepslate
fill 377 203 333 377 203 334 minecraft:gray_concrete
setblock 377 203 335 minecraft:ochre_froglight
setblock 377 203 336 minecraft:gray_concrete
setblock 377 203 337 minecraft:polished_deepslate
fill 377 203 338 377 206 338 minecraft:gray_concrete
setblock 377 203 342 minecraft:polished_deepslate
fill 377 203 343 377 206 343 minecraft:gray_concrete
setblock 377 203 347 minecraft:polished_deepslate
fill 377 203 355 377 203 356 minecraft:gray_concrete
setblock 377 203 357 minecraft:polished_deepslate
fill 377 203 358 377 203 361 minecraft:gray_concrete
setblock 377 203 362 minecraft:polished_deepslate
fill 377 203 363 380 203 363 minecraft:gray_concrete
fill 378 203 323 378 203 325 minecraft:gray_concrete
setblock 378 203 326 minecraft:polished_deepslate
fill 378 203 327 378 206 327 minecraft:gray_concrete
setblock 378 203 341 minecraft:polished_deepslate
fill 378 203 342 378 206 342 minecraft:gray_concrete
fill 378 203 357 378 203 360 minecraft:gray_concrete
setblock 378 203 361 minecraft:polished_deepslate
fill 378 203 362 381 203 362 minecraft:gray_concrete
fill 379 203 323 380 203 323 minecraft:gray_concrete
setblock 379 203 360 minecraft:polished_deepslate
fill 379 203 361 379 206 361 minecraft:gray_concrete
setblock 380 203 324 minecraft:polished_deepslate
fill 380 203 346 380 207 346 minecraft:black_concrete
setblock 381 203 323 minecraft:polished_deepslate
fill 381 203 324 381 206 324 minecraft:gray_concrete
fill 381 203 345 381 207 345 minecraft:black_concrete
fill 381 203 347 381 207 347 minecraft:black_concrete
setblock 381 203 363 minecraft:polished_deepslate
fill 382 203 323 382 206 323 minecraft:gray_concrete
fill 382 203 346 382 207 346 minecraft:black_concrete
setblock 382 203 362 minecraft:polished_deepslate
fill 382 203 363 385 203 363 minecraft:gray_concrete
setblock 383 203 327 minecraft:black_concrete
setblock 383 203 349 minecraft:black_concrete
fill 383 203 350 383 204 350 minecraft:light_blue_stained_glass
fill 383 203 362 386 203 362 minecraft:gray_concrete
setblock 386 203 327 minecraft:black_concrete
setblock 386 203 349 minecraft:black_concrete
setblock 386 203 363 minecraft:polished_deepslate
fill 387 203 328 388 203 328 minecraft:black_concrete
fill 387 203 348 388 203 348 minecraft:black_concrete
fill 387 203 363 390 203 363 minecraft:gray_concrete
fill 389 203 329 390 203 329 minecraft:white_wool
setblock 390 203 328 minecraft:black_concrete
setblock 390 203 348 minecraft:black_concrete
setblock 391 203 329 minecraft:black_concrete
setblock 391 203 330 minecraft:white_wool
setblock 391 203 347 minecraft:black_concrete
setblock 391 203 362 minecraft:gray_concrete
setblock 391 203 363 minecraft:polished_deepslate
setblock 392 203 362 minecraft:polished_deepslate
fill 392 203 363 395 203 363 minecraft:gray_concrete
fill 393 203 362 396 203 362 minecraft:gray_concrete
fill 393 203 364 393 246 364 minecraft:black_concrete
fill 394 203 323 395 203 323 minecraft:gray_concrete
setblock 396 203 323 minecraft:polished_deepslate
fill 396 203 344 398 204 344 minecraft:polished_deepslate
setblock 396 203 363 minecraft:polished_deepslate
fill 397 203 323 397 206 323 minecraft:gray_concrete
fill 397 203 343 398 203 343 minecraft:polished_deepslate
setblock 397 203 362 minecraft:polished_deepslate
fill 397 203 363 397 206 363 minecraft:gray_concrete
setblock 398 203 342 minecraft:polished_deepslate
fill 398 203 345 398 205 346 minecraft:black_concrete
fill 398 203 362 398 206 362 minecraft:gray_concrete
fill 399 203 342 401 204 342 minecraft:black_concrete
fill 400 203 347 400 204 347 minecraft:black_concrete
setblock 401 203 323 minecraft:polished_deepslate
setblock 401 203 363 minecraft:polished_deepslate
fill 402 203 323 402 206 323 minecraft:gray_concrete
fill 402 203 343 402 204 343 minecraft:black_concrete
fill 402 203 345 402 204 346 minecraft:black_concrete
fill 402 203 363 402 205 363 minecraft:gray_concrete
setblock 411 203 323 minecraft:polished_deepslate
fill 412 203 323 412 206 323 minecraft:gray_concrete
fill 412 203 363 412 206 363 minecraft:gray_concrete
setblock 414 203 324 minecraft:gray_concrete
setblock 415 203 324 minecraft:polished_deepslate
setblock 416 203 323 minecraft:polished_deepslate
fill 416 203 324 416 206 324 minecraft:gray_concrete
setblock 416 203 327 minecraft:gray_concrete
setblock 416 203 328 minecraft:polished_deepslate
fill 416 203 329 416 206 329 minecraft:gray_concrete
fill 416 203 334 416 206 334 minecraft:gray_concrete
setblock 416 203 338 minecraft:polished_deepslate
fill 416 203 339 416 206 339 minecraft:gray_concrete
setblock 416 203 343 minecraft:polished_deepslate
fill 416 203 344 416 206 344 minecraft:gray_concrete
setblock 416 203 363 minecraft:polished_deepslate
fill 417 203 323 417 206 323 minecraft:gray_concrete
setblock 417 203 327 minecraft:polished_deepslate
fill 417 203 328 417 206 328 minecraft:gray_concrete
setblock 417 203 332 minecraft:polished_deepslate
fill 417 203 333 417 206 333 minecraft:gray_concrete
setblock 417 203 337 minecraft:polished_deepslate
fill 417 203 338 417 206 338 minecraft:gray_concrete
setblock 417 203 342 minecraft:polished_deepslate
fill 417 203 343 417 206 343 minecraft:gray_concrete
setblock 417 203 347 minecraft:polished_deepslate
fill 417 203 358 417 206 358 minecraft:gray_concrete
setblock 417 203 362 minecraft:polished_deepslate
fill 417 203 363 417 206 363 minecraft:gray_concrete
fill 418 203 341 418 242 341 minecraft:black_concrete
fill 377 204 323 377 204 325 minecraft:gray_concrete
setblock 377 204 326 minecraft:polished_deepslate
fill 377 204 327 377 207 327 minecraft:gray_concrete
setblock 377 204 331 minecraft:polished_deepslate
setblock 377 204 335 minecraft:gray_concrete
setblock 377 204 336 minecraft:polished_deepslate
fill 377 204 337 377 207 337 minecraft:gray_concrete
setblock 377 204 341 minecraft:polished_deepslate
fill 377 204 342 377 207 342 minecraft:gray_concrete
setblock 377 204 346 minecraft:polished_deepslate
fill 377 204 347 377 206 348 minecraft:gray_concrete
setblock 377 204 355 minecraft:gray_concrete
setblock 377 204 356 minecraft:polished_deepslate
fill 377 204 357 377 204 360 minecraft:gray_concrete
setblock 377 204 361 minecraft:polished_deepslate
fill 377 204 362 379 204 363 minecraft:gray_concrete
fill 378 204 323 378 204 324 minecraft:gray_concrete
setblock 378 204 325 minecraft:polished_deepslate
fill 378 204 326 378 207 326 minecraft:gray_concrete
fill 378 204 328 379 204 328 minecraft:light_blue_stained_glass
fill 378 204 341 378 205 341 minecraft:gray_concrete
setblock 378 204 344 minecraft:gray_concrete
fill 378 204 357 378 204 359 minecraft:gray_concrete
setblock 378 204 360 minecraft:polished_deepslate
fill 378 204 361 378 207 361 minecraft:gray_concrete
setblock 379 204 323 minecraft:gray_concrete
setblock 379 204 324 minecraft:polished_deepslate
fill 379 204 325 380 204 325 minecraft:black_concrete
fill 379 204 351 380 204 351 minecraft:black_concrete
fill 379 204 360 379 206 360 minecraft:gray_concrete
setblock 380 204 323 minecraft:polished_deepslate
fill 380 204 324 380 207 324 minecraft:gray_concrete
fill 380 204 326 381 204 326 minecraft:black_concrete
fill 380 204 350 381 204 350 minecraft:black_concrete
setblock 380 204 362 minecraft:gray_concrete
setblock 380 204 363 minecraft:polished_deepslate
fill 381 204 323 381 207 323 minecraft:gray_concrete
setblock 381 204 362 minecraft:polished_deepslate
fill 381 204 363 384 204 363 minecraft:gray_concrete
fill 382 204 362 385 204 362 minecraft:gray_concrete
fill 384 204 326 385 204 326 minecraft:black_concrete
fill 384 204 350 385 204 350 minecraft:black_concrete
setblock 385 204 323 minecraft:polished_deepslate
setblock 385 204 363 minecraft:polished_deepslate
fill 386 204 363 389 204 363 minecraft:gray_concrete
setblock 387 204 327 minecraft:black_concrete
setblock 387 204 349 minecraft:black_concrete
fill 389 204 327 389 205 327 minecraft:black_concrete
fill 389 204 349 389 205 349 minecraft:black_concrete
setblock 390 204 363 minecraft:polished_deepslate
fill 391 204 328 391 205 328 minecraft:black_concrete
fill 391 204 348 391 205 348 minecraft:black_concrete
setblock 391 204 362 minecraft:polished_deepslate
fill 391 204 363 394 204 363 minecraft:gray_concrete
fill 392 204 362 395 204 362 minecraft:gray_concrete
fill 393 204 323 394 204 323 minecraft:gray_concrete
setblock 395 204 322 minecraft:light_blue_stained_glass
setblock 395 204 323 minecraft:polished_deepslate
setblock 395 204 363 minecraft:polished_deepslate
fill 396 204 323 396 207 323 minecraft:gray_concrete
fill 396 204 345 397 205 345 minecraft:black_concrete
setblock 396 204 362 minecraft:polished_deepslate
fill 396 204 363 396 207 363 minecraft:gray_concrete
fill 397 204 346 397 205 346 minecraft:black_concrete
fill 397 204 362 397 207 362 minecraft:gray_concrete
fill 398 204 343 398 205 343 minecraft:polished_deepslate
fill 398 204 347 399 204 347 minecraft:black_concrete
fill 399 204 343 399 205 344 minecraft:black_concrete
fill 399 204 345 401 204 346 minecraft:polished_deepslate
setblock 400 204 323 minecraft:polished_deepslate
setblock 400 204 341 minecraft:black_concrete
fill 400 204 343 401 204 344 minecraft:polished_deepslate
setblock 400 204 363 minecraft:polished_deepslate
fill 401 204 323 401 207 323 minecraft:gray_concrete
fill 401 204 347 402 204 347 minecraft:black_concrete
fill 401 204 363 401 207 363 minecraft:gray_concrete
setblock 402 204 342 minecraft:black_concrete
fill 403 204 343 403 204 346 minecraft:black_concrete
setblock 410 204 323 minecraft:polished_deepslate
fill 411 204 323 411 207 323 minecraft:gray_concrete
fill 412 204 324 413 204 324 minecraft:gray_concrete
setblock 414 204 324 minecraft:polished_deepslate
setblock 415 204 323 minecraft:polished_deepslate
fill 415 204 324 415 206 325 minecraft:gray_concrete
setblock 415 204 363 minecraft:polished_deepslate
fill 416 204 323 416 207 323 minecraft:gray_concrete
setblock 416 204 326 minecraft:gray_concrete
setblock 416 204 327 minecraft:polished_deepslate
fill 416 204 328 416 207 328 minecraft:gray_concrete
fill 416 204 330 416 205 330 minecraft:gray_concrete
setblock 416 204 337 minecraft:polished_deepslate
fill 416 204 338 416 207 338 minecraft:gray_concrete
setblock 416 204 342 minecraft:polished_deepslate
fill 416 204 343 416 207 343 minecraft:gray_concrete
fill 416 204 345 416 205 345 minecraft:gray_concrete
setblock 416 204 362 minecraft:polished_deepslate
fill 416 204 363 416 207 363 minecraft:gray_concrete
setblock 417 204 326 minecraft:polished_deepslate
fill 417 204 327 417 207 327 minecraft:gray_concrete
setblock 417 204 331 minecraft:polished_deepslate
fill 417 204 332 417 207 332 minecraft:gray_concrete
setblock 417 204 336 minecraft:polished_deepslate
fill 417 204 337 417 207 337 minecraft:gray_concrete
setblock 417 204 341 minecraft:polished_deepslate
fill 417 204 342 417 207 342 minecraft:gray_concrete
setblock 417 204 346 minecraft:polished_deepslate
fill 417 204 347 417 206 348 minecraft:gray_concrete
setblock 417 204 361 minecraft:polished_deepslate
fill 417 204 362 417 207 362 minecraft:gray_concrete
setblock 376 205 328 minecraft:light_blue_stained_glass
fill 377 205 323 377 205 324 minecraft:gray_concrete
setblock 377 205 325 minecraft:polished_deepslate
fill 377 205 326 377 208 326 minecraft:gray_concrete
setblock 377 205 330 minecraft:polished_deepslate
fill 377 205 331 377 208 331 minecraft:gray_concrete
setblock 377 205 336 minecraft:gray_concrete
setblock 377 205 340 minecraft:polished_deepslate
fill 377 205 341 377 208 341 minecraft:gray_concrete
setblock 377 205 345 minecraft:polished_deepslate
fill 377 205 346 378 207 346 minecraft:gray_concrete
setblock 377 205 349 minecraft:gray_concrete
setblock 377 205 350 minecraft:polished_deepslate
fill 377 205 351 377 205 354 minecraft:gray_concrete
setblock 377 205 355 minecraft:polished_deepslate
fill 377 205 356 377 205 359 minecraft:gray_concrete
setblock 377 205 360 minecraft:polished_deepslate
fill 377 205 361 377 206 363 minecraft:gray_concrete
setblock 378 205 323 minecraft:gray_concrete
setblock 378 205 324 minecraft:polished_deepslate
fill 378 205 325 378 208 325 minecraft:gray_concrete
setblock 378 205 344 minecraft:polished_deepslate
fill 378 205 345 378 208 345 minecraft:gray_concrete
fill 378 205 357 378 205 358 minecraft:gray_concrete
setblock 378 205 359 minecraft:polished_deepslate
fill 378 205 360 378 208 360 minecraft:gray_concrete
fill 378 205 362 378 205 363 minecraft:gray_concrete
setblock 379 205 323 minecraft:polished_deepslate
fill 379 205 324 379 208 324 minecraft:gray_concrete
setblock 379 205 325 minecraft:black_concrete
setblock 379 205 351 minecraft:black_concrete
setblock 379 205 362 minecraft:gray_concrete
setblock 379 205 363 minecraft:polished_deepslate
fill 380 205 323 380 208 323 minecraft:gray_concrete
setblock 380 205 362 minecraft:polished_deepslate
fill 380 205 363 383 205 363 minecraft:gray_concrete
setblock 381 205 361 minecraft:polished_deepslate
fill 381 205 362 384 205 362 minecraft:gray_concrete
fill 382 205 324 382 206 324 minecraft:black_concrete
fill 382 205 352 382 206 352 minecraft:black_concrete
setblock 383 205 325 minecraft:black_concrete
setblock 383 205 351 minecraft:black_concrete
setblock 384 205 323 minecraft:polished_deepslate
setblock 384 205 363 minecraft:polished_deepslate
fill 385 205 323 385 208 323 minecraft:gray_concrete
setblock 385 205 362 minecraft:polished_deepslate
fill 385 205 363 388 205 363 minecraft:gray_concrete
fill 386 205 326 386 206 326 minecraft:black_concrete
fill 386 205 350 386 206 350 minecraft:black_concrete
fill 388 205 332 388 205 333 minecraft:blackstone
fill 388 205 343 388 205 344 minecraft:blackstone
fill 389 205 326 389 206 326 minecraft:black_concrete
setblock 389 205 332 minecraft:blackstone
setblock 389 205 344 minecraft:blackstone
fill 389 205 350 389 206 350 minecraft:black_concrete
setblock 389 205 363 minecraft:polished_deepslate
fill 390 205 363 393 205 363 minecraft:gray_concrete
fill 391 205 323 393 205 323 minecraft:gray_concrete
fill 391 205 327 391 206 327 minecraft:black_concrete
fill 391 205 349 391 206 349 minecraft:black_concrete
fill 391 205 362 394 205 362 minecraft:gray_concrete
setblock 394 205 323 minecraft:polished_deepslate
setblock 394 205 363 minecraft:polished_deepslate
fill 395 205 322 395 233 322 minecraft:black_concrete
fill 395 205 323 395 208 323 minecraft:gray_concrete
setblock 395 205 345 minecraft:black_concrete
setblock 395 205 362 minecraft:polished_deepslate
fill 395 205 363 395 208 363 minecraft:gray_concrete
setblock 396 205 346 minecraft:black_concrete
fill 396 205 362 396 208 362 minecraft:gray_concrete
setblock 397 205 324 minecraft:gray_concrete
fill 397 205 344 398 205 344 minecraft:polished_deepslate
setblock 399 205 323 minecraft:polished_deepslate
fill 399 205 342 400 205 342 minecraft:black_concrete
setblock 399 205 345 minecraft:black_concrete
fill 399 205 346 401 232 346 minecraft:polished_deepslate
setblock 399 205 363 minecraft:polished_deepslate
fill 400 205 323 400 208 323 minecraft:gray_concrete
fill 400 205 343 400 205 344 minecraft:black_concrete
fill 400 205 345 401 232 345 minecraft:polished_deepslate
fill 400 205 363 400 208 363 minecraft:gray_concrete
fill 401 205 343 401 232 344 minecraft:polished_deepslate
setblock 403 205 323 minecraft:gray_concrete
fill 406 205 322 408 221 322 minecraft:black_concrete
setblock 408 205 323 minecraft:gray_concrete
setblock 409 205 322 minecraft:light_blue_stained_glass
setblock 409 205 323 minecraft:polished_deepslate
fill 410 205 322 416 208 322 minecraft:black_concrete
fill 410 205 323 410 208 323 minecraft:gray_concrete
fill 411 205 324 412 205 324 minecraft:gray_concrete
fill 411 205 363 411 207 363 minecraft:gray_concrete
setblock 413 205 324 minecraft:polished_deepslate
setblock 414 205 323 minecraft:polished_deepslate
fill 414 205 324 414 207 325 minecraft:gray_concrete
setblock 414 205 362 minecraft:gray_concrete
setblock 414 205 363 minecraft:polished_deepslate
fill 415 205 323 415 208 323 minecraft:gray_concrete
setblock 415 205 326 minecraft:gray_concrete
setblock 415 205 327 minecraft:polished_deepslate
setblock 415 205 362 minecraft:polished_deepslate
fill 415 205 363 415 208 363 minecraft:gray_concrete
setblock 416 205 326 minecraft:polished_deepslate
fill 416 205 327 416 208 327 minecraft:gray_concrete
setblock 416 205 331 minecraft:polished_deepslate
fill 416 205 332 416 207 333 minecraft:gray_concrete
setblock 416 205 336 minecraft:polished_deepslate
fill 416 205 337 416 208 337 minecraft:gray_concrete
setblock 416 205 341 minecraft:polished_deepslate
fill 416 205 342 416 208 342 minecraft:gray_concrete
setblock 416 205 346 minecraft:polished_deepslate
setblock 416 205 361 minecraft:polished_deepslate
fill 416 205 362 416 208 362 minecraft:gray_concrete
setblock 417 205 325 minecraft:polished_deepslate
fill 417 205 326 417 208 326 minecraft:gray_concrete
setblock 417 205 330 minecraft:polished_deepslate
fill 417 205 331 417 208 331 minecraft:gray_concrete
setblock 417 205 335 minecraft:polished_deepslate
fill 417 205 336 417 208 336 minecraft:gray_concrete
setblock 417 205 340 minecraft:polished_deepslate
fill 417 205 341 417 208 341 minecraft:gray_concrete
setblock 417 205 345 minecraft:polished_deepslate
fill 417 205 346 417 208 346 minecraft:gray_concrete
setblock 417 205 349 minecraft:gray_concrete
setblock 417 205 360 minecraft:polished_deepslate
fill 417 205 361 417 208 361 minecraft:gray_concrete
fill 418 205 327 418 246 327 minecraft:black_concrete
setblock 418 205 328 minecraft:light_blue_stained_glass
fill 418 205 329 418 246 330 minecraft:black_concrete
fill 418 205 358 418 205 361 minecraft:black_concrete
setblock 418 205 362 minecraft:light_blue_stained_glass
fill 376 206 328 376 244 328 minecraft:black_concrete
setblock 377 206 323 minecraft:gray_concrete
setblock 377 206 324 minecraft:polished_deepslate
fill 377 206 325 377 209 325 minecraft:gray_concrete
setblock 377 206 329 minecraft:polished_deepslate
fill 377 206 330 377 209 330 minecraft:gray_concrete
fill 377 206 332 377 207 332 minecraft:gray_concrete
setblock 377 206 339 minecraft:polished_deepslate
fill 377 206 340 377 209 340 minecraft:gray_concrete
setblock 377 206 344 minecraft:polished_deepslate
fill 377 206 345 377 209 345 minecraft:gray_concrete
setblock 377 206 349 minecraft:polished_deepslate
fill 377 206 350 377 206 353 minecraft:gray_concrete
setblock 377 206 354 minecraft:polished_deepslate
fill 377 206 355 377 206 358 minecraft:gray_concrete
setblock 377 206 359 minecraft:polished_deepslate
fill 377 206 360 377 209 360 minecraft:gray_concrete
setblock 378 206 323 minecraft:polished_deepslate
fill 378 206 324 378 209 324 minecraft:gray_concrete
setblock 378 206 328 minecraft:polished_deepslate
setblock 378 206 343 minecraft:polished_deepslate
fill 378 206 344 378 209 344 minecraft:gray_concrete
setblock 378 206 347 minecraft:gray_concrete
setblock 378 206 348 minecraft:polished_deepslate
setblock 378 206 357 minecraft:gray_concrete
setblock 378 206 358 minecraft:polished_deepslate
fill 378 206 359 378 209 359 minecraft:gray_concrete
setblock 378 206 362 minecraft:gray_concrete
setblock 378 206 363 minecraft:polished_deepslate
fill 379 206 323 379 209 323 minecraft:gray_concrete
fill 379 206 325 379 207 325 minecraft:gray_concrete
setblock 379 206 332 minecraft:light[level=12]
setblock 379 206 333 minecraft:light[level=13]
setblock 379 206 339 minecraft:light[level=12]
setblock 379 206 341 minecraft:light[level=13]
setblock 379 206 346 minecraft:light[level=12]
setblock 379 206 349 minecraft:light[level=13]
setblock 379 206 353 minecraft:light[level=12]
setblock 379 206 357 minecraft:light[level=13]
setblock 379 206 362 minecraft:polished_deepslate
fill 379 206 363 382 206 363 minecraft:gray_concrete
fill 380 206 345 380 207 345 minecraft:black_concrete
fill 380 206 347 380 207 347 minecraft:black_concrete
setblock 380 206 361 minecraft:polished_deepslate
fill 380 206 362 383 206 362 minecraft:gray_concrete
fill 382 206 345 382 207 345 minecraft:black_concrete
fill 382 206 347 382 207 347 minecraft:black_concrete
setblock 383 206 323 minecraft:polished_deepslate
setblock 383 206 363 minecraft:polished_deepslate
fill 384 206 323 384 209 323 minecraft:gray_concrete
setblock 384 206 362 minecraft:polished_deepslate
fill 384 206 363 387 206 363 minecraft:gray_concrete
fill 385 206 325 385 207 325 minecraft:black_concrete
fill 385 206 351 385 207 351 minecraft:black_concrete
fill 386 206 323 386 207 323 minecraft:gray_concrete
setblock 386 206 325 minecraft:light[level=12]
setblock 386 206 332 minecraft:light[level=12]
setblock 386 206 346 minecraft:light[level=12]
setblock 386 206 353 minecraft:light[level=12]
setblock 386 206 360 minecraft:light[level=12]
setblock 387 206 325 minecraft:light[level=13]
fill 387 206 332 388 207 332 minecraft:blackstone
setblock 387 206 333 minecraft:light[level=13]
fill 387 206 344 388 207 344 minecraft:blackstone
setblock 387 206 349 minecraft:light[level=13]
setblock 387 206 357 minecraft:light[level=13]
setblock 388 206 363 minecraft:polished_deepslate
fill 389 206 323 392 206 323 minecraft:gray_concrete
fill 389 206 363 392 206 363 minecraft:gray_concrete
fill 390 206 362 393 206 362 minecraft:gray_concrete
setblock 393 206 323 minecraft:polished_deepslate
setblock 393 206 325 minecraft:light[level=12]
setblock 393 206 346 minecraft:light[level=12]
setblock 393 206 353 minecraft:light[level=12]
setblock 393 206 360 minecraft:light[level=12]
setblock 393 206 363 minecraft:polished_deepslate
fill 394 206 323 394 208 324 minecraft:gray_concrete
setblock 394 206 362 minecraft:polished_deepslate
fill 394 206 363 394 209 363 minecraft:gray_concrete
fill 395 206 324 396 206 324 minecraft:gray_concrete
setblock 395 206 325 minecraft:light[level=13]
setblock 395 206 349 minecraft:light[level=13]
setblock 395 206 357 minecraft:light[level=13]
fill 395 206 362 395 209 362 minecraft:gray_concrete
setblock 397 206 324 minecraft:polished_deepslate
setblock 398 206 323 minecraft:polished_deepslate
fill 398 206 324 399 208 324 minecraft:gray_concrete
fill 398 206 344 400 207 344 minecraft:polished_deepslate
setblock 398 206 363 minecraft:polished_deepslate
fill 399 206 323 399 209 323 minecraft:gray_concrete
fill 399 206 343 400 207 343 minecraft:polished_deepslate
fill 399 206 345 399 228 345 minecraft:polished_deepslate
fill 399 206 363 399 209 363 minecraft:gray_concrete
setblock 400 206 325 minecraft:light[level=12]
setblock 400 206 332 minecraft:light[level=12]
setblock 400 206 353 minecraft:light[level=12]
setblock 400 206 360 minecraft:light[level=12]
setblock 403 206 323 minecraft:polished_deepslate
setblock 403 206 325 minecraft:light[level=13]
setblock 403 206 333 minecraft:light[level=13]
setblock 403 206 341 minecraft:light[level=13]
setblock 403 206 349 minecraft:light[level=13]
setblock 403 206 357 minecraft:light[level=13]
fill 404 206 323 407 206 323 minecraft:gray_concrete
fill 405 206 355 405 207 355 minecraft:light_blue_stained_glass
setblock 407 206 325 minecraft:light[level=12]
setblock 407 206 332 minecraft:light[level=12]
setblock 407 206 339 minecraft:light[level=12]
setblock 407 206 346 minecraft:light[level=12]
setblock 407 206 353 minecraft:light[level=12]
setblock 407 206 360 minecraft:light[level=12]
setblock 408 206 323 minecraft:polished_deepslate
setblock 409 206 322 minecraft:black_concrete
fill 409 206 323 409 209 323 minecraft:gray_concrete
setblock 409 206 364 minecraft:light_blue_stained_glass
fill 410 206 324 411 206 324 minecraft:gray_concrete
fill 410 206 363 410 208 363 minecraft:gray_concrete
setblock 411 206 325 minecraft:light[level=13]
setblock 411 206 333 minecraft:light[level=13]
setblock 411 206 341 minecraft:light[level=13]
setblock 411 206 349 minecraft:light[level=13]
setblock 411 206 357 minecraft:light[level=13]
setblock 412 206 324 minecraft:polished_deepslate
fill 412 206 325 413 208 325 minecraft:gray_concrete
setblock 413 206 323 minecraft:polished_deepslate
fill 413 206 324 413 209 324 minecraft:gray_concrete
setblock 413 206 363 minecraft:polished_deepslate
fill 414 206 323 414 209 323 minecraft:gray_concrete
setblock 414 206 332 minecraft:light[level=12]
setblock 414 206 339 minecraft:light[level=12]
setblock 414 206 346 minecraft:light[level=12]
setblock 414 206 353 minecraft:light[level=12]
setblock 414 206 360 minecraft:light[level=12]
setblock 414 206 362 minecraft:polished_deepslate
fill 414 206 363 414 209 363 minecraft:gray_concrete
setblock 415 206 326 minecraft:polished_deepslate
fill 415 206 327 415 208 328 minecraft:gray_concrete
fill 415 206 342 415 208 343 minecraft:gray_concrete
fill 415 206 362 415 209 362 minecraft:gray_concrete
setblock 416 206 325 minecraft:polished_deepslate
fill 416 206 326 416 209 326 minecraft:gray_concrete
setblock 416 206 330 minecraft:polished_deepslate
fill 416 206 331 416 209 331 minecraft:gray_concrete
setblock 416 206 335 minecraft:polished_deepslate
fill 416 206 336 416 209 336 minecraft:gray_concrete
setblock 416 206 340 minecraft:polished_deepslate
fill 416 206 341 416 209 341 minecraft:gray_concrete
setblock 416 206 345 minecraft:polished_deepslate
fill 416 206 346 416 208 347 minecraft:gray_concrete
setblock 416 206 360 minecraft:polished_deepslate
fill 416 206 361 416 209 361 minecraft:gray_concrete
setblock 417 206 324 minecraft:polished_deepslate
fill 417 206 325 417 209 325 minecraft:gray_concrete
setblock 417 206 329 minecraft:polished_deepslate
fill 417 206 330 417 209 330 minecraft:gray_concrete
setblock 417 206 334 minecraft:polished_deepslate
fill 417 206 335 417 209 335 minecraft:gray_concrete
setblock 417 206 339 minecraft:polished_deepslate
fill 417 206 340 417 209 340 minecraft:gray_concrete
setblock 417 206 344 minecraft:polished_deepslate
fill 417 206 345 417 209 345 minecraft:gray_concrete
setblock 417 206 349 minecraft:polished_deepslate
fill 417 206 350 417 209 350 minecraft:gray_concrete
fill 417 206 357 417 207 357 minecraft:gray_concrete
setblock 417 206 359 minecraft:polished_deepslate
fill 417 206 360 417 209 360 minecraft:gray_concrete
fill 418 206 328 418 246 328 minecraft:black_concrete
fill 418 206 358 418 243 359 minecraft:black_concrete
setblock 418 206 360 minecraft:light_blue_stained_glass
fill 418 206 361 418 246 362 minecraft:black_concrete
fill 377 207 322 378 227 322 minecraft:black_concrete
setblock 377 207 323 minecraft:polished_deepslate
fill 377 207 324 377 210 324 minecraft:gray_concrete
setblock 377 207 328 minecraft:polished_deepslate
fill 377 207 329 377 210 329 minecraft:gray_concrete
setblock 377 207 338 minecraft:polished_deepslate
fill 377 207 339 377 209 339 minecraft:gray_concrete
setblock 377 207 343 minecraft:polished_deepslate
fill 377 207 344 377 210 344 minecraft:gray_concrete
setblock 377 207 347 minecraft:gray_concrete
setblock 377 207 348 minecraft:polished_deepslate
fill 377 207 349 377 207 352 minecraft:gray_concrete
setblock 377 207 353 minecraft:polished_deepslate
fill 377 207 354 377 207 357 minecraft:gray_concrete
setblock 377 207 358 minecraft:polished_deepslate
fill 377 207 359 377 210 359 minecraft:gray_concrete
fill 377 207 361 377 207 362 minecraft:gray_concrete
setblock 377 207 363 minecraft:polished_deepslate
fill 378 207 323 378 210 323 minecraft:gray_concrete
setblock 378 207 327 minecraft:polished_deepslate
fill 378 207 328 378 210 328 minecraft:gray_concrete
setblock 378 207 342 minecraft:polished_deepslate
fill 378 207 343 378 210 343 minecraft:gray_concrete
setblock 378 207 347 minecraft:polished_deepslate
fill 378 207 348 378 208 350 minecraft:gray_concrete
setblock 378 207 357 minecraft:polished_deepslate
fill 378 207 358 378 210 358 minecraft:gray_concrete
setblock 378 207 362 minecraft:polished_deepslate
fill 378 207 363 381 207 363 minecraft:gray_concrete
setblock 379 207 322 minecraft:light_blue_stained_glass
setblock 379 207 361 minecraft:polished_deepslate
fill 379 207 362 382 207 362 minecraft:gray_concrete
fill 380 207 322 382 223 322 minecraft:black_concrete
setblock 380 207 361 minecraft:gray_concrete
setblock 381 207 324 minecraft:polished_deepslate
setblock 382 207 323 minecraft:polished_deepslate
fill 382 207 324 382 209 324 minecraft:gray_concrete
setblock 382 207 363 minecraft:polished_deepslate
fill 383 207 323 383 210 323 minecraft:gray_concrete
setblock 383 207 362 minecraft:polished_deepslate
fill 383 207 363 386 207 363 minecraft:gray_concrete
setblock 384 207 362 minecraft:gray_concrete
setblock 387 207 323 minecraft:polished_deepslate
fill 387 207 331 388 207 331 minecraft:blackstone
fill 387 207 345 388 207 345 minecraft:blackstone
setblock 387 207 363 minecraft:polished_deepslate
fill 388 207 323 391 207 323 minecraft:gray_concrete
fill 388 207 324 388 207 325 minecraft:black_concrete
fill 388 207 351 388 207 352 minecraft:black_concrete
fill 388 207 363 391 207 363 minecraft:gray_concrete
setblock 388 207 364 minecraft:light_blue_stained_glass
fill 390 207 362 392 207 362 minecraft:gray_concrete
setblock 391 207 326 minecraft:black_concrete
setblock 391 207 350 minecraft:black_concrete
setblock 392 207 323 minecraft:polished_deepslate
fill 392 207 324 393 209 324 minecraft:gray_concrete
setblock 392 207 363 minecraft:polished_deepslate
fill 393 207 323 393 210 323 minecraft:gray_concrete
setblock 393 207 362 minecraft:polished_deepslate
fill 393 207 363 393 210 363 minecraft:gray_concrete
fill 394 207 362 394 210 362 minecraft:gray_concrete
setblock 395 207 324 minecraft:gray_concrete
setblock 396 207 324 minecraft:polished_deepslate
setblock 397 207 323 minecraft:polished_deepslate
fill 397 207 324 397 210 324 minecraft:gray_concrete
setblock 397 207 363 minecraft:polished_deepslate
fill 398 207 323 398 210 323 minecraft:gray_concrete
setblock 398 207 362 minecraft:polished_deepslate
fill 398 207 363 398 210 363 minecraft:gray_concrete
setblock 400 207 324 minecraft:gray_concrete
setblock 402 207 323 minecraft:polished_deepslate
fill 403 207 323 406 207 323 minecraft:gray_concrete
setblock 407 207 323 minecraft:polished_deepslate
fill 408 207 323 408 209 324 minecraft:gray_concrete
setblock 409 207 322 minecraft:light_blue_stained_glass
fill 409 207 324 410 207 324 minecraft:gray_concrete
fill 409 207 364 409 246 364 minecraft:black_concrete
setblock 411 207 324 minecraft:polished_deepslate
schedule function dropper:buildpart/80_6 1t
