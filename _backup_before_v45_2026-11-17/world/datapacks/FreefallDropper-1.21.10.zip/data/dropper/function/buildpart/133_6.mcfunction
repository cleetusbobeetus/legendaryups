setblock 60 182 596 minecraft:calcite
fill 60 182 597 63 182 597 minecraft:cobbled_deepslate
fill 61 182 596 64 182 596 minecraft:cobbled_deepslate
fill 62 182 595 65 182 595 minecraft:cobbled_deepslate
setblock 63 182 558 minecraft:calcite
setblock 63 182 598 minecraft:calcite
fill 64 182 558 64 185 558 minecraft:cobbled_deepslate
setblock 64 182 597 minecraft:calcite
fill 64 182 598 67 182 598 minecraft:cobbled_deepslate
setblock 65 182 596 minecraft:calcite
fill 65 182 597 65 185 597 minecraft:cobbled_deepslate
fill 66 182 558 67 182 558 minecraft:cobbled_deepslate
setblock 66 182 595 minecraft:calcite
fill 66 182 596 66 185 596 minecraft:cobbled_deepslate
fill 67 182 595 67 184 595 minecraft:cobbled_deepslate
setblock 68 182 558 minecraft:calcite
setblock 68 182 598 minecraft:calcite
setblock 69 182 558 minecraft:cobbled_deepslate
setblock 69 182 597 minecraft:calcite
fill 69 182 598 69 185 598 minecraft:cobbled_deepslate
setblock 70 182 596 minecraft:calcite
fill 70 182 597 70 185 597 minecraft:cobbled_deepslate
fill 71 182 589 71 183 589 minecraft:light_blue_stained_glass
setblock 73 182 598 minecraft:calcite
setblock 82 182 558 minecraft:cobbled_deepslate
setblock 82 182 598 minecraft:cobbled_deepslate
setblock 83 182 558 minecraft:calcite
setblock 83 182 598 minecraft:calcite
fill 84 182 558 87 182 558 minecraft:cobbled_deepslate
setblock 84 182 597 minecraft:calcite
fill 84 182 598 84 185 598 minecraft:cobbled_deepslate
fill 85 182 559 86 182 559 minecraft:cobbled_deepslate
setblock 85 182 566 minecraft:calcite
fill 85 182 567 85 182 570 minecraft:cobbled_deepslate
setblock 85 182 571 minecraft:calcite
fill 85 182 572 85 185 572 minecraft:cobbled_deepslate
setblock 85 182 575 minecraft:cobbled_deepslate
fill 85 182 597 85 185 597 minecraft:cobbled_deepslate
fill 86 182 562 86 182 564 minecraft:cobbled_deepslate
setblock 86 182 565 minecraft:calcite
fill 86 182 566 86 185 566 minecraft:cobbled_deepslate
setblock 86 182 569 minecraft:cobbled_deepslate
setblock 86 182 570 minecraft:calcite
fill 86 182 571 86 185 571 minecraft:cobbled_deepslate
setblock 86 182 575 minecraft:calcite
fill 86 182 576 86 185 576 minecraft:cobbled_deepslate
setblock 86 182 591 minecraft:cobbled_deepslate
setblock 86 182 594 minecraft:cobbled_deepslate
setblock 86 182 595 minecraft:calcite
setblock 87 182 559 minecraft:calcite
fill 87 182 560 87 182 563 minecraft:cobbled_deepslate
setblock 87 182 564 minecraft:calcite
fill 87 182 565 87 185 565 minecraft:cobbled_deepslate
setblock 87 182 568 minecraft:cobbled_deepslate
setblock 87 182 569 minecraft:calcite
fill 87 182 570 87 185 570 minecraft:cobbled_deepslate
setblock 87 182 573 minecraft:cobbled_deepslate
setblock 87 182 574 minecraft:calcite
fill 87 182 575 87 185 575 minecraft:cobbled_deepslate
setblock 87 182 578 minecraft:cobbled_deepslate
setblock 87 182 579 minecraft:calcite
fill 87 182 580 88 182 580 minecraft:cobbled_deepslate
fill 87 182 587 87 182 588 minecraft:cobbled_deepslate
setblock 87 182 589 minecraft:calcite
fill 87 182 590 87 184 590 minecraft:cobbled_deepslate
setblock 87 182 593 minecraft:cobbled_deepslate
setblock 87 182 594 minecraft:calcite
fill 87 182 595 87 185 595 minecraft:cobbled_deepslate
setblock 87 182 598 minecraft:cobbled_deepslate
setblock 88 182 558 minecraft:calcite
fill 88 182 559 88 182 562 minecraft:cobbled_deepslate
setblock 88 182 563 minecraft:calcite
fill 88 182 564 88 185 564 minecraft:cobbled_deepslate
setblock 88 182 568 minecraft:calcite
fill 88 182 569 88 185 569 minecraft:cobbled_deepslate
setblock 88 182 573 minecraft:calcite
fill 88 182 574 88 185 574 minecraft:cobbled_deepslate
setblock 88 182 578 minecraft:calcite
fill 88 182 579 88 185 579 minecraft:cobbled_deepslate
fill 88 182 581 88 182 582 minecraft:cobbled_deepslate
setblock 88 182 583 minecraft:calcite
fill 88 182 584 88 182 587 minecraft:cobbled_deepslate
setblock 88 182 588 minecraft:calcite
fill 88 182 589 88 185 589 minecraft:cobbled_deepslate
setblock 88 182 593 minecraft:calcite
fill 88 182 594 88 185 594 minecraft:cobbled_deepslate
setblock 88 182 598 minecraft:calcite
fill 48 183 558 48 183 561 minecraft:cobbled_deepslate
setblock 48 183 562 minecraft:calcite
fill 48 183 563 48 183 566 minecraft:cobbled_deepslate
setblock 48 183 567 minecraft:calcite
fill 48 183 568 48 183 571 minecraft:cobbled_deepslate
setblock 48 183 572 minecraft:calcite
fill 48 183 573 48 186 573 minecraft:cobbled_deepslate
setblock 48 183 577 minecraft:calcite
fill 48 183 578 48 186 578 minecraft:cobbled_deepslate
fill 48 183 585 48 183 586 minecraft:cobbled_deepslate
setblock 48 183 587 minecraft:calcite
fill 48 183 588 48 183 591 minecraft:cobbled_deepslate
setblock 48 183 592 minecraft:calcite
fill 48 183 593 48 186 593 minecraft:cobbled_deepslate
setblock 48 183 596 minecraft:cobbled_deepslate
setblock 48 183 597 minecraft:calcite
fill 48 183 598 51 183 598 minecraft:cobbled_deepslate
fill 49 183 558 49 183 560 minecraft:cobbled_deepslate
setblock 49 183 561 minecraft:calcite
fill 49 183 562 49 183 565 minecraft:cobbled_deepslate
setblock 49 183 566 minecraft:calcite
fill 49 183 567 49 184 567 minecraft:cobbled_deepslate
setblock 49 183 571 minecraft:calcite
fill 49 183 572 49 185 572 minecraft:cobbled_deepslate
setblock 49 183 576 minecraft:calcite
fill 49 183 588 49 183 590 minecraft:cobbled_deepslate
setblock 49 183 591 minecraft:calcite
fill 49 183 592 49 186 592 minecraft:cobbled_deepslate
setblock 49 183 596 minecraft:calcite
fill 49 183 597 49 186 597 minecraft:cobbled_deepslate
setblock 50 183 591 minecraft:cobbled_deepslate
setblock 50 183 595 minecraft:calcite
fill 50 183 596 50 186 596 minecraft:cobbled_deepslate
setblock 52 183 558 minecraft:calcite
setblock 52 183 598 minecraft:calcite
fill 53 183 558 53 184 558 minecraft:cobbled_deepslate
setblock 53 183 597 minecraft:calcite
fill 53 183 598 56 183 598 minecraft:cobbled_deepslate
setblock 54 183 596 minecraft:calcite
fill 54 183 597 57 183 597 minecraft:cobbled_deepslate
setblock 57 183 598 minecraft:calcite
setblock 58 183 596 minecraft:cobbled_deepslate
setblock 58 183 597 minecraft:calcite
fill 58 183 598 61 183 598 minecraft:cobbled_deepslate
setblock 59 183 596 minecraft:calcite
fill 59 183 597 62 183 597 minecraft:cobbled_deepslate
fill 60 183 596 63 183 596 minecraft:cobbled_deepslate
setblock 62 183 558 minecraft:calcite
fill 62 183 595 64 183 595 minecraft:cobbled_deepslate
setblock 62 183 598 minecraft:calcite
fill 63 183 558 63 186 558 minecraft:cobbled_deepslate
setblock 63 183 597 minecraft:calcite
fill 63 183 598 66 183 598 minecraft:cobbled_deepslate
setblock 64 183 596 minecraft:calcite
fill 64 183 597 64 186 597 minecraft:cobbled_deepslate
setblock 65 183 595 minecraft:calcite
fill 65 183 596 65 186 596 minecraft:cobbled_deepslate
setblock 66 183 558 minecraft:cobbled_deepslate
fill 66 183 595 66 185 595 minecraft:cobbled_deepslate
setblock 67 183 558 minecraft:calcite
setblock 67 183 598 minecraft:calcite
fill 68 183 558 68 184 558 minecraft:cobbled_deepslate
setblock 68 183 595 minecraft:cobbled_deepslate
setblock 68 183 597 minecraft:calcite
fill 68 183 598 68 186 598 minecraft:cobbled_deepslate
setblock 69 183 596 minecraft:calcite
fill 69 183 597 69 186 597 minecraft:cobbled_deepslate
setblock 70 183 596 minecraft:cobbled_deepslate
setblock 72 183 598 minecraft:calcite
setblock 81 183 598 minecraft:cobbled_deepslate
setblock 82 183 558 minecraft:calcite
setblock 82 183 598 minecraft:calcite
fill 83 183 558 86 183 558 minecraft:cobbled_deepslate
setblock 83 183 597 minecraft:calcite
fill 83 183 598 83 186 598 minecraft:cobbled_deepslate
fill 84 183 559 85 183 559 minecraft:cobbled_deepslate
fill 84 183 597 84 186 597 minecraft:cobbled_deepslate
fill 85 183 566 85 183 569 minecraft:cobbled_deepslate
setblock 85 183 570 minecraft:calcite
fill 85 183 571 85 186 571 minecraft:cobbled_deepslate
fill 85 183 573 85 183 574 minecraft:cobbled_deepslate
setblock 85 183 575 minecraft:calcite
setblock 86 183 559 minecraft:calcite
fill 86 183 562 86 183 563 minecraft:cobbled_deepslate
setblock 86 183 564 minecraft:calcite
fill 86 183 565 86 185 565 minecraft:cobbled_deepslate
setblock 86 183 569 minecraft:calcite
fill 86 183 570 86 186 570 minecraft:cobbled_deepslate
setblock 86 183 573 minecraft:cobbled_deepslate
setblock 86 183 574 minecraft:calcite
fill 86 183 575 86 186 575 minecraft:cobbled_deepslate
setblock 86 183 594 minecraft:calcite
fill 86 183 595 86 185 596 minecraft:cobbled_deepslate
setblock 87 183 558 minecraft:calcite
fill 87 183 559 87 183 562 minecraft:cobbled_deepslate
setblock 87 183 563 minecraft:calcite
fill 87 183 564 87 186 564 minecraft:cobbled_deepslate
setblock 87 183 568 minecraft:calcite
fill 87 183 569 87 186 569 minecraft:cobbled_deepslate
setblock 87 183 573 minecraft:calcite
fill 87 183 574 87 186 574 minecraft:cobbled_deepslate
setblock 87 183 578 minecraft:calcite
fill 87 183 579 87 185 579 minecraft:cobbled_deepslate
setblock 87 183 588 minecraft:calcite
setblock 87 183 589 minecraft:cobbled_deepslate
setblock 87 183 593 minecraft:calcite
fill 87 183 594 87 186 594 minecraft:cobbled_deepslate
setblock 87 183 598 minecraft:calcite
fill 88 183 558 88 183 561 minecraft:cobbled_deepslate
setblock 88 183 562 minecraft:calcite
fill 88 183 563 88 186 563 minecraft:cobbled_deepslate
setblock 88 183 567 minecraft:calcite
fill 88 183 568 88 186 568 minecraft:cobbled_deepslate
setblock 88 183 572 minecraft:calcite
fill 88 183 573 88 186 573 minecraft:cobbled_deepslate
setblock 88 183 577 minecraft:calcite
fill 88 183 578 88 186 578 minecraft:cobbled_deepslate
fill 88 183 580 88 183 581 minecraft:cobbled_deepslate
setblock 88 183 582 minecraft:calcite
fill 88 183 583 88 183 586 minecraft:cobbled_deepslate
setblock 88 183 587 minecraft:calcite
fill 88 183 588 88 184 588 minecraft:cobbled_deepslate
setblock 88 183 592 minecraft:calcite
fill 88 183 593 88 186 593 minecraft:cobbled_deepslate
setblock 88 183 597 minecraft:calcite
fill 88 183 598 88 186 598 minecraft:cobbled_deepslate
fill 48 184 558 48 184 560 minecraft:cobbled_deepslate
setblock 48 184 561 minecraft:calcite
fill 48 184 562 48 184 565 minecraft:cobbled_deepslate
setblock 48 184 566 minecraft:calcite
fill 48 184 567 48 184 570 minecraft:cobbled_deepslate
setblock 48 184 571 minecraft:calcite
fill 48 184 572 48 187 572 minecraft:cobbled_deepslate
setblock 48 184 576 minecraft:calcite
fill 48 184 577 48 187 577 minecraft:cobbled_deepslate
setblock 48 184 586 minecraft:calcite
fill 48 184 587 48 184 590 minecraft:cobbled_deepslate
setblock 48 184 591 minecraft:calcite
fill 48 184 592 48 187 592 minecraft:cobbled_deepslate
setblock 48 184 596 minecraft:calcite
fill 48 184 597 48 186 598 minecraft:cobbled_deepslate
fill 49 184 558 49 184 559 minecraft:cobbled_deepslate
setblock 49 184 560 minecraft:calcite
setblock 49 184 561 minecraft:cobbled_deepslate
setblock 49 184 565 minecraft:calcite
setblock 49 184 566 minecraft:cobbled_deepslate
setblock 49 184 570 minecraft:calcite
fill 49 184 571 49 185 571 minecraft:cobbled_deepslate
setblock 49 184 575 minecraft:calcite
setblock 49 184 589 minecraft:cobbled_deepslate
setblock 49 184 590 minecraft:calcite
fill 49 184 591 49 186 591 minecraft:cobbled_deepslate
setblock 49 184 595 minecraft:calcite
fill 49 184 596 49 187 596 minecraft:cobbled_deepslate
fill 49 184 598 50 184 598 minecraft:cobbled_deepslate
setblock 50 184 559 minecraft:calcite
setblock 50 184 594 minecraft:calcite
fill 50 184 595 50 186 595 minecraft:cobbled_deepslate
setblock 51 184 558 minecraft:calcite
setblock 51 184 598 minecraft:calcite
fill 52 184 558 52 186 558 minecraft:cobbled_deepslate
setblock 52 184 596 minecraft:cobbled_deepslate
setblock 52 184 597 minecraft:calcite
fill 52 184 598 55 184 598 minecraft:cobbled_deepslate
setblock 53 184 596 minecraft:calcite
fill 53 184 597 56 184 597 minecraft:cobbled_deepslate
setblock 56 184 598 minecraft:calcite
setblock 57 184 597 minecraft:calcite
fill 57 184 598 60 184 598 minecraft:cobbled_deepslate
setblock 58 184 596 minecraft:calcite
fill 58 184 597 61 184 597 minecraft:cobbled_deepslate
fill 59 184 596 62 184 596 minecraft:cobbled_deepslate
fill 61 184 595 63 184 595 minecraft:cobbled_deepslate
setblock 61 184 598 minecraft:calcite
fill 62 184 558 62 187 558 minecraft:cobbled_deepslate
setblock 62 184 597 minecraft:calcite
fill 62 184 598 65 184 598 minecraft:cobbled_deepslate
setblock 63 184 596 minecraft:calcite
fill 63 184 597 63 187 597 minecraft:cobbled_deepslate
setblock 64 184 595 minecraft:calcite
fill 64 184 596 64 187 596 minecraft:cobbled_deepslate
fill 65 184 595 65 186 595 minecraft:cobbled_deepslate
setblock 66 184 558 minecraft:calcite
setblock 66 184 598 minecraft:calcite
fill 67 184 558 67 186 558 minecraft:cobbled_deepslate
setblock 67 184 597 minecraft:calcite
fill 67 184 598 67 187 598 minecraft:cobbled_deepslate
setblock 68 184 596 minecraft:calcite
fill 68 184 597 68 187 597 minecraft:cobbled_deepslate
setblock 69 184 596 minecraft:cobbled_deepslate
fill 71 184 589 71 190 589 minecraft:deepslate
setblock 71 184 598 minecraft:calcite
setblock 72 184 598 minecraft:cobbled_deepslate
setblock 81 184 558 minecraft:calcite
setblock 81 184 598 minecraft:calcite
fill 82 184 558 85 184 558 minecraft:cobbled_deepslate
fill 82 184 598 82 187 598 minecraft:cobbled_deepslate
fill 83 184 559 84 184 559 minecraft:cobbled_deepslate
fill 83 184 597 83 187 597 minecraft:cobbled_deepslate
setblock 85 184 559 minecraft:calcite
fill 85 184 567 85 184 568 minecraft:cobbled_deepslate
setblock 85 184 569 minecraft:calcite
fill 85 184 570 85 185 570 minecraft:cobbled_deepslate
setblock 85 184 573 minecraft:cobbled_deepslate
setblock 85 184 574 minecraft:calcite
fill 85 184 575 85 185 575 minecraft:cobbled_deepslate
setblock 85 184 596 minecraft:cobbled_deepslate
setblock 86 184 558 minecraft:calcite
fill 86 184 559 88 185 559 minecraft:cobbled_deepslate
setblock 86 184 563 minecraft:calcite
setblock 86 184 564 minecraft:cobbled_deepslate
setblock 86 184 568 minecraft:calcite
fill 86 184 569 86 187 569 minecraft:cobbled_deepslate
setblock 86 184 573 minecraft:calcite
fill 86 184 574 86 187 574 minecraft:cobbled_deepslate
setblock 86 184 593 minecraft:calcite
setblock 86 184 594 minecraft:cobbled_deepslate
setblock 86 184 598 minecraft:calcite
fill 87 184 558 88 186 558 minecraft:cobbled_deepslate
fill 87 184 560 87 184 561 minecraft:cobbled_deepslate
setblock 87 184 562 minecraft:calcite
fill 87 184 563 87 187 563 minecraft:cobbled_deepslate
setblock 87 184 567 minecraft:calcite
fill 87 184 568 87 187 568 minecraft:cobbled_deepslate
setblock 87 184 572 minecraft:calcite
fill 87 184 573 87 187 573 minecraft:cobbled_deepslate
setblock 87 184 577 minecraft:calcite
fill 87 184 578 87 187 578 minecraft:cobbled_deepslate
setblock 87 184 592 minecraft:calcite
fill 87 184 593 87 186 593 minecraft:cobbled_deepslate
setblock 87 184 597 minecraft:calcite
fill 87 184 598 87 187 598 minecraft:cobbled_deepslate
setblock 88 184 560 minecraft:cobbled_deepslate
setblock 88 184 561 minecraft:calcite
fill 88 184 562 88 187 562 minecraft:cobbled_deepslate
setblock 88 184 566 minecraft:calcite
fill 88 184 567 88 187 567 minecraft:cobbled_deepslate
setblock 88 184 571 minecraft:calcite
fill 88 184 572 88 187 572 minecraft:cobbled_deepslate
setblock 88 184 576 minecraft:calcite
fill 88 184 577 88 187 577 minecraft:cobbled_deepslate
setblock 88 184 580 minecraft:cobbled_deepslate
setblock 88 184 581 minecraft:calcite
setblock 88 184 587 minecraft:cobbled_deepslate
setblock 88 184 591 minecraft:calcite
fill 88 184 592 88 187 592 minecraft:cobbled_deepslate
setblock 88 184 596 minecraft:calcite
fill 88 184 597 88 187 597 minecraft:cobbled_deepslate
fill 48 185 558 48 185 559 minecraft:cobbled_deepslate
setblock 48 185 560 minecraft:calcite
fill 48 185 561 48 185 564 minecraft:cobbled_deepslate
setblock 48 185 565 minecraft:calcite
fill 48 185 566 48 185 569 minecraft:cobbled_deepslate
setblock 48 185 570 minecraft:calcite
fill 48 185 571 48 187 571 minecraft:cobbled_deepslate
setblock 48 185 575 minecraft:calcite
fill 48 185 576 48 188 576 minecraft:cobbled_deepslate
fill 48 185 587 48 185 589 minecraft:cobbled_deepslate
setblock 48 185 590 minecraft:calcite
fill 48 185 591 48 188 591 minecraft:cobbled_deepslate
setblock 48 185 595 minecraft:calcite
fill 48 185 596 48 188 596 minecraft:cobbled_deepslate
setblock 49 185 558 minecraft:cobbled_deepslate
setblock 49 185 559 minecraft:calcite
setblock 49 185 569 minecraft:calcite
setblock 49 185 570 minecraft:cobbled_deepslate
setblock 49 185 574 minecraft:calcite
setblock 49 185 590 minecraft:cobbled_deepslate
setblock 49 185 594 minecraft:calcite
fill 49 185 595 49 188 595 minecraft:cobbled_deepslate
setblock 49 185 598 minecraft:cobbled_deepslate
setblock 50 185 558 minecraft:calcite
setblock 50 185 593 minecraft:calcite
setblock 50 185 594 minecraft:cobbled_deepslate
setblock 50 185 598 minecraft:calcite
fill 51 185 558 51 188 558 minecraft:cobbled_deepslate
setblock 51 185 597 minecraft:calcite
fill 51 185 598 54 185 598 minecraft:cobbled_deepslate
setblock 52 185 596 minecraft:calcite
fill 52 185 597 55 185 597 minecraft:cobbled_deepslate
setblock 55 185 598 minecraft:calcite
setblock 56 185 597 minecraft:calcite
fill 56 185 598 59 185 598 minecraft:cobbled_deepslate
fill 57 185 597 60 185 597 minecraft:cobbled_deepslate
fill 58 185 596 61 185 596 minecraft:cobbled_deepslate
setblock 60 185 598 minecraft:calcite
fill 61 185 558 61 188 558 minecraft:cobbled_deepslate
setblock 61 185 597 minecraft:calcite
fill 61 185 598 64 185 598 minecraft:cobbled_deepslate
setblock 62 185 595 minecraft:cobbled_deepslate
setblock 62 185 596 minecraft:calcite
fill 62 185 597 62 188 597 minecraft:cobbled_deepslate
setblock 63 185 595 minecraft:calcite
fill 63 185 596 63 188 596 minecraft:cobbled_deepslate
fill 64 185 595 64 186 595 minecraft:cobbled_deepslate
setblock 65 185 558 minecraft:calcite
setblock 65 185 598 minecraft:calcite
fill 66 185 558 66 188 558 minecraft:cobbled_deepslate
setblock 66 185 597 minecraft:calcite
fill 66 185 598 66 188 598 minecraft:cobbled_deepslate
setblock 67 185 596 minecraft:calcite
fill 67 185 597 67 188 597 minecraft:cobbled_deepslate
setblock 68 185 596 minecraft:cobbled_deepslate
fill 70 185 589 70 190 589 minecraft:deepslate
setblock 70 185 598 minecraft:calcite
fill 71 185 588 71 190 588 minecraft:deepslate
fill 71 185 598 71 186 598 minecraft:cobbled_deepslate
setblock 80 185 558 minecraft:calcite
setblock 80 185 598 minecraft:calcite
fill 81 185 558 84 185 558 minecraft:cobbled_deepslate
fill 81 185 598 81 188 598 minecraft:cobbled_deepslate
fill 82 185 597 82 188 597 minecraft:cobbled_deepslate
setblock 83 185 559 minecraft:cobbled_deepslate
setblock 84 185 559 minecraft:calcite
setblock 85 185 558 minecraft:calcite
fill 85 185 559 85 188 559 minecraft:cobbled_deepslate
setblock 85 185 569 minecraft:cobbled_deepslate
setblock 85 185 573 minecraft:calcite
fill 85 185 574 85 186 574 minecraft:cobbled_deepslate
setblock 85 185 598 minecraft:calcite
fill 86 185 558 86 188 558 minecraft:cobbled_deepslate
setblock 86 185 567 minecraft:calcite
fill 86 185 568 86 186 568 minecraft:cobbled_deepslate
setblock 86 185 572 minecraft:calcite
fill 86 185 573 86 188 573 minecraft:cobbled_deepslate
setblock 86 185 577 minecraft:calcite
setblock 86 185 597 minecraft:calcite
fill 86 185 598 86 188 598 minecraft:cobbled_deepslate
setblock 87 185 560 minecraft:cobbled_deepslate
setblock 87 185 561 minecraft:calcite
fill 87 185 562 87 187 562 minecraft:cobbled_deepslate
setblock 87 185 566 minecraft:calcite
fill 87 185 567 87 187 567 minecraft:cobbled_deepslate
setblock 87 185 571 minecraft:calcite
fill 87 185 572 87 188 572 minecraft:cobbled_deepslate
setblock 87 185 576 minecraft:calcite
fill 87 185 577 87 188 577 minecraft:cobbled_deepslate
setblock 87 185 591 minecraft:calcite
setblock 87 185 592 minecraft:cobbled_deepslate
setblock 87 185 596 minecraft:calcite
fill 87 185 597 87 188 597 minecraft:cobbled_deepslate
setblock 88 185 560 minecraft:calcite
fill 88 185 561 88 188 561 minecraft:cobbled_deepslate
setblock 88 185 565 minecraft:calcite
fill 88 185 566 88 188 566 minecraft:cobbled_deepslate
setblock 88 185 570 minecraft:calcite
fill 88 185 571 88 188 571 minecraft:cobbled_deepslate
setblock 88 185 575 minecraft:calcite
fill 88 185 576 88 188 576 minecraft:cobbled_deepslate
setblock 88 185 580 minecraft:calcite
setblock 88 185 590 minecraft:calcite
fill 88 185 591 88 186 591 minecraft:cobbled_deepslate
setblock 88 185 595 minecraft:calcite
fill 88 185 596 88 188 596 minecraft:cobbled_deepslate
setblock 48 186 558 minecraft:cobbled_deepslate
setblock 48 186 559 minecraft:calcite
fill 48 186 560 48 186 563 minecraft:cobbled_deepslate
setblock 48 186 564 minecraft:calcite
fill 48 186 565 48 186 568 minecraft:cobbled_deepslate
setblock 48 186 569 minecraft:calcite
fill 48 186 570 48 187 570 minecraft:cobbled_deepslate
setblock 48 186 574 minecraft:calcite
fill 48 186 575 48 188 575 minecraft:cobbled_deepslate
setblock 48 186 589 minecraft:calcite
fill 48 186 590 48 187 590 minecraft:cobbled_deepslate
setblock 48 186 594 minecraft:calcite
fill 48 186 595 48 189 595 minecraft:cobbled_deepslate
setblock 49 186 558 minecraft:calcite
setblock 49 186 593 minecraft:calcite
fill 49 186 594 49 189 594 minecraft:cobbled_deepslate
setblock 49 186 598 minecraft:calcite
fill 50 186 558 50 189 558 minecraft:cobbled_deepslate
setblock 50 186 597 minecraft:calcite
fill 50 186 598 53 186 598 minecraft:cobbled_deepslate
setblock 51 186 596 minecraft:calcite
fill 51 186 597 54 186 597 minecraft:cobbled_deepslate
setblock 54 186 598 minecraft:calcite
setblock 55 186 597 minecraft:calcite
fill 55 186 598 58 186 598 minecraft:cobbled_deepslate
fill 56 186 597 59 186 597 minecraft:cobbled_deepslate
fill 58 186 596 60 186 596 minecraft:cobbled_deepslate
setblock 59 186 598 minecraft:calcite
setblock 60 186 597 minecraft:calcite
fill 60 186 598 63 186 598 minecraft:cobbled_deepslate
setblock 61 186 596 minecraft:calcite
fill 61 186 597 61 189 597 minecraft:cobbled_deepslate
setblock 62 186 595 minecraft:calcite
fill 62 186 596 62 189 596 minecraft:cobbled_deepslate
setblock 63 186 595 minecraft:cobbled_deepslate
setblock 64 186 558 minecraft:calcite
setblock 64 186 598 minecraft:calcite
fill 65 186 558 65 189 558 minecraft:cobbled_deepslate
setblock 65 186 597 minecraft:calcite
fill 65 186 598 65 189 598 minecraft:cobbled_deepslate
setblock 66 186 596 minecraft:calcite
fill 66 186 597 66 189 597 minecraft:cobbled_deepslate
setblock 67 186 596 minecraft:cobbled_deepslate
setblock 69 186 598 minecraft:calcite
fill 70 186 588 70 190 588 minecraft:deepslate
fill 70 186 598 70 187 598 minecraft:cobbled_deepslate
fill 71 186 590 71 190 590 minecraft:deepslate
fill 72 186 588 72 190 589 minecraft:deepslate
fill 80 186 558 83 186 558 minecraft:cobbled_deepslate
fill 80 186 598 80 189 598 minecraft:cobbled_deepslate
setblock 82 186 559 minecraft:cobbled_deepslate
setblock 83 186 559 minecraft:calcite
setblock 84 186 558 minecraft:calcite
fill 84 186 559 84 189 559 minecraft:cobbled_deepslate
setblock 84 186 598 minecraft:calcite
fill 85 186 558 85 189 558 minecraft:cobbled_deepslate
setblock 85 186 572 minecraft:calcite
setblock 85 186 573 minecraft:cobbled_deepslate
setblock 85 186 597 minecraft:calcite
fill 85 186 598 85 189 598 minecraft:cobbled_deepslate
fill 86 186 559 87 186 559 minecraft:cobbled_deepslate
setblock 86 186 567 minecraft:cobbled_deepslate
setblock 86 186 571 minecraft:calcite
fill 86 186 572 86 188 572 minecraft:cobbled_deepslate
setblock 86 186 576 minecraft:calcite
setblock 86 186 577 minecraft:cobbled_deepslate
fill 86 186 597 86 189 597 minecraft:cobbled_deepslate
setblock 87 186 560 minecraft:calcite
fill 87 186 561 87 189 561 minecraft:cobbled_deepslate
setblock 87 186 565 minecraft:calcite
fill 87 186 566 87 187 566 minecraft:cobbled_deepslate
setblock 87 186 570 minecraft:calcite
fill 87 186 571 87 188 571 minecraft:cobbled_deepslate
setblock 87 186 575 minecraft:calcite
fill 87 186 576 87 189 576 minecraft:cobbled_deepslate
setblock 87 186 595 minecraft:calcite
fill 87 186 596 87 189 596 minecraft:cobbled_deepslate
setblock 88 186 559 minecraft:calcite
fill 88 186 560 88 189 560 minecraft:cobbled_deepslate
setblock 88 186 564 minecraft:calcite
fill 88 186 565 88 188 565 minecraft:cobbled_deepslate
setblock 88 186 569 minecraft:calcite
fill 88 186 570 88 189 570 minecraft:cobbled_deepslate
setblock 88 186 574 minecraft:calcite
fill 88 186 575 88 189 575 minecraft:cobbled_deepslate
setblock 88 186 579 minecraft:calcite
setblock 88 186 580 minecraft:cobbled_deepslate
setblock 88 186 590 minecraft:cobbled_deepslate
setblock 88 186 594 minecraft:calcite
fill 88 186 595 88 189 595 minecraft:cobbled_deepslate
setblock 48 187 558 minecraft:calcite
fill 48 187 559 48 187 562 minecraft:cobbled_deepslate
setblock 48 187 569 minecraft:cobbled_deepslate
setblock 48 187 573 minecraft:calcite
fill 48 187 574 48 188 574 minecraft:cobbled_deepslate
setblock 48 187 578 minecraft:calcite
setblock 48 187 593 minecraft:calcite
fill 48 187 594 48 190 594 minecraft:cobbled_deepslate
setblock 48 187 597 minecraft:cobbled_deepslate
setblock 48 187 598 minecraft:calcite
fill 49 187 558 49 190 558 minecraft:cobbled_deepslate
setblock 49 187 592 minecraft:calcite
fill 49 187 593 49 188 593 minecraft:cobbled_deepslate
setblock 49 187 597 minecraft:calcite
fill 49 187 598 52 187 598 minecraft:cobbled_deepslate
fill 50 187 597 53 187 597 minecraft:cobbled_deepslate
setblock 53 187 598 minecraft:calcite
setblock 54 187 597 minecraft:calcite
fill 54 187 598 57 187 598 minecraft:cobbled_deepslate
fill 55 187 597 58 187 597 minecraft:cobbled_deepslate
setblock 58 187 598 minecraft:calcite
setblock 59 187 596 minecraft:cobbled_deepslate
setblock 59 187 597 minecraft:calcite
fill 59 187 598 62 187 598 minecraft:cobbled_deepslate
fill 60 187 558 60 189 558 minecraft:cobbled_deepslate
setblock 60 187 596 minecraft:calcite
fill 60 187 597 60 190 597 minecraft:cobbled_deepslate
fill 61 187 596 61 190 596 minecraft:cobbled_deepslate
setblock 63 187 558 minecraft:calcite
setblock 63 187 598 minecraft:calcite
fill 64 187 558 64 190 558 minecraft:cobbled_deepslate
setblock 64 187 597 minecraft:calcite
fill 64 187 598 64 190 598 minecraft:cobbled_deepslate
setblock 65 187 596 minecraft:calcite
fill 65 187 597 65 190 597 minecraft:cobbled_deepslate
setblock 66 187 596 minecraft:cobbled_deepslate
setblock 68 187 598 minecraft:calcite
fill 69 187 598 69 188 598 minecraft:cobbled_deepslate
fill 70 187 590 70 190 590 minecraft:deepslate
fill 71 187 587 71 190 587 minecraft:deepslate
fill 72 187 590 72 190 590 minecraft:deepslate
fill 79 187 558 82 187 558 minecraft:cobbled_deepslate
fill 79 187 598 79 190 598 minecraft:cobbled_deepslate
setblock 82 187 559 minecraft:calcite
setblock 83 187 558 minecraft:calcite
fill 83 187 559 83 190 559 minecraft:cobbled_deepslate
setblock 83 187 598 minecraft:calcite
fill 84 187 558 84 190 558 minecraft:cobbled_deepslate
setblock 84 187 597 minecraft:calcite
fill 84 187 598 84 190 598 minecraft:cobbled_deepslate
fill 85 187 597 85 190 597 minecraft:cobbled_deepslate
setblock 86 187 559 minecraft:cobbled_deepslate
setblock 86 187 570 minecraft:calcite
setblock 86 187 571 minecraft:cobbled_deepslate
setblock 86 187 575 minecraft:calcite
setblock 86 187 576 minecraft:cobbled_deepslate
setblock 87 187 558 minecraft:cobbled_deepslate
setblock 87 187 559 minecraft:calcite
fill 87 187 560 87 190 560 minecraft:cobbled_deepslate
setblock 87 187 565 minecraft:cobbled_deepslate
setblock 87 187 569 minecraft:calcite
fill 87 187 570 87 188 570 minecraft:cobbled_deepslate
setblock 87 187 574 minecraft:calcite
fill 87 187 575 87 190 575 minecraft:cobbled_deepslate
setblock 87 187 594 minecraft:calcite
fill 87 187 595 87 188 595 minecraft:cobbled_deepslate
setblock 88 187 558 minecraft:calcite
fill 88 187 559 88 190 559 minecraft:cobbled_deepslate
setblock 88 187 563 minecraft:calcite
fill 88 187 564 88 189 564 minecraft:cobbled_deepslate
setblock 88 187 568 minecraft:calcite
fill 88 187 569 88 189 569 minecraft:cobbled_deepslate
setblock 88 187 573 minecraft:calcite
fill 88 187 574 88 190 574 minecraft:cobbled_deepslate
setblock 88 187 578 minecraft:calcite
fill 88 187 579 88 189 579 minecraft:cobbled_deepslate
setblock 88 187 593 minecraft:calcite
fill 88 187 594 88 190 594 minecraft:cobbled_deepslate
setblock 88 187 598 minecraft:calcite
fill 48 188 558 48 188 561 minecraft:cobbled_deepslate
setblock 48 188 573 minecraft:cobbled_deepslate
setblock 48 188 577 minecraft:calcite
setblock 48 188 592 minecraft:calcite
fill 48 188 593 48 191 593 minecraft:cobbled_deepslate
setblock 48 188 597 minecraft:calcite
fill 48 188 598 51 188 598 minecraft:cobbled_deepslate
setblock 49 188 596 minecraft:calcite
fill 49 188 597 52 188 597 minecraft:cobbled_deepslate
setblock 50 188 560 minecraft:light[level=14]
setblock 50 188 568 minecraft:light[level=14]
setblock 50 188 576 minecraft:light[level=14]
setblock 50 188 584 minecraft:light[level=14]
setblock 50 188 592 minecraft:light[level=14]
setblock 52 188 598 minecraft:calcite
setblock 53 188 597 minecraft:calcite
fill 53 188 598 56 188 598 minecraft:cobbled_deepslate
fill 54 188 597 57 188 597 minecraft:cobbled_deepslate
setblock 57 188 598 minecraft:calcite
setblock 58 188 560 minecraft:light[level=14]
setblock 58 188 568 minecraft:light[level=14]
setblock 58 188 576 minecraft:light[level=14]
setblock 58 188 584 minecraft:light[level=14]
setblock 58 188 592 minecraft:light[level=14]
setblock 58 188 597 minecraft:calcite
fill 58 188 598 61 188 598 minecraft:cobbled_deepslate
fill 59 188 558 59 190 558 minecraft:cobbled_deepslate
setblock 59 188 596 minecraft:calcite
fill 59 188 597 59 191 597 minecraft:cobbled_deepslate
fill 60 188 596 60 191 596 minecraft:cobbled_deepslate
setblock 62 188 558 minecraft:calcite
setblock 62 188 598 minecraft:calcite
fill 63 188 558 63 191 558 minecraft:cobbled_deepslate
setblock 63 188 597 minecraft:calcite
fill 63 188 598 63 191 598 minecraft:cobbled_deepslate
setblock 64 188 596 minecraft:calcite
fill 64 188 597 64 191 597 minecraft:cobbled_deepslate
setblock 65 188 596 minecraft:cobbled_deepslate
setblock 66 188 560 minecraft:light[level=14]
setblock 66 188 568 minecraft:light[level=14]
setblock 66 188 576 minecraft:light[level=14]
setblock 66 188 584 minecraft:light[level=14]
setblock 66 188 592 minecraft:light[level=14]
setblock 67 188 598 minecraft:calcite
fill 68 188 598 68 191 598 minecraft:cobbled_deepslate
fill 69 188 588 69 190 590 minecraft:deepslate
fill 70 188 587 70 190 587 minecraft:deepslate
fill 70 188 591 71 190 591 minecraft:deepslate
fill 72 188 587 72 190 587 minecraft:deepslate
fill 73 188 588 73 190 589 minecraft:deepslate
setblock 74 188 560 minecraft:light[level=14]
setblock 74 188 568 minecraft:light[level=14]
setblock 74 188 576 minecraft:light[level=14]
setblock 74 188 584 minecraft:light[level=14]
setblock 74 188 592 minecraft:light[level=14]
fill 78 188 558 81 188 558 minecraft:cobbled_deepslate
setblock 81 188 559 minecraft:calcite
fill 81 188 597 81 189 597 minecraft:cobbled_deepslate
setblock 82 188 558 minecraft:calcite
fill 82 188 559 82 191 559 minecraft:cobbled_deepslate
setblock 82 188 560 minecraft:light[level=14]
setblock 82 188 568 minecraft:light[level=14]
setblock 82 188 576 minecraft:light[level=14]
setblock 82 188 584 minecraft:light[level=14]
setblock 82 188 592 minecraft:light[level=14]
setblock 82 188 598 minecraft:calcite
fill 83 188 558 83 191 558 minecraft:cobbled_deepslate
setblock 83 188 597 minecraft:calcite
fill 83 188 598 83 191 598 minecraft:cobbled_deepslate
fill 84 188 597 84 191 597 minecraft:cobbled_deepslate
setblock 86 188 559 minecraft:calcite
setblock 86 188 574 minecraft:calcite
setblock 86 188 575 minecraft:cobbled_deepslate
setblock 87 188 558 minecraft:calcite
fill 87 188 559 87 191 559 minecraft:cobbled_deepslate
setblock 87 188 569 minecraft:cobbled_deepslate
setblock 87 188 573 minecraft:calcite
fill 87 188 574 87 189 574 minecraft:cobbled_deepslate
setblock 87 188 598 minecraft:calcite
fill 88 188 558 88 191 558 minecraft:cobbled_deepslate
setblock 88 188 562 minecraft:calcite
fill 88 188 563 88 191 563 minecraft:cobbled_deepslate
setblock 88 188 567 minecraft:calcite
fill 88 188 568 88 189 568 minecraft:cobbled_deepslate
setblock 88 188 572 minecraft:calcite
fill 88 188 573 88 191 573 minecraft:cobbled_deepslate
setblock 88 188 577 minecraft:calcite
fill 88 188 578 88 191 578 minecraft:cobbled_deepslate
setblock 88 188 593 minecraft:cobbled_deepslate
setblock 88 188 597 minecraft:calcite
fill 88 188 598 88 191 598 minecraft:cobbled_deepslate
fill 48 189 558 48 189 560 minecraft:cobbled_deepslate
setblock 48 189 561 minecraft:calcite
fill 48 189 592 48 190 592 minecraft:cobbled_deepslate
setblock 48 189 596 minecraft:calcite
fill 48 189 597 50 189 598 minecraft:cobbled_deepslate
setblock 49 189 595 minecraft:calcite
fill 49 189 596 49 192 596 minecraft:cobbled_deepslate
setblock 51 189 558 minecraft:calcite
setblock 51 189 597 minecraft:cobbled_deepslate
setblock 51 189 598 minecraft:calcite
setblock 52 189 597 minecraft:calcite
fill 52 189 598 55 189 598 minecraft:cobbled_deepslate
fill 53 189 597 56 189 597 minecraft:cobbled_deepslate
setblock 56 189 598 minecraft:calcite
setblock 57 189 597 minecraft:calcite
fill 57 189 598 60 189 598 minecraft:cobbled_deepslate
fill 58 189 558 58 191 558 minecraft:cobbled_deepslate
fill 58 189 597 58 192 597 minecraft:cobbled_deepslate
fill 59 189 596 59 192 596 minecraft:cobbled_deepslate
setblock 61 189 558 minecraft:calcite
setblock 61 189 598 minecraft:calcite
fill 62 189 558 62 192 558 minecraft:cobbled_deepslate
setblock 62 189 597 minecraft:calcite
fill 62 189 598 62 192 598 minecraft:cobbled_deepslate
setblock 63 189 596 minecraft:calcite
fill 63 189 597 63 192 597 minecraft:cobbled_deepslate
setblock 64 189 596 minecraft:cobbled_deepslate
setblock 66 189 558 minecraft:calcite
setblock 66 189 598 minecraft:calcite
fill 67 189 598 67 192 598 minecraft:cobbled_deepslate
fill 69 189 587 69 190 587 minecraft:deepslate
fill 72 189 591 72 190 591 minecraft:deepslate
fill 73 189 590 73 190 590 minecraft:deepslate
fill 78 189 558 80 189 558 minecraft:cobbled_deepslate
fill 78 189 598 78 191 598 minecraft:cobbled_deepslate
setblock 80 189 559 minecraft:calcite
setblock 81 189 558 minecraft:calcite
fill 81 189 559 81 192 559 minecraft:cobbled_deepslate
setblock 81 189 598 minecraft:calcite
fill 82 189 558 82 192 558 minecraft:cobbled_deepslate
setblock 82 189 597 minecraft:calcite
fill 82 189 598 82 192 598 minecraft:cobbled_deepslate
fill 83 189 597 83 192 597 minecraft:cobbled_deepslate
setblock 85 189 559 minecraft:calcite
setblock 86 189 558 minecraft:calcite
fill 86 189 559 86 192 559 minecraft:cobbled_deepslate
setblock 86 189 598 minecraft:calcite
fill 87 189 558 87 192 558 minecraft:cobbled_deepslate
setblock 87 189 572 minecraft:calcite
setblock 87 189 573 minecraft:cobbled_deepslate
setblock 87 189 577 minecraft:calcite
setblock 87 189 597 minecraft:calcite
fill 87 189 598 87 192 598 minecraft:cobbled_deepslate
setblock 88 189 561 minecraft:calcite
fill 88 189 562 88 192 562 minecraft:cobbled_deepslate
setblock 88 189 571 minecraft:calcite
fill 88 189 572 88 190 572 minecraft:cobbled_deepslate
setblock 88 189 576 minecraft:calcite
fill 88 189 577 88 192 577 minecraft:cobbled_deepslate
setblock 88 189 596 minecraft:calcite
fill 88 189 597 88 192 597 minecraft:cobbled_deepslate
fill 48 190 558 48 190 559 minecraft:cobbled_deepslate
setblock 48 190 560 minecraft:calcite
setblock 48 190 595 minecraft:calcite
fill 48 190 596 48 191 598 minecraft:cobbled_deepslate
setblock 49 190 595 minecraft:cobbled_deepslate
fill 49 190 597 49 190 598 minecraft:cobbled_deepslate
setblock 50 190 558 minecraft:calcite
setblock 50 190 597 minecraft:cobbled_deepslate
setblock 50 190 598 minecraft:calcite
fill 51 190 558 51 193 558 minecraft:cobbled_deepslate
setblock 51 190 597 minecraft:calcite
fill 51 190 598 54 190 598 minecraft:cobbled_deepslate
fill 52 190 597 55 190 597 minecraft:cobbled_deepslate
setblock 55 190 598 minecraft:calcite
fill 56 190 558 57 192 558 minecraft:cobbled_deepslate
setblock 56 190 597 minecraft:calcite
fill 56 190 598 59 190 598 minecraft:cobbled_deepslate
fill 57 190 597 57 193 597 minecraft:cobbled_deepslate
setblock 60 190 558 minecraft:calcite
setblock 60 190 598 minecraft:calcite
fill 61 190 558 61 193 558 minecraft:cobbled_deepslate
setblock 61 190 597 minecraft:calcite
fill 61 190 598 61 193 598 minecraft:cobbled_deepslate
setblock 62 190 596 minecraft:calcite
fill 62 190 597 62 193 597 minecraft:cobbled_deepslate
setblock 63 190 596 minecraft:cobbled_deepslate
setblock 65 190 558 minecraft:calcite
setblock 65 190 598 minecraft:calcite
fill 66 190 558 66 193 558 minecraft:cobbled_deepslate
setblock 66 190 597 minecraft:calcite
fill 66 190 598 66 193 598 minecraft:cobbled_deepslate
fill 68 190 588 68 190 590 minecraft:deepslate
setblock 69 190 591 minecraft:deepslate
fill 70 190 586 72 190 586 minecraft:deepslate
setblock 71 190 592 minecraft:deepslate
setblock 73 190 587 minecraft:deepslate
setblock 73 190 591 minecraft:deepslate
fill 74 190 588 74 190 589 minecraft:deepslate
fill 76 190 558 79 190 558 minecraft:cobbled_deepslate
setblock 79 190 559 minecraft:calcite
setblock 80 190 558 minecraft:calcite
fill 80 190 559 80 193 559 minecraft:cobbled_deepslate
setblock 80 190 598 minecraft:calcite
fill 81 190 558 81 193 558 minecraft:cobbled_deepslate
setblock 81 190 597 minecraft:calcite
fill 81 190 598 81 193 598 minecraft:cobbled_deepslate
setblock 82 190 560 minecraft:cobbled_deepslate
fill 82 190 597 82 193 597 minecraft:cobbled_deepslate
setblock 83 190 560 minecraft:calcite
setblock 84 190 559 minecraft:calcite
fill 84 190 560 85 192 560 minecraft:cobbled_deepslate
setblock 85 190 558 minecraft:calcite
fill 85 190 559 85 193 559 minecraft:cobbled_deepslate
setblock 85 190 598 minecraft:calcite
fill 86 190 558 86 193 558 minecraft:cobbled_deepslate
setblock 86 190 597 minecraft:calcite
fill 86 190 598 86 193 598 minecraft:cobbled_deepslate
setblock 87 190 561 minecraft:calcite
setblock 87 190 596 minecraft:calcite
fill 87 190 597 87 193 597 minecraft:cobbled_deepslate
setblock 88 190 560 minecraft:calcite
fill 88 190 561 88 193 561 minecraft:cobbled_deepslate
setblock 88 190 571 minecraft:cobbled_deepslate
setblock 88 190 575 minecraft:calcite
fill 88 190 576 88 192 576 minecraft:cobbled_deepslate
setblock 88 190 595 minecraft:calcite
fill 88 190 596 88 193 596 minecraft:cobbled_deepslate
setblock 48 191 558 minecraft:cobbled_deepslate
setblock 48 191 559 minecraft:calcite
fill 48 191 560 48 193 561 minecraft:cobbled_deepslate
setblock 48 191 594 minecraft:calcite
fill 48 191 595 48 194 595 minecraft:cobbled_deepslate
setblock 49 191 558 minecraft:calcite
fill 49 191 583 51 196 584 minecraft:calcite
setblock 49 191 597 minecraft:cobbled_deepslate
setblock 49 191 598 minecraft:calcite
fill 50 191 558 50 194 558 minecraft:cobbled_deepslate
setblock 50 191 597 minecraft:calcite
fill 50 191 598 53 191 598 minecraft:cobbled_deepslate
fill 51 191 597 54 191 597 minecraft:cobbled_deepslate
fill 52 191 558 53 191 558 minecraft:cobbled_deepslate
setblock 54 191 558 minecraft:calcite
setblock 54 191 598 minecraft:calcite
fill 55 191 558 55 194 558 minecraft:cobbled_deepslate
setblock 55 191 597 minecraft:calcite
fill 55 191 598 58 191 598 minecraft:cobbled_deepslate
fill 56 191 596 57 192 596 minecraft:light_blue_stained_glass
fill 56 191 597 56 194 597 minecraft:cobbled_deepslate
fill 57 191 595 57 194 595 minecraft:light_blue_stained_glass
fill 58 191 596 58 193 596 minecraft:cobbled_deepslate
setblock 59 191 558 minecraft:calcite
setblock 59 191 598 minecraft:calcite
fill 60 191 558 60 194 558 minecraft:cobbled_deepslate
setblock 60 191 597 minecraft:calcite
fill 60 191 598 60 194 598 minecraft:cobbled_deepslate
setblock 61 191 596 minecraft:calcite
fill 61 191 597 61 194 597 minecraft:cobbled_deepslate
fill 62 191 596 62 192 596 minecraft:cobbled_deepslate
setblock 64 191 558 minecraft:calcite
setblock 64 191 598 minecraft:calcite
fill 65 191 558 65 194 558 minecraft:cobbled_deepslate
setblock 65 191 597 minecraft:calcite
fill 65 191 598 65 194 598 minecraft:cobbled_deepslate
fill 67 191 558 67 192 558 minecraft:cobbled_deepslate
fill 70 191 588 71 191 589 minecraft:light_blue_stained_glass
setblock 71 191 590 minecraft:light_blue_stained_glass
setblock 72 191 589 minecraft:light_blue_stained_glass
fill 75 191 558 78 191 558 minecraft:cobbled_deepslate
setblock 77 191 559 minecraft:cobbled_deepslate
fill 77 191 598 77 192 598 minecraft:cobbled_deepslate
setblock 78 191 559 minecraft:calcite
setblock 79 191 558 minecraft:calcite
fill 79 191 559 79 194 559 minecraft:cobbled_deepslate
setblock 79 191 598 minecraft:calcite
fill 80 191 558 80 194 558 minecraft:cobbled_deepslate
fill 80 191 560 81 191 560 minecraft:cobbled_deepslate
setblock 80 191 597 minecraft:calcite
fill 80 191 598 80 194 598 minecraft:cobbled_deepslate
fill 81 191 597 81 194 597 minecraft:cobbled_deepslate
setblock 82 191 560 minecraft:calcite
setblock 83 191 559 minecraft:calcite
fill 83 191 560 83 194 560 minecraft:cobbled_deepslate
setblock 84 191 558 minecraft:calcite
fill 84 191 559 84 194 559 minecraft:cobbled_deepslate
setblock 84 191 598 minecraft:calcite
fill 85 191 558 85 194 558 minecraft:cobbled_deepslate
setblock 85 191 597 minecraft:calcite
fill 85 191 598 85 194 598 minecraft:cobbled_deepslate
setblock 86 191 560 minecraft:cobbled_deepslate
fill 86 191 597 86 194 597 minecraft:cobbled_deepslate
setblock 87 191 560 minecraft:calcite
fill 87 191 561 87 193 562 minecraft:cobbled_deepslate
setblock 88 191 559 minecraft:calcite
fill 88 191 560 88 194 560 minecraft:cobbled_deepslate
setblock 88 191 564 minecraft:calcite
setblock 88 191 574 minecraft:calcite
fill 88 191 575 88 192 575 minecraft:cobbled_deepslate
setblock 88 191 579 minecraft:calcite
fill 88 191 595 88 194 595 minecraft:cobbled_deepslate
setblock 48 192 558 minecraft:calcite
fill 48 192 559 48 195 559 minecraft:cobbled_deepslate
setblock 48 192 593 minecraft:calcite
fill 48 192 594 48 195 594 minecraft:cobbled_deepslate
fill 48 192 596 48 192 597 minecraft:cobbled_deepslate
setblock 48 192 598 minecraft:calcite
fill 49 192 558 49 195 558 minecraft:cobbled_deepslate
fill 49 192 582 51 193 582 minecraft:deepslate
setblock 49 192 597 minecraft:calcite
fill 49 192 598 52 192 598 minecraft:cobbled_deepslate
fill 50 192 585 50 193 585 minecraft:deepslate
fill 50 192 597 53 192 597 minecraft:cobbled_deepslate
setblock 52 192 558 minecraft:cobbled_deepslate
setblock 53 192 558 minecraft:calcite
setblock 53 192 598 minecraft:calcite
fill 54 192 558 54 195 558 minecraft:cobbled_deepslate
setblock 54 192 597 minecraft:calcite
fill 54 192 598 57 192 598 minecraft:cobbled_deepslate
fill 55 192 596 55 193 596 minecraft:light_blue_stained_glass
fill 55 192 597 55 195 597 minecraft:cobbled_deepslate
fill 56 192 595 56 194 595 minecraft:light_blue_stained_glass
fill 57 192 594 57 194 594 minecraft:light_blue_stained_glass
setblock 58 192 558 minecraft:calcite
fill 58 192 595 58 194 595 minecraft:light_blue_stained_glass
setblock 58 192 598 minecraft:calcite
fill 59 192 558 59 194 559 minecraft:cobbled_deepslate
setblock 59 192 597 minecraft:calcite
fill 59 192 598 59 195 598 minecraft:cobbled_deepslate
fill 60 192 559 61 192 559 minecraft:cobbled_deepslate
setblock 60 192 596 minecraft:calcite
fill 60 192 597 60 195 597 minecraft:cobbled_deepslate
fill 61 192 596 61 194 596 minecraft:cobbled_deepslate
setblock 62 192 559 minecraft:calcite
setblock 63 192 558 minecraft:calcite
fill 63 192 559 63 195 559 minecraft:cobbled_deepslate
setblock 63 192 598 minecraft:calcite
fill 64 192 558 64 195 558 minecraft:cobbled_deepslate
setblock 64 192 597 minecraft:calcite
fill 64 192 598 64 195 598 minecraft:cobbled_deepslate
setblock 65 192 597 minecraft:cobbled_deepslate
fill 70 192 589 71 192 589 minecraft:light_blue_stained_glass
setblock 71 192 588 minecraft:light_blue_stained_glass
fill 74 192 558 77 192 558 minecraft:cobbled_deepslate
setblock 76 192 559 minecraft:cobbled_deepslate
fill 76 192 598 76 193 598 minecraft:cobbled_deepslate
setblock 77 192 559 minecraft:calcite
setblock 78 192 558 minecraft:calcite
fill 78 192 559 78 194 560 minecraft:cobbled_deepslate
setblock 78 192 598 minecraft:calcite
fill 79 192 558 79 195 558 minecraft:cobbled_deepslate
fill 79 192 560 80 192 560 minecraft:cobbled_deepslate
setblock 79 192 597 minecraft:calcite
fill 79 192 598 79 195 598 minecraft:cobbled_deepslate
fill 80 192 597 80 195 597 minecraft:cobbled_deepslate
setblock 81 192 560 minecraft:calcite
setblock 82 192 559 minecraft:calcite
fill 82 192 560 82 195 560 minecraft:cobbled_deepslate
setblock 83 192 558 minecraft:calcite
fill 83 192 559 83 195 559 minecraft:cobbled_deepslate
setblock 83 192 598 minecraft:calcite
fill 84 192 558 84 195 558 minecraft:cobbled_deepslate
setblock 84 192 597 minecraft:calcite
fill 84 192 598 84 195 598 minecraft:cobbled_deepslate
fill 85 192 597 85 195 597 minecraft:cobbled_deepslate
setblock 86 192 560 minecraft:calcite
fill 86 192 561 86 195 561 minecraft:cobbled_deepslate
setblock 87 192 559 minecraft:calcite
fill 87 192 560 87 195 560 minecraft:cobbled_deepslate
setblock 88 192 558 minecraft:calcite
fill 88 192 559 88 195 559 minecraft:cobbled_deepslate
setblock 88 192 563 minecraft:calcite
fill 88 192 564 88 195 564 minecraft:cobbled_deepslate
setblock 88 192 578 minecraft:calcite
fill 88 192 579 88 195 579 minecraft:cobbled_deepslate
setblock 88 192 598 minecraft:calcite
fill 48 193 558 48 196 558 minecraft:cobbled_deepslate
setblock 48 193 562 minecraft:calcite
fill 48 193 578 48 193 581 minecraft:cobbled_deepslate
setblock 48 193 582 minecraft:calcite
fill 48 193 583 48 193 584 minecraft:deepslate
fill 48 193 593 48 196 593 minecraft:cobbled_deepslate
setblock 48 193 596 minecraft:cobbled_deepslate
setblock 48 193 597 minecraft:calcite
fill 48 193 598 51 193 598 minecraft:cobbled_deepslate
setblock 49 193 585 minecraft:deepslate
setblock 49 193 596 minecraft:calcite
fill 49 193 597 52 193 597 minecraft:cobbled_deepslate
setblock 51 193 585 minecraft:deepslate
setblock 52 193 558 minecraft:calcite
fill 52 193 583 52 193 584 minecraft:deepslate
setblock 52 193 598 minecraft:calcite
fill 53 193 558 53 196 558 minecraft:cobbled_deepslate
setblock 53 193 597 minecraft:calcite
fill 53 193 598 56 193 598 minecraft:cobbled_deepslate
fill 54 193 597 54 196 597 minecraft:cobbled_deepslate
setblock 56 193 558 minecraft:cobbled_deepslate
setblock 56 193 594 minecraft:light_blue_stained_glass
fill 56 193 596 56 194 596 minecraft:light_blue_stained_glass
setblock 57 193 558 minecraft:calcite
fill 57 193 559 58 195 559 minecraft:cobbled_deepslate
setblock 57 193 593 minecraft:light_blue_stained_glass
fill 57 193 596 57 194 596 minecraft:cobbled_deepslate
setblock 57 193 598 minecraft:calcite
fill 58 193 558 58 196 558 minecraft:cobbled_deepslate
setblock 58 193 594 minecraft:light_blue_stained_glass
setblock 58 193 597 minecraft:calcite
fill 58 193 598 58 196 598 minecraft:cobbled_deepslate
setblock 59 193 596 minecraft:calcite
fill 59 193 597 59 196 597 minecraft:cobbled_deepslate
setblock 60 193 559 minecraft:cobbled_deepslate
fill 60 193 596 60 195 596 minecraft:cobbled_deepslate
setblock 61 193 559 minecraft:calcite
setblock 62 193 558 minecraft:calcite
fill 62 193 559 62 196 559 minecraft:cobbled_deepslate
setblock 62 193 598 minecraft:calcite
fill 63 193 558 63 196 558 minecraft:cobbled_deepslate
setblock 63 193 597 minecraft:calcite
fill 63 193 598 63 196 598 minecraft:cobbled_deepslate
fill 64 193 559 64 194 559 minecraft:cobbled_deepslate
fill 64 193 597 64 194 597 minecraft:cobbled_deepslate
setblock 67 193 558 minecraft:calcite
setblock 67 193 598 minecraft:calcite
fill 68 193 558 68 196 558 minecraft:cobbled_deepslate
setblock 71 193 558 minecraft:cobbled_deepslate
fill 71 193 589 71 195 589 minecraft:light_blue_stained_glass
setblock 72 193 558 minecraft:calcite
fill 73 193 558 76 193 558 minecraft:cobbled_deepslate
setblock 75 193 559 minecraft:cobbled_deepslate
fill 75 193 598 75 194 598 minecraft:cobbled_deepslate
setblock 76 193 559 minecraft:calcite
setblock 77 193 558 minecraft:calcite
fill 77 193 559 77 195 560 minecraft:cobbled_deepslate
setblock 77 193 598 minecraft:calcite
fill 78 193 558 78 196 558 minecraft:cobbled_deepslate
setblock 78 193 597 minecraft:calcite
fill 78 193 598 78 196 598 minecraft:cobbled_deepslate
setblock 79 193 560 minecraft:cobbled_deepslate
fill 79 193 597 79 196 597 minecraft:cobbled_deepslate
setblock 80 193 560 minecraft:calcite
fill 80 193 561 83 193 561 minecraft:cobbled_deepslate
setblock 81 193 559 minecraft:calcite
fill 81 193 560 81 196 560 minecraft:cobbled_deepslate
setblock 82 193 558 minecraft:calcite
fill 82 193 559 82 196 559 minecraft:cobbled_deepslate
setblock 82 193 598 minecraft:calcite
fill 83 193 558 83 196 558 minecraft:cobbled_deepslate
setblock 83 193 597 minecraft:calcite
fill 83 193 598 83 196 598 minecraft:cobbled_deepslate
setblock 84 193 560 minecraft:cobbled_deepslate
fill 84 193 597 84 196 597 minecraft:cobbled_deepslate
setblock 85 193 560 minecraft:calcite
setblock 86 193 559 minecraft:calcite
fill 86 193 560 86 196 560 minecraft:cobbled_deepslate
setblock 87 193 558 minecraft:calcite
fill 87 193 559 87 196 559 minecraft:cobbled_deepslate
setblock 87 193 563 minecraft:calcite
setblock 87 193 598 minecraft:calcite
fill 88 193 558 88 196 558 minecraft:cobbled_deepslate
setblock 88 193 562 minecraft:calcite
fill 88 193 563 88 196 563 minecraft:cobbled_deepslate
setblock 88 193 577 minecraft:calcite
fill 88 193 578 88 194 578 minecraft:cobbled_deepslate
fill 88 193 580 88 194 580 minecraft:cobbled_deepslate
setblock 88 193 597 minecraft:calcite
fill 88 193 598 88 196 598 minecraft:cobbled_deepslate
setblock 48 194 560 minecraft:cobbled_deepslate
setblock 48 194 561 minecraft:calcite
fill 48 194 562 48 197 562 minecraft:cobbled_deepslate
fill 48 194 578 48 194 580 minecraft:cobbled_deepslate
setblock 48 194 581 minecraft:calcite
fill 48 194 582 48 194 585 minecraft:cobbled_deepslate
setblock 48 194 596 minecraft:calcite
fill 48 194 597 50 194 598 minecraft:cobbled_deepslate
setblock 49 194 596 minecraft:cobbled_deepslate
setblock 51 194 558 minecraft:calcite
setblock 51 194 597 minecraft:cobbled_deepslate
setblock 51 194 598 minecraft:calcite
fill 52 194 558 52 197 558 minecraft:cobbled_deepslate
setblock 52 194 597 minecraft:calcite
fill 52 194 598 55 194 598 minecraft:cobbled_deepslate
fill 53 194 597 53 197 597 minecraft:cobbled_deepslate
setblock 55 194 559 minecraft:calcite
setblock 56 194 558 minecraft:calcite
fill 56 194 559 56 197 559 minecraft:cobbled_deepslate
setblock 56 194 598 minecraft:calcite
fill 57 194 558 57 197 558 minecraft:cobbled_deepslate
setblock 57 194 597 minecraft:calcite
fill 57 194 598 57 197 598 minecraft:cobbled_deepslate
setblock 58 194 596 minecraft:calcite
fill 58 194 597 58 197 597 minecraft:cobbled_deepslate
fill 59 194 596 59 195 596 minecraft:cobbled_deepslate
setblock 60 194 559 minecraft:calcite
setblock 61 194 558 minecraft:calcite
fill 61 194 559 61 197 559 minecraft:cobbled_deepslate
setblock 61 194 598 minecraft:calcite
fill 62 194 558 62 197 558 minecraft:cobbled_deepslate
setblock 62 194 597 minecraft:calcite
fill 62 194 598 62 197 598 minecraft:cobbled_deepslate
fill 63 194 597 63 195 597 minecraft:cobbled_deepslate
setblock 65 194 559 minecraft:calcite
setblock 66 194 558 minecraft:calcite
setblock 66 194 598 minecraft:calcite
fill 67 194 558 67 197 558 minecraft:cobbled_deepslate
setblock 67 194 598 minecraft:cobbled_deepslate
fill 69 194 558 70 194 558 minecraft:cobbled_deepslate
setblock 71 194 558 minecraft:calcite
fill 72 194 558 75 194 558 minecraft:cobbled_deepslate
fill 73 194 559 74 194 559 minecraft:cobbled_deepslate
fill 74 194 598 74 195 598 minecraft:cobbled_deepslate
setblock 75 194 559 minecraft:calcite
setblock 76 194 558 minecraft:calcite
fill 76 194 559 76 196 560 minecraft:cobbled_deepslate
setblock 76 194 598 minecraft:calcite
fill 77 194 558 77 197 558 minecraft:cobbled_deepslate
fill 77 194 598 77 197 598 minecraft:cobbled_deepslate
setblock 78 194 561 minecraft:calcite
fill 78 194 597 78 197 597 minecraft:cobbled_deepslate
setblock 79 194 560 minecraft:calcite
fill 79 194 561 82 194 561 minecraft:cobbled_deepslate
setblock 80 194 559 minecraft:calcite
fill 80 194 560 80 197 560 minecraft:cobbled_deepslate
setblock 81 194 558 minecraft:calcite
fill 81 194 559 81 197 559 minecraft:cobbled_deepslate
setblock 81 194 598 minecraft:calcite
fill 82 194 558 82 197 558 minecraft:cobbled_deepslate
setblock 82 194 597 minecraft:calcite
fill 82 194 598 82 197 598 minecraft:cobbled_deepslate
setblock 83 194 561 minecraft:calcite
fill 83 194 597 83 197 597 minecraft:cobbled_deepslate
setblock 84 194 560 minecraft:calcite
fill 84 194 561 84 197 561 minecraft:cobbled_deepslate
setblock 85 194 559 minecraft:calcite
fill 85 194 560 85 197 560 minecraft:cobbled_deepslate
setblock 86 194 558 minecraft:calcite
fill 86 194 559 86 197 559 minecraft:cobbled_deepslate
setblock 86 194 562 minecraft:cobbled_deepslate
setblock 86 194 598 minecraft:calcite
fill 87 194 558 87 197 558 minecraft:cobbled_deepslate
setblock 87 194 561 minecraft:cobbled_deepslate
setblock 87 194 562 minecraft:calcite
fill 87 194 563 87 197 563 minecraft:cobbled_deepslate
setblock 87 194 597 minecraft:calcite
fill 87 194 598 87 197 598 minecraft:cobbled_deepslate
setblock 88 194 561 minecraft:calcite
fill 88 194 562 88 197 562 minecraft:cobbled_deepslate
setblock 88 194 565 minecraft:cobbled_deepslate
setblock 88 194 581 minecraft:calcite
setblock 88 194 596 minecraft:calcite
fill 88 194 597 88 197 597 minecraft:cobbled_deepslate
setblock 48 195 560 minecraft:calcite
fill 48 195 561 48 198 561 minecraft:cobbled_deepslate
fill 48 195 578 48 195 579 minecraft:cobbled_deepslate
setblock 48 195 580 minecraft:calcite
fill 48 195 581 48 195 584 minecraft:cobbled_deepslate
setblock 48 195 585 minecraft:calcite
fill 48 195 586 48 197 587 minecraft:cobbled_deepslate
setblock 48 195 595 minecraft:calcite
fill 48 195 596 48 196 598 minecraft:cobbled_deepslate
setblock 49 195 559 minecraft:calcite
fill 49 195 597 49 195 598 minecraft:cobbled_deepslate
setblock 50 195 558 minecraft:calcite
setblock 50 195 597 minecraft:cobbled_deepslate
setblock 50 195 598 minecraft:calcite
fill 51 195 558 51 198 558 minecraft:cobbled_deepslate
setblock 51 195 597 minecraft:calcite
fill 51 195 598 54 195 598 minecraft:cobbled_deepslate
fill 52 195 597 52 197 597 minecraft:cobbled_deepslate
setblock 53 195 559 minecraft:cobbled_deepslate
setblock 54 195 559 minecraft:calcite
setblock 55 195 558 minecraft:calcite
fill 55 195 559 55 198 559 minecraft:cobbled_deepslate
setblock 55 195 598 minecraft:calcite
fill 56 195 558 56 198 558 minecraft:cobbled_deepslate
setblock 56 195 597 minecraft:calcite
fill 56 195 598 56 198 598 minecraft:cobbled_deepslate
setblock 57 195 596 minecraft:calcite
fill 57 195 597 57 198 597 minecraft:cobbled_deepslate
fill 58 195 596 58 196 596 minecraft:cobbled_deepslate
setblock 59 195 558 minecraft:cobbled_deepslate
setblock 59 195 559 minecraft:calcite
fill 59 195 560 60 197 560 minecraft:cobbled_deepslate
setblock 60 195 558 minecraft:calcite
fill 60 195 559 60 198 559 minecraft:cobbled_deepslate
setblock 60 195 598 minecraft:calcite
fill 61 195 558 61 198 558 minecraft:cobbled_deepslate
setblock 61 195 597 minecraft:calcite
fill 61 195 598 61 198 598 minecraft:cobbled_deepslate
fill 62 195 597 62 196 597 minecraft:cobbled_deepslate
setblock 64 195 559 minecraft:calcite
setblock 65 195 558 minecraft:calcite
fill 65 195 559 65 196 559 minecraft:cobbled_deepslate
setblock 65 195 598 minecraft:calcite
fill 66 195 558 66 198 558 minecraft:cobbled_deepslate
setblock 66 195 598 minecraft:cobbled_deepslate
setblock 69 195 558 minecraft:cobbled_deepslate
setblock 70 195 558 minecraft:calcite
fill 71 195 558 74 195 558 minecraft:cobbled_deepslate
fill 72 195 559 73 195 559 minecraft:cobbled_deepslate
setblock 74 195 559 minecraft:calcite
fill 74 195 560 75 197 560 minecraft:cobbled_deepslate
setblock 75 195 558 minecraft:calcite
fill 75 195 559 75 198 559 minecraft:cobbled_deepslate
setblock 75 195 598 minecraft:calcite
fill 76 195 558 76 198 558 minecraft:cobbled_deepslate
fill 76 195 598 76 198 598 minecraft:cobbled_deepslate
setblock 77 195 561 minecraft:calcite
fill 77 195 597 77 197 597 minecraft:cobbled_deepslate
setblock 78 195 559 minecraft:cobbled_deepslate
setblock 78 195 560 minecraft:calcite
fill 78 195 561 81 195 561 minecraft:cobbled_deepslate
setblock 79 195 559 minecraft:calcite
fill 79 195 560 79 198 560 minecraft:cobbled_deepslate
setblock 80 195 558 minecraft:calcite
fill 80 195 559 80 198 559 minecraft:cobbled_deepslate
setblock 80 195 598 minecraft:calcite
fill 81 195 558 81 198 558 minecraft:cobbled_deepslate
setblock 81 195 597 minecraft:calcite
fill 81 195 598 81 198 598 minecraft:cobbled_deepslate
setblock 82 195 561 minecraft:calcite
fill 82 195 597 82 198 597 minecraft:cobbled_deepslate
setblock 83 195 560 minecraft:calcite
fill 83 195 561 83 198 561 minecraft:cobbled_deepslate
setblock 84 195 559 minecraft:calcite
fill 84 195 560 84 198 560 minecraft:cobbled_deepslate
setblock 85 195 558 minecraft:calcite
fill 85 195 559 85 198 559 minecraft:cobbled_deepslate
setblock 85 195 598 minecraft:calcite
fill 86 195 558 86 198 558 minecraft:cobbled_deepslate
setblock 86 195 562 minecraft:calcite
setblock 86 195 597 minecraft:calcite
fill 86 195 598 86 198 598 minecraft:cobbled_deepslate
setblock 87 195 561 minecraft:calcite
fill 87 195 562 87 198 562 minecraft:cobbled_deepslate
fill 87 195 564 87 196 564 minecraft:cobbled_deepslate
setblock 87 195 597 minecraft:cobbled_deepslate
setblock 88 195 560 minecraft:calcite
fill 88 195 561 88 198 561 minecraft:cobbled_deepslate
setblock 88 195 565 minecraft:calcite
setblock 88 195 580 minecraft:calcite
fill 88 195 581 88 197 582 minecraft:cobbled_deepslate
setblock 88 195 595 minecraft:calcite
fill 88 195 596 88 197 596 minecraft:cobbled_deepslate
setblock 48 196 559 minecraft:calcite
fill 48 196 560 48 199 560 minecraft:cobbled_deepslate
setblock 48 196 563 minecraft:cobbled_deepslate
setblock 48 196 578 minecraft:cobbled_deepslate
setblock 48 196 579 minecraft:calcite
fill 48 196 580 48 196 583 minecraft:cobbled_deepslate
setblock 48 196 584 minecraft:calcite
fill 48 196 585 48 199 585 minecraft:cobbled_deepslate
setblock 48 196 588 minecraft:cobbled_deepslate
setblock 48 196 589 minecraft:calcite
setblock 48 196 594 minecraft:calcite
fill 48 196 595 48 198 595 minecraft:cobbled_deepslate
setblock 49 196 558 minecraft:calcite
setblock 49 196 559 minecraft:cobbled_deepslate
setblock 49 196 582 minecraft:cobbled_deepslate
setblock 49 196 598 minecraft:calcite
fill 50 196 558 50 199 558 minecraft:cobbled_deepslate
setblock 50 196 560 minecraft:light[level=14]
setblock 50 196 568 minecraft:light[level=14]
setblock 50 196 576 minecraft:light[level=14]
setblock 50 196 592 minecraft:light[level=14]
setblock 50 196 597 minecraft:calcite
fill 50 196 598 53 196 598 minecraft:cobbled_deepslate
setblock 51 196 597 minecraft:cobbled_deepslate
setblock 52 196 559 minecraft:cobbled_deepslate
setblock 53 196 559 minecraft:calcite
setblock 54 196 558 minecraft:calcite
fill 54 196 559 54 199 559 minecraft:cobbled_deepslate
setblock 54 196 598 minecraft:calcite
fill 55 196 558 55 199 558 minecraft:cobbled_deepslate
setblock 55 196 597 minecraft:calcite
fill 55 196 598 55 199 598 minecraft:cobbled_deepslate
fill 56 196 597 56 199 597 minecraft:cobbled_deepslate
setblock 57 196 559 minecraft:cobbled_deepslate
setblock 57 196 560 minecraft:calcite
setblock 58 196 559 minecraft:calcite
fill 58 196 560 58 198 560 minecraft:cobbled_deepslate
setblock 58 196 568 minecraft:light[level=14]
setblock 58 196 576 minecraft:light[level=14]
setblock 58 196 584 minecraft:light[level=14]
setblock 58 196 592 minecraft:light[level=14]
setblock 59 196 558 minecraft:calcite
fill 59 196 559 59 199 559 minecraft:cobbled_deepslate
setblock 59 196 598 minecraft:calcite
fill 60 196 558 60 199 558 minecraft:cobbled_deepslate
setblock 60 196 597 minecraft:calcite
fill 60 196 598 60 199 598 minecraft:cobbled_deepslate
setblock 61 196 560 minecraft:cobbled_deepslate
fill 61 196 597 61 197 597 minecraft:cobbled_deepslate
setblock 63 196 559 minecraft:calcite
setblock 64 196 558 minecraft:calcite
fill 64 196 559 64 197 559 minecraft:cobbled_deepslate
setblock 64 196 598 minecraft:calcite
fill 65 196 558 65 198 558 minecraft:cobbled_deepslate
setblock 65 196 598 minecraft:cobbled_deepslate
setblock 66 196 560 minecraft:light[level=14]
setblock 66 196 568 minecraft:light[level=14]
setblock 66 196 576 minecraft:light[level=14]
setblock 66 196 584 minecraft:light[level=14]
setblock 66 196 592 minecraft:light[level=14]
setblock 69 196 558 minecraft:calcite
fill 70 196 558 73 196 558 minecraft:cobbled_deepslate
fill 71 196 559 72 196 559 minecraft:cobbled_deepslate
setblock 73 196 559 minecraft:calcite
fill 73 196 560 73 199 560 minecraft:cobbled_deepslate
setblock 74 196 558 minecraft:calcite
fill 74 196 559 74 199 559 minecraft:cobbled_deepslate
setblock 74 196 568 minecraft:light[level=14]
setblock 74 196 576 minecraft:light[level=14]
setblock 74 196 584 minecraft:light[level=14]
setblock 74 196 592 minecraft:light[level=14]
setblock 74 196 598 minecraft:calcite
fill 75 196 558 75 199 558 minecraft:cobbled_deepslate
fill 75 196 598 75 199 598 minecraft:cobbled_deepslate
setblock 76 196 561 minecraft:calcite
setblock 77 196 559 minecraft:cobbled_deepslate
setblock 77 196 560 minecraft:calcite
fill 77 196 561 80 196 561 minecraft:cobbled_deepslate
setblock 78 196 559 minecraft:calcite
fill 78 196 560 78 199 560 minecraft:cobbled_deepslate
setblock 79 196 558 minecraft:calcite
fill 79 196 559 79 199 559 minecraft:cobbled_deepslate
setblock 79 196 562 minecraft:cobbled_deepslate
setblock 79 196 598 minecraft:calcite
fill 80 196 558 80 199 558 minecraft:cobbled_deepslate
setblock 80 196 562 minecraft:calcite
setblock 80 196 597 minecraft:calcite
fill 80 196 598 80 199 598 minecraft:cobbled_deepslate
setblock 81 196 561 minecraft:calcite
fill 81 196 597 81 198 597 minecraft:cobbled_deepslate
setblock 82 196 560 minecraft:calcite
fill 82 196 561 82 199 561 minecraft:cobbled_deepslate
setblock 82 196 568 minecraft:light[level=14]
setblock 82 196 576 minecraft:light[level=14]
setblock 82 196 584 minecraft:light[level=14]
setblock 82 196 592 minecraft:light[level=14]
setblock 83 196 559 minecraft:calcite
fill 83 196 560 83 199 560 minecraft:cobbled_deepslate
setblock 84 196 558 minecraft:calcite
fill 84 196 559 84 199 559 minecraft:cobbled_deepslate
setblock 84 196 598 minecraft:calcite
fill 85 196 558 85 199 558 minecraft:cobbled_deepslate
setblock 85 196 597 minecraft:calcite
fill 85 196 598 85 199 598 minecraft:cobbled_deepslate
setblock 86 196 561 minecraft:calcite
fill 86 196 562 86 196 563 minecraft:cobbled_deepslate
setblock 87 196 560 minecraft:calcite
fill 87 196 561 87 199 561 minecraft:cobbled_deepslate
setblock 88 196 559 minecraft:calcite
fill 88 196 560 88 199 560 minecraft:cobbled_deepslate
setblock 88 196 564 minecraft:calcite
fill 88 196 565 88 198 566 minecraft:cobbled_deepslate
setblock 88 196 580 minecraft:cobbled_deepslate
setblock 88 196 583 minecraft:cobbled_deepslate
setblock 48 197 558 minecraft:calcite
fill 48 197 559 48 199 559 minecraft:cobbled_deepslate
setblock 48 197 563 minecraft:calcite
fill 48 197 579 48 197 582 minecraft:cobbled_deepslate
setblock 48 197 583 minecraft:calcite
fill 48 197 584 49 199 584 minecraft:cobbled_deepslate
setblock 48 197 588 minecraft:calcite
fill 48 197 589 48 198 591 minecraft:cobbled_deepslate
setblock 48 197 593 minecraft:calcite
setblock 48 197 594 minecraft:cobbled_deepslate
fill 48 197 596 48 197 597 minecraft:cobbled_deepslate
setblock 48 197 598 minecraft:calcite
fill 49 197 558 49 199 558 minecraft:cobbled_deepslate
setblock 49 197 581 minecraft:cobbled_deepslate
setblock 49 197 582 minecraft:calcite
fill 49 197 583 49 200 583 minecraft:cobbled_deepslate
fill 49 197 585 49 198 585 minecraft:cobbled_deepslate
fill 49 197 598 52 197 598 minecraft:cobbled_deepslate
fill 50 197 583 51 205 584 minecraft:calcite
setblock 52 197 559 minecraft:calcite
setblock 53 197 558 minecraft:calcite
fill 53 197 559 53 199 559 minecraft:cobbled_deepslate
setblock 53 197 598 minecraft:calcite
fill 54 197 558 54 200 558 minecraft:cobbled_deepslate
setblock 54 197 597 minecraft:calcite
fill 54 197 598 54 200 598 minecraft:cobbled_deepslate
fill 55 197 597 55 199 597 minecraft:cobbled_deepslate
setblock 57 197 559 minecraft:calcite
fill 57 197 560 57 198 560 minecraft:cobbled_deepslate
setblock 58 197 558 minecraft:calcite
fill 58 197 559 58 200 559 minecraft:cobbled_deepslate
setblock 58 197 598 minecraft:calcite
fill 59 197 558 59 200 558 minecraft:cobbled_deepslate
setblock 59 197 597 minecraft:calcite
fill 59 197 598 59 200 598 minecraft:cobbled_deepslate
fill 60 197 597 60 198 597 minecraft:cobbled_deepslate
setblock 62 197 559 minecraft:calcite
setblock 63 197 558 minecraft:calcite
fill 63 197 559 63 198 559 minecraft:cobbled_deepslate
setblock 63 197 598 minecraft:calcite
fill 64 197 558 64 199 558 minecraft:cobbled_deepslate
setblock 64 197 598 minecraft:cobbled_deepslate
setblock 68 197 558 minecraft:calcite
fill 69 197 558 72 197 558 minecraft:cobbled_deepslate
setblock 71 197 559 minecraft:cobbled_deepslate
setblock 72 197 559 minecraft:calcite
setblock 73 197 558 minecraft:calcite
fill 73 197 559 73 200 559 minecraft:cobbled_deepslate
fill 74 197 558 74 200 558 minecraft:cobbled_deepslate
fill 74 197 598 74 199 598 minecraft:cobbled_deepslate
setblock 75 197 561 minecraft:calcite
setblock 76 197 559 minecraft:cobbled_deepslate
setblock 76 197 560 minecraft:calcite
fill 76 197 561 79 197 561 minecraft:cobbled_deepslate
setblock 77 197 559 minecraft:calcite
fill 77 197 560 77 200 560 minecraft:cobbled_deepslate
setblock 78 197 558 minecraft:calcite
fill 78 197 559 78 200 559 minecraft:cobbled_deepslate
setblock 78 197 562 minecraft:cobbled_deepslate
setblock 78 197 598 minecraft:calcite
fill 79 197 558 79 200 558 minecraft:cobbled_deepslate
setblock 79 197 562 minecraft:calcite
setblock 79 197 597 minecraft:calcite
fill 79 197 598 79 200 598 minecraft:cobbled_deepslate
setblock 80 197 561 minecraft:calcite
fill 80 197 562 81 197 562 minecraft:cobbled_deepslate
fill 80 197 597 80 198 597 minecraft:cobbled_deepslate
setblock 81 197 560 minecraft:calcite
fill 81 197 561 81 200 561 minecraft:cobbled_deepslate
setblock 82 197 559 minecraft:calcite
fill 82 197 560 82 200 560 minecraft:cobbled_deepslate
setblock 83 197 558 minecraft:calcite
fill 83 197 559 83 200 559 minecraft:cobbled_deepslate
setblock 83 197 598 minecraft:calcite
fill 84 197 558 84 200 558 minecraft:cobbled_deepslate
setblock 84 197 597 minecraft:calcite
fill 84 197 598 84 200 598 minecraft:cobbled_deepslate
setblock 86 197 560 minecraft:calcite
fill 86 197 561 86 198 562 minecraft:cobbled_deepslate
setblock 87 197 559 minecraft:calcite
fill 87 197 560 87 200 560 minecraft:cobbled_deepslate
setblock 87 197 564 minecraft:calcite
setblock 88 197 558 minecraft:calcite
fill 88 197 559 88 200 559 minecraft:cobbled_deepslate
setblock 88 197 563 minecraft:calcite
fill 88 197 564 88 200 564 minecraft:cobbled_deepslate
setblock 88 197 583 minecraft:calcite
fill 88 197 584 88 199 584 minecraft:cobbled_deepslate
setblock 88 197 598 minecraft:calcite
fill 48 198 558 48 199 558 minecraft:cobbled_deepslate
setblock 48 198 562 minecraft:calcite
fill 48 198 563 48 199 563 minecraft:cobbled_deepslate
fill 48 198 579 48 198 581 minecraft:cobbled_deepslate
setblock 48 198 582 minecraft:calcite
fill 48 198 583 48 201 583 minecraft:cobbled_deepslate
setblock 48 198 586 minecraft:cobbled_deepslate
setblock 48 198 587 minecraft:calcite
fill 48 198 588 48 201 588 minecraft:cobbled_deepslate
setblock 48 198 596 minecraft:cobbled_deepslate
setblock 48 198 597 minecraft:calcite
fill 48 198 598 51 198 598 minecraft:cobbled_deepslate
fill 49 198 582 49 200 582 minecraft:cobbled_deepslate
setblock 49 198 586 minecraft:calcite
fill 49 198 587 49 201 587 minecraft:cobbled_deepslate
setblock 52 198 558 minecraft:calcite
setblock 52 198 598 minecraft:calcite
fill 53 198 558 53 201 558 minecraft:cobbled_deepslate
setblock 53 198 597 minecraft:calcite
fill 53 198 598 53 201 598 minecraft:cobbled_deepslate
fill 54 198 597 54 199 597 minecraft:cobbled_deepslate
setblock 56 198 559 minecraft:calcite
setblock 57 198 558 minecraft:calcite
fill 57 198 559 57 200 559 minecraft:cobbled_deepslate
setblock 57 198 598 minecraft:calcite
fill 58 198 558 58 201 558 minecraft:cobbled_deepslate
setblock 58 198 597 minecraft:calcite
fill 58 198 598 58 200 598 minecraft:cobbled_deepslate
setblock 59 198 560 minecraft:cobbled_deepslate
setblock 59 198 597 minecraft:cobbled_deepslate
setblock 61 198 559 minecraft:calcite
setblock 62 198 558 minecraft:calcite
setblock 62 198 559 minecraft:cobbled_deepslate
setblock 62 198 598 minecraft:calcite
fill 63 198 558 63 199 558 minecraft:cobbled_deepslate
setblock 67 198 558 minecraft:calcite
fill 68 198 558 71 198 558 minecraft:cobbled_deepslate
setblock 71 198 559 minecraft:calcite
setblock 72 198 558 minecraft:calcite
fill 72 198 559 72 201 559 minecraft:cobbled_deepslate
fill 73 198 558 73 201 558 minecraft:cobbled_deepslate
setblock 74 198 560 minecraft:cobbled_deepslate
setblock 74 198 561 minecraft:calcite
setblock 75 198 560 minecraft:calcite
fill 75 198 561 78 198 561 minecraft:cobbled_deepslate
setblock 76 198 559 minecraft:calcite
fill 76 198 560 76 201 560 minecraft:cobbled_deepslate
setblock 77 198 558 minecraft:calcite
fill 77 198 559 77 201 559 minecraft:cobbled_deepslate
setblock 77 198 562 minecraft:cobbled_deepslate
setblock 77 198 598 minecraft:calcite
fill 78 198 558 78 201 558 minecraft:cobbled_deepslate
setblock 78 198 562 minecraft:calcite
setblock 78 198 597 minecraft:calcite
fill 78 198 598 78 201 598 minecraft:cobbled_deepslate
setblock 79 198 561 minecraft:calcite
fill 79 198 562 80 198 562 minecraft:cobbled_deepslate
setblock 79 198 597 minecraft:cobbled_deepslate
setblock 80 198 560 minecraft:calcite
fill 80 198 561 80 200 561 minecraft:cobbled_deepslate
setblock 81 198 559 minecraft:calcite
fill 81 198 560 81 201 560 minecraft:cobbled_deepslate
setblock 82 198 558 minecraft:calcite
fill 82 198 559 82 201 559 minecraft:cobbled_deepslate
setblock 82 198 598 minecraft:calcite
fill 83 198 558 83 201 558 minecraft:cobbled_deepslate
fill 83 198 598 83 200 598 minecraft:cobbled_deepslate
setblock 85 198 560 minecraft:calcite
setblock 86 198 559 minecraft:calcite
setblock 86 198 560 minecraft:cobbled_deepslate
setblock 87 198 558 minecraft:calcite
fill 87 198 559 87 200 559 minecraft:cobbled_deepslate
setblock 87 198 563 minecraft:calcite
setblock 87 198 564 minecraft:cobbled_deepslate
setblock 87 198 598 minecraft:calcite
fill 88 198 558 88 201 558 minecraft:cobbled_deepslate
setblock 88 198 562 minecraft:calcite
fill 88 198 563 88 201 563 minecraft:cobbled_deepslate
setblock 88 198 582 minecraft:calcite
setblock 88 198 583 minecraft:cobbled_deepslate
fill 88 198 585 88 199 585 minecraft:cobbled_deepslate
setblock 88 198 597 minecraft:calcite
fill 88 198 598 88 199 598 minecraft:cobbled_deepslate
setblock 48 199 561 minecraft:calcite
setblock 48 199 562 minecraft:cobbled_deepslate
setblock 48 199 580 minecraft:cobbled_deepslate
setblock 48 199 581 minecraft:calcite
fill 48 199 582 48 202 582 minecraft:cobbled_deepslate
setblock 48 199 586 minecraft:calcite
fill 48 199 587 48 202 587 minecraft:cobbled_deepslate
fill 48 199 589 48 199 590 minecraft:cobbled_deepslate
setblock 48 199 591 minecraft:calcite
fill 48 199 597 48 199 598 minecraft:cobbled_deepslate
setblock 49 199 585 minecraft:calcite
fill 49 199 586 49 202 586 minecraft:cobbled_deepslate
fill 49 199 598 50 199 598 minecraft:cobbled_deepslate
setblock 51 199 558 minecraft:calcite
setblock 51 199 598 minecraft:calcite
fill 52 199 558 52 200 558 minecraft:cobbled_deepslate
fill 52 199 598 52 201 598 minecraft:cobbled_deepslate
setblock 55 199 559 minecraft:calcite
setblock 56 199 558 minecraft:calcite
fill 56 199 559 56 200 559 minecraft:cobbled_deepslate
setblock 56 199 598 minecraft:calcite
fill 57 199 558 57 202 558 minecraft:cobbled_deepslate
setblock 57 199 597 minecraft:calcite
fill 57 199 598 57 201 598 minecraft:cobbled_deepslate
setblock 58 199 597 minecraft:cobbled_deepslate
setblock 60 199 559 minecraft:calcite
setblock 61 199 558 minecraft:calcite
setblock 61 199 559 minecraft:cobbled_deepslate
setblock 61 199 598 minecraft:calcite
setblock 62 199 558 minecraft:cobbled_deepslate
fill 69 199 558 70 199 558 minecraft:cobbled_deepslate
setblock 71 199 558 minecraft:calcite
fill 71 199 559 71 200 559 minecraft:cobbled_deepslate
fill 72 199 558 72 202 558 minecraft:cobbled_deepslate
setblock 74 199 560 minecraft:calcite
fill 74 199 561 77 199 561 minecraft:cobbled_deepslate
setblock 75 199 559 minecraft:calcite
fill 75 199 560 75 202 560 minecraft:cobbled_deepslate
setblock 76 199 558 minecraft:calcite
fill 76 199 559 76 202 559 minecraft:cobbled_deepslate
setblock 76 199 598 minecraft:calcite
fill 77 199 558 77 202 558 minecraft:cobbled_deepslate
setblock 77 199 562 minecraft:calcite
fill 77 199 598 77 202 598 minecraft:cobbled_deepslate
setblock 78 199 561 minecraft:calcite
fill 78 199 562 79 199 562 minecraft:cobbled_deepslate
setblock 79 199 560 minecraft:calcite
fill 79 199 561 79 201 561 minecraft:cobbled_deepslate
setblock 80 199 559 minecraft:calcite
fill 80 199 560 80 202 560 minecraft:cobbled_deepslate
setblock 81 199 558 minecraft:calcite
fill 81 199 559 81 202 559 minecraft:cobbled_deepslate
setblock 81 199 598 minecraft:calcite
fill 82 199 558 82 202 558 minecraft:cobbled_deepslate
fill 82 199 598 82 200 598 minecraft:cobbled_deepslate
setblock 84 199 560 minecraft:calcite
setblock 85 199 559 minecraft:calcite
setblock 85 199 560 minecraft:cobbled_deepslate
setblock 86 199 558 minecraft:calcite
fill 86 199 559 86 200 559 minecraft:cobbled_deepslate
setblock 86 199 598 minecraft:calcite
fill 87 199 558 87 201 558 minecraft:cobbled_deepslate
setblock 87 199 562 minecraft:calcite
setblock 87 199 563 minecraft:cobbled_deepslate
setblock 87 199 598 minecraft:cobbled_deepslate
setblock 88 199 561 minecraft:calcite
fill 88 199 562 88 202 562 minecraft:cobbled_deepslate
setblock 88 199 565 minecraft:cobbled_deepslate
setblock 48 200 561 minecraft:cobbled_deepslate
fill 48 200 581 48 201 581 minecraft:cobbled_deepslate
setblock 48 200 584 minecraft:cobbled_deepslate
setblock 48 200 585 minecraft:calcite
fill 48 200 586 48 203 586 minecraft:cobbled_deepslate
setblock 48 200 589 minecraft:cobbled_deepslate
setblock 48 200 590 minecraft:calcite
fill 48 200 591 48 203 591 minecraft:cobbled_deepslate
setblock 49 200 584 minecraft:calcite
fill 49 200 585 49 203 585 minecraft:cobbled_deepslate
setblock 49 200 588 minecraft:cobbled_deepslate
setblock 50 200 598 minecraft:calcite
setblock 51 200 558 minecraft:cobbled_deepslate
setblock 51 200 598 minecraft:cobbled_deepslate
setblock 55 200 558 minecraft:calcite
setblock 55 200 559 minecraft:cobbled_deepslate
setblock 55 200 598 minecraft:calcite
fill 56 200 558 56 202 558 minecraft:cobbled_deepslate
fill 56 200 598 56 201 598 minecraft:cobbled_deepslate
setblock 59 200 559 minecraft:calcite
setblock 60 200 558 minecraft:calcite
setblock 61 200 558 minecraft:cobbled_deepslate
setblock 70 200 558 minecraft:calcite
fill 71 200 558 71 203 558 minecraft:cobbled_deepslate
setblock 73 200 560 minecraft:calcite
setblock 74 200 559 minecraft:calcite
fill 74 200 560 74 200 561 minecraft:cobbled_deepslate
setblock 75 200 558 minecraft:calcite
fill 75 200 559 75 203 559 minecraft:cobbled_deepslate
fill 75 200 561 76 200 561 minecraft:cobbled_deepslate
setblock 75 200 598 minecraft:calcite
fill 76 200 558 76 203 558 minecraft:cobbled_deepslate
fill 76 200 598 76 202 598 minecraft:cobbled_deepslate
setblock 77 200 561 minecraft:calcite
setblock 78 200 560 minecraft:calcite
fill 78 200 561 78 201 561 minecraft:cobbled_deepslate
setblock 79 200 559 minecraft:calcite
fill 79 200 560 79 203 560 minecraft:cobbled_deepslate
setblock 80 200 558 minecraft:calcite
fill 80 200 559 80 203 559 minecraft:cobbled_deepslate
setblock 80 200 598 minecraft:calcite
fill 81 200 558 81 203 558 minecraft:cobbled_deepslate
fill 81 200 598 81 201 598 minecraft:cobbled_deepslate
setblock 83 200 560 minecraft:calcite
setblock 84 200 559 minecraft:calcite
setblock 85 200 558 minecraft:calcite
setblock 85 200 559 minecraft:cobbled_deepslate
fill 86 200 558 86 201 558 minecraft:cobbled_deepslate
setblock 87 200 561 minecraft:calcite
setblock 87 200 562 minecraft:cobbled_deepslate
setblock 88 200 560 minecraft:calcite
fill 88 200 561 88 203 561 minecraft:cobbled_deepslate
setblock 88 200 565 minecraft:calcite
setblock 88 200 585 minecraft:calcite
fill 88 200 586 88 203 586 minecraft:cobbled_deepslate
setblock 48 201 584 minecraft:calcite
fill 48 201 585 48 204 585 minecraft:cobbled_deepslate
setblock 48 201 589 minecraft:calcite
fill 48 201 590 48 204 590 minecraft:cobbled_deepslate
setblock 49 201 583 minecraft:calcite
fill 49 201 584 49 204 584 minecraft:cobbled_deepslate
setblock 49 201 588 minecraft:calcite
fill 49 201 589 49 204 589 minecraft:cobbled_deepslate
setblock 54 201 558 minecraft:calcite
setblock 54 201 598 minecraft:calcite
fill 55 201 558 55 202 558 minecraft:cobbled_deepslate
fill 55 201 598 55 202 598 minecraft:cobbled_deepslate
setblock 59 201 558 minecraft:calcite
setblock 73 201 559 minecraft:calcite
fill 73 201 560 74 202 560 minecraft:cobbled_deepslate
setblock 74 201 558 minecraft:calcite
fill 74 201 559 74 204 559 minecraft:cobbled_deepslate
fill 75 201 558 75 204 558 minecraft:cobbled_deepslate
setblock 75 201 561 minecraft:cobbled_deepslate
setblock 75 201 598 minecraft:cobbled_deepslate
setblock 76 201 561 minecraft:calcite
setblock 77 201 560 minecraft:calcite
fill 77 201 561 77 202 561 minecraft:cobbled_deepslate
setblock 78 201 559 minecraft:calcite
fill 78 201 560 78 203 560 minecraft:cobbled_deepslate
setblock 79 201 558 minecraft:calcite
fill 79 201 559 79 204 559 minecraft:cobbled_deepslate
setblock 79 201 598 minecraft:calcite
fill 80 201 558 80 204 558 minecraft:cobbled_deepslate
setblock 80 201 598 minecraft:cobbled_deepslate
setblock 82 201 560 minecraft:calcite
setblock 83 201 559 minecraft:calcite
setblock 84 201 558 minecraft:calcite
setblock 84 201 559 minecraft:cobbled_deepslate
fill 85 201 558 85 202 558 minecraft:cobbled_deepslate
setblock 88 201 559 minecraft:calcite
fill 88 201 560 88 202 560 minecraft:cobbled_deepslate
setblock 88 201 564 minecraft:calcite
fill 88 201 565 88 204 565 minecraft:cobbled_deepslate
fill 88 201 587 88 202 587 minecraft:cobbled_deepslate
setblock 48 202 583 minecraft:calcite
fill 48 202 584 48 205 584 minecraft:cobbled_deepslate
setblock 48 202 588 minecraft:calcite
fill 48 202 589 48 205 589 minecraft:cobbled_deepslate
setblock 48 202 592 minecraft:cobbled_deepslate
fill 49 202 583 49 205 583 minecraft:cobbled_deepslate
setblock 49 202 587 minecraft:calcite
fill 49 202 588 49 205 588 minecraft:cobbled_deepslate
setblock 50 202 586 minecraft:calcite
setblock 53 202 598 minecraft:calcite
setblock 54 202 558 minecraft:cobbled_deepslate
setblock 54 202 598 minecraft:cobbled_deepslate
setblock 72 202 559 minecraft:calcite
setblock 73 202 558 minecraft:calcite
fill 73 202 559 73 205 559 minecraft:cobbled_deepslate
fill 74 202 558 74 205 558 minecraft:cobbled_deepslate
setblock 76 202 560 minecraft:calcite
setblock 76 202 561 minecraft:cobbled_deepslate
setblock 77 202 559 minecraft:calcite
fill 77 202 560 77 204 560 minecraft:cobbled_deepslate
setblock 78 202 558 minecraft:calcite
fill 78 202 559 78 205 559 minecraft:cobbled_deepslate
setblock 78 202 598 minecraft:calcite
fill 79 202 558 79 205 558 minecraft:cobbled_deepslate
setblock 79 202 598 minecraft:cobbled_deepslate
setblock 82 202 559 minecraft:calcite
setblock 83 202 558 minecraft:calcite
setblock 84 202 558 minecraft:cobbled_deepslate
setblock 88 202 559 minecraft:cobbled_deepslate
setblock 88 202 563 minecraft:calcite
fill 88 202 564 88 205 564 minecraft:cobbled_deepslate
setblock 88 202 588 minecraft:calcite
setblock 48 203 582 minecraft:calcite
fill 48 203 583 48 206 583 minecraft:cobbled_deepslate
setblock 48 203 587 minecraft:calcite
fill 48 203 588 48 206 588 minecraft:cobbled_deepslate
setblock 48 203 592 minecraft:calcite
setblock 49 203 586 minecraft:calcite
fill 49 203 587 50 205 587 minecraft:cobbled_deepslate
setblock 49 203 590 minecraft:cobbled_deepslate
setblock 50 203 585 minecraft:calcite
fill 50 203 586 50 206 586 minecraft:cobbled_deepslate
fill 50 203 588 50 204 588 minecraft:cobbled_deepslate
setblock 72 203 558 minecraft:calcite
fill 72 203 559 72 206 559 minecraft:cobbled_deepslate
fill 73 203 558 73 206 558 minecraft:cobbled_deepslate
setblock 74 203 560 minecraft:cobbled_deepslate
setblock 75 203 560 minecraft:calcite
setblock 76 203 559 minecraft:calcite
fill 76 203 560 76 205 560 minecraft:cobbled_deepslate
setblock 77 203 558 minecraft:calcite
fill 77 203 559 77 206 559 minecraft:cobbled_deepslate
setblock 77 203 598 minecraft:calcite
fill 78 203 558 78 206 558 minecraft:cobbled_deepslate
setblock 81 203 559 minecraft:calcite
setblock 82 203 558 minecraft:calcite
setblock 83 203 558 minecraft:cobbled_deepslate
setblock 88 203 562 minecraft:calcite
fill 88 203 563 88 206 563 minecraft:cobbled_deepslate
fill 88 203 585 88 204 585 minecraft:cobbled_deepslate
setblock 88 203 587 minecraft:calcite
fill 88 203 588 88 204 590 minecraft:cobbled_deepslate
fill 48 204 582 48 207 582 minecraft:cobbled_deepslate
setblock 48 204 586 minecraft:calcite
fill 48 204 587 48 207 587 minecraft:cobbled_deepslate
setblock 48 204 591 minecraft:calcite
fill 48 204 592 48 206 593 minecraft:cobbled_deepslate
setblock 49 204 585 minecraft:calcite
fill 49 204 586 49 207 586 minecraft:cobbled_deepslate
setblock 49 204 590 minecraft:calcite
fill 49 204 591 49 207 591 minecraft:cobbled_deepslate
setblock 50 204 560 minecraft:light[level=14]
setblock 50 204 568 minecraft:light[level=14]
setblock 50 204 576 minecraft:light[level=14]
fill 50 204 585 50 207 585 minecraft:cobbled_deepslate
setblock 50 204 589 minecraft:calcite
setblock 50 204 592 minecraft:light[level=14]
setblock 58 204 560 minecraft:light[level=14]
setblock 58 204 568 minecraft:light[level=14]
setblock 58 204 576 minecraft:light[level=14]
setblock 58 204 584 minecraft:light[level=14]
setblock 58 204 592 minecraft:light[level=14]
setblock 66 204 560 minecraft:light[level=14]
setblock 66 204 568 minecraft:light[level=14]
setblock 66 204 576 minecraft:light[level=14]
setblock 66 204 584 minecraft:light[level=14]
setblock 66 204 592 minecraft:light[level=14]
setblock 71 204 558 minecraft:calcite
fill 72 204 558 72 207 558 minecraft:cobbled_deepslate
setblock 74 204 560 minecraft:calcite
setblock 74 204 568 minecraft:light[level=14]
setblock 74 204 576 minecraft:light[level=14]
setblock 74 204 584 minecraft:light[level=14]
setblock 74 204 592 minecraft:light[level=14]
setblock 75 204 559 minecraft:calcite
fill 75 204 560 75 206 560 minecraft:cobbled_deepslate
setblock 76 204 558 minecraft:calcite
fill 76 204 559 76 207 559 minecraft:cobbled_deepslate
fill 77 204 558 77 207 558 minecraft:cobbled_deepslate
setblock 81 204 558 minecraft:calcite
setblock 82 204 560 minecraft:light[level=14]
setblock 82 204 568 minecraft:light[level=14]
setblock 82 204 576 minecraft:light[level=14]
setblock 82 204 584 minecraft:light[level=14]
setblock 82 204 592 minecraft:light[level=14]
setblock 88 204 562 minecraft:cobbled_deepslate
setblock 88 204 586 minecraft:calcite
fill 88 204 587 88 207 587 minecraft:cobbled_deepslate
setblock 88 204 591 minecraft:calcite
fill 88 204 592 88 207 592 minecraft:cobbled_deepslate
setblock 47 205 559 minecraft:deepslate
setblock 47 205 565 minecraft:deepslate
setblock 47 205 574 minecraft:deepslate
fill 47 205 575 47 206 582 minecraft:cobbled_deepslate
fill 47 205 583 47 207 583 minecraft:deepslate
fill 47 205 584 47 206 586 minecraft:cobbled_deepslate
fill 47 205 587 47 206 587 minecraft:deepslate
fill 47 205 588 47 205 593 minecraft:cobbled_deepslate
setblock 48 205 585 minecraft:calcite
fill 48 205 586 48 208 586 minecraft:cobbled_deepslate
setblock 48 205 590 minecraft:calcite
fill 48 205 591 48 208 591 minecraft:cobbled_deepslate
setblock 48 205 594 minecraft:cobbled_deepslate
setblock 49 205 584 minecraft:calcite
fill 49 205 585 49 208 585 minecraft:cobbled_deepslate
setblock 49 205 589 minecraft:calcite
fill 49 205 590 50 207 590 minecraft:cobbled_deepslate
fill 49 205 592 49 206 592 minecraft:cobbled_deepslate
setblock 50 205 588 minecraft:calcite
fill 50 205 589 50 208 589 minecraft:cobbled_deepslate
fill 50 205 591 50 206 591 minecraft:cobbled_deepslate
fill 51 205 599 51 206 599 minecraft:cobbled_deepslate
setblock 52 205 599 minecraft:deepslate
setblock 56 205 557 minecraft:deepslate
fill 57 205 557 59 208 557 minecraft:cobbled_deepslate
setblock 59 205 599 minecraft:deepslate
setblock 60 205 557 minecraft:deepslate
fill 60 205 599 60 206 599 minecraft:cobbled_deepslate
fill 61 205 557 62 208 557 minecraft:cobbled_deepslate
fill 69 205 599 75 208 599 minecraft:cobbled_deepslate
setblock 70 205 558 minecraft:calcite
fill 71 205 558 71 208 558 minecraft:cobbled_deepslate
setblock 73 205 557 minecraft:deepslate
fill 74 205 557 78 208 557 minecraft:cobbled_deepslate
setblock 74 205 559 minecraft:calcite
fill 74 205 560 74 208 560 minecraft:cobbled_deepslate
setblock 75 205 558 minecraft:calcite
fill 75 205 559 75 208 559 minecraft:cobbled_deepslate
setblock 75 205 598 minecraft:calcite
fill 76 205 558 76 208 558 minecraft:cobbled_deepslate
fill 76 205 598 77 207 598 minecraft:cobbled_deepslate
fill 76 205 599 76 206 599 minecraft:deepslate
setblock 80 205 558 minecraft:calcite
setblock 81 205 558 minecraft:cobbled_deepslate
setblock 88 205 565 minecraft:calcite
fill 88 205 566 88 208 566 minecraft:cobbled_deepslate
setblock 88 205 585 minecraft:calcite
fill 88 205 586 88 208 586 minecraft:cobbled_deepslate
fill 88 205 588 88 205 589 minecraft:cobbled_deepslate
setblock 88 205 590 minecraft:calcite
fill 88 205 591 88 208 591 minecraft:cobbled_deepslate
fill 88 205 593 88 205 594 minecraft:cobbled_deepslate
setblock 88 205 595 minecraft:calcite
fill 89 205 560 89 205 561 minecraft:deepslate
fill 89 205 562 89 208 564 minecraft:cobbled_deepslate
setblock 89 205 566 minecraft:deepslate
fill 89 205 569 89 208 569 minecraft:cobbled_deepslate
setblock 89 205 570 minecraft:deepslate
fill 47 206 559 47 209 559 minecraft:cobbled_deepslate
setblock 47 206 565 minecraft:cobbled_deepslate
fill 47 206 566 47 207 566 minecraft:deepslate
fill 47 206 567 47 208 571 minecraft:cobbled_deepslate
setblock 47 206 572 minecraft:deepslate
fill 47 206 574 47 208 574 minecraft:cobbled_deepslate
fill 47 206 588 47 208 591 minecraft:cobbled_deepslate
setblock 47 206 592 minecraft:deepslate
fill 47 206 593 47 208 593 minecraft:cobbled_deepslate
setblock 48 206 557 minecraft:deepslate
fill 48 206 566 48 206 568 minecraft:cobbled_deepslate
setblock 48 206 569 minecraft:calcite
fill 48 206 581 48 208 581 minecraft:cobbled_deepslate
setblock 48 206 584 minecraft:calcite
fill 48 206 585 48 209 585 minecraft:cobbled_deepslate
setblock 48 206 589 minecraft:calcite
fill 48 206 590 48 209 590 minecraft:cobbled_deepslate
setblock 48 206 594 minecraft:calcite
fill 48 206 595 48 208 596 minecraft:cobbled_deepslate
fill 49 206 583 51 206 583 minecraft:calcite
fill 49 206 584 50 208 584 minecraft:cobbled_deepslate
setblock 49 206 587 minecraft:cobbled_deepslate
setblock 49 206 588 minecraft:calcite
fill 49 206 589 49 209 589 minecraft:cobbled_deepslate
setblock 49 206 593 minecraft:calcite
fill 49 206 594 49 209 594 minecraft:cobbled_deepslate
setblock 50 206 587 minecraft:calcite
fill 50 206 588 51 208 588 minecraft:cobbled_deepslate
setblock 50 206 592 minecraft:calcite
fill 51 206 584 51 226 584 minecraft:calcite
setblock 51 206 586 minecraft:calcite
fill 51 206 587 51 209 587 minecraft:cobbled_deepslate
fill 51 206 589 51 207 589 minecraft:cobbled_deepslate
fill 52 206 598 52 207 599 minecraft:cobbled_deepslate
setblock 53 206 598 minecraft:cobbled_deepslate
fill 56 206 557 56 208 557 minecraft:cobbled_deepslate
setblock 58 206 599 minecraft:deepslate
fill 59 206 599 59 208 599 minecraft:cobbled_deepslate
fill 60 206 557 60 208 557 minecraft:cobbled_deepslate
fill 67 206 557 70 208 557 minecraft:cobbled_deepslate
setblock 67 206 599 minecraft:deepslate
fill 70 206 558 70 209 558 minecraft:cobbled_deepslate
setblock 71 206 557 minecraft:deepslate
fill 71 206 559 71 207 559 minecraft:cobbled_deepslate
fill 73 206 557 73 208 557 minecraft:cobbled_deepslate
setblock 73 206 559 minecraft:calcite
setblock 73 206 598 minecraft:cobbled_deepslate
setblock 74 206 558 minecraft:calcite
fill 74 206 559 74 209 559 minecraft:cobbled_deepslate
setblock 74 206 598 minecraft:calcite
fill 75 206 558 75 209 558 minecraft:cobbled_deepslate
fill 75 206 598 75 209 598 minecraft:cobbled_deepslate
setblock 78 206 559 minecraft:calcite
setblock 78 206 598 minecraft:cobbled_deepslate
setblock 79 206 558 minecraft:calcite
fill 80 206 558 80 209 558 minecraft:cobbled_deepslate
fill 82 206 599 83 206 599 minecraft:cobbled_deepslate
setblock 84 206 599 minecraft:deepslate
fill 85 206 599 86 206 599 minecraft:cobbled_deepslate
fill 87 206 588 87 206 589 minecraft:cobbled_deepslate
setblock 87 206 590 minecraft:calcite
fill 87 206 591 87 209 591 minecraft:cobbled_deepslate
fill 88 206 562 88 207 562 minecraft:cobbled_deepslate
setblock 88 206 564 minecraft:calcite
fill 88 206 565 88 209 565 minecraft:cobbled_deepslate
fill 88 206 567 88 206 568 minecraft:cobbled_deepslate
setblock 88 206 584 minecraft:calcite
fill 88 206 585 88 209 585 minecraft:cobbled_deepslate
setblock 88 206 588 minecraft:cobbled_deepslate
setblock 88 206 589 minecraft:calcite
fill 88 206 590 88 209 590 minecraft:cobbled_deepslate
setblock 88 206 593 minecraft:cobbled_deepslate
setblock 88 206 594 minecraft:calcite
fill 88 206 595 88 207 597 minecraft:cobbled_deepslate
fill 89 206 560 89 208 561 minecraft:cobbled_deepslate
setblock 89 206 565 minecraft:deepslate
fill 89 206 566 89 208 566 minecraft:cobbled_deepslate
setblock 89 206 567 minecraft:deepslate
fill 89 206 570 89 208 570 minecraft:cobbled_deepslate
setblock 89 206 572 minecraft:deepslate
fill 89 206 584 89 209 584 minecraft:cobbled_deepslate
setblock 89 206 585 minecraft:deepslate
setblock 89 206 589 minecraft:deepslate
setblock 47 207 558 minecraft:deepslate
fill 47 207 560 47 208 561 minecraft:cobbled_deepslate
setblock 47 207 562 minecraft:deepslate
fill 47 207 563 47 208 563 minecraft:cobbled_deepslate
fill 47 207 564 47 207 565 minecraft:deepslate
fill 47 207 572 48 207 572 minecraft:cobbled_deepslate
setblock 47 207 575 minecraft:deepslate
fill 47 207 576 47 208 582 minecraft:cobbled_deepslate
fill 47 207 584 47 208 585 minecraft:cobbled_deepslate
setblock 47 207 586 minecraft:deepslate
fill 47 207 587 47 208 587 minecraft:cobbled_deepslate
fill 47 207 592 48 207 592 minecraft:cobbled_deepslate
setblock 47 207 599 minecraft:deepslate
fill 48 207 557 48 208 557 minecraft:cobbled_deepslate
fill 48 207 564 48 207 567 minecraft:cobbled_deepslate
setblock 48 207 568 minecraft:calcite
fill 48 207 569 48 208 571 minecraft:cobbled_deepslate
setblock 48 207 573 minecraft:calcite
fill 48 207 580 48 209 580 minecraft:cobbled_deepslate
setblock 48 207 583 minecraft:calcite
fill 48 207 584 48 210 584 minecraft:cobbled_deepslate
setblock 48 207 588 minecraft:calcite
fill 48 207 589 48 210 589 minecraft:cobbled_deepslate
setblock 48 207 593 minecraft:calcite
fill 48 207 594 48 210 594 minecraft:cobbled_deepslate
setblock 48 207 597 minecraft:cobbled_deepslate
setblock 49 207 557 minecraft:deepslate
setblock 49 207 567 minecraft:calcite
fill 49 207 568 49 209 569 minecraft:cobbled_deepslate
setblock 49 207 582 minecraft:calcite
fill 49 207 583 49 210 583 minecraft:cobbled_deepslate
setblock 49 207 587 minecraft:calcite
fill 49 207 588 49 210 588 minecraft:cobbled_deepslate
setblock 49 207 592 minecraft:calcite
fill 49 207 593 50 209 593 minecraft:cobbled_deepslate
fill 49 207 595 49 208 595 minecraft:cobbled_deepslate
fill 49 207 598 51 208 598 minecraft:cobbled_deepslate
fill 50 207 557 50 208 557 minecraft:cobbled_deepslate
fill 50 207 583 51 207 583 minecraft:calcite
setblock 50 207 586 minecraft:calcite
fill 50 207 587 50 210 587 minecraft:cobbled_deepslate
setblock 50 207 591 minecraft:calcite
fill 50 207 592 50 210 592 minecraft:cobbled_deepslate
setblock 51 207 557 minecraft:deepslate
fill 51 207 586 51 210 586 minecraft:cobbled_deepslate
setblock 51 207 590 minecraft:calcite
fill 51 207 591 51 210 591 minecraft:cobbled_deepslate
setblock 51 207 599 minecraft:deepslate
fill 52 207 557 53 208 557 minecraft:cobbled_deepslate
setblock 53 207 598 minecraft:calcite
fill 54 207 598 54 208 599 minecraft:cobbled_deepslate
setblock 55 207 599 minecraft:deepslate
fill 56 207 599 56 208 599 minecraft:cobbled_deepslate
fill 58 207 599 58 208 599 minecraft:cobbled_deepslate
setblock 60 207 599 minecraft:deepslate
setblock 66 207 557 minecraft:deepslate
fill 67 207 599 67 208 599 minecraft:cobbled_deepslate
fill 69 207 558 69 210 558 minecraft:cobbled_deepslate
fill 71 207 557 71 208 557 minecraft:cobbled_deepslate
setblock 72 207 559 minecraft:calcite
setblock 72 207 598 minecraft:cobbled_deepslate
setblock 73 207 558 minecraft:calcite
fill 73 207 559 73 209 560 minecraft:cobbled_deepslate
setblock 73 207 598 minecraft:calcite
fill 74 207 558 74 210 558 minecraft:cobbled_deepslate
fill 74 207 598 74 210 598 minecraft:cobbled_deepslate
fill 76 207 599 76 208 599 minecraft:cobbled_deepslate
setblock 77 207 559 minecraft:calcite
setblock 78 207 558 minecraft:calcite
setblock 78 207 598 minecraft:calcite
fill 79 207 558 79 210 558 minecraft:cobbled_deepslate
fill 79 207 598 79 210 598 minecraft:cobbled_deepslate
fill 82 207 599 82 209 599 minecraft:cobbled_deepslate
setblock 83 207 599 minecraft:deepslate
fill 84 207 599 84 208 599 minecraft:cobbled_deepslate
setblock 85 207 599 minecraft:deepslate
fill 86 207 582 87 216 584 minecraft:light_blue_stained_glass
fill 86 207 599 86 208 599 minecraft:cobbled_deepslate
fill 87 207 587 87 207 588 minecraft:cobbled_deepslate
setblock 87 207 589 minecraft:calcite
fill 87 207 590 87 210 590 minecraft:cobbled_deepslate
fill 87 207 592 87 207 593 minecraft:cobbled_deepslate
setblock 87 207 594 minecraft:calcite
setblock 87 207 598 minecraft:cobbled_deepslate
setblock 88 207 563 minecraft:calcite
fill 88 207 564 88 210 564 minecraft:cobbled_deepslate
fill 88 207 567 89 207 567 minecraft:cobbled_deepslate
setblock 88 207 568 minecraft:calcite
fill 88 207 569 88 209 570 minecraft:cobbled_deepslate
fill 88 207 582 88 207 583 minecraft:light_blue_stained_glass
fill 88 207 584 88 210 584 minecraft:cobbled_deepslate
setblock 88 207 588 minecraft:calcite
fill 88 207 589 89 208 589 minecraft:cobbled_deepslate
setblock 88 207 593 minecraft:calcite
fill 88 207 594 88 210 594 minecraft:cobbled_deepslate
setblock 88 207 598 minecraft:calcite
setblock 88 207 599 minecraft:deepslate
fill 89 207 565 89 208 565 minecraft:cobbled_deepslate
fill 89 207 572 89 208 572 minecraft:cobbled_deepslate
fill 89 207 579 89 208 580 minecraft:cobbled_deepslate
setblock 89 207 581 minecraft:deepslate
fill 89 207 582 89 208 582 minecraft:cobbled_deepslate
fill 89 207 585 89 208 585 minecraft:cobbled_deepslate
setblock 89 207 595 minecraft:deepslate
fill 89 207 599 89 208 599 minecraft:cobbled_deepslate
setblock 47 208 558 minecraft:cobbled_deepslate
setblock 47 208 562 minecraft:cobbled_deepslate
fill 47 208 564 48 208 566 minecraft:cobbled_deepslate
setblock 47 208 572 minecraft:cobbled_deepslate
fill 47 208 575 48 208 575 minecraft:cobbled_deepslate
fill 47 208 583 48 208 583 minecraft:cobbled_deepslate
setblock 47 208 586 minecraft:cobbled_deepslate
setblock 47 208 592 minecraft:cobbled_deepslate
setblock 47 208 599 minecraft:cobbled_deepslate
setblock 48 208 567 minecraft:calcite
fill 48 208 568 48 211 568 minecraft:cobbled_deepslate
setblock 48 208 572 minecraft:calcite
fill 48 208 573 49 209 574 minecraft:cobbled_deepslate
setblock 48 208 576 minecraft:cobbled_deepslate
setblock 48 208 577 minecraft:calcite
fill 48 208 578 48 210 579 minecraft:cobbled_deepslate
setblock 48 208 582 minecraft:calcite
setblock 48 208 587 minecraft:calcite
fill 48 208 588 48 211 588 minecraft:cobbled_deepslate
setblock 48 208 592 minecraft:calcite
fill 48 208 593 48 211 593 minecraft:cobbled_deepslate
setblock 48 208 597 minecraft:calcite
fill 48 208 598 48 211 598 minecraft:cobbled_deepslate
setblock 49 208 557 minecraft:cobbled_deepslate
setblock 49 208 566 minecraft:calcite
fill 49 208 567 49 211 567 minecraft:cobbled_deepslate
setblock 49 208 570 minecraft:cobbled_deepslate
setblock 49 208 571 minecraft:calcite
fill 49 208 572 49 211 572 minecraft:cobbled_deepslate
setblock 49 208 581 minecraft:calcite
fill 49 208 582 49 211 582 minecraft:cobbled_deepslate
setblock 49 208 586 minecraft:calcite
fill 49 208 587 49 211 587 minecraft:cobbled_deepslate
setblock 49 208 590 minecraft:cobbled_deepslate
setblock 49 208 591 minecraft:calcite
fill 49 208 592 49 211 592 minecraft:cobbled_deepslate
setblock 49 208 596 minecraft:calcite
setblock 50 208 569 minecraft:cobbled_deepslate
setblock 50 208 570 minecraft:calcite
fill 50 208 583 50 209 583 minecraft:cobbled_deepslate
setblock 50 208 585 minecraft:calcite
fill 50 208 586 50 211 586 minecraft:cobbled_deepslate
setblock 50 208 590 minecraft:calcite
fill 50 208 591 50 211 591 minecraft:cobbled_deepslate
setblock 50 208 594 minecraft:cobbled_deepslate
fill 50 208 597 52 208 597 minecraft:cobbled_deepslate
setblock 51 208 557 minecraft:cobbled_deepslate
fill 51 208 583 51 226 583 minecraft:calcite
fill 51 208 585 51 210 585 minecraft:cobbled_deepslate
setblock 51 208 589 minecraft:calcite
fill 51 208 590 51 211 590 minecraft:cobbled_deepslate
fill 51 208 592 51 209 592 minecraft:cobbled_deepslate
fill 51 208 599 52 208 599 minecraft:cobbled_deepslate
setblock 52 208 598 minecraft:calcite
fill 53 208 598 53 211 598 minecraft:cobbled_deepslate
fill 55 208 598 55 208 599 minecraft:cobbled_deepslate
setblock 60 208 599 minecraft:cobbled_deepslate
setblock 66 208 557 minecraft:cobbled_deepslate
fill 68 208 558 68 211 558 minecraft:cobbled_deepslate
setblock 70 208 559 minecraft:cobbled_deepslate
fill 70 208 598 71 208 598 minecraft:cobbled_deepslate
setblock 71 208 559 minecraft:calcite
setblock 72 208 558 minecraft:calcite
fill 72 208 559 72 210 560 minecraft:cobbled_deepslate
setblock 72 208 598 minecraft:calcite
fill 73 208 558 73 211 558 minecraft:cobbled_deepslate
setblock 73 208 597 minecraft:calcite
fill 73 208 598 73 211 598 minecraft:cobbled_deepslate
fill 74 208 597 76 209 597 minecraft:cobbled_deepslate
setblock 76 208 559 minecraft:calcite
setblock 76 208 598 minecraft:cobbled_deepslate
setblock 77 208 558 minecraft:calcite
fill 77 208 559 77 209 559 minecraft:cobbled_deepslate
setblock 77 208 598 minecraft:calcite
fill 78 208 558 78 211 558 minecraft:cobbled_deepslate
fill 78 208 598 78 211 598 minecraft:cobbled_deepslate
fill 80 208 598 80 209 598 minecraft:cobbled_deepslate
setblock 83 208 599 minecraft:cobbled_deepslate
fill 84 208 582 85 211 584 minecraft:light_blue_stained_glass
fill 85 208 598 85 208 599 minecraft:cobbled_deepslate
fill 86 208 581 88 209 581 minecraft:light_blue_stained_glass
fill 86 208 585 87 209 585 minecraft:light_blue_stained_glass
setblock 86 208 598 minecraft:cobbled_deepslate
fill 87 208 586 87 208 587 minecraft:cobbled_deepslate
setblock 87 208 588 minecraft:calcite
fill 87 208 589 87 211 589 minecraft:cobbled_deepslate
setblock 87 208 592 minecraft:cobbled_deepslate
setblock 87 208 593 minecraft:calcite
fill 87 208 594 87 209 596 minecraft:cobbled_deepslate
setblock 87 208 598 minecraft:calcite
setblock 88 208 561 minecraft:cobbled_deepslate
setblock 88 208 562 minecraft:calcite
fill 88 208 563 88 211 563 minecraft:cobbled_deepslate
setblock 88 208 567 minecraft:calcite
fill 88 208 568 88 211 568 minecraft:cobbled_deepslate
setblock 88 208 571 minecraft:cobbled_deepslate
setblock 88 208 572 minecraft:calcite
setblock 88 208 582 minecraft:light_blue_stained_glass
fill 88 208 583 88 211 583 minecraft:cobbled_deepslate
setblock 88 208 587 minecraft:calcite
fill 88 208 588 88 211 588 minecraft:cobbled_deepslate
setblock 88 208 592 minecraft:calcite
fill 88 208 593 88 211 593 minecraft:cobbled_deepslate
fill 88 208 595 88 208 596 minecraft:cobbled_deepslate
setblock 88 208 597 minecraft:calcite
fill 88 208 598 88 208 599 minecraft:cobbled_deepslate
setblock 89 208 567 minecraft:cobbled_deepslate
setblock 89 208 581 minecraft:cobbled_deepslate
setblock 89 208 595 minecraft:cobbled_deepslate
fill 47 209 557 47 307 558 minecraft:deepslate
fill 47 209 560 47 209 564 minecraft:deepslate
fill 47 209 565 48 209 565 minecraft:cobbled_deepslate
fill 47 209 566 47 307 567 minecraft:deepslate
setblock 47 209 568 minecraft:cobbled_deepslate
fill 47 209 569 47 210 572 minecraft:deepslate
fill 47 209 574 47 209 593 minecraft:deepslate
setblock 47 209 594 minecraft:cobbled_deepslate
fill 47 209 595 47 209 599 minecraft:deepslate
fill 48 209 557 57 209 557 minecraft:deepslate
fill 48 209 563 48 210 564 minecraft:cobbled_deepslate
setblock 48 209 566 minecraft:calcite
fill 48 209 567 48 212 567 minecraft:cobbled_deepslate
fill 48 209 569 48 209 570 minecraft:cobbled_deepslate
setblock 48 209 571 minecraft:calcite
fill 48 209 572 48 212 572 minecraft:cobbled_deepslate
setblock 48 209 575 minecraft:cobbled_deepslate
setblock 48 209 576 minecraft:calcite
fill 48 209 577 49 211 577 minecraft:cobbled_deepslate
setblock 48 209 581 minecraft:calcite
fill 48 209 582 48 211 583 minecraft:cobbled_deepslate
setblock 48 209 586 minecraft:calcite
fill 48 209 587 48 212 587 minecraft:cobbled_deepslate
setblock 48 209 591 minecraft:calcite
fill 48 209 592 48 212 592 minecraft:cobbled_deepslate
setblock 48 209 595 minecraft:cobbled_deepslate
setblock 48 209 596 minecraft:calcite
fill 48 209 597 51 209 597 minecraft:cobbled_deepslate
fill 48 209 599 56 307 599 minecraft:deepslate
setblock 49 209 565 minecraft:calcite
fill 49 209 566 49 212 566 minecraft:cobbled_deepslate
setblock 49 209 570 minecraft:calcite
fill 49 209 571 50 211 571 minecraft:cobbled_deepslate
setblock 49 209 575 minecraft:calcite
fill 49 209 576 49 212 576 minecraft:cobbled_deepslate
fill 49 209 578 49 209 579 minecraft:cobbled_deepslate
setblock 49 209 580 minecraft:calcite
fill 49 209 581 49 212 581 minecraft:cobbled_deepslate
setblock 49 209 584 minecraft:cobbled_deepslate
setblock 49 209 585 minecraft:calcite
fill 49 209 586 49 212 586 minecraft:cobbled_deepslate
setblock 49 209 590 minecraft:calcite
fill 49 209 591 49 212 591 minecraft:cobbled_deepslate
setblock 49 209 595 minecraft:calcite
fill 49 209 596 49 212 596 minecraft:cobbled_deepslate
fill 49 209 598 50 209 598 minecraft:cobbled_deepslate
fill 50 209 567 50 209 568 minecraft:cobbled_deepslate
setblock 50 209 569 minecraft:calcite
fill 50 209 570 50 212 570 minecraft:cobbled_deepslate
fill 50 209 572 50 209 573 minecraft:cobbled_deepslate
setblock 50 209 574 minecraft:calcite
fill 50 209 582 50 210 582 minecraft:cobbled_deepslate
setblock 50 209 584 minecraft:calcite
fill 50 209 585 50 212 585 minecraft:cobbled_deepslate
setblock 50 209 588 minecraft:cobbled_deepslate
setblock 50 209 589 minecraft:calcite
fill 50 209 590 50 212 590 minecraft:cobbled_deepslate
setblock 50 209 594 minecraft:calcite
fill 50 209 595 50 212 595 minecraft:cobbled_deepslate
setblock 51 209 588 minecraft:calcite
fill 51 209 589 51 212 589 minecraft:cobbled_deepslate
setblock 51 209 593 minecraft:calcite
setblock 51 209 598 minecraft:calcite
setblock 52 209 597 minecraft:calcite
fill 52 209 598 52 212 598 minecraft:cobbled_deepslate
fill 53 209 597 53 212 597 minecraft:cobbled_deepslate
fill 54 209 598 55 209 598 minecraft:cobbled_deepslate
setblock 58 209 557 minecraft:cobbled_deepslate
fill 58 209 599 70 209 599 minecraft:deepslate
fill 59 209 557 71 209 557 minecraft:deepslate
fill 67 209 558 67 212 558 minecraft:cobbled_deepslate
setblock 69 209 559 minecraft:cobbled_deepslate
fill 69 209 598 70 209 598 minecraft:cobbled_deepslate
setblock 70 209 559 minecraft:calcite
setblock 71 209 558 minecraft:calcite
fill 71 209 559 71 211 560 minecraft:cobbled_deepslate
setblock 71 209 597 minecraft:cobbled_deepslate
setblock 71 209 598 minecraft:calcite
setblock 71 209 599 minecraft:cobbled_deepslate
fill 72 209 558 72 212 558 minecraft:cobbled_deepslate
setblock 72 209 597 minecraft:calcite
fill 72 209 598 72 212 598 minecraft:cobbled_deepslate
fill 72 209 599 76 307 599 minecraft:deepslate
fill 73 209 557 79 307 557 minecraft:deepslate
fill 73 209 597 73 212 597 minecraft:cobbled_deepslate
setblock 74 209 560 minecraft:calcite
setblock 75 209 559 minecraft:calcite
setblock 76 209 558 minecraft:calcite
fill 76 209 559 76 211 559 minecraft:cobbled_deepslate
setblock 76 209 598 minecraft:calcite
fill 77 209 558 77 212 558 minecraft:cobbled_deepslate
setblock 77 209 597 minecraft:calcite
fill 77 209 598 77 212 598 minecraft:cobbled_deepslate
fill 78 209 599 81 307 599 minecraft:deepslate
setblock 80 209 557 minecraft:cobbled_deepslate
fill 81 209 557 82 210 557 minecraft:deepslate
fill 81 209 583 83 210 583 minecraft:light_blue_stained_glass
setblock 81 209 598 minecraft:calcite
fill 82 209 582 83 210 582 minecraft:light_blue_stained_glass
fill 82 209 584 83 210 584 minecraft:light_blue_stained_glass
fill 82 209 598 85 209 598 minecraft:cobbled_deepslate
setblock 83 209 557 minecraft:cobbled_deepslate
fill 83 209 599 89 209 599 minecraft:deepslate
setblock 85 209 557 minecraft:cobbled_deepslate
fill 85 209 581 85 210 581 minecraft:light_blue_stained_glass
fill 85 209 585 85 214 585 minecraft:light_blue_stained_glass
fill 86 209 557 89 307 557 minecraft:deepslate
fill 86 209 586 86 214 586 minecraft:light_blue_stained_glass
fill 86 209 589 86 209 592 minecraft:cobbled_deepslate
setblock 86 209 593 minecraft:calcite
fill 86 209 594 86 212 594 minecraft:cobbled_deepslate
setblock 86 209 597 minecraft:cobbled_deepslate
setblock 86 209 598 minecraft:calcite
setblock 87 209 586 minecraft:cobbled_deepslate
setblock 87 209 587 minecraft:calcite
fill 87 209 588 87 212 588 minecraft:cobbled_deepslate
setblock 87 209 592 minecraft:calcite
fill 87 209 593 87 212 593 minecraft:cobbled_deepslate
setblock 87 209 597 minecraft:calcite
fill 87 209 598 88 211 598 minecraft:cobbled_deepslate
fill 88 209 558 88 209 560 minecraft:cobbled_deepslate
setblock 88 209 561 minecraft:calcite
fill 88 209 562 88 212 562 minecraft:cobbled_deepslate
setblock 88 209 566 minecraft:calcite
fill 88 209 567 88 212 567 minecraft:cobbled_deepslate
setblock 88 209 571 minecraft:calcite
fill 88 209 572 88 210 574 minecraft:cobbled_deepslate
fill 88 209 582 88 212 582 minecraft:cobbled_deepslate
setblock 88 209 586 minecraft:calcite
fill 88 209 587 88 212 587 minecraft:cobbled_deepslate
fill 88 209 589 88 210 589 minecraft:cobbled_deepslate
setblock 88 209 591 minecraft:calcite
fill 88 209 592 88 212 592 minecraft:cobbled_deepslate
setblock 88 209 595 minecraft:cobbled_deepslate
setblock 88 209 596 minecraft:calcite
fill 88 209 597 88 212 597 minecraft:cobbled_deepslate
fill 89 209 558 89 209 579 minecraft:deepslate
setblock 89 209 580 minecraft:cobbled_deepslate
fill 89 209 581 89 209 583 minecraft:deepslate
fill 89 209 585 89 209 598 minecraft:deepslate
fill 47 210 559 47 307 561 minecraft:deepslate
fill 47 210 562 47 210 564 minecraft:cobbled_deepslate
fill 47 210 565 47 307 565 minecraft:deepslate
fill 47 210 568 47 307 568 minecraft:deepslate
fill 47 210 573 47 307 575 minecraft:deepslate
fill 47 210 576 48 210 576 minecraft:cobbled_deepslate
fill 47 210 577 47 307 578 minecraft:deepslate
setblock 47 210 579 minecraft:cobbled_deepslate
fill 47 210 580 47 307 594 minecraft:deepslate
setblock 47 210 595 minecraft:cobbled_deepslate
fill 47 210 596 47 307 599 minecraft:deepslate
fill 48 210 557 49 210 557 minecraft:deepslate
setblock 48 210 565 minecraft:calcite
fill 48 210 566 48 213 566 minecraft:cobbled_deepslate
setblock 48 210 569 minecraft:cobbled_deepslate
setblock 48 210 570 minecraft:calcite
fill 48 210 571 48 213 571 minecraft:cobbled_deepslate
fill 48 210 573 48 210 574 minecraft:cobbled_deepslate
setblock 48 210 575 minecraft:calcite
setblock 48 210 580 minecraft:calcite
fill 48 210 581 48 213 581 minecraft:cobbled_deepslate
setblock 48 210 585 minecraft:calcite
fill 48 210 586 48 213 586 minecraft:cobbled_deepslate
setblock 48 210 590 minecraft:calcite
fill 48 210 591 48 213 591 minecraft:cobbled_deepslate
setblock 48 210 595 minecraft:calcite
fill 48 210 596 48 212 597 minecraft:cobbled_deepslate
fill 49 210 565 49 212 565 minecraft:cobbled_deepslate
setblock 49 210 568 minecraft:cobbled_deepslate
setblock 49 210 569 minecraft:calcite
fill 49 210 570 49 213 570 minecraft:cobbled_deepslate
setblock 49 210 573 minecraft:cobbled_deepslate
setblock 49 210 574 minecraft:calcite
fill 49 210 575 50 212 575 minecraft:cobbled_deepslate
setblock 49 210 578 minecraft:cobbled_deepslate
setblock 49 210 579 minecraft:calcite
fill 49 210 580 49 213 580 minecraft:cobbled_deepslate
setblock 49 210 584 minecraft:calcite
fill 49 210 585 49 213 585 minecraft:cobbled_deepslate
setblock 49 210 589 minecraft:calcite
fill 49 210 590 49 213 590 minecraft:cobbled_deepslate
setblock 49 210 593 minecraft:cobbled_deepslate
setblock 49 210 594 minecraft:calcite
fill 49 210 595 49 213 595 minecraft:cobbled_deepslate
fill 49 210 597 49 210 598 minecraft:cobbled_deepslate
setblock 50 210 557 minecraft:cobbled_deepslate
setblock 50 210 567 minecraft:cobbled_deepslate
setblock 50 210 568 minecraft:calcite
fill 50 210 569 51 212 569 minecraft:cobbled_deepslate
setblock 50 210 572 minecraft:cobbled_deepslate
setblock 50 210 573 minecraft:calcite
fill 50 210 574 50 213 574 minecraft:cobbled_deepslate
fill 50 210 576 50 210 577 minecraft:cobbled_deepslate
setblock 50 210 578 minecraft:calcite
fill 50 210 581 50 211 581 minecraft:cobbled_deepslate
setblock 50 210 583 minecraft:calcite
fill 50 210 584 50 213 584 minecraft:cobbled_deepslate
setblock 50 210 588 minecraft:calcite
fill 50 210 589 50 213 589 minecraft:cobbled_deepslate
setblock 50 210 593 minecraft:calcite
fill 50 210 594 51 212 594 minecraft:cobbled_deepslate
fill 50 210 596 50 210 597 minecraft:cobbled_deepslate
setblock 50 210 598 minecraft:calcite
fill 51 210 557 54 307 557 minecraft:deepslate
fill 51 210 558 52 212 558 minecraft:cobbled_deepslate
fill 51 210 570 51 210 571 minecraft:cobbled_deepslate
setblock 51 210 572 minecraft:calcite
fill 51 210 573 51 213 573 minecraft:cobbled_deepslate
setblock 51 210 587 minecraft:calcite
fill 51 210 588 51 212 588 minecraft:cobbled_deepslate
setblock 51 210 592 minecraft:calcite
fill 51 210 593 51 213 593 minecraft:cobbled_deepslate
setblock 51 210 596 minecraft:cobbled_deepslate
setblock 51 210 597 minecraft:calcite
fill 51 210 598 51 213 598 minecraft:cobbled_deepslate
setblock 52 210 596 minecraft:calcite
fill 52 210 597 52 213 597 minecraft:cobbled_deepslate
fill 54 210 597 54 210 598 minecraft:cobbled_deepslate
setblock 55 210 557 minecraft:cobbled_deepslate
setblock 55 210 598 minecraft:calcite
fill 56 210 557 59 307 557 minecraft:deepslate
fill 58 210 599 58 307 599 minecraft:deepslate
setblock 59 210 599 minecraft:cobbled_deepslate
setblock 60 210 557 minecraft:cobbled_deepslate
fill 60 210 599 61 307 599 minecraft:deepslate
fill 61 210 557 72 210 557 minecraft:deepslate
setblock 62 210 599 minecraft:cobbled_deepslate
fill 63 210 599 66 210 599 minecraft:deepslate
fill 66 210 558 66 213 558 minecraft:cobbled_deepslate
fill 67 210 598 69 210 599 minecraft:cobbled_deepslate
setblock 68 210 559 minecraft:cobbled_deepslate
setblock 69 210 559 minecraft:calcite
fill 69 210 597 70 210 597 minecraft:cobbled_deepslate
setblock 70 210 558 minecraft:calcite
fill 70 210 559 70 213 559 minecraft:cobbled_deepslate
setblock 70 210 598 minecraft:calcite
fill 70 210 599 71 307 599 minecraft:deepslate
fill 71 210 558 71 213 558 minecraft:cobbled_deepslate
setblock 71 210 597 minecraft:calcite
fill 71 210 598 71 213 598 minecraft:cobbled_deepslate
setblock 72 210 596 minecraft:calcite
fill 72 210 597 72 213 597 minecraft:cobbled_deepslate
setblock 73 210 559 minecraft:cobbled_deepslate
setblock 73 210 560 minecraft:calcite
fill 73 210 596 74 212 596 minecraft:cobbled_deepslate
setblock 74 210 559 minecraft:calcite
setblock 74 210 560 minecraft:cobbled_deepslate
fill 74 210 597 75 210 597 minecraft:cobbled_deepslate
setblock 75 210 558 minecraft:calcite
fill 75 210 559 75 213 559 minecraft:cobbled_deepslate
setblock 75 210 598 minecraft:calcite
fill 76 210 558 76 213 558 minecraft:cobbled_deepslate
setblock 76 210 597 minecraft:calcite
fill 76 210 598 76 213 598 minecraft:cobbled_deepslate
fill 77 210 597 79 211 597 minecraft:cobbled_deepslate
fill 77 210 599 77 307 599 minecraft:deepslate
fill 80 210 557 80 307 557 minecraft:deepslate
setblock 80 210 558 minecraft:calcite
setblock 80 210 583 minecraft:light_blue_stained_glass
setblock 80 210 598 minecraft:calcite
fill 81 210 598 84 210 598 minecraft:cobbled_deepslate
fill 82 210 599 82 307 599 minecraft:deepslate
fill 83 210 557 85 307 557 minecraft:deepslate
setblock 83 210 599 minecraft:cobbled_deepslate
fill 84 210 597 85 210 597 minecraft:cobbled_deepslate
fill 84 210 599 89 307 599 minecraft:deepslate
fill 85 210 586 85 214 586 minecraft:light_blue_stained_glass
setblock 85 210 598 minecraft:calcite
fill 86 210 581 87 211 581 minecraft:light_blue_stained_glass
fill 86 210 585 86 215 585 minecraft:light_blue_stained_glass
fill 86 210 587 86 213 587 minecraft:light_blue_stained_glass
fill 86 210 589 86 210 591 minecraft:cobbled_deepslate
setblock 86 210 592 minecraft:calcite
fill 86 210 593 86 213 593 minecraft:cobbled_deepslate
fill 86 210 595 86 210 596 minecraft:cobbled_deepslate
setblock 86 210 597 minecraft:calcite
fill 86 210 598 86 213 598 minecraft:cobbled_deepslate
fill 87 210 558 89 210 558 minecraft:cobbled_deepslate
fill 87 210 567 87 210 570 minecraft:cobbled_deepslate
setblock 87 210 571 minecraft:calcite
setblock 87 210 585 minecraft:cobbled_deepslate
setblock 87 210 586 minecraft:calcite
fill 87 210 587 87 213 587 minecraft:cobbled_deepslate
setblock 87 210 591 minecraft:calcite
fill 87 210 592 87 213 592 minecraft:cobbled_deepslate
fill 87 210 594 87 210 595 minecraft:cobbled_deepslate
setblock 87 210 596 minecraft:calcite
fill 87 210 597 87 213 597 minecraft:cobbled_deepslate
setblock 88 210 559 minecraft:cobbled_deepslate
setblock 88 210 560 minecraft:calcite
fill 88 210 561 88 213 561 minecraft:cobbled_deepslate
setblock 88 210 565 minecraft:calcite
fill 88 210 566 88 213 566 minecraft:cobbled_deepslate
fill 88 210 569 89 210 569 minecraft:cobbled_deepslate
setblock 88 210 570 minecraft:calcite
fill 88 210 571 88 213 571 minecraft:cobbled_deepslate
setblock 88 210 575 minecraft:calcite
fill 88 210 576 88 210 579 minecraft:cobbled_deepslate
setblock 88 210 580 minecraft:calcite
fill 88 210 581 89 210 581 minecraft:cobbled_deepslate
setblock 88 210 585 minecraft:calcite
fill 88 210 586 88 213 586 minecraft:cobbled_deepslate
setblock 88 210 590 minecraft:calcite
fill 88 210 591 88 213 591 minecraft:cobbled_deepslate
setblock 88 210 595 minecraft:calcite
fill 88 210 596 88 213 596 minecraft:cobbled_deepslate
fill 89 210 559 89 210 568 minecraft:deepslate
fill 89 210 570 89 210 573 minecraft:deepslate
fill 89 210 574 89 210 576 minecraft:cobbled_deepslate
fill 89 210 577 89 278 580 minecraft:deepslate
fill 89 210 582 89 210 583 minecraft:cobbled_deepslate
fill 89 210 584 89 278 586 minecraft:deepslate
setblock 89 210 587 minecraft:cobbled_deepslate
fill 89 210 588 89 307 589 minecraft:deepslate
setblock 89 210 590 minecraft:cobbled_deepslate
fill 89 210 591 89 307 597 minecraft:deepslate
fill 89 210 598 89 211 598 minecraft:cobbled_deepslate
fill 47 211 562 47 307 564 minecraft:deepslate
fill 47 211 569 47 307 571 minecraft:deepslate
setblock 47 211 572 minecraft:cobbled_deepslate
fill 47 211 576 47 307 576 minecraft:deepslate
fill 47 211 579 47 307 579 minecraft:deepslate
fill 47 211 595 47 307 595 minecraft:deepslate
fill 48 211 557 48 307 557 minecraft:deepslate
setblock 48 211 563 minecraft:cobbled_deepslate
setblock 48 211 564 minecraft:calcite
fill 48 211 565 48 214 565 minecraft:cobbled_deepslate
setblock 48 211 569 minecraft:calcite
fill 48 211 570 48 214 570 minecraft:cobbled_deepslate
setblock 48 211 573 minecraft:cobbled_deepslate
setblock 48 211 574 minecraft:calcite
fill 48 211 575 48 213 576 minecraft:cobbled_deepslate
setblock 48 211 578 minecraft:cobbled_deepslate
setblock 48 211 579 minecraft:calcite
fill 48 211 580 48 214 580 minecraft:cobbled_deepslate
setblock 48 211 584 minecraft:calcite
fill 48 211 585 48 214 585 minecraft:cobbled_deepslate
setblock 48 211 589 minecraft:calcite
fill 48 211 590 48 214 590 minecraft:cobbled_deepslate
setblock 48 211 594 minecraft:calcite
fill 48 211 595 48 214 595 minecraft:cobbled_deepslate
setblock 49 211 557 minecraft:cobbled_deepslate
setblock 49 211 568 minecraft:calcite
schedule function dropper:buildpart/133_7 1t
