setblock 510 30 467 minecraft:terracotta
fill 510 30 468 511 32 468 minecraft:red_terracotta
setblock 510 30 477 minecraft:terracotta
fill 510 30 478 510 33 478 minecraft:red_terracotta
setblock 510 30 482 minecraft:terracotta
fill 510 30 483 510 33 483 minecraft:red_terracotta
setblock 510 30 487 minecraft:terracotta
fill 510 30 488 510 33 488 minecraft:red_terracotta
setblock 511 30 466 minecraft:terracotta
fill 511 30 467 511 33 467 minecraft:red_terracotta
fill 511 30 469 511 30 470 minecraft:red_terracotta
setblock 511 30 471 minecraft:terracotta
fill 511 30 472 511 33 472 minecraft:red_terracotta
setblock 511 30 476 minecraft:terracotta
fill 511 30 477 511 33 477 minecraft:red_terracotta
setblock 511 30 481 minecraft:terracotta
fill 511 30 482 511 33 482 minecraft:red_terracotta
setblock 511 30 486 minecraft:terracotta
fill 511 30 487 511 33 487 minecraft:red_terracotta
setblock 511 30 491 minecraft:terracotta
fill 511 30 492 511 33 492 minecraft:red_terracotta
setblock 511 30 501 minecraft:terracotta
fill 511 30 502 511 33 502 minecraft:red_terracotta
setblock 471 31 465 minecraft:terracotta
fill 471 31 466 471 34 466 minecraft:red_terracotta
setblock 471 31 470 minecraft:terracotta
fill 471 31 471 471 31 474 minecraft:red_terracotta
setblock 471 31 475 minecraft:terracotta
fill 471 31 476 471 34 476 minecraft:red_terracotta
setblock 471 31 480 minecraft:terracotta
fill 471 31 481 471 34 481 minecraft:red_terracotta
setblock 471 31 485 minecraft:terracotta
fill 471 31 486 471 34 486 minecraft:red_terracotta
setblock 471 31 490 minecraft:terracotta
setblock 471 31 500 minecraft:terracotta
fill 471 31 501 471 34 501 minecraft:red_terracotta
setblock 472 31 464 minecraft:terracotta
fill 472 31 465 472 34 465 minecraft:red_terracotta
setblock 472 31 469 minecraft:terracotta
fill 472 31 470 472 34 470 minecraft:red_terracotta
setblock 472 31 479 minecraft:terracotta
fill 472 31 480 472 32 480 minecraft:red_terracotta
setblock 472 31 484 minecraft:terracotta
fill 472 31 485 472 34 485 minecraft:red_terracotta
setblock 472 31 504 minecraft:terracotta
fill 473 31 464 476 31 464 minecraft:red_terracotta
setblock 473 31 467 minecraft:red_terracotta
setblock 473 31 503 minecraft:terracotta
fill 473 31 504 476 31 504 minecraft:red_terracotta
setblock 474 31 466 minecraft:red_terracotta
setblock 476 31 465 minecraft:terracotta
setblock 477 31 464 minecraft:terracotta
fill 477 31 465 480 31 465 minecraft:red_terracotta
setblock 477 31 504 minecraft:terracotta
fill 478 31 464 481 31 464 minecraft:red_terracotta
fill 478 31 504 481 31 504 minecraft:red_terracotta
setblock 481 31 465 minecraft:terracotta
setblock 482 31 464 minecraft:terracotta
fill 482 31 465 482 34 465 minecraft:red_terracotta
setblock 482 31 503 minecraft:red_terracotta
setblock 482 31 504 minecraft:terracotta
fill 483 31 464 483 34 464 minecraft:red_terracotta
setblock 483 31 503 minecraft:terracotta
fill 483 31 504 483 34 504 minecraft:red_terracotta
fill 484 31 503 484 34 503 minecraft:red_terracotta
fill 485 31 502 485 34 502 minecraft:red_terracotta
setblock 486 31 464 minecraft:red_terracotta
setblock 486 31 465 minecraft:terracotta
fill 486 31 478 486 32 481 minecraft:brown_terracotta
setblock 487 31 464 minecraft:terracotta
fill 487 31 465 487 34 465 minecraft:red_terracotta
fill 487 31 477 489 32 477 minecraft:brown_terracotta
setblock 487 31 504 minecraft:terracotta
fill 488 31 464 488 34 464 minecraft:red_terracotta
setblock 488 31 503 minecraft:terracotta
fill 488 31 504 488 34 504 minecraft:red_terracotta
setblock 489 31 502 minecraft:terracotta
fill 489 31 503 489 34 503 minecraft:red_terracotta
fill 490 31 478 490 32 479 minecraft:brown_terracotta
fill 490 31 502 490 34 502 minecraft:red_terracotta
setblock 491 31 465 minecraft:terracotta
setblock 492 31 464 minecraft:terracotta
fill 492 31 465 492 34 465 minecraft:red_terracotta
setblock 492 31 504 minecraft:terracotta
fill 493 31 464 493 34 464 minecraft:red_terracotta
setblock 493 31 503 minecraft:terracotta
fill 493 31 504 493 34 504 minecraft:red_terracotta
fill 494 31 503 494 33 503 minecraft:red_terracotta
setblock 497 31 504 minecraft:terracotta
setblock 498 31 504 minecraft:red_terracotta
fill 504 31 464 504 33 464 minecraft:red_terracotta
setblock 507 31 464 minecraft:terracotta
fill 507 31 465 507 34 465 minecraft:red_terracotta
setblock 507 31 504 minecraft:terracotta
fill 508 31 464 508 34 464 minecraft:red_terracotta
setblock 508 31 483 minecraft:terracotta
fill 508 31 484 508 34 484 minecraft:red_terracotta
fill 508 31 486 509 31 486 minecraft:red_terracotta
fill 508 31 504 508 34 504 minecraft:red_terracotta
fill 509 31 465 510 31 465 minecraft:red_terracotta
fill 509 31 478 509 34 478 minecraft:red_terracotta
setblock 509 31 482 minecraft:terracotta
fill 509 31 483 509 34 483 minecraft:red_terracotta
setblock 509 31 487 minecraft:terracotta
fill 509 31 488 509 33 489 minecraft:red_terracotta
setblock 510 31 466 minecraft:terracotta
fill 510 31 467 510 34 467 minecraft:red_terracotta
fill 510 31 469 510 31 470 minecraft:red_terracotta
setblock 510 31 471 minecraft:terracotta
fill 510 31 472 510 32 474 minecraft:red_terracotta
setblock 510 31 476 minecraft:terracotta
fill 510 31 477 510 34 477 minecraft:red_terracotta
setblock 510 31 481 minecraft:terracotta
fill 510 31 482 510 34 482 minecraft:red_terracotta
setblock 510 31 486 minecraft:terracotta
fill 510 31 487 510 34 487 minecraft:red_terracotta
setblock 510 31 491 minecraft:terracotta
setblock 511 31 465 minecraft:terracotta
fill 511 31 466 511 34 466 minecraft:red_terracotta
setblock 511 31 469 minecraft:red_terracotta
setblock 511 31 470 minecraft:terracotta
fill 511 31 471 511 34 471 minecraft:red_terracotta
setblock 511 31 475 minecraft:terracotta
fill 511 31 476 511 34 476 minecraft:red_terracotta
setblock 511 31 480 minecraft:terracotta
fill 511 31 481 511 34 481 minecraft:red_terracotta
setblock 511 31 485 minecraft:terracotta
fill 511 31 486 511 34 486 minecraft:red_terracotta
setblock 511 31 490 minecraft:terracotta
fill 511 31 491 511 34 491 minecraft:red_terracotta
fill 511 31 493 511 32 493 minecraft:red_terracotta
fill 511 31 501 511 33 501 minecraft:red_terracotta
setblock 471 32 464 minecraft:terracotta
fill 471 32 465 471 35 465 minecraft:red_terracotta
setblock 471 32 469 minecraft:terracotta
fill 471 32 470 471 32 473 minecraft:red_terracotta
setblock 471 32 474 minecraft:terracotta
fill 471 32 475 471 35 475 minecraft:red_terracotta
setblock 471 32 479 minecraft:terracotta
fill 471 32 480 471 35 480 minecraft:red_terracotta
setblock 471 32 484 minecraft:terracotta
fill 471 32 485 471 35 485 minecraft:red_terracotta
setblock 471 32 489 minecraft:terracotta
fill 471 32 490 471 34 491 minecraft:red_terracotta
fill 471 32 500 471 34 500 minecraft:red_terracotta
setblock 471 32 504 minecraft:terracotta
fill 472 32 464 475 32 464 minecraft:red_terracotta
setblock 472 32 468 minecraft:terracotta
fill 472 32 469 472 35 469 minecraft:red_terracotta
setblock 472 32 472 minecraft:red_terracotta
setblock 472 32 483 minecraft:terracotta
fill 472 32 484 472 34 484 minecraft:red_terracotta
setblock 472 32 487 minecraft:red_terracotta
setblock 472 32 503 minecraft:terracotta
fill 472 32 504 475 32 504 minecraft:red_terracotta
setblock 473 32 467 minecraft:terracotta
fill 473 32 468 473 35 468 minecraft:red_terracotta
fill 473 32 503 473 33 503 minecraft:red_terracotta
setblock 474 32 466 minecraft:terracotta
setblock 475 32 465 minecraft:terracotta
setblock 476 32 464 minecraft:terracotta
fill 476 32 465 479 32 465 minecraft:red_terracotta
fill 476 32 473 477 33 474 minecraft:magma_block
setblock 476 32 504 minecraft:terracotta
fill 477 32 464 480 32 464 minecraft:red_terracotta
fill 477 32 504 480 32 504 minecraft:red_terracotta
setblock 480 32 465 minecraft:terracotta
setblock 481 32 464 minecraft:terracotta
fill 481 32 465 481 35 465 minecraft:red_terracotta
setblock 481 32 503 minecraft:red_terracotta
setblock 481 32 504 minecraft:terracotta
fill 482 32 464 482 35 464 minecraft:red_terracotta
setblock 482 32 503 minecraft:terracotta
fill 482 32 504 482 35 504 minecraft:red_terracotta
fill 483 32 503 483 35 503 minecraft:red_terracotta
setblock 485 32 464 minecraft:red_terracotta
setblock 485 32 465 minecraft:terracotta
fill 485 32 478 485 32 481 minecraft:brown_terracotta
setblock 486 32 464 minecraft:terracotta
fill 486 32 465 486 34 466 minecraft:red_terracotta
setblock 486 32 477 minecraft:brown_terracotta
setblock 486 32 482 minecraft:brown_terracotta
setblock 486 32 504 minecraft:terracotta
fill 487 32 464 487 35 464 minecraft:red_terracotta
fill 487 32 466 488 32 466 minecraft:red_terracotta
setblock 487 32 503 minecraft:terracotta
fill 487 32 504 487 35 504 minecraft:red_terracotta
setblock 488 32 476 minecraft:brown_terracotta
setblock 488 32 502 minecraft:terracotta
fill 488 32 503 488 35 503 minecraft:red_terracotta
setblock 489 32 466 minecraft:terracotta
fill 489 32 502 489 35 502 minecraft:red_terracotta
setblock 490 32 465 minecraft:terracotta
setblock 490 32 477 minecraft:brown_terracotta
setblock 491 32 464 minecraft:terracotta
fill 491 32 465 491 35 465 minecraft:red_terracotta
fill 491 32 478 491 32 479 minecraft:brown_terracotta
setblock 491 32 504 minecraft:terracotta
fill 492 32 464 492 35 464 minecraft:red_terracotta
setblock 492 32 503 minecraft:terracotta
fill 492 32 504 492 35 504 minecraft:red_terracotta
fill 493 32 503 493 34 503 minecraft:red_terracotta
setblock 496 32 504 minecraft:terracotta
fill 497 32 504 497 33 504 minecraft:red_terracotta
fill 503 32 464 503 34 464 minecraft:red_terracotta
fill 503 32 504 503 34 504 minecraft:red_terracotta
setblock 505 32 465 minecraft:terracotta
setblock 506 32 464 minecraft:terracotta
fill 506 32 465 506 35 465 minecraft:red_terracotta
setblock 506 32 504 minecraft:terracotta
fill 507 32 464 507 35 464 minecraft:red_terracotta
fill 507 32 504 507 35 504 minecraft:red_terracotta
setblock 508 32 466 minecraft:red_terracotta
setblock 508 32 481 minecraft:red_terracotta
setblock 508 32 482 minecraft:terracotta
fill 508 32 483 508 35 483 minecraft:red_terracotta
setblock 508 32 486 minecraft:red_terracotta
setblock 508 32 487 minecraft:terracotta
setblock 509 32 465 minecraft:red_terracotta
setblock 509 32 466 minecraft:terracotta
fill 509 32 467 509 34 468 minecraft:red_terracotta
setblock 509 32 481 minecraft:terracotta
fill 509 32 482 509 35 482 minecraft:red_terracotta
setblock 509 32 486 minecraft:terracotta
fill 509 32 487 509 35 487 minecraft:red_terracotta
setblock 509 32 490 minecraft:red_terracotta
setblock 510 32 464 minecraft:red_terracotta
setblock 510 32 465 minecraft:terracotta
fill 510 32 466 510 35 466 minecraft:red_terracotta
setblock 510 32 469 minecraft:red_terracotta
setblock 510 32 470 minecraft:terracotta
fill 510 32 471 510 35 471 minecraft:red_terracotta
setblock 510 32 475 minecraft:terracotta
fill 510 32 476 510 35 476 minecraft:red_terracotta
setblock 510 32 480 minecraft:terracotta
fill 510 32 481 510 35 481 minecraft:red_terracotta
setblock 510 32 485 minecraft:terracotta
fill 510 32 486 510 35 486 minecraft:red_terracotta
setblock 510 32 489 minecraft:red_terracotta
setblock 510 32 490 minecraft:terracotta
fill 510 32 491 510 35 491 minecraft:red_terracotta
setblock 511 32 464 minecraft:terracotta
fill 511 32 465 511 35 465 minecraft:red_terracotta
setblock 511 32 469 minecraft:terracotta
fill 511 32 470 511 35 470 minecraft:red_terracotta
setblock 511 32 474 minecraft:terracotta
fill 511 32 475 511 35 475 minecraft:red_terracotta
setblock 511 32 479 minecraft:terracotta
fill 511 32 480 511 35 480 minecraft:red_terracotta
setblock 511 32 484 minecraft:terracotta
fill 511 32 485 511 35 485 minecraft:red_terracotta
setblock 511 32 489 minecraft:terracotta
fill 511 32 490 511 35 490 minecraft:red_terracotta
setblock 511 32 504 minecraft:terracotta
fill 471 33 464 474 33 464 minecraft:red_terracotta
setblock 471 33 468 minecraft:terracotta
fill 471 33 469 471 33 472 minecraft:red_terracotta
setblock 471 33 473 minecraft:terracotta
fill 471 33 474 471 36 474 minecraft:red_terracotta
setblock 471 33 478 minecraft:terracotta
fill 471 33 479 471 36 479 minecraft:red_terracotta
setblock 471 33 483 minecraft:terracotta
fill 471 33 484 471 36 484 minecraft:red_terracotta
setblock 471 33 488 minecraft:terracotta
fill 471 33 489 471 36 489 minecraft:red_terracotta
setblock 471 33 492 minecraft:red_terracotta
setblock 471 33 503 minecraft:terracotta
fill 471 33 504 474 33 504 minecraft:red_terracotta
setblock 472 33 466 minecraft:red_terracotta
setblock 472 33 467 minecraft:terracotta
fill 472 33 468 472 36 468 minecraft:red_terracotta
setblock 472 33 472 minecraft:terracotta
setblock 472 33 482 minecraft:terracotta
setblock 472 33 483 minecraft:red_terracotta
setblock 472 33 487 minecraft:terracotta
fill 472 33 503 472 34 503 minecraft:red_terracotta
setblock 473 33 466 minecraft:terracotta
fill 473 33 467 473 36 467 minecraft:red_terracotta
setblock 474 33 465 minecraft:terracotta
fill 474 33 466 475 35 466 minecraft:red_terracotta
setblock 475 33 464 minecraft:terracotta
fill 475 33 465 478 33 465 minecraft:red_terracotta
setblock 475 33 504 minecraft:terracotta
fill 476 33 464 479 33 464 minecraft:red_terracotta
fill 476 33 504 479 33 504 minecraft:red_terracotta
setblock 479 33 465 minecraft:terracotta
setblock 480 33 464 minecraft:terracotta
fill 480 33 465 480 36 465 minecraft:red_terracotta
setblock 480 33 503 minecraft:red_terracotta
setblock 480 33 504 minecraft:terracotta
fill 481 33 464 481 36 464 minecraft:red_terracotta
setblock 481 33 503 minecraft:terracotta
fill 481 33 504 481 36 504 minecraft:red_terracotta
fill 482 33 503 482 36 503 minecraft:red_terracotta
setblock 483 33 465 minecraft:red_terracotta
setblock 483 33 466 minecraft:terracotta
setblock 484 33 465 minecraft:terracotta
fill 484 33 466 485 35 466 minecraft:red_terracotta
fill 484 33 502 484 35 502 minecraft:red_terracotta
setblock 485 33 464 minecraft:terracotta
fill 485 33 465 485 36 465 minecraft:red_terracotta
setblock 485 33 504 minecraft:terracotta
fill 486 33 464 486 36 464 minecraft:red_terracotta
setblock 486 33 503 minecraft:terracotta
fill 486 33 504 486 36 504 minecraft:red_terracotta
setblock 487 33 466 minecraft:red_terracotta
setblock 487 33 502 minecraft:terracotta
fill 487 33 503 487 36 503 minecraft:red_terracotta
setblock 488 33 466 minecraft:terracotta
fill 488 33 502 488 36 502 minecraft:red_terracotta
setblock 489 33 465 minecraft:terracotta
fill 489 33 466 490 35 466 minecraft:red_terracotta
setblock 490 33 464 minecraft:terracotta
fill 490 33 465 490 36 465 minecraft:red_terracotta
setblock 490 33 504 minecraft:terracotta
fill 491 33 464 491 36 464 minecraft:red_terracotta
setblock 491 33 503 minecraft:terracotta
fill 491 33 504 491 36 504 minecraft:red_terracotta
fill 492 33 503 492 35 503 minecraft:red_terracotta
setblock 493 33 465 minecraft:red_terracotta
setblock 495 33 464 minecraft:terracotta
setblock 495 33 504 minecraft:terracotta
fill 496 33 504 496 34 504 minecraft:red_terracotta
fill 501 33 464 502 35 464 minecraft:red_terracotta
fill 502 33 504 502 35 504 minecraft:red_terracotta
setblock 504 33 465 minecraft:terracotta
setblock 505 33 464 minecraft:terracotta
fill 505 33 465 505 36 465 minecraft:red_terracotta
setblock 505 33 504 minecraft:terracotta
fill 506 33 464 506 36 464 minecraft:red_terracotta
fill 506 33 466 507 33 466 minecraft:red_terracotta
fill 506 33 504 506 36 504 minecraft:red_terracotta
setblock 508 33 466 minecraft:terracotta
setblock 508 33 481 minecraft:terracotta
fill 508 33 482 508 35 482 minecraft:red_terracotta
setblock 508 33 486 minecraft:terracotta
fill 508 33 487 508 35 488 minecraft:red_terracotta
setblock 509 33 465 minecraft:terracotta
fill 509 33 466 509 36 466 minecraft:red_terracotta
setblock 509 33 469 minecraft:red_terracotta
setblock 509 33 470 minecraft:terracotta
fill 509 33 471 509 36 471 minecraft:red_terracotta
setblock 509 33 480 minecraft:terracotta
fill 509 33 481 509 36 481 minecraft:red_terracotta
setblock 509 33 485 minecraft:terracotta
fill 509 33 486 509 36 486 minecraft:red_terracotta
setblock 509 33 490 minecraft:terracotta
setblock 510 33 464 minecraft:terracotta
fill 510 33 465 510 36 465 minecraft:red_terracotta
setblock 510 33 468 minecraft:red_terracotta
setblock 510 33 469 minecraft:terracotta
fill 510 33 470 510 36 470 minecraft:red_terracotta
fill 510 33 472 510 33 473 minecraft:red_terracotta
setblock 510 33 474 minecraft:terracotta
fill 510 33 475 510 36 475 minecraft:red_terracotta
setblock 510 33 479 minecraft:terracotta
fill 510 33 480 510 36 480 minecraft:red_terracotta
setblock 510 33 484 minecraft:terracotta
fill 510 33 485 510 36 485 minecraft:red_terracotta
setblock 510 33 489 minecraft:terracotta
fill 510 33 490 510 36 490 minecraft:red_terracotta
fill 510 33 492 510 34 492 minecraft:red_terracotta
setblock 510 33 504 minecraft:terracotta
fill 511 33 464 511 36 464 minecraft:red_terracotta
setblock 511 33 468 minecraft:terracotta
fill 511 33 469 511 36 469 minecraft:red_terracotta
setblock 511 33 473 minecraft:terracotta
fill 511 33 474 511 36 474 minecraft:red_terracotta
setblock 511 33 478 minecraft:terracotta
fill 511 33 479 511 36 479 minecraft:red_terracotta
setblock 511 33 483 minecraft:terracotta
fill 511 33 484 511 36 484 minecraft:red_terracotta
setblock 511 33 488 minecraft:terracotta
fill 511 33 489 511 36 489 minecraft:red_terracotta
setblock 511 33 493 minecraft:terracotta
fill 511 33 494 511 36 494 minecraft:red_terracotta
setblock 511 33 503 minecraft:terracotta
fill 511 33 504 511 36 504 minecraft:red_terracotta
fill 471 34 464 473 34 464 minecraft:red_terracotta
setblock 471 34 467 minecraft:terracotta
fill 471 34 468 471 34 471 minecraft:red_terracotta
setblock 471 34 472 minecraft:terracotta
fill 471 34 473 472 36 473 minecraft:red_terracotta
setblock 471 34 477 minecraft:terracotta
fill 471 34 478 471 36 478 minecraft:red_terracotta
setblock 471 34 482 minecraft:terracotta
fill 471 34 483 471 37 483 minecraft:red_terracotta
setblock 471 34 487 minecraft:terracotta
fill 471 34 488 472 35 488 minecraft:red_terracotta
setblock 471 34 492 minecraft:terracotta
fill 471 34 493 471 37 493 minecraft:red_terracotta
setblock 471 34 502 minecraft:terracotta
fill 471 34 503 471 36 504 minecraft:red_terracotta
setblock 472 34 466 minecraft:terracotta
fill 472 34 467 472 37 467 minecraft:red_terracotta
setblock 472 34 471 minecraft:terracotta
fill 472 34 472 472 37 472 minecraft:red_terracotta
setblock 472 34 486 minecraft:terracotta
fill 472 34 487 472 35 487 minecraft:red_terracotta
fill 472 34 504 473 34 504 minecraft:red_terracotta
setblock 473 34 465 minecraft:terracotta
fill 473 34 466 473 37 466 minecraft:red_terracotta
setblock 473 34 469 minecraft:red_terracotta
setblock 474 34 464 minecraft:terracotta
fill 474 34 465 477 34 465 minecraft:red_terracotta
setblock 474 34 504 minecraft:terracotta
fill 475 34 464 478 34 464 minecraft:red_terracotta
fill 475 34 504 478 34 504 minecraft:red_terracotta
setblock 476 34 466 minecraft:red_terracotta
setblock 478 34 465 minecraft:terracotta
setblock 479 34 464 minecraft:terracotta
fill 479 34 465 479 37 465 minecraft:red_terracotta
setblock 479 34 504 minecraft:terracotta
fill 480 34 464 480 37 464 minecraft:red_terracotta
setblock 480 34 503 minecraft:terracotta
fill 480 34 504 480 37 504 minecraft:red_terracotta
setblock 481 34 466 minecraft:red_terracotta
fill 481 34 503 481 37 503 minecraft:red_terracotta
setblock 482 34 466 minecraft:terracotta
setblock 483 34 465 minecraft:terracotta
fill 483 34 466 483 37 466 minecraft:red_terracotta
setblock 484 34 464 minecraft:terracotta
fill 484 34 465 484 37 465 minecraft:red_terracotta
setblock 484 34 504 minecraft:terracotta
fill 485 34 464 485 37 464 minecraft:red_terracotta
setblock 485 34 503 minecraft:terracotta
fill 485 34 504 485 37 504 minecraft:red_terracotta
setblock 486 34 502 minecraft:terracotta
fill 486 34 503 486 37 503 minecraft:red_terracotta
setblock 487 34 466 minecraft:terracotta
fill 487 34 502 487 37 502 minecraft:red_terracotta
setblock 488 34 465 minecraft:terracotta
fill 488 34 466 488 37 466 minecraft:red_terracotta
setblock 489 34 464 minecraft:terracotta
fill 489 34 465 489 37 465 minecraft:red_terracotta
setblock 489 34 504 minecraft:terracotta
fill 490 34 464 490 37 464 minecraft:red_terracotta
setblock 490 34 503 minecraft:terracotta
fill 490 34 504 490 37 504 minecraft:red_terracotta
fill 491 34 503 491 36 503 minecraft:red_terracotta
setblock 493 34 465 minecraft:terracotta
setblock 494 34 464 minecraft:terracotta
setblock 494 34 504 minecraft:terracotta
fill 495 34 464 496 34 464 minecraft:red_terracotta
fill 495 34 504 495 35 504 minecraft:red_terracotta
fill 500 34 464 500 37 464 minecraft:red_terracotta
setblock 503 34 465 minecraft:terracotta
setblock 504 34 464 minecraft:terracotta
fill 504 34 465 504 37 465 minecraft:red_terracotta
setblock 504 34 504 minecraft:terracotta
fill 505 34 464 505 37 464 minecraft:red_terracotta
fill 505 34 466 506 34 466 minecraft:red_terracotta
fill 505 34 504 505 37 504 minecraft:red_terracotta
setblock 507 34 466 minecraft:terracotta
setblock 508 34 465 minecraft:terracotta
fill 508 34 466 508 36 467 minecraft:red_terracotta
setblock 508 34 481 minecraft:red_terracotta
setblock 508 34 485 minecraft:terracotta
fill 508 34 486 508 37 486 minecraft:red_terracotta
setblock 508 34 489 minecraft:red_terracotta
setblock 509 34 464 minecraft:terracotta
fill 509 34 465 509 37 465 minecraft:red_terracotta
setblock 509 34 469 minecraft:terracotta
fill 509 34 470 509 37 470 minecraft:red_terracotta
fill 509 34 472 509 34 473 minecraft:red_terracotta
setblock 509 34 474 minecraft:terracotta
fill 509 34 477 509 35 477 minecraft:red_terracotta
setblock 509 34 479 minecraft:terracotta
fill 509 34 480 509 36 480 minecraft:red_terracotta
setblock 509 34 484 minecraft:terracotta
fill 509 34 485 509 37 485 minecraft:red_terracotta
setblock 509 34 488 minecraft:red_terracotta
setblock 509 34 489 minecraft:terracotta
fill 509 34 490 509 36 491 minecraft:red_terracotta
setblock 509 34 504 minecraft:terracotta
fill 510 34 464 510 37 464 minecraft:red_terracotta
setblock 510 34 468 minecraft:terracotta
fill 510 34 469 510 37 469 minecraft:red_terracotta
setblock 510 34 472 minecraft:red_terracotta
setblock 510 34 473 minecraft:terracotta
fill 510 34 474 510 37 474 minecraft:red_terracotta
setblock 510 34 478 minecraft:terracotta
fill 510 34 479 510 37 479 minecraft:red_terracotta
setblock 510 34 483 minecraft:terracotta
fill 510 34 484 510 37 484 minecraft:red_terracotta
setblock 510 34 488 minecraft:terracotta
fill 510 34 489 510 37 489 minecraft:red_terracotta
fill 510 34 504 510 37 504 minecraft:red_terracotta
setblock 511 34 467 minecraft:terracotta
fill 511 34 468 511 37 468 minecraft:red_terracotta
setblock 511 34 472 minecraft:terracotta
fill 511 34 473 511 37 473 minecraft:red_terracotta
setblock 511 34 477 minecraft:terracotta
fill 511 34 478 511 37 478 minecraft:red_terracotta
setblock 511 34 482 minecraft:terracotta
fill 511 34 483 511 37 483 minecraft:red_terracotta
setblock 511 34 487 minecraft:terracotta
fill 511 34 488 511 37 488 minecraft:red_terracotta
setblock 511 34 492 minecraft:terracotta
fill 511 34 493 511 37 493 minecraft:red_terracotta
setblock 511 34 502 minecraft:terracotta
fill 511 34 503 511 36 503 minecraft:red_terracotta
fill 471 35 464 472 35 464 minecraft:red_terracotta
setblock 471 35 466 minecraft:terracotta
fill 471 35 467 471 35 470 minecraft:red_terracotta
setblock 471 35 471 minecraft:terracotta
fill 471 35 472 471 38 472 minecraft:red_terracotta
setblock 471 35 476 minecraft:terracotta
fill 471 35 477 471 37 477 minecraft:red_terracotta
setblock 471 35 481 minecraft:terracotta
fill 471 35 482 471 36 482 minecraft:red_terracotta
setblock 471 35 486 minecraft:terracotta
fill 471 35 487 471 38 487 minecraft:red_terracotta
setblock 471 35 490 minecraft:red_terracotta
setblock 471 35 491 minecraft:terracotta
fill 471 35 492 471 38 492 minecraft:red_terracotta
setblock 471 35 501 minecraft:terracotta
fill 471 35 502 471 37 502 minecraft:red_terracotta
setblock 472 35 465 minecraft:terracotta
fill 472 35 466 472 38 466 minecraft:red_terracotta
setblock 472 35 470 minecraft:terracotta
fill 472 35 471 472 38 471 minecraft:red_terracotta
setblock 472 35 486 minecraft:red_terracotta
setblock 472 35 504 minecraft:red_terracotta
setblock 473 35 464 minecraft:terracotta
fill 473 35 465 476 35 465 minecraft:red_terracotta
setblock 473 35 469 minecraft:terracotta
setblock 473 35 504 minecraft:terracotta
fill 474 35 464 477 35 464 minecraft:red_terracotta
fill 474 35 504 477 35 504 minecraft:red_terracotta
setblock 476 35 466 minecraft:terracotta
setblock 477 35 465 minecraft:terracotta
setblock 478 35 464 minecraft:terracotta
fill 478 35 465 478 38 465 minecraft:red_terracotta
setblock 478 35 504 minecraft:terracotta
fill 479 35 464 479 38 464 minecraft:red_terracotta
fill 479 35 504 479 38 504 minecraft:red_terracotta
setblock 480 35 466 minecraft:red_terracotta
fill 480 35 503 480 38 503 minecraft:red_terracotta
setblock 481 35 466 minecraft:terracotta
setblock 482 35 465 minecraft:terracotta
fill 482 35 466 482 38 466 minecraft:red_terracotta
setblock 483 35 464 minecraft:terracotta
fill 483 35 465 483 38 465 minecraft:red_terracotta
fill 483 35 502 483 36 502 minecraft:red_terracotta
setblock 483 35 504 minecraft:terracotta
fill 484 35 464 484 38 464 minecraft:red_terracotta
setblock 484 35 503 minecraft:terracotta
fill 484 35 504 484 38 504 minecraft:red_terracotta
setblock 485 35 502 minecraft:terracotta
fill 485 35 503 485 38 503 minecraft:red_terracotta
setblock 486 35 465 minecraft:red_terracotta
setblock 486 35 466 minecraft:terracotta
fill 486 35 502 486 38 502 minecraft:red_terracotta
setblock 487 35 465 minecraft:terracotta
fill 487 35 466 487 38 466 minecraft:red_terracotta
setblock 488 35 464 minecraft:terracotta
fill 488 35 465 488 38 465 minecraft:red_terracotta
setblock 488 35 504 minecraft:terracotta
fill 489 35 464 489 38 464 minecraft:red_terracotta
setblock 489 35 503 minecraft:terracotta
fill 489 35 504 489 38 504 minecraft:red_terracotta
setblock 490 35 502 minecraft:terracotta
fill 490 35 503 490 37 503 minecraft:red_terracotta
setblock 492 35 465 minecraft:terracotta
setblock 493 35 464 minecraft:terracotta
setblock 493 35 504 minecraft:terracotta
fill 494 35 464 495 35 464 minecraft:red_terracotta
fill 494 35 504 494 36 504 minecraft:red_terracotta
fill 499 35 464 499 37 464 minecraft:red_terracotta
setblock 502 35 465 minecraft:terracotta
setblock 503 35 464 minecraft:terracotta
fill 503 35 465 503 38 465 minecraft:red_terracotta
setblock 503 35 504 minecraft:terracotta
fill 504 35 464 504 38 464 minecraft:red_terracotta
fill 504 35 466 505 35 466 minecraft:red_terracotta
fill 504 35 504 504 38 504 minecraft:red_terracotta
setblock 506 35 466 minecraft:terracotta
setblock 507 35 465 minecraft:terracotta
fill 507 35 466 507 37 467 minecraft:red_terracotta
setblock 508 35 464 minecraft:terracotta
fill 508 35 465 508 38 465 minecraft:red_terracotta
setblock 508 35 468 minecraft:red_terracotta
setblock 508 35 469 minecraft:terracotta
fill 508 35 470 508 38 470 minecraft:red_terracotta
setblock 508 35 484 minecraft:terracotta
fill 508 35 485 508 37 485 minecraft:red_terracotta
setblock 508 35 489 minecraft:terracotta
fill 508 35 490 508 36 490 minecraft:red_terracotta
setblock 508 35 504 minecraft:terracotta
fill 509 35 464 509 38 464 minecraft:red_terracotta
setblock 509 35 467 minecraft:red_terracotta
setblock 509 35 468 minecraft:terracotta
fill 509 35 469 509 38 469 minecraft:red_terracotta
setblock 509 35 472 minecraft:red_terracotta
setblock 509 35 473 minecraft:terracotta
fill 509 35 474 509 36 476 minecraft:red_terracotta
setblock 509 35 478 minecraft:terracotta
fill 509 35 479 509 36 479 minecraft:red_terracotta
setblock 509 35 483 minecraft:terracotta
fill 509 35 484 509 37 484 minecraft:red_terracotta
setblock 509 35 488 minecraft:terracotta
fill 509 35 489 509 38 489 minecraft:red_terracotta
fill 509 35 504 509 38 504 minecraft:red_terracotta
setblock 510 35 467 minecraft:terracotta
fill 510 35 468 510 38 468 minecraft:red_terracotta
setblock 510 35 472 minecraft:terracotta
fill 510 35 473 510 38 473 minecraft:red_terracotta
setblock 510 35 477 minecraft:terracotta
fill 510 35 478 510 38 478 minecraft:red_terracotta
setblock 510 35 482 minecraft:terracotta
fill 510 35 483 510 38 483 minecraft:red_terracotta
setblock 510 35 487 minecraft:terracotta
fill 510 35 488 510 38 488 minecraft:red_terracotta
setblock 510 35 492 minecraft:terracotta
fill 510 35 493 510 37 493 minecraft:red_terracotta
setblock 511 35 466 minecraft:terracotta
fill 511 35 467 511 38 467 minecraft:red_terracotta
setblock 511 35 471 minecraft:terracotta
fill 511 35 472 511 38 472 minecraft:red_terracotta
setblock 511 35 476 minecraft:terracotta
fill 511 35 477 511 38 477 minecraft:red_terracotta
setblock 511 35 481 minecraft:terracotta
fill 511 35 482 511 38 482 minecraft:red_terracotta
setblock 511 35 486 minecraft:terracotta
fill 511 35 487 511 38 487 minecraft:red_terracotta
setblock 511 35 491 minecraft:terracotta
fill 511 35 492 511 38 492 minecraft:red_terracotta
setblock 471 36 464 minecraft:red_terracotta
setblock 471 36 465 minecraft:terracotta
fill 471 36 466 471 36 469 minecraft:red_terracotta
setblock 471 36 470 minecraft:terracotta
fill 471 36 471 471 39 471 minecraft:red_terracotta
setblock 471 36 475 minecraft:terracotta
fill 471 36 476 471 38 476 minecraft:red_terracotta
setblock 471 36 480 minecraft:terracotta
setblock 471 36 481 minecraft:red_terracotta
setblock 471 36 485 minecraft:terracotta
fill 471 36 486 471 38 486 minecraft:red_terracotta
fill 471 36 488 471 37 488 minecraft:red_terracotta
setblock 471 36 490 minecraft:terracotta
fill 471 36 491 471 39 491 minecraft:red_terracotta
setblock 471 36 494 minecraft:red_terracotta
setblock 471 36 501 minecraft:red_terracotta
setblock 472 36 464 minecraft:terracotta
fill 472 36 465 475 36 465 minecraft:red_terracotta
setblock 472 36 469 minecraft:terracotta
fill 472 36 470 472 39 470 minecraft:red_terracotta
setblock 472 36 504 minecraft:terracotta
fill 473 36 464 476 36 464 minecraft:red_terracotta
setblock 473 36 468 minecraft:terracotta
fill 473 36 469 473 37 469 minecraft:red_terracotta
fill 473 36 504 476 36 504 minecraft:red_terracotta
setblock 474 36 466 minecraft:red_terracotta
setblock 475 36 466 minecraft:terracotta
setblock 476 36 465 minecraft:terracotta
setblock 476 36 466 minecraft:red_terracotta
setblock 477 36 464 minecraft:terracotta
fill 477 36 465 477 39 465 minecraft:red_terracotta
setblock 477 36 504 minecraft:terracotta
fill 478 36 464 478 39 464 minecraft:red_terracotta
fill 478 36 504 478 39 504 minecraft:red_terracotta
setblock 479 36 466 minecraft:red_terracotta
setblock 480 36 466 minecraft:terracotta
setblock 481 36 465 minecraft:terracotta
fill 481 36 466 481 38 466 minecraft:red_terracotta
setblock 482 36 464 minecraft:terracotta
fill 482 36 465 482 39 465 minecraft:red_terracotta
setblock 482 36 504 minecraft:terracotta
fill 483 36 464 483 39 464 minecraft:red_terracotta
setblock 483 36 503 minecraft:terracotta
fill 483 36 504 483 39 504 minecraft:red_terracotta
setblock 484 36 466 minecraft:red_terracotta
setblock 484 36 502 minecraft:terracotta
fill 484 36 503 484 39 503 minecraft:red_terracotta
setblock 485 36 466 minecraft:terracotta
fill 485 36 502 485 38 502 minecraft:red_terracotta
setblock 486 36 465 minecraft:terracotta
fill 486 36 466 486 38 466 minecraft:red_terracotta
setblock 487 36 464 minecraft:terracotta
fill 487 36 465 487 39 465 minecraft:red_terracotta
setblock 487 36 504 minecraft:terracotta
fill 488 36 464 488 39 464 minecraft:red_terracotta
setblock 488 36 503 minecraft:terracotta
fill 488 36 504 488 39 504 minecraft:red_terracotta
setblock 489 36 466 minecraft:red_terracotta
setblock 489 36 502 minecraft:terracotta
fill 489 36 503 489 38 503 minecraft:red_terracotta
setblock 491 36 465 minecraft:terracotta
setblock 492 36 464 minecraft:terracotta
setblock 492 36 465 minecraft:red_terracotta
setblock 492 36 504 minecraft:terracotta
fill 493 36 464 494 36 464 minecraft:red_terracotta
fill 493 36 504 493 37 504 minecraft:red_terracotta
setblock 501 36 464 minecraft:red_terracotta
setblock 501 36 465 minecraft:terracotta
setblock 502 36 464 minecraft:terracotta
fill 502 36 465 502 39 465 minecraft:red_terracotta
setblock 502 36 504 minecraft:terracotta
fill 503 36 464 503 39 464 minecraft:red_terracotta
fill 503 36 466 504 36 466 minecraft:red_terracotta
fill 503 36 504 503 38 504 minecraft:red_terracotta
setblock 505 36 466 minecraft:terracotta
setblock 506 36 465 minecraft:terracotta
fill 506 36 466 506 38 467 minecraft:red_terracotta
setblock 507 36 464 minecraft:terracotta
fill 507 36 465 507 39 465 minecraft:red_terracotta
setblock 507 36 504 minecraft:terracotta
fill 508 36 464 508 39 464 minecraft:red_terracotta
setblock 508 36 468 minecraft:terracotta
fill 508 36 469 508 39 469 minecraft:red_terracotta
fill 508 36 471 508 37 471 minecraft:red_terracotta
setblock 508 36 483 minecraft:terracotta
setblock 508 36 484 minecraft:red_terracotta
setblock 508 36 487 minecraft:red_terracotta
setblock 508 36 488 minecraft:terracotta
fill 508 36 489 508 37 489 minecraft:red_terracotta
fill 508 36 504 508 38 504 minecraft:red_terracotta
setblock 509 36 467 minecraft:terracotta
fill 509 36 468 509 39 468 minecraft:red_terracotta
setblock 509 36 472 minecraft:terracotta
fill 509 36 473 509 39 473 minecraft:red_terracotta
setblock 509 36 482 minecraft:terracotta
fill 509 36 483 509 37 483 minecraft:red_terracotta
setblock 509 36 487 minecraft:terracotta
fill 509 36 488 509 38 488 minecraft:red_terracotta
setblock 510 36 466 minecraft:terracotta
fill 510 36 467 510 39 467 minecraft:red_terracotta
setblock 510 36 471 minecraft:terracotta
fill 510 36 472 510 39 472 minecraft:red_terracotta
setblock 510 36 476 minecraft:terracotta
fill 510 36 477 510 38 477 minecraft:red_terracotta
setblock 510 36 481 minecraft:terracotta
fill 510 36 482 510 38 482 minecraft:red_terracotta
setblock 510 36 486 minecraft:terracotta
fill 510 36 487 510 39 487 minecraft:red_terracotta
setblock 510 36 491 minecraft:terracotta
fill 510 36 492 510 38 492 minecraft:red_terracotta
setblock 511 36 465 minecraft:terracotta
fill 511 36 466 511 39 466 minecraft:red_terracotta
setblock 511 36 470 minecraft:terracotta
fill 511 36 471 511 39 471 minecraft:red_terracotta
setblock 511 36 475 minecraft:terracotta
fill 511 36 476 511 39 476 minecraft:red_terracotta
setblock 511 36 480 minecraft:terracotta
fill 511 36 481 511 38 481 minecraft:red_terracotta
setblock 511 36 485 minecraft:terracotta
fill 511 36 486 511 39 486 minecraft:red_terracotta
setblock 511 36 490 minecraft:terracotta
fill 511 36 491 511 39 491 minecraft:red_terracotta
setblock 471 37 464 minecraft:terracotta
fill 471 37 465 471 37 468 minecraft:red_terracotta
setblock 471 37 469 minecraft:terracotta
fill 471 37 470 471 40 470 minecraft:red_terracotta
setblock 471 37 473 minecraft:red_terracotta
setblock 471 37 474 minecraft:terracotta
fill 471 37 475 471 39 475 minecraft:red_terracotta
setblock 471 37 484 minecraft:terracotta
setblock 471 37 485 minecraft:red_terracotta
setblock 471 37 489 minecraft:terracotta
fill 471 37 490 471 39 490 minecraft:red_terracotta
setblock 471 37 494 minecraft:terracotta
setblock 471 37 503 minecraft:red_terracotta
setblock 471 37 504 minecraft:terracotta
fill 472 37 464 474 37 465 minecraft:red_terracotta
setblock 472 37 468 minecraft:terracotta
fill 472 37 469 472 40 469 minecraft:red_terracotta
setblock 472 37 473 minecraft:terracotta
fill 472 37 504 475 37 504 minecraft:red_terracotta
setblock 473 37 467 minecraft:terracotta
fill 473 37 468 473 38 468 minecraft:red_terracotta
setblock 473 37 474 minecraft:light[level=14]
setblock 473 37 482 minecraft:light[level=14]
setblock 473 37 490 minecraft:light[level=14]
setblock 473 37 498 minecraft:light[level=14]
setblock 474 37 466 minecraft:terracotta
setblock 475 37 464 minecraft:red_terracotta
setblock 475 37 465 minecraft:terracotta
setblock 476 37 464 minecraft:terracotta
fill 476 37 465 476 39 465 minecraft:red_terracotta
setblock 476 37 504 minecraft:terracotta
fill 477 37 464 477 40 464 minecraft:red_terracotta
fill 477 37 504 477 40 504 minecraft:red_terracotta
setblock 479 37 466 minecraft:terracotta
setblock 480 37 465 minecraft:terracotta
fill 480 37 466 480 38 466 minecraft:red_terracotta
setblock 481 37 464 minecraft:terracotta
fill 481 37 465 481 40 465 minecraft:red_terracotta
setblock 481 37 474 minecraft:light[level=14]
setblock 481 37 482 minecraft:light[level=14]
setblock 481 37 490 minecraft:light[level=14]
setblock 481 37 504 minecraft:terracotta
fill 482 37 464 482 40 464 minecraft:red_terracotta
setblock 482 37 503 minecraft:terracotta
fill 482 37 504 482 40 504 minecraft:red_terracotta
setblock 483 37 502 minecraft:terracotta
fill 483 37 503 483 40 503 minecraft:red_terracotta
setblock 484 37 466 minecraft:terracotta
fill 484 37 502 484 38 502 minecraft:red_terracotta
setblock 485 37 465 minecraft:terracotta
fill 485 37 466 485 39 466 minecraft:red_terracotta
setblock 486 37 464 minecraft:terracotta
fill 486 37 465 486 40 465 minecraft:red_terracotta
setblock 486 37 504 minecraft:terracotta
fill 487 37 464 487 40 464 minecraft:red_terracotta
setblock 487 37 503 minecraft:terracotta
fill 487 37 504 487 40 504 minecraft:red_terracotta
fill 488 37 503 488 39 503 minecraft:red_terracotta
setblock 489 37 466 minecraft:light[level=14]
setblock 489 37 490 minecraft:light[level=14]
setblock 489 37 498 minecraft:light[level=14]
setblock 490 37 465 minecraft:terracotta
setblock 491 37 464 minecraft:terracotta
setblock 491 37 465 minecraft:red_terracotta
setblock 491 37 504 minecraft:terracotta
fill 492 37 464 493 37 464 minecraft:red_terracotta
setblock 492 37 504 minecraft:red_terracotta
setblock 497 37 466 minecraft:light[level=14]
setblock 497 37 474 minecraft:light[level=14]
setblock 497 37 482 minecraft:light[level=14]
setblock 497 37 490 minecraft:light[level=14]
setblock 501 37 464 minecraft:terracotta
fill 501 37 465 501 38 465 minecraft:red_terracotta
fill 502 37 464 502 40 464 minecraft:red_terracotta
setblock 502 37 504 minecraft:red_terracotta
setblock 503 37 466 minecraft:red_terracotta
setblock 504 37 466 minecraft:terracotta
setblock 505 37 465 minecraft:terracotta
fill 505 37 466 505 38 467 minecraft:red_terracotta
setblock 505 37 474 minecraft:light[level=14]
setblock 505 37 482 minecraft:light[level=14]
setblock 505 37 490 minecraft:light[level=14]
setblock 505 37 498 minecraft:light[level=14]
setblock 506 37 464 minecraft:terracotta
fill 506 37 465 506 40 465 minecraft:red_terracotta
setblock 506 37 504 minecraft:terracotta
fill 507 37 464 507 40 464 minecraft:red_terracotta
fill 507 37 504 507 38 504 minecraft:red_terracotta
setblock 508 37 466 minecraft:red_terracotta
setblock 508 37 467 minecraft:terracotta
fill 508 37 468 508 39 468 minecraft:red_terracotta
setblock 508 37 472 minecraft:terracotta
setblock 508 37 487 minecraft:terracotta
setblock 508 37 488 minecraft:red_terracotta
setblock 509 37 466 minecraft:terracotta
fill 509 37 467 509 40 467 minecraft:red_terracotta
setblock 509 37 471 minecraft:terracotta
fill 509 37 472 509 40 472 minecraft:red_terracotta
fill 509 37 474 509 37 475 minecraft:red_terracotta
setblock 509 37 482 minecraft:red_terracotta
setblock 509 37 486 minecraft:terracotta
fill 509 37 487 509 38 487 minecraft:red_terracotta
setblock 509 37 490 minecraft:red_terracotta
setblock 509 37 491 minecraft:terracotta
setblock 510 37 465 minecraft:terracotta
fill 510 37 466 510 40 466 minecraft:red_terracotta
setblock 510 37 470 minecraft:terracotta
fill 510 37 471 510 40 471 minecraft:red_terracotta
setblock 510 37 475 minecraft:terracotta
fill 510 37 476 510 39 476 minecraft:red_terracotta
setblock 510 37 480 minecraft:terracotta
setblock 510 37 481 minecraft:red_terracotta
setblock 510 37 485 minecraft:terracotta
fill 510 37 486 510 39 486 minecraft:red_terracotta
setblock 510 37 490 minecraft:terracotta
fill 510 37 491 510 39 491 minecraft:red_terracotta
setblock 511 37 464 minecraft:terracotta
fill 511 37 465 511 40 465 minecraft:red_terracotta
setblock 511 37 469 minecraft:terracotta
fill 511 37 470 511 40 470 minecraft:red_terracotta
setblock 511 37 474 minecraft:terracotta
fill 511 37 475 511 40 475 minecraft:red_terracotta
setblock 511 37 479 minecraft:terracotta
fill 511 37 480 511 38 480 minecraft:red_terracotta
setblock 511 37 484 minecraft:terracotta
fill 511 37 485 511 39 485 minecraft:red_terracotta
setblock 511 37 489 minecraft:terracotta
fill 511 37 490 511 40 490 minecraft:red_terracotta
setblock 511 37 494 minecraft:terracotta
setblock 511 37 504 minecraft:terracotta
fill 471 38 464 471 38 467 minecraft:red_terracotta
setblock 471 38 468 minecraft:terracotta
fill 471 38 469 471 41 469 minecraft:red_terracotta
setblock 471 38 473 minecraft:terracotta
fill 471 38 474 471 41 474 minecraft:red_terracotta
setblock 471 38 488 minecraft:terracotta
fill 471 38 489 471 39 489 minecraft:red_terracotta
setblock 471 38 493 minecraft:terracotta
setblock 471 38 494 minecraft:red_terracotta
setblock 471 38 503 minecraft:terracotta
fill 471 38 504 474 38 504 minecraft:red_terracotta
fill 472 38 464 473 38 465 minecraft:red_terracotta
setblock 472 38 467 minecraft:terracotta
fill 472 38 468 472 40 468 minecraft:red_terracotta
setblock 472 38 472 minecraft:terracotta
setblock 473 38 466 minecraft:terracotta
setblock 473 38 467 minecraft:red_terracotta
setblock 474 38 464 minecraft:red_terracotta
setblock 474 38 465 minecraft:terracotta
setblock 475 38 464 minecraft:terracotta
fill 475 38 465 475 39 465 minecraft:red_terracotta
setblock 475 38 504 minecraft:terracotta
fill 476 38 464 476 41 464 minecraft:red_terracotta
setblock 476 38 504 minecraft:red_terracotta
setblock 479 38 465 minecraft:terracotta
setblock 480 38 464 minecraft:terracotta
fill 480 38 465 480 40 465 minecraft:red_terracotta
setblock 480 38 504 minecraft:terracotta
fill 481 38 464 481 41 464 minecraft:red_terracotta
setblock 481 38 503 minecraft:terracotta
fill 481 38 504 481 41 504 minecraft:red_terracotta
fill 482 38 503 482 41 503 minecraft:red_terracotta
setblock 483 38 466 minecraft:terracotta
setblock 484 38 465 minecraft:terracotta
fill 484 38 466 484 39 466 minecraft:red_terracotta
setblock 485 38 464 minecraft:terracotta
fill 485 38 465 485 40 465 minecraft:red_terracotta
setblock 485 38 504 minecraft:terracotta
fill 486 38 464 486 41 464 minecraft:red_terracotta
setblock 486 38 503 minecraft:terracotta
fill 486 38 504 486 41 504 minecraft:red_terracotta
fill 487 38 503 487 39 503 minecraft:red_terracotta
setblock 489 38 465 minecraft:terracotta
setblock 490 38 464 minecraft:terracotta
setblock 490 38 504 minecraft:terracotta
setblock 491 38 464 minecraft:red_terracotta
setblock 491 38 504 minecraft:red_terracotta
setblock 500 38 464 minecraft:terracotta
fill 501 38 464 501 41 464 minecraft:red_terracotta
setblock 503 38 466 minecraft:terracotta
setblock 504 38 465 minecraft:terracotta
fill 504 38 466 504 40 466 minecraft:red_terracotta
setblock 505 38 464 minecraft:terracotta
fill 505 38 465 505 41 465 minecraft:red_terracotta
setblock 505 38 504 minecraft:terracotta
fill 506 38 464 506 41 464 minecraft:red_terracotta
fill 506 38 504 506 39 504 minecraft:red_terracotta
setblock 507 38 466 minecraft:red_terracotta
setblock 507 38 467 minecraft:terracotta
setblock 508 38 466 minecraft:terracotta
setblock 508 38 467 minecraft:red_terracotta
setblock 508 38 471 minecraft:terracotta
fill 508 38 472 508 39 472 minecraft:red_terracotta
setblock 509 38 465 minecraft:terracotta
fill 509 38 466 509 39 466 minecraft:red_terracotta
setblock 509 38 470 minecraft:terracotta
fill 509 38 471 509 41 471 minecraft:red_terracotta
setblock 509 38 474 minecraft:red_terracotta
setblock 509 38 475 minecraft:terracotta
setblock 509 38 485 minecraft:terracotta
setblock 509 38 486 minecraft:red_terracotta
setblock 509 38 490 minecraft:terracotta
setblock 510 38 464 minecraft:terracotta
fill 510 38 465 510 40 465 minecraft:red_terracotta
setblock 510 38 469 minecraft:terracotta
fill 510 38 470 510 41 470 minecraft:red_terracotta
setblock 510 38 474 minecraft:terracotta
fill 510 38 475 510 41 475 minecraft:red_terracotta
setblock 510 38 484 minecraft:terracotta
setblock 510 38 485 minecraft:red_terracotta
setblock 510 38 489 minecraft:terracotta
fill 510 38 490 510 39 490 minecraft:red_terracotta
fill 511 38 464 511 41 464 minecraft:red_terracotta
setblock 511 38 468 minecraft:terracotta
fill 511 38 469 511 41 469 minecraft:red_terracotta
setblock 511 38 473 minecraft:terracotta
fill 511 38 474 511 41 474 minecraft:red_terracotta
setblock 511 38 478 minecraft:terracotta
fill 511 38 479 511 39 479 minecraft:red_terracotta
setblock 511 38 483 minecraft:terracotta
fill 511 38 484 511 39 484 minecraft:red_terracotta
setblock 511 38 488 minecraft:terracotta
fill 511 38 489 511 40 489 minecraft:red_terracotta
setblock 511 38 493 minecraft:terracotta
setblock 511 38 494 minecraft:red_terracotta
fill 471 39 464 471 39 466 minecraft:red_terracotta
setblock 471 39 467 minecraft:terracotta
fill 471 39 468 471 42 468 minecraft:red_terracotta
setblock 471 39 472 minecraft:terracotta
fill 471 39 473 471 42 473 minecraft:red_terracotta
setblock 471 39 488 minecraft:red_terracotta
setblock 471 39 492 minecraft:terracotta
setblock 471 39 493 minecraft:red_terracotta
setblock 471 39 504 minecraft:red_terracotta
fill 472 39 464 472 39 465 minecraft:red_terracotta
setblock 472 39 466 minecraft:terracotta
fill 472 39 467 472 40 467 minecraft:red_terracotta
setblock 472 39 471 minecraft:terracotta
setblock 472 39 472 minecraft:red_terracotta
setblock 473 39 464 minecraft:red_terracotta
setblock 473 39 465 minecraft:terracotta
setblock 474 39 464 minecraft:terracotta
setblock 474 39 465 minecraft:red_terracotta
fill 475 39 464 475 40 464 minecraft:red_terracotta
setblock 478 39 465 minecraft:terracotta
setblock 479 39 464 minecraft:terracotta
fill 479 39 465 479 40 465 minecraft:red_terracotta
setblock 479 39 504 minecraft:terracotta
fill 480 39 464 480 42 464 minecraft:red_terracotta
setblock 480 39 503 minecraft:terracotta
fill 480 39 504 480 42 504 minecraft:red_terracotta
fill 481 39 503 481 41 503 minecraft:red_terracotta
setblock 482 39 466 minecraft:terracotta
setblock 483 39 465 minecraft:terracotta
setblock 483 39 466 minecraft:red_terracotta
setblock 484 39 464 minecraft:terracotta
fill 484 39 465 484 41 465 minecraft:red_terracotta
setblock 484 39 504 minecraft:terracotta
fill 485 39 464 485 42 464 minecraft:red_terracotta
setblock 485 39 503 minecraft:terracotta
fill 485 39 504 485 42 504 minecraft:red_terracotta
fill 486 39 503 486 40 503 minecraft:red_terracotta
setblock 488 39 465 minecraft:terracotta
fill 488 39 478 488 88 479 minecraft:terracotta
setblock 489 39 464 minecraft:terracotta
setblock 489 39 504 minecraft:terracotta
setblock 490 39 464 minecraft:red_terracotta
setblock 490 39 504 minecraft:red_terracotta
setblock 500 39 464 minecraft:red_terracotta
setblock 503 39 465 minecraft:terracotta
setblock 503 39 466 minecraft:red_terracotta
setblock 504 39 464 minecraft:terracotta
fill 504 39 465 504 42 465 minecraft:red_terracotta
fill 505 39 464 505 42 464 minecraft:red_terracotta
fill 505 39 466 506 39 466 minecraft:red_terracotta
setblock 505 39 504 minecraft:red_terracotta
setblock 506 39 467 minecraft:terracotta
setblock 507 39 466 minecraft:terracotta
setblock 508 39 465 minecraft:terracotta
fill 508 39 466 508 40 466 minecraft:red_terracotta
setblock 508 39 470 minecraft:terracotta
setblock 508 39 471 minecraft:red_terracotta
setblock 509 39 464 minecraft:terracotta
fill 509 39 465 509 40 465 minecraft:red_terracotta
setblock 509 39 469 minecraft:terracotta
fill 509 39 470 509 42 470 minecraft:red_terracotta
setblock 509 39 474 minecraft:terracotta
fill 510 39 464 510 41 464 minecraft:red_terracotta
setblock 510 39 468 minecraft:terracotta
fill 510 39 469 510 42 469 minecraft:red_terracotta
setblock 510 39 473 minecraft:terracotta
fill 510 39 474 510 42 474 minecraft:red_terracotta
setblock 510 39 488 minecraft:terracotta
setblock 510 39 489 minecraft:red_terracotta
setblock 511 39 467 minecraft:terracotta
fill 511 39 468 511 42 468 minecraft:red_terracotta
setblock 511 39 472 minecraft:terracotta
fill 511 39 473 511 42 473 minecraft:red_terracotta
setblock 511 39 477 minecraft:terracotta
setblock 511 39 478 minecraft:red_terracotta
setblock 511 39 483 minecraft:red_terracotta
setblock 511 39 487 minecraft:terracotta
fill 511 39 488 511 40 488 minecraft:red_terracotta
setblock 511 39 492 minecraft:terracotta
setblock 511 39 493 minecraft:red_terracotta
fill 471 40 464 471 40 465 minecraft:red_terracotta
setblock 471 40 466 minecraft:terracotta
fill 471 40 467 471 43 467 minecraft:red_terracotta
setblock 471 40 471 minecraft:terracotta
fill 471 40 472 471 43 472 minecraft:red_terracotta
setblock 471 40 492 minecraft:red_terracotta
setblock 472 40 464 minecraft:red_terracotta
setblock 472 40 466 minecraft:red_terracotta
setblock 472 40 470 minecraft:terracotta
setblock 472 40 471 minecraft:red_terracotta
setblock 473 40 464 minecraft:terracotta
setblock 474 40 464 minecraft:red_terracotta
setblock 478 40 464 minecraft:terracotta
setblock 478 40 504 minecraft:terracotta
fill 479 40 464 479 43 464 minecraft:red_terracotta
fill 479 40 504 479 43 504 minecraft:red_terracotta
setblock 482 40 465 minecraft:terracotta
setblock 483 40 464 minecraft:terracotta
fill 483 40 465 483 41 465 minecraft:red_terracotta
setblock 483 40 504 minecraft:terracotta
fill 484 40 464 484 42 464 minecraft:red_terracotta
setblock 484 40 503 minecraft:terracotta
fill 484 40 504 484 43 504 minecraft:red_terracotta
setblock 485 40 503 minecraft:red_terracotta
fill 487 40 478 487 55 480 minecraft:terracotta
setblock 488 40 464 minecraft:terracotta
setblock 488 40 504 minecraft:terracotta
setblock 502 40 465 minecraft:terracotta
setblock 503 40 464 minecraft:terracotta
fill 503 40 465 503 41 465 minecraft:red_terracotta
fill 504 40 464 504 43 464 minecraft:red_terracotta
setblock 505 40 466 minecraft:red_terracotta
setblock 506 40 466 minecraft:terracotta
setblock 507 40 465 minecraft:terracotta
setblock 507 40 466 minecraft:red_terracotta
setblock 508 40 464 minecraft:terracotta
fill 508 40 465 508 41 465 minecraft:red_terracotta
setblock 508 40 470 minecraft:red_terracotta
fill 509 40 464 509 42 464 minecraft:red_terracotta
setblock 509 40 468 minecraft:terracotta
fill 509 40 469 509 41 469 minecraft:red_terracotta
setblock 509 40 473 minecraft:terracotta
setblock 509 40 474 minecraft:red_terracotta
setblock 510 40 467 minecraft:terracotta
fill 510 40 468 510 42 468 minecraft:red_terracotta
setblock 510 40 472 minecraft:terracotta
fill 510 40 473 510 43 473 minecraft:red_terracotta
setblock 511 40 466 minecraft:terracotta
fill 511 40 467 511 43 467 minecraft:red_terracotta
setblock 511 40 471 minecraft:terracotta
fill 511 40 472 511 43 472 minecraft:red_terracotta
setblock 511 40 476 minecraft:terracotta
setblock 511 40 477 minecraft:red_terracotta
setblock 511 40 487 minecraft:red_terracotta
setblock 511 40 491 minecraft:terracotta
setblock 511 40 492 minecraft:red_terracotta
setblock 471 41 464 minecraft:red_terracotta
setblock 471 41 465 minecraft:terracotta
fill 471 41 466 471 42 466 minecraft:red_terracotta
setblock 471 41 470 minecraft:terracotta
fill 471 41 471 471 44 471 minecraft:red_terracotta
setblock 472 41 464 minecraft:terracotta
setblock 472 41 469 minecraft:terracotta
setblock 477 41 464 minecraft:terracotta
fill 478 41 464 478 42 464 minecraft:red_terracotta
fill 478 41 504 478 44 504 minecraft:red_terracotta
setblock 481 41 465 minecraft:terracotta
setblock 482 41 464 minecraft:terracotta
setblock 482 41 465 minecraft:red_terracotta
setblock 482 41 504 minecraft:terracotta
fill 483 41 464 483 43 464 minecraft:red_terracotta
setblock 483 41 503 minecraft:terracotta
fill 483 41 504 483 44 504 minecraft:red_terracotta
setblock 484 41 503 minecraft:red_terracotta
setblock 487 41 504 minecraft:terracotta
setblock 502 41 464 minecraft:terracotta
fill 503 41 464 503 44 464 minecraft:red_terracotta
setblock 506 41 465 minecraft:terracotta
setblock 507 41 464 minecraft:terracotta
setblock 507 41 465 minecraft:red_terracotta
fill 508 41 464 508 42 464 minecraft:red_terracotta
setblock 509 41 468 minecraft:red_terracotta
setblock 509 41 472 minecraft:terracotta
setblock 509 41 473 minecraft:red_terracotta
setblock 510 41 466 minecraft:terracotta
fill 510 41 467 510 42 467 minecraft:red_terracotta
setblock 510 41 471 minecraft:terracotta
fill 510 41 472 510 44 472 minecraft:red_terracotta
setblock 511 41 465 minecraft:terracotta
fill 511 41 466 511 43 466 minecraft:red_terracotta
setblock 511 41 470 minecraft:terracotta
fill 511 41 471 511 44 471 minecraft:red_terracotta
setblock 511 41 475 minecraft:terracotta
fill 511 41 476 511 44 476 minecraft:red_terracotta
setblock 471 42 465 minecraft:red_terracotta
setblock 471 42 469 minecraft:terracotta
fill 471 42 470 471 45 470 minecraft:red_terracotta
setblock 481 42 464 minecraft:terracotta
setblock 481 42 504 minecraft:terracotta
fill 482 42 464 482 44 464 minecraft:red_terracotta
setblock 482 42 503 minecraft:terracotta
fill 482 42 504 482 45 504 minecraft:red_terracotta
setblock 483 42 503 minecraft:red_terracotta
setblock 486 42 504 minecraft:terracotta
fill 502 42 464 502 45 464 minecraft:red_terracotta
setblock 505 42 465 minecraft:terracotta
setblock 506 42 464 minecraft:terracotta
setblock 506 42 465 minecraft:red_terracotta
fill 507 42 464 507 43 464 minecraft:red_terracotta
setblock 509 42 471 minecraft:terracotta
setblock 509 42 472 minecraft:red_terracotta
setblock 510 42 470 minecraft:terracotta
fill 510 42 471 510 45 471 minecraft:red_terracotta
setblock 511 42 465 minecraft:red_terracotta
setblock 511 42 469 minecraft:terracotta
fill 511 42 470 511 45 470 minecraft:red_terracotta
setblock 511 42 474 minecraft:terracotta
fill 511 42 475 511 45 475 minecraft:red_terracotta
setblock 471 43 468 minecraft:terracotta
fill 471 43 469 471 44 469 minecraft:red_terracotta
setblock 471 43 473 minecraft:terracotta
setblock 480 43 464 minecraft:terracotta
setblock 480 43 504 minecraft:terracotta
fill 481 43 464 481 46 464 minecraft:red_terracotta
fill 481 43 504 481 46 504 minecraft:red_terracotta
fill 482 43 503 482 46 503 minecraft:red_terracotta
setblock 485 43 504 minecraft:terracotta
setblock 505 43 464 minecraft:terracotta
fill 506 43 464 506 44 464 minecraft:red_terracotta
setblock 510 43 469 minecraft:terracotta
fill 510 43 470 510 45 470 minecraft:red_terracotta
setblock 510 43 474 minecraft:terracotta
setblock 511 43 468 minecraft:terracotta
fill 511 43 469 511 46 469 minecraft:red_terracotta
setblock 511 43 473 minecraft:terracotta
fill 511 43 474 511 46 474 minecraft:red_terracotta
setblock 471 44 468 minecraft:red_terracotta
setblock 471 44 472 minecraft:terracotta
fill 471 44 473 471 47 473 minecraft:red_terracotta
fill 477 44 504 477 45 504 minecraft:red_terracotta
setblock 479 44 464 minecraft:terracotta
setblock 479 44 504 minecraft:terracotta
fill 480 44 464 480 47 464 minecraft:red_terracotta
setblock 480 44 503 minecraft:terracotta
fill 480 44 504 480 47 504 minecraft:red_terracotta
fill 481 44 503 481 47 503 minecraft:red_terracotta
setblock 484 44 504 minecraft:terracotta
fill 485 44 504 485 47 504 minecraft:red_terracotta
fill 497 44 474 497 45 475 minecraft:orange_concrete
setblock 504 44 464 minecraft:terracotta
fill 505 44 464 505 47 464 minecraft:red_terracotta
setblock 510 44 469 minecraft:red_terracotta
setblock 510 44 473 minecraft:terracotta
fill 510 44 474 510 47 474 minecraft:red_terracotta
setblock 511 44 467 minecraft:terracotta
fill 511 44 468 511 47 468 minecraft:red_terracotta
setblock 511 44 472 minecraft:terracotta
fill 511 44 473 511 47 473 minecraft:red_terracotta
setblock 471 45 471 minecraft:terracotta
fill 471 45 472 471 48 472 minecraft:red_terracotta
setblock 471 45 495 minecraft:red_terracotta
setblock 471 45 496 minecraft:terracotta
fill 471 45 497 471 48 497 minecraft:red_terracotta
setblock 473 45 466 minecraft:light[level=14]
setblock 473 45 474 minecraft:light[level=14]
setblock 473 45 482 minecraft:light[level=14]
setblock 473 45 490 minecraft:light[level=14]
setblock 473 45 498 minecraft:light[level=14]
fill 476 45 504 476 46 504 minecraft:red_terracotta
setblock 478 45 504 minecraft:terracotta
fill 479 45 464 479 48 464 minecraft:red_terracotta
setblock 479 45 503 minecraft:terracotta
fill 479 45 504 479 48 504 minecraft:red_terracotta
fill 480 45 503 480 48 503 minecraft:red_terracotta
setblock 481 45 466 minecraft:light[level=14]
setblock 481 45 474 minecraft:light[level=14]
setblock 481 45 482 minecraft:light[level=14]
setblock 481 45 490 minecraft:light[level=14]
fill 482 45 464 482 63 464 minecraft:magma_block
setblock 483 45 503 minecraft:red_terracotta
setblock 483 45 504 minecraft:terracotta
fill 484 45 504 484 48 504 minecraft:red_terracotta
setblock 489 45 466 minecraft:light[level=14]
setblock 489 45 490 minecraft:light[level=14]
setblock 489 45 498 minecraft:light[level=14]
setblock 497 45 466 minecraft:light[level=14]
setblock 497 45 482 minecraft:light[level=14]
setblock 497 45 490 minecraft:light[level=14]
fill 501 45 464 501 46 464 minecraft:red_terracotta
setblock 503 45 464 minecraft:terracotta
fill 504 45 464 504 48 464 minecraft:red_terracotta
setblock 505 45 466 minecraft:light[level=14]
setblock 505 45 474 minecraft:light[level=14]
setblock 505 45 482 minecraft:light[level=14]
setblock 505 45 490 minecraft:light[level=14]
setblock 505 45 498 minecraft:light[level=14]
setblock 510 45 472 minecraft:terracotta
fill 510 45 473 510 48 473 minecraft:red_terracotta
fill 510 45 475 510 46 475 minecraft:red_terracotta
setblock 511 45 467 minecraft:red_terracotta
setblock 511 45 471 minecraft:terracotta
fill 511 45 472 511 48 472 minecraft:red_terracotta
setblock 511 45 476 minecraft:terracotta
fill 511 45 477 511 48 477 minecraft:red_terracotta
fill 471 46 471 471 49 471 minecraft:red_terracotta
setblock 471 46 474 minecraft:red_terracotta
setblock 471 46 494 minecraft:red_terracotta
setblock 471 46 495 minecraft:terracotta
fill 471 46 496 471 49 496 minecraft:red_terracotta
fill 471 46 498 471 46 499 minecraft:red_terracotta
setblock 471 46 500 minecraft:terracotta
fill 474 46 504 475 47 504 minecraft:red_terracotta
setblock 477 46 503 minecraft:red_terracotta
setblock 477 46 504 minecraft:terracotta
fill 478 46 464 478 49 464 minecraft:red_terracotta
setblock 478 46 503 minecraft:terracotta
fill 478 46 504 478 49 504 minecraft:red_terracotta
fill 479 46 503 479 49 503 minecraft:red_terracotta
fill 480 46 502 481 48 502 minecraft:red_terracotta
setblock 482 46 504 minecraft:terracotta
setblock 483 46 503 minecraft:terracotta
fill 483 46 504 483 49 504 minecraft:red_terracotta
fill 500 46 464 500 47 464 minecraft:red_terracotta
setblock 502 46 464 minecraft:terracotta
fill 503 46 464 503 49 464 minecraft:red_terracotta
setblock 510 46 471 minecraft:terracotta
fill 510 46 472 510 49 472 minecraft:red_terracotta
setblock 511 46 470 minecraft:terracotta
fill 511 46 471 511 49 471 minecraft:red_terracotta
setblock 511 46 475 minecraft:terracotta
fill 511 46 476 511 49 476 minecraft:red_terracotta
setblock 471 47 474 minecraft:terracotta
fill 471 47 475 471 50 475 minecraft:red_terracotta
setblock 471 47 494 minecraft:terracotta
fill 471 47 495 471 50 495 minecraft:red_terracotta
setblock 471 47 498 minecraft:red_terracotta
setblock 471 47 499 minecraft:terracotta
fill 471 47 500 471 47 503 minecraft:red_terracotta
fill 472 47 496 472 47 497 minecraft:red_terracotta
setblock 472 47 498 minecraft:terracotta
fill 472 47 499 472 50 499 minecraft:red_terracotta
fill 472 47 504 473 49 504 minecraft:red_terracotta
fill 475 47 503 476 47 503 minecraft:red_terracotta
setblock 476 47 504 minecraft:terracotta
fill 477 47 464 477 50 464 minecraft:red_terracotta
setblock 477 47 502 minecraft:red_terracotta
setblock 477 47 503 minecraft:terracotta
fill 477 47 504 477 50 504 minecraft:red_terracotta
setblock 478 47 502 minecraft:terracotta
fill 478 47 503 478 50 503 minecraft:red_terracotta
fill 479 47 502 479 50 502 minecraft:red_terracotta
fill 480 47 474 480 48 475 minecraft:orange_concrete
setblock 481 47 464 minecraft:terracotta
setblock 481 47 504 minecraft:terracotta
setblock 482 47 502 minecraft:red_terracotta
setblock 482 47 503 minecraft:terracotta
fill 482 47 504 482 50 504 minecraft:red_terracotta
fill 483 47 503 484 49 503 minecraft:red_terracotta
fill 499 47 464 499 48 464 minecraft:red_terracotta
setblock 501 47 464 minecraft:terracotta
fill 502 47 464 502 50 464 minecraft:red_terracotta
fill 510 47 471 510 49 471 minecraft:red_terracotta
setblock 510 47 475 minecraft:terracotta
fill 510 47 476 510 50 476 minecraft:red_terracotta
fill 511 47 467 511 48 467 minecraft:red_terracotta
setblock 511 47 469 minecraft:terracotta
fill 511 47 470 511 50 470 minecraft:red_terracotta
setblock 511 47 474 minecraft:terracotta
fill 511 47 475 511 50 475 minecraft:red_terracotta
setblock 511 47 478 minecraft:red_terracotta
setblock 471 48 473 minecraft:terracotta
fill 471 48 474 471 51 474 minecraft:red_terracotta
fill 471 48 476 471 49 476 minecraft:red_terracotta
setblock 471 48 493 minecraft:terracotta
fill 471 48 494 471 51 494 minecraft:red_terracotta
setblock 471 48 498 minecraft:terracotta
fill 471 48 499 471 48 502 minecraft:red_terracotta
setblock 471 48 503 minecraft:terracotta
fill 471 48 504 471 51 504 minecraft:red_terracotta
fill 472 48 495 472 48 496 minecraft:red_terracotta
setblock 472 48 497 minecraft:terracotta
fill 472 48 498 473 50 498 minecraft:red_terracotta
fill 472 48 500 472 48 501 minecraft:red_terracotta
setblock 472 48 502 minecraft:terracotta
fill 473 48 497 473 51 497 minecraft:red_terracotta
fill 473 48 499 473 49 499 minecraft:red_terracotta
fill 473 48 503 475 48 503 minecraft:red_terracotta
setblock 474 48 504 minecraft:red_terracotta
setblock 475 48 464 minecraft:terracotta
fill 475 48 502 476 48 502 minecraft:red_terracotta
setblock 475 48 504 minecraft:terracotta
fill 476 48 464 476 51 464 minecraft:red_terracotta
setblock 476 48 503 minecraft:terracotta
fill 476 48 504 476 51 504 minecraft:red_terracotta
setblock 477 48 501 minecraft:red_terracotta
setblock 477 48 502 minecraft:terracotta
fill 477 48 503 477 51 503 minecraft:red_terracotta
setblock 478 48 501 minecraft:terracotta
fill 478 48 502 478 51 502 minecraft:red_terracotta
fill 479 48 501 481 49 501 minecraft:red_terracotta
setblock 480 48 464 minecraft:terracotta
setblock 480 48 504 minecraft:terracotta
fill 481 48 464 481 51 464 minecraft:red_terracotta
setblock 481 48 503 minecraft:terracotta
fill 481 48 504 481 51 504 minecraft:red_terracotta
setblock 482 48 502 minecraft:terracotta
fill 482 48 503 482 51 503 minecraft:red_terracotta
fill 483 48 502 483 51 502 minecraft:red_terracotta
setblock 485 48 504 minecraft:terracotta
fill 498 48 464 498 49 464 minecraft:red_terracotta
fill 498 48 504 499 48 504 minecraft:red_terracotta
setblock 500 48 464 minecraft:terracotta
setblock 500 48 504 minecraft:terracotta
fill 501 48 464 501 51 464 minecraft:red_terracotta
fill 501 48 504 503 49 504 minecraft:red_terracotta
setblock 505 48 464 minecraft:terracotta
fill 506 48 464 506 51 464 minecraft:red_terracotta
setblock 510 48 474 minecraft:terracotta
fill 510 48 475 510 51 475 minecraft:red_terracotta
fill 510 48 477 510 49 477 minecraft:red_terracotta
setblock 511 48 468 minecraft:terracotta
fill 511 48 469 511 51 469 minecraft:red_terracotta
setblock 511 48 473 minecraft:terracotta
fill 511 48 474 511 51 474 minecraft:red_terracotta
setblock 511 48 478 minecraft:terracotta
fill 511 48 479 511 51 479 minecraft:red_terracotta
fill 511 48 496 511 48 497 minecraft:red_terracotta
setblock 511 48 498 minecraft:terracotta
fill 511 48 499 511 50 500 minecraft:red_terracotta
setblock 471 49 472 minecraft:terracotta
fill 471 49 473 471 51 473 minecraft:red_terracotta
setblock 471 49 477 minecraft:terracotta
fill 471 49 478 471 52 478 minecraft:red_terracotta
fill 471 49 493 471 52 493 minecraft:red_terracotta
setblock 471 49 497 minecraft:terracotta
fill 471 49 498 471 49 501 minecraft:red_terracotta
setblock 471 49 502 minecraft:terracotta
fill 471 49 503 474 49 503 minecraft:red_terracotta
fill 472 49 494 472 49 495 minecraft:red_terracotta
setblock 472 49 496 minecraft:terracotta
fill 472 49 497 472 52 497 minecraft:red_terracotta
setblock 472 49 500 minecraft:red_terracotta
setblock 472 49 501 minecraft:terracotta
fill 472 49 502 475 49 502 minecraft:red_terracotta
setblock 473 49 464 minecraft:red_terracotta
fill 473 49 496 473 52 496 minecraft:red_terracotta
setblock 473 49 500 minecraft:terracotta
fill 473 49 501 473 52 501 minecraft:red_terracotta
setblock 474 49 464 minecraft:terracotta
setblock 474 49 504 minecraft:terracotta
fill 475 49 464 475 52 464 minecraft:red_terracotta
setblock 475 49 503 minecraft:terracotta
fill 475 49 504 475 52 504 minecraft:red_terracotta
setblock 476 49 501 minecraft:red_terracotta
setblock 476 49 502 minecraft:terracotta
fill 476 49 503 476 52 503 minecraft:red_terracotta
setblock 477 49 501 minecraft:terracotta
fill 477 49 502 477 52 502 minecraft:red_terracotta
fill 478 49 497 478 49 500 minecraft:terracotta
fill 478 49 501 478 52 501 minecraft:red_terracotta
setblock 479 49 464 minecraft:terracotta
fill 479 49 497 481 88 499 minecraft:terracotta
fill 479 49 500 479 52 500 minecraft:red_terracotta
setblock 479 49 504 minecraft:terracotta
fill 480 49 464 480 52 464 minecraft:red_terracotta
fill 480 49 500 481 49 500 minecraft:terracotta
setblock 480 49 502 minecraft:red_terracotta
setblock 480 49 503 minecraft:terracotta
fill 480 49 504 480 52 504 minecraft:red_terracotta
setblock 481 49 502 minecraft:terracotta
fill 481 49 503 481 52 503 minecraft:red_terracotta
setblock 482 49 501 minecraft:terracotta
fill 482 49 502 482 52 502 minecraft:red_terracotta
setblock 484 49 504 minecraft:terracotta
fill 485 49 504 485 52 504 minecraft:red_terracotta
fill 496 49 504 498 49 504 minecraft:red_terracotta
fill 497 49 464 497 50 464 minecraft:red_terracotta
setblock 499 49 464 minecraft:terracotta
setblock 499 49 503 minecraft:red_terracotta
setblock 499 49 504 minecraft:terracotta
fill 500 49 464 500 51 465 minecraft:red_terracotta
setblock 500 49 503 minecraft:terracotta
fill 500 49 504 500 52 504 minecraft:red_terracotta
fill 501 49 465 502 49 465 minecraft:red_terracotta
fill 501 49 503 501 52 503 minecraft:red_terracotta
setblock 504 49 464 minecraft:terracotta
setblock 504 49 504 minecraft:terracotta
fill 505 49 464 505 52 464 minecraft:red_terracotta
fill 505 49 504 505 52 504 minecraft:red_terracotta
fill 507 49 464 507 50 464 minecraft:red_terracotta
setblock 510 49 473 minecraft:terracotta
fill 510 49 474 510 51 474 minecraft:red_terracotta
fill 511 49 464 511 49 466 minecraft:red_terracotta
setblock 511 49 467 minecraft:terracotta
fill 511 49 468 511 52 468 minecraft:red_terracotta
setblock 511 49 472 minecraft:terracotta
fill 511 49 473 511 52 473 minecraft:red_terracotta
setblock 511 49 477 minecraft:terracotta
fill 511 49 478 511 52 478 minecraft:red_terracotta
fill 511 49 480 511 50 480 minecraft:red_terracotta
setblock 511 49 496 minecraft:red_terracotta
setblock 511 49 497 minecraft:terracotta
fill 511 49 498 511 52 498 minecraft:red_terracotta
setblock 511 49 501 minecraft:red_terracotta
setblock 511 49 502 minecraft:terracotta
fill 511 49 503 511 51 504 minecraft:red_terracotta
setblock 471 50 472 minecraft:red_terracotta
setblock 471 50 476 minecraft:terracotta
fill 471 50 477 471 53 477 minecraft:red_terracotta
fill 471 50 479 471 51 479 minecraft:red_terracotta
setblock 471 50 496 minecraft:terracotta
fill 471 50 497 471 50 500 minecraft:red_terracotta
setblock 471 50 501 minecraft:terracotta
fill 471 50 502 473 50 503 minecraft:red_terracotta
setblock 472 50 464 minecraft:red_terracotta
setblock 472 50 494 minecraft:red_terracotta
setblock 472 50 495 minecraft:terracotta
fill 472 50 496 472 53 496 minecraft:red_terracotta
setblock 472 50 500 minecraft:terracotta
fill 472 50 501 472 53 501 minecraft:red_terracotta
setblock 472 50 504 minecraft:red_terracotta
setblock 473 50 464 minecraft:terracotta
fill 473 50 495 473 53 495 minecraft:red_terracotta
setblock 473 50 499 minecraft:terracotta
fill 473 50 500 474 52 500 minecraft:red_terracotta
setblock 473 50 504 minecraft:terracotta
fill 474 50 464 474 53 464 minecraft:red_terracotta
setblock 474 50 497 minecraft:red_terracotta
setblock 474 50 498 minecraft:terracotta
fill 474 50 499 474 53 499 minecraft:red_terracotta
fill 474 50 501 474 50 502 minecraft:red_terracotta
setblock 474 50 503 minecraft:terracotta
fill 474 50 504 474 53 504 minecraft:red_terracotta
setblock 475 50 501 minecraft:red_terracotta
setblock 475 50 502 minecraft:terracotta
fill 475 50 503 475 53 503 minecraft:red_terracotta
setblock 476 50 501 minecraft:terracotta
fill 476 50 502 476 53 502 minecraft:red_terracotta
setblock 477 50 500 minecraft:terracotta
fill 477 50 501 477 53 501 minecraft:red_terracotta
setblock 478 50 464 minecraft:terracotta
fill 478 50 497 478 88 499 minecraft:terracotta
fill 478 50 500 478 52 500 minecraft:red_terracotta
setblock 478 50 504 minecraft:terracotta
fill 479 50 464 479 53 464 minecraft:red_terracotta
fill 479 50 501 480 50 501 minecraft:red_terracotta
setblock 479 50 503 minecraft:terracotta
fill 479 50 504 479 53 504 minecraft:red_terracotta
fill 480 50 500 480 51 500 minecraft:red_terracotta
setblock 480 50 502 minecraft:terracotta
fill 480 50 503 480 53 503 minecraft:red_terracotta
fill 481 50 500 481 50 501 minecraft:terracotta
fill 481 50 502 481 53 502 minecraft:red_terracotta
fill 482 50 501 482 51 501 minecraft:red_terracotta
setblock 483 50 503 minecraft:red_terracotta
setblock 483 50 504 minecraft:terracotta
setblock 484 50 503 minecraft:terracotta
fill 484 50 504 484 53 504 minecraft:red_terracotta
fill 486 50 504 486 51 504 minecraft:red_terracotta
fill 495 50 504 497 50 504 minecraft:red_terracotta
fill 496 50 464 496 51 464 minecraft:red_terracotta
fill 497 50 503 498 50 503 minecraft:red_terracotta
setblock 498 50 464 minecraft:terracotta
fill 498 50 465 499 52 465 minecraft:red_terracotta
setblock 498 50 504 minecraft:terracotta
fill 499 50 464 499 53 464 minecraft:red_terracotta
setblock 499 50 503 minecraft:terracotta
fill 499 50 504 499 53 504 minecraft:red_terracotta
fill 500 50 503 500 53 503 minecraft:red_terracotta
setblock 501 50 465 minecraft:red_terracotta
fill 501 50 504 502 50 504 minecraft:red_terracotta
setblock 502 50 465 minecraft:terracotta
fill 502 50 503 502 51 503 minecraft:red_terracotta
setblock 503 50 464 minecraft:terracotta
setblock 503 50 504 minecraft:terracotta
fill 504 50 464 504 53 464 minecraft:red_terracotta
fill 504 50 504 504 53 504 minecraft:red_terracotta
fill 506 50 504 507 50 504 minecraft:red_terracotta
setblock 508 50 464 minecraft:terracotta
fill 509 50 464 511 51 464 minecraft:red_terracotta
fill 509 50 504 510 52 504 minecraft:red_terracotta
setblock 510 50 472 minecraft:terracotta
fill 510 50 473 510 51 473 minecraft:red_terracotta
setblock 510 50 477 minecraft:terracotta
fill 510 50 478 510 52 478 minecraft:red_terracotta
setblock 511 50 465 minecraft:red_terracotta
setblock 511 50 466 minecraft:terracotta
fill 511 50 467 511 53 467 minecraft:red_terracotta
setblock 511 50 471 minecraft:terracotta
fill 511 50 472 511 53 472 minecraft:red_terracotta
setblock 511 50 476 minecraft:terracotta
fill 511 50 477 511 53 477 minecraft:red_terracotta
setblock 511 50 495 minecraft:red_terracotta
setblock 511 50 496 minecraft:terracotta
fill 511 50 497 511 53 497 minecraft:red_terracotta
setblock 511 50 501 minecraft:terracotta
fill 511 50 502 511 53 502 minecraft:red_terracotta
setblock 471 51 464 minecraft:red_terracotta
setblock 471 51 475 minecraft:terracotta
fill 471 51 476 471 54 476 minecraft:red_terracotta
setblock 471 51 480 minecraft:terracotta
setblock 471 51 495 minecraft:terracotta
fill 471 51 496 471 51 499 minecraft:red_terracotta
setblock 471 51 500 minecraft:terracotta
fill 471 51 501 471 52 503 minecraft:red_terracotta
setblock 472 51 464 minecraft:terracotta
setblock 472 51 494 minecraft:terracotta
fill 472 51 495 472 54 495 minecraft:red_terracotta
setblock 472 51 498 minecraft:red_terracotta
setblock 472 51 499 minecraft:terracotta
fill 472 51 500 472 54 500 minecraft:red_terracotta
fill 472 51 502 472 51 503 minecraft:red_terracotta
setblock 472 51 504 minecraft:terracotta
fill 473 51 464 473 54 464 minecraft:red_terracotta
setblock 473 51 498 minecraft:terracotta
fill 473 51 499 473 54 499 minecraft:red_terracotta
setblock 473 51 502 minecraft:red_terracotta
setblock 473 51 503 minecraft:terracotta
fill 473 51 504 473 54 504 minecraft:red_terracotta
setblock 474 51 496 minecraft:red_terracotta
setblock 474 51 497 minecraft:terracotta
fill 474 51 498 474 54 498 minecraft:red_terracotta
setblock 474 51 501 minecraft:red_terracotta
setblock 474 51 502 minecraft:terracotta
fill 474 51 503 474 54 503 minecraft:red_terracotta
setblock 475 51 501 minecraft:terracotta
fill 475 51 502 475 54 502 minecraft:red_terracotta
setblock 476 51 500 minecraft:terracotta
fill 476 51 501 476 54 501 minecraft:red_terracotta
setblock 477 51 464 minecraft:terracotta
fill 477 51 500 477 53 500 minecraft:red_terracotta
setblock 477 51 504 minecraft:terracotta
fill 478 51 464 478 54 464 minecraft:red_terracotta
setblock 478 51 503 minecraft:terracotta
fill 478 51 504 478 54 504 minecraft:red_terracotta
setblock 479 51 501 minecraft:red_terracotta
setblock 479 51 502 minecraft:terracotta
fill 479 51 503 479 54 503 minecraft:red_terracotta
setblock 480 51 501 minecraft:terracotta
fill 480 51 502 480 54 502 minecraft:red_terracotta
fill 481 51 500 481 88 500 minecraft:terracotta
fill 481 51 501 481 52 501 minecraft:red_terracotta
setblock 482 51 504 minecraft:terracotta
setblock 483 51 503 minecraft:terracotta
fill 483 51 504 483 54 504 minecraft:red_terracotta
fill 484 51 503 484 52 503 minecraft:red_terracotta
fill 493 51 504 496 51 504 minecraft:red_terracotta
fill 495 51 464 495 52 464 minecraft:red_terracotta
fill 495 51 503 497 51 503 minecraft:red_terracotta
setblock 497 51 464 minecraft:terracotta
setblock 497 51 504 minecraft:terracotta
fill 498 51 464 498 54 464 minecraft:red_terracotta
setblock 498 51 503 minecraft:terracotta
fill 498 51 504 498 54 504 minecraft:red_terracotta
fill 499 51 503 499 54 503 minecraft:red_terracotta
setblock 501 51 465 minecraft:terracotta
setblock 501 51 504 minecraft:red_terracotta
setblock 502 51 464 minecraft:terracotta
fill 502 51 465 502 53 465 minecraft:red_terracotta
setblock 502 51 504 minecraft:terracotta
fill 503 51 464 503 54 464 minecraft:red_terracotta
setblock 503 51 503 minecraft:terracotta
fill 503 51 504 503 54 504 minecraft:red_terracotta
setblock 506 51 504 minecraft:red_terracotta
setblock 507 51 464 minecraft:terracotta
setblock 507 51 504 minecraft:terracotta
fill 508 51 464 508 54 464 minecraft:red_terracotta
fill 508 51 504 508 54 504 minecraft:red_terracotta
setblock 510 51 476 minecraft:terracotta
fill 510 51 477 510 52 477 minecraft:red_terracotta
setblock 510 51 500 minecraft:red_terracotta
setblock 510 51 501 minecraft:terracotta
setblock 511 51 465 minecraft:terracotta
fill 511 51 466 511 54 466 minecraft:red_terracotta
setblock 511 51 470 minecraft:terracotta
fill 511 51 471 511 53 471 minecraft:red_terracotta
setblock 511 51 475 minecraft:terracotta
fill 511 51 476 511 54 476 minecraft:red_terracotta
setblock 511 51 480 minecraft:terracotta
fill 511 51 481 511 54 481 minecraft:red_terracotta
setblock 511 51 495 minecraft:terracotta
fill 511 51 496 511 54 496 minecraft:red_terracotta
setblock 511 51 499 minecraft:red_terracotta
setblock 511 51 500 minecraft:terracotta
fill 511 51 501 511 54 501 minecraft:red_terracotta
setblock 471 52 464 minecraft:terracotta
setblock 471 52 474 minecraft:terracotta
fill 471 52 475 471 53 475 minecraft:red_terracotta
setblock 471 52 479 minecraft:terracotta
fill 471 52 480 471 54 481 minecraft:red_terracotta
setblock 471 52 494 minecraft:terracotta
fill 471 52 495 471 52 498 minecraft:red_terracotta
setblock 471 52 499 minecraft:terracotta
fill 471 52 500 471 55 500 minecraft:red_terracotta
setblock 471 52 504 minecraft:terracotta
fill 472 52 464 472 55 464 minecraft:red_terracotta
fill 472 52 494 472 53 494 minecraft:red_terracotta
setblock 472 52 498 minecraft:terracotta
fill 472 52 499 472 55 499 minecraft:red_terracotta
setblock 472 52 502 minecraft:red_terracotta
setblock 472 52 503 minecraft:terracotta
fill 472 52 504 472 55 504 minecraft:red_terracotta
setblock 473 52 497 minecraft:terracotta
fill 473 52 498 473 55 498 minecraft:red_terracotta
setblock 473 52 502 minecraft:terracotta
fill 473 52 503 473 55 503 minecraft:red_terracotta
fill 474 52 497 474 53 497 minecraft:red_terracotta
setblock 474 52 501 minecraft:terracotta
fill 474 52 502 474 55 502 minecraft:red_terracotta
setblock 475 52 500 minecraft:terracotta
fill 475 52 501 475 55 501 minecraft:red_terracotta
setblock 476 52 464 minecraft:terracotta
fill 476 52 500 476 53 500 minecraft:red_terracotta
setblock 476 52 504 minecraft:terracotta
fill 477 52 464 477 55 464 minecraft:red_terracotta
setblock 477 52 503 minecraft:terracotta
fill 477 52 504 477 55 504 minecraft:red_terracotta
setblock 478 52 502 minecraft:terracotta
fill 478 52 503 478 55 503 minecraft:red_terracotta
setblock 479 52 501 minecraft:terracotta
fill 479 52 502 479 55 502 minecraft:red_terracotta
fill 480 52 500 480 88 500 minecraft:terracotta
fill 480 52 501 480 53 501 minecraft:red_terracotta
setblock 481 52 464 minecraft:terracotta
setblock 481 52 504 minecraft:terracotta
setblock 482 52 503 minecraft:terracotta
fill 482 52 504 482 55 504 minecraft:red_terracotta
setblock 483 52 502 minecraft:terracotta
fill 483 52 503 483 54 503 minecraft:red_terracotta
fill 492 52 504 495 52 504 minecraft:red_terracotta
fill 494 52 464 494 53 464 minecraft:red_terracotta
fill 494 52 503 496 52 503 minecraft:red_terracotta
setblock 496 52 464 minecraft:terracotta
setblock 496 52 504 minecraft:terracotta
fill 497 52 464 497 54 465 minecraft:red_terracotta
setblock 497 52 503 minecraft:terracotta
fill 497 52 504 497 55 504 minecraft:red_terracotta
fill 498 52 503 498 55 503 minecraft:red_terracotta
setblock 500 52 464 minecraft:red_terracotta
setblock 500 52 465 minecraft:terracotta
setblock 501 52 464 minecraft:terracotta
fill 501 52 465 501 54 465 minecraft:red_terracotta
setblock 501 52 504 minecraft:terracotta
fill 502 52 464 502 55 464 minecraft:red_terracotta
setblock 502 52 503 minecraft:terracotta
fill 502 52 504 502 55 504 minecraft:red_terracotta
setblock 503 52 503 minecraft:red_terracotta
setblock 506 52 464 minecraft:terracotta
setblock 506 52 504 minecraft:terracotta
fill 507 52 464 507 55 464 minecraft:red_terracotta
fill 507 52 504 507 55 504 minecraft:red_terracotta
fill 509 52 464 510 52 464 minecraft:red_terracotta
setblock 510 52 475 minecraft:terracotta
setblock 510 52 476 minecraft:red_terracotta
setblock 510 52 500 minecraft:terracotta
fill 510 52 501 510 53 503 minecraft:red_terracotta
setblock 511 52 464 minecraft:terracotta
fill 511 52 465 511 55 465 minecraft:red_terracotta
setblock 511 52 469 minecraft:terracotta
fill 511 52 470 511 53 470 minecraft:red_terracotta
setblock 511 52 474 minecraft:terracotta
fill 511 52 475 511 55 475 minecraft:red_terracotta
setblock 511 52 479 minecraft:terracotta
fill 511 52 480 511 55 480 minecraft:red_terracotta
fill 511 52 482 511 53 482 minecraft:red_terracotta
setblock 511 52 499 minecraft:terracotta
fill 511 52 500 511 55 500 minecraft:red_terracotta
setblock 511 52 503 minecraft:red_terracotta
setblock 511 52 504 minecraft:terracotta
fill 471 53 464 471 55 465 minecraft:red_terracotta
setblock 471 53 478 minecraft:terracotta
fill 471 53 479 471 56 479 minecraft:red_terracotta
setblock 471 53 482 minecraft:red_terracotta
setblock 471 53 493 minecraft:terracotta
fill 471 53 494 471 53 497 minecraft:red_terracotta
setblock 471 53 498 minecraft:terracotta
fill 471 53 499 471 56 499 minecraft:red_terracotta
fill 471 53 501 471 53 502 minecraft:red_terracotta
setblock 471 53 503 minecraft:terracotta
fill 471 53 504 471 56 504 minecraft:red_terracotta
setblock 472 53 497 minecraft:terracotta
fill 472 53 498 472 56 498 minecraft:red_terracotta
setblock 472 53 502 minecraft:terracotta
fill 472 53 503 472 56 503 minecraft:red_terracotta
setblock 473 53 466 minecraft:light[level=14]
setblock 473 53 474 minecraft:light[level=14]
setblock 473 53 482 minecraft:light[level=14]
setblock 473 53 490 minecraft:light[level=14]
setblock 473 53 496 minecraft:terracotta
fill 473 53 497 473 56 497 minecraft:red_terracotta
setblock 473 53 500 minecraft:red_terracotta
setblock 473 53 501 minecraft:terracotta
fill 473 53 502 473 56 502 minecraft:red_terracotta
setblock 474 53 500 minecraft:terracotta
fill 474 53 501 474 56 501 minecraft:red_terracotta
setblock 475 53 464 minecraft:terracotta
setblock 475 53 504 minecraft:terracotta
fill 476 53 464 476 56 464 minecraft:red_terracotta
setblock 476 53 503 minecraft:terracotta
fill 476 53 504 476 56 504 minecraft:red_terracotta
setblock 477 53 502 minecraft:terracotta
fill 477 53 503 477 56 503 minecraft:red_terracotta
fill 478 53 500 478 53 501 minecraft:terracotta
fill 478 53 502 478 56 502 minecraft:red_terracotta
fill 479 53 500 479 88 500 minecraft:terracotta
fill 479 53 501 479 54 501 minecraft:red_terracotta
setblock 480 53 464 minecraft:terracotta
setblock 480 53 504 minecraft:terracotta
fill 481 53 464 481 63 464 minecraft:shroomlight
setblock 481 53 466 minecraft:light[level=14]
setblock 481 53 474 minecraft:light[level=14]
setblock 481 53 482 minecraft:light[level=14]
setblock 481 53 490 minecraft:light[level=14]
setblock 481 53 503 minecraft:terracotta
fill 481 53 504 481 56 504 minecraft:red_terracotta
setblock 482 53 502 minecraft:terracotta
fill 482 53 503 482 55 503 minecraft:red_terracotta
setblock 485 53 504 minecraft:terracotta
setblock 489 53 466 minecraft:light[level=14]
setblock 489 53 490 minecraft:light[level=14]
setblock 489 53 498 minecraft:light[level=14]
fill 491 53 504 494 53 504 minecraft:red_terracotta
fill 493 53 464 493 54 464 minecraft:red_terracotta
fill 494 53 503 495 53 503 minecraft:red_terracotta
setblock 495 53 464 minecraft:terracotta
setblock 495 53 504 minecraft:terracotta
fill 496 53 464 496 55 465 minecraft:red_terracotta
setblock 496 53 503 minecraft:terracotta
fill 496 53 504 496 56 504 minecraft:red_terracotta
setblock 497 53 466 minecraft:light[level=14]
setblock 497 53 474 minecraft:light[level=14]
setblock 497 53 482 minecraft:light[level=14]
setblock 497 53 490 minecraft:light[level=14]
fill 497 53 503 497 56 503 minecraft:red_terracotta
setblock 498 53 465 minecraft:red_terracotta
setblock 499 53 465 minecraft:terracotta
setblock 500 53 464 minecraft:terracotta
fill 500 53 465 500 56 465 minecraft:red_terracotta
setblock 500 53 504 minecraft:terracotta
fill 501 53 464 501 56 464 minecraft:red_terracotta
setblock 501 53 503 minecraft:terracotta
fill 501 53 504 501 56 504 minecraft:red_terracotta
setblock 502 53 503 minecraft:red_terracotta
setblock 505 53 464 minecraft:terracotta
setblock 505 53 466 minecraft:light[level=14]
setblock 505 53 474 minecraft:light[level=14]
setblock 505 53 482 minecraft:light[level=14]
setblock 505 53 490 minecraft:light[level=14]
setblock 505 53 498 minecraft:light[level=14]
setblock 505 53 504 minecraft:terracotta
fill 506 53 464 506 56 464 minecraft:red_terracotta
fill 506 53 504 506 56 504 minecraft:red_terracotta
setblock 509 53 464 minecraft:red_terracotta
fill 509 53 503 509 53 504 minecraft:red_terracotta
setblock 510 53 464 minecraft:terracotta
fill 510 53 500 510 56 500 minecraft:red_terracotta
setblock 510 53 504 minecraft:terracotta
fill 511 53 464 511 56 464 minecraft:red_terracotta
setblock 511 53 468 minecraft:terracotta
setblock 511 53 469 minecraft:red_terracotta
setblock 511 53 473 minecraft:terracotta
fill 511 53 474 511 54 474 minecraft:red_terracotta
setblock 511 53 478 minecraft:terracotta
fill 511 53 479 511 56 479 minecraft:red_terracotta
setblock 511 53 498 minecraft:terracotta
fill 511 53 499 511 56 499 minecraft:red_terracotta
setblock 511 53 503 minecraft:terracotta
fill 511 53 504 511 56 504 minecraft:red_terracotta
setblock 471 54 477 minecraft:terracotta
fill 471 54 478 471 56 478 minecraft:red_terracotta
setblock 471 54 482 minecraft:terracotta
fill 471 54 483 471 56 484 minecraft:red_terracotta
fill 471 54 493 471 54 496 minecraft:red_terracotta
setblock 471 54 497 minecraft:terracotta
fill 471 54 498 471 57 498 minecraft:red_terracotta
setblock 471 54 501 minecraft:red_terracotta
setblock 471 54 502 minecraft:terracotta
fill 471 54 503 471 57 503 minecraft:red_terracotta
setblock 472 54 496 minecraft:terracotta
fill 472 54 497 472 57 497 minecraft:red_terracotta
setblock 472 54 501 minecraft:terracotta
fill 472 54 502 472 57 502 minecraft:red_terracotta
setblock 473 54 496 minecraft:red_terracotta
setblock 473 54 500 minecraft:terracotta
fill 473 54 501 473 57 501 minecraft:red_terracotta
setblock 474 54 464 minecraft:terracotta
setblock 474 54 499 minecraft:terracotta
fill 474 54 500 474 56 500 minecraft:red_terracotta
setblock 474 54 504 minecraft:terracotta
fill 475 54 464 475 57 464 minecraft:red_terracotta
setblock 475 54 503 minecraft:terracotta
fill 475 54 504 475 57 504 minecraft:red_terracotta
setblock 476 54 502 minecraft:terracotta
fill 476 54 503 476 57 503 minecraft:red_terracotta
setblock 477 54 501 minecraft:terracotta
fill 477 54 502 477 57 502 minecraft:red_terracotta
fill 478 54 500 478 88 500 minecraft:terracotta
fill 478 54 501 478 55 501 minecraft:red_terracotta
setblock 479 54 464 minecraft:terracotta
setblock 479 54 504 minecraft:terracotta
setblock 480 54 464 minecraft:red_terracotta
setblock 480 54 503 minecraft:terracotta
fill 480 54 504 480 57 504 minecraft:red_terracotta
setblock 481 54 502 minecraft:terracotta
fill 481 54 503 481 56 503 minecraft:red_terracotta
setblock 484 54 504 minecraft:terracotta
fill 491 54 504 493 54 504 minecraft:red_terracotta
setblock 494 54 464 minecraft:terracotta
setblock 494 54 503 minecraft:red_terracotta
setblock 494 54 504 minecraft:terracotta
fill 495 54 464 495 57 464 minecraft:red_terracotta
setblock 495 54 503 minecraft:terracotta
fill 495 54 504 495 57 504 minecraft:red_terracotta
fill 496 54 503 496 57 503 minecraft:red_terracotta
setblock 498 54 465 minecraft:terracotta
setblock 499 54 464 minecraft:terracotta
fill 499 54 465 499 57 465 minecraft:red_terracotta
setblock 499 54 504 minecraft:terracotta
fill 500 54 464 500 57 464 minecraft:red_terracotta
setblock 500 54 503 minecraft:terracotta
fill 500 54 504 500 57 504 minecraft:red_terracotta
setblock 501 54 503 minecraft:red_terracotta
setblock 504 54 464 minecraft:terracotta
setblock 504 54 504 minecraft:terracotta
fill 505 54 464 505 57 464 minecraft:red_terracotta
fill 505 54 504 505 57 504 minecraft:red_terracotta
setblock 509 54 464 minecraft:terracotta
setblock 509 54 503 minecraft:red_terracotta
setblock 509 54 504 minecraft:terracotta
fill 510 54 464 510 57 464 minecraft:red_terracotta
fill 510 54 501 510 54 502 minecraft:red_terracotta
setblock 510 54 503 minecraft:terracotta
fill 510 54 504 510 57 504 minecraft:red_terracotta
setblock 511 54 467 minecraft:terracotta
setblock 511 54 468 minecraft:red_terracotta
setblock 511 54 473 minecraft:red_terracotta
setblock 511 54 477 minecraft:terracotta
fill 511 54 478 511 57 478 minecraft:red_terracotta
setblock 511 54 482 minecraft:terracotta
setblock 511 54 497 minecraft:terracotta
fill 511 54 498 511 57 498 minecraft:red_terracotta
setblock 511 54 502 minecraft:terracotta
fill 511 54 503 511 57 503 minecraft:red_terracotta
setblock 471 55 477 minecraft:red_terracotta
setblock 471 55 480 minecraft:red_terracotta
setblock 471 55 481 minecraft:terracotta
fill 471 55 482 471 58 482 minecraft:red_terracotta
setblock 471 55 485 minecraft:red_terracotta
fill 471 55 493 471 55 495 minecraft:red_terracotta
setblock 471 55 496 minecraft:terracotta
fill 471 55 497 471 58 497 minecraft:red_terracotta
setblock 471 55 501 minecraft:terracotta
fill 471 55 502 471 58 502 minecraft:red_terracotta
setblock 472 55 495 minecraft:terracotta
fill 472 55 496 472 58 496 minecraft:red_terracotta
setblock 472 55 500 minecraft:terracotta
fill 472 55 501 472 58 501 minecraft:red_terracotta
setblock 473 55 464 minecraft:terracotta
setblock 473 55 499 minecraft:terracotta
fill 473 55 500 473 58 500 minecraft:red_terracotta
setblock 473 55 504 minecraft:terracotta
fill 474 55 464 474 58 464 minecraft:red_terracotta
setblock 474 55 499 minecraft:red_terracotta
setblock 474 55 503 minecraft:terracotta
fill 474 55 504 474 58 504 minecraft:red_terracotta
setblock 475 55 502 minecraft:terracotta
fill 475 55 503 475 58 503 minecraft:red_terracotta
setblock 476 55 501 minecraft:terracotta
fill 476 55 502 476 58 502 minecraft:red_terracotta
setblock 477 55 501 minecraft:red_terracotta
setblock 478 55 464 minecraft:terracotta
setblock 478 55 504 minecraft:terracotta
fill 479 55 464 479 56 464 minecraft:red_terracotta
setblock 479 55 503 minecraft:terracotta
fill 479 55 504 479 58 504 minecraft:red_terracotta
fill 480 55 464 480 63 464 minecraft:magma_block
setblock 480 55 502 minecraft:terracotta
fill 480 55 503 480 57 503 minecraft:red_terracotta
setblock 483 55 504 minecraft:terracotta
fill 491 55 504 492 55 504 minecraft:red_terracotta
setblock 492 55 464 minecraft:red_terracotta
setblock 493 55 464 minecraft:terracotta
setblock 493 55 504 minecraft:terracotta
fill 494 55 464 494 58 464 minecraft:red_terracotta
setblock 494 55 503 minecraft:terracotta
fill 494 55 504 494 58 504 minecraft:red_terracotta
fill 495 55 465 495 56 465 minecraft:red_terracotta
fill 495 55 503 495 58 503 minecraft:red_terracotta
setblock 497 55 464 minecraft:red_terracotta
setblock 497 55 465 minecraft:terracotta
setblock 498 55 464 minecraft:terracotta
fill 498 55 465 498 58 465 minecraft:red_terracotta
setblock 498 55 504 minecraft:terracotta
fill 499 55 464 499 58 464 minecraft:red_terracotta
setblock 499 55 503 minecraft:terracotta
fill 499 55 504 499 58 504 minecraft:red_terracotta
setblock 500 55 503 minecraft:red_terracotta
setblock 503 55 464 minecraft:terracotta
setblock 503 55 504 minecraft:terracotta
fill 504 55 464 504 58 464 minecraft:red_terracotta
fill 504 55 504 504 58 504 minecraft:red_terracotta
setblock 508 55 464 minecraft:terracotta
setblock 508 55 504 minecraft:terracotta
fill 509 55 464 509 58 464 minecraft:red_terracotta
setblock 509 55 503 minecraft:terracotta
fill 509 55 504 509 58 504 minecraft:red_terracotta
setblock 510 55 501 minecraft:red_terracotta
setblock 510 55 502 minecraft:terracotta
fill 510 55 503 510 58 503 minecraft:red_terracotta
setblock 511 55 466 minecraft:terracotta
fill 511 55 467 511 58 467 minecraft:red_terracotta
setblock 511 55 476 minecraft:terracotta
fill 511 55 477 511 56 477 minecraft:red_terracotta
setblock 511 55 481 minecraft:terracotta
fill 511 55 482 511 58 482 minecraft:red_terracotta
fill 511 55 497 511 58 497 minecraft:red_terracotta
setblock 511 55 501 minecraft:terracotta
fill 511 55 502 511 58 502 minecraft:red_terracotta
setblock 471 56 464 minecraft:red_terracotta
setblock 471 56 465 minecraft:terracotta
setblock 471 56 480 minecraft:terracotta
fill 471 56 481 472 58 481 minecraft:red_terracotta
setblock 471 56 485 minecraft:terracotta
fill 471 56 486 471 58 487 minecraft:red_terracotta
fill 471 56 493 471 56 494 minecraft:red_terracotta
setblock 471 56 495 minecraft:terracotta
fill 471 56 496 471 59 496 minecraft:red_terracotta
setblock 471 56 500 minecraft:terracotta
fill 471 56 501 471 59 501 minecraft:red_terracotta
setblock 472 56 464 minecraft:terracotta
fill 472 56 482 472 56 483 minecraft:red_terracotta
setblock 472 56 495 minecraft:red_terracotta
setblock 472 56 499 minecraft:terracotta
fill 472 56 500 472 59 500 minecraft:red_terracotta
setblock 472 56 504 minecraft:terracotta
fill 473 56 464 473 59 464 minecraft:red_terracotta
setblock 473 56 498 minecraft:terracotta
fill 473 56 499 473 59 499 minecraft:red_terracotta
setblock 473 56 503 minecraft:terracotta
fill 473 56 504 473 59 504 minecraft:red_terracotta
setblock 474 56 502 minecraft:terracotta
fill 474 56 503 474 59 503 minecraft:red_terracotta
setblock 475 56 501 minecraft:terracotta
fill 475 56 502 475 59 502 minecraft:red_terracotta
setblock 476 56 501 minecraft:red_terracotta
setblock 477 56 464 minecraft:terracotta
setblock 477 56 504 minecraft:terracotta
fill 478 56 464 478 59 464 minecraft:red_terracotta
setblock 478 56 503 minecraft:terracotta
fill 478 56 504 478 59 504 minecraft:red_terracotta
setblock 479 56 502 minecraft:terracotta
fill 479 56 503 479 58 503 minecraft:red_terracotta
setblock 482 56 504 minecraft:terracotta
setblock 483 56 504 minecraft:red_terracotta
fill 487 56 478 487 88 479 minecraft:terracotta
setblock 491 56 504 minecraft:red_terracotta
setblock 492 56 464 minecraft:terracotta
setblock 492 56 504 minecraft:terracotta
fill 493 56 464 493 59 464 minecraft:red_terracotta
fill 493 56 504 493 59 504 minecraft:red_terracotta
fill 494 56 465 494 57 465 minecraft:red_terracotta
fill 494 56 503 494 59 503 minecraft:red_terracotta
setblock 496 56 464 minecraft:red_terracotta
setblock 496 56 465 minecraft:terracotta
setblock 497 56 464 minecraft:terracotta
fill 497 56 465 497 59 465 minecraft:red_terracotta
setblock 497 56 504 minecraft:terracotta
fill 498 56 464 498 59 464 minecraft:red_terracotta
setblock 498 56 503 minecraft:terracotta
fill 498 56 504 498 59 504 minecraft:red_terracotta
setblock 499 56 503 minecraft:red_terracotta
setblock 502 56 464 minecraft:terracotta
setblock 502 56 504 minecraft:terracotta
fill 503 56 464 503 59 464 minecraft:red_terracotta
fill 503 56 504 503 59 504 minecraft:red_terracotta
setblock 507 56 464 minecraft:terracotta
setblock 507 56 504 minecraft:terracotta
fill 508 56 464 508 59 464 minecraft:red_terracotta
fill 508 56 504 508 59 504 minecraft:red_terracotta
fill 509 56 503 509 59 503 minecraft:red_terracotta
setblock 510 56 501 minecraft:terracotta
fill 510 56 502 510 59 502 minecraft:red_terracotta
setblock 511 56 465 minecraft:terracotta
fill 511 56 466 511 59 466 minecraft:red_terracotta
setblock 511 56 480 minecraft:terracotta
fill 511 56 481 511 59 481 minecraft:red_terracotta
fill 511 56 483 511 57 483 minecraft:red_terracotta
setblock 511 56 500 minecraft:terracotta
fill 511 56 501 511 59 501 minecraft:red_terracotta
setblock 471 57 464 minecraft:terracotta
fill 471 57 465 471 60 465 minecraft:red_terracotta
setblock 471 57 479 minecraft:terracotta
fill 471 57 480 471 60 480 minecraft:red_terracotta
setblock 471 57 483 minecraft:red_terracotta
setblock 471 57 484 minecraft:terracotta
fill 471 57 485 472 59 485 minecraft:red_terracotta
setblock 471 57 488 minecraft:red_terracotta
setblock 471 57 489 minecraft:terracotta
setblock 471 57 493 minecraft:red_terracotta
setblock 471 57 494 minecraft:terracotta
fill 471 57 495 471 60 495 minecraft:red_terracotta
setblock 471 57 499 minecraft:terracotta
fill 471 57 500 471 60 500 minecraft:red_terracotta
setblock 471 57 504 minecraft:terracotta
fill 472 57 464 472 60 464 minecraft:red_terracotta
setblock 472 57 482 minecraft:red_terracotta
setblock 472 57 483 minecraft:terracotta
fill 472 57 484 472 60 484 minecraft:red_terracotta
fill 472 57 486 472 58 486 minecraft:red_terracotta
setblock 472 57 498 minecraft:terracotta
fill 472 57 499 472 60 499 minecraft:red_terracotta
setblock 472 57 503 minecraft:terracotta
fill 472 57 504 472 60 504 minecraft:red_terracotta
setblock 473 57 498 minecraft:red_terracotta
setblock 473 57 502 minecraft:terracotta
fill 473 57 503 473 60 503 minecraft:red_terracotta
fill 474 57 502 474 60 502 minecraft:red_terracotta
setblock 476 57 464 minecraft:terracotta
setblock 476 57 504 minecraft:terracotta
fill 477 57 464 477 60 464 minecraft:red_terracotta
setblock 477 57 503 minecraft:terracotta
fill 477 57 504 477 60 504 minecraft:red_terracotta
setblock 478 57 502 minecraft:terracotta
fill 478 57 503 478 60 503 minecraft:red_terracotta
setblock 481 57 504 minecraft:terracotta
setblock 482 57 504 minecraft:red_terracotta
setblock 490 57 504 minecraft:red_terracotta
setblock 491 57 464 minecraft:terracotta
setblock 491 57 504 minecraft:terracotta
fill 492 57 464 492 60 464 minecraft:red_terracotta
fill 492 57 504 492 60 504 minecraft:red_terracotta
setblock 495 57 465 minecraft:terracotta
setblock 496 57 464 minecraft:terracotta
fill 496 57 465 496 60 465 minecraft:red_terracotta
setblock 496 57 504 minecraft:terracotta
fill 497 57 464 497 60 464 minecraft:red_terracotta
setblock 497 57 503 minecraft:terracotta
fill 497 57 504 497 60 504 minecraft:red_terracotta
setblock 498 57 503 minecraft:red_terracotta
setblock 500 57 465 minecraft:terracotta
setblock 501 57 464 minecraft:terracotta
setblock 501 57 504 minecraft:terracotta
fill 502 57 464 502 60 464 minecraft:red_terracotta
fill 502 57 504 502 60 504 minecraft:red_terracotta
setblock 506 57 464 minecraft:terracotta
setblock 506 57 504 minecraft:terracotta
fill 507 57 464 507 60 464 minecraft:red_terracotta
fill 507 57 504 507 60 504 minecraft:red_terracotta
setblock 510 57 465 minecraft:terracotta
fill 510 57 501 510 60 501 minecraft:red_terracotta
setblock 511 57 464 minecraft:terracotta
fill 511 57 465 511 60 465 minecraft:red_terracotta
setblock 511 57 468 minecraft:red_terracotta
setblock 511 57 479 minecraft:terracotta
fill 511 57 480 511 60 480 minecraft:red_terracotta
setblock 511 57 484 minecraft:terracotta
setblock 511 57 499 minecraft:terracotta
fill 511 57 500 511 60 500 minecraft:red_terracotta
setblock 511 57 504 minecraft:terracotta
fill 471 58 464 471 61 464 minecraft:red_terracotta
fill 471 58 466 471 59 466 minecraft:red_terracotta
fill 471 58 479 471 61 479 minecraft:red_terracotta
setblock 471 58 483 minecraft:terracotta
fill 471 58 484 471 61 484 minecraft:red_terracotta
setblock 471 58 488 minecraft:terracotta
fill 471 58 489 471 58 492 minecraft:red_terracotta
setblock 471 58 493 minecraft:terracotta
fill 471 58 494 471 61 494 minecraft:red_terracotta
setblock 471 58 498 minecraft:terracotta
fill 471 58 499 471 61 499 minecraft:red_terracotta
setblock 471 58 503 minecraft:terracotta
fill 471 58 504 471 61 504 minecraft:red_terracotta
setblock 472 58 482 minecraft:terracotta
fill 472 58 483 472 61 483 minecraft:red_terracotta
setblock 472 58 487 minecraft:terracotta
fill 472 58 488 472 61 488 minecraft:red_terracotta
setblock 472 58 497 minecraft:terracotta
fill 472 58 498 472 61 498 minecraft:red_terracotta
setblock 472 58 502 minecraft:terracotta
fill 472 58 503 472 61 503 minecraft:red_terracotta
setblock 473 58 501 minecraft:terracotta
fill 473 58 502 473 61 502 minecraft:red_terracotta
setblock 475 58 464 minecraft:terracotta
setblock 475 58 504 minecraft:terracotta
fill 476 58 464 476 61 464 minecraft:red_terracotta
setblock 476 58 503 minecraft:terracotta
fill 476 58 504 476 61 504 minecraft:red_terracotta
setblock 477 58 502 minecraft:terracotta
fill 477 58 503 477 61 503 minecraft:red_terracotta
setblock 480 58 504 minecraft:terracotta
fill 481 58 504 481 59 504 minecraft:red_terracotta
setblock 490 58 464 minecraft:terracotta
setblock 490 58 504 minecraft:terracotta
fill 491 58 464 491 61 464 minecraft:red_terracotta
fill 491 58 504 491 61 504 minecraft:red_terracotta
fill 492 58 465 493 58 465 minecraft:red_terracotta
setblock 494 58 465 minecraft:terracotta
setblock 495 58 464 minecraft:terracotta
fill 495 58 465 495 61 465 minecraft:red_terracotta
setblock 495 58 504 minecraft:terracotta
fill 496 58 464 496 61 464 minecraft:red_terracotta
setblock 496 58 503 minecraft:terracotta
fill 496 58 504 496 61 504 minecraft:red_terracotta
setblock 497 58 503 minecraft:red_terracotta
setblock 499 58 465 minecraft:terracotta
setblock 500 58 464 minecraft:terracotta
fill 500 58 465 500 61 465 minecraft:red_terracotta
setblock 500 58 504 minecraft:terracotta
fill 501 58 464 501 61 464 minecraft:red_terracotta
fill 501 58 504 501 61 504 minecraft:red_terracotta
setblock 505 58 464 minecraft:terracotta
setblock 505 58 504 minecraft:terracotta
fill 506 58 464 506 61 464 minecraft:red_terracotta
fill 506 58 504 506 61 504 minecraft:red_terracotta
fill 508 58 503 508 60 503 minecraft:red_terracotta
setblock 509 58 465 minecraft:terracotta
setblock 510 58 464 minecraft:terracotta
fill 510 58 465 510 61 465 minecraft:red_terracotta
fill 510 58 500 510 61 500 minecraft:red_terracotta
setblock 510 58 504 minecraft:terracotta
fill 511 58 464 511 61 464 minecraft:red_terracotta
setblock 511 58 468 minecraft:terracotta
fill 511 58 479 511 61 479 minecraft:red_terracotta
setblock 511 58 483 minecraft:terracotta
fill 511 58 484 511 60 485 minecraft:red_terracotta
setblock 511 58 498 minecraft:terracotta
fill 511 58 499 511 61 499 minecraft:red_terracotta
setblock 511 58 503 minecraft:terracotta
fill 511 58 504 511 61 504 minecraft:red_terracotta
setblock 471 59 467 minecraft:terracotta
setblock 471 59 481 minecraft:red_terracotta
setblock 471 59 482 minecraft:terracotta
fill 471 59 483 471 62 483 minecraft:red_terracotta
setblock 471 59 486 minecraft:red_terracotta
setblock 471 59 487 minecraft:terracotta
fill 471 59 488 471 59 491 minecraft:red_terracotta
setblock 471 59 492 minecraft:terracotta
fill 471 59 493 471 62 493 minecraft:red_terracotta
setblock 471 59 497 minecraft:terracotta
fill 471 59 498 471 62 498 minecraft:red_terracotta
setblock 471 59 502 minecraft:terracotta
fill 471 59 503 471 62 503 minecraft:red_terracotta
setblock 472 59 465 minecraft:red_terracotta
setblock 472 59 481 minecraft:terracotta
fill 472 59 482 472 62 482 minecraft:red_terracotta
setblock 472 59 486 minecraft:terracotta
fill 472 59 487 473 61 487 minecraft:red_terracotta
fill 472 59 489 472 59 490 minecraft:red_terracotta
setblock 472 59 491 minecraft:terracotta
setblock 472 59 495 minecraft:red_terracotta
setblock 472 59 496 minecraft:terracotta
fill 472 59 497 472 62 497 minecraft:red_terracotta
setblock 472 59 501 minecraft:terracotta
fill 472 59 502 472 62 502 minecraft:red_terracotta
setblock 473 59 465 minecraft:terracotta
fill 473 59 483 473 59 484 minecraft:red_terracotta
setblock 473 59 485 minecraft:terracotta
fill 473 59 486 473 62 486 minecraft:red_terracotta
setblock 473 59 500 minecraft:terracotta
fill 473 59 501 473 62 501 minecraft:red_terracotta
setblock 474 59 464 minecraft:terracotta
fill 474 59 465 474 62 465 minecraft:red_terracotta
setblock 474 59 504 minecraft:terracotta
fill 475 59 464 475 62 464 minecraft:red_terracotta
setblock 475 59 503 minecraft:terracotta
fill 475 59 504 475 62 504 minecraft:red_terracotta
setblock 476 59 502 minecraft:terracotta
fill 476 59 503 476 62 503 minecraft:red_terracotta
setblock 479 59 504 minecraft:terracotta
fill 480 59 504 480 61 504 minecraft:red_terracotta
setblock 489 59 464 minecraft:terracotta
setblock 489 59 504 minecraft:terracotta
fill 490 59 464 490 62 464 minecraft:red_terracotta
fill 490 59 504 490 62 504 minecraft:red_terracotta
fill 491 59 465 492 59 465 minecraft:red_terracotta
setblock 493 59 465 minecraft:terracotta
fill 493 59 503 493 60 503 minecraft:red_terracotta
setblock 494 59 464 minecraft:terracotta
fill 494 59 465 494 62 465 minecraft:red_terracotta
setblock 494 59 504 minecraft:terracotta
fill 495 59 464 495 62 464 minecraft:red_terracotta
setblock 495 59 503 minecraft:terracotta
fill 495 59 504 495 62 504 minecraft:red_terracotta
fill 496 59 503 496 61 503 minecraft:red_terracotta
setblock 498 59 465 minecraft:terracotta
setblock 499 59 464 minecraft:terracotta
fill 499 59 465 499 62 465 minecraft:red_terracotta
setblock 499 59 504 minecraft:terracotta
fill 500 59 464 500 62 464 minecraft:red_terracotta
fill 500 59 504 500 62 504 minecraft:red_terracotta
fill 501 59 465 501 60 465 minecraft:red_terracotta
setblock 504 59 464 minecraft:terracotta
setblock 504 59 504 minecraft:terracotta
fill 505 59 464 505 62 464 minecraft:red_terracotta
fill 505 59 504 505 62 504 minecraft:red_terracotta
setblock 507 59 465 minecraft:red_terracotta
setblock 508 59 465 minecraft:terracotta
setblock 509 59 464 minecraft:terracotta
fill 509 59 465 509 62 465 minecraft:red_terracotta
setblock 509 59 504 minecraft:terracotta
fill 510 59 464 510 62 464 minecraft:red_terracotta
fill 510 59 466 510 60 466 minecraft:red_terracotta
setblock 510 59 503 minecraft:terracotta
fill 510 59 504 510 62 504 minecraft:red_terracotta
setblock 511 59 467 minecraft:terracotta
fill 511 59 468 511 61 469 minecraft:red_terracotta
setblock 511 59 482 minecraft:terracotta
fill 511 59 483 511 62 483 minecraft:red_terracotta
setblock 511 59 486 minecraft:red_terracotta
setblock 511 59 487 minecraft:terracotta
setblock 511 59 497 minecraft:terracotta
fill 511 59 498 511 62 498 minecraft:red_terracotta
setblock 511 59 502 minecraft:terracotta
fill 511 59 503 511 62 503 minecraft:red_terracotta
setblock 471 60 466 minecraft:terracotta
fill 471 60 467 471 62 468 minecraft:red_terracotta
fill 471 60 478 471 62 478 minecraft:red_terracotta
setblock 471 60 481 minecraft:terracotta
fill 471 60 482 471 63 482 minecraft:red_terracotta
setblock 471 60 485 minecraft:red_terracotta
setblock 471 60 486 minecraft:terracotta
fill 471 60 487 471 60 490 minecraft:red_terracotta
setblock 471 60 491 minecraft:terracotta
fill 471 60 492 472 62 492 minecraft:red_terracotta
setblock 471 60 496 minecraft:terracotta
fill 471 60 497 471 63 497 minecraft:red_terracotta
setblock 471 60 501 minecraft:terracotta
fill 471 60 502 471 63 502 minecraft:red_terracotta
setblock 472 60 465 minecraft:terracotta
fill 472 60 466 472 63 466 minecraft:red_terracotta
setblock 472 60 480 minecraft:terracotta
fill 472 60 481 472 63 481 minecraft:red_terracotta
setblock 472 60 485 minecraft:terracotta
fill 472 60 486 472 63 486 minecraft:red_terracotta
setblock 472 60 489 minecraft:red_terracotta
setblock 472 60 490 minecraft:terracotta
fill 472 60 491 472 63 491 minecraft:red_terracotta
fill 472 60 493 472 60 494 minecraft:red_terracotta
setblock 472 60 495 minecraft:terracotta
fill 472 60 496 472 63 496 minecraft:red_terracotta
setblock 472 60 500 minecraft:terracotta
fill 472 60 501 472 63 501 minecraft:red_terracotta
setblock 473 60 464 minecraft:terracotta
fill 473 60 465 473 63 465 minecraft:red_terracotta
fill 473 60 482 473 60 483 minecraft:red_terracotta
setblock 473 60 484 minecraft:terracotta
fill 473 60 485 473 63 485 minecraft:red_terracotta
setblock 473 60 488 minecraft:red_terracotta
setblock 473 60 489 minecraft:terracotta
setblock 473 60 499 minecraft:terracotta
fill 473 60 500 473 63 500 minecraft:red_terracotta
setblock 473 60 504 minecraft:terracotta
fill 474 60 464 474 63 464 minecraft:red_terracotta
setblock 474 60 503 minecraft:terracotta
fill 474 60 504 474 63 504 minecraft:red_terracotta
fill 475 60 465 475 61 465 minecraft:red_terracotta
setblock 475 60 502 minecraft:terracotta
fill 475 60 503 475 63 503 minecraft:red_terracotta
setblock 478 60 464 minecraft:terracotta
setblock 478 60 504 minecraft:terracotta
fill 479 60 504 479 63 504 minecraft:red_terracotta
setblock 488 60 464 minecraft:terracotta
setblock 488 60 504 minecraft:terracotta
fill 489 60 464 489 63 464 minecraft:red_terracotta
fill 489 60 504 489 63 504 minecraft:red_terracotta
fill 490 60 465 491 60 465 minecraft:red_terracotta
setblock 492 60 465 minecraft:terracotta
setblock 493 60 464 minecraft:terracotta
fill 493 60 465 493 62 466 minecraft:red_terracotta
setblock 493 60 504 minecraft:terracotta
fill 494 60 464 494 63 464 minecraft:red_terracotta
fill 494 60 466 495 60 466 minecraft:red_terracotta
setblock 494 60 503 minecraft:terracotta
fill 494 60 504 494 63 504 minecraft:red_terracotta
fill 495 60 503 495 63 503 minecraft:red_terracotta
setblock 496 60 466 minecraft:terracotta
setblock 497 60 465 minecraft:terracotta
fill 497 60 466 497 63 466 minecraft:red_terracotta
setblock 498 60 464 minecraft:terracotta
fill 498 60 465 498 63 465 minecraft:red_terracotta
setblock 498 60 504 minecraft:terracotta
fill 499 60 464 499 63 464 minecraft:red_terracotta
fill 499 60 504 499 63 504 minecraft:red_terracotta
setblock 502 60 465 minecraft:terracotta
setblock 503 60 464 minecraft:terracotta
fill 503 60 465 506 60 465 minecraft:red_terracotta
setblock 503 60 504 minecraft:terracotta
fill 504 60 464 504 63 464 minecraft:red_terracotta
fill 504 60 504 504 63 504 minecraft:red_terracotta
setblock 507 60 465 minecraft:terracotta
fill 507 60 503 507 61 503 minecraft:red_terracotta
setblock 508 60 464 minecraft:terracotta
fill 508 60 465 508 63 465 minecraft:red_terracotta
setblock 508 60 504 minecraft:terracotta
fill 509 60 464 509 63 464 minecraft:red_terracotta
setblock 509 60 503 minecraft:terracotta
fill 509 60 504 509 63 504 minecraft:red_terracotta
setblock 510 60 467 minecraft:terracotta
setblock 510 60 502 minecraft:terracotta
fill 510 60 503 510 63 503 minecraft:red_terracotta
setblock 511 60 466 minecraft:terracotta
fill 511 60 467 511 63 467 minecraft:red_terracotta
setblock 511 60 470 minecraft:red_terracotta
setblock 511 60 481 minecraft:terracotta
fill 511 60 482 511 63 482 minecraft:red_terracotta
setblock 511 60 486 minecraft:terracotta
fill 511 60 487 511 60 490 minecraft:red_terracotta
setblock 511 60 491 minecraft:terracotta
setblock 511 60 495 minecraft:red_terracotta
setblock 511 60 496 minecraft:terracotta
fill 511 60 497 511 63 497 minecraft:red_terracotta
setblock 511 60 501 minecraft:terracotta
fill 511 60 502 511 63 502 minecraft:red_terracotta
setblock 471 61 465 minecraft:terracotta
fill 471 61 466 471 64 466 minecraft:red_terracotta
setblock 471 61 469 minecraft:red_terracotta
setblock 471 61 480 minecraft:terracotta
fill 471 61 481 471 64 481 minecraft:red_terracotta
setblock 471 61 485 minecraft:terracotta
fill 471 61 486 471 61 489 minecraft:red_terracotta
setblock 471 61 490 minecraft:terracotta
fill 471 61 491 471 64 491 minecraft:red_terracotta
setblock 471 61 495 minecraft:terracotta
fill 471 61 496 471 64 496 minecraft:red_terracotta
setblock 471 61 500 minecraft:terracotta
fill 471 61 501 471 64 501 minecraft:red_terracotta
setblock 472 61 464 minecraft:terracotta
fill 472 61 465 472 64 465 minecraft:red_terracotta
fill 472 61 467 472 62 467 minecraft:red_terracotta
fill 472 61 480 472 64 480 minecraft:red_terracotta
setblock 472 61 484 minecraft:terracotta
fill 472 61 485 472 64 485 minecraft:red_terracotta
setblock 472 61 489 minecraft:terracotta
fill 472 61 490 473 63 490 minecraft:red_terracotta
setblock 472 61 493 minecraft:red_terracotta
setblock 472 61 494 minecraft:terracotta
fill 472 61 495 472 64 495 minecraft:red_terracotta
setblock 472 61 499 minecraft:terracotta
fill 472 61 500 472 64 500 minecraft:red_terracotta
setblock 472 61 504 minecraft:terracotta
fill 473 61 464 473 64 464 minecraft:red_terracotta
setblock 473 61 466 minecraft:light[level=14]
setblock 473 61 474 minecraft:light[level=14]
setblock 473 61 482 minecraft:red_terracotta
setblock 473 61 483 minecraft:terracotta
fill 473 61 484 473 64 484 minecraft:red_terracotta
setblock 473 61 488 minecraft:terracotta
fill 473 61 489 473 64 489 minecraft:red_terracotta
fill 473 61 491 473 62 491 minecraft:red_terracotta
setblock 473 61 498 minecraft:light[level=14]
setblock 473 61 503 minecraft:terracotta
fill 473 61 504 473 64 504 minecraft:red_terracotta
setblock 474 61 486 minecraft:red_terracotta
setblock 474 61 502 minecraft:terracotta
fill 474 61 503 474 64 503 minecraft:red_terracotta
setblock 475 61 502 minecraft:red_terracotta
setblock 477 61 464 minecraft:terracotta
setblock 477 61 504 minecraft:terracotta
fill 478 61 464 479 63 464 minecraft:red_terracotta
fill 478 61 504 478 64 504 minecraft:red_terracotta
setblock 481 61 466 minecraft:light[level=14]
setblock 481 61 474 minecraft:light[level=14]
setblock 481 61 482 minecraft:light[level=14]
setblock 481 61 490 minecraft:light[level=14]
fill 483 61 498 485 62 498 minecraft:orange_concrete
fill 484 61 497 484 62 497 minecraft:orange_concrete
fill 484 61 499 484 62 499 minecraft:orange_concrete
setblock 486 61 464 minecraft:red_terracotta
setblock 487 61 464 minecraft:terracotta
fill 488 61 464 488 64 464 minecraft:red_terracotta
fill 488 61 504 488 64 504 minecraft:red_terracotta
fill 489 61 465 490 61 465 minecraft:red_terracotta
setblock 489 61 466 minecraft:light[level=14]
setblock 489 61 490 minecraft:light[level=14]
setblock 489 61 498 minecraft:light[level=14]
setblock 491 61 465 minecraft:terracotta
fill 491 61 466 492 63 466 minecraft:red_terracotta
setblock 492 61 464 minecraft:terracotta
fill 492 61 465 492 64 465 minecraft:red_terracotta
setblock 492 61 503 minecraft:red_terracotta
setblock 492 61 504 minecraft:terracotta
fill 493 61 464 493 64 464 minecraft:red_terracotta
setblock 493 61 503 minecraft:terracotta
fill 493 61 504 493 64 504 minecraft:red_terracotta
setblock 494 61 466 minecraft:red_terracotta
fill 494 61 503 494 64 503 minecraft:red_terracotta
setblock 495 61 466 minecraft:terracotta
setblock 496 61 465 minecraft:terracotta
fill 496 61 466 496 64 466 minecraft:red_terracotta
setblock 497 61 464 minecraft:terracotta
fill 497 61 465 497 64 465 minecraft:red_terracotta
setblock 497 61 474 minecraft:light[level=14]
setblock 497 61 482 minecraft:light[level=14]
setblock 497 61 490 minecraft:light[level=14]
setblock 497 61 504 minecraft:terracotta
fill 498 61 464 498 64 464 minecraft:red_terracotta
fill 498 61 466 498 62 466 minecraft:red_terracotta
fill 498 61 504 498 64 504 minecraft:red_terracotta
setblock 501 61 465 minecraft:terracotta
setblock 502 61 464 minecraft:terracotta
fill 502 61 465 505 61 465 minecraft:red_terracotta
setblock 502 61 504 minecraft:terracotta
fill 503 61 464 503 64 464 minecraft:red_terracotta
fill 503 61 488 505 62 488 minecraft:magma_block
fill 503 61 504 503 64 504 minecraft:red_terracotta
fill 504 61 487 505 62 487 minecraft:magma_block
setblock 505 61 466 minecraft:light[level=14]
setblock 505 61 474 minecraft:light[level=14]
setblock 505 61 482 minecraft:light[level=14]
setblock 505 61 490 minecraft:light[level=14]
setblock 505 61 498 minecraft:light[level=14]
setblock 506 61 465 minecraft:terracotta
fill 506 61 503 506 62 503 minecraft:red_terracotta
setblock 507 61 464 minecraft:terracotta
fill 507 61 465 507 64 465 minecraft:red_terracotta
setblock 507 61 504 minecraft:terracotta
fill 508 61 464 508 64 464 minecraft:red_terracotta
setblock 508 61 503 minecraft:terracotta
fill 508 61 504 508 64 504 minecraft:red_terracotta
setblock 509 61 466 minecraft:red_terracotta
fill 509 61 503 509 64 503 minecraft:red_terracotta
setblock 510 61 466 minecraft:terracotta
fill 510 61 467 510 62 469 minecraft:red_terracotta
fill 510 61 484 510 61 485 minecraft:red_terracotta
setblock 510 61 486 minecraft:terracotta
fill 510 61 499 510 62 499 minecraft:red_terracotta
setblock 510 61 501 minecraft:terracotta
fill 510 61 502 510 64 502 minecraft:red_terracotta
setblock 511 61 465 minecraft:terracotta
fill 511 61 466 511 64 466 minecraft:red_terracotta
setblock 511 61 470 minecraft:terracotta
fill 511 61 471 511 64 471 minecraft:red_terracotta
setblock 511 61 480 minecraft:terracotta
fill 511 61 481 511 64 481 minecraft:red_terracotta
setblock 511 61 484 minecraft:red_terracotta
setblock 511 61 485 minecraft:terracotta
fill 511 61 486 511 61 489 minecraft:red_terracotta
setblock 511 61 490 minecraft:terracotta
fill 511 61 491 511 61 494 minecraft:red_terracotta
setblock 511 61 495 minecraft:terracotta
fill 511 61 496 511 64 496 minecraft:red_terracotta
setblock 511 61 500 minecraft:terracotta
fill 511 61 501 511 64 501 minecraft:red_terracotta
setblock 471 62 464 minecraft:terracotta
fill 471 62 465 471 65 465 minecraft:red_terracotta
schedule function dropper:buildpart/118_2 1t
