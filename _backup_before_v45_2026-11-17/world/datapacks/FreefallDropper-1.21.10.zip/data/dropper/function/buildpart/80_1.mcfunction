setblock 395 87 324 minecraft:gray_concrete
setblock 396 87 324 minecraft:polished_deepslate
setblock 396 87 363 minecraft:gray_concrete
setblock 397 87 323 minecraft:polished_deepslate
fill 397 87 324 397 89 325 minecraft:gray_concrete
setblock 397 87 363 minecraft:polished_deepslate
fill 398 87 323 398 90 323 minecraft:gray_concrete
fill 398 87 363 398 90 363 minecraft:gray_concrete
setblock 400 87 324 minecraft:gray_concrete
setblock 400 87 325 minecraft:polished_deepslate
setblock 401 87 324 minecraft:polished_deepslate
fill 401 87 325 401 90 325 minecraft:gray_concrete
setblock 402 87 323 minecraft:polished_deepslate
fill 402 87 324 402 90 324 minecraft:gray_concrete
setblock 402 87 363 minecraft:polished_deepslate
fill 403 87 323 403 90 323 minecraft:gray_concrete
setblock 403 87 362 minecraft:polished_deepslate
fill 403 87 363 403 90 363 minecraft:gray_concrete
fill 404 87 362 404 89 362 minecraft:gray_concrete
setblock 405 87 325 minecraft:polished_deepslate
setblock 406 87 324 minecraft:polished_deepslate
setblock 407 87 323 minecraft:polished_deepslate
fill 407 87 324 407 90 324 minecraft:gray_concrete
setblock 407 87 363 minecraft:polished_deepslate
fill 408 87 323 408 90 323 minecraft:gray_concrete
fill 408 87 363 408 90 363 minecraft:gray_concrete
setblock 412 87 323 minecraft:polished_deepslate
setblock 412 87 363 minecraft:polished_deepslate
fill 413 87 323 413 90 323 minecraft:gray_concrete
fill 413 87 363 413 90 363 minecraft:gray_concrete
fill 414 87 362 414 90 362 minecraft:gray_concrete
setblock 416 87 324 minecraft:polished_deepslate
fill 416 87 360 416 90 360 minecraft:gray_concrete
setblock 417 87 323 minecraft:polished_deepslate
fill 417 87 324 417 90 324 minecraft:gray_concrete
setblock 417 87 327 minecraft:gray_concrete
setblock 417 87 343 minecraft:polished_deepslate
fill 417 87 344 417 90 344 minecraft:gray_concrete
fill 417 87 346 417 87 347 minecraft:gray_concrete
setblock 417 87 348 minecraft:polished_deepslate
fill 417 87 349 417 90 349 minecraft:gray_concrete
fill 417 87 351 417 87 352 minecraft:gray_concrete
setblock 417 87 353 minecraft:polished_deepslate
fill 417 87 354 417 89 355 minecraft:gray_concrete
setblock 417 87 358 minecraft:polished_deepslate
fill 417 87 359 417 90 359 minecraft:gray_concrete
setblock 417 87 363 minecraft:polished_deepslate
fill 376 88 328 376 122 328 minecraft:black_concrete
fill 377 88 323 377 91 323 minecraft:gray_concrete
setblock 377 88 327 minecraft:polished_deepslate
fill 377 88 328 377 91 328 minecraft:gray_concrete
fill 377 88 338 377 91 338 minecraft:gray_concrete
setblock 377 88 342 minecraft:polished_deepslate
fill 377 88 343 377 91 343 minecraft:gray_concrete
setblock 377 88 347 minecraft:polished_deepslate
fill 377 88 348 377 91 348 minecraft:gray_concrete
setblock 377 88 352 minecraft:polished_deepslate
fill 377 88 353 377 88 356 minecraft:gray_concrete
setblock 377 88 357 minecraft:polished_deepslate
fill 377 88 358 377 91 358 minecraft:gray_concrete
setblock 377 88 362 minecraft:polished_deepslate
fill 377 88 363 377 91 363 minecraft:gray_concrete
fill 378 88 324 379 88 324 minecraft:gray_concrete
setblock 378 88 341 minecraft:polished_deepslate
fill 378 88 342 378 91 342 minecraft:gray_concrete
setblock 378 88 346 minecraft:polished_deepslate
fill 378 88 347 378 91 347 minecraft:gray_concrete
setblock 378 88 351 minecraft:polished_deepslate
fill 378 88 352 378 91 352 minecraft:gray_concrete
fill 378 88 354 378 89 354 minecraft:gray_concrete
setblock 378 88 361 minecraft:polished_deepslate
fill 378 88 362 378 91 362 minecraft:gray_concrete
fill 379 88 341 379 91 341 minecraft:gray_concrete
setblock 379 88 345 minecraft:polished_deepslate
fill 379 88 346 379 91 346 minecraft:gray_concrete
setblock 379 88 350 minecraft:polished_deepslate
fill 379 88 351 379 91 351 minecraft:gray_concrete
setblock 380 88 324 minecraft:polished_deepslate
setblock 380 88 343 minecraft:gray_concrete
setblock 380 88 344 minecraft:polished_deepslate
fill 380 88 345 380 91 345 minecraft:gray_concrete
setblock 380 88 348 minecraft:gray_concrete
setblock 381 88 323 minecraft:polished_deepslate
fill 381 88 324 382 90 324 minecraft:gray_concrete
setblock 381 88 363 minecraft:polished_deepslate
fill 382 88 323 382 91 323 minecraft:gray_concrete
fill 382 88 363 382 91 363 minecraft:gray_concrete
setblock 386 88 323 minecraft:polished_deepslate
setblock 391 88 323 minecraft:polished_deepslate
fill 392 88 323 395 88 323 minecraft:gray_concrete
setblock 394 88 324 minecraft:gray_concrete
setblock 395 88 324 minecraft:polished_deepslate
setblock 396 88 323 minecraft:polished_deepslate
fill 396 88 324 396 90 325 minecraft:gray_concrete
setblock 396 88 363 minecraft:polished_deepslate
fill 397 88 323 397 91 323 minecraft:gray_concrete
fill 397 88 363 397 91 363 minecraft:gray_concrete
setblock 399 88 324 minecraft:gray_concrete
setblock 399 88 325 minecraft:polished_deepslate
fill 399 88 326 401 89 326 minecraft:gray_concrete
fill 399 88 362 399 90 362 minecraft:gray_concrete
setblock 400 88 324 minecraft:polished_deepslate
fill 400 88 325 400 91 325 minecraft:gray_concrete
setblock 401 88 323 minecraft:polished_deepslate
fill 401 88 324 401 91 324 minecraft:gray_concrete
setblock 401 88 363 minecraft:polished_deepslate
fill 402 88 323 402 91 323 minecraft:gray_concrete
setblock 402 88 362 minecraft:polished_deepslate
fill 402 88 363 402 91 363 minecraft:gray_concrete
fill 403 88 362 403 91 362 minecraft:gray_concrete
setblock 404 88 325 minecraft:polished_deepslate
setblock 405 88 324 minecraft:polished_deepslate
fill 405 88 325 405 91 325 minecraft:gray_concrete
setblock 406 88 323 minecraft:polished_deepslate
fill 406 88 324 406 91 324 minecraft:gray_concrete
setblock 406 88 363 minecraft:polished_deepslate
fill 407 88 323 407 91 323 minecraft:gray_concrete
fill 407 88 363 407 91 363 minecraft:gray_concrete
fill 409 88 336 409 96 336 minecraft:black_concrete
fill 410 88 337 410 96 337 minecraft:black_concrete
setblock 411 88 323 minecraft:polished_deepslate
fill 411 88 336 411 96 336 minecraft:black_concrete
setblock 411 88 363 minecraft:polished_deepslate
fill 412 88 323 412 91 323 minecraft:gray_concrete
fill 412 88 363 412 91 363 minecraft:gray_concrete
fill 413 88 352 413 90 352 minecraft:black_concrete
setblock 414 88 324 minecraft:gray_concrete
fill 414 88 351 414 90 351 minecraft:black_concrete
fill 414 88 353 414 90 353 minecraft:black_concrete
setblock 415 88 324 minecraft:polished_deepslate
fill 415 88 352 415 90 352 minecraft:black_concrete
setblock 416 88 323 minecraft:polished_deepslate
fill 416 88 324 416 90 325 minecraft:gray_concrete
fill 416 88 345 416 88 347 minecraft:gray_concrete
setblock 416 88 348 minecraft:polished_deepslate
setblock 416 88 363 minecraft:polished_deepslate
fill 417 88 323 417 91 323 minecraft:gray_concrete
setblock 417 88 327 minecraft:polished_deepslate
fill 417 88 328 417 91 328 minecraft:gray_concrete
fill 417 88 340 417 89 340 minecraft:gray_concrete
setblock 417 88 342 minecraft:polished_deepslate
fill 417 88 343 417 91 343 minecraft:gray_concrete
setblock 417 88 346 minecraft:gray_concrete
setblock 417 88 347 minecraft:polished_deepslate
fill 417 88 348 417 91 348 minecraft:gray_concrete
setblock 417 88 351 minecraft:gray_concrete
setblock 417 88 352 minecraft:polished_deepslate
fill 417 88 353 417 91 353 minecraft:gray_concrete
setblock 417 88 357 minecraft:polished_deepslate
fill 417 88 358 417 91 358 minecraft:gray_concrete
setblock 417 88 362 minecraft:polished_deepslate
fill 417 88 363 417 91 363 minecraft:gray_concrete
fill 418 88 336 418 120 339 minecraft:black_concrete
setblock 418 88 340 minecraft:light_blue_stained_glass
fill 418 88 341 418 101 361 minecraft:black_concrete
setblock 376 89 359 minecraft:light_blue_stained_glass
setblock 377 89 326 minecraft:polished_deepslate
fill 377 89 327 378 91 327 minecraft:gray_concrete
fill 377 89 329 377 89 330 minecraft:gray_concrete
fill 377 89 337 377 92 337 minecraft:gray_concrete
setblock 377 89 341 minecraft:polished_deepslate
fill 377 89 342 377 92 342 minecraft:gray_concrete
setblock 377 89 346 minecraft:polished_deepslate
fill 377 89 347 377 92 347 minecraft:gray_concrete
setblock 377 89 351 minecraft:polished_deepslate
fill 377 89 352 377 89 355 minecraft:gray_concrete
setblock 377 89 356 minecraft:polished_deepslate
fill 377 89 357 377 92 357 minecraft:gray_concrete
setblock 377 89 361 minecraft:polished_deepslate
fill 377 89 362 377 92 362 minecraft:gray_concrete
setblock 378 89 324 minecraft:gray_concrete
setblock 378 89 325 minecraft:polished_deepslate
fill 378 89 326 378 92 326 minecraft:gray_concrete
setblock 378 89 340 minecraft:polished_deepslate
fill 378 89 341 378 92 341 minecraft:gray_concrete
setblock 378 89 345 minecraft:polished_deepslate
fill 378 89 346 378 92 346 minecraft:gray_concrete
setblock 378 89 349 minecraft:gray_concrete
setblock 378 89 350 minecraft:polished_deepslate
fill 378 89 351 378 92 351 minecraft:gray_concrete
setblock 378 89 355 minecraft:polished_deepslate
fill 378 89 361 378 91 361 minecraft:gray_concrete
setblock 379 89 324 minecraft:polished_deepslate
setblock 379 89 344 minecraft:polished_deepslate
fill 379 89 345 379 92 345 minecraft:gray_concrete
setblock 379 89 349 minecraft:polished_deepslate
fill 379 89 350 379 92 350 minecraft:gray_concrete
fill 379 89 352 379 90 352 minecraft:gray_concrete
setblock 380 89 323 minecraft:polished_deepslate
fill 380 89 324 380 92 324 minecraft:gray_concrete
setblock 380 89 343 minecraft:polished_deepslate
fill 380 89 344 380 92 344 minecraft:gray_concrete
setblock 380 89 348 minecraft:polished_deepslate
fill 380 89 349 380 92 349 minecraft:gray_concrete
setblock 380 89 363 minecraft:polished_deepslate
fill 381 89 323 381 92 323 minecraft:gray_concrete
fill 381 89 363 381 92 363 minecraft:gray_concrete
setblock 383 89 324 minecraft:gray_concrete
setblock 385 89 323 minecraft:polished_deepslate
fill 386 89 323 386 92 323 minecraft:gray_concrete
setblock 390 89 323 minecraft:polished_deepslate
fill 391 89 323 394 89 323 minecraft:gray_concrete
setblock 393 89 324 minecraft:gray_concrete
setblock 394 89 324 minecraft:polished_deepslate
setblock 395 89 323 minecraft:polished_deepslate
fill 395 89 324 395 91 325 minecraft:gray_concrete
setblock 395 89 363 minecraft:polished_deepslate
fill 396 89 323 396 92 323 minecraft:gray_concrete
fill 396 89 363 396 92 363 minecraft:gray_concrete
setblock 397 89 326 minecraft:polished_deepslate
fill 398 89 322 398 120 322 minecraft:black_concrete
setblock 398 89 324 minecraft:gray_concrete
setblock 398 89 325 minecraft:polished_deepslate
fill 398 89 326 398 92 326 minecraft:gray_concrete
setblock 399 89 322 minecraft:light_blue_stained_glass
setblock 399 89 324 minecraft:polished_deepslate
fill 399 89 325 399 92 325 minecraft:gray_concrete
setblock 399 89 364 minecraft:light_blue_stained_glass
fill 400 89 322 407 92 322 minecraft:black_concrete
setblock 400 89 323 minecraft:polished_deepslate
fill 400 89 324 400 92 324 minecraft:gray_concrete
setblock 400 89 363 minecraft:polished_deepslate
fill 401 89 323 401 92 323 minecraft:gray_concrete
setblock 401 89 362 minecraft:polished_deepslate
fill 401 89 363 401 92 363 minecraft:gray_concrete
setblock 402 89 326 minecraft:polished_deepslate
fill 402 89 362 402 92 362 minecraft:gray_concrete
setblock 403 89 325 minecraft:polished_deepslate
setblock 404 89 324 minecraft:polished_deepslate
fill 404 89 325 404 92 325 minecraft:gray_concrete
setblock 405 89 323 minecraft:polished_deepslate
fill 405 89 324 405 92 324 minecraft:gray_concrete
setblock 405 89 363 minecraft:polished_deepslate
fill 406 89 323 406 92 323 minecraft:gray_concrete
fill 406 89 363 406 92 363 minecraft:gray_concrete
fill 407 89 352 407 90 353 minecraft:white_wool
setblock 409 89 324 minecraft:polished_deepslate
fill 409 89 335 411 96 335 minecraft:black_concrete
fill 409 89 337 409 96 337 minecraft:black_concrete
setblock 410 89 323 minecraft:polished_deepslate
fill 410 89 324 413 89 324 minecraft:gray_concrete
setblock 410 89 363 minecraft:polished_deepslate
fill 411 89 323 411 92 323 minecraft:gray_concrete
fill 411 89 337 411 96 337 minecraft:black_concrete
fill 411 89 363 411 92 363 minecraft:gray_concrete
setblock 414 89 324 minecraft:polished_deepslate
setblock 415 89 323 minecraft:polished_deepslate
fill 415 89 324 415 92 324 minecraft:gray_concrete
setblock 415 89 363 minecraft:polished_deepslate
fill 416 89 323 416 92 323 minecraft:gray_concrete
setblock 416 89 326 minecraft:gray_concrete
fill 416 89 344 416 89 346 minecraft:gray_concrete
setblock 416 89 347 minecraft:polished_deepslate
fill 416 89 348 416 89 351 minecraft:gray_concrete
setblock 416 89 352 minecraft:polished_deepslate
fill 416 89 359 416 91 359 minecraft:gray_concrete
setblock 416 89 362 minecraft:polished_deepslate
fill 416 89 363 416 92 363 minecraft:gray_concrete
setblock 417 89 326 minecraft:polished_deepslate
fill 417 89 327 417 92 327 minecraft:gray_concrete
fill 417 89 329 417 90 329 minecraft:gray_concrete
setblock 417 89 341 minecraft:polished_deepslate
fill 417 89 342 417 92 342 minecraft:gray_concrete
setblock 417 89 346 minecraft:polished_deepslate
fill 417 89 347 417 92 347 minecraft:gray_concrete
setblock 417 89 351 minecraft:polished_deepslate
fill 417 89 352 417 92 352 minecraft:gray_concrete
setblock 417 89 356 minecraft:polished_deepslate
fill 417 89 357 417 92 357 minecraft:gray_concrete
setblock 417 89 361 minecraft:polished_deepslate
fill 417 89 362 417 92 362 minecraft:gray_concrete
fill 418 89 340 418 122 340 minecraft:black_concrete
fill 376 90 359 376 122 359 minecraft:black_concrete
setblock 377 90 325 minecraft:polished_deepslate
fill 377 90 326 377 93 326 minecraft:gray_concrete
setblock 377 90 329 minecraft:gray_concrete
setblock 377 90 330 minecraft:polished_deepslate
fill 377 90 331 377 90 334 minecraft:gray_concrete
setblock 377 90 335 minecraft:polished_deepslate
fill 377 90 336 377 93 336 minecraft:gray_concrete
setblock 377 90 340 minecraft:polished_deepslate
fill 377 90 341 377 93 341 minecraft:gray_concrete
setblock 377 90 345 minecraft:polished_deepslate
fill 377 90 346 377 93 346 minecraft:gray_concrete
setblock 377 90 350 minecraft:polished_deepslate
fill 377 90 351 377 90 354 minecraft:gray_concrete
setblock 377 90 355 minecraft:polished_deepslate
fill 377 90 356 378 92 356 minecraft:gray_concrete
setblock 377 90 360 minecraft:polished_deepslate
fill 377 90 361 377 93 361 minecraft:gray_concrete
setblock 378 90 324 minecraft:polished_deepslate
fill 378 90 325 378 93 325 minecraft:gray_concrete
setblock 378 90 328 minecraft:gray_concrete
setblock 378 90 329 minecraft:polished_deepslate
setblock 378 90 338 minecraft:gray_concrete
setblock 378 90 339 minecraft:polished_deepslate
fill 378 90 340 379 92 340 minecraft:gray_concrete
setblock 378 90 344 minecraft:polished_deepslate
fill 378 90 345 378 93 345 minecraft:gray_concrete
setblock 378 90 349 minecraft:polished_deepslate
fill 378 90 350 378 93 350 minecraft:gray_concrete
setblock 378 90 354 minecraft:polished_deepslate
fill 378 90 355 378 93 355 minecraft:gray_concrete
fill 378 90 357 378 91 357 minecraft:gray_concrete
setblock 379 90 323 minecraft:polished_deepslate
fill 379 90 324 379 93 324 minecraft:gray_concrete
setblock 379 90 343 minecraft:polished_deepslate
fill 379 90 344 379 93 344 minecraft:gray_concrete
setblock 379 90 347 minecraft:gray_concrete
setblock 379 90 348 minecraft:polished_deepslate
fill 379 90 349 379 93 349 minecraft:gray_concrete
setblock 379 90 353 minecraft:polished_deepslate
setblock 379 90 363 minecraft:polished_deepslate
fill 380 90 323 380 93 323 minecraft:gray_concrete
fill 380 90 343 380 92 343 minecraft:gray_concrete
setblock 380 90 347 minecraft:polished_deepslate
fill 380 90 348 380 93 348 minecraft:gray_concrete
fill 380 90 350 380 91 350 minecraft:gray_concrete
fill 380 90 363 380 93 363 minecraft:gray_concrete
setblock 383 90 324 minecraft:polished_deepslate
setblock 384 90 323 minecraft:polished_deepslate
fill 385 90 323 385 93 323 minecraft:gray_concrete
fill 387 90 323 388 90 323 minecraft:gray_concrete
setblock 389 90 323 minecraft:polished_deepslate
fill 390 90 323 393 90 323 minecraft:gray_concrete
setblock 392 90 324 minecraft:gray_concrete
setblock 393 90 324 minecraft:polished_deepslate
setblock 394 90 323 minecraft:polished_deepslate
fill 394 90 324 394 92 325 minecraft:gray_concrete
setblock 394 90 363 minecraft:polished_deepslate
fill 395 90 323 395 93 323 minecraft:gray_concrete
fill 395 90 363 395 93 363 minecraft:gray_concrete
setblock 396 90 326 minecraft:polished_deepslate
fill 396 90 358 396 106 358 minecraft:light_blue_concrete
setblock 397 90 324 minecraft:gray_concrete
setblock 397 90 325 minecraft:polished_deepslate
fill 397 90 326 397 93 326 minecraft:gray_concrete
setblock 398 90 324 minecraft:polished_deepslate
fill 398 90 325 398 93 325 minecraft:gray_concrete
fill 398 90 362 398 91 362 minecraft:gray_concrete
setblock 399 90 322 minecraft:black_concrete
setblock 399 90 323 minecraft:polished_deepslate
fill 399 90 324 399 93 324 minecraft:gray_concrete
fill 399 90 326 400 90 326 minecraft:gray_concrete
setblock 399 90 363 minecraft:polished_deepslate
fill 399 90 364 399 122 364 minecraft:black_concrete
fill 400 90 323 400 93 323 minecraft:gray_concrete
setblock 400 90 362 minecraft:polished_deepslate
fill 400 90 363 400 93 363 minecraft:gray_concrete
setblock 401 90 326 minecraft:polished_deepslate
fill 401 90 362 401 93 362 minecraft:gray_concrete
setblock 402 90 325 minecraft:polished_deepslate
fill 402 90 326 403 92 326 minecraft:gray_concrete
setblock 403 90 324 minecraft:polished_deepslate
fill 403 90 325 403 93 325 minecraft:gray_concrete
setblock 404 90 323 minecraft:polished_deepslate
fill 404 90 324 404 93 324 minecraft:gray_concrete
setblock 404 90 363 minecraft:polished_deepslate
fill 405 90 323 405 93 323 minecraft:gray_concrete
fill 405 90 363 405 93 363 minecraft:gray_concrete
setblock 406 90 325 minecraft:gray_concrete
setblock 408 90 324 minecraft:polished_deepslate
fill 408 90 336 408 96 337 minecraft:black_concrete
setblock 409 90 323 minecraft:polished_deepslate
fill 409 90 324 412 90 324 minecraft:gray_concrete
fill 409 90 338 411 96 338 minecraft:black_concrete
setblock 409 90 363 minecraft:polished_deepslate
fill 410 90 323 410 93 323 minecraft:gray_concrete
fill 410 90 363 410 93 363 minecraft:gray_concrete
fill 412 90 336 412 96 337 minecraft:black_concrete
setblock 413 90 324 minecraft:polished_deepslate
setblock 413 90 351 minecraft:black_concrete
setblock 413 90 353 minecraft:black_concrete
fill 413 90 362 413 91 362 minecraft:gray_concrete
setblock 414 90 323 minecraft:polished_deepslate
fill 414 90 324 414 93 324 minecraft:gray_concrete
setblock 414 90 363 minecraft:polished_deepslate
fill 415 90 323 415 93 323 minecraft:gray_concrete
setblock 415 90 351 minecraft:black_concrete
setblock 415 90 353 minecraft:black_concrete
setblock 415 90 362 minecraft:polished_deepslate
fill 415 90 363 415 93 363 minecraft:gray_concrete
setblock 416 90 326 minecraft:polished_deepslate
fill 416 90 327 416 92 328 minecraft:gray_concrete
fill 416 90 343 416 90 345 minecraft:gray_concrete
setblock 416 90 346 minecraft:polished_deepslate
fill 416 90 347 416 90 350 minecraft:gray_concrete
setblock 416 90 351 minecraft:polished_deepslate
fill 416 90 352 416 90 355 minecraft:gray_concrete
setblock 416 90 356 minecraft:polished_deepslate
fill 416 90 357 416 92 358 minecraft:gray_concrete
setblock 416 90 361 minecraft:polished_deepslate
fill 416 90 362 416 93 362 minecraft:gray_concrete
setblock 417 90 325 minecraft:polished_deepslate
fill 417 90 326 417 93 326 minecraft:gray_concrete
setblock 417 90 330 minecraft:polished_deepslate
fill 417 90 331 417 93 331 minecraft:gray_concrete
setblock 417 90 339 minecraft:gray_concrete
setblock 417 90 340 minecraft:polished_deepslate
fill 417 90 341 417 93 341 minecraft:gray_concrete
setblock 417 90 345 minecraft:polished_deepslate
fill 417 90 346 417 93 346 minecraft:gray_concrete
setblock 417 90 350 minecraft:polished_deepslate
fill 417 90 351 417 93 351 minecraft:gray_concrete
setblock 417 90 354 minecraft:gray_concrete
setblock 417 90 355 minecraft:polished_deepslate
fill 417 90 356 417 93 356 minecraft:gray_concrete
setblock 417 90 360 minecraft:polished_deepslate
fill 417 90 361 417 93 361 minecraft:gray_concrete
fill 376 91 347 376 120 353 minecraft:black_concrete
setblock 376 91 354 minecraft:light_blue_stained_glass
fill 376 91 355 376 122 356 minecraft:black_concrete
setblock 377 91 324 minecraft:polished_deepslate
fill 377 91 325 377 94 325 minecraft:gray_concrete
setblock 377 91 329 minecraft:polished_deepslate
fill 377 91 330 377 91 333 minecraft:gray_concrete
setblock 377 91 334 minecraft:polished_deepslate
fill 377 91 335 377 94 335 minecraft:gray_concrete
setblock 377 91 339 minecraft:polished_deepslate
fill 377 91 340 377 94 340 minecraft:gray_concrete
setblock 377 91 344 minecraft:polished_deepslate
fill 377 91 345 377 94 345 minecraft:gray_concrete
setblock 377 91 349 minecraft:polished_deepslate
fill 377 91 350 377 91 353 minecraft:gray_concrete
setblock 377 91 354 minecraft:polished_deepslate
fill 377 91 355 377 94 355 minecraft:gray_concrete
setblock 377 91 359 minecraft:polished_deepslate
fill 377 91 360 377 94 360 minecraft:gray_concrete
setblock 378 91 323 minecraft:polished_deepslate
fill 378 91 324 378 94 324 minecraft:gray_concrete
setblock 378 91 328 minecraft:polished_deepslate
fill 378 91 329 378 91 332 minecraft:gray_concrete
setblock 378 91 337 minecraft:gray_concrete
setblock 378 91 338 minecraft:polished_deepslate
fill 378 91 339 378 94 339 minecraft:gray_concrete
setblock 378 91 343 minecraft:polished_deepslate
fill 378 91 344 378 94 344 minecraft:gray_concrete
setblock 378 91 348 minecraft:polished_deepslate
fill 378 91 349 378 94 349 minecraft:gray_concrete
setblock 378 91 353 minecraft:polished_deepslate
fill 378 91 354 379 93 354 minecraft:gray_concrete
setblock 378 91 358 minecraft:polished_deepslate
fill 378 91 359 378 93 359 minecraft:gray_concrete
setblock 378 91 363 minecraft:polished_deepslate
fill 379 91 323 379 94 323 minecraft:gray_concrete
setblock 379 91 326 minecraft:gray_concrete
setblock 379 91 342 minecraft:polished_deepslate
fill 379 91 343 379 94 343 minecraft:gray_concrete
setblock 379 91 347 minecraft:polished_deepslate
fill 379 91 348 379 94 348 minecraft:gray_concrete
setblock 379 91 352 minecraft:polished_deepslate
fill 379 91 353 379 94 353 minecraft:gray_concrete
setblock 379 91 362 minecraft:polished_deepslate
fill 379 91 363 379 94 363 minecraft:gray_concrete
setblock 380 91 346 minecraft:polished_deepslate
fill 380 91 347 380 94 347 minecraft:gray_concrete
setblock 380 91 351 minecraft:polished_deepslate
setblock 381 91 324 minecraft:gray_concrete
setblock 382 91 324 minecraft:polished_deepslate
setblock 383 91 323 minecraft:polished_deepslate
fill 383 91 324 383 92 324 minecraft:gray_concrete
fill 384 91 323 384 94 323 minecraft:gray_concrete
setblock 387 91 323 minecraft:gray_concrete
setblock 388 91 323 minecraft:polished_deepslate
fill 389 91 323 392 91 323 minecraft:gray_concrete
setblock 391 91 324 minecraft:gray_concrete
setblock 392 91 324 minecraft:polished_deepslate
setblock 393 91 323 minecraft:polished_deepslate
fill 393 91 324 393 93 325 minecraft:gray_concrete
fill 393 91 358 395 105 360 minecraft:light_blue_concrete
fill 394 91 323 394 94 323 minecraft:gray_concrete
fill 394 91 355 398 105 357 minecraft:light_blue_concrete
fill 394 91 361 398 104 361 minecraft:light_blue_concrete
fill 394 91 363 394 94 363 minecraft:gray_concrete
setblock 395 91 326 minecraft:polished_deepslate
setblock 396 91 324 minecraft:gray_concrete
setblock 396 91 325 minecraft:polished_deepslate
fill 396 91 326 396 94 326 minecraft:gray_concrete
fill 396 91 359 399 105 360 minecraft:light_blue_concrete
setblock 397 91 324 minecraft:polished_deepslate
fill 397 91 325 397 94 325 minecraft:gray_concrete
fill 397 91 358 399 105 358 minecraft:light_blue_concrete
fill 397 91 362 397 92 362 minecraft:gray_concrete
setblock 398 91 323 minecraft:polished_deepslate
fill 398 91 324 398 94 324 minecraft:gray_concrete
setblock 398 91 327 minecraft:gray_concrete
setblock 398 91 363 minecraft:polished_deepslate
setblock 399 91 322 minecraft:light_blue_stained_glass
fill 399 91 323 399 94 323 minecraft:gray_concrete
setblock 399 91 326 minecraft:gray_concrete
setblock 399 91 327 minecraft:polished_deepslate
fill 399 91 356 399 105 357 minecraft:light_blue_concrete
setblock 399 91 362 minecraft:polished_deepslate
fill 399 91 363 399 94 363 minecraft:gray_concrete
setblock 400 91 326 minecraft:polished_deepslate
fill 400 91 362 400 94 362 minecraft:gray_concrete
setblock 401 91 325 minecraft:polished_deepslate
fill 401 91 326 401 94 326 minecraft:gray_concrete
setblock 402 91 324 minecraft:polished_deepslate
fill 402 91 325 402 94 325 minecraft:gray_concrete
setblock 403 91 323 minecraft:polished_deepslate
fill 403 91 324 403 94 324 minecraft:gray_concrete
setblock 403 91 363 minecraft:polished_deepslate
fill 404 91 323 404 94 323 minecraft:gray_concrete
fill 404 91 363 404 94 363 minecraft:gray_concrete
setblock 406 91 325 minecraft:polished_deepslate
setblock 407 91 324 minecraft:polished_deepslate
setblock 408 91 323 minecraft:polished_deepslate
fill 408 91 324 411 91 324 minecraft:gray_concrete
fill 408 91 335 408 96 335 minecraft:black_concrete
fill 408 91 338 408 96 338 minecraft:black_concrete
setblock 408 91 363 minecraft:polished_deepslate
fill 409 91 323 409 94 323 minecraft:gray_concrete
fill 409 91 334 411 96 334 minecraft:black_concrete
fill 409 91 363 409 94 363 minecraft:gray_concrete
setblock 412 91 324 minecraft:polished_deepslate
fill 412 91 335 412 96 335 minecraft:black_concrete
fill 412 91 338 412 96 338 minecraft:black_concrete
setblock 413 91 323 minecraft:polished_deepslate
fill 413 91 324 413 94 324 minecraft:gray_concrete
setblock 413 91 363 minecraft:polished_deepslate
fill 414 91 323 414 94 323 minecraft:gray_concrete
setblock 414 91 362 minecraft:polished_deepslate
fill 414 91 363 414 94 363 minecraft:gray_concrete
setblock 415 91 325 minecraft:gray_concrete
setblock 415 91 346 minecraft:polished_deepslate
fill 415 91 347 415 91 350 minecraft:gray_concrete
setblock 415 91 351 minecraft:polished_deepslate
fill 415 91 352 416 93 352 minecraft:gray_concrete
fill 415 91 362 415 94 362 minecraft:gray_concrete
setblock 416 91 324 minecraft:gray_concrete
setblock 416 91 325 minecraft:polished_deepslate
fill 416 91 326 416 94 326 minecraft:gray_concrete
setblock 416 91 329 minecraft:gray_concrete
fill 416 91 342 416 91 344 minecraft:gray_concrete
setblock 416 91 345 minecraft:polished_deepslate
fill 416 91 346 416 91 349 minecraft:gray_concrete
setblock 416 91 350 minecraft:polished_deepslate
fill 416 91 351 416 94 351 minecraft:gray_concrete
fill 416 91 353 416 91 354 minecraft:gray_concrete
setblock 416 91 355 minecraft:polished_deepslate
fill 416 91 356 416 94 356 minecraft:gray_concrete
setblock 416 91 360 minecraft:polished_deepslate
fill 416 91 361 416 94 361 minecraft:gray_concrete
setblock 417 91 324 minecraft:polished_deepslate
fill 417 91 325 417 94 325 minecraft:gray_concrete
setblock 417 91 329 minecraft:polished_deepslate
fill 417 91 330 417 94 330 minecraft:gray_concrete
fill 417 91 332 417 91 333 minecraft:gray_concrete
setblock 417 91 339 minecraft:polished_deepslate
fill 417 91 340 417 94 340 minecraft:gray_concrete
setblock 417 91 344 minecraft:polished_deepslate
fill 417 91 345 417 94 345 minecraft:gray_concrete
setblock 417 91 349 minecraft:polished_deepslate
fill 417 91 350 417 94 350 minecraft:gray_concrete
setblock 417 91 354 minecraft:polished_deepslate
fill 417 91 355 417 94 355 minecraft:gray_concrete
setblock 417 91 359 minecraft:polished_deepslate
fill 417 91 360 417 94 360 minecraft:gray_concrete
fill 376 92 354 376 119 354 minecraft:black_concrete
setblock 377 92 323 minecraft:polished_deepslate
fill 377 92 324 377 95 324 minecraft:gray_concrete
setblock 377 92 327 minecraft:gray_concrete
setblock 377 92 328 minecraft:polished_deepslate
fill 377 92 329 377 92 332 minecraft:gray_concrete
setblock 377 92 333 minecraft:polished_deepslate
fill 377 92 334 378 94 334 minecraft:gray_concrete
setblock 377 92 338 minecraft:polished_deepslate
fill 377 92 339 377 95 339 minecraft:gray_concrete
setblock 377 92 343 minecraft:polished_deepslate
fill 377 92 344 377 95 344 minecraft:gray_concrete
setblock 377 92 348 minecraft:polished_deepslate
fill 377 92 349 377 92 352 minecraft:gray_concrete
setblock 377 92 353 minecraft:polished_deepslate
fill 377 92 354 377 95 354 minecraft:gray_concrete
setblock 377 92 358 minecraft:polished_deepslate
fill 377 92 359 377 95 359 minecraft:gray_concrete
setblock 377 92 363 minecraft:polished_deepslate
fill 378 92 323 378 95 323 minecraft:gray_concrete
setblock 378 92 327 minecraft:polished_deepslate
fill 378 92 328 378 92 331 minecraft:gray_concrete
setblock 378 92 332 minecraft:polished_deepslate
fill 378 92 333 378 95 333 minecraft:gray_concrete
fill 378 92 335 378 92 336 minecraft:gray_concrete
setblock 378 92 337 minecraft:polished_deepslate
fill 378 92 338 378 95 338 minecraft:gray_concrete
setblock 378 92 342 minecraft:polished_deepslate
fill 378 92 343 378 95 343 minecraft:gray_concrete
setblock 378 92 347 minecraft:polished_deepslate
fill 378 92 348 378 95 348 minecraft:gray_concrete
setblock 378 92 352 minecraft:polished_deepslate
fill 378 92 353 378 95 353 minecraft:gray_concrete
setblock 378 92 357 minecraft:polished_deepslate
fill 378 92 358 378 95 358 minecraft:gray_concrete
setblock 378 92 362 minecraft:polished_deepslate
fill 378 92 363 378 95 363 minecraft:gray_concrete
setblock 379 92 325 minecraft:gray_concrete
setblock 379 92 326 minecraft:polished_deepslate
fill 379 92 327 379 93 329 minecraft:gray_concrete
setblock 379 92 332 minecraft:light[level=12]
setblock 379 92 339 minecraft:light[level=12]
setblock 379 92 341 minecraft:polished_deepslate
fill 379 92 342 379 95 342 minecraft:gray_concrete
setblock 379 92 346 minecraft:polished_deepslate
fill 379 92 347 379 95 347 minecraft:gray_concrete
setblock 379 92 351 minecraft:polished_deepslate
fill 379 92 352 379 95 352 minecraft:gray_concrete
setblock 379 92 360 minecraft:light[level=12]
setblock 380 92 345 minecraft:polished_deepslate
fill 380 92 346 380 94 346 minecraft:gray_concrete
setblock 380 92 350 minecraft:polished_deepslate
fill 380 92 351 380 95 351 minecraft:gray_concrete
setblock 381 92 324 minecraft:polished_deepslate
setblock 382 92 323 minecraft:polished_deepslate
fill 382 92 324 382 93 324 minecraft:gray_concrete
setblock 382 92 363 minecraft:polished_deepslate
fill 383 92 323 383 94 323 minecraft:gray_concrete
setblock 386 92 325 minecraft:light[level=12]
setblock 386 92 332 minecraft:light[level=12]
setblock 386 92 339 minecraft:light[level=12]
setblock 386 92 346 minecraft:light[level=12]
setblock 386 92 353 minecraft:light[level=12]
setblock 386 92 360 minecraft:light[level=12]
setblock 387 92 323 minecraft:polished_deepslate
fill 388 92 323 391 92 323 minecraft:gray_concrete
setblock 390 92 324 minecraft:gray_concrete
setblock 391 92 324 minecraft:polished_deepslate
fill 391 92 359 392 104 359 minecraft:light_blue_concrete
setblock 392 92 323 minecraft:polished_deepslate
fill 392 92 324 392 94 325 minecraft:gray_concrete
fill 392 92 360 392 104 361 minecraft:light_blue_concrete
fill 393 92 323 393 95 323 minecraft:gray_concrete
setblock 393 92 332 minecraft:light[level=12]
setblock 393 92 339 minecraft:light[level=12]
setblock 393 92 346 minecraft:light[level=12]
setblock 393 92 353 minecraft:light[level=12]
fill 393 92 354 399 104 354 minecraft:light_blue_concrete
fill 393 92 361 393 102 362 minecraft:light_blue_concrete
fill 393 92 363 393 95 363 minecraft:gray_concrete
setblock 394 92 326 minecraft:polished_deepslate
fill 394 92 362 396 93 362 minecraft:light_blue_concrete
setblock 395 92 324 minecraft:gray_concrete
setblock 395 92 325 minecraft:polished_deepslate
fill 395 92 326 395 95 326 minecraft:gray_concrete
fill 395 92 353 397 104 353 minecraft:light_blue_concrete
setblock 396 92 324 minecraft:polished_deepslate
fill 396 92 325 396 95 325 minecraft:gray_concrete
fill 396 92 327 397 92 327 minecraft:gray_concrete
setblock 397 92 323 minecraft:polished_deepslate
fill 397 92 324 397 95 324 minecraft:gray_concrete
setblock 397 92 363 minecraft:polished_deepslate
fill 398 92 323 398 95 323 minecraft:gray_concrete
setblock 398 92 327 minecraft:polished_deepslate
setblock 398 92 362 minecraft:polished_deepslate
fill 398 92 363 398 95 363 minecraft:gray_concrete
fill 399 92 322 399 122 322 minecraft:black_concrete
setblock 399 92 326 minecraft:polished_deepslate
fill 399 92 327 400 93 327 minecraft:gray_concrete
fill 399 92 355 400 104 355 minecraft:light_blue_concrete
fill 399 92 361 400 104 361 minecraft:light_blue_concrete
fill 399 92 362 399 95 362 minecraft:gray_concrete
setblock 400 92 325 minecraft:polished_deepslate
fill 400 92 326 400 95 326 minecraft:gray_concrete
setblock 400 92 332 minecraft:light[level=12]
setblock 400 92 339 minecraft:light[level=12]
setblock 400 92 346 minecraft:light[level=12]
setblock 400 92 353 minecraft:light[level=12]
fill 400 92 356 400 104 360 minecraft:light_blue_concrete
setblock 401 92 324 minecraft:polished_deepslate
fill 401 92 325 401 95 325 minecraft:gray_concrete
fill 401 92 357 401 104 359 minecraft:light_blue_concrete
setblock 402 92 323 minecraft:polished_deepslate
fill 402 92 324 402 95 324 minecraft:gray_concrete
setblock 402 92 363 minecraft:polished_deepslate
fill 403 92 323 403 95 323 minecraft:gray_concrete
fill 403 92 363 403 95 363 minecraft:gray_concrete
setblock 405 92 325 minecraft:polished_deepslate
setblock 406 92 324 minecraft:polished_deepslate
setblock 407 92 323 minecraft:polished_deepslate
fill 407 92 324 410 92 324 minecraft:gray_concrete
setblock 407 92 325 minecraft:light[level=12]
setblock 407 92 332 minecraft:light[level=12]
fill 407 92 336 407 96 337 minecraft:black_concrete
setblock 407 92 339 minecraft:light[level=12]
setblock 407 92 346 minecraft:light[level=12]
setblock 407 92 353 minecraft:light[level=12]
setblock 407 92 360 minecraft:light[level=12]
setblock 407 92 363 minecraft:polished_deepslate
fill 408 92 323 408 95 323 minecraft:gray_concrete
fill 408 92 334 408 96 334 minecraft:black_concrete
fill 408 92 363 408 95 363 minecraft:gray_concrete
fill 409 92 339 411 96 339 minecraft:black_concrete
setblock 411 92 324 minecraft:polished_deepslate
fill 411 92 364 411 122 364 minecraft:black_concrete
setblock 412 92 323 minecraft:polished_deepslate
fill 412 92 324 412 95 324 minecraft:gray_concrete
fill 412 92 334 412 96 334 minecraft:black_concrete
setblock 412 92 362 minecraft:gray_concrete
setblock 412 92 363 minecraft:polished_deepslate
setblock 412 92 364 minecraft:light_blue_stained_glass
fill 413 92 323 413 95 323 minecraft:gray_concrete
fill 413 92 336 413 96 337 minecraft:black_concrete
fill 413 92 344 413 101 344 minecraft:polished_deepslate
setblock 413 92 362 minecraft:polished_deepslate
fill 413 92 363 413 95 363 minecraft:gray_concrete
fill 413 92 364 416 108 364 minecraft:black_concrete
setblock 414 92 325 minecraft:gray_concrete
setblock 414 92 332 minecraft:light[level=12]
setblock 414 92 339 minecraft:light[level=12]
setblock 414 92 346 minecraft:light[level=12]
setblock 414 92 353 minecraft:light[level=12]
setblock 414 92 360 minecraft:light[level=12]
fill 414 92 362 414 95 362 minecraft:gray_concrete
setblock 415 92 325 minecraft:polished_deepslate
fill 415 92 326 415 94 327 minecraft:gray_concrete
setblock 415 92 345 minecraft:polished_deepslate
fill 415 92 346 415 92 349 minecraft:gray_concrete
setblock 415 92 350 minecraft:polished_deepslate
fill 415 92 351 415 95 351 minecraft:gray_concrete
fill 415 92 353 415 92 354 minecraft:gray_concrete
setblock 415 92 355 minecraft:polished_deepslate
setblock 416 92 324 minecraft:polished_deepslate
fill 416 92 325 416 95 325 minecraft:gray_concrete
setblock 416 92 329 minecraft:polished_deepslate
fill 416 92 330 416 95 330 minecraft:gray_concrete
fill 416 92 342 416 92 343 minecraft:gray_concrete
setblock 416 92 344 minecraft:polished_deepslate
fill 416 92 345 416 92 348 minecraft:gray_concrete
setblock 416 92 349 minecraft:polished_deepslate
fill 416 92 350 416 95 350 minecraft:gray_concrete
setblock 416 92 353 minecraft:gray_concrete
setblock 416 92 354 minecraft:polished_deepslate
fill 416 92 355 416 95 355 minecraft:gray_concrete
setblock 416 92 359 minecraft:polished_deepslate
fill 416 92 360 416 95 360 minecraft:gray_concrete
setblock 417 92 323 minecraft:polished_deepslate
fill 417 92 324 417 95 324 minecraft:gray_concrete
setblock 417 92 328 minecraft:polished_deepslate
fill 417 92 329 417 95 329 minecraft:gray_concrete
setblock 417 92 332 minecraft:gray_concrete
setblock 417 92 333 minecraft:polished_deepslate
fill 417 92 334 417 92 337 minecraft:gray_concrete
setblock 417 92 338 minecraft:polished_deepslate
fill 417 92 339 417 95 339 minecraft:gray_concrete
setblock 417 92 343 minecraft:polished_deepslate
fill 417 92 344 417 95 344 minecraft:gray_concrete
setblock 417 92 348 minecraft:polished_deepslate
fill 417 92 349 417 95 349 minecraft:gray_concrete
setblock 417 92 353 minecraft:polished_deepslate
fill 417 92 354 417 95 354 minecraft:gray_concrete
setblock 417 92 358 minecraft:polished_deepslate
fill 417 92 359 417 95 359 minecraft:gray_concrete
setblock 417 92 363 minecraft:polished_deepslate
setblock 376 93 335 minecraft:light_blue_stained_glass
fill 376 93 336 376 122 337 minecraft:black_concrete
fill 377 93 323 377 96 323 minecraft:gray_concrete
setblock 377 93 327 minecraft:polished_deepslate
fill 377 93 328 377 93 331 minecraft:gray_concrete
setblock 377 93 332 minecraft:polished_deepslate
fill 377 93 333 377 96 333 minecraft:gray_concrete
setblock 377 93 337 minecraft:polished_deepslate
fill 377 93 338 377 96 338 minecraft:gray_concrete
setblock 377 93 342 minecraft:polished_deepslate
fill 377 93 343 377 96 343 minecraft:gray_concrete
setblock 377 93 347 minecraft:polished_deepslate
fill 377 93 348 377 93 351 minecraft:gray_concrete
setblock 377 93 352 minecraft:polished_deepslate
fill 377 93 353 377 96 353 minecraft:gray_concrete
setblock 377 93 356 minecraft:gray_concrete
setblock 377 93 357 minecraft:polished_deepslate
fill 377 93 358 377 96 358 minecraft:gray_concrete
setblock 377 93 362 minecraft:polished_deepslate
fill 377 93 363 377 96 363 minecraft:gray_concrete
setblock 378 93 326 minecraft:polished_deepslate
fill 378 93 327 378 93 330 minecraft:gray_concrete
setblock 378 93 331 minecraft:polished_deepslate
fill 378 93 332 378 96 332 minecraft:gray_concrete
setblock 378 93 335 minecraft:gray_concrete
setblock 378 93 336 minecraft:polished_deepslate
fill 378 93 337 378 96 337 minecraft:gray_concrete
setblock 378 93 340 minecraft:gray_concrete
setblock 378 93 341 minecraft:polished_deepslate
fill 378 93 342 378 96 342 minecraft:gray_concrete
setblock 378 93 346 minecraft:polished_deepslate
fill 378 93 347 378 96 347 minecraft:gray_concrete
setblock 378 93 351 minecraft:polished_deepslate
fill 378 93 352 378 96 352 minecraft:gray_concrete
setblock 378 93 356 minecraft:polished_deepslate
fill 378 93 357 378 96 357 minecraft:gray_concrete
setblock 379 93 325 minecraft:polished_deepslate
fill 379 93 326 379 94 326 minecraft:gray_concrete
setblock 379 93 330 minecraft:polished_deepslate
fill 379 93 331 379 96 331 minecraft:gray_concrete
setblock 379 93 340 minecraft:polished_deepslate
fill 379 93 341 379 94 341 minecraft:gray_concrete
setblock 379 93 345 minecraft:polished_deepslate
fill 379 93 346 379 96 346 minecraft:gray_concrete
setblock 379 93 350 minecraft:polished_deepslate
fill 379 93 351 379 96 351 minecraft:gray_concrete
setblock 379 93 355 minecraft:polished_deepslate
setblock 380 93 324 minecraft:polished_deepslate
setblock 380 93 344 minecraft:polished_deepslate
fill 380 93 345 380 94 345 minecraft:gray_concrete
setblock 380 93 349 minecraft:polished_deepslate
fill 380 93 350 380 95 350 minecraft:gray_concrete
setblock 380 93 352 minecraft:gray_concrete
setblock 381 93 323 minecraft:polished_deepslate
fill 381 93 324 381 94 324 minecraft:gray_concrete
fill 381 93 349 381 94 349 minecraft:gray_wool
setblock 381 93 363 minecraft:polished_deepslate
fill 382 93 323 382 95 323 minecraft:gray_concrete
setblock 386 93 323 minecraft:polished_deepslate
fill 387 93 323 390 93 323 minecraft:gray_concrete
setblock 389 93 324 minecraft:gray_concrete
setblock 390 93 324 minecraft:polished_deepslate
fill 390 93 359 390 103 359 minecraft:light_blue_concrete
setblock 391 93 323 minecraft:polished_deepslate
fill 391 93 324 391 95 325 minecraft:gray_concrete
fill 391 93 360 391 103 361 minecraft:light_blue_concrete
fill 392 93 323 392 96 323 minecraft:gray_concrete
fill 392 93 354 392 103 354 minecraft:light_blue_concrete
fill 392 93 362 392 102 362 minecraft:light_blue_concrete
setblock 393 93 326 minecraft:polished_deepslate
fill 393 93 353 394 103 353 minecraft:light_blue_concrete
setblock 394 93 324 minecraft:gray_concrete
setblock 394 93 325 minecraft:polished_deepslate
fill 394 93 326 394 96 326 minecraft:gray_concrete
setblock 395 93 324 minecraft:polished_deepslate
fill 395 93 325 395 96 325 minecraft:gray_concrete
fill 395 93 327 396 93 327 minecraft:gray_concrete
fill 395 93 352 397 103 352 minecraft:light_blue_concrete
setblock 396 93 323 minecraft:polished_deepslate
fill 396 93 324 396 96 324 minecraft:gray_concrete
setblock 396 93 363 minecraft:polished_deepslate
fill 397 93 323 397 96 323 minecraft:gray_concrete
setblock 397 93 327 minecraft:polished_deepslate
setblock 397 93 362 minecraft:polished_deepslate
fill 397 93 363 397 96 363 minecraft:gray_concrete
setblock 398 93 326 minecraft:polished_deepslate
fill 398 93 327 398 95 327 minecraft:gray_concrete
fill 398 93 353 399 103 353 minecraft:light_blue_concrete
fill 398 93 362 398 95 362 minecraft:gray_concrete
setblock 399 93 325 minecraft:polished_deepslate
fill 399 93 326 399 96 326 minecraft:gray_concrete
fill 400 93 322 403 97 322 minecraft:black_concrete
setblock 400 93 324 minecraft:polished_deepslate
fill 400 93 325 400 96 325 minecraft:gray_concrete
fill 400 93 354 400 103 354 minecraft:light_blue_concrete
setblock 401 93 323 minecraft:polished_deepslate
fill 401 93 324 401 96 324 minecraft:gray_concrete
fill 401 93 355 401 103 356 minecraft:light_blue_concrete
fill 401 93 360 401 103 361 minecraft:light_blue_concrete
setblock 401 93 363 minecraft:polished_deepslate
fill 402 93 323 402 96 323 minecraft:gray_concrete
setblock 402 93 326 minecraft:gray_concrete
fill 402 93 357 402 103 359 minecraft:light_blue_concrete
fill 402 93 363 402 96 363 minecraft:gray_concrete
setblock 404 93 322 minecraft:light_blue_stained_glass
setblock 404 93 325 minecraft:polished_deepslate
fill 405 93 322 406 101 322 minecraft:black_concrete
setblock 405 93 324 minecraft:polished_deepslate
setblock 405 93 325 minecraft:gray_concrete
setblock 406 93 323 minecraft:polished_deepslate
fill 406 93 324 409 93 324 minecraft:gray_concrete
setblock 406 93 363 minecraft:polished_deepslate
setblock 407 93 322 minecraft:light_blue_stained_glass
fill 407 93 323 407 96 323 minecraft:gray_concrete
fill 407 93 335 407 96 335 minecraft:black_concrete
fill 407 93 338 407 96 338 minecraft:black_concrete
fill 407 93 363 407 95 363 minecraft:gray_concrete
fill 408 93 339 408 96 339 minecraft:black_concrete
fill 409 93 333 411 96 333 minecraft:black_concrete
setblock 410 93 324 minecraft:polished_deepslate
setblock 411 93 323 minecraft:polished_deepslate
fill 411 93 324 411 95 324 minecraft:gray_concrete
setblock 411 93 363 minecraft:polished_deepslate
fill 412 93 323 412 96 323 minecraft:gray_concrete
fill 412 93 339 412 96 339 minecraft:black_concrete
setblock 412 93 362 minecraft:polished_deepslate
fill 412 93 363 412 96 363 minecraft:gray_concrete
fill 412 93 364 412 98 364 minecraft:black_concrete
fill 413 93 335 413 96 335 minecraft:black_concrete
fill 413 93 338 413 96 338 minecraft:black_concrete
fill 413 93 362 413 96 362 minecraft:gray_concrete
setblock 414 93 322 minecraft:light_blue_stained_glass
setblock 414 93 325 minecraft:polished_deepslate
setblock 414 93 349 minecraft:gray_concrete
setblock 414 93 350 minecraft:polished_deepslate
fill 414 93 351 414 96 351 minecraft:gray_concrete
setblock 415 93 324 minecraft:polished_deepslate
fill 415 93 325 415 94 325 minecraft:gray_concrete
setblock 415 93 328 minecraft:gray_concrete
fill 415 93 345 415 93 348 minecraft:gray_concrete
setblock 415 93 349 minecraft:polished_deepslate
fill 415 93 350 415 96 350 minecraft:gray_concrete
setblock 415 93 353 minecraft:gray_concrete
setblock 415 93 354 minecraft:polished_deepslate
fill 415 93 355 415 94 357 minecraft:gray_concrete
setblock 416 93 323 minecraft:polished_deepslate
fill 416 93 324 416 96 324 minecraft:gray_concrete
setblock 416 93 327 minecraft:gray_concrete
setblock 416 93 328 minecraft:polished_deepslate
fill 416 93 329 416 96 329 minecraft:gray_concrete
fill 416 93 331 416 93 332 minecraft:gray_concrete
setblock 416 93 342 minecraft:gray_concrete
setblock 416 93 343 minecraft:polished_deepslate
fill 416 93 344 416 93 347 minecraft:gray_concrete
setblock 416 93 348 minecraft:polished_deepslate
fill 416 93 349 416 96 349 minecraft:gray_concrete
setblock 416 93 353 minecraft:polished_deepslate
fill 416 93 354 416 96 354 minecraft:gray_concrete
setblock 416 93 357 minecraft:gray_concrete
setblock 416 93 358 minecraft:polished_deepslate
fill 416 93 359 416 96 359 minecraft:gray_concrete
setblock 416 93 363 minecraft:polished_deepslate
fill 417 93 323 417 96 323 minecraft:gray_concrete
setblock 417 93 327 minecraft:polished_deepslate
fill 417 93 328 417 96 328 minecraft:gray_concrete
setblock 417 93 332 minecraft:polished_deepslate
fill 417 93 333 417 93 336 minecraft:gray_concrete
setblock 417 93 337 minecraft:polished_deepslate
fill 417 93 338 417 96 338 minecraft:gray_concrete
setblock 417 93 342 minecraft:polished_deepslate
fill 417 93 343 417 96 343 minecraft:gray_concrete
setblock 417 93 347 minecraft:polished_deepslate
fill 417 93 348 417 96 348 minecraft:gray_concrete
setblock 417 93 352 minecraft:polished_deepslate
fill 417 93 353 417 96 353 minecraft:gray_concrete
setblock 417 93 357 minecraft:polished_deepslate
fill 417 93 358 417 96 358 minecraft:gray_concrete
setblock 417 93 362 minecraft:polished_deepslate
fill 417 93 363 417 96 363 minecraft:gray_concrete
setblock 418 93 362 minecraft:light_blue_stained_glass
fill 376 94 335 376 120 335 minecraft:black_concrete
setblock 377 94 326 minecraft:polished_deepslate
fill 377 94 327 377 94 330 minecraft:gray_concrete
setblock 377 94 331 minecraft:polished_deepslate
fill 377 94 332 377 97 332 minecraft:gray_concrete
setblock 377 94 336 minecraft:polished_deepslate
fill 377 94 337 377 97 337 minecraft:gray_concrete
setblock 377 94 341 minecraft:polished_deepslate
fill 377 94 342 377 97 342 minecraft:gray_concrete
setblock 377 94 346 minecraft:polished_deepslate
fill 377 94 347 377 94 350 minecraft:gray_concrete
setblock 377 94 351 minecraft:polished_deepslate
fill 377 94 352 377 97 352 minecraft:gray_concrete
setblock 377 94 356 minecraft:polished_deepslate
fill 377 94 357 377 97 357 minecraft:gray_concrete
setblock 377 94 361 minecraft:polished_deepslate
fill 377 94 362 377 96 362 minecraft:gray_concrete
setblock 378 94 325 minecraft:polished_deepslate
fill 378 94 326 378 94 329 minecraft:gray_concrete
setblock 378 94 330 minecraft:polished_deepslate
fill 378 94 331 378 97 331 minecraft:gray_concrete
setblock 378 94 335 minecraft:polished_deepslate
fill 378 94 336 378 97 336 minecraft:gray_concrete
setblock 378 94 340 minecraft:polished_deepslate
fill 378 94 341 378 97 341 minecraft:gray_concrete
setblock 378 94 345 minecraft:polished_deepslate
fill 378 94 346 378 97 346 minecraft:gray_concrete
setblock 378 94 350 minecraft:polished_deepslate
fill 378 94 351 378 97 351 minecraft:gray_concrete
setblock 378 94 354 minecraft:gray_concrete
setblock 378 94 355 minecraft:polished_deepslate
fill 378 94 356 378 97 356 minecraft:gray_concrete
setblock 379 94 324 minecraft:polished_deepslate
setblock 379 94 325 minecraft:light[level=13]
fill 379 94 327 379 94 328 minecraft:gray_concrete
setblock 379 94 329 minecraft:polished_deepslate
fill 379 94 330 379 97 330 minecraft:gray_concrete
fill 379 94 332 379 94 333 minecraft:gray_concrete
setblock 379 94 344 minecraft:polished_deepslate
fill 379 94 345 379 96 345 minecraft:gray_concrete
setblock 379 94 349 minecraft:polished_deepslate
fill 379 94 350 379 97 350 minecraft:gray_concrete
setblock 379 94 354 minecraft:polished_deepslate
setblock 379 94 355 minecraft:gray_concrete
setblock 379 94 357 minecraft:light[level=13]
setblock 380 94 323 minecraft:polished_deepslate
setblock 380 94 324 minecraft:gray_concrete
fill 380 94 341 380 95 342 minecraft:white_wool
setblock 380 94 348 minecraft:polished_deepslate
fill 380 94 349 380 95 349 minecraft:gray_concrete
setblock 380 94 363 minecraft:polished_deepslate
fill 381 94 323 381 95 323 minecraft:gray_concrete
fill 387 94 323 389 94 323 minecraft:gray_concrete
setblock 387 94 325 minecraft:light[level=13]
setblock 387 94 333 minecraft:light[level=13]
setblock 387 94 341 minecraft:light[level=13]
setblock 387 94 349 minecraft:light[level=13]
setblock 387 94 357 minecraft:light[level=13]
setblock 389 94 324 minecraft:polished_deepslate
setblock 390 94 323 minecraft:polished_deepslate
fill 390 94 324 390 97 324 minecraft:gray_concrete
fill 390 94 355 390 102 355 minecraft:light_blue_concrete
fill 390 94 360 390 102 361 minecraft:light_blue_concrete
fill 391 94 323 391 97 323 minecraft:gray_concrete
fill 391 94 354 391 102 354 minecraft:light_blue_concrete
fill 391 94 362 391 102 362 minecraft:light_blue_concrete
setblock 392 94 326 minecraft:polished_deepslate
fill 392 94 353 392 102 353 minecraft:light_blue_concrete
fill 392 94 363 392 100 363 minecraft:light_blue_concrete
setblock 393 94 324 minecraft:gray_concrete
setblock 393 94 325 minecraft:polished_deepslate
fill 393 94 326 393 97 326 minecraft:gray_concrete
fill 393 94 352 394 102 352 minecraft:light_blue_concrete
setblock 394 94 324 minecraft:polished_deepslate
fill 394 94 325 394 97 325 minecraft:gray_concrete
fill 394 94 362 395 102 362 minecraft:light_blue_concrete
setblock 395 94 323 minecraft:polished_deepslate
fill 395 94 324 395 97 324 minecraft:gray_concrete
setblock 395 94 327 minecraft:gray_concrete
setblock 395 94 333 minecraft:light[level=13]
setblock 395 94 341 minecraft:light[level=13]
setblock 395 94 349 minecraft:light[level=13]
setblock 395 94 363 minecraft:polished_deepslate
fill 396 94 323 396 97 323 minecraft:gray_concrete
setblock 396 94 327 minecraft:polished_deepslate
setblock 396 94 362 minecraft:polished_deepslate
fill 396 94 363 396 97 363 minecraft:gray_concrete
setblock 397 94 326 minecraft:polished_deepslate
fill 397 94 327 397 95 327 minecraft:gray_concrete
fill 397 94 362 397 95 362 minecraft:gray_concrete
setblock 398 94 325 minecraft:polished_deepslate
fill 398 94 326 398 96 326 minecraft:gray_concrete
fill 398 94 352 399 102 352 minecraft:light_blue_concrete
setblock 399 94 324 minecraft:polished_deepslate
fill 399 94 325 399 97 325 minecraft:gray_concrete
setblock 399 94 327 minecraft:gray_concrete
setblock 400 94 323 minecraft:polished_deepslate
fill 400 94 324 400 97 324 minecraft:gray_concrete
fill 400 94 353 400 102 353 minecraft:light_blue_concrete
setblock 400 94 363 minecraft:polished_deepslate
fill 401 94 323 401 97 323 minecraft:gray_concrete
fill 401 94 354 401 102 354 minecraft:light_blue_concrete
fill 401 94 362 401 102 362 minecraft:light_blue_concrete
fill 401 94 363 401 97 363 minecraft:gray_concrete
setblock 402 94 326 minecraft:polished_deepslate
fill 402 94 355 402 102 356 minecraft:light_blue_concrete
fill 402 94 360 402 102 361 minecraft:light_blue_concrete
setblock 403 94 325 minecraft:polished_deepslate
setblock 403 94 333 minecraft:light[level=13]
setblock 403 94 341 minecraft:light[level=13]
setblock 403 94 349 minecraft:light[level=13]
setblock 403 94 357 minecraft:light[level=13]
fill 404 94 322 404 122 322 minecraft:black_concrete
setblock 404 94 324 minecraft:polished_deepslate
setblock 404 94 325 minecraft:gray_concrete
setblock 405 94 323 minecraft:polished_deepslate
fill 405 94 324 408 94 324 minecraft:gray_concrete
setblock 405 94 363 minecraft:polished_deepslate
fill 406 94 323 406 96 323 minecraft:gray_concrete
fill 406 94 336 406 96 337 minecraft:black_concrete
fill 406 94 363 406 95 363 minecraft:gray_concrete
fill 407 94 322 407 119 322 minecraft:black_concrete
fill 407 94 334 407 96 334 minecraft:black_concrete
fill 407 94 339 407 96 339 minecraft:black_concrete
fill 408 94 333 408 96 333 minecraft:black_concrete
setblock 409 94 324 minecraft:polished_deepslate
fill 409 94 340 411 96 340 minecraft:black_concrete
setblock 410 94 323 minecraft:polished_deepslate
fill 410 94 324 410 95 324 minecraft:gray_concrete
setblock 410 94 363 minecraft:polished_deepslate
fill 411 94 323 411 97 323 minecraft:gray_concrete
setblock 411 94 325 minecraft:light[level=13]
setblock 411 94 341 minecraft:light[level=13]
setblock 411 94 349 minecraft:light[level=13]
setblock 411 94 357 minecraft:light[level=13]
fill 411 94 363 411 97 363 minecraft:gray_concrete
fill 412 94 333 412 96 333 minecraft:black_concrete
fill 412 94 362 412 97 362 minecraft:gray_concrete
fill 413 94 334 413 96 334 minecraft:black_concrete
fill 413 94 339 413 96 339 minecraft:black_concrete
fill 414 94 322 414 110 322 minecraft:black_concrete
setblock 414 94 324 minecraft:polished_deepslate
setblock 414 94 325 minecraft:gray_concrete
fill 414 94 336 414 96 337 minecraft:black_concrete
setblock 414 94 348 minecraft:gray_concrete
setblock 414 94 349 minecraft:polished_deepslate
fill 414 94 350 414 97 350 minecraft:gray_concrete
fill 414 94 352 414 94 353 minecraft:gray_concrete
setblock 415 94 323 minecraft:polished_deepslate
fill 415 94 324 415 96 324 minecraft:gray_concrete
setblock 415 94 328 minecraft:polished_deepslate
fill 415 94 329 415 95 329 minecraft:gray_concrete
fill 415 94 345 415 94 347 minecraft:gray_concrete
setblock 415 94 348 minecraft:polished_deepslate
fill 415 94 349 415 97 349 minecraft:gray_concrete
setblock 415 94 352 minecraft:gray_concrete
setblock 415 94 353 minecraft:polished_deepslate
fill 415 94 354 415 97 354 minecraft:gray_concrete
setblock 415 94 358 minecraft:polished_deepslate
fill 415 94 359 415 97 359 minecraft:gray_concrete
setblock 415 94 363 minecraft:polished_deepslate
fill 416 94 323 416 97 323 minecraft:gray_concrete
setblock 416 94 327 minecraft:polished_deepslate
fill 416 94 328 416 97 328 minecraft:gray_concrete
setblock 416 94 331 minecraft:gray_concrete
setblock 416 94 332 minecraft:polished_deepslate
fill 416 94 333 417 96 333 minecraft:gray_concrete
setblock 416 94 342 minecraft:polished_deepslate
fill 416 94 343 416 94 346 minecraft:gray_concrete
setblock 416 94 347 minecraft:polished_deepslate
fill 416 94 348 416 97 348 minecraft:gray_concrete
setblock 416 94 352 minecraft:polished_deepslate
fill 416 94 353 416 97 353 minecraft:gray_concrete
setblock 416 94 357 minecraft:polished_deepslate
fill 416 94 358 416 97 358 minecraft:gray_concrete
setblock 416 94 362 minecraft:polished_deepslate
fill 416 94 363 416 97 363 minecraft:gray_concrete
setblock 417 94 326 minecraft:polished_deepslate
fill 417 94 327 417 97 327 minecraft:gray_concrete
setblock 417 94 331 minecraft:polished_deepslate
fill 417 94 332 417 97 332 minecraft:gray_concrete
fill 417 94 334 417 94 335 minecraft:gray_concrete
setblock 417 94 336 minecraft:polished_deepslate
fill 417 94 337 417 97 337 minecraft:gray_concrete
setblock 417 94 341 minecraft:polished_deepslate
fill 417 94 342 417 97 342 minecraft:gray_concrete
setblock 417 94 346 minecraft:polished_deepslate
fill 417 94 347 417 97 347 minecraft:gray_concrete
setblock 417 94 351 minecraft:polished_deepslate
fill 417 94 352 417 97 352 minecraft:gray_concrete
setblock 417 94 356 minecraft:polished_deepslate
fill 417 94 357 417 97 357 minecraft:gray_concrete
setblock 417 94 361 minecraft:polished_deepslate
fill 417 94 362 417 97 362 minecraft:gray_concrete
fill 418 94 362 418 107 362 minecraft:black_concrete
setblock 377 95 325 minecraft:polished_deepslate
fill 377 95 326 377 95 329 minecraft:gray_concrete
setblock 377 95 330 minecraft:polished_deepslate
fill 377 95 331 377 98 331 minecraft:gray_concrete
setblock 377 95 334 minecraft:gray_concrete
setblock 377 95 335 minecraft:polished_deepslate
fill 377 95 336 377 98 336 minecraft:gray_concrete
setblock 377 95 340 minecraft:polished_deepslate
fill 377 95 341 377 98 341 minecraft:gray_concrete
setblock 377 95 345 minecraft:polished_deepslate
fill 377 95 346 377 95 349 minecraft:gray_concrete
setblock 377 95 350 minecraft:polished_deepslate
fill 377 95 351 377 98 351 minecraft:gray_concrete
setblock 377 95 355 minecraft:polished_deepslate
fill 377 95 356 377 98 356 minecraft:gray_concrete
setblock 377 95 360 minecraft:polished_deepslate
fill 377 95 361 377 96 361 minecraft:gray_concrete
setblock 378 95 324 minecraft:polished_deepslate
fill 378 95 325 378 95 328 minecraft:gray_concrete
setblock 378 95 329 minecraft:polished_deepslate
fill 378 95 330 378 98 330 minecraft:gray_concrete
setblock 378 95 334 minecraft:polished_deepslate
fill 378 95 335 378 98 335 minecraft:gray_concrete
setblock 378 95 339 minecraft:polished_deepslate
fill 378 95 340 378 97 340 minecraft:gray_concrete
setblock 378 95 344 minecraft:polished_deepslate
fill 378 95 345 378 98 345 minecraft:gray_concrete
setblock 378 95 349 minecraft:polished_deepslate
fill 378 95 350 378 98 350 minecraft:gray_concrete
setblock 378 95 354 minecraft:polished_deepslate
fill 378 95 355 378 98 355 minecraft:gray_concrete
setblock 379 95 323 minecraft:polished_deepslate
setblock 379 95 324 minecraft:gray_concrete
setblock 379 95 327 minecraft:gray_concrete
setblock 379 95 328 minecraft:polished_deepslate
fill 379 95 329 379 96 329 minecraft:gray_concrete
setblock 379 95 332 minecraft:gray_concrete
setblock 379 95 333 minecraft:polished_deepslate
setblock 379 95 341 minecraft:white_wool
setblock 379 95 343 minecraft:polished_deepslate
fill 379 95 344 379 96 344 minecraft:gray_concrete
setblock 379 95 348 minecraft:polished_deepslate
fill 379 95 349 379 97 349 minecraft:gray_concrete
setblock 379 95 353 minecraft:polished_deepslate
fill 379 95 354 379 96 354 minecraft:gray_concrete
setblock 380 95 323 minecraft:gray_concrete
setblock 380 95 347 minecraft:polished_deepslate
setblock 380 95 348 minecraft:gray_concrete
fill 382 95 324 382 98 324 minecraft:light_blue_stained_glass
fill 383 95 323 383 98 323 minecraft:light_blue_stained_glass
fill 386 95 322 386 107 322 minecraft:black_concrete
setblock 387 95 322 minecraft:light_blue_stained_glass
fill 388 95 322 390 120 322 minecraft:black_concrete
setblock 388 95 323 minecraft:gray_concrete
setblock 389 95 323 minecraft:polished_deepslate
fill 389 95 356 389 101 360 minecraft:light_blue_concrete
fill 390 95 323 390 98 323 minecraft:gray_concrete
fill 390 95 354 390 101 354 minecraft:light_blue_concrete
fill 390 95 362 390 101 362 minecraft:light_blue_concrete
fill 391 95 353 391 101 353 minecraft:light_blue_concrete
fill 391 95 363 391 101 363 minecraft:light_blue_concrete
setblock 392 95 324 minecraft:gray_concrete
setblock 392 95 325 minecraft:polished_deepslate
setblock 392 95 326 minecraft:gray_concrete
fill 392 95 352 392 101 352 minecraft:light_blue_concrete
setblock 393 95 324 minecraft:polished_deepslate
fill 393 95 325 393 98 325 minecraft:gray_concrete
setblock 394 95 323 minecraft:polished_deepslate
fill 394 95 324 394 98 324 minecraft:gray_concrete
fill 394 95 351 398 101 351 minecraft:light_blue_concrete
setblock 394 95 363 minecraft:polished_deepslate
fill 395 95 323 395 98 323 minecraft:gray_concrete
setblock 395 95 327 minecraft:polished_deepslate
fill 395 95 363 395 98 363 minecraft:gray_concrete
setblock 396 95 326 minecraft:polished_deepslate
setblock 396 95 327 minecraft:gray_concrete
fill 396 95 362 396 103 362 minecraft:light_blue_concrete
setblock 397 95 325 minecraft:polished_deepslate
fill 397 95 326 397 97 326 minecraft:gray_concrete
setblock 398 95 324 minecraft:polished_deepslate
fill 398 95 325 398 98 325 minecraft:gray_concrete
setblock 399 95 323 minecraft:polished_deepslate
fill 399 95 324 399 98 324 minecraft:gray_concrete
setblock 399 95 363 minecraft:polished_deepslate
fill 400 95 323 400 98 323 minecraft:gray_concrete
fill 400 95 352 400 101 352 minecraft:light_blue_concrete
fill 400 95 362 400 103 362 minecraft:light_blue_concrete
fill 400 95 363 400 98 363 minecraft:gray_concrete
fill 401 95 353 401 101 353 minecraft:light_blue_concrete
setblock 402 95 325 minecraft:polished_deepslate
fill 402 95 354 402 101 354 minecraft:light_blue_concrete
fill 402 95 362 402 101 362 minecraft:light_blue_concrete
setblock 403 95 324 minecraft:polished_deepslate
setblock 403 95 325 minecraft:gray_concrete
fill 403 95 356 403 101 360 minecraft:light_blue_concrete
setblock 404 95 323 minecraft:polished_deepslate
fill 404 95 324 405 95 324 minecraft:gray_concrete
setblock 404 95 363 minecraft:polished_deepslate
fill 405 95 323 405 96 323 minecraft:gray_concrete
setblock 405 95 363 minecraft:gray_concrete
fill 406 95 335 406 96 335 minecraft:black_concrete
fill 406 95 338 406 96 338 minecraft:black_concrete
fill 407 95 333 407 96 333 minecraft:black_concrete
fill 408 95 340 408 96 340 minecraft:black_concrete
setblock 409 95 323 minecraft:polished_deepslate
fill 409 95 332 411 96 332 minecraft:black_concrete
setblock 409 95 363 minecraft:polished_deepslate
fill 410 95 323 410 97 323 minecraft:gray_concrete
fill 410 95 363 410 98 363 minecraft:gray_concrete
fill 412 95 340 412 96 340 minecraft:black_concrete
setblock 413 95 324 minecraft:polished_deepslate
fill 413 95 333 413 96 333 minecraft:black_concrete
setblock 414 95 323 minecraft:polished_deepslate
fill 414 95 324 414 96 324 minecraft:gray_concrete
fill 414 95 334 414 96 335 minecraft:black_concrete
fill 414 95 338 414 96 338 minecraft:black_concrete
setblock 414 95 348 minecraft:polished_deepslate
fill 414 95 349 414 97 349 minecraft:gray_concrete
setblock 414 95 352 minecraft:gray_concrete
setblock 414 95 353 minecraft:polished_deepslate
fill 414 95 354 414 98 354 minecraft:gray_concrete
setblock 414 95 363 minecraft:polished_deepslate
fill 415 95 323 415 98 323 minecraft:gray_concrete
setblock 415 95 326 minecraft:gray_concrete
setblock 415 95 327 minecraft:polished_deepslate
setblock 415 95 328 minecraft:gray_concrete
fill 415 95 345 415 95 346 minecraft:gray_concrete
setblock 415 95 347 minecraft:polished_deepslate
fill 415 95 348 415 98 348 minecraft:gray_concrete
setblock 415 95 352 minecraft:polished_deepslate
fill 415 95 353 415 98 353 minecraft:gray_concrete
fill 415 95 355 415 95 356 minecraft:gray_concrete
setblock 415 95 357 minecraft:polished_deepslate
fill 415 95 358 415 98 358 minecraft:gray_concrete
setblock 415 95 362 minecraft:polished_deepslate
fill 415 95 363 415 98 363 minecraft:gray_concrete
setblock 416 95 326 minecraft:polished_deepslate
fill 416 95 327 416 97 327 minecraft:gray_concrete
setblock 416 95 331 minecraft:polished_deepslate
fill 416 95 332 416 98 332 minecraft:gray_concrete
fill 416 95 334 417 95 334 minecraft:gray_concrete
fill 416 95 342 416 95 345 minecraft:gray_concrete
setblock 416 95 346 minecraft:polished_deepslate
fill 416 95 347 416 98 347 minecraft:gray_concrete
setblock 416 95 351 minecraft:polished_deepslate
fill 416 95 352 416 98 352 minecraft:gray_concrete
setblock 416 95 356 minecraft:polished_deepslate
fill 416 95 357 416 98 357 minecraft:gray_concrete
setblock 416 95 361 minecraft:polished_deepslate
fill 416 95 362 416 97 362 minecraft:gray_concrete
setblock 417 95 325 minecraft:polished_deepslate
fill 417 95 326 417 98 326 minecraft:gray_concrete
setblock 417 95 330 minecraft:polished_deepslate
fill 417 95 331 417 98 331 minecraft:gray_concrete
setblock 417 95 335 minecraft:polished_deepslate
fill 417 95 336 417 98 336 minecraft:gray_concrete
setblock 417 95 340 minecraft:polished_deepslate
fill 417 95 341 417 98 341 minecraft:gray_concrete
setblock 417 95 345 minecraft:polished_deepslate
fill 417 95 346 417 98 346 minecraft:gray_concrete
setblock 417 95 350 minecraft:polished_deepslate
fill 417 95 351 417 98 351 minecraft:gray_concrete
setblock 417 95 355 minecraft:polished_deepslate
fill 417 95 356 417 98 356 minecraft:gray_concrete
setblock 417 95 360 minecraft:polished_deepslate
fill 417 95 361 417 98 361 minecraft:gray_concrete
fill 376 96 329 376 122 329 minecraft:black_concrete
setblock 376 96 330 minecraft:light_blue_stained_glass
fill 376 96 331 376 112 334 minecraft:black_concrete
setblock 377 96 324 minecraft:polished_deepslate
fill 377 96 325 377 96 328 minecraft:gray_concrete
setblock 377 96 329 minecraft:polished_deepslate
fill 377 96 330 377 99 330 minecraft:gray_concrete
setblock 377 96 334 minecraft:polished_deepslate
fill 377 96 335 377 99 335 minecraft:gray_concrete
setblock 377 96 339 minecraft:polished_deepslate
fill 377 96 340 377 99 340 minecraft:gray_concrete
setblock 377 96 344 minecraft:polished_deepslate
fill 377 96 345 377 96 348 minecraft:gray_concrete
setblock 377 96 349 minecraft:polished_deepslate
fill 377 96 350 377 99 350 minecraft:gray_concrete
setblock 377 96 354 minecraft:polished_deepslate
fill 377 96 355 377 99 355 minecraft:gray_concrete
setblock 377 96 359 minecraft:polished_deepslate
fill 377 96 360 377 97 360 minecraft:gray_concrete
setblock 378 96 323 minecraft:polished_deepslate
fill 378 96 325 378 96 327 minecraft:gray_concrete
setblock 378 96 328 minecraft:polished_deepslate
fill 378 96 329 378 99 329 minecraft:gray_concrete
setblock 378 96 333 minecraft:polished_deepslate
fill 378 96 334 378 99 334 minecraft:gray_concrete
setblock 378 96 338 minecraft:polished_deepslate
fill 378 96 339 378 98 339 minecraft:gray_concrete
setblock 378 96 343 minecraft:polished_deepslate
fill 378 96 344 378 98 344 minecraft:gray_concrete
setblock 378 96 348 minecraft:polished_deepslate
fill 378 96 349 378 99 349 minecraft:gray_concrete
setblock 378 96 353 minecraft:polished_deepslate
fill 378 96 354 378 99 354 minecraft:gray_concrete
setblock 379 96 323 minecraft:gray_concrete
setblock 379 96 328 minecraft:gray_concrete
setblock 379 96 332 minecraft:polished_deepslate
fill 379 96 333 379 97 333 minecraft:gray_concrete
setblock 379 96 347 minecraft:polished_deepslate
fill 379 96 348 379 97 348 minecraft:gray_concrete
setblock 379 96 352 minecraft:polished_deepslate
fill 379 96 353 379 97 353 minecraft:gray_concrete
fill 381 96 323 381 98 324 minecraft:light_blue_stained_glass
fill 382 96 323 382 98 323 minecraft:light_blue_stained_glass
fill 382 96 325 382 98 325 minecraft:light_blue_stained_glass
fill 383 96 324 383 98 324 minecraft:light_blue_stained_glass
fill 387 96 322 387 122 322 minecraft:black_concrete
fill 389 96 323 389 98 323 minecraft:gray_concrete
fill 389 96 355 389 100 355 minecraft:light_blue_concrete
fill 389 96 361 389 100 361 minecraft:light_blue_concrete
setblock 391 96 324 minecraft:gray_concrete
setblock 391 96 325 minecraft:polished_deepslate
setblock 392 96 324 minecraft:polished_deepslate
fill 392 96 325 392 98 325 minecraft:gray_concrete
setblock 393 96 323 minecraft:polished_deepslate
fill 393 96 324 393 99 324 minecraft:gray_concrete
fill 393 96 351 393 100 351 minecraft:light_blue_concrete
setblock 393 96 363 minecraft:polished_deepslate
fill 394 96 323 394 99 323 minecraft:gray_concrete
fill 394 96 363 394 99 363 minecraft:gray_concrete
setblock 395 96 322 minecraft:light_blue_stained_glass
setblock 395 96 326 minecraft:polished_deepslate
setblock 396 96 325 minecraft:polished_deepslate
fill 396 96 326 396 97 326 minecraft:gray_concrete
setblock 397 96 324 minecraft:polished_deepslate
fill 397 96 325 397 98 325 minecraft:gray_concrete
fill 397 96 362 399 103 362 minecraft:light_blue_concrete
setblock 398 96 323 minecraft:polished_deepslate
fill 398 96 324 398 99 324 minecraft:gray_concrete
setblock 398 96 363 minecraft:polished_deepslate
fill 399 96 323 399 99 323 minecraft:gray_concrete
fill 399 96 351 399 100 351 minecraft:light_blue_concrete
fill 399 96 363 399 98 363 minecraft:gray_concrete
setblock 401 96 325 minecraft:polished_deepslate
fill 401 96 331 401 97 331 minecraft:light_gray_wool
setblock 402 96 324 minecraft:polished_deepslate
fill 402 96 364 406 105 364 minecraft:black_concrete
setblock 403 96 323 minecraft:polished_deepslate
setblock 403 96 324 minecraft:gray_concrete
fill 403 96 355 403 100 355 minecraft:light_blue_concrete
fill 403 96 361 403 100 361 minecraft:light_blue_concrete
setblock 403 96 363 minecraft:polished_deepslate
fill 404 96 323 404 97 323 minecraft:gray_concrete
fill 405 96 336 405 96 337 minecraft:black_concrete
setblock 406 96 334 minecraft:black_concrete
setblock 406 96 339 minecraft:black_concrete
setblock 407 96 340 minecraft:black_concrete
setblock 407 96 364 minecraft:light_blue_stained_glass
setblock 408 96 323 minecraft:polished_deepslate
setblock 408 96 332 minecraft:black_concrete
setblock 408 96 363 minecraft:polished_deepslate
fill 408 96 364 409 122 364 minecraft:black_concrete
setblock 409 96 323 minecraft:gray_concrete
fill 409 96 341 412 96 341 minecraft:black_concrete
fill 409 96 363 409 99 363 minecraft:gray_concrete
setblock 410 96 364 minecraft:light_blue_stained_glass
setblock 412 96 324 minecraft:polished_deepslate
setblock 412 96 332 minecraft:black_concrete
setblock 413 96 323 minecraft:polished_deepslate
setblock 413 96 324 minecraft:gray_concrete
setblock 413 96 340 minecraft:black_concrete
setblock 413 96 363 minecraft:polished_deepslate
fill 414 96 323 414 98 323 minecraft:gray_concrete
setblock 414 96 339 minecraft:black_concrete
setblock 414 96 348 minecraft:gray_concrete
setblock 414 96 352 minecraft:polished_deepslate
fill 414 96 353 414 99 353 minecraft:gray_concrete
fill 414 96 355 415 96 355 minecraft:gray_concrete
setblock 414 96 362 minecraft:polished_deepslate
fill 414 96 363 414 99 363 minecraft:gray_concrete
fill 415 96 336 415 96 337 minecraft:black_concrete
setblock 415 96 345 minecraft:gray_concrete
setblock 415 96 346 minecraft:polished_deepslate
fill 415 96 347 415 98 347 minecraft:gray_concrete
setblock 415 96 351 minecraft:polished_deepslate
fill 415 96 352 415 99 352 minecraft:gray_concrete
setblock 415 96 356 minecraft:polished_deepslate
fill 415 96 357 415 99 357 minecraft:gray_concrete
fill 415 96 362 415 98 362 minecraft:gray_concrete
setblock 416 96 325 minecraft:polished_deepslate
fill 416 96 326 416 97 326 minecraft:gray_concrete
setblock 416 96 330 minecraft:polished_deepslate
fill 416 96 331 416 99 331 minecraft:gray_concrete
setblock 416 96 334 minecraft:gray_concrete
fill 416 96 342 416 96 344 minecraft:gray_concrete
setblock 416 96 345 minecraft:polished_deepslate
fill 416 96 346 416 99 346 minecraft:gray_concrete
setblock 416 96 350 minecraft:polished_deepslate
fill 416 96 351 416 99 351 minecraft:gray_concrete
setblock 416 96 355 minecraft:polished_deepslate
fill 416 96 356 416 99 356 minecraft:gray_concrete
setblock 416 96 360 minecraft:polished_deepslate
fill 416 96 361 416 98 361 minecraft:gray_concrete
setblock 417 96 324 minecraft:polished_deepslate
fill 417 96 325 417 98 325 minecraft:gray_concrete
setblock 417 96 329 minecraft:polished_deepslate
fill 417 96 330 417 99 330 minecraft:gray_concrete
setblock 417 96 334 minecraft:polished_deepslate
fill 417 96 335 417 99 335 minecraft:gray_concrete
setblock 417 96 339 minecraft:polished_deepslate
fill 417 96 340 417 99 340 minecraft:gray_concrete
setblock 417 96 344 minecraft:polished_deepslate
fill 417 96 345 417 99 345 minecraft:gray_concrete
setblock 417 96 349 minecraft:polished_deepslate
fill 417 96 350 417 99 350 minecraft:gray_concrete
setblock 417 96 354 minecraft:polished_deepslate
fill 417 96 355 417 99 355 minecraft:gray_concrete
setblock 417 96 359 minecraft:polished_deepslate
fill 417 96 360 417 99 360 minecraft:gray_concrete
fill 376 97 330 376 119 330 minecraft:black_concrete
setblock 377 97 323 minecraft:polished_deepslate
fill 377 97 324 377 97 327 minecraft:gray_concrete
setblock 377 97 328 minecraft:polished_deepslate
fill 377 97 329 377 100 329 minecraft:gray_concrete
setblock 377 97 333 minecraft:polished_deepslate
fill 377 97 334 377 100 334 minecraft:gray_concrete
setblock 377 97 338 minecraft:polished_deepslate
fill 377 97 339 377 100 339 minecraft:gray_concrete
setblock 377 97 343 minecraft:polished_deepslate
fill 377 97 344 377 97 347 minecraft:gray_concrete
setblock 377 97 348 minecraft:polished_deepslate
fill 377 97 349 377 100 349 minecraft:gray_concrete
setblock 377 97 353 minecraft:polished_deepslate
fill 377 97 354 377 100 354 minecraft:gray_concrete
setblock 377 97 358 minecraft:polished_deepslate
fill 377 97 359 377 99 359 minecraft:gray_concrete
setblock 378 97 326 minecraft:gray_concrete
setblock 378 97 327 minecraft:polished_deepslate
fill 378 97 328 378 98 328 minecraft:gray_concrete
setblock 378 97 332 minecraft:polished_deepslate
fill 378 97 333 378 100 333 minecraft:gray_concrete
setblock 378 97 337 minecraft:polished_deepslate
fill 378 97 338 378 100 338 minecraft:gray_concrete
setblock 378 97 342 minecraft:polished_deepslate
fill 378 97 343 378 98 343 minecraft:gray_concrete
setblock 378 97 347 minecraft:polished_deepslate
fill 378 97 348 378 99 348 minecraft:gray_concrete
setblock 378 97 352 minecraft:polished_deepslate
fill 378 97 353 378 100 353 minecraft:gray_concrete
setblock 378 97 357 minecraft:polished_deepslate
setblock 379 97 331 minecraft:polished_deepslate
setblock 379 97 332 minecraft:gray_concrete
setblock 379 97 347 minecraft:gray_concrete
setblock 379 97 351 minecraft:polished_deepslate
setblock 379 97 352 minecraft:gray_concrete
setblock 381 97 325 minecraft:light_blue_stained_glass
fill 382 97 326 382 98 326 minecraft:light_blue_stained_glass
setblock 383 97 325 minecraft:light_blue_stained_glass
fill 390 97 353 390 99 353 minecraft:light_blue_concrete
fill 390 97 363 390 99 363 minecraft:light_blue_concrete
setblock 391 97 322 minecraft:light_blue_stained_glass
setblock 391 97 324 minecraft:polished_deepslate
fill 391 97 352 391 99 352 minecraft:light_blue_concrete
setblock 392 97 323 minecraft:polished_deepslate
fill 392 97 324 392 100 324 minecraft:gray_concrete
fill 393 97 323 393 100 323 minecraft:gray_concrete
fill 393 97 363 393 100 363 minecraft:gray_concrete
setblock 394 97 326 minecraft:polished_deepslate
fill 395 97 322 395 113 322 minecraft:black_concrete
setblock 395 97 325 minecraft:polished_deepslate
setblock 395 97 326 minecraft:gray_concrete
setblock 396 97 324 minecraft:polished_deepslate
fill 396 97 325 396 98 325 minecraft:gray_concrete
fill 396 97 333 396 98 333 minecraft:gray_wool
setblock 397 97 323 minecraft:polished_deepslate
fill 397 97 324 397 99 324 minecraft:gray_concrete
setblock 397 97 363 minecraft:polished_deepslate
fill 398 97 323 398 100 323 minecraft:gray_concrete
fill 398 97 363 398 100 363 minecraft:gray_concrete
setblock 401 97 324 minecraft:polished_deepslate
fill 401 97 352 401 99 352 minecraft:light_blue_concrete
setblock 402 97 323 minecraft:polished_deepslate
fill 402 97 353 402 99 353 minecraft:light_blue_concrete
fill 402 97 363 402 99 363 minecraft:light_blue_concrete
setblock 403 97 323 minecraft:gray_concrete
fill 407 97 364 407 122 364 minecraft:black_concrete
fill 409 97 335 409 99 335 minecraft:polished_deepslate
fill 410 97 338 410 101 338 minecraft:polished_deepslate
fill 410 97 364 410 120 364 minecraft:black_concrete
fill 411 97 336 411 99 336 minecraft:polished_deepslate
setblock 412 97 323 minecraft:polished_deepslate
setblock 412 97 363 minecraft:polished_deepslate
fill 413 97 323 413 98 323 minecraft:gray_concrete
setblock 413 97 362 minecraft:polished_deepslate
fill 413 97 363 413 100 363 minecraft:gray_concrete
setblock 414 97 351 minecraft:polished_deepslate
fill 414 97 352 414 100 352 minecraft:gray_concrete
setblock 414 97 355 minecraft:gray_concrete
setblock 414 97 356 minecraft:polished_deepslate
fill 414 97 362 414 98 362 minecraft:gray_concrete
setblock 415 97 346 minecraft:gray_concrete
setblock 415 97 350 minecraft:polished_deepslate
fill 415 97 351 415 100 351 minecraft:gray_concrete
setblock 415 97 355 minecraft:polished_deepslate
fill 415 97 356 415 100 356 minecraft:gray_concrete
setblock 416 97 325 minecraft:gray_concrete
setblock 416 97 329 minecraft:polished_deepslate
fill 416 97 330 416 99 330 minecraft:gray_concrete
setblock 416 97 333 minecraft:gray_concrete
setblock 416 97 334 minecraft:polished_deepslate
setblock 416 97 343 minecraft:gray_concrete
setblock 416 97 344 minecraft:polished_deepslate
fill 416 97 345 416 99 345 minecraft:gray_concrete
setblock 416 97 349 minecraft:polished_deepslate
fill 416 97 350 416 100 350 minecraft:gray_concrete
setblock 416 97 354 minecraft:polished_deepslate
fill 416 97 355 416 100 355 minecraft:gray_concrete
setblock 416 97 359 minecraft:polished_deepslate
fill 416 97 360 416 100 360 minecraft:gray_concrete
setblock 417 97 323 minecraft:polished_deepslate
fill 417 97 324 417 98 324 minecraft:gray_concrete
setblock 417 97 328 minecraft:polished_deepslate
fill 417 97 329 417 100 329 minecraft:gray_concrete
setblock 417 97 333 minecraft:polished_deepslate
fill 417 97 334 417 100 334 minecraft:gray_concrete
setblock 417 97 338 minecraft:polished_deepslate
fill 417 97 339 417 100 339 minecraft:gray_concrete
setblock 417 97 343 minecraft:polished_deepslate
fill 417 97 344 417 100 344 minecraft:gray_concrete
setblock 417 97 348 minecraft:polished_deepslate
fill 417 97 349 417 100 349 minecraft:gray_concrete
setblock 417 97 353 minecraft:polished_deepslate
fill 417 97 354 417 100 354 minecraft:gray_concrete
setblock 417 97 358 minecraft:polished_deepslate
fill 417 97 359 417 100 359 minecraft:gray_concrete
setblock 417 97 363 minecraft:polished_deepslate
fill 377 98 325 377 98 326 minecraft:gray_concrete
setblock 377 98 327 minecraft:polished_deepslate
fill 377 98 328 377 101 328 minecraft:gray_concrete
setblock 377 98 332 minecraft:polished_deepslate
fill 377 98 333 377 101 333 minecraft:gray_concrete
setblock 377 98 337 minecraft:polished_deepslate
fill 377 98 338 377 101 338 minecraft:gray_concrete
setblock 377 98 342 minecraft:polished_deepslate
fill 377 98 343 377 98 346 minecraft:gray_concrete
setblock 377 98 347 minecraft:polished_deepslate
fill 377 98 348 377 101 348 minecraft:gray_concrete
setblock 377 98 352 minecraft:polished_deepslate
fill 377 98 353 377 101 353 minecraft:gray_concrete
setblock 377 98 357 minecraft:polished_deepslate
fill 377 98 358 377 101 358 minecraft:gray_concrete
setblock 378 98 331 minecraft:polished_deepslate
fill 378 98 332 378 101 332 minecraft:gray_concrete
setblock 378 98 336 minecraft:polished_deepslate
fill 378 98 337 378 101 337 minecraft:gray_concrete
setblock 378 98 346 minecraft:polished_deepslate
fill 378 98 347 378 99 347 minecraft:gray_concrete
setblock 378 98 351 minecraft:polished_deepslate
fill 378 98 352 378 100 352 minecraft:gray_concrete
setblock 378 98 356 minecraft:polished_deepslate
setblock 379 98 325 minecraft:light[level=12]
setblock 379 98 332 minecraft:light[level=12]
setblock 379 98 339 minecraft:light[level=12]
setblock 379 98 346 minecraft:light[level=12]
setblock 379 98 350 minecraft:polished_deepslate
setblock 379 98 351 minecraft:gray_concrete
setblock 379 98 353 minecraft:light[level=12]
setblock 379 98 360 minecraft:light[level=12]
fill 385 98 356 386 98 360 minecraft:sea_lantern
setblock 386 98 325 minecraft:light[level=12]
setblock 386 98 332 minecraft:light[level=12]
setblock 386 98 339 minecraft:light[level=12]
setblock 386 98 346 minecraft:light[level=12]
fill 386 98 353 386 98 355 minecraft:sea_lantern
fill 386 98 361 386 98 363 minecraft:sea_lantern
fill 387 98 352 387 98 354 minecraft:sea_lantern
fill 387 98 362 387 98 363 minecraft:sea_lantern
fill 388 98 351 388 98 352 minecraft:sea_lantern
setblock 388 98 358 minecraft:light_blue_concrete
fill 389 98 350 389 98 351 minecraft:sea_lantern
fill 390 98 349 390 98 350 minecraft:sea_lantern
fill 391 98 322 391 122 322 minecraft:black_concrete
setblock 391 98 323 minecraft:polished_deepslate
fill 391 98 324 391 101 324 minecraft:gray_concrete
fill 391 98 348 392 98 349 minecraft:sea_lantern
fill 392 98 323 392 101 323 minecraft:gray_concrete
setblock 393 98 332 minecraft:light[level=12]
setblock 393 98 339 minecraft:light[level=12]
setblock 393 98 346 minecraft:light[level=12]
fill 393 98 348 401 98 348 minecraft:sea_lantern
setblock 394 98 325 minecraft:polished_deepslate
fill 394 98 347 398 98 347 minecraft:sea_lantern
setblock 395 98 324 minecraft:polished_deepslate
fill 395 98 325 395 99 325 minecraft:gray_concrete
setblock 396 98 323 minecraft:polished_deepslate
fill 396 98 324 396 100 324 minecraft:gray_concrete
setblock 396 98 350 minecraft:light_blue_concrete
setblock 396 98 363 minecraft:polished_deepslate
fill 397 98 323 397 101 323 minecraft:gray_concrete
fill 397 98 363 397 101 363 minecraft:gray_concrete
fill 400 98 322 400 113 322 minecraft:black_concrete
setblock 400 98 324 minecraft:polished_deepslate
setblock 400 98 325 minecraft:light[level=12]
setblock 400 98 332 minecraft:light[level=12]
setblock 400 98 339 minecraft:light[level=12]
setblock 400 98 346 minecraft:light[level=12]
fill 400 98 349 402 98 349 minecraft:sea_lantern
setblock 401 98 322 minecraft:light_blue_stained_glass
setblock 401 98 323 minecraft:polished_deepslate
fill 401 98 363 401 101 363 minecraft:light_blue_concrete
fill 402 98 322 403 122 322 minecraft:black_concrete
setblock 402 98 323 minecraft:gray_concrete
fill 402 98 350 403 98 350 minecraft:sea_lantern
fill 403 98 351 404 98 351 minecraft:sea_lantern
fill 404 98 352 405 98 352 minecraft:sea_lantern
setblock 404 98 358 minecraft:light_blue_concrete
fill 405 98 353 406 98 354 minecraft:sea_lantern
fill 405 98 362 406 98 363 minecraft:sea_lantern
fill 406 98 355 406 98 361 minecraft:sea_lantern
setblock 407 98 325 minecraft:light[level=12]
setblock 407 98 332 minecraft:light[level=12]
setblock 407 98 339 minecraft:light[level=12]
setblock 407 98 346 minecraft:light[level=12]
setblock 407 98 353 minecraft:light[level=12]
fill 407 98 356 407 98 360 minecraft:sea_lantern
setblock 411 98 323 minecraft:polished_deepslate
setblock 411 98 363 minecraft:polished_deepslate
setblock 412 98 323 minecraft:gray_concrete
fill 412 98 344 412 101 344 minecraft:polished_deepslate
fill 412 98 363 412 101 363 minecraft:gray_concrete
fill 413 98 343 413 101 343 minecraft:polished_deepslate
fill 413 98 345 413 101 345 minecraft:polished_deepslate
setblock 413 98 362 minecraft:gray_concrete
setblock 414 98 325 minecraft:light[level=12]
setblock 414 98 332 minecraft:light[level=12]
setblock 414 98 339 minecraft:light[level=12]
fill 414 98 344 414 101 344 minecraft:polished_deepslate
setblock 414 98 346 minecraft:light[level=12]
setblock 414 98 350 minecraft:polished_deepslate
fill 414 98 351 414 100 351 minecraft:gray_concrete
setblock 414 98 355 minecraft:polished_deepslate
fill 414 98 356 414 101 356 minecraft:gray_concrete
setblock 414 98 360 minecraft:light[level=12]
setblock 415 98 349 minecraft:polished_deepslate
fill 415 98 350 415 101 350 minecraft:gray_concrete
setblock 415 98 354 minecraft:polished_deepslate
fill 415 98 355 415 101 355 minecraft:gray_concrete
setblock 416 98 323 minecraft:polished_deepslate
setblock 416 98 328 minecraft:polished_deepslate
setblock 416 98 329 minecraft:gray_concrete
setblock 416 98 333 minecraft:polished_deepslate
fill 416 98 334 416 101 334 minecraft:gray_concrete
setblock 416 98 344 minecraft:gray_concrete
setblock 416 98 348 minecraft:polished_deepslate
fill 416 98 349 416 101 349 minecraft:gray_concrete
setblock 416 98 353 minecraft:polished_deepslate
fill 416 98 354 416 101 354 minecraft:gray_concrete
setblock 416 98 358 minecraft:polished_deepslate
fill 416 98 359 416 101 359 minecraft:gray_concrete
setblock 416 98 363 minecraft:polished_deepslate
setblock 417 98 327 minecraft:polished_deepslate
fill 417 98 328 417 100 328 minecraft:gray_concrete
setblock 417 98 332 minecraft:polished_deepslate
fill 417 98 333 417 101 333 minecraft:gray_concrete
setblock 417 98 337 minecraft:polished_deepslate
fill 417 98 338 417 101 338 minecraft:gray_concrete
setblock 417 98 342 minecraft:polished_deepslate
fill 417 98 343 417 101 343 minecraft:gray_concrete
setblock 417 98 347 minecraft:polished_deepslate
fill 417 98 348 417 101 348 minecraft:gray_concrete
setblock 417 98 352 minecraft:polished_deepslate
fill 417 98 353 417 101 353 minecraft:gray_concrete
setblock 417 98 357 minecraft:polished_deepslate
fill 417 98 358 417 101 358 minecraft:gray_concrete
setblock 417 98 362 minecraft:polished_deepslate
setblock 417 98 363 minecraft:gray_concrete
setblock 377 99 326 minecraft:polished_deepslate
fill 377 99 327 377 100 327 minecraft:gray_concrete
setblock 377 99 331 minecraft:polished_deepslate
fill 377 99 332 377 102 332 minecraft:gray_concrete
setblock 377 99 336 minecraft:polished_deepslate
fill 377 99 337 377 102 337 minecraft:gray_concrete
setblock 377 99 341 minecraft:polished_deepslate
fill 377 99 342 377 99 345 minecraft:gray_concrete
setblock 377 99 346 minecraft:polished_deepslate
fill 377 99 347 377 102 347 minecraft:gray_concrete
setblock 377 99 351 minecraft:polished_deepslate
fill 377 99 352 377 102 352 minecraft:gray_concrete
setblock 377 99 356 minecraft:polished_deepslate
fill 377 99 357 377 102 357 minecraft:gray_concrete
setblock 378 99 330 minecraft:polished_deepslate
fill 378 99 331 378 102 331 minecraft:gray_concrete
setblock 378 99 335 minecraft:polished_deepslate
fill 378 99 336 378 102 336 minecraft:gray_concrete
setblock 378 99 346 minecraft:gray_concrete
setblock 378 99 350 minecraft:polished_deepslate
fill 378 99 351 378 100 351 minecraft:gray_concrete
setblock 378 99 355 minecraft:polished_deepslate
setblock 385 99 364 minecraft:light_blue_stained_glass
fill 386 99 364 386 106 364 minecraft:black_concrete
setblock 390 99 323 minecraft:polished_deepslate
fill 391 99 323 391 102 323 minecraft:gray_concrete
setblock 393 99 325 minecraft:polished_deepslate
setblock 394 99 324 minecraft:polished_deepslate
setblock 394 99 325 minecraft:gray_concrete
setblock 395 99 323 minecraft:polished_deepslate
fill 395 99 324 395 101 324 minecraft:gray_concrete
setblock 395 99 363 minecraft:polished_deepslate
fill 396 99 323 396 102 323 minecraft:gray_concrete
fill 396 99 363 396 102 363 minecraft:gray_concrete
fill 399 99 363 400 102 363 minecraft:light_blue_concrete
setblock 400 99 323 minecraft:polished_deepslate
fill 401 99 322 401 122 322 minecraft:black_concrete
fill 410 99 347 415 100 347 minecraft:light_blue_stained_glass
setblock 410 99 363 minecraft:polished_deepslate
fill 411 99 363 411 102 363 minecraft:gray_concrete
setblock 412 99 364 minecraft:light_blue_stained_glass
fill 413 99 346 415 101 346 minecraft:light_blue_stained_glass
fill 413 99 348 414 101 348 minecraft:light_blue_stained_glass
setblock 414 99 354 minecraft:polished_deepslate
fill 414 99 355 414 102 355 minecraft:gray_concrete
setblock 415 99 348 minecraft:polished_deepslate
fill 415 99 349 415 101 349 minecraft:gray_concrete
setblock 415 99 353 minecraft:polished_deepslate
fill 415 99 354 415 102 354 minecraft:gray_concrete
setblock 415 99 358 minecraft:polished_deepslate
setblock 415 99 363 minecraft:polished_deepslate
setblock 416 99 332 minecraft:polished_deepslate
fill 416 99 333 416 102 333 minecraft:gray_concrete
setblock 416 99 347 minecraft:polished_deepslate
fill 416 99 348 416 102 348 minecraft:gray_concrete
setblock 416 99 352 minecraft:polished_deepslate
fill 416 99 353 416 102 353 minecraft:gray_concrete
setblock 416 99 357 minecraft:polished_deepslate
fill 416 99 358 416 102 358 minecraft:gray_concrete
fill 416 99 363 416 100 363 minecraft:gray_concrete
setblock 417 99 327 minecraft:gray_concrete
setblock 417 99 331 minecraft:polished_deepslate
fill 417 99 332 417 102 332 minecraft:gray_concrete
setblock 417 99 336 minecraft:polished_deepslate
fill 417 99 337 417 102 337 minecraft:gray_concrete
setblock 417 99 341 minecraft:polished_deepslate
fill 417 99 342 417 102 342 minecraft:gray_concrete
setblock 417 99 346 minecraft:polished_deepslate
fill 417 99 347 417 102 347 minecraft:gray_concrete
setblock 417 99 351 minecraft:polished_deepslate
fill 417 99 352 417 102 352 minecraft:gray_concrete
setblock 417 99 356 minecraft:polished_deepslate
fill 417 99 357 417 102 357 minecraft:gray_concrete
setblock 417 99 361 minecraft:polished_deepslate
setblock 417 99 362 minecraft:gray_concrete
setblock 377 100 330 minecraft:polished_deepslate
fill 377 100 331 377 103 331 minecraft:gray_concrete
setblock 377 100 335 minecraft:polished_deepslate
fill 377 100 336 377 103 336 minecraft:gray_concrete
setblock 377 100 340 minecraft:polished_deepslate
fill 377 100 341 377 100 344 minecraft:gray_concrete
setblock 377 100 345 minecraft:polished_deepslate
fill 377 100 346 377 102 346 minecraft:gray_concrete
setblock 377 100 350 minecraft:polished_deepslate
fill 377 100 351 377 103 351 minecraft:gray_concrete
setblock 377 100 355 minecraft:polished_deepslate
fill 377 100 356 377 103 356 minecraft:gray_concrete
setblock 378 100 330 minecraft:gray_concrete
setblock 378 100 334 minecraft:polished_deepslate
fill 378 100 335 378 103 335 minecraft:gray_concrete
setblock 378 100 349 minecraft:polished_deepslate
setblock 378 100 350 minecraft:gray_concrete
setblock 378 100 354 minecraft:polished_deepslate
setblock 378 100 355 minecraft:gray_concrete
fill 385 100 364 385 122 364 minecraft:black_concrete
fill 390 100 323 390 103 323 minecraft:gray_concrete
setblock 393 100 324 minecraft:polished_deepslate
setblock 394 100 323 minecraft:polished_deepslate
fill 394 100 324 394 103 324 minecraft:gray_concrete
setblock 394 100 363 minecraft:polished_deepslate
fill 395 100 323 395 103 323 minecraft:gray_concrete
fill 395 100 363 395 103 363 minecraft:gray_concrete
setblock 399 100 323 minecraft:polished_deepslate
setblock 409 100 347 minecraft:light_blue_stained_glass
setblock 409 100 363 minecraft:polished_deepslate
fill 410 100 363 410 103 363 minecraft:gray_concrete
fill 411 100 346 412 100 346 minecraft:light_blue_stained_glass
fill 411 100 348 412 100 348 minecraft:light_blue_stained_glass
fill 412 100 364 412 122 364 minecraft:black_concrete
setblock 414 100 353 minecraft:polished_deepslate
fill 414 100 354 414 103 354 minecraft:gray_concrete
setblock 414 100 363 minecraft:polished_deepslate
fill 415 100 348 415 102 348 minecraft:light_blue_stained_glass
setblock 415 100 352 minecraft:polished_deepslate
fill 415 100 353 415 103 353 minecraft:gray_concrete
setblock 415 100 357 minecraft:polished_deepslate
fill 415 100 358 415 103 358 minecraft:gray_concrete
fill 415 100 363 415 103 363 minecraft:gray_concrete
setblock 416 100 331 minecraft:polished_deepslate
fill 416 100 332 416 101 332 minecraft:gray_concrete
setblock 416 100 335 minecraft:gray_concrete
fill 416 100 345 416 101 345 minecraft:light_blue_stained_glass
setblock 416 100 346 minecraft:polished_deepslate
fill 416 100 347 416 101 347 minecraft:gray_concrete
setblock 416 100 351 minecraft:polished_deepslate
fill 416 100 352 416 103 352 minecraft:gray_concrete
setblock 416 100 356 minecraft:polished_deepslate
fill 416 100 357 416 103 357 minecraft:gray_concrete
setblock 417 100 330 minecraft:polished_deepslate
fill 417 100 331 417 103 331 minecraft:gray_concrete
setblock 417 100 335 minecraft:polished_deepslate
fill 417 100 336 417 103 336 minecraft:gray_concrete
setblock 417 100 340 minecraft:polished_deepslate
fill 417 100 341 417 103 341 minecraft:gray_concrete
setblock 417 100 345 minecraft:polished_deepslate
fill 417 100 346 417 103 346 minecraft:gray_concrete
setblock 417 100 350 minecraft:polished_deepslate
fill 417 100 351 417 103 351 minecraft:gray_concrete
setblock 417 100 355 minecraft:polished_deepslate
fill 417 100 356 417 103 356 minecraft:gray_concrete
setblock 417 100 360 minecraft:polished_deepslate
fill 417 100 361 417 103 361 minecraft:gray_concrete
setblock 377 101 329 minecraft:polished_deepslate
fill 377 101 330 377 104 330 minecraft:gray_concrete
setblock 377 101 334 minecraft:polished_deepslate
fill 377 101 335 377 104 335 minecraft:gray_concrete
setblock 377 101 339 minecraft:polished_deepslate
fill 377 101 340 377 101 343 minecraft:gray_concrete
setblock 377 101 344 minecraft:polished_deepslate
fill 377 101 345 377 102 345 minecraft:gray_concrete
setblock 377 101 349 minecraft:polished_deepslate
fill 377 101 350 377 104 350 minecraft:gray_concrete
setblock 377 101 354 minecraft:polished_deepslate
fill 377 101 355 377 104 355 minecraft:gray_concrete
setblock 378 101 333 minecraft:polished_deepslate
fill 378 101 334 378 104 334 minecraft:gray_concrete
setblock 378 101 338 minecraft:polished_deepslate
fill 389 101 323 389 104 323 minecraft:gray_concrete
setblock 392 101 324 minecraft:polished_deepslate
setblock 392 101 363 minecraft:gray_concrete
setblock 393 101 323 minecraft:polished_deepslate
fill 393 101 324 393 104 324 minecraft:gray_concrete
setblock 393 101 363 minecraft:polished_deepslate
fill 394 101 323 394 104 323 minecraft:gray_concrete
fill 394 101 363 394 104 363 minecraft:gray_concrete
setblock 398 101 323 minecraft:polished_deepslate
setblock 398 101 363 minecraft:light_blue_concrete
setblock 408 101 363 minecraft:polished_deepslate
fill 409 101 363 409 104 363 minecraft:gray_concrete
fill 411 101 347 415 101 347 minecraft:light_blue_stained_glass
fill 411 101 362 413 101 362 minecraft:gray_concrete
setblock 412 101 343 minecraft:polished_deepslate
setblock 412 101 345 minecraft:polished_deepslate
setblock 413 101 363 minecraft:polished_deepslate
setblock 414 101 343 minecraft:polished_deepslate
setblock 414 101 345 minecraft:polished_deepslate
setblock 414 101 352 minecraft:polished_deepslate
fill 414 101 353 414 103 353 minecraft:gray_concrete
fill 414 101 363 414 104 363 minecraft:gray_concrete
fill 415 101 342 415 102 342 minecraft:white_wool
setblock 415 101 351 minecraft:polished_deepslate
fill 415 101 352 415 104 352 minecraft:gray_concrete
setblock 415 101 356 minecraft:polished_deepslate
fill 415 101 357 415 104 357 minecraft:gray_concrete
setblock 416 101 335 minecraft:polished_deepslate
fill 416 101 346 416 102 346 minecraft:light_blue_stained_glass
setblock 416 101 350 minecraft:polished_deepslate
fill 416 101 351 416 104 351 minecraft:gray_concrete
setblock 416 101 355 minecraft:polished_deepslate
fill 416 101 356 416 104 356 minecraft:gray_concrete
setblock 416 101 360 minecraft:polished_deepslate
setblock 417 101 329 minecraft:polished_deepslate
fill 417 101 330 417 102 330 minecraft:gray_concrete
setblock 417 101 334 minecraft:polished_deepslate
fill 417 101 335 417 104 335 minecraft:gray_concrete
setblock 417 101 339 minecraft:polished_deepslate
fill 417 101 340 417 104 340 minecraft:gray_concrete
setblock 417 101 344 minecraft:polished_deepslate
fill 417 101 345 417 104 345 minecraft:gray_concrete
setblock 417 101 349 minecraft:polished_deepslate
fill 417 101 350 417 104 350 minecraft:gray_concrete
setblock 417 101 354 minecraft:polished_deepslate
fill 417 101 355 417 104 355 minecraft:gray_concrete
setblock 417 101 359 minecraft:polished_deepslate
fill 417 101 360 417 104 360 minecraft:gray_concrete
setblock 377 102 328 minecraft:polished_deepslate
fill 377 102 329 377 105 329 minecraft:gray_concrete
setblock 377 102 333 minecraft:polished_deepslate
fill 377 102 334 377 105 334 minecraft:gray_concrete
setblock 377 102 338 minecraft:polished_deepslate
fill 377 102 339 377 102 342 minecraft:gray_concrete
setblock 377 102 343 minecraft:polished_deepslate
fill 377 102 344 377 105 344 minecraft:gray_concrete
setblock 377 102 348 minecraft:polished_deepslate
fill 377 102 349 377 103 349 minecraft:gray_concrete
setblock 377 102 353 minecraft:polished_deepslate
fill 377 102 354 377 105 354 minecraft:gray_concrete
setblock 377 102 358 minecraft:polished_deepslate
setblock 378 102 332 minecraft:polished_deepslate
fill 378 102 333 378 105 333 minecraft:gray_concrete
setblock 378 102 337 minecraft:polished_deepslate
fill 378 102 338 378 105 338 minecraft:gray_concrete
setblock 379 102 325 minecraft:light[level=13]
setblock 379 102 333 minecraft:light[level=13]
setblock 379 102 341 minecraft:light[level=13]
setblock 379 102 349 minecraft:light[level=13]
setblock 379 102 357 minecraft:light[level=13]
setblock 387 102 325 minecraft:light[level=13]
setblock 387 102 333 minecraft:light[level=13]
setblock 387 102 341 minecraft:light[level=13]
setblock 387 102 349 minecraft:light[level=13]
setblock 387 102 357 minecraft:light[level=13]
setblock 391 102 324 minecraft:polished_deepslate
setblock 391 102 363 minecraft:gray_concrete
setblock 392 102 323 minecraft:polished_deepslate
fill 392 102 324 392 105 324 minecraft:gray_concrete
setblock 392 102 363 minecraft:polished_deepslate
fill 393 102 323 393 105 323 minecraft:gray_concrete
fill 393 102 363 393 105 363 minecraft:gray_concrete
setblock 395 102 325 minecraft:light[level=13]
setblock 395 102 333 minecraft:light[level=13]
setblock 395 102 341 minecraft:light[level=13]
setblock 395 102 349 minecraft:light[level=13]
setblock 397 102 323 minecraft:polished_deepslate
setblock 397 102 363 minecraft:polished_deepslate
fill 398 102 363 398 105 363 minecraft:gray_concrete
setblock 403 102 325 minecraft:light[level=13]
setblock 403 102 333 minecraft:light[level=13]
setblock 403 102 341 minecraft:light[level=13]
setblock 403 102 349 minecraft:light[level=13]
setblock 403 102 357 minecraft:light[level=13]
setblock 405 102 322 minecraft:light_blue_stained_glass
fill 406 102 322 406 118 322 minecraft:black_concrete
fill 407 102 334 407 103 335 minecraft:white_wool
setblock 407 102 363 minecraft:polished_deepslate
fill 408 102 363 408 105 363 minecraft:gray_concrete
fill 410 102 362 412 102 362 minecraft:gray_concrete
setblock 411 102 325 minecraft:light[level=13]
setblock 411 102 333 minecraft:light[level=13]
setblock 411 102 341 minecraft:light[level=13]
setblock 411 102 349 minecraft:light[level=13]
setblock 411 102 357 minecraft:light[level=13]
setblock 412 102 363 minecraft:polished_deepslate
setblock 413 102 362 minecraft:polished_deepslate
fill 413 102 363 413 105 363 minecraft:gray_concrete
fill 414 102 347 416 102 347 minecraft:light_blue_stained_glass
setblock 414 102 356 minecraft:polished_deepslate
fill 414 102 362 414 105 362 minecraft:gray_concrete
setblock 415 102 346 minecraft:light_blue_stained_glass
setblock 415 102 350 minecraft:polished_deepslate
fill 415 102 351 415 104 351 minecraft:gray_concrete
setblock 415 102 355 minecraft:polished_deepslate
fill 415 102 356 415 105 356 minecraft:gray_concrete
setblock 415 102 359 minecraft:gray_concrete
setblock 416 102 334 minecraft:polished_deepslate
fill 416 102 335 416 103 337 minecraft:gray_concrete
setblock 416 102 349 minecraft:polished_deepslate
fill 416 102 350 416 105 350 minecraft:gray_concrete
setblock 416 102 354 minecraft:polished_deepslate
fill 416 102 355 416 105 355 minecraft:gray_concrete
setblock 416 102 359 minecraft:polished_deepslate
fill 416 102 360 416 105 360 minecraft:gray_concrete
setblock 417 102 333 minecraft:polished_deepslate
fill 417 102 334 417 105 334 minecraft:gray_concrete
setblock 417 102 338 minecraft:polished_deepslate
fill 417 102 339 417 105 339 minecraft:gray_concrete
setblock 417 102 343 minecraft:polished_deepslate
fill 417 102 344 417 105 344 minecraft:gray_concrete
setblock 417 102 348 minecraft:polished_deepslate
fill 417 102 349 417 105 349 minecraft:gray_concrete
setblock 417 102 353 minecraft:polished_deepslate
fill 417 102 354 417 105 354 minecraft:gray_concrete
setblock 417 102 358 minecraft:polished_deepslate
fill 417 102 359 417 105 359 minecraft:gray_concrete
fill 418 102 341 418 103 352 minecraft:black_concrete
setblock 418 102 353 minecraft:light_blue_stained_glass
fill 418 102 354 418 109 361 minecraft:black_concrete
setblock 377 103 332 minecraft:polished_deepslate
fill 377 103 333 377 106 333 minecraft:gray_concrete
setblock 377 103 337 minecraft:polished_deepslate
fill 377 103 338 377 103 341 minecraft:gray_concrete
setblock 377 103 342 minecraft:polished_deepslate
fill 377 103 343 377 106 343 minecraft:gray_concrete
setblock 377 103 348 minecraft:gray_concrete
setblock 377 103 352 minecraft:polished_deepslate
fill 377 103 353 377 106 353 minecraft:gray_concrete
setblock 377 103 357 minecraft:polished_deepslate
fill 377 103 358 377 105 359 minecraft:gray_concrete
setblock 378 103 331 minecraft:polished_deepslate
fill 378 103 332 378 106 332 minecraft:gray_concrete
setblock 378 103 336 minecraft:polished_deepslate
fill 378 103 337 378 106 337 minecraft:gray_concrete
fill 378 103 339 378 104 339 minecraft:gray_concrete
fill 388 103 323 388 105 323 minecraft:gray_concrete
fill 389 103 363 390 103 363 minecraft:gray_concrete
setblock 390 103 324 minecraft:polished_deepslate
setblock 391 103 323 minecraft:polished_deepslate
fill 391 103 324 391 106 324 minecraft:gray_concrete
setblock 391 103 363 minecraft:polished_deepslate
fill 392 103 323 392 106 323 minecraft:gray_concrete
setblock 392 103 362 minecraft:polished_deepslate
fill 392 103 363 392 106 363 minecraft:gray_concrete
fill 393 103 361 393 104 361 minecraft:light_blue_concrete
fill 393 103 362 395 104 362 minecraft:gray_concrete
setblock 396 103 323 minecraft:polished_deepslate
setblock 396 103 363 minecraft:polished_deepslate
fill 397 103 323 397 106 323 minecraft:gray_concrete
fill 397 103 363 397 106 363 minecraft:gray_concrete
fill 399 103 363 399 104 363 minecraft:gray_concrete
fill 405 103 322 405 116 322 minecraft:black_concrete
setblock 405 103 363 minecraft:gray_concrete
setblock 406 103 363 minecraft:polished_deepslate
fill 407 103 363 407 106 363 minecraft:gray_concrete
fill 408 103 362 411 103 362 minecraft:gray_concrete
fill 410 103 361 412 103 361 minecraft:gray_concrete
setblock 411 103 363 minecraft:polished_deepslate
setblock 412 103 362 minecraft:polished_deepslate
fill 412 103 363 412 106 363 minecraft:gray_concrete
fill 413 103 362 413 106 362 minecraft:gray_concrete
setblock 414 103 355 minecraft:polished_deepslate
fill 414 103 356 414 105 357 minecraft:gray_concrete
setblock 415 103 354 minecraft:polished_deepslate
fill 415 103 355 415 106 355 minecraft:gray_concrete
setblock 415 103 359 minecraft:polished_deepslate
setblock 416 103 333 minecraft:polished_deepslate
fill 416 103 334 416 106 334 minecraft:gray_concrete
setblock 416 103 338 minecraft:polished_deepslate
fill 416 103 339 416 106 339 minecraft:gray_concrete
setblock 416 103 348 minecraft:polished_deepslate
fill 416 103 349 416 105 349 minecraft:gray_concrete
setblock 416 103 353 minecraft:polished_deepslate
fill 416 103 354 416 106 354 minecraft:gray_concrete
setblock 416 103 358 minecraft:polished_deepslate
fill 416 103 359 416 106 359 minecraft:gray_concrete
setblock 417 103 332 minecraft:polished_deepslate
fill 417 103 333 417 106 333 minecraft:gray_concrete
setblock 417 103 337 minecraft:polished_deepslate
fill 417 103 338 417 106 338 minecraft:gray_concrete
setblock 417 103 342 minecraft:polished_deepslate
fill 417 103 343 417 106 343 minecraft:gray_concrete
setblock 417 103 347 minecraft:polished_deepslate
fill 417 103 348 417 106 348 minecraft:gray_concrete
setblock 417 103 352 minecraft:polished_deepslate
fill 417 103 353 417 106 353 minecraft:gray_concrete
setblock 417 103 357 minecraft:polished_deepslate
fill 417 103 358 417 106 358 minecraft:gray_concrete
fill 418 103 353 418 120 353 minecraft:black_concrete
setblock 376 104 357 minecraft:light_blue_stained_glass
setblock 377 104 331 minecraft:polished_deepslate
fill 377 104 332 377 107 332 minecraft:gray_concrete
setblock 377 104 336 minecraft:polished_deepslate
fill 377 104 337 377 104 340 minecraft:gray_concrete
setblock 377 104 341 minecraft:polished_deepslate
fill 377 104 342 377 107 342 minecraft:gray_concrete
setblock 377 104 351 minecraft:polished_deepslate
fill 377 104 352 377 105 352 minecraft:gray_concrete
setblock 377 104 356 minecraft:polished_deepslate
fill 377 104 357 377 107 357 minecraft:gray_concrete
setblock 378 104 335 minecraft:polished_deepslate
fill 378 104 336 378 107 336 minecraft:gray_concrete
setblock 378 104 340 minecraft:polished_deepslate
setblock 379 104 325 minecraft:light[level=12]
setblock 379 104 332 minecraft:light[level=12]
setblock 379 104 339 minecraft:light[level=12]
setblock 379 104 346 minecraft:light[level=12]
setblock 379 104 353 minecraft:light[level=12]
setblock 379 104 360 minecraft:light[level=12]
setblock 386 104 325 minecraft:light[level=12]
setblock 386 104 332 minecraft:light[level=12]
setblock 386 104 339 minecraft:light[level=12]
setblock 386 104 346 minecraft:light[level=12]
setblock 386 104 353 minecraft:light[level=12]
setblock 386 104 360 minecraft:light[level=12]
fill 387 104 323 387 106 323 minecraft:gray_concrete
fill 388 104 363 389 104 363 minecraft:gray_concrete
setblock 389 104 324 minecraft:polished_deepslate
setblock 390 104 323 minecraft:polished_deepslate
fill 390 104 324 390 107 324 minecraft:gray_concrete
setblock 390 104 362 minecraft:gray_concrete
setblock 390 104 363 minecraft:polished_deepslate
fill 391 104 323 391 107 323 minecraft:gray_concrete
setblock 391 104 362 minecraft:polished_deepslate
fill 391 104 363 391 107 363 minecraft:gray_concrete
fill 392 104 362 392 107 362 minecraft:gray_concrete
setblock 393 104 325 minecraft:light[level=12]
setblock 393 104 332 minecraft:light[level=12]
setblock 393 104 339 minecraft:light[level=12]
setblock 393 104 346 minecraft:light[level=12]
setblock 393 104 353 minecraft:light[level=12]
setblock 394 104 324 minecraft:polished_deepslate
setblock 395 104 323 minecraft:polished_deepslate
setblock 395 104 363 minecraft:polished_deepslate
fill 396 104 323 396 107 323 minecraft:gray_concrete
setblock 396 104 362 minecraft:polished_deepslate
fill 396 104 363 396 107 363 minecraft:gray_concrete
fill 397 104 362 397 107 362 minecraft:gray_concrete
fill 398 104 362 399 104 362 minecraft:light_blue_concrete
setblock 400 104 325 minecraft:light[level=12]
setblock 400 104 332 minecraft:light[level=12]
setblock 400 104 339 minecraft:light[level=12]
setblock 400 104 346 minecraft:light[level=12]
setblock 400 104 353 minecraft:light[level=12]
setblock 400 104 363 minecraft:polished_deepslate
fill 401 104 363 404 104 363 minecraft:gray_concrete
setblock 405 104 363 minecraft:polished_deepslate
setblock 406 104 362 minecraft:polished_deepslate
fill 406 104 363 406 107 363 minecraft:gray_concrete
setblock 407 104 325 minecraft:light[level=12]
setblock 407 104 332 minecraft:light[level=12]
setblock 407 104 339 minecraft:light[level=12]
setblock 407 104 346 minecraft:light[level=12]
setblock 407 104 353 minecraft:light[level=12]
setblock 407 104 360 minecraft:light[level=12]
fill 407 104 362 410 104 362 minecraft:gray_concrete
fill 408 104 361 411 104 361 minecraft:gray_concrete
setblock 410 104 363 minecraft:polished_deepslate
setblock 411 104 362 minecraft:polished_deepslate
fill 411 104 363 411 107 363 minecraft:gray_concrete
setblock 412 104 361 minecraft:polished_deepslate
fill 412 104 362 412 107 362 minecraft:gray_concrete
fill 413 104 361 413 107 361 minecraft:gray_concrete
setblock 414 104 325 minecraft:light[level=12]
setblock 414 104 332 minecraft:light[level=12]
setblock 414 104 339 minecraft:light[level=12]
setblock 414 104 346 minecraft:light[level=12]
setblock 414 104 353 minecraft:light[level=12]
setblock 414 104 354 minecraft:polished_deepslate
fill 414 104 355 414 106 355 minecraft:gray_concrete
setblock 414 104 360 minecraft:light[level=12]
setblock 415 104 353 minecraft:polished_deepslate
fill 415 104 354 415 107 354 minecraft:gray_concrete
setblock 415 104 358 minecraft:polished_deepslate
fill 415 104 359 415 107 359 minecraft:gray_concrete
setblock 415 104 362 minecraft:gray_concrete
setblock 415 104 363 minecraft:polished_deepslate
fill 416 104 333 416 106 333 minecraft:gray_concrete
fill 416 104 335 416 104 336 minecraft:gray_concrete
setblock 416 104 337 minecraft:polished_deepslate
fill 416 104 338 416 107 338 minecraft:gray_concrete
fill 416 104 340 416 104 341 minecraft:gray_concrete
setblock 416 104 352 minecraft:polished_deepslate
fill 416 104 353 416 107 353 minecraft:gray_concrete
setblock 416 104 357 minecraft:polished_deepslate
fill 416 104 358 416 107 358 minecraft:gray_concrete
setblock 416 104 361 minecraft:gray_concrete
fill 416 104 363 416 107 363 minecraft:gray_concrete
setblock 417 104 331 minecraft:polished_deepslate
fill 417 104 332 417 107 332 minecraft:gray_concrete
setblock 417 104 336 minecraft:polished_deepslate
fill 417 104 337 417 107 337 minecraft:gray_concrete
setblock 417 104 341 minecraft:polished_deepslate
fill 417 104 342 417 107 342 minecraft:gray_concrete
setblock 417 104 346 minecraft:polished_deepslate
fill 417 104 347 417 107 347 minecraft:gray_concrete
setblock 417 104 351 minecraft:polished_deepslate
fill 417 104 352 417 107 352 minecraft:gray_concrete
setblock 417 104 356 minecraft:polished_deepslate
fill 417 104 357 417 107 357 minecraft:gray_concrete
setblock 417 104 361 minecraft:polished_deepslate
fill 417 104 362 417 107 362 minecraft:gray_concrete
fill 418 104 326 418 118 331 minecraft:black_concrete
setblock 418 104 332 minecraft:light_blue_stained_glass
fill 418 104 333 418 115 334 minecraft:black_concrete
fill 418 104 341 418 108 347 minecraft:black_concrete
setblock 418 104 348 minecraft:light_blue_stained_glass
fill 418 104 349 418 120 352 minecraft:black_concrete
fill 376 105 357 376 122 357 minecraft:black_concrete
setblock 377 105 330 minecraft:polished_deepslate
fill 377 105 331 377 108 331 minecraft:gray_concrete
setblock 377 105 335 minecraft:polished_deepslate
fill 377 105 336 377 105 339 minecraft:gray_concrete
setblock 377 105 340 minecraft:polished_deepslate
fill 377 105 341 377 108 341 minecraft:gray_concrete
setblock 377 105 345 minecraft:polished_deepslate
setblock 377 105 351 minecraft:gray_concrete
setblock 377 105 355 minecraft:polished_deepslate
fill 377 105 356 377 108 356 minecraft:gray_concrete
setblock 377 105 360 minecraft:polished_deepslate
setblock 378 105 334 minecraft:polished_deepslate
fill 378 105 335 378 108 335 minecraft:gray_concrete
setblock 378 105 339 minecraft:polished_deepslate
fill 378 105 340 378 108 340 minecraft:gray_concrete
fill 380 105 334 380 114 334 minecraft:polished_deepslate
fill 385 105 323 386 107 323 minecraft:gray_concrete
fill 386 105 363 388 105 363 minecraft:gray_concrete
setblock 388 105 324 minecraft:polished_deepslate
fill 388 105 362 389 105 362 minecraft:gray_concrete
setblock 389 105 323 minecraft:polished_deepslate
fill 389 105 324 389 108 324 minecraft:gray_concrete
setblock 389 105 363 minecraft:polished_deepslate
fill 390 105 323 390 108 323 minecraft:gray_concrete
setblock 390 105 361 minecraft:gray_concrete
setblock 390 105 362 minecraft:polished_deepslate
fill 390 105 363 390 108 363 minecraft:gray_concrete
setblock 391 105 361 minecraft:polished_deepslate
fill 391 105 362 391 108 362 minecraft:gray_concrete
fill 392 105 361 395 105 361 minecraft:gray_concrete
setblock 393 105 324 minecraft:polished_deepslate
fill 393 105 362 394 105 362 minecraft:gray_concrete
setblock 394 105 323 minecraft:polished_deepslate
fill 394 105 324 394 108 324 minecraft:gray_concrete
setblock 394 105 363 minecraft:polished_deepslate
fill 395 105 323 395 108 323 minecraft:gray_concrete
setblock 395 105 362 minecraft:polished_deepslate
fill 395 105 363 395 108 363 minecraft:gray_concrete
fill 396 105 361 398 105 361 minecraft:light_blue_concrete
fill 396 105 362 396 108 362 minecraft:gray_concrete
fill 398 105 362 399 105 362 minecraft:gray_concrete
setblock 399 105 363 minecraft:polished_deepslate
fill 400 105 363 403 105 363 minecraft:gray_concrete
fill 403 105 362 404 105 362 minecraft:gray_concrete
setblock 404 105 363 minecraft:polished_deepslate
setblock 405 105 362 minecraft:polished_deepslate
fill 405 105 363 405 108 363 minecraft:gray_concrete
setblock 406 105 361 minecraft:polished_deepslate
fill 406 105 362 409 105 362 minecraft:gray_concrete
fill 407 105 361 410 105 361 minecraft:gray_concrete
fill 408 105 360 411 105 360 minecraft:gray_concrete
setblock 409 105 323 minecraft:polished_deepslate
setblock 409 105 363 minecraft:polished_deepslate
fill 410 105 323 411 107 323 minecraft:gray_concrete
setblock 410 105 362 minecraft:polished_deepslate
fill 410 105 363 410 108 363 minecraft:gray_concrete
setblock 411 105 361 minecraft:polished_deepslate
fill 411 105 362 411 108 362 minecraft:gray_concrete
setblock 412 105 360 minecraft:polished_deepslate
fill 412 105 361 412 108 361 minecraft:gray_concrete
setblock 414 105 354 minecraft:gray_concrete
setblock 414 105 358 minecraft:polished_deepslate
fill 414 105 361 414 106 361 minecraft:gray_concrete
setblock 414 105 363 minecraft:polished_deepslate
setblock 415 105 322 minecraft:light_blue_stained_glass
setblock 415 105 336 minecraft:gray_concrete
setblock 415 105 337 minecraft:polished_deepslate
fill 415 105 338 415 108 338 minecraft:gray_concrete
setblock 415 105 352 minecraft:polished_deepslate
fill 415 105 353 415 106 353 minecraft:gray_concrete
setblock 415 105 357 minecraft:polished_deepslate
fill 415 105 358 415 108 358 minecraft:gray_concrete
fill 415 105 360 415 106 360 minecraft:gray_concrete
setblock 415 105 362 minecraft:polished_deepslate
fill 415 105 363 415 108 363 minecraft:gray_concrete
setblock 416 105 335 minecraft:gray_concrete
setblock 416 105 336 minecraft:polished_deepslate
fill 416 105 337 416 108 337 minecraft:gray_concrete
setblock 416 105 340 minecraft:gray_concrete
setblock 416 105 341 minecraft:polished_deepslate
fill 416 105 342 416 107 343 minecraft:gray_concrete
setblock 416 105 351 minecraft:polished_deepslate
fill 416 105 352 416 107 352 minecraft:gray_concrete
setblock 416 105 356 minecraft:polished_deepslate
fill 416 105 357 416 108 357 minecraft:gray_concrete
setblock 416 105 361 minecraft:polished_deepslate
fill 417 105 331 417 106 331 minecraft:gray_concrete
setblock 417 105 335 minecraft:polished_deepslate
fill 417 105 336 417 108 336 minecraft:gray_concrete
setblock 417 105 340 minecraft:polished_deepslate
fill 417 105 341 417 108 341 minecraft:gray_concrete
setblock 417 105 345 minecraft:polished_deepslate
fill 417 105 346 417 108 346 minecraft:gray_concrete
setblock 417 105 350 minecraft:polished_deepslate
fill 417 105 351 417 108 351 minecraft:gray_concrete
setblock 417 105 355 minecraft:polished_deepslate
fill 417 105 356 417 108 356 minecraft:gray_concrete
setblock 417 105 360 minecraft:polished_deepslate
fill 417 105 361 417 108 361 minecraft:gray_concrete
fill 418 105 332 418 122 332 minecraft:black_concrete
fill 418 105 348 418 122 348 minecraft:black_concrete
setblock 377 106 329 minecraft:polished_deepslate
fill 377 106 330 377 109 330 minecraft:gray_concrete
setblock 377 106 334 minecraft:polished_deepslate
fill 377 106 335 377 106 338 minecraft:gray_concrete
setblock 377 106 339 minecraft:polished_deepslate
fill 377 106 340 377 109 340 minecraft:gray_concrete
setblock 377 106 344 minecraft:polished_deepslate
fill 377 106 345 377 109 345 minecraft:gray_concrete
setblock 377 106 354 minecraft:polished_deepslate
fill 377 106 355 377 107 355 minecraft:gray_concrete
setblock 377 106 358 minecraft:gray_concrete
setblock 377 106 359 minecraft:polished_deepslate
fill 377 106 360 377 109 360 minecraft:gray_concrete
setblock 378 106 333 minecraft:polished_deepslate
fill 378 106 334 378 109 334 minecraft:gray_concrete
setblock 378 106 338 minecraft:polished_deepslate
fill 378 106 339 378 109 339 minecraft:gray_concrete
fill 378 106 341 378 107 341 minecraft:gray_concrete
fill 379 106 335 379 106 336 minecraft:gray_concrete
setblock 379 106 337 minecraft:polished_deepslate
fill 384 106 323 384 109 323 minecraft:gray_concrete
fill 384 106 363 387 106 363 minecraft:gray_concrete
setblock 386 106 324 minecraft:gray_concrete
fill 386 106 362 388 106 362 minecraft:gray_concrete
setblock 387 106 324 minecraft:polished_deepslate
setblock 388 106 323 minecraft:polished_deepslate
fill 388 106 324 388 109 324 minecraft:gray_concrete
fill 388 106 361 389 106 361 minecraft:gray_concrete
setblock 388 106 363 minecraft:polished_deepslate
fill 389 106 323 389 109 323 minecraft:gray_concrete
setblock 389 106 362 minecraft:polished_deepslate
fill 389 106 363 389 109 363 minecraft:gray_concrete
setblock 390 106 325 minecraft:gray_concrete
setblock 390 106 361 minecraft:polished_deepslate
fill 390 106 362 390 109 362 minecraft:gray_concrete
setblock 391 106 325 minecraft:polished_deepslate
fill 391 106 361 394 106 361 minecraft:gray_concrete
setblock 392 106 324 minecraft:polished_deepslate
setblock 393 106 323 minecraft:polished_deepslate
fill 393 106 324 393 109 324 minecraft:gray_concrete
setblock 393 106 362 minecraft:gray_concrete
setblock 393 106 363 minecraft:polished_deepslate
fill 394 106 323 394 109 323 minecraft:gray_concrete
setblock 394 106 362 minecraft:polished_deepslate
fill 394 106 363 394 109 363 minecraft:gray_concrete
fill 395 106 324 395 107 324 minecraft:gray_concrete
setblock 395 106 361 minecraft:polished_deepslate
fill 395 106 362 395 109 362 minecraft:gray_concrete
fill 396 106 361 396 109 361 minecraft:gray_concrete
setblock 398 106 323 minecraft:polished_deepslate
setblock 398 106 362 minecraft:gray_concrete
setblock 398 106 363 minecraft:polished_deepslate
setblock 399 106 362 minecraft:polished_deepslate
fill 399 106 363 402 106 363 minecraft:gray_concrete
fill 400 106 362 403 106 362 minecraft:gray_concrete
fill 402 106 364 403 112 364 minecraft:black_concrete
setblock 403 106 363 minecraft:polished_deepslate
setblock 404 106 361 minecraft:gray_concrete
setblock 404 106 362 minecraft:polished_deepslate
fill 404 106 363 404 109 363 minecraft:gray_concrete
setblock 404 106 364 minecraft:light_blue_stained_glass
setblock 405 106 361 minecraft:polished_deepslate
fill 405 106 362 408 106 362 minecraft:gray_concrete
fill 405 106 364 406 112 364 minecraft:black_concrete
fill 406 106 323 407 106 323 minecraft:gray_concrete
setblock 406 106 360 minecraft:polished_deepslate
fill 406 106 361 409 106 361 minecraft:gray_concrete
fill 407 106 360 410 106 360 minecraft:gray_concrete
setblock 408 106 323 minecraft:polished_deepslate
setblock 408 106 363 minecraft:polished_deepslate
fill 409 106 322 409 122 322 minecraft:black_concrete
fill 409 106 323 409 109 323 minecraft:gray_concrete
setblock 409 106 362 minecraft:polished_deepslate
fill 409 106 363 409 109 363 minecraft:gray_concrete
setblock 410 106 322 minecraft:light_blue_stained_glass
setblock 410 106 361 minecraft:polished_deepslate
fill 410 106 362 410 109 362 minecraft:gray_concrete
setblock 411 106 360 minecraft:polished_deepslate
fill 411 106 361 411 109 361 minecraft:gray_concrete
setblock 412 106 323 minecraft:gray_concrete
fill 412 106 360 413 107 360 minecraft:gray_concrete
setblock 413 106 363 minecraft:polished_deepslate
setblock 414 106 356 minecraft:gray_concrete
setblock 414 106 357 minecraft:polished_deepslate
setblock 414 106 358 minecraft:gray_concrete
setblock 414 106 362 minecraft:polished_deepslate
fill 414 106 363 414 109 363 minecraft:gray_concrete
fill 415 106 322 415 122 322 minecraft:black_concrete
setblock 415 106 336 minecraft:polished_deepslate
fill 415 106 337 415 109 337 minecraft:gray_concrete
fill 415 106 339 415 106 340 minecraft:gray_concrete
setblock 415 106 356 minecraft:polished_deepslate
fill 415 106 357 415 108 357 minecraft:gray_concrete
fill 415 106 362 415 109 362 minecraft:gray_concrete
setblock 416 106 335 minecraft:polished_deepslate
fill 416 106 336 416 109 336 minecraft:gray_concrete
setblock 416 106 340 minecraft:polished_deepslate
fill 416 106 341 416 109 341 minecraft:gray_concrete
setblock 416 106 344 minecraft:gray_concrete
setblock 416 106 350 minecraft:polished_deepslate
fill 416 106 351 416 107 351 minecraft:gray_concrete
setblock 416 106 355 minecraft:polished_deepslate
fill 416 106 356 416 109 356 minecraft:gray_concrete
setblock 416 106 360 minecraft:polished_deepslate
fill 416 106 361 416 109 361 minecraft:gray_concrete
setblock 417 106 334 minecraft:polished_deepslate
fill 417 106 335 417 109 335 minecraft:gray_concrete
setblock 417 106 339 minecraft:polished_deepslate
fill 417 106 340 417 109 340 minecraft:gray_concrete
setblock 417 106 344 minecraft:polished_deepslate
fill 417 106 345 417 109 345 minecraft:gray_concrete
setblock 417 106 349 minecraft:polished_deepslate
fill 417 106 350 417 108 350 minecraft:gray_concrete
setblock 417 106 354 minecraft:polished_deepslate
fill 417 106 355 417 109 355 minecraft:gray_concrete
setblock 417 106 359 minecraft:polished_deepslate
fill 417 106 360 417 109 360 minecraft:gray_concrete
setblock 417 106 363 minecraft:gray_concrete
setblock 377 107 329 minecraft:gray_concrete
setblock 377 107 333 minecraft:polished_deepslate
fill 377 107 334 377 107 337 minecraft:gray_concrete
setblock 377 107 338 minecraft:polished_deepslate
fill 377 107 339 377 110 339 minecraft:gray_concrete
setblock 377 107 343 minecraft:polished_deepslate
fill 377 107 344 377 110 344 minecraft:gray_concrete
setblock 377 107 358 minecraft:polished_deepslate
fill 377 107 359 377 109 359 minecraft:gray_concrete
fill 377 107 361 377 108 361 minecraft:gray_concrete
setblock 378 107 332 minecraft:polished_deepslate
fill 378 107 333 378 109 333 minecraft:gray_concrete
setblock 378 107 337 minecraft:polished_deepslate
fill 378 107 338 379 109 338 minecraft:gray_concrete
setblock 378 107 342 minecraft:polished_deepslate
setblock 379 107 335 minecraft:gray_concrete
setblock 379 107 336 minecraft:polished_deepslate
fill 379 107 337 379 109 337 minecraft:gray_concrete
fill 383 107 323 383 110 323 minecraft:gray_concrete
fill 383 107 363 386 107 363 minecraft:gray_concrete
setblock 385 107 324 minecraft:gray_concrete
fill 385 107 362 387 107 362 minecraft:gray_concrete
setblock 386 107 324 minecraft:polished_deepslate
setblock 386 107 364 minecraft:light_blue_stained_glass
setblock 387 107 323 minecraft:polished_deepslate
fill 387 107 324 387 110 324 minecraft:gray_concrete
fill 387 107 361 388 107 361 minecraft:gray_concrete
setblock 387 107 363 minecraft:polished_deepslate
fill 388 107 323 388 110 323 minecraft:gray_concrete
fill 388 107 325 389 107 325 minecraft:gray_concrete
setblock 388 107 362 minecraft:polished_deepslate
fill 388 107 363 388 110 363 minecraft:gray_concrete
setblock 389 107 361 minecraft:polished_deepslate
fill 389 107 362 389 110 362 minecraft:gray_concrete
setblock 390 107 325 minecraft:polished_deepslate
setblock 390 107 360 minecraft:polished_deepslate
fill 390 107 361 393 107 361 minecraft:gray_concrete
setblock 391 107 324 minecraft:polished_deepslate
fill 391 107 325 391 110 325 minecraft:gray_concrete
fill 391 107 332 392 108 332 minecraft:gray_wool
fill 391 107 360 392 109 360 minecraft:gray_concrete
setblock 392 107 323 minecraft:polished_deepslate
fill 392 107 324 392 110 324 minecraft:gray_concrete
setblock 392 107 363 minecraft:polished_deepslate
fill 393 107 323 393 110 323 minecraft:gray_concrete
setblock 393 107 362 minecraft:polished_deepslate
fill 393 107 363 393 110 363 minecraft:gray_concrete
setblock 394 107 361 minecraft:polished_deepslate
fill 394 107 362 394 110 362 minecraft:gray_concrete
fill 395 107 361 395 110 361 minecraft:gray_concrete
setblock 397 107 323 minecraft:polished_deepslate
fill 397 107 361 397 108 361 minecraft:gray_concrete
setblock 397 107 363 minecraft:polished_deepslate
fill 398 107 323 398 110 323 minecraft:gray_concrete
setblock 398 107 362 minecraft:polished_deepslate
fill 398 107 363 401 107 363 minecraft:gray_concrete
fill 399 107 362 402 107 362 minecraft:gray_concrete
fill 402 107 361 403 107 361 minecraft:gray_concrete
setblock 402 107 363 minecraft:polished_deepslate
fill 403 107 327 404 108 328 minecraft:light_gray_wool
setblock 403 107 362 minecraft:polished_deepslate
fill 403 107 363 403 110 363 minecraft:gray_concrete
fill 404 107 323 406 107 323 minecraft:gray_concrete
fill 404 107 329 404 108 329 minecraft:light_gray_wool
setblock 404 107 361 minecraft:polished_deepslate
fill 404 107 362 407 107 362 minecraft:gray_concrete
fill 404 107 364 404 122 364 minecraft:black_concrete
setblock 405 107 360 minecraft:polished_deepslate
fill 405 107 361 408 107 361 minecraft:gray_concrete
fill 406 107 360 409 107 360 minecraft:gray_concrete
setblock 407 107 323 minecraft:polished_deepslate
setblock 407 107 363 minecraft:polished_deepslate
fill 408 107 323 408 110 323 minecraft:gray_concrete
fill 408 107 359 410 107 359 minecraft:gray_concrete
setblock 408 107 362 minecraft:polished_deepslate
fill 408 107 363 408 110 363 minecraft:gray_concrete
setblock 409 107 361 minecraft:polished_deepslate
fill 409 107 362 409 110 362 minecraft:gray_concrete
fill 410 107 322 410 123 322 minecraft:black_concrete
setblock 410 107 360 minecraft:polished_deepslate
fill 410 107 361 410 110 361 minecraft:gray_concrete
fill 411 107 360 411 110 360 minecraft:gray_concrete
setblock 412 107 323 minecraft:polished_deepslate
setblock 412 107 363 minecraft:polished_deepslate
fill 413 107 323 413 110 323 minecraft:gray_concrete
setblock 413 107 362 minecraft:polished_deepslate
fill 413 107 363 413 110 363 minecraft:gray_concrete
setblock 414 107 361 minecraft:polished_deepslate
fill 414 107 362 414 110 362 minecraft:gray_concrete
fill 415 107 336 415 108 336 minecraft:gray_concrete
setblock 415 107 339 minecraft:gray_concrete
setblock 415 107 340 minecraft:polished_deepslate
fill 415 107 341 415 109 342 minecraft:gray_concrete
setblock 415 107 355 minecraft:polished_deepslate
fill 415 107 356 415 108 356 minecraft:gray_concrete
schedule function dropper:buildpart/80_2 1t
