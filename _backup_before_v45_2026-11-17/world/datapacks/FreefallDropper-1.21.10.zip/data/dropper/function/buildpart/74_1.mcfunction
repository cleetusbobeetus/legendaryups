setblock 124 88 323 minecraft:stripped_spruce_log
fill 124 88 328 124 88 363 minecraft:iron_bars
fill 125 88 323 125 89 323 minecraft:stone
setblock 128 88 324 minecraft:stripped_spruce_log
setblock 128 88 363 minecraft:stone
setblock 129 88 323 minecraft:stripped_spruce_log
fill 129 88 324 129 89 324 minecraft:stone
setblock 129 88 363 minecraft:stripped_spruce_log
fill 130 88 323 130 89 323 minecraft:stone
setblock 130 88 362 minecraft:stripped_spruce_log
fill 130 88 363 130 89 363 minecraft:stone
fill 131 88 326 131 88 334 minecraft:iron_bars
fill 131 88 362 131 89 362 minecraft:stone
setblock 132 88 325 minecraft:stripped_spruce_log
setblock 132 88 329 minecraft:stone
setblock 132 88 330 minecraft:stripped_spruce_log
fill 132 88 331 132 89 331 minecraft:stone
fill 132 88 347 132 97 347 minecraft:stripped_spruce_log
setblock 133 88 324 minecraft:stripped_spruce_log
fill 133 88 325 133 89 325 minecraft:stone
setblock 133 88 329 minecraft:stripped_spruce_log
fill 133 88 330 133 91 330 minecraft:stone
setblock 133 88 334 minecraft:stripped_spruce_log
fill 133 88 335 133 90 335 minecraft:stone
fill 133 88 350 133 88 353 minecraft:stone
setblock 133 88 354 minecraft:stripped_spruce_log
fill 133 88 355 133 88 358 minecraft:stone
setblock 133 88 359 minecraft:stripped_spruce_log
fill 133 88 360 133 90 361 minecraft:stone
fill 133 88 364 133 110 364 minecraft:cobbled_deepslate
setblock 134 88 323 minecraft:stripped_spruce_log
setblock 134 88 324 minecraft:glowstone
setblock 134 88 328 minecraft:stripped_spruce_log
fill 134 88 329 134 89 329 minecraft:stone
setblock 134 88 333 minecraft:stripped_spruce_log
fill 134 88 334 134 89 334 minecraft:stone
setblock 134 88 343 minecraft:glowstone
setblock 134 88 347 minecraft:stone
setblock 134 88 348 minecraft:stripped_spruce_log
fill 134 88 349 134 88 352 minecraft:stone
setblock 134 88 353 minecraft:stripped_spruce_log
fill 134 88 354 134 88 357 minecraft:stone
setblock 134 88 358 minecraft:stripped_spruce_log
fill 134 88 359 134 89 359 minecraft:stone
setblock 134 88 362 minecraft:glowstone
setblock 134 88 363 minecraft:stripped_spruce_log
fill 135 88 323 135 89 323 minecraft:stone
setblock 135 88 327 minecraft:stripped_spruce_log
fill 135 88 328 135 89 328 minecraft:stone
setblock 135 88 332 minecraft:stripped_spruce_log
fill 135 88 333 135 89 333 minecraft:stone
setblock 135 88 337 minecraft:stripped_spruce_log
fill 135 88 338 135 89 338 minecraft:stone
setblock 135 88 347 minecraft:stripped_spruce_log
fill 135 88 348 135 88 351 minecraft:stone
setblock 135 88 352 minecraft:stripped_spruce_log
fill 135 88 353 135 89 353 minecraft:stone
setblock 135 88 357 minecraft:stripped_spruce_log
fill 135 88 358 135 89 358 minecraft:stone
setblock 135 88 362 minecraft:stripped_spruce_log
fill 135 88 363 135 89 363 minecraft:stone
fill 136 88 336 136 117 336 minecraft:cobbled_deepslate
fill 94 89 332 94 99 332 minecraft:cobbled_deepslate
fill 94 89 351 94 105 351 minecraft:cobbled_deepslate
setblock 95 89 326 minecraft:stripped_spruce_log
setblock 95 89 327 minecraft:stone
setblock 95 89 331 minecraft:stripped_spruce_log
setblock 95 89 332 minecraft:stone
setblock 95 89 335 minecraft:stone
setblock 95 89 336 minecraft:stripped_spruce_log
setblock 95 89 337 minecraft:stone
setblock 95 89 341 minecraft:stripped_spruce_log
fill 95 89 342 95 89 345 minecraft:stone
setblock 95 89 346 minecraft:stripped_spruce_log
fill 95 89 347 95 89 350 minecraft:stone
setblock 95 89 351 minecraft:stripped_spruce_log
setblock 95 89 352 minecraft:stone
setblock 95 89 356 minecraft:stripped_spruce_log
setblock 95 89 357 minecraft:stone
setblock 95 89 361 minecraft:stripped_spruce_log
setblock 95 89 362 minecraft:stone
fill 96 89 324 96 90 324 minecraft:spruce_log
setblock 96 89 330 minecraft:stripped_spruce_log
setblock 96 89 331 minecraft:stone
setblock 96 89 335 minecraft:stripped_spruce_log
setblock 96 89 336 minecraft:stone
fill 96 89 343 96 90 343 minecraft:spruce_log
fill 96 89 346 96 89 349 minecraft:stone
setblock 96 89 350 minecraft:stripped_spruce_log
setblock 96 89 351 minecraft:stone
setblock 96 89 355 minecraft:stripped_spruce_log
setblock 96 89 356 minecraft:stone
setblock 96 89 360 minecraft:stripped_spruce_log
setblock 96 89 361 minecraft:stone
fill 96 89 362 96 90 362 minecraft:spruce_log
setblock 97 89 349 minecraft:stripped_spruce_log
fill 97 89 350 97 90 350 minecraft:stone
setblock 97 89 354 minecraft:stripped_spruce_log
fill 97 89 355 97 92 355 minecraft:stone
setblock 97 89 359 minecraft:stripped_spruce_log
setblock 98 89 353 minecraft:stripped_spruce_log
setblock 98 89 354 minecraft:stone
setblock 98 89 363 minecraft:stripped_spruce_log
setblock 113 89 323 minecraft:stripped_spruce_log
setblock 113 89 363 minecraft:stripped_spruce_log
fill 114 89 323 117 89 323 minecraft:stone
fill 115 89 324 115 90 324 minecraft:spruce_log
fill 115 89 362 115 90 362 minecraft:spruce_log
fill 117 89 351 117 89 363 minecraft:iron_bars
setblock 118 89 323 minecraft:stripped_spruce_log
setblock 119 89 323 minecraft:stone
fill 124 89 364 127 89 364 minecraft:cobbled_deepslate
setblock 128 89 323 minecraft:stripped_spruce_log
setblock 128 89 324 minecraft:stone
setblock 128 89 363 minecraft:stripped_spruce_log
setblock 128 89 364 minecraft:raw_gold_block
setblock 129 89 323 minecraft:stone
setblock 129 89 363 minecraft:stone
fill 129 89 364 129 122 364 minecraft:cobbled_deepslate
setblock 130 89 362 minecraft:stone
setblock 131 89 325 minecraft:stripped_spruce_log
setblock 132 89 324 minecraft:stripped_spruce_log
setblock 132 89 325 minecraft:stone
setblock 132 89 329 minecraft:stripped_spruce_log
setblock 132 89 330 minecraft:stone
fill 132 89 361 132 91 361 minecraft:stone
setblock 133 89 323 minecraft:stripped_spruce_log
setblock 133 89 324 minecraft:stone
setblock 133 89 328 minecraft:stripped_spruce_log
fill 133 89 329 133 91 329 minecraft:stone
setblock 133 89 333 minecraft:stripped_spruce_log
fill 133 89 334 133 91 334 minecraft:stone
fill 133 89 351 133 89 352 minecraft:stone
setblock 133 89 353 minecraft:stripped_spruce_log
fill 133 89 354 133 89 357 minecraft:stone
setblock 133 89 358 minecraft:stripped_spruce_log
fill 133 89 359 133 92 359 minecraft:stone
setblock 133 89 363 minecraft:stripped_spruce_log
setblock 134 89 323 minecraft:stone
fill 134 89 324 134 90 324 minecraft:spruce_log
setblock 134 89 327 minecraft:stripped_spruce_log
setblock 134 89 328 minecraft:stone
setblock 134 89 332 minecraft:stripped_spruce_log
setblock 134 89 333 minecraft:stone
setblock 134 89 337 minecraft:stripped_spruce_log
fill 134 89 343 134 90 343 minecraft:spruce_log
fill 134 89 348 134 89 351 minecraft:stone
setblock 134 89 352 minecraft:stripped_spruce_log
fill 134 89 353 134 89 356 minecraft:stone
setblock 134 89 357 minecraft:stripped_spruce_log
setblock 134 89 358 minecraft:stone
fill 134 89 362 134 90 362 minecraft:spruce_log
setblock 134 89 363 minecraft:stone
setblock 135 89 326 minecraft:stripped_spruce_log
setblock 135 89 327 minecraft:stone
setblock 135 89 331 minecraft:stripped_spruce_log
setblock 135 89 332 minecraft:stone
setblock 135 89 336 minecraft:stripped_spruce_log
setblock 135 89 337 minecraft:stone
setblock 135 89 340 minecraft:stone
setblock 135 89 346 minecraft:stripped_spruce_log
fill 135 89 347 135 89 350 minecraft:stone
setblock 135 89 351 minecraft:stripped_spruce_log
setblock 135 89 352 minecraft:stone
setblock 135 89 356 minecraft:stripped_spruce_log
setblock 135 89 357 minecraft:stone
setblock 135 89 361 minecraft:stripped_spruce_log
setblock 135 89 362 minecraft:stone
fill 136 89 350 136 122 350 minecraft:cobbled_deepslate
setblock 136 89 351 minecraft:raw_gold_block
fill 136 89 352 136 105 353 minecraft:cobbled_deepslate
setblock 94 90 331 minecraft:raw_iron_block
fill 95 90 323 95 90 363 minecraft:spruce_planks
fill 96 90 323 135 90 323 minecraft:spruce_planks
fill 96 90 325 96 90 342 minecraft:spruce_planks
fill 96 90 344 96 90 361 minecraft:spruce_planks
fill 96 90 363 135 90 363 minecraft:spruce_planks
fill 97 90 324 114 90 324 minecraft:spruce_planks
setblock 97 90 353 minecraft:stripped_spruce_log
fill 97 90 354 97 92 354 minecraft:stone
setblock 97 90 358 minecraft:stripped_spruce_log
setblock 97 90 359 minecraft:stone
fill 97 90 362 114 90 362 minecraft:spruce_planks
setblock 102 90 322 minecraft:raw_gold_block
setblock 106 90 322 minecraft:gold_block
fill 107 90 322 107 125 322 minecraft:cobbled_deepslate
fill 116 90 324 133 90 324 minecraft:spruce_planks
fill 116 90 362 133 90 362 minecraft:spruce_planks
fill 124 90 364 124 98 364 minecraft:cobbled_deepslate
setblock 125 90 364 minecraft:gold_block
fill 126 90 364 128 112 364 minecraft:cobbled_deepslate
fill 127 90 331 130 145 332 minecraft:stripped_spruce_log
fill 128 90 330 129 145 330 minecraft:stripped_spruce_log
fill 128 90 333 129 145 333 minecraft:stripped_spruce_log
fill 131 90 361 131 92 361 minecraft:stone
setblock 133 90 327 minecraft:stripped_spruce_log
setblock 133 90 328 minecraft:stone
setblock 133 90 332 minecraft:stripped_spruce_log
fill 133 90 333 133 91 333 minecraft:stone
setblock 133 90 351 minecraft:stone
setblock 133 90 352 minecraft:stripped_spruce_log
fill 133 90 353 133 90 356 minecraft:stone
setblock 133 90 357 minecraft:stripped_spruce_log
fill 133 90 358 133 93 358 minecraft:stone
fill 134 90 325 135 90 342 minecraft:spruce_planks
fill 134 90 344 135 90 361 minecraft:spruce_planks
setblock 135 90 324 minecraft:spruce_planks
setblock 135 90 343 minecraft:spruce_planks
setblock 135 90 362 minecraft:spruce_planks
fill 136 90 351 136 125 351 minecraft:cobbled_deepslate
setblock 136 90 360 minecraft:raw_gold_block
fill 136 90 361 136 99 363 minecraft:cobbled_deepslate
fill 94 91 331 94 109 331 minecraft:cobbled_deepslate
setblock 95 91 328 minecraft:stone
setblock 95 91 329 minecraft:stripped_spruce_log
fill 95 91 330 95 91 333 minecraft:stone
setblock 95 91 334 minecraft:stripped_spruce_log
fill 95 91 335 95 91 338 minecraft:stone
setblock 95 91 339 minecraft:stripped_spruce_log
fill 95 91 340 95 91 343 minecraft:stone
setblock 95 91 344 minecraft:stripped_spruce_log
fill 95 91 345 95 91 348 minecraft:stone
setblock 95 91 349 minecraft:stripped_spruce_log
fill 95 91 350 95 91 353 minecraft:stone
setblock 95 91 354 minecraft:stripped_spruce_log
fill 95 91 355 95 91 358 minecraft:stone
setblock 95 91 359 minecraft:stripped_spruce_log
fill 95 91 360 95 91 363 minecraft:stone
setblock 96 91 348 minecraft:stripped_spruce_log
fill 96 91 349 96 91 352 minecraft:stone
setblock 96 91 353 minecraft:stripped_spruce_log
fill 96 91 354 96 91 357 minecraft:stone
setblock 96 91 358 minecraft:stripped_spruce_log
fill 96 91 359 96 91 362 minecraft:stone
setblock 96 91 363 minecraft:stripped_spruce_log
setblock 97 91 325 minecraft:light[level=15]
setblock 97 91 332 minecraft:light[level=12]
setblock 97 91 333 minecraft:light[level=15]
setblock 97 91 339 minecraft:light[level=12]
setblock 97 91 341 minecraft:light[level=15]
setblock 97 91 346 minecraft:light[level=12]
setblock 97 91 349 minecraft:light[level=15]
setblock 97 91 352 minecraft:stripped_spruce_log
setblock 97 91 353 minecraft:stone
setblock 97 91 357 minecraft:stripped_spruce_log
setblock 97 91 358 minecraft:stone
setblock 97 91 360 minecraft:light[level=12]
setblock 97 91 363 minecraft:stone
fill 102 91 322 102 125 322 minecraft:cobbled_deepslate
setblock 104 91 325 minecraft:light[level=12]
setblock 104 91 332 minecraft:light[level=12]
setblock 104 91 339 minecraft:light[level=12]
setblock 104 91 346 minecraft:light[level=12]
setblock 104 91 353 minecraft:light[level=12]
setblock 104 91 360 minecraft:light[level=12]
setblock 105 91 325 minecraft:light[level=15]
setblock 105 91 333 minecraft:light[level=15]
setblock 105 91 341 minecraft:light[level=15]
setblock 105 91 349 minecraft:light[level=15]
setblock 105 91 357 minecraft:light[level=15]
fill 106 91 322 106 125 322 minecraft:cobbled_deepslate
setblock 111 91 325 minecraft:light[level=12]
setblock 111 91 332 minecraft:light[level=12]
setblock 111 91 339 minecraft:light[level=12]
setblock 111 91 346 minecraft:light[level=12]
setblock 111 91 353 minecraft:light[level=12]
setblock 111 91 360 minecraft:light[level=12]
fill 112 91 323 115 91 323 minecraft:stone
setblock 113 91 325 minecraft:light[level=15]
setblock 113 91 333 minecraft:light[level=15]
setblock 113 91 341 minecraft:light[level=15]
setblock 113 91 349 minecraft:light[level=15]
setblock 113 91 357 minecraft:light[level=15]
setblock 118 91 325 minecraft:light[level=12]
setblock 118 91 332 minecraft:light[level=12]
setblock 118 91 346 minecraft:light[level=12]
setblock 118 91 353 minecraft:light[level=12]
setblock 118 91 360 minecraft:light[level=12]
setblock 120 91 364 minecraft:diamond_block
setblock 121 91 325 minecraft:light[level=15]
setblock 121 91 333 minecraft:light[level=15]
setblock 121 91 341 minecraft:light[level=15]
setblock 121 91 349 minecraft:light[level=15]
setblock 121 91 357 minecraft:light[level=15]
fill 121 91 364 121 105 364 minecraft:cobbled_deepslate
setblock 125 91 325 minecraft:light[level=12]
setblock 125 91 332 minecraft:light[level=12]
setblock 125 91 339 minecraft:light[level=12]
setblock 125 91 346 minecraft:light[level=12]
setblock 125 91 353 minecraft:light[level=12]
setblock 125 91 360 minecraft:light[level=12]
fill 125 91 364 125 125 364 minecraft:cobbled_deepslate
setblock 126 91 323 minecraft:stripped_spruce_log
fill 126 91 331 126 92 332 minecraft:cobbled_deepslate
fill 127 91 323 130 91 323 minecraft:stone
fill 127 91 330 127 92 330 minecraft:cobbled_deepslate
fill 127 91 333 127 92 333 minecraft:cobbled_deepslate
fill 127 91 363 130 91 363 minecraft:stone
fill 128 91 329 129 92 329 minecraft:cobbled_deepslate
fill 128 91 334 128 92 334 minecraft:cobbled_deepslate
setblock 129 91 324 minecraft:stone
setblock 129 91 325 minecraft:light[level=15]
setblock 129 91 341 minecraft:light[level=15]
fill 129 91 342 131 129 343 minecraft:stripped_spruce_log
setblock 129 91 349 minecraft:light[level=15]
setblock 129 91 357 minecraft:light[level=15]
fill 129 91 362 131 91 362 minecraft:stone
setblock 130 91 324 minecraft:stripped_spruce_log
fill 130 91 330 130 92 330 minecraft:cobbled_deepslate
fill 130 91 333 130 92 333 minecraft:cobbled_deepslate
fill 130 91 341 130 145 341 minecraft:stripped_spruce_log
fill 130 91 344 131 145 344 minecraft:stripped_spruce_log
setblock 131 91 323 minecraft:stripped_spruce_log
fill 131 91 324 134 91 324 minecraft:stone
setblock 131 91 363 minecraft:stripped_spruce_log
fill 132 91 323 135 91 323 minecraft:stone
setblock 132 91 325 minecraft:light[level=12]
setblock 132 91 332 minecraft:light[level=12]
setblock 132 91 339 minecraft:light[level=12]
setblock 132 91 346 minecraft:light[level=12]
setblock 132 91 353 minecraft:light[level=12]
setblock 132 91 360 minecraft:light[level=12]
setblock 132 91 362 minecraft:stripped_spruce_log
fill 132 91 363 135 91 363 minecraft:stone
setblock 133 91 331 minecraft:stripped_spruce_log
fill 133 91 332 135 91 332 minecraft:stone
fill 133 91 352 133 91 355 minecraft:stone
setblock 133 91 356 minecraft:stripped_spruce_log
fill 133 91 357 135 92 357 minecraft:stone
setblock 133 91 360 minecraft:stone
setblock 133 91 361 minecraft:stripped_spruce_log
fill 133 91 362 135 92 362 minecraft:stone
setblock 134 91 325 minecraft:stripped_spruce_log
fill 134 91 326 134 91 329 minecraft:stone
setblock 134 91 330 minecraft:stripped_spruce_log
fill 134 91 331 135 92 331 minecraft:stone
fill 134 91 333 134 91 334 minecraft:stone
setblock 134 91 335 minecraft:stripped_spruce_log
fill 134 91 336 135 91 337 minecraft:stone
setblock 134 91 350 minecraft:stripped_spruce_log
fill 134 91 351 134 91 354 minecraft:stone
setblock 134 91 355 minecraft:stripped_spruce_log
fill 134 91 356 135 93 356 minecraft:stone
fill 134 91 358 134 91 359 minecraft:stone
setblock 134 91 360 minecraft:stripped_spruce_log
fill 134 91 361 135 93 361 minecraft:stone
setblock 135 91 324 minecraft:stripped_spruce_log
fill 135 91 325 135 91 328 minecraft:stone
setblock 135 91 329 minecraft:stripped_spruce_log
fill 135 91 330 135 93 330 minecraft:stone
setblock 135 91 333 minecraft:stone
setblock 135 91 334 minecraft:stripped_spruce_log
fill 135 91 335 135 94 335 minecraft:stone
setblock 135 91 338 minecraft:stone
setblock 135 91 339 minecraft:stripped_spruce_log
setblock 135 91 348 minecraft:stone
setblock 135 91 349 minecraft:stripped_spruce_log
fill 135 91 350 135 91 353 minecraft:stone
setblock 135 91 354 minecraft:stripped_spruce_log
fill 135 91 355 135 94 355 minecraft:stone
setblock 135 91 358 minecraft:stone
setblock 135 91 359 minecraft:stripped_spruce_log
fill 135 91 360 135 94 360 minecraft:stone
setblock 136 91 323 minecraft:raw_iron_block
fill 136 91 324 136 122 324 minecraft:cobbled_deepslate
fill 136 91 360 136 125 360 minecraft:cobbled_deepslate
setblock 94 92 347 minecraft:raw_iron_block
fill 94 92 348 94 98 350 minecraft:cobbled_deepslate
fill 95 92 330 95 92 332 minecraft:stone
setblock 95 92 333 minecraft:stripped_spruce_log
fill 95 92 334 95 92 337 minecraft:stone
setblock 95 92 338 minecraft:stripped_spruce_log
fill 95 92 339 95 93 341 minecraft:stone
fill 95 92 346 95 92 347 minecraft:stone
setblock 95 92 348 minecraft:stripped_spruce_log
fill 95 92 349 95 92 352 minecraft:stone
setblock 95 92 353 minecraft:stripped_spruce_log
fill 95 92 354 95 92 357 minecraft:stone
setblock 95 92 358 minecraft:stripped_spruce_log
fill 95 92 359 95 92 362 minecraft:stone
setblock 95 92 363 minecraft:stripped_spruce_log
fill 96 92 350 96 92 351 minecraft:stone
setblock 96 92 352 minecraft:stripped_spruce_log
fill 96 92 353 96 92 356 minecraft:stone
setblock 96 92 357 minecraft:stripped_spruce_log
fill 96 92 358 96 92 361 minecraft:stone
fill 96 92 363 96 93 363 minecraft:stone
setblock 97 92 356 minecraft:stripped_spruce_log
setblock 97 92 357 minecraft:stone
fill 120 92 364 120 125 364 minecraft:cobbled_deepslate
fill 126 92 323 129 92 323 minecraft:stone
fill 126 92 329 126 92 330 minecraft:cobbled_deepslate
setblock 126 92 333 minecraft:cobbled_deepslate
fill 126 92 363 129 92 363 minecraft:stone
setblock 127 92 329 minecraft:cobbled_deepslate
setblock 127 92 334 minecraft:cobbled_deepslate
fill 128 92 342 128 93 343 minecraft:cobbled_deepslate
fill 128 92 362 130 92 362 minecraft:stone
setblock 129 92 324 minecraft:stripped_spruce_log
fill 129 92 334 130 92 334 minecraft:cobbled_deepslate
fill 129 92 341 129 93 341 minecraft:cobbled_deepslate
fill 129 92 344 129 93 344 minecraft:cobbled_deepslate
setblock 130 92 323 minecraft:stripped_spruce_log
fill 130 92 324 132 92 324 minecraft:stone
setblock 130 92 329 minecraft:cobbled_deepslate
fill 130 92 345 130 93 345 minecraft:cobbled_deepslate
fill 130 92 361 130 93 361 minecraft:stone
setblock 130 92 363 minecraft:stripped_spruce_log
fill 131 92 323 134 92 323 minecraft:stone
fill 131 92 330 131 92 333 minecraft:cobbled_deepslate
fill 131 92 341 131 93 341 minecraft:cobbled_deepslate
setblock 131 92 362 minecraft:stripped_spruce_log
fill 131 92 363 134 92 363 minecraft:stone
fill 132 92 342 132 93 344 minecraft:cobbled_deepslate
setblock 132 92 361 minecraft:stripped_spruce_log
fill 132 92 362 132 95 362 minecraft:stone
fill 133 92 353 133 92 354 minecraft:stone
setblock 133 92 355 minecraft:stripped_spruce_log
fill 133 92 356 133 95 356 minecraft:stone
setblock 133 92 360 minecraft:stripped_spruce_log
fill 133 92 361 133 95 361 minecraft:stone
setblock 134 92 329 minecraft:stripped_spruce_log
setblock 134 92 330 minecraft:stone
fill 134 92 332 134 92 333 minecraft:stone
setblock 134 92 334 minecraft:stripped_spruce_log
fill 134 92 335 134 92 336 minecraft:stone
fill 134 92 351 134 92 353 minecraft:stone
setblock 134 92 354 minecraft:stripped_spruce_log
fill 134 92 355 134 95 355 minecraft:stone
setblock 134 92 358 minecraft:stone
setblock 134 92 359 minecraft:stripped_spruce_log
fill 134 92 360 134 95 360 minecraft:stone
setblock 135 92 323 minecraft:stripped_spruce_log
fill 135 92 324 135 92 327 minecraft:stone
setblock 135 92 328 minecraft:stripped_spruce_log
setblock 135 92 329 minecraft:stone
setblock 135 92 332 minecraft:stone
setblock 135 92 333 minecraft:stripped_spruce_log
fill 135 92 334 135 94 334 minecraft:stone
fill 135 92 336 135 92 337 minecraft:stone
setblock 135 92 338 minecraft:stripped_spruce_log
setblock 135 92 339 minecraft:stone
fill 135 92 349 135 92 352 minecraft:stone
setblock 135 92 353 minecraft:stripped_spruce_log
fill 135 92 354 135 95 354 minecraft:stone
setblock 135 92 358 minecraft:stripped_spruce_log
fill 135 92 359 135 95 359 minecraft:stone
setblock 135 92 363 minecraft:stripped_spruce_log
setblock 136 92 323 minecraft:diamond_block
setblock 136 92 337 minecraft:raw_gold_block
fill 136 92 338 136 121 340 minecraft:cobbled_deepslate
fill 94 93 347 94 109 347 minecraft:cobbled_deepslate
setblock 94 93 357 minecraft:raw_iron_block
fill 94 93 358 94 97 361 minecraft:cobbled_deepslate
setblock 95 93 332 minecraft:stripped_spruce_log
fill 95 93 333 95 93 336 minecraft:stone
setblock 95 93 337 minecraft:stripped_spruce_log
fill 95 93 338 95 96 338 minecraft:stone
setblock 95 93 347 minecraft:stripped_spruce_log
fill 95 93 348 95 93 351 minecraft:stone
setblock 95 93 352 minecraft:stripped_spruce_log
fill 95 93 353 95 93 356 minecraft:stone
setblock 95 93 357 minecraft:stripped_spruce_log
fill 95 93 358 95 93 361 minecraft:stone
setblock 95 93 362 minecraft:stripped_spruce_log
fill 95 93 363 95 96 363 minecraft:stone
setblock 96 93 351 minecraft:stripped_spruce_log
fill 96 93 352 96 93 355 minecraft:stone
setblock 96 93 356 minecraft:stripped_spruce_log
fill 96 93 357 96 93 360 minecraft:stone
fill 97 93 331 97 98 331 minecraft:stripped_spruce_log
fill 100 93 343 102 94 345 minecraft:iron_block
fill 126 93 323 128 93 323 minecraft:stone
fill 126 93 363 128 93 363 minecraft:stone
fill 127 93 362 129 93 362 minecraft:stone
setblock 128 93 341 minecraft:cobbled_deepslate
setblock 128 93 344 minecraft:cobbled_deepslate
setblock 129 93 323 minecraft:stripped_spruce_log
fill 129 93 340 131 93 340 minecraft:cobbled_deepslate
setblock 129 93 345 minecraft:cobbled_deepslate
setblock 129 93 363 minecraft:stripped_spruce_log
fill 130 93 323 133 93 323 minecraft:stone
setblock 130 93 362 minecraft:stripped_spruce_log
fill 130 93 363 133 93 363 minecraft:stone
fill 131 93 322 131 125 322 minecraft:cobbled_deepslate
fill 131 93 345 132 93 345 minecraft:cobbled_deepslate
fill 131 93 347 131 97 347 minecraft:stripped_spruce_log
setblock 131 93 361 minecraft:stripped_spruce_log
fill 131 93 362 131 96 362 minecraft:stone
setblock 132 93 322 minecraft:diamond_block
setblock 132 93 341 minecraft:cobbled_deepslate
fill 132 93 346 132 97 346 minecraft:stripped_spruce_log
fill 132 93 348 132 97 348 minecraft:stripped_spruce_log
fill 132 93 361 132 96 361 minecraft:stone
fill 133 93 322 136 96 322 minecraft:cobbled_deepslate
fill 133 93 342 133 93 343 minecraft:cobbled_deepslate
fill 133 93 347 133 97 347 minecraft:stripped_spruce_log
setblock 133 93 354 minecraft:stripped_spruce_log
fill 133 93 355 133 94 355 minecraft:stone
fill 133 93 357 134 93 357 minecraft:stone
setblock 133 93 359 minecraft:stripped_spruce_log
fill 133 93 360 133 96 360 minecraft:stone
fill 133 93 362 134 93 362 minecraft:stone
setblock 134 93 323 minecraft:stripped_spruce_log
setblock 134 93 333 minecraft:stripped_spruce_log
fill 134 93 334 134 93 335 minecraft:stone
setblock 134 93 352 minecraft:stone
setblock 134 93 353 minecraft:stripped_spruce_log
fill 134 93 354 134 96 354 minecraft:stone
setblock 134 93 358 minecraft:stripped_spruce_log
fill 134 93 359 134 96 359 minecraft:stone
setblock 134 93 363 minecraft:stripped_spruce_log
setblock 135 93 331 minecraft:stone
setblock 135 93 332 minecraft:stripped_spruce_log
fill 135 93 333 135 94 333 minecraft:stone
setblock 135 93 336 minecraft:stone
setblock 135 93 337 minecraft:stripped_spruce_log
fill 135 93 338 135 94 338 minecraft:stone
fill 135 93 350 135 93 351 minecraft:stone
setblock 135 93 352 minecraft:stripped_spruce_log
fill 135 93 353 135 96 353 minecraft:stone
setblock 135 93 357 minecraft:stripped_spruce_log
fill 135 93 358 135 96 358 minecraft:stone
setblock 135 93 362 minecraft:stripped_spruce_log
fill 135 93 363 135 96 363 minecraft:stone
fill 136 93 323 136 124 323 minecraft:cobbled_deepslate
fill 136 93 337 136 125 337 minecraft:cobbled_deepslate
setblock 94 94 334 minecraft:raw_iron_block
fill 94 94 357 94 125 357 minecraft:cobbled_deepslate
fill 95 94 334 95 94 335 minecraft:stone
setblock 95 94 336 minecraft:stripped_spruce_log
fill 95 94 337 95 97 337 minecraft:stone
fill 95 94 339 95 94 340 minecraft:stone
setblock 95 94 341 minecraft:stripped_spruce_log
fill 95 94 349 95 94 350 minecraft:stone
setblock 95 94 351 minecraft:stripped_spruce_log
fill 95 94 352 95 94 355 minecraft:stone
setblock 95 94 356 minecraft:stripped_spruce_log
fill 95 94 357 95 94 360 minecraft:stone
setblock 95 94 361 minecraft:stripped_spruce_log
fill 95 94 362 95 97 362 minecraft:stone
fill 96 94 353 96 94 354 minecraft:stone
setblock 96 94 355 minecraft:stripped_spruce_log
fill 96 94 356 96 94 359 minecraft:stone
setblock 96 94 360 minecraft:stripped_spruce_log
fill 125 94 323 127 94 323 minecraft:stone
fill 125 94 363 127 94 363 minecraft:stone
fill 127 94 362 128 94 362 minecraft:stone
setblock 128 94 323 minecraft:stripped_spruce_log
setblock 128 94 363 minecraft:stripped_spruce_log
fill 129 94 323 132 94 323 minecraft:stone
setblock 129 94 361 minecraft:stone
setblock 129 94 362 minecraft:stripped_spruce_log
fill 129 94 363 132 94 363 minecraft:stone
setblock 130 94 361 minecraft:stripped_spruce_log
fill 130 94 362 130 97 362 minecraft:stone
fill 131 94 361 131 97 361 minecraft:stone
fill 132 94 322 132 97 322 minecraft:cobbled_deepslate
setblock 133 94 323 minecraft:stripped_spruce_log
setblock 133 94 357 minecraft:stone
setblock 133 94 358 minecraft:stripped_spruce_log
fill 133 94 359 133 97 359 minecraft:stone
setblock 133 94 362 minecraft:stone
setblock 133 94 363 minecraft:stripped_spruce_log
fill 134 94 323 134 95 323 minecraft:stone
setblock 134 94 353 minecraft:stone
setblock 134 94 356 minecraft:stone
setblock 134 94 357 minecraft:stripped_spruce_log
fill 134 94 358 134 97 358 minecraft:stone
setblock 134 94 361 minecraft:stone
setblock 134 94 362 minecraft:stripped_spruce_log
fill 134 94 363 134 97 363 minecraft:stone
setblock 135 94 336 minecraft:stripped_spruce_log
fill 135 94 337 135 95 337 minecraft:stone
setblock 135 94 351 minecraft:stripped_spruce_log
fill 135 94 352 135 96 352 minecraft:stone
setblock 135 94 356 minecraft:stripped_spruce_log
fill 135 94 357 135 97 357 minecraft:stone
setblock 135 94 361 minecraft:stripped_spruce_log
fill 135 94 362 135 97 362 minecraft:stone
fill 94 95 334 94 125 334 minecraft:cobbled_deepslate
setblock 94 95 345 minecraft:raw_iron_block
fill 94 95 352 94 99 352 minecraft:cobbled_deepslate
setblock 94 95 353 minecraft:raw_gold_block
fill 94 95 354 94 97 354 minecraft:cobbled_deepslate
setblock 95 95 335 minecraft:stripped_spruce_log
fill 95 95 336 95 98 336 minecraft:stone
setblock 95 95 339 minecraft:stone
setblock 95 95 340 minecraft:stripped_spruce_log
fill 95 95 341 95 97 342 minecraft:stone
setblock 95 95 350 minecraft:stripped_spruce_log
fill 95 95 351 95 95 354 minecraft:stone
setblock 95 95 355 minecraft:stripped_spruce_log
fill 95 95 356 95 95 359 minecraft:stone
setblock 95 95 360 minecraft:stripped_spruce_log
fill 95 95 361 95 98 361 minecraft:stone
setblock 96 95 354 minecraft:stripped_spruce_log
fill 96 95 355 96 95 358 minecraft:stone
setblock 96 95 359 minecraft:stripped_spruce_log
setblock 96 95 360 minecraft:stone
fill 99 95 364 111 102 364 minecraft:cobbled_deepslate
fill 100 95 343 102 95 345 minecraft:raw_gold_block
fill 108 95 363 111 95 363 minecraft:stone
setblock 111 95 323 minecraft:stone
setblock 112 95 363 minecraft:stripped_spruce_log
setblock 112 95 364 minecraft:gold_block
fill 113 95 364 117 99 364 minecraft:cobbled_deepslate
fill 124 95 323 126 95 323 minecraft:stone
fill 124 95 363 126 95 363 minecraft:stone
fill 126 95 362 127 95 362 minecraft:stone
setblock 127 95 323 minecraft:stripped_spruce_log
setblock 127 95 363 minecraft:stripped_spruce_log
fill 128 95 323 131 95 323 minecraft:stone
setblock 128 95 361 minecraft:stone
setblock 128 95 362 minecraft:stripped_spruce_log
fill 128 95 363 131 95 363 minecraft:stone
setblock 129 95 361 minecraft:stripped_spruce_log
fill 129 95 362 129 98 362 minecraft:stone
fill 130 95 361 130 98 361 minecraft:stone
setblock 132 95 323 minecraft:stripped_spruce_log
setblock 132 95 363 minecraft:stripped_spruce_log
fill 133 95 323 133 98 323 minecraft:stone
setblock 133 95 357 minecraft:stripped_spruce_log
fill 133 95 358 133 98 358 minecraft:stone
setblock 133 95 362 minecraft:stripped_spruce_log
fill 133 95 363 133 98 363 minecraft:stone
setblock 134 95 356 minecraft:stripped_spruce_log
fill 134 95 357 134 98 357 minecraft:stone
setblock 134 95 361 minecraft:stripped_spruce_log
fill 134 95 362 134 98 362 minecraft:stone
setblock 135 95 335 minecraft:stripped_spruce_log
setblock 135 95 336 minecraft:stone
setblock 135 95 355 minecraft:stripped_spruce_log
fill 135 95 356 135 98 356 minecraft:stone
setblock 135 95 360 minecraft:stripped_spruce_log
fill 135 95 361 135 98 361 minecraft:stone
fill 94 96 345 94 121 345 minecraft:cobbled_deepslate
setblock 94 96 353 minecraft:diamond_block
setblock 95 96 335 minecraft:stone
setblock 95 96 339 minecraft:stripped_spruce_log
fill 95 96 340 95 99 340 minecraft:stone
setblock 95 96 343 minecraft:stone
fill 95 96 351 95 96 353 minecraft:stone
setblock 95 96 354 minecraft:stripped_spruce_log
fill 95 96 355 95 96 358 minecraft:stone
setblock 95 96 359 minecraft:stripped_spruce_log
fill 95 96 360 95 99 360 minecraft:stone
fill 96 96 331 96 98 331 minecraft:stripped_spruce_log
fill 96 96 356 96 96 357 minecraft:stone
setblock 96 96 358 minecraft:stripped_spruce_log
fill 96 96 359 96 99 359 minecraft:stone
fill 97 96 329 97 110 329 minecraft:iron_bars
fill 97 96 330 97 98 330 minecraft:stripped_spruce_log
fill 97 96 332 97 98 332 minecraft:stripped_spruce_log
fill 98 96 331 98 98 331 minecraft:stripped_spruce_log
setblock 106 96 363 minecraft:stripped_spruce_log
fill 107 96 363 110 96 363 minecraft:stone
fill 109 96 323 110 96 323 minecraft:stone
setblock 111 96 323 minecraft:stripped_spruce_log
setblock 111 96 363 minecraft:stripped_spruce_log
fill 112 96 323 113 98 323 minecraft:stone
fill 112 96 363 113 98 363 minecraft:stone
fill 112 96 364 112 125 364 minecraft:cobbled_deepslate
fill 122 96 363 125 96 363 minecraft:stone
fill 123 96 323 125 96 323 minecraft:stone
fill 124 96 362 126 96 362 minecraft:stone
setblock 126 96 323 minecraft:stripped_spruce_log
fill 126 96 361 127 96 361 minecraft:stone
setblock 126 96 363 minecraft:stripped_spruce_log
fill 127 96 323 129 96 324 minecraft:stone
setblock 127 96 362 minecraft:stripped_spruce_log
fill 127 96 363 130 96 363 minecraft:stone
setblock 128 96 361 minecraft:stripped_spruce_log
fill 128 96 362 128 99 362 minecraft:stone
setblock 129 96 360 minecraft:stripped_spruce_log
fill 129 96 361 129 99 361 minecraft:stone
setblock 130 96 323 minecraft:stone
setblock 130 96 324 minecraft:stripped_spruce_log
fill 130 96 360 131 98 360 minecraft:stone
setblock 131 96 323 minecraft:stripped_spruce_log
fill 131 96 346 131 97 346 minecraft:stripped_spruce_log
fill 131 96 348 131 97 348 minecraft:stripped_spruce_log
setblock 131 96 363 minecraft:stripped_spruce_log
fill 132 96 323 132 99 323 minecraft:stone
setblock 132 96 362 minecraft:stripped_spruce_log
fill 132 96 363 132 99 363 minecraft:stone
fill 133 96 346 133 97 346 minecraft:stripped_spruce_log
fill 133 96 348 133 97 348 minecraft:stripped_spruce_log
setblock 133 96 356 minecraft:stripped_spruce_log
fill 133 96 357 133 99 357 minecraft:stone
setblock 133 96 361 minecraft:stripped_spruce_log
fill 133 96 362 133 99 362 minecraft:stone
setblock 134 96 355 minecraft:stripped_spruce_log
fill 134 96 356 134 99 356 minecraft:stone
setblock 134 96 360 minecraft:stripped_spruce_log
fill 134 96 361 134 99 361 minecraft:stone
setblock 135 96 354 minecraft:stripped_spruce_log
fill 135 96 355 135 99 355 minecraft:stone
setblock 135 96 359 minecraft:stripped_spruce_log
fill 135 96 360 135 99 360 minecraft:stone
fill 94 97 353 94 125 353 minecraft:cobbled_deepslate
setblock 95 97 338 minecraft:stripped_spruce_log
fill 95 97 339 95 100 339 minecraft:stone
setblock 95 97 343 minecraft:stripped_spruce_log
fill 95 97 344 95 99 345 minecraft:stone
fill 95 97 351 95 97 352 minecraft:stone
setblock 95 97 353 minecraft:stripped_spruce_log
fill 95 97 354 95 97 357 minecraft:stone
setblock 95 97 358 minecraft:stripped_spruce_log
fill 95 97 359 95 100 359 minecraft:stone
setblock 95 97 363 minecraft:stripped_spruce_log
fill 96 97 330 96 98 330 minecraft:stripped_spruce_log
fill 96 97 332 96 98 332 minecraft:stripped_spruce_log
setblock 96 97 357 minecraft:stripped_spruce_log
fill 96 97 358 96 98 358 minecraft:stone
fill 96 97 363 96 100 363 minecraft:stone
setblock 97 97 325 minecraft:light[level=12]
setblock 97 97 339 minecraft:light[level=12]
setblock 97 97 346 minecraft:light[level=12]
setblock 97 97 353 minecraft:light[level=12]
setblock 97 97 360 minecraft:light[level=12]
fill 98 97 330 98 98 330 minecraft:stripped_spruce_log
fill 98 97 332 98 98 332 minecraft:stripped_spruce_log
setblock 104 97 325 minecraft:light[level=12]
setblock 104 97 332 minecraft:light[level=12]
setblock 104 97 339 minecraft:light[level=12]
setblock 104 97 346 minecraft:light[level=12]
setblock 104 97 353 minecraft:light[level=12]
setblock 104 97 360 minecraft:light[level=12]
setblock 104 97 363 minecraft:stone
fill 105 97 358 105 102 358 minecraft:stripped_spruce_log
setblock 105 97 363 minecraft:stripped_spruce_log
fill 106 97 363 109 97 363 minecraft:stone
fill 107 97 323 109 97 323 minecraft:stone
fill 107 97 362 110 97 362 minecraft:stone
setblock 110 97 322 minecraft:raw_iron_block
setblock 110 97 323 minecraft:stripped_spruce_log
setblock 110 97 324 minecraft:iron_bars
setblock 110 97 363 minecraft:stripped_spruce_log
fill 111 97 323 111 100 323 minecraft:stone
setblock 111 97 325 minecraft:light[level=12]
setblock 111 97 332 minecraft:light[level=12]
setblock 111 97 339 minecraft:light[level=12]
setblock 111 97 346 minecraft:light[level=12]
setblock 111 97 353 minecraft:light[level=12]
setblock 111 97 360 minecraft:light[level=12]
fill 111 97 363 111 100 363 minecraft:stone
fill 112 97 322 112 121 322 minecraft:cobbled_deepslate
setblock 113 97 322 minecraft:gold_block
fill 114 97 322 114 125 322 minecraft:cobbled_deepslate
setblock 114 97 323 minecraft:stone
setblock 114 97 363 minecraft:stone
setblock 118 97 325 minecraft:light[level=12]
setblock 118 97 332 minecraft:light[level=12]
setblock 118 97 346 minecraft:light[level=12]
setblock 118 97 353 minecraft:light[level=12]
setblock 118 97 360 minecraft:light[level=12]
fill 121 97 323 124 97 323 minecraft:stone
fill 121 97 363 124 97 363 minecraft:stone
fill 123 97 362 125 97 362 minecraft:stone
setblock 125 97 323 minecraft:stripped_spruce_log
fill 125 97 324 128 97 324 minecraft:stone
setblock 125 97 325 minecraft:light[level=12]
setblock 125 97 332 minecraft:light[level=12]
setblock 125 97 339 minecraft:light[level=12]
setblock 125 97 346 minecraft:light[level=12]
setblock 125 97 353 minecraft:light[level=12]
setblock 125 97 360 minecraft:light[level=12]
fill 125 97 361 126 97 361 minecraft:stone
setblock 125 97 363 minecraft:stripped_spruce_log
fill 126 97 323 129 97 323 minecraft:stone
setblock 126 97 362 minecraft:stripped_spruce_log
fill 126 97 363 129 97 363 minecraft:stone
setblock 127 97 361 minecraft:stripped_spruce_log
fill 127 97 362 127 100 362 minecraft:stone
setblock 128 97 360 minecraft:stripped_spruce_log
fill 128 97 361 128 100 361 minecraft:stone
setblock 129 97 324 minecraft:stripped_spruce_log
fill 129 97 360 129 100 360 minecraft:stone
setblock 130 97 323 minecraft:stripped_spruce_log
fill 130 97 324 130 100 324 minecraft:stone
setblock 130 97 363 minecraft:stripped_spruce_log
fill 131 97 323 131 100 323 minecraft:stone
setblock 131 97 362 minecraft:stripped_spruce_log
fill 131 97 363 131 100 363 minecraft:stone
setblock 132 97 325 minecraft:light[level=12]
setblock 132 97 332 minecraft:light[level=12]
setblock 132 97 339 minecraft:light[level=12]
setblock 132 97 353 minecraft:light[level=12]
fill 132 97 359 132 97 360 minecraft:stone
setblock 132 97 361 minecraft:stripped_spruce_log
fill 132 97 362 132 100 362 minecraft:stone
fill 133 97 322 133 123 322 minecraft:cobbled_deepslate
setblock 133 97 356 minecraft:stone
setblock 133 97 360 minecraft:stripped_spruce_log
fill 133 97 361 133 100 361 minecraft:stone
setblock 134 97 322 minecraft:raw_iron_block
setblock 134 97 323 minecraft:stone
fill 134 97 355 134 100 355 minecraft:stone
setblock 134 97 359 minecraft:stripped_spruce_log
fill 134 97 360 134 100 360 minecraft:stone
fill 135 97 322 136 97 322 minecraft:cobbled_deepslate
setblock 135 97 338 minecraft:stripped_spruce_log
fill 135 97 339 135 100 339 minecraft:stone
setblock 135 97 353 minecraft:stripped_spruce_log
fill 135 97 354 135 100 354 minecraft:stone
setblock 135 97 358 minecraft:stripped_spruce_log
fill 135 97 359 135 100 359 minecraft:stone
setblock 135 97 363 minecraft:stripped_spruce_log
setblock 136 97 332 minecraft:raw_iron_block
setblock 94 98 346 minecraft:diamond_block
setblock 94 98 354 minecraft:gold_block
setblock 94 98 358 minecraft:gold_block
fill 94 98 359 94 125 361 minecraft:cobbled_deepslate
setblock 95 98 337 minecraft:stripped_spruce_log
fill 95 98 338 95 101 338 minecraft:stone
setblock 95 98 341 minecraft:stone
setblock 95 98 342 minecraft:stripped_spruce_log
fill 95 98 343 95 101 343 minecraft:stone
setblock 95 98 346 minecraft:stone
setblock 95 98 347 minecraft:stripped_spruce_log
setblock 95 98 352 minecraft:stripped_spruce_log
fill 95 98 353 95 98 356 minecraft:stone
setblock 95 98 357 minecraft:stripped_spruce_log
fill 95 98 358 95 101 358 minecraft:stone
setblock 95 98 362 minecraft:stripped_spruce_log
fill 95 98 363 95 101 363 minecraft:stone
setblock 101 98 322 minecraft:raw_iron_block
fill 102 98 363 103 98 363 minecraft:stone
setblock 104 98 363 minecraft:stripped_spruce_log
fill 105 98 323 108 98 323 minecraft:stone
setblock 105 98 362 minecraft:stripped_spruce_log
fill 105 98 363 108 98 363 minecraft:stone
fill 106 98 362 109 98 362 minecraft:stone
setblock 109 98 323 minecraft:stripped_spruce_log
fill 109 98 324 110 100 324 minecraft:stone
setblock 109 98 363 minecraft:stripped_spruce_log
fill 110 98 322 110 125 322 minecraft:cobbled_deepslate
fill 110 98 323 110 101 323 minecraft:stone
setblock 110 98 362 minecraft:stripped_spruce_log
fill 110 98 363 110 101 363 minecraft:stone
fill 111 98 362 111 101 362 minecraft:stone
fill 113 98 322 113 126 322 minecraft:cobbled_deepslate
setblock 114 98 323 minecraft:stripped_spruce_log
setblock 114 98 363 minecraft:stripped_spruce_log
fill 115 98 323 118 98 323 minecraft:stone
fill 115 98 363 118 98 363 minecraft:stone
setblock 119 98 323 minecraft:stripped_spruce_log
setblock 119 98 363 minecraft:stripped_spruce_log
fill 120 98 323 123 98 323 minecraft:stone
fill 120 98 363 123 98 363 minecraft:stone
fill 122 98 362 124 98 362 minecraft:stone
setblock 123 98 324 minecraft:stripped_spruce_log
setblock 124 98 323 minecraft:stripped_spruce_log
fill 124 98 324 127 98 324 minecraft:stone
fill 124 98 361 125 98 361 minecraft:stone
setblock 124 98 363 minecraft:stripped_spruce_log
fill 125 98 323 128 98 323 minecraft:stone
setblock 125 98 362 minecraft:stripped_spruce_log
fill 125 98 363 128 98 363 minecraft:stone
setblock 126 98 360 minecraft:stone
setblock 126 98 361 minecraft:stripped_spruce_log
fill 126 98 362 126 101 362 minecraft:stone
setblock 127 98 360 minecraft:stripped_spruce_log
fill 127 98 361 127 101 361 minecraft:stone
setblock 128 98 324 minecraft:stripped_spruce_log
fill 128 98 360 128 101 360 minecraft:stone
setblock 129 98 323 minecraft:stripped_spruce_log
fill 129 98 324 129 101 324 minecraft:stone
setblock 129 98 363 minecraft:stripped_spruce_log
fill 130 98 323 130 101 323 minecraft:stone
setblock 130 98 362 minecraft:stripped_spruce_log
fill 130 98 363 130 101 363 minecraft:stone
fill 131 98 324 131 99 324 minecraft:stone
setblock 131 98 361 minecraft:stripped_spruce_log
fill 131 98 362 131 101 362 minecraft:stone
setblock 132 98 322 minecraft:raw_iron_block
setblock 132 98 359 minecraft:stone
setblock 132 98 360 minecraft:stripped_spruce_log
fill 132 98 361 132 101 361 minecraft:stone
setblock 133 98 359 minecraft:stripped_spruce_log
fill 133 98 360 133 101 360 minecraft:stone
fill 134 98 322 134 125 322 minecraft:cobbled_deepslate
setblock 134 98 323 minecraft:stripped_spruce_log
setblock 134 98 358 minecraft:stripped_spruce_log
fill 134 98 359 134 101 359 minecraft:stone
setblock 134 98 363 minecraft:stripped_spruce_log
setblock 135 98 322 minecraft:raw_iron_block
fill 135 98 338 135 101 338 minecraft:stone
fill 135 98 340 135 98 341 minecraft:stone
fill 135 98 353 135 101 353 minecraft:stone
setblock 135 98 357 minecraft:stripped_spruce_log
fill 135 98 358 135 101 358 minecraft:stone
setblock 135 98 362 minecraft:stripped_spruce_log
fill 135 98 363 135 101 363 minecraft:stone
fill 136 98 322 136 125 322 minecraft:cobbled_deepslate
fill 136 98 332 136 121 332 minecraft:cobbled_deepslate
fill 94 99 346 94 125 346 minecraft:cobbled_deepslate
setblock 94 99 348 minecraft:diamond_block
fill 94 99 349 94 125 350 minecraft:cobbled_deepslate
fill 94 99 354 94 121 354 minecraft:cobbled_deepslate
setblock 94 99 358 minecraft:raw_iron_block
setblock 95 99 336 minecraft:stripped_spruce_log
fill 95 99 337 95 102 337 minecraft:stone
setblock 95 99 341 minecraft:stripped_spruce_log
fill 95 99 342 96 101 342 minecraft:stone
setblock 95 99 346 minecraft:stripped_spruce_log
fill 95 99 347 95 100 349 minecraft:stone
setblock 95 99 351 minecraft:stripped_spruce_log
fill 95 99 352 95 99 355 minecraft:stone
setblock 95 99 356 minecraft:stripped_spruce_log
fill 95 99 357 95 102 357 minecraft:stone
setblock 95 99 361 minecraft:stripped_spruce_log
fill 95 99 362 95 102 362 minecraft:stone
setblock 96 99 339 minecraft:stone
setblock 96 99 340 minecraft:stripped_spruce_log
fill 96 99 341 96 102 341 minecraft:stone
setblock 96 99 343 minecraft:stone
setblock 97 99 325 minecraft:light[level=15]
setblock 97 99 333 minecraft:light[level=15]
setblock 97 99 341 minecraft:light[level=15]
setblock 97 99 349 minecraft:light[level=15]
setblock 97 99 357 minecraft:light[level=15]
setblock 97 99 363 minecraft:stone
setblock 98 99 363 minecraft:stripped_spruce_log
fill 99 99 363 102 99 363 minecraft:stone
fill 101 99 322 101 123 322 minecraft:cobbled_deepslate
fill 101 99 341 101 100 341 minecraft:raw_gold_block
setblock 103 99 323 minecraft:stripped_spruce_log
setblock 103 99 362 minecraft:stone
setblock 103 99 363 minecraft:stripped_spruce_log
fill 104 99 323 107 99 323 minecraft:stone
setblock 104 99 362 minecraft:stripped_spruce_log
fill 104 99 363 107 99 363 minecraft:stone
setblock 105 99 325 minecraft:light[level=15]
setblock 105 99 333 minecraft:light[level=15]
setblock 105 99 341 minecraft:light[level=15]
setblock 105 99 349 minecraft:light[level=15]
setblock 105 99 357 minecraft:light[level=15]
fill 105 99 362 108 99 362 minecraft:stone
setblock 106 99 324 minecraft:stone
setblock 107 99 324 minecraft:stripped_spruce_log
setblock 108 99 323 minecraft:stripped_spruce_log
fill 108 99 324 108 102 324 minecraft:stone
setblock 108 99 363 minecraft:stripped_spruce_log
fill 109 99 323 109 102 323 minecraft:stone
setblock 109 99 362 minecraft:stripped_spruce_log
fill 109 99 363 109 102 363 minecraft:stone
fill 110 99 362 110 102 362 minecraft:stone
setblock 111 99 324 minecraft:stone
setblock 112 99 323 minecraft:stone
setblock 112 99 324 minecraft:stripped_spruce_log
fill 112 99 362 112 99 363 minecraft:stone
setblock 113 99 323 minecraft:stripped_spruce_log
setblock 113 99 325 minecraft:light[level=15]
setblock 113 99 333 minecraft:light[level=15]
setblock 113 99 341 minecraft:light[level=15]
setblock 113 99 349 minecraft:light[level=15]
setblock 113 99 357 minecraft:light[level=15]
setblock 113 99 363 minecraft:stripped_spruce_log
fill 114 99 323 117 99 323 minecraft:stone
fill 114 99 363 117 99 363 minecraft:stone
setblock 117 99 322 minecraft:raw_gold_block
fill 118 99 322 119 107 322 minecraft:cobbled_deepslate
setblock 118 99 323 minecraft:stripped_spruce_log
setblock 118 99 363 minecraft:stripped_spruce_log
fill 119 99 323 122 99 323 minecraft:stone
fill 119 99 363 122 99 363 minecraft:stone
fill 120 99 362 123 99 362 minecraft:stone
setblock 121 99 324 minecraft:stone
setblock 121 99 325 minecraft:light[level=15]
setblock 121 99 333 minecraft:light[level=15]
setblock 121 99 341 minecraft:light[level=15]
setblock 121 99 349 minecraft:light[level=15]
setblock 121 99 357 minecraft:light[level=15]
setblock 122 99 324 minecraft:stripped_spruce_log
setblock 123 99 323 minecraft:stripped_spruce_log
fill 123 99 324 126 99 324 minecraft:stone
fill 123 99 361 124 99 361 minecraft:stone
setblock 123 99 363 minecraft:stripped_spruce_log
fill 124 99 323 127 99 323 minecraft:stone
setblock 124 99 362 minecraft:stripped_spruce_log
fill 124 99 363 127 99 363 minecraft:stone
setblock 124 99 364 minecraft:raw_gold_block
setblock 125 99 360 minecraft:stone
setblock 125 99 361 minecraft:stripped_spruce_log
fill 125 99 362 125 102 362 minecraft:stone
fill 126 99 352 128 100 354 minecraft:iron_block
setblock 126 99 360 minecraft:stripped_spruce_log
fill 126 99 361 126 102 361 minecraft:stone
setblock 127 99 324 minecraft:stripped_spruce_log
fill 127 99 360 127 102 360 minecraft:stone
setblock 128 99 323 minecraft:stripped_spruce_log
fill 128 99 324 128 102 324 minecraft:stone
setblock 128 99 363 minecraft:stripped_spruce_log
fill 129 99 323 129 102 323 minecraft:stone
setblock 129 99 325 minecraft:light[level=15]
setblock 129 99 341 minecraft:light[level=15]
setblock 129 99 349 minecraft:light[level=15]
setblock 129 99 357 minecraft:light[level=15]
setblock 129 99 362 minecraft:stripped_spruce_log
fill 129 99 363 129 102 363 minecraft:stone
setblock 130 99 360 minecraft:stone
setblock 130 99 361 minecraft:stripped_spruce_log
fill 130 99 362 130 102 362 minecraft:stone
setblock 131 99 360 minecraft:stripped_spruce_log
fill 131 99 361 131 102 361 minecraft:stone
setblock 132 99 322 minecraft:cobbled_deepslate
setblock 132 99 359 minecraft:stripped_spruce_log
fill 132 99 360 132 100 360 minecraft:stone
setblock 133 99 323 minecraft:stripped_spruce_log
setblock 133 99 358 minecraft:stripped_spruce_log
fill 133 99 359 133 102 359 minecraft:stone
setblock 133 99 363 minecraft:stripped_spruce_log
fill 134 99 323 134 102 323 minecraft:stone
setblock 134 99 357 minecraft:stripped_spruce_log
fill 134 99 358 134 102 358 minecraft:stone
setblock 134 99 362 minecraft:stripped_spruce_log
fill 134 99 363 134 102 363 minecraft:stone
fill 135 99 322 135 105 322 minecraft:cobbled_deepslate
setblock 135 99 340 minecraft:stone
setblock 135 99 341 minecraft:stripped_spruce_log
fill 135 99 342 135 100 344 minecraft:stone
setblock 135 99 356 minecraft:stripped_spruce_log
fill 135 99 357 135 102 357 minecraft:stone
setblock 135 99 361 minecraft:stripped_spruce_log
fill 135 99 362 135 102 362 minecraft:stone
setblock 94 100 332 minecraft:diamond_block
fill 94 100 348 94 125 348 minecraft:cobbled_deepslate
setblock 94 100 352 minecraft:raw_iron_block
fill 94 100 358 94 125 358 minecraft:cobbled_deepslate
fill 95 100 336 95 102 336 minecraft:stone
setblock 95 100 340 minecraft:stripped_spruce_log
fill 95 100 341 95 103 341 minecraft:stone
setblock 95 100 344 minecraft:stone
setblock 95 100 345 minecraft:stripped_spruce_log
fill 95 100 346 95 103 346 minecraft:stone
setblock 95 100 350 minecraft:stripped_spruce_log
fill 95 100 351 95 100 354 minecraft:stone
setblock 95 100 355 minecraft:stripped_spruce_log
fill 95 100 356 95 102 356 minecraft:stone
setblock 95 100 360 minecraft:stripped_spruce_log
fill 95 100 361 95 103 361 minecraft:stone
fill 96 100 324 96 103 324 minecraft:spruce_log
setblock 96 100 338 minecraft:stone
setblock 96 100 339 minecraft:stripped_spruce_log
fill 96 100 340 96 103 340 minecraft:stone
fill 96 100 343 96 103 343 minecraft:spruce_log
setblock 96 100 344 minecraft:stripped_spruce_log
fill 96 100 345 96 103 345 minecraft:stone
fill 96 100 362 96 103 362 minecraft:spruce_log
setblock 97 100 363 minecraft:stripped_spruce_log
fill 98 100 363 101 100 363 minecraft:stone
setblock 102 100 323 minecraft:stripped_spruce_log
setblock 102 100 362 minecraft:stone
setblock 102 100 363 minecraft:stripped_spruce_log
fill 103 100 323 106 100 323 minecraft:stone
setblock 103 100 362 minecraft:stripped_spruce_log
fill 103 100 363 106 100 363 minecraft:stone
fill 104 100 362 107 100 362 minecraft:stone
setblock 105 100 324 minecraft:stone
setblock 106 100 324 minecraft:stripped_spruce_log
fill 106 100 361 108 100 361 minecraft:stone
setblock 107 100 323 minecraft:stripped_spruce_log
fill 107 100 324 107 103 324 minecraft:stone
setblock 107 100 363 minecraft:stripped_spruce_log
fill 108 100 323 108 103 323 minecraft:stone
setblock 108 100 362 minecraft:stripped_spruce_log
fill 108 100 363 108 103 363 minecraft:stone
fill 109 100 362 109 103 362 minecraft:stone
setblock 111 100 324 minecraft:stripped_spruce_log
setblock 112 100 323 minecraft:stripped_spruce_log
fill 112 100 324 114 101 324 minecraft:stone
setblock 112 100 362 minecraft:stone
setblock 112 100 363 minecraft:stripped_spruce_log
fill 113 100 323 116 100 323 minecraft:stone
setblock 113 100 362 minecraft:stripped_spruce_log
fill 113 100 363 116 100 363 minecraft:stone
fill 113 100 364 113 121 364 minecraft:cobbled_deepslate
setblock 114 100 364 minecraft:raw_iron_block
fill 115 100 324 115 103 324 minecraft:spruce_log
fill 115 100 362 115 103 362 minecraft:spruce_log
fill 115 100 364 117 113 364 minecraft:cobbled_deepslate
fill 117 100 322 117 125 322 minecraft:cobbled_deepslate
setblock 117 100 323 minecraft:stripped_spruce_log
setblock 117 100 363 minecraft:stripped_spruce_log
fill 118 100 323 121 100 323 minecraft:stone
fill 118 100 363 121 100 363 minecraft:stone
fill 119 100 324 120 100 324 minecraft:stone
fill 119 100 362 122 100 362 minecraft:stone
setblock 121 100 324 minecraft:stripped_spruce_log
setblock 122 100 323 minecraft:stripped_spruce_log
fill 122 100 324 125 100 324 minecraft:stone
fill 122 100 361 123 100 361 minecraft:stone
setblock 122 100 363 minecraft:stripped_spruce_log
fill 123 100 323 126 100 323 minecraft:stone
setblock 123 100 362 minecraft:stripped_spruce_log
fill 123 100 363 126 100 363 minecraft:stone
setblock 124 100 325 minecraft:stone
setblock 124 100 360 minecraft:stone
setblock 124 100 361 minecraft:stripped_spruce_log
fill 124 100 362 124 103 362 minecraft:stone
fill 124 100 364 124 125 364 minecraft:cobbled_deepslate
setblock 125 100 325 minecraft:stripped_spruce_log
setblock 125 100 360 minecraft:stripped_spruce_log
fill 125 100 361 125 103 361 minecraft:stone
setblock 126 100 324 minecraft:stripped_spruce_log
fill 126 100 325 128 101 325 minecraft:stone
fill 126 100 360 126 103 360 minecraft:stone
setblock 127 100 323 minecraft:stripped_spruce_log
fill 127 100 324 127 103 324 minecraft:stone
setblock 127 100 363 minecraft:stripped_spruce_log
fill 128 100 323 128 103 323 minecraft:stone
setblock 128 100 362 minecraft:stripped_spruce_log
fill 128 100 363 128 103 363 minecraft:stone
setblock 129 100 361 minecraft:stripped_spruce_log
fill 129 100 362 129 103 362 minecraft:stone
setblock 130 100 360 minecraft:stripped_spruce_log
fill 130 100 361 130 103 361 minecraft:stone
setblock 131 100 324 minecraft:stripped_spruce_log
fill 131 100 360 131 102 360 minecraft:stone
setblock 132 100 322 minecraft:raw_iron_block
setblock 132 100 323 minecraft:stripped_spruce_log
fill 132 100 324 132 102 324 minecraft:stone
setblock 132 100 363 minecraft:stripped_spruce_log
fill 133 100 323 133 103 323 minecraft:stone
setblock 133 100 357 minecraft:stripped_spruce_log
fill 133 100 358 133 101 358 minecraft:stone
setblock 133 100 362 minecraft:stripped_spruce_log
fill 133 100 363 133 103 363 minecraft:stone
fill 134 100 324 134 103 324 minecraft:spruce_log
fill 134 100 343 134 103 343 minecraft:spruce_log
setblock 134 100 356 minecraft:stripped_spruce_log
fill 134 100 357 134 102 357 minecraft:stone
setblock 134 100 361 minecraft:stripped_spruce_log
fill 134 100 362 134 103 362 minecraft:spruce_log
fill 135 100 323 135 101 323 minecraft:stone
setblock 135 100 340 minecraft:stripped_spruce_log
fill 135 100 341 135 103 341 minecraft:stone
setblock 135 100 345 minecraft:stripped_spruce_log
fill 135 100 346 135 103 346 minecraft:stone
setblock 135 100 355 minecraft:stripped_spruce_log
fill 135 100 356 135 103 356 minecraft:stone
setblock 135 100 360 minecraft:stripped_spruce_log
fill 135 100 361 135 103 361 minecraft:stone
fill 136 100 361 136 125 361 minecraft:cobbled_deepslate
setblock 136 100 362 minecraft:diamond_block
fill 136 100 363 136 101 363 minecraft:cobbled_deepslate
fill 94 101 332 94 124 332 minecraft:cobbled_deepslate
fill 94 101 352 94 125 352 minecraft:cobbled_deepslate
setblock 95 101 339 minecraft:stripped_spruce_log
fill 95 101 340 95 104 340 minecraft:stone
setblock 95 101 344 minecraft:stripped_spruce_log
fill 95 101 345 95 104 345 minecraft:stone
fill 95 101 347 95 101 348 minecraft:stone
setblock 95 101 349 minecraft:stripped_spruce_log
fill 95 101 350 95 101 353 minecraft:stone
setblock 95 101 354 minecraft:stripped_spruce_log
setblock 95 101 355 minecraft:stone
setblock 95 101 359 minecraft:stripped_spruce_log
fill 95 101 360 95 103 360 minecraft:stone
setblock 96 101 338 minecraft:stripped_spruce_log
fill 96 101 339 96 104 339 minecraft:stone
fill 96 101 344 96 104 344 minecraft:stone
fill 96 101 346 96 102 346 minecraft:stone
setblock 96 101 363 minecraft:stripped_spruce_log
fill 97 101 363 100 101 363 minecraft:stone
fill 98 101 360 98 102 362 minecraft:iron_bars
setblock 100 101 323 minecraft:stone
setblock 101 101 323 minecraft:stripped_spruce_log
fill 101 101 341 101 108 341 minecraft:cobbled_deepslate
setblock 101 101 362 minecraft:stone
setblock 101 101 363 minecraft:stripped_spruce_log
fill 102 101 323 105 101 323 minecraft:stone
setblock 102 101 362 minecraft:stripped_spruce_log
fill 102 101 363 105 101 363 minecraft:stone
fill 103 101 324 104 101 324 minecraft:stone
fill 103 101 362 106 101 362 minecraft:stone
fill 104 101 358 104 102 358 minecraft:stripped_spruce_log
setblock 105 101 324 minecraft:stripped_spruce_log
fill 105 101 357 105 102 357 minecraft:stripped_spruce_log
fill 105 101 359 105 102 359 minecraft:stripped_spruce_log
fill 105 101 361 107 101 361 minecraft:stone
setblock 106 101 323 minecraft:stripped_spruce_log
fill 106 101 324 106 104 324 minecraft:stone
fill 106 101 358 106 102 358 minecraft:stripped_spruce_log
setblock 106 101 363 minecraft:stripped_spruce_log
fill 107 101 323 107 104 323 minecraft:stone
fill 107 101 325 108 101 325 minecraft:stone
setblock 107 101 362 minecraft:stripped_spruce_log
fill 107 101 363 107 104 363 minecraft:stone
setblock 108 101 361 minecraft:stripped_spruce_log
fill 108 101 362 108 104 362 minecraft:stone
setblock 109 101 324 minecraft:stone
setblock 109 101 325 minecraft:stripped_spruce_log
setblock 110 101 324 minecraft:stripped_spruce_log
setblock 111 101 323 minecraft:stripped_spruce_log
fill 111 101 324 111 104 324 minecraft:stone
setblock 111 101 363 minecraft:stripped_spruce_log
fill 112 101 323 115 101 323 minecraft:stone
setblock 112 101 362 minecraft:stripped_spruce_log
fill 112 101 363 115 101 363 minecraft:stone
setblock 113 101 362 minecraft:stone
fill 114 101 364 114 106 364 minecraft:cobbled_deepslate
setblock 116 101 323 minecraft:stripped_spruce_log
fill 116 101 324 119 101 324 minecraft:stone
setblock 116 101 363 minecraft:stripped_spruce_log
fill 117 101 323 120 101 323 minecraft:stone
fill 117 101 363 120 101 363 minecraft:stone
fill 118 101 362 121 101 362 minecraft:stone
setblock 120 101 324 minecraft:stripped_spruce_log
setblock 121 101 323 minecraft:stripped_spruce_log
fill 121 101 324 124 101 324 minecraft:stone
fill 121 101 361 122 101 361 minecraft:stone
setblock 121 101 363 minecraft:stripped_spruce_log
fill 122 101 323 125 101 323 minecraft:stone
fill 122 101 325 123 101 325 minecraft:stone
setblock 122 101 362 minecraft:stripped_spruce_log
fill 122 101 363 125 101 363 minecraft:stone
fill 123 101 322 124 122 322 minecraft:cobbled_deepslate
setblock 123 101 361 minecraft:stripped_spruce_log
fill 123 101 362 123 104 362 minecraft:stone
setblock 124 101 325 minecraft:stripped_spruce_log
setblock 124 101 360 minecraft:stripped_spruce_log
fill 124 101 361 124 104 361 minecraft:stone
setblock 125 101 322 minecraft:gold_block
setblock 125 101 324 minecraft:stripped_spruce_log
fill 125 101 325 125 104 325 minecraft:stone
fill 125 101 360 125 104 360 minecraft:stone
fill 126 101 322 127 121 322 minecraft:cobbled_deepslate
setblock 126 101 323 minecraft:stripped_spruce_log
fill 126 101 324 126 104 324 minecraft:stone
fill 126 101 352 128 101 354 minecraft:raw_gold_block
setblock 126 101 363 minecraft:stripped_spruce_log
fill 127 101 323 127 104 323 minecraft:stone
setblock 127 101 362 minecraft:stripped_spruce_log
fill 127 101 363 127 104 363 minecraft:stone
setblock 128 101 361 minecraft:stripped_spruce_log
fill 128 101 362 128 104 362 minecraft:stone
setblock 129 101 325 minecraft:stripped_spruce_log
setblock 129 101 360 minecraft:stripped_spruce_log
fill 129 101 361 129 104 361 minecraft:stone
setblock 130 101 324 minecraft:stripped_spruce_log
fill 130 101 360 130 102 360 minecraft:stone
setblock 131 101 323 minecraft:stripped_spruce_log
fill 131 101 324 131 104 324 minecraft:stone
setblock 131 101 363 minecraft:stripped_spruce_log
fill 132 101 322 132 121 322 minecraft:cobbled_deepslate
fill 132 101 323 132 104 323 minecraft:stone
setblock 132 101 362 minecraft:stripped_spruce_log
fill 132 101 363 132 104 363 minecraft:stone
setblock 133 101 361 minecraft:stripped_spruce_log
fill 133 101 362 133 104 362 minecraft:stone
setblock 134 101 356 minecraft:stone
setblock 134 101 360 minecraft:stripped_spruce_log
fill 134 101 361 134 104 361 minecraft:stone
setblock 135 101 339 minecraft:stripped_spruce_log
fill 135 101 340 135 104 340 minecraft:stone
fill 135 101 342 135 101 343 minecraft:stone
setblock 135 101 344 minecraft:stripped_spruce_log
fill 135 101 345 135 104 345 minecraft:stone
fill 135 101 347 135 101 348 minecraft:stone
setblock 135 101 354 minecraft:stripped_spruce_log
fill 135 101 355 135 103 355 minecraft:stone
setblock 135 101 359 minecraft:stripped_spruce_log
fill 135 101 360 135 104 360 minecraft:stone
fill 136 101 362 136 125 362 minecraft:cobbled_deepslate
setblock 95 102 338 minecraft:stripped_spruce_log
fill 95 102 339 95 105 339 minecraft:stone
setblock 95 102 342 minecraft:stone
setblock 95 102 343 minecraft:stripped_spruce_log
fill 95 102 344 95 105 344 minecraft:stone
setblock 95 102 347 minecraft:stone
setblock 95 102 348 minecraft:stripped_spruce_log
fill 95 102 349 95 103 351 minecraft:stone
setblock 95 102 358 minecraft:stripped_spruce_log
fill 95 102 359 95 103 359 minecraft:stone
setblock 95 102 363 minecraft:stripped_spruce_log
setblock 96 102 338 minecraft:stone
setblock 96 102 342 minecraft:stripped_spruce_log
setblock 96 102 347 minecraft:stripped_spruce_log
fill 96 102 363 99 102 363 minecraft:stone
setblock 97 102 341 minecraft:stripped_spruce_log
fill 97 102 342 97 103 344 minecraft:stone
setblock 99 102 323 minecraft:stone
setblock 100 102 323 minecraft:stripped_spruce_log
setblock 100 102 362 minecraft:stone
setblock 100 102 363 minecraft:stripped_spruce_log
fill 101 102 323 104 102 323 minecraft:stone
setblock 101 102 362 minecraft:stripped_spruce_log
fill 101 102 363 104 102 363 minecraft:stone
fill 102 102 324 103 102 324 minecraft:stone
fill 102 102 362 105 102 362 minecraft:stone
setblock 104 102 324 minecraft:stripped_spruce_log
setblock 105 102 323 minecraft:stripped_spruce_log
fill 105 102 324 105 104 325 minecraft:stone
fill 105 102 361 106 102 361 minecraft:stone
setblock 105 102 363 minecraft:stripped_spruce_log
fill 106 102 323 106 105 323 minecraft:stone
fill 106 102 325 107 102 325 minecraft:stone
setblock 106 102 362 minecraft:stripped_spruce_log
fill 106 102 363 106 105 363 minecraft:stone
fill 107 102 359 107 107 359 minecraft:cobbled_deepslate
fill 107 102 362 107 105 362 minecraft:stone
setblock 108 102 325 minecraft:stripped_spruce_log
setblock 109 102 324 minecraft:stripped_spruce_log
fill 109 102 325 110 104 325 minecraft:stone
setblock 110 102 323 minecraft:stripped_spruce_log
fill 110 102 324 110 105 324 minecraft:stone
setblock 110 102 363 minecraft:stripped_spruce_log
fill 111 102 323 114 102 323 minecraft:stone
setblock 111 102 362 minecraft:stripped_spruce_log
fill 111 102 363 114 102 363 minecraft:stone
fill 112 102 324 113 102 324 minecraft:stone
setblock 112 102 362 minecraft:stone
setblock 114 102 324 minecraft:stripped_spruce_log
setblock 115 102 323 minecraft:stripped_spruce_log
setblock 115 102 363 minecraft:stripped_spruce_log
fill 116 102 323 118 102 324 minecraft:stone
fill 116 102 363 119 102 363 minecraft:stone
fill 117 102 362 120 102 362 minecraft:stone
setblock 119 102 323 minecraft:stone
setblock 119 102 324 minecraft:stripped_spruce_log
setblock 120 102 323 minecraft:stripped_spruce_log
fill 120 102 324 123 102 324 minecraft:stone
setblock 120 102 363 minecraft:stripped_spruce_log
fill 121 102 323 124 102 323 minecraft:stone
fill 121 102 325 122 102 325 minecraft:stone
setblock 121 102 361 minecraft:stone
setblock 121 102 362 minecraft:stripped_spruce_log
fill 121 102 363 124 102 363 minecraft:stone
setblock 122 102 361 minecraft:stripped_spruce_log
fill 122 102 362 122 105 362 minecraft:stone
setblock 122 102 364 minecraft:raw_gold_block
setblock 123 102 325 minecraft:stripped_spruce_log
fill 123 102 361 123 105 361 minecraft:stone
setblock 124 102 324 minecraft:stripped_spruce_log
fill 124 102 325 124 105 325 minecraft:stone
fill 124 102 360 124 104 360 minecraft:stone
fill 125 102 322 125 125 322 minecraft:cobbled_deepslate
setblock 125 102 323 minecraft:stripped_spruce_log
fill 125 102 324 125 105 324 minecraft:stone
setblock 125 102 363 minecraft:stripped_spruce_log
fill 126 102 323 126 105 323 minecraft:stone
fill 126 102 325 127 102 325 minecraft:stone
setblock 126 102 362 minecraft:stripped_spruce_log
fill 126 102 363 126 105 363 minecraft:stone
setblock 127 102 361 minecraft:stripped_spruce_log
fill 127 102 362 127 105 362 minecraft:stone
setblock 128 102 325 minecraft:stripped_spruce_log
setblock 128 102 360 minecraft:stripped_spruce_log
fill 128 102 361 128 105 361 minecraft:stone
setblock 129 102 324 minecraft:stripped_spruce_log
setblock 129 102 325 minecraft:stone
fill 129 102 360 129 103 360 minecraft:stone
setblock 130 102 322 minecraft:raw_gold_block
setblock 130 102 323 minecraft:stripped_spruce_log
fill 130 102 324 130 105 324 minecraft:stone
setblock 130 102 363 minecraft:stripped_spruce_log
fill 131 102 323 131 105 323 minecraft:stone
setblock 131 102 362 minecraft:stripped_spruce_log
fill 131 102 363 131 105 363 minecraft:stone
setblock 132 102 361 minecraft:stripped_spruce_log
fill 132 102 362 132 105 362 minecraft:stone
setblock 133 102 360 minecraft:stripped_spruce_log
fill 133 102 361 133 103 361 minecraft:stone
setblock 134 102 359 minecraft:stripped_spruce_log
fill 134 102 360 134 104 360 minecraft:stone
setblock 135 102 323 minecraft:stripped_spruce_log
fill 135 102 339 135 103 339 minecraft:stone
setblock 135 102 342 minecraft:stone
setblock 135 102 343 minecraft:stripped_spruce_log
fill 135 102 344 135 105 344 minecraft:stone
setblock 135 102 347 minecraft:stone
setblock 135 102 348 minecraft:stripped_spruce_log
fill 135 102 349 135 104 350 minecraft:stone
setblock 135 102 353 minecraft:stripped_spruce_log
fill 135 102 354 135 103 354 minecraft:stone
setblock 135 102 358 minecraft:stripped_spruce_log
fill 135 102 359 135 105 359 minecraft:stone
setblock 135 102 363 minecraft:stripped_spruce_log
setblock 136 102 363 minecraft:raw_gold_block
setblock 95 103 337 minecraft:stripped_spruce_log
fill 95 103 338 95 105 338 minecraft:stone
setblock 95 103 342 minecraft:stripped_spruce_log
fill 95 103 343 95 105 343 minecraft:stone
setblock 95 103 347 minecraft:stripped_spruce_log
fill 95 103 348 95 105 348 minecraft:stone
setblock 95 103 358 minecraft:stone
setblock 95 103 362 minecraft:stripped_spruce_log
fill 95 103 363 98 103 363 minecraft:stone
setblock 96 103 341 minecraft:stripped_spruce_log
fill 96 103 342 96 105 342 minecraft:stone
setblock 96 103 346 minecraft:stripped_spruce_log
fill 96 103 347 96 105 347 minecraft:stone
setblock 97 103 325 minecraft:light[level=12]
setblock 97 103 332 minecraft:light[level=12]
setblock 97 103 339 minecraft:light[level=12]
fill 97 103 341 97 104 341 minecraft:stone
setblock 97 103 345 minecraft:stripped_spruce_log
setblock 97 103 346 minecraft:light[level=12]
setblock 97 103 353 minecraft:light[level=12]
setblock 97 103 360 minecraft:light[level=12]
setblock 98 103 323 minecraft:stone
setblock 99 103 323 minecraft:stripped_spruce_log
setblock 99 103 363 minecraft:stripped_spruce_log
fill 99 103 364 105 114 364 minecraft:cobbled_deepslate
fill 100 103 323 103 103 323 minecraft:stone
fill 100 103 341 100 108 341 minecraft:cobbled_deepslate
setblock 100 103 362 minecraft:stripped_spruce_log
fill 100 103 363 103 103 363 minecraft:stone
fill 101 103 324 102 103 324 minecraft:stone
fill 101 103 340 101 108 340 minecraft:cobbled_deepslate
fill 101 103 342 101 108 342 minecraft:cobbled_deepslate
fill 101 103 362 104 103 362 minecraft:stone
setblock 103 103 322 minecraft:gold_block
setblock 103 103 324 minecraft:stripped_spruce_log
fill 104 103 322 104 125 322 minecraft:cobbled_deepslate
setblock 104 103 323 minecraft:stripped_spruce_log
fill 104 103 324 104 105 325 minecraft:stone
setblock 104 103 332 minecraft:light[level=12]
setblock 104 103 339 minecraft:light[level=12]
setblock 104 103 346 minecraft:light[level=12]
setblock 104 103 353 minecraft:light[level=12]
setblock 104 103 360 minecraft:light[level=12]
setblock 104 103 363 minecraft:stripped_spruce_log
fill 105 103 323 105 105 323 minecraft:stone
setblock 105 103 362 minecraft:stripped_spruce_log
fill 105 103 363 105 105 363 minecraft:stone
setblock 106 103 325 minecraft:stone
fill 106 103 362 106 105 362 minecraft:stone
setblock 106 103 364 minecraft:gold_block
setblock 107 103 325 minecraft:stripped_spruce_log
fill 107 103 364 111 107 364 minecraft:cobbled_deepslate
setblock 108 103 324 minecraft:stripped_spruce_log
fill 108 103 325 108 106 325 minecraft:stone
setblock 109 103 323 minecraft:stripped_spruce_log
fill 109 103 324 109 105 324 minecraft:stone
setblock 109 103 363 minecraft:stripped_spruce_log
fill 110 103 323 113 103 323 minecraft:stone
setblock 110 103 362 minecraft:stripped_spruce_log
fill 110 103 363 113 103 363 minecraft:stone
setblock 111 103 325 minecraft:light[level=12]
setblock 111 103 332 minecraft:light[level=12]
setblock 111 103 339 minecraft:light[level=12]
setblock 111 103 346 minecraft:light[level=12]
setblock 111 103 353 minecraft:light[level=12]
setblock 111 103 360 minecraft:light[level=12]
setblock 111 103 362 minecraft:stone
setblock 112 103 324 minecraft:stone
setblock 113 103 324 minecraft:stripped_spruce_log
setblock 114 103 323 minecraft:stripped_spruce_log
fill 114 103 324 114 105 324 minecraft:stone
setblock 114 103 363 minecraft:stripped_spruce_log
fill 115 103 323 118 103 323 minecraft:stone
fill 115 103 363 118 103 363 minecraft:stone
fill 116 103 324 117 103 324 minecraft:stone
fill 117 103 362 119 103 362 minecraft:stone
setblock 118 103 324 minecraft:stripped_spruce_log
setblock 118 103 325 minecraft:light[level=12]
setblock 118 103 332 minecraft:light[level=12]
setblock 118 103 346 minecraft:light[level=12]
setblock 118 103 353 minecraft:light[level=12]
setblock 118 103 360 minecraft:light[level=12]
setblock 119 103 323 minecraft:stripped_spruce_log
fill 119 103 324 122 103 324 minecraft:stone
setblock 119 103 363 minecraft:stripped_spruce_log
fill 120 103 323 123 103 323 minecraft:stone
fill 120 103 325 121 103 325 minecraft:stone
setblock 120 103 362 minecraft:stripped_spruce_log
fill 120 103 363 123 103 363 minecraft:stone
setblock 121 103 361 minecraft:stripped_spruce_log
fill 121 103 362 121 105 362 minecraft:stone
setblock 122 103 325 minecraft:stripped_spruce_log
fill 122 103 361 122 106 361 minecraft:stone
fill 122 103 364 122 126 364 minecraft:cobbled_deepslate
setblock 123 103 324 minecraft:stripped_spruce_log
fill 123 103 325 123 106 325 minecraft:stone
setblock 124 103 323 minecraft:stripped_spruce_log
fill 124 103 324 124 105 324 minecraft:stone
setblock 124 103 363 minecraft:stripped_spruce_log
fill 125 103 323 125 105 323 minecraft:stone
setblock 125 103 332 minecraft:light[level=12]
setblock 125 103 339 minecraft:light[level=12]
setblock 125 103 346 minecraft:light[level=12]
setblock 125 103 353 minecraft:light[level=12]
setblock 125 103 362 minecraft:stripped_spruce_log
fill 125 103 363 125 105 363 minecraft:stone
setblock 126 103 325 minecraft:stone
setblock 126 103 361 minecraft:stripped_spruce_log
fill 126 103 362 126 105 362 minecraft:stone
setblock 127 103 325 minecraft:stripped_spruce_log
setblock 127 103 360 minecraft:stripped_spruce_log
fill 127 103 361 127 106 361 minecraft:stone
setblock 128 103 324 minecraft:stripped_spruce_log
fill 128 103 325 128 104 325 minecraft:stone
setblock 128 103 360 minecraft:stone
setblock 129 103 323 minecraft:stripped_spruce_log
fill 129 103 324 129 105 324 minecraft:stone
setblock 129 103 363 minecraft:stripped_spruce_log
fill 130 103 322 130 123 322 minecraft:cobbled_deepslate
fill 130 103 323 130 105 323 minecraft:stone
setblock 130 103 362 minecraft:stripped_spruce_log
fill 130 103 363 130 105 363 minecraft:stone
setblock 131 103 361 minecraft:stripped_spruce_log
fill 131 103 362 131 105 362 minecraft:stone
setblock 132 103 325 minecraft:light[level=12]
setblock 132 103 332 minecraft:light[level=12]
setblock 132 103 339 minecraft:light[level=12]
setblock 132 103 346 minecraft:light[level=12]
setblock 132 103 353 minecraft:light[level=12]
setblock 132 103 360 minecraft:light[level=12]
setblock 132 103 361 minecraft:stone
setblock 134 103 323 minecraft:stripped_spruce_log
setblock 134 103 344 minecraft:stone
setblock 134 103 358 minecraft:stripped_spruce_log
setblock 134 103 359 minecraft:stone
setblock 134 103 363 minecraft:stripped_spruce_log
fill 135 103 323 135 105 323 minecraft:stone
setblock 135 103 342 minecraft:stripped_spruce_log
fill 135 103 343 135 105 343 minecraft:stone
setblock 135 103 347 minecraft:stripped_spruce_log
fill 135 103 348 135 105 348 minecraft:stone
setblock 135 103 351 minecraft:stone
setblock 135 103 357 minecraft:stripped_spruce_log
fill 135 103 358 135 105 358 minecraft:stone
setblock 135 103 362 minecraft:stripped_spruce_log
fill 135 103 363 135 105 363 minecraft:stone
fill 136 103 363 136 125 363 minecraft:cobbled_deepslate
setblock 95 104 337 minecraft:stone
setblock 95 104 341 minecraft:stripped_spruce_log
fill 95 104 342 95 105 342 minecraft:stone
setblock 95 104 346 minecraft:stripped_spruce_log
fill 95 104 347 95 105 347 minecraft:stone
fill 95 104 349 95 104 350 minecraft:stone
setblock 95 104 361 minecraft:stripped_spruce_log
fill 95 104 362 95 104 363 minecraft:stone
setblock 96 104 324 minecraft:glowstone
setblock 96 104 340 minecraft:stripped_spruce_log
fill 96 104 341 96 105 341 minecraft:stone
setblock 96 104 343 minecraft:glowstone
setblock 96 104 345 minecraft:stripped_spruce_log
fill 96 104 346 96 105 346 minecraft:stone
fill 96 104 348 96 105 348 minecraft:stone
setblock 96 104 362 minecraft:glowstone
fill 96 104 363 97 104 363 minecraft:stone
setblock 97 104 323 minecraft:stone
fill 97 104 342 97 104 343 minecraft:stone
setblock 97 104 344 minecraft:stripped_spruce_log
fill 97 104 345 97 107 345 minecraft:stone
setblock 98 104 323 minecraft:stripped_spruce_log
setblock 98 104 363 minecraft:stripped_spruce_log
fill 99 104 323 102 104 323 minecraft:stone
fill 99 104 363 102 104 363 minecraft:stone
fill 100 104 324 101 104 324 minecraft:stone
fill 100 104 340 100 108 340 minecraft:cobbled_deepslate
fill 100 104 342 100 108 342 minecraft:cobbled_deepslate
fill 101 104 362 103 104 362 minecraft:stone
setblock 102 104 324 minecraft:stripped_spruce_log
fill 102 104 340 102 108 341 minecraft:cobbled_deepslate
fill 103 104 322 103 122 322 minecraft:cobbled_deepslate
setblock 103 104 323 minecraft:stripped_spruce_log
fill 103 104 324 103 105 325 minecraft:stone
setblock 103 104 363 minecraft:stripped_spruce_log
fill 104 104 323 104 105 323 minecraft:stone
setblock 104 104 362 minecraft:stripped_spruce_log
fill 104 104 363 104 105 363 minecraft:stone
fill 105 104 362 105 105 362 minecraft:stone
setblock 106 104 325 minecraft:stripped_spruce_log
fill 106 104 364 106 125 364 minecraft:cobbled_deepslate
setblock 107 104 324 minecraft:stripped_spruce_log
fill 107 104 325 107 107 325 minecraft:stone
setblock 108 104 323 minecraft:stripped_spruce_log
fill 108 104 324 108 105 324 minecraft:stone
setblock 108 104 363 minecraft:stripped_spruce_log
fill 109 104 323 112 104 323 minecraft:stone
setblock 109 104 362 minecraft:stripped_spruce_log
fill 109 104 363 112 104 363 minecraft:stone
setblock 112 104 324 minecraft:stripped_spruce_log
setblock 113 104 323 minecraft:stripped_spruce_log
fill 113 104 324 113 105 324 minecraft:stone
setblock 113 104 363 minecraft:stripped_spruce_log
fill 114 104 323 117 104 323 minecraft:stone
fill 114 104 363 117 104 363 minecraft:stone
setblock 115 104 322 minecraft:raw_gold_block
setblock 115 104 324 minecraft:glowstone
setblock 115 104 362 minecraft:glowstone
setblock 116 104 324 minecraft:stone
setblock 117 104 324 minecraft:stripped_spruce_log
fill 117 104 362 118 104 362 minecraft:stone
setblock 118 104 323 minecraft:stripped_spruce_log
fill 118 104 324 121 104 324 minecraft:stone
setblock 118 104 363 minecraft:stripped_spruce_log
fill 119 104 323 122 104 323 minecraft:stone
fill 119 104 325 120 104 325 minecraft:stone
setblock 119 104 362 minecraft:stripped_spruce_log
fill 119 104 363 122 104 363 minecraft:stone
fill 120 104 362 120 105 362 minecraft:stone
setblock 121 104 325 minecraft:stripped_spruce_log
fill 121 104 361 121 106 361 minecraft:stone
setblock 122 104 324 minecraft:stripped_spruce_log
fill 122 104 325 122 107 325 minecraft:stone
setblock 123 104 323 minecraft:stripped_spruce_log
fill 123 104 324 123 105 324 minecraft:stone
setblock 123 104 363 minecraft:stripped_spruce_log
fill 124 104 323 124 105 323 minecraft:stone
setblock 124 104 362 minecraft:stripped_spruce_log
fill 124 104 363 124 105 363 minecraft:stone
setblock 125 104 361 minecraft:stripped_spruce_log
fill 125 104 362 125 105 362 minecraft:stone
setblock 126 104 325 minecraft:stripped_spruce_log
setblock 126 104 360 minecraft:stripped_spruce_log
fill 126 104 361 126 107 361 minecraft:stone
setblock 127 104 324 minecraft:stripped_spruce_log
fill 127 104 325 127 106 325 minecraft:stone
setblock 127 104 360 minecraft:stone
setblock 128 104 323 minecraft:stripped_spruce_log
fill 128 104 324 128 105 324 minecraft:stone
setblock 128 104 363 minecraft:stripped_spruce_log
fill 129 104 323 129 105 323 minecraft:stone
setblock 129 104 362 minecraft:stripped_spruce_log
fill 129 104 363 129 105 363 minecraft:stone
setblock 130 104 361 minecraft:stripped_spruce_log
fill 130 104 362 130 105 362 minecraft:stone
setblock 131 104 361 minecraft:stone
setblock 133 104 323 minecraft:stripped_spruce_log
setblock 133 104 363 minecraft:stripped_spruce_log
fill 134 104 323 134 105 323 minecraft:stone
setblock 134 104 324 minecraft:glowstone
setblock 134 104 343 minecraft:glowstone
setblock 134 104 362 minecraft:glowstone
fill 134 104 363 134 105 363 minecraft:stone
setblock 135 104 341 minecraft:stripped_spruce_log
fill 135 104 342 135 105 342 minecraft:stone
setblock 135 104 346 minecraft:stripped_spruce_log
fill 135 104 347 135 105 347 minecraft:stone
setblock 135 104 351 minecraft:stripped_spruce_log
setblock 135 104 356 minecraft:stripped_spruce_log
setblock 135 104 357 minecraft:stone
setblock 135 104 361 minecraft:stripped_spruce_log
fill 135 104 362 135 105 362 minecraft:stone
setblock 95 105 322 minecraft:gold_block
setblock 95 105 340 minecraft:stripped_spruce_log
setblock 95 105 341 minecraft:stone
setblock 95 105 345 minecraft:stripped_spruce_log
setblock 95 105 346 minecraft:stone
setblock 95 105 349 minecraft:stone
setblock 95 105 350 minecraft:stripped_spruce_log
setblock 95 105 364 minecraft:raw_iron_block
fill 96 105 322 96 117 322 minecraft:cobbled_deepslate
fill 96 105 324 96 106 324 minecraft:spruce_log
setblock 96 105 340 minecraft:stone
fill 96 105 343 96 106 343 minecraft:spruce_log
setblock 96 105 344 minecraft:stripped_spruce_log
setblock 96 105 345 minecraft:stone
fill 96 105 362 96 106 362 minecraft:spruce_log
fill 96 105 364 97 125 364 minecraft:cobbled_deepslate
setblock 97 105 323 minecraft:stripped_spruce_log
setblock 97 105 342 minecraft:stone
setblock 97 105 343 minecraft:stripped_spruce_log
fill 97 105 344 97 107 344 minecraft:stone
setblock 97 105 363 minecraft:stripped_spruce_log
fill 98 105 323 101 105 323 minecraft:stone
fill 98 105 363 101 105 363 minecraft:stone
fill 99 105 340 99 108 341 minecraft:cobbled_deepslate
setblock 100 105 324 minecraft:stone
setblock 101 105 324 minecraft:stripped_spruce_log
fill 101 105 339 101 108 339 minecraft:cobbled_deepslate
setblock 102 105 323 minecraft:stripped_spruce_log
fill 102 105 324 102 105 325 minecraft:stone
fill 102 105 342 102 108 342 minecraft:cobbled_deepslate
setblock 102 105 362 minecraft:stone
setblock 102 105 363 minecraft:stripped_spruce_log
setblock 103 105 323 minecraft:stone
setblock 103 105 362 minecraft:stripped_spruce_log
setblock 103 105 363 minecraft:stone
setblock 104 105 362 minecraft:stone
setblock 105 105 324 minecraft:stone
setblock 105 105 325 minecraft:stripped_spruce_log
setblock 106 105 324 minecraft:stripped_spruce_log
fill 106 105 325 106 108 325 minecraft:stone
fill 106 105 359 106 107 359 minecraft:cobbled_deepslate
setblock 107 105 323 minecraft:stripped_spruce_log
setblock 107 105 324 minecraft:stone
fill 107 105 358 107 107 358 minecraft:cobbled_deepslate
fill 107 105 360 107 107 360 minecraft:cobbled_deepslate
setblock 107 105 363 minecraft:stripped_spruce_log
fill 108 105 323 111 105 323 minecraft:stone
fill 108 105 359 108 107 359 minecraft:cobbled_deepslate
fill 108 105 363 111 105 363 minecraft:stone
setblock 109 105 325 minecraft:stone
setblock 111 105 324 minecraft:stripped_spruce_log
setblock 112 105 323 minecraft:stripped_spruce_log
setblock 112 105 324 minecraft:stone
setblock 112 105 363 minecraft:stripped_spruce_log
fill 113 105 323 116 105 323 minecraft:stone
fill 113 105 363 116 105 363 minecraft:stone
fill 115 105 322 115 126 322 minecraft:cobbled_deepslate
fill 115 105 324 115 106 324 minecraft:spruce_log
fill 115 105 362 115 106 362 minecraft:spruce_log
setblock 116 105 324 minecraft:stripped_spruce_log
setblock 117 105 323 minecraft:stripped_spruce_log
fill 117 105 324 120 105 324 minecraft:stone
setblock 117 105 363 minecraft:stripped_spruce_log
fill 118 105 323 121 105 323 minecraft:stone
fill 118 105 325 119 105 325 minecraft:stone
setblock 118 105 362 minecraft:stripped_spruce_log
fill 118 105 363 121 105 363 minecraft:stone
setblock 119 105 362 minecraft:stone
setblock 120 105 325 minecraft:stripped_spruce_log
setblock 121 105 324 minecraft:stripped_spruce_log
fill 121 105 325 121 108 325 minecraft:stone
setblock 122 105 323 minecraft:stripped_spruce_log
setblock 122 105 324 minecraft:stone
setblock 122 105 363 minecraft:stripped_spruce_log
setblock 123 105 323 minecraft:stone
setblock 123 105 362 minecraft:stripped_spruce_log
setblock 123 105 363 minecraft:stone
setblock 124 105 361 minecraft:stripped_spruce_log
setblock 124 105 362 minecraft:stone
setblock 125 105 325 minecraft:stripped_spruce_log
fill 125 105 361 125 107 361 minecraft:stone
setblock 126 105 324 minecraft:stripped_spruce_log
fill 126 105 325 126 107 325 minecraft:stone
setblock 127 105 323 minecraft:stripped_spruce_log
setblock 127 105 324 minecraft:stone
setblock 127 105 363 minecraft:stripped_spruce_log
setblock 128 105 323 minecraft:stone
setblock 128 105 362 minecraft:stripped_spruce_log
setblock 128 105 363 minecraft:stone
setblock 129 105 361 minecraft:stripped_spruce_log
setblock 129 105 362 minecraft:stone
setblock 132 105 323 minecraft:stripped_spruce_log
setblock 132 105 363 minecraft:stripped_spruce_log
setblock 133 105 323 minecraft:stone
setblock 133 105 362 minecraft:stripped_spruce_log
setblock 133 105 363 minecraft:stone
fill 134 105 324 134 106 324 minecraft:spruce_log
fill 134 105 343 134 106 343 minecraft:spruce_log
fill 134 105 362 134 106 362 minecraft:spruce_log
setblock 135 105 341 minecraft:stone
setblock 135 105 345 minecraft:stripped_spruce_log
setblock 135 105 346 minecraft:stone
setblock 135 105 349 minecraft:stone
setblock 135 105 350 minecraft:stripped_spruce_log
setblock 135 105 351 minecraft:stone
setblock 135 105 360 minecraft:stripped_spruce_log
setblock 135 105 361 minecraft:stone
fill 136 105 326 136 122 328 minecraft:cobbled_deepslate
setblock 136 105 329 minecraft:raw_iron_block
fill 136 105 330 136 125 330 minecraft:cobbled_deepslate
setblock 94 106 336 minecraft:gold_block
fill 94 106 337 94 109 338 minecraft:cobbled_deepslate
setblock 94 106 351 minecraft:gold_block
fill 95 106 322 95 123 322 minecraft:cobbled_deepslate
fill 95 106 323 95 106 363 minecraft:spruce_planks
fill 95 106 364 95 125 364 minecraft:cobbled_deepslate
fill 96 106 323 135 106 323 minecraft:spruce_planks
fill 96 106 325 96 106 342 minecraft:spruce_planks
fill 96 106 344 96 106 361 minecraft:spruce_planks
fill 96 106 363 135 106 363 minecraft:spruce_planks
fill 97 106 324 114 106 324 minecraft:spruce_planks
setblock 97 106 343 minecraft:stone
fill 97 106 362 114 106 362 minecraft:spruce_planks
fill 99 106 342 99 108 342 minecraft:cobbled_deepslate
fill 100 106 339 100 108 339 minecraft:cobbled_deepslate
fill 100 106 343 102 108 343 minecraft:cobbled_deepslate
fill 102 106 325 103 106 325 minecraft:stone
fill 102 106 339 102 108 339 minecraft:cobbled_deepslate
fill 103 106 340 103 108 342 minecraft:cobbled_deepslate
setblock 104 106 325 minecraft:stripped_spruce_log
fill 105 106 325 105 109 325 minecraft:stone
fill 106 106 358 106 107 358 minecraft:cobbled_deepslate
fill 106 106 360 106 107 360 minecraft:cobbled_deepslate
fill 108 106 358 108 107 358 minecraft:cobbled_deepslate
fill 108 106 360 108 107 360 minecraft:cobbled_deepslate
setblock 109 106 325 minecraft:stripped_spruce_log
fill 116 106 324 133 106 324 minecraft:spruce_planks
fill 116 106 362 133 106 362 minecraft:spruce_planks
setblock 118 106 325 minecraft:stone
setblock 119 106 325 minecraft:stripped_spruce_log
fill 120 106 325 120 109 325 minecraft:stone
setblock 121 106 364 minecraft:raw_gold_block
setblock 123 106 361 minecraft:stripped_spruce_log
setblock 124 106 325 minecraft:stripped_spruce_log
fill 124 106 361 124 107 361 minecraft:stone
fill 125 106 325 125 108 325 minecraft:stone
setblock 128 106 361 minecraft:stripped_spruce_log
fill 131 106 361 131 113 361 minecraft:cobbled_deepslate
fill 134 106 325 135 106 342 minecraft:spruce_planks
fill 134 106 344 135 106 361 minecraft:spruce_planks
setblock 135 106 322 minecraft:diamond_block
setblock 135 106 324 minecraft:spruce_planks
setblock 135 106 343 minecraft:spruce_planks
setblock 135 106 362 minecraft:spruce_planks
fill 136 106 329 136 125 329 minecraft:cobbled_deepslate
setblock 136 106 352 minecraft:gold_block
fill 136 106 353 136 125 353 minecraft:cobbled_deepslate
fill 94 107 336 94 109 336 minecraft:cobbled_deepslate
fill 94 107 351 94 125 351 minecraft:cobbled_deepslate
fill 95 107 340 95 107 342 minecraft:stone
setblock 95 107 343 minecraft:stripped_spruce_log
fill 95 107 344 95 107 347 minecraft:stone
setblock 95 107 348 minecraft:stripped_spruce_log
fill 95 107 349 95 109 350 minecraft:stone
setblock 96 107 341 minecraft:stone
setblock 96 107 342 minecraft:stripped_spruce_log
fill 96 107 343 96 107 346 minecraft:stone
setblock 96 107 347 minecraft:stripped_spruce_log
fill 96 107 348 96 110 348 minecraft:stone
fill 97 107 323 99 107 323 minecraft:stone
setblock 97 107 325 minecraft:light[level=15]
setblock 97 107 333 minecraft:light[level=15]
setblock 97 107 341 minecraft:light[level=15]
setblock 97 107 349 minecraft:light[level=15]
setblock 97 107 357 minecraft:light[level=15]
fill 98 107 340 98 108 341 minecraft:cobbled_deepslate
setblock 99 107 324 minecraft:stripped_spruce_log
fill 99 107 339 99 108 339 minecraft:cobbled_deepslate
fill 99 107 343 99 108 343 minecraft:cobbled_deepslate
setblock 99 107 363 minecraft:stone
setblock 100 107 323 minecraft:stripped_spruce_log
fill 100 107 324 103 107 324 minecraft:stone
setblock 100 107 363 minecraft:stripped_spruce_log
fill 101 107 323 104 107 323 minecraft:stone
fill 101 107 363 104 107 363 minecraft:stone
setblock 102 107 325 minecraft:stone
setblock 103 107 325 minecraft:stripped_spruce_log
setblock 104 107 324 minecraft:stripped_spruce_log
fill 104 107 325 104 110 325 minecraft:stone
setblock 105 107 323 minecraft:stripped_spruce_log
fill 105 107 324 108 107 324 minecraft:stone
setblock 105 107 333 minecraft:light[level=15]
setblock 105 107 341 minecraft:light[level=15]
setblock 105 107 349 minecraft:light[level=15]
setblock 105 107 357 minecraft:light[level=15]
setblock 105 107 359 minecraft:cobbled_deepslate
setblock 105 107 363 minecraft:stripped_spruce_log
fill 106 107 323 109 107 323 minecraft:stone
fill 106 107 363 109 107 363 minecraft:stone
setblock 107 107 357 minecraft:cobbled_deepslate
setblock 107 107 361 minecraft:cobbled_deepslate
setblock 108 107 325 minecraft:stripped_spruce_log
setblock 109 107 324 minecraft:stripped_spruce_log
setblock 109 107 359 minecraft:cobbled_deepslate
setblock 110 107 323 minecraft:stripped_spruce_log
fill 110 107 324 113 107 324 minecraft:stone
fill 111 107 323 114 107 323 minecraft:stone
setblock 113 107 325 minecraft:light[level=15]
setblock 113 107 333 minecraft:light[level=15]
setblock 113 107 341 minecraft:light[level=15]
setblock 113 107 349 minecraft:light[level=15]
setblock 113 107 357 minecraft:light[level=15]
setblock 114 107 324 minecraft:stripped_spruce_log
setblock 114 107 364 minecraft:raw_gold_block
setblock 115 107 323 minecraft:stripped_spruce_log
fill 115 107 324 118 107 324 minecraft:stone
setblock 115 107 363 minecraft:stripped_spruce_log
fill 116 107 323 119 107 323 minecraft:stone
fill 116 107 363 119 107 363 minecraft:stone
setblock 118 107 325 minecraft:stripped_spruce_log
setblock 119 107 324 minecraft:stripped_spruce_log
fill 119 107 325 119 110 325 minecraft:stone
fill 119 107 362 120 107 362 minecraft:stone
setblock 120 107 323 minecraft:stripped_spruce_log
fill 120 107 324 123 107 324 minecraft:stone
setblock 120 107 363 minecraft:stripped_spruce_log
fill 121 107 323 124 107 323 minecraft:stone
setblock 121 107 333 minecraft:light[level=15]
setblock 121 107 341 minecraft:light[level=15]
setblock 121 107 349 minecraft:light[level=15]
setblock 121 107 357 minecraft:light[level=15]
setblock 121 107 362 minecraft:stripped_spruce_log
fill 121 107 363 124 107 363 minecraft:stone
fill 121 107 364 121 122 364 minecraft:cobbled_deepslate
setblock 122 107 361 minecraft:stripped_spruce_log
fill 122 107 362 125 107 362 minecraft:stone
setblock 123 107 325 minecraft:stripped_spruce_log
setblock 123 107 361 minecraft:stone
setblock 124 107 324 minecraft:stripped_spruce_log
fill 124 107 325 124 110 325 minecraft:stone
setblock 125 107 323 minecraft:stripped_spruce_log
fill 125 107 324 128 107 324 minecraft:stone
setblock 125 107 363 minecraft:stripped_spruce_log
fill 126 107 323 129 107 323 minecraft:stone
setblock 126 107 362 minecraft:stripped_spruce_log
fill 126 107 363 129 107 363 minecraft:stone
fill 127 107 362 129 107 362 minecraft:stone
setblock 129 107 325 minecraft:light[level=15]
setblock 129 107 341 minecraft:light[level=15]
setblock 129 107 349 minecraft:light[level=15]
setblock 129 107 357 minecraft:light[level=15]
setblock 130 107 323 minecraft:stripped_spruce_log
setblock 130 107 363 minecraft:stripped_spruce_log
setblock 131 107 323 minecraft:stone
fill 131 107 363 134 107 363 minecraft:stone
fill 135 107 322 135 113 322 minecraft:cobbled_deepslate
setblock 135 107 342 minecraft:stone
setblock 135 107 343 minecraft:stripped_spruce_log
fill 135 107 344 135 107 347 minecraft:stone
setblock 135 107 348 minecraft:stripped_spruce_log
fill 135 107 349 135 108 351 minecraft:stone
setblock 135 107 363 minecraft:stripped_spruce_log
fill 136 107 352 136 122 352 minecraft:cobbled_deepslate
setblock 136 107 355 minecraft:raw_gold_block
setblock 94 108 324 minecraft:raw_gold_block
fill 95 108 340 95 108 341 minecraft:stone
setblock 95 108 342 minecraft:stripped_spruce_log
fill 95 108 343 95 108 346 minecraft:stone
setblock 95 108 347 minecraft:stripped_spruce_log
fill 95 108 348 95 111 348 minecraft:stone
setblock 95 108 351 minecraft:stone
fill 96 108 342 96 108 345 minecraft:stone
setblock 96 108 346 minecraft:stripped_spruce_log
fill 96 108 347 96 111 347 minecraft:stone
fill 96 108 349 96 109 349 minecraft:stone
fill 97 108 323 98 108 323 minecraft:stone
setblock 97 108 345 minecraft:stripped_spruce_log
setblock 98 108 339 minecraft:cobbled_deepslate
setblock 98 108 342 minecraft:cobbled_deepslate
setblock 99 108 323 minecraft:stripped_spruce_log
fill 99 108 324 102 108 324 minecraft:stone
fill 100 108 323 103 108 323 minecraft:stone
fill 100 108 338 102 108 338 minecraft:cobbled_deepslate
fill 100 108 344 102 108 344 minecraft:cobbled_deepslate
fill 100 108 363 103 108 363 minecraft:stone
setblock 101 108 325 minecraft:stone
setblock 102 108 325 minecraft:stripped_spruce_log
setblock 103 108 324 minecraft:stripped_spruce_log
fill 103 108 325 103 111 325 minecraft:stone
setblock 103 108 339 minecraft:cobbled_deepslate
setblock 103 108 343 minecraft:cobbled_deepslate
setblock 104 108 323 minecraft:stripped_spruce_log
fill 104 108 324 107 108 324 minecraft:stone
fill 104 108 340 104 108 341 minecraft:cobbled_deepslate
setblock 104 108 363 minecraft:stripped_spruce_log
fill 105 108 323 108 108 323 minecraft:stone
fill 105 108 363 106 108 363 minecraft:stone
setblock 107 108 325 minecraft:stripped_spruce_log
fill 107 108 364 109 123 364 minecraft:cobbled_deepslate
setblock 108 108 324 minecraft:stripped_spruce_log
setblock 109 108 323 minecraft:stripped_spruce_log
fill 109 108 324 112 108 324 minecraft:stone
fill 110 108 323 113 108 323 minecraft:stone
setblock 110 108 364 minecraft:raw_gold_block
fill 111 108 364 111 125 364 minecraft:cobbled_deepslate
setblock 113 108 324 minecraft:stripped_spruce_log
setblock 114 108 323 minecraft:stripped_spruce_log
fill 114 108 324 117 108 324 minecraft:stone
fill 114 108 364 114 125 364 minecraft:cobbled_deepslate
fill 115 108 323 118 108 323 minecraft:stone
fill 116 108 363 118 108 363 minecraft:stone
fill 118 108 322 118 125 322 minecraft:cobbled_deepslate
setblock 118 108 324 minecraft:stripped_spruce_log
fill 118 108 325 118 111 325 minecraft:stone
setblock 119 108 322 minecraft:raw_iron_block
setblock 119 108 323 minecraft:stripped_spruce_log
fill 119 108 324 122 108 324 minecraft:stone
setblock 119 108 362 minecraft:stone
setblock 119 108 363 minecraft:stripped_spruce_log
fill 120 108 323 123 108 323 minecraft:stone
setblock 120 108 362 minecraft:stripped_spruce_log
fill 120 108 363 123 108 363 minecraft:stone
fill 121 108 362 124 108 362 minecraft:stone
setblock 122 108 325 minecraft:stripped_spruce_log
setblock 123 108 324 minecraft:stripped_spruce_log
fill 123 108 325 123 111 325 minecraft:stone
setblock 124 108 323 minecraft:stripped_spruce_log
fill 124 108 324 127 108 324 minecraft:stone
setblock 124 108 363 minecraft:stripped_spruce_log
fill 125 108 323 128 108 323 minecraft:stone
setblock 125 108 362 minecraft:stripped_spruce_log
fill 125 108 363 128 108 363 minecraft:stone
fill 126 108 362 128 108 362 minecraft:stone
setblock 128 108 324 minecraft:stripped_spruce_log
setblock 129 108 323 minecraft:stripped_spruce_log
setblock 129 108 363 minecraft:stripped_spruce_log
setblock 130 108 323 minecraft:stone
fill 130 108 363 131 108 363 minecraft:stone
fill 135 108 343 135 108 346 minecraft:stone
setblock 135 108 347 minecraft:stripped_spruce_log
fill 135 108 348 135 111 348 minecraft:stone
setblock 135 108 352 minecraft:stripped_spruce_log
fill 136 108 355 136 118 355 minecraft:cobbled_deepslate
fill 94 109 324 94 122 324 minecraft:cobbled_deepslate
setblock 95 109 340 minecraft:stone
setblock 95 109 341 minecraft:stripped_spruce_log
fill 95 109 342 95 109 345 minecraft:stone
setblock 95 109 346 minecraft:stripped_spruce_log
fill 95 109 347 95 112 347 minecraft:stone
setblock 95 109 351 minecraft:stripped_spruce_log
fill 96 109 342 96 109 344 minecraft:stone
setblock 96 109 345 minecraft:stripped_spruce_log
fill 96 109 346 97 111 346 minecraft:stone
setblock 97 109 323 minecraft:stone
setblock 97 109 325 minecraft:light[level=12]
setblock 97 109 332 minecraft:light[level=12]
setblock 97 109 339 minecraft:light[level=12]
fill 97 109 345 97 112 345 minecraft:stone
setblock 97 109 353 minecraft:light[level=12]
setblock 97 109 360 minecraft:light[level=12]
setblock 98 109 323 minecraft:stripped_spruce_log
fill 99 109 323 101 109 324 minecraft:stone
fill 100 109 340 101 109 342 minecraft:raw_gold_block
setblock 101 109 325 minecraft:stripped_spruce_log
fill 101 109 363 102 109 363 minecraft:stone
setblock 102 109 323 minecraft:stone
setblock 102 109 324 minecraft:stripped_spruce_log
fill 102 109 325 102 112 325 minecraft:stone
setblock 102 109 341 minecraft:raw_gold_block
setblock 103 109 323 minecraft:stripped_spruce_log
fill 103 109 324 106 109 324 minecraft:stone
setblock 103 109 363 minecraft:stripped_spruce_log
fill 104 109 323 107 109 323 minecraft:stone
setblock 104 109 332 minecraft:light[level=12]
setblock 104 109 339 minecraft:light[level=12]
setblock 104 109 346 minecraft:light[level=12]
setblock 104 109 353 minecraft:light[level=12]
setblock 104 109 360 minecraft:light[level=12]
setblock 104 109 363 minecraft:stone
setblock 106 109 325 minecraft:stripped_spruce_log
setblock 107 109 324 minecraft:stripped_spruce_log
setblock 108 109 323 minecraft:stripped_spruce_log
fill 108 109 324 111 109 324 minecraft:stone
fill 109 109 323 112 109 323 minecraft:stone
fill 110 109 364 110 123 364 minecraft:cobbled_deepslate
setblock 111 109 322 minecraft:raw_gold_block
setblock 111 109 325 minecraft:light[level=12]
setblock 111 109 332 minecraft:light[level=12]
setblock 111 109 339 minecraft:light[level=12]
setblock 111 109 346 minecraft:light[level=12]
setblock 111 109 353 minecraft:light[level=12]
setblock 111 109 360 minecraft:light[level=12]
setblock 112 109 324 minecraft:stripped_spruce_log
setblock 113 109 323 minecraft:stripped_spruce_log
fill 113 109 324 116 109 324 minecraft:stone
fill 114 109 323 117 109 323 minecraft:stone
fill 116 109 363 117 109 363 minecraft:stone
setblock 117 109 324 minecraft:stripped_spruce_log
fill 117 109 325 117 112 325 minecraft:stone
setblock 118 109 323 minecraft:stripped_spruce_log
fill 118 109 324 121 109 324 minecraft:stone
setblock 118 109 332 minecraft:light[level=12]
setblock 118 109 346 minecraft:light[level=12]
setblock 118 109 353 minecraft:light[level=12]
setblock 118 109 360 minecraft:light[level=12]
setblock 118 109 363 minecraft:stripped_spruce_log
fill 119 109 322 119 126 322 minecraft:cobbled_deepslate
fill 119 109 323 122 109 323 minecraft:stone
setblock 119 109 362 minecraft:stripped_spruce_log
fill 119 109 363 122 109 363 minecraft:stone
fill 120 109 362 123 109 362 minecraft:stone
setblock 121 109 322 minecraft:raw_gold_block
setblock 121 109 325 minecraft:stripped_spruce_log
fill 122 109 322 122 125 322 minecraft:cobbled_deepslate
setblock 122 109 324 minecraft:stripped_spruce_log
fill 122 109 325 122 112 325 minecraft:stone
setblock 123 109 323 minecraft:stripped_spruce_log
fill 123 109 324 126 109 324 minecraft:stone
setblock 123 109 363 minecraft:stripped_spruce_log
fill 124 109 323 127 109 323 minecraft:stone
setblock 124 109 362 minecraft:stripped_spruce_log
fill 124 109 363 127 109 363 minecraft:stone
setblock 125 109 325 minecraft:light[level=12]
setblock 125 109 332 minecraft:light[level=12]
setblock 125 109 339 minecraft:light[level=12]
setblock 125 109 346 minecraft:light[level=12]
setblock 125 109 353 minecraft:light[level=12]
setblock 125 109 360 minecraft:light[level=12]
fill 125 109 362 126 109 362 minecraft:stone
setblock 127 109 324 minecraft:stripped_spruce_log
setblock 128 109 323 minecraft:stripped_spruce_log
setblock 128 109 363 minecraft:stripped_spruce_log
setblock 129 109 323 minecraft:stone
fill 129 109 363 130 109 363 minecraft:stone
setblock 132 109 325 minecraft:light[level=12]
setblock 132 109 332 minecraft:light[level=12]
setblock 132 109 339 minecraft:light[level=12]
setblock 132 109 346 minecraft:light[level=12]
setblock 132 109 353 minecraft:light[level=12]
setblock 132 109 360 minecraft:light[level=12]
setblock 134 109 347 minecraft:stripped_spruce_log
fill 134 109 348 134 112 348 minecraft:stone
fill 135 109 343 135 109 345 minecraft:stone
setblock 135 109 346 minecraft:stripped_spruce_log
fill 135 109 347 135 112 347 minecraft:stone
fill 135 109 349 135 109 350 minecraft:stone
setblock 135 109 351 minecraft:stripped_spruce_log
fill 135 109 352 135 111 353 minecraft:stone
setblock 94 110 325 minecraft:diamond_block
fill 94 110 326 94 117 330 minecraft:cobbled_deepslate
setblock 94 110 331 minecraft:gold_block
setblock 94 110 336 minecraft:gold_block
fill 94 110 337 94 122 337 minecraft:cobbled_deepslate
setblock 94 110 338 minecraft:raw_iron_block
setblock 94 110 347 minecraft:gold_block
fill 95 110 326 95 110 329 minecraft:stone
setblock 95 110 340 minecraft:stripped_spruce_log
fill 95 110 341 95 110 344 minecraft:stone
setblock 95 110 345 minecraft:stripped_spruce_log
fill 95 110 346 95 113 346 minecraft:stone
setblock 95 110 349 minecraft:stone
setblock 95 110 350 minecraft:stripped_spruce_log
fill 95 110 351 95 112 352 minecraft:stone
fill 96 110 342 96 110 343 minecraft:stone
setblock 96 110 344 minecraft:stripped_spruce_log
fill 96 110 345 96 113 345 minecraft:stone
setblock 96 110 349 minecraft:stripped_spruce_log
fill 96 110 350 96 113 350 minecraft:stone
setblock 97 110 323 minecraft:stripped_spruce_log
setblock 97 110 347 minecraft:stone
fill 98 110 323 100 110 324 minecraft:stone
setblock 100 110 325 minecraft:stripped_spruce_log
fill 100 110 341 101 111 341 minecraft:raw_gold_block
setblock 101 110 323 minecraft:stone
setblock 101 110 324 minecraft:stripped_spruce_log
fill 101 110 325 101 113 325 minecraft:stone
setblock 101 110 340 minecraft:raw_gold_block
setblock 102 110 323 minecraft:stripped_spruce_log
fill 102 110 324 105 110 324 minecraft:stone
setblock 102 110 363 minecraft:stripped_spruce_log
fill 103 110 323 106 110 323 minecraft:stone
setblock 105 110 325 minecraft:stripped_spruce_log
setblock 106 110 324 minecraft:stripped_spruce_log
fill 106 110 325 106 112 325 minecraft:stone
setblock 107 110 323 minecraft:stripped_spruce_log
fill 107 110 324 110 110 324 minecraft:stone
fill 108 110 323 111 110 323 minecraft:stone
fill 111 110 322 111 113 322 minecraft:cobbled_deepslate
setblock 111 110 324 minecraft:stripped_spruce_log
setblock 112 110 323 minecraft:stripped_spruce_log
fill 112 110 324 115 110 324 minecraft:stone
fill 113 110 323 116 110 323 minecraft:stone
setblock 116 110 324 minecraft:stripped_spruce_log
setblock 116 110 363 minecraft:stone
setblock 117 110 323 minecraft:stripped_spruce_log
fill 117 110 324 120 110 324 minecraft:stone
setblock 117 110 363 minecraft:stripped_spruce_log
fill 118 110 323 121 110 323 minecraft:stone
fill 118 110 363 121 110 363 minecraft:stone
fill 119 110 362 122 110 362 minecraft:stone
setblock 120 110 325 minecraft:stripped_spruce_log
fill 121 110 322 121 123 322 minecraft:cobbled_deepslate
setblock 121 110 324 minecraft:stripped_spruce_log
fill 121 110 325 121 113 325 minecraft:stone
setblock 122 110 323 minecraft:stripped_spruce_log
fill 122 110 324 125 110 324 minecraft:stone
setblock 122 110 363 minecraft:stripped_spruce_log
fill 123 110 323 126 110 323 minecraft:stone
setblock 123 110 362 minecraft:stripped_spruce_log
fill 123 110 363 126 110 363 minecraft:stone
fill 124 110 362 125 111 362 minecraft:stone
setblock 126 110 324 minecraft:stripped_spruce_log
setblock 127 110 323 minecraft:stripped_spruce_log
setblock 127 110 363 minecraft:stripped_spruce_log
setblock 128 110 323 minecraft:stone
fill 128 110 363 128 111 363 minecraft:stone
fill 130 110 361 130 113 361 minecraft:cobbled_deepslate
fill 131 110 360 131 113 360 minecraft:cobbled_deepslate
fill 131 110 362 131 113 362 minecraft:cobbled_deepslate
fill 132 110 361 132 113 361 minecraft:cobbled_deepslate
setblock 134 110 346 minecraft:stripped_spruce_log
fill 134 110 347 134 113 347 minecraft:stone
fill 134 110 349 134 110 350 minecraft:stone
fill 135 110 343 135 110 344 minecraft:stone
setblock 135 110 345 minecraft:stripped_spruce_log
fill 135 110 346 135 113 346 minecraft:stone
setblock 135 110 349 minecraft:stone
setblock 135 110 350 minecraft:stripped_spruce_log
fill 135 110 351 135 113 351 minecraft:stone
setblock 135 110 354 minecraft:stone
fill 94 111 325 94 120 325 minecraft:cobbled_deepslate
fill 94 111 331 94 125 331 minecraft:cobbled_deepslate
fill 94 111 336 94 125 336 minecraft:cobbled_deepslate
fill 94 111 338 94 126 338 minecraft:cobbled_deepslate
fill 94 111 341 94 122 341 minecraft:cobbled_deepslate
setblock 94 111 342 minecraft:gold_block
fill 94 111 347 94 125 347 minecraft:cobbled_deepslate
setblock 95 111 324 minecraft:stripped_spruce_log
fill 95 111 325 95 111 328 minecraft:stone
setblock 95 111 329 minecraft:stripped_spruce_log
fill 95 111 330 95 112 332 minecraft:stone
setblock 95 111 339 minecraft:stripped_spruce_log
fill 95 111 340 95 111 343 minecraft:stone
setblock 95 111 344 minecraft:stripped_spruce_log
fill 95 111 345 95 114 345 minecraft:stone
setblock 95 111 349 minecraft:stripped_spruce_log
fill 95 111 350 95 114 350 minecraft:stone
setblock 95 111 353 minecraft:stone
fill 95 111 358 95 114 360 minecraft:raw_gold_block
setblock 96 111 323 minecraft:stripped_spruce_log
setblock 96 111 327 minecraft:stone
setblock 96 111 328 minecraft:stripped_spruce_log
fill 96 111 329 96 114 329 minecraft:stone
setblock 96 111 342 minecraft:stone
setblock 96 111 343 minecraft:stripped_spruce_log
fill 96 111 344 96 114 344 minecraft:stone
setblock 96 111 348 minecraft:stripped_spruce_log
fill 96 111 349 97 113 349 minecraft:stone
fill 96 111 351 96 112 351 minecraft:stone
fill 96 111 359 97 113 359 minecraft:raw_gold_block
fill 97 111 322 98 125 322 minecraft:cobbled_deepslate
fill 97 111 323 100 111 323 minecraft:stone
setblock 97 111 347 minecraft:stripped_spruce_log
fill 97 111 348 97 114 348 minecraft:stone
fill 98 111 324 99 111 324 minecraft:stone
setblock 99 111 322 minecraft:gold_block
setblock 99 111 325 minecraft:stripped_spruce_log
setblock 100 111 324 minecraft:stripped_spruce_log
fill 100 111 325 100 114 325 minecraft:stone
setblock 101 111 323 minecraft:stripped_spruce_log
fill 101 111 324 104 111 324 minecraft:stone
fill 102 111 323 105 111 323 minecraft:stone
setblock 104 111 325 minecraft:stripped_spruce_log
setblock 105 111 324 minecraft:stripped_spruce_log
fill 105 111 325 105 114 325 minecraft:stone
setblock 106 111 323 minecraft:stripped_spruce_log
fill 106 111 324 109 111 324 minecraft:stone
fill 107 111 323 110 111 323 minecraft:stone
setblock 110 111 324 minecraft:stripped_spruce_log
setblock 111 111 323 minecraft:stripped_spruce_log
fill 111 111 324 114 111 324 minecraft:stone
fill 112 111 323 115 111 323 minecraft:stone
setblock 115 111 324 minecraft:stripped_spruce_log
setblock 115 111 363 minecraft:stone
setblock 116 111 323 minecraft:stripped_spruce_log
fill 116 111 324 116 113 325 minecraft:stone
setblock 116 111 363 minecraft:stripped_spruce_log
fill 117 111 323 119 111 324 minecraft:stone
fill 117 111 363 120 111 363 minecraft:stone
fill 118 111 362 121 111 362 minecraft:stone
setblock 119 111 325 minecraft:stripped_spruce_log
setblock 120 111 323 minecraft:stone
setblock 120 111 324 minecraft:stripped_spruce_log
fill 120 111 325 120 114 325 minecraft:stone
setblock 121 111 323 minecraft:stripped_spruce_log
fill 121 111 324 124 111 324 minecraft:stone
setblock 121 111 363 minecraft:stripped_spruce_log
fill 122 111 323 125 111 323 minecraft:stone
setblock 122 111 362 minecraft:stripped_spruce_log
fill 122 111 363 125 111 363 minecraft:stone
fill 123 111 362 123 114 362 minecraft:stone
setblock 125 111 324 minecraft:stripped_spruce_log
setblock 126 111 323 minecraft:stripped_spruce_log
setblock 126 111 363 minecraft:stripped_spruce_log
fill 127 111 323 127 112 323 minecraft:stone
fill 127 111 363 127 113 363 minecraft:stone
setblock 133 111 364 minecraft:raw_iron_block
fill 134 111 346 134 114 346 minecraft:stone
setblock 134 111 349 minecraft:stone
setblock 134 111 350 minecraft:stripped_spruce_log
fill 134 111 351 134 114 351 minecraft:stone
fill 135 111 342 135 111 343 minecraft:stone
setblock 135 111 344 minecraft:stripped_spruce_log
fill 135 111 345 135 114 345 minecraft:stone
setblock 135 111 349 minecraft:stripped_spruce_log
fill 135 111 350 135 114 350 minecraft:stone
setblock 135 111 354 minecraft:stripped_spruce_log
fill 135 111 355 135 114 355 minecraft:stone
fill 94 112 322 94 125 322 minecraft:cobbled_deepslate
setblock 94 112 323 minecraft:gold_block
fill 94 112 342 94 121 342 minecraft:cobbled_deepslate
fill 95 112 324 95 112 327 minecraft:stone
setblock 95 112 328 minecraft:stripped_spruce_log
fill 95 112 329 95 115 329 minecraft:stone
setblock 95 112 333 minecraft:stripped_spruce_log
fill 95 112 334 95 112 337 minecraft:stone
setblock 95 112 338 minecraft:stripped_spruce_log
fill 95 112 339 95 112 342 minecraft:stone
setblock 95 112 343 minecraft:stripped_spruce_log
fill 95 112 344 95 115 344 minecraft:stone
setblock 95 112 348 minecraft:stripped_spruce_log
fill 95 112 349 95 115 349 minecraft:stone
setblock 95 112 353 minecraft:stripped_spruce_log
fill 95 112 354 95 115 354 minecraft:stone
fill 96 112 323 99 112 323 minecraft:stone
fill 96 112 325 96 112 326 minecraft:stone
setblock 96 112 327 minecraft:stripped_spruce_log
fill 96 112 328 97 114 328 minecraft:stone
fill 96 112 330 96 112 331 minecraft:stone
setblock 96 112 332 minecraft:stripped_spruce_log
fill 96 112 333 96 115 333 minecraft:stone
setblock 96 112 341 minecraft:stone
setblock 96 112 342 minecraft:stripped_spruce_log
fill 96 112 343 96 115 343 minecraft:stone
setblock 96 112 346 minecraft:stone
setblock 96 112 347 minecraft:stripped_spruce_log
fill 96 112 348 96 115 348 minecraft:stone
setblock 96 112 352 minecraft:stripped_spruce_log
fill 96 112 358 97 113 358 minecraft:raw_gold_block
fill 96 112 360 97 113 360 minecraft:raw_gold_block
fill 97 112 324 98 112 324 minecraft:stone
fill 97 112 327 97 115 327 minecraft:stone
fill 97 112 329 97 112 330 minecraft:stone
fill 97 112 344 97 113 344 minecraft:stone
setblock 97 112 346 minecraft:stripped_spruce_log
fill 97 112 347 97 115 347 minecraft:stone
setblock 97 112 350 minecraft:stone
setblock 98 112 325 minecraft:stripped_spruce_log
fill 98 112 359 99 112 359 minecraft:raw_gold_block
fill 99 112 322 99 125 322 minecraft:cobbled_deepslate
setblock 99 112 324 minecraft:stripped_spruce_log
fill 99 112 325 99 115 325 minecraft:stone
setblock 100 112 323 minecraft:stripped_spruce_log
fill 100 112 324 103 112 324 minecraft:stone
fill 101 112 323 104 112 323 minecraft:stone
fill 101 112 341 101 113 341 minecraft:raw_gold_block
setblock 103 112 325 minecraft:stripped_spruce_log
setblock 104 112 324 minecraft:stripped_spruce_log
fill 104 112 325 104 115 325 minecraft:stone
setblock 105 112 323 minecraft:stripped_spruce_log
fill 105 112 324 108 112 324 minecraft:stone
fill 106 112 323 109 112 323 minecraft:stone
setblock 109 112 324 minecraft:stripped_spruce_log
setblock 110 112 323 minecraft:stripped_spruce_log
fill 110 112 324 113 112 324 minecraft:stone
fill 111 112 323 114 112 323 minecraft:stone
setblock 114 112 324 minecraft:stripped_spruce_log
setblock 115 112 323 minecraft:stripped_spruce_log
fill 115 112 324 115 114 325 minecraft:stone
setblock 115 112 363 minecraft:stripped_spruce_log
fill 116 112 323 119 112 323 minecraft:stone
fill 116 112 363 119 112 363 minecraft:stone
fill 117 112 324 118 112 324 minecraft:stone
setblock 118 112 325 minecraft:stripped_spruce_log
fill 118 112 362 120 112 362 minecraft:stone
setblock 119 112 324 minecraft:stripped_spruce_log
fill 119 112 325 119 115 325 minecraft:stone
setblock 120 112 323 minecraft:stripped_spruce_log
fill 120 112 324 123 112 324 minecraft:stone
setblock 120 112 363 minecraft:stripped_spruce_log
fill 121 112 323 124 112 323 minecraft:stone
setblock 121 112 362 minecraft:stripped_spruce_log
fill 121 112 363 124 112 363 minecraft:stone
fill 122 112 362 122 115 362 minecraft:stone
setblock 123 112 325 minecraft:stripped_spruce_log
setblock 124 112 324 minecraft:stripped_spruce_log
fill 124 112 362 124 113 362 minecraft:stone
setblock 125 112 323 minecraft:stripped_spruce_log
setblock 125 112 324 minecraft:stone
setblock 125 112 363 minecraft:stripped_spruce_log
fill 126 112 323 126 114 323 minecraft:stone
fill 126 112 363 126 115 363 minecraft:stone
fill 130 112 360 130 113 360 minecraft:cobbled_deepslate
fill 130 112 362 130 113 362 minecraft:cobbled_deepslate
fill 132 112 329 134 113 329 minecraft:iron_bars
fill 132 112 360 132 113 360 minecraft:cobbled_deepslate
fill 132 112 362 132 113 362 minecraft:cobbled_deepslate
fill 133 112 364 133 125 364 minecraft:cobbled_deepslate
fill 134 112 345 134 115 345 minecraft:stone
setblock 134 112 349 minecraft:stripped_spruce_log
fill 134 112 350 134 115 350 minecraft:stone
fill 134 112 352 134 112 353 minecraft:stone
fill 135 112 326 135 112 327 minecraft:stone
setblock 135 112 328 minecraft:stripped_spruce_log
fill 135 112 329 135 115 329 minecraft:stone
setblock 135 112 342 minecraft:stone
setblock 135 112 343 minecraft:stripped_spruce_log
fill 135 112 344 135 115 344 minecraft:stone
setblock 135 112 348 minecraft:stripped_spruce_log
fill 135 112 349 135 115 349 minecraft:stone
setblock 135 112 352 minecraft:stone
setblock 135 112 353 minecraft:stripped_spruce_log
fill 135 112 354 135 115 354 minecraft:stone
fill 135 112 356 135 113 356 minecraft:stone
setblock 94 113 323 minecraft:cobbled_deepslate
setblock 94 113 335 minecraft:gold_block
fill 95 113 323 95 113 326 minecraft:stone
setblock 95 113 327 minecraft:stripped_spruce_log
fill 95 113 328 95 116 328 minecraft:stone
fill 95 113 330 95 113 331 minecraft:stone
setblock 95 113 332 minecraft:stripped_spruce_log
fill 95 113 333 95 113 336 minecraft:stone
setblock 95 113 337 minecraft:stripped_spruce_log
fill 95 113 338 95 113 341 minecraft:stone
setblock 95 113 342 minecraft:stripped_spruce_log
fill 95 113 343 95 116 343 minecraft:stone
setblock 95 113 347 minecraft:stripped_spruce_log
fill 95 113 348 95 116 348 minecraft:stone
setblock 95 113 351 minecraft:stone
setblock 95 113 352 minecraft:stripped_spruce_log
fill 95 113 353 96 115 353 minecraft:stone
fill 95 113 355 95 114 355 minecraft:stone
fill 96 113 323 96 113 325 minecraft:stone
setblock 96 113 326 minecraft:stripped_spruce_log
fill 96 113 327 96 116 327 minecraft:stone
setblock 96 113 330 minecraft:stone
setblock 96 113 331 minecraft:stripped_spruce_log
fill 96 113 332 97 115 332 minecraft:stone
fill 96 113 334 96 113 335 minecraft:stone
setblock 96 113 336 minecraft:stripped_spruce_log
fill 96 113 337 96 113 340 minecraft:stone
setblock 96 113 341 minecraft:stripped_spruce_log
fill 96 113 342 96 116 342 minecraft:stone
setblock 96 113 346 minecraft:stripped_spruce_log
fill 96 113 347 96 116 347 minecraft:stone
setblock 96 113 351 minecraft:stripped_spruce_log
fill 96 113 352 96 116 352 minecraft:stone
fill 97 113 323 97 113 324 minecraft:stone
fill 97 113 326 97 116 326 minecraft:stone
setblock 97 113 329 minecraft:stone
setblock 97 113 330 minecraft:stripped_spruce_log
fill 97 113 331 97 116 331 minecraft:stone
fill 97 113 333 97 113 334 minecraft:stone
setblock 97 113 345 minecraft:stripped_spruce_log
fill 97 113 346 97 116 346 minecraft:stone
setblock 97 113 350 minecraft:stripped_spruce_log
fill 97 113 351 97 116 351 minecraft:stone
setblock 98 113 323 minecraft:stone
setblock 98 113 324 minecraft:stripped_spruce_log
fill 98 113 325 98 116 325 minecraft:stone
setblock 98 113 328 minecraft:stone
setblock 98 113 329 minecraft:stripped_spruce_log
fill 98 113 330 98 116 330 minecraft:stone
setblock 98 113 359 minecraft:raw_gold_block
setblock 99 113 323 minecraft:stripped_spruce_log
fill 99 113 324 102 113 324 minecraft:stone
fill 100 113 323 103 113 323 minecraft:stone
setblock 100 113 326 minecraft:stone
setblock 101 113 326 minecraft:stripped_spruce_log
setblock 102 113 325 minecraft:stripped_spruce_log
fill 102 113 326 102 115 326 minecraft:stone
setblock 103 113 324 minecraft:stripped_spruce_log
fill 103 113 325 103 116 325 minecraft:stone
setblock 104 113 323 minecraft:stripped_spruce_log
fill 104 113 324 107 113 324 minecraft:stone
fill 105 113 323 108 113 323 minecraft:stone
setblock 108 113 324 minecraft:stripped_spruce_log
setblock 109 113 323 minecraft:stripped_spruce_log
fill 109 113 324 112 113 324 minecraft:stone
fill 110 113 323 113 113 323 minecraft:stone
setblock 113 113 324 minecraft:stripped_spruce_log
setblock 114 113 323 minecraft:stripped_spruce_log
fill 114 113 324 114 115 325 minecraft:stone
setblock 114 113 363 minecraft:stripped_spruce_log
fill 115 113 323 118 113 323 minecraft:stone
fill 115 113 363 118 113 363 minecraft:stone
setblock 117 113 324 minecraft:stone
setblock 117 113 325 minecraft:stripped_spruce_log
fill 117 113 362 119 113 362 minecraft:stone
setblock 118 113 324 minecraft:stripped_spruce_log
fill 118 113 325 118 116 325 minecraft:stone
setblock 118 113 364 minecraft:raw_gold_block
setblock 119 113 323 minecraft:stripped_spruce_log
fill 119 113 324 122 113 324 minecraft:stone
setblock 119 113 363 minecraft:stripped_spruce_log
fill 119 113 364 119 125 364 minecraft:cobbled_deepslate
fill 120 113 323 123 113 323 minecraft:stone
setblock 120 113 362 minecraft:stripped_spruce_log
fill 120 113 363 123 113 363 minecraft:stone
fill 121 113 362 121 116 362 minecraft:stone
setblock 122 113 325 minecraft:stripped_spruce_log
setblock 123 113 324 minecraft:stripped_spruce_log
setblock 123 113 325 minecraft:stone
setblock 124 113 323 minecraft:stripped_spruce_log
fill 124 113 324 124 114 324 minecraft:stone
setblock 124 113 363 minecraft:stripped_spruce_log
fill 125 113 323 125 115 323 minecraft:stone
fill 125 113 363 125 116 363 minecraft:stone
fill 126 113 364 127 125 364 minecraft:cobbled_deepslate
setblock 128 113 364 minecraft:diamond_block
setblock 133 113 349 minecraft:stripped_spruce_log
fill 133 113 350 133 115 351 minecraft:stone
fill 134 113 344 134 116 344 minecraft:stone
setblock 134 113 348 minecraft:stripped_spruce_log
fill 134 113 349 134 116 349 minecraft:stone
setblock 134 113 352 minecraft:stone
setblock 134 113 353 minecraft:stripped_spruce_log
fill 134 113 354 134 116 354 minecraft:stone
fill 135 113 325 135 113 326 minecraft:stone
setblock 135 113 327 minecraft:stripped_spruce_log
fill 135 113 328 135 116 328 minecraft:stone
fill 135 113 330 135 113 331 minecraft:stone
setblock 135 113 332 minecraft:stripped_spruce_log
fill 135 113 333 135 116 333 minecraft:stone
setblock 135 113 341 minecraft:stone
setblock 135 113 342 minecraft:stripped_spruce_log
fill 135 113 343 135 116 343 minecraft:stone
setblock 135 113 347 minecraft:stripped_spruce_log
fill 135 113 348 135 116 348 minecraft:stone
setblock 135 113 352 minecraft:stripped_spruce_log
fill 135 113 353 135 116 353 minecraft:stone
setblock 135 113 357 minecraft:stripped_spruce_log
fill 135 113 358 135 116 358 minecraft:stone
fill 136 113 334 136 125 334 minecraft:cobbled_deepslate
setblock 136 113 335 minecraft:raw_iron_block
setblock 94 114 323 minecraft:raw_gold_block
fill 94 114 335 94 121 335 minecraft:cobbled_deepslate
fill 95 114 323 95 114 325 minecraft:stone
setblock 95 114 326 minecraft:stripped_spruce_log
fill 95 114 327 95 117 327 minecraft:stone
setblock 95 114 330 minecraft:stone
setblock 95 114 331 minecraft:stripped_spruce_log
fill 95 114 332 95 114 335 minecraft:stone
setblock 95 114 336 minecraft:stripped_spruce_log
fill 95 114 337 95 114 340 minecraft:stone
setblock 95 114 341 minecraft:stripped_spruce_log
fill 95 114 342 95 117 342 minecraft:stone
setblock 95 114 346 minecraft:stripped_spruce_log
fill 95 114 347 95 117 347 minecraft:stone
schedule function dropper:buildpart/74_2 1t
