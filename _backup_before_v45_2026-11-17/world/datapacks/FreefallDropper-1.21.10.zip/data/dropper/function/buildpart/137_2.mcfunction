fill 264 107 586 272 107 586 minecraft:gray_concrete
fill 265 107 571 266 107 571 minecraft:gray_concrete
fill 265 107 585 272 107 585 minecraft:gray_concrete
fill 266 107 557 266 108 557 minecraft:orange_terracotta
fill 266 107 584 272 107 584 minecraft:gray_concrete
setblock 267 107 557 minecraft:black_concrete
fill 267 107 574 270 107 575 minecraft:gray_concrete
fill 267 107 581 268 107 583 minecraft:gray_concrete
setblock 267 107 599 minecraft:yellow_concrete
fill 268 107 557 269 109 557 minecraft:orange_terracotta
fill 268 107 576 269 107 576 minecraft:gray_concrete
setblock 268 107 580 minecraft:gray_concrete
setblock 268 107 599 minecraft:black_concrete
fill 269 107 599 272 107 599 minecraft:orange_terracotta
fill 271 107 574 271 108 574 minecraft:gray_concrete
setblock 273 107 599 minecraft:black_concrete
setblock 274 107 599 minecraft:orange_terracotta
fill 277 107 558 277 111 558 minecraft:orange_terracotta
fill 277 107 560 277 110 560 minecraft:orange_terracotta
setblock 277 107 561 minecraft:yellow_concrete
setblock 277 107 562 minecraft:black_concrete
setblock 277 107 563 minecraft:orange_terracotta
fill 277 107 564 277 107 565 minecraft:yellow_concrete
fill 277 107 566 277 107 571 minecraft:orange_terracotta
fill 277 107 574 277 107 576 minecraft:orange_terracotta
setblock 277 107 577 minecraft:black_concrete
fill 277 107 578 277 108 581 minecraft:orange_terracotta
setblock 277 107 585 minecraft:yellow_concrete
fill 277 107 586 277 107 589 minecraft:orange_terracotta
fill 277 107 592 277 110 592 minecraft:orange_terracotta
setblock 277 107 593 minecraft:yellow_concrete
fill 277 107 594 277 107 595 minecraft:orange_terracotta
setblock 277 107 596 minecraft:yellow_concrete
fill 277 107 597 277 107 599 minecraft:orange_terracotta
setblock 235 108 561 minecraft:orange_terracotta
fill 235 108 563 235 109 564 minecraft:orange_terracotta
fill 235 108 565 235 108 566 minecraft:yellow_concrete
fill 235 108 567 235 109 572 minecraft:orange_terracotta
fill 235 108 573 235 109 574 minecraft:yellow_concrete
fill 235 108 575 235 113 576 minecraft:orange_terracotta
setblock 235 108 577 minecraft:yellow_concrete
fill 235 108 583 235 109 584 minecraft:orange_terracotta
fill 235 108 585 235 109 586 minecraft:yellow_concrete
fill 235 108 587 235 108 588 minecraft:black_concrete
fill 235 108 590 235 108 593 minecraft:orange_terracotta
fill 235 108 594 235 109 594 minecraft:yellow_concrete
fill 235 108 595 235 109 596 minecraft:orange_terracotta
fill 235 108 597 235 108 598 minecraft:yellow_concrete
fill 235 108 599 235 113 599 minecraft:orange_terracotta
fill 236 108 558 238 108 558 minecraft:orange_concrete
fill 236 108 560 236 108 562 minecraft:orange_concrete
fill 236 108 564 236 108 566 minecraft:orange_concrete
fill 236 108 568 236 108 570 minecraft:orange_concrete
fill 236 108 572 236 108 574 minecraft:orange_concrete
fill 236 108 576 236 108 578 minecraft:orange_concrete
fill 236 108 580 236 108 582 minecraft:orange_concrete
fill 236 108 584 236 108 586 minecraft:orange_concrete
fill 236 108 588 236 108 590 minecraft:orange_concrete
fill 236 108 592 236 108 594 minecraft:orange_concrete
fill 236 108 596 236 108 598 minecraft:orange_concrete
fill 237 108 557 237 109 557 minecraft:orange_terracotta
fill 238 108 598 240 108 598 minecraft:orange_concrete
fill 240 108 557 241 113 557 minecraft:orange_terracotta
fill 240 108 558 242 108 558 minecraft:orange_concrete
fill 240 108 599 240 109 599 minecraft:orange_terracotta
fill 241 108 582 243 108 582 minecraft:gray_concrete
fill 241 108 599 242 109 599 minecraft:yellow_concrete
fill 242 108 557 243 109 557 minecraft:yellow_concrete
fill 242 108 569 243 108 573 minecraft:gray_concrete
fill 242 108 575 242 108 579 minecraft:gray_concrete
setblock 242 108 581 minecraft:gray_concrete
fill 242 108 598 244 108 598 minecraft:orange_concrete
setblock 243 108 599 minecraft:black_concrete
fill 244 108 557 248 108 557 minecraft:orange_terracotta
fill 244 108 558 246 108 558 minecraft:orange_concrete
fill 244 108 568 244 108 571 minecraft:gray_concrete
fill 244 108 585 244 108 586 minecraft:gray_concrete
fill 244 108 588 247 108 590 minecraft:gray_concrete
fill 244 108 599 244 113 599 minecraft:orange_terracotta
fill 245 108 568 245 108 570 minecraft:gray_concrete
fill 245 108 586 245 108 587 minecraft:gray_concrete
fill 246 108 568 246 108 569 minecraft:gray_concrete
setblock 246 108 587 minecraft:gray_concrete
fill 246 108 598 248 108 598 minecraft:orange_concrete
fill 246 108 599 247 110 599 minecraft:orange_terracotta
fill 247 108 564 247 108 568 minecraft:gray_concrete
fill 248 108 558 250 108 558 minecraft:orange_concrete
fill 248 108 564 248 108 567 minecraft:gray_concrete
fill 248 108 589 248 108 590 minecraft:gray_concrete
setblock 248 108 599 minecraft:black_concrete
fill 249 108 564 249 108 566 minecraft:gray_concrete
fill 249 108 590 249 108 592 minecraft:magma_block
fill 249 108 599 252 108 599 minecraft:orange_terracotta
fill 250 108 557 250 111 557 minecraft:orange_terracotta
fill 250 108 564 250 108 565 minecraft:gray_concrete
fill 250 108 591 252 108 592 minecraft:gray_concrete
fill 250 108 598 252 108 598 minecraft:orange_concrete
setblock 251 108 557 minecraft:yellow_concrete
fill 252 108 557 253 113 557 minecraft:orange_terracotta
fill 252 108 558 254 108 558 minecraft:orange_concrete
setblock 252 108 565 minecraft:gray_concrete
fill 253 108 592 254 108 592 minecraft:gray_concrete
fill 253 108 599 254 108 599 minecraft:yellow_concrete
fill 254 108 557 255 109 557 minecraft:yellow_concrete
fill 254 108 598 256 108 598 minecraft:orange_concrete
fill 255 108 599 256 113 599 minecraft:orange_terracotta
fill 256 108 557 256 109 557 minecraft:orange_terracotta
fill 256 108 558 258 108 558 minecraft:orange_concrete
setblock 257 108 557 minecraft:black_concrete
fill 258 108 557 261 111 557 minecraft:orange_terracotta
fill 258 108 598 260 108 598 minecraft:orange_concrete
fill 258 108 599 258 111 599 minecraft:orange_terracotta
fill 259 108 599 260 108 599 minecraft:black_concrete
fill 260 108 558 262 108 558 minecraft:orange_concrete
fill 260 108 565 262 108 565 minecraft:gray_concrete
fill 261 108 599 262 109 599 minecraft:yellow_concrete
fill 262 108 557 263 108 557 minecraft:yellow_concrete
fill 262 108 598 264 108 598 minecraft:orange_concrete
fill 263 108 564 263 108 566 minecraft:magma_block
fill 263 108 590 269 108 590 minecraft:gray_concrete
fill 263 108 599 264 113 599 minecraft:orange_terracotta
fill 264 108 557 265 109 557 minecraft:orange_terracotta
fill 264 108 558 266 108 558 minecraft:orange_concrete
fill 264 108 564 267 108 567 minecraft:gray_concrete
fill 264 108 589 270 108 589 minecraft:gray_concrete
fill 265 108 568 267 108 568 minecraft:gray_concrete
fill 265 108 588 268 108 588 minecraft:gray_concrete
setblock 265 108 599 minecraft:yellow_concrete
fill 266 108 569 267 108 569 minecraft:gray_concrete
fill 266 108 598 268 108 598 minecraft:orange_concrete
fill 266 108 599 268 110 599 minecraft:orange_terracotta
setblock 267 108 557 minecraft:orange_terracotta
fill 267 108 570 272 108 570 minecraft:gray_concrete
fill 267 108 586 272 108 586 minecraft:gray_concrete
fill 268 108 558 270 108 558 minecraft:orange_concrete
fill 268 108 585 272 108 585 minecraft:gray_concrete
fill 269 108 572 270 108 574 minecraft:gray_concrete
fill 269 108 584 272 108 584 minecraft:gray_concrete
setblock 269 108 599 minecraft:black_concrete
setblock 270 108 575 minecraft:gray_concrete
fill 270 108 577 271 108 581 minecraft:gray_concrete
fill 270 108 598 272 108 598 minecraft:orange_concrete
fill 270 108 599 272 108 599 minecraft:orange_terracotta
fill 271 108 572 272 108 573 minecraft:gray_concrete
fill 272 108 557 273 113 557 minecraft:orange_terracotta
fill 272 108 558 274 108 558 minecraft:orange_concrete
fill 272 108 577 273 108 579 minecraft:gray_concrete
setblock 273 108 573 minecraft:gray_concrete
fill 273 108 599 274 109 599 minecraft:yellow_concrete
fill 274 108 557 275 109 557 minecraft:yellow_concrete
fill 274 108 598 276 108 598 minecraft:orange_concrete
fill 275 108 599 276 113 599 minecraft:orange_terracotta
fill 276 108 557 277 109 557 minecraft:orange_terracotta
fill 276 108 558 276 108 560 minecraft:orange_concrete
fill 276 108 562 276 108 564 minecraft:orange_concrete
fill 276 108 566 276 108 568 minecraft:orange_concrete
fill 276 108 570 276 108 572 minecraft:orange_concrete
fill 276 108 574 276 108 576 minecraft:orange_concrete
fill 276 108 578 276 108 580 minecraft:orange_concrete
fill 276 108 582 276 108 584 minecraft:orange_concrete
fill 276 108 586 276 108 588 minecraft:orange_concrete
fill 276 108 590 276 108 592 minecraft:orange_concrete
fill 276 108 594 276 108 596 minecraft:orange_concrete
fill 277 108 561 277 111 562 minecraft:orange_terracotta
setblock 277 108 563 minecraft:yellow_concrete
fill 277 108 564 277 113 565 minecraft:orange_terracotta
fill 277 108 566 277 109 566 minecraft:yellow_concrete
fill 277 108 567 277 108 568 minecraft:orange_terracotta
setblock 277 108 569 minecraft:black_concrete
fill 277 108 570 277 111 571 minecraft:orange_terracotta
setblock 277 108 572 minecraft:black_concrete
fill 277 108 573 277 113 573 minecraft:orange_terracotta
fill 277 108 574 277 108 575 minecraft:yellow_concrete
setblock 277 108 576 minecraft:black_concrete
fill 277 108 577 277 109 577 minecraft:orange_terracotta
setblock 277 108 582 minecraft:black_concrete
fill 277 108 583 277 111 585 minecraft:orange_terracotta
fill 277 108 586 277 109 587 minecraft:yellow_concrete
fill 277 108 588 277 109 589 minecraft:orange_terracotta
fill 277 108 593 277 113 593 minecraft:orange_terracotta
fill 277 108 594 277 108 595 minecraft:yellow_concrete
fill 277 108 596 277 109 597 minecraft:orange_terracotta
fill 277 108 598 277 109 598 minecraft:yellow_concrete
setblock 277 108 599 minecraft:black_concrete
fill 235 109 561 235 109 562 minecraft:yellow_concrete
setblock 235 109 565 minecraft:yellow_concrete
fill 235 109 566 235 112 566 minecraft:orange_terracotta
fill 235 109 577 235 112 577 minecraft:orange_terracotta
fill 235 109 579 235 110 581 minecraft:orange_terracotta
setblock 235 109 582 minecraft:yellow_concrete
fill 235 109 587 235 113 588 minecraft:orange_terracotta
fill 235 109 590 235 109 592 minecraft:orange_terracotta
setblock 235 109 593 minecraft:yellow_concrete
fill 235 109 597 235 112 598 minecraft:orange_terracotta
fill 243 109 599 243 113 599 minecraft:orange_terracotta
fill 244 109 557 245 109 557 minecraft:orange_terracotta
setblock 246 109 557 minecraft:yellow_concrete
fill 247 109 557 248 110 557 minecraft:orange_terracotta
fill 248 109 583 248 110 583 minecraft:red_concrete
setblock 248 109 599 minecraft:orange_terracotta
fill 249 109 599 250 109 599 minecraft:yellow_concrete
fill 251 109 557 251 112 557 minecraft:orange_terracotta
fill 251 109 599 252 109 599 minecraft:orange_terracotta
setblock 253 109 599 minecraft:yellow_concrete
fill 254 109 599 254 112 599 minecraft:orange_terracotta
setblock 257 109 557 minecraft:orange_terracotta
fill 259 109 599 260 109 599 minecraft:orange_terracotta
fill 262 109 557 262 112 557 minecraft:orange_terracotta
setblock 263 109 557 minecraft:yellow_concrete
fill 265 109 599 265 112 599 minecraft:orange_terracotta
fill 266 109 557 267 109 557 minecraft:yellow_concrete
fill 269 109 599 269 111 599 minecraft:orange_terracotta
setblock 270 109 599 minecraft:yellow_concrete
fill 271 109 599 272 109 599 minecraft:orange_terracotta
fill 277 109 563 277 112 563 minecraft:orange_terracotta
setblock 277 109 567 minecraft:yellow_concrete
fill 277 109 568 277 109 569 minecraft:orange_terracotta
fill 277 109 572 277 113 572 minecraft:orange_terracotta
fill 277 109 574 277 112 574 minecraft:orange_terracotta
setblock 277 109 575 minecraft:yellow_concrete
setblock 277 109 576 minecraft:orange_terracotta
setblock 277 109 578 minecraft:yellow_concrete
fill 277 109 579 277 109 582 minecraft:orange_terracotta
fill 277 109 594 277 112 595 minecraft:orange_terracotta
fill 277 109 599 277 111 599 minecraft:orange_terracotta
fill 235 110 557 235 111 557 minecraft:orange_terracotta
setblock 235 110 559 minecraft:orange_terracotta
fill 235 110 560 235 111 560 minecraft:yellow_concrete
fill 235 110 561 235 115 562 minecraft:orange_terracotta
setblock 235 110 563 minecraft:yellow_concrete
fill 235 110 564 235 113 565 minecraft:orange_terracotta
fill 235 110 567 235 111 570 minecraft:orange_terracotta
fill 235 110 571 235 111 572 minecraft:yellow_concrete
fill 235 110 573 235 115 574 minecraft:orange_terracotta
fill 235 110 582 235 115 582 minecraft:orange_terracotta
fill 235 110 583 235 110 584 minecraft:yellow_concrete
fill 235 110 585 235 115 586 minecraft:orange_terracotta
fill 235 110 590 235 111 590 minecraft:orange_terracotta
fill 235 110 591 235 111 592 minecraft:yellow_concrete
fill 235 110 593 235 115 594 minecraft:orange_terracotta
setblock 235 110 595 minecraft:yellow_concrete
fill 235 110 596 235 113 596 minecraft:orange_terracotta
fill 236 110 557 237 111 557 minecraft:yellow_concrete
fill 237 110 599 238 111 599 minecraft:orange_terracotta
fill 239 110 599 240 111 599 minecraft:yellow_concrete
fill 241 110 599 242 115 599 minecraft:orange_terracotta
fill 242 110 557 243 115 557 minecraft:orange_terracotta
fill 244 110 557 245 110 557 minecraft:yellow_concrete
fill 246 110 557 246 115 557 minecraft:orange_terracotta
fill 248 110 599 248 111 599 minecraft:yellow_concrete
fill 249 110 599 250 111 599 minecraft:orange_terracotta
fill 251 110 599 252 110 599 minecraft:yellow_concrete
fill 253 110 599 253 115 599 minecraft:orange_terracotta
fill 254 110 557 255 115 557 minecraft:orange_terracotta
fill 256 110 557 257 111 557 minecraft:yellow_concrete
fill 259 110 599 260 111 599 minecraft:yellow_concrete
fill 261 110 599 262 115 599 minecraft:orange_terracotta
fill 263 110 557 264 113 557 minecraft:orange_terracotta
setblock 265 110 557 minecraft:yellow_concrete
fill 266 110 557 267 115 557 minecraft:orange_terracotta
fill 268 110 557 268 111 557 minecraft:yellow_concrete
setblock 269 110 557 minecraft:orange_terracotta
fill 270 110 599 270 111 599 minecraft:orange_terracotta
fill 271 110 599 272 110 599 minecraft:yellow_concrete
fill 273 110 599 274 115 599 minecraft:orange_terracotta
fill 274 110 557 275 115 557 minecraft:orange_terracotta
fill 276 110 557 277 110 557 minecraft:yellow_concrete
fill 277 110 566 277 115 567 minecraft:orange_terracotta
fill 277 110 568 277 111 569 minecraft:yellow_concrete
fill 277 110 575 277 115 575 minecraft:orange_terracotta
fill 277 110 576 277 110 577 minecraft:yellow_concrete
fill 277 110 578 277 111 579 minecraft:orange_terracotta
fill 277 110 580 277 111 580 minecraft:yellow_concrete
fill 277 110 581 277 110 582 minecraft:orange_terracotta
fill 277 110 586 277 115 587 minecraft:orange_terracotta
fill 277 110 588 277 111 589 minecraft:yellow_concrete
fill 277 110 596 277 113 596 minecraft:orange_terracotta
setblock 277 110 597 minecraft:yellow_concrete
fill 277 110 598 277 115 598 minecraft:orange_terracotta
setblock 235 111 559 minecraft:yellow_concrete
fill 235 111 563 235 114 563 minecraft:orange_terracotta
fill 235 111 579 235 111 580 minecraft:yellow_concrete
setblock 235 111 581 minecraft:orange_terracotta
setblock 235 111 583 minecraft:yellow_concrete
fill 235 111 584 235 114 584 minecraft:orange_terracotta
fill 235 111 595 235 114 595 minecraft:orange_terracotta
setblock 236 111 599 minecraft:yellow_concrete
setblock 238 111 560 minecraft:light[level=14]
setblock 238 111 568 minecraft:light[level=14]
setblock 238 111 576 minecraft:light[level=14]
setblock 238 111 584 minecraft:light[level=14]
setblock 238 111 592 minecraft:light[level=14]
fill 244 111 557 244 114 557 minecraft:orange_terracotta
setblock 245 111 557 minecraft:yellow_concrete
setblock 246 111 560 minecraft:light[level=14]
setblock 246 111 568 minecraft:light[level=14]
setblock 246 111 576 minecraft:light[level=14]
setblock 246 111 584 minecraft:light[level=14]
setblock 246 111 592 minecraft:light[level=14]
setblock 246 111 599 minecraft:orange_terracotta
setblock 247 111 557 minecraft:orange_terracotta
setblock 247 111 599 minecraft:yellow_concrete
fill 248 111 557 249 111 557 minecraft:yellow_concrete
fill 251 111 599 252 113 599 minecraft:orange_terracotta
setblock 254 111 560 minecraft:light[level=14]
setblock 254 111 568 minecraft:light[level=14]
setblock 254 111 576 minecraft:light[level=14]
setblock 254 111 584 minecraft:light[level=14]
setblock 254 111 592 minecraft:light[level=14]
setblock 262 111 560 minecraft:light[level=14]
setblock 262 111 568 minecraft:light[level=14]
setblock 262 111 576 minecraft:light[level=14]
setblock 262 111 584 minecraft:light[level=14]
setblock 262 111 592 minecraft:light[level=14]
fill 265 111 557 265 114 557 minecraft:orange_terracotta
setblock 266 111 599 minecraft:orange_terracotta
fill 267 111 599 268 111 599 minecraft:yellow_concrete
setblock 269 111 557 minecraft:yellow_concrete
setblock 270 111 560 minecraft:light[level=14]
setblock 270 111 568 minecraft:light[level=14]
setblock 270 111 576 minecraft:light[level=14]
setblock 270 111 584 minecraft:light[level=14]
setblock 270 111 592 minecraft:light[level=14]
setblock 271 111 599 minecraft:yellow_concrete
fill 272 111 599 272 114 599 minecraft:orange_terracotta
fill 276 111 557 276 114 557 minecraft:orange_terracotta
setblock 277 111 557 minecraft:yellow_concrete
setblock 277 111 560 minecraft:yellow_concrete
fill 277 111 576 277 114 577 minecraft:orange_terracotta
setblock 277 111 581 minecraft:yellow_concrete
setblock 277 111 582 minecraft:orange_terracotta
setblock 277 111 592 minecraft:yellow_concrete
fill 277 111 597 277 114 597 minecraft:orange_terracotta
fill 235 112 557 235 113 558 minecraft:yellow_concrete
fill 235 112 559 235 117 560 minecraft:orange_terracotta
fill 235 112 567 235 113 568 minecraft:orange_terracotta
fill 235 112 569 235 112 570 minecraft:yellow_concrete
fill 235 112 571 235 117 572 minecraft:orange_terracotta
fill 235 112 578 235 113 578 minecraft:yellow_concrete
fill 235 112 579 235 117 580 minecraft:orange_terracotta
setblock 235 112 581 minecraft:yellow_concrete
fill 235 112 583 235 117 583 minecraft:orange_terracotta
fill 235 112 589 235 113 590 minecraft:yellow_concrete
fill 235 112 591 235 117 592 minecraft:orange_terracotta
fill 236 112 557 237 117 557 minecraft:orange_terracotta
fill 236 112 599 236 117 599 minecraft:orange_terracotta
fill 237 112 599 238 112 599 minecraft:yellow_concrete
fill 238 112 557 239 113 557 minecraft:yellow_concrete
fill 239 112 599 240 114 599 minecraft:orange_terracotta
fill 245 112 557 245 117 557 minecraft:orange_terracotta
fill 245 112 599 246 113 599 minecraft:yellow_concrete
setblock 247 112 557 minecraft:yellow_concrete
fill 247 112 599 248 117 599 minecraft:orange_terracotta
fill 248 112 557 249 117 557 minecraft:orange_terracotta
setblock 249 112 599 minecraft:yellow_concrete
fill 250 112 557 250 113 557 minecraft:yellow_concrete
fill 250 112 599 250 115 599 minecraft:orange_terracotta
fill 256 112 557 257 117 557 minecraft:orange_terracotta
fill 257 112 599 258 113 599 minecraft:yellow_concrete
fill 258 112 557 259 112 557 minecraft:yellow_concrete
fill 259 112 599 260 117 599 minecraft:orange_terracotta
fill 260 112 557 261 113 557 minecraft:orange_terracotta
fill 266 112 599 266 113 599 minecraft:yellow_concrete
fill 267 112 599 268 113 599 minecraft:orange_terracotta
fill 268 112 557 269 117 557 minecraft:orange_terracotta
fill 269 112 599 270 112 599 minecraft:yellow_concrete
fill 270 112 557 271 113 557 minecraft:yellow_concrete
fill 271 112 599 271 117 599 minecraft:orange_terracotta
fill 277 112 557 277 117 557 minecraft:orange_terracotta
fill 277 112 558 277 112 559 minecraft:yellow_concrete
fill 277 112 560 277 113 561 minecraft:orange_terracotta
fill 277 112 562 277 113 562 minecraft:yellow_concrete
fill 277 112 568 277 117 569 minecraft:orange_terracotta
fill 277 112 570 277 113 571 minecraft:yellow_concrete
fill 277 112 578 277 115 578 minecraft:orange_terracotta
setblock 277 112 579 minecraft:yellow_concrete
fill 277 112 580 277 117 581 minecraft:orange_terracotta
fill 277 112 582 277 113 583 minecraft:yellow_concrete
fill 277 112 584 277 113 585 minecraft:orange_terracotta
fill 277 112 588 277 117 589 minecraft:orange_terracotta
fill 277 112 590 277 112 591 minecraft:yellow_concrete
fill 277 112 592 277 117 592 minecraft:orange_terracotta
fill 277 112 599 277 113 599 minecraft:yellow_concrete
setblock 235 113 566 minecraft:yellow_concrete
setblock 235 113 569 minecraft:yellow_concrete
fill 235 113 570 235 116 570 minecraft:orange_terracotta
setblock 235 113 577 minecraft:yellow_concrete
fill 235 113 581 235 116 581 minecraft:orange_terracotta
fill 235 113 597 235 113 598 minecraft:yellow_concrete
setblock 237 113 599 minecraft:yellow_concrete
fill 238 113 599 238 116 599 minecraft:orange_terracotta
fill 247 113 557 247 116 557 minecraft:orange_terracotta
fill 249 113 599 249 115 599 minecraft:orange_terracotta
setblock 251 113 557 minecraft:yellow_concrete
setblock 254 113 599 minecraft:yellow_concrete
fill 258 113 557 258 116 557 minecraft:orange_terracotta
setblock 259 113 557 minecraft:yellow_concrete
setblock 262 113 557 minecraft:yellow_concrete
setblock 265 113 599 minecraft:yellow_concrete
fill 269 113 599 270 115 599 minecraft:orange_terracotta
fill 277 113 558 277 116 559 minecraft:orange_terracotta
setblock 277 113 563 minecraft:yellow_concrete
setblock 277 113 574 minecraft:yellow_concrete
fill 277 113 579 277 116 579 minecraft:orange_terracotta
fill 277 113 590 277 116 590 minecraft:orange_terracotta
setblock 277 113 591 minecraft:yellow_concrete
fill 277 113 594 277 113 595 minecraft:yellow_concrete
fill 235 114 557 235 119 558 minecraft:orange_terracotta
fill 235 114 564 235 115 564 minecraft:yellow_concrete
fill 235 114 565 235 115 566 minecraft:orange_terracotta
fill 235 114 567 235 114 568 minecraft:yellow_concrete
fill 235 114 569 235 119 569 minecraft:orange_terracotta
fill 235 114 575 235 115 576 minecraft:yellow_concrete
fill 235 114 577 235 119 578 minecraft:orange_terracotta
fill 235 114 587 235 114 588 minecraft:yellow_concrete
fill 235 114 589 235 119 590 minecraft:orange_terracotta
fill 235 114 596 235 115 596 minecraft:yellow_concrete
fill 235 114 597 235 119 598 minecraft:orange_terracotta
setblock 235 114 599 minecraft:yellow_concrete
fill 236 114 558 238 114 558 minecraft:orange_concrete
fill 236 114 560 236 114 562 minecraft:orange_concrete
fill 236 114 564 236 114 566 minecraft:orange_concrete
fill 236 114 568 236 114 570 minecraft:orange_concrete
fill 236 114 572 236 114 574 minecraft:orange_concrete
fill 236 114 576 236 114 578 minecraft:orange_concrete
fill 236 114 580 236 114 582 minecraft:orange_concrete
fill 236 114 584 236 114 586 minecraft:orange_concrete
fill 236 114 588 236 114 590 minecraft:orange_concrete
fill 236 114 592 236 114 594 minecraft:orange_concrete
fill 236 114 596 236 114 598 minecraft:orange_concrete
fill 237 114 599 237 116 599 minecraft:orange_terracotta
fill 238 114 557 239 119 557 minecraft:orange_terracotta
fill 238 114 598 240 114 598 minecraft:orange_concrete
fill 240 114 557 241 114 557 minecraft:yellow_concrete
fill 240 114 558 242 114 558 minecraft:orange_concrete
fill 242 114 598 244 114 598 minecraft:orange_concrete
fill 243 114 599 244 115 599 minecraft:yellow_concrete
fill 244 114 558 246 114 558 minecraft:orange_concrete
fill 245 114 599 246 119 599 minecraft:orange_terracotta
fill 246 114 598 248 114 598 minecraft:orange_concrete
fill 248 114 558 250 114 558 minecraft:orange_concrete
fill 250 114 557 251 119 557 minecraft:orange_terracotta
fill 250 114 598 252 114 598 minecraft:orange_concrete
setblock 251 114 599 minecraft:orange_terracotta
fill 252 114 557 253 115 557 minecraft:yellow_concrete
fill 252 114 558 254 114 558 minecraft:orange_concrete
fill 252 114 599 252 115 599 minecraft:yellow_concrete
fill 254 114 598 256 114 598 minecraft:orange_concrete
fill 254 114 599 254 119 599 minecraft:orange_terracotta
fill 255 114 599 256 114 599 minecraft:yellow_concrete
fill 256 114 558 258 114 558 minecraft:orange_concrete
fill 257 114 599 258 116 599 minecraft:orange_terracotta
fill 258 114 598 260 114 598 minecraft:orange_concrete
fill 259 114 557 259 119 557 minecraft:orange_terracotta
fill 260 114 557 261 114 557 minecraft:yellow_concrete
fill 260 114 558 262 114 558 minecraft:orange_concrete
fill 262 114 557 263 115 557 minecraft:orange_terracotta
fill 262 114 598 264 114 598 minecraft:orange_concrete
fill 263 114 599 264 115 599 minecraft:yellow_concrete
fill 264 114 557 264 115 557 minecraft:yellow_concrete
fill 264 114 558 266 114 558 minecraft:orange_concrete
fill 265 114 599 266 119 599 minecraft:orange_terracotta
fill 266 114 598 268 114 598 minecraft:orange_concrete
setblock 267 114 599 minecraft:yellow_concrete
fill 268 114 558 270 114 558 minecraft:orange_concrete
fill 268 114 599 268 117 599 minecraft:orange_terracotta
fill 270 114 557 271 119 557 minecraft:orange_terracotta
fill 270 114 598 272 114 598 minecraft:orange_concrete
fill 272 114 557 273 115 557 minecraft:yellow_concrete
fill 272 114 558 274 114 558 minecraft:orange_concrete
fill 274 114 598 276 114 598 minecraft:orange_concrete
fill 275 114 599 276 114 599 minecraft:yellow_concrete
fill 276 114 558 276 114 560 minecraft:orange_concrete
fill 276 114 562 276 114 564 minecraft:orange_concrete
fill 276 114 566 276 114 568 minecraft:orange_concrete
fill 276 114 570 276 114 572 minecraft:orange_concrete
fill 276 114 574 276 114 576 minecraft:orange_concrete
fill 276 114 578 276 114 580 minecraft:orange_concrete
fill 276 114 582 276 114 584 minecraft:orange_concrete
fill 276 114 586 276 114 588 minecraft:orange_concrete
fill 276 114 590 276 114 592 minecraft:orange_concrete
fill 276 114 594 276 114 596 minecraft:orange_concrete
fill 277 114 560 277 117 560 minecraft:orange_terracotta
setblock 277 114 561 minecraft:yellow_concrete
fill 277 114 562 277 119 563 minecraft:orange_terracotta
fill 277 114 564 277 115 565 minecraft:yellow_concrete
fill 277 114 570 277 119 571 minecraft:orange_terracotta
fill 277 114 572 277 114 573 minecraft:yellow_concrete
fill 277 114 574 277 119 574 minecraft:orange_terracotta
fill 277 114 582 277 119 583 minecraft:orange_terracotta
fill 277 114 584 277 115 585 minecraft:yellow_concrete
fill 277 114 591 277 119 591 minecraft:orange_terracotta
setblock 277 114 593 minecraft:yellow_concrete
fill 277 114 594 277 119 595 minecraft:orange_terracotta
fill 277 114 596 277 115 596 minecraft:yellow_concrete
fill 277 114 599 277 119 599 minecraft:orange_terracotta
setblock 235 115 563 minecraft:yellow_concrete
fill 235 115 567 235 118 568 minecraft:orange_terracotta
setblock 235 115 584 minecraft:yellow_concrete
setblock 235 115 587 minecraft:yellow_concrete
fill 235 115 588 235 118 588 minecraft:orange_terracotta
setblock 235 115 595 minecraft:yellow_concrete
fill 235 115 599 235 118 599 minecraft:orange_terracotta
fill 239 115 599 239 117 599 minecraft:orange_terracotta
fill 240 115 557 240 118 557 minecraft:orange_terracotta
setblock 240 115 599 minecraft:yellow_concrete
setblock 241 115 557 minecraft:yellow_concrete
setblock 244 115 557 minecraft:yellow_concrete
setblock 251 115 599 minecraft:yellow_concrete
setblock 255 115 599 minecraft:yellow_concrete
fill 256 115 599 256 118 599 minecraft:orange_terracotta
fill 260 115 557 261 118 557 minecraft:orange_terracotta
setblock 265 115 557 minecraft:yellow_concrete
fill 267 115 599 267 117 599 minecraft:orange_terracotta
setblock 272 115 599 minecraft:yellow_concrete
setblock 275 115 599 minecraft:yellow_concrete
setblock 276 115 557 minecraft:yellow_concrete
fill 276 115 599 276 118 599 minecraft:orange_terracotta
fill 277 115 561 277 118 561 minecraft:orange_terracotta
fill 277 115 572 277 118 572 minecraft:orange_terracotta
setblock 277 115 573 minecraft:yellow_concrete
fill 277 115 576 277 115 577 minecraft:yellow_concrete
fill 277 115 593 277 118 593 minecraft:orange_terracotta
setblock 277 115 597 minecraft:yellow_concrete
fill 235 116 561 235 117 562 minecraft:yellow_concrete
fill 235 116 563 235 121 564 minecraft:orange_terracotta
setblock 235 116 565 minecraft:yellow_concrete
fill 235 116 566 235 119 566 minecraft:orange_terracotta
fill 235 116 573 235 117 574 minecraft:yellow_concrete
fill 235 116 575 235 121 576 minecraft:orange_terracotta
fill 235 116 582 235 117 582 minecraft:yellow_concrete
fill 235 116 584 235 121 584 minecraft:orange_terracotta
fill 235 116 585 235 116 586 minecraft:yellow_concrete
fill 235 116 587 235 121 587 minecraft:orange_terracotta
fill 235 116 593 235 117 594 minecraft:yellow_concrete
fill 235 116 595 235 121 596 minecraft:orange_terracotta
fill 240 116 599 240 117 599 minecraft:orange_terracotta
fill 241 116 557 241 121 557 minecraft:orange_terracotta
fill 241 116 599 242 116 599 minecraft:yellow_concrete
fill 242 116 557 243 116 557 minecraft:yellow_concrete
fill 243 116 599 244 121 599 minecraft:orange_terracotta
fill 244 116 557 244 121 557 minecraft:orange_terracotta
fill 246 116 557 246 117 557 minecraft:yellow_concrete
fill 249 116 599 250 117 599 minecraft:yellow_concrete
fill 251 116 599 252 121 599 minecraft:orange_terracotta
fill 252 116 557 253 121 557 minecraft:orange_terracotta
setblock 253 116 599 minecraft:yellow_concrete
fill 254 116 557 255 117 557 minecraft:yellow_concrete
fill 255 116 599 255 118 599 minecraft:orange_terracotta
fill 261 116 599 262 117 599 minecraft:yellow_concrete
fill 262 116 557 262 119 557 minecraft:orange_terracotta
setblock 263 116 557 minecraft:yellow_concrete
fill 263 116 599 264 121 599 minecraft:orange_terracotta
fill 264 116 557 265 121 557 minecraft:orange_terracotta
fill 266 116 557 267 117 557 minecraft:yellow_concrete
setblock 269 116 599 minecraft:orange_terracotta
fill 270 116 599 270 117 599 minecraft:yellow_concrete
fill 272 116 557 273 121 557 minecraft:orange_terracotta
fill 272 116 599 272 121 599 minecraft:orange_terracotta
fill 273 116 599 274 116 599 minecraft:yellow_concrete
fill 274 116 557 275 116 557 minecraft:yellow_concrete
fill 275 116 599 275 121 599 minecraft:orange_terracotta
fill 276 116 557 276 121 557 minecraft:orange_terracotta
fill 277 116 564 277 121 565 minecraft:orange_terracotta
fill 277 116 566 277 117 567 minecraft:yellow_concrete
fill 277 116 573 277 121 573 minecraft:orange_terracotta
setblock 277 116 575 minecraft:yellow_concrete
fill 277 116 576 277 121 577 minecraft:orange_terracotta
fill 277 116 578 277 117 578 minecraft:yellow_concrete
fill 277 116 584 277 121 585 minecraft:orange_terracotta
fill 277 116 586 277 116 587 minecraft:yellow_concrete
fill 277 116 596 277 121 597 minecraft:orange_terracotta
fill 277 116 598 277 117 598 minecraft:yellow_concrete
fill 235 117 565 235 120 565 minecraft:orange_terracotta
setblock 235 117 570 minecraft:yellow_concrete
setblock 235 117 581 minecraft:yellow_concrete
fill 235 117 585 235 120 586 minecraft:orange_terracotta
fill 237 117 599 238 117 599 minecraft:yellow_concrete
setblock 241 117 599 minecraft:yellow_concrete
fill 242 117 557 243 120 557 minecraft:orange_terracotta
fill 242 117 599 242 120 599 minecraft:orange_terracotta
setblock 247 117 557 minecraft:yellow_concrete
fill 253 117 599 253 120 599 minecraft:orange_terracotta
fill 257 117 599 257 119 599 minecraft:orange_terracotta
setblock 258 117 557 minecraft:yellow_concrete
setblock 258 117 599 minecraft:yellow_concrete
fill 263 117 557 263 120 557 minecraft:orange_terracotta
setblock 269 117 599 minecraft:yellow_concrete
fill 273 117 599 274 120 599 minecraft:orange_terracotta
fill 274 117 557 274 120 557 minecraft:orange_terracotta
setblock 275 117 557 minecraft:yellow_concrete
fill 277 117 558 277 117 559 minecraft:yellow_concrete
fill 277 117 575 277 120 575 minecraft:orange_terracotta
setblock 277 117 579 minecraft:yellow_concrete
fill 277 117 586 277 120 586 minecraft:orange_terracotta
setblock 277 117 587 minecraft:yellow_concrete
setblock 277 117 590 minecraft:yellow_concrete
fill 235 118 559 235 119 560 minecraft:yellow_concrete
fill 235 118 561 235 123 562 minecraft:orange_terracotta
fill 235 118 570 235 123 570 minecraft:orange_terracotta
fill 235 118 571 235 118 572 minecraft:yellow_concrete
fill 235 118 573 235 123 574 minecraft:orange_terracotta
fill 235 118 579 235 119 580 minecraft:yellow_concrete
fill 235 118 581 235 123 582 minecraft:orange_terracotta
setblock 235 118 583 minecraft:yellow_concrete
fill 235 118 591 235 119 592 minecraft:yellow_concrete
fill 235 118 593 235 123 594 minecraft:orange_terracotta
fill 236 118 557 237 119 557 minecraft:yellow_concrete
fill 236 118 599 236 119 599 minecraft:yellow_concrete
fill 237 118 599 238 119 599 minecraft:orange_terracotta
fill 239 118 599 240 118 599 minecraft:yellow_concrete
fill 241 118 599 241 123 599 minecraft:orange_terracotta
setblock 245 118 557 minecraft:yellow_concrete
fill 246 118 557 247 123 557 minecraft:orange_terracotta
fill 247 118 599 248 119 599 minecraft:yellow_concrete
fill 248 118 557 249 119 557 minecraft:yellow_concrete
fill 249 118 599 250 123 599 minecraft:orange_terracotta
fill 254 118 557 255 123 557 minecraft:orange_terracotta
fill 256 118 557 257 118 557 minecraft:yellow_concrete
fill 258 118 557 258 123 557 minecraft:orange_terracotta
fill 258 118 599 258 119 599 minecraft:orange_terracotta
fill 259 118 599 260 118 599 minecraft:yellow_concrete
fill 261 118 599 262 123 599 minecraft:orange_terracotta
fill 266 118 557 267 123 557 minecraft:orange_terracotta
fill 267 118 599 268 119 599 minecraft:yellow_concrete
fill 268 118 557 269 119 557 minecraft:yellow_concrete
fill 269 118 599 270 123 599 minecraft:orange_terracotta
setblock 271 118 599 minecraft:yellow_concrete
fill 275 118 557 275 123 557 minecraft:orange_terracotta
setblock 277 118 557 minecraft:yellow_concrete
fill 277 118 558 277 123 559 minecraft:orange_terracotta
fill 277 118 560 277 119 560 minecraft:yellow_concrete
fill 277 118 566 277 123 567 minecraft:orange_terracotta
fill 277 118 568 277 118 569 minecraft:yellow_concrete
fill 277 118 578 277 123 579 minecraft:orange_terracotta
fill 277 118 580 277 119 581 minecraft:yellow_concrete
fill 277 118 587 277 123 587 minecraft:orange_terracotta
fill 277 118 588 277 118 589 minecraft:yellow_concrete
fill 277 118 590 277 123 590 minecraft:orange_terracotta
fill 277 118 592 277 119 592 minecraft:yellow_concrete
fill 277 118 598 277 123 598 minecraft:orange_terracotta
fill 235 119 567 235 119 568 minecraft:yellow_concrete
setblock 235 119 571 minecraft:yellow_concrete
fill 235 119 572 235 122 572 minecraft:orange_terracotta
fill 235 119 583 235 122 583 minecraft:orange_terracotta
setblock 235 119 588 minecraft:yellow_concrete
setblock 235 119 599 minecraft:yellow_concrete
setblock 238 119 560 minecraft:light[level=14]
setblock 238 119 568 minecraft:light[level=14]
setblock 238 119 576 minecraft:light[level=14]
setblock 238 119 584 minecraft:light[level=14]
setblock 238 119 592 minecraft:light[level=14]
fill 239 119 599 240 121 599 minecraft:orange_terracotta
setblock 240 119 557 minecraft:yellow_concrete
fill 245 119 557 245 122 557 minecraft:orange_terracotta
setblock 246 119 560 minecraft:light[level=14]
setblock 246 119 568 minecraft:light[level=14]
setblock 246 119 576 minecraft:light[level=14]
setblock 246 119 584 minecraft:light[level=14]
setblock 246 119 592 minecraft:light[level=14]
setblock 254 119 560 minecraft:light[level=14]
setblock 254 119 568 minecraft:light[level=14]
setblock 254 119 576 minecraft:light[level=14]
setblock 254 119 584 minecraft:light[level=14]
setblock 254 119 592 minecraft:light[level=14]
fill 255 119 599 256 119 599 minecraft:yellow_concrete
fill 256 119 557 256 122 557 minecraft:orange_terracotta
setblock 257 119 557 minecraft:yellow_concrete
setblock 259 119 599 minecraft:yellow_concrete
fill 260 119 557 261 119 557 minecraft:yellow_concrete
fill 260 119 599 260 122 599 minecraft:orange_terracotta
setblock 262 119 560 minecraft:light[level=14]
setblock 262 119 568 minecraft:light[level=14]
setblock 262 119 576 minecraft:light[level=14]
setblock 262 119 584 minecraft:light[level=14]
setblock 262 119 592 minecraft:light[level=14]
setblock 270 119 560 minecraft:light[level=14]
setblock 270 119 568 minecraft:light[level=14]
setblock 270 119 576 minecraft:light[level=14]
setblock 270 119 584 minecraft:light[level=14]
setblock 270 119 592 minecraft:light[level=14]
fill 271 119 599 271 122 599 minecraft:orange_terracotta
setblock 276 119 599 minecraft:yellow_concrete
fill 277 119 557 277 122 557 minecraft:orange_terracotta
setblock 277 119 561 minecraft:yellow_concrete
fill 277 119 568 277 122 568 minecraft:orange_terracotta
setblock 277 119 569 minecraft:yellow_concrete
setblock 277 119 572 minecraft:yellow_concrete
fill 277 119 588 277 122 589 minecraft:orange_terracotta
setblock 277 119 593 minecraft:yellow_concrete
fill 235 120 557 235 120 558 minecraft:yellow_concrete
fill 235 120 559 235 125 560 minecraft:orange_terracotta
fill 235 120 566 235 121 566 minecraft:yellow_concrete
fill 235 120 567 235 125 568 minecraft:orange_terracotta
setblock 235 120 569 minecraft:yellow_concrete
fill 235 120 571 235 125 571 minecraft:orange_terracotta
fill 235 120 577 235 121 578 minecraft:yellow_concrete
fill 235 120 579 235 125 580 minecraft:orange_terracotta
fill 235 120 588 235 125 588 minecraft:orange_terracotta
fill 235 120 589 235 120 590 minecraft:yellow_concrete
fill 235 120 591 235 122 592 minecraft:orange_terracotta
fill 235 120 597 235 121 598 minecraft:yellow_concrete
fill 235 120 599 236 125 599 minecraft:orange_terracotta
fill 236 120 557 237 125 557 minecraft:orange_terracotta
fill 236 120 558 238 120 558 minecraft:orange_concrete
fill 236 120 560 236 120 562 minecraft:orange_concrete
fill 236 120 564 236 120 566 minecraft:orange_concrete
fill 236 120 568 236 120 570 minecraft:orange_concrete
fill 236 120 572 236 120 574 minecraft:orange_concrete
fill 236 120 576 236 120 578 minecraft:orange_concrete
fill 236 120 580 236 120 582 minecraft:orange_concrete
fill 236 120 584 236 120 586 minecraft:orange_concrete
fill 236 120 588 236 120 590 minecraft:orange_concrete
fill 236 120 592 236 120 594 minecraft:orange_concrete
fill 236 120 596 236 120 598 minecraft:orange_concrete
setblock 237 120 599 minecraft:yellow_concrete
fill 238 120 557 239 120 557 minecraft:yellow_concrete
fill 238 120 598 240 120 598 minecraft:orange_concrete
fill 238 120 599 238 123 599 minecraft:orange_terracotta
fill 240 120 557 240 125 557 minecraft:orange_terracotta
fill 240 120 558 242 120 558 minecraft:orange_concrete
fill 242 120 598 244 120 598 minecraft:orange_concrete
fill 244 120 558 246 120 558 minecraft:orange_concrete
fill 245 120 599 246 121 599 minecraft:yellow_concrete
fill 246 120 598 248 120 598 minecraft:orange_concrete
fill 247 120 599 248 125 599 minecraft:orange_terracotta
fill 248 120 557 249 125 557 minecraft:orange_terracotta
fill 248 120 558 250 120 558 minecraft:orange_concrete
fill 250 120 557 251 121 557 minecraft:yellow_concrete
fill 250 120 594 250 121 595 minecraft:yellow_concrete
fill 250 120 598 252 120 598 minecraft:orange_concrete
fill 252 120 558 254 120 558 minecraft:orange_concrete
fill 254 120 598 256 120 598 minecraft:orange_concrete
fill 254 120 599 254 121 599 minecraft:yellow_concrete
fill 255 120 599 256 121 599 minecraft:orange_terracotta
fill 256 120 558 258 120 558 minecraft:orange_concrete
fill 257 120 557 257 125 557 minecraft:orange_terracotta
fill 257 120 599 258 120 599 minecraft:yellow_concrete
fill 258 120 598 260 120 598 minecraft:orange_concrete
setblock 259 120 557 minecraft:yellow_concrete
fill 259 120 587 259 121 587 minecraft:shroomlight
fill 259 120 599 259 125 599 minecraft:orange_terracotta
fill 260 120 557 261 125 557 minecraft:orange_terracotta
fill 260 120 558 262 120 558 minecraft:orange_concrete
fill 260 120 594 260 121 594 minecraft:orange_concrete
fill 262 120 557 262 121 557 minecraft:yellow_concrete
fill 262 120 598 264 120 598 minecraft:orange_concrete
fill 264 120 558 266 120 558 minecraft:orange_concrete
fill 265 120 599 266 121 599 minecraft:yellow_concrete
fill 266 120 598 268 120 598 minecraft:orange_concrete
fill 267 120 599 268 125 599 minecraft:orange_terracotta
fill 268 120 557 269 125 557 minecraft:orange_terracotta
fill 268 120 558 270 120 558 minecraft:orange_concrete
fill 270 120 557 271 120 557 minecraft:yellow_concrete
fill 270 120 598 272 120 598 minecraft:orange_concrete
fill 272 120 558 274 120 558 minecraft:orange_concrete
fill 274 120 598 276 120 598 minecraft:orange_concrete
fill 276 120 558 276 120 560 minecraft:orange_concrete
fill 276 120 562 276 120 564 minecraft:orange_concrete
fill 276 120 566 276 120 568 minecraft:orange_concrete
fill 276 120 570 276 120 572 minecraft:orange_concrete
fill 276 120 574 276 120 576 minecraft:orange_concrete
fill 276 120 578 276 120 580 minecraft:orange_concrete
fill 276 120 582 276 120 584 minecraft:orange_concrete
fill 276 120 586 276 120 588 minecraft:orange_concrete
fill 276 120 590 276 120 592 minecraft:orange_concrete
fill 276 120 594 276 120 596 minecraft:orange_concrete
fill 276 120 599 276 125 599 minecraft:orange_terracotta
fill 277 120 560 277 125 561 minecraft:orange_terracotta
fill 277 120 562 277 121 563 minecraft:yellow_concrete
fill 277 120 569 277 125 569 minecraft:orange_terracotta
fill 277 120 570 277 120 571 minecraft:yellow_concrete
fill 277 120 572 277 125 572 minecraft:orange_terracotta
fill 277 120 574 277 121 574 minecraft:yellow_concrete
fill 277 120 580 277 125 581 minecraft:orange_terracotta
fill 277 120 582 277 121 583 minecraft:yellow_concrete
setblock 277 120 591 minecraft:yellow_concrete
fill 277 120 592 277 125 593 minecraft:orange_terracotta
fill 277 120 594 277 121 595 minecraft:yellow_concrete
fill 277 120 599 277 121 599 minecraft:yellow_concrete
setblock 235 121 557 minecraft:yellow_concrete
fill 235 121 558 235 124 558 minecraft:orange_terracotta
setblock 235 121 565 minecraft:yellow_concrete
fill 235 121 569 235 124 569 minecraft:orange_terracotta
fill 235 121 585 235 121 586 minecraft:yellow_concrete
setblock 235 121 589 minecraft:yellow_concrete
fill 235 121 590 235 124 590 minecraft:orange_terracotta
fill 237 121 599 237 123 599 minecraft:orange_terracotta
fill 238 121 557 238 124 557 minecraft:orange_terracotta
setblock 239 121 557 minecraft:yellow_concrete
fill 242 121 557 243 121 557 minecraft:yellow_concrete
setblock 242 121 599 minecraft:yellow_concrete
setblock 253 121 599 minecraft:yellow_concrete
fill 257 121 599 258 123 599 minecraft:orange_terracotta
fill 259 121 557 259 124 557 minecraft:orange_terracotta
setblock 263 121 557 minecraft:yellow_concrete
fill 270 121 557 270 124 557 minecraft:orange_terracotta
setblock 271 121 557 minecraft:yellow_concrete
fill 273 121 599 274 121 599 minecraft:yellow_concrete
setblock 274 121 557 minecraft:yellow_concrete
fill 277 121 570 277 124 571 minecraft:orange_terracotta
setblock 277 121 575 minecraft:yellow_concrete
setblock 277 121 586 minecraft:yellow_concrete
fill 277 121 591 277 124 591 minecraft:orange_terracotta
fill 235 122 557 235 127 557 minecraft:orange_terracotta
fill 235 122 563 235 123 564 minecraft:yellow_concrete
fill 235 122 565 235 127 566 minecraft:orange_terracotta
fill 235 122 575 235 122 576 minecraft:yellow_concrete
fill 235 122 577 235 127 578 minecraft:orange_terracotta
fill 235 122 584 235 123 584 minecraft:yellow_concrete
fill 235 122 585 235 127 586 minecraft:orange_terracotta
setblock 235 122 587 minecraft:yellow_concrete
fill 235 122 589 235 124 589 minecraft:orange_terracotta
fill 235 122 595 235 123 596 minecraft:yellow_concrete
fill 235 122 597 235 127 598 minecraft:orange_terracotta
fill 239 122 557 239 127 557 minecraft:orange_terracotta
setblock 239 122 599 minecraft:orange_terracotta
fill 240 122 599 240 123 599 minecraft:yellow_concrete
setblock 241 122 557 minecraft:yellow_concrete
fill 242 122 557 243 127 557 minecraft:orange_terracotta
fill 242 122 599 242 127 599 minecraft:orange_terracotta
fill 243 122 599 244 122 599 minecraft:yellow_concrete
fill 244 122 557 244 123 557 minecraft:yellow_concrete
fill 245 122 599 246 124 599 minecraft:orange_terracotta
fill 250 122 557 251 127 557 minecraft:orange_terracotta
fill 251 122 599 252 123 599 minecraft:yellow_concrete
fill 252 122 557 253 122 557 minecraft:yellow_concrete
fill 253 122 599 254 127 599 minecraft:orange_terracotta
setblock 255 122 599 minecraft:yellow_concrete
fill 256 122 599 256 125 599 minecraft:orange_terracotta
fill 262 122 557 263 127 557 minecraft:orange_terracotta
fill 263 122 599 264 122 599 minecraft:yellow_concrete
fill 264 122 557 265 123 557 minecraft:yellow_concrete
fill 265 122 599 266 127 599 minecraft:orange_terracotta
fill 271 122 557 271 127 557 minecraft:orange_terracotta
fill 272 122 557 273 122 557 minecraft:yellow_concrete
fill 272 122 599 272 123 599 minecraft:yellow_concrete
fill 273 122 599 274 127 599 minecraft:orange_terracotta
fill 274 122 557 274 127 557 minecraft:orange_terracotta
setblock 275 122 599 minecraft:yellow_concrete
fill 276 122 557 276 123 557 minecraft:yellow_concrete
fill 277 122 562 277 127 563 minecraft:orange_terracotta
fill 277 122 564 277 123 565 minecraft:yellow_concrete
setblock 277 122 573 minecraft:yellow_concrete
fill 277 122 574 277 127 575 minecraft:orange_terracotta
fill 277 122 576 277 123 577 minecraft:yellow_concrete
fill 277 122 582 277 127 583 minecraft:orange_terracotta
fill 277 122 584 277 122 585 minecraft:yellow_concrete
fill 277 122 586 277 127 586 minecraft:orange_terracotta
fill 277 122 594 277 127 595 minecraft:orange_terracotta
fill 277 122 596 277 123 597 minecraft:yellow_concrete
fill 277 122 599 277 127 599 minecraft:orange_terracotta
setblock 235 123 572 minecraft:yellow_concrete
setblock 235 123 575 minecraft:yellow_concrete
fill 235 123 576 235 126 576 minecraft:orange_terracotta
setblock 235 123 583 minecraft:yellow_concrete
fill 235 123 587 235 126 587 minecraft:orange_terracotta
fill 235 123 591 235 125 591 minecraft:orange_terracotta
setblock 235 123 592 minecraft:yellow_concrete
setblock 239 123 599 minecraft:yellow_concrete
fill 241 123 557 241 126 557 minecraft:orange_terracotta
setblock 243 123 599 minecraft:yellow_concrete
fill 244 123 599 244 126 599 minecraft:orange_terracotta
setblock 245 123 557 minecraft:yellow_concrete
fill 252 123 557 252 126 557 minecraft:orange_terracotta
setblock 253 123 557 minecraft:yellow_concrete
fill 255 123 599 255 125 599 minecraft:orange_terracotta
setblock 256 123 557 minecraft:yellow_concrete
setblock 260 123 599 minecraft:yellow_concrete
setblock 263 123 599 minecraft:yellow_concrete
fill 264 123 579 264 124 580 minecraft:shroomlight
fill 264 123 599 264 126 599 minecraft:orange_terracotta
setblock 271 123 599 minecraft:yellow_concrete
fill 272 123 557 273 126 557 minecraft:orange_terracotta
fill 275 123 599 275 126 599 minecraft:orange_terracotta
setblock 277 123 557 minecraft:yellow_concrete
setblock 277 123 568 minecraft:yellow_concrete
fill 277 123 573 277 126 573 minecraft:orange_terracotta
fill 277 123 584 277 126 584 minecraft:orange_terracotta
setblock 277 123 585 minecraft:yellow_concrete
fill 277 123 588 277 123 589 minecraft:yellow_concrete
fill 235 124 561 235 125 562 minecraft:yellow_concrete
fill 235 124 563 235 129 564 minecraft:orange_terracotta
fill 235 124 570 235 125 570 minecraft:yellow_concrete
fill 235 124 572 235 129 572 minecraft:orange_terracotta
fill 235 124 573 235 124 574 minecraft:yellow_concrete
fill 235 124 575 235 129 575 minecraft:orange_terracotta
fill 235 124 581 235 125 582 minecraft:yellow_concrete
fill 235 124 583 235 129 584 minecraft:orange_terracotta
fill 235 124 592 235 125 592 minecraft:orange_terracotta
fill 235 124 593 235 124 594 minecraft:yellow_concrete
fill 235 124 595 235 129 596 minecraft:orange_terracotta
fill 237 124 599 238 125 599 minecraft:yellow_concrete
fill 239 124 599 240 129 599 minecraft:orange_terracotta
setblock 241 124 599 minecraft:yellow_concrete
fill 243 124 599 243 126 599 minecraft:orange_terracotta
fill 244 124 557 245 129 557 minecraft:orange_terracotta
fill 246 124 557 247 125 557 minecraft:yellow_concrete
fill 249 124 599 250 125 599 minecraft:yellow_concrete
fill 251 124 599 252 129 599 minecraft:orange_terracotta
fill 253 124 557 253 129 557 minecraft:orange_terracotta
fill 254 124 557 255 124 557 minecraft:yellow_concrete
fill 256 124 557 256 129 557 minecraft:orange_terracotta
setblock 257 124 599 minecraft:orange_terracotta
fill 258 124 557 258 125 557 minecraft:yellow_concrete
fill 258 124 599 258 125 599 minecraft:yellow_concrete
fill 260 124 599 260 129 599 minecraft:orange_terracotta
fill 261 124 599 262 124 599 minecraft:yellow_concrete
fill 263 124 599 263 129 599 minecraft:orange_terracotta
fill 264 124 557 265 129 557 minecraft:orange_terracotta
fill 266 124 557 267 125 557 minecraft:yellow_concrete
fill 269 124 599 270 125 599 minecraft:yellow_concrete
fill 271 124 599 272 129 599 minecraft:orange_terracotta
setblock 275 124 557 minecraft:yellow_concrete
fill 276 124 557 277 129 557 minecraft:orange_terracotta
fill 277 124 558 277 125 559 minecraft:yellow_concrete
fill 277 124 564 277 129 565 minecraft:orange_terracotta
fill 277 124 566 277 124 567 minecraft:yellow_concrete
fill 277 124 568 277 129 568 minecraft:orange_terracotta
fill 277 124 576 277 129 577 minecraft:orange_terracotta
fill 277 124 578 277 125 579 minecraft:yellow_concrete
fill 277 124 585 277 129 585 minecraft:orange_terracotta
setblock 277 124 587 minecraft:yellow_concrete
fill 277 124 588 277 129 589 minecraft:orange_terracotta
fill 277 124 590 277 125 590 minecraft:yellow_concrete
fill 277 124 596 277 129 597 minecraft:orange_terracotta
setblock 277 124 598 minecraft:yellow_concrete
setblock 235 125 558 minecraft:yellow_concrete
setblock 235 125 569 minecraft:yellow_concrete
fill 235 125 573 235 128 574 minecraft:orange_terracotta
fill 235 125 589 235 125 590 minecraft:yellow_concrete
setblock 235 125 593 minecraft:yellow_concrete
fill 235 125 594 235 128 594 minecraft:orange_terracotta
setblock 238 125 557 minecraft:yellow_concrete
fill 241 125 599 241 128 599 minecraft:orange_terracotta
fill 245 125 599 245 127 599 minecraft:orange_terracotta
setblock 246 125 599 minecraft:yellow_concrete
fill 254 125 557 255 128 557 minecraft:orange_terracotta
fill 256 125 586 257 126 587 minecraft:shroomlight
setblock 257 125 599 minecraft:yellow_concrete
setblock 259 125 557 minecraft:yellow_concrete
fill 261 125 599 262 128 599 minecraft:orange_terracotta
setblock 270 125 557 minecraft:yellow_concrete
fill 275 125 557 275 128 557 minecraft:orange_terracotta
fill 277 125 566 277 128 566 minecraft:orange_terracotta
setblock 277 125 567 minecraft:yellow_concrete
fill 277 125 570 277 125 571 minecraft:yellow_concrete
fill 277 125 587 277 128 587 minecraft:orange_terracotta
setblock 277 125 591 minecraft:yellow_concrete
fill 277 125 598 277 128 598 minecraft:orange_terracotta
fill 235 126 558 235 131 558 minecraft:orange_terracotta
fill 235 126 559 235 126 560 minecraft:yellow_concrete
fill 235 126 561 235 131 562 minecraft:orange_terracotta
fill 235 126 567 235 127 568 minecraft:yellow_concrete
fill 235 126 569 235 131 570 minecraft:orange_terracotta
setblock 235 126 571 minecraft:yellow_concrete
fill 235 126 579 235 127 580 minecraft:yellow_concrete
fill 235 126 581 235 131 582 minecraft:orange_terracotta
fill 235 126 588 235 127 588 minecraft:yellow_concrete
fill 235 126 589 235 127 590 minecraft:orange_terracotta
fill 235 126 591 235 126 592 minecraft:yellow_concrete
fill 235 126 593 235 131 593 minecraft:orange_terracotta
fill 235 126 599 236 127 599 minecraft:yellow_concrete
fill 236 126 557 237 126 557 minecraft:yellow_concrete
fill 236 126 558 238 126 558 minecraft:orange_concrete
fill 236 126 560 236 126 562 minecraft:orange_concrete
fill 236 126 564 236 126 566 minecraft:orange_concrete
fill 236 126 568 236 126 570 minecraft:orange_concrete
fill 236 126 572 236 126 574 minecraft:orange_concrete
fill 236 126 576 236 126 578 minecraft:orange_concrete
fill 236 126 580 236 126 582 minecraft:orange_concrete
fill 236 126 584 236 126 586 minecraft:orange_concrete
fill 236 126 588 236 126 590 minecraft:orange_concrete
fill 236 126 592 236 126 594 minecraft:orange_concrete
fill 236 126 596 236 126 598 minecraft:orange_concrete
fill 237 126 599 238 131 599 minecraft:orange_terracotta
fill 238 126 557 238 131 557 minecraft:orange_terracotta
fill 238 126 598 240 126 598 minecraft:orange_concrete
fill 240 126 557 240 127 557 minecraft:yellow_concrete
fill 240 126 558 242 126 558 minecraft:orange_concrete
fill 242 126 598 244 126 598 minecraft:orange_concrete
fill 244 126 558 246 126 558 minecraft:orange_concrete
fill 246 126 557 247 131 557 minecraft:orange_terracotta
fill 246 126 598 248 126 598 minecraft:orange_concrete
fill 246 126 599 246 127 599 minecraft:orange_terracotta
fill 247 126 599 248 126 599 minecraft:yellow_concrete
fill 248 126 557 249 127 557 minecraft:yellow_concrete
fill 248 126 558 250 126 558 minecraft:orange_concrete
fill 249 126 599 250 131 599 minecraft:orange_terracotta
fill 250 126 598 252 126 598 minecraft:orange_concrete
fill 252 126 558 254 126 558 minecraft:orange_concrete
fill 254 126 598 256 126 598 minecraft:orange_concrete
fill 255 126 599 256 127 599 minecraft:yellow_concrete
fill 256 126 558 258 126 558 minecraft:orange_concrete
setblock 257 126 557 minecraft:yellow_concrete
fill 257 126 599 258 131 599 minecraft:orange_terracotta
fill 258 126 557 259 131 557 minecraft:orange_terracotta
fill 258 126 598 260 126 598 minecraft:orange_concrete
setblock 259 126 599 minecraft:yellow_concrete
fill 260 126 557 261 127 557 minecraft:yellow_concrete
fill 260 126 558 262 126 558 minecraft:orange_concrete
fill 262 126 598 264 126 598 minecraft:orange_concrete
fill 264 126 558 266 126 558 minecraft:orange_concrete
fill 266 126 557 267 131 557 minecraft:orange_terracotta
fill 266 126 598 268 126 598 minecraft:orange_concrete
fill 267 126 599 268 127 599 minecraft:yellow_concrete
fill 268 126 557 269 126 557 minecraft:yellow_concrete
fill 268 126 558 270 126 558 minecraft:orange_concrete
fill 269 126 599 270 131 599 minecraft:orange_terracotta
fill 270 126 557 270 131 557 minecraft:orange_terracotta
fill 270 126 598 272 126 598 minecraft:orange_concrete
fill 272 126 558 274 126 558 minecraft:orange_concrete
fill 274 126 598 276 126 598 minecraft:orange_concrete
fill 276 126 558 276 126 560 minecraft:orange_concrete
fill 276 126 562 276 126 564 minecraft:orange_concrete
fill 276 126 566 276 126 568 minecraft:orange_concrete
fill 276 126 570 276 126 572 minecraft:orange_concrete
fill 276 126 574 276 126 576 minecraft:orange_concrete
fill 276 126 578 276 126 580 minecraft:orange_concrete
fill 276 126 582 276 126 584 minecraft:orange_concrete
fill 276 126 586 276 126 588 minecraft:orange_concrete
fill 276 126 590 276 126 592 minecraft:orange_concrete
fill 276 126 594 276 126 596 minecraft:orange_concrete
fill 276 126 599 276 127 599 minecraft:yellow_concrete
fill 277 126 558 277 131 559 minecraft:orange_terracotta
fill 277 126 560 277 127 561 minecraft:yellow_concrete
fill 277 126 567 277 131 567 minecraft:orange_terracotta
setblock 277 126 569 minecraft:yellow_concrete
fill 277 126 570 277 131 571 minecraft:orange_terracotta
fill 277 126 572 277 127 572 minecraft:yellow_concrete
fill 277 126 578 277 131 579 minecraft:orange_terracotta
fill 277 126 580 277 126 581 minecraft:yellow_concrete
fill 277 126 590 277 131 591 minecraft:orange_terracotta
fill 277 126 592 277 127 593 minecraft:yellow_concrete
setblock 235 127 559 minecraft:yellow_concrete
fill 235 127 560 235 130 560 minecraft:orange_terracotta
fill 235 127 571 235 130 571 minecraft:orange_terracotta
setblock 235 127 576 minecraft:yellow_concrete
setblock 235 127 587 minecraft:yellow_concrete
fill 235 127 591 235 129 592 minecraft:orange_terracotta
fill 236 127 557 237 130 557 minecraft:orange_terracotta
setblock 238 127 560 minecraft:light[level=14]
setblock 238 127 568 minecraft:light[level=14]
setblock 238 127 576 minecraft:light[level=14]
setblock 238 127 584 minecraft:light[level=14]
setblock 238 127 592 minecraft:light[level=14]
setblock 241 127 557 minecraft:yellow_concrete
fill 243 127 599 244 127 599 minecraft:yellow_concrete
setblock 246 127 560 minecraft:light[level=14]
setblock 246 127 568 minecraft:light[level=14]
setblock 246 127 576 minecraft:light[level=14]
setblock 246 127 584 minecraft:light[level=14]
setblock 246 127 592 minecraft:light[level=14]
setblock 247 127 599 minecraft:yellow_concrete
fill 248 127 599 248 130 599 minecraft:orange_terracotta
setblock 252 127 557 minecraft:yellow_concrete
setblock 254 127 560 minecraft:light[level=14]
setblock 254 127 568 minecraft:light[level=14]
setblock 254 127 576 minecraft:light[level=14]
setblock 254 127 584 minecraft:light[level=14]
setblock 254 127 592 minecraft:light[level=14]
fill 257 127 557 257 130 557 minecraft:orange_terracotta
fill 259 127 599 259 130 599 minecraft:orange_terracotta
setblock 262 127 560 minecraft:light[level=14]
setblock 262 127 568 minecraft:light[level=14]
setblock 262 127 576 minecraft:light[level=14]
setblock 262 127 584 minecraft:light[level=14]
setblock 262 127 592 minecraft:light[level=14]
setblock 264 127 599 minecraft:yellow_concrete
fill 268 127 557 268 130 557 minecraft:orange_terracotta
setblock 269 127 557 minecraft:yellow_concrete
setblock 270 127 560 minecraft:light[level=14]
setblock 270 127 568 minecraft:light[level=14]
setblock 270 127 576 minecraft:light[level=14]
setblock 270 127 584 minecraft:light[level=14]
setblock 270 127 592 minecraft:light[level=14]
fill 272 127 557 273 127 557 minecraft:yellow_concrete
setblock 275 127 599 minecraft:yellow_concrete
fill 277 127 569 277 130 569 minecraft:orange_terracotta
setblock 277 127 573 minecraft:yellow_concrete
fill 277 127 580 277 130 580 minecraft:orange_terracotta
setblock 277 127 581 minecraft:yellow_concrete
setblock 277 127 584 minecraft:yellow_concrete
setblock 235 128 557 minecraft:yellow_concrete
fill 235 128 559 235 133 559 minecraft:orange_terracotta
fill 235 128 565 235 129 566 minecraft:yellow_concrete
fill 235 128 567 235 133 568 minecraft:orange_terracotta
fill 235 128 576 235 133 576 minecraft:orange_terracotta
fill 235 128 577 235 128 578 minecraft:yellow_concrete
fill 235 128 579 235 130 580 minecraft:orange_terracotta
fill 235 128 585 235 129 586 minecraft:yellow_concrete
fill 235 128 587 235 133 588 minecraft:orange_terracotta
setblock 235 128 589 minecraft:yellow_concrete
fill 235 128 590 235 131 590 minecraft:orange_terracotta
fill 235 128 597 235 129 598 minecraft:yellow_concrete
fill 235 128 599 236 133 599 minecraft:orange_terracotta
setblock 239 128 557 minecraft:yellow_concrete
fill 240 128 557 241 133 557 minecraft:orange_terracotta
fill 242 128 557 243 129 557 minecraft:yellow_concrete
fill 242 128 599 242 129 599 minecraft:yellow_concrete
fill 243 128 599 244 129 599 minecraft:orange_terracotta
fill 245 128 599 246 128 599 minecraft:yellow_concrete
fill 247 128 599 247 133 599 minecraft:orange_terracotta
fill 248 128 557 249 133 557 minecraft:orange_terracotta
fill 250 128 557 251 128 557 minecraft:yellow_concrete
fill 252 128 557 252 133 557 minecraft:orange_terracotta
fill 253 128 599 254 129 599 minecraft:yellow_concrete
fill 255 128 599 256 133 599 minecraft:orange_terracotta
fill 260 128 557 261 133 557 minecraft:orange_terracotta
fill 262 128 557 263 129 557 minecraft:yellow_concrete
fill 264 128 599 264 133 599 minecraft:orange_terracotta
fill 265 128 599 266 128 599 minecraft:yellow_concrete
fill 267 128 599 268 133 599 minecraft:orange_terracotta
fill 269 128 557 269 133 557 minecraft:orange_terracotta
setblock 271 128 557 minecraft:yellow_concrete
fill 272 128 557 273 133 557 minecraft:orange_terracotta
fill 273 128 599 274 129 599 minecraft:yellow_concrete
fill 274 128 557 274 129 557 minecraft:yellow_concrete
fill 275 128 599 276 133 599 minecraft:orange_terracotta
fill 277 128 560 277 133 561 minecraft:orange_terracotta
fill 277 128 562 277 128 563 minecraft:yellow_concrete
fill 277 128 572 277 133 573 minecraft:orange_terracotta
fill 277 128 574 277 129 575 minecraft:yellow_concrete
fill 277 128 581 277 133 581 minecraft:orange_terracotta
fill 277 128 582 277 128 583 minecraft:yellow_concrete
fill 277 128 584 277 133 584 minecraft:orange_terracotta
fill 277 128 586 277 129 586 minecraft:yellow_concrete
fill 277 128 592 277 133 593 minecraft:orange_terracotta
fill 277 128 594 277 129 595 minecraft:yellow_concrete
setblock 277 128 599 minecraft:yellow_concrete
fill 235 129 557 235 132 557 minecraft:orange_terracotta
fill 235 129 573 235 129 574 minecraft:yellow_concrete
setblock 235 129 577 minecraft:yellow_concrete
fill 235 129 578 235 132 578 minecraft:orange_terracotta
fill 235 129 589 235 131 589 minecraft:orange_terracotta
setblock 235 129 594 minecraft:yellow_concrete
fill 239 129 557 239 132 557 minecraft:orange_terracotta
setblock 241 129 599 minecraft:yellow_concrete
fill 245 129 599 246 131 599 minecraft:orange_terracotta
fill 250 129 557 250 132 557 minecraft:orange_terracotta
setblock 251 129 557 minecraft:yellow_concrete
fill 254 129 557 255 129 557 minecraft:yellow_concrete
fill 261 129 599 262 129 599 minecraft:yellow_concrete
setblock 265 129 599 minecraft:yellow_concrete
fill 266 129 599 266 132 599 minecraft:orange_terracotta
fill 271 129 557 271 132 557 minecraft:orange_terracotta
setblock 275 129 557 minecraft:yellow_concrete
fill 277 129 562 277 132 562 minecraft:orange_terracotta
setblock 277 129 563 minecraft:yellow_concrete
setblock 277 129 566 minecraft:yellow_concrete
fill 277 129 582 277 132 583 minecraft:orange_terracotta
setblock 277 129 587 minecraft:yellow_concrete
setblock 277 129 598 minecraft:yellow_concrete
fill 277 129 599 277 132 599 minecraft:orange_terracotta
fill 235 130 563 235 130 564 minecraft:yellow_concrete
fill 235 130 565 235 135 566 minecraft:orange_terracotta
fill 235 130 572 235 131 572 minecraft:yellow_concrete
fill 235 130 573 235 135 574 minecraft:orange_terracotta
setblock 235 130 575 minecraft:yellow_concrete
fill 235 130 577 235 132 577 minecraft:orange_terracotta
fill 235 130 583 235 131 584 minecraft:yellow_concrete
fill 235 130 585 235 135 586 minecraft:orange_terracotta
setblock 235 130 591 minecraft:orange_terracotta
fill 235 130 592 235 131 592 minecraft:yellow_concrete
fill 235 130 594 235 135 594 minecraft:orange_terracotta
fill 235 130 595 235 130 596 minecraft:yellow_concrete
fill 235 130 597 235 132 598 minecraft:orange_terracotta
fill 239 130 599 240 131 599 minecraft:yellow_concrete
fill 241 130 599 242 135 599 minecraft:orange_terracotta
fill 242 130 557 243 135 557 minecraft:orange_terracotta
setblock 243 130 599 minecraft:yellow_concrete
fill 244 130 557 245 131 557 minecraft:yellow_concrete
fill 244 130 599 244 133 599 minecraft:orange_terracotta
fill 251 130 557 251 135 557 minecraft:orange_terracotta
fill 251 130 599 252 130 599 minecraft:yellow_concrete
setblock 253 130 557 minecraft:yellow_concrete
fill 253 130 599 254 135 599 minecraft:orange_terracotta
fill 254 130 557 255 135 557 minecraft:orange_terracotta
fill 256 130 557 256 131 557 minecraft:yellow_concrete
fill 260 130 599 260 131 599 minecraft:yellow_concrete
fill 261 130 599 262 135 599 minecraft:orange_terracotta
fill 262 130 557 263 135 557 minecraft:orange_terracotta
setblock 263 130 599 minecraft:yellow_concrete
fill 264 130 557 265 130 557 minecraft:yellow_concrete
fill 265 130 599 265 135 599 minecraft:orange_terracotta
fill 271 130 599 272 131 599 minecraft:yellow_concrete
fill 273 130 599 274 135 599 minecraft:orange_terracotta
fill 274 130 557 275 135 557 minecraft:orange_terracotta
fill 276 130 557 277 131 557 minecraft:yellow_concrete
fill 277 130 563 277 135 563 minecraft:orange_terracotta
fill 277 130 564 277 130 565 minecraft:yellow_concrete
fill 277 130 566 277 135 566 minecraft:orange_terracotta
fill 277 130 568 277 131 568 minecraft:yellow_concrete
fill 277 130 574 277 135 575 minecraft:orange_terracotta
fill 277 130 576 277 131 577 minecraft:yellow_concrete
setblock 277 130 585 minecraft:yellow_concrete
fill 277 130 586 277 135 587 minecraft:orange_terracotta
fill 277 130 588 277 131 589 minecraft:yellow_concrete
fill 277 130 594 277 135 595 minecraft:orange_terracotta
fill 277 130 596 277 130 597 minecraft:yellow_concrete
fill 277 130 598 277 135 598 minecraft:orange_terracotta
setblock 235 131 560 minecraft:yellow_concrete
setblock 235 131 563 minecraft:yellow_concrete
fill 235 131 564 235 134 564 minecraft:orange_terracotta
setblock 235 131 571 minecraft:yellow_concrete
fill 235 131 575 235 134 575 minecraft:orange_terracotta
fill 235 131 579 235 133 579 minecraft:orange_terracotta
setblock 235 131 580 minecraft:yellow_concrete
setblock 235 131 591 minecraft:yellow_concrete
setblock 235 131 595 minecraft:yellow_concrete
fill 235 131 596 235 134 596 minecraft:orange_terracotta
fill 236 131 557 237 131 557 minecraft:yellow_concrete
fill 243 131 599 243 133 599 minecraft:orange_terracotta
setblock 248 131 599 minecraft:yellow_concrete
setblock 251 131 599 minecraft:yellow_concrete
fill 252 131 599 252 134 599 minecraft:orange_terracotta
fill 253 131 557 253 134 557 minecraft:orange_terracotta
setblock 257 131 557 minecraft:yellow_concrete
setblock 259 131 599 minecraft:yellow_concrete
fill 263 131 599 263 134 599 minecraft:orange_terracotta
fill 264 131 557 264 134 557 minecraft:orange_terracotta
setblock 265 131 557 minecraft:yellow_concrete
setblock 268 131 557 minecraft:yellow_concrete
fill 277 131 564 277 134 565 minecraft:orange_terracotta
setblock 277 131 569 minecraft:yellow_concrete
setblock 277 131 580 minecraft:yellow_concrete
fill 277 131 585 277 134 585 minecraft:orange_terracotta
fill 277 131 596 277 134 596 minecraft:orange_terracotta
setblock 277 131 597 minecraft:yellow_concrete
fill 235 132 558 235 133 558 minecraft:yellow_concrete
fill 235 132 560 235 137 560 minecraft:orange_terracotta
fill 235 132 561 235 132 562 minecraft:yellow_concrete
fill 235 132 563 235 137 563 minecraft:orange_terracotta
fill 235 132 569 235 133 570 minecraft:yellow_concrete
fill 235 132 571 235 137 572 minecraft:orange_terracotta
fill 235 132 580 235 133 580 minecraft:orange_terracotta
fill 235 132 581 235 132 582 minecraft:yellow_concrete
fill 235 132 583 235 137 584 minecraft:orange_terracotta
fill 235 132 589 235 133 590 minecraft:yellow_concrete
fill 235 132 591 235 137 592 minecraft:orange_terracotta
setblock 235 132 593 minecraft:yellow_concrete
fill 235 132 595 235 134 595 minecraft:orange_terracotta
fill 236 132 557 237 137 557 minecraft:orange_terracotta
fill 236 132 558 238 132 558 minecraft:orange_concrete
fill 236 132 560 236 132 562 minecraft:orange_concrete
fill 236 132 564 236 132 566 minecraft:orange_concrete
fill 236 132 568 236 132 570 minecraft:orange_concrete
fill 236 132 572 236 132 574 minecraft:orange_concrete
fill 236 132 576 236 132 578 minecraft:orange_concrete
fill 236 132 580 236 132 582 minecraft:orange_concrete
fill 236 132 584 236 132 586 minecraft:orange_concrete
fill 236 132 588 236 132 590 minecraft:orange_concrete
fill 236 132 592 236 132 594 minecraft:orange_concrete
fill 236 132 596 236 132 598 minecraft:orange_concrete
fill 237 132 599 238 133 599 minecraft:yellow_concrete
fill 238 132 557 238 133 557 minecraft:yellow_concrete
fill 238 132 598 240 132 598 minecraft:orange_concrete
fill 239 132 599 240 137 599 minecraft:orange_terracotta
fill 240 132 558 242 132 558 minecraft:orange_concrete
fill 242 132 598 244 132 598 minecraft:orange_concrete
fill 244 132 557 245 137 557 minecraft:orange_terracotta
fill 244 132 558 246 132 558 minecraft:orange_concrete
setblock 245 132 599 minecraft:orange_terracotta
fill 246 132 557 247 132 557 minecraft:yellow_concrete
fill 246 132 598 248 132 598 minecraft:orange_concrete
fill 246 132 599 246 133 599 minecraft:yellow_concrete
fill 248 132 558 250 132 558 minecraft:orange_concrete
fill 248 132 599 248 137 599 minecraft:orange_terracotta
fill 249 132 599 250 132 599 minecraft:yellow_concrete
fill 250 132 598 252 132 598 minecraft:orange_concrete
fill 251 132 599 251 137 599 minecraft:orange_terracotta
fill 252 132 558 254 132 558 minecraft:orange_concrete
fill 254 132 598 256 132 598 minecraft:orange_concrete
fill 256 132 557 257 137 557 minecraft:orange_terracotta
fill 256 132 558 258 132 558 minecraft:orange_concrete
fill 257 132 599 258 133 599 minecraft:yellow_concrete
fill 258 132 557 259 133 557 minecraft:yellow_concrete
fill 258 132 598 260 132 598 minecraft:orange_concrete
fill 259 132 599 260 137 599 minecraft:orange_terracotta
fill 260 132 558 262 132 558 minecraft:orange_concrete
fill 262 132 598 264 132 598 minecraft:orange_concrete
fill 264 132 558 266 132 558 minecraft:orange_concrete
fill 265 132 557 265 137 557 minecraft:orange_terracotta
fill 266 132 557 267 132 557 minecraft:yellow_concrete
fill 266 132 598 268 132 598 minecraft:orange_concrete
fill 268 132 557 268 137 557 minecraft:orange_terracotta
fill 268 132 558 270 132 558 minecraft:orange_concrete
fill 269 132 599 270 132 599 minecraft:yellow_concrete
fill 270 132 557 270 133 557 minecraft:yellow_concrete
fill 270 132 598 272 132 598 minecraft:orange_concrete
fill 271 132 599 272 137 599 minecraft:orange_terracotta
fill 272 132 558 274 132 558 minecraft:orange_concrete
fill 274 132 598 276 132 598 minecraft:orange_concrete
fill 276 132 557 277 137 557 minecraft:orange_terracotta
fill 276 132 558 276 132 560 minecraft:orange_concrete
fill 276 132 562 276 132 564 minecraft:orange_concrete
fill 276 132 566 276 132 568 minecraft:orange_concrete
fill 276 132 570 276 132 572 minecraft:orange_concrete
fill 276 132 574 276 132 576 minecraft:orange_concrete
fill 276 132 578 276 132 580 minecraft:orange_concrete
fill 276 132 582 276 132 584 minecraft:orange_concrete
fill 276 132 586 276 132 588 minecraft:orange_concrete
fill 276 132 590 276 132 592 minecraft:orange_concrete
fill 276 132 594 276 132 596 minecraft:orange_concrete
fill 277 132 558 277 133 559 minecraft:yellow_concrete
setblock 277 132 567 minecraft:yellow_concrete
fill 277 132 568 277 137 569 minecraft:orange_terracotta
fill 277 132 570 277 133 571 minecraft:yellow_concrete
fill 277 132 576 277 137 577 minecraft:orange_terracotta
fill 277 132 578 277 132 579 minecraft:yellow_concrete
fill 277 132 580 277 137 580 minecraft:orange_terracotta
fill 277 132 588 277 137 589 minecraft:orange_terracotta
fill 277 132 590 277 133 591 minecraft:yellow_concrete
fill 277 132 597 277 137 597 minecraft:orange_terracotta
setblock 235 133 557 minecraft:yellow_concrete
fill 235 133 561 235 136 562 minecraft:orange_terracotta
fill 235 133 577 235 133 578 minecraft:yellow_concrete
setblock 235 133 581 minecraft:yellow_concrete
fill 235 133 582 235 136 582 minecraft:orange_terracotta
fill 235 133 593 235 136 593 minecraft:orange_terracotta
fill 235 133 597 235 135 597 minecraft:orange_terracotta
setblock 235 133 598 minecraft:yellow_concrete
setblock 239 133 557 minecraft:yellow_concrete
setblock 245 133 599 minecraft:yellow_concrete
fill 246 133 557 246 136 557 minecraft:orange_terracotta
setblock 247 133 557 minecraft:yellow_concrete
fill 249 133 599 250 136 599 minecraft:orange_terracotta
setblock 250 133 557 minecraft:yellow_concrete
fill 266 133 557 267 136 557 minecraft:orange_terracotta
setblock 266 133 599 minecraft:yellow_concrete
setblock 269 133 599 minecraft:yellow_concrete
fill 270 133 599 270 136 599 minecraft:orange_terracotta
setblock 271 133 557 minecraft:yellow_concrete
setblock 277 133 562 minecraft:yellow_concrete
fill 277 133 567 277 136 567 minecraft:orange_terracotta
fill 277 133 578 277 136 578 minecraft:orange_terracotta
setblock 277 133 579 minecraft:yellow_concrete
fill 277 133 582 277 133 583 minecraft:yellow_concrete
setblock 277 133 599 minecraft:yellow_concrete
fill 235 134 557 235 139 558 minecraft:orange_terracotta
setblock 235 134 559 minecraft:yellow_concrete
fill 235 134 567 235 135 568 minecraft:yellow_concrete
fill 235 134 569 235 139 570 minecraft:orange_terracotta
fill 235 134 576 235 135 576 minecraft:yellow_concrete
fill 235 134 577 235 135 578 minecraft:orange_terracotta
fill 235 134 579 235 134 580 minecraft:yellow_concrete
fill 235 134 581 235 139 581 minecraft:orange_terracotta
fill 235 134 587 235 135 588 minecraft:yellow_concrete
fill 235 134 589 235 139 590 minecraft:orange_terracotta
fill 235 134 598 235 135 598 minecraft:orange_terracotta
fill 235 134 599 236 134 599 minecraft:yellow_concrete
fill 237 134 599 238 139 599 minecraft:orange_terracotta
fill 238 134 557 239 139 557 minecraft:orange_terracotta
fill 240 134 557 241 135 557 minecraft:yellow_concrete
fill 243 134 599 244 135 599 minecraft:yellow_concrete
fill 245 134 599 246 139 599 minecraft:orange_terracotta
fill 247 134 557 247 139 557 minecraft:orange_terracotta
setblock 247 134 599 minecraft:yellow_concrete
fill 248 134 557 249 134 557 minecraft:yellow_concrete
fill 250 134 557 250 139 557 minecraft:orange_terracotta
fill 252 134 557 252 135 557 minecraft:yellow_concrete
fill 255 134 599 256 135 599 minecraft:yellow_concrete
fill 257 134 599 258 139 599 minecraft:orange_terracotta
fill 258 134 557 259 139 557 minecraft:orange_terracotta
fill 260 134 557 261 135 557 minecraft:yellow_concrete
fill 264 134 599 264 135 599 minecraft:yellow_concrete
fill 266 134 599 266 139 599 minecraft:orange_terracotta
fill 267 134 599 268 134 599 minecraft:yellow_concrete
setblock 269 134 557 minecraft:yellow_concrete
fill 269 134 599 269 139 599 minecraft:orange_terracotta
fill 270 134 557 271 139 557 minecraft:orange_terracotta
fill 272 134 557 273 135 557 minecraft:yellow_concrete
fill 275 134 599 276 135 599 minecraft:yellow_concrete
fill 277 134 558 277 139 559 minecraft:orange_terracotta
fill 277 134 560 277 134 561 minecraft:yellow_concrete
fill 277 134 562 277 139 562 minecraft:orange_terracotta
fill 277 134 570 277 139 571 minecraft:orange_terracotta
fill 277 134 572 277 135 573 minecraft:yellow_concrete
fill 277 134 579 277 139 579 minecraft:orange_terracotta
setblock 277 134 581 minecraft:yellow_concrete
fill 277 134 582 277 139 583 minecraft:orange_terracotta
fill 277 134 584 277 135 584 minecraft:yellow_concrete
fill 277 134 590 277 139 591 minecraft:orange_terracotta
fill 277 134 592 277 134 593 minecraft:yellow_concrete
fill 277 134 599 277 139 599 minecraft:orange_terracotta
fill 235 135 559 235 138 559 minecraft:orange_terracotta
setblock 235 135 564 minecraft:yellow_concrete
setblock 235 135 575 minecraft:yellow_concrete
fill 235 135 579 235 137 580 minecraft:orange_terracotta
fill 235 135 595 235 135 596 minecraft:yellow_concrete
setblock 235 135 599 minecraft:yellow_concrete
fill 236 135 599 236 138 599 minecraft:orange_terracotta
setblock 238 135 560 minecraft:light[level=14]
setblock 238 135 568 minecraft:light[level=14]
setblock 238 135 576 minecraft:light[level=14]
setblock 238 135 584 minecraft:light[level=14]
setblock 238 135 592 minecraft:light[level=14]
setblock 246 135 560 minecraft:light[level=14]
setblock 246 135 568 minecraft:light[level=14]
setblock 246 135 576 minecraft:light[level=14]
setblock 246 135 584 minecraft:light[level=14]
setblock 246 135 592 minecraft:light[level=14]
fill 247 135 599 247 138 599 minecraft:orange_terracotta
fill 248 135 557 249 138 557 minecraft:orange_terracotta
setblock 252 135 599 minecraft:yellow_concrete
setblock 253 135 557 minecraft:yellow_concrete
setblock 254 135 560 minecraft:light[level=14]
setblock 254 135 568 minecraft:light[level=14]
setblock 254 135 576 minecraft:light[level=14]
setblock 254 135 584 minecraft:light[level=14]
setblock 254 135 592 minecraft:light[level=14]
setblock 262 135 560 minecraft:light[level=14]
setblock 262 135 568 minecraft:light[level=14]
setblock 262 135 576 minecraft:light[level=14]
setblock 262 135 584 minecraft:light[level=14]
setblock 262 135 592 minecraft:light[level=14]
setblock 263 135 599 minecraft:yellow_concrete
setblock 264 135 557 minecraft:yellow_concrete
fill 267 135 599 268 138 599 minecraft:orange_terracotta
fill 269 135 557 269 138 557 minecraft:orange_terracotta
setblock 270 135 560 minecraft:light[level=14]
setblock 270 135 568 minecraft:light[level=14]
setblock 270 135 576 minecraft:light[level=14]
setblock 270 135 584 minecraft:light[level=14]
setblock 270 135 592 minecraft:light[level=14]
fill 277 135 560 277 138 560 minecraft:orange_terracotta
setblock 277 135 561 minecraft:yellow_concrete
fill 277 135 564 277 135 565 minecraft:yellow_concrete
fill 277 135 581 277 138 581 minecraft:orange_terracotta
setblock 277 135 585 minecraft:yellow_concrete
fill 277 135 592 277 138 592 minecraft:orange_terracotta
setblock 277 135 593 minecraft:yellow_concrete
setblock 277 135 596 minecraft:yellow_concrete
fill 235 136 564 235 141 564 minecraft:orange_terracotta
fill 235 136 565 235 136 566 minecraft:yellow_concrete
fill 235 136 567 235 138 568 minecraft:orange_terracotta
fill 235 136 573 235 137 574 minecraft:yellow_concrete
fill 235 136 575 235 141 576 minecraft:orange_terracotta
setblock 235 136 577 minecraft:yellow_concrete
fill 235 136 578 235 139 578 minecraft:orange_terracotta
fill 235 136 585 235 137 586 minecraft:yellow_concrete
fill 235 136 587 235 141 588 minecraft:orange_terracotta
fill 235 136 594 235 137 594 minecraft:yellow_concrete
fill 235 136 595 235 137 596 minecraft:orange_terracotta
fill 235 136 597 235 136 598 minecraft:yellow_concrete
fill 235 136 599 235 141 599 minecraft:orange_terracotta
fill 240 136 557 241 141 557 minecraft:orange_terracotta
fill 241 136 599 242 137 599 minecraft:yellow_concrete
fill 242 136 557 243 137 557 minecraft:yellow_concrete
fill 243 136 599 244 141 599 minecraft:orange_terracotta
setblock 251 136 557 minecraft:yellow_concrete
fill 252 136 557 253 141 557 minecraft:orange_terracotta
fill 252 136 599 252 141 599 minecraft:orange_terracotta
fill 253 136 599 254 136 599 minecraft:yellow_concrete
fill 254 136 557 255 137 557 minecraft:yellow_concrete
fill 255 136 599 256 141 599 minecraft:orange_terracotta
fill 260 136 557 261 141 557 minecraft:orange_terracotta
fill 261 136 599 262 137 599 minecraft:yellow_concrete
fill 262 136 557 263 136 557 minecraft:yellow_concrete
fill 263 136 599 264 141 599 minecraft:orange_terracotta
fill 264 136 557 264 141 557 minecraft:orange_terracotta
setblock 265 136 599 minecraft:yellow_concrete
fill 272 136 557 273 141 557 minecraft:orange_terracotta
fill 273 136 599 274 137 599 minecraft:yellow_concrete
fill 274 136 557 275 137 557 minecraft:yellow_concrete
fill 275 136 599 276 141 599 minecraft:orange_terracotta
fill 277 136 561 277 141 561 minecraft:orange_terracotta
setblock 277 136 563 minecraft:yellow_concrete
fill 277 136 564 277 141 565 minecraft:orange_terracotta
fill 277 136 566 277 137 566 minecraft:yellow_concrete
fill 277 136 572 277 141 573 minecraft:orange_terracotta
fill 277 136 574 277 136 575 minecraft:yellow_concrete
fill 277 136 584 277 141 585 minecraft:orange_terracotta
fill 277 136 586 277 137 587 minecraft:yellow_concrete
fill 277 136 593 277 141 593 minecraft:orange_terracotta
fill 277 136 594 277 136 595 minecraft:yellow_concrete
fill 277 136 596 277 141 596 minecraft:orange_terracotta
fill 277 136 598 277 137 598 minecraft:yellow_concrete
fill 235 137 561 235 137 562 minecraft:yellow_concrete
setblock 235 137 565 minecraft:yellow_concrete
fill 235 137 566 235 140 566 minecraft:orange_terracotta
fill 235 137 577 235 139 577 minecraft:orange_terracotta
setblock 235 137 582 minecraft:yellow_concrete
setblock 235 137 593 minecraft:yellow_concrete
fill 235 137 597 235 139 598 minecraft:orange_terracotta
fill 245 137 589 246 138 590 minecraft:red_concrete
setblock 246 137 557 minecraft:yellow_concrete
fill 249 137 599 250 137 599 minecraft:yellow_concrete
fill 251 137 557 251 140 557 minecraft:orange_terracotta
setblock 253 137 599 minecraft:yellow_concrete
fill 254 137 599 254 140 599 minecraft:orange_terracotta
fill 262 137 557 262 140 557 minecraft:orange_terracotta
setblock 263 137 557 minecraft:yellow_concrete
fill 265 137 599 265 140 599 minecraft:orange_terracotta
fill 266 137 557 267 137 557 minecraft:yellow_concrete
setblock 270 137 599 minecraft:yellow_concrete
fill 277 137 563 277 140 563 minecraft:orange_terracotta
setblock 277 137 567 minecraft:yellow_concrete
fill 277 137 574 277 140 574 minecraft:orange_terracotta
setblock 277 137 575 minecraft:yellow_concrete
setblock 277 137 578 minecraft:yellow_concrete
fill 277 137 594 277 140 595 minecraft:orange_terracotta
fill 235 138 560 235 139 560 minecraft:yellow_concrete
fill 235 138 561 235 143 562 minecraft:orange_terracotta
setblock 235 138 563 minecraft:yellow_concrete
fill 235 138 565 235 140 565 minecraft:orange_terracotta
fill 235 138 571 235 139 572 minecraft:yellow_concrete
fill 235 138 573 235 143 574 minecraft:orange_terracotta
setblock 235 138 579 minecraft:orange_terracotta
fill 235 138 580 235 139 580 minecraft:yellow_concrete
fill 235 138 582 235 143 582 minecraft:orange_terracotta
fill 235 138 583 235 138 584 minecraft:yellow_concrete
fill 235 138 585 235 140 586 minecraft:orange_terracotta
fill 235 138 591 235 139 592 minecraft:yellow_concrete
fill 235 138 593 235 143 594 minecraft:orange_terracotta
setblock 235 138 595 minecraft:yellow_concrete
fill 235 138 596 235 141 596 minecraft:orange_terracotta
fill 236 138 557 237 139 557 minecraft:yellow_concrete
fill 236 138 558 238 138 558 minecraft:orange_concrete
fill 236 138 560 236 138 562 minecraft:orange_concrete
fill 236 138 564 236 138 566 minecraft:orange_concrete
fill 236 138 568 236 138 570 minecraft:orange_concrete
fill 236 138 572 236 138 574 minecraft:orange_concrete
fill 236 138 576 236 138 578 minecraft:orange_concrete
fill 236 138 580 236 138 582 minecraft:orange_concrete
fill 236 138 584 236 138 586 minecraft:orange_concrete
fill 236 138 588 236 138 590 minecraft:orange_concrete
fill 236 138 592 236 138 594 minecraft:orange_concrete
fill 236 138 596 236 138 598 minecraft:orange_concrete
fill 238 138 598 240 138 598 minecraft:orange_concrete
fill 239 138 599 240 138 599 minecraft:yellow_concrete
fill 240 138 558 242 138 558 minecraft:orange_concrete
fill 241 138 599 242 143 599 minecraft:orange_terracotta
fill 242 138 557 243 143 557 minecraft:orange_terracotta
fill 242 138 598 244 138 598 minecraft:orange_concrete
fill 244 138 557 245 138 557 minecraft:yellow_concrete
fill 244 138 558 246 138 558 minecraft:orange_concrete
fill 246 138 557 246 143 557 minecraft:orange_terracotta
fill 246 138 598 248 138 598 minecraft:orange_concrete
fill 248 138 558 250 138 558 minecraft:orange_concrete
fill 248 138 599 248 139 599 minecraft:yellow_concrete
fill 249 138 599 250 143 599 minecraft:orange_terracotta
fill 250 138 598 252 138 598 minecraft:orange_concrete
setblock 251 138 599 minecraft:yellow_concrete
fill 252 138 558 254 138 558 minecraft:orange_concrete
fill 253 138 599 253 143 599 minecraft:orange_terracotta
fill 254 138 557 255 143 557 minecraft:orange_terracotta
fill 254 138 598 256 138 598 minecraft:orange_concrete
fill 256 138 557 257 139 557 minecraft:yellow_concrete
fill 256 138 558 258 138 558 minecraft:orange_concrete
fill 258 138 598 260 138 598 minecraft:orange_concrete
fill 259 138 599 260 139 599 minecraft:yellow_concrete
fill 260 138 558 262 138 558 minecraft:orange_concrete
fill 261 138 599 262 143 599 minecraft:orange_terracotta
fill 262 138 598 264 138 598 minecraft:orange_concrete
fill 263 138 557 263 143 557 minecraft:orange_terracotta
fill 264 138 558 266 138 558 minecraft:orange_concrete
setblock 265 138 557 minecraft:yellow_concrete
fill 266 138 557 267 143 557 minecraft:orange_terracotta
fill 266 138 598 268 138 598 minecraft:orange_concrete
fill 268 138 557 268 139 557 minecraft:yellow_concrete
fill 268 138 558 270 138 558 minecraft:orange_concrete
fill 270 138 598 272 138 598 minecraft:orange_concrete
fill 270 138 599 270 143 599 minecraft:orange_terracotta
fill 271 138 599 272 138 599 minecraft:yellow_concrete
fill 272 138 558 274 138 558 minecraft:orange_concrete
fill 273 138 599 274 143 599 minecraft:orange_terracotta
fill 274 138 557 275 143 557 minecraft:orange_terracotta
fill 274 138 598 276 138 598 minecraft:orange_concrete
fill 276 138 557 277 138 557 minecraft:yellow_concrete
fill 276 138 558 276 138 560 minecraft:orange_concrete
fill 276 138 562 276 138 564 minecraft:orange_concrete
fill 276 138 566 276 138 568 minecraft:orange_concrete
fill 276 138 570 276 138 572 minecraft:orange_concrete
fill 276 138 574 276 138 576 minecraft:orange_concrete
fill 276 138 578 276 138 580 minecraft:orange_concrete
fill 276 138 582 276 138 584 minecraft:orange_concrete
fill 276 138 586 276 138 588 minecraft:orange_concrete
fill 276 138 590 276 138 592 minecraft:orange_concrete
fill 276 138 594 276 138 596 minecraft:orange_concrete
fill 277 138 566 277 143 567 minecraft:orange_terracotta
fill 277 138 568 277 139 569 minecraft:yellow_concrete
fill 277 138 575 277 143 575 minecraft:orange_terracotta
fill 277 138 576 277 138 577 minecraft:yellow_concrete
fill 277 138 578 277 143 578 minecraft:orange_terracotta
fill 277 138 580 277 139 580 minecraft:yellow_concrete
fill 277 138 586 277 143 587 minecraft:orange_terracotta
fill 277 138 588 277 139 589 minecraft:yellow_concrete
setblock 277 138 597 minecraft:yellow_concrete
fill 277 138 598 277 143 598 minecraft:orange_terracotta
setblock 235 139 559 minecraft:yellow_concrete
fill 235 139 563 235 142 563 minecraft:orange_terracotta
fill 235 139 567 235 141 567 minecraft:orange_terracotta
setblock 235 139 568 minecraft:yellow_concrete
setblock 235 139 579 minecraft:yellow_concrete
setblock 235 139 583 minecraft:yellow_concrete
fill 235 139 584 235 142 584 minecraft:orange_terracotta
fill 235 139 595 235 141 595 minecraft:orange_terracotta
setblock 236 139 599 minecraft:yellow_concrete
setblock 239 139 599 minecraft:yellow_concrete
fill 240 139 599 240 142 599 minecraft:orange_terracotta
fill 244 139 557 244 142 557 minecraft:orange_terracotta
setblock 245 139 557 minecraft:yellow_concrete
setblock 247 139 599 minecraft:yellow_concrete
fill 248 139 557 249 139 557 minecraft:yellow_concrete
fill 251 139 599 251 142 599 minecraft:orange_terracotta
fill 265 139 557 265 142 557 minecraft:orange_terracotta
fill 267 139 599 268 139 599 minecraft:yellow_concrete
setblock 269 139 557 minecraft:yellow_concrete
setblock 271 139 599 minecraft:yellow_concrete
fill 272 139 599 272 142 599 minecraft:orange_terracotta
fill 276 139 557 276 142 557 minecraft:orange_terracotta
setblock 277 139 557 minecraft:yellow_concrete
setblock 277 139 560 minecraft:yellow_concrete
fill 277 139 576 277 142 577 minecraft:orange_terracotta
setblock 277 139 581 minecraft:yellow_concrete
setblock 277 139 592 minecraft:yellow_concrete
fill 277 139 597 277 142 597 minecraft:orange_terracotta
fill 235 140 557 235 141 558 minecraft:yellow_concrete
fill 235 140 559 235 145 560 minecraft:orange_terracotta
fill 235 140 568 235 141 568 minecraft:orange_terracotta
fill 235 140 569 235 140 570 minecraft:yellow_concrete
fill 235 140 571 235 145 572 minecraft:orange_terracotta
fill 235 140 577 235 141 578 minecraft:yellow_concrete
fill 235 140 579 235 145 580 minecraft:orange_terracotta
setblock 235 140 581 minecraft:yellow_concrete
fill 235 140 583 235 142 583 minecraft:orange_terracotta
fill 235 140 589 235 141 590 minecraft:yellow_concrete
fill 235 140 591 235 145 592 minecraft:orange_terracotta
setblock 235 140 597 minecraft:orange_terracotta
fill 235 140 598 235 141 598 minecraft:yellow_concrete
fill 236 140 557 237 145 557 minecraft:orange_terracotta
fill 236 140 599 236 145 599 minecraft:orange_terracotta
fill 237 140 599 238 140 599 minecraft:yellow_concrete
fill 238 140 557 239 141 557 minecraft:yellow_concrete
fill 239 140 599 239 145 599 minecraft:orange_terracotta
fill 245 140 557 245 145 557 minecraft:orange_terracotta
fill 245 140 599 246 141 599 minecraft:yellow_concrete
setblock 247 140 557 minecraft:yellow_concrete
fill 247 140 599 248 145 599 minecraft:orange_terracotta
fill 248 140 557 249 145 557 minecraft:orange_terracotta
fill 250 140 557 250 141 557 minecraft:yellow_concrete
fill 256 140 557 257 145 557 minecraft:orange_terracotta
fill 257 140 599 258 140 599 minecraft:yellow_concrete
fill 258 140 557 259 140 557 minecraft:yellow_concrete
fill 259 140 599 260 145 599 minecraft:orange_terracotta
fill 266 140 599 266 141 599 minecraft:yellow_concrete
fill 267 140 599 268 145 599 minecraft:orange_terracotta
fill 268 140 557 269 145 557 minecraft:orange_terracotta
setblock 269 140 599 minecraft:yellow_concrete
fill 270 140 557 271 141 557 minecraft:yellow_concrete
fill 271 140 599 271 145 599 minecraft:orange_terracotta
fill 277 140 557 277 145 557 minecraft:orange_terracotta
fill 277 140 558 277 140 559 minecraft:yellow_concrete
fill 277 140 560 277 145 560 minecraft:orange_terracotta
fill 277 140 562 277 141 562 minecraft:yellow_concrete
fill 277 140 568 277 145 569 minecraft:orange_terracotta
fill 277 140 570 277 141 571 minecraft:yellow_concrete
setblock 277 140 579 minecraft:yellow_concrete
fill 277 140 580 277 145 581 minecraft:orange_terracotta
fill 277 140 582 277 141 583 minecraft:yellow_concrete
fill 277 140 588 277 145 589 minecraft:orange_terracotta
fill 277 140 590 277 140 591 minecraft:yellow_concrete
fill 277 140 592 277 145 592 minecraft:orange_terracotta
fill 277 140 599 277 141 599 minecraft:yellow_concrete
fill 235 141 565 235 141 566 minecraft:yellow_concrete
setblock 235 141 569 minecraft:yellow_concrete
fill 235 141 570 235 144 570 minecraft:orange_terracotta
fill 235 141 581 235 144 581 minecraft:orange_terracotta
fill 235 141 585 235 143 585 minecraft:orange_terracotta
setblock 235 141 586 minecraft:yellow_concrete
setblock 235 141 597 minecraft:yellow_concrete
fill 237 141 599 238 144 599 minecraft:orange_terracotta
fill 247 141 557 247 144 557 minecraft:orange_terracotta
setblock 251 141 557 minecraft:yellow_concrete
setblock 254 141 599 minecraft:yellow_concrete
setblock 257 141 599 minecraft:yellow_concrete
fill 258 141 557 258 144 557 minecraft:orange_terracotta
fill 258 141 599 258 144 599 minecraft:orange_terracotta
setblock 259 141 557 minecraft:yellow_concrete
setblock 262 141 557 minecraft:yellow_concrete
setblock 265 141 599 minecraft:yellow_concrete
fill 268 141 588 269 142 589 minecraft:orange_concrete
fill 269 141 599 269 144 599 minecraft:orange_terracotta
fill 277 141 558 277 144 559 minecraft:orange_terracotta
setblock 277 141 563 minecraft:yellow_concrete
setblock 277 141 574 minecraft:yellow_concrete
fill 277 141 579 277 144 579 minecraft:orange_terracotta
fill 277 141 590 277 144 590 minecraft:orange_terracotta
setblock 277 141 591 minecraft:yellow_concrete
fill 277 141 594 277 141 595 minecraft:yellow_concrete
fill 235 142 557 235 147 558 minecraft:orange_terracotta
fill 235 142 564 235 143 564 minecraft:yellow_concrete
fill 235 142 565 235 143 566 minecraft:orange_terracotta
fill 235 142 567 235 142 568 minecraft:yellow_concrete
fill 235 142 569 235 147 569 minecraft:orange_terracotta
fill 235 142 575 235 143 576 minecraft:yellow_concrete
fill 235 142 577 235 147 578 minecraft:orange_terracotta
fill 235 142 586 235 143 586 minecraft:orange_terracotta
fill 235 142 587 235 142 588 minecraft:yellow_concrete
fill 235 142 589 235 147 590 minecraft:orange_terracotta
fill 235 142 595 235 143 596 minecraft:yellow_concrete
fill 235 142 597 235 147 598 minecraft:orange_terracotta
setblock 235 142 599 minecraft:yellow_concrete
fill 238 142 557 239 147 557 minecraft:orange_terracotta
fill 240 142 557 241 142 557 minecraft:yellow_concrete
fill 243 142 599 244 143 599 minecraft:yellow_concrete
fill 245 142 599 246 147 599 minecraft:orange_terracotta
fill 250 142 557 251 147 557 minecraft:orange_terracotta
fill 252 142 557 253 143 557 minecraft:yellow_concrete
fill 252 142 599 252 143 599 minecraft:yellow_concrete
fill 254 142 599 254 147 599 minecraft:orange_terracotta
fill 255 142 599 256 142 599 minecraft:yellow_concrete
fill 257 142 599 257 147 599 minecraft:orange_terracotta
fill 259 142 557 259 147 557 minecraft:orange_terracotta
fill 260 142 557 261 142 557 minecraft:yellow_concrete
fill 262 142 557 262 147 557 minecraft:orange_terracotta
fill 263 142 581 264 143 581 minecraft:red_concrete
fill 263 142 599 264 143 599 minecraft:yellow_concrete
fill 264 142 557 264 143 557 minecraft:yellow_concrete
fill 265 142 599 266 147 599 minecraft:orange_terracotta
fill 270 142 557 271 147 557 minecraft:orange_terracotta
fill 272 142 557 273 143 557 minecraft:yellow_concrete
fill 274 142 590 276 143 592 minecraft:magma_block
fill 275 142 599 276 142 599 minecraft:yellow_concrete
setblock 277 142 561 minecraft:yellow_concrete
fill 277 142 562 277 147 563 minecraft:orange_terracotta
fill 277 142 564 277 143 565 minecraft:yellow_concrete
fill 277 142 570 277 147 571 minecraft:orange_terracotta
fill 277 142 572 277 142 573 minecraft:yellow_concrete
fill 277 142 574 277 147 574 minecraft:orange_terracotta
fill 277 142 582 277 147 583 minecraft:orange_terracotta
fill 277 142 584 277 143 585 minecraft:yellow_concrete
fill 277 142 591 277 147 591 minecraft:orange_terracotta
setblock 277 142 593 minecraft:yellow_concrete
fill 277 142 594 277 147 595 minecraft:orange_terracotta
fill 277 142 596 277 143 596 minecraft:yellow_concrete
fill 277 142 599 277 147 599 minecraft:orange_terracotta
setblock 235 143 563 minecraft:yellow_concrete
fill 235 143 567 235 145 568 minecraft:orange_terracotta
fill 235 143 583 235 143 584 minecraft:yellow_concrete
setblock 235 143 587 minecraft:yellow_concrete
fill 235 143 588 235 146 588 minecraft:orange_terracotta
fill 235 143 599 235 146 599 minecraft:orange_terracotta
setblock 238 143 560 minecraft:light[level=14]
setblock 238 143 568 minecraft:light[level=14]
setblock 238 143 576 minecraft:light[level=14]
setblock 238 143 584 minecraft:light[level=14]
setblock 238 143 592 minecraft:light[level=14]
fill 240 143 557 240 146 557 minecraft:orange_terracotta
setblock 240 143 599 minecraft:yellow_concrete
setblock 241 143 557 minecraft:yellow_concrete
setblock 244 143 557 minecraft:yellow_concrete
setblock 246 143 560 minecraft:light[level=14]
setblock 246 143 568 minecraft:light[level=14]
setblock 246 143 576 minecraft:light[level=14]
setblock 246 143 584 minecraft:light[level=14]
setblock 246 143 592 minecraft:light[level=14]
fill 248 143 575 248 144 575 minecraft:red_concrete
setblock 251 143 599 minecraft:yellow_concrete
setblock 254 143 560 minecraft:light[level=14]
setblock 254 143 568 minecraft:light[level=14]
setblock 254 143 576 minecraft:light[level=14]
setblock 254 143 584 minecraft:light[level=14]
setblock 254 143 592 minecraft:light[level=14]
fill 255 143 599 256 146 599 minecraft:orange_terracotta
fill 260 143 557 261 146 557 minecraft:orange_terracotta
setblock 262 143 560 minecraft:light[level=14]
setblock 262 143 568 minecraft:light[level=14]
setblock 262 143 576 minecraft:light[level=14]
setblock 262 143 584 minecraft:light[level=14]
setblock 262 143 592 minecraft:light[level=14]
setblock 265 143 557 minecraft:yellow_concrete
setblock 270 143 560 minecraft:light[level=14]
setblock 270 143 568 minecraft:light[level=14]
setblock 270 143 576 minecraft:light[level=14]
setblock 270 143 584 minecraft:light[level=14]
setblock 270 143 592 minecraft:light[level=14]
fill 272 143 591 273 146 591 minecraft:magma_block
setblock 272 143 599 minecraft:yellow_concrete
fill 273 143 590 273 145 590 minecraft:magma_block
fill 273 143 592 273 145 592 minecraft:magma_block
fill 274 143 589 276 144 589 minecraft:magma_block
fill 274 143 593 276 144 593 minecraft:magma_block
setblock 275 143 599 minecraft:yellow_concrete
setblock 276 143 557 minecraft:yellow_concrete
fill 276 143 599 276 146 599 minecraft:orange_terracotta
fill 277 143 561 277 146 561 minecraft:orange_terracotta
fill 277 143 572 277 146 572 minecraft:orange_terracotta
setblock 277 143 573 minecraft:yellow_concrete
fill 277 143 576 277 143 577 minecraft:yellow_concrete
fill 277 143 593 277 146 593 minecraft:orange_terracotta
setblock 277 143 597 minecraft:yellow_concrete
fill 235 144 561 235 145 562 minecraft:yellow_concrete
fill 235 144 563 235 149 564 minecraft:orange_terracotta
setblock 235 144 565 minecraft:yellow_concrete
fill 235 144 566 235 147 566 minecraft:orange_terracotta
fill 235 144 573 235 145 574 minecraft:yellow_concrete
fill 235 144 575 235 149 576 minecraft:orange_terracotta
fill 235 144 582 235 145 582 minecraft:yellow_concrete
fill 235 144 583 235 145 584 minecraft:orange_terracotta
fill 235 144 585 235 144 586 minecraft:yellow_concrete
fill 235 144 587 235 149 587 minecraft:orange_terracotta
fill 235 144 593 235 145 594 minecraft:yellow_concrete
fill 235 144 595 235 149 596 minecraft:orange_terracotta
fill 236 144 558 238 144 558 minecraft:orange_concrete
fill 236 144 560 236 144 562 minecraft:orange_concrete
fill 236 144 564 236 144 566 minecraft:orange_concrete
fill 236 144 568 236 144 570 minecraft:orange_concrete
fill 236 144 572 236 144 574 minecraft:orange_concrete
fill 236 144 576 236 144 578 minecraft:orange_concrete
fill 236 144 580 236 144 582 minecraft:orange_concrete
fill 236 144 584 236 144 586 minecraft:orange_concrete
fill 236 144 588 236 144 590 minecraft:orange_concrete
fill 236 144 592 236 144 594 minecraft:orange_concrete
fill 236 144 596 236 144 598 minecraft:orange_concrete
fill 238 144 598 240 144 598 minecraft:orange_concrete
fill 240 144 558 242 144 558 minecraft:orange_concrete
fill 240 144 599 240 149 599 minecraft:orange_terracotta
fill 241 144 557 241 149 557 minecraft:orange_terracotta
fill 241 144 599 242 144 599 minecraft:yellow_concrete
fill 242 144 557 243 144 557 minecraft:yellow_concrete
fill 242 144 598 244 144 598 minecraft:orange_concrete
fill 243 144 599 244 149 599 minecraft:orange_terracotta
fill 244 144 557 244 149 557 minecraft:orange_terracotta
fill 244 144 558 246 144 558 minecraft:orange_concrete
fill 246 144 557 246 145 557 minecraft:yellow_concrete
fill 246 144 598 248 144 598 minecraft:orange_concrete
fill 247 144 558 247 147 558 minecraft:magma_block
fill 248 144 558 250 144 558 minecraft:orange_concrete
fill 249 144 599 250 145 599 minecraft:yellow_concrete
fill 250 144 598 252 144 598 minecraft:orange_concrete
fill 251 144 599 252 149 599 minecraft:orange_terracotta
fill 252 144 557 253 149 557 minecraft:orange_terracotta
fill 252 144 558 254 144 558 minecraft:orange_concrete
setblock 253 144 599 minecraft:yellow_concrete
fill 254 144 557 255 145 557 minecraft:yellow_concrete
fill 254 144 598 256 144 598 minecraft:orange_concrete
fill 256 144 558 258 144 558 minecraft:orange_concrete
fill 256 144 587 257 145 588 minecraft:orange_concrete
fill 258 144 598 260 144 598 minecraft:orange_concrete
fill 260 144 558 262 144 558 minecraft:orange_concrete
fill 261 144 599 262 145 599 minecraft:yellow_concrete
fill 262 144 598 264 144 598 minecraft:orange_concrete
setblock 263 144 557 minecraft:yellow_concrete
fill 263 144 599 264 149 599 minecraft:orange_terracotta
fill 264 144 557 265 149 557 minecraft:orange_terracotta
fill 264 144 558 266 144 558 minecraft:orange_concrete
fill 266 144 557 267 145 557 minecraft:yellow_concrete
fill 266 144 598 268 144 598 minecraft:orange_concrete
fill 268 144 558 270 144 558 minecraft:orange_concrete
fill 270 144 598 272 144 598 minecraft:orange_concrete
fill 270 144 599 270 145 599 minecraft:yellow_concrete
fill 271 144 591 271 146 591 minecraft:magma_block
fill 272 144 557 273 149 557 minecraft:orange_terracotta
fill 272 144 558 274 144 558 minecraft:orange_concrete
fill 272 144 590 272 145 590 minecraft:magma_block
fill 272 144 592 272 145 592 minecraft:magma_block
fill 272 144 599 272 149 599 minecraft:orange_terracotta
fill 273 144 599 274 144 599 minecraft:yellow_concrete
fill 274 144 557 275 144 557 minecraft:yellow_concrete
fill 274 144 590 275 145 592 minecraft:magma_block
fill 274 144 598 276 144 598 minecraft:orange_concrete
fill 275 144 599 275 149 599 minecraft:orange_terracotta
fill 276 144 557 276 149 557 minecraft:orange_terracotta
fill 276 144 558 276 144 560 minecraft:orange_concrete
fill 276 144 562 276 144 564 minecraft:orange_concrete
fill 276 144 566 276 144 568 minecraft:orange_concrete
fill 276 144 570 276 144 572 minecraft:orange_concrete
fill 276 144 574 276 144 576 minecraft:orange_concrete
fill 276 144 578 276 144 580 minecraft:orange_concrete
fill 276 144 582 276 144 584 minecraft:orange_concrete
fill 276 144 586 276 144 588 minecraft:orange_concrete
fill 276 144 590 276 144 592 minecraft:orange_concrete
fill 276 144 594 276 144 596 minecraft:orange_concrete
fill 277 144 564 277 149 565 minecraft:orange_terracotta
fill 277 144 566 277 145 567 minecraft:yellow_concrete
fill 277 144 573 277 149 573 minecraft:orange_terracotta
setblock 277 144 575 minecraft:yellow_concrete
fill 277 144 576 277 149 577 minecraft:orange_terracotta
fill 277 144 578 277 145 578 minecraft:yellow_concrete
fill 277 144 584 277 149 585 minecraft:orange_terracotta
fill 277 144 586 277 144 587 minecraft:yellow_concrete
fill 277 144 596 277 149 597 minecraft:orange_terracotta
fill 277 144 598 277 145 598 minecraft:yellow_concrete
fill 235 145 565 235 147 565 minecraft:orange_terracotta
setblock 235 145 570 minecraft:yellow_concrete
setblock 235 145 581 minecraft:yellow_concrete
fill 235 145 585 235 147 586 minecraft:orange_terracotta
fill 237 145 599 238 145 599 minecraft:yellow_concrete
setblock 241 145 599 minecraft:yellow_concrete
fill 242 145 557 243 148 557 minecraft:orange_terracotta
fill 242 145 599 242 148 599 minecraft:orange_terracotta
fill 246 145 558 246 146 559 minecraft:magma_block
setblock 247 145 557 minecraft:yellow_concrete
fill 247 145 559 247 147 560 minecraft:magma_block
fill 248 145 558 248 146 559 minecraft:magma_block
fill 253 145 599 253 148 599 minecraft:orange_terracotta
setblock 258 145 557 minecraft:yellow_concrete
setblock 258 145 599 minecraft:yellow_concrete
fill 263 145 557 263 148 557 minecraft:orange_terracotta
fill 269 145 591 270 146 591 minecraft:magma_block
setblock 269 145 599 minecraft:yellow_concrete
fill 270 145 590 271 145 590 minecraft:magma_block
fill 270 145 592 271 145 592 minecraft:magma_block
fill 273 145 599 274 148 599 minecraft:orange_terracotta
fill 274 145 557 274 148 557 minecraft:orange_terracotta
setblock 275 145 557 minecraft:yellow_concrete
fill 276 145 590 276 145 592 minecraft:magma_block
fill 277 145 558 277 145 559 minecraft:yellow_concrete
fill 277 145 575 277 148 575 minecraft:orange_terracotta
setblock 277 145 579 minecraft:yellow_concrete
fill 277 145 586 277 148 586 minecraft:orange_terracotta
setblock 277 145 587 minecraft:yellow_concrete
setblock 277 145 590 minecraft:yellow_concrete
fill 235 146 559 235 147 560 minecraft:yellow_concrete
fill 235 146 561 235 151 562 minecraft:orange_terracotta
setblock 235 146 567 minecraft:orange_terracotta
fill 235 146 568 235 147 568 minecraft:yellow_concrete
fill 235 146 570 235 151 570 minecraft:orange_terracotta
fill 235 146 571 235 146 572 minecraft:yellow_concrete
fill 235 146 573 235 148 574 minecraft:orange_terracotta
fill 235 146 579 235 147 580 minecraft:yellow_concrete
fill 235 146 581 235 151 582 minecraft:orange_terracotta
setblock 235 146 583 minecraft:yellow_concrete
fill 235 146 584 235 149 584 minecraft:orange_terracotta
fill 235 146 591 235 146 592 minecraft:yellow_concrete
fill 235 146 593 235 151 594 minecraft:orange_terracotta
fill 236 146 557 237 147 557 minecraft:yellow_concrete
fill 236 146 599 236 147 599 minecraft:yellow_concrete
fill 237 146 599 238 151 599 minecraft:orange_terracotta
setblock 239 146 599 minecraft:yellow_concrete
fill 241 146 599 241 151 599 minecraft:orange_terracotta
setblock 245 146 557 minecraft:yellow_concrete
fill 246 146 557 247 151 557 minecraft:orange_terracotta
setblock 246 146 560 minecraft:magma_block
fill 247 146 561 247 147 562 minecraft:magma_block
fill 247 146 599 248 147 599 minecraft:yellow_concrete
fill 248 146 557 249 147 557 minecraft:yellow_concrete
setblock 248 146 560 minecraft:magma_block
fill 249 146 599 250 151 599 minecraft:orange_terracotta
fill 254 146 557 255 151 557 minecraft:orange_terracotta
fill 256 146 557 257 146 557 minecraft:yellow_concrete
fill 258 146 557 258 151 557 minecraft:orange_terracotta
fill 258 146 599 258 151 599 minecraft:orange_terracotta
fill 259 146 599 260 146 599 minecraft:yellow_concrete
fill 261 146 599 262 151 599 minecraft:orange_terracotta
fill 266 146 557 267 151 557 minecraft:orange_terracotta
fill 267 146 599 268 147 599 minecraft:yellow_concrete
fill 268 146 557 269 147 557 minecraft:yellow_concrete
setblock 268 146 591 minecraft:magma_block
fill 269 146 599 270 151 599 minecraft:orange_terracotta
setblock 271 146 599 minecraft:yellow_concrete
setblock 274 146 591 minecraft:magma_block
fill 275 146 557 275 151 557 minecraft:orange_terracotta
setblock 277 146 557 minecraft:yellow_concrete
fill 277 146 558 277 151 559 minecraft:orange_terracotta
fill 277 146 560 277 147 560 minecraft:yellow_concrete
fill 277 146 566 277 151 567 minecraft:orange_terracotta
fill 277 146 568 277 146 569 minecraft:yellow_concrete
fill 277 146 578 277 151 579 minecraft:orange_terracotta
fill 277 146 580 277 147 581 minecraft:yellow_concrete
fill 277 146 587 277 151 587 minecraft:orange_terracotta
fill 277 146 588 277 146 589 minecraft:yellow_concrete
fill 277 146 590 277 151 590 minecraft:orange_terracotta
fill 277 146 592 277 147 592 minecraft:yellow_concrete
fill 277 146 598 277 151 598 minecraft:orange_terracotta
setblock 235 147 567 minecraft:yellow_concrete
setblock 235 147 571 minecraft:yellow_concrete
fill 235 147 572 235 150 572 minecraft:orange_terracotta
fill 235 147 583 235 149 583 minecraft:orange_terracotta
setblock 235 147 588 minecraft:yellow_concrete
setblock 235 147 591 minecraft:yellow_concrete
fill 235 147 592 235 150 592 minecraft:orange_terracotta
setblock 235 147 599 minecraft:yellow_concrete
fill 239 147 599 239 150 599 minecraft:orange_terracotta
setblock 240 147 557 minecraft:yellow_concrete
fill 245 147 557 245 150 557 minecraft:orange_terracotta
fill 247 147 563 247 148 563 minecraft:magma_block
fill 255 147 599 256 147 599 minecraft:yellow_concrete
fill 256 147 557 256 150 557 minecraft:orange_terracotta
setblock 257 147 557 minecraft:yellow_concrete
setblock 259 147 599 minecraft:yellow_concrete
fill 260 147 557 261 147 557 minecraft:yellow_concrete
fill 260 147 599 260 150 599 minecraft:orange_terracotta
fill 271 147 599 271 150 599 minecraft:orange_terracotta
setblock 276 147 599 minecraft:yellow_concrete
fill 277 147 557 277 150 557 minecraft:orange_terracotta
setblock 277 147 561 minecraft:yellow_concrete
fill 277 147 568 277 150 568 minecraft:orange_terracotta
setblock 277 147 569 minecraft:yellow_concrete
setblock 277 147 572 minecraft:yellow_concrete
fill 277 147 588 277 150 589 minecraft:orange_terracotta
setblock 277 147 593 minecraft:yellow_concrete
fill 235 148 557 235 148 558 minecraft:yellow_concrete
fill 235 148 559 235 153 560 minecraft:orange_terracotta
fill 235 148 565 235 149 566 minecraft:yellow_concrete
fill 235 148 567 235 153 568 minecraft:orange_terracotta
setblock 235 148 569 minecraft:yellow_concrete
fill 235 148 571 235 150 571 minecraft:orange_terracotta
fill 235 148 577 235 149 578 minecraft:yellow_concrete
fill 235 148 579 235 153 580 minecraft:orange_terracotta
setblock 235 148 585 minecraft:orange_terracotta
fill 235 148 586 235 149 586 minecraft:yellow_concrete
fill 235 148 588 235 153 588 minecraft:orange_terracotta
fill 235 148 589 235 148 590 minecraft:yellow_concrete
fill 235 148 591 235 153 591 minecraft:orange_terracotta
fill 235 148 597 235 149 598 minecraft:yellow_concrete
fill 235 148 599 236 153 599 minecraft:orange_terracotta
fill 236 148 557 237 153 557 minecraft:orange_terracotta
fill 238 148 557 239 148 557 minecraft:yellow_concrete
fill 240 148 557 240 153 557 minecraft:orange_terracotta
fill 245 148 599 246 148 599 minecraft:yellow_concrete
setblock 247 148 564 minecraft:magma_block
fill 247 148 599 248 153 599 minecraft:orange_terracotta
fill 248 148 557 249 153 557 minecraft:orange_terracotta
fill 250 148 557 251 149 557 minecraft:yellow_concrete
fill 254 148 599 254 149 599 minecraft:yellow_concrete
fill 255 148 599 256 153 599 minecraft:orange_terracotta
fill 257 148 557 257 153 557 minecraft:orange_terracotta
setblock 257 148 599 minecraft:yellow_concrete
setblock 259 148 557 minecraft:yellow_concrete
fill 259 148 599 259 153 599 minecraft:orange_terracotta
fill 260 148 557 261 153 557 minecraft:orange_terracotta
fill 262 148 557 262 149 557 minecraft:yellow_concrete
fill 265 148 599 266 149 599 minecraft:yellow_concrete
fill 267 148 599 268 153 599 minecraft:orange_terracotta
fill 268 148 557 269 153 557 minecraft:orange_terracotta
fill 270 148 557 271 148 557 minecraft:yellow_concrete
fill 276 148 599 276 153 599 minecraft:orange_terracotta
fill 277 148 560 277 153 561 minecraft:orange_terracotta
fill 277 148 562 277 149 563 minecraft:yellow_concrete
fill 277 148 569 277 153 569 minecraft:orange_terracotta
fill 277 148 570 277 148 571 minecraft:yellow_concrete
fill 277 148 572 277 153 572 minecraft:orange_terracotta
fill 277 148 574 277 149 574 minecraft:yellow_concrete
fill 277 148 580 277 153 581 minecraft:orange_terracotta
fill 277 148 582 277 149 583 minecraft:yellow_concrete
setblock 277 148 591 minecraft:yellow_concrete
fill 277 148 592 277 153 593 minecraft:orange_terracotta
fill 277 148 594 277 149 595 minecraft:yellow_concrete
fill 277 148 599 277 149 599 minecraft:yellow_concrete
setblock 235 149 557 minecraft:yellow_concrete
fill 235 149 558 235 152 558 minecraft:orange_terracotta
fill 235 149 569 235 152 569 minecraft:orange_terracotta
fill 235 149 573 235 151 573 minecraft:orange_terracotta
setblock 235 149 574 minecraft:yellow_concrete
setblock 235 149 585 minecraft:yellow_concrete
fill 235 149 589 235 152 590 minecraft:orange_terracotta
fill 238 149 557 238 152 557 minecraft:orange_terracotta
setblock 239 149 557 minecraft:yellow_concrete
fill 242 149 557 243 149 557 minecraft:yellow_concrete
setblock 242 149 599 minecraft:yellow_concrete
setblock 245 149 599 minecraft:yellow_concrete
fill 246 149 599 246 152 599 minecraft:orange_terracotta
setblock 253 149 599 minecraft:yellow_concrete
fill 257 149 599 257 152 599 minecraft:orange_terracotta
fill 259 149 557 259 152 557 minecraft:orange_terracotta
setblock 263 149 557 minecraft:yellow_concrete
fill 270 149 557 270 152 557 minecraft:orange_terracotta
setblock 271 149 557 minecraft:yellow_concrete
fill 273 149 599 274 149 599 minecraft:yellow_concrete
setblock 274 149 557 minecraft:yellow_concrete
fill 277 149 570 277 152 571 minecraft:orange_terracotta
setblock 277 149 575 minecraft:yellow_concrete
setblock 277 149 586 minecraft:yellow_concrete
fill 277 149 591 277 152 591 minecraft:orange_terracotta
fill 235 150 557 235 155 557 minecraft:orange_terracotta
fill 235 150 563 235 151 564 minecraft:yellow_concrete
fill 235 150 565 235 155 566 minecraft:orange_terracotta
fill 235 150 574 235 151 574 minecraft:orange_terracotta
fill 235 150 575 235 150 576 minecraft:yellow_concrete
fill 235 150 577 235 155 578 minecraft:orange_terracotta
fill 235 150 583 235 151 584 minecraft:yellow_concrete
fill 235 150 585 235 155 586 minecraft:orange_terracotta
setblock 235 150 587 minecraft:yellow_concrete
fill 235 150 595 235 151 596 minecraft:yellow_concrete
fill 235 150 597 235 155 598 minecraft:orange_terracotta
fill 236 150 558 238 150 558 minecraft:orange_concrete
fill 236 150 560 236 150 562 minecraft:orange_concrete
fill 236 150 564 236 150 566 minecraft:orange_concrete
fill 236 150 568 236 150 570 minecraft:orange_concrete
fill 236 150 572 236 150 574 minecraft:orange_concrete
fill 236 150 576 236 150 578 minecraft:orange_concrete
fill 236 150 580 236 150 582 minecraft:orange_concrete
fill 236 150 584 236 150 586 minecraft:orange_concrete
fill 236 150 588 236 150 590 minecraft:orange_concrete
fill 236 150 592 236 150 594 minecraft:orange_concrete
fill 236 150 596 236 150 598 minecraft:orange_concrete
fill 238 150 598 240 150 598 minecraft:orange_concrete
fill 239 150 557 239 155 557 minecraft:orange_terracotta
fill 240 150 558 242 150 558 minecraft:orange_concrete
fill 240 150 599 240 151 599 minecraft:yellow_concrete
setblock 241 150 557 minecraft:yellow_concrete
fill 242 150 557 243 155 557 minecraft:orange_terracotta
fill 242 150 598 244 150 598 minecraft:orange_concrete
fill 242 150 599 242 155 599 minecraft:orange_terracotta
fill 243 150 599 244 150 599 minecraft:yellow_concrete
fill 244 150 557 244 151 557 minecraft:yellow_concrete
fill 244 150 558 246 150 558 minecraft:orange_concrete
fill 245 150 599 245 155 599 minecraft:orange_terracotta
fill 246 150 598 248 150 598 minecraft:orange_concrete
fill 248 150 558 250 150 558 minecraft:orange_concrete
fill 250 150 557 251 155 557 minecraft:orange_terracotta
fill 250 150 598 252 150 598 minecraft:orange_concrete
fill 251 150 599 252 151 599 minecraft:yellow_concrete
fill 252 150 557 253 150 557 minecraft:yellow_concrete
fill 252 150 558 254 150 558 minecraft:orange_concrete
fill 253 150 599 254 155 599 minecraft:orange_terracotta
fill 254 150 598 256 150 598 minecraft:orange_concrete
fill 256 150 558 258 150 558 minecraft:orange_concrete
fill 258 150 598 260 150 598 minecraft:orange_concrete
fill 260 150 558 262 150 558 minecraft:orange_concrete
fill 262 150 557 263 155 557 minecraft:orange_terracotta
fill 262 150 598 264 150 598 minecraft:orange_concrete
fill 263 150 599 264 150 599 minecraft:yellow_concrete
fill 264 150 557 265 151 557 minecraft:yellow_concrete
fill 264 150 558 266 150 558 minecraft:orange_concrete
fill 265 150 599 266 155 599 minecraft:orange_terracotta
fill 266 150 598 268 150 598 minecraft:orange_concrete
fill 268 150 558 270 150 558 minecraft:orange_concrete
fill 270 150 598 272 150 598 minecraft:orange_concrete
fill 271 150 557 271 155 557 minecraft:orange_terracotta
fill 272 150 557 273 150 557 minecraft:yellow_concrete
fill 272 150 558 274 150 558 minecraft:orange_concrete
fill 272 150 599 272 151 599 minecraft:yellow_concrete
fill 273 150 599 274 155 599 minecraft:orange_terracotta
fill 274 150 557 274 155 557 minecraft:orange_terracotta
fill 274 150 598 276 150 598 minecraft:orange_concrete
setblock 275 150 599 minecraft:yellow_concrete
fill 276 150 557 276 151 557 minecraft:yellow_concrete
fill 276 150 558 276 150 560 minecraft:orange_concrete
fill 276 150 562 276 150 564 minecraft:orange_concrete
fill 276 150 566 276 150 568 minecraft:orange_concrete
fill 276 150 570 276 150 572 minecraft:orange_concrete
fill 276 150 574 276 150 576 minecraft:orange_concrete
fill 276 150 578 276 150 580 minecraft:orange_concrete
fill 276 150 582 276 150 584 minecraft:orange_concrete
fill 276 150 586 276 150 588 minecraft:orange_concrete
fill 276 150 590 276 150 592 minecraft:orange_concrete
fill 276 150 594 276 150 596 minecraft:orange_concrete
fill 277 150 562 277 155 563 minecraft:orange_terracotta
fill 277 150 564 277 151 565 minecraft:yellow_concrete
setblock 277 150 573 minecraft:yellow_concrete
fill 277 150 574 277 155 575 minecraft:orange_terracotta
fill 277 150 576 277 151 577 minecraft:yellow_concrete
fill 277 150 582 277 155 583 minecraft:orange_terracotta
fill 277 150 584 277 150 585 minecraft:yellow_concrete
fill 277 150 586 277 155 586 minecraft:orange_terracotta
fill 277 150 594 277 155 595 minecraft:orange_terracotta
fill 277 150 596 277 151 597 minecraft:yellow_concrete
fill 277 150 599 277 155 599 minecraft:orange_terracotta
fill 235 151 571 235 151 572 minecraft:yellow_concrete
setblock 235 151 575 minecraft:yellow_concrete
fill 235 151 576 235 154 576 minecraft:orange_terracotta
fill 235 151 587 235 154 587 minecraft:orange_terracotta
setblock 235 151 592 minecraft:yellow_concrete
setblock 238 151 560 minecraft:light[level=14]
setblock 238 151 568 minecraft:light[level=14]
setblock 238 151 576 minecraft:light[level=14]
setblock 238 151 584 minecraft:light[level=14]
setblock 238 151 592 minecraft:light[level=14]
setblock 239 151 599 minecraft:yellow_concrete
fill 241 151 557 241 154 557 minecraft:orange_terracotta
fill 243 151 599 244 154 599 minecraft:orange_terracotta
setblock 245 151 557 minecraft:yellow_concrete
setblock 246 151 560 minecraft:light[level=14]
setblock 246 151 568 minecraft:light[level=14]
setblock 246 151 576 minecraft:light[level=14]
setblock 246 151 584 minecraft:light[level=14]
setblock 246 151 592 minecraft:light[level=14]
fill 252 151 557 252 154 557 minecraft:orange_terracotta
setblock 253 151 557 minecraft:yellow_concrete
setblock 254 151 560 minecraft:light[level=14]
setblock 254 151 568 minecraft:light[level=14]
setblock 254 151 576 minecraft:light[level=14]
setblock 254 151 584 minecraft:light[level=14]
setblock 254 151 592 minecraft:light[level=14]
setblock 256 151 557 minecraft:yellow_concrete
setblock 260 151 599 minecraft:yellow_concrete
setblock 262 151 560 minecraft:light[level=14]
setblock 262 151 568 minecraft:light[level=14]
setblock 262 151 576 minecraft:light[level=14]
setblock 262 151 584 minecraft:light[level=14]
setblock 262 151 592 minecraft:light[level=14]
setblock 263 151 599 minecraft:yellow_concrete
fill 264 151 599 264 154 599 minecraft:orange_terracotta
setblock 270 151 560 minecraft:light[level=14]
setblock 270 151 568 minecraft:light[level=14]
setblock 270 151 576 minecraft:light[level=14]
setblock 270 151 584 minecraft:light[level=14]
setblock 270 151 592 minecraft:light[level=14]
setblock 271 151 599 minecraft:yellow_concrete
fill 272 151 557 273 154 557 minecraft:orange_terracotta
fill 275 151 599 275 154 599 minecraft:orange_terracotta
setblock 277 151 557 minecraft:yellow_concrete
setblock 277 151 568 minecraft:yellow_concrete
fill 277 151 573 277 154 573 minecraft:orange_terracotta
fill 277 151 584 277 154 584 minecraft:orange_terracotta
setblock 277 151 585 minecraft:yellow_concrete
fill 277 151 588 277 151 589 minecraft:yellow_concrete
fill 235 152 561 235 153 562 minecraft:yellow_concrete
fill 235 152 563 235 157 564 minecraft:orange_terracotta
fill 235 152 570 235 153 570 minecraft:yellow_concrete
fill 235 152 571 235 153 572 minecraft:orange_terracotta
fill 235 152 573 235 152 574 minecraft:yellow_concrete
fill 235 152 575 235 157 575 minecraft:orange_terracotta
fill 235 152 581 235 153 582 minecraft:yellow_concrete
fill 235 152 583 235 157 584 minecraft:orange_terracotta
fill 235 152 592 235 157 592 minecraft:orange_terracotta
fill 235 152 593 235 152 594 minecraft:yellow_concrete
fill 235 152 595 235 157 596 minecraft:orange_terracotta
fill 237 152 599 238 153 599 minecraft:yellow_concrete
fill 239 152 599 240 157 599 minecraft:orange_terracotta
setblock 241 152 599 minecraft:yellow_concrete
fill 244 152 557 245 157 557 minecraft:orange_terracotta
fill 246 152 557 247 153 557 minecraft:yellow_concrete
fill 249 152 599 250 153 599 minecraft:yellow_concrete
fill 251 152 599 252 157 599 minecraft:orange_terracotta
fill 253 152 557 253 157 557 minecraft:orange_terracotta
fill 254 152 557 255 152 557 minecraft:yellow_concrete
fill 256 152 557 256 157 557 minecraft:orange_terracotta
fill 258 152 557 258 153 557 minecraft:yellow_concrete
fill 258 152 599 258 153 599 minecraft:yellow_concrete
fill 260 152 599 260 157 599 minecraft:orange_terracotta
fill 261 152 599 262 152 599 minecraft:yellow_concrete
fill 263 152 599 263 157 599 minecraft:orange_terracotta
fill 264 152 557 265 157 557 minecraft:orange_terracotta
fill 266 152 557 267 153 557 minecraft:yellow_concrete
fill 269 152 599 270 153 599 minecraft:yellow_concrete
fill 271 152 599 272 157 599 minecraft:orange_terracotta
setblock 275 152 557 minecraft:yellow_concrete
fill 276 152 557 277 157 557 minecraft:orange_terracotta
fill 277 152 558 277 153 559 minecraft:yellow_concrete
fill 277 152 564 277 157 565 minecraft:orange_terracotta
fill 277 152 566 277 152 567 minecraft:yellow_concrete
fill 277 152 568 277 157 568 minecraft:orange_terracotta
fill 277 152 576 277 157 577 minecraft:orange_terracotta
fill 277 152 578 277 153 579 minecraft:yellow_concrete
fill 277 152 585 277 157 585 minecraft:orange_terracotta
setblock 277 152 587 minecraft:yellow_concrete
fill 277 152 588 277 157 589 minecraft:orange_terracotta
fill 277 152 590 277 153 590 minecraft:yellow_concrete
fill 277 152 596 277 157 597 minecraft:orange_terracotta
setblock 277 152 598 minecraft:yellow_concrete
setblock 235 153 558 minecraft:yellow_concrete
setblock 235 153 569 minecraft:yellow_concrete
fill 235 153 573 235 155 574 minecraft:orange_terracotta
fill 235 153 589 235 153 590 minecraft:yellow_concrete
setblock 235 153 593 minecraft:yellow_concrete
fill 235 153 594 235 156 594 minecraft:orange_terracotta
setblock 238 153 557 minecraft:yellow_concrete
fill 241 153 599 241 156 599 minecraft:orange_terracotta
setblock 246 153 599 minecraft:yellow_concrete
fill 254 153 557 255 156 557 minecraft:orange_terracotta
setblock 257 153 599 minecraft:yellow_concrete
setblock 259 153 557 minecraft:yellow_concrete
fill 261 153 599 262 156 599 minecraft:orange_terracotta
setblock 270 153 557 minecraft:yellow_concrete
fill 275 153 557 275 156 557 minecraft:orange_terracotta
fill 277 153 566 277 156 566 minecraft:orange_terracotta
setblock 277 153 567 minecraft:yellow_concrete
fill 277 153 570 277 153 571 minecraft:yellow_concrete
fill 277 153 587 277 156 587 minecraft:orange_terracotta
setblock 277 153 591 minecraft:yellow_concrete
fill 277 153 598 277 156 598 minecraft:orange_terracotta
fill 235 154 558 235 159 558 minecraft:orange_terracotta
fill 235 154 559 235 154 560 minecraft:yellow_concrete
fill 235 154 561 235 156 562 minecraft:orange_terracotta
fill 235 154 567 235 155 568 minecraft:yellow_concrete
fill 235 154 569 235 159 570 minecraft:orange_terracotta
setblock 235 154 571 minecraft:yellow_concrete
fill 235 154 572 235 157 572 minecraft:orange_terracotta
fill 235 154 579 235 154 580 minecraft:yellow_concrete
fill 235 154 581 235 159 582 minecraft:orange_terracotta
fill 235 154 588 235 155 588 minecraft:yellow_concrete
fill 235 154 589 235 159 590 minecraft:orange_terracotta
setblock 235 154 591 minecraft:yellow_concrete
fill 235 154 593 235 159 593 minecraft:orange_terracotta
fill 235 154 599 236 155 599 minecraft:yellow_concrete
fill 236 154 557 237 154 557 minecraft:yellow_concrete
fill 237 154 599 238 159 599 minecraft:orange_terracotta
fill 238 154 557 238 159 557 minecraft:orange_terracotta
fill 240 154 557 240 155 557 minecraft:yellow_concrete
fill 246 154 557 247 159 557 minecraft:orange_terracotta
fill 246 154 599 246 159 599 minecraft:orange_terracotta
fill 247 154 599 248 154 599 minecraft:yellow_concrete
fill 248 154 557 249 155 557 minecraft:yellow_concrete
fill 249 154 599 250 159 599 minecraft:orange_terracotta
fill 255 154 599 256 155 599 minecraft:yellow_concrete
fill 256 154 590 257 155 591 minecraft:shroomlight
setblock 257 154 557 minecraft:yellow_concrete
fill 257 154 599 258 159 599 minecraft:orange_terracotta
fill 258 154 557 259 159 557 minecraft:orange_terracotta
setblock 259 154 599 minecraft:yellow_concrete
fill 260 154 557 261 155 557 minecraft:yellow_concrete
fill 266 154 557 267 159 557 minecraft:orange_terracotta
fill 267 154 599 268 155 599 minecraft:yellow_concrete
fill 268 154 557 269 154 557 minecraft:yellow_concrete
fill 269 154 599 270 159 599 minecraft:orange_terracotta
fill 270 154 557 270 159 557 minecraft:orange_terracotta
fill 276 154 599 276 155 599 minecraft:yellow_concrete
fill 277 154 558 277 159 559 minecraft:orange_terracotta
fill 277 154 560 277 155 561 minecraft:yellow_concrete
fill 277 154 567 277 159 567 minecraft:orange_terracotta
setblock 277 154 569 minecraft:yellow_concrete
fill 277 154 570 277 159 571 minecraft:orange_terracotta
fill 277 154 572 277 155 572 minecraft:yellow_concrete
fill 277 154 578 277 159 579 minecraft:orange_terracotta
fill 277 154 580 277 154 581 minecraft:yellow_concrete
fill 277 154 590 277 159 591 minecraft:orange_terracotta
fill 277 154 592 277 155 593 minecraft:yellow_concrete
setblock 235 155 559 minecraft:yellow_concrete
fill 235 155 560 235 158 560 minecraft:orange_terracotta
fill 235 155 571 235 157 571 minecraft:orange_terracotta
setblock 235 155 576 minecraft:yellow_concrete
setblock 235 155 579 minecraft:yellow_concrete
fill 235 155 580 235 158 580 minecraft:orange_terracotta
setblock 235 155 587 minecraft:yellow_concrete
fill 235 155 591 235 158 591 minecraft:orange_terracotta
fill 236 155 557 237 157 557 minecraft:orange_terracotta
setblock 241 155 557 minecraft:yellow_concrete
fill 243 155 599 244 155 599 minecraft:yellow_concrete
setblock 247 155 599 minecraft:yellow_concrete
fill 248 155 599 248 158 599 minecraft:orange_terracotta
setblock 252 155 557 minecraft:yellow_concrete
fill 257 155 557 257 158 557 minecraft:orange_terracotta
fill 259 155 599 259 158 599 minecraft:orange_terracotta
setblock 264 155 599 minecraft:yellow_concrete
fill 268 155 557 268 158 557 minecraft:orange_terracotta
setblock 269 155 557 minecraft:yellow_concrete
fill 272 155 557 273 155 557 minecraft:yellow_concrete
setblock 275 155 599 minecraft:yellow_concrete
fill 277 155 569 277 158 569 minecraft:orange_terracotta
setblock 277 155 573 minecraft:yellow_concrete
fill 277 155 580 277 158 580 minecraft:orange_terracotta
setblock 277 155 581 minecraft:yellow_concrete
setblock 277 155 584 minecraft:yellow_concrete
setblock 235 156 557 minecraft:yellow_concrete
fill 235 156 559 235 158 559 minecraft:orange_terracotta
fill 235 156 565 235 157 566 minecraft:yellow_concrete
fill 235 156 567 235 161 568 minecraft:orange_terracotta
setblock 235 156 573 minecraft:orange_terracotta
fill 235 156 574 235 157 574 minecraft:yellow_concrete
fill 235 156 576 235 161 576 minecraft:orange_terracotta
fill 235 156 577 235 156 578 minecraft:yellow_concrete
fill 235 156 579 235 161 579 minecraft:orange_terracotta
fill 235 156 585 235 157 586 minecraft:yellow_concrete
fill 235 156 587 235 161 588 minecraft:orange_terracotta
fill 235 156 597 235 156 598 minecraft:yellow_concrete
fill 235 156 599 236 161 599 minecraft:orange_terracotta
fill 236 156 558 238 156 558 minecraft:orange_concrete
fill 236 156 560 236 156 562 minecraft:orange_concrete
fill 236 156 564 236 156 566 minecraft:orange_concrete
fill 236 156 568 236 156 570 minecraft:orange_concrete
fill 236 156 572 236 156 574 minecraft:orange_concrete
fill 236 156 576 236 156 578 minecraft:orange_concrete
fill 236 156 580 236 156 582 minecraft:orange_concrete
fill 236 156 584 236 156 586 minecraft:orange_concrete
fill 236 156 588 236 156 590 minecraft:orange_concrete
fill 236 156 592 236 156 594 minecraft:orange_concrete
fill 236 156 596 236 156 598 minecraft:orange_concrete
fill 238 156 598 240 156 598 minecraft:orange_concrete
setblock 239 156 557 minecraft:yellow_concrete
fill 240 156 557 241 161 557 minecraft:orange_terracotta
fill 240 156 558 242 156 558 minecraft:orange_concrete
fill 242 156 557 243 157 557 minecraft:yellow_concrete
fill 242 156 598 244 156 598 minecraft:orange_concrete
fill 242 156 599 242 157 599 minecraft:yellow_concrete
fill 243 156 599 244 161 599 minecraft:orange_terracotta
fill 244 156 558 246 156 558 minecraft:orange_concrete
setblock 245 156 599 minecraft:yellow_concrete
fill 246 156 598 248 156 598 minecraft:orange_concrete
fill 247 156 599 247 161 599 minecraft:orange_terracotta
fill 248 156 557 249 161 557 minecraft:orange_terracotta
fill 248 156 558 250 156 558 minecraft:orange_concrete
fill 250 156 557 251 156 557 minecraft:yellow_concrete
fill 250 156 598 252 156 598 minecraft:orange_concrete
fill 252 156 557 252 161 557 minecraft:orange_terracotta
fill 252 156 558 254 156 558 minecraft:orange_concrete
fill 253 156 599 254 157 599 minecraft:yellow_concrete
fill 254 156 598 256 156 598 minecraft:orange_concrete
fill 255 156 599 256 161 599 minecraft:orange_terracotta
fill 256 156 558 258 156 558 minecraft:orange_concrete
fill 258 156 598 260 156 598 minecraft:orange_concrete
fill 260 156 557 261 161 557 minecraft:orange_terracotta
fill 260 156 558 262 156 558 minecraft:orange_concrete
fill 262 156 557 263 157 557 minecraft:yellow_concrete
fill 262 156 598 264 156 598 minecraft:orange_concrete
fill 264 156 558 266 156 558 minecraft:orange_concrete
fill 264 156 599 264 161 599 minecraft:orange_terracotta
fill 265 156 599 266 156 599 minecraft:yellow_concrete
fill 266 156 598 268 156 598 minecraft:orange_concrete
fill 267 156 599 268 161 599 minecraft:orange_terracotta
fill 268 156 558 270 156 558 minecraft:orange_concrete
fill 269 156 557 269 161 557 minecraft:orange_terracotta
fill 270 156 598 272 156 598 minecraft:orange_concrete
setblock 271 156 557 minecraft:yellow_concrete
fill 272 156 557 273 161 557 minecraft:orange_terracotta
fill 272 156 558 274 156 558 minecraft:orange_concrete
fill 273 156 599 274 157 599 minecraft:yellow_concrete
fill 274 156 557 274 157 557 minecraft:yellow_concrete
fill 274 156 598 276 156 598 minecraft:orange_concrete
fill 275 156 599 276 161 599 minecraft:orange_terracotta
fill 276 156 558 276 156 560 minecraft:orange_concrete
fill 276 156 562 276 156 564 minecraft:orange_concrete
fill 276 156 566 276 156 568 minecraft:orange_concrete
fill 276 156 570 276 156 572 minecraft:orange_concrete
fill 276 156 574 276 156 576 minecraft:orange_concrete
fill 276 156 578 276 156 580 minecraft:orange_concrete
fill 276 156 582 276 156 584 minecraft:orange_concrete
fill 276 156 586 276 156 588 minecraft:orange_concrete
fill 276 156 590 276 156 592 minecraft:orange_concrete
fill 276 156 594 276 156 596 minecraft:orange_concrete
fill 277 156 560 277 161 561 minecraft:orange_terracotta
fill 277 156 562 277 156 563 minecraft:yellow_concrete
fill 277 156 572 277 161 573 minecraft:orange_terracotta
fill 277 156 574 277 157 575 minecraft:yellow_concrete
fill 277 156 581 277 161 581 minecraft:orange_terracotta
fill 277 156 582 277 156 583 minecraft:yellow_concrete
fill 277 156 584 277 161 584 minecraft:orange_terracotta
fill 277 156 586 277 157 586 minecraft:yellow_concrete
fill 277 156 592 277 161 593 minecraft:orange_terracotta
fill 277 156 594 277 157 595 minecraft:yellow_concrete
setblock 277 156 599 minecraft:yellow_concrete
fill 235 157 557 235 160 557 minecraft:orange_terracotta
fill 235 157 561 235 159 561 minecraft:orange_terracotta
setblock 235 157 562 minecraft:yellow_concrete
setblock 235 157 573 minecraft:yellow_concrete
fill 235 157 577 235 160 578 minecraft:orange_terracotta
setblock 235 157 594 minecraft:yellow_concrete
setblock 235 157 597 minecraft:yellow_concrete
fill 235 157 598 235 160 598 minecraft:orange_terracotta
fill 239 157 557 239 159 557 minecraft:orange_terracotta
setblock 241 157 599 minecraft:yellow_concrete
fill 245 157 599 245 160 599 minecraft:orange_terracotta
fill 250 157 557 250 160 557 minecraft:orange_terracotta
setblock 251 157 557 minecraft:yellow_concrete
fill 254 157 557 255 157 557 minecraft:yellow_concrete
fill 261 157 599 262 157 599 minecraft:yellow_concrete
setblock 265 157 599 minecraft:yellow_concrete
fill 266 157 599 266 160 599 minecraft:orange_terracotta
fill 271 157 557 271 160 557 minecraft:orange_terracotta
setblock 275 157 557 minecraft:yellow_concrete
fill 277 157 562 277 160 562 minecraft:orange_terracotta
setblock 277 157 563 minecraft:yellow_concrete
setblock 277 157 566 minecraft:yellow_concrete
fill 277 157 582 277 160 583 minecraft:orange_terracotta
setblock 277 157 587 minecraft:yellow_concrete
setblock 277 157 598 minecraft:yellow_concrete
fill 277 157 599 277 160 599 minecraft:orange_terracotta
fill 235 158 562 235 159 562 minecraft:orange_terracotta
fill 235 158 563 235 158 564 minecraft:yellow_concrete
fill 235 158 565 235 175 566 minecraft:orange_terracotta
fill 235 158 571 235 159 572 minecraft:yellow_concrete
fill 235 158 573 235 176 574 minecraft:orange_terracotta
setblock 235 158 575 minecraft:yellow_concrete
fill 235 158 583 235 159 584 minecraft:yellow_concrete
fill 235 158 585 235 175 586 minecraft:orange_terracotta
fill 235 158 592 235 159 592 minecraft:yellow_concrete
fill 235 158 594 235 179 594 minecraft:orange_terracotta
fill 235 158 595 235 158 596 minecraft:yellow_concrete
fill 235 158 597 235 175 597 minecraft:orange_terracotta
fill 236 158 557 236 159 557 minecraft:yellow_concrete
setblock 237 158 557 minecraft:orange_terracotta
fill 239 158 599 240 159 599 minecraft:yellow_concrete
fill 241 158 599 242 176 599 minecraft:orange_terracotta
fill 242 158 557 243 175 557 minecraft:orange_terracotta
fill 244 158 557 245 159 557 minecraft:yellow_concrete
fill 251 158 557 251 175 557 minecraft:orange_terracotta
fill 251 158 599 252 158 599 minecraft:yellow_concrete
setblock 253 158 557 minecraft:yellow_concrete
fill 253 158 599 254 175 599 minecraft:orange_terracotta
fill 254 158 557 255 176 557 minecraft:orange_terracotta
fill 256 158 557 256 159 557 minecraft:yellow_concrete
fill 260 158 599 260 159 599 minecraft:yellow_concrete
fill 261 158 599 262 179 599 minecraft:orange_terracotta
fill 262 158 557 263 175 557 minecraft:orange_terracotta
setblock 263 158 599 minecraft:yellow_concrete
fill 264 158 557 265 158 557 minecraft:yellow_concrete
fill 265 158 599 265 175 599 minecraft:orange_terracotta
fill 271 158 599 272 159 599 minecraft:yellow_concrete
fill 273 158 599 274 176 599 minecraft:orange_terracotta
fill 274 158 557 275 176 557 minecraft:orange_terracotta
fill 276 158 557 277 159 557 minecraft:yellow_concrete
fill 277 158 563 277 175 563 minecraft:orange_terracotta
fill 277 158 564 277 158 565 minecraft:yellow_concrete
fill 277 158 566 277 179 566 minecraft:orange_terracotta
fill 277 158 568 277 159 568 minecraft:yellow_concrete
fill 277 158 574 277 175 575 minecraft:orange_terracotta
fill 277 158 576 277 159 577 minecraft:yellow_concrete
setblock 277 158 585 minecraft:yellow_concrete
fill 277 158 586 277 176 587 minecraft:orange_terracotta
fill 277 158 588 277 159 589 minecraft:yellow_concrete
fill 277 158 594 277 175 595 minecraft:orange_terracotta
fill 277 158 596 277 158 597 minecraft:yellow_concrete
fill 277 158 598 277 179 598 minecraft:orange_terracotta
fill 235 159 559 235 159 560 minecraft:yellow_concrete
setblock 235 159 563 minecraft:yellow_concrete
fill 235 159 564 235 162 564 minecraft:orange_terracotta
schedule function dropper:buildpart/137_3 1t
