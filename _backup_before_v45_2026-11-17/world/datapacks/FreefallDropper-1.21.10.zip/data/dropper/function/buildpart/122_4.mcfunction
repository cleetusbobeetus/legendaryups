setblock 95 102 541 minecraft:smooth_basalt
fill 95 102 542 95 105 542 minecraft:blackstone
setblock 95 102 546 minecraft:smooth_basalt
fill 95 102 547 95 105 547 minecraft:blackstone
setblock 95 102 551 minecraft:smooth_basalt
fill 96 102 511 96 105 511 minecraft:blackstone
setblock 96 102 525 minecraft:smooth_basalt
fill 96 102 526 96 105 526 minecraft:blackstone
setblock 96 102 530 minecraft:smooth_basalt
fill 96 102 531 96 105 531 minecraft:blackstone
setblock 96 102 535 minecraft:smooth_basalt
fill 96 102 536 96 105 536 minecraft:blackstone
setblock 96 102 540 minecraft:smooth_basalt
fill 96 102 541 96 104 541 minecraft:blackstone
setblock 96 102 545 minecraft:smooth_basalt
fill 96 102 546 96 104 546 minecraft:blackstone
setblock 96 102 550 minecraft:smooth_basalt
fill 96 102 551 96 105 551 minecraft:blackstone
setblock 97 102 525 minecraft:blackstone
setblock 97 102 529 minecraft:smooth_basalt
fill 97 102 530 97 105 530 minecraft:blackstone
setblock 97 102 534 minecraft:smooth_basalt
fill 97 102 535 97 105 535 minecraft:blackstone
setblock 97 102 545 minecraft:blackstone
setblock 97 102 549 minecraft:smooth_basalt
fill 97 102 550 97 105 550 minecraft:blackstone
setblock 98 102 528 minecraft:smooth_basalt
fill 98 102 529 98 103 529 minecraft:blackstone
setblock 98 102 549 minecraft:blackstone
fill 100 102 510 100 201 510 minecraft:blackstone
setblock 100 102 511 minecraft:smooth_basalt
setblock 100 102 551 minecraft:smooth_basalt
fill 100 102 552 100 198 552 minecraft:blackstone
fill 101 102 511 101 103 511 minecraft:blackstone
setblock 101 102 550 minecraft:smooth_basalt
fill 101 102 551 101 104 551 minecraft:blackstone
setblock 110 102 511 minecraft:smooth_basalt
fill 111 102 511 114 102 511 minecraft:blackstone
fill 111 102 551 114 102 551 minecraft:blackstone
fill 112 102 512 113 102 512 minecraft:blackstone
fill 113 102 550 115 102 550 minecraft:blackstone
setblock 114 102 512 minecraft:smooth_basalt
setblock 115 102 511 minecraft:smooth_basalt
fill 115 102 512 115 104 513 minecraft:blackstone
setblock 115 102 551 minecraft:smooth_basalt
fill 116 102 511 116 105 511 minecraft:blackstone
setblock 116 102 550 minecraft:smooth_basalt
fill 116 102 551 116 105 551 minecraft:blackstone
setblock 117 102 549 minecraft:smooth_basalt
fill 117 102 550 117 105 550 minecraft:blackstone
setblock 118 102 513 minecraft:smooth_basalt
setblock 118 102 549 minecraft:blackstone
setblock 119 102 512 minecraft:smooth_basalt
fill 119 102 513 119 105 513 minecraft:blackstone
setblock 120 102 511 minecraft:smooth_basalt
fill 120 102 512 120 105 512 minecraft:blackstone
setblock 120 102 551 minecraft:smooth_basalt
fill 121 102 511 121 105 511 minecraft:blackstone
setblock 121 102 550 minecraft:smooth_basalt
fill 121 102 551 121 105 551 minecraft:blackstone
fill 122 102 550 125 102 550 minecraft:blackstone
setblock 124 102 512 minecraft:smooth_basalt
setblock 125 102 511 minecraft:smooth_basalt
setblock 125 102 551 minecraft:smooth_basalt
fill 126 102 511 126 105 511 minecraft:blackstone
setblock 126 102 550 minecraft:smooth_basalt
fill 126 102 551 126 105 551 minecraft:blackstone
fill 127 102 550 127 103 550 minecraft:blackstone
setblock 130 102 511 minecraft:smooth_basalt
setblock 130 102 551 minecraft:smooth_basalt
fill 131 102 511 131 105 511 minecraft:blackstone
setblock 131 102 550 minecraft:smooth_basalt
fill 131 102 551 131 105 551 minecraft:blackstone
setblock 132 102 549 minecraft:smooth_basalt
fill 132 102 550 132 105 550 minecraft:blackstone
setblock 133 102 548 minecraft:smooth_basalt
fill 133 102 549 133 105 549 minecraft:blackstone
setblock 134 102 511 minecraft:blackstone
setblock 134 102 512 minecraft:smooth_basalt
setblock 134 102 527 minecraft:smooth_basalt
fill 134 102 528 134 104 528 minecraft:blackstone
setblock 134 102 531 minecraft:blackstone
setblock 134 102 532 minecraft:smooth_basalt
fill 134 102 533 134 105 533 minecraft:blackstone
fill 134 102 543 134 104 543 minecraft:blackstone
setblock 134 102 547 minecraft:smooth_basalt
fill 134 102 548 134 105 548 minecraft:blackstone
setblock 135 102 511 minecraft:smooth_basalt
fill 135 102 512 135 105 512 minecraft:blackstone
setblock 135 102 526 minecraft:smooth_basalt
fill 135 102 527 135 105 527 minecraft:blackstone
setblock 135 102 531 minecraft:smooth_basalt
fill 135 102 532 135 105 532 minecraft:blackstone
setblock 135 102 536 minecraft:smooth_basalt
fill 135 102 537 135 105 537 minecraft:blackstone
setblock 135 102 541 minecraft:smooth_basalt
fill 135 102 542 135 105 542 minecraft:blackstone
setblock 135 102 546 minecraft:smooth_basalt
fill 135 102 547 135 105 547 minecraft:blackstone
setblock 135 102 551 minecraft:smooth_basalt
fill 136 102 536 136 201 536 minecraft:blackstone
fill 136 102 546 136 199 546 minecraft:blackstone
fill 94 103 540 94 201 540 minecraft:blackstone
fill 95 103 511 95 106 511 minecraft:blackstone
setblock 95 103 514 minecraft:blackstone
setblock 95 103 525 minecraft:smooth_basalt
fill 95 103 526 95 106 526 minecraft:blackstone
setblock 95 103 530 minecraft:smooth_basalt
fill 95 103 531 95 106 531 minecraft:blackstone
setblock 95 103 535 minecraft:smooth_basalt
fill 95 103 536 95 106 536 minecraft:blackstone
setblock 95 103 540 minecraft:smooth_basalt
fill 95 103 541 95 106 541 minecraft:blackstone
setblock 95 103 545 minecraft:smooth_basalt
fill 95 103 546 95 106 546 minecraft:blackstone
setblock 95 103 550 minecraft:smooth_basalt
fill 95 103 551 95 106 551 minecraft:blackstone
setblock 96 103 524 minecraft:smooth_basalt
fill 96 103 525 96 105 525 minecraft:blackstone
setblock 96 103 529 minecraft:smooth_basalt
fill 96 103 530 96 106 530 minecraft:blackstone
setblock 96 103 534 minecraft:smooth_basalt
fill 96 103 535 96 106 535 minecraft:blackstone
setblock 96 103 539 minecraft:smooth_basalt
fill 96 103 540 96 106 540 minecraft:blackstone
setblock 96 103 544 minecraft:smooth_basalt
fill 96 103 545 96 104 545 minecraft:blackstone
setblock 96 103 549 minecraft:smooth_basalt
fill 96 103 550 96 106 550 minecraft:blackstone
setblock 97 103 528 minecraft:smooth_basalt
fill 97 103 529 97 106 529 minecraft:blackstone
setblock 97 103 533 minecraft:smooth_basalt
fill 97 103 534 97 106 534 minecraft:blackstone
setblock 97 103 548 minecraft:smooth_basalt
setblock 97 103 549 minecraft:blackstone
setblock 98 103 532 minecraft:smooth_basalt
setblock 99 103 511 minecraft:smooth_basalt
setblock 99 103 551 minecraft:smooth_basalt
fill 100 103 511 100 106 511 minecraft:blackstone
setblock 100 103 550 minecraft:smooth_basalt
fill 100 103 551 100 105 551 minecraft:blackstone
setblock 109 103 511 minecraft:smooth_basalt
fill 110 103 511 113 103 511 minecraft:blackstone
fill 111 103 551 113 103 551 minecraft:blackstone
setblock 112 103 512 minecraft:blackstone
setblock 113 103 512 minecraft:smooth_basalt
fill 113 103 550 114 103 550 minecraft:blackstone
setblock 114 103 511 minecraft:smooth_basalt
fill 114 103 512 114 106 512 minecraft:blackstone
setblock 114 103 551 minecraft:smooth_basalt
fill 115 103 511 115 106 511 minecraft:blackstone
setblock 115 103 550 minecraft:smooth_basalt
fill 115 103 551 115 106 551 minecraft:blackstone
fill 116 103 550 116 106 550 minecraft:blackstone
setblock 117 103 513 minecraft:smooth_basalt
setblock 118 103 512 minecraft:smooth_basalt
fill 118 103 513 118 106 513 minecraft:blackstone
setblock 119 103 511 minecraft:smooth_basalt
fill 119 103 512 119 106 512 minecraft:blackstone
setblock 119 103 551 minecraft:smooth_basalt
fill 120 103 511 120 106 511 minecraft:blackstone
setblock 120 103 550 minecraft:smooth_basalt
fill 120 103 551 120 106 551 minecraft:blackstone
fill 121 103 550 124 103 550 minecraft:blackstone
setblock 123 103 512 minecraft:smooth_basalt
setblock 124 103 511 minecraft:smooth_basalt
setblock 124 103 551 minecraft:smooth_basalt
fill 125 103 511 125 106 511 minecraft:blackstone
setblock 125 103 550 minecraft:smooth_basalt
fill 125 103 551 125 106 551 minecraft:blackstone
setblock 126 103 550 minecraft:blackstone
setblock 129 103 511 minecraft:smooth_basalt
setblock 129 103 551 minecraft:smooth_basalt
fill 130 103 511 130 106 511 minecraft:blackstone
setblock 130 103 550 minecraft:smooth_basalt
fill 130 103 551 130 106 551 minecraft:blackstone
setblock 131 103 549 minecraft:smooth_basalt
fill 131 103 550 131 106 550 minecraft:blackstone
setblock 132 103 512 minecraft:blackstone
fill 132 103 549 132 106 549 minecraft:blackstone
setblock 133 103 512 minecraft:smooth_basalt
setblock 133 103 547 minecraft:smooth_basalt
fill 133 103 548 133 106 548 minecraft:blackstone
setblock 134 103 511 minecraft:smooth_basalt
fill 134 103 512 134 106 512 minecraft:blackstone
setblock 134 103 530 minecraft:blackstone
setblock 134 103 531 minecraft:smooth_basalt
fill 134 103 532 134 106 532 minecraft:blackstone
fill 134 103 534 134 104 534 minecraft:blackstone
setblock 134 103 546 minecraft:smooth_basalt
fill 134 103 547 134 106 547 minecraft:blackstone
setblock 134 103 551 minecraft:smooth_basalt
fill 135 103 511 135 106 511 minecraft:blackstone
setblock 135 103 515 minecraft:smooth_basalt
setblock 135 103 525 minecraft:smooth_basalt
fill 135 103 526 135 106 526 minecraft:blackstone
setblock 135 103 530 minecraft:smooth_basalt
fill 135 103 531 135 106 531 minecraft:blackstone
setblock 135 103 535 minecraft:smooth_basalt
fill 135 103 536 135 106 536 minecraft:blackstone
setblock 135 103 540 minecraft:smooth_basalt
fill 135 103 541 135 106 541 minecraft:blackstone
setblock 135 103 545 minecraft:smooth_basalt
fill 135 103 546 135 106 546 minecraft:blackstone
setblock 135 103 550 minecraft:smooth_basalt
fill 135 103 551 135 106 551 minecraft:blackstone
setblock 95 104 514 minecraft:smooth_basalt
setblock 95 104 524 minecraft:smooth_basalt
fill 95 104 525 95 107 525 minecraft:blackstone
setblock 95 104 529 minecraft:smooth_basalt
fill 95 104 530 95 107 530 minecraft:blackstone
setblock 95 104 534 minecraft:smooth_basalt
fill 95 104 535 95 107 535 minecraft:blackstone
setblock 95 104 539 minecraft:smooth_basalt
fill 95 104 540 95 107 540 minecraft:blackstone
setblock 95 104 544 minecraft:smooth_basalt
fill 95 104 545 95 107 545 minecraft:blackstone
setblock 95 104 549 minecraft:smooth_basalt
fill 95 104 550 95 107 550 minecraft:blackstone
setblock 96 104 528 minecraft:smooth_basalt
fill 96 104 529 96 107 529 minecraft:blackstone
setblock 96 104 533 minecraft:smooth_basalt
fill 96 104 534 96 107 534 minecraft:blackstone
setblock 96 104 538 minecraft:smooth_basalt
fill 96 104 539 96 107 539 minecraft:blackstone
setblock 96 104 543 minecraft:smooth_basalt
setblock 96 104 544 minecraft:blackstone
setblock 96 104 548 minecraft:smooth_basalt
fill 96 104 549 96 106 549 minecraft:blackstone
setblock 97 104 513 minecraft:light[level=12]
setblock 97 104 521 minecraft:light[level=12]
setblock 97 104 527 minecraft:smooth_basalt
fill 97 104 528 97 106 528 minecraft:blackstone
setblock 97 104 532 minecraft:smooth_basalt
fill 97 104 533 97 107 533 minecraft:blackstone
setblock 97 104 537 minecraft:light[level=12]
setblock 97 104 545 minecraft:light[level=12]
setblock 98 104 511 minecraft:smooth_basalt
setblock 98 104 551 minecraft:smooth_basalt
fill 99 104 511 99 107 511 minecraft:blackstone
fill 99 104 551 99 106 551 minecraft:blackstone
setblock 105 104 513 minecraft:light[level=12]
setblock 105 104 521 minecraft:light[level=12]
setblock 105 104 529 minecraft:light[level=12]
setblock 105 104 537 minecraft:light[level=12]
setblock 105 104 545 minecraft:light[level=12]
fill 109 104 511 112 104 511 minecraft:blackstone
setblock 111 104 512 minecraft:blackstone
fill 111 104 551 112 104 551 minecraft:blackstone
setblock 112 104 512 minecraft:smooth_basalt
setblock 113 104 511 minecraft:smooth_basalt
fill 113 104 512 113 107 512 minecraft:blackstone
setblock 113 104 513 minecraft:light[level=12]
setblock 113 104 521 minecraft:light[level=12]
setblock 113 104 529 minecraft:light[level=12]
setblock 113 104 537 minecraft:light[level=12]
setblock 113 104 545 minecraft:light[level=12]
setblock 113 104 551 minecraft:smooth_basalt
fill 114 104 511 114 107 511 minecraft:blackstone
fill 114 104 513 114 105 513 minecraft:blackstone
setblock 114 104 550 minecraft:smooth_basalt
fill 114 104 551 114 107 551 minecraft:blackstone
fill 115 104 550 115 107 550 minecraft:blackstone
setblock 116 104 513 minecraft:smooth_basalt
setblock 117 104 512 minecraft:smooth_basalt
fill 117 104 513 117 107 513 minecraft:blackstone
setblock 118 104 511 minecraft:smooth_basalt
fill 118 104 512 118 107 512 minecraft:blackstone
setblock 118 104 551 minecraft:smooth_basalt
fill 119 104 511 119 107 511 minecraft:blackstone
setblock 119 104 550 minecraft:smooth_basalt
fill 119 104 551 119 107 551 minecraft:blackstone
fill 120 104 550 122 104 550 minecraft:blackstone
setblock 121 104 513 minecraft:light[level=12]
setblock 121 104 521 minecraft:light[level=12]
setblock 121 104 529 minecraft:light[level=12]
setblock 121 104 537 minecraft:light[level=12]
setblock 121 104 545 minecraft:light[level=12]
setblock 122 104 512 minecraft:smooth_basalt
setblock 123 104 511 minecraft:smooth_basalt
fill 123 104 512 123 107 512 minecraft:blackstone
setblock 123 104 551 minecraft:smooth_basalt
fill 124 104 511 124 107 511 minecraft:blackstone
fill 124 104 551 124 107 551 minecraft:blackstone
setblock 128 104 511 minecraft:smooth_basalt
setblock 128 104 551 minecraft:smooth_basalt
fill 129 104 511 129 107 511 minecraft:blackstone
setblock 129 104 513 minecraft:light[level=12]
setblock 129 104 521 minecraft:light[level=12]
setblock 129 104 529 minecraft:light[level=12]
setblock 129 104 537 minecraft:light[level=12]
setblock 129 104 545 minecraft:light[level=12]
setblock 129 104 550 minecraft:smooth_basalt
fill 129 104 551 129 107 551 minecraft:blackstone
fill 130 104 550 130 107 550 minecraft:blackstone
setblock 132 104 512 minecraft:smooth_basalt
setblock 133 104 511 minecraft:smooth_basalt
fill 133 104 512 133 107 512 minecraft:blackstone
setblock 133 104 551 minecraft:smooth_basalt
fill 134 104 511 134 107 511 minecraft:blackstone
fill 134 104 513 134 105 513 minecraft:blackstone
setblock 134 104 530 minecraft:smooth_basalt
fill 134 104 531 134 107 531 minecraft:blackstone
setblock 134 104 535 minecraft:smooth_basalt
fill 134 104 536 134 107 536 minecraft:blackstone
setblock 134 104 545 minecraft:smooth_basalt
fill 134 104 546 134 107 546 minecraft:blackstone
setblock 134 104 550 minecraft:smooth_basalt
fill 134 104 551 134 107 551 minecraft:blackstone
setblock 135 104 514 minecraft:smooth_basalt
fill 135 104 515 135 107 515 minecraft:blackstone
setblock 135 104 525 minecraft:blackstone
setblock 135 104 529 minecraft:smooth_basalt
fill 135 104 530 135 107 530 minecraft:blackstone
setblock 135 104 534 minecraft:smooth_basalt
fill 135 104 535 135 107 535 minecraft:blackstone
setblock 135 104 539 minecraft:smooth_basalt
fill 135 104 540 135 107 540 minecraft:blackstone
setblock 135 104 544 minecraft:smooth_basalt
fill 135 104 545 135 107 545 minecraft:blackstone
setblock 135 104 549 minecraft:smooth_basalt
fill 135 104 550 135 107 550 minecraft:blackstone
setblock 95 105 513 minecraft:smooth_basalt
fill 95 105 514 95 107 515 minecraft:blackstone
setblock 95 105 523 minecraft:smooth_basalt
fill 95 105 524 95 108 524 minecraft:blackstone
setblock 95 105 528 minecraft:smooth_basalt
fill 95 105 529 95 108 529 minecraft:blackstone
setblock 95 105 533 minecraft:smooth_basalt
fill 95 105 534 95 108 534 minecraft:blackstone
setblock 95 105 538 minecraft:smooth_basalt
fill 95 105 539 95 108 539 minecraft:blackstone
setblock 95 105 543 minecraft:smooth_basalt
fill 95 105 544 95 108 544 minecraft:blackstone
setblock 95 105 548 minecraft:smooth_basalt
fill 95 105 549 95 108 549 minecraft:blackstone
setblock 96 105 527 minecraft:smooth_basalt
fill 96 105 528 96 108 528 minecraft:blackstone
setblock 96 105 532 minecraft:smooth_basalt
fill 96 105 533 96 108 533 minecraft:blackstone
setblock 96 105 537 minecraft:smooth_basalt
fill 96 105 538 96 108 538 minecraft:blackstone
setblock 96 105 547 minecraft:smooth_basalt
setblock 96 105 548 minecraft:blackstone
setblock 97 105 511 minecraft:smooth_basalt
setblock 97 105 531 minecraft:smooth_basalt
fill 97 105 532 97 108 532 minecraft:blackstone
setblock 97 105 536 minecraft:smooth_basalt
setblock 97 105 551 minecraft:smooth_basalt
fill 98 105 511 98 108 511 minecraft:blackstone
fill 98 105 551 98 108 551 minecraft:blackstone
fill 108 105 511 111 105 511 minecraft:blackstone
setblock 110 105 512 minecraft:blackstone
fill 110 105 551 111 105 551 minecraft:blackstone
setblock 111 105 512 minecraft:smooth_basalt
setblock 112 105 511 minecraft:smooth_basalt
fill 112 105 512 112 108 512 minecraft:blackstone
setblock 112 105 551 minecraft:smooth_basalt
fill 113 105 511 113 108 511 minecraft:blackstone
fill 113 105 513 113 106 513 minecraft:blackstone
fill 113 105 551 113 108 551 minecraft:blackstone
fill 114 105 550 114 108 550 minecraft:blackstone
setblock 115 105 512 minecraft:blackstone
setblock 115 105 513 minecraft:smooth_basalt
setblock 116 105 512 minecraft:smooth_basalt
fill 116 105 513 116 108 513 minecraft:blackstone
setblock 117 105 511 minecraft:smooth_basalt
fill 117 105 512 117 108 512 minecraft:blackstone
setblock 117 105 551 minecraft:smooth_basalt
fill 118 105 511 118 108 511 minecraft:blackstone
setblock 118 105 550 minecraft:smooth_basalt
fill 118 105 551 118 108 551 minecraft:blackstone
fill 119 105 550 121 105 550 minecraft:blackstone
setblock 121 105 512 minecraft:smooth_basalt
setblock 122 105 511 minecraft:smooth_basalt
fill 122 105 512 122 108 512 minecraft:blackstone
setblock 122 105 551 minecraft:smooth_basalt
fill 123 105 511 123 108 511 minecraft:blackstone
fill 123 105 551 123 108 551 minecraft:blackstone
setblock 127 105 511 minecraft:smooth_basalt
setblock 127 105 551 minecraft:smooth_basalt
fill 128 105 511 128 108 511 minecraft:blackstone
setblock 128 105 550 minecraft:smooth_basalt
fill 128 105 551 128 108 551 minecraft:blackstone
fill 129 105 550 129 108 550 minecraft:blackstone
setblock 131 105 512 minecraft:smooth_basalt
setblock 132 105 511 minecraft:smooth_basalt
fill 132 105 512 132 108 512 minecraft:blackstone
setblock 132 105 551 minecraft:smooth_basalt
fill 133 105 511 133 108 511 minecraft:blackstone
setblock 133 105 550 minecraft:smooth_basalt
fill 133 105 551 133 108 551 minecraft:blackstone
setblock 134 105 529 minecraft:smooth_basalt
fill 134 105 530 134 108 530 minecraft:blackstone
setblock 134 105 534 minecraft:smooth_basalt
fill 134 105 535 134 108 535 minecraft:blackstone
fill 134 105 537 134 105 538 minecraft:blackstone
setblock 134 105 544 minecraft:smooth_basalt
fill 134 105 545 134 108 545 minecraft:blackstone
setblock 134 105 549 minecraft:smooth_basalt
fill 134 105 550 134 108 550 minecraft:blackstone
setblock 135 105 513 minecraft:smooth_basalt
fill 135 105 514 135 108 514 minecraft:blackstone
setblock 135 105 528 minecraft:smooth_basalt
fill 135 105 529 135 108 529 minecraft:blackstone
setblock 135 105 533 minecraft:smooth_basalt
fill 135 105 534 135 108 534 minecraft:blackstone
setblock 135 105 538 minecraft:smooth_basalt
fill 135 105 539 135 108 539 minecraft:blackstone
setblock 135 105 543 minecraft:smooth_basalt
fill 135 105 544 135 108 544 minecraft:blackstone
setblock 135 105 548 minecraft:smooth_basalt
fill 135 105 549 135 108 549 minecraft:blackstone
setblock 95 106 512 minecraft:smooth_basalt
fill 95 106 513 95 109 513 minecraft:blackstone
setblock 95 106 516 minecraft:blackstone
fill 95 106 523 95 109 523 minecraft:blackstone
setblock 95 106 527 minecraft:smooth_basalt
fill 95 106 528 95 109 528 minecraft:blackstone
setblock 95 106 532 minecraft:smooth_basalt
fill 95 106 533 95 109 533 minecraft:blackstone
setblock 95 106 537 minecraft:smooth_basalt
fill 95 106 538 95 109 538 minecraft:blackstone
setblock 95 106 542 minecraft:smooth_basalt
fill 95 106 543 95 109 543 minecraft:blackstone
setblock 95 106 547 minecraft:smooth_basalt
fill 95 106 548 95 109 548 minecraft:blackstone
setblock 96 106 511 minecraft:smooth_basalt
setblock 96 106 526 minecraft:smooth_basalt
fill 96 106 527 96 109 527 minecraft:blackstone
setblock 96 106 531 minecraft:smooth_basalt
fill 96 106 532 96 109 532 minecraft:blackstone
setblock 96 106 536 minecraft:smooth_basalt
fill 96 106 537 96 109 537 minecraft:blackstone
setblock 96 106 551 minecraft:smooth_basalt
fill 97 106 511 97 109 511 minecraft:blackstone
setblock 97 106 530 minecraft:smooth_basalt
fill 97 106 531 97 109 531 minecraft:blackstone
setblock 97 106 535 minecraft:smooth_basalt
fill 97 106 536 97 109 536 minecraft:blackstone
fill 97 106 551 97 109 551 minecraft:blackstone
fill 107 106 511 110 106 511 minecraft:blackstone
setblock 109 106 512 minecraft:blackstone
setblock 110 106 512 minecraft:smooth_basalt
setblock 110 106 551 minecraft:blackstone
setblock 111 106 511 minecraft:smooth_basalt
fill 111 106 512 111 109 512 minecraft:blackstone
setblock 111 106 551 minecraft:smooth_basalt
fill 112 106 511 112 109 511 minecraft:blackstone
fill 112 106 513 112 107 513 minecraft:blackstone
fill 112 106 551 112 109 551 minecraft:blackstone
fill 113 106 550 113 109 550 minecraft:blackstone
setblock 114 106 513 minecraft:smooth_basalt
setblock 115 106 512 minecraft:smooth_basalt
fill 115 106 513 115 109 513 minecraft:blackstone
setblock 116 106 511 minecraft:smooth_basalt
fill 116 106 512 116 109 512 minecraft:blackstone
setblock 116 106 551 minecraft:smooth_basalt
fill 117 106 511 117 109 511 minecraft:blackstone
setblock 117 106 550 minecraft:smooth_basalt
fill 117 106 551 117 109 551 minecraft:blackstone
fill 118 106 550 119 106 550 minecraft:blackstone
setblock 119 106 513 minecraft:smooth_basalt
setblock 120 106 512 minecraft:smooth_basalt
setblock 121 106 511 minecraft:smooth_basalt
fill 121 106 512 121 109 512 minecraft:blackstone
setblock 121 106 551 minecraft:smooth_basalt
fill 122 106 511 122 109 511 minecraft:blackstone
fill 122 106 551 122 109 551 minecraft:blackstone
setblock 126 106 511 minecraft:smooth_basalt
setblock 126 106 551 minecraft:smooth_basalt
fill 127 106 511 127 109 511 minecraft:blackstone
fill 127 106 551 127 109 551 minecraft:blackstone
fill 128 106 550 128 109 550 minecraft:blackstone
setblock 129 106 512 minecraft:blackstone
setblock 130 106 512 minecraft:smooth_basalt
setblock 131 106 511 minecraft:smooth_basalt
fill 131 106 512 131 109 512 minecraft:blackstone
setblock 131 106 551 minecraft:smooth_basalt
fill 132 106 511 132 109 511 minecraft:blackstone
setblock 132 106 550 minecraft:smooth_basalt
fill 132 106 551 132 109 551 minecraft:blackstone
setblock 133 106 549 minecraft:smooth_basalt
fill 133 106 550 133 109 550 minecraft:blackstone
setblock 134 106 513 minecraft:smooth_basalt
fill 134 106 529 134 109 529 minecraft:blackstone
setblock 134 106 533 minecraft:smooth_basalt
fill 134 106 534 134 109 534 minecraft:blackstone
setblock 134 106 537 minecraft:blackstone
setblock 134 106 538 minecraft:smooth_basalt
fill 134 106 539 134 106 542 minecraft:blackstone
setblock 134 106 543 minecraft:smooth_basalt
fill 134 106 544 134 109 544 minecraft:blackstone
setblock 134 106 548 minecraft:smooth_basalt
fill 134 106 549 134 109 549 minecraft:blackstone
setblock 135 106 512 minecraft:smooth_basalt
fill 135 106 513 135 109 513 minecraft:blackstone
setblock 135 106 516 minecraft:blackstone
setblock 135 106 527 minecraft:smooth_basalt
fill 135 106 528 135 109 528 minecraft:blackstone
setblock 135 106 532 minecraft:smooth_basalt
fill 135 106 533 135 109 533 minecraft:blackstone
setblock 135 106 537 minecraft:smooth_basalt
fill 135 106 538 135 109 538 minecraft:blackstone
setblock 135 106 542 minecraft:smooth_basalt
fill 135 106 543 135 109 543 minecraft:blackstone
setblock 135 106 547 minecraft:smooth_basalt
fill 135 106 548 135 109 548 minecraft:blackstone
setblock 95 107 511 minecraft:smooth_basalt
fill 95 107 512 96 109 512 minecraft:blackstone
setblock 95 107 516 minecraft:smooth_basalt
fill 95 107 517 95 110 517 minecraft:blackstone
setblock 95 107 526 minecraft:smooth_basalt
fill 95 107 527 95 110 527 minecraft:blackstone
setblock 95 107 531 minecraft:smooth_basalt
fill 95 107 532 95 110 532 minecraft:blackstone
setblock 95 107 536 minecraft:smooth_basalt
fill 95 107 537 95 110 537 minecraft:blackstone
setblock 95 107 541 minecraft:smooth_basalt
fill 95 107 542 95 110 542 minecraft:blackstone
setblock 95 107 546 minecraft:smooth_basalt
fill 95 107 547 95 110 547 minecraft:blackstone
setblock 95 107 551 minecraft:smooth_basalt
fill 96 107 511 96 110 511 minecraft:blackstone
fill 96 107 526 96 110 526 minecraft:blackstone
setblock 96 107 530 minecraft:smooth_basalt
fill 96 107 531 96 110 531 minecraft:blackstone
setblock 96 107 535 minecraft:smooth_basalt
fill 96 107 536 96 110 536 minecraft:blackstone
setblock 96 107 540 minecraft:smooth_basalt
fill 96 107 551 96 110 551 minecraft:blackstone
setblock 97 107 529 minecraft:smooth_basalt
fill 97 107 530 97 110 530 minecraft:blackstone
setblock 97 107 534 minecraft:smooth_basalt
fill 97 107 535 97 110 535 minecraft:blackstone
fill 97 107 537 97 108 537 minecraft:blackstone
setblock 100 107 511 minecraft:smooth_basalt
fill 106 107 511 109 107 511 minecraft:blackstone
setblock 108 107 512 minecraft:blackstone
setblock 109 107 512 minecraft:smooth_basalt
setblock 110 107 511 minecraft:smooth_basalt
fill 110 107 512 110 109 513 minecraft:blackstone
setblock 110 107 551 minecraft:smooth_basalt
fill 111 107 511 111 110 511 minecraft:blackstone
fill 111 107 513 111 108 513 minecraft:blackstone
fill 111 107 551 111 110 551 minecraft:blackstone
setblock 113 107 513 minecraft:smooth_basalt
setblock 114 107 512 minecraft:smooth_basalt
fill 114 107 513 114 109 514 minecraft:blackstone
setblock 115 107 511 minecraft:smooth_basalt
fill 115 107 512 115 110 512 minecraft:blackstone
fill 115 107 514 115 108 514 minecraft:blackstone
setblock 115 107 551 minecraft:smooth_basalt
fill 116 107 511 116 110 511 minecraft:blackstone
setblock 116 107 550 minecraft:smooth_basalt
fill 116 107 551 116 110 551 minecraft:blackstone
fill 117 107 550 118 108 550 minecraft:blackstone
setblock 118 107 513 minecraft:smooth_basalt
setblock 119 107 512 minecraft:smooth_basalt
fill 119 107 513 119 110 513 minecraft:blackstone
setblock 120 107 511 minecraft:smooth_basalt
fill 120 107 512 120 110 512 minecraft:blackstone
setblock 120 107 551 minecraft:smooth_basalt
fill 121 107 511 121 110 511 minecraft:blackstone
fill 121 107 551 121 110 551 minecraft:blackstone
setblock 125 107 511 minecraft:smooth_basalt
setblock 125 107 551 minecraft:smooth_basalt
fill 126 107 511 126 110 511 minecraft:blackstone
fill 126 107 551 126 110 551 minecraft:blackstone
setblock 128 107 512 minecraft:blackstone
setblock 129 107 512 minecraft:smooth_basalt
setblock 130 107 511 minecraft:smooth_basalt
fill 130 107 512 130 110 512 minecraft:blackstone
setblock 130 107 551 minecraft:smooth_basalt
fill 131 107 511 131 110 511 minecraft:blackstone
setblock 131 107 550 minecraft:smooth_basalt
fill 131 107 551 131 110 551 minecraft:blackstone
setblock 132 107 549 minecraft:smooth_basalt
fill 132 107 550 132 110 550 minecraft:blackstone
setblock 133 107 532 minecraft:blackstone
setblock 133 107 533 minecraft:smooth_basalt
fill 133 107 534 133 108 536 minecraft:blackstone
setblock 133 107 548 minecraft:smooth_basalt
fill 133 107 549 133 110 549 minecraft:blackstone
setblock 134 107 512 minecraft:smooth_basalt
fill 134 107 513 134 109 514 minecraft:blackstone
setblock 134 107 532 minecraft:smooth_basalt
fill 134 107 533 134 110 533 minecraft:blackstone
setblock 134 107 537 minecraft:smooth_basalt
fill 134 107 538 134 107 541 minecraft:blackstone
setblock 134 107 542 minecraft:smooth_basalt
fill 134 107 543 134 110 543 minecraft:blackstone
setblock 134 107 547 minecraft:smooth_basalt
fill 134 107 548 134 110 548 minecraft:blackstone
setblock 135 107 511 minecraft:smooth_basalt
fill 135 107 512 135 110 512 minecraft:blackstone
setblock 135 107 516 minecraft:smooth_basalt
fill 135 107 517 135 110 517 minecraft:blackstone
setblock 135 107 526 minecraft:smooth_basalt
fill 135 107 527 135 110 527 minecraft:blackstone
setblock 135 107 531 minecraft:smooth_basalt
fill 135 107 532 135 110 532 minecraft:blackstone
setblock 135 107 536 minecraft:smooth_basalt
fill 135 107 537 135 110 537 minecraft:blackstone
setblock 135 107 541 minecraft:smooth_basalt
fill 135 107 542 135 110 542 minecraft:blackstone
setblock 135 107 546 minecraft:smooth_basalt
fill 135 107 547 135 110 547 minecraft:blackstone
setblock 135 107 551 minecraft:smooth_basalt
fill 95 108 511 95 111 511 minecraft:blackstone
setblock 95 108 514 minecraft:blackstone
setblock 95 108 515 minecraft:smooth_basalt
fill 95 108 516 95 111 516 minecraft:blackstone
fill 95 108 518 95 108 519 minecraft:blackstone
setblock 95 108 520 minecraft:smooth_basalt
fill 95 108 521 95 110 522 minecraft:blackstone
setblock 95 108 525 minecraft:smooth_basalt
fill 95 108 526 95 111 526 minecraft:blackstone
setblock 95 108 530 minecraft:smooth_basalt
fill 95 108 531 95 111 531 minecraft:blackstone
setblock 95 108 535 minecraft:smooth_basalt
fill 95 108 536 95 111 536 minecraft:blackstone
setblock 95 108 540 minecraft:smooth_basalt
fill 95 108 541 96 110 541 minecraft:blackstone
setblock 95 108 545 minecraft:smooth_basalt
fill 95 108 546 95 111 546 minecraft:blackstone
setblock 95 108 550 minecraft:smooth_basalt
fill 95 108 551 95 111 551 minecraft:blackstone
setblock 96 108 513 minecraft:blackstone
setblock 96 108 514 minecraft:smooth_basalt
setblock 96 108 529 minecraft:smooth_basalt
fill 96 108 530 96 111 530 minecraft:blackstone
setblock 96 108 534 minecraft:smooth_basalt
fill 96 108 535 96 111 535 minecraft:blackstone
setblock 96 108 539 minecraft:smooth_basalt
fill 96 108 540 96 111 540 minecraft:blackstone
fill 97 108 529 97 109 529 minecraft:blackstone
setblock 97 108 533 minecraft:smooth_basalt
fill 97 108 534 97 111 534 minecraft:blackstone
setblock 99 108 511 minecraft:smooth_basalt
fill 100 108 511 100 111 511 minecraft:blackstone
setblock 104 108 511 minecraft:smooth_basalt
fill 105 108 511 108 108 511 minecraft:blackstone
setblock 107 108 512 minecraft:blackstone
setblock 108 108 512 minecraft:smooth_basalt
setblock 109 108 511 minecraft:smooth_basalt
fill 109 108 512 109 110 513 minecraft:blackstone
setblock 109 108 551 minecraft:smooth_basalt
fill 110 108 511 110 111 511 minecraft:blackstone
fill 110 108 551 110 111 551 minecraft:blackstone
setblock 112 108 513 minecraft:smooth_basalt
fill 112 108 514 113 110 514 minecraft:blackstone
setblock 113 108 512 minecraft:smooth_basalt
fill 113 108 513 113 111 513 minecraft:blackstone
setblock 114 108 511 minecraft:smooth_basalt
fill 114 108 512 114 111 512 minecraft:blackstone
setblock 114 108 551 minecraft:smooth_basalt
fill 115 108 511 115 111 511 minecraft:blackstone
setblock 115 108 550 minecraft:smooth_basalt
fill 115 108 551 115 111 551 minecraft:blackstone
setblock 116 108 514 minecraft:smooth_basalt
fill 116 108 550 116 111 550 minecraft:blackstone
setblock 117 108 513 minecraft:smooth_basalt
setblock 118 108 512 minecraft:smooth_basalt
fill 118 108 513 118 111 513 minecraft:blackstone
setblock 119 108 511 minecraft:smooth_basalt
fill 119 108 512 119 111 512 minecraft:blackstone
setblock 119 108 551 minecraft:smooth_basalt
fill 120 108 511 120 111 511 minecraft:blackstone
fill 120 108 551 120 111 551 minecraft:blackstone
setblock 123 108 512 minecraft:smooth_basalt
setblock 124 108 511 minecraft:smooth_basalt
fill 124 108 512 127 108 512 minecraft:blackstone
setblock 124 108 551 minecraft:smooth_basalt
fill 125 108 511 125 111 511 minecraft:blackstone
fill 125 108 551 125 111 551 minecraft:blackstone
fill 127 108 550 127 110 550 minecraft:blackstone
setblock 128 108 512 minecraft:smooth_basalt
setblock 129 108 511 minecraft:smooth_basalt
fill 129 108 512 129 111 512 minecraft:blackstone
setblock 129 108 551 minecraft:smooth_basalt
fill 130 108 511 130 111 511 minecraft:blackstone
setblock 130 108 550 minecraft:smooth_basalt
fill 130 108 551 130 111 551 minecraft:blackstone
fill 131 108 550 131 111 550 minecraft:blackstone
fill 132 108 549 132 111 549 minecraft:blackstone
setblock 133 108 512 minecraft:smooth_basalt
setblock 133 108 531 minecraft:blackstone
setblock 133 108 532 minecraft:smooth_basalt
fill 133 108 533 133 111 533 minecraft:blackstone
setblock 133 108 537 minecraft:smooth_basalt
fill 133 108 538 134 109 539 minecraft:blackstone
fill 133 108 548 133 111 548 minecraft:blackstone
setblock 134 108 511 minecraft:smooth_basalt
fill 134 108 512 134 111 512 minecraft:blackstone
setblock 134 108 515 minecraft:blackstone
setblock 134 108 531 minecraft:smooth_basalt
fill 134 108 532 134 111 532 minecraft:blackstone
setblock 134 108 536 minecraft:smooth_basalt
fill 134 108 537 134 111 537 minecraft:blackstone
setblock 134 108 540 minecraft:blackstone
setblock 134 108 541 minecraft:smooth_basalt
fill 134 108 542 134 111 542 minecraft:blackstone
setblock 134 108 546 minecraft:smooth_basalt
fill 134 108 547 134 111 547 minecraft:blackstone
setblock 134 108 551 minecraft:smooth_basalt
fill 135 108 511 135 111 511 minecraft:blackstone
setblock 135 108 515 minecraft:smooth_basalt
fill 135 108 516 135 111 516 minecraft:blackstone
fill 135 108 518 135 109 518 minecraft:blackstone
fill 135 108 526 135 111 526 minecraft:blackstone
setblock 135 108 530 minecraft:smooth_basalt
fill 135 108 531 135 111 531 minecraft:blackstone
setblock 135 108 535 minecraft:smooth_basalt
fill 135 108 536 135 111 536 minecraft:blackstone
setblock 135 108 540 minecraft:smooth_basalt
fill 135 108 541 135 111 541 minecraft:blackstone
setblock 135 108 545 minecraft:smooth_basalt
fill 135 108 546 135 111 546 minecraft:blackstone
setblock 135 108 550 minecraft:smooth_basalt
fill 135 108 551 135 111 551 minecraft:blackstone
setblock 95 109 514 minecraft:smooth_basalt
fill 95 109 515 96 111 515 minecraft:blackstone
setblock 95 109 518 minecraft:blackstone
setblock 95 109 519 minecraft:smooth_basalt
fill 95 109 520 95 112 520 minecraft:blackstone
setblock 95 109 524 minecraft:smooth_basalt
fill 95 109 525 95 112 525 minecraft:blackstone
setblock 95 109 529 minecraft:smooth_basalt
fill 95 109 530 95 112 530 minecraft:blackstone
setblock 95 109 534 minecraft:smooth_basalt
fill 95 109 535 95 112 535 minecraft:blackstone
setblock 95 109 539 minecraft:smooth_basalt
fill 95 109 540 95 112 540 minecraft:blackstone
setblock 95 109 544 minecraft:smooth_basalt
fill 95 109 545 95 112 545 minecraft:blackstone
setblock 95 109 549 minecraft:smooth_basalt
fill 95 109 550 95 112 550 minecraft:blackstone
setblock 96 109 513 minecraft:smooth_basalt
fill 96 109 514 96 112 514 minecraft:blackstone
fill 96 109 516 96 110 516 minecraft:blackstone
setblock 96 109 528 minecraft:smooth_basalt
fill 96 109 529 96 112 529 minecraft:blackstone
setblock 96 109 533 minecraft:smooth_basalt
fill 96 109 534 96 112 534 minecraft:blackstone
setblock 96 109 538 minecraft:smooth_basalt
fill 96 109 539 96 112 539 minecraft:blackstone
setblock 97 109 512 minecraft:smooth_basalt
setblock 97 109 532 minecraft:smooth_basalt
fill 97 109 533 97 112 533 minecraft:blackstone
setblock 97 109 537 minecraft:smooth_basalt
fill 97 109 538 97 112 538 minecraft:blackstone
setblock 98 109 511 minecraft:smooth_basalt
fill 99 109 511 99 112 511 minecraft:blackstone
fill 101 109 511 102 109 511 minecraft:blackstone
setblock 103 109 511 minecraft:smooth_basalt
fill 104 109 511 107 109 511 minecraft:blackstone
setblock 106 109 512 minecraft:blackstone
setblock 107 109 512 minecraft:smooth_basalt
setblock 108 109 511 minecraft:smooth_basalt
fill 108 109 512 108 111 513 minecraft:blackstone
setblock 108 109 551 minecraft:smooth_basalt
fill 109 109 511 109 112 511 minecraft:blackstone
fill 109 109 551 109 112 551 minecraft:blackstone
setblock 110 109 514 minecraft:smooth_basalt
setblock 111 109 513 minecraft:smooth_basalt
fill 111 109 514 111 112 514 minecraft:blackstone
setblock 112 109 512 minecraft:smooth_basalt
fill 112 109 513 112 112 513 minecraft:blackstone
fill 112 109 550 112 110 550 minecraft:blackstone
setblock 113 109 511 minecraft:smooth_basalt
fill 113 109 512 113 112 512 minecraft:blackstone
setblock 113 109 551 minecraft:smooth_basalt
fill 114 109 511 114 112 511 minecraft:blackstone
setblock 114 109 550 minecraft:smooth_basalt
fill 114 109 551 114 112 551 minecraft:blackstone
setblock 115 109 514 minecraft:smooth_basalt
fill 115 109 550 115 112 550 minecraft:blackstone
setblock 116 109 513 minecraft:smooth_basalt
fill 116 109 514 117 111 514 minecraft:blackstone
setblock 117 109 512 minecraft:smooth_basalt
fill 117 109 513 117 112 513 minecraft:blackstone
fill 117 109 550 117 110 550 minecraft:blackstone
setblock 118 109 511 minecraft:smooth_basalt
fill 118 109 512 118 112 512 minecraft:blackstone
setblock 118 109 551 minecraft:smooth_basalt
fill 119 109 511 119 112 511 minecraft:blackstone
fill 119 109 551 119 112 551 minecraft:blackstone
setblock 120 109 513 minecraft:blackstone
setblock 122 109 512 minecraft:smooth_basalt
setblock 123 109 511 minecraft:smooth_basalt
fill 123 109 512 126 109 512 minecraft:blackstone
setblock 123 109 551 minecraft:smooth_basalt
fill 124 109 511 124 112 511 minecraft:blackstone
fill 124 109 551 124 112 551 minecraft:blackstone
setblock 127 109 512 minecraft:smooth_basalt
setblock 128 109 511 minecraft:smooth_basalt
fill 128 109 512 128 112 512 minecraft:blackstone
setblock 128 109 551 minecraft:smooth_basalt
fill 129 109 511 129 112 511 minecraft:blackstone
setblock 129 109 550 minecraft:smooth_basalt
fill 129 109 551 129 112 551 minecraft:blackstone
setblock 130 109 513 minecraft:blackstone
fill 130 109 550 130 112 550 minecraft:blackstone
setblock 131 109 513 minecraft:smooth_basalt
fill 131 109 549 131 112 549 minecraft:blackstone
setblock 132 109 512 minecraft:smooth_basalt
fill 132 109 513 133 111 513 minecraft:blackstone
setblock 133 109 511 minecraft:smooth_basalt
fill 133 109 512 133 112 512 minecraft:blackstone
setblock 133 109 531 minecraft:smooth_basalt
fill 133 109 532 133 112 532 minecraft:blackstone
fill 133 109 534 133 109 535 minecraft:blackstone
setblock 133 109 536 minecraft:smooth_basalt
fill 133 109 537 133 112 537 minecraft:blackstone
setblock 133 109 540 minecraft:blackstone
setblock 133 109 541 minecraft:smooth_basalt
setblock 133 109 551 minecraft:smooth_basalt
fill 134 109 511 134 112 511 minecraft:blackstone
setblock 134 109 515 minecraft:smooth_basalt
fill 134 109 516 134 112 516 minecraft:blackstone
fill 134 109 528 134 110 528 minecraft:blackstone
setblock 134 109 530 minecraft:smooth_basalt
fill 134 109 531 134 112 531 minecraft:blackstone
setblock 134 109 535 minecraft:smooth_basalt
fill 134 109 536 134 112 536 minecraft:blackstone
setblock 134 109 540 minecraft:smooth_basalt
fill 134 109 541 134 112 541 minecraft:blackstone
setblock 134 109 545 minecraft:smooth_basalt
fill 134 109 546 134 112 546 minecraft:blackstone
setblock 134 109 550 minecraft:smooth_basalt
fill 134 109 551 134 112 551 minecraft:blackstone
setblock 135 109 514 minecraft:smooth_basalt
fill 135 109 515 135 112 515 minecraft:blackstone
setblock 135 109 519 minecraft:smooth_basalt
setblock 135 109 529 minecraft:smooth_basalt
fill 135 109 530 135 112 530 minecraft:blackstone
setblock 135 109 534 minecraft:smooth_basalt
fill 135 109 535 135 112 535 minecraft:blackstone
setblock 135 109 539 minecraft:smooth_basalt
fill 135 109 540 135 112 540 minecraft:blackstone
setblock 135 109 544 minecraft:smooth_basalt
fill 135 109 545 135 112 545 minecraft:blackstone
setblock 135 109 549 minecraft:smooth_basalt
fill 135 109 550 135 112 550 minecraft:blackstone
setblock 95 110 512 minecraft:blackstone
setblock 95 110 513 minecraft:smooth_basalt
fill 95 110 514 95 113 514 minecraft:blackstone
setblock 95 110 518 minecraft:smooth_basalt
fill 95 110 519 95 113 519 minecraft:blackstone
setblock 95 110 523 minecraft:smooth_basalt
fill 95 110 524 95 113 524 minecraft:blackstone
setblock 95 110 528 minecraft:smooth_basalt
fill 95 110 529 95 113 529 minecraft:blackstone
setblock 95 110 533 minecraft:smooth_basalt
fill 95 110 534 95 113 534 minecraft:blackstone
setblock 95 110 538 minecraft:smooth_basalt
fill 95 110 539 95 113 539 minecraft:blackstone
setblock 95 110 543 minecraft:smooth_basalt
fill 95 110 544 95 113 544 minecraft:blackstone
setblock 95 110 548 minecraft:smooth_basalt
fill 95 110 549 95 111 549 minecraft:blackstone
setblock 96 110 512 minecraft:smooth_basalt
fill 96 110 513 96 113 513 minecraft:blackstone
setblock 96 110 517 minecraft:smooth_basalt
fill 96 110 518 96 113 518 minecraft:blackstone
setblock 96 110 527 minecraft:smooth_basalt
fill 96 110 528 96 113 528 minecraft:blackstone
setblock 96 110 532 minecraft:smooth_basalt
fill 96 110 533 96 113 533 minecraft:blackstone
setblock 96 110 537 minecraft:smooth_basalt
fill 96 110 538 96 113 538 minecraft:blackstone
setblock 96 110 542 minecraft:smooth_basalt
setblock 97 110 511 minecraft:smooth_basalt
fill 97 110 512 97 111 512 minecraft:blackstone
setblock 97 110 531 minecraft:smooth_basalt
fill 97 110 532 97 112 532 minecraft:blackstone
setblock 97 110 536 minecraft:smooth_basalt
fill 97 110 537 97 113 537 minecraft:blackstone
setblock 97 110 551 minecraft:smooth_basalt
fill 98 110 511 98 113 511 minecraft:blackstone
setblock 101 110 511 minecraft:blackstone
setblock 102 110 511 minecraft:smooth_basalt
fill 103 110 511 106 110 511 minecraft:blackstone
setblock 105 110 512 minecraft:blackstone
setblock 106 110 512 minecraft:smooth_basalt
setblock 107 110 511 minecraft:smooth_basalt
fill 107 110 512 107 112 513 minecraft:blackstone
fill 108 110 511 108 113 511 minecraft:blackstone
fill 108 110 551 108 113 551 minecraft:blackstone
setblock 109 110 514 minecraft:smooth_basalt
setblock 110 110 512 minecraft:blackstone
setblock 110 110 513 minecraft:smooth_basalt
fill 110 110 514 110 113 514 minecraft:blackstone
setblock 111 110 512 minecraft:smooth_basalt
fill 111 110 513 111 113 513 minecraft:blackstone
fill 111 110 550 111 111 550 minecraft:blackstone
setblock 112 110 511 minecraft:smooth_basalt
fill 112 110 512 112 113 512 minecraft:blackstone
setblock 112 110 551 minecraft:smooth_basalt
fill 113 110 511 113 113 511 minecraft:blackstone
setblock 113 110 550 minecraft:smooth_basalt
fill 113 110 551 113 113 551 minecraft:blackstone
setblock 114 110 513 minecraft:blackstone
setblock 114 110 514 minecraft:smooth_basalt
fill 114 110 550 114 113 550 minecraft:blackstone
setblock 115 110 513 minecraft:smooth_basalt
fill 115 110 514 115 113 514 minecraft:blackstone
setblock 116 110 512 minecraft:smooth_basalt
fill 116 110 513 116 113 513 minecraft:blackstone
setblock 117 110 511 minecraft:smooth_basalt
fill 117 110 512 117 113 512 minecraft:blackstone
setblock 117 110 551 minecraft:smooth_basalt
fill 118 110 511 118 113 511 minecraft:blackstone
fill 118 110 551 118 113 551 minecraft:blackstone
setblock 120 110 513 minecraft:smooth_basalt
setblock 121 110 512 minecraft:smooth_basalt
setblock 122 110 511 minecraft:smooth_basalt
fill 122 110 512 125 110 512 minecraft:blackstone
setblock 122 110 551 minecraft:smooth_basalt
fill 123 110 511 123 113 511 minecraft:blackstone
fill 123 110 551 123 113 551 minecraft:blackstone
setblock 126 110 512 minecraft:smooth_basalt
fill 126 110 550 126 111 550 minecraft:blackstone
setblock 127 110 511 minecraft:smooth_basalt
fill 127 110 512 127 113 512 minecraft:blackstone
setblock 127 110 551 minecraft:smooth_basalt
fill 128 110 511 128 113 511 minecraft:blackstone
setblock 128 110 550 minecraft:smooth_basalt
fill 128 110 551 128 113 551 minecraft:blackstone
setblock 129 110 513 minecraft:blackstone
fill 129 110 550 129 113 550 minecraft:blackstone
setblock 130 110 513 minecraft:smooth_basalt
fill 130 110 549 130 113 549 minecraft:blackstone
setblock 131 110 512 minecraft:smooth_basalt
fill 131 110 513 131 113 513 minecraft:blackstone
setblock 132 110 511 minecraft:smooth_basalt
fill 132 110 512 132 113 512 minecraft:blackstone
fill 132 110 534 132 110 535 minecraft:blackstone
setblock 132 110 536 minecraft:smooth_basalt
fill 132 110 537 132 111 539 minecraft:blackstone
setblock 132 110 551 minecraft:smooth_basalt
fill 133 110 511 133 113 511 minecraft:blackstone
setblock 133 110 514 minecraft:blackstone
fill 133 110 531 133 113 531 minecraft:blackstone
setblock 133 110 534 minecraft:blackstone
setblock 133 110 535 minecraft:smooth_basalt
fill 133 110 536 133 113 536 minecraft:blackstone
fill 133 110 538 133 110 539 minecraft:blackstone
setblock 133 110 540 minecraft:smooth_basalt
fill 133 110 541 133 110 544 minecraft:blackstone
setblock 133 110 550 minecraft:smooth_basalt
fill 133 110 551 133 113 551 minecraft:blackstone
setblock 134 110 513 minecraft:blackstone
setblock 134 110 514 minecraft:smooth_basalt
fill 134 110 515 134 113 515 minecraft:blackstone
fill 134 110 517 134 111 517 minecraft:blackstone
setblock 134 110 529 minecraft:smooth_basalt
fill 134 110 530 134 113 530 minecraft:blackstone
setblock 134 110 534 minecraft:smooth_basalt
fill 134 110 535 134 113 535 minecraft:blackstone
setblock 134 110 538 minecraft:blackstone
setblock 134 110 539 minecraft:smooth_basalt
fill 134 110 540 134 113 540 minecraft:blackstone
setblock 134 110 544 minecraft:smooth_basalt
fill 134 110 545 134 113 545 minecraft:blackstone
setblock 134 110 549 minecraft:smooth_basalt
fill 134 110 550 134 113 550 minecraft:blackstone
setblock 135 110 513 minecraft:smooth_basalt
fill 135 110 514 135 113 514 minecraft:blackstone
setblock 135 110 518 minecraft:smooth_basalt
fill 135 110 519 135 112 520 minecraft:blackstone
fill 135 110 525 135 112 525 minecraft:blackstone
setblock 135 110 528 minecraft:smooth_basalt
fill 135 110 529 135 113 529 minecraft:blackstone
setblock 135 110 533 minecraft:smooth_basalt
fill 135 110 534 135 113 534 minecraft:blackstone
setblock 135 110 538 minecraft:smooth_basalt
fill 135 110 539 135 113 539 minecraft:blackstone
setblock 135 110 543 minecraft:smooth_basalt
fill 135 110 544 135 113 544 minecraft:blackstone
setblock 135 110 548 minecraft:smooth_basalt
fill 135 110 549 135 113 549 minecraft:blackstone
setblock 95 111 512 minecraft:smooth_basalt
fill 95 111 513 95 114 513 minecraft:blackstone
setblock 95 111 517 minecraft:smooth_basalt
fill 95 111 518 95 114 518 minecraft:blackstone
setblock 95 111 521 minecraft:blackstone
setblock 95 111 522 minecraft:smooth_basalt
fill 95 111 523 95 114 523 minecraft:blackstone
setblock 95 111 527 minecraft:smooth_basalt
fill 95 111 528 95 114 528 minecraft:blackstone
setblock 95 111 532 minecraft:smooth_basalt
fill 95 111 533 95 114 533 minecraft:blackstone
setblock 95 111 537 minecraft:smooth_basalt
fill 95 111 538 95 114 538 minecraft:blackstone
setblock 95 111 541 minecraft:blackstone
setblock 95 111 542 minecraft:smooth_basalt
fill 95 111 543 95 114 543 minecraft:blackstone
setblock 95 111 547 minecraft:smooth_basalt
setblock 95 111 548 minecraft:blackstone
setblock 96 111 511 minecraft:smooth_basalt
fill 96 111 512 96 112 512 minecraft:blackstone
setblock 96 111 516 minecraft:smooth_basalt
fill 96 111 517 96 114 517 minecraft:blackstone
fill 96 111 519 96 111 520 minecraft:blackstone
setblock 96 111 526 minecraft:smooth_basalt
fill 96 111 527 96 112 527 minecraft:blackstone
setblock 96 111 531 minecraft:smooth_basalt
fill 96 111 532 96 114 532 minecraft:blackstone
setblock 96 111 536 minecraft:smooth_basalt
fill 96 111 537 96 114 537 minecraft:blackstone
setblock 96 111 541 minecraft:smooth_basalt
fill 96 111 542 96 114 542 minecraft:blackstone
setblock 96 111 551 minecraft:smooth_basalt
fill 97 111 511 97 113 511 minecraft:blackstone
setblock 97 111 530 minecraft:smooth_basalt
fill 97 111 531 97 112 531 minecraft:blackstone
setblock 97 111 535 minecraft:smooth_basalt
fill 97 111 536 97 114 536 minecraft:blackstone
setblock 97 111 539 minecraft:blackstone
setblock 101 111 511 minecraft:smooth_basalt
fill 102 111 511 105 111 511 minecraft:blackstone
setblock 104 111 512 minecraft:blackstone
setblock 105 111 512 minecraft:smooth_basalt
setblock 106 111 511 minecraft:smooth_basalt
fill 106 111 512 106 113 513 minecraft:blackstone
fill 107 111 511 107 114 511 minecraft:blackstone
fill 107 111 551 107 114 551 minecraft:blackstone
setblock 108 111 514 minecraft:smooth_basalt
setblock 109 111 512 minecraft:blackstone
setblock 109 111 513 minecraft:smooth_basalt
fill 109 111 514 109 114 514 minecraft:blackstone
setblock 110 111 512 minecraft:smooth_basalt
fill 110 111 513 110 114 513 minecraft:blackstone
setblock 111 111 511 minecraft:smooth_basalt
fill 111 111 512 111 114 512 minecraft:blackstone
setblock 111 111 515 minecraft:blackstone
setblock 111 111 551 minecraft:smooth_basalt
fill 112 111 511 112 114 511 minecraft:blackstone
setblock 112 111 514 minecraft:blackstone
setblock 112 111 515 minecraft:smooth_basalt
setblock 112 111 550 minecraft:smooth_basalt
fill 112 111 551 112 114 551 minecraft:blackstone
setblock 113 111 514 minecraft:smooth_basalt
fill 113 111 515 114 112 515 minecraft:blackstone
fill 113 111 550 113 113 550 minecraft:blackstone
setblock 114 111 513 minecraft:smooth_basalt
fill 114 111 514 114 114 514 minecraft:blackstone
setblock 115 111 512 minecraft:smooth_basalt
fill 115 111 513 115 114 513 minecraft:blackstone
setblock 116 111 511 minecraft:smooth_basalt
fill 116 111 512 116 114 512 minecraft:blackstone
setblock 116 111 551 minecraft:smooth_basalt
fill 117 111 511 117 114 511 minecraft:blackstone
fill 117 111 551 117 114 551 minecraft:blackstone
setblock 119 111 513 minecraft:smooth_basalt
setblock 120 111 512 minecraft:smooth_basalt
setblock 120 111 513 minecraft:blackstone
setblock 121 111 511 minecraft:smooth_basalt
fill 121 111 512 124 111 512 minecraft:blackstone
setblock 121 111 551 minecraft:smooth_basalt
fill 122 111 511 122 114 511 minecraft:blackstone
fill 122 111 551 122 114 551 minecraft:blackstone
setblock 125 111 512 minecraft:smooth_basalt
setblock 126 111 511 minecraft:smooth_basalt
fill 126 111 512 126 114 512 minecraft:blackstone
setblock 126 111 551 minecraft:smooth_basalt
fill 127 111 511 127 114 511 minecraft:blackstone
fill 127 111 513 128 111 513 minecraft:blackstone
setblock 127 111 550 minecraft:smooth_basalt
fill 127 111 551 127 114 551 minecraft:blackstone
fill 128 111 550 128 114 550 minecraft:blackstone
setblock 129 111 513 minecraft:smooth_basalt
fill 129 111 531 130 112 531 minecraft:gold_block
setblock 130 111 512 minecraft:smooth_basalt
fill 130 111 513 130 114 513 minecraft:blackstone
setblock 131 111 511 minecraft:smooth_basalt
fill 131 111 512 131 114 512 minecraft:blackstone
setblock 131 111 551 minecraft:smooth_basalt
fill 132 111 511 132 114 511 minecraft:blackstone
fill 132 111 533 132 111 534 minecraft:blackstone
setblock 132 111 535 minecraft:smooth_basalt
fill 132 111 536 132 114 536 minecraft:blackstone
setblock 132 111 540 minecraft:smooth_basalt
fill 132 111 541 133 113 541 minecraft:blackstone
setblock 132 111 550 minecraft:smooth_basalt
fill 132 111 551 132 114 551 minecraft:blackstone
setblock 133 111 514 minecraft:smooth_basalt
fill 133 111 515 133 113 515 minecraft:blackstone
setblock 133 111 534 minecraft:smooth_basalt
fill 133 111 535 133 114 535 minecraft:blackstone
setblock 133 111 538 minecraft:blackstone
setblock 133 111 539 minecraft:smooth_basalt
fill 133 111 540 133 114 540 minecraft:blackstone
fill 133 111 542 133 111 543 minecraft:blackstone
setblock 133 111 544 minecraft:smooth_basalt
fill 133 111 545 133 113 546 minecraft:blackstone
setblock 133 111 549 minecraft:smooth_basalt
fill 133 111 550 133 114 550 minecraft:blackstone
setblock 134 111 513 minecraft:smooth_basalt
fill 134 111 514 134 114 514 minecraft:blackstone
setblock 134 111 518 minecraft:smooth_basalt
setblock 134 111 528 minecraft:smooth_basalt
fill 134 111 529 134 113 529 minecraft:blackstone
setblock 134 111 533 minecraft:smooth_basalt
fill 134 111 534 134 114 534 minecraft:blackstone
setblock 134 111 538 minecraft:smooth_basalt
fill 134 111 539 134 114 539 minecraft:blackstone
setblock 134 111 543 minecraft:smooth_basalt
fill 134 111 544 134 114 544 minecraft:blackstone
setblock 134 111 548 minecraft:smooth_basalt
fill 134 111 549 134 113 549 minecraft:blackstone
setblock 135 111 512 minecraft:smooth_basalt
fill 135 111 513 135 114 513 minecraft:blackstone
setblock 135 111 517 minecraft:smooth_basalt
fill 135 111 518 135 114 518 minecraft:blackstone
setblock 135 111 521 minecraft:blackstone
setblock 135 111 522 minecraft:smooth_basalt
fill 135 111 524 135 113 524 minecraft:blackstone
setblock 135 111 527 minecraft:smooth_basalt
fill 135 111 528 135 114 528 minecraft:blackstone
setblock 135 111 532 minecraft:smooth_basalt
fill 135 111 533 135 114 533 minecraft:blackstone
setblock 135 111 537 minecraft:smooth_basalt
fill 135 111 538 135 114 538 minecraft:blackstone
setblock 135 111 542 minecraft:smooth_basalt
fill 135 111 543 135 114 543 minecraft:blackstone
setblock 135 111 547 minecraft:smooth_basalt
fill 135 111 548 135 114 548 minecraft:blackstone
setblock 95 112 511 minecraft:smooth_basalt
fill 95 112 512 95 115 512 minecraft:blackstone
setblock 95 112 515 minecraft:blackstone
setblock 95 112 516 minecraft:smooth_basalt
fill 95 112 517 95 115 517 minecraft:blackstone
setblock 95 112 521 minecraft:smooth_basalt
fill 95 112 522 95 115 522 minecraft:blackstone
setblock 95 112 526 minecraft:smooth_basalt
fill 95 112 527 95 115 527 minecraft:blackstone
setblock 95 112 531 minecraft:smooth_basalt
fill 95 112 532 95 115 532 minecraft:blackstone
setblock 95 112 536 minecraft:smooth_basalt
fill 95 112 537 95 115 537 minecraft:blackstone
setblock 95 112 541 minecraft:smooth_basalt
fill 95 112 542 95 115 542 minecraft:blackstone
setblock 95 112 546 minecraft:smooth_basalt
setblock 95 112 547 minecraft:blackstone
setblock 95 112 551 minecraft:smooth_basalt
fill 96 112 511 96 114 511 minecraft:blackstone
setblock 96 112 515 minecraft:smooth_basalt
fill 96 112 516 96 115 516 minecraft:blackstone
setblock 96 112 519 minecraft:blackstone
setblock 96 112 520 minecraft:smooth_basalt
fill 96 112 521 96 115 521 minecraft:blackstone
setblock 96 112 526 minecraft:blackstone
setblock 96 112 530 minecraft:smooth_basalt
fill 96 112 531 96 114 531 minecraft:blackstone
setblock 96 112 535 minecraft:smooth_basalt
fill 96 112 536 96 115 536 minecraft:blackstone
setblock 96 112 540 minecraft:smooth_basalt
fill 96 112 541 96 115 541 minecraft:blackstone
setblock 97 112 513 minecraft:light[level=12]
setblock 97 112 521 minecraft:light[level=12]
setblock 97 112 529 minecraft:light[level=12]
setblock 97 112 534 minecraft:smooth_basalt
fill 97 112 535 97 114 535 minecraft:blackstone
setblock 97 112 539 minecraft:smooth_basalt
setblock 97 112 545 minecraft:light[level=12]
setblock 100 112 511 minecraft:smooth_basalt
fill 101 112 511 104 112 511 minecraft:blackstone
setblock 103 112 512 minecraft:blackstone
setblock 104 112 512 minecraft:smooth_basalt
setblock 105 112 511 minecraft:smooth_basalt
fill 105 112 512 105 114 513 minecraft:blackstone
setblock 105 112 521 minecraft:light[level=12]
setblock 105 112 529 minecraft:light[level=12]
setblock 105 112 537 minecraft:light[level=12]
setblock 105 112 545 minecraft:light[level=12]
fill 106 112 511 106 115 511 minecraft:blackstone
setblock 107 112 514 minecraft:smooth_basalt
setblock 108 112 512 minecraft:blackstone
setblock 108 112 513 minecraft:smooth_basalt
fill 108 112 514 108 115 514 minecraft:blackstone
setblock 109 112 512 minecraft:smooth_basalt
fill 109 112 513 109 115 513 minecraft:blackstone
fill 109 112 515 110 112 515 minecraft:blackstone
setblock 110 112 511 minecraft:smooth_basalt
fill 110 112 512 110 115 512 minecraft:blackstone
setblock 110 112 551 minecraft:smooth_basalt
fill 111 112 511 111 115 511 minecraft:blackstone
setblock 111 112 515 minecraft:smooth_basalt
setblock 111 112 550 minecraft:smooth_basalt
fill 111 112 551 111 115 551 minecraft:blackstone
setblock 112 112 514 minecraft:smooth_basalt
fill 112 112 515 112 114 515 minecraft:blackstone
fill 112 112 550 112 114 550 minecraft:blackstone
setblock 113 112 513 minecraft:smooth_basalt
fill 113 112 514 113 115 514 minecraft:blackstone
setblock 113 112 521 minecraft:light[level=12]
setblock 113 112 529 minecraft:light[level=12]
setblock 113 112 537 minecraft:light[level=12]
setblock 113 112 545 minecraft:light[level=12]
setblock 114 112 512 minecraft:smooth_basalt
fill 114 112 513 114 115 513 minecraft:blackstone
setblock 115 112 511 minecraft:smooth_basalt
fill 115 112 512 115 115 512 minecraft:blackstone
setblock 115 112 551 minecraft:smooth_basalt
fill 116 112 511 116 115 511 minecraft:blackstone
setblock 116 112 514 minecraft:blackstone
fill 116 112 551 116 115 551 minecraft:blackstone
setblock 117 112 514 minecraft:smooth_basalt
setblock 118 112 513 minecraft:smooth_basalt
setblock 119 112 512 minecraft:smooth_basalt
setblock 119 112 513 minecraft:blackstone
setblock 120 112 511 minecraft:smooth_basalt
fill 120 112 512 123 112 512 minecraft:blackstone
setblock 120 112 551 minecraft:smooth_basalt
fill 121 112 511 121 115 511 minecraft:blackstone
setblock 121 112 513 minecraft:light[level=12]
setblock 121 112 521 minecraft:light[level=12]
setblock 121 112 529 minecraft:light[level=12]
setblock 121 112 537 minecraft:light[level=12]
setblock 121 112 545 minecraft:light[level=12]
fill 121 112 551 121 114 551 minecraft:blackstone
setblock 124 112 512 minecraft:smooth_basalt
setblock 125 112 511 minecraft:smooth_basalt
fill 125 112 512 125 115 512 minecraft:blackstone
setblock 125 112 550 minecraft:blackstone
setblock 125 112 551 minecraft:smooth_basalt
fill 126 112 511 126 115 511 minecraft:blackstone
setblock 126 112 550 minecraft:smooth_basalt
fill 126 112 551 126 115 551 minecraft:blackstone
setblock 127 112 513 minecraft:blackstone
fill 127 112 550 127 115 550 minecraft:blackstone
setblock 128 112 513 minecraft:smooth_basalt
setblock 129 112 512 minecraft:smooth_basalt
fill 129 112 513 129 114 513 minecraft:blackstone
setblock 129 112 521 minecraft:light[level=12]
setblock 129 112 529 minecraft:light[level=12]
setblock 129 112 537 minecraft:light[level=12]
setblock 129 112 545 minecraft:light[level=12]
setblock 130 112 511 minecraft:smooth_basalt
fill 130 112 512 130 115 512 minecraft:blackstone
setblock 130 112 551 minecraft:smooth_basalt
fill 131 112 511 131 115 511 minecraft:blackstone
setblock 131 112 550 minecraft:smooth_basalt
fill 131 112 551 131 115 551 minecraft:blackstone
setblock 132 112 513 minecraft:blackstone
setblock 132 112 533 minecraft:blackstone
setblock 132 112 534 minecraft:smooth_basalt
fill 132 112 535 132 115 535 minecraft:blackstone
fill 132 112 537 132 112 538 minecraft:blackstone
setblock 132 112 539 minecraft:smooth_basalt
fill 132 112 540 132 115 540 minecraft:blackstone
fill 132 112 542 133 112 542 minecraft:blackstone
setblock 132 112 549 minecraft:smooth_basalt
fill 132 112 550 132 115 550 minecraft:blackstone
setblock 133 112 513 minecraft:smooth_basalt
fill 133 112 514 133 113 514 minecraft:blackstone
fill 133 112 516 133 113 516 minecraft:blackstone
setblock 133 112 533 minecraft:smooth_basalt
fill 133 112 534 133 115 534 minecraft:blackstone
setblock 133 112 538 minecraft:smooth_basalt
fill 133 112 539 133 115 539 minecraft:blackstone
setblock 133 112 543 minecraft:smooth_basalt
fill 133 112 544 133 115 544 minecraft:blackstone
setblock 134 112 512 minecraft:smooth_basalt
fill 134 112 513 134 114 513 minecraft:blackstone
setblock 134 112 517 minecraft:smooth_basalt
fill 134 112 518 134 114 519 minecraft:blackstone
setblock 134 112 528 minecraft:blackstone
setblock 134 112 532 minecraft:smooth_basalt
fill 134 112 533 134 115 533 minecraft:blackstone
setblock 134 112 537 minecraft:smooth_basalt
fill 134 112 538 134 115 538 minecraft:blackstone
setblock 134 112 542 minecraft:smooth_basalt
fill 134 112 543 134 115 543 minecraft:blackstone
setblock 134 112 547 minecraft:smooth_basalt
fill 134 112 548 134 114 548 minecraft:blackstone
setblock 135 112 511 minecraft:smooth_basalt
fill 135 112 512 135 115 512 minecraft:blackstone
setblock 135 112 516 minecraft:smooth_basalt
fill 135 112 517 135 115 517 minecraft:blackstone
setblock 135 112 521 minecraft:smooth_basalt
fill 135 112 522 135 114 523 minecraft:blackstone
setblock 135 112 526 minecraft:smooth_basalt
fill 135 112 527 135 114 527 minecraft:blackstone
setblock 135 112 531 minecraft:smooth_basalt
fill 135 112 532 135 115 532 minecraft:blackstone
setblock 135 112 536 minecraft:smooth_basalt
fill 135 112 537 135 115 537 minecraft:blackstone
setblock 135 112 541 minecraft:smooth_basalt
fill 135 112 542 135 115 542 minecraft:blackstone
setblock 135 112 546 minecraft:smooth_basalt
fill 135 112 547 135 115 547 minecraft:blackstone
setblock 135 112 551 minecraft:smooth_basalt
fill 95 113 511 95 114 511 minecraft:blackstone
setblock 95 113 515 minecraft:smooth_basalt
fill 95 113 516 95 116 516 minecraft:blackstone
setblock 95 113 520 minecraft:smooth_basalt
fill 95 113 521 95 116 521 minecraft:blackstone
setblock 95 113 525 minecraft:smooth_basalt
fill 95 113 526 95 116 526 minecraft:blackstone
setblock 95 113 530 minecraft:smooth_basalt
fill 95 113 531 95 116 531 minecraft:blackstone
setblock 95 113 535 minecraft:smooth_basalt
fill 95 113 536 95 116 536 minecraft:blackstone
setblock 95 113 540 minecraft:smooth_basalt
fill 95 113 541 95 116 541 minecraft:blackstone
setblock 95 113 545 minecraft:smooth_basalt
setblock 95 113 546 minecraft:blackstone
setblock 96 113 514 minecraft:smooth_basalt
fill 96 113 515 96 115 515 minecraft:blackstone
setblock 96 113 519 minecraft:smooth_basalt
fill 96 113 520 96 116 520 minecraft:blackstone
fill 96 113 522 96 114 522 minecraft:blackstone
setblock 96 113 529 minecraft:smooth_basalt
fill 96 113 530 96 114 530 minecraft:blackstone
setblock 96 113 534 minecraft:smooth_basalt
fill 96 113 535 96 116 535 minecraft:blackstone
setblock 96 113 539 minecraft:smooth_basalt
fill 96 113 540 96 116 540 minecraft:blackstone
setblock 97 113 533 minecraft:smooth_basalt
setblock 97 113 534 minecraft:blackstone
setblock 97 113 538 minecraft:smooth_basalt
setblock 99 113 511 minecraft:smooth_basalt
fill 100 113 511 103 113 511 minecraft:blackstone
setblock 103 113 512 minecraft:smooth_basalt
setblock 104 113 511 minecraft:smooth_basalt
fill 104 113 512 104 116 512 minecraft:blackstone
fill 105 113 511 105 116 511 minecraft:blackstone
setblock 107 113 512 minecraft:blackstone
setblock 107 113 513 minecraft:smooth_basalt
fill 107 113 514 107 116 514 minecraft:blackstone
setblock 108 113 512 minecraft:smooth_basalt
fill 108 113 513 108 116 513 minecraft:blackstone
setblock 109 113 511 minecraft:smooth_basalt
fill 109 113 512 109 116 512 minecraft:blackstone
setblock 109 113 515 minecraft:blackstone
setblock 109 113 551 minecraft:smooth_basalt
fill 110 113 511 110 116 511 minecraft:blackstone
setblock 110 113 515 minecraft:smooth_basalt
fill 110 113 551 110 116 551 minecraft:blackstone
setblock 111 113 514 minecraft:smooth_basalt
fill 111 113 515 111 114 515 minecraft:blackstone
fill 111 113 550 111 114 550 minecraft:blackstone
setblock 112 113 513 minecraft:smooth_basalt
fill 112 113 514 112 116 514 minecraft:blackstone
setblock 113 113 512 minecraft:smooth_basalt
fill 113 113 513 113 116 513 minecraft:blackstone
setblock 113 113 515 minecraft:blackstone
setblock 114 113 511 minecraft:smooth_basalt
fill 114 113 512 114 116 512 minecraft:blackstone
setblock 114 113 551 minecraft:smooth_basalt
fill 115 113 511 115 116 511 minecraft:blackstone
fill 115 113 551 115 116 551 minecraft:blackstone
setblock 116 113 514 minecraft:smooth_basalt
setblock 117 113 513 minecraft:smooth_basalt
setblock 118 113 512 minecraft:smooth_basalt
setblock 118 113 513 minecraft:blackstone
setblock 119 113 511 minecraft:smooth_basalt
fill 119 113 512 122 113 512 minecraft:blackstone
setblock 119 113 551 minecraft:smooth_basalt
fill 120 113 511 120 115 511 minecraft:blackstone
fill 120 113 551 120 114 551 minecraft:blackstone
setblock 123 113 512 minecraft:smooth_basalt
setblock 124 113 511 minecraft:smooth_basalt
fill 124 113 512 124 114 512 minecraft:blackstone
setblock 124 113 551 minecraft:smooth_basalt
fill 125 113 511 125 116 511 minecraft:blackstone
setblock 125 113 550 minecraft:smooth_basalt
fill 125 113 551 125 116 551 minecraft:blackstone
fill 126 113 550 126 116 550 minecraft:blackstone
setblock 127 113 513 minecraft:smooth_basalt
setblock 128 113 512 minecraft:smooth_basalt
fill 128 113 513 128 114 513 minecraft:blackstone
setblock 129 113 511 minecraft:smooth_basalt
fill 129 113 512 129 116 512 minecraft:blackstone
setblock 129 113 551 minecraft:smooth_basalt
fill 130 113 511 130 116 511 minecraft:blackstone
setblock 130 113 550 minecraft:smooth_basalt
fill 130 113 551 130 116 551 minecraft:blackstone
fill 131 113 537 131 113 538 minecraft:blackstone
setblock 131 113 539 minecraft:smooth_basalt
setblock 131 113 549 minecraft:smooth_basalt
fill 131 113 550 131 116 550 minecraft:blackstone
setblock 132 113 513 minecraft:smooth_basalt
setblock 132 113 533 minecraft:smooth_basalt
fill 132 113 534 132 114 534 minecraft:blackstone
setblock 132 113 537 minecraft:blackstone
setblock 132 113 538 minecraft:smooth_basalt
fill 132 113 539 132 116 539 minecraft:blackstone
setblock 132 113 542 minecraft:blackstone
setblock 132 113 543 minecraft:smooth_basalt
setblock 133 113 512 minecraft:smooth_basalt
setblock 133 113 513 minecraft:blackstone
setblock 133 113 532 minecraft:smooth_basalt
fill 133 113 533 133 115 533 minecraft:blackstone
setblock 133 113 537 minecraft:smooth_basalt
fill 133 113 538 133 116 538 minecraft:blackstone
setblock 133 113 542 minecraft:smooth_basalt
fill 133 113 543 133 116 543 minecraft:blackstone
setblock 134 113 511 minecraft:smooth_basalt
fill 134 113 512 134 114 512 minecraft:blackstone
setblock 134 113 516 minecraft:smooth_basalt
fill 134 113 517 134 115 517 minecraft:blackstone
setblock 134 113 520 minecraft:blackstone
setblock 134 113 531 minecraft:smooth_basalt
fill 134 113 532 134 116 532 minecraft:blackstone
setblock 134 113 536 minecraft:smooth_basalt
fill 134 113 537 134 116 537 minecraft:blackstone
setblock 134 113 541 minecraft:smooth_basalt
fill 134 113 542 134 116 542 minecraft:blackstone
setblock 134 113 546 minecraft:smooth_basalt
fill 134 113 547 134 114 547 minecraft:blackstone
setblock 134 113 551 minecraft:smooth_basalt
fill 135 113 511 135 114 511 minecraft:blackstone
setblock 135 113 515 minecraft:smooth_basalt
fill 135 113 516 135 116 516 minecraft:blackstone
setblock 135 113 519 minecraft:blackstone
setblock 135 113 520 minecraft:smooth_basalt
fill 135 113 521 135 116 521 minecraft:blackstone
setblock 135 113 525 minecraft:smooth_basalt
fill 135 113 526 135 114 526 minecraft:blackstone
setblock 135 113 530 minecraft:smooth_basalt
fill 135 113 531 135 116 531 minecraft:blackstone
setblock 135 113 535 minecraft:smooth_basalt
fill 135 113 536 135 116 536 minecraft:blackstone
setblock 135 113 540 minecraft:smooth_basalt
fill 135 113 541 135 116 541 minecraft:blackstone
setblock 135 113 545 minecraft:smooth_basalt
fill 135 113 546 135 116 546 minecraft:blackstone
setblock 135 113 550 minecraft:smooth_basalt
fill 135 113 551 135 114 551 minecraft:blackstone
setblock 95 114 514 minecraft:smooth_basalt
fill 95 114 515 95 117 515 minecraft:blackstone
setblock 95 114 519 minecraft:smooth_basalt
fill 95 114 520 95 117 520 minecraft:blackstone
setblock 95 114 524 minecraft:smooth_basalt
fill 95 114 525 95 117 525 minecraft:blackstone
setblock 95 114 529 minecraft:smooth_basalt
fill 95 114 530 95 116 530 minecraft:blackstone
setblock 95 114 534 minecraft:smooth_basalt
fill 95 114 535 95 117 535 minecraft:blackstone
setblock 95 114 539 minecraft:smooth_basalt
fill 95 114 540 95 117 540 minecraft:blackstone
setblock 95 114 544 minecraft:smooth_basalt
setblock 95 114 545 minecraft:blackstone
setblock 96 114 514 minecraft:blackstone
setblock 96 114 518 minecraft:smooth_basalt
fill 96 114 519 96 117 519 minecraft:blackstone
setblock 96 114 533 minecraft:smooth_basalt
fill 96 114 534 96 115 534 minecraft:blackstone
setblock 96 114 538 minecraft:smooth_basalt
fill 96 114 539 96 116 539 minecraft:blackstone
setblock 97 114 537 minecraft:smooth_basalt
setblock 102 114 511 minecraft:blackstone
setblock 103 114 511 minecraft:smooth_basalt
setblock 103 114 512 minecraft:blackstone
fill 104 114 511 104 117 511 minecraft:blackstone
setblock 106 114 512 minecraft:blackstone
setblock 106 114 513 minecraft:smooth_basalt
setblock 106 114 514 minecraft:blackstone
setblock 107 114 512 minecraft:smooth_basalt
fill 107 114 513 107 117 513 minecraft:blackstone
setblock 108 114 511 minecraft:smooth_basalt
fill 108 114 512 108 117 512 minecraft:blackstone
setblock 108 114 551 minecraft:smooth_basalt
fill 109 114 511 109 117 511 minecraft:blackstone
setblock 109 114 515 minecraft:smooth_basalt
fill 109 114 551 109 117 551 minecraft:blackstone
setblock 110 114 514 minecraft:smooth_basalt
fill 110 114 515 110 115 515 minecraft:blackstone
setblock 111 114 513 minecraft:smooth_basalt
fill 111 114 514 111 116 514 minecraft:blackstone
setblock 112 114 512 minecraft:smooth_basalt
fill 112 114 513 112 117 513 minecraft:blackstone
setblock 113 114 511 minecraft:smooth_basalt
fill 113 114 512 113 117 512 minecraft:blackstone
setblock 113 114 551 minecraft:smooth_basalt
fill 114 114 511 114 117 511 minecraft:blackstone
fill 114 114 551 114 116 551 minecraft:blackstone
setblock 115 114 514 minecraft:smooth_basalt
setblock 116 114 513 minecraft:smooth_basalt
setblock 117 114 512 minecraft:smooth_basalt
setblock 117 114 513 minecraft:blackstone
setblock 118 114 511 minecraft:smooth_basalt
fill 118 114 512 121 114 512 minecraft:blackstone
setblock 118 114 551 minecraft:smooth_basalt
fill 119 114 511 119 116 511 minecraft:blackstone
setblock 119 114 551 minecraft:blackstone
setblock 122 114 512 minecraft:smooth_basalt
setblock 123 114 511 minecraft:smooth_basalt
setblock 123 114 512 minecraft:blackstone
setblock 123 114 551 minecraft:smooth_basalt
fill 124 114 511 124 117 511 minecraft:blackstone
fill 124 114 551 124 117 551 minecraft:blackstone
setblock 127 114 512 minecraft:smooth_basalt
setblock 128 114 511 minecraft:smooth_basalt
fill 128 114 512 128 116 512 minecraft:blackstone
setblock 128 114 551 minecraft:smooth_basalt
fill 129 114 511 129 117 511 minecraft:blackstone
setblock 129 114 550 minecraft:smooth_basalt
fill 129 114 551 129 117 551 minecraft:blackstone
fill 130 114 550 130 116 550 minecraft:blackstone
setblock 131 114 513 minecraft:smooth_basalt
setblock 131 114 537 minecraft:blackstone
setblock 131 114 538 minecraft:smooth_basalt
fill 131 114 539 131 115 539 minecraft:blackstone
setblock 132 114 512 minecraft:smooth_basalt
setblock 132 114 537 minecraft:smooth_basalt
fill 132 114 538 132 117 538 minecraft:blackstone
setblock 132 114 541 minecraft:blackstone
setblock 132 114 542 minecraft:smooth_basalt
fill 132 114 543 132 115 543 minecraft:blackstone
setblock 133 114 511 minecraft:smooth_basalt
setblock 133 114 512 minecraft:blackstone
setblock 133 114 532 minecraft:blackstone
setblock 133 114 536 minecraft:smooth_basalt
fill 133 114 537 133 117 537 minecraft:blackstone
setblock 133 114 541 minecraft:smooth_basalt
fill 133 114 542 133 117 542 minecraft:blackstone
setblock 133 114 545 minecraft:blackstone
setblock 133 114 551 minecraft:smooth_basalt
fill 134 114 511 134 115 511 minecraft:blackstone
setblock 134 114 515 minecraft:smooth_basalt
fill 134 114 516 134 115 516 minecraft:blackstone
setblock 134 114 520 minecraft:smooth_basalt
setblock 134 114 530 minecraft:smooth_basalt
fill 134 114 531 134 115 531 minecraft:blackstone
setblock 134 114 535 minecraft:smooth_basalt
fill 134 114 536 134 117 536 minecraft:blackstone
setblock 134 114 540 minecraft:smooth_basalt
fill 134 114 541 134 117 541 minecraft:blackstone
setblock 134 114 545 minecraft:smooth_basalt
fill 134 114 546 134 115 546 minecraft:blackstone
fill 134 114 551 134 115 551 minecraft:blackstone
setblock 135 114 514 minecraft:smooth_basalt
fill 135 114 515 135 116 515 minecraft:blackstone
setblock 135 114 519 minecraft:smooth_basalt
fill 135 114 520 135 117 520 minecraft:blackstone
setblock 135 114 524 minecraft:smooth_basalt
setblock 135 114 525 minecraft:blackstone
setblock 135 114 529 minecraft:smooth_basalt
fill 135 114 530 135 116 530 minecraft:blackstone
setblock 135 114 534 minecraft:smooth_basalt
fill 135 114 535 135 117 535 minecraft:blackstone
setblock 135 114 539 minecraft:smooth_basalt
fill 135 114 540 135 117 540 minecraft:blackstone
setblock 135 114 544 minecraft:smooth_basalt
fill 135 114 545 135 117 545 minecraft:blackstone
setblock 135 114 549 minecraft:smooth_basalt
setblock 135 114 550 minecraft:blackstone
setblock 95 115 513 minecraft:smooth_basalt
fill 95 115 514 95 116 514 minecraft:blackstone
setblock 95 115 518 minecraft:smooth_basalt
fill 95 115 519 95 118 519 minecraft:blackstone
setblock 95 115 523 minecraft:smooth_basalt
fill 95 115 524 95 118 524 minecraft:blackstone
setblock 95 115 528 minecraft:smooth_basalt
fill 95 115 529 95 116 529 minecraft:blackstone
setblock 95 115 533 minecraft:smooth_basalt
fill 95 115 534 95 118 534 minecraft:blackstone
setblock 95 115 538 minecraft:smooth_basalt
fill 95 115 539 95 118 539 minecraft:blackstone
setblock 95 115 543 minecraft:smooth_basalt
fill 95 115 544 95 116 544 minecraft:blackstone
setblock 96 115 517 minecraft:smooth_basalt
fill 96 115 518 96 117 518 minecraft:blackstone
setblock 96 115 522 minecraft:smooth_basalt
setblock 96 115 532 minecraft:smooth_basalt
setblock 96 115 533 minecraft:blackstone
setblock 96 115 537 minecraft:smooth_basalt
fill 96 115 538 96 116 538 minecraft:blackstone
setblock 102 115 511 minecraft:smooth_basalt
fill 103 115 511 103 117 511 minecraft:blackstone
setblock 105 115 512 minecraft:blackstone
setblock 105 115 513 minecraft:smooth_basalt
setblock 106 115 512 minecraft:smooth_basalt
fill 106 115 513 106 117 513 minecraft:blackstone
setblock 107 115 511 minecraft:smooth_basalt
fill 107 115 512 107 118 512 minecraft:blackstone
setblock 107 115 551 minecraft:smooth_basalt
fill 108 115 511 108 118 511 minecraft:blackstone
fill 108 115 551 108 118 551 minecraft:blackstone
setblock 109 115 514 minecraft:smooth_basalt
setblock 109 115 515 minecraft:blackstone
setblock 110 115 513 minecraft:smooth_basalt
fill 110 115 514 110 116 514 minecraft:blackstone
setblock 111 115 512 minecraft:smooth_basalt
fill 111 115 513 111 117 513 minecraft:blackstone
setblock 112 115 511 minecraft:smooth_basalt
fill 112 115 512 112 118 512 minecraft:blackstone
setblock 112 115 551 minecraft:smooth_basalt
fill 113 115 511 113 118 511 minecraft:blackstone
fill 113 115 551 113 117 551 minecraft:blackstone
setblock 115 115 513 minecraft:smooth_basalt
setblock 116 115 512 minecraft:smooth_basalt
setblock 117 115 511 minecraft:smooth_basalt
fill 117 115 512 118 115 512 minecraft:blackstone
setblock 117 115 551 minecraft:smooth_basalt
fill 118 115 511 118 116 511 minecraft:blackstone
setblock 122 115 511 minecraft:smooth_basalt
setblock 122 115 551 minecraft:smooth_basalt
fill 123 115 511 123 116 511 minecraft:blackstone
fill 123 115 551 123 118 551 minecraft:blackstone
setblock 126 115 512 minecraft:smooth_basalt
setblock 127 115 511 minecraft:smooth_basalt
fill 127 115 512 127 116 512 minecraft:blackstone
setblock 127 115 551 minecraft:smooth_basalt
fill 128 115 511 128 118 511 minecraft:blackstone
setblock 128 115 550 minecraft:smooth_basalt
fill 128 115 551 128 118 551 minecraft:blackstone
fill 129 115 550 129 117 550 minecraft:blackstone
setblock 131 115 512 minecraft:smooth_basalt
setblock 132 115 511 minecraft:smooth_basalt
setblock 132 115 512 minecraft:blackstone
setblock 132 115 536 minecraft:smooth_basalt
fill 132 115 537 132 116 537 minecraft:blackstone
setblock 132 115 541 minecraft:smooth_basalt
fill 132 115 542 132 116 542 minecraft:blackstone
setblock 132 115 551 minecraft:smooth_basalt
setblock 133 115 511 minecraft:blackstone
setblock 133 115 535 minecraft:smooth_basalt
fill 133 115 536 133 117 536 minecraft:blackstone
setblock 133 115 540 minecraft:smooth_basalt
fill 133 115 541 133 118 541 minecraft:blackstone
setblock 133 115 545 minecraft:smooth_basalt
fill 133 115 551 133 116 551 minecraft:blackstone
setblock 134 115 515 minecraft:blackstone
setblock 134 115 518 minecraft:blackstone
setblock 134 115 519 minecraft:smooth_basalt
setblock 134 115 534 minecraft:smooth_basalt
fill 134 115 535 134 118 535 minecraft:blackstone
setblock 134 115 539 minecraft:smooth_basalt
fill 134 115 540 134 118 540 minecraft:blackstone
setblock 134 115 544 minecraft:smooth_basalt
fill 134 115 545 134 117 545 minecraft:blackstone
setblock 135 115 513 minecraft:smooth_basalt
fill 135 115 514 135 116 514 minecraft:blackstone
setblock 135 115 518 minecraft:smooth_basalt
fill 135 115 519 135 118 519 minecraft:blackstone
setblock 135 115 522 minecraft:blackstone
setblock 135 115 523 minecraft:smooth_basalt
setblock 135 115 524 minecraft:blackstone
setblock 135 115 528 minecraft:smooth_basalt
setblock 135 115 529 minecraft:blackstone
setblock 135 115 533 minecraft:smooth_basalt
fill 135 115 534 135 118 534 minecraft:blackstone
setblock 135 115 538 minecraft:smooth_basalt
fill 135 115 539 135 118 539 minecraft:blackstone
setblock 135 115 543 minecraft:smooth_basalt
fill 135 115 544 135 118 544 minecraft:blackstone
setblock 135 115 548 minecraft:smooth_basalt
setblock 135 115 549 minecraft:blackstone
setblock 95 116 513 minecraft:blackstone
setblock 95 116 517 minecraft:smooth_basalt
fill 95 116 518 95 119 518 minecraft:blackstone
setblock 95 116 522 minecraft:smooth_basalt
fill 95 116 523 95 119 523 minecraft:blackstone
setblock 95 116 527 minecraft:smooth_basalt
setblock 95 116 528 minecraft:blackstone
setblock 95 116 532 minecraft:smooth_basalt
fill 95 116 533 95 117 533 minecraft:blackstone
setblock 95 116 537 minecraft:smooth_basalt
fill 95 116 538 95 119 538 minecraft:blackstone
setblock 95 116 542 minecraft:smooth_basalt
fill 95 116 543 95 117 543 minecraft:blackstone
setblock 96 116 516 minecraft:smooth_basalt
setblock 96 116 517 minecraft:blackstone
setblock 96 116 521 minecraft:smooth_basalt
setblock 96 116 522 minecraft:blackstone
setblock 96 116 536 minecraft:smooth_basalt
setblock 96 116 537 minecraft:blackstone
setblock 105 116 512 minecraft:smooth_basalt
setblock 105 116 513 minecraft:blackstone
setblock 106 116 511 minecraft:smooth_basalt
fill 106 116 512 106 119 512 minecraft:blackstone
fill 107 116 511 107 119 511 minecraft:blackstone
fill 107 116 551 107 117 551 minecraft:blackstone
setblock 108 116 514 minecraft:smooth_basalt
setblock 109 116 513 minecraft:smooth_basalt
fill 109 116 514 109 117 514 minecraft:blackstone
setblock 110 116 512 minecraft:smooth_basalt
fill 110 116 513 110 118 513 minecraft:blackstone
setblock 111 116 511 minecraft:smooth_basalt
fill 111 116 512 111 119 512 minecraft:blackstone
setblock 111 116 551 minecraft:smooth_basalt
fill 112 116 511 112 119 511 minecraft:blackstone
fill 112 116 551 112 118 551 minecraft:blackstone
setblock 114 116 513 minecraft:smooth_basalt
setblock 115 116 512 minecraft:smooth_basalt
setblock 116 116 511 minecraft:smooth_basalt
setblock 116 116 512 minecraft:blackstone
setblock 117 116 511 minecraft:blackstone
setblock 122 116 511 minecraft:blackstone
setblock 126 116 511 minecraft:smooth_basalt
setblock 126 116 551 minecraft:smooth_basalt
fill 127 116 511 127 118 511 minecraft:blackstone
setblock 127 116 550 minecraft:smooth_basalt
fill 127 116 551 127 119 551 minecraft:blackstone
fill 128 116 550 128 117 550 minecraft:blackstone
setblock 130 116 512 minecraft:smooth_basalt
setblock 131 116 511 minecraft:smooth_basalt
setblock 131 116 551 minecraft:smooth_basalt
setblock 132 116 511 minecraft:blackstone
setblock 132 116 536 minecraft:blackstone
setblock 132 116 540 minecraft:smooth_basalt
fill 132 116 541 132 117 541 minecraft:blackstone
fill 132 116 551 132 117 551 minecraft:blackstone
setblock 133 116 534 minecraft:smooth_basalt
setblock 133 116 535 minecraft:blackstone
setblock 133 116 539 minecraft:smooth_basalt
fill 133 116 540 133 119 540 minecraft:blackstone
setblock 133 116 544 minecraft:smooth_basalt
setblock 134 116 533 minecraft:smooth_basalt
fill 134 116 534 134 117 534 minecraft:blackstone
setblock 134 116 538 minecraft:smooth_basalt
fill 134 116 539 134 119 539 minecraft:blackstone
setblock 134 116 543 minecraft:smooth_basalt
fill 134 116 544 134 119 544 minecraft:blackstone
setblock 135 116 517 minecraft:smooth_basalt
fill 135 116 518 135 117 518 minecraft:blackstone
setblock 135 116 522 minecraft:smooth_basalt
setblock 135 116 523 minecraft:blackstone
setblock 135 116 532 minecraft:smooth_basalt
fill 135 116 533 135 118 533 minecraft:blackstone
setblock 135 116 537 minecraft:smooth_basalt
fill 135 116 538 135 119 538 minecraft:blackstone
setblock 135 116 542 minecraft:smooth_basalt
fill 135 116 543 135 119 543 minecraft:blackstone
setblock 135 116 547 minecraft:smooth_basalt
setblock 95 117 516 minecraft:smooth_basalt
fill 95 117 517 95 120 517 minecraft:blackstone
setblock 95 117 521 minecraft:smooth_basalt
fill 95 117 522 95 120 522 minecraft:blackstone
setblock 95 117 526 minecraft:smooth_basalt
setblock 95 117 527 minecraft:blackstone
setblock 95 117 531 minecraft:smooth_basalt
setblock 95 117 532 minecraft:blackstone
setblock 95 117 536 minecraft:smooth_basalt
fill 95 117 537 95 118 537 minecraft:blackstone
setblock 95 117 541 minecraft:smooth_basalt
fill 95 117 542 95 118 542 minecraft:blackstone
setblock 96 117 520 minecraft:smooth_basalt
setblock 96 117 521 minecraft:blackstone
setblock 105 117 511 minecraft:smooth_basalt
fill 105 117 512 105 120 512 minecraft:blackstone
fill 106 117 511 106 120 511 minecraft:blackstone
setblock 108 117 513 minecraft:smooth_basalt
setblock 109 117 512 minecraft:smooth_basalt
fill 109 117 513 109 118 513 minecraft:blackstone
setblock 110 117 511 minecraft:smooth_basalt
fill 110 117 512 110 120 512 minecraft:blackstone
setblock 110 117 551 minecraft:smooth_basalt
fill 111 117 511 111 120 511 minecraft:blackstone
fill 111 117 551 111 120 551 minecraft:blackstone
setblock 114 117 512 minecraft:smooth_basalt
setblock 115 117 511 minecraft:smooth_basalt
setblock 116 117 511 minecraft:blackstone
setblock 125 117 511 minecraft:smooth_basalt
setblock 125 117 551 minecraft:smooth_basalt
fill 126 117 511 126 118 511 minecraft:blackstone
fill 126 117 551 126 120 551 minecraft:blackstone
setblock 127 117 550 minecraft:blackstone
setblock 130 117 511 minecraft:smooth_basalt
setblock 130 117 551 minecraft:smooth_basalt
fill 131 117 551 131 118 551 minecraft:blackstone
setblock 132 117 539 minecraft:smooth_basalt
setblock 132 117 540 minecraft:blackstone
setblock 133 117 538 minecraft:smooth_basalt
fill 133 117 539 133 119 539 minecraft:blackstone
setblock 133 117 543 minecraft:smooth_basalt
setblock 134 117 537 minecraft:smooth_basalt
fill 134 117 538 134 120 538 minecraft:blackstone
setblock 134 117 542 minecraft:smooth_basalt
fill 134 117 543 134 120 543 minecraft:blackstone
setblock 135 117 517 minecraft:blackstone
setblock 135 117 521 minecraft:smooth_basalt
fill 135 117 522 135 120 522 minecraft:blackstone
setblock 135 117 532 minecraft:blackstone
setblock 135 117 536 minecraft:smooth_basalt
fill 135 117 537 135 120 537 minecraft:blackstone
setblock 135 117 541 minecraft:smooth_basalt
fill 135 117 542 135 120 542 minecraft:blackstone
setblock 135 117 546 minecraft:smooth_basalt
setblock 95 118 516 minecraft:blackstone
setblock 95 118 520 minecraft:smooth_basalt
fill 95 118 521 95 121 521 minecraft:blackstone
setblock 95 118 525 minecraft:smooth_basalt
fill 95 118 526 95 121 526 minecraft:blackstone
setblock 95 118 535 minecraft:smooth_basalt
setblock 95 118 536 minecraft:blackstone
setblock 95 118 540 minecraft:smooth_basalt
fill 95 118 541 95 119 541 minecraft:blackstone
setblock 96 118 520 minecraft:blackstone
setblock 104 118 511 minecraft:smooth_basalt
fill 105 118 511 105 121 511 minecraft:blackstone
setblock 107 118 513 minecraft:smooth_basalt
setblock 108 118 512 minecraft:smooth_basalt
setblock 108 118 513 minecraft:blackstone
setblock 109 118 511 minecraft:smooth_basalt
fill 109 118 512 109 121 512 minecraft:blackstone
setblock 109 118 551 minecraft:smooth_basalt
fill 110 118 511 110 121 511 minecraft:blackstone
fill 110 118 551 110 121 551 minecraft:blackstone
setblock 114 118 511 minecraft:smooth_basalt
setblock 124 118 551 minecraft:smooth_basalt
fill 125 118 551 125 121 551 minecraft:blackstone
setblock 129 118 551 minecraft:smooth_basalt
fill 130 118 551 130 119 551 minecraft:blackstone
setblock 133 118 537 minecraft:smooth_basalt
setblock 133 118 538 minecraft:blackstone
setblock 133 118 542 minecraft:smooth_basalt
setblock 133 118 543 minecraft:blackstone
setblock 134 118 536 minecraft:smooth_basalt
fill 134 118 537 134 119 537 minecraft:blackstone
setblock 134 118 541 minecraft:smooth_basalt
fill 134 118 542 134 121 542 minecraft:blackstone
setblock 135 118 520 minecraft:smooth_basalt
fill 135 118 521 135 121 521 minecraft:blackstone
setblock 135 118 535 minecraft:smooth_basalt
fill 135 118 536 135 120 536 minecraft:blackstone
setblock 135 118 540 minecraft:smooth_basalt
fill 135 118 541 135 121 541 minecraft:blackstone
setblock 135 118 545 minecraft:smooth_basalt
setblock 135 118 546 minecraft:blackstone
setblock 95 119 519 minecraft:smooth_basalt
fill 95 119 520 95 122 520 minecraft:blackstone
setblock 95 119 524 minecraft:smooth_basalt
fill 95 119 525 95 122 525 minecraft:blackstone
setblock 95 119 539 minecraft:smooth_basalt
setblock 95 119 540 minecraft:blackstone
fill 104 119 511 104 122 511 minecraft:blackstone
setblock 107 119 512 minecraft:smooth_basalt
setblock 107 119 551 minecraft:blackstone
setblock 108 119 511 minecraft:smooth_basalt
fill 108 119 512 108 122 512 minecraft:blackstone
setblock 108 119 551 minecraft:smooth_basalt
fill 109 119 511 109 122 511 minecraft:blackstone
fill 109 119 551 109 122 551 minecraft:blackstone
setblock 113 119 511 minecraft:smooth_basalt
setblock 123 119 551 minecraft:smooth_basalt
fill 124 119 551 124 122 551 minecraft:blackstone
setblock 128 119 551 minecraft:smooth_basalt
fill 129 119 551 129 122 551 minecraft:blackstone
setblock 133 119 541 minecraft:smooth_basalt
setblock 133 119 542 minecraft:blackstone
setblock 134 119 540 minecraft:smooth_basalt
fill 134 119 541 134 122 541 minecraft:blackstone
setblock 135 119 520 minecraft:blackstone
setblock 135 119 535 minecraft:blackstone
setblock 135 119 539 minecraft:smooth_basalt
fill 135 119 540 135 122 540 minecraft:blackstone
setblock 135 119 544 minecraft:smooth_basalt
fill 135 119 545 135 122 545 minecraft:blackstone
setblock 95 120 518 minecraft:smooth_basalt
fill 95 120 519 95 123 519 minecraft:blackstone
setblock 95 120 523 minecraft:smooth_basalt
fill 95 120 524 95 123 524 minecraft:blackstone
setblock 97 120 513 minecraft:light[level=12]
setblock 97 120 521 minecraft:light[level=12]
setblock 97 120 529 minecraft:light[level=12]
setblock 97 120 537 minecraft:light[level=12]
setblock 97 120 545 minecraft:light[level=12]
fill 103 120 511 103 123 511 minecraft:blackstone
setblock 105 120 513 minecraft:light[level=12]
setblock 105 120 521 minecraft:light[level=12]
setblock 105 120 529 minecraft:light[level=12]
setblock 105 120 537 minecraft:light[level=12]
setblock 105 120 545 minecraft:light[level=12]
setblock 106 120 512 minecraft:smooth_basalt
setblock 106 120 551 minecraft:blackstone
setblock 107 120 511 minecraft:smooth_basalt
fill 107 120 512 107 123 512 minecraft:blackstone
setblock 107 120 551 minecraft:smooth_basalt
fill 108 120 511 108 123 511 minecraft:blackstone
fill 108 120 551 108 123 551 minecraft:blackstone
setblock 112 120 511 minecraft:smooth_basalt
setblock 113 120 513 minecraft:light[level=12]
setblock 113 120 521 minecraft:light[level=12]
setblock 113 120 529 minecraft:light[level=12]
setblock 113 120 537 minecraft:light[level=12]
setblock 113 120 545 minecraft:light[level=12]
setblock 121 120 513 minecraft:light[level=12]
setblock 121 120 521 minecraft:light[level=12]
setblock 121 120 529 minecraft:light[level=12]
setblock 121 120 537 minecraft:light[level=12]
setblock 121 120 545 minecraft:light[level=12]
setblock 122 120 551 minecraft:smooth_basalt
fill 123 120 551 123 123 551 minecraft:blackstone
fill 126 120 550 127 120 550 minecraft:blackstone
setblock 127 120 551 minecraft:smooth_basalt
fill 128 120 551 128 123 551 minecraft:blackstone
setblock 129 120 513 minecraft:light[level=12]
setblock 129 120 521 minecraft:light[level=12]
setblock 129 120 529 minecraft:light[level=12]
setblock 129 120 537 minecraft:light[level=12]
setblock 129 120 545 minecraft:light[level=12]
setblock 134 120 539 minecraft:smooth_basalt
fill 134 120 540 134 121 540 minecraft:blackstone
setblock 135 120 523 minecraft:smooth_basalt
setblock 135 120 538 minecraft:smooth_basalt
fill 135 120 539 135 123 539 minecraft:blackstone
setblock 135 120 543 minecraft:smooth_basalt
fill 135 120 544 135 123 544 minecraft:blackstone
setblock 95 121 517 minecraft:smooth_basalt
fill 95 121 518 95 124 518 minecraft:blackstone
setblock 95 121 522 minecraft:smooth_basalt
fill 95 121 523 96 123 523 minecraft:blackstone
setblock 95 121 527 minecraft:smooth_basalt
setblock 96 121 521 minecraft:smooth_basalt
fill 96 121 522 96 124 522 minecraft:blackstone
setblock 105 121 512 minecraft:smooth_basalt
setblock 105 121 551 minecraft:blackstone
setblock 106 121 511 minecraft:smooth_basalt
fill 106 121 512 106 124 512 minecraft:blackstone
setblock 106 121 551 minecraft:smooth_basalt
fill 107 121 511 107 124 511 minecraft:blackstone
fill 107 121 551 107 124 551 minecraft:blackstone
setblock 111 121 511 minecraft:smooth_basalt
setblock 111 121 551 minecraft:smooth_basalt
setblock 121 121 551 minecraft:smooth_basalt
fill 122 121 551 122 124 551 minecraft:blackstone
fill 124 121 550 126 121 550 minecraft:blackstone
setblock 126 121 551 minecraft:smooth_basalt
setblock 127 121 550 minecraft:smooth_basalt
fill 127 121 551 127 124 551 minecraft:blackstone
setblock 134 121 543 minecraft:smooth_basalt
setblock 135 121 522 minecraft:smooth_basalt
fill 135 121 523 135 122 525 minecraft:blackstone
setblock 135 121 537 minecraft:smooth_basalt
fill 135 121 538 135 123 538 minecraft:blackstone
setblock 135 121 542 minecraft:smooth_basalt
fill 135 121 543 135 124 543 minecraft:blackstone
setblock 95 122 521 minecraft:smooth_basalt
fill 95 122 522 95 125 522 minecraft:blackstone
setblock 95 122 526 minecraft:smooth_basalt
fill 95 122 527 95 125 527 minecraft:blackstone
setblock 96 122 520 minecraft:smooth_basalt
fill 96 122 521 96 125 521 minecraft:blackstone
setblock 96 122 524 minecraft:blackstone
fill 102 122 511 102 124 511 minecraft:blackstone
setblock 104 122 512 minecraft:smooth_basalt
setblock 104 122 551 minecraft:blackstone
setblock 105 122 511 minecraft:smooth_basalt
fill 105 122 512 105 125 512 minecraft:blackstone
setblock 105 122 551 minecraft:smooth_basalt
fill 106 122 511 106 125 511 minecraft:blackstone
fill 106 122 551 106 125 551 minecraft:blackstone
fill 107 122 550 107 125 550 minecraft:blackstone
setblock 110 122 511 minecraft:smooth_basalt
setblock 110 122 551 minecraft:smooth_basalt
fill 111 122 511 111 125 511 minecraft:blackstone
fill 111 122 551 112 124 551 minecraft:blackstone
setblock 119 122 551 minecraft:blackstone
setblock 120 122 551 minecraft:smooth_basalt
fill 121 122 551 121 125 551 minecraft:blackstone
fill 122 122 550 125 122 550 minecraft:blackstone
fill 125 122 549 126 122 549 minecraft:blackstone
setblock 125 122 551 minecraft:smooth_basalt
setblock 126 122 550 minecraft:smooth_basalt
fill 126 122 551 126 125 551 minecraft:blackstone
fill 127 122 550 128 124 550 minecraft:blackstone
setblock 134 122 542 minecraft:smooth_basalt
setblock 134 122 543 minecraft:blackstone
setblock 135 122 520 minecraft:blackstone
setblock 135 122 521 minecraft:smooth_basalt
fill 135 122 522 135 125 522 minecraft:blackstone
setblock 135 122 526 minecraft:smooth_basalt
fill 135 122 527 135 125 527 minecraft:blackstone
setblock 135 122 541 minecraft:smooth_basalt
fill 135 122 542 135 125 542 minecraft:blackstone
fill 95 123 517 95 125 517 minecraft:blackstone
setblock 95 123 520 minecraft:smooth_basalt
fill 95 123 521 95 126 521 minecraft:blackstone
setblock 95 123 525 minecraft:smooth_basalt
fill 95 123 526 96 125 526 minecraft:blackstone
fill 95 123 528 95 124 528 minecraft:blackstone
fill 96 123 520 96 126 520 minecraft:blackstone
setblock 96 123 524 minecraft:smooth_basalt
fill 96 123 525 96 126 525 minecraft:blackstone
fill 101 123 511 101 125 511 minecraft:blackstone
fill 102 123 551 103 123 551 minecraft:blackstone
setblock 103 123 512 minecraft:smooth_basalt
setblock 104 123 511 minecraft:smooth_basalt
fill 104 123 512 104 126 512 minecraft:blackstone
setblock 104 123 550 minecraft:blackstone
setblock 104 123 551 minecraft:smooth_basalt
fill 105 123 511 105 126 511 minecraft:blackstone
setblock 105 123 550 minecraft:smooth_basalt
fill 105 123 551 105 126 551 minecraft:blackstone
fill 106 123 550 106 126 550 minecraft:blackstone
setblock 108 123 512 minecraft:smooth_basalt
fill 108 123 550 109 123 550 minecraft:blackstone
setblock 109 123 511 minecraft:smooth_basalt
setblock 109 123 551 minecraft:smooth_basalt
fill 110 123 511 110 126 511 minecraft:blackstone
setblock 110 123 550 minecraft:smooth_basalt
fill 110 123 551 110 126 551 minecraft:blackstone
setblock 113 123 551 minecraft:blackstone
setblock 114 123 551 minecraft:smooth_basalt
fill 115 123 551 118 123 551 minecraft:blackstone
setblock 119 123 551 minecraft:smooth_basalt
setblock 120 123 550 minecraft:smooth_basalt
fill 120 123 551 120 126 551 minecraft:blackstone
fill 121 123 550 124 123 550 minecraft:blackstone
fill 122 123 549 125 123 549 minecraft:blackstone
setblock 124 123 551 minecraft:smooth_basalt
setblock 125 123 550 minecraft:smooth_basalt
fill 125 123 551 125 126 551 minecraft:blackstone
setblock 126 123 549 minecraft:smooth_basalt
fill 126 123 550 126 126 550 minecraft:blackstone
fill 127 123 549 127 126 549 minecraft:blackstone
setblock 129 123 550 minecraft:blackstone
setblock 129 123 551 minecraft:smooth_basalt
fill 130 123 551 130 126 551 minecraft:blackstone
setblock 135 123 520 minecraft:smooth_basalt
fill 135 123 521 135 126 521 minecraft:blackstone
fill 135 123 523 135 123 524 minecraft:blackstone
setblock 135 123 525 minecraft:smooth_basalt
fill 135 123 526 135 126 526 minecraft:blackstone
fill 135 123 528 135 123 529 minecraft:blackstone
setblock 135 123 540 minecraft:smooth_basalt
fill 135 123 541 135 126 541 minecraft:blackstone
setblock 135 123 545 minecraft:smooth_basalt
fill 135 123 546 135 126 546 minecraft:blackstone
setblock 95 124 519 minecraft:smooth_basalt
fill 95 124 520 95 127 520 minecraft:blackstone
setblock 95 124 523 minecraft:blackstone
setblock 95 124 524 minecraft:smooth_basalt
fill 95 124 525 95 127 525 minecraft:blackstone
setblock 95 124 529 minecraft:smooth_basalt
fill 96 124 519 96 127 519 minecraft:blackstone
setblock 96 124 523 minecraft:smooth_basalt
fill 96 124 524 96 127 524 minecraft:blackstone
setblock 96 124 527 minecraft:blackstone
setblock 97 124 522 minecraft:smooth_basalt
fill 97 124 523 97 127 523 minecraft:blackstone
fill 100 124 511 100 126 511 minecraft:blackstone
fill 101 124 551 102 124 551 minecraft:blackstone
setblock 102 124 512 minecraft:smooth_basalt
fill 102 124 550 103 124 550 minecraft:blackstone
setblock 103 124 511 minecraft:smooth_basalt
fill 103 124 512 103 127 512 minecraft:blackstone
fill 103 124 546 105 125 546 minecraft:gold_block
setblock 103 124 551 minecraft:smooth_basalt
fill 104 124 511 104 127 511 minecraft:blackstone
fill 104 124 545 104 125 545 minecraft:gold_block
fill 104 124 547 104 125 547 minecraft:gold_block
setblock 104 124 550 minecraft:smooth_basalt
fill 104 124 551 104 127 551 minecraft:blackstone
setblock 105 124 549 minecraft:smooth_basalt
fill 105 124 550 105 127 550 minecraft:blackstone
fill 106 124 549 107 126 549 minecraft:blackstone
setblock 107 124 512 minecraft:smooth_basalt
setblock 108 124 511 minecraft:smooth_basalt
fill 108 124 512 108 127 512 minecraft:blackstone
setblock 108 124 550 minecraft:blackstone
setblock 108 124 551 minecraft:smooth_basalt
fill 109 124 511 109 127 511 minecraft:blackstone
setblock 109 124 550 minecraft:smooth_basalt
fill 109 124 551 109 127 551 minecraft:blackstone
fill 110 124 550 111 126 550 minecraft:blackstone
setblock 113 124 551 minecraft:smooth_basalt
fill 114 124 551 117 124 551 minecraft:blackstone
setblock 118 124 550 minecraft:blackstone
setblock 118 124 551 minecraft:smooth_basalt
setblock 119 124 550 minecraft:smooth_basalt
fill 119 124 551 119 127 551 minecraft:blackstone
setblock 120 124 549 minecraft:smooth_basalt
fill 120 124 550 123 124 550 minecraft:blackstone
fill 121 124 549 124 124 549 minecraft:blackstone
setblock 122 124 511 minecraft:blackstone
fill 122 124 548 125 124 548 minecraft:blackstone
setblock 123 124 511 minecraft:smooth_basalt
setblock 123 124 551 minecraft:smooth_basalt
fill 124 124 511 125 126 511 minecraft:blackstone
setblock 124 124 550 minecraft:smooth_basalt
fill 124 124 551 124 127 551 minecraft:blackstone
setblock 125 124 549 minecraft:smooth_basalt
fill 125 124 550 125 127 550 minecraft:blackstone
setblock 126 124 548 minecraft:smooth_basalt
fill 126 124 549 126 127 549 minecraft:blackstone
fill 128 124 549 128 125 549 minecraft:blackstone
setblock 128 124 551 minecraft:smooth_basalt
setblock 129 124 550 minecraft:smooth_basalt
fill 129 124 551 129 127 551 minecraft:blackstone
fill 134 124 523 134 124 524 minecraft:blackstone
setblock 134 124 525 minecraft:smooth_basalt
fill 134 124 526 134 127 526 minecraft:blackstone
fill 135 124 520 135 127 520 minecraft:blackstone
setblock 135 124 523 minecraft:blackstone
setblock 135 124 524 minecraft:smooth_basalt
fill 135 124 525 135 127 525 minecraft:blackstone
setblock 135 124 528 minecraft:blackstone
setblock 135 124 529 minecraft:smooth_basalt
fill 135 124 530 135 127 530 minecraft:blackstone
setblock 135 124 539 minecraft:smooth_basalt
fill 135 124 540 135 126 540 minecraft:blackstone
setblock 135 124 544 minecraft:smooth_basalt
fill 135 124 545 135 127 545 minecraft:blackstone
fill 135 124 547 135 125 547 minecraft:blackstone
setblock 95 125 518 minecraft:smooth_basalt
fill 95 125 519 95 128 519 minecraft:blackstone
setblock 95 125 523 minecraft:smooth_basalt
fill 95 125 524 95 128 524 minecraft:blackstone
setblock 95 125 528 minecraft:smooth_basalt
fill 95 125 529 95 127 530 minecraft:blackstone
setblock 96 125 522 minecraft:smooth_basalt
fill 96 125 523 96 128 523 minecraft:blackstone
setblock 96 125 527 minecraft:smooth_basalt
fill 96 125 528 96 128 528 minecraft:blackstone
setblock 97 125 521 minecraft:smooth_basalt
fill 97 125 522 97 128 522 minecraft:blackstone
fill 97 125 524 97 125 525 minecraft:blackstone
setblock 97 125 526 minecraft:smooth_basalt
fill 98 125 511 99 127 511 minecraft:blackstone
fill 99 125 551 101 125 551 minecraft:blackstone
setblock 101 125 512 minecraft:smooth_basalt
fill 101 125 550 102 125 550 minecraft:blackstone
setblock 102 125 511 minecraft:smooth_basalt
fill 102 125 512 102 128 512 minecraft:blackstone
setblock 102 125 551 minecraft:smooth_basalt
fill 103 125 511 103 128 511 minecraft:blackstone
setblock 103 125 549 minecraft:blackstone
setblock 103 125 550 minecraft:smooth_basalt
fill 103 125 551 103 128 551 minecraft:blackstone
setblock 104 125 513 minecraft:blackstone
setblock 104 125 549 minecraft:smooth_basalt
fill 104 125 550 104 128 550 minecraft:blackstone
setblock 105 125 513 minecraft:smooth_basalt
fill 105 125 549 105 128 549 minecraft:blackstone
setblock 106 125 512 minecraft:smooth_basalt
setblock 107 125 511 minecraft:smooth_basalt
fill 107 125 512 107 128 512 minecraft:blackstone
setblock 107 125 551 minecraft:smooth_basalt
fill 108 125 511 108 128 511 minecraft:blackstone
setblock 108 125 549 minecraft:blackstone
setblock 108 125 550 minecraft:smooth_basalt
fill 108 125 551 108 128 551 minecraft:blackstone
fill 109 125 512 109 126 512 minecraft:blackstone
setblock 109 125 549 minecraft:smooth_basalt
fill 109 125 550 109 128 550 minecraft:blackstone
setblock 111 125 551 minecraft:blackstone
setblock 112 125 511 minecraft:smooth_basalt
setblock 112 125 550 minecraft:blackstone
setblock 112 125 551 minecraft:smooth_basalt
setblock 113 125 550 minecraft:smooth_basalt
fill 113 125 551 116 125 551 minecraft:blackstone
fill 114 125 550 117 125 550 minecraft:blackstone
setblock 117 125 551 minecraft:smooth_basalt
setblock 118 125 549 minecraft:blackstone
setblock 118 125 550 minecraft:smooth_basalt
fill 118 125 551 118 128 551 minecraft:blackstone
setblock 119 125 549 minecraft:smooth_basalt
fill 119 125 550 122 125 550 minecraft:blackstone
fill 120 125 511 121 125 511 minecraft:blackstone
setblock 120 125 548 minecraft:smooth_basalt
fill 120 125 549 123 125 549 minecraft:blackstone
fill 121 125 548 124 125 548 minecraft:blackstone
setblock 122 125 511 minecraft:smooth_basalt
setblock 122 125 551 minecraft:smooth_basalt
fill 123 125 511 123 128 511 minecraft:blackstone
setblock 123 125 550 minecraft:smooth_basalt
fill 123 125 551 123 128 551 minecraft:blackstone
setblock 124 125 549 minecraft:smooth_basalt
fill 124 125 550 124 128 550 minecraft:blackstone
setblock 125 125 548 minecraft:smooth_basalt
fill 125 125 549 125 128 549 minecraft:blackstone
setblock 126 125 511 minecraft:blackstone
fill 126 125 548 127 126 548 minecraft:blackstone
setblock 127 125 550 minecraft:blackstone
setblock 127 125 551 minecraft:smooth_basalt
setblock 128 125 550 minecraft:smooth_basalt
fill 128 125 551 128 128 551 minecraft:blackstone
fill 129 125 550 129 128 550 minecraft:blackstone
fill 134 125 522 134 125 523 minecraft:blackstone
setblock 134 125 524 minecraft:smooth_basalt
fill 134 125 525 134 128 525 minecraft:blackstone
fill 134 125 527 134 125 528 minecraft:blackstone
setblock 135 125 523 minecraft:smooth_basalt
fill 135 125 524 135 128 524 minecraft:blackstone
setblock 135 125 528 minecraft:smooth_basalt
fill 135 125 529 135 128 529 minecraft:blackstone
fill 135 125 531 135 125 532 minecraft:blackstone
setblock 135 125 539 minecraft:blackstone
setblock 135 125 543 minecraft:smooth_basalt
fill 135 125 544 135 128 544 minecraft:blackstone
setblock 135 125 548 minecraft:smooth_basalt
setblock 95 126 517 minecraft:smooth_basalt
fill 95 126 518 95 129 518 minecraft:blackstone
setblock 95 126 522 minecraft:smooth_basalt
fill 95 126 523 95 129 523 minecraft:blackstone
setblock 95 126 526 minecraft:blackstone
setblock 95 126 527 minecraft:smooth_basalt
fill 95 126 528 95 129 528 minecraft:blackstone
setblock 95 126 531 minecraft:blackstone
fill 95 126 545 95 126 546 minecraft:blackstone
setblock 95 126 547 minecraft:smooth_basalt
setblock 96 126 521 minecraft:smooth_basalt
fill 96 126 522 96 129 522 minecraft:blackstone
setblock 96 126 526 minecraft:smooth_basalt
fill 96 126 527 97 128 527 minecraft:blackstone
fill 96 126 529 96 127 529 minecraft:blackstone
fill 97 126 511 97 129 511 minecraft:blackstone
fill 97 126 521 97 128 521 minecraft:blackstone
setblock 97 126 524 minecraft:blackstone
setblock 97 126 525 minecraft:smooth_basalt
fill 97 126 526 97 129 526 minecraft:blackstone
fill 97 126 551 100 126 551 minecraft:blackstone
fill 99 126 550 101 126 550 minecraft:blackstone
setblock 100 126 512 minecraft:smooth_basalt
setblock 101 126 511 minecraft:smooth_basalt
fill 101 126 512 101 129 512 minecraft:blackstone
fill 101 126 549 102 126 549 minecraft:blackstone
setblock 101 126 551 minecraft:smooth_basalt
fill 102 126 511 102 129 511 minecraft:blackstone
setblock 102 126 550 minecraft:smooth_basalt
fill 102 126 551 102 129 551 minecraft:blackstone
setblock 103 126 513 minecraft:blackstone
setblock 103 126 549 minecraft:smooth_basalt
fill 103 126 550 103 129 550 minecraft:blackstone
setblock 104 126 513 minecraft:smooth_basalt
fill 104 126 549 104 129 549 minecraft:blackstone
setblock 105 126 512 minecraft:smooth_basalt
fill 105 126 513 105 128 513 minecraft:blackstone
setblock 106 126 511 minecraft:smooth_basalt
fill 106 126 512 106 129 512 minecraft:blackstone
setblock 106 126 551 minecraft:smooth_basalt
fill 107 126 511 107 129 511 minecraft:blackstone
setblock 107 126 550 minecraft:smooth_basalt
fill 107 126 551 107 129 551 minecraft:blackstone
setblock 108 126 549 minecraft:smooth_basalt
fill 108 126 550 108 129 550 minecraft:blackstone
fill 109 126 549 110 128 549 minecraft:blackstone
setblock 111 126 511 minecraft:smooth_basalt
setblock 111 126 551 minecraft:smooth_basalt
fill 112 126 511 112 129 511 minecraft:blackstone
setblock 112 126 550 minecraft:smooth_basalt
fill 112 126 551 115 126 551 minecraft:blackstone
fill 113 126 550 116 126 550 minecraft:blackstone
fill 116 126 549 117 126 549 minecraft:blackstone
setblock 116 126 551 minecraft:smooth_basalt
setblock 117 126 550 minecraft:smooth_basalt
fill 117 126 551 117 129 551 minecraft:blackstone
fill 118 126 511 120 126 511 minecraft:blackstone
fill 118 126 544 118 126 548 minecraft:blackstone
setblock 118 126 549 minecraft:smooth_basalt
fill 118 126 550 121 126 550 minecraft:blackstone
fill 119 126 544 122 127 547 minecraft:blackstone
setblock 119 126 548 minecraft:smooth_basalt
fill 119 126 549 122 126 549 minecraft:blackstone
fill 120 126 548 123 126 548 minecraft:blackstone
setblock 121 126 511 minecraft:smooth_basalt
setblock 121 126 551 minecraft:smooth_basalt
fill 122 126 511 122 129 511 minecraft:blackstone
setblock 122 126 550 minecraft:smooth_basalt
fill 122 126 551 122 129 551 minecraft:blackstone
fill 123 126 547 124 126 547 minecraft:blackstone
setblock 123 126 549 minecraft:smooth_basalt
fill 123 126 550 123 129 550 minecraft:blackstone
setblock 124 126 548 minecraft:smooth_basalt
fill 124 126 549 124 129 549 minecraft:blackstone
fill 125 126 548 125 129 548 minecraft:blackstone
setblock 126 126 511 minecraft:smooth_basalt
setblock 126 126 551 minecraft:smooth_basalt
setblock 127 126 550 minecraft:smooth_basalt
fill 127 126 551 127 129 551 minecraft:blackstone
setblock 128 126 549 minecraft:smooth_basalt
fill 128 126 550 128 129 550 minecraft:blackstone
setblock 131 126 551 minecraft:smooth_basalt
setblock 134 126 522 minecraft:blackstone
setblock 134 126 523 minecraft:smooth_basalt
fill 134 126 524 134 129 524 minecraft:blackstone
setblock 134 126 527 minecraft:blackstone
setblock 134 126 528 minecraft:smooth_basalt
fill 134 126 529 134 128 530 minecraft:blackstone
fill 135 126 519 135 127 519 minecraft:blackstone
setblock 135 126 522 minecraft:smooth_basalt
fill 135 126 523 135 129 523 minecraft:blackstone
setblock 135 126 527 minecraft:smooth_basalt
fill 135 126 528 135 129 528 minecraft:blackstone
setblock 135 126 531 minecraft:blackstone
setblock 135 126 532 minecraft:smooth_basalt
fill 135 126 533 135 128 534 minecraft:blackstone
setblock 135 126 542 minecraft:smooth_basalt
fill 135 126 543 135 128 543 minecraft:blackstone
setblock 135 126 547 minecraft:smooth_basalt
fill 135 126 548 135 129 548 minecraft:blackstone
setblock 95 127 516 minecraft:smooth_basalt
fill 95 127 517 95 130 517 minecraft:blackstone
setblock 95 127 521 minecraft:smooth_basalt
fill 95 127 522 95 130 522 minecraft:blackstone
setblock 95 127 526 minecraft:smooth_basalt
fill 95 127 527 95 130 527 minecraft:blackstone
setblock 95 127 531 minecraft:smooth_basalt
fill 95 127 532 95 130 532 minecraft:blackstone
setblock 95 127 545 minecraft:blackstone
setblock 95 127 546 minecraft:smooth_basalt
fill 95 127 547 95 127 550 minecraft:blackstone
fill 96 127 511 96 130 511 minecraft:blackstone
setblock 96 127 520 minecraft:smooth_basalt
fill 96 127 521 96 130 521 minecraft:blackstone
setblock 96 127 525 minecraft:smooth_basalt
fill 96 127 526 96 130 526 minecraft:blackstone
setblock 96 127 530 minecraft:smooth_basalt
fill 96 127 551 99 127 551 minecraft:blackstone
setblock 97 127 524 minecraft:smooth_basalt
fill 97 127 525 97 130 525 minecraft:blackstone
setblock 97 127 528 minecraft:blackstone
fill 98 127 550 100 127 550 minecraft:blackstone
setblock 99 127 512 minecraft:smooth_basalt
setblock 100 127 511 minecraft:smooth_basalt
fill 100 127 512 100 130 512 minecraft:blackstone
fill 100 127 549 101 127 549 minecraft:blackstone
setblock 100 127 551 minecraft:smooth_basalt
fill 101 127 511 101 130 511 minecraft:blackstone
fill 101 127 513 102 127 513 minecraft:blackstone
setblock 101 127 550 minecraft:smooth_basalt
fill 101 127 551 101 130 551 minecraft:blackstone
setblock 102 127 549 minecraft:smooth_basalt
fill 102 127 550 102 130 550 minecraft:blackstone
setblock 103 127 513 minecraft:smooth_basalt
setblock 103 127 548 minecraft:smooth_basalt
fill 103 127 549 103 130 549 minecraft:blackstone
setblock 104 127 512 minecraft:smooth_basalt
fill 104 127 513 104 130 513 minecraft:blackstone
fill 104 127 548 106 128 548 minecraft:blackstone
setblock 105 127 511 minecraft:smooth_basalt
fill 105 127 512 105 130 512 minecraft:blackstone
setblock 105 127 551 minecraft:smooth_basalt
fill 106 127 511 106 130 511 minecraft:blackstone
setblock 106 127 549 minecraft:blackstone
setblock 106 127 550 minecraft:smooth_basalt
fill 106 127 551 106 130 551 minecraft:blackstone
setblock 107 127 549 minecraft:smooth_basalt
fill 107 127 550 107 130 550 minecraft:blackstone
fill 108 127 549 108 130 549 minecraft:blackstone
setblock 109 127 512 minecraft:smooth_basalt
setblock 110 127 511 minecraft:smooth_basalt
setblock 110 127 550 minecraft:blackstone
setblock 110 127 551 minecraft:smooth_basalt
fill 111 127 511 111 130 511 minecraft:blackstone
setblock 111 127 549 minecraft:blackstone
setblock 111 127 550 minecraft:smooth_basalt
fill 111 127 551 114 127 551 minecraft:blackstone
setblock 112 127 549 minecraft:smooth_basalt
fill 112 127 550 115 127 550 minecraft:blackstone
fill 113 127 511 114 127 511 minecraft:blackstone
fill 114 127 549 116 127 549 minecraft:blackstone
setblock 115 127 551 minecraft:smooth_basalt
fill 116 127 511 119 127 511 minecraft:blackstone
setblock 116 127 550 minecraft:smooth_basalt
fill 116 127 551 116 130 551 minecraft:blackstone
setblock 117 127 549 minecraft:smooth_basalt
fill 117 127 550 120 127 550 minecraft:blackstone
fill 118 127 544 118 127 547 minecraft:blackstone
setblock 118 127 548 minecraft:smooth_basalt
fill 118 127 549 121 127 549 minecraft:blackstone
fill 119 127 548 122 127 548 minecraft:blackstone
setblock 120 127 511 minecraft:smooth_basalt
setblock 120 127 551 minecraft:smooth_basalt
fill 121 127 511 121 130 511 minecraft:blackstone
setblock 121 127 550 minecraft:smooth_basalt
fill 121 127 551 121 130 551 minecraft:blackstone
setblock 122 127 549 minecraft:smooth_basalt
fill 122 127 550 122 130 550 minecraft:blackstone
setblock 123 127 547 minecraft:blackstone
setblock 123 127 548 minecraft:smooth_basalt
fill 123 127 549 123 130 549 minecraft:blackstone
setblock 124 127 511 minecraft:blackstone
setblock 124 127 547 minecraft:smooth_basalt
fill 124 127 548 124 130 548 minecraft:blackstone
setblock 125 127 511 minecraft:smooth_basalt
setblock 125 127 551 minecraft:smooth_basalt
fill 126 127 511 127 128 511 minecraft:blackstone
fill 126 127 548 126 128 548 minecraft:blackstone
setblock 126 127 550 minecraft:smooth_basalt
fill 126 127 551 126 130 551 minecraft:blackstone
setblock 127 127 549 minecraft:smooth_basalt
fill 127 127 550 127 130 550 minecraft:blackstone
fill 128 127 549 128 128 549 minecraft:blackstone
setblock 130 127 551 minecraft:smooth_basalt
fill 131 127 551 131 129 551 minecraft:blackstone
setblock 134 127 522 minecraft:smooth_basalt
fill 134 127 523 134 129 523 minecraft:blackstone
setblock 134 127 527 minecraft:smooth_basalt
fill 134 127 528 134 130 528 minecraft:blackstone
setblock 134 127 531 minecraft:blackstone
setblock 135 127 521 minecraft:smooth_basalt
fill 135 127 522 135 130 522 minecraft:blackstone
setblock 135 127 526 minecraft:smooth_basalt
fill 135 127 527 135 130 527 minecraft:blackstone
setblock 135 127 531 minecraft:smooth_basalt
fill 135 127 532 135 130 532 minecraft:blackstone
setblock 135 127 541 minecraft:smooth_basalt
fill 135 127 542 135 128 542 minecraft:blackstone
setblock 135 127 546 minecraft:smooth_basalt
fill 135 127 547 135 130 547 minecraft:blackstone
fill 135 127 549 135 128 549 minecraft:blackstone
fill 95 128 511 95 129 513 minecraft:blackstone
setblock 95 128 515 minecraft:smooth_basalt
fill 95 128 516 95 131 516 minecraft:blackstone
setblock 95 128 520 minecraft:smooth_basalt
fill 95 128 521 95 131 521 minecraft:blackstone
setblock 95 128 525 minecraft:smooth_basalt
fill 95 128 526 95 131 526 minecraft:blackstone
setblock 95 128 529 minecraft:blackstone
setblock 95 128 530 minecraft:smooth_basalt
fill 95 128 531 95 131 531 minecraft:blackstone
setblock 95 128 545 minecraft:smooth_basalt
fill 95 128 546 95 128 549 minecraft:blackstone
setblock 95 128 550 minecraft:smooth_basalt
fill 95 128 551 98 128 551 minecraft:blackstone
setblock 96 128 519 minecraft:smooth_basalt
fill 96 128 520 96 130 520 minecraft:blackstone
setblock 96 128 524 minecraft:smooth_basalt
fill 96 128 525 96 131 525 minecraft:blackstone
setblock 96 128 529 minecraft:smooth_basalt
fill 96 128 530 96 131 530 minecraft:blackstone
setblock 97 128 513 minecraft:light[level=12]
setblock 97 128 523 minecraft:smooth_basalt
fill 97 128 524 97 130 524 minecraft:blackstone
setblock 97 128 528 minecraft:smooth_basalt
setblock 97 128 529 minecraft:light[level=12]
setblock 97 128 537 minecraft:light[level=12]
setblock 97 128 545 minecraft:light[level=12]
fill 97 128 550 99 128 550 minecraft:blackstone
setblock 98 128 511 minecraft:blackstone
setblock 98 128 512 minecraft:smooth_basalt
setblock 99 128 511 minecraft:smooth_basalt
fill 99 128 512 99 131 512 minecraft:blackstone
fill 99 128 549 100 128 549 minecraft:blackstone
setblock 99 128 551 minecraft:smooth_basalt
fill 100 128 511 100 131 511 minecraft:blackstone
fill 100 128 513 101 128 513 minecraft:blackstone
setblock 100 128 550 minecraft:smooth_basalt
fill 100 128 551 100 131 551 minecraft:blackstone
setblock 101 128 549 minecraft:smooth_basalt
fill 101 128 550 101 131 550 minecraft:blackstone
setblock 102 128 513 minecraft:smooth_basalt
fill 102 128 549 102 131 549 minecraft:blackstone
setblock 103 128 512 minecraft:smooth_basalt
fill 103 128 513 103 131 513 minecraft:blackstone
fill 103 128 548 103 129 548 minecraft:blackstone
setblock 104 128 511 minecraft:smooth_basalt
fill 104 128 512 104 131 512 minecraft:blackstone
setblock 104 128 551 minecraft:smooth_basalt
fill 105 128 511 105 131 511 minecraft:blackstone
setblock 105 128 521 minecraft:light[level=12]
setblock 105 128 529 minecraft:light[level=12]
setblock 105 128 537 minecraft:light[level=12]
setblock 105 128 545 minecraft:light[level=12]
setblock 105 128 550 minecraft:smooth_basalt
fill 105 128 551 105 131 551 minecraft:blackstone
setblock 106 128 549 minecraft:smooth_basalt
fill 106 128 550 106 131 550 minecraft:blackstone
fill 107 128 549 107 131 549 minecraft:blackstone
setblock 108 128 512 minecraft:smooth_basalt
setblock 109 128 511 minecraft:smooth_basalt
setblock 109 128 551 minecraft:smooth_basalt
fill 110 128 511 110 131 511 minecraft:blackstone
setblock 110 128 550 minecraft:smooth_basalt
fill 110 128 551 113 128 551 minecraft:blackstone
setblock 111 128 549 minecraft:smooth_basalt
fill 111 128 550 114 128 550 minecraft:blackstone
fill 112 128 549 115 128 549 minecraft:blackstone
setblock 113 128 511 minecraft:blackstone
setblock 113 128 513 minecraft:light[level=12]
setblock 113 128 521 minecraft:light[level=12]
setblock 113 128 529 minecraft:light[level=12]
setblock 113 128 537 minecraft:light[level=12]
setblock 113 128 545 minecraft:light[level=12]
setblock 114 128 511 minecraft:smooth_basalt
setblock 114 128 551 minecraft:smooth_basalt
fill 115 128 511 118 128 511 minecraft:blackstone
setblock 115 128 550 minecraft:smooth_basalt
fill 115 128 551 115 131 551 minecraft:blackstone
setblock 116 128 549 minecraft:smooth_basalt
fill 116 128 550 119 128 550 minecraft:blackstone
setblock 117 128 548 minecraft:smooth_basalt
fill 117 128 549 120 128 549 minecraft:blackstone
fill 118 128 548 121 128 548 minecraft:blackstone
setblock 119 128 511 minecraft:smooth_basalt
fill 119 128 545 120 129 547 minecraft:smooth_basalt
setblock 119 128 551 minecraft:smooth_basalt
fill 120 128 511 120 131 511 minecraft:blackstone
setblock 120 128 550 minecraft:smooth_basalt
fill 120 128 551 120 131 551 minecraft:blackstone
setblock 121 128 513 minecraft:light[level=12]
setblock 121 128 521 minecraft:light[level=12]
setblock 121 128 529 minecraft:light[level=12]
setblock 121 128 537 minecraft:light[level=12]
fill 121 128 545 121 129 546 minecraft:smooth_basalt
fill 121 128 547 122 128 547 minecraft:blackstone
setblock 121 128 549 minecraft:smooth_basalt
fill 121 128 550 121 131 550 minecraft:blackstone
setblock 122 128 548 minecraft:smooth_basalt
fill 122 128 549 122 131 549 minecraft:blackstone
schedule function dropper:buildpart/122_5 1t
