fill 108 279 294 108 279 295 minecraft:red_concrete
fill 108 279 300 110 279 300 minecraft:red_concrete
setblock 108 279 302 minecraft:red_concrete
fill 108 279 303 108 279 304 minecraft:orange_terracotta
setblock 108 279 305 minecraft:white_concrete
fill 108 279 306 110 279 306 minecraft:light_gray_concrete
setblock 108 279 309 minecraft:white_concrete
fill 108 279 310 110 279 310 minecraft:light_gray_concrete
setblock 108 279 313 minecraft:white_concrete
fill 108 279 314 110 279 314 minecraft:light_gray_concrete
setblock 109 279 276 minecraft:white_concrete
fill 109 279 277 109 279 279 minecraft:light_gray_concrete
setblock 109 279 280 minecraft:white_concrete
fill 109 279 281 109 279 283 minecraft:light_gray_concrete
setblock 109 279 284 minecraft:white_concrete
fill 109 279 285 109 279 286 minecraft:orange_terracotta
fill 109 279 287 110 279 287 minecraft:yellow_wool
setblock 109 279 291 minecraft:yellow_wool
fill 109 279 292 109 279 293 minecraft:red_terracotta
fill 109 279 294 110 279 294 minecraft:red_concrete
setblock 109 279 295 minecraft:red_terracotta
setblock 109 279 298 minecraft:yellow_wool
fill 109 279 299 110 279 299 minecraft:red_concrete
fill 109 279 302 110 279 303 minecraft:yellow_wool
fill 109 279 304 109 279 305 minecraft:orange_terracotta
setblock 109 279 308 minecraft:white_concrete
fill 109 279 309 111 279 309 minecraft:light_gray_concrete
setblock 109 279 312 minecraft:white_concrete
fill 109 279 313 111 279 313 minecraft:light_gray_concrete
setblock 109 279 316 minecraft:white_concrete
fill 110 279 276 110 279 278 minecraft:light_gray_concrete
setblock 110 279 279 minecraft:white_concrete
fill 110 279 280 110 279 282 minecraft:light_gray_concrete
setblock 110 279 283 minecraft:white_concrete
setblock 110 279 284 minecraft:light_gray_concrete
setblock 110 279 285 minecraft:orange_terracotta
setblock 110 279 286 minecraft:yellow_wool
fill 110 279 291 111 279 291 minecraft:red_terracotta
setblock 110 279 292 minecraft:brown_terracotta
fill 110 279 293 111 279 293 minecraft:red_terracotta
setblock 110 279 295 minecraft:red_concrete
setblock 110 279 298 minecraft:brown_terracotta
setblock 110 279 304 minecraft:yellow_wool
setblock 110 279 305 minecraft:orange_terracotta
setblock 110 279 307 minecraft:white_concrete
fill 110 279 308 112 279 308 minecraft:light_gray_concrete
setblock 110 279 311 minecraft:white_concrete
fill 110 279 312 112 279 312 minecraft:light_gray_concrete
setblock 110 279 315 minecraft:white_concrete
fill 110 279 316 112 279 316 minecraft:light_gray_concrete
fill 111 279 276 111 279 277 minecraft:light_gray_concrete
setblock 111 279 278 minecraft:white_concrete
fill 111 279 279 111 279 281 minecraft:light_gray_concrete
setblock 111 279 282 minecraft:white_concrete
setblock 111 279 283 minecraft:light_gray_concrete
fill 111 279 284 113 279 284 minecraft:orange_terracotta
fill 111 279 285 112 279 287 minecraft:red_concrete
fill 111 279 288 112 279 290 minecraft:yellow_wool
setblock 111 279 292 minecraft:red_terracotta
fill 111 279 294 112 279 295 minecraft:yellow_wool
fill 111 279 296 111 279 298 minecraft:red_concrete
fill 111 279 299 111 279 301 minecraft:yellow_wool
fill 111 279 302 111 279 305 minecraft:red_concrete
fill 111 279 306 113 279 306 minecraft:orange_terracotta
setblock 111 279 307 minecraft:light_gray_concrete
setblock 111 279 310 minecraft:white_concrete
fill 111 279 311 113 279 311 minecraft:light_gray_concrete
setblock 111 279 314 minecraft:white_concrete
fill 111 279 315 113 279 315 minecraft:light_gray_concrete
setblock 112 279 276 minecraft:light_gray_concrete
setblock 112 279 277 minecraft:white_concrete
fill 112 279 278 112 279 280 minecraft:light_gray_concrete
setblock 112 279 281 minecraft:white_concrete
fill 112 279 282 114 279 282 minecraft:light_gray_concrete
setblock 112 279 283 minecraft:brown_terracotta
fill 112 279 291 112 279 292 minecraft:red_concrete
setblock 112 279 293 minecraft:brown_terracotta
setblock 112 279 296 minecraft:red_concrete
setblock 112 279 297 minecraft:brown_terracotta
setblock 112 279 298 minecraft:red_concrete
fill 112 279 299 113 279 301 minecraft:red_terracotta
fill 112 279 302 112 279 304 minecraft:red_concrete
setblock 112 279 305 minecraft:yellow_wool
setblock 112 279 307 minecraft:brown_terracotta
setblock 112 279 309 minecraft:white_concrete
fill 112 279 310 114 279 310 minecraft:light_gray_concrete
setblock 112 279 313 minecraft:white_concrete
fill 112 279 314 114 279 314 minecraft:light_gray_concrete
setblock 113 279 276 minecraft:white_concrete
fill 113 279 277 113 279 279 minecraft:light_gray_concrete
setblock 113 279 280 minecraft:white_concrete
fill 113 279 281 115 279 281 minecraft:light_gray_concrete
fill 113 279 283 121 279 283 minecraft:orange_terracotta
fill 113 279 285 113 279 286 minecraft:brown_terracotta
fill 113 279 287 113 279 290 minecraft:red_concrete
fill 113 279 291 113 279 292 minecraft:yellow_wool
setblock 113 279 293 minecraft:red_concrete
fill 113 279 294 113 279 296 minecraft:white_concrete
fill 113 279 297 113 279 298 minecraft:yellow_wool
setblock 113 279 302 minecraft:red_concrete
fill 113 279 303 115 279 303 minecraft:yellow_wool
fill 113 279 304 113 279 305 minecraft:brown_terracotta
fill 113 279 307 121 279 307 minecraft:orange_terracotta
setblock 113 279 308 minecraft:white_concrete
fill 113 279 309 115 279 309 minecraft:light_gray_concrete
setblock 113 279 312 minecraft:white_concrete
fill 113 279 313 115 279 313 minecraft:light_gray_concrete
setblock 113 279 316 minecraft:white_concrete
fill 114 279 276 114 279 278 minecraft:light_gray_concrete
setblock 114 279 279 minecraft:white_concrete
fill 114 279 280 116 279 280 minecraft:light_gray_concrete
fill 114 279 284 115 279 284 minecraft:red_concrete
fill 114 279 285 114 279 287 minecraft:yellow_wool
setblock 114 279 288 minecraft:brown_terracotta
fill 114 279 289 114 279 290 minecraft:red_concrete
fill 114 279 291 115 279 291 minecraft:yellow_wool
fill 114 279 292 114 279 294 minecraft:white_concrete
fill 114 279 296 114 279 298 minecraft:white_concrete
setblock 114 279 299 minecraft:red_concrete
setblock 114 279 300 minecraft:red_terracotta
fill 114 279 301 115 279 301 minecraft:red_concrete
setblock 114 279 302 minecraft:brown_terracotta
fill 114 279 304 115 279 304 minecraft:yellow_wool
fill 114 279 305 115 279 306 minecraft:red_concrete
fill 114 279 308 116 279 308 minecraft:light_gray_concrete
setblock 114 279 311 minecraft:white_concrete
fill 114 279 312 116 279 312 minecraft:light_gray_concrete
setblock 114 279 315 minecraft:white_concrete
fill 114 279 316 116 279 316 minecraft:light_gray_concrete
fill 115 279 276 115 279 277 minecraft:light_gray_concrete
setblock 115 279 278 minecraft:white_concrete
fill 115 279 279 117 279 279 minecraft:light_gray_concrete
setblock 115 279 282 minecraft:white_concrete
fill 115 279 285 115 279 286 minecraft:yellow_wool
fill 115 279 287 115 279 289 minecraft:red_concrete
setblock 115 279 290 minecraft:brown_terracotta
fill 115 279 292 116 279 292 minecraft:white_concrete
fill 115 279 298 116 279 298 minecraft:white_concrete
setblock 115 279 299 minecraft:red_terracotta
setblock 115 279 300 minecraft:brown_terracotta
fill 115 279 302 117 279 302 minecraft:red_concrete
setblock 115 279 310 minecraft:white_concrete
fill 115 279 311 117 279 311 minecraft:light_gray_concrete
setblock 115 279 314 minecraft:white_concrete
fill 115 279 315 117 279 315 minecraft:light_gray_concrete
setblock 116 279 276 minecraft:light_gray_concrete
setblock 116 279 277 minecraft:white_concrete
fill 116 279 278 118 279 278 minecraft:light_gray_concrete
setblock 116 279 281 minecraft:white_concrete
setblock 116 279 282 minecraft:light_gray_concrete
fill 116 279 284 117 279 284 minecraft:yellow_wool
fill 116 279 285 117 279 287 minecraft:red_concrete
fill 116 279 288 116 279 289 minecraft:yellow_wool
fill 116 279 290 118 279 290 minecraft:red_terracotta
fill 116 279 291 118 279 291 minecraft:white_concrete
fill 116 279 299 118 279 299 minecraft:white_concrete
fill 116 279 300 117 279 300 minecraft:red_terracotta
fill 116 279 301 117 279 301 minecraft:yellow_wool
fill 116 279 303 117 279 304 minecraft:red_concrete
fill 116 279 305 117 279 306 minecraft:yellow_wool
setblock 116 279 309 minecraft:white_concrete
fill 116 279 310 118 279 310 minecraft:light_gray_concrete
setblock 116 279 313 minecraft:white_concrete
fill 116 279 314 118 279 314 minecraft:light_gray_concrete
setblock 117 279 276 minecraft:white_concrete
fill 117 279 277 119 279 277 minecraft:light_gray_concrete
setblock 117 279 280 minecraft:white_concrete
fill 117 279 281 119 279 281 minecraft:light_gray_concrete
setblock 117 279 288 minecraft:yellow_wool
setblock 117 279 289 minecraft:red_terracotta
fill 117 279 309 119 279 309 minecraft:light_gray_concrete
setblock 117 279 312 minecraft:white_concrete
fill 117 279 313 119 279 313 minecraft:light_gray_concrete
setblock 117 279 316 minecraft:white_concrete
fill 118 279 276 120 279 276 minecraft:light_gray_concrete
setblock 118 279 279 minecraft:white_concrete
fill 118 279 280 120 279 280 minecraft:light_gray_concrete
setblock 118 279 282 minecraft:light_gray_concrete
fill 118 279 284 120 279 284 minecraft:red_concrete
fill 118 279 285 119 279 287 minecraft:yellow_wool
fill 118 279 288 119 279 289 minecraft:red_concrete
fill 118 279 292 120 279 292 minecraft:white_concrete
fill 118 279 298 120 279 298 minecraft:white_concrete
fill 118 279 300 118 279 301 minecraft:red_concrete
fill 118 279 302 119 279 304 minecraft:yellow_wool
fill 118 279 305 120 279 306 minecraft:red_concrete
fill 118 279 308 120 279 308 minecraft:light_gray_concrete
setblock 118 279 311 minecraft:white_concrete
fill 118 279 312 120 279 312 minecraft:light_gray_concrete
setblock 118 279 315 minecraft:white_concrete
fill 118 279 316 120 279 316 minecraft:light_gray_concrete
setblock 119 279 278 minecraft:white_concrete
fill 119 279 279 121 279 279 minecraft:light_gray_concrete
setblock 119 279 282 minecraft:white_concrete
setblock 119 279 290 minecraft:brown_terracotta
fill 119 279 291 122 279 291 minecraft:red_terracotta
fill 119 279 299 120 279 299 minecraft:red_concrete
setblock 119 279 300 minecraft:brown_terracotta
fill 119 279 301 120 279 301 minecraft:red_concrete
setblock 119 279 310 minecraft:white_concrete
fill 119 279 311 121 279 311 minecraft:light_gray_concrete
setblock 119 279 314 minecraft:white_concrete
fill 119 279 315 121 279 315 minecraft:light_gray_concrete
setblock 120 279 277 minecraft:white_concrete
fill 120 279 278 122 279 278 minecraft:light_gray_concrete
setblock 120 279 281 minecraft:white_concrete
fill 120 279 282 122 279 282 minecraft:light_gray_concrete
fill 120 279 285 120 279 287 minecraft:red_concrete
setblock 120 279 288 minecraft:brown_terracotta
fill 120 279 289 120 279 290 minecraft:red_concrete
fill 120 279 293 120 279 294 minecraft:white_concrete
fill 120 279 296 120 279 297 minecraft:white_concrete
setblock 120 279 300 minecraft:red_concrete
setblock 120 279 302 minecraft:brown_terracotta
fill 120 279 303 120 279 304 minecraft:red_concrete
setblock 120 279 309 minecraft:white_concrete
fill 120 279 310 122 279 310 minecraft:light_gray_concrete
setblock 120 279 313 minecraft:white_concrete
fill 120 279 314 122 279 314 minecraft:light_gray_concrete
setblock 121 279 276 minecraft:white_concrete
fill 121 279 277 123 279 277 minecraft:light_gray_concrete
setblock 121 279 280 minecraft:white_concrete
fill 121 279 281 123 279 281 minecraft:light_gray_concrete
fill 121 279 284 123 279 284 minecraft:orange_terracotta
fill 121 279 285 121 279 286 minecraft:brown_terracotta
fill 121 279 287 122 279 287 minecraft:red_concrete
fill 121 279 288 121 279 290 minecraft:yellow_wool
fill 121 279 292 121 279 293 minecraft:red_terracotta
fill 121 279 294 121 279 296 minecraft:white_concrete
fill 121 279 297 121 279 298 minecraft:red_concrete
fill 121 279 299 121 279 301 minecraft:yellow_wool
fill 121 279 302 122 279 303 minecraft:red_concrete
fill 121 279 304 121 279 305 minecraft:brown_terracotta
fill 121 279 306 123 279 306 minecraft:orange_terracotta
setblock 121 279 308 minecraft:white_concrete
fill 121 279 309 123 279 309 minecraft:light_gray_concrete
setblock 121 279 312 minecraft:white_concrete
fill 121 279 313 123 279 313 minecraft:light_gray_concrete
setblock 121 279 316 minecraft:white_concrete
fill 122 279 276 124 279 276 minecraft:light_gray_concrete
setblock 122 279 279 minecraft:white_concrete
fill 122 279 280 124 279 280 minecraft:light_gray_concrete
setblock 122 279 283 minecraft:brown_terracotta
fill 122 279 285 122 279 286 minecraft:red_concrete
fill 122 279 288 122 279 289 minecraft:yellow_wool
fill 122 279 290 125 279 290 minecraft:red_concrete
fill 122 279 292 123 279 292 minecraft:red_terracotta
setblock 122 279 293 minecraft:brown_terracotta
fill 122 279 294 122 279 295 minecraft:yellow_wool
fill 122 279 296 123 279 296 minecraft:red_concrete
setblock 122 279 297 minecraft:brown_terracotta
fill 122 279 298 122 279 299 minecraft:red_concrete
fill 122 279 300 122 279 301 minecraft:yellow_wool
setblock 122 279 304 minecraft:red_concrete
setblock 122 279 305 minecraft:yellow_wool
setblock 122 279 307 minecraft:brown_terracotta
fill 122 279 308 124 279 308 minecraft:light_gray_concrete
setblock 122 279 311 minecraft:white_concrete
fill 122 279 312 124 279 312 minecraft:light_gray_concrete
setblock 122 279 315 minecraft:white_concrete
fill 122 279 316 124 279 316 minecraft:light_gray_concrete
setblock 123 279 278 minecraft:white_concrete
fill 123 279 279 125 279 279 minecraft:light_gray_concrete
setblock 123 279 282 minecraft:white_concrete
fill 123 279 283 125 279 283 minecraft:light_gray_concrete
setblock 123 279 285 minecraft:red_concrete
fill 123 279 286 124 279 287 minecraft:yellow_wool
fill 123 279 288 125 279 289 minecraft:red_concrete
setblock 123 279 291 minecraft:yellow_wool
fill 123 279 293 125 279 293 minecraft:red_terracotta
fill 123 279 294 123 279 295 minecraft:red_concrete
fill 123 279 297 123 279 298 minecraft:yellow_wool
setblock 123 279 299 minecraft:red_concrete
fill 123 279 300 125 279 300 minecraft:red_terracotta
setblock 123 279 301 minecraft:red_concrete
fill 123 279 302 124 279 304 minecraft:yellow_wool
setblock 123 279 305 minecraft:red_concrete
fill 123 279 307 125 279 307 minecraft:light_gray_concrete
setblock 123 279 310 minecraft:white_concrete
fill 123 279 311 125 279 311 minecraft:light_gray_concrete
setblock 123 279 314 minecraft:white_concrete
fill 123 279 315 125 279 315 minecraft:light_gray_concrete
setblock 124 279 277 minecraft:white_concrete
fill 124 279 278 126 279 278 minecraft:light_gray_concrete
setblock 124 279 281 minecraft:white_concrete
fill 124 279 282 126 279 282 minecraft:light_gray_concrete
setblock 124 279 284 minecraft:light_gray_concrete
fill 124 279 285 125 279 285 minecraft:orange_terracotta
setblock 124 279 291 minecraft:red_terracotta
setblock 124 279 292 minecraft:brown_terracotta
fill 124 279 294 125 279 296 minecraft:red_terracotta
setblock 124 279 297 minecraft:yellow_wool
setblock 124 279 298 minecraft:brown_terracotta
fill 124 279 299 125 279 299 minecraft:red_terracotta
fill 124 279 301 125 279 301 minecraft:red_terracotta
fill 124 279 305 125 279 305 minecraft:orange_terracotta
fill 124 279 306 126 279 306 minecraft:light_gray_concrete
setblock 124 279 309 minecraft:white_concrete
fill 124 279 310 126 279 310 minecraft:light_gray_concrete
setblock 124 279 313 minecraft:white_concrete
fill 124 279 314 126 279 314 minecraft:light_gray_concrete
setblock 125 279 276 minecraft:white_concrete
fill 125 279 277 127 279 277 minecraft:light_gray_concrete
setblock 125 279 280 minecraft:white_concrete
fill 125 279 281 127 279 281 minecraft:light_gray_concrete
setblock 125 279 284 minecraft:white_concrete
fill 125 279 286 126 279 286 minecraft:orange_terracotta
setblock 125 279 287 minecraft:red_concrete
setblock 125 279 291 minecraft:red_concrete
setblock 125 279 292 minecraft:red_terracotta
fill 125 279 297 127 279 298 minecraft:red_concrete
fill 125 279 302 125 279 303 minecraft:red_concrete
fill 125 279 304 126 279 304 minecraft:orange_terracotta
setblock 125 279 308 minecraft:white_concrete
fill 125 279 309 127 279 309 minecraft:light_gray_concrete
setblock 125 279 312 minecraft:white_concrete
fill 125 279 313 127 279 313 minecraft:light_gray_concrete
setblock 125 279 316 minecraft:white_concrete
fill 126 279 276 128 279 276 minecraft:light_gray_concrete
setblock 126 279 279 minecraft:white_concrete
fill 126 279 280 128 279 280 minecraft:light_gray_concrete
setblock 126 279 283 minecraft:white_concrete
fill 126 279 284 127 279 285 minecraft:light_gray_concrete
fill 126 279 287 127 279 287 minecraft:orange_terracotta
fill 126 279 288 126 279 290 minecraft:yellow_wool
fill 126 279 291 127 279 291 minecraft:brown_terracotta
fill 126 279 292 127 279 293 minecraft:red_concrete
fill 126 279 294 127 279 295 minecraft:yellow_wool
fill 126 279 296 128 279 296 minecraft:red_concrete
fill 126 279 299 127 279 299 minecraft:brown_terracotta
fill 126 279 300 126 279 301 minecraft:yellow_wool
setblock 126 279 302 minecraft:red_concrete
fill 126 279 303 127 279 303 minecraft:orange_terracotta
fill 126 279 305 127 279 305 minecraft:light_gray_concrete
setblock 126 279 307 minecraft:white_concrete
fill 126 279 308 128 279 308 minecraft:light_gray_concrete
setblock 126 279 311 minecraft:white_concrete
fill 126 279 312 128 279 312 minecraft:light_gray_concrete
setblock 126 279 315 minecraft:white_concrete
fill 126 279 316 128 279 316 minecraft:light_gray_concrete
setblock 127 279 278 minecraft:white_concrete
fill 127 279 279 129 279 279 minecraft:light_gray_concrete
setblock 127 279 282 minecraft:white_concrete
fill 127 279 283 129 279 283 minecraft:light_gray_concrete
setblock 127 279 286 minecraft:white_concrete
setblock 127 279 288 minecraft:orange_terracotta
fill 127 279 289 127 279 290 minecraft:red_concrete
setblock 127 279 300 minecraft:yellow_wool
setblock 127 279 301 minecraft:red_concrete
setblock 127 279 302 minecraft:orange_terracotta
fill 127 279 304 128 279 304 minecraft:light_gray_concrete
setblock 127 279 306 minecraft:white_concrete
fill 127 279 307 129 279 307 minecraft:light_gray_concrete
setblock 127 279 310 minecraft:white_concrete
fill 127 279 311 129 279 311 minecraft:light_gray_concrete
setblock 127 279 314 minecraft:white_concrete
fill 127 279 315 129 279 315 minecraft:light_gray_concrete
setblock 128 279 277 minecraft:white_concrete
fill 128 279 278 130 279 278 minecraft:light_gray_concrete
setblock 128 279 281 minecraft:white_concrete
fill 128 279 282 130 279 282 minecraft:light_gray_concrete
setblock 128 279 284 minecraft:light_gray_concrete
setblock 128 279 285 minecraft:white_concrete
fill 128 279 286 128 279 288 minecraft:light_gray_concrete
fill 128 279 289 128 279 291 minecraft:orange_terracotta
setblock 128 279 292 minecraft:yellow_wool
fill 128 279 293 128 279 295 minecraft:red_concrete
fill 128 279 297 128 279 298 minecraft:yellow_wool
fill 128 279 299 128 279 301 minecraft:orange_terracotta
fill 128 279 302 129 279 303 minecraft:light_gray_concrete
setblock 128 279 305 minecraft:white_concrete
fill 128 279 306 130 279 306 minecraft:light_gray_concrete
setblock 128 279 309 minecraft:white_concrete
fill 128 279 310 130 279 310 minecraft:light_gray_concrete
setblock 128 279 313 minecraft:white_concrete
fill 128 279 314 130 279 314 minecraft:light_gray_concrete
setblock 129 279 276 minecraft:white_concrete
fill 129 279 277 131 279 277 minecraft:light_gray_concrete
setblock 129 279 280 minecraft:white_concrete
fill 129 279 281 131 279 281 minecraft:light_gray_concrete
setblock 129 279 284 minecraft:white_concrete
fill 129 279 285 129 279 287 minecraft:light_gray_concrete
setblock 129 279 288 minecraft:white_concrete
fill 129 279 289 131 279 289 minecraft:light_gray_concrete
setblock 129 279 290 minecraft:brown_terracotta
fill 129 279 291 129 279 299 minecraft:orange_terracotta
setblock 129 279 300 minecraft:brown_terracotta
fill 129 279 301 131 279 301 minecraft:light_gray_concrete
setblock 129 279 304 minecraft:white_concrete
fill 129 279 305 131 279 305 minecraft:light_gray_concrete
setblock 129 279 308 minecraft:white_concrete
fill 129 279 309 131 279 309 minecraft:light_gray_concrete
setblock 129 279 312 minecraft:white_concrete
fill 129 279 313 131 279 313 minecraft:light_gray_concrete
setblock 129 279 316 minecraft:white_concrete
fill 130 279 276 132 279 276 minecraft:light_gray_concrete
setblock 130 279 279 minecraft:white_concrete
fill 130 279 280 132 279 280 minecraft:light_gray_concrete
setblock 130 279 283 minecraft:white_concrete
fill 130 279 284 130 279 286 minecraft:light_gray_concrete
setblock 130 279 287 minecraft:white_concrete
fill 130 279 288 132 279 288 minecraft:light_gray_concrete
setblock 130 279 290 minecraft:light_gray_concrete
setblock 130 279 291 minecraft:white_concrete
fill 130 279 292 130 279 294 minecraft:light_gray_concrete
setblock 130 279 295 minecraft:orange_terracotta
fill 130 279 296 130 279 298 minecraft:light_gray_concrete
setblock 130 279 299 minecraft:white_concrete
fill 130 279 300 132 279 300 minecraft:light_gray_concrete
setblock 130 279 302 minecraft:light_gray_concrete
setblock 130 279 303 minecraft:white_concrete
fill 130 279 304 132 279 304 minecraft:light_gray_concrete
setblock 130 279 307 minecraft:white_concrete
fill 130 279 308 132 279 308 minecraft:light_gray_concrete
setblock 130 279 311 minecraft:white_concrete
fill 130 279 312 132 279 312 minecraft:light_gray_concrete
setblock 130 279 315 minecraft:white_concrete
fill 130 279 316 132 279 316 minecraft:light_gray_concrete
setblock 131 279 278 minecraft:white_concrete
fill 131 279 279 133 279 279 minecraft:light_gray_concrete
setblock 131 279 282 minecraft:white_concrete
fill 131 279 283 131 279 285 minecraft:light_gray_concrete
setblock 131 279 286 minecraft:white_concrete
fill 131 279 287 133 279 287 minecraft:light_gray_concrete
setblock 131 279 290 minecraft:white_concrete
fill 131 279 291 131 279 293 minecraft:light_gray_concrete
setblock 131 279 294 minecraft:white_concrete
fill 131 279 295 131 279 297 minecraft:light_gray_concrete
setblock 131 279 298 minecraft:white_concrete
fill 131 279 299 133 279 299 minecraft:light_gray_concrete
setblock 131 279 302 minecraft:white_concrete
fill 131 279 303 133 279 303 minecraft:light_gray_concrete
setblock 131 279 306 minecraft:white_concrete
fill 131 279 307 133 279 307 minecraft:light_gray_concrete
setblock 131 279 310 minecraft:white_concrete
fill 131 279 311 133 279 311 minecraft:light_gray_concrete
setblock 131 279 314 minecraft:white_concrete
fill 131 279 315 133 279 315 minecraft:light_gray_concrete
setblock 132 279 277 minecraft:white_concrete
fill 132 279 278 134 279 278 minecraft:light_gray_concrete
setblock 132 279 281 minecraft:white_concrete
fill 132 279 282 132 279 284 minecraft:light_gray_concrete
setblock 132 279 285 minecraft:white_concrete
fill 132 279 286 134 279 286 minecraft:light_gray_concrete
setblock 132 279 289 minecraft:white_concrete
fill 132 279 290 132 279 292 minecraft:light_gray_concrete
setblock 132 279 293 minecraft:white_concrete
fill 132 279 294 132 279 296 minecraft:light_gray_concrete
setblock 132 279 297 minecraft:white_concrete
fill 132 279 298 134 279 298 minecraft:light_gray_concrete
setblock 132 279 301 minecraft:white_concrete
fill 132 279 302 134 279 302 minecraft:light_gray_concrete
setblock 132 279 305 minecraft:white_concrete
fill 132 279 306 134 279 306 minecraft:light_gray_concrete
setblock 132 279 309 minecraft:white_concrete
fill 132 279 310 134 279 310 minecraft:light_gray_concrete
setblock 132 279 313 minecraft:white_concrete
fill 132 279 314 134 279 314 minecraft:light_gray_concrete
setblock 133 279 276 minecraft:white_concrete
fill 133 279 277 135 279 277 minecraft:light_gray_concrete
setblock 133 279 280 minecraft:white_concrete
fill 133 279 281 133 279 283 minecraft:light_gray_concrete
setblock 133 279 284 minecraft:white_concrete
fill 133 279 285 135 279 285 minecraft:light_gray_concrete
setblock 133 279 288 minecraft:white_concrete
fill 133 279 289 133 279 291 minecraft:light_gray_concrete
setblock 133 279 292 minecraft:white_concrete
fill 133 279 293 133 279 295 minecraft:light_gray_concrete
setblock 133 279 296 minecraft:white_concrete
fill 133 279 297 135 279 297 minecraft:light_gray_concrete
setblock 133 279 300 minecraft:white_concrete
fill 133 279 301 135 279 301 minecraft:light_gray_concrete
setblock 133 279 304 minecraft:white_concrete
fill 133 279 305 135 279 305 minecraft:light_gray_concrete
setblock 133 279 308 minecraft:white_concrete
fill 133 279 309 135 279 309 minecraft:light_gray_concrete
setblock 133 279 312 minecraft:white_concrete
fill 133 279 313 135 279 313 minecraft:light_gray_concrete
setblock 133 279 316 minecraft:white_concrete
fill 134 279 276 135 279 276 minecraft:light_gray_concrete
setblock 134 279 279 minecraft:white_concrete
fill 134 279 280 134 279 282 minecraft:light_gray_concrete
setblock 134 279 283 minecraft:white_concrete
fill 134 279 284 135 279 284 minecraft:light_gray_concrete
setblock 134 279 287 minecraft:white_concrete
fill 134 279 288 134 279 290 minecraft:light_gray_concrete
setblock 134 279 291 minecraft:white_concrete
fill 134 279 292 134 279 294 minecraft:light_gray_concrete
setblock 134 279 295 minecraft:white_concrete
fill 134 279 296 135 279 296 minecraft:light_gray_concrete
setblock 134 279 299 minecraft:white_concrete
fill 134 279 300 135 279 300 minecraft:light_gray_concrete
setblock 134 279 303 minecraft:white_concrete
fill 134 279 304 135 279 304 minecraft:light_gray_concrete
setblock 134 279 307 minecraft:white_concrete
fill 134 279 308 135 279 308 minecraft:light_gray_concrete
setblock 134 279 311 minecraft:white_concrete
fill 134 279 312 135 279 312 minecraft:light_gray_concrete
setblock 134 279 315 minecraft:white_concrete
fill 134 279 316 135 279 316 minecraft:light_gray_concrete
setblock 135 279 278 minecraft:white_concrete
fill 135 279 279 135 279 281 minecraft:light_gray_concrete
setblock 135 279 282 minecraft:white_concrete
setblock 135 279 283 minecraft:light_gray_concrete
setblock 135 279 286 minecraft:white_concrete
fill 135 279 287 135 279 289 minecraft:light_gray_concrete
setblock 135 279 290 minecraft:white_concrete
fill 135 279 291 135 279 293 minecraft:light_gray_concrete
setblock 135 279 294 minecraft:white_concrete
setblock 135 279 295 minecraft:light_gray_concrete
setblock 135 279 298 minecraft:white_concrete
setblock 135 279 299 minecraft:light_gray_concrete
setblock 135 279 302 minecraft:white_concrete
setblock 135 279 303 minecraft:light_gray_concrete
setblock 135 279 306 minecraft:white_concrete
setblock 135 279 307 minecraft:light_gray_concrete
setblock 135 279 310 minecraft:white_concrete
setblock 135 279 311 minecraft:light_gray_concrete
setblock 135 279 314 minecraft:white_concrete
setblock 135 279 315 minecraft:light_gray_concrete
fill 94 280 275 94 281 276 minecraft:red_concrete
fill 94 280 277 94 281 278 minecraft:white_concrete
fill 94 280 279 94 281 280 minecraft:red_concrete
fill 94 280 281 94 281 282 minecraft:white_concrete
fill 94 280 283 94 281 284 minecraft:red_concrete
fill 94 280 285 94 281 286 minecraft:white_concrete
fill 94 280 287 94 281 288 minecraft:red_concrete
fill 94 280 289 94 281 290 minecraft:white_concrete
fill 94 280 291 94 281 292 minecraft:red_concrete
fill 94 280 293 94 281 294 minecraft:white_concrete
fill 94 280 295 94 281 296 minecraft:red_concrete
fill 94 280 297 94 281 298 minecraft:white_concrete
fill 94 280 299 94 281 300 minecraft:red_concrete
fill 94 280 301 94 281 302 minecraft:white_concrete
fill 94 280 303 94 281 304 minecraft:red_concrete
fill 94 280 305 94 281 306 minecraft:white_concrete
fill 94 280 307 94 281 308 minecraft:red_concrete
fill 94 280 309 94 281 310 minecraft:white_concrete
fill 94 280 311 94 281 312 minecraft:red_concrete
fill 94 280 313 94 281 314 minecraft:white_concrete
fill 94 280 315 94 281 316 minecraft:red_concrete
fill 95 280 275 95 281 275 minecraft:red_concrete
fill 95 280 317 95 281 317 minecraft:red_concrete
fill 96 280 275 97 281 275 minecraft:white_concrete
fill 96 280 317 97 281 317 minecraft:white_concrete
fill 98 280 275 99 281 275 minecraft:red_concrete
fill 98 280 317 99 281 317 minecraft:red_concrete
fill 100 280 275 101 281 275 minecraft:white_concrete
fill 100 280 317 101 281 317 minecraft:white_concrete
fill 102 280 275 103 281 275 minecraft:red_concrete
fill 102 280 317 103 281 317 minecraft:red_concrete
fill 104 280 275 105 281 275 minecraft:white_concrete
fill 104 280 317 105 281 317 minecraft:white_concrete
fill 106 280 275 107 281 275 minecraft:red_concrete
fill 106 280 317 107 281 317 minecraft:red_concrete
fill 108 280 275 109 281 275 minecraft:white_concrete
fill 108 280 317 109 281 317 minecraft:white_concrete
fill 110 280 275 111 281 275 minecraft:red_concrete
fill 110 280 317 111 281 317 minecraft:red_concrete
fill 112 280 275 113 281 275 minecraft:white_concrete
fill 112 280 317 113 281 317 minecraft:white_concrete
fill 114 280 275 115 281 275 minecraft:red_concrete
fill 114 280 317 115 281 317 minecraft:red_concrete
fill 116 280 275 117 281 275 minecraft:white_concrete
fill 116 280 317 117 281 317 minecraft:white_concrete
fill 118 280 275 119 281 275 minecraft:red_concrete
fill 118 280 317 119 281 317 minecraft:red_concrete
fill 120 280 275 121 281 275 minecraft:white_concrete
fill 120 280 317 121 281 317 minecraft:white_concrete
fill 122 280 275 123 281 275 minecraft:red_concrete
fill 122 280 317 123 281 317 minecraft:red_concrete
fill 124 280 275 125 281 275 minecraft:white_concrete
fill 124 280 317 125 281 317 minecraft:white_concrete
fill 126 280 275 127 281 275 minecraft:red_concrete
fill 126 280 317 127 281 317 minecraft:red_concrete
fill 128 280 275 129 281 275 minecraft:white_concrete
fill 128 280 317 129 281 317 minecraft:white_concrete
fill 130 280 275 131 281 275 minecraft:red_concrete
fill 130 280 317 131 281 317 minecraft:red_concrete
fill 132 280 275 133 281 275 minecraft:white_concrete
fill 132 280 317 133 281 317 minecraft:white_concrete
fill 134 280 275 135 281 275 minecraft:red_concrete
fill 134 280 317 135 281 317 minecraft:red_concrete
fill 136 280 276 136 281 276 minecraft:red_concrete
fill 136 280 277 136 281 278 minecraft:white_concrete
fill 136 280 279 136 281 280 minecraft:red_concrete
fill 136 280 281 136 281 282 minecraft:white_concrete
fill 136 280 283 136 281 284 minecraft:red_concrete
fill 136 280 285 136 281 286 minecraft:white_concrete
fill 136 280 287 136 281 288 minecraft:red_concrete
fill 136 280 289 136 281 290 minecraft:white_concrete
fill 136 280 291 136 281 292 minecraft:red_concrete
fill 136 280 293 136 281 294 minecraft:white_concrete
fill 136 280 295 136 281 296 minecraft:red_concrete
fill 136 280 297 136 281 298 minecraft:white_concrete
fill 136 280 299 136 281 300 minecraft:red_concrete
fill 136 280 301 136 281 302 minecraft:white_concrete
fill 136 280 303 136 281 304 minecraft:red_concrete
fill 136 280 305 136 281 306 minecraft:white_concrete
fill 136 280 307 136 281 308 minecraft:red_concrete
fill 136 280 309 136 281 310 minecraft:white_concrete
fill 136 280 311 136 281 312 minecraft:red_concrete
fill 136 280 313 136 281 314 minecraft:white_concrete
fill 136 280 315 136 281 316 minecraft:red_concrete
fill 136 280 317 136 281 317 minecraft:white_concrete
fill 94 282 275 94 283 276 minecraft:white_concrete
fill 94 282 277 94 283 278 minecraft:red_concrete
fill 94 282 279 94 283 280 minecraft:white_concrete
fill 94 282 281 94 283 282 minecraft:red_concrete
fill 94 282 283 94 283 284 minecraft:white_concrete
fill 94 282 285 94 283 286 minecraft:red_concrete
fill 94 282 287 94 283 288 minecraft:white_concrete
fill 94 282 289 94 283 290 minecraft:red_concrete
fill 94 282 291 94 283 292 minecraft:white_concrete
fill 94 282 293 94 283 294 minecraft:red_concrete
fill 94 282 295 94 283 296 minecraft:white_concrete
fill 94 282 297 94 283 298 minecraft:red_concrete
fill 94 282 299 94 283 300 minecraft:white_concrete
fill 94 282 301 94 283 302 minecraft:red_concrete
fill 94 282 303 94 283 304 minecraft:white_concrete
fill 94 282 305 94 283 306 minecraft:red_concrete
fill 94 282 307 94 283 308 minecraft:white_concrete
fill 94 282 309 94 283 310 minecraft:red_concrete
fill 94 282 311 94 283 312 minecraft:white_concrete
fill 94 282 313 94 283 314 minecraft:red_concrete
fill 94 282 315 94 283 316 minecraft:white_concrete
fill 95 282 275 95 283 275 minecraft:white_concrete
fill 95 282 317 95 283 317 minecraft:white_concrete
fill 96 282 275 97 283 275 minecraft:red_concrete
fill 96 282 317 97 283 317 minecraft:red_concrete
fill 98 282 275 99 283 275 minecraft:white_concrete
fill 98 282 317 99 283 317 minecraft:white_concrete
fill 100 282 275 101 283 275 minecraft:red_concrete
fill 100 282 317 101 283 317 minecraft:red_concrete
fill 102 282 275 103 283 275 minecraft:white_concrete
fill 102 282 317 103 283 317 minecraft:white_concrete
fill 104 282 275 105 283 275 minecraft:red_concrete
fill 104 282 317 105 283 317 minecraft:red_concrete
fill 106 282 275 107 283 275 minecraft:white_concrete
fill 106 282 317 107 283 317 minecraft:white_concrete
fill 108 282 275 109 283 275 minecraft:red_concrete
fill 108 282 317 109 283 317 minecraft:red_concrete
fill 110 282 275 111 283 275 minecraft:white_concrete
fill 110 282 317 111 283 317 minecraft:white_concrete
fill 112 282 275 113 283 275 minecraft:red_concrete
fill 112 282 317 113 283 317 minecraft:red_concrete
fill 114 282 275 115 283 275 minecraft:white_concrete
fill 114 282 317 115 283 317 minecraft:white_concrete
fill 116 282 275 117 283 275 minecraft:red_concrete
fill 116 282 317 117 283 317 minecraft:red_concrete
fill 118 282 275 119 283 275 minecraft:white_concrete
fill 118 282 317 119 283 317 minecraft:white_concrete
setblock 119 282 278 minecraft:iron_block
fill 120 282 275 121 283 275 minecraft:red_concrete
setblock 120 282 277 minecraft:iron_block
fill 120 282 278 122 282 278 minecraft:black_concrete
setblock 120 282 279 minecraft:iron_block
fill 120 282 317 121 283 317 minecraft:red_concrete
setblock 121 282 276 minecraft:iron_block
setblock 121 282 277 minecraft:black_concrete
setblock 121 282 279 minecraft:black_concrete
setblock 121 282 280 minecraft:iron_block
fill 122 282 275 123 283 275 minecraft:white_concrete
setblock 122 282 277 minecraft:iron_block
setblock 122 282 279 minecraft:iron_block
fill 122 282 317 123 283 317 minecraft:white_concrete
setblock 123 282 278 minecraft:iron_block
fill 124 282 275 125 283 275 minecraft:red_concrete
fill 124 282 317 125 283 317 minecraft:red_concrete
fill 126 282 275 127 283 275 minecraft:white_concrete
fill 126 282 317 127 283 317 minecraft:white_concrete
fill 128 282 275 129 283 275 minecraft:red_concrete
fill 128 282 317 129 283 317 minecraft:red_concrete
fill 130 282 275 131 283 275 minecraft:white_concrete
fill 130 282 317 131 283 317 minecraft:white_concrete
fill 132 282 275 133 283 275 minecraft:red_concrete
fill 132 282 317 133 283 317 minecraft:red_concrete
fill 134 282 275 135 283 275 minecraft:white_concrete
fill 134 282 317 135 283 317 minecraft:white_concrete
fill 136 282 276 136 283 276 minecraft:white_concrete
fill 136 282 277 136 283 278 minecraft:red_concrete
fill 136 282 279 136 283 280 minecraft:white_concrete
fill 136 282 281 136 283 282 minecraft:red_concrete
fill 136 282 283 136 283 284 minecraft:white_concrete
fill 136 282 285 136 283 286 minecraft:red_concrete
fill 136 282 287 136 283 288 minecraft:white_concrete
fill 136 282 289 136 283 290 minecraft:red_concrete
fill 136 282 291 136 283 292 minecraft:white_concrete
fill 136 282 293 136 283 294 minecraft:red_concrete
fill 136 282 295 136 283 296 minecraft:white_concrete
fill 136 282 297 136 283 298 minecraft:red_concrete
fill 136 282 299 136 283 300 minecraft:white_concrete
fill 136 282 301 136 283 302 minecraft:red_concrete
fill 136 282 303 136 283 304 minecraft:white_concrete
fill 136 282 305 136 283 306 minecraft:red_concrete
fill 136 282 307 136 283 308 minecraft:white_concrete
fill 136 282 309 136 283 310 minecraft:red_concrete
fill 136 282 311 136 283 312 minecraft:white_concrete
fill 136 282 313 136 283 314 minecraft:red_concrete
fill 136 282 315 136 283 316 minecraft:white_concrete
fill 136 282 317 136 283 317 minecraft:red_concrete
fill 95 283 282 95 300 283 minecraft:red_terracotta
fill 95 283 290 95 300 291 minecraft:red_terracotta
fill 95 283 298 95 300 299 minecraft:red_terracotta
fill 95 283 306 95 300 307 minecraft:red_terracotta
fill 95 283 314 95 300 315 minecraft:red_terracotta
fill 96 283 276 97 300 276 minecraft:red_terracotta
fill 97 283 307 101 300 308 minecraft:red_terracotta
fill 97 283 309 97 283 310 minecraft:iron_block
fill 98 283 306 100 300 306 minecraft:red_terracotta
fill 98 283 309 100 300 309 minecraft:red_terracotta
fill 98 283 310 99 283 310 minecraft:iron_block
fill 101 283 316 102 300 316 minecraft:red_terracotta
fill 104 283 276 105 300 276 minecraft:red_terracotta
setblock 109 283 307 minecraft:red_concrete
fill 109 283 316 110 300 316 minecraft:red_terracotta
fill 112 283 276 113 300 276 minecraft:red_terracotta
fill 112 283 310 115 300 313 minecraft:red_terracotta
fill 113 283 309 114 300 309 minecraft:red_terracotta
fill 116 283 311 116 300 311 minecraft:red_terracotta
fill 117 283 316 118 300 316 minecraft:red_terracotta
fill 120 283 276 121 300 276 minecraft:red_terracotta
fill 125 283 316 126 300 316 minecraft:red_terracotta
fill 128 283 276 129 300 276 minecraft:red_terracotta
fill 133 283 316 134 300 316 minecraft:red_terracotta
fill 135 283 277 135 300 278 minecraft:red_terracotta
fill 135 283 285 135 300 286 minecraft:red_terracotta
fill 135 283 293 135 300 294 minecraft:red_terracotta
fill 135 283 301 135 300 302 minecraft:red_terracotta
fill 135 283 309 135 300 310 minecraft:red_terracotta
fill 94 284 275 94 285 276 minecraft:red_concrete
fill 94 284 277 94 285 278 minecraft:white_concrete
fill 94 284 279 94 285 279 minecraft:red_concrete
fill 94 284 280 94 289 280 minecraft:shroomlight
fill 94 284 281 94 285 282 minecraft:white_concrete
fill 94 284 283 94 285 284 minecraft:red_concrete
fill 94 284 285 94 285 286 minecraft:white_concrete
fill 94 284 287 94 285 287 minecraft:red_concrete
fill 94 284 288 94 289 288 minecraft:shroomlight
fill 94 284 289 94 285 290 minecraft:white_concrete
fill 94 284 291 94 285 292 minecraft:red_concrete
fill 94 284 293 94 285 294 minecraft:white_concrete
fill 94 284 295 94 285 295 minecraft:red_concrete
fill 94 284 296 94 289 296 minecraft:shroomlight
fill 94 284 297 94 285 298 minecraft:white_concrete
fill 94 284 299 94 285 300 minecraft:red_concrete
fill 94 284 301 94 285 302 minecraft:white_concrete
fill 94 284 303 94 285 303 minecraft:red_concrete
fill 94 284 304 94 289 304 minecraft:shroomlight
fill 94 284 305 94 285 306 minecraft:white_concrete
fill 94 284 307 94 285 308 minecraft:red_concrete
fill 94 284 309 94 285 310 minecraft:white_concrete
fill 94 284 311 94 285 311 minecraft:red_concrete
fill 94 284 312 94 289 312 minecraft:shroomlight
fill 94 284 313 94 285 314 minecraft:white_concrete
fill 94 284 315 94 285 316 minecraft:red_concrete
fill 95 284 275 95 285 275 minecraft:red_concrete
fill 95 284 317 95 285 317 minecraft:red_concrete
fill 96 284 275 97 285 275 minecraft:white_concrete
fill 96 284 307 96 285 308 minecraft:brown_terracotta
fill 96 284 317 96 285 317 minecraft:white_concrete
fill 97 284 305 97 285 306 minecraft:brown_terracotta
fill 97 284 309 97 285 309 minecraft:brown_terracotta
setblock 97 284 310 minecraft:iron_block
fill 97 284 317 97 289 317 minecraft:shroomlight
fill 98 284 275 99 285 275 minecraft:red_concrete
fill 98 284 305 101 285 305 minecraft:brown_terracotta
fill 98 284 310 100 285 310 minecraft:brown_terracotta
fill 98 284 317 99 285 317 minecraft:red_concrete
fill 100 284 275 100 285 275 minecraft:white_concrete
fill 100 284 317 101 285 317 minecraft:white_concrete
fill 101 284 275 101 289 275 minecraft:shroomlight
fill 101 284 306 101 285 306 minecraft:brown_terracotta
fill 101 284 309 101 285 309 minecraft:brown_terracotta
fill 102 284 275 103 285 275 minecraft:red_concrete
fill 102 284 307 102 285 308 minecraft:brown_terracotta
fill 102 284 317 103 285 317 minecraft:red_concrete
fill 104 284 275 105 285 275 minecraft:white_concrete
fill 104 284 317 104 285 317 minecraft:white_concrete
fill 105 284 317 105 289 317 minecraft:shroomlight
fill 106 284 275 107 285 275 minecraft:red_concrete
fill 106 284 317 107 285 317 minecraft:red_concrete
fill 108 284 275 108 285 275 minecraft:white_concrete
fill 108 284 317 109 285 317 minecraft:white_concrete
fill 109 284 275 109 289 275 minecraft:shroomlight
fill 110 284 275 111 285 275 minecraft:red_concrete
fill 110 284 311 111 285 311 minecraft:brown_terracotta
fill 110 284 317 111 285 317 minecraft:red_concrete
fill 111 284 309 111 285 310 minecraft:brown_terracotta
fill 111 284 312 111 285 313 minecraft:brown_terracotta
fill 112 284 275 113 285 275 minecraft:white_concrete
fill 112 284 309 112 285 309 minecraft:brown_terracotta
fill 112 284 314 115 285 314 minecraft:brown_terracotta
fill 112 284 317 112 285 317 minecraft:white_concrete
fill 113 284 308 114 285 308 minecraft:brown_terracotta
fill 113 284 317 113 289 317 minecraft:shroomlight
fill 114 284 275 115 285 275 minecraft:red_concrete
fill 114 284 317 115 285 317 minecraft:red_concrete
fill 115 284 309 116 285 309 minecraft:brown_terracotta
fill 116 284 275 116 285 275 minecraft:white_concrete
fill 116 284 310 116 285 310 minecraft:brown_terracotta
fill 116 284 312 116 285 313 minecraft:brown_terracotta
fill 116 284 317 117 285 317 minecraft:white_concrete
fill 117 284 275 117 289 275 minecraft:shroomlight
fill 117 284 311 117 285 312 minecraft:brown_terracotta
fill 118 284 275 119 285 275 minecraft:red_concrete
fill 118 284 317 119 285 317 minecraft:red_concrete
fill 120 284 275 121 285 275 minecraft:white_concrete
fill 120 284 317 120 285 317 minecraft:white_concrete
fill 121 284 317 121 289 317 minecraft:shroomlight
fill 122 284 275 123 285 275 minecraft:red_concrete
fill 122 284 317 123 285 317 minecraft:red_concrete
fill 124 284 275 124 285 275 minecraft:white_concrete
fill 124 284 317 125 285 317 minecraft:white_concrete
fill 125 284 275 125 289 275 minecraft:shroomlight
fill 126 284 275 127 285 275 minecraft:red_concrete
fill 126 284 317 127 285 317 minecraft:red_concrete
fill 128 284 275 129 285 275 minecraft:white_concrete
fill 128 284 295 132 285 299 minecraft:brown_terracotta
fill 128 284 317 128 285 317 minecraft:white_concrete
fill 129 284 317 129 289 317 minecraft:shroomlight
fill 130 284 275 131 285 275 minecraft:red_concrete
fill 130 284 317 131 285 317 minecraft:red_concrete
fill 132 284 275 132 285 275 minecraft:white_concrete
fill 132 284 317 133 285 317 minecraft:white_concrete
fill 133 284 275 133 289 275 minecraft:shroomlight
fill 133 284 297 134 284 297 minecraft:brown_terracotta
fill 134 284 275 135 285 275 minecraft:red_concrete
fill 134 284 317 135 285 317 minecraft:red_concrete
fill 136 284 276 136 285 276 minecraft:red_concrete
fill 136 284 277 136 285 278 minecraft:white_concrete
fill 136 284 279 136 285 279 minecraft:red_concrete
fill 136 284 280 136 289 280 minecraft:shroomlight
fill 136 284 281 136 285 282 minecraft:white_concrete
fill 136 284 283 136 285 284 minecraft:red_concrete
fill 136 284 285 136 285 286 minecraft:white_concrete
fill 136 284 287 136 285 287 minecraft:red_concrete
fill 136 284 288 136 289 288 minecraft:shroomlight
fill 136 284 289 136 285 290 minecraft:white_concrete
fill 136 284 291 136 285 292 minecraft:red_concrete
fill 136 284 293 136 285 294 minecraft:white_concrete
fill 136 284 295 136 285 295 minecraft:red_concrete
fill 136 284 296 136 289 296 minecraft:shroomlight
fill 136 284 297 136 285 298 minecraft:white_concrete
fill 136 284 299 136 285 300 minecraft:red_concrete
fill 136 284 301 136 285 302 minecraft:white_concrete
fill 136 284 303 136 285 303 minecraft:red_concrete
fill 136 284 304 136 289 304 minecraft:shroomlight
fill 136 284 305 136 285 306 minecraft:white_concrete
fill 136 284 307 136 285 308 minecraft:red_concrete
fill 136 284 309 136 285 310 minecraft:white_concrete
fill 136 284 311 136 285 311 minecraft:red_concrete
fill 136 284 312 136 289 312 minecraft:shroomlight
fill 136 284 313 136 285 314 minecraft:white_concrete
fill 136 284 315 136 285 316 minecraft:red_concrete
fill 136 284 317 136 285 317 minecraft:white_concrete
setblock 95 285 308 minecraft:brown_terracotta
fill 96 285 305 96 285 306 minecraft:brown_terracotta
fill 96 285 309 96 285 310 minecraft:brown_terracotta
setblock 97 285 278 minecraft:light[level=15]
setblock 97 285 285 minecraft:light[level=12]
setblock 97 285 286 minecraft:light[level=15]
setblock 97 285 292 minecraft:light[level=12]
setblock 97 285 294 minecraft:light[level=15]
setblock 97 285 299 minecraft:light[level=12]
setblock 97 285 302 minecraft:light[level=15]
fill 97 285 304 101 285 304 minecraft:brown_terracotta
setblock 97 285 310 minecraft:brown_terracotta
setblock 97 285 311 minecraft:red_terracotta
setblock 97 285 313 minecraft:light[level=12]
fill 98 285 311 100 285 311 minecraft:brown_terracotta
fill 101 285 310 102 285 310 minecraft:brown_terracotta
fill 102 285 305 102 285 306 minecraft:brown_terracotta
setblock 102 285 309 minecraft:brown_terracotta
fill 103 285 307 103 285 308 minecraft:brown_terracotta
setblock 104 285 278 minecraft:light[level=12]
setblock 104 285 285 minecraft:light[level=12]
setblock 104 285 292 minecraft:light[level=12]
setblock 104 285 299 minecraft:light[level=12]
setblock 104 285 306 minecraft:light[level=12]
setblock 104 285 313 minecraft:light[level=12]
setblock 105 285 278 minecraft:light[level=15]
setblock 105 285 286 minecraft:light[level=15]
setblock 105 285 294 minecraft:light[level=15]
setblock 105 285 302 minecraft:light[level=15]
setblock 105 285 310 minecraft:light[level=15]
setblock 109 285 311 minecraft:brown_terracotta
fill 110 285 309 110 285 310 minecraft:brown_terracotta
fill 110 285 312 110 285 314 minecraft:brown_terracotta
setblock 111 285 278 minecraft:light[level=12]
setblock 111 285 285 minecraft:light[level=12]
setblock 111 285 292 minecraft:light[level=12]
setblock 111 285 299 minecraft:light[level=12]
setblock 111 285 306 minecraft:light[level=12]
fill 111 285 308 112 285 308 minecraft:brown_terracotta
fill 111 285 314 111 285 315 minecraft:brown_terracotta
fill 112 285 307 115 285 307 minecraft:brown_terracotta
fill 112 285 315 116 285 315 minecraft:brown_terracotta
setblock 113 285 278 minecraft:light[level=15]
setblock 113 285 286 minecraft:light[level=15]
setblock 113 285 294 minecraft:light[level=15]
setblock 113 285 302 minecraft:light[level=15]
fill 115 285 308 116 285 308 minecraft:brown_terracotta
fill 116 285 314 117 285 314 minecraft:brown_terracotta
fill 117 285 309 117 285 310 minecraft:brown_terracotta
setblock 117 285 313 minecraft:brown_terracotta
setblock 118 285 278 minecraft:light[level=12]
setblock 118 285 285 minecraft:light[level=12]
setblock 118 285 292 minecraft:light[level=12]
setblock 118 285 299 minecraft:light[level=12]
setblock 118 285 306 minecraft:light[level=12]
fill 118 285 311 118 285 312 minecraft:brown_terracotta
setblock 118 285 313 minecraft:light[level=12]
setblock 120 285 278 minecraft:iron_block
setblock 121 285 277 minecraft:iron_block
fill 121 285 278 123 285 278 minecraft:black_concrete
setblock 121 285 279 minecraft:iron_block
setblock 121 285 286 minecraft:light[level=15]
setblock 121 285 294 minecraft:light[level=15]
setblock 121 285 302 minecraft:light[level=15]
setblock 121 285 310 minecraft:light[level=15]
setblock 122 285 276 minecraft:iron_block
setblock 122 285 277 minecraft:black_concrete
setblock 122 285 279 minecraft:black_concrete
setblock 122 285 280 minecraft:iron_block
setblock 123 285 277 minecraft:iron_block
setblock 123 285 279 minecraft:iron_block
setblock 124 285 278 minecraft:iron_block
setblock 125 285 278 minecraft:light[level=12]
setblock 125 285 285 minecraft:light[level=12]
setblock 125 285 292 minecraft:light[level=12]
setblock 125 285 299 minecraft:light[level=12]
setblock 125 285 306 minecraft:light[level=12]
setblock 125 285 313 minecraft:light[level=12]
setblock 129 285 278 minecraft:light[level=15]
setblock 129 285 286 minecraft:light[level=15]
setblock 129 285 294 minecraft:light[level=15]
setblock 129 285 302 minecraft:light[level=15]
setblock 129 285 310 minecraft:light[level=15]
setblock 132 285 278 minecraft:light[level=12]
setblock 132 285 285 minecraft:light[level=12]
setblock 132 285 292 minecraft:light[level=12]
setblock 132 285 306 minecraft:light[level=12]
setblock 132 285 313 minecraft:light[level=12]
fill 94 286 275 94 287 276 minecraft:white_concrete
fill 94 286 277 94 287 278 minecraft:red_concrete
fill 94 286 279 94 287 279 minecraft:white_concrete
fill 94 286 281 94 287 282 minecraft:red_concrete
fill 94 286 283 94 287 284 minecraft:white_concrete
fill 94 286 285 94 287 286 minecraft:red_concrete
fill 94 286 287 94 287 287 minecraft:white_concrete
fill 94 286 289 94 287 290 minecraft:red_concrete
fill 94 286 291 94 287 292 minecraft:white_concrete
fill 94 286 293 94 287 294 minecraft:red_concrete
fill 94 286 295 94 287 295 minecraft:white_concrete
fill 94 286 297 94 287 298 minecraft:red_concrete
fill 94 286 299 94 287 300 minecraft:white_concrete
fill 94 286 301 94 287 302 minecraft:red_concrete
fill 94 286 303 94 287 303 minecraft:white_concrete
fill 94 286 305 94 287 306 minecraft:red_concrete
fill 94 286 307 94 287 308 minecraft:white_concrete
fill 94 286 309 94 287 310 minecraft:red_concrete
fill 94 286 311 94 287 311 minecraft:white_concrete
fill 94 286 313 94 287 314 minecraft:red_concrete
fill 94 286 315 94 287 316 minecraft:white_concrete
fill 95 286 275 95 287 275 minecraft:white_concrete
fill 95 286 317 95 287 317 minecraft:white_concrete
fill 96 286 275 97 287 275 minecraft:red_concrete
fill 96 286 317 96 287 317 minecraft:red_concrete
fill 97 286 309 97 296 310 minecraft:iron_block
fill 98 286 275 99 287 275 minecraft:white_concrete
fill 98 286 310 99 296 310 minecraft:iron_block
fill 98 286 317 99 287 317 minecraft:white_concrete
fill 100 286 275 100 287 275 minecraft:red_concrete
fill 100 286 317 101 287 317 minecraft:red_concrete
fill 102 286 275 103 287 275 minecraft:white_concrete
fill 102 286 317 103 287 317 minecraft:white_concrete
fill 104 286 275 105 287 275 minecraft:red_concrete
fill 104 286 317 104 287 317 minecraft:red_concrete
fill 106 286 275 107 287 275 minecraft:white_concrete
fill 106 286 317 107 287 317 minecraft:white_concrete
fill 108 286 275 108 287 275 minecraft:red_concrete
fill 108 286 317 109 287 317 minecraft:red_concrete
fill 109 286 286 112 300 288 minecraft:red_terracotta
fill 110 286 275 111 287 275 minecraft:white_concrete
fill 110 286 285 111 300 285 minecraft:red_terracotta
fill 110 286 289 112 300 289 minecraft:red_terracotta
fill 110 286 317 111 287 317 minecraft:white_concrete
fill 112 286 275 113 287 275 minecraft:red_concrete
fill 112 286 317 112 287 317 minecraft:red_concrete
fill 113 286 287 113 300 288 minecraft:red_terracotta
fill 114 286 275 115 287 275 minecraft:white_concrete
fill 114 286 317 115 287 317 minecraft:white_concrete
fill 116 286 275 116 287 275 minecraft:red_concrete
fill 116 286 317 117 287 317 minecraft:red_concrete
fill 118 286 275 119 287 275 minecraft:white_concrete
fill 118 286 317 119 287 317 minecraft:white_concrete
fill 120 286 275 121 287 275 minecraft:red_concrete
fill 120 286 317 120 287 317 minecraft:red_concrete
fill 122 286 275 123 287 275 minecraft:white_concrete
fill 122 286 317 123 287 317 minecraft:white_concrete
fill 124 286 275 124 287 275 minecraft:red_concrete
fill 124 286 317 125 287 317 minecraft:red_concrete
fill 126 286 275 127 287 275 minecraft:white_concrete
fill 126 286 317 127 287 317 minecraft:white_concrete
fill 127 286 307 129 300 309 minecraft:red_terracotta
fill 128 286 275 129 287 275 minecraft:red_concrete
fill 128 286 306 128 300 306 minecraft:red_terracotta
fill 128 286 317 128 287 317 minecraft:red_concrete
fill 130 286 275 131 287 275 minecraft:white_concrete
fill 130 286 297 130 289 297 minecraft:red_terracotta
fill 130 286 308 130 300 308 minecraft:red_terracotta
fill 130 286 317 131 287 317 minecraft:white_concrete
fill 132 286 275 132 287 275 minecraft:red_concrete
fill 132 286 317 133 287 317 minecraft:red_concrete
fill 134 286 275 135 287 275 minecraft:white_concrete
fill 134 286 317 135 287 317 minecraft:white_concrete
fill 136 286 276 136 287 276 minecraft:white_concrete
fill 136 286 277 136 287 278 minecraft:red_concrete
fill 136 286 279 136 287 279 minecraft:white_concrete
fill 136 286 281 136 287 282 minecraft:red_concrete
fill 136 286 283 136 287 284 minecraft:white_concrete
fill 136 286 285 136 287 286 minecraft:red_concrete
fill 136 286 287 136 287 287 minecraft:white_concrete
fill 136 286 289 136 287 290 minecraft:red_concrete
fill 136 286 291 136 287 292 minecraft:white_concrete
fill 136 286 293 136 287 294 minecraft:red_concrete
fill 136 286 295 136 287 295 minecraft:white_concrete
fill 136 286 297 136 287 298 minecraft:red_concrete
fill 136 286 299 136 287 300 minecraft:white_concrete
fill 136 286 301 136 287 302 minecraft:red_concrete
fill 136 286 303 136 287 303 minecraft:white_concrete
fill 136 286 305 136 287 306 minecraft:red_concrete
fill 136 286 307 136 287 308 minecraft:white_concrete
fill 136 286 309 136 287 310 minecraft:red_concrete
fill 136 286 311 136 287 311 minecraft:white_concrete
fill 136 286 313 136 287 314 minecraft:red_concrete
fill 136 286 315 136 287 316 minecraft:white_concrete
fill 136 286 317 136 287 317 minecraft:red_concrete
fill 108 287 286 108 288 289 minecraft:brown_terracotta
fill 109 287 285 109 288 285 minecraft:brown_terracotta
fill 109 287 289 109 288 290 minecraft:brown_terracotta
fill 110 287 284 112 288 284 minecraft:brown_terracotta
fill 110 287 290 112 288 290 minecraft:brown_terracotta
fill 112 287 285 113 288 285 minecraft:brown_terracotta
fill 113 287 286 114 288 286 minecraft:brown_terracotta
fill 113 287 289 113 288 289 minecraft:brown_terracotta
fill 114 287 287 114 288 288 minecraft:brown_terracotta
fill 126 287 307 126 288 309 minecraft:brown_terracotta
fill 127 287 306 127 288 306 minecraft:brown_terracotta
fill 127 287 310 129 288 310 minecraft:brown_terracotta
fill 129 287 306 130 288 306 minecraft:brown_terracotta
fill 130 287 307 130 288 307 minecraft:brown_terracotta
fill 130 287 309 130 288 309 minecraft:brown_terracotta
fill 94 288 275 94 289 276 minecraft:red_concrete
fill 94 288 277 94 289 278 minecraft:white_concrete
fill 94 288 279 94 289 279 minecraft:red_concrete
fill 94 288 281 94 289 282 minecraft:white_concrete
fill 94 288 283 94 289 284 minecraft:red_concrete
fill 94 288 285 94 289 286 minecraft:white_concrete
fill 94 288 287 94 289 287 minecraft:red_concrete
fill 94 288 289 94 289 290 minecraft:white_concrete
fill 94 288 291 94 289 292 minecraft:red_concrete
fill 94 288 293 94 289 294 minecraft:white_concrete
fill 94 288 295 94 289 295 minecraft:red_concrete
fill 94 288 297 94 289 298 minecraft:white_concrete
fill 94 288 299 94 289 300 minecraft:red_concrete
fill 94 288 301 94 289 302 minecraft:white_concrete
fill 94 288 303 94 289 303 minecraft:red_concrete
fill 94 288 305 94 289 306 minecraft:white_concrete
fill 94 288 307 94 289 308 minecraft:red_concrete
fill 94 288 309 94 289 310 minecraft:white_concrete
fill 94 288 311 94 289 311 minecraft:red_concrete
fill 94 288 313 94 289 314 minecraft:white_concrete
fill 94 288 315 94 289 316 minecraft:red_concrete
fill 95 288 275 95 289 275 minecraft:red_concrete
fill 95 288 317 95 289 317 minecraft:red_concrete
fill 96 288 275 97 289 275 minecraft:white_concrete
fill 96 288 317 96 289 317 minecraft:white_concrete
fill 98 288 275 99 289 275 minecraft:red_concrete
fill 98 288 317 99 289 317 minecraft:red_concrete
fill 100 288 275 100 289 275 minecraft:white_concrete
fill 100 288 317 101 289 317 minecraft:white_concrete
fill 102 288 275 103 289 275 minecraft:red_concrete
fill 102 288 317 103 289 317 minecraft:red_concrete
fill 104 288 275 105 289 275 minecraft:white_concrete
fill 104 288 317 104 289 317 minecraft:white_concrete
fill 106 288 275 107 289 275 minecraft:red_concrete
fill 106 288 317 107 289 317 minecraft:red_concrete
fill 107 288 285 107 288 289 minecraft:brown_terracotta
fill 108 288 275 108 289 275 minecraft:white_concrete
fill 108 288 284 108 288 285 minecraft:brown_terracotta
setblock 108 288 290 minecraft:brown_terracotta
fill 108 288 317 109 289 317 minecraft:white_concrete
setblock 109 288 284 minecraft:brown_terracotta
fill 109 288 291 113 288 291 minecraft:brown_terracotta
fill 110 288 275 111 289 275 minecraft:red_concrete
fill 110 288 283 112 288 283 minecraft:brown_terracotta
fill 110 288 317 111 289 317 minecraft:red_concrete
fill 112 288 275 113 289 275 minecraft:white_concrete
fill 112 288 317 112 289 317 minecraft:white_concrete
setblock 113 288 284 minecraft:brown_terracotta
fill 113 288 290 114 288 290 minecraft:brown_terracotta
fill 114 288 275 115 289 275 minecraft:red_concrete
setblock 114 288 285 minecraft:brown_terracotta
setblock 114 288 289 minecraft:brown_terracotta
fill 114 288 317 115 289 317 minecraft:red_concrete
fill 115 288 286 115 288 288 minecraft:brown_terracotta
fill 116 288 275 116 289 275 minecraft:white_concrete
fill 116 288 317 117 289 317 minecraft:white_concrete
fill 118 288 275 119 289 275 minecraft:red_concrete
fill 118 288 317 119 289 317 minecraft:red_concrete
fill 120 288 275 121 289 275 minecraft:white_concrete
fill 120 288 317 120 289 317 minecraft:white_concrete
fill 122 288 275 123 289 275 minecraft:red_concrete
fill 122 288 317 123 289 317 minecraft:red_concrete
fill 124 288 275 124 289 275 minecraft:white_concrete
fill 124 288 317 125 289 317 minecraft:white_concrete
fill 125 288 307 125 288 309 minecraft:brown_terracotta
fill 126 288 275 127 289 275 minecraft:red_concrete
setblock 126 288 306 minecraft:brown_terracotta
setblock 126 288 310 minecraft:brown_terracotta
fill 126 288 317 127 289 317 minecraft:red_concrete
fill 127 288 305 130 288 305 minecraft:brown_terracotta
fill 128 288 275 129 289 275 minecraft:white_concrete
fill 128 288 311 129 288 311 minecraft:brown_terracotta
fill 128 288 317 128 289 317 minecraft:white_concrete
fill 130 288 275 131 289 275 minecraft:red_concrete
setblock 130 288 310 minecraft:brown_terracotta
fill 130 288 317 131 289 317 minecraft:red_concrete
fill 131 288 306 131 288 309 minecraft:brown_terracotta
fill 132 288 275 132 289 275 minecraft:white_concrete
fill 132 288 317 133 289 317 minecraft:white_concrete
fill 134 288 275 135 289 275 minecraft:red_concrete
fill 134 288 317 135 289 317 minecraft:red_concrete
fill 136 288 276 136 289 276 minecraft:red_concrete
fill 136 288 277 136 289 278 minecraft:white_concrete
fill 136 288 279 136 289 279 minecraft:red_concrete
fill 136 288 281 136 289 282 minecraft:white_concrete
fill 136 288 283 136 289 284 minecraft:red_concrete
fill 136 288 285 136 289 286 minecraft:white_concrete
fill 136 288 287 136 289 287 minecraft:red_concrete
fill 136 288 289 136 289 290 minecraft:white_concrete
fill 136 288 291 136 289 292 minecraft:red_concrete
fill 136 288 293 136 289 294 minecraft:white_concrete
fill 136 288 295 136 289 295 minecraft:red_concrete
fill 136 288 297 136 289 298 minecraft:white_concrete
fill 136 288 299 136 289 300 minecraft:red_concrete
fill 136 288 301 136 289 302 minecraft:white_concrete
fill 136 288 303 136 289 303 minecraft:red_concrete
fill 136 288 305 136 289 306 minecraft:white_concrete
fill 136 288 307 136 289 308 minecraft:red_concrete
fill 136 288 309 136 289 310 minecraft:white_concrete
fill 136 288 311 136 289 311 minecraft:red_concrete
fill 136 288 313 136 289 314 minecraft:white_concrete
fill 136 288 315 136 289 316 minecraft:red_concrete
fill 136 288 317 136 289 317 minecraft:white_concrete
fill 94 290 275 94 291 276 minecraft:white_concrete
fill 94 290 277 94 291 278 minecraft:red_concrete
fill 94 290 279 94 291 280 minecraft:white_concrete
fill 94 290 281 94 291 282 minecraft:red_concrete
fill 94 290 283 94 291 284 minecraft:white_concrete
fill 94 290 285 94 291 286 minecraft:red_concrete
fill 94 290 287 94 291 288 minecraft:white_concrete
fill 94 290 289 94 291 290 minecraft:red_concrete
fill 94 290 291 94 291 292 minecraft:white_concrete
fill 94 290 293 94 291 294 minecraft:red_concrete
fill 94 290 295 94 291 296 minecraft:white_concrete
fill 94 290 297 94 291 298 minecraft:red_concrete
fill 94 290 299 94 291 300 minecraft:white_concrete
fill 94 290 301 94 291 302 minecraft:red_concrete
fill 94 290 303 94 291 304 minecraft:white_concrete
fill 94 290 305 94 291 306 minecraft:red_concrete
fill 94 290 307 94 291 308 minecraft:white_concrete
fill 94 290 309 94 291 310 minecraft:red_concrete
fill 94 290 311 94 291 312 minecraft:white_concrete
fill 94 290 313 94 291 314 minecraft:red_concrete
fill 94 290 315 94 291 316 minecraft:white_concrete
fill 95 290 275 95 291 275 minecraft:white_concrete
fill 95 290 317 95 291 317 minecraft:white_concrete
fill 96 290 275 97 291 275 minecraft:red_concrete
fill 96 290 308 96 290 310 minecraft:red_terracotta
fill 96 290 317 97 291 317 minecraft:red_concrete
fill 97 290 311 99 290 311 minecraft:red_terracotta
fill 98 290 275 99 291 275 minecraft:white_concrete
fill 98 290 317 99 291 317 minecraft:white_concrete
fill 100 290 275 101 291 275 minecraft:red_concrete
setblock 100 290 310 minecraft:red_terracotta
fill 100 290 317 101 291 317 minecraft:red_concrete
fill 102 290 275 103 291 275 minecraft:white_concrete
fill 102 290 317 103 291 317 minecraft:white_concrete
fill 104 290 275 105 291 275 minecraft:red_concrete
fill 104 290 317 105 291 317 minecraft:red_concrete
fill 106 290 275 107 291 275 minecraft:white_concrete
fill 106 290 317 107 291 317 minecraft:white_concrete
fill 108 290 275 109 291 275 minecraft:red_concrete
fill 108 290 317 109 291 317 minecraft:red_concrete
fill 110 290 275 111 291 275 minecraft:white_concrete
fill 110 290 317 111 291 317 minecraft:white_concrete
fill 112 290 275 113 291 275 minecraft:red_concrete
fill 112 290 317 113 291 317 minecraft:red_concrete
fill 114 290 275 115 291 275 minecraft:white_concrete
fill 114 290 317 115 291 317 minecraft:white_concrete
fill 116 290 275 117 291 275 minecraft:red_concrete
fill 116 290 317 117 291 317 minecraft:red_concrete
fill 118 290 275 119 291 275 minecraft:white_concrete
fill 118 290 317 119 291 317 minecraft:white_concrete
fill 120 290 275 121 291 275 minecraft:red_concrete
fill 120 290 317 121 291 317 minecraft:red_concrete
fill 122 290 275 123 291 275 minecraft:white_concrete
fill 122 290 317 123 291 317 minecraft:white_concrete
fill 124 290 275 125 291 275 minecraft:red_concrete
fill 124 290 317 125 291 317 minecraft:red_concrete
fill 126 290 275 127 291 275 minecraft:white_concrete
fill 126 290 317 127 291 317 minecraft:white_concrete
fill 128 290 275 129 291 275 minecraft:red_concrete
fill 128 290 297 132 293 297 minecraft:yellow_concrete
fill 128 290 317 129 291 317 minecraft:red_concrete
fill 129 290 296 131 293 296 minecraft:yellow_concrete
fill 129 290 298 131 293 298 minecraft:yellow_concrete
fill 130 290 275 131 291 275 minecraft:white_concrete
fill 130 290 295 130 293 295 minecraft:yellow_concrete
fill 130 290 299 130 293 299 minecraft:yellow_concrete
fill 130 290 317 131 291 317 minecraft:white_concrete
fill 132 290 275 133 291 275 minecraft:red_concrete
fill 132 290 317 133 291 317 minecraft:red_concrete
fill 134 290 275 135 291 275 minecraft:white_concrete
fill 134 290 317 135 291 317 minecraft:white_concrete
fill 136 290 276 136 291 276 minecraft:white_concrete
fill 136 290 277 136 291 278 minecraft:red_concrete
fill 136 290 279 136 291 280 minecraft:white_concrete
fill 136 290 281 136 291 282 minecraft:red_concrete
fill 136 290 283 136 291 284 minecraft:white_concrete
fill 136 290 285 136 291 286 minecraft:red_concrete
fill 136 290 287 136 291 288 minecraft:white_concrete
fill 136 290 289 136 291 290 minecraft:red_concrete
fill 136 290 291 136 291 292 minecraft:white_concrete
fill 136 290 293 136 291 294 minecraft:red_concrete
fill 136 290 295 136 291 296 minecraft:white_concrete
fill 136 290 297 136 291 298 minecraft:red_concrete
fill 136 290 299 136 291 300 minecraft:white_concrete
fill 136 290 301 136 291 302 minecraft:red_concrete
fill 136 290 303 136 291 304 minecraft:white_concrete
fill 136 290 305 136 291 306 minecraft:red_concrete
fill 136 290 307 136 291 308 minecraft:white_concrete
fill 136 290 309 136 291 310 minecraft:red_concrete
fill 136 290 311 136 291 312 minecraft:white_concrete
fill 136 290 313 136 291 314 minecraft:red_concrete
fill 136 290 315 136 291 316 minecraft:white_concrete
fill 136 290 317 136 291 317 minecraft:red_concrete
setblock 97 291 278 minecraft:light[level=12]
setblock 97 291 285 minecraft:light[level=12]
setblock 97 291 292 minecraft:light[level=12]
setblock 97 291 299 minecraft:light[level=12]
setblock 97 291 306 minecraft:light[level=12]
setblock 97 291 313 minecraft:light[level=12]
setblock 104 291 278 minecraft:light[level=12]
setblock 104 291 285 minecraft:light[level=12]
setblock 104 291 292 minecraft:light[level=12]
setblock 104 291 299 minecraft:light[level=12]
setblock 104 291 306 minecraft:light[level=12]
setblock 104 291 313 minecraft:light[level=12]
setblock 111 291 278 minecraft:light[level=12]
setblock 111 291 292 minecraft:light[level=12]
setblock 111 291 299 minecraft:light[level=12]
setblock 111 291 306 minecraft:light[level=12]
setblock 111 291 313 minecraft:light[level=12]
setblock 118 291 278 minecraft:light[level=12]
setblock 118 291 285 minecraft:light[level=12]
setblock 118 291 292 minecraft:light[level=12]
setblock 118 291 299 minecraft:light[level=12]
setblock 118 291 306 minecraft:light[level=12]
setblock 118 291 313 minecraft:light[level=12]
setblock 125 291 278 minecraft:light[level=12]
setblock 125 291 285 minecraft:light[level=12]
setblock 125 291 292 minecraft:light[level=12]
setblock 125 291 299 minecraft:light[level=12]
setblock 125 291 306 minecraft:light[level=12]
setblock 125 291 313 minecraft:light[level=12]
fill 128 291 296 128 292 296 minecraft:yellow_concrete
fill 128 291 298 128 292 298 minecraft:yellow_concrete
fill 129 291 295 129 292 295 minecraft:yellow_concrete
fill 129 291 299 129 292 299 minecraft:yellow_concrete
fill 131 291 295 131 292 295 minecraft:yellow_concrete
fill 131 291 299 131 292 299 minecraft:yellow_concrete
setblock 132 291 278 minecraft:light[level=12]
setblock 132 291 285 minecraft:light[level=12]
setblock 132 291 292 minecraft:light[level=12]
fill 132 291 296 132 292 296 minecraft:yellow_concrete
fill 132 291 298 132 292 298 minecraft:yellow_concrete
setblock 132 291 299 minecraft:light[level=12]
setblock 132 291 306 minecraft:light[level=12]
setblock 132 291 313 minecraft:light[level=12]
fill 94 292 275 94 293 276 minecraft:red_concrete
fill 94 292 277 94 293 278 minecraft:white_concrete
fill 94 292 279 94 293 280 minecraft:red_concrete
fill 94 292 281 94 293 282 minecraft:white_concrete
fill 94 292 283 94 293 284 minecraft:red_concrete
fill 94 292 285 94 293 286 minecraft:white_concrete
fill 94 292 287 94 293 288 minecraft:red_concrete
fill 94 292 289 94 293 290 minecraft:white_concrete
fill 94 292 291 94 293 292 minecraft:red_concrete
fill 94 292 293 94 293 294 minecraft:white_concrete
fill 94 292 295 94 293 296 minecraft:red_concrete
fill 94 292 297 94 293 298 minecraft:white_concrete
fill 94 292 299 94 293 300 minecraft:red_concrete
fill 94 292 301 94 293 302 minecraft:white_concrete
fill 94 292 303 94 293 304 minecraft:red_concrete
fill 94 292 305 94 293 306 minecraft:white_concrete
fill 94 292 307 94 293 308 minecraft:red_concrete
fill 94 292 309 94 293 310 minecraft:white_concrete
fill 94 292 311 94 293 312 minecraft:red_concrete
fill 94 292 313 94 293 314 minecraft:white_concrete
fill 94 292 315 94 293 316 minecraft:red_concrete
fill 95 292 275 95 293 275 minecraft:red_concrete
fill 95 292 317 95 293 317 minecraft:red_concrete
fill 96 292 275 97 293 275 minecraft:white_concrete
fill 96 292 317 97 293 317 minecraft:white_concrete
fill 98 292 275 99 293 275 minecraft:red_concrete
fill 98 292 317 99 293 317 minecraft:red_concrete
fill 100 292 275 101 293 275 minecraft:white_concrete
fill 100 292 317 101 293 317 minecraft:white_concrete
fill 102 292 275 103 293 275 minecraft:red_concrete
fill 102 292 317 103 293 317 minecraft:red_concrete
fill 104 292 275 105 293 275 minecraft:white_concrete
fill 104 292 317 105 293 317 minecraft:white_concrete
fill 106 292 275 107 293 275 minecraft:red_concrete
fill 106 292 317 107 293 317 minecraft:red_concrete
fill 108 292 275 109 293 275 minecraft:white_concrete
fill 108 292 317 109 293 317 minecraft:white_concrete
fill 110 292 275 111 293 275 minecraft:red_concrete
fill 110 292 317 111 293 317 minecraft:red_concrete
fill 112 292 275 113 293 275 minecraft:white_concrete
fill 112 292 317 113 293 317 minecraft:white_concrete
fill 114 292 275 115 293 275 minecraft:red_concrete
fill 114 292 317 115 293 317 minecraft:red_concrete
fill 116 292 275 117 293 275 minecraft:white_concrete
fill 116 292 317 117 293 317 minecraft:white_concrete
fill 118 292 275 119 293 275 minecraft:red_concrete
fill 118 292 317 119 293 317 minecraft:red_concrete
fill 120 292 275 121 293 275 minecraft:white_concrete
fill 120 292 317 121 293 317 minecraft:white_concrete
fill 122 292 275 123 293 275 minecraft:red_concrete
fill 122 292 317 123 293 317 minecraft:red_concrete
fill 124 292 275 125 293 275 minecraft:white_concrete
fill 124 292 317 125 293 317 minecraft:white_concrete
fill 126 292 275 127 293 275 minecraft:red_concrete
fill 126 292 317 127 293 317 minecraft:red_concrete
fill 128 292 275 129 293 275 minecraft:white_concrete
fill 128 292 317 129 293 317 minecraft:white_concrete
fill 130 292 275 131 293 275 minecraft:red_concrete
fill 130 292 317 131 293 317 minecraft:red_concrete
fill 132 292 275 133 293 275 minecraft:white_concrete
fill 132 292 317 133 293 317 minecraft:white_concrete
fill 134 292 275 135 293 275 minecraft:red_concrete
fill 134 292 317 135 293 317 minecraft:red_concrete
fill 136 292 276 136 293 276 minecraft:red_concrete
fill 136 292 277 136 293 278 minecraft:white_concrete
fill 136 292 279 136 293 280 minecraft:red_concrete
fill 136 292 281 136 293 282 minecraft:white_concrete
fill 136 292 283 136 293 284 minecraft:red_concrete
fill 136 292 285 136 293 286 minecraft:white_concrete
fill 136 292 287 136 293 288 minecraft:red_concrete
fill 136 292 289 136 293 290 minecraft:white_concrete
fill 136 292 291 136 293 292 minecraft:red_concrete
fill 136 292 293 136 293 294 minecraft:white_concrete
fill 136 292 295 136 293 296 minecraft:red_concrete
fill 136 292 297 136 293 298 minecraft:white_concrete
fill 136 292 299 136 293 300 minecraft:red_concrete
fill 136 292 301 136 293 302 minecraft:white_concrete
fill 136 292 303 136 293 304 minecraft:red_concrete
fill 136 292 305 136 293 306 minecraft:white_concrete
fill 136 292 307 136 293 308 minecraft:red_concrete
fill 136 292 309 136 293 310 minecraft:white_concrete
fill 136 292 311 136 293 312 minecraft:red_concrete
fill 136 292 313 136 293 314 minecraft:white_concrete
fill 136 292 315 136 293 316 minecraft:red_concrete
fill 136 292 317 136 293 317 minecraft:white_concrete
setblock 97 293 278 minecraft:light[level=15]
setblock 97 293 286 minecraft:light[level=15]
setblock 97 293 294 minecraft:light[level=15]
setblock 97 293 302 minecraft:light[level=15]
setblock 105 293 278 minecraft:light[level=15]
setblock 105 293 286 minecraft:light[level=15]
setblock 105 293 294 minecraft:light[level=15]
setblock 105 293 302 minecraft:light[level=15]
setblock 105 293 310 minecraft:light[level=15]
setblock 113 293 278 minecraft:light[level=15]
setblock 113 293 286 minecraft:light[level=15]
setblock 113 293 294 minecraft:light[level=15]
setblock 113 293 302 minecraft:light[level=15]
setblock 121 293 278 minecraft:light[level=15]
setblock 121 293 286 minecraft:light[level=15]
setblock 121 293 294 minecraft:light[level=15]
setblock 121 293 302 minecraft:light[level=15]
setblock 121 293 310 minecraft:light[level=15]
setblock 129 293 278 minecraft:light[level=15]
setblock 129 293 286 minecraft:light[level=15]
setblock 129 293 294 minecraft:light[level=15]
setblock 129 293 302 minecraft:light[level=15]
setblock 129 293 310 minecraft:light[level=15]
fill 94 294 275 94 295 276 minecraft:white_concrete
fill 94 294 277 94 295 278 minecraft:red_concrete
fill 94 294 279 94 295 280 minecraft:white_concrete
fill 94 294 281 94 295 282 minecraft:red_concrete
fill 94 294 283 94 295 284 minecraft:white_concrete
fill 94 294 285 94 295 286 minecraft:red_concrete
fill 94 294 287 94 295 288 minecraft:white_concrete
fill 94 294 289 94 295 290 minecraft:red_concrete
fill 94 294 291 94 295 292 minecraft:white_concrete
fill 94 294 293 94 295 294 minecraft:red_concrete
fill 94 294 295 94 295 296 minecraft:white_concrete
fill 94 294 297 94 295 298 minecraft:red_concrete
fill 94 294 299 94 295 300 minecraft:white_concrete
fill 94 294 301 94 295 302 minecraft:red_concrete
fill 94 294 303 94 295 304 minecraft:white_concrete
fill 94 294 305 94 295 306 minecraft:red_concrete
fill 94 294 307 94 295 308 minecraft:white_concrete
fill 94 294 309 94 295 310 minecraft:red_concrete
fill 94 294 311 94 295 312 minecraft:white_concrete
fill 94 294 313 94 295 314 minecraft:red_concrete
fill 94 294 315 94 295 316 minecraft:white_concrete
fill 95 294 275 95 295 275 minecraft:white_concrete
fill 95 294 276 95 295 281 minecraft:red_terracotta
fill 95 294 284 96 294 289 minecraft:red_terracotta
fill 95 294 292 96 294 297 minecraft:red_terracotta
fill 95 294 300 96 294 305 minecraft:red_terracotta
fill 95 294 308 96 294 313 minecraft:red_terracotta
fill 95 294 316 100 295 316 minecraft:red_terracotta
fill 95 294 317 95 295 317 minecraft:white_concrete
fill 96 294 275 97 295 275 minecraft:red_concrete
fill 96 294 277 96 294 283 minecraft:red_terracotta
fill 96 294 290 96 294 291 minecraft:red_terracotta
fill 96 294 298 96 294 299 minecraft:red_terracotta
fill 96 294 306 96 294 307 minecraft:red_terracotta
fill 96 294 314 96 294 315 minecraft:red_terracotta
fill 96 294 317 97 295 317 minecraft:red_concrete
fill 97 294 277 134 294 277 minecraft:red_terracotta
fill 97 294 315 135 294 315 minecraft:red_terracotta
fill 98 294 275 99 295 275 minecraft:white_concrete
fill 98 294 276 103 295 276 minecraft:red_terracotta
fill 98 294 317 99 295 317 minecraft:white_concrete
fill 100 294 275 101 295 275 minecraft:red_concrete
fill 100 294 317 101 295 317 minecraft:red_concrete
fill 102 294 275 103 295 275 minecraft:white_concrete
fill 102 294 317 103 295 317 minecraft:white_concrete
fill 103 294 316 108 295 316 minecraft:red_terracotta
fill 104 294 275 105 295 275 minecraft:red_concrete
fill 104 294 317 105 295 317 minecraft:red_concrete
fill 106 294 275 107 295 275 minecraft:white_concrete
fill 106 294 276 111 295 276 minecraft:red_terracotta
fill 106 294 317 107 295 317 minecraft:white_concrete
fill 108 294 275 109 295 275 minecraft:red_concrete
fill 108 294 317 109 295 317 minecraft:red_concrete
fill 110 294 275 111 295 275 minecraft:white_concrete
fill 110 294 317 111 295 317 minecraft:white_concrete
fill 111 294 316 116 295 316 minecraft:red_terracotta
fill 112 294 275 113 295 275 minecraft:red_concrete
fill 112 294 317 113 295 317 minecraft:red_concrete
fill 114 294 275 115 295 275 minecraft:white_concrete
fill 114 294 276 119 295 276 minecraft:red_terracotta
fill 114 294 317 115 295 317 minecraft:white_concrete
fill 116 294 275 117 295 275 minecraft:red_concrete
fill 116 294 317 117 295 317 minecraft:red_concrete
fill 118 294 275 119 295 275 minecraft:white_concrete
fill 118 294 317 119 295 317 minecraft:white_concrete
fill 119 294 316 124 295 316 minecraft:red_terracotta
fill 120 294 275 121 295 275 minecraft:red_concrete
fill 120 294 317 121 295 317 minecraft:red_concrete
fill 122 294 275 123 295 275 minecraft:white_concrete
fill 122 294 276 127 295 276 minecraft:red_terracotta
fill 122 294 317 123 295 317 minecraft:white_concrete
fill 124 294 275 125 295 275 minecraft:red_concrete
fill 124 294 317 125 295 317 minecraft:red_concrete
fill 126 294 275 127 295 275 minecraft:white_concrete
fill 126 294 317 127 295 317 minecraft:white_concrete
fill 127 294 316 132 295 316 minecraft:red_terracotta
fill 128 294 275 129 295 275 minecraft:red_concrete
fill 128 294 317 129 295 317 minecraft:red_concrete
fill 130 294 275 131 295 275 minecraft:white_concrete
fill 130 294 276 135 295 276 minecraft:red_terracotta
setblock 130 294 297 minecraft:yellow_concrete
fill 130 294 317 131 295 317 minecraft:white_concrete
fill 132 294 275 133 295 275 minecraft:red_concrete
fill 132 294 317 133 295 317 minecraft:red_concrete
fill 134 294 275 135 295 275 minecraft:white_concrete
fill 134 294 278 134 294 314 minecraft:red_terracotta
fill 134 294 317 135 295 317 minecraft:white_concrete
fill 135 294 279 135 295 284 minecraft:red_terracotta
fill 135 294 287 135 295 292 minecraft:red_terracotta
fill 135 294 295 135 295 300 minecraft:red_terracotta
fill 135 294 303 135 295 308 minecraft:red_terracotta
fill 135 294 311 135 295 314 minecraft:red_terracotta
fill 135 294 316 135 295 316 minecraft:red_terracotta
fill 136 294 276 136 295 276 minecraft:white_concrete
fill 136 294 277 136 295 278 minecraft:red_concrete
fill 136 294 279 136 295 280 minecraft:white_concrete
fill 136 294 281 136 295 282 minecraft:red_concrete
fill 136 294 283 136 295 284 minecraft:white_concrete
fill 136 294 285 136 295 286 minecraft:red_concrete
fill 136 294 287 136 295 288 minecraft:white_concrete
fill 136 294 289 136 295 290 minecraft:red_concrete
fill 136 294 291 136 295 292 minecraft:white_concrete
fill 136 294 293 136 295 294 minecraft:red_concrete
fill 136 294 295 136 295 296 minecraft:white_concrete
fill 136 294 297 136 295 298 minecraft:red_concrete
fill 136 294 299 136 295 300 minecraft:white_concrete
fill 136 294 301 136 295 302 minecraft:red_concrete
fill 136 294 303 136 295 304 minecraft:white_concrete
fill 136 294 305 136 295 306 minecraft:red_concrete
fill 136 294 307 136 295 308 minecraft:white_concrete
fill 136 294 309 136 295 310 minecraft:red_concrete
fill 136 294 311 136 295 312 minecraft:white_concrete
fill 136 294 313 136 295 314 minecraft:red_concrete
fill 136 294 315 136 295 316 minecraft:white_concrete
fill 136 294 317 136 295 317 minecraft:red_concrete
fill 95 295 284 95 295 289 minecraft:red_terracotta
fill 95 295 292 95 295 297 minecraft:red_terracotta
fill 95 295 300 95 295 305 minecraft:red_terracotta
fill 95 295 308 95 295 313 minecraft:red_terracotta
fill 96 295 308 96 295 310 minecraft:red_terracotta
fill 97 295 311 99 295 311 minecraft:red_terracotta
setblock 100 295 310 minecraft:red_terracotta
fill 125 295 291 126 296 292 minecraft:yellow_wool
setblock 135 295 315 minecraft:red_terracotta
fill 94 296 275 94 297 276 minecraft:red_concrete
fill 94 296 277 94 297 278 minecraft:white_concrete
fill 94 296 279 94 297 280 minecraft:red_concrete
fill 94 296 281 94 297 282 minecraft:white_concrete
fill 94 296 283 94 297 284 minecraft:red_concrete
fill 94 296 285 94 297 286 minecraft:white_concrete
fill 94 296 287 94 297 288 minecraft:red_concrete
fill 94 296 289 94 297 290 minecraft:white_concrete
fill 94 296 291 94 297 292 minecraft:red_concrete
fill 94 296 293 94 297 294 minecraft:white_concrete
fill 94 296 295 94 297 296 minecraft:red_concrete
fill 94 296 297 94 297 298 minecraft:white_concrete
fill 94 296 299 94 297 300 minecraft:red_concrete
fill 94 296 301 94 297 302 minecraft:white_concrete
fill 94 296 303 94 297 304 minecraft:red_concrete
fill 94 296 305 94 297 306 minecraft:white_concrete
fill 94 296 307 94 297 308 minecraft:red_concrete
fill 94 296 309 94 297 310 minecraft:white_concrete
fill 94 296 311 94 297 312 minecraft:red_concrete
fill 94 296 313 94 297 314 minecraft:white_concrete
fill 94 296 315 94 297 316 minecraft:red_concrete
fill 95 296 275 95 297 275 minecraft:red_concrete
fill 95 296 317 95 297 317 minecraft:red_concrete
fill 96 296 275 97 297 275 minecraft:white_concrete
fill 96 296 317 97 297 317 minecraft:white_concrete
fill 98 296 275 99 297 275 minecraft:red_concrete
fill 98 296 317 99 297 317 minecraft:red_concrete
fill 100 296 275 101 297 275 minecraft:white_concrete
fill 100 296 317 101 297 317 minecraft:white_concrete
fill 102 296 275 103 297 275 minecraft:red_concrete
fill 102 296 317 103 297 317 minecraft:red_concrete
fill 104 296 275 105 297 275 minecraft:white_concrete
fill 104 296 317 105 297 317 minecraft:white_concrete
fill 106 296 275 107 297 275 minecraft:red_concrete
fill 106 296 317 107 297 317 minecraft:red_concrete
fill 108 296 275 109 297 275 minecraft:white_concrete
fill 108 296 317 109 297 317 minecraft:white_concrete
fill 110 296 275 111 297 275 minecraft:red_concrete
fill 110 296 317 111 297 317 minecraft:red_concrete
fill 112 296 275 113 297 275 minecraft:white_concrete
fill 112 296 317 113 297 317 minecraft:white_concrete
fill 114 296 275 115 297 275 minecraft:red_concrete
fill 114 296 317 115 297 317 minecraft:red_concrete
fill 116 296 275 117 297 275 minecraft:white_concrete
fill 116 296 317 117 297 317 minecraft:white_concrete
fill 118 296 275 119 297 275 minecraft:red_concrete
fill 118 296 317 119 297 317 minecraft:red_concrete
fill 120 296 275 121 297 275 minecraft:white_concrete
fill 120 296 317 121 297 317 minecraft:white_concrete
fill 122 296 275 123 297 275 minecraft:red_concrete
fill 122 296 317 123 297 317 minecraft:red_concrete
fill 124 296 275 125 297 275 minecraft:white_concrete
fill 124 296 317 125 297 317 minecraft:white_concrete
fill 126 296 275 127 297 275 minecraft:red_concrete
fill 126 296 317 127 297 317 minecraft:red_concrete
fill 128 296 275 129 297 275 minecraft:white_concrete
fill 128 296 317 129 297 317 minecraft:white_concrete
fill 130 296 275 131 297 275 minecraft:red_concrete
fill 130 296 317 131 297 317 minecraft:red_concrete
fill 132 296 275 133 297 275 minecraft:white_concrete
fill 132 296 317 133 297 317 minecraft:white_concrete
fill 134 296 275 135 297 275 minecraft:red_concrete
fill 134 296 317 135 297 317 minecraft:red_concrete
fill 136 296 276 136 297 276 minecraft:red_concrete
fill 136 296 277 136 297 278 minecraft:white_concrete
fill 136 296 279 136 297 280 minecraft:red_concrete
fill 136 296 281 136 297 282 minecraft:white_concrete
fill 136 296 283 136 297 284 minecraft:red_concrete
fill 136 296 285 136 297 286 minecraft:white_concrete
fill 136 296 287 136 297 288 minecraft:red_concrete
fill 136 296 289 136 297 290 minecraft:white_concrete
fill 136 296 291 136 297 292 minecraft:red_concrete
fill 136 296 293 136 297 294 minecraft:white_concrete
fill 136 296 295 136 297 296 minecraft:red_concrete
fill 136 296 297 136 297 298 minecraft:white_concrete
fill 136 296 299 136 297 300 minecraft:red_concrete
fill 136 296 301 136 297 302 minecraft:white_concrete
fill 136 296 303 136 297 304 minecraft:red_concrete
fill 136 296 305 136 297 306 minecraft:white_concrete
fill 136 296 307 136 297 308 minecraft:red_concrete
fill 136 296 309 136 297 310 minecraft:white_concrete
fill 136 296 311 136 297 312 minecraft:red_concrete
fill 136 296 313 136 297 314 minecraft:white_concrete
fill 136 296 315 136 297 316 minecraft:red_concrete
fill 136 296 317 136 297 317 minecraft:white_concrete
fill 95 297 308 96 297 309 minecraft:yellow_concrete
fill 96 297 305 96 297 307 minecraft:yellow_concrete
fill 96 297 310 102 297 310 minecraft:yellow_concrete
setblock 97 297 278 minecraft:light[level=12]
setblock 97 297 285 minecraft:light[level=12]
setblock 97 297 292 minecraft:light[level=12]
setblock 97 297 299 minecraft:light[level=12]
fill 97 297 304 97 297 306 minecraft:yellow_concrete
fill 97 297 309 97 299 309 minecraft:yellow_concrete
fill 97 297 311 101 297 311 minecraft:yellow_concrete
setblock 97 297 313 minecraft:light[level=12]
fill 98 297 304 101 297 305 minecraft:yellow_concrete
fill 101 297 306 103 297 306 minecraft:yellow_concrete
fill 101 297 309 102 298 309 minecraft:yellow_concrete
setblock 102 297 305 minecraft:yellow_concrete
fill 102 297 307 103 297 308 minecraft:yellow_concrete
setblock 104 297 278 minecraft:light[level=12]
setblock 104 297 285 minecraft:light[level=12]
setblock 104 297 292 minecraft:light[level=12]
setblock 104 297 299 minecraft:light[level=12]
setblock 104 297 306 minecraft:light[level=12]
setblock 104 297 313 minecraft:light[level=12]
fill 107 297 285 108 297 289 minecraft:yellow_concrete
fill 108 297 284 114 297 284 minecraft:yellow_concrete
fill 108 297 290 114 297 290 minecraft:yellow_concrete
fill 109 297 283 112 297 283 minecraft:yellow_concrete
fill 109 297 285 109 299 285 minecraft:yellow_concrete
fill 109 297 289 109 299 289 minecraft:yellow_concrete
fill 109 297 291 113 297 291 minecraft:yellow_concrete
fill 109 297 310 111 297 313 minecraft:yellow_concrete
fill 110 297 308 112 297 309 minecraft:yellow_concrete
fill 110 297 314 117 297 314 minecraft:yellow_concrete
setblock 111 297 278 minecraft:light[level=12]
setblock 111 297 292 minecraft:light[level=12]
setblock 111 297 299 minecraft:light[level=12]
setblock 111 297 306 minecraft:light[level=12]
fill 111 297 315 116 297 315 minecraft:yellow_concrete
fill 112 297 285 114 298 285 minecraft:yellow_concrete
fill 112 297 307 115 297 307 minecraft:yellow_concrete
fill 113 297 286 115 297 286 minecraft:yellow_concrete
fill 113 297 289 115 297 289 minecraft:yellow_concrete
fill 113 297 308 117 297 308 minecraft:yellow_concrete
fill 113 297 316 114 297 316 minecraft:yellow_concrete
fill 114 297 287 115 297 288 minecraft:yellow_concrete
fill 115 297 309 117 297 309 minecraft:yellow_concrete
fill 116 297 310 118 297 310 minecraft:yellow_concrete
fill 116 297 312 118 297 313 minecraft:yellow_concrete
fill 117 297 311 118 297 311 minecraft:yellow_concrete
setblock 118 297 278 minecraft:light[level=12]
setblock 118 297 285 minecraft:light[level=12]
setblock 118 297 292 minecraft:light[level=12]
setblock 118 297 299 minecraft:light[level=12]
setblock 118 297 306 minecraft:light[level=12]
fill 122 297 310 124 298 310 minecraft:green_concrete
fill 123 297 309 123 298 309 minecraft:green_concrete
fill 123 297 311 123 298 311 minecraft:green_concrete
setblock 125 297 278 minecraft:light[level=12]
setblock 125 297 285 minecraft:light[level=12]
setblock 125 297 292 minecraft:light[level=12]
setblock 125 297 299 minecraft:light[level=12]
setblock 125 297 306 minecraft:light[level=12]
fill 125 297 307 126 297 309 minecraft:yellow_concrete
setblock 125 297 313 minecraft:light[level=12]
fill 126 297 305 127 297 306 minecraft:yellow_concrete
fill 126 297 310 130 297 310 minecraft:yellow_concrete
fill 127 297 311 129 297 311 minecraft:yellow_concrete
fill 128 297 305 130 297 305 minecraft:yellow_concrete
fill 129 297 306 131 297 306 minecraft:yellow_concrete
fill 130 297 307 131 298 307 minecraft:yellow_concrete
fill 130 297 309 131 297 309 minecraft:yellow_concrete
fill 131 297 308 131 298 308 minecraft:yellow_concrete
setblock 132 297 278 minecraft:light[level=12]
setblock 132 297 285 minecraft:light[level=12]
setblock 132 297 292 minecraft:light[level=12]
setblock 132 297 299 minecraft:light[level=12]
setblock 132 297 306 minecraft:light[level=12]
setblock 132 297 313 minecraft:light[level=12]
fill 94 298 275 94 299 276 minecraft:white_concrete
fill 94 298 277 94 299 278 minecraft:red_concrete
fill 94 298 279 94 299 279 minecraft:white_concrete
fill 94 298 280 94 300 280 minecraft:shroomlight
fill 94 298 281 94 299 282 minecraft:red_concrete
fill 94 298 283 94 299 284 minecraft:white_concrete
fill 94 298 285 94 299 286 minecraft:red_concrete
fill 94 298 287 94 299 287 minecraft:white_concrete
fill 94 298 288 94 300 288 minecraft:shroomlight
fill 94 298 289 94 299 290 minecraft:red_concrete
fill 94 298 291 94 299 292 minecraft:white_concrete
fill 94 298 293 94 299 294 minecraft:red_concrete
fill 94 298 295 94 299 295 minecraft:white_concrete
fill 94 298 296 94 300 296 minecraft:shroomlight
fill 94 298 297 94 299 298 minecraft:red_concrete
fill 94 298 299 94 299 300 minecraft:white_concrete
fill 94 298 301 94 299 302 minecraft:red_concrete
fill 94 298 303 94 299 303 minecraft:white_concrete
fill 94 298 304 94 300 304 minecraft:shroomlight
fill 94 298 305 94 299 306 minecraft:red_concrete
fill 94 298 307 94 299 308 minecraft:white_concrete
fill 94 298 309 94 299 310 minecraft:red_concrete
fill 94 298 311 94 299 311 minecraft:white_concrete
fill 94 298 312 94 300 312 minecraft:shroomlight
fill 94 298 313 94 299 314 minecraft:red_concrete
fill 94 298 315 94 299 316 minecraft:white_concrete
fill 95 298 275 95 299 275 minecraft:white_concrete
fill 95 298 317 95 299 317 minecraft:white_concrete
fill 96 298 275 97 299 275 minecraft:red_concrete
fill 96 298 306 96 298 309 minecraft:yellow_concrete
fill 96 298 317 96 299 317 minecraft:red_concrete
fill 97 298 305 97 298 306 minecraft:yellow_concrete
fill 97 298 310 101 298 310 minecraft:yellow_concrete
fill 97 298 317 97 300 317 minecraft:shroomlight
fill 98 298 275 99 299 275 minecraft:white_concrete
fill 98 298 304 100 298 305 minecraft:yellow_concrete
fill 98 298 317 99 299 317 minecraft:white_concrete
setblock 99 298 311 minecraft:yellow_concrete
fill 100 298 275 100 299 275 minecraft:red_concrete
fill 100 298 317 101 299 317 minecraft:red_concrete
fill 101 298 275 101 300 275 minecraft:shroomlight
fill 101 298 305 101 298 306 minecraft:yellow_concrete
fill 102 298 275 103 299 275 minecraft:white_concrete
fill 102 298 306 102 298 308 minecraft:yellow_concrete
fill 102 298 317 103 299 317 minecraft:white_concrete
fill 104 298 275 105 299 275 minecraft:red_concrete
fill 104 298 317 104 299 317 minecraft:red_concrete
fill 105 298 317 105 300 317 minecraft:shroomlight
fill 106 298 275 107 299 275 minecraft:white_concrete
fill 106 298 317 107 299 317 minecraft:white_concrete
fill 107 298 287 108 298 288 minecraft:yellow_concrete
fill 108 298 275 108 299 275 minecraft:red_concrete
fill 108 298 285 108 298 286 minecraft:yellow_concrete
setblock 108 298 289 minecraft:yellow_concrete
fill 108 298 317 109 299 317 minecraft:red_concrete
fill 109 298 275 109 300 275 minecraft:shroomlight
fill 109 298 284 113 298 284 minecraft:yellow_concrete
fill 109 298 290 113 298 290 minecraft:yellow_concrete
fill 110 298 275 111 299 275 minecraft:white_concrete
fill 110 298 291 111 298 291 minecraft:yellow_concrete
fill 110 298 310 111 298 313 minecraft:yellow_concrete
fill 110 298 317 111 299 317 minecraft:white_concrete
fill 111 298 309 112 298 309 minecraft:yellow_concrete
fill 111 298 314 116 298 314 minecraft:yellow_concrete
fill 112 298 275 113 299 275 minecraft:red_concrete
fill 112 298 308 115 298 308 minecraft:yellow_concrete
fill 112 298 315 115 298 315 minecraft:yellow_concrete
fill 112 298 317 112 299 317 minecraft:red_concrete
fill 113 298 286 114 298 286 minecraft:yellow_concrete
fill 113 298 289 114 298 289 minecraft:yellow_concrete
fill 113 298 317 113 300 317 minecraft:shroomlight
fill 114 298 275 115 299 275 minecraft:white_concrete
fill 114 298 287 114 298 288 minecraft:yellow_concrete
fill 114 298 317 115 299 317 minecraft:white_concrete
fill 115 298 309 116 298 309 minecraft:yellow_concrete
fill 116 298 275 116 299 275 minecraft:red_concrete
fill 116 298 310 117 298 310 minecraft:yellow_concrete
fill 116 298 312 117 298 313 minecraft:yellow_concrete
fill 116 298 317 117 299 317 minecraft:red_concrete
fill 117 298 275 117 300 275 minecraft:shroomlight
setblock 117 298 311 minecraft:yellow_concrete
fill 118 298 275 119 299 275 minecraft:white_concrete
fill 118 298 317 119 299 317 minecraft:white_concrete
fill 120 298 275 121 299 275 minecraft:red_concrete
fill 120 298 317 120 299 317 minecraft:red_concrete
fill 121 298 317 121 300 317 minecraft:shroomlight
fill 122 298 275 123 299 275 minecraft:white_concrete
fill 122 298 317 123 299 317 minecraft:white_concrete
fill 124 298 275 124 299 275 minecraft:red_concrete
fill 124 298 317 125 299 317 minecraft:red_concrete
fill 125 298 275 125 300 275 minecraft:shroomlight
fill 126 298 275 127 299 275 minecraft:white_concrete
fill 126 298 306 126 298 309 minecraft:yellow_concrete
fill 126 298 317 127 299 317 minecraft:white_concrete
fill 127 298 305 127 298 306 minecraft:yellow_concrete
fill 127 298 310 130 298 310 minecraft:yellow_concrete
fill 128 298 275 129 299 275 minecraft:red_concrete
fill 128 298 305 129 298 305 minecraft:yellow_concrete
fill 128 298 317 128 299 317 minecraft:red_concrete
fill 129 298 306 130 298 306 minecraft:yellow_concrete
fill 129 298 317 129 300 317 minecraft:shroomlight
fill 130 298 275 131 299 275 minecraft:white_concrete
fill 130 298 309 130 299 309 minecraft:yellow_concrete
fill 130 298 317 131 299 317 minecraft:white_concrete
fill 132 298 275 132 299 275 minecraft:red_concrete
fill 132 298 317 133 299 317 minecraft:red_concrete
fill 133 298 275 133 300 275 minecraft:shroomlight
fill 134 298 275 135 299 275 minecraft:white_concrete
fill 134 298 317 135 299 317 minecraft:white_concrete
fill 136 298 276 136 299 276 minecraft:white_concrete
fill 136 298 277 136 299 278 minecraft:red_concrete
fill 136 298 279 136 299 279 minecraft:white_concrete
fill 136 298 280 136 300 280 minecraft:shroomlight
fill 136 298 281 136 299 282 minecraft:red_concrete
fill 136 298 283 136 299 284 minecraft:white_concrete
fill 136 298 285 136 299 286 minecraft:red_concrete
fill 136 298 287 136 299 287 minecraft:white_concrete
fill 136 298 288 136 300 288 minecraft:shroomlight
fill 136 298 289 136 299 290 minecraft:red_concrete
fill 136 298 291 136 299 292 minecraft:white_concrete
fill 136 298 293 136 299 294 minecraft:red_concrete
fill 136 298 295 136 299 295 minecraft:white_concrete
fill 136 298 296 136 300 296 minecraft:shroomlight
fill 136 298 297 136 299 298 minecraft:red_concrete
fill 136 298 299 136 299 300 minecraft:white_concrete
fill 136 298 301 136 299 302 minecraft:red_concrete
fill 136 298 303 136 299 303 minecraft:white_concrete
fill 136 298 304 136 300 304 minecraft:shroomlight
fill 136 298 305 136 299 306 minecraft:red_concrete
fill 136 298 307 136 299 308 minecraft:white_concrete
fill 136 298 309 136 299 310 minecraft:red_concrete
fill 136 298 311 136 299 311 minecraft:white_concrete
fill 136 298 312 136 300 312 minecraft:shroomlight
fill 136 298 313 136 299 314 minecraft:red_concrete
fill 136 298 315 136 299 316 minecraft:white_concrete
fill 136 298 317 136 299 317 minecraft:red_concrete
fill 95 299 308 96 300 310 minecraft:iron_block
setblock 97 299 306 minecraft:yellow_concrete
fill 97 299 310 97 300 310 minecraft:iron_block
fill 98 299 305 100 299 305 minecraft:yellow_concrete
fill 98 299 310 100 299 310 minecraft:yellow_concrete
setblock 101 299 306 minecraft:yellow_concrete
setblock 101 299 309 minecraft:yellow_concrete
fill 108 299 286 108 299 288 minecraft:yellow_concrete
fill 110 299 290 112 299 290 minecraft:yellow_concrete
fill 111 299 310 111 299 313 minecraft:yellow_concrete
fill 112 299 285 113 299 285 minecraft:yellow_concrete
setblock 112 299 309 minecraft:yellow_concrete
fill 112 299 314 115 299 314 minecraft:yellow_concrete
setblock 113 299 286 minecraft:yellow_concrete
setblock 113 299 289 minecraft:yellow_concrete
setblock 114 299 287 minecraft:yellow_concrete
setblock 115 299 309 minecraft:yellow_concrete
setblock 116 299 310 minecraft:yellow_concrete
fill 116 299 312 116 299 313 minecraft:yellow_concrete
fill 126 299 307 126 299 308 minecraft:yellow_concrete
setblock 127 299 306 minecraft:yellow_concrete
fill 128 299 310 129 299 310 minecraft:yellow_concrete
setblock 129 299 306 minecraft:yellow_concrete
setblock 130 299 307 minecraft:yellow_concrete
fill 94 300 275 94 301 276 minecraft:red_concrete
fill 94 300 277 94 301 278 minecraft:white_concrete
fill 94 300 279 94 301 279 minecraft:red_concrete
fill 94 300 281 94 301 282 minecraft:white_concrete
fill 94 300 283 94 301 284 minecraft:red_concrete
fill 94 300 285 94 301 286 minecraft:white_concrete
fill 94 300 287 94 301 287 minecraft:red_concrete
fill 94 300 289 94 301 290 minecraft:white_concrete
fill 94 300 291 94 301 292 minecraft:red_concrete
fill 94 300 293 94 301 294 minecraft:white_concrete
fill 94 300 295 94 301 295 minecraft:red_concrete
fill 94 300 297 94 301 298 minecraft:white_concrete
fill 94 300 299 94 301 300 minecraft:red_concrete
fill 94 300 301 94 301 302 minecraft:white_concrete
fill 94 300 303 94 301 303 minecraft:red_concrete
fill 94 300 305 94 301 306 minecraft:white_concrete
fill 94 300 307 94 301 308 minecraft:red_concrete
fill 94 300 309 94 301 310 minecraft:white_concrete
fill 94 300 311 94 301 311 minecraft:red_concrete
fill 94 300 313 94 301 314 minecraft:white_concrete
fill 94 300 315 94 301 316 minecraft:red_concrete
fill 95 300 275 95 301 275 minecraft:red_concrete
fill 95 300 317 95 301 317 minecraft:red_concrete
fill 96 300 275 97 301 275 minecraft:white_concrete
fill 96 300 317 96 301 317 minecraft:white_concrete
setblock 97 300 309 minecraft:iron_block
fill 98 300 275 99 301 275 minecraft:red_concrete
fill 98 300 310 99 300 310 minecraft:iron_block
fill 98 300 317 99 301 317 minecraft:red_concrete
fill 100 300 275 100 301 275 minecraft:white_concrete
fill 100 300 317 101 301 317 minecraft:white_concrete
fill 102 300 275 103 301 275 minecraft:red_concrete
fill 102 300 317 103 301 317 minecraft:red_concrete
fill 104 300 275 105 301 275 minecraft:white_concrete
fill 104 300 317 104 301 317 minecraft:white_concrete
fill 106 300 275 107 301 275 minecraft:red_concrete
fill 106 300 317 107 301 317 minecraft:red_concrete
fill 108 300 275 108 301 275 minecraft:white_concrete
fill 108 300 317 109 301 317 minecraft:white_concrete
fill 110 300 275 111 301 275 minecraft:red_concrete
fill 110 300 317 111 301 317 minecraft:red_concrete
fill 112 300 275 113 301 275 minecraft:white_concrete
fill 112 300 317 112 301 317 minecraft:white_concrete
fill 114 300 275 115 301 275 minecraft:red_concrete
fill 114 300 317 115 301 317 minecraft:red_concrete
fill 116 300 275 116 301 275 minecraft:white_concrete
fill 116 300 317 117 301 317 minecraft:white_concrete
fill 118 300 275 119 301 275 minecraft:red_concrete
fill 118 300 317 119 301 317 minecraft:red_concrete
setblock 119 300 314 minecraft:iron_block
fill 120 300 275 121 301 275 minecraft:white_concrete
setblock 120 300 313 minecraft:iron_block
fill 120 300 314 122 300 314 minecraft:black_concrete
setblock 120 300 315 minecraft:iron_block
fill 120 300 317 120 301 317 minecraft:white_concrete
setblock 121 300 312 minecraft:iron_block
setblock 121 300 313 minecraft:black_concrete
setblock 121 300 315 minecraft:black_concrete
setblock 121 300 316 minecraft:iron_block
fill 122 300 275 123 301 275 minecraft:red_concrete
setblock 122 300 313 minecraft:iron_block
setblock 122 300 315 minecraft:iron_block
fill 122 300 317 123 301 317 minecraft:red_concrete
setblock 123 300 314 minecraft:iron_block
fill 124 300 275 124 301 275 minecraft:white_concrete
fill 124 300 317 125 301 317 minecraft:white_concrete
fill 126 300 275 127 301 275 minecraft:red_concrete
fill 126 300 317 127 301 317 minecraft:red_concrete
fill 128 300 275 129 301 275 minecraft:white_concrete
fill 128 300 317 128 301 317 minecraft:white_concrete
fill 130 300 275 131 301 275 minecraft:red_concrete
fill 130 300 317 131 301 317 minecraft:red_concrete
fill 132 300 275 132 301 275 minecraft:white_concrete
fill 132 300 317 133 301 317 minecraft:white_concrete
fill 134 300 275 135 301 275 minecraft:red_concrete
fill 134 300 317 135 301 317 minecraft:red_concrete
fill 136 300 276 136 301 276 minecraft:red_concrete
fill 136 300 277 136 301 278 minecraft:white_concrete
fill 136 300 279 136 301 279 minecraft:red_concrete
fill 136 300 281 136 301 282 minecraft:white_concrete
fill 136 300 283 136 301 284 minecraft:red_concrete
fill 136 300 285 136 301 286 minecraft:white_concrete
fill 136 300 287 136 301 287 minecraft:red_concrete
fill 136 300 289 136 301 290 minecraft:white_concrete
fill 136 300 291 136 301 292 minecraft:red_concrete
fill 136 300 293 136 301 294 minecraft:white_concrete
fill 136 300 295 136 301 295 minecraft:red_concrete
fill 136 300 297 136 301 298 minecraft:white_concrete
fill 136 300 299 136 301 300 minecraft:red_concrete
fill 136 300 301 136 301 302 minecraft:white_concrete
fill 136 300 303 136 301 303 minecraft:red_concrete
fill 136 300 305 136 301 306 minecraft:white_concrete
fill 136 300 307 136 301 308 minecraft:red_concrete
fill 136 300 309 136 301 310 minecraft:white_concrete
fill 136 300 311 136 301 311 minecraft:red_concrete
fill 136 300 313 136 301 314 minecraft:white_concrete
fill 136 300 315 136 301 316 minecraft:red_concrete
fill 136 300 317 136 301 317 minecraft:white_concrete
setblock 94 301 280 minecraft:red_concrete
setblock 94 301 288 minecraft:red_concrete
setblock 94 301 296 minecraft:red_concrete
setblock 94 301 304 minecraft:red_concrete
setblock 94 301 312 minecraft:red_concrete
setblock 97 301 278 minecraft:light[level=15]
setblock 97 301 286 minecraft:light[level=15]
setblock 97 301 294 minecraft:light[level=15]
setblock 97 301 302 minecraft:light[level=15]
setblock 97 301 310 minecraft:light[level=15]
setblock 97 301 317 minecraft:white_concrete
setblock 101 301 275 minecraft:white_concrete
setblock 105 301 278 minecraft:light[level=15]
setblock 105 301 286 minecraft:light[level=15]
setblock 105 301 294 minecraft:light[level=15]
setblock 105 301 302 minecraft:light[level=15]
setblock 105 301 310 minecraft:light[level=15]
setblock 105 301 317 minecraft:white_concrete
setblock 109 301 275 minecraft:white_concrete
setblock 113 301 278 minecraft:light[level=15]
setblock 113 301 286 minecraft:light[level=15]
setblock 113 301 294 minecraft:light[level=15]
setblock 113 301 302 minecraft:light[level=15]
setblock 113 301 310 minecraft:light[level=15]
setblock 113 301 317 minecraft:white_concrete
setblock 117 301 275 minecraft:white_concrete
setblock 121 301 278 minecraft:light[level=15]
setblock 121 301 286 minecraft:light[level=15]
setblock 121 301 294 minecraft:light[level=15]
setblock 121 301 302 minecraft:light[level=15]
setblock 121 301 310 minecraft:light[level=15]
setblock 121 301 317 minecraft:white_concrete
setblock 125 301 275 minecraft:white_concrete
setblock 129 301 278 minecraft:light[level=15]
setblock 129 301 286 minecraft:light[level=15]
setblock 129 301 294 minecraft:light[level=15]
setblock 129 301 302 minecraft:light[level=15]
setblock 129 301 310 minecraft:light[level=15]
setblock 129 301 317 minecraft:white_concrete
setblock 133 301 275 minecraft:white_concrete
setblock 136 301 280 minecraft:red_concrete
setblock 136 301 288 minecraft:red_concrete
setblock 136 301 296 minecraft:red_concrete
setblock 136 301 304 minecraft:red_concrete
setblock 136 301 312 minecraft:red_concrete
fill 94 302 275 94 303 276 minecraft:white_concrete
fill 94 302 277 94 303 278 minecraft:red_concrete
fill 94 302 279 94 303 280 minecraft:white_concrete
fill 94 302 281 94 303 282 minecraft:red_concrete
fill 94 302 283 94 303 284 minecraft:white_concrete
fill 94 302 285 94 303 286 minecraft:red_concrete
fill 94 302 287 94 303 288 minecraft:white_concrete
fill 94 302 289 94 303 290 minecraft:red_concrete
fill 94 302 291 94 303 292 minecraft:white_concrete
fill 94 302 293 94 303 294 minecraft:red_concrete
fill 94 302 295 94 303 296 minecraft:white_concrete
fill 94 302 297 94 303 298 minecraft:red_concrete
fill 94 302 299 94 303 300 minecraft:white_concrete
fill 94 302 301 94 303 302 minecraft:red_concrete
fill 94 302 303 94 303 304 minecraft:white_concrete
fill 94 302 305 94 303 306 minecraft:red_concrete
fill 94 302 307 94 303 308 minecraft:white_concrete
fill 94 302 309 94 303 310 minecraft:red_concrete
fill 94 302 311 94 303 312 minecraft:white_concrete
fill 94 302 313 94 303 314 minecraft:red_concrete
fill 94 302 315 94 303 316 minecraft:white_concrete
fill 95 302 275 95 303 275 minecraft:white_concrete
fill 95 302 317 95 303 317 minecraft:white_concrete
fill 96 302 275 97 303 275 minecraft:red_concrete
fill 96 302 317 97 303 317 minecraft:red_concrete
fill 98 302 275 99 303 275 minecraft:white_concrete
fill 98 302 317 99 303 317 minecraft:white_concrete
fill 100 302 275 101 303 275 minecraft:red_concrete
fill 100 302 317 101 303 317 minecraft:red_concrete
fill 102 302 275 103 303 275 minecraft:white_concrete
fill 102 302 317 103 303 317 minecraft:white_concrete
fill 104 302 275 105 303 275 minecraft:red_concrete
fill 104 302 317 105 303 317 minecraft:red_concrete
fill 106 302 275 107 303 275 minecraft:white_concrete
fill 106 302 317 107 303 317 minecraft:white_concrete
fill 108 302 275 109 303 275 minecraft:red_concrete
fill 108 302 317 109 303 317 minecraft:red_concrete
fill 110 302 275 111 303 275 minecraft:white_concrete
fill 110 302 317 111 303 317 minecraft:white_concrete
fill 112 302 275 113 303 275 minecraft:red_concrete
fill 112 302 317 113 303 317 minecraft:red_concrete
fill 114 302 275 115 303 275 minecraft:white_concrete
fill 114 302 317 115 303 317 minecraft:white_concrete
fill 116 302 275 117 303 275 minecraft:red_concrete
fill 116 302 317 117 303 317 minecraft:red_concrete
fill 118 302 275 119 303 275 minecraft:white_concrete
fill 118 302 317 119 303 317 minecraft:white_concrete
fill 120 302 275 121 303 275 minecraft:red_concrete
fill 120 302 317 121 303 317 minecraft:red_concrete
fill 122 302 275 123 303 275 minecraft:white_concrete
fill 122 302 317 123 303 317 minecraft:white_concrete
fill 124 302 275 125 303 275 minecraft:red_concrete
fill 124 302 317 125 303 317 minecraft:red_concrete
fill 126 302 275 127 303 275 minecraft:white_concrete
fill 126 302 317 127 303 317 minecraft:white_concrete
fill 128 302 275 129 303 275 minecraft:red_concrete
fill 128 302 317 129 303 317 minecraft:red_concrete
fill 130 302 275 131 303 275 minecraft:white_concrete
fill 130 302 317 131 303 317 minecraft:white_concrete
fill 132 302 275 133 303 275 minecraft:red_concrete
fill 132 302 317 133 303 317 minecraft:red_concrete
fill 134 302 275 135 303 275 minecraft:white_concrete
fill 134 302 317 135 303 317 minecraft:white_concrete
fill 136 302 276 136 303 276 minecraft:white_concrete
fill 136 302 277 136 303 278 minecraft:red_concrete
fill 136 302 279 136 303 280 minecraft:white_concrete
fill 136 302 281 136 303 282 minecraft:red_concrete
fill 136 302 283 136 303 284 minecraft:white_concrete
fill 136 302 285 136 303 286 minecraft:red_concrete
fill 136 302 287 136 303 288 minecraft:white_concrete
fill 136 302 289 136 303 290 minecraft:red_concrete
fill 136 302 291 136 303 292 minecraft:white_concrete
fill 136 302 293 136 303 294 minecraft:red_concrete
fill 136 302 295 136 303 296 minecraft:white_concrete
fill 136 302 297 136 303 298 minecraft:red_concrete
fill 136 302 299 136 303 300 minecraft:white_concrete
fill 136 302 301 136 303 302 minecraft:red_concrete
fill 136 302 303 136 303 304 minecraft:white_concrete
fill 136 302 305 136 303 306 minecraft:red_concrete
fill 136 302 307 136 303 308 minecraft:white_concrete
fill 136 302 309 136 303 310 minecraft:red_concrete
fill 136 302 311 136 303 312 minecraft:white_concrete
fill 136 302 313 136 303 314 minecraft:red_concrete
fill 136 302 315 136 303 316 minecraft:white_concrete
fill 136 302 317 136 303 317 minecraft:red_concrete
setblock 97 303 278 minecraft:light[level=12]
setblock 97 303 285 minecraft:light[level=12]
setblock 97 303 292 minecraft:light[level=12]
setblock 97 303 299 minecraft:light[level=12]
setblock 97 303 306 minecraft:light[level=12]
setblock 97 303 313 minecraft:light[level=12]
setblock 104 303 278 minecraft:light[level=12]
setblock 104 303 285 minecraft:light[level=12]
setblock 104 303 292 minecraft:light[level=12]
setblock 104 303 299 minecraft:light[level=12]
setblock 104 303 306 minecraft:light[level=12]
setblock 104 303 313 minecraft:light[level=12]
setblock 111 303 278 minecraft:light[level=12]
setblock 111 303 285 minecraft:light[level=12]
setblock 111 303 292 minecraft:light[level=12]
setblock 111 303 299 minecraft:light[level=12]
setblock 111 303 306 minecraft:light[level=12]
setblock 111 303 313 minecraft:light[level=12]
setblock 118 303 278 minecraft:light[level=12]
setblock 118 303 285 minecraft:light[level=12]
setblock 118 303 292 minecraft:light[level=12]
setblock 118 303 299 minecraft:light[level=12]
setblock 118 303 306 minecraft:light[level=12]
setblock 118 303 313 minecraft:light[level=12]
setblock 125 303 278 minecraft:light[level=12]
setblock 125 303 285 minecraft:light[level=12]
setblock 125 303 292 minecraft:light[level=12]
setblock 125 303 299 minecraft:light[level=12]
setblock 125 303 306 minecraft:light[level=12]
setblock 125 303 313 minecraft:light[level=12]
setblock 132 303 278 minecraft:light[level=12]
setblock 132 303 285 minecraft:light[level=12]
setblock 132 303 292 minecraft:light[level=12]
setblock 132 303 299 minecraft:light[level=12]
setblock 132 303 306 minecraft:light[level=12]
setblock 132 303 313 minecraft:light[level=12]
fill 94 304 275 94 305 276 minecraft:red_concrete
fill 94 304 277 94 305 278 minecraft:white_concrete
fill 94 304 279 94 305 280 minecraft:red_concrete
fill 94 304 281 94 305 282 minecraft:white_concrete
fill 94 304 283 94 305 284 minecraft:red_concrete
fill 94 304 285 94 305 286 minecraft:white_concrete
fill 94 304 287 94 305 288 minecraft:red_concrete
fill 94 304 289 94 305 290 minecraft:white_concrete
fill 94 304 291 94 305 292 minecraft:red_concrete
fill 94 304 293 94 305 294 minecraft:white_concrete
fill 94 304 295 94 305 296 minecraft:red_concrete
fill 94 304 297 94 305 298 minecraft:white_concrete
fill 94 304 299 94 305 300 minecraft:red_concrete
fill 94 304 301 94 305 302 minecraft:white_concrete
fill 94 304 303 94 305 304 minecraft:red_concrete
fill 94 304 305 94 305 306 minecraft:white_concrete
fill 94 304 307 94 305 308 minecraft:red_concrete
fill 94 304 309 94 305 310 minecraft:white_concrete
fill 94 304 311 94 305 312 minecraft:red_concrete
fill 94 304 313 94 305 314 minecraft:white_concrete
fill 94 304 315 94 305 316 minecraft:red_concrete
fill 95 304 275 95 305 275 minecraft:red_concrete
fill 95 304 317 95 305 317 minecraft:red_concrete
fill 96 304 275 97 305 275 minecraft:white_concrete
fill 96 304 317 97 305 317 minecraft:white_concrete
fill 98 304 275 99 305 275 minecraft:red_concrete
fill 98 304 317 99 305 317 minecraft:red_concrete
fill 100 304 275 101 305 275 minecraft:white_concrete
fill 100 304 317 101 305 317 minecraft:white_concrete
fill 102 304 275 103 305 275 minecraft:red_concrete
fill 102 304 317 103 305 317 minecraft:red_concrete
fill 104 304 275 105 305 275 minecraft:white_concrete
fill 104 304 317 105 305 317 minecraft:white_concrete
fill 106 304 275 107 305 275 minecraft:red_concrete
fill 106 304 317 107 305 317 minecraft:red_concrete
fill 108 304 275 109 305 275 minecraft:white_concrete
fill 108 304 317 109 305 317 minecraft:white_concrete
fill 110 304 275 111 305 275 minecraft:red_concrete
fill 110 304 317 111 305 317 minecraft:red_concrete
fill 112 304 275 113 305 275 minecraft:white_concrete
fill 112 304 317 113 305 317 minecraft:white_concrete
fill 114 304 275 115 305 275 minecraft:red_concrete
fill 114 304 317 115 305 317 minecraft:red_concrete
fill 116 304 275 117 305 275 minecraft:white_concrete
fill 116 304 317 117 305 317 minecraft:white_concrete
fill 118 304 275 119 305 275 minecraft:red_concrete
fill 118 304 317 119 305 317 minecraft:red_concrete
fill 120 304 275 121 305 275 minecraft:white_concrete
fill 120 304 317 121 305 317 minecraft:white_concrete
fill 122 304 275 123 305 275 minecraft:red_concrete
fill 122 304 317 123 305 317 minecraft:red_concrete
fill 124 304 275 125 305 275 minecraft:white_concrete
fill 124 304 317 125 305 317 minecraft:white_concrete
fill 126 304 275 127 305 275 minecraft:red_concrete
fill 126 304 317 127 305 317 minecraft:red_concrete
fill 128 304 275 129 305 275 minecraft:white_concrete
fill 128 304 317 129 305 317 minecraft:white_concrete
fill 130 304 275 131 305 275 minecraft:red_concrete
fill 130 304 317 131 305 317 minecraft:red_concrete
fill 132 304 275 133 305 275 minecraft:white_concrete
fill 132 304 317 133 305 317 minecraft:white_concrete
fill 134 304 275 135 305 275 minecraft:red_concrete
fill 134 304 317 135 305 317 minecraft:red_concrete
fill 136 304 276 136 305 276 minecraft:red_concrete
fill 136 304 277 136 305 278 minecraft:white_concrete
fill 136 304 279 136 305 280 minecraft:red_concrete
fill 136 304 281 136 305 282 minecraft:white_concrete
fill 136 304 283 136 305 284 minecraft:red_concrete
fill 136 304 285 136 305 286 minecraft:white_concrete
fill 136 304 287 136 305 288 minecraft:red_concrete
fill 136 304 289 136 305 290 minecraft:white_concrete
fill 136 304 291 136 305 292 minecraft:red_concrete
fill 136 304 293 136 305 294 minecraft:white_concrete
fill 136 304 295 136 305 296 minecraft:red_concrete
fill 136 304 297 136 305 298 minecraft:white_concrete
fill 136 304 299 136 305 300 minecraft:red_concrete
fill 136 304 301 136 305 302 minecraft:white_concrete
fill 136 304 303 136 305 304 minecraft:red_concrete
fill 136 304 305 136 305 306 minecraft:white_concrete
fill 136 304 307 136 305 308 minecraft:red_concrete
fill 136 304 309 136 305 310 minecraft:white_concrete
fill 136 304 311 136 305 312 minecraft:red_concrete
fill 136 304 313 136 305 314 minecraft:white_concrete
fill 136 304 315 136 305 316 minecraft:red_concrete
fill 136 304 317 136 305 317 minecraft:white_concrete
fill 94 306 275 94 307 276 minecraft:white_concrete
fill 94 306 277 94 307 278 minecraft:red_concrete
fill 94 306 279 94 307 280 minecraft:white_concrete
fill 94 306 281 94 307 282 minecraft:red_concrete
fill 94 306 283 94 307 284 minecraft:white_concrete
fill 94 306 285 94 307 286 minecraft:red_concrete
fill 94 306 287 94 307 288 minecraft:white_concrete
fill 94 306 289 94 307 290 minecraft:red_concrete
fill 94 306 291 94 307 292 minecraft:white_concrete
fill 94 306 293 94 307 294 minecraft:red_concrete
fill 94 306 295 94 307 296 minecraft:white_concrete
fill 94 306 297 94 307 298 minecraft:red_concrete
fill 94 306 299 94 307 300 minecraft:white_concrete
fill 94 306 301 94 307 302 minecraft:red_concrete
fill 94 306 303 94 307 304 minecraft:white_concrete
fill 94 306 305 94 307 306 minecraft:red_concrete
fill 94 306 307 94 307 308 minecraft:white_concrete
fill 94 306 309 94 307 310 minecraft:red_concrete
fill 94 306 311 94 307 312 minecraft:white_concrete
fill 94 306 313 94 307 314 minecraft:red_concrete
fill 94 306 315 94 307 316 minecraft:white_concrete
fill 95 306 275 95 307 275 minecraft:white_concrete
fill 95 306 317 95 307 317 minecraft:white_concrete
fill 96 306 275 97 307 275 minecraft:red_concrete
fill 96 306 317 97 307 317 minecraft:red_concrete
fill 98 306 275 99 307 275 minecraft:white_concrete
fill 98 306 317 99 307 317 minecraft:white_concrete
fill 100 306 275 101 307 275 minecraft:red_concrete
fill 100 306 317 101 307 317 minecraft:red_concrete
fill 102 306 275 103 307 275 minecraft:white_concrete
fill 102 306 317 103 307 317 minecraft:white_concrete
fill 104 306 275 105 307 275 minecraft:red_concrete
fill 104 306 317 105 307 317 minecraft:red_concrete
fill 106 306 275 107 307 275 minecraft:white_concrete
fill 106 306 317 107 307 317 minecraft:white_concrete
fill 108 306 275 109 307 275 minecraft:red_concrete
fill 108 306 317 109 307 317 minecraft:red_concrete
fill 110 306 275 111 307 275 minecraft:white_concrete
fill 110 306 317 111 307 317 minecraft:white_concrete
fill 112 306 275 113 307 275 minecraft:red_concrete
fill 112 306 317 113 307 317 minecraft:red_concrete
fill 114 306 275 115 307 275 minecraft:white_concrete
fill 114 306 317 115 307 317 minecraft:white_concrete
fill 116 306 275 117 307 275 minecraft:red_concrete
fill 116 306 317 117 307 317 minecraft:red_concrete
fill 118 306 275 119 307 275 minecraft:white_concrete
fill 118 306 317 119 307 317 minecraft:white_concrete
fill 120 306 275 121 307 275 minecraft:red_concrete
fill 120 306 317 121 307 317 minecraft:red_concrete
fill 122 306 275 123 307 275 minecraft:white_concrete
fill 122 306 317 123 307 317 minecraft:white_concrete
fill 124 306 275 125 307 275 minecraft:red_concrete
fill 124 306 317 125 307 317 minecraft:red_concrete
fill 126 306 275 127 307 275 minecraft:white_concrete
fill 126 306 317 127 307 317 minecraft:white_concrete
fill 128 306 275 129 307 275 minecraft:red_concrete
fill 128 306 317 129 307 317 minecraft:red_concrete
fill 130 306 275 131 307 275 minecraft:white_concrete
fill 130 306 317 131 307 317 minecraft:white_concrete
fill 132 306 275 133 307 275 minecraft:red_concrete
fill 132 306 317 133 307 317 minecraft:red_concrete
fill 134 306 275 135 307 275 minecraft:white_concrete
fill 134 306 317 135 307 317 minecraft:white_concrete
fill 136 306 276 136 307 276 minecraft:white_concrete
fill 136 306 277 136 307 278 minecraft:red_concrete
fill 136 306 279 136 307 280 minecraft:white_concrete
fill 136 306 281 136 307 282 minecraft:red_concrete
fill 136 306 283 136 307 284 minecraft:white_concrete
fill 136 306 285 136 307 286 minecraft:red_concrete
fill 136 306 287 136 307 288 minecraft:white_concrete
fill 136 306 289 136 307 290 minecraft:red_concrete
fill 136 306 291 136 307 292 minecraft:white_concrete
fill 136 306 293 136 307 294 minecraft:red_concrete
fill 136 306 295 136 307 296 minecraft:white_concrete
fill 136 306 297 136 307 298 minecraft:red_concrete
fill 136 306 299 136 307 300 minecraft:white_concrete
fill 136 306 301 136 307 302 minecraft:red_concrete
fill 136 306 303 136 307 304 minecraft:white_concrete
fill 136 306 305 136 307 306 minecraft:red_concrete
fill 136 306 307 136 307 308 minecraft:white_concrete
fill 136 306 309 136 307 310 minecraft:red_concrete
fill 136 306 311 136 307 312 minecraft:white_concrete
fill 136 306 313 136 307 314 minecraft:red_concrete
fill 136 306 315 136 307 316 minecraft:white_concrete
fill 136 306 317 136 307 317 minecraft:red_concrete
fill 94 308 275 94 308 276 minecraft:red_concrete
fill 94 308 277 94 308 278 minecraft:white_concrete
fill 94 308 279 94 308 280 minecraft:red_concrete
fill 94 308 281 94 308 282 minecraft:white_concrete
fill 94 308 283 94 308 284 minecraft:red_concrete
fill 94 308 285 94 308 286 minecraft:white_concrete
fill 94 308 287 94 308 288 minecraft:red_concrete
fill 94 308 289 94 308 290 minecraft:white_concrete
fill 94 308 291 94 308 292 minecraft:red_concrete
fill 94 308 293 94 308 294 minecraft:white_concrete
fill 94 308 295 94 308 296 minecraft:red_concrete
fill 94 308 297 94 308 298 minecraft:white_concrete
fill 94 308 299 94 308 300 minecraft:red_concrete
fill 94 308 301 94 308 302 minecraft:white_concrete
fill 94 308 303 94 308 304 minecraft:red_concrete
fill 94 308 305 94 308 306 minecraft:white_concrete
fill 94 308 307 94 308 308 minecraft:red_concrete
fill 94 308 309 94 308 310 minecraft:white_concrete
fill 94 308 311 94 308 312 minecraft:red_concrete
fill 94 308 313 94 308 314 minecraft:white_concrete
fill 94 308 315 94 308 316 minecraft:red_concrete
setblock 95 308 275 minecraft:red_concrete
setblock 95 308 317 minecraft:red_concrete
fill 96 308 275 97 308 275 minecraft:white_concrete
fill 96 308 317 97 308 317 minecraft:white_concrete
fill 98 308 275 99 308 275 minecraft:red_concrete
fill 98 308 317 99 308 317 minecraft:red_concrete
fill 100 308 275 101 308 275 minecraft:white_concrete
fill 100 308 317 101 308 317 minecraft:white_concrete
fill 102 308 275 103 308 275 minecraft:red_concrete
fill 102 308 317 103 308 317 minecraft:red_concrete
fill 104 308 275 105 308 275 minecraft:white_concrete
fill 104 308 317 105 308 317 minecraft:white_concrete
fill 106 308 275 107 308 275 minecraft:red_concrete
fill 106 308 317 107 308 317 minecraft:red_concrete
fill 108 308 275 109 308 275 minecraft:white_concrete
fill 108 308 317 109 308 317 minecraft:white_concrete
fill 110 308 275 111 308 275 minecraft:red_concrete
fill 110 308 317 111 308 317 minecraft:red_concrete
fill 112 308 275 113 308 275 minecraft:white_concrete
fill 112 308 317 113 308 317 minecraft:white_concrete
fill 114 308 275 115 308 275 minecraft:red_concrete
fill 114 308 317 115 308 317 minecraft:red_concrete
fill 116 308 275 117 308 275 minecraft:white_concrete
fill 116 308 317 117 308 317 minecraft:white_concrete
fill 118 308 275 119 308 275 minecraft:red_concrete
fill 118 308 317 119 308 317 minecraft:red_concrete
fill 120 308 275 121 308 275 minecraft:white_concrete
fill 120 308 317 121 308 317 minecraft:white_concrete
fill 122 308 275 123 308 275 minecraft:red_concrete
fill 122 308 317 123 308 317 minecraft:red_concrete
fill 124 308 275 125 308 275 minecraft:white_concrete
fill 124 308 317 125 308 317 minecraft:white_concrete
fill 126 308 275 127 308 275 minecraft:red_concrete
fill 126 308 317 127 308 317 minecraft:red_concrete
fill 128 308 275 129 308 275 minecraft:white_concrete
fill 128 308 317 129 308 317 minecraft:white_concrete
fill 130 308 275 131 308 275 minecraft:red_concrete
fill 130 308 317 131 308 317 minecraft:red_concrete
fill 132 308 275 133 308 275 minecraft:white_concrete
fill 132 308 317 133 308 317 minecraft:white_concrete
fill 134 308 275 135 308 275 minecraft:red_concrete
fill 134 308 317 135 308 317 minecraft:red_concrete
setblock 136 308 276 minecraft:red_concrete
fill 136 308 277 136 308 278 minecraft:white_concrete
fill 136 308 279 136 308 280 minecraft:red_concrete
fill 136 308 281 136 308 282 minecraft:white_concrete
fill 136 308 283 136 308 284 minecraft:red_concrete
fill 136 308 285 136 308 286 minecraft:white_concrete
fill 136 308 287 136 308 288 minecraft:red_concrete
fill 136 308 289 136 308 290 minecraft:white_concrete
fill 136 308 291 136 308 292 minecraft:red_concrete
fill 136 308 293 136 308 294 minecraft:white_concrete
fill 136 308 295 136 308 296 minecraft:red_concrete
fill 136 308 297 136 308 298 minecraft:white_concrete
fill 136 308 299 136 308 300 minecraft:red_concrete
fill 136 308 301 136 308 302 minecraft:white_concrete
fill 136 308 303 136 308 304 minecraft:red_concrete
fill 136 308 305 136 308 306 minecraft:white_concrete
fill 136 308 307 136 308 308 minecraft:red_concrete
fill 136 308 309 136 308 310 minecraft:white_concrete
fill 136 308 311 136 308 312 minecraft:red_concrete
fill 136 308 313 136 308 314 minecraft:white_concrete
fill 136 308 315 136 308 316 minecraft:red_concrete
setblock 136 308 317 minecraft:white_concrete
