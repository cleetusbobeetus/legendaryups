fill 106 131 574 106 131 575 minecraft:gray_concrete
setblock 106 131 582 minecraft:gray_concrete
fill 108 131 571 109 131 571 minecraft:gray_concrete
fill 108 131 585 109 131 585 minecraft:gray_concrete
fill 109 131 570 111 131 570 minecraft:gray_concrete
fill 112 131 587 114 131 587 minecraft:gray_concrete
setblock 115 131 561 minecraft:light_gray_concrete
fill 117 131 570 129 131 570 minecraft:gray_concrete
fill 117 131 586 119 131 586 minecraft:gray_concrete
fill 119 131 571 124 131 571 minecraft:gray_concrete
fill 119 131 585 129 131 585 minecraft:gray_concrete
fill 121 131 572 123 131 573 minecraft:gray_concrete
fill 121 131 583 129 131 584 minecraft:gray_concrete
fill 122 131 578 125 132 578 minecraft:gray_concrete
fill 122 131 581 126 131 582 minecraft:gray_concrete
fill 123 131 576 125 131 577 minecraft:gray_concrete
fill 123 131 579 125 131 580 minecraft:gray_concrete
fill 124 131 572 129 132 572 minecraft:gray_concrete
fill 127 131 581 129 133 581 minecraft:gray_concrete
fill 130 131 583 130 133 583 minecraft:gray_concrete
setblock 136 131 574 minecraft:white_stained_glass
setblock 136 131 588 minecraft:pearlescent_froglight
fill 136 131 596 136 169 596 minecraft:black_concrete
setblock 136 131 597 minecraft:pearlescent_froglight
fill 94 132 589 94 147 589 minecraft:black_concrete
fill 100 132 581 103 132 581 minecraft:gray_concrete
fill 101 132 580 103 132 580 minecraft:gray_concrete
fill 102 132 568 110 132 568 minecraft:gray_concrete
fill 102 132 574 103 132 578 minecraft:gray_concrete
setblock 103 132 579 minecraft:gray_concrete
fill 103 132 586 107 132 587 minecraft:gray_concrete
setblock 104 132 574 minecraft:gray_concrete
fill 104 132 584 105 132 585 minecraft:gray_concrete
setblock 105 132 557 minecraft:pearlescent_froglight
fill 105 132 570 105 132 572 minecraft:gray_concrete
fill 106 132 570 106 132 571 minecraft:gray_concrete
setblock 106 132 585 minecraft:gray_concrete
fill 107 132 569 107 132 570 minecraft:gray_concrete
setblock 108 132 569 minecraft:gray_concrete
fill 108 132 587 108 132 592 minecraft:gray_concrete
fill 109 132 588 110 132 592 minecraft:gray_concrete
fill 111 132 589 111 132 592 minecraft:gray_concrete
fill 118 132 568 120 132 568 minecraft:gray_concrete
fill 118 132 588 126 132 588 minecraft:gray_concrete
fill 120 132 569 125 132 569 minecraft:gray_concrete
fill 120 132 587 121 132 587 minecraft:gray_concrete
fill 121 132 570 129 132 570 minecraft:gray_concrete
fill 122 132 571 124 132 571 minecraft:gray_concrete
fill 122 132 572 122 133 573 minecraft:light_gray_concrete
fill 122 132 585 129 132 585 minecraft:gray_concrete
setblock 123 132 572 minecraft:gray_concrete
setblock 123 132 577 minecraft:gray_concrete
setblock 123 132 579 minecraft:gray_concrete
fill 123 132 584 129 132 584 minecraft:gray_concrete
fill 124 132 582 126 132 583 minecraft:gray_concrete
fill 125 132 575 125 132 577 minecraft:gray_concrete
fill 125 132 579 125 132 581 minecraft:gray_concrete
fill 126 132 575 128 132 575 minecraft:gray_concrete
setblock 126 132 581 minecraft:gray_concrete
fill 127 132 583 129 133 583 minecraft:gray_concrete
fill 136 132 574 136 166 574 minecraft:black_concrete
setblock 136 132 582 minecraft:white_concrete
fill 136 132 588 136 169 588 minecraft:black_concrete
fill 136 132 597 136 159 597 minecraft:black_concrete
setblock 94 133 563 minecraft:white_stained_glass
fill 99 133 582 102 133 582 minecraft:gray_concrete
fill 100 133 581 101 133 581 minecraft:gray_concrete
fill 101 133 569 102 133 573 minecraft:gray_concrete
setblock 101 133 580 minecraft:gray_concrete
fill 102 133 568 106 133 568 minecraft:gray_concrete
setblock 102 133 574 minecraft:gray_concrete
fill 103 133 569 103 133 572 minecraft:gray_concrete
setblock 103 133 584 minecraft:gray_concrete
fill 103 133 586 104 133 587 minecraft:gray_concrete
fill 104 133 569 104 133 570 minecraft:gray_concrete
fill 105 133 557 105 166 557 minecraft:black_concrete
setblock 105 133 569 minecraft:end_stone
setblock 105 133 587 minecraft:gray_concrete
fill 107 133 589 107 133 592 minecraft:end_stone
fill 108 133 589 108 133 592 minecraft:gray_concrete
setblock 109 133 566 minecraft:gray_concrete
fill 109 133 590 110 133 592 minecraft:gray_concrete
fill 111 133 591 111 133 592 minecraft:gray_concrete
fill 113 133 591 117 133 591 minecraft:gray_concrete
fill 118 133 566 120 133 566 minecraft:gray_concrete
setblock 119 133 599 minecraft:pearlescent_froglight
setblock 120 133 567 minecraft:gray_concrete
fill 120 133 589 126 133 589 minecraft:gray_concrete
fill 121 133 564 121 133 567 minecraft:end_stone
fill 122 133 588 126 133 588 minecraft:gray_concrete
fill 123 133 569 125 133 569 minecraft:gray_concrete
setblock 123 133 587 minecraft:end_stone
fill 124 133 570 129 133 570 minecraft:gray_concrete
fill 124 133 586 129 133 586 minecraft:gray_concrete
fill 125 133 572 129 133 572 minecraft:gray_concrete
fill 125 133 584 129 133 585 minecraft:gray_concrete
fill 126 133 573 129 133 574 minecraft:gray_concrete
fill 126 133 582 126 133 583 minecraft:gray_concrete
fill 127 133 575 127 133 576 minecraft:gray_concrete
fill 127 133 578 130 133 580 minecraft:gray_concrete
setblock 128 133 575 minecraft:gray_concrete
setblock 130 133 573 minecraft:gray_concrete
setblock 133 133 557 minecraft:white_concrete
setblock 136 133 567 minecraft:white_concrete
fill 136 133 582 136 136 582 minecraft:black_concrete
fill 94 134 563 94 169 563 minecraft:black_concrete
fill 119 134 599 119 160 599 minecraft:black_concrete
fill 133 134 557 133 141 557 minecraft:black_concrete
setblock 136 134 558 minecraft:white_concrete
fill 136 134 559 136 165 560 minecraft:black_concrete
setblock 136 134 567 minecraft:white_stained_glass
fill 136 134 570 136 134 571 minecraft:pearlescent_froglight
fill 136 134 578 136 159 578 minecraft:black_concrete
setblock 136 134 579 minecraft:pearlescent_froglight
setblock 94 135 572 minecraft:white_stained_glass
setblock 96 135 599 minecraft:white_stained_glass
fill 136 135 558 136 166 558 minecraft:black_concrete
setblock 136 135 567 minecraft:black_concrete
fill 136 135 570 136 164 571 minecraft:black_concrete
fill 136 135 579 136 148 579 minecraft:black_concrete
fill 94 136 565 94 137 565 minecraft:light_gray_concrete
fill 94 136 572 94 158 572 minecraft:black_concrete
setblock 94 136 575 minecraft:white_stained_glass
fill 94 136 581 94 137 581 minecraft:light_gray_concrete
fill 94 136 597 94 137 597 minecraft:light_gray_concrete
fill 96 136 599 96 166 599 minecraft:black_concrete
fill 98 136 557 98 137 557 minecraft:light_gray_concrete
setblock 98 136 599 minecraft:white_concrete
fill 99 136 557 99 144 557 minecraft:black_concrete
fill 108 136 599 108 137 599 minecraft:light_gray_concrete
fill 114 136 557 114 137 557 minecraft:light_gray_concrete
fill 124 136 557 124 164 557 minecraft:black_concrete
fill 124 136 599 124 137 599 minecraft:light_gray_concrete
setblock 125 136 557 minecraft:white_concrete
fill 130 136 557 130 137 557 minecraft:light_gray_concrete
fill 136 136 567 136 137 567 minecraft:light_gray_concrete
fill 136 136 583 136 137 583 minecraft:light_gray_concrete
setblock 94 137 558 minecraft:pearlescent_froglight
fill 94 137 575 94 166 575 minecraft:black_concrete
setblock 94 137 593 minecraft:white_stained_glass
fill 94 137 594 94 143 595 minecraft:black_concrete
fill 98 137 599 98 154 599 minecraft:black_concrete
fill 124 137 575 126 138 576 minecraft:light_gray_concrete
fill 125 137 557 125 169 557 minecraft:black_concrete
setblock 136 137 582 minecraft:pearlescent_froglight
fill 94 138 558 94 147 558 minecraft:black_concrete
fill 94 138 565 94 144 565 minecraft:black_concrete
setblock 94 138 580 minecraft:pearlescent_froglight
fill 94 138 581 94 144 581 minecraft:black_concrete
fill 94 138 593 94 169 593 minecraft:black_concrete
fill 94 138 597 94 144 597 minecraft:black_concrete
setblock 97 138 560 minecraft:light[level=14]
setblock 97 138 568 minecraft:light[level=14]
setblock 97 138 576 minecraft:light[level=14]
setblock 97 138 584 minecraft:light[level=14]
setblock 97 138 592 minecraft:light[level=14]
fill 98 138 557 98 144 557 minecraft:black_concrete
setblock 105 138 560 minecraft:light[level=14]
setblock 105 138 568 minecraft:light[level=14]
setblock 105 138 576 minecraft:light[level=14]
setblock 105 138 584 minecraft:light[level=14]
setblock 105 138 592 minecraft:light[level=14]
fill 108 138 599 108 144 599 minecraft:black_concrete
setblock 113 138 560 minecraft:light[level=14]
setblock 113 138 568 minecraft:light[level=14]
setblock 113 138 576 minecraft:light[level=14]
setblock 113 138 584 minecraft:light[level=14]
setblock 113 138 592 minecraft:light[level=14]
fill 114 138 557 114 144 557 minecraft:black_concrete
setblock 121 138 560 minecraft:light[level=14]
setblock 121 138 568 minecraft:light[level=14]
setblock 121 138 576 minecraft:light[level=14]
setblock 121 138 584 minecraft:light[level=14]
setblock 121 138 592 minecraft:light[level=14]
fill 124 138 599 124 144 599 minecraft:black_concrete
setblock 129 138 560 minecraft:light[level=14]
setblock 129 138 568 minecraft:light[level=14]
setblock 129 138 576 minecraft:light[level=14]
setblock 129 138 584 minecraft:light[level=14]
setblock 129 138 592 minecraft:light[level=14]
fill 130 138 557 130 139 557 minecraft:black_concrete
setblock 130 138 599 minecraft:white_concrete
setblock 132 138 557 minecraft:white_stained_glass
setblock 136 138 566 minecraft:white_stained_glass
fill 136 138 567 136 139 567 minecraft:black_concrete
fill 136 138 582 136 139 583 minecraft:black_concrete
setblock 94 139 560 minecraft:pearlescent_froglight
fill 94 139 580 94 162 580 minecraft:black_concrete
setblock 122 139 557 minecraft:white_stained_glass
fill 130 139 599 130 169 599 minecraft:black_concrete
fill 132 139 557 132 141 557 minecraft:black_concrete
setblock 136 139 566 minecraft:pearlescent_froglight
setblock 136 139 592 minecraft:pearlescent_froglight
fill 94 140 560 94 141 560 minecraft:black_concrete
setblock 94 140 561 minecraft:white_stained_glass
setblock 94 140 596 minecraft:pearlescent_froglight
setblock 100 140 557 minecraft:white_stained_glass
fill 101 140 557 101 142 557 minecraft:black_concrete
fill 122 140 557 122 165 557 minecraft:black_concrete
setblock 130 140 557 minecraft:white_concrete
fill 136 140 566 136 144 566 minecraft:black_concrete
setblock 136 140 567 minecraft:pearlescent_froglight
setblock 136 140 580 minecraft:white_concrete
fill 136 140 581 136 169 581 minecraft:black_concrete
setblock 136 140 582 minecraft:white_concrete
fill 136 140 583 136 143 583 minecraft:black_concrete
fill 136 140 592 136 147 592 minecraft:black_concrete
fill 94 141 561 94 167 561 minecraft:black_concrete
fill 94 141 596 94 160 596 minecraft:black_concrete
fill 100 141 557 100 170 557 minecraft:black_concrete
setblock 112 141 557 minecraft:white_stained_glass
fill 121 141 593 122 142 594 minecraft:gray_concrete
fill 130 141 557 130 144 557 minecraft:black_concrete
setblock 132 141 599 minecraft:white_concrete
fill 136 141 567 136 144 567 minecraft:black_concrete
fill 136 141 580 136 165 580 minecraft:black_concrete
fill 136 141 582 136 169 582 minecraft:black_concrete
setblock 94 142 560 minecraft:pearlescent_froglight
fill 112 142 557 112 165 557 minecraft:black_concrete
setblock 123 142 599 minecraft:white_stained_glass
setblock 132 142 557 minecraft:white_stained_glass
fill 132 142 599 132 166 599 minecraft:black_concrete
setblock 133 142 557 minecraft:white_concrete
fill 94 143 560 94 169 560 minecraft:black_concrete
setblock 101 143 557 minecraft:white_concrete
fill 123 143 599 123 157 599 minecraft:black_concrete
setblock 131 143 599 minecraft:pearlescent_froglight
fill 132 143 557 134 166 557 minecraft:black_concrete
setblock 135 143 557 minecraft:pearlescent_froglight
fill 136 143 557 136 169 557 minecraft:black_concrete
setblock 94 144 568 minecraft:white_stained_glass
fill 94 144 569 94 166 570 minecraft:black_concrete
fill 94 144 594 94 156 594 minecraft:black_concrete
setblock 94 144 595 minecraft:white_stained_glass
fill 101 144 557 101 169 557 minecraft:black_concrete
setblock 111 144 557 minecraft:white_stained_glass
fill 127 144 578 128 145 579 minecraft:end_stone
fill 129 144 579 129 145 579 minecraft:end_stone
fill 131 144 599 131 170 599 minecraft:black_concrete
fill 135 144 557 135 165 557 minecraft:black_concrete
setblock 136 144 577 minecraft:white_concrete
setblock 136 144 583 minecraft:white_stained_glass
setblock 136 144 585 minecraft:pearlescent_froglight
fill 136 144 586 136 161 587 minecraft:black_concrete
fill 94 145 565 94 146 565 minecraft:light_gray_concrete
fill 94 145 568 94 169 568 minecraft:black_concrete
fill 94 145 581 94 146 581 minecraft:light_gray_concrete
fill 94 145 595 94 164 595 minecraft:black_concrete
fill 94 145 597 94 146 597 minecraft:light_gray_concrete
fill 98 145 557 98 146 557 minecraft:light_gray_concrete
setblock 99 145 557 minecraft:pearlescent_froglight
fill 108 145 599 108 146 599 minecraft:light_gray_concrete
fill 111 145 557 111 169 557 minecraft:black_concrete
fill 114 145 557 114 146 557 minecraft:light_gray_concrete
setblock 121 145 557 minecraft:white_stained_glass
fill 124 145 599 124 146 599 minecraft:light_gray_concrete
fill 125 145 586 126 146 586 minecraft:light_gray_concrete
setblock 128 145 557 minecraft:white_stained_glass
fill 130 145 557 130 146 557 minecraft:light_gray_concrete
setblock 136 145 566 minecraft:white_concrete
fill 136 145 567 136 146 567 minecraft:light_gray_concrete
fill 136 145 577 136 152 577 minecraft:black_concrete
fill 136 145 583 136 146 583 minecraft:light_gray_concrete
fill 136 145 585 136 157 585 minecraft:black_concrete
setblock 94 146 574 minecraft:white_stained_glass
setblock 94 146 598 minecraft:white_stained_glass
fill 94 146 599 94 170 599 minecraft:black_concrete
setblock 97 146 560 minecraft:light[level=14]
setblock 97 146 568 minecraft:light[level=14]
setblock 97 146 576 minecraft:light[level=14]
setblock 97 146 584 minecraft:light[level=14]
setblock 97 146 592 minecraft:light[level=14]
fill 99 146 557 99 165 557 minecraft:black_concrete
setblock 105 146 560 minecraft:light[level=14]
setblock 105 146 568 minecraft:light[level=14]
setblock 105 146 576 minecraft:light[level=14]
setblock 105 146 584 minecraft:light[level=14]
setblock 105 146 592 minecraft:light[level=14]
setblock 113 146 560 minecraft:light[level=14]
setblock 113 146 568 minecraft:light[level=14]
setblock 113 146 576 minecraft:light[level=14]
setblock 113 146 584 minecraft:light[level=14]
setblock 113 146 592 minecraft:light[level=14]
setblock 119 146 557 minecraft:white_stained_glass
fill 121 146 557 121 167 557 minecraft:black_concrete
setblock 121 146 560 minecraft:light[level=14]
setblock 121 146 568 minecraft:light[level=14]
setblock 121 146 576 minecraft:light[level=14]
setblock 121 146 584 minecraft:light[level=14]
setblock 121 146 592 minecraft:light[level=14]
fill 128 146 557 128 170 557 minecraft:black_concrete
fill 128 146 570 128 147 570 minecraft:light_gray_concrete
setblock 129 146 560 minecraft:light[level=14]
setblock 129 146 568 minecraft:light[level=14]
setblock 129 146 576 minecraft:light[level=14]
setblock 129 146 584 minecraft:light[level=14]
setblock 129 146 592 minecraft:light[level=14]
fill 136 146 566 136 169 566 minecraft:black_concrete
fill 94 147 565 94 153 565 minecraft:black_concrete
fill 94 147 574 94 169 574 minecraft:black_concrete
fill 94 147 581 94 153 581 minecraft:black_concrete
setblock 94 147 591 minecraft:pearlescent_froglight
fill 94 147 597 94 153 598 minecraft:black_concrete
fill 98 147 557 98 153 557 minecraft:black_concrete
fill 108 147 599 108 153 599 minecraft:black_concrete
setblock 110 147 599 minecraft:pearlescent_froglight
fill 114 147 557 114 153 557 minecraft:black_concrete
setblock 118 147 557 minecraft:pearlescent_froglight
fill 119 147 557 119 149 557 minecraft:black_concrete
fill 124 147 599 124 153 599 minecraft:black_concrete
fill 130 147 557 130 153 557 minecraft:black_concrete
setblock 136 147 562 minecraft:white_concrete
fill 136 147 567 136 149 567 minecraft:black_concrete
setblock 136 147 576 minecraft:pearlescent_froglight
fill 136 147 583 136 153 583 minecraft:black_concrete
setblock 94 148 558 minecraft:white_concrete
setblock 94 148 589 minecraft:white_concrete
setblock 94 148 590 minecraft:white_stained_glass
fill 94 148 591 94 153 591 minecraft:black_concrete
setblock 102 148 599 minecraft:white_concrete
setblock 105 148 599 minecraft:white_stained_glass
fill 110 148 599 110 158 599 minecraft:black_concrete
fill 116 148 565 117 149 567 minecraft:light_gray_concrete
fill 118 148 557 118 154 557 minecraft:black_concrete
fill 136 148 562 136 169 562 minecraft:black_concrete
fill 136 148 576 136 165 576 minecraft:black_concrete
setblock 136 148 592 minecraft:white_stained_glass
fill 94 149 558 94 169 558 minecraft:black_concrete
fill 94 149 589 94 165 590 minecraft:black_concrete
fill 102 149 599 102 169 599 minecraft:black_concrete
fill 105 149 599 105 169 599 minecraft:black_concrete
setblock 111 149 599 minecraft:pearlescent_froglight
setblock 116 149 599 minecraft:white_concrete
setblock 117 149 557 minecraft:white_concrete
setblock 136 149 579 minecraft:white_stained_glass
setblock 136 149 591 minecraft:white_stained_glass
fill 136 149 592 136 170 592 minecraft:black_concrete
fill 94 150 582 94 169 582 minecraft:black_concrete
setblock 94 150 583 minecraft:white_concrete
fill 99 150 599 99 169 599 minecraft:black_concrete
setblock 100 150 599 minecraft:white_concrete
setblock 106 150 557 minecraft:white_stained_glass
fill 111 150 599 111 163 599 minecraft:black_concrete
fill 115 150 565 116 151 566 minecraft:end_stone
fill 116 150 599 116 171 599 minecraft:black_concrete
fill 117 150 557 117 169 557 minecraft:black_concrete
setblock 119 150 557 minecraft:white_concrete
setblock 136 150 567 minecraft:white_stained_glass
fill 136 150 579 136 169 579 minecraft:black_concrete
fill 136 150 591 136 157 591 minecraft:black_concrete
fill 94 151 583 94 167 583 minecraft:black_concrete
fill 100 151 599 100 153 599 minecraft:black_concrete
fill 106 151 557 106 169 557 minecraft:black_concrete
fill 119 151 557 119 169 557 minecraft:black_concrete
fill 136 151 567 136 153 567 minecraft:black_concrete
setblock 94 152 576 minecraft:white_stained_glass
setblock 115 152 557 minecraft:white_concrete
fill 116 152 557 116 169 557 minecraft:black_concrete
fill 94 153 576 94 169 576 minecraft:black_concrete
setblock 114 153 599 minecraft:white_concrete
fill 115 153 557 115 166 557 minecraft:black_concrete
setblock 136 153 577 minecraft:white_concrete
fill 94 154 565 94 155 565 minecraft:light_gray_concrete
fill 94 154 581 94 155 581 minecraft:light_gray_concrete
setblock 94 154 591 minecraft:white_stained_glass
fill 94 154 597 94 155 597 minecraft:light_gray_concrete
setblock 94 154 598 minecraft:pearlescent_froglight
setblock 97 154 560 minecraft:light[level=14]
setblock 97 154 568 minecraft:light[level=14]
setblock 97 154 576 minecraft:light[level=14]
setblock 97 154 584 minecraft:light[level=14]
setblock 97 154 592 minecraft:light[level=14]
fill 98 154 557 98 155 557 minecraft:light_gray_concrete
setblock 100 154 599 minecraft:white_concrete
setblock 105 154 560 minecraft:light[level=14]
setblock 105 154 568 minecraft:light[level=14]
setblock 105 154 576 minecraft:light[level=14]
setblock 105 154 584 minecraft:light[level=14]
setblock 105 154 592 minecraft:light[level=14]
fill 108 154 599 108 155 599 minecraft:light_gray_concrete
setblock 113 154 560 minecraft:light[level=14]
setblock 113 154 568 minecraft:light[level=14]
setblock 113 154 576 minecraft:light[level=14]
setblock 113 154 584 minecraft:light[level=14]
setblock 113 154 592 minecraft:light[level=14]
fill 114 154 557 114 155 557 minecraft:light_gray_concrete
fill 114 154 599 114 169 599 minecraft:black_concrete
setblock 121 154 560 minecraft:light[level=14]
setblock 121 154 568 minecraft:light[level=14]
setblock 121 154 576 minecraft:light[level=14]
setblock 121 154 584 minecraft:light[level=14]
setblock 121 154 592 minecraft:light[level=14]
fill 124 154 599 124 155 599 minecraft:light_gray_concrete
setblock 127 154 599 minecraft:pearlescent_froglight
setblock 129 154 560 minecraft:light[level=14]
setblock 129 154 568 minecraft:light[level=14]
setblock 129 154 576 minecraft:light[level=14]
setblock 129 154 584 minecraft:light[level=14]
setblock 129 154 592 minecraft:light[level=14]
fill 130 154 557 130 155 557 minecraft:light_gray_concrete
fill 136 154 567 136 155 567 minecraft:light_gray_concrete
fill 136 154 577 136 169 577 minecraft:black_concrete
fill 136 154 583 136 155 583 minecraft:light_gray_concrete
fill 94 155 591 94 169 591 minecraft:black_concrete
fill 94 155 598 94 166 598 minecraft:black_concrete
setblock 98 155 599 minecraft:pearlescent_froglight
fill 100 155 599 100 165 599 minecraft:black_concrete
setblock 118 155 557 minecraft:pearlescent_froglight
setblock 127 155 599 minecraft:black_concrete
setblock 94 156 559 minecraft:pearlescent_froglight
fill 94 156 565 94 161 565 minecraft:black_concrete
fill 94 156 581 94 161 581 minecraft:black_concrete
fill 94 156 597 94 161 597 minecraft:black_concrete
setblock 95 156 557 minecraft:pearlescent_froglight
fill 98 156 557 98 161 557 minecraft:black_concrete
fill 98 156 599 98 169 599 minecraft:black_concrete
setblock 103 156 599 minecraft:pearlescent_froglight
fill 108 156 599 108 161 599 minecraft:black_concrete
fill 114 156 557 114 161 557 minecraft:black_concrete
fill 118 156 557 118 162 557 minecraft:black_concrete
fill 124 156 599 124 161 599 minecraft:black_concrete
setblock 127 156 599 minecraft:pearlescent_froglight
setblock 129 156 557 minecraft:pearlescent_froglight
fill 130 156 557 130 161 557 minecraft:black_concrete
setblock 136 156 567 minecraft:white_stained_glass
fill 136 156 583 136 161 583 minecraft:black_concrete
fill 94 157 559 94 169 559 minecraft:black_concrete
setblock 94 157 594 minecraft:pearlescent_froglight
fill 95 157 557 95 165 557 minecraft:black_concrete
fill 103 157 599 103 169 599 minecraft:black_concrete
fill 127 157 599 127 158 599 minecraft:black_concrete
fill 129 157 557 129 166 557 minecraft:black_concrete
fill 136 157 567 136 161 567 minecraft:black_concrete
setblock 94 158 587 minecraft:white_concrete
fill 94 158 594 94 166 594 minecraft:black_concrete
setblock 123 158 599 minecraft:pearlescent_froglight
setblock 136 158 585 minecraft:white_stained_glass
setblock 136 158 591 minecraft:pearlescent_froglight
setblock 94 159 572 minecraft:white_concrete
fill 94 159 587 94 165 587 minecraft:black_concrete
setblock 107 159 599 minecraft:white_concrete
setblock 110 159 599 minecraft:white_concrete
setblock 123 159 599 minecraft:white_stained_glass
setblock 127 159 599 minecraft:white_concrete
fill 136 159 585 136 169 585 minecraft:black_concrete
fill 136 159 591 136 166 591 minecraft:black_concrete
fill 94 160 572 94 169 572 minecraft:black_concrete
fill 107 160 599 107 165 599 minecraft:black_concrete
fill 110 160 599 110 169 599 minecraft:black_concrete
fill 123 160 599 123 169 599 minecraft:black_concrete
fill 127 160 599 127 169 599 minecraft:black_concrete
setblock 136 160 578 minecraft:white_stained_glass
setblock 136 160 597 minecraft:white_concrete
setblock 94 161 596 minecraft:white_stained_glass
setblock 119 161 599 minecraft:pearlescent_froglight
fill 124 161 562 125 162 563 minecraft:light_gray_concrete
fill 125 161 591 126 162 592 minecraft:gray_concrete
fill 136 161 578 136 169 578 minecraft:black_concrete
fill 136 161 597 136 169 597 minecraft:black_concrete
fill 94 162 565 94 164 565 minecraft:light_gray_concrete
fill 94 162 581 94 164 581 minecraft:light_gray_concrete
fill 94 162 596 94 165 596 minecraft:black_concrete
fill 94 162 597 94 164 597 minecraft:light_gray_concrete
setblock 97 162 560 minecraft:light[level=14]
setblock 97 162 568 minecraft:light[level=14]
setblock 97 162 576 minecraft:light[level=14]
setblock 97 162 584 minecraft:light[level=14]
setblock 97 162 592 minecraft:light[level=14]
fill 98 162 557 98 164 557 minecraft:light_gray_concrete
setblock 105 162 560 minecraft:light[level=14]
setblock 105 162 568 minecraft:light[level=14]
setblock 105 162 576 minecraft:light[level=14]
setblock 105 162 584 minecraft:light[level=14]
setblock 105 162 592 minecraft:light[level=14]
fill 108 162 599 108 164 599 minecraft:light_gray_concrete
setblock 113 162 560 minecraft:light[level=14]
setblock 113 162 568 minecraft:light[level=14]
setblock 113 162 576 minecraft:light[level=14]
setblock 113 162 584 minecraft:light[level=14]
setblock 113 162 592 minecraft:light[level=14]
fill 114 162 557 114 164 557 minecraft:light_gray_concrete
fill 119 162 599 119 165 599 minecraft:black_concrete
setblock 121 162 560 minecraft:light[level=14]
setblock 121 162 568 minecraft:light[level=14]
setblock 121 162 576 minecraft:light[level=14]
setblock 121 162 584 minecraft:light[level=14]
setblock 121 162 592 minecraft:light[level=14]
fill 124 162 599 124 164 599 minecraft:light_gray_concrete
setblock 129 162 560 minecraft:light[level=14]
setblock 129 162 568 minecraft:light[level=14]
setblock 129 162 576 minecraft:light[level=14]
setblock 129 162 584 minecraft:light[level=14]
setblock 129 162 592 minecraft:light[level=14]
fill 130 162 557 130 164 557 minecraft:light_gray_concrete
fill 136 162 567 136 164 567 minecraft:light_gray_concrete
fill 136 162 583 136 164 583 minecraft:light_gray_concrete
setblock 136 162 586 minecraft:white_stained_glass
fill 136 162 587 136 169 587 minecraft:black_concrete
setblock 94 163 580 minecraft:white_concrete
setblock 107 163 557 minecraft:white_concrete
setblock 118 163 557 minecraft:white_stained_glass
setblock 126 163 557 minecraft:white_concrete
fill 136 163 586 136 169 586 minecraft:black_concrete
setblock 136 163 594 minecraft:pearlescent_froglight
fill 94 164 580 94 167 580 minecraft:black_concrete
fill 107 164 557 107 169 557 minecraft:black_concrete
fill 108 164 569 108 165 569 minecraft:white_stained_glass
setblock 111 164 599 minecraft:white_stained_glass
fill 118 164 557 118 169 557 minecraft:black_concrete
fill 126 164 557 126 169 557 minecraft:black_concrete
setblock 136 164 573 minecraft:white_stained_glass
fill 136 164 594 136 170 594 minecraft:black_concrete
fill 94 165 565 94 166 565 minecraft:black_concrete
setblock 94 165 573 minecraft:white_stained_glass
setblock 94 165 577 minecraft:white_stained_glass
fill 94 165 581 94 167 581 minecraft:black_concrete
setblock 94 165 595 minecraft:pearlescent_froglight
fill 94 165 597 94 169 597 minecraft:black_concrete
setblock 97 165 557 minecraft:white_concrete
fill 98 165 557 98 167 557 minecraft:black_concrete
fill 108 165 599 108 169 599 minecraft:black_concrete
fill 111 165 599 111 169 599 minecraft:black_concrete
fill 114 165 557 114 168 557 minecraft:black_concrete
setblock 124 165 557 minecraft:white_stained_glass
setblock 124 165 599 minecraft:pearlescent_froglight
fill 130 165 557 130 169 557 minecraft:black_concrete
fill 136 165 567 136 169 567 minecraft:black_concrete
fill 136 165 570 136 169 570 minecraft:black_concrete
setblock 136 165 571 minecraft:white_stained_glass
fill 136 165 573 136 169 573 minecraft:black_concrete
fill 136 165 583 136 169 583 minecraft:black_concrete
fill 94 166 573 94 169 573 minecraft:black_concrete
fill 94 166 577 94 169 577 minecraft:black_concrete
setblock 94 166 587 minecraft:blue_concrete
setblock 94 166 589 minecraft:blue_concrete
fill 94 166 590 94 169 590 minecraft:black_concrete
fill 94 166 595 94 167 595 minecraft:black_concrete
setblock 94 166 596 minecraft:blue_concrete
setblock 95 166 557 minecraft:blue_concrete
setblock 97 166 557 minecraft:black_concrete
setblock 99 166 557 minecraft:blue_concrete
setblock 100 166 599 minecraft:pearlescent_froglight
setblock 102 166 557 minecraft:blue_concrete
fill 106 166 599 107 166 599 minecraft:blue_concrete
fill 108 166 569 108 176 569 minecraft:gray_concrete
setblock 109 166 599 minecraft:blue_concrete
fill 112 166 557 112 167 557 minecraft:blue_concrete
setblock 113 166 599 minecraft:blue_concrete
setblock 115 166 599 minecraft:blue_concrete
setblock 119 166 599 minecraft:blue_concrete
setblock 122 166 557 minecraft:blue_concrete
fill 124 166 557 124 169 557 minecraft:black_concrete
fill 124 166 599 124 169 599 minecraft:black_concrete
setblock 135 166 557 minecraft:blue_concrete
setblock 136 166 559 minecraft:black_concrete
setblock 136 166 560 minecraft:blue_concrete
setblock 136 166 563 minecraft:white_stained_glass
fill 136 166 571 136 167 571 minecraft:black_concrete
setblock 136 166 576 minecraft:blue_concrete
setblock 136 166 580 minecraft:blue_concrete
setblock 136 166 599 minecraft:blue_concrete
setblock 94 167 565 minecraft:blue_concrete
setblock 94 167 569 minecraft:blue_concrete
fill 94 167 570 94 170 570 minecraft:black_concrete
setblock 94 167 575 minecraft:pearlescent_froglight
fill 94 167 578 94 169 578 minecraft:black_concrete
setblock 94 167 579 minecraft:blue_concrete
fill 94 167 587 94 169 587 minecraft:black_concrete
fill 94 167 589 94 169 589 minecraft:black_concrete
fill 94 167 592 94 168 592 minecraft:blue_concrete
setblock 94 167 594 minecraft:pearlescent_froglight
fill 94 167 596 94 169 596 minecraft:black_concrete
fill 94 167 598 94 168 598 minecraft:blue_concrete
setblock 95 167 557 minecraft:black_concrete
fill 95 167 599 96 167 599 minecraft:blue_concrete
fill 97 167 557 97 168 557 minecraft:blue_concrete
setblock 99 167 557 minecraft:black_concrete
fill 100 167 599 100 169 599 minecraft:black_concrete
fill 102 167 557 102 169 557 minecraft:black_concrete
setblock 105 167 557 minecraft:blue_concrete
fill 106 167 599 107 169 599 minecraft:black_concrete
fill 109 167 599 109 169 599 minecraft:black_concrete
fill 113 167 599 113 169 599 minecraft:black_concrete
fill 115 167 557 115 168 557 minecraft:blue_concrete
fill 115 167 599 115 169 599 minecraft:black_concrete
fill 119 167 599 119 169 599 minecraft:black_concrete
fill 122 167 557 122 169 557 minecraft:black_concrete
setblock 129 167 557 minecraft:blue_concrete
fill 132 167 557 133 169 557 minecraft:black_concrete
setblock 132 167 599 minecraft:white_stained_glass
setblock 133 167 599 minecraft:blue_concrete
setblock 134 167 557 minecraft:white_concrete
fill 135 167 557 135 170 557 minecraft:black_concrete
fill 136 167 558 136 167 559 minecraft:blue_concrete
fill 136 167 560 136 169 560 minecraft:black_concrete
fill 136 167 563 136 170 563 minecraft:black_concrete
setblock 136 167 572 minecraft:blue_concrete
setblock 136 167 574 minecraft:white_concrete
fill 136 167 576 136 169 576 minecraft:black_concrete
fill 136 167 580 136 169 580 minecraft:black_concrete
setblock 136 167 591 minecraft:blue_concrete
setblock 136 167 593 minecraft:blue_concrete
fill 136 167 599 136 169 599 minecraft:black_concrete
setblock 94 168 561 minecraft:blue_concrete
setblock 94 168 564 minecraft:blue_concrete
fill 94 168 565 94 169 565 minecraft:black_concrete
fill 94 168 569 94 169 569 minecraft:black_concrete
fill 94 168 575 94 169 575 minecraft:black_concrete
fill 94 168 579 94 169 579 minecraft:black_concrete
fill 94 168 580 94 168 581 minecraft:blue_concrete
setblock 94 168 583 minecraft:blue_concrete
fill 94 168 594 94 170 594 minecraft:black_concrete
setblock 94 168 595 minecraft:blue_concrete
setblock 95 168 557 minecraft:blue_concrete
fill 95 168 599 96 169 599 minecraft:black_concrete
setblock 98 168 557 minecraft:white_concrete
setblock 99 168 557 minecraft:blue_concrete
fill 105 168 557 105 169 557 minecraft:black_concrete
fill 108 168 568 109 176 568 minecraft:gray_concrete
fill 109 168 569 109 176 569 minecraft:gray_concrete
fill 112 168 557 112 170 557 minecraft:black_concrete
setblock 112 168 599 minecraft:blue_concrete
fill 117 168 595 119 169 595 minecraft:gray_concrete
fill 118 168 596 119 169 596 minecraft:gray_concrete
setblock 121 168 557 minecraft:blue_concrete
fill 129 168 557 129 169 557 minecraft:black_concrete
fill 130 168 568 131 169 569 minecraft:light_gray_concrete
fill 132 168 599 133 169 599 minecraft:black_concrete
fill 134 168 557 134 169 557 minecraft:black_concrete
setblock 134 168 599 minecraft:blue_concrete
fill 136 168 558 136 169 559 minecraft:black_concrete
setblock 136 168 571 minecraft:pearlescent_froglight
fill 136 168 572 136 169 572 minecraft:black_concrete
fill 136 168 574 136 169 574 minecraft:black_concrete
fill 136 168 591 136 169 591 minecraft:black_concrete
fill 136 168 593 136 169 593 minecraft:black_concrete
setblock 94 169 561 minecraft:black_concrete
setblock 94 169 564 minecraft:black_concrete
fill 94 169 580 94 169 581 minecraft:black_concrete
fill 94 169 583 94 170 583 minecraft:black_concrete
fill 94 169 592 94 170 592 minecraft:black_concrete
fill 94 169 595 94 170 595 minecraft:black_concrete
setblock 94 169 598 minecraft:black_concrete
setblock 95 169 557 minecraft:black_concrete
fill 97 169 557 99 169 557 minecraft:black_concrete
fill 107 169 568 107 176 569 minecraft:gray_concrete
fill 108 169 570 109 176 570 minecraft:gray_concrete
setblock 112 169 599 minecraft:black_concrete
setblock 114 169 557 minecraft:pearlescent_froglight
setblock 115 169 557 minecraft:black_concrete
setblock 121 169 557 minecraft:black_concrete
setblock 134 169 599 minecraft:white_concrete
setblock 136 169 571 minecraft:black_concrete
fill 94 170 557 94 170 569 minecraft:blue_concrete
fill 94 170 572 94 170 582 minecraft:blue_concrete
fill 94 170 584 94 204 584 minecraft:blue_concrete
fill 94 170 586 94 170 591 minecraft:blue_concrete
fill 94 170 593 94 203 593 minecraft:blue_concrete
fill 94 170 596 94 170 598 minecraft:blue_concrete
fill 95 170 557 99 170 557 minecraft:blue_concrete
fill 95 170 599 115 170 599 minecraft:blue_concrete
setblock 97 170 560 minecraft:light[level=14]
setblock 97 170 568 minecraft:light[level=14]
setblock 97 170 576 minecraft:light[level=14]
setblock 97 170 584 minecraft:light[level=14]
setblock 97 170 592 minecraft:light[level=14]
setblock 101 170 557 minecraft:white_concrete
fill 102 170 557 111 170 557 minecraft:blue_concrete
setblock 105 170 560 minecraft:light[level=14]
setblock 105 170 568 minecraft:light[level=14]
setblock 105 170 576 minecraft:light[level=14]
setblock 105 170 584 minecraft:light[level=14]
setblock 105 170 592 minecraft:light[level=14]
fill 107 170 570 107 176 570 minecraft:gray_concrete
fill 108 170 567 109 176 567 minecraft:gray_concrete
fill 110 170 568 110 176 570 minecraft:gray_concrete
fill 113 170 557 113 228 557 minecraft:blue_concrete
setblock 113 170 560 minecraft:light[level=14]
setblock 113 170 568 minecraft:light[level=14]
setblock 113 170 576 minecraft:light[level=14]
setblock 113 170 584 minecraft:light[level=14]
setblock 113 170 592 minecraft:light[level=14]
setblock 114 170 557 minecraft:black_concrete
fill 115 170 557 127 170 557 minecraft:blue_concrete
fill 117 170 599 117 212 599 minecraft:blue_concrete
fill 119 170 599 120 184 599 minecraft:blue_concrete
setblock 121 170 560 minecraft:light[level=14]
setblock 121 170 568 minecraft:light[level=14]
setblock 121 170 576 minecraft:light[level=14]
setblock 121 170 584 minecraft:light[level=14]
setblock 121 170 592 minecraft:light[level=14]
setblock 121 170 599 minecraft:black_concrete
fill 122 170 599 125 170 599 minecraft:blue_concrete
fill 125 170 563 125 171 563 minecraft:gray_concrete
fill 127 170 599 130 191 599 minecraft:blue_concrete
fill 129 170 557 134 170 557 minecraft:blue_concrete
setblock 129 170 560 minecraft:light[level=14]
setblock 129 170 568 minecraft:light[level=14]
setblock 129 170 576 minecraft:light[level=14]
setblock 129 170 584 minecraft:light[level=14]
setblock 129 170 592 minecraft:light[level=14]
fill 132 170 599 136 187 599 minecraft:blue_concrete
fill 136 170 557 136 184 562 minecraft:blue_concrete
fill 136 170 564 136 170 591 minecraft:blue_concrete
fill 136 170 593 136 171 593 minecraft:blue_concrete
fill 136 170 596 136 170 598 minecraft:blue_concrete
setblock 94 171 557 minecraft:black_concrete
fill 94 171 558 94 186 564 minecraft:blue_concrete
fill 94 171 565 94 173 565 minecraft:light_gray_concrete
fill 94 171 566 94 184 568 minecraft:blue_concrete
setblock 94 171 569 minecraft:black_concrete
fill 94 171 570 94 171 580 minecraft:blue_concrete
fill 94 171 581 94 173 581 minecraft:light_gray_concrete
fill 94 171 582 94 171 583 minecraft:blue_concrete
fill 94 171 585 94 171 589 minecraft:blue_concrete
setblock 94 171 590 minecraft:black_concrete
fill 94 171 591 94 228 592 minecraft:blue_concrete
setblock 94 171 594 minecraft:pearlescent_froglight
fill 94 171 595 94 193 596 minecraft:blue_concrete
fill 94 171 597 94 173 597 minecraft:light_gray_concrete
fill 94 171 598 94 171 599 minecraft:blue_concrete
fill 95 171 557 95 214 557 minecraft:blue_concrete
fill 95 171 599 95 188 599 minecraft:blue_concrete
setblock 96 171 557 minecraft:black_concrete
setblock 96 171 599 minecraft:black_concrete
fill 97 171 557 97 229 557 minecraft:blue_concrete
fill 97 171 599 97 203 599 minecraft:blue_concrete
fill 98 171 557 98 173 557 minecraft:light_gray_concrete
setblock 98 171 599 minecraft:black_concrete
fill 99 171 557 102 187 557 minecraft:blue_concrete
fill 99 171 599 107 171 599 minecraft:blue_concrete
setblock 103 171 557 minecraft:black_concrete
fill 104 171 557 107 180 557 minecraft:blue_concrete
fill 106 171 568 106 176 570 minecraft:gray_concrete
fill 107 171 567 107 176 567 minecraft:gray_concrete
fill 107 171 571 109 176 571 minecraft:gray_concrete
setblock 108 171 557 minecraft:black_concrete
fill 108 171 599 108 173 599 minecraft:light_gray_concrete
fill 109 171 557 112 184 557 minecraft:blue_concrete
fill 109 171 599 110 171 599 minecraft:blue_concrete
fill 110 171 567 110 176 567 minecraft:gray_concrete
setblock 111 171 599 minecraft:black_concrete
fill 112 171 599 112 172 599 minecraft:blue_concrete
setblock 113 171 599 minecraft:black_concrete
fill 114 171 557 114 173 557 minecraft:light_gray_concrete
fill 114 171 599 115 234 599 minecraft:blue_concrete
fill 115 171 557 119 171 557 minecraft:blue_concrete
fill 118 171 599 118 193 599 minecraft:blue_concrete
setblock 120 171 557 minecraft:black_concrete
fill 121 171 557 129 171 557 minecraft:blue_concrete
fill 121 171 599 123 179 599 minecraft:blue_concrete
fill 124 171 599 124 173 599 minecraft:light_gray_concrete
setblock 125 171 599 minecraft:black_concrete
fill 126 171 599 126 238 599 minecraft:blue_concrete
fill 130 171 557 130 173 557 minecraft:light_gray_concrete
setblock 131 171 557 minecraft:black_concrete
fill 131 171 599 131 238 599 minecraft:blue_concrete
fill 132 171 557 135 183 557 minecraft:blue_concrete
fill 136 171 563 136 171 566 minecraft:blue_concrete
fill 136 171 567 136 173 567 minecraft:light_gray_concrete
fill 136 171 568 136 172 569 minecraft:blue_concrete
setblock 136 171 570 minecraft:white_concrete
fill 136 171 571 136 238 571 minecraft:blue_concrete
setblock 136 171 572 minecraft:black_concrete
fill 136 171 573 136 171 582 minecraft:blue_concrete
fill 136 171 583 136 173 583 minecraft:light_gray_concrete
fill 136 171 584 136 208 585 minecraft:blue_concrete
setblock 136 171 586 minecraft:black_concrete
fill 136 171 587 136 171 592 minecraft:blue_concrete
fill 136 171 594 136 171 597 minecraft:blue_concrete
setblock 136 171 598 minecraft:black_concrete
fill 94 172 557 94 234 557 minecraft:blue_concrete
fill 94 172 569 94 234 569 minecraft:blue_concrete
setblock 94 172 570 minecraft:black_concrete
fill 94 172 571 94 199 575 minecraft:blue_concrete
setblock 94 172 576 minecraft:black_concrete
fill 94 172 577 94 197 580 minecraft:blue_concrete
fill 94 172 582 94 223 582 minecraft:blue_concrete
setblock 94 172 583 minecraft:black_concrete
fill 94 172 585 94 175 586 minecraft:blue_concrete
setblock 94 172 587 minecraft:black_concrete
fill 94 172 588 94 176 590 minecraft:blue_concrete
fill 94 172 594 94 174 594 minecraft:blue_concrete
fill 94 172 598 94 172 599 minecraft:black_concrete
fill 96 172 557 96 237 557 minecraft:blue_concrete
fill 96 172 599 96 234 599 minecraft:blue_concrete
fill 98 172 599 98 183 599 minecraft:blue_concrete
setblock 99 172 599 minecraft:black_concrete
fill 100 172 599 102 212 599 minecraft:blue_concrete
fill 103 172 557 103 186 557 minecraft:blue_concrete
setblock 103 172 599 minecraft:black_concrete
fill 104 172 599 107 189 599 minecraft:blue_concrete
fill 106 172 567 106 176 567 minecraft:gray_concrete
fill 107 172 566 109 176 566 minecraft:gray_concrete
fill 108 172 557 108 179 557 minecraft:blue_concrete
setblock 109 172 599 minecraft:black_concrete
fill 110 172 571 110 176 571 minecraft:gray_concrete
fill 110 172 599 111 191 599 minecraft:blue_concrete
fill 111 172 568 111 176 570 minecraft:gray_concrete
fill 113 172 599 113 238 599 minecraft:blue_concrete
fill 115 172 557 115 180 557 minecraft:blue_concrete
setblock 116 172 557 minecraft:pearlescent_froglight
fill 116 172 599 116 190 599 minecraft:blue_concrete
fill 117 172 557 117 182 557 minecraft:blue_concrete
setblock 118 172 557 minecraft:black_concrete
fill 119 172 557 122 182 557 minecraft:blue_concrete
fill 123 172 557 124 172 557 minecraft:black_concrete
fill 125 172 557 127 213 557 minecraft:blue_concrete
fill 125 172 599 125 195 599 minecraft:blue_concrete
setblock 128 172 557 minecraft:black_concrete
setblock 129 172 557 minecraft:blue_concrete
fill 131 172 557 131 238 557 minecraft:blue_concrete
fill 136 172 563 136 173 563 minecraft:blue_concrete
setblock 136 172 564 minecraft:pearlescent_froglight
fill 136 172 565 136 172 566 minecraft:blue_concrete
setblock 136 172 570 minecraft:black_concrete
fill 136 172 572 136 174 579 minecraft:blue_concrete
setblock 136 172 580 minecraft:black_concrete
fill 136 172 581 136 223 582 minecraft:blue_concrete
fill 136 172 586 136 183 591 minecraft:blue_concrete
fill 136 172 592 136 172 594 minecraft:black_concrete
fill 136 172 595 136 179 598 minecraft:blue_concrete
fill 94 173 570 94 197 570 minecraft:blue_concrete
fill 94 173 576 94 176 576 minecraft:blue_concrete
fill 94 173 583 94 238 583 minecraft:blue_concrete
fill 94 173 587 94 176 587 minecraft:blue_concrete
fill 94 173 598 94 236 599 minecraft:blue_concrete
fill 99 173 599 99 180 599 minecraft:blue_concrete
fill 103 173 599 103 234 599 minecraft:blue_concrete
fill 105 173 568 105 176 570 minecraft:gray_concrete
fill 106 173 571 106 176 571 minecraft:gray_concrete
fill 107 173 572 110 176 572 minecraft:gray_concrete
fill 109 173 599 109 238 599 minecraft:blue_concrete
fill 110 173 566 110 176 566 minecraft:gray_concrete
fill 111 173 567 111 176 567 minecraft:gray_concrete
fill 111 173 571 111 176 571 minecraft:gray_concrete
setblock 112 173 599 minecraft:white_concrete
fill 116 173 557 116 177 557 minecraft:blue_concrete
fill 118 173 557 118 238 557 minecraft:blue_concrete
fill 123 173 557 124 173 557 minecraft:blue_concrete
fill 128 173 557 128 195 557 minecraft:blue_concrete
setblock 129 173 557 minecraft:white_concrete
fill 136 173 564 136 187 564 minecraft:blue_concrete
setblock 136 173 565 minecraft:pearlescent_froglight
fill 136 173 566 136 234 566 minecraft:blue_concrete
fill 136 173 568 136 238 568 minecraft:blue_concrete
setblock 136 173 569 minecraft:pearlescent_froglight
fill 136 173 570 136 185 570 minecraft:blue_concrete
fill 136 173 580 136 220 580 minecraft:blue_concrete
fill 136 173 592 136 174 594 minecraft:blue_concrete
fill 94 174 565 94 179 565 minecraft:blue_concrete
fill 94 174 581 94 179 581 minecraft:blue_concrete
fill 94 174 597 94 179 597 minecraft:blue_concrete
fill 98 174 557 98 179 557 minecraft:blue_concrete
fill 105 174 567 105 176 567 minecraft:gray_concrete
fill 105 174 571 105 176 571 minecraft:gray_concrete
fill 106 174 566 106 176 566 minecraft:gray_concrete
fill 106 174 572 106 176 572 minecraft:gray_concrete
fill 107 174 565 109 176 565 minecraft:gray_concrete
fill 108 174 599 108 179 599 minecraft:blue_concrete
fill 110 174 589 110 175 589 minecraft:gray_concrete
fill 111 174 566 111 176 566 minecraft:gray_concrete
fill 112 174 568 112 176 570 minecraft:gray_concrete
fill 112 174 599 112 209 599 minecraft:blue_concrete
fill 114 174 557 114 179 557 minecraft:blue_concrete
setblock 123 174 557 minecraft:white_concrete
fill 124 174 557 124 239 557 minecraft:blue_concrete
fill 124 174 599 124 177 599 minecraft:blue_concrete
fill 129 174 557 130 179 557 minecraft:blue_concrete
setblock 136 174 563 minecraft:white_concrete
fill 136 174 565 136 178 565 minecraft:blue_concrete
fill 136 174 567 136 179 567 minecraft:blue_concrete
fill 136 174 569 136 238 569 minecraft:blue_concrete
fill 136 174 583 136 179 583 minecraft:blue_concrete
setblock 94 175 594 minecraft:pearlescent_froglight
fill 104 175 568 104 176 570 minecraft:gray_concrete
fill 105 175 566 105 176 566 minecraft:gray_concrete
fill 105 175 572 105 176 572 minecraft:gray_concrete
fill 106 175 565 106 176 565 minecraft:gray_concrete
fill 107 175 573 110 176 573 minecraft:gray_concrete
fill 110 175 565 110 176 565 minecraft:gray_concrete
fill 111 175 572 111 176 572 minecraft:gray_concrete
fill 112 175 567 112 176 567 minecraft:gray_concrete
fill 112 175 571 112 176 571 minecraft:gray_concrete
fill 123 175 557 123 234 557 minecraft:blue_concrete
fill 136 175 563 136 208 563 minecraft:blue_concrete
fill 136 175 572 136 182 576 minecraft:blue_concrete
setblock 136 175 577 minecraft:white_concrete
fill 136 175 578 136 192 579 minecraft:blue_concrete
setblock 136 175 592 minecraft:white_concrete
fill 136 175 593 136 184 594 minecraft:blue_concrete
setblock 94 176 585 minecraft:pearlescent_froglight
fill 94 176 586 94 188 586 minecraft:blue_concrete
fill 94 176 594 94 234 594 minecraft:blue_concrete
setblock 104 176 567 minecraft:gray_concrete
setblock 104 176 571 minecraft:gray_concrete
setblock 105 176 565 minecraft:gray_concrete
setblock 106 176 573 minecraft:gray_concrete
fill 107 176 564 109 176 564 minecraft:gray_concrete
setblock 111 176 565 minecraft:gray_concrete
setblock 111 176 573 minecraft:gray_concrete
setblock 112 176 566 minecraft:gray_concrete
setblock 112 176 572 minecraft:gray_concrete
fill 113 176 567 113 176 570 minecraft:gray_concrete
fill 136 176 577 136 209 577 minecraft:blue_concrete
fill 136 176 592 136 180 592 minecraft:blue_concrete
setblock 94 177 576 minecraft:white_concrete
fill 94 177 585 94 238 585 minecraft:blue_concrete
setblock 94 177 587 minecraft:white_stained_glass
fill 94 177 588 94 238 588 minecraft:blue_concrete
setblock 94 177 589 minecraft:white_stained_glass
fill 94 177 590 94 185 590 minecraft:blue_concrete
fill 107 177 568 107 179 568 minecraft:end_stone
fill 108 177 570 108 180 570 minecraft:end_stone
fill 110 177 569 110 178 569 minecraft:end_stone
fill 112 177 567 112 178 567 minecraft:light_gray_concrete
fill 94 178 576 94 238 576 minecraft:blue_concrete
fill 94 178 587 94 190 587 minecraft:blue_concrete
fill 94 178 589 94 234 589 minecraft:blue_concrete
setblock 97 178 560 minecraft:light[level=14]
setblock 97 178 568 minecraft:light[level=14]
setblock 97 178 576 minecraft:light[level=14]
setblock 97 178 584 minecraft:light[level=14]
setblock 97 178 592 minecraft:light[level=14]
setblock 105 178 560 minecraft:light[level=14]
setblock 105 178 568 minecraft:light[level=14]
setblock 105 178 576 minecraft:light[level=14]
setblock 105 178 584 minecraft:light[level=14]
setblock 105 178 592 minecraft:light[level=14]
setblock 113 178 560 minecraft:light[level=14]
setblock 113 178 568 minecraft:light[level=14]
setblock 113 178 576 minecraft:light[level=14]
setblock 113 178 584 minecraft:light[level=14]
setblock 113 178 592 minecraft:light[level=14]
setblock 116 178 557 minecraft:white_concrete
setblock 121 178 560 minecraft:light[level=14]
setblock 121 178 568 minecraft:light[level=14]
setblock 121 178 576 minecraft:light[level=14]
setblock 121 178 584 minecraft:light[level=14]
setblock 121 178 592 minecraft:light[level=14]
fill 124 178 589 124 179 589 minecraft:light_gray_concrete
setblock 124 178 599 minecraft:white_concrete
setblock 129 178 560 minecraft:light[level=14]
setblock 129 178 568 minecraft:light[level=14]
setblock 129 178 576 minecraft:light[level=14]
setblock 129 178 584 minecraft:light[level=14]
setblock 129 178 592 minecraft:light[level=14]
fill 116 179 557 116 227 557 minecraft:blue_concrete
setblock 124 179 599 minecraft:blue_concrete
setblock 136 179 565 minecraft:white_concrete
setblock 94 180 565 minecraft:light_gray_concrete
setblock 94 180 581 minecraft:light_gray_concrete
setblock 94 180 597 minecraft:light_gray_concrete
setblock 98 180 557 minecraft:light_gray_concrete
setblock 108 180 557 minecraft:pearlescent_froglight
setblock 108 180 599 minecraft:light_gray_concrete
fill 113 180 578 113 180 580 minecraft:pearlescent_froglight
setblock 114 180 557 minecraft:light_gray_concrete
fill 114 180 577 114 180 579 minecraft:pearlescent_froglight
setblock 114 180 581 minecraft:pearlescent_froglight
fill 115 180 577 116 180 578 minecraft:pearlescent_froglight
fill 116 180 579 117 180 579 minecraft:pearlescent_froglight
setblock 117 180 578 minecraft:pearlescent_froglight
setblock 117 180 580 minecraft:pearlescent_froglight
setblock 121 180 599 minecraft:pearlescent_froglight
fill 122 180 599 123 200 599 minecraft:blue_concrete
setblock 124 180 599 minecraft:light_gray_concrete
fill 129 180 557 129 183 557 minecraft:blue_concrete
setblock 130 180 557 minecraft:light_gray_concrete
fill 136 180 565 136 198 565 minecraft:blue_concrete
setblock 136 180 567 minecraft:light_gray_concrete
setblock 136 180 583 minecraft:light_gray_concrete
fill 136 180 595 136 184 597 minecraft:blue_concrete
setblock 136 180 598 minecraft:white_concrete
fill 94 181 565 94 190 565 minecraft:blue_concrete
fill 94 181 581 94 188 581 minecraft:blue_concrete
fill 94 181 597 94 190 597 minecraft:blue_concrete
fill 98 181 557 98 182 557 minecraft:blue_concrete
setblock 99 181 599 minecraft:pearlescent_froglight
fill 104 181 557 105 205 557 minecraft:blue_concrete
setblock 106 181 557 minecraft:pearlescent_froglight
fill 107 181 557 108 215 557 minecraft:blue_concrete
fill 108 181 599 108 188 599 minecraft:blue_concrete
fill 111 181 578 112 181 580 minecraft:pearlescent_froglight
fill 112 181 576 113 181 577 minecraft:pearlescent_froglight
fill 112 181 581 113 181 582 minecraft:pearlescent_froglight
fill 113 181 578 113 186 580 minecraft:light_gray_concrete
fill 114 181 557 114 190 557 minecraft:blue_concrete
fill 114 181 575 116 181 576 minecraft:pearlescent_froglight
fill 114 181 577 114 184 579 minecraft:light_gray_concrete
fill 114 181 581 114 184 581 minecraft:light_gray_concrete
fill 114 181 582 116 181 583 minecraft:pearlescent_froglight
setblock 115 181 557 minecraft:white_stained_glass
fill 115 181 577 116 186 578 minecraft:light_gray_concrete
fill 116 181 579 117 184 579 minecraft:light_gray_concrete
fill 117 181 576 118 181 577 minecraft:pearlescent_froglight
fill 117 181 578 117 186 578 minecraft:light_gray_concrete
fill 117 181 580 117 186 580 minecraft:light_gray_concrete
fill 117 181 581 118 181 582 minecraft:pearlescent_froglight
fill 118 181 578 119 181 580 minecraft:pearlescent_froglight
fill 121 181 599 121 238 599 minecraft:blue_concrete
fill 124 181 599 124 190 599 minecraft:blue_concrete
fill 130 181 557 130 190 557 minecraft:blue_concrete
fill 136 181 567 136 189 567 minecraft:blue_concrete
fill 136 181 583 136 190 583 minecraft:blue_concrete
setblock 136 181 592 minecraft:white_concrete
fill 136 181 598 136 183 598 minecraft:blue_concrete
fill 99 182 599 99 236 599 minecraft:blue_concrete
fill 106 182 557 106 207 557 minecraft:blue_concrete
fill 110 182 578 110 182 580 minecraft:pearlescent_froglight
fill 111 182 576 111 182 577 minecraft:pearlescent_froglight
fill 111 182 578 112 186 580 minecraft:light_gray_concrete
fill 111 182 581 111 182 582 minecraft:pearlescent_froglight
fill 112 182 575 113 182 575 minecraft:pearlescent_froglight
fill 112 182 576 113 184 577 minecraft:light_gray_concrete
fill 112 182 581 113 186 582 minecraft:light_gray_concrete
fill 112 182 583 113 182 583 minecraft:pearlescent_froglight
fill 114 182 574 116 182 574 minecraft:pearlescent_froglight
fill 114 182 575 116 186 576 minecraft:light_gray_concrete
fill 114 182 582 116 186 583 minecraft:light_gray_concrete
fill 114 182 584 116 182 584 minecraft:pearlescent_froglight
fill 115 182 557 115 209 557 minecraft:blue_concrete
fill 117 182 575 118 182 575 minecraft:pearlescent_froglight
fill 117 182 576 118 191 577 minecraft:light_gray_concrete
fill 117 182 581 118 186 582 minecraft:light_gray_concrete
fill 117 182 583 118 182 583 minecraft:pearlescent_froglight
fill 118 182 578 119 187 580 minecraft:light_gray_concrete
fill 119 182 576 119 182 577 minecraft:pearlescent_froglight
fill 119 182 581 119 182 582 minecraft:pearlescent_froglight
fill 120 182 578 120 182 580 minecraft:pearlescent_froglight
fill 136 182 592 136 227 592 minecraft:blue_concrete
setblock 98 183 557 minecraft:white_stained_glass
fill 109 183 579 109 187 579 minecraft:pearlescent_froglight
fill 110 183 576 110 183 578 minecraft:pearlescent_froglight
fill 110 183 579 110 187 579 minecraft:light_gray_concrete
fill 110 183 580 110 183 582 minecraft:pearlescent_froglight
setblock 111 183 575 minecraft:pearlescent_froglight
fill 111 183 576 111 184 577 minecraft:light_gray_concrete
fill 111 183 581 111 186 582 minecraft:light_gray_concrete
setblock 111 183 583 minecraft:pearlescent_froglight
fill 112 183 574 114 183 574 minecraft:pearlescent_froglight
fill 112 183 575 113 184 575 minecraft:light_gray_concrete
fill 112 183 583 113 184 583 minecraft:light_gray_concrete
fill 112 183 584 114 183 584 minecraft:pearlescent_froglight
fill 115 183 573 115 190 573 minecraft:pearlescent_froglight
fill 115 183 574 115 190 574 minecraft:light_gray_concrete
fill 115 183 584 115 190 584 minecraft:light_gray_concrete
fill 115 183 585 115 190 585 minecraft:pearlescent_froglight
fill 116 183 574 118 183 574 minecraft:pearlescent_froglight
fill 116 183 584 118 183 584 minecraft:pearlescent_froglight
setblock 117 183 557 minecraft:white_concrete
fill 117 183 575 118 190 575 minecraft:light_gray_concrete
fill 117 183 583 118 184 583 minecraft:light_gray_concrete
fill 119 183 557 120 238 557 minecraft:blue_concrete
setblock 119 183 575 minecraft:pearlescent_froglight
fill 119 183 576 119 187 577 minecraft:light_gray_concrete
fill 119 183 581 119 186 582 minecraft:light_gray_concrete
setblock 119 183 583 minecraft:pearlescent_froglight
fill 120 183 576 120 183 578 minecraft:pearlescent_froglight
fill 120 183 579 120 187 579 minecraft:light_gray_concrete
fill 120 183 580 120 183 582 minecraft:pearlescent_froglight
setblock 121 183 557 minecraft:white_stained_glass
fill 121 183 579 121 187 579 minecraft:pearlescent_froglight
fill 122 183 557 122 235 557 minecraft:blue_concrete
fill 136 183 572 136 186 573 minecraft:blue_concrete
setblock 136 183 574 minecraft:white_stained_glass
fill 136 183 575 136 219 576 minecraft:blue_concrete
fill 98 184 557 98 190 557 minecraft:blue_concrete
setblock 98 184 599 minecraft:white_concrete
fill 109 184 577 109 187 578 minecraft:pearlescent_froglight
fill 109 184 580 109 187 581 minecraft:pearlescent_froglight
fill 110 184 575 110 184 576 minecraft:pearlescent_froglight
fill 110 184 577 110 186 578 minecraft:light_gray_concrete
fill 110 184 580 110 187 581 minecraft:light_gray_concrete
fill 110 184 582 110 184 583 minecraft:pearlescent_froglight
fill 111 184 574 112 184 574 minecraft:pearlescent_froglight
setblock 111 184 575 minecraft:light_gray_concrete
setblock 111 184 583 minecraft:light_gray_concrete
fill 111 184 584 112 184 584 minecraft:pearlescent_froglight
fill 113 184 573 114 189 573 minecraft:pearlescent_froglight
fill 113 184 574 114 186 574 minecraft:light_gray_concrete
fill 113 184 584 114 184 584 minecraft:light_gray_concrete
fill 113 184 585 114 184 585 minecraft:pearlescent_froglight
fill 116 184 573 117 189 573 minecraft:pearlescent_froglight
fill 116 184 574 117 189 574 minecraft:light_gray_concrete
fill 116 184 584 117 184 584 minecraft:light_gray_concrete
fill 116 184 585 117 184 585 minecraft:pearlescent_froglight
fill 117 184 557 117 193 557 minecraft:blue_concrete
fill 118 184 574 119 184 574 minecraft:pearlescent_froglight
fill 118 184 584 119 184 584 minecraft:pearlescent_froglight
fill 119 184 575 119 187 575 minecraft:light_gray_concrete
setblock 119 184 583 minecraft:light_gray_concrete
fill 120 184 575 120 184 576 minecraft:pearlescent_froglight
fill 120 184 577 120 187 578 minecraft:light_gray_concrete
fill 120 184 580 120 187 581 minecraft:light_gray_concrete
fill 120 184 582 120 184 583 minecraft:pearlescent_froglight
fill 121 184 557 121 236 557 minecraft:blue_concrete
fill 121 184 577 121 187 578 minecraft:pearlescent_froglight
fill 121 184 580 121 187 581 minecraft:pearlescent_froglight
setblock 129 184 557 minecraft:pearlescent_froglight
setblock 132 184 557 minecraft:pearlescent_froglight
fill 133 184 557 135 208 557 minecraft:blue_concrete
fill 136 184 574 136 204 574 minecraft:blue_concrete
fill 136 184 586 136 207 590 minecraft:blue_concrete
setblock 136 184 591 minecraft:pearlescent_froglight
setblock 136 184 598 minecraft:white_concrete
fill 94 185 566 94 186 566 minecraft:white_concrete
fill 94 185 567 94 196 568 minecraft:blue_concrete
fill 98 185 599 98 223 599 minecraft:blue_concrete
fill 109 185 557 109 240 557 minecraft:blue_concrete
fill 109 185 576 109 187 576 minecraft:pearlescent_froglight
fill 109 185 582 109 187 582 minecraft:pearlescent_froglight
setblock 110 185 557 minecraft:white_concrete
fill 110 185 575 110 187 575 minecraft:pearlescent_froglight
fill 110 185 576 110 186 576 minecraft:light_gray_concrete
fill 110 185 582 110 186 582 minecraft:light_gray_concrete
fill 110 185 583 110 187 583 minecraft:pearlescent_froglight
fill 111 185 557 112 234 557 minecraft:blue_concrete
fill 111 185 574 111 187 574 minecraft:pearlescent_froglight
fill 111 185 575 113 185 577 minecraft:redstone_block
fill 111 185 583 113 185 585 minecraft:redstone_block
fill 112 185 573 112 187 573 minecraft:pearlescent_froglight
fill 112 185 574 112 186 574 minecraft:light_gray_concrete
fill 114 185 577 114 186 578 minecraft:light_gray_concrete
fill 114 185 584 114 186 584 minecraft:light_gray_concrete
fill 114 185 585 114 189 585 minecraft:pearlescent_froglight
fill 116 185 584 116 186 584 minecraft:light_gray_concrete
fill 116 185 585 116 189 585 minecraft:pearlescent_froglight
fill 117 185 579 117 186 579 minecraft:light_gray_concrete
fill 117 185 583 119 185 585 minecraft:redstone_block
fill 118 185 573 118 188 573 minecraft:pearlescent_froglight
fill 118 185 574 118 188 574 minecraft:light_gray_concrete
fill 119 185 574 119 187 574 minecraft:pearlescent_froglight
setblock 119 185 599 minecraft:white_concrete
fill 120 185 575 120 187 575 minecraft:pearlescent_froglight
fill 120 185 576 120 187 576 minecraft:light_gray_concrete
fill 120 185 582 120 186 582 minecraft:light_gray_concrete
fill 120 185 583 120 187 583 minecraft:pearlescent_froglight
fill 120 185 599 120 224 599 minecraft:blue_concrete
fill 121 185 576 121 187 576 minecraft:pearlescent_froglight
fill 121 185 582 121 187 582 minecraft:pearlescent_froglight
setblock 129 185 557 minecraft:blue_concrete
fill 132 185 557 132 189 557 minecraft:blue_concrete
fill 136 185 557 136 238 558 minecraft:blue_concrete
setblock 136 185 559 minecraft:white_concrete
fill 136 185 560 136 193 562 minecraft:blue_concrete
fill 136 185 591 136 187 591 minecraft:blue_concrete
setblock 136 185 593 minecraft:white_stained_glass
fill 136 185 594 136 238 594 minecraft:blue_concrete
setblock 136 185 595 minecraft:white_stained_glass
fill 136 185 596 136 195 598 minecraft:blue_concrete
setblock 94 186 590 minecraft:white_stained_glass
setblock 97 186 560 minecraft:light[level=14]
setblock 97 186 568 minecraft:light[level=14]
setblock 97 186 576 minecraft:light[level=14]
setblock 97 186 584 minecraft:light[level=14]
setblock 97 186 592 minecraft:light[level=14]
setblock 105 186 560 minecraft:light[level=14]
setblock 105 186 568 minecraft:light[level=14]
setblock 105 186 576 minecraft:light[level=14]
setblock 105 186 584 minecraft:light[level=14]
setblock 105 186 592 minecraft:light[level=14]
fill 110 186 557 110 238 557 minecraft:blue_concrete
setblock 113 186 560 minecraft:light[level=14]
setblock 113 186 568 minecraft:light[level=14]
setblock 113 186 576 minecraft:light[level=14]
setblock 113 186 584 minecraft:light[level=14]
setblock 113 186 592 minecraft:light[level=14]
fill 119 186 599 119 234 599 minecraft:blue_concrete
setblock 121 186 560 minecraft:light[level=14]
setblock 121 186 568 minecraft:light[level=14]
setblock 121 186 584 minecraft:light[level=14]
setblock 121 186 592 minecraft:light[level=14]
setblock 129 186 557 minecraft:pearlescent_froglight
setblock 129 186 560 minecraft:light[level=14]
setblock 129 186 568 minecraft:light[level=14]
setblock 129 186 576 minecraft:light[level=14]
setblock 129 186 584 minecraft:light[level=14]
setblock 129 186 592 minecraft:light[level=14]
fill 136 186 559 136 227 559 minecraft:blue_concrete
setblock 136 186 570 minecraft:pearlescent_froglight
fill 136 186 593 136 197 593 minecraft:blue_concrete
setblock 136 186 595 minecraft:white_concrete
fill 94 187 558 94 201 560 minecraft:blue_concrete
setblock 94 187 561 minecraft:white_stained_glass
fill 94 187 562 94 202 564 minecraft:blue_concrete
fill 94 187 566 94 234 566 minecraft:blue_concrete
fill 94 187 590 94 216 590 minecraft:blue_concrete
fill 95 187 558 108 187 598 minecraft:black_concrete
setblock 103 187 557 minecraft:pearlescent_froglight
fill 109 187 558 109 187 575 minecraft:black_concrete
fill 109 187 583 109 187 598 minecraft:black_concrete
fill 110 187 558 111 187 573 minecraft:black_concrete
setblock 110 187 574 minecraft:pearlescent_froglight
fill 110 187 576 110 187 578 minecraft:pearlescent_froglight
fill 110 187 582 113 187 582 minecraft:pearlescent_froglight
fill 110 187 584 110 187 586 minecraft:pearlescent_froglight
fill 110 187 587 135 187 598 minecraft:black_concrete
fill 111 187 575 113 187 577 minecraft:black_concrete
fill 111 187 578 113 187 578 minecraft:pearlescent_froglight
fill 111 187 579 112 187 581 minecraft:light_gray_concrete
fill 111 187 583 113 187 585 minecraft:black_concrete
fill 111 187 586 114 187 586 minecraft:pearlescent_froglight
fill 112 187 558 135 187 572 minecraft:black_concrete
fill 112 187 574 114 187 574 minecraft:pearlescent_froglight
fill 113 187 579 113 187 581 minecraft:ochre_froglight
fill 114 187 575 114 187 577 minecraft:pearlescent_froglight
fill 114 187 578 116 187 578 minecraft:ochre_froglight
fill 114 187 582 116 187 582 minecraft:ochre_froglight
fill 114 187 583 114 187 584 minecraft:pearlescent_froglight
fill 115 187 575 116 191 577 minecraft:light_gray_concrete
fill 115 187 583 115 191 583 minecraft:light_gray_concrete
setblock 115 187 586 minecraft:black_concrete
fill 116 187 583 116 187 584 minecraft:pearlescent_froglight
fill 116 187 586 120 187 586 minecraft:pearlescent_froglight
setblock 117 187 578 minecraft:pearlescent_froglight
fill 117 187 579 117 187 581 minecraft:ochre_froglight
fill 117 187 582 120 187 582 minecraft:pearlescent_froglight
fill 117 187 583 119 187 585 minecraft:black_concrete
fill 118 187 581 119 187 581 minecraft:light_gray_concrete
fill 119 187 573 135 187 573 minecraft:black_concrete
fill 120 187 574 135 187 574 minecraft:black_concrete
fill 120 187 584 120 187 585 minecraft:pearlescent_froglight
fill 121 187 575 135 187 575 minecraft:black_concrete
fill 121 187 583 135 187 586 minecraft:black_concrete
fill 122 187 576 135 187 582 minecraft:black_concrete
fill 129 187 557 129 188 557 minecraft:blue_concrete
fill 136 187 570 136 235 570 minecraft:blue_concrete
setblock 136 187 572 minecraft:white_stained_glass
fill 136 187 573 136 234 573 minecraft:blue_concrete
fill 136 187 595 136 238 595 minecraft:blue_concrete
fill 94 188 561 94 217 561 minecraft:blue_concrete
fill 99 188 557 100 238 557 minecraft:blue_concrete
setblock 101 188 557 minecraft:white_concrete
fill 102 188 557 103 190 557 minecraft:blue_concrete
fill 102 188 571 111 196 589 minecraft:smooth_stone
fill 112 188 571 112 196 589 minecraft:oak_planks
fill 113 188 574 113 189 584 minecraft:light_gray_concrete
fill 113 188 585 113 189 585 minecraft:pearlescent_froglight
fill 114 188 574 114 189 578 minecraft:light_gray_concrete
fill 114 188 582 114 189 584 minecraft:light_gray_concrete
fill 115 188 578 118 191 578 minecraft:light_gray_concrete
fill 115 188 582 118 191 582 minecraft:light_gray_concrete
fill 116 188 583 118 188 584 minecraft:light_gray_concrete
fill 117 188 579 118 191 581 minecraft:light_gray_concrete
fill 117 188 585 118 188 585 minecraft:pearlescent_froglight
fill 119 188 571 119 196 589 minecraft:oak_planks
fill 120 188 571 128 196 589 minecraft:smooth_stone
fill 132 188 599 133 193 599 minecraft:blue_concrete
setblock 134 188 599 minecraft:pearlescent_froglight
fill 135 188 599 136 234 599 minecraft:blue_concrete
setblock 136 188 564 minecraft:white_concrete
fill 136 188 572 136 238 572 minecraft:blue_concrete
setblock 136 188 591 minecraft:white_concrete
setblock 94 189 581 minecraft:white_stained_glass
setblock 94 189 586 minecraft:pearlescent_froglight
setblock 95 189 599 minecraft:white_concrete
fill 101 189 557 101 209 557 minecraft:blue_concrete
setblock 108 189 599 minecraft:white_stained_glass
fill 116 189 583 117 189 584 minecraft:light_gray_concrete
setblock 117 189 585 minecraft:pearlescent_froglight
fill 118 189 574 118 190 574 minecraft:pearlescent_froglight
fill 118 189 583 118 190 583 minecraft:light_gray_concrete
fill 118 189 584 118 190 584 minecraft:pearlescent_froglight
setblock 129 189 557 minecraft:white_stained_glass
fill 134 189 599 134 191 599 minecraft:blue_concrete
fill 136 189 564 136 196 564 minecraft:blue_concrete
fill 136 189 591 136 232 591 minecraft:blue_concrete
setblock 94 190 581 minecraft:blue_concrete
fill 94 190 586 94 192 586 minecraft:blue_concrete
fill 95 190 599 95 211 599 minecraft:blue_concrete
setblock 104 190 599 minecraft:white_concrete
fill 105 190 599 108 190 599 minecraft:blue_concrete
fill 113 190 574 114 190 574 minecraft:pearlescent_froglight
fill 113 190 575 114 190 583 minecraft:light_gray_concrete
fill 113 190 584 114 190 584 minecraft:pearlescent_froglight
fill 115 190 579 116 192 579 minecraft:light_gray_concrete
fill 116 190 574 117 190 574 minecraft:pearlescent_froglight
fill 116 190 583 117 190 583 minecraft:light_gray_concrete
fill 116 190 584 117 190 584 minecraft:pearlescent_froglight
fill 129 190 557 129 234 557 minecraft:blue_concrete
setblock 132 190 557 minecraft:white_concrete
setblock 136 190 567 minecraft:pearlescent_froglight
setblock 94 191 565 minecraft:light_gray_concrete
setblock 94 191 581 minecraft:light_gray_concrete
setblock 94 191 587 minecraft:white_concrete
setblock 94 191 597 minecraft:light_gray_concrete
setblock 98 191 557 minecraft:light_gray_concrete
fill 102 191 557 102 234 557 minecraft:blue_concrete
setblock 103 191 557 minecraft:pearlescent_froglight
fill 104 191 599 107 199 599 minecraft:blue_concrete
setblock 108 191 599 minecraft:light_gray_concrete
setblock 113 191 575 minecraft:pearlescent_froglight
fill 113 191 576 114 191 582 minecraft:light_gray_concrete
setblock 113 191 583 minecraft:pearlescent_froglight
setblock 114 191 557 minecraft:light_gray_concrete
fill 114 191 574 116 191 574 minecraft:pearlescent_froglight
setblock 114 191 575 minecraft:light_gray_concrete
setblock 114 191 583 minecraft:light_gray_concrete
fill 114 191 584 116 191 584 minecraft:pearlescent_froglight
setblock 116 191 583 minecraft:light_gray_concrete
setblock 116 191 599 minecraft:white_concrete
fill 117 191 575 118 191 575 minecraft:pearlescent_froglight
fill 117 191 583 118 191 583 minecraft:pearlescent_froglight
setblock 124 191 599 minecraft:light_gray_concrete
setblock 130 191 557 minecraft:light_gray_concrete
fill 132 191 557 132 231 557 minecraft:blue_concrete
setblock 136 191 567 minecraft:light_gray_concrete
setblock 136 191 583 minecraft:light_gray_concrete
setblock 94 192 565 minecraft:blue_concrete
fill 94 192 581 94 197 581 minecraft:blue_concrete
fill 94 192 587 94 198 587 minecraft:blue_concrete
fill 94 192 597 94 197 597 minecraft:blue_concrete
fill 98 192 557 98 197 557 minecraft:blue_concrete
fill 103 192 557 103 238 557 minecraft:blue_concrete
fill 108 192 599 108 197 599 minecraft:blue_concrete
fill 110 192 599 110 238 599 minecraft:blue_concrete
setblock 111 192 599 minecraft:white_concrete
fill 113 192 576 113 192 577 minecraft:pearlescent_froglight
fill 113 192 578 114 192 580 minecraft:light_gray_concrete
fill 113 192 581 113 192 582 minecraft:pearlescent_froglight
fill 114 192 557 114 197 557 minecraft:blue_concrete
fill 114 192 575 116 192 576 minecraft:pearlescent_froglight
fill 114 192 577 116 192 577 minecraft:light_gray_concrete
setblock 114 192 581 minecraft:light_gray_concrete
fill 114 192 582 116 192 583 minecraft:pearlescent_froglight
fill 115 192 578 117 192 578 minecraft:light_gray_concrete
fill 116 192 599 116 238 599 minecraft:blue_concrete
fill 117 192 576 118 192 577 minecraft:pearlescent_froglight
fill 117 192 579 117 192 580 minecraft:light_gray_concrete
fill 117 192 581 118 192 582 minecraft:pearlescent_froglight
fill 118 192 578 118 192 580 minecraft:pearlescent_froglight
fill 124 192 599 124 197 599 minecraft:blue_concrete
fill 127 192 599 128 207 599 minecraft:blue_concrete
setblock 129 192 599 minecraft:white_stained_glass
fill 130 192 557 130 197 557 minecraft:blue_concrete
fill 130 192 599 130 206 599 minecraft:blue_concrete
setblock 134 192 599 minecraft:pearlescent_froglight
fill 136 192 567 136 197 567 minecraft:blue_concrete
fill 136 192 583 136 197 583 minecraft:blue_concrete
setblock 94 193 565 minecraft:white_stained_glass
setblock 94 193 586 minecraft:white_concrete
fill 111 193 599 111 232 599 minecraft:blue_concrete
fill 113 193 578 114 193 580 minecraft:pearlescent_froglight
fill 114 193 577 116 193 577 minecraft:pearlescent_froglight
setblock 114 193 581 minecraft:pearlescent_froglight
fill 115 193 578 117 193 579 minecraft:pearlescent_froglight
fill 117 193 587 117 194 588 minecraft:light_gray_concrete
fill 129 193 599 129 220 599 minecraft:blue_concrete
fill 134 193 599 134 239 599 minecraft:blue_concrete
fill 136 193 578 136 204 578 minecraft:blue_concrete
setblock 136 193 579 minecraft:white_stained_glass
fill 94 194 565 94 197 565 minecraft:blue_concrete
fill 94 194 586 94 208 586 minecraft:blue_concrete
fill 94 194 595 94 234 595 minecraft:blue_concrete
setblock 94 194 596 minecraft:white_concrete
setblock 97 194 560 minecraft:light[level=14]
setblock 97 194 568 minecraft:light[level=14]
setblock 97 194 576 minecraft:light[level=14]
setblock 97 194 584 minecraft:light[level=14]
setblock 97 194 592 minecraft:light[level=14]
setblock 105 194 560 minecraft:light[level=14]
setblock 105 194 568 minecraft:light[level=14]
setblock 105 194 592 minecraft:light[level=14]
setblock 113 194 560 minecraft:light[level=14]
setblock 113 194 568 minecraft:light[level=14]
setblock 113 194 576 minecraft:light[level=14]
setblock 113 194 584 minecraft:light[level=14]
setblock 113 194 592 minecraft:light[level=14]
setblock 117 194 557 minecraft:pearlescent_froglight
setblock 118 194 599 minecraft:pearlescent_froglight
setblock 121 194 560 minecraft:light[level=14]
setblock 121 194 568 minecraft:light[level=14]
setblock 121 194 592 minecraft:light[level=14]
setblock 129 194 560 minecraft:light[level=14]
setblock 129 194 568 minecraft:light[level=14]
setblock 129 194 576 minecraft:light[level=14]
setblock 129 194 584 minecraft:light[level=14]
setblock 129 194 592 minecraft:light[level=14]
setblock 132 194 599 minecraft:pearlescent_froglight
fill 133 194 599 133 238 599 minecraft:blue_concrete
fill 136 194 560 136 201 561 minecraft:blue_concrete
setblock 136 194 562 minecraft:white_concrete
fill 136 194 579 136 237 579 minecraft:blue_concrete
fill 94 195 596 94 209 596 minecraft:blue_concrete
fill 117 195 557 117 208 557 minecraft:blue_concrete
fill 118 195 599 118 238 599 minecraft:blue_concrete
fill 132 195 599 132 235 599 minecraft:blue_concrete
fill 136 195 562 136 205 562 minecraft:blue_concrete
setblock 125 196 599 minecraft:white_concrete
setblock 128 196 557 minecraft:white_stained_glass
fill 136 196 596 136 209 597 minecraft:blue_concrete
setblock 136 196 598 minecraft:white_stained_glass
setblock 94 197 567 minecraft:pearlescent_froglight
fill 94 197 568 94 238 568 minecraft:blue_concrete
fill 104 197 576 104 198 576 minecraft:gray_concrete
fill 125 197 599 125 238 599 minecraft:blue_concrete
fill 128 197 557 128 235 557 minecraft:blue_concrete
setblock 136 197 564 minecraft:pearlescent_froglight
fill 136 197 598 136 227 598 minecraft:blue_concrete
fill 94 198 565 94 200 565 minecraft:light_gray_concrete
fill 94 198 567 94 199 567 minecraft:blue_concrete
setblock 94 198 570 minecraft:white_concrete
fill 94 198 577 94 215 577 minecraft:blue_concrete
setblock 94 198 578 minecraft:white_stained_glass
fill 94 198 579 94 238 579 minecraft:blue_concrete
setblock 94 198 580 minecraft:white_stained_glass
fill 94 198 581 94 200 581 minecraft:light_gray_concrete
fill 94 198 597 94 200 597 minecraft:light_gray_concrete
fill 98 198 557 98 200 557 minecraft:light_gray_concrete
fill 108 198 599 108 200 599 minecraft:light_gray_concrete
fill 114 198 557 114 200 557 minecraft:light_gray_concrete
fill 124 198 599 124 200 599 minecraft:light_gray_concrete
fill 130 198 557 130 200 557 minecraft:light_gray_concrete
fill 136 198 564 136 214 564 minecraft:blue_concrete
fill 136 198 567 136 200 567 minecraft:light_gray_concrete
fill 136 198 583 136 200 583 minecraft:light_gray_concrete
setblock 136 198 593 minecraft:white_concrete
fill 94 199 570 94 224 570 minecraft:blue_concrete
fill 94 199 578 94 203 578 minecraft:blue_concrete
fill 94 199 580 94 213 580 minecraft:blue_concrete
setblock 94 199 587 minecraft:white_concrete
fill 102 199 578 128 200 579 minecraft:iron_block
setblock 136 199 565 minecraft:white_concrete
fill 136 199 593 136 235 593 minecraft:blue_concrete
setblock 94 200 567 minecraft:white_concrete
fill 94 200 571 94 204 574 minecraft:blue_concrete
setblock 94 200 575 minecraft:white_stained_glass
fill 94 200 587 94 212 587 minecraft:blue_concrete
setblock 104 200 599 minecraft:pearlescent_froglight
fill 105 200 599 107 234 599 minecraft:blue_concrete
fill 132 200 580 134 201 580 minecraft:gray_concrete
fill 133 200 581 133 201 581 minecraft:gray_concrete
fill 136 200 565 136 238 565 minecraft:blue_concrete
fill 94 201 565 94 206 565 minecraft:blue_concrete
fill 94 201 567 94 235 567 minecraft:blue_concrete
fill 94 201 575 94 238 575 minecraft:blue_concrete
fill 94 201 581 94 206 581 minecraft:blue_concrete
fill 94 201 597 94 206 597 minecraft:blue_concrete
fill 98 201 557 98 206 557 minecraft:blue_concrete
fill 104 201 599 104 223 599 minecraft:blue_concrete
fill 108 201 599 108 206 599 minecraft:blue_concrete
fill 114 201 557 114 206 557 minecraft:blue_concrete
fill 122 201 599 122 207 599 minecraft:blue_concrete
setblock 123 201 599 minecraft:white_concrete
fill 124 201 599 124 206 599 minecraft:blue_concrete
fill 130 201 557 130 206 557 minecraft:blue_concrete
fill 136 201 567 136 206 567 minecraft:blue_concrete
fill 136 201 583 136 206 583 minecraft:blue_concrete
fill 94 202 558 94 238 558 minecraft:blue_concrete
setblock 94 202 559 minecraft:pearlescent_froglight
fill 94 202 560 94 238 560 minecraft:blue_concrete
setblock 97 202 560 minecraft:light[level=14]
setblock 97 202 568 minecraft:light[level=14]
setblock 97 202 576 minecraft:light[level=14]
setblock 97 202 584 minecraft:light[level=14]
setblock 97 202 592 minecraft:light[level=14]
setblock 105 202 560 minecraft:light[level=14]
setblock 105 202 568 minecraft:light[level=14]
setblock 105 202 576 minecraft:light[level=14]
setblock 105 202 584 minecraft:light[level=14]
setblock 105 202 592 minecraft:light[level=14]
setblock 113 202 560 minecraft:light[level=14]
setblock 113 202 568 minecraft:light[level=14]
setblock 113 202 576 minecraft:light[level=14]
setblock 113 202 584 minecraft:light[level=14]
setblock 113 202 592 minecraft:light[level=14]
setblock 121 202 560 minecraft:light[level=14]
setblock 121 202 568 minecraft:light[level=14]
setblock 121 202 576 minecraft:light[level=14]
setblock 121 202 584 minecraft:light[level=14]
setblock 121 202 592 minecraft:light[level=14]
fill 123 202 599 123 236 599 minecraft:blue_concrete
setblock 129 202 560 minecraft:light[level=14]
setblock 129 202 568 minecraft:light[level=14]
setblock 129 202 576 minecraft:light[level=14]
setblock 129 202 584 minecraft:light[level=14]
setblock 129 202 592 minecraft:light[level=14]
setblock 136 202 560 minecraft:white_stained_glass
fill 136 202 561 136 234 561 minecraft:blue_concrete
fill 94 203 559 94 221 559 minecraft:blue_concrete
setblock 94 203 562 minecraft:white_concrete
fill 94 203 563 94 219 564 minecraft:blue_concrete
setblock 136 203 560 minecraft:blue_concrete
fill 94 204 562 94 238 562 minecraft:blue_concrete
setblock 94 204 578 minecraft:white_concrete
setblock 94 204 593 minecraft:white_stained_glass
setblock 97 204 599 minecraft:pearlescent_froglight
setblock 136 204 560 minecraft:white_stained_glass
fill 94 205 571 94 212 571 minecraft:blue_concrete
setblock 94 205 572 minecraft:pearlescent_froglight
setblock 94 205 573 minecraft:white_concrete
fill 94 205 574 94 236 574 minecraft:blue_concrete
fill 94 205 578 94 238 578 minecraft:blue_concrete
setblock 94 205 584 minecraft:pearlescent_froglight
fill 94 205 593 94 234 593 minecraft:blue_concrete
fill 97 205 599 97 235 599 minecraft:blue_concrete
fill 136 205 560 136 238 560 minecraft:blue_concrete
setblock 136 205 574 minecraft:pearlescent_froglight
setblock 136 205 578 minecraft:white_concrete
setblock 94 206 572 minecraft:white_stained_glass
fill 94 206 573 94 226 573 minecraft:blue_concrete
fill 94 206 584 94 209 584 minecraft:blue_concrete
setblock 104 206 557 minecraft:pearlescent_froglight
fill 105 206 557 105 238 557 minecraft:blue_concrete
setblock 136 206 562 minecraft:white_concrete
fill 136 206 574 136 220 574 minecraft:blue_concrete
fill 136 206 578 136 238 578 minecraft:blue_concrete
fill 94 207 565 94 209 565 minecraft:light_gray_concrete
fill 94 207 572 94 233 572 minecraft:blue_concrete
fill 94 207 581 94 209 581 minecraft:light_gray_concrete
fill 94 207 597 94 209 597 minecraft:light_gray_concrete
fill 98 207 557 98 209 557 minecraft:light_gray_concrete
fill 104 207 557 104 208 557 minecraft:blue_concrete
fill 105 207 587 107 208 587 minecraft:end_stone
fill 106 207 586 106 208 586 minecraft:end_stone
fill 106 207 588 106 208 588 minecraft:end_stone
fill 108 207 599 108 209 599 minecraft:light_gray_concrete
fill 114 207 557 114 209 557 minecraft:light_gray_concrete
fill 124 207 599 124 209 599 minecraft:light_gray_concrete
fill 130 207 557 130 209 557 minecraft:light_gray_concrete
setblock 130 207 599 minecraft:white_stained_glass
fill 136 207 562 136 238 562 minecraft:blue_concrete
fill 136 207 567 136 209 567 minecraft:light_gray_concrete
fill 136 207 583 136 209 583 minecraft:light_gray_concrete
setblock 106 208 557 minecraft:white_concrete
setblock 122 208 599 minecraft:white_concrete
setblock 127 208 599 minecraft:pearlescent_froglight
fill 128 208 599 128 238 599 minecraft:blue_concrete
fill 130 208 599 130 238 599 minecraft:blue_concrete
fill 136 208 586 136 218 588 minecraft:blue_concrete
setblock 136 208 589 minecraft:white_stained_glass
fill 136 208 590 136 214 590 minecraft:blue_concrete
setblock 94 209 586 minecraft:white_concrete
setblock 104 209 557 minecraft:white_stained_glass
fill 106 209 557 106 218 557 minecraft:blue_concrete
setblock 117 209 557 minecraft:white_concrete
fill 122 209 599 122 220 599 minecraft:blue_concrete
fill 127 209 599 127 231 599 minecraft:blue_concrete
fill 133 209 557 134 220 557 minecraft:blue_concrete
setblock 135 209 557 minecraft:white_stained_glass
setblock 136 209 563 minecraft:white_concrete
setblock 136 209 584 minecraft:white_stained_glass
fill 136 209 585 136 213 585 minecraft:blue_concrete
fill 136 209 589 136 221 589 minecraft:blue_concrete
fill 94 210 565 94 215 565 minecraft:blue_concrete
fill 94 210 581 94 215 581 minecraft:blue_concrete
setblock 94 210 584 minecraft:white_concrete
fill 94 210 586 94 234 586 minecraft:blue_concrete
setblock 94 210 596 minecraft:pearlescent_froglight
fill 94 210 597 94 215 597 minecraft:blue_concrete
setblock 97 210 560 minecraft:light[level=14]
setblock 97 210 568 minecraft:light[level=14]
setblock 97 210 576 minecraft:light[level=14]
setblock 97 210 584 minecraft:light[level=14]
setblock 97 210 592 minecraft:light[level=14]
fill 98 210 557 98 215 557 minecraft:blue_concrete
setblock 101 210 557 minecraft:white_concrete
fill 104 210 557 104 238 557 minecraft:blue_concrete
setblock 105 210 560 minecraft:light[level=14]
setblock 105 210 568 minecraft:light[level=14]
setblock 105 210 576 minecraft:light[level=14]
setblock 105 210 584 minecraft:light[level=14]
setblock 105 210 592 minecraft:light[level=14]
fill 108 210 599 108 215 599 minecraft:blue_concrete
setblock 112 210 599 minecraft:white_stained_glass
setblock 113 210 560 minecraft:light[level=14]
setblock 113 210 568 minecraft:light[level=14]
setblock 113 210 576 minecraft:light[level=14]
setblock 113 210 584 minecraft:light[level=14]
setblock 113 210 592 minecraft:light[level=14]
fill 114 210 557 114 215 557 minecraft:blue_concrete
setblock 115 210 557 minecraft:white_concrete
fill 117 210 557 117 236 557 minecraft:blue_concrete
setblock 121 210 560 minecraft:light[level=14]
setblock 121 210 568 minecraft:light[level=14]
setblock 121 210 576 minecraft:light[level=14]
setblock 121 210 584 minecraft:light[level=14]
setblock 121 210 592 minecraft:light[level=14]
fill 124 210 599 124 215 599 minecraft:blue_concrete
setblock 129 210 560 minecraft:light[level=14]
setblock 129 210 568 minecraft:light[level=14]
setblock 129 210 576 minecraft:light[level=14]
setblock 129 210 584 minecraft:light[level=14]
setblock 129 210 592 minecraft:light[level=14]
fill 130 210 557 130 214 557 minecraft:blue_concrete
fill 135 210 557 135 234 557 minecraft:blue_concrete
fill 136 210 563 136 228 563 minecraft:blue_concrete
fill 136 210 567 136 215 567 minecraft:blue_concrete
setblock 136 210 577 minecraft:pearlescent_froglight
fill 136 210 583 136 215 584 minecraft:blue_concrete
setblock 136 210 596 minecraft:white_stained_glass
fill 136 210 597 136 226 597 minecraft:blue_concrete
fill 94 211 584 94 229 584 minecraft:blue_concrete
fill 94 211 596 94 238 596 minecraft:blue_concrete
fill 101 211 557 101 236 557 minecraft:blue_concrete
fill 112 211 599 112 238 599 minecraft:blue_concrete
fill 115 211 557 115 238 557 minecraft:blue_concrete
fill 136 211 577 136 230 577 minecraft:blue_concrete
fill 136 211 596 136 238 596 minecraft:blue_concrete
setblock 95 212 599 minecraft:pearlescent_froglight
setblock 94 213 571 minecraft:pearlescent_froglight
setblock 94 213 587 minecraft:white_concrete
fill 95 213 599 95 238 599 minecraft:blue_concrete
fill 100 213 599 100 235 599 minecraft:blue_concrete
setblock 101 213 599 minecraft:pearlescent_froglight
fill 102 213 599 102 239 599 minecraft:blue_concrete
setblock 117 213 599 minecraft:white_stained_glass
fill 94 214 571 94 238 571 minecraft:blue_concrete
setblock 94 214 580 minecraft:pearlescent_froglight
fill 94 214 587 94 238 587 minecraft:blue_concrete
fill 101 214 599 101 238 599 minecraft:blue_concrete
fill 117 214 599 117 239 599 minecraft:blue_concrete
setblock 125 214 557 minecraft:white_concrete
fill 126 214 557 127 235 557 minecraft:blue_concrete
setblock 136 214 585 minecraft:white_concrete
fill 94 215 580 94 238 580 minecraft:blue_concrete
setblock 95 215 557 minecraft:white_stained_glass
setblock 125 215 557 minecraft:pearlescent_froglight
setblock 130 215 557 minecraft:pearlescent_froglight
setblock 136 215 564 minecraft:pearlescent_froglight
fill 136 215 585 136 238 585 minecraft:blue_concrete
setblock 136 215 590 minecraft:white_stained_glass
fill 94 216 565 94 218 565 minecraft:light_gray_concrete
setblock 94 216 577 minecraft:pearlescent_froglight
fill 94 216 581 94 218 581 minecraft:light_gray_concrete
fill 94 216 597 94 218 597 minecraft:light_gray_concrete
fill 95 216 557 95 219 557 minecraft:blue_concrete
fill 98 216 557 98 218 557 minecraft:light_gray_concrete
setblock 107 216 557 minecraft:white_stained_glass
fill 108 216 557 108 236 557 minecraft:blue_concrete
fill 108 216 599 108 218 599 minecraft:light_gray_concrete
fill 114 216 557 114 218 557 minecraft:light_gray_concrete
fill 114 216 569 114 217 569 minecraft:gray_concrete
fill 124 216 599 124 218 599 minecraft:light_gray_concrete
fill 125 216 557 125 236 557 minecraft:blue_concrete
fill 130 216 557 130 218 557 minecraft:light_gray_concrete
fill 136 216 564 136 236 564 minecraft:blue_concrete
fill 136 216 567 136 218 567 minecraft:light_gray_concrete
fill 136 216 583 136 218 583 minecraft:light_gray_concrete
fill 136 216 584 136 235 584 minecraft:blue_concrete
fill 136 216 590 136 235 590 minecraft:blue_concrete
fill 94 217 577 94 234 577 minecraft:blue_concrete
setblock 94 217 590 minecraft:white_concrete
fill 102 217 591 106 218 595 minecraft:gray_concrete
fill 104 217 596 104 217 597 minecraft:gray_concrete
fill 107 217 557 107 235 557 minecraft:blue_concrete
setblock 94 218 561 minecraft:white_stained_glass
fill 94 218 590 94 236 590 minecraft:blue_concrete
setblock 97 218 560 minecraft:light[level=14]
setblock 97 218 568 minecraft:light[level=14]
setblock 97 218 576 minecraft:light[level=14]
setblock 97 218 584 minecraft:light[level=14]
setblock 97 218 592 minecraft:light[level=14]
fill 101 218 593 101 219 593 minecraft:light_gray_concrete
fill 104 218 590 104 219 590 minecraft:light_gray_concrete
fill 104 218 596 104 219 596 minecraft:light_gray_concrete
setblock 105 218 560 minecraft:light[level=14]
setblock 105 218 568 minecraft:light[level=14]
setblock 105 218 576 minecraft:light[level=14]
setblock 105 218 584 minecraft:light[level=14]
fill 107 218 593 107 219 593 minecraft:light_gray_concrete
setblock 113 218 560 minecraft:light[level=14]
setblock 113 218 568 minecraft:light[level=14]
setblock 113 218 576 minecraft:light[level=14]
setblock 113 218 584 minecraft:light[level=14]
setblock 113 218 592 minecraft:light[level=14]
setblock 121 218 560 minecraft:light[level=14]
setblock 121 218 568 minecraft:light[level=14]
setblock 121 218 576 minecraft:light[level=14]
setblock 121 218 584 minecraft:light[level=14]
setblock 121 218 592 minecraft:light[level=14]
setblock 129 218 560 minecraft:light[level=14]
setblock 129 218 568 minecraft:light[level=14]
setblock 129 218 576 minecraft:light[level=14]
setblock 129 218 584 minecraft:light[level=14]
setblock 129 218 592 minecraft:light[level=14]
fill 94 219 561 94 221 561 minecraft:blue_concrete
fill 94 219 565 94 224 565 minecraft:blue_concrete
fill 94 219 581 94 224 581 minecraft:blue_concrete
fill 94 219 597 94 224 597 minecraft:blue_concrete
fill 98 219 557 98 224 557 minecraft:blue_concrete
fill 103 219 592 105 229 594 minecraft:end_stone
setblock 106 219 557 minecraft:white_stained_glass
fill 108 219 599 108 224 599 minecraft:blue_concrete
fill 114 219 557 114 224 557 minecraft:blue_concrete
fill 124 219 599 124 224 599 minecraft:blue_concrete
fill 130 219 557 130 224 557 minecraft:blue_concrete
fill 136 219 567 136 224 567 minecraft:blue_concrete
fill 136 219 583 136 224 583 minecraft:blue_concrete
fill 136 219 586 136 230 587 minecraft:blue_concrete
setblock 136 219 588 minecraft:white_concrete
setblock 94 220 563 minecraft:white_concrete
fill 94 220 564 94 238 564 minecraft:blue_concrete
setblock 95 220 557 minecraft:white_concrete
fill 102 220 593 102 221 593 minecraft:light_gray_concrete
fill 104 220 591 104 221 591 minecraft:light_gray_concrete
fill 104 220 595 104 221 595 minecraft:light_gray_concrete
fill 106 220 557 106 238 557 minecraft:blue_concrete
fill 106 220 593 106 221 593 minecraft:light_gray_concrete
fill 114 220 586 115 221 587 minecraft:gray_concrete
fill 119 220 563 120 221 564 minecraft:end_stone
setblock 136 220 575 minecraft:pearlescent_froglight
fill 136 220 576 136 237 576 minecraft:blue_concrete
fill 136 220 588 136 238 588 minecraft:blue_concrete
fill 94 221 563 94 228 563 minecraft:blue_concrete
fill 95 221 557 95 238 557 minecraft:blue_concrete
setblock 122 221 599 minecraft:pearlescent_froglight
setblock 129 221 599 minecraft:pearlescent_froglight
setblock 133 221 557 minecraft:white_stained_glass
fill 134 221 557 134 238 557 minecraft:blue_concrete
setblock 136 221 574 minecraft:pearlescent_froglight
fill 136 221 575 136 231 575 minecraft:blue_concrete
setblock 136 221 580 minecraft:white_concrete
setblock 94 222 559 minecraft:white_concrete
setblock 94 222 561 minecraft:white_stained_glass
fill 122 222 599 122 238 599 minecraft:blue_concrete
fill 129 222 599 129 238 599 minecraft:blue_concrete
fill 133 222 557 133 238 557 minecraft:blue_concrete
fill 136 222 574 136 238 574 minecraft:blue_concrete
fill 136 222 580 136 238 580 minecraft:blue_concrete
setblock 136 222 589 minecraft:white_stained_glass
fill 94 223 559 94 235 559 minecraft:blue_concrete
fill 94 223 561 94 238 561 minecraft:blue_concrete
fill 109 223 591 113 224 595 minecraft:gray_concrete
fill 111 223 596 111 223 597 minecraft:gray_concrete
fill 136 223 589 136 239 589 minecraft:blue_concrete
setblock 94 224 582 minecraft:white_concrete
setblock 98 224 599 minecraft:pearlescent_froglight
setblock 104 224 599 minecraft:white_concrete
fill 108 224 593 108 225 593 minecraft:light_gray_concrete
fill 111 224 590 111 225 590 minecraft:light_gray_concrete
fill 111 224 596 111 225 596 minecraft:light_gray_concrete
fill 114 224 593 114 225 593 minecraft:light_gray_concrete
setblock 136 224 581 minecraft:white_stained_glass
fill 136 224 582 136 238 582 minecraft:blue_concrete
fill 94 225 565 94 227 565 minecraft:light_gray_concrete
setblock 94 225 570 minecraft:pearlescent_froglight
fill 94 225 581 94 227 581 minecraft:light_gray_concrete
fill 94 225 582 94 228 582 minecraft:blue_concrete
fill 94 225 597 94 227 597 minecraft:light_gray_concrete
fill 98 225 557 98 227 557 minecraft:light_gray_concrete
fill 98 225 599 98 236 599 minecraft:blue_concrete
fill 104 225 599 104 235 599 minecraft:blue_concrete
fill 108 225 599 108 227 599 minecraft:light_gray_concrete
fill 110 225 592 112 231 594 minecraft:end_stone
fill 114 225 557 114 227 557 minecraft:light_gray_concrete
setblock 120 225 599 minecraft:pearlescent_froglight
fill 124 225 599 124 227 599 minecraft:light_gray_concrete
fill 130 225 557 130 227 557 minecraft:light_gray_concrete
fill 136 225 567 136 227 567 minecraft:light_gray_concrete
fill 136 225 581 136 238 581 minecraft:blue_concrete
fill 136 225 583 136 227 583 minecraft:light_gray_concrete
fill 94 226 570 94 239 570 minecraft:blue_concrete
setblock 97 226 560 minecraft:light[level=14]
setblock 97 226 568 minecraft:light[level=14]
setblock 97 226 576 minecraft:light[level=14]
setblock 97 226 584 minecraft:light[level=14]
setblock 97 226 592 minecraft:light[level=14]
setblock 105 226 560 minecraft:light[level=14]
setblock 105 226 568 minecraft:light[level=14]
setblock 105 226 576 minecraft:light[level=14]
setblock 105 226 584 minecraft:light[level=14]
fill 109 226 593 109 227 593 minecraft:light_gray_concrete
fill 111 226 591 111 227 591 minecraft:light_gray_concrete
fill 111 226 595 111 227 595 minecraft:light_gray_concrete
setblock 113 226 560 minecraft:light[level=14]
setblock 113 226 568 minecraft:light[level=14]
setblock 113 226 576 minecraft:light[level=14]
setblock 113 226 584 minecraft:light[level=14]
setblock 113 226 592 minecraft:light[level=14]
fill 113 226 593 113 227 593 minecraft:light_gray_concrete
fill 120 226 599 120 234 599 minecraft:blue_concrete
setblock 121 226 560 minecraft:light[level=14]
setblock 121 226 568 minecraft:light[level=14]
setblock 121 226 576 minecraft:light[level=14]
setblock 121 226 584 minecraft:light[level=14]
setblock 121 226 592 minecraft:light[level=14]
setblock 129 226 560 minecraft:light[level=14]
setblock 129 226 568 minecraft:light[level=14]
setblock 129 226 576 minecraft:light[level=14]
setblock 129 226 584 minecraft:light[level=14]
setblock 129 226 592 minecraft:light[level=14]
setblock 94 227 573 minecraft:white_concrete
setblock 136 227 597 minecraft:white_stained_glass
fill 94 228 565 94 236 565 minecraft:blue_concrete
fill 94 228 573 94 236 573 minecraft:blue_concrete
fill 94 228 581 94 238 581 minecraft:blue_concrete
fill 94 228 597 94 238 597 minecraft:blue_concrete
fill 98 228 557 98 238 557 minecraft:blue_concrete
fill 108 228 599 108 238 599 minecraft:blue_concrete
fill 114 228 557 114 231 557 minecraft:blue_concrete
setblock 116 228 557 minecraft:white_stained_glass
fill 124 228 599 124 238 599 minecraft:blue_concrete
fill 130 228 557 130 238 557 minecraft:blue_concrete
setblock 136 228 559 minecraft:pearlescent_froglight
fill 136 228 567 136 238 567 minecraft:blue_concrete
fill 136 228 583 136 233 583 minecraft:blue_concrete
setblock 136 228 592 minecraft:pearlescent_froglight
fill 136 228 597 136 238 597 minecraft:blue_concrete
setblock 136 228 598 minecraft:white_stained_glass
setblock 94 229 563 minecraft:pearlescent_froglight
setblock 94 229 582 minecraft:white_stained_glass
setblock 94 229 591 minecraft:white_concrete
fill 94 229 592 94 236 592 minecraft:blue_concrete
setblock 113 229 557 minecraft:pearlescent_froglight
fill 116 229 557 116 235 557 minecraft:blue_concrete
fill 136 229 559 136 238 559 minecraft:blue_concrete
setblock 136 229 563 minecraft:pearlescent_froglight
fill 136 229 592 136 236 592 minecraft:blue_concrete
fill 136 229 598 136 238 598 minecraft:blue_concrete
fill 94 230 563 94 238 563 minecraft:blue_concrete
fill 94 230 582 94 238 582 minecraft:blue_concrete
setblock 94 230 584 minecraft:white_stained_glass
fill 94 230 591 94 235 591 minecraft:blue_concrete
setblock 97 230 557 minecraft:white_stained_glass
fill 103 230 592 105 230 594 minecraft:light_gray_concrete
fill 113 230 557 113 238 557 minecraft:blue_concrete
fill 136 230 563 136 235 563 minecraft:blue_concrete
fill 94 231 584 94 234 584 minecraft:blue_concrete
fill 97 231 557 97 238 557 minecraft:blue_concrete
fill 103 231 593 105 231 593 minecraft:light_gray_concrete
setblock 104 231 592 minecraft:light_gray_concrete
setblock 104 231 594 minecraft:light_gray_concrete
setblock 136 231 577 minecraft:white_concrete
fill 136 231 586 136 238 586 minecraft:blue_concrete
setblock 136 231 587 minecraft:white_stained_glass
setblock 114 232 557 minecraft:white_concrete
setblock 127 232 599 minecraft:white_concrete
setblock 132 232 557 minecraft:white_stained_glass
setblock 136 232 575 minecraft:white_concrete
fill 136 232 577 136 238 577 minecraft:blue_concrete
fill 136 232 587 136 238 587 minecraft:blue_concrete
setblock 111 233 599 minecraft:white_stained_glass
fill 114 233 557 114 234 557 minecraft:blue_concrete
fill 127 233 599 127 238 599 minecraft:blue_concrete
fill 132 233 557 132 234 557 minecraft:blue_concrete
fill 136 233 575 136 239 575 minecraft:blue_concrete
setblock 136 233 591 minecraft:pearlescent_froglight
setblock 94 234 572 minecraft:white_concrete
setblock 97 234 560 minecraft:light[level=14]
setblock 97 234 568 minecraft:light[level=14]
setblock 97 234 576 minecraft:light[level=14]
setblock 97 234 584 minecraft:light[level=14]
setblock 97 234 592 minecraft:light[level=14]
setblock 105 234 560 minecraft:light[level=14]
setblock 105 234 568 minecraft:light[level=14]
setblock 105 234 576 minecraft:light[level=14]
setblock 105 234 584 minecraft:light[level=14]
setblock 105 234 592 minecraft:light[level=14]
fill 111 234 599 111 238 599 minecraft:blue_concrete
setblock 113 234 560 minecraft:light[level=14]
setblock 113 234 568 minecraft:light[level=14]
setblock 113 234 576 minecraft:light[level=14]
setblock 113 234 584 minecraft:light[level=14]
setblock 113 234 592 minecraft:light[level=14]
setblock 121 234 560 minecraft:light[level=14]
setblock 121 234 568 minecraft:light[level=14]
setblock 121 234 576 minecraft:light[level=14]
setblock 121 234 584 minecraft:light[level=14]
setblock 121 234 592 minecraft:light[level=14]
setblock 129 234 560 minecraft:light[level=14]
setblock 129 234 568 minecraft:light[level=14]
setblock 129 234 576 minecraft:light[level=14]
setblock 129 234 584 minecraft:light[level=14]
setblock 129 234 592 minecraft:light[level=14]
setblock 136 234 583 minecraft:white_concrete
fill 136 234 591 136 238 591 minecraft:blue_concrete
setblock 94 235 557 minecraft:black_concrete
setblock 94 235 566 minecraft:white_stained_glass
fill 94 235 569 94 236 569 minecraft:black_concrete
fill 94 235 572 94 238 572 minecraft:blue_concrete
setblock 94 235 577 minecraft:black_concrete
setblock 94 235 584 minecraft:pearlescent_froglight
fill 94 235 586 94 237 586 minecraft:black_concrete
setblock 94 235 589 minecraft:black_concrete
setblock 94 235 593 minecraft:white_concrete
fill 94 235 594 94 235 595 minecraft:black_concrete
setblock 96 235 599 minecraft:black_concrete
setblock 102 235 557 minecraft:black_concrete
setblock 103 235 599 minecraft:black_concrete
fill 105 235 599 106 238 599 minecraft:blue_concrete
fill 107 235 599 107 236 599 minecraft:black_concrete
fill 111 235 557 111 238 557 minecraft:blue_concrete
setblock 112 235 557 minecraft:white_stained_glass
setblock 114 235 557 minecraft:black_concrete
fill 114 235 599 114 238 599 minecraft:blue_concrete
fill 115 235 599 115 236 599 minecraft:black_concrete
setblock 119 235 599 minecraft:white_stained_glass
setblock 120 235 599 minecraft:black_concrete
setblock 123 235 557 minecraft:black_concrete
setblock 129 235 557 minecraft:black_concrete
setblock 132 235 557 minecraft:black_concrete
setblock 135 235 557 minecraft:black_concrete
fill 135 235 599 135 238 599 minecraft:blue_concrete
setblock 136 235 561 minecraft:black_concrete
setblock 136 235 566 minecraft:black_concrete
setblock 136 235 573 minecraft:black_concrete
fill 136 235 583 136 238 583 minecraft:blue_concrete
setblock 136 235 599 minecraft:black_concrete
fill 94 236 557 94 238 557 minecraft:blue_concrete
setblock 94 236 559 minecraft:black_concrete
fill 94 236 566 94 238 566 minecraft:blue_concrete
setblock 94 236 567 minecraft:black_concrete
fill 94 236 577 94 239 577 minecraft:blue_concrete
fill 94 236 584 94 238 584 minecraft:blue_concrete
fill 94 236 589 94 238 589 minecraft:blue_concrete
setblock 94 236 591 minecraft:white_concrete
fill 94 236 593 94 236 595 minecraft:blue_concrete
fill 96 236 599 96 238 599 minecraft:blue_concrete
setblock 97 236 599 minecraft:black_concrete
setblock 100 236 599 minecraft:black_concrete
setblock 102 236 557 minecraft:blue_concrete
fill 103 236 599 103 238 599 minecraft:blue_concrete
setblock 104 236 599 minecraft:white_concrete
setblock 107 236 557 minecraft:black_concrete
fill 111 236 579 113 236 581 minecraft:redstone_block
fill 112 236 557 112 239 557 minecraft:blue_concrete
fill 114 236 557 114 238 557 minecraft:blue_concrete
setblock 116 236 557 minecraft:black_concrete
fill 116 236 574 118 236 576 minecraft:redstone_block
fill 116 236 584 118 236 586 minecraft:redstone_block
fill 119 236 599 120 238 599 minecraft:blue_concrete
fill 121 236 579 123 236 581 minecraft:redstone_block
setblock 122 236 557 minecraft:white_concrete
fill 123 236 557 123 238 557 minecraft:blue_concrete
fill 126 236 557 126 239 557 minecraft:blue_concrete
setblock 127 236 557 minecraft:pearlescent_froglight
setblock 128 236 557 minecraft:white_stained_glass
setblock 129 236 557 minecraft:blue_concrete
setblock 132 236 557 minecraft:blue_concrete
setblock 132 236 599 minecraft:black_concrete
fill 135 236 557 135 238 557 minecraft:blue_concrete
fill 136 236 561 136 238 561 minecraft:blue_concrete
setblock 136 236 563 minecraft:white_concrete
fill 136 236 566 136 238 566 minecraft:blue_concrete
setblock 136 236 570 minecraft:black_concrete
fill 136 236 573 136 238 573 minecraft:blue_concrete
setblock 136 236 584 minecraft:black_concrete
setblock 136 236 590 minecraft:pearlescent_froglight
setblock 136 236 593 minecraft:black_concrete
fill 136 236 599 136 239 599 minecraft:blue_concrete
fill 94 237 559 94 238 559 minecraft:blue_concrete
setblock 94 237 565 minecraft:black_concrete
fill 94 237 567 94 238 567 minecraft:blue_concrete
fill 94 237 569 94 238 569 minecraft:blue_concrete
fill 94 237 573 94 237 574 minecraft:black_concrete
setblock 94 237 590 minecraft:black_concrete
fill 94 237 591 94 238 591 minecraft:blue_concrete
setblock 94 237 592 minecraft:black_concrete
fill 94 237 593 94 238 594 minecraft:blue_concrete
setblock 94 237 595 minecraft:black_concrete
fill 94 237 598 94 239 598 minecraft:blue_concrete
setblock 94 237 599 minecraft:black_concrete
fill 95 237 558 96 238 562 minecraft:end_stone
fill 95 237 563 95 238 563 minecraft:black_concrete
fill 95 237 564 97 238 567 minecraft:end_stone
fill 95 237 568 95 238 568 minecraft:black_concrete
fill 95 237 569 95 238 588 minecraft:end_stone
fill 95 237 589 95 238 589 minecraft:black_concrete
fill 95 237 590 95 238 598 minecraft:end_stone
fill 96 237 563 101 238 563 minecraft:end_stone
fill 96 237 568 101 238 568 minecraft:end_stone
fill 96 237 569 96 238 569 minecraft:black_concrete
fill 96 237 570 98 238 573 minecraft:end_stone
fill 96 237 574 96 238 574 minecraft:black_concrete
fill 96 237 575 96 238 594 minecraft:end_stone
fill 96 237 595 96 238 595 minecraft:black_concrete
fill 96 237 596 99 238 598 minecraft:end_stone
fill 97 237 558 135 238 558 minecraft:end_stone
fill 97 237 559 97 238 559 minecraft:black_concrete
fill 97 237 560 97 238 562 minecraft:end_stone
fill 97 237 569 102 238 569 minecraft:end_stone
fill 97 237 574 99 238 579 minecraft:end_stone
fill 97 237 580 97 238 580 minecraft:black_concrete
fill 97 237 581 97 238 595 minecraft:end_stone
fill 97 237 599 97 238 599 minecraft:blue_concrete
fill 98 237 559 103 238 559 minecraft:end_stone
fill 98 237 560 98 238 560 minecraft:black_concrete
fill 98 237 561 100 238 562 minecraft:end_stone
fill 98 237 564 135 238 564 minecraft:end_stone
fill 98 237 565 98 238 565 minecraft:black_concrete
fill 98 237 566 98 238 567 minecraft:end_stone
fill 98 237 580 100 238 585 minecraft:end_stone
fill 98 237 586 98 238 586 minecraft:black_concrete
fill 98 237 587 98 238 595 minecraft:end_stone
fill 98 237 599 99 237 599 minecraft:black_concrete
fill 99 237 560 104 238 560 minecraft:end_stone
fill 99 237 565 104 238 565 minecraft:end_stone
fill 99 237 566 99 238 566 minecraft:black_concrete
fill 99 237 567 135 238 567 minecraft:end_stone
fill 99 237 570 135 238 570 minecraft:end_stone
fill 99 237 571 99 238 571 minecraft:black_concrete
fill 99 237 572 99 238 573 minecraft:end_stone
fill 99 237 586 101 238 591 minecraft:end_stone
fill 99 237 592 99 238 592 minecraft:black_concrete
fill 99 237 593 102 238 595 minecraft:end_stone
fill 100 237 566 105 238 566 minecraft:end_stone
fill 100 237 571 105 238 571 minecraft:end_stone
fill 100 237 572 100 238 572 minecraft:black_concrete
fill 100 237 573 102 238 576 minecraft:end_stone
fill 100 237 577 100 238 577 minecraft:black_concrete
fill 100 237 578 107 238 579 minecraft:end_stone
fill 100 237 592 105 238 592 minecraft:end_stone
fill 100 237 596 131 238 597 minecraft:end_stone
fill 100 237 598 100 238 598 minecraft:black_concrete
fill 100 237 599 100 238 599 minecraft:blue_concrete
setblock 101 237 557 minecraft:white_concrete
fill 101 237 561 135 238 561 minecraft:end_stone
fill 101 237 562 101 238 562 minecraft:black_concrete
fill 101 237 572 106 238 572 minecraft:end_stone
fill 101 237 577 106 238 577 minecraft:end_stone
fill 101 237 580 103 238 582 minecraft:end_stone
fill 101 237 583 101 238 583 minecraft:black_concrete
fill 101 237 584 115 237 585 minecraft:end_stone
fill 101 237 598 106 238 598 minecraft:end_stone
setblock 102 237 557 minecraft:black_concrete
fill 102 237 562 107 238 562 minecraft:end_stone
fill 102 237 563 102 238 563 minecraft:black_concrete
fill 102 237 568 102 238 568 minecraft:black_concrete
fill 102 237 583 107 238 583 minecraft:end_stone
fill 102 237 586 104 238 588 minecraft:end_stone
fill 102 237 589 102 238 589 minecraft:black_concrete
fill 102 237 590 123 238 591 minecraft:end_stone
fill 103 237 563 108 238 563 minecraft:end_stone
fill 103 237 568 108 238 568 minecraft:end_stone
fill 103 237 569 103 238 569 minecraft:black_concrete
fill 103 237 573 135 237 573 minecraft:end_stone
fill 103 237 574 103 238 574 minecraft:black_concrete
fill 103 237 575 103 238 576 minecraft:end_stone
fill 103 237 589 108 238 589 minecraft:end_stone
fill 103 237 593 127 238 594 minecraft:end_stone
fill 103 237 595 103 238 595 minecraft:black_concrete
fill 104 237 559 104 238 559 minecraft:black_concrete
fill 104 237 569 109 238 569 minecraft:end_stone
fill 104 237 574 109 238 574 minecraft:end_stone
fill 104 237 575 104 238 575 minecraft:black_concrete
fill 104 237 576 115 237 576 minecraft:end_stone
fill 104 237 580 104 238 580 minecraft:black_concrete
fill 104 237 581 110 237 582 minecraft:end_stone
fill 104 237 595 109 238 595 minecraft:end_stone
fill 104 237 599 104 238 599 minecraft:blue_concrete
fill 105 237 559 110 238 559 minecraft:end_stone
fill 105 237 560 105 238 560 minecraft:black_concrete
fill 105 237 565 105 238 565 minecraft:black_concrete
fill 105 237 575 110 238 575 minecraft:end_stone
fill 105 237 580 110 237 580 minecraft:end_stone
fill 105 237 586 105 238 586 minecraft:black_concrete
fill 105 237 587 119 237 588 minecraft:end_stone
fill 106 237 560 111 238 560 minecraft:end_stone
fill 106 237 565 111 238 565 minecraft:end_stone
fill 106 237 566 106 238 566 minecraft:black_concrete
fill 106 237 571 106 238 571 minecraft:black_concrete
fill 106 237 586 111 238 586 minecraft:end_stone
fill 106 237 592 106 238 592 minecraft:black_concrete
fill 107 237 557 107 238 557 minecraft:blue_concrete
fill 107 237 566 112 238 566 minecraft:end_stone
fill 107 237 571 112 238 571 minecraft:end_stone
fill 107 237 572 107 238 572 minecraft:black_concrete
fill 107 237 577 107 238 577 minecraft:black_concrete
fill 107 237 592 112 238 592 minecraft:end_stone
fill 107 237 598 107 238 598 minecraft:black_concrete
fill 107 237 599 107 238 599 minecraft:blue_concrete
setblock 108 237 557 minecraft:white_stained_glass
fill 108 237 562 108 238 562 minecraft:black_concrete
fill 108 237 572 113 238 572 minecraft:end_stone
fill 108 237 577 113 238 577 minecraft:end_stone
fill 108 237 578 108 238 578 minecraft:black_concrete
fill 108 237 579 110 237 579 minecraft:end_stone
fill 108 237 583 108 238 583 minecraft:black_concrete
fill 108 237 598 113 238 598 minecraft:end_stone
fill 109 237 562 114 238 562 minecraft:end_stone
fill 109 237 563 109 238 563 minecraft:black_concrete
fill 109 237 568 109 238 568 minecraft:black_concrete
fill 109 237 578 114 237 578 minecraft:end_stone
fill 109 237 583 114 238 583 minecraft:end_stone
fill 109 237 589 109 238 589 minecraft:black_concrete
fill 110 237 563 115 238 563 minecraft:end_stone
fill 110 237 568 115 238 568 minecraft:end_stone
fill 110 237 569 110 238 569 minecraft:black_concrete
fill 110 237 574 110 238 574 minecraft:black_concrete
fill 110 237 589 115 238 589 minecraft:end_stone
fill 110 237 595 110 238 595 minecraft:black_concrete
fill 111 237 559 111 238 559 minecraft:black_concrete
fill 111 237 569 116 238 569 minecraft:end_stone
fill 111 237 574 115 237 574 minecraft:end_stone
fill 111 237 575 111 238 575 minecraft:black_concrete
fill 111 237 582 135 237 582 minecraft:end_stone
fill 111 237 595 116 238 595 minecraft:end_stone
fill 112 237 559 135 238 559 minecraft:end_stone
fill 112 237 560 112 238 560 minecraft:black_concrete
fill 112 237 565 112 238 565 minecraft:black_concrete
fill 112 237 575 115 237 575 minecraft:end_stone
fill 112 237 586 112 238 586 minecraft:black_concrete
fill 113 237 560 118 238 560 minecraft:end_stone
fill 113 237 565 118 238 565 minecraft:end_stone
fill 113 237 566 113 238 566 minecraft:black_concrete
fill 113 237 571 113 238 571 minecraft:black_concrete
fill 113 237 586 115 237 586 minecraft:end_stone
fill 113 237 592 113 238 592 minecraft:black_concrete
fill 114 237 566 119 238 566 minecraft:end_stone
fill 114 237 571 119 238 571 minecraft:end_stone
fill 114 237 572 114 238 572 minecraft:black_concrete
fill 114 237 577 114 238 577 minecraft:black_concrete
fill 114 237 579 115 237 581 minecraft:end_stone
fill 114 237 592 119 238 592 minecraft:end_stone
fill 114 237 598 114 238 598 minecraft:black_concrete
fill 115 237 562 115 238 562 minecraft:black_concrete
fill 115 237 572 120 238 572 minecraft:end_stone
fill 115 237 577 120 237 577 minecraft:end_stone
setblock 115 237 578 minecraft:black_concrete
setblock 115 237 583 minecraft:black_concrete
fill 115 237 598 120 238 598 minecraft:end_stone
fill 115 237 599 115 238 599 minecraft:blue_concrete
fill 116 237 557 116 238 557 minecraft:blue_concrete
fill 116 237 562 135 238 562 minecraft:end_stone
fill 116 237 563 116 238 563 minecraft:black_concrete
fill 116 237 568 116 238 568 minecraft:black_concrete
fill 116 237 578 121 237 578 minecraft:end_stone
fill 116 237 583 121 237 583 minecraft:end_stone
fill 116 237 589 116 238 589 minecraft:black_concrete
setblock 117 237 557 minecraft:black_concrete
fill 117 237 563 122 238 563 minecraft:end_stone
fill 117 237 568 122 238 568 minecraft:end_stone
fill 117 237 569 117 238 569 minecraft:black_concrete
fill 117 237 589 122 238 589 minecraft:end_stone
fill 117 237 595 117 238 595 minecraft:black_concrete
fill 118 237 569 123 238 569 minecraft:end_stone
fill 118 237 595 123 238 595 minecraft:end_stone
fill 119 237 560 119 238 560 minecraft:black_concrete
fill 119 237 565 119 238 565 minecraft:black_concrete
fill 119 237 574 123 237 576 minecraft:end_stone
fill 119 237 579 120 237 580 minecraft:end_stone
setblock 119 237 581 minecraft:black_concrete
fill 119 237 584 122 237 585 minecraft:end_stone
setblock 119 237 586 minecraft:black_concrete
fill 120 237 560 125 238 560 minecraft:end_stone
fill 120 237 565 135 238 565 minecraft:end_stone
fill 120 237 566 120 238 566 minecraft:black_concrete
fill 120 237 571 120 238 571 minecraft:black_concrete
setblock 120 237 581 minecraft:end_stone
fill 120 237 586 125 238 586 minecraft:end_stone
fill 120 237 587 120 238 587 minecraft:black_concrete
fill 120 237 588 135 238 588 minecraft:end_stone
fill 120 237 592 120 238 592 minecraft:black_concrete
setblock 121 237 557 minecraft:black_concrete
fill 121 237 566 126 238 566 minecraft:end_stone
fill 121 237 571 126 238 571 minecraft:end_stone
fill 121 237 572 121 238 572 minecraft:black_concrete
fill 121 237 577 121 238 577 minecraft:black_concrete
fill 121 237 587 126 238 587 minecraft:end_stone
fill 121 237 592 126 238 592 minecraft:end_stone
fill 121 237 598 121 238 598 minecraft:black_concrete
fill 122 237 557 122 238 557 minecraft:blue_concrete
fill 122 237 572 127 238 572 minecraft:end_stone
fill 122 237 577 127 238 577 minecraft:end_stone
setblock 122 237 578 minecraft:black_concrete
fill 122 237 583 122 238 583 minecraft:black_concrete
fill 122 237 598 127 238 598 minecraft:end_stone
fill 123 237 563 123 238 563 minecraft:black_concrete
fill 123 237 568 123 238 568 minecraft:black_concrete
fill 123 237 578 128 237 578 minecraft:end_stone
fill 123 237 583 128 238 583 minecraft:end_stone
fill 123 237 584 123 238 584 minecraft:black_concrete
fill 123 237 585 135 238 585 minecraft:end_stone
fill 123 237 589 123 238 589 minecraft:black_concrete
setblock 123 237 599 minecraft:black_concrete
fill 124 237 563 129 238 563 minecraft:end_stone
fill 124 237 568 135 238 568 minecraft:end_stone
fill 124 237 569 124 238 569 minecraft:black_concrete
fill 124 237 574 124 238 574 minecraft:black_concrete
fill 124 237 575 124 238 576 minecraft:end_stone
fill 124 237 579 124 237 581 minecraft:end_stone
fill 124 237 584 129 238 584 minecraft:end_stone
fill 124 237 589 129 238 589 minecraft:end_stone
fill 124 237 590 124 238 590 minecraft:black_concrete
fill 124 237 591 135 238 591 minecraft:end_stone
fill 124 237 595 124 238 595 minecraft:black_concrete
setblock 125 237 557 minecraft:black_concrete
fill 125 237 569 130 238 569 minecraft:end_stone
fill 125 237 574 130 238 574 minecraft:end_stone
fill 125 237 575 125 238 575 minecraft:black_concrete
fill 125 237 576 135 238 576 minecraft:end_stone
fill 125 237 579 135 238 579 minecraft:end_stone
fill 125 237 580 125 238 580 minecraft:black_concrete
fill 125 237 581 125 238 581 minecraft:end_stone
fill 125 237 590 130 238 590 minecraft:end_stone
fill 125 237 595 130 238 595 minecraft:end_stone
fill 126 237 560 126 238 560 minecraft:black_concrete
fill 126 237 575 131 238 575 minecraft:end_stone
fill 126 237 580 131 238 580 minecraft:end_stone
fill 126 237 581 126 238 581 minecraft:black_concrete
fill 126 237 586 126 238 586 minecraft:black_concrete
fill 127 237 557 128 238 557 minecraft:blue_concrete
fill 127 237 560 132 238 560 minecraft:end_stone
fill 127 237 566 127 238 566 minecraft:black_concrete
fill 127 237 571 127 238 571 minecraft:black_concrete
fill 127 237 581 132 238 581 minecraft:end_stone
fill 127 237 586 132 238 586 minecraft:end_stone
fill 127 237 587 127 238 587 minecraft:black_concrete
fill 127 237 592 127 238 592 minecraft:black_concrete
fill 128 237 566 133 238 566 minecraft:end_stone
fill 128 237 571 135 238 571 minecraft:end_stone
fill 128 237 572 128 238 572 minecraft:black_concrete
fill 128 237 577 128 238 577 minecraft:black_concrete
fill 128 237 587 133 238 587 minecraft:end_stone
fill 128 237 592 133 238 592 minecraft:end_stone
fill 128 237 593 128 238 593 minecraft:black_concrete
fill 128 237 594 135 238 594 minecraft:end_stone
fill 128 237 598 128 238 598 minecraft:black_concrete
setblock 129 237 557 minecraft:black_concrete
fill 129 237 572 134 238 572 minecraft:end_stone
fill 129 237 577 134 238 577 minecraft:end_stone
fill 129 237 578 129 238 578 minecraft:black_concrete
fill 129 237 583 129 238 583 minecraft:black_concrete
fill 129 237 593 134 238 593 minecraft:end_stone
fill 129 237 598 134 238 598 minecraft:end_stone
fill 130 237 563 130 238 563 minecraft:black_concrete
fill 130 237 578 135 238 578 minecraft:end_stone
fill 130 237 583 135 238 583 minecraft:end_stone
fill 130 237 584 130 238 584 minecraft:black_concrete
fill 130 237 589 130 238 589 minecraft:black_concrete
fill 131 237 563 135 238 563 minecraft:end_stone
fill 131 237 569 131 238 569 minecraft:black_concrete
fill 131 237 574 131 238 574 minecraft:black_concrete
fill 131 237 584 135 238 584 minecraft:end_stone
fill 131 237 589 135 238 589 minecraft:end_stone
fill 131 237 590 131 238 590 minecraft:black_concrete
fill 131 237 595 131 238 595 minecraft:black_concrete
fill 132 237 557 132 238 557 minecraft:white_stained_glass
fill 132 237 569 135 238 569 minecraft:end_stone
fill 132 237 574 135 238 574 minecraft:end_stone
fill 132 237 575 132 238 575 minecraft:black_concrete
fill 132 237 580 132 238 580 minecraft:black_concrete
fill 132 237 590 135 238 590 minecraft:end_stone
fill 132 237 595 135 238 595 minecraft:end_stone
fill 132 237 596 132 238 596 minecraft:black_concrete
fill 132 237 597 135 238 597 minecraft:end_stone
fill 132 237 599 132 238 599 minecraft:blue_concrete
fill 133 237 560 133 238 560 minecraft:black_concrete
fill 133 237 575 135 238 575 minecraft:end_stone
fill 133 237 580 135 238 580 minecraft:end_stone
fill 133 237 581 133 238 581 minecraft:black_concrete
fill 133 237 586 133 238 586 minecraft:black_concrete
fill 133 237 596 135 238 596 minecraft:end_stone
fill 134 237 560 135 238 560 minecraft:end_stone
fill 134 237 566 134 238 566 minecraft:black_concrete
fill 134 237 581 135 238 581 minecraft:end_stone
fill 134 237 586 135 238 586 minecraft:end_stone
fill 134 237 587 134 238 587 minecraft:black_concrete
fill 134 237 592 134 238 592 minecraft:black_concrete
fill 135 237 566 135 238 566 minecraft:end_stone
fill 135 237 572 135 238 572 minecraft:black_concrete
fill 135 237 577 135 238 577 minecraft:black_concrete
fill 135 237 587 135 238 587 minecraft:end_stone
fill 135 237 592 135 238 592 minecraft:end_stone
fill 135 237 593 135 238 593 minecraft:black_concrete
fill 135 237 598 135 238 598 minecraft:black_concrete
fill 136 237 563 136 239 563 minecraft:blue_concrete
setblock 136 237 564 minecraft:black_concrete
fill 136 237 570 136 238 570 minecraft:blue_concrete
fill 136 237 584 136 238 584 minecraft:blue_concrete
fill 136 237 590 136 238 590 minecraft:blue_concrete
setblock 136 237 592 minecraft:black_concrete
fill 136 237 593 136 238 593 minecraft:blue_concrete
setblock 94 238 565 minecraft:blue_concrete
fill 94 238 573 94 238 574 minecraft:blue_concrete
setblock 94 238 586 minecraft:blue_concrete
setblock 94 238 590 minecraft:blue_concrete
setblock 94 238 592 minecraft:blue_concrete
setblock 94 238 595 minecraft:blue_concrete
setblock 94 238 599 minecraft:blue_concrete
setblock 96 238 557 minecraft:white_stained_glass
fill 98 238 599 99 238 599 minecraft:blue_concrete
fill 101 238 557 102 238 557 minecraft:blue_concrete
fill 101 238 584 114 238 585 minecraft:end_stone
fill 103 238 573 114 238 573 minecraft:end_stone
fill 104 238 576 114 238 576 minecraft:end_stone
fill 104 238 581 109 238 582 minecraft:end_stone
fill 105 238 580 109 238 580 minecraft:end_stone
fill 105 238 587 114 238 588 minecraft:end_stone
setblock 108 238 557 minecraft:blue_concrete
fill 108 238 579 109 238 579 minecraft:end_stone
setblock 109 238 578 minecraft:end_stone
fill 110 238 578 110 238 582 minecraft:pearlescent_froglight
fill 111 238 574 114 238 574 minecraft:end_stone
fill 111 238 578 124 238 578 minecraft:pearlescent_froglight
fill 111 238 579 113 238 581 minecraft:end_stone
fill 111 238 582 124 238 582 minecraft:pearlescent_froglight
fill 112 238 575 114 238 575 minecraft:end_stone
fill 113 238 586 114 238 586 minecraft:end_stone
fill 114 238 579 115 238 581 minecraft:pearlescent_froglight
fill 115 238 573 115 238 577 minecraft:pearlescent_froglight
fill 115 238 583 115 238 587 minecraft:pearlescent_froglight
fill 115 238 588 119 238 588 minecraft:end_stone
fill 116 238 573 119 238 573 minecraft:pearlescent_froglight
fill 116 238 574 118 238 576 minecraft:end_stone
fill 116 238 577 119 238 577 minecraft:pearlescent_froglight
fill 116 238 583 119 238 583 minecraft:pearlescent_froglight
fill 116 238 584 118 238 586 minecraft:end_stone
fill 116 238 587 119 238 587 minecraft:pearlescent_froglight
setblock 117 238 557 minecraft:blue_concrete
fill 119 238 574 119 238 576 minecraft:pearlescent_froglight
fill 119 238 579 120 238 581 minecraft:pearlescent_froglight
fill 119 238 584 119 238 586 minecraft:pearlescent_froglight
fill 120 238 573 120 238 577 minecraft:end_stone
fill 120 238 583 121 238 585 minecraft:end_stone
fill 121 238 557 121 239 557 minecraft:blue_concrete
fill 121 238 573 123 238 576 minecraft:end_stone
fill 121 238 579 123 238 581 minecraft:end_stone
fill 122 238 584 122 238 585 minecraft:end_stone
setblock 123 238 599 minecraft:blue_concrete
fill 124 238 573 135 238 573 minecraft:end_stone
fill 124 238 579 124 238 581 minecraft:pearlescent_froglight
setblock 125 238 557 minecraft:blue_concrete
fill 125 238 578 128 238 578 minecraft:end_stone
fill 125 238 582 135 238 582 minecraft:end_stone
fill 129 238 557 129 239 557 minecraft:blue_concrete
setblock 136 238 564 minecraft:blue_concrete
setblock 136 238 576 minecraft:white_stained_glass
setblock 136 238 579 minecraft:white_stained_glass
setblock 136 238 592 minecraft:blue_concrete
fill 94 239 557 94 239 569 minecraft:black_concrete
fill 94 239 571 94 240 576 minecraft:black_concrete
fill 94 239 578 94 239 591 minecraft:black_concrete
setblock 94 239 592 minecraft:white_stained_glass
fill 94 239 593 94 240 597 minecraft:black_concrete
fill 94 239 599 97 239 599 minecraft:black_concrete
fill 95 239 557 108 239 557 minecraft:black_concrete
setblock 98 239 599 minecraft:blue_concrete
fill 99 239 599 101 239 599 minecraft:black_concrete
fill 103 239 599 105 274 599 minecraft:black_concrete
setblock 106 239 599 minecraft:blue_concrete
fill 107 239 599 116 239 599 minecraft:black_concrete
fill 110 239 557 111 268 557 minecraft:black_concrete
fill 113 239 557 119 242 557 minecraft:black_concrete
fill 118 239 599 133 239 599 minecraft:black_concrete
setblock 120 239 557 minecraft:blue_concrete
fill 122 239 557 123 278 557 minecraft:black_concrete
fill 125 239 557 125 307 557 minecraft:black_concrete
fill 127 239 557 128 279 557 minecraft:black_concrete
fill 130 239 557 136 239 557 minecraft:black_concrete
fill 135 239 599 135 243 599 minecraft:black_concrete
fill 136 239 558 136 247 562 minecraft:black_concrete
fill 136 239 564 136 239 574 minecraft:black_concrete
fill 136 239 576 136 239 588 minecraft:black_concrete
fill 136 239 590 136 240 598 minecraft:black_concrete
fill 94 240 557 94 241 557 minecraft:blue_concrete
fill 94 240 558 94 268 564 minecraft:black_concrete
setblock 94 240 565 minecraft:blue_concrete
fill 94 240 566 94 240 570 minecraft:black_concrete
fill 94 240 577 94 256 577 minecraft:black_concrete
setblock 94 240 578 minecraft:blue_concrete
fill 94 240 579 94 307 579 minecraft:black_concrete
setblock 94 240 580 minecraft:blue_concrete
fill 94 240 581 94 242 583 minecraft:black_concrete
setblock 94 240 584 minecraft:blue_concrete
fill 94 240 585 94 240 589 minecraft:black_concrete
setblock 94 240 590 minecraft:blue_concrete
fill 94 240 591 94 240 592 minecraft:black_concrete
fill 94 240 598 94 307 599 minecraft:black_concrete
fill 95 240 557 97 250 557 minecraft:black_concrete
fill 95 240 599 96 271 599 minecraft:black_concrete
setblock 97 240 599 minecraft:blue_concrete
setblock 98 240 557 minecraft:blue_concrete
fill 98 240 599 98 287 599 minecraft:black_concrete
fill 99 240 557 101 241 557 minecraft:black_concrete
setblock 99 240 599 minecraft:blue_concrete
fill 100 240 599 102 250 599 minecraft:black_concrete
setblock 102 240 557 minecraft:blue_concrete
fill 103 240 557 108 240 557 minecraft:black_concrete
fill 106 240 599 109 242 599 minecraft:black_concrete
setblock 110 240 599 minecraft:blue_concrete
fill 111 240 599 120 240 599 minecraft:black_concrete
fill 112 240 557 112 241 557 minecraft:black_concrete
fill 120 240 557 121 246 557 minecraft:black_concrete
fill 121 240 599 121 241 599 minecraft:blue_concrete
fill 122 240 599 134 240 599 minecraft:black_concrete
fill 124 240 557 124 294 557 minecraft:black_concrete
fill 126 240 557 126 249 557 minecraft:black_concrete
fill 129 240 557 135 242 557 minecraft:black_concrete
setblock 136 240 557 minecraft:blue_concrete
fill 136 240 563 136 240 572 minecraft:black_concrete
setblock 136 240 573 minecraft:blue_concrete
fill 136 240 574 136 265 575 minecraft:black_concrete
setblock 136 240 576 minecraft:pearlescent_froglight
fill 136 240 577 136 242 579 minecraft:black_concrete
setblock 136 240 580 minecraft:blue_concrete
fill 136 240 581 136 258 582 minecraft:black_concrete
fill 136 240 583 136 240 584 minecraft:blue_concrete
fill 136 240 585 136 240 589 minecraft:black_concrete
fill 136 240 599 136 307 599 minecraft:black_concrete
fill 94 241 565 94 242 568 minecraft:black_concrete
setblock 94 241 569 minecraft:blue_concrete
fill 94 241 570 94 258 570 minecraft:black_concrete
setblock 94 241 571 minecraft:blue_concrete
fill 94 241 572 94 249 576 minecraft:black_concrete
fill 94 241 578 94 283 578 minecraft:black_concrete
fill 94 241 580 94 262 580 minecraft:black_concrete
fill 94 241 584 94 245 585 minecraft:black_concrete
setblock 94 241 586 minecraft:blue_concrete
fill 94 241 587 94 245 591 minecraft:black_concrete
fill 94 241 592 94 241 594 minecraft:blue_concrete
fill 94 241 595 94 242 597 minecraft:black_concrete
fill 97 241 599 97 250 599 minecraft:black_concrete
fill 98 241 557 98 242 557 minecraft:black_concrete
fill 99 241 599 99 307 599 minecraft:black_concrete
fill 102 241 557 105 262 557 minecraft:black_concrete
setblock 106 241 557 minecraft:white_stained_glass
fill 107 241 557 109 256 557 minecraft:black_concrete
fill 110 241 599 114 255 599 minecraft:black_concrete
setblock 115 241 599 minecraft:blue_concrete
fill 116 241 599 120 248 599 minecraft:black_concrete
fill 122 241 599 123 241 599 minecraft:blue_concrete
fill 124 241 599 134 242 599 minecraft:black_concrete
fill 136 241 557 136 307 557 minecraft:black_concrete
fill 136 241 563 136 258 563 minecraft:black_concrete
setblock 136 241 564 minecraft:blue_concrete
fill 136 241 565 136 307 565 minecraft:black_concrete
setblock 136 241 566 minecraft:white_concrete
fill 136 241 567 136 242 573 minecraft:black_concrete
fill 136 241 576 136 262 576 minecraft:black_concrete
fill 136 241 580 136 278 580 minecraft:black_concrete
fill 136 241 583 136 242 586 minecraft:black_concrete
setblock 136 241 587 minecraft:blue_concrete
fill 136 241 588 136 242 594 minecraft:black_concrete
setblock 136 241 595 minecraft:blue_concrete
fill 136 241 596 136 256 597 minecraft:black_concrete
setblock 136 241 598 minecraft:blue_concrete
fill 94 242 557 94 307 557 minecraft:black_concrete
setblock 94 242 569 minecraft:black_concrete
fill 94 242 571 94 291 571 minecraft:black_concrete
setblock 94 242 586 minecraft:black_concrete
fill 94 242 592 94 245 594 minecraft:black_concrete
setblock 97 242 560 minecraft:light[level=14]
setblock 97 242 568 minecraft:light[level=14]
setblock 97 242 576 minecraft:light[level=14]
setblock 97 242 584 minecraft:light[level=14]
setblock 97 242 592 minecraft:light[level=14]
fill 99 242 557 100 279 557 minecraft:black_concrete
setblock 101 242 557 minecraft:white_concrete
setblock 105 242 560 minecraft:light[level=14]
setblock 105 242 568 minecraft:light[level=14]
setblock 105 242 576 minecraft:light[level=14]
setblock 105 242 584 minecraft:light[level=14]
setblock 105 242 592 minecraft:light[level=14]
fill 106 242 557 106 307 557 minecraft:black_concrete
setblock 112 242 557 minecraft:pearlescent_froglight
setblock 113 242 560 minecraft:light[level=14]
setblock 113 242 568 minecraft:light[level=14]
setblock 113 242 576 minecraft:light[level=14]
setblock 113 242 584 minecraft:light[level=14]
setblock 113 242 592 minecraft:light[level=14]
fill 115 242 599 115 268 599 minecraft:black_concrete
fill 119 242 561 119 243 562 minecraft:gray_concrete
setblock 121 242 560 minecraft:light[level=14]
setblock 121 242 568 minecraft:light[level=14]
setblock 121 242 576 minecraft:light[level=14]
setblock 121 242 584 minecraft:light[level=14]
setblock 121 242 592 minecraft:light[level=14]
fill 121 242 599 123 243 599 minecraft:black_concrete
setblock 129 242 560 minecraft:light[level=14]
setblock 129 242 568 minecraft:light[level=14]
setblock 129 242 576 minecraft:light[level=14]
setblock 129 242 584 minecraft:light[level=14]
setblock 129 242 592 minecraft:light[level=14]
fill 136 242 564 136 252 564 minecraft:black_concrete
fill 136 242 566 136 251 566 minecraft:black_concrete
setblock 136 242 587 minecraft:black_concrete
fill 136 242 595 136 307 595 minecraft:black_concrete
fill 136 242 598 136 299 598 minecraft:black_concrete
fill 94 243 565 94 245 565 minecraft:light_gray_concrete
fill 94 243 566 94 270 568 minecraft:black_concrete
setblock 94 243 569 minecraft:white_stained_glass
fill 94 243 581 94 245 581 minecraft:light_gray_concrete
fill 94 243 582 94 273 583 minecraft:black_concrete
setblock 94 243 586 minecraft:white_concrete
fill 94 243 595 94 280 596 minecraft:black_concrete
fill 94 243 597 94 245 597 minecraft:light_gray_concrete
fill 98 243 557 98 245 557 minecraft:light_gray_concrete
fill 101 243 557 101 253 557 minecraft:black_concrete
fill 106 243 599 107 282 599 minecraft:black_concrete
fill 108 243 599 108 245 599 minecraft:light_gray_concrete
setblock 109 243 599 minecraft:white_stained_glass
fill 112 243 557 113 245 557 minecraft:black_concrete
fill 114 243 557 114 245 557 minecraft:light_gray_concrete
fill 115 243 557 119 251 557 minecraft:black_concrete
fill 124 243 599 124 245 599 minecraft:light_gray_concrete
fill 125 243 599 125 250 599 minecraft:black_concrete
setblock 126 243 599 minecraft:white_concrete
fill 127 243 599 134 247 599 minecraft:black_concrete
fill 129 243 557 129 296 557 minecraft:black_concrete
fill 130 243 557 130 245 557 minecraft:light_gray_concrete
fill 131 243 557 135 250 557 minecraft:black_concrete
fill 136 243 567 136 245 567 minecraft:light_gray_concrete
fill 136 243 568 136 253 573 minecraft:black_concrete
fill 136 243 577 136 264 578 minecraft:black_concrete
setblock 136 243 579 minecraft:pearlescent_froglight
fill 136 243 583 136 245 583 minecraft:light_gray_concrete
fill 136 243 584 136 248 586 minecraft:black_concrete
schedule function dropper:buildpart/134_2 1t
