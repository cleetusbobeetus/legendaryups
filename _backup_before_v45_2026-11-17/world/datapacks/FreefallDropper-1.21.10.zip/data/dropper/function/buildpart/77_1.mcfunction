fill 265 88 324 265 89 324 minecraft:moss_block
setblock 265 88 363 minecraft:mushroom_stem
fill 266 88 323 266 89 323 minecraft:moss_block
setblock 266 88 362 minecraft:mushroom_stem
fill 266 88 363 266 89 363 minecraft:moss_block
setblock 266 88 364 minecraft:red_mushroom_block
fill 269 88 340 272 88 340 minecraft:mushroom_stem
fill 270 88 339 272 88 339 minecraft:mushroom_stem
fill 270 88 341 272 88 341 minecraft:mushroom_stem
setblock 273 88 340 minecraft:red_mushroom_block
fill 274 88 346 274 141 346 minecraft:mushroom_stem
setblock 274 88 349 minecraft:mushroom_stem
fill 274 88 350 274 89 350 minecraft:moss_block
setblock 275 88 343 minecraft:mushroom_stem
fill 275 88 344 275 90 344 minecraft:moss_block
setblock 275 88 348 minecraft:mushroom_stem
fill 275 88 349 275 91 349 minecraft:moss_block
setblock 275 88 353 minecraft:mushroom_stem
setblock 276 88 323 minecraft:moss_block
setblock 276 88 326 minecraft:moss_block
setblock 276 88 327 minecraft:mushroom_stem
fill 276 88 328 276 91 328 minecraft:moss_block
setblock 276 88 332 minecraft:mushroom_stem
setblock 276 88 335 minecraft:red_mushroom_block
setblock 276 88 342 minecraft:mushroom_stem
fill 276 88 343 276 91 343 minecraft:moss_block
setblock 276 88 347 minecraft:mushroom_stem
fill 276 88 348 276 91 348 minecraft:moss_block
setblock 276 88 352 minecraft:mushroom_stem
fill 276 88 353 276 91 353 minecraft:moss_block
setblock 276 88 357 minecraft:mushroom_stem
fill 277 88 330 277 147 330 minecraft:brown_terracotta
fill 277 88 358 277 98 358 minecraft:brown_terracotta
fill 236 89 323 236 89 325 minecraft:moss_block
setblock 236 89 326 minecraft:mushroom_stem
fill 236 89 327 236 89 330 minecraft:moss_block
setblock 236 89 331 minecraft:mushroom_stem
fill 236 89 332 236 92 332 minecraft:moss_block
setblock 236 89 336 minecraft:mushroom_stem
fill 236 89 337 236 92 337 minecraft:moss_block
setblock 236 89 341 minecraft:mushroom_stem
fill 236 89 342 236 92 342 minecraft:moss_block
setblock 236 89 346 minecraft:mushroom_stem
fill 236 89 347 236 92 347 minecraft:moss_block
setblock 236 89 351 minecraft:mushroom_stem
fill 236 89 352 236 92 352 minecraft:moss_block
setblock 236 89 357 minecraft:red_mushroom_block
fill 237 89 323 237 89 324 minecraft:moss_block
setblock 237 89 325 minecraft:mushroom_stem
fill 237 89 326 238 91 326 minecraft:moss_block
setblock 237 89 329 minecraft:moss_block
setblock 237 89 330 minecraft:mushroom_stem
fill 237 89 331 237 92 331 minecraft:moss_block
setblock 237 89 335 minecraft:mushroom_stem
fill 237 89 336 237 92 336 minecraft:moss_block
setblock 237 89 340 minecraft:mushroom_stem
fill 237 89 341 237 90 341 minecraft:moss_block
setblock 237 89 345 minecraft:mushroom_stem
fill 237 89 346 237 92 346 minecraft:moss_block
setblock 237 89 350 minecraft:mushroom_stem
fill 237 89 351 237 92 351 minecraft:moss_block
setblock 238 89 323 minecraft:moss_block
setblock 238 89 324 minecraft:mushroom_stem
fill 238 89 325 238 90 325 minecraft:moss_block
setblock 238 89 329 minecraft:mushroom_stem
fill 238 89 330 238 92 330 minecraft:moss_block
setblock 238 89 344 minecraft:mushroom_stem
setblock 238 89 345 minecraft:moss_block
setblock 238 89 349 minecraft:mushroom_stem
setblock 238 89 350 minecraft:moss_block
setblock 239 89 323 minecraft:mushroom_stem
fill 239 89 324 239 92 324 minecraft:moss_block
setblock 239 89 328 minecraft:mushroom_stem
fill 239 89 329 239 92 329 minecraft:moss_block
setblock 239 89 340 minecraft:red_mushroom_block
fill 240 89 323 243 89 323 minecraft:moss_block
setblock 240 89 326 minecraft:moss_block
fill 240 89 363 243 89 363 minecraft:moss_block
setblock 241 89 326 minecraft:mushroom_stem
setblock 242 89 325 minecraft:mushroom_stem
setblock 242 89 326 minecraft:moss_block
fill 242 89 339 242 90 339 minecraft:mushroom_stem
fill 242 89 341 242 90 341 minecraft:mushroom_stem
setblock 243 89 324 minecraft:mushroom_stem
fill 243 89 325 243 91 325 minecraft:moss_block
fill 243 89 340 243 91 340 minecraft:mushroom_stem
setblock 244 89 323 minecraft:mushroom_stem
fill 244 89 324 244 91 324 minecraft:moss_block
fill 245 89 323 248 89 323 minecraft:moss_block
fill 246 89 352 246 97 352 minecraft:dirt
fill 246 89 364 248 147 364 minecraft:brown_terracotta
setblock 247 89 325 minecraft:mushroom_stem
setblock 248 89 324 minecraft:mushroom_stem
setblock 249 89 323 minecraft:mushroom_stem
fill 249 89 324 252 89 324 minecraft:moss_block
setblock 249 89 364 minecraft:shroomlight
fill 250 89 323 253 89 323 minecraft:moss_block
fill 250 89 364 260 98 364 minecraft:brown_terracotta
setblock 253 89 324 minecraft:mushroom_stem
setblock 254 89 323 minecraft:mushroom_stem
fill 254 89 324 255 91 324 minecraft:moss_block
fill 254 89 360 254 95 360 minecraft:iron_block
setblock 254 89 363 minecraft:mushroom_stem
fill 255 89 323 258 89 323 minecraft:moss_block
fill 255 89 363 258 89 363 minecraft:moss_block
setblock 256 89 325 minecraft:moss_block
setblock 257 89 325 minecraft:mushroom_stem
fill 257 89 362 259 89 362 minecraft:moss_block
setblock 258 89 324 minecraft:mushroom_stem
fill 258 89 325 258 90 325 minecraft:moss_block
setblock 259 89 323 minecraft:mushroom_stem
fill 259 89 324 259 92 324 minecraft:moss_block
setblock 259 89 363 minecraft:mushroom_stem
fill 260 89 323 260 92 323 minecraft:moss_block
setblock 260 89 362 minecraft:mushroom_stem
fill 260 89 363 260 92 363 minecraft:moss_block
fill 261 89 362 261 91 362 minecraft:moss_block
setblock 262 89 325 minecraft:mushroom_stem
setblock 263 89 324 minecraft:mushroom_stem
setblock 263 89 325 minecraft:moss_block
setblock 264 89 323 minecraft:mushroom_stem
setblock 264 89 324 minecraft:moss_block
setblock 264 89 363 minecraft:mushroom_stem
fill 265 89 323 265 90 323 minecraft:moss_block
fill 265 89 363 265 90 363 minecraft:moss_block
fill 266 89 351 266 99 351 minecraft:dirt
fill 266 89 364 266 104 364 minecraft:brown_terracotta
fill 268 89 340 271 89 340 minecraft:mushroom_stem
fill 269 89 339 270 89 339 minecraft:mushroom_stem
fill 269 89 341 270 89 341 minecraft:mushroom_stem
setblock 272 89 340 minecraft:red_mushroom_block
fill 274 89 347 274 96 348 minecraft:mushroom_stem
setblock 274 89 349 minecraft:moss_block
setblock 274 89 363 minecraft:red_mushroom_block
setblock 275 89 347 minecraft:mushroom_stem
fill 275 89 348 275 92 348 minecraft:moss_block
setblock 275 89 352 minecraft:mushroom_stem
fill 275 89 353 275 91 354 minecraft:moss_block
setblock 276 89 326 minecraft:mushroom_stem
fill 276 89 327 276 92 327 minecraft:moss_block
fill 276 89 329 276 89 330 minecraft:moss_block
setblock 276 89 331 minecraft:mushroom_stem
fill 276 89 332 276 90 334 minecraft:moss_block
setblock 276 89 341 minecraft:mushroom_stem
fill 276 89 342 276 92 342 minecraft:moss_block
setblock 276 89 346 minecraft:mushroom_stem
fill 276 89 347 276 92 347 minecraft:moss_block
setblock 276 89 351 minecraft:mushroom_stem
fill 276 89 352 276 92 352 minecraft:moss_block
setblock 276 89 356 minecraft:mushroom_stem
fill 276 89 357 276 92 357 minecraft:moss_block
fill 236 90 323 236 90 324 minecraft:moss_block
setblock 236 90 325 minecraft:mushroom_stem
fill 236 90 326 236 90 329 minecraft:moss_block
setblock 236 90 330 minecraft:mushroom_stem
fill 236 90 331 236 93 331 minecraft:moss_block
setblock 236 90 334 minecraft:moss_block
setblock 236 90 335 minecraft:mushroom_stem
fill 236 90 336 236 93 336 minecraft:moss_block
setblock 236 90 340 minecraft:mushroom_stem
fill 236 90 341 236 93 341 minecraft:moss_block
setblock 236 90 345 minecraft:mushroom_stem
fill 236 90 346 236 93 346 minecraft:moss_block
setblock 236 90 350 minecraft:mushroom_stem
fill 236 90 351 236 93 351 minecraft:moss_block
setblock 236 90 355 minecraft:mushroom_stem
setblock 236 90 363 minecraft:red_mushroom_block
setblock 237 90 323 minecraft:moss_block
setblock 237 90 324 minecraft:mushroom_stem
fill 237 90 325 237 93 325 minecraft:moss_block
setblock 237 90 329 minecraft:mushroom_stem
fill 237 90 330 237 93 330 minecraft:moss_block
setblock 237 90 334 minecraft:mushroom_stem
fill 237 90 335 237 93 335 minecraft:moss_block
setblock 237 90 344 minecraft:mushroom_stem
fill 237 90 345 237 92 345 minecraft:moss_block
setblock 237 90 349 minecraft:mushroom_stem
fill 237 90 350 237 93 350 minecraft:moss_block
setblock 237 90 353 minecraft:moss_block
setblock 238 90 323 minecraft:mushroom_stem
fill 238 90 324 238 93 324 minecraft:moss_block
setblock 238 90 327 minecraft:moss_block
setblock 238 90 328 minecraft:mushroom_stem
fill 238 90 329 238 93 329 minecraft:moss_block
setblock 238 90 333 minecraft:mushroom_stem
fill 238 90 334 238 93 334 minecraft:moss_block
setblock 238 90 348 minecraft:mushroom_stem
setblock 238 90 349 minecraft:moss_block
fill 239 90 322 247 112 322 minecraft:brown_terracotta
fill 239 90 323 242 90 323 minecraft:moss_block
setblock 239 90 327 minecraft:mushroom_stem
fill 239 90 328 239 92 328 minecraft:moss_block
setblock 239 90 331 minecraft:moss_block
setblock 240 90 340 minecraft:red_mushroom_block
setblock 241 90 325 minecraft:mushroom_stem
setblock 241 90 340 minecraft:mushroom_stem
setblock 242 90 324 minecraft:mushroom_stem
fill 242 90 325 242 91 325 minecraft:moss_block
setblock 243 90 323 minecraft:mushroom_stem
fill 243 90 324 243 92 324 minecraft:moss_block
fill 243 90 339 244 90 339 minecraft:mushroom_stem
fill 243 90 341 244 90 341 minecraft:mushroom_stem
fill 244 90 323 247 90 323 minecraft:moss_block
fill 244 90 340 245 91 340 minecraft:mushroom_stem
setblock 247 90 324 minecraft:mushroom_stem
setblock 248 90 322 minecraft:red_mushroom_block
setblock 248 90 323 minecraft:mushroom_stem
fill 249 90 323 252 90 323 minecraft:moss_block
fill 249 90 364 249 147 364 minecraft:brown_terracotta
setblock 253 90 323 minecraft:mushroom_stem
setblock 253 90 324 minecraft:moss_block
fill 254 90 323 257 90 323 minecraft:moss_block
fill 255 90 363 257 90 363 minecraft:moss_block
setblock 257 90 324 minecraft:mushroom_stem
setblock 257 90 325 minecraft:moss_block
setblock 258 90 323 minecraft:mushroom_stem
fill 258 90 324 258 93 324 minecraft:moss_block
setblock 258 90 362 minecraft:moss_block
setblock 258 90 363 minecraft:mushroom_stem
fill 259 90 323 259 93 323 minecraft:moss_block
fill 259 90 327 259 97 327 minecraft:dirt
setblock 259 90 362 minecraft:mushroom_stem
fill 259 90 363 259 93 363 minecraft:moss_block
fill 260 90 362 260 93 362 minecraft:moss_block
setblock 261 90 325 minecraft:mushroom_stem
setblock 262 90 324 minecraft:mushroom_stem
setblock 263 90 323 minecraft:mushroom_stem
setblock 263 90 324 minecraft:moss_block
setblock 263 90 363 minecraft:mushroom_stem
fill 264 90 323 264 91 323 minecraft:moss_block
fill 264 90 363 264 91 363 minecraft:moss_block
fill 266 90 340 270 90 340 minecraft:mushroom_stem
fill 267 90 339 269 90 339 minecraft:mushroom_stem
fill 267 90 341 269 90 341 minecraft:mushroom_stem
setblock 271 90 340 minecraft:red_mushroom_block
setblock 275 90 346 minecraft:mushroom_stem
fill 275 90 347 275 93 347 minecraft:moss_block
setblock 275 90 351 minecraft:mushroom_stem
fill 275 90 352 275 93 352 minecraft:moss_block
setblock 276 90 323 minecraft:red_mushroom_block
setblock 276 90 325 minecraft:mushroom_stem
fill 276 90 326 276 93 326 minecraft:moss_block
setblock 276 90 329 minecraft:moss_block
setblock 276 90 330 minecraft:mushroom_stem
fill 276 90 331 276 93 331 minecraft:moss_block
setblock 276 90 335 minecraft:mushroom_stem
fill 276 90 336 276 93 336 minecraft:moss_block
setblock 276 90 340 minecraft:mushroom_stem
fill 276 90 341 276 93 341 minecraft:moss_block
setblock 276 90 345 minecraft:mushroom_stem
fill 276 90 346 276 93 346 minecraft:moss_block
setblock 276 90 350 minecraft:mushroom_stem
fill 276 90 351 276 93 351 minecraft:moss_block
setblock 276 90 355 minecraft:mushroom_stem
fill 276 90 356 276 93 356 minecraft:moss_block
setblock 277 90 331 minecraft:red_mushroom_block
fill 277 90 332 277 124 333 minecraft:brown_terracotta
setblock 236 91 323 minecraft:moss_block
setblock 236 91 324 minecraft:mushroom_stem
fill 236 91 325 236 91 328 minecraft:moss_block
setblock 236 91 329 minecraft:mushroom_stem
fill 236 91 330 236 94 330 minecraft:moss_block
setblock 236 91 334 minecraft:mushroom_stem
fill 236 91 335 236 94 335 minecraft:moss_block
setblock 236 91 339 minecraft:mushroom_stem
fill 236 91 340 236 94 340 minecraft:moss_block
setblock 236 91 344 minecraft:mushroom_stem
fill 236 91 345 236 94 345 minecraft:moss_block
setblock 236 91 349 minecraft:mushroom_stem
fill 236 91 350 236 94 350 minecraft:moss_block
setblock 236 91 354 minecraft:mushroom_stem
fill 236 91 355 236 94 355 minecraft:moss_block
setblock 237 91 323 minecraft:mushroom_stem
fill 237 91 324 237 94 324 minecraft:moss_block
setblock 237 91 328 minecraft:mushroom_stem
fill 237 91 329 237 94 329 minecraft:moss_block
setblock 237 91 333 minecraft:mushroom_stem
fill 237 91 334 237 94 334 minecraft:moss_block
setblock 237 91 338 minecraft:mushroom_stem
setblock 237 91 343 minecraft:mushroom_stem
setblock 237 91 344 minecraft:moss_block
setblock 237 91 348 minecraft:mushroom_stem
fill 237 91 349 237 94 349 minecraft:moss_block
setblock 237 91 353 minecraft:mushroom_stem
fill 237 91 364 242 103 364 minecraft:brown_terracotta
fill 238 91 323 241 91 323 minecraft:moss_block
setblock 238 91 327 minecraft:mushroom_stem
fill 238 91 328 238 94 328 minecraft:moss_block
setblock 238 91 332 minecraft:mushroom_stem
fill 238 91 333 238 94 333 minecraft:moss_block
setblock 239 91 331 minecraft:mushroom_stem
setblock 240 91 325 minecraft:mushroom_stem
setblock 241 91 324 minecraft:mushroom_stem
setblock 241 91 325 minecraft:moss_block
setblock 242 91 323 minecraft:mushroom_stem
fill 242 91 324 242 93 324 minecraft:moss_block
setblock 242 91 340 minecraft:red_mushroom_block
setblock 242 91 363 minecraft:red_mushroom_block
fill 243 91 323 246 91 323 minecraft:moss_block
setblock 243 91 364 minecraft:red_mushroom_block
fill 244 91 339 246 91 339 minecraft:mushroom_stem
fill 244 91 341 246 91 341 minecraft:mushroom_stem
fill 244 91 364 244 119 364 minecraft:brown_terracotta
fill 245 91 352 245 97 352 minecraft:dirt
fill 246 91 340 247 93 340 minecraft:mushroom_stem
fill 246 91 353 247 97 353 minecraft:dirt
setblock 247 91 323 minecraft:mushroom_stem
fill 248 91 322 248 135 322 minecraft:brown_terracotta
fill 248 91 323 251 91 323 minecraft:moss_block
setblock 252 91 323 minecraft:mushroom_stem
fill 253 91 323 256 91 323 minecraft:moss_block
fill 255 91 363 256 91 363 minecraft:moss_block
setblock 256 91 324 minecraft:mushroom_stem
setblock 257 91 323 minecraft:mushroom_stem
fill 257 91 324 257 94 324 minecraft:moss_block
setblock 257 91 363 minecraft:mushroom_stem
fill 258 91 323 258 94 323 minecraft:moss_block
setblock 258 91 362 minecraft:mushroom_stem
fill 258 91 363 258 94 363 minecraft:moss_block
fill 259 91 362 259 94 362 minecraft:moss_block
setblock 261 91 324 minecraft:mushroom_stem
setblock 262 91 323 minecraft:mushroom_stem
setblock 262 91 324 minecraft:moss_block
setblock 262 91 363 minecraft:mushroom_stem
setblock 263 91 323 minecraft:moss_block
fill 263 91 363 263 92 363 minecraft:moss_block
fill 264 91 340 268 91 340 minecraft:mushroom_stem
fill 265 91 339 267 91 339 minecraft:mushroom_stem
fill 265 91 341 267 91 341 minecraft:mushroom_stem
fill 265 91 351 265 99 351 minecraft:dirt
fill 266 91 350 267 99 350 minecraft:dirt
fill 266 91 352 266 99 352 minecraft:dirt
fill 267 91 351 267 99 351 minecraft:dirt
setblock 267 91 363 minecraft:red_mushroom_block
fill 268 91 364 271 131 364 minecraft:brown_terracotta
setblock 269 91 340 minecraft:red_mushroom_block
setblock 270 91 323 minecraft:red_mushroom_block
setblock 272 91 364 minecraft:shroomlight
fill 273 91 364 277 101 364 minecraft:brown_terracotta
setblock 275 91 345 minecraft:mushroom_stem
fill 275 91 346 275 94 346 minecraft:moss_block
setblock 275 91 350 minecraft:mushroom_stem
fill 275 91 351 275 94 351 minecraft:moss_block
setblock 276 91 325 minecraft:moss_block
setblock 276 91 329 minecraft:mushroom_stem
fill 276 91 330 276 94 330 minecraft:moss_block
fill 276 91 332 276 91 333 minecraft:moss_block
setblock 276 91 334 minecraft:mushroom_stem
fill 276 91 335 276 94 335 minecraft:moss_block
fill 276 91 337 276 91 338 minecraft:moss_block
setblock 276 91 339 minecraft:mushroom_stem
fill 276 91 340 276 94 340 minecraft:moss_block
setblock 276 91 344 minecraft:mushroom_stem
fill 276 91 345 276 94 345 minecraft:moss_block
setblock 276 91 349 minecraft:mushroom_stem
fill 276 91 350 276 94 350 minecraft:moss_block
setblock 276 91 354 minecraft:mushroom_stem
fill 276 91 355 276 94 355 minecraft:moss_block
setblock 276 91 361 minecraft:red_mushroom_block
fill 277 91 331 277 101 331 minecraft:brown_terracotta
fill 277 91 359 277 145 359 minecraft:brown_terracotta
setblock 277 91 360 minecraft:shroomlight
fill 277 91 361 277 116 363 minecraft:brown_terracotta
setblock 236 92 323 minecraft:mushroom_stem
fill 236 92 324 236 92 327 minecraft:moss_block
setblock 236 92 328 minecraft:mushroom_stem
fill 236 92 329 236 95 329 minecraft:moss_block
setblock 236 92 333 minecraft:mushroom_stem
fill 236 92 334 236 95 334 minecraft:moss_block
setblock 236 92 338 minecraft:mushroom_stem
fill 236 92 339 236 95 339 minecraft:moss_block
setblock 236 92 343 minecraft:mushroom_stem
fill 236 92 344 236 95 344 minecraft:moss_block
setblock 236 92 348 minecraft:mushroom_stem
fill 236 92 349 236 95 349 minecraft:moss_block
setblock 236 92 353 minecraft:mushroom_stem
fill 236 92 354 236 95 354 minecraft:moss_block
setblock 236 92 356 minecraft:red_mushroom_block
fill 237 92 323 240 92 323 minecraft:moss_block
setblock 237 92 326 minecraft:moss_block
setblock 237 92 327 minecraft:mushroom_stem
fill 237 92 328 237 95 328 minecraft:moss_block
setblock 237 92 332 minecraft:mushroom_stem
fill 237 92 333 237 95 333 minecraft:moss_block
setblock 237 92 337 minecraft:mushroom_stem
fill 237 92 338 237 95 338 minecraft:moss_block
setblock 237 92 347 minecraft:mushroom_stem
fill 237 92 348 237 95 348 minecraft:moss_block
setblock 237 92 352 minecraft:mushroom_stem
fill 237 92 353 237 95 353 minecraft:moss_block
setblock 238 92 326 minecraft:mushroom_stem
fill 238 92 327 238 95 327 minecraft:moss_block
setblock 238 92 331 minecraft:mushroom_stem
fill 238 92 332 239 94 332 minecraft:moss_block
setblock 238 92 335 minecraft:moss_block
setblock 239 92 330 minecraft:mushroom_stem
fill 239 92 331 239 95 331 minecraft:moss_block
setblock 240 92 324 minecraft:mushroom_stem
setblock 240 92 325 minecraft:moss_block
setblock 241 92 323 minecraft:mushroom_stem
fill 241 92 324 241 94 324 minecraft:moss_block
fill 242 92 323 245 92 323 minecraft:moss_block
fill 243 92 340 244 92 340 minecraft:red_mushroom_block
fill 243 92 364 243 147 364 minecraft:brown_terracotta
setblock 245 92 340 minecraft:mushroom_stem
fill 245 92 353 245 97 353 minecraft:dirt
setblock 246 92 323 minecraft:mushroom_stem
fill 246 92 339 248 92 339 minecraft:mushroom_stem
fill 246 92 341 248 92 341 minecraft:mushroom_stem
fill 248 92 340 249 94 340 minecraft:mushroom_stem
fill 248 92 353 248 97 353 minecraft:dirt
setblock 248 92 363 minecraft:red_mushroom_block
fill 252 92 323 255 92 323 minecraft:moss_block
setblock 255 92 324 minecraft:mushroom_stem
setblock 255 92 363 minecraft:moss_block
setblock 256 92 323 minecraft:mushroom_stem
fill 256 92 324 256 94 324 minecraft:moss_block
setblock 256 92 363 minecraft:mushroom_stem
fill 257 92 323 257 95 323 minecraft:moss_block
fill 257 92 363 257 95 363 minecraft:moss_block
fill 258 92 362 258 95 362 minecraft:moss_block
setblock 260 92 324 minecraft:mushroom_stem
setblock 261 92 323 minecraft:mushroom_stem
setblock 261 92 363 minecraft:mushroom_stem
setblock 262 92 323 minecraft:moss_block
fill 262 92 340 266 92 340 minecraft:mushroom_stem
fill 262 92 363 262 95 363 minecraft:moss_block
fill 263 92 339 265 92 339 minecraft:mushroom_stem
fill 263 92 341 265 92 341 minecraft:mushroom_stem
setblock 264 92 323 minecraft:red_mushroom_block
fill 265 92 350 265 99 350 minecraft:dirt
fill 265 92 352 265 99 352 minecraft:dirt
fill 267 92 340 268 92 340 minecraft:red_mushroom_block
fill 267 92 352 267 99 352 minecraft:dirt
fill 272 92 364 272 147 364 minecraft:brown_terracotta
setblock 273 92 363 minecraft:red_mushroom_block
fill 275 92 345 275 95 345 minecraft:moss_block
setblock 275 92 349 minecraft:mushroom_stem
fill 275 92 350 275 95 350 minecraft:moss_block
setblock 275 92 353 minecraft:moss_block
setblock 275 92 354 minecraft:mushroom_stem
fill 275 92 355 275 95 355 minecraft:moss_block
setblock 276 92 328 minecraft:mushroom_stem
fill 276 92 329 276 95 329 minecraft:moss_block
setblock 276 92 332 minecraft:moss_block
setblock 276 92 333 minecraft:mushroom_stem
fill 276 92 334 276 95 334 minecraft:moss_block
setblock 276 92 337 minecraft:moss_block
setblock 276 92 338 minecraft:mushroom_stem
fill 276 92 339 276 95 339 minecraft:moss_block
setblock 276 92 343 minecraft:mushroom_stem
fill 276 92 344 276 95 344 minecraft:moss_block
setblock 276 92 348 minecraft:mushroom_stem
fill 276 92 349 276 95 349 minecraft:moss_block
setblock 276 92 353 minecraft:mushroom_stem
fill 276 92 354 276 95 354 minecraft:moss_block
fill 277 92 360 277 147 360 minecraft:brown_terracotta
fill 236 93 323 236 93 326 minecraft:moss_block
setblock 236 93 327 minecraft:mushroom_stem
fill 236 93 328 236 96 328 minecraft:moss_block
setblock 236 93 332 minecraft:mushroom_stem
fill 236 93 333 236 96 333 minecraft:moss_block
setblock 236 93 337 minecraft:mushroom_stem
fill 236 93 338 236 96 338 minecraft:moss_block
setblock 236 93 342 minecraft:mushroom_stem
fill 236 93 343 236 96 343 minecraft:moss_block
setblock 236 93 347 minecraft:mushroom_stem
fill 236 93 348 236 96 348 minecraft:moss_block
setblock 236 93 352 minecraft:mushroom_stem
fill 236 93 353 236 96 353 minecraft:moss_block
setblock 236 93 356 minecraft:moss_block
setblock 236 93 362 minecraft:red_mushroom_block
fill 237 93 323 239 93 323 minecraft:moss_block
setblock 237 93 326 minecraft:mushroom_stem
fill 237 93 327 237 96 327 minecraft:moss_block
setblock 237 93 331 minecraft:mushroom_stem
fill 237 93 332 237 96 332 minecraft:moss_block
setblock 237 93 336 minecraft:mushroom_stem
fill 237 93 337 237 96 337 minecraft:moss_block
fill 237 93 339 237 94 339 minecraft:moss_block
setblock 237 93 346 minecraft:mushroom_stem
fill 237 93 347 237 94 347 minecraft:moss_block
setblock 237 93 351 minecraft:mushroom_stem
fill 237 93 352 237 96 352 minecraft:moss_block
fill 237 93 354 237 94 354 minecraft:moss_block
setblock 238 93 325 minecraft:light[level=15]
fill 238 93 326 238 96 326 minecraft:moss_block
setblock 238 93 330 minecraft:mushroom_stem
fill 238 93 331 238 96 331 minecraft:moss_block
setblock 238 93 335 minecraft:mushroom_stem
fill 238 93 336 238 96 336 minecraft:moss_block
setblock 238 93 339 minecraft:light[level=12]
setblock 238 93 341 minecraft:light[level=15]
setblock 238 93 346 minecraft:light[level=12]
setblock 238 93 349 minecraft:light[level=15]
setblock 238 93 353 minecraft:light[level=12]
setblock 238 93 357 minecraft:light[level=15]
setblock 238 93 360 minecraft:light[level=12]
setblock 239 93 324 minecraft:mushroom_stem
setblock 239 93 329 minecraft:mushroom_stem
fill 239 93 330 239 96 330 minecraft:moss_block
setblock 239 93 333 minecraft:moss_block
fill 239 93 334 242 94 335 minecraft:dirt
setblock 240 93 323 minecraft:mushroom_stem
fill 240 93 324 240 96 324 minecraft:moss_block
fill 240 93 331 242 94 333 minecraft:dirt
fill 241 93 323 244 93 323 minecraft:moss_block
fill 244 93 352 244 97 352 minecraft:dirt
setblock 245 93 323 minecraft:mushroom_stem
setblock 245 93 325 minecraft:light[level=12]
setblock 245 93 332 minecraft:light[level=12]
setblock 245 93 339 minecraft:light[level=12]
setblock 245 93 340 minecraft:red_mushroom_block
setblock 245 93 346 minecraft:light[level=12]
setblock 245 93 360 minecraft:light[level=12]
setblock 246 93 325 minecraft:light[level=15]
setblock 246 93 333 minecraft:light[level=15]
setblock 246 93 341 minecraft:light[level=15]
setblock 246 93 349 minecraft:light[level=15]
fill 246 93 354 248 97 354 minecraft:dirt
setblock 246 93 357 minecraft:light[level=15]
fill 247 93 339 251 93 339 minecraft:mushroom_stem
fill 247 93 341 251 93 341 minecraft:mushroom_stem
fill 249 93 353 249 97 353 minecraft:dirt
fill 250 93 340 254 94 340 minecraft:mushroom_stem
fill 252 93 323 254 93 323 minecraft:moss_block
setblock 252 93 325 minecraft:light[level=12]
setblock 252 93 332 minecraft:light[level=12]
setblock 252 93 339 minecraft:light[level=12]
setblock 252 93 346 minecraft:light[level=12]
setblock 252 93 353 minecraft:light[level=12]
setblock 252 93 360 minecraft:light[level=12]
setblock 254 93 325 minecraft:light[level=15]
setblock 254 93 333 minecraft:light[level=15]
setblock 254 93 341 minecraft:light[level=15]
setblock 254 93 349 minecraft:light[level=15]
setblock 254 93 357 minecraft:light[level=15]
setblock 254 93 363 minecraft:moss_block
setblock 255 93 323 minecraft:mushroom_stem
setblock 255 93 363 minecraft:mushroom_stem
fill 256 93 323 256 96 323 minecraft:moss_block
fill 256 93 363 256 96 363 minecraft:moss_block
fill 257 93 340 265 93 340 minecraft:mushroom_stem
fill 257 93 362 257 96 362 minecraft:moss_block
setblock 259 93 324 minecraft:mushroom_stem
setblock 259 93 325 minecraft:light[level=12]
setblock 259 93 332 minecraft:light[level=12]
setblock 259 93 339 minecraft:light[level=12]
setblock 259 93 346 minecraft:light[level=12]
setblock 259 93 353 minecraft:light[level=12]
setblock 259 93 360 minecraft:light[level=12]
setblock 260 93 323 minecraft:mushroom_stem
fill 260 93 339 264 93 339 minecraft:mushroom_stem
fill 260 93 341 264 93 341 minecraft:mushroom_stem
setblock 260 93 363 minecraft:mushroom_stem
setblock 261 93 323 minecraft:moss_block
fill 261 93 363 261 96 363 minecraft:moss_block
setblock 262 93 325 minecraft:light[level=15]
setblock 262 93 333 minecraft:light[level=15]
setblock 262 93 349 minecraft:light[level=15]
setblock 262 93 357 minecraft:light[level=15]
fill 264 93 350 264 99 351 minecraft:dirt
fill 265 93 349 267 99 349 minecraft:dirt
setblock 266 93 325 minecraft:light[level=12]
setblock 266 93 332 minecraft:light[level=12]
setblock 266 93 339 minecraft:light[level=12]
setblock 266 93 340 minecraft:red_mushroom_block
setblock 266 93 346 minecraft:light[level=12]
fill 266 93 353 266 99 353 minecraft:dirt
setblock 266 93 360 minecraft:light[level=12]
fill 268 93 350 268 99 352 minecraft:dirt
setblock 270 93 325 minecraft:light[level=15]
setblock 270 93 333 minecraft:light[level=15]
setblock 270 93 341 minecraft:light[level=15]
setblock 270 93 349 minecraft:light[level=15]
setblock 270 93 357 minecraft:light[level=15]
setblock 272 93 329 minecraft:shroomlight
setblock 273 93 325 minecraft:light[level=12]
setblock 273 93 332 minecraft:light[level=12]
setblock 273 93 339 minecraft:light[level=12]
setblock 273 93 353 minecraft:light[level=12]
setblock 273 93 360 minecraft:light[level=12]
fill 274 93 350 274 95 351 minecraft:moss_block
fill 275 93 330 275 93 332 minecraft:moss_block
setblock 275 93 333 minecraft:mushroom_stem
fill 275 93 334 275 96 334 minecraft:moss_block
setblock 275 93 348 minecraft:mushroom_stem
fill 275 93 349 275 96 349 minecraft:moss_block
setblock 275 93 353 minecraft:mushroom_stem
fill 275 93 354 275 96 354 minecraft:moss_block
setblock 276 93 324 minecraft:red_mushroom_block
setblock 276 93 327 minecraft:mushroom_stem
fill 276 93 328 276 96 328 minecraft:moss_block
setblock 276 93 332 minecraft:mushroom_stem
fill 276 93 333 276 96 333 minecraft:moss_block
setblock 276 93 337 minecraft:mushroom_stem
fill 276 93 338 276 96 338 minecraft:moss_block
setblock 276 93 342 minecraft:mushroom_stem
fill 276 93 343 276 96 343 minecraft:moss_block
setblock 276 93 347 minecraft:mushroom_stem
fill 276 93 348 276 96 348 minecraft:moss_block
setblock 276 93 352 minecraft:mushroom_stem
fill 276 93 353 276 96 353 minecraft:moss_block
setblock 276 93 357 minecraft:mushroom_stem
fill 276 93 358 276 96 358 minecraft:moss_block
fill 236 94 323 236 94 325 minecraft:moss_block
setblock 236 94 326 minecraft:mushroom_stem
fill 236 94 327 236 97 327 minecraft:moss_block
setblock 236 94 331 minecraft:mushroom_stem
fill 236 94 332 236 97 332 minecraft:moss_block
setblock 236 94 336 minecraft:mushroom_stem
fill 236 94 337 236 97 337 minecraft:moss_block
setblock 236 94 341 minecraft:mushroom_stem
fill 236 94 342 236 97 342 minecraft:moss_block
setblock 236 94 346 minecraft:mushroom_stem
fill 236 94 347 236 97 347 minecraft:moss_block
setblock 236 94 351 minecraft:mushroom_stem
fill 236 94 352 236 97 352 minecraft:moss_block
setblock 236 94 356 minecraft:mushroom_stem
fill 236 94 357 236 96 358 minecraft:moss_block
fill 237 94 323 238 94 323 minecraft:moss_block
setblock 237 94 325 minecraft:mushroom_stem
fill 237 94 326 237 97 326 minecraft:moss_block
setblock 237 94 330 minecraft:mushroom_stem
fill 237 94 331 237 97 331 minecraft:moss_block
setblock 237 94 335 minecraft:mushroom_stem
fill 237 94 336 237 97 336 minecraft:moss_block
setblock 237 94 340 minecraft:mushroom_stem
setblock 237 94 350 minecraft:mushroom_stem
fill 237 94 351 237 97 351 minecraft:moss_block
setblock 237 94 355 minecraft:mushroom_stem
setblock 238 94 324 minecraft:mushroom_stem
setblock 238 94 329 minecraft:mushroom_stem
fill 238 94 330 238 97 330 minecraft:moss_block
setblock 238 94 334 minecraft:mushroom_stem
fill 238 94 335 238 97 335 minecraft:moss_block
fill 238 94 337 238 95 337 minecraft:moss_block
setblock 239 94 323 minecraft:mushroom_stem
fill 239 94 324 239 97 324 minecraft:moss_block
fill 239 94 329 239 97 329 minecraft:moss_block
setblock 239 94 333 minecraft:mushroom_stem
fill 240 94 323 243 94 323 minecraft:moss_block
setblock 241 94 363 minecraft:red_mushroom_block
setblock 244 94 323 minecraft:mushroom_stem
fill 244 94 351 244 97 351 minecraft:dirt
fill 244 94 353 244 97 353 minecraft:dirt
fill 245 94 354 245 97 354 minecraft:dirt
fill 246 94 323 246 95 323 minecraft:red_mushroom_block
setblock 247 94 340 minecraft:red_mushroom_block
fill 250 94 339 261 94 339 minecraft:mushroom_stem
fill 250 94 341 261 94 341 minecraft:mushroom_stem
fill 252 94 323 253 94 323 minecraft:moss_block
setblock 253 94 363 minecraft:moss_block
setblock 254 94 323 minecraft:mushroom_stem
setblock 254 94 363 minecraft:mushroom_stem
fill 255 94 323 255 97 323 minecraft:moss_block
fill 255 94 340 263 94 340 minecraft:mushroom_stem
fill 255 94 363 255 97 363 minecraft:moss_block
fill 256 94 362 256 97 362 minecraft:moss_block
fill 258 94 327 258 97 327 minecraft:dirt
setblock 259 94 323 minecraft:mushroom_stem
fill 259 94 326 259 97 326 minecraft:dirt
fill 259 94 328 259 97 328 minecraft:dirt
setblock 259 94 363 minecraft:mushroom_stem
fill 260 94 323 260 96 323 minecraft:moss_block
fill 260 94 327 260 97 327 minecraft:dirt
setblock 260 94 362 minecraft:mushroom_stem
fill 260 94 363 260 97 363 minecraft:moss_block
setblock 264 94 340 minecraft:red_mushroom_block
fill 264 94 352 264 99 352 minecraft:dirt
fill 265 94 353 265 99 353 minecraft:dirt
fill 267 94 353 267 99 353 minecraft:dirt
fill 268 94 349 268 99 349 minecraft:dirt
setblock 271 94 323 minecraft:red_mushroom_block
fill 272 94 329 272 98 329 minecraft:mushroom_stem
setblock 274 94 352 minecraft:moss_block
setblock 274 94 353 minecraft:mushroom_stem
fill 275 94 329 275 94 331 minecraft:moss_block
setblock 275 94 332 minecraft:mushroom_stem
fill 275 94 333 275 97 333 minecraft:moss_block
fill 275 94 335 275 94 336 minecraft:moss_block
setblock 275 94 337 minecraft:mushroom_stem
setblock 275 94 347 minecraft:mushroom_stem
fill 275 94 348 275 97 348 minecraft:moss_block
setblock 275 94 352 minecraft:mushroom_stem
fill 275 94 353 275 97 353 minecraft:moss_block
setblock 275 94 356 minecraft:moss_block
setblock 276 94 325 minecraft:moss_block
setblock 276 94 326 minecraft:mushroom_stem
fill 276 94 327 276 97 327 minecraft:moss_block
setblock 276 94 331 minecraft:mushroom_stem
fill 276 94 332 276 97 332 minecraft:moss_block
setblock 276 94 336 minecraft:mushroom_stem
fill 276 94 337 276 97 337 minecraft:moss_block
setblock 276 94 341 minecraft:mushroom_stem
fill 276 94 342 276 97 342 minecraft:moss_block
setblock 276 94 346 minecraft:mushroom_stem
fill 276 94 347 276 97 347 minecraft:moss_block
setblock 276 94 351 minecraft:mushroom_stem
fill 276 94 352 276 97 352 minecraft:moss_block
setblock 276 94 356 minecraft:mushroom_stem
fill 276 94 357 276 97 357 minecraft:moss_block
fill 276 94 359 276 95 359 minecraft:moss_block
setblock 276 94 362 minecraft:red_mushroom_block
fill 235 95 355 235 144 355 minecraft:brown_terracotta
setblock 235 95 356 minecraft:red_mushroom_block
fill 235 95 357 235 143 358 minecraft:brown_terracotta
fill 236 95 323 236 95 324 minecraft:moss_block
setblock 236 95 325 minecraft:mushroom_stem
fill 236 95 326 236 98 326 minecraft:moss_block
setblock 236 95 330 minecraft:mushroom_stem
fill 236 95 331 236 98 331 minecraft:moss_block
setblock 236 95 335 minecraft:mushroom_stem
fill 236 95 336 236 98 336 minecraft:moss_block
setblock 236 95 340 minecraft:mushroom_stem
fill 236 95 341 237 97 341 minecraft:moss_block
setblock 236 95 345 minecraft:mushroom_stem
fill 236 95 346 236 98 346 minecraft:moss_block
setblock 236 95 350 minecraft:mushroom_stem
fill 236 95 351 236 98 351 minecraft:moss_block
setblock 236 95 355 minecraft:mushroom_stem
fill 236 95 356 237 97 356 minecraft:moss_block
setblock 236 95 359 minecraft:moss_block
setblock 237 95 323 minecraft:moss_block
setblock 237 95 324 minecraft:mushroom_stem
fill 237 95 325 237 98 325 minecraft:moss_block
setblock 237 95 329 minecraft:mushroom_stem
fill 237 95 330 237 98 330 minecraft:moss_block
setblock 237 95 334 minecraft:mushroom_stem
fill 237 95 335 237 98 335 minecraft:moss_block
setblock 237 95 339 minecraft:mushroom_stem
fill 237 95 340 237 98 340 minecraft:moss_block
setblock 237 95 349 minecraft:mushroom_stem
fill 237 95 350 237 98 350 minecraft:moss_block
setblock 237 95 354 minecraft:mushroom_stem
fill 237 95 355 237 98 355 minecraft:moss_block
setblock 238 95 323 minecraft:mushroom_stem
fill 238 95 324 238 98 324 minecraft:moss_block
setblock 238 95 328 minecraft:mushroom_stem
fill 238 95 329 238 98 329 minecraft:moss_block
setblock 238 95 332 minecraft:moss_block
setblock 238 95 333 minecraft:mushroom_stem
fill 238 95 334 239 97 334 minecraft:moss_block
fill 239 95 323 242 95 323 minecraft:moss_block
fill 239 95 332 240 95 332 minecraft:mushroom_stem
fill 239 95 333 239 98 333 minecraft:moss_block
fill 240 95 333 240 101 334 minecraft:mushroom_stem
fill 241 95 333 241 101 333 minecraft:mushroom_stem
setblock 243 95 323 minecraft:mushroom_stem
fill 243 95 352 243 97 352 minecraft:dirt
fill 244 95 354 244 97 354 minecraft:dirt
fill 245 95 355 248 97 355 minecraft:dirt
setblock 247 95 363 minecraft:red_mushroom_block
fill 249 95 340 251 95 340 minecraft:red_mushroom_block
fill 249 95 354 249 97 354 minecraft:dirt
fill 250 95 352 250 97 353 minecraft:dirt
setblock 252 95 323 minecraft:moss_block
fill 252 95 340 259 95 340 minecraft:mushroom_stem
setblock 252 95 363 minecraft:moss_block
setblock 253 95 323 minecraft:mushroom_stem
setblock 253 95 363 minecraft:mushroom_stem
fill 254 95 323 254 98 323 minecraft:moss_block
fill 254 95 363 254 98 363 minecraft:moss_block
fill 255 95 339 256 95 339 minecraft:mushroom_stem
fill 255 95 341 256 95 341 minecraft:mushroom_stem
fill 255 95 362 255 98 362 minecraft:moss_block
setblock 258 95 323 minecraft:mushroom_stem
fill 258 95 326 258 97 326 minecraft:dirt
fill 258 95 328 258 97 328 minecraft:dirt
setblock 258 95 363 minecraft:mushroom_stem
fill 259 95 323 259 98 323 minecraft:moss_block
setblock 259 95 362 minecraft:mushroom_stem
fill 259 95 363 259 98 363 minecraft:moss_block
fill 260 95 326 260 97 326 minecraft:dirt
fill 260 95 328 260 97 328 minecraft:dirt
fill 260 95 340 262 95 340 minecraft:red_mushroom_block
fill 260 95 362 260 98 362 minecraft:moss_block
fill 262 95 364 263 147 364 minecraft:brown_terracotta
fill 263 95 350 263 99 351 minecraft:dirt
fill 264 95 349 264 99 349 minecraft:dirt
fill 264 95 353 264 99 353 minecraft:dirt
setblock 264 95 364 minecraft:red_mushroom_block
setblock 265 95 323 minecraft:red_mushroom_block
fill 265 95 348 267 99 348 minecraft:dirt
fill 265 95 364 265 145 364 minecraft:brown_terracotta
fill 266 95 354 267 99 354 minecraft:dirt
setblock 266 95 363 minecraft:red_mushroom_block
fill 268 95 353 268 99 353 minecraft:dirt
fill 269 95 350 269 99 352 minecraft:dirt
fill 274 95 349 274 97 349 minecraft:moss_block
setblock 274 95 352 minecraft:mushroom_stem
fill 274 95 353 274 97 354 minecraft:moss_block
fill 275 95 328 275 95 330 minecraft:moss_block
setblock 275 95 331 minecraft:mushroom_stem
fill 275 95 332 275 98 332 minecraft:moss_block
setblock 275 95 335 minecraft:moss_block
setblock 275 95 336 minecraft:mushroom_stem
fill 275 95 337 275 95 340 minecraft:moss_block
setblock 275 95 341 minecraft:mushroom_stem
fill 275 95 342 275 96 344 minecraft:moss_block
setblock 275 95 346 minecraft:mushroom_stem
fill 275 95 347 275 98 347 minecraft:moss_block
setblock 275 95 351 minecraft:mushroom_stem
fill 275 95 352 275 98 352 minecraft:moss_block
setblock 275 95 356 minecraft:mushroom_stem
fill 275 95 357 275 98 357 minecraft:moss_block
setblock 276 95 325 minecraft:mushroom_stem
fill 276 95 326 276 98 326 minecraft:moss_block
setblock 276 95 330 minecraft:mushroom_stem
fill 276 95 331 276 98 331 minecraft:moss_block
setblock 276 95 335 minecraft:mushroom_stem
fill 276 95 336 276 98 336 minecraft:moss_block
setblock 276 95 340 minecraft:mushroom_stem
fill 276 95 341 276 98 341 minecraft:moss_block
setblock 276 95 345 minecraft:mushroom_stem
fill 276 95 346 276 98 346 minecraft:moss_block
setblock 276 95 350 minecraft:mushroom_stem
fill 276 95 351 276 98 351 minecraft:moss_block
setblock 276 95 355 minecraft:mushroom_stem
fill 276 95 356 276 98 356 minecraft:moss_block
setblock 276 95 360 minecraft:mushroom_stem
fill 235 96 356 235 147 356 minecraft:brown_terracotta
setblock 236 96 323 minecraft:moss_block
setblock 236 96 324 minecraft:mushroom_stem
fill 236 96 325 236 99 325 minecraft:moss_block
setblock 236 96 329 minecraft:mushroom_stem
fill 236 96 330 236 99 330 minecraft:moss_block
setblock 236 96 334 minecraft:mushroom_stem
fill 236 96 335 236 99 335 minecraft:moss_block
setblock 236 96 339 minecraft:mushroom_stem
fill 236 96 340 236 99 340 minecraft:moss_block
setblock 236 96 344 minecraft:mushroom_stem
fill 236 96 345 236 99 345 minecraft:moss_block
setblock 236 96 349 minecraft:mushroom_stem
fill 236 96 350 236 99 350 minecraft:moss_block
setblock 236 96 354 minecraft:mushroom_stem
fill 236 96 355 236 99 355 minecraft:moss_block
setblock 236 96 359 minecraft:mushroom_stem
fill 236 96 360 236 98 361 minecraft:moss_block
setblock 237 96 323 minecraft:mushroom_stem
fill 237 96 324 237 99 324 minecraft:moss_block
setblock 237 96 328 minecraft:mushroom_stem
fill 237 96 329 237 99 329 minecraft:moss_block
setblock 237 96 333 minecraft:mushroom_stem
fill 237 96 334 237 99 334 minecraft:moss_block
setblock 237 96 338 minecraft:mushroom_stem
fill 237 96 339 237 99 339 minecraft:moss_block
setblock 237 96 342 minecraft:moss_block
setblock 237 96 348 minecraft:mushroom_stem
fill 237 96 349 237 97 349 minecraft:moss_block
setblock 237 96 353 minecraft:mushroom_stem
fill 237 96 354 237 99 354 minecraft:moss_block
setblock 237 96 357 minecraft:moss_block
setblock 237 96 358 minecraft:mushroom_stem
fill 238 96 323 241 96 323 minecraft:moss_block
setblock 238 96 327 minecraft:mushroom_stem
fill 238 96 328 238 99 328 minecraft:moss_block
setblock 238 96 332 minecraft:mushroom_stem
fill 238 96 333 238 99 333 minecraft:moss_block
setblock 238 96 337 minecraft:mushroom_stem
fill 238 96 338 238 99 338 minecraft:moss_block
fill 238 96 363 238 99 363 minecraft:moss_block
setblock 239 96 331 minecraft:mushroom_stem
fill 239 96 332 239 99 332 minecraft:moss_block
setblock 239 96 335 minecraft:moss_block
fill 240 96 332 240 101 332 minecraft:mushroom_stem
setblock 242 96 323 minecraft:mushroom_stem
fill 243 96 323 243 99 323 minecraft:moss_block
fill 243 96 350 243 97 351 minecraft:dirt
fill 243 96 353 243 97 353 minecraft:dirt
fill 244 96 355 244 97 355 minecraft:dirt
fill 249 96 355 249 97 355 minecraft:dirt
fill 250 96 354 250 97 354 minecraft:dirt
setblock 251 96 323 minecraft:moss_block
setblock 251 96 363 minecraft:moss_block
setblock 252 96 323 minecraft:mushroom_stem
fill 252 96 340 259 96 340 minecraft:red_mushroom_block
setblock 252 96 363 minecraft:mushroom_stem
fill 253 96 323 253 99 323 minecraft:moss_block
fill 253 96 356 255 97 360 minecraft:dirt
setblock 253 96 362 minecraft:mushroom_stem
fill 253 96 363 253 99 363 minecraft:moss_block
fill 254 96 362 254 99 362 minecraft:moss_block
setblock 255 96 324 minecraft:moss_block
fill 255 96 361 258 96 361 minecraft:moss_block
setblock 256 96 324 minecraft:mushroom_stem
fill 256 96 358 256 96 360 minecraft:dirt
setblock 257 96 323 minecraft:mushroom_stem
fill 257 96 359 257 96 360 minecraft:dirt
setblock 257 96 363 minecraft:mushroom_stem
fill 258 96 323 258 99 323 minecraft:moss_block
setblock 258 96 362 minecraft:mushroom_stem
fill 258 96 363 258 99 363 minecraft:moss_block
setblock 259 96 361 minecraft:mushroom_stem
fill 259 96 362 259 99 362 minecraft:moss_block
fill 261 96 362 261 97 362 minecraft:moss_block
setblock 262 96 363 minecraft:mushroom_stem
fill 263 96 349 263 99 349 minecraft:dirt
fill 263 96 352 263 99 353 minecraft:dirt
fill 264 96 348 264 99 348 minecraft:dirt
fill 264 96 364 264 108 364 minecraft:brown_terracotta
fill 265 96 354 265 99 354 minecraft:dirt
fill 268 96 348 268 99 348 minecraft:dirt
fill 268 96 354 268 99 354 minecraft:dirt
fill 269 96 349 269 99 349 minecraft:dirt
fill 269 96 353 269 99 353 minecraft:dirt
setblock 272 96 363 minecraft:red_mushroom_block
setblock 274 96 331 minecraft:mushroom_stem
fill 274 96 332 274 96 335 minecraft:moss_block
setblock 274 96 336 minecraft:mushroom_stem
fill 274 96 337 275 98 337 minecraft:moss_block
setblock 274 96 350 minecraft:moss_block
setblock 274 96 351 minecraft:mushroom_stem
fill 274 96 352 274 99 352 minecraft:moss_block
setblock 274 96 355 minecraft:moss_block
setblock 274 96 356 minecraft:mushroom_stem
fill 275 96 328 275 96 329 minecraft:moss_block
setblock 275 96 330 minecraft:mushroom_stem
fill 275 96 331 275 99 331 minecraft:moss_block
setblock 275 96 335 minecraft:mushroom_stem
fill 275 96 336 275 99 336 minecraft:moss_block
fill 275 96 338 275 96 339 minecraft:moss_block
setblock 275 96 340 minecraft:mushroom_stem
fill 275 96 341 275 99 341 minecraft:moss_block
setblock 275 96 345 minecraft:mushroom_stem
fill 275 96 346 275 99 346 minecraft:moss_block
setblock 275 96 350 minecraft:mushroom_stem
fill 275 96 351 275 99 351 minecraft:moss_block
setblock 275 96 355 minecraft:mushroom_stem
fill 275 96 356 275 99 356 minecraft:moss_block
fill 275 96 358 275 96 359 minecraft:moss_block
setblock 276 96 324 minecraft:mushroom_stem
fill 276 96 325 276 99 325 minecraft:moss_block
setblock 276 96 329 minecraft:mushroom_stem
fill 276 96 330 276 99 330 minecraft:moss_block
setblock 276 96 334 minecraft:mushroom_stem
fill 276 96 335 276 99 335 minecraft:moss_block
setblock 276 96 339 minecraft:mushroom_stem
fill 276 96 340 276 99 340 minecraft:moss_block
setblock 276 96 344 minecraft:mushroom_stem
fill 276 96 345 276 99 345 minecraft:moss_block
setblock 276 96 349 minecraft:mushroom_stem
fill 276 96 350 276 99 350 minecraft:moss_block
setblock 276 96 354 minecraft:mushroom_stem
fill 276 96 355 276 99 355 minecraft:moss_block
setblock 276 96 359 minecraft:mushroom_stem
fill 276 96 360 276 98 361 minecraft:moss_block
setblock 236 97 323 minecraft:mushroom_stem
fill 236 97 324 236 100 324 minecraft:moss_block
setblock 236 97 328 minecraft:mushroom_stem
fill 236 97 329 236 100 329 minecraft:moss_block
setblock 236 97 333 minecraft:mushroom_stem
fill 236 97 334 236 100 334 minecraft:moss_block
setblock 236 97 338 minecraft:mushroom_stem
fill 236 97 339 236 100 339 minecraft:moss_block
setblock 236 97 343 minecraft:mushroom_stem
fill 236 97 344 236 100 344 minecraft:moss_block
setblock 236 97 348 minecraft:mushroom_stem
fill 236 97 349 236 100 349 minecraft:moss_block
setblock 236 97 353 minecraft:mushroom_stem
fill 236 97 354 236 100 354 minecraft:moss_block
setblock 236 97 357 minecraft:moss_block
setblock 236 97 358 minecraft:mushroom_stem
fill 236 97 359 237 99 359 minecraft:moss_block
setblock 236 97 362 minecraft:moss_block
setblock 236 97 363 minecraft:mushroom_stem
fill 237 97 323 240 97 323 minecraft:moss_block
setblock 237 97 327 minecraft:mushroom_stem
fill 237 97 328 237 100 328 minecraft:moss_block
setblock 237 97 332 minecraft:mushroom_stem
fill 237 97 333 237 100 333 minecraft:moss_block
setblock 237 97 337 minecraft:mushroom_stem
fill 237 97 338 237 100 338 minecraft:moss_block
setblock 237 97 342 minecraft:mushroom_stem
setblock 237 97 352 minecraft:mushroom_stem
fill 237 97 353 237 100 353 minecraft:moss_block
setblock 237 97 357 minecraft:mushroom_stem
fill 237 97 358 237 100 358 minecraft:moss_block
fill 237 97 363 237 100 363 minecraft:moss_block
setblock 238 97 326 minecraft:mushroom_stem
fill 238 97 327 238 99 327 minecraft:moss_block
setblock 238 97 331 minecraft:mushroom_stem
fill 238 97 332 238 100 332 minecraft:moss_block
setblock 238 97 336 minecraft:mushroom_stem
fill 238 97 337 238 100 337 minecraft:moss_block
fill 238 97 339 238 98 339 minecraft:moss_block
setblock 239 97 330 minecraft:mushroom_stem
fill 239 97 331 239 99 331 minecraft:moss_block
setblock 239 97 335 minecraft:mushroom_stem
fill 239 97 336 239 99 336 minecraft:moss_block
fill 239 97 363 240 97 363 minecraft:moss_block
setblock 240 97 324 minecraft:mushroom_stem
setblock 241 97 323 minecraft:mushroom_stem
fill 242 97 323 242 100 323 minecraft:moss_block
setblock 243 97 349 minecraft:dirt
setblock 243 97 354 minecraft:dirt
fill 245 97 356 248 97 356 minecraft:dirt
fill 249 97 323 250 97 323 minecraft:moss_block
fill 249 97 363 250 97 363 minecraft:moss_block
setblock 251 97 323 minecraft:mushroom_stem
fill 251 97 351 251 97 353 minecraft:dirt
setblock 251 97 362 minecraft:moss_block
setblock 251 97 363 minecraft:mushroom_stem
fill 252 97 323 252 100 323 minecraft:moss_block
setblock 252 97 362 minecraft:mushroom_stem
fill 252 97 363 252 100 363 minecraft:moss_block
setblock 253 97 361 minecraft:mushroom_stem
fill 253 97 362 253 100 362 minecraft:moss_block
setblock 254 97 324 minecraft:moss_block
fill 254 97 361 257 97 361 minecraft:moss_block
setblock 255 97 324 minecraft:mushroom_stem
setblock 256 97 323 minecraft:mushroom_stem
fill 256 97 324 256 99 324 minecraft:moss_block
fill 256 97 358 256 97 359 minecraft:dirt
fill 256 97 360 257 98 360 minecraft:moss_block
setblock 256 97 363 minecraft:mushroom_stem
fill 257 97 323 257 100 323 minecraft:moss_block
setblock 257 97 327 minecraft:dirt
setblock 257 97 359 minecraft:dirt
setblock 257 97 362 minecraft:mushroom_stem
fill 257 97 363 257 100 363 minecraft:moss_block
setblock 258 97 361 minecraft:mushroom_stem
fill 258 97 362 258 100 362 minecraft:moss_block
setblock 259 97 325 minecraft:dirt
setblock 259 97 329 minecraft:dirt
fill 259 97 361 260 99 361 minecraft:moss_block
setblock 261 97 327 minecraft:dirt
setblock 261 97 363 minecraft:mushroom_stem
fill 262 97 350 262 99 352 minecraft:dirt
fill 262 97 363 262 100 363 minecraft:moss_block
fill 263 97 348 263 99 348 minecraft:dirt
fill 264 97 354 264 99 354 minecraft:dirt
fill 265 97 347 267 99 347 minecraft:dirt
fill 266 97 355 267 99 355 minecraft:dirt
fill 269 97 348 269 99 348 minecraft:dirt
fill 269 97 354 269 99 354 minecraft:dirt
fill 270 97 350 270 99 352 minecraft:dirt
setblock 272 97 323 minecraft:red_mushroom_block
setblock 274 97 330 minecraft:mushroom_stem
fill 274 97 331 274 97 334 minecraft:moss_block
setblock 274 97 335 minecraft:mushroom_stem
fill 274 97 336 274 100 336 minecraft:moss_block
fill 274 97 338 274 97 339 minecraft:moss_block
setblock 274 97 340 minecraft:mushroom_stem
fill 274 97 347 274 140 347 minecraft:mushroom_stem
fill 274 97 348 274 98 348 minecraft:moss_block
setblock 274 97 350 minecraft:mushroom_stem
fill 274 97 351 274 100 351 minecraft:moss_block
setblock 274 97 355 minecraft:mushroom_stem
fill 274 97 356 274 99 357 minecraft:moss_block
fill 275 97 327 275 97 328 minecraft:moss_block
setblock 275 97 329 minecraft:mushroom_stem
fill 275 97 330 275 100 330 minecraft:moss_block
setblock 275 97 334 minecraft:mushroom_stem
fill 275 97 335 275 100 335 minecraft:moss_block
setblock 275 97 338 minecraft:moss_block
setblock 275 97 339 minecraft:mushroom_stem
fill 275 97 340 275 100 340 minecraft:moss_block
fill 275 97 342 275 97 343 minecraft:moss_block
setblock 275 97 344 minecraft:mushroom_stem
fill 275 97 345 275 100 345 minecraft:moss_block
setblock 275 97 349 minecraft:mushroom_stem
fill 275 97 350 275 100 350 minecraft:moss_block
setblock 275 97 354 minecraft:mushroom_stem
fill 275 97 355 275 100 355 minecraft:moss_block
setblock 275 97 358 minecraft:moss_block
setblock 275 97 359 minecraft:mushroom_stem
fill 275 97 360 275 100 360 minecraft:moss_block
setblock 276 97 323 minecraft:mushroom_stem
fill 276 97 324 276 100 324 minecraft:moss_block
setblock 276 97 328 minecraft:mushroom_stem
fill 276 97 329 276 100 329 minecraft:moss_block
setblock 276 97 333 minecraft:mushroom_stem
fill 276 97 334 276 100 334 minecraft:moss_block
setblock 276 97 338 minecraft:mushroom_stem
fill 276 97 339 276 100 339 minecraft:moss_block
setblock 276 97 343 minecraft:mushroom_stem
fill 276 97 344 276 100 344 minecraft:moss_block
setblock 276 97 348 minecraft:mushroom_stem
fill 276 97 349 276 100 349 minecraft:moss_block
setblock 276 97 353 minecraft:mushroom_stem
fill 276 97 354 276 100 354 minecraft:moss_block
setblock 276 97 358 minecraft:mushroom_stem
fill 276 97 359 276 100 359 minecraft:moss_block
setblock 276 97 362 minecraft:moss_block
setblock 276 97 363 minecraft:mushroom_stem
fill 236 98 323 239 98 323 minecraft:moss_block
setblock 236 98 327 minecraft:mushroom_stem
fill 236 98 328 236 101 328 minecraft:moss_block
setblock 236 98 332 minecraft:mushroom_stem
fill 236 98 333 236 101 333 minecraft:moss_block
setblock 236 98 337 minecraft:mushroom_stem
fill 236 98 338 236 101 338 minecraft:moss_block
setblock 236 98 341 minecraft:moss_block
setblock 236 98 342 minecraft:mushroom_stem
fill 236 98 343 237 100 343 minecraft:moss_block
setblock 236 98 347 minecraft:mushroom_stem
fill 236 98 348 236 101 348 minecraft:moss_block
setblock 236 98 352 minecraft:mushroom_stem
fill 236 98 353 236 101 353 minecraft:moss_block
setblock 236 98 356 minecraft:moss_block
setblock 236 98 357 minecraft:mushroom_stem
fill 236 98 358 236 101 358 minecraft:moss_block
setblock 236 98 362 minecraft:mushroom_stem
fill 236 98 363 236 101 363 minecraft:moss_block
setblock 237 98 326 minecraft:mushroom_stem
fill 237 98 327 237 101 327 minecraft:moss_block
setblock 237 98 331 minecraft:mushroom_stem
fill 237 98 332 237 101 332 minecraft:moss_block
setblock 237 98 336 minecraft:mushroom_stem
fill 237 98 337 237 101 337 minecraft:moss_block
setblock 237 98 341 minecraft:mushroom_stem
fill 237 98 342 237 101 342 minecraft:moss_block
setblock 237 98 351 minecraft:mushroom_stem
fill 237 98 352 237 100 352 minecraft:moss_block
setblock 237 98 356 minecraft:mushroom_stem
fill 237 98 357 237 101 357 minecraft:moss_block
setblock 237 98 360 minecraft:moss_block
setblock 237 98 361 minecraft:mushroom_stem
setblock 238 98 326 minecraft:moss_block
setblock 238 98 330 minecraft:mushroom_stem
fill 238 98 331 238 101 331 minecraft:moss_block
setblock 238 98 334 minecraft:moss_block
setblock 238 98 335 minecraft:mushroom_stem
fill 238 98 336 238 101 336 minecraft:moss_block
setblock 239 98 324 minecraft:mushroom_stem
setblock 239 98 330 minecraft:moss_block
setblock 239 98 334 minecraft:mushroom_stem
fill 239 98 335 239 100 335 minecraft:moss_block
setblock 239 98 363 minecraft:moss_block
setblock 240 98 323 minecraft:mushroom_stem
fill 240 98 324 240 99 324 minecraft:moss_block
setblock 240 98 363 minecraft:mushroom_stem
fill 241 98 323 241 101 323 minecraft:moss_block
fill 241 98 363 242 100 363 minecraft:moss_block
setblock 244 98 323 minecraft:moss_block
setblock 246 98 363 minecraft:red_mushroom_block
setblock 247 98 323 minecraft:red_mushroom_block
fill 247 98 363 249 98 363 minecraft:moss_block
fill 248 98 323 249 98 323 minecraft:moss_block
setblock 250 98 323 minecraft:mushroom_stem
setblock 250 98 362 minecraft:moss_block
setblock 250 98 363 minecraft:mushroom_stem
fill 251 98 323 251 101 323 minecraft:moss_block
setblock 251 98 362 minecraft:mushroom_stem
fill 251 98 363 251 101 363 minecraft:moss_block
setblock 252 98 361 minecraft:mushroom_stem
fill 252 98 362 252 101 362 minecraft:moss_block
setblock 253 98 324 minecraft:moss_block
fill 253 98 361 256 98 361 minecraft:moss_block
setblock 254 98 324 minecraft:mushroom_stem
fill 254 98 358 256 104 358 minecraft:mushroom_stem
fill 254 98 360 255 100 360 minecraft:moss_block
setblock 255 98 323 minecraft:mushroom_stem
fill 255 98 324 255 100 324 minecraft:moss_block
fill 255 98 357 255 104 357 minecraft:mushroom_stem
setblock 255 98 359 minecraft:mushroom_stem
setblock 255 98 363 minecraft:mushroom_stem
fill 256 98 323 256 101 323 minecraft:moss_block
setblock 256 98 362 minecraft:mushroom_stem
fill 256 98 363 256 101 363 minecraft:moss_block
setblock 257 98 361 minecraft:mushroom_stem
fill 257 98 362 257 101 362 minecraft:moss_block
setblock 258 98 360 minecraft:mushroom_stem
fill 258 98 361 258 101 361 minecraft:moss_block
setblock 260 98 363 minecraft:mushroom_stem
setblock 261 98 362 minecraft:mushroom_stem
fill 261 98 363 261 101 363 minecraft:moss_block
fill 262 98 349 262 99 349 minecraft:dirt
fill 262 98 353 262 99 353 minecraft:dirt
fill 263 98 354 263 99 354 minecraft:dirt
fill 263 98 363 263 99 363 minecraft:moss_block
fill 264 98 347 264 99 347 minecraft:dirt
fill 264 98 355 265 99 355 minecraft:dirt
setblock 265 98 363 minecraft:red_mushroom_block
setblock 266 98 323 minecraft:red_mushroom_block
fill 268 98 347 268 99 347 minecraft:dirt
fill 268 98 355 268 99 355 minecraft:dirt
fill 270 98 349 270 99 349 minecraft:dirt
fill 270 98 353 270 99 353 minecraft:dirt
setblock 273 98 334 minecraft:moss_block
setblock 273 98 335 minecraft:mushroom_stem
fill 273 98 336 273 100 337 minecraft:moss_block
fill 273 98 363 274 98 363 minecraft:moss_block
fill 274 98 330 274 98 333 minecraft:moss_block
setblock 274 98 334 minecraft:mushroom_stem
fill 274 98 335 274 101 335 minecraft:moss_block
setblock 274 98 338 minecraft:moss_block
setblock 274 98 339 minecraft:mushroom_stem
fill 274 98 340 274 99 342 minecraft:moss_block
setblock 274 98 349 minecraft:mushroom_stem
fill 274 98 350 274 100 350 minecraft:moss_block
setblock 274 98 353 minecraft:moss_block
setblock 274 98 354 minecraft:mushroom_stem
fill 274 98 355 274 101 355 minecraft:moss_block
setblock 274 98 358 minecraft:moss_block
setblock 275 98 323 minecraft:mushroom_stem
setblock 275 98 327 minecraft:moss_block
setblock 275 98 328 minecraft:mushroom_stem
fill 275 98 329 275 101 329 minecraft:moss_block
setblock 275 98 333 minecraft:mushroom_stem
fill 275 98 334 275 101 334 minecraft:moss_block
setblock 275 98 338 minecraft:mushroom_stem
fill 275 98 339 275 101 339 minecraft:moss_block
setblock 275 98 342 minecraft:moss_block
setblock 275 98 343 minecraft:mushroom_stem
fill 275 98 344 275 101 344 minecraft:moss_block
setblock 275 98 348 minecraft:mushroom_stem
fill 275 98 349 275 101 349 minecraft:moss_block
setblock 275 98 353 minecraft:mushroom_stem
fill 275 98 354 275 101 354 minecraft:moss_block
setblock 275 98 358 minecraft:mushroom_stem
fill 275 98 359 275 101 359 minecraft:moss_block
fill 275 98 361 275 99 361 minecraft:moss_block
setblock 275 98 363 minecraft:mushroom_stem
fill 276 98 323 276 101 323 minecraft:moss_block
setblock 276 98 327 minecraft:mushroom_stem
fill 276 98 328 276 101 328 minecraft:moss_block
setblock 276 98 332 minecraft:mushroom_stem
fill 276 98 333 276 101 333 minecraft:moss_block
setblock 276 98 337 minecraft:mushroom_stem
fill 276 98 338 276 101 338 minecraft:moss_block
setblock 276 98 342 minecraft:mushroom_stem
fill 276 98 343 276 101 343 minecraft:moss_block
setblock 276 98 347 minecraft:mushroom_stem
fill 276 98 348 276 101 348 minecraft:moss_block
setblock 276 98 352 minecraft:mushroom_stem
fill 276 98 353 276 101 353 minecraft:moss_block
setblock 276 98 357 minecraft:mushroom_stem
fill 276 98 358 276 101 358 minecraft:moss_block
setblock 276 98 362 minecraft:mushroom_stem
fill 276 98 363 276 101 363 minecraft:moss_block
fill 236 99 323 238 99 323 minecraft:moss_block
setblock 236 99 326 minecraft:mushroom_stem
fill 236 99 327 236 102 327 minecraft:moss_block
setblock 236 99 331 minecraft:mushroom_stem
fill 236 99 332 236 102 332 minecraft:moss_block
setblock 236 99 336 minecraft:mushroom_stem
fill 236 99 337 236 102 337 minecraft:moss_block
setblock 236 99 341 minecraft:mushroom_stem
fill 236 99 342 236 102 342 minecraft:moss_block
setblock 236 99 346 minecraft:mushroom_stem
fill 236 99 347 236 101 347 minecraft:moss_block
setblock 236 99 351 minecraft:mushroom_stem
fill 236 99 352 236 102 352 minecraft:moss_block
setblock 236 99 356 minecraft:mushroom_stem
fill 236 99 357 236 102 357 minecraft:moss_block
setblock 236 99 360 minecraft:moss_block
setblock 236 99 361 minecraft:mushroom_stem
fill 236 99 362 239 99 362 minecraft:moss_block
setblock 237 99 325 minecraft:mushroom_stem
fill 237 99 326 237 102 326 minecraft:moss_block
setblock 237 99 330 minecraft:mushroom_stem
fill 237 99 331 237 102 331 minecraft:moss_block
setblock 237 99 335 minecraft:mushroom_stem
fill 237 99 336 237 102 336 minecraft:moss_block
setblock 237 99 340 minecraft:mushroom_stem
fill 237 99 341 237 102 341 minecraft:moss_block
setblock 237 99 351 minecraft:moss_block
setblock 237 99 355 minecraft:mushroom_stem
fill 237 99 356 237 102 356 minecraft:moss_block
setblock 237 99 360 minecraft:mushroom_stem
fill 237 99 361 237 102 361 minecraft:moss_block
setblock 238 99 324 minecraft:mushroom_stem
setblock 238 99 325 minecraft:light[level=12]
setblock 238 99 329 minecraft:mushroom_stem
fill 238 99 330 238 101 330 minecraft:moss_block
setblock 238 99 334 minecraft:mushroom_stem
fill 238 99 335 238 102 335 minecraft:moss_block
setblock 238 99 339 minecraft:mushroom_stem
fill 238 99 340 238 100 340 minecraft:moss_block
setblock 238 99 346 minecraft:light[level=12]
setblock 238 99 353 minecraft:light[level=12]
setblock 238 99 360 minecraft:light[level=12]
setblock 239 99 323 minecraft:mushroom_stem
fill 239 99 324 239 101 324 minecraft:moss_block
setblock 239 99 333 minecraft:mushroom_stem
fill 239 99 334 239 100 334 minecraft:moss_block
setblock 239 99 363 minecraft:mushroom_stem
fill 240 99 323 240 102 323 minecraft:moss_block
fill 240 99 363 240 102 363 minecraft:moss_block
setblock 243 99 363 minecraft:moss_block
setblock 244 99 323 minecraft:mushroom_stem
setblock 244 99 363 minecraft:mushroom_stem
fill 245 99 323 248 99 323 minecraft:moss_block
setblock 245 99 325 minecraft:light[level=12]
setblock 245 99 332 minecraft:light[level=12]
setblock 245 99 339 minecraft:light[level=12]
setblock 245 99 346 minecraft:light[level=12]
setblock 245 99 353 minecraft:light[level=12]
setblock 245 99 360 minecraft:light[level=12]
fill 245 99 363 248 99 363 minecraft:moss_block
fill 248 99 362 249 99 362 minecraft:moss_block
setblock 249 99 323 minecraft:mushroom_stem
setblock 249 99 363 minecraft:mushroom_stem
fill 250 99 323 250 102 323 minecraft:moss_block
setblock 250 99 326 minecraft:shroomlight
setblock 250 99 361 minecraft:moss_block
setblock 250 99 362 minecraft:mushroom_stem
fill 250 99 363 250 102 363 minecraft:moss_block
fill 250 99 364 252 138 364 minecraft:brown_terracotta
setblock 251 99 361 minecraft:mushroom_stem
fill 251 99 362 251 102 362 minecraft:moss_block
setblock 252 99 324 minecraft:moss_block
setblock 252 99 325 minecraft:light[level=12]
setblock 252 99 332 minecraft:light[level=12]
setblock 252 99 339 minecraft:light[level=12]
setblock 252 99 346 minecraft:light[level=12]
setblock 252 99 353 minecraft:light[level=12]
setblock 252 99 360 minecraft:mushroom_stem
fill 252 99 361 255 99 361 minecraft:moss_block
setblock 253 99 324 minecraft:mushroom_stem
fill 253 99 360 253 102 360 minecraft:moss_block
setblock 253 99 364 minecraft:shroomlight
setblock 254 99 323 minecraft:mushroom_stem
fill 254 99 324 254 101 324 minecraft:moss_block
setblock 254 99 363 minecraft:mushroom_stem
fill 254 99 364 260 112 364 minecraft:brown_terracotta
fill 255 99 323 255 102 323 minecraft:moss_block
fill 255 99 359 256 100 359 minecraft:moss_block
setblock 255 99 362 minecraft:mushroom_stem
fill 255 99 363 255 102 363 minecraft:moss_block
setblock 256 99 360 minecraft:moss_block
setblock 256 99 361 minecraft:mushroom_stem
fill 256 99 362 256 102 362 minecraft:moss_block
setblock 257 99 360 minecraft:mushroom_stem
fill 257 99 361 257 102 361 minecraft:moss_block
fill 258 99 360 259 100 360 minecraft:moss_block
setblock 259 99 323 minecraft:mushroom_stem
setblock 259 99 325 minecraft:light[level=12]
setblock 259 99 332 minecraft:light[level=12]
setblock 259 99 339 minecraft:light[level=12]
setblock 259 99 346 minecraft:light[level=12]
setblock 259 99 353 minecraft:light[level=12]
setblock 259 99 363 minecraft:mushroom_stem
setblock 260 99 323 minecraft:red_mushroom_block
setblock 260 99 362 minecraft:mushroom_stem
fill 260 99 363 260 102 363 minecraft:moss_block
fill 261 99 350 261 99 352 minecraft:dirt
fill 261 99 362 262 100 362 minecraft:moss_block
setblock 262 99 348 minecraft:dirt
setblock 262 99 354 minecraft:dirt
setblock 263 99 347 minecraft:dirt
setblock 263 99 355 minecraft:dirt
fill 265 99 346 268 99 346 minecraft:dirt
fill 265 99 356 267 99 356 minecraft:dirt
setblock 266 99 325 minecraft:light[level=12]
setblock 266 99 332 minecraft:light[level=12]
setblock 266 99 339 minecraft:light[level=12]
setblock 266 99 360 minecraft:light[level=12]
setblock 269 99 347 minecraft:dirt
setblock 269 99 355 minecraft:dirt
fill 270 99 329 274 99 330 minecraft:red_mushroom_block
setblock 270 99 348 minecraft:dirt
setblock 270 99 354 minecraft:dirt
fill 271 99 327 273 99 328 minecraft:red_mushroom_block
fill 271 99 331 273 99 331 minecraft:red_mushroom_block
fill 271 99 349 271 99 352 minecraft:dirt
fill 271 99 363 273 99 363 minecraft:moss_block
setblock 273 99 325 minecraft:light[level=12]
setblock 273 99 332 minecraft:light[level=12]
setblock 273 99 333 minecraft:moss_block
setblock 273 99 334 minecraft:mushroom_stem
fill 273 99 335 273 102 335 minecraft:moss_block
setblock 273 99 338 minecraft:moss_block
setblock 273 99 339 minecraft:mushroom_stem
setblock 273 99 353 minecraft:light[level=12]
setblock 273 99 360 minecraft:light[level=12]
setblock 274 99 323 minecraft:mushroom_stem
setblock 274 99 328 minecraft:red_mushroom_block
fill 274 99 331 274 99 332 minecraft:moss_block
setblock 274 99 333 minecraft:mushroom_stem
fill 274 99 334 274 102 334 minecraft:moss_block
setblock 274 99 337 minecraft:moss_block
setblock 274 99 338 minecraft:mushroom_stem
fill 274 99 339 274 102 339 minecraft:moss_block
setblock 274 99 343 minecraft:mushroom_stem
fill 274 99 344 274 102 344 minecraft:moss_block
fill 274 99 348 274 141 348 minecraft:mushroom_stem
fill 274 99 349 274 100 349 minecraft:moss_block
setblock 274 99 353 minecraft:mushroom_stem
fill 274 99 354 274 102 354 minecraft:moss_block
setblock 274 99 358 minecraft:mushroom_stem
fill 274 99 359 274 102 359 minecraft:moss_block
setblock 274 99 362 minecraft:moss_block
setblock 274 99 363 minecraft:mushroom_stem
fill 275 99 323 275 102 323 minecraft:moss_block
setblock 275 99 327 minecraft:mushroom_stem
fill 275 99 328 275 102 328 minecraft:moss_block
setblock 275 99 332 minecraft:mushroom_stem
fill 275 99 333 275 102 333 minecraft:moss_block
setblock 275 99 337 minecraft:mushroom_stem
fill 275 99 338 275 102 338 minecraft:moss_block
setblock 275 99 342 minecraft:mushroom_stem
fill 275 99 343 275 102 343 minecraft:moss_block
setblock 275 99 347 minecraft:mushroom_stem
fill 275 99 348 275 102 348 minecraft:moss_block
setblock 275 99 352 minecraft:mushroom_stem
fill 275 99 353 275 102 353 minecraft:moss_block
setblock 275 99 357 minecraft:mushroom_stem
fill 275 99 358 275 102 358 minecraft:moss_block
setblock 275 99 362 minecraft:mushroom_stem
fill 275 99 363 275 102 363 minecraft:moss_block
setblock 276 99 326 minecraft:mushroom_stem
fill 276 99 327 276 102 327 minecraft:moss_block
setblock 276 99 331 minecraft:mushroom_stem
fill 276 99 332 276 102 332 minecraft:moss_block
setblock 276 99 336 minecraft:mushroom_stem
fill 276 99 337 276 102 337 minecraft:moss_block
setblock 276 99 341 minecraft:mushroom_stem
fill 276 99 342 276 102 342 minecraft:moss_block
setblock 276 99 346 minecraft:mushroom_stem
fill 276 99 347 276 102 347 minecraft:moss_block
setblock 276 99 351 minecraft:mushroom_stem
fill 276 99 352 276 102 352 minecraft:moss_block
setblock 276 99 356 minecraft:mushroom_stem
fill 276 99 357 276 102 357 minecraft:moss_block
setblock 276 99 360 minecraft:moss_block
setblock 276 99 361 minecraft:mushroom_stem
fill 276 99 362 276 102 362 minecraft:moss_block
setblock 277 99 358 minecraft:red_mushroom_block
fill 235 100 334 235 138 337 minecraft:brown_terracotta
setblock 235 100 338 minecraft:red_mushroom_block
fill 235 100 339 235 111 349 minecraft:brown_terracotta
fill 236 100 323 237 100 323 minecraft:moss_block
setblock 236 100 325 minecraft:mushroom_stem
fill 236 100 326 236 103 326 minecraft:moss_block
setblock 236 100 330 minecraft:mushroom_stem
fill 236 100 331 236 103 331 minecraft:moss_block
setblock 236 100 335 minecraft:mushroom_stem
fill 236 100 336 236 103 336 minecraft:moss_block
setblock 236 100 340 minecraft:mushroom_stem
fill 236 100 341 236 103 341 minecraft:moss_block
setblock 236 100 345 minecraft:mushroom_stem
fill 236 100 346 236 102 346 minecraft:moss_block
setblock 236 100 350 minecraft:mushroom_stem
fill 236 100 351 236 102 351 minecraft:moss_block
setblock 236 100 355 minecraft:mushroom_stem
fill 236 100 356 236 103 356 minecraft:moss_block
setblock 236 100 359 minecraft:moss_block
setblock 236 100 360 minecraft:mushroom_stem
fill 236 100 361 236 102 362 minecraft:moss_block
setblock 237 100 324 minecraft:mushroom_stem
fill 237 100 325 237 103 325 minecraft:moss_block
setblock 237 100 329 minecraft:mushroom_stem
fill 237 100 330 237 103 330 minecraft:moss_block
setblock 237 100 334 minecraft:mushroom_stem
fill 237 100 335 237 103 335 minecraft:moss_block
setblock 237 100 339 minecraft:mushroom_stem
fill 237 100 340 237 103 340 minecraft:moss_block
setblock 237 100 354 minecraft:mushroom_stem
fill 237 100 355 237 101 355 minecraft:moss_block
setblock 237 100 359 minecraft:mushroom_stem
fill 237 100 360 237 103 360 minecraft:moss_block
fill 237 100 362 238 100 362 minecraft:moss_block
setblock 238 100 323 minecraft:mushroom_stem
fill 238 100 324 238 102 324 minecraft:moss_block
setblock 238 100 328 minecraft:mushroom_stem
fill 238 100 329 238 101 329 minecraft:moss_block
setblock 238 100 333 minecraft:mushroom_stem
fill 238 100 334 238 102 334 minecraft:moss_block
setblock 238 100 338 minecraft:mushroom_stem
fill 238 100 339 238 102 339 minecraft:moss_block
setblock 238 100 363 minecraft:mushroom_stem
fill 239 100 323 239 103 323 minecraft:moss_block
setblock 239 100 333 minecraft:moss_block
setblock 239 100 362 minecraft:mushroom_stem
fill 239 100 363 239 103 363 minecraft:moss_block
setblock 243 100 323 minecraft:mushroom_stem
setblock 243 100 363 minecraft:mushroom_stem
fill 244 100 323 247 100 323 minecraft:moss_block
fill 244 100 363 247 100 363 minecraft:moss_block
fill 247 100 362 248 100 362 minecraft:moss_block
setblock 248 100 323 minecraft:mushroom_stem
setblock 248 100 363 minecraft:mushroom_stem
fill 249 100 323 249 103 323 minecraft:moss_block
setblock 249 100 361 minecraft:moss_block
setblock 249 100 362 minecraft:mushroom_stem
fill 249 100 363 249 103 363 minecraft:moss_block
fill 250 100 326 250 104 326 minecraft:mushroom_stem
setblock 250 100 361 minecraft:mushroom_stem
fill 250 100 362 250 103 362 minecraft:moss_block
setblock 251 100 360 minecraft:mushroom_stem
fill 251 100 361 254 100 361 minecraft:moss_block
setblock 252 100 324 minecraft:mushroom_stem
fill 252 100 360 252 103 360 minecraft:moss_block
setblock 253 100 323 minecraft:mushroom_stem
fill 253 100 324 253 102 324 minecraft:moss_block
setblock 253 100 363 minecraft:mushroom_stem
fill 253 100 364 253 147 364 minecraft:brown_terracotta
fill 254 100 323 254 103 323 minecraft:moss_block
fill 254 100 359 254 102 359 minecraft:moss_block
setblock 254 100 362 minecraft:mushroom_stem
fill 254 100 363 254 103 363 minecraft:moss_block
setblock 255 100 361 minecraft:mushroom_stem
fill 255 100 362 255 103 362 minecraft:moss_block
setblock 256 100 360 minecraft:mushroom_stem
fill 256 100 361 256 103 361 minecraft:moss_block
setblock 257 100 359 minecraft:mushroom_stem
fill 257 100 360 257 103 360 minecraft:moss_block
setblock 258 100 323 minecraft:mushroom_stem
setblock 258 100 363 minecraft:mushroom_stem
setblock 259 100 323 minecraft:moss_block
setblock 259 100 361 minecraft:moss_block
setblock 259 100 362 minecraft:mushroom_stem
fill 259 100 363 259 103 363 minecraft:moss_block
setblock 260 100 361 minecraft:mushroom_stem
fill 260 100 362 260 103 362 minecraft:moss_block
setblock 263 100 363 minecraft:mushroom_stem
fill 266 100 351 266 103 351 minecraft:mushroom_stem
fill 270 100 363 272 100 363 minecraft:moss_block
fill 272 100 362 273 100 362 minecraft:moss_block
setblock 273 100 323 minecraft:mushroom_stem
setblock 273 100 333 minecraft:mushroom_stem
fill 273 100 334 273 103 334 minecraft:moss_block
setblock 273 100 338 minecraft:mushroom_stem
fill 273 100 339 273 101 341 minecraft:moss_block
setblock 273 100 363 minecraft:mushroom_stem
fill 274 100 323 274 103 323 minecraft:moss_block
fill 274 100 330 274 100 331 minecraft:moss_block
setblock 274 100 332 minecraft:mushroom_stem
fill 274 100 333 274 103 333 minecraft:moss_block
setblock 274 100 337 minecraft:mushroom_stem
fill 274 100 338 274 103 338 minecraft:moss_block
fill 274 100 340 274 100 341 minecraft:moss_block
setblock 274 100 342 minecraft:mushroom_stem
fill 274 100 343 274 103 343 minecraft:moss_block
fill 274 100 345 274 101 345 minecraft:moss_block
setblock 274 100 352 minecraft:mushroom_stem
fill 274 100 353 274 101 353 minecraft:moss_block
setblock 274 100 356 minecraft:moss_block
setblock 274 100 357 minecraft:mushroom_stem
fill 274 100 358 274 102 358 minecraft:moss_block
fill 274 100 360 274 101 360 minecraft:moss_block
setblock 274 100 362 minecraft:mushroom_stem
fill 274 100 363 274 103 363 minecraft:moss_block
fill 275 100 327 275 101 327 minecraft:moss_block
setblock 275 100 331 minecraft:mushroom_stem
fill 275 100 332 275 103 332 minecraft:moss_block
setblock 275 100 336 minecraft:mushroom_stem
fill 275 100 337 275 103 337 minecraft:moss_block
setblock 275 100 341 minecraft:mushroom_stem
fill 275 100 342 275 103 342 minecraft:moss_block
setblock 275 100 346 minecraft:mushroom_stem
fill 275 100 347 275 103 347 minecraft:moss_block
setblock 275 100 351 minecraft:mushroom_stem
fill 275 100 352 275 102 352 minecraft:moss_block
setblock 275 100 356 minecraft:mushroom_stem
fill 275 100 357 275 103 357 minecraft:moss_block
setblock 275 100 361 minecraft:mushroom_stem
fill 275 100 362 275 103 362 minecraft:moss_block
setblock 276 100 325 minecraft:mushroom_stem
fill 276 100 326 276 103 326 minecraft:moss_block
setblock 276 100 330 minecraft:mushroom_stem
fill 276 100 331 276 103 331 minecraft:moss_block
setblock 276 100 335 minecraft:mushroom_stem
fill 276 100 336 276 103 336 minecraft:moss_block
setblock 276 100 340 minecraft:mushroom_stem
fill 276 100 341 276 103 341 minecraft:moss_block
setblock 276 100 345 minecraft:mushroom_stem
fill 276 100 346 276 103 346 minecraft:moss_block
setblock 276 100 350 minecraft:mushroom_stem
fill 276 100 351 276 103 351 minecraft:moss_block
setblock 276 100 355 minecraft:mushroom_stem
fill 276 100 356 276 103 356 minecraft:moss_block
setblock 276 100 360 minecraft:mushroom_stem
fill 276 100 361 276 103 361 minecraft:moss_block
fill 277 100 358 277 142 358 minecraft:brown_terracotta
fill 235 101 338 235 147 338 minecraft:brown_terracotta
setblock 236 101 323 minecraft:moss_block
setblock 236 101 324 minecraft:mushroom_stem
fill 236 101 325 236 104 325 minecraft:moss_block
setblock 236 101 329 minecraft:mushroom_stem
fill 236 101 330 236 104 330 minecraft:moss_block
setblock 236 101 334 minecraft:mushroom_stem
fill 236 101 335 236 104 335 minecraft:moss_block
setblock 236 101 339 minecraft:mushroom_stem
fill 236 101 340 236 104 340 minecraft:moss_block
setblock 236 101 343 minecraft:moss_block
setblock 236 101 344 minecraft:mushroom_stem
fill 236 101 345 236 103 345 minecraft:moss_block
setblock 236 101 349 minecraft:mushroom_stem
setblock 236 101 350 minecraft:moss_block
setblock 236 101 354 minecraft:mushroom_stem
fill 236 101 355 236 104 355 minecraft:moss_block
setblock 236 101 359 minecraft:mushroom_stem
fill 236 101 360 236 104 360 minecraft:moss_block
setblock 237 101 323 minecraft:mushroom_stem
fill 237 101 324 237 103 324 minecraft:moss_block
setblock 237 101 328 minecraft:mushroom_stem
fill 237 101 329 237 103 329 minecraft:moss_block
setblock 237 101 333 minecraft:mushroom_stem
fill 237 101 334 237 104 334 minecraft:moss_block
setblock 237 101 338 minecraft:mushroom_stem
fill 237 101 339 237 104 339 minecraft:moss_block
setblock 237 101 354 minecraft:moss_block
setblock 237 101 358 minecraft:mushroom_stem
fill 237 101 359 237 104 359 minecraft:moss_block
setblock 237 101 362 minecraft:moss_block
setblock 237 101 363 minecraft:mushroom_stem
fill 238 101 323 238 104 323 minecraft:moss_block
setblock 238 101 325 minecraft:light[level=15]
setblock 238 101 332 minecraft:mushroom_stem
fill 238 101 333 238 102 333 minecraft:moss_block
setblock 238 101 337 minecraft:mushroom_stem
fill 238 101 338 238 102 338 minecraft:moss_block
setblock 238 101 341 minecraft:light[level=15]
setblock 238 101 349 minecraft:light[level=15]
setblock 238 101 357 minecraft:light[level=15]
setblock 238 101 362 minecraft:mushroom_stem
fill 238 101 363 238 104 363 minecraft:moss_block
setblock 239 101 333 minecraft:mushroom_stem
fill 239 101 362 240 102 362 minecraft:moss_block
setblock 241 101 363 minecraft:moss_block
setblock 242 101 323 minecraft:mushroom_stem
setblock 242 101 363 minecraft:mushroom_stem
fill 243 101 323 246 101 323 minecraft:moss_block
fill 243 101 363 246 101 363 minecraft:moss_block
fill 245 101 352 247 103 353 minecraft:red_mushroom_block
setblock 246 101 325 minecraft:light[level=15]
setblock 246 101 333 minecraft:light[level=15]
setblock 246 101 341 minecraft:light[level=15]
setblock 246 101 349 minecraft:light[level=15]
setblock 246 101 357 minecraft:light[level=15]
fill 246 101 362 247 101 362 minecraft:moss_block
setblock 247 101 323 minecraft:mushroom_stem
setblock 247 101 363 minecraft:mushroom_stem
fill 248 101 323 248 104 323 minecraft:moss_block
fill 248 101 353 248 103 353 minecraft:red_mushroom_block
setblock 248 101 361 minecraft:moss_block
setblock 248 101 362 minecraft:mushroom_stem
fill 248 101 363 248 104 363 minecraft:moss_block
setblock 249 101 361 minecraft:mushroom_stem
fill 249 101 362 249 104 362 minecraft:moss_block
setblock 250 101 360 minecraft:mushroom_stem
fill 250 101 361 253 101 361 minecraft:moss_block
setblock 251 101 324 minecraft:mushroom_stem
fill 251 101 360 251 104 360 minecraft:moss_block
setblock 252 101 323 minecraft:mushroom_stem
fill 252 101 324 252 103 324 minecraft:moss_block
setblock 252 101 363 minecraft:mushroom_stem
fill 253 101 323 253 104 323 minecraft:moss_block
fill 253 101 359 253 102 359 minecraft:moss_block
setblock 253 101 362 minecraft:mushroom_stem
fill 253 101 363 253 104 363 minecraft:moss_block
setblock 254 101 325 minecraft:light[level=15]
setblock 254 101 333 minecraft:light[level=15]
setblock 254 101 341 minecraft:light[level=15]
setblock 254 101 349 minecraft:light[level=15]
setblock 254 101 357 minecraft:light[level=15]
setblock 254 101 360 minecraft:moss_block
setblock 254 101 361 minecraft:mushroom_stem
fill 254 101 362 254 104 362 minecraft:moss_block
setblock 255 101 359 minecraft:moss_block
setblock 255 101 360 minecraft:mushroom_stem
fill 255 101 361 255 104 361 minecraft:moss_block
setblock 256 101 359 minecraft:mushroom_stem
fill 256 101 360 256 104 360 minecraft:moss_block
setblock 257 101 323 minecraft:mushroom_stem
setblock 257 101 363 minecraft:mushroom_stem
setblock 258 101 323 minecraft:moss_block
fill 258 101 360 258 102 360 minecraft:moss_block
setblock 258 101 362 minecraft:mushroom_stem
fill 258 101 363 258 104 363 minecraft:moss_block
setblock 259 101 361 minecraft:mushroom_stem
fill 259 101 362 259 104 362 minecraft:moss_block
setblock 260 101 361 minecraft:moss_block
fill 261 101 362 261 102 362 minecraft:moss_block
fill 262 101 322 270 115 322 minecraft:brown_terracotta
setblock 262 101 325 minecraft:light[level=15]
setblock 262 101 333 minecraft:light[level=15]
setblock 262 101 341 minecraft:light[level=15]
setblock 262 101 349 minecraft:light[level=15]
setblock 262 101 357 minecraft:light[level=15]
setblock 262 101 363 minecraft:mushroom_stem
fill 263 101 363 263 102 363 minecraft:moss_block
setblock 264 101 363 minecraft:red_mushroom_block
fill 269 101 363 271 101 363 minecraft:moss_block
setblock 270 101 325 minecraft:light[level=15]
setblock 270 101 333 minecraft:light[level=15]
setblock 270 101 341 minecraft:light[level=15]
setblock 270 101 349 minecraft:light[level=15]
setblock 270 101 357 minecraft:light[level=15]
setblock 271 101 322 minecraft:shroomlight
fill 271 101 362 272 101 362 minecraft:moss_block
fill 272 101 322 272 143 322 minecraft:brown_terracotta
setblock 272 101 323 minecraft:mushroom_stem
setblock 272 101 363 minecraft:mushroom_stem
fill 273 101 323 273 104 323 minecraft:moss_block
fill 273 101 333 273 102 333 minecraft:moss_block
setblock 273 101 336 minecraft:moss_block
setblock 273 101 337 minecraft:mushroom_stem
fill 273 101 338 273 104 338 minecraft:moss_block
setblock 273 101 362 minecraft:mushroom_stem
fill 273 101 363 273 104 363 minecraft:moss_block
setblock 274 101 330 minecraft:moss_block
setblock 274 101 331 minecraft:mushroom_stem
fill 274 101 332 274 104 332 minecraft:moss_block
setblock 274 101 336 minecraft:mushroom_stem
fill 274 101 337 274 104 337 minecraft:moss_block
setblock 274 101 340 minecraft:moss_block
setblock 274 101 341 minecraft:mushroom_stem
fill 274 101 342 274 104 342 minecraft:moss_block
setblock 274 101 352 minecraft:moss_block
setblock 274 101 356 minecraft:mushroom_stem
fill 274 101 357 274 102 357 minecraft:moss_block
fill 274 101 362 274 104 362 minecraft:moss_block
setblock 275 101 330 minecraft:mushroom_stem
fill 275 101 331 275 104 331 minecraft:moss_block
setblock 275 101 335 minecraft:mushroom_stem
fill 275 101 336 275 104 336 minecraft:moss_block
setblock 275 101 340 minecraft:mushroom_stem
fill 275 101 341 275 104 341 minecraft:moss_block
setblock 275 101 345 minecraft:mushroom_stem
fill 275 101 346 275 104 346 minecraft:moss_block
setblock 275 101 350 minecraft:mushroom_stem
fill 275 101 351 275 102 351 minecraft:moss_block
setblock 275 101 355 minecraft:mushroom_stem
fill 275 101 356 275 103 356 minecraft:moss_block
setblock 275 101 360 minecraft:mushroom_stem
fill 275 101 361 275 104 361 minecraft:moss_block
setblock 276 101 324 minecraft:mushroom_stem
fill 276 101 325 276 104 325 minecraft:moss_block
setblock 276 101 329 minecraft:mushroom_stem
fill 276 101 330 276 104 330 minecraft:moss_block
setblock 276 101 334 minecraft:mushroom_stem
fill 276 101 335 276 104 335 minecraft:moss_block
setblock 276 101 339 minecraft:mushroom_stem
fill 276 101 340 276 104 340 minecraft:moss_block
setblock 276 101 344 minecraft:mushroom_stem
fill 276 101 345 276 104 345 minecraft:moss_block
setblock 276 101 349 minecraft:mushroom_stem
fill 276 101 350 276 103 350 minecraft:moss_block
setblock 276 101 354 minecraft:mushroom_stem
fill 276 101 355 276 104 355 minecraft:moss_block
setblock 276 101 359 minecraft:mushroom_stem
fill 276 101 360 276 104 360 minecraft:moss_block
setblock 236 102 323 minecraft:mushroom_stem
fill 236 102 324 236 105 324 minecraft:moss_block
setblock 236 102 328 minecraft:mushroom_stem
fill 236 102 329 236 105 329 minecraft:moss_block
setblock 236 102 333 minecraft:mushroom_stem
fill 236 102 334 236 105 334 minecraft:moss_block
setblock 236 102 338 minecraft:mushroom_stem
fill 236 102 339 236 105 339 minecraft:moss_block
setblock 236 102 343 minecraft:mushroom_stem
fill 236 102 344 236 105 344 minecraft:moss_block
setblock 236 102 353 minecraft:mushroom_stem
fill 236 102 354 236 103 354 minecraft:moss_block
setblock 236 102 358 minecraft:mushroom_stem
fill 236 102 359 236 105 359 minecraft:moss_block
setblock 236 102 363 minecraft:mushroom_stem
fill 237 102 323 237 105 323 minecraft:moss_block
setblock 237 102 327 minecraft:mushroom_stem
fill 237 102 328 237 103 328 minecraft:moss_block
setblock 237 102 332 minecraft:mushroom_stem
fill 237 102 333 237 104 333 minecraft:moss_block
setblock 237 102 337 minecraft:mushroom_stem
fill 237 102 338 237 105 338 minecraft:moss_block
setblock 237 102 342 minecraft:mushroom_stem
setblock 237 102 357 minecraft:mushroom_stem
fill 237 102 358 237 103 358 minecraft:moss_block
setblock 237 102 362 minecraft:mushroom_stem
fill 237 102 363 237 105 363 minecraft:moss_block
fill 238 102 331 242 105 331 minecraft:red_mushroom_block
setblock 238 102 332 minecraft:moss_block
setblock 238 102 336 minecraft:mushroom_stem
fill 238 102 337 238 103 337 minecraft:moss_block
fill 238 102 362 238 104 362 minecraft:moss_block
fill 239 102 332 239 105 335 minecraft:red_mushroom_block
fill 240 102 332 242 105 332 minecraft:red_mushroom_block
setblock 240 102 333 minecraft:mushroom_stem
fill 240 102 334 242 105 335 minecraft:red_mushroom_block
setblock 241 102 323 minecraft:mushroom_stem
fill 241 102 333 242 105 333 minecraft:red_mushroom_block
setblock 241 102 363 minecraft:mushroom_stem
fill 242 102 323 245 102 323 minecraft:moss_block
fill 242 102 363 245 102 363 minecraft:moss_block
fill 245 102 362 246 102 362 minecraft:moss_block
setblock 246 102 323 minecraft:mushroom_stem
fill 246 102 354 247 102 354 minecraft:red_mushroom_block
setblock 246 102 363 minecraft:mushroom_stem
fill 247 102 323 247 105 323 minecraft:moss_block
setblock 247 102 362 minecraft:mushroom_stem
fill 247 102 363 247 105 363 minecraft:moss_block
setblock 248 102 361 minecraft:mushroom_stem
fill 248 102 362 248 105 362 minecraft:moss_block
fill 249 102 361 252 102 361 minecraft:moss_block
fill 250 102 360 250 105 360 minecraft:moss_block
setblock 251 102 323 minecraft:mushroom_stem
setblock 251 102 324 minecraft:moss_block
setblock 251 102 363 minecraft:mushroom_stem
fill 252 102 323 252 105 323 minecraft:moss_block
setblock 252 102 362 minecraft:mushroom_stem
fill 252 102 363 252 105 363 minecraft:moss_block
setblock 253 102 361 minecraft:mushroom_stem
fill 253 102 362 253 105 362 minecraft:moss_block
setblock 254 102 360 minecraft:mushroom_stem
fill 254 102 361 254 105 361 minecraft:moss_block
fill 255 102 359 255 104 359 minecraft:mushroom_stem
fill 255 102 360 255 105 360 minecraft:moss_block
setblock 256 102 323 minecraft:mushroom_stem
setblock 256 102 363 minecraft:mushroom_stem
fill 257 102 323 257 103 323 minecraft:moss_block
setblock 257 102 362 minecraft:mushroom_stem
fill 257 102 363 257 105 363 minecraft:moss_block
setblock 258 102 361 minecraft:mushroom_stem
fill 258 102 362 258 105 362 minecraft:moss_block
fill 259 102 361 259 103 361 minecraft:moss_block
setblock 261 102 363 minecraft:mushroom_stem
fill 262 102 363 262 103 363 minecraft:moss_block
setblock 267 102 323 minecraft:red_mushroom_block
fill 268 102 363 270 102 363 minecraft:moss_block
fill 270 102 362 271 102 362 minecraft:moss_block
fill 271 102 322 271 147 322 minecraft:brown_terracotta
setblock 271 102 363 minecraft:mushroom_stem
fill 272 102 323 272 105 323 minecraft:moss_block
setblock 272 102 362 minecraft:mushroom_stem
fill 272 102 363 272 105 363 minecraft:moss_block
setblock 273 102 336 minecraft:mushroom_stem
fill 273 102 337 273 105 337 minecraft:moss_block
fill 273 102 339 273 102 340 minecraft:moss_block
setblock 273 102 341 minecraft:mushroom_stem
fill 273 102 342 273 105 342 minecraft:moss_block
fill 273 102 362 273 105 362 minecraft:moss_block
fill 273 102 364 275 104 364 minecraft:brown_terracotta
fill 274 102 331 274 103 331 minecraft:moss_block
setblock 274 102 335 minecraft:mushroom_stem
fill 274 102 336 274 105 336 minecraft:moss_block
setblock 274 102 340 minecraft:mushroom_stem
fill 274 102 341 274 105 341 minecraft:moss_block
fill 274 102 345 274 140 345 minecraft:mushroom_stem
setblock 274 102 355 minecraft:mushroom_stem
setblock 274 102 356 minecraft:moss_block
setblock 274 102 360 minecraft:mushroom_stem
setblock 275 102 329 minecraft:mushroom_stem
fill 275 102 330 275 104 330 minecraft:moss_block
setblock 275 102 334 minecraft:mushroom_stem
fill 275 102 335 275 105 335 minecraft:moss_block
setblock 275 102 339 minecraft:mushroom_stem
fill 275 102 340 275 105 340 minecraft:moss_block
setblock 275 102 344 minecraft:mushroom_stem
fill 275 102 345 275 105 345 minecraft:moss_block
setblock 275 102 349 minecraft:mushroom_stem
setblock 275 102 350 minecraft:moss_block
setblock 275 102 354 minecraft:mushroom_stem
fill 275 102 355 275 103 355 minecraft:moss_block
setblock 275 102 359 minecraft:mushroom_stem
fill 275 102 360 275 104 360 minecraft:moss_block
setblock 276 102 323 minecraft:mushroom_stem
fill 276 102 324 276 105 324 minecraft:moss_block
setblock 276 102 328 minecraft:mushroom_stem
fill 276 102 329 276 105 329 minecraft:moss_block
setblock 276 102 333 minecraft:mushroom_stem
fill 276 102 334 276 105 334 minecraft:moss_block
setblock 276 102 338 minecraft:mushroom_stem
fill 276 102 339 276 105 339 minecraft:moss_block
setblock 276 102 343 minecraft:mushroom_stem
fill 276 102 344 276 105 344 minecraft:moss_block
setblock 276 102 348 minecraft:mushroom_stem
fill 276 102 349 276 103 349 minecraft:moss_block
setblock 276 102 353 minecraft:mushroom_stem
fill 276 102 354 276 104 354 minecraft:moss_block
setblock 276 102 358 minecraft:mushroom_stem
fill 276 102 359 276 105 359 minecraft:moss_block
setblock 276 102 363 minecraft:mushroom_stem
setblock 276 102 364 minecraft:shroomlight
setblock 277 102 331 minecraft:shroomlight
fill 277 102 334 277 104 337 minecraft:brown_terracotta
setblock 277 102 338 minecraft:shroomlight
fill 277 102 364 277 148 364 minecraft:brown_terracotta
fill 235 103 322 235 147 325 minecraft:brown_terracotta
setblock 235 103 326 minecraft:shroomlight
fill 236 103 323 236 106 323 minecraft:moss_block
setblock 236 103 327 minecraft:mushroom_stem
fill 236 103 328 236 106 328 minecraft:moss_block
setblock 236 103 332 minecraft:mushroom_stem
fill 236 103 333 236 106 333 minecraft:moss_block
setblock 236 103 337 minecraft:mushroom_stem
fill 236 103 338 236 106 338 minecraft:moss_block
setblock 236 103 342 minecraft:mushroom_stem
fill 236 103 343 236 106 343 minecraft:moss_block
setblock 236 103 353 minecraft:moss_block
setblock 236 103 357 minecraft:mushroom_stem
fill 236 103 358 236 106 358 minecraft:moss_block
setblock 236 103 361 minecraft:moss_block
setblock 236 103 362 minecraft:mushroom_stem
fill 236 103 363 236 106 363 minecraft:moss_block
setblock 237 103 326 minecraft:mushroom_stem
setblock 237 103 327 minecraft:moss_block
setblock 237 103 331 minecraft:mushroom_stem
fill 237 103 332 237 104 332 minecraft:moss_block
setblock 237 103 336 minecraft:mushroom_stem
fill 237 103 337 237 105 337 minecraft:moss_block
setblock 237 103 341 minecraft:mushroom_stem
setblock 237 103 357 minecraft:moss_block
setblock 237 103 361 minecraft:mushroom_stem
fill 237 103 362 237 105 362 minecraft:moss_block
fill 238 103 332 238 105 334 minecraft:red_mushroom_block
setblock 238 103 335 minecraft:mushroom_stem
setblock 238 103 336 minecraft:moss_block
fill 239 103 330 241 104 330 minecraft:red_mushroom_block
fill 239 103 336 241 104 336 minecraft:red_mushroom_block
setblock 239 103 362 minecraft:moss_block
setblock 240 103 323 minecraft:mushroom_stem
fill 240 103 333 240 106 333 minecraft:red_mushroom_block
setblock 240 103 363 minecraft:mushroom_stem
fill 241 103 323 244 103 323 minecraft:moss_block
fill 241 103 363 244 103 363 minecraft:moss_block
fill 243 103 332 243 104 334 minecraft:red_mushroom_block
fill 244 103 362 245 103 362 minecraft:moss_block
setblock 245 103 323 minecraft:mushroom_stem
setblock 245 103 363 minecraft:mushroom_stem
fill 246 103 323 246 106 323 minecraft:moss_block
setblock 246 103 362 minecraft:mushroom_stem
fill 246 103 363 246 106 363 minecraft:moss_block
setblock 247 103 361 minecraft:mushroom_stem
fill 247 103 362 247 106 362 minecraft:moss_block
fill 248 103 361 251 103 361 minecraft:moss_block
fill 249 103 360 249 105 360 minecraft:moss_block
setblock 250 103 323 minecraft:mushroom_stem
setblock 250 103 363 minecraft:mushroom_stem
fill 251 103 323 251 106 323 minecraft:moss_block
setblock 251 103 362 minecraft:mushroom_stem
fill 251 103 363 251 106 363 minecraft:moss_block
setblock 252 103 361 minecraft:mushroom_stem
fill 252 103 362 252 106 362 minecraft:moss_block
setblock 253 103 360 minecraft:mushroom_stem
fill 253 103 361 253 106 361 minecraft:moss_block
fill 254 103 360 254 105 360 minecraft:moss_block
setblock 255 103 323 minecraft:mushroom_stem
setblock 255 103 363 minecraft:mushroom_stem
fill 256 103 323 256 105 323 minecraft:moss_block
setblock 256 103 362 minecraft:mushroom_stem
fill 256 103 363 256 106 363 minecraft:moss_block
setblock 257 103 361 minecraft:mushroom_stem
fill 257 103 362 257 106 362 minecraft:moss_block
fill 258 103 361 258 104 361 minecraft:moss_block
setblock 260 103 363 minecraft:mushroom_stem
setblock 261 103 323 minecraft:red_mushroom_block
fill 261 103 363 261 105 363 minecraft:moss_block
fill 265 103 350 265 105 352 minecraft:red_mushroom_block
fill 266 103 349 266 105 350 minecraft:red_mushroom_block
fill 266 103 352 267 105 352 minecraft:red_mushroom_block
fill 267 103 350 267 105 351 minecraft:red_mushroom_block
fill 267 103 363 269 103 363 minecraft:moss_block
fill 268 103 351 268 105 351 minecraft:red_mushroom_block
setblock 270 103 362 minecraft:moss_block
setblock 270 103 363 minecraft:mushroom_stem
fill 271 103 323 271 106 323 minecraft:moss_block
setblock 271 103 362 minecraft:mushroom_stem
fill 271 103 363 271 106 363 minecraft:moss_block
fill 272 103 362 272 106 362 minecraft:moss_block
setblock 273 103 335 minecraft:mushroom_stem
fill 273 103 336 273 105 336 minecraft:moss_block
setblock 273 103 339 minecraft:moss_block
setblock 273 103 340 minecraft:mushroom_stem
fill 273 103 341 273 106 341 minecraft:moss_block
setblock 274 103 334 minecraft:mushroom_stem
fill 274 103 335 274 106 335 minecraft:moss_block
setblock 274 103 339 minecraft:mushroom_stem
fill 274 103 340 274 106 340 minecraft:moss_block
setblock 274 103 344 minecraft:mushroom_stem
setblock 275 103 323 minecraft:mushroom_stem
setblock 275 103 329 minecraft:moss_block
setblock 275 103 333 minecraft:mushroom_stem
fill 275 103 334 275 106 334 minecraft:moss_block
setblock 275 103 338 minecraft:mushroom_stem
fill 275 103 339 275 106 339 minecraft:moss_block
setblock 275 103 343 minecraft:mushroom_stem
fill 275 103 344 275 106 344 minecraft:moss_block
setblock 275 103 353 minecraft:mushroom_stem
setblock 275 103 354 minecraft:moss_block
setblock 275 103 358 minecraft:mushroom_stem
fill 275 103 359 275 104 359 minecraft:moss_block
setblock 275 103 363 minecraft:mushroom_stem
fill 276 103 323 276 106 323 minecraft:moss_block
setblock 276 103 327 minecraft:mushroom_stem
fill 276 103 328 276 106 328 minecraft:moss_block
setblock 276 103 332 minecraft:mushroom_stem
fill 276 103 333 276 106 333 minecraft:moss_block
setblock 276 103 337 minecraft:mushroom_stem
fill 276 103 338 276 106 338 minecraft:moss_block
setblock 276 103 342 minecraft:mushroom_stem
fill 276 103 343 276 106 343 minecraft:moss_block
setblock 276 103 347 minecraft:mushroom_stem
fill 276 103 348 276 104 348 minecraft:moss_block
setblock 276 103 352 minecraft:mushroom_stem
fill 276 103 353 276 104 353 minecraft:moss_block
setblock 276 103 357 minecraft:mushroom_stem
fill 276 103 358 276 105 358 minecraft:moss_block
setblock 276 103 362 minecraft:mushroom_stem
fill 276 103 363 276 106 363 minecraft:moss_block
fill 276 103 364 276 143 364 minecraft:brown_terracotta
fill 277 103 331 277 147 331 minecraft:brown_terracotta
fill 277 103 338 277 147 338 minecraft:brown_terracotta
fill 235 104 326 235 147 326 minecraft:brown_terracotta
setblock 236 104 326 minecraft:mushroom_stem
fill 236 104 327 236 107 327 minecraft:moss_block
setblock 236 104 331 minecraft:mushroom_stem
fill 236 104 332 236 106 332 minecraft:moss_block
setblock 236 104 336 minecraft:mushroom_stem
fill 236 104 337 236 107 337 minecraft:moss_block
setblock 236 104 341 minecraft:mushroom_stem
fill 236 104 342 236 107 342 minecraft:moss_block
setblock 236 104 356 minecraft:mushroom_stem
fill 236 104 357 236 105 357 minecraft:moss_block
setblock 236 104 361 minecraft:mushroom_stem
fill 236 104 362 236 107 362 minecraft:moss_block
setblock 237 104 331 minecraft:moss_block
setblock 237 104 335 minecraft:mushroom_stem
fill 237 104 336 237 105 336 minecraft:moss_block
setblock 237 104 340 minecraft:mushroom_stem
setblock 237 104 341 minecraft:moss_block
setblock 237 104 360 minecraft:mushroom_stem
fill 237 104 361 237 105 361 minecraft:moss_block
fill 237 104 364 239 147 364 minecraft:brown_terracotta
fill 238 104 335 238 105 335 minecraft:red_mushroom_block
setblock 239 104 323 minecraft:mushroom_stem
setblock 239 104 363 minecraft:mushroom_stem
fill 240 104 323 243 104 323 minecraft:moss_block
fill 240 104 363 243 104 363 minecraft:moss_block
setblock 240 104 364 minecraft:shroomlight
fill 241 104 364 242 143 364 minecraft:brown_terracotta
setblock 244 104 323 minecraft:mushroom_stem
setblock 244 104 362 minecraft:moss_block
setblock 244 104 363 minecraft:mushroom_stem
fill 245 104 323 245 107 323 minecraft:moss_block
setblock 245 104 362 minecraft:mushroom_stem
fill 245 104 363 245 107 363 minecraft:moss_block
fill 246 104 362 246 107 362 minecraft:moss_block
fill 247 104 361 250 104 361 minecraft:moss_block
setblock 249 104 323 minecraft:mushroom_stem
setblock 249 104 363 minecraft:mushroom_stem
fill 250 104 323 250 107 323 minecraft:moss_block
setblock 250 104 362 minecraft:mushroom_stem
fill 250 104 363 250 107 363 minecraft:moss_block
setblock 251 104 361 minecraft:mushroom_stem
fill 251 104 362 251 107 362 minecraft:moss_block
setblock 252 104 360 minecraft:mushroom_stem
fill 252 104 361 252 107 361 minecraft:moss_block
fill 253 104 360 253 106 360 minecraft:moss_block
setblock 254 104 323 minecraft:mushroom_stem
setblock 254 104 363 minecraft:mushroom_stem
fill 255 104 323 255 107 323 minecraft:moss_block
setblock 255 104 362 minecraft:mushroom_stem
fill 255 104 363 255 107 363 minecraft:moss_block
setblock 256 104 361 minecraft:mushroom_stem
fill 256 104 362 256 107 362 minecraft:moss_block
fill 257 104 361 257 105 361 minecraft:moss_block
setblock 259 104 363 minecraft:mushroom_stem
fill 260 104 363 260 106 363 minecraft:moss_block
fill 264 104 350 264 104 351 minecraft:red_mushroom_block
setblock 265 104 349 minecraft:red_mushroom_block
fill 266 104 351 266 105 351 minecraft:red_mushroom_block
fill 266 104 353 267 104 353 minecraft:red_mushroom_block
setblock 267 104 349 minecraft:red_mushroom_block
fill 267 104 363 268 104 363 minecraft:moss_block
setblock 268 104 350 minecraft:red_mushroom_block
setblock 268 104 352 minecraft:red_mushroom_block
setblock 269 104 363 minecraft:mushroom_stem
setblock 270 104 362 minecraft:mushroom_stem
fill 270 104 363 270 107 363 minecraft:moss_block
fill 271 104 362 271 107 362 minecraft:moss_block
setblock 273 104 335 minecraft:moss_block
setblock 273 104 339 minecraft:mushroom_stem
fill 273 104 340 273 107 340 minecraft:moss_block
setblock 274 104 323 minecraft:mushroom_stem
setblock 274 104 333 minecraft:mushroom_stem
fill 274 104 334 274 105 334 minecraft:moss_block
setblock 274 104 338 minecraft:mushroom_stem
fill 274 104 339 274 107 339 minecraft:moss_block
setblock 274 104 343 minecraft:mushroom_stem
fill 274 104 344 274 105 344 minecraft:moss_block
setblock 274 104 363 minecraft:mushroom_stem
fill 275 104 323 275 107 323 minecraft:moss_block
setblock 275 104 332 minecraft:mushroom_stem
fill 275 104 333 275 106 333 minecraft:moss_block
setblock 275 104 337 minecraft:mushroom_stem
fill 275 104 338 275 107 338 minecraft:moss_block
setblock 275 104 342 minecraft:mushroom_stem
fill 275 104 343 275 107 343 minecraft:moss_block
fill 275 104 347 275 139 347 minecraft:mushroom_stem
setblock 275 104 357 minecraft:mushroom_stem
setblock 275 104 358 minecraft:moss_block
setblock 275 104 362 minecraft:mushroom_stem
fill 275 104 363 275 107 363 minecraft:moss_block
setblock 276 104 326 minecraft:mushroom_stem
fill 276 104 327 276 105 327 minecraft:moss_block
setblock 276 104 331 minecraft:mushroom_stem
fill 276 104 332 276 107 332 minecraft:moss_block
setblock 276 104 336 minecraft:mushroom_stem
fill 276 104 337 276 107 337 minecraft:moss_block
setblock 276 104 341 minecraft:mushroom_stem
fill 276 104 342 276 107 342 minecraft:moss_block
setblock 276 104 346 minecraft:mushroom_stem
fill 276 104 347 276 105 347 minecraft:moss_block
setblock 276 104 356 minecraft:mushroom_stem
fill 276 104 357 276 105 357 minecraft:moss_block
setblock 276 104 361 minecraft:mushroom_stem
fill 276 104 362 276 107 362 minecraft:moss_block
setblock 236 105 325 minecraft:mushroom_stem
fill 236 105 326 236 108 326 minecraft:moss_block
setblock 236 105 330 minecraft:mushroom_stem
fill 236 105 331 236 106 331 minecraft:moss_block
setblock 236 105 335 minecraft:mushroom_stem
fill 236 105 336 236 108 336 minecraft:moss_block
setblock 236 105 340 minecraft:mushroom_stem
fill 236 105 341 236 108 341 minecraft:moss_block
setblock 236 105 346 minecraft:red_mushroom_block
setblock 236 105 360 minecraft:mushroom_stem
fill 236 105 361 236 108 361 minecraft:moss_block
setblock 237 105 335 minecraft:moss_block
setblock 237 105 339 minecraft:mushroom_stem
setblock 237 105 340 minecraft:moss_block
setblock 238 105 323 minecraft:mushroom_stem
setblock 238 105 325 minecraft:light[level=12]
setblock 238 105 339 minecraft:light[level=12]
setblock 238 105 346 minecraft:light[level=12]
setblock 238 105 353 minecraft:light[level=12]
setblock 238 105 360 minecraft:light[level=12]
setblock 238 105 363 minecraft:mushroom_stem
fill 239 105 323 242 105 323 minecraft:moss_block
fill 239 105 363 242 105 363 minecraft:moss_block
fill 240 105 364 240 147 364 minecraft:brown_terracotta
setblock 243 105 323 minecraft:mushroom_stem
setblock 243 105 363 minecraft:mushroom_stem
fill 244 105 323 244 108 323 minecraft:moss_block
fill 244 105 356 248 106 360 minecraft:dirt
setblock 244 105 362 minecraft:mushroom_stem
fill 244 105 363 244 108 363 minecraft:moss_block
setblock 245 105 325 minecraft:light[level=12]
setblock 245 105 332 minecraft:light[level=12]
setblock 245 105 339 minecraft:light[level=12]
setblock 245 105 346 minecraft:light[level=12]
setblock 245 105 353 minecraft:light[level=12]
fill 245 105 362 245 108 362 minecraft:moss_block
setblock 246 105 361 minecraft:dirt
fill 247 105 361 249 105 361 minecraft:moss_block
setblock 248 105 323 minecraft:mushroom_stem
fill 248 105 325 252 105 327 minecraft:brown_mushroom_block
setblock 248 105 363 minecraft:mushroom_stem
fill 249 105 323 249 108 323 minecraft:moss_block
fill 249 105 324 251 105 324 minecraft:brown_mushroom_block
fill 249 105 328 251 105 328 minecraft:brown_mushroom_block
setblock 249 105 362 minecraft:mushroom_stem
fill 249 105 363 249 108 363 minecraft:moss_block
setblock 250 105 361 minecraft:mushroom_stem
fill 250 105 362 250 108 362 minecraft:moss_block
setblock 251 105 360 minecraft:mushroom_stem
fill 251 105 361 251 108 361 minecraft:moss_block
setblock 252 105 332 minecraft:light[level=12]
setblock 252 105 339 minecraft:light[level=12]
setblock 252 105 346 minecraft:light[level=12]
setblock 252 105 353 minecraft:light[level=12]
fill 252 105 360 252 107 360 minecraft:moss_block
setblock 253 105 323 minecraft:mushroom_stem
fill 253 105 356 254 108 359 minecraft:red_mushroom_block
setblock 253 105 363 minecraft:mushroom_stem
fill 254 105 323 254 108 323 minecraft:moss_block
setblock 254 105 362 minecraft:mushroom_stem
fill 254 105 363 254 108 363 minecraft:moss_block
fill 255 105 356 255 108 357 minecraft:red_mushroom_block
setblock 255 105 358 minecraft:mushroom_stem
fill 255 105 359 257 108 359 minecraft:red_mushroom_block
setblock 255 105 361 minecraft:mushroom_stem
fill 255 105 362 255 108 362 minecraft:moss_block
fill 256 105 358 256 108 358 minecraft:red_mushroom_block
fill 256 105 360 257 108 360 minecraft:red_mushroom_block
fill 256 105 361 256 106 361 minecraft:moss_block
setblock 258 105 363 minecraft:mushroom_stem
setblock 259 105 325 minecraft:light[level=12]
setblock 259 105 332 minecraft:light[level=12]
setblock 259 105 339 minecraft:light[level=12]
setblock 259 105 346 minecraft:light[level=12]
setblock 259 105 353 minecraft:light[level=12]
setblock 259 105 360 minecraft:light[level=12]
setblock 259 105 362 minecraft:mushroom_stem
fill 259 105 363 259 108 363 minecraft:moss_block
setblock 263 105 363 minecraft:red_mushroom_block
setblock 266 105 325 minecraft:light[level=12]
setblock 266 105 332 minecraft:light[level=12]
setblock 266 105 339 minecraft:light[level=12]
setblock 266 105 346 minecraft:light[level=12]
setblock 266 105 353 minecraft:light[level=12]
setblock 266 105 360 minecraft:light[level=12]
setblock 266 105 364 minecraft:red_mushroom_block
setblock 267 105 363 minecraft:moss_block
setblock 268 105 323 minecraft:red_mushroom_block
setblock 268 105 363 minecraft:mushroom_stem
fill 269 105 363 269 108 363 minecraft:moss_block
fill 270 105 323 270 107 323 minecraft:moss_block
fill 270 105 362 270 108 362 minecraft:moss_block
setblock 273 105 323 minecraft:mushroom_stem
setblock 273 105 325 minecraft:light[level=12]
setblock 273 105 332 minecraft:light[level=12]
setblock 273 105 338 minecraft:mushroom_stem
fill 273 105 339 273 107 339 minecraft:moss_block
setblock 273 105 353 minecraft:light[level=12]
setblock 273 105 360 minecraft:light[level=12]
setblock 273 105 363 minecraft:mushroom_stem
fill 273 105 364 274 135 364 minecraft:brown_terracotta
fill 274 105 323 274 108 323 minecraft:moss_block
setblock 274 105 337 minecraft:mushroom_stem
fill 274 105 338 274 108 338 minecraft:moss_block
setblock 274 105 342 minecraft:mushroom_stem
fill 274 105 343 274 108 343 minecraft:moss_block
setblock 274 105 362 minecraft:mushroom_stem
fill 274 105 363 274 108 363 minecraft:moss_block
setblock 275 105 331 minecraft:mushroom_stem
fill 275 105 332 275 106 332 minecraft:moss_block
setblock 275 105 336 minecraft:mushroom_stem
fill 275 105 337 275 108 337 minecraft:moss_block
setblock 275 105 341 minecraft:mushroom_stem
fill 275 105 342 275 108 342 minecraft:moss_block
fill 275 105 346 275 111 346 minecraft:mushroom_stem
setblock 275 105 364 minecraft:shroomlight
setblock 276 105 325 minecraft:mushroom_stem
fill 276 105 326 276 108 326 minecraft:moss_block
setblock 276 105 330 minecraft:mushroom_stem
fill 276 105 331 276 107 331 minecraft:moss_block
setblock 276 105 335 minecraft:mushroom_stem
fill 276 105 336 276 108 336 minecraft:moss_block
setblock 276 105 340 minecraft:mushroom_stem
fill 276 105 341 276 108 341 minecraft:moss_block
setblock 276 105 345 minecraft:mushroom_stem
fill 276 105 346 276 108 346 minecraft:moss_block
setblock 276 105 356 minecraft:moss_block
setblock 276 105 360 minecraft:mushroom_stem
fill 276 105 361 276 107 361 minecraft:moss_block
fill 277 105 334 277 129 334 minecraft:brown_terracotta
setblock 277 105 335 minecraft:shroomlight
fill 277 105 336 277 112 337 minecraft:brown_terracotta
setblock 236 106 324 minecraft:mushroom_stem
fill 236 106 325 236 109 325 minecraft:moss_block
setblock 236 106 329 minecraft:mushroom_stem
setblock 236 106 330 minecraft:moss_block
setblock 236 106 334 minecraft:mushroom_stem
fill 236 106 335 236 107 335 minecraft:moss_block
setblock 236 106 339 minecraft:mushroom_stem
fill 236 106 340 236 109 340 minecraft:moss_block
setblock 236 106 352 minecraft:red_mushroom_block
setblock 236 106 359 minecraft:mushroom_stem
fill 236 106 360 236 109 360 minecraft:moss_block
setblock 237 106 323 minecraft:mushroom_stem
setblock 237 106 363 minecraft:mushroom_stem
fill 238 106 323 241 106 323 minecraft:moss_block
fill 238 106 363 241 106 363 minecraft:moss_block
setblock 242 106 323 minecraft:mushroom_stem
setblock 242 106 363 minecraft:mushroom_stem
fill 243 106 323 243 109 323 minecraft:moss_block
fill 243 106 363 243 109 363 minecraft:moss_block
fill 244 106 362 244 109 362 minecraft:moss_block
setblock 247 106 323 minecraft:mushroom_stem
fill 247 106 361 248 106 361 minecraft:moss_block
setblock 247 106 363 minecraft:mushroom_stem
fill 248 106 323 248 109 323 minecraft:moss_block
setblock 248 106 362 minecraft:mushroom_stem
fill 248 106 363 248 109 363 minecraft:moss_block
setblock 249 106 361 minecraft:mushroom_stem
fill 249 106 362 249 109 362 minecraft:moss_block
setblock 250 106 360 minecraft:mushroom_stem
fill 250 106 361 250 109 361 minecraft:moss_block
fill 251 106 360 251 108 360 minecraft:moss_block
setblock 252 106 323 minecraft:mushroom_stem
fill 252 106 357 252 107 359 minecraft:red_mushroom_block
setblock 252 106 363 minecraft:mushroom_stem
fill 253 106 323 253 109 323 minecraft:moss_block
setblock 253 106 362 minecraft:mushroom_stem
fill 253 106 363 253 109 363 minecraft:moss_block
fill 254 106 355 255 107 355 minecraft:red_mushroom_block
fill 254 106 360 255 108 360 minecraft:red_mushroom_block
setblock 254 106 361 minecraft:mushroom_stem
fill 254 106 362 254 109 362 minecraft:moss_block
fill 255 106 358 255 109 358 minecraft:red_mushroom_block
fill 255 106 361 255 107 361 minecraft:moss_block
setblock 257 106 363 minecraft:mushroom_stem
fill 258 106 359 258 107 359 minecraft:red_mushroom_block
setblock 258 106 362 minecraft:mushroom_stem
fill 258 106 363 258 109 363 minecraft:moss_block
setblock 262 106 323 minecraft:red_mushroom_block
setblock 266 106 363 minecraft:moss_block
fill 266 106 364 266 143 364 minecraft:brown_terracotta
setblock 267 106 363 minecraft:mushroom_stem
fill 268 106 363 268 109 363 minecraft:moss_block
fill 269 106 323 269 108 323 minecraft:moss_block
setblock 272 106 323 minecraft:mushroom_stem
setblock 272 106 363 minecraft:mushroom_stem
fill 273 106 323 273 109 323 minecraft:moss_block
setblock 273 106 337 minecraft:mushroom_stem
setblock 273 106 338 minecraft:moss_block
setblock 273 106 362 minecraft:mushroom_stem
fill 273 106 363 273 109 363 minecraft:moss_block
setblock 274 106 336 minecraft:mushroom_stem
fill 274 106 337 274 108 337 minecraft:moss_block
setblock 274 106 341 minecraft:mushroom_stem
fill 274 106 342 274 109 342 minecraft:moss_block
setblock 275 106 335 minecraft:mushroom_stem
fill 275 106 336 275 109 336 minecraft:moss_block
setblock 275 106 340 minecraft:mushroom_stem
fill 275 106 341 275 109 341 minecraft:moss_block
setblock 275 106 345 minecraft:mushroom_stem
fill 275 106 364 275 115 364 minecraft:brown_terracotta
setblock 276 106 324 minecraft:mushroom_stem
fill 276 106 325 276 109 325 minecraft:moss_block
setblock 276 106 329 minecraft:mushroom_stem
fill 276 106 330 276 107 330 minecraft:moss_block
setblock 276 106 334 minecraft:mushroom_stem
fill 276 106 335 276 109 335 minecraft:moss_block
setblock 276 106 339 minecraft:mushroom_stem
fill 276 106 340 276 109 340 minecraft:moss_block
setblock 276 106 344 minecraft:mushroom_stem
fill 276 106 345 276 109 345 minecraft:moss_block
setblock 276 106 353 minecraft:red_mushroom_block
setblock 276 106 359 minecraft:mushroom_stem
fill 276 106 360 276 107 360 minecraft:moss_block
fill 277 106 335 277 144 335 minecraft:brown_terracotta
setblock 236 107 323 minecraft:mushroom_stem
fill 236 107 324 236 110 324 minecraft:moss_block
setblock 236 107 328 minecraft:mushroom_stem
setblock 236 107 333 minecraft:mushroom_stem
setblock 236 107 334 minecraft:moss_block
setblock 236 107 338 minecraft:mushroom_stem
fill 236 107 339 236 109 339 minecraft:moss_block
setblock 236 107 343 minecraft:mushroom_stem
setblock 236 107 358 minecraft:red_mushroom_block
fill 236 107 359 236 108 359 minecraft:moss_block
setblock 236 107 363 minecraft:mushroom_stem
fill 237 107 323 240 107 323 minecraft:moss_block
fill 237 107 363 240 107 363 minecraft:moss_block
setblock 241 107 323 minecraft:mushroom_stem
setblock 241 107 363 minecraft:mushroom_stem
fill 242 107 323 242 110 323 minecraft:moss_block
fill 242 107 363 242 110 363 minecraft:moss_block
fill 243 107 362 243 110 362 minecraft:moss_block
fill 245 107 358 247 113 358 minecraft:mushroom_stem
setblock 246 107 323 minecraft:mushroom_stem
fill 246 107 357 246 113 357 minecraft:mushroom_stem
fill 246 107 359 246 113 359 minecraft:mushroom_stem
fill 246 107 361 247 107 361 minecraft:moss_block
setblock 246 107 363 minecraft:mushroom_stem
fill 247 107 323 247 110 323 minecraft:moss_block
setblock 247 107 362 minecraft:mushroom_stem
fill 247 107 363 247 110 363 minecraft:moss_block
fill 248 107 324 249 107 324 minecraft:moss_block
setblock 248 107 361 minecraft:mushroom_stem
fill 248 107 362 248 110 362 minecraft:moss_block
fill 249 107 361 249 110 361 minecraft:moss_block
setblock 250 107 324 minecraft:mushroom_stem
fill 250 107 360 250 109 360 minecraft:moss_block
setblock 251 107 323 minecraft:mushroom_stem
fill 251 107 324 251 110 324 minecraft:moss_block
setblock 251 107 363 minecraft:mushroom_stem
fill 252 107 323 252 110 323 minecraft:moss_block
setblock 252 107 362 minecraft:mushroom_stem
fill 252 107 363 252 110 363 minecraft:moss_block
fill 253 107 360 253 108 360 minecraft:red_mushroom_block
setblock 253 107 361 minecraft:mushroom_stem
fill 253 107 362 253 110 362 minecraft:moss_block
fill 254 107 361 254 109 361 minecraft:moss_block
setblock 256 107 323 minecraft:red_mushroom_block
setblock 256 107 361 minecraft:red_mushroom_block
setblock 256 107 363 minecraft:mushroom_stem
setblock 257 107 362 minecraft:mushroom_stem
fill 257 107 363 257 110 363 minecraft:moss_block
setblock 266 107 363 minecraft:mushroom_stem
fill 267 107 363 267 110 363 minecraft:moss_block
fill 268 107 323 268 109 323 minecraft:moss_block
fill 269 107 362 269 109 362 minecraft:moss_block
setblock 271 107 323 minecraft:mushroom_stem
setblock 271 107 363 minecraft:mushroom_stem
fill 272 107 323 272 110 323 minecraft:moss_block
setblock 272 107 362 minecraft:mushroom_stem
fill 272 107 363 272 110 363 minecraft:moss_block
setblock 273 107 341 minecraft:mushroom_stem
setblock 274 107 336 minecraft:moss_block
setblock 274 107 340 minecraft:mushroom_stem
fill 274 107 341 274 110 341 minecraft:moss_block
setblock 275 107 334 minecraft:mushroom_stem
fill 275 107 335 275 108 335 minecraft:moss_block
setblock 275 107 339 minecraft:mushroom_stem
fill 275 107 340 275 110 340 minecraft:moss_block
setblock 275 107 344 minecraft:mushroom_stem
fill 275 107 345 275 110 345 minecraft:moss_block
setblock 276 107 323 minecraft:mushroom_stem
fill 276 107 324 276 110 324 minecraft:moss_block
setblock 276 107 333 minecraft:mushroom_stem
fill 276 107 334 276 110 334 minecraft:moss_block
setblock 276 107 338 minecraft:mushroom_stem
fill 276 107 339 276 110 339 minecraft:moss_block
setblock 276 107 343 minecraft:mushroom_stem
fill 276 107 344 276 110 344 minecraft:moss_block
setblock 276 107 347 minecraft:red_mushroom_block
setblock 276 107 363 minecraft:mushroom_stem
fill 236 108 323 239 108 323 minecraft:moss_block
setblock 236 108 327 minecraft:mushroom_stem
setblock 236 108 337 minecraft:mushroom_stem
fill 236 108 338 236 109 338 minecraft:moss_block
setblock 236 108 342 minecraft:mushroom_stem
fill 236 108 343 236 111 343 minecraft:moss_block
setblock 236 108 345 minecraft:red_mushroom_block
setblock 236 108 362 minecraft:mushroom_stem
fill 236 108 363 239 108 363 minecraft:moss_block
setblock 240 108 323 minecraft:mushroom_stem
setblock 240 108 363 minecraft:mushroom_stem
fill 241 108 323 241 111 323 minecraft:moss_block
fill 241 108 363 241 111 363 minecraft:moss_block
fill 242 108 362 242 111 362 minecraft:moss_block
setblock 245 108 323 minecraft:mushroom_stem
setblock 245 108 363 minecraft:mushroom_stem
fill 246 108 323 246 110 324 minecraft:moss_block
setblock 246 108 361 minecraft:moss_block
setblock 246 108 362 minecraft:mushroom_stem
fill 246 108 363 246 111 363 minecraft:moss_block
fill 247 108 324 248 108 324 minecraft:moss_block
setblock 247 108 361 minecraft:mushroom_stem
fill 247 108 362 247 111 362 minecraft:moss_block
fill 248 108 361 248 111 361 minecraft:moss_block
setblock 249 108 324 minecraft:mushroom_stem
setblock 250 108 323 minecraft:mushroom_stem
fill 250 108 324 250 111 324 minecraft:moss_block
setblock 250 108 363 minecraft:mushroom_stem
fill 251 108 323 251 111 323 minecraft:moss_block
setblock 251 108 362 minecraft:mushroom_stem
fill 251 108 363 251 111 363 minecraft:moss_block
setblock 252 108 361 minecraft:mushroom_stem
fill 252 108 362 252 111 362 minecraft:moss_block
fill 253 108 361 253 111 361 minecraft:moss_block
setblock 255 108 323 minecraft:mushroom_stem
setblock 255 108 363 minecraft:mushroom_stem
setblock 256 108 362 minecraft:mushroom_stem
fill 256 108 363 256 111 363 minecraft:moss_block
setblock 257 108 362 minecraft:moss_block
setblock 262 108 363 minecraft:red_mushroom_block
setblock 265 108 363 minecraft:mushroom_stem
fill 266 108 363 266 111 363 minecraft:moss_block
fill 267 108 323 267 110 323 minecraft:moss_block
setblock 270 108 323 minecraft:mushroom_stem
setblock 270 108 363 minecraft:mushroom_stem
fill 271 108 323 271 110 324 minecraft:moss_block
setblock 271 108 362 minecraft:mushroom_stem
fill 271 108 363 271 111 363 minecraft:moss_block
fill 272 108 324 273 108 324 minecraft:moss_block
fill 272 108 362 272 111 362 minecraft:moss_block
setblock 274 108 339 minecraft:mushroom_stem
fill 274 108 340 274 111 340 minecraft:moss_block
setblock 275 108 323 minecraft:mushroom_stem
setblock 275 108 338 minecraft:mushroom_stem
fill 275 108 339 275 111 339 minecraft:moss_block
setblock 275 108 343 minecraft:mushroom_stem
fill 275 108 344 275 111 344 minecraft:moss_block
setblock 275 108 363 minecraft:mushroom_stem
fill 276 108 323 276 111 323 minecraft:moss_block
setblock 276 108 327 minecraft:mushroom_stem
setblock 276 108 332 minecraft:mushroom_stem
fill 276 108 333 276 111 333 minecraft:moss_block
setblock 276 108 337 minecraft:mushroom_stem
fill 276 108 338 276 111 338 minecraft:moss_block
setblock 276 108 342 minecraft:mushroom_stem
fill 276 108 343 276 111 343 minecraft:moss_block
setblock 276 108 360 minecraft:red_mushroom_block
setblock 276 108 362 minecraft:mushroom_stem
fill 276 108 363 276 111 363 minecraft:moss_block
fill 235 109 351 236 109 351 minecraft:red_mushroom_block
fill 236 109 323 238 109 323 minecraft:moss_block
setblock 236 109 326 minecraft:mushroom_stem
fill 236 109 327 236 111 328 minecraft:moss_block
setblock 236 109 332 minecraft:red_mushroom_block
setblock 236 109 341 minecraft:mushroom_stem
fill 236 109 342 236 112 342 minecraft:moss_block
setblock 236 109 361 minecraft:mushroom_stem
fill 236 109 362 236 111 363 minecraft:moss_block
setblock 237 109 324 minecraft:moss_block
fill 237 109 363 238 109 363 minecraft:moss_block
setblock 238 109 325 minecraft:light[level=15]
setblock 238 109 333 minecraft:light[level=15]
setblock 238 109 341 minecraft:light[level=15]
setblock 238 109 349 minecraft:light[level=15]
setblock 238 109 357 minecraft:light[level=15]
setblock 239 109 323 minecraft:mushroom_stem
setblock 239 109 363 minecraft:mushroom_stem
fill 240 109 323 240 112 323 minecraft:moss_block
fill 240 109 363 240 112 363 minecraft:moss_block
fill 241 109 362 241 112 362 minecraft:moss_block
setblock 244 109 323 minecraft:mushroom_stem
fill 244 109 324 245 111 324 minecraft:moss_block
setblock 244 109 363 minecraft:mushroom_stem
fill 245 109 323 245 112 323 minecraft:moss_block
setblock 245 109 361 minecraft:moss_block
setblock 245 109 362 minecraft:mushroom_stem
fill 245 109 363 245 112 363 minecraft:moss_block
setblock 246 109 325 minecraft:light[level=15]
setblock 246 109 333 minecraft:light[level=15]
setblock 246 109 341 minecraft:light[level=15]
setblock 246 109 349 minecraft:light[level=15]
setblock 246 109 361 minecraft:mushroom_stem
fill 246 109 362 246 112 362 minecraft:moss_block
setblock 247 109 324 minecraft:moss_block
fill 247 109 361 247 112 361 minecraft:moss_block
setblock 248 109 324 minecraft:mushroom_stem
schedule function dropper:buildpart/77_2 1t
