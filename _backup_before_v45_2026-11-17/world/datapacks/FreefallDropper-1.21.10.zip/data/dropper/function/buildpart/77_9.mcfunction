fill 243 275 337 243 276 338 minecraft:white_concrete
fill 243 275 339 245 277 343 minecraft:red_mushroom_block
fill 243 275 344 243 275 345 minecraft:white_concrete
fill 243 275 346 245 276 350 minecraft:red_mushroom_block
fill 243 275 351 243 276 352 minecraft:white_concrete
fill 244 275 334 245 275 335 minecraft:red_mushroom_block
setblock 244 275 337 minecraft:white_concrete
fill 244 275 338 249 277 338 minecraft:red_mushroom_block
setblock 244 275 344 minecraft:white_concrete
fill 244 275 345 249 278 345 minecraft:red_mushroom_block
setblock 244 275 351 minecraft:white_concrete
fill 244 275 352 246 275 354 minecraft:red_mushroom_block
fill 245 275 333 246 275 333 minecraft:red_mushroom_block
fill 245 275 337 249 277 337 minecraft:red_mushroom_block
fill 245 275 344 249 278 344 minecraft:red_mushroom_block
fill 245 275 351 249 277 351 minecraft:red_mushroom_block
setblock 245 275 355 minecraft:red_mushroom_block
fill 246 275 334 247 275 334 minecraft:white_concrete
fill 246 275 335 266 276 335 minecraft:red_mushroom_block
fill 246 275 339 246 278 340 minecraft:red_mushroom_block
fill 246 275 341 247 275 341 minecraft:white_concrete
fill 246 275 342 252 278 343 minecraft:red_mushroom_block
fill 246 275 346 246 278 347 minecraft:red_mushroom_block
fill 246 275 348 247 275 348 minecraft:white_concrete
fill 246 275 349 268 276 350 minecraft:red_mushroom_block
fill 246 275 355 247 276 355 minecraft:white_concrete
fill 247 275 332 263 276 332 minecraft:red_mushroom_block
fill 247 275 333 247 276 333 minecraft:white_concrete
fill 247 275 339 269 275 339 minecraft:red_mushroom_block
setblock 247 275 340 minecraft:white_concrete
fill 247 275 346 251 278 346 minecraft:red_mushroom_block
setblock 247 275 347 minecraft:white_concrete
fill 247 275 352 249 277 353 minecraft:red_mushroom_block
setblock 247 275 354 minecraft:white_concrete
fill 247 275 356 263 276 356 minecraft:red_mushroom_block
fill 248 275 331 249 275 331 minecraft:red_mushroom_block
fill 248 275 333 252 277 334 minecraft:red_mushroom_block
fill 248 275 340 252 279 341 minecraft:red_mushroom_block
fill 248 275 347 252 278 348 minecraft:red_mushroom_block
fill 248 275 354 252 277 355 minecraft:red_mushroom_block
fill 248 275 357 262 275 357 minecraft:red_mushroom_block
fill 250 275 330 250 275 331 minecraft:white_concrete
fill 250 275 337 250 275 338 minecraft:white_concrete
fill 250 275 344 250 275 345 minecraft:white_concrete
fill 250 275 351 250 275 352 minecraft:white_concrete
fill 250 275 353 266 276 353 minecraft:red_mushroom_block
fill 250 275 358 251 275 358 minecraft:white_concrete
setblock 251 275 330 minecraft:white_concrete
fill 251 275 331 256 276 331 minecraft:red_mushroom_block
setblock 251 275 337 minecraft:white_concrete
fill 251 275 338 256 279 338 minecraft:red_mushroom_block
setblock 251 275 344 minecraft:white_concrete
fill 251 275 345 251 278 345 minecraft:red_mushroom_block
setblock 251 275 351 minecraft:white_concrete
fill 251 275 352 256 278 352 minecraft:red_mushroom_block
fill 252 275 330 256 276 330 minecraft:red_mushroom_block
fill 252 275 337 256 279 337 minecraft:red_mushroom_block
fill 252 275 351 256 279 351 minecraft:red_mushroom_block
fill 252 275 358 256 276 358 minecraft:red_mushroom_block
fill 253 275 333 253 278 333 minecraft:red_mushroom_block
fill 253 275 334 254 275 334 minecraft:white_concrete
fill 253 275 340 253 279 340 minecraft:red_mushroom_block
fill 253 275 341 254 275 341 minecraft:white_concrete
fill 253 275 342 269 276 342 minecraft:red_mushroom_block
fill 253 275 348 254 275 348 minecraft:white_concrete
fill 253 275 354 253 278 354 minecraft:red_mushroom_block
fill 253 275 355 254 275 355 minecraft:white_concrete
setblock 254 275 333 minecraft:white_concrete
setblock 254 275 340 minecraft:white_concrete
setblock 254 275 354 minecraft:white_concrete
fill 255 275 333 259 277 334 minecraft:red_mushroom_block
fill 255 275 340 259 279 341 minecraft:red_mushroom_block
fill 255 275 348 259 278 348 minecraft:red_mushroom_block
fill 255 275 354 259 277 355 minecraft:red_mushroom_block
fill 256 275 343 269 276 343 minecraft:red_mushroom_block
fill 256 275 347 260 278 347 minecraft:red_mushroom_block
fill 257 275 330 257 275 331 minecraft:white_concrete
fill 257 275 337 257 275 338 minecraft:white_concrete
fill 257 275 344 257 275 345 minecraft:white_concrete
fill 257 275 346 269 276 346 minecraft:red_mushroom_block
fill 257 275 351 257 275 352 minecraft:white_concrete
fill 257 275 358 258 276 358 minecraft:white_concrete
fill 258 275 330 258 276 330 minecraft:white_concrete
fill 258 275 331 262 275 331 minecraft:red_mushroom_block
setblock 258 275 337 minecraft:white_concrete
fill 258 275 338 263 278 338 minecraft:red_mushroom_block
setblock 258 275 344 minecraft:white_concrete
fill 258 275 345 263 279 345 minecraft:red_mushroom_block
setblock 258 275 351 minecraft:white_concrete
fill 258 275 352 263 278 352 minecraft:red_mushroom_block
fill 259 275 330 260 275 330 minecraft:red_mushroom_block
fill 259 275 337 263 278 337 minecraft:red_mushroom_block
fill 259 275 344 263 279 344 minecraft:red_mushroom_block
fill 259 275 351 263 278 351 minecraft:red_mushroom_block
fill 259 275 358 260 275 358 minecraft:red_mushroom_block
fill 260 275 333 260 277 333 minecraft:red_mushroom_block
fill 260 275 334 261 275 334 minecraft:white_concrete
fill 260 275 340 260 279 340 minecraft:red_mushroom_block
fill 260 275 341 261 275 341 minecraft:white_concrete
fill 260 275 348 261 275 348 minecraft:white_concrete
fill 260 275 354 260 278 354 minecraft:red_mushroom_block
fill 260 275 355 261 275 355 minecraft:white_concrete
setblock 261 275 333 minecraft:white_concrete
setblock 261 275 340 minecraft:white_concrete
setblock 261 275 347 minecraft:white_concrete
setblock 261 275 354 minecraft:white_concrete
fill 262 275 333 265 275 334 minecraft:red_mushroom_block
fill 262 275 340 266 277 341 minecraft:red_mushroom_block
fill 262 275 347 266 277 348 minecraft:red_mushroom_block
fill 262 275 354 265 275 355 minecraft:red_mushroom_block
fill 264 275 337 264 275 338 minecraft:white_concrete
fill 264 275 344 264 275 345 minecraft:white_concrete
fill 264 275 351 264 275 352 minecraft:white_concrete
setblock 265 275 337 minecraft:white_concrete
fill 265 275 338 268 276 338 minecraft:red_mushroom_block
setblock 265 275 344 minecraft:white_concrete
fill 265 275 345 269 276 345 minecraft:red_mushroom_block
setblock 265 275 351 minecraft:white_concrete
fill 265 275 352 267 276 352 minecraft:red_mushroom_block
setblock 266 275 334 minecraft:red_mushroom_block
fill 266 275 337 268 275 337 minecraft:red_mushroom_block
fill 266 275 344 269 276 344 minecraft:red_mushroom_block
fill 266 275 351 268 275 351 minecraft:red_mushroom_block
setblock 266 275 354 minecraft:red_mushroom_block
fill 267 275 340 267 277 340 minecraft:red_mushroom_block
fill 267 275 341 268 275 341 minecraft:white_concrete
fill 267 275 347 267 277 347 minecraft:red_mushroom_block
fill 267 275 348 268 275 348 minecraft:white_concrete
fill 268 275 340 268 276 340 minecraft:white_concrete
setblock 268 275 347 minecraft:white_concrete
fill 269 275 340 269 275 341 minecraft:red_mushroom_block
fill 269 275 347 269 275 349 minecraft:red_mushroom_block
fill 277 275 328 277 295 328 minecraft:moss_block
fill 241 276 341 242 276 347 minecraft:red_mushroom_block
fill 242 276 338 242 276 340 minecraft:red_mushroom_block
fill 242 276 348 242 276 350 minecraft:red_mushroom_block
fill 243 276 344 243 276 345 minecraft:red_mushroom_block
fill 244 276 335 245 276 335 minecraft:red_mushroom_block
setblock 244 276 337 minecraft:red_mushroom_block
fill 244 276 344 244 277 344 minecraft:red_mushroom_block
fill 244 276 351 244 276 353 minecraft:red_mushroom_block
setblock 245 276 334 minecraft:red_mushroom_block
fill 245 276 352 246 276 354 minecraft:red_mushroom_block
setblock 246 276 333 minecraft:red_mushroom_block
setblock 246 276 334 minecraft:white_concrete
fill 246 276 341 247 277 341 minecraft:red_mushroom_block
fill 246 276 348 247 277 348 minecraft:red_mushroom_block
setblock 247 276 334 minecraft:red_mushroom_block
fill 247 276 339 247 277 340 minecraft:red_mushroom_block
fill 247 276 347 247 278 347 minecraft:red_mushroom_block
setblock 247 276 354 minecraft:red_mushroom_block
fill 248 276 339 268 276 339 minecraft:red_mushroom_block
setblock 249 276 331 minecraft:red_mushroom_block
fill 249 276 357 261 276 357 minecraft:red_mushroom_block
setblock 250 276 331 minecraft:white_concrete
fill 250 276 337 250 278 338 minecraft:red_mushroom_block
fill 250 276 344 250 278 345 minecraft:red_mushroom_block
fill 250 276 351 250 277 352 minecraft:red_mushroom_block
fill 251 276 337 251 278 337 minecraft:red_mushroom_block
fill 251 276 344 251 278 344 minecraft:red_mushroom_block
fill 251 276 351 251 278 351 minecraft:red_mushroom_block
fill 253 276 334 254 277 334 minecraft:red_mushroom_block
fill 253 276 341 254 278 341 minecraft:red_mushroom_block
fill 253 276 348 254 278 348 minecraft:red_mushroom_block
fill 253 276 355 254 277 355 minecraft:red_mushroom_block
fill 254 276 333 254 277 333 minecraft:red_mushroom_block
fill 254 276 340 254 278 340 minecraft:red_mushroom_block
fill 254 276 354 254 277 354 minecraft:red_mushroom_block
setblock 257 276 330 minecraft:white_concrete
fill 257 276 331 261 276 331 minecraft:red_mushroom_block
fill 257 276 337 257 278 338 minecraft:red_mushroom_block
fill 257 276 344 257 278 345 minecraft:red_mushroom_block
fill 257 276 351 257 278 352 minecraft:red_mushroom_block
fill 258 276 337 258 278 337 minecraft:red_mushroom_block
fill 258 276 344 258 278 344 minecraft:red_mushroom_block
fill 258 276 351 258 278 351 minecraft:red_mushroom_block
fill 260 276 334 265 276 334 minecraft:red_mushroom_block
fill 260 276 341 261 278 341 minecraft:red_mushroom_block
fill 260 276 348 261 278 348 minecraft:red_mushroom_block
fill 260 276 355 264 276 355 minecraft:red_mushroom_block
fill 261 276 333 264 276 333 minecraft:red_mushroom_block
fill 261 276 340 261 278 340 minecraft:red_mushroom_block
fill 261 276 347 261 278 347 minecraft:red_mushroom_block
fill 261 276 354 265 276 354 minecraft:red_mushroom_block
fill 264 276 337 264 277 338 minecraft:red_mushroom_block
fill 264 276 344 264 277 345 minecraft:red_mushroom_block
fill 264 276 351 264 276 352 minecraft:red_mushroom_block
fill 265 276 337 267 276 337 minecraft:red_mushroom_block
fill 265 276 344 265 277 344 minecraft:red_mushroom_block
fill 265 276 351 267 276 351 minecraft:red_mushroom_block
fill 267 276 341 269 276 341 minecraft:red_mushroom_block
setblock 267 276 348 minecraft:red_mushroom_block
fill 268 276 347 269 276 347 minecraft:red_mushroom_block
setblock 268 276 348 minecraft:white_concrete
fill 277 276 338 277 308 338 minecraft:moss_block
setblock 277 276 339 minecraft:red_mushroom_block
fill 277 276 340 277 308 340 minecraft:moss_block
setblock 238 277 325 minecraft:light[level=15]
setblock 238 277 333 minecraft:light[level=15]
setblock 238 277 341 minecraft:light[level=15]
setblock 238 277 349 minecraft:light[level=15]
setblock 238 277 357 minecraft:light[level=15]
fill 242 277 341 242 277 347 minecraft:red_mushroom_block
fill 243 277 344 243 277 345 minecraft:white_concrete
fill 243 277 346 245 277 349 minecraft:red_mushroom_block
setblock 244 277 337 minecraft:white_concrete
fill 244 277 350 266 277 350 minecraft:red_mushroom_block
setblock 244 277 351 minecraft:white_concrete
fill 245 277 336 265 277 336 minecraft:red_mushroom_block
fill 245 277 352 246 277 352 minecraft:red_mushroom_block
setblock 246 277 325 minecraft:light[level=15]
setblock 246 277 333 minecraft:light[level=15]
fill 246 277 335 264 277 335 minecraft:red_mushroom_block
fill 246 277 349 267 277 349 minecraft:red_mushroom_block
setblock 246 277 353 minecraft:red_mushroom_block
setblock 246 277 357 minecraft:light[level=15]
setblock 247 277 334 minecraft:white_concrete
setblock 247 277 354 minecraft:white_concrete
fill 248 277 339 267 277 339 minecraft:red_mushroom_block
fill 250 277 332 260 277 332 minecraft:red_mushroom_block
fill 250 277 353 264 277 353 minecraft:red_mushroom_block
fill 250 277 356 260 277 356 minecraft:red_mushroom_block
fill 252 277 331 256 277 331 minecraft:red_mushroom_block
fill 252 277 357 258 277 357 minecraft:red_mushroom_block
fill 253 277 342 268 277 342 minecraft:red_mushroom_block
setblock 254 277 325 minecraft:light[level=15]
fill 256 277 343 268 277 343 minecraft:red_mushroom_block
setblock 257 277 331 minecraft:white_concrete
fill 257 277 346 268 277 346 minecraft:red_mushroom_block
setblock 258 277 331 minecraft:red_mushroom_block
setblock 260 277 334 minecraft:red_mushroom_block
fill 260 277 355 261 277 355 minecraft:white_concrete
fill 261 277 333 261 277 334 minecraft:white_concrete
setblock 261 277 354 minecraft:white_concrete
setblock 262 277 325 minecraft:light[level=15]
fill 262 277 333 262 277 334 minecraft:red_mushroom_block
fill 262 277 354 262 277 355 minecraft:red_mushroom_block
setblock 262 277 357 minecraft:light[level=15]
setblock 263 277 334 minecraft:red_mushroom_block
setblock 263 277 354 minecraft:red_mushroom_block
setblock 264 277 351 minecraft:red_mushroom_block
setblock 264 277 352 minecraft:white_concrete
setblock 265 277 337 minecraft:white_concrete
fill 265 277 338 266 277 338 minecraft:red_mushroom_block
fill 265 277 345 268 277 345 minecraft:red_mushroom_block
setblock 265 277 351 minecraft:white_concrete
setblock 265 277 352 minecraft:red_mushroom_block
setblock 266 277 337 minecraft:red_mushroom_block
fill 266 277 344 268 277 344 minecraft:red_mushroom_block
setblock 266 277 351 minecraft:red_mushroom_block
fill 267 277 341 268 277 341 minecraft:white_concrete
setblock 267 277 348 minecraft:white_concrete
setblock 268 277 347 minecraft:white_concrete
setblock 270 277 325 minecraft:light[level=15]
setblock 270 277 333 minecraft:light[level=15]
setblock 270 277 341 minecraft:light[level=15]
setblock 270 277 349 minecraft:light[level=15]
setblock 270 277 357 minecraft:light[level=15]
fill 277 277 339 277 308 339 minecraft:moss_block
fill 244 278 341 245 278 343 minecraft:red_mushroom_block
setblock 244 278 344 minecraft:white_concrete
fill 244 278 346 245 278 347 minecraft:red_mushroom_block
fill 245 278 339 245 278 340 minecraft:red_mushroom_block
fill 245 278 348 245 278 349 minecraft:red_mushroom_block
fill 246 278 337 249 278 338 minecraft:red_mushroom_block
setblock 246 278 341 minecraft:white_concrete
fill 246 278 348 247 278 348 minecraft:white_concrete
fill 246 278 349 250 278 351 minecraft:red_mushroom_block
fill 247 278 336 263 278 336 minecraft:red_mushroom_block
fill 247 278 339 265 278 339 minecraft:red_mushroom_block
setblock 247 278 340 minecraft:white_concrete
setblock 247 278 341 minecraft:red_mushroom_block
fill 247 278 352 249 278 352 minecraft:red_mushroom_block
fill 248 278 335 262 278 335 minecraft:red_mushroom_block
fill 248 278 353 262 278 353 minecraft:red_mushroom_block
fill 250 278 334 252 278 334 minecraft:red_mushroom_block
setblock 250 278 352 minecraft:white_concrete
fill 250 278 354 252 278 354 minecraft:red_mushroom_block
fill 251 278 349 264 278 350 minecraft:red_mushroom_block
setblock 252 278 333 minecraft:red_mushroom_block
setblock 252 278 355 minecraft:red_mushroom_block
fill 253 278 334 254 278 334 minecraft:white_concrete
fill 253 278 342 266 278 342 minecraft:red_mushroom_block
fill 253 278 355 254 278 355 minecraft:white_concrete
setblock 254 278 333 minecraft:white_concrete
setblock 254 278 354 minecraft:white_concrete
fill 255 278 333 258 278 334 minecraft:red_mushroom_block
fill 255 278 354 258 278 355 minecraft:red_mushroom_block
fill 256 278 343 266 278 343 minecraft:red_mushroom_block
fill 257 278 346 266 278 346 minecraft:red_mushroom_block
setblock 259 278 334 minecraft:red_mushroom_block
setblock 259 278 354 minecraft:red_mushroom_block
setblock 260 278 334 minecraft:white_concrete
fill 262 278 340 265 278 341 minecraft:red_mushroom_block
fill 262 278 347 265 278 348 minecraft:red_mushroom_block
fill 264 278 337 264 278 338 minecraft:white_concrete
fill 264 278 344 264 278 345 minecraft:white_concrete
setblock 264 278 351 minecraft:white_concrete
setblock 265 278 344 minecraft:white_concrete
fill 265 278 345 266 278 345 minecraft:red_mushroom_block
setblock 265 278 349 minecraft:red_mushroom_block
setblock 266 278 341 minecraft:red_mushroom_block
setblock 266 278 344 minecraft:red_mushroom_block
setblock 266 278 347 minecraft:red_mushroom_block
setblock 277 278 335 minecraft:shroomlight
fill 236 279 323 246 279 363 minecraft:mushroom_stem
fill 247 279 323 247 279 340 minecraft:mushroom_stem
setblock 247 279 341 minecraft:white_concrete
fill 247 279 342 249 279 346 minecraft:red_mushroom_block
setblock 247 279 347 minecraft:white_concrete
fill 247 279 348 247 279 363 minecraft:mushroom_stem
fill 248 279 323 248 279 338 minecraft:mushroom_stem
fill 248 279 339 262 279 339 minecraft:red_mushroom_block
fill 248 279 347 250 279 349 minecraft:red_mushroom_block
fill 248 279 350 248 279 363 minecraft:mushroom_stem
fill 249 279 323 249 279 337 minecraft:mushroom_stem
setblock 249 279 338 minecraft:red_mushroom_block
fill 249 279 350 261 279 350 minecraft:red_mushroom_block
fill 249 279 351 249 279 363 minecraft:mushroom_stem
fill 250 279 323 251 279 336 minecraft:mushroom_stem
fill 250 279 337 250 279 338 minecraft:white_concrete
fill 250 279 342 250 279 343 minecraft:red_mushroom_block
fill 250 279 344 250 279 345 minecraft:white_concrete
setblock 250 279 346 minecraft:red_mushroom_block
fill 250 279 351 251 279 351 minecraft:white_concrete
fill 250 279 352 251 279 363 minecraft:mushroom_stem
setblock 251 279 322 minecraft:shroomlight
setblock 251 279 337 minecraft:white_concrete
setblock 251 279 342 minecraft:red_mushroom_block
fill 251 279 343 251 279 347 minecraft:shroomlight
fill 251 279 348 251 279 349 minecraft:red_mushroom_block
fill 252 279 323 276 279 335 minecraft:mushroom_stem
fill 252 279 336 258 279 336 minecraft:red_mushroom_block
fill 252 279 342 252 279 343 minecraft:shroomlight
fill 252 279 347 252 279 348 minecraft:shroomlight
fill 252 279 349 262 279 349 minecraft:red_mushroom_block
fill 252 279 352 256 279 352 minecraft:red_mushroom_block
fill 252 279 353 276 279 363 minecraft:mushroom_stem
fill 253 279 341 254 279 341 minecraft:white_concrete
fill 253 279 342 256 279 342 minecraft:shroomlight
fill 253 279 348 256 279 348 minecraft:shroomlight
setblock 254 279 340 minecraft:white_concrete
fill 256 279 343 257 279 343 minecraft:shroomlight
fill 256 279 347 257 279 347 minecraft:shroomlight
fill 257 279 337 257 279 338 minecraft:white_concrete
fill 257 279 342 263 279 342 minecraft:red_mushroom_block
fill 257 279 344 257 279 346 minecraft:shroomlight
fill 257 279 348 259 279 348 minecraft:red_mushroom_block
fill 257 279 351 257 279 352 minecraft:white_concrete
setblock 258 279 337 minecraft:white_concrete
fill 258 279 338 261 279 338 minecraft:red_mushroom_block
fill 258 279 343 263 279 343 minecraft:red_mushroom_block
setblock 258 279 344 minecraft:white_concrete
fill 258 279 346 260 279 347 minecraft:red_mushroom_block
setblock 258 279 351 minecraft:white_concrete
setblock 258 279 352 minecraft:red_mushroom_block
fill 259 279 336 276 279 336 minecraft:mushroom_stem
fill 259 279 337 260 279 337 minecraft:red_mushroom_block
fill 259 279 351 260 279 351 minecraft:red_mushroom_block
fill 259 279 352 276 279 352 minecraft:mushroom_stem
fill 260 279 341 261 279 341 minecraft:white_concrete
fill 260 279 348 261 279 348 minecraft:white_concrete
fill 261 279 337 276 279 337 minecraft:mushroom_stem
setblock 261 279 340 minecraft:white_concrete
fill 261 279 346 263 279 346 minecraft:red_mushroom_block
setblock 261 279 347 minecraft:white_concrete
fill 261 279 351 276 279 351 minecraft:mushroom_stem
fill 262 279 338 276 279 338 minecraft:mushroom_stem
fill 262 279 340 262 279 341 minecraft:red_mushroom_block
fill 262 279 347 262 279 348 minecraft:red_mushroom_block
fill 262 279 350 276 279 350 minecraft:mushroom_stem
fill 263 279 339 276 279 340 minecraft:mushroom_stem
setblock 263 279 341 minecraft:red_mushroom_block
setblock 263 279 347 minecraft:red_mushroom_block
fill 263 279 348 276 279 349 minecraft:mushroom_stem
fill 264 279 341 276 279 347 minecraft:mushroom_stem
fill 277 279 335 277 299 335 minecraft:moss_block
setblock 235 280 359 minecraft:shroomlight
setblock 236 280 364 minecraft:red_mushroom_block
fill 237 280 364 237 308 364 minecraft:moss_block
fill 251 280 322 251 308 322 minecraft:moss_block
setblock 258 280 322 minecraft:shroomlight
setblock 266 280 322 minecraft:red_mushroom_block
fill 267 280 322 267 292 322 minecraft:moss_block
setblock 275 280 364 minecraft:shroomlight
fill 235 281 359 235 308 359 minecraft:moss_block
fill 236 281 364 236 308 364 minecraft:moss_block
fill 258 281 322 258 308 322 minecraft:moss_block
fill 266 281 322 266 308 322 minecraft:moss_block
fill 275 281 364 275 308 364 minecraft:moss_block
setblock 235 282 362 minecraft:shroomlight
fill 235 283 362 235 308 362 minecraft:moss_block
setblock 236 283 324 minecraft:red_mushroom_block
setblock 236 283 332 minecraft:mushroom_stem
fill 236 283 333 236 283 336 minecraft:moss_block
setblock 236 283 337 minecraft:mushroom_stem
fill 236 283 338 236 283 341 minecraft:moss_block
setblock 236 283 342 minecraft:mushroom_stem
fill 236 283 343 236 283 346 minecraft:moss_block
setblock 236 283 347 minecraft:mushroom_stem
fill 236 283 348 236 283 351 minecraft:moss_block
setblock 236 283 352 minecraft:mushroom_stem
fill 236 283 353 236 283 356 minecraft:moss_block
setblock 236 283 357 minecraft:mushroom_stem
fill 236 283 358 236 283 361 minecraft:moss_block
setblock 236 283 362 minecraft:mushroom_stem
fill 236 283 363 239 283 363 minecraft:moss_block
fill 237 283 334 237 283 335 minecraft:moss_block
setblock 237 283 336 minecraft:mushroom_stem
fill 237 283 337 237 283 340 minecraft:moss_block
setblock 237 283 341 minecraft:mushroom_stem
fill 237 283 342 237 283 345 minecraft:moss_block
setblock 237 283 346 minecraft:mushroom_stem
fill 237 283 347 237 283 350 minecraft:moss_block
setblock 237 283 351 minecraft:mushroom_stem
fill 237 283 352 237 283 355 minecraft:moss_block
setblock 237 283 356 minecraft:mushroom_stem
fill 237 283 357 237 283 360 minecraft:moss_block
setblock 237 283 361 minecraft:mushroom_stem
fill 237 283 362 238 285 362 minecraft:moss_block
fill 238 283 337 238 283 339 minecraft:moss_block
setblock 238 283 340 minecraft:mushroom_stem
fill 238 283 341 238 285 342 minecraft:moss_block
fill 238 283 357 238 283 358 minecraft:moss_block
setblock 240 283 363 minecraft:mushroom_stem
setblock 241 283 363 minecraft:red_mushroom_block
setblock 246 283 323 minecraft:red_mushroom_block
fill 252 283 323 254 283 323 minecraft:moss_block
fill 252 283 363 254 283 363 minecraft:moss_block
fill 254 283 362 255 283 362 minecraft:moss_block
setblock 255 283 323 minecraft:mushroom_stem
fill 255 283 324 258 283 324 minecraft:moss_block
setblock 255 283 363 minecraft:mushroom_stem
fill 256 283 323 259 283 323 minecraft:moss_block
setblock 256 283 362 minecraft:mushroom_stem
fill 256 283 363 259 283 363 minecraft:moss_block
fill 257 283 362 260 283 362 minecraft:moss_block
setblock 259 283 324 minecraft:mushroom_stem
setblock 260 283 323 minecraft:mushroom_stem
setblock 260 283 363 minecraft:mushroom_stem
fill 261 283 323 263 284 323 minecraft:moss_block
setblock 261 283 362 minecraft:mushroom_stem
fill 261 283 363 264 283 363 minecraft:moss_block
fill 265 283 323 265 284 323 minecraft:red_mushroom_block
setblock 265 283 363 minecraft:mushroom_stem
fill 266 283 363 269 283 363 minecraft:moss_block
fill 269 283 362 270 283 362 minecraft:moss_block
setblock 270 283 363 minecraft:mushroom_stem
fill 271 283 323 274 283 323 minecraft:moss_block
setblock 271 283 361 minecraft:moss_block
setblock 271 283 362 minecraft:mushroom_stem
fill 271 283 363 274 283 363 minecraft:moss_block
setblock 272 283 361 minecraft:mushroom_stem
fill 272 283 362 275 283 362 minecraft:moss_block
fill 273 283 361 276 283 361 minecraft:moss_block
fill 274 283 355 274 283 358 minecraft:moss_block
setblock 274 283 359 minecraft:mushroom_stem
fill 274 283 360 276 284 360 minecraft:moss_block
setblock 275 283 323 minecraft:mushroom_stem
setblock 275 283 337 minecraft:moss_block
setblock 275 283 338 minecraft:mushroom_stem
fill 275 283 339 276 283 341 minecraft:moss_block
setblock 275 283 352 minecraft:moss_block
setblock 275 283 353 minecraft:mushroom_stem
fill 275 283 354 275 283 357 minecraft:moss_block
setblock 275 283 358 minecraft:mushroom_stem
fill 275 283 359 276 285 359 minecraft:moss_block
setblock 275 283 363 minecraft:mushroom_stem
fill 276 283 323 276 285 324 minecraft:moss_block
fill 276 283 333 276 283 336 minecraft:moss_block
setblock 276 283 337 minecraft:mushroom_stem
fill 276 283 338 276 286 338 minecraft:moss_block
setblock 276 283 342 minecraft:mushroom_stem
fill 276 283 343 276 283 346 minecraft:moss_block
setblock 276 283 347 minecraft:mushroom_stem
fill 276 283 348 276 283 351 minecraft:moss_block
setblock 276 283 352 minecraft:mushroom_stem
fill 276 283 353 276 283 356 minecraft:moss_block
setblock 276 283 357 minecraft:mushroom_stem
fill 276 283 358 276 286 358 minecraft:moss_block
setblock 276 283 362 minecraft:mushroom_stem
fill 276 283 363 276 286 363 minecraft:moss_block
setblock 236 284 330 minecraft:red_mushroom_block
fill 236 284 332 236 284 335 minecraft:moss_block
setblock 236 284 336 minecraft:mushroom_stem
fill 236 284 337 236 284 340 minecraft:moss_block
setblock 236 284 341 minecraft:mushroom_stem
fill 236 284 342 236 284 345 minecraft:moss_block
setblock 236 284 346 minecraft:mushroom_stem
fill 236 284 347 236 284 350 minecraft:moss_block
setblock 236 284 351 minecraft:mushroom_stem
fill 236 284 352 236 284 355 minecraft:moss_block
setblock 236 284 356 minecraft:mushroom_stem
fill 236 284 357 236 284 360 minecraft:moss_block
setblock 236 284 361 minecraft:mushroom_stem
fill 236 284 362 236 286 363 minecraft:moss_block
setblock 237 284 334 minecraft:moss_block
setblock 237 284 335 minecraft:mushroom_stem
fill 237 284 336 237 284 339 minecraft:moss_block
setblock 237 284 340 minecraft:mushroom_stem
fill 237 284 341 237 284 344 minecraft:moss_block
setblock 237 284 345 minecraft:mushroom_stem
fill 237 284 346 237 284 349 minecraft:moss_block
setblock 237 284 350 minecraft:mushroom_stem
fill 237 284 351 237 284 354 minecraft:moss_block
setblock 237 284 355 minecraft:mushroom_stem
fill 237 284 356 237 284 359 minecraft:moss_block
setblock 237 284 360 minecraft:mushroom_stem
fill 237 284 361 237 287 361 minecraft:moss_block
fill 237 284 363 238 284 363 minecraft:moss_block
fill 238 284 337 238 284 338 minecraft:moss_block
setblock 238 284 339 minecraft:mushroom_stem
fill 238 284 340 238 287 340 minecraft:moss_block
setblock 238 284 343 minecraft:moss_block
setblock 239 284 363 minecraft:mushroom_stem
setblock 240 284 323 minecraft:red_mushroom_block
fill 240 284 363 240 287 363 minecraft:moss_block
fill 243 284 364 243 308 364 minecraft:moss_block
setblock 244 284 364 minecraft:red_mushroom_block
fill 245 284 364 248 290 364 minecraft:moss_block
setblock 247 284 363 minecraft:red_mushroom_block
fill 251 284 323 253 284 323 minecraft:moss_block
fill 251 284 363 253 284 363 minecraft:moss_block
setblock 253 284 324 minecraft:mushroom_stem
fill 253 284 362 254 284 362 minecraft:moss_block
setblock 254 284 323 minecraft:mushroom_stem
fill 254 284 324 257 284 324 minecraft:moss_block
setblock 254 284 363 minecraft:mushroom_stem
fill 255 284 323 258 284 323 minecraft:moss_block
setblock 255 284 362 minecraft:mushroom_stem
fill 255 284 363 258 284 363 minecraft:moss_block
fill 256 284 362 259 284 362 minecraft:moss_block
setblock 258 284 324 minecraft:mushroom_stem
setblock 259 284 323 minecraft:mushroom_stem
fill 259 284 324 259 287 324 minecraft:moss_block
setblock 259 284 363 minecraft:mushroom_stem
fill 260 284 323 260 287 323 minecraft:moss_block
setblock 260 284 362 minecraft:mushroom_stem
fill 260 284 363 263 284 363 minecraft:moss_block
fill 261 284 362 262 286 362 minecraft:moss_block
setblock 264 284 363 minecraft:mushroom_stem
fill 265 284 363 268 284 363 minecraft:moss_block
fill 267 284 362 269 284 362 minecraft:moss_block
setblock 269 284 323 minecraft:mushroom_stem
setblock 269 284 363 minecraft:mushroom_stem
fill 270 284 323 273 284 323 minecraft:moss_block
setblock 270 284 361 minecraft:moss_block
setblock 270 284 362 minecraft:mushroom_stem
fill 270 284 363 273 284 363 minecraft:moss_block
setblock 271 284 361 minecraft:mushroom_stem
fill 271 284 362 274 284 362 minecraft:moss_block
fill 272 284 361 275 284 361 minecraft:moss_block
setblock 273 284 359 minecraft:mushroom_stem
fill 273 284 360 273 287 360 minecraft:moss_block
setblock 274 284 323 minecraft:mushroom_stem
fill 274 284 355 274 284 357 minecraft:moss_block
setblock 274 284 358 minecraft:mushroom_stem
fill 274 284 359 274 287 359 minecraft:moss_block
setblock 274 284 363 minecraft:mushroom_stem
fill 275 284 323 275 287 323 minecraft:moss_block
setblock 275 284 336 minecraft:moss_block
setblock 275 284 337 minecraft:mushroom_stem
fill 275 284 338 275 284 341 minecraft:moss_block
setblock 275 284 342 minecraft:mushroom_stem
fill 275 284 343 276 285 344 minecraft:moss_block
setblock 275 284 352 minecraft:mushroom_stem
fill 275 284 353 275 284 356 minecraft:moss_block
setblock 275 284 357 minecraft:mushroom_stem
fill 275 284 358 275 287 358 minecraft:moss_block
setblock 275 284 362 minecraft:mushroom_stem
fill 275 284 363 275 287 363 minecraft:moss_block
setblock 276 284 331 minecraft:red_mushroom_block
fill 276 284 333 276 284 335 minecraft:moss_block
setblock 276 284 336 minecraft:mushroom_stem
fill 276 284 337 276 287 337 minecraft:moss_block
fill 276 284 339 276 284 340 minecraft:moss_block
setblock 276 284 341 minecraft:mushroom_stem
fill 276 284 342 276 287 342 minecraft:moss_block
setblock 276 284 345 minecraft:moss_block
setblock 276 284 346 minecraft:mushroom_stem
fill 276 284 347 276 284 350 minecraft:moss_block
setblock 276 284 351 minecraft:mushroom_stem
fill 276 284 352 276 284 355 minecraft:moss_block
setblock 276 284 356 minecraft:mushroom_stem
fill 276 284 357 276 287 357 minecraft:moss_block
setblock 276 284 361 minecraft:mushroom_stem
fill 276 284 362 276 287 362 minecraft:moss_block
fill 236 285 323 237 285 323 minecraft:moss_block
fill 236 285 332 236 285 334 minecraft:moss_block
setblock 236 285 335 minecraft:mushroom_stem
fill 236 285 336 236 285 339 minecraft:moss_block
setblock 236 285 340 minecraft:mushroom_stem
fill 236 285 341 236 285 344 minecraft:moss_block
setblock 236 285 345 minecraft:mushroom_stem
fill 236 285 346 236 285 349 minecraft:moss_block
setblock 236 285 350 minecraft:mushroom_stem
fill 236 285 351 236 285 354 minecraft:moss_block
setblock 236 285 355 minecraft:mushroom_stem
fill 236 285 356 236 285 359 minecraft:moss_block
setblock 236 285 360 minecraft:mushroom_stem
fill 236 285 361 236 288 361 minecraft:moss_block
setblock 237 285 334 minecraft:mushroom_stem
fill 237 285 335 237 285 338 minecraft:moss_block
setblock 237 285 339 minecraft:mushroom_stem
fill 237 285 340 237 285 343 minecraft:moss_block
setblock 237 285 344 minecraft:mushroom_stem
fill 237 285 345 237 285 348 minecraft:moss_block
setblock 237 285 349 minecraft:mushroom_stem
fill 237 285 350 237 285 353 minecraft:moss_block
setblock 237 285 354 minecraft:mushroom_stem
fill 237 285 355 237 285 358 minecraft:moss_block
setblock 237 285 359 minecraft:mushroom_stem
fill 237 285 360 237 288 360 minecraft:moss_block
setblock 237 285 363 minecraft:moss_block
setblock 238 285 325 minecraft:light[level=15]
setblock 238 285 332 minecraft:light[level=12]
setblock 238 285 333 minecraft:light[level=15]
setblock 238 285 337 minecraft:moss_block
setblock 238 285 338 minecraft:mushroom_stem
fill 238 285 339 238 288 339 minecraft:moss_block
fill 238 285 343 240 285 343 minecraft:mushroom_stem
fill 238 285 344 238 288 344 minecraft:moss_block
fill 238 285 345 238 285 346 minecraft:mushroom_stem
setblock 238 285 349 minecraft:light[level=15]
setblock 238 285 353 minecraft:light[level=12]
setblock 238 285 357 minecraft:light[level=15]
setblock 238 285 360 minecraft:light[level=12]
setblock 238 285 363 minecraft:mushroom_stem
fill 239 285 342 239 300 342 minecraft:mushroom_stem
fill 239 285 344 240 300 345 minecraft:mushroom_stem
fill 239 285 363 239 288 363 minecraft:moss_block
fill 244 285 364 244 308 364 minecraft:moss_block
setblock 245 285 325 minecraft:light[level=12]
setblock 245 285 332 minecraft:light[level=12]
setblock 245 285 339 minecraft:light[level=12]
setblock 245 285 346 minecraft:light[level=12]
setblock 245 285 353 minecraft:light[level=12]
setblock 245 285 360 minecraft:light[level=12]
setblock 246 285 325 minecraft:light[level=15]
setblock 246 285 333 minecraft:light[level=15]
setblock 246 285 341 minecraft:light[level=15]
setblock 246 285 349 minecraft:light[level=15]
setblock 246 285 357 minecraft:light[level=15]
fill 249 285 323 252 285 323 minecraft:moss_block
fill 249 285 363 252 285 363 minecraft:moss_block
setblock 252 285 324 minecraft:mushroom_stem
setblock 252 285 325 minecraft:light[level=12]
setblock 252 285 332 minecraft:light[level=12]
setblock 252 285 339 minecraft:light[level=12]
setblock 252 285 346 minecraft:light[level=12]
setblock 252 285 353 minecraft:light[level=12]
setblock 252 285 360 minecraft:light[level=12]
fill 252 285 362 253 285 362 minecraft:moss_block
setblock 253 285 323 minecraft:mushroom_stem
fill 253 285 324 256 285 324 minecraft:moss_block
setblock 253 285 363 minecraft:mushroom_stem
fill 254 285 323 257 285 323 minecraft:moss_block
setblock 254 285 325 minecraft:light[level=15]
setblock 254 285 333 minecraft:light[level=15]
setblock 254 285 341 minecraft:light[level=15]
setblock 254 285 349 minecraft:light[level=15]
setblock 254 285 357 minecraft:light[level=15]
setblock 254 285 362 minecraft:mushroom_stem
fill 254 285 363 257 285 363 minecraft:moss_block
setblock 255 285 361 minecraft:mushroom_stem
fill 255 285 362 258 285 362 minecraft:moss_block
fill 256 285 361 257 287 361 minecraft:moss_block
setblock 257 285 324 minecraft:mushroom_stem
setblock 258 285 323 minecraft:mushroom_stem
fill 258 285 324 258 288 324 minecraft:moss_block
setblock 258 285 363 minecraft:mushroom_stem
fill 259 285 323 259 288 323 minecraft:moss_block
setblock 259 285 325 minecraft:light[level=12]
setblock 259 285 332 minecraft:light[level=12]
setblock 259 285 339 minecraft:light[level=12]
setblock 259 285 346 minecraft:light[level=12]
setblock 259 285 353 minecraft:light[level=12]
setblock 259 285 360 minecraft:light[level=12]
setblock 259 285 362 minecraft:mushroom_stem
fill 259 285 363 262 285 363 minecraft:moss_block
fill 260 285 324 260 286 324 minecraft:moss_block
fill 260 285 362 260 288 362 minecraft:moss_block
fill 261 285 323 262 285 323 minecraft:moss_block
setblock 262 285 325 minecraft:light[level=15]
setblock 262 285 333 minecraft:light[level=15]
setblock 262 285 341 minecraft:light[level=15]
setblock 262 285 349 minecraft:light[level=15]
setblock 262 285 357 minecraft:light[level=15]
setblock 263 285 323 minecraft:mushroom_stem
setblock 263 285 362 minecraft:moss_block
setblock 263 285 363 minecraft:mushroom_stem
fill 264 285 323 267 285 323 minecraft:moss_block
setblock 264 285 362 minecraft:mushroom_stem
fill 264 285 363 267 285 363 minecraft:moss_block
fill 265 285 362 268 285 362 minecraft:moss_block
setblock 266 285 325 minecraft:light[level=12]
setblock 266 285 332 minecraft:light[level=12]
setblock 266 285 339 minecraft:light[level=12]
setblock 266 285 346 minecraft:light[level=12]
setblock 266 285 353 minecraft:light[level=12]
setblock 266 285 360 minecraft:light[level=12]
setblock 268 285 323 minecraft:mushroom_stem
setblock 268 285 363 minecraft:mushroom_stem
fill 269 285 323 272 285 323 minecraft:moss_block
setblock 269 285 361 minecraft:moss_block
setblock 269 285 362 minecraft:mushroom_stem
fill 269 285 363 272 285 363 minecraft:moss_block
setblock 270 285 325 minecraft:light[level=15]
setblock 270 285 333 minecraft:light[level=15]
setblock 270 285 341 minecraft:light[level=15]
setblock 270 285 349 minecraft:light[level=15]
setblock 270 285 357 minecraft:light[level=15]
setblock 270 285 361 minecraft:mushroom_stem
fill 270 285 362 273 285 362 minecraft:moss_block
fill 271 285 361 274 285 361 minecraft:moss_block
fill 272 285 360 272 288 360 minecraft:moss_block
setblock 273 285 323 minecraft:mushroom_stem
setblock 273 285 325 minecraft:light[level=12]
setblock 273 285 332 minecraft:light[level=12]
setblock 273 285 339 minecraft:light[level=12]
setblock 273 285 346 minecraft:light[level=12]
setblock 273 285 353 minecraft:light[level=12]
setblock 273 285 358 minecraft:mushroom_stem
fill 273 285 359 273 288 359 minecraft:moss_block
setblock 273 285 363 minecraft:mushroom_stem
fill 274 285 323 274 288 323 minecraft:moss_block
fill 274 285 355 274 285 356 minecraft:moss_block
setblock 274 285 357 minecraft:mushroom_stem
fill 274 285 358 274 288 358 minecraft:moss_block
fill 274 285 360 275 285 360 minecraft:moss_block
setblock 274 285 362 minecraft:mushroom_stem
fill 274 285 363 274 288 363 minecraft:moss_block
setblock 275 285 336 minecraft:mushroom_stem
fill 275 285 337 275 285 340 minecraft:moss_block
setblock 275 285 341 minecraft:mushroom_stem
fill 275 285 342 275 288 342 minecraft:moss_block
setblock 275 285 345 minecraft:moss_block
setblock 275 285 346 minecraft:mushroom_stem
fill 275 285 347 276 287 347 minecraft:moss_block
setblock 275 285 350 minecraft:moss_block
setblock 275 285 351 minecraft:mushroom_stem
fill 275 285 352 275 285 355 minecraft:moss_block
setblock 275 285 356 minecraft:mushroom_stem
fill 275 285 357 275 288 357 minecraft:moss_block
setblock 275 285 361 minecraft:mushroom_stem
fill 275 285 362 275 288 362 minecraft:moss_block
setblock 276 285 325 minecraft:mushroom_stem
fill 276 285 333 276 285 334 minecraft:moss_block
setblock 276 285 335 minecraft:mushroom_stem
fill 276 285 336 276 288 336 minecraft:moss_block
setblock 276 285 339 minecraft:moss_block
setblock 276 285 340 minecraft:mushroom_stem
fill 276 285 341 276 288 341 minecraft:moss_block
setblock 276 285 345 minecraft:mushroom_stem
fill 276 285 346 276 288 346 minecraft:moss_block
fill 276 285 348 276 285 349 minecraft:moss_block
setblock 276 285 350 minecraft:mushroom_stem
fill 276 285 351 276 285 354 minecraft:moss_block
setblock 276 285 355 minecraft:mushroom_stem
fill 276 285 356 276 288 356 minecraft:moss_block
setblock 276 285 360 minecraft:mushroom_stem
fill 276 285 361 276 288 361 minecraft:moss_block
setblock 236 286 323 minecraft:moss_block
setblock 236 286 324 minecraft:mushroom_stem
fill 236 286 325 236 289 325 minecraft:moss_block
fill 236 286 332 236 286 333 minecraft:moss_block
setblock 236 286 334 minecraft:mushroom_stem
fill 236 286 335 236 286 338 minecraft:moss_block
setblock 236 286 339 minecraft:mushroom_stem
fill 236 286 340 236 286 343 minecraft:moss_block
setblock 236 286 344 minecraft:mushroom_stem
fill 236 286 345 236 286 348 minecraft:moss_block
setblock 236 286 349 minecraft:mushroom_stem
fill 236 286 350 236 286 353 minecraft:moss_block
setblock 236 286 354 minecraft:mushroom_stem
fill 236 286 355 236 286 358 minecraft:moss_block
setblock 236 286 359 minecraft:mushroom_stem
fill 236 286 360 236 289 360 minecraft:moss_block
setblock 237 286 323 minecraft:mushroom_stem
fill 237 286 334 237 286 337 minecraft:moss_block
setblock 237 286 338 minecraft:mushroom_stem
fill 237 286 339 237 286 342 minecraft:moss_block
setblock 237 286 343 minecraft:mushroom_stem
fill 237 286 344 237 286 347 minecraft:moss_block
setblock 237 286 348 minecraft:mushroom_stem
fill 237 286 349 237 287 351 minecraft:moss_block
setblock 237 286 353 minecraft:mushroom_stem
fill 237 286 354 237 286 357 minecraft:moss_block
setblock 237 286 358 minecraft:mushroom_stem
fill 237 286 359 237 289 359 minecraft:moss_block
setblock 237 286 362 minecraft:moss_block
setblock 237 286 363 minecraft:mushroom_stem
fill 238 286 323 238 289 323 minecraft:moss_block
setblock 238 286 337 minecraft:mushroom_stem
fill 238 286 338 238 289 338 minecraft:moss_block
setblock 238 286 341 minecraft:moss_block
setblock 238 286 342 minecraft:mushroom_stem
fill 238 286 343 238 289 343 minecraft:moss_block
fill 238 286 345 238 287 345 minecraft:moss_block
fill 238 286 346 238 287 346 minecraft:mushroom_stem
setblock 238 286 362 minecraft:mushroom_stem
fill 238 286 363 238 289 363 minecraft:moss_block
fill 239 286 341 240 287 341 minecraft:dirt
fill 239 286 343 240 300 343 minecraft:mushroom_stem
fill 239 286 346 240 287 346 minecraft:dirt
fill 240 286 342 241 287 342 minecraft:dirt
fill 241 286 343 241 287 345 minecraft:dirt
setblock 247 286 323 minecraft:mushroom_stem
fill 248 286 323 251 286 323 minecraft:moss_block
fill 248 286 363 251 286 363 minecraft:moss_block
setblock 250 286 324 minecraft:moss_block
fill 250 286 362 252 286 362 minecraft:moss_block
setblock 251 286 324 minecraft:mushroom_stem
setblock 252 286 323 minecraft:mushroom_stem
fill 252 286 324 255 286 324 minecraft:moss_block
setblock 252 286 363 minecraft:mushroom_stem
fill 253 286 323 256 286 323 minecraft:moss_block
fill 253 286 325 254 286 325 minecraft:moss_block
setblock 253 286 361 minecraft:moss_block
setblock 253 286 362 minecraft:mushroom_stem
fill 253 286 363 256 286 363 minecraft:moss_block
setblock 254 286 361 minecraft:mushroom_stem
fill 254 286 362 257 286 362 minecraft:moss_block
setblock 255 286 325 minecraft:mushroom_stem
fill 255 286 361 255 289 361 minecraft:moss_block
setblock 256 286 324 minecraft:mushroom_stem
fill 256 286 325 256 289 325 minecraft:moss_block
setblock 257 286 323 minecraft:mushroom_stem
fill 257 286 324 257 289 324 minecraft:moss_block
setblock 257 286 363 minecraft:mushroom_stem
fill 258 286 323 258 289 323 minecraft:moss_block
setblock 258 286 361 minecraft:moss_block
setblock 258 286 362 minecraft:mushroom_stem
fill 258 286 363 261 286 363 minecraft:moss_block
fill 259 286 362 259 289 362 minecraft:moss_block
setblock 261 286 323 minecraft:moss_block
setblock 262 286 323 minecraft:mushroom_stem
setblock 262 286 363 minecraft:mushroom_stem
fill 263 286 323 266 286 323 minecraft:moss_block
setblock 263 286 362 minecraft:mushroom_stem
fill 263 286 363 266 286 363 minecraft:moss_block
fill 264 286 362 267 286 362 minecraft:moss_block
setblock 267 286 323 minecraft:mushroom_stem
setblock 267 286 363 minecraft:mushroom_stem
fill 268 286 323 271 286 323 minecraft:moss_block
setblock 268 286 361 minecraft:moss_block
setblock 268 286 362 minecraft:mushroom_stem
fill 268 286 363 271 286 363 minecraft:moss_block
setblock 269 286 361 minecraft:mushroom_stem
fill 269 286 362 272 286 362 minecraft:moss_block
fill 270 286 361 273 286 361 minecraft:moss_block
setblock 271 286 324 minecraft:mushroom_stem
fill 271 286 360 271 289 360 minecraft:moss_block
setblock 272 286 323 minecraft:mushroom_stem
fill 272 286 324 275 286 324 minecraft:moss_block
setblock 272 286 363 minecraft:mushroom_stem
fill 273 286 323 273 289 323 minecraft:moss_block
fill 273 286 358 273 289 358 minecraft:moss_block
setblock 273 286 362 minecraft:mushroom_stem
fill 273 286 363 273 289 363 minecraft:moss_block
setblock 274 286 340 minecraft:moss_block
setblock 274 286 341 minecraft:mushroom_stem
fill 274 286 342 274 288 343 minecraft:moss_block
fill 274 286 354 274 286 355 minecraft:moss_block
setblock 274 286 356 minecraft:mushroom_stem
fill 274 286 357 274 289 357 minecraft:moss_block
setblock 274 286 360 minecraft:moss_block
setblock 274 286 361 minecraft:mushroom_stem
fill 274 286 362 274 289 362 minecraft:moss_block
fill 275 286 336 275 286 339 minecraft:moss_block
setblock 275 286 340 minecraft:mushroom_stem
fill 275 286 341 275 289 341 minecraft:moss_block
fill 275 286 343 275 286 344 minecraft:moss_block
setblock 275 286 345 minecraft:mushroom_stem
fill 275 286 346 275 289 346 minecraft:moss_block
fill 275 286 348 275 286 349 minecraft:moss_block
setblock 275 286 350 minecraft:mushroom_stem
fill 275 286 351 275 286 354 minecraft:moss_block
setblock 275 286 355 minecraft:mushroom_stem
fill 275 286 356 275 289 356 minecraft:moss_block
setblock 275 286 359 minecraft:moss_block
setblock 275 286 360 minecraft:mushroom_stem
fill 275 286 361 275 289 361 minecraft:moss_block
setblock 276 286 323 minecraft:moss_block
setblock 276 286 324 minecraft:mushroom_stem
fill 276 286 325 276 288 326 minecraft:moss_block
setblock 276 286 333 minecraft:moss_block
setblock 276 286 334 minecraft:mushroom_stem
fill 276 286 335 276 289 335 minecraft:moss_block
setblock 276 286 339 minecraft:mushroom_stem
fill 276 286 340 276 289 340 minecraft:moss_block
setblock 276 286 343 minecraft:moss_block
setblock 276 286 344 minecraft:mushroom_stem
fill 276 286 345 276 289 345 minecraft:moss_block
setblock 276 286 348 minecraft:moss_block
setblock 276 286 349 minecraft:mushroom_stem
fill 276 286 350 276 286 353 minecraft:moss_block
setblock 276 286 354 minecraft:mushroom_stem
fill 276 286 355 276 289 355 minecraft:moss_block
setblock 276 286 359 minecraft:mushroom_stem
fill 276 286 360 276 289 360 minecraft:moss_block
setblock 235 287 334 minecraft:red_mushroom_block
fill 235 287 335 237 288 335 minecraft:moss_block
setblock 236 287 323 minecraft:mushroom_stem
fill 236 287 324 236 290 324 minecraft:moss_block
fill 236 287 326 236 288 326 minecraft:moss_block
setblock 236 287 329 minecraft:red_mushroom_block
fill 236 287 331 236 287 332 minecraft:moss_block
setblock 236 287 333 minecraft:mushroom_stem
fill 236 287 334 237 287 334 minecraft:moss_block
fill 236 287 336 236 287 337 minecraft:moss_block
setblock 236 287 338 minecraft:mushroom_stem
fill 236 287 339 236 287 342 minecraft:moss_block
setblock 236 287 343 minecraft:mushroom_stem
fill 236 287 344 236 287 347 minecraft:moss_block
setblock 236 287 348 minecraft:mushroom_stem
fill 236 287 349 236 287 352 minecraft:moss_block
setblock 236 287 353 minecraft:mushroom_stem
fill 236 287 354 236 287 357 minecraft:moss_block
setblock 236 287 358 minecraft:mushroom_stem
fill 236 287 359 236 290 359 minecraft:moss_block
setblock 236 287 362 minecraft:moss_block
setblock 236 287 363 minecraft:mushroom_stem
fill 237 287 323 237 290 323 minecraft:moss_block
setblock 237 287 336 minecraft:moss_block
setblock 237 287 337 minecraft:mushroom_stem
fill 237 287 338 237 287 341 minecraft:moss_block
setblock 237 287 342 minecraft:mushroom_stem
fill 237 287 343 237 287 346 minecraft:moss_block
setblock 237 287 347 minecraft:mushroom_stem
fill 237 287 348 237 290 348 minecraft:moss_block
fill 237 287 355 237 287 356 minecraft:moss_block
setblock 237 287 357 minecraft:mushroom_stem
fill 237 287 358 237 288 358 minecraft:moss_block
setblock 237 287 362 minecraft:mushroom_stem
fill 237 287 363 237 290 363 minecraft:moss_block
fill 238 287 337 238 288 337 minecraft:moss_block
setblock 238 287 341 minecraft:mushroom_stem
fill 238 287 342 238 290 342 minecraft:moss_block
fill 238 287 347 240 287 347 minecraft:dirt
fill 238 287 362 238 288 362 minecraft:moss_block
fill 239 287 323 239 288 323 minecraft:moss_block
fill 239 287 340 240 287 340 minecraft:dirt
setblock 241 287 323 minecraft:red_mushroom_block
setblock 241 287 341 minecraft:dirt
setblock 241 287 346 minecraft:dirt
setblock 241 287 363 minecraft:mushroom_stem
fill 242 287 342 242 287 345 minecraft:dirt
setblock 242 287 361 minecraft:shroomlight
setblock 246 287 323 minecraft:mushroom_stem
setblock 246 287 363 minecraft:mushroom_stem
fill 247 287 323 250 287 323 minecraft:moss_block
fill 247 287 363 250 287 363 minecraft:moss_block
fill 248 287 324 249 287 324 minecraft:moss_block
fill 249 287 362 251 287 362 minecraft:moss_block
setblock 250 287 324 minecraft:mushroom_stem
setblock 251 287 323 minecraft:mushroom_stem
fill 251 287 324 253 287 325 minecraft:moss_block
setblock 251 287 363 minecraft:mushroom_stem
fill 252 287 323 255 287 323 minecraft:moss_block
setblock 252 287 361 minecraft:moss_block
setblock 252 287 362 minecraft:mushroom_stem
fill 252 287 363 255 287 363 minecraft:moss_block
setblock 253 287 361 minecraft:mushroom_stem
fill 253 287 362 256 287 362 minecraft:moss_block
setblock 254 287 324 minecraft:moss_block
setblock 254 287 325 minecraft:mushroom_stem
fill 254 287 361 254 290 361 minecraft:moss_block
setblock 255 287 324 minecraft:mushroom_stem
fill 255 287 325 255 290 325 minecraft:moss_block
setblock 256 287 323 minecraft:mushroom_stem
fill 256 287 324 256 290 324 minecraft:moss_block
setblock 256 287 363 minecraft:mushroom_stem
fill 257 287 323 257 290 323 minecraft:moss_block
fill 257 287 325 257 288 325 minecraft:moss_block
setblock 257 287 362 minecraft:mushroom_stem
fill 257 287 363 260 287 363 minecraft:moss_block
setblock 258 287 361 minecraft:mushroom_stem
fill 258 287 362 258 290 362 minecraft:moss_block
setblock 260 287 324 minecraft:mushroom_stem
setblock 261 287 323 minecraft:mushroom_stem
fill 261 287 324 261 290 324 minecraft:moss_block
setblock 261 287 362 minecraft:moss_block
setblock 261 287 363 minecraft:mushroom_stem
fill 262 287 323 265 287 323 minecraft:moss_block
setblock 262 287 362 minecraft:mushroom_stem
fill 262 287 363 265 287 363 minecraft:moss_block
fill 263 287 362 266 287 362 minecraft:moss_block
setblock 266 287 323 minecraft:mushroom_stem
setblock 266 287 363 minecraft:mushroom_stem
fill 267 287 323 270 287 323 minecraft:moss_block
setblock 267 287 361 minecraft:moss_block
setblock 267 287 362 minecraft:mushroom_stem
fill 267 287 363 270 287 363 minecraft:moss_block
fill 268 287 324 269 287 324 minecraft:moss_block
setblock 268 287 361 minecraft:mushroom_stem
fill 268 287 362 271 287 362 minecraft:moss_block
fill 269 287 361 272 287 361 minecraft:moss_block
setblock 270 287 324 minecraft:mushroom_stem
fill 270 287 360 270 290 360 minecraft:moss_block
setblock 271 287 323 minecraft:mushroom_stem
fill 271 287 324 274 287 324 minecraft:moss_block
setblock 271 287 363 minecraft:mushroom_stem
fill 272 287 323 272 290 323 minecraft:moss_block
setblock 272 287 362 minecraft:mushroom_stem
fill 272 287 363 272 290 363 minecraft:moss_block
fill 273 287 357 273 288 357 minecraft:moss_block
setblock 273 287 361 minecraft:mushroom_stem
fill 273 287 362 273 290 362 minecraft:moss_block
setblock 274 287 339 minecraft:moss_block
setblock 274 287 340 minecraft:mushroom_stem
fill 274 287 341 274 290 341 minecraft:moss_block
setblock 274 287 344 minecraft:moss_block
setblock 274 287 345 minecraft:mushroom_stem
fill 274 287 346 274 290 346 minecraft:moss_block
setblock 274 287 354 minecraft:moss_block
setblock 274 287 355 minecraft:mushroom_stem
fill 274 287 356 274 290 356 minecraft:moss_block
setblock 274 287 360 minecraft:mushroom_stem
fill 274 287 361 274 290 361 minecraft:moss_block
setblock 275 287 324 minecraft:mushroom_stem
fill 275 287 336 275 287 338 minecraft:moss_block
setblock 275 287 339 minecraft:mushroom_stem
fill 275 287 340 275 290 340 minecraft:moss_block
setblock 275 287 343 minecraft:moss_block
setblock 275 287 344 minecraft:mushroom_stem
fill 275 287 345 275 290 345 minecraft:moss_block
setblock 275 287 348 minecraft:moss_block
setblock 275 287 349 minecraft:mushroom_stem
fill 275 287 350 275 287 353 minecraft:moss_block
setblock 275 287 354 minecraft:mushroom_stem
fill 275 287 355 275 290 355 minecraft:moss_block
setblock 275 287 359 minecraft:mushroom_stem
fill 275 287 360 275 290 360 minecraft:moss_block
setblock 276 287 323 minecraft:mushroom_stem
fill 276 287 324 276 290 324 minecraft:moss_block
setblock 276 287 332 minecraft:red_mushroom_block
fill 276 287 334 276 289 334 minecraft:moss_block
setblock 276 287 338 minecraft:mushroom_stem
fill 276 287 339 276 290 339 minecraft:moss_block
setblock 276 287 343 minecraft:mushroom_stem
fill 276 287 344 276 290 344 minecraft:moss_block
setblock 276 287 348 minecraft:mushroom_stem
fill 276 287 349 276 287 352 minecraft:moss_block
setblock 276 287 353 minecraft:mushroom_stem
fill 276 287 354 276 290 354 minecraft:moss_block
setblock 276 287 358 minecraft:mushroom_stem
fill 276 287 359 276 290 359 minecraft:moss_block
setblock 276 287 363 minecraft:mushroom_stem
fill 235 288 334 236 290 334 minecraft:moss_block
fill 236 288 323 236 291 323 minecraft:moss_block
setblock 236 288 327 minecraft:mushroom_stem
fill 236 288 328 236 288 331 minecraft:moss_block
setblock 236 288 332 minecraft:mushroom_stem
fill 236 288 333 236 291 333 minecraft:moss_block
setblock 236 288 336 minecraft:moss_block
setblock 236 288 337 minecraft:mushroom_stem
fill 236 288 338 236 288 341 minecraft:moss_block
setblock 236 288 342 minecraft:mushroom_stem
fill 236 288 343 236 288 346 minecraft:moss_block
setblock 236 288 347 minecraft:mushroom_stem
fill 236 288 348 236 288 351 minecraft:moss_block
setblock 236 288 352 minecraft:mushroom_stem
fill 236 288 353 236 288 356 minecraft:moss_block
setblock 236 288 357 minecraft:mushroom_stem
fill 236 288 358 236 291 358 minecraft:moss_block
setblock 236 288 362 minecraft:mushroom_stem
fill 236 288 363 236 291 363 minecraft:moss_block
setblock 237 288 336 minecraft:mushroom_stem
fill 237 288 337 237 288 340 minecraft:moss_block
setblock 237 288 341 minecraft:mushroom_stem
fill 237 288 342 237 288 345 minecraft:moss_block
setblock 237 288 346 minecraft:mushroom_stem
fill 237 288 347 237 291 347 minecraft:moss_block
fill 237 288 349 237 288 350 minecraft:moss_block
setblock 237 288 351 minecraft:mushroom_stem
setblock 237 288 357 minecraft:moss_block
setblock 237 288 361 minecraft:mushroom_stem
fill 237 288 362 237 290 362 minecraft:moss_block
setblock 238 288 340 minecraft:mushroom_stem
fill 238 288 341 238 291 341 minecraft:moss_block
setblock 238 288 345 minecraft:mushroom_stem
fill 238 288 346 238 291 346 minecraft:moss_block
setblock 240 288 323 minecraft:mushroom_stem
setblock 240 288 363 minecraft:mushroom_stem
fill 241 288 323 241 291 323 minecraft:moss_block
fill 241 288 363 241 289 363 minecraft:moss_block
fill 242 288 361 242 292 361 minecraft:mushroom_stem
fill 243 288 323 244 288 323 minecraft:moss_block
setblock 245 288 323 minecraft:mushroom_stem
setblock 245 288 363 minecraft:mushroom_stem
fill 246 288 323 249 288 323 minecraft:moss_block
fill 246 288 363 249 288 363 minecraft:moss_block
fill 247 288 324 248 288 324 minecraft:moss_block
fill 248 288 348 251 300 351 minecraft:mushroom_stem
fill 248 288 362 250 288 362 minecraft:moss_block
setblock 249 288 324 minecraft:mushroom_stem
setblock 250 288 323 minecraft:mushroom_stem
fill 250 288 324 252 288 325 minecraft:moss_block
setblock 250 288 363 minecraft:mushroom_stem
fill 251 288 323 254 288 323 minecraft:moss_block
setblock 251 288 361 minecraft:moss_block
setblock 251 288 362 minecraft:mushroom_stem
fill 251 288 363 254 288 363 minecraft:moss_block
setblock 252 288 361 minecraft:mushroom_stem
fill 252 288 362 255 288 362 minecraft:moss_block
setblock 253 288 324 minecraft:moss_block
setblock 253 288 325 minecraft:mushroom_stem
fill 253 288 361 253 291 361 minecraft:moss_block
setblock 254 288 324 minecraft:mushroom_stem
fill 254 288 325 254 291 325 minecraft:moss_block
setblock 255 288 323 minecraft:mushroom_stem
fill 255 288 324 255 291 324 minecraft:moss_block
setblock 255 288 363 minecraft:mushroom_stem
fill 256 288 323 256 291 323 minecraft:moss_block
setblock 256 288 361 minecraft:moss_block
setblock 256 288 362 minecraft:mushroom_stem
fill 256 288 363 259 288 363 minecraft:moss_block
setblock 257 288 361 minecraft:mushroom_stem
fill 257 288 362 257 291 362 minecraft:moss_block
setblock 258 288 325 minecraft:mushroom_stem
fill 258 288 361 258 289 361 minecraft:moss_block
setblock 259 288 324 minecraft:mushroom_stem
setblock 260 288 323 minecraft:mushroom_stem
fill 260 288 324 260 291 324 minecraft:moss_block
setblock 260 288 363 minecraft:mushroom_stem
fill 261 288 323 264 288 323 minecraft:moss_block
setblock 261 288 362 minecraft:mushroom_stem
fill 261 288 363 264 288 363 minecraft:moss_block
fill 262 288 324 263 288 324 minecraft:moss_block
fill 262 288 362 265 288 362 minecraft:moss_block
setblock 264 288 324 minecraft:mushroom_stem
setblock 265 288 323 minecraft:mushroom_stem
fill 265 288 324 268 288 324 minecraft:moss_block
setblock 265 288 363 minecraft:mushroom_stem
fill 266 288 323 269 288 323 minecraft:moss_block
setblock 266 288 361 minecraft:moss_block
setblock 266 288 362 minecraft:mushroom_stem
fill 266 288 363 269 288 363 minecraft:moss_block
setblock 267 288 361 minecraft:mushroom_stem
fill 267 288 362 270 288 362 minecraft:moss_block
fill 268 288 361 271 288 361 minecraft:moss_block
setblock 269 288 324 minecraft:mushroom_stem
fill 269 288 360 269 290 360 minecraft:moss_block
setblock 270 288 323 minecraft:mushroom_stem
fill 270 288 324 273 288 324 minecraft:moss_block
setblock 270 288 363 minecraft:mushroom_stem
fill 271 288 323 271 291 323 minecraft:moss_block
fill 271 288 340 273 300 340 minecraft:mushroom_stem
setblock 271 288 362 minecraft:mushroom_stem
fill 271 288 363 271 291 363 minecraft:moss_block
fill 272 288 339 274 288 339 minecraft:mushroom_stem
fill 272 288 341 273 300 341 minecraft:mushroom_stem
setblock 272 288 361 minecraft:mushroom_stem
fill 272 288 362 272 291 362 minecraft:moss_block
fill 273 288 338 273 300 338 minecraft:mushroom_stem
setblock 273 288 342 minecraft:mushroom_stem
setblock 273 288 360 minecraft:mushroom_stem
fill 273 288 361 273 291 361 minecraft:moss_block
setblock 274 288 324 minecraft:mushroom_stem
fill 274 288 340 274 291 340 minecraft:moss_block
setblock 274 288 344 minecraft:mushroom_stem
fill 274 288 345 274 291 345 minecraft:moss_block
fill 274 288 347 274 288 348 minecraft:moss_block
setblock 274 288 349 minecraft:mushroom_stem
setblock 274 288 353 minecraft:moss_block
setblock 274 288 354 minecraft:mushroom_stem
fill 274 288 355 274 290 355 minecraft:moss_block
setblock 274 288 359 minecraft:mushroom_stem
fill 274 288 360 274 291 360 minecraft:moss_block
setblock 275 288 323 minecraft:mushroom_stem
fill 275 288 324 275 290 325 minecraft:moss_block
fill 275 288 336 275 288 337 minecraft:moss_block
setblock 275 288 338 minecraft:mushroom_stem
fill 275 288 339 275 291 339 minecraft:moss_block
setblock 275 288 343 minecraft:mushroom_stem
fill 275 288 344 275 291 344 minecraft:moss_block
setblock 275 288 347 minecraft:moss_block
setblock 275 288 348 minecraft:mushroom_stem
fill 275 288 349 275 288 352 minecraft:moss_block
setblock 275 288 353 minecraft:mushroom_stem
fill 275 288 354 275 291 354 minecraft:moss_block
setblock 275 288 358 minecraft:mushroom_stem
fill 275 288 359 275 291 359 minecraft:moss_block
setblock 275 288 363 minecraft:mushroom_stem
fill 276 288 323 276 291 323 minecraft:moss_block
setblock 276 288 327 minecraft:mushroom_stem
setblock 276 288 337 minecraft:mushroom_stem
fill 276 288 338 276 291 338 minecraft:moss_block
setblock 276 288 342 minecraft:mushroom_stem
fill 276 288 343 276 291 343 minecraft:moss_block
setblock 276 288 347 minecraft:mushroom_stem
fill 276 288 348 276 288 351 minecraft:moss_block
setblock 276 288 352 minecraft:mushroom_stem
fill 276 288 353 276 291 353 minecraft:moss_block
setblock 276 288 357 minecraft:mushroom_stem
fill 276 288 358 276 291 358 minecraft:moss_block
setblock 276 288 362 minecraft:mushroom_stem
fill 276 288 363 276 291 363 minecraft:moss_block
setblock 235 289 335 minecraft:shroomlight
setblock 236 289 326 minecraft:mushroom_stem
fill 236 289 327 236 289 330 minecraft:moss_block
setblock 236 289 331 minecraft:mushroom_stem
fill 236 289 332 236 291 332 minecraft:moss_block
setblock 236 289 335 minecraft:moss_block
setblock 236 289 336 minecraft:mushroom_stem
fill 236 289 337 236 289 340 minecraft:moss_block
setblock 236 289 341 minecraft:mushroom_stem
fill 236 289 342 236 289 345 minecraft:moss_block
setblock 236 289 346 minecraft:mushroom_stem
fill 236 289 347 236 289 350 minecraft:moss_block
setblock 236 289 351 minecraft:mushroom_stem
fill 236 289 352 236 289 355 minecraft:moss_block
setblock 236 289 356 minecraft:mushroom_stem
fill 236 289 357 236 291 357 minecraft:moss_block
setblock 236 289 361 minecraft:mushroom_stem
fill 236 289 362 236 292 362 minecraft:moss_block
setblock 237 289 335 minecraft:mushroom_stem
fill 237 289 336 237 289 339 minecraft:moss_block
setblock 237 289 340 minecraft:mushroom_stem
fill 237 289 341 237 289 344 minecraft:moss_block
setblock 237 289 345 minecraft:mushroom_stem
fill 237 289 346 237 292 346 minecraft:moss_block
setblock 237 289 349 minecraft:moss_block
setblock 237 289 350 minecraft:mushroom_stem
setblock 237 289 360 minecraft:mushroom_stem
setblock 237 289 361 minecraft:moss_block
setblock 238 289 339 minecraft:mushroom_stem
fill 238 289 340 238 291 340 minecraft:moss_block
setblock 238 289 344 minecraft:mushroom_stem
fill 238 289 345 238 292 345 minecraft:moss_block
fill 238 289 347 238 290 347 minecraft:moss_block
setblock 239 289 323 minecraft:mushroom_stem
setblock 239 289 363 minecraft:mushroom_stem
fill 240 289 323 240 292 323 minecraft:moss_block
fill 240 289 363 240 290 363 minecraft:moss_block
fill 242 289 323 243 289 323 minecraft:moss_block
fill 242 289 363 243 289 363 minecraft:moss_block
setblock 244 289 323 minecraft:mushroom_stem
setblock 244 289 363 minecraft:mushroom_stem
fill 245 289 323 248 289 323 minecraft:moss_block
fill 245 289 363 248 289 363 minecraft:moss_block
fill 246 289 324 247 289 324 minecraft:moss_block
fill 247 289 348 247 290 351 minecraft:dirt
setblock 248 289 324 minecraft:mushroom_stem
fill 248 289 325 251 289 325 minecraft:moss_block
fill 248 289 347 251 290 347 minecraft:dirt
fill 248 289 352 251 290 352 minecraft:dirt
fill 248 289 362 249 289 362 minecraft:moss_block
setblock 249 289 323 minecraft:mushroom_stem
fill 249 289 324 252 289 324 minecraft:moss_block
setblock 249 289 363 minecraft:mushroom_stem
fill 250 289 323 253 289 323 minecraft:moss_block
setblock 250 289 362 minecraft:mushroom_stem
fill 250 289 363 253 289 363 minecraft:moss_block
setblock 251 289 326 minecraft:mushroom_stem
setblock 251 289 361 minecraft:mushroom_stem
fill 251 289 362 254 289 362 minecraft:moss_block
setblock 252 289 325 minecraft:mushroom_stem
fill 252 289 326 254 290 326 minecraft:moss_block
fill 252 289 348 252 290 351 minecraft:dirt
fill 252 289 361 252 291 361 minecraft:moss_block
setblock 253 289 324 minecraft:mushroom_stem
fill 253 289 325 253 292 325 minecraft:moss_block
setblock 254 289 323 minecraft:mushroom_stem
fill 254 289 324 254 292 324 minecraft:moss_block
setblock 254 289 363 minecraft:mushroom_stem
fill 255 289 323 255 292 323 minecraft:moss_block
setblock 255 289 362 minecraft:mushroom_stem
fill 255 289 363 258 289 363 minecraft:moss_block
setblock 256 289 361 minecraft:mushroom_stem
fill 256 289 362 256 292 362 minecraft:moss_block
setblock 257 289 325 minecraft:mushroom_stem
setblock 257 289 361 minecraft:moss_block
setblock 258 289 324 minecraft:mushroom_stem
fill 258 289 325 258 292 325 minecraft:moss_block
setblock 259 289 323 minecraft:mushroom_stem
fill 259 289 324 259 292 324 minecraft:moss_block
setblock 259 289 363 minecraft:mushroom_stem
fill 260 289 323 263 289 323 minecraft:moss_block
setblock 260 289 362 minecraft:mushroom_stem
fill 260 289 363 263 289 363 minecraft:moss_block
fill 261 289 362 264 289 362 minecraft:moss_block
setblock 262 289 324 minecraft:moss_block
setblock 263 289 324 minecraft:mushroom_stem
setblock 263 289 364 minecraft:shroomlight
setblock 264 289 323 minecraft:mushroom_stem
fill 264 289 324 267 289 324 minecraft:moss_block
setblock 264 289 363 minecraft:mushroom_stem
fill 265 289 323 268 289 323 minecraft:moss_block
setblock 265 289 361 minecraft:moss_block
setblock 265 289 362 minecraft:mushroom_stem
fill 265 289 363 268 289 363 minecraft:moss_block
setblock 266 289 361 minecraft:mushroom_stem
fill 266 289 362 269 289 362 minecraft:moss_block
fill 267 289 361 270 289 361 minecraft:moss_block
setblock 268 289 324 minecraft:mushroom_stem
setblock 269 289 323 minecraft:mushroom_stem
fill 269 289 324 272 289 324 minecraft:moss_block
fill 269 289 347 269 296 347 minecraft:iron_block
setblock 269 289 363 minecraft:mushroom_stem
fill 270 289 323 270 292 323 minecraft:moss_block
setblock 270 289 362 minecraft:mushroom_stem
fill 270 289 363 270 292 363 minecraft:moss_block
fill 271 289 338 271 290 339 minecraft:dirt
fill 271 289 341 271 290 342 minecraft:dirt
setblock 271 289 361 minecraft:mushroom_stem
fill 271 289 362 271 292 362 minecraft:moss_block
fill 272 289 338 272 290 338 minecraft:dirt
fill 272 289 339 273 300 339 minecraft:mushroom_stem
fill 272 289 342 272 290 342 minecraft:dirt
setblock 272 289 360 minecraft:mushroom_stem
fill 272 289 361 272 292 361 minecraft:moss_block
setblock 273 289 324 minecraft:mushroom_stem
fill 273 289 337 273 290 337 minecraft:dirt
fill 273 289 342 273 289 343 minecraft:moss_block
setblock 273 289 344 minecraft:mushroom_stem
fill 273 289 345 273 292 345 minecraft:moss_block
setblock 273 289 359 minecraft:mushroom_stem
fill 273 289 360 273 290 360 minecraft:moss_block
setblock 274 289 323 minecraft:mushroom_stem
fill 274 289 324 274 292 324 minecraft:moss_block
fill 274 289 338 274 290 338 minecraft:dirt
fill 274 289 339 274 290 339 minecraft:moss_block
setblock 274 289 342 minecraft:moss_block
setblock 274 289 343 minecraft:mushroom_stem
fill 274 289 344 274 292 344 minecraft:moss_block
setblock 274 289 347 minecraft:moss_block
setblock 274 289 348 minecraft:mushroom_stem
fill 274 289 349 274 289 352 minecraft:moss_block
setblock 274 289 353 minecraft:mushroom_stem
fill 274 289 354 274 290 354 minecraft:moss_block
setblock 274 289 358 minecraft:mushroom_stem
fill 274 289 359 274 291 359 minecraft:moss_block
setblock 274 289 363 minecraft:mushroom_stem
fill 275 289 323 275 292 323 minecraft:moss_block
setblock 275 289 337 minecraft:mushroom_stem
fill 275 289 338 275 291 338 minecraft:moss_block
setblock 275 289 342 minecraft:mushroom_stem
fill 275 289 343 275 292 343 minecraft:moss_block
setblock 275 289 347 minecraft:mushroom_stem
fill 275 289 348 275 289 351 minecraft:moss_block
setblock 275 289 352 minecraft:mushroom_stem
fill 275 289 353 275 292 353 minecraft:moss_block
setblock 275 289 357 minecraft:mushroom_stem
fill 275 289 358 275 292 358 minecraft:moss_block
setblock 275 289 362 minecraft:mushroom_stem
fill 275 289 363 275 292 363 minecraft:moss_block
setblock 276 289 325 minecraft:moss_block
setblock 276 289 326 minecraft:mushroom_stem
fill 276 289 327 276 292 327 minecraft:moss_block
setblock 276 289 336 minecraft:mushroom_stem
fill 276 289 337 276 292 337 minecraft:moss_block
setblock 276 289 341 minecraft:mushroom_stem
fill 276 289 342 276 292 342 minecraft:moss_block
setblock 276 289 346 minecraft:mushroom_stem
fill 276 289 347 276 289 350 minecraft:moss_block
setblock 276 289 351 minecraft:mushroom_stem
fill 276 289 352 276 292 352 minecraft:moss_block
setblock 276 289 356 minecraft:mushroom_stem
fill 276 289 357 276 292 357 minecraft:moss_block
setblock 276 289 361 minecraft:mushroom_stem
fill 276 289 362 276 292 362 minecraft:moss_block
fill 235 290 335 235 308 335 minecraft:moss_block
setblock 236 290 325 minecraft:mushroom_stem
fill 236 290 326 236 290 329 minecraft:moss_block
setblock 236 290 330 minecraft:mushroom_stem
fill 236 290 331 236 291 331 minecraft:moss_block
setblock 236 290 335 minecraft:mushroom_stem
fill 236 290 336 236 290 339 minecraft:moss_block
setblock 236 290 340 minecraft:mushroom_stem
fill 236 290 341 236 290 344 minecraft:moss_block
setblock 236 290 345 minecraft:mushroom_stem
fill 236 290 346 236 290 349 minecraft:moss_block
setblock 236 290 350 minecraft:mushroom_stem
fill 236 290 351 236 290 354 minecraft:moss_block
setblock 236 290 355 minecraft:mushroom_stem
fill 236 290 356 236 291 356 minecraft:moss_block
setblock 236 290 360 minecraft:mushroom_stem
fill 236 290 361 236 292 361 minecraft:moss_block
fill 237 290 336 237 290 338 minecraft:moss_block
setblock 237 290 339 minecraft:mushroom_stem
fill 237 290 340 237 290 343 minecraft:moss_block
setblock 237 290 344 minecraft:mushroom_stem
fill 237 290 345 237 293 345 minecraft:moss_block
setblock 237 290 349 minecraft:mushroom_stem
fill 237 290 350 237 291 350 minecraft:moss_block
setblock 238 290 323 minecraft:mushroom_stem
setblock 238 290 339 minecraft:moss_block
setblock 238 290 343 minecraft:mushroom_stem
fill 238 290 344 238 292 344 minecraft:moss_block
setblock 238 290 363 minecraft:mushroom_stem
fill 239 290 323 239 293 323 minecraft:moss_block
fill 239 290 363 239 291 363 minecraft:moss_block
setblock 242 290 323 minecraft:moss_block
setblock 243 290 323 minecraft:mushroom_stem
setblock 243 290 363 minecraft:mushroom_stem
fill 244 290 323 246 290 324 minecraft:moss_block
fill 244 290 363 247 290 363 minecraft:moss_block
fill 246 290 348 246 290 351 minecraft:dirt
setblock 247 290 323 minecraft:moss_block
setblock 247 290 324 minecraft:mushroom_stem
fill 247 290 325 250 290 325 minecraft:moss_block
setblock 247 290 347 minecraft:dirt
setblock 247 290 352 minecraft:dirt
fill 247 290 362 248 290 362 minecraft:moss_block
setblock 248 290 323 minecraft:mushroom_stem
fill 248 290 324 251 290 324 minecraft:moss_block
fill 248 290 346 250 290 346 minecraft:dirt
fill 248 290 353 251 290 353 minecraft:dirt
setblock 248 290 363 minecraft:mushroom_stem
fill 249 290 323 252 290 323 minecraft:moss_block
setblock 249 290 362 minecraft:mushroom_stem
fill 249 290 363 252 290 363 minecraft:moss_block
setblock 250 290 326 minecraft:mushroom_stem
fill 250 290 362 253 290 362 minecraft:moss_block
setblock 251 290 325 minecraft:mushroom_stem
fill 251 290 326 251 293 326 minecraft:moss_block
fill 251 290 361 251 291 361 minecraft:moss_block
setblock 252 290 324 minecraft:mushroom_stem
fill 252 290 325 252 293 325 minecraft:moss_block
setblock 252 290 352 minecraft:dirt
setblock 253 290 323 minecraft:mushroom_stem
fill 253 290 324 253 293 324 minecraft:moss_block
fill 253 290 349 253 290 351 minecraft:dirt
setblock 253 290 363 minecraft:mushroom_stem
fill 254 290 323 254 293 323 minecraft:moss_block
setblock 254 290 362 minecraft:mushroom_stem
fill 254 290 363 257 290 363 minecraft:moss_block
setblock 255 290 326 minecraft:mushroom_stem
setblock 255 290 361 minecraft:mushroom_stem
fill 255 290 362 255 293 362 minecraft:moss_block
setblock 256 290 325 minecraft:mushroom_stem
setblock 256 290 361 minecraft:moss_block
setblock 257 290 324 minecraft:mushroom_stem
fill 257 290 325 257 293 325 minecraft:moss_block
setblock 258 290 323 minecraft:mushroom_stem
fill 258 290 324 258 293 324 minecraft:moss_block
setblock 258 290 363 minecraft:mushroom_stem
fill 259 290 323 262 290 323 minecraft:moss_block
setblock 259 290 362 minecraft:mushroom_stem
fill 259 290 363 262 290 363 minecraft:moss_block
fill 260 290 362 263 290 362 minecraft:moss_block
setblock 261 290 326 minecraft:shroomlight
setblock 262 290 324 minecraft:mushroom_stem
setblock 263 290 323 minecraft:mushroom_stem
fill 263 290 324 266 290 324 minecraft:moss_block
setblock 263 290 363 minecraft:mushroom_stem
fill 263 290 364 263 308 364 minecraft:moss_block
fill 264 290 323 267 290 323 minecraft:moss_block
setblock 264 290 362 minecraft:mushroom_stem
fill 264 290 363 267 290 363 minecraft:moss_block
setblock 265 290 361 minecraft:mushroom_stem
fill 265 290 362 268 290 362 minecraft:moss_block
fill 266 290 361 269 290 361 minecraft:moss_block
setblock 267 290 324 minecraft:mushroom_stem
setblock 268 290 323 minecraft:mushroom_stem
fill 268 290 324 271 290 324 minecraft:moss_block
setblock 268 290 363 minecraft:mushroom_stem
fill 269 290 323 269 293 323 minecraft:moss_block
setblock 269 290 362 minecraft:mushroom_stem
fill 269 290 363 269 293 363 minecraft:moss_block
setblock 270 290 325 minecraft:moss_block
fill 270 290 338 270 290 342 minecraft:dirt
setblock 270 290 361 minecraft:mushroom_stem
fill 270 290 362 270 293 362 minecraft:moss_block
setblock 271 290 325 minecraft:mushroom_stem
fill 271 290 337 272 290 337 minecraft:dirt
fill 271 290 343 272 290 343 minecraft:dirt
setblock 271 290 360 minecraft:mushroom_stem
fill 271 290 361 271 293 361 minecraft:moss_block
setblock 272 290 324 minecraft:mushroom_stem
fill 272 290 325 272 292 325 minecraft:moss_block
fill 272 290 360 272 291 360 minecraft:moss_block
setblock 273 290 323 minecraft:mushroom_stem
fill 273 290 324 273 293 324 minecraft:moss_block
setblock 273 290 342 minecraft:moss_block
setblock 273 290 343 minecraft:mushroom_stem
fill 273 290 344 273 292 344 minecraft:moss_block
fill 273 290 346 273 290 347 minecraft:moss_block
setblock 273 290 359 minecraft:moss_block
setblock 273 290 363 minecraft:mushroom_stem
fill 274 290 323 274 293 323 minecraft:moss_block
setblock 274 290 337 minecraft:dirt
setblock 274 290 342 minecraft:mushroom_stem
fill 274 290 343 274 293 343 minecraft:moss_block
setblock 274 290 347 minecraft:mushroom_stem
fill 274 290 348 274 290 351 minecraft:moss_block
setblock 274 290 352 minecraft:mushroom_stem
setblock 274 290 353 minecraft:moss_block
setblock 274 290 357 minecraft:mushroom_stem
fill 274 290 358 274 291 358 minecraft:moss_block
setblock 274 290 362 minecraft:mushroom_stem
fill 274 290 363 274 293 363 minecraft:moss_block
setblock 275 290 326 minecraft:mushroom_stem
setblock 275 290 337 minecraft:moss_block
setblock 275 290 341 minecraft:mushroom_stem
fill 275 290 342 275 293 342 minecraft:moss_block
setblock 275 290 346 minecraft:mushroom_stem
fill 275 290 347 275 290 350 minecraft:moss_block
setblock 275 290 351 minecraft:mushroom_stem
fill 275 290 352 275 293 352 minecraft:moss_block
setblock 275 290 356 minecraft:mushroom_stem
fill 275 290 357 275 292 357 minecraft:moss_block
setblock 275 290 361 minecraft:mushroom_stem
fill 275 290 362 275 293 362 minecraft:moss_block
setblock 276 290 325 minecraft:mushroom_stem
fill 276 290 326 276 293 326 minecraft:moss_block
fill 276 290 328 276 291 328 minecraft:moss_block
setblock 276 290 335 minecraft:mushroom_stem
fill 276 290 336 276 291 336 minecraft:moss_block
setblock 276 290 340 minecraft:mushroom_stem
fill 276 290 341 276 293 341 minecraft:moss_block
setblock 276 290 345 minecraft:mushroom_stem
fill 276 290 346 276 290 349 minecraft:moss_block
setblock 276 290 350 minecraft:mushroom_stem
fill 276 290 351 276 293 351 minecraft:moss_block
setblock 276 290 355 minecraft:mushroom_stem
fill 276 290 356 276 293 356 minecraft:moss_block
setblock 276 290 360 minecraft:mushroom_stem
fill 276 290 361 276 293 361 minecraft:moss_block
fill 235 291 334 235 308 334 minecraft:moss_block
fill 235 291 349 235 299 351 minecraft:moss_block
setblock 235 291 352 minecraft:red_mushroom_block
fill 235 291 353 235 308 355 minecraft:moss_block
setblock 236 291 324 minecraft:mushroom_stem
fill 236 291 325 236 291 328 minecraft:moss_block
setblock 236 291 329 minecraft:mushroom_stem
fill 236 291 330 236 292 330 minecraft:moss_block
setblock 236 291 334 minecraft:mushroom_stem
fill 236 291 335 236 291 338 minecraft:moss_block
setblock 236 291 339 minecraft:mushroom_stem
fill 236 291 340 236 291 343 minecraft:moss_block
setblock 236 291 344 minecraft:mushroom_stem
fill 236 291 345 236 291 348 minecraft:moss_block
setblock 236 291 349 minecraft:mushroom_stem
fill 236 291 350 236 291 353 minecraft:moss_block
setblock 236 291 354 minecraft:mushroom_stem
setblock 236 291 355 minecraft:moss_block
setblock 236 291 359 minecraft:mushroom_stem
setblock 236 291 360 minecraft:moss_block
setblock 237 291 323 minecraft:mushroom_stem
setblock 237 291 337 minecraft:moss_block
setblock 237 291 338 minecraft:mushroom_stem
fill 237 291 339 237 291 342 minecraft:moss_block
setblock 237 291 343 minecraft:mushroom_stem
fill 237 291 344 237 294 344 minecraft:moss_block
setblock 237 291 348 minecraft:mushroom_stem
fill 237 291 349 237 293 349 minecraft:moss_block
setblock 237 291 363 minecraft:mushroom_stem
fill 238 291 323 238 293 323 minecraft:moss_block
setblock 238 291 325 minecraft:light[level=12]
setblock 238 291 332 minecraft:light[level=12]
setblock 238 291 339 minecraft:light[level=12]
setblock 238 291 342 minecraft:mushroom_stem
fill 238 291 343 238 292 343 minecraft:moss_block
setblock 238 291 353 minecraft:light[level=12]
setblock 238 291 360 minecraft:light[level=12]
setblock 238 291 363 minecraft:moss_block
setblock 240 291 348 minecraft:shroomlight
setblock 242 291 323 minecraft:mushroom_stem
fill 243 291 323 246 291 323 minecraft:moss_block
fill 244 291 324 245 291 324 minecraft:moss_block
fill 244 291 363 246 291 363 minecraft:moss_block
setblock 245 291 325 minecraft:light[level=12]
setblock 245 291 332 minecraft:light[level=12]
setblock 245 291 339 minecraft:light[level=12]
setblock 245 291 346 minecraft:light[level=12]
setblock 245 291 353 minecraft:light[level=12]
setblock 245 291 360 minecraft:light[level=12]
setblock 245 291 364 minecraft:shroomlight
setblock 246 291 324 minecraft:mushroom_stem
fill 246 291 325 249 291 325 minecraft:moss_block
fill 246 291 364 248 308 364 minecraft:moss_block
setblock 247 291 323 minecraft:mushroom_stem
fill 247 291 324 250 291 324 minecraft:moss_block
setblock 247 291 362 minecraft:moss_block
setblock 247 291 363 minecraft:mushroom_stem
fill 248 291 323 251 291 323 minecraft:moss_block
setblock 248 291 362 minecraft:mushroom_stem
fill 248 291 363 251 291 363 minecraft:moss_block
setblock 249 291 326 minecraft:mushroom_stem
fill 249 291 362 252 291 362 minecraft:moss_block
setblock 250 291 325 minecraft:mushroom_stem
fill 250 291 326 250 294 326 minecraft:moss_block
setblock 251 291 324 minecraft:mushroom_stem
fill 251 291 325 251 294 325 minecraft:moss_block
setblock 252 291 323 minecraft:mushroom_stem
fill 252 291 324 252 294 324 minecraft:moss_block
fill 252 291 326 253 291 326 minecraft:moss_block
setblock 252 291 332 minecraft:light[level=12]
setblock 252 291 339 minecraft:light[level=12]
setblock 252 291 346 minecraft:light[level=12]
setblock 252 291 353 minecraft:light[level=12]
setblock 252 291 360 minecraft:light[level=12]
setblock 252 291 363 minecraft:mushroom_stem
fill 253 291 323 253 294 323 minecraft:moss_block
setblock 253 291 362 minecraft:mushroom_stem
fill 253 291 363 256 291 363 minecraft:moss_block
setblock 254 291 326 minecraft:mushroom_stem
setblock 254 291 361 minecraft:mushroom_stem
fill 254 291 362 254 294 362 minecraft:moss_block
setblock 255 291 325 minecraft:mushroom_stem
setblock 255 291 326 minecraft:moss_block
setblock 256 291 324 minecraft:mushroom_stem
fill 256 291 325 256 294 325 minecraft:moss_block
setblock 257 291 323 minecraft:mushroom_stem
fill 257 291 324 257 294 324 minecraft:moss_block
setblock 257 291 363 minecraft:mushroom_stem
fill 258 291 323 261 291 323 minecraft:moss_block
setblock 258 291 362 minecraft:mushroom_stem
fill 258 291 363 261 291 363 minecraft:moss_block
setblock 259 291 325 minecraft:light[level=12]
setblock 259 291 332 minecraft:light[level=12]
setblock 259 291 339 minecraft:light[level=12]
setblock 259 291 346 minecraft:light[level=12]
setblock 259 291 353 minecraft:light[level=12]
setblock 259 291 360 minecraft:light[level=12]
fill 259 291 362 262 291 362 minecraft:moss_block
setblock 261 291 324 minecraft:mushroom_stem
fill 261 291 326 261 295 326 minecraft:mushroom_stem
setblock 262 291 323 minecraft:mushroom_stem
fill 262 291 324 265 291 324 minecraft:moss_block
setblock 262 291 363 minecraft:mushroom_stem
fill 263 291 323 266 291 323 minecraft:moss_block
setblock 263 291 362 minecraft:mushroom_stem
fill 263 291 363 266 291 363 minecraft:moss_block
fill 264 291 362 267 291 362 minecraft:moss_block
setblock 266 291 324 minecraft:mushroom_stem
setblock 266 291 325 minecraft:light[level=12]
setblock 266 291 332 minecraft:light[level=12]
setblock 266 291 339 minecraft:light[level=12]
setblock 266 291 346 minecraft:light[level=12]
setblock 266 291 353 minecraft:light[level=12]
setblock 266 291 360 minecraft:light[level=12]
fill 266 291 361 268 291 361 minecraft:moss_block
setblock 267 291 323 minecraft:mushroom_stem
fill 267 291 324 270 291 324 minecraft:moss_block
setblock 267 291 363 minecraft:mushroom_stem
fill 268 291 323 268 294 323 minecraft:moss_block
fill 268 291 325 269 291 325 minecraft:moss_block
setblock 268 291 362 minecraft:mushroom_stem
fill 268 291 363 268 294 363 minecraft:moss_block
setblock 269 291 361 minecraft:mushroom_stem
fill 269 291 362 269 294 362 minecraft:moss_block
setblock 270 291 325 minecraft:mushroom_stem
setblock 270 291 360 minecraft:mushroom_stem
fill 270 291 361 270 294 361 minecraft:moss_block
setblock 271 291 324 minecraft:mushroom_stem
fill 271 291 325 271 292 325 minecraft:moss_block
setblock 271 291 360 minecraft:moss_block
setblock 272 291 323 minecraft:mushroom_stem
fill 272 291 324 272 294 324 minecraft:moss_block
setblock 272 291 363 minecraft:mushroom_stem
fill 273 291 323 273 294 323 minecraft:moss_block
setblock 273 291 325 minecraft:light[level=12]
setblock 273 291 332 minecraft:light[level=12]
fill 273 291 342 273 300 342 minecraft:mushroom_stem
setblock 273 291 343 minecraft:moss_block
setblock 273 291 346 minecraft:moss_block
setblock 273 291 347 minecraft:mushroom_stem
fill 273 291 348 276 291 348 minecraft:moss_block
setblock 273 291 353 minecraft:light[level=12]
setblock 273 291 360 minecraft:light[level=12]
setblock 273 291 362 minecraft:mushroom_stem
fill 273 291 363 273 294 363 minecraft:moss_block
fill 274 291 339 274 300 339 minecraft:mushroom_stem
setblock 274 291 341 minecraft:mushroom_stem
fill 274 291 342 274 293 342 minecraft:moss_block
setblock 274 291 346 minecraft:mushroom_stem
fill 274 291 347 276 292 347 minecraft:moss_block
fill 274 291 349 274 291 350 minecraft:moss_block
setblock 274 291 351 minecraft:mushroom_stem
fill 274 291 352 274 292 352 minecraft:moss_block
setblock 274 291 357 minecraft:moss_block
setblock 274 291 361 minecraft:mushroom_stem
fill 274 291 362 274 294 362 minecraft:moss_block
setblock 275 291 324 minecraft:moss_block
setblock 275 291 325 minecraft:mushroom_stem
setblock 275 291 326 minecraft:moss_block
setblock 275 291 340 minecraft:mushroom_stem
fill 275 291 341 275 294 341 minecraft:moss_block
setblock 275 291 345 minecraft:mushroom_stem
fill 275 291 346 276 293 346 minecraft:moss_block
setblock 275 291 349 minecraft:moss_block
setblock 275 291 350 minecraft:mushroom_stem
fill 275 291 351 275 294 351 minecraft:moss_block
setblock 275 291 355 minecraft:mushroom_stem
fill 275 291 356 275 292 356 minecraft:moss_block
setblock 275 291 360 minecraft:mushroom_stem
fill 275 291 361 275 293 361 minecraft:moss_block
setblock 276 291 324 minecraft:mushroom_stem
fill 276 291 325 276 294 325 minecraft:moss_block
setblock 276 291 333 minecraft:red_mushroom_block
setblock 276 291 339 minecraft:mushroom_stem
fill 276 291 340 276 294 340 minecraft:moss_block
setblock 276 291 344 minecraft:mushroom_stem
fill 276 291 345 276 294 345 minecraft:moss_block
setblock 276 291 349 minecraft:mushroom_stem
fill 276 291 350 276 294 350 minecraft:moss_block
setblock 276 291 354 minecraft:mushroom_stem
fill 276 291 355 276 294 355 minecraft:moss_block
setblock 276 291 359 minecraft:mushroom_stem
fill 276 291 360 276 293 360 minecraft:moss_block
fill 235 292 352 236 292 352 minecraft:moss_block
setblock 236 292 323 minecraft:mushroom_stem
fill 236 292 324 236 292 327 minecraft:moss_block
setblock 236 292 328 minecraft:mushroom_stem
fill 236 292 329 236 295 329 minecraft:moss_block
setblock 236 292 333 minecraft:mushroom_stem
fill 236 292 334 236 292 337 minecraft:moss_block
setblock 236 292 338 minecraft:mushroom_stem
fill 236 292 339 236 292 342 minecraft:moss_block
setblock 236 292 343 minecraft:mushroom_stem
fill 236 292 344 236 292 347 minecraft:moss_block
setblock 236 292 348 minecraft:mushroom_stem
fill 236 292 349 236 293 351 minecraft:moss_block
setblock 236 292 353 minecraft:mushroom_stem
setblock 236 292 359 minecraft:red_mushroom_block
setblock 236 292 363 minecraft:mushroom_stem
fill 237 292 323 237 294 323 minecraft:moss_block
fill 237 292 338 237 292 341 minecraft:moss_block
setblock 237 292 342 minecraft:mushroom_stem
fill 237 292 343 237 294 343 minecraft:moss_block
setblock 237 292 347 minecraft:mushroom_stem
fill 237 292 348 237 294 348 minecraft:moss_block
setblock 237 292 363 minecraft:moss_block
fill 238 292 327 238 293 327 minecraft:dirt
setblock 238 292 342 minecraft:moss_block
fill 238 292 346 238 300 346 minecraft:mushroom_stem
fill 240 292 330 240 293 330 minecraft:dirt
fill 240 292 340 240 293 340 minecraft:dirt
fill 240 292 348 240 296 348 minecraft:mushroom_stem
setblock 241 292 323 minecraft:mushroom_stem
fill 242 292 323 245 292 323 minecraft:moss_block
fill 243 292 324 244 292 324 minecraft:moss_block
fill 244 292 363 245 292 363 minecraft:moss_block
setblock 245 292 324 minecraft:mushroom_stem
fill 245 292 364 245 308 364 minecraft:moss_block
setblock 246 292 323 minecraft:mushroom_stem
fill 246 292 324 248 292 325 minecraft:moss_block
setblock 246 292 363 minecraft:mushroom_stem
fill 247 292 323 250 292 323 minecraft:moss_block
fill 247 292 358 247 293 358 minecraft:dirt
fill 247 292 363 250 292 363 minecraft:moss_block
setblock 248 292 326 minecraft:mushroom_stem
fill 248 292 362 251 292 362 minecraft:moss_block
setblock 249 292 324 minecraft:moss_block
setblock 249 292 325 minecraft:mushroom_stem
fill 249 292 326 249 295 326 minecraft:moss_block
setblock 250 292 324 minecraft:mushroom_stem
fill 250 292 325 250 295 325 minecraft:moss_block
setblock 251 292 323 minecraft:mushroom_stem
fill 251 292 324 251 295 324 minecraft:moss_block
setblock 251 292 363 minecraft:mushroom_stem
fill 252 292 323 252 295 323 minecraft:moss_block
setblock 252 292 326 minecraft:moss_block
setblock 252 292 362 minecraft:mushroom_stem
fill 252 292 363 255 292 363 minecraft:moss_block
setblock 253 292 326 minecraft:mushroom_stem
fill 253 292 362 253 294 362 minecraft:moss_block
setblock 254 292 325 minecraft:mushroom_stem
setblock 254 292 326 minecraft:moss_block
setblock 255 292 324 minecraft:mushroom_stem
fill 255 292 325 255 295 325 minecraft:moss_block
setblock 256 292 323 minecraft:mushroom_stem
fill 256 292 324 256 295 324 minecraft:moss_block
setblock 256 292 363 minecraft:mushroom_stem
fill 257 292 323 260 292 323 minecraft:moss_block
setblock 257 292 362 minecraft:mushroom_stem
fill 257 292 363 260 292 363 minecraft:moss_block
fill 258 292 362 261 292 362 minecraft:moss_block
setblock 260 292 324 minecraft:mushroom_stem
setblock 261 292 323 minecraft:mushroom_stem
fill 261 292 324 264 292 324 minecraft:moss_block
setblock 261 292 363 minecraft:mushroom_stem
fill 262 292 323 265 292 323 minecraft:moss_block
setblock 262 292 362 minecraft:mushroom_stem
fill 262 292 363 265 292 363 minecraft:moss_block
fill 263 292 362 266 292 362 minecraft:moss_block
setblock 265 292 324 minecraft:mushroom_stem
setblock 266 292 323 minecraft:mushroom_stem
fill 266 292 324 269 292 324 minecraft:moss_block
fill 266 292 361 267 292 361 minecraft:moss_block
setblock 266 292 363 minecraft:mushroom_stem
fill 267 292 323 267 295 323 minecraft:moss_block
setblock 267 292 362 minecraft:mushroom_stem
fill 267 292 363 267 295 363 minecraft:moss_block
setblock 268 292 325 minecraft:moss_block
setblock 268 292 361 minecraft:mushroom_stem
fill 268 292 362 268 295 362 minecraft:moss_block
setblock 269 292 325 minecraft:mushroom_stem
fill 269 292 361 269 294 361 minecraft:moss_block
setblock 270 292 324 minecraft:mushroom_stem
fill 270 292 325 270 293 325 minecraft:moss_block
setblock 271 292 323 minecraft:mushroom_stem
fill 271 292 324 271 295 324 minecraft:moss_block
fill 271 292 348 271 293 348 minecraft:dirt
setblock 271 292 363 minecraft:mushroom_stem
fill 272 292 323 272 295 323 minecraft:moss_block
fill 272 292 358 272 293 358 minecraft:dirt
setblock 272 292 362 minecraft:mushroom_stem
fill 272 292 363 272 295 363 minecraft:moss_block
setblock 273 292 346 minecraft:mushroom_stem
fill 273 292 347 273 293 348 minecraft:moss_block
setblock 273 292 361 minecraft:mushroom_stem
fill 273 292 362 273 294 362 minecraft:moss_block
fill 274 292 340 274 300 340 minecraft:mushroom_stem
setblock 274 292 341 minecraft:moss_block
setblock 274 292 345 minecraft:mushroom_stem
fill 274 292 346 274 295 346 minecraft:moss_block
fill 274 292 348 274 292 349 minecraft:moss_block
setblock 274 292 350 minecraft:mushroom_stem
fill 274 292 351 274 293 351 minecraft:moss_block
setblock 274 292 360 minecraft:mushroom_stem
setblock 274 292 361 minecraft:moss_block
setblock 275 292 324 minecraft:mushroom_stem
setblock 275 292 325 minecraft:moss_block
setblock 275 292 339 minecraft:mushroom_stem
fill 275 292 340 275 293 340 minecraft:moss_block
setblock 275 292 344 minecraft:mushroom_stem
fill 275 292 345 275 295 345 minecraft:moss_block
setblock 275 292 348 minecraft:moss_block
setblock 275 292 349 minecraft:mushroom_stem
fill 275 292 350 275 295 350 minecraft:moss_block
setblock 275 292 354 minecraft:mushroom_stem
setblock 275 292 355 minecraft:moss_block
setblock 275 292 359 minecraft:mushroom_stem
fill 275 292 360 275 293 360 minecraft:moss_block
setblock 276 292 323 minecraft:mushroom_stem
fill 276 292 324 276 294 324 minecraft:moss_block
setblock 276 292 338 minecraft:mushroom_stem
fill 276 292 339 276 293 339 minecraft:moss_block
setblock 276 292 343 minecraft:mushroom_stem
fill 276 292 344 276 295 344 minecraft:moss_block
setblock 276 292 348 minecraft:mushroom_stem
fill 276 292 349 276 295 349 minecraft:moss_block
setblock 276 292 353 minecraft:mushroom_stem
fill 276 292 354 276 295 354 minecraft:moss_block
setblock 276 292 358 minecraft:mushroom_stem
fill 276 292 359 276 293 359 minecraft:moss_block
setblock 276 292 363 minecraft:mushroom_stem
fill 235 293 352 235 308 352 minecraft:moss_block
fill 236 293 323 236 293 326 minecraft:moss_block
setblock 236 293 327 minecraft:mushroom_stem
fill 236 293 328 236 296 328 minecraft:moss_block
setblock 236 293 336 minecraft:moss_block
setblock 236 293 337 minecraft:mushroom_stem
fill 236 293 338 236 293 341 minecraft:moss_block
setblock 236 293 342 minecraft:mushroom_stem
fill 236 293 343 236 293 346 minecraft:moss_block
setblock 236 293 347 minecraft:mushroom_stem
fill 236 293 348 236 296 348 minecraft:moss_block
setblock 236 293 352 minecraft:mushroom_stem
setblock 237 293 340 minecraft:moss_block
setblock 237 293 341 minecraft:mushroom_stem
fill 237 293 342 237 294 342 minecraft:moss_block
setblock 237 293 346 minecraft:mushroom_stem
fill 237 293 347 237 295 347 minecraft:moss_block
setblock 238 293 325 minecraft:light[level=15]
fill 238 293 326 238 294 326 minecraft:dirt
setblock 238 293 333 minecraft:light[level=15]
setblock 238 293 341 minecraft:light[level=15]
fill 238 293 342 238 300 345 minecraft:mushroom_stem
setblock 238 293 349 minecraft:light[level=15]
setblock 238 293 357 minecraft:light[level=15]
setblock 238 293 363 minecraft:red_mushroom_block
fill 239 293 330 239 294 330 minecraft:dirt
fill 239 293 340 239 294 340 minecraft:dirt
fill 239 293 348 239 294 348 minecraft:dirt
setblock 240 293 323 minecraft:mushroom_stem
fill 240 293 360 244 293 362 minecraft:brown_mushroom_block
fill 241 293 323 244 293 323 minecraft:moss_block
fill 241 293 359 243 293 359 minecraft:brown_mushroom_block
fill 241 293 363 243 293 363 minecraft:brown_mushroom_block
setblock 243 293 324 minecraft:moss_block
setblock 244 293 324 minecraft:mushroom_stem
setblock 245 293 323 minecraft:mushroom_stem
fill 245 293 324 247 293 325 minecraft:moss_block
setblock 245 293 363 minecraft:mushroom_stem
fill 246 293 323 249 293 323 minecraft:moss_block
setblock 246 293 333 minecraft:light[level=15]
setblock 246 293 341 minecraft:light[level=15]
setblock 246 293 349 minecraft:light[level=15]
setblock 246 293 357 minecraft:light[level=15]
fill 246 293 363 249 293 363 minecraft:moss_block
fill 247 293 359 247 294 359 minecraft:dirt
setblock 248 293 324 minecraft:moss_block
setblock 248 293 325 minecraft:mushroom_stem
fill 248 293 326 248 296 326 minecraft:moss_block
fill 248 293 362 250 293 362 minecraft:moss_block
setblock 249 293 324 minecraft:mushroom_stem
fill 249 293 325 249 296 325 minecraft:moss_block
setblock 250 293 323 minecraft:mushroom_stem
fill 250 293 324 250 296 324 minecraft:moss_block
setblock 250 293 363 minecraft:mushroom_stem
fill 251 293 323 251 296 323 minecraft:moss_block
setblock 251 293 362 minecraft:mushroom_stem
fill 251 293 363 254 293 363 minecraft:moss_block
setblock 252 293 326 minecraft:mushroom_stem
fill 252 293 362 252 294 362 minecraft:moss_block
setblock 253 293 325 minecraft:mushroom_stem
fill 253 293 326 253 294 326 minecraft:moss_block
setblock 254 293 324 minecraft:mushroom_stem
fill 254 293 325 254 296 325 minecraft:moss_block
setblock 254 293 333 minecraft:light[level=15]
setblock 254 293 341 minecraft:light[level=15]
setblock 254 293 349 minecraft:light[level=15]
setblock 254 293 357 minecraft:light[level=15]
setblock 255 293 323 minecraft:mushroom_stem
fill 255 293 324 255 296 324 minecraft:moss_block
setblock 255 293 363 minecraft:mushroom_stem
setblock 256 293 322 minecraft:shroomlight
fill 256 293 323 259 293 323 minecraft:moss_block
setblock 256 293 362 minecraft:mushroom_stem
fill 256 293 363 259 293 363 minecraft:moss_block
setblock 257 293 362 minecraft:moss_block
setblock 259 293 324 minecraft:mushroom_stem
setblock 260 293 323 minecraft:mushroom_stem
fill 260 293 324 263 293 324 minecraft:moss_block
setblock 260 293 363 minecraft:mushroom_stem
fill 261 293 323 264 293 323 minecraft:moss_block
fill 261 293 363 264 293 363 minecraft:moss_block
setblock 262 293 325 minecraft:light[level=15]
setblock 262 293 333 minecraft:light[level=15]
setblock 262 293 341 minecraft:light[level=15]
setblock 262 293 349 minecraft:light[level=15]
setblock 262 293 357 minecraft:light[level=15]
fill 263 293 362 265 293 362 minecraft:moss_block
setblock 264 293 324 minecraft:mushroom_stem
setblock 265 293 323 minecraft:mushroom_stem
fill 265 293 324 268 293 324 minecraft:moss_block
setblock 265 293 363 minecraft:mushroom_stem
fill 266 293 323 266 296 323 minecraft:moss_block
setblock 266 293 362 minecraft:mushroom_stem
fill 266 293 363 266 296 363 minecraft:moss_block
setblock 267 293 322 minecraft:red_mushroom_block
setblock 267 293 361 minecraft:mushroom_stem
fill 267 293 362 267 296 362 minecraft:moss_block
setblock 268 293 325 minecraft:mushroom_stem
fill 268 293 361 268 294 361 minecraft:moss_block
setblock 269 293 324 minecraft:mushroom_stem
setblock 269 293 325 minecraft:moss_block
setblock 270 293 323 minecraft:mushroom_stem
fill 270 293 324 270 296 324 minecraft:moss_block
setblock 270 293 333 minecraft:light[level=15]
setblock 270 293 341 minecraft:light[level=15]
setblock 270 293 349 minecraft:light[level=15]
setblock 270 293 357 minecraft:light[level=15]
setblock 270 293 363 minecraft:mushroom_stem
fill 271 293 323 271 296 323 minecraft:moss_block
setblock 271 293 362 minecraft:mushroom_stem
fill 271 293 363 271 296 363 minecraft:moss_block
fill 272 293 348 272 294 348 minecraft:dirt
fill 272 293 359 272 294 359 minecraft:dirt
setblock 272 293 361 minecraft:mushroom_stem
fill 272 293 362 272 295 362 minecraft:moss_block
setblock 273 293 345 minecraft:mushroom_stem
setblock 273 293 346 minecraft:moss_block
setblock 273 293 361 minecraft:moss_block
setblock 274 293 324 minecraft:mushroom_stem
fill 274 293 341 274 300 341 minecraft:mushroom_stem
setblock 274 293 344 minecraft:mushroom_stem
fill 274 293 345 274 295 345 minecraft:moss_block
fill 274 293 347 274 293 348 minecraft:moss_block
setblock 274 293 349 minecraft:mushroom_stem
fill 274 293 350 274 295 350 minecraft:moss_block
setblock 275 293 323 minecraft:mushroom_stem
setblock 275 293 343 minecraft:mushroom_stem
fill 275 293 344 275 296 344 minecraft:moss_block
setblock 275 293 347 minecraft:moss_block
setblock 275 293 348 minecraft:mushroom_stem
fill 275 293 349 275 296 349 minecraft:moss_block
setblock 275 293 353 minecraft:mushroom_stem
setblock 275 293 354 minecraft:moss_block
setblock 275 293 363 minecraft:mushroom_stem
fill 276 293 323 276 294 323 minecraft:moss_block
setblock 276 293 327 minecraft:mushroom_stem
setblock 276 293 338 minecraft:moss_block
setblock 276 293 342 minecraft:mushroom_stem
fill 276 293 343 276 296 343 minecraft:moss_block
setblock 276 293 347 minecraft:mushroom_stem
fill 276 293 348 276 296 348 minecraft:moss_block
setblock 276 293 352 minecraft:mushroom_stem
fill 276 293 353 276 296 353 minecraft:moss_block
setblock 276 293 357 minecraft:mushroom_stem
setblock 276 293 358 minecraft:moss_block
setblock 276 293 362 minecraft:mushroom_stem
fill 276 293 363 276 294 363 minecraft:moss_block
setblock 277 293 326 minecraft:red_mushroom_block
fill 277 293 333 277 308 333 minecraft:moss_block
setblock 277 293 334 minecraft:shroomlight
fill 236 294 323 236 294 325 minecraft:moss_block
setblock 236 294 326 minecraft:mushroom_stem
fill 236 294 327 236 297 327 minecraft:moss_block
fill 236 294 338 236 294 340 minecraft:moss_block
setblock 236 294 341 minecraft:mushroom_stem
fill 236 294 342 236 294 345 minecraft:moss_block
setblock 236 294 346 minecraft:mushroom_stem
fill 236 294 347 236 297 347 minecraft:moss_block
fill 236 294 349 236 294 350 minecraft:moss_block
setblock 236 294 351 minecraft:mushroom_stem
setblock 236 294 352 minecraft:red_mushroom_block
setblock 237 294 341 minecraft:moss_block
setblock 237 294 345 minecraft:mushroom_stem
fill 237 294 346 237 295 346 minecraft:moss_block
fill 238 294 325 238 295 325 minecraft:dirt
fill 238 294 330 238 295 330 minecraft:dirt
fill 238 294 340 238 295 340 minecraft:dirt
fill 238 294 348 238 295 348 minecraft:dirt
setblock 238 294 364 minecraft:red_mushroom_block
fill 240 294 323 243 294 323 minecraft:moss_block
setblock 243 294 324 minecraft:mushroom_stem
setblock 244 294 323 minecraft:mushroom_stem
fill 244 294 324 247 294 324 minecraft:moss_block
setblock 244 294 363 minecraft:red_mushroom_block
fill 245 294 323 248 294 323 minecraft:moss_block
fill 245 294 325 246 294 325 minecraft:moss_block
fill 245 294 363 248 294 363 minecraft:moss_block
setblock 247 294 325 minecraft:mushroom_stem
fill 247 294 326 247 297 326 minecraft:moss_block
fill 247 294 360 247 295 360 minecraft:dirt
setblock 248 294 324 minecraft:mushroom_stem
fill 248 294 325 248 297 325 minecraft:moss_block
setblock 249 294 323 minecraft:mushroom_stem
fill 249 294 324 249 297 324 minecraft:moss_block
setblock 249 294 362 minecraft:moss_block
setblock 249 294 363 minecraft:mushroom_stem
fill 250 294 323 250 297 323 minecraft:moss_block
setblock 250 294 362 minecraft:mushroom_stem
fill 250 294 363 253 294 363 minecraft:moss_block
setblock 251 294 326 minecraft:mushroom_stem
setblock 251 294 362 minecraft:moss_block
setblock 252 294 325 minecraft:mushroom_stem
fill 252 294 326 252 295 326 minecraft:moss_block
setblock 253 294 324 minecraft:mushroom_stem
fill 253 294 325 253 297 325 minecraft:moss_block
setblock 254 294 323 minecraft:mushroom_stem
fill 254 294 324 254 297 324 minecraft:moss_block
setblock 254 294 363 minecraft:mushroom_stem
fill 255 294 323 258 294 323 minecraft:moss_block
fill 255 294 363 258 294 363 minecraft:moss_block
fill 256 294 322 256 308 322 minecraft:moss_block
setblock 258 294 324 minecraft:mushroom_stem
setblock 259 294 323 minecraft:mushroom_stem
fill 259 294 324 262 294 324 minecraft:moss_block
setblock 259 294 363 minecraft:mushroom_stem
fill 260 294 323 263 294 323 minecraft:moss_block
fill 260 294 363 263 294 363 minecraft:moss_block
setblock 263 294 324 minecraft:mushroom_stem
setblock 264 294 323 minecraft:mushroom_stem
fill 264 294 324 267 294 324 minecraft:moss_block
setblock 264 294 362 minecraft:moss_block
setblock 264 294 363 minecraft:mushroom_stem
fill 265 294 323 265 297 323 minecraft:moss_block
setblock 265 294 362 minecraft:mushroom_stem
fill 265 294 363 265 297 363 minecraft:moss_block
fill 266 294 362 266 297 362 minecraft:moss_block
fill 267 294 322 267 308 322 minecraft:moss_block
setblock 268 294 324 minecraft:mushroom_stem
setblock 269 294 323 minecraft:mushroom_stem
fill 269 294 324 269 297 324 minecraft:moss_block
setblock 269 294 363 minecraft:mushroom_stem
fill 270 294 323 270 297 323 minecraft:moss_block
setblock 270 294 362 minecraft:mushroom_stem
fill 270 294 363 270 297 363 minecraft:moss_block
fill 271 294 362 271 296 362 minecraft:moss_block
fill 272 294 360 272 295 360 minecraft:dirt
setblock 273 294 324 minecraft:mushroom_stem
fill 273 294 348 273 295 348 minecraft:dirt
setblock 274 294 323 minecraft:mushroom_stem
setblock 274 294 343 minecraft:mushroom_stem
setblock 274 294 344 minecraft:moss_block
setblock 274 294 347 minecraft:moss_block
setblock 274 294 348 minecraft:mushroom_stem
fill 274 294 349 274 297 349 minecraft:moss_block
setblock 274 294 363 minecraft:mushroom_stem
fill 275 294 323 275 295 323 minecraft:moss_block
fill 275 294 340 275 300 340 minecraft:mushroom_stem
setblock 275 294 342 minecraft:mushroom_stem
fill 275 294 343 275 295 343 minecraft:moss_block
setblock 275 294 346 minecraft:moss_block
setblock 275 294 347 minecraft:mushroom_stem
fill 275 294 348 275 297 348 minecraft:moss_block
setblock 275 294 352 minecraft:mushroom_stem
fill 275 294 363 275 295 363 minecraft:moss_block
setblock 276 294 334 minecraft:red_mushroom_block
setblock 276 294 341 minecraft:mushroom_stem
fill 276 294 342 276 296 342 minecraft:moss_block
setblock 276 294 346 minecraft:mushroom_stem
fill 276 294 347 276 297 347 minecraft:moss_block
setblock 276 294 351 minecraft:mushroom_stem
fill 276 294 352 276 297 352 minecraft:moss_block
setblock 276 294 359 minecraft:red_mushroom_block
setblock 276 294 362 minecraft:moss_block
fill 277 294 326 277 308 326 minecraft:moss_block
fill 277 294 334 277 308 334 minecraft:moss_block
setblock 236 295 324 minecraft:moss_block
setblock 236 295 325 minecraft:mushroom_stem
fill 236 295 326 236 298 326 minecraft:moss_block
setblock 236 295 333 minecraft:red_mushroom_block
setblock 236 295 339 minecraft:moss_block
setblock 236 295 340 minecraft:mushroom_stem
fill 236 295 341 236 295 344 minecraft:moss_block
setblock 236 295 345 minecraft:mushroom_stem
fill 236 295 346 236 298 346 minecraft:moss_block
setblock 236 295 349 minecraft:moss_block
setblock 236 295 350 minecraft:mushroom_stem
setblock 236 295 351 minecraft:moss_block
setblock 236 295 358 minecraft:red_mushroom_block
setblock 237 295 323 minecraft:red_mushroom_block
fill 237 295 330 237 296 330 minecraft:dirt
fill 237 295 340 237 296 340 minecraft:dirt
fill 237 295 342 237 300 344 minecraft:mushroom_stem
setblock 237 295 345 minecraft:moss_block
fill 237 295 348 237 296 348 minecraft:dirt
fill 238 295 324 238 296 324 minecraft:dirt
fill 238 295 364 238 308 364 minecraft:moss_block
fill 241 295 323 242 295 323 minecraft:moss_block
setblock 243 295 323 minecraft:mushroom_stem
fill 243 295 324 246 295 324 minecraft:moss_block
fill 244 295 323 247 295 323 minecraft:moss_block
setblock 245 295 325 minecraft:moss_block
setblock 246 295 325 minecraft:mushroom_stem
fill 246 295 363 247 295 363 minecraft:moss_block
setblock 247 295 324 minecraft:mushroom_stem
fill 247 295 325 247 298 325 minecraft:moss_block
fill 247 295 361 247 296 361 minecraft:dirt
setblock 248 295 323 minecraft:mushroom_stem
fill 248 295 324 248 298 324 minecraft:moss_block
setblock 248 295 363 minecraft:mushroom_stem
fill 249 295 323 249 298 323 minecraft:moss_block
fill 249 295 363 252 295 363 minecraft:moss_block
setblock 250 295 326 minecraft:mushroom_stem
setblock 251 295 325 minecraft:mushroom_stem
fill 251 295 326 251 296 326 minecraft:moss_block
setblock 252 295 324 minecraft:mushroom_stem
fill 252 295 325 252 298 325 minecraft:moss_block
setblock 253 295 323 minecraft:mushroom_stem
fill 253 295 324 253 298 324 minecraft:moss_block
setblock 253 295 363 minecraft:mushroom_stem
fill 254 295 323 257 295 323 minecraft:moss_block
fill 254 295 363 257 295 363 minecraft:moss_block
setblock 257 295 324 minecraft:mushroom_stem
setblock 258 295 323 minecraft:mushroom_stem
setblock 258 295 324 minecraft:moss_block
setblock 258 295 363 minecraft:mushroom_stem
fill 259 295 323 262 295 323 minecraft:moss_block
fill 259 295 363 262 295 363 minecraft:moss_block
setblock 263 295 323 minecraft:mushroom_stem
fill 263 295 324 266 295 324 minecraft:moss_block
setblock 263 295 363 minecraft:mushroom_stem
fill 264 295 323 264 298 323 minecraft:moss_block
fill 264 295 363 264 298 363 minecraft:moss_block
fill 265 295 362 265 296 362 minecraft:moss_block
setblock 267 295 324 minecraft:mushroom_stem
setblock 268 295 323 minecraft:mushroom_stem
fill 268 295 324 268 298 324 minecraft:moss_block
setblock 268 295 363 minecraft:mushroom_stem
fill 269 295 323 269 298 323 minecraft:moss_block
setblock 269 295 362 minecraft:mushroom_stem
fill 269 295 363 269 298 363 minecraft:moss_block
fill 270 295 362 270 296 362 minecraft:moss_block
setblock 272 295 324 minecraft:mushroom_stem
fill 272 295 361 272 296 361 minecraft:dirt
setblock 273 295 323 minecraft:mushroom_stem
setblock 273 295 363 minecraft:mushroom_stem
setblock 274 295 323 minecraft:moss_block
setblock 274 295 347 minecraft:mushroom_stem
fill 274 295 348 274 297 348 minecraft:moss_block
setblock 274 295 363 minecraft:moss_block
setblock 275 295 346 minecraft:mushroom_stem
fill 275 295 347 275 298 347 minecraft:moss_block
setblock 275 295 351 minecraft:mushroom_stem
fill 275 295 352 275 296 352 minecraft:moss_block
setblock 276 295 328 minecraft:red_mushroom_block
setblock 276 295 341 minecraft:moss_block
setblock 276 295 345 minecraft:mushroom_stem
fill 276 295 346 276 298 346 minecraft:moss_block
setblock 276 295 350 minecraft:mushroom_stem
fill 276 295 351 276 298 351 minecraft:moss_block
setblock 236 296 329 minecraft:mushroom_stem
setblock 236 296 330 minecraft:dirt
setblock 236 296 339 minecraft:red_mushroom_block
fill 236 296 340 236 297 340 minecraft:dirt
fill 236 296 341 236 296 343 minecraft:moss_block
setblock 236 296 344 minecraft:mushroom_stem
fill 236 296 345 236 299 345 minecraft:moss_block
setblock 236 296 349 minecraft:mushroom_stem
fill 236 296 350 236 299 350 minecraft:moss_block
fill 237 296 345 237 300 345 minecraft:mushroom_stem
setblock 237 296 363 minecraft:red_mushroom_block
fill 238 296 323 238 297 323 minecraft:dirt
setblock 241 296 323 minecraft:moss_block
setblock 242 296 323 minecraft:mushroom_stem
fill 243 296 323 245 296 324 minecraft:moss_block
setblock 245 296 325 minecraft:mushroom_stem
setblock 246 296 323 minecraft:moss_block
setblock 246 296 324 minecraft:mushroom_stem
fill 246 296 325 246 299 325 minecraft:moss_block
setblock 246 296 363 minecraft:moss_block
setblock 247 296 323 minecraft:mushroom_stem
fill 247 296 324 247 299 324 minecraft:moss_block
fill 247 296 362 247 297 362 minecraft:dirt
setblock 247 296 363 minecraft:mushroom_stem
fill 248 296 323 248 299 323 minecraft:moss_block
fill 248 296 363 251 296 363 minecraft:moss_block
setblock 249 296 326 minecraft:mushroom_stem
setblock 250 296 325 minecraft:mushroom_stem
fill 250 296 326 250 298 326 minecraft:moss_block
setblock 251 296 324 minecraft:mushroom_stem
fill 251 296 325 251 299 325 minecraft:moss_block
setblock 252 296 323 minecraft:mushroom_stem
fill 252 296 324 252 299 324 minecraft:moss_block
setblock 252 296 363 minecraft:mushroom_stem
fill 253 296 323 256 296 323 minecraft:moss_block
fill 253 296 363 256 296 363 minecraft:moss_block
setblock 255 296 360 minecraft:shroomlight
setblock 256 296 324 minecraft:mushroom_stem
setblock 257 296 323 minecraft:mushroom_stem
setblock 257 296 324 minecraft:moss_block
fill 258 296 323 261 296 323 minecraft:moss_block
fill 259 296 325 263 296 327 minecraft:red_mushroom_block
fill 260 296 324 262 296 324 minecraft:red_mushroom_block
fill 260 296 328 262 296 328 minecraft:red_mushroom_block
fill 260 296 363 261 296 363 minecraft:moss_block
setblock 262 296 323 minecraft:mushroom_stem
setblock 262 296 363 minecraft:mushroom_stem
fill 263 296 323 263 299 323 minecraft:moss_block
fill 263 296 363 263 299 363 minecraft:moss_block
fill 264 296 324 265 296 324 minecraft:moss_block
setblock 266 296 324 minecraft:mushroom_stem
setblock 267 296 323 minecraft:mushroom_stem
fill 267 296 324 267 299 324 minecraft:moss_block
setblock 267 296 363 minecraft:mushroom_stem
fill 268 296 323 268 299 323 minecraft:moss_block
setblock 268 296 362 minecraft:mushroom_stem
fill 268 296 363 268 299 363 minecraft:moss_block
fill 269 296 362 269 297 362 minecraft:moss_block
setblock 271 296 324 minecraft:mushroom_stem
setblock 272 296 323 minecraft:mushroom_stem
fill 272 296 362 272 297 362 minecraft:dirt
setblock 272 296 363 minecraft:mushroom_stem
setblock 273 296 323 minecraft:moss_block
setblock 273 296 363 minecraft:moss_block
setblock 274 296 346 minecraft:mushroom_stem
setblock 274 296 347 minecraft:moss_block
setblock 275 296 323 minecraft:red_mushroom_block
setblock 275 296 345 minecraft:mushroom_stem
fill 275 296 346 275 299 346 minecraft:moss_block
setblock 275 296 350 minecraft:mushroom_stem
fill 275 296 351 275 299 351 minecraft:moss_block
fill 276 296 341 276 298 341 minecraft:red_mushroom_block
setblock 276 296 344 minecraft:mushroom_stem
fill 276 296 345 276 299 345 minecraft:moss_block
setblock 276 296 349 minecraft:mushroom_stem
fill 276 296 350 276 299 350 minecraft:moss_block
setblock 277 296 328 minecraft:red_mushroom_block
setblock 236 297 328 minecraft:mushroom_stem
fill 236 297 329 236 299 330 minecraft:moss_block
fill 236 297 341 241 297 341 minecraft:red_mushroom_block
setblock 236 297 342 minecraft:moss_block
setblock 236 297 343 minecraft:mushroom_stem
fill 236 297 344 236 298 344 minecraft:moss_block
setblock 236 297 348 minecraft:mushroom_stem
fill 236 297 349 236 300 349 minecraft:moss_block
setblock 236 297 351 minecraft:red_mushroom_block
fill 237 297 340 240 297 340 minecraft:red_mushroom_block
fill 237 297 346 237 298 347 minecraft:red_mushroom_block
setblock 238 297 325 minecraft:light[level=12]
setblock 238 297 332 minecraft:light[level=12]
setblock 238 297 339 minecraft:light[level=12]
fill 238 297 347 242 297 349 minecraft:red_mushroom_block
setblock 238 297 353 minecraft:light[level=12]
setblock 238 297 360 minecraft:light[level=12]
fill 239 297 346 242 297 346 minecraft:red_mushroom_block
fill 239 297 350 241 297 350 minecraft:red_mushroom_block
setblock 240 297 329 minecraft:shroomlight
setblock 240 297 335 minecraft:shroomlight
fill 240 297 342 242 297 342 minecraft:red_mushroom_block
setblock 240 297 353 minecraft:shroomlight
setblock 240 297 359 minecraft:shroomlight
setblock 241 297 323 minecraft:mushroom_stem
fill 241 297 343 242 297 345 minecraft:red_mushroom_block
fill 242 297 323 245 297 323 minecraft:moss_block
setblock 242 297 327 minecraft:shroomlight
fill 243 297 324 244 297 324 minecraft:moss_block
setblock 243 297 363 minecraft:red_mushroom_block
setblock 244 297 325 minecraft:mushroom_stem
setblock 245 297 324 minecraft:mushroom_stem
fill 245 297 325 245 300 325 minecraft:moss_block
setblock 245 297 332 minecraft:light[level=12]
setblock 245 297 339 minecraft:light[level=12]
setblock 245 297 346 minecraft:light[level=12]
setblock 245 297 353 minecraft:light[level=12]
setblock 245 297 360 minecraft:light[level=12]
setblock 246 297 323 minecraft:mushroom_stem
fill 246 297 324 246 300 324 minecraft:moss_block
fill 246 297 326 246 298 326 minecraft:moss_block
fill 246 297 348 247 297 351 minecraft:red_mushroom_block
setblock 246 297 359 minecraft:shroomlight
setblock 246 297 363 minecraft:mushroom_stem
fill 247 297 323 247 300 323 minecraft:moss_block
fill 247 297 347 252 297 347 minecraft:red_mushroom_block
fill 247 297 352 252 297 352 minecraft:red_mushroom_block
fill 247 297 363 250 297 363 minecraft:moss_block
setblock 248 297 326 minecraft:mushroom_stem
setblock 248 297 327 minecraft:shroomlight
fill 248 297 346 251 297 346 minecraft:red_mushroom_block
fill 248 297 353 251 297 353 minecraft:red_mushroom_block
setblock 249 297 325 minecraft:mushroom_stem
fill 249 297 326 249 300 326 minecraft:moss_block
setblock 250 297 324 minecraft:mushroom_stem
fill 250 297 325 250 300 325 minecraft:moss_block
setblock 251 297 323 minecraft:mushroom_stem
fill 251 297 324 251 300 324 minecraft:moss_block
setblock 251 297 363 minecraft:mushroom_stem
fill 252 297 323 255 297 323 minecraft:moss_block
setblock 252 297 332 minecraft:light[level=12]
setblock 252 297 339 minecraft:light[level=12]
setblock 252 297 346 minecraft:light[level=12]
fill 252 297 348 253 297 351 minecraft:red_mushroom_block
setblock 252 297 353 minecraft:light[level=12]
setblock 252 297 359 minecraft:shroomlight
setblock 252 297 360 minecraft:light[level=12]
fill 252 297 363 254 297 363 minecraft:moss_block
setblock 254 297 327 minecraft:shroomlight
setblock 255 297 324 minecraft:mushroom_stem
fill 255 297 360 255 301 360 minecraft:mushroom_stem
setblock 256 297 323 minecraft:mushroom_stem
fill 257 297 323 260 297 323 minecraft:moss_block
setblock 258 297 359 minecraft:shroomlight
setblock 259 297 325 minecraft:light[level=12]
setblock 259 297 332 minecraft:light[level=12]
setblock 259 297 339 minecraft:light[level=12]
setblock 259 297 346 minecraft:light[level=12]
setblock 259 297 353 minecraft:light[level=12]
setblock 259 297 360 minecraft:light[level=12]
setblock 260 297 327 minecraft:shroomlight
setblock 261 297 323 minecraft:mushroom_stem
setblock 261 297 363 minecraft:mushroom_stem
fill 262 297 323 262 300 323 minecraft:moss_block
fill 262 297 363 262 300 363 minecraft:moss_block
setblock 264 297 324 minecraft:moss_block
setblock 264 297 359 minecraft:shroomlight
setblock 265 297 324 minecraft:mushroom_stem
setblock 266 297 323 minecraft:mushroom_stem
fill 266 297 324 266 300 324 minecraft:moss_block
setblock 266 297 325 minecraft:light[level=12]
setblock 266 297 327 minecraft:shroomlight
setblock 266 297 332 minecraft:light[level=12]
setblock 266 297 339 minecraft:light[level=12]
setblock 266 297 346 minecraft:light[level=12]
setblock 266 297 353 minecraft:light[level=12]
setblock 266 297 360 minecraft:light[level=12]
setblock 266 297 363 minecraft:mushroom_stem
fill 267 297 323 267 300 323 minecraft:moss_block
setblock 267 297 362 minecraft:mushroom_stem
fill 267 297 363 267 300 363 minecraft:moss_block
fill 268 297 362 268 298 362 minecraft:moss_block
fill 270 297 324 270 298 324 minecraft:mushroom_stem
fill 270 297 338 270 297 342 minecraft:red_mushroom_block
setblock 270 297 359 minecraft:shroomlight
setblock 271 297 323 minecraft:mushroom_stem
fill 271 297 337 271 297 339 minecraft:red_mushroom_block
fill 271 297 341 271 297 343 minecraft:red_mushroom_block
setblock 271 297 363 minecraft:mushroom_stem
setblock 272 297 323 minecraft:moss_block
setblock 272 297 327 minecraft:shroomlight
setblock 272 297 333 minecraft:shroomlight
fill 272 297 337 272 299 338 minecraft:red_mushroom_block
fill 272 297 342 272 299 343 minecraft:red_mushroom_block
setblock 272 297 345 minecraft:shroomlight
setblock 272 297 351 minecraft:shroomlight
setblock 272 297 357 minecraft:shroomlight
setblock 272 297 363 minecraft:moss_block
setblock 273 297 325 minecraft:light[level=12]
setblock 273 297 332 minecraft:light[level=12]
fill 273 297 336 274 297 337 minecraft:red_mushroom_block
fill 273 297 343 275 297 343 minecraft:red_mushroom_block
setblock 273 297 346 minecraft:light[level=12]
setblock 273 297 353 minecraft:light[level=12]
setblock 273 297 360 minecraft:light[level=12]
fill 274 297 338 276 297 338 minecraft:red_mushroom_block
fill 274 297 342 276 297 342 minecraft:red_mushroom_block
setblock 275 297 337 minecraft:red_mushroom_block
fill 275 297 339 276 298 339 minecraft:red_mushroom_block
fill 275 297 341 275 299 341 minecraft:red_mushroom_block
setblock 275 297 345 minecraft:moss_block
setblock 275 297 349 minecraft:mushroom_stem
fill 275 297 350 275 300 350 minecraft:moss_block
setblock 276 297 335 minecraft:red_mushroom_block
fill 276 297 340 276 298 340 minecraft:red_mushroom_block
setblock 276 297 343 minecraft:mushroom_stem
fill 276 297 344 276 300 344 minecraft:moss_block
setblock 276 297 348 minecraft:mushroom_stem
fill 276 297 349 276 300 349 minecraft:moss_block
setblock 276 297 353 minecraft:mushroom_stem
setblock 276 297 360 minecraft:red_mushroom_block
fill 277 297 328 277 308 328 minecraft:moss_block
fill 277 297 354 277 308 354 minecraft:moss_block
setblock 277 297 355 minecraft:red_mushroom_block
fill 277 297 356 277 308 356 minecraft:moss_block
fill 236 298 323 237 298 325 minecraft:mushroom_stem
fill 236 298 327 276 298 327 minecraft:mushroom_stem
fill 236 298 328 236 300 328 minecraft:moss_block
setblock 236 298 331 minecraft:moss_block
setblock 236 298 332 minecraft:red_mushroom_block
fill 236 298 333 240 298 340 minecraft:mushroom_stem
fill 236 298 341 236 298 343 minecraft:red_mushroom_block
setblock 236 298 347 minecraft:mushroom_stem
fill 236 298 348 236 300 348 minecraft:moss_block
fill 236 298 351 240 298 356 minecraft:mushroom_stem
setblock 236 298 357 minecraft:red_mushroom_block
fill 236 298 358 240 298 363 minecraft:mushroom_stem
fill 237 298 326 245 298 326 minecraft:mushroom_stem
fill 237 298 328 240 298 332 minecraft:mushroom_stem
fill 237 298 341 240 298 341 minecraft:red_mushroom_block
fill 237 298 348 240 298 350 minecraft:mushroom_stem
fill 237 298 357 240 298 357 minecraft:mushroom_stem
setblock 238 298 323 minecraft:red_mushroom_block
fill 238 298 324 241 298 325 minecraft:mushroom_stem
fill 238 298 347 240 298 347 minecraft:red_mushroom_block
fill 239 298 323 240 298 323 minecraft:mushroom_stem
fill 239 298 346 241 298 346 minecraft:red_mushroom_block
fill 240 298 342 241 298 342 minecraft:red_mushroom_block
fill 241 298 323 244 298 323 minecraft:moss_block
fill 241 298 343 241 299 345 minecraft:red_mushroom_block
fill 241 298 359 245 298 363 minecraft:mushroom_stem
fill 242 298 324 243 298 324 minecraft:moss_block
fill 242 298 325 243 298 325 minecraft:mushroom_stem
setblock 242 298 344 minecraft:red_mushroom_block
setblock 244 298 324 minecraft:mushroom_stem
fill 244 298 325 244 300 325 minecraft:moss_block
setblock 245 298 323 minecraft:mushroom_stem
fill 245 298 324 245 300 324 minecraft:moss_block
fill 246 298 323 246 300 323 minecraft:moss_block
fill 246 298 349 247 298 350 minecraft:red_mushroom_block
fill 246 298 359 254 298 362 minecraft:mushroom_stem
fill 246 298 363 249 298 363 minecraft:moss_block
setblock 247 298 326 minecraft:mushroom_stem
fill 247 298 347 247 298 348 minecraft:red_mushroom_block
fill 247 298 351 247 298 352 minecraft:red_mushroom_block
setblock 248 298 325 minecraft:mushroom_stem
fill 248 298 326 248 300 326 minecraft:moss_block
fill 248 298 347 251 298 347 minecraft:red_mushroom_block
fill 248 298 352 251 298 352 minecraft:red_mushroom_block
setblock 249 298 324 minecraft:mushroom_stem
fill 249 298 325 249 300 325 minecraft:moss_block
fill 249 298 353 250 298 353 minecraft:red_mushroom_block
setblock 250 298 323 minecraft:mushroom_stem
fill 250 298 324 250 300 324 minecraft:moss_block
setblock 250 298 363 minecraft:mushroom_stem
fill 251 298 323 254 298 323 minecraft:moss_block
fill 251 298 326 276 298 326 minecraft:mushroom_stem
fill 251 298 363 253 298 363 minecraft:moss_block
fill 252 298 348 252 298 351 minecraft:red_mushroom_block
fill 253 298 325 276 298 325 minecraft:mushroom_stem
setblock 254 298 324 minecraft:mushroom_stem
fill 254 298 363 260 298 363 minecraft:mushroom_stem
setblock 255 298 323 minecraft:mushroom_stem
setblock 255 298 324 minecraft:moss_block
fill 255 298 359 276 298 359 minecraft:mushroom_stem
fill 255 298 361 266 298 362 minecraft:mushroom_stem
fill 256 298 323 259 298 323 minecraft:moss_block
fill 256 298 324 264 298 324 minecraft:mushroom_stem
fill 256 298 360 276 298 360 minecraft:mushroom_stem
setblock 260 298 323 minecraft:mushroom_stem
fill 261 298 323 261 300 323 minecraft:moss_block
fill 261 298 363 261 300 363 minecraft:moss_block
setblock 265 298 323 minecraft:mushroom_stem
fill 265 298 324 265 300 324 minecraft:moss_block
setblock 265 298 363 minecraft:mushroom_stem
fill 266 298 323 266 300 323 minecraft:moss_block
fill 266 298 363 266 300 363 minecraft:moss_block
fill 267 298 361 276 298 361 minecraft:mushroom_stem
fill 267 298 362 267 300 362 minecraft:moss_block
setblock 269 298 324 minecraft:mushroom_stem
fill 269 298 362 276 298 362 minecraft:mushroom_stem
setblock 270 298 323 minecraft:mushroom_stem
fill 270 298 339 270 298 341 minecraft:red_mushroom_block
setblock 270 298 363 minecraft:mushroom_stem
setblock 271 298 323 minecraft:moss_block
fill 271 298 324 276 298 324 minecraft:mushroom_stem
fill 271 298 338 271 298 339 minecraft:red_mushroom_block
fill 271 298 341 271 298 342 minecraft:red_mushroom_block
fill 271 298 363 271 299 363 minecraft:moss_block
fill 272 298 323 276 298 323 minecraft:mushroom_stem
fill 272 298 328 275 298 336 minecraft:mushroom_stem
fill 272 298 344 274 298 358 minecraft:mushroom_stem
fill 272 298 363 273 298 363 minecraft:mushroom_stem
fill 273 298 337 274 298 337 minecraft:red_mushroom_block
fill 273 298 343 274 298 343 minecraft:red_mushroom_block
fill 274 298 338 275 299 338 minecraft:red_mushroom_block
fill 274 298 342 275 298 342 minecraft:red_mushroom_block
setblock 274 298 363 minecraft:red_mushroom_block
fill 275 298 337 276 298 337 minecraft:mushroom_stem
fill 275 298 343 275 298 345 minecraft:mushroom_stem
setblock 275 298 348 minecraft:mushroom_stem
fill 275 298 349 275 300 349 minecraft:moss_block
schedule function dropper:buildpart/77_10 1t
