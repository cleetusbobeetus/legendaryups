setblock 511 117 464 minecraft:terracotta
fill 511 117 465 511 119 466 minecraft:red_terracotta
setblock 511 117 504 minecraft:terracotta
fill 471 118 464 471 120 465 minecraft:red_terracotta
setblock 471 118 502 minecraft:red_terracotta
setblock 471 118 503 minecraft:terracotta
fill 471 118 504 474 118 504 minecraft:red_terracotta
fill 472 118 464 474 118 464 minecraft:red_terracotta
fill 472 118 503 475 118 503 minecraft:red_terracotta
setblock 475 118 464 minecraft:terracotta
setblock 475 118 504 minecraft:terracotta
fill 476 118 464 476 121 464 minecraft:red_terracotta
setblock 476 118 503 minecraft:terracotta
fill 476 118 504 476 121 504 minecraft:red_terracotta
setblock 477 118 502 minecraft:terracotta
fill 477 118 503 477 121 503 minecraft:red_terracotta
fill 478 118 502 478 121 502 minecraft:red_terracotta
setblock 480 118 464 minecraft:terracotta
setblock 480 118 504 minecraft:terracotta
fill 481 118 464 481 121 464 minecraft:red_terracotta
setblock 481 118 503 minecraft:terracotta
fill 481 118 504 481 121 504 minecraft:red_terracotta
setblock 482 118 502 minecraft:terracotta
fill 482 118 503 482 121 503 minecraft:red_terracotta
fill 483 118 502 483 121 502 minecraft:red_terracotta
setblock 485 118 464 minecraft:terracotta
setblock 485 118 504 minecraft:terracotta
fill 486 118 464 486 121 464 minecraft:red_terracotta
setblock 486 118 503 minecraft:terracotta
fill 486 118 504 486 121 504 minecraft:red_terracotta
setblock 487 118 503 minecraft:red_terracotta
fill 497 118 464 497 120 464 minecraft:red_terracotta
fill 497 118 504 499 118 504 minecraft:red_terracotta
setblock 499 118 465 minecraft:terracotta
setblock 500 118 464 minecraft:terracotta
fill 500 118 465 500 121 465 minecraft:red_terracotta
setblock 500 118 504 minecraft:terracotta
fill 501 118 464 501 121 464 minecraft:red_terracotta
setblock 501 118 503 minecraft:terracotta
fill 501 118 504 501 121 504 minecraft:red_terracotta
fill 502 118 503 502 121 503 minecraft:red_terracotta
setblock 504 118 465 minecraft:terracotta
fill 504 118 479 504 118 483 minecraft:brown_terracotta
setblock 505 118 464 minecraft:terracotta
fill 505 118 465 505 121 465 minecraft:red_terracotta
fill 505 118 478 505 118 479 minecraft:brown_terracotta
fill 505 118 484 506 118 484 minecraft:brown_terracotta
setblock 505 118 504 minecraft:terracotta
fill 506 118 464 506 121 464 minecraft:red_terracotta
fill 506 118 478 509 118 478 minecraft:brown_terracotta
setblock 506 118 503 minecraft:terracotta
fill 506 118 504 506 121 504 minecraft:red_terracotta
setblock 509 118 465 minecraft:terracotta
setblock 509 118 484 minecraft:brown_terracotta
setblock 510 118 464 minecraft:terracotta
setblock 510 118 479 minecraft:brown_terracotta
setblock 510 118 483 minecraft:brown_terracotta
setblock 510 118 504 minecraft:terracotta
fill 511 118 464 511 121 464 minecraft:red_terracotta
setblock 511 118 467 minecraft:red_terracotta
fill 511 118 480 511 118 482 minecraft:brown_terracotta
setblock 511 118 503 minecraft:terracotta
fill 511 118 504 511 121 504 minecraft:red_terracotta
setblock 471 119 466 minecraft:red_terracotta
setblock 471 119 502 minecraft:terracotta
fill 471 119 503 473 119 504 minecraft:red_terracotta
fill 472 119 464 473 119 464 minecraft:red_terracotta
fill 472 119 502 472 122 502 minecraft:red_terracotta
setblock 474 119 464 minecraft:terracotta
setblock 474 119 503 minecraft:red_terracotta
setblock 474 119 504 minecraft:terracotta
fill 475 119 464 475 122 464 minecraft:red_terracotta
setblock 475 119 503 minecraft:terracotta
fill 475 119 504 475 122 504 minecraft:red_terracotta
setblock 476 119 502 minecraft:terracotta
fill 476 119 503 476 122 503 minecraft:red_terracotta
fill 477 119 502 477 122 502 minecraft:red_terracotta
setblock 478 119 465 minecraft:terracotta
setblock 479 119 464 minecraft:terracotta
fill 479 119 465 482 119 465 minecraft:red_terracotta
setblock 479 119 504 minecraft:terracotta
fill 480 119 464 480 122 464 minecraft:red_terracotta
setblock 480 119 503 minecraft:terracotta
fill 480 119 504 480 122 504 minecraft:red_terracotta
setblock 481 119 502 minecraft:terracotta
fill 481 119 503 481 122 503 minecraft:red_terracotta
fill 482 119 502 482 122 502 minecraft:red_terracotta
setblock 483 119 465 minecraft:terracotta
setblock 484 119 464 minecraft:terracotta
setblock 484 119 504 minecraft:terracotta
fill 485 119 464 485 122 464 minecraft:red_terracotta
setblock 485 119 503 minecraft:terracotta
fill 485 119 504 485 122 504 minecraft:red_terracotta
fill 486 119 503 486 120 503 minecraft:red_terracotta
setblock 489 119 504 minecraft:terracotta
fill 496 119 464 496 121 464 minecraft:red_terracotta
fill 496 119 504 498 119 504 minecraft:red_terracotta
setblock 498 119 465 minecraft:terracotta
setblock 499 119 464 minecraft:terracotta
fill 499 119 465 499 122 465 minecraft:red_terracotta
setblock 499 119 504 minecraft:terracotta
fill 500 119 464 500 122 464 minecraft:red_terracotta
setblock 500 119 503 minecraft:terracotta
fill 500 119 504 500 122 504 minecraft:red_terracotta
setblock 501 119 466 minecraft:red_terracotta
fill 501 119 503 501 122 503 minecraft:red_terracotta
setblock 502 119 466 minecraft:terracotta
setblock 503 119 465 minecraft:terracotta
fill 503 119 466 505 120 466 minecraft:red_terracotta
setblock 504 119 464 minecraft:terracotta
fill 504 119 465 504 122 465 minecraft:red_terracotta
setblock 504 119 504 minecraft:terracotta
fill 505 119 464 505 122 464 minecraft:red_terracotta
setblock 505 119 503 minecraft:terracotta
fill 505 119 504 505 122 504 minecraft:red_terracotta
fill 506 119 503 506 121 503 minecraft:red_terracotta
setblock 508 119 465 minecraft:terracotta
setblock 509 119 464 minecraft:terracotta
fill 509 119 465 510 121 465 minecraft:red_terracotta
setblock 509 119 504 minecraft:terracotta
fill 510 119 464 510 122 464 minecraft:red_terracotta
fill 510 119 504 510 122 504 minecraft:red_terracotta
setblock 511 119 467 minecraft:terracotta
fill 511 119 468 511 122 468 minecraft:red_terracotta
setblock 511 119 502 minecraft:terracotta
fill 511 119 503 511 122 503 minecraft:red_terracotta
setblock 471 120 466 minecraft:terracotta
setblock 471 120 501 minecraft:terracotta
fill 471 120 502 471 121 504 minecraft:red_terracotta
setblock 472 120 464 minecraft:red_terracotta
fill 472 120 503 472 120 504 minecraft:red_terracotta
setblock 473 120 464 minecraft:terracotta
setblock 473 120 503 minecraft:red_terracotta
setblock 473 120 504 minecraft:terracotta
fill 474 120 464 474 123 464 minecraft:red_terracotta
setblock 474 120 503 minecraft:terracotta
fill 474 120 504 474 123 504 minecraft:red_terracotta
fill 475 120 465 476 120 465 minecraft:red_terracotta
fill 475 120 503 475 123 503 minecraft:red_terracotta
fill 476 120 502 476 123 502 minecraft:red_terracotta
setblock 477 120 465 minecraft:terracotta
setblock 478 120 464 minecraft:terracotta
fill 478 120 465 481 120 465 minecraft:red_terracotta
setblock 478 120 504 minecraft:terracotta
fill 479 120 464 479 123 464 minecraft:red_terracotta
setblock 479 120 503 minecraft:terracotta
fill 479 120 504 479 123 504 minecraft:red_terracotta
setblock 480 120 502 minecraft:terracotta
fill 480 120 503 480 123 503 minecraft:red_terracotta
fill 481 120 502 481 123 502 minecraft:red_terracotta
setblock 482 120 465 minecraft:terracotta
setblock 483 120 464 minecraft:terracotta
fill 483 120 465 483 123 465 minecraft:red_terracotta
setblock 483 120 504 minecraft:terracotta
fill 484 120 464 484 123 464 minecraft:red_terracotta
setblock 484 120 503 minecraft:terracotta
fill 484 120 504 484 123 504 minecraft:red_terracotta
fill 485 120 503 485 122 503 minecraft:red_terracotta
setblock 487 120 464 minecraft:red_terracotta
setblock 488 120 504 minecraft:terracotta
fill 494 120 464 495 122 464 minecraft:red_terracotta
fill 495 120 504 497 120 504 minecraft:red_terracotta
setblock 497 120 465 minecraft:terracotta
setblock 498 120 464 minecraft:terracotta
fill 498 120 465 498 123 465 minecraft:red_terracotta
setblock 498 120 504 minecraft:terracotta
fill 499 120 464 499 123 464 minecraft:red_terracotta
fill 499 120 466 500 120 466 minecraft:red_terracotta
setblock 499 120 503 minecraft:terracotta
fill 499 120 504 499 123 504 minecraft:red_terracotta
fill 500 120 503 500 123 503 minecraft:red_terracotta
setblock 501 120 466 minecraft:terracotta
setblock 502 120 465 minecraft:terracotta
fill 502 120 466 502 123 466 minecraft:red_terracotta
setblock 503 120 464 minecraft:terracotta
fill 503 120 465 503 123 465 minecraft:red_terracotta
setblock 503 120 504 minecraft:terracotta
fill 504 120 464 504 123 464 minecraft:red_terracotta
setblock 504 120 503 minecraft:terracotta
fill 504 120 504 504 123 504 minecraft:red_terracotta
fill 505 120 503 505 122 503 minecraft:red_terracotta
setblock 506 120 466 minecraft:terracotta
setblock 507 120 465 minecraft:terracotta
setblock 508 120 464 minecraft:terracotta
fill 508 120 465 508 123 465 minecraft:red_terracotta
setblock 508 120 504 minecraft:terracotta
fill 509 120 464 509 123 464 minecraft:red_terracotta
fill 509 120 504 509 123 504 minecraft:red_terracotta
setblock 510 120 466 minecraft:red_terracotta
setblock 511 120 465 minecraft:red_terracotta
setblock 511 120 466 minecraft:terracotta
fill 511 120 467 511 123 467 minecraft:red_terracotta
fill 511 120 469 511 121 469 minecraft:red_terracotta
fill 511 120 502 511 123 502 minecraft:red_terracotta
setblock 471 121 464 minecraft:red_terracotta
setblock 471 121 465 minecraft:terracotta
fill 471 121 466 471 123 467 minecraft:red_terracotta
fill 471 121 486 471 124 486 minecraft:red_terracotta
setblock 471 121 499 minecraft:red_terracotta
setblock 471 121 500 minecraft:terracotta
fill 471 121 501 471 124 501 minecraft:red_terracotta
setblock 472 121 464 minecraft:terracotta
fill 472 121 465 475 121 465 minecraft:red_terracotta
setblock 472 121 503 minecraft:red_terracotta
setblock 472 121 504 minecraft:terracotta
fill 473 121 464 473 124 464 minecraft:red_terracotta
setblock 473 121 503 minecraft:terracotta
fill 473 121 504 473 124 504 minecraft:red_terracotta
fill 474 121 503 474 124 503 minecraft:red_terracotta
fill 475 121 502 475 124 502 minecraft:red_terracotta
setblock 476 121 465 minecraft:terracotta
setblock 477 121 464 minecraft:terracotta
fill 477 121 465 480 121 465 minecraft:red_terracotta
setblock 477 121 504 minecraft:terracotta
fill 478 121 464 478 124 464 minecraft:red_terracotta
setblock 478 121 503 minecraft:terracotta
fill 478 121 504 478 124 504 minecraft:red_terracotta
setblock 479 121 502 minecraft:terracotta
fill 479 121 503 479 124 503 minecraft:red_terracotta
fill 480 121 502 480 124 502 minecraft:red_terracotta
setblock 481 121 465 minecraft:terracotta
setblock 482 121 464 minecraft:terracotta
fill 482 121 465 482 124 465 minecraft:red_terracotta
setblock 482 121 504 minecraft:terracotta
fill 483 121 464 483 124 464 minecraft:red_terracotta
setblock 483 121 503 minecraft:terracotta
fill 483 121 504 483 124 504 minecraft:red_terracotta
fill 484 121 465 484 122 465 minecraft:red_terracotta
fill 484 121 503 484 123 503 minecraft:red_terracotta
setblock 487 121 464 minecraft:terracotta
setblock 487 121 504 minecraft:terracotta
fill 488 121 464 488 124 464 minecraft:red_terracotta
fill 488 121 504 488 122 504 minecraft:red_terracotta
setblock 492 121 464 minecraft:terracotta
fill 493 121 464 493 124 464 minecraft:red_terracotta
fill 494 121 504 496 121 504 minecraft:red_terracotta
setblock 495 121 465 minecraft:red_terracotta
setblock 496 121 465 minecraft:terracotta
setblock 497 121 464 minecraft:terracotta
fill 497 121 465 497 123 466 minecraft:red_terracotta
setblock 497 121 504 minecraft:terracotta
fill 498 121 464 498 124 464 minecraft:red_terracotta
fill 498 121 466 499 121 466 minecraft:red_terracotta
setblock 498 121 503 minecraft:terracotta
fill 498 121 504 498 124 504 minecraft:red_terracotta
fill 499 121 503 499 124 503 minecraft:red_terracotta
setblock 500 121 466 minecraft:terracotta
setblock 501 121 465 minecraft:terracotta
fill 501 121 466 501 123 467 minecraft:red_terracotta
setblock 502 121 464 minecraft:terracotta
fill 502 121 465 502 124 465 minecraft:red_terracotta
fill 502 121 467 502 122 467 minecraft:red_terracotta
setblock 502 121 504 minecraft:terracotta
fill 503 121 464 503 124 464 minecraft:red_terracotta
fill 503 121 466 504 121 466 minecraft:red_terracotta
setblock 503 121 503 minecraft:terracotta
fill 503 121 504 503 124 504 minecraft:red_terracotta
fill 504 121 503 504 123 503 minecraft:red_terracotta
setblock 505 121 466 minecraft:terracotta
setblock 506 121 465 minecraft:terracotta
fill 506 121 466 507 123 466 minecraft:red_terracotta
setblock 507 121 464 minecraft:terracotta
fill 507 121 465 507 124 465 minecraft:red_terracotta
setblock 507 121 504 minecraft:terracotta
fill 508 121 464 508 124 464 minecraft:red_terracotta
fill 508 121 504 508 124 504 minecraft:red_terracotta
setblock 510 121 466 minecraft:terracotta
fill 510 121 467 510 124 467 minecraft:red_terracotta
setblock 511 121 465 minecraft:terracotta
fill 511 121 466 511 124 466 minecraft:red_terracotta
setblock 511 121 470 minecraft:terracotta
setblock 471 122 464 minecraft:terracotta
fill 471 122 465 474 122 465 minecraft:red_terracotta
setblock 471 122 468 minecraft:red_terracotta
setblock 471 122 484 minecraft:terracotta
fill 471 122 485 471 125 485 minecraft:red_terracotta
fill 471 122 487 471 122 488 minecraft:red_terracotta
setblock 471 122 489 minecraft:terracotta
fill 471 122 490 471 125 490 minecraft:red_terracotta
setblock 471 122 499 minecraft:terracotta
fill 471 122 500 471 125 500 minecraft:red_terracotta
fill 471 122 502 471 122 503 minecraft:red_terracotta
setblock 471 122 504 minecraft:terracotta
fill 472 122 464 472 125 464 minecraft:red_terracotta
fill 472 122 466 472 123 466 minecraft:red_terracotta
fill 472 122 501 472 123 501 minecraft:red_terracotta
setblock 472 122 503 minecraft:terracotta
fill 472 122 504 472 125 504 minecraft:red_terracotta
fill 473 122 503 473 125 503 minecraft:red_terracotta
setblock 475 122 465 minecraft:terracotta
setblock 476 122 464 minecraft:terracotta
fill 476 122 465 479 122 465 minecraft:red_terracotta
setblock 476 122 504 minecraft:terracotta
fill 477 122 464 477 125 464 minecraft:red_terracotta
setblock 477 122 503 minecraft:terracotta
fill 477 122 504 477 125 504 minecraft:red_terracotta
setblock 478 122 466 minecraft:red_terracotta
setblock 478 122 502 minecraft:terracotta
fill 478 122 503 478 125 503 minecraft:red_terracotta
setblock 479 122 466 minecraft:terracotta
fill 479 122 502 479 125 502 minecraft:red_terracotta
setblock 480 122 465 minecraft:terracotta
fill 480 122 466 480 125 466 minecraft:red_terracotta
setblock 481 122 464 minecraft:terracotta
fill 481 122 465 481 125 465 minecraft:red_terracotta
setblock 481 122 504 minecraft:terracotta
fill 482 122 464 482 125 464 minecraft:red_terracotta
setblock 482 122 503 minecraft:terracotta
fill 482 122 504 482 125 504 minecraft:red_terracotta
fill 483 122 503 483 124 503 minecraft:red_terracotta
setblock 486 122 464 minecraft:terracotta
setblock 486 122 504 minecraft:terracotta
fill 487 122 464 487 124 464 minecraft:red_terracotta
fill 487 122 504 487 123 504 minecraft:red_terracotta
fill 489 122 464 490 122 464 minecraft:red_terracotta
setblock 491 122 464 minecraft:terracotta
fill 492 122 464 492 125 464 minecraft:red_terracotta
setblock 494 122 465 minecraft:red_terracotta
fill 494 122 504 495 122 504 minecraft:red_terracotta
setblock 495 122 465 minecraft:terracotta
setblock 496 122 464 minecraft:terracotta
fill 496 122 465 496 124 466 minecraft:red_terracotta
setblock 496 122 504 minecraft:terracotta
fill 497 122 464 497 125 464 minecraft:red_terracotta
fill 497 122 504 497 125 504 minecraft:red_terracotta
setblock 498 122 466 minecraft:red_terracotta
fill 498 122 503 498 124 503 minecraft:red_terracotta
setblock 499 122 466 minecraft:terracotta
fill 499 122 467 500 124 467 minecraft:red_terracotta
setblock 500 122 465 minecraft:terracotta
fill 500 122 466 500 125 466 minecraft:red_terracotta
setblock 501 122 464 minecraft:terracotta
fill 501 122 465 501 125 465 minecraft:red_terracotta
setblock 501 122 504 minecraft:terracotta
fill 502 122 464 502 125 464 minecraft:red_terracotta
setblock 502 122 503 minecraft:terracotta
fill 502 122 504 502 125 504 minecraft:red_terracotta
setblock 503 122 466 minecraft:red_terracotta
setblock 503 122 467 minecraft:terracotta
fill 503 122 503 503 124 503 minecraft:red_terracotta
setblock 504 122 466 minecraft:terracotta
fill 504 122 467 504 125 467 minecraft:red_terracotta
setblock 505 122 465 minecraft:terracotta
fill 505 122 466 505 125 466 minecraft:red_terracotta
setblock 506 122 464 minecraft:terracotta
fill 506 122 465 506 125 465 minecraft:red_terracotta
setblock 506 122 504 minecraft:terracotta
fill 507 122 464 507 125 464 minecraft:red_terracotta
fill 507 122 504 507 125 504 minecraft:red_terracotta
setblock 508 122 466 minecraft:red_terracotta
setblock 509 122 465 minecraft:red_terracotta
setblock 510 122 465 minecraft:terracotta
fill 510 122 466 510 125 466 minecraft:red_terracotta
fill 510 122 468 510 123 468 minecraft:red_terracotta
setblock 511 122 464 minecraft:terracotta
fill 511 122 465 511 125 465 minecraft:red_terracotta
setblock 511 122 469 minecraft:terracotta
fill 511 122 470 511 125 470 minecraft:red_terracotta
setblock 511 122 504 minecraft:terracotta
fill 471 123 464 471 125 465 minecraft:red_terracotta
setblock 471 123 468 minecraft:terracotta
fill 471 123 469 471 126 469 minecraft:red_terracotta
fill 471 123 484 471 126 484 minecraft:red_terracotta
setblock 471 123 487 minecraft:red_terracotta
setblock 471 123 488 minecraft:terracotta
fill 471 123 489 472 125 489 minecraft:red_terracotta
fill 471 123 491 471 123 492 minecraft:red_terracotta
setblock 471 123 493 minecraft:terracotta
setblock 471 123 498 minecraft:terracotta
fill 471 123 499 471 126 499 minecraft:red_terracotta
setblock 471 123 502 minecraft:red_terracotta
setblock 471 123 503 minecraft:terracotta
fill 471 123 504 471 126 504 minecraft:red_terracotta
fill 472 123 465 473 123 465 minecraft:red_terracotta
setblock 472 123 467 minecraft:terracotta
setblock 472 123 486 minecraft:red_terracotta
setblock 472 123 487 minecraft:terracotta
fill 472 123 488 472 126 488 minecraft:red_terracotta
setblock 472 123 502 minecraft:terracotta
fill 472 123 503 472 126 503 minecraft:red_terracotta
setblock 474 123 465 minecraft:terracotta
setblock 475 123 464 minecraft:terracotta
fill 475 123 465 478 123 465 minecraft:red_terracotta
setblock 475 123 504 minecraft:terracotta
fill 476 123 464 476 126 464 minecraft:red_terracotta
fill 476 123 466 477 123 466 minecraft:red_terracotta
setblock 476 123 503 minecraft:terracotta
fill 476 123 504 476 126 504 minecraft:red_terracotta
setblock 477 123 502 minecraft:terracotta
fill 477 123 503 477 126 503 minecraft:red_terracotta
setblock 478 123 466 minecraft:terracotta
fill 478 123 502 478 125 502 minecraft:red_terracotta
setblock 479 123 465 minecraft:terracotta
fill 479 123 466 479 125 466 minecraft:red_terracotta
setblock 480 123 464 minecraft:terracotta
fill 480 123 465 480 126 465 minecraft:red_terracotta
setblock 480 123 504 minecraft:terracotta
fill 481 123 464 481 126 464 minecraft:red_terracotta
setblock 481 123 466 minecraft:red_terracotta
setblock 481 123 503 minecraft:terracotta
fill 481 123 504 481 126 504 minecraft:red_terracotta
fill 482 123 503 482 125 503 minecraft:red_terracotta
setblock 484 123 465 minecraft:terracotta
setblock 485 123 464 minecraft:terracotta
setblock 485 123 504 minecraft:terracotta
fill 486 123 464 486 125 464 minecraft:red_terracotta
fill 486 123 504 486 124 504 minecraft:red_terracotta
setblock 489 123 464 minecraft:red_terracotta
setblock 490 123 464 minecraft:terracotta
fill 491 123 464 491 126 464 minecraft:red_terracotta
setblock 493 123 465 minecraft:red_terracotta
fill 493 123 504 494 123 504 minecraft:red_terracotta
setblock 494 123 464 minecraft:red_terracotta
setblock 494 123 465 minecraft:terracotta
setblock 495 123 464 minecraft:terracotta
fill 495 123 465 495 125 466 minecraft:red_terracotta
setblock 495 123 504 minecraft:terracotta
fill 496 123 464 496 126 464 minecraft:red_terracotta
fill 496 123 504 496 126 504 minecraft:red_terracotta
setblock 497 123 467 minecraft:terracotta
setblock 497 123 503 minecraft:red_terracotta
setblock 498 123 466 minecraft:terracotta
fill 498 123 467 498 126 467 minecraft:red_terracotta
setblock 499 123 465 minecraft:terracotta
fill 499 123 466 499 126 466 minecraft:red_terracotta
setblock 500 123 464 minecraft:terracotta
fill 500 123 465 500 126 465 minecraft:red_terracotta
setblock 500 123 504 minecraft:terracotta
fill 501 123 464 501 126 464 minecraft:red_terracotta
setblock 501 123 503 minecraft:terracotta
fill 501 123 504 501 126 504 minecraft:red_terracotta
setblock 502 123 467 minecraft:terracotta
fill 502 123 503 502 124 503 minecraft:red_terracotta
setblock 503 123 466 minecraft:terracotta
fill 503 123 467 503 126 467 minecraft:red_terracotta
setblock 504 123 465 minecraft:terracotta
fill 504 123 466 504 126 466 minecraft:red_terracotta
setblock 505 123 464 minecraft:terracotta
fill 505 123 465 505 126 465 minecraft:red_terracotta
setblock 505 123 504 minecraft:terracotta
fill 506 123 464 506 126 464 minecraft:red_terracotta
fill 506 123 504 506 126 504 minecraft:red_terracotta
setblock 508 123 466 minecraft:terracotta
setblock 509 123 465 minecraft:terracotta
fill 509 123 466 509 125 466 minecraft:red_terracotta
setblock 510 123 464 minecraft:terracotta
fill 510 123 465 510 126 465 minecraft:red_terracotta
setblock 510 123 469 minecraft:terracotta
setblock 510 123 504 minecraft:terracotta
fill 511 123 464 511 126 464 minecraft:red_terracotta
setblock 511 123 468 minecraft:terracotta
fill 511 123 469 511 126 469 minecraft:red_terracotta
fill 511 123 471 511 124 471 minecraft:red_terracotta
fill 511 123 485 511 123 487 minecraft:red_terracotta
setblock 511 123 503 minecraft:terracotta
fill 511 123 504 511 126 504 minecraft:red_terracotta
setblock 471 124 466 minecraft:red_terracotta
setblock 471 124 467 minecraft:terracotta
fill 471 124 468 471 127 468 minecraft:red_terracotta
setblock 471 124 487 minecraft:terracotta
fill 471 124 488 471 127 488 minecraft:red_terracotta
setblock 471 124 491 minecraft:red_terracotta
setblock 471 124 492 minecraft:terracotta
fill 471 124 493 471 124 496 minecraft:red_terracotta
setblock 471 124 497 minecraft:terracotta
fill 471 124 498 471 127 498 minecraft:red_terracotta
setblock 471 124 502 minecraft:terracotta
fill 471 124 503 471 127 503 minecraft:red_terracotta
setblock 472 124 465 minecraft:red_terracotta
setblock 472 124 466 minecraft:terracotta
fill 472 124 467 472 127 467 minecraft:red_terracotta
setblock 472 124 485 minecraft:red_terracotta
setblock 472 124 486 minecraft:terracotta
fill 472 124 487 472 127 487 minecraft:red_terracotta
setblock 472 124 490 minecraft:red_terracotta
setblock 472 124 491 minecraft:terracotta
fill 472 124 492 472 127 492 minecraft:red_terracotta
setblock 472 124 501 minecraft:terracotta
fill 472 124 502 472 126 502 minecraft:red_terracotta
setblock 473 124 465 minecraft:terracotta
fill 473 124 488 473 125 488 minecraft:red_terracotta
setblock 474 124 464 minecraft:terracotta
fill 474 124 465 477 124 465 minecraft:red_terracotta
setblock 474 124 504 minecraft:terracotta
fill 475 124 464 475 127 464 minecraft:red_terracotta
fill 475 124 466 476 124 466 minecraft:red_terracotta
setblock 475 124 503 minecraft:terracotta
fill 475 124 504 475 127 504 minecraft:red_terracotta
setblock 476 124 502 minecraft:terracotta
fill 476 124 503 476 127 503 minecraft:red_terracotta
setblock 477 124 466 minecraft:terracotta
fill 477 124 502 477 125 502 minecraft:red_terracotta
setblock 478 124 465 minecraft:terracotta
fill 478 124 466 478 126 466 minecraft:red_terracotta
setblock 479 124 464 minecraft:terracotta
fill 479 124 465 479 127 465 minecraft:red_terracotta
setblock 479 124 504 minecraft:terracotta
fill 480 124 464 480 127 464 minecraft:red_terracotta
setblock 480 124 503 minecraft:terracotta
fill 480 124 504 480 127 504 minecraft:red_terracotta
fill 481 124 503 481 125 503 minecraft:red_terracotta
setblock 483 124 465 minecraft:terracotta
setblock 484 124 464 minecraft:terracotta
setblock 484 124 465 minecraft:red_terracotta
setblock 484 124 504 minecraft:terracotta
fill 485 124 464 485 125 464 minecraft:red_terracotta
setblock 485 124 504 minecraft:red_terracotta
setblock 489 124 464 minecraft:terracotta
fill 490 124 464 490 126 464 minecraft:red_terracotta
setblock 492 124 465 minecraft:red_terracotta
fill 492 124 466 493 125 467 minecraft:terracotta
setblock 493 124 465 minecraft:terracotta
fill 493 124 468 493 125 474 minecraft:terracotta
setblock 493 124 504 minecraft:red_terracotta
setblock 494 124 464 minecraft:terracotta
fill 494 124 465 494 126 466 minecraft:red_terracotta
fill 494 124 469 494 125 476 minecraft:terracotta
setblock 494 124 504 minecraft:terracotta
fill 495 124 464 495 127 464 minecraft:red_terracotta
fill 495 124 504 495 127 504 minecraft:red_terracotta
setblock 496 124 467 minecraft:terracotta
setblock 497 124 465 minecraft:red_terracotta
setblock 497 124 466 minecraft:terracotta
fill 497 124 467 497 127 467 minecraft:red_terracotta
setblock 498 124 465 minecraft:terracotta
fill 498 124 466 498 127 466 minecraft:red_terracotta
setblock 499 124 464 minecraft:terracotta
fill 499 124 465 499 127 465 minecraft:red_terracotta
setblock 499 124 504 minecraft:terracotta
fill 500 124 464 500 127 464 minecraft:red_terracotta
setblock 500 124 503 minecraft:terracotta
fill 500 124 504 500 127 504 minecraft:red_terracotta
setblock 501 124 466 minecraft:red_terracotta
setblock 501 124 467 minecraft:terracotta
setblock 501 124 503 minecraft:red_terracotta
setblock 502 124 466 minecraft:terracotta
fill 502 124 467 502 126 467 minecraft:red_terracotta
setblock 503 124 465 minecraft:terracotta
fill 503 124 466 503 127 466 minecraft:red_terracotta
setblock 504 124 464 minecraft:terracotta
fill 504 124 465 504 127 465 minecraft:red_terracotta
setblock 504 124 504 minecraft:terracotta
fill 505 124 464 505 127 464 minecraft:red_terracotta
fill 505 124 504 505 126 504 minecraft:red_terracotta
setblock 506 124 466 minecraft:red_terracotta
setblock 507 124 466 minecraft:terracotta
setblock 508 124 465 minecraft:terracotta
fill 508 124 466 508 125 466 minecraft:red_terracotta
setblock 509 124 464 minecraft:terracotta
fill 509 124 465 509 127 465 minecraft:red_terracotta
setblock 509 124 467 minecraft:red_terracotta
setblock 509 124 504 minecraft:terracotta
fill 510 124 464 510 127 464 minecraft:red_terracotta
setblock 510 124 468 minecraft:terracotta
fill 510 124 469 510 127 469 minecraft:red_terracotta
fill 510 124 504 510 127 504 minecraft:red_terracotta
setblock 511 124 467 minecraft:terracotta
fill 511 124 468 511 127 468 minecraft:red_terracotta
setblock 511 124 472 minecraft:terracotta
fill 511 124 485 511 124 486 minecraft:red_terracotta
setblock 511 124 487 minecraft:terracotta
fill 511 124 488 511 126 489 minecraft:red_terracotta
setblock 511 124 502 minecraft:terracotta
fill 511 124 503 511 127 503 minecraft:red_terracotta
setblock 471 125 466 minecraft:terracotta
fill 471 125 467 471 128 467 minecraft:red_terracotta
setblock 471 125 470 minecraft:red_terracotta
setblock 471 125 486 minecraft:terracotta
fill 471 125 487 471 128 487 minecraft:red_terracotta
setblock 471 125 491 minecraft:terracotta
fill 471 125 492 471 125 495 minecraft:red_terracotta
setblock 471 125 496 minecraft:terracotta
fill 471 125 497 471 128 497 minecraft:red_terracotta
setblock 471 125 501 minecraft:terracotta
fill 471 125 502 471 128 502 minecraft:red_terracotta
setblock 472 125 465 minecraft:terracotta
fill 472 125 466 472 127 466 minecraft:red_terracotta
fill 472 125 468 472 126 468 minecraft:red_terracotta
setblock 472 125 485 minecraft:terracotta
fill 472 125 486 472 128 486 minecraft:red_terracotta
setblock 472 125 490 minecraft:terracotta
fill 472 125 491 473 127 491 minecraft:red_terracotta
fill 472 125 493 472 125 494 minecraft:red_terracotta
setblock 473 125 464 minecraft:terracotta
fill 473 125 465 476 125 465 minecraft:red_terracotta
setblock 473 125 466 minecraft:light[level=14]
setblock 473 125 474 minecraft:light[level=14]
setblock 473 125 482 minecraft:light[level=14]
fill 473 125 487 473 126 487 minecraft:red_terracotta
setblock 473 125 489 minecraft:terracotta
fill 473 125 490 473 128 490 minecraft:red_terracotta
fill 473 125 492 473 126 492 minecraft:red_terracotta
setblock 473 125 498 minecraft:light[level=14]
setblock 473 125 504 minecraft:terracotta
fill 474 125 464 474 128 464 minecraft:red_terracotta
setblock 474 125 503 minecraft:terracotta
fill 474 125 504 474 128 504 minecraft:red_terracotta
setblock 475 125 466 minecraft:red_terracotta
setblock 475 125 502 minecraft:terracotta
fill 475 125 503 475 128 503 minecraft:red_terracotta
setblock 476 125 466 minecraft:terracotta
setblock 476 125 502 minecraft:red_terracotta
setblock 477 125 465 minecraft:terracotta
fill 477 125 466 477 126 466 minecraft:red_terracotta
setblock 478 125 464 minecraft:terracotta
fill 478 125 465 478 128 465 minecraft:red_terracotta
setblock 478 125 504 minecraft:terracotta
fill 479 125 464 479 128 464 minecraft:red_terracotta
setblock 479 125 503 minecraft:terracotta
fill 479 125 504 479 128 504 minecraft:red_terracotta
fill 480 125 503 480 126 503 minecraft:red_terracotta
setblock 481 125 466 minecraft:light[level=14]
setblock 481 125 474 minecraft:light[level=14]
setblock 481 125 482 minecraft:light[level=14]
setblock 481 125 490 minecraft:light[level=14]
setblock 481 125 498 minecraft:light[level=14]
setblock 482 125 465 minecraft:terracotta
setblock 483 125 464 minecraft:terracotta
setblock 483 125 465 minecraft:red_terracotta
setblock 483 125 504 minecraft:terracotta
fill 484 125 464 484 126 464 minecraft:red_terracotta
fill 484 125 494 485 126 495 minecraft:magma_block
setblock 484 125 504 minecraft:red_terracotta
setblock 489 125 464 minecraft:red_terracotta
setblock 489 125 466 minecraft:light[level=14]
setblock 489 125 474 minecraft:light[level=14]
setblock 489 125 482 minecraft:light[level=14]
setblock 489 125 490 minecraft:light[level=14]
setblock 489 125 498 minecraft:light[level=14]
setblock 492 125 465 minecraft:terracotta
fill 492 125 468 492 125 469 minecraft:terracotta
setblock 493 125 464 minecraft:terracotta
fill 493 125 465 493 128 465 minecraft:red_terracotta
fill 493 125 475 493 125 481 minecraft:terracotta
fill 494 125 464 494 128 464 minecraft:red_terracotta
fill 494 125 467 494 125 468 minecraft:terracotta
fill 494 125 477 494 126 490 minecraft:terracotta
fill 494 125 504 494 126 504 minecraft:red_terracotta
fill 495 125 478 495 125 496 minecraft:terracotta
setblock 496 125 465 minecraft:red_terracotta
setblock 496 125 466 minecraft:terracotta
fill 496 125 467 496 128 467 minecraft:red_terracotta
setblock 497 125 465 minecraft:terracotta
fill 497 125 466 497 128 466 minecraft:red_terracotta
setblock 497 125 474 minecraft:light[level=14]
setblock 497 125 482 minecraft:light[level=14]
setblock 497 125 490 minecraft:light[level=14]
setblock 497 125 498 minecraft:light[level=14]
setblock 498 125 464 minecraft:terracotta
fill 498 125 465 498 128 465 minecraft:red_terracotta
setblock 498 125 504 minecraft:terracotta
fill 499 125 464 499 128 464 minecraft:red_terracotta
setblock 499 125 467 minecraft:red_terracotta
setblock 499 125 503 minecraft:terracotta
fill 499 125 504 499 128 504 minecraft:red_terracotta
setblock 500 125 467 minecraft:terracotta
setblock 500 125 503 minecraft:red_terracotta
setblock 501 125 466 minecraft:terracotta
fill 501 125 467 501 127 467 minecraft:red_terracotta
setblock 502 125 465 minecraft:terracotta
fill 502 125 466 502 128 466 minecraft:red_terracotta
setblock 503 125 464 minecraft:terracotta
fill 503 125 465 503 128 465 minecraft:red_terracotta
setblock 503 125 504 minecraft:terracotta
fill 504 125 464 504 128 464 minecraft:red_terracotta
fill 504 125 504 504 126 504 minecraft:red_terracotta
setblock 505 125 474 minecraft:light[level=14]
setblock 505 125 482 minecraft:light[level=14]
setblock 505 125 490 minecraft:light[level=14]
setblock 505 125 498 minecraft:light[level=14]
setblock 506 125 466 minecraft:terracotta
setblock 507 125 465 minecraft:terracotta
fill 507 125 466 507 126 466 minecraft:red_terracotta
setblock 508 125 464 minecraft:terracotta
fill 508 125 465 508 128 465 minecraft:red_terracotta
setblock 508 125 504 minecraft:terracotta
fill 509 125 464 509 128 464 minecraft:red_terracotta
fill 509 125 504 509 127 504 minecraft:red_terracotta
setblock 510 125 467 minecraft:terracotta
fill 510 125 468 510 128 468 minecraft:red_terracotta
fill 510 125 470 510 126 470 minecraft:red_terracotta
setblock 511 125 466 minecraft:terracotta
fill 511 125 467 511 128 467 minecraft:red_terracotta
setblock 511 125 471 minecraft:terracotta
fill 511 125 472 511 128 472 minecraft:red_terracotta
setblock 511 125 486 minecraft:terracotta
fill 511 125 487 511 127 487 minecraft:red_terracotta
setblock 511 125 490 minecraft:red_terracotta
setblock 511 125 491 minecraft:terracotta
fill 511 125 502 511 127 502 minecraft:red_terracotta
setblock 471 126 464 minecraft:red_terracotta
setblock 471 126 465 minecraft:terracotta
fill 471 126 466 471 129 466 minecraft:red_terracotta
setblock 471 126 470 minecraft:terracotta
setblock 471 126 485 minecraft:terracotta
fill 471 126 486 471 129 486 minecraft:red_terracotta
setblock 471 126 489 minecraft:red_terracotta
setblock 471 126 490 minecraft:terracotta
fill 471 126 491 471 126 494 minecraft:red_terracotta
setblock 471 126 495 minecraft:terracotta
fill 471 126 496 472 128 496 minecraft:red_terracotta
setblock 471 126 500 minecraft:terracotta
fill 471 126 501 471 129 501 minecraft:red_terracotta
setblock 472 126 464 minecraft:terracotta
fill 472 126 465 475 126 465 minecraft:red_terracotta
setblock 472 126 485 minecraft:red_terracotta
setblock 472 126 489 minecraft:terracotta
fill 472 126 490 472 129 490 minecraft:red_terracotta
setblock 472 126 493 minecraft:red_terracotta
setblock 472 126 494 minecraft:terracotta
fill 472 126 495 472 129 495 minecraft:red_terracotta
setblock 472 126 504 minecraft:terracotta
fill 473 126 464 473 129 464 minecraft:red_terracotta
setblock 473 126 488 minecraft:terracotta
fill 473 126 489 473 129 489 minecraft:red_terracotta
setblock 473 126 493 minecraft:terracotta
setblock 473 126 503 minecraft:terracotta
fill 473 126 504 473 129 504 minecraft:red_terracotta
fill 474 126 503 474 128 503 minecraft:red_terracotta
setblock 476 126 465 minecraft:terracotta
setblock 476 126 466 minecraft:red_terracotta
setblock 477 126 464 minecraft:terracotta
fill 477 126 465 477 128 465 minecraft:red_terracotta
setblock 477 126 504 minecraft:terracotta
fill 478 126 464 478 129 464 minecraft:red_terracotta
setblock 478 126 503 minecraft:terracotta
fill 478 126 504 478 129 504 minecraft:red_terracotta
fill 479 126 503 479 127 503 minecraft:red_terracotta
setblock 481 126 465 minecraft:terracotta
setblock 482 126 464 minecraft:terracotta
setblock 482 126 504 minecraft:terracotta
setblock 483 126 464 minecraft:red_terracotta
setblock 483 126 504 minecraft:red_terracotta
setblock 492 126 464 minecraft:terracotta
fill 492 126 465 492 128 465 minecraft:red_terracotta
fill 493 126 464 493 129 464 minecraft:red_terracotta
fill 493 126 466 493 126 469 minecraft:orange_concrete
fill 493 126 470 493 126 480 minecraft:terracotta
fill 494 126 473 494 126 476 minecraft:terracotta
fill 494 126 491 495 126 495 minecraft:terracotta
setblock 495 126 465 minecraft:red_terracotta
setblock 495 126 466 minecraft:terracotta
fill 495 126 467 495 127 467 minecraft:red_terracotta
fill 495 126 481 495 126 490 minecraft:terracotta
fill 495 126 496 496 127 503 minecraft:terracotta
setblock 496 126 465 minecraft:terracotta
fill 496 126 466 496 129 466 minecraft:red_terracotta
setblock 496 126 491 minecraft:terracotta
fill 496 126 494 496 126 495 minecraft:terracotta
setblock 497 126 464 minecraft:terracotta
fill 497 126 465 497 129 465 minecraft:red_terracotta
setblock 497 126 504 minecraft:terracotta
fill 498 126 464 498 129 464 minecraft:red_terracotta
fill 498 126 504 498 128 504 minecraft:red_terracotta
setblock 499 126 467 minecraft:terracotta
setblock 500 126 466 minecraft:terracotta
fill 500 126 467 500 128 467 minecraft:red_terracotta
setblock 501 126 465 minecraft:terracotta
fill 501 126 466 501 129 466 minecraft:red_terracotta
setblock 502 126 464 minecraft:terracotta
fill 502 126 465 502 129 465 minecraft:red_terracotta
setblock 502 126 504 minecraft:terracotta
fill 503 126 464 503 129 464 minecraft:red_terracotta
fill 503 126 504 503 127 504 minecraft:red_terracotta
setblock 505 126 466 minecraft:terracotta
setblock 506 126 465 minecraft:terracotta
setblock 506 126 466 minecraft:red_terracotta
setblock 507 126 464 minecraft:terracotta
fill 507 126 465 507 128 465 minecraft:red_terracotta
setblock 507 126 504 minecraft:terracotta
fill 508 126 464 508 129 464 minecraft:red_terracotta
setblock 508 126 504 minecraft:red_terracotta
setblock 510 126 466 minecraft:terracotta
fill 510 126 467 510 129 467 minecraft:red_terracotta
setblock 511 126 465 minecraft:terracotta
fill 511 126 466 511 129 466 minecraft:red_terracotta
setblock 511 126 470 minecraft:terracotta
fill 511 126 471 511 129 471 minecraft:red_terracotta
setblock 511 126 486 minecraft:red_terracotta
setblock 511 126 490 minecraft:terracotta
fill 511 126 491 511 128 492 minecraft:red_terracotta
setblock 471 127 464 minecraft:terracotta
fill 471 127 465 474 127 465 minecraft:red_terracotta
setblock 471 127 469 minecraft:terracotta
fill 471 127 470 471 130 470 minecraft:red_terracotta
fill 471 127 485 471 129 485 minecraft:red_terracotta
setblock 471 127 489 minecraft:terracotta
fill 471 127 490 471 127 493 minecraft:red_terracotta
setblock 471 127 494 minecraft:terracotta
fill 471 127 495 471 130 495 minecraft:red_terracotta
setblock 471 127 499 minecraft:terracotta
fill 471 127 500 471 130 500 minecraft:red_terracotta
setblock 471 127 504 minecraft:terracotta
fill 472 127 464 472 130 464 minecraft:red_terracotta
setblock 472 127 468 minecraft:terracotta
setblock 472 127 488 minecraft:terracotta
fill 472 127 489 472 130 489 minecraft:red_terracotta
setblock 472 127 493 minecraft:terracotta
fill 472 127 494 473 129 494 minecraft:red_terracotta
setblock 472 127 497 minecraft:red_terracotta
fill 472 127 504 472 130 504 minecraft:red_terracotta
setblock 473 127 487 minecraft:terracotta
fill 473 127 488 473 130 488 minecraft:red_terracotta
setblock 473 127 492 minecraft:terracotta
fill 473 127 493 473 130 493 minecraft:red_terracotta
setblock 473 127 503 minecraft:red_terracotta
setblock 474 127 490 minecraft:red_terracotta
setblock 474 127 491 minecraft:terracotta
setblock 475 127 465 minecraft:terracotta
setblock 476 127 464 minecraft:terracotta
fill 476 127 465 476 128 465 minecraft:red_terracotta
setblock 476 127 504 minecraft:terracotta
fill 477 127 464 477 130 464 minecraft:red_terracotta
setblock 477 127 503 minecraft:terracotta
fill 477 127 504 477 130 504 minecraft:red_terracotta
setblock 478 127 503 minecraft:red_terracotta
setblock 480 127 465 minecraft:terracotta
setblock 481 127 464 minecraft:terracotta
setblock 481 127 504 minecraft:terracotta
setblock 482 127 464 minecraft:red_terracotta
setblock 491 127 464 minecraft:terracotta
fill 492 127 464 492 130 464 minecraft:red_terracotta
setblock 494 127 465 minecraft:red_terracotta
setblock 494 127 466 minecraft:terracotta
fill 494 127 475 494 127 486 minecraft:orange_concrete
setblock 495 127 465 minecraft:terracotta
fill 495 127 466 495 130 466 minecraft:red_terracotta
fill 495 127 487 495 127 489 minecraft:orange_concrete
fill 495 127 490 495 127 495 minecraft:terracotta
setblock 496 127 464 minecraft:terracotta
fill 496 127 465 496 130 465 minecraft:red_terracotta
setblock 496 127 504 minecraft:terracotta
fill 497 127 464 497 130 464 minecraft:red_terracotta
fill 497 127 504 497 128 504 minecraft:red_terracotta
setblock 498 127 467 minecraft:terracotta
setblock 499 127 466 minecraft:terracotta
fill 499 127 467 499 128 467 minecraft:red_terracotta
setblock 500 127 465 minecraft:terracotta
fill 500 127 466 500 129 466 minecraft:red_terracotta
setblock 501 127 464 minecraft:terracotta
fill 501 127 465 501 130 465 minecraft:red_terracotta
setblock 501 127 504 minecraft:terracotta
fill 502 127 464 502 130 464 minecraft:red_terracotta
setblock 502 127 504 minecraft:red_terracotta
setblock 504 127 466 minecraft:terracotta
setblock 505 127 465 minecraft:terracotta
setblock 506 127 464 minecraft:terracotta
fill 506 127 465 506 128 465 minecraft:red_terracotta
fill 507 127 464 507 130 464 minecraft:red_terracotta
setblock 510 127 465 minecraft:terracotta
fill 510 127 466 510 130 466 minecraft:red_terracotta
setblock 510 127 470 minecraft:terracotta
setblock 511 127 464 minecraft:terracotta
fill 511 127 465 511 130 465 minecraft:red_terracotta
setblock 511 127 469 minecraft:terracotta
fill 511 127 470 511 130 470 minecraft:red_terracotta
setblock 511 127 488 minecraft:red_terracotta
setblock 511 127 489 minecraft:terracotta
fill 511 127 490 511 130 490 minecraft:red_terracotta
setblock 511 127 493 minecraft:red_terracotta
setblock 511 127 494 minecraft:terracotta
setblock 511 127 504 minecraft:terracotta
fill 471 128 464 471 129 465 minecraft:red_terracotta
setblock 471 128 468 minecraft:terracotta
fill 471 128 469 471 131 469 minecraft:red_terracotta
fill 471 128 471 471 129 471 minecraft:red_terracotta
setblock 471 128 488 minecraft:terracotta
fill 471 128 489 471 128 492 minecraft:red_terracotta
setblock 471 128 493 minecraft:terracotta
fill 471 128 494 471 131 494 minecraft:red_terracotta
setblock 471 128 498 minecraft:terracotta
fill 471 128 499 471 131 499 minecraft:red_terracotta
setblock 471 128 503 minecraft:terracotta
fill 471 128 504 471 131 504 minecraft:red_terracotta
setblock 472 128 467 minecraft:terracotta
setblock 472 128 487 minecraft:terracotta
fill 472 128 488 472 131 488 minecraft:red_terracotta
setblock 472 128 491 minecraft:red_terracotta
setblock 472 128 492 minecraft:terracotta
fill 472 128 493 472 131 493 minecraft:red_terracotta
setblock 472 128 497 minecraft:terracotta
setblock 473 128 465 minecraft:red_terracotta
setblock 473 128 491 minecraft:terracotta
fill 473 128 492 474 130 492 minecraft:red_terracotta
setblock 473 128 495 minecraft:red_terracotta
setblock 474 128 465 minecraft:terracotta
setblock 474 128 490 minecraft:terracotta
fill 474 128 491 474 131 491 minecraft:red_terracotta
setblock 475 128 464 minecraft:terracotta
setblock 475 128 465 minecraft:red_terracotta
fill 475 128 474 476 129 474 minecraft:magma_block
setblock 475 128 504 minecraft:terracotta
fill 476 128 464 476 130 464 minecraft:red_terracotta
setblock 476 128 503 minecraft:terracotta
fill 476 128 504 476 131 504 minecraft:red_terracotta
setblock 480 128 464 minecraft:terracotta
setblock 480 128 504 minecraft:terracotta
fill 491 128 464 491 129 464 minecraft:red_terracotta
setblock 494 128 465 minecraft:terracotta
fill 494 128 466 494 130 466 minecraft:red_terracotta
setblock 495 128 464 minecraft:terracotta
fill 495 128 465 495 131 465 minecraft:red_terracotta
fill 495 128 491 495 128 500 minecraft:orange_concrete
fill 496 128 464 496 131 464 minecraft:red_terracotta
fill 496 128 499 496 128 503 minecraft:orange_concrete
setblock 496 128 504 minecraft:red_terracotta
setblock 497 128 467 minecraft:terracotta
setblock 498 128 466 minecraft:terracotta
fill 498 128 467 498 129 467 minecraft:red_terracotta
setblock 499 128 465 minecraft:terracotta
fill 499 128 466 499 130 466 minecraft:red_terracotta
setblock 500 128 464 minecraft:terracotta
fill 500 128 465 500 131 465 minecraft:red_terracotta
setblock 500 128 504 minecraft:terracotta
fill 501 128 464 501 131 464 minecraft:red_terracotta
setblock 503 128 466 minecraft:terracotta
setblock 504 128 465 minecraft:terracotta
setblock 505 128 464 minecraft:terracotta
setblock 505 128 465 minecraft:red_terracotta
fill 506 128 464 506 130 464 minecraft:red_terracotta
setblock 509 128 465 minecraft:terracotta
setblock 510 128 464 minecraft:terracotta
fill 510 128 465 510 129 465 minecraft:red_terracotta
setblock 510 128 469 minecraft:terracotta
fill 510 128 470 510 131 470 minecraft:red_terracotta
setblock 510 128 504 minecraft:terracotta
fill 511 128 464 511 131 464 minecraft:red_terracotta
setblock 511 128 468 minecraft:terracotta
fill 511 128 469 511 131 469 minecraft:red_terracotta
setblock 511 128 473 minecraft:terracotta
setblock 511 128 488 minecraft:terracotta
fill 511 128 489 511 131 489 minecraft:red_terracotta
setblock 511 128 493 minecraft:terracotta
fill 511 128 494 511 130 495 minecraft:red_terracotta
setblock 511 128 503 minecraft:terracotta
fill 511 128 504 511 131 504 minecraft:red_terracotta
setblock 471 129 467 minecraft:terracotta
fill 471 129 468 471 132 468 minecraft:red_terracotta
setblock 471 129 487 minecraft:terracotta
fill 471 129 488 471 129 491 minecraft:red_terracotta
setblock 471 129 492 minecraft:terracotta
fill 471 129 493 471 132 493 minecraft:red_terracotta
setblock 471 129 496 minecraft:red_terracotta
setblock 471 129 497 minecraft:terracotta
fill 471 129 498 472 131 498 minecraft:red_terracotta
setblock 471 129 502 minecraft:terracotta
fill 471 129 503 471 132 503 minecraft:red_terracotta
fill 472 129 487 472 132 487 minecraft:red_terracotta
setblock 472 129 491 minecraft:terracotta
fill 472 129 492 472 132 492 minecraft:red_terracotta
setblock 472 129 496 minecraft:terracotta
fill 472 129 497 472 132 497 minecraft:red_terracotta
setblock 473 129 490 minecraft:terracotta
fill 473 129 491 473 132 491 minecraft:red_terracotta
setblock 473 129 495 minecraft:terracotta
setblock 474 129 464 minecraft:terracotta
fill 474 129 490 474 130 490 minecraft:red_terracotta
setblock 474 129 493 minecraft:red_terracotta
setblock 474 129 504 minecraft:terracotta
fill 475 129 464 475 130 464 minecraft:red_terracotta
fill 475 129 504 475 132 504 minecraft:red_terracotta
setblock 479 129 464 minecraft:terracotta
setblock 493 129 465 minecraft:terracotta
setblock 494 129 464 minecraft:terracotta
fill 494 129 465 494 132 465 minecraft:red_terracotta
fill 495 129 464 495 132 464 minecraft:red_terracotta
setblock 496 129 467 minecraft:terracotta
setblock 497 129 466 minecraft:terracotta
setblock 497 129 467 minecraft:red_terracotta
setblock 498 129 465 minecraft:terracotta
fill 498 129 466 498 131 466 minecraft:red_terracotta
setblock 499 129 464 minecraft:terracotta
fill 499 129 465 499 132 465 minecraft:red_terracotta
fill 500 129 464 500 132 464 minecraft:red_terracotta
setblock 503 129 465 minecraft:terracotta
setblock 504 129 464 minecraft:terracotta
fill 505 129 464 505 130 464 minecraft:red_terracotta
setblock 509 129 464 minecraft:terracotta
fill 510 129 464 510 132 464 minecraft:red_terracotta
setblock 510 129 468 minecraft:terracotta
fill 510 129 469 510 132 469 minecraft:red_terracotta
setblock 511 129 467 minecraft:terracotta
fill 511 129 468 511 132 468 minecraft:red_terracotta
setblock 511 129 472 minecraft:terracotta
fill 511 129 473 511 132 473 minecraft:red_terracotta
fill 511 129 488 511 132 488 minecraft:red_terracotta
setblock 511 129 491 minecraft:red_terracotta
setblock 511 129 492 minecraft:terracotta
fill 511 129 493 511 132 493 minecraft:red_terracotta
setblock 511 129 496 minecraft:red_terracotta
setblock 511 129 497 minecraft:terracotta
fill 511 129 503 511 132 503 minecraft:red_terracotta
setblock 471 130 465 minecraft:red_terracotta
setblock 471 130 466 minecraft:terracotta
fill 471 130 467 471 133 467 minecraft:red_terracotta
setblock 471 130 471 minecraft:terracotta
fill 471 130 472 471 133 472 minecraft:red_terracotta
fill 471 130 486 474 130 486 minecraft:terracotta
fill 471 130 487 471 130 490 minecraft:red_terracotta
setblock 471 130 491 minecraft:terracotta
fill 471 130 492 471 133 492 minecraft:red_terracotta
setblock 471 130 496 minecraft:terracotta
fill 471 130 497 471 133 497 minecraft:red_terracotta
setblock 471 130 501 minecraft:terracotta
fill 471 130 502 471 133 502 minecraft:red_terracotta
fill 472 130 485 474 131 485 minecraft:terracotta
setblock 472 130 490 minecraft:terracotta
fill 472 130 491 472 133 491 minecraft:red_terracotta
setblock 472 130 494 minecraft:red_terracotta
setblock 472 130 495 minecraft:terracotta
fill 472 130 496 473 132 496 minecraft:red_terracotta
setblock 472 130 499 minecraft:red_terracotta
setblock 473 130 464 minecraft:terracotta
fill 473 130 479 474 131 484 minecraft:terracotta
fill 473 130 487 473 131 487 minecraft:terracotta
setblock 473 130 489 minecraft:terracotta
fill 473 130 490 473 133 490 minecraft:red_terracotta
setblock 473 130 494 minecraft:terracotta
fill 473 130 495 473 133 495 minecraft:red_terracotta
setblock 473 130 504 minecraft:terracotta
fill 474 130 464 474 131 464 minecraft:red_terracotta
fill 474 130 474 474 131 478 minecraft:terracotta
setblock 474 130 493 minecraft:terracotta
fill 474 130 504 474 133 504 minecraft:red_terracotta
fill 475 130 471 475 131 477 minecraft:terracotta
setblock 493 130 464 minecraft:terracotta
fill 493 130 465 493 133 465 minecraft:red_terracotta
fill 494 130 464 494 133 464 minecraft:red_terracotta
setblock 496 130 466 minecraft:terracotta
setblock 497 130 465 minecraft:terracotta
fill 497 130 466 497 131 466 minecraft:red_terracotta
setblock 498 130 464 minecraft:terracotta
fill 498 130 465 498 133 465 minecraft:red_terracotta
fill 499 130 464 499 133 464 minecraft:red_terracotta
setblock 502 130 465 minecraft:terracotta
setblock 503 130 464 minecraft:terracotta
setblock 504 130 464 minecraft:red_terracotta
setblock 508 130 464 minecraft:terracotta
fill 509 130 464 509 133 464 minecraft:red_terracotta
setblock 510 130 467 minecraft:terracotta
fill 510 130 468 510 133 468 minecraft:red_terracotta
setblock 511 130 466 minecraft:terracotta
fill 511 130 467 511 133 467 minecraft:red_terracotta
setblock 511 130 471 minecraft:terracotta
fill 511 130 472 511 133 472 minecraft:red_terracotta
setblock 511 130 491 minecraft:terracotta
fill 511 130 492 511 133 492 minecraft:red_terracotta
setblock 511 130 496 minecraft:terracotta
fill 511 130 497 511 130 500 minecraft:red_terracotta
fill 471 131 466 471 134 466 minecraft:red_terracotta
setblock 471 131 470 minecraft:terracotta
fill 471 131 471 471 134 471 minecraft:red_terracotta
fill 471 131 473 471 132 473 minecraft:red_terracotta
fill 471 131 486 471 131 489 minecraft:red_terracotta
setblock 471 131 490 minecraft:terracotta
fill 471 131 491 471 134 491 minecraft:red_terracotta
setblock 471 131 495 minecraft:terracotta
fill 471 131 496 471 134 496 minecraft:red_terracotta
setblock 471 131 500 minecraft:terracotta
fill 471 131 501 471 134 501 minecraft:red_terracotta
fill 472 131 486 473 131 486 minecraft:terracotta
setblock 472 131 489 minecraft:terracotta
fill 472 131 490 472 134 490 minecraft:red_terracotta
setblock 472 131 494 minecraft:terracotta
fill 472 131 495 472 134 495 minecraft:red_terracotta
setblock 472 131 499 minecraft:terracotta
setblock 472 131 504 minecraft:terracotta
setblock 473 131 464 minecraft:red_terracotta
setblock 473 131 478 minecraft:terracotta
setblock 473 131 488 minecraft:terracotta
fill 473 131 489 473 134 489 minecraft:red_terracotta
setblock 473 131 492 minecraft:red_terracotta
setblock 473 131 493 minecraft:terracotta
fill 473 131 494 474 133 494 minecraft:red_terracotta
setblock 473 131 497 minecraft:red_terracotta
fill 473 131 504 473 134 504 minecraft:red_terracotta
fill 474 131 471 474 131 473 minecraft:terracotta
setblock 474 131 492 minecraft:terracotta
fill 474 131 493 474 134 493 minecraft:red_terracotta
fill 475 131 465 476 132 470 minecraft:terracotta
fill 475 131 478 475 131 479 minecraft:terracotta
fill 476 131 464 477 132 464 minecraft:terracotta
fill 476 131 471 476 131 473 minecraft:terracotta
fill 477 131 465 477 131 466 minecraft:terracotta
setblock 492 131 464 minecraft:terracotta
fill 493 131 464 493 134 464 minecraft:red_terracotta
setblock 495 131 466 minecraft:terracotta
setblock 496 131 465 minecraft:terracotta
fill 496 131 466 496 132 466 minecraft:red_terracotta
setblock 497 131 464 minecraft:terracotta
fill 497 131 465 497 134 465 minecraft:red_terracotta
fill 498 131 464 498 134 464 minecraft:red_terracotta
setblock 502 131 464 minecraft:terracotta
setblock 503 131 464 minecraft:red_terracotta
setblock 508 131 464 minecraft:red_terracotta
setblock 510 131 467 minecraft:red_terracotta
setblock 511 131 465 minecraft:terracotta
fill 511 131 466 511 134 466 minecraft:red_terracotta
setblock 511 131 470 minecraft:terracotta
fill 511 131 471 511 134 471 minecraft:red_terracotta
setblock 511 131 474 minecraft:red_terracotta
setblock 511 131 490 minecraft:terracotta
fill 511 131 491 511 134 491 minecraft:red_terracotta
setblock 511 131 494 minecraft:red_terracotta
setblock 511 131 495 minecraft:terracotta
fill 511 131 496 511 131 499 minecraft:red_terracotta
setblock 511 131 500 minecraft:terracotta
fill 511 131 501 511 133 502 minecraft:red_terracotta
setblock 471 132 469 minecraft:terracotta
fill 471 132 470 471 135 470 minecraft:red_terracotta
setblock 471 132 474 minecraft:terracotta
fill 471 132 475 471 135 475 minecraft:red_terracotta
fill 471 132 485 471 132 488 minecraft:red_terracotta
setblock 471 132 489 minecraft:terracotta
fill 471 132 490 471 135 490 minecraft:red_terracotta
setblock 471 132 494 minecraft:terracotta
fill 471 132 495 471 135 495 minecraft:red_terracotta
setblock 471 132 498 minecraft:red_terracotta
setblock 471 132 499 minecraft:terracotta
fill 471 132 500 472 134 500 minecraft:red_terracotta
setblock 471 132 504 minecraft:terracotta
setblock 472 132 488 minecraft:terracotta
fill 472 132 489 472 135 489 minecraft:red_terracotta
setblock 472 132 493 minecraft:terracotta
fill 472 132 494 472 135 494 minecraft:red_terracotta
setblock 472 132 498 minecraft:terracotta
fill 472 132 499 472 135 499 minecraft:red_terracotta
fill 472 132 504 472 135 504 minecraft:red_terracotta
fill 473 132 482 473 132 487 minecraft:orange_concrete
fill 473 132 488 473 135 488 minecraft:red_terracotta
setblock 473 132 492 minecraft:terracotta
fill 473 132 493 473 135 493 minecraft:red_terracotta
setblock 473 132 497 minecraft:terracotta
fill 473 132 498 473 135 498 minecraft:red_terracotta
fill 474 132 475 474 132 477 minecraft:terracotta
fill 474 132 478 474 132 482 minecraft:orange_concrete
setblock 474 132 491 minecraft:terracotta
fill 474 132 492 474 135 492 minecraft:red_terracotta
setblock 474 132 495 minecraft:red_terracotta
fill 475 132 471 475 132 475 minecraft:terracotta
setblock 477 132 465 minecraft:terracotta
setblock 491 132 464 minecraft:terracotta
fill 492 132 464 492 135 464 minecraft:red_terracotta
setblock 495 132 465 minecraft:terracotta
fill 495 132 466 495 133 466 minecraft:red_terracotta
setblock 496 132 464 minecraft:terracotta
fill 496 132 465 496 135 465 minecraft:red_terracotta
fill 497 132 464 497 135 464 minecraft:red_terracotta
setblock 501 132 464 minecraft:terracotta
setblock 510 132 470 minecraft:terracotta
fill 510 132 471 510 135 471 minecraft:red_terracotta
fill 510 132 492 510 132 494 minecraft:red_terracotta
setblock 510 132 495 minecraft:terracotta
fill 510 132 496 511 134 496 minecraft:red_terracotta
setblock 510 132 504 minecraft:red_terracotta
setblock 511 132 464 minecraft:terracotta
fill 511 132 465 511 135 465 minecraft:red_terracotta
setblock 511 132 469 minecraft:terracotta
fill 511 132 470 511 135 470 minecraft:red_terracotta
setblock 511 132 474 minecraft:terracotta
fill 511 132 475 511 135 475 minecraft:red_terracotta
setblock 511 132 489 minecraft:terracotta
fill 511 132 490 511 135 490 minecraft:red_terracotta
setblock 511 132 494 minecraft:terracotta
fill 511 132 495 511 135 495 minecraft:red_terracotta
fill 511 132 497 511 132 498 minecraft:red_terracotta
setblock 511 132 499 minecraft:terracotta
fill 511 132 500 511 135 500 minecraft:red_terracotta
setblock 511 132 504 minecraft:terracotta
setblock 471 133 468 minecraft:terracotta
fill 471 133 469 471 136 469 minecraft:red_terracotta
setblock 471 133 473 minecraft:terracotta
fill 471 133 474 472 135 474 minecraft:red_terracotta
fill 471 133 476 471 133 477 minecraft:red_terracotta
fill 471 133 484 471 133 487 minecraft:red_terracotta
setblock 471 133 488 minecraft:terracotta
fill 471 133 489 471 136 489 minecraft:red_terracotta
setblock 471 133 493 minecraft:terracotta
fill 471 133 494 471 136 494 minecraft:red_terracotta
setblock 471 133 498 minecraft:terracotta
fill 471 133 499 471 136 499 minecraft:red_terracotta
setblock 471 133 503 minecraft:terracotta
fill 471 133 504 471 136 504 minecraft:red_terracotta
fill 472 133 470 472 133 471 minecraft:red_terracotta
setblock 472 133 472 minecraft:terracotta
fill 472 133 473 472 136 473 minecraft:red_terracotta
setblock 472 133 486 minecraft:red_terracotta
setblock 472 133 487 minecraft:terracotta
fill 472 133 488 472 136 488 minecraft:red_terracotta
setblock 472 133 492 minecraft:terracotta
fill 472 133 493 472 136 493 minecraft:red_terracotta
setblock 472 133 496 minecraft:red_terracotta
setblock 472 133 497 minecraft:terracotta
fill 472 133 498 472 136 498 minecraft:red_terracotta
setblock 472 133 501 minecraft:red_terracotta
setblock 473 133 466 minecraft:light[level=14]
setblock 473 133 474 minecraft:light[level=14]
setblock 473 133 482 minecraft:light[level=14]
setblock 473 133 491 minecraft:terracotta
fill 473 133 492 473 136 492 minecraft:red_terracotta
setblock 473 133 496 minecraft:terracotta
fill 473 133 497 473 136 497 minecraft:red_terracotta
fill 473 133 499 473 134 499 minecraft:red_terracotta
fill 474 133 491 474 136 491 minecraft:red_terracotta
setblock 474 133 495 minecraft:terracotta
fill 474 133 496 474 136 496 minecraft:red_terracotta
fill 475 133 469 475 133 474 minecraft:orange_concrete
setblock 475 133 504 minecraft:terracotta
fill 476 133 464 476 133 468 minecraft:orange_concrete
setblock 481 133 466 minecraft:light[level=14]
setblock 481 133 474 minecraft:light[level=14]
setblock 481 133 482 minecraft:light[level=14]
setblock 481 133 490 minecraft:light[level=14]
setblock 481 133 498 minecraft:light[level=14]
setblock 489 133 466 minecraft:light[level=14]
setblock 489 133 474 minecraft:light[level=14]
setblock 489 133 482 minecraft:light[level=14]
setblock 489 133 490 minecraft:light[level=14]
setblock 489 133 498 minecraft:light[level=14]
fill 491 133 464 491 136 464 minecraft:red_terracotta
fill 492 133 465 492 134 465 minecraft:red_terracotta
setblock 494 133 465 minecraft:terracotta
setblock 495 133 464 minecraft:terracotta
fill 495 133 465 495 136 465 minecraft:red_terracotta
fill 495 133 475 496 134 476 minecraft:orange_concrete
fill 496 133 464 496 136 464 minecraft:red_terracotta
setblock 497 133 466 minecraft:light[level=14]
setblock 497 133 474 minecraft:light[level=14]
setblock 497 133 482 minecraft:light[level=14]
setblock 497 133 490 minecraft:light[level=14]
setblock 497 133 498 minecraft:light[level=14]
setblock 500 133 464 minecraft:terracotta
setblock 501 133 464 minecraft:red_terracotta
setblock 505 133 466 minecraft:light[level=14]
setblock 505 133 474 minecraft:light[level=14]
setblock 505 133 482 minecraft:light[level=14]
setblock 505 133 490 minecraft:light[level=14]
setblock 505 133 498 minecraft:light[level=14]
fill 508 133 464 508 134 464 minecraft:red_terracotta
setblock 509 133 504 minecraft:red_terracotta
setblock 510 133 464 minecraft:terracotta
setblock 510 133 469 minecraft:terracotta
fill 510 133 470 510 136 470 minecraft:red_terracotta
fill 510 133 472 510 134 472 minecraft:red_terracotta
fill 510 133 491 510 133 493 minecraft:red_terracotta
setblock 510 133 494 minecraft:terracotta
fill 510 133 495 510 136 495 minecraft:red_terracotta
fill 510 133 497 510 133 498 minecraft:red_terracotta
setblock 510 133 499 minecraft:terracotta
fill 510 133 500 510 136 500 minecraft:red_terracotta
setblock 510 133 504 minecraft:terracotta
fill 511 133 464 511 136 464 minecraft:red_terracotta
setblock 511 133 468 minecraft:terracotta
fill 511 133 469 511 136 469 minecraft:red_terracotta
setblock 511 133 473 minecraft:terracotta
fill 511 133 474 511 136 474 minecraft:red_terracotta
fill 511 133 476 511 134 476 minecraft:red_terracotta
setblock 511 133 488 minecraft:terracotta
fill 511 133 489 511 136 489 minecraft:red_terracotta
setblock 511 133 493 minecraft:terracotta
fill 511 133 494 511 136 494 minecraft:red_terracotta
setblock 511 133 497 minecraft:red_terracotta
setblock 511 133 498 minecraft:terracotta
fill 511 133 499 511 136 499 minecraft:red_terracotta
setblock 511 133 503 minecraft:terracotta
fill 511 133 504 511 136 504 minecraft:red_terracotta
setblock 471 134 467 minecraft:terracotta
fill 471 134 468 471 137 468 minecraft:red_terracotta
setblock 471 134 472 minecraft:terracotta
fill 471 134 473 471 137 473 minecraft:red_terracotta
setblock 471 134 476 minecraft:red_terracotta
setblock 471 134 477 minecraft:terracotta
fill 471 134 478 471 134 481 minecraft:red_terracotta
setblock 471 134 482 minecraft:terracotta
fill 471 134 483 471 134 486 minecraft:red_terracotta
setblock 471 134 487 minecraft:terracotta
fill 471 134 488 471 137 488 minecraft:red_terracotta
setblock 471 134 492 minecraft:terracotta
fill 471 134 493 471 137 493 minecraft:red_terracotta
setblock 471 134 497 minecraft:terracotta
fill 471 134 498 471 137 498 minecraft:red_terracotta
setblock 471 134 502 minecraft:terracotta
fill 471 134 503 471 137 503 minecraft:red_terracotta
setblock 472 134 470 minecraft:red_terracotta
setblock 472 134 471 minecraft:terracotta
fill 472 134 472 472 137 472 minecraft:red_terracotta
setblock 472 134 475 minecraft:red_terracotta
setblock 472 134 476 minecraft:terracotta
fill 472 134 477 472 137 477 minecraft:red_terracotta
setblock 472 134 486 minecraft:terracotta
fill 472 134 487 472 137 487 minecraft:red_terracotta
setblock 472 134 491 minecraft:terracotta
fill 472 134 492 472 137 492 minecraft:red_terracotta
setblock 472 134 496 minecraft:terracotta
fill 472 134 497 472 137 497 minecraft:red_terracotta
setblock 472 134 501 minecraft:terracotta
fill 472 134 502 472 137 502 minecraft:red_terracotta
setblock 473 134 490 minecraft:terracotta
fill 473 134 491 473 137 491 minecraft:red_terracotta
setblock 473 134 494 minecraft:red_terracotta
setblock 473 134 495 minecraft:terracotta
fill 473 134 496 473 137 496 minecraft:red_terracotta
setblock 473 134 500 minecraft:terracotta
setblock 474 134 494 minecraft:terracotta
fill 474 134 495 474 137 495 minecraft:red_terracotta
fill 474 134 497 474 135 497 minecraft:red_terracotta
setblock 474 134 504 minecraft:terracotta
fill 475 134 504 475 137 504 minecraft:red_terracotta
fill 490 134 464 490 137 464 minecraft:red_terracotta
setblock 493 134 465 minecraft:terracotta
setblock 494 134 464 minecraft:terracotta
fill 494 134 465 494 137 465 minecraft:red_terracotta
fill 495 134 464 495 137 464 minecraft:red_terracotta
setblock 498 134 465 minecraft:terracotta
setblock 499 134 464 minecraft:terracotta
fill 500 134 464 500 137 464 minecraft:red_terracotta
setblock 508 134 504 minecraft:red_terracotta
setblock 509 134 464 minecraft:terracotta
setblock 509 134 504 minecraft:terracotta
fill 510 134 464 510 137 464 minecraft:red_terracotta
setblock 510 134 467 minecraft:red_terracotta
setblock 510 134 468 minecraft:terracotta
fill 510 134 469 510 137 469 minecraft:red_terracotta
setblock 510 134 473 minecraft:terracotta
fill 510 134 474 510 137 474 minecraft:red_terracotta
fill 510 134 491 510 134 492 minecraft:red_terracotta
setblock 510 134 493 minecraft:terracotta
fill 510 134 494 510 137 494 minecraft:red_terracotta
setblock 510 134 497 minecraft:red_terracotta
setblock 510 134 498 minecraft:terracotta
fill 510 134 499 510 137 499 minecraft:red_terracotta
fill 510 134 501 510 134 502 minecraft:red_terracotta
setblock 510 134 503 minecraft:terracotta
fill 510 134 504 510 137 504 minecraft:red_terracotta
setblock 511 134 467 minecraft:terracotta
fill 511 134 468 511 137 468 minecraft:red_terracotta
setblock 511 134 472 minecraft:terracotta
fill 511 134 473 511 137 473 minecraft:red_terracotta
setblock 511 134 477 minecraft:terracotta
fill 511 134 478 511 137 478 minecraft:red_terracotta
setblock 511 134 487 minecraft:terracotta
fill 511 134 488 511 137 488 minecraft:red_terracotta
setblock 511 134 492 minecraft:terracotta
fill 511 134 493 511 137 493 minecraft:red_terracotta
setblock 511 134 497 minecraft:terracotta
fill 511 134 498 511 137 498 minecraft:red_terracotta
setblock 511 134 501 minecraft:red_terracotta
setblock 511 134 502 minecraft:terracotta
fill 511 134 503 511 137 503 minecraft:red_terracotta
setblock 471 135 466 minecraft:terracotta
fill 471 135 467 471 138 467 minecraft:red_terracotta
setblock 471 135 471 minecraft:terracotta
fill 471 135 472 471 138 472 minecraft:red_terracotta
setblock 471 135 476 minecraft:terracotta
fill 471 135 477 471 135 480 minecraft:red_terracotta
setblock 471 135 481 minecraft:terracotta
fill 471 135 482 471 135 485 minecraft:red_terracotta
setblock 471 135 486 minecraft:terracotta
fill 471 135 487 471 138 487 minecraft:red_terracotta
setblock 471 135 491 minecraft:terracotta
fill 471 135 492 471 138 492 minecraft:red_terracotta
setblock 471 135 496 minecraft:terracotta
fill 471 135 497 471 138 497 minecraft:red_terracotta
setblock 471 135 500 minecraft:red_terracotta
setblock 471 135 501 minecraft:terracotta
fill 471 135 502 471 138 502 minecraft:red_terracotta
setblock 472 135 469 minecraft:red_terracotta
setblock 472 135 470 minecraft:terracotta
fill 472 135 471 472 138 471 minecraft:red_terracotta
setblock 472 135 475 minecraft:terracotta
fill 472 135 476 472 138 476 minecraft:red_terracotta
fill 472 135 478 472 135 479 minecraft:red_terracotta
setblock 472 135 480 minecraft:terracotta
fill 472 135 481 472 138 481 minecraft:red_terracotta
setblock 472 135 484 minecraft:red_terracotta
setblock 472 135 485 minecraft:terracotta
fill 472 135 486 472 138 486 minecraft:red_terracotta
setblock 472 135 490 minecraft:terracotta
fill 472 135 491 472 138 491 minecraft:red_terracotta
setblock 472 135 495 minecraft:terracotta
fill 472 135 496 472 138 496 minecraft:red_terracotta
setblock 472 135 500 minecraft:terracotta
fill 472 135 501 473 137 501 minecraft:red_terracotta
fill 472 135 503 473 135 503 minecraft:red_terracotta
setblock 473 135 474 minecraft:terracotta
fill 473 135 475 473 138 475 minecraft:red_terracotta
setblock 473 135 489 minecraft:terracotta
fill 473 135 490 473 138 490 minecraft:red_terracotta
setblock 473 135 494 minecraft:terracotta
fill 473 135 495 473 138 495 minecraft:red_terracotta
setblock 473 135 499 minecraft:terracotta
fill 473 135 500 473 138 500 minecraft:red_terracotta
setblock 473 135 504 minecraft:terracotta
setblock 474 135 493 minecraft:terracotta
fill 474 135 494 474 138 494 minecraft:red_terracotta
setblock 474 135 498 minecraft:terracotta
fill 474 135 504 474 138 504 minecraft:red_terracotta
fill 489 135 464 489 138 464 minecraft:red_terracotta
setblock 491 135 465 minecraft:red_terracotta
setblock 492 135 465 minecraft:terracotta
setblock 492 135 504 minecraft:red_terracotta
setblock 493 135 464 minecraft:terracotta
fill 493 135 465 493 137 466 minecraft:red_terracotta
setblock 493 135 504 minecraft:terracotta
fill 494 135 464 494 138 464 minecraft:red_terracotta
fill 494 135 466 494 136 466 minecraft:red_terracotta
fill 494 135 504 496 136 504 minecraft:red_terracotta
setblock 497 135 465 minecraft:terracotta
setblock 498 135 464 minecraft:terracotta
fill 499 135 464 499 138 464 minecraft:red_terracotta
fill 506 135 504 507 135 504 minecraft:red_terracotta
setblock 507 135 464 minecraft:red_terracotta
setblock 508 135 464 minecraft:terracotta
setblock 508 135 504 minecraft:terracotta
fill 509 135 464 509 138 464 minecraft:red_terracotta
fill 509 135 494 509 135 497 minecraft:red_terracotta
setblock 509 135 498 minecraft:terracotta
fill 509 135 499 509 138 499 minecraft:red_terracotta
setblock 509 135 503 minecraft:terracotta
fill 509 135 504 509 138 504 minecraft:red_terracotta
setblock 510 135 467 minecraft:terracotta
fill 510 135 468 510 138 468 minecraft:red_terracotta
setblock 510 135 472 minecraft:terracotta
fill 510 135 473 510 138 473 minecraft:red_terracotta
fill 510 135 475 510 135 476 minecraft:red_terracotta
fill 510 135 490 510 135 491 minecraft:red_terracotta
setblock 510 135 492 minecraft:terracotta
fill 510 135 493 510 138 493 minecraft:red_terracotta
setblock 510 135 496 minecraft:red_terracotta
setblock 510 135 497 minecraft:terracotta
fill 510 135 498 510 138 498 minecraft:red_terracotta
setblock 510 135 501 minecraft:red_terracotta
setblock 510 135 502 minecraft:terracotta
fill 510 135 503 510 138 503 minecraft:red_terracotta
setblock 511 135 466 minecraft:terracotta
fill 511 135 467 511 138 467 minecraft:red_terracotta
setblock 511 135 471 minecraft:terracotta
fill 511 135 472 511 138 472 minecraft:red_terracotta
setblock 511 135 476 minecraft:terracotta
fill 511 135 477 511 138 477 minecraft:red_terracotta
fill 511 135 479 511 135 480 minecraft:red_terracotta
setblock 511 135 486 minecraft:terracotta
fill 511 135 487 511 138 487 minecraft:red_terracotta
setblock 511 135 491 minecraft:terracotta
fill 511 135 492 511 138 492 minecraft:red_terracotta
setblock 511 135 496 minecraft:terracotta
fill 511 135 497 511 138 497 minecraft:red_terracotta
setblock 511 135 501 minecraft:terracotta
fill 511 135 502 511 138 502 minecraft:red_terracotta
setblock 471 136 464 minecraft:red_terracotta
setblock 471 136 465 minecraft:terracotta
fill 471 136 466 471 139 466 minecraft:red_terracotta
setblock 471 136 470 minecraft:terracotta
fill 471 136 471 471 139 471 minecraft:red_terracotta
setblock 471 136 474 minecraft:red_terracotta
setblock 471 136 475 minecraft:terracotta
fill 471 136 476 471 136 479 minecraft:red_terracotta
setblock 471 136 480 minecraft:terracotta
fill 471 136 481 471 136 484 minecraft:red_terracotta
setblock 471 136 485 minecraft:terracotta
fill 471 136 486 471 139 486 minecraft:red_terracotta
setblock 471 136 490 minecraft:terracotta
fill 471 136 491 471 139 491 minecraft:red_terracotta
setblock 471 136 495 minecraft:terracotta
fill 471 136 496 471 139 496 minecraft:red_terracotta
setblock 471 136 500 minecraft:terracotta
fill 471 136 501 471 139 501 minecraft:red_terracotta
setblock 472 136 464 minecraft:terracotta
setblock 472 136 469 minecraft:terracotta
fill 472 136 470 472 138 470 minecraft:red_terracotta
setblock 472 136 474 minecraft:terracotta
fill 472 136 475 472 139 475 minecraft:red_terracotta
setblock 472 136 478 minecraft:red_terracotta
setblock 472 136 479 minecraft:terracotta
fill 472 136 480 472 139 480 minecraft:red_terracotta
fill 472 136 482 472 136 483 minecraft:red_terracotta
setblock 472 136 484 minecraft:terracotta
fill 472 136 485 472 139 485 minecraft:red_terracotta
setblock 472 136 489 minecraft:terracotta
fill 472 136 490 472 139 490 minecraft:red_terracotta
setblock 472 136 494 minecraft:terracotta
fill 472 136 495 472 139 495 minecraft:red_terracotta
setblock 472 136 499 minecraft:terracotta
fill 472 136 500 472 139 500 minecraft:red_terracotta
setblock 472 136 503 minecraft:red_terracotta
setblock 472 136 504 minecraft:terracotta
setblock 473 136 473 minecraft:terracotta
fill 473 136 474 473 139 474 minecraft:red_terracotta
fill 473 136 476 473 136 477 minecraft:red_terracotta
setblock 473 136 478 minecraft:terracotta
setblock 473 136 487 minecraft:red_terracotta
setblock 473 136 488 minecraft:terracotta
fill 473 136 489 473 139 489 minecraft:red_terracotta
setblock 473 136 493 minecraft:terracotta
fill 473 136 494 473 139 494 minecraft:red_terracotta
setblock 473 136 498 minecraft:terracotta
fill 473 136 499 473 139 499 minecraft:red_terracotta
setblock 473 136 503 minecraft:terracotta
fill 473 136 504 473 139 504 minecraft:red_terracotta
setblock 474 136 492 minecraft:terracotta
fill 474 136 493 474 138 493 minecraft:red_terracotta
setblock 474 136 497 minecraft:terracotta
fill 474 136 498 474 139 498 minecraft:red_terracotta
fill 474 136 503 474 139 503 minecraft:red_terracotta
fill 488 136 464 488 139 464 minecraft:red_terracotta
setblock 490 136 465 minecraft:red_terracotta
fill 490 136 504 491 136 504 minecraft:red_terracotta
setblock 491 136 465 minecraft:terracotta
setblock 492 136 464 minecraft:terracotta
fill 492 136 465 492 139 465 minecraft:red_terracotta
setblock 492 136 504 minecraft:terracotta
fill 493 136 464 493 139 464 minecraft:red_terracotta
fill 493 136 504 493 139 504 minecraft:red_terracotta
setblock 496 136 465 minecraft:terracotta
setblock 497 136 464 minecraft:terracotta
fill 497 136 465 497 137 465 minecraft:red_terracotta
setblock 497 136 504 minecraft:terracotta
fill 498 136 464 498 139 464 minecraft:red_terracotta
fill 498 136 504 498 139 504 minecraft:red_terracotta
fill 505 136 504 506 136 504 minecraft:red_terracotta
setblock 506 136 464 minecraft:red_terracotta
setblock 507 136 464 minecraft:terracotta
setblock 507 136 503 minecraft:red_terracotta
setblock 507 136 504 minecraft:terracotta
fill 508 136 464 508 139 464 minecraft:red_terracotta
setblock 508 136 503 minecraft:terracotta
fill 508 136 504 508 139 504 minecraft:red_terracotta
fill 509 136 493 509 136 496 minecraft:red_terracotta
setblock 509 136 497 minecraft:terracotta
fill 509 136 498 509 139 498 minecraft:red_terracotta
fill 509 136 500 509 136 501 minecraft:red_terracotta
setblock 509 136 502 minecraft:terracotta
fill 509 136 503 509 139 503 minecraft:red_terracotta
setblock 510 136 466 minecraft:terracotta
fill 510 136 467 510 138 467 minecraft:red_terracotta
setblock 510 136 471 minecraft:terracotta
fill 510 136 472 510 139 472 minecraft:red_terracotta
setblock 510 136 475 minecraft:red_terracotta
setblock 510 136 476 minecraft:terracotta
fill 510 136 477 510 139 477 minecraft:red_terracotta
fill 510 136 489 510 136 490 minecraft:red_terracotta
setblock 510 136 491 minecraft:terracotta
fill 510 136 492 510 139 492 minecraft:red_terracotta
setblock 510 136 496 minecraft:terracotta
fill 510 136 497 510 139 497 minecraft:red_terracotta
setblock 510 136 501 minecraft:terracotta
fill 510 136 502 510 139 502 minecraft:red_terracotta
setblock 511 136 465 minecraft:terracotta
fill 511 136 466 511 139 466 minecraft:red_terracotta
setblock 511 136 470 minecraft:terracotta
fill 511 136 471 511 139 471 minecraft:red_terracotta
setblock 511 136 475 minecraft:terracotta
fill 511 136 476 511 139 476 minecraft:red_terracotta
setblock 511 136 479 minecraft:red_terracotta
setblock 511 136 480 minecraft:terracotta
fill 511 136 481 511 136 484 minecraft:red_terracotta
setblock 511 136 485 minecraft:terracotta
fill 511 136 486 511 139 486 minecraft:red_terracotta
setblock 511 136 490 minecraft:terracotta
fill 511 136 491 511 139 491 minecraft:red_terracotta
setblock 511 136 495 minecraft:terracotta
fill 511 136 496 511 139 496 minecraft:red_terracotta
setblock 511 136 500 minecraft:terracotta
fill 511 136 501 511 139 501 minecraft:red_terracotta
setblock 471 137 464 minecraft:terracotta
fill 471 137 465 471 139 465 minecraft:red_terracotta
setblock 471 137 469 minecraft:terracotta
fill 471 137 470 471 140 470 minecraft:red_terracotta
setblock 471 137 474 minecraft:terracotta
fill 471 137 475 471 137 478 minecraft:red_terracotta
setblock 471 137 479 minecraft:terracotta
fill 471 137 480 471 137 483 minecraft:red_terracotta
setblock 471 137 484 minecraft:terracotta
fill 471 137 485 471 140 485 minecraft:red_terracotta
setblock 471 137 489 minecraft:terracotta
fill 471 137 490 471 140 490 minecraft:red_terracotta
setblock 471 137 494 minecraft:terracotta
fill 471 137 495 471 140 495 minecraft:red_terracotta
setblock 471 137 499 minecraft:terracotta
fill 471 137 500 471 140 500 minecraft:red_terracotta
setblock 471 137 504 minecraft:terracotta
fill 472 137 464 472 139 464 minecraft:red_terracotta
setblock 472 137 469 minecraft:red_terracotta
setblock 472 137 473 minecraft:terracotta
fill 472 137 474 472 140 474 minecraft:red_terracotta
setblock 472 137 478 minecraft:terracotta
fill 472 137 479 473 139 479 minecraft:red_terracotta
setblock 472 137 482 minecraft:red_terracotta
setblock 472 137 483 minecraft:terracotta
fill 472 137 484 472 140 484 minecraft:red_terracotta
setblock 472 137 488 minecraft:terracotta
fill 472 137 489 472 140 489 minecraft:red_terracotta
setblock 472 137 493 minecraft:terracotta
fill 472 137 494 472 140 494 minecraft:red_terracotta
setblock 472 137 498 minecraft:terracotta
fill 472 137 499 472 140 499 minecraft:red_terracotta
setblock 472 137 503 minecraft:terracotta
fill 472 137 504 472 140 504 minecraft:red_terracotta
setblock 473 137 472 minecraft:terracotta
fill 473 137 473 473 138 473 minecraft:red_terracotta
setblock 473 137 476 minecraft:red_terracotta
setblock 473 137 477 minecraft:terracotta
fill 473 137 478 473 140 478 minecraft:red_terracotta
fill 473 137 480 473 137 481 minecraft:red_terracotta
setblock 473 137 487 minecraft:terracotta
fill 473 137 488 473 138 488 minecraft:red_terracotta
setblock 473 137 492 minecraft:terracotta
fill 473 137 493 473 140 493 minecraft:red_terracotta
setblock 473 137 497 minecraft:terracotta
fill 473 137 498 473 140 498 minecraft:red_terracotta
setblock 473 137 502 minecraft:terracotta
fill 473 137 503 473 140 503 minecraft:red_terracotta
setblock 474 137 492 minecraft:red_terracotta
setblock 474 137 496 minecraft:terracotta
fill 474 137 497 474 139 497 minecraft:red_terracotta
fill 474 137 499 474 138 499 minecraft:red_terracotta
setblock 476 137 504 minecraft:terracotta
setblock 489 137 465 minecraft:red_terracotta
fill 489 137 504 490 137 504 minecraft:red_terracotta
setblock 490 137 465 minecraft:terracotta
setblock 491 137 464 minecraft:terracotta
fill 491 137 465 491 140 465 minecraft:red_terracotta
setblock 491 137 504 minecraft:terracotta
fill 492 137 464 492 140 464 minecraft:red_terracotta
fill 492 137 466 492 138 466 minecraft:red_terracotta
setblock 492 137 503 minecraft:terracotta
fill 492 137 504 492 140 504 minecraft:red_terracotta
fill 493 137 503 494 139 503 minecraft:red_terracotta
setblock 494 137 466 minecraft:terracotta
fill 494 137 504 495 137 504 minecraft:red_terracotta
setblock 495 137 465 minecraft:terracotta
setblock 496 137 464 minecraft:terracotta
fill 496 137 465 496 139 465 minecraft:red_terracotta
setblock 496 137 504 minecraft:terracotta
fill 497 137 464 497 140 464 minecraft:red_terracotta
fill 497 137 504 497 140 504 minecraft:red_terracotta
fill 499 137 504 500 137 504 minecraft:red_terracotta
setblock 501 137 464 minecraft:terracotta
fill 502 137 504 505 137 504 minecraft:red_terracotta
fill 504 137 464 505 137 464 minecraft:red_terracotta
setblock 506 137 464 minecraft:terracotta
setblock 506 137 503 minecraft:red_terracotta
setblock 506 137 504 minecraft:terracotta
fill 507 137 464 507 140 464 minecraft:red_terracotta
setblock 507 137 503 minecraft:terracotta
fill 507 137 504 507 140 504 minecraft:red_terracotta
setblock 508 137 496 minecraft:red_terracotta
setblock 508 137 497 minecraft:terracotta
fill 508 137 498 508 139 499 minecraft:red_terracotta
setblock 508 137 502 minecraft:terracotta
fill 508 137 503 508 140 503 minecraft:red_terracotta
fill 509 137 492 509 137 495 minecraft:red_terracotta
setblock 509 137 496 minecraft:terracotta
fill 509 137 497 509 140 497 minecraft:red_terracotta
setblock 509 137 500 minecraft:red_terracotta
setblock 509 137 501 minecraft:terracotta
fill 509 137 502 509 140 502 minecraft:red_terracotta
setblock 510 137 465 minecraft:terracotta
fill 510 137 466 510 138 466 minecraft:red_terracotta
setblock 510 137 470 minecraft:terracotta
fill 510 137 471 510 140 471 minecraft:red_terracotta
setblock 510 137 475 minecraft:terracotta
fill 510 137 476 510 140 476 minecraft:red_terracotta
fill 510 137 478 510 137 479 minecraft:red_terracotta
setblock 510 137 489 minecraft:red_terracotta
setblock 510 137 490 minecraft:terracotta
fill 510 137 491 510 140 491 minecraft:red_terracotta
setblock 510 137 495 minecraft:terracotta
fill 510 137 496 510 140 496 minecraft:red_terracotta
setblock 510 137 500 minecraft:terracotta
fill 510 137 501 510 140 501 minecraft:red_terracotta
setblock 511 137 464 minecraft:terracotta
fill 511 137 465 511 140 465 minecraft:red_terracotta
setblock 511 137 469 minecraft:terracotta
fill 511 137 470 511 140 470 minecraft:red_terracotta
setblock 511 137 474 minecraft:terracotta
fill 511 137 475 511 140 475 minecraft:red_terracotta
setblock 511 137 479 minecraft:terracotta
fill 511 137 480 511 137 483 minecraft:red_terracotta
setblock 511 137 484 minecraft:terracotta
fill 511 137 485 511 140 485 minecraft:red_terracotta
setblock 511 137 489 minecraft:terracotta
fill 511 137 490 511 140 490 minecraft:red_terracotta
setblock 511 137 494 minecraft:terracotta
fill 511 137 495 511 140 495 minecraft:red_terracotta
setblock 511 137 499 minecraft:terracotta
fill 511 137 500 511 140 500 minecraft:red_terracotta
setblock 511 137 504 minecraft:terracotta
fill 471 138 464 471 140 464 minecraft:red_terracotta
setblock 471 138 468 minecraft:terracotta
fill 471 138 469 471 140 469 minecraft:red_terracotta
setblock 471 138 473 minecraft:terracotta
fill 471 138 474 471 138 477 minecraft:red_terracotta
setblock 471 138 478 minecraft:terracotta
fill 471 138 479 471 138 482 minecraft:red_terracotta
setblock 471 138 483 minecraft:terracotta
fill 471 138 484 471 141 484 minecraft:red_terracotta
setblock 471 138 488 minecraft:terracotta
fill 471 138 489 471 141 489 minecraft:red_terracotta
setblock 471 138 493 minecraft:terracotta
fill 471 138 494 471 141 494 minecraft:red_terracotta
setblock 471 138 498 minecraft:terracotta
fill 471 138 499 471 141 499 minecraft:red_terracotta
setblock 471 138 503 minecraft:terracotta
fill 471 138 504 471 141 504 minecraft:red_terracotta
setblock 472 138 472 minecraft:terracotta
fill 472 138 473 472 141 473 minecraft:red_terracotta
setblock 472 138 477 minecraft:terracotta
fill 472 138 478 472 141 478 minecraft:red_terracotta
setblock 472 138 482 minecraft:terracotta
fill 472 138 483 473 140 483 minecraft:red_terracotta
setblock 472 138 487 minecraft:terracotta
fill 472 138 488 472 141 488 minecraft:red_terracotta
setblock 472 138 492 minecraft:terracotta
fill 472 138 493 472 141 493 minecraft:red_terracotta
setblock 472 138 497 minecraft:terracotta
fill 472 138 498 472 141 498 minecraft:red_terracotta
setblock 472 138 501 minecraft:red_terracotta
setblock 472 138 502 minecraft:terracotta
fill 472 138 503 472 141 503 minecraft:red_terracotta
setblock 473 138 476 minecraft:terracotta
fill 473 138 477 473 141 477 minecraft:red_terracotta
setblock 473 138 480 minecraft:red_terracotta
setblock 473 138 481 minecraft:terracotta
fill 473 138 482 473 141 482 minecraft:red_terracotta
setblock 473 138 491 minecraft:terracotta
fill 473 138 492 473 140 492 minecraft:red_terracotta
setblock 473 138 496 minecraft:terracotta
fill 473 138 497 473 141 497 minecraft:red_terracotta
setblock 473 138 501 minecraft:terracotta
fill 473 138 502 473 140 502 minecraft:red_terracotta
setblock 474 138 495 minecraft:terracotta
fill 474 138 496 474 139 496 minecraft:red_terracotta
setblock 475 138 504 minecraft:terracotta
setblock 476 138 504 minecraft:red_terracotta
fill 487 138 464 487 140 464 minecraft:red_terracotta
fill 488 138 504 489 138 504 minecraft:red_terracotta
setblock 489 138 465 minecraft:terracotta
setblock 490 138 464 minecraft:terracotta
fill 490 138 465 490 141 465 minecraft:red_terracotta
setblock 490 138 503 minecraft:red_terracotta
setblock 490 138 504 minecraft:terracotta
fill 491 138 464 491 141 464 minecraft:red_terracotta
setblock 491 138 466 minecraft:red_terracotta
setblock 491 138 503 minecraft:terracotta
fill 491 138 504 491 141 504 minecraft:red_terracotta
fill 492 138 503 492 141 503 minecraft:red_terracotta
setblock 493 138 465 minecraft:red_terracotta
setblock 493 138 466 minecraft:terracotta
setblock 494 138 465 minecraft:terracotta
setblock 494 138 504 minecraft:red_terracotta
setblock 495 138 464 minecraft:terracotta
fill 495 138 465 495 140 465 minecraft:red_terracotta
setblock 495 138 503 minecraft:red_terracotta
setblock 495 138 504 minecraft:terracotta
fill 496 138 464 496 141 464 minecraft:red_terracotta
setblock 496 138 503 minecraft:terracotta
fill 496 138 504 496 141 504 minecraft:red_terracotta
setblock 499 138 504 minecraft:red_terracotta
setblock 500 138 464 minecraft:terracotta
setblock 500 138 504 minecraft:terracotta
fill 501 138 464 504 138 464 minecraft:red_terracotta
fill 501 138 504 504 138 504 minecraft:red_terracotta
fill 504 138 503 505 138 503 minecraft:red_terracotta
setblock 505 138 464 minecraft:terracotta
setblock 505 138 504 minecraft:terracotta
fill 506 138 464 506 141 464 minecraft:red_terracotta
setblock 506 138 502 minecraft:red_terracotta
setblock 506 138 503 minecraft:terracotta
fill 506 138 504 506 141 504 minecraft:red_terracotta
setblock 507 138 502 minecraft:terracotta
fill 507 138 503 507 141 503 minecraft:red_terracotta
setblock 508 138 495 minecraft:red_terracotta
setblock 508 138 496 minecraft:terracotta
fill 508 138 497 508 141 497 minecraft:red_terracotta
setblock 508 138 500 minecraft:red_terracotta
setblock 508 138 501 minecraft:terracotta
fill 508 138 502 508 141 502 minecraft:red_terracotta
setblock 509 138 465 minecraft:terracotta
setblock 509 138 474 minecraft:red_terracotta
setblock 509 138 475 minecraft:terracotta
fill 509 138 492 509 138 494 minecraft:red_terracotta
setblock 509 138 495 minecraft:terracotta
fill 509 138 496 509 141 496 minecraft:red_terracotta
setblock 509 138 500 minecraft:terracotta
fill 509 138 501 509 141 501 minecraft:red_terracotta
setblock 510 138 464 minecraft:terracotta
fill 510 138 465 510 139 465 minecraft:red_terracotta
setblock 510 138 469 minecraft:terracotta
fill 510 138 470 510 139 470 minecraft:red_terracotta
setblock 510 138 474 minecraft:terracotta
fill 510 138 475 510 141 475 minecraft:red_terracotta
setblock 510 138 478 minecraft:red_terracotta
setblock 510 138 479 minecraft:terracotta
fill 510 138 480 511 139 481 minecraft:red_terracotta
setblock 510 138 489 minecraft:terracotta
fill 510 138 490 510 141 490 minecraft:red_terracotta
setblock 510 138 494 minecraft:terracotta
fill 510 138 495 510 141 495 minecraft:red_terracotta
setblock 510 138 499 minecraft:terracotta
fill 510 138 500 510 141 500 minecraft:red_terracotta
setblock 510 138 504 minecraft:terracotta
fill 511 138 464 511 141 464 minecraft:red_terracotta
setblock 511 138 468 minecraft:terracotta
fill 511 138 469 511 141 469 minecraft:red_terracotta
setblock 511 138 473 minecraft:terracotta
fill 511 138 474 511 141 474 minecraft:red_terracotta
setblock 511 138 478 minecraft:terracotta
fill 511 138 479 511 141 479 minecraft:red_terracotta
setblock 511 138 482 minecraft:red_terracotta
setblock 511 138 483 minecraft:terracotta
fill 511 138 484 511 141 484 minecraft:red_terracotta
setblock 511 138 488 minecraft:terracotta
fill 511 138 489 511 141 489 minecraft:red_terracotta
setblock 511 138 493 minecraft:terracotta
fill 511 138 494 511 141 494 minecraft:red_terracotta
setblock 511 138 498 minecraft:terracotta
fill 511 138 499 511 141 499 minecraft:red_terracotta
setblock 511 138 503 minecraft:terracotta
fill 511 138 504 511 141 504 minecraft:red_terracotta
setblock 471 139 467 minecraft:terracotta
fill 471 139 468 471 140 468 minecraft:red_terracotta
setblock 471 139 472 minecraft:terracotta
fill 471 139 473 471 139 476 minecraft:red_terracotta
setblock 471 139 477 minecraft:terracotta
fill 471 139 478 471 139 481 minecraft:red_terracotta
setblock 471 139 482 minecraft:terracotta
fill 471 139 483 471 142 483 minecraft:red_terracotta
setblock 471 139 487 minecraft:terracotta
fill 471 139 488 471 142 488 minecraft:red_terracotta
setblock 471 139 492 minecraft:terracotta
fill 471 139 493 471 142 493 minecraft:red_terracotta
setblock 471 139 497 minecraft:terracotta
fill 471 139 498 471 142 498 minecraft:red_terracotta
setblock 471 139 502 minecraft:terracotta
fill 471 139 503 471 142 503 minecraft:red_terracotta
setblock 472 139 471 minecraft:terracotta
fill 472 139 472 472 140 472 minecraft:red_terracotta
setblock 472 139 476 minecraft:terracotta
fill 472 139 477 472 142 477 minecraft:red_terracotta
setblock 472 139 481 minecraft:terracotta
fill 472 139 482 472 142 482 minecraft:red_terracotta
setblock 472 139 486 minecraft:terracotta
fill 472 139 487 472 142 487 minecraft:red_terracotta
setblock 472 139 491 minecraft:terracotta
fill 472 139 492 472 142 492 minecraft:red_terracotta
setblock 472 139 496 minecraft:terracotta
fill 472 139 497 472 142 497 minecraft:red_terracotta
setblock 472 139 501 minecraft:terracotta
fill 472 139 502 472 142 502 minecraft:red_terracotta
setblock 473 139 475 minecraft:terracotta
fill 473 139 476 473 141 476 minecraft:red_terracotta
setblock 473 139 480 minecraft:terracotta
fill 473 139 481 473 142 481 minecraft:red_terracotta
setblock 473 139 490 minecraft:terracotta
fill 473 139 491 473 140 491 minecraft:red_terracotta
setblock 473 139 495 minecraft:terracotta
fill 473 139 496 473 141 496 minecraft:red_terracotta
setblock 473 139 500 minecraft:terracotta
fill 473 139 501 473 141 501 minecraft:red_terracotta
setblock 474 139 495 minecraft:red_terracotta
setblock 474 139 504 minecraft:terracotta
fill 475 139 504 475 141 504 minecraft:red_terracotta
fill 486 139 464 486 141 464 minecraft:red_terracotta
fill 487 139 504 488 139 504 minecraft:red_terracotta
setblock 488 139 465 minecraft:terracotta
setblock 489 139 464 minecraft:terracotta
fill 489 139 465 489 142 465 minecraft:red_terracotta
setblock 489 139 503 minecraft:red_terracotta
setblock 489 139 504 minecraft:terracotta
fill 490 139 464 490 142 464 minecraft:red_terracotta
setblock 490 139 503 minecraft:terracotta
fill 490 139 504 490 142 504 minecraft:red_terracotta
fill 491 139 503 491 142 503 minecraft:red_terracotta
setblock 493 139 465 minecraft:terracotta
setblock 494 139 464 minecraft:terracotta
fill 494 139 465 494 141 465 minecraft:red_terracotta
setblock 494 139 504 minecraft:terracotta
fill 495 139 464 495 142 464 minecraft:red_terracotta
setblock 495 139 503 minecraft:terracotta
fill 495 139 504 495 142 504 minecraft:red_terracotta
fill 496 139 503 496 141 503 minecraft:red_terracotta
setblock 499 139 464 minecraft:terracotta
setblock 499 139 504 minecraft:terracotta
fill 500 139 464 503 139 464 minecraft:red_terracotta
fill 500 139 504 503 139 504 minecraft:red_terracotta
fill 503 139 503 504 139 503 minecraft:red_terracotta
setblock 504 139 464 minecraft:terracotta
setblock 504 139 504 minecraft:terracotta
fill 505 139 464 505 142 464 minecraft:red_terracotta
setblock 505 139 502 minecraft:red_terracotta
setblock 505 139 503 minecraft:terracotta
fill 505 139 504 505 142 504 minecraft:red_terracotta
setblock 506 139 502 minecraft:terracotta
fill 506 139 503 506 142 503 minecraft:red_terracotta
setblock 507 139 501 minecraft:terracotta
fill 507 139 502 507 142 502 minecraft:red_terracotta
setblock 508 139 495 minecraft:terracotta
fill 508 139 496 508 141 496 minecraft:red_terracotta
setblock 508 139 500 minecraft:terracotta
fill 508 139 501 508 142 501 minecraft:red_terracotta
setblock 509 139 464 minecraft:terracotta
setblock 509 139 465 minecraft:red_terracotta
fill 509 139 475 509 139 476 minecraft:red_terracotta
fill 509 139 492 509 139 493 minecraft:red_terracotta
setblock 509 139 494 minecraft:terracotta
fill 509 139 495 509 142 495 minecraft:red_terracotta
setblock 509 139 499 minecraft:terracotta
fill 509 139 500 509 142 500 minecraft:red_terracotta
setblock 509 139 504 minecraft:terracotta
fill 510 139 464 510 142 464 minecraft:red_terracotta
setblock 510 139 469 minecraft:red_terracotta
setblock 510 139 473 minecraft:terracotta
fill 510 139 474 510 141 474 minecraft:red_terracotta
setblock 510 139 478 minecraft:terracotta
fill 510 139 479 510 142 479 minecraft:red_terracotta
setblock 510 139 482 minecraft:red_terracotta
setblock 510 139 488 minecraft:terracotta
fill 510 139 489 510 141 489 minecraft:red_terracotta
setblock 510 139 493 minecraft:terracotta
fill 510 139 494 510 142 494 minecraft:red_terracotta
setblock 510 139 498 minecraft:terracotta
fill 510 139 499 510 142 499 minecraft:red_terracotta
setblock 510 139 503 minecraft:terracotta
fill 510 139 504 510 142 504 minecraft:red_terracotta
setblock 511 139 467 minecraft:terracotta
fill 511 139 468 511 141 468 minecraft:red_terracotta
setblock 511 139 472 minecraft:terracotta
fill 511 139 473 511 142 473 minecraft:red_terracotta
setblock 511 139 477 minecraft:terracotta
fill 511 139 478 511 142 478 minecraft:red_terracotta
setblock 511 139 482 minecraft:terracotta
fill 511 139 483 511 142 483 minecraft:red_terracotta
setblock 511 139 487 minecraft:terracotta
fill 511 139 488 511 142 488 minecraft:red_terracotta
setblock 511 139 492 minecraft:terracotta
fill 511 139 493 511 142 493 minecraft:red_terracotta
setblock 511 139 497 minecraft:terracotta
fill 511 139 498 511 142 498 minecraft:red_terracotta
setblock 511 139 502 minecraft:terracotta
fill 511 139 503 511 142 503 minecraft:red_terracotta
setblock 471 140 471 minecraft:terracotta
fill 471 140 472 471 140 475 minecraft:red_terracotta
setblock 471 140 476 minecraft:terracotta
fill 471 140 477 471 140 480 minecraft:red_terracotta
setblock 471 140 481 minecraft:terracotta
fill 471 140 482 471 143 482 minecraft:red_terracotta
setblock 471 140 486 minecraft:terracotta
fill 471 140 487 471 143 487 minecraft:red_terracotta
setblock 471 140 491 minecraft:terracotta
fill 471 140 492 471 143 492 minecraft:red_terracotta
setblock 471 140 496 minecraft:terracotta
fill 471 140 497 471 143 497 minecraft:red_terracotta
setblock 471 140 501 minecraft:terracotta
fill 471 140 502 471 143 502 minecraft:red_terracotta
setblock 472 140 475 minecraft:terracotta
fill 472 140 476 472 143 476 minecraft:red_terracotta
setblock 472 140 479 minecraft:red_terracotta
setblock 472 140 480 minecraft:terracotta
fill 472 140 481 472 143 481 minecraft:red_terracotta
setblock 472 140 485 minecraft:terracotta
fill 472 140 486 472 143 486 minecraft:red_terracotta
setblock 472 140 490 minecraft:terracotta
fill 472 140 491 472 142 491 minecraft:red_terracotta
setblock 472 140 495 minecraft:terracotta
fill 472 140 496 472 143 496 minecraft:red_terracotta
setblock 472 140 500 minecraft:terracotta
fill 472 140 501 472 143 501 minecraft:red_terracotta
setblock 473 140 474 minecraft:terracotta
setblock 473 140 475 minecraft:red_terracotta
setblock 473 140 479 minecraft:terracotta
fill 473 140 480 473 143 480 minecraft:red_terracotta
setblock 473 140 494 minecraft:terracotta
fill 473 140 495 473 141 495 minecraft:red_terracotta
setblock 473 140 499 minecraft:terracotta
fill 473 140 500 473 141 500 minecraft:red_terracotta
setblock 473 140 504 minecraft:terracotta
setblock 474 140 503 minecraft:terracotta
fill 474 140 504 474 142 504 minecraft:red_terracotta
fill 486 140 504 487 140 504 minecraft:red_terracotta
setblock 488 140 464 minecraft:terracotta
fill 488 140 465 488 143 465 minecraft:red_terracotta
setblock 488 140 503 minecraft:red_terracotta
setblock 488 140 504 minecraft:terracotta
fill 489 140 464 489 143 464 minecraft:red_terracotta
setblock 489 140 503 minecraft:terracotta
fill 489 140 504 489 143 504 minecraft:red_terracotta
fill 490 140 503 490 143 503 minecraft:red_terracotta
setblock 492 140 465 minecraft:terracotta
setblock 493 140 464 minecraft:terracotta
fill 493 140 465 493 142 465 minecraft:red_terracotta
setblock 493 140 503 minecraft:red_terracotta
setblock 493 140 504 minecraft:terracotta
fill 494 140 464 494 143 464 minecraft:red_terracotta
setblock 494 140 503 minecraft:terracotta
fill 494 140 504 494 143 504 minecraft:red_terracotta
fill 495 140 503 495 143 503 minecraft:red_terracotta
setblock 498 140 464 minecraft:terracotta
setblock 498 140 504 minecraft:terracotta
fill 499 140 464 502 140 464 minecraft:red_terracotta
fill 499 140 504 502 140 504 minecraft:red_terracotta
fill 502 140 503 503 140 503 minecraft:red_terracotta
setblock 503 140 464 minecraft:terracotta
setblock 503 140 504 minecraft:terracotta
fill 504 140 464 504 143 464 minecraft:red_terracotta
setblock 504 140 502 minecraft:red_terracotta
setblock 504 140 503 minecraft:terracotta
fill 504 140 504 504 143 504 minecraft:red_terracotta
setblock 505 140 502 minecraft:terracotta
fill 505 140 503 505 143 503 minecraft:red_terracotta
setblock 506 140 501 minecraft:terracotta
fill 506 140 502 506 143 502 minecraft:red_terracotta
fill 507 140 501 507 143 501 minecraft:red_terracotta
setblock 508 140 464 minecraft:terracotta
setblock 508 140 495 minecraft:red_terracotta
setblock 508 140 498 minecraft:red_terracotta
setblock 508 140 499 minecraft:terracotta
fill 508 140 500 508 143 500 minecraft:red_terracotta
setblock 508 140 504 minecraft:terracotta
fill 509 140 464 509 143 464 minecraft:red_terracotta
setblock 509 140 492 minecraft:red_terracotta
setblock 509 140 493 minecraft:terracotta
fill 509 140 494 509 142 494 minecraft:red_terracotta
setblock 509 140 498 minecraft:terracotta
fill 509 140 499 509 143 499 minecraft:red_terracotta
setblock 509 140 503 minecraft:terracotta
fill 509 140 504 509 143 504 minecraft:red_terracotta
setblock 510 140 472 minecraft:terracotta
fill 510 140 473 510 141 473 minecraft:red_terracotta
setblock 510 140 477 minecraft:terracotta
fill 510 140 478 510 143 478 minecraft:red_terracotta
fill 510 140 480 510 140 481 minecraft:red_terracotta
setblock 510 140 482 minecraft:terracotta
fill 510 140 483 510 143 483 minecraft:red_terracotta
setblock 510 140 492 minecraft:terracotta
fill 510 140 493 510 143 493 minecraft:red_terracotta
setblock 510 140 497 minecraft:terracotta
fill 510 140 498 510 143 498 minecraft:red_terracotta
setblock 510 140 502 minecraft:terracotta
fill 510 140 503 510 143 503 minecraft:red_terracotta
setblock 511 140 466 minecraft:terracotta
fill 511 140 467 511 141 467 minecraft:red_terracotta
setblock 511 140 471 minecraft:terracotta
fill 511 140 472 511 142 472 minecraft:red_terracotta
setblock 511 140 476 minecraft:terracotta
fill 511 140 477 511 143 477 minecraft:red_terracotta
setblock 511 140 480 minecraft:red_terracotta
setblock 511 140 481 minecraft:terracotta
fill 511 140 482 511 143 482 minecraft:red_terracotta
setblock 511 140 486 minecraft:terracotta
fill 511 140 487 511 143 487 minecraft:red_terracotta
setblock 511 140 491 minecraft:terracotta
fill 511 140 492 511 143 492 minecraft:red_terracotta
setblock 511 140 496 minecraft:terracotta
fill 511 140 497 511 143 497 minecraft:red_terracotta
setblock 511 140 501 minecraft:terracotta
fill 511 140 502 511 143 502 minecraft:red_terracotta
setblock 471 141 470 minecraft:terracotta
fill 471 141 471 471 141 474 minecraft:red_terracotta
setblock 471 141 475 minecraft:terracotta
fill 471 141 476 471 141 479 minecraft:red_terracotta
setblock 471 141 480 minecraft:terracotta
fill 471 141 481 471 144 481 minecraft:red_terracotta
setblock 471 141 485 minecraft:terracotta
fill 471 141 486 471 144 486 minecraft:red_terracotta
setblock 471 141 490 minecraft:terracotta
fill 471 141 491 471 144 491 minecraft:red_terracotta
setblock 471 141 495 minecraft:terracotta
fill 471 141 496 471 144 496 minecraft:red_terracotta
setblock 471 141 500 minecraft:terracotta
fill 471 141 501 471 144 501 minecraft:red_terracotta
setblock 472 141 474 minecraft:terracotta
fill 472 141 475 472 143 475 minecraft:red_terracotta
setblock 472 141 479 minecraft:terracotta
fill 472 141 480 472 144 480 minecraft:red_terracotta
setblock 472 141 483 minecraft:red_terracotta
setblock 472 141 484 minecraft:terracotta
fill 472 141 485 472 144 485 minecraft:red_terracotta
setblock 472 141 489 minecraft:terracotta
fill 472 141 490 472 142 490 minecraft:red_terracotta
setblock 472 141 494 minecraft:terracotta
fill 472 141 495 472 143 495 minecraft:red_terracotta
setblock 472 141 499 minecraft:terracotta
fill 472 141 500 472 144 500 minecraft:red_terracotta
setblock 472 141 504 minecraft:terracotta
setblock 473 141 466 minecraft:light[level=14]
setblock 473 141 474 minecraft:light[level=14]
setblock 473 141 478 minecraft:terracotta
fill 473 141 479 473 143 479 minecraft:red_terracotta
setblock 473 141 483 minecraft:terracotta
setblock 473 141 490 minecraft:light[level=14]
setblock 473 141 494 minecraft:red_terracotta
setblock 473 141 498 minecraft:terracotta
fill 473 141 499 473 142 499 minecraft:red_terracotta
setblock 473 141 503 minecraft:terracotta
fill 473 141 504 473 144 504 minecraft:red_terracotta
setblock 481 141 466 minecraft:light[level=14]
setblock 481 141 474 minecraft:light[level=14]
setblock 481 141 482 minecraft:light[level=14]
setblock 481 141 490 minecraft:light[level=14]
setblock 481 141 498 minecraft:light[level=14]
fill 485 141 464 485 142 464 minecraft:red_terracotta
fill 485 141 504 486 141 504 minecraft:red_terracotta
setblock 487 141 464 minecraft:terracotta
fill 487 141 465 487 144 465 minecraft:red_terracotta
setblock 487 141 503 minecraft:red_terracotta
setblock 487 141 504 minecraft:terracotta
fill 488 141 464 488 144 464 minecraft:red_terracotta
setblock 488 141 503 minecraft:terracotta
fill 488 141 504 488 144 504 minecraft:red_terracotta
setblock 489 141 466 minecraft:light[level=14]
setblock 489 141 474 minecraft:light[level=14]
setblock 489 141 482 minecraft:light[level=14]
setblock 489 141 490 minecraft:light[level=14]
setblock 489 141 498 minecraft:light[level=14]
fill 489 141 503 489 144 503 minecraft:red_terracotta
setblock 491 141 465 minecraft:terracotta
setblock 492 141 464 minecraft:terracotta
fill 492 141 465 492 144 465 minecraft:red_terracotta
setblock 492 141 504 minecraft:terracotta
fill 493 141 464 493 144 464 minecraft:red_terracotta
setblock 493 141 503 minecraft:terracotta
fill 493 141 504 493 144 504 minecraft:red_terracotta
fill 494 141 503 494 144 503 minecraft:red_terracotta
setblock 497 141 464 minecraft:terracotta
setblock 497 141 466 minecraft:light[level=14]
setblock 497 141 474 minecraft:light[level=14]
setblock 497 141 482 minecraft:light[level=14]
setblock 497 141 490 minecraft:light[level=14]
setblock 497 141 498 minecraft:light[level=14]
setblock 497 141 504 minecraft:terracotta
fill 498 141 464 499 141 464 minecraft:red_terracotta
fill 498 141 504 501 141 504 minecraft:red_terracotta
fill 501 141 503 502 141 503 minecraft:red_terracotta
setblock 502 141 464 minecraft:terracotta
setblock 502 141 504 minecraft:terracotta
fill 503 141 464 503 144 464 minecraft:red_terracotta
setblock 503 141 503 minecraft:terracotta
fill 503 141 504 503 144 504 minecraft:red_terracotta
setblock 504 141 502 minecraft:terracotta
fill 504 141 503 504 144 503 minecraft:red_terracotta
setblock 505 141 466 minecraft:light[level=14]
setblock 505 141 474 minecraft:light[level=14]
setblock 505 141 482 minecraft:light[level=14]
setblock 505 141 490 minecraft:light[level=14]
setblock 505 141 498 minecraft:light[level=14]
fill 505 141 502 505 144 502 minecraft:red_terracotta
fill 506 141 501 506 144 501 minecraft:red_terracotta
setblock 507 141 464 minecraft:terracotta
setblock 507 141 504 minecraft:terracotta
fill 508 141 464 508 144 464 minecraft:red_terracotta
setblock 508 141 498 minecraft:terracotta
fill 508 141 499 508 144 499 minecraft:red_terracotta
setblock 508 141 503 minecraft:terracotta
fill 508 141 504 508 144 504 minecraft:red_terracotta
setblock 509 141 493 minecraft:red_terracotta
setblock 509 141 497 minecraft:terracotta
fill 509 141 498 509 144 498 minecraft:red_terracotta
setblock 509 141 502 minecraft:terracotta
fill 509 141 503 509 144 503 minecraft:red_terracotta
setblock 510 141 476 minecraft:terracotta
fill 510 141 477 510 143 477 minecraft:red_terracotta
setblock 510 141 480 minecraft:red_terracotta
setblock 510 141 481 minecraft:terracotta
fill 510 141 482 510 144 482 minecraft:red_terracotta
fill 510 141 484 510 142 484 minecraft:red_terracotta
setblock 510 141 491 minecraft:terracotta
fill 510 141 492 510 143 492 minecraft:red_terracotta
setblock 510 141 496 minecraft:terracotta
fill 510 141 497 510 144 497 minecraft:red_terracotta
setblock 510 141 501 minecraft:terracotta
fill 510 141 502 510 144 502 minecraft:red_terracotta
setblock 511 141 465 minecraft:terracotta
setblock 511 141 466 minecraft:red_terracotta
setblock 511 141 470 minecraft:terracotta
setblock 511 141 471 minecraft:red_terracotta
setblock 511 141 475 minecraft:terracotta
fill 511 141 476 511 144 476 minecraft:red_terracotta
setblock 511 141 480 minecraft:terracotta
fill 511 141 481 511 144 481 minecraft:red_terracotta
setblock 511 141 485 minecraft:terracotta
fill 511 141 486 511 144 486 minecraft:red_terracotta
setblock 511 141 490 minecraft:terracotta
fill 511 141 491 511 144 491 minecraft:red_terracotta
setblock 511 141 495 minecraft:terracotta
fill 511 141 496 511 144 496 minecraft:red_terracotta
setblock 511 141 500 minecraft:terracotta
fill 511 141 501 511 144 501 minecraft:red_terracotta
fill 471 142 471 471 142 473 minecraft:red_terracotta
setblock 471 142 474 minecraft:terracotta
fill 471 142 475 471 142 478 minecraft:red_terracotta
setblock 471 142 479 minecraft:terracotta
fill 471 142 480 471 145 480 minecraft:red_terracotta
setblock 471 142 484 minecraft:terracotta
fill 471 142 485 471 145 485 minecraft:red_terracotta
setblock 471 142 489 minecraft:terracotta
fill 471 142 490 471 145 490 minecraft:red_terracotta
setblock 471 142 494 minecraft:terracotta
fill 471 142 495 471 145 495 minecraft:red_terracotta
setblock 471 142 499 minecraft:terracotta
fill 471 142 500 471 145 500 minecraft:red_terracotta
setblock 471 142 504 minecraft:terracotta
setblock 472 142 474 minecraft:red_terracotta
setblock 472 142 478 minecraft:terracotta
fill 472 142 479 472 145 479 minecraft:red_terracotta
setblock 472 142 483 minecraft:terracotta
fill 472 142 484 472 145 484 minecraft:red_terracotta
setblock 472 142 488 minecraft:terracotta
setblock 472 142 489 minecraft:red_terracotta
setblock 472 142 493 minecraft:terracotta
fill 472 142 494 472 143 494 minecraft:red_terracotta
setblock 472 142 498 minecraft:terracotta
fill 472 142 499 472 144 499 minecraft:red_terracotta
setblock 472 142 503 minecraft:terracotta
fill 472 142 504 472 145 504 minecraft:red_terracotta
setblock 473 142 477 minecraft:terracotta
setblock 473 142 478 minecraft:red_terracotta
setblock 473 142 482 minecraft:terracotta
setblock 473 142 483 minecraft:red_terracotta
setblock 473 142 498 minecraft:red_terracotta
setblock 473 142 503 minecraft:red_terracotta
setblock 485 142 504 minecraft:red_terracotta
setblock 486 142 464 minecraft:terracotta
setblock 486 142 504 minecraft:terracotta
fill 487 142 464 487 145 464 minecraft:red_terracotta
setblock 487 142 503 minecraft:terracotta
fill 487 142 504 487 145 504 minecraft:red_terracotta
fill 488 142 503 488 145 503 minecraft:red_terracotta
setblock 490 142 465 minecraft:terracotta
setblock 491 142 464 minecraft:terracotta
fill 491 142 465 491 145 465 minecraft:red_terracotta
setblock 491 142 504 minecraft:terracotta
fill 492 142 464 492 145 464 minecraft:red_terracotta
setblock 492 142 503 minecraft:terracotta
fill 492 142 504 492 145 504 minecraft:red_terracotta
fill 493 142 503 493 145 503 minecraft:red_terracotta
setblock 496 142 464 minecraft:terracotta
setblock 496 142 504 minecraft:terracotta
fill 497 142 464 498 142 464 minecraft:red_terracotta
fill 497 142 504 500 142 504 minecraft:red_terracotta
fill 500 142 503 501 142 503 minecraft:red_terracotta
setblock 501 142 504 minecraft:terracotta
fill 502 142 464 502 145 464 minecraft:red_terracotta
setblock 502 142 503 minecraft:terracotta
fill 502 142 504 502 145 504 minecraft:red_terracotta
setblock 503 142 502 minecraft:terracotta
fill 503 142 503 503 145 503 minecraft:red_terracotta
fill 504 142 502 504 145 502 minecraft:red_terracotta
setblock 506 142 464 minecraft:terracotta
setblock 506 142 504 minecraft:terracotta
fill 507 142 464 507 145 464 minecraft:red_terracotta
setblock 507 142 503 minecraft:terracotta
fill 507 142 504 507 145 504 minecraft:red_terracotta
setblock 508 142 497 minecraft:terracotta
fill 508 142 498 508 143 498 minecraft:red_terracotta
setblock 508 142 502 minecraft:terracotta
fill 508 142 503 508 145 503 minecraft:red_terracotta
setblock 509 142 496 minecraft:terracotta
fill 509 142 497 509 145 497 minecraft:red_terracotta
setblock 509 142 501 minecraft:terracotta
fill 509 142 502 509 145 502 minecraft:red_terracotta
setblock 510 142 475 minecraft:terracotta
fill 510 142 476 510 143 476 minecraft:red_terracotta
setblock 510 142 480 minecraft:terracotta
fill 510 142 481 510 145 481 minecraft:red_terracotta
setblock 510 142 485 minecraft:terracotta
setblock 510 142 490 minecraft:terracotta
fill 510 142 491 510 143 491 minecraft:red_terracotta
setblock 510 142 495 minecraft:terracotta
fill 510 142 496 510 145 496 minecraft:red_terracotta
setblock 510 142 500 minecraft:terracotta
fill 510 142 501 510 145 501 minecraft:red_terracotta
setblock 511 142 464 minecraft:terracotta
setblock 511 142 465 minecraft:red_terracotta
setblock 511 142 474 minecraft:terracotta
fill 511 142 475 511 144 475 minecraft:red_terracotta
setblock 511 142 479 minecraft:terracotta
fill 511 142 480 511 145 480 minecraft:red_terracotta
setblock 511 142 484 minecraft:terracotta
fill 511 142 485 511 145 485 minecraft:red_terracotta
setblock 511 142 489 minecraft:terracotta
fill 511 142 490 511 145 490 minecraft:red_terracotta
setblock 511 142 494 minecraft:terracotta
fill 511 142 495 511 145 495 minecraft:red_terracotta
setblock 511 142 499 minecraft:terracotta
fill 511 142 500 511 145 500 minecraft:red_terracotta
setblock 511 142 504 minecraft:terracotta
setblock 471 143 473 minecraft:terracotta
fill 471 143 474 471 143 477 minecraft:red_terracotta
setblock 471 143 478 minecraft:terracotta
fill 471 143 479 471 146 479 minecraft:red_terracotta
setblock 471 143 483 minecraft:terracotta
fill 471 143 484 471 146 484 minecraft:red_terracotta
setblock 471 143 488 minecraft:terracotta
fill 471 143 489 471 146 489 minecraft:red_terracotta
setblock 471 143 493 minecraft:terracotta
fill 471 143 494 471 146 494 minecraft:red_terracotta
setblock 471 143 498 minecraft:terracotta
fill 471 143 499 471 146 499 minecraft:red_terracotta
setblock 471 143 503 minecraft:terracotta
fill 471 143 504 471 146 504 minecraft:red_terracotta
setblock 472 143 477 minecraft:terracotta
fill 472 143 478 472 146 478 minecraft:red_terracotta
setblock 472 143 482 minecraft:terracotta
fill 472 143 483 472 146 483 minecraft:red_terracotta
setblock 472 143 487 minecraft:terracotta
setblock 472 143 497 minecraft:terracotta
fill 472 143 498 472 144 498 minecraft:red_terracotta
setblock 472 143 502 minecraft:terracotta
setblock 472 143 503 minecraft:red_terracotta
setblock 473 143 481 minecraft:terracotta
setblock 473 143 482 minecraft:red_terracotta
setblock 484 143 464 minecraft:red_terracotta
setblock 484 143 504 minecraft:red_terracotta
setblock 485 143 464 minecraft:terracotta
setblock 485 143 504 minecraft:terracotta
fill 486 143 464 486 146 464 minecraft:red_terracotta
setblock 486 143 503 minecraft:terracotta
fill 486 143 504 486 146 504 minecraft:red_terracotta
fill 487 143 503 487 146 503 minecraft:red_terracotta
setblock 489 143 465 minecraft:terracotta
setblock 490 143 464 minecraft:terracotta
fill 490 143 465 490 146 465 minecraft:red_terracotta
setblock 490 143 504 minecraft:terracotta
fill 491 143 464 491 146 464 minecraft:red_terracotta
setblock 491 143 503 minecraft:terracotta
fill 491 143 504 491 146 504 minecraft:red_terracotta
fill 492 143 503 492 146 503 minecraft:red_terracotta
setblock 495 143 464 minecraft:terracotta
setblock 495 143 504 minecraft:terracotta
fill 496 143 464 497 145 464 minecraft:red_terracotta
fill 496 143 504 499 143 504 minecraft:red_terracotta
setblock 500 143 503 minecraft:red_terracotta
setblock 500 143 504 minecraft:terracotta
setblock 501 143 503 minecraft:terracotta
fill 501 143 504 501 146 504 minecraft:red_terracotta
fill 502 143 503 502 146 503 minecraft:red_terracotta
fill 503 143 502 503 146 502 minecraft:red_terracotta
setblock 505 143 464 minecraft:terracotta
setblock 505 143 504 minecraft:terracotta
fill 506 143 464 506 146 464 minecraft:red_terracotta
setblock 506 143 503 minecraft:terracotta
fill 506 143 504 506 146 504 minecraft:red_terracotta
setblock 507 143 502 minecraft:terracotta
fill 507 143 503 507 146 503 minecraft:red_terracotta
setblock 508 143 501 minecraft:terracotta
fill 508 143 502 508 146 502 minecraft:red_terracotta
setblock 509 143 495 minecraft:terracotta
fill 509 143 496 509 144 496 minecraft:red_terracotta
setblock 509 143 500 minecraft:terracotta
fill 509 143 501 509 146 501 minecraft:red_terracotta
setblock 510 143 464 minecraft:terracotta
setblock 510 143 479 minecraft:terracotta
fill 510 143 480 510 146 480 minecraft:red_terracotta
setblock 510 143 484 minecraft:terracotta
fill 510 143 485 510 146 485 minecraft:red_terracotta
setblock 510 143 494 minecraft:terracotta
fill 510 143 495 510 146 495 minecraft:red_terracotta
setblock 510 143 499 minecraft:terracotta
fill 510 143 500 510 146 500 minecraft:red_terracotta
setblock 510 143 504 minecraft:terracotta
fill 511 143 464 511 146 464 minecraft:red_terracotta
setblock 511 143 474 minecraft:red_terracotta
setblock 511 143 478 minecraft:terracotta
fill 511 143 479 511 146 479 minecraft:red_terracotta
setblock 511 143 483 minecraft:terracotta
fill 511 143 484 511 146 484 minecraft:red_terracotta
setblock 511 143 488 minecraft:terracotta
fill 511 143 489 511 146 489 minecraft:red_terracotta
setblock 511 143 493 minecraft:terracotta
fill 511 143 494 511 146 494 minecraft:red_terracotta
setblock 511 143 498 minecraft:terracotta
fill 511 143 499 511 146 499 minecraft:red_terracotta
setblock 511 143 503 minecraft:terracotta
fill 511 143 504 511 146 504 minecraft:red_terracotta
fill 471 144 474 471 144 476 minecraft:red_terracotta
setblock 471 144 477 minecraft:terracotta
fill 471 144 478 471 147 478 minecraft:red_terracotta
setblock 471 144 482 minecraft:terracotta
fill 471 144 483 471 147 483 minecraft:red_terracotta
setblock 471 144 487 minecraft:terracotta
fill 471 144 488 471 147 488 minecraft:red_terracotta
setblock 471 144 492 minecraft:terracotta
fill 471 144 493 471 145 493 minecraft:red_terracotta
setblock 471 144 497 minecraft:terracotta
fill 471 144 498 471 147 498 minecraft:red_terracotta
setblock 471 144 502 minecraft:terracotta
fill 471 144 503 471 147 503 minecraft:red_terracotta
setblock 472 144 476 minecraft:terracotta
fill 472 144 477 472 145 477 minecraft:red_terracotta
setblock 472 144 481 minecraft:terracotta
fill 472 144 482 472 147 482 minecraft:red_terracotta
setblock 472 144 486 minecraft:terracotta
setblock 472 144 497 minecraft:red_terracotta
setblock 472 144 501 minecraft:terracotta
setblock 472 144 502 minecraft:red_terracotta
setblock 483 144 464 minecraft:red_terracotta
setblock 483 144 504 minecraft:red_terracotta
setblock 484 144 464 minecraft:terracotta
setblock 484 144 504 minecraft:terracotta
fill 485 144 464 485 147 464 minecraft:red_terracotta
fill 485 144 504 485 147 504 minecraft:red_terracotta
fill 486 144 465 486 145 465 minecraft:red_terracotta
fill 486 144 503 486 147 503 minecraft:red_terracotta
setblock 488 144 465 minecraft:terracotta
setblock 489 144 464 minecraft:terracotta
fill 489 144 465 489 147 465 minecraft:red_terracotta
setblock 489 144 504 minecraft:terracotta
fill 490 144 464 490 147 464 minecraft:red_terracotta
setblock 490 144 503 minecraft:terracotta
fill 490 144 504 490 147 504 minecraft:red_terracotta
fill 491 144 503 491 147 503 minecraft:red_terracotta
setblock 494 144 464 minecraft:terracotta
setblock 494 144 504 minecraft:terracotta
fill 495 144 464 495 147 464 minecraft:red_terracotta
fill 495 144 504 498 144 504 minecraft:red_terracotta
setblock 499 144 504 minecraft:terracotta
setblock 500 144 503 minecraft:terracotta
fill 500 144 504 500 147 504 minecraft:red_terracotta
fill 501 144 464 501 146 464 minecraft:red_terracotta
fill 501 144 503 501 147 503 minecraft:red_terracotta
setblock 504 144 464 minecraft:terracotta
setblock 504 144 504 minecraft:terracotta
fill 505 144 464 505 147 464 minecraft:red_terracotta
setblock 505 144 503 minecraft:terracotta
fill 505 144 504 505 147 504 minecraft:red_terracotta
setblock 506 144 502 minecraft:terracotta
fill 506 144 503 506 147 503 minecraft:red_terracotta
setblock 507 144 501 minecraft:terracotta
fill 507 144 502 507 147 502 minecraft:red_terracotta
setblock 508 144 500 minecraft:terracotta
fill 508 144 501 508 146 501 minecraft:red_terracotta
setblock 509 144 464 minecraft:terracotta
setblock 509 144 499 minecraft:terracotta
fill 509 144 500 509 147 500 minecraft:red_terracotta
setblock 509 144 504 minecraft:terracotta
fill 510 144 464 510 147 464 minecraft:red_terracotta
setblock 510 144 478 minecraft:terracotta
fill 510 144 479 510 145 479 minecraft:red_terracotta
setblock 510 144 483 minecraft:terracotta
fill 510 144 484 510 147 484 minecraft:red_terracotta
setblock 510 144 493 minecraft:terracotta
fill 510 144 494 510 145 494 minecraft:red_terracotta
setblock 510 144 498 minecraft:terracotta
fill 510 144 499 510 147 499 minecraft:red_terracotta
setblock 510 144 503 minecraft:terracotta
fill 510 144 504 510 147 504 minecraft:red_terracotta
setblock 511 144 477 minecraft:terracotta
fill 511 144 478 511 147 478 minecraft:red_terracotta
setblock 511 144 482 minecraft:terracotta
fill 511 144 483 511 147 483 minecraft:red_terracotta
setblock 511 144 487 minecraft:terracotta
fill 511 144 488 511 147 488 minecraft:red_terracotta
setblock 511 144 492 minecraft:terracotta
fill 511 144 493 511 147 493 minecraft:red_terracotta
setblock 511 144 497 minecraft:terracotta
fill 511 144 498 511 147 498 minecraft:red_terracotta
setblock 511 144 502 minecraft:terracotta
fill 511 144 503 511 147 503 minecraft:red_terracotta
setblock 471 145 475 minecraft:red_terracotta
setblock 471 145 476 minecraft:terracotta
fill 471 145 477 471 148 477 minecraft:red_terracotta
setblock 471 145 481 minecraft:terracotta
fill 471 145 482 471 148 482 minecraft:red_terracotta
setblock 471 145 486 minecraft:terracotta
fill 471 145 487 471 148 487 minecraft:red_terracotta
setblock 471 145 491 minecraft:terracotta
fill 471 145 492 471 146 492 minecraft:red_terracotta
setblock 471 145 496 minecraft:terracotta
fill 471 145 497 471 147 497 minecraft:red_terracotta
setblock 471 145 501 minecraft:terracotta
fill 471 145 502 471 148 502 minecraft:red_terracotta
setblock 472 145 480 minecraft:terracotta
fill 472 145 481 472 148 481 minecraft:red_terracotta
setblock 472 145 485 minecraft:terracotta
fill 472 145 486 472 148 486 minecraft:red_terracotta
setblock 483 145 464 minecraft:terracotta
setblock 483 145 504 minecraft:terracotta
fill 484 145 464 484 148 464 minecraft:red_terracotta
fill 484 145 504 484 148 504 minecraft:red_terracotta
fill 485 145 465 485 146 465 minecraft:red_terracotta
fill 485 145 503 485 148 503 minecraft:red_terracotta
setblock 487 145 465 minecraft:terracotta
setblock 488 145 464 minecraft:terracotta
fill 488 145 465 488 148 465 minecraft:red_terracotta
setblock 488 145 504 minecraft:terracotta
fill 489 145 464 489 148 464 minecraft:red_terracotta
setblock 489 145 503 minecraft:terracotta
fill 489 145 504 489 148 504 minecraft:red_terracotta
fill 490 145 503 490 148 503 minecraft:red_terracotta
setblock 492 145 465 minecraft:terracotta
setblock 493 145 464 minecraft:terracotta
setblock 493 145 504 minecraft:terracotta
fill 494 145 464 494 148 464 minecraft:red_terracotta
fill 494 145 504 497 145 504 minecraft:red_terracotta
setblock 498 145 464 minecraft:terracotta
setblock 498 145 504 minecraft:terracotta
fill 499 145 464 500 147 464 minecraft:red_terracotta
setblock 499 145 503 minecraft:terracotta
fill 499 145 504 499 148 504 minecraft:red_terracotta
schedule function dropper:buildpart/118_5 1t
