fill 474 207 502 474 210 502 minecraft:red_terracotta
setblock 476 207 464 minecraft:terracotta
setblock 476 207 504 minecraft:terracotta
fill 477 207 464 478 209 464 minecraft:red_terracotta
setblock 477 207 503 minecraft:terracotta
fill 477 207 504 477 210 504 minecraft:red_terracotta
fill 478 207 503 478 208 503 minecraft:red_terracotta
fill 487 207 464 487 210 464 minecraft:red_terracotta
fill 488 207 504 490 207 504 minecraft:red_terracotta
setblock 489 207 465 minecraft:red_terracotta
setblock 490 207 465 minecraft:terracotta
fill 490 207 503 491 207 503 minecraft:red_terracotta
setblock 491 207 464 minecraft:terracotta
fill 491 207 465 491 210 465 minecraft:red_terracotta
setblock 491 207 504 minecraft:terracotta
fill 492 207 464 492 210 464 minecraft:red_terracotta
fill 492 207 466 493 207 466 minecraft:red_terracotta
setblock 492 207 503 minecraft:terracotta
fill 492 207 504 492 210 504 minecraft:red_terracotta
fill 493 207 503 493 210 503 minecraft:red_terracotta
setblock 494 207 466 minecraft:terracotta
setblock 495 207 465 minecraft:terracotta
fill 495 207 466 497 208 466 minecraft:red_terracotta
fill 495 207 502 496 208 502 minecraft:red_terracotta
setblock 496 207 464 minecraft:terracotta
fill 496 207 465 496 210 465 minecraft:red_terracotta
setblock 496 207 504 minecraft:terracotta
fill 497 207 464 497 210 464 minecraft:red_terracotta
setblock 497 207 503 minecraft:terracotta
fill 497 207 504 497 210 504 minecraft:red_terracotta
fill 498 207 503 498 210 503 minecraft:red_terracotta
setblock 500 207 465 minecraft:terracotta
setblock 501 207 464 minecraft:terracotta
fill 501 207 465 501 210 465 minecraft:red_terracotta
setblock 501 207 504 minecraft:terracotta
fill 502 207 464 505 207 464 minecraft:red_terracotta
setblock 502 207 503 minecraft:terracotta
fill 502 207 504 502 210 504 minecraft:red_terracotta
fill 503 207 503 503 210 503 minecraft:red_terracotta
setblock 506 207 464 minecraft:terracotta
setblock 506 207 503 minecraft:red_terracotta
setblock 506 207 504 minecraft:terracotta
fill 507 207 464 507 210 464 minecraft:red_terracotta
setblock 507 207 503 minecraft:terracotta
fill 507 207 504 507 210 504 minecraft:red_terracotta
setblock 508 207 502 minecraft:terracotta
fill 508 207 503 508 210 503 minecraft:red_terracotta
setblock 509 207 501 minecraft:terracotta
fill 509 207 502 509 210 502 minecraft:red_terracotta
setblock 510 207 465 minecraft:terracotta
fill 510 207 497 510 209 497 minecraft:red_terracotta
setblock 510 207 500 minecraft:terracotta
fill 510 207 501 510 210 501 minecraft:red_terracotta
setblock 511 207 464 minecraft:terracotta
fill 511 207 465 511 210 465 minecraft:red_terracotta
fill 511 207 467 511 208 467 minecraft:red_terracotta
fill 511 207 477 511 207 478 minecraft:red_terracotta
setblock 511 207 479 minecraft:terracotta
fill 511 207 480 511 210 480 minecraft:red_terracotta
fill 511 207 482 511 207 483 minecraft:red_terracotta
setblock 511 207 484 minecraft:terracotta
fill 511 207 485 511 210 485 minecraft:red_terracotta
setblock 511 207 489 minecraft:terracotta
fill 511 207 490 511 208 492 minecraft:red_terracotta
setblock 511 207 494 minecraft:terracotta
fill 511 207 495 511 210 495 minecraft:red_terracotta
setblock 511 207 499 minecraft:terracotta
fill 511 207 500 511 210 500 minecraft:red_terracotta
setblock 511 207 504 minecraft:terracotta
fill 471 208 464 471 211 464 minecraft:red_terracotta
setblock 471 208 467 minecraft:red_terracotta
fill 471 208 475 471 210 475 minecraft:red_terracotta
setblock 471 208 478 minecraft:terracotta
fill 471 208 479 471 211 479 minecraft:red_terracotta
setblock 471 208 483 minecraft:terracotta
fill 471 208 484 471 211 484 minecraft:red_terracotta
setblock 471 208 487 minecraft:red_terracotta
setblock 471 208 488 minecraft:terracotta
fill 471 208 489 471 211 489 minecraft:red_terracotta
setblock 471 208 493 minecraft:terracotta
fill 471 208 494 471 211 494 minecraft:red_terracotta
setblock 471 208 498 minecraft:terracotta
fill 471 208 499 471 211 499 minecraft:red_terracotta
setblock 471 208 503 minecraft:terracotta
fill 471 208 504 471 211 504 minecraft:red_terracotta
fill 472 208 465 473 208 465 minecraft:red_terracotta
setblock 472 208 477 minecraft:terracotta
fill 472 208 478 472 211 478 minecraft:red_terracotta
setblock 472 208 481 minecraft:red_terracotta
setblock 472 208 482 minecraft:terracotta
fill 472 208 483 472 211 483 minecraft:red_terracotta
setblock 472 208 487 minecraft:terracotta
fill 472 208 488 472 211 488 minecraft:red_terracotta
setblock 472 208 492 minecraft:terracotta
fill 472 208 493 472 211 493 minecraft:red_terracotta
setblock 472 208 497 minecraft:terracotta
fill 472 208 498 472 211 498 minecraft:red_terracotta
setblock 472 208 502 minecraft:terracotta
fill 472 208 503 472 211 503 minecraft:red_terracotta
setblock 473 208 481 minecraft:terracotta
fill 473 208 482 473 211 482 minecraft:red_terracotta
setblock 473 208 486 minecraft:terracotta
fill 473 208 487 474 210 487 minecraft:red_terracotta
setblock 473 208 490 minecraft:red_terracotta
setblock 473 208 491 minecraft:terracotta
setblock 473 208 501 minecraft:terracotta
fill 473 208 502 473 211 502 minecraft:red_terracotta
setblock 474 208 464 minecraft:red_terracotta
setblock 474 208 465 minecraft:terracotta
fill 474 208 481 474 211 481 minecraft:red_terracotta
setblock 474 208 484 minecraft:red_terracotta
setblock 474 208 485 minecraft:terracotta
fill 474 208 486 474 211 486 minecraft:red_terracotta
setblock 475 208 464 minecraft:terracotta
setblock 475 208 504 minecraft:terracotta
fill 476 208 464 476 211 464 minecraft:red_terracotta
setblock 476 208 503 minecraft:terracotta
fill 476 208 504 476 211 504 minecraft:red_terracotta
fill 477 208 503 477 210 503 minecraft:red_terracotta
setblock 479 208 464 minecraft:red_terracotta
setblock 480 208 504 minecraft:terracotta
setblock 485 208 464 minecraft:terracotta
fill 486 208 464 486 211 464 minecraft:red_terracotta
fill 486 208 504 489 208 504 minecraft:red_terracotta
setblock 488 208 465 minecraft:red_terracotta
setblock 489 208 465 minecraft:terracotta
fill 489 208 503 490 208 503 minecraft:red_terracotta
setblock 490 208 464 minecraft:terracotta
fill 490 208 465 490 210 466 minecraft:red_terracotta
setblock 490 208 504 minecraft:terracotta
fill 491 208 464 491 211 464 minecraft:red_terracotta
fill 491 208 466 492 208 466 minecraft:red_terracotta
setblock 491 208 503 minecraft:terracotta
fill 491 208 504 491 211 504 minecraft:red_terracotta
fill 492 208 503 492 211 503 minecraft:red_terracotta
setblock 493 208 466 minecraft:terracotta
fill 493 208 502 494 210 502 minecraft:red_terracotta
setblock 494 208 465 minecraft:terracotta
fill 494 208 466 494 211 466 minecraft:red_terracotta
setblock 495 208 464 minecraft:terracotta
fill 495 208 465 495 211 465 minecraft:red_terracotta
setblock 495 208 504 minecraft:terracotta
fill 496 208 464 496 211 464 minecraft:red_terracotta
setblock 496 208 503 minecraft:terracotta
fill 496 208 504 496 211 504 minecraft:red_terracotta
fill 497 208 503 497 211 503 minecraft:red_terracotta
setblock 498 208 466 minecraft:terracotta
setblock 499 208 465 minecraft:terracotta
setblock 500 208 464 minecraft:terracotta
fill 500 208 465 500 211 465 minecraft:red_terracotta
setblock 500 208 504 minecraft:terracotta
fill 501 208 464 504 208 464 minecraft:red_terracotta
setblock 501 208 503 minecraft:terracotta
fill 501 208 504 501 211 504 minecraft:red_terracotta
fill 502 208 465 502 209 465 minecraft:red_terracotta
fill 502 208 503 502 211 503 minecraft:red_terracotta
setblock 505 208 464 minecraft:terracotta
setblock 505 208 504 minecraft:terracotta
fill 506 208 464 506 211 464 minecraft:red_terracotta
setblock 506 208 503 minecraft:terracotta
fill 506 208 504 506 211 504 minecraft:red_terracotta
fill 507 208 465 508 208 465 minecraft:red_terracotta
setblock 507 208 502 minecraft:terracotta
fill 507 208 503 507 211 503 minecraft:red_terracotta
fill 508 208 502 508 211 502 minecraft:red_terracotta
setblock 509 208 465 minecraft:terracotta
setblock 509 208 500 minecraft:terracotta
fill 509 208 501 509 211 501 minecraft:red_terracotta
setblock 510 208 464 minecraft:terracotta
fill 510 208 465 510 210 466 minecraft:red_terracotta
fill 510 208 481 510 208 483 minecraft:red_terracotta
setblock 510 208 484 minecraft:terracotta
fill 510 208 485 510 209 487 minecraft:red_terracotta
fill 510 208 496 510 210 496 minecraft:red_terracotta
setblock 510 208 499 minecraft:terracotta
fill 510 208 500 510 211 500 minecraft:red_terracotta
setblock 510 208 504 minecraft:terracotta
fill 511 208 464 511 211 464 minecraft:red_terracotta
setblock 511 208 468 minecraft:terracotta
fill 511 208 469 511 211 469 minecraft:red_terracotta
setblock 511 208 477 minecraft:red_terracotta
setblock 511 208 478 minecraft:terracotta
fill 511 208 479 511 211 479 minecraft:red_terracotta
setblock 511 208 482 minecraft:red_terracotta
setblock 511 208 483 minecraft:terracotta
fill 511 208 484 511 211 484 minecraft:red_terracotta
fill 511 208 486 511 208 487 minecraft:red_terracotta
setblock 511 208 488 minecraft:terracotta
fill 511 208 489 511 211 489 minecraft:red_terracotta
setblock 511 208 493 minecraft:terracotta
fill 511 208 494 511 211 494 minecraft:red_terracotta
setblock 511 208 498 minecraft:terracotta
fill 511 208 499 511 211 499 minecraft:red_terracotta
setblock 511 208 503 minecraft:terracotta
fill 511 208 504 511 211 504 minecraft:red_terracotta
setblock 471 209 467 minecraft:terracotta
fill 471 209 468 471 210 470 minecraft:red_terracotta
fill 471 209 474 471 211 474 minecraft:red_terracotta
setblock 471 209 477 minecraft:terracotta
fill 471 209 478 471 212 478 minecraft:red_terracotta
setblock 471 209 482 minecraft:terracotta
fill 471 209 483 471 212 483 minecraft:red_terracotta
setblock 471 209 487 minecraft:terracotta
fill 471 209 488 471 212 488 minecraft:red_terracotta
setblock 471 209 491 minecraft:red_terracotta
setblock 471 209 492 minecraft:terracotta
fill 471 209 493 471 212 493 minecraft:red_terracotta
setblock 471 209 497 minecraft:terracotta
fill 471 209 498 471 212 498 minecraft:red_terracotta
setblock 471 209 502 minecraft:terracotta
fill 471 209 503 471 212 503 minecraft:red_terracotta
setblock 472 209 465 minecraft:red_terracotta
setblock 472 209 466 minecraft:terracotta
setblock 472 209 476 minecraft:terracotta
fill 472 209 477 472 212 477 minecraft:red_terracotta
setblock 472 209 481 minecraft:terracotta
fill 472 209 482 472 212 482 minecraft:red_terracotta
setblock 472 209 485 minecraft:red_terracotta
setblock 472 209 486 minecraft:terracotta
fill 472 209 487 472 212 487 minecraft:red_terracotta
setblock 472 209 491 minecraft:terracotta
fill 472 209 492 473 211 492 minecraft:red_terracotta
setblock 472 209 496 minecraft:terracotta
fill 472 209 497 472 212 497 minecraft:red_terracotta
setblock 472 209 501 minecraft:terracotta
fill 472 209 502 472 212 502 minecraft:red_terracotta
setblock 473 209 465 minecraft:terracotta
fill 473 209 478 473 210 478 minecraft:red_terracotta
setblock 473 209 480 minecraft:terracotta
fill 473 209 481 473 212 481 minecraft:red_terracotta
setblock 473 209 485 minecraft:terracotta
fill 473 209 486 473 212 486 minecraft:red_terracotta
setblock 473 209 490 minecraft:terracotta
fill 473 209 491 473 212 491 minecraft:red_terracotta
setblock 473 209 500 minecraft:terracotta
fill 473 209 501 473 210 501 minecraft:red_terracotta
setblock 474 209 464 minecraft:terracotta
fill 474 209 465 476 210 465 minecraft:red_terracotta
setblock 474 209 480 minecraft:red_terracotta
setblock 474 209 484 minecraft:terracotta
fill 474 209 485 474 212 485 minecraft:red_terracotta
setblock 474 209 488 minecraft:red_terracotta
setblock 474 209 504 minecraft:terracotta
fill 475 209 464 475 212 464 minecraft:red_terracotta
setblock 475 209 503 minecraft:terracotta
fill 475 209 504 475 212 504 minecraft:red_terracotta
fill 476 209 503 476 211 503 minecraft:red_terracotta
setblock 479 209 464 minecraft:terracotta
setblock 479 209 504 minecraft:terracotta
fill 480 209 464 483 209 464 minecraft:red_terracotta
fill 480 209 504 480 210 504 minecraft:red_terracotta
setblock 484 209 464 minecraft:terracotta
fill 485 209 464 485 212 464 minecraft:red_terracotta
fill 485 209 504 488 209 504 minecraft:red_terracotta
fill 486 209 465 487 209 465 minecraft:red_terracotta
setblock 488 209 464 minecraft:red_terracotta
setblock 488 209 465 minecraft:terracotta
setblock 489 209 464 minecraft:terracotta
fill 489 209 465 489 211 466 minecraft:red_terracotta
setblock 489 209 503 minecraft:red_terracotta
setblock 489 209 504 minecraft:terracotta
fill 490 209 464 490 212 464 minecraft:red_terracotta
setblock 490 209 503 minecraft:terracotta
fill 490 209 504 490 212 504 minecraft:red_terracotta
setblock 491 209 466 minecraft:red_terracotta
fill 491 209 503 491 212 503 minecraft:red_terracotta
setblock 492 209 466 minecraft:terracotta
fill 492 209 467 494 210 467 minecraft:red_terracotta
fill 492 209 502 492 211 502 minecraft:red_terracotta
setblock 493 209 465 minecraft:terracotta
fill 493 209 466 493 212 466 minecraft:red_terracotta
setblock 494 209 464 minecraft:terracotta
fill 494 209 465 494 212 465 minecraft:red_terracotta
setblock 494 209 504 minecraft:terracotta
fill 495 209 464 495 212 464 minecraft:red_terracotta
fill 495 209 466 496 209 466 minecraft:red_terracotta
setblock 495 209 502 minecraft:red_terracotta
setblock 495 209 503 minecraft:terracotta
fill 495 209 504 495 212 504 minecraft:red_terracotta
setblock 496 209 502 minecraft:terracotta
fill 496 209 503 496 212 503 minecraft:red_terracotta
setblock 497 209 466 minecraft:terracotta
setblock 498 209 465 minecraft:terracotta
fill 498 209 466 498 212 466 minecraft:red_terracotta
setblock 499 209 464 minecraft:terracotta
fill 499 209 465 499 212 465 minecraft:red_terracotta
setblock 499 209 504 minecraft:terracotta
fill 500 209 464 503 209 464 minecraft:red_terracotta
setblock 500 209 503 minecraft:terracotta
fill 500 209 504 500 212 504 minecraft:red_terracotta
fill 501 209 503 501 212 503 minecraft:red_terracotta
setblock 503 209 465 minecraft:terracotta
setblock 504 209 464 minecraft:terracotta
fill 504 209 465 507 209 465 minecraft:red_terracotta
setblock 504 209 503 minecraft:red_terracotta
setblock 504 209 504 minecraft:terracotta
fill 505 209 464 505 212 464 minecraft:red_terracotta
setblock 505 209 503 minecraft:terracotta
fill 505 209 504 505 212 504 minecraft:red_terracotta
fill 506 209 503 506 212 503 minecraft:red_terracotta
fill 507 209 502 507 212 502 minecraft:red_terracotta
setblock 508 209 465 minecraft:terracotta
setblock 509 209 464 minecraft:terracotta
fill 509 209 465 509 212 465 minecraft:red_terracotta
setblock 509 209 499 minecraft:terracotta
fill 509 209 500 509 212 500 minecraft:red_terracotta
setblock 509 209 504 minecraft:terracotta
fill 510 209 464 510 212 464 minecraft:red_terracotta
setblock 510 209 467 minecraft:red_terracotta
fill 510 209 480 510 209 482 minecraft:red_terracotta
setblock 510 209 483 minecraft:terracotta
fill 510 209 484 510 212 484 minecraft:red_terracotta
setblock 510 209 488 minecraft:terracotta
fill 510 209 489 510 209 492 minecraft:red_terracotta
setblock 510 209 493 minecraft:terracotta
fill 510 209 494 510 211 495 minecraft:red_terracotta
setblock 510 209 498 minecraft:terracotta
fill 510 209 499 510 212 499 minecraft:red_terracotta
setblock 510 209 503 minecraft:terracotta
fill 510 209 504 510 212 504 minecraft:red_terracotta
setblock 511 209 467 minecraft:terracotta
fill 511 209 468 511 212 468 minecraft:red_terracotta
fill 511 209 470 511 210 470 minecraft:red_terracotta
setblock 511 209 476 minecraft:red_terracotta
setblock 511 209 477 minecraft:terracotta
fill 511 209 478 511 212 478 minecraft:red_terracotta
setblock 511 209 482 minecraft:terracotta
fill 511 209 483 511 212 483 minecraft:red_terracotta
setblock 511 209 486 minecraft:red_terracotta
setblock 511 209 487 minecraft:terracotta
fill 511 209 488 511 212 488 minecraft:red_terracotta
fill 511 209 490 511 209 491 minecraft:red_terracotta
setblock 511 209 492 minecraft:terracotta
fill 511 209 493 511 212 493 minecraft:red_terracotta
setblock 511 209 497 minecraft:terracotta
fill 511 209 498 511 212 498 minecraft:red_terracotta
setblock 511 209 502 minecraft:terracotta
fill 511 209 503 511 212 503 minecraft:red_terracotta
setblock 471 210 465 minecraft:red_terracotta
setblock 471 210 466 minecraft:terracotta
fill 471 210 467 472 212 467 minecraft:red_terracotta
setblock 471 210 471 minecraft:terracotta
fill 471 210 472 471 212 473 minecraft:red_terracotta
setblock 471 210 476 minecraft:terracotta
fill 471 210 477 471 213 477 minecraft:red_terracotta
setblock 471 210 481 minecraft:terracotta
fill 471 210 482 471 213 482 minecraft:red_terracotta
setblock 471 210 486 minecraft:terracotta
fill 471 210 487 471 213 487 minecraft:red_terracotta
setblock 471 210 491 minecraft:terracotta
fill 471 210 492 471 213 492 minecraft:red_terracotta
setblock 471 210 496 minecraft:terracotta
fill 471 210 497 471 213 497 minecraft:red_terracotta
setblock 471 210 501 minecraft:terracotta
fill 471 210 502 471 213 502 minecraft:red_terracotta
setblock 472 210 465 minecraft:terracotta
fill 472 210 466 472 213 466 minecraft:red_terracotta
fill 472 210 468 472 211 468 minecraft:red_terracotta
fill 472 210 476 472 212 476 minecraft:red_terracotta
setblock 472 210 480 minecraft:terracotta
fill 472 210 481 472 213 481 minecraft:red_terracotta
setblock 472 210 485 minecraft:terracotta
fill 472 210 486 472 213 486 minecraft:red_terracotta
setblock 472 210 489 minecraft:red_terracotta
setblock 472 210 490 minecraft:terracotta
fill 472 210 491 472 213 491 minecraft:red_terracotta
setblock 472 210 495 minecraft:terracotta
fill 472 210 496 472 213 496 minecraft:red_terracotta
setblock 472 210 500 minecraft:terracotta
fill 472 210 501 472 213 501 minecraft:red_terracotta
setblock 473 210 464 minecraft:terracotta
fill 473 210 465 473 213 465 minecraft:red_terracotta
setblock 473 210 479 minecraft:terracotta
fill 473 210 480 473 213 480 minecraft:red_terracotta
setblock 473 210 483 minecraft:red_terracotta
setblock 473 210 484 minecraft:terracotta
fill 473 210 485 473 213 485 minecraft:red_terracotta
setblock 473 210 489 minecraft:terracotta
fill 473 210 490 473 213 490 minecraft:red_terracotta
setblock 473 210 493 minecraft:red_terracotta
setblock 473 210 500 minecraft:red_terracotta
setblock 473 210 504 minecraft:terracotta
fill 474 210 464 474 213 464 minecraft:red_terracotta
setblock 474 210 483 minecraft:terracotta
fill 474 210 484 474 213 484 minecraft:red_terracotta
setblock 474 210 488 minecraft:terracotta
fill 474 210 489 474 213 489 minecraft:red_terracotta
setblock 474 210 503 minecraft:terracotta
fill 474 210 504 474 213 504 minecraft:red_terracotta
fill 475 210 503 475 212 503 minecraft:red_terracotta
setblock 477 210 464 minecraft:red_terracotta
setblock 477 210 465 minecraft:terracotta
setblock 478 210 464 minecraft:terracotta
setblock 478 210 504 minecraft:terracotta
fill 479 210 464 482 210 464 minecraft:red_terracotta
fill 479 210 504 479 211 504 minecraft:red_terracotta
setblock 483 210 464 minecraft:terracotta
fill 484 210 464 484 213 464 minecraft:red_terracotta
fill 484 210 504 487 210 504 minecraft:red_terracotta
fill 485 210 465 486 210 465 minecraft:red_terracotta
setblock 487 210 465 minecraft:terracotta
fill 487 210 466 488 212 466 minecraft:red_terracotta
setblock 488 210 464 minecraft:terracotta
fill 488 210 465 488 213 465 minecraft:red_terracotta
setblock 488 210 503 minecraft:red_terracotta
setblock 488 210 504 minecraft:terracotta
fill 489 210 464 489 213 464 minecraft:red_terracotta
setblock 489 210 503 minecraft:terracotta
fill 489 210 504 489 213 504 minecraft:red_terracotta
setblock 490 210 467 minecraft:terracotta
fill 490 210 503 490 213 503 minecraft:red_terracotta
setblock 491 210 466 minecraft:terracotta
fill 491 210 467 491 213 467 minecraft:red_terracotta
setblock 492 210 465 minecraft:terracotta
fill 492 210 466 492 213 466 minecraft:red_terracotta
setblock 493 210 464 minecraft:terracotta
fill 493 210 465 493 213 465 minecraft:red_terracotta
setblock 493 210 504 minecraft:terracotta
fill 494 210 464 494 213 464 minecraft:red_terracotta
setblock 494 210 503 minecraft:terracotta
fill 494 210 504 494 213 504 minecraft:red_terracotta
setblock 495 210 466 minecraft:red_terracotta
setblock 495 210 467 minecraft:terracotta
setblock 495 210 502 minecraft:terracotta
fill 495 210 503 495 213 503 minecraft:red_terracotta
setblock 496 210 466 minecraft:terracotta
setblock 496 210 502 minecraft:red_terracotta
setblock 497 210 465 minecraft:terracotta
fill 497 210 466 497 213 466 minecraft:red_terracotta
setblock 498 210 464 minecraft:terracotta
fill 498 210 465 498 213 465 minecraft:red_terracotta
setblock 498 210 504 minecraft:terracotta
fill 499 210 464 502 210 464 minecraft:red_terracotta
fill 499 210 466 499 211 466 minecraft:red_terracotta
setblock 499 210 503 minecraft:terracotta
fill 499 210 504 499 213 504 minecraft:red_terracotta
fill 500 210 503 500 212 503 minecraft:red_terracotta
setblock 502 210 465 minecraft:terracotta
setblock 503 210 464 minecraft:terracotta
fill 503 210 465 506 210 465 minecraft:red_terracotta
setblock 503 210 504 minecraft:terracotta
fill 504 210 464 504 213 464 minecraft:red_terracotta
setblock 504 210 503 minecraft:terracotta
fill 504 210 504 504 213 504 minecraft:red_terracotta
fill 505 210 503 505 213 503 minecraft:red_terracotta
fill 506 210 502 506 212 502 minecraft:red_terracotta
setblock 507 210 465 minecraft:terracotta
setblock 508 210 464 minecraft:terracotta
fill 508 210 465 508 213 465 minecraft:red_terracotta
setblock 508 210 504 minecraft:terracotta
fill 509 210 464 509 213 464 minecraft:red_terracotta
fill 509 210 485 509 210 487 minecraft:red_terracotta
fill 509 210 499 509 213 499 minecraft:red_terracotta
setblock 509 210 503 minecraft:terracotta
fill 509 210 504 509 213 504 minecraft:red_terracotta
setblock 510 210 467 minecraft:terracotta
fill 510 210 468 510 213 468 minecraft:red_terracotta
fill 510 210 480 510 210 481 minecraft:red_terracotta
setblock 510 210 482 minecraft:terracotta
fill 510 210 483 510 213 483 minecraft:red_terracotta
fill 510 210 485 510 210 486 minecraft:red_terracotta
setblock 510 210 487 minecraft:terracotta
fill 510 210 488 510 210 491 minecraft:red_terracotta
setblock 510 210 492 minecraft:terracotta
fill 510 210 493 510 213 493 minecraft:red_terracotta
setblock 510 210 497 minecraft:terracotta
fill 510 210 498 510 213 498 minecraft:red_terracotta
setblock 510 210 502 minecraft:terracotta
fill 510 210 503 510 213 503 minecraft:red_terracotta
setblock 511 210 466 minecraft:terracotta
fill 511 210 467 511 213 467 minecraft:red_terracotta
setblock 511 210 471 minecraft:terracotta
setblock 511 210 476 minecraft:terracotta
fill 511 210 477 511 213 477 minecraft:red_terracotta
setblock 511 210 481 minecraft:terracotta
fill 511 210 482 511 213 482 minecraft:red_terracotta
setblock 511 210 486 minecraft:terracotta
fill 511 210 487 511 213 487 minecraft:red_terracotta
setblock 511 210 490 minecraft:red_terracotta
setblock 511 210 491 minecraft:terracotta
fill 511 210 492 511 213 492 minecraft:red_terracotta
setblock 511 210 496 minecraft:terracotta
fill 511 210 497 511 213 497 minecraft:red_terracotta
setblock 511 210 501 minecraft:terracotta
fill 511 210 502 511 213 502 minecraft:red_terracotta
setblock 471 211 465 minecraft:terracotta
fill 471 211 466 471 214 466 minecraft:red_terracotta
fill 471 211 468 471 211 469 minecraft:red_terracotta
setblock 471 211 470 minecraft:terracotta
fill 471 211 471 471 214 471 minecraft:red_terracotta
setblock 471 211 475 minecraft:terracotta
fill 471 211 476 471 214 476 minecraft:red_terracotta
setblock 471 211 480 minecraft:terracotta
fill 471 211 481 471 214 481 minecraft:red_terracotta
setblock 471 211 485 minecraft:terracotta
fill 471 211 486 471 214 486 minecraft:red_terracotta
setblock 471 211 490 minecraft:terracotta
fill 471 211 491 471 214 491 minecraft:red_terracotta
setblock 471 211 495 minecraft:terracotta
fill 471 211 496 471 214 496 minecraft:red_terracotta
setblock 471 211 500 minecraft:terracotta
fill 471 211 501 471 214 501 minecraft:red_terracotta
setblock 472 211 464 minecraft:terracotta
fill 472 211 465 472 214 465 minecraft:red_terracotta
setblock 472 211 469 minecraft:terracotta
setblock 472 211 479 minecraft:terracotta
fill 472 211 480 472 214 480 minecraft:red_terracotta
setblock 472 211 484 minecraft:terracotta
fill 472 211 485 472 214 485 minecraft:red_terracotta
setblock 472 211 489 minecraft:terracotta
fill 472 211 490 472 214 490 minecraft:red_terracotta
setblock 472 211 494 minecraft:terracotta
fill 472 211 495 472 214 495 minecraft:red_terracotta
setblock 472 211 499 minecraft:terracotta
fill 472 211 500 472 213 500 minecraft:red_terracotta
setblock 472 211 504 minecraft:terracotta
fill 473 211 464 473 214 464 minecraft:red_terracotta
fill 473 211 479 473 212 479 minecraft:red_terracotta
setblock 473 211 483 minecraft:terracotta
fill 473 211 484 473 214 484 minecraft:red_terracotta
setblock 473 211 487 minecraft:red_terracotta
setblock 473 211 488 minecraft:terracotta
fill 473 211 489 473 214 489 minecraft:red_terracotta
setblock 473 211 493 minecraft:terracotta
setblock 473 211 503 minecraft:terracotta
fill 473 211 504 473 214 504 minecraft:red_terracotta
fill 474 211 465 475 211 465 minecraft:red_terracotta
setblock 474 211 482 minecraft:terracotta
fill 474 211 483 474 213 483 minecraft:red_terracotta
setblock 474 211 487 minecraft:terracotta
fill 474 211 488 474 214 488 minecraft:red_terracotta
fill 474 211 490 474 212 490 minecraft:red_terracotta
fill 474 211 503 474 212 503 minecraft:red_terracotta
setblock 476 211 465 minecraft:terracotta
setblock 477 211 464 minecraft:terracotta
fill 477 211 465 477 212 465 minecraft:red_terracotta
setblock 477 211 504 minecraft:terracotta
fill 478 211 464 481 211 464 minecraft:red_terracotta
fill 478 211 504 478 212 504 minecraft:red_terracotta
setblock 482 211 464 minecraft:terracotta
fill 483 211 464 483 214 464 minecraft:red_terracotta
fill 484 211 465 485 211 465 minecraft:red_terracotta
fill 484 211 504 486 211 504 minecraft:red_terracotta
setblock 486 211 465 minecraft:terracotta
fill 486 211 466 486 214 466 minecraft:red_terracotta
setblock 487 211 464 minecraft:terracotta
fill 487 211 465 487 214 465 minecraft:red_terracotta
setblock 487 211 504 minecraft:terracotta
fill 488 211 464 488 214 464 minecraft:red_terracotta
setblock 488 211 503 minecraft:terracotta
fill 488 211 504 488 214 504 minecraft:red_terracotta
setblock 489 211 467 minecraft:terracotta
fill 489 211 503 489 214 503 minecraft:red_terracotta
setblock 490 211 465 minecraft:red_terracotta
setblock 490 211 466 minecraft:terracotta
fill 490 211 467 490 214 467 minecraft:red_terracotta
setblock 491 211 465 minecraft:terracotta
fill 491 211 466 491 214 466 minecraft:red_terracotta
setblock 492 211 464 minecraft:terracotta
fill 492 211 465 492 214 465 minecraft:red_terracotta
fill 492 211 467 493 211 467 minecraft:red_terracotta
setblock 492 211 504 minecraft:terracotta
fill 493 211 464 493 214 464 minecraft:red_terracotta
setblock 493 211 502 minecraft:red_terracotta
setblock 493 211 503 minecraft:terracotta
fill 493 211 504 493 214 504 minecraft:red_terracotta
setblock 494 211 467 minecraft:terracotta
setblock 494 211 502 minecraft:terracotta
fill 494 211 503 494 214 503 minecraft:red_terracotta
setblock 495 211 466 minecraft:terracotta
fill 495 211 467 495 213 467 minecraft:red_terracotta
setblock 496 211 465 minecraft:terracotta
fill 496 211 466 496 214 466 minecraft:red_terracotta
setblock 497 211 464 minecraft:terracotta
fill 497 211 465 497 214 465 minecraft:red_terracotta
setblock 497 211 504 minecraft:terracotta
fill 498 211 464 501 211 464 minecraft:red_terracotta
setblock 498 211 503 minecraft:terracotta
fill 498 211 504 498 214 504 minecraft:red_terracotta
fill 499 211 503 499 213 503 minecraft:red_terracotta
setblock 501 211 465 minecraft:terracotta
setblock 502 211 464 minecraft:terracotta
fill 502 211 465 505 211 465 minecraft:red_terracotta
setblock 502 211 504 minecraft:terracotta
fill 503 211 464 503 214 464 minecraft:red_terracotta
setblock 503 211 503 minecraft:terracotta
fill 503 211 504 503 214 504 minecraft:red_terracotta
fill 504 211 503 504 214 503 minecraft:red_terracotta
setblock 506 211 465 minecraft:terracotta
setblock 507 211 464 minecraft:terracotta
fill 507 211 465 507 214 465 minecraft:red_terracotta
setblock 507 211 504 minecraft:terracotta
fill 508 211 464 508 214 464 minecraft:red_terracotta
fill 508 211 466 509 211 466 minecraft:red_terracotta
setblock 508 211 503 minecraft:terracotta
fill 508 211 504 508 214 504 minecraft:red_terracotta
fill 509 211 483 509 211 486 minecraft:red_terracotta
setblock 509 211 487 minecraft:terracotta
fill 509 211 488 510 211 490 minecraft:red_terracotta
setblock 509 211 502 minecraft:terracotta
fill 509 211 503 509 214 503 minecraft:red_terracotta
setblock 510 211 465 minecraft:red_terracotta
setblock 510 211 466 minecraft:terracotta
fill 510 211 467 510 214 467 minecraft:red_terracotta
fill 510 211 469 510 212 469 minecraft:red_terracotta
setblock 510 211 480 minecraft:red_terracotta
setblock 510 211 481 minecraft:terracotta
fill 510 211 482 510 214 482 minecraft:red_terracotta
setblock 510 211 485 minecraft:red_terracotta
setblock 510 211 486 minecraft:terracotta
fill 510 211 487 510 214 487 minecraft:red_terracotta
setblock 510 211 491 minecraft:terracotta
fill 510 211 492 510 214 492 minecraft:red_terracotta
setblock 510 211 496 minecraft:terracotta
fill 510 211 497 510 214 497 minecraft:red_terracotta
setblock 510 211 501 minecraft:terracotta
fill 510 211 502 510 214 502 minecraft:red_terracotta
setblock 511 211 465 minecraft:terracotta
fill 511 211 466 511 214 466 minecraft:red_terracotta
setblock 511 211 470 minecraft:terracotta
fill 511 211 471 511 212 473 minecraft:red_terracotta
setblock 511 211 475 minecraft:terracotta
fill 511 211 476 511 213 476 minecraft:red_terracotta
setblock 511 211 480 minecraft:terracotta
fill 511 211 481 511 214 481 minecraft:red_terracotta
setblock 511 211 485 minecraft:terracotta
fill 511 211 486 511 214 486 minecraft:red_terracotta
setblock 511 211 490 minecraft:terracotta
fill 511 211 491 511 214 491 minecraft:red_terracotta
setblock 511 211 495 minecraft:terracotta
fill 511 211 496 511 214 496 minecraft:red_terracotta
setblock 511 211 500 minecraft:terracotta
fill 511 211 501 511 214 501 minecraft:red_terracotta
setblock 471 212 464 minecraft:terracotta
fill 471 212 465 471 215 465 minecraft:red_terracotta
setblock 471 212 468 minecraft:red_terracotta
setblock 471 212 469 minecraft:terracotta
fill 471 212 470 472 214 470 minecraft:red_terracotta
setblock 471 212 474 minecraft:terracotta
fill 471 212 475 471 215 475 minecraft:red_terracotta
setblock 471 212 479 minecraft:terracotta
fill 471 212 480 471 215 480 minecraft:red_terracotta
setblock 471 212 484 minecraft:terracotta
fill 471 212 485 471 215 485 minecraft:red_terracotta
setblock 471 212 489 minecraft:terracotta
fill 471 212 490 471 215 490 minecraft:red_terracotta
setblock 471 212 494 minecraft:terracotta
fill 471 212 495 471 215 495 minecraft:red_terracotta
setblock 471 212 499 minecraft:terracotta
fill 471 212 500 471 215 500 minecraft:red_terracotta
setblock 471 212 504 minecraft:terracotta
fill 472 212 464 472 215 464 minecraft:red_terracotta
setblock 472 212 468 minecraft:terracotta
fill 472 212 469 472 215 469 minecraft:red_terracotta
setblock 472 212 478 minecraft:terracotta
fill 472 212 479 472 215 479 minecraft:red_terracotta
setblock 472 212 483 minecraft:terracotta
fill 472 212 484 472 215 484 minecraft:red_terracotta
setblock 472 212 488 minecraft:terracotta
fill 472 212 489 472 215 489 minecraft:red_terracotta
setblock 472 212 492 minecraft:red_terracotta
setblock 472 212 493 minecraft:terracotta
fill 472 212 494 472 215 494 minecraft:red_terracotta
setblock 472 212 498 minecraft:terracotta
fill 472 212 499 472 213 499 minecraft:red_terracotta
setblock 472 212 503 minecraft:terracotta
fill 472 212 504 472 215 504 minecraft:red_terracotta
setblock 473 212 482 minecraft:terracotta
fill 473 212 483 473 215 483 minecraft:red_terracotta
setblock 473 212 487 minecraft:terracotta
fill 473 212 488 473 215 488 minecraft:red_terracotta
setblock 473 212 492 minecraft:terracotta
fill 473 212 493 473 213 493 minecraft:red_terracotta
fill 473 212 503 473 213 503 minecraft:red_terracotta
setblock 474 212 465 minecraft:red_terracotta
setblock 474 212 482 minecraft:red_terracotta
setblock 474 212 486 minecraft:terracotta
fill 474 212 487 474 214 487 minecraft:red_terracotta
setblock 475 212 465 minecraft:terracotta
setblock 476 212 464 minecraft:terracotta
fill 476 212 465 476 213 465 minecraft:red_terracotta
setblock 476 212 504 minecraft:terracotta
fill 477 212 464 480 212 464 minecraft:red_terracotta
setblock 477 212 504 minecraft:red_terracotta
setblock 481 212 464 minecraft:terracotta
fill 482 212 464 482 215 464 minecraft:red_terracotta
fill 483 212 465 484 212 465 minecraft:red_terracotta
fill 484 212 504 485 212 504 minecraft:red_terracotta
setblock 485 212 465 minecraft:terracotta
fill 485 212 466 485 215 466 minecraft:red_terracotta
setblock 486 212 464 minecraft:terracotta
fill 486 212 465 486 215 465 minecraft:red_terracotta
setblock 486 212 504 minecraft:terracotta
fill 487 212 464 487 215 464 minecraft:red_terracotta
fill 487 212 504 487 215 504 minecraft:red_terracotta
setblock 488 212 467 minecraft:terracotta
fill 488 212 503 488 214 503 minecraft:red_terracotta
setblock 489 212 465 minecraft:red_terracotta
setblock 489 212 466 minecraft:terracotta
fill 489 212 467 489 215 467 minecraft:red_terracotta
setblock 490 212 465 minecraft:terracotta
fill 490 212 466 490 215 466 minecraft:red_terracotta
setblock 491 212 464 minecraft:terracotta
fill 491 212 465 491 215 465 minecraft:red_terracotta
setblock 491 212 504 minecraft:terracotta
fill 492 212 464 492 215 464 minecraft:red_terracotta
setblock 492 212 467 minecraft:red_terracotta
setblock 492 212 503 minecraft:terracotta
fill 492 212 504 492 215 504 minecraft:red_terracotta
setblock 493 212 467 minecraft:terracotta
fill 493 212 503 493 215 503 minecraft:red_terracotta
setblock 494 212 466 minecraft:terracotta
fill 494 212 467 494 214 467 minecraft:red_terracotta
setblock 495 212 465 minecraft:terracotta
fill 495 212 466 495 215 466 minecraft:red_terracotta
setblock 496 212 464 minecraft:terracotta
fill 496 212 465 496 215 465 minecraft:red_terracotta
setblock 496 212 504 minecraft:terracotta
fill 497 212 464 500 212 464 minecraft:red_terracotta
setblock 497 212 503 minecraft:terracotta
fill 497 212 504 497 215 504 minecraft:red_terracotta
fill 498 212 503 498 213 503 minecraft:red_terracotta
setblock 499 212 466 minecraft:terracotta
setblock 500 212 465 minecraft:terracotta
setblock 501 212 464 minecraft:terracotta
fill 501 212 465 504 212 465 minecraft:red_terracotta
setblock 501 212 504 minecraft:terracotta
fill 502 212 464 502 215 464 minecraft:red_terracotta
setblock 502 212 503 minecraft:terracotta
fill 502 212 504 502 215 504 minecraft:red_terracotta
fill 503 212 503 503 214 503 minecraft:red_terracotta
setblock 505 212 465 minecraft:terracotta
setblock 506 212 464 minecraft:terracotta
fill 506 212 465 506 215 465 minecraft:red_terracotta
setblock 506 212 504 minecraft:terracotta
fill 507 212 464 507 215 464 minecraft:red_terracotta
fill 507 212 466 508 212 466 minecraft:red_terracotta
setblock 507 212 503 minecraft:terracotta
fill 507 212 504 507 215 504 minecraft:red_terracotta
setblock 508 212 502 minecraft:terracotta
fill 508 212 503 508 215 503 minecraft:red_terracotta
setblock 509 212 466 minecraft:terracotta
fill 509 212 467 509 214 467 minecraft:red_terracotta
fill 509 212 483 509 212 485 minecraft:red_terracotta
setblock 509 212 486 minecraft:terracotta
fill 509 212 487 509 212 490 minecraft:red_terracotta
setblock 509 212 491 minecraft:terracotta
fill 509 212 492 509 214 493 minecraft:red_terracotta
setblock 509 212 501 minecraft:terracotta
fill 509 212 502 509 214 502 minecraft:red_terracotta
setblock 510 212 465 minecraft:terracotta
fill 510 212 466 510 215 466 minecraft:red_terracotta
setblock 510 212 480 minecraft:terracotta
fill 510 212 481 510 214 481 minecraft:red_terracotta
setblock 510 212 485 minecraft:terracotta
fill 510 212 486 510 215 486 minecraft:red_terracotta
fill 510 212 488 510 212 489 minecraft:red_terracotta
setblock 510 212 490 minecraft:terracotta
fill 510 212 491 510 215 491 minecraft:red_terracotta
setblock 510 212 494 minecraft:red_terracotta
setblock 510 212 495 minecraft:terracotta
fill 510 212 496 510 215 496 minecraft:red_terracotta
setblock 510 212 500 minecraft:terracotta
fill 510 212 501 510 215 501 minecraft:red_terracotta
setblock 511 212 464 minecraft:terracotta
fill 511 212 465 511 215 465 minecraft:red_terracotta
setblock 511 212 469 minecraft:terracotta
fill 511 212 470 511 215 470 minecraft:red_terracotta
setblock 511 212 474 minecraft:terracotta
setblock 511 212 475 minecraft:red_terracotta
setblock 511 212 479 minecraft:terracotta
fill 511 212 480 511 215 480 minecraft:red_terracotta
setblock 511 212 484 minecraft:terracotta
fill 511 212 485 511 215 485 minecraft:red_terracotta
setblock 511 212 489 minecraft:terracotta
fill 511 212 490 511 215 490 minecraft:red_terracotta
setblock 511 212 494 minecraft:terracotta
fill 511 212 495 511 215 495 minecraft:red_terracotta
setblock 511 212 499 minecraft:terracotta
fill 511 212 500 511 215 500 minecraft:red_terracotta
setblock 511 212 504 minecraft:terracotta
fill 471 213 464 471 216 464 minecraft:red_terracotta
setblock 471 213 467 minecraft:red_terracotta
setblock 471 213 468 minecraft:terracotta
fill 471 213 469 471 216 469 minecraft:red_terracotta
setblock 471 213 472 minecraft:red_terracotta
setblock 471 213 473 minecraft:terracotta
fill 471 213 474 471 216 474 minecraft:red_terracotta
setblock 471 213 478 minecraft:terracotta
fill 471 213 479 471 216 479 minecraft:red_terracotta
setblock 471 213 483 minecraft:terracotta
fill 471 213 484 471 216 484 minecraft:red_terracotta
setblock 471 213 488 minecraft:terracotta
fill 471 213 489 471 216 489 minecraft:red_terracotta
setblock 471 213 493 minecraft:terracotta
fill 471 213 494 471 216 494 minecraft:red_terracotta
setblock 471 213 498 minecraft:terracotta
fill 471 213 499 471 216 499 minecraft:red_terracotta
setblock 471 213 503 minecraft:terracotta
fill 471 213 504 471 216 504 minecraft:red_terracotta
setblock 472 213 467 minecraft:terracotta
fill 472 213 468 472 216 468 minecraft:red_terracotta
setblock 472 213 471 minecraft:red_terracotta
setblock 472 213 477 minecraft:terracotta
fill 472 213 478 472 214 478 minecraft:red_terracotta
setblock 472 213 482 minecraft:terracotta
fill 472 213 483 472 216 483 minecraft:red_terracotta
setblock 472 213 487 minecraft:terracotta
fill 472 213 488 472 216 488 minecraft:red_terracotta
setblock 472 213 492 minecraft:terracotta
fill 472 213 493 472 216 493 minecraft:red_terracotta
setblock 472 213 497 minecraft:terracotta
setblock 472 213 498 minecraft:red_terracotta
setblock 472 213 502 minecraft:terracotta
fill 472 213 503 472 214 503 minecraft:red_terracotta
setblock 473 213 466 minecraft:light[level=14]
setblock 473 213 474 minecraft:light[level=14]
setblock 473 213 481 minecraft:terracotta
fill 473 213 482 473 214 482 minecraft:red_terracotta
setblock 473 213 486 minecraft:terracotta
fill 473 213 487 473 216 487 minecraft:red_terracotta
setblock 473 213 491 minecraft:terracotta
fill 473 213 492 473 215 492 minecraft:red_terracotta
setblock 473 213 498 minecraft:light[level=14]
setblock 474 213 465 minecraft:terracotta
setblock 474 213 485 minecraft:terracotta
fill 474 213 486 474 214 486 minecraft:red_terracotta
setblock 475 213 464 minecraft:terracotta
fill 475 213 465 475 214 465 minecraft:red_terracotta
setblock 475 213 504 minecraft:terracotta
fill 476 213 464 479 213 464 minecraft:red_terracotta
setblock 476 213 504 minecraft:red_terracotta
setblock 480 213 464 minecraft:terracotta
fill 481 213 464 481 216 464 minecraft:red_terracotta
setblock 481 213 466 minecraft:light[level=14]
setblock 481 213 474 minecraft:light[level=14]
setblock 481 213 482 minecraft:light[level=14]
setblock 481 213 490 minecraft:light[level=14]
setblock 481 213 498 minecraft:light[level=14]
fill 482 213 465 483 213 465 minecraft:red_terracotta
setblock 484 213 465 minecraft:terracotta
setblock 485 213 464 minecraft:terracotta
fill 485 213 465 485 216 465 minecraft:red_terracotta
setblock 485 213 504 minecraft:terracotta
fill 486 213 464 486 216 464 minecraft:red_terracotta
fill 486 213 504 486 216 504 minecraft:red_terracotta
setblock 487 213 466 minecraft:red_terracotta
setblock 487 213 467 minecraft:terracotta
setblock 488 213 466 minecraft:terracotta
fill 488 213 467 488 216 467 minecraft:red_terracotta
setblock 489 213 465 minecraft:terracotta
fill 489 213 466 489 216 466 minecraft:red_terracotta
setblock 489 213 474 minecraft:light[level=14]
setblock 489 213 482 minecraft:light[level=14]
setblock 489 213 490 minecraft:light[level=14]
setblock 489 213 498 minecraft:light[level=14]
setblock 490 213 464 minecraft:terracotta
fill 490 213 465 490 216 465 minecraft:red_terracotta
setblock 490 213 504 minecraft:terracotta
fill 491 213 464 491 216 464 minecraft:red_terracotta
setblock 491 213 503 minecraft:terracotta
fill 491 213 504 491 216 504 minecraft:red_terracotta
setblock 492 213 467 minecraft:terracotta
fill 492 213 503 492 215 503 minecraft:red_terracotta
setblock 493 213 466 minecraft:terracotta
fill 493 213 467 493 215 467 minecraft:red_terracotta
setblock 494 213 465 minecraft:terracotta
fill 494 213 466 494 216 466 minecraft:red_terracotta
setblock 495 213 464 minecraft:terracotta
fill 495 213 465 495 216 465 minecraft:red_terracotta
setblock 495 213 504 minecraft:terracotta
fill 496 213 464 499 213 464 minecraft:red_terracotta
setblock 496 213 503 minecraft:terracotta
fill 496 213 504 496 216 504 minecraft:red_terracotta
setblock 497 213 474 minecraft:light[level=14]
setblock 497 213 482 minecraft:light[level=14]
setblock 497 213 490 minecraft:light[level=14]
setblock 497 213 498 minecraft:light[level=14]
setblock 497 213 503 minecraft:red_terracotta
setblock 498 213 466 minecraft:terracotta
setblock 499 213 465 minecraft:terracotta
setblock 500 213 464 minecraft:terracotta
fill 500 213 465 503 213 465 minecraft:red_terracotta
setblock 500 213 504 minecraft:terracotta
fill 501 213 464 501 216 464 minecraft:red_terracotta
setblock 501 213 503 minecraft:terracotta
fill 501 213 504 501 216 504 minecraft:red_terracotta
setblock 502 213 503 minecraft:red_terracotta
setblock 504 213 465 minecraft:terracotta
setblock 505 213 464 minecraft:terracotta
fill 505 213 465 505 216 465 minecraft:red_terracotta
setblock 505 213 466 minecraft:light[level=14]
setblock 505 213 474 minecraft:light[level=14]
setblock 505 213 482 minecraft:light[level=14]
setblock 505 213 490 minecraft:light[level=14]
setblock 505 213 498 minecraft:light[level=14]
setblock 505 213 504 minecraft:terracotta
fill 506 213 464 506 216 464 minecraft:red_terracotta
fill 506 213 466 507 213 466 minecraft:red_terracotta
setblock 506 213 503 minecraft:terracotta
fill 506 213 504 506 216 504 minecraft:red_terracotta
setblock 507 213 502 minecraft:terracotta
fill 507 213 503 507 216 503 minecraft:red_terracotta
setblock 508 213 466 minecraft:terracotta
fill 508 213 502 508 214 502 minecraft:red_terracotta
setblock 509 213 465 minecraft:terracotta
fill 509 213 466 509 215 466 minecraft:red_terracotta
fill 509 213 483 509 213 484 minecraft:red_terracotta
setblock 509 213 485 minecraft:terracotta
fill 509 213 486 509 213 489 minecraft:red_terracotta
setblock 509 213 490 minecraft:terracotta
fill 509 213 491 509 216 491 minecraft:red_terracotta
setblock 509 213 494 minecraft:red_terracotta
setblock 509 213 500 minecraft:terracotta
fill 509 213 501 509 214 501 minecraft:red_terracotta
setblock 510 213 464 minecraft:terracotta
fill 510 213 465 510 216 465 minecraft:red_terracotta
setblock 510 213 469 minecraft:terracotta
fill 510 213 470 510 216 470 minecraft:red_terracotta
setblock 510 213 480 minecraft:red_terracotta
setblock 510 213 484 minecraft:terracotta
fill 510 213 485 510 216 485 minecraft:red_terracotta
setblock 510 213 488 minecraft:red_terracotta
setblock 510 213 489 minecraft:terracotta
fill 510 213 490 510 216 490 minecraft:red_terracotta
setblock 510 213 494 minecraft:terracotta
fill 510 213 495 510 216 495 minecraft:red_terracotta
setblock 510 213 499 minecraft:terracotta
fill 510 213 500 510 216 500 minecraft:red_terracotta
setblock 510 213 504 minecraft:terracotta
fill 511 213 464 511 216 464 minecraft:red_terracotta
setblock 511 213 468 minecraft:terracotta
fill 511 213 469 511 216 469 minecraft:red_terracotta
fill 511 213 471 511 213 472 minecraft:red_terracotta
setblock 511 213 473 minecraft:terracotta
setblock 511 213 474 minecraft:red_terracotta
setblock 511 213 478 minecraft:terracotta
fill 511 213 479 511 215 479 minecraft:red_terracotta
setblock 511 213 483 minecraft:terracotta
fill 511 213 484 511 216 484 minecraft:red_terracotta
setblock 511 213 488 minecraft:terracotta
fill 511 213 489 511 216 489 minecraft:red_terracotta
setblock 511 213 493 minecraft:terracotta
fill 511 213 494 511 216 494 minecraft:red_terracotta
setblock 511 213 498 minecraft:terracotta
fill 511 213 499 511 216 499 minecraft:red_terracotta
setblock 511 213 503 minecraft:terracotta
fill 511 213 504 511 216 504 minecraft:red_terracotta
setblock 471 214 467 minecraft:terracotta
fill 471 214 468 471 217 468 minecraft:red_terracotta
setblock 471 214 472 minecraft:terracotta
fill 471 214 473 471 217 473 minecraft:red_terracotta
setblock 471 214 477 minecraft:terracotta
fill 471 214 478 471 217 478 minecraft:red_terracotta
setblock 471 214 482 minecraft:terracotta
fill 471 214 483 471 217 483 minecraft:red_terracotta
setblock 471 214 487 minecraft:terracotta
fill 471 214 488 471 217 488 minecraft:red_terracotta
setblock 471 214 492 minecraft:terracotta
fill 471 214 493 471 217 493 minecraft:red_terracotta
setblock 471 214 497 minecraft:terracotta
fill 471 214 498 471 216 498 minecraft:red_terracotta
setblock 471 214 502 minecraft:terracotta
fill 471 214 503 471 216 503 minecraft:red_terracotta
setblock 472 214 466 minecraft:terracotta
fill 472 214 467 472 216 467 minecraft:red_terracotta
setblock 472 214 471 minecraft:terracotta
setblock 472 214 481 minecraft:terracotta
fill 472 214 482 472 217 482 minecraft:red_terracotta
setblock 472 214 486 minecraft:terracotta
fill 472 214 487 472 217 487 minecraft:red_terracotta
setblock 472 214 491 minecraft:terracotta
fill 472 214 492 472 217 492 minecraft:red_terracotta
setblock 472 214 496 minecraft:terracotta
setblock 473 214 465 minecraft:terracotta
setblock 473 214 481 minecraft:red_terracotta
setblock 473 214 485 minecraft:terracotta
fill 473 214 486 473 216 486 minecraft:red_terracotta
setblock 473 214 490 minecraft:terracotta
fill 473 214 491 473 216 491 minecraft:red_terracotta
setblock 474 214 464 minecraft:terracotta
setblock 474 214 465 minecraft:red_terracotta
setblock 474 214 485 minecraft:red_terracotta
setblock 474 214 489 minecraft:terracotta
setblock 474 214 504 minecraft:terracotta
fill 475 214 464 478 214 464 minecraft:red_terracotta
setblock 475 214 504 minecraft:red_terracotta
setblock 479 214 464 minecraft:terracotta
fill 480 214 464 480 215 464 minecraft:red_terracotta
setblock 482 214 465 minecraft:red_terracotta
setblock 483 214 465 minecraft:terracotta
setblock 484 214 464 minecraft:terracotta
fill 484 214 465 484 217 465 minecraft:red_terracotta
fill 485 214 464 485 217 464 minecraft:red_terracotta
fill 485 214 504 485 215 504 minecraft:red_terracotta
setblock 487 214 466 minecraft:terracotta
fill 487 214 467 487 217 467 minecraft:red_terracotta
setblock 488 214 465 minecraft:terracotta
fill 488 214 466 488 217 466 minecraft:red_terracotta
setblock 489 214 464 minecraft:terracotta
fill 489 214 465 489 217 465 minecraft:red_terracotta
setblock 489 214 504 minecraft:terracotta
fill 490 214 464 490 217 464 minecraft:red_terracotta
setblock 490 214 503 minecraft:terracotta
fill 490 214 504 490 217 504 minecraft:red_terracotta
setblock 491 214 467 minecraft:terracotta
fill 491 214 503 491 215 503 minecraft:red_terracotta
setblock 492 214 466 minecraft:terracotta
fill 492 214 467 492 216 467 minecraft:red_terracotta
setblock 493 214 465 minecraft:terracotta
fill 493 214 466 493 217 466 minecraft:red_terracotta
setblock 494 214 464 minecraft:terracotta
fill 494 214 465 494 217 465 minecraft:red_terracotta
setblock 494 214 504 minecraft:terracotta
fill 495 214 464 498 214 464 minecraft:red_terracotta
setblock 495 214 503 minecraft:terracotta
fill 495 214 504 495 217 504 minecraft:red_terracotta
setblock 497 214 466 minecraft:terracotta
setblock 498 214 465 minecraft:terracotta
setblock 499 214 464 minecraft:terracotta
fill 499 214 465 502 214 465 minecraft:red_terracotta
setblock 499 214 504 minecraft:terracotta
fill 500 214 464 500 217 464 minecraft:red_terracotta
fill 500 214 504 500 216 504 minecraft:red_terracotta
setblock 503 214 465 minecraft:terracotta
setblock 504 214 464 minecraft:terracotta
fill 504 214 465 504 217 465 minecraft:red_terracotta
setblock 504 214 504 minecraft:terracotta
fill 505 214 464 505 217 464 minecraft:red_terracotta
setblock 505 214 503 minecraft:terracotta
fill 505 214 504 505 217 504 minecraft:red_terracotta
fill 506 214 503 506 217 503 minecraft:red_terracotta
setblock 507 214 466 minecraft:terracotta
setblock 507 214 502 minecraft:red_terracotta
setblock 508 214 465 minecraft:terracotta
fill 508 214 466 508 215 466 minecraft:red_terracotta
setblock 509 214 464 minecraft:terracotta
fill 509 214 465 509 217 465 minecraft:red_terracotta
setblock 509 214 484 minecraft:terracotta
fill 509 214 485 509 214 488 minecraft:red_terracotta
setblock 509 214 489 minecraft:terracotta
fill 509 214 490 509 217 490 minecraft:red_terracotta
setblock 509 214 494 minecraft:terracotta
fill 509 214 495 509 217 495 minecraft:red_terracotta
setblock 509 214 504 minecraft:terracotta
fill 510 214 464 510 217 464 minecraft:red_terracotta
setblock 510 214 468 minecraft:terracotta
fill 510 214 469 510 217 469 minecraft:red_terracotta
setblock 510 214 483 minecraft:terracotta
fill 510 214 484 510 217 484 minecraft:red_terracotta
setblock 510 214 488 minecraft:terracotta
fill 510 214 489 510 217 489 minecraft:red_terracotta
setblock 510 214 493 minecraft:terracotta
fill 510 214 494 510 217 494 minecraft:red_terracotta
setblock 510 214 498 minecraft:terracotta
fill 510 214 499 510 217 499 minecraft:red_terracotta
setblock 510 214 503 minecraft:terracotta
fill 510 214 504 510 217 504 minecraft:red_terracotta
setblock 511 214 467 minecraft:terracotta
fill 511 214 468 511 217 468 minecraft:red_terracotta
setblock 511 214 471 minecraft:red_terracotta
setblock 511 214 472 minecraft:terracotta
fill 511 214 473 511 216 473 minecraft:red_terracotta
setblock 511 214 478 minecraft:red_terracotta
setblock 511 214 482 minecraft:terracotta
fill 511 214 483 511 217 483 minecraft:red_terracotta
setblock 511 214 487 minecraft:terracotta
fill 511 214 488 511 217 488 minecraft:red_terracotta
setblock 511 214 492 minecraft:terracotta
fill 511 214 493 511 217 493 minecraft:red_terracotta
setblock 511 214 497 minecraft:terracotta
fill 511 214 498 511 217 498 minecraft:red_terracotta
setblock 511 214 502 minecraft:terracotta
fill 511 214 503 511 217 503 minecraft:red_terracotta
setblock 471 215 466 minecraft:terracotta
fill 471 215 467 471 218 467 minecraft:red_terracotta
setblock 471 215 470 minecraft:red_terracotta
setblock 471 215 471 minecraft:terracotta
fill 471 215 472 471 218 472 minecraft:red_terracotta
setblock 471 215 476 minecraft:terracotta
fill 471 215 477 471 218 477 minecraft:red_terracotta
setblock 471 215 481 minecraft:terracotta
fill 471 215 482 471 218 482 minecraft:red_terracotta
setblock 471 215 486 minecraft:terracotta
fill 471 215 487 471 218 487 minecraft:red_terracotta
setblock 471 215 491 minecraft:terracotta
fill 471 215 492 471 218 492 minecraft:red_terracotta
setblock 471 215 496 minecraft:terracotta
fill 471 215 497 471 218 497 minecraft:red_terracotta
setblock 471 215 501 minecraft:terracotta
setblock 471 215 502 minecraft:red_terracotta
setblock 472 215 465 minecraft:terracotta
fill 472 215 466 472 216 466 minecraft:red_terracotta
setblock 472 215 470 minecraft:terracotta
fill 472 215 471 472 216 471 minecraft:red_terracotta
setblock 472 215 480 minecraft:terracotta
fill 472 215 481 472 216 481 minecraft:red_terracotta
setblock 472 215 485 minecraft:terracotta
fill 472 215 486 472 218 486 minecraft:red_terracotta
setblock 472 215 490 minecraft:terracotta
fill 472 215 491 472 218 491 minecraft:red_terracotta
setblock 472 215 495 minecraft:terracotta
setblock 473 215 464 minecraft:terracotta
setblock 473 215 465 minecraft:red_terracotta
setblock 473 215 484 minecraft:terracotta
fill 473 215 485 473 216 485 minecraft:red_terracotta
setblock 473 215 489 minecraft:terracotta
fill 473 215 490 473 217 490 minecraft:red_terracotta
setblock 473 215 504 minecraft:terracotta
fill 474 215 464 477 215 464 minecraft:red_terracotta
setblock 483 215 464 minecraft:terracotta
fill 483 215 465 483 218 465 minecraft:red_terracotta
fill 484 215 464 484 218 464 minecraft:red_terracotta
fill 484 215 466 484 216 466 minecraft:red_terracotta
setblock 486 215 466 minecraft:terracotta
fill 486 215 467 486 218 467 minecraft:red_terracotta
setblock 487 215 465 minecraft:terracotta
fill 487 215 466 487 218 466 minecraft:red_terracotta
fill 487 215 493 487 216 493 minecraft:orange_concrete
setblock 488 215 464 minecraft:terracotta
fill 488 215 465 488 218 465 minecraft:red_terracotta
setblock 488 215 504 minecraft:terracotta
fill 489 215 464 489 218 464 minecraft:red_terracotta
setblock 489 215 503 minecraft:terracotta
fill 489 215 504 489 218 504 minecraft:red_terracotta
setblock 490 215 467 minecraft:terracotta
setblock 490 215 503 minecraft:red_terracotta
setblock 491 215 466 minecraft:terracotta
fill 491 215 467 491 217 467 minecraft:red_terracotta
setblock 492 215 465 minecraft:terracotta
fill 492 215 466 492 218 466 minecraft:red_terracotta
setblock 493 215 464 minecraft:terracotta
fill 493 215 465 493 218 465 minecraft:red_terracotta
fill 493 215 471 495 216 471 minecraft:orange_concrete
setblock 493 215 504 minecraft:terracotta
fill 494 215 464 497 215 464 minecraft:red_terracotta
fill 494 215 470 494 216 470 minecraft:orange_concrete
fill 494 215 504 494 217 504 minecraft:red_terracotta
setblock 496 215 466 minecraft:terracotta
setblock 497 215 465 minecraft:terracotta
setblock 498 215 464 minecraft:terracotta
fill 498 215 465 501 215 465 minecraft:red_terracotta
setblock 498 215 504 minecraft:terracotta
fill 499 215 464 499 218 464 minecraft:red_terracotta
fill 499 215 504 499 216 504 minecraft:red_terracotta
setblock 502 215 465 minecraft:terracotta
setblock 503 215 464 minecraft:terracotta
fill 503 215 465 503 216 465 minecraft:red_terracotta
setblock 503 215 504 minecraft:terracotta
fill 504 215 464 504 218 464 minecraft:red_terracotta
setblock 504 215 503 minecraft:terracotta
fill 504 215 504 504 218 504 minecraft:red_terracotta
fill 505 215 503 505 216 503 minecraft:red_terracotta
setblock 507 215 465 minecraft:terracotta
setblock 507 215 466 minecraft:red_terracotta
setblock 508 215 464 minecraft:terracotta
fill 508 215 465 508 218 465 minecraft:red_terracotta
setblock 508 215 504 minecraft:terracotta
fill 509 215 464 509 218 464 minecraft:red_terracotta
fill 509 215 485 509 215 487 minecraft:red_terracotta
setblock 509 215 488 minecraft:terracotta
fill 509 215 489 509 218 489 minecraft:red_terracotta
setblock 509 215 492 minecraft:red_terracotta
setblock 509 215 493 minecraft:terracotta
fill 509 215 494 509 218 494 minecraft:red_terracotta
setblock 509 215 503 minecraft:terracotta
fill 509 215 504 509 218 504 minecraft:red_terracotta
setblock 510 215 467 minecraft:terracotta
fill 510 215 468 510 218 468 minecraft:red_terracotta
setblock 510 215 482 minecraft:terracotta
fill 510 215 483 510 216 483 minecraft:red_terracotta
setblock 510 215 487 minecraft:terracotta
fill 510 215 488 510 218 488 minecraft:red_terracotta
setblock 510 215 492 minecraft:terracotta
fill 510 215 493 510 218 493 minecraft:red_terracotta
setblock 510 215 497 minecraft:terracotta
fill 510 215 498 510 218 498 minecraft:red_terracotta
setblock 510 215 502 minecraft:terracotta
fill 510 215 503 510 217 503 minecraft:red_terracotta
setblock 511 215 466 minecraft:terracotta
fill 511 215 467 511 218 467 minecraft:red_terracotta
setblock 511 215 471 minecraft:terracotta
fill 511 215 472 511 218 472 minecraft:red_terracotta
setblock 511 215 481 minecraft:terracotta
fill 511 215 482 511 218 482 minecraft:red_terracotta
setblock 511 215 486 minecraft:terracotta
fill 511 215 487 511 218 487 minecraft:red_terracotta
setblock 511 215 491 minecraft:terracotta
fill 511 215 492 511 218 492 minecraft:red_terracotta
setblock 511 215 496 minecraft:terracotta
fill 511 215 497 511 218 497 minecraft:red_terracotta
setblock 511 215 501 minecraft:terracotta
fill 511 215 502 511 218 502 minecraft:red_terracotta
setblock 471 216 465 minecraft:terracotta
fill 471 216 466 471 219 466 minecraft:red_terracotta
setblock 471 216 470 minecraft:terracotta
fill 471 216 471 471 219 471 minecraft:red_terracotta
setblock 471 216 475 minecraft:terracotta
fill 471 216 476 471 219 476 minecraft:red_terracotta
setblock 471 216 480 minecraft:terracotta
fill 471 216 481 471 219 481 minecraft:red_terracotta
setblock 471 216 485 minecraft:terracotta
fill 471 216 486 471 219 486 minecraft:red_terracotta
setblock 471 216 490 minecraft:terracotta
fill 471 216 491 471 219 491 minecraft:red_terracotta
setblock 471 216 495 minecraft:terracotta
fill 471 216 496 471 219 496 minecraft:red_terracotta
setblock 472 216 464 minecraft:terracotta
setblock 472 216 469 minecraft:terracotta
fill 472 216 470 472 217 470 minecraft:red_terracotta
setblock 472 216 484 minecraft:terracotta
fill 472 216 485 472 219 485 minecraft:red_terracotta
setblock 472 216 489 minecraft:terracotta
fill 472 216 490 472 219 490 minecraft:red_terracotta
setblock 472 216 494 minecraft:terracotta
fill 473 216 464 474 216 464 minecraft:red_terracotta
setblock 473 216 484 minecraft:red_terracotta
setblock 473 216 488 minecraft:terracotta
fill 473 216 489 473 217 489 minecraft:red_terracotta
setblock 482 216 464 minecraft:terracotta
fill 483 216 464 483 219 464 minecraft:red_terracotta
setblock 485 216 466 minecraft:terracotta
setblock 486 216 465 minecraft:terracotta
fill 486 216 466 486 219 466 minecraft:red_terracotta
setblock 487 216 464 minecraft:terracotta
fill 487 216 465 487 219 465 minecraft:red_terracotta
setblock 487 216 504 minecraft:terracotta
fill 488 216 464 488 219 464 minecraft:red_terracotta
fill 488 216 504 488 219 504 minecraft:red_terracotta
setblock 489 216 467 minecraft:terracotta
setblock 490 216 466 minecraft:terracotta
fill 490 216 467 490 218 467 minecraft:red_terracotta
setblock 491 216 465 minecraft:terracotta
fill 491 216 466 491 219 466 minecraft:red_terracotta
setblock 492 216 464 minecraft:terracotta
fill 492 216 465 492 219 465 minecraft:red_terracotta
setblock 492 216 504 minecraft:terracotta
fill 493 216 464 496 216 464 minecraft:red_terracotta
fill 493 216 504 493 218 504 minecraft:red_terracotta
setblock 495 216 466 minecraft:terracotta
setblock 496 216 465 minecraft:terracotta
setblock 497 216 464 minecraft:terracotta
fill 497 216 465 498 216 465 minecraft:red_terracotta
setblock 497 216 504 minecraft:terracotta
fill 498 216 464 498 218 464 minecraft:red_terracotta
setblock 498 216 504 minecraft:red_terracotta
setblock 502 216 464 minecraft:terracotta
setblock 502 216 504 minecraft:terracotta
fill 503 216 464 503 219 464 minecraft:red_terracotta
fill 503 216 504 503 219 504 minecraft:red_terracotta
setblock 506 216 465 minecraft:terracotta
setblock 507 216 464 minecraft:terracotta
fill 507 216 465 507 218 465 minecraft:red_terracotta
setblock 507 216 504 minecraft:terracotta
fill 508 216 464 508 219 464 minecraft:red_terracotta
setblock 508 216 503 minecraft:terracotta
fill 508 216 504 508 219 504 minecraft:red_terracotta
fill 509 216 485 509 216 486 minecraft:red_terracotta
setblock 509 216 487 minecraft:terracotta
fill 509 216 488 509 219 488 minecraft:red_terracotta
setblock 509 216 492 minecraft:terracotta
fill 509 216 493 509 219 493 minecraft:red_terracotta
fill 509 216 503 509 217 503 minecraft:red_terracotta
setblock 510 216 466 minecraft:terracotta
fill 510 216 467 510 218 467 minecraft:red_terracotta
setblock 510 216 486 minecraft:terracotta
fill 510 216 487 510 219 487 minecraft:red_terracotta
setblock 510 216 491 minecraft:terracotta
fill 510 216 492 510 219 492 minecraft:red_terracotta
setblock 510 216 496 minecraft:terracotta
fill 510 216 497 510 219 497 minecraft:red_terracotta
setblock 510 216 501 minecraft:terracotta
setblock 510 216 502 minecraft:red_terracotta
setblock 511 216 465 minecraft:terracotta
fill 511 216 466 511 219 466 minecraft:red_terracotta
setblock 511 216 470 minecraft:terracotta
fill 511 216 471 511 219 471 minecraft:red_terracotta
setblock 511 216 480 minecraft:terracotta
fill 511 216 481 511 217 481 minecraft:red_terracotta
setblock 511 216 485 minecraft:terracotta
fill 511 216 486 511 219 486 minecraft:red_terracotta
setblock 511 216 490 minecraft:terracotta
fill 511 216 491 511 219 491 minecraft:red_terracotta
setblock 511 216 495 minecraft:terracotta
fill 511 216 496 511 219 496 minecraft:red_terracotta
setblock 511 216 500 minecraft:terracotta
fill 511 216 501 511 219 501 minecraft:red_terracotta
setblock 471 217 464 minecraft:terracotta
fill 471 217 465 471 218 465 minecraft:red_terracotta
setblock 471 217 469 minecraft:terracotta
fill 471 217 470 471 220 470 minecraft:red_terracotta
setblock 471 217 474 minecraft:terracotta
fill 471 217 475 471 220 475 minecraft:red_terracotta
setblock 471 217 479 minecraft:terracotta
fill 471 217 480 471 220 480 minecraft:red_terracotta
setblock 471 217 484 minecraft:terracotta
fill 471 217 485 471 220 485 minecraft:red_terracotta
setblock 471 217 489 minecraft:terracotta
fill 471 217 490 471 220 490 minecraft:red_terracotta
setblock 471 217 494 minecraft:terracotta
fill 471 217 495 471 220 495 minecraft:red_terracotta
setblock 472 217 464 minecraft:red_terracotta
setblock 472 217 468 minecraft:terracotta
setblock 472 217 469 minecraft:red_terracotta
setblock 472 217 483 minecraft:terracotta
fill 472 217 484 472 218 484 minecraft:red_terracotta
setblock 472 217 488 minecraft:terracotta
fill 472 217 489 472 220 489 minecraft:red_terracotta
setblock 472 217 493 minecraft:terracotta
fill 472 217 494 472 218 494 minecraft:red_terracotta
setblock 473 217 487 minecraft:terracotta
setblock 473 217 488 minecraft:red_terracotta
setblock 481 217 464 minecraft:terracotta
fill 482 217 464 482 220 464 minecraft:red_terracotta
setblock 484 217 466 minecraft:terracotta
setblock 485 217 465 minecraft:terracotta
fill 485 217 466 485 220 466 minecraft:red_terracotta
setblock 486 217 464 minecraft:terracotta
fill 486 217 465 486 220 465 minecraft:red_terracotta
setblock 486 217 504 minecraft:terracotta
fill 487 217 464 487 220 464 minecraft:red_terracotta
fill 487 217 504 487 220 504 minecraft:red_terracotta
setblock 488 217 467 minecraft:terracotta
setblock 489 217 466 minecraft:terracotta
fill 489 217 467 489 219 467 minecraft:red_terracotta
setblock 490 217 465 minecraft:terracotta
fill 490 217 466 490 220 466 minecraft:red_terracotta
setblock 491 217 464 minecraft:terracotta
fill 491 217 465 491 220 465 minecraft:red_terracotta
setblock 491 217 504 minecraft:terracotta
fill 492 217 464 495 217 464 minecraft:red_terracotta
fill 492 217 504 492 218 504 minecraft:red_terracotta
setblock 494 217 466 minecraft:terracotta
setblock 495 217 465 minecraft:terracotta
setblock 496 217 464 minecraft:terracotta
setblock 496 217 465 minecraft:red_terracotta
fill 497 217 464 497 218 464 minecraft:red_terracotta
setblock 501 217 464 minecraft:terracotta
setblock 501 217 504 minecraft:terracotta
fill 502 217 464 502 220 464 minecraft:red_terracotta
fill 502 217 504 502 220 504 minecraft:red_terracotta
setblock 505 217 465 minecraft:terracotta
setblock 506 217 464 minecraft:terracotta
fill 506 217 465 506 218 465 minecraft:red_terracotta
setblock 506 217 504 minecraft:terracotta
fill 507 217 464 507 220 464 minecraft:red_terracotta
setblock 507 217 503 minecraft:terracotta
fill 507 217 504 507 220 504 minecraft:red_terracotta
fill 508 217 503 508 218 503 minecraft:red_terracotta
setblock 509 217 486 minecraft:terracotta
fill 509 217 487 509 220 487 minecraft:red_terracotta
setblock 509 217 491 minecraft:terracotta
fill 509 217 492 509 220 492 minecraft:red_terracotta
setblock 510 217 465 minecraft:terracotta
setblock 510 217 466 minecraft:red_terracotta
setblock 510 217 485 minecraft:terracotta
fill 510 217 486 510 220 486 minecraft:red_terracotta
setblock 510 217 490 minecraft:terracotta
fill 510 217 491 510 220 491 minecraft:red_terracotta
setblock 510 217 495 minecraft:terracotta
fill 510 217 496 510 220 496 minecraft:red_terracotta
setblock 511 217 464 minecraft:terracotta
fill 511 217 465 511 219 465 minecraft:red_terracotta
setblock 511 217 469 minecraft:terracotta
fill 511 217 470 511 220 470 minecraft:red_terracotta
setblock 511 217 484 minecraft:terracotta
fill 511 217 485 511 220 485 minecraft:red_terracotta
setblock 511 217 489 minecraft:terracotta
fill 511 217 490 511 220 490 minecraft:red_terracotta
setblock 511 217 494 minecraft:terracotta
fill 511 217 495 511 220 495 minecraft:red_terracotta
setblock 511 217 499 minecraft:terracotta
fill 511 217 500 511 220 500 minecraft:red_terracotta
setblock 511 217 504 minecraft:terracotta
setblock 471 218 468 minecraft:terracotta
fill 471 218 469 471 221 469 minecraft:red_terracotta
setblock 471 218 473 minecraft:terracotta
fill 471 218 474 471 221 474 minecraft:red_terracotta
setblock 471 218 478 minecraft:terracotta
fill 471 218 479 471 221 479 minecraft:red_terracotta
setblock 471 218 483 minecraft:terracotta
fill 471 218 484 471 221 484 minecraft:red_terracotta
setblock 471 218 488 minecraft:terracotta
fill 471 218 489 471 221 489 minecraft:red_terracotta
setblock 471 218 493 minecraft:terracotta
fill 471 218 494 471 221 494 minecraft:red_terracotta
setblock 472 218 487 minecraft:terracotta
fill 472 218 488 472 221 488 minecraft:red_terracotta
setblock 472 218 492 minecraft:terracotta
fill 472 218 493 472 221 493 minecraft:red_terracotta
setblock 484 218 465 minecraft:terracotta
fill 484 218 466 484 221 466 minecraft:red_terracotta
setblock 485 218 464 minecraft:terracotta
fill 485 218 465 485 221 465 minecraft:red_terracotta
fill 486 218 464 486 221 464 minecraft:red_terracotta
setblock 487 218 467 minecraft:terracotta
setblock 488 218 466 minecraft:terracotta
fill 488 218 467 488 220 467 minecraft:red_terracotta
setblock 489 218 465 minecraft:terracotta
fill 489 218 466 489 221 466 minecraft:red_terracotta
setblock 490 218 464 minecraft:terracotta
fill 490 218 465 490 221 465 minecraft:red_terracotta
setblock 490 218 504 minecraft:terracotta
fill 491 218 464 494 218 464 minecraft:red_terracotta
fill 491 218 504 491 221 504 minecraft:red_terracotta
setblock 494 218 465 minecraft:terracotta
setblock 495 218 464 minecraft:terracotta
setblock 495 218 465 minecraft:red_terracotta
fill 496 218 464 496 219 464 minecraft:red_terracotta
setblock 500 218 464 minecraft:terracotta
fill 501 218 464 501 219 464 minecraft:red_terracotta
setblock 505 218 464 minecraft:terracotta
setblock 505 218 465 minecraft:red_terracotta
setblock 505 218 504 minecraft:terracotta
fill 506 218 464 506 221 464 minecraft:red_terracotta
fill 506 218 504 506 221 504 minecraft:red_terracotta
setblock 507 218 503 minecraft:red_terracotta
setblock 508 218 491 minecraft:terracotta
setblock 509 218 465 minecraft:terracotta
setblock 509 218 490 minecraft:terracotta
fill 509 218 491 509 221 491 minecraft:red_terracotta
setblock 509 218 495 minecraft:terracotta
fill 509 218 496 509 221 496 minecraft:red_terracotta
setblock 510 218 464 minecraft:terracotta
setblock 510 218 484 minecraft:terracotta
fill 510 218 485 510 220 485 minecraft:red_terracotta
setblock 510 218 489 minecraft:terracotta
fill 510 218 490 510 221 490 minecraft:red_terracotta
setblock 510 218 494 minecraft:terracotta
fill 510 218 495 510 221 495 minecraft:red_terracotta
setblock 510 218 504 minecraft:terracotta
setblock 511 218 464 minecraft:red_terracotta
setblock 511 218 468 minecraft:terracotta
fill 511 218 469 511 221 469 minecraft:red_terracotta
setblock 511 218 473 minecraft:terracotta
setblock 511 218 483 minecraft:terracotta
fill 511 218 484 511 221 484 minecraft:red_terracotta
setblock 511 218 488 minecraft:terracotta
fill 511 218 489 511 221 489 minecraft:red_terracotta
setblock 511 218 493 minecraft:terracotta
fill 511 218 494 511 221 494 minecraft:red_terracotta
setblock 511 218 498 minecraft:terracotta
fill 511 218 499 511 221 499 minecraft:red_terracotta
setblock 511 218 503 minecraft:terracotta
setblock 511 218 504 minecraft:red_terracotta
setblock 471 219 467 minecraft:terracotta
fill 471 219 468 471 222 468 minecraft:red_terracotta
setblock 471 219 472 minecraft:terracotta
fill 471 219 473 471 222 473 minecraft:red_terracotta
setblock 471 219 477 minecraft:terracotta
fill 471 219 478 471 222 478 minecraft:red_terracotta
setblock 471 219 482 minecraft:terracotta
fill 471 219 483 471 222 483 minecraft:red_terracotta
setblock 471 219 487 minecraft:terracotta
fill 471 219 488 471 222 488 minecraft:red_terracotta
setblock 471 219 492 minecraft:terracotta
fill 471 219 493 471 222 493 minecraft:red_terracotta
setblock 471 219 497 minecraft:terracotta
setblock 472 219 486 minecraft:terracotta
fill 472 219 487 472 220 487 minecraft:red_terracotta
setblock 472 219 491 minecraft:terracotta
fill 472 219 492 472 222 492 minecraft:red_terracotta
setblock 483 219 465 minecraft:terracotta
setblock 484 219 464 minecraft:terracotta
fill 484 219 465 484 222 465 minecraft:red_terracotta
fill 485 219 464 485 222 464 minecraft:red_terracotta
setblock 486 219 467 minecraft:terracotta
setblock 487 219 466 minecraft:terracotta
fill 487 219 467 487 222 467 minecraft:red_terracotta
setblock 488 219 465 minecraft:terracotta
fill 488 219 466 488 222 466 minecraft:red_terracotta
setblock 489 219 464 minecraft:terracotta
fill 489 219 465 489 222 465 minecraft:red_terracotta
setblock 489 219 504 minecraft:terracotta
fill 490 219 464 493 219 464 minecraft:red_terracotta
fill 490 219 504 490 222 504 minecraft:red_terracotta
setblock 493 219 465 minecraft:terracotta
setblock 494 219 464 minecraft:terracotta
fill 495 219 464 495 220 464 minecraft:red_terracotta
setblock 504 219 464 minecraft:terracotta
setblock 504 219 504 minecraft:terracotta
fill 505 219 464 505 222 464 minecraft:red_terracotta
fill 505 219 504 505 222 504 minecraft:red_terracotta
setblock 508 219 490 minecraft:terracotta
fill 508 219 491 508 220 493 minecraft:red_terracotta
setblock 509 219 464 minecraft:terracotta
setblock 509 219 489 minecraft:terracotta
fill 509 219 490 509 222 490 minecraft:red_terracotta
setblock 509 219 494 minecraft:terracotta
fill 509 219 495 509 222 495 minecraft:red_terracotta
setblock 509 219 504 minecraft:terracotta
setblock 510 219 464 minecraft:red_terracotta
setblock 510 219 488 minecraft:terracotta
fill 510 219 489 510 222 489 minecraft:red_terracotta
setblock 510 219 493 minecraft:terracotta
fill 510 219 494 510 222 494 minecraft:red_terracotta
setblock 510 219 498 minecraft:terracotta
fill 510 219 504 510 220 504 minecraft:red_terracotta
setblock 511 219 467 minecraft:terracotta
fill 511 219 468 511 222 468 minecraft:red_terracotta
setblock 511 219 472 minecraft:terracotta
fill 511 219 473 511 222 473 minecraft:red_terracotta
fill 511 219 483 511 222 483 minecraft:red_terracotta
setblock 511 219 487 minecraft:terracotta
fill 511 219 488 511 222 488 minecraft:red_terracotta
setblock 511 219 492 minecraft:terracotta
fill 511 219 493 511 222 493 minecraft:red_terracotta
setblock 511 219 497 minecraft:terracotta
fill 511 219 498 511 222 498 minecraft:red_terracotta
setblock 471 220 466 minecraft:terracotta
fill 471 220 467 471 223 467 minecraft:red_terracotta
setblock 471 220 471 minecraft:terracotta
fill 471 220 472 472 222 472 minecraft:red_terracotta
setblock 471 220 476 minecraft:terracotta
fill 471 220 477 471 223 477 minecraft:red_terracotta
setblock 471 220 481 minecraft:terracotta
fill 471 220 482 471 223 482 minecraft:red_terracotta
setblock 471 220 486 minecraft:terracotta
fill 471 220 487 471 223 487 minecraft:red_terracotta
setblock 471 220 491 minecraft:terracotta
fill 471 220 492 471 223 492 minecraft:red_terracotta
setblock 471 220 496 minecraft:terracotta
fill 471 220 497 471 223 497 minecraft:red_terracotta
setblock 472 220 470 minecraft:terracotta
fill 472 220 471 472 223 471 minecraft:red_terracotta
setblock 472 220 486 minecraft:red_terracotta
setblock 472 220 490 minecraft:terracotta
fill 472 220 491 472 223 491 minecraft:red_terracotta
fill 481 220 464 481 221 464 minecraft:red_terracotta
setblock 482 220 465 minecraft:terracotta
setblock 483 220 464 minecraft:terracotta
fill 483 220 465 483 223 465 minecraft:red_terracotta
fill 484 220 464 484 223 464 minecraft:red_terracotta
setblock 486 220 466 minecraft:terracotta
fill 486 220 467 486 223 467 minecraft:red_terracotta
fill 486 220 504 486 221 504 minecraft:red_terracotta
setblock 487 220 465 minecraft:terracotta
fill 487 220 466 487 223 466 minecraft:red_terracotta
setblock 488 220 464 minecraft:terracotta
fill 488 220 465 488 223 465 minecraft:red_terracotta
setblock 488 220 504 minecraft:terracotta
fill 489 220 464 492 220 464 minecraft:red_terracotta
fill 489 220 504 489 223 504 minecraft:red_terracotta
setblock 491 220 466 minecraft:terracotta
setblock 492 220 465 minecraft:terracotta
setblock 493 220 464 minecraft:terracotta
setblock 493 220 465 minecraft:red_terracotta
fill 494 220 464 494 221 464 minecraft:red_terracotta
setblock 503 220 464 minecraft:terracotta
setblock 503 220 504 minecraft:terracotta
fill 504 220 464 504 223 464 minecraft:red_terracotta
fill 504 220 504 504 223 504 minecraft:red_terracotta
setblock 508 220 464 minecraft:terracotta
fill 508 220 490 508 223 490 minecraft:red_terracotta
setblock 508 220 494 minecraft:terracotta
setblock 508 220 504 minecraft:terracotta
setblock 509 220 464 minecraft:red_terracotta
setblock 509 220 488 minecraft:terracotta
fill 509 220 489 509 223 489 minecraft:red_terracotta
setblock 509 220 493 minecraft:terracotta
fill 509 220 494 509 223 494 minecraft:red_terracotta
setblock 509 220 497 minecraft:red_terracotta
fill 509 220 504 509 223 504 minecraft:red_terracotta
setblock 510 220 487 minecraft:terracotta
fill 510 220 488 510 223 488 minecraft:red_terracotta
setblock 510 220 492 minecraft:terracotta
fill 510 220 493 510 223 493 minecraft:red_terracotta
setblock 510 220 497 minecraft:terracotta
fill 510 220 498 510 223 498 minecraft:red_terracotta
fill 511 220 467 511 221 467 minecraft:red_terracotta
setblock 511 220 471 minecraft:terracotta
fill 511 220 472 511 223 472 minecraft:red_terracotta
fill 511 220 474 511 221 474 minecraft:red_terracotta
setblock 511 220 486 minecraft:terracotta
fill 511 220 487 511 223 487 minecraft:red_terracotta
setblock 511 220 491 minecraft:terracotta
fill 511 220 492 511 223 492 minecraft:red_terracotta
setblock 511 220 496 minecraft:terracotta
fill 511 220 497 511 223 497 minecraft:red_terracotta
setblock 471 221 470 minecraft:terracotta
fill 471 221 471 471 224 471 minecraft:red_terracotta
setblock 471 221 475 minecraft:terracotta
fill 471 221 476 471 224 476 minecraft:red_terracotta
setblock 471 221 480 minecraft:terracotta
fill 471 221 481 471 224 481 minecraft:red_terracotta
setblock 471 221 485 minecraft:terracotta
fill 471 221 486 471 224 486 minecraft:red_terracotta
setblock 471 221 490 minecraft:terracotta
fill 471 221 491 471 224 491 minecraft:red_terracotta
setblock 471 221 495 minecraft:terracotta
fill 471 221 496 471 224 496 minecraft:red_terracotta
fill 472 221 470 472 224 470 minecraft:red_terracotta
setblock 472 221 473 minecraft:red_terracotta
setblock 472 221 474 minecraft:terracotta
setblock 472 221 489 minecraft:terracotta
fill 472 221 490 472 223 490 minecraft:red_terracotta
setblock 473 221 466 minecraft:light[level=14]
fill 473 221 471 475 222 472 minecraft:terracotta
setblock 473 221 474 minecraft:light[level=14]
setblock 473 221 482 minecraft:light[level=14]
setblock 473 221 490 minecraft:light[level=14]
setblock 473 221 498 minecraft:light[level=14]
fill 476 221 472 481 222 472 minecraft:terracotta
fill 477 221 473 484 222 473 minecraft:terracotta
fill 480 221 478 480 222 479 minecraft:orange_concrete
setblock 481 221 466 minecraft:light[level=14]
setblock 481 221 474 minecraft:light[level=14]
setblock 481 221 482 minecraft:light[level=14]
setblock 481 221 490 minecraft:light[level=14]
setblock 481 221 498 minecraft:light[level=14]
setblock 482 221 464 minecraft:terracotta
fill 482 221 465 482 224 465 minecraft:red_terracotta
fill 483 221 464 483 224 464 minecraft:red_terracotta
fill 483 221 466 483 222 466 minecraft:red_terracotta
setblock 485 221 466 minecraft:terracotta
fill 485 221 504 485 222 504 minecraft:red_terracotta
setblock 486 221 465 minecraft:terracotta
fill 486 221 466 486 224 466 minecraft:red_terracotta
setblock 487 221 464 minecraft:terracotta
fill 487 221 465 487 224 465 minecraft:red_terracotta
setblock 487 221 504 minecraft:terracotta
fill 488 221 464 491 221 464 minecraft:red_terracotta
fill 488 221 504 488 224 504 minecraft:red_terracotta
setblock 489 221 474 minecraft:light[level=14]
setblock 489 221 482 minecraft:light[level=14]
setblock 489 221 490 minecraft:light[level=14]
setblock 489 221 498 minecraft:light[level=14]
setblock 490 221 466 minecraft:terracotta
setblock 491 221 465 minecraft:terracotta
setblock 492 221 464 minecraft:terracotta
setblock 492 221 465 minecraft:red_terracotta
fill 492 221 484 493 221 489 minecraft:orange_concrete
fill 493 221 464 493 224 464 minecraft:red_terracotta
fill 493 221 483 499 221 483 minecraft:orange_concrete
fill 493 221 490 499 221 490 minecraft:orange_concrete
fill 494 221 482 498 221 482 minecraft:orange_concrete
fill 494 221 484 494 223 484 minecraft:orange_concrete
fill 494 221 489 495 223 489 minecraft:orange_concrete
fill 494 221 491 497 221 491 minecraft:orange_concrete
setblock 497 221 466 minecraft:light[level=14]
setblock 497 221 474 minecraft:light[level=14]
fill 497 221 489 500 221 489 minecraft:orange_concrete
setblock 497 221 498 minecraft:light[level=14]
fill 498 221 484 500 221 484 minecraft:orange_concrete
fill 498 221 488 500 221 488 minecraft:orange_concrete
fill 499 221 485 500 221 487 minecraft:orange_concrete
setblock 501 221 504 minecraft:red_terracotta
setblock 502 221 464 minecraft:terracotta
setblock 502 221 504 minecraft:terracotta
fill 503 221 464 503 224 464 minecraft:red_terracotta
fill 503 221 504 503 224 504 minecraft:red_terracotta
setblock 505 221 466 minecraft:light[level=14]
setblock 505 221 474 minecraft:light[level=14]
setblock 505 221 482 minecraft:light[level=14]
setblock 505 221 490 minecraft:light[level=14]
setblock 505 221 498 minecraft:light[level=14]
fill 505 221 503 506 222 503 minecraft:red_terracotta
setblock 507 221 464 minecraft:terracotta
setblock 507 221 504 minecraft:terracotta
fill 508 221 464 508 222 464 minecraft:red_terracotta
fill 508 221 491 508 221 492 minecraft:red_terracotta
setblock 508 221 493 minecraft:terracotta
fill 508 221 494 508 223 495 minecraft:red_terracotta
fill 508 221 504 508 224 504 minecraft:red_terracotta
fill 509 221 488 509 224 488 minecraft:red_terracotta
setblock 509 221 492 minecraft:terracotta
fill 509 221 493 509 224 493 minecraft:red_terracotta
setblock 509 221 497 minecraft:terracotta
setblock 510 221 486 minecraft:terracotta
fill 510 221 487 510 224 487 minecraft:red_terracotta
setblock 510 221 491 minecraft:terracotta
fill 510 221 492 510 224 492 minecraft:red_terracotta
setblock 510 221 496 minecraft:terracotta
fill 510 221 497 510 224 497 minecraft:red_terracotta
fill 510 221 499 510 222 499 minecraft:red_terracotta
setblock 511 221 470 minecraft:terracotta
fill 511 221 471 511 224 471 minecraft:red_terracotta
setblock 511 221 475 minecraft:terracotta
fill 511 221 476 511 224 476 minecraft:red_terracotta
setblock 511 221 485 minecraft:terracotta
fill 511 221 486 511 224 486 minecraft:red_terracotta
setblock 511 221 490 minecraft:terracotta
fill 511 221 491 511 224 491 minecraft:red_terracotta
setblock 511 221 495 minecraft:terracotta
fill 511 221 496 511 224 496 minecraft:red_terracotta
setblock 511 221 500 minecraft:terracotta
setblock 471 222 469 minecraft:terracotta
fill 471 222 470 471 224 470 minecraft:red_terracotta
setblock 471 222 474 minecraft:terracotta
fill 471 222 475 472 224 475 minecraft:red_terracotta
setblock 471 222 479 minecraft:terracotta
fill 471 222 480 471 224 480 minecraft:red_terracotta
setblock 471 222 484 minecraft:terracotta
fill 471 222 485 471 224 485 minecraft:red_terracotta
setblock 471 222 489 minecraft:terracotta
fill 471 222 490 471 224 490 minecraft:red_terracotta
setblock 471 222 494 minecraft:terracotta
fill 471 222 495 471 224 495 minecraft:red_terracotta
setblock 472 222 473 minecraft:terracotta
fill 472 222 474 472 224 474 minecraft:red_terracotta
fill 472 222 476 472 223 476 minecraft:red_terracotta
setblock 472 222 489 minecraft:red_terracotta
setblock 472 222 493 minecraft:terracotta
fill 472 222 494 472 224 494 minecraft:red_terracotta
fill 475 222 473 476 222 473 minecraft:terracotta
fill 476 222 471 477 222 471 minecraft:terracotta
setblock 480 222 464 minecraft:red_terracotta
setblock 481 222 464 minecraft:terracotta
fill 481 222 465 481 224 465 minecraft:red_terracotta
fill 482 222 464 482 224 464 minecraft:red_terracotta
fill 482 222 472 485 222 472 minecraft:terracotta
fill 483 222 474 499 222 474 minecraft:terracotta
setblock 484 222 466 minecraft:terracotta
fill 484 222 504 484 223 504 minecraft:red_terracotta
setblock 485 222 465 minecraft:terracotta
fill 485 222 466 485 224 467 minecraft:red_terracotta
fill 485 222 473 493 223 473 minecraft:terracotta
setblock 486 222 464 minecraft:terracotta
fill 486 222 465 486 224 465 minecraft:red_terracotta
setblock 486 222 504 minecraft:terracotta
fill 487 222 464 490 222 464 minecraft:red_terracotta
fill 487 222 504 487 224 504 minecraft:red_terracotta
setblock 489 222 466 minecraft:terracotta
setblock 490 222 465 minecraft:terracotta
setblock 491 222 464 minecraft:terracotta
fill 491 222 465 491 223 465 minecraft:red_terracotta
setblock 491 222 504 minecraft:terracotta
fill 492 222 464 492 224 464 minecraft:red_terracotta
fill 492 222 485 493 222 488 minecraft:orange_concrete
fill 493 222 475 503 223 475 minecraft:terracotta
setblock 493 222 484 minecraft:orange_concrete
setblock 493 222 489 minecraft:orange_concrete
fill 494 222 483 498 222 483 minecraft:orange_concrete
fill 494 222 490 498 222 490 minecraft:orange_concrete
fill 497 222 489 499 222 489 minecraft:orange_concrete
fill 498 222 484 499 222 484 minecraft:orange_concrete
fill 498 222 488 499 222 488 minecraft:orange_concrete
fill 499 222 485 499 223 487 minecraft:orange_concrete
fill 500 222 486 500 222 487 minecraft:orange_concrete
setblock 500 222 504 minecraft:red_terracotta
setblock 501 222 464 minecraft:terracotta
setblock 501 222 504 minecraft:terracotta
fill 502 222 464 502 224 464 minecraft:red_terracotta
fill 502 222 504 502 224 504 minecraft:red_terracotta
fill 503 222 503 504 224 503 minecraft:red_terracotta
setblock 506 222 464 minecraft:terracotta
setblock 506 222 504 minecraft:terracotta
fill 507 222 464 507 224 464 minecraft:red_terracotta
setblock 507 222 503 minecraft:terracotta
fill 507 222 504 507 224 504 minecraft:red_terracotta
setblock 508 222 491 minecraft:red_terracotta
setblock 508 222 492 minecraft:terracotta
fill 508 222 493 508 224 493 minecraft:red_terracotta
setblock 508 222 496 minecraft:red_terracotta
setblock 509 222 491 minecraft:terracotta
fill 509 222 492 509 224 492 minecraft:red_terracotta
setblock 509 222 496 minecraft:terracotta
fill 509 222 497 509 224 498 minecraft:red_terracotta
fill 510 222 472 510 223 473 minecraft:red_terracotta
fill 510 222 486 510 224 486 minecraft:red_terracotta
setblock 510 222 490 minecraft:terracotta
fill 510 222 491 510 224 491 minecraft:red_terracotta
setblock 510 222 495 minecraft:terracotta
fill 510 222 496 510 224 496 minecraft:red_terracotta
setblock 511 222 469 minecraft:terracotta
fill 511 222 470 511 224 470 minecraft:red_terracotta
setblock 511 222 474 minecraft:terracotta
fill 511 222 475 511 224 475 minecraft:red_terracotta
fill 511 222 477 511 222 478 minecraft:red_terracotta
setblock 511 222 484 minecraft:terracotta
fill 511 222 485 511 224 485 minecraft:red_terracotta
setblock 511 222 489 minecraft:terracotta
fill 511 222 490 511 224 490 minecraft:red_terracotta
setblock 511 222 494 minecraft:terracotta
fill 511 222 495 511 224 495 minecraft:red_terracotta
setblock 511 222 499 minecraft:terracotta
fill 511 222 500 511 224 501 minecraft:red_terracotta
setblock 471 223 468 minecraft:terracotta
fill 471 223 469 471 224 469 minecraft:red_terracotta
setblock 471 223 472 minecraft:red_terracotta
setblock 471 223 473 minecraft:terracotta
fill 471 223 474 471 224 474 minecraft:red_terracotta
setblock 471 223 478 minecraft:terracotta
fill 471 223 479 471 224 479 minecraft:red_terracotta
setblock 471 223 483 minecraft:terracotta
fill 471 223 484 471 224 484 minecraft:red_terracotta
setblock 471 223 488 minecraft:terracotta
fill 471 223 489 471 224 489 minecraft:red_terracotta
setblock 471 223 493 minecraft:terracotta
fill 471 223 494 471 224 494 minecraft:red_terracotta
setblock 471 223 498 minecraft:terracotta
setblock 472 223 472 minecraft:terracotta
fill 472 223 473 472 224 473 minecraft:red_terracotta
setblock 472 223 477 minecraft:terracotta
setblock 472 223 492 minecraft:terracotta
fill 472 223 493 472 224 493 minecraft:red_terracotta
fill 473 223 472 476 223 472 minecraft:orange_concrete
fill 477 223 472 482 223 472 minecraft:terracotta
setblock 480 223 464 minecraft:terracotta
fill 480 223 473 484 223 473 minecraft:terracotta
fill 481 223 464 481 224 464 minecraft:red_terracotta
setblock 482 223 466 minecraft:red_terracotta
setblock 483 223 466 minecraft:terracotta
fill 483 223 504 483 224 504 minecraft:red_terracotta
setblock 484 223 465 minecraft:terracotta
fill 484 223 466 484 224 467 minecraft:red_terracotta
setblock 485 223 464 minecraft:terracotta
fill 485 223 465 485 224 465 minecraft:red_terracotta
fill 485 223 474 503 223 474 minecraft:terracotta
setblock 485 223 504 minecraft:terracotta
fill 486 223 464 489 223 464 minecraft:red_terracotta
fill 486 223 504 486 224 504 minecraft:red_terracotta
setblock 488 223 466 minecraft:terracotta
setblock 489 223 465 minecraft:terracotta
setblock 489 223 466 minecraft:red_terracotta
setblock 490 223 464 minecraft:terracotta
fill 490 223 465 490 224 465 minecraft:red_terracotta
setblock 490 223 504 minecraft:terracotta
fill 491 223 464 491 224 464 minecraft:red_terracotta
fill 491 223 504 491 224 504 minecraft:red_terracotta
setblock 492 223 475 minecraft:terracotta
fill 493 223 485 493 223 488 minecraft:orange_concrete
setblock 494 223 473 minecraft:terracotta
setblock 496 223 483 minecraft:orange_concrete
fill 497 223 489 498 223 489 minecraft:orange_concrete
setblock 498 223 484 minecraft:orange_concrete
setblock 498 223 488 minecraft:orange_concrete
fill 498 223 504 499 223 504 minecraft:red_terracotta
setblock 500 223 464 minecraft:terracotta
fill 500 223 476 510 223 476 minecraft:terracotta
setblock 500 223 504 minecraft:terracotta
fill 501 223 464 501 224 464 minecraft:red_terracotta
fill 501 223 504 501 224 504 minecraft:red_terracotta
fill 502 223 503 502 224 503 minecraft:red_terracotta
fill 504 223 475 509 224 475 minecraft:terracotta
setblock 505 223 464 minecraft:terracotta
setblock 505 223 503 minecraft:red_terracotta
setblock 505 223 504 minecraft:terracotta
fill 506 223 464 506 224 464 minecraft:red_terracotta
setblock 506 223 503 minecraft:terracotta
fill 506 223 504 506 224 504 minecraft:red_terracotta
fill 507 223 503 507 224 503 minecraft:red_terracotta
setblock 508 223 491 minecraft:terracotta
fill 508 223 492 508 224 492 minecraft:red_terracotta
setblock 508 223 496 minecraft:terracotta
fill 508 223 497 508 224 497 minecraft:red_terracotta
setblock 509 223 477 minecraft:terracotta
setblock 509 223 490 minecraft:terracotta
fill 509 223 491 509 224 491 minecraft:red_terracotta
setblock 509 223 495 minecraft:terracotta
fill 509 223 496 509 224 496 minecraft:red_terracotta
fill 510 223 471 510 224 471 minecraft:red_terracotta
setblock 510 223 474 minecraft:terracotta
fill 510 223 475 510 224 475 minecraft:red_terracotta
setblock 510 223 489 minecraft:terracotta
fill 510 223 490 510 224 490 minecraft:red_terracotta
setblock 510 223 494 minecraft:terracotta
fill 510 223 495 510 224 495 minecraft:red_terracotta
setblock 510 223 499 minecraft:terracotta
fill 510 223 500 510 224 500 minecraft:red_terracotta
setblock 511 223 468 minecraft:terracotta
fill 511 223 469 511 224 469 minecraft:red_terracotta
setblock 511 223 473 minecraft:terracotta
fill 511 223 474 511 224 474 minecraft:red_terracotta
setblock 511 223 477 minecraft:red_terracotta
setblock 511 223 478 minecraft:terracotta
fill 511 223 479 511 223 482 minecraft:red_terracotta
setblock 511 223 483 minecraft:terracotta
fill 511 223 484 511 224 484 minecraft:red_terracotta
setblock 511 223 488 minecraft:terracotta
fill 511 223 489 511 224 489 minecraft:red_terracotta
setblock 511 223 493 minecraft:terracotta
fill 511 223 494 511 224 494 minecraft:red_terracotta
setblock 511 223 498 minecraft:terracotta
fill 511 223 499 511 224 499 minecraft:red_terracotta
setblock 471 224 467 minecraft:terracotta
setblock 471 224 468 minecraft:red_terracotta
setblock 471 224 472 minecraft:terracotta
setblock 471 224 473 minecraft:red_terracotta
setblock 471 224 477 minecraft:terracotta
fill 471 224 478 472 224 478 minecraft:red_terracotta
setblock 471 224 482 minecraft:terracotta
setblock 471 224 483 minecraft:red_terracotta
setblock 471 224 487 minecraft:terracotta
setblock 471 224 488 minecraft:red_terracotta
setblock 471 224 492 minecraft:terracotta
setblock 471 224 493 minecraft:red_terracotta
setblock 471 224 497 minecraft:terracotta
setblock 471 224 498 minecraft:red_terracotta
setblock 472 224 471 minecraft:terracotta
setblock 472 224 472 minecraft:red_terracotta
setblock 472 224 476 minecraft:terracotta
setblock 472 224 477 minecraft:red_terracotta
setblock 472 224 492 minecraft:red_terracotta
setblock 479 224 464 minecraft:terracotta
fill 480 224 464 480 224 465 minecraft:red_terracotta
fill 481 224 473 489 224 473 minecraft:orange_concrete
setblock 482 224 466 minecraft:terracotta
setblock 482 224 504 minecraft:red_terracotta
setblock 483 224 465 minecraft:terracotta
setblock 483 224 466 minecraft:red_terracotta
setblock 484 224 464 minecraft:terracotta
setblock 484 224 465 minecraft:red_terracotta
setblock 484 224 504 minecraft:terracotta
fill 485 224 464 488 224 464 minecraft:red_terracotta
setblock 485 224 503 minecraft:terracotta
setblock 485 224 504 minecraft:red_terracotta
fill 486 224 503 488 224 503 minecraft:red_terracotta
setblock 487 224 466 minecraft:terracotta
setblock 488 224 465 minecraft:terracotta
setblock 488 224 466 minecraft:red_terracotta
setblock 489 224 464 minecraft:terracotta
setblock 489 224 465 minecraft:red_terracotta
fill 489 224 474 496 224 474 minecraft:orange_concrete
setblock 489 224 504 minecraft:terracotta
setblock 490 224 464 minecraft:red_terracotta
setblock 490 224 504 minecraft:red_terracotta
setblock 492 224 504 minecraft:red_terracotta
fill 496 224 504 498 224 504 minecraft:red_terracotta
fill 498 224 475 503 224 475 minecraft:terracotta
setblock 499 224 504 minecraft:terracotta
setblock 500 224 464 minecraft:red_terracotta
setblock 500 224 503 minecraft:terracotta
setblock 500 224 504 minecraft:red_terracotta
setblock 501 224 503 minecraft:red_terracotta
fill 503 224 476 509 224 476 minecraft:terracotta
fill 503 224 502 505 224 502 minecraft:red_terracotta
setblock 504 224 464 minecraft:terracotta
setblock 504 224 504 minecraft:terracotta
setblock 505 224 464 minecraft:red_terracotta
setblock 505 224 503 minecraft:terracotta
setblock 505 224 504 minecraft:red_terracotta
setblock 506 224 503 minecraft:red_terracotta
fill 507 224 494 508 224 494 minecraft:red_terracotta
setblock 508 224 490 minecraft:terracotta
setblock 508 224 491 minecraft:red_terracotta
setblock 508 224 495 minecraft:terracotta
setblock 508 224 496 minecraft:red_terracotta
setblock 509 224 489 minecraft:terracotta
setblock 509 224 490 minecraft:red_terracotta
setblock 509 224 494 minecraft:terracotta
setblock 509 224 495 minecraft:red_terracotta
setblock 509 224 499 minecraft:terracotta
setblock 509 224 504 minecraft:terracotta
setblock 510 224 472 minecraft:red_terracotta
setblock 510 224 473 minecraft:terracotta
setblock 510 224 474 minecraft:red_terracotta
fill 510 224 476 510 224 477 minecraft:red_terracotta
setblock 510 224 488 minecraft:terracotta
setblock 510 224 489 minecraft:red_terracotta
setblock 510 224 493 minecraft:terracotta
setblock 510 224 494 minecraft:red_terracotta
setblock 510 224 498 minecraft:terracotta
setblock 510 224 499 minecraft:red_terracotta
setblock 511 224 472 minecraft:terracotta
setblock 511 224 473 minecraft:red_terracotta
setblock 511 224 477 minecraft:terracotta
fill 511 224 478 511 224 481 minecraft:red_terracotta
setblock 511 224 482 minecraft:terracotta
setblock 511 224 483 minecraft:red_terracotta
setblock 511 224 487 minecraft:terracotta
setblock 511 224 488 minecraft:red_terracotta
setblock 511 224 492 minecraft:terracotta
setblock 511 224 493 minecraft:red_terracotta
setblock 511 224 497 minecraft:terracotta
setblock 511 224 498 minecraft:red_terracotta
setblock 470 228 466 minecraft:orange_terracotta
fill 470 228 467 470 228 470 minecraft:red_terracotta
fill 470 228 476 470 229 479 minecraft:red_terracotta
setblock 470 228 480 minecraft:orange_terracotta
fill 470 228 481 470 231 481 minecraft:red_terracotta
setblock 470 228 482 minecraft:orange_terracotta
fill 470 228 483 470 228 492 minecraft:red_terracotta
setblock 470 228 503 minecraft:orange_terracotta
fill 470 228 504 470 231 504 minecraft:red_terracotta
fill 484 228 505 484 230 505 minecraft:orange_terracotta
setblock 487 228 505 minecraft:orange_terracotta
fill 488 228 505 488 229 505 minecraft:red_terracotta
setblock 492 228 463 minecraft:orange_terracotta
fill 493 228 463 496 228 463 minecraft:red_terracotta
fill 500 228 505 507 228 505 minecraft:red_terracotta
setblock 502 228 463 minecraft:orange_terracotta
fill 508 228 505 509 228 505 minecraft:orange_terracotta
setblock 510 228 463 minecraft:orange_terracotta
fill 510 228 505 512 231 505 minecraft:red_terracotta
setblock 512 228 465 minecraft:red_terracotta
fill 512 228 466 512 230 466 minecraft:orange_terracotta
fill 512 228 467 512 228 473 minecraft:red_terracotta
fill 512 228 474 512 229 474 minecraft:orange_terracotta
fill 512 228 475 512 229 477 minecraft:red_terracotta
setblock 512 228 478 minecraft:orange_terracotta
setblock 512 228 479 minecraft:red_terracotta
setblock 512 228 483 minecraft:orange_terracotta
fill 470 229 466 470 231 467 minecraft:red_terracotta
setblock 470 229 468 minecraft:orange_terracotta
fill 470 229 469 470 231 470 minecraft:red_terracotta
fill 470 229 480 470 231 480 minecraft:red_terracotta
fill 470 229 482 470 229 483 minecraft:red_terracotta
setblock 470 229 484 minecraft:orange_terracotta
fill 470 229 485 470 231 490 minecraft:red_terracotta
setblock 470 229 491 minecraft:orange_terracotta
fill 470 229 492 470 231 492 minecraft:red_terracotta
setblock 470 229 493 minecraft:orange_terracotta
fill 470 229 494 470 231 495 minecraft:red_terracotta
setblock 470 229 498 minecraft:orange_terracotta
fill 470 229 499 470 231 503 minecraft:red_terracotta
setblock 471 229 505 minecraft:orange_terracotta
fill 472 229 463 473 231 463 minecraft:red_terracotta
fill 472 229 505 477 231 505 minecraft:red_terracotta
setblock 473 229 466 minecraft:light[level=14]
setblock 473 229 474 minecraft:light[level=14]
setblock 473 229 482 minecraft:light[level=14]
setblock 473 229 490 minecraft:light[level=14]
setblock 473 229 498 minecraft:light[level=14]
setblock 474 229 463 minecraft:orange_terracotta
fill 475 229 463 475 231 463 minecraft:red_terracotta
setblock 477 229 463 minecraft:orange_terracotta
fill 478 229 463 478 231 463 minecraft:red_terracotta
fill 479 229 505 479 231 505 minecraft:red_terracotta
setblock 480 229 505 minecraft:orange_terracotta
setblock 481 229 466 minecraft:light[level=14]
setblock 481 229 474 minecraft:light[level=14]
setblock 481 229 482 minecraft:light[level=14]
setblock 481 229 490 minecraft:light[level=14]
setblock 481 229 498 minecraft:light[level=14]
fill 481 229 505 483 231 505 minecraft:red_terracotta
fill 487 229 505 487 232 505 minecraft:red_terracotta
setblock 489 229 466 minecraft:light[level=14]
setblock 489 229 474 minecraft:light[level=14]
setblock 489 229 482 minecraft:light[level=14]
setblock 489 229 490 minecraft:light[level=14]
setblock 489 229 498 minecraft:light[level=14]
fill 490 229 505 492 231 505 minecraft:red_terracotta
setblock 491 229 463 minecraft:orange_terracotta
fill 492 229 463 494 229 463 minecraft:red_terracotta
setblock 493 229 505 minecraft:orange_terracotta
fill 494 229 505 497 231 505 minecraft:red_terracotta
setblock 495 229 463 minecraft:orange_terracotta
fill 496 229 463 496 231 463 minecraft:red_terracotta
setblock 497 229 466 minecraft:light[level=14]
setblock 497 229 474 minecraft:light[level=14]
setblock 497 229 482 minecraft:light[level=14]
setblock 497 229 490 minecraft:light[level=14]
setblock 497 229 498 minecraft:light[level=14]
fill 500 229 505 503 231 505 minecraft:red_terracotta
fill 502 229 463 502 231 463 minecraft:red_terracotta
fill 504 229 505 505 229 505 minecraft:orange_terracotta
setblock 505 229 466 minecraft:light[level=14]
setblock 505 229 474 minecraft:light[level=14]
setblock 505 229 482 minecraft:light[level=14]
setblock 505 229 490 minecraft:light[level=14]
setblock 505 229 498 minecraft:light[level=14]
fill 506 229 505 509 229 505 minecraft:red_terracotta
fill 510 229 463 510 231 463 minecraft:red_terracotta
setblock 512 229 465 minecraft:orange_terracotta
fill 512 229 467 512 231 468 minecraft:red_terracotta
fill 512 229 469 512 229 471 minecraft:orange_terracotta
fill 512 229 472 512 231 473 minecraft:red_terracotta
fill 512 229 478 512 231 478 minecraft:red_terracotta
fill 512 229 479 512 230 479 minecraft:orange_terracotta
fill 512 229 483 512 233 483 minecraft:red_terracotta
setblock 512 229 492 minecraft:orange_terracotta
fill 512 229 493 512 231 493 minecraft:red_terracotta
setblock 512 229 494 minecraft:orange_terracotta
fill 512 229 502 512 231 503 minecraft:red_terracotta
setblock 512 229 504 minecraft:orange_terracotta
setblock 470 230 463 minecraft:orange_terracotta
fill 470 230 464 470 231 464 minecraft:red_terracotta
setblock 470 230 465 minecraft:orange_terracotta
fill 470 230 468 470 231 468 minecraft:red_terracotta
fill 470 230 472 470 231 473 minecraft:red_terracotta
setblock 470 230 474 minecraft:orange_terracotta
fill 470 230 475 470 231 475 minecraft:red_terracotta
setblock 470 230 476 minecraft:orange_terracotta
fill 470 230 477 470 231 479 minecraft:red_terracotta
setblock 470 230 482 minecraft:orange_terracotta
fill 470 230 483 470 231 484 minecraft:red_terracotta
fill 470 230 491 470 231 491 minecraft:red_terracotta
fill 470 230 493 470 231 493 minecraft:red_terracotta
fill 470 230 498 470 232 498 minecraft:red_terracotta
fill 471 230 482 486 230 488 minecraft:terracotta
fill 471 230 505 471 231 505 minecraft:red_terracotta
fill 474 230 463 474 231 463 minecraft:red_terracotta
fill 477 230 463 477 231 463 minecraft:red_terracotta
setblock 478 230 505 minecraft:orange_terracotta
fill 480 230 505 480 231 505 minecraft:red_terracotta
fill 486 230 467 492 230 481 minecraft:terracotta
fill 486 230 489 492 230 503 minecraft:terracotta
fill 487 230 482 487 230 484 minecraft:terracotta
fill 487 230 486 487 230 488 minecraft:terracotta
fill 488 230 482 488 230 483 minecraft:terracotta
fill 488 230 487 488 230 488 minecraft:terracotta
setblock 488 230 505 minecraft:orange_terracotta
fill 489 230 482 507 230 482 minecraft:terracotta
fill 489 230 488 507 230 488 minecraft:terracotta
fill 490 230 483 507 230 483 minecraft:terracotta
fill 490 230 487 507 230 487 minecraft:terracotta
fill 491 230 463 493 231 463 minecraft:red_terracotta
fill 491 230 484 507 230 484 minecraft:terracotta
fill 491 230 486 507 230 486 minecraft:terracotta
fill 492 230 485 507 230 485 minecraft:terracotta
fill 493 230 505 493 231 505 minecraft:red_terracotta
setblock 494 230 463 minecraft:orange_terracotta
fill 495 230 463 495 231 463 minecraft:red_terracotta
setblock 498 230 463 minecraft:orange_terracotta
setblock 500 230 463 minecraft:orange_terracotta
fill 501 230 463 501 231 463 minecraft:red_terracotta
setblock 503 230 463 minecraft:orange_terracotta
fill 504 230 463 506 231 463 minecraft:red_terracotta
fill 504 230 505 508 231 505 minecraft:red_terracotta
setblock 507 230 463 minecraft:orange_terracotta
fill 508 230 463 509 231 463 minecraft:red_terracotta
setblock 509 230 505 minecraft:orange_terracotta
fill 512 230 465 512 231 465 minecraft:red_terracotta
fill 512 230 469 512 231 471 minecraft:red_terracotta
fill 512 230 474 512 231 475 minecraft:red_terracotta
setblock 512 230 476 minecraft:orange_terracotta
fill 512 230 477 512 231 477 minecraft:red_terracotta
setblock 512 230 480 minecraft:orange_terracotta
setblock 512 230 490 minecraft:orange_terracotta
fill 512 230 492 512 232 492 minecraft:red_terracotta
fill 512 230 494 512 231 494 minecraft:red_terracotta
fill 512 230 497 512 231 497 minecraft:red_terracotta
setblock 512 230 498 minecraft:orange_terracotta
fill 512 230 500 512 230 501 minecraft:orange_terracotta
fill 512 230 504 512 231 504 minecraft:red_terracotta
setblock 470 231 463 minecraft:red_terracotta
setblock 470 231 465 minecraft:red_terracotta
setblock 470 231 474 minecraft:red_terracotta
setblock 470 231 476 minecraft:red_terracotta
setblock 470 231 482 minecraft:red_terracotta
fill 471 231 464 485 231 481 minecraft:brown_terracotta
fill 471 231 482 487 231 482 minecraft:orange_terracotta
fill 471 231 483 485 231 487 minecraft:terracotta
fill 471 231 488 487 231 488 minecraft:orange_terracotta
fill 471 231 489 485 231 504 minecraft:brown_terracotta
setblock 478 231 505 minecraft:red_terracotta
setblock 484 231 505 minecraft:red_terracotta
fill 486 231 464 511 231 466 minecraft:brown_terracotta
fill 486 231 467 486 231 481 minecraft:orange_terracotta
setblock 486 231 483 minecraft:orange_terracotta
fill 486 231 484 486 231 486 minecraft:shroomlight
setblock 486 231 487 minecraft:orange_terracotta
fill 486 231 489 486 231 503 minecraft:orange_terracotta
fill 486 231 504 511 231 504 minecraft:brown_terracotta
fill 487 231 467 491 231 481 minecraft:terracotta
fill 487 231 483 487 231 484 minecraft:shroomlight
fill 487 231 486 487 231 487 minecraft:shroomlight
fill 487 231 489 491 231 503 minecraft:terracotta
fill 488 231 482 488 231 483 minecraft:shroomlight
fill 488 231 487 488 231 488 minecraft:shroomlight
setblock 488 231 505 minecraft:red_terracotta
fill 489 231 482 490 231 482 minecraft:shroomlight
fill 489 231 488 490 231 488 minecraft:shroomlight
fill 490 231 483 491 231 483 minecraft:shroomlight
fill 490 231 487 491 231 487 minecraft:shroomlight
fill 491 231 482 507 231 482 minecraft:orange_terracotta
fill 491 231 484 492 231 484 minecraft:shroomlight
fill 491 231 486 492 231 486 minecraft:shroomlight
fill 491 231 488 507 231 488 minecraft:orange_terracotta
fill 492 231 467 492 231 481 minecraft:orange_terracotta
setblock 492 231 483 minecraft:orange_terracotta
setblock 492 231 485 minecraft:shroomlight
setblock 492 231 487 minecraft:orange_terracotta
fill 492 231 489 492 231 503 minecraft:orange_terracotta
fill 493 231 467 511 231 481 minecraft:brown_terracotta
fill 493 231 483 507 231 487 minecraft:terracotta
fill 493 231 489 511 231 503 minecraft:brown_terracotta
fill 494 231 463 494 232 463 minecraft:red_terracotta
setblock 498 231 463 minecraft:red_terracotta
setblock 500 231 463 minecraft:red_terracotta
setblock 503 231 463 minecraft:red_terracotta
setblock 507 231 463 minecraft:red_terracotta
fill 508 231 482 511 231 488 minecraft:brown_terracotta
fill 509 231 505 509 233 505 minecraft:red_terracotta
fill 512 231 466 512 232 466 minecraft:red_terracotta
fill 512 231 476 512 232 476 minecraft:red_terracotta
fill 512 231 479 512 231 480 minecraft:red_terracotta
setblock 512 231 490 minecraft:red_terracotta
fill 512 231 498 512 232 498 minecraft:red_terracotta
fill 512 231 500 512 231 501 minecraft:red_terracotta
fill 470 232 463 470 232 477 minecraft:orange_terracotta
setblock 470 232 478 minecraft:red_terracotta
fill 470 232 479 470 232 493 minecraft:orange_terracotta
fill 470 232 494 470 234 494 minecraft:red_terracotta
fill 470 232 495 470 307 497 minecraft:orange_terracotta
fill 470 232 499 470 232 505 minecraft:orange_terracotta
fill 471 232 463 493 232 463 minecraft:orange_terracotta
fill 471 232 470 472 232 500 minecraft:basalt
fill 471 232 505 471 307 505 minecraft:orange_terracotta
fill 472 232 469 475 232 469 minecraft:basalt
fill 472 232 501 478 232 501 minecraft:basalt
setblock 472 232 505 minecraft:red_terracotta
fill 473 232 468 478 232 468 minecraft:basalt
setblock 473 232 470 minecraft:magma_block
fill 473 232 471 475 234 472 minecraft:basalt
setblock 473 232 473 minecraft:magma_block
fill 473 232 474 475 236 475 minecraft:basalt
setblock 473 232 476 minecraft:magma_block
fill 473 232 477 475 237 478 minecraft:basalt
setblock 473 232 479 minecraft:magma_block
fill 473 232 480 474 239 481 minecraft:basalt
setblock 473 232 482 minecraft:magma_block
fill 473 232 483 474 240 484 minecraft:basalt
setblock 473 232 485 minecraft:magma_block
fill 473 232 486 474 240 487 minecraft:basalt
setblock 473 232 488 minecraft:magma_block
fill 473 232 489 474 239 490 minecraft:basalt
setblock 473 232 491 minecraft:magma_block
fill 473 232 492 475 237 493 minecraft:basalt
setblock 473 232 494 minecraft:magma_block
fill 473 232 495 475 236 496 minecraft:basalt
setblock 473 232 497 minecraft:magma_block
fill 473 232 498 475 234 499 minecraft:basalt
setblock 473 232 500 minecraft:magma_block
fill 473 232 502 475 232 502 minecraft:basalt
fill 473 232 505 486 232 505 minecraft:orange_terracotta
fill 474 232 467 481 232 467 minecraft:basalt
fill 474 232 470 481 233 470 minecraft:basalt
fill 474 232 473 480 236 473 minecraft:basalt
fill 474 232 476 477 238 476 minecraft:basalt
fill 474 232 479 475 240 479 minecraft:basalt
fill 474 232 482 474 241 482 minecraft:basalt
fill 474 232 485 474 241 485 minecraft:basalt
fill 474 232 488 474 241 488 minecraft:basalt
fill 474 232 491 475 240 491 minecraft:basalt
fill 474 232 494 477 238 494 minecraft:basalt
fill 474 232 497 480 236 497 minecraft:basalt
fill 474 232 500 481 233 500 minecraft:basalt
fill 474 232 503 481 232 503 minecraft:basalt
setblock 475 232 480 minecraft:basalt
fill 475 232 490 475 241 490 minecraft:basalt
setblock 476 232 466 minecraft:magma_block
setblock 476 232 469 minecraft:magma_block
fill 476 232 471 478 236 471 minecraft:basalt
setblock 476 232 472 minecraft:magma_block
fill 476 232 474 478 239 474 minecraft:basalt
setblock 476 232 475 minecraft:magma_block
fill 476 232 477 476 241 477 minecraft:basalt
setblock 476 232 478 minecraft:magma_block
fill 476 232 492 476 242 492 minecraft:basalt
setblock 476 232 493 minecraft:magma_block
fill 476 232 495 478 240 495 minecraft:basalt
setblock 476 232 496 minecraft:magma_block
fill 476 232 498 478 237 498 minecraft:basalt
setblock 476 232 499 minecraft:magma_block
setblock 476 232 502 minecraft:magma_block
fill 476 232 504 478 232 504 minecraft:basalt
fill 477 232 465 478 232 466 minecraft:basalt
fill 477 232 469 484 235 469 minecraft:basalt
fill 477 232 472 482 238 472 minecraft:basalt
fill 477 232 475 478 241 475 minecraft:basalt
fill 477 232 496 479 240 496 minecraft:basalt
fill 477 232 499 484 237 499 minecraft:basalt
fill 477 232 502 484 235 502 minecraft:basalt
fill 479 232 464 481 232 464 minecraft:basalt
setblock 479 232 465 minecraft:magma_block
fill 479 232 466 484 234 466 minecraft:basalt
setblock 479 232 468 minecraft:magma_block
setblock 479 232 471 minecraft:magma_block
setblock 479 232 474 minecraft:magma_block
setblock 479 232 498 minecraft:magma_block
setblock 479 232 501 minecraft:magma_block
setblock 479 232 504 minecraft:magma_block
fill 480 232 465 487 233 465 minecraft:basalt
fill 480 232 468 487 236 468 minecraft:basalt
fill 480 232 471 484 232 471 minecraft:basalt
fill 480 232 498 482 240 498 minecraft:basalt
fill 480 232 501 487 237 501 minecraft:basalt
fill 480 232 504 487 233 504 minecraft:basalt
setblock 482 232 464 minecraft:magma_block
setblock 482 232 467 minecraft:magma_block
setblock 482 232 470 minecraft:magma_block
setblock 482 232 500 minecraft:magma_block
setblock 482 232 503 minecraft:magma_block
fill 483 232 464 490 233 464 minecraft:basalt
fill 483 232 467 490 237 467 minecraft:basalt
fill 483 232 470 490 240 470 minecraft:basalt
fill 483 232 500 490 240 500 minecraft:basalt
fill 483 232 503 490 237 503 minecraft:basalt
setblock 485 232 466 minecraft:magma_block
setblock 485 232 469 minecraft:magma_block
setblock 485 232 502 minecraft:magma_block
fill 486 232 466 493 235 466 minecraft:basalt
fill 486 232 469 493 238 469 minecraft:basalt
fill 486 232 502 493 238 502 minecraft:basalt
setblock 488 232 465 minecraft:magma_block
setblock 488 232 468 minecraft:magma_block
setblock 488 232 501 minecraft:magma_block
setblock 488 232 504 minecraft:magma_block
fill 488 232 505 490 233 505 minecraft:orange_terracotta
fill 489 232 465 496 234 465 minecraft:basalt
fill 489 232 468 496 237 468 minecraft:basalt
fill 489 232 501 496 238 501 minecraft:basalt
fill 489 232 504 496 235 504 minecraft:basalt
setblock 491 232 464 minecraft:magma_block
setblock 491 232 467 minecraft:magma_block
setblock 491 232 470 minecraft:magma_block
setblock 491 232 500 minecraft:magma_block
setblock 491 232 503 minecraft:magma_block
setblock 491 232 505 minecraft:red_terracotta
fill 492 232 464 499 232 464 minecraft:basalt
fill 492 232 467 499 235 467 minecraft:basalt
fill 492 232 470 499 238 470 minecraft:basalt
fill 492 232 500 499 238 500 minecraft:basalt
fill 492 232 503 499 235 503 minecraft:basalt
fill 492 232 505 508 232 505 minecraft:orange_terracotta
setblock 494 232 466 minecraft:magma_block
setblock 494 232 469 minecraft:magma_block
fill 494 232 471 496 241 471 minecraft:basalt
setblock 494 232 499 minecraft:magma_block
setblock 494 232 502 minecraft:magma_block
fill 495 232 463 511 233 463 minecraft:orange_terracotta
fill 495 232 466 502 232 466 minecraft:basalt
fill 495 232 469 502 235 469 minecraft:basalt
fill 495 232 499 502 236 499 minecraft:basalt
fill 495 232 502 502 234 502 minecraft:basalt
fill 496 232 472 502 237 472 minecraft:basalt
fill 496 232 498 496 242 498 minecraft:basalt
setblock 497 232 465 minecraft:magma_block
setblock 497 232 468 minecraft:magma_block
setblock 497 232 471 minecraft:magma_block
setblock 497 232 498 minecraft:magma_block
setblock 497 232 501 minecraft:magma_block
setblock 497 232 504 minecraft:magma_block
fill 498 232 465 501 232 465 minecraft:basalt
fill 498 232 468 505 232 468 minecraft:basalt
fill 498 232 471 505 234 471 minecraft:basalt
fill 498 232 473 499 241 473 minecraft:basalt
fill 498 232 497 499 240 498 minecraft:basalt
fill 498 232 501 505 233 501 minecraft:basalt
fill 498 232 504 502 232 504 minecraft:basalt
fill 499 232 474 505 236 474 minecraft:basalt
fill 499 232 496 502 238 496 minecraft:basalt
setblock 500 232 467 minecraft:magma_block
setblock 500 232 470 minecraft:magma_block
setblock 500 232 473 minecraft:magma_block
fill 500 232 475 502 240 475 minecraft:basalt
fill 500 232 495 505 237 495 minecraft:basalt
setblock 500 232 497 minecraft:magma_block
fill 500 232 498 505 235 498 minecraft:basalt
setblock 500 232 500 minecraft:magma_block
setblock 500 232 503 minecraft:magma_block
fill 501 232 467 504 232 467 minecraft:basalt
fill 501 232 470 507 232 470 minecraft:basalt
fill 501 232 473 508 233 473 minecraft:basalt
fill 501 232 476 508 234 476 minecraft:basalt
fill 501 232 494 508 234 494 minecraft:basalt
fill 501 232 497 508 233 497 minecraft:basalt
fill 501 232 500 507 232 500 minecraft:basalt
fill 501 232 503 504 232 503 minecraft:basalt
fill 502 232 477 502 241 478 minecraft:basalt
fill 502 232 492 502 232 493 minecraft:basalt
setblock 503 232 469 minecraft:magma_block
setblock 503 232 472 minecraft:magma_block
setblock 503 232 475 minecraft:magma_block
fill 503 232 477 505 238 477 minecraft:basalt
setblock 503 232 478 minecraft:magma_block
fill 503 232 479 505 238 480 minecraft:basalt
setblock 503 232 490 minecraft:magma_block
fill 503 232 491 505 238 492 minecraft:basalt
setblock 503 232 493 minecraft:magma_block
setblock 503 232 496 minecraft:magma_block
setblock 503 232 499 minecraft:magma_block
setblock 503 232 502 minecraft:magma_block
fill 504 232 469 506 232 469 minecraft:basalt
fill 504 232 472 508 232 472 minecraft:basalt
fill 504 232 475 510 232 475 minecraft:basalt
fill 504 232 478 511 232 478 minecraft:basalt
fill 504 232 481 505 238 490 minecraft:basalt
fill 504 232 493 511 232 493 minecraft:basalt
fill 504 232 496 509 232 496 minecraft:basalt
fill 504 232 499 507 232 499 minecraft:basalt
fill 504 232 502 505 232 502 minecraft:basalt
setblock 506 232 471 minecraft:magma_block
setblock 506 232 474 minecraft:magma_block
setblock 506 232 477 minecraft:magma_block
fill 506 232 479 508 236 479 minecraft:basalt
setblock 506 232 480 minecraft:magma_block
fill 506 232 481 508 236 482 minecraft:basalt
setblock 506 232 483 minecraft:magma_block
fill 506 232 484 508 237 485 minecraft:basalt
setblock 506 232 486 minecraft:magma_block
fill 506 232 487 508 236 488 minecraft:basalt
setblock 506 232 489 minecraft:magma_block
fill 506 232 490 508 236 491 minecraft:basalt
setblock 506 232 492 minecraft:magma_block
setblock 506 232 495 minecraft:magma_block
setblock 506 232 498 minecraft:magma_block
setblock 506 232 501 minecraft:magma_block
setblock 507 232 471 minecraft:basalt
fill 507 232 474 509 232 474 minecraft:basalt
fill 507 232 477 511 232 477 minecraft:basalt
fill 507 232 480 511 232 480 minecraft:basalt
fill 507 232 483 511 232 483 minecraft:basalt
fill 507 232 486 511 232 486 minecraft:basalt
fill 507 232 489 511 232 489 minecraft:basalt
fill 507 232 492 511 232 492 minecraft:basalt
fill 507 232 495 510 232 495 minecraft:basalt
fill 507 232 498 508 232 498 minecraft:basalt
setblock 509 232 473 minecraft:magma_block
setblock 509 232 476 minecraft:magma_block
setblock 509 232 479 minecraft:magma_block
fill 509 232 481 511 233 481 minecraft:basalt
setblock 509 232 482 minecraft:magma_block
fill 509 232 484 511 233 484 minecraft:basalt
setblock 509 232 485 minecraft:magma_block
fill 509 232 487 511 233 487 minecraft:basalt
setblock 509 232 488 minecraft:magma_block
fill 509 232 490 511 233 490 minecraft:basalt
setblock 509 232 491 minecraft:magma_block
setblock 509 232 494 minecraft:magma_block
setblock 509 232 497 minecraft:magma_block
setblock 510 232 476 minecraft:basalt
fill 510 232 479 511 232 479 minecraft:basalt
fill 510 232 482 511 233 482 minecraft:basalt
fill 510 232 485 511 233 485 minecraft:basalt
fill 510 232 488 511 233 488 minecraft:basalt
fill 510 232 491 511 232 491 minecraft:basalt
setblock 510 232 494 minecraft:basalt
fill 510 232 505 512 233 505 minecraft:orange_terracotta
fill 512 232 464 512 307 465 minecraft:orange_terracotta
fill 512 232 467 512 307 470 minecraft:orange_terracotta
setblock 512 232 471 minecraft:red_terracotta
fill 512 232 472 512 307 475 minecraft:orange_terracotta
fill 512 232 477 512 232 479 minecraft:orange_terracotta
setblock 512 232 480 minecraft:red_terracotta
fill 512 232 481 512 307 482 minecraft:orange_terracotta
fill 512 232 484 512 232 491 minecraft:orange_terracotta
fill 512 232 493 512 232 497 minecraft:orange_terracotta
fill 512 232 499 512 232 504 minecraft:orange_terracotta
fill 470 233 463 473 233 463 minecraft:orange_terracotta
setblock 470 233 464 minecraft:red_terracotta
fill 470 233 465 470 233 475 minecraft:orange_terracotta
setblock 470 233 476 minecraft:red_terracotta
fill 470 233 477 470 307 479 minecraft:orange_terracotta
setblock 470 233 480 minecraft:red_terracotta
fill 470 233 481 470 233 488 minecraft:orange_terracotta
setblock 470 233 489 minecraft:red_terracotta
fill 470 233 490 470 307 493 minecraft:orange_terracotta
fill 470 233 498 470 307 500 minecraft:orange_terracotta
setblock 470 233 501 minecraft:red_terracotta
fill 470 233 502 470 233 505 minecraft:orange_terracotta
fill 471 233 472 472 233 498 minecraft:basalt
fill 472 233 470 472 233 471 minecraft:basalt
setblock 472 233 499 minecraft:magma_block
fill 472 233 500 473 233 500 minecraft:basalt
fill 472 233 505 472 307 505 minecraft:orange_terracotta
fill 473 233 469 473 233 470 minecraft:basalt
fill 473 233 473 473 236 473 minecraft:basalt
fill 473 233 476 473 237 476 minecraft:basalt
fill 473 233 479 473 239 479 minecraft:basalt
fill 473 233 482 473 240 482 minecraft:basalt
fill 473 233 485 473 240 485 minecraft:basalt
fill 473 233 488 473 240 488 minecraft:basalt
fill 473 233 491 473 239 491 minecraft:basalt
fill 473 233 494 473 237 494 minecraft:basalt
fill 473 233 497 473 236 497 minecraft:basalt
fill 473 233 501 479 233 501 minecraft:basalt
setblock 473 233 505 minecraft:red_terracotta
setblock 474 233 463 minecraft:red_terracotta
fill 474 233 468 474 233 469 minecraft:basalt
fill 474 233 502 476 233 502 minecraft:basalt
fill 474 233 505 474 307 505 minecraft:orange_terracotta
fill 475 233 463 477 307 463 minecraft:orange_terracotta
setblock 475 233 468 minecraft:magma_block
fill 475 233 469 476 234 469 minecraft:basalt
setblock 475 233 480 minecraft:magma_block
fill 475 233 481 475 242 482 minecraft:basalt
setblock 475 233 483 minecraft:magma_block
fill 475 233 487 475 242 488 minecraft:basalt
setblock 475 233 489 minecraft:magma_block
fill 475 233 505 476 233 505 minecraft:red_terracotta
fill 476 233 467 479 233 468 minecraft:basalt
fill 476 233 472 476 237 472 minecraft:basalt
fill 476 233 475 476 240 475 minecraft:basalt
fill 476 233 478 476 242 479 minecraft:basalt
fill 476 233 491 476 242 491 minecraft:basalt
fill 476 233 493 477 240 493 minecraft:basalt
fill 476 233 496 476 239 496 minecraft:basalt
fill 476 233 499 476 237 499 minecraft:basalt
fill 476 233 503 482 233 503 minecraft:basalt
fill 477 233 466 478 233 466 minecraft:basalt
fill 477 233 477 477 242 477 minecraft:basalt
fill 477 233 504 479 233 504 minecraft:basalt
fill 477 233 505 483 233 505 minecraft:orange_terracotta
setblock 478 233 463 minecraft:red_terracotta
setblock 478 233 476 minecraft:magma_block
setblock 478 233 494 minecraft:magma_block
fill 479 233 463 486 307 463 minecraft:orange_terracotta
setblock 479 233 465 minecraft:basalt
fill 479 233 471 483 239 471 minecraft:basalt
fill 479 233 474 479 240 475 minecraft:basalt
fill 479 233 495 479 242 495 minecraft:basalt
fill 479 233 498 479 240 498 minecraft:basalt
fill 480 233 467 482 235 467 minecraft:basalt
fill 480 233 474 480 242 474 minecraft:basalt
fill 480 233 496 480 242 496 minecraft:basalt
fill 481 233 464 482 233 464 minecraft:basalt
fill 481 233 473 481 242 473 minecraft:basalt
schedule function dropper:buildpart/118_8 1t
