setblock 148 159 599 minecraft:black_concrete
fill 164 159 557 164 170 557 minecraft:black_concrete
fill 166 159 557 166 173 557 minecraft:black_concrete
fill 183 159 569 183 173 569 minecraft:black_concrete
setblock 183 159 570 minecraft:shroomlight
fill 183 159 572 183 173 572 minecraft:black_concrete
setblock 141 160 572 minecraft:shroomlight
fill 141 160 573 141 169 573 minecraft:black_concrete
fill 143 160 557 143 173 557 minecraft:black_concrete
fill 147 160 599 147 173 599 minecraft:black_concrete
setblock 148 160 599 minecraft:white_concrete
setblock 150 160 599 minecraft:shroomlight
fill 183 160 562 183 165 563 minecraft:black_concrete
setblock 183 160 564 minecraft:shroomlight
fill 183 160 570 183 165 570 minecraft:black_concrete
setblock 141 161 558 minecraft:shroomlight
fill 141 161 572 141 167 572 minecraft:black_concrete
fill 148 161 599 148 173 599 minecraft:black_concrete
fill 150 161 599 150 171 599 minecraft:black_concrete
setblock 155 161 599 minecraft:shroomlight
fill 183 161 564 183 174 564 minecraft:black_concrete
fill 183 161 591 183 174 591 minecraft:black_concrete
setblock 183 161 592 minecraft:shroomlight
fill 183 161 593 183 173 593 minecraft:black_concrete
fill 141 162 558 141 173 558 minecraft:black_concrete
fill 141 162 565 141 164 565 minecraft:gold_block
fill 141 162 581 141 164 581 minecraft:gold_block
fill 141 162 597 141 164 597 minecraft:gold_block
setblock 144 162 560 minecraft:light[level=14]
setblock 144 162 568 minecraft:light[level=14]
setblock 144 162 576 minecraft:light[level=14]
setblock 144 162 584 minecraft:light[level=14]
setblock 144 162 592 minecraft:light[level=14]
fill 145 162 557 145 164 557 minecraft:gold_block
fill 146 162 557 146 173 557 minecraft:black_concrete
setblock 152 162 560 minecraft:light[level=14]
setblock 152 162 568 minecraft:light[level=14]
setblock 152 162 576 minecraft:light[level=14]
setblock 152 162 584 minecraft:light[level=14]
setblock 152 162 592 minecraft:light[level=14]
fill 155 162 599 155 164 599 minecraft:gold_block
setblock 160 162 560 minecraft:light[level=14]
setblock 160 162 568 minecraft:light[level=14]
setblock 160 162 576 minecraft:light[level=14]
setblock 160 162 584 minecraft:light[level=14]
setblock 160 162 592 minecraft:light[level=14]
fill 161 162 557 161 164 557 minecraft:gold_block
setblock 168 162 560 minecraft:light[level=14]
setblock 168 162 568 minecraft:light[level=14]
setblock 168 162 576 minecraft:light[level=14]
setblock 168 162 584 minecraft:light[level=14]
setblock 168 162 592 minecraft:light[level=14]
fill 171 162 599 171 164 599 minecraft:gold_block
setblock 175 162 599 minecraft:white_concrete
setblock 176 162 560 minecraft:light[level=14]
setblock 176 162 568 minecraft:light[level=14]
setblock 176 162 576 minecraft:light[level=14]
setblock 176 162 584 minecraft:light[level=14]
setblock 176 162 592 minecraft:light[level=14]
fill 177 162 557 177 164 557 minecraft:gold_block
fill 183 162 566 183 169 566 minecraft:black_concrete
fill 183 162 567 183 164 567 minecraft:gold_block
fill 183 162 583 183 164 583 minecraft:gold_block
setblock 183 162 592 minecraft:black_concrete
setblock 145 163 599 minecraft:white_concrete
setblock 160 163 557 minecraft:white_concrete
setblock 160 163 599 minecraft:black_concrete
setblock 161 163 599 minecraft:white_concrete
fill 162 163 599 162 169 599 minecraft:black_concrete
fill 175 163 599 175 173 599 minecraft:black_concrete
setblock 176 163 599 minecraft:shroomlight
setblock 183 163 592 minecraft:white_concrete
fill 145 164 599 145 165 599 minecraft:black_concrete
fill 153 164 591 155 169 592 minecraft:red_terracotta
fill 154 164 593 154 169 593 minecraft:red_terracotta
setblock 160 164 557 minecraft:shroomlight
setblock 160 164 599 minecraft:white_concrete
fill 161 164 599 161 171 599 minecraft:black_concrete
setblock 170 164 557 minecraft:white_concrete
fill 176 164 599 176 173 599 minecraft:black_concrete
fill 183 164 592 183 171 592 minecraft:black_concrete
setblock 183 164 596 minecraft:white_concrete
setblock 141 165 563 minecraft:shroomlight
fill 141 165 564 141 170 565 minecraft:black_concrete
fill 141 165 581 141 170 581 minecraft:black_concrete
fill 141 165 597 141 169 597 minecraft:black_concrete
fill 145 165 557 145 170 557 minecraft:black_concrete
fill 152 165 591 152 168 593 minecraft:red_terracotta
fill 153 165 590 155 168 590 minecraft:red_terracotta
fill 153 165 593 153 168 593 minecraft:red_terracotta
fill 153 165 599 153 166 599 minecraft:black_concrete
fill 154 165 594 154 168 594 minecraft:red_terracotta
setblock 154 165 599 minecraft:white_concrete
fill 155 165 593 155 168 593 minecraft:red_terracotta
fill 155 165 599 155 170 599 minecraft:black_concrete
fill 156 165 591 156 168 592 minecraft:red_terracotta
setblock 156 165 599 minecraft:shroomlight
fill 160 165 557 160 173 557 minecraft:black_concrete
fill 160 165 599 160 173 599 minecraft:black_concrete
setblock 161 165 557 minecraft:white_concrete
setblock 163 165 557 minecraft:shroomlight
fill 170 165 557 170 173 557 minecraft:black_concrete
fill 171 165 599 171 170 599 minecraft:black_concrete
fill 177 165 557 177 170 557 minecraft:black_concrete
fill 183 165 567 183 169 567 minecraft:black_concrete
fill 183 165 583 183 170 583 minecraft:black_concrete
fill 183 165 596 183 173 596 minecraft:black_concrete
fill 141 166 563 141 173 563 minecraft:black_concrete
setblock 141 166 592 minecraft:white_concrete
setblock 145 166 599 minecraft:shroomlight
fill 152 166 590 152 167 590 minecraft:red_terracotta
fill 153 166 589 154 167 589 minecraft:red_terracotta
fill 153 166 594 153 167 594 minecraft:red_terracotta
setblock 154 166 599 minecraft:black_concrete
fill 155 166 594 155 167 594 minecraft:red_terracotta
fill 156 166 590 156 167 590 minecraft:red_terracotta
fill 156 166 593 156 167 593 minecraft:red_terracotta
fill 156 166 599 156 173 599 minecraft:black_concrete
fill 161 166 557 161 170 557 minecraft:black_concrete
fill 163 166 557 163 170 557 minecraft:black_concrete
setblock 183 166 562 minecraft:shroomlight
fill 183 166 563 183 169 563 minecraft:black_concrete
setblock 183 166 570 minecraft:shroomlight
setblock 141 167 587 minecraft:white_concrete
fill 141 167 588 141 173 588 minecraft:black_concrete
fill 141 167 592 141 173 592 minecraft:black_concrete
fill 145 167 599 145 173 599 minecraft:black_concrete
setblock 153 167 599 minecraft:shroomlight
setblock 154 167 599 minecraft:white_concrete
fill 183 167 562 183 173 562 minecraft:black_concrete
fill 183 167 570 183 171 570 minecraft:black_concrete
setblock 141 168 559 minecraft:shroomlight
setblock 141 168 572 minecraft:shroomlight
fill 141 168 587 141 173 587 minecraft:black_concrete
setblock 144 168 599 minecraft:white_concrete
fill 153 168 599 154 170 599 minecraft:black_concrete
setblock 183 168 581 minecraft:shroomlight
setblock 183 168 595 minecraft:shroomlight
fill 141 169 559 141 173 559 minecraft:black_concrete
fill 141 169 572 141 174 572 minecraft:black_concrete
fill 144 169 599 144 173 599 minecraft:black_concrete
setblock 165 169 599 minecraft:white_concrete
setblock 174 169 557 minecraft:white_concrete
fill 183 169 581 183 171 581 minecraft:black_concrete
setblock 183 169 587 minecraft:white_concrete
setblock 183 169 595 minecraft:black_concrete
setblock 141 170 566 minecraft:blue_concrete
setblock 141 170 569 minecraft:blue_concrete
fill 141 170 573 141 171 573 minecraft:blue_concrete
setblock 141 170 576 minecraft:blue_concrete
setblock 141 170 578 minecraft:blue_concrete
setblock 141 170 597 minecraft:blue_concrete
setblock 144 170 560 minecraft:light[level=14]
setblock 144 170 568 minecraft:light[level=14]
setblock 144 170 576 minecraft:light[level=14]
setblock 144 170 584 minecraft:light[level=14]
setblock 144 170 592 minecraft:light[level=14]
setblock 150 170 557 minecraft:white_concrete
setblock 152 170 560 minecraft:light[level=14]
setblock 152 170 568 minecraft:light[level=14]
setblock 152 170 576 minecraft:light[level=14]
setblock 152 170 584 minecraft:light[level=14]
setblock 152 170 592 minecraft:light[level=14]
setblock 155 170 557 minecraft:blue_concrete
setblock 160 170 560 minecraft:light[level=14]
setblock 160 170 568 minecraft:light[level=14]
setblock 160 170 576 minecraft:light[level=14]
setblock 160 170 584 minecraft:light[level=14]
setblock 160 170 592 minecraft:light[level=14]
setblock 162 170 599 minecraft:blue_concrete
setblock 165 170 599 minecraft:black_concrete
fill 167 170 557 167 173 557 minecraft:black_concrete
setblock 168 170 557 minecraft:blue_concrete
setblock 168 170 560 minecraft:light[level=14]
setblock 168 170 568 minecraft:light[level=14]
setblock 168 170 576 minecraft:light[level=14]
setblock 168 170 584 minecraft:light[level=14]
setblock 168 170 592 minecraft:light[level=14]
fill 169 170 557 169 173 557 minecraft:black_concrete
setblock 171 170 557 minecraft:shroomlight
fill 174 170 557 174 173 557 minecraft:black_concrete
setblock 176 170 560 minecraft:light[level=14]
setblock 176 170 568 minecraft:light[level=14]
setblock 176 170 576 minecraft:light[level=14]
setblock 176 170 584 minecraft:light[level=14]
setblock 176 170 592 minecraft:light[level=14]
fill 180 170 557 180 172 557 minecraft:blue_concrete
setblock 180 170 599 minecraft:white_concrete
fill 182 170 557 182 171 557 minecraft:black_concrete
setblock 182 170 599 minecraft:blue_concrete
setblock 183 170 557 minecraft:blue_concrete
setblock 183 170 558 minecraft:white_concrete
setblock 183 170 563 minecraft:blue_concrete
fill 183 170 566 183 170 568 minecraft:blue_concrete
setblock 183 170 571 minecraft:blue_concrete
fill 183 170 574 183 171 574 minecraft:blue_concrete
setblock 183 170 586 minecraft:blue_concrete
setblock 183 170 587 minecraft:black_concrete
fill 183 170 595 183 171 595 minecraft:blue_concrete
fill 141 171 557 141 172 557 minecraft:blue_concrete
setblock 141 171 560 minecraft:white_concrete
fill 141 171 564 141 173 564 minecraft:black_concrete
fill 141 171 565 141 173 565 minecraft:gold_block
setblock 141 171 566 minecraft:shroomlight
fill 141 171 567 141 171 568 minecraft:blue_concrete
fill 141 171 569 141 173 569 minecraft:black_concrete
fill 141 171 576 141 173 576 minecraft:black_concrete
fill 141 171 578 141 173 578 minecraft:black_concrete
fill 141 171 581 141 173 581 minecraft:gold_block
setblock 141 171 583 minecraft:blue_concrete
fill 141 171 597 141 173 597 minecraft:gold_block
fill 142 171 557 142 173 557 minecraft:black_concrete
setblock 144 171 557 minecraft:blue_concrete
fill 145 171 557 145 173 557 minecraft:gold_block
fill 150 171 557 150 173 557 minecraft:black_concrete
setblock 152 171 599 minecraft:shroomlight
setblock 153 171 599 minecraft:blue_concrete
fill 154 171 599 154 173 599 minecraft:black_concrete
fill 155 171 557 155 173 557 minecraft:black_concrete
fill 155 171 599 155 173 599 minecraft:gold_block
fill 161 171 557 161 173 557 minecraft:gold_block
setblock 162 171 599 minecraft:black_concrete
setblock 163 171 557 minecraft:white_concrete
setblock 164 171 557 minecraft:shroomlight
setblock 165 171 599 minecraft:blue_concrete
setblock 168 171 557 minecraft:black_concrete
setblock 170 171 599 minecraft:blue_concrete
setblock 171 171 557 minecraft:black_concrete
fill 171 171 599 171 173 599 minecraft:gold_block
fill 177 171 557 177 173 557 minecraft:gold_block
setblock 177 171 599 minecraft:blue_concrete
fill 179 171 599 179 172 599 minecraft:blue_concrete
fill 180 171 599 180 173 599 minecraft:black_concrete
fill 182 171 599 182 173 599 minecraft:black_concrete
fill 183 171 557 183 173 558 minecraft:black_concrete
fill 183 171 563 183 174 563 minecraft:black_concrete
setblock 183 171 565 minecraft:shroomlight
setblock 183 171 566 minecraft:blue_concrete
fill 183 171 567 183 173 567 minecraft:gold_block
setblock 183 171 568 minecraft:black_concrete
fill 183 171 571 183 173 571 minecraft:black_concrete
setblock 183 171 573 minecraft:blue_concrete
setblock 183 171 575 minecraft:blue_concrete
setblock 183 171 582 minecraft:shroomlight
fill 183 171 583 183 173 583 minecraft:gold_block
fill 183 171 586 183 173 586 minecraft:black_concrete
setblock 183 171 587 minecraft:blue_concrete
setblock 183 171 594 minecraft:blue_concrete
fill 141 172 560 141 173 560 minecraft:black_concrete
setblock 141 172 562 minecraft:shroomlight
fill 141 172 566 141 173 568 minecraft:black_concrete
setblock 141 172 571 minecraft:blue_concrete
fill 141 172 573 141 173 573 minecraft:black_concrete
setblock 141 172 582 minecraft:blue_concrete
fill 141 172 583 141 173 583 minecraft:black_concrete
setblock 141 172 598 minecraft:blue_concrete
fill 141 172 599 141 173 599 minecraft:black_concrete
fill 144 172 557 144 173 557 minecraft:black_concrete
setblock 150 172 599 minecraft:blue_concrete
setblock 151 172 557 minecraft:blue_concrete
fill 152 172 599 153 173 599 minecraft:black_concrete
setblock 156 172 557 minecraft:blue_concrete
fill 161 172 599 162 172 599 minecraft:blue_concrete
fill 163 172 557 164 173 557 minecraft:black_concrete
fill 165 172 599 165 173 599 minecraft:black_concrete
setblock 168 172 557 minecraft:blue_concrete
fill 168 172 599 168 173 599 minecraft:black_concrete
setblock 169 172 599 minecraft:blue_concrete
fill 170 172 599 170 173 599 minecraft:black_concrete
setblock 171 172 557 minecraft:blue_concrete
fill 177 172 599 177 173 599 minecraft:black_concrete
setblock 178 172 557 minecraft:blue_concrete
setblock 182 172 557 minecraft:blue_concrete
fill 183 172 565 183 173 566 minecraft:black_concrete
setblock 183 172 568 minecraft:shroomlight
setblock 183 172 570 minecraft:blue_concrete
fill 183 172 573 183 173 575 minecraft:black_concrete
setblock 183 172 576 minecraft:blue_concrete
fill 183 172 577 183 173 577 minecraft:black_concrete
setblock 183 172 579 minecraft:blue_concrete
setblock 183 172 581 minecraft:blue_concrete
fill 183 172 582 183 173 582 minecraft:black_concrete
setblock 183 172 585 minecraft:shroomlight
fill 183 172 587 183 173 587 minecraft:black_concrete
setblock 183 172 592 minecraft:white_concrete
fill 183 172 594 183 173 595 minecraft:black_concrete
fill 141 173 557 141 175 557 minecraft:black_concrete
setblock 141 173 562 minecraft:black_concrete
setblock 141 173 571 minecraft:black_concrete
fill 141 173 582 141 174 582 minecraft:black_concrete
setblock 141 173 598 minecraft:black_concrete
setblock 150 173 599 minecraft:black_concrete
setblock 151 173 557 minecraft:black_concrete
setblock 154 173 557 minecraft:white_concrete
setblock 156 173 557 minecraft:black_concrete
fill 161 173 599 162 173 599 minecraft:black_concrete
setblock 168 173 557 minecraft:black_concrete
setblock 169 173 599 minecraft:shroomlight
setblock 171 173 557 minecraft:black_concrete
setblock 178 173 557 minecraft:black_concrete
setblock 179 173 599 minecraft:black_concrete
setblock 180 173 557 minecraft:black_concrete
setblock 182 173 557 minecraft:black_concrete
setblock 183 173 568 minecraft:black_concrete
setblock 183 173 570 minecraft:black_concrete
fill 183 173 576 183 174 576 minecraft:black_concrete
setblock 183 173 579 minecraft:black_concrete
setblock 183 173 581 minecraft:black_concrete
setblock 183 173 585 minecraft:black_concrete
setblock 183 173 592 minecraft:black_concrete
setblock 141 174 558 minecraft:blue_concrete
setblock 141 174 559 minecraft:white_concrete
fill 141 174 560 141 174 569 minecraft:blue_concrete
fill 141 174 571 141 207 571 minecraft:blue_concrete
setblock 141 174 573 minecraft:shroomlight
fill 141 174 574 141 175 581 minecraft:blue_concrete
fill 141 174 583 141 175 588 minecraft:blue_concrete
fill 141 174 591 141 174 595 minecraft:blue_concrete
fill 141 174 597 141 174 599 minecraft:blue_concrete
fill 142 174 557 174 174 557 minecraft:blue_concrete
fill 142 174 599 143 175 599 minecraft:blue_concrete
fill 144 174 599 144 175 599 minecraft:shroomlight
fill 145 174 599 148 186 599 minecraft:blue_concrete
fill 150 174 599 151 187 599 minecraft:blue_concrete
setblock 152 174 599 minecraft:shroomlight
fill 153 174 599 154 182 599 minecraft:blue_concrete
setblock 155 174 599 minecraft:shroomlight
fill 156 174 599 160 175 599 minecraft:blue_concrete
setblock 161 174 599 minecraft:black_concrete
fill 162 174 599 180 174 599 minecraft:blue_concrete
fill 176 174 557 176 194 557 minecraft:blue_concrete
setblock 177 174 557 minecraft:black_concrete
fill 178 174 557 178 205 557 minecraft:blue_concrete
fill 180 174 557 183 175 557 minecraft:blue_concrete
fill 182 174 599 183 211 599 minecraft:blue_concrete
fill 183 174 558 183 195 560 minecraft:blue_concrete
fill 183 174 562 183 214 562 minecraft:blue_concrete
fill 183 174 565 183 174 575 minecraft:blue_concrete
fill 183 174 577 183 204 579 minecraft:blue_concrete
fill 183 174 581 183 175 590 minecraft:blue_concrete
fill 183 174 592 183 175 594 minecraft:blue_concrete
setblock 183 174 595 minecraft:black_concrete
fill 183 174 596 183 226 598 minecraft:blue_concrete
fill 141 175 558 141 176 558 minecraft:black_concrete
fill 141 175 559 141 184 562 minecraft:blue_concrete
setblock 141 175 563 minecraft:black_concrete
fill 141 175 564 141 179 568 minecraft:blue_concrete
setblock 141 175 569 minecraft:shroomlight
fill 141 175 570 141 194 570 minecraft:blue_concrete
fill 141 175 572 141 175 573 minecraft:blue_concrete
fill 141 175 582 141 200 582 minecraft:blue_concrete
fill 141 175 589 141 175 592 minecraft:blue_concrete
setblock 141 175 593 minecraft:black_concrete
fill 141 175 594 141 179 597 minecraft:blue_concrete
setblock 141 175 598 minecraft:white_concrete
fill 141 175 599 141 240 599 minecraft:blue_concrete
fill 142 175 557 156 175 557 minecraft:blue_concrete
setblock 149 175 599 minecraft:blue_concrete
fill 152 175 599 152 230 599 minecraft:blue_concrete
fill 155 175 599 155 179 599 minecraft:blue_concrete
setblock 157 175 557 minecraft:black_concrete
fill 158 175 557 163 175 557 minecraft:blue_concrete
fill 161 175 599 169 175 599 minecraft:blue_concrete
setblock 164 175 557 minecraft:black_concrete
fill 165 175 557 170 175 557 minecraft:blue_concrete
setblock 170 175 599 minecraft:black_concrete
setblock 171 175 557 minecraft:black_concrete
fill 171 175 599 180 175 599 minecraft:blue_concrete
fill 172 175 557 175 179 557 minecraft:blue_concrete
fill 177 175 557 177 179 557 minecraft:blue_concrete
setblock 179 175 557 minecraft:blue_concrete
fill 183 175 563 183 182 566 minecraft:blue_concrete
fill 183 175 567 183 176 567 minecraft:black_concrete
fill 183 175 568 183 176 576 minecraft:blue_concrete
fill 183 175 580 183 179 580 minecraft:blue_concrete
fill 183 175 591 183 201 591 minecraft:blue_concrete
fill 183 175 595 183 176 595 minecraft:blue_concrete
fill 141 176 557 142 237 557 minecraft:blue_concrete
fill 141 176 563 141 238 563 minecraft:blue_concrete
fill 141 176 569 141 230 569 minecraft:blue_concrete
setblock 141 176 572 minecraft:black_concrete
fill 141 176 573 141 182 576 minecraft:blue_concrete
setblock 141 176 577 minecraft:black_concrete
fill 141 176 578 141 179 581 minecraft:blue_concrete
fill 141 176 583 141 240 584 minecraft:blue_concrete
setblock 141 176 585 minecraft:black_concrete
fill 141 176 586 141 177 589 minecraft:blue_concrete
setblock 141 176 590 minecraft:black_concrete
fill 141 176 591 141 196 593 minecraft:blue_concrete
fill 141 176 598 141 187 598 minecraft:blue_concrete
fill 142 176 599 142 194 599 minecraft:blue_concrete
setblock 143 176 557 minecraft:black_concrete
setblock 143 176 599 minecraft:black_concrete
fill 144 176 557 162 177 557 minecraft:blue_concrete
fill 144 176 599 144 188 599 minecraft:blue_concrete
setblock 149 176 599 minecraft:black_concrete
setblock 156 176 599 minecraft:black_concrete
fill 157 176 599 159 177 599 minecraft:blue_concrete
setblock 160 176 599 minecraft:black_concrete
fill 161 176 599 168 183 599 minecraft:blue_concrete
setblock 163 176 557 minecraft:black_concrete
fill 164 176 557 165 177 557 minecraft:blue_concrete
setblock 166 176 557 minecraft:black_concrete
fill 167 176 557 168 222 557 minecraft:blue_concrete
setblock 169 176 557 minecraft:black_concrete
setblock 169 176 599 minecraft:black_concrete
fill 170 176 557 170 193 557 minecraft:blue_concrete
fill 170 176 599 170 213 599 minecraft:blue_concrete
setblock 171 176 557 minecraft:shroomlight
setblock 171 176 599 minecraft:black_concrete
fill 172 176 599 174 181 599 minecraft:blue_concrete
setblock 175 176 599 minecraft:black_concrete
fill 176 176 599 181 179 599 minecraft:blue_concrete
fill 179 176 557 180 176 557 minecraft:black_concrete
fill 181 176 557 183 208 557 minecraft:blue_concrete
fill 183 176 561 183 178 561 minecraft:blue_concrete
fill 183 176 581 183 179 584 minecraft:blue_concrete
setblock 183 176 585 minecraft:black_concrete
fill 183 176 586 183 185 590 minecraft:blue_concrete
fill 183 176 592 183 210 593 minecraft:blue_concrete
setblock 183 176 594 minecraft:black_concrete
fill 141 177 558 141 179 558 minecraft:blue_concrete
fill 141 177 572 141 236 572 minecraft:blue_concrete
fill 141 177 577 141 189 577 minecraft:blue_concrete
fill 141 177 585 141 184 585 minecraft:blue_concrete
fill 141 177 590 141 219 590 minecraft:blue_concrete
fill 143 177 557 143 222 557 minecraft:blue_concrete
fill 143 177 599 143 186 599 minecraft:blue_concrete
fill 149 177 599 149 240 599 minecraft:blue_concrete
fill 156 177 599 156 240 599 minecraft:blue_concrete
setblock 160 177 599 minecraft:blue_concrete
fill 163 177 557 163 182 557 minecraft:blue_concrete
fill 166 177 557 166 240 557 minecraft:blue_concrete
fill 169 177 557 169 200 557 minecraft:blue_concrete
fill 169 177 599 169 234 599 minecraft:blue_concrete
fill 171 177 557 171 217 557 minecraft:blue_concrete
fill 171 177 599 171 179 599 minecraft:blue_concrete
fill 175 177 599 175 190 599 minecraft:blue_concrete
fill 179 177 557 180 213 557 minecraft:blue_concrete
fill 183 177 567 183 179 572 minecraft:blue_concrete
setblock 183 177 573 minecraft:white_concrete
fill 183 177 574 183 181 576 minecraft:blue_concrete
fill 183 177 585 183 217 585 minecraft:blue_concrete
fill 183 177 594 183 224 594 minecraft:blue_concrete
setblock 183 177 595 minecraft:white_concrete
fill 141 178 586 141 236 588 minecraft:blue_concrete
setblock 141 178 589 minecraft:shroomlight
setblock 144 178 557 minecraft:white_concrete
setblock 144 178 560 minecraft:light[level=14]
setblock 144 178 568 minecraft:light[level=14]
setblock 144 178 576 minecraft:light[level=14]
setblock 144 178 584 minecraft:light[level=14]
setblock 144 178 592 minecraft:light[level=14]
fill 145 178 557 162 179 557 minecraft:blue_concrete
setblock 152 178 560 minecraft:light[level=14]
setblock 152 178 568 minecraft:light[level=14]
setblock 152 178 576 minecraft:light[level=14]
setblock 152 178 584 minecraft:light[level=14]
setblock 152 178 592 minecraft:light[level=14]
setblock 157 178 599 minecraft:shroomlight
fill 158 178 599 159 192 599 minecraft:blue_concrete
setblock 160 178 560 minecraft:light[level=14]
setblock 160 178 568 minecraft:light[level=14]
setblock 160 178 576 minecraft:light[level=14]
setblock 160 178 584 minecraft:light[level=14]
setblock 160 178 592 minecraft:light[level=14]
setblock 160 178 599 minecraft:shroomlight
fill 164 178 557 164 240 557 minecraft:blue_concrete
setblock 165 178 557 minecraft:white_concrete
setblock 168 178 560 minecraft:light[level=14]
setblock 168 178 568 minecraft:light[level=14]
setblock 168 178 576 minecraft:light[level=14]
setblock 168 178 584 minecraft:light[level=14]
setblock 168 178 592 minecraft:light[level=14]
setblock 176 178 560 minecraft:light[level=14]
setblock 176 178 568 minecraft:light[level=14]
setblock 176 178 576 minecraft:light[level=14]
setblock 176 178 584 minecraft:light[level=14]
setblock 176 178 592 minecraft:light[level=14]
fill 183 178 573 183 241 573 minecraft:blue_concrete
fill 183 178 595 183 190 595 minecraft:blue_concrete
fill 141 179 589 141 197 589 minecraft:blue_concrete
fill 144 179 557 144 241 557 minecraft:blue_concrete
fill 157 179 599 157 238 599 minecraft:blue_concrete
fill 160 179 599 160 187 599 minecraft:blue_concrete
fill 165 179 557 165 186 557 minecraft:blue_concrete
setblock 183 179 561 minecraft:shroomlight
setblock 141 180 558 minecraft:shroomlight
fill 141 180 564 141 199 564 minecraft:blue_concrete
fill 141 180 565 141 182 565 minecraft:gold_block
fill 141 180 566 141 182 568 minecraft:blue_concrete
fill 141 180 578 141 188 580 minecraft:blue_concrete
fill 141 180 581 141 182 581 minecraft:gold_block
fill 141 180 594 141 202 596 minecraft:blue_concrete
fill 141 180 597 141 182 597 minecraft:gold_block
fill 145 180 557 145 182 557 minecraft:gold_block
fill 146 180 557 160 182 557 minecraft:blue_concrete
fill 155 180 599 155 182 599 minecraft:gold_block
fill 161 180 557 161 182 557 minecraft:gold_block
fill 162 180 557 162 213 557 minecraft:blue_concrete
fill 171 180 599 171 182 599 minecraft:gold_block
setblock 172 180 557 minecraft:shroomlight
fill 173 180 557 175 180 557 minecraft:blue_concrete
fill 176 180 599 176 186 599 minecraft:blue_concrete
fill 177 180 557 177 182 557 minecraft:gold_block
setblock 177 180 599 minecraft:white_concrete
fill 178 180 599 179 193 599 minecraft:blue_concrete
setblock 180 180 599 minecraft:shroomlight
fill 181 180 599 181 211 599 minecraft:blue_concrete
fill 183 180 561 183 181 561 minecraft:blue_concrete
fill 183 180 567 183 182 567 minecraft:gold_block
fill 183 180 568 183 188 572 minecraft:blue_concrete
setblock 183 180 580 minecraft:shroomlight
fill 183 180 581 183 189 582 minecraft:blue_concrete
fill 183 180 583 183 182 583 minecraft:gold_block
fill 183 180 584 183 194 584 minecraft:blue_concrete
fill 141 181 558 141 237 558 minecraft:blue_concrete
fill 172 181 557 174 234 557 minecraft:blue_concrete
setblock 175 181 557 minecraft:shroomlight
fill 177 181 599 177 185 599 minecraft:blue_concrete
fill 180 181 599 180 190 599 minecraft:blue_concrete
fill 183 181 580 183 208 580 minecraft:blue_concrete
fill 172 182 599 172 232 599 minecraft:blue_concrete
fill 173 182 599 173 183 599 minecraft:shroomlight
fill 174 182 599 174 227 599 minecraft:blue_concrete
setblock 175 182 557 minecraft:blue_concrete
fill 183 182 561 183 183 561 minecraft:white_concrete
fill 183 182 574 183 219 575 minecraft:blue_concrete
setblock 183 182 576 minecraft:white_concrete
fill 141 183 565 141 197 565 minecraft:blue_concrete
setblock 141 183 566 minecraft:shroomlight
fill 141 183 567 141 188 568 minecraft:blue_concrete
fill 141 183 573 141 226 574 minecraft:blue_concrete
setblock 141 183 575 minecraft:shroomlight
fill 141 183 576 141 185 576 minecraft:blue_concrete
fill 141 183 581 141 197 581 minecraft:blue_concrete
fill 141 183 597 141 197 597 minecraft:blue_concrete
fill 145 183 557 145 197 557 minecraft:blue_concrete
setblock 146 183 557 minecraft:shroomlight
fill 147 183 557 161 184 557 minecraft:blue_concrete
fill 153 183 599 153 237 599 minecraft:blue_concrete
setblock 154 183 599 minecraft:white_concrete
fill 155 183 599 155 195 599 minecraft:blue_concrete
setblock 163 183 557 minecraft:white_concrete
fill 171 183 599 171 197 599 minecraft:blue_concrete
setblock 175 183 557 minecraft:white_concrete
fill 177 183 557 177 189 557 minecraft:blue_concrete
setblock 183 183 563 minecraft:shroomlight
fill 183 183 564 183 186 567 minecraft:blue_concrete
fill 183 183 576 183 241 576 minecraft:blue_concrete
fill 183 183 583 183 197 583 minecraft:blue_concrete
fill 141 184 566 141 240 566 minecraft:blue_concrete
fill 141 184 575 141 205 575 minecraft:blue_concrete
fill 146 184 557 146 224 557 minecraft:blue_concrete
fill 154 184 599 154 238 599 minecraft:blue_concrete
fill 161 184 599 161 186 599 minecraft:blue_concrete
setblock 162 184 599 minecraft:shroomlight
fill 163 184 557 163 197 557 minecraft:blue_concrete
fill 163 184 599 168 200 599 minecraft:blue_concrete
fill 173 184 599 173 232 599 minecraft:blue_concrete
fill 175 184 557 175 227 557 minecraft:blue_concrete
fill 183 184 561 183 241 561 minecraft:blue_concrete
fill 183 184 563 183 225 563 minecraft:blue_concrete
setblock 141 185 559 minecraft:shroomlight
fill 141 185 560 141 218 562 minecraft:blue_concrete
setblock 141 185 585 minecraft:white_concrete
fill 147 185 557 152 189 557 minecraft:blue_concrete
setblock 153 185 557 minecraft:shroomlight
fill 154 185 557 159 185 557 minecraft:blue_concrete
setblock 160 185 557 minecraft:shroomlight
fill 161 185 557 161 197 557 minecraft:blue_concrete
fill 162 185 599 162 189 599 minecraft:blue_concrete
fill 141 186 559 141 198 559 minecraft:blue_concrete
setblock 141 186 576 minecraft:shroomlight
fill 141 186 585 141 241 585 minecraft:blue_concrete
setblock 144 186 560 minecraft:light[level=14]
setblock 144 186 568 minecraft:light[level=14]
setblock 144 186 576 minecraft:light[level=14]
setblock 144 186 584 minecraft:light[level=14]
setblock 144 186 592 minecraft:light[level=14]
setblock 152 186 560 minecraft:light[level=14]
setblock 152 186 568 minecraft:light[level=14]
setblock 152 186 576 minecraft:light[level=14]
setblock 152 186 584 minecraft:light[level=14]
setblock 152 186 592 minecraft:light[level=14]
fill 153 186 557 156 204 557 minecraft:blue_concrete
setblock 157 186 557 minecraft:shroomlight
fill 158 186 557 160 196 557 minecraft:blue_concrete
setblock 160 186 560 minecraft:light[level=14]
setblock 160 186 568 minecraft:light[level=14]
setblock 160 186 576 minecraft:light[level=14]
setblock 160 186 584 minecraft:light[level=14]
setblock 160 186 592 minecraft:light[level=14]
setblock 168 186 560 minecraft:light[level=14]
setblock 168 186 568 minecraft:light[level=14]
setblock 168 186 576 minecraft:light[level=14]
setblock 168 186 584 minecraft:light[level=14]
setblock 168 186 592 minecraft:light[level=14]
setblock 176 186 560 minecraft:light[level=14]
setblock 176 186 568 minecraft:light[level=14]
setblock 176 186 576 minecraft:light[level=14]
setblock 176 186 584 minecraft:light[level=14]
setblock 176 186 592 minecraft:light[level=14]
setblock 177 186 599 minecraft:shroomlight
fill 183 186 586 183 191 588 minecraft:blue_concrete
setblock 183 186 589 minecraft:shroomlight
fill 183 186 590 183 240 590 minecraft:blue_concrete
fill 141 187 576 141 236 576 minecraft:blue_concrete
setblock 143 187 599 minecraft:shroomlight
setblock 145 187 599 minecraft:shroomlight
fill 146 187 599 148 193 599 minecraft:blue_concrete
fill 157 187 557 157 196 557 minecraft:blue_concrete
fill 160 187 576 162 187 578 minecraft:redstone_block
setblock 161 187 599 minecraft:shroomlight
setblock 165 187 557 minecraft:shroomlight
fill 165 187 571 167 187 573 minecraft:redstone_block
fill 168 187 580 170 187 582 minecraft:redstone_block
setblock 176 187 599 minecraft:shroomlight
fill 177 187 599 177 238 599 minecraft:blue_concrete
fill 183 187 564 183 240 564 minecraft:blue_concrete
setblock 183 187 565 minecraft:shroomlight
fill 183 187 566 183 197 567 minecraft:blue_concrete
fill 183 187 589 183 202 589 minecraft:blue_concrete
setblock 141 188 598 minecraft:shroomlight
fill 143 188 599 143 200 599 minecraft:blue_concrete
fill 145 188 599 145 212 599 minecraft:blue_concrete
fill 150 188 599 150 236 599 minecraft:blue_concrete
setblock 151 188 599 minecraft:shroomlight
fill 152 188 577 159 188 577 minecraft:black_concrete
fill 153 188 572 159 188 576 minecraft:black_concrete
fill 153 188 578 159 188 582 minecraft:black_concrete
fill 154 188 570 164 188 571 minecraft:black_concrete
fill 154 188 583 178 188 584 minecraft:black_concrete
fill 155 188 569 177 188 569 minecraft:black_concrete
fill 155 188 585 177 188 585 minecraft:black_concrete
fill 156 188 568 176 188 568 minecraft:black_concrete
fill 156 188 586 176 188 586 minecraft:black_concrete
fill 157 188 567 175 188 567 minecraft:black_concrete
fill 157 188 587 175 188 587 minecraft:black_concrete
fill 158 188 566 174 188 566 minecraft:black_concrete
fill 158 188 588 174 188 588 minecraft:black_concrete
fill 159 188 565 173 188 565 minecraft:black_concrete
fill 159 188 589 173 188 589 minecraft:black_concrete
fill 160 188 572 164 188 575 minecraft:black_concrete
fill 160 188 579 167 188 582 minecraft:black_concrete
setblock 160 188 599 minecraft:white_concrete
fill 161 188 564 171 188 564 minecraft:black_concrete
fill 161 188 590 171 188 590 minecraft:black_concrete
fill 161 188 599 161 198 599 minecraft:blue_concrete
fill 163 188 576 164 188 578 minecraft:black_concrete
fill 165 188 557 165 209 557 minecraft:blue_concrete
fill 165 188 570 178 188 570 minecraft:black_concrete
fill 165 188 574 179 188 575 minecraft:black_concrete
setblock 166 188 563 minecraft:black_concrete
setblock 166 188 591 minecraft:black_concrete
fill 168 188 571 178 188 573 minecraft:black_concrete
fill 168 188 576 179 188 579 minecraft:black_concrete
fill 171 188 580 179 188 582 minecraft:black_concrete
fill 176 188 599 176 218 599 minecraft:blue_concrete
fill 179 188 572 179 188 573 minecraft:black_concrete
setblock 180 188 577 minecraft:black_concrete
fill 183 188 565 183 206 565 minecraft:blue_concrete
setblock 141 189 567 minecraft:shroomlight
fill 141 189 568 141 197 568 minecraft:blue_concrete
fill 141 189 578 141 237 578 minecraft:blue_concrete
fill 141 189 579 142 189 579 minecraft:white_concrete
fill 141 189 580 141 203 580 minecraft:blue_concrete
fill 141 189 598 141 240 598 minecraft:blue_concrete
fill 142 189 558 142 189 562 minecraft:orange_terracotta
setblock 142 189 563 minecraft:white_concrete
fill 142 189 564 142 189 570 minecraft:orange_terracotta
setblock 142 189 571 minecraft:white_concrete
fill 142 189 572 142 189 578 minecraft:orange_terracotta
fill 142 189 580 142 189 586 minecraft:orange_terracotta
setblock 142 189 587 minecraft:white_concrete
fill 142 189 588 142 189 594 minecraft:orange_terracotta
setblock 142 189 595 minecraft:white_concrete
fill 142 189 596 146 189 598 minecraft:orange_terracotta
fill 143 189 558 143 189 561 minecraft:orange_terracotta
setblock 143 189 562 minecraft:white_concrete
fill 143 189 563 143 189 569 minecraft:orange_terracotta
setblock 143 189 570 minecraft:white_concrete
fill 143 189 571 143 189 577 minecraft:orange_terracotta
setblock 143 189 578 minecraft:white_concrete
fill 143 189 579 143 189 585 minecraft:orange_terracotta
setblock 143 189 586 minecraft:white_concrete
fill 143 189 587 143 189 593 minecraft:orange_terracotta
setblock 143 189 594 minecraft:white_concrete
fill 143 189 595 149 189 595 minecraft:orange_terracotta
fill 144 189 558 144 189 560 minecraft:orange_terracotta
setblock 144 189 561 minecraft:white_concrete
fill 144 189 562 144 189 568 minecraft:orange_terracotta
setblock 144 189 569 minecraft:white_concrete
fill 144 189 570 144 189 576 minecraft:orange_terracotta
setblock 144 189 577 minecraft:white_concrete
fill 144 189 578 144 189 584 minecraft:orange_terracotta
setblock 144 189 585 minecraft:white_concrete
fill 144 189 586 144 189 592 minecraft:orange_terracotta
setblock 144 189 593 minecraft:white_concrete
fill 144 189 594 150 189 594 minecraft:orange_terracotta
setblock 144 189 599 minecraft:shroomlight
fill 145 189 558 145 189 559 minecraft:orange_terracotta
setblock 145 189 560 minecraft:white_concrete
fill 145 189 561 145 189 567 minecraft:orange_terracotta
setblock 145 189 568 minecraft:white_concrete
fill 145 189 569 145 189 575 minecraft:orange_terracotta
setblock 145 189 576 minecraft:white_concrete
fill 145 189 577 145 189 583 minecraft:orange_terracotta
setblock 145 189 584 minecraft:white_concrete
fill 145 189 585 145 189 591 minecraft:orange_terracotta
setblock 145 189 592 minecraft:white_concrete
fill 145 189 593 151 189 593 minecraft:orange_terracotta
setblock 146 189 558 minecraft:orange_terracotta
setblock 146 189 559 minecraft:white_concrete
fill 146 189 560 146 189 566 minecraft:orange_terracotta
setblock 146 189 567 minecraft:white_concrete
fill 146 189 568 146 189 574 minecraft:orange_terracotta
setblock 146 189 575 minecraft:white_concrete
fill 146 189 576 146 189 582 minecraft:orange_terracotta
setblock 146 189 583 minecraft:white_concrete
fill 146 189 584 146 189 590 minecraft:orange_terracotta
setblock 146 189 591 minecraft:white_concrete
fill 146 189 592 152 189 592 minecraft:orange_terracotta
setblock 147 189 558 minecraft:white_concrete
fill 147 189 559 147 189 565 minecraft:orange_terracotta
setblock 147 189 566 minecraft:white_concrete
fill 147 189 567 147 189 573 minecraft:orange_terracotta
setblock 147 189 574 minecraft:white_concrete
fill 147 189 575 147 189 581 minecraft:orange_terracotta
setblock 147 189 582 minecraft:white_concrete
fill 147 189 583 147 189 589 minecraft:orange_terracotta
setblock 147 189 590 minecraft:white_concrete
fill 147 189 591 153 189 591 minecraft:orange_terracotta
fill 147 189 596 147 189 597 minecraft:orange_terracotta
setblock 147 189 598 minecraft:white_concrete
fill 148 189 558 148 189 564 minecraft:orange_terracotta
setblock 148 189 565 minecraft:white_concrete
fill 148 189 566 148 189 572 minecraft:orange_terracotta
setblock 148 189 573 minecraft:white_concrete
fill 148 189 574 148 189 580 minecraft:orange_terracotta
setblock 148 189 581 minecraft:white_concrete
fill 148 189 582 148 189 588 minecraft:orange_terracotta
setblock 148 189 589 minecraft:white_concrete
fill 148 189 590 154 189 590 minecraft:orange_terracotta
setblock 148 189 596 minecraft:orange_terracotta
setblock 148 189 597 minecraft:white_concrete
fill 148 189 598 154 189 598 minecraft:orange_terracotta
fill 149 189 558 149 189 563 minecraft:orange_terracotta
setblock 149 189 564 minecraft:white_concrete
fill 149 189 565 149 189 571 minecraft:orange_terracotta
setblock 149 189 572 minecraft:white_concrete
fill 149 189 573 149 189 579 minecraft:orange_terracotta
setblock 149 189 580 minecraft:white_concrete
fill 149 189 581 149 189 587 minecraft:orange_terracotta
setblock 149 189 588 minecraft:white_concrete
fill 149 189 589 155 189 589 minecraft:orange_terracotta
setblock 149 189 596 minecraft:white_concrete
fill 149 189 597 155 189 597 minecraft:orange_terracotta
fill 150 189 558 150 189 562 minecraft:orange_terracotta
setblock 150 189 563 minecraft:white_concrete
fill 150 189 564 150 189 570 minecraft:orange_terracotta
setblock 150 189 571 minecraft:white_concrete
fill 150 189 572 150 189 578 minecraft:orange_terracotta
setblock 150 189 579 minecraft:white_concrete
fill 150 189 580 150 189 586 minecraft:orange_terracotta
setblock 150 189 587 minecraft:white_concrete
fill 150 189 588 156 189 588 minecraft:orange_terracotta
setblock 150 189 595 minecraft:white_concrete
fill 150 189 596 156 189 596 minecraft:orange_terracotta
fill 151 189 558 151 189 561 minecraft:orange_terracotta
setblock 151 189 562 minecraft:white_concrete
fill 151 189 563 151 189 569 minecraft:orange_terracotta
setblock 151 189 570 minecraft:white_concrete
fill 151 189 571 151 189 577 minecraft:orange_terracotta
setblock 151 189 578 minecraft:white_concrete
fill 151 189 579 151 189 585 minecraft:orange_terracotta
setblock 151 189 586 minecraft:white_concrete
fill 151 189 587 157 189 587 minecraft:orange_terracotta
setblock 151 189 594 minecraft:white_concrete
fill 151 189 595 157 189 595 minecraft:orange_terracotta
fill 151 189 599 151 240 599 minecraft:blue_concrete
fill 152 189 558 152 189 560 minecraft:orange_terracotta
setblock 152 189 561 minecraft:white_concrete
fill 152 189 562 152 189 568 minecraft:orange_terracotta
setblock 152 189 569 minecraft:white_concrete
fill 152 189 570 152 189 576 minecraft:orange_terracotta
setblock 152 189 577 minecraft:white_concrete
fill 152 189 578 152 189 584 minecraft:orange_terracotta
setblock 152 189 585 minecraft:white_concrete
fill 152 189 586 158 189 586 minecraft:orange_terracotta
setblock 152 189 593 minecraft:white_concrete
fill 152 189 594 158 189 594 minecraft:orange_terracotta
fill 153 189 558 153 189 559 minecraft:orange_terracotta
setblock 153 189 560 minecraft:white_concrete
fill 153 189 561 153 189 567 minecraft:orange_terracotta
setblock 153 189 568 minecraft:white_concrete
fill 153 189 569 153 189 575 minecraft:orange_terracotta
setblock 153 189 576 minecraft:white_concrete
fill 153 189 577 153 189 583 minecraft:orange_terracotta
setblock 153 189 584 minecraft:white_concrete
fill 153 189 585 159 189 585 minecraft:orange_terracotta
setblock 153 189 592 minecraft:white_concrete
fill 153 189 593 159 189 593 minecraft:orange_terracotta
setblock 154 189 558 minecraft:orange_terracotta
setblock 154 189 559 minecraft:white_concrete
fill 154 189 560 154 189 566 minecraft:orange_terracotta
setblock 154 189 567 minecraft:white_concrete
fill 154 189 568 154 189 574 minecraft:orange_terracotta
setblock 154 189 575 minecraft:white_concrete
fill 154 189 576 154 189 582 minecraft:orange_terracotta
setblock 154 189 583 minecraft:white_concrete
fill 154 189 584 160 189 584 minecraft:orange_terracotta
setblock 154 189 591 minecraft:white_concrete
fill 154 189 592 160 189 592 minecraft:orange_terracotta
setblock 155 189 558 minecraft:white_concrete
fill 155 189 559 155 189 565 minecraft:orange_terracotta
setblock 155 189 566 minecraft:white_concrete
fill 155 189 567 155 189 573 minecraft:orange_terracotta
setblock 155 189 574 minecraft:white_concrete
fill 155 189 575 155 189 581 minecraft:orange_terracotta
setblock 155 189 582 minecraft:white_concrete
fill 155 189 583 161 189 583 minecraft:orange_terracotta
setblock 155 189 590 minecraft:white_concrete
fill 155 189 591 161 189 591 minecraft:orange_terracotta
setblock 155 189 598 minecraft:white_concrete
fill 156 189 558 156 189 564 minecraft:orange_terracotta
setblock 156 189 565 minecraft:white_concrete
fill 156 189 566 156 189 572 minecraft:orange_terracotta
setblock 156 189 573 minecraft:white_concrete
fill 156 189 574 156 189 580 minecraft:orange_terracotta
setblock 156 189 581 minecraft:white_concrete
fill 156 189 582 162 189 582 minecraft:orange_terracotta
setblock 156 189 589 minecraft:white_concrete
fill 156 189 590 162 189 590 minecraft:orange_terracotta
setblock 156 189 597 minecraft:white_concrete
fill 156 189 598 162 189 598 minecraft:orange_terracotta
fill 157 189 558 157 189 563 minecraft:orange_terracotta
setblock 157 189 564 minecraft:white_concrete
fill 157 189 565 157 189 571 minecraft:orange_terracotta
setblock 157 189 572 minecraft:white_concrete
fill 157 189 573 157 189 579 minecraft:orange_terracotta
setblock 157 189 580 minecraft:white_concrete
fill 157 189 581 163 189 581 minecraft:orange_terracotta
setblock 157 189 588 minecraft:white_concrete
fill 157 189 589 163 189 589 minecraft:orange_terracotta
setblock 157 189 596 minecraft:white_concrete
fill 157 189 597 163 189 597 minecraft:orange_terracotta
fill 158 189 558 158 189 562 minecraft:orange_terracotta
setblock 158 189 563 minecraft:white_concrete
fill 158 189 564 158 189 570 minecraft:orange_terracotta
setblock 158 189 571 minecraft:white_concrete
fill 158 189 572 158 189 578 minecraft:orange_terracotta
setblock 158 189 579 minecraft:white_concrete
fill 158 189 580 164 189 580 minecraft:orange_terracotta
setblock 158 189 587 minecraft:white_concrete
fill 158 189 588 164 189 588 minecraft:orange_terracotta
setblock 158 189 595 minecraft:white_concrete
fill 158 189 596 164 189 596 minecraft:orange_terracotta
fill 159 189 558 159 189 561 minecraft:orange_terracotta
setblock 159 189 562 minecraft:white_concrete
fill 159 189 563 159 189 569 minecraft:orange_terracotta
setblock 159 189 570 minecraft:white_concrete
fill 159 189 571 159 189 577 minecraft:orange_terracotta
setblock 159 189 578 minecraft:white_concrete
fill 159 189 579 164 189 579 minecraft:orange_terracotta
setblock 159 189 586 minecraft:white_concrete
fill 159 189 587 165 189 587 minecraft:orange_terracotta
setblock 159 189 594 minecraft:white_concrete
fill 159 189 595 165 189 595 minecraft:orange_terracotta
fill 160 189 558 160 189 560 minecraft:orange_terracotta
setblock 160 189 561 minecraft:white_concrete
fill 160 189 562 160 189 568 minecraft:orange_terracotta
setblock 160 189 569 minecraft:white_concrete
fill 160 189 570 160 189 576 minecraft:orange_terracotta
setblock 160 189 577 minecraft:white_concrete
fill 160 189 578 163 189 578 minecraft:orange_terracotta
setblock 160 189 585 minecraft:white_concrete
fill 160 189 586 166 189 586 minecraft:orange_terracotta
setblock 160 189 593 minecraft:white_concrete
fill 160 189 594 166 189 594 minecraft:orange_terracotta
fill 160 189 599 160 241 599 minecraft:blue_concrete
fill 161 189 558 161 189 559 minecraft:orange_terracotta
setblock 161 189 560 minecraft:white_concrete
fill 161 189 561 161 189 567 minecraft:orange_terracotta
setblock 161 189 568 minecraft:white_concrete
fill 161 189 569 161 189 575 minecraft:orange_terracotta
setblock 161 189 576 minecraft:white_concrete
fill 161 189 577 163 189 577 minecraft:orange_terracotta
setblock 161 189 584 minecraft:white_concrete
fill 161 189 585 167 189 585 minecraft:orange_terracotta
setblock 161 189 592 minecraft:white_concrete
fill 161 189 593 167 189 593 minecraft:orange_terracotta
setblock 162 189 558 minecraft:orange_terracotta
setblock 162 189 559 minecraft:white_concrete
fill 162 189 560 162 189 566 minecraft:orange_terracotta
setblock 162 189 567 minecraft:white_concrete
fill 162 189 568 162 189 574 minecraft:orange_terracotta
fill 162 189 575 162 190 575 minecraft:white_concrete
fill 162 189 576 163 189 576 minecraft:orange_terracotta
setblock 162 189 583 minecraft:white_concrete
fill 162 189 584 168 189 584 minecraft:orange_terracotta
setblock 162 189 591 minecraft:white_concrete
fill 162 189 592 168 189 592 minecraft:orange_terracotta
setblock 163 189 558 minecraft:white_concrete
fill 163 189 559 163 189 565 minecraft:orange_terracotta
setblock 163 189 566 minecraft:white_concrete
fill 163 189 567 163 189 573 minecraft:orange_terracotta
setblock 163 189 574 minecraft:white_concrete
fill 163 189 575 164 189 575 minecraft:orange_terracotta
setblock 163 189 582 minecraft:white_concrete
fill 163 189 583 169 189 583 minecraft:orange_terracotta
setblock 163 189 590 minecraft:white_concrete
fill 163 189 591 169 189 591 minecraft:orange_terracotta
setblock 163 189 598 minecraft:white_concrete
fill 164 189 558 164 189 564 minecraft:orange_terracotta
setblock 164 189 565 minecraft:white_concrete
fill 164 189 566 164 189 572 minecraft:orange_terracotta
setblock 164 189 573 minecraft:white_concrete
fill 164 189 574 170 189 574 minecraft:orange_terracotta
fill 164 189 576 164 190 578 minecraft:orange_concrete
setblock 164 189 581 minecraft:white_concrete
fill 164 189 582 170 189 582 minecraft:orange_terracotta
setblock 164 189 589 minecraft:white_concrete
fill 164 189 590 170 189 590 minecraft:orange_terracotta
setblock 164 189 597 minecraft:white_concrete
fill 164 189 598 170 189 598 minecraft:orange_terracotta
fill 165 189 558 165 189 563 minecraft:orange_terracotta
setblock 165 189 564 minecraft:white_concrete
fill 165 189 565 165 189 571 minecraft:orange_terracotta
setblock 165 189 572 minecraft:white_concrete
fill 165 189 573 171 189 573 minecraft:orange_terracotta
fill 165 189 575 167 190 575 minecraft:orange_concrete
fill 165 189 579 167 190 579 minecraft:orange_concrete
setblock 165 189 580 minecraft:white_concrete
fill 165 189 581 171 189 581 minecraft:orange_terracotta
setblock 165 189 588 minecraft:white_concrete
fill 165 189 589 171 189 589 minecraft:orange_terracotta
setblock 165 189 596 minecraft:white_concrete
fill 165 189 597 171 189 597 minecraft:orange_terracotta
fill 166 189 558 166 189 562 minecraft:orange_terracotta
setblock 166 189 563 minecraft:white_concrete
fill 166 189 564 166 189 570 minecraft:orange_terracotta
setblock 166 189 571 minecraft:white_concrete
fill 166 189 572 172 189 572 minecraft:orange_terracotta
fill 166 189 580 172 189 580 minecraft:orange_terracotta
setblock 166 189 587 minecraft:white_concrete
fill 166 189 588 172 189 588 minecraft:orange_terracotta
setblock 166 189 595 minecraft:white_concrete
fill 166 189 596 172 189 596 minecraft:orange_terracotta
fill 167 189 558 167 189 561 minecraft:orange_terracotta
setblock 167 189 562 minecraft:white_concrete
fill 167 189 563 167 189 569 minecraft:orange_terracotta
setblock 167 189 570 minecraft:white_concrete
fill 167 189 571 173 189 571 minecraft:orange_terracotta
setblock 167 189 586 minecraft:white_concrete
fill 167 189 587 173 189 587 minecraft:orange_terracotta
setblock 167 189 594 minecraft:white_concrete
fill 167 189 595 173 189 595 minecraft:orange_terracotta
fill 168 189 558 168 189 560 minecraft:orange_terracotta
setblock 168 189 561 minecraft:white_concrete
fill 168 189 562 168 189 568 minecraft:orange_terracotta
setblock 168 189 569 minecraft:white_concrete
fill 168 189 570 174 189 570 minecraft:orange_terracotta
fill 168 189 575 169 189 575 minecraft:orange_terracotta
fill 168 189 576 168 190 578 minecraft:orange_concrete
fill 168 189 579 173 189 579 minecraft:orange_terracotta
setblock 168 189 585 minecraft:white_concrete
fill 168 189 586 174 189 586 minecraft:orange_terracotta
setblock 168 189 593 minecraft:white_concrete
fill 168 189 594 174 189 594 minecraft:orange_terracotta
fill 169 189 558 169 189 559 minecraft:orange_terracotta
setblock 169 189 560 minecraft:white_concrete
fill 169 189 561 169 189 567 minecraft:orange_terracotta
setblock 169 189 568 minecraft:white_concrete
fill 169 189 569 175 189 569 minecraft:orange_terracotta
setblock 169 189 576 minecraft:white_concrete
fill 169 189 577 174 189 578 minecraft:orange_terracotta
setblock 169 189 584 minecraft:white_concrete
fill 169 189 585 175 189 585 minecraft:orange_terracotta
setblock 169 189 592 minecraft:white_concrete
fill 169 189 593 175 189 593 minecraft:orange_terracotta
setblock 170 189 558 minecraft:orange_terracotta
setblock 170 189 559 minecraft:white_concrete
fill 170 189 560 170 189 566 minecraft:orange_terracotta
setblock 170 189 567 minecraft:white_concrete
fill 170 189 568 176 189 568 minecraft:orange_terracotta
setblock 170 189 575 minecraft:white_concrete
fill 170 189 576 176 189 576 minecraft:orange_terracotta
setblock 170 189 583 minecraft:white_concrete
fill 170 189 584 176 189 584 minecraft:orange_terracotta
setblock 170 189 591 minecraft:white_concrete
fill 170 189 592 176 189 592 minecraft:orange_terracotta
setblock 171 189 558 minecraft:white_concrete
fill 171 189 559 171 189 565 minecraft:orange_terracotta
setblock 171 189 566 minecraft:white_concrete
fill 171 189 567 177 189 567 minecraft:orange_terracotta
setblock 171 189 574 minecraft:white_concrete
fill 171 189 575 177 189 575 minecraft:orange_terracotta
setblock 171 189 582 minecraft:white_concrete
fill 171 189 583 177 189 583 minecraft:orange_terracotta
setblock 171 189 590 minecraft:white_concrete
fill 171 189 591 177 189 591 minecraft:orange_terracotta
setblock 171 189 598 minecraft:white_concrete
fill 172 189 558 172 189 564 minecraft:orange_terracotta
setblock 172 189 565 minecraft:white_concrete
fill 172 189 566 178 189 566 minecraft:orange_terracotta
setblock 172 189 573 minecraft:white_concrete
fill 172 189 574 178 189 574 minecraft:orange_terracotta
setblock 172 189 581 minecraft:white_concrete
fill 172 189 582 178 189 582 minecraft:orange_terracotta
setblock 172 189 589 minecraft:white_concrete
fill 172 189 590 178 189 590 minecraft:orange_terracotta
setblock 172 189 597 minecraft:white_concrete
fill 172 189 598 178 189 598 minecraft:orange_terracotta
fill 173 189 558 173 189 563 minecraft:orange_terracotta
setblock 173 189 564 minecraft:white_concrete
fill 173 189 565 179 189 565 minecraft:orange_terracotta
setblock 173 189 572 minecraft:white_concrete
fill 173 189 573 179 189 573 minecraft:orange_terracotta
setblock 173 189 580 minecraft:white_concrete
fill 173 189 581 179 189 581 minecraft:orange_terracotta
setblock 173 189 588 minecraft:white_concrete
fill 173 189 589 179 189 589 minecraft:orange_terracotta
setblock 173 189 596 minecraft:white_concrete
fill 173 189 597 179 189 597 minecraft:orange_terracotta
fill 174 189 558 174 189 562 minecraft:orange_terracotta
setblock 174 189 563 minecraft:white_concrete
fill 174 189 564 180 189 564 minecraft:orange_terracotta
setblock 174 189 571 minecraft:white_concrete
fill 174 189 572 180 189 572 minecraft:orange_terracotta
setblock 174 189 579 minecraft:white_concrete
fill 174 189 580 180 189 580 minecraft:orange_terracotta
setblock 174 189 587 minecraft:white_concrete
fill 174 189 588 180 189 588 minecraft:orange_terracotta
setblock 174 189 595 minecraft:white_concrete
fill 174 189 596 180 189 596 minecraft:orange_terracotta
fill 175 189 558 175 189 561 minecraft:orange_terracotta
setblock 175 189 562 minecraft:white_concrete
fill 175 189 563 181 189 563 minecraft:orange_terracotta
setblock 175 189 570 minecraft:white_concrete
fill 175 189 571 181 189 571 minecraft:orange_terracotta
setblock 175 189 577 minecraft:orange_terracotta
setblock 175 189 578 minecraft:white_concrete
fill 175 189 579 181 189 579 minecraft:orange_terracotta
setblock 175 189 586 minecraft:white_concrete
fill 175 189 587 181 189 587 minecraft:orange_terracotta
setblock 175 189 594 minecraft:white_concrete
fill 175 189 595 181 189 595 minecraft:orange_terracotta
fill 176 189 558 176 189 560 minecraft:orange_terracotta
setblock 176 189 561 minecraft:white_concrete
fill 176 189 562 182 189 562 minecraft:orange_terracotta
setblock 176 189 569 minecraft:white_concrete
fill 176 189 570 182 189 570 minecraft:orange_terracotta
setblock 176 189 577 minecraft:white_concrete
fill 176 189 578 182 189 578 minecraft:orange_terracotta
setblock 176 189 585 minecraft:white_concrete
fill 176 189 586 182 189 586 minecraft:orange_terracotta
setblock 176 189 593 minecraft:white_concrete
fill 176 189 594 182 189 594 minecraft:orange_terracotta
fill 177 189 558 177 189 559 minecraft:orange_terracotta
setblock 177 189 560 minecraft:white_concrete
fill 177 189 561 182 189 561 minecraft:orange_terracotta
setblock 177 189 568 minecraft:white_concrete
fill 177 189 569 182 189 569 minecraft:orange_terracotta
setblock 177 189 576 minecraft:white_concrete
fill 177 189 577 182 189 577 minecraft:orange_terracotta
setblock 177 189 584 minecraft:white_concrete
fill 177 189 585 182 189 585 minecraft:orange_terracotta
setblock 177 189 592 minecraft:white_concrete
fill 177 189 593 182 189 593 minecraft:orange_terracotta
setblock 178 189 558 minecraft:orange_terracotta
setblock 178 189 559 minecraft:white_concrete
fill 178 189 560 182 189 560 minecraft:orange_terracotta
setblock 178 189 567 minecraft:white_concrete
fill 178 189 568 182 189 568 minecraft:orange_terracotta
setblock 178 189 575 minecraft:white_concrete
fill 178 189 576 182 189 576 minecraft:orange_terracotta
setblock 178 189 583 minecraft:white_concrete
fill 178 189 584 182 189 584 minecraft:orange_terracotta
setblock 178 189 591 minecraft:white_concrete
fill 178 189 592 182 189 592 minecraft:orange_terracotta
setblock 179 189 558 minecraft:white_concrete
fill 179 189 559 182 189 559 minecraft:orange_terracotta
setblock 179 189 566 minecraft:white_concrete
fill 179 189 567 182 189 567 minecraft:orange_terracotta
setblock 179 189 574 minecraft:white_concrete
fill 179 189 575 182 189 575 minecraft:orange_terracotta
setblock 179 189 582 minecraft:white_concrete
fill 179 189 583 182 189 583 minecraft:orange_terracotta
setblock 179 189 590 minecraft:white_concrete
fill 179 189 591 182 189 591 minecraft:orange_terracotta
setblock 179 189 598 minecraft:white_concrete
fill 180 189 558 182 189 558 minecraft:orange_terracotta
setblock 180 189 565 minecraft:white_concrete
fill 180 189 566 182 189 566 minecraft:orange_terracotta
setblock 180 189 573 minecraft:white_concrete
fill 180 189 574 182 189 574 minecraft:orange_terracotta
setblock 180 189 581 minecraft:white_concrete
fill 180 189 582 182 189 582 minecraft:orange_terracotta
setblock 180 189 589 minecraft:white_concrete
fill 180 189 590 182 189 590 minecraft:orange_terracotta
setblock 180 189 597 minecraft:white_concrete
fill 180 189 598 182 189 598 minecraft:orange_terracotta
setblock 181 189 564 minecraft:white_concrete
fill 181 189 565 182 189 565 minecraft:orange_terracotta
setblock 181 189 572 minecraft:white_concrete
fill 181 189 573 182 189 573 minecraft:orange_terracotta
setblock 181 189 580 minecraft:white_concrete
fill 181 189 581 182 189 581 minecraft:orange_terracotta
setblock 181 189 588 minecraft:white_concrete
fill 181 189 589 182 189 589 minecraft:orange_terracotta
setblock 181 189 596 minecraft:white_concrete
fill 181 189 597 182 189 597 minecraft:orange_terracotta
setblock 182 189 563 minecraft:white_concrete
setblock 182 189 564 minecraft:orange_terracotta
setblock 182 189 571 minecraft:white_concrete
setblock 182 189 572 minecraft:orange_terracotta
setblock 182 189 579 minecraft:white_concrete
setblock 182 189 580 minecraft:orange_terracotta
setblock 182 189 587 minecraft:white_concrete
setblock 182 189 588 minecraft:orange_terracotta
setblock 182 189 595 minecraft:white_concrete
setblock 182 189 596 minecraft:orange_terracotta
fill 183 189 568 183 236 568 minecraft:blue_concrete
setblock 183 189 569 minecraft:shroomlight
fill 183 189 570 183 193 570 minecraft:blue_concrete
setblock 183 189 571 minecraft:shroomlight
fill 183 189 572 183 194 572 minecraft:blue_concrete
fill 141 190 567 141 196 567 minecraft:blue_concrete
setblock 141 190 577 minecraft:shroomlight
fill 141 190 579 141 237 579 minecraft:blue_concrete
fill 144 190 599 144 237 599 minecraft:blue_concrete
fill 147 190 557 150 191 557 minecraft:blue_concrete
setblock 151 190 557 minecraft:shroomlight
fill 152 190 557 152 191 557 minecraft:blue_concrete
setblock 152 190 577 minecraft:gold_block
fill 162 190 572 162 196 574 minecraft:white_concrete
fill 162 190 576 162 190 582 minecraft:white_concrete
setblock 162 190 599 minecraft:shroomlight
setblock 166 190 563 minecraft:gold_block
setblock 166 190 591 minecraft:gold_block
setblock 177 190 557 minecraft:white_concrete
setblock 180 190 577 minecraft:gold_block
fill 183 190 569 183 211 569 minecraft:blue_concrete
fill 183 190 571 183 240 571 minecraft:blue_concrete
setblock 183 190 581 minecraft:shroomlight
fill 183 190 582 183 236 582 minecraft:blue_concrete
fill 141 191 577 141 240 577 minecraft:blue_concrete
fill 151 191 557 151 209 557 minecraft:blue_concrete
fill 162 191 575 162 194 579 minecraft:red_concrete
fill 162 191 580 162 196 582 minecraft:white_concrete
fill 162 191 599 162 241 599 minecraft:blue_concrete
setblock 175 191 599 minecraft:white_concrete
fill 177 191 557 177 197 557 minecraft:blue_concrete
setblock 180 191 599 minecraft:shroomlight
fill 183 191 581 183 209 581 minecraft:blue_concrete
setblock 183 191 595 minecraft:white_concrete
fill 147 192 557 148 202 557 minecraft:blue_concrete
setblock 149 192 557 minecraft:shroomlight
fill 150 192 557 150 196 557 minecraft:blue_concrete
setblock 152 192 557 minecraft:shroomlight
fill 175 192 599 175 240 599 minecraft:blue_concrete
fill 180 192 599 180 240 599 minecraft:blue_concrete
fill 183 192 586 183 199 587 minecraft:blue_concrete
setblock 183 192 588 minecraft:shroomlight
fill 183 192 595 183 193 595 minecraft:blue_concrete
fill 149 193 557 149 239 557 minecraft:blue_concrete
fill 152 193 557 152 226 557 minecraft:blue_concrete
setblock 158 193 599 minecraft:shroomlight
fill 159 193 599 159 197 599 minecraft:blue_concrete
fill 183 193 588 183 240 588 minecraft:blue_concrete
setblock 144 194 560 minecraft:light[level=14]
setblock 144 194 568 minecraft:light[level=14]
setblock 144 194 576 minecraft:light[level=14]
setblock 144 194 584 minecraft:light[level=14]
setblock 144 194 592 minecraft:light[level=14]
fill 146 194 599 147 203 599 minecraft:blue_concrete
setblock 148 194 599 minecraft:white_concrete
setblock 152 194 560 minecraft:light[level=14]
setblock 152 194 568 minecraft:light[level=14]
setblock 152 194 576 minecraft:light[level=14]
setblock 152 194 584 minecraft:light[level=14]
setblock 152 194 592 minecraft:light[level=14]
fill 158 194 599 158 209 599 minecraft:blue_concrete
setblock 160 194 560 minecraft:light[level=14]
setblock 160 194 568 minecraft:light[level=14]
setblock 160 194 576 minecraft:light[level=14]
setblock 160 194 584 minecraft:light[level=14]
setblock 160 194 592 minecraft:light[level=14]
setblock 168 194 560 minecraft:light[level=14]
setblock 168 194 568 minecraft:light[level=14]
setblock 168 194 576 minecraft:light[level=14]
setblock 168 194 584 minecraft:light[level=14]
setblock 168 194 592 minecraft:light[level=14]
setblock 170 194 557 minecraft:shroomlight
setblock 176 194 560 minecraft:light[level=14]
setblock 176 194 568 minecraft:light[level=14]
setblock 176 194 576 minecraft:light[level=14]
setblock 176 194 584 minecraft:light[level=14]
setblock 176 194 592 minecraft:light[level=14]
fill 178 194 599 178 236 599 minecraft:blue_concrete
setblock 179 194 599 minecraft:shroomlight
setblock 183 194 570 minecraft:white_concrete
setblock 183 194 595 minecraft:shroomlight
setblock 141 195 570 minecraft:shroomlight
setblock 142 195 599 minecraft:shroomlight
fill 148 195 599 148 220 599 minecraft:blue_concrete
fill 162 195 575 162 196 579 minecraft:white_concrete
fill 170 195 557 170 219 557 minecraft:blue_concrete
setblock 176 195 557 minecraft:white_concrete
fill 179 195 599 179 240 599 minecraft:blue_concrete
fill 183 195 570 183 234 570 minecraft:blue_concrete
setblock 183 195 572 minecraft:white_concrete
setblock 183 195 584 minecraft:white_concrete
fill 183 195 595 183 211 595 minecraft:blue_concrete
fill 141 196 570 141 240 570 minecraft:blue_concrete
fill 142 196 599 142 240 599 minecraft:blue_concrete
setblock 155 196 599 minecraft:shroomlight
fill 176 196 557 176 212 557 minecraft:blue_concrete
fill 183 196 558 183 218 558 minecraft:blue_concrete
setblock 183 196 559 minecraft:shroomlight
fill 183 196 560 183 240 560 minecraft:blue_concrete
fill 183 196 572 183 225 572 minecraft:blue_concrete
fill 183 196 584 183 236 584 minecraft:blue_concrete
setblock 141 197 567 minecraft:white_concrete
setblock 141 197 591 minecraft:shroomlight
fill 141 197 592 141 224 593 minecraft:blue_concrete
setblock 150 197 557 minecraft:shroomlight
setblock 155 197 599 minecraft:blue_concrete
fill 157 197 557 158 197 557 minecraft:white_concrete
fill 159 197 557 160 204 557 minecraft:blue_concrete
fill 171 197 560 175 198 564 minecraft:polished_blackstone
fill 173 197 558 173 197 559 minecraft:polished_blackstone
fill 183 197 559 183 232 559 minecraft:blue_concrete
fill 141 198 565 141 200 565 minecraft:gold_block
fill 141 198 567 141 237 567 minecraft:blue_concrete
setblock 141 198 568 minecraft:shroomlight
fill 141 198 581 141 200 581 minecraft:gold_block
setblock 141 198 589 minecraft:shroomlight
fill 141 198 591 141 222 591 minecraft:blue_concrete
fill 141 198 597 141 200 597 minecraft:gold_block
fill 145 198 557 145 200 557 minecraft:gold_block
fill 150 198 557 150 240 557 minecraft:blue_concrete
fill 155 198 599 155 200 599 minecraft:gold_block
fill 157 198 557 158 236 557 minecraft:blue_concrete
setblock 159 198 599 minecraft:shroomlight
fill 161 198 557 161 200 557 minecraft:gold_block
setblock 163 198 557 minecraft:white_concrete
fill 171 198 599 171 200 599 minecraft:gold_block
fill 177 198 557 177 200 557 minecraft:gold_block
fill 183 198 566 183 205 566 minecraft:blue_concrete
fill 183 198 567 183 200 567 minecraft:gold_block
fill 183 198 583 183 200 583 minecraft:gold_block
setblock 141 199 559 minecraft:shroomlight
fill 141 199 568 141 205 568 minecraft:blue_concrete
fill 141 199 589 141 240 589 minecraft:blue_concrete
fill 159 199 599 159 236 599 minecraft:blue_concrete
setblock 161 199 599 minecraft:shroomlight
fill 163 199 557 163 211 557 minecraft:blue_concrete
fill 176 199 572 178 206 575 minecraft:yellow_concrete
fill 141 200 559 141 228 559 minecraft:blue_concrete
setblock 141 200 564 minecraft:white_concrete
fill 147 200 575 148 207 576 minecraft:orange_concrete
fill 161 200 599 161 240 599 minecraft:blue_concrete
fill 174 200 573 175 205 574 minecraft:yellow_concrete
fill 175 200 572 175 205 572 minecraft:yellow_concrete
fill 175 200 575 175 205 575 minecraft:yellow_concrete
fill 176 200 571 178 205 571 minecraft:yellow_concrete
fill 176 200 576 178 205 576 minecraft:yellow_concrete
fill 179 200 572 179 205 575 minecraft:yellow_concrete
fill 180 200 573 180 205 574 minecraft:yellow_concrete
setblock 183 200 586 minecraft:shroomlight
fill 183 200 587 183 205 587 minecraft:blue_concrete
fill 141 201 564 141 206 565 minecraft:blue_concrete
fill 141 201 581 141 206 581 minecraft:blue_concrete
setblock 141 201 582 minecraft:shroomlight
fill 141 201 597 141 206 597 minecraft:blue_concrete
setblock 143 201 599 minecraft:shroomlight
fill 145 201 557 145 206 557 minecraft:blue_concrete
fill 145 201 575 146 206 576 minecraft:orange_concrete
fill 146 201 574 149 206 574 minecraft:orange_concrete
fill 146 201 577 149 206 577 minecraft:orange_concrete
fill 147 201 573 148 206 573 minecraft:orange_concrete
fill 147 201 578 148 206 578 minecraft:orange_concrete
fill 149 201 575 150 206 576 minecraft:orange_concrete
fill 155 201 599 155 206 599 minecraft:blue_concrete
fill 161 201 557 161 206 557 minecraft:blue_concrete
fill 163 201 599 166 204 599 minecraft:blue_concrete
setblock 167 201 599 minecraft:shroomlight
fill 168 201 599 168 202 599 minecraft:blue_concrete
setblock 169 201 557 minecraft:shroomlight
fill 171 201 599 171 206 599 minecraft:blue_concrete
fill 173 201 591 177 202 595 minecraft:polished_blackstone
fill 174 201 572 174 204 572 minecraft:yellow_concrete
fill 174 201 575 174 204 575 minecraft:yellow_concrete
fill 175 201 571 175 204 571 minecraft:yellow_concrete
fill 175 201 576 175 204 576 minecraft:yellow_concrete
fill 175 201 596 175 201 597 minecraft:polished_blackstone
fill 176 201 570 178 204 570 minecraft:yellow_concrete
fill 176 201 577 178 204 577 minecraft:yellow_concrete
fill 177 201 557 177 206 557 minecraft:blue_concrete
fill 179 201 571 179 204 571 minecraft:yellow_concrete
fill 179 201 576 179 204 576 minecraft:yellow_concrete
fill 180 201 572 180 204 572 minecraft:yellow_concrete
fill 180 201 575 180 204 575 minecraft:yellow_concrete
fill 183 201 567 183 206 567 minecraft:blue_concrete
fill 183 201 583 183 206 583 minecraft:blue_concrete
fill 183 201 586 183 237 586 minecraft:blue_concrete
fill 141 202 582 141 237 582 minecraft:blue_concrete
fill 143 202 599 143 221 599 minecraft:blue_concrete
setblock 144 202 560 minecraft:light[level=14]
setblock 144 202 568 minecraft:light[level=14]
setblock 144 202 576 minecraft:light[level=14]
setblock 144 202 584 minecraft:light[level=14]
setblock 144 202 592 minecraft:light[level=14]
fill 145 202 574 145 205 574 minecraft:orange_concrete
fill 145 202 577 145 205 578 minecraft:orange_concrete
fill 146 202 573 146 205 573 minecraft:orange_concrete
fill 146 202 578 146 205 578 minecraft:orange_concrete
fill 149 202 573 149 205 573 minecraft:orange_concrete
fill 149 202 578 149 205 578 minecraft:orange_concrete
fill 150 202 574 150 205 574 minecraft:orange_concrete
fill 150 202 577 150 205 577 minecraft:orange_concrete
setblock 152 202 560 minecraft:light[level=14]
setblock 152 202 568 minecraft:light[level=14]
setblock 152 202 576 minecraft:light[level=14]
setblock 152 202 584 minecraft:light[level=14]
setblock 152 202 592 minecraft:light[level=14]
setblock 160 202 560 minecraft:light[level=14]
setblock 160 202 568 minecraft:light[level=14]
setblock 160 202 576 minecraft:light[level=14]
setblock 160 202 584 minecraft:light[level=14]
setblock 160 202 592 minecraft:light[level=14]
fill 167 202 599 167 212 599 minecraft:blue_concrete
setblock 168 202 560 minecraft:light[level=14]
setblock 168 202 568 minecraft:light[level=14]
setblock 168 202 576 minecraft:light[level=14]
setblock 168 202 584 minecraft:light[level=14]
setblock 168 202 592 minecraft:light[level=14]
fill 169 202 557 169 240 557 minecraft:blue_concrete
fill 170 202 560 170 203 564 minecraft:waxed_copper_block
fill 171 202 559 171 203 560 minecraft:waxed_copper_block
fill 171 202 562 175 203 562 minecraft:waxed_cut_copper
fill 171 202 564 171 203 565 minecraft:waxed_copper_block
fill 172 202 559 175 203 559 minecraft:waxed_copper_block
fill 172 202 565 175 203 565 minecraft:waxed_copper_block
fill 173 202 560 173 203 561 minecraft:waxed_cut_copper
fill 173 202 563 173 203 564 minecraft:waxed_cut_copper
fill 174 202 571 174 203 571 minecraft:yellow_concrete
fill 174 202 576 174 203 576 minecraft:yellow_concrete
fill 175 202 560 176 203 560 minecraft:waxed_copper_block
fill 175 202 564 176 203 564 minecraft:waxed_copper_block
fill 176 202 561 176 203 563 minecraft:waxed_copper_block
setblock 176 202 568 minecraft:light[level=14]
setblock 176 202 584 minecraft:light[level=14]
fill 180 202 571 180 203 571 minecraft:yellow_concrete
fill 180 202 576 180 203 576 minecraft:yellow_concrete
setblock 183 202 591 minecraft:shroomlight
fill 141 203 594 141 207 595 minecraft:blue_concrete
setblock 141 203 596 minecraft:shroomlight
fill 144 203 575 144 204 577 minecraft:orange_concrete
fill 145 203 573 145 204 573 minecraft:orange_concrete
fill 147 203 557 147 240 557 minecraft:blue_concrete
fill 147 203 572 148 204 572 minecraft:orange_concrete
fill 147 203 579 148 204 579 minecraft:orange_concrete
setblock 148 203 557 minecraft:shroomlight
fill 150 203 573 150 204 573 minecraft:orange_concrete
fill 150 203 578 150 204 578 minecraft:orange_concrete
fill 151 203 575 151 204 576 minecraft:orange_concrete
setblock 168 203 599 minecraft:shroomlight
setblock 183 203 589 minecraft:shroomlight
fill 183 203 591 183 208 591 minecraft:blue_concrete
setblock 141 204 580 minecraft:shroomlight
fill 141 204 596 141 216 596 minecraft:blue_concrete
setblock 146 204 599 minecraft:shroomlight
fill 147 204 599 147 213 599 minecraft:blue_concrete
fill 148 204 557 148 240 557 minecraft:blue_concrete
fill 168 204 599 168 208 599 minecraft:blue_concrete
fill 183 204 589 183 240 589 minecraft:blue_concrete
fill 141 205 580 141 236 580 minecraft:blue_concrete
fill 146 205 599 146 215 599 minecraft:blue_concrete
setblock 153 205 557 minecraft:shroomlight
fill 154 205 557 156 227 557 minecraft:blue_concrete
fill 159 205 557 159 237 557 minecraft:blue_concrete
setblock 160 205 557 minecraft:shroomlight
fill 163 205 599 164 208 599 minecraft:blue_concrete
setblock 165 205 599 minecraft:shroomlight
fill 166 205 599 166 241 599 minecraft:blue_concrete
fill 183 205 577 183 215 577 minecraft:blue_concrete
setblock 183 205 578 minecraft:shroomlight
fill 183 205 579 183 236 579 minecraft:blue_concrete
setblock 141 206 568 minecraft:shroomlight
setblock 141 206 575 minecraft:shroomlight
fill 153 206 557 153 236 557 minecraft:blue_concrete
fill 160 206 557 160 237 557 minecraft:blue_concrete
fill 165 206 599 165 240 599 minecraft:blue_concrete
fill 172 206 591 172 207 595 minecraft:waxed_copper_block
fill 173 206 590 173 207 591 minecraft:waxed_copper_block
fill 173 206 593 177 207 593 minecraft:waxed_cut_copper
fill 173 206 595 173 207 596 minecraft:waxed_copper_block
fill 174 206 590 177 207 590 minecraft:waxed_copper_block
fill 174 206 596 177 207 596 minecraft:waxed_copper_block
fill 175 206 591 175 207 592 minecraft:waxed_cut_copper
fill 175 206 594 175 207 595 minecraft:waxed_cut_copper
fill 177 206 591 178 207 591 minecraft:waxed_copper_block
fill 177 206 595 178 207 595 minecraft:waxed_copper_block
setblock 178 206 557 minecraft:white_concrete
fill 178 206 592 178 207 594 minecraft:waxed_copper_block
setblock 183 206 566 minecraft:white_concrete
fill 183 206 578 183 233 578 minecraft:blue_concrete
setblock 183 206 587 minecraft:white_concrete
fill 141 207 564 141 221 564 minecraft:blue_concrete
fill 141 207 565 141 209 565 minecraft:gold_block
fill 141 207 568 141 223 568 minecraft:blue_concrete
fill 141 207 575 141 233 575 minecraft:blue_concrete
fill 141 207 581 141 209 581 minecraft:gold_block
fill 141 207 597 141 209 597 minecraft:gold_block
fill 145 207 557 145 209 557 minecraft:gold_block
fill 155 207 599 155 209 599 minecraft:gold_block
fill 161 207 557 161 209 557 minecraft:gold_block
fill 171 207 599 171 209 599 minecraft:gold_block
fill 177 207 557 177 209 557 minecraft:gold_block
setblock 178 207 557 minecraft:blue_concrete
setblock 183 207 565 minecraft:shroomlight
fill 183 207 566 183 231 566 minecraft:blue_concrete
fill 183 207 567 183 209 567 minecraft:gold_block
fill 183 207 583 183 209 583 minecraft:gold_block
fill 183 207 587 183 234 587 minecraft:blue_concrete
setblock 141 208 571 minecraft:shroomlight
setblock 141 208 594 minecraft:shroomlight
fill 141 208 595 141 240 595 minecraft:blue_concrete
setblock 178 208 557 minecraft:shroomlight
fill 183 208 565 183 222 565 minecraft:blue_concrete
fill 141 209 571 141 240 571 minecraft:blue_concrete
fill 141 209 594 141 240 594 minecraft:blue_concrete
fill 163 209 599 163 233 599 minecraft:blue_concrete
setblock 164 209 599 minecraft:white_concrete
setblock 168 209 599 minecraft:white_concrete
fill 178 209 557 178 240 557 minecraft:blue_concrete
fill 181 209 557 181 216 557 minecraft:blue_concrete
setblock 182 209 557 minecraft:shroomlight
fill 183 209 557 183 240 557 minecraft:blue_concrete
setblock 183 209 580 minecraft:shroomlight
setblock 183 209 591 minecraft:shroomlight
fill 141 210 565 141 215 565 minecraft:blue_concrete
fill 141 210 581 141 215 581 minecraft:blue_concrete
setblock 141 210 597 minecraft:blue_concrete
setblock 144 210 560 minecraft:light[level=14]
setblock 144 210 568 minecraft:light[level=14]
setblock 144 210 576 minecraft:light[level=14]
setblock 144 210 584 minecraft:light[level=14]
setblock 144 210 592 minecraft:light[level=14]
fill 145 210 557 145 215 557 minecraft:blue_concrete
setblock 151 210 557 minecraft:shroomlight
setblock 152 210 560 minecraft:light[level=14]
setblock 152 210 568 minecraft:light[level=14]
setblock 152 210 576 minecraft:light[level=14]
setblock 152 210 584 minecraft:light[level=14]
setblock 152 210 592 minecraft:light[level=14]
fill 155 210 599 155 215 599 minecraft:blue_concrete
setblock 158 210 599 minecraft:white_concrete
setblock 160 210 560 minecraft:light[level=14]
setblock 160 210 568 minecraft:light[level=14]
setblock 160 210 576 minecraft:light[level=14]
setblock 160 210 584 minecraft:light[level=14]
setblock 160 210 592 minecraft:light[level=14]
fill 161 210 557 161 215 557 minecraft:blue_concrete
fill 164 210 599 164 212 599 minecraft:blue_concrete
setblock 165 210 557 minecraft:shroomlight
setblock 168 210 560 minecraft:light[level=14]
setblock 168 210 568 minecraft:light[level=14]
setblock 168 210 576 minecraft:light[level=14]
setblock 168 210 584 minecraft:light[level=14]
setblock 168 210 592 minecraft:light[level=14]
fill 168 210 599 168 222 599 minecraft:blue_concrete
fill 171 210 599 171 215 599 minecraft:blue_concrete
setblock 176 210 560 minecraft:light[level=14]
setblock 176 210 568 minecraft:light[level=14]
setblock 176 210 576 minecraft:light[level=14]
setblock 176 210 584 minecraft:light[level=14]
setblock 176 210 592 minecraft:light[level=14]
fill 177 210 557 177 215 557 minecraft:blue_concrete
fill 182 210 557 182 240 557 minecraft:blue_concrete
fill 183 210 567 183 215 567 minecraft:blue_concrete
fill 183 210 580 183 232 580 minecraft:blue_concrete
setblock 183 210 581 minecraft:shroomlight
fill 183 210 583 183 215 583 minecraft:blue_concrete
fill 183 210 591 183 211 591 minecraft:blue_concrete
setblock 141 211 597 minecraft:white_concrete
fill 151 211 557 151 238 557 minecraft:blue_concrete
fill 158 211 599 158 220 599 minecraft:blue_concrete
fill 165 211 557 165 240 557 minecraft:blue_concrete
fill 183 211 581 183 238 581 minecraft:blue_concrete
setblock 183 211 592 minecraft:shroomlight
fill 183 211 593 183 216 593 minecraft:blue_concrete
fill 141 212 597 141 215 597 minecraft:blue_concrete
setblock 163 212 557 minecraft:shroomlight
setblock 181 212 599 minecraft:white_concrete
setblock 182 212 599 minecraft:shroomlight
setblock 183 212 569 minecraft:white_concrete
setblock 183 212 591 minecraft:white_concrete
fill 183 212 592 183 240 592 minecraft:blue_concrete
setblock 183 212 595 minecraft:white_concrete
fill 183 212 599 183 240 599 minecraft:blue_concrete
setblock 145 213 599 minecraft:white_concrete
fill 163 213 557 163 240 557 minecraft:blue_concrete
setblock 164 213 599 minecraft:shroomlight
setblock 167 213 599 minecraft:shroomlight
setblock 176 213 557 minecraft:white_concrete
fill 181 213 599 182 237 599 minecraft:blue_concrete
fill 183 213 569 183 232 569 minecraft:blue_concrete
fill 183 213 591 183 238 591 minecraft:blue_concrete
fill 183 213 595 183 228 595 minecraft:blue_concrete
fill 145 214 574 145 216 582 minecraft:waxed_cut_copper
fill 145 214 599 145 240 599 minecraft:blue_concrete
fill 146 214 571 146 216 574 minecraft:waxed_cut_copper
fill 146 214 582 146 216 585 minecraft:waxed_cut_copper
fill 147 214 569 147 216 571 minecraft:waxed_cut_copper
fill 147 214 585 147 216 587 minecraft:waxed_cut_copper
setblock 147 214 599 minecraft:shroomlight
fill 148 214 568 148 216 569 minecraft:waxed_cut_copper
fill 148 214 587 148 216 588 minecraft:waxed_cut_copper
fill 149 214 567 149 216 568 minecraft:waxed_cut_copper
fill 149 214 588 149 216 589 minecraft:waxed_cut_copper
fill 150 214 566 150 216 566 minecraft:waxed_cut_copper
fill 150 214 590 150 216 590 minecraft:waxed_cut_copper
fill 151 214 565 152 216 565 minecraft:waxed_cut_copper
fill 151 214 591 152 216 591 minecraft:waxed_cut_copper
fill 152 214 564 153 216 564 minecraft:waxed_cut_copper
fill 152 214 592 153 216 592 minecraft:waxed_cut_copper
fill 153 214 563 155 216 563 minecraft:waxed_cut_copper
fill 153 214 593 155 216 593 minecraft:waxed_cut_copper
fill 155 214 562 158 216 562 minecraft:waxed_cut_copper
fill 155 214 594 158 216 594 minecraft:waxed_cut_copper
fill 158 214 561 166 216 561 minecraft:waxed_cut_copper
fill 158 214 595 166 216 595 minecraft:waxed_cut_copper
setblock 162 214 557 minecraft:shroomlight
fill 164 214 599 164 229 599 minecraft:blue_concrete
fill 166 214 562 169 216 562 minecraft:waxed_cut_copper
fill 166 214 594 169 216 594 minecraft:waxed_cut_copper
fill 167 214 599 167 240 599 minecraft:blue_concrete
fill 169 214 563 171 216 563 minecraft:waxed_cut_copper
fill 169 214 593 171 216 593 minecraft:waxed_cut_copper
setblock 170 214 599 minecraft:shroomlight
fill 171 214 564 172 216 564 minecraft:waxed_cut_copper
fill 171 214 592 172 216 592 minecraft:waxed_cut_copper
fill 172 214 565 173 216 565 minecraft:waxed_cut_copper
fill 172 214 591 173 216 591 minecraft:waxed_cut_copper
fill 174 214 566 174 216 566 minecraft:waxed_cut_copper
fill 174 214 590 174 216 590 minecraft:waxed_cut_copper
fill 175 214 567 175 216 568 minecraft:waxed_cut_copper
fill 175 214 588 175 216 589 minecraft:waxed_cut_copper
fill 176 214 557 176 240 557 minecraft:blue_concrete
fill 176 214 568 176 216 569 minecraft:waxed_cut_copper
fill 176 214 587 176 216 588 minecraft:waxed_cut_copper
fill 177 214 569 177 216 571 minecraft:waxed_cut_copper
fill 177 214 585 177 216 587 minecraft:waxed_cut_copper
fill 178 214 571 178 216 574 minecraft:waxed_cut_copper
fill 178 214 582 178 216 585 minecraft:waxed_cut_copper
setblock 179 214 557 minecraft:white_concrete
fill 179 214 574 179 216 582 minecraft:waxed_cut_copper
fill 180 214 557 180 237 557 minecraft:blue_concrete
fill 147 215 599 147 240 599 minecraft:blue_concrete
fill 162 215 557 162 229 557 minecraft:blue_concrete
fill 170 215 599 170 236 599 minecraft:blue_concrete
setblock 179 215 557 minecraft:shroomlight
setblock 183 215 562 minecraft:shroomlight
fill 141 216 565 141 218 565 minecraft:gold_block
fill 141 216 581 141 218 581 minecraft:gold_block
fill 141 216 597 141 218 597 minecraft:gold_block
fill 145 216 557 145 218 557 minecraft:gold_block
fill 146 216 570 146 217 570 minecraft:shroomlight
setblock 146 216 599 minecraft:shroomlight
fill 147 216 568 147 217 568 minecraft:shroomlight
fill 148 216 567 148 217 567 minecraft:shroomlight
fill 149 216 566 149 217 566 minecraft:shroomlight
fill 150 216 565 150 217 565 minecraft:shroomlight
fill 151 216 564 151 217 564 minecraft:shroomlight
fill 155 216 599 155 218 599 minecraft:gold_block
fill 161 216 557 161 218 557 minecraft:gold_block
fill 171 216 599 171 218 599 minecraft:gold_block
fill 177 216 557 177 218 557 minecraft:gold_block
fill 179 216 557 179 240 557 minecraft:blue_concrete
fill 183 216 562 183 236 562 minecraft:blue_concrete
fill 183 216 567 183 218 567 minecraft:gold_block
setblock 183 216 577 minecraft:white_concrete
fill 183 216 583 183 218 583 minecraft:gold_block
setblock 141 217 596 minecraft:shroomlight
fill 144 217 577 144 217 579 minecraft:shroomlight
fill 145 217 572 145 217 576 minecraft:shroomlight
setblock 145 217 580 minecraft:shroomlight
setblock 146 217 571 minecraft:shroomlight
fill 146 217 585 146 217 586 minecraft:shroomlight
fill 146 217 599 146 240 599 minecraft:blue_concrete
setblock 147 217 569 minecraft:shroomlight
fill 147 217 587 147 217 588 minecraft:shroomlight
setblock 148 217 568 minecraft:shroomlight
fill 148 217 588 148 217 589 minecraft:shroomlight
setblock 149 217 590 minecraft:shroomlight
setblock 150 217 591 minecraft:shroomlight
fill 151 217 592 152 217 592 minecraft:shroomlight
fill 152 217 563 152 217 564 minecraft:shroomlight
fill 152 217 593 153 217 593 minecraft:shroomlight
setblock 153 217 563 minecraft:shroomlight
fill 154 217 562 155 217 562 minecraft:shroomlight
fill 154 217 594 155 217 594 minecraft:shroomlight
fill 156 217 561 160 217 561 minecraft:shroomlight
fill 156 217 595 160 217 595 minecraft:shroomlight
fill 161 217 560 163 217 560 minecraft:shroomlight
fill 161 217 596 163 217 596 minecraft:shroomlight
fill 164 217 561 168 217 561 minecraft:shroomlight
fill 164 217 595 168 217 595 minecraft:shroomlight
fill 169 217 562 170 217 562 minecraft:shroomlight
fill 169 217 594 170 217 594 minecraft:shroomlight
fill 171 217 563 172 217 563 minecraft:shroomlight
fill 171 217 593 172 217 593 minecraft:shroomlight
fill 172 217 564 173 217 564 minecraft:shroomlight
fill 172 217 592 173 217 592 minecraft:shroomlight
setblock 174 217 565 minecraft:shroomlight
setblock 174 217 591 minecraft:shroomlight
setblock 175 217 566 minecraft:shroomlight
setblock 175 217 590 minecraft:shroomlight
fill 176 217 567 176 217 568 minecraft:shroomlight
fill 176 217 588 176 217 589 minecraft:shroomlight
fill 177 217 568 177 217 569 minecraft:shroomlight
fill 177 217 587 177 217 588 minecraft:shroomlight
fill 178 217 570 178 217 571 minecraft:shroomlight
fill 178 217 585 178 217 586 minecraft:shroomlight
fill 179 217 572 179 217 576 minecraft:shroomlight
fill 179 217 580 179 217 584 minecraft:shroomlight
fill 180 217 577 180 217 579 minecraft:shroomlight
setblock 181 217 557 minecraft:shroomlight
fill 183 217 577 183 235 577 minecraft:blue_concrete
setblock 183 217 593 minecraft:shroomlight
fill 141 218 596 141 240 596 minecraft:blue_concrete
setblock 144 218 560 minecraft:light[level=14]
setblock 144 218 568 minecraft:light[level=14]
setblock 144 218 576 minecraft:light[level=14]
setblock 144 218 584 minecraft:light[level=14]
setblock 144 218 592 minecraft:light[level=14]
setblock 152 218 560 minecraft:light[level=14]
setblock 152 218 568 minecraft:light[level=14]
setblock 152 218 576 minecraft:light[level=14]
setblock 152 218 584 minecraft:light[level=14]
setblock 152 218 592 minecraft:light[level=14]
setblock 160 218 560 minecraft:light[level=14]
setblock 160 218 568 minecraft:light[level=14]
setblock 160 218 576 minecraft:light[level=14]
setblock 160 218 584 minecraft:light[level=14]
setblock 160 218 592 minecraft:light[level=14]
setblock 168 218 560 minecraft:light[level=14]
setblock 168 218 568 minecraft:light[level=14]
setblock 168 218 576 minecraft:light[level=14]
setblock 168 218 584 minecraft:light[level=14]
setblock 168 218 592 minecraft:light[level=14]
setblock 171 218 557 minecraft:shroomlight
setblock 176 218 560 minecraft:light[level=14]
setblock 176 218 568 minecraft:light[level=14]
setblock 176 218 576 minecraft:light[level=14]
setblock 176 218 584 minecraft:light[level=14]
setblock 176 218 592 minecraft:light[level=14]
fill 181 218 557 181 240 557 minecraft:blue_concrete
setblock 183 218 585 minecraft:shroomlight
fill 183 218 593 183 221 593 minecraft:blue_concrete
setblock 141 219 560 minecraft:shroomlight
fill 141 219 561 141 238 562 minecraft:blue_concrete
fill 141 219 565 141 224 565 minecraft:blue_concrete
fill 141 219 581 141 224 581 minecraft:blue_concrete
fill 141 219 597 141 224 597 minecraft:blue_concrete
fill 145 219 557 145 224 557 minecraft:blue_concrete
fill 155 219 599 155 224 599 minecraft:blue_concrete
fill 161 219 557 161 224 557 minecraft:blue_concrete
fill 171 219 557 171 227 557 minecraft:blue_concrete
fill 171 219 599 171 224 599 minecraft:blue_concrete
setblock 176 219 599 minecraft:shroomlight
fill 177 219 557 177 224 557 minecraft:blue_concrete
setblock 183 219 558 minecraft:shroomlight
fill 183 219 567 183 224 567 minecraft:blue_concrete
fill 183 219 583 183 224 583 minecraft:blue_concrete
fill 183 219 585 183 230 585 minecraft:blue_concrete
fill 141 220 560 141 240 560 minecraft:blue_concrete
setblock 141 220 590 minecraft:shroomlight
setblock 170 220 557 minecraft:shroomlight
fill 176 220 599 176 240 599 minecraft:blue_concrete
fill 183 220 558 183 241 558 minecraft:blue_concrete
fill 183 220 574 183 239 574 minecraft:blue_concrete
setblock 183 220 575 minecraft:white_concrete
fill 141 221 590 141 225 590 minecraft:blue_concrete
setblock 148 221 599 minecraft:white_concrete
setblock 158 221 599 minecraft:shroomlight
fill 170 221 557 170 240 557 minecraft:blue_concrete
fill 183 221 575 183 240 575 minecraft:blue_concrete
setblock 141 222 564 minecraft:shroomlight
setblock 143 222 599 minecraft:shroomlight
fill 148 222 599 148 240 599 minecraft:blue_concrete
fill 158 222 599 158 238 599 minecraft:blue_concrete
setblock 183 222 593 minecraft:shroomlight
fill 141 223 564 141 240 564 minecraft:blue_concrete
setblock 141 223 591 minecraft:shroomlight
setblock 143 223 557 minecraft:white_concrete
fill 143 223 599 143 224 599 minecraft:blue_concrete
fill 167 223 557 167 236 557 minecraft:blue_concrete
setblock 168 223 557 minecraft:shroomlight
setblock 168 223 599 minecraft:shroomlight
setblock 183 223 565 minecraft:white_concrete
fill 183 223 593 183 240 593 minecraft:blue_concrete
setblock 141 224 568 minecraft:shroomlight
fill 141 224 591 141 240 591 minecraft:blue_concrete
fill 143 224 557 143 241 557 minecraft:blue_concrete
fill 168 224 557 168 237 557 minecraft:blue_concrete
fill 168 224 599 168 236 599 minecraft:blue_concrete
fill 174 224 584 176 231 585 minecraft:light_blue_concrete
fill 175 224 583 176 231 583 minecraft:light_blue_concrete
fill 175 224 586 176 231 586 minecraft:light_blue_concrete
fill 183 224 565 183 238 565 minecraft:blue_concrete
fill 141 225 565 141 227 565 minecraft:gold_block
fill 141 225 568 141 240 568 minecraft:blue_concrete
fill 141 225 581 141 227 581 minecraft:gold_block
fill 141 225 592 141 240 592 minecraft:blue_concrete
setblock 141 225 593 minecraft:white_concrete
fill 141 225 597 141 227 597 minecraft:gold_block
setblock 143 225 599 minecraft:white_concrete
fill 145 225 557 145 227 557 minecraft:gold_block
setblock 146 225 557 minecraft:shroomlight
fill 155 225 599 155 227 599 minecraft:gold_block
fill 161 225 557 161 227 557 minecraft:gold_block
fill 171 225 599 171 227 599 minecraft:gold_block
fill 173 225 583 173 230 586 minecraft:light_blue_concrete
fill 174 225 582 174 230 583 minecraft:light_blue_concrete
fill 174 225 586 174 230 587 minecraft:light_blue_concrete
fill 175 225 582 176 230 582 minecraft:light_blue_concrete
fill 175 225 587 176 230 587 minecraft:light_blue_concrete
fill 177 225 557 177 227 557 minecraft:gold_block
fill 177 225 583 177 230 586 minecraft:light_blue_concrete
fill 178 225 584 178 230 585 minecraft:light_blue_concrete
fill 183 225 567 183 227 567 minecraft:gold_block
fill 183 225 583 183 227 583 minecraft:gold_block
setblock 183 225 594 minecraft:white_concrete
setblock 141 226 590 minecraft:shroomlight
fill 141 226 593 141 228 593 minecraft:blue_concrete
fill 143 226 599 143 240 599 minecraft:blue_concrete
setblock 144 226 560 minecraft:light[level=14]
setblock 144 226 568 minecraft:light[level=14]
setblock 144 226 576 minecraft:light[level=14]
setblock 144 226 584 minecraft:light[level=14]
setblock 144 226 592 minecraft:light[level=14]
fill 146 226 557 146 228 557 minecraft:blue_concrete
setblock 152 226 560 minecraft:light[level=14]
setblock 152 226 568 minecraft:light[level=14]
setblock 152 226 576 minecraft:light[level=14]
setblock 152 226 584 minecraft:light[level=14]
setblock 152 226 592 minecraft:light[level=14]
setblock 160 226 560 minecraft:light[level=14]
setblock 160 226 568 minecraft:light[level=14]
setblock 160 226 576 minecraft:light[level=14]
setblock 160 226 584 minecraft:light[level=14]
setblock 160 226 592 minecraft:light[level=14]
setblock 168 226 560 minecraft:light[level=14]
setblock 168 226 568 minecraft:light[level=14]
setblock 168 226 576 minecraft:light[level=14]
setblock 168 226 584 minecraft:light[level=14]
setblock 168 226 592 minecraft:light[level=14]
fill 172 226 583 172 229 586 minecraft:light_blue_concrete
fill 173 226 582 173 229 582 minecraft:light_blue_concrete
fill 173 226 587 173 229 587 minecraft:light_blue_concrete
fill 174 226 581 176 229 581 minecraft:light_blue_concrete
fill 175 226 588 176 229 588 minecraft:light_blue_concrete
setblock 176 226 560 minecraft:light[level=14]
setblock 176 226 568 minecraft:light[level=14]
setblock 176 226 576 minecraft:light[level=14]
setblock 176 226 592 minecraft:light[level=14]
fill 177 226 582 177 229 582 minecraft:light_blue_concrete
fill 177 226 587 177 229 587 minecraft:light_blue_concrete
fill 178 226 583 178 229 583 minecraft:light_blue_concrete
fill 178 226 586 178 229 586 minecraft:light_blue_concrete
setblock 183 226 563 minecraft:shroomlight
setblock 183 226 572 minecraft:shroomlight
fill 183 226 594 183 240 594 minecraft:blue_concrete
setblock 141 227 573 minecraft:white_concrete
fill 141 227 574 141 229 574 minecraft:blue_concrete
fill 141 227 590 141 240 590 minecraft:blue_concrete
setblock 152 227 557 minecraft:shroomlight
fill 174 227 588 174 228 588 minecraft:light_blue_concrete
fill 177 227 581 177 228 581 minecraft:light_blue_concrete
fill 178 227 582 178 228 582 minecraft:light_blue_concrete
fill 178 227 587 178 228 587 minecraft:light_blue_concrete
fill 179 227 584 179 228 585 minecraft:light_blue_concrete
fill 183 227 563 183 236 563 minecraft:blue_concrete
fill 183 227 572 183 240 572 minecraft:blue_concrete
setblock 183 227 596 minecraft:shroomlight
fill 183 227 597 183 240 597 minecraft:blue_concrete
setblock 183 227 598 minecraft:shroomlight
fill 141 228 565 141 237 565 minecraft:blue_concrete
fill 141 228 573 141 241 573 minecraft:blue_concrete
fill 141 228 581 141 240 581 minecraft:blue_concrete
fill 141 228 597 141 240 597 minecraft:blue_concrete
fill 145 228 557 145 240 557 minecraft:blue_concrete
fill 152 228 557 152 241 557 minecraft:blue_concrete
setblock 154 228 557 minecraft:white_concrete
fill 155 228 557 156 237 557 minecraft:blue_concrete
fill 155 228 599 155 231 599 minecraft:blue_concrete
fill 161 228 557 161 234 557 minecraft:blue_concrete
setblock 171 228 557 minecraft:shroomlight
fill 171 228 599 171 240 599 minecraft:blue_concrete
setblock 174 228 599 minecraft:white_concrete
setblock 175 228 557 minecraft:shroomlight
fill 177 228 557 177 236 557 minecraft:blue_concrete
setblock 183 228 567 minecraft:shroomlight
fill 183 228 583 183 240 583 minecraft:blue_concrete
fill 183 228 596 183 241 596 minecraft:blue_concrete
fill 183 228 598 183 240 598 minecraft:blue_concrete
setblock 141 229 559 minecraft:shroomlight
setblock 141 229 593 minecraft:shroomlight
setblock 146 229 557 minecraft:shroomlight
fill 154 229 557 154 232 557 minecraft:blue_concrete
fill 171 229 557 171 240 557 minecraft:blue_concrete
fill 174 229 599 174 240 599 minecraft:blue_concrete
fill 175 229 557 175 241 557 minecraft:blue_concrete
fill 183 229 567 183 240 567 minecraft:blue_concrete
setblock 183 229 595 minecraft:shroomlight
fill 141 230 559 141 240 559 minecraft:blue_concrete
setblock 141 230 574 minecraft:shroomlight
setblock 141 230 593 minecraft:blue_concrete
fill 146 230 557 146 240 557 minecraft:blue_concrete
setblock 162 230 557 minecraft:shroomlight
setblock 164 230 599 minecraft:shroomlight
fill 183 230 595 183 236 595 minecraft:blue_concrete
setblock 141 231 569 minecraft:shroomlight
fill 141 231 574 141 237 574 minecraft:blue_concrete
setblock 141 231 593 minecraft:white_concrete
setblock 152 231 599 minecraft:shroomlight
fill 162 231 557 162 237 557 minecraft:blue_concrete
fill 164 231 599 164 240 599 minecraft:blue_concrete
fill 175 231 587 179 232 590 minecraft:polished_blackstone
fill 177 231 586 179 232 586 minecraft:polished_blackstone
fill 180 231 588 181 231 588 minecraft:polished_blackstone
setblock 183 231 585 minecraft:white_concrete
fill 141 232 569 141 240 569 minecraft:blue_concrete
fill 141 232 593 141 236 593 minecraft:blue_concrete
fill 152 232 599 152 240 599 minecraft:blue_concrete
setblock 155 232 599 minecraft:shroomlight
fill 175 232 586 176 232 586 minecraft:polished_blackstone
setblock 183 232 566 minecraft:shroomlight
fill 183 232 585 183 240 585 minecraft:blue_concrete
setblock 154 233 557 minecraft:white_concrete
fill 155 233 599 155 240 599 minecraft:blue_concrete
setblock 172 233 599 minecraft:white_concrete
setblock 173 233 599 minecraft:shroomlight
setblock 183 233 559 minecraft:shroomlight
fill 183 233 566 183 240 566 minecraft:blue_concrete
setblock 183 233 569 minecraft:shroomlight
setblock 183 233 580 minecraft:shroomlight
setblock 141 234 575 minecraft:shroomlight
setblock 144 234 560 minecraft:light[level=14]
setblock 144 234 568 minecraft:light[level=14]
setblock 144 234 576 minecraft:light[level=14]
setblock 144 234 584 minecraft:light[level=14]
setblock 144 234 592 minecraft:light[level=14]
setblock 152 234 560 minecraft:light[level=14]
setblock 152 234 568 minecraft:light[level=14]
setblock 152 234 576 minecraft:light[level=14]
setblock 152 234 584 minecraft:light[level=14]
setblock 152 234 592 minecraft:light[level=14]
fill 154 234 557 154 241 557 minecraft:blue_concrete
setblock 160 234 560 minecraft:light[level=14]
setblock 160 234 568 minecraft:light[level=14]
setblock 160 234 576 minecraft:light[level=14]
setblock 160 234 584 minecraft:light[level=14]
setblock 160 234 592 minecraft:light[level=14]
setblock 163 234 599 minecraft:white_concrete
setblock 168 234 560 minecraft:light[level=14]
setblock 168 234 568 minecraft:light[level=14]
setblock 168 234 576 minecraft:light[level=14]
setblock 168 234 584 minecraft:light[level=14]
setblock 168 234 592 minecraft:light[level=14]
fill 172 234 599 173 235 599 minecraft:blue_concrete
setblock 176 234 560 minecraft:light[level=14]
setblock 176 234 568 minecraft:light[level=14]
setblock 176 234 576 minecraft:light[level=14]
setblock 176 234 584 minecraft:light[level=14]
setblock 176 234 592 minecraft:light[level=14]
fill 183 234 559 183 240 559 minecraft:blue_concrete
fill 183 234 569 183 240 569 minecraft:blue_concrete
setblock 183 234 578 minecraft:shroomlight
fill 183 234 580 183 237 580 minecraft:blue_concrete
fill 141 235 575 141 237 575 minecraft:blue_concrete
setblock 161 235 557 minecraft:shroomlight
fill 163 235 599 163 240 599 minecraft:blue_concrete
setblock 169 235 599 minecraft:white_concrete
setblock 172 235 557 minecraft:shroomlight
fill 173 235 557 174 236 557 minecraft:blue_concrete
setblock 183 235 570 minecraft:white_concrete
fill 183 235 578 183 240 578 minecraft:blue_concrete
setblock 183 235 587 minecraft:shroomlight
fill 161 236 557 161 240 557 minecraft:blue_concrete
fill 169 236 599 169 240 599 minecraft:blue_concrete
fill 172 236 557 172 240 557 minecraft:blue_concrete
fill 172 236 599 172 240 599 minecraft:blue_concrete
setblock 173 236 599 minecraft:shroomlight
setblock 183 236 570 minecraft:blue_concrete
setblock 183 236 577 minecraft:shroomlight
fill 183 236 587 183 240 587 minecraft:blue_concrete
setblock 141 237 572 minecraft:black_concrete
setblock 141 237 576 minecraft:black_concrete
setblock 141 237 580 minecraft:black_concrete
fill 141 237 586 141 238 587 minecraft:blue_concrete
setblock 141 237 588 minecraft:black_concrete
setblock 141 237 593 minecraft:black_concrete
setblock 150 237 599 minecraft:black_concrete
setblock 153 237 557 minecraft:black_concrete
setblock 157 237 557 minecraft:black_concrete
fill 158 237 557 158 238 557 minecraft:blue_concrete
setblock 159 237 599 minecraft:black_concrete
setblock 167 237 557 minecraft:black_concrete
setblock 168 237 599 minecraft:shroomlight
setblock 170 237 599 minecraft:black_concrete
fill 173 237 557 173 240 557 minecraft:blue_concrete
fill 173 237 599 173 240 599 minecraft:blue_concrete
setblock 174 237 557 minecraft:shroomlight
fill 177 237 557 177 238 557 minecraft:black_concrete
setblock 178 237 599 minecraft:shroomlight
fill 183 237 562 183 238 563 minecraft:black_concrete
setblock 183 237 568 minecraft:shroomlight
setblock 183 237 570 minecraft:black_concrete
fill 183 237 577 183 241 577 minecraft:blue_concrete
setblock 183 237 579 minecraft:black_concrete
setblock 183 237 582 minecraft:black_concrete
fill 183 237 584 183 239 584 minecraft:black_concrete
fill 183 237 595 183 238 595 minecraft:black_concrete
setblock 141 238 557 minecraft:black_concrete
setblock 141 238 558 minecraft:shroomlight
setblock 141 238 565 minecraft:black_concrete
setblock 141 238 567 minecraft:black_concrete
fill 141 238 572 141 240 572 minecraft:blue_concrete
fill 141 238 574 141 238 575 minecraft:black_concrete
fill 141 238 576 141 240 576 minecraft:blue_concrete
fill 141 238 578 141 238 579 minecraft:black_concrete
fill 141 238 580 141 240 580 minecraft:blue_concrete
setblock 141 238 582 minecraft:black_concrete
fill 141 238 588 141 241 588 minecraft:blue_concrete
setblock 141 238 593 minecraft:blue_concrete
fill 142 238 557 142 240 557 minecraft:blue_concrete
setblock 144 238 599 minecraft:black_concrete
fill 150 238 599 150 240 599 minecraft:blue_concrete
fill 153 238 557 153 240 557 minecraft:blue_concrete
setblock 153 238 599 minecraft:black_concrete
setblock 155 238 557 minecraft:black_concrete
fill 156 238 557 157 240 557 minecraft:blue_concrete
fill 159 238 557 160 238 557 minecraft:black_concrete
fill 159 238 599 159 240 599 minecraft:blue_concrete
fill 160 238 573 162 238 575 minecraft:redstone_block
fill 162 238 557 162 239 557 minecraft:black_concrete
fill 162 238 578 164 238 580 minecraft:redstone_block
fill 165 238 569 167 238 571 minecraft:redstone_block
fill 167 238 557 167 240 557 minecraft:blue_concrete
fill 168 238 557 168 239 557 minecraft:black_concrete
fill 168 238 578 170 238 580 minecraft:redstone_block
fill 168 238 599 168 240 599 minecraft:blue_concrete
fill 170 238 599 170 240 599 minecraft:blue_concrete
fill 174 238 557 174 240 557 minecraft:blue_concrete
fill 178 238 599 178 240 599 minecraft:blue_concrete
setblock 180 238 557 minecraft:black_concrete
fill 181 238 599 181 240 599 minecraft:blue_concrete
setblock 182 238 599 minecraft:black_concrete
setblock 183 238 568 minecraft:blue_concrete
fill 183 238 570 183 240 570 minecraft:blue_concrete
fill 183 238 579 183 240 579 minecraft:blue_concrete
setblock 183 238 580 minecraft:black_concrete
fill 183 238 582 183 240 582 minecraft:blue_concrete
setblock 183 238 586 minecraft:black_concrete
fill 141 239 557 141 240 558 minecraft:blue_concrete
fill 141 239 561 141 240 561 minecraft:blue_concrete
fill 141 239 562 141 239 563 minecraft:black_concrete
fill 141 239 565 141 240 565 minecraft:blue_concrete
fill 141 239 567 141 241 567 minecraft:blue_concrete
fill 141 239 574 141 240 575 minecraft:blue_concrete
fill 141 239 578 141 240 579 minecraft:blue_concrete
fill 141 239 582 141 240 582 minecraft:blue_concrete
fill 141 239 586 141 240 586 minecraft:blue_concrete
setblock 141 239 587 minecraft:white_concrete
setblock 141 239 593 minecraft:black_concrete
fill 144 239 599 144 240 599 minecraft:blue_concrete
setblock 151 239 557 minecraft:black_concrete
fill 153 239 599 153 240 599 minecraft:blue_concrete
setblock 154 239 599 minecraft:black_concrete
fill 155 239 557 155 240 557 minecraft:blue_concrete
fill 155 239 575 155 240 575 minecraft:black_concrete
fill 156 239 571 156 240 571 minecraft:black_concrete
fill 156 239 572 156 240 572 minecraft:blue_concrete
fill 156 239 573 156 240 574 minecraft:black_concrete
fill 156 239 575 156 240 575 minecraft:blue_concrete
fill 156 239 576 156 240 577 minecraft:black_concrete
fill 156 239 578 156 240 578 minecraft:blue_concrete
fill 156 239 579 157 240 579 minecraft:black_concrete
fill 157 239 569 157 240 570 minecraft:black_concrete
fill 157 239 571 157 240 571 minecraft:blue_concrete
fill 157 239 572 157 240 573 minecraft:black_concrete
fill 157 239 574 157 240 574 minecraft:blue_concrete
fill 157 239 575 157 240 576 minecraft:black_concrete
fill 157 239 577 157 240 577 minecraft:blue_concrete
fill 157 239 578 158 240 578 minecraft:black_concrete
fill 157 239 580 157 240 580 minecraft:blue_concrete
fill 157 239 581 158 240 581 minecraft:black_concrete
fill 157 239 599 158 239 599 minecraft:black_concrete
setblock 158 239 557 minecraft:black_concrete
fill 158 239 568 158 240 569 minecraft:black_concrete
fill 158 239 570 158 240 570 minecraft:blue_concrete
fill 158 239 571 158 240 572 minecraft:black_concrete
fill 158 239 573 158 240 573 minecraft:blue_concrete
fill 158 239 574 158 240 575 minecraft:black_concrete
fill 158 239 576 158 240 576 minecraft:blue_concrete
fill 158 239 577 159 240 577 minecraft:black_concrete
fill 158 239 579 158 240 579 minecraft:blue_concrete
fill 158 239 580 159 240 580 minecraft:black_concrete
fill 158 239 582 158 240 582 minecraft:blue_concrete
fill 159 239 557 160 240 557 minecraft:blue_concrete
fill 159 239 567 159 240 568 minecraft:black_concrete
fill 159 239 569 159 240 569 minecraft:blue_concrete
fill 159 239 570 159 240 571 minecraft:black_concrete
setblock 159 239 572 minecraft:blue_concrete
fill 159 239 573 159 239 574 minecraft:black_concrete
setblock 159 239 575 minecraft:blue_concrete
fill 159 239 576 160 239 576 minecraft:black_concrete
fill 159 239 578 159 240 578 minecraft:blue_concrete
fill 159 239 579 160 240 579 minecraft:black_concrete
fill 159 239 581 159 240 581 minecraft:blue_concrete
fill 159 239 582 159 240 583 minecraft:black_concrete
fill 160 239 566 160 240 567 minecraft:black_concrete
fill 160 239 568 160 240 568 minecraft:blue_concrete
fill 160 239 569 160 240 570 minecraft:black_concrete
fill 160 239 571 160 240 571 minecraft:blue_concrete
fill 160 239 572 161 239 572 minecraft:black_concrete
fill 160 239 577 160 240 577 minecraft:blue_concrete
fill 160 239 578 161 239 578 minecraft:black_concrete
fill 160 239 580 160 240 580 minecraft:blue_concrete
fill 160 239 581 160 240 582 minecraft:black_concrete
fill 160 239 583 160 240 583 minecraft:blue_concrete
fill 160 239 584 161 240 584 minecraft:black_concrete
fill 161 239 566 161 240 566 minecraft:black_concrete
fill 161 239 567 161 240 567 minecraft:blue_concrete
fill 161 239 568 161 240 569 minecraft:black_concrete
fill 161 239 570 161 240 570 minecraft:blue_concrete
fill 161 239 571 162 240 571 minecraft:black_concrete
setblock 161 239 576 minecraft:blue_concrete
fill 161 239 577 162 239 577 minecraft:black_concrete
setblock 161 239 579 minecraft:blue_concrete
fill 161 239 580 161 239 581 minecraft:black_concrete
fill 161 239 582 161 240 582 minecraft:blue_concrete
fill 161 239 583 162 240 583 minecraft:black_concrete
fill 162 239 565 162 240 565 minecraft:black_concrete
fill 162 239 566 162 240 566 minecraft:blue_concrete
fill 162 239 567 162 240 568 minecraft:black_concrete
fill 162 239 569 162 240 569 minecraft:blue_concrete
fill 162 239 570 163 240 570 minecraft:black_concrete
setblock 162 239 572 minecraft:blue_concrete
fill 162 239 576 163 239 576 minecraft:black_concrete
setblock 162 239 581 minecraft:blue_concrete
fill 162 239 582 163 240 582 minecraft:black_concrete
fill 162 239 584 162 240 584 minecraft:blue_concrete
fill 162 239 585 163 240 585 minecraft:black_concrete
fill 163 239 565 163 240 565 minecraft:blue_concrete
fill 163 239 566 163 240 567 minecraft:black_concrete
fill 163 239 568 163 240 568 minecraft:blue_concrete
fill 163 239 569 164 239 569 minecraft:black_concrete
fill 163 239 571 163 240 571 minecraft:blue_concrete
fill 163 239 572 163 239 573 minecraft:black_concrete
setblock 163 239 574 minecraft:blue_concrete
fill 163 239 575 164 239 575 minecraft:black_concrete
setblock 163 239 577 minecraft:blue_concrete
fill 163 239 581 164 239 581 minecraft:black_concrete
fill 163 239 583 163 240 583 minecraft:blue_concrete
fill 163 239 584 164 240 584 minecraft:black_concrete
fill 164 239 565 164 240 566 minecraft:black_concrete
fill 164 239 567 164 240 567 minecraft:blue_concrete
fill 164 239 568 165 239 568 minecraft:black_concrete
setblock 164 239 570 minecraft:blue_concrete
fill 164 239 571 164 239 572 minecraft:black_concrete
setblock 164 239 573 minecraft:blue_concrete
setblock 164 239 574 minecraft:black_concrete
setblock 164 239 576 minecraft:blue_concrete
fill 164 239 577 165 239 577 minecraft:black_concrete
fill 164 239 582 164 240 582 minecraft:blue_concrete
fill 164 239 583 165 240 583 minecraft:black_concrete
fill 164 239 585 164 240 585 minecraft:blue_concrete
fill 165 239 565 165 240 565 minecraft:black_concrete
fill 165 239 566 165 240 566 minecraft:blue_concrete
fill 165 239 567 166 240 567 minecraft:black_concrete
setblock 165 239 572 minecraft:blue_concrete
fill 165 239 573 166 239 573 minecraft:black_concrete
setblock 165 239 578 minecraft:blue_concrete
fill 165 239 579 165 239 580 minecraft:black_concrete
setblock 165 239 581 minecraft:blue_concrete
fill 165 239 582 166 240 582 minecraft:black_concrete
fill 165 239 584 165 240 584 minecraft:blue_concrete
fill 165 239 585 166 240 585 minecraft:black_concrete
fill 166 239 564 166 240 564 minecraft:black_concrete
fill 166 239 565 166 240 565 minecraft:blue_concrete
fill 166 239 566 167 240 566 minecraft:black_concrete
setblock 166 239 568 minecraft:blue_concrete
fill 166 239 572 167 239 572 minecraft:black_concrete
setblock 166 239 577 minecraft:blue_concrete
fill 166 239 578 166 240 579 minecraft:black_concrete
fill 166 239 580 166 240 580 minecraft:blue_concrete
fill 166 239 581 167 239 581 minecraft:black_concrete
fill 166 239 583 166 240 583 minecraft:blue_concrete
fill 166 239 584 167 240 584 minecraft:black_concrete
fill 166 239 586 166 240 586 minecraft:blue_concrete
fill 167 239 565 168 240 565 minecraft:black_concrete
fill 167 239 567 167 240 567 minecraft:blue_concrete
fill 167 239 568 168 239 568 minecraft:black_concrete
setblock 167 239 573 minecraft:blue_concrete
fill 167 239 577 167 239 578 minecraft:black_concrete
setblock 167 239 579 minecraft:blue_concrete
setblock 167 239 580 minecraft:black_concrete
fill 167 239 582 167 240 582 minecraft:blue_concrete
fill 167 239 583 168 240 583 minecraft:black_concrete
fill 167 239 585 167 240 585 minecraft:blue_concrete
fill 168 239 566 168 240 566 minecraft:blue_concrete
fill 168 239 567 169 240 567 minecraft:black_concrete
setblock 168 239 569 minecraft:blue_concrete
fill 168 239 570 168 239 571 minecraft:black_concrete
setblock 168 239 572 minecraft:blue_concrete
fill 168 239 573 168 239 574 minecraft:black_concrete
setblock 168 239 575 minecraft:blue_concrete
fill 168 239 576 168 239 577 minecraft:black_concrete
setblock 168 239 581 minecraft:blue_concrete
fill 168 239 582 169 240 582 minecraft:black_concrete
fill 168 239 584 168 240 584 minecraft:blue_concrete
fill 168 239 585 169 240 585 minecraft:black_concrete
fill 169 239 565 169 240 565 minecraft:blue_concrete
fill 169 239 566 170 240 566 minecraft:black_concrete
fill 169 239 568 169 240 568 minecraft:blue_concrete
fill 169 239 569 169 240 570 minecraft:black_concrete
fill 169 239 571 169 240 571 minecraft:blue_concrete
fill 169 239 572 169 240 573 minecraft:black_concrete
fill 169 239 574 169 240 574 minecraft:blue_concrete
fill 169 239 575 169 240 576 minecraft:black_concrete
setblock 169 239 577 minecraft:blue_concrete
fill 169 239 581 170 239 581 minecraft:black_concrete
fill 169 239 583 169 240 583 minecraft:blue_concrete
fill 169 239 584 170 240 584 minecraft:black_concrete
fill 170 239 565 170 240 565 minecraft:black_concrete
fill 170 239 567 170 240 567 minecraft:blue_concrete
fill 170 239 568 170 240 569 minecraft:black_concrete
fill 170 239 570 170 240 570 minecraft:blue_concrete
fill 170 239 571 170 240 572 minecraft:black_concrete
fill 170 239 573 170 240 573 minecraft:blue_concrete
fill 170 239 574 170 240 575 minecraft:black_concrete
fill 170 239 576 170 240 576 minecraft:blue_concrete
fill 170 239 577 171 239 577 minecraft:black_concrete
fill 170 239 582 170 240 582 minecraft:blue_concrete
fill 170 239 583 171 240 583 minecraft:black_concrete
fill 170 239 585 170 240 585 minecraft:blue_concrete
fill 171 239 566 171 240 566 minecraft:blue_concrete
fill 171 239 567 171 240 568 minecraft:black_concrete
fill 171 239 569 171 240 569 minecraft:blue_concrete
fill 171 239 570 171 240 571 minecraft:black_concrete
fill 171 239 572 171 240 572 minecraft:blue_concrete
fill 171 239 573 171 240 574 minecraft:black_concrete
fill 171 239 575 171 240 575 minecraft:blue_concrete
fill 171 239 576 172 240 576 minecraft:black_concrete
setblock 171 239 578 minecraft:blue_concrete
fill 171 239 579 171 239 580 minecraft:black_concrete
setblock 171 239 581 minecraft:blue_concrete
fill 171 239 582 172 240 582 minecraft:black_concrete
fill 171 239 584 171 240 584 minecraft:blue_concrete
fill 172 239 566 172 240 567 minecraft:black_concrete
fill 172 239 568 172 240 568 minecraft:blue_concrete
fill 172 239 569 172 240 570 minecraft:black_concrete
fill 172 239 571 172 240 571 minecraft:blue_concrete
fill 172 239 572 172 240 573 minecraft:black_concrete
fill 172 239 574 172 240 574 minecraft:blue_concrete
fill 172 239 575 173 240 575 minecraft:black_concrete
fill 172 239 577 172 240 577 minecraft:blue_concrete
fill 172 239 578 172 240 579 minecraft:black_concrete
fill 172 239 580 172 240 580 minecraft:blue_concrete
fill 172 239 581 173 240 581 minecraft:black_concrete
fill 172 239 583 172 240 583 minecraft:blue_concrete
fill 172 239 584 172 240 584 minecraft:black_concrete
fill 173 239 567 173 240 567 minecraft:blue_concrete
fill 173 239 568 173 240 569 minecraft:black_concrete
fill 173 239 570 173 240 570 minecraft:blue_concrete
fill 173 239 571 173 240 572 minecraft:black_concrete
fill 173 239 573 173 240 573 minecraft:blue_concrete
fill 173 239 574 174 240 574 minecraft:black_concrete
fill 173 239 576 173 240 576 minecraft:blue_concrete
fill 173 239 577 173 240 578 minecraft:black_concrete
fill 173 239 579 173 240 579 minecraft:blue_concrete
fill 173 239 580 174 240 580 minecraft:black_concrete
fill 173 239 582 173 240 582 minecraft:blue_concrete
fill 173 239 583 173 240 583 minecraft:black_concrete
fill 174 239 568 174 240 568 minecraft:black_concrete
fill 174 239 569 174 240 569 minecraft:blue_concrete
fill 174 239 570 174 240 571 minecraft:black_concrete
fill 174 239 572 174 240 572 minecraft:blue_concrete
fill 174 239 573 175 240 573 minecraft:black_concrete
fill 174 239 575 174 240 575 minecraft:blue_concrete
fill 174 239 576 174 240 577 minecraft:black_concrete
fill 174 239 578 174 240 578 minecraft:blue_concrete
fill 174 239 579 175 240 579 minecraft:black_concrete
fill 174 239 581 174 240 581 minecraft:blue_concrete
fill 174 239 582 174 240 582 minecraft:black_concrete
fill 175 239 569 175 240 570 minecraft:black_concrete
fill 175 239 571 175 240 571 minecraft:blue_concrete
fill 175 239 572 176 240 572 minecraft:black_concrete
fill 175 239 574 175 240 574 minecraft:blue_concrete
fill 175 239 575 175 240 576 minecraft:black_concrete
fill 175 239 577 175 240 577 minecraft:blue_concrete
fill 175 239 578 176 240 578 minecraft:black_concrete
fill 175 239 580 175 240 580 minecraft:blue_concrete
fill 175 239 581 175 240 581 minecraft:black_concrete
fill 176 239 571 176 240 571 minecraft:black_concrete
fill 176 239 573 176 240 573 minecraft:blue_concrete
fill 176 239 574 176 240 575 minecraft:black_concrete
fill 176 239 576 176 240 576 minecraft:blue_concrete
fill 176 239 577 176 240 577 minecraft:black_concrete
fill 176 239 579 176 240 579 minecraft:blue_concrete
fill 177 239 557 177 240 557 minecraft:blue_concrete
fill 177 239 575 177 240 575 minecraft:blue_concrete
setblock 177 239 599 minecraft:black_concrete
fill 180 239 557 180 240 557 minecraft:blue_concrete
fill 182 239 599 182 240 599 minecraft:blue_concrete
fill 183 239 562 183 240 562 minecraft:blue_concrete
setblock 183 239 563 minecraft:shroomlight
setblock 183 239 565 minecraft:black_concrete
setblock 183 239 568 minecraft:black_concrete
fill 183 239 580 183 240 580 minecraft:blue_concrete
setblock 183 239 581 minecraft:white_concrete
setblock 183 239 586 minecraft:blue_concrete
setblock 183 239 591 minecraft:black_concrete
fill 183 239 595 183 240 595 minecraft:blue_concrete
fill 141 240 562 141 240 563 minecraft:blue_concrete
setblock 141 240 587 minecraft:blue_concrete
setblock 141 240 593 minecraft:shroomlight
fill 142 240 558 153 240 598 minecraft:black_concrete
setblock 149 240 557 minecraft:shroomlight
setblock 151 240 557 minecraft:blue_concrete
fill 154 240 558 154 240 574 minecraft:black_concrete
setblock 154 240 575 minecraft:waxed_copper_block
fill 154 240 576 154 240 598 minecraft:black_concrete
setblock 154 240 599 minecraft:blue_concrete
fill 155 240 558 155 240 570 minecraft:black_concrete
fill 155 240 571 155 240 574 minecraft:waxed_copper_block
fill 155 240 576 155 240 579 minecraft:waxed_copper_block
fill 155 240 580 155 240 598 minecraft:black_concrete
fill 156 240 558 156 240 568 minecraft:black_concrete
fill 156 240 569 156 240 570 minecraft:waxed_copper_block
fill 156 240 580 156 240 581 minecraft:waxed_copper_block
fill 156 240 582 156 240 598 minecraft:black_concrete
fill 157 240 558 157 240 567 minecraft:black_concrete
setblock 157 240 568 minecraft:waxed_copper_block
setblock 157 240 582 minecraft:waxed_copper_block
fill 157 240 583 157 240 598 minecraft:black_concrete
fill 157 240 599 158 240 599 minecraft:blue_concrete
setblock 158 240 557 minecraft:blue_concrete
fill 158 240 558 158 240 566 minecraft:black_concrete
setblock 158 240 567 minecraft:waxed_copper_block
setblock 158 240 583 minecraft:waxed_copper_block
fill 158 240 584 158 240 598 minecraft:black_concrete
fill 159 240 558 159 240 565 minecraft:black_concrete
setblock 159 240 566 minecraft:waxed_copper_block
fill 159 240 572 159 240 576 minecraft:shroomlight
setblock 159 240 584 minecraft:waxed_copper_block
fill 159 240 585 159 240 598 minecraft:black_concrete
fill 160 240 558 161 240 564 minecraft:black_concrete
fill 160 240 565 161 240 565 minecraft:waxed_copper_block
fill 160 240 572 168 240 572 minecraft:shroomlight
fill 160 240 573 162 240 575 minecraft:black_concrete
fill 160 240 576 164 240 576 minecraft:shroomlight
setblock 160 240 578 minecraft:black_concrete
fill 160 240 585 161 240 585 minecraft:waxed_copper_block
fill 160 240 586 161 240 598 minecraft:black_concrete
fill 161 240 577 161 240 581 minecraft:shroomlight
setblock 162 240 557 minecraft:blue_concrete
fill 162 240 558 165 240 563 minecraft:black_concrete
fill 162 240 564 165 240 564 minecraft:waxed_copper_block
fill 162 240 577 171 240 577 minecraft:shroomlight
fill 162 240 578 164 240 580 minecraft:black_concrete
fill 162 240 581 165 240 581 minecraft:shroomlight
fill 162 240 586 165 240 586 minecraft:waxed_copper_block
fill 162 240 587 165 240 598 minecraft:black_concrete
setblock 163 240 569 minecraft:black_concrete
fill 163 240 573 164 240 575 minecraft:shroomlight
fill 164 240 568 164 240 571 minecraft:shroomlight
fill 165 240 568 168 240 568 minecraft:shroomlight
fill 165 240 569 167 240 571 minecraft:black_concrete
fill 165 240 573 168 240 573 minecraft:shroomlight
fill 165 240 578 165 240 580 minecraft:shroomlight
fill 166 240 558 182 240 562 minecraft:black_concrete
setblock 166 240 563 minecraft:waxed_copper_block
setblock 166 240 581 minecraft:black_concrete
setblock 166 240 587 minecraft:waxed_copper_block
fill 166 240 588 182 240 598 minecraft:black_concrete
fill 167 240 563 182 240 563 minecraft:black_concrete
fill 167 240 564 170 240 564 minecraft:waxed_copper_block
fill 167 240 578 167 240 581 minecraft:shroomlight
fill 167 240 586 170 240 586 minecraft:waxed_copper_block
fill 167 240 587 182 240 587 minecraft:black_concrete
setblock 168 240 557 minecraft:blue_concrete
fill 168 240 569 168 240 571 minecraft:shroomlight
fill 168 240 574 168 240 576 minecraft:shroomlight
fill 168 240 578 170 240 580 minecraft:black_concrete
fill 168 240 581 171 240 581 minecraft:shroomlight
fill 171 240 564 182 240 564 minecraft:black_concrete
fill 171 240 565 172 240 565 minecraft:waxed_copper_block
fill 171 240 578 171 240 580 minecraft:shroomlight
fill 171 240 585 172 240 585 minecraft:waxed_copper_block
fill 171 240 586 182 240 586 minecraft:black_concrete
fill 173 240 565 182 240 565 minecraft:black_concrete
setblock 173 240 566 minecraft:waxed_copper_block
setblock 173 240 584 minecraft:waxed_copper_block
fill 173 240 585 182 240 585 minecraft:black_concrete
fill 174 240 566 182 240 566 minecraft:black_concrete
setblock 174 240 567 minecraft:waxed_copper_block
setblock 174 240 583 minecraft:waxed_copper_block
fill 174 240 584 182 240 584 minecraft:black_concrete
fill 175 240 567 182 240 567 minecraft:black_concrete
setblock 175 240 568 minecraft:waxed_copper_block
setblock 175 240 582 minecraft:waxed_copper_block
fill 175 240 583 182 240 583 minecraft:black_concrete
fill 176 240 568 182 240 568 minecraft:black_concrete
fill 176 240 569 176 240 570 minecraft:waxed_copper_block
fill 176 240 580 176 240 581 minecraft:waxed_copper_block
fill 176 240 582 182 240 582 minecraft:black_concrete
fill 177 240 569 182 240 570 minecraft:black_concrete
fill 177 240 571 177 240 574 minecraft:waxed_copper_block
fill 177 240 576 177 240 579 minecraft:waxed_copper_block
fill 177 240 580 182 240 581 minecraft:black_concrete
fill 177 240 599 177 241 599 minecraft:blue_concrete
fill 178 240 571 182 240 574 minecraft:black_concrete
setblock 178 240 575 minecraft:waxed_copper_block
fill 178 240 576 182 240 579 minecraft:black_concrete
fill 179 240 575 182 240 575 minecraft:black_concrete
setblock 183 240 563 minecraft:blue_concrete
setblock 183 240 565 minecraft:shroomlight
setblock 183 240 568 minecraft:blue_concrete
setblock 183 240 574 minecraft:shroomlight
setblock 183 240 581 minecraft:shroomlight
setblock 183 240 584 minecraft:blue_concrete
setblock 183 240 586 minecraft:shroomlight
setblock 183 240 591 minecraft:blue_concrete
fill 141 241 557 141 241 566 minecraft:black_concrete
fill 141 241 568 141 255 572 minecraft:black_concrete
fill 141 241 574 141 269 574 minecraft:black_concrete
setblock 141 241 575 minecraft:blue_concrete
fill 141 241 576 141 243 583 minecraft:black_concrete
setblock 141 241 584 minecraft:blue_concrete
fill 141 241 586 141 243 587 minecraft:black_concrete
fill 141 241 589 141 262 592 minecraft:black_concrete
setblock 141 241 593 minecraft:blue_concrete
fill 141 241 594 141 241 599 minecraft:black_concrete
fill 142 241 557 142 263 557 minecraft:black_concrete
fill 142 241 599 159 241 599 minecraft:black_concrete
fill 145 241 557 151 241 557 minecraft:black_concrete
fill 153 241 557 153 278 557 minecraft:black_concrete
fill 155 241 557 160 241 557 minecraft:black_concrete
setblock 155 241 575 minecraft:waxed_copper_block
setblock 161 241 557 minecraft:shroomlight
fill 161 241 599 161 307 599 minecraft:black_concrete
fill 162 241 557 174 241 557 minecraft:black_concrete
fill 163 241 599 165 245 599 minecraft:black_concrete
setblock 166 241 564 minecraft:waxed_copper_block
setblock 166 241 586 minecraft:waxed_copper_block
fill 167 241 599 167 302 599 minecraft:black_concrete
setblock 168 241 599 minecraft:shroomlight
fill 169 241 599 176 241 599 minecraft:black_concrete
setblock 176 241 557 minecraft:shroomlight
fill 177 241 557 183 241 557 minecraft:black_concrete
setblock 177 241 575 minecraft:waxed_copper_block
fill 178 241 599 183 241 599 minecraft:black_concrete
fill 183 241 559 183 241 560 minecraft:black_concrete
fill 183 241 562 183 241 572 minecraft:black_concrete
fill 183 241 574 183 276 575 minecraft:black_concrete
fill 183 241 578 183 241 595 minecraft:black_concrete
fill 183 241 597 183 266 598 minecraft:black_concrete
fill 141 242 557 141 242 559 minecraft:black_concrete
setblock 141 242 560 minecraft:blue_concrete
fill 141 242 561 141 242 567 minecraft:black_concrete
fill 141 242 573 141 307 573 minecraft:black_concrete
fill 141 242 575 141 257 575 minecraft:black_concrete
fill 141 242 584 141 252 585 minecraft:black_concrete
fill 141 242 588 141 273 588 minecraft:black_concrete
fill 141 242 593 141 243 598 minecraft:black_concrete
setblock 141 242 599 minecraft:blue_concrete
fill 142 242 599 155 242 599 minecraft:black_concrete
fill 143 242 557 144 256 557 minecraft:black_concrete
setblock 144 242 560 minecraft:light[level=14]
setblock 144 242 568 minecraft:light[level=14]
setblock 144 242 576 minecraft:light[level=14]
setblock 144 242 584 minecraft:light[level=14]
setblock 144 242 592 minecraft:light[level=14]
setblock 145 242 557 minecraft:blue_concrete
fill 146 242 557 148 269 557 minecraft:black_concrete
setblock 149 242 557 minecraft:blue_concrete
fill 150 242 557 152 242 557 minecraft:black_concrete
setblock 152 242 560 minecraft:light[level=14]
setblock 152 242 568 minecraft:light[level=14]
setblock 152 242 576 minecraft:light[level=14]
setblock 152 242 584 minecraft:light[level=14]
setblock 152 242 592 minecraft:light[level=14]
fill 154 242 557 157 242 557 minecraft:black_concrete
fill 156 242 599 157 242 599 minecraft:blue_concrete
setblock 158 242 557 minecraft:blue_concrete
fill 158 242 599 160 242 599 minecraft:black_concrete
fill 159 242 557 164 242 557 minecraft:black_concrete
setblock 160 242 560 minecraft:light[level=14]
setblock 160 242 568 minecraft:light[level=14]
setblock 160 242 576 minecraft:light[level=14]
setblock 160 242 584 minecraft:light[level=14]
setblock 160 242 592 minecraft:light[level=14]
fill 162 242 599 162 307 599 minecraft:black_concrete
setblock 165 242 557 minecraft:blue_concrete
fill 166 242 557 169 242 557 minecraft:black_concrete
fill 166 242 599 166 277 599 minecraft:black_concrete
setblock 168 242 560 minecraft:light[level=14]
setblock 168 242 568 minecraft:light[level=14]
setblock 168 242 576 minecraft:light[level=14]
setblock 168 242 584 minecraft:light[level=14]
setblock 168 242 592 minecraft:light[level=14]
fill 168 242 599 170 250 599 minecraft:black_concrete
fill 170 242 557 171 242 557 minecraft:blue_concrete
setblock 171 242 599 minecraft:blue_concrete
setblock 172 242 557 minecraft:shroomlight
fill 172 242 599 174 242 599 minecraft:black_concrete
fill 173 242 557 175 257 557 minecraft:black_concrete
setblock 175 242 599 minecraft:blue_concrete
setblock 176 242 557 minecraft:blue_concrete
setblock 176 242 560 minecraft:light[level=14]
setblock 176 242 568 minecraft:light[level=14]
setblock 176 242 576 minecraft:light[level=14]
setblock 176 242 584 minecraft:light[level=14]
setblock 176 242 592 minecraft:light[level=14]
fill 176 242 599 180 250 599 minecraft:black_concrete
fill 177 242 557 178 243 557 minecraft:black_concrete
setblock 179 242 557 minecraft:blue_concrete
fill 180 242 557 181 284 557 minecraft:black_concrete
fill 181 242 599 181 243 599 minecraft:blue_concrete
setblock 182 242 557 minecraft:white_concrete
fill 182 242 599 183 254 599 minecraft:black_concrete
fill 183 242 557 183 245 559 minecraft:black_concrete
setblock 183 242 560 minecraft:blue_concrete
fill 183 242 561 183 242 564 minecraft:black_concrete
setblock 183 242 565 minecraft:blue_concrete
fill 183 242 566 183 279 566 minecraft:black_concrete
setblock 183 242 567 minecraft:blue_concrete
fill 183 242 568 183 252 568 minecraft:black_concrete
setblock 183 242 569 minecraft:shroomlight
setblock 183 242 570 minecraft:blue_concrete
fill 183 242 571 183 249 573 minecraft:black_concrete
fill 183 242 576 183 242 579 minecraft:black_concrete
setblock 183 242 580 minecraft:blue_concrete
fill 183 242 581 183 243 586 minecraft:black_concrete
setblock 183 242 587 minecraft:blue_concrete
fill 183 242 588 183 242 596 minecraft:black_concrete
fill 141 243 557 141 243 558 minecraft:blue_concrete
fill 141 243 559 141 256 562 minecraft:black_concrete
setblock 141 243 563 minecraft:blue_concrete
fill 141 243 564 141 243 567 minecraft:black_concrete
fill 141 243 599 147 261 599 minecraft:black_concrete
setblock 145 243 557 minecraft:black_concrete
setblock 148 243 599 minecraft:blue_concrete
fill 149 243 557 151 267 557 minecraft:black_concrete
setblock 149 243 599 minecraft:white_concrete
setblock 150 243 599 minecraft:blue_concrete
fill 151 243 599 158 243 599 minecraft:black_concrete
setblock 152 243 557 minecraft:blue_concrete
fill 154 243 557 156 243 557 minecraft:blue_concrete
fill 157 243 557 161 243 557 minecraft:black_concrete
setblock 159 243 599 minecraft:white_concrete
fill 160 243 599 160 267 599 minecraft:black_concrete
setblock 162 243 557 minecraft:shroomlight
fill 163 243 557 165 294 557 minecraft:black_concrete
setblock 166 243 557 minecraft:shroomlight
fill 167 243 557 172 252 557 minecraft:black_concrete
fill 171 243 599 173 243 599 minecraft:black_concrete
setblock 174 243 599 minecraft:blue_concrete
fill 175 243 599 175 307 599 minecraft:black_concrete
fill 176 243 557 176 307 557 minecraft:black_concrete
fill 179 243 557 179 307 557 minecraft:black_concrete
setblock 182 243 557 minecraft:blue_concrete
fill 183 243 560 183 245 562 minecraft:black_concrete
setblock 183 243 563 minecraft:blue_concrete
fill 183 243 564 183 261 565 minecraft:black_concrete
setblock 183 243 567 minecraft:black_concrete
fill 183 243 569 183 249 570 minecraft:black_concrete
setblock 183 243 576 minecraft:shroomlight
fill 183 243 577 183 245 578 minecraft:black_concrete
setblock 183 243 579 minecraft:blue_concrete
fill 183 243 580 183 255 580 minecraft:black_concrete
fill 183 243 587 183 259 589 minecraft:black_concrete
setblock 183 243 590 minecraft:white_concrete
fill 183 243 591 183 292 594 minecraft:black_concrete
setblock 183 243 595 minecraft:blue_concrete
fill 183 243 596 183 252 596 minecraft:black_concrete
fill 141 244 557 141 307 558 minecraft:black_concrete
fill 141 244 563 141 253 564 minecraft:black_concrete
fill 141 244 565 141 245 565 minecraft:gold_block
fill 141 244 566 141 250 567 minecraft:black_concrete
fill 141 244 576 141 250 580 minecraft:black_concrete
fill 141 244 581 141 245 581 minecraft:gold_block
schedule function dropper:buildpart/135_2 1t
