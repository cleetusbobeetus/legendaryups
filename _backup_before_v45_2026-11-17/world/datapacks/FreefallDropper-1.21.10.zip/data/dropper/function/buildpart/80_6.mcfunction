fill 411 207 325 411 210 325 minecraft:gray_concrete
setblock 412 207 323 minecraft:polished_deepslate
fill 412 207 324 412 210 324 minecraft:gray_concrete
setblock 412 207 363 minecraft:polished_deepslate
fill 413 207 323 413 210 323 minecraft:gray_concrete
setblock 413 207 362 minecraft:polished_deepslate
fill 413 207 363 413 208 363 minecraft:gray_concrete
setblock 414 207 326 minecraft:polished_deepslate
fill 414 207 327 414 210 327 minecraft:gray_concrete
fill 414 207 362 414 210 362 minecraft:gray_concrete
setblock 415 207 324 minecraft:gray_concrete
setblock 415 207 325 minecraft:polished_deepslate
fill 415 207 326 415 210 326 minecraft:gray_concrete
setblock 415 207 329 minecraft:gray_concrete
setblock 415 207 330 minecraft:polished_deepslate
setblock 415 207 341 minecraft:gray_concrete
setblock 415 207 344 minecraft:gray_concrete
setblock 415 207 345 minecraft:polished_deepslate
setblock 416 207 324 minecraft:polished_deepslate
fill 416 207 325 416 210 325 minecraft:gray_concrete
setblock 416 207 329 minecraft:polished_deepslate
fill 416 207 330 416 210 330 minecraft:gray_concrete
setblock 416 207 334 minecraft:polished_deepslate
fill 416 207 335 416 210 335 minecraft:gray_concrete
setblock 416 207 339 minecraft:polished_deepslate
fill 416 207 340 416 210 340 minecraft:gray_concrete
setblock 416 207 344 minecraft:polished_deepslate
fill 416 207 345 416 210 345 minecraft:gray_concrete
setblock 416 207 348 minecraft:gray_concrete
fill 416 207 360 416 210 360 minecraft:gray_concrete
setblock 417 207 323 minecraft:polished_deepslate
fill 417 207 324 417 210 324 minecraft:gray_concrete
setblock 417 207 328 minecraft:polished_deepslate
fill 417 207 329 417 210 329 minecraft:gray_concrete
setblock 417 207 333 minecraft:polished_deepslate
fill 417 207 334 417 210 334 minecraft:gray_concrete
setblock 417 207 338 minecraft:polished_deepslate
fill 417 207 339 417 210 339 minecraft:gray_concrete
setblock 417 207 343 minecraft:polished_deepslate
fill 417 207 344 417 210 344 minecraft:gray_concrete
setblock 417 207 347 minecraft:gray_concrete
setblock 417 207 348 minecraft:polished_deepslate
fill 417 207 349 417 210 349 minecraft:gray_concrete
fill 417 207 351 417 207 352 minecraft:gray_concrete
setblock 417 207 358 minecraft:polished_deepslate
fill 417 207 359 417 210 359 minecraft:gray_concrete
setblock 417 207 363 minecraft:polished_deepslate
fill 418 207 360 418 246 360 minecraft:black_concrete
fill 377 208 323 377 211 323 minecraft:gray_concrete
setblock 377 208 327 minecraft:polished_deepslate
fill 377 208 328 377 211 328 minecraft:gray_concrete
setblock 377 208 332 minecraft:polished_deepslate
fill 377 208 333 377 211 333 minecraft:gray_concrete
setblock 377 208 338 minecraft:gray_concrete
setblock 377 208 342 minecraft:polished_deepslate
fill 377 208 343 377 211 343 minecraft:gray_concrete
setblock 377 208 346 minecraft:gray_concrete
setblock 377 208 347 minecraft:polished_deepslate
fill 377 208 348 377 208 351 minecraft:gray_concrete
setblock 377 208 352 minecraft:polished_deepslate
fill 377 208 353 377 208 356 minecraft:gray_concrete
setblock 377 208 357 minecraft:polished_deepslate
fill 377 208 358 377 211 358 minecraft:gray_concrete
setblock 377 208 361 minecraft:gray_concrete
setblock 377 208 362 minecraft:polished_deepslate
fill 377 208 363 380 208 363 minecraft:gray_concrete
setblock 378 208 326 minecraft:polished_deepslate
fill 378 208 327 378 211 327 minecraft:gray_concrete
fill 378 208 329 378 209 329 minecraft:gray_concrete
setblock 378 208 342 minecraft:gray_concrete
setblock 378 208 346 minecraft:polished_deepslate
fill 378 208 347 378 211 347 minecraft:gray_concrete
setblock 378 208 351 minecraft:polished_deepslate
fill 378 208 352 378 210 353 minecraft:gray_concrete
setblock 378 208 356 minecraft:polished_deepslate
fill 378 208 357 378 211 357 minecraft:gray_concrete
setblock 378 208 361 minecraft:polished_deepslate
fill 378 208 362 381 208 362 minecraft:gray_concrete
fill 378 208 364 378 242 364 minecraft:black_concrete
fill 379 208 322 379 246 322 minecraft:black_concrete
setblock 379 208 325 minecraft:polished_deepslate
fill 379 208 326 379 209 326 minecraft:gray_concrete
setblock 379 208 361 minecraft:gray_concrete
setblock 379 208 364 minecraft:light_blue_stained_glass
setblock 380 208 324 minecraft:polished_deepslate
setblock 381 208 323 minecraft:polished_deepslate
fill 381 208 324 381 211 324 minecraft:gray_concrete
setblock 381 208 363 minecraft:polished_deepslate
fill 382 208 323 382 211 323 minecraft:gray_concrete
setblock 382 208 362 minecraft:polished_deepslate
fill 382 208 363 385 208 363 minecraft:gray_concrete
setblock 383 208 362 minecraft:gray_concrete
setblock 386 208 323 minecraft:polished_deepslate
fill 386 208 331 387 208 332 minecraft:blackstone
fill 386 208 344 387 208 345 minecraft:blackstone
fill 386 208 358 386 212 358 minecraft:black_concrete
setblock 386 208 363 minecraft:polished_deepslate
fill 387 208 323 390 208 323 minecraft:gray_concrete
fill 387 208 357 387 212 357 minecraft:black_concrete
fill 387 208 359 387 212 359 minecraft:black_concrete
fill 387 208 363 390 208 363 minecraft:gray_concrete
setblock 388 208 324 minecraft:black_concrete
setblock 388 208 352 minecraft:black_concrete
fill 388 208 358 388 212 358 minecraft:black_concrete
fill 388 208 364 388 242 364 minecraft:black_concrete
fill 389 208 362 391 208 362 minecraft:gray_concrete
setblock 391 208 323 minecraft:polished_deepslate
fill 391 208 324 391 211 324 minecraft:gray_concrete
fill 391 208 325 391 209 325 minecraft:black_concrete
fill 391 208 351 391 209 351 minecraft:black_concrete
setblock 391 208 363 minecraft:polished_deepslate
fill 392 208 323 392 211 323 minecraft:gray_concrete
setblock 392 208 362 minecraft:polished_deepslate
fill 392 208 363 392 211 363 minecraft:gray_concrete
fill 393 208 362 393 211 362 minecraft:gray_concrete
setblock 395 208 324 minecraft:polished_deepslate
setblock 396 208 323 minecraft:polished_deepslate
fill 396 208 324 396 211 324 minecraft:gray_concrete
setblock 396 208 363 minecraft:polished_deepslate
fill 397 208 323 397 211 323 minecraft:gray_concrete
setblock 397 208 362 minecraft:polished_deepslate
fill 397 208 363 397 211 363 minecraft:gray_concrete
fill 399 208 344 400 228 344 minecraft:polished_deepslate
setblock 400 208 324 minecraft:polished_deepslate
fill 400 208 343 400 228 343 minecraft:polished_deepslate
setblock 401 208 323 minecraft:polished_deepslate
fill 401 208 324 401 211 324 minecraft:gray_concrete
setblock 401 208 363 minecraft:polished_deepslate
fill 402 208 323 405 208 323 minecraft:gray_concrete
fill 405 208 355 405 217 355 minecraft:black_concrete
setblock 406 208 323 minecraft:polished_deepslate
fill 407 208 323 407 210 324 minecraft:gray_concrete
fill 409 208 322 409 211 322 minecraft:black_concrete
setblock 409 208 324 minecraft:gray_concrete
setblock 409 208 325 minecraft:polished_deepslate
fill 409 208 363 409 209 363 minecraft:gray_concrete
setblock 410 208 324 minecraft:polished_deepslate
fill 410 208 325 410 211 325 minecraft:gray_concrete
setblock 411 208 323 minecraft:polished_deepslate
fill 411 208 324 411 211 324 minecraft:gray_concrete
setblock 411 208 363 minecraft:polished_deepslate
fill 412 208 323 412 211 323 minecraft:gray_concrete
setblock 412 208 326 minecraft:gray_concrete
setblock 412 208 362 minecraft:polished_deepslate
fill 412 208 363 412 209 363 minecraft:gray_concrete
setblock 413 208 326 minecraft:polished_deepslate
fill 413 208 362 413 211 362 minecraft:gray_concrete
setblock 414 208 324 minecraft:gray_concrete
setblock 414 208 325 minecraft:polished_deepslate
fill 414 208 326 414 211 326 minecraft:gray_concrete
fill 414 208 328 414 209 328 minecraft:gray_concrete
setblock 415 208 324 minecraft:polished_deepslate
fill 415 208 325 415 211 325 minecraft:gray_concrete
setblock 415 208 329 minecraft:polished_deepslate
fill 415 208 330 415 210 331 minecraft:gray_concrete
setblock 415 208 344 minecraft:polished_deepslate
fill 415 208 345 415 210 346 minecraft:gray_concrete
setblock 416 208 323 minecraft:polished_deepslate
fill 416 208 324 416 211 324 minecraft:gray_concrete
setblock 416 208 328 minecraft:polished_deepslate
fill 416 208 329 416 211 329 minecraft:gray_concrete
setblock 416 208 332 minecraft:gray_concrete
setblock 416 208 333 minecraft:polished_deepslate
fill 416 208 334 416 211 334 minecraft:gray_concrete
setblock 416 208 338 minecraft:polished_deepslate
fill 416 208 339 416 210 339 minecraft:gray_concrete
setblock 416 208 343 minecraft:polished_deepslate
fill 416 208 344 416 211 344 minecraft:gray_concrete
setblock 416 208 348 minecraft:polished_deepslate
fill 416 208 349 416 210 350 minecraft:gray_concrete
setblock 416 208 363 minecraft:polished_deepslate
fill 417 208 323 417 211 323 minecraft:gray_concrete
setblock 417 208 327 minecraft:polished_deepslate
fill 417 208 328 417 211 328 minecraft:gray_concrete
setblock 417 208 332 minecraft:polished_deepslate
fill 417 208 333 417 211 333 minecraft:gray_concrete
setblock 417 208 337 minecraft:polished_deepslate
fill 417 208 338 417 211 338 minecraft:gray_concrete
setblock 417 208 342 minecraft:polished_deepslate
fill 417 208 343 417 211 343 minecraft:gray_concrete
setblock 417 208 347 minecraft:polished_deepslate
fill 417 208 348 417 211 348 minecraft:gray_concrete
setblock 417 208 351 minecraft:gray_concrete
setblock 417 208 352 minecraft:polished_deepslate
fill 417 208 353 417 208 356 minecraft:gray_concrete
setblock 417 208 357 minecraft:polished_deepslate
fill 417 208 358 417 211 358 minecraft:gray_concrete
setblock 417 208 362 minecraft:polished_deepslate
fill 417 208 363 417 211 363 minecraft:gray_concrete
setblock 377 209 326 minecraft:polished_deepslate
fill 377 209 327 377 212 327 minecraft:gray_concrete
setblock 377 209 331 minecraft:polished_deepslate
fill 377 209 332 377 212 332 minecraft:gray_concrete
setblock 377 209 341 minecraft:polished_deepslate
fill 377 209 342 377 212 342 minecraft:gray_concrete
setblock 377 209 346 minecraft:polished_deepslate
fill 377 209 347 377 209 350 minecraft:gray_concrete
setblock 377 209 351 minecraft:polished_deepslate
fill 377 209 352 377 209 355 minecraft:gray_concrete
setblock 377 209 356 minecraft:polished_deepslate
fill 377 209 357 377 212 357 minecraft:gray_concrete
setblock 377 209 361 minecraft:polished_deepslate
fill 377 209 362 379 209 363 minecraft:gray_concrete
setblock 378 209 325 minecraft:polished_deepslate
fill 378 209 326 378 212 326 minecraft:gray_concrete
setblock 378 209 345 minecraft:polished_deepslate
fill 378 209 346 378 212 346 minecraft:gray_concrete
fill 378 209 348 378 209 349 minecraft:gray_concrete
setblock 378 209 350 minecraft:polished_deepslate
fill 378 209 351 378 212 351 minecraft:gray_concrete
setblock 378 209 354 minecraft:gray_concrete
setblock 378 209 355 minecraft:polished_deepslate
fill 378 209 356 378 212 356 minecraft:gray_concrete
setblock 378 209 360 minecraft:polished_deepslate
fill 378 209 361 378 212 361 minecraft:gray_concrete
setblock 379 209 324 minecraft:polished_deepslate
fill 379 209 325 379 210 325 minecraft:gray_concrete
fill 379 209 364 379 242 364 minecraft:black_concrete
setblock 380 209 323 minecraft:polished_deepslate
fill 380 209 324 380 211 324 minecraft:gray_concrete
setblock 380 209 362 minecraft:gray_concrete
setblock 380 209 363 minecraft:polished_deepslate
fill 381 209 323 381 212 323 minecraft:gray_concrete
setblock 381 209 362 minecraft:polished_deepslate
fill 381 209 363 384 209 363 minecraft:gray_concrete
setblock 382 209 362 minecraft:gray_concrete
setblock 385 209 323 minecraft:polished_deepslate
fill 385 209 330 386 210 331 minecraft:blackstone
fill 385 209 345 386 210 346 minecraft:blackstone
setblock 385 209 363 minecraft:polished_deepslate
fill 386 209 323 389 209 323 minecraft:gray_concrete
setblock 386 209 332 minecraft:blackstone
setblock 386 209 344 minecraft:blackstone
fill 386 209 363 389 209 363 minecraft:gray_concrete
setblock 387 209 331 minecraft:blackstone
setblock 387 209 345 minecraft:blackstone
fill 389 209 362 390 209 362 minecraft:gray_concrete
setblock 390 209 323 minecraft:polished_deepslate
fill 390 209 324 390 212 324 minecraft:gray_concrete
setblock 390 209 363 minecraft:polished_deepslate
fill 391 209 323 391 212 323 minecraft:gray_concrete
setblock 391 209 362 minecraft:polished_deepslate
fill 391 209 363 391 212 363 minecraft:gray_concrete
fill 392 209 362 392 211 362 minecraft:gray_concrete
setblock 393 209 325 minecraft:polished_deepslate
setblock 394 209 323 minecraft:gray_concrete
setblock 394 209 324 minecraft:polished_deepslate
fill 394 209 325 397 209 325 minecraft:gray_concrete
setblock 395 209 323 minecraft:polished_deepslate
fill 395 209 324 395 212 324 minecraft:gray_concrete
setblock 395 209 363 minecraft:polished_deepslate
fill 396 209 323 396 212 323 minecraft:gray_concrete
fill 396 209 342 398 232 344 minecraft:polished_deepslate
setblock 396 209 362 minecraft:polished_deepslate
fill 396 209 363 396 212 363 minecraft:gray_concrete
setblock 397 209 362 minecraft:gray_concrete
setblock 397 209 364 minecraft:light_blue_stained_glass
setblock 398 209 324 minecraft:gray_concrete
fill 398 209 364 398 211 364 minecraft:black_concrete
setblock 399 209 324 minecraft:polished_deepslate
fill 399 209 343 399 228 343 minecraft:polished_deepslate
setblock 400 209 323 minecraft:polished_deepslate
fill 400 209 324 400 211 324 minecraft:gray_concrete
setblock 400 209 363 minecraft:polished_deepslate
fill 401 209 323 404 209 323 minecraft:gray_concrete
fill 402 209 324 402 210 324 minecraft:gray_concrete
setblock 405 209 323 minecraft:polished_deepslate
fill 405 209 324 406 211 324 minecraft:gray_concrete
fill 406 209 323 406 212 323 minecraft:gray_concrete
setblock 408 209 325 minecraft:polished_deepslate
setblock 409 209 324 minecraft:polished_deepslate
fill 409 209 325 409 212 325 minecraft:gray_concrete
fill 410 209 322 415 243 322 minecraft:black_concrete
setblock 410 209 323 minecraft:polished_deepslate
fill 410 209 324 410 212 324 minecraft:gray_concrete
setblock 410 209 363 minecraft:polished_deepslate
fill 411 209 323 411 212 323 minecraft:gray_concrete
setblock 411 209 326 minecraft:gray_concrete
fill 411 209 363 411 212 363 minecraft:gray_concrete
setblock 412 209 325 minecraft:gray_concrete
setblock 412 209 326 minecraft:polished_deepslate
fill 412 209 362 412 212 362 minecraft:gray_concrete
setblock 413 209 325 minecraft:polished_deepslate
fill 413 209 326 413 212 326 minecraft:gray_concrete
setblock 413 209 363 minecraft:yellow_concrete
setblock 414 209 324 minecraft:polished_deepslate
fill 414 209 325 414 212 325 minecraft:gray_concrete
setblock 414 209 329 minecraft:polished_deepslate
setblock 415 209 323 minecraft:polished_deepslate
fill 415 209 324 415 212 324 minecraft:gray_concrete
setblock 415 209 327 minecraft:gray_concrete
setblock 415 209 328 minecraft:polished_deepslate
fill 415 209 329 415 212 329 minecraft:gray_concrete
setblock 415 209 332 minecraft:gray_concrete
setblock 415 209 342 minecraft:gray_concrete
setblock 415 209 343 minecraft:polished_deepslate
fill 415 209 344 415 210 344 minecraft:gray_concrete
setblock 415 209 347 minecraft:gray_concrete
setblock 415 209 363 minecraft:polished_deepslate
setblock 416 209 322 minecraft:light_blue_stained_glass
fill 416 209 323 416 212 323 minecraft:gray_concrete
setblock 416 209 327 minecraft:polished_deepslate
fill 416 209 328 416 212 328 minecraft:gray_concrete
setblock 416 209 332 minecraft:polished_deepslate
fill 416 209 333 416 212 333 minecraft:gray_concrete
setblock 416 209 337 minecraft:polished_deepslate
setblock 416 209 338 minecraft:gray_concrete
setblock 416 209 342 minecraft:polished_deepslate
fill 416 209 343 416 211 343 minecraft:gray_concrete
setblock 416 209 346 minecraft:gray_concrete
setblock 416 209 347 minecraft:polished_deepslate
fill 416 209 348 416 212 348 minecraft:gray_concrete
setblock 416 209 351 minecraft:gray_concrete
setblock 416 209 362 minecraft:polished_deepslate
fill 416 209 363 416 212 363 minecraft:gray_concrete
setblock 417 209 326 minecraft:polished_deepslate
fill 417 209 327 417 212 327 minecraft:gray_concrete
setblock 417 209 331 minecraft:polished_deepslate
fill 417 209 332 417 212 332 minecraft:gray_concrete
setblock 417 209 336 minecraft:polished_deepslate
fill 417 209 337 417 211 337 minecraft:gray_concrete
setblock 417 209 341 minecraft:polished_deepslate
fill 417 209 342 417 212 342 minecraft:gray_concrete
setblock 417 209 346 minecraft:polished_deepslate
fill 417 209 347 417 212 347 minecraft:gray_concrete
setblock 417 209 351 minecraft:polished_deepslate
fill 417 209 352 417 209 355 minecraft:gray_concrete
setblock 417 209 356 minecraft:polished_deepslate
fill 417 209 357 417 212 357 minecraft:gray_concrete
setblock 417 209 361 minecraft:polished_deepslate
fill 417 209 362 417 212 362 minecraft:gray_concrete
setblock 377 210 325 minecraft:polished_deepslate
fill 377 210 326 377 213 326 minecraft:gray_concrete
setblock 377 210 330 minecraft:polished_deepslate
fill 377 210 331 377 213 331 minecraft:gray_concrete
setblock 377 210 340 minecraft:polished_deepslate
fill 377 210 341 377 211 341 minecraft:gray_concrete
setblock 377 210 345 minecraft:polished_deepslate
fill 377 210 346 377 210 349 minecraft:gray_concrete
setblock 377 210 350 minecraft:polished_deepslate
fill 377 210 351 377 210 354 minecraft:gray_concrete
setblock 377 210 355 minecraft:polished_deepslate
fill 377 210 356 377 213 356 minecraft:gray_concrete
setblock 377 210 360 minecraft:polished_deepslate
fill 377 210 361 377 211 363 minecraft:gray_concrete
setblock 378 210 324 minecraft:polished_deepslate
fill 378 210 325 378 213 325 minecraft:gray_concrete
setblock 378 210 329 minecraft:polished_deepslate
setblock 378 210 344 minecraft:polished_deepslate
fill 378 210 345 378 212 345 minecraft:gray_concrete
setblock 378 210 348 minecraft:gray_concrete
setblock 378 210 349 minecraft:polished_deepslate
fill 378 210 350 378 213 350 minecraft:gray_concrete
setblock 378 210 354 minecraft:polished_deepslate
fill 378 210 355 378 213 355 minecraft:gray_concrete
setblock 378 210 359 minecraft:polished_deepslate
fill 378 210 360 378 212 360 minecraft:gray_concrete
fill 378 210 362 378 210 363 minecraft:gray_concrete
setblock 379 210 323 minecraft:polished_deepslate
fill 379 210 324 379 212 324 minecraft:gray_concrete
setblock 379 210 362 minecraft:gray_concrete
setblock 379 210 363 minecraft:polished_deepslate
fill 380 210 323 380 213 323 minecraft:gray_concrete
setblock 380 210 362 minecraft:polished_deepslate
fill 380 210 363 383 210 363 minecraft:gray_concrete
setblock 381 210 362 minecraft:gray_concrete
setblock 384 210 323 minecraft:polished_deepslate
setblock 384 210 363 minecraft:polished_deepslate
fill 385 210 323 388 210 323 minecraft:gray_concrete
fill 385 210 363 388 210 363 minecraft:gray_concrete
setblock 386 210 364 minecraft:light_blue_stained_glass
setblock 389 210 323 minecraft:polished_deepslate
fill 389 210 324 389 212 324 minecraft:gray_concrete
setblock 389 210 362 minecraft:gray_concrete
setblock 389 210 363 minecraft:polished_deepslate
fill 390 210 323 390 213 323 minecraft:gray_concrete
setblock 390 210 362 minecraft:polished_deepslate
fill 390 210 363 390 213 363 minecraft:gray_concrete
fill 391 210 362 391 211 362 minecraft:gray_concrete
setblock 392 210 324 minecraft:gray_concrete
setblock 392 210 325 minecraft:polished_deepslate
setblock 393 210 324 minecraft:polished_deepslate
fill 393 210 325 396 210 325 minecraft:gray_concrete
setblock 394 210 323 minecraft:polished_deepslate
fill 394 210 324 394 213 324 minecraft:gray_concrete
setblock 394 210 363 minecraft:polished_deepslate
fill 395 210 323 395 213 323 minecraft:gray_concrete
setblock 395 210 362 minecraft:polished_deepslate
fill 395 210 363 395 213 363 minecraft:gray_concrete
setblock 396 210 362 minecraft:gray_concrete
setblock 397 210 322 minecraft:light_blue_stained_glass
setblock 397 210 325 minecraft:polished_deepslate
fill 397 210 364 397 239 364 minecraft:black_concrete
setblock 398 210 324 minecraft:polished_deepslate
setblock 399 210 323 minecraft:polished_deepslate
fill 399 210 324 399 212 324 minecraft:gray_concrete
setblock 399 210 363 minecraft:polished_deepslate
fill 400 210 323 403 210 323 minecraft:gray_concrete
setblock 403 210 324 minecraft:polished_deepslate
setblock 404 210 323 minecraft:polished_deepslate
fill 404 210 324 404 212 324 minecraft:gray_concrete
fill 404 210 355 404 217 355 minecraft:black_concrete
fill 405 210 323 405 213 323 minecraft:gray_concrete
fill 405 210 354 405 217 354 minecraft:black_concrete
fill 405 210 356 405 217 356 minecraft:black_concrete
fill 406 210 355 406 217 355 minecraft:black_concrete
setblock 407 210 325 minecraft:polished_deepslate
setblock 408 210 323 minecraft:gray_concrete
setblock 408 210 324 minecraft:polished_deepslate
fill 408 210 325 408 213 325 minecraft:gray_concrete
setblock 408 210 363 minecraft:gray_concrete
setblock 409 210 323 minecraft:polished_deepslate
fill 409 210 324 409 213 324 minecraft:gray_concrete
setblock 409 210 363 minecraft:polished_deepslate
fill 410 210 323 410 213 323 minecraft:gray_concrete
setblock 410 210 326 minecraft:gray_concrete
fill 410 210 363 410 213 363 minecraft:gray_concrete
setblock 411 210 326 minecraft:polished_deepslate
setblock 412 210 325 minecraft:polished_deepslate
fill 412 210 326 412 213 326 minecraft:gray_concrete
setblock 412 210 363 minecraft:yellow_concrete
setblock 413 210 324 minecraft:polished_deepslate
fill 413 210 325 413 213 325 minecraft:gray_concrete
fill 413 210 327 413 211 327 minecraft:gray_concrete
setblock 413 210 363 minecraft:gray_concrete
setblock 414 210 323 minecraft:polished_deepslate
fill 414 210 324 414 213 324 minecraft:gray_concrete
setblock 414 210 328 minecraft:polished_deepslate
fill 414 210 329 414 212 330 minecraft:gray_concrete
setblock 414 210 363 minecraft:polished_deepslate
fill 415 210 323 415 213 323 minecraft:gray_concrete
setblock 415 210 327 minecraft:polished_deepslate
fill 415 210 328 415 213 328 minecraft:gray_concrete
setblock 415 210 332 minecraft:polished_deepslate
fill 415 210 333 415 211 333 minecraft:gray_concrete
setblock 415 210 347 minecraft:polished_deepslate
fill 415 210 348 415 211 348 minecraft:gray_concrete
setblock 415 210 362 minecraft:polished_deepslate
fill 415 210 363 415 212 363 minecraft:gray_concrete
fill 416 210 322 416 236 322 minecraft:black_concrete
setblock 416 210 326 minecraft:polished_deepslate
fill 416 210 327 416 213 327 minecraft:gray_concrete
setblock 416 210 331 minecraft:polished_deepslate
fill 416 210 332 416 213 332 minecraft:gray_concrete
setblock 416 210 336 minecraft:polished_deepslate
setblock 416 210 341 minecraft:polished_deepslate
fill 416 210 342 416 211 342 minecraft:gray_concrete
setblock 416 210 346 minecraft:polished_deepslate
fill 416 210 347 416 213 347 minecraft:gray_concrete
setblock 416 210 351 minecraft:polished_deepslate
fill 416 210 352 417 212 352 minecraft:gray_concrete
setblock 416 210 361 minecraft:polished_deepslate
fill 416 210 362 416 213 362 minecraft:gray_concrete
setblock 417 210 325 minecraft:polished_deepslate
fill 417 210 326 417 213 326 minecraft:gray_concrete
setblock 417 210 330 minecraft:polished_deepslate
fill 417 210 331 417 213 331 minecraft:gray_concrete
setblock 417 210 335 minecraft:polished_deepslate
fill 417 210 336 417 212 336 minecraft:gray_concrete
setblock 417 210 340 minecraft:polished_deepslate
fill 417 210 341 417 212 341 minecraft:gray_concrete
setblock 417 210 345 minecraft:polished_deepslate
fill 417 210 346 417 213 346 minecraft:gray_concrete
setblock 417 210 350 minecraft:polished_deepslate
fill 417 210 351 417 213 351 minecraft:gray_concrete
fill 417 210 353 417 210 354 minecraft:gray_concrete
setblock 417 210 355 minecraft:polished_deepslate
fill 417 210 356 417 213 356 minecraft:gray_concrete
setblock 417 210 360 minecraft:polished_deepslate
fill 417 210 361 417 213 361 minecraft:gray_concrete
setblock 377 211 324 minecraft:polished_deepslate
fill 377 211 325 377 214 325 minecraft:gray_concrete
setblock 377 211 329 minecraft:polished_deepslate
fill 377 211 330 377 214 330 minecraft:gray_concrete
fill 377 211 334 378 212 334 minecraft:light_blue_stained_glass
setblock 377 211 344 minecraft:polished_deepslate
fill 377 211 345 377 211 348 minecraft:gray_concrete
setblock 377 211 349 minecraft:polished_deepslate
fill 377 211 350 377 211 353 minecraft:gray_concrete
setblock 377 211 354 minecraft:polished_deepslate
fill 377 211 355 377 214 355 minecraft:gray_concrete
setblock 377 211 359 minecraft:polished_deepslate
fill 377 211 360 377 214 360 minecraft:gray_concrete
setblock 378 211 323 minecraft:polished_deepslate
fill 378 211 324 378 213 324 minecraft:gray_concrete
setblock 378 211 328 minecraft:polished_deepslate
fill 378 211 329 378 212 329 minecraft:gray_concrete
fill 378 211 332 378 213 333 minecraft:light_blue_stained_glass
setblock 378 211 344 minecraft:gray_concrete
setblock 378 211 348 minecraft:polished_deepslate
fill 378 211 349 378 214 349 minecraft:gray_concrete
setblock 378 211 352 minecraft:gray_concrete
setblock 378 211 353 minecraft:polished_deepslate
fill 378 211 354 378 214 354 minecraft:gray_concrete
setblock 378 211 358 minecraft:polished_deepslate
setblock 378 211 359 minecraft:gray_concrete
setblock 378 211 362 minecraft:gray_concrete
setblock 378 211 363 minecraft:polished_deepslate
fill 379 211 323 379 213 323 minecraft:gray_concrete
fill 379 211 333 379 213 333 minecraft:light_blue_stained_glass
setblock 379 211 362 minecraft:polished_deepslate
fill 379 211 363 382 211 363 minecraft:gray_concrete
setblock 380 211 362 minecraft:gray_concrete
setblock 383 211 323 minecraft:polished_deepslate
setblock 383 211 363 minecraft:polished_deepslate
fill 384 211 323 387 211 323 minecraft:gray_concrete
fill 384 211 363 387 211 363 minecraft:gray_concrete
setblock 385 211 330 minecraft:blackstone
setblock 385 211 346 minecraft:blackstone
fill 386 211 357 386 212 357 minecraft:black_concrete
fill 386 211 359 386 212 359 minecraft:black_concrete
fill 386 211 364 386 246 364 minecraft:black_concrete
setblock 388 211 323 minecraft:polished_deepslate
fill 388 211 357 388 212 357 minecraft:black_concrete
fill 388 211 359 388 212 359 minecraft:black_concrete
setblock 388 211 363 minecraft:polished_deepslate
fill 389 211 323 389 214 323 minecraft:gray_concrete
fill 389 211 363 389 214 363 minecraft:gray_concrete
setblock 390 211 362 minecraft:gray_concrete
setblock 391 211 322 minecraft:light_blue_stained_glass
setblock 392 211 324 minecraft:polished_deepslate
fill 392 211 325 395 211 325 minecraft:gray_concrete
setblock 393 211 323 minecraft:polished_deepslate
fill 393 211 324 393 214 324 minecraft:gray_concrete
setblock 393 211 363 minecraft:polished_deepslate
fill 394 211 323 394 214 323 minecraft:gray_concrete
setblock 394 211 362 minecraft:polished_deepslate
fill 394 211 363 394 213 363 minecraft:gray_concrete
setblock 395 211 364 minecraft:light_blue_stained_glass
setblock 396 211 325 minecraft:polished_deepslate
fill 396 211 364 396 228 364 minecraft:black_concrete
fill 397 211 322 397 240 322 minecraft:black_concrete
setblock 397 211 324 minecraft:polished_deepslate
setblock 397 211 325 minecraft:gray_concrete
setblock 398 211 323 minecraft:polished_deepslate
fill 398 211 324 398 212 324 minecraft:gray_concrete
setblock 398 211 363 minecraft:polished_deepslate
fill 399 211 323 402 211 323 minecraft:gray_concrete
setblock 403 211 323 minecraft:polished_deepslate
setblock 403 211 324 minecraft:gray_concrete
fill 404 211 323 404 214 323 minecraft:gray_concrete
fill 404 211 354 404 217 354 minecraft:black_concrete
fill 404 211 356 404 217 356 minecraft:black_concrete
fill 406 211 354 406 217 354 minecraft:black_concrete
fill 406 211 356 406 217 356 minecraft:black_concrete
setblock 407 211 323 minecraft:gray_concrete
setblock 407 211 324 minecraft:polished_deepslate
fill 407 211 325 407 214 325 minecraft:gray_concrete
setblock 408 211 323 minecraft:polished_deepslate
fill 408 211 324 408 214 324 minecraft:gray_concrete
setblock 408 211 363 minecraft:polished_deepslate
fill 409 211 323 409 214 323 minecraft:gray_concrete
setblock 409 211 326 minecraft:gray_concrete
fill 409 211 363 409 214 363 minecraft:gray_concrete
setblock 410 211 326 minecraft:polished_deepslate
setblock 411 211 325 minecraft:polished_deepslate
fill 411 211 326 411 214 326 minecraft:gray_concrete
setblock 411 211 362 minecraft:gray_concrete
setblock 412 211 324 minecraft:polished_deepslate
fill 412 211 325 412 214 325 minecraft:gray_concrete
fill 412 211 327 412 212 327 minecraft:gray_concrete
setblock 412 211 363 minecraft:gray_concrete
setblock 413 211 323 minecraft:polished_deepslate
fill 413 211 324 413 214 324 minecraft:gray_concrete
setblock 413 211 328 minecraft:polished_deepslate
setblock 413 211 363 minecraft:yellow_concrete
fill 414 211 323 414 214 323 minecraft:gray_concrete
setblock 414 211 327 minecraft:polished_deepslate
fill 414 211 328 414 214 328 minecraft:gray_concrete
setblock 414 211 331 minecraft:gray_concrete
setblock 414 211 362 minecraft:polished_deepslate
setblock 414 211 363 minecraft:gray_concrete
setblock 415 211 326 minecraft:polished_deepslate
fill 415 211 327 415 214 327 minecraft:gray_concrete
setblock 415 211 330 minecraft:gray_concrete
setblock 415 211 331 minecraft:polished_deepslate
fill 415 211 332 415 214 332 minecraft:gray_concrete
setblock 415 211 345 minecraft:gray_concrete
setblock 415 211 346 minecraft:polished_deepslate
setblock 415 211 347 minecraft:gray_concrete
fill 415 211 349 416 211 349 minecraft:gray_concrete
fill 415 211 362 415 213 362 minecraft:gray_concrete
setblock 416 211 325 minecraft:polished_deepslate
fill 416 211 326 416 214 326 minecraft:gray_concrete
setblock 416 211 330 minecraft:polished_deepslate
fill 416 211 331 416 214 331 minecraft:gray_concrete
setblock 416 211 335 minecraft:polished_deepslate
setblock 416 211 345 minecraft:polished_deepslate
fill 416 211 346 416 213 346 minecraft:gray_concrete
setblock 416 211 350 minecraft:polished_deepslate
fill 416 211 351 416 214 351 minecraft:gray_concrete
fill 416 211 353 417 211 353 minecraft:gray_concrete
setblock 416 211 360 minecraft:polished_deepslate
fill 416 211 361 416 212 361 minecraft:gray_concrete
setblock 417 211 324 minecraft:polished_deepslate
fill 417 211 325 417 214 325 minecraft:gray_concrete
setblock 417 211 329 minecraft:polished_deepslate
fill 417 211 330 417 214 330 minecraft:gray_concrete
setblock 417 211 334 minecraft:polished_deepslate
fill 417 211 335 417 213 335 minecraft:gray_concrete
setblock 417 211 339 minecraft:polished_deepslate
setblock 417 211 340 minecraft:gray_concrete
setblock 417 211 344 minecraft:polished_deepslate
fill 417 211 345 417 213 345 minecraft:gray_concrete
setblock 417 211 349 minecraft:polished_deepslate
fill 417 211 350 417 214 350 minecraft:gray_concrete
setblock 417 211 354 minecraft:polished_deepslate
fill 417 211 355 417 214 355 minecraft:gray_concrete
setblock 417 211 359 minecraft:polished_deepslate
fill 417 211 360 417 214 360 minecraft:gray_concrete
fill 376 212 352 376 224 354 minecraft:black_concrete
setblock 376 212 355 minecraft:light_blue_stained_glass
fill 376 212 356 376 243 357 minecraft:black_concrete
setblock 377 212 323 minecraft:polished_deepslate
fill 377 212 324 377 215 324 minecraft:gray_concrete
setblock 377 212 328 minecraft:polished_deepslate
fill 377 212 329 377 215 329 minecraft:gray_concrete
fill 377 212 333 377 213 333 minecraft:light_blue_stained_glass
setblock 377 212 343 minecraft:polished_deepslate
fill 377 212 344 377 212 347 minecraft:gray_concrete
setblock 377 212 348 minecraft:polished_deepslate
fill 377 212 349 377 212 352 minecraft:gray_concrete
setblock 377 212 353 minecraft:polished_deepslate
fill 377 212 354 377 215 354 minecraft:gray_concrete
setblock 377 212 358 minecraft:polished_deepslate
fill 377 212 359 377 215 359 minecraft:gray_concrete
fill 377 212 361 377 212 362 minecraft:gray_concrete
setblock 377 212 363 minecraft:polished_deepslate
fill 378 212 323 378 214 323 minecraft:gray_concrete
setblock 378 212 327 minecraft:polished_deepslate
fill 378 212 328 378 213 328 minecraft:gray_concrete
setblock 378 212 347 minecraft:polished_deepslate
fill 378 212 348 378 214 348 minecraft:gray_concrete
setblock 378 212 352 minecraft:polished_deepslate
fill 378 212 353 378 215 353 minecraft:gray_concrete
setblock 378 212 357 minecraft:polished_deepslate
setblock 378 212 362 minecraft:polished_deepslate
fill 378 212 363 381 212 363 minecraft:gray_concrete
setblock 379 212 325 minecraft:light[level=12]
fill 379 212 332 380 213 332 minecraft:light_blue_stained_glass
fill 379 212 334 380 213 334 minecraft:light_blue_stained_glass
setblock 379 212 339 minecraft:light[level=12]
setblock 379 212 346 minecraft:light[level=12]
setblock 379 212 353 minecraft:light[level=12]
setblock 379 212 360 minecraft:light[level=12]
fill 380 212 333 380 213 333 minecraft:light_blue_stained_glass
setblock 382 212 323 minecraft:polished_deepslate
setblock 382 212 363 minecraft:polished_deepslate
setblock 383 212 323 minecraft:gray_concrete
fill 383 212 363 386 212 363 minecraft:gray_concrete
fill 385 212 323 386 212 323 minecraft:gray_concrete
setblock 386 212 325 minecraft:light[level=12]
setblock 386 212 332 minecraft:light[level=12]
setblock 386 212 339 minecraft:light[level=12]
setblock 386 212 346 minecraft:light[level=12]
setblock 386 212 353 minecraft:light[level=12]
setblock 386 212 360 minecraft:light[level=12]
setblock 387 212 323 minecraft:polished_deepslate
setblock 387 212 363 minecraft:polished_deepslate
fill 388 212 323 388 214 323 minecraft:gray_concrete
fill 388 212 363 388 213 363 minecraft:gray_concrete
fill 391 212 322 391 247 322 minecraft:black_concrete
setblock 391 212 324 minecraft:polished_deepslate
fill 391 212 358 391 213 358 minecraft:gray_wool
setblock 392 212 323 minecraft:polished_deepslate
fill 392 212 324 392 212 325 minecraft:gray_concrete
setblock 392 212 363 minecraft:polished_deepslate
fill 393 212 323 393 215 323 minecraft:gray_concrete
fill 393 212 325 394 212 325 minecraft:gray_concrete
setblock 393 212 332 minecraft:light[level=12]
setblock 393 212 339 minecraft:light[level=12]
setblock 393 212 346 minecraft:light[level=12]
setblock 393 212 353 minecraft:light[level=12]
setblock 393 212 360 minecraft:light[level=12]
fill 393 212 363 393 214 363 minecraft:gray_concrete
setblock 395 212 325 minecraft:polished_deepslate
fill 395 212 364 395 247 364 minecraft:black_concrete
setblock 396 212 324 minecraft:polished_deepslate
setblock 397 212 323 minecraft:polished_deepslate
fill 397 212 324 397 213 324 minecraft:gray_concrete
fill 398 212 323 401 212 323 minecraft:gray_concrete
setblock 398 212 364 minecraft:light_blue_stained_glass
setblock 400 212 325 minecraft:light[level=12]
setblock 400 212 332 minecraft:light[level=12]
setblock 400 212 339 minecraft:light[level=12]
setblock 400 212 353 minecraft:light[level=12]
setblock 400 212 360 minecraft:light[level=12]
fill 401 212 358 402 213 359 minecraft:white_wool
setblock 402 212 323 minecraft:polished_deepslate
fill 403 212 323 403 213 323 minecraft:gray_concrete
fill 403 212 355 403 217 356 minecraft:black_concrete
fill 403 212 358 403 213 358 minecraft:white_wool
fill 404 212 357 405 217 357 minecraft:black_concrete
setblock 405 212 324 minecraft:gray_concrete
setblock 406 212 324 minecraft:polished_deepslate
setblock 407 212 323 minecraft:polished_deepslate
fill 407 212 324 407 215 324 minecraft:gray_concrete
setblock 407 212 332 minecraft:light[level=12]
setblock 407 212 339 minecraft:light[level=12]
setblock 407 212 346 minecraft:light[level=12]
setblock 407 212 353 minecraft:light[level=12]
fill 407 212 355 407 217 355 minecraft:black_concrete
setblock 407 212 360 minecraft:light[level=12]
fill 408 212 323 408 215 323 minecraft:gray_concrete
setblock 408 212 363 minecraft:gray_concrete
setblock 409 212 322 minecraft:light_blue_stained_glass
setblock 409 212 326 minecraft:polished_deepslate
setblock 410 212 325 minecraft:polished_deepslate
fill 410 212 326 410 215 326 minecraft:gray_concrete
setblock 411 212 324 minecraft:polished_deepslate
fill 411 212 325 411 215 325 minecraft:gray_concrete
fill 411 212 327 411 213 327 minecraft:gray_concrete
setblock 412 212 323 minecraft:polished_deepslate
fill 412 212 324 412 215 324 minecraft:gray_concrete
setblock 412 212 363 minecraft:polished_deepslate
fill 413 212 323 413 215 323 minecraft:gray_concrete
setblock 413 212 327 minecraft:polished_deepslate
fill 413 212 328 413 213 328 minecraft:gray_concrete
setblock 413 212 362 minecraft:polished_deepslate
fill 413 212 363 413 214 363 minecraft:gray_concrete
setblock 414 212 326 minecraft:polished_deepslate
fill 414 212 327 414 215 327 minecraft:gray_concrete
setblock 414 212 331 minecraft:polished_deepslate
setblock 414 212 332 minecraft:light[level=12]
setblock 414 212 339 minecraft:light[level=12]
setblock 414 212 346 minecraft:light[level=12]
setblock 414 212 353 minecraft:light[level=12]
setblock 414 212 360 minecraft:light[level=12]
fill 414 212 362 414 213 362 minecraft:gray_concrete
setblock 414 212 363 minecraft:ochre_froglight
setblock 415 212 325 minecraft:polished_deepslate
fill 415 212 326 415 215 326 minecraft:gray_concrete
setblock 415 212 330 minecraft:polished_deepslate
fill 415 212 331 415 215 331 minecraft:gray_concrete
setblock 416 212 324 minecraft:polished_deepslate
fill 416 212 325 416 215 325 minecraft:gray_concrete
setblock 416 212 329 minecraft:polished_deepslate
fill 416 212 330 416 215 330 minecraft:gray_concrete
setblock 416 212 334 minecraft:polished_deepslate
setblock 416 212 344 minecraft:polished_deepslate
setblock 416 212 345 minecraft:gray_concrete
setblock 416 212 349 minecraft:polished_deepslate
fill 416 212 350 416 214 350 minecraft:gray_concrete
setblock 416 212 353 minecraft:gray_concrete
setblock 417 212 323 minecraft:polished_deepslate
fill 417 212 324 417 215 324 minecraft:gray_concrete
setblock 417 212 328 minecraft:polished_deepslate
fill 417 212 329 417 215 329 minecraft:gray_concrete
setblock 417 212 333 minecraft:polished_deepslate
fill 417 212 334 417 214 334 minecraft:gray_concrete
setblock 417 212 343 minecraft:polished_deepslate
fill 417 212 344 417 213 344 minecraft:gray_concrete
setblock 417 212 348 minecraft:polished_deepslate
fill 417 212 349 417 215 349 minecraft:gray_concrete
setblock 417 212 353 minecraft:polished_deepslate
fill 417 212 354 417 215 354 minecraft:gray_concrete
setblock 417 212 358 minecraft:polished_deepslate
fill 417 212 359 417 214 359 minecraft:gray_concrete
setblock 417 212 363 minecraft:polished_deepslate
setblock 376 213 333 minecraft:light_blue_stained_glass
fill 376 213 334 376 242 334 minecraft:black_concrete
fill 376 213 355 376 246 355 minecraft:black_concrete
fill 377 213 323 377 215 323 minecraft:gray_concrete
setblock 377 213 327 minecraft:polished_deepslate
fill 377 213 328 377 216 328 minecraft:gray_concrete
setblock 377 213 332 minecraft:polished_deepslate
fill 377 213 343 377 213 346 minecraft:gray_concrete
setblock 377 213 347 minecraft:polished_deepslate
fill 377 213 348 377 213 351 minecraft:gray_concrete
setblock 377 213 352 minecraft:polished_deepslate
fill 377 213 353 377 216 353 minecraft:gray_concrete
setblock 377 213 357 minecraft:polished_deepslate
fill 377 213 358 377 216 358 minecraft:gray_concrete
setblock 377 213 361 minecraft:gray_concrete
setblock 377 213 362 minecraft:polished_deepslate
fill 377 213 363 380 213 363 minecraft:gray_concrete
setblock 378 213 326 minecraft:polished_deepslate
setblock 378 213 327 minecraft:gray_concrete
setblock 378 213 334 minecraft:light_blue_stained_glass
setblock 378 213 346 minecraft:polished_deepslate
setblock 378 213 347 minecraft:gray_concrete
setblock 378 213 351 minecraft:polished_deepslate
fill 378 213 352 378 216 352 minecraft:gray_concrete
setblock 378 213 356 minecraft:polished_deepslate
fill 381 213 332 381 213 334 minecraft:light_blue_stained_glass
fill 382 213 333 382 214 333 minecraft:light_blue_stained_glass
setblock 387 213 323 minecraft:gray_concrete
setblock 387 213 363 minecraft:gray_concrete
setblock 390 213 324 minecraft:polished_deepslate
setblock 391 213 323 minecraft:polished_deepslate
fill 391 213 324 392 214 324 minecraft:gray_concrete
setblock 391 213 363 minecraft:polished_deepslate
fill 392 213 323 392 215 323 minecraft:gray_concrete
fill 392 213 363 392 214 363 minecraft:gray_concrete
setblock 395 213 324 minecraft:polished_deepslate
setblock 396 213 323 minecraft:polished_deepslate
setblock 396 213 324 minecraft:gray_concrete
fill 397 213 323 400 213 323 minecraft:gray_concrete
fill 398 213 364 398 244 364 minecraft:black_concrete
setblock 401 213 323 minecraft:polished_deepslate
setblock 402 213 323 minecraft:gray_concrete
fill 403 213 354 403 217 354 minecraft:black_concrete
fill 404 213 353 406 217 353 minecraft:black_concrete
setblock 405 213 324 minecraft:polished_deepslate
setblock 406 213 323 minecraft:polished_deepslate
fill 406 213 324 406 216 324 minecraft:gray_concrete
fill 406 213 357 406 217 357 minecraft:black_concrete
fill 407 213 323 407 216 323 minecraft:gray_concrete
fill 407 213 354 407 217 354 minecraft:black_concrete
fill 407 213 356 407 217 356 minecraft:black_concrete
fill 409 213 322 409 246 322 minecraft:black_concrete
setblock 409 213 325 minecraft:polished_deepslate
fill 409 213 326 409 215 326 minecraft:gray_concrete
setblock 410 213 324 minecraft:polished_deepslate
fill 410 213 325 410 216 325 minecraft:gray_concrete
setblock 411 213 323 minecraft:polished_deepslate
fill 411 213 324 411 216 324 minecraft:gray_concrete
setblock 411 213 363 minecraft:polished_deepslate
fill 412 213 323 412 216 323 minecraft:gray_concrete
setblock 412 213 327 minecraft:polished_deepslate
setblock 412 213 362 minecraft:polished_deepslate
fill 412 213 363 412 215 363 minecraft:gray_concrete
setblock 413 213 326 minecraft:polished_deepslate
setblock 413 213 327 minecraft:gray_concrete
setblock 413 213 362 minecraft:gray_concrete
setblock 414 213 325 minecraft:polished_deepslate
fill 414 213 326 414 215 326 minecraft:gray_concrete
setblock 414 213 329 minecraft:gray_concrete
setblock 414 213 330 minecraft:polished_deepslate
setblock 414 213 363 minecraft:gray_concrete
setblock 415 213 324 minecraft:polished_deepslate
fill 415 213 325 415 215 325 minecraft:gray_concrete
setblock 415 213 329 minecraft:polished_deepslate
fill 415 213 330 415 216 330 minecraft:gray_concrete
setblock 415 213 363 minecraft:yellow_concrete
setblock 416 213 323 minecraft:polished_deepslate
fill 416 213 324 416 216 324 minecraft:gray_concrete
setblock 416 213 328 minecraft:polished_deepslate
fill 416 213 329 416 216 329 minecraft:gray_concrete
setblock 416 213 333 minecraft:polished_deepslate
setblock 416 213 348 minecraft:polished_deepslate
fill 416 213 349 416 214 349 minecraft:gray_concrete
setblock 416 213 352 minecraft:gray_concrete
setblock 416 213 353 minecraft:polished_deepslate
setblock 416 213 363 minecraft:polished_deepslate
fill 417 213 323 417 216 323 minecraft:gray_concrete
setblock 417 213 327 minecraft:polished_deepslate
fill 417 213 328 417 216 328 minecraft:gray_concrete
setblock 417 213 332 minecraft:polished_deepslate
fill 417 213 333 417 216 333 minecraft:gray_concrete
setblock 417 213 347 minecraft:polished_deepslate
fill 417 213 348 417 215 348 minecraft:gray_concrete
setblock 417 213 352 minecraft:polished_deepslate
fill 417 213 353 417 216 353 minecraft:gray_concrete
setblock 417 213 357 minecraft:polished_deepslate
fill 417 213 358 417 214 358 minecraft:gray_concrete
setblock 417 213 362 minecraft:polished_deepslate
fill 417 213 363 417 215 363 minecraft:gray_concrete
fill 376 214 333 376 243 333 minecraft:black_concrete
setblock 376 214 338 minecraft:light_blue_stained_glass
fill 376 214 339 376 246 339 minecraft:black_concrete
setblock 377 214 326 minecraft:polished_deepslate
fill 377 214 327 377 215 327 minecraft:gray_concrete
setblock 377 214 331 minecraft:polished_deepslate
setblock 377 214 345 minecraft:gray_concrete
setblock 377 214 346 minecraft:polished_deepslate
fill 377 214 347 377 214 350 minecraft:gray_concrete
setblock 377 214 351 minecraft:polished_deepslate
fill 377 214 352 377 217 352 minecraft:gray_concrete
setblock 377 214 356 minecraft:polished_deepslate
fill 377 214 357 377 217 357 minecraft:gray_concrete
setblock 377 214 361 minecraft:polished_deepslate
fill 377 214 362 377 215 363 minecraft:gray_concrete
setblock 378 214 350 minecraft:polished_deepslate
fill 378 214 351 378 217 351 minecraft:gray_concrete
setblock 378 214 355 minecraft:polished_deepslate
fill 378 214 363 379 214 363 minecraft:gray_concrete
setblock 379 214 325 minecraft:light[level=13]
setblock 379 214 333 minecraft:light[level=13]
setblock 379 214 341 minecraft:light[level=13]
setblock 379 214 349 minecraft:light[level=13]
setblock 379 214 357 minecraft:light[level=13]
setblock 381 214 333 minecraft:light_blue_stained_glass
fill 383 214 333 384 214 333 minecraft:light_blue_stained_glass
fill 385 214 336 385 215 337 minecraft:white_wool
setblock 386 214 363 minecraft:yellow_concrete
setblock 387 214 325 minecraft:light[level=13]
setblock 387 214 333 minecraft:light[level=13]
setblock 387 214 341 minecraft:light[level=13]
fill 387 214 349 387 215 349 minecraft:gray_wool
setblock 387 214 357 minecraft:light[level=13]
setblock 390 214 323 minecraft:polished_deepslate
setblock 390 214 363 minecraft:polished_deepslate
fill 391 214 323 391 215 323 minecraft:gray_concrete
setblock 391 214 363 minecraft:gray_concrete
setblock 394 214 324 minecraft:polished_deepslate
setblock 395 214 323 minecraft:polished_deepslate
setblock 395 214 325 minecraft:light[level=13]
setblock 395 214 333 minecraft:light[level=13]
setblock 395 214 341 minecraft:light[level=13]
setblock 395 214 349 minecraft:light[level=13]
setblock 395 214 357 minecraft:light[level=13]
fill 396 214 323 397 214 323 minecraft:gray_concrete
fill 402 214 355 402 217 356 minecraft:black_concrete
setblock 403 214 325 minecraft:light[level=13]
setblock 403 214 333 minecraft:light[level=13]
setblock 403 214 341 minecraft:light[level=13]
setblock 403 214 349 minecraft:light[level=13]
fill 403 214 353 403 217 353 minecraft:black_concrete
fill 403 214 357 403 217 357 minecraft:black_concrete
fill 404 214 358 406 217 358 minecraft:black_concrete
setblock 405 214 323 minecraft:polished_deepslate
fill 406 214 323 406 217 323 minecraft:gray_concrete
fill 407 214 353 407 217 353 minecraft:black_concrete
fill 407 214 357 407 217 357 minecraft:black_concrete
setblock 408 214 325 minecraft:polished_deepslate
fill 408 214 355 408 217 355 minecraft:black_concrete
setblock 409 214 324 minecraft:polished_deepslate
fill 409 214 325 409 217 325 minecraft:gray_concrete
setblock 410 214 323 minecraft:polished_deepslate
fill 410 214 324 410 217 324 minecraft:gray_concrete
setblock 410 214 363 minecraft:polished_deepslate
fill 411 214 323 411 217 323 minecraft:gray_concrete
setblock 411 214 333 minecraft:light[level=13]
setblock 411 214 341 minecraft:light[level=13]
setblock 411 214 349 minecraft:light[level=13]
setblock 411 214 357 minecraft:light[level=13]
fill 411 214 363 411 217 363 minecraft:gray_concrete
setblock 412 214 326 minecraft:polished_deepslate
setblock 413 214 325 minecraft:polished_deepslate
fill 413 214 326 413 215 326 minecraft:gray_concrete
setblock 414 214 324 minecraft:polished_deepslate
fill 414 214 325 414 216 325 minecraft:gray_concrete
setblock 414 214 329 minecraft:polished_deepslate
setblock 414 214 330 minecraft:gray_concrete
setblock 414 214 363 minecraft:yellow_concrete
setblock 415 214 323 minecraft:polished_deepslate
fill 415 214 324 415 217 324 minecraft:gray_concrete
setblock 415 214 328 minecraft:polished_deepslate
fill 415 214 329 415 216 329 minecraft:gray_concrete
setblock 415 214 363 minecraft:polished_deepslate
fill 416 214 323 416 217 323 minecraft:gray_concrete
setblock 416 214 327 minecraft:polished_deepslate
fill 416 214 328 416 217 328 minecraft:gray_concrete
setblock 416 214 332 minecraft:polished_deepslate
setblock 416 214 333 minecraft:gray_concrete
setblock 416 214 352 minecraft:polished_deepslate
setblock 416 214 353 minecraft:gray_concrete
fill 416 214 363 416 216 363 minecraft:gray_concrete
setblock 417 214 326 minecraft:polished_deepslate
fill 417 214 327 417 217 327 minecraft:gray_concrete
setblock 417 214 331 minecraft:polished_deepslate
fill 417 214 332 417 217 332 minecraft:gray_concrete
setblock 417 214 346 minecraft:polished_deepslate
setblock 417 214 347 minecraft:gray_concrete
setblock 417 214 351 minecraft:polished_deepslate
fill 417 214 352 417 217 352 minecraft:gray_concrete
setblock 417 214 356 minecraft:polished_deepslate
fill 417 214 357 417 215 357 minecraft:gray_concrete
setblock 417 214 361 minecraft:polished_deepslate
fill 417 214 362 417 215 362 minecraft:gray_concrete
fill 376 215 338 376 243 338 minecraft:black_concrete
setblock 377 215 325 minecraft:polished_deepslate
setblock 377 215 326 minecraft:gray_concrete
setblock 377 215 330 minecraft:polished_deepslate
setblock 377 215 331 minecraft:gray_concrete
fill 377 215 346 377 215 349 minecraft:gray_concrete
setblock 377 215 350 minecraft:polished_deepslate
fill 377 215 351 377 218 351 minecraft:gray_concrete
setblock 377 215 355 minecraft:polished_deepslate
fill 377 215 356 377 218 356 minecraft:gray_concrete
setblock 377 215 360 minecraft:polished_deepslate
setblock 377 215 361 minecraft:gray_concrete
setblock 378 215 349 minecraft:polished_deepslate
fill 378 215 350 378 216 350 minecraft:gray_concrete
setblock 378 215 354 minecraft:polished_deepslate
setblock 384 215 333 minecraft:light_blue_stained_glass
setblock 385 215 363 minecraft:yellow_concrete
setblock 389 215 323 minecraft:polished_deepslate
setblock 390 215 323 minecraft:gray_concrete
fill 391 215 364 391 247 364 minecraft:black_concrete
setblock 392 215 364 minecraft:light_blue_stained_glass
setblock 394 215 323 minecraft:polished_deepslate
fill 402 215 354 402 217 354 minecraft:black_concrete
fill 402 215 357 402 217 357 minecraft:black_concrete
fill 403 215 358 403 217 358 minecraft:black_concrete
fill 404 215 352 406 217 352 minecraft:black_concrete
fill 405 215 323 405 218 323 minecraft:gray_concrete
setblock 407 215 325 minecraft:polished_deepslate
fill 407 215 358 407 217 358 minecraft:black_concrete
setblock 408 215 324 minecraft:polished_deepslate
fill 408 215 325 408 217 325 minecraft:gray_concrete
fill 408 215 354 408 217 354 minecraft:black_concrete
fill 408 215 356 408 217 356 minecraft:black_concrete
setblock 409 215 323 minecraft:polished_deepslate
fill 409 215 324 409 218 324 minecraft:gray_concrete
setblock 409 215 363 minecraft:polished_deepslate
fill 410 215 323 410 218 323 minecraft:gray_concrete
fill 410 215 363 410 218 363 minecraft:gray_concrete
setblock 411 215 326 minecraft:polished_deepslate
setblock 412 215 325 minecraft:polished_deepslate
setblock 412 215 326 minecraft:gray_concrete
setblock 413 215 324 minecraft:polished_deepslate
fill 413 215 325 413 217 325 minecraft:gray_concrete
setblock 413 215 363 minecraft:yellow_concrete
setblock 414 215 323 minecraft:polished_deepslate
fill 414 215 324 414 217 324 minecraft:gray_concrete
setblock 414 215 328 minecraft:polished_deepslate
setblock 414 215 329 minecraft:gray_concrete
setblock 414 215 363 minecraft:polished_deepslate
fill 415 215 323 415 218 323 minecraft:gray_concrete
setblock 415 215 327 minecraft:polished_deepslate
fill 415 215 328 415 216 328 minecraft:gray_concrete
fill 415 215 363 415 217 363 minecraft:gray_concrete
setblock 416 215 326 minecraft:polished_deepslate
fill 416 215 327 416 217 327 minecraft:gray_concrete
setblock 416 215 331 minecraft:polished_deepslate
setblock 416 215 332 minecraft:gray_concrete
setblock 417 215 325 minecraft:polished_deepslate
fill 417 215 326 417 218 326 minecraft:gray_concrete
setblock 417 215 330 minecraft:polished_deepslate
fill 417 215 331 417 218 331 minecraft:gray_concrete
setblock 417 215 350 minecraft:polished_deepslate
fill 417 215 351 417 218 351 minecraft:gray_concrete
setblock 417 215 355 minecraft:polished_deepslate
fill 417 215 356 417 218 356 minecraft:gray_concrete
setblock 377 216 329 minecraft:polished_deepslate
fill 377 216 347 377 216 348 minecraft:gray_concrete
setblock 377 216 349 minecraft:polished_deepslate
fill 377 216 350 377 219 350 minecraft:gray_concrete
setblock 377 216 354 minecraft:polished_deepslate
fill 377 216 355 377 219 355 minecraft:gray_concrete
setblock 377 216 359 minecraft:polished_deepslate
setblock 378 216 353 minecraft:polished_deepslate
fill 378 216 354 378 219 354 minecraft:gray_concrete
setblock 386 216 363 minecraft:yellow_concrete
fill 392 216 364 392 244 364 minecraft:black_concrete
fill 401 216 355 401 217 356 minecraft:black_concrete
fill 402 216 353 402 217 353 minecraft:black_concrete
fill 403 216 352 403 217 352 minecraft:black_concrete
fill 404 216 359 406 217 359 minecraft:black_concrete
setblock 407 216 324 minecraft:polished_deepslate
fill 407 216 352 407 217 352 minecraft:black_concrete
setblock 408 216 323 minecraft:polished_deepslate
fill 408 216 324 408 219 324 minecraft:gray_concrete
fill 408 216 353 408 217 353 minecraft:black_concrete
fill 408 216 357 408 217 357 minecraft:black_concrete
fill 409 216 323 409 219 323 minecraft:gray_concrete
fill 409 216 363 409 219 363 minecraft:gray_concrete
setblock 411 216 325 minecraft:polished_deepslate
setblock 411 216 326 minecraft:gray_concrete
setblock 412 216 324 minecraft:polished_deepslate
fill 412 216 325 412 217 325 minecraft:gray_concrete
setblock 412 216 363 minecraft:yellow_concrete
setblock 413 216 323 minecraft:polished_deepslate
fill 413 216 324 413 218 324 minecraft:gray_concrete
setblock 413 216 363 minecraft:polished_deepslate
fill 414 216 323 414 219 323 minecraft:gray_concrete
fill 414 216 363 414 217 363 minecraft:gray_concrete
setblock 415 216 326 minecraft:polished_deepslate
setblock 415 216 327 minecraft:gray_concrete
setblock 416 216 325 minecraft:polished_deepslate
fill 416 216 326 416 217 326 minecraft:gray_concrete
setblock 416 216 330 minecraft:polished_deepslate
fill 416 216 331 416 217 331 minecraft:gray_concrete
setblock 417 216 324 minecraft:polished_deepslate
fill 417 216 325 417 217 325 minecraft:gray_concrete
setblock 417 216 329 minecraft:polished_deepslate
fill 417 216 330 417 219 330 minecraft:gray_concrete
setblock 417 216 349 minecraft:polished_deepslate
setblock 417 216 350 minecraft:gray_concrete
setblock 417 216 354 minecraft:polished_deepslate
fill 417 216 355 417 219 355 minecraft:gray_concrete
setblock 376 217 341 minecraft:light_blue_stained_glass
fill 376 217 342 376 242 347 minecraft:black_concrete
setblock 377 217 348 minecraft:polished_deepslate
fill 377 217 349 377 220 349 minecraft:gray_concrete
setblock 377 217 353 minecraft:polished_deepslate
fill 377 217 354 377 220 354 minecraft:gray_concrete
setblock 377 217 358 minecraft:polished_deepslate
setblock 378 217 352 minecraft:polished_deepslate
fill 378 217 353 378 220 353 minecraft:gray_concrete
setblock 387 217 363 minecraft:ochre_froglight
fill 401 217 353 401 217 354 minecraft:black_concrete
setblock 401 217 357 minecraft:black_concrete
setblock 402 217 352 minecraft:black_concrete
setblock 402 217 358 minecraft:black_concrete
setblock 403 217 359 minecraft:black_concrete
fill 404 217 351 406 217 351 minecraft:black_concrete
setblock 407 217 323 minecraft:polished_deepslate
fill 407 217 324 407 220 324 minecraft:gray_concrete
setblock 407 217 359 minecraft:black_concrete
fill 408 217 323 408 220 323 minecraft:gray_concrete
setblock 408 217 352 minecraft:black_concrete
setblock 408 217 358 minecraft:black_concrete
fill 409 217 354 409 217 357 minecraft:black_concrete
setblock 410 217 325 minecraft:polished_deepslate
setblock 411 217 324 minecraft:polished_deepslate
fill 411 217 325 411 218 325 minecraft:gray_concrete
setblock 412 217 323 minecraft:polished_deepslate
fill 412 217 324 412 220 324 minecraft:gray_concrete
setblock 412 217 363 minecraft:polished_deepslate
fill 413 217 323 413 220 323 minecraft:gray_concrete
setblock 413 217 363 minecraft:ochre_froglight
setblock 416 217 329 minecraft:polished_deepslate
setblock 416 217 330 minecraft:gray_concrete
setblock 417 217 324 minecraft:gray_concrete
setblock 417 217 328 minecraft:polished_deepslate
fill 417 217 329 417 219 329 minecraft:gray_concrete
setblock 417 217 353 minecraft:polished_deepslate
fill 417 217 354 417 220 354 minecraft:gray_concrete
setblock 417 217 357 minecraft:gray_concrete
fill 376 218 341 376 246 341 minecraft:black_concrete
setblock 377 218 352 minecraft:polished_deepslate
fill 377 218 353 377 221 353 minecraft:gray_concrete
setblock 377 218 357 minecraft:polished_deepslate
fill 377 218 358 377 221 358 minecraft:gray_concrete
fill 378 218 352 378 221 352 minecraft:gray_concrete
setblock 379 218 325 minecraft:light[level=12]
setblock 379 218 332 minecraft:light[level=12]
setblock 379 218 339 minecraft:light[level=12]
setblock 379 218 346 minecraft:light[level=12]
setblock 379 218 353 minecraft:light[level=12]
setblock 379 218 360 minecraft:light[level=12]
setblock 386 218 325 minecraft:light[level=12]
setblock 386 218 332 minecraft:light[level=12]
setblock 386 218 339 minecraft:light[level=12]
setblock 386 218 346 minecraft:light[level=12]
setblock 386 218 353 minecraft:light[level=12]
setblock 386 218 360 minecraft:light[level=12]
setblock 388 218 363 minecraft:yellow_concrete
fill 390 218 336 391 219 337 minecraft:gray_wool
fill 391 218 335 391 219 335 minecraft:gray_wool
setblock 393 218 325 minecraft:light[level=12]
setblock 393 218 332 minecraft:light[level=12]
setblock 393 218 339 minecraft:light[level=12]
setblock 393 218 346 minecraft:light[level=12]
setblock 393 218 353 minecraft:light[level=12]
setblock 393 218 360 minecraft:light[level=12]
setblock 400 218 325 minecraft:light[level=12]
setblock 400 218 332 minecraft:light[level=12]
setblock 400 218 339 minecraft:light[level=12]
setblock 400 218 353 minecraft:light[level=12]
setblock 400 218 360 minecraft:light[level=12]
fill 403 218 355 403 220 355 minecraft:polished_deepslate
setblock 405 218 364 minecraft:light_blue_stained_glass
setblock 406 218 323 minecraft:polished_deepslate
fill 406 218 354 406 219 354 minecraft:polished_deepslate
fill 406 218 356 406 220 356 minecraft:polished_deepslate
fill 407 218 323 407 221 323 minecraft:gray_concrete
setblock 407 218 325 minecraft:light[level=12]
setblock 407 218 332 minecraft:light[level=12]
setblock 407 218 339 minecraft:light[level=12]
setblock 407 218 346 minecraft:light[level=12]
setblock 407 218 353 minecraft:light[level=12]
setblock 407 218 360 minecraft:light[level=12]
setblock 409 218 325 minecraft:polished_deepslate
setblock 410 218 324 minecraft:polished_deepslate
setblock 410 218 325 minecraft:gray_concrete
setblock 411 218 323 minecraft:polished_deepslate
fill 411 218 324 411 221 324 minecraft:gray_concrete
setblock 411 218 363 minecraft:polished_deepslate
fill 412 218 323 412 221 323 minecraft:gray_concrete
fill 412 218 363 413 220 363 minecraft:gray_concrete
setblock 414 218 325 minecraft:light[level=12]
setblock 414 218 332 minecraft:light[level=12]
setblock 414 218 339 minecraft:light[level=12]
setblock 414 218 346 minecraft:light[level=12]
setblock 414 218 353 minecraft:light[level=12]
setblock 414 218 360 minecraft:light[level=12]
setblock 414 218 363 minecraft:yellow_concrete
setblock 417 218 327 minecraft:polished_deepslate
fill 417 218 328 417 219 328 minecraft:gray_concrete
setblock 417 218 332 minecraft:polished_deepslate
setblock 417 218 352 minecraft:polished_deepslate
fill 417 218 353 417 221 353 minecraft:gray_concrete
setblock 417 218 357 minecraft:polished_deepslate
setblock 377 219 351 minecraft:polished_deepslate
fill 377 219 352 377 222 352 minecraft:gray_concrete
setblock 377 219 356 minecraft:polished_deepslate
fill 377 219 357 377 222 357 minecraft:gray_concrete
fill 377 219 359 377 220 359 minecraft:gray_concrete
setblock 378 219 355 minecraft:polished_deepslate
setblock 387 219 363 minecraft:yellow_concrete
setblock 405 219 323 minecraft:polished_deepslate
fill 405 219 364 405 246 364 minecraft:black_concrete
fill 406 219 323 406 221 324 minecraft:gray_concrete
fill 408 219 363 408 220 363 minecraft:gray_concrete
setblock 409 219 324 minecraft:polished_deepslate
setblock 410 219 323 minecraft:polished_deepslate
fill 410 219 324 410 222 324 minecraft:gray_concrete
setblock 410 219 363 minecraft:polished_deepslate
fill 411 219 323 411 222 323 minecraft:gray_concrete
fill 411 219 363 411 222 363 minecraft:gray_concrete
setblock 414 219 363 minecraft:gray_concrete
setblock 415 219 323 minecraft:polished_deepslate
setblock 415 219 363 minecraft:yellow_concrete
setblock 417 219 331 minecraft:polished_deepslate
fill 417 219 352 417 222 352 minecraft:gray_concrete
setblock 417 219 356 minecraft:polished_deepslate
fill 417 219 357 417 221 358 minecraft:gray_concrete
setblock 377 220 350 minecraft:polished_deepslate
fill 377 220 351 377 223 351 minecraft:gray_concrete
setblock 377 220 355 minecraft:polished_deepslate
fill 377 220 356 378 222 356 minecraft:gray_concrete
setblock 377 220 360 minecraft:polished_deepslate
setblock 378 220 354 minecraft:polished_deepslate
fill 378 220 355 378 223 355 minecraft:gray_concrete
setblock 386 220 363 minecraft:yellow_concrete
setblock 404 220 323 minecraft:polished_deepslate
fill 405 220 323 405 223 323 minecraft:gray_concrete
fill 407 220 363 407 221 363 minecraft:gray_concrete
setblock 408 220 324 minecraft:polished_deepslate
setblock 409 220 323 minecraft:polished_deepslate
fill 409 220 324 409 223 324 minecraft:gray_concrete
setblock 409 220 363 minecraft:polished_deepslate
fill 410 220 323 410 223 323 minecraft:gray_concrete
fill 410 220 363 410 223 363 minecraft:gray_concrete
setblock 414 220 323 minecraft:polished_deepslate
setblock 414 220 363 minecraft:yellow_concrete
setblock 417 220 330 minecraft:polished_deepslate
setblock 417 220 331 minecraft:gray_concrete
setblock 417 220 355 minecraft:polished_deepslate
fill 417 220 356 417 223 356 minecraft:gray_concrete
setblock 417 220 359 minecraft:gray_concrete
setblock 417 220 360 minecraft:polished_deepslate
setblock 418 220 324 minecraft:light_blue_stained_glass
setblock 377 221 349 minecraft:polished_deepslate
fill 377 221 350 377 224 350 minecraft:gray_concrete
setblock 377 221 354 minecraft:polished_deepslate
fill 377 221 355 377 224 355 minecraft:gray_concrete
setblock 377 221 359 minecraft:polished_deepslate
fill 377 221 360 377 224 360 minecraft:gray_concrete
setblock 378 221 353 minecraft:polished_deepslate
fill 378 221 354 378 224 354 minecraft:gray_concrete
setblock 378 221 357 minecraft:gray_concrete
setblock 385 221 363 minecraft:yellow_concrete
setblock 403 221 323 minecraft:polished_deepslate
fill 404 221 323 404 224 323 minecraft:gray_concrete
fill 405 221 324 405 222 324 minecraft:gray_concrete
fill 405 221 363 406 222 363 minecraft:gray_concrete
setblock 407 221 324 minecraft:polished_deepslate
setblock 408 221 323 minecraft:polished_deepslate
fill 408 221 324 408 224 324 minecraft:gray_concrete
setblock 408 221 362 minecraft:gray_concrete
setblock 408 221 363 minecraft:polished_deepslate
fill 409 221 323 409 224 323 minecraft:gray_concrete
setblock 409 221 362 minecraft:polished_deepslate
fill 409 221 363 409 224 363 minecraft:gray_concrete
fill 410 221 362 412 222 362 minecraft:gray_concrete
setblock 412 221 363 minecraft:gray_concrete
setblock 413 221 323 minecraft:polished_deepslate
setblock 413 221 363 minecraft:yellow_concrete
fill 414 221 323 414 224 323 minecraft:gray_concrete
fill 414 221 363 415 223 363 minecraft:gray_concrete
setblock 416 221 355 minecraft:polished_deepslate
fill 416 221 356 416 222 358 minecraft:gray_concrete
setblock 417 221 354 minecraft:polished_deepslate
fill 417 221 355 417 224 355 minecraft:gray_concrete
setblock 417 221 359 minecraft:polished_deepslate
fill 417 221 360 417 223 361 minecraft:gray_concrete
fill 418 221 324 418 246 324 minecraft:black_concrete
fill 377 222 349 377 225 349 minecraft:gray_concrete
setblock 377 222 353 minecraft:polished_deepslate
fill 377 222 354 377 225 354 minecraft:gray_concrete
setblock 377 222 358 minecraft:polished_deepslate
fill 377 222 359 378 224 359 minecraft:gray_concrete
fill 377 222 361 377 223 361 minecraft:gray_concrete
setblock 378 222 351 minecraft:gray_concrete
setblock 378 222 352 minecraft:polished_deepslate
fill 378 222 353 378 225 353 minecraft:gray_concrete
setblock 378 222 357 minecraft:polished_deepslate
fill 378 222 358 378 225 358 minecraft:gray_concrete
setblock 379 222 325 minecraft:light[level=13]
setblock 379 222 333 minecraft:light[level=13]
setblock 379 222 341 minecraft:light[level=13]
setblock 379 222 349 minecraft:light[level=13]
setblock 379 222 357 minecraft:light[level=13]
fill 384 222 363 385 223 363 minecraft:gray_concrete
fill 385 222 344 387 223 344 minecraft:white_wool
fill 386 222 343 386 223 343 minecraft:white_wool
fill 386 222 345 386 223 345 minecraft:white_wool
setblock 386 222 363 minecraft:ochre_froglight
setblock 387 222 325 minecraft:light[level=13]
setblock 387 222 333 minecraft:light[level=13]
setblock 387 222 341 minecraft:light[level=13]
setblock 387 222 349 minecraft:light[level=13]
setblock 387 222 357 minecraft:light[level=13]
setblock 387 222 363 minecraft:polished_deepslate
fill 388 222 363 389 223 363 minecraft:gray_concrete
setblock 395 222 325 minecraft:light[level=13]
setblock 395 222 333 minecraft:light[level=13]
setblock 395 222 341 minecraft:light[level=13]
setblock 395 222 349 minecraft:light[level=13]
setblock 395 222 357 minecraft:light[level=13]
setblock 402 222 323 minecraft:polished_deepslate
fill 403 222 323 403 225 323 minecraft:gray_concrete
setblock 403 222 325 minecraft:light[level=13]
setblock 403 222 333 minecraft:light[level=13]
setblock 403 222 341 minecraft:light[level=13]
setblock 403 222 349 minecraft:light[level=13]
setblock 403 222 357 minecraft:light[level=13]
fill 404 222 324 404 223 324 minecraft:gray_concrete
fill 404 222 363 404 224 363 minecraft:gray_concrete
fill 406 222 322 407 246 322 minecraft:black_concrete
setblock 406 222 323 minecraft:gray_concrete
setblock 406 222 324 minecraft:polished_deepslate
fill 406 222 362 407 222 362 minecraft:gray_concrete
setblock 407 222 323 minecraft:polished_deepslate
fill 407 222 324 407 224 325 minecraft:gray_concrete
setblock 407 222 363 minecraft:polished_deepslate
setblock 408 222 322 minecraft:light_blue_stained_glass
fill 408 222 323 408 225 323 minecraft:gray_concrete
fill 408 222 325 408 223 325 minecraft:gray_concrete
setblock 408 222 362 minecraft:polished_deepslate
fill 408 222 363 408 225 363 minecraft:gray_concrete
fill 409 222 362 409 225 362 minecraft:gray_concrete
setblock 411 222 324 minecraft:polished_deepslate
setblock 411 222 325 minecraft:light[level=13]
setblock 411 222 333 minecraft:light[level=13]
setblock 411 222 341 minecraft:light[level=13]
setblock 411 222 349 minecraft:light[level=13]
setblock 411 222 357 minecraft:light[level=13]
setblock 412 222 323 minecraft:polished_deepslate
setblock 412 222 363 minecraft:ochre_froglight
fill 413 222 323 413 225 323 minecraft:gray_concrete
setblock 413 222 362 minecraft:polished_deepslate
fill 413 222 363 413 225 363 minecraft:gray_concrete
setblock 416 222 354 minecraft:polished_deepslate
fill 416 222 355 416 225 355 minecraft:gray_concrete
setblock 416 222 359 minecraft:polished_deepslate
fill 416 222 360 416 225 360 minecraft:gray_concrete
setblock 416 222 363 minecraft:gray_concrete
fill 417 222 351 417 223 351 minecraft:gray_concrete
setblock 417 222 353 minecraft:polished_deepslate
fill 417 222 354 417 225 354 minecraft:gray_concrete
setblock 417 222 357 minecraft:gray_concrete
setblock 417 222 358 minecraft:polished_deepslate
fill 417 222 359 417 225 359 minecraft:gray_concrete
setblock 417 222 362 minecraft:gray_concrete
setblock 417 222 363 minecraft:polished_deepslate
fill 377 223 334 377 223 336 minecraft:gray_concrete
setblock 377 223 352 minecraft:polished_deepslate
fill 377 223 353 377 226 353 minecraft:gray_concrete
setblock 377 223 356 minecraft:gray_concrete
setblock 377 223 357 minecraft:polished_deepslate
fill 377 223 358 377 226 358 minecraft:gray_concrete
setblock 377 223 362 minecraft:polished_deepslate
setblock 378 223 351 minecraft:polished_deepslate
fill 378 223 352 378 226 352 minecraft:gray_concrete
setblock 378 223 356 minecraft:polished_deepslate
fill 378 223 357 379 225 357 minecraft:gray_concrete
setblock 378 223 360 minecraft:gray_concrete
setblock 379 223 354 minecraft:gray_concrete
setblock 379 223 355 minecraft:polished_deepslate
fill 379 223 356 379 226 356 minecraft:gray_concrete
setblock 381 223 363 minecraft:polished_deepslate
fill 382 223 363 383 225 363 minecraft:gray_concrete
fill 384 223 349 384 224 349 minecraft:light_blue_stained_glass
fill 384 223 362 386 223 362 minecraft:gray_concrete
setblock 386 223 363 minecraft:polished_deepslate
setblock 387 223 362 minecraft:polished_deepslate
setblock 387 223 363 minecraft:yellow_concrete
setblock 390 223 363 minecraft:gray_concrete
setblock 401 223 323 minecraft:polished_deepslate
fill 402 223 323 402 226 323 minecraft:gray_concrete
fill 402 223 363 403 225 363 minecraft:gray_concrete
fill 403 223 324 403 224 324 minecraft:gray_concrete
fill 404 223 362 406 223 362 minecraft:gray_concrete
setblock 405 223 324 minecraft:polished_deepslate
setblock 405 223 363 minecraft:gray_concrete
setblock 406 223 323 minecraft:polished_deepslate
fill 406 223 324 406 225 325 minecraft:gray_concrete
fill 406 223 361 407 223 361 minecraft:gray_concrete
setblock 406 223 363 minecraft:polished_deepslate
fill 407 223 323 407 226 323 minecraft:gray_concrete
setblock 407 223 362 minecraft:polished_deepslate
fill 407 223 363 407 226 363 minecraft:gray_concrete
fill 408 223 322 408 244 322 minecraft:black_concrete
setblock 408 223 361 minecraft:polished_deepslate
fill 408 223 362 408 226 362 minecraft:gray_concrete
fill 409 223 361 411 224 361 minecraft:gray_concrete
setblock 410 223 324 minecraft:polished_deepslate
fill 410 223 362 411 223 362 minecraft:gray_concrete
setblock 411 223 323 minecraft:polished_deepslate
fill 411 223 324 411 224 324 minecraft:gray_concrete
setblock 411 223 363 minecraft:polished_deepslate
fill 412 223 323 412 226 323 minecraft:gray_concrete
setblock 412 223 362 minecraft:polished_deepslate
fill 412 223 363 412 226 363 minecraft:gray_concrete
fill 413 223 362 414 225 362 minecraft:gray_concrete
fill 416 223 354 416 226 354 minecraft:gray_concrete
fill 416 223 356 416 223 357 minecraft:gray_concrete
setblock 416 223 358 minecraft:polished_deepslate
fill 416 223 359 416 226 359 minecraft:gray_concrete
fill 416 223 361 416 224 361 minecraft:gray_concrete
setblock 416 223 363 minecraft:polished_deepslate
setblock 417 223 333 minecraft:gray_concrete
setblock 417 223 352 minecraft:polished_deepslate
fill 417 223 353 417 226 353 minecraft:gray_concrete
setblock 417 223 357 minecraft:polished_deepslate
fill 417 223 358 417 226 358 minecraft:gray_concrete
setblock 417 223 362 minecraft:polished_deepslate
fill 417 223 363 417 226 363 minecraft:gray_concrete
fill 377 224 334 377 224 335 minecraft:gray_concrete
setblock 377 224 336 minecraft:polished_deepslate
fill 377 224 337 377 224 340 minecraft:gray_concrete
setblock 377 224 351 minecraft:polished_deepslate
fill 377 224 352 377 227 352 minecraft:gray_concrete
setblock 377 224 356 minecraft:polished_deepslate
fill 377 224 357 377 227 357 minecraft:gray_concrete
setblock 377 224 361 minecraft:polished_deepslate
fill 377 224 362 377 226 363 minecraft:gray_concrete
fill 378 224 351 378 225 351 minecraft:gray_concrete
setblock 378 224 355 minecraft:polished_deepslate
fill 378 224 356 378 227 356 minecraft:gray_concrete
setblock 378 224 360 minecraft:polished_deepslate
fill 378 224 363 379 224 363 minecraft:gray_concrete
setblock 379 224 325 minecraft:light[level=12]
setblock 379 224 332 minecraft:light[level=12]
setblock 379 224 339 minecraft:light[level=12]
setblock 379 224 346 minecraft:light[level=12]
setblock 379 224 353 minecraft:light[level=12]
setblock 379 224 354 minecraft:polished_deepslate
fill 379 224 355 379 227 355 minecraft:gray_concrete
setblock 379 224 358 minecraft:gray_concrete
setblock 379 224 360 minecraft:light[level=12]
fill 380 224 322 381 244 322 minecraft:black_concrete
setblock 380 224 363 minecraft:polished_deepslate
fill 381 224 363 381 227 363 minecraft:gray_concrete
setblock 382 224 322 minecraft:light_blue_stained_glass
fill 382 224 362 385 224 362 minecraft:gray_concrete
setblock 384 224 363 minecraft:gray_concrete
setblock 385 224 363 minecraft:polished_deepslate
fill 386 224 323 389 224 323 minecraft:gray_concrete
setblock 386 224 325 minecraft:light[level=12]
setblock 386 224 332 minecraft:light[level=12]
setblock 386 224 339 minecraft:light[level=12]
setblock 386 224 346 minecraft:light[level=12]
setblock 386 224 353 minecraft:light[level=12]
setblock 386 224 360 minecraft:light[level=12]
setblock 386 224 362 minecraft:polished_deepslate
fill 386 224 363 387 224 363 minecraft:gray_concrete
fill 387 224 362 388 226 362 minecraft:gray_concrete
setblock 388 224 363 minecraft:yellow_concrete
setblock 389 224 363 minecraft:gray_concrete
setblock 390 224 363 minecraft:polished_deepslate
setblock 393 224 325 minecraft:light[level=12]
setblock 393 224 332 minecraft:light[level=12]
setblock 393 224 339 minecraft:light[level=12]
setblock 393 224 346 minecraft:light[level=12]
setblock 393 224 353 minecraft:light[level=12]
setblock 393 224 360 minecraft:light[level=12]
setblock 400 224 323 minecraft:polished_deepslate
setblock 400 224 325 minecraft:light[level=12]
setblock 400 224 332 minecraft:light[level=12]
setblock 400 224 339 minecraft:light[level=12]
setblock 400 224 353 minecraft:light[level=12]
setblock 400 224 360 minecraft:light[level=12]
fill 401 224 323 401 227 323 minecraft:gray_concrete
fill 401 224 363 401 227 363 minecraft:gray_concrete
fill 402 224 324 402 225 324 minecraft:gray_concrete
fill 403 224 362 405 224 362 minecraft:gray_concrete
setblock 404 224 324 minecraft:polished_deepslate
setblock 405 224 323 minecraft:polished_deepslate
fill 405 224 324 405 226 325 minecraft:gray_concrete
fill 405 224 361 406 224 361 minecraft:gray_concrete
setblock 405 224 363 minecraft:polished_deepslate
fill 406 224 323 406 227 323 minecraft:gray_concrete
setblock 406 224 362 minecraft:polished_deepslate
fill 406 224 363 406 227 363 minecraft:gray_concrete
setblock 407 224 332 minecraft:light[level=12]
setblock 407 224 339 minecraft:light[level=12]
setblock 407 224 346 minecraft:light[level=12]
setblock 407 224 353 minecraft:light[level=12]
setblock 407 224 360 minecraft:light[level=12]
setblock 407 224 361 minecraft:polished_deepslate
fill 407 224 362 407 227 362 minecraft:gray_concrete
setblock 408 224 325 minecraft:polished_deepslate
fill 408 224 361 408 227 361 minecraft:gray_concrete
setblock 409 224 324 minecraft:polished_deepslate
setblock 410 224 323 minecraft:polished_deepslate
fill 410 224 324 410 226 324 minecraft:gray_concrete
setblock 410 224 362 minecraft:gray_concrete
setblock 410 224 363 minecraft:polished_deepslate
fill 411 224 323 411 227 323 minecraft:gray_concrete
setblock 411 224 362 minecraft:polished_deepslate
fill 411 224 363 411 227 363 minecraft:gray_concrete
setblock 412 224 361 minecraft:polished_deepslate
fill 412 224 362 412 227 362 minecraft:gray_concrete
setblock 414 224 325 minecraft:light[level=12]
setblock 414 224 332 minecraft:light[level=12]
setblock 414 224 339 minecraft:light[level=12]
setblock 414 224 346 minecraft:light[level=12]
setblock 414 224 353 minecraft:light[level=12]
setblock 414 224 360 minecraft:light[level=12]
setblock 414 224 363 minecraft:gray_concrete
setblock 415 224 358 minecraft:polished_deepslate
setblock 415 224 362 minecraft:gray_concrete
setblock 415 224 363 minecraft:polished_deepslate
setblock 416 224 356 minecraft:gray_concrete
setblock 416 224 357 minecraft:polished_deepslate
fill 416 224 358 416 227 358 minecraft:gray_concrete
setblock 416 224 362 minecraft:polished_deepslate
fill 416 224 363 416 227 363 minecraft:gray_concrete
fill 417 224 334 417 224 335 minecraft:gray_concrete
setblock 417 224 351 minecraft:polished_deepslate
fill 417 224 352 417 227 352 minecraft:gray_concrete
setblock 417 224 356 minecraft:polished_deepslate
fill 417 224 357 417 227 357 minecraft:gray_concrete
setblock 417 224 360 minecraft:gray_concrete
setblock 417 224 361 minecraft:polished_deepslate
fill 417 224 362 417 227 362 minecraft:gray_concrete
fill 376 225 352 376 246 352 minecraft:black_concrete
setblock 376 225 353 minecraft:light_blue_stained_glass
fill 376 225 354 376 247 354 minecraft:black_concrete
setblock 377 225 334 minecraft:gray_concrete
setblock 377 225 335 minecraft:polished_deepslate
fill 377 225 336 377 225 339 minecraft:gray_concrete
setblock 377 225 340 minecraft:polished_deepslate
fill 377 225 341 377 227 342 minecraft:gray_concrete
fill 377 225 348 377 226 348 minecraft:gray_concrete
setblock 377 225 350 minecraft:polished_deepslate
fill 377 225 351 377 228 351 minecraft:gray_concrete
setblock 377 225 355 minecraft:polished_deepslate
fill 377 225 356 377 228 356 minecraft:gray_concrete
setblock 377 225 359 minecraft:gray_concrete
setblock 377 225 360 minecraft:polished_deepslate
fill 377 225 361 378 227 361 minecraft:gray_concrete
fill 378 225 337 378 226 337 minecraft:gray_concrete
setblock 378 225 354 minecraft:polished_deepslate
fill 378 225 355 378 228 355 minecraft:gray_concrete
setblock 378 225 359 minecraft:polished_deepslate
fill 378 225 360 378 228 360 minecraft:gray_concrete
setblock 378 225 363 minecraft:gray_concrete
fill 379 225 354 379 226 354 minecraft:gray_concrete
setblock 379 225 358 minecraft:polished_deepslate
fill 379 225 359 379 228 359 minecraft:gray_concrete
setblock 379 225 363 minecraft:polished_deepslate
setblock 380 225 362 minecraft:polished_deepslate
fill 380 225 363 380 228 363 minecraft:gray_concrete
fill 381 225 362 384 225 362 minecraft:gray_concrete
fill 382 225 322 382 247 322 minecraft:black_concrete
fill 383 225 349 384 232 349 minecraft:black_concrete
fill 383 225 361 385 225 361 minecraft:gray_concrete
setblock 384 225 323 minecraft:polished_deepslate
setblock 384 225 363 minecraft:polished_deepslate
fill 385 225 323 388 225 323 minecraft:gray_concrete
setblock 385 225 362 minecraft:polished_deepslate
fill 385 225 363 386 225 363 minecraft:gray_concrete
setblock 386 225 361 minecraft:polished_deepslate
fill 386 225 362 386 228 362 minecraft:gray_concrete
setblock 387 225 363 minecraft:yellow_concrete
setblock 388 225 363 minecraft:gray_concrete
setblock 389 225 323 minecraft:polished_deepslate
setblock 389 225 362 minecraft:gray_concrete
setblock 389 225 363 minecraft:polished_deepslate
fill 390 225 363 390 228 363 minecraft:gray_concrete
setblock 399 225 323 minecraft:polished_deepslate
fill 400 225 323 400 228 323 minecraft:gray_concrete
fill 400 225 363 400 228 363 minecraft:gray_concrete
fill 401 225 362 404 225 362 minecraft:gray_concrete
setblock 403 225 324 minecraft:polished_deepslate
fill 403 225 361 405 225 361 minecraft:gray_concrete
setblock 404 225 323 minecraft:polished_deepslate
fill 404 225 324 404 227 325 minecraft:gray_concrete
setblock 404 225 363 minecraft:polished_deepslate
fill 405 225 323 405 228 323 minecraft:gray_concrete
setblock 405 225 362 minecraft:polished_deepslate
fill 405 225 363 405 228 363 minecraft:gray_concrete
setblock 406 225 360 minecraft:gray_concrete
setblock 406 225 361 minecraft:polished_deepslate
fill 406 225 362 406 228 362 minecraft:gray_concrete
setblock 407 225 324 minecraft:gray_concrete
setblock 407 225 325 minecraft:polished_deepslate
setblock 407 225 360 minecraft:polished_deepslate
fill 407 225 361 407 228 361 minecraft:gray_concrete
setblock 408 225 324 minecraft:polished_deepslate
fill 408 225 360 409 226 360 minecraft:gray_concrete
setblock 409 225 323 minecraft:polished_deepslate
fill 409 225 324 409 228 324 minecraft:gray_concrete
fill 409 225 361 410 225 361 minecraft:gray_concrete
setblock 409 225 363 minecraft:polished_deepslate
fill 410 225 323 410 228 323 minecraft:gray_concrete
setblock 410 225 362 minecraft:polished_deepslate
fill 410 225 363 410 228 363 minecraft:gray_concrete
setblock 411 225 361 minecraft:polished_deepslate
fill 411 225 362 411 228 362 minecraft:gray_concrete
fill 412 225 361 413 227 361 minecraft:gray_concrete
setblock 414 225 323 minecraft:polished_deepslate
setblock 414 225 363 minecraft:polished_deepslate
setblock 415 225 357 minecraft:polished_deepslate
fill 415 225 358 415 226 359 minecraft:gray_concrete
setblock 415 225 362 minecraft:polished_deepslate
fill 415 225 363 415 228 363 minecraft:gray_concrete
setblock 416 225 356 minecraft:polished_deepslate
fill 416 225 357 416 228 357 minecraft:gray_concrete
setblock 416 225 361 minecraft:polished_deepslate
fill 416 225 362 416 228 362 minecraft:gray_concrete
setblock 417 225 334 minecraft:gray_concrete
setblock 417 225 335 minecraft:polished_deepslate
fill 417 225 336 417 226 337 minecraft:gray_concrete
setblock 417 225 351 minecraft:gray_concrete
setblock 417 225 355 minecraft:polished_deepslate
fill 417 225 356 417 228 356 minecraft:gray_concrete
setblock 417 225 360 minecraft:polished_deepslate
fill 417 225 361 417 228 361 minecraft:gray_concrete
setblock 418 225 333 minecraft:light_blue_stained_glass
fill 376 226 353 376 227 353 minecraft:black_concrete
setblock 377 226 334 minecraft:polished_deepslate
fill 377 226 335 377 226 338 minecraft:gray_concrete
setblock 377 226 339 minecraft:polished_deepslate
fill 377 226 340 378 228 340 minecraft:gray_concrete
setblock 377 226 343 minecraft:gray_concrete
setblock 377 226 344 minecraft:polished_deepslate
fill 377 226 345 377 229 345 minecraft:gray_concrete
setblock 377 226 349 minecraft:polished_deepslate
fill 377 226 350 377 229 350 minecraft:gray_concrete
setblock 377 226 354 minecraft:polished_deepslate
fill 377 226 355 377 229 355 minecraft:gray_concrete
setblock 377 226 359 minecraft:polished_deepslate
fill 377 226 360 377 229 360 minecraft:gray_concrete
fill 378 226 336 378 227 336 minecraft:gray_concrete
setblock 378 226 338 minecraft:polished_deepslate
fill 378 226 339 378 229 339 minecraft:gray_concrete
fill 378 226 341 378 227 341 minecraft:gray_concrete
setblock 378 226 353 minecraft:polished_deepslate
fill 378 226 354 378 228 354 minecraft:gray_concrete
setblock 378 226 357 minecraft:gray_concrete
setblock 378 226 358 minecraft:polished_deepslate
fill 378 226 359 378 229 359 minecraft:gray_concrete
setblock 378 226 362 minecraft:gray_concrete
setblock 378 226 363 minecraft:polished_deepslate
setblock 379 226 357 minecraft:polished_deepslate
fill 379 226 358 379 228 358 minecraft:gray_concrete
setblock 379 226 362 minecraft:polished_deepslate
fill 379 226 363 379 229 363 minecraft:gray_concrete
fill 380 226 362 383 226 362 minecraft:gray_concrete
fill 382 226 361 384 226 361 minecraft:gray_concrete
setblock 382 226 363 minecraft:gray_concrete
setblock 383 226 323 minecraft:polished_deepslate
setblock 383 226 363 minecraft:polished_deepslate
fill 384 226 323 387 226 323 minecraft:gray_concrete
setblock 384 226 362 minecraft:polished_deepslate
fill 384 226 363 385 226 363 minecraft:gray_concrete
setblock 385 226 361 minecraft:polished_deepslate
fill 385 226 362 385 229 362 minecraft:gray_concrete
fill 386 226 361 386 227 361 minecraft:gray_concrete
setblock 386 226 363 minecraft:yellow_concrete
setblock 387 226 363 minecraft:gray_concrete
setblock 388 226 323 minecraft:polished_deepslate
setblock 388 226 363 minecraft:polished_deepslate
fill 389 226 323 389 227 323 minecraft:gray_concrete
fill 389 226 363 389 229 363 minecraft:gray_concrete
setblock 398 226 323 minecraft:polished_deepslate
fill 399 226 323 399 229 323 minecraft:gray_concrete
fill 399 226 363 399 229 363 minecraft:gray_concrete
fill 400 226 362 403 226 362 minecraft:gray_concrete
setblock 401 226 324 minecraft:gray_concrete
setblock 402 226 324 minecraft:polished_deepslate
fill 402 226 361 404 226 361 minecraft:gray_concrete
setblock 402 226 363 minecraft:gray_concrete
setblock 403 226 323 minecraft:polished_deepslate
fill 403 226 324 403 229 324 minecraft:gray_concrete
setblock 403 226 363 minecraft:polished_deepslate
fill 404 226 323 404 229 323 minecraft:gray_concrete
setblock 404 226 362 minecraft:polished_deepslate
fill 404 226 363 404 229 363 minecraft:gray_concrete
setblock 405 226 360 minecraft:gray_concrete
setblock 405 226 361 minecraft:polished_deepslate
fill 405 226 362 405 229 362 minecraft:gray_concrete
setblock 406 226 324 minecraft:gray_concrete
setblock 406 226 325 minecraft:polished_deepslate
setblock 406 226 360 minecraft:polished_deepslate
fill 406 226 361 406 229 361 minecraft:gray_concrete
setblock 407 226 324 minecraft:polished_deepslate
setblock 407 226 325 minecraft:gray_concrete
fill 407 226 360 407 228 360 minecraft:gray_concrete
setblock 408 226 323 minecraft:polished_deepslate
fill 408 226 324 408 229 324 minecraft:gray_concrete
setblock 408 226 363 minecraft:polished_deepslate
fill 409 226 323 409 229 323 minecraft:gray_concrete
setblock 409 226 361 minecraft:gray_concrete
setblock 409 226 362 minecraft:polished_deepslate
fill 409 226 363 409 229 363 minecraft:gray_concrete
setblock 410 226 361 minecraft:polished_deepslate
fill 410 226 362 410 229 362 minecraft:gray_concrete
fill 411 226 361 411 228 361 minecraft:gray_concrete
setblock 413 226 323 minecraft:polished_deepslate
setblock 413 226 362 minecraft:gray_concrete
setblock 413 226 363 minecraft:polished_deepslate
setblock 414 226 362 minecraft:polished_deepslate
fill 414 226 363 414 229 363 minecraft:gray_concrete
setblock 415 226 360 minecraft:gray_concrete
fill 415 226 362 415 229 362 minecraft:gray_concrete
setblock 416 226 355 minecraft:polished_deepslate
fill 416 226 356 416 228 356 minecraft:gray_concrete
setblock 416 226 360 minecraft:polished_deepslate
fill 416 226 361 416 229 361 minecraft:gray_concrete
setblock 417 226 338 minecraft:gray_concrete
setblock 417 226 354 minecraft:polished_deepslate
fill 417 226 355 417 229 355 minecraft:gray_concrete
setblock 417 226 359 minecraft:polished_deepslate
fill 417 226 360 417 229 360 minecraft:gray_concrete
fill 418 226 333 418 246 333 minecraft:black_concrete
setblock 418 226 336 minecraft:light_blue_stained_glass
fill 418 226 337 418 242 340 minecraft:black_concrete
fill 376 227 324 376 233 324 minecraft:black_concrete
setblock 376 227 325 minecraft:light_blue_stained_glass
fill 376 227 326 376 241 327 minecraft:black_concrete
fill 377 227 334 377 227 337 minecraft:gray_concrete
setblock 377 227 338 minecraft:polished_deepslate
fill 377 227 339 377 230 339 minecraft:gray_concrete
setblock 377 227 343 minecraft:polished_deepslate
fill 377 227 344 377 230 344 minecraft:gray_concrete
fill 377 227 346 377 227 347 minecraft:gray_concrete
setblock 377 227 348 minecraft:polished_deepslate
fill 377 227 349 377 230 349 minecraft:gray_concrete
setblock 377 227 353 minecraft:polished_deepslate
fill 377 227 354 377 230 354 minecraft:gray_concrete
setblock 377 227 358 minecraft:polished_deepslate
fill 377 227 359 377 230 359 minecraft:gray_concrete
setblock 377 227 362 minecraft:gray_concrete
setblock 377 227 363 minecraft:polished_deepslate
setblock 378 227 337 minecraft:polished_deepslate
fill 378 227 338 378 230 338 minecraft:gray_concrete
setblock 378 227 342 minecraft:polished_deepslate
setblock 378 227 352 minecraft:polished_deepslate
setblock 378 227 353 minecraft:gray_concrete
setblock 378 227 357 minecraft:polished_deepslate
fill 378 227 358 378 230 358 minecraft:gray_concrete
setblock 378 227 362 minecraft:polished_deepslate
fill 378 227 363 378 230 363 minecraft:gray_concrete
setblock 379 227 356 minecraft:polished_deepslate
fill 379 227 357 379 228 357 minecraft:gray_concrete
fill 379 227 362 382 227 362 minecraft:gray_concrete
setblock 380 227 364 minecraft:light_blue_stained_glass
fill 381 227 361 383 227 361 minecraft:gray_concrete
setblock 382 227 323 minecraft:polished_deepslate
setblock 382 227 363 minecraft:polished_deepslate
fill 383 227 323 386 227 323 minecraft:gray_concrete
fill 383 227 350 384 232 350 minecraft:black_concrete
setblock 383 227 362 minecraft:polished_deepslate
fill 383 227 363 384 229 363 minecraft:gray_concrete
setblock 384 227 361 minecraft:polished_deepslate
fill 384 227 362 384 230 362 minecraft:gray_concrete
fill 385 227 361 385 228 361 minecraft:gray_concrete
setblock 385 227 363 minecraft:ochre_froglight
setblock 386 227 363 minecraft:gray_concrete
setblock 387 227 323 minecraft:polished_deepslate
setblock 387 227 362 minecraft:gray_concrete
setblock 387 227 363 minecraft:polished_deepslate
fill 388 227 323 388 230 323 minecraft:gray_concrete
setblock 388 227 362 minecraft:polished_deepslate
fill 388 227 363 388 230 363 minecraft:gray_concrete
setblock 397 227 323 minecraft:polished_deepslate
fill 398 227 323 398 230 323 minecraft:gray_concrete
fill 398 227 363 398 230 363 minecraft:gray_concrete
setblock 400 227 324 minecraft:gray_concrete
fill 400 227 362 402 227 362 minecraft:gray_concrete
setblock 401 227 324 minecraft:polished_deepslate
setblock 402 227 323 minecraft:polished_deepslate
fill 402 227 324 402 230 324 minecraft:gray_concrete
fill 402 227 361 403 227 361 minecraft:gray_concrete
setblock 402 227 363 minecraft:polished_deepslate
fill 403 227 323 403 230 323 minecraft:gray_concrete
setblock 403 227 362 minecraft:polished_deepslate
fill 403 227 363 403 230 363 minecraft:gray_concrete
setblock 404 227 360 minecraft:gray_concrete
setblock 404 227 361 minecraft:polished_deepslate
fill 404 227 362 404 230 362 minecraft:gray_concrete
setblock 405 227 324 minecraft:gray_concrete
setblock 405 227 325 minecraft:polished_deepslate
setblock 405 227 360 minecraft:polished_deepslate
fill 405 227 361 405 230 361 minecraft:gray_concrete
setblock 406 227 324 minecraft:polished_deepslate
setblock 406 227 325 minecraft:gray_concrete
fill 406 227 360 406 228 360 minecraft:gray_concrete
setblock 407 227 323 minecraft:polished_deepslate
fill 407 227 324 407 230 324 minecraft:gray_concrete
setblock 407 227 363 minecraft:polished_deepslate
fill 408 227 323 408 230 323 minecraft:gray_concrete
setblock 408 227 360 minecraft:gray_concrete
setblock 408 227 362 minecraft:polished_deepslate
fill 408 227 363 408 230 363 minecraft:gray_concrete
setblock 409 227 361 minecraft:polished_deepslate
fill 409 227 362 409 230 362 minecraft:gray_concrete
fill 410 227 361 410 229 361 minecraft:gray_concrete
setblock 412 227 323 minecraft:polished_deepslate
setblock 412 227 363 minecraft:polished_deepslate
setblock 413 227 323 minecraft:gray_concrete
setblock 413 227 362 minecraft:polished_deepslate
fill 413 227 363 413 230 363 minecraft:gray_concrete
fill 414 227 362 414 230 362 minecraft:gray_concrete
setblock 415 227 359 minecraft:gray_concrete
setblock 416 227 355 minecraft:gray_concrete
setblock 416 227 359 minecraft:polished_deepslate
fill 416 227 360 416 230 360 minecraft:gray_concrete
setblock 417 227 337 minecraft:gray_concrete
setblock 417 227 338 minecraft:polished_deepslate
fill 417 227 339 417 230 339 minecraft:gray_concrete
setblock 417 227 353 minecraft:polished_deepslate
fill 417 227 354 417 230 354 minecraft:gray_concrete
setblock 417 227 358 minecraft:polished_deepslate
fill 417 227 359 417 230 359 minecraft:gray_concrete
setblock 417 227 363 minecraft:polished_deepslate
fill 418 227 336 418 234 336 minecraft:black_concrete
fill 376 228 325 376 247 325 minecraft:black_concrete
setblock 376 228 353 minecraft:light_blue_stained_glass
fill 377 228 322 377 246 322 minecraft:black_concrete
fill 377 228 335 377 228 336 minecraft:gray_concrete
setblock 377 228 337 minecraft:polished_deepslate
fill 377 228 338 377 231 338 minecraft:gray_concrete
setblock 377 228 341 minecraft:gray_concrete
setblock 377 228 342 minecraft:polished_deepslate
fill 377 228 343 378 230 343 minecraft:gray_concrete
setblock 377 228 346 minecraft:gray_concrete
setblock 377 228 347 minecraft:polished_deepslate
fill 377 228 348 377 231 348 minecraft:gray_concrete
setblock 377 228 352 minecraft:polished_deepslate
fill 377 228 353 377 230 353 minecraft:gray_concrete
setblock 377 228 357 minecraft:polished_deepslate
fill 377 228 358 377 231 358 minecraft:gray_concrete
setblock 377 228 361 minecraft:gray_concrete
setblock 377 228 362 minecraft:polished_deepslate
fill 377 228 363 377 231 363 minecraft:gray_concrete
setblock 378 228 322 minecraft:light_blue_stained_glass
setblock 378 228 336 minecraft:polished_deepslate
fill 378 228 337 378 231 337 minecraft:gray_concrete
setblock 378 228 341 minecraft:polished_deepslate
fill 378 228 342 378 231 342 minecraft:gray_concrete
fill 378 228 344 378 229 344 minecraft:gray_concrete
setblock 378 228 356 minecraft:polished_deepslate
fill 378 228 357 378 230 357 minecraft:gray_concrete
setblock 378 228 361 minecraft:polished_deepslate
fill 378 228 362 381 228 362 minecraft:gray_concrete
fill 379 228 338 379 228 339 minecraft:gray_concrete
setblock 379 228 340 minecraft:polished_deepslate
fill 379 228 341 379 231 341 minecraft:gray_concrete
fill 380 228 364 380 243 364 minecraft:black_concrete
fill 381 228 361 382 228 361 minecraft:gray_concrete
setblock 381 228 363 minecraft:polished_deepslate
fill 382 228 323 385 228 323 minecraft:gray_concrete
fill 382 228 349 382 232 349 minecraft:black_concrete
setblock 382 228 362 minecraft:polished_deepslate
fill 382 228 363 382 231 363 minecraft:gray_concrete
fill 383 228 348 384 232 348 minecraft:black_concrete
setblock 383 228 361 minecraft:polished_deepslate
fill 383 228 362 383 231 362 minecraft:gray_concrete
setblock 384 228 361 minecraft:gray_concrete
fill 385 228 349 385 232 349 minecraft:black_concrete
setblock 385 228 363 minecraft:gray_concrete
setblock 386 228 323 minecraft:polished_deepslate
setblock 386 228 363 minecraft:polished_deepslate
fill 387 228 323 387 231 323 minecraft:gray_concrete
setblock 387 228 362 minecraft:polished_deepslate
fill 387 228 363 387 231 363 minecraft:gray_concrete
fill 397 228 323 397 231 323 minecraft:gray_concrete
fill 397 228 363 397 231 363 minecraft:gray_concrete
fill 399 228 362 401 228 362 minecraft:gray_concrete
setblock 400 228 324 minecraft:polished_deepslate
setblock 401 228 323 minecraft:polished_deepslate
fill 401 228 324 401 231 324 minecraft:gray_concrete
fill 401 228 361 402 228 361 minecraft:gray_concrete
setblock 401 228 363 minecraft:polished_deepslate
fill 402 228 323 402 231 323 minecraft:gray_concrete
setblock 402 228 362 minecraft:polished_deepslate
fill 402 228 363 402 231 363 minecraft:gray_concrete
setblock 403 228 361 minecraft:polished_deepslate
fill 403 228 362 403 231 362 minecraft:gray_concrete
setblock 404 228 324 minecraft:gray_concrete
setblock 404 228 325 minecraft:polished_deepslate
fill 404 228 361 404 231 361 minecraft:gray_concrete
setblock 405 228 324 minecraft:polished_deepslate
setblock 405 228 325 minecraft:gray_concrete
setblock 405 228 360 minecraft:gray_concrete
setblock 406 228 323 minecraft:polished_deepslate
fill 406 228 324 406 231 324 minecraft:gray_concrete
setblock 406 228 363 minecraft:polished_deepslate
setblock 406 228 364 minecraft:light_blue_stained_glass
fill 407 228 323 407 231 323 minecraft:gray_concrete
setblock 407 228 362 minecraft:polished_deepslate
fill 407 228 363 407 231 363 minecraft:gray_concrete
fill 407 228 364 407 238 364 minecraft:black_concrete
setblock 408 228 361 minecraft:polished_deepslate
fill 408 228 362 408 231 362 minecraft:gray_concrete
fill 409 228 361 409 230 361 minecraft:gray_concrete
setblock 411 228 323 minecraft:polished_deepslate
setblock 411 228 363 minecraft:polished_deepslate
fill 412 228 323 412 229 323 minecraft:gray_concrete
setblock 412 228 361 minecraft:gray_concrete
setblock 412 228 362 minecraft:polished_deepslate
fill 412 228 363 412 231 363 minecraft:gray_concrete
fill 413 228 362 413 231 362 minecraft:gray_concrete
setblock 416 228 358 minecraft:polished_deepslate
fill 416 228 359 416 231 359 minecraft:gray_concrete
setblock 416 228 363 minecraft:polished_deepslate
setblock 417 228 338 minecraft:gray_concrete
fill 417 228 340 417 229 340 minecraft:gray_concrete
fill 417 228 353 417 229 353 minecraft:gray_concrete
setblock 417 228 357 minecraft:polished_deepslate
fill 417 228 358 417 231 358 minecraft:gray_concrete
setblock 417 228 362 minecraft:polished_deepslate
fill 417 228 363 417 231 363 minecraft:gray_concrete
setblock 376 229 353 minecraft:black_concrete
setblock 377 229 335 minecraft:gray_concrete
setblock 377 229 336 minecraft:polished_deepslate
fill 377 229 337 377 232 337 minecraft:gray_concrete
setblock 377 229 340 minecraft:gray_concrete
setblock 377 229 341 minecraft:polished_deepslate
fill 377 229 342 377 232 342 minecraft:gray_concrete
setblock 377 229 346 minecraft:polished_deepslate
fill 377 229 347 377 232 347 minecraft:gray_concrete
setblock 377 229 351 minecraft:polished_deepslate
fill 377 229 352 377 230 352 minecraft:gray_concrete
setblock 377 229 356 minecraft:polished_deepslate
fill 377 229 357 377 232 357 minecraft:gray_concrete
setblock 377 229 361 minecraft:polished_deepslate
fill 377 229 362 380 229 362 minecraft:gray_concrete
fill 378 229 322 378 246 322 minecraft:black_concrete
setblock 378 229 336 minecraft:gray_concrete
setblock 378 229 340 minecraft:polished_deepslate
fill 378 229 341 378 232 341 minecraft:gray_concrete
setblock 378 229 345 minecraft:polished_deepslate
setblock 378 229 355 minecraft:polished_deepslate
setblock 378 229 356 minecraft:gray_concrete
setblock 378 229 360 minecraft:polished_deepslate
fill 378 229 361 378 232 361 minecraft:gray_concrete
setblock 379 229 338 minecraft:gray_concrete
setblock 379 229 339 minecraft:polished_deepslate
fill 379 229 340 379 232 340 minecraft:gray_concrete
fill 379 229 342 379 230 342 minecraft:gray_concrete
setblock 380 229 363 minecraft:polished_deepslate
fill 381 229 323 384 229 323 minecraft:gray_concrete
setblock 381 229 362 minecraft:polished_deepslate
fill 381 229 363 381 232 363 minecraft:gray_concrete
fill 382 229 348 382 232 348 minecraft:black_concrete
fill 382 229 350 382 232 350 minecraft:black_concrete
setblock 382 229 361 minecraft:polished_deepslate
fill 382 229 362 382 232 362 minecraft:gray_concrete
fill 383 229 351 384 232 351 minecraft:black_concrete
setblock 383 229 361 minecraft:gray_concrete
setblock 385 229 323 minecraft:polished_deepslate
fill 385 229 348 385 232 348 minecraft:black_concrete
fill 385 229 350 385 232 350 minecraft:black_concrete
setblock 385 229 363 minecraft:polished_deepslate
fill 386 229 323 386 232 323 minecraft:gray_concrete
setblock 386 229 362 minecraft:polished_deepslate
fill 386 229 363 386 232 363 minecraft:gray_concrete
setblock 387 229 362 minecraft:gray_concrete
fill 394 229 342 395 229 344 minecraft:light_blue_concrete
fill 395 229 341 401 229 341 minecraft:light_blue_concrete
fill 395 229 345 399 230 345 minecraft:light_blue_concrete
fill 396 229 323 396 232 323 minecraft:gray_concrete
fill 396 229 346 398 229 346 minecraft:light_blue_concrete
setblock 396 229 364 minecraft:light_blue_stained_glass
fill 398 229 347 402 229 347 minecraft:light_blue_concrete
setblock 399 229 324 minecraft:polished_deepslate
fill 399 229 342 400 229 344 minecraft:light_blue_concrete
fill 399 229 362 400 229 362 minecraft:gray_concrete
setblock 400 229 323 minecraft:polished_deepslate
fill 400 229 324 400 232 324 minecraft:gray_concrete
setblock 400 229 348 minecraft:light_blue_concrete
setblock 400 229 363 minecraft:polished_deepslate
fill 401 229 323 401 232 323 minecraft:gray_concrete
fill 401 229 342 402 230 342 minecraft:light_blue_concrete
setblock 401 229 361 minecraft:gray_concrete
setblock 401 229 362 minecraft:polished_deepslate
fill 401 229 363 401 232 363 minecraft:gray_concrete
fill 402 229 343 403 229 343 minecraft:light_blue_concrete
fill 402 229 345 403 229 346 minecraft:light_blue_concrete
setblock 402 229 361 minecraft:polished_deepslate
fill 402 229 362 402 232 362 minecraft:gray_concrete
fill 403 229 344 403 230 344 minecraft:light_blue_concrete
fill 403 229 361 403 232 361 minecraft:gray_concrete
setblock 404 229 324 minecraft:polished_deepslate
setblock 405 229 323 minecraft:polished_deepslate
fill 405 229 324 405 232 324 minecraft:gray_concrete
setblock 405 229 363 minecraft:polished_deepslate
fill 406 229 323 406 232 323 minecraft:gray_concrete
setblock 406 229 362 minecraft:polished_deepslate
fill 406 229 363 406 232 363 minecraft:gray_concrete
fill 406 229 364 406 243 364 minecraft:black_concrete
setblock 407 229 361 minecraft:polished_deepslate
fill 407 229 362 407 232 362 minecraft:gray_concrete
fill 408 229 361 408 231 361 minecraft:gray_concrete
setblock 410 229 323 minecraft:polished_deepslate
setblock 410 229 363 minecraft:polished_deepslate
fill 411 229 323 411 231 323 minecraft:gray_concrete
setblock 411 229 362 minecraft:polished_deepslate
fill 411 229 363 411 232 363 minecraft:gray_concrete
fill 412 229 362 412 232 362 minecraft:gray_concrete
setblock 415 229 363 minecraft:polished_deepslate
setblock 416 229 357 minecraft:polished_deepslate
fill 416 229 358 416 231 358 minecraft:gray_concrete
setblock 416 229 362 minecraft:polished_deepslate
fill 416 229 363 416 232 363 minecraft:gray_concrete
setblock 417 229 341 minecraft:polished_deepslate
setblock 417 229 356 minecraft:polished_deepslate
fill 417 229 357 417 232 357 minecraft:gray_concrete
setblock 417 229 361 minecraft:polished_deepslate
fill 417 229 362 417 232 362 minecraft:gray_concrete
setblock 376 230 330 minecraft:light_blue_stained_glass
fill 376 230 331 376 246 331 minecraft:black_concrete
setblock 376 230 353 minecraft:light_blue_stained_glass
fill 377 230 336 377 232 336 minecraft:gray_concrete
setblock 377 230 340 minecraft:polished_deepslate
fill 377 230 341 377 232 341 minecraft:gray_concrete
setblock 377 230 345 minecraft:polished_deepslate
fill 377 230 346 377 232 346 minecraft:gray_concrete
setblock 377 230 355 minecraft:polished_deepslate
fill 377 230 356 377 232 356 minecraft:gray_concrete
setblock 377 230 360 minecraft:polished_deepslate
fill 377 230 361 377 232 362 minecraft:gray_concrete
setblock 378 230 339 minecraft:polished_deepslate
fill 378 230 340 378 232 340 minecraft:gray_concrete
setblock 378 230 344 minecraft:polished_deepslate
fill 378 230 345 378 232 345 minecraft:gray_concrete
setblock 378 230 359 minecraft:polished_deepslate
fill 378 230 360 378 232 360 minecraft:gray_concrete
fill 378 230 362 379 230 362 minecraft:gray_concrete
setblock 379 230 325 minecraft:light[level=13]
setblock 379 230 332 minecraft:light[level=12]
setblock 379 230 333 minecraft:light[level=13]
setblock 379 230 338 minecraft:polished_deepslate
fill 379 230 339 379 232 339 minecraft:gray_concrete
setblock 379 230 343 minecraft:polished_deepslate
setblock 379 230 346 minecraft:light[level=12]
setblock 379 230 349 minecraft:light[level=13]
setblock 379 230 353 minecraft:light[level=12]
setblock 379 230 357 minecraft:light[level=13]
setblock 379 230 360 minecraft:light[level=12]
setblock 379 230 363 minecraft:polished_deepslate
setblock 380 230 362 minecraft:polished_deepslate
fill 380 230 363 380 232 363 minecraft:gray_concrete
fill 381 230 323 383 230 323 minecraft:gray_concrete
fill 381 230 362 381 232 362 minecraft:gray_concrete
fill 382 230 351 382 232 351 minecraft:black_concrete
fill 383 230 347 384 232 347 minecraft:black_concrete
setblock 383 230 363 minecraft:gray_concrete
setblock 384 230 323 minecraft:polished_deepslate
setblock 384 230 363 minecraft:polished_deepslate
fill 385 230 323 385 232 323 minecraft:gray_concrete
fill 385 230 351 385 232 351 minecraft:black_concrete
setblock 385 230 362 minecraft:polished_deepslate
fill 385 230 363 385 232 363 minecraft:gray_concrete
setblock 386 230 325 minecraft:light[level=12]
setblock 386 230 332 minecraft:light[level=12]
setblock 386 230 339 minecraft:light[level=12]
setblock 386 230 346 minecraft:light[level=12]
setblock 386 230 353 minecraft:light[level=12]
setblock 386 230 360 minecraft:light[level=12]
setblock 386 230 362 minecraft:gray_concrete
setblock 387 230 325 minecraft:light[level=13]
setblock 387 230 333 minecraft:light[level=13]
setblock 387 230 341 minecraft:light[level=13]
setblock 387 230 349 minecraft:light[level=13]
setblock 387 230 357 minecraft:light[level=13]
setblock 393 230 325 minecraft:light[level=12]
setblock 393 230 332 minecraft:light[level=12]
setblock 393 230 339 minecraft:light[level=12]
setblock 393 230 346 minecraft:light[level=12]
setblock 393 230 353 minecraft:light[level=12]
setblock 393 230 360 minecraft:light[level=12]
setblock 395 230 325 minecraft:light[level=13]
setblock 395 230 333 minecraft:light[level=13]
fill 395 230 341 395 230 344 minecraft:light_blue_concrete
setblock 395 230 349 minecraft:light[level=13]
setblock 395 230 357 minecraft:light[level=13]
fill 396 230 341 399 230 341 minecraft:light_blue_concrete
fill 396 230 363 396 232 363 minecraft:gray_concrete
fill 396 230 364 396 246 364 minecraft:black_concrete
setblock 398 230 346 minecraft:light_blue_concrete
setblock 399 230 323 minecraft:polished_deepslate
fill 399 230 324 399 232 324 minecraft:gray_concrete
fill 399 230 342 399 231 344 minecraft:light_blue_concrete
fill 399 230 347 401 230 347 minecraft:light_blue_concrete
setblock 399 230 362 minecraft:gray_concrete
setblock 399 230 363 minecraft:polished_deepslate
fill 400 230 323 400 232 323 minecraft:gray_concrete
setblock 400 230 325 minecraft:light[level=12]
setblock 400 230 332 minecraft:light[level=12]
setblock 400 230 339 minecraft:light[level=12]
fill 400 230 342 400 231 342 minecraft:light_blue_concrete
fill 400 230 343 400 232 344 minecraft:polished_deepslate
setblock 400 230 353 minecraft:light[level=12]
setblock 400 230 360 minecraft:light[level=12]
setblock 400 230 362 minecraft:polished_deepslate
fill 400 230 363 400 232 363 minecraft:gray_concrete
setblock 401 230 361 minecraft:polished_deepslate
fill 401 230 362 401 232 362 minecraft:gray_concrete
fill 402 230 343 402 231 343 minecraft:light_blue_concrete
fill 402 230 345 402 231 346 minecraft:light_blue_concrete
fill 402 230 361 402 232 361 minecraft:gray_concrete
setblock 403 230 324 minecraft:polished_deepslate
setblock 403 230 325 minecraft:light[level=13]
setblock 403 230 333 minecraft:light[level=13]
setblock 403 230 341 minecraft:light[level=13]
setblock 403 230 345 minecraft:light_blue_concrete
setblock 403 230 349 minecraft:light[level=13]
setblock 403 230 357 minecraft:light[level=13]
setblock 404 230 323 minecraft:polished_deepslate
fill 404 230 324 404 232 324 minecraft:gray_concrete
setblock 404 230 363 minecraft:polished_deepslate
fill 405 230 323 405 232 323 minecraft:gray_concrete
setblock 405 230 362 minecraft:polished_deepslate
fill 405 230 363 405 232 363 minecraft:gray_concrete
setblock 406 230 361 minecraft:polished_deepslate
fill 406 230 362 406 232 362 minecraft:gray_concrete
setblock 407 230 325 minecraft:light[level=12]
setblock 407 230 332 minecraft:light[level=12]
setblock 407 230 339 minecraft:light[level=12]
setblock 407 230 346 minecraft:light[level=12]
setblock 407 230 353 minecraft:light[level=12]
setblock 407 230 360 minecraft:light[level=12]
fill 407 230 361 407 232 361 minecraft:gray_concrete
setblock 409 230 323 minecraft:polished_deepslate
setblock 409 230 363 minecraft:polished_deepslate
fill 410 230 323 410 232 323 minecraft:gray_concrete
setblock 410 230 362 minecraft:polished_deepslate
fill 410 230 363 410 232 363 minecraft:gray_concrete
setblock 411 230 325 minecraft:light[level=13]
setblock 411 230 333 minecraft:light[level=13]
setblock 411 230 341 minecraft:light[level=13]
setblock 411 230 349 minecraft:light[level=13]
setblock 411 230 357 minecraft:light[level=13]
fill 411 230 362 411 232 362 minecraft:gray_concrete
setblock 414 230 325 minecraft:light[level=12]
setblock 414 230 332 minecraft:light[level=12]
setblock 414 230 339 minecraft:light[level=12]
setblock 414 230 346 minecraft:light[level=12]
setblock 414 230 353 minecraft:light[level=12]
setblock 414 230 360 minecraft:light[level=12]
setblock 414 230 363 minecraft:polished_deepslate
setblock 415 230 362 minecraft:polished_deepslate
fill 415 230 363 415 232 363 minecraft:gray_concrete
setblock 416 230 357 minecraft:gray_concrete
setblock 416 230 361 minecraft:polished_deepslate
fill 416 230 362 416 232 362 minecraft:gray_concrete
setblock 417 230 340 minecraft:polished_deepslate
fill 417 230 341 417 231 343 minecraft:gray_concrete
setblock 417 230 355 minecraft:polished_deepslate
fill 417 230 356 417 232 356 minecraft:gray_concrete
setblock 417 230 360 minecraft:polished_deepslate
fill 417 230 361 417 232 361 minecraft:gray_concrete
fill 376 231 330 376 246 330 minecraft:black_concrete
fill 376 231 353 376 242 353 minecraft:black_concrete
setblock 377 231 339 minecraft:polished_deepslate
fill 377 231 340 377 232 340 minecraft:gray_concrete
setblock 377 231 343 minecraft:gray_concrete
setblock 377 231 344 minecraft:polished_deepslate
fill 377 231 345 377 232 345 minecraft:gray_concrete
setblock 377 231 349 minecraft:polished_deepslate
fill 377 231 350 377 232 350 minecraft:gray_concrete
setblock 377 231 354 minecraft:polished_deepslate
fill 377 231 355 377 232 355 minecraft:gray_concrete
setblock 377 231 359 minecraft:polished_deepslate
fill 377 231 360 377 232 360 minecraft:gray_concrete
setblock 378 231 338 minecraft:polished_deepslate
fill 378 231 339 378 232 339 minecraft:gray_concrete
setblock 378 231 343 minecraft:polished_deepslate
fill 378 231 344 379 232 344 minecraft:gray_concrete
fill 378 231 346 378 232 346 minecraft:gray_concrete
setblock 378 231 358 minecraft:polished_deepslate
setblock 378 231 359 minecraft:gray_concrete
setblock 378 231 362 minecraft:gray_concrete
setblock 378 231 363 minecraft:polished_deepslate
fill 379 231 338 379 232 338 minecraft:gray_concrete
setblock 379 231 342 minecraft:polished_deepslate
fill 379 231 343 379 232 343 minecraft:gray_concrete
setblock 379 231 362 minecraft:polished_deepslate
fill 379 231 363 379 232 363 minecraft:gray_concrete
fill 380 231 323 382 231 323 minecraft:gray_concrete
fill 380 231 362 380 232 362 minecraft:gray_concrete
fill 381 231 348 381 232 350 minecraft:black_concrete
fill 382 231 347 382 232 347 minecraft:black_concrete
setblock 383 231 323 minecraft:polished_deepslate
fill 383 231 352 384 232 352 minecraft:black_concrete
setblock 383 231 363 minecraft:polished_deepslate
fill 384 231 323 384 232 323 minecraft:gray_concrete
setblock 384 231 362 minecraft:polished_deepslate
fill 384 231 363 384 232 363 minecraft:gray_concrete
fill 385 231 347 385 232 347 minecraft:black_concrete
setblock 385 231 362 minecraft:gray_concrete
fill 386 231 348 386 232 350 minecraft:black_concrete
fill 395 231 323 395 232 323 minecraft:gray_concrete
fill 395 231 342 395 231 344 minecraft:light_blue_concrete
fill 396 231 345 398 231 345 minecraft:light_blue_concrete
fill 397 231 341 398 231 341 minecraft:light_blue_concrete
setblock 398 231 323 minecraft:polished_deepslate
fill 398 231 324 398 232 324 minecraft:gray_concrete
setblock 398 231 362 minecraft:gray_concrete
setblock 398 231 363 minecraft:polished_deepslate
fill 399 231 323 399 232 323 minecraft:gray_concrete
fill 399 231 345 399 232 345 minecraft:polished_deepslate
setblock 399 231 362 minecraft:polished_deepslate
fill 399 231 363 399 232 363 minecraft:gray_concrete
fill 400 231 362 400 232 362 minecraft:gray_concrete
fill 401 231 361 401 232 361 minecraft:gray_concrete
setblock 402 231 324 minecraft:polished_deepslate
setblock 403 231 323 minecraft:polished_deepslate
fill 403 231 324 403 232 324 minecraft:gray_concrete
setblock 403 231 363 minecraft:polished_deepslate
fill 404 231 323 404 232 323 minecraft:gray_concrete
setblock 404 231 362 minecraft:polished_deepslate
fill 404 231 363 404 232 363 minecraft:gray_concrete
setblock 405 231 361 minecraft:polished_deepslate
fill 405 231 362 405 232 362 minecraft:gray_concrete
fill 406 231 361 406 232 361 minecraft:gray_concrete
setblock 407 231 324 minecraft:polished_deepslate
setblock 408 231 323 minecraft:polished_deepslate
setblock 408 231 363 minecraft:polished_deepslate
fill 409 231 323 409 232 323 minecraft:gray_concrete
setblock 409 231 362 minecraft:polished_deepslate
fill 409 231 363 409 232 363 minecraft:gray_concrete
fill 410 231 362 410 232 362 minecraft:gray_concrete
setblock 413 231 363 minecraft:polished_deepslate
setblock 414 231 362 minecraft:polished_deepslate
fill 414 231 363 414 232 363 minecraft:gray_concrete
fill 415 231 362 415 232 362 minecraft:gray_concrete
setblock 416 231 360 minecraft:polished_deepslate
fill 416 231 361 416 232 361 minecraft:gray_concrete
setblock 417 231 339 minecraft:polished_deepslate
fill 417 231 340 417 232 340 minecraft:gray_concrete
setblock 417 231 344 minecraft:polished_deepslate
fill 417 231 345 417 232 345 minecraft:gray_concrete
setblock 417 231 354 minecraft:polished_deepslate
fill 417 231 355 417 232 355 minecraft:gray_concrete
setblock 417 231 359 minecraft:polished_deepslate
fill 417 231 360 417 232 360 minecraft:gray_concrete
setblock 377 232 338 minecraft:polished_deepslate
setblock 377 232 339 minecraft:gray_concrete
setblock 377 232 343 minecraft:polished_deepslate
setblock 377 232 344 minecraft:gray_concrete
setblock 377 232 348 minecraft:polished_deepslate
setblock 377 232 349 minecraft:gray_concrete
setblock 377 232 351 minecraft:gray_concrete
setblock 377 232 358 minecraft:polished_deepslate
setblock 377 232 359 minecraft:gray_concrete
setblock 377 232 363 minecraft:polished_deepslate
setblock 378 232 337 minecraft:polished_deepslate
setblock 378 232 338 minecraft:gray_concrete
setblock 378 232 342 minecraft:polished_deepslate
setblock 378 232 343 minecraft:gray_concrete
setblock 378 232 347 minecraft:polished_deepslate
setblock 378 232 362 minecraft:polished_deepslate
setblock 378 232 363 minecraft:gray_concrete
fill 379 232 323 381 232 323 minecraft:gray_concrete
setblock 379 232 341 minecraft:polished_deepslate
fill 379 232 342 380 232 342 minecraft:gray_concrete
setblock 379 232 345 minecraft:gray_concrete
setblock 379 232 362 minecraft:gray_concrete
setblock 380 232 341 minecraft:gray_concrete
setblock 381 232 347 minecraft:black_concrete
setblock 381 232 351 minecraft:black_concrete
setblock 382 232 323 minecraft:polished_deepslate
setblock 382 232 352 minecraft:black_concrete
setblock 382 232 363 minecraft:polished_deepslate
setblock 383 232 323 minecraft:gray_concrete
fill 383 232 346 384 232 346 minecraft:black_concrete
setblock 383 232 362 minecraft:polished_deepslate
setblock 383 232 363 minecraft:gray_concrete
setblock 384 232 362 minecraft:gray_concrete
setblock 385 232 352 minecraft:black_concrete
setblock 386 232 347 minecraft:black_concrete
setblock 386 232 351 minecraft:black_concrete
setblock 387 232 323 minecraft:polished_deepslate
fill 387 232 328 389 239 330 minecraft:polished_blackstone
fill 387 232 344 389 239 346 minecraft:polished_blackstone
setblock 387 232 363 minecraft:polished_deepslate
setblock 388 232 323 minecraft:gray_concrete
fill 388 232 331 389 239 331 minecraft:polished_blackstone
fill 388 232 343 389 239 343 minecraft:polished_blackstone
fill 390 232 329 390 239 330 minecraft:polished_blackstone
fill 390 232 344 390 239 345 minecraft:polished_blackstone
setblock 394 232 323 minecraft:gray_concrete
setblock 395 232 363 minecraft:gray_concrete
setblock 397 232 323 minecraft:polished_deepslate
setblock 397 232 324 minecraft:gray_concrete
setblock 397 232 363 minecraft:polished_deepslate
setblock 398 232 323 minecraft:gray_concrete
setblock 398 232 362 minecraft:polished_deepslate
setblock 398 232 363 minecraft:gray_concrete
fill 399 232 343 399 232 344 minecraft:polished_deepslate
setblock 399 232 362 minecraft:gray_concrete
setblock 401 232 324 minecraft:polished_deepslate
fill 401 232 325 403 232 325 minecraft:gray_concrete
setblock 402 232 323 minecraft:polished_deepslate
setblock 402 232 324 minecraft:gray_concrete
fill 402 232 329 405 239 330 minecraft:polished_blackstone
fill 402 232 344 405 239 345 minecraft:polished_blackstone
setblock 402 232 363 minecraft:polished_deepslate
setblock 403 232 323 minecraft:gray_concrete
fill 403 232 328 405 245 328 minecraft:polished_blackstone
fill 403 232 331 404 239 331 minecraft:polished_blackstone
fill 403 232 343 404 239 343 minecraft:polished_blackstone
fill 403 232 346 405 245 346 minecraft:polished_blackstone
setblock 403 232 362 minecraft:polished_deepslate
setblock 403 232 363 minecraft:gray_concrete
setblock 404 232 361 minecraft:polished_deepslate
setblock 404 232 362 minecraft:gray_concrete
setblock 405 232 361 minecraft:gray_concrete
setblock 406 232 324 minecraft:polished_deepslate
setblock 407 232 323 minecraft:polished_deepslate
setblock 407 232 324 minecraft:gray_concrete
setblock 407 232 363 minecraft:polished_deepslate
setblock 408 232 323 minecraft:gray_concrete
setblock 408 232 362 minecraft:polished_deepslate
setblock 408 232 363 minecraft:gray_concrete
setblock 409 232 362 minecraft:gray_concrete
setblock 412 232 363 minecraft:polished_deepslate
setblock 413 232 362 minecraft:polished_deepslate
setblock 413 232 363 minecraft:gray_concrete
setblock 414 232 362 minecraft:gray_concrete
setblock 416 232 359 minecraft:polished_deepslate
setblock 416 232 360 minecraft:gray_concrete
setblock 417 232 339 minecraft:gray_concrete
fill 417 232 341 417 232 342 minecraft:gray_concrete
setblock 417 232 343 minecraft:polished_deepslate
setblock 417 232 344 minecraft:gray_concrete
fill 417 232 346 417 232 347 minecraft:gray_concrete
setblock 417 232 354 minecraft:gray_concrete
setblock 417 232 358 minecraft:polished_deepslate
setblock 417 232 359 minecraft:gray_concrete
setblock 417 232 363 minecraft:polished_deepslate
fill 402 233 322 402 245 322 minecraft:black_concrete
setblock 403 233 322 minecraft:light_blue_stained_glass
fill 404 233 322 404 246 322 minecraft:black_concrete
setblock 376 234 324 minecraft:light_blue_stained_glass
setblock 395 234 322 minecraft:light_blue_stained_glass
setblock 398 234 322 minecraft:light_blue_stained_glass
fill 399 234 322 400 246 322 minecraft:black_concrete
fill 403 234 322 403 246 322 minecraft:black_concrete
fill 376 235 324 376 246 324 minecraft:black_concrete
fill 395 235 322 395 244 322 minecraft:black_concrete
fill 398 235 322 398 246 322 minecraft:black_concrete
setblock 418 235 325 minecraft:light_blue_stained_glass
fill 418 235 326 418 246 326 minecraft:black_concrete
setblock 418 235 336 minecraft:light_blue_stained_glass
setblock 379 236 325 minecraft:light[level=12]
setblock 379 236 332 minecraft:light[level=12]
setblock 379 236 339 minecraft:light[level=12]
setblock 379 236 346 minecraft:light[level=12]
setblock 379 236 353 minecraft:light[level=12]
setblock 379 236 360 minecraft:light[level=12]
setblock 386 236 325 minecraft:light[level=12]
setblock 386 236 332 minecraft:light[level=12]
setblock 386 236 339 minecraft:light[level=12]
setblock 386 236 346 minecraft:light[level=12]
setblock 386 236 353 minecraft:light[level=12]
setblock 386 236 360 minecraft:light[level=12]
setblock 393 236 325 minecraft:light[level=12]
setblock 393 236 332 minecraft:light[level=12]
setblock 393 236 339 minecraft:light[level=12]
setblock 393 236 346 minecraft:light[level=12]
setblock 393 236 353 minecraft:light[level=12]
setblock 393 236 360 minecraft:light[level=12]
setblock 400 236 325 minecraft:light[level=12]
setblock 400 236 332 minecraft:light[level=12]
setblock 400 236 339 minecraft:light[level=12]
setblock 400 236 346 minecraft:light[level=12]
setblock 400 236 353 minecraft:light[level=12]
setblock 400 236 360 minecraft:light[level=12]
setblock 407 236 325 minecraft:light[level=12]
setblock 407 236 332 minecraft:light[level=12]
setblock 407 236 339 minecraft:light[level=12]
setblock 407 236 346 minecraft:light[level=12]
setblock 407 236 353 minecraft:light[level=12]
setblock 407 236 360 minecraft:light[level=12]
setblock 414 236 325 minecraft:light[level=12]
setblock 414 236 332 minecraft:light[level=12]
setblock 414 236 339 minecraft:light[level=12]
setblock 414 236 346 minecraft:light[level=12]
setblock 414 236 353 minecraft:light[level=12]
setblock 414 236 360 minecraft:light[level=12]
fill 418 236 325 418 246 325 minecraft:black_concrete
fill 418 236 336 418 246 336 minecraft:black_concrete
setblock 416 237 322 minecraft:light_blue_stained_glass
setblock 379 238 325 minecraft:light[level=13]
setblock 379 238 333 minecraft:light[level=13]
setblock 379 238 341 minecraft:light[level=13]
setblock 379 238 349 minecraft:light[level=13]
setblock 379 238 357 minecraft:light[level=13]
fill 385 238 337 393 238 337 minecraft:blackstone
fill 386 238 333 393 238 336 minecraft:blackstone
fill 386 238 338 393 238 341 minecraft:blackstone
setblock 387 238 325 minecraft:light[level=13]
fill 387 238 331 387 238 332 minecraft:blackstone
fill 387 238 342 387 238 343 minecraft:blackstone
setblock 387 238 349 minecraft:light[level=13]
setblock 387 238 357 minecraft:light[level=13]
setblock 387 238 364 minecraft:light_blue_stained_glass
fill 388 238 332 405 238 332 minecraft:blackstone
fill 388 238 342 405 238 342 minecraft:blackstone
fill 390 238 328 402 238 328 minecraft:blackstone
fill 390 238 331 402 239 331 minecraft:blackstone
fill 390 238 343 402 239 343 minecraft:blackstone
fill 390 238 346 402 238 346 minecraft:blackstone
fill 391 238 329 401 239 330 minecraft:blackstone
fill 391 238 344 401 239 345 minecraft:blackstone
fill 392 238 327 400 238 327 minecraft:blackstone
fill 392 238 347 400 238 347 minecraft:blackstone
fill 394 238 333 394 238 335 minecraft:blackstone
fill 394 238 339 394 238 341 minecraft:blackstone
setblock 395 238 325 minecraft:light[level=13]
fill 395 238 333 406 238 334 minecraft:blackstone
fill 395 238 340 406 238 341 minecraft:blackstone
setblock 395 238 349 minecraft:light[level=13]
setblock 395 238 357 minecraft:light[level=13]
fill 396 238 326 396 241 326 minecraft:blackstone
fill 396 238 348 396 241 348 minecraft:blackstone
fill 398 238 335 406 238 335 minecraft:blackstone
fill 398 238 339 406 238 339 minecraft:blackstone
fill 399 238 336 406 238 338 minecraft:blackstone
setblock 403 238 325 minecraft:light[level=13]
setblock 403 238 349 minecraft:light[level=13]
setblock 403 238 357 minecraft:light[level=13]
setblock 405 238 331 minecraft:blackstone
setblock 405 238 343 minecraft:blackstone
fill 407 238 337 407 241 337 minecraft:blackstone
setblock 411 238 325 minecraft:light[level=13]
setblock 411 238 333 minecraft:light[level=13]
setblock 411 238 341 minecraft:light[level=13]
setblock 411 238 349 minecraft:light[level=13]
setblock 411 238 357 minecraft:light[level=13]
fill 416 238 322 416 243 322 minecraft:black_concrete
fill 377 239 323 377 239 324 minecraft:gray_wool
setblock 377 239 325 minecraft:light_gray_wool
fill 377 239 326 377 239 328 minecraft:gray_wool
setblock 377 239 329 minecraft:light_gray_wool
fill 377 239 330 377 239 332 minecraft:gray_wool
setblock 377 239 333 minecraft:light_gray_wool
fill 377 239 334 377 239 336 minecraft:gray_wool
setblock 377 239 337 minecraft:light_gray_wool
fill 377 239 338 377 239 340 minecraft:gray_wool
setblock 377 239 341 minecraft:light_gray_wool
fill 377 239 342 377 239 344 minecraft:gray_wool
setblock 377 239 345 minecraft:light_gray_wool
fill 377 239 346 377 239 348 minecraft:gray_wool
setblock 377 239 349 minecraft:light_gray_wool
fill 377 239 350 377 239 352 minecraft:gray_wool
setblock 377 239 353 minecraft:light_gray_wool
fill 377 239 354 377 239 356 minecraft:gray_wool
setblock 377 239 357 minecraft:light_gray_wool
fill 377 239 358 377 239 360 minecraft:gray_wool
setblock 377 239 361 minecraft:light_gray_wool
fill 377 239 362 378 239 363 minecraft:gray_wool
setblock 378 239 323 minecraft:gray_wool
setblock 378 239 324 minecraft:light_gray_wool
fill 378 239 325 378 239 327 minecraft:gray_wool
setblock 378 239 328 minecraft:light_gray_wool
fill 378 239 329 378 239 331 minecraft:gray_wool
setblock 378 239 332 minecraft:light_gray_wool
fill 378 239 333 378 239 335 minecraft:gray_wool
setblock 378 239 336 minecraft:light_gray_wool
fill 378 239 337 378 239 339 minecraft:gray_wool
setblock 378 239 340 minecraft:light_gray_wool
fill 378 239 341 378 239 343 minecraft:gray_wool
setblock 378 239 344 minecraft:light_gray_wool
fill 378 239 345 378 239 347 minecraft:gray_wool
setblock 378 239 348 minecraft:light_gray_wool
fill 378 239 349 378 239 351 minecraft:gray_wool
setblock 378 239 352 minecraft:light_gray_wool
fill 378 239 353 378 239 355 minecraft:gray_wool
setblock 378 239 356 minecraft:light_gray_wool
fill 378 239 357 378 239 359 minecraft:gray_wool
setblock 378 239 360 minecraft:light_gray_wool
fill 378 239 361 380 239 361 minecraft:gray_wool
setblock 379 239 323 minecraft:light_gray_wool
fill 379 239 324 379 239 326 minecraft:gray_wool
setblock 379 239 327 minecraft:light_gray_wool
fill 379 239 328 379 239 330 minecraft:gray_wool
setblock 379 239 331 minecraft:light_gray_wool
fill 379 239 332 379 239 334 minecraft:gray_wool
setblock 379 239 335 minecraft:light_gray_wool
fill 379 239 336 379 239 338 minecraft:gray_wool
setblock 379 239 339 minecraft:light_gray_wool
fill 379 239 340 379 239 342 minecraft:gray_wool
setblock 379 239 343 minecraft:light_gray_wool
fill 379 239 344 379 239 346 minecraft:gray_wool
setblock 379 239 347 minecraft:light_gray_wool
fill 379 239 348 379 239 350 minecraft:gray_wool
setblock 379 239 351 minecraft:light_gray_wool
fill 379 239 352 379 239 354 minecraft:gray_wool
setblock 379 239 355 minecraft:light_gray_wool
fill 379 239 356 379 239 358 minecraft:gray_wool
setblock 379 239 359 minecraft:light_gray_wool
fill 379 239 360 381 239 360 minecraft:gray_wool
setblock 379 239 362 minecraft:gray_wool
setblock 379 239 363 minecraft:light_gray_wool
fill 380 239 323 380 239 325 minecraft:gray_wool
setblock 380 239 326 minecraft:light_gray_wool
fill 380 239 327 380 239 329 minecraft:gray_wool
setblock 380 239 330 minecraft:light_gray_wool
fill 380 239 331 380 239 333 minecraft:gray_wool
setblock 380 239 334 minecraft:light_gray_wool
fill 380 239 335 380 239 337 minecraft:gray_wool
setblock 380 239 338 minecraft:light_gray_wool
fill 380 239 339 380 239 341 minecraft:gray_wool
setblock 380 239 342 minecraft:light_gray_wool
schedule function dropper:buildpart/80_7 1t
