setblock 534 217 285 minecraft:light[level=12]
setblock 534 217 292 minecraft:light[level=12]
setblock 534 217 299 minecraft:light[level=12]
setblock 534 217 306 minecraft:light[level=12]
setblock 534 217 313 minecraft:light[level=12]
setblock 541 217 278 minecraft:light[level=12]
setblock 541 217 285 minecraft:light[level=12]
setblock 541 217 292 minecraft:light[level=12]
setblock 541 217 299 minecraft:light[level=12]
setblock 541 217 306 minecraft:light[level=12]
setblock 541 217 313 minecraft:light[level=12]
setblock 548 217 278 minecraft:light[level=12]
setblock 548 217 285 minecraft:light[level=12]
setblock 548 217 292 minecraft:light[level=12]
setblock 548 217 299 minecraft:light[level=12]
setblock 548 217 306 minecraft:light[level=12]
setblock 548 217 313 minecraft:light[level=12]
setblock 555 217 278 minecraft:light[level=12]
setblock 555 217 285 minecraft:light[level=12]
setblock 555 217 292 minecraft:light[level=12]
setblock 555 217 299 minecraft:light[level=12]
setblock 555 217 306 minecraft:light[level=12]
setblock 555 217 313 minecraft:light[level=12]
fill 527 219 297 527 220 305 minecraft:green_wool
fill 528 219 296 528 220 298 minecraft:green_wool
fill 528 219 299 533 219 303 minecraft:white_stained_glass
fill 528 219 304 528 220 306 minecraft:green_wool
fill 529 219 294 529 220 296 minecraft:green_wool
fill 529 219 297 543 219 298 minecraft:white_stained_glass
fill 529 219 304 543 219 305 minecraft:white_stained_glass
fill 529 219 306 529 220 308 minecraft:green_wool
fill 530 219 294 531 220 294 minecraft:green_wool
fill 530 219 295 542 220 296 minecraft:white_stained_glass
fill 530 219 306 542 220 307 minecraft:white_stained_glass
fill 530 219 308 531 220 308 minecraft:green_wool
fill 531 219 293 533 220 293 minecraft:green_wool
fill 531 219 309 533 220 309 minecraft:green_wool
fill 532 219 292 540 220 292 minecraft:green_wool
fill 532 219 294 540 220 294 minecraft:white_stained_glass
fill 532 219 308 540 220 308 minecraft:white_stained_glass
fill 532 219 310 540 220 310 minecraft:green_wool
fill 534 219 293 538 220 293 minecraft:white_stained_glass
setblock 534 219 299 minecraft:white_stained_glass
setblock 534 219 303 minecraft:white_stained_glass
fill 534 219 309 538 220 309 minecraft:white_stained_glass
fill 538 219 299 544 219 299 minecraft:white_stained_glass
fill 538 219 303 544 219 303 minecraft:white_stained_glass
fill 539 219 293 541 220 293 minecraft:green_wool
fill 539 219 300 544 219 302 minecraft:white_stained_glass
fill 539 219 309 541 220 309 minecraft:green_wool
fill 541 219 294 543 220 294 minecraft:green_wool
fill 541 219 308 543 220 308 minecraft:green_wool
fill 543 219 295 543 220 296 minecraft:green_wool
fill 543 219 306 543 220 307 minecraft:green_wool
fill 544 219 296 544 220 298 minecraft:green_wool
fill 544 219 304 544 220 306 minecraft:green_wool
fill 545 219 297 545 220 305 minecraft:green_wool
setblock 517 220 277 minecraft:white_concrete
setblock 517 220 281 minecraft:white_concrete
setblock 517 220 285 minecraft:white_concrete
setblock 517 220 289 minecraft:white_concrete
setblock 517 220 293 minecraft:white_concrete
setblock 517 220 297 minecraft:white_concrete
setblock 517 220 301 minecraft:white_concrete
setblock 517 220 305 minecraft:white_concrete
setblock 517 220 309 minecraft:white_concrete
setblock 517 220 313 minecraft:white_concrete
setblock 517 220 317 minecraft:white_concrete
fill 518 220 276 525 220 316 minecraft:snow_block
setblock 518 220 317 minecraft:brown_terracotta
setblock 519 220 275 minecraft:white_concrete
setblock 519 220 317 minecraft:white_concrete
setblock 520 220 317 minecraft:brown_terracotta
setblock 523 220 275 minecraft:white_concrete
setblock 523 220 317 minecraft:white_concrete
fill 526 220 276 526 220 298 minecraft:snow_block
fill 526 220 299 526 220 303 minecraft:green_wool
fill 526 220 304 526 220 316 minecraft:snow_block
setblock 527 220 275 minecraft:white_concrete
fill 527 220 276 527 220 295 minecraft:snow_block
setblock 527 220 296 minecraft:green_wool
setblock 527 220 306 minecraft:green_wool
fill 527 220 307 527 220 316 minecraft:snow_block
setblock 527 220 317 minecraft:white_concrete
fill 528 220 276 528 220 294 minecraft:snow_block
setblock 528 220 295 minecraft:green_wool
fill 528 220 299 532 220 303 minecraft:white_stained_glass
setblock 528 220 307 minecraft:green_wool
fill 528 220 308 528 220 316 minecraft:snow_block
fill 529 220 276 529 220 293 minecraft:snow_block
fill 529 220 297 533 220 298 minecraft:white_stained_glass
fill 529 220 304 533 220 305 minecraft:white_stained_glass
fill 529 220 309 529 220 316 minecraft:snow_block
fill 530 220 276 530 220 292 minecraft:snow_block
setblock 530 220 293 minecraft:green_wool
setblock 530 220 309 minecraft:green_wool
fill 530 220 310 530 220 316 minecraft:snow_block
setblock 530 220 317 minecraft:brown_terracotta
setblock 531 220 275 minecraft:white_concrete
fill 531 220 276 533 220 291 minecraft:snow_block
setblock 531 220 292 minecraft:green_wool
setblock 531 220 310 minecraft:green_wool
fill 531 220 311 533 220 316 minecraft:snow_block
setblock 531 220 317 minecraft:white_concrete
setblock 532 220 317 minecraft:brown_terracotta
setblock 533 220 299 minecraft:red_concrete
fill 533 220 300 533 220 302 minecraft:ochre_froglight
setblock 533 220 303 minecraft:red_concrete
fill 534 220 276 558 220 290 minecraft:snow_block
fill 534 220 291 538 220 291 minecraft:green_wool
fill 534 220 297 543 220 297 minecraft:white_stained_glass
setblock 534 220 298 minecraft:red_concrete
setblock 534 220 299 minecraft:ochre_froglight
setblock 534 220 303 minecraft:ochre_froglight
setblock 534 220 304 minecraft:red_concrete
fill 534 220 305 543 220 305 minecraft:white_stained_glass
fill 534 220 311 538 220 311 minecraft:green_wool
fill 534 220 312 558 220 316 minecraft:snow_block
setblock 535 220 275 minecraft:white_concrete
fill 535 220 298 537 220 298 minecraft:ochre_froglight
fill 535 220 304 537 220 304 minecraft:ochre_froglight
setblock 535 220 317 minecraft:white_concrete
setblock 538 220 298 minecraft:red_concrete
setblock 538 220 299 minecraft:ochre_froglight
setblock 538 220 303 minecraft:ochre_froglight
setblock 538 220 304 minecraft:red_concrete
setblock 539 220 275 minecraft:white_concrete
fill 539 220 291 558 220 291 minecraft:snow_block
fill 539 220 298 543 220 298 minecraft:white_stained_glass
setblock 539 220 299 minecraft:red_concrete
fill 539 220 300 539 220 302 minecraft:ochre_froglight
setblock 539 220 303 minecraft:red_concrete
fill 539 220 304 543 220 304 minecraft:white_stained_glass
fill 539 220 311 558 220 311 minecraft:snow_block
setblock 539 220 317 minecraft:white_concrete
fill 540 220 299 544 220 303 minecraft:white_stained_glass
setblock 541 220 292 minecraft:green_wool
setblock 541 220 310 minecraft:green_wool
fill 542 220 292 558 220 292 minecraft:snow_block
setblock 542 220 293 minecraft:green_wool
setblock 542 220 309 minecraft:green_wool
fill 542 220 310 558 220 310 minecraft:snow_block
setblock 542 220 317 minecraft:brown_terracotta
setblock 543 220 275 minecraft:white_concrete
fill 543 220 293 558 220 293 minecraft:snow_block
fill 543 220 309 558 220 309 minecraft:snow_block
setblock 543 220 317 minecraft:white_concrete
fill 544 220 294 558 220 294 minecraft:snow_block
setblock 544 220 295 minecraft:green_wool
setblock 544 220 307 minecraft:green_wool
fill 544 220 308 558 220 308 minecraft:snow_block
setblock 544 220 317 minecraft:brown_terracotta
fill 545 220 295 558 220 295 minecraft:snow_block
setblock 545 220 296 minecraft:green_wool
setblock 545 220 306 minecraft:green_wool
fill 545 220 307 558 220 307 minecraft:snow_block
fill 546 220 296 558 220 298 minecraft:snow_block
fill 546 220 299 546 220 303 minecraft:green_wool
fill 546 220 304 558 220 306 minecraft:snow_block
setblock 547 220 275 minecraft:white_concrete
fill 547 220 299 558 220 303 minecraft:snow_block
setblock 547 220 317 minecraft:white_concrete
setblock 551 220 275 minecraft:white_concrete
setblock 551 220 317 minecraft:white_concrete
setblock 554 220 317 minecraft:brown_terracotta
setblock 555 220 275 minecraft:white_concrete
setblock 555 220 317 minecraft:white_concrete
setblock 556 220 317 minecraft:brown_terracotta
setblock 559 220 275 minecraft:white_concrete
setblock 559 220 276 minecraft:brown_terracotta
setblock 559 220 277 minecraft:white_concrete
setblock 559 220 278 minecraft:brown_terracotta
setblock 559 220 281 minecraft:white_concrete
setblock 559 220 285 minecraft:white_concrete
setblock 559 220 288 minecraft:brown_terracotta
setblock 559 220 289 minecraft:white_concrete
setblock 559 220 290 minecraft:brown_terracotta
setblock 559 220 293 minecraft:white_concrete
setblock 559 220 297 minecraft:white_concrete
setblock 559 220 300 minecraft:brown_terracotta
setblock 559 220 301 minecraft:white_concrete
setblock 559 220 302 minecraft:brown_terracotta
setblock 559 220 305 minecraft:white_concrete
setblock 559 220 309 minecraft:white_concrete
setblock 559 220 312 minecraft:brown_terracotta
setblock 559 220 313 minecraft:white_concrete
setblock 559 220 314 minecraft:brown_terracotta
setblock 559 220 317 minecraft:white_concrete
setblock 517 221 276 minecraft:white_concrete
fill 517 221 277 517 228 277 minecraft:brown_terracotta
setblock 517 221 278 minecraft:white_concrete
setblock 517 221 280 minecraft:white_concrete
fill 517 221 281 517 225 281 minecraft:brown_terracotta
setblock 517 221 282 minecraft:white_concrete
setblock 517 221 284 minecraft:white_concrete
fill 517 221 285 517 228 285 minecraft:brown_terracotta
setblock 517 221 286 minecraft:white_concrete
setblock 517 221 288 minecraft:white_concrete
fill 517 221 289 517 228 289 minecraft:brown_terracotta
setblock 517 221 290 minecraft:white_concrete
setblock 517 221 292 minecraft:white_concrete
fill 517 221 293 517 225 293 minecraft:brown_terracotta
setblock 517 221 294 minecraft:white_concrete
setblock 517 221 296 minecraft:white_concrete
fill 517 221 297 517 228 297 minecraft:brown_terracotta
setblock 517 221 298 minecraft:white_concrete
setblock 517 221 300 minecraft:white_concrete
fill 517 221 301 517 228 301 minecraft:brown_terracotta
setblock 517 221 302 minecraft:white_concrete
setblock 517 221 304 minecraft:white_concrete
fill 517 221 305 517 225 305 minecraft:brown_terracotta
setblock 517 221 306 minecraft:white_concrete
setblock 517 221 308 minecraft:white_concrete
fill 517 221 309 517 228 309 minecraft:brown_terracotta
setblock 517 221 310 minecraft:white_concrete
setblock 517 221 312 minecraft:white_concrete
fill 517 221 313 517 228 313 minecraft:brown_terracotta
setblock 517 221 314 minecraft:white_concrete
setblock 517 221 316 minecraft:white_concrete
setblock 517 221 317 minecraft:brown_terracotta
setblock 518 221 275 minecraft:white_concrete
setblock 518 221 317 minecraft:white_concrete
fill 519 221 275 519 228 275 minecraft:brown_terracotta
fill 519 221 317 519 225 317 minecraft:brown_terracotta
setblock 520 221 275 minecraft:white_concrete
setblock 520 221 278 minecraft:light[level=15]
setblock 520 221 286 minecraft:light[level=15]
setblock 520 221 294 minecraft:light[level=15]
setblock 520 221 302 minecraft:light[level=15]
setblock 520 221 310 minecraft:light[level=15]
setblock 520 221 317 minecraft:white_concrete
setblock 522 221 275 minecraft:white_concrete
setblock 522 221 317 minecraft:white_concrete
fill 523 221 275 523 228 275 minecraft:brown_terracotta
fill 523 221 292 531 229 310 minecraft:smooth_stone
fill 523 221 317 523 228 317 minecraft:brown_terracotta
setblock 524 221 275 minecraft:white_concrete
setblock 524 221 317 minecraft:white_concrete
setblock 526 221 275 minecraft:white_concrete
setblock 526 221 317 minecraft:white_concrete
fill 527 221 275 527 225 275 minecraft:brown_terracotta
fill 527 221 317 527 228 317 minecraft:brown_terracotta
setblock 528 221 275 minecraft:white_concrete
setblock 528 221 278 minecraft:light[level=15]
setblock 528 221 286 minecraft:light[level=15]
setblock 528 221 317 minecraft:white_concrete
setblock 530 221 275 minecraft:white_concrete
setblock 530 221 317 minecraft:white_concrete
fill 531 221 275 531 228 275 minecraft:brown_terracotta
fill 531 221 317 531 225 317 minecraft:brown_terracotta
setblock 532 221 275 minecraft:white_concrete
fill 532 221 292 532 229 310 minecraft:oak_planks
setblock 532 221 317 minecraft:white_concrete
fill 533 221 292 540 221 292 minecraft:green_wool
fill 533 221 293 534 222 293 minecraft:red_concrete
fill 533 221 294 535 221 294 minecraft:green_wool
fill 533 221 308 535 221 308 minecraft:green_wool
fill 533 221 309 534 222 309 minecraft:red_concrete
fill 533 221 310 540 221 310 minecraft:green_wool
setblock 534 221 275 minecraft:white_concrete
setblock 534 221 317 minecraft:white_concrete
fill 535 221 275 535 228 275 minecraft:brown_terracotta
fill 535 221 293 537 221 293 minecraft:green_wool
fill 535 221 309 537 221 309 minecraft:green_wool
fill 535 221 317 535 228 317 minecraft:brown_terracotta
setblock 536 221 275 minecraft:white_concrete
setblock 536 221 278 minecraft:light[level=15]
setblock 536 221 286 minecraft:light[level=15]
setblock 536 221 294 minecraft:light[level=15]
setblock 536 221 317 minecraft:white_concrete
fill 537 221 294 540 221 294 minecraft:green_wool
fill 537 221 308 540 221 308 minecraft:green_wool
setblock 538 221 275 minecraft:white_concrete
fill 538 221 293 539 222 293 minecraft:red_concrete
fill 538 221 309 539 222 309 minecraft:red_concrete
setblock 538 221 317 minecraft:white_concrete
fill 539 221 275 539 225 275 minecraft:brown_terracotta
fill 539 221 317 539 228 317 minecraft:brown_terracotta
setblock 540 221 275 minecraft:white_concrete
setblock 540 221 293 minecraft:green_wool
setblock 540 221 295 minecraft:green_wool
setblock 540 221 307 minecraft:green_wool
setblock 540 221 309 minecraft:green_wool
setblock 540 221 317 minecraft:white_concrete
fill 541 221 292 541 229 310 minecraft:oak_planks
setblock 542 221 275 minecraft:white_concrete
fill 542 221 292 549 229 310 minecraft:smooth_stone
setblock 542 221 317 minecraft:white_concrete
fill 543 221 275 543 228 275 minecraft:brown_terracotta
fill 543 221 317 543 225 317 minecraft:brown_terracotta
setblock 544 221 275 minecraft:white_concrete
setblock 544 221 278 minecraft:light[level=15]
setblock 544 221 286 minecraft:light[level=15]
setblock 544 221 317 minecraft:white_concrete
setblock 546 221 275 minecraft:white_concrete
setblock 546 221 317 minecraft:white_concrete
fill 547 221 275 547 228 275 minecraft:brown_terracotta
fill 547 221 317 547 228 317 minecraft:brown_terracotta
setblock 548 221 275 minecraft:white_concrete
setblock 548 221 317 minecraft:white_concrete
setblock 550 221 275 minecraft:white_concrete
setblock 550 221 317 minecraft:white_concrete
fill 551 221 275 551 225 275 minecraft:brown_terracotta
fill 551 221 317 551 228 317 minecraft:brown_terracotta
setblock 552 221 275 minecraft:white_concrete
setblock 552 221 278 minecraft:light[level=15]
setblock 552 221 286 minecraft:light[level=15]
setblock 552 221 294 minecraft:light[level=15]
setblock 552 221 302 minecraft:light[level=15]
setblock 552 221 310 minecraft:light[level=15]
setblock 552 221 317 minecraft:white_concrete
setblock 554 221 275 minecraft:white_concrete
setblock 554 221 317 minecraft:white_concrete
fill 555 221 275 555 228 275 minecraft:brown_terracotta
fill 555 221 317 555 225 317 minecraft:brown_terracotta
setblock 556 221 275 minecraft:white_concrete
setblock 556 221 317 minecraft:white_concrete
setblock 558 221 275 minecraft:white_concrete
setblock 558 221 317 minecraft:white_concrete
setblock 559 221 275 minecraft:brown_terracotta
setblock 559 221 276 minecraft:white_concrete
fill 559 221 277 559 225 277 minecraft:brown_terracotta
setblock 559 221 278 minecraft:white_concrete
setblock 559 221 280 minecraft:white_concrete
fill 559 221 281 559 228 281 minecraft:brown_terracotta
setblock 559 221 282 minecraft:white_concrete
setblock 559 221 284 minecraft:white_concrete
fill 559 221 285 559 228 285 minecraft:brown_terracotta
setblock 559 221 286 minecraft:white_concrete
setblock 559 221 288 minecraft:white_concrete
fill 559 221 289 559 225 289 minecraft:brown_terracotta
setblock 559 221 290 minecraft:white_concrete
setblock 559 221 292 minecraft:white_concrete
fill 559 221 293 559 228 293 minecraft:brown_terracotta
setblock 559 221 294 minecraft:white_concrete
setblock 559 221 296 minecraft:white_concrete
fill 559 221 297 559 228 297 minecraft:brown_terracotta
setblock 559 221 298 minecraft:white_concrete
setblock 559 221 300 minecraft:white_concrete
fill 559 221 301 559 225 301 minecraft:brown_terracotta
setblock 559 221 302 minecraft:white_concrete
setblock 559 221 304 minecraft:white_concrete
fill 559 221 305 559 228 305 minecraft:brown_terracotta
setblock 559 221 306 minecraft:white_concrete
setblock 559 221 308 minecraft:white_concrete
fill 559 221 309 559 228 309 minecraft:brown_terracotta
setblock 559 221 310 minecraft:white_concrete
setblock 559 221 312 minecraft:white_concrete
fill 559 221 313 559 225 313 minecraft:brown_terracotta
setblock 559 221 314 minecraft:white_concrete
setblock 559 221 316 minecraft:white_concrete
fill 559 221 317 559 228 317 minecraft:brown_terracotta
setblock 517 222 275 minecraft:white_concrete
fill 517 222 276 517 229 276 minecraft:brown_terracotta
fill 517 222 278 517 229 278 minecraft:brown_terracotta
setblock 517 222 279 minecraft:white_concrete
fill 517 222 280 517 229 280 minecraft:brown_terracotta
fill 517 222 282 517 225 282 minecraft:brown_terracotta
setblock 517 222 283 minecraft:white_concrete
fill 517 222 284 517 225 284 minecraft:brown_terracotta
fill 517 222 286 517 229 286 minecraft:brown_terracotta
setblock 517 222 287 minecraft:white_concrete
fill 517 222 288 517 229 288 minecraft:brown_terracotta
fill 517 222 290 517 229 290 minecraft:brown_terracotta
setblock 517 222 291 minecraft:white_concrete
fill 517 222 292 517 229 292 minecraft:brown_terracotta
fill 517 222 294 517 225 294 minecraft:brown_terracotta
setblock 517 222 295 minecraft:white_concrete
fill 517 222 296 517 225 296 minecraft:brown_terracotta
fill 517 222 298 517 229 298 minecraft:brown_terracotta
setblock 517 222 299 minecraft:white_concrete
fill 517 222 300 517 229 300 minecraft:brown_terracotta
fill 517 222 302 517 229 302 minecraft:brown_terracotta
setblock 517 222 303 minecraft:white_concrete
fill 517 222 304 517 229 304 minecraft:brown_terracotta
fill 517 222 306 517 225 306 minecraft:brown_terracotta
setblock 517 222 307 minecraft:white_concrete
fill 517 222 308 517 225 308 minecraft:brown_terracotta
fill 517 222 310 517 229 310 minecraft:brown_terracotta
setblock 517 222 311 minecraft:white_concrete
fill 517 222 312 517 229 312 minecraft:brown_terracotta
fill 517 222 314 517 229 314 minecraft:brown_terracotta
setblock 517 222 315 minecraft:white_concrete
fill 517 222 316 517 229 316 minecraft:brown_terracotta
setblock 517 222 317 minecraft:white_concrete
fill 518 222 275 518 229 275 minecraft:brown_terracotta
fill 518 222 317 518 225 317 minecraft:brown_terracotta
fill 520 222 275 520 229 275 minecraft:brown_terracotta
fill 520 222 317 520 225 317 minecraft:brown_terracotta
setblock 521 222 275 minecraft:white_concrete
setblock 521 222 317 minecraft:white_concrete
fill 522 222 275 522 229 275 minecraft:brown_terracotta
fill 522 222 317 522 229 317 minecraft:brown_terracotta
fill 524 222 275 524 225 275 minecraft:brown_terracotta
fill 524 222 317 524 229 317 minecraft:brown_terracotta
setblock 525 222 275 minecraft:white_concrete
setblock 525 222 317 minecraft:white_concrete
fill 526 222 275 526 225 275 minecraft:brown_terracotta
fill 526 222 317 526 229 317 minecraft:brown_terracotta
fill 528 222 275 528 229 275 minecraft:brown_terracotta
fill 528 222 317 528 229 317 minecraft:brown_terracotta
setblock 529 222 275 minecraft:white_concrete
setblock 529 222 317 minecraft:white_concrete
fill 530 222 275 530 229 275 minecraft:brown_terracotta
fill 530 222 317 530 225 317 minecraft:brown_terracotta
fill 532 222 275 532 229 275 minecraft:brown_terracotta
fill 532 222 317 532 225 317 minecraft:brown_terracotta
setblock 533 222 275 minecraft:white_concrete
setblock 533 222 317 minecraft:white_concrete
fill 534 222 275 534 229 275 minecraft:brown_terracotta
fill 534 222 317 534 229 317 minecraft:brown_terracotta
fill 536 222 275 536 225 275 minecraft:brown_terracotta
fill 536 222 317 536 229 317 minecraft:brown_terracotta
setblock 537 222 275 minecraft:white_concrete
setblock 537 222 317 minecraft:white_concrete
fill 538 222 275 538 225 275 minecraft:brown_terracotta
fill 538 222 317 538 229 317 minecraft:brown_terracotta
fill 540 222 275 540 229 275 minecraft:brown_terracotta
fill 540 222 317 540 229 317 minecraft:brown_terracotta
setblock 541 222 275 minecraft:white_concrete
setblock 541 222 317 minecraft:white_concrete
fill 542 222 275 542 229 275 minecraft:brown_terracotta
fill 542 222 317 542 225 317 minecraft:brown_terracotta
fill 544 222 275 544 229 275 minecraft:brown_terracotta
fill 544 222 317 544 225 317 minecraft:brown_terracotta
setblock 545 222 275 minecraft:white_concrete
setblock 545 222 317 minecraft:white_concrete
fill 546 222 275 546 229 275 minecraft:brown_terracotta
fill 546 222 317 546 229 317 minecraft:brown_terracotta
fill 548 222 275 548 225 275 minecraft:brown_terracotta
fill 548 222 317 548 229 317 minecraft:brown_terracotta
setblock 549 222 275 minecraft:white_concrete
setblock 549 222 317 minecraft:white_concrete
fill 550 222 275 550 225 275 minecraft:brown_terracotta
fill 550 222 317 550 229 317 minecraft:brown_terracotta
fill 552 222 275 552 229 275 minecraft:brown_terracotta
fill 552 222 317 552 229 317 minecraft:brown_terracotta
setblock 553 222 275 minecraft:white_concrete
setblock 553 222 317 minecraft:white_concrete
fill 554 222 275 554 229 275 minecraft:brown_terracotta
fill 554 222 317 554 225 317 minecraft:brown_terracotta
fill 556 222 275 556 229 275 minecraft:brown_terracotta
fill 556 222 317 556 225 317 minecraft:brown_terracotta
setblock 557 222 275 minecraft:white_concrete
setblock 557 222 317 minecraft:white_concrete
fill 558 222 275 558 229 275 minecraft:brown_terracotta
fill 558 222 317 558 229 317 minecraft:brown_terracotta
setblock 559 222 275 minecraft:white_concrete
fill 559 222 276 559 225 276 minecraft:brown_terracotta
fill 559 222 278 559 225 278 minecraft:brown_terracotta
setblock 559 222 279 minecraft:white_concrete
fill 559 222 280 559 229 280 minecraft:brown_terracotta
fill 559 222 282 559 229 282 minecraft:brown_terracotta
setblock 559 222 283 minecraft:white_concrete
fill 559 222 284 559 229 284 minecraft:brown_terracotta
fill 559 222 286 559 229 286 minecraft:brown_terracotta
setblock 559 222 287 minecraft:white_concrete
fill 559 222 288 559 225 288 minecraft:brown_terracotta
fill 559 222 290 559 225 290 minecraft:brown_terracotta
setblock 559 222 291 minecraft:white_concrete
fill 559 222 292 559 229 292 minecraft:brown_terracotta
fill 559 222 294 559 229 294 minecraft:brown_terracotta
setblock 559 222 295 minecraft:white_concrete
fill 559 222 296 559 229 296 minecraft:brown_terracotta
fill 559 222 298 559 229 298 minecraft:brown_terracotta
setblock 559 222 299 minecraft:white_concrete
fill 559 222 300 559 225 300 minecraft:brown_terracotta
fill 559 222 302 559 225 302 minecraft:brown_terracotta
setblock 559 222 303 minecraft:white_concrete
fill 559 222 304 559 229 304 minecraft:brown_terracotta
fill 559 222 306 559 229 306 minecraft:brown_terracotta
setblock 559 222 307 minecraft:white_concrete
fill 559 222 308 559 229 308 minecraft:brown_terracotta
fill 559 222 310 559 229 310 minecraft:brown_terracotta
setblock 559 222 311 minecraft:white_concrete
fill 559 222 312 559 225 312 minecraft:brown_terracotta
fill 559 222 314 559 225 314 minecraft:brown_terracotta
setblock 559 222 315 minecraft:white_concrete
fill 559 222 316 559 229 316 minecraft:brown_terracotta
fill 517 223 275 517 230 275 minecraft:brown_terracotta
fill 517 223 279 517 230 279 minecraft:brown_terracotta
fill 517 223 283 517 225 283 minecraft:brown_terracotta
fill 517 223 287 517 230 287 minecraft:brown_terracotta
fill 517 223 291 517 230 291 minecraft:brown_terracotta
fill 517 223 295 517 225 295 minecraft:brown_terracotta
fill 517 223 299 517 230 299 minecraft:brown_terracotta
fill 517 223 303 517 230 303 minecraft:brown_terracotta
fill 517 223 307 517 225 307 minecraft:brown_terracotta
fill 517 223 311 517 230 311 minecraft:brown_terracotta
fill 517 223 315 517 230 315 minecraft:brown_terracotta
fill 517 223 317 517 225 317 minecraft:brown_terracotta
fill 518 223 290 522 223 294 minecraft:orange_terracotta
setblock 520 223 278 minecraft:light[level=12]
setblock 520 223 285 minecraft:light[level=12]
setblock 520 223 299 minecraft:light[level=12]
setblock 520 223 306 minecraft:light[level=12]
setblock 520 223 313 minecraft:light[level=12]
fill 521 223 275 521 230 275 minecraft:brown_terracotta
fill 521 223 317 521 230 317 minecraft:brown_terracotta
fill 525 223 275 525 225 275 minecraft:brown_terracotta
fill 525 223 317 525 230 317 minecraft:brown_terracotta
setblock 527 223 278 minecraft:light[level=12]
setblock 527 223 285 minecraft:light[level=12]
setblock 527 223 313 minecraft:light[level=12]
fill 529 223 275 529 230 275 minecraft:brown_terracotta
fill 529 223 317 529 225 317 minecraft:brown_terracotta
fill 533 223 275 533 230 275 minecraft:brown_terracotta
fill 533 223 317 533 230 317 minecraft:brown_terracotta
setblock 534 223 278 minecraft:light[level=12]
setblock 534 223 285 minecraft:light[level=12]
setblock 534 223 292 minecraft:light[level=12]
setblock 534 223 299 minecraft:light[level=12]
setblock 534 223 306 minecraft:light[level=12]
setblock 534 223 313 minecraft:light[level=12]
fill 537 223 275 537 225 275 minecraft:brown_terracotta
fill 537 223 317 537 230 317 minecraft:brown_terracotta
fill 541 223 275 541 230 275 minecraft:brown_terracotta
setblock 541 223 278 minecraft:light[level=12]
setblock 541 223 285 minecraft:light[level=12]
setblock 541 223 313 minecraft:light[level=12]
fill 541 223 317 541 225 317 minecraft:brown_terracotta
fill 545 223 275 545 230 275 minecraft:brown_terracotta
fill 545 223 317 545 230 317 minecraft:brown_terracotta
setblock 548 223 278 minecraft:light[level=12]
setblock 548 223 285 minecraft:light[level=12]
setblock 548 223 313 minecraft:light[level=12]
fill 549 223 275 549 225 275 minecraft:brown_terracotta
fill 549 223 317 549 230 317 minecraft:brown_terracotta
fill 553 223 275 553 230 275 minecraft:brown_terracotta
fill 553 223 302 557 223 306 minecraft:orange_terracotta
fill 553 223 317 553 225 317 minecraft:brown_terracotta
setblock 555 223 278 minecraft:light[level=12]
setblock 555 223 285 minecraft:light[level=12]
setblock 555 223 292 minecraft:light[level=12]
setblock 555 223 299 minecraft:light[level=12]
setblock 555 223 313 minecraft:light[level=12]
fill 557 223 275 557 230 275 minecraft:brown_terracotta
fill 557 223 317 557 230 317 minecraft:brown_terracotta
fill 559 223 275 559 228 275 minecraft:brown_terracotta
fill 559 223 279 559 225 279 minecraft:brown_terracotta
fill 559 223 283 559 230 283 minecraft:brown_terracotta
fill 559 223 287 559 230 287 minecraft:brown_terracotta
fill 559 223 291 559 225 291 minecraft:brown_terracotta
fill 559 223 295 559 230 295 minecraft:brown_terracotta
fill 559 223 299 559 230 299 minecraft:brown_terracotta
fill 559 223 303 559 225 303 minecraft:brown_terracotta
fill 559 223 307 559 230 307 minecraft:brown_terracotta
fill 559 223 311 559 230 311 minecraft:brown_terracotta
fill 559 223 315 559 225 315 minecraft:brown_terracotta
fill 518 224 276 520 271 276 minecraft:white_concrete
fill 518 224 283 524 224 289 minecraft:white_concrete
fill 518 224 290 519 225 294 minecraft:orange_terracotta
fill 518 224 295 522 224 295 minecraft:white_concrete
fill 518 224 298 518 271 300 minecraft:white_concrete
fill 518 224 303 518 224 312 minecraft:white_concrete
fill 519 224 297 519 225 299 minecraft:white_concrete
fill 519 224 303 522 225 311 minecraft:white_concrete
fill 520 224 290 522 225 291 minecraft:orange_terracotta
fill 520 224 292 520 225 292 minecraft:ochre_froglight
fill 520 224 293 522 225 294 minecraft:orange_terracotta
fill 521 224 292 522 225 292 minecraft:orange_terracotta
fill 523 224 290 524 225 291 minecraft:white_concrete
fill 523 224 311 534 225 311 minecraft:white_concrete
fill 524 224 312 534 224 316 minecraft:white_concrete
fill 529 224 277 531 225 277 minecraft:white_concrete
fill 530 224 276 532 271 276 minecraft:white_concrete
fill 536 224 316 538 271 316 minecraft:white_concrete
fill 537 224 315 539 225 315 minecraft:white_concrete
fill 541 224 277 543 225 277 minecraft:white_concrete
fill 542 224 276 544 271 276 minecraft:white_concrete
fill 548 224 316 550 256 316 minecraft:white_concrete
fill 549 224 315 551 225 315 minecraft:white_concrete
fill 553 224 277 555 225 277 minecraft:white_concrete
fill 553 224 302 554 227 306 minecraft:orange_terracotta
fill 554 224 276 556 271 276 minecraft:white_concrete
fill 555 224 302 557 227 303 minecraft:orange_terracotta
fill 555 224 304 555 225 304 minecraft:ochre_froglight
fill 555 224 305 557 227 306 minecraft:orange_terracotta
fill 556 224 285 556 226 289 minecraft:red_wool
fill 556 224 304 557 227 304 minecraft:orange_terracotta
fill 557 224 285 557 225 287 minecraft:white_concrete
fill 557 224 297 557 225 299 minecraft:white_concrete
fill 557 224 309 557 225 311 minecraft:white_concrete
fill 558 224 284 558 271 286 minecraft:white_concrete
fill 558 224 296 558 271 298 minecraft:white_concrete
fill 558 224 308 558 271 310 minecraft:white_concrete
fill 518 225 279 518 225 284 minecraft:brown_terracotta
fill 518 225 285 524 225 289 minecraft:white_concrete
fill 518 225 295 518 225 296 minecraft:brown_terracotta
fill 518 225 303 518 225 308 minecraft:brown_terracotta
fill 518 225 309 518 225 312 minecraft:white_concrete
fill 518 225 315 518 225 316 minecraft:brown_terracotta
fill 519 225 283 524 225 284 minecraft:white_concrete
fill 519 225 295 522 225 295 minecraft:white_concrete
fill 519 225 316 522 225 316 minecraft:brown_terracotta
fill 522 225 276 527 225 276 minecraft:brown_terracotta
fill 524 225 312 528 225 316 minecraft:white_concrete
fill 529 225 312 534 225 315 minecraft:white_concrete
fill 529 225 316 534 225 316 minecraft:brown_terracotta
fill 534 225 276 539 225 276 minecraft:brown_terracotta
fill 541 225 316 546 225 316 minecraft:brown_terracotta
fill 543 225 289 544 226 290 minecraft:white_concrete
fill 546 225 276 551 225 276 minecraft:brown_terracotta
fill 553 225 316 558 225 316 minecraft:brown_terracotta
fill 558 225 276 558 225 281 minecraft:brown_terracotta
fill 558 225 288 558 225 293 minecraft:brown_terracotta
fill 558 225 300 558 225 305 minecraft:brown_terracotta
fill 558 225 312 558 225 315 minecraft:brown_terracotta
fill 517 226 281 517 231 284 minecraft:shroomlight
fill 517 226 293 517 231 296 minecraft:shroomlight
fill 517 226 305 517 231 308 minecraft:shroomlight
fill 517 226 317 520 231 317 minecraft:shroomlight
fill 518 226 283 518 238 283 minecraft:white_concrete
setblock 518 226 284 minecraft:shroomlight
fill 518 226 285 518 238 285 minecraft:white_concrete
setblock 518 226 286 minecraft:shroomlight
fill 518 226 287 518 271 287 minecraft:white_concrete
setblock 518 226 288 minecraft:shroomlight
fill 518 226 289 518 238 289 minecraft:white_concrete
setblock 518 226 290 minecraft:shroomlight
fill 518 226 291 518 227 291 minecraft:orange_terracotta
setblock 518 226 292 minecraft:shroomlight
fill 518 226 293 518 227 293 minecraft:orange_terracotta
setblock 518 226 294 minecraft:shroomlight
fill 518 226 295 518 238 295 minecraft:white_concrete
fill 518 226 303 518 236 303 minecraft:white_concrete
setblock 518 226 304 minecraft:shroomlight
fill 518 226 305 518 236 305 minecraft:white_concrete
setblock 518 226 306 minecraft:shroomlight
fill 518 226 307 518 236 307 minecraft:white_concrete
setblock 518 226 308 minecraft:shroomlight
fill 518 226 309 518 236 309 minecraft:white_concrete
setblock 518 226 310 minecraft:shroomlight
fill 518 226 311 518 271 312 minecraft:white_concrete
setblock 519 226 283 minecraft:shroomlight
fill 519 226 284 519 238 284 minecraft:white_concrete
setblock 519 226 285 minecraft:shroomlight
fill 519 226 286 519 238 286 minecraft:white_concrete
setblock 519 226 287 minecraft:shroomlight
fill 519 226 288 519 238 288 minecraft:white_concrete
setblock 519 226 289 minecraft:shroomlight
fill 519 226 290 519 227 290 minecraft:orange_terracotta
setblock 519 226 291 minecraft:shroomlight
fill 519 226 292 519 227 292 minecraft:orange_terracotta
setblock 519 226 293 minecraft:shroomlight
fill 519 226 294 519 227 294 minecraft:orange_terracotta
setblock 519 226 295 minecraft:shroomlight
setblock 519 226 303 minecraft:shroomlight
fill 519 226 304 519 236 304 minecraft:white_concrete
setblock 519 226 305 minecraft:shroomlight
fill 519 226 306 519 236 306 minecraft:white_concrete
setblock 519 226 307 minecraft:shroomlight
fill 519 226 308 519 236 308 minecraft:white_concrete
setblock 519 226 309 minecraft:shroomlight
fill 519 226 310 519 236 310 minecraft:white_concrete
setblock 519 226 311 minecraft:shroomlight
fill 520 226 283 520 238 283 minecraft:white_concrete
setblock 520 226 284 minecraft:shroomlight
fill 520 226 285 520 238 285 minecraft:white_concrete
setblock 520 226 286 minecraft:shroomlight
fill 520 226 287 520 238 287 minecraft:white_concrete
setblock 520 226 288 minecraft:shroomlight
fill 520 226 289 520 238 289 minecraft:white_concrete
setblock 520 226 290 minecraft:shroomlight
fill 520 226 291 520 227 291 minecraft:orange_terracotta
setblock 520 226 292 minecraft:shroomlight
fill 520 226 293 520 227 293 minecraft:orange_terracotta
setblock 520 226 294 minecraft:shroomlight
fill 520 226 295 520 238 295 minecraft:white_concrete
fill 520 226 303 520 236 303 minecraft:white_concrete
setblock 520 226 304 minecraft:shroomlight
fill 520 226 305 520 236 305 minecraft:white_concrete
setblock 520 226 306 minecraft:shroomlight
fill 520 226 307 520 236 307 minecraft:white_concrete
setblock 520 226 308 minecraft:shroomlight
fill 520 226 309 520 236 309 minecraft:white_concrete
setblock 520 226 310 minecraft:shroomlight
fill 520 226 311 520 236 311 minecraft:white_concrete
setblock 521 226 283 minecraft:shroomlight
fill 521 226 284 521 238 284 minecraft:white_concrete
setblock 521 226 285 minecraft:shroomlight
fill 521 226 286 521 238 286 minecraft:white_concrete
setblock 521 226 287 minecraft:shroomlight
fill 521 226 288 521 238 288 minecraft:white_concrete
setblock 521 226 289 minecraft:shroomlight
fill 521 226 290 521 227 290 minecraft:orange_terracotta
setblock 521 226 291 minecraft:shroomlight
fill 521 226 292 521 227 292 minecraft:orange_terracotta
setblock 521 226 293 minecraft:shroomlight
fill 521 226 294 521 227 294 minecraft:orange_terracotta
setblock 521 226 295 minecraft:shroomlight
setblock 521 226 303 minecraft:shroomlight
fill 521 226 304 521 236 304 minecraft:white_concrete
setblock 521 226 305 minecraft:shroomlight
fill 521 226 306 521 236 306 minecraft:white_concrete
setblock 521 226 307 minecraft:shroomlight
fill 521 226 308 521 236 308 minecraft:white_concrete
setblock 521 226 309 minecraft:shroomlight
fill 521 226 310 521 236 310 minecraft:white_concrete
setblock 521 226 311 minecraft:shroomlight
fill 522 226 283 522 238 283 minecraft:white_concrete
setblock 522 226 284 minecraft:shroomlight
fill 522 226 285 522 238 285 minecraft:white_concrete
setblock 522 226 286 minecraft:shroomlight
fill 522 226 287 522 238 287 minecraft:white_concrete
setblock 522 226 288 minecraft:shroomlight
fill 522 226 289 522 238 289 minecraft:white_concrete
setblock 522 226 290 minecraft:shroomlight
fill 522 226 291 522 227 291 minecraft:orange_terracotta
setblock 522 226 292 minecraft:shroomlight
fill 522 226 293 522 227 293 minecraft:orange_terracotta
setblock 522 226 294 minecraft:shroomlight
fill 522 226 295 522 238 295 minecraft:white_concrete
fill 522 226 303 522 236 303 minecraft:white_concrete
setblock 522 226 304 minecraft:shroomlight
fill 522 226 305 522 236 305 minecraft:white_concrete
setblock 522 226 306 minecraft:shroomlight
fill 522 226 307 522 236 307 minecraft:white_concrete
setblock 522 226 308 minecraft:shroomlight
fill 522 226 309 522 236 309 minecraft:white_concrete
setblock 522 226 310 minecraft:shroomlight
fill 522 226 311 522 236 311 minecraft:white_concrete
setblock 523 226 283 minecraft:shroomlight
fill 523 226 284 523 238 284 minecraft:white_concrete
setblock 523 226 285 minecraft:shroomlight
fill 523 226 286 523 238 286 minecraft:white_concrete
setblock 523 226 287 minecraft:shroomlight
fill 523 226 288 523 238 288 minecraft:white_concrete
setblock 523 226 289 minecraft:shroomlight
fill 523 226 290 523 238 290 minecraft:white_concrete
setblock 523 226 291 minecraft:shroomlight
setblock 523 226 311 minecraft:shroomlight
fill 524 226 275 527 231 275 minecraft:shroomlight
fill 524 226 283 524 238 283 minecraft:white_concrete
setblock 524 226 284 minecraft:shroomlight
fill 524 226 285 524 238 285 minecraft:white_concrete
setblock 524 226 286 minecraft:shroomlight
fill 524 226 287 524 238 287 minecraft:white_concrete
setblock 524 226 288 minecraft:shroomlight
fill 524 226 289 524 238 289 minecraft:white_concrete
setblock 524 226 290 minecraft:shroomlight
fill 524 226 291 524 238 291 minecraft:white_concrete
fill 524 226 311 524 249 311 minecraft:white_concrete
setblock 524 226 312 minecraft:shroomlight
fill 524 226 313 524 249 313 minecraft:white_concrete
setblock 524 226 314 minecraft:shroomlight
fill 524 226 315 524 249 315 minecraft:white_concrete
setblock 524 226 316 minecraft:shroomlight
setblock 525 226 311 minecraft:shroomlight
fill 525 226 312 525 249 312 minecraft:white_concrete
setblock 525 226 313 minecraft:shroomlight
fill 525 226 314 525 249 314 minecraft:white_concrete
setblock 525 226 315 minecraft:shroomlight
fill 525 226 316 525 271 316 minecraft:white_concrete
fill 526 226 311 526 249 311 minecraft:white_concrete
setblock 526 226 312 minecraft:shroomlight
fill 526 226 313 526 249 313 minecraft:white_concrete
setblock 526 226 314 minecraft:shroomlight
fill 526 226 315 526 249 315 minecraft:white_concrete
setblock 526 226 316 minecraft:shroomlight
setblock 527 226 311 minecraft:shroomlight
fill 527 226 312 527 249 312 minecraft:white_concrete
setblock 527 226 313 minecraft:shroomlight
fill 527 226 314 527 249 314 minecraft:white_concrete
setblock 527 226 315 minecraft:shroomlight
fill 527 226 316 527 249 316 minecraft:white_concrete
fill 528 226 311 528 249 311 minecraft:white_concrete
setblock 528 226 312 minecraft:shroomlight
fill 528 226 313 528 249 313 minecraft:white_concrete
setblock 528 226 314 minecraft:shroomlight
fill 528 226 315 528 249 315 minecraft:white_concrete
setblock 528 226 316 minecraft:shroomlight
setblock 529 226 311 minecraft:shroomlight
fill 529 226 312 529 249 312 minecraft:white_concrete
setblock 529 226 313 minecraft:shroomlight
fill 529 226 314 529 249 314 minecraft:white_concrete
setblock 529 226 315 minecraft:shroomlight
fill 529 226 316 529 244 316 minecraft:white_concrete
fill 529 226 317 532 231 317 minecraft:shroomlight
fill 530 226 311 530 249 311 minecraft:white_concrete
setblock 530 226 312 minecraft:shroomlight
fill 530 226 313 530 249 313 minecraft:white_concrete
setblock 530 226 314 minecraft:shroomlight
fill 530 226 315 530 249 315 minecraft:white_concrete
setblock 530 226 316 minecraft:shroomlight
setblock 531 226 311 minecraft:shroomlight
fill 531 226 312 531 249 312 minecraft:white_concrete
setblock 531 226 313 minecraft:shroomlight
fill 531 226 314 531 249 314 minecraft:white_concrete
setblock 531 226 315 minecraft:shroomlight
fill 531 226 316 531 244 316 minecraft:white_concrete
fill 532 226 311 532 249 311 minecraft:white_concrete
setblock 532 226 312 minecraft:shroomlight
fill 532 226 313 532 249 313 minecraft:white_concrete
setblock 532 226 314 minecraft:shroomlight
fill 532 226 315 532 249 315 minecraft:white_concrete
setblock 532 226 316 minecraft:shroomlight
setblock 533 226 311 minecraft:shroomlight
fill 533 226 312 533 249 312 minecraft:white_concrete
setblock 533 226 313 minecraft:shroomlight
fill 533 226 314 533 249 314 minecraft:white_concrete
setblock 533 226 315 minecraft:shroomlight
fill 533 226 316 533 244 316 minecraft:white_concrete
fill 534 226 311 534 249 311 minecraft:white_concrete
setblock 534 226 312 minecraft:shroomlight
fill 534 226 313 534 249 313 minecraft:white_concrete
setblock 534 226 314 minecraft:shroomlight
fill 534 226 315 534 249 315 minecraft:white_concrete
setblock 534 226 316 minecraft:shroomlight
fill 536 226 275 539 231 275 minecraft:shroomlight
fill 541 226 317 544 231 317 minecraft:shroomlight
fill 548 226 275 551 231 275 minecraft:shroomlight
fill 553 226 317 556 231 317 minecraft:shroomlight
fill 555 226 304 555 227 304 minecraft:orange_terracotta
fill 559 226 276 559 231 279 minecraft:shroomlight
fill 559 226 288 559 231 291 minecraft:shroomlight
fill 559 226 300 559 231 303 minecraft:shroomlight
fill 559 226 312 559 231 315 minecraft:shroomlight
fill 518 227 284 518 228 284 minecraft:white_concrete
fill 518 227 286 518 228 286 minecraft:white_concrete
fill 518 227 288 518 228 288 minecraft:white_concrete
setblock 518 227 290 minecraft:orange_terracotta
setblock 518 227 292 minecraft:orange_terracotta
setblock 518 227 294 minecraft:orange_terracotta
fill 518 227 304 518 228 304 minecraft:white_concrete
fill 518 227 306 518 228 306 minecraft:white_concrete
fill 518 227 308 518 228 308 minecraft:white_concrete
fill 518 227 310 518 228 310 minecraft:white_concrete
fill 519 227 283 519 228 283 minecraft:white_concrete
fill 519 227 285 519 228 285 minecraft:white_concrete
fill 519 227 287 519 228 287 minecraft:white_concrete
fill 519 227 289 519 228 289 minecraft:white_concrete
setblock 519 227 291 minecraft:orange_terracotta
setblock 519 227 293 minecraft:orange_terracotta
fill 519 227 295 519 228 295 minecraft:white_concrete
fill 519 227 303 519 228 303 minecraft:white_concrete
fill 519 227 305 519 228 305 minecraft:white_concrete
fill 519 227 307 519 228 307 minecraft:white_concrete
fill 519 227 309 519 228 309 minecraft:white_concrete
fill 519 227 311 519 228 311 minecraft:white_concrete
fill 520 227 284 520 228 284 minecraft:white_concrete
fill 520 227 286 520 228 286 minecraft:white_concrete
fill 520 227 288 520 228 288 minecraft:white_concrete
setblock 520 227 290 minecraft:orange_terracotta
setblock 520 227 292 minecraft:orange_terracotta
setblock 520 227 294 minecraft:orange_terracotta
fill 520 227 304 520 228 304 minecraft:white_concrete
fill 520 227 306 520 228 306 minecraft:white_concrete
fill 520 227 308 520 228 308 minecraft:white_concrete
fill 520 227 310 520 228 310 minecraft:white_concrete
fill 521 227 283 521 228 283 minecraft:white_concrete
fill 521 227 285 521 228 285 minecraft:white_concrete
fill 521 227 287 521 228 287 minecraft:white_concrete
fill 521 227 289 521 228 289 minecraft:white_concrete
setblock 521 227 291 minecraft:orange_terracotta
setblock 521 227 293 minecraft:orange_terracotta
fill 521 227 295 521 228 295 minecraft:white_concrete
fill 521 227 303 521 228 303 minecraft:white_concrete
fill 521 227 305 521 228 305 minecraft:white_concrete
fill 521 227 307 521 228 307 minecraft:white_concrete
fill 521 227 309 521 228 309 minecraft:white_concrete
fill 521 227 311 521 228 311 minecraft:white_concrete
fill 522 227 284 522 228 284 minecraft:white_concrete
fill 522 227 286 522 228 286 minecraft:white_concrete
fill 522 227 288 522 228 288 minecraft:white_concrete
setblock 522 227 290 minecraft:orange_terracotta
setblock 522 227 292 minecraft:orange_terracotta
setblock 522 227 294 minecraft:orange_terracotta
fill 522 227 304 522 228 304 minecraft:white_concrete
fill 522 227 306 522 228 306 minecraft:white_concrete
fill 522 227 308 522 228 308 minecraft:white_concrete
fill 522 227 310 522 228 310 minecraft:white_concrete
fill 523 227 283 523 228 283 minecraft:white_concrete
fill 523 227 285 523 228 285 minecraft:white_concrete
fill 523 227 287 523 228 287 minecraft:white_concrete
fill 523 227 289 523 228 289 minecraft:white_concrete
fill 523 227 291 523 228 291 minecraft:white_concrete
fill 523 227 311 523 228 311 minecraft:white_concrete
fill 524 227 284 524 228 284 minecraft:white_concrete
fill 524 227 286 524 228 286 minecraft:white_concrete
fill 524 227 288 524 228 288 minecraft:white_concrete
fill 524 227 290 524 228 290 minecraft:white_concrete
fill 524 227 312 524 228 312 minecraft:white_concrete
fill 524 227 314 524 228 314 minecraft:white_concrete
fill 524 227 316 524 228 316 minecraft:white_concrete
fill 525 227 311 525 228 311 minecraft:white_concrete
fill 525 227 313 525 228 313 minecraft:white_concrete
fill 525 227 315 525 228 315 minecraft:white_concrete
fill 526 227 312 526 228 312 minecraft:white_concrete
fill 526 227 314 526 228 314 minecraft:white_concrete
fill 526 227 316 526 228 316 minecraft:white_concrete
fill 527 227 311 527 228 311 minecraft:white_concrete
fill 527 227 313 527 228 313 minecraft:white_concrete
fill 527 227 315 527 228 315 minecraft:white_concrete
fill 528 227 312 528 228 312 minecraft:white_concrete
fill 528 227 314 528 228 314 minecraft:white_concrete
fill 528 227 316 528 228 316 minecraft:white_concrete
fill 529 227 311 529 228 311 minecraft:white_concrete
fill 529 227 313 529 228 313 minecraft:white_concrete
fill 529 227 315 529 228 315 minecraft:white_concrete
fill 530 227 312 530 228 312 minecraft:white_concrete
fill 530 227 314 530 228 314 minecraft:white_concrete
fill 530 227 316 530 228 316 minecraft:white_concrete
fill 531 227 311 531 228 311 minecraft:white_concrete
fill 531 227 313 531 228 313 minecraft:white_concrete
fill 531 227 315 531 228 315 minecraft:white_concrete
fill 532 227 312 532 228 312 minecraft:white_concrete
fill 532 227 314 532 228 314 minecraft:white_concrete
fill 532 227 316 532 228 316 minecraft:white_concrete
fill 533 227 311 533 228 311 minecraft:white_concrete
fill 533 227 313 533 228 313 minecraft:white_concrete
fill 533 227 315 533 228 315 minecraft:white_concrete
fill 534 227 312 534 228 312 minecraft:white_concrete
fill 534 227 314 534 228 314 minecraft:white_concrete
fill 534 227 316 534 228 316 minecraft:white_concrete
fill 556 227 284 556 228 290 minecraft:iron_block
fill 518 228 290 522 228 294 minecraft:white_concrete
fill 553 228 302 557 228 306 minecraft:white_concrete
setblock 517 229 277 minecraft:white_concrete
setblock 517 229 285 minecraft:white_concrete
setblock 517 229 289 minecraft:white_concrete
setblock 517 229 297 minecraft:white_concrete
setblock 517 229 301 minecraft:white_concrete
setblock 517 229 309 minecraft:white_concrete
setblock 517 229 313 minecraft:white_concrete
setblock 518 229 284 minecraft:shroomlight
setblock 518 229 286 minecraft:shroomlight
setblock 518 229 288 minecraft:shroomlight
setblock 518 229 290 minecraft:shroomlight
fill 518 229 291 518 238 291 minecraft:white_concrete
setblock 518 229 292 minecraft:shroomlight
fill 518 229 293 518 238 293 minecraft:white_concrete
setblock 518 229 294 minecraft:shroomlight
setblock 518 229 304 minecraft:shroomlight
setblock 518 229 306 minecraft:shroomlight
setblock 518 229 308 minecraft:shroomlight
setblock 518 229 310 minecraft:shroomlight
setblock 519 229 275 minecraft:white_concrete
setblock 519 229 283 minecraft:shroomlight
setblock 519 229 285 minecraft:shroomlight
setblock 519 229 287 minecraft:shroomlight
setblock 519 229 289 minecraft:shroomlight
fill 519 229 290 519 238 290 minecraft:white_concrete
setblock 519 229 291 minecraft:shroomlight
fill 519 229 292 519 238 292 minecraft:white_concrete
setblock 519 229 293 minecraft:shroomlight
fill 519 229 294 519 238 294 minecraft:white_concrete
setblock 519 229 295 minecraft:shroomlight
setblock 519 229 303 minecraft:shroomlight
setblock 519 229 305 minecraft:shroomlight
setblock 519 229 307 minecraft:shroomlight
setblock 519 229 309 minecraft:shroomlight
setblock 519 229 311 minecraft:shroomlight
setblock 520 229 278 minecraft:light[level=15]
setblock 520 229 284 minecraft:shroomlight
setblock 520 229 286 minecraft:shroomlight
setblock 520 229 288 minecraft:shroomlight
setblock 520 229 290 minecraft:shroomlight
fill 520 229 291 520 238 291 minecraft:white_concrete
setblock 520 229 292 minecraft:shroomlight
fill 520 229 293 520 238 293 minecraft:white_concrete
setblock 520 229 294 minecraft:shroomlight
setblock 520 229 299 minecraft:light[level=12]
setblock 520 229 302 minecraft:light[level=15]
setblock 520 229 304 minecraft:shroomlight
setblock 520 229 306 minecraft:shroomlight
setblock 520 229 308 minecraft:shroomlight
setblock 520 229 310 minecraft:shroomlight
setblock 520 229 313 minecraft:light[level=12]
setblock 521 229 283 minecraft:shroomlight
setblock 521 229 285 minecraft:shroomlight
setblock 521 229 287 minecraft:shroomlight
setblock 521 229 289 minecraft:shroomlight
fill 521 229 290 521 238 290 minecraft:white_concrete
setblock 521 229 291 minecraft:shroomlight
fill 521 229 292 521 238 292 minecraft:white_concrete
setblock 521 229 293 minecraft:shroomlight
fill 521 229 294 521 238 294 minecraft:white_concrete
setblock 521 229 295 minecraft:shroomlight
setblock 521 229 303 minecraft:shroomlight
setblock 521 229 305 minecraft:shroomlight
setblock 521 229 307 minecraft:shroomlight
setblock 521 229 309 minecraft:shroomlight
setblock 521 229 311 minecraft:shroomlight
setblock 522 229 284 minecraft:shroomlight
setblock 522 229 286 minecraft:shroomlight
setblock 522 229 288 minecraft:shroomlight
setblock 522 229 290 minecraft:shroomlight
fill 522 229 291 522 238 291 minecraft:white_concrete
setblock 522 229 292 minecraft:shroomlight
fill 522 229 293 522 238 293 minecraft:white_concrete
setblock 522 229 294 minecraft:shroomlight
setblock 522 229 304 minecraft:shroomlight
setblock 522 229 306 minecraft:shroomlight
setblock 522 229 308 minecraft:shroomlight
setblock 522 229 310 minecraft:shroomlight
setblock 523 229 275 minecraft:white_concrete
setblock 523 229 283 minecraft:shroomlight
setblock 523 229 285 minecraft:shroomlight
setblock 523 229 287 minecraft:shroomlight
setblock 523 229 289 minecraft:shroomlight
setblock 523 229 291 minecraft:shroomlight
setblock 523 229 311 minecraft:shroomlight
setblock 523 229 317 minecraft:white_concrete
setblock 524 229 284 minecraft:shroomlight
setblock 524 229 286 minecraft:shroomlight
setblock 524 229 288 minecraft:shroomlight
setblock 524 229 290 minecraft:shroomlight
setblock 524 229 312 minecraft:shroomlight
setblock 524 229 314 minecraft:shroomlight
setblock 524 229 316 minecraft:shroomlight
setblock 525 229 311 minecraft:shroomlight
setblock 525 229 313 minecraft:shroomlight
setblock 525 229 315 minecraft:shroomlight
setblock 526 229 312 minecraft:shroomlight
setblock 526 229 314 minecraft:shroomlight
setblock 526 229 316 minecraft:shroomlight
setblock 527 229 278 minecraft:light[level=12]
fill 527 229 283 528 230 284 minecraft:red_concrete
setblock 527 229 285 minecraft:light[level=12]
setblock 527 229 311 minecraft:shroomlight
setblock 527 229 313 minecraft:shroomlight
setblock 527 229 315 minecraft:shroomlight
setblock 527 229 317 minecraft:white_concrete
setblock 528 229 278 minecraft:light[level=15]
setblock 528 229 286 minecraft:light[level=15]
setblock 528 229 312 minecraft:shroomlight
setblock 528 229 314 minecraft:shroomlight
setblock 528 229 316 minecraft:shroomlight
setblock 529 229 311 minecraft:shroomlight
setblock 529 229 313 minecraft:shroomlight
setblock 529 229 315 minecraft:shroomlight
setblock 530 229 312 minecraft:shroomlight
setblock 530 229 314 minecraft:shroomlight
setblock 530 229 316 minecraft:shroomlight
setblock 531 229 275 minecraft:white_concrete
setblock 531 229 311 minecraft:shroomlight
setblock 531 229 313 minecraft:shroomlight
setblock 531 229 315 minecraft:shroomlight
setblock 532 229 312 minecraft:shroomlight
setblock 532 229 314 minecraft:shroomlight
setblock 532 229 316 minecraft:shroomlight
setblock 533 229 311 minecraft:shroomlight
setblock 533 229 313 minecraft:shroomlight
setblock 533 229 315 minecraft:shroomlight
setblock 534 229 278 minecraft:light[level=12]
setblock 534 229 285 minecraft:light[level=12]
setblock 534 229 292 minecraft:light[level=12]
setblock 534 229 299 minecraft:light[level=12]
setblock 534 229 306 minecraft:light[level=12]
setblock 534 229 312 minecraft:shroomlight
setblock 534 229 314 minecraft:shroomlight
setblock 534 229 316 minecraft:shroomlight
setblock 535 229 275 minecraft:white_concrete
setblock 535 229 317 minecraft:white_concrete
setblock 536 229 278 minecraft:light[level=15]
setblock 536 229 286 minecraft:light[level=15]
setblock 536 229 294 minecraft:light[level=15]
setblock 536 229 302 minecraft:light[level=15]
setblock 536 229 310 minecraft:light[level=15]
setblock 539 229 317 minecraft:white_concrete
setblock 541 229 278 minecraft:light[level=12]
setblock 541 229 285 minecraft:light[level=12]
setblock 541 229 313 minecraft:light[level=12]
setblock 543 229 275 minecraft:white_concrete
setblock 544 229 278 minecraft:light[level=15]
setblock 544 229 286 minecraft:light[level=15]
setblock 547 229 275 minecraft:white_concrete
setblock 547 229 317 minecraft:white_concrete
setblock 548 229 278 minecraft:light[level=12]
setblock 548 229 285 minecraft:light[level=12]
setblock 548 229 313 minecraft:light[level=12]
setblock 551 229 317 minecraft:white_concrete
setblock 552 229 278 minecraft:light[level=15]
setblock 552 229 286 minecraft:light[level=15]
setblock 552 229 294 minecraft:light[level=15]
setblock 552 229 302 minecraft:light[level=15]
setblock 552 229 310 minecraft:light[level=15]
fill 554 229 302 556 229 306 minecraft:white_concrete
setblock 555 229 275 minecraft:white_concrete
setblock 555 229 278 minecraft:light[level=12]
setblock 555 229 285 minecraft:light[level=12]
setblock 555 229 292 minecraft:light[level=12]
setblock 555 229 299 minecraft:light[level=12]
setblock 555 229 313 minecraft:light[level=12]
setblock 559 229 275 minecraft:white_concrete
setblock 559 229 281 minecraft:white_concrete
setblock 559 229 285 minecraft:white_concrete
setblock 559 229 293 minecraft:white_concrete
setblock 559 229 297 minecraft:white_concrete
setblock 559 229 305 minecraft:white_concrete
setblock 559 229 309 minecraft:white_concrete
setblock 559 229 317 minecraft:white_concrete
setblock 517 230 276 minecraft:white_concrete
fill 517 230 277 517 237 277 minecraft:brown_terracotta
setblock 517 230 278 minecraft:white_concrete
setblock 517 230 280 minecraft:white_concrete
fill 517 230 285 517 237 285 minecraft:brown_terracotta
fill 517 230 286 518 230 286 minecraft:white_concrete
fill 517 230 288 518 230 288 minecraft:white_concrete
fill 517 230 289 517 237 289 minecraft:brown_terracotta
fill 517 230 290 518 230 290 minecraft:white_concrete
fill 517 230 292 518 230 292 minecraft:white_concrete
fill 517 230 297 517 237 297 minecraft:brown_terracotta
setblock 517 230 298 minecraft:white_concrete
setblock 517 230 300 minecraft:white_concrete
fill 517 230 301 517 237 301 minecraft:brown_terracotta
setblock 517 230 302 minecraft:white_concrete
fill 517 230 304 518 230 304 minecraft:white_concrete
fill 517 230 309 517 237 309 minecraft:brown_terracotta
fill 517 230 310 518 230 310 minecraft:white_concrete
setblock 517 230 312 minecraft:white_concrete
fill 517 230 313 517 237 313 minecraft:brown_terracotta
setblock 517 230 314 minecraft:white_concrete
setblock 517 230 316 minecraft:white_concrete
setblock 518 230 275 minecraft:white_concrete
fill 518 230 284 518 231 284 minecraft:white_concrete
fill 518 230 294 518 231 294 minecraft:white_concrete
fill 518 230 306 518 231 306 minecraft:white_concrete
fill 518 230 308 518 231 308 minecraft:white_concrete
fill 519 230 275 519 237 275 minecraft:brown_terracotta
fill 519 230 283 519 231 283 minecraft:white_concrete
fill 519 230 285 519 231 285 minecraft:white_concrete
fill 519 230 287 519 231 287 minecraft:white_concrete
fill 519 230 289 519 231 289 minecraft:white_concrete
fill 519 230 291 519 231 291 minecraft:white_concrete
fill 519 230 293 519 231 293 minecraft:white_concrete
fill 519 230 295 519 231 295 minecraft:white_concrete
fill 519 230 303 519 231 303 minecraft:white_concrete
fill 519 230 305 519 231 305 minecraft:white_concrete
fill 519 230 307 519 231 307 minecraft:white_concrete
fill 519 230 309 519 231 309 minecraft:white_concrete
fill 519 230 311 519 231 311 minecraft:white_concrete
setblock 520 230 275 minecraft:white_concrete
fill 520 230 284 520 231 284 minecraft:white_concrete
fill 520 230 286 520 231 286 minecraft:white_concrete
fill 520 230 288 520 231 288 minecraft:white_concrete
fill 520 230 290 520 231 290 minecraft:white_concrete
fill 520 230 292 520 231 292 minecraft:white_concrete
fill 520 230 294 520 231 294 minecraft:white_concrete
fill 520 230 304 520 231 304 minecraft:white_concrete
fill 520 230 306 520 231 306 minecraft:white_concrete
fill 520 230 308 520 231 308 minecraft:white_concrete
fill 520 230 310 520 231 310 minecraft:white_concrete
fill 521 230 283 521 231 283 minecraft:white_concrete
fill 521 230 285 521 231 285 minecraft:white_concrete
fill 521 230 287 521 231 287 minecraft:white_concrete
fill 521 230 289 521 231 289 minecraft:white_concrete
fill 521 230 291 521 231 291 minecraft:white_concrete
fill 521 230 293 521 231 293 minecraft:white_concrete
fill 521 230 295 521 231 295 minecraft:white_concrete
fill 521 230 303 521 231 303 minecraft:white_concrete
fill 521 230 305 521 231 305 minecraft:white_concrete
fill 521 230 307 521 231 307 minecraft:white_concrete
fill 521 230 309 521 231 309 minecraft:white_concrete
fill 521 230 311 521 231 311 minecraft:white_concrete
setblock 522 230 275 minecraft:white_concrete
fill 522 230 284 522 231 284 minecraft:white_concrete
fill 522 230 286 522 231 286 minecraft:white_concrete
fill 522 230 288 522 231 288 minecraft:white_concrete
fill 522 230 290 522 231 290 minecraft:white_concrete
fill 522 230 292 524 231 292 minecraft:white_concrete
fill 522 230 294 524 231 294 minecraft:white_concrete
fill 522 230 304 524 231 304 minecraft:white_concrete
fill 522 230 306 524 231 306 minecraft:white_concrete
fill 522 230 308 524 231 308 minecraft:white_concrete
fill 522 230 310 524 231 310 minecraft:white_concrete
setblock 522 230 317 minecraft:white_concrete
fill 523 230 275 523 237 275 minecraft:brown_terracotta
fill 523 230 283 523 231 283 minecraft:white_concrete
fill 523 230 285 523 231 285 minecraft:white_concrete
fill 523 230 287 523 231 287 minecraft:white_concrete
fill 523 230 289 523 231 289 minecraft:white_concrete
fill 523 230 291 523 231 291 minecraft:white_concrete
fill 523 230 293 524 231 293 minecraft:white_concrete
fill 523 230 295 524 231 295 minecraft:white_concrete
fill 523 230 303 524 231 303 minecraft:white_concrete
fill 523 230 305 524 231 305 minecraft:white_concrete
fill 523 230 307 524 231 307 minecraft:white_concrete
fill 523 230 309 524 231 309 minecraft:white_concrete
fill 523 230 311 523 231 311 minecraft:white_concrete
fill 523 230 317 523 237 317 minecraft:brown_terracotta
fill 524 230 284 524 231 284 minecraft:white_concrete
fill 524 230 286 524 231 286 minecraft:white_concrete
fill 524 230 288 524 231 288 minecraft:white_concrete
fill 524 230 290 524 231 290 minecraft:white_concrete
fill 524 230 312 524 231 312 minecraft:white_concrete
fill 524 230 314 524 231 314 minecraft:white_concrete
fill 524 230 316 524 230 317 minecraft:white_concrete
fill 525 230 311 525 231 311 minecraft:white_concrete
fill 525 230 313 525 231 313 minecraft:white_concrete
fill 525 230 315 525 231 315 minecraft:white_concrete
fill 526 230 312 526 231 312 minecraft:white_concrete
fill 526 230 314 526 231 314 minecraft:white_concrete
fill 526 230 316 526 230 317 minecraft:white_concrete
fill 527 230 311 527 231 311 minecraft:white_concrete
fill 527 230 313 527 231 313 minecraft:white_concrete
fill 527 230 315 527 231 315 minecraft:white_concrete
fill 527 230 317 527 237 317 minecraft:brown_terracotta
setblock 528 230 275 minecraft:white_concrete
fill 528 230 312 528 231 312 minecraft:white_concrete
fill 528 230 314 528 231 314 minecraft:white_concrete
fill 528 230 316 528 230 317 minecraft:white_concrete
fill 529 230 311 529 231 311 minecraft:white_concrete
fill 529 230 313 529 231 313 minecraft:white_concrete
fill 529 230 315 529 231 315 minecraft:white_concrete
setblock 530 230 275 minecraft:white_concrete
fill 530 230 312 530 231 312 minecraft:white_concrete
fill 530 230 314 530 231 314 minecraft:white_concrete
fill 530 230 316 530 231 316 minecraft:white_concrete
fill 531 230 275 531 237 275 minecraft:brown_terracotta
fill 531 230 311 531 231 311 minecraft:white_concrete
fill 531 230 313 531 231 313 minecraft:white_concrete
fill 531 230 315 531 231 315 minecraft:white_concrete
setblock 532 230 275 minecraft:white_concrete
fill 532 230 312 532 231 312 minecraft:white_concrete
fill 532 230 314 532 231 314 minecraft:white_concrete
fill 532 230 316 532 231 316 minecraft:white_concrete
fill 533 230 311 533 231 311 minecraft:white_concrete
fill 533 230 313 533 231 313 minecraft:white_concrete
fill 533 230 315 533 231 315 minecraft:white_concrete
setblock 534 230 275 minecraft:white_concrete
fill 534 230 312 534 231 312 minecraft:white_concrete
fill 534 230 314 534 231 314 minecraft:white_concrete
fill 534 230 316 534 230 317 minecraft:white_concrete
fill 535 230 275 535 237 275 minecraft:brown_terracotta
fill 535 230 317 535 237 317 minecraft:brown_terracotta
setblock 536 230 317 minecraft:white_concrete
setblock 538 230 317 minecraft:white_concrete
fill 539 230 317 539 237 317 minecraft:brown_terracotta
setblock 540 230 275 minecraft:white_concrete
setblock 540 230 317 minecraft:white_concrete
setblock 542 230 275 minecraft:white_concrete
fill 543 230 275 543 237 275 minecraft:brown_terracotta
setblock 544 230 275 minecraft:white_concrete
setblock 546 230 275 minecraft:white_concrete
setblock 546 230 317 minecraft:white_concrete
fill 547 230 275 547 237 275 minecraft:brown_terracotta
fill 547 230 317 547 237 317 minecraft:brown_terracotta
setblock 548 230 317 minecraft:white_concrete
setblock 550 230 317 minecraft:white_concrete
fill 551 230 317 551 237 317 minecraft:brown_terracotta
setblock 552 230 275 minecraft:white_concrete
setblock 552 230 317 minecraft:white_concrete
setblock 554 230 275 minecraft:white_concrete
fill 555 230 275 555 237 275 minecraft:brown_terracotta
fill 555 230 302 555 230 306 minecraft:white_concrete
setblock 556 230 275 minecraft:white_concrete
setblock 558 230 275 minecraft:white_concrete
setblock 558 230 317 minecraft:white_concrete
setblock 559 230 275 minecraft:brown_terracotta
setblock 559 230 280 minecraft:white_concrete
fill 559 230 281 559 237 281 minecraft:brown_terracotta
setblock 559 230 282 minecraft:white_concrete
setblock 559 230 284 minecraft:white_concrete
fill 559 230 285 559 237 285 minecraft:brown_terracotta
setblock 559 230 286 minecraft:white_concrete
setblock 559 230 292 minecraft:white_concrete
fill 559 230 293 559 237 293 minecraft:brown_terracotta
setblock 559 230 294 minecraft:white_concrete
setblock 559 230 296 minecraft:white_concrete
fill 559 230 297 559 237 297 minecraft:brown_terracotta
setblock 559 230 298 minecraft:white_concrete
setblock 559 230 304 minecraft:white_concrete
fill 559 230 305 559 237 305 minecraft:brown_terracotta
setblock 559 230 306 minecraft:white_concrete
setblock 559 230 308 minecraft:white_concrete
fill 559 230 309 559 237 309 minecraft:brown_terracotta
setblock 559 230 310 minecraft:white_concrete
setblock 559 230 316 minecraft:white_concrete
fill 559 230 317 559 237 317 minecraft:brown_terracotta
setblock 517 231 275 minecraft:white_concrete
fill 517 231 276 517 238 276 minecraft:brown_terracotta
fill 517 231 278 517 238 278 minecraft:brown_terracotta
setblock 517 231 279 minecraft:white_concrete
fill 517 231 280 517 238 280 minecraft:brown_terracotta
fill 517 231 286 517 238 286 minecraft:brown_terracotta
setblock 517 231 287 minecraft:white_concrete
fill 517 231 288 517 238 288 minecraft:brown_terracotta
fill 517 231 290 517 238 290 minecraft:brown_terracotta
setblock 517 231 291 minecraft:white_concrete
fill 517 231 292 517 238 292 minecraft:brown_terracotta
fill 517 231 298 517 238 298 minecraft:brown_terracotta
setblock 517 231 299 minecraft:white_concrete
fill 517 231 300 517 238 300 minecraft:brown_terracotta
fill 517 231 302 517 238 302 minecraft:brown_terracotta
setblock 517 231 303 minecraft:white_concrete
fill 517 231 304 517 238 304 minecraft:brown_terracotta
fill 517 231 310 517 238 310 minecraft:brown_terracotta
setblock 517 231 311 minecraft:white_concrete
fill 517 231 312 517 238 312 minecraft:brown_terracotta
fill 517 231 314 517 238 314 minecraft:brown_terracotta
setblock 517 231 315 minecraft:white_concrete
fill 517 231 316 517 238 316 minecraft:brown_terracotta
fill 518 231 275 518 238 275 minecraft:brown_terracotta
setblock 518 231 286 minecraft:white_concrete
setblock 518 231 288 minecraft:white_concrete
setblock 518 231 290 minecraft:white_concrete
setblock 518 231 292 minecraft:white_concrete
setblock 518 231 304 minecraft:white_concrete
setblock 518 231 310 minecraft:white_concrete
fill 520 231 275 520 238 275 minecraft:brown_terracotta
setblock 521 231 275 minecraft:white_concrete
setblock 521 231 317 minecraft:white_concrete
fill 522 231 275 522 238 275 minecraft:brown_terracotta
fill 522 231 317 522 238 317 minecraft:brown_terracotta
setblock 524 231 316 minecraft:white_concrete
fill 524 231 317 524 238 317 minecraft:brown_terracotta
setblock 525 231 317 minecraft:white_concrete
setblock 526 231 316 minecraft:white_concrete
fill 526 231 317 526 238 317 minecraft:brown_terracotta
fill 528 231 275 528 238 275 minecraft:brown_terracotta
setblock 528 231 316 minecraft:white_concrete
fill 528 231 317 528 238 317 minecraft:brown_terracotta
setblock 529 231 275 minecraft:white_concrete
fill 530 231 275 530 238 275 minecraft:brown_terracotta
fill 532 231 275 532 238 275 minecraft:brown_terracotta
setblock 533 231 275 minecraft:white_concrete
setblock 533 231 317 minecraft:white_concrete
fill 534 231 275 534 238 275 minecraft:brown_terracotta
setblock 534 231 316 minecraft:white_concrete
fill 534 231 317 534 238 317 minecraft:brown_terracotta
fill 536 231 317 536 238 317 minecraft:brown_terracotta
setblock 537 231 317 minecraft:white_concrete
fill 538 231 317 538 238 317 minecraft:brown_terracotta
fill 540 231 275 540 238 275 minecraft:brown_terracotta
fill 540 231 317 540 238 317 minecraft:brown_terracotta
setblock 541 231 275 minecraft:white_concrete
fill 542 231 275 542 238 275 minecraft:brown_terracotta
fill 544 231 275 544 238 275 minecraft:brown_terracotta
setblock 545 231 275 minecraft:white_concrete
setblock 545 231 317 minecraft:white_concrete
fill 546 231 275 546 238 275 minecraft:brown_terracotta
fill 546 231 317 546 238 317 minecraft:brown_terracotta
fill 548 231 317 548 238 317 minecraft:brown_terracotta
setblock 549 231 317 minecraft:white_concrete
fill 550 231 317 550 238 317 minecraft:brown_terracotta
fill 552 231 275 552 238 275 minecraft:brown_terracotta
fill 552 231 317 552 238 317 minecraft:brown_terracotta
setblock 553 231 275 minecraft:white_concrete
fill 554 231 275 554 238 275 minecraft:brown_terracotta
fill 556 231 275 556 238 275 minecraft:brown_terracotta
setblock 557 231 275 minecraft:white_concrete
setblock 557 231 317 minecraft:white_concrete
fill 558 231 275 558 238 275 minecraft:brown_terracotta
fill 558 231 317 558 238 317 minecraft:brown_terracotta
setblock 559 231 275 minecraft:white_concrete
fill 559 231 280 559 238 280 minecraft:brown_terracotta
fill 559 231 282 559 238 282 minecraft:brown_terracotta
setblock 559 231 283 minecraft:white_concrete
fill 559 231 284 559 238 284 minecraft:brown_terracotta
fill 559 231 286 559 238 286 minecraft:brown_terracotta
setblock 559 231 287 minecraft:white_concrete
fill 559 231 292 559 238 292 minecraft:brown_terracotta
fill 559 231 294 559 238 294 minecraft:brown_terracotta
setblock 559 231 295 minecraft:white_concrete
fill 559 231 296 559 238 296 minecraft:brown_terracotta
fill 559 231 298 559 238 298 minecraft:brown_terracotta
setblock 559 231 299 minecraft:white_concrete
fill 559 231 304 559 238 304 minecraft:brown_terracotta
fill 559 231 306 559 238 306 minecraft:brown_terracotta
setblock 559 231 307 minecraft:white_concrete
fill 559 231 308 559 238 308 minecraft:brown_terracotta
fill 559 231 310 559 238 310 minecraft:brown_terracotta
setblock 559 231 311 minecraft:white_concrete
fill 559 231 316 559 238 316 minecraft:brown_terracotta
fill 517 232 275 517 239 275 minecraft:brown_terracotta
fill 517 232 279 517 239 279 minecraft:brown_terracotta
fill 517 232 281 517 237 281 minecraft:brown_terracotta
fill 517 232 282 517 232 283 minecraft:shroomlight
fill 517 232 284 517 238 284 minecraft:brown_terracotta
fill 517 232 287 517 239 287 minecraft:brown_terracotta
fill 517 232 291 517 239 291 minecraft:brown_terracotta
fill 517 232 293 517 237 293 minecraft:brown_terracotta
fill 517 232 294 517 232 295 minecraft:shroomlight
fill 517 232 296 517 238 296 minecraft:brown_terracotta
fill 517 232 299 517 239 299 minecraft:brown_terracotta
fill 517 232 303 517 239 303 minecraft:brown_terracotta
fill 517 232 305 517 237 305 minecraft:brown_terracotta
fill 517 232 306 517 232 307 minecraft:shroomlight
fill 517 232 308 517 238 308 minecraft:brown_terracotta
fill 517 232 311 517 239 311 minecraft:brown_terracotta
fill 517 232 315 517 239 315 minecraft:brown_terracotta
fill 517 232 317 517 237 317 minecraft:brown_terracotta
setblock 518 232 284 minecraft:shroomlight
setblock 518 232 286 minecraft:shroomlight
setblock 518 232 288 minecraft:shroomlight
setblock 518 232 290 minecraft:shroomlight
setblock 518 232 292 minecraft:shroomlight
setblock 518 232 294 minecraft:shroomlight
setblock 518 232 304 minecraft:shroomlight
setblock 518 232 306 minecraft:shroomlight
setblock 518 232 308 minecraft:shroomlight
setblock 518 232 310 minecraft:shroomlight
fill 518 232 317 519 232 317 minecraft:shroomlight
setblock 519 232 283 minecraft:shroomlight
setblock 519 232 285 minecraft:shroomlight
setblock 519 232 287 minecraft:shroomlight
setblock 519 232 289 minecraft:shroomlight
setblock 519 232 291 minecraft:shroomlight
setblock 519 232 293 minecraft:shroomlight
setblock 519 232 295 minecraft:shroomlight
setblock 519 232 303 minecraft:shroomlight
setblock 519 232 305 minecraft:shroomlight
setblock 519 232 307 minecraft:shroomlight
setblock 519 232 309 minecraft:shroomlight
setblock 519 232 311 minecraft:shroomlight
setblock 520 232 284 minecraft:shroomlight
setblock 520 232 286 minecraft:shroomlight
setblock 520 232 288 minecraft:shroomlight
setblock 520 232 290 minecraft:shroomlight
setblock 520 232 292 minecraft:shroomlight
setblock 520 232 294 minecraft:shroomlight
setblock 520 232 304 minecraft:shroomlight
setblock 520 232 306 minecraft:shroomlight
setblock 520 232 308 minecraft:shroomlight
setblock 520 232 310 minecraft:shroomlight
fill 520 232 317 521 238 317 minecraft:brown_terracotta
fill 521 232 275 521 239 275 minecraft:brown_terracotta
setblock 521 232 283 minecraft:shroomlight
setblock 521 232 285 minecraft:shroomlight
setblock 521 232 287 minecraft:shroomlight
setblock 521 232 289 minecraft:shroomlight
setblock 521 232 291 minecraft:shroomlight
setblock 521 232 293 minecraft:shroomlight
setblock 521 232 295 minecraft:shroomlight
setblock 521 232 303 minecraft:shroomlight
setblock 521 232 305 minecraft:shroomlight
setblock 521 232 307 minecraft:shroomlight
setblock 521 232 309 minecraft:shroomlight
setblock 521 232 311 minecraft:shroomlight
setblock 522 232 284 minecraft:shroomlight
setblock 522 232 286 minecraft:shroomlight
setblock 522 232 288 minecraft:shroomlight
setblock 522 232 290 minecraft:shroomlight
setblock 522 232 292 minecraft:shroomlight
setblock 522 232 294 minecraft:shroomlight
setblock 522 232 304 minecraft:shroomlight
setblock 522 232 306 minecraft:shroomlight
setblock 522 232 308 minecraft:shroomlight
setblock 522 232 310 minecraft:shroomlight
setblock 523 232 283 minecraft:shroomlight
setblock 523 232 285 minecraft:shroomlight
setblock 523 232 287 minecraft:shroomlight
setblock 523 232 289 minecraft:shroomlight
setblock 523 232 291 minecraft:shroomlight
fill 523 232 292 523 238 292 minecraft:white_concrete
setblock 523 232 293 minecraft:shroomlight
fill 523 232 294 523 238 294 minecraft:white_concrete
setblock 523 232 295 minecraft:shroomlight
fill 523 232 299 535 233 300 minecraft:iron_block
setblock 523 232 303 minecraft:shroomlight
fill 523 232 304 523 236 304 minecraft:white_concrete
setblock 523 232 305 minecraft:shroomlight
fill 523 232 306 523 236 306 minecraft:white_concrete
setblock 523 232 307 minecraft:shroomlight
fill 523 232 308 523 236 308 minecraft:white_concrete
setblock 523 232 309 minecraft:shroomlight
fill 523 232 310 523 236 310 minecraft:white_concrete
setblock 523 232 311 minecraft:shroomlight
fill 524 232 275 524 238 275 minecraft:brown_terracotta
setblock 524 232 284 minecraft:shroomlight
setblock 524 232 286 minecraft:shroomlight
setblock 524 232 288 minecraft:shroomlight
setblock 524 232 290 minecraft:shroomlight
setblock 524 232 292 minecraft:shroomlight
fill 524 232 293 524 238 293 minecraft:white_concrete
setblock 524 232 294 minecraft:shroomlight
fill 524 232 295 524 238 295 minecraft:white_concrete
fill 524 232 303 524 236 303 minecraft:white_concrete
setblock 524 232 304 minecraft:shroomlight
fill 524 232 305 524 236 305 minecraft:white_concrete
setblock 524 232 306 minecraft:shroomlight
fill 524 232 307 524 236 307 minecraft:white_concrete
setblock 524 232 308 minecraft:shroomlight
fill 524 232 309 524 236 309 minecraft:white_concrete
setblock 524 232 310 minecraft:shroomlight
setblock 524 232 312 minecraft:shroomlight
setblock 524 232 314 minecraft:shroomlight
setblock 524 232 316 minecraft:shroomlight
fill 525 232 275 526 232 275 minecraft:shroomlight
setblock 525 232 311 minecraft:shroomlight
setblock 525 232 313 minecraft:shroomlight
setblock 525 232 315 minecraft:shroomlight
fill 525 232 317 525 239 317 minecraft:brown_terracotta
setblock 526 232 312 minecraft:shroomlight
setblock 526 232 314 minecraft:shroomlight
setblock 526 232 316 minecraft:shroomlight
fill 527 232 275 527 237 275 minecraft:brown_terracotta
setblock 527 232 311 minecraft:shroomlight
setblock 527 232 313 minecraft:shroomlight
setblock 527 232 315 minecraft:shroomlight
setblock 528 232 312 minecraft:shroomlight
setblock 528 232 314 minecraft:shroomlight
setblock 528 232 316 minecraft:shroomlight
fill 529 232 275 529 239 275 minecraft:brown_terracotta
setblock 529 232 311 minecraft:shroomlight
setblock 529 232 313 minecraft:shroomlight
setblock 529 232 315 minecraft:shroomlight
fill 529 232 317 529 239 317 minecraft:brown_terracotta
setblock 530 232 312 minecraft:shroomlight
setblock 530 232 314 minecraft:shroomlight
fill 530 232 316 530 232 317 minecraft:shroomlight
setblock 531 232 311 minecraft:shroomlight
setblock 531 232 313 minecraft:shroomlight
setblock 531 232 315 minecraft:shroomlight
setblock 531 232 317 minecraft:shroomlight
setblock 532 232 312 minecraft:shroomlight
setblock 532 232 314 minecraft:shroomlight
setblock 532 232 316 minecraft:shroomlight
fill 532 232 317 533 238 317 minecraft:brown_terracotta
fill 533 232 275 533 239 275 minecraft:brown_terracotta
setblock 533 232 311 minecraft:shroomlight
setblock 533 232 313 minecraft:shroomlight
setblock 533 232 315 minecraft:shroomlight
setblock 534 232 312 minecraft:shroomlight
setblock 534 232 314 minecraft:shroomlight
setblock 534 232 316 minecraft:shroomlight
fill 536 232 275 536 238 275 minecraft:brown_terracotta
fill 536 232 299 549 233 299 minecraft:iron_block
fill 537 232 275 538 232 275 minecraft:shroomlight
fill 537 232 317 537 239 317 minecraft:brown_terracotta
fill 538 232 300 549 232 300 minecraft:iron_block
fill 539 232 275 539 237 275 minecraft:brown_terracotta
fill 541 232 275 541 239 275 minecraft:brown_terracotta
fill 541 232 317 541 239 317 minecraft:brown_terracotta
fill 542 232 317 543 232 317 minecraft:shroomlight
fill 544 232 317 545 238 317 minecraft:brown_terracotta
fill 545 232 275 545 239 275 minecraft:brown_terracotta
fill 548 232 275 548 238 275 minecraft:brown_terracotta
fill 549 232 275 550 232 275 minecraft:shroomlight
fill 549 232 317 549 239 317 minecraft:brown_terracotta
fill 551 232 275 551 237 275 minecraft:brown_terracotta
fill 553 232 275 553 239 275 minecraft:brown_terracotta
fill 553 232 317 553 239 317 minecraft:brown_terracotta
fill 554 232 317 555 232 317 minecraft:shroomlight
fill 556 232 317 557 238 317 minecraft:brown_terracotta
fill 557 232 275 557 239 275 minecraft:brown_terracotta
fill 559 232 275 559 237 276 minecraft:brown_terracotta
fill 559 232 277 559 232 278 minecraft:shroomlight
fill 559 232 279 559 239 279 minecraft:brown_terracotta
fill 559 232 283 559 239 283 minecraft:brown_terracotta
fill 559 232 287 559 238 288 minecraft:brown_terracotta
fill 559 232 289 559 232 290 minecraft:shroomlight
fill 559 232 291 559 239 291 minecraft:brown_terracotta
fill 559 232 295 559 239 295 minecraft:brown_terracotta
fill 559 232 299 559 238 300 minecraft:brown_terracotta
fill 559 232 301 559 232 302 minecraft:shroomlight
fill 559 232 303 559 239 303 minecraft:brown_terracotta
fill 559 232 307 559 239 307 minecraft:brown_terracotta
fill 559 232 311 559 238 312 minecraft:brown_terracotta
fill 559 232 313 559 232 314 minecraft:shroomlight
fill 559 232 315 559 239 315 minecraft:brown_terracotta
fill 517 233 282 517 238 283 minecraft:brown_terracotta
fill 517 233 294 517 238 295 minecraft:brown_terracotta
fill 517 233 306 517 238 307 minecraft:brown_terracotta
fill 518 233 284 518 234 284 minecraft:white_concrete
fill 518 233 286 518 234 286 minecraft:white_concrete
fill 518 233 288 518 234 288 minecraft:white_concrete
fill 518 233 290 518 234 290 minecraft:white_concrete
fill 518 233 292 518 234 292 minecraft:white_concrete
fill 518 233 294 518 234 294 minecraft:white_concrete
fill 518 233 304 518 234 304 minecraft:white_concrete
fill 518 233 306 518 234 306 minecraft:white_concrete
fill 518 233 308 518 234 308 minecraft:white_concrete
fill 518 233 310 518 234 310 minecraft:white_concrete
fill 518 233 317 519 237 317 minecraft:brown_terracotta
fill 519 233 283 519 234 283 minecraft:white_concrete
fill 519 233 285 519 234 285 minecraft:white_concrete
fill 519 233 287 519 234 287 minecraft:white_concrete
fill 519 233 289 519 234 289 minecraft:white_concrete
fill 519 233 291 519 234 291 minecraft:white_concrete
fill 519 233 293 519 234 293 minecraft:white_concrete
fill 519 233 295 519 234 295 minecraft:white_concrete
fill 519 233 303 519 234 303 minecraft:white_concrete
fill 519 233 305 519 234 305 minecraft:white_concrete
fill 519 233 307 519 234 307 minecraft:white_concrete
fill 519 233 309 519 234 309 minecraft:white_concrete
fill 519 233 311 519 234 311 minecraft:white_concrete
fill 520 233 284 520 234 284 minecraft:white_concrete
fill 520 233 286 520 234 286 minecraft:white_concrete
fill 520 233 288 520 234 288 minecraft:white_concrete
fill 520 233 290 520 234 290 minecraft:white_concrete
fill 520 233 292 520 234 292 minecraft:white_concrete
fill 520 233 294 520 234 294 minecraft:white_concrete
fill 520 233 304 520 234 304 minecraft:white_concrete
fill 520 233 306 520 234 306 minecraft:white_concrete
fill 520 233 308 520 234 308 minecraft:white_concrete
fill 520 233 310 520 234 310 minecraft:white_concrete
fill 521 233 283 521 234 283 minecraft:white_concrete
fill 521 233 285 521 234 285 minecraft:white_concrete
fill 521 233 287 521 234 287 minecraft:white_concrete
fill 521 233 289 521 234 289 minecraft:white_concrete
fill 521 233 291 521 234 291 minecraft:white_concrete
fill 521 233 293 521 234 293 minecraft:white_concrete
fill 521 233 295 521 234 295 minecraft:white_concrete
fill 521 233 303 521 234 303 minecraft:white_concrete
fill 521 233 305 521 234 305 minecraft:white_concrete
fill 521 233 307 521 234 307 minecraft:white_concrete
fill 521 233 309 521 234 309 minecraft:white_concrete
fill 521 233 311 521 234 311 minecraft:white_concrete
fill 522 233 284 522 234 284 minecraft:white_concrete
fill 522 233 286 522 234 286 minecraft:white_concrete
fill 522 233 288 522 234 288 minecraft:white_concrete
fill 522 233 290 522 234 290 minecraft:white_concrete
fill 522 233 292 522 234 292 minecraft:white_concrete
fill 522 233 294 522 234 294 minecraft:white_concrete
fill 522 233 304 522 234 304 minecraft:white_concrete
fill 522 233 306 522 234 306 minecraft:white_concrete
fill 522 233 308 522 234 308 minecraft:white_concrete
fill 522 233 310 522 234 310 minecraft:white_concrete
fill 523 233 283 523 234 283 minecraft:white_concrete
fill 523 233 285 523 234 285 minecraft:white_concrete
fill 523 233 287 523 234 287 minecraft:white_concrete
fill 523 233 289 523 234 289 minecraft:white_concrete
fill 523 233 291 523 234 291 minecraft:white_concrete
fill 523 233 293 523 234 293 minecraft:white_concrete
fill 523 233 295 523 234 295 minecraft:white_concrete
fill 523 233 303 523 234 303 minecraft:white_concrete
fill 523 233 305 523 234 305 minecraft:white_concrete
fill 523 233 307 523 234 307 minecraft:white_concrete
fill 523 233 309 523 234 309 minecraft:white_concrete
fill 523 233 311 523 234 311 minecraft:white_concrete
fill 524 233 284 524 234 284 minecraft:white_concrete
fill 524 233 286 524 234 286 minecraft:white_concrete
fill 524 233 288 524 234 288 minecraft:white_concrete
fill 524 233 290 524 234 290 minecraft:white_concrete
fill 524 233 292 524 234 292 minecraft:white_concrete
fill 524 233 294 524 234 294 minecraft:white_concrete
fill 524 233 304 524 234 304 minecraft:white_concrete
fill 524 233 306 524 234 306 minecraft:white_concrete
fill 524 233 308 524 234 308 minecraft:white_concrete
fill 524 233 310 524 234 310 minecraft:white_concrete
fill 524 233 312 524 234 312 minecraft:white_concrete
fill 524 233 314 524 234 314 minecraft:white_concrete
fill 524 233 316 524 234 316 minecraft:white_concrete
fill 525 233 275 526 238 275 minecraft:brown_terracotta
fill 525 233 311 525 234 311 minecraft:white_concrete
fill 525 233 313 525 234 313 minecraft:white_concrete
fill 525 233 315 525 234 315 minecraft:white_concrete
fill 526 233 312 526 234 312 minecraft:white_concrete
fill 526 233 314 526 234 314 minecraft:white_concrete
fill 526 233 316 526 234 316 minecraft:white_concrete
fill 527 233 311 527 234 311 minecraft:white_concrete
fill 527 233 313 527 234 313 minecraft:white_concrete
fill 527 233 315 527 234 315 minecraft:white_concrete
fill 528 233 312 528 234 312 minecraft:white_concrete
fill 528 233 314 528 234 314 minecraft:white_concrete
fill 528 233 316 528 234 316 minecraft:white_concrete
fill 529 233 311 529 234 311 minecraft:white_concrete
fill 529 233 313 529 234 313 minecraft:white_concrete
fill 529 233 315 529 234 315 minecraft:white_concrete
fill 530 233 312 530 234 312 minecraft:white_concrete
fill 530 233 314 530 234 314 minecraft:white_concrete
fill 530 233 316 530 234 316 minecraft:white_concrete
fill 530 233 317 531 237 317 minecraft:brown_terracotta
fill 531 233 311 531 234 311 minecraft:white_concrete
fill 531 233 313 531 234 313 minecraft:white_concrete
fill 531 233 315 531 234 315 minecraft:white_concrete
fill 532 233 312 532 234 312 minecraft:white_concrete
fill 532 233 314 532 234 314 minecraft:white_concrete
fill 532 233 316 532 234 316 minecraft:white_concrete
fill 533 233 311 533 234 311 minecraft:white_concrete
fill 533 233 313 533 234 313 minecraft:white_concrete
fill 533 233 315 533 234 315 minecraft:white_concrete
fill 534 233 312 534 234 312 minecraft:white_concrete
fill 534 233 314 534 234 314 minecraft:white_concrete
fill 534 233 316 534 234 316 minecraft:white_concrete
fill 537 233 275 538 238 275 minecraft:brown_terracotta
fill 539 233 300 549 233 300 minecraft:iron_block
fill 542 233 317 543 237 317 minecraft:brown_terracotta
fill 549 233 275 550 238 275 minecraft:brown_terracotta
fill 554 233 317 555 237 317 minecraft:brown_terracotta
fill 559 233 277 559 237 278 minecraft:brown_terracotta
fill 559 233 289 559 237 290 minecraft:brown_terracotta
fill 559 233 301 559 237 302 minecraft:brown_terracotta
fill 559 233 313 559 237 314 minecraft:brown_terracotta
setblock 518 235 284 minecraft:shroomlight
setblock 518 235 286 minecraft:shroomlight
setblock 518 235 288 minecraft:shroomlight
setblock 518 235 290 minecraft:shroomlight
setblock 518 235 292 minecraft:shroomlight
setblock 518 235 294 minecraft:shroomlight
setblock 518 235 304 minecraft:shroomlight
setblock 518 235 306 minecraft:shroomlight
setblock 518 235 308 minecraft:shroomlight
setblock 518 235 310 minecraft:shroomlight
setblock 519 235 283 minecraft:shroomlight
setblock 519 235 285 minecraft:shroomlight
setblock 519 235 287 minecraft:shroomlight
setblock 519 235 289 minecraft:shroomlight
setblock 519 235 291 minecraft:shroomlight
setblock 519 235 293 minecraft:shroomlight
setblock 519 235 295 minecraft:shroomlight
setblock 519 235 303 minecraft:shroomlight
setblock 519 235 305 minecraft:shroomlight
setblock 519 235 307 minecraft:shroomlight
setblock 519 235 309 minecraft:shroomlight
setblock 519 235 311 minecraft:shroomlight
setblock 520 235 278 minecraft:light[level=12]
setblock 520 235 284 minecraft:shroomlight
setblock 520 235 286 minecraft:shroomlight
setblock 520 235 288 minecraft:shroomlight
setblock 520 235 290 minecraft:shroomlight
setblock 520 235 292 minecraft:shroomlight
setblock 520 235 294 minecraft:shroomlight
setblock 520 235 299 minecraft:light[level=12]
setblock 520 235 304 minecraft:shroomlight
setblock 520 235 306 minecraft:shroomlight
setblock 520 235 308 minecraft:shroomlight
setblock 520 235 310 minecraft:shroomlight
setblock 520 235 313 minecraft:light[level=12]
setblock 521 235 283 minecraft:shroomlight
setblock 521 235 285 minecraft:shroomlight
setblock 521 235 287 minecraft:shroomlight
setblock 521 235 289 minecraft:shroomlight
setblock 521 235 291 minecraft:shroomlight
setblock 521 235 293 minecraft:shroomlight
setblock 521 235 295 minecraft:shroomlight
setblock 521 235 303 minecraft:shroomlight
setblock 521 235 305 minecraft:shroomlight
setblock 521 235 307 minecraft:shroomlight
setblock 521 235 309 minecraft:shroomlight
setblock 521 235 311 minecraft:shroomlight
setblock 522 235 284 minecraft:shroomlight
setblock 522 235 286 minecraft:shroomlight
setblock 522 235 288 minecraft:shroomlight
setblock 522 235 290 minecraft:shroomlight
setblock 522 235 292 minecraft:shroomlight
setblock 522 235 294 minecraft:shroomlight
setblock 522 235 304 minecraft:shroomlight
setblock 522 235 306 minecraft:shroomlight
setblock 522 235 308 minecraft:shroomlight
setblock 522 235 310 minecraft:shroomlight
setblock 523 235 283 minecraft:shroomlight
setblock 523 235 285 minecraft:shroomlight
setblock 523 235 287 minecraft:shroomlight
setblock 523 235 289 minecraft:shroomlight
setblock 523 235 291 minecraft:shroomlight
setblock 523 235 293 minecraft:shroomlight
setblock 523 235 295 minecraft:shroomlight
setblock 523 235 303 minecraft:shroomlight
setblock 523 235 305 minecraft:shroomlight
setblock 523 235 307 minecraft:shroomlight
setblock 523 235 309 minecraft:shroomlight
setblock 523 235 311 minecraft:shroomlight
setblock 524 235 284 minecraft:shroomlight
setblock 524 235 286 minecraft:shroomlight
setblock 524 235 288 minecraft:shroomlight
setblock 524 235 290 minecraft:shroomlight
setblock 524 235 292 minecraft:shroomlight
setblock 524 235 294 minecraft:shroomlight
setblock 524 235 304 minecraft:shroomlight
setblock 524 235 306 minecraft:shroomlight
setblock 524 235 308 minecraft:shroomlight
setblock 524 235 310 minecraft:shroomlight
setblock 524 235 312 minecraft:shroomlight
setblock 524 235 314 minecraft:shroomlight
setblock 524 235 316 minecraft:shroomlight
setblock 525 235 311 minecraft:shroomlight
setblock 525 235 313 minecraft:shroomlight
setblock 525 235 315 minecraft:shroomlight
setblock 526 235 312 minecraft:shroomlight
setblock 526 235 314 minecraft:shroomlight
setblock 526 235 316 minecraft:shroomlight
setblock 527 235 278 minecraft:light[level=12]
setblock 527 235 285 minecraft:light[level=12]
setblock 527 235 292 minecraft:light[level=12]
setblock 527 235 299 minecraft:light[level=12]
setblock 527 235 306 minecraft:light[level=12]
setblock 527 235 311 minecraft:shroomlight
setblock 527 235 313 minecraft:shroomlight
setblock 527 235 315 minecraft:shroomlight
setblock 528 235 312 minecraft:shroomlight
setblock 528 235 314 minecraft:shroomlight
setblock 528 235 316 minecraft:shroomlight
setblock 529 235 311 minecraft:shroomlight
setblock 529 235 313 minecraft:shroomlight
setblock 529 235 315 minecraft:shroomlight
setblock 530 235 312 minecraft:shroomlight
setblock 530 235 314 minecraft:shroomlight
setblock 530 235 316 minecraft:shroomlight
setblock 531 235 311 minecraft:shroomlight
setblock 531 235 313 minecraft:shroomlight
setblock 531 235 315 minecraft:shroomlight
fill 532 235 305 532 236 305 minecraft:shroomlight
setblock 532 235 312 minecraft:shroomlight
setblock 532 235 314 minecraft:shroomlight
setblock 532 235 316 minecraft:shroomlight
setblock 533 235 311 minecraft:shroomlight
setblock 533 235 313 minecraft:shroomlight
setblock 533 235 315 minecraft:shroomlight
setblock 534 235 278 minecraft:light[level=12]
setblock 534 235 285 minecraft:light[level=12]
setblock 534 235 292 minecraft:light[level=12]
setblock 534 235 299 minecraft:light[level=12]
setblock 534 235 306 minecraft:light[level=12]
setblock 534 235 312 minecraft:shroomlight
setblock 534 235 314 minecraft:shroomlight
setblock 534 235 316 minecraft:shroomlight
setblock 541 235 278 minecraft:light[level=12]
setblock 541 235 285 minecraft:light[level=12]
setblock 541 235 292 minecraft:light[level=12]
setblock 541 235 299 minecraft:light[level=12]
setblock 541 235 306 minecraft:light[level=12]
setblock 541 235 313 minecraft:light[level=12]
setblock 548 235 278 minecraft:light[level=12]
setblock 548 235 285 minecraft:light[level=12]
setblock 548 235 292 minecraft:light[level=12]
setblock 548 235 299 minecraft:light[level=12]
setblock 548 235 306 minecraft:light[level=12]
setblock 548 235 313 minecraft:light[level=12]
setblock 555 235 278 minecraft:light[level=12]
setblock 555 235 285 minecraft:light[level=12]
setblock 555 235 292 minecraft:light[level=12]
setblock 555 235 299 minecraft:light[level=12]
setblock 555 235 306 minecraft:light[level=12]
setblock 555 235 313 minecraft:light[level=12]
fill 518 236 284 518 238 284 minecraft:white_concrete
fill 518 236 286 518 271 286 minecraft:white_concrete
fill 518 236 288 518 271 288 minecraft:white_concrete
fill 518 236 290 518 238 290 minecraft:white_concrete
fill 518 236 292 518 238 292 minecraft:white_concrete
fill 518 236 294 518 238 294 minecraft:white_concrete
setblock 518 236 304 minecraft:white_concrete
setblock 518 236 306 minecraft:white_concrete
setblock 518 236 308 minecraft:white_concrete
fill 518 236 310 518 271 310 minecraft:white_concrete
fill 519 236 283 519 238 283 minecraft:white_concrete
fill 519 236 285 519 238 285 minecraft:white_concrete
fill 519 236 287 519 238 287 minecraft:white_concrete
fill 519 236 289 519 238 289 minecraft:white_concrete
fill 519 236 291 519 238 291 minecraft:white_concrete
fill 519 236 293 519 238 293 minecraft:white_concrete
fill 519 236 295 519 238 295 minecraft:white_concrete
setblock 519 236 303 minecraft:white_concrete
setblock 519 236 305 minecraft:white_concrete
setblock 519 236 307 minecraft:white_concrete
setblock 519 236 309 minecraft:white_concrete
setblock 519 236 311 minecraft:white_concrete
fill 520 236 284 520 238 284 minecraft:white_concrete
fill 520 236 286 520 238 286 minecraft:white_concrete
fill 520 236 288 520 238 288 minecraft:white_concrete
fill 520 236 290 520 238 290 minecraft:white_concrete
fill 520 236 292 520 238 292 minecraft:white_concrete
fill 520 236 294 520 238 294 minecraft:white_concrete
setblock 520 236 304 minecraft:white_concrete
setblock 520 236 306 minecraft:white_concrete
setblock 520 236 308 minecraft:white_concrete
setblock 520 236 310 minecraft:white_concrete
fill 521 236 283 521 238 283 minecraft:white_concrete
fill 521 236 285 521 238 285 minecraft:white_concrete
fill 521 236 287 521 238 287 minecraft:white_concrete
fill 521 236 289 521 238 289 minecraft:white_concrete
fill 521 236 291 521 238 291 minecraft:white_concrete
fill 521 236 293 521 238 293 minecraft:white_concrete
fill 521 236 295 521 238 295 minecraft:white_concrete
setblock 521 236 303 minecraft:white_concrete
setblock 521 236 305 minecraft:white_concrete
setblock 521 236 307 minecraft:white_concrete
setblock 521 236 309 minecraft:white_concrete
setblock 521 236 311 minecraft:white_concrete
fill 522 236 284 522 238 284 minecraft:white_concrete
fill 522 236 286 522 238 286 minecraft:white_concrete
fill 522 236 288 522 238 288 minecraft:white_concrete
fill 522 236 290 522 238 290 minecraft:white_concrete
fill 522 236 292 522 238 292 minecraft:white_concrete
fill 522 236 294 522 238 294 minecraft:white_concrete
setblock 522 236 304 minecraft:white_concrete
setblock 522 236 306 minecraft:white_concrete
setblock 522 236 308 minecraft:white_concrete
setblock 522 236 310 minecraft:white_concrete
fill 523 236 283 523 238 283 minecraft:white_concrete
fill 523 236 285 523 238 285 minecraft:white_concrete
fill 523 236 287 523 238 287 minecraft:white_concrete
fill 523 236 289 523 238 289 minecraft:white_concrete
fill 523 236 291 523 238 291 minecraft:white_concrete
fill 523 236 293 523 238 293 minecraft:white_concrete
fill 523 236 295 523 238 295 minecraft:white_concrete
setblock 523 236 303 minecraft:white_concrete
setblock 523 236 305 minecraft:white_concrete
setblock 523 236 307 minecraft:white_concrete
setblock 523 236 309 minecraft:white_concrete
setblock 523 236 311 minecraft:white_concrete
fill 524 236 284 524 238 284 minecraft:white_concrete
fill 524 236 286 524 238 286 minecraft:white_concrete
fill 524 236 288 524 238 288 minecraft:white_concrete
fill 524 236 290 524 238 290 minecraft:white_concrete
fill 524 236 292 524 238 292 minecraft:white_concrete
fill 524 236 294 524 238 294 minecraft:white_concrete
setblock 524 236 304 minecraft:white_concrete
setblock 524 236 306 minecraft:white_concrete
setblock 524 236 308 minecraft:white_concrete
setblock 524 236 310 minecraft:white_concrete
fill 524 236 312 524 237 312 minecraft:white_concrete
fill 524 236 314 524 237 314 minecraft:white_concrete
fill 524 236 316 524 237 316 minecraft:white_concrete
fill 525 236 311 525 237 311 minecraft:white_concrete
fill 525 236 313 525 237 313 minecraft:white_concrete
fill 525 236 315 525 237 315 minecraft:white_concrete
fill 526 236 312 526 237 312 minecraft:white_concrete
fill 526 236 314 526 237 314 minecraft:white_concrete
fill 526 236 316 526 237 316 minecraft:white_concrete
fill 527 236 280 527 237 280 minecraft:brown_terracotta
fill 527 236 311 527 237 311 minecraft:white_concrete
fill 527 236 313 527 237 313 minecraft:white_concrete
fill 527 236 315 527 237 315 minecraft:white_concrete
fill 528 236 312 528 237 312 minecraft:white_concrete
fill 528 236 314 528 237 314 minecraft:white_concrete
fill 528 236 316 528 237 316 minecraft:white_concrete
fill 529 236 311 529 237 311 minecraft:white_concrete
fill 529 236 313 529 237 313 minecraft:white_concrete
fill 529 236 315 529 237 315 minecraft:white_concrete
fill 530 236 312 530 237 312 minecraft:white_concrete
fill 530 236 314 530 237 314 minecraft:white_concrete
fill 530 236 316 530 237 316 minecraft:white_concrete
fill 531 236 311 531 237 311 minecraft:white_concrete
fill 531 236 313 531 237 313 minecraft:white_concrete
fill 531 236 315 531 237 315 minecraft:white_concrete
fill 532 236 312 532 237 312 minecraft:white_concrete
fill 532 236 314 532 237 314 minecraft:white_concrete
fill 532 236 316 532 237 316 minecraft:white_concrete
fill 533 236 311 533 237 311 minecraft:white_concrete
fill 533 236 313 533 237 313 minecraft:white_concrete
fill 533 236 315 533 237 315 minecraft:white_concrete
fill 534 236 312 534 237 312 minecraft:white_concrete
fill 534 236 314 534 237 314 minecraft:white_concrete
fill 534 236 316 534 237 316 minecraft:white_concrete
fill 541 236 280 541 237 280 minecraft:brown_terracotta
fill 549 236 311 549 237 311 minecraft:brown_terracotta
fill 551 236 280 551 237 280 minecraft:brown_terracotta
fill 553 236 284 553 237 284 minecraft:brown_terracotta
fill 519 237 304 523 237 310 minecraft:red_concrete
setblock 520 237 278 minecraft:light[level=15]
setblock 520 237 302 minecraft:light[level=15]
fill 521 237 311 522 237 311 minecraft:brown_terracotta
fill 527 237 279 527 238 279 minecraft:brown_terracotta
setblock 528 237 278 minecraft:light[level=15]
setblock 528 237 286 minecraft:light[level=15]
setblock 528 237 294 minecraft:light[level=15]
fill 528 237 300 528 238 300 minecraft:shroomlight
setblock 528 237 302 minecraft:light[level=15]
setblock 528 237 310 minecraft:light[level=15]
fill 532 237 305 532 243 305 minecraft:brown_terracotta
setblock 536 237 278 minecraft:light[level=15]
setblock 536 237 286 minecraft:light[level=15]
setblock 536 237 294 minecraft:light[level=15]
setblock 536 237 302 minecraft:light[level=15]
setblock 536 237 310 minecraft:light[level=15]
fill 541 237 279 541 238 279 minecraft:brown_terracotta
setblock 544 237 278 minecraft:light[level=15]
setblock 544 237 286 minecraft:light[level=15]
setblock 544 237 294 minecraft:light[level=15]
setblock 544 237 302 minecraft:light[level=15]
setblock 544 237 310 minecraft:light[level=15]
fill 549 237 312 549 238 312 minecraft:brown_terracotta
fill 551 237 279 551 238 279 minecraft:brown_terracotta
setblock 552 237 278 minecraft:light[level=15]
setblock 552 237 286 minecraft:light[level=15]
setblock 552 237 294 minecraft:light[level=15]
setblock 552 237 302 minecraft:light[level=15]
setblock 552 237 310 minecraft:light[level=15]
fill 554 237 284 554 238 284 minecraft:brown_terracotta
setblock 517 238 277 minecraft:white_concrete
setblock 517 238 281 minecraft:white_concrete
setblock 517 238 285 minecraft:white_concrete
setblock 517 238 289 minecraft:white_concrete
setblock 517 238 293 minecraft:white_concrete
setblock 517 238 297 minecraft:white_concrete
setblock 517 238 301 minecraft:white_concrete
setblock 517 238 305 minecraft:white_concrete
setblock 517 238 309 minecraft:white_concrete
setblock 517 238 313 minecraft:white_concrete
setblock 517 238 317 minecraft:white_concrete
setblock 518 238 317 minecraft:brown_terracotta
setblock 519 238 275 minecraft:white_concrete
setblock 519 238 317 minecraft:white_concrete
fill 520 238 305 522 238 309 minecraft:red_concrete
fill 520 238 311 521 238 311 minecraft:brown_terracotta
setblock 523 238 275 minecraft:white_concrete
setblock 523 238 317 minecraft:white_concrete
setblock 524 238 312 minecraft:shroomlight
setblock 524 238 314 minecraft:shroomlight
setblock 524 238 316 minecraft:shroomlight
setblock 525 238 311 minecraft:shroomlight
setblock 525 238 313 minecraft:shroomlight
setblock 525 238 315 minecraft:shroomlight
setblock 526 238 312 minecraft:shroomlight
setblock 526 238 314 minecraft:shroomlight
setblock 526 238 316 minecraft:shroomlight
setblock 527 238 275 minecraft:white_concrete
fill 527 238 278 527 239 278 minecraft:brown_terracotta
setblock 527 238 311 minecraft:shroomlight
setblock 527 238 313 minecraft:shroomlight
setblock 527 238 315 minecraft:shroomlight
setblock 527 238 317 minecraft:white_concrete
setblock 528 238 312 minecraft:shroomlight
setblock 528 238 314 minecraft:shroomlight
setblock 528 238 316 minecraft:shroomlight
setblock 529 238 311 minecraft:shroomlight
setblock 529 238 313 minecraft:shroomlight
setblock 529 238 315 minecraft:shroomlight
setblock 530 238 312 minecraft:shroomlight
setblock 530 238 314 minecraft:shroomlight
setblock 530 238 316 minecraft:shroomlight
setblock 530 238 317 minecraft:brown_terracotta
setblock 531 238 275 minecraft:white_concrete
setblock 531 238 311 minecraft:shroomlight
setblock 531 238 313 minecraft:shroomlight
setblock 531 238 315 minecraft:shroomlight
setblock 531 238 317 minecraft:white_concrete
setblock 532 238 312 minecraft:shroomlight
setblock 532 238 314 minecraft:shroomlight
setblock 532 238 316 minecraft:shroomlight
setblock 533 238 311 minecraft:shroomlight
setblock 533 238 313 minecraft:shroomlight
setblock 533 238 315 minecraft:shroomlight
setblock 534 238 312 minecraft:shroomlight
setblock 534 238 314 minecraft:shroomlight
setblock 534 238 316 minecraft:shroomlight
setblock 535 238 275 minecraft:white_concrete
setblock 535 238 317 minecraft:white_concrete
setblock 539 238 275 minecraft:white_concrete
setblock 539 238 317 minecraft:white_concrete
fill 541 238 278 541 239 278 minecraft:brown_terracotta
setblock 542 238 317 minecraft:brown_terracotta
setblock 543 238 275 minecraft:white_concrete
setblock 543 238 317 minecraft:white_concrete
setblock 547 238 275 minecraft:white_concrete
setblock 547 238 317 minecraft:white_concrete
fill 549 238 313 549 239 313 minecraft:brown_terracotta
setblock 551 238 275 minecraft:white_concrete
fill 551 238 278 551 239 278 minecraft:brown_terracotta
setblock 551 238 317 minecraft:white_concrete
setblock 554 238 317 minecraft:brown_terracotta
setblock 555 238 275 minecraft:white_concrete
fill 555 238 284 555 239 284 minecraft:brown_terracotta
setblock 555 238 317 minecraft:white_concrete
setblock 559 238 275 minecraft:white_concrete
setblock 559 238 276 minecraft:brown_terracotta
setblock 559 238 277 minecraft:white_concrete
setblock 559 238 278 minecraft:brown_terracotta
setblock 559 238 281 minecraft:white_concrete
setblock 559 238 285 minecraft:white_concrete
setblock 559 238 289 minecraft:white_concrete
setblock 559 238 290 minecraft:brown_terracotta
setblock 559 238 293 minecraft:white_concrete
setblock 559 238 297 minecraft:white_concrete
setblock 559 238 301 minecraft:white_concrete
setblock 559 238 302 minecraft:brown_terracotta
setblock 559 238 305 minecraft:white_concrete
setblock 559 238 309 minecraft:white_concrete
setblock 559 238 313 minecraft:white_concrete
setblock 559 238 314 minecraft:brown_terracotta
setblock 559 238 317 minecraft:white_concrete
setblock 517 239 276 minecraft:white_concrete
fill 517 239 277 517 246 277 minecraft:brown_terracotta
setblock 517 239 278 minecraft:white_concrete
setblock 517 239 280 minecraft:white_concrete
fill 517 239 281 517 245 281 minecraft:brown_terracotta
setblock 517 239 282 minecraft:white_concrete
setblock 517 239 283 minecraft:brown_terracotta
setblock 517 239 284 minecraft:white_concrete
fill 517 239 285 517 246 285 minecraft:brown_terracotta
setblock 517 239 286 minecraft:white_concrete
setblock 517 239 288 minecraft:white_concrete
fill 517 239 289 517 246 289 minecraft:brown_terracotta
setblock 517 239 290 minecraft:white_concrete
setblock 517 239 292 minecraft:white_concrete
fill 517 239 293 517 245 293 minecraft:brown_terracotta
setblock 517 239 294 minecraft:white_concrete
setblock 517 239 295 minecraft:brown_terracotta
setblock 517 239 296 minecraft:white_concrete
fill 517 239 297 517 246 297 minecraft:brown_terracotta
setblock 517 239 298 minecraft:white_concrete
setblock 517 239 300 minecraft:white_concrete
fill 517 239 301 517 246 301 minecraft:brown_terracotta
setblock 517 239 302 minecraft:white_concrete
setblock 517 239 304 minecraft:white_concrete
fill 517 239 305 517 245 305 minecraft:brown_terracotta
setblock 517 239 306 minecraft:white_concrete
setblock 517 239 307 minecraft:brown_terracotta
setblock 517 239 308 minecraft:white_concrete
fill 517 239 309 517 246 309 minecraft:brown_terracotta
setblock 517 239 310 minecraft:white_concrete
setblock 517 239 312 minecraft:white_concrete
fill 517 239 313 517 246 313 minecraft:brown_terracotta
setblock 517 239 314 minecraft:white_concrete
setblock 517 239 316 minecraft:white_concrete
setblock 517 239 317 minecraft:brown_terracotta
setblock 518 239 275 minecraft:white_concrete
setblock 518 239 317 minecraft:white_concrete
fill 519 239 275 519 246 275 minecraft:brown_terracotta
fill 519 239 283 520 239 283 minecraft:brown_terracotta
fill 519 239 284 523 239 294 minecraft:red_concrete
fill 519 239 311 520 239 311 minecraft:brown_terracotta
fill 519 239 317 519 245 317 minecraft:brown_terracotta
setblock 520 239 275 minecraft:white_concrete
setblock 520 239 317 minecraft:white_concrete
fill 521 239 306 521 239 308 minecraft:red_concrete
setblock 521 239 317 minecraft:brown_terracotta
setblock 522 239 275 minecraft:white_concrete
setblock 522 239 317 minecraft:white_concrete
fill 523 239 275 523 246 275 minecraft:brown_terracotta
fill 523 239 317 523 246 317 minecraft:brown_terracotta
setblock 524 239 275 minecraft:white_concrete
fill 524 239 312 524 240 312 minecraft:white_concrete
fill 524 239 314 524 240 314 minecraft:white_concrete
fill 524 239 316 524 239 317 minecraft:white_concrete
setblock 525 239 275 minecraft:brown_terracotta
fill 525 239 311 525 240 311 minecraft:white_concrete
fill 525 239 313 525 240 313 minecraft:white_concrete
fill 525 239 315 525 240 315 minecraft:white_concrete
setblock 526 239 275 minecraft:white_concrete
fill 526 239 312 526 240 312 minecraft:white_concrete
fill 526 239 314 526 240 314 minecraft:white_concrete
fill 526 239 316 526 239 317 minecraft:white_concrete
fill 527 239 275 527 245 275 minecraft:brown_terracotta
fill 527 239 277 527 240 277 minecraft:brown_terracotta
fill 527 239 300 528 246 300 minecraft:brown_terracotta
fill 527 239 311 527 240 311 minecraft:white_concrete
fill 527 239 313 527 240 313 minecraft:white_concrete
fill 527 239 315 527 240 315 minecraft:white_concrete
fill 527 239 317 527 246 317 minecraft:brown_terracotta
setblock 528 239 275 minecraft:white_concrete
fill 528 239 312 528 240 312 minecraft:white_concrete
fill 528 239 314 528 240 314 minecraft:white_concrete
fill 528 239 316 528 239 317 minecraft:white_concrete
fill 529 239 311 529 240 311 minecraft:white_concrete
fill 529 239 313 529 240 313 minecraft:white_concrete
fill 529 239 315 529 240 315 minecraft:white_concrete
setblock 530 239 275 minecraft:white_concrete
fill 530 239 312 530 240 312 minecraft:white_concrete
fill 530 239 314 530 240 314 minecraft:white_concrete
fill 530 239 316 530 239 317 minecraft:white_concrete
fill 531 239 275 531 246 275 minecraft:brown_terracotta
fill 531 239 305 531 243 305 minecraft:brown_terracotta
fill 531 239 311 531 240 311 minecraft:white_concrete
fill 531 239 313 531 240 313 minecraft:white_concrete
fill 531 239 315 531 240 315 minecraft:white_concrete
fill 531 239 317 531 245 317 minecraft:brown_terracotta
setblock 532 239 275 minecraft:white_concrete
fill 532 239 304 532 243 304 minecraft:brown_terracotta
fill 532 239 306 532 243 306 minecraft:brown_terracotta
fill 532 239 312 532 240 312 minecraft:white_concrete
fill 532 239 314 532 240 314 minecraft:white_concrete
fill 532 239 316 532 239 317 minecraft:white_concrete
fill 533 239 305 533 243 305 minecraft:brown_terracotta
fill 533 239 311 533 240 311 minecraft:white_concrete
fill 533 239 313 533 240 313 minecraft:white_concrete
fill 533 239 315 533 240 315 minecraft:white_concrete
setblock 533 239 317 minecraft:brown_terracotta
setblock 534 239 275 minecraft:white_concrete
fill 534 239 312 534 240 312 minecraft:white_concrete
fill 534 239 314 534 240 314 minecraft:white_concrete
fill 534 239 316 534 239 317 minecraft:white_concrete
fill 535 239 275 535 246 275 minecraft:brown_terracotta
fill 535 239 317 535 246 317 minecraft:brown_terracotta
setblock 536 239 275 minecraft:white_concrete
setblock 536 239 317 minecraft:white_concrete
setblock 537 239 275 minecraft:brown_terracotta
setblock 538 239 275 minecraft:white_concrete
setblock 538 239 317 minecraft:white_concrete
fill 539 239 275 539 245 275 minecraft:brown_terracotta
fill 539 239 317 539 246 317 minecraft:brown_terracotta
setblock 540 239 275 minecraft:white_concrete
setblock 540 239 317 minecraft:white_concrete
setblock 541 239 277 minecraft:brown_terracotta
setblock 542 239 275 minecraft:white_concrete
setblock 542 239 317 minecraft:white_concrete
fill 543 239 275 543 246 275 minecraft:brown_terracotta
fill 543 239 317 543 245 317 minecraft:brown_terracotta
setblock 544 239 275 minecraft:white_concrete
setblock 544 239 317 minecraft:white_concrete
setblock 545 239 317 minecraft:brown_terracotta
setblock 546 239 275 minecraft:white_concrete
setblock 546 239 317 minecraft:white_concrete
fill 547 239 275 547 246 275 minecraft:brown_terracotta
fill 547 239 317 547 246 317 minecraft:brown_terracotta
setblock 548 239 275 minecraft:white_concrete
setblock 548 239 317 minecraft:white_concrete
setblock 549 239 275 minecraft:brown_terracotta
fill 549 239 314 549 240 314 minecraft:brown_terracotta
setblock 550 239 275 minecraft:white_concrete
setblock 550 239 317 minecraft:white_concrete
fill 551 239 275 551 245 275 minecraft:brown_terracotta
fill 551 239 277 551 240 277 minecraft:brown_terracotta
fill 551 239 317 551 246 317 minecraft:brown_terracotta
setblock 552 239 275 minecraft:white_concrete
setblock 552 239 317 minecraft:white_concrete
setblock 554 239 275 minecraft:white_concrete
setblock 554 239 317 minecraft:white_concrete
fill 555 239 275 555 246 275 minecraft:brown_terracotta
fill 555 239 317 555 245 317 minecraft:brown_terracotta
setblock 556 239 275 minecraft:white_concrete
fill 556 239 284 556 240 284 minecraft:brown_terracotta
setblock 556 239 317 minecraft:white_concrete
setblock 557 239 317 minecraft:brown_terracotta
setblock 558 239 275 minecraft:white_concrete
setblock 558 239 317 minecraft:white_concrete
setblock 559 239 275 minecraft:brown_terracotta
setblock 559 239 276 minecraft:white_concrete
fill 559 239 277 559 245 277 minecraft:brown_terracotta
setblock 559 239 278 minecraft:white_concrete
setblock 559 239 280 minecraft:white_concrete
fill 559 239 281 559 246 281 minecraft:brown_terracotta
setblock 559 239 282 minecraft:white_concrete
setblock 559 239 284 minecraft:white_concrete
fill 559 239 285 559 246 285 minecraft:brown_terracotta
setblock 559 239 286 minecraft:white_concrete
setblock 559 239 287 minecraft:brown_terracotta
setblock 559 239 288 minecraft:white_concrete
fill 559 239 289 559 245 289 minecraft:brown_terracotta
setblock 559 239 290 minecraft:white_concrete
setblock 559 239 292 minecraft:white_concrete
fill 559 239 293 559 246 293 minecraft:brown_terracotta
setblock 559 239 294 minecraft:white_concrete
setblock 559 239 296 minecraft:white_concrete
fill 559 239 297 559 246 297 minecraft:brown_terracotta
setblock 559 239 298 minecraft:white_concrete
setblock 559 239 299 minecraft:brown_terracotta
setblock 559 239 300 minecraft:white_concrete
fill 559 239 301 559 245 301 minecraft:brown_terracotta
setblock 559 239 302 minecraft:white_concrete
setblock 559 239 304 minecraft:white_concrete
fill 559 239 305 559 246 305 minecraft:brown_terracotta
setblock 559 239 306 minecraft:white_concrete
setblock 559 239 308 minecraft:white_concrete
fill 559 239 309 559 246 309 minecraft:brown_terracotta
setblock 559 239 310 minecraft:white_concrete
setblock 559 239 311 minecraft:brown_terracotta
setblock 559 239 312 minecraft:white_concrete
fill 559 239 313 559 245 313 minecraft:brown_terracotta
setblock 559 239 314 minecraft:white_concrete
setblock 559 239 316 minecraft:white_concrete
fill 559 239 317 559 246 317 minecraft:brown_terracotta
setblock 517 240 275 minecraft:white_concrete
fill 517 240 276 517 247 276 minecraft:brown_terracotta
fill 517 240 278 517 247 278 minecraft:brown_terracotta
setblock 517 240 279 minecraft:white_concrete
fill 517 240 280 517 247 280 minecraft:brown_terracotta
fill 517 240 282 517 245 282 minecraft:brown_terracotta
setblock 517 240 283 minecraft:white_concrete
fill 517 240 284 517 245 284 minecraft:brown_terracotta
fill 517 240 286 517 247 286 minecraft:brown_terracotta
setblock 517 240 287 minecraft:white_concrete
fill 517 240 288 517 247 288 minecraft:brown_terracotta
fill 517 240 290 517 247 290 minecraft:brown_terracotta
setblock 517 240 291 minecraft:white_concrete
fill 517 240 292 517 247 292 minecraft:brown_terracotta
fill 517 240 294 517 245 294 minecraft:brown_terracotta
setblock 517 240 295 minecraft:white_concrete
fill 517 240 296 517 245 296 minecraft:brown_terracotta
fill 517 240 298 517 247 298 minecraft:brown_terracotta
setblock 517 240 299 minecraft:white_concrete
fill 517 240 300 517 247 300 minecraft:brown_terracotta
fill 517 240 302 517 247 302 minecraft:brown_terracotta
setblock 517 240 303 minecraft:white_concrete
fill 517 240 304 517 247 304 minecraft:brown_terracotta
fill 517 240 306 517 245 306 minecraft:brown_terracotta
setblock 517 240 307 minecraft:white_concrete
fill 517 240 308 517 245 308 minecraft:brown_terracotta
fill 517 240 310 517 247 310 minecraft:brown_terracotta
setblock 517 240 311 minecraft:white_concrete
fill 517 240 312 517 247 312 minecraft:brown_terracotta
fill 517 240 314 517 247 314 minecraft:brown_terracotta
setblock 517 240 315 minecraft:white_concrete
fill 517 240 316 517 247 316 minecraft:brown_terracotta
setblock 517 240 317 minecraft:white_concrete
fill 518 240 275 518 247 275 minecraft:brown_terracotta
fill 518 240 283 519 240 283 minecraft:brown_terracotta
fill 518 240 317 518 245 317 minecraft:brown_terracotta
fill 519 240 285 519 245 287 minecraft:white_concrete
fill 519 240 297 519 245 299 minecraft:white_concrete
fill 519 240 309 519 245 311 minecraft:white_concrete
fill 520 240 275 520 247 275 minecraft:brown_terracotta
fill 520 240 285 522 240 293 minecraft:red_concrete
fill 520 240 307 522 240 307 minecraft:red_concrete
fill 520 240 317 520 245 317 minecraft:brown_terracotta
setblock 521 240 275 minecraft:white_concrete
setblock 521 240 317 minecraft:white_concrete
fill 522 240 275 522 247 275 minecraft:brown_terracotta
fill 522 240 317 522 247 317 minecraft:brown_terracotta
fill 524 240 275 524 245 275 minecraft:brown_terracotta
setblock 524 240 316 minecraft:white_concrete
fill 524 240 317 524 247 317 minecraft:brown_terracotta
setblock 525 240 275 minecraft:white_concrete
setblock 525 240 317 minecraft:white_concrete
fill 526 240 275 526 245 275 minecraft:brown_terracotta
setblock 526 240 316 minecraft:white_concrete
fill 526 240 317 526 247 317 minecraft:brown_terracotta
fill 527 240 276 527 241 276 minecraft:brown_terracotta
fill 528 240 275 528 247 275 minecraft:brown_terracotta
fill 528 240 299 528 246 299 minecraft:brown_terracotta
setblock 528 240 316 minecraft:white_concrete
fill 528 240 317 528 247 317 minecraft:brown_terracotta
setblock 529 240 275 minecraft:white_concrete
fill 529 240 277 531 245 277 minecraft:white_concrete
setblock 529 240 317 minecraft:white_concrete
fill 530 240 275 530 247 275 minecraft:brown_terracotta
setblock 530 240 316 minecraft:white_concrete
fill 530 240 317 530 245 317 minecraft:brown_terracotta
fill 531 240 304 531 243 304 minecraft:brown_terracotta
fill 531 240 306 531 243 306 minecraft:brown_terracotta
fill 532 240 275 532 247 275 minecraft:brown_terracotta
setblock 532 240 316 minecraft:white_concrete
fill 532 240 317 532 245 317 minecraft:brown_terracotta
setblock 533 240 275 minecraft:white_concrete
fill 533 240 304 533 243 304 minecraft:brown_terracotta
fill 533 240 306 533 243 306 minecraft:brown_terracotta
setblock 533 240 317 minecraft:white_concrete
fill 534 240 275 534 247 275 minecraft:brown_terracotta
setblock 534 240 316 minecraft:white_concrete
fill 534 240 317 534 247 317 minecraft:brown_terracotta
fill 536 240 275 536 245 275 minecraft:brown_terracotta
fill 536 240 317 536 247 317 minecraft:brown_terracotta
setblock 537 240 275 minecraft:white_concrete
fill 537 240 315 539 245 315 minecraft:white_concrete
setblock 537 240 317 minecraft:white_concrete
fill 538 240 275 538 245 275 minecraft:brown_terracotta
fill 538 240 317 538 247 317 minecraft:brown_terracotta
fill 540 240 275 540 247 275 minecraft:brown_terracotta
fill 540 240 317 540 247 317 minecraft:brown_terracotta
setblock 541 240 275 minecraft:white_concrete
fill 541 240 276 541 241 276 minecraft:brown_terracotta
fill 541 240 277 543 245 277 minecraft:white_concrete
setblock 541 240 317 minecraft:white_concrete
fill 542 240 275 542 247 275 minecraft:brown_terracotta
fill 542 240 317 542 245 317 minecraft:brown_terracotta
fill 544 240 275 544 247 275 minecraft:brown_terracotta
fill 544 240 317 544 245 317 minecraft:brown_terracotta
setblock 545 240 275 minecraft:white_concrete
setblock 545 240 317 minecraft:white_concrete
fill 546 240 275 546 247 275 minecraft:brown_terracotta
fill 546 240 317 546 247 317 minecraft:brown_terracotta
fill 548 240 275 548 245 275 minecraft:brown_terracotta
fill 548 240 317 548 247 317 minecraft:brown_terracotta
setblock 549 240 275 minecraft:white_concrete
fill 549 240 315 551 245 315 minecraft:white_concrete
setblock 549 240 317 minecraft:white_concrete
fill 550 240 275 550 245 275 minecraft:brown_terracotta
fill 550 240 317 550 247 317 minecraft:brown_terracotta
fill 551 240 276 551 241 276 minecraft:brown_terracotta
fill 552 240 275 552 247 275 minecraft:brown_terracotta
fill 552 240 317 552 247 317 minecraft:brown_terracotta
setblock 553 240 275 minecraft:white_concrete
fill 553 240 277 555 245 277 minecraft:white_concrete
setblock 553 240 317 minecraft:white_concrete
fill 554 240 275 554 247 275 minecraft:brown_terracotta
fill 554 240 317 554 245 317 minecraft:brown_terracotta
fill 556 240 275 556 247 275 minecraft:brown_terracotta
fill 556 240 317 556 245 317 minecraft:brown_terracotta
setblock 557 240 275 minecraft:white_concrete
fill 557 240 284 557 241 284 minecraft:brown_terracotta
fill 557 240 285 557 245 287 minecraft:white_concrete
fill 557 240 297 557 245 299 minecraft:white_concrete
fill 557 240 309 557 245 311 minecraft:white_concrete
setblock 557 240 317 minecraft:white_concrete
fill 558 240 275 558 247 275 minecraft:brown_terracotta
fill 558 240 317 558 247 317 minecraft:brown_terracotta
setblock 559 240 275 minecraft:white_concrete
fill 559 240 276 559 245 276 minecraft:brown_terracotta
fill 559 240 278 559 245 278 minecraft:brown_terracotta
setblock 559 240 279 minecraft:white_concrete
fill 559 240 280 559 247 280 minecraft:brown_terracotta
fill 559 240 282 559 247 282 minecraft:brown_terracotta
setblock 559 240 283 minecraft:white_concrete
fill 559 240 284 559 247 284 minecraft:brown_terracotta
fill 559 240 286 559 247 286 minecraft:brown_terracotta
setblock 559 240 287 minecraft:white_concrete
fill 559 240 288 559 245 288 minecraft:brown_terracotta
fill 559 240 290 559 245 290 minecraft:brown_terracotta
setblock 559 240 291 minecraft:white_concrete
fill 559 240 292 559 247 292 minecraft:brown_terracotta
fill 559 240 294 559 247 294 minecraft:brown_terracotta
setblock 559 240 295 minecraft:white_concrete
fill 559 240 296 559 247 296 minecraft:brown_terracotta
fill 559 240 298 559 247 298 minecraft:brown_terracotta
setblock 559 240 299 minecraft:white_concrete
fill 559 240 300 559 245 300 minecraft:brown_terracotta
fill 559 240 302 559 245 302 minecraft:brown_terracotta
setblock 559 240 303 minecraft:white_concrete
fill 559 240 304 559 247 304 minecraft:brown_terracotta
fill 559 240 306 559 247 306 minecraft:brown_terracotta
setblock 559 240 307 minecraft:white_concrete
fill 559 240 308 559 247 308 minecraft:brown_terracotta
fill 559 240 310 559 247 310 minecraft:brown_terracotta
setblock 559 240 311 minecraft:white_concrete
fill 559 240 312 559 245 312 minecraft:brown_terracotta
fill 559 240 314 559 245 314 minecraft:brown_terracotta
setblock 559 240 315 minecraft:white_concrete
fill 559 240 316 559 247 316 minecraft:brown_terracotta
fill 517 241 275 517 248 275 minecraft:brown_terracotta
fill 517 241 279 517 248 279 minecraft:brown_terracotta
fill 517 241 283 518 241 283 minecraft:brown_terracotta
fill 517 241 287 517 248 287 minecraft:brown_terracotta
fill 517 241 291 517 248 291 minecraft:brown_terracotta
fill 517 241 295 517 245 295 minecraft:brown_terracotta
fill 517 241 299 517 248 299 minecraft:brown_terracotta
fill 517 241 303 517 248 303 minecraft:brown_terracotta
fill 517 241 307 517 245 307 minecraft:brown_terracotta
fill 517 241 311 517 248 311 minecraft:brown_terracotta
fill 517 241 315 517 248 315 minecraft:brown_terracotta
fill 517 241 317 517 245 317 minecraft:brown_terracotta
setblock 520 241 278 minecraft:light[level=12]
setblock 520 241 285 minecraft:light[level=12]
setblock 520 241 292 minecraft:light[level=12]
setblock 520 241 299 minecraft:light[level=12]
setblock 520 241 306 minecraft:light[level=12]
setblock 520 241 313 minecraft:light[level=12]
fill 521 241 275 521 248 275 minecraft:brown_terracotta
fill 521 241 286 521 241 292 minecraft:red_concrete
fill 521 241 317 521 248 317 minecraft:brown_terracotta
setblock 522 241 282 minecraft:shroomlight
setblock 522 241 288 minecraft:shroomlight
setblock 522 241 294 minecraft:shroomlight
setblock 522 241 300 minecraft:shroomlight
setblock 522 241 306 minecraft:shroomlight
setblock 522 241 312 minecraft:shroomlight
setblock 524 241 280 minecraft:shroomlight
setblock 524 241 312 minecraft:shroomlight
setblock 524 241 314 minecraft:shroomlight
setblock 524 241 316 minecraft:shroomlight
fill 525 241 275 525 245 275 minecraft:brown_terracotta
setblock 525 241 311 minecraft:shroomlight
setblock 525 241 313 minecraft:shroomlight
setblock 525 241 315 minecraft:shroomlight
fill 525 241 317 525 248 317 minecraft:brown_terracotta
setblock 526 241 312 minecraft:shroomlight
setblock 526 241 314 minecraft:shroomlight
setblock 526 241 316 minecraft:shroomlight
setblock 527 241 278 minecraft:light[level=12]
setblock 527 241 285 minecraft:light[level=12]
setblock 527 241 292 minecraft:light[level=12]
fill 527 241 299 527 246 299 minecraft:brown_terracotta
fill 527 241 301 528 246 301 minecraft:brown_terracotta
setblock 527 241 306 minecraft:light[level=12]
setblock 527 241 311 minecraft:shroomlight
setblock 527 241 313 minecraft:shroomlight
setblock 527 241 315 minecraft:shroomlight
setblock 528 241 312 minecraft:shroomlight
setblock 528 241 314 minecraft:shroomlight
setblock 528 241 316 minecraft:shroomlight
fill 529 241 275 529 248 275 minecraft:brown_terracotta
setblock 529 241 311 minecraft:shroomlight
setblock 529 241 313 minecraft:shroomlight
setblock 529 241 315 minecraft:shroomlight
fill 529 241 317 529 245 317 minecraft:brown_terracotta
setblock 530 241 280 minecraft:shroomlight
fill 530 241 305 530 243 305 minecraft:brown_terracotta
setblock 530 241 312 minecraft:shroomlight
setblock 530 241 314 minecraft:shroomlight
setblock 530 241 316 minecraft:shroomlight
setblock 531 241 311 minecraft:shroomlight
setblock 531 241 313 minecraft:shroomlight
setblock 531 241 315 minecraft:shroomlight
fill 532 241 303 532 243 303 minecraft:brown_terracotta
fill 532 241 307 532 243 307 minecraft:brown_terracotta
setblock 532 241 312 minecraft:shroomlight
setblock 532 241 314 minecraft:shroomlight
setblock 532 241 316 minecraft:shroomlight
fill 533 241 275 533 248 275 minecraft:brown_terracotta
setblock 533 241 311 minecraft:shroomlight
setblock 533 241 313 minecraft:shroomlight
setblock 533 241 315 minecraft:shroomlight
fill 533 241 317 533 248 317 minecraft:brown_terracotta
setblock 534 241 278 minecraft:light[level=12]
setblock 534 241 285 minecraft:light[level=12]
setblock 534 241 292 minecraft:light[level=12]
setblock 534 241 299 minecraft:light[level=12]
fill 534 241 304 534 243 305 minecraft:brown_terracotta
setblock 534 241 306 minecraft:light[level=12]
setblock 534 241 312 minecraft:shroomlight
setblock 534 241 314 minecraft:shroomlight
setblock 534 241 316 minecraft:shroomlight
setblock 536 241 280 minecraft:shroomlight
fill 537 241 275 537 245 275 minecraft:brown_terracotta
fill 537 241 317 537 248 317 minecraft:brown_terracotta
setblock 540 241 312 minecraft:shroomlight
fill 541 241 275 541 248 275 minecraft:brown_terracotta
setblock 541 241 278 minecraft:light[level=12]
setblock 541 241 285 minecraft:light[level=12]
setblock 541 241 292 minecraft:light[level=12]
setblock 541 241 299 minecraft:light[level=12]
setblock 541 241 306 minecraft:light[level=12]
setblock 541 241 313 minecraft:light[level=12]
fill 541 241 317 541 245 317 minecraft:brown_terracotta
setblock 542 241 280 minecraft:shroomlight
fill 545 241 275 545 248 275 minecraft:brown_terracotta
fill 545 241 317 545 248 317 minecraft:brown_terracotta
setblock 546 241 312 minecraft:shroomlight
setblock 548 241 278 minecraft:light[level=12]
setblock 548 241 280 minecraft:shroomlight
setblock 548 241 285 minecraft:light[level=12]
setblock 548 241 292 minecraft:light[level=12]
setblock 548 241 299 minecraft:light[level=12]
setblock 548 241 306 minecraft:light[level=12]
setblock 548 241 313 minecraft:light[level=12]
fill 549 241 275 549 245 275 minecraft:brown_terracotta
fill 549 241 317 549 248 317 minecraft:brown_terracotta
schedule function dropper:buildpart/71_6 1t
