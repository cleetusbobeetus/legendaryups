fill 69 129 332 70 129 332 minecraft:smooth_sandstone
setblock 69 129 333 minecraft:white_concrete
fill 69 129 334 69 129 335 minecraft:smooth_sandstone
setblock 69 129 336 minecraft:white_concrete
fill 69 129 337 69 129 339 minecraft:smooth_sandstone
fill 69 129 340 69 129 341 minecraft:white_concrete
fill 69 129 345 73 129 345 minecraft:smooth_sandstone
setblock 69 129 346 minecraft:white_concrete
fill 69 129 347 69 129 348 minecraft:smooth_sandstone
setblock 69 129 349 minecraft:white_concrete
fill 69 129 350 70 129 350 minecraft:smooth_sandstone
setblock 69 129 352 minecraft:mossy_cobblestone
fill 69 129 353 71 129 353 minecraft:moss_block
setblock 69 129 356 minecraft:mossy_cobblestone
fill 69 129 357 71 129 357 minecraft:moss_block
setblock 69 129 360 minecraft:mossy_cobblestone
fill 69 129 361 71 129 361 minecraft:moss_block
setblock 69 129 364 minecraft:dark_oak_planks
setblock 70 129 323 minecraft:mossy_cobblestone
fill 70 129 324 70 129 326 minecraft:moss_block
setblock 70 129 327 minecraft:mossy_cobblestone
fill 70 129 328 70 129 330 minecraft:moss_block
setblock 70 129 331 minecraft:mossy_cobblestone
fill 70 129 333 70 129 334 minecraft:smooth_sandstone
setblock 70 129 335 minecraft:white_concrete
fill 70 129 336 71 129 337 minecraft:smooth_sandstone
setblock 70 129 338 minecraft:white_concrete
fill 70 129 339 70 129 343 minecraft:smooth_sandstone
setblock 70 129 344 minecraft:white_concrete
fill 70 129 346 71 129 346 minecraft:smooth_sandstone
setblock 70 129 347 minecraft:white_concrete
fill 70 129 348 70 129 349 minecraft:smooth_sandstone
setblock 70 129 351 minecraft:mossy_cobblestone
fill 70 129 352 72 129 352 minecraft:moss_block
setblock 70 129 355 minecraft:mossy_cobblestone
fill 70 129 356 72 129 356 minecraft:moss_block
setblock 70 129 359 minecraft:mossy_cobblestone
fill 70 129 360 72 129 360 minecraft:moss_block
setblock 70 129 363 minecraft:mossy_cobblestone
fill 71 129 323 71 129 325 minecraft:moss_block
setblock 71 129 326 minecraft:mossy_cobblestone
fill 71 129 327 71 129 329 minecraft:moss_block
setblock 71 129 330 minecraft:mossy_cobblestone
fill 71 129 331 72 129 331 minecraft:smooth_sandstone
setblock 71 129 332 minecraft:white_concrete
fill 71 129 333 73 129 333 minecraft:smooth_sandstone
setblock 71 129 334 minecraft:white_concrete
fill 71 129 335 73 129 335 minecraft:smooth_sandstone
fill 71 129 338 71 129 339 minecraft:smooth_sandstone
fill 71 129 340 71 129 342 minecraft:white_concrete
fill 71 129 343 71 129 344 minecraft:smooth_sandstone
fill 71 129 347 73 129 347 minecraft:smooth_sandstone
setblock 71 129 348 minecraft:white_concrete
fill 71 129 349 73 129 349 minecraft:smooth_sandstone
setblock 71 129 350 minecraft:white_concrete
fill 71 129 351 72 129 351 minecraft:smooth_sandstone
setblock 71 129 354 minecraft:mossy_cobblestone
fill 71 129 355 73 129 355 minecraft:moss_block
setblock 71 129 358 minecraft:mossy_cobblestone
fill 71 129 359 73 129 359 minecraft:moss_block
setblock 71 129 362 minecraft:mossy_cobblestone
fill 71 129 363 73 129 363 minecraft:moss_block
fill 72 129 323 72 129 324 minecraft:moss_block
setblock 72 129 325 minecraft:mossy_cobblestone
fill 72 129 326 72 129 328 minecraft:moss_block
setblock 72 129 329 minecraft:mossy_cobblestone
fill 72 129 330 74 129 330 minecraft:moss_block
fill 72 129 332 78 129 332 minecraft:smooth_sandstone
fill 72 129 334 75 129 334 minecraft:smooth_sandstone
setblock 72 129 336 minecraft:white_concrete
fill 72 129 337 72 129 338 minecraft:smooth_sandstone
fill 72 129 339 72 129 343 minecraft:red_concrete
setblock 72 129 344 minecraft:smooth_sandstone
setblock 72 129 346 minecraft:white_concrete
fill 72 129 348 78 129 348 minecraft:smooth_sandstone
fill 72 129 350 78 129 350 minecraft:smooth_sandstone
setblock 72 129 353 minecraft:mossy_cobblestone
fill 72 129 354 74 129 354 minecraft:moss_block
setblock 72 129 357 minecraft:mossy_cobblestone
fill 72 129 358 74 129 358 minecraft:moss_block
setblock 72 129 361 minecraft:mossy_cobblestone
fill 72 129 362 74 129 362 minecraft:moss_block
setblock 73 129 323 minecraft:moss_block
setblock 73 129 324 minecraft:mossy_cobblestone
fill 73 129 325 73 129 327 minecraft:moss_block
setblock 73 129 328 minecraft:mossy_cobblestone
fill 73 129 329 75 129 329 minecraft:moss_block
fill 73 129 331 77 129 331 minecraft:white_concrete
fill 73 129 336 73 129 337 minecraft:smooth_sandstone
fill 73 129 338 73 129 339 minecraft:red_concrete
fill 73 129 343 73 129 344 minecraft:red_concrete
fill 73 129 346 77 129 346 minecraft:smooth_sandstone
fill 73 129 351 77 129 351 minecraft:white_concrete
setblock 73 129 352 minecraft:mossy_cobblestone
fill 73 129 353 75 129 353 minecraft:moss_block
setblock 73 129 356 minecraft:mossy_cobblestone
fill 73 129 357 75 129 357 minecraft:moss_block
setblock 73 129 360 minecraft:mossy_cobblestone
fill 73 129 361 75 129 361 minecraft:moss_block
setblock 73 129 364 minecraft:dark_oak_planks
setblock 74 129 323 minecraft:mossy_cobblestone
fill 74 129 324 74 129 326 minecraft:moss_block
setblock 74 129 327 minecraft:mossy_cobblestone
fill 74 129 328 76 129 328 minecraft:moss_block
fill 74 129 333 75 129 333 minecraft:white_concrete
fill 74 129 335 75 129 335 minecraft:white_concrete
fill 74 129 336 77 129 336 minecraft:smooth_sandstone
fill 74 129 337 76 129 337 minecraft:white_concrete
fill 74 129 338 77 129 338 minecraft:red_concrete
fill 74 129 344 77 129 344 minecraft:red_concrete
fill 74 129 345 76 129 345 minecraft:white_concrete
fill 74 129 347 76 129 347 minecraft:white_concrete
fill 74 129 349 76 129 349 minecraft:white_concrete
setblock 74 129 352 minecraft:moss_block
setblock 74 129 355 minecraft:mossy_cobblestone
fill 74 129 356 76 129 356 minecraft:moss_block
setblock 74 129 359 minecraft:mossy_cobblestone
fill 74 129 360 76 129 360 minecraft:moss_block
setblock 74 129 363 minecraft:mossy_cobblestone
fill 75 129 323 75 129 325 minecraft:moss_block
setblock 75 129 326 minecraft:mossy_cobblestone
fill 75 129 327 77 129 327 minecraft:moss_block
setblock 75 129 354 minecraft:mossy_cobblestone
fill 75 129 355 77 129 355 minecraft:moss_block
setblock 75 129 358 minecraft:mossy_cobblestone
fill 75 129 359 77 129 359 minecraft:moss_block
setblock 75 129 362 minecraft:mossy_cobblestone
fill 75 129 363 77 129 363 minecraft:moss_block
fill 76 129 323 76 129 324 minecraft:moss_block
setblock 76 129 325 minecraft:mossy_cobblestone
fill 76 129 326 78 129 326 minecraft:moss_block
setblock 76 129 329 minecraft:mossy_cobblestone
fill 76 129 330 78 129 330 minecraft:moss_block
fill 76 129 333 76 130 335 minecraft:stone
setblock 76 129 352 minecraft:moss_block
setblock 76 129 353 minecraft:mossy_cobblestone
fill 76 129 354 78 129 354 minecraft:moss_block
setblock 76 129 357 minecraft:mossy_cobblestone
fill 76 129 358 78 129 358 minecraft:moss_block
setblock 76 129 361 minecraft:mossy_cobblestone
fill 76 129 362 78 129 362 minecraft:moss_block
setblock 77 129 323 minecraft:moss_block
setblock 77 129 324 minecraft:mossy_cobblestone
fill 77 129 325 79 129 325 minecraft:moss_block
setblock 77 129 328 minecraft:mossy_cobblestone
fill 77 129 329 79 129 329 minecraft:moss_block
fill 77 129 333 80 129 333 minecraft:smooth_sandstone
fill 77 129 334 77 130 335 minecraft:stone
fill 77 129 337 81 129 337 minecraft:smooth_sandstone
fill 77 129 339 78 129 339 minecraft:red_concrete
fill 77 129 343 78 129 343 minecraft:red_concrete
fill 77 129 345 78 129 345 minecraft:smooth_sandstone
fill 77 129 347 79 129 347 minecraft:smooth_sandstone
fill 77 129 349 80 129 349 minecraft:smooth_sandstone
setblock 77 129 352 minecraft:mossy_cobblestone
fill 77 129 353 79 129 353 minecraft:moss_block
setblock 77 129 356 minecraft:mossy_cobblestone
fill 77 129 357 79 129 357 minecraft:moss_block
setblock 77 129 360 minecraft:mossy_cobblestone
fill 77 129 361 79 129 361 minecraft:moss_block
setblock 78 129 323 minecraft:mossy_cobblestone
fill 78 129 324 80 129 324 minecraft:moss_block
setblock 78 129 327 minecraft:mossy_cobblestone
fill 78 129 328 80 129 328 minecraft:moss_block
fill 78 129 331 79 129 331 minecraft:smooth_sandstone
fill 78 129 334 78 129 335 minecraft:smooth_sandstone
setblock 78 129 336 minecraft:white_concrete
fill 78 129 338 79 129 338 minecraft:smooth_sandstone
fill 78 129 340 78 129 342 minecraft:red_concrete
fill 78 129 344 79 129 344 minecraft:smooth_sandstone
setblock 78 129 346 minecraft:white_concrete
fill 78 129 351 79 129 351 minecraft:smooth_sandstone
fill 78 129 352 80 129 352 minecraft:moss_block
setblock 78 129 355 minecraft:mossy_cobblestone
fill 78 129 356 80 129 356 minecraft:moss_block
setblock 78 129 359 minecraft:mossy_cobblestone
fill 78 129 360 80 129 360 minecraft:moss_block
setblock 78 129 363 minecraft:mossy_cobblestone
fill 79 129 323 81 129 323 minecraft:moss_block
setblock 79 129 326 minecraft:mossy_cobblestone
fill 79 129 327 81 129 327 minecraft:moss_block
setblock 79 129 330 minecraft:mossy_cobblestone
setblock 79 129 332 minecraft:white_concrete
setblock 79 129 334 minecraft:white_concrete
fill 79 129 335 79 129 336 minecraft:smooth_sandstone
fill 79 129 339 84 129 339 minecraft:smooth_sandstone
fill 79 129 340 79 129 342 minecraft:white_concrete
fill 79 129 343 84 129 343 minecraft:smooth_sandstone
fill 79 129 345 81 129 345 minecraft:stone
setblock 79 129 346 minecraft:smooth_sandstone
setblock 79 129 348 minecraft:white_concrete
setblock 79 129 350 minecraft:white_concrete
setblock 79 129 354 minecraft:mossy_cobblestone
fill 79 129 355 81 129 355 minecraft:moss_block
setblock 79 129 358 minecraft:mossy_cobblestone
fill 79 129 359 81 129 359 minecraft:moss_block
setblock 79 129 362 minecraft:mossy_cobblestone
fill 79 129 363 81 129 363 minecraft:moss_block
setblock 80 129 325 minecraft:mossy_cobblestone
fill 80 129 326 82 129 326 minecraft:moss_block
setblock 80 129 329 minecraft:mossy_cobblestone
fill 80 129 330 81 129 331 minecraft:moss_block
fill 80 129 332 81 129 332 minecraft:smooth_sandstone
fill 80 129 334 81 129 334 minecraft:smooth_sandstone
setblock 80 129 335 minecraft:white_concrete
setblock 80 129 336 minecraft:smooth_sandstone
setblock 80 129 338 minecraft:white_concrete
fill 80 129 340 80 129 342 minecraft:smooth_sandstone
setblock 80 129 344 minecraft:white_concrete
fill 80 129 346 80 129 347 minecraft:stone
fill 80 129 348 81 129 348 minecraft:smooth_sandstone
fill 80 129 350 81 129 350 minecraft:smooth_sandstone
fill 80 129 351 81 129 351 minecraft:moss_block
setblock 80 129 353 minecraft:mossy_cobblestone
fill 80 129 354 82 129 354 minecraft:moss_block
setblock 80 129 357 minecraft:mossy_cobblestone
fill 80 129 358 82 129 358 minecraft:moss_block
setblock 80 129 361 minecraft:mossy_cobblestone
fill 80 129 362 82 129 362 minecraft:moss_block
fill 80 129 364 80 130 364 minecraft:dark_oak_planks
setblock 81 129 324 minecraft:mossy_cobblestone
fill 81 129 325 83 129 325 minecraft:moss_block
setblock 81 129 328 minecraft:mossy_cobblestone
fill 81 129 329 83 129 329 minecraft:moss_block
setblock 81 129 333 minecraft:white_concrete
fill 81 129 335 82 129 335 minecraft:smooth_sandstone
setblock 81 129 336 minecraft:white_concrete
fill 81 129 338 85 129 338 minecraft:smooth_sandstone
fill 81 129 340 81 129 342 minecraft:white_concrete
fill 81 129 344 85 129 344 minecraft:smooth_sandstone
fill 81 129 346 81 130 346 minecraft:stone
fill 81 129 347 82 129 347 minecraft:smooth_sandstone
setblock 81 129 349 minecraft:white_concrete
setblock 81 129 352 minecraft:mossy_cobblestone
fill 81 129 353 83 129 353 minecraft:moss_block
setblock 81 129 356 minecraft:mossy_cobblestone
fill 81 129 357 83 129 357 minecraft:moss_block
setblock 81 129 360 minecraft:mossy_cobblestone
fill 81 129 361 83 129 361 minecraft:moss_block
setblock 82 129 323 minecraft:mossy_cobblestone
fill 82 129 324 84 129 324 minecraft:moss_block
setblock 82 129 327 minecraft:mossy_cobblestone
fill 82 129 328 84 129 328 minecraft:moss_block
setblock 82 129 330 minecraft:moss_block
setblock 82 129 331 minecraft:mossy_cobblestone
fill 82 129 332 84 129 332 minecraft:moss_block
setblock 82 129 333 minecraft:smooth_sandstone
setblock 82 129 334 minecraft:white_concrete
fill 82 129 336 84 129 336 minecraft:smooth_sandstone
setblock 82 129 337 minecraft:white_concrete
fill 82 129 340 82 129 342 minecraft:smooth_sandstone
setblock 82 129 345 minecraft:white_concrete
fill 82 129 346 84 129 346 minecraft:smooth_sandstone
setblock 82 129 348 minecraft:white_concrete
setblock 82 129 349 minecraft:smooth_sandstone
setblock 82 129 350 minecraft:moss_block
setblock 82 129 351 minecraft:mossy_cobblestone
fill 82 129 352 84 129 352 minecraft:moss_block
setblock 82 129 355 minecraft:mossy_cobblestone
fill 82 129 356 84 129 356 minecraft:moss_block
setblock 82 129 359 minecraft:mossy_cobblestone
fill 82 129 360 84 129 360 minecraft:moss_block
setblock 82 129 363 minecraft:mossy_cobblestone
fill 83 129 323 85 129 323 minecraft:moss_block
setblock 83 129 326 minecraft:mossy_cobblestone
fill 83 129 327 85 129 327 minecraft:moss_block
setblock 83 129 330 minecraft:mossy_cobblestone
fill 83 129 331 85 129 331 minecraft:moss_block
setblock 83 129 333 minecraft:moss_block
setblock 83 129 334 minecraft:smooth_sandstone
setblock 83 129 335 minecraft:white_concrete
setblock 83 129 337 minecraft:smooth_sandstone
fill 83 129 340 83 129 342 minecraft:white_concrete
setblock 83 129 345 minecraft:smooth_sandstone
setblock 83 129 347 minecraft:white_concrete
setblock 83 129 348 minecraft:smooth_sandstone
setblock 83 129 349 minecraft:moss_block
setblock 83 129 350 minecraft:mossy_cobblestone
fill 83 129 351 85 129 351 minecraft:moss_block
setblock 83 129 354 minecraft:mossy_cobblestone
fill 83 129 355 85 129 355 minecraft:moss_block
setblock 83 129 358 minecraft:mossy_cobblestone
fill 83 129 359 85 129 359 minecraft:moss_block
setblock 83 129 362 minecraft:mossy_cobblestone
fill 83 129 363 85 129 363 minecraft:moss_block
setblock 84 129 325 minecraft:mossy_cobblestone
fill 84 129 326 86 129 326 minecraft:moss_block
setblock 84 129 329 minecraft:mossy_cobblestone
fill 84 129 330 86 129 330 minecraft:moss_block
setblock 84 129 333 minecraft:mossy_cobblestone
fill 84 129 334 86 129 334 minecraft:moss_block
setblock 84 129 335 minecraft:smooth_sandstone
setblock 84 129 337 minecraft:white_concrete
fill 84 129 340 84 129 342 minecraft:smooth_sandstone
setblock 84 129 345 minecraft:white_concrete
setblock 84 129 347 minecraft:smooth_sandstone
setblock 84 129 348 minecraft:moss_block
setblock 84 129 349 minecraft:mossy_cobblestone
fill 84 129 350 86 129 350 minecraft:moss_block
setblock 84 129 353 minecraft:mossy_cobblestone
fill 84 129 354 86 129 354 minecraft:moss_block
setblock 84 129 357 minecraft:mossy_cobblestone
fill 84 129 358 86 129 358 minecraft:moss_block
setblock 84 129 361 minecraft:mossy_cobblestone
fill 84 129 362 86 129 362 minecraft:moss_block
setblock 85 129 324 minecraft:mossy_cobblestone
fill 85 129 325 87 129 325 minecraft:moss_block
setblock 85 129 328 minecraft:mossy_cobblestone
fill 85 129 329 87 129 329 minecraft:moss_block
setblock 85 129 332 minecraft:mossy_cobblestone
fill 85 129 333 87 129 333 minecraft:moss_block
setblock 85 129 335 minecraft:moss_block
setblock 85 129 336 minecraft:mossy_cobblestone
setblock 85 129 337 minecraft:smooth_sandstone
fill 85 129 339 85 129 343 minecraft:white_concrete
setblock 85 129 345 minecraft:smooth_sandstone
fill 85 129 346 85 129 347 minecraft:moss_block
setblock 85 129 348 minecraft:mossy_cobblestone
fill 85 129 349 87 129 349 minecraft:moss_block
setblock 85 129 352 minecraft:mossy_cobblestone
fill 85 129 353 87 129 353 minecraft:moss_block
setblock 85 129 356 minecraft:mossy_cobblestone
fill 85 129 357 87 129 357 minecraft:moss_block
setblock 85 129 360 minecraft:mossy_cobblestone
fill 85 129 361 87 129 361 minecraft:moss_block
setblock 86 129 323 minecraft:mossy_cobblestone
fill 86 129 324 88 129 324 minecraft:moss_block
setblock 86 129 327 minecraft:mossy_cobblestone
fill 86 129 328 88 129 328 minecraft:moss_block
setblock 86 129 331 minecraft:mossy_cobblestone
fill 86 129 332 88 129 332 minecraft:moss_block
setblock 86 129 335 minecraft:mossy_cobblestone
fill 86 129 336 86 129 338 minecraft:moss_block
setblock 86 129 339 minecraft:mossy_cobblestone
fill 86 129 340 88 129 340 minecraft:moss_block
setblock 86 129 342 minecraft:moss_block
setblock 86 129 343 minecraft:mossy_cobblestone
fill 86 129 344 86 129 346 minecraft:moss_block
setblock 86 129 347 minecraft:mossy_cobblestone
fill 86 129 348 88 129 348 minecraft:moss_block
setblock 86 129 351 minecraft:mossy_cobblestone
fill 86 129 352 88 129 352 minecraft:moss_block
setblock 86 129 355 minecraft:mossy_cobblestone
fill 86 129 356 88 129 356 minecraft:moss_block
setblock 86 129 359 minecraft:mossy_cobblestone
fill 86 129 360 88 129 360 minecraft:moss_block
setblock 86 129 363 minecraft:mossy_cobblestone
fill 87 129 323 88 129 323 minecraft:moss_block
setblock 87 129 326 minecraft:mossy_cobblestone
fill 87 129 327 88 129 327 minecraft:moss_block
setblock 87 129 330 minecraft:mossy_cobblestone
fill 87 129 331 88 129 331 minecraft:moss_block
setblock 87 129 334 minecraft:mossy_cobblestone
fill 87 129 335 87 129 337 minecraft:moss_block
setblock 87 129 338 minecraft:mossy_cobblestone
fill 87 129 339 88 129 339 minecraft:moss_block
setblock 87 129 341 minecraft:moss_block
setblock 87 129 342 minecraft:mossy_cobblestone
fill 87 129 343 87 129 345 minecraft:moss_block
setblock 87 129 346 minecraft:mossy_cobblestone
fill 87 129 347 88 129 347 minecraft:moss_block
setblock 87 129 350 minecraft:mossy_cobblestone
fill 87 129 351 88 129 351 minecraft:moss_block
setblock 87 129 354 minecraft:mossy_cobblestone
fill 87 129 355 88 129 355 minecraft:moss_block
setblock 87 129 358 minecraft:mossy_cobblestone
fill 87 129 359 88 129 359 minecraft:moss_block
setblock 87 129 362 minecraft:mossy_cobblestone
fill 87 129 363 88 129 363 minecraft:moss_block
setblock 88 129 325 minecraft:mossy_cobblestone
setblock 88 129 326 minecraft:moss_block
setblock 88 129 329 minecraft:mossy_cobblestone
setblock 88 129 330 minecraft:moss_block
setblock 88 129 333 minecraft:mossy_cobblestone
fill 88 129 334 88 129 336 minecraft:moss_block
setblock 88 129 337 minecraft:mossy_cobblestone
setblock 88 129 338 minecraft:moss_block
setblock 88 129 341 minecraft:mossy_cobblestone
fill 88 129 342 88 129 344 minecraft:moss_block
setblock 88 129 345 minecraft:mossy_cobblestone
setblock 88 129 346 minecraft:moss_block
setblock 88 129 349 minecraft:mossy_cobblestone
setblock 88 129 350 minecraft:moss_block
setblock 88 129 353 minecraft:mossy_cobblestone
setblock 88 129 354 minecraft:moss_block
setblock 88 129 357 minecraft:mossy_cobblestone
setblock 88 129 358 minecraft:moss_block
setblock 88 129 361 minecraft:mossy_cobblestone
setblock 88 129 362 minecraft:moss_block
setblock 89 129 322 minecraft:dark_oak_planks
setblock 89 129 332 minecraft:dark_oak_planks
setblock 89 129 337 minecraft:dark_oak_planks
setblock 89 129 347 minecraft:dark_oak_planks
setblock 89 129 349 minecraft:dark_oak_planks
setblock 89 129 352 minecraft:dark_oak_planks
setblock 89 129 357 minecraft:red_concrete
setblock 89 129 363 minecraft:dark_oak_planks
fill 47 130 322 47 219 323 minecraft:spruce_planks
setblock 47 130 324 minecraft:dark_oak_planks
fill 47 130 325 47 131 325 minecraft:spruce_planks
fill 47 130 327 47 219 327 minecraft:spruce_planks
fill 47 130 329 47 130 334 minecraft:spruce_planks
fill 47 130 336 47 130 343 minecraft:spruce_planks
setblock 47 130 344 minecraft:dark_oak_planks
fill 47 130 345 47 130 347 minecraft:spruce_planks
fill 47 130 349 47 130 359 minecraft:spruce_planks
setblock 47 130 360 minecraft:dark_oak_planks
fill 47 130 361 47 192 363 minecraft:spruce_planks
fill 48 130 322 51 217 322 minecraft:spruce_planks
fill 48 130 364 52 130 364 minecraft:spruce_planks
setblock 50 130 325 minecraft:light[level=15]
setblock 50 130 333 minecraft:light[level=15]
setblock 50 130 341 minecraft:light[level=15]
setblock 50 130 349 minecraft:light[level=15]
setblock 50 130 357 minecraft:light[level=15]
fill 53 130 322 83 130 322 minecraft:spruce_planks
fill 54 130 364 55 130 364 minecraft:spruce_planks
setblock 56 130 364 minecraft:dark_oak_planks
fill 57 130 364 64 130 364 minecraft:spruce_planks
setblock 58 130 325 minecraft:light[level=15]
setblock 58 130 333 minecraft:light[level=15]
setblock 58 130 341 minecraft:light[level=15]
setblock 58 130 349 minecraft:light[level=15]
setblock 58 130 357 minecraft:light[level=15]
setblock 66 130 325 minecraft:light[level=15]
setblock 66 130 333 minecraft:light[level=15]
setblock 66 130 341 minecraft:light[level=15]
setblock 66 130 349 minecraft:light[level=15]
setblock 66 130 357 minecraft:light[level=15]
fill 66 130 364 70 131 364 minecraft:spruce_planks
fill 68 130 343 69 130 344 minecraft:stone
setblock 71 130 364 minecraft:dark_oak_planks
fill 72 130 364 79 130 364 minecraft:spruce_planks
setblock 74 130 325 minecraft:light[level=15]
setblock 74 130 333 minecraft:light[level=15]
setblock 74 130 349 minecraft:light[level=15]
setblock 74 130 357 minecraft:light[level=15]
fill 80 130 345 80 130 346 minecraft:stone
setblock 81 130 345 minecraft:stone
fill 81 130 364 82 219 364 minecraft:spruce_planks
setblock 82 130 325 minecraft:light[level=15]
setblock 82 130 333 minecraft:light[level=15]
setblock 82 130 341 minecraft:light[level=15]
setblock 82 130 349 minecraft:light[level=15]
setblock 82 130 357 minecraft:light[level=15]
setblock 83 130 364 minecraft:dark_oak_planks
setblock 84 130 322 minecraft:dark_oak_planks
fill 84 130 364 89 131 364 minecraft:spruce_planks
fill 85 130 322 89 215 322 minecraft:spruce_planks
fill 89 130 323 89 215 327 minecraft:spruce_planks
fill 89 130 329 89 189 329 minecraft:spruce_planks
fill 89 130 330 89 130 331 minecraft:dark_oak_planks
fill 89 130 332 89 130 339 minecraft:spruce_planks
setblock 89 130 341 minecraft:dark_oak_planks
fill 89 130 342 89 130 361 minecraft:spruce_planks
setblock 89 130 362 minecraft:dark_oak_planks
fill 89 130 363 89 216 363 minecraft:spruce_planks
fill 47 131 324 47 215 324 minecraft:spruce_planks
fill 47 131 328 47 211 329 minecraft:spruce_planks
setblock 47 131 330 minecraft:dark_oak_planks
fill 47 131 331 47 131 336 minecraft:spruce_planks
setblock 47 131 337 minecraft:dark_oak_planks
fill 47 131 338 47 131 340 minecraft:spruce_planks
setblock 47 131 341 minecraft:dark_oak_planks
fill 47 131 342 47 219 342 minecraft:spruce_planks
setblock 47 131 343 minecraft:dark_oak_planks
fill 47 131 344 47 217 345 minecraft:spruce_planks
setblock 47 131 346 minecraft:dark_oak_planks
fill 47 131 347 47 215 348 minecraft:spruce_planks
setblock 47 131 349 minecraft:dark_oak_planks
fill 47 131 350 47 202 356 minecraft:spruce_planks
setblock 47 131 357 minecraft:red_concrete
fill 47 131 358 47 186 360 minecraft:spruce_planks
fill 47 131 364 47 219 364 minecraft:spruce_planks
setblock 48 131 364 minecraft:red_concrete
setblock 49 131 364 minecraft:dark_oak_planks
fill 50 131 364 53 151 364 minecraft:spruce_planks
setblock 53 131 322 minecraft:dark_oak_planks
fill 54 131 322 57 131 322 minecraft:spruce_planks
fill 54 131 364 55 131 364 minecraft:dark_oak_planks
fill 56 131 364 59 162 364 minecraft:spruce_planks
setblock 58 131 322 minecraft:dark_oak_planks
fill 59 131 322 59 159 322 minecraft:spruce_planks
fill 60 131 322 60 132 322 minecraft:dark_oak_planks
setblock 60 131 364 minecraft:dark_oak_planks
fill 61 131 322 64 205 322 minecraft:spruce_planks
fill 61 131 364 62 203 364 minecraft:spruce_planks
fill 63 131 364 64 131 364 minecraft:dark_oak_planks
setblock 65 131 322 minecraft:dark_oak_planks
fill 65 131 364 65 216 364 minecraft:spruce_planks
fill 66 131 322 68 142 322 minecraft:spruce_planks
setblock 69 131 322 minecraft:dark_oak_planks
fill 70 131 322 72 215 322 minecraft:spruce_planks
fill 71 131 364 76 131 364 minecraft:spruce_planks
setblock 73 131 322 minecraft:dark_oak_planks
fill 74 131 322 84 131 322 minecraft:spruce_planks
setblock 77 131 364 minecraft:red_concrete
setblock 78 131 364 minecraft:dark_oak_planks
fill 79 131 364 80 185 364 minecraft:spruce_planks
fill 83 131 364 83 219 364 minecraft:spruce_planks
fill 89 131 328 89 183 328 minecraft:spruce_planks
fill 89 131 330 89 131 338 minecraft:spruce_planks
setblock 89 131 339 minecraft:dark_oak_planks
fill 89 131 340 89 131 341 minecraft:spruce_planks
setblock 89 131 342 minecraft:dark_oak_planks
fill 89 131 343 89 219 343 minecraft:spruce_planks
setblock 89 131 344 minecraft:dark_oak_planks
fill 89 131 345 89 215 345 minecraft:spruce_planks
setblock 89 131 346 minecraft:dark_oak_planks
fill 89 131 347 89 131 352 minecraft:spruce_planks
fill 89 131 353 89 131 354 minecraft:dark_oak_planks
fill 89 131 355 89 217 356 minecraft:spruce_planks
setblock 89 131 357 minecraft:dark_oak_planks
fill 89 131 358 89 163 362 minecraft:spruce_planks
setblock 47 132 325 minecraft:dark_oak_planks
fill 47 132 326 47 219 326 minecraft:spruce_planks
fill 47 132 330 47 215 334 minecraft:spruce_planks
setblock 47 132 335 minecraft:dark_oak_planks
fill 47 132 336 47 135 337 minecraft:spruce_planks
setblock 47 132 338 minecraft:dark_oak_planks
fill 47 132 339 47 216 341 minecraft:spruce_planks
fill 47 132 343 47 219 343 minecraft:spruce_planks
fill 47 132 346 47 216 346 minecraft:spruce_planks
fill 47 132 349 47 219 349 minecraft:spruce_planks
fill 47 132 357 47 219 357 minecraft:spruce_planks
fill 48 132 364 49 217 364 minecraft:spruce_planks
setblock 50 132 325 minecraft:light[level=12]
setblock 50 132 332 minecraft:light[level=12]
setblock 50 132 339 minecraft:light[level=12]
setblock 50 132 346 minecraft:light[level=12]
setblock 50 132 353 minecraft:light[level=12]
setblock 50 132 360 minecraft:light[level=12]
fill 52 132 322 55 183 322 minecraft:spruce_planks
fill 54 132 364 55 219 364 minecraft:spruce_planks
setblock 56 132 322 minecraft:dark_oak_planks
fill 57 132 322 58 159 322 minecraft:spruce_planks
setblock 57 132 325 minecraft:light[level=12]
setblock 57 132 332 minecraft:light[level=12]
setblock 57 132 339 minecraft:light[level=12]
setblock 57 132 346 minecraft:light[level=12]
setblock 57 132 353 minecraft:light[level=12]
setblock 57 132 360 minecraft:light[level=12]
fill 60 132 364 60 151 364 minecraft:spruce_planks
fill 63 132 364 64 219 364 minecraft:spruce_planks
setblock 64 132 325 minecraft:light[level=12]
setblock 64 132 332 minecraft:light[level=12]
setblock 64 132 339 minecraft:light[level=12]
setblock 64 132 346 minecraft:light[level=12]
setblock 64 132 353 minecraft:light[level=12]
setblock 64 132 360 minecraft:light[level=12]
fill 65 132 322 65 220 322 minecraft:spruce_planks
fill 66 132 364 68 219 364 minecraft:spruce_planks
fill 69 132 322 69 219 322 minecraft:spruce_planks
setblock 69 132 364 minecraft:dark_oak_planks
fill 70 132 364 74 138 364 minecraft:spruce_planks
setblock 71 132 325 minecraft:light[level=12]
setblock 71 132 332 minecraft:light[level=12]
setblock 71 132 339 minecraft:light[level=12]
setblock 71 132 346 minecraft:light[level=12]
setblock 71 132 353 minecraft:light[level=12]
setblock 71 132 360 minecraft:light[level=12]
fill 73 132 322 73 220 322 minecraft:spruce_planks
setblock 74 132 322 minecraft:dark_oak_planks
fill 75 132 322 75 217 322 minecraft:spruce_planks
setblock 75 132 364 minecraft:dark_oak_planks
setblock 76 132 322 minecraft:dark_oak_planks
fill 76 132 364 78 163 364 minecraft:spruce_planks
fill 77 132 322 79 192 322 minecraft:spruce_planks
setblock 78 132 325 minecraft:light[level=12]
setblock 78 132 332 minecraft:light[level=12]
setblock 78 132 339 minecraft:light[level=12]
setblock 78 132 346 minecraft:light[level=12]
setblock 78 132 353 minecraft:light[level=12]
setblock 78 132 360 minecraft:light[level=12]
setblock 80 132 322 minecraft:dark_oak_planks
fill 81 132 322 84 190 322 minecraft:spruce_planks
fill 84 132 364 85 161 364 minecraft:spruce_planks
setblock 85 132 325 minecraft:light[level=12]
setblock 85 132 332 minecraft:light[level=12]
setblock 85 132 339 minecraft:light[level=12]
setblock 85 132 346 minecraft:light[level=12]
setblock 85 132 353 minecraft:light[level=12]
setblock 85 132 360 minecraft:light[level=12]
setblock 86 132 364 minecraft:dark_oak_planks
fill 87 132 364 89 167 364 minecraft:spruce_planks
fill 89 132 330 89 219 330 minecraft:spruce_planks
fill 89 132 331 89 132 332 minecraft:dark_oak_planks
fill 89 132 333 89 215 339 minecraft:spruce_planks
setblock 89 132 340 minecraft:dark_oak_planks
fill 89 132 341 89 164 342 minecraft:spruce_planks
fill 89 132 344 89 219 344 minecraft:spruce_planks
fill 89 132 346 89 215 350 minecraft:spruce_planks
fill 89 132 351 89 132 352 minecraft:dark_oak_planks
fill 89 132 353 89 187 354 minecraft:spruce_planks
fill 89 132 357 89 217 357 minecraft:spruce_planks
fill 47 133 325 47 219 325 minecraft:spruce_planks
fill 47 133 335 47 219 335 minecraft:spruce_planks
fill 47 133 338 47 215 338 minecraft:spruce_planks
fill 48 133 328 48 205 328 minecraft:stripped_dark_oak_log
fill 48 133 335 48 205 335 minecraft:stripped_dark_oak_log
fill 48 133 340 48 135 349 minecraft:stripped_dark_oak_log
fill 48 133 356 48 205 356 minecraft:stripped_dark_oak_log
fill 48 133 363 48 205 363 minecraft:stripped_dark_oak_log
fill 49 133 340 55 135 348 minecraft:stripped_dark_oak_log
fill 50 133 323 50 205 323 minecraft:stripped_dark_oak_log
fill 55 133 363 55 205 363 minecraft:stripped_dark_oak_log
fill 56 133 322 56 218 322 minecraft:spruce_planks
fill 57 133 323 57 205 323 minecraft:stripped_dark_oak_log
fill 60 133 322 60 220 322 minecraft:spruce_planks
fill 62 133 363 62 205 363 minecraft:stripped_dark_oak_log
fill 64 133 323 64 205 323 minecraft:stripped_dark_oak_log
fill 69 133 363 69 205 363 minecraft:stripped_dark_oak_log
fill 69 133 364 69 140 364 minecraft:spruce_planks
fill 71 133 323 71 205 323 minecraft:stripped_dark_oak_log
fill 74 133 322 74 190 322 minecraft:spruce_planks
fill 75 133 323 83 135 328 minecraft:stripped_dark_oak_log
fill 75 133 364 75 219 364 minecraft:spruce_planks
fill 76 133 322 76 217 322 minecraft:spruce_planks
fill 76 133 363 76 205 363 minecraft:stripped_dark_oak_log
fill 80 133 322 80 147 322 minecraft:spruce_planks
fill 83 133 363 83 205 363 minecraft:stripped_dark_oak_log
fill 85 133 323 85 205 323 minecraft:stripped_dark_oak_log
fill 86 133 364 86 217 364 minecraft:spruce_planks
fill 88 133 327 88 205 327 minecraft:stripped_dark_oak_log
fill 88 133 334 88 205 334 minecraft:stripped_dark_oak_log
fill 88 133 341 88 205 341 minecraft:stripped_dark_oak_log
fill 88 133 348 88 205 348 minecraft:stripped_dark_oak_log
fill 88 133 355 88 205 355 minecraft:stripped_dark_oak_log
fill 88 133 362 88 205 362 minecraft:stripped_dark_oak_log
fill 89 133 331 89 219 332 minecraft:spruce_planks
fill 89 133 340 89 219 340 minecraft:spruce_planks
fill 89 133 351 89 219 352 minecraft:spruce_planks
setblock 48 134 329 minecraft:stripped_dark_oak_log
setblock 48 134 336 minecraft:stripped_dark_oak_log
setblock 48 134 350 minecraft:stripped_dark_oak_log
setblock 48 134 357 minecraft:stripped_dark_oak_log
setblock 49 134 323 minecraft:stripped_dark_oak_log
setblock 49 134 363 minecraft:stripped_dark_oak_log
setblock 56 134 323 minecraft:stripped_dark_oak_log
setblock 56 134 363 minecraft:stripped_dark_oak_log
setblock 63 134 323 minecraft:stripped_dark_oak_log
setblock 63 134 363 minecraft:stripped_dark_oak_log
setblock 70 134 323 minecraft:stripped_dark_oak_log
setblock 70 134 363 minecraft:stripped_dark_oak_log
setblock 77 134 363 minecraft:stripped_dark_oak_log
setblock 84 134 323 minecraft:stripped_dark_oak_log
setblock 84 134 363 minecraft:stripped_dark_oak_log
setblock 88 134 326 minecraft:stripped_dark_oak_log
setblock 88 134 333 minecraft:stripped_dark_oak_log
setblock 88 134 340 minecraft:stripped_dark_oak_log
setblock 88 134 347 minecraft:stripped_dark_oak_log
setblock 88 134 354 minecraft:stripped_dark_oak_log
setblock 88 134 361 minecraft:stripped_dark_oak_log
setblock 48 135 323 minecraft:stripped_dark_oak_log
setblock 48 135 330 minecraft:stripped_dark_oak_log
setblock 48 135 337 minecraft:stripped_dark_oak_log
setblock 48 135 351 minecraft:stripped_dark_oak_log
setblock 48 135 358 minecraft:stripped_dark_oak_log
setblock 50 135 363 minecraft:stripped_dark_oak_log
setblock 55 135 323 minecraft:stripped_dark_oak_log
setblock 57 135 363 minecraft:stripped_dark_oak_log
setblock 62 135 323 minecraft:stripped_dark_oak_log
setblock 64 135 363 minecraft:stripped_dark_oak_log
fill 65 135 358 65 136 358 minecraft:shroomlight
setblock 69 135 323 minecraft:stripped_dark_oak_log
setblock 71 135 363 minecraft:stripped_dark_oak_log
setblock 78 135 363 minecraft:stripped_dark_oak_log
setblock 85 135 363 minecraft:stripped_dark_oak_log
setblock 88 135 325 minecraft:stripped_dark_oak_log
setblock 88 135 332 minecraft:stripped_dark_oak_log
setblock 88 135 339 minecraft:stripped_dark_oak_log
setblock 88 135 346 minecraft:stripped_dark_oak_log
setblock 88 135 353 minecraft:stripped_dark_oak_log
setblock 88 135 360 minecraft:stripped_dark_oak_log
fill 47 136 336 47 216 336 minecraft:spruce_planks
setblock 47 136 337 minecraft:red_concrete
setblock 48 136 324 minecraft:stripped_dark_oak_log
setblock 48 136 331 minecraft:stripped_dark_oak_log
setblock 48 136 338 minecraft:stripped_dark_oak_log
fill 48 136 340 48 148 340 minecraft:stripped_dark_oak_log
setblock 48 136 341 minecraft:shroomlight
fill 48 136 342 48 205 342 minecraft:stripped_dark_oak_log
setblock 48 136 343 minecraft:shroomlight
fill 48 136 344 48 150 344 minecraft:stripped_dark_oak_log
setblock 48 136 345 minecraft:shroomlight
fill 48 136 346 48 148 346 minecraft:stripped_dark_oak_log
setblock 48 136 347 minecraft:shroomlight
fill 48 136 348 48 148 349 minecraft:stripped_dark_oak_log
setblock 48 136 352 minecraft:stripped_dark_oak_log
setblock 48 136 359 minecraft:stripped_dark_oak_log
setblock 49 136 340 minecraft:shroomlight
fill 49 136 341 49 148 341 minecraft:stripped_dark_oak_log
setblock 49 136 342 minecraft:shroomlight
fill 49 136 343 49 148 343 minecraft:stripped_dark_oak_log
setblock 49 136 344 minecraft:shroomlight
fill 49 136 345 49 148 345 minecraft:stripped_dark_oak_log
setblock 49 136 346 minecraft:shroomlight
fill 49 136 347 49 148 347 minecraft:stripped_dark_oak_log
setblock 49 136 348 minecraft:shroomlight
fill 50 136 340 50 148 340 minecraft:stripped_dark_oak_log
setblock 50 136 341 minecraft:shroomlight
fill 50 136 342 50 148 342 minecraft:stripped_dark_oak_log
setblock 50 136 343 minecraft:shroomlight
fill 50 136 344 50 148 344 minecraft:stripped_dark_oak_log
setblock 50 136 345 minecraft:shroomlight
fill 50 136 346 50 148 346 minecraft:stripped_dark_oak_log
setblock 50 136 347 minecraft:shroomlight
fill 50 136 348 50 148 348 minecraft:stripped_dark_oak_log
setblock 51 136 340 minecraft:shroomlight
fill 51 136 341 51 148 341 minecraft:stripped_dark_oak_log
setblock 51 136 342 minecraft:shroomlight
fill 51 136 343 51 148 343 minecraft:stripped_dark_oak_log
setblock 51 136 344 minecraft:shroomlight
fill 51 136 345 51 148 345 minecraft:stripped_dark_oak_log
setblock 51 136 346 minecraft:shroomlight
fill 51 136 347 51 148 347 minecraft:stripped_dark_oak_log
setblock 51 136 348 minecraft:shroomlight
setblock 51 136 363 minecraft:stripped_dark_oak_log
fill 52 136 340 52 148 340 minecraft:stripped_dark_oak_log
setblock 52 136 341 minecraft:shroomlight
fill 52 136 342 52 148 342 minecraft:stripped_dark_oak_log
setblock 52 136 343 minecraft:shroomlight
fill 52 136 344 52 148 344 minecraft:stripped_dark_oak_log
setblock 52 136 345 minecraft:shroomlight
fill 52 136 346 52 148 346 minecraft:stripped_dark_oak_log
setblock 52 136 347 minecraft:shroomlight
fill 52 136 348 52 148 348 minecraft:stripped_dark_oak_log
setblock 53 136 340 minecraft:shroomlight
fill 53 136 341 53 148 341 minecraft:stripped_dark_oak_log
setblock 53 136 342 minecraft:shroomlight
fill 53 136 343 53 148 343 minecraft:stripped_dark_oak_log
setblock 53 136 344 minecraft:shroomlight
fill 53 136 345 53 148 345 minecraft:stripped_dark_oak_log
setblock 53 136 346 minecraft:shroomlight
fill 53 136 347 53 148 347 minecraft:stripped_dark_oak_log
setblock 53 136 348 minecraft:shroomlight
setblock 54 136 323 minecraft:stripped_dark_oak_log
fill 54 136 340 54 148 340 minecraft:stripped_dark_oak_log
setblock 54 136 341 minecraft:shroomlight
fill 54 136 342 54 148 342 minecraft:stripped_dark_oak_log
setblock 54 136 343 minecraft:shroomlight
fill 54 136 344 54 148 344 minecraft:stripped_dark_oak_log
setblock 54 136 345 minecraft:shroomlight
fill 54 136 346 54 148 346 minecraft:stripped_dark_oak_log
setblock 54 136 347 minecraft:shroomlight
fill 54 136 348 54 148 348 minecraft:stripped_dark_oak_log
setblock 55 136 340 minecraft:shroomlight
fill 55 136 341 55 148 341 minecraft:stripped_dark_oak_log
setblock 55 136 342 minecraft:shroomlight
fill 55 136 343 55 148 343 minecraft:stripped_dark_oak_log
setblock 55 136 344 minecraft:shroomlight
fill 55 136 345 55 148 345 minecraft:stripped_dark_oak_log
setblock 55 136 346 minecraft:shroomlight
fill 55 136 347 55 148 347 minecraft:stripped_dark_oak_log
setblock 55 136 348 minecraft:shroomlight
fill 57 136 332 59 138 334 minecraft:cherry_leaves[persistent=true]
fill 58 136 335 58 137 335 minecraft:cherry_leaves[persistent=true]
setblock 58 136 363 minecraft:stripped_dark_oak_log
setblock 61 136 323 minecraft:stripped_dark_oak_log
setblock 65 136 363 minecraft:stripped_dark_oak_log
setblock 68 136 323 minecraft:stripped_dark_oak_log
setblock 72 136 363 minecraft:stripped_dark_oak_log
fill 75 136 323 75 152 323 minecraft:stripped_dark_oak_log
setblock 75 136 324 minecraft:shroomlight
fill 75 136 325 75 152 325 minecraft:stripped_dark_oak_log
setblock 75 136 326 minecraft:shroomlight
fill 75 136 327 75 152 327 minecraft:stripped_dark_oak_log
setblock 75 136 328 minecraft:shroomlight
setblock 76 136 323 minecraft:shroomlight
fill 76 136 324 76 152 324 minecraft:stripped_dark_oak_log
setblock 76 136 325 minecraft:shroomlight
fill 76 136 326 76 152 326 minecraft:stripped_dark_oak_log
setblock 76 136 327 minecraft:shroomlight
fill 76 136 328 76 152 328 minecraft:stripped_dark_oak_log
fill 77 136 323 77 152 323 minecraft:stripped_dark_oak_log
setblock 77 136 324 minecraft:shroomlight
fill 77 136 325 77 152 325 minecraft:stripped_dark_oak_log
setblock 77 136 326 minecraft:shroomlight
fill 77 136 327 77 152 327 minecraft:stripped_dark_oak_log
setblock 77 136 328 minecraft:shroomlight
setblock 78 136 323 minecraft:shroomlight
fill 78 136 324 78 152 324 minecraft:stripped_dark_oak_log
setblock 78 136 325 minecraft:shroomlight
fill 78 136 326 78 152 326 minecraft:stripped_dark_oak_log
setblock 78 136 327 minecraft:shroomlight
fill 78 136 328 78 152 328 minecraft:stripped_dark_oak_log
fill 79 136 323 79 153 323 minecraft:stripped_dark_oak_log
setblock 79 136 324 minecraft:shroomlight
fill 79 136 325 79 152 325 minecraft:stripped_dark_oak_log
setblock 79 136 326 minecraft:shroomlight
fill 79 136 327 79 152 327 minecraft:stripped_dark_oak_log
setblock 79 136 328 minecraft:shroomlight
setblock 79 136 363 minecraft:stripped_dark_oak_log
setblock 80 136 323 minecraft:shroomlight
fill 80 136 324 80 152 324 minecraft:stripped_dark_oak_log
setblock 80 136 325 minecraft:shroomlight
fill 80 136 326 80 152 326 minecraft:stripped_dark_oak_log
setblock 80 136 327 minecraft:shroomlight
fill 80 136 328 80 152 328 minecraft:stripped_dark_oak_log
fill 81 136 323 81 152 323 minecraft:stripped_dark_oak_log
setblock 81 136 324 minecraft:shroomlight
fill 81 136 325 81 152 325 minecraft:stripped_dark_oak_log
setblock 81 136 326 minecraft:shroomlight
fill 81 136 327 81 152 327 minecraft:stripped_dark_oak_log
setblock 81 136 328 minecraft:shroomlight
setblock 82 136 323 minecraft:shroomlight
fill 82 136 324 82 152 324 minecraft:stripped_dark_oak_log
setblock 82 136 325 minecraft:shroomlight
fill 82 136 326 82 152 326 minecraft:stripped_dark_oak_log
setblock 82 136 327 minecraft:shroomlight
fill 82 136 328 82 152 328 minecraft:stripped_dark_oak_log
fill 83 136 323 83 152 323 minecraft:stripped_dark_oak_log
setblock 83 136 324 minecraft:shroomlight
fill 83 136 325 83 152 325 minecraft:stripped_dark_oak_log
setblock 83 136 326 minecraft:shroomlight
fill 83 136 327 83 152 327 minecraft:stripped_dark_oak_log
setblock 83 136 328 minecraft:shroomlight
setblock 86 136 363 minecraft:stripped_dark_oak_log
setblock 88 136 324 minecraft:stripped_dark_oak_log
setblock 88 136 331 minecraft:stripped_dark_oak_log
setblock 88 136 338 minecraft:stripped_dark_oak_log
setblock 88 136 345 minecraft:stripped_dark_oak_log
setblock 88 136 352 minecraft:stripped_dark_oak_log
setblock 88 136 359 minecraft:stripped_dark_oak_log
fill 47 137 337 47 142 337 minecraft:spruce_planks
setblock 48 137 325 minecraft:stripped_dark_oak_log
setblock 48 137 332 minecraft:stripped_dark_oak_log
setblock 48 137 339 minecraft:stripped_dark_oak_log
fill 48 137 341 48 138 341 minecraft:stripped_dark_oak_log
fill 48 137 343 48 138 343 minecraft:stripped_dark_oak_log
fill 48 137 345 48 138 345 minecraft:stripped_dark_oak_log
fill 48 137 347 48 138 347 minecraft:stripped_dark_oak_log
setblock 48 137 353 minecraft:stripped_dark_oak_log
setblock 48 137 360 minecraft:stripped_dark_oak_log
fill 49 137 340 49 138 340 minecraft:stripped_dark_oak_log
fill 49 137 342 49 138 342 minecraft:stripped_dark_oak_log
fill 49 137 344 49 138 344 minecraft:stripped_dark_oak_log
fill 49 137 346 49 138 346 minecraft:stripped_dark_oak_log
fill 49 137 348 49 138 348 minecraft:stripped_dark_oak_log
fill 50 137 341 50 138 341 minecraft:stripped_dark_oak_log
fill 50 137 343 50 138 343 minecraft:stripped_dark_oak_log
fill 50 137 345 50 138 345 minecraft:stripped_dark_oak_log
fill 50 137 347 50 138 347 minecraft:stripped_dark_oak_log
fill 51 137 340 51 138 340 minecraft:stripped_dark_oak_log
fill 51 137 342 51 138 342 minecraft:stripped_dark_oak_log
fill 51 137 344 51 138 344 minecraft:stripped_dark_oak_log
fill 51 137 346 51 138 346 minecraft:stripped_dark_oak_log
fill 51 137 348 51 138 348 minecraft:stripped_dark_oak_log
fill 52 137 341 52 138 341 minecraft:stripped_dark_oak_log
fill 52 137 343 52 138 343 minecraft:stripped_dark_oak_log
fill 52 137 345 52 138 345 minecraft:stripped_dark_oak_log
fill 52 137 347 52 138 347 minecraft:stripped_dark_oak_log
setblock 52 137 363 minecraft:stripped_dark_oak_log
setblock 53 137 323 minecraft:stripped_dark_oak_log
fill 53 137 340 53 138 340 minecraft:stripped_dark_oak_log
fill 53 137 342 53 138 342 minecraft:stripped_dark_oak_log
fill 53 137 344 53 138 344 minecraft:stripped_dark_oak_log
fill 53 137 346 53 138 346 minecraft:stripped_dark_oak_log
fill 53 137 348 53 138 348 minecraft:stripped_dark_oak_log
fill 54 137 341 54 138 341 minecraft:stripped_dark_oak_log
fill 54 137 343 54 138 343 minecraft:stripped_dark_oak_log
fill 54 137 345 54 138 345 minecraft:stripped_dark_oak_log
fill 54 137 347 54 138 347 minecraft:stripped_dark_oak_log
fill 55 137 340 55 138 340 minecraft:stripped_dark_oak_log
fill 55 137 342 55 138 342 minecraft:stripped_dark_oak_log
fill 55 137 344 55 138 344 minecraft:stripped_dark_oak_log
fill 55 137 346 55 138 346 minecraft:stripped_dark_oak_log
fill 55 137 348 55 138 348 minecraft:stripped_dark_oak_log
fill 57 137 331 59 138 331 minecraft:cherry_leaves[persistent=true]
setblock 59 137 363 minecraft:stripped_dark_oak_log
setblock 60 137 323 minecraft:stripped_dark_oak_log
fill 64 137 358 65 147 358 minecraft:dark_oak_planks
setblock 66 137 363 minecraft:stripped_dark_oak_log
setblock 67 137 323 minecraft:stripped_dark_oak_log
setblock 73 137 363 minecraft:stripped_dark_oak_log
setblock 74 137 323 minecraft:stripped_dark_oak_log
fill 75 137 324 75 138 324 minecraft:stripped_dark_oak_log
fill 75 137 326 75 138 326 minecraft:stripped_dark_oak_log
fill 75 137 328 75 138 328 minecraft:stripped_dark_oak_log
fill 76 137 323 76 138 323 minecraft:stripped_dark_oak_log
fill 76 137 325 76 138 325 minecraft:stripped_dark_oak_log
fill 76 137 327 76 138 327 minecraft:stripped_dark_oak_log
fill 77 137 324 77 138 324 minecraft:stripped_dark_oak_log
fill 77 137 326 77 138 326 minecraft:stripped_dark_oak_log
fill 77 137 328 77 138 328 minecraft:stripped_dark_oak_log
fill 78 137 323 78 138 323 minecraft:stripped_dark_oak_log
fill 78 137 325 78 138 325 minecraft:stripped_dark_oak_log
fill 78 137 327 78 138 327 minecraft:stripped_dark_oak_log
fill 79 137 324 79 138 324 minecraft:stripped_dark_oak_log
fill 79 137 326 79 138 326 minecraft:stripped_dark_oak_log
fill 79 137 328 79 138 328 minecraft:stripped_dark_oak_log
fill 80 137 323 80 138 323 minecraft:stripped_dark_oak_log
fill 80 137 325 80 138 325 minecraft:stripped_dark_oak_log
fill 80 137 327 80 138 327 minecraft:stripped_dark_oak_log
setblock 80 137 363 minecraft:stripped_dark_oak_log
fill 81 137 324 81 138 324 minecraft:stripped_dark_oak_log
fill 81 137 326 81 138 326 minecraft:stripped_dark_oak_log
fill 81 137 328 81 138 328 minecraft:stripped_dark_oak_log
fill 82 137 323 82 138 323 minecraft:stripped_dark_oak_log
fill 82 137 325 82 138 325 minecraft:stripped_dark_oak_log
fill 82 137 327 82 138 327 minecraft:stripped_dark_oak_log
fill 83 137 324 83 138 324 minecraft:stripped_dark_oak_log
fill 83 137 326 83 138 326 minecraft:stripped_dark_oak_log
fill 83 137 328 83 138 328 minecraft:stripped_dark_oak_log
setblock 87 137 363 minecraft:stripped_dark_oak_log
setblock 88 137 323 minecraft:stripped_dark_oak_log
setblock 88 137 330 minecraft:stripped_dark_oak_log
setblock 88 137 337 minecraft:stripped_dark_oak_log
setblock 88 137 344 minecraft:stripped_dark_oak_log
setblock 88 137 351 minecraft:stripped_dark_oak_log
setblock 88 137 358 minecraft:stripped_dark_oak_log
setblock 48 138 326 minecraft:stripped_dark_oak_log
setblock 48 138 333 minecraft:stripped_dark_oak_log
setblock 48 138 354 minecraft:stripped_dark_oak_log
setblock 48 138 361 minecraft:stripped_dark_oak_log
setblock 50 138 325 minecraft:light[level=15]
setblock 50 138 332 minecraft:light[level=12]
setblock 50 138 333 minecraft:light[level=15]
setblock 50 138 339 minecraft:light[level=12]
setblock 50 138 349 minecraft:light[level=15]
setblock 50 138 353 minecraft:light[level=12]
setblock 50 138 357 minecraft:light[level=15]
setblock 50 138 360 minecraft:light[level=12]
setblock 52 138 323 minecraft:stripped_dark_oak_log
setblock 53 138 363 minecraft:stripped_dark_oak_log
setblock 56 138 333 minecraft:cherry_leaves[persistent=true]
setblock 57 138 325 minecraft:light[level=12]
setblock 57 138 339 minecraft:light[level=12]
setblock 57 138 346 minecraft:light[level=12]
setblock 57 138 353 minecraft:light[level=12]
setblock 57 138 360 minecraft:light[level=12]
setblock 58 138 325 minecraft:light[level=15]
setblock 58 138 341 minecraft:light[level=15]
setblock 58 138 349 minecraft:light[level=15]
setblock 58 138 357 minecraft:light[level=15]
setblock 59 138 323 minecraft:stripped_dark_oak_log
setblock 60 138 332 minecraft:cherry_leaves[persistent=true]
setblock 60 138 363 minecraft:stripped_dark_oak_log
setblock 64 138 325 minecraft:light[level=12]
setblock 64 138 332 minecraft:light[level=12]
setblock 64 138 339 minecraft:light[level=12]
setblock 64 138 346 minecraft:light[level=12]
setblock 64 138 353 minecraft:light[level=12]
fill 64 138 359 65 147 359 minecraft:dark_oak_planks
setblock 64 138 360 minecraft:light[level=12]
setblock 66 138 323 minecraft:stripped_dark_oak_log
setblock 66 138 325 minecraft:light[level=15]
setblock 66 138 333 minecraft:light[level=15]
setblock 66 138 341 minecraft:light[level=15]
setblock 66 138 349 minecraft:light[level=15]
setblock 66 138 357 minecraft:light[level=15]
setblock 67 138 363 minecraft:stripped_dark_oak_log
setblock 71 138 325 minecraft:light[level=12]
setblock 71 138 332 minecraft:light[level=12]
setblock 71 138 339 minecraft:light[level=12]
setblock 71 138 346 minecraft:light[level=12]
setblock 71 138 353 minecraft:light[level=12]
setblock 71 138 360 minecraft:light[level=12]
setblock 73 138 323 minecraft:stripped_dark_oak_log
setblock 74 138 325 minecraft:light[level=15]
setblock 74 138 333 minecraft:light[level=15]
setblock 74 138 349 minecraft:light[level=15]
setblock 74 138 357 minecraft:light[level=15]
setblock 74 138 363 minecraft:stripped_dark_oak_log
setblock 78 138 332 minecraft:light[level=12]
setblock 78 138 339 minecraft:light[level=12]
setblock 78 138 346 minecraft:light[level=12]
setblock 78 138 353 minecraft:light[level=12]
setblock 78 138 360 minecraft:light[level=12]
setblock 81 138 363 minecraft:stripped_dark_oak_log
setblock 82 138 333 minecraft:light[level=15]
setblock 82 138 341 minecraft:light[level=15]
setblock 82 138 349 minecraft:light[level=15]
setblock 82 138 357 minecraft:light[level=15]
setblock 85 138 325 minecraft:light[level=12]
setblock 85 138 332 minecraft:light[level=12]
setblock 85 138 339 minecraft:light[level=12]
setblock 85 138 346 minecraft:light[level=12]
setblock 85 138 353 minecraft:light[level=12]
setblock 85 138 360 minecraft:light[level=12]
setblock 87 138 323 minecraft:stripped_dark_oak_log
setblock 88 138 329 minecraft:stripped_dark_oak_log
setblock 88 138 336 minecraft:stripped_dark_oak_log
setblock 88 138 343 minecraft:stripped_dark_oak_log
setblock 88 138 350 minecraft:stripped_dark_oak_log
setblock 88 138 357 minecraft:stripped_dark_oak_log
setblock 88 138 363 minecraft:stripped_dark_oak_log
fill 48 139 327 48 140 327 minecraft:stripped_dark_oak_log
fill 48 139 334 48 140 334 minecraft:stripped_dark_oak_log
setblock 48 139 341 minecraft:shroomlight
setblock 48 139 343 minecraft:shroomlight
setblock 48 139 345 minecraft:shroomlight
setblock 48 139 347 minecraft:shroomlight
fill 48 139 355 48 140 355 minecraft:stripped_dark_oak_log
fill 48 139 362 48 140 362 minecraft:stripped_dark_oak_log
setblock 49 139 340 minecraft:shroomlight
setblock 49 139 342 minecraft:shroomlight
setblock 49 139 344 minecraft:shroomlight
setblock 49 139 346 minecraft:shroomlight
setblock 49 139 348 minecraft:shroomlight
setblock 50 139 341 minecraft:shroomlight
setblock 50 139 343 minecraft:shroomlight
setblock 50 139 345 minecraft:shroomlight
setblock 50 139 347 minecraft:shroomlight
fill 51 139 323 51 140 323 minecraft:stripped_dark_oak_log
setblock 51 139 340 minecraft:shroomlight
setblock 51 139 342 minecraft:shroomlight
setblock 51 139 344 minecraft:shroomlight
setblock 51 139 346 minecraft:shroomlight
setblock 51 139 348 minecraft:shroomlight
setblock 52 139 341 minecraft:shroomlight
setblock 52 139 343 minecraft:shroomlight
setblock 52 139 345 minecraft:shroomlight
setblock 52 139 347 minecraft:shroomlight
setblock 53 139 340 minecraft:shroomlight
setblock 53 139 342 minecraft:shroomlight
setblock 53 139 344 minecraft:shroomlight
setblock 53 139 346 minecraft:shroomlight
setblock 53 139 348 minecraft:shroomlight
setblock 54 139 341 minecraft:shroomlight
setblock 54 139 343 minecraft:shroomlight
setblock 54 139 345 minecraft:shroomlight
setblock 54 139 347 minecraft:shroomlight
fill 54 139 363 54 140 363 minecraft:stripped_dark_oak_log
setblock 55 139 340 minecraft:shroomlight
setblock 55 139 342 minecraft:shroomlight
setblock 55 139 344 minecraft:shroomlight
setblock 55 139 346 minecraft:shroomlight
setblock 55 139 348 minecraft:shroomlight
fill 57 139 332 59 139 333 minecraft:cherry_leaves[persistent=true]
fill 58 139 323 58 140 323 minecraft:stripped_dark_oak_log
setblock 58 139 331 minecraft:cherry_leaves[persistent=true]
fill 61 139 363 61 140 363 minecraft:stripped_dark_oak_log
fill 64 139 357 65 147 357 minecraft:dark_oak_planks
fill 65 139 323 65 140 323 minecraft:stripped_dark_oak_log
fill 66 139 358 66 147 358 minecraft:dark_oak_planks
fill 68 139 363 68 140 363 minecraft:stripped_dark_oak_log
setblock 70 139 364 minecraft:red_concrete
fill 71 139 364 74 196 364 minecraft:spruce_planks
fill 72 139 323 72 140 323 minecraft:stripped_dark_oak_log
setblock 75 139 324 minecraft:shroomlight
setblock 75 139 326 minecraft:shroomlight
setblock 75 139 328 minecraft:shroomlight
fill 75 139 363 75 140 363 minecraft:stripped_dark_oak_log
setblock 76 139 323 minecraft:shroomlight
setblock 76 139 325 minecraft:shroomlight
setblock 76 139 327 minecraft:shroomlight
setblock 77 139 324 minecraft:shroomlight
setblock 77 139 326 minecraft:shroomlight
setblock 77 139 328 minecraft:shroomlight
setblock 78 139 323 minecraft:shroomlight
setblock 78 139 325 minecraft:shroomlight
setblock 78 139 327 minecraft:shroomlight
setblock 79 139 324 minecraft:shroomlight
setblock 79 139 326 minecraft:shroomlight
setblock 79 139 328 minecraft:shroomlight
setblock 80 139 323 minecraft:shroomlight
setblock 80 139 325 minecraft:shroomlight
setblock 80 139 327 minecraft:shroomlight
setblock 81 139 324 minecraft:shroomlight
setblock 81 139 326 minecraft:shroomlight
setblock 81 139 328 minecraft:shroomlight
setblock 82 139 323 minecraft:shroomlight
setblock 82 139 325 minecraft:shroomlight
setblock 82 139 327 minecraft:shroomlight
fill 82 139 363 82 140 363 minecraft:stripped_dark_oak_log
setblock 83 139 324 minecraft:shroomlight
setblock 83 139 326 minecraft:shroomlight
setblock 83 139 328 minecraft:shroomlight
fill 86 139 323 86 140 323 minecraft:stripped_dark_oak_log
fill 88 139 328 88 140 328 minecraft:stripped_dark_oak_log
fill 88 139 335 88 140 335 minecraft:stripped_dark_oak_log
fill 88 139 342 88 140 342 minecraft:stripped_dark_oak_log
fill 88 139 349 88 140 349 minecraft:stripped_dark_oak_log
fill 88 139 356 88 140 356 minecraft:stripped_dark_oak_log
fill 48 140 323 48 140 326 minecraft:stripped_dark_oak_log
fill 48 140 329 48 140 333 minecraft:stripped_dark_oak_log
fill 48 140 336 48 140 339 minecraft:stripped_dark_oak_log
fill 48 140 341 48 141 341 minecraft:stripped_dark_oak_log
fill 48 140 343 48 141 343 minecraft:stripped_dark_oak_log
fill 48 140 345 48 141 345 minecraft:stripped_dark_oak_log
fill 48 140 347 48 141 347 minecraft:stripped_dark_oak_log
fill 48 140 350 48 140 354 minecraft:stripped_dark_oak_log
fill 48 140 357 48 140 361 minecraft:stripped_dark_oak_log
fill 49 140 323 49 141 323 minecraft:stripped_dark_oak_log
fill 49 140 340 49 141 340 minecraft:stripped_dark_oak_log
fill 49 140 342 49 141 342 minecraft:stripped_dark_oak_log
fill 49 140 344 49 141 344 minecraft:stripped_dark_oak_log
fill 49 140 346 49 141 346 minecraft:stripped_dark_oak_log
fill 49 140 348 49 141 348 minecraft:stripped_dark_oak_log
fill 49 140 363 53 140 363 minecraft:stripped_dark_oak_log
fill 50 140 341 50 141 341 minecraft:stripped_dark_oak_log
fill 50 140 343 50 141 343 minecraft:stripped_dark_oak_log
fill 50 140 345 50 141 345 minecraft:stripped_dark_oak_log
fill 50 140 347 50 141 347 minecraft:stripped_dark_oak_log
fill 51 140 340 51 141 340 minecraft:stripped_dark_oak_log
fill 51 140 342 51 141 342 minecraft:stripped_dark_oak_log
fill 51 140 344 51 141 344 minecraft:stripped_dark_oak_log
fill 51 140 346 51 141 346 minecraft:stripped_dark_oak_log
fill 51 140 348 51 141 348 minecraft:stripped_dark_oak_log
fill 52 140 323 56 140 323 minecraft:stripped_dark_oak_log
fill 52 140 341 52 141 341 minecraft:stripped_dark_oak_log
fill 52 140 343 52 141 343 minecraft:stripped_dark_oak_log
fill 52 140 345 52 141 345 minecraft:stripped_dark_oak_log
fill 52 140 347 52 141 347 minecraft:stripped_dark_oak_log
fill 53 140 340 53 141 340 minecraft:stripped_dark_oak_log
fill 53 140 342 53 141 342 minecraft:stripped_dark_oak_log
fill 53 140 344 53 141 344 minecraft:stripped_dark_oak_log
fill 53 140 346 53 141 346 minecraft:stripped_dark_oak_log
fill 53 140 348 53 141 348 minecraft:stripped_dark_oak_log
fill 54 140 341 54 141 341 minecraft:stripped_dark_oak_log
fill 54 140 343 54 141 343 minecraft:stripped_dark_oak_log
fill 54 140 345 54 141 345 minecraft:stripped_dark_oak_log
fill 54 140 347 54 141 347 minecraft:stripped_dark_oak_log
fill 55 140 340 55 141 340 minecraft:stripped_dark_oak_log
fill 55 140 342 55 141 342 minecraft:stripped_dark_oak_log
fill 55 140 344 55 141 344 minecraft:stripped_dark_oak_log
fill 55 140 346 55 141 346 minecraft:stripped_dark_oak_log
fill 55 140 348 55 141 348 minecraft:stripped_dark_oak_log
fill 56 140 363 60 140 363 minecraft:stripped_dark_oak_log
fill 59 140 323 63 140 323 minecraft:stripped_dark_oak_log
fill 63 140 357 63 147 359 minecraft:dark_oak_planks
fill 63 140 363 67 140 363 minecraft:stripped_dark_oak_log
fill 64 140 360 65 147 360 minecraft:dark_oak_planks
fill 66 140 323 70 140 323 minecraft:stripped_dark_oak_log
fill 66 140 357 66 147 357 minecraft:dark_oak_planks
fill 66 140 359 66 147 359 minecraft:dark_oak_planks
fill 70 140 363 74 140 363 minecraft:stripped_dark_oak_log
fill 70 140 364 70 170 364 minecraft:spruce_planks
fill 73 140 323 74 140 323 minecraft:stripped_dark_oak_log
fill 75 140 324 75 141 324 minecraft:stripped_dark_oak_log
fill 75 140 326 75 141 326 minecraft:stripped_dark_oak_log
fill 75 140 328 75 141 328 minecraft:stripped_dark_oak_log
fill 76 140 323 76 141 323 minecraft:stripped_dark_oak_log
fill 76 140 325 76 141 325 minecraft:stripped_dark_oak_log
fill 76 140 327 76 141 327 minecraft:stripped_dark_oak_log
fill 77 140 324 77 141 324 minecraft:stripped_dark_oak_log
fill 77 140 326 77 141 326 minecraft:stripped_dark_oak_log
fill 77 140 328 77 141 328 minecraft:stripped_dark_oak_log
fill 77 140 363 81 140 363 minecraft:stripped_dark_oak_log
fill 78 140 323 78 141 323 minecraft:stripped_dark_oak_log
fill 78 140 325 78 141 325 minecraft:stripped_dark_oak_log
fill 78 140 327 78 141 327 minecraft:stripped_dark_oak_log
fill 79 140 324 79 141 324 minecraft:stripped_dark_oak_log
fill 79 140 326 79 141 326 minecraft:stripped_dark_oak_log
fill 79 140 328 79 141 328 minecraft:stripped_dark_oak_log
fill 80 140 323 80 141 323 minecraft:stripped_dark_oak_log
fill 80 140 325 80 141 325 minecraft:stripped_dark_oak_log
fill 80 140 327 80 141 327 minecraft:stripped_dark_oak_log
fill 81 140 324 81 141 324 minecraft:stripped_dark_oak_log
fill 81 140 326 81 141 326 minecraft:stripped_dark_oak_log
fill 81 140 328 81 141 328 minecraft:stripped_dark_oak_log
fill 82 140 323 82 141 323 minecraft:stripped_dark_oak_log
fill 82 140 325 82 141 325 minecraft:stripped_dark_oak_log
fill 82 140 327 82 141 327 minecraft:stripped_dark_oak_log
fill 83 140 324 83 141 324 minecraft:stripped_dark_oak_log
fill 83 140 326 83 141 326 minecraft:stripped_dark_oak_log
fill 83 140 328 83 141 328 minecraft:stripped_dark_oak_log
fill 84 140 323 84 141 323 minecraft:stripped_dark_oak_log
fill 84 140 363 88 140 363 minecraft:stripped_dark_oak_log
fill 87 140 323 88 140 323 minecraft:stripped_dark_oak_log
fill 88 140 324 88 140 326 minecraft:stripped_dark_oak_log
fill 88 140 329 88 140 333 minecraft:stripped_dark_oak_log
fill 88 140 336 88 140 340 minecraft:stripped_dark_oak_log
fill 88 140 343 88 140 347 minecraft:stripped_dark_oak_log
fill 88 140 350 88 140 354 minecraft:stripped_dark_oak_log
fill 88 140 357 88 140 361 minecraft:stripped_dark_oak_log
setblock 48 141 329 minecraft:stripped_dark_oak_log
setblock 48 141 336 minecraft:stripped_dark_oak_log
setblock 48 141 350 minecraft:stripped_dark_oak_log
setblock 48 141 357 minecraft:stripped_dark_oak_log
setblock 49 141 363 minecraft:stripped_dark_oak_log
setblock 56 141 323 minecraft:stripped_dark_oak_log
setblock 56 141 363 minecraft:stripped_dark_oak_log
setblock 63 141 323 minecraft:stripped_dark_oak_log
fill 63 141 360 63 147 360 minecraft:dark_oak_planks
setblock 63 141 363 minecraft:stripped_dark_oak_log
fill 64 141 356 65 147 356 minecraft:dark_oak_planks
fill 66 141 360 66 147 360 minecraft:dark_oak_planks
fill 67 141 358 67 147 358 minecraft:dark_oak_planks
setblock 69 141 364 minecraft:red_concrete
setblock 70 141 323 minecraft:stripped_dark_oak_log
setblock 70 141 363 minecraft:stripped_dark_oak_log
setblock 77 141 363 minecraft:stripped_dark_oak_log
setblock 84 141 363 minecraft:stripped_dark_oak_log
setblock 88 141 326 minecraft:stripped_dark_oak_log
setblock 88 141 333 minecraft:stripped_dark_oak_log
setblock 88 141 340 minecraft:stripped_dark_oak_log
setblock 88 141 347 minecraft:stripped_dark_oak_log
setblock 88 141 354 minecraft:stripped_dark_oak_log
setblock 88 141 361 minecraft:stripped_dark_oak_log
setblock 48 142 323 minecraft:stripped_dark_oak_log
setblock 48 142 330 minecraft:stripped_dark_oak_log
setblock 48 142 337 minecraft:stripped_dark_oak_log
setblock 48 142 341 minecraft:shroomlight
setblock 48 142 343 minecraft:shroomlight
setblock 48 142 345 minecraft:shroomlight
setblock 48 142 347 minecraft:shroomlight
setblock 48 142 351 minecraft:stripped_dark_oak_log
setblock 48 142 358 minecraft:stripped_dark_oak_log
fill 49 142 335 49 151 335 minecraft:red_wool
setblock 49 142 340 minecraft:shroomlight
setblock 49 142 342 minecraft:shroomlight
setblock 49 142 344 minecraft:shroomlight
setblock 49 142 346 minecraft:shroomlight
setblock 49 142 348 minecraft:shroomlight
setblock 50 142 341 minecraft:shroomlight
setblock 50 142 343 minecraft:shroomlight
setblock 50 142 345 minecraft:shroomlight
setblock 50 142 347 minecraft:shroomlight
setblock 50 142 363 minecraft:stripped_dark_oak_log
setblock 51 142 340 minecraft:shroomlight
setblock 51 142 342 minecraft:shroomlight
setblock 51 142 344 minecraft:shroomlight
setblock 51 142 346 minecraft:shroomlight
setblock 51 142 348 minecraft:shroomlight
setblock 52 142 341 minecraft:shroomlight
setblock 52 142 343 minecraft:shroomlight
setblock 52 142 345 minecraft:shroomlight
setblock 52 142 347 minecraft:shroomlight
setblock 53 142 340 minecraft:shroomlight
setblock 53 142 342 minecraft:shroomlight
setblock 53 142 344 minecraft:shroomlight
setblock 53 142 346 minecraft:shroomlight
setblock 53 142 348 minecraft:shroomlight
setblock 54 142 341 minecraft:shroomlight
setblock 54 142 343 minecraft:shroomlight
setblock 54 142 345 minecraft:shroomlight
setblock 54 142 347 minecraft:shroomlight
setblock 55 142 323 minecraft:stripped_dark_oak_log
setblock 55 142 340 minecraft:shroomlight
setblock 55 142 342 minecraft:shroomlight
setblock 55 142 344 minecraft:shroomlight
setblock 55 142 346 minecraft:shroomlight
setblock 55 142 348 minecraft:shroomlight
setblock 57 142 363 minecraft:stripped_dark_oak_log
setblock 62 142 323 minecraft:stripped_dark_oak_log
fill 62 142 357 62 147 359 minecraft:dark_oak_planks
fill 63 142 356 63 147 356 minecraft:dark_oak_planks
fill 64 142 361 65 147 361 minecraft:dark_oak_planks
setblock 64 142 363 minecraft:stripped_dark_oak_log
fill 66 142 356 66 147 356 minecraft:dark_oak_planks
fill 67 142 357 67 147 357 minecraft:dark_oak_planks
fill 67 142 359 67 147 359 minecraft:dark_oak_planks
setblock 69 142 323 minecraft:stripped_dark_oak_log
fill 69 142 364 69 215 364 minecraft:spruce_planks
setblock 71 142 363 minecraft:stripped_dark_oak_log
setblock 75 142 324 minecraft:shroomlight
setblock 75 142 326 minecraft:shroomlight
setblock 75 142 328 minecraft:shroomlight
setblock 76 142 323 minecraft:shroomlight
setblock 76 142 325 minecraft:shroomlight
setblock 76 142 327 minecraft:shroomlight
setblock 77 142 324 minecraft:shroomlight
setblock 77 142 326 minecraft:shroomlight
setblock 77 142 328 minecraft:shroomlight
setblock 78 142 323 minecraft:shroomlight
setblock 78 142 325 minecraft:shroomlight
setblock 78 142 327 minecraft:shroomlight
setblock 78 142 363 minecraft:stripped_dark_oak_log
setblock 79 142 324 minecraft:shroomlight
setblock 79 142 326 minecraft:shroomlight
setblock 79 142 328 minecraft:shroomlight
setblock 80 142 323 minecraft:shroomlight
setblock 80 142 325 minecraft:shroomlight
setblock 80 142 327 minecraft:shroomlight
setblock 81 142 324 minecraft:shroomlight
setblock 81 142 326 minecraft:shroomlight
setblock 81 142 328 minecraft:shroomlight
setblock 82 142 323 minecraft:shroomlight
setblock 82 142 325 minecraft:shroomlight
setblock 82 142 327 minecraft:shroomlight
setblock 83 142 324 minecraft:shroomlight
setblock 83 142 326 minecraft:shroomlight
setblock 83 142 328 minecraft:shroomlight
setblock 85 142 363 minecraft:stripped_dark_oak_log
setblock 88 142 325 minecraft:stripped_dark_oak_log
setblock 88 142 332 minecraft:stripped_dark_oak_log
setblock 88 142 339 minecraft:stripped_dark_oak_log
setblock 88 142 346 minecraft:stripped_dark_oak_log
setblock 88 142 353 minecraft:stripped_dark_oak_log
setblock 88 142 360 minecraft:stripped_dark_oak_log
setblock 47 143 337 minecraft:red_concrete
setblock 48 143 324 minecraft:stripped_dark_oak_log
setblock 48 143 331 minecraft:stripped_dark_oak_log
setblock 48 143 338 minecraft:stripped_dark_oak_log
fill 48 143 341 48 144 341 minecraft:stripped_dark_oak_log
fill 48 143 343 48 144 343 minecraft:stripped_dark_oak_log
fill 48 143 345 48 144 345 minecraft:stripped_dark_oak_log
fill 48 143 347 48 144 347 minecraft:stripped_dark_oak_log
setblock 48 143 352 minecraft:stripped_dark_oak_log
setblock 48 143 359 minecraft:stripped_dark_oak_log
fill 49 143 333 49 151 334 minecraft:red_wool
fill 49 143 336 49 151 337 minecraft:red_wool
fill 49 143 340 49 144 340 minecraft:stripped_dark_oak_log
fill 49 143 342 49 144 342 minecraft:stripped_dark_oak_log
fill 49 143 344 49 144 344 minecraft:stripped_dark_oak_log
fill 49 143 346 49 144 346 minecraft:stripped_dark_oak_log
fill 49 143 348 49 144 348 minecraft:stripped_dark_oak_log
fill 50 143 341 50 144 341 minecraft:stripped_dark_oak_log
fill 50 143 343 50 144 343 minecraft:stripped_dark_oak_log
fill 50 143 345 50 144 345 minecraft:stripped_dark_oak_log
fill 50 143 347 50 144 347 minecraft:stripped_dark_oak_log
fill 51 143 340 51 144 340 minecraft:stripped_dark_oak_log
fill 51 143 342 51 144 342 minecraft:stripped_dark_oak_log
fill 51 143 344 51 144 344 minecraft:stripped_dark_oak_log
fill 51 143 346 51 144 346 minecraft:stripped_dark_oak_log
fill 51 143 348 51 144 348 minecraft:stripped_dark_oak_log
setblock 51 143 363 minecraft:stripped_dark_oak_log
fill 52 143 341 52 144 341 minecraft:stripped_dark_oak_log
fill 52 143 343 52 144 343 minecraft:stripped_dark_oak_log
fill 52 143 345 52 144 345 minecraft:stripped_dark_oak_log
fill 52 143 347 52 144 347 minecraft:stripped_dark_oak_log
fill 53 143 340 53 144 340 minecraft:stripped_dark_oak_log
fill 53 143 342 53 144 342 minecraft:stripped_dark_oak_log
fill 53 143 344 53 144 344 minecraft:stripped_dark_oak_log
fill 53 143 346 53 144 346 minecraft:stripped_dark_oak_log
fill 53 143 348 53 144 348 minecraft:stripped_dark_oak_log
setblock 54 143 323 minecraft:stripped_dark_oak_log
fill 54 143 341 54 144 341 minecraft:stripped_dark_oak_log
fill 54 143 343 54 144 343 minecraft:stripped_dark_oak_log
fill 54 143 345 54 144 345 minecraft:stripped_dark_oak_log
fill 54 143 347 54 144 347 minecraft:stripped_dark_oak_log
fill 55 143 340 55 144 340 minecraft:stripped_dark_oak_log
fill 55 143 342 55 144 342 minecraft:stripped_dark_oak_log
fill 55 143 344 55 144 344 minecraft:stripped_dark_oak_log
fill 55 143 346 55 144 346 minecraft:stripped_dark_oak_log
fill 55 143 348 55 144 348 minecraft:stripped_dark_oak_log
setblock 58 143 363 minecraft:stripped_dark_oak_log
setblock 61 143 323 minecraft:stripped_dark_oak_log
fill 62 143 356 62 147 356 minecraft:dark_oak_planks
fill 62 143 360 62 147 360 minecraft:dark_oak_planks
fill 63 143 361 63 147 361 minecraft:dark_oak_planks
fill 64 143 355 65 147 355 minecraft:dark_oak_planks
setblock 65 143 363 minecraft:stripped_dark_oak_log
fill 66 143 322 67 156 322 minecraft:spruce_planks
fill 66 143 361 66 147 361 minecraft:dark_oak_planks
fill 67 143 356 67 147 356 minecraft:dark_oak_planks
fill 67 143 360 67 147 360 minecraft:dark_oak_planks
setblock 68 143 322 minecraft:red_concrete
setblock 68 143 323 minecraft:stripped_dark_oak_log
fill 68 143 358 68 147 358 minecraft:dark_oak_planks
setblock 72 143 363 minecraft:stripped_dark_oak_log
fill 75 143 324 75 144 324 minecraft:stripped_dark_oak_log
fill 75 143 326 75 144 326 minecraft:stripped_dark_oak_log
fill 75 143 328 75 144 328 minecraft:stripped_dark_oak_log
fill 76 143 323 76 144 323 minecraft:stripped_dark_oak_log
fill 76 143 325 76 144 325 minecraft:stripped_dark_oak_log
fill 76 143 327 76 144 327 minecraft:stripped_dark_oak_log
fill 77 143 324 77 144 324 minecraft:stripped_dark_oak_log
fill 77 143 326 77 144 326 minecraft:stripped_dark_oak_log
fill 77 143 328 77 144 328 minecraft:stripped_dark_oak_log
fill 78 143 323 78 144 323 minecraft:stripped_dark_oak_log
fill 78 143 325 78 144 325 minecraft:stripped_dark_oak_log
fill 78 143 327 78 144 327 minecraft:stripped_dark_oak_log
fill 79 143 324 79 144 324 minecraft:stripped_dark_oak_log
fill 79 143 326 79 144 326 minecraft:stripped_dark_oak_log
fill 79 143 328 79 144 328 minecraft:stripped_dark_oak_log
setblock 79 143 363 minecraft:stripped_dark_oak_log
fill 80 143 323 80 144 323 minecraft:stripped_dark_oak_log
fill 80 143 325 80 144 325 minecraft:stripped_dark_oak_log
fill 80 143 327 80 144 327 minecraft:stripped_dark_oak_log
fill 81 143 324 81 144 324 minecraft:stripped_dark_oak_log
fill 81 143 326 81 144 326 minecraft:stripped_dark_oak_log
fill 81 143 328 81 144 328 minecraft:stripped_dark_oak_log
fill 82 143 323 82 144 323 minecraft:stripped_dark_oak_log
fill 82 143 325 82 144 325 minecraft:stripped_dark_oak_log
fill 82 143 327 82 144 327 minecraft:stripped_dark_oak_log
fill 83 143 324 83 144 324 minecraft:stripped_dark_oak_log
fill 83 143 326 83 144 326 minecraft:stripped_dark_oak_log
fill 83 143 328 83 144 328 minecraft:stripped_dark_oak_log
setblock 86 143 363 minecraft:stripped_dark_oak_log
setblock 88 143 324 minecraft:stripped_dark_oak_log
setblock 88 143 331 minecraft:stripped_dark_oak_log
setblock 88 143 338 minecraft:stripped_dark_oak_log
setblock 88 143 345 minecraft:stripped_dark_oak_log
setblock 88 143 352 minecraft:stripped_dark_oak_log
setblock 88 143 359 minecraft:stripped_dark_oak_log
fill 47 144 337 47 219 337 minecraft:spruce_planks
setblock 48 144 325 minecraft:stripped_dark_oak_log
setblock 48 144 332 minecraft:stripped_dark_oak_log
setblock 48 144 339 minecraft:stripped_dark_oak_log
setblock 48 144 353 minecraft:stripped_dark_oak_log
setblock 48 144 360 minecraft:stripped_dark_oak_log
setblock 50 144 325 minecraft:light[level=12]
setblock 50 144 332 minecraft:light[level=12]
setblock 50 144 339 minecraft:light[level=12]
setblock 50 144 353 minecraft:light[level=12]
setblock 50 144 360 minecraft:light[level=12]
setblock 52 144 363 minecraft:stripped_dark_oak_log
setblock 53 144 323 minecraft:stripped_dark_oak_log
setblock 57 144 325 minecraft:light[level=12]
setblock 57 144 332 minecraft:light[level=12]
setblock 57 144 339 minecraft:light[level=12]
setblock 57 144 346 minecraft:light[level=12]
setblock 57 144 353 minecraft:light[level=12]
setblock 57 144 360 minecraft:light[level=12]
setblock 59 144 363 minecraft:stripped_dark_oak_log
setblock 60 144 323 minecraft:stripped_dark_oak_log
fill 61 144 357 61 147 360 minecraft:dark_oak_planks
fill 62 144 361 62 147 361 minecraft:dark_oak_planks
fill 63 144 355 63 147 355 minecraft:dark_oak_planks
setblock 64 144 325 minecraft:light[level=12]
setblock 64 144 332 minecraft:light[level=12]
setblock 64 144 339 minecraft:light[level=12]
setblock 64 144 346 minecraft:light[level=12]
setblock 64 144 353 minecraft:light[level=12]
fill 64 144 362 65 147 362 minecraft:dark_oak_planks
fill 66 144 355 66 147 355 minecraft:dark_oak_planks
setblock 66 144 363 minecraft:stripped_dark_oak_log
setblock 67 144 323 minecraft:stripped_dark_oak_log
fill 67 144 361 67 147 361 minecraft:dark_oak_planks
fill 68 144 322 68 215 322 minecraft:spruce_planks
fill 68 144 357 68 147 357 minecraft:dark_oak_planks
fill 68 144 359 68 147 360 minecraft:dark_oak_planks
setblock 71 144 325 minecraft:light[level=12]
setblock 71 144 332 minecraft:light[level=12]
setblock 71 144 339 minecraft:light[level=12]
setblock 71 144 346 minecraft:light[level=12]
setblock 71 144 353 minecraft:light[level=12]
setblock 71 144 360 minecraft:light[level=12]
setblock 73 144 363 minecraft:stripped_dark_oak_log
setblock 74 144 323 minecraft:stripped_dark_oak_log
setblock 78 144 332 minecraft:light[level=12]
setblock 78 144 339 minecraft:light[level=12]
setblock 78 144 346 minecraft:light[level=12]
setblock 78 144 353 minecraft:light[level=12]
setblock 78 144 360 minecraft:light[level=12]
setblock 80 144 363 minecraft:stripped_dark_oak_log
setblock 85 144 325 minecraft:light[level=12]
setblock 85 144 332 minecraft:light[level=12]
setblock 85 144 339 minecraft:light[level=12]
setblock 85 144 346 minecraft:light[level=12]
setblock 85 144 353 minecraft:light[level=12]
setblock 85 144 360 minecraft:light[level=12]
setblock 87 144 363 minecraft:stripped_dark_oak_log
setblock 88 144 323 minecraft:stripped_dark_oak_log
setblock 88 144 330 minecraft:stripped_dark_oak_log
setblock 88 144 337 minecraft:stripped_dark_oak_log
setblock 88 144 344 minecraft:stripped_dark_oak_log
setblock 88 144 351 minecraft:stripped_dark_oak_log
setblock 88 144 358 minecraft:stripped_dark_oak_log
setblock 48 145 326 minecraft:stripped_dark_oak_log
setblock 48 145 333 minecraft:stripped_dark_oak_log
setblock 48 145 341 minecraft:shroomlight
setblock 48 145 343 minecraft:shroomlight
setblock 48 145 345 minecraft:shroomlight
setblock 48 145 347 minecraft:shroomlight
setblock 48 145 354 minecraft:stripped_dark_oak_log
setblock 48 145 361 minecraft:stripped_dark_oak_log
setblock 49 145 340 minecraft:shroomlight
setblock 49 145 342 minecraft:shroomlight
setblock 49 145 344 minecraft:shroomlight
setblock 49 145 346 minecraft:shroomlight
setblock 49 145 348 minecraft:shroomlight
setblock 50 145 341 minecraft:shroomlight
setblock 50 145 343 minecraft:shroomlight
setblock 50 145 345 minecraft:shroomlight
setblock 50 145 347 minecraft:shroomlight
setblock 51 145 340 minecraft:shroomlight
setblock 51 145 342 minecraft:shroomlight
setblock 51 145 344 minecraft:shroomlight
setblock 51 145 346 minecraft:shroomlight
setblock 51 145 348 minecraft:shroomlight
setblock 52 145 323 minecraft:stripped_dark_oak_log
setblock 52 145 341 minecraft:shroomlight
setblock 52 145 343 minecraft:shroomlight
setblock 52 145 345 minecraft:shroomlight
setblock 52 145 347 minecraft:shroomlight
setblock 53 145 340 minecraft:shroomlight
setblock 53 145 342 minecraft:shroomlight
setblock 53 145 344 minecraft:shroomlight
setblock 53 145 346 minecraft:shroomlight
setblock 53 145 348 minecraft:shroomlight
setblock 53 145 363 minecraft:stripped_dark_oak_log
setblock 54 145 341 minecraft:shroomlight
setblock 54 145 343 minecraft:shroomlight
setblock 54 145 345 minecraft:shroomlight
setblock 54 145 347 minecraft:shroomlight
setblock 55 145 340 minecraft:shroomlight
setblock 55 145 342 minecraft:shroomlight
setblock 55 145 344 minecraft:shroomlight
setblock 55 145 346 minecraft:shroomlight
setblock 55 145 348 minecraft:shroomlight
setblock 59 145 323 minecraft:stripped_dark_oak_log
setblock 60 145 363 minecraft:stripped_dark_oak_log
fill 61 145 356 61 147 356 minecraft:dark_oak_planks
fill 61 145 361 61 147 361 minecraft:dark_oak_planks
fill 62 145 355 62 147 355 minecraft:dark_oak_planks
fill 62 145 362 63 147 362 minecraft:dark_oak_planks
fill 64 145 354 65 147 354 minecraft:dark_oak_planks
setblock 66 145 323 minecraft:stripped_dark_oak_log
fill 66 145 362 67 147 362 minecraft:dark_oak_planks
fill 67 145 355 67 147 355 minecraft:dark_oak_planks
setblock 67 145 363 minecraft:stripped_dark_oak_log
fill 68 145 356 68 147 356 minecraft:dark_oak_planks
fill 68 145 361 68 147 361 minecraft:dark_oak_planks
setblock 73 145 323 minecraft:stripped_dark_oak_log
setblock 74 145 363 minecraft:stripped_dark_oak_log
setblock 75 145 324 minecraft:shroomlight
setblock 75 145 326 minecraft:shroomlight
setblock 75 145 328 minecraft:shroomlight
setblock 76 145 323 minecraft:shroomlight
setblock 76 145 325 minecraft:shroomlight
setblock 76 145 327 minecraft:shroomlight
setblock 77 145 324 minecraft:shroomlight
setblock 77 145 326 minecraft:shroomlight
setblock 77 145 328 minecraft:shroomlight
setblock 78 145 323 minecraft:shroomlight
setblock 78 145 325 minecraft:shroomlight
setblock 78 145 327 minecraft:shroomlight
setblock 79 145 324 minecraft:shroomlight
setblock 79 145 326 minecraft:shroomlight
setblock 79 145 328 minecraft:shroomlight
setblock 80 145 323 minecraft:shroomlight
setblock 80 145 325 minecraft:shroomlight
setblock 80 145 327 minecraft:shroomlight
setblock 81 145 324 minecraft:shroomlight
setblock 81 145 326 minecraft:shroomlight
setblock 81 145 328 minecraft:shroomlight
setblock 81 145 363 minecraft:stripped_dark_oak_log
setblock 82 145 323 minecraft:shroomlight
setblock 82 145 325 minecraft:shroomlight
setblock 82 145 327 minecraft:shroomlight
setblock 83 145 324 minecraft:shroomlight
setblock 83 145 326 minecraft:shroomlight
setblock 83 145 328 minecraft:shroomlight
setblock 87 145 323 minecraft:stripped_dark_oak_log
setblock 88 145 329 minecraft:stripped_dark_oak_log
setblock 88 145 336 minecraft:stripped_dark_oak_log
setblock 88 145 343 minecraft:stripped_dark_oak_log
setblock 88 145 350 minecraft:stripped_dark_oak_log
setblock 88 145 357 minecraft:stripped_dark_oak_log
setblock 88 145 363 minecraft:stripped_dark_oak_log
setblock 48 146 327 minecraft:stripped_dark_oak_log
setblock 48 146 334 minecraft:stripped_dark_oak_log
fill 48 146 341 48 148 341 minecraft:stripped_dark_oak_log
fill 48 146 343 48 148 343 minecraft:stripped_dark_oak_log
fill 48 146 345 48 148 345 minecraft:stripped_dark_oak_log
fill 48 146 347 48 148 347 minecraft:stripped_dark_oak_log
setblock 48 146 355 minecraft:stripped_dark_oak_log
setblock 48 146 362 minecraft:stripped_dark_oak_log
fill 49 146 340 49 148 340 minecraft:stripped_dark_oak_log
fill 49 146 342 49 148 342 minecraft:stripped_dark_oak_log
fill 49 146 344 49 148 344 minecraft:stripped_dark_oak_log
fill 49 146 346 49 148 346 minecraft:stripped_dark_oak_log
fill 49 146 348 49 148 348 minecraft:stripped_dark_oak_log
setblock 50 146 325 minecraft:light[level=15]
setblock 50 146 333 minecraft:light[level=15]
fill 50 146 334 50 147 334 minecraft:iron_bars
fill 50 146 341 50 148 341 minecraft:stripped_dark_oak_log
fill 50 146 343 50 148 343 minecraft:stripped_dark_oak_log
fill 50 146 345 50 148 345 minecraft:stripped_dark_oak_log
fill 50 146 347 50 148 347 minecraft:stripped_dark_oak_log
setblock 50 146 349 minecraft:light[level=15]
setblock 50 146 357 minecraft:light[level=15]
setblock 51 146 323 minecraft:stripped_dark_oak_log
fill 51 146 340 51 148 340 minecraft:stripped_dark_oak_log
fill 51 146 342 51 148 342 minecraft:stripped_dark_oak_log
fill 51 146 344 51 148 344 minecraft:stripped_dark_oak_log
fill 51 146 346 51 148 346 minecraft:stripped_dark_oak_log
fill 51 146 348 51 148 348 minecraft:stripped_dark_oak_log
fill 52 146 341 52 148 341 minecraft:stripped_dark_oak_log
fill 52 146 343 52 148 343 minecraft:stripped_dark_oak_log
fill 52 146 345 52 148 345 minecraft:stripped_dark_oak_log
fill 52 146 347 52 148 347 minecraft:stripped_dark_oak_log
fill 53 146 340 53 148 340 minecraft:stripped_dark_oak_log
fill 53 146 342 53 148 342 minecraft:stripped_dark_oak_log
fill 53 146 344 53 148 344 minecraft:stripped_dark_oak_log
fill 53 146 346 53 148 346 minecraft:stripped_dark_oak_log
fill 53 146 348 53 148 348 minecraft:stripped_dark_oak_log
fill 54 146 341 54 148 341 minecraft:stripped_dark_oak_log
fill 54 146 343 54 148 343 minecraft:stripped_dark_oak_log
fill 54 146 345 54 148 345 minecraft:stripped_dark_oak_log
fill 54 146 347 54 148 347 minecraft:stripped_dark_oak_log
setblock 54 146 363 minecraft:stripped_dark_oak_log
fill 55 146 340 55 148 340 minecraft:stripped_dark_oak_log
fill 55 146 342 55 148 342 minecraft:stripped_dark_oak_log
fill 55 146 344 55 148 344 minecraft:stripped_dark_oak_log
fill 55 146 346 55 148 346 minecraft:stripped_dark_oak_log
fill 55 146 348 55 148 348 minecraft:stripped_dark_oak_log
setblock 58 146 323 minecraft:stripped_dark_oak_log
setblock 58 146 325 minecraft:light[level=15]
setblock 58 146 333 minecraft:light[level=15]
setblock 58 146 341 minecraft:light[level=15]
setblock 58 146 349 minecraft:light[level=15]
setblock 58 146 357 minecraft:light[level=15]
fill 60 146 357 60 147 360 minecraft:dark_oak_planks
fill 61 146 355 61 147 355 minecraft:dark_oak_planks
setblock 61 146 363 minecraft:stripped_dark_oak_log
fill 62 146 354 63 147 354 minecraft:dark_oak_planks
fill 63 146 363 66 147 363 minecraft:dark_oak_planks
setblock 65 146 323 minecraft:stripped_dark_oak_log
setblock 66 146 325 minecraft:light[level=15]
setblock 66 146 333 minecraft:light[level=15]
setblock 66 146 341 minecraft:light[level=15]
setblock 66 146 349 minecraft:light[level=15]
fill 66 146 354 67 147 354 minecraft:dark_oak_planks
fill 68 146 355 68 147 355 minecraft:dark_oak_planks
setblock 68 146 363 minecraft:stripped_dark_oak_log
fill 69 146 357 69 147 360 minecraft:dark_oak_planks
setblock 72 146 323 minecraft:stripped_dark_oak_log
setblock 74 146 325 minecraft:light[level=15]
setblock 74 146 333 minecraft:light[level=15]
setblock 74 146 349 minecraft:light[level=15]
setblock 74 146 357 minecraft:light[level=15]
fill 75 146 324 75 147 324 minecraft:stripped_dark_oak_log
fill 75 146 326 75 147 326 minecraft:stripped_dark_oak_log
fill 75 146 328 75 147 328 minecraft:stripped_dark_oak_log
setblock 75 146 363 minecraft:stripped_dark_oak_log
fill 76 146 323 76 147 323 minecraft:stripped_dark_oak_log
fill 76 146 325 76 147 325 minecraft:stripped_dark_oak_log
fill 76 146 327 76 147 327 minecraft:stripped_dark_oak_log
fill 77 146 324 77 147 324 minecraft:stripped_dark_oak_log
fill 77 146 326 77 147 326 minecraft:stripped_dark_oak_log
fill 77 146 328 77 147 328 minecraft:stripped_dark_oak_log
fill 78 146 323 78 147 323 minecraft:stripped_dark_oak_log
fill 78 146 325 78 147 325 minecraft:stripped_dark_oak_log
fill 78 146 327 78 147 327 minecraft:stripped_dark_oak_log
fill 79 146 324 79 147 324 minecraft:stripped_dark_oak_log
fill 79 146 326 79 147 326 minecraft:stripped_dark_oak_log
fill 79 146 328 79 147 328 minecraft:stripped_dark_oak_log
fill 80 146 323 80 147 323 minecraft:stripped_dark_oak_log
fill 80 146 325 80 147 325 minecraft:stripped_dark_oak_log
fill 80 146 327 80 147 327 minecraft:stripped_dark_oak_log
fill 81 146 324 81 147 324 minecraft:stripped_dark_oak_log
fill 81 146 326 81 147 326 minecraft:stripped_dark_oak_log
fill 81 146 328 81 147 328 minecraft:stripped_dark_oak_log
fill 82 146 323 82 147 323 minecraft:stripped_dark_oak_log
fill 82 146 325 82 147 325 minecraft:stripped_dark_oak_log
fill 82 146 327 82 147 327 minecraft:stripped_dark_oak_log
setblock 82 146 333 minecraft:light[level=15]
setblock 82 146 341 minecraft:light[level=15]
setblock 82 146 349 minecraft:light[level=15]
setblock 82 146 357 minecraft:light[level=15]
setblock 82 146 363 minecraft:stripped_dark_oak_log
fill 83 146 324 83 147 324 minecraft:stripped_dark_oak_log
fill 83 146 326 83 147 326 minecraft:stripped_dark_oak_log
fill 83 146 328 83 147 328 minecraft:stripped_dark_oak_log
setblock 86 146 323 minecraft:stripped_dark_oak_log
setblock 88 146 328 minecraft:stripped_dark_oak_log
setblock 88 146 335 minecraft:stripped_dark_oak_log
setblock 88 146 342 minecraft:stripped_dark_oak_log
setblock 88 146 349 minecraft:stripped_dark_oak_log
setblock 88 146 356 minecraft:stripped_dark_oak_log
setblock 48 147 334 minecraft:iron_bars
setblock 60 147 356 minecraft:dark_oak_planks
setblock 60 147 361 minecraft:dark_oak_planks
setblock 61 147 362 minecraft:dark_oak_planks
fill 63 147 353 66 147 353 minecraft:dark_oak_planks
setblock 67 147 363 minecraft:dark_oak_planks
setblock 68 147 362 minecraft:dark_oak_planks
setblock 69 147 356 minecraft:dark_oak_planks
setblock 69 147 361 minecraft:dark_oak_planks
setblock 48 148 329 minecraft:stripped_dark_oak_log
setblock 48 148 336 minecraft:stripped_dark_oak_log
setblock 48 148 350 minecraft:stripped_dark_oak_log
setblock 48 148 357 minecraft:stripped_dark_oak_log
setblock 49 148 323 minecraft:stripped_dark_oak_log
setblock 49 148 363 minecraft:stripped_dark_oak_log
setblock 56 148 323 minecraft:stripped_dark_oak_log
setblock 56 148 363 minecraft:stripped_dark_oak_log
setblock 63 148 323 minecraft:stripped_dark_oak_log
setblock 63 148 363 minecraft:stripped_dark_oak_log
fill 64 148 358 65 150 358 minecraft:stripped_dark_oak_log
setblock 70 148 323 minecraft:stripped_dark_oak_log
setblock 70 148 363 minecraft:stripped_dark_oak_log
setblock 75 148 324 minecraft:shroomlight
setblock 75 148 326 minecraft:shroomlight
setblock 75 148 328 minecraft:shroomlight
setblock 76 148 323 minecraft:shroomlight
setblock 76 148 325 minecraft:shroomlight
setblock 76 148 327 minecraft:shroomlight
setblock 77 148 324 minecraft:shroomlight
setblock 77 148 326 minecraft:shroomlight
setblock 77 148 328 minecraft:shroomlight
setblock 77 148 363 minecraft:stripped_dark_oak_log
setblock 78 148 323 minecraft:shroomlight
setblock 78 148 325 minecraft:shroomlight
setblock 78 148 327 minecraft:shroomlight
setblock 79 148 324 minecraft:shroomlight
setblock 79 148 326 minecraft:shroomlight
setblock 79 148 328 minecraft:shroomlight
setblock 80 148 322 minecraft:red_concrete
setblock 80 148 323 minecraft:shroomlight
setblock 80 148 325 minecraft:shroomlight
setblock 80 148 327 minecraft:shroomlight
setblock 81 148 324 minecraft:shroomlight
setblock 81 148 326 minecraft:shroomlight
setblock 81 148 328 minecraft:shroomlight
setblock 82 148 323 minecraft:shroomlight
setblock 82 148 325 minecraft:shroomlight
setblock 82 148 327 minecraft:shroomlight
setblock 83 148 324 minecraft:shroomlight
setblock 83 148 326 minecraft:shroomlight
setblock 83 148 328 minecraft:shroomlight
setblock 84 148 323 minecraft:stripped_dark_oak_log
setblock 84 148 363 minecraft:stripped_dark_oak_log
setblock 88 148 326 minecraft:stripped_dark_oak_log
setblock 88 148 333 minecraft:stripped_dark_oak_log
setblock 88 148 340 minecraft:stripped_dark_oak_log
setblock 88 148 347 minecraft:stripped_dark_oak_log
setblock 88 148 354 minecraft:stripped_dark_oak_log
setblock 88 148 361 minecraft:stripped_dark_oak_log
fill 48 149 323 48 150 323 minecraft:stripped_dark_oak_log
fill 48 149 330 48 150 330 minecraft:stripped_dark_oak_log
fill 48 149 337 48 150 337 minecraft:stripped_dark_oak_log
fill 48 149 349 48 205 349 minecraft:stripped_dark_oak_log
fill 48 149 350 50 149 350 minecraft:iron_bars
fill 48 149 351 48 150 351 minecraft:stripped_dark_oak_log
fill 48 149 358 48 150 358 minecraft:stripped_dark_oak_log
fill 49 149 341 54 149 347 minecraft:red_concrete
fill 50 149 363 50 150 363 minecraft:stripped_dark_oak_log
fill 55 149 323 55 150 323 minecraft:stripped_dark_oak_log
fill 57 149 363 57 150 363 minecraft:stripped_dark_oak_log
fill 62 149 323 62 150 323 minecraft:stripped_dark_oak_log
fill 64 149 363 64 150 363 minecraft:stripped_dark_oak_log
fill 69 149 323 69 150 323 minecraft:stripped_dark_oak_log
fill 71 149 363 71 150 363 minecraft:stripped_dark_oak_log
fill 75 149 324 75 150 324 minecraft:stripped_dark_oak_log
fill 75 149 326 75 150 326 minecraft:stripped_dark_oak_log
fill 75 149 328 75 150 328 minecraft:stripped_dark_oak_log
fill 76 149 323 76 150 323 minecraft:stripped_dark_oak_log
fill 76 149 325 76 150 325 minecraft:stripped_dark_oak_log
fill 76 149 327 76 150 327 minecraft:stripped_dark_oak_log
fill 77 149 324 77 150 324 minecraft:stripped_dark_oak_log
fill 77 149 326 77 150 326 minecraft:stripped_dark_oak_log
fill 77 149 328 77 150 328 minecraft:stripped_dark_oak_log
fill 78 149 323 78 150 323 minecraft:stripped_dark_oak_log
fill 78 149 325 78 150 325 minecraft:stripped_dark_oak_log
fill 78 149 327 78 150 327 minecraft:stripped_dark_oak_log
fill 78 149 363 78 150 363 minecraft:stripped_dark_oak_log
fill 79 149 324 79 150 324 minecraft:stripped_dark_oak_log
fill 79 149 326 79 150 326 minecraft:stripped_dark_oak_log
fill 79 149 328 79 150 328 minecraft:stripped_dark_oak_log
fill 80 149 322 80 219 322 minecraft:spruce_planks
fill 80 149 323 80 150 323 minecraft:stripped_dark_oak_log
fill 80 149 325 80 150 325 minecraft:stripped_dark_oak_log
fill 80 149 327 80 150 327 minecraft:stripped_dark_oak_log
fill 81 149 324 81 150 324 minecraft:stripped_dark_oak_log
fill 81 149 326 81 150 326 minecraft:stripped_dark_oak_log
fill 81 149 328 81 150 328 minecraft:stripped_dark_oak_log
fill 82 149 323 82 150 323 minecraft:stripped_dark_oak_log
fill 82 149 325 82 150 325 minecraft:stripped_dark_oak_log
fill 82 149 327 82 150 327 minecraft:stripped_dark_oak_log
fill 83 149 324 83 150 324 minecraft:stripped_dark_oak_log
fill 83 149 326 83 150 326 minecraft:stripped_dark_oak_log
fill 83 149 328 83 150 328 minecraft:stripped_dark_oak_log
fill 85 149 363 85 150 363 minecraft:stripped_dark_oak_log
fill 88 149 325 88 150 325 minecraft:stripped_dark_oak_log
fill 88 149 332 88 150 332 minecraft:stripped_dark_oak_log
fill 88 149 339 88 150 339 minecraft:stripped_dark_oak_log
fill 88 149 346 88 150 346 minecraft:stripped_dark_oak_log
fill 88 149 353 88 150 353 minecraft:stripped_dark_oak_log
fill 88 149 360 88 150 360 minecraft:stripped_dark_oak_log
fill 48 150 324 48 150 327 minecraft:stripped_dark_oak_log
setblock 48 150 329 minecraft:stripped_dark_oak_log
fill 48 150 331 48 150 334 minecraft:stripped_dark_oak_log
setblock 48 150 336 minecraft:stripped_dark_oak_log
fill 48 150 338 48 150 341 minecraft:stripped_dark_oak_log
setblock 48 150 343 minecraft:stripped_dark_oak_log
fill 48 150 345 48 150 348 minecraft:stripped_dark_oak_log
setblock 48 150 350 minecraft:stripped_dark_oak_log
fill 48 150 352 48 150 355 minecraft:stripped_dark_oak_log
setblock 48 150 357 minecraft:stripped_dark_oak_log
fill 48 150 359 48 150 362 minecraft:stripped_dark_oak_log
setblock 49 150 323 minecraft:stripped_dark_oak_log
fill 49 150 350 50 150 350 minecraft:iron_bars
setblock 49 150 363 minecraft:stripped_dark_oak_log
setblock 50 150 325 minecraft:light[level=12]
setblock 50 150 332 minecraft:light[level=12]
setblock 50 150 339 minecraft:light[level=12]
fill 50 150 342 53 150 346 minecraft:red_concrete
setblock 50 150 353 minecraft:light[level=12]
setblock 50 150 360 minecraft:light[level=12]
fill 51 150 323 54 150 323 minecraft:stripped_dark_oak_log
fill 51 150 363 54 150 363 minecraft:stripped_dark_oak_log
setblock 56 150 323 minecraft:stripped_dark_oak_log
setblock 56 150 363 minecraft:stripped_dark_oak_log
setblock 57 150 325 minecraft:light[level=12]
setblock 57 150 332 minecraft:light[level=12]
setblock 57 150 339 minecraft:light[level=12]
setblock 57 150 346 minecraft:light[level=12]
setblock 57 150 353 minecraft:light[level=12]
setblock 57 150 360 minecraft:light[level=12]
fill 58 150 323 61 150 323 minecraft:stripped_dark_oak_log
fill 58 150 363 61 150 363 minecraft:stripped_dark_oak_log
setblock 63 150 323 minecraft:stripped_dark_oak_log
setblock 63 150 363 minecraft:stripped_dark_oak_log
setblock 64 150 325 minecraft:light[level=12]
setblock 64 150 332 minecraft:light[level=12]
setblock 64 150 339 minecraft:light[level=12]
setblock 64 150 346 minecraft:light[level=12]
setblock 64 150 353 minecraft:light[level=12]
setblock 64 150 360 minecraft:light[level=12]
fill 65 150 323 68 150 323 minecraft:stripped_dark_oak_log
fill 65 150 363 68 150 363 minecraft:stripped_dark_oak_log
setblock 70 150 323 minecraft:stripped_dark_oak_log
setblock 70 150 363 minecraft:stripped_dark_oak_log
setblock 71 150 325 minecraft:light[level=12]
setblock 71 150 332 minecraft:light[level=12]
setblock 71 150 339 minecraft:light[level=12]
setblock 71 150 346 minecraft:light[level=12]
setblock 71 150 353 minecraft:light[level=12]
setblock 71 150 360 minecraft:light[level=12]
fill 72 150 323 74 150 323 minecraft:stripped_dark_oak_log
fill 72 150 363 75 150 363 minecraft:stripped_dark_oak_log
setblock 77 150 363 minecraft:stripped_dark_oak_log
setblock 78 150 332 minecraft:light[level=12]
setblock 78 150 339 minecraft:light[level=12]
setblock 78 150 346 minecraft:light[level=12]
setblock 78 150 353 minecraft:light[level=12]
setblock 78 150 360 minecraft:light[level=12]
fill 79 150 363 82 150 363 minecraft:stripped_dark_oak_log
setblock 84 150 323 minecraft:stripped_dark_oak_log
setblock 84 150 363 minecraft:stripped_dark_oak_log
setblock 85 150 325 minecraft:light[level=12]
setblock 85 150 332 minecraft:light[level=12]
setblock 85 150 339 minecraft:light[level=12]
setblock 85 150 346 minecraft:light[level=12]
setblock 85 150 353 minecraft:light[level=12]
setblock 85 150 360 minecraft:light[level=12]
fill 86 150 323 88 150 323 minecraft:stripped_dark_oak_log
fill 86 150 363 88 150 363 minecraft:stripped_dark_oak_log
setblock 88 150 324 minecraft:stripped_dark_oak_log
setblock 88 150 326 minecraft:stripped_dark_oak_log
fill 88 150 328 88 150 331 minecraft:stripped_dark_oak_log
setblock 88 150 333 minecraft:stripped_dark_oak_log
fill 88 150 335 88 150 338 minecraft:stripped_dark_oak_log
setblock 88 150 340 minecraft:stripped_dark_oak_log
fill 88 150 342 88 150 345 minecraft:stripped_dark_oak_log
setblock 88 150 347 minecraft:stripped_dark_oak_log
fill 88 150 349 88 150 352 minecraft:stripped_dark_oak_log
setblock 88 150 354 minecraft:stripped_dark_oak_log
fill 88 150 356 88 150 359 minecraft:stripped_dark_oak_log
setblock 88 150 361 minecraft:stripped_dark_oak_log
setblock 48 151 325 minecraft:stripped_dark_oak_log
setblock 48 151 332 minecraft:stripped_dark_oak_log
setblock 48 151 339 minecraft:stripped_dark_oak_log
setblock 48 151 346 minecraft:stripped_dark_oak_log
fill 48 151 351 50 152 351 minecraft:iron_bars
setblock 48 151 353 minecraft:stripped_dark_oak_log
setblock 48 151 360 minecraft:stripped_dark_oak_log
fill 51 151 343 52 151 345 minecraft:red_concrete
setblock 52 151 363 minecraft:stripped_dark_oak_log
setblock 53 151 323 minecraft:stripped_dark_oak_log
setblock 59 151 363 minecraft:stripped_dark_oak_log
setblock 60 151 323 minecraft:stripped_dark_oak_log
fill 63 151 357 66 153 359 minecraft:cherry_leaves[persistent=true]
fill 64 151 360 65 153 360 minecraft:cherry_leaves[persistent=true]
setblock 66 151 363 minecraft:stripped_dark_oak_log
setblock 67 151 323 minecraft:stripped_dark_oak_log
setblock 73 151 363 minecraft:stripped_dark_oak_log
setblock 74 151 323 minecraft:stripped_dark_oak_log
setblock 75 151 324 minecraft:shroomlight
setblock 75 151 326 minecraft:shroomlight
setblock 75 151 328 minecraft:shroomlight
setblock 76 151 323 minecraft:shroomlight
setblock 76 151 325 minecraft:shroomlight
setblock 76 151 327 minecraft:shroomlight
setblock 77 151 324 minecraft:shroomlight
setblock 77 151 326 minecraft:shroomlight
setblock 77 151 328 minecraft:shroomlight
setblock 78 151 323 minecraft:shroomlight
setblock 78 151 325 minecraft:shroomlight
setblock 78 151 327 minecraft:shroomlight
setblock 79 151 324 minecraft:shroomlight
setblock 79 151 326 minecraft:shroomlight
setblock 79 151 328 minecraft:shroomlight
setblock 80 151 323 minecraft:shroomlight
setblock 80 151 325 minecraft:shroomlight
setblock 80 151 327 minecraft:shroomlight
setblock 80 151 363 minecraft:stripped_dark_oak_log
setblock 81 151 324 minecraft:shroomlight
setblock 81 151 326 minecraft:shroomlight
setblock 81 151 328 minecraft:shroomlight
setblock 82 151 323 minecraft:shroomlight
setblock 82 151 325 minecraft:shroomlight
setblock 82 151 327 minecraft:shroomlight
setblock 83 151 324 minecraft:shroomlight
setblock 83 151 326 minecraft:shroomlight
setblock 83 151 328 minecraft:shroomlight
setblock 87 151 363 minecraft:stripped_dark_oak_log
setblock 88 151 323 minecraft:stripped_dark_oak_log
setblock 88 151 330 minecraft:stripped_dark_oak_log
setblock 88 151 337 minecraft:stripped_dark_oak_log
setblock 88 151 344 minecraft:stripped_dark_oak_log
setblock 88 151 351 minecraft:stripped_dark_oak_log
setblock 88 151 358 minecraft:stripped_dark_oak_log
setblock 48 152 326 minecraft:stripped_dark_oak_log
setblock 48 152 333 minecraft:stripped_dark_oak_log
setblock 48 152 340 minecraft:stripped_dark_oak_log
setblock 48 152 347 minecraft:stripped_dark_oak_log
setblock 48 152 354 minecraft:stripped_dark_oak_log
setblock 48 152 361 minecraft:stripped_dark_oak_log
fill 49 152 332 49 153 338 minecraft:iron_bars
setblock 50 152 364 minecraft:red_concrete
fill 51 152 344 52 152 344 minecraft:red_concrete
fill 51 152 364 53 208 364 minecraft:spruce_planks
setblock 52 152 323 minecraft:stripped_dark_oak_log
setblock 53 152 363 minecraft:stripped_dark_oak_log
setblock 59 152 323 minecraft:stripped_dark_oak_log
setblock 60 152 363 minecraft:stripped_dark_oak_log
setblock 60 152 364 minecraft:red_concrete
setblock 63 152 360 minecraft:cherry_leaves[persistent=true]
fill 64 152 356 65 152 356 minecraft:cherry_leaves[persistent=true]
setblock 66 152 323 minecraft:stripped_dark_oak_log
setblock 66 152 360 minecraft:cherry_leaves[persistent=true]
setblock 67 152 363 minecraft:stripped_dark_oak_log
setblock 73 152 323 minecraft:stripped_dark_oak_log
setblock 74 152 363 minecraft:stripped_dark_oak_log
setblock 75 152 324 minecraft:stripped_dark_oak_log
setblock 75 152 326 minecraft:stripped_dark_oak_log
setblock 75 152 328 minecraft:stripped_dark_oak_log
setblock 76 152 323 minecraft:stripped_dark_oak_log
setblock 76 152 325 minecraft:stripped_dark_oak_log
setblock 76 152 327 minecraft:stripped_dark_oak_log
setblock 77 152 324 minecraft:stripped_dark_oak_log
setblock 77 152 326 minecraft:stripped_dark_oak_log
setblock 77 152 328 minecraft:stripped_dark_oak_log
fill 78 152 323 78 205 323 minecraft:stripped_dark_oak_log
setblock 78 152 325 minecraft:stripped_dark_oak_log
setblock 78 152 327 minecraft:stripped_dark_oak_log
setblock 79 152 324 minecraft:stripped_dark_oak_log
setblock 79 152 326 minecraft:stripped_dark_oak_log
setblock 79 152 328 minecraft:stripped_dark_oak_log
setblock 80 152 323 minecraft:stripped_dark_oak_log
setblock 80 152 325 minecraft:stripped_dark_oak_log
setblock 80 152 327 minecraft:stripped_dark_oak_log
setblock 81 152 324 minecraft:stripped_dark_oak_log
setblock 81 152 326 minecraft:stripped_dark_oak_log
setblock 81 152 328 minecraft:stripped_dark_oak_log
setblock 81 152 363 minecraft:stripped_dark_oak_log
setblock 82 152 323 minecraft:stripped_dark_oak_log
setblock 82 152 325 minecraft:stripped_dark_oak_log
setblock 82 152 327 minecraft:stripped_dark_oak_log
setblock 83 152 324 minecraft:stripped_dark_oak_log
setblock 83 152 326 minecraft:stripped_dark_oak_log
setblock 83 152 328 minecraft:stripped_dark_oak_log
setblock 87 152 323 minecraft:stripped_dark_oak_log
setblock 88 152 329 minecraft:stripped_dark_oak_log
setblock 88 152 336 minecraft:stripped_dark_oak_log
setblock 88 152 343 minecraft:stripped_dark_oak_log
setblock 88 152 350 minecraft:stripped_dark_oak_log
setblock 88 152 357 minecraft:stripped_dark_oak_log
setblock 88 152 363 minecraft:stripped_dark_oak_log
setblock 48 153 327 minecraft:stripped_dark_oak_log
setblock 48 153 334 minecraft:stripped_dark_oak_log
setblock 48 153 341 minecraft:stripped_dark_oak_log
setblock 48 153 348 minecraft:stripped_dark_oak_log
setblock 48 153 355 minecraft:stripped_dark_oak_log
setblock 48 153 362 minecraft:stripped_dark_oak_log
fill 50 153 364 50 219 364 minecraft:spruce_planks
setblock 51 153 323 minecraft:stripped_dark_oak_log
setblock 54 153 363 minecraft:stripped_dark_oak_log
setblock 58 153 323 minecraft:stripped_dark_oak_log
fill 60 153 364 60 219 364 minecraft:spruce_planks
setblock 61 153 363 minecraft:stripped_dark_oak_log
setblock 65 153 323 minecraft:stripped_dark_oak_log
setblock 68 153 363 minecraft:stripped_dark_oak_log
setblock 72 153 323 minecraft:stripped_dark_oak_log
setblock 75 153 363 minecraft:stripped_dark_oak_log
fill 76 153 324 82 153 327 minecraft:red_concrete
fill 82 153 361 82 162 361 minecraft:red_wool
setblock 82 153 363 minecraft:stripped_dark_oak_log
setblock 86 153 323 minecraft:stripped_dark_oak_log
setblock 88 153 328 minecraft:stripped_dark_oak_log
setblock 88 153 335 minecraft:stripped_dark_oak_log
setblock 88 153 342 minecraft:stripped_dark_oak_log
setblock 88 153 349 minecraft:stripped_dark_oak_log
setblock 88 153 356 minecraft:stripped_dark_oak_log
setblock 50 154 325 minecraft:light[level=15]
setblock 50 154 333 minecraft:light[level=15]
setblock 50 154 341 minecraft:light[level=15]
setblock 50 154 349 minecraft:light[level=15]
setblock 50 154 357 minecraft:light[level=15]
setblock 58 154 325 minecraft:light[level=15]
fill 58 154 326 58 157 326 minecraft:iron_bars
setblock 58 154 333 minecraft:light[level=15]
setblock 58 154 341 minecraft:light[level=15]
setblock 58 154 349 minecraft:light[level=15]
setblock 58 154 357 minecraft:light[level=15]
setblock 66 154 325 minecraft:light[level=15]
setblock 66 154 333 minecraft:light[level=15]
setblock 66 154 341 minecraft:light[level=15]
setblock 66 154 349 minecraft:light[level=15]
setblock 66 154 357 minecraft:light[level=15]
setblock 74 154 325 minecraft:light[level=15]
setblock 74 154 333 minecraft:light[level=15]
setblock 74 154 341 minecraft:light[level=15]
setblock 74 154 349 minecraft:light[level=15]
setblock 74 154 357 minecraft:light[level=15]
fill 77 154 325 81 154 326 minecraft:red_concrete
fill 80 154 361 81 162 361 minecraft:red_wool
setblock 82 154 325 minecraft:light[level=15]
setblock 82 154 333 minecraft:light[level=15]
setblock 82 154 341 minecraft:light[level=15]
setblock 82 154 349 minecraft:light[level=15]
setblock 82 154 357 minecraft:light[level=15]
fill 83 154 361 84 162 361 minecraft:red_wool
setblock 48 155 329 minecraft:stripped_dark_oak_log
setblock 48 155 336 minecraft:stripped_dark_oak_log
setblock 48 155 343 minecraft:stripped_dark_oak_log
setblock 48 155 350 minecraft:stripped_dark_oak_log
setblock 48 155 357 minecraft:stripped_dark_oak_log
setblock 49 155 323 minecraft:stripped_dark_oak_log
setblock 49 155 363 minecraft:stripped_dark_oak_log
setblock 56 155 323 minecraft:stripped_dark_oak_log
setblock 56 155 363 minecraft:stripped_dark_oak_log
setblock 63 155 323 minecraft:stripped_dark_oak_log
setblock 63 155 363 minecraft:stripped_dark_oak_log
setblock 70 155 323 minecraft:stripped_dark_oak_log
setblock 70 155 363 minecraft:stripped_dark_oak_log
setblock 77 155 323 minecraft:stripped_dark_oak_log
setblock 77 155 363 minecraft:stripped_dark_oak_log
fill 78 155 325 80 155 326 minecraft:red_concrete
setblock 84 155 323 minecraft:stripped_dark_oak_log
setblock 84 155 363 minecraft:stripped_dark_oak_log
setblock 88 155 326 minecraft:stripped_dark_oak_log
setblock 88 155 333 minecraft:stripped_dark_oak_log
setblock 88 155 340 minecraft:stripped_dark_oak_log
setblock 88 155 347 minecraft:stripped_dark_oak_log
setblock 88 155 354 minecraft:stripped_dark_oak_log
setblock 88 155 361 minecraft:stripped_dark_oak_log
setblock 48 156 323 minecraft:stripped_dark_oak_log
setblock 48 156 330 minecraft:stripped_dark_oak_log
setblock 48 156 337 minecraft:stripped_dark_oak_log
setblock 48 156 344 minecraft:stripped_dark_oak_log
setblock 48 156 351 minecraft:stripped_dark_oak_log
setblock 48 156 358 minecraft:stripped_dark_oak_log
setblock 50 156 325 minecraft:light[level=12]
setblock 50 156 332 minecraft:light[level=12]
setblock 50 156 339 minecraft:light[level=12]
setblock 50 156 346 minecraft:light[level=12]
setblock 50 156 353 minecraft:light[level=12]
setblock 50 156 360 minecraft:light[level=12]
setblock 50 156 363 minecraft:stripped_dark_oak_log
setblock 55 156 323 minecraft:stripped_dark_oak_log
setblock 57 156 325 minecraft:light[level=12]
setblock 57 156 332 minecraft:light[level=12]
setblock 57 156 339 minecraft:light[level=12]
setblock 57 156 346 minecraft:light[level=12]
setblock 57 156 353 minecraft:light[level=12]
setblock 57 156 360 minecraft:light[level=12]
setblock 57 156 363 minecraft:stripped_dark_oak_log
setblock 62 156 323 minecraft:stripped_dark_oak_log
setblock 64 156 325 minecraft:light[level=12]
setblock 64 156 332 minecraft:light[level=12]
setblock 64 156 339 minecraft:light[level=12]
setblock 64 156 346 minecraft:light[level=12]
setblock 64 156 353 minecraft:light[level=12]
setblock 64 156 360 minecraft:light[level=12]
setblock 64 156 363 minecraft:stripped_dark_oak_log
setblock 69 156 323 minecraft:stripped_dark_oak_log
setblock 71 156 325 minecraft:light[level=12]
setblock 71 156 332 minecraft:light[level=12]
setblock 71 156 339 minecraft:light[level=12]
setblock 71 156 346 minecraft:light[level=12]
setblock 71 156 353 minecraft:light[level=12]
setblock 71 156 360 minecraft:light[level=12]
setblock 71 156 363 minecraft:stripped_dark_oak_log
setblock 76 156 323 minecraft:stripped_dark_oak_log
setblock 78 156 325 minecraft:light[level=12]
setblock 78 156 332 minecraft:light[level=12]
setblock 78 156 339 minecraft:light[level=12]
setblock 78 156 346 minecraft:light[level=12]
setblock 78 156 353 minecraft:light[level=12]
setblock 78 156 360 minecraft:light[level=12]
setblock 78 156 363 minecraft:stripped_dark_oak_log
fill 79 156 324 79 156 327 minecraft:red_concrete
setblock 83 156 323 minecraft:stripped_dark_oak_log
setblock 85 156 325 minecraft:light[level=12]
setblock 85 156 332 minecraft:light[level=12]
setblock 85 156 339 minecraft:light[level=12]
setblock 85 156 346 minecraft:light[level=12]
setblock 85 156 353 minecraft:light[level=12]
setblock 85 156 360 minecraft:light[level=12]
setblock 85 156 363 minecraft:stripped_dark_oak_log
setblock 88 156 325 minecraft:stripped_dark_oak_log
setblock 88 156 332 minecraft:stripped_dark_oak_log
setblock 88 156 339 minecraft:stripped_dark_oak_log
setblock 88 156 346 minecraft:stripped_dark_oak_log
setblock 88 156 353 minecraft:stripped_dark_oak_log
setblock 88 156 360 minecraft:stripped_dark_oak_log
setblock 48 157 324 minecraft:stripped_dark_oak_log
setblock 48 157 331 minecraft:stripped_dark_oak_log
setblock 48 157 338 minecraft:stripped_dark_oak_log
setblock 48 157 345 minecraft:stripped_dark_oak_log
setblock 48 157 352 minecraft:stripped_dark_oak_log
setblock 48 157 359 minecraft:stripped_dark_oak_log
setblock 51 157 363 minecraft:stripped_dark_oak_log
setblock 54 157 323 minecraft:stripped_dark_oak_log
setblock 58 157 363 minecraft:stripped_dark_oak_log
setblock 61 157 323 minecraft:stripped_dark_oak_log
setblock 65 157 363 minecraft:stripped_dark_oak_log
setblock 66 157 322 minecraft:red_concrete
fill 67 157 322 67 219 322 minecraft:spruce_planks
setblock 68 157 323 minecraft:stripped_dark_oak_log
setblock 72 157 363 minecraft:stripped_dark_oak_log
setblock 75 157 323 minecraft:stripped_dark_oak_log
setblock 79 157 363 minecraft:stripped_dark_oak_log
setblock 82 157 323 minecraft:stripped_dark_oak_log
setblock 86 157 363 minecraft:stripped_dark_oak_log
setblock 88 157 324 minecraft:stripped_dark_oak_log
setblock 88 157 331 minecraft:stripped_dark_oak_log
setblock 88 157 338 minecraft:stripped_dark_oak_log
setblock 88 157 345 minecraft:stripped_dark_oak_log
setblock 88 157 352 minecraft:stripped_dark_oak_log
setblock 88 157 359 minecraft:stripped_dark_oak_log
setblock 48 158 325 minecraft:stripped_dark_oak_log
setblock 48 158 332 minecraft:stripped_dark_oak_log
setblock 48 158 339 minecraft:stripped_dark_oak_log
setblock 48 158 346 minecraft:stripped_dark_oak_log
setblock 48 158 353 minecraft:stripped_dark_oak_log
setblock 48 158 360 minecraft:stripped_dark_oak_log
setblock 52 158 363 minecraft:stripped_dark_oak_log
fill 53 158 323 53 160 323 minecraft:stripped_dark_oak_log
fill 53 158 324 63 158 326 minecraft:dark_oak_planks
fill 54 158 323 56 158 323 minecraft:dark_oak_planks
fill 58 158 323 59 158 323 minecraft:dark_oak_planks
setblock 59 158 363 minecraft:stripped_dark_oak_log
fill 60 158 323 60 160 323 minecraft:stripped_dark_oak_log
fill 61 158 323 63 158 323 minecraft:dark_oak_planks
fill 66 158 322 66 181 322 minecraft:spruce_planks
setblock 66 158 363 minecraft:stripped_dark_oak_log
setblock 67 158 323 minecraft:stripped_dark_oak_log
setblock 73 158 363 minecraft:stripped_dark_oak_log
setblock 74 158 323 minecraft:stripped_dark_oak_log
setblock 80 158 363 minecraft:stripped_dark_oak_log
setblock 81 158 323 minecraft:stripped_dark_oak_log
setblock 87 158 363 minecraft:stripped_dark_oak_log
setblock 88 158 323 minecraft:stripped_dark_oak_log
setblock 88 158 330 minecraft:stripped_dark_oak_log
setblock 88 158 337 minecraft:stripped_dark_oak_log
setblock 88 158 344 minecraft:stripped_dark_oak_log
setblock 88 158 351 minecraft:stripped_dark_oak_log
setblock 88 158 358 minecraft:stripped_dark_oak_log
fill 48 159 326 48 160 326 minecraft:stripped_dark_oak_log
fill 48 159 333 48 160 333 minecraft:stripped_dark_oak_log
fill 48 159 340 48 160 340 minecraft:stripped_dark_oak_log
fill 48 159 347 48 160 347 minecraft:stripped_dark_oak_log
fill 48 159 354 48 160 354 minecraft:stripped_dark_oak_log
fill 48 159 361 48 160 361 minecraft:stripped_dark_oak_log
fill 52 159 323 52 160 323 minecraft:stripped_dark_oak_log
fill 53 159 324 63 159 326 minecraft:stripped_dark_oak_log
fill 53 159 363 53 160 363 minecraft:stripped_dark_oak_log
fill 54 159 323 56 160 323 minecraft:stripped_dark_oak_log
fill 58 159 323 59 160 323 minecraft:stripped_dark_oak_log
fill 60 159 363 60 160 363 minecraft:stripped_dark_oak_log
fill 61 159 323 63 160 323 minecraft:stripped_dark_oak_log
fill 66 159 323 66 160 323 minecraft:stripped_dark_oak_log
fill 67 159 363 67 160 363 minecraft:stripped_dark_oak_log
fill 73 159 323 73 160 323 minecraft:stripped_dark_oak_log
fill 74 159 363 74 160 363 minecraft:stripped_dark_oak_log
fill 80 159 323 80 160 323 minecraft:stripped_dark_oak_log
fill 81 159 363 81 160 363 minecraft:stripped_dark_oak_log
fill 87 159 323 87 160 323 minecraft:stripped_dark_oak_log
fill 88 159 329 88 160 329 minecraft:stripped_dark_oak_log
fill 88 159 336 88 160 336 minecraft:stripped_dark_oak_log
fill 88 159 343 88 160 343 minecraft:stripped_dark_oak_log
fill 88 159 350 88 160 350 minecraft:stripped_dark_oak_log
fill 88 159 357 88 160 357 minecraft:stripped_dark_oak_log
fill 88 159 363 88 160 363 minecraft:stripped_dark_oak_log
fill 48 160 323 48 160 325 minecraft:stripped_dark_oak_log
setblock 48 160 327 minecraft:stripped_dark_oak_log
fill 48 160 329 48 160 332 minecraft:stripped_dark_oak_log
setblock 48 160 334 minecraft:stripped_dark_oak_log
fill 48 160 336 48 160 339 minecraft:stripped_dark_oak_log
setblock 48 160 341 minecraft:stripped_dark_oak_log
fill 48 160 343 48 160 346 minecraft:stripped_dark_oak_log
setblock 48 160 348 minecraft:stripped_dark_oak_log
fill 48 160 350 48 160 353 minecraft:stripped_dark_oak_log
setblock 48 160 355 minecraft:stripped_dark_oak_log
fill 48 160 357 48 160 360 minecraft:stripped_dark_oak_log
setblock 48 160 362 minecraft:stripped_dark_oak_log
setblock 49 160 323 minecraft:stripped_dark_oak_log
fill 49 160 363 52 160 363 minecraft:stripped_dark_oak_log
setblock 51 160 323 minecraft:stripped_dark_oak_log
fill 53 160 326 63 160 326 minecraft:red_concrete
setblock 54 160 363 minecraft:stripped_dark_oak_log
fill 56 160 363 59 160 363 minecraft:stripped_dark_oak_log
fill 57 160 322 59 163 322 minecraft:shroomlight
setblock 61 160 363 minecraft:stripped_dark_oak_log
fill 63 160 363 66 160 363 minecraft:stripped_dark_oak_log
setblock 65 160 323 minecraft:stripped_dark_oak_log
fill 67 160 323 70 160 323 minecraft:stripped_dark_oak_log
setblock 68 160 363 minecraft:stripped_dark_oak_log
fill 70 160 363 73 160 363 minecraft:stripped_dark_oak_log
setblock 72 160 323 minecraft:stripped_dark_oak_log
fill 74 160 323 77 160 323 minecraft:stripped_dark_oak_log
setblock 75 160 363 minecraft:stripped_dark_oak_log
fill 77 160 363 80 160 363 minecraft:stripped_dark_oak_log
setblock 79 160 323 minecraft:stripped_dark_oak_log
fill 81 160 323 84 160 323 minecraft:stripped_dark_oak_log
setblock 82 160 363 minecraft:stripped_dark_oak_log
fill 84 160 363 87 160 363 minecraft:stripped_dark_oak_log
setblock 86 160 323 minecraft:stripped_dark_oak_log
fill 88 160 323 88 160 326 minecraft:stripped_dark_oak_log
setblock 88 160 328 minecraft:stripped_dark_oak_log
fill 88 160 330 88 160 333 minecraft:stripped_dark_oak_log
setblock 88 160 335 minecraft:stripped_dark_oak_log
fill 88 160 337 88 160 340 minecraft:stripped_dark_oak_log
setblock 88 160 342 minecraft:stripped_dark_oak_log
fill 88 160 344 88 160 347 minecraft:stripped_dark_oak_log
setblock 88 160 349 minecraft:stripped_dark_oak_log
fill 88 160 351 88 160 354 minecraft:stripped_dark_oak_log
setblock 88 160 356 minecraft:stripped_dark_oak_log
fill 88 160 358 88 160 361 minecraft:stripped_dark_oak_log
setblock 53 161 326 minecraft:stripped_dark_oak_log
setblock 58 161 326 minecraft:stripped_dark_oak_log
setblock 63 161 326 minecraft:stripped_dark_oak_log
fill 81 161 334 82 163 336 minecraft:cherry_leaves[persistent=true]
fill 83 161 334 83 163 335 minecraft:cherry_leaves[persistent=true]
setblock 48 162 329 minecraft:stripped_dark_oak_log
setblock 48 162 336 minecraft:stripped_dark_oak_log
setblock 48 162 343 minecraft:stripped_dark_oak_log
setblock 48 162 350 minecraft:stripped_dark_oak_log
setblock 48 162 357 minecraft:stripped_dark_oak_log
setblock 49 162 323 minecraft:stripped_dark_oak_log
setblock 49 162 363 minecraft:stripped_dark_oak_log
setblock 50 162 325 minecraft:light[level=15]
setblock 50 162 332 minecraft:light[level=12]
setblock 50 162 333 minecraft:light[level=15]
setblock 50 162 339 minecraft:light[level=12]
setblock 50 162 341 minecraft:light[level=15]
setblock 50 162 346 minecraft:light[level=12]
setblock 50 162 349 minecraft:light[level=15]
setblock 50 162 353 minecraft:light[level=12]
setblock 50 162 357 minecraft:light[level=15]
setblock 50 162 360 minecraft:light[level=12]
setblock 56 162 323 minecraft:stripped_dark_oak_log
setblock 56 162 363 minecraft:stripped_dark_oak_log
fill 57 162 324 57 163 325 minecraft:iron_bars
setblock 57 162 332 minecraft:light[level=12]
setblock 57 162 339 minecraft:light[level=12]
setblock 57 162 346 minecraft:light[level=12]
setblock 57 162 353 minecraft:light[level=12]
setblock 57 162 360 minecraft:light[level=12]
setblock 58 162 325 minecraft:light[level=15]
setblock 58 162 333 minecraft:light[level=15]
setblock 58 162 341 minecraft:light[level=15]
setblock 58 162 349 minecraft:light[level=15]
setblock 58 162 357 minecraft:light[level=15]
setblock 63 162 323 minecraft:stripped_dark_oak_log
setblock 63 162 363 minecraft:stripped_dark_oak_log
setblock 64 162 325 minecraft:light[level=12]
setblock 64 162 332 minecraft:light[level=12]
setblock 64 162 339 minecraft:light[level=12]
setblock 64 162 346 minecraft:light[level=12]
setblock 64 162 353 minecraft:light[level=12]
setblock 64 162 360 minecraft:light[level=12]
setblock 66 162 325 minecraft:light[level=15]
setblock 66 162 333 minecraft:light[level=15]
setblock 66 162 341 minecraft:light[level=15]
setblock 66 162 349 minecraft:light[level=15]
setblock 66 162 357 minecraft:light[level=15]
setblock 70 162 323 minecraft:stripped_dark_oak_log
setblock 70 162 363 minecraft:stripped_dark_oak_log
setblock 71 162 325 minecraft:light[level=12]
setblock 71 162 332 minecraft:light[level=12]
setblock 71 162 339 minecraft:light[level=12]
setblock 71 162 346 minecraft:light[level=12]
setblock 71 162 353 minecraft:light[level=12]
setblock 71 162 360 minecraft:light[level=12]
setblock 74 162 325 minecraft:light[level=15]
setblock 74 162 333 minecraft:light[level=15]
setblock 74 162 341 minecraft:light[level=15]
setblock 74 162 349 minecraft:light[level=15]
setblock 74 162 357 minecraft:light[level=15]
setblock 77 162 323 minecraft:stripped_dark_oak_log
setblock 77 162 363 minecraft:stripped_dark_oak_log
setblock 78 162 325 minecraft:light[level=12]
setblock 78 162 332 minecraft:light[level=12]
setblock 78 162 339 minecraft:light[level=12]
setblock 78 162 346 minecraft:light[level=12]
setblock 78 162 353 minecraft:light[level=12]
setblock 78 162 360 minecraft:light[level=12]
fill 80 162 335 80 164 335 minecraft:cherry_leaves[persistent=true]
setblock 82 162 325 minecraft:light[level=15]
fill 82 162 333 83 163 333 minecraft:cherry_leaves[persistent=true]
setblock 82 162 337 minecraft:cherry_leaves[persistent=true]
setblock 82 162 341 minecraft:light[level=15]
setblock 82 162 349 minecraft:light[level=15]
setblock 82 162 357 minecraft:light[level=15]
fill 83 162 336 83 164 336 minecraft:cherry_leaves[persistent=true]
setblock 84 162 323 minecraft:stripped_dark_oak_log
setblock 84 162 363 minecraft:stripped_dark_oak_log
fill 84 162 364 84 200 364 minecraft:spruce_planks
setblock 85 162 325 minecraft:light[level=12]
setblock 85 162 332 minecraft:light[level=12]
setblock 85 162 339 minecraft:light[level=12]
setblock 85 162 346 minecraft:light[level=12]
setblock 85 162 353 minecraft:light[level=12]
setblock 85 162 360 minecraft:light[level=12]
setblock 85 162 364 minecraft:red_concrete
setblock 88 162 326 minecraft:stripped_dark_oak_log
setblock 88 162 333 minecraft:stripped_dark_oak_log
setblock 88 162 340 minecraft:stripped_dark_oak_log
setblock 88 162 347 minecraft:stripped_dark_oak_log
setblock 88 162 354 minecraft:stripped_dark_oak_log
setblock 88 162 361 minecraft:stripped_dark_oak_log
setblock 48 163 323 minecraft:stripped_dark_oak_log
setblock 48 163 330 minecraft:stripped_dark_oak_log
setblock 48 163 337 minecraft:stripped_dark_oak_log
setblock 48 163 344 minecraft:stripped_dark_oak_log
setblock 48 163 351 minecraft:stripped_dark_oak_log
setblock 48 163 358 minecraft:stripped_dark_oak_log
setblock 50 163 363 minecraft:stripped_dark_oak_log
setblock 55 163 323 minecraft:stripped_dark_oak_log
setblock 56 163 364 minecraft:red_concrete
setblock 57 163 363 minecraft:stripped_dark_oak_log
fill 57 163 364 59 165 364 minecraft:spruce_planks
setblock 62 163 323 minecraft:stripped_dark_oak_log
setblock 64 163 363 minecraft:stripped_dark_oak_log
setblock 69 163 323 minecraft:stripped_dark_oak_log
setblock 71 163 363 minecraft:stripped_dark_oak_log
setblock 76 163 323 minecraft:stripped_dark_oak_log
setblock 78 163 363 minecraft:stripped_dark_oak_log
fill 79 163 361 85 164 361 minecraft:iron_bars
setblock 80 163 334 minecraft:cherry_leaves[persistent=true]
setblock 80 163 336 minecraft:cherry_leaves[persistent=true]
setblock 81 163 333 minecraft:cherry_leaves[persistent=true]
setblock 83 163 323 minecraft:stripped_dark_oak_log
setblock 85 163 363 minecraft:stripped_dark_oak_log
fill 85 163 364 85 219 364 minecraft:spruce_planks
setblock 88 163 325 minecraft:stripped_dark_oak_log
setblock 88 163 332 minecraft:stripped_dark_oak_log
setblock 88 163 339 minecraft:stripped_dark_oak_log
setblock 88 163 346 minecraft:stripped_dark_oak_log
setblock 88 163 353 minecraft:stripped_dark_oak_log
setblock 88 163 360 minecraft:stripped_dark_oak_log
setblock 48 164 324 minecraft:stripped_dark_oak_log
setblock 48 164 331 minecraft:stripped_dark_oak_log
setblock 48 164 338 minecraft:stripped_dark_oak_log
setblock 48 164 345 minecraft:stripped_dark_oak_log
setblock 48 164 352 minecraft:stripped_dark_oak_log
setblock 48 164 359 minecraft:stripped_dark_oak_log
setblock 51 164 363 minecraft:stripped_dark_oak_log
setblock 54 164 323 minecraft:stripped_dark_oak_log
fill 56 164 364 56 219 364 minecraft:spruce_planks
fill 57 164 322 59 203 322 minecraft:spruce_planks
setblock 58 164 363 minecraft:stripped_dark_oak_log
setblock 61 164 323 minecraft:stripped_dark_oak_log
setblock 65 164 363 minecraft:stripped_dark_oak_log
setblock 68 164 323 minecraft:stripped_dark_oak_log
setblock 72 164 363 minecraft:stripped_dark_oak_log
setblock 75 164 323 minecraft:stripped_dark_oak_log
fill 76 164 364 77 190 364 minecraft:spruce_planks
setblock 78 164 364 minecraft:red_concrete
setblock 79 164 363 minecraft:stripped_dark_oak_log
fill 81 164 334 81 164 336 minecraft:cherry_leaves[persistent=true]
setblock 82 164 323 minecraft:stripped_dark_oak_log
fill 82 164 334 82 164 335 minecraft:cherry_leaves[persistent=true]
setblock 83 164 335 minecraft:cherry_leaves[persistent=true]
setblock 86 164 363 minecraft:stripped_dark_oak_log
setblock 87 164 340 minecraft:red_concrete
setblock 88 164 324 minecraft:stripped_dark_oak_log
setblock 88 164 331 minecraft:stripped_dark_oak_log
setblock 88 164 338 minecraft:stripped_dark_oak_log
setblock 88 164 345 minecraft:stripped_dark_oak_log
setblock 88 164 352 minecraft:stripped_dark_oak_log
setblock 88 164 359 minecraft:stripped_dark_oak_log
fill 89 164 358 89 219 358 minecraft:spruce_planks
setblock 89 164 359 minecraft:red_concrete
fill 89 164 360 89 183 362 minecraft:spruce_planks
setblock 48 165 325 minecraft:stripped_dark_oak_log
setblock 48 165 332 minecraft:stripped_dark_oak_log
setblock 48 165 339 minecraft:stripped_dark_oak_log
setblock 48 165 346 minecraft:stripped_dark_oak_log
setblock 48 165 353 minecraft:stripped_dark_oak_log
setblock 48 165 360 minecraft:stripped_dark_oak_log
setblock 52 165 363 minecraft:stripped_dark_oak_log
setblock 53 165 323 minecraft:stripped_dark_oak_log
fill 53 165 329 53 166 329 minecraft:dark_oak_planks
setblock 59 165 363 minecraft:stripped_dark_oak_log
setblock 60 165 323 minecraft:stripped_dark_oak_log
setblock 66 165 363 minecraft:stripped_dark_oak_log
setblock 67 165 323 minecraft:stripped_dark_oak_log
setblock 73 165 363 minecraft:stripped_dark_oak_log
setblock 74 165 323 minecraft:stripped_dark_oak_log
fill 76 165 352 77 167 354 minecraft:cherry_leaves[persistent=true]
fill 76 165 357 76 166 357 minecraft:dark_oak_planks
fill 78 165 352 78 167 353 minecraft:cherry_leaves[persistent=true]
fill 78 165 364 78 196 364 minecraft:spruce_planks
setblock 80 165 363 minecraft:stripped_dark_oak_log
setblock 81 165 323 minecraft:stripped_dark_oak_log
fill 82 165 349 82 166 349 minecraft:dark_oak_planks
fill 82 165 354 82 166 354 minecraft:dark_oak_planks
fill 87 165 340 87 166 340 minecraft:shroomlight
setblock 87 165 363 minecraft:stripped_dark_oak_log
setblock 88 165 323 minecraft:stripped_dark_oak_log
setblock 88 165 330 minecraft:stripped_dark_oak_log
setblock 88 165 337 minecraft:stripped_dark_oak_log
setblock 88 165 344 minecraft:stripped_dark_oak_log
setblock 88 165 351 minecraft:stripped_dark_oak_log
setblock 88 165 358 minecraft:stripped_dark_oak_log
fill 89 165 341 89 215 341 minecraft:spruce_planks
setblock 89 165 342 minecraft:red_concrete
fill 89 165 359 89 198 359 minecraft:spruce_planks
setblock 48 166 326 minecraft:stripped_dark_oak_log
setblock 48 166 333 minecraft:stripped_dark_oak_log
setblock 48 166 340 minecraft:stripped_dark_oak_log
setblock 48 166 347 minecraft:stripped_dark_oak_log
setblock 48 166 354 minecraft:stripped_dark_oak_log
setblock 48 166 361 minecraft:stripped_dark_oak_log
setblock 52 166 323 minecraft:stripped_dark_oak_log
fill 52 166 329 52 167 329 minecraft:dark_oak_planks
setblock 53 166 363 minecraft:stripped_dark_oak_log
fill 57 166 364 58 216 364 minecraft:spruce_planks
setblock 59 166 323 minecraft:stripped_dark_oak_log
setblock 59 166 364 minecraft:red_concrete
setblock 60 166 363 minecraft:stripped_dark_oak_log
setblock 66 166 323 minecraft:stripped_dark_oak_log
setblock 67 166 363 minecraft:stripped_dark_oak_log
setblock 73 166 323 minecraft:stripped_dark_oak_log
setblock 74 166 363 minecraft:stripped_dark_oak_log
fill 75 166 352 75 166 353 minecraft:cherry_leaves[persistent=true]
fill 76 166 351 78 167 351 minecraft:cherry_leaves[persistent=true]
fill 76 166 358 76 167 358 minecraft:dark_oak_planks
setblock 77 166 355 minecraft:cherry_leaves[persistent=true]
fill 78 166 354 78 168 354 minecraft:cherry_leaves[persistent=true]
setblock 80 166 323 minecraft:stripped_dark_oak_log
setblock 81 166 363 minecraft:stripped_dark_oak_log
fill 83 166 349 83 167 349 minecraft:dark_oak_planks
fill 83 166 354 83 167 354 minecraft:dark_oak_planks
setblock 87 166 323 minecraft:stripped_dark_oak_log
setblock 88 166 329 minecraft:stripped_dark_oak_log
setblock 88 166 336 minecraft:stripped_dark_oak_log
setblock 88 166 343 minecraft:stripped_dark_oak_log
setblock 88 166 350 minecraft:stripped_dark_oak_log
setblock 88 166 357 minecraft:stripped_dark_oak_log
setblock 88 166 363 minecraft:stripped_dark_oak_log
fill 89 166 342 89 219 342 minecraft:spruce_planks
setblock 48 167 327 minecraft:stripped_dark_oak_log
setblock 48 167 334 minecraft:stripped_dark_oak_log
setblock 48 167 341 minecraft:stripped_dark_oak_log
setblock 48 167 348 minecraft:stripped_dark_oak_log
setblock 48 167 355 minecraft:stripped_dark_oak_log
setblock 48 167 362 minecraft:stripped_dark_oak_log
setblock 51 167 323 minecraft:stripped_dark_oak_log
fill 51 167 329 51 168 329 minecraft:dark_oak_planks
setblock 54 167 363 minecraft:stripped_dark_oak_log
setblock 58 167 323 minecraft:stripped_dark_oak_log
fill 59 167 364 59 218 364 minecraft:spruce_planks
setblock 61 167 363 minecraft:stripped_dark_oak_log
setblock 65 167 323 minecraft:stripped_dark_oak_log
setblock 68 167 363 minecraft:stripped_dark_oak_log
setblock 72 167 323 minecraft:stripped_dark_oak_log
fill 75 167 353 75 168 353 minecraft:cherry_leaves[persistent=true]
setblock 75 167 363 minecraft:stripped_dark_oak_log
fill 76 167 359 76 168 359 minecraft:dark_oak_planks
setblock 79 167 323 minecraft:stripped_dark_oak_log
setblock 82 167 363 minecraft:stripped_dark_oak_log
fill 84 167 349 84 168 349 minecraft:dark_oak_planks
fill 84 167 354 84 168 354 minecraft:dark_oak_planks
setblock 86 167 323 minecraft:stripped_dark_oak_log
setblock 87 167 340 minecraft:red_concrete
setblock 88 167 328 minecraft:stripped_dark_oak_log
setblock 88 167 335 minecraft:stripped_dark_oak_log
setblock 88 167 342 minecraft:stripped_dark_oak_log
setblock 88 167 349 minecraft:stripped_dark_oak_log
setblock 88 167 356 minecraft:stripped_dark_oak_log
setblock 50 168 325 minecraft:light[level=12]
fill 50 168 329 50 169 329 minecraft:dark_oak_planks
setblock 50 168 332 minecraft:light[level=12]
setblock 50 168 339 minecraft:light[level=12]
setblock 50 168 346 minecraft:light[level=12]
setblock 50 168 353 minecraft:light[level=12]
setblock 50 168 360 minecraft:light[level=12]
setblock 57 168 325 minecraft:light[level=12]
setblock 57 168 332 minecraft:light[level=12]
setblock 57 168 339 minecraft:light[level=12]
setblock 57 168 346 minecraft:light[level=12]
setblock 57 168 353 minecraft:light[level=12]
setblock 57 168 360 minecraft:light[level=12]
setblock 64 168 325 minecraft:light[level=12]
setblock 64 168 332 minecraft:light[level=12]
setblock 64 168 339 minecraft:light[level=12]
setblock 64 168 346 minecraft:light[level=12]
setblock 64 168 353 minecraft:light[level=12]
setblock 64 168 360 minecraft:light[level=12]
setblock 71 168 325 minecraft:light[level=12]
setblock 71 168 332 minecraft:light[level=12]
setblock 71 168 339 minecraft:light[level=12]
setblock 71 168 346 minecraft:light[level=12]
setblock 71 168 353 minecraft:light[level=12]
setblock 71 168 360 minecraft:light[level=12]
fill 76 168 351 77 168 353 minecraft:cherry_leaves[persistent=true]
fill 76 168 360 76 169 360 minecraft:dark_oak_planks
setblock 78 168 325 minecraft:light[level=12]
setblock 78 168 332 minecraft:light[level=12]
setblock 78 168 339 minecraft:light[level=12]
setblock 78 168 346 minecraft:light[level=12]
setblock 78 168 353 minecraft:cherry_leaves[persistent=true]
setblock 78 168 360 minecraft:light[level=12]
setblock 85 168 325 minecraft:light[level=12]
setblock 85 168 332 minecraft:light[level=12]
setblock 85 168 339 minecraft:light[level=12]
setblock 85 168 346 minecraft:light[level=12]
fill 85 168 349 85 169 349 minecraft:dark_oak_planks
schedule function dropper:buildpart/73_3 1t
