setblock 552 241 312 minecraft:shroomlight
fill 553 241 275 553 248 275 minecraft:brown_terracotta
fill 553 241 317 553 245 317 minecraft:brown_terracotta
setblock 554 241 280 minecraft:shroomlight
setblock 554 241 286 minecraft:shroomlight
setblock 554 241 292 minecraft:shroomlight
setblock 554 241 298 minecraft:shroomlight
setblock 554 241 304 minecraft:shroomlight
setblock 554 241 310 minecraft:shroomlight
setblock 555 241 278 minecraft:light[level=12]
setblock 555 241 285 minecraft:light[level=12]
setblock 555 241 292 minecraft:light[level=12]
setblock 555 241 299 minecraft:light[level=12]
setblock 555 241 306 minecraft:light[level=12]
setblock 555 241 313 minecraft:light[level=12]
fill 557 241 275 557 248 275 minecraft:brown_terracotta
fill 557 241 317 557 248 317 minecraft:brown_terracotta
fill 559 241 275 559 246 275 minecraft:brown_terracotta
fill 559 241 279 559 245 279 minecraft:brown_terracotta
fill 559 241 283 559 248 283 minecraft:brown_terracotta
fill 559 241 287 559 248 287 minecraft:brown_terracotta
fill 559 241 291 559 245 291 minecraft:brown_terracotta
fill 559 241 295 559 248 295 minecraft:brown_terracotta
fill 559 241 299 559 248 299 minecraft:brown_terracotta
fill 559 241 303 559 245 303 minecraft:brown_terracotta
fill 559 241 307 559 248 307 minecraft:brown_terracotta
fill 559 241 311 559 248 311 minecraft:brown_terracotta
fill 559 241 315 559 245 315 minecraft:brown_terracotta
fill 517 242 283 517 245 283 minecraft:brown_terracotta
fill 518 242 277 518 242 285 minecraft:white_concrete
fill 518 242 289 518 242 297 minecraft:white_concrete
fill 518 242 301 518 242 309 minecraft:white_concrete
fill 518 242 313 523 242 316 minecraft:white_concrete
fill 519 242 277 522 242 284 minecraft:white_concrete
fill 519 242 288 519 242 296 minecraft:white_concrete
fill 519 242 300 522 242 308 minecraft:white_concrete
fill 519 242 312 524 242 312 minecraft:white_concrete
fill 520 242 285 522 242 286 minecraft:white_concrete
fill 520 242 287 522 242 291 minecraft:red_concrete
fill 520 242 292 522 242 299 minecraft:white_concrete
fill 520 242 309 522 242 311 minecraft:white_concrete
fill 521 242 276 529 242 276 minecraft:white_concrete
fill 523 242 277 528 242 280 minecraft:white_concrete
fill 524 242 314 524 243 314 minecraft:white_concrete
fill 524 242 316 524 243 316 minecraft:white_concrete
fill 525 242 311 525 243 311 minecraft:white_concrete
fill 525 242 313 525 243 313 minecraft:white_concrete
fill 525 242 315 525 243 315 minecraft:white_concrete
fill 526 242 299 526 246 300 minecraft:brown_terracotta
fill 526 242 312 526 243 312 minecraft:white_concrete
fill 526 242 314 526 243 314 minecraft:white_concrete
fill 526 242 316 526 243 316 minecraft:white_concrete
fill 527 242 311 527 243 311 minecraft:white_concrete
fill 527 242 313 527 243 313 minecraft:white_concrete
fill 527 242 315 527 243 315 minecraft:white_concrete
fill 528 242 298 528 246 298 minecraft:brown_terracotta
fill 528 242 312 528 243 312 minecraft:white_concrete
fill 528 242 314 528 243 314 minecraft:white_concrete
fill 528 242 316 528 243 316 minecraft:white_concrete
fill 529 242 278 558 242 280 minecraft:white_concrete
fill 529 242 299 529 246 300 minecraft:brown_terracotta
fill 529 242 311 529 243 311 minecraft:white_concrete
fill 529 242 313 529 243 313 minecraft:white_concrete
fill 529 242 315 529 243 315 minecraft:white_concrete
fill 530 242 304 530 243 304 minecraft:brown_terracotta
fill 530 242 306 530 243 306 minecraft:brown_terracotta
fill 530 242 312 530 243 312 minecraft:white_concrete
fill 530 242 314 530 243 314 minecraft:white_concrete
fill 530 242 316 530 243 316 minecraft:white_concrete
fill 531 242 303 531 243 303 minecraft:brown_terracotta
fill 531 242 307 531 243 307 minecraft:brown_terracotta
fill 531 242 311 531 243 311 minecraft:white_concrete
fill 531 242 313 531 243 313 minecraft:white_concrete
fill 531 242 315 531 243 315 minecraft:white_concrete
fill 532 242 277 540 242 277 minecraft:white_concrete
fill 532 242 312 532 243 312 minecraft:white_concrete
fill 532 242 314 532 243 314 minecraft:white_concrete
fill 532 242 316 532 243 316 minecraft:white_concrete
fill 533 242 276 541 242 276 minecraft:white_concrete
fill 533 242 303 533 243 303 minecraft:brown_terracotta
fill 533 242 307 533 243 307 minecraft:brown_terracotta
fill 533 242 311 533 243 311 minecraft:white_concrete
fill 533 242 313 533 243 313 minecraft:white_concrete
fill 533 242 315 533 243 315 minecraft:white_concrete
fill 534 242 306 534 243 306 minecraft:brown_terracotta
fill 534 242 312 558 242 312 minecraft:white_concrete
fill 534 242 314 558 242 314 minecraft:white_concrete
fill 534 242 316 535 242 316 minecraft:white_concrete
fill 535 242 313 558 242 313 minecraft:white_concrete
fill 535 242 315 536 242 315 minecraft:white_concrete
fill 539 242 316 547 242 316 minecraft:white_concrete
fill 540 242 315 548 242 315 minecraft:white_concrete
fill 544 242 277 552 242 277 minecraft:white_concrete
fill 545 242 276 553 242 276 minecraft:white_concrete
fill 551 242 316 558 242 316 minecraft:white_concrete
fill 552 242 315 558 242 315 minecraft:white_concrete
fill 554 242 281 556 242 311 minecraft:white_concrete
fill 556 242 277 558 242 277 minecraft:white_concrete
fill 557 242 276 558 242 276 minecraft:white_concrete
fill 557 242 281 557 242 284 minecraft:white_concrete
fill 557 242 288 557 242 296 minecraft:white_concrete
fill 557 242 300 557 242 308 minecraft:white_concrete
fill 558 242 281 558 242 283 minecraft:white_concrete
fill 558 242 287 558 242 295 minecraft:white_concrete
fill 558 242 299 558 242 307 minecraft:white_concrete
setblock 558 242 311 minecraft:white_concrete
fill 522 243 280 522 243 312 minecraft:red_concrete
fill 523 243 280 554 243 280 minecraft:red_concrete
fill 523 243 289 523 246 289 minecraft:iron_block
setblock 523 243 312 minecraft:red_concrete
setblock 524 243 312 minecraft:white_concrete
fill 526 243 301 526 246 301 minecraft:brown_terracotta
fill 527 243 298 527 246 298 minecraft:brown_terracotta
fill 527 243 302 528 246 302 minecraft:brown_terracotta
fill 529 243 298 529 246 298 minecraft:brown_terracotta
fill 529 243 301 529 246 301 minecraft:brown_terracotta
setblock 530 243 303 minecraft:brown_terracotta
setblock 530 243 307 minecraft:brown_terracotta
setblock 532 243 302 minecraft:brown_terracotta
setblock 534 243 303 minecraft:brown_terracotta
setblock 534 243 307 minecraft:brown_terracotta
setblock 534 243 312 minecraft:white_concrete
setblock 534 243 314 minecraft:white_concrete
setblock 534 243 316 minecraft:white_concrete
setblock 535 243 305 minecraft:brown_terracotta
fill 535 243 312 554 243 312 minecraft:red_concrete
fill 554 243 281 554 243 311 minecraft:red_concrete
fill 556 243 297 556 244 297 minecraft:white_concrete
setblock 524 244 312 minecraft:shroomlight
setblock 524 244 314 minecraft:shroomlight
setblock 524 244 316 minecraft:shroomlight
fill 525 244 299 525 246 300 minecraft:brown_terracotta
setblock 525 244 311 minecraft:shroomlight
setblock 525 244 313 minecraft:shroomlight
setblock 525 244 315 minecraft:shroomlight
fill 526 244 298 526 246 298 minecraft:brown_terracotta
fill 526 244 302 526 246 302 minecraft:brown_terracotta
setblock 526 244 312 minecraft:shroomlight
setblock 526 244 314 minecraft:shroomlight
setblock 526 244 316 minecraft:shroomlight
setblock 527 244 311 minecraft:shroomlight
setblock 527 244 313 minecraft:shroomlight
setblock 527 244 315 minecraft:shroomlight
setblock 528 244 312 minecraft:shroomlight
setblock 528 244 314 minecraft:shroomlight
setblock 528 244 316 minecraft:shroomlight
fill 529 244 302 529 246 302 minecraft:brown_terracotta
setblock 529 244 311 minecraft:shroomlight
setblock 529 244 313 minecraft:shroomlight
setblock 529 244 315 minecraft:shroomlight
fill 530 244 299 530 246 301 minecraft:brown_terracotta
setblock 530 244 312 minecraft:shroomlight
setblock 530 244 314 minecraft:shroomlight
setblock 530 244 316 minecraft:shroomlight
setblock 531 244 311 minecraft:shroomlight
setblock 531 244 313 minecraft:shroomlight
setblock 531 244 315 minecraft:shroomlight
fill 532 244 277 533 257 277 minecraft:red_wool
fill 532 244 305 532 247 305 minecraft:white_concrete
setblock 532 244 312 minecraft:shroomlight
setblock 532 244 314 minecraft:shroomlight
setblock 532 244 316 minecraft:shroomlight
setblock 533 244 311 minecraft:shroomlight
setblock 533 244 313 minecraft:shroomlight
setblock 533 244 315 minecraft:shroomlight
setblock 534 244 312 minecraft:shroomlight
setblock 534 244 314 minecraft:shroomlight
setblock 534 244 316 minecraft:shroomlight
fill 547 244 306 547 246 306 minecraft:shroomlight
fill 518 245 279 518 245 284 minecraft:brown_terracotta
fill 518 245 291 518 245 296 minecraft:brown_terracotta
fill 518 245 303 518 245 308 minecraft:brown_terracotta
fill 518 245 315 518 245 316 minecraft:brown_terracotta
fill 519 245 316 522 245 316 minecraft:brown_terracotta
setblock 520 245 278 minecraft:light[level=15]
setblock 520 245 286 minecraft:light[level=15]
setblock 520 245 294 minecraft:light[level=15]
setblock 520 245 302 minecraft:light[level=15]
setblock 520 245 310 minecraft:light[level=15]
fill 522 245 276 527 245 276 minecraft:brown_terracotta
fill 524 245 312 524 246 312 minecraft:white_concrete
fill 524 245 314 524 246 314 minecraft:white_concrete
fill 524 245 316 524 246 316 minecraft:white_concrete
fill 525 245 298 525 246 298 minecraft:brown_terracotta
fill 525 245 301 525 246 301 minecraft:brown_terracotta
fill 525 245 311 525 246 311 minecraft:white_concrete
fill 525 245 313 525 246 313 minecraft:white_concrete
fill 525 245 315 525 246 315 minecraft:white_concrete
fill 526 245 297 529 246 297 minecraft:brown_terracotta
fill 526 245 312 526 246 312 minecraft:white_concrete
fill 526 245 314 526 246 314 minecraft:white_concrete
fill 526 245 316 526 246 316 minecraft:white_concrete
fill 527 245 311 527 246 311 minecraft:white_concrete
fill 527 245 313 527 246 313 minecraft:white_concrete
fill 527 245 315 527 246 315 minecraft:white_concrete
setblock 528 245 278 minecraft:light[level=15]
setblock 528 245 286 minecraft:light[level=15]
setblock 528 245 294 minecraft:light[level=15]
setblock 528 245 310 minecraft:light[level=15]
fill 528 245 312 528 246 312 minecraft:white_concrete
fill 528 245 314 528 246 314 minecraft:white_concrete
fill 528 245 316 528 246 316 minecraft:white_concrete
fill 529 245 311 529 246 311 minecraft:white_concrete
fill 529 245 313 529 246 313 minecraft:white_concrete
fill 529 245 315 529 246 315 minecraft:white_concrete
fill 529 245 316 534 245 316 minecraft:brown_terracotta
fill 530 245 298 530 246 298 minecraft:brown_terracotta
fill 530 245 312 530 246 312 minecraft:white_concrete
fill 530 245 314 530 246 314 minecraft:white_concrete
fill 531 245 311 531 246 311 minecraft:white_concrete
fill 531 245 313 531 246 313 minecraft:white_concrete
fill 531 245 315 531 246 315 minecraft:white_concrete
fill 532 245 312 532 246 312 minecraft:white_concrete
fill 532 245 314 532 246 314 minecraft:white_concrete
fill 533 245 311 533 246 311 minecraft:white_concrete
fill 533 245 313 533 246 313 minecraft:white_concrete
fill 533 245 315 533 246 315 minecraft:white_concrete
fill 534 245 276 539 245 276 minecraft:brown_terracotta
fill 534 245 312 534 246 312 minecraft:white_concrete
fill 534 245 314 534 246 314 minecraft:white_concrete
setblock 536 245 278 minecraft:light[level=15]
setblock 536 245 286 minecraft:light[level=15]
setblock 536 245 294 minecraft:light[level=15]
setblock 536 245 302 minecraft:light[level=15]
setblock 536 245 310 minecraft:light[level=15]
fill 541 245 316 546 245 316 minecraft:brown_terracotta
setblock 544 245 278 minecraft:light[level=15]
setblock 544 245 286 minecraft:light[level=15]
setblock 544 245 294 minecraft:light[level=15]
setblock 544 245 302 minecraft:light[level=15]
setblock 544 245 310 minecraft:light[level=15]
fill 546 245 276 551 245 276 minecraft:brown_terracotta
setblock 552 245 278 minecraft:light[level=15]
setblock 552 245 286 minecraft:light[level=15]
setblock 552 245 294 minecraft:light[level=15]
setblock 552 245 302 minecraft:light[level=15]
setblock 552 245 310 minecraft:light[level=15]
fill 553 245 316 558 245 316 minecraft:brown_terracotta
fill 558 245 276 558 245 281 minecraft:brown_terracotta
fill 558 245 288 558 245 293 minecraft:brown_terracotta
fill 558 245 300 558 245 305 minecraft:brown_terracotta
fill 558 245 312 558 245 315 minecraft:brown_terracotta
fill 517 246 281 517 251 284 minecraft:shroomlight
fill 517 246 293 517 251 296 minecraft:shroomlight
fill 517 246 305 517 251 308 minecraft:shroomlight
fill 517 246 317 520 251 317 minecraft:shroomlight
fill 524 246 275 527 251 275 minecraft:shroomlight
fill 524 246 299 524 246 300 minecraft:brown_terracotta
setblock 525 246 302 minecraft:brown_terracotta
fill 526 246 303 529 246 303 minecraft:brown_terracotta
fill 529 246 277 531 257 277 minecraft:red_wool
fill 529 246 316 534 246 316 minecraft:white_concrete
fill 529 246 317 532 251 317 minecraft:shroomlight
setblock 530 246 297 minecraft:brown_terracotta
setblock 530 246 302 minecraft:brown_terracotta
fill 531 246 299 531 246 301 minecraft:brown_terracotta
fill 536 246 275 539 251 275 minecraft:shroomlight
fill 541 246 317 544 251 317 minecraft:shroomlight
fill 548 246 275 551 251 275 minecraft:shroomlight
fill 553 246 317 556 251 317 minecraft:shroomlight
fill 559 246 276 559 251 279 minecraft:shroomlight
fill 559 246 288 559 251 291 minecraft:shroomlight
fill 559 246 300 559 251 303 minecraft:shroomlight
fill 559 246 312 559 251 315 minecraft:shroomlight
setblock 517 247 277 minecraft:white_concrete
setblock 517 247 285 minecraft:white_concrete
setblock 517 247 289 minecraft:white_concrete
setblock 517 247 297 minecraft:white_concrete
setblock 517 247 301 minecraft:white_concrete
setblock 517 247 309 minecraft:white_concrete
setblock 517 247 313 minecraft:white_concrete
fill 518 247 285 523 247 285 minecraft:brown_terracotta
fill 518 247 289 523 247 293 minecraft:brown_terracotta
setblock 519 247 275 minecraft:white_concrete
fill 519 247 286 523 247 288 minecraft:brown_terracotta
setblock 520 247 278 minecraft:light[level=12]
setblock 520 247 299 minecraft:light[level=12]
setblock 520 247 306 minecraft:light[level=12]
setblock 520 247 313 minecraft:light[level=12]
setblock 523 247 275 minecraft:white_concrete
setblock 523 247 317 minecraft:white_concrete
setblock 524 247 312 minecraft:shroomlight
setblock 524 247 314 minecraft:shroomlight
setblock 524 247 316 minecraft:shroomlight
setblock 525 247 311 minecraft:shroomlight
setblock 525 247 313 minecraft:shroomlight
setblock 525 247 315 minecraft:shroomlight
setblock 526 247 312 minecraft:shroomlight
setblock 526 247 314 minecraft:shroomlight
setblock 526 247 316 minecraft:shroomlight
setblock 527 247 278 minecraft:light[level=12]
setblock 527 247 285 minecraft:light[level=12]
setblock 527 247 292 minecraft:light[level=12]
setblock 527 247 299 minecraft:light[level=12]
fill 527 247 300 528 249 300 minecraft:white_concrete
setblock 527 247 306 minecraft:light[level=12]
setblock 527 247 311 minecraft:shroomlight
setblock 527 247 313 minecraft:shroomlight
setblock 527 247 315 minecraft:shroomlight
setblock 527 247 317 minecraft:white_concrete
setblock 528 247 312 minecraft:shroomlight
setblock 528 247 314 minecraft:shroomlight
setblock 528 247 316 minecraft:shroomlight
setblock 529 247 311 minecraft:shroomlight
setblock 529 247 313 minecraft:shroomlight
setblock 529 247 315 minecraft:shroomlight
fill 529 247 316 529 249 316 minecraft:white_concrete
setblock 530 247 312 minecraft:shroomlight
setblock 530 247 314 minecraft:shroomlight
setblock 530 247 316 minecraft:shroomlight
setblock 531 247 275 minecraft:white_concrete
fill 531 247 304 531 249 306 minecraft:spruce_leaves[persistent=true]
setblock 531 247 311 minecraft:shroomlight
setblock 531 247 313 minecraft:shroomlight
setblock 531 247 315 minecraft:shroomlight
fill 531 247 316 531 249 316 minecraft:white_concrete
fill 532 247 303 532 249 304 minecraft:spruce_leaves[persistent=true]
fill 532 247 306 533 249 306 minecraft:spruce_leaves[persistent=true]
setblock 532 247 312 minecraft:shroomlight
setblock 532 247 314 minecraft:shroomlight
setblock 532 247 316 minecraft:shroomlight
fill 533 247 304 533 249 305 minecraft:spruce_leaves[persistent=true]
setblock 533 247 311 minecraft:shroomlight
setblock 533 247 313 minecraft:shroomlight
setblock 533 247 315 minecraft:shroomlight
fill 533 247 316 533 249 316 minecraft:white_concrete
setblock 534 247 278 minecraft:light[level=12]
setblock 534 247 285 minecraft:light[level=12]
setblock 534 247 292 minecraft:light[level=12]
setblock 534 247 299 minecraft:light[level=12]
fill 534 247 305 534 249 305 minecraft:spruce_leaves[persistent=true]
setblock 534 247 306 minecraft:light[level=12]
setblock 534 247 312 minecraft:shroomlight
setblock 534 247 314 minecraft:shroomlight
setblock 534 247 316 minecraft:shroomlight
setblock 535 247 275 minecraft:white_concrete
setblock 535 247 317 minecraft:white_concrete
setblock 539 247 317 minecraft:white_concrete
setblock 541 247 278 minecraft:light[level=12]
setblock 541 247 285 minecraft:light[level=12]
setblock 541 247 292 minecraft:light[level=12]
setblock 541 247 299 minecraft:light[level=12]
setblock 541 247 306 minecraft:light[level=12]
setblock 541 247 313 minecraft:light[level=12]
setblock 543 247 275 minecraft:white_concrete
fill 546 247 306 547 256 306 minecraft:brown_terracotta
setblock 547 247 275 minecraft:white_concrete
setblock 547 247 317 minecraft:white_concrete
setblock 548 247 278 minecraft:light[level=12]
setblock 548 247 285 minecraft:light[level=12]
setblock 548 247 292 minecraft:light[level=12]
setblock 548 247 299 minecraft:light[level=12]
setblock 548 247 306 minecraft:light[level=12]
setblock 548 247 313 minecraft:light[level=12]
setblock 551 247 317 minecraft:white_concrete
setblock 555 247 275 minecraft:white_concrete
setblock 555 247 278 minecraft:light[level=12]
setblock 555 247 285 minecraft:light[level=12]
setblock 555 247 292 minecraft:light[level=12]
setblock 555 247 299 minecraft:light[level=12]
setblock 555 247 306 minecraft:light[level=12]
setblock 555 247 313 minecraft:light[level=12]
setblock 559 247 275 minecraft:white_concrete
setblock 559 247 281 minecraft:white_concrete
setblock 559 247 285 minecraft:white_concrete
setblock 559 247 293 minecraft:white_concrete
setblock 559 247 297 minecraft:white_concrete
setblock 559 247 305 minecraft:white_concrete
setblock 559 247 309 minecraft:white_concrete
setblock 559 247 317 minecraft:white_concrete
setblock 517 248 276 minecraft:white_concrete
fill 517 248 277 517 255 277 minecraft:brown_terracotta
setblock 517 248 278 minecraft:white_concrete
setblock 517 248 280 minecraft:white_concrete
fill 517 248 285 517 255 285 minecraft:brown_terracotta
setblock 517 248 286 minecraft:white_concrete
setblock 517 248 288 minecraft:white_concrete
setblock 517 248 289 minecraft:brown_terracotta
fill 517 248 290 523 248 290 minecraft:white_concrete
fill 517 248 292 523 248 292 minecraft:white_concrete
fill 517 248 297 517 255 297 minecraft:brown_terracotta
setblock 517 248 298 minecraft:white_concrete
setblock 517 248 300 minecraft:white_concrete
fill 517 248 301 517 255 301 minecraft:brown_terracotta
setblock 517 248 302 minecraft:white_concrete
setblock 517 248 304 minecraft:white_concrete
fill 517 248 309 517 255 309 minecraft:brown_terracotta
setblock 517 248 310 minecraft:white_concrete
setblock 517 248 312 minecraft:white_concrete
fill 517 248 313 517 255 313 minecraft:brown_terracotta
setblock 517 248 314 minecraft:white_concrete
setblock 517 248 316 minecraft:white_concrete
setblock 518 248 275 minecraft:white_concrete
fill 518 248 285 523 248 285 minecraft:white_concrete
fill 518 248 289 523 248 289 minecraft:white_concrete
fill 518 248 291 523 248 291 minecraft:white_concrete
fill 518 248 293 523 248 293 minecraft:white_concrete
fill 519 248 275 519 255 275 minecraft:brown_terracotta
fill 519 248 286 523 248 288 minecraft:white_concrete
setblock 520 248 275 minecraft:white_concrete
setblock 522 248 275 minecraft:white_concrete
setblock 522 248 317 minecraft:white_concrete
fill 523 248 275 523 255 275 minecraft:brown_terracotta
fill 523 248 317 523 255 317 minecraft:brown_terracotta
fill 524 248 312 524 249 312 minecraft:white_concrete
fill 524 248 314 524 249 314 minecraft:white_concrete
fill 524 248 316 524 248 317 minecraft:white_concrete
fill 525 248 311 525 249 311 minecraft:white_concrete
fill 525 248 313 525 249 313 minecraft:white_concrete
fill 525 248 315 525 249 315 minecraft:white_concrete
fill 526 248 312 526 249 312 minecraft:white_concrete
fill 526 248 314 526 249 314 minecraft:white_concrete
fill 526 248 316 526 248 317 minecraft:white_concrete
fill 527 248 311 527 249 311 minecraft:white_concrete
fill 527 248 313 527 249 313 minecraft:white_concrete
fill 527 248 315 527 249 315 minecraft:white_concrete
fill 527 248 317 527 255 317 minecraft:brown_terracotta
setblock 528 248 275 minecraft:white_concrete
fill 528 248 312 528 249 312 minecraft:white_concrete
fill 528 248 314 528 249 314 minecraft:white_concrete
fill 528 248 316 528 248 317 minecraft:white_concrete
fill 529 248 311 529 249 311 minecraft:white_concrete
fill 529 248 313 529 249 313 minecraft:white_concrete
fill 529 248 315 529 249 315 minecraft:white_concrete
setblock 530 248 275 minecraft:white_concrete
fill 530 248 304 530 248 306 minecraft:spruce_leaves[persistent=true]
fill 530 248 312 530 249 312 minecraft:white_concrete
fill 530 248 314 530 249 314 minecraft:white_concrete
fill 530 248 316 530 249 316 minecraft:white_concrete
fill 531 248 275 531 255 275 minecraft:brown_terracotta
setblock 531 248 303 minecraft:spruce_leaves[persistent=true]
fill 531 248 307 533 248 307 minecraft:spruce_leaves[persistent=true]
fill 531 248 311 531 249 311 minecraft:white_concrete
fill 531 248 313 531 249 313 minecraft:white_concrete
fill 531 248 315 531 249 315 minecraft:white_concrete
setblock 532 248 275 minecraft:white_concrete
fill 532 248 305 532 249 305 minecraft:spruce_leaves[persistent=true]
fill 532 248 312 532 249 312 minecraft:white_concrete
fill 532 248 314 532 249 314 minecraft:white_concrete
fill 532 248 316 532 249 316 minecraft:white_concrete
setblock 533 248 303 minecraft:spruce_leaves[persistent=true]
fill 533 248 311 533 249 311 minecraft:white_concrete
fill 533 248 313 533 249 313 minecraft:white_concrete
fill 533 248 315 533 249 315 minecraft:white_concrete
setblock 534 248 275 minecraft:white_concrete
setblock 534 248 304 minecraft:spruce_leaves[persistent=true]
setblock 534 248 306 minecraft:spruce_leaves[persistent=true]
fill 534 248 312 534 249 312 minecraft:white_concrete
fill 534 248 314 534 249 314 minecraft:white_concrete
fill 534 248 316 534 248 317 minecraft:white_concrete
fill 535 248 275 535 255 275 minecraft:brown_terracotta
fill 535 248 317 535 255 317 minecraft:brown_terracotta
setblock 536 248 317 minecraft:white_concrete
setblock 538 248 317 minecraft:white_concrete
fill 539 248 317 539 255 317 minecraft:brown_terracotta
setblock 540 248 275 minecraft:white_concrete
setblock 540 248 317 minecraft:white_concrete
setblock 542 248 275 minecraft:white_concrete
fill 543 248 275 543 255 275 minecraft:brown_terracotta
setblock 544 248 275 minecraft:white_concrete
setblock 546 248 275 minecraft:white_concrete
fill 546 248 307 547 256 307 minecraft:brown_terracotta
setblock 546 248 317 minecraft:white_concrete
fill 547 248 275 547 255 275 minecraft:brown_terracotta
fill 547 248 317 547 255 317 minecraft:brown_terracotta
setblock 548 248 317 minecraft:white_concrete
setblock 550 248 317 minecraft:white_concrete
fill 551 248 317 551 255 317 minecraft:brown_terracotta
setblock 552 248 275 minecraft:white_concrete
setblock 552 248 317 minecraft:white_concrete
setblock 554 248 275 minecraft:white_concrete
fill 555 248 275 555 255 275 minecraft:brown_terracotta
setblock 556 248 275 minecraft:white_concrete
setblock 558 248 275 minecraft:white_concrete
setblock 558 248 317 minecraft:white_concrete
setblock 559 248 275 minecraft:brown_terracotta
setblock 559 248 280 minecraft:white_concrete
fill 559 248 281 559 255 281 minecraft:brown_terracotta
setblock 559 248 282 minecraft:white_concrete
setblock 559 248 284 minecraft:white_concrete
fill 559 248 285 559 255 285 minecraft:brown_terracotta
setblock 559 248 286 minecraft:white_concrete
setblock 559 248 292 minecraft:white_concrete
fill 559 248 293 559 255 293 minecraft:brown_terracotta
setblock 559 248 294 minecraft:white_concrete
setblock 559 248 296 minecraft:white_concrete
fill 559 248 297 559 255 297 minecraft:brown_terracotta
setblock 559 248 298 minecraft:white_concrete
setblock 559 248 304 minecraft:white_concrete
fill 559 248 305 559 255 305 minecraft:brown_terracotta
setblock 559 248 306 minecraft:white_concrete
setblock 559 248 308 minecraft:white_concrete
fill 559 248 309 559 255 309 minecraft:brown_terracotta
setblock 559 248 310 minecraft:white_concrete
setblock 559 248 316 minecraft:white_concrete
fill 559 248 317 559 255 317 minecraft:brown_terracotta
setblock 517 249 275 minecraft:white_concrete
fill 517 249 276 517 256 276 minecraft:brown_terracotta
fill 517 249 278 517 256 278 minecraft:brown_terracotta
setblock 517 249 279 minecraft:white_concrete
fill 517 249 280 517 256 280 minecraft:brown_terracotta
fill 517 249 286 517 256 286 minecraft:brown_terracotta
setblock 517 249 287 minecraft:white_concrete
fill 517 249 288 517 252 290 minecraft:shroomlight
setblock 517 249 291 minecraft:white_concrete
fill 517 249 292 517 256 292 minecraft:brown_terracotta
fill 517 249 298 517 256 298 minecraft:brown_terracotta
setblock 517 249 299 minecraft:white_concrete
fill 517 249 300 517 256 300 minecraft:brown_terracotta
fill 517 249 302 517 256 302 minecraft:brown_terracotta
setblock 517 249 303 minecraft:white_concrete
fill 517 249 304 517 256 304 minecraft:brown_terracotta
fill 517 249 310 517 256 310 minecraft:brown_terracotta
setblock 517 249 311 minecraft:white_concrete
fill 517 249 312 517 256 312 minecraft:brown_terracotta
fill 517 249 314 517 256 314 minecraft:brown_terracotta
setblock 517 249 315 minecraft:white_concrete
fill 517 249 316 517 256 316 minecraft:brown_terracotta
fill 518 249 275 518 256 275 minecraft:brown_terracotta
fill 520 249 275 520 256 275 minecraft:brown_terracotta
setblock 521 249 275 minecraft:white_concrete
setblock 521 249 317 minecraft:white_concrete
fill 522 249 275 522 256 275 minecraft:brown_terracotta
fill 522 249 317 522 256 317 minecraft:brown_terracotta
fill 523 249 285 523 249 293 minecraft:red_concrete
fill 524 249 316 524 271 316 minecraft:white_concrete
fill 524 249 317 524 256 317 minecraft:brown_terracotta
setblock 525 249 317 minecraft:white_concrete
fill 526 249 316 526 271 316 minecraft:white_concrete
fill 526 249 317 526 256 317 minecraft:brown_terracotta
fill 528 249 275 528 256 275 minecraft:brown_terracotta
setblock 528 249 316 minecraft:white_concrete
fill 528 249 317 528 256 317 minecraft:brown_terracotta
setblock 529 249 275 minecraft:white_concrete
fill 530 249 275 530 256 275 minecraft:brown_terracotta
fill 532 249 275 532 256 275 minecraft:brown_terracotta
setblock 533 249 275 minecraft:white_concrete
setblock 533 249 317 minecraft:white_concrete
fill 534 249 275 534 256 275 minecraft:brown_terracotta
setblock 534 249 316 minecraft:white_concrete
fill 534 249 317 534 256 317 minecraft:brown_terracotta
fill 536 249 317 536 256 317 minecraft:brown_terracotta
setblock 537 249 317 minecraft:white_concrete
fill 538 249 317 538 256 317 minecraft:brown_terracotta
fill 540 249 275 540 256 275 minecraft:brown_terracotta
fill 540 249 317 540 256 317 minecraft:brown_terracotta
setblock 541 249 275 minecraft:white_concrete
fill 542 249 275 542 256 275 minecraft:brown_terracotta
fill 544 249 275 544 256 275 minecraft:brown_terracotta
setblock 545 249 275 minecraft:white_concrete
fill 545 249 306 545 256 307 minecraft:brown_terracotta
setblock 545 249 317 minecraft:white_concrete
fill 546 249 275 546 256 275 minecraft:brown_terracotta
fill 546 249 305 547 256 305 minecraft:brown_terracotta
fill 546 249 308 547 256 308 minecraft:brown_terracotta
fill 546 249 317 546 256 317 minecraft:brown_terracotta
fill 548 249 306 548 256 307 minecraft:brown_terracotta
fill 548 249 317 548 256 317 minecraft:brown_terracotta
setblock 549 249 317 minecraft:white_concrete
fill 550 249 317 550 256 317 minecraft:brown_terracotta
fill 552 249 275 552 256 275 minecraft:brown_terracotta
fill 552 249 317 552 256 317 minecraft:brown_terracotta
setblock 553 249 275 minecraft:white_concrete
fill 554 249 275 554 256 275 minecraft:brown_terracotta
fill 556 249 275 556 256 275 minecraft:brown_terracotta
setblock 557 249 275 minecraft:white_concrete
setblock 557 249 317 minecraft:white_concrete
fill 558 249 275 558 256 275 minecraft:brown_terracotta
fill 558 249 317 558 256 317 minecraft:brown_terracotta
setblock 559 249 275 minecraft:white_concrete
fill 559 249 280 559 256 280 minecraft:brown_terracotta
fill 559 249 282 559 256 282 minecraft:brown_terracotta
setblock 559 249 283 minecraft:white_concrete
fill 559 249 284 559 256 284 minecraft:brown_terracotta
fill 559 249 286 559 256 286 minecraft:brown_terracotta
setblock 559 249 287 minecraft:white_concrete
fill 559 249 292 559 256 292 minecraft:brown_terracotta
fill 559 249 294 559 256 294 minecraft:brown_terracotta
setblock 559 249 295 minecraft:white_concrete
fill 559 249 296 559 256 296 minecraft:brown_terracotta
fill 559 249 298 559 256 298 minecraft:brown_terracotta
setblock 559 249 299 minecraft:white_concrete
fill 559 249 304 559 256 304 minecraft:brown_terracotta
fill 559 249 306 559 256 306 minecraft:brown_terracotta
setblock 559 249 307 minecraft:white_concrete
fill 559 249 308 559 256 308 minecraft:brown_terracotta
fill 559 249 310 559 256 310 minecraft:brown_terracotta
setblock 559 249 311 minecraft:white_concrete
fill 559 249 316 559 256 316 minecraft:brown_terracotta
fill 517 250 275 517 257 275 minecraft:brown_terracotta
fill 517 250 279 517 257 279 minecraft:brown_terracotta
fill 517 250 287 517 257 287 minecraft:brown_terracotta
fill 517 250 291 517 257 291 minecraft:brown_terracotta
fill 517 250 299 517 257 299 minecraft:brown_terracotta
fill 517 250 303 517 257 303 minecraft:brown_terracotta
fill 517 250 311 517 257 311 minecraft:brown_terracotta
fill 517 250 315 517 257 315 minecraft:brown_terracotta
fill 521 250 275 521 257 275 minecraft:brown_terracotta
fill 521 250 317 521 257 317 minecraft:brown_terracotta
setblock 523 250 285 minecraft:white_concrete
setblock 523 250 289 minecraft:white_concrete
setblock 523 250 293 minecraft:white_concrete
fill 525 250 312 533 250 315 minecraft:red_concrete
fill 525 250 317 525 257 317 minecraft:brown_terracotta
fill 526 250 299 529 252 301 minecraft:spruce_leaves[persistent=true]
fill 527 250 298 528 252 298 minecraft:spruce_leaves[persistent=true]
fill 529 250 275 529 257 275 minecraft:brown_terracotta
fill 533 250 275 533 257 275 minecraft:brown_terracotta
fill 533 250 317 533 257 317 minecraft:brown_terracotta
fill 537 250 317 537 257 317 minecraft:brown_terracotta
fill 541 250 275 541 257 275 minecraft:brown_terracotta
fill 545 250 275 545 257 275 minecraft:brown_terracotta
fill 545 250 305 545 256 305 minecraft:brown_terracotta
fill 545 250 317 545 257 317 minecraft:brown_terracotta
fill 548 250 305 548 256 305 minecraft:brown_terracotta
fill 548 250 308 548 256 308 minecraft:brown_terracotta
fill 549 250 317 549 257 317 minecraft:brown_terracotta
fill 553 250 275 553 257 275 minecraft:brown_terracotta
fill 557 250 275 557 257 275 minecraft:brown_terracotta
fill 557 250 317 557 257 317 minecraft:brown_terracotta
fill 559 250 275 559 255 275 minecraft:brown_terracotta
fill 559 250 283 559 257 283 minecraft:brown_terracotta
fill 559 250 287 559 257 287 minecraft:brown_terracotta
fill 559 250 295 559 257 295 minecraft:brown_terracotta
fill 559 250 299 559 257 299 minecraft:brown_terracotta
fill 559 250 307 559 257 307 minecraft:brown_terracotta
fill 559 250 311 559 257 311 minecraft:brown_terracotta
setblock 526 251 298 minecraft:spruce_leaves[persistent=true]
fill 526 251 313 532 251 314 minecraft:red_concrete
fill 527 251 302 528 251 302 minecraft:spruce_leaves[persistent=true]
setblock 529 251 298 minecraft:spruce_leaves[persistent=true]
fill 544 251 306 544 256 307 minecraft:brown_terracotta
fill 545 251 308 545 256 308 minecraft:brown_terracotta
fill 546 251 304 547 256 304 minecraft:brown_terracotta
fill 546 251 309 547 256 309 minecraft:brown_terracotta
fill 549 251 306 549 256 307 minecraft:brown_terracotta
fill 549 251 310 549 254 310 minecraft:iron_block
fill 517 252 281 517 255 281 minecraft:brown_terracotta
fill 517 252 282 517 252 283 minecraft:shroomlight
fill 517 252 284 517 256 284 minecraft:brown_terracotta
fill 517 252 293 517 255 293 minecraft:brown_terracotta
fill 517 252 294 517 252 295 minecraft:shroomlight
fill 517 252 296 517 256 296 minecraft:brown_terracotta
fill 517 252 305 517 255 305 minecraft:brown_terracotta
fill 517 252 306 517 252 307 minecraft:shroomlight
fill 517 252 308 517 256 308 minecraft:brown_terracotta
fill 517 252 317 517 255 317 minecraft:brown_terracotta
fill 518 252 317 519 252 317 minecraft:shroomlight
fill 520 252 317 520 256 317 minecraft:brown_terracotta
fill 524 252 275 524 256 275 minecraft:brown_terracotta
fill 525 252 275 526 252 275 minecraft:shroomlight
fill 527 252 275 527 255 275 minecraft:brown_terracotta
fill 527 252 313 531 252 314 minecraft:red_concrete
fill 529 252 317 529 257 317 minecraft:brown_terracotta
fill 530 252 317 531 252 317 minecraft:shroomlight
fill 532 252 317 532 256 317 minecraft:brown_terracotta
fill 536 252 275 536 256 275 minecraft:brown_terracotta
fill 537 252 275 538 252 275 minecraft:shroomlight
fill 539 252 275 539 255 275 minecraft:brown_terracotta
fill 541 252 317 541 257 317 minecraft:brown_terracotta
fill 542 252 317 543 252 317 minecraft:shroomlight
fill 544 252 305 544 256 305 minecraft:brown_terracotta
fill 544 252 308 544 256 308 minecraft:brown_terracotta
fill 544 252 317 544 256 317 minecraft:brown_terracotta
fill 545 252 304 545 256 304 minecraft:brown_terracotta
fill 545 252 309 545 256 309 minecraft:brown_terracotta
fill 548 252 275 548 256 275 minecraft:brown_terracotta
fill 548 252 304 548 256 304 minecraft:brown_terracotta
fill 548 252 309 548 256 309 minecraft:brown_terracotta
fill 549 252 275 550 252 275 minecraft:shroomlight
fill 549 252 305 549 256 305 minecraft:brown_terracotta
fill 549 252 308 549 256 308 minecraft:brown_terracotta
fill 551 252 275 551 255 275 minecraft:brown_terracotta
fill 553 252 317 553 257 317 minecraft:brown_terracotta
fill 554 252 317 555 252 317 minecraft:shroomlight
fill 556 252 317 556 256 317 minecraft:brown_terracotta
fill 559 252 276 559 256 276 minecraft:brown_terracotta
fill 559 252 277 559 252 278 minecraft:shroomlight
fill 559 252 279 559 257 279 minecraft:brown_terracotta
fill 559 252 288 559 256 288 minecraft:brown_terracotta
fill 559 252 289 559 252 290 minecraft:shroomlight
fill 559 252 291 559 257 291 minecraft:brown_terracotta
fill 559 252 300 559 256 300 minecraft:brown_terracotta
fill 559 252 301 559 252 302 minecraft:shroomlight
fill 559 252 303 559 257 303 minecraft:brown_terracotta
fill 559 252 312 559 256 312 minecraft:brown_terracotta
fill 559 252 313 559 252 314 minecraft:shroomlight
fill 559 252 315 559 257 315 minecraft:brown_terracotta
fill 517 253 282 517 256 283 minecraft:brown_terracotta
fill 517 253 288 517 255 290 minecraft:brown_terracotta
fill 517 253 294 517 256 295 minecraft:brown_terracotta
fill 517 253 306 517 256 307 minecraft:brown_terracotta
fill 518 253 317 519 255 317 minecraft:brown_terracotta
setblock 520 253 278 minecraft:light[level=15]
setblock 520 253 285 minecraft:light[level=12]
setblock 520 253 286 minecraft:light[level=15]
setblock 520 253 292 minecraft:light[level=12]
setblock 520 253 294 minecraft:light[level=15]
setblock 520 253 299 minecraft:light[level=12]
setblock 520 253 302 minecraft:light[level=15]
setblock 520 253 306 minecraft:light[level=12]
setblock 520 253 310 minecraft:light[level=15]
setblock 520 253 313 minecraft:light[level=12]
fill 525 253 275 526 256 275 minecraft:brown_terracotta
setblock 527 253 278 minecraft:light[level=12]
setblock 527 253 285 minecraft:light[level=12]
setblock 527 253 292 minecraft:light[level=12]
setblock 527 253 299 minecraft:light[level=12]
setblock 527 253 306 minecraft:light[level=12]
setblock 527 253 313 minecraft:light[level=12]
setblock 528 253 278 minecraft:light[level=15]
setblock 528 253 286 minecraft:light[level=15]
setblock 528 253 294 minecraft:light[level=15]
setblock 528 253 302 minecraft:light[level=15]
setblock 528 253 310 minecraft:light[level=15]
fill 528 253 312 530 253 315 minecraft:red_concrete
fill 530 253 317 531 255 317 minecraft:brown_terracotta
setblock 534 253 278 minecraft:light[level=12]
setblock 534 253 285 minecraft:light[level=12]
setblock 534 253 292 minecraft:light[level=12]
setblock 534 253 299 minecraft:light[level=12]
setblock 534 253 306 minecraft:light[level=12]
setblock 534 253 313 minecraft:light[level=12]
setblock 536 253 278 minecraft:light[level=15]
setblock 536 253 286 minecraft:light[level=15]
setblock 536 253 294 minecraft:light[level=15]
setblock 536 253 302 minecraft:light[level=15]
setblock 536 253 310 minecraft:light[level=15]
fill 537 253 275 538 256 275 minecraft:brown_terracotta
setblock 541 253 278 minecraft:light[level=12]
setblock 541 253 285 minecraft:light[level=12]
setblock 541 253 292 minecraft:light[level=12]
setblock 541 253 299 minecraft:light[level=12]
setblock 541 253 306 minecraft:light[level=12]
setblock 541 253 313 minecraft:light[level=12]
fill 542 253 317 543 255 317 minecraft:brown_terracotta
fill 543 253 306 543 256 307 minecraft:brown_terracotta
setblock 544 253 278 minecraft:light[level=15]
setblock 544 253 286 minecraft:light[level=15]
setblock 544 253 294 minecraft:light[level=15]
setblock 544 253 302 minecraft:light[level=15]
fill 544 253 304 544 256 304 minecraft:brown_terracotta
fill 544 253 309 544 256 309 minecraft:brown_terracotta
setblock 544 253 310 minecraft:light[level=15]
fill 546 253 303 547 256 303 minecraft:brown_terracotta
fill 546 253 310 547 256 310 minecraft:brown_terracotta
setblock 548 253 278 minecraft:light[level=12]
setblock 548 253 285 minecraft:light[level=12]
setblock 548 253 292 minecraft:light[level=12]
setblock 548 253 299 minecraft:light[level=12]
setblock 548 253 313 minecraft:light[level=12]
fill 549 253 275 550 256 275 minecraft:brown_terracotta
fill 549 253 304 549 256 304 minecraft:brown_terracotta
fill 549 253 309 549 256 309 minecraft:brown_terracotta
fill 550 253 306 550 256 307 minecraft:brown_terracotta
setblock 552 253 278 minecraft:light[level=15]
setblock 552 253 286 minecraft:light[level=15]
setblock 552 253 294 minecraft:light[level=15]
setblock 552 253 302 minecraft:light[level=15]
setblock 552 253 310 minecraft:light[level=15]
fill 554 253 317 555 255 317 minecraft:brown_terracotta
setblock 555 253 278 minecraft:light[level=12]
setblock 555 253 285 minecraft:light[level=12]
setblock 555 253 292 minecraft:light[level=12]
setblock 555 253 299 minecraft:light[level=12]
setblock 555 253 306 minecraft:light[level=12]
setblock 555 253 313 minecraft:light[level=12]
fill 559 253 277 559 255 278 minecraft:brown_terracotta
fill 559 253 289 559 255 290 minecraft:brown_terracotta
fill 559 253 301 559 255 302 minecraft:brown_terracotta
fill 559 253 313 559 255 314 minecraft:brown_terracotta
fill 543 254 305 543 256 305 minecraft:brown_terracotta
fill 543 254 308 543 256 308 minecraft:brown_terracotta
fill 545 254 303 545 256 303 minecraft:brown_terracotta
fill 545 254 310 545 256 310 minecraft:brown_terracotta
fill 548 254 303 548 256 303 minecraft:brown_terracotta
fill 548 254 310 548 256 310 minecraft:brown_terracotta
fill 550 254 305 550 256 305 minecraft:brown_terracotta
fill 550 254 308 550 256 308 minecraft:brown_terracotta
fill 542 255 306 542 256 307 minecraft:brown_terracotta
fill 543 255 304 543 256 304 minecraft:brown_terracotta
fill 543 255 309 543 256 309 minecraft:brown_terracotta
fill 544 255 303 544 256 303 minecraft:brown_terracotta
fill 544 255 310 544 256 310 minecraft:brown_terracotta
fill 545 255 311 553 255 315 minecraft:brown_terracotta
fill 546 255 302 547 256 302 minecraft:brown_terracotta
fill 549 255 303 549 256 303 minecraft:brown_terracotta
fill 549 255 310 553 255 310 minecraft:brown_terracotta
fill 550 255 304 550 256 304 minecraft:brown_terracotta
fill 550 255 309 550 256 309 minecraft:brown_terracotta
fill 551 255 306 551 256 307 minecraft:brown_terracotta
setblock 517 256 277 minecraft:white_concrete
setblock 517 256 281 minecraft:white_concrete
setblock 517 256 285 minecraft:white_concrete
setblock 517 256 288 minecraft:brown_terracotta
setblock 517 256 289 minecraft:white_concrete
setblock 517 256 290 minecraft:brown_terracotta
setblock 517 256 293 minecraft:white_concrete
setblock 517 256 297 minecraft:white_concrete
setblock 517 256 301 minecraft:white_concrete
setblock 517 256 305 minecraft:white_concrete
setblock 517 256 309 minecraft:white_concrete
setblock 517 256 313 minecraft:white_concrete
setblock 517 256 317 minecraft:white_concrete
setblock 518 256 317 minecraft:brown_terracotta
setblock 519 256 275 minecraft:white_concrete
setblock 519 256 317 minecraft:white_concrete
setblock 523 256 275 minecraft:white_concrete
setblock 523 256 317 minecraft:white_concrete
setblock 527 256 275 minecraft:white_concrete
setblock 527 256 317 minecraft:white_concrete
setblock 530 256 317 minecraft:brown_terracotta
setblock 531 256 275 minecraft:white_concrete
setblock 531 256 317 minecraft:white_concrete
setblock 535 256 275 minecraft:white_concrete
setblock 535 256 317 minecraft:white_concrete
setblock 539 256 275 minecraft:white_concrete
setblock 539 256 317 minecraft:white_concrete
setblock 542 256 305 minecraft:brown_terracotta
setblock 542 256 308 minecraft:brown_terracotta
setblock 542 256 317 minecraft:brown_terracotta
setblock 543 256 275 minecraft:white_concrete
setblock 543 256 303 minecraft:brown_terracotta
setblock 543 256 310 minecraft:brown_terracotta
setblock 543 256 317 minecraft:white_concrete
fill 544 256 302 545 256 302 minecraft:brown_terracotta
fill 545 256 311 548 256 311 minecraft:brown_terracotta
fill 545 256 312 553 256 315 minecraft:white_concrete
setblock 547 256 275 minecraft:white_concrete
setblock 547 256 317 minecraft:white_concrete
fill 548 256 302 549 256 302 minecraft:brown_terracotta
fill 549 256 310 550 256 310 minecraft:brown_terracotta
fill 549 256 311 553 256 311 minecraft:white_concrete
setblock 550 256 303 minecraft:brown_terracotta
setblock 551 256 275 minecraft:white_concrete
fill 551 256 304 551 256 305 minecraft:brown_terracotta
setblock 551 256 308 minecraft:brown_terracotta
fill 551 256 310 553 256 310 minecraft:white_concrete
setblock 551 256 317 minecraft:white_concrete
setblock 554 256 317 minecraft:brown_terracotta
setblock 555 256 275 minecraft:white_concrete
setblock 555 256 317 minecraft:white_concrete
setblock 559 256 275 minecraft:white_concrete
setblock 559 256 277 minecraft:white_concrete
setblock 559 256 278 minecraft:brown_terracotta
setblock 559 256 281 minecraft:white_concrete
setblock 559 256 285 minecraft:white_concrete
setblock 559 256 289 minecraft:white_concrete
setblock 559 256 290 minecraft:brown_terracotta
setblock 559 256 293 minecraft:white_concrete
setblock 559 256 297 minecraft:white_concrete
setblock 559 256 301 minecraft:white_concrete
setblock 559 256 302 minecraft:brown_terracotta
setblock 559 256 305 minecraft:white_concrete
setblock 559 256 309 minecraft:white_concrete
setblock 559 256 313 minecraft:white_concrete
setblock 559 256 314 minecraft:brown_terracotta
setblock 559 256 317 minecraft:white_concrete
setblock 517 257 276 minecraft:white_concrete
fill 517 257 277 517 264 277 minecraft:brown_terracotta
setblock 517 257 278 minecraft:white_concrete
setblock 517 257 280 minecraft:white_concrete
fill 517 257 281 517 264 281 minecraft:brown_terracotta
setblock 517 257 282 minecraft:white_concrete
setblock 517 257 283 minecraft:brown_terracotta
setblock 517 257 284 minecraft:white_concrete
fill 517 257 285 517 264 285 minecraft:brown_terracotta
setblock 517 257 286 minecraft:white_concrete
setblock 517 257 288 minecraft:white_concrete
fill 517 257 289 517 264 289 minecraft:brown_terracotta
setblock 517 257 290 minecraft:white_concrete
setblock 517 257 292 minecraft:white_concrete
fill 517 257 293 517 264 293 minecraft:brown_terracotta
setblock 517 257 294 minecraft:white_concrete
setblock 517 257 295 minecraft:brown_terracotta
setblock 517 257 296 minecraft:white_concrete
fill 517 257 297 517 264 297 minecraft:brown_terracotta
setblock 517 257 298 minecraft:white_concrete
setblock 517 257 300 minecraft:white_concrete
fill 517 257 301 517 264 301 minecraft:brown_terracotta
setblock 517 257 302 minecraft:white_concrete
setblock 517 257 304 minecraft:white_concrete
fill 517 257 305 517 264 305 minecraft:brown_terracotta
setblock 517 257 306 minecraft:white_concrete
setblock 517 257 307 minecraft:brown_terracotta
setblock 517 257 308 minecraft:white_concrete
fill 517 257 309 517 264 309 minecraft:brown_terracotta
setblock 517 257 310 minecraft:white_concrete
setblock 517 257 312 minecraft:white_concrete
fill 517 257 313 517 264 313 minecraft:brown_terracotta
setblock 517 257 314 minecraft:white_concrete
setblock 517 257 316 minecraft:white_concrete
setblock 517 257 317 minecraft:brown_terracotta
setblock 518 257 275 minecraft:white_concrete
setblock 518 257 317 minecraft:white_concrete
fill 519 257 275 519 264 275 minecraft:brown_terracotta
fill 519 257 317 519 264 317 minecraft:brown_terracotta
setblock 520 257 275 minecraft:white_concrete
setblock 520 257 317 minecraft:white_concrete
setblock 522 257 275 minecraft:white_concrete
setblock 522 257 317 minecraft:white_concrete
fill 523 257 275 523 264 275 minecraft:brown_terracotta
fill 523 257 317 523 264 317 minecraft:brown_terracotta
setblock 524 257 275 minecraft:white_concrete
setblock 524 257 317 minecraft:white_concrete
setblock 525 257 275 minecraft:brown_terracotta
setblock 526 257 275 minecraft:white_concrete
setblock 526 257 317 minecraft:white_concrete
fill 527 257 275 527 264 275 minecraft:brown_terracotta
fill 527 257 317 527 264 317 minecraft:brown_terracotta
setblock 528 257 275 minecraft:white_concrete
fill 528 257 289 530 258 290 minecraft:lime_concrete
setblock 528 257 317 minecraft:white_concrete
setblock 530 257 275 minecraft:white_concrete
setblock 530 257 317 minecraft:white_concrete
fill 531 257 275 531 264 275 minecraft:brown_terracotta
fill 531 257 317 531 264 317 minecraft:brown_terracotta
setblock 532 257 275 minecraft:white_concrete
setblock 532 257 317 minecraft:white_concrete
setblock 534 257 275 minecraft:white_concrete
setblock 534 257 317 minecraft:white_concrete
fill 535 257 275 535 264 275 minecraft:brown_terracotta
fill 535 257 317 535 264 317 minecraft:brown_terracotta
setblock 536 257 275 minecraft:white_concrete
setblock 536 257 317 minecraft:white_concrete
setblock 537 257 275 minecraft:brown_terracotta
setblock 538 257 275 minecraft:white_concrete
setblock 538 257 317 minecraft:white_concrete
fill 539 257 275 539 264 275 minecraft:brown_terracotta
fill 539 257 317 539 264 317 minecraft:brown_terracotta
setblock 540 257 275 minecraft:white_concrete
setblock 540 257 317 minecraft:white_concrete
setblock 542 257 275 minecraft:white_concrete
setblock 542 257 317 minecraft:white_concrete
fill 543 257 275 543 264 275 minecraft:brown_terracotta
fill 543 257 317 543 264 317 minecraft:brown_terracotta
setblock 544 257 275 minecraft:white_concrete
setblock 544 257 317 minecraft:white_concrete
fill 545 257 310 553 257 310 minecraft:red_concrete
setblock 546 257 275 minecraft:white_concrete
setblock 546 257 317 minecraft:white_concrete
fill 547 257 275 547 264 275 minecraft:brown_terracotta
fill 547 257 317 547 264 317 minecraft:brown_terracotta
setblock 548 257 275 minecraft:white_concrete
fill 548 257 316 550 260 316 minecraft:shroomlight
setblock 548 257 317 minecraft:white_concrete
setblock 549 257 275 minecraft:brown_terracotta
setblock 550 257 275 minecraft:white_concrete
setblock 550 257 317 minecraft:white_concrete
fill 551 257 275 551 264 275 minecraft:brown_terracotta
fill 551 257 317 551 264 317 minecraft:brown_terracotta
setblock 552 257 275 minecraft:white_concrete
setblock 552 257 317 minecraft:white_concrete
setblock 554 257 275 minecraft:white_concrete
setblock 554 257 317 minecraft:white_concrete
fill 555 257 275 555 264 275 minecraft:brown_terracotta
fill 555 257 317 555 264 317 minecraft:brown_terracotta
setblock 556 257 275 minecraft:white_concrete
setblock 556 257 317 minecraft:white_concrete
setblock 558 257 275 minecraft:white_concrete
setblock 558 257 317 minecraft:white_concrete
setblock 559 257 275 minecraft:brown_terracotta
setblock 559 257 276 minecraft:white_concrete
fill 559 257 277 559 264 277 minecraft:brown_terracotta
setblock 559 257 278 minecraft:white_concrete
setblock 559 257 280 minecraft:white_concrete
fill 559 257 281 559 264 281 minecraft:brown_terracotta
setblock 559 257 282 minecraft:white_concrete
setblock 559 257 284 minecraft:white_concrete
fill 559 257 285 559 264 285 minecraft:brown_terracotta
setblock 559 257 286 minecraft:white_concrete
setblock 559 257 288 minecraft:white_concrete
fill 559 257 289 559 264 289 minecraft:brown_terracotta
setblock 559 257 290 minecraft:white_concrete
setblock 559 257 292 minecraft:white_concrete
fill 559 257 293 559 264 293 minecraft:brown_terracotta
setblock 559 257 294 minecraft:white_concrete
setblock 559 257 296 minecraft:white_concrete
fill 559 257 297 559 264 297 minecraft:brown_terracotta
setblock 559 257 298 minecraft:white_concrete
setblock 559 257 300 minecraft:white_concrete
fill 559 257 301 559 264 301 minecraft:brown_terracotta
setblock 559 257 302 minecraft:white_concrete
setblock 559 257 304 minecraft:white_concrete
fill 559 257 305 559 264 305 minecraft:brown_terracotta
setblock 559 257 306 minecraft:white_concrete
setblock 559 257 308 minecraft:white_concrete
fill 559 257 309 559 264 309 minecraft:brown_terracotta
setblock 559 257 310 minecraft:white_concrete
setblock 559 257 312 minecraft:white_concrete
fill 559 257 313 559 264 313 minecraft:brown_terracotta
setblock 559 257 314 minecraft:white_concrete
setblock 559 257 316 minecraft:white_concrete
fill 559 257 317 559 264 317 minecraft:brown_terracotta
setblock 517 258 275 minecraft:white_concrete
fill 517 258 276 517 265 276 minecraft:brown_terracotta
fill 517 258 278 517 265 278 minecraft:brown_terracotta
setblock 517 258 279 minecraft:white_concrete
fill 517 258 280 517 265 280 minecraft:brown_terracotta
fill 517 258 282 517 265 282 minecraft:brown_terracotta
setblock 517 258 283 minecraft:white_concrete
fill 517 258 284 517 265 284 minecraft:brown_terracotta
fill 517 258 286 517 265 286 minecraft:brown_terracotta
setblock 517 258 287 minecraft:white_concrete
fill 517 258 288 517 265 288 minecraft:brown_terracotta
fill 517 258 290 517 265 290 minecraft:brown_terracotta
setblock 517 258 291 minecraft:white_concrete
fill 517 258 292 517 265 292 minecraft:brown_terracotta
fill 517 258 294 517 265 294 minecraft:brown_terracotta
setblock 517 258 295 minecraft:white_concrete
fill 517 258 296 517 265 296 minecraft:brown_terracotta
fill 517 258 298 517 265 298 minecraft:brown_terracotta
setblock 517 258 299 minecraft:white_concrete
fill 517 258 300 517 265 300 minecraft:brown_terracotta
fill 517 258 302 517 265 302 minecraft:brown_terracotta
setblock 517 258 303 minecraft:white_concrete
fill 517 258 304 517 265 304 minecraft:brown_terracotta
fill 517 258 306 517 265 306 minecraft:brown_terracotta
setblock 517 258 307 minecraft:white_concrete
fill 517 258 308 517 265 308 minecraft:brown_terracotta
fill 517 258 310 517 265 310 minecraft:brown_terracotta
setblock 517 258 311 minecraft:white_concrete
fill 517 258 312 517 265 312 minecraft:brown_terracotta
fill 517 258 314 517 265 314 minecraft:brown_terracotta
setblock 517 258 315 minecraft:white_concrete
fill 517 258 316 517 265 316 minecraft:brown_terracotta
setblock 517 258 317 minecraft:white_concrete
fill 518 258 275 518 265 275 minecraft:brown_terracotta
fill 518 258 317 518 265 317 minecraft:brown_terracotta
fill 520 258 275 520 265 275 minecraft:brown_terracotta
fill 520 258 317 520 265 317 minecraft:brown_terracotta
setblock 521 258 275 minecraft:white_concrete
setblock 521 258 317 minecraft:white_concrete
fill 522 258 275 522 265 275 minecraft:brown_terracotta
fill 522 258 317 522 265 317 minecraft:brown_terracotta
fill 524 258 275 524 265 275 minecraft:brown_terracotta
fill 524 258 317 524 265 317 minecraft:brown_terracotta
setblock 525 258 275 minecraft:white_concrete
setblock 525 258 317 minecraft:white_concrete
fill 526 258 275 526 265 275 minecraft:brown_terracotta
fill 526 258 317 526 265 317 minecraft:brown_terracotta
fill 528 258 275 528 265 275 minecraft:brown_terracotta
fill 528 258 277 534 259 277 minecraft:iron_block
fill 528 258 317 528 265 317 minecraft:brown_terracotta
setblock 529 258 275 minecraft:white_concrete
setblock 529 258 317 minecraft:white_concrete
fill 530 258 275 530 265 275 minecraft:brown_terracotta
fill 530 258 317 530 265 317 minecraft:brown_terracotta
fill 532 258 275 532 265 275 minecraft:brown_terracotta
fill 532 258 317 532 265 317 minecraft:brown_terracotta
setblock 533 258 275 minecraft:white_concrete
setblock 533 258 317 minecraft:white_concrete
fill 534 258 275 534 265 275 minecraft:brown_terracotta
fill 534 258 317 534 265 317 minecraft:brown_terracotta
fill 536 258 275 536 265 275 minecraft:brown_terracotta
fill 536 258 317 536 265 317 minecraft:brown_terracotta
setblock 537 258 275 minecraft:white_concrete
setblock 537 258 317 minecraft:white_concrete
fill 538 258 275 538 265 275 minecraft:brown_terracotta
fill 538 258 317 538 265 317 minecraft:brown_terracotta
fill 540 258 275 540 265 275 minecraft:brown_terracotta
fill 540 258 317 540 265 317 minecraft:brown_terracotta
setblock 541 258 275 minecraft:white_concrete
setblock 541 258 317 minecraft:white_concrete
fill 542 258 275 542 265 275 minecraft:brown_terracotta
fill 542 258 317 542 265 317 minecraft:brown_terracotta
fill 544 258 275 544 265 275 minecraft:brown_terracotta
fill 544 258 317 544 265 317 minecraft:brown_terracotta
setblock 545 258 275 minecraft:white_concrete
setblock 545 258 310 minecraft:white_concrete
setblock 545 258 317 minecraft:white_concrete
fill 546 258 275 546 265 275 minecraft:brown_terracotta
fill 546 258 317 546 265 317 minecraft:brown_terracotta
fill 548 258 275 548 265 275 minecraft:brown_terracotta
fill 548 258 317 548 265 317 minecraft:brown_terracotta
setblock 549 258 275 minecraft:white_concrete
setblock 549 258 310 minecraft:white_concrete
setblock 549 258 317 minecraft:white_concrete
fill 550 258 275 550 265 275 minecraft:brown_terracotta
fill 550 258 317 550 265 317 minecraft:brown_terracotta
fill 552 258 275 552 265 275 minecraft:brown_terracotta
fill 552 258 317 552 265 317 minecraft:brown_terracotta
setblock 553 258 275 minecraft:white_concrete
setblock 553 258 310 minecraft:white_concrete
setblock 553 258 317 minecraft:white_concrete
fill 554 258 275 554 265 275 minecraft:brown_terracotta
fill 554 258 317 554 265 317 minecraft:brown_terracotta
fill 556 258 275 556 265 275 minecraft:brown_terracotta
fill 556 258 317 556 265 317 minecraft:brown_terracotta
setblock 557 258 275 minecraft:white_concrete
setblock 557 258 317 minecraft:white_concrete
fill 558 258 275 558 265 275 minecraft:brown_terracotta
fill 558 258 317 558 265 317 minecraft:brown_terracotta
setblock 559 258 275 minecraft:white_concrete
fill 559 258 276 559 265 276 minecraft:brown_terracotta
fill 559 258 278 559 265 278 minecraft:brown_terracotta
setblock 559 258 279 minecraft:white_concrete
fill 559 258 280 559 265 280 minecraft:brown_terracotta
fill 559 258 282 559 265 282 minecraft:brown_terracotta
setblock 559 258 283 minecraft:white_concrete
fill 559 258 284 559 265 284 minecraft:brown_terracotta
fill 559 258 286 559 265 286 minecraft:brown_terracotta
setblock 559 258 287 minecraft:white_concrete
fill 559 258 288 559 265 288 minecraft:brown_terracotta
fill 559 258 290 559 265 290 minecraft:brown_terracotta
setblock 559 258 291 minecraft:white_concrete
fill 559 258 292 559 265 292 minecraft:brown_terracotta
fill 559 258 294 559 265 294 minecraft:brown_terracotta
setblock 559 258 295 minecraft:white_concrete
fill 559 258 296 559 265 296 minecraft:brown_terracotta
fill 559 258 298 559 265 298 minecraft:brown_terracotta
setblock 559 258 299 minecraft:white_concrete
fill 559 258 300 559 265 300 minecraft:brown_terracotta
fill 559 258 302 559 265 302 minecraft:brown_terracotta
setblock 559 258 303 minecraft:white_concrete
fill 559 258 304 559 265 304 minecraft:brown_terracotta
fill 559 258 306 559 265 306 minecraft:brown_terracotta
setblock 559 258 307 minecraft:white_concrete
fill 559 258 308 559 265 308 minecraft:brown_terracotta
fill 559 258 310 559 265 310 minecraft:brown_terracotta
setblock 559 258 311 minecraft:white_concrete
fill 559 258 312 559 265 312 minecraft:brown_terracotta
fill 559 258 314 559 265 314 minecraft:brown_terracotta
setblock 559 258 315 minecraft:white_concrete
fill 559 258 316 559 265 316 minecraft:brown_terracotta
fill 517 259 275 517 266 275 minecraft:brown_terracotta
fill 517 259 279 517 266 279 minecraft:brown_terracotta
fill 517 259 283 517 265 283 minecraft:brown_terracotta
fill 517 259 287 517 266 287 minecraft:brown_terracotta
fill 517 259 291 517 266 291 minecraft:brown_terracotta
fill 517 259 295 517 265 295 minecraft:brown_terracotta
fill 517 259 299 517 266 299 minecraft:brown_terracotta
fill 517 259 303 517 266 303 minecraft:brown_terracotta
fill 517 259 307 517 265 307 minecraft:brown_terracotta
fill 517 259 311 517 266 311 minecraft:brown_terracotta
fill 517 259 315 517 266 315 minecraft:brown_terracotta
fill 517 259 317 517 264 317 minecraft:brown_terracotta
setblock 520 259 278 minecraft:light[level=12]
setblock 520 259 285 minecraft:light[level=12]
setblock 520 259 292 minecraft:light[level=12]
setblock 520 259 299 minecraft:light[level=12]
setblock 520 259 306 minecraft:light[level=12]
setblock 520 259 313 minecraft:light[level=12]
fill 521 259 275 521 266 275 minecraft:brown_terracotta
fill 521 259 317 521 266 317 minecraft:brown_terracotta
fill 525 259 275 525 265 275 minecraft:brown_terracotta
fill 525 259 317 525 266 317 minecraft:brown_terracotta
setblock 527 259 278 minecraft:light[level=12]
setblock 527 259 285 minecraft:light[level=12]
setblock 527 259 292 minecraft:light[level=12]
setblock 527 259 299 minecraft:light[level=12]
setblock 527 259 306 minecraft:light[level=12]
setblock 527 259 313 minecraft:light[level=12]
fill 529 259 275 529 266 275 minecraft:brown_terracotta
fill 529 259 317 529 265 317 minecraft:brown_terracotta
fill 533 259 275 533 266 275 minecraft:brown_terracotta
fill 533 259 317 533 266 317 minecraft:brown_terracotta
setblock 534 259 278 minecraft:light[level=12]
setblock 534 259 285 minecraft:light[level=12]
setblock 534 259 292 minecraft:light[level=12]
setblock 534 259 299 minecraft:light[level=12]
setblock 534 259 306 minecraft:light[level=12]
setblock 534 259 313 minecraft:light[level=12]
fill 537 259 275 537 265 275 minecraft:brown_terracotta
fill 537 259 317 537 266 317 minecraft:brown_terracotta
fill 541 259 275 541 266 275 minecraft:brown_terracotta
setblock 541 259 278 minecraft:light[level=12]
setblock 541 259 285 minecraft:light[level=12]
setblock 541 259 292 minecraft:light[level=12]
setblock 541 259 299 minecraft:light[level=12]
setblock 541 259 306 minecraft:light[level=12]
setblock 541 259 313 minecraft:light[level=12]
fill 541 259 317 541 265 317 minecraft:brown_terracotta
fill 545 259 275 545 266 275 minecraft:brown_terracotta
fill 545 259 317 545 266 317 minecraft:brown_terracotta
setblock 548 259 278 minecraft:light[level=12]
setblock 548 259 285 minecraft:light[level=12]
setblock 548 259 292 minecraft:light[level=12]
setblock 548 259 299 minecraft:light[level=12]
setblock 548 259 306 minecraft:light[level=12]
setblock 548 259 313 minecraft:light[level=12]
fill 549 259 275 549 265 275 minecraft:brown_terracotta
fill 549 259 317 549 266 317 minecraft:brown_terracotta
fill 550 259 286 550 260 286 minecraft:shroomlight
fill 553 259 275 553 266 275 minecraft:brown_terracotta
fill 553 259 317 553 265 317 minecraft:brown_terracotta
setblock 555 259 278 minecraft:light[level=12]
setblock 555 259 285 minecraft:light[level=12]
setblock 555 259 292 minecraft:light[level=12]
setblock 555 259 299 minecraft:light[level=12]
setblock 555 259 306 minecraft:light[level=12]
setblock 555 259 313 minecraft:light[level=12]
fill 557 259 275 557 266 275 minecraft:brown_terracotta
fill 557 259 317 557 266 317 minecraft:brown_terracotta
fill 559 259 275 559 264 275 minecraft:brown_terracotta
fill 559 259 279 559 265 279 minecraft:brown_terracotta
fill 559 259 283 559 266 283 minecraft:brown_terracotta
fill 559 259 287 559 266 287 minecraft:brown_terracotta
fill 559 259 291 559 265 291 minecraft:brown_terracotta
fill 559 259 295 559 266 295 minecraft:brown_terracotta
fill 559 259 299 559 266 299 minecraft:brown_terracotta
fill 559 259 303 559 265 303 minecraft:brown_terracotta
fill 559 259 307 559 266 307 minecraft:brown_terracotta
fill 559 259 311 559 266 311 minecraft:brown_terracotta
fill 559 259 315 559 265 315 minecraft:brown_terracotta
fill 519 260 285 519 265 287 minecraft:white_concrete
fill 519 260 297 519 265 299 minecraft:white_concrete
fill 519 260 309 519 265 311 minecraft:white_concrete
fill 525 260 315 527 265 315 minecraft:white_concrete
fill 529 260 277 531 265 277 minecraft:white_concrete
fill 537 260 315 539 265 315 minecraft:white_concrete
fill 541 260 277 543 265 277 minecraft:white_concrete
fill 545 260 306 548 262 307 minecraft:spruce_leaves[persistent=true]
fill 546 260 305 547 262 305 minecraft:spruce_leaves[persistent=true]
fill 546 260 308 547 262 308 minecraft:spruce_leaves[persistent=true]
fill 549 260 315 551 265 315 minecraft:white_concrete
fill 553 260 277 555 265 277 minecraft:white_concrete
fill 557 260 285 557 265 287 minecraft:white_concrete
fill 557 260 297 557 265 299 minecraft:white_concrete
fill 557 260 309 557 265 311 minecraft:white_concrete
setblock 520 261 278 minecraft:light[level=15]
setblock 520 261 286 minecraft:light[level=15]
setblock 520 261 294 minecraft:light[level=15]
setblock 520 261 302 minecraft:light[level=15]
setblock 520 261 310 minecraft:light[level=15]
setblock 528 261 278 minecraft:light[level=15]
setblock 528 261 286 minecraft:light[level=15]
setblock 528 261 294 minecraft:light[level=15]
setblock 528 261 302 minecraft:light[level=15]
setblock 528 261 310 minecraft:light[level=15]
setblock 536 261 278 minecraft:light[level=15]
setblock 536 261 286 minecraft:light[level=15]
setblock 536 261 294 minecraft:light[level=15]
setblock 536 261 302 minecraft:light[level=15]
setblock 536 261 310 minecraft:light[level=15]
setblock 544 261 278 minecraft:light[level=15]
setblock 544 261 286 minecraft:light[level=15]
setblock 544 261 294 minecraft:light[level=15]
setblock 544 261 302 minecraft:light[level=15]
setblock 544 261 310 minecraft:light[level=15]
setblock 545 261 305 minecraft:spruce_leaves[persistent=true]
setblock 545 261 308 minecraft:spruce_leaves[persistent=true]
setblock 548 261 305 minecraft:spruce_leaves[persistent=true]
setblock 548 261 308 minecraft:spruce_leaves[persistent=true]
fill 548 261 316 550 271 316 minecraft:white_concrete
fill 550 261 286 550 268 286 minecraft:brown_terracotta
setblock 552 261 278 minecraft:light[level=15]
setblock 552 261 286 minecraft:light[level=15]
setblock 552 261 294 minecraft:light[level=15]
setblock 552 261 302 minecraft:light[level=15]
setblock 552 261 310 minecraft:light[level=15]
fill 536 262 303 536 263 305 minecraft:lime_concrete
fill 537 262 303 537 263 304 minecraft:lime_concrete
fill 550 262 285 550 268 285 minecraft:brown_terracotta
fill 551 263 285 551 268 286 minecraft:brown_terracotta
fill 529 264 299 529 265 300 minecraft:white_concrete
fill 549 264 285 549 268 286 minecraft:brown_terracotta
fill 550 264 287 550 268 287 minecraft:brown_terracotta
setblock 517 265 277 minecraft:white_concrete
setblock 517 265 281 minecraft:white_concrete
setblock 517 265 285 minecraft:white_concrete
setblock 517 265 289 minecraft:white_concrete
setblock 517 265 293 minecraft:white_concrete
setblock 517 265 297 minecraft:white_concrete
setblock 517 265 301 minecraft:white_concrete
setblock 517 265 305 minecraft:white_concrete
setblock 517 265 309 minecraft:white_concrete
setblock 517 265 313 minecraft:white_concrete
setblock 517 265 317 minecraft:white_concrete
fill 518 265 279 518 265 284 minecraft:brown_terracotta
fill 518 265 291 518 265 296 minecraft:brown_terracotta
fill 518 265 303 518 265 308 minecraft:brown_terracotta
fill 518 265 315 518 265 316 minecraft:brown_terracotta
setblock 519 265 275 minecraft:white_concrete
fill 519 265 316 522 265 316 minecraft:brown_terracotta
setblock 519 265 317 minecraft:white_concrete
setblock 520 265 278 minecraft:light[level=12]
setblock 520 265 285 minecraft:light[level=12]
setblock 520 265 292 minecraft:light[level=12]
setblock 520 265 299 minecraft:light[level=12]
setblock 520 265 306 minecraft:light[level=12]
setblock 520 265 313 minecraft:light[level=12]
fill 522 265 276 527 265 276 minecraft:brown_terracotta
setblock 523 265 275 minecraft:white_concrete
setblock 523 265 317 minecraft:white_concrete
setblock 527 265 275 minecraft:white_concrete
setblock 527 265 278 minecraft:light[level=12]
setblock 527 265 285 minecraft:light[level=12]
setblock 527 265 292 minecraft:light[level=12]
setblock 527 265 299 minecraft:light[level=12]
setblock 527 265 306 minecraft:light[level=12]
setblock 527 265 313 minecraft:light[level=12]
setblock 527 265 317 minecraft:white_concrete
fill 529 265 316 534 265 316 minecraft:brown_terracotta
setblock 531 265 275 minecraft:white_concrete
setblock 531 265 317 minecraft:white_concrete
fill 534 265 276 539 265 276 minecraft:brown_terracotta
setblock 534 265 278 minecraft:light[level=12]
setblock 534 265 285 minecraft:light[level=12]
setblock 534 265 292 minecraft:light[level=12]
setblock 534 265 299 minecraft:light[level=12]
setblock 534 265 306 minecraft:light[level=12]
setblock 534 265 313 minecraft:light[level=12]
setblock 535 265 275 minecraft:white_concrete
setblock 535 265 317 minecraft:white_concrete
fill 538 265 311 538 266 312 minecraft:lime_concrete
setblock 539 265 275 minecraft:white_concrete
setblock 539 265 317 minecraft:white_concrete
setblock 541 265 278 minecraft:light[level=12]
setblock 541 265 285 minecraft:light[level=12]
setblock 541 265 292 minecraft:light[level=12]
setblock 541 265 299 minecraft:light[level=12]
setblock 541 265 306 minecraft:light[level=12]
setblock 541 265 313 minecraft:light[level=12]
fill 541 265 316 546 265 316 minecraft:brown_terracotta
setblock 543 265 275 minecraft:white_concrete
setblock 543 265 317 minecraft:white_concrete
fill 546 265 276 551 265 276 minecraft:brown_terracotta
setblock 547 265 275 minecraft:white_concrete
setblock 547 265 317 minecraft:white_concrete
setblock 548 265 278 minecraft:light[level=12]
setblock 548 265 285 minecraft:light[level=12]
setblock 548 265 292 minecraft:light[level=12]
setblock 548 265 299 minecraft:light[level=12]
setblock 548 265 306 minecraft:light[level=12]
setblock 548 265 313 minecraft:light[level=12]
fill 549 265 284 551 268 284 minecraft:brown_terracotta
fill 549 265 287 549 268 287 minecraft:brown_terracotta
setblock 551 265 275 minecraft:white_concrete
fill 551 265 287 551 268 287 minecraft:brown_terracotta
setblock 551 265 317 minecraft:white_concrete
fill 552 265 285 552 268 286 minecraft:brown_terracotta
fill 553 265 316 558 265 316 minecraft:brown_terracotta
setblock 555 265 275 minecraft:white_concrete
setblock 555 265 278 minecraft:light[level=12]
setblock 555 265 285 minecraft:light[level=12]
setblock 555 265 292 minecraft:light[level=12]
setblock 555 265 299 minecraft:light[level=12]
setblock 555 265 306 minecraft:light[level=12]
setblock 555 265 313 minecraft:light[level=12]
setblock 555 265 317 minecraft:white_concrete
fill 558 265 276 558 265 281 minecraft:brown_terracotta
fill 558 265 288 558 265 293 minecraft:brown_terracotta
fill 558 265 300 558 265 305 minecraft:brown_terracotta
fill 558 265 312 558 265 315 minecraft:brown_terracotta
setblock 559 265 275 minecraft:white_concrete
setblock 559 265 277 minecraft:white_concrete
setblock 559 265 281 minecraft:white_concrete
setblock 559 265 285 minecraft:white_concrete
setblock 559 265 289 minecraft:white_concrete
setblock 559 265 293 minecraft:white_concrete
setblock 559 265 297 minecraft:white_concrete
setblock 559 265 301 minecraft:white_concrete
setblock 559 265 305 minecraft:white_concrete
setblock 559 265 309 minecraft:white_concrete
setblock 559 265 313 minecraft:white_concrete
setblock 559 265 317 minecraft:white_concrete
setblock 517 266 276 minecraft:white_concrete
fill 517 266 277 517 273 277 minecraft:brown_terracotta
setblock 517 266 278 minecraft:white_concrete
setblock 517 266 280 minecraft:white_concrete
fill 517 266 281 517 271 284 minecraft:shroomlight
fill 517 266 285 517 273 285 minecraft:brown_terracotta
setblock 517 266 286 minecraft:white_concrete
setblock 517 266 288 minecraft:white_concrete
fill 517 266 289 517 273 289 minecraft:brown_terracotta
setblock 517 266 290 minecraft:white_concrete
setblock 517 266 292 minecraft:white_concrete
fill 517 266 293 517 271 296 minecraft:shroomlight
fill 517 266 297 517 273 297 minecraft:brown_terracotta
setblock 517 266 298 minecraft:white_concrete
setblock 517 266 300 minecraft:white_concrete
fill 517 266 301 517 273 301 minecraft:brown_terracotta
setblock 517 266 302 minecraft:white_concrete
setblock 517 266 304 minecraft:white_concrete
fill 517 266 305 517 271 308 minecraft:shroomlight
fill 517 266 309 517 273 309 minecraft:brown_terracotta
setblock 517 266 310 minecraft:white_concrete
setblock 517 266 312 minecraft:white_concrete
fill 517 266 313 517 273 313 minecraft:brown_terracotta
setblock 517 266 314 minecraft:white_concrete
setblock 517 266 316 minecraft:white_concrete
fill 517 266 317 520 271 317 minecraft:shroomlight
setblock 518 266 275 minecraft:white_concrete
fill 519 266 275 519 273 275 minecraft:brown_terracotta
setblock 520 266 275 minecraft:white_concrete
setblock 522 266 275 minecraft:white_concrete
setblock 522 266 317 minecraft:white_concrete
fill 523 266 275 523 273 275 minecraft:brown_terracotta
fill 523 266 317 523 273 317 minecraft:brown_terracotta
fill 524 266 275 527 271 275 minecraft:shroomlight
setblock 524 266 317 minecraft:white_concrete
setblock 526 266 317 minecraft:white_concrete
fill 527 266 317 527 273 317 minecraft:brown_terracotta
setblock 528 266 275 minecraft:white_concrete
setblock 528 266 317 minecraft:white_concrete
fill 529 266 317 532 271 317 minecraft:shroomlight
setblock 530 266 275 minecraft:white_concrete
fill 531 266 275 531 273 275 minecraft:brown_terracotta
setblock 532 266 275 minecraft:white_concrete
setblock 534 266 275 minecraft:white_concrete
setblock 534 266 317 minecraft:white_concrete
fill 535 266 275 535 273 275 minecraft:brown_terracotta
fill 535 266 317 535 273 317 minecraft:brown_terracotta
fill 536 266 275 539 271 275 minecraft:shroomlight
setblock 536 266 317 minecraft:white_concrete
setblock 538 266 317 minecraft:white_concrete
fill 539 266 317 539 273 317 minecraft:brown_terracotta
setblock 540 266 275 minecraft:white_concrete
setblock 540 266 317 minecraft:white_concrete
fill 541 266 317 544 271 317 minecraft:shroomlight
setblock 542 266 275 minecraft:white_concrete
fill 543 266 275 543 273 275 minecraft:brown_terracotta
setblock 544 266 275 minecraft:white_concrete
setblock 546 266 275 minecraft:white_concrete
setblock 546 266 317 minecraft:white_concrete
fill 547 266 275 547 273 275 minecraft:brown_terracotta
fill 547 266 317 547 273 317 minecraft:brown_terracotta
fill 548 266 275 551 271 275 minecraft:shroomlight
fill 548 266 285 548 268 286 minecraft:brown_terracotta
setblock 548 266 317 minecraft:white_concrete
fill 550 266 288 550 268 288 minecraft:brown_terracotta
setblock 550 266 317 minecraft:white_concrete
fill 551 266 317 551 273 317 minecraft:brown_terracotta
setblock 552 266 275 minecraft:white_concrete
fill 552 266 284 552 268 284 minecraft:brown_terracotta
fill 552 266 287 552 268 287 minecraft:brown_terracotta
setblock 552 266 317 minecraft:white_concrete
fill 553 266 317 556 271 317 minecraft:shroomlight
setblock 554 266 275 minecraft:white_concrete
fill 555 266 275 555 273 275 minecraft:brown_terracotta
setblock 556 266 275 minecraft:white_concrete
setblock 558 266 275 minecraft:white_concrete
setblock 558 266 317 minecraft:white_concrete
setblock 559 266 275 minecraft:brown_terracotta
fill 559 266 276 559 271 279 minecraft:shroomlight
setblock 559 266 280 minecraft:white_concrete
fill 559 266 281 559 273 281 minecraft:brown_terracotta
setblock 559 266 282 minecraft:white_concrete
setblock 559 266 284 minecraft:white_concrete
fill 559 266 285 559 273 285 minecraft:brown_terracotta
setblock 559 266 286 minecraft:white_concrete
fill 559 266 288 559 271 291 minecraft:shroomlight
setblock 559 266 292 minecraft:white_concrete
fill 559 266 293 559 273 293 minecraft:brown_terracotta
setblock 559 266 294 minecraft:white_concrete
setblock 559 266 296 minecraft:white_concrete
fill 559 266 297 559 273 297 minecraft:brown_terracotta
setblock 559 266 298 minecraft:white_concrete
fill 559 266 300 559 271 303 minecraft:shroomlight
setblock 559 266 304 minecraft:white_concrete
fill 559 266 305 559 273 305 minecraft:brown_terracotta
setblock 559 266 306 minecraft:white_concrete
setblock 559 266 308 minecraft:white_concrete
fill 559 266 309 559 273 309 minecraft:brown_terracotta
setblock 559 266 310 minecraft:white_concrete
fill 559 266 312 559 271 315 minecraft:shroomlight
setblock 559 266 316 minecraft:white_concrete
fill 559 266 317 559 273 317 minecraft:brown_terracotta
setblock 517 267 275 minecraft:white_concrete
fill 517 267 276 517 274 276 minecraft:brown_terracotta
fill 517 267 278 517 274 278 minecraft:brown_terracotta
setblock 517 267 279 minecraft:white_concrete
fill 517 267 280 517 274 280 minecraft:brown_terracotta
fill 517 267 286 517 274 286 minecraft:brown_terracotta
setblock 517 267 287 minecraft:white_concrete
fill 517 267 288 517 274 288 minecraft:brown_terracotta
fill 517 267 290 517 274 290 minecraft:brown_terracotta
setblock 517 267 291 minecraft:white_concrete
fill 517 267 292 517 274 292 minecraft:brown_terracotta
fill 517 267 298 517 274 298 minecraft:brown_terracotta
setblock 517 267 299 minecraft:white_concrete
fill 517 267 300 517 274 300 minecraft:brown_terracotta
fill 517 267 302 517 274 302 minecraft:brown_terracotta
setblock 517 267 303 minecraft:white_concrete
fill 517 267 304 517 274 304 minecraft:brown_terracotta
fill 517 267 310 517 274 310 minecraft:brown_terracotta
setblock 517 267 311 minecraft:white_concrete
fill 517 267 312 517 274 312 minecraft:brown_terracotta
fill 517 267 314 517 274 314 minecraft:brown_terracotta
setblock 517 267 315 minecraft:white_concrete
fill 517 267 316 517 274 316 minecraft:brown_terracotta
fill 518 267 275 518 274 275 minecraft:brown_terracotta
fill 520 267 275 520 274 275 minecraft:brown_terracotta
setblock 521 267 275 minecraft:white_concrete
setblock 521 267 317 minecraft:white_concrete
fill 522 267 275 522 274 275 minecraft:brown_terracotta
fill 522 267 317 522 274 317 minecraft:brown_terracotta
fill 524 267 317 524 274 317 minecraft:brown_terracotta
setblock 525 267 317 minecraft:white_concrete
fill 526 267 317 526 274 317 minecraft:brown_terracotta
fill 528 267 275 528 274 275 minecraft:brown_terracotta
fill 528 267 317 528 274 317 minecraft:brown_terracotta
setblock 529 267 275 minecraft:white_concrete
fill 530 267 275 530 274 275 minecraft:brown_terracotta
fill 532 267 275 532 274 275 minecraft:brown_terracotta
setblock 533 267 275 minecraft:white_concrete
setblock 533 267 317 minecraft:white_concrete
fill 534 267 275 534 274 275 minecraft:brown_terracotta
fill 534 267 317 534 274 317 minecraft:brown_terracotta
fill 536 267 317 536 274 317 minecraft:brown_terracotta
setblock 537 267 317 minecraft:white_concrete
fill 538 267 317 538 274 317 minecraft:brown_terracotta
fill 540 267 275 540 274 275 minecraft:brown_terracotta
fill 540 267 317 540 274 317 minecraft:brown_terracotta
setblock 541 267 275 minecraft:white_concrete
fill 542 267 275 542 274 275 minecraft:brown_terracotta
fill 544 267 275 544 274 275 minecraft:brown_terracotta
setblock 545 267 275 minecraft:white_concrete
setblock 545 267 317 minecraft:white_concrete
fill 546 267 275 546 274 275 minecraft:brown_terracotta
fill 546 267 317 546 274 317 minecraft:brown_terracotta
fill 548 267 284 548 268 284 minecraft:brown_terracotta
fill 548 267 287 548 268 287 minecraft:brown_terracotta
fill 548 267 317 548 274 317 minecraft:brown_terracotta
fill 549 267 283 551 268 283 minecraft:brown_terracotta
fill 549 267 288 549 268 288 minecraft:brown_terracotta
setblock 549 267 317 minecraft:white_concrete
fill 550 267 317 550 274 317 minecraft:brown_terracotta
fill 551 267 288 551 268 288 minecraft:brown_terracotta
fill 552 267 275 552 274 275 minecraft:brown_terracotta
fill 552 267 317 552 274 317 minecraft:brown_terracotta
setblock 553 267 275 minecraft:white_concrete
fill 553 267 285 553 268 286 minecraft:brown_terracotta
fill 554 267 275 554 274 275 minecraft:brown_terracotta
fill 556 267 275 556 274 275 minecraft:brown_terracotta
setblock 557 267 275 minecraft:white_concrete
setblock 557 267 317 minecraft:white_concrete
fill 558 267 275 558 274 275 minecraft:brown_terracotta
fill 558 267 317 558 274 317 minecraft:brown_terracotta
setblock 559 267 275 minecraft:white_concrete
fill 559 267 280 559 274 280 minecraft:brown_terracotta
fill 559 267 282 559 274 282 minecraft:brown_terracotta
setblock 559 267 283 minecraft:white_concrete
fill 559 267 284 559 274 284 minecraft:brown_terracotta
fill 559 267 286 559 274 286 minecraft:brown_terracotta
setblock 559 267 287 minecraft:white_concrete
fill 559 267 292 559 274 292 minecraft:brown_terracotta
fill 559 267 294 559 274 294 minecraft:brown_terracotta
setblock 559 267 295 minecraft:white_concrete
fill 559 267 296 559 274 296 minecraft:brown_terracotta
fill 559 267 298 559 274 298 minecraft:brown_terracotta
setblock 559 267 299 minecraft:white_concrete
fill 559 267 304 559 274 304 minecraft:brown_terracotta
fill 559 267 306 559 274 306 minecraft:brown_terracotta
setblock 559 267 307 minecraft:white_concrete
fill 559 267 308 559 274 308 minecraft:brown_terracotta
fill 559 267 310 559 274 310 minecraft:brown_terracotta
setblock 559 267 311 minecraft:white_concrete
fill 559 267 316 559 274 316 minecraft:brown_terracotta
fill 517 268 275 517 275 275 minecraft:brown_terracotta
fill 517 268 279 517 275 279 minecraft:brown_terracotta
fill 517 268 287 517 275 287 minecraft:brown_terracotta
fill 517 268 291 517 275 291 minecraft:brown_terracotta
fill 517 268 299 517 275 299 minecraft:brown_terracotta
fill 517 268 303 517 275 303 minecraft:brown_terracotta
fill 517 268 311 517 275 311 minecraft:brown_terracotta
fill 517 268 315 517 275 315 minecraft:brown_terracotta
fill 521 268 275 521 275 275 minecraft:brown_terracotta
fill 521 268 317 521 275 317 minecraft:brown_terracotta
fill 524 268 300 525 269 301 minecraft:red_concrete
fill 525 268 317 525 275 317 minecraft:brown_terracotta
fill 529 268 275 529 275 275 minecraft:brown_terracotta
fill 533 268 275 533 275 275 minecraft:brown_terracotta
fill 533 268 317 533 275 317 minecraft:brown_terracotta
fill 537 268 317 537 275 317 minecraft:brown_terracotta
fill 541 268 275 541 275 275 minecraft:brown_terracotta
fill 545 268 275 545 275 275 minecraft:brown_terracotta
fill 545 268 317 545 275 317 minecraft:brown_terracotta
fill 547 268 285 547 268 286 minecraft:brown_terracotta
setblock 548 268 288 minecraft:brown_terracotta
fill 549 268 317 549 275 317 minecraft:brown_terracotta
setblock 552 268 283 minecraft:brown_terracotta
setblock 552 268 288 minecraft:brown_terracotta
fill 553 268 275 553 275 275 minecraft:brown_terracotta
setblock 553 268 284 minecraft:brown_terracotta
setblock 553 268 287 minecraft:brown_terracotta
fill 557 268 275 557 275 275 minecraft:brown_terracotta
fill 557 268 317 557 275 317 minecraft:brown_terracotta
fill 559 268 275 559 273 275 minecraft:brown_terracotta
fill 559 268 283 559 275 283 minecraft:brown_terracotta
fill 559 268 287 559 275 287 minecraft:brown_terracotta
fill 559 268 295 559 275 295 minecraft:brown_terracotta
fill 559 268 299 559 275 299 minecraft:brown_terracotta
fill 559 268 307 559 275 307 minecraft:brown_terracotta
fill 559 268 311 559 275 311 minecraft:brown_terracotta
setblock 520 269 278 minecraft:light[level=15]
setblock 520 269 286 minecraft:light[level=15]
setblock 520 269 294 minecraft:light[level=15]
setblock 520 269 302 minecraft:light[level=15]
setblock 520 269 310 minecraft:light[level=15]
setblock 528 269 278 minecraft:light[level=15]
setblock 528 269 286 minecraft:light[level=15]
setblock 528 269 294 minecraft:light[level=15]
setblock 528 269 302 minecraft:light[level=15]
setblock 528 269 310 minecraft:light[level=15]
setblock 536 269 278 minecraft:light[level=15]
setblock 536 269 286 minecraft:light[level=15]
setblock 536 269 294 minecraft:light[level=15]
setblock 536 269 302 minecraft:light[level=15]
setblock 536 269 310 minecraft:light[level=15]
setblock 544 269 278 minecraft:light[level=15]
setblock 544 269 286 minecraft:light[level=15]
setblock 544 269 294 minecraft:light[level=15]
setblock 544 269 302 minecraft:light[level=15]
setblock 544 269 310 minecraft:light[level=15]
fill 550 269 286 550 271 286 minecraft:white_concrete
setblock 552 269 278 minecraft:light[level=15]
setblock 552 269 286 minecraft:light[level=15]
setblock 552 269 294 minecraft:light[level=15]
setblock 552 269 302 minecraft:light[level=15]
setblock 552 269 310 minecraft:light[level=15]
setblock 520 271 278 minecraft:light[level=12]
setblock 520 271 285 minecraft:light[level=12]
setblock 520 271 292 minecraft:light[level=12]
setblock 520 271 299 minecraft:light[level=12]
setblock 520 271 306 minecraft:light[level=12]
setblock 520 271 313 minecraft:light[level=12]
setblock 527 271 278 minecraft:light[level=12]
setblock 527 271 285 minecraft:light[level=12]
setblock 527 271 292 minecraft:light[level=12]
setblock 527 271 299 minecraft:light[level=12]
setblock 527 271 306 minecraft:light[level=12]
setblock 527 271 313 minecraft:light[level=12]
setblock 534 271 278 minecraft:light[level=12]
setblock 534 271 285 minecraft:light[level=12]
setblock 534 271 292 minecraft:light[level=12]
setblock 534 271 299 minecraft:light[level=12]
setblock 534 271 306 minecraft:light[level=12]
setblock 534 271 313 minecraft:light[level=12]
setblock 541 271 278 minecraft:light[level=12]
setblock 541 271 285 minecraft:light[level=12]
setblock 541 271 292 minecraft:light[level=12]
setblock 541 271 299 minecraft:light[level=12]
setblock 541 271 306 minecraft:light[level=12]
setblock 541 271 313 minecraft:light[level=12]
setblock 548 271 278 minecraft:light[level=12]
setblock 548 271 285 minecraft:light[level=12]
setblock 548 271 292 minecraft:light[level=12]
setblock 548 271 299 minecraft:light[level=12]
setblock 548 271 306 minecraft:light[level=12]
setblock 548 271 313 minecraft:light[level=12]
setblock 555 271 278 minecraft:light[level=12]
setblock 555 271 285 minecraft:light[level=12]
setblock 555 271 292 minecraft:light[level=12]
setblock 555 271 299 minecraft:light[level=12]
setblock 555 271 306 minecraft:light[level=12]
setblock 555 271 313 minecraft:light[level=12]
fill 517 272 281 517 273 284 minecraft:brown_terracotta
fill 517 272 293 517 273 296 minecraft:brown_terracotta
fill 517 272 305 517 273 308 minecraft:brown_terracotta
fill 517 272 317 520 273 317 minecraft:brown_terracotta
fill 524 272 275 527 273 275 minecraft:brown_terracotta
fill 529 272 317 532 273 317 minecraft:brown_terracotta
fill 536 272 275 539 273 275 minecraft:brown_terracotta
fill 541 272 317 544 273 317 minecraft:brown_terracotta
fill 548 272 275 551 273 275 minecraft:brown_terracotta
fill 553 272 317 556 273 317 minecraft:brown_terracotta
fill 559 272 276 559 273 279 minecraft:brown_terracotta
fill 559 272 288 559 273 291 minecraft:brown_terracotta
fill 559 272 300 559 273 303 minecraft:brown_terracotta
fill 559 272 312 559 273 315 minecraft:brown_terracotta
setblock 517 274 277 minecraft:white_concrete
setblock 517 274 281 minecraft:white_concrete
fill 517 274 282 517 274 284 minecraft:brown_terracotta
setblock 517 274 285 minecraft:white_concrete
setblock 517 274 289 minecraft:white_concrete
setblock 517 274 293 minecraft:white_concrete
fill 517 274 294 517 274 296 minecraft:brown_terracotta
setblock 517 274 297 minecraft:white_concrete
setblock 517 274 301 minecraft:white_concrete
setblock 517 274 305 minecraft:white_concrete
fill 517 274 306 517 274 308 minecraft:brown_terracotta
setblock 517 274 309 minecraft:white_concrete
setblock 517 274 313 minecraft:white_concrete
setblock 517 274 317 minecraft:white_concrete
setblock 518 274 317 minecraft:brown_terracotta
setblock 519 274 275 minecraft:white_concrete
setblock 519 274 317 minecraft:white_concrete
setblock 520 274 317 minecraft:brown_terracotta
setblock 523 274 275 minecraft:white_concrete
setblock 523 274 317 minecraft:white_concrete
fill 524 274 275 526 274 275 minecraft:brown_terracotta
setblock 527 274 275 minecraft:white_concrete
setblock 527 274 317 minecraft:white_concrete
fill 529 274 317 530 274 317 minecraft:brown_terracotta
setblock 531 274 275 minecraft:white_concrete
setblock 531 274 317 minecraft:white_concrete
setblock 532 274 317 minecraft:brown_terracotta
setblock 535 274 275 minecraft:white_concrete
setblock 535 274 317 minecraft:white_concrete
fill 536 274 275 538 274 275 minecraft:brown_terracotta
setblock 539 274 275 minecraft:white_concrete
setblock 539 274 317 minecraft:white_concrete
fill 541 274 317 542 274 317 minecraft:brown_terracotta
setblock 543 274 275 minecraft:white_concrete
setblock 543 274 317 minecraft:white_concrete
setblock 544 274 317 minecraft:brown_terracotta
setblock 547 274 275 minecraft:white_concrete
setblock 547 274 317 minecraft:white_concrete
fill 548 274 275 550 274 275 minecraft:brown_terracotta
setblock 551 274 275 minecraft:white_concrete
setblock 551 274 317 minecraft:white_concrete
fill 553 274 317 554 274 317 minecraft:brown_terracotta
setblock 555 274 275 minecraft:white_concrete
setblock 555 274 317 minecraft:white_concrete
setblock 556 274 317 minecraft:brown_terracotta
setblock 559 274 275 minecraft:white_concrete
setblock 559 274 276 minecraft:brown_terracotta
setblock 559 274 277 minecraft:white_concrete
fill 559 274 278 559 274 279 minecraft:brown_terracotta
setblock 559 274 281 minecraft:white_concrete
setblock 559 274 285 minecraft:white_concrete
setblock 559 274 288 minecraft:brown_terracotta
setblock 559 274 289 minecraft:white_concrete
fill 559 274 290 559 274 291 minecraft:brown_terracotta
setblock 559 274 293 minecraft:white_concrete
setblock 559 274 297 minecraft:white_concrete
setblock 559 274 300 minecraft:brown_terracotta
setblock 559 274 301 minecraft:white_concrete
fill 559 274 302 559 274 303 minecraft:brown_terracotta
setblock 559 274 305 minecraft:white_concrete
setblock 559 274 309 minecraft:white_concrete
setblock 559 274 312 minecraft:brown_terracotta
setblock 559 274 313 minecraft:white_concrete
fill 559 274 314 559 274 315 minecraft:brown_terracotta
setblock 559 274 317 minecraft:white_concrete
setblock 517 275 276 minecraft:white_concrete
fill 517 275 277 517 282 277 minecraft:brown_terracotta
setblock 517 275 278 minecraft:white_concrete
setblock 517 275 280 minecraft:white_concrete
fill 517 275 281 517 282 281 minecraft:brown_terracotta
setblock 517 275 282 minecraft:white_concrete
setblock 517 275 283 minecraft:brown_terracotta
setblock 517 275 284 minecraft:white_concrete
fill 517 275 285 517 282 285 minecraft:brown_terracotta
setblock 517 275 286 minecraft:white_concrete
setblock 517 275 288 minecraft:white_concrete
fill 517 275 289 517 282 289 minecraft:brown_terracotta
setblock 517 275 290 minecraft:white_concrete
setblock 517 275 292 minecraft:white_concrete
fill 517 275 293 517 282 293 minecraft:brown_terracotta
setblock 517 275 294 minecraft:white_concrete
setblock 517 275 295 minecraft:brown_terracotta
setblock 517 275 296 minecraft:white_concrete
fill 517 275 297 517 282 297 minecraft:brown_terracotta
setblock 517 275 298 minecraft:white_concrete
setblock 517 275 300 minecraft:white_concrete
fill 517 275 301 517 282 301 minecraft:brown_terracotta
setblock 517 275 302 minecraft:white_concrete
setblock 517 275 304 minecraft:white_concrete
fill 517 275 305 517 282 305 minecraft:brown_terracotta
setblock 517 275 306 minecraft:white_concrete
setblock 517 275 307 minecraft:brown_terracotta
setblock 517 275 308 minecraft:white_concrete
fill 517 275 309 517 282 309 minecraft:brown_terracotta
setblock 517 275 310 minecraft:white_concrete
setblock 517 275 312 minecraft:white_concrete
fill 517 275 313 517 282 313 minecraft:brown_terracotta
setblock 517 275 314 minecraft:white_concrete
setblock 517 275 316 minecraft:white_concrete
setblock 517 275 317 minecraft:brown_terracotta
setblock 518 275 275 minecraft:white_concrete
setblock 518 275 317 minecraft:white_concrete
fill 519 275 275 519 282 275 minecraft:brown_terracotta
fill 519 275 317 519 282 317 minecraft:brown_terracotta
setblock 520 275 275 minecraft:white_concrete
setblock 520 275 317 minecraft:white_concrete
setblock 522 275 275 minecraft:white_concrete
setblock 522 275 317 minecraft:white_concrete
fill 523 275 275 523 282 275 minecraft:brown_terracotta
fill 523 275 317 523 282 317 minecraft:brown_terracotta
setblock 524 275 275 minecraft:white_concrete
setblock 524 275 317 minecraft:white_concrete
setblock 525 275 275 minecraft:brown_terracotta
setblock 526 275 275 minecraft:white_concrete
setblock 526 275 317 minecraft:white_concrete
fill 527 275 275 527 282 275 minecraft:brown_terracotta
fill 527 275 317 527 282 317 minecraft:brown_terracotta
setblock 528 275 275 minecraft:white_concrete
setblock 528 275 317 minecraft:white_concrete
setblock 529 275 317 minecraft:brown_terracotta
setblock 530 275 275 minecraft:white_concrete
setblock 530 275 317 minecraft:white_concrete
fill 531 275 275 531 282 275 minecraft:brown_terracotta
fill 531 275 317 531 282 317 minecraft:brown_terracotta
setblock 532 275 275 minecraft:white_concrete
setblock 532 275 317 minecraft:white_concrete
setblock 534 275 275 minecraft:white_concrete
setblock 534 275 317 minecraft:white_concrete
fill 535 275 275 535 282 275 minecraft:brown_terracotta
fill 535 275 317 535 282 317 minecraft:brown_terracotta
setblock 536 275 275 minecraft:white_concrete
setblock 536 275 317 minecraft:white_concrete
setblock 537 275 275 minecraft:brown_terracotta
setblock 538 275 275 minecraft:white_concrete
setblock 538 275 317 minecraft:white_concrete
fill 539 275 275 539 282 275 minecraft:brown_terracotta
fill 539 275 317 539 282 317 minecraft:brown_terracotta
setblock 540 275 275 minecraft:white_concrete
setblock 540 275 317 minecraft:white_concrete
setblock 541 275 317 minecraft:brown_terracotta
setblock 542 275 275 minecraft:white_concrete
setblock 542 275 317 minecraft:white_concrete
fill 543 275 275 543 282 275 minecraft:brown_terracotta
fill 543 275 317 543 282 317 minecraft:brown_terracotta
setblock 544 275 275 minecraft:white_concrete
setblock 544 275 317 minecraft:white_concrete
setblock 546 275 275 minecraft:white_concrete
setblock 546 275 317 minecraft:white_concrete
fill 547 275 275 547 282 275 minecraft:brown_terracotta
fill 547 275 317 547 282 317 minecraft:brown_terracotta
setblock 548 275 275 minecraft:white_concrete
setblock 548 275 317 minecraft:white_concrete
setblock 549 275 275 minecraft:brown_terracotta
setblock 550 275 275 minecraft:white_concrete
setblock 550 275 317 minecraft:white_concrete
fill 551 275 275 551 282 275 minecraft:brown_terracotta
fill 551 275 317 551 282 317 minecraft:brown_terracotta
setblock 552 275 275 minecraft:white_concrete
setblock 552 275 317 minecraft:white_concrete
setblock 553 275 317 minecraft:brown_terracotta
setblock 554 275 275 minecraft:white_concrete
setblock 554 275 317 minecraft:white_concrete
fill 555 275 275 555 282 275 minecraft:brown_terracotta
fill 555 275 317 555 282 317 minecraft:brown_terracotta
setblock 556 275 275 minecraft:white_concrete
setblock 556 275 317 minecraft:white_concrete
setblock 558 275 275 minecraft:white_concrete
setblock 558 275 317 minecraft:white_concrete
setblock 559 275 275 minecraft:brown_terracotta
setblock 559 275 276 minecraft:white_concrete
fill 559 275 277 559 282 277 minecraft:brown_terracotta
setblock 559 275 278 minecraft:white_concrete
setblock 559 275 279 minecraft:brown_terracotta
setblock 559 275 280 minecraft:white_concrete
fill 559 275 281 559 282 281 minecraft:brown_terracotta
setblock 559 275 282 minecraft:white_concrete
setblock 559 275 284 minecraft:white_concrete
fill 559 275 285 559 282 285 minecraft:brown_terracotta
setblock 559 275 286 minecraft:white_concrete
setblock 559 275 288 minecraft:white_concrete
fill 559 275 289 559 282 289 minecraft:brown_terracotta
setblock 559 275 290 minecraft:white_concrete
setblock 559 275 291 minecraft:brown_terracotta
setblock 559 275 292 minecraft:white_concrete
fill 559 275 293 559 282 293 minecraft:brown_terracotta
setblock 559 275 294 minecraft:white_concrete
setblock 559 275 296 minecraft:white_concrete
fill 559 275 297 559 282 297 minecraft:brown_terracotta
setblock 559 275 298 minecraft:white_concrete
setblock 559 275 300 minecraft:white_concrete
fill 559 275 301 559 282 301 minecraft:brown_terracotta
setblock 559 275 302 minecraft:white_concrete
setblock 559 275 303 minecraft:brown_terracotta
setblock 559 275 304 minecraft:white_concrete
fill 559 275 305 559 282 305 minecraft:brown_terracotta
setblock 559 275 306 minecraft:white_concrete
setblock 559 275 308 minecraft:white_concrete
fill 559 275 309 559 282 309 minecraft:brown_terracotta
setblock 559 275 310 minecraft:white_concrete
setblock 559 275 312 minecraft:white_concrete
fill 559 275 313 559 282 313 minecraft:brown_terracotta
setblock 559 275 314 minecraft:white_concrete
setblock 559 275 315 minecraft:brown_terracotta
setblock 559 275 316 minecraft:white_concrete
fill 559 275 317 559 282 317 minecraft:brown_terracotta
setblock 517 276 275 minecraft:white_concrete
fill 517 276 276 517 283 276 minecraft:brown_terracotta
fill 517 276 278 517 283 278 minecraft:brown_terracotta
setblock 517 276 279 minecraft:white_concrete
fill 517 276 280 517 283 280 minecraft:brown_terracotta
fill 517 276 282 517 283 282 minecraft:brown_terracotta
setblock 517 276 283 minecraft:white_concrete
fill 517 276 284 517 283 284 minecraft:brown_terracotta
fill 517 276 286 517 283 286 minecraft:brown_terracotta
setblock 517 276 287 minecraft:white_concrete
fill 517 276 288 517 283 288 minecraft:brown_terracotta
fill 517 276 290 517 283 290 minecraft:brown_terracotta
setblock 517 276 291 minecraft:white_concrete
fill 517 276 292 517 283 292 minecraft:brown_terracotta
fill 517 276 294 517 283 294 minecraft:brown_terracotta
setblock 517 276 295 minecraft:white_concrete
fill 517 276 296 517 283 296 minecraft:brown_terracotta
fill 517 276 298 517 283 298 minecraft:brown_terracotta
setblock 517 276 299 minecraft:white_concrete
fill 517 276 300 517 283 300 minecraft:brown_terracotta
fill 517 276 302 517 283 302 minecraft:brown_terracotta
setblock 517 276 303 minecraft:white_concrete
fill 517 276 304 517 283 304 minecraft:brown_terracotta
fill 517 276 306 517 283 306 minecraft:brown_terracotta
setblock 517 276 307 minecraft:white_concrete
fill 517 276 308 517 283 308 minecraft:brown_terracotta
fill 517 276 310 517 283 310 minecraft:brown_terracotta
setblock 517 276 311 minecraft:white_concrete
fill 517 276 312 517 283 312 minecraft:brown_terracotta
fill 517 276 314 517 283 314 minecraft:brown_terracotta
setblock 517 276 315 minecraft:white_concrete
fill 517 276 316 517 283 316 minecraft:brown_terracotta
setblock 517 276 317 minecraft:white_concrete
fill 518 276 275 518 283 275 minecraft:brown_terracotta
fill 518 276 317 518 283 317 minecraft:brown_terracotta
fill 520 276 275 520 283 275 minecraft:brown_terracotta
fill 520 276 317 520 283 317 minecraft:brown_terracotta
setblock 521 276 275 minecraft:white_concrete
setblock 521 276 317 minecraft:white_concrete
fill 522 276 275 522 283 275 minecraft:brown_terracotta
fill 522 276 317 522 283 317 minecraft:brown_terracotta
fill 524 276 275 524 283 275 minecraft:brown_terracotta
fill 524 276 317 524 283 317 minecraft:brown_terracotta
setblock 525 276 275 minecraft:white_concrete
setblock 525 276 317 minecraft:white_concrete
fill 526 276 275 526 283 275 minecraft:brown_terracotta
fill 526 276 317 526 283 317 minecraft:brown_terracotta
fill 528 276 275 528 283 275 minecraft:brown_terracotta
fill 528 276 317 528 283 317 minecraft:brown_terracotta
setblock 529 276 275 minecraft:white_concrete
setblock 529 276 317 minecraft:white_concrete
fill 530 276 275 530 283 275 minecraft:brown_terracotta
fill 530 276 317 530 283 317 minecraft:brown_terracotta
fill 532 276 275 532 283 275 minecraft:brown_terracotta
fill 532 276 317 532 283 317 minecraft:brown_terracotta
setblock 533 276 275 minecraft:white_concrete
setblock 533 276 317 minecraft:white_concrete
fill 534 276 275 534 283 275 minecraft:brown_terracotta
fill 534 276 317 534 283 317 minecraft:brown_terracotta
fill 536 276 275 536 283 275 minecraft:brown_terracotta
fill 536 276 317 536 283 317 minecraft:brown_terracotta
setblock 537 276 275 minecraft:white_concrete
setblock 537 276 317 minecraft:white_concrete
fill 538 276 275 538 283 275 minecraft:brown_terracotta
fill 538 276 317 538 283 317 minecraft:brown_terracotta
fill 540 276 275 540 283 275 minecraft:brown_terracotta
fill 540 276 317 540 283 317 minecraft:brown_terracotta
setblock 541 276 275 minecraft:white_concrete
setblock 541 276 317 minecraft:white_concrete
fill 542 276 275 542 283 275 minecraft:brown_terracotta
fill 542 276 317 542 283 317 minecraft:brown_terracotta
fill 544 276 275 544 283 275 minecraft:brown_terracotta
fill 544 276 317 544 283 317 minecraft:brown_terracotta
setblock 545 276 275 minecraft:white_concrete
setblock 545 276 317 minecraft:white_concrete
fill 546 276 275 546 283 275 minecraft:brown_terracotta
fill 546 276 317 546 283 317 minecraft:brown_terracotta
fill 548 276 275 548 283 275 minecraft:brown_terracotta
fill 548 276 317 548 283 317 minecraft:brown_terracotta
setblock 549 276 275 minecraft:white_concrete
setblock 549 276 317 minecraft:white_concrete
fill 550 276 275 550 283 275 minecraft:brown_terracotta
fill 550 276 317 550 283 317 minecraft:brown_terracotta
fill 552 276 275 552 283 275 minecraft:brown_terracotta
fill 552 276 317 552 283 317 minecraft:brown_terracotta
setblock 553 276 275 minecraft:white_concrete
setblock 553 276 317 minecraft:white_concrete
fill 554 276 275 554 283 275 minecraft:brown_terracotta
fill 554 276 317 554 283 317 minecraft:brown_terracotta
fill 556 276 275 556 283 275 minecraft:brown_terracotta
fill 556 276 317 556 283 317 minecraft:brown_terracotta
setblock 557 276 275 minecraft:white_concrete
setblock 557 276 317 minecraft:white_concrete
fill 558 276 275 558 283 275 minecraft:brown_terracotta
fill 558 276 317 558 283 317 minecraft:brown_terracotta
setblock 559 276 275 minecraft:white_concrete
fill 559 276 276 559 283 276 minecraft:brown_terracotta
fill 559 276 278 559 283 278 minecraft:brown_terracotta
setblock 559 276 279 minecraft:white_concrete
fill 559 276 280 559 283 280 minecraft:brown_terracotta
fill 559 276 282 559 283 282 minecraft:brown_terracotta
setblock 559 276 283 minecraft:white_concrete
fill 559 276 284 559 283 284 minecraft:brown_terracotta
fill 559 276 286 559 283 286 minecraft:brown_terracotta
setblock 559 276 287 minecraft:white_concrete
fill 559 276 288 559 283 288 minecraft:brown_terracotta
fill 559 276 290 559 283 290 minecraft:brown_terracotta
setblock 559 276 291 minecraft:white_concrete
fill 559 276 292 559 283 292 minecraft:brown_terracotta
fill 559 276 294 559 283 294 minecraft:brown_terracotta
setblock 559 276 295 minecraft:white_concrete
fill 559 276 296 559 283 296 minecraft:brown_terracotta
fill 559 276 298 559 283 298 minecraft:brown_terracotta
setblock 559 276 299 minecraft:white_concrete
fill 559 276 300 559 283 300 minecraft:brown_terracotta
fill 559 276 302 559 283 302 minecraft:brown_terracotta
setblock 559 276 303 minecraft:white_concrete
fill 559 276 304 559 283 304 minecraft:brown_terracotta
fill 559 276 306 559 283 306 minecraft:brown_terracotta
setblock 559 276 307 minecraft:white_concrete
fill 559 276 308 559 283 308 minecraft:brown_terracotta
fill 559 276 310 559 283 310 minecraft:brown_terracotta
setblock 559 276 311 minecraft:white_concrete
fill 559 276 312 559 283 312 minecraft:brown_terracotta
fill 559 276 314 559 283 314 minecraft:brown_terracotta
setblock 559 276 315 minecraft:white_concrete
fill 559 276 316 559 283 316 minecraft:brown_terracotta
fill 517 277 275 517 284 275 minecraft:brown_terracotta
fill 517 277 279 517 284 279 minecraft:brown_terracotta
fill 517 277 283 517 284 283 minecraft:brown_terracotta
fill 517 277 287 517 284 287 minecraft:brown_terracotta
fill 517 277 291 517 284 291 minecraft:brown_terracotta
fill 517 277 295 517 284 295 minecraft:brown_terracotta
fill 517 277 299 517 284 299 minecraft:brown_terracotta
fill 517 277 303 517 284 303 minecraft:brown_terracotta
fill 517 277 307 517 284 307 minecraft:brown_terracotta
fill 517 277 311 517 284 311 minecraft:brown_terracotta
fill 517 277 315 517 284 315 minecraft:brown_terracotta
fill 517 277 317 517 282 317 minecraft:brown_terracotta
setblock 520 277 278 minecraft:light[level=15]
setblock 520 277 285 minecraft:light[level=12]
setblock 520 277 286 minecraft:light[level=15]
setblock 520 277 292 minecraft:light[level=12]
setblock 520 277 294 minecraft:light[level=15]
setblock 520 277 299 minecraft:light[level=12]
setblock 520 277 302 minecraft:light[level=15]
setblock 520 277 306 minecraft:light[level=12]
setblock 520 277 310 minecraft:light[level=15]
setblock 520 277 313 minecraft:light[level=12]
fill 521 277 275 521 284 275 minecraft:brown_terracotta
fill 521 277 317 521 284 317 minecraft:brown_terracotta
fill 525 277 275 525 284 275 minecraft:brown_terracotta
fill 525 277 317 525 284 317 minecraft:brown_terracotta
setblock 527 277 278 minecraft:light[level=12]
setblock 527 277 285 minecraft:light[level=12]
setblock 527 277 292 minecraft:light[level=12]
setblock 527 277 299 minecraft:light[level=12]
setblock 527 277 306 minecraft:light[level=12]
setblock 527 277 313 minecraft:light[level=12]
setblock 528 277 278 minecraft:light[level=15]
setblock 528 277 286 minecraft:light[level=15]
setblock 528 277 294 minecraft:light[level=15]
fill 528 277 299 535 278 299 minecraft:brown_terracotta
setblock 528 277 302 minecraft:light[level=15]
setblock 528 277 310 minecraft:light[level=15]
fill 529 277 275 529 284 275 minecraft:brown_terracotta
fill 529 277 295 536 278 298 minecraft:brown_terracotta
fill 529 277 300 536 278 303 minecraft:brown_terracotta
fill 529 277 317 529 284 317 minecraft:brown_terracotta
fill 530 277 293 548 278 294 minecraft:brown_terracotta
fill 530 277 304 548 277 305 minecraft:brown_terracotta
fill 531 277 292 547 278 292 minecraft:brown_terracotta
fill 531 277 306 547 278 306 minecraft:brown_terracotta
fill 532 277 291 546 278 291 minecraft:brown_terracotta
fill 532 277 307 546 278 307 minecraft:brown_terracotta
fill 533 277 275 533 284 275 minecraft:brown_terracotta
fill 533 277 290 545 278 290 minecraft:brown_terracotta
fill 533 277 308 545 278 308 minecraft:brown_terracotta
fill 533 277 317 533 284 317 minecraft:brown_terracotta
setblock 534 277 278 minecraft:light[level=12]
setblock 534 277 285 minecraft:light[level=12]
setblock 534 277 313 minecraft:light[level=12]
fill 535 277 289 543 278 289 minecraft:brown_terracotta
fill 535 277 309 543 278 309 minecraft:brown_terracotta
setblock 536 277 278 minecraft:light[level=15]
setblock 536 277 286 minecraft:light[level=15]
setblock 536 277 310 minecraft:light[level=15]
fill 537 277 275 537 284 275 minecraft:brown_terracotta
fill 537 277 295 538 278 296 minecraft:brown_terracotta
fill 537 277 302 538 278 303 minecraft:brown_terracotta
fill 537 277 317 537 284 317 minecraft:brown_terracotta
fill 539 277 288 539 278 288 minecraft:brown_terracotta
fill 539 277 295 549 278 295 minecraft:brown_terracotta
fill 539 277 303 549 278 303 minecraft:brown_terracotta
fill 539 277 310 539 278 310 minecraft:brown_terracotta
fill 540 277 296 549 278 296 minecraft:brown_terracotta
fill 540 277 302 549 278 302 minecraft:brown_terracotta
fill 541 277 275 541 284 275 minecraft:brown_terracotta
setblock 541 277 278 minecraft:light[level=12]
setblock 541 277 285 minecraft:light[level=12]
setblock 541 277 313 minecraft:light[level=12]
fill 541 277 317 541 284 317 minecraft:brown_terracotta
fill 542 277 297 549 278 298 minecraft:brown_terracotta
fill 542 277 300 549 278 301 minecraft:brown_terracotta
fill 543 277 299 550 278 299 minecraft:brown_terracotta
setblock 544 277 278 minecraft:light[level=15]
setblock 544 277 286 minecraft:light[level=15]
setblock 544 277 310 minecraft:light[level=15]
fill 545 277 275 545 284 275 minecraft:brown_terracotta
fill 545 277 317 545 284 317 minecraft:brown_terracotta
setblock 548 277 278 minecraft:light[level=12]
setblock 548 277 285 minecraft:light[level=12]
setblock 548 277 292 minecraft:light[level=12]
setblock 548 277 306 minecraft:light[level=12]
setblock 548 277 313 minecraft:light[level=12]
fill 549 277 275 549 284 275 minecraft:brown_terracotta
fill 549 277 317 549 284 317 minecraft:brown_terracotta
setblock 552 277 278 minecraft:light[level=15]
setblock 552 277 286 minecraft:light[level=15]
setblock 552 277 294 minecraft:light[level=15]
setblock 552 277 302 minecraft:light[level=15]
setblock 552 277 310 minecraft:light[level=15]
fill 553 277 275 553 284 275 minecraft:brown_terracotta
fill 553 277 317 553 284 317 minecraft:brown_terracotta
setblock 555 277 278 minecraft:light[level=12]
setblock 555 277 285 minecraft:light[level=12]
setblock 555 277 292 minecraft:light[level=12]
setblock 555 277 299 minecraft:light[level=12]
setblock 555 277 306 minecraft:light[level=12]
setblock 555 277 313 minecraft:light[level=12]
fill 557 277 275 557 284 275 minecraft:brown_terracotta
fill 557 277 317 557 284 317 minecraft:brown_terracotta
fill 559 277 275 559 282 275 minecraft:brown_terracotta
fill 559 277 279 559 284 279 minecraft:brown_terracotta
fill 559 277 283 559 284 283 minecraft:brown_terracotta
fill 559 277 287 559 284 287 minecraft:brown_terracotta
fill 559 277 291 559 284 291 minecraft:brown_terracotta
fill 559 277 295 559 284 295 minecraft:brown_terracotta
fill 559 277 299 559 284 299 minecraft:brown_terracotta
fill 559 277 303 559 284 303 minecraft:brown_terracotta
fill 559 277 307 559 284 307 minecraft:brown_terracotta
fill 559 277 311 559 284 311 minecraft:brown_terracotta
fill 559 277 315 559 284 315 minecraft:brown_terracotta
fill 530 278 304 534 278 305 minecraft:brown_terracotta
fill 535 278 304 548 278 304 minecraft:brown_terracotta
fill 535 278 305 535 280 305 minecraft:red_concrete
fill 536 278 305 538 278 305 minecraft:brown_terracotta
fill 539 278 305 539 280 305 minecraft:lime_concrete
fill 540 278 305 542 278 305 minecraft:brown_terracotta
fill 543 278 305 543 280 305 minecraft:light_blue_concrete
fill 544 278 305 548 278 305 minecraft:brown_terracotta
fill 518 279 276 518 279 277 minecraft:snow_block
setblock 518 279 278 minecraft:white_wool
fill 518 279 279 518 279 281 minecraft:snow_block
setblock 518 279 282 minecraft:white_wool
fill 518 279 283 518 279 285 minecraft:snow_block
setblock 518 279 286 minecraft:white_wool
fill 518 279 287 518 279 289 minecraft:snow_block
setblock 518 279 290 minecraft:white_wool
fill 518 279 291 518 279 293 minecraft:snow_block
setblock 518 279 294 minecraft:white_wool
fill 518 279 295 518 279 297 minecraft:snow_block
setblock 518 279 298 minecraft:white_wool
fill 518 279 299 518 279 301 minecraft:snow_block
setblock 518 279 302 minecraft:white_wool
fill 518 279 303 518 279 305 minecraft:snow_block
setblock 518 279 306 minecraft:white_wool
fill 518 279 307 518 279 309 minecraft:snow_block
setblock 518 279 310 minecraft:white_wool
fill 518 279 311 518 279 313 minecraft:snow_block
setblock 518 279 314 minecraft:white_wool
fill 518 279 315 519 279 316 minecraft:snow_block
setblock 519 279 276 minecraft:snow_block
setblock 519 279 277 minecraft:white_wool
fill 519 279 278 519 279 280 minecraft:snow_block
setblock 519 279 281 minecraft:white_wool
fill 519 279 282 519 279 284 minecraft:snow_block
setblock 519 279 285 minecraft:white_wool
fill 519 279 286 519 279 288 minecraft:snow_block
setblock 519 279 289 minecraft:white_wool
fill 519 279 290 519 279 292 minecraft:snow_block
setblock 519 279 293 minecraft:white_wool
fill 519 279 294 519 279 296 minecraft:snow_block
setblock 519 279 297 minecraft:white_wool
fill 519 279 298 519 279 300 minecraft:snow_block
setblock 519 279 301 minecraft:white_wool
fill 519 279 302 519 279 304 minecraft:snow_block
setblock 519 279 305 minecraft:white_wool
fill 519 279 306 519 279 308 minecraft:snow_block
setblock 519 279 309 minecraft:white_wool
fill 519 279 310 519 279 312 minecraft:snow_block
setblock 519 279 313 minecraft:white_wool
fill 519 279 314 521 279 314 minecraft:snow_block
setblock 520 279 276 minecraft:white_wool
fill 520 279 277 520 279 279 minecraft:snow_block
setblock 520 279 280 minecraft:white_wool
fill 520 279 281 520 279 283 minecraft:snow_block
setblock 520 279 284 minecraft:white_wool
fill 520 279 285 520 279 287 minecraft:snow_block
setblock 520 279 288 minecraft:white_wool
fill 520 279 289 520 279 291 minecraft:snow_block
setblock 520 279 292 minecraft:white_wool
fill 520 279 293 520 279 295 minecraft:snow_block
setblock 520 279 296 minecraft:white_wool
fill 520 279 297 520 279 299 minecraft:snow_block
setblock 520 279 300 minecraft:white_wool
fill 520 279 301 520 279 303 minecraft:snow_block
setblock 520 279 304 minecraft:white_wool
fill 520 279 305 520 279 307 minecraft:snow_block
setblock 520 279 308 minecraft:white_wool
fill 520 279 309 520 279 311 minecraft:snow_block
setblock 520 279 312 minecraft:white_wool
fill 520 279 313 522 279 313 minecraft:snow_block
setblock 520 279 315 minecraft:snow_block
setblock 520 279 316 minecraft:white_wool
fill 521 279 276 521 279 278 minecraft:snow_block
setblock 521 279 279 minecraft:white_wool
fill 521 279 280 521 279 282 minecraft:snow_block
setblock 521 279 283 minecraft:white_wool
fill 521 279 284 521 279 286 minecraft:snow_block
setblock 521 279 287 minecraft:white_wool
fill 521 279 288 521 279 290 minecraft:snow_block
setblock 521 279 291 minecraft:white_wool
fill 521 279 292 521 279 294 minecraft:snow_block
setblock 521 279 295 minecraft:white_wool
fill 521 279 296 521 279 298 minecraft:snow_block
setblock 521 279 299 minecraft:white_wool
fill 521 279 300 521 279 302 minecraft:snow_block
setblock 521 279 303 minecraft:white_wool
fill 521 279 304 521 279 306 minecraft:snow_block
setblock 521 279 307 minecraft:white_wool
fill 521 279 308 521 279 310 minecraft:snow_block
setblock 521 279 311 minecraft:white_wool
fill 521 279 312 523 279 312 minecraft:snow_block
setblock 521 279 315 minecraft:white_wool
fill 521 279 316 523 279 316 minecraft:snow_block
fill 522 279 276 522 279 277 minecraft:snow_block
setblock 522 279 278 minecraft:white_wool
fill 522 279 279 522 279 281 minecraft:snow_block
setblock 522 279 282 minecraft:white_wool
fill 522 279 283 522 279 285 minecraft:snow_block
setblock 522 279 286 minecraft:white_wool
fill 522 279 287 522 279 289 minecraft:snow_block
setblock 522 279 290 minecraft:white_wool
fill 522 279 291 522 279 293 minecraft:snow_block
setblock 522 279 294 minecraft:white_wool
fill 522 279 295 522 279 297 minecraft:snow_block
setblock 522 279 298 minecraft:white_wool
fill 522 279 299 522 279 301 minecraft:snow_block
setblock 522 279 302 minecraft:white_wool
fill 522 279 303 522 279 305 minecraft:snow_block
setblock 522 279 306 minecraft:white_wool
fill 522 279 307 522 279 309 minecraft:snow_block
setblock 522 279 310 minecraft:white_wool
fill 522 279 311 524 279 311 minecraft:snow_block
setblock 522 279 314 minecraft:white_wool
fill 522 279 315 524 279 315 minecraft:snow_block
setblock 523 279 276 minecraft:snow_block
setblock 523 279 277 minecraft:white_wool
fill 523 279 278 523 279 280 minecraft:snow_block
setblock 523 279 281 minecraft:white_wool
fill 523 279 282 523 279 284 minecraft:snow_block
setblock 523 279 285 minecraft:white_wool
fill 523 279 286 523 279 288 minecraft:snow_block
setblock 523 279 289 minecraft:white_wool
fill 523 279 290 523 279 292 minecraft:snow_block
setblock 523 279 293 minecraft:white_wool
fill 523 279 294 523 279 296 minecraft:snow_block
setblock 523 279 297 minecraft:white_wool
fill 523 279 298 523 279 300 minecraft:snow_block
setblock 523 279 301 minecraft:white_wool
fill 523 279 302 523 279 304 minecraft:snow_block
setblock 523 279 305 minecraft:white_wool
fill 523 279 306 523 279 308 minecraft:snow_block
setblock 523 279 309 minecraft:white_wool
fill 523 279 310 525 279 310 minecraft:snow_block
setblock 523 279 313 minecraft:white_wool
fill 523 279 314 525 279 314 minecraft:snow_block
setblock 524 279 276 minecraft:white_wool
fill 524 279 277 524 279 279 minecraft:snow_block
setblock 524 279 280 minecraft:white_wool
fill 524 279 281 524 279 283 minecraft:snow_block
setblock 524 279 284 minecraft:white_wool
fill 524 279 285 524 279 287 minecraft:snow_block
setblock 524 279 288 minecraft:white_wool
fill 524 279 289 524 279 291 minecraft:snow_block
setblock 524 279 292 minecraft:white_wool
fill 524 279 293 524 279 295 minecraft:snow_block
setblock 524 279 296 minecraft:white_wool
fill 524 279 297 524 279 299 minecraft:snow_block
setblock 524 279 300 minecraft:white_wool
fill 524 279 301 524 279 303 minecraft:snow_block
setblock 524 279 304 minecraft:white_wool
fill 524 279 305 524 279 307 minecraft:snow_block
setblock 524 279 308 minecraft:white_wool
fill 524 279 309 526 279 309 minecraft:snow_block
setblock 524 279 312 minecraft:white_wool
fill 524 279 313 526 279 313 minecraft:snow_block
setblock 524 279 316 minecraft:white_wool
fill 525 279 276 525 279 278 minecraft:snow_block
setblock 525 279 279 minecraft:white_wool
fill 525 279 280 525 279 282 minecraft:snow_block
setblock 525 279 283 minecraft:white_wool
fill 525 279 284 525 279 286 minecraft:snow_block
setblock 525 279 287 minecraft:white_wool
fill 525 279 288 525 279 290 minecraft:snow_block
setblock 525 279 291 minecraft:white_wool
fill 525 279 292 525 279 294 minecraft:snow_block
setblock 525 279 295 minecraft:white_wool
fill 525 279 296 525 279 298 minecraft:snow_block
setblock 525 279 299 minecraft:white_wool
fill 525 279 300 525 279 302 minecraft:snow_block
setblock 525 279 303 minecraft:white_wool
fill 525 279 304 525 279 306 minecraft:snow_block
setblock 525 279 307 minecraft:white_wool
fill 525 279 308 527 279 308 minecraft:snow_block
setblock 525 279 311 minecraft:white_wool
fill 525 279 312 527 279 312 minecraft:snow_block
setblock 525 279 315 minecraft:white_wool
fill 525 279 316 527 279 316 minecraft:snow_block
fill 526 279 276 526 279 277 minecraft:snow_block
setblock 526 279 278 minecraft:white_wool
fill 526 279 279 526 279 281 minecraft:snow_block
setblock 526 279 282 minecraft:white_wool
fill 526 279 283 526 279 285 minecraft:snow_block
setblock 526 279 286 minecraft:white_wool
fill 526 279 287 526 279 289 minecraft:snow_block
setblock 526 279 290 minecraft:white_wool
fill 526 279 291 526 279 293 minecraft:snow_block
setblock 526 279 294 minecraft:white_wool
fill 526 279 295 526 279 297 minecraft:snow_block
setblock 526 279 298 minecraft:white_wool
fill 526 279 299 526 279 301 minecraft:snow_block
setblock 526 279 302 minecraft:white_wool
fill 526 279 303 526 279 305 minecraft:snow_block
setblock 526 279 306 minecraft:white_wool
fill 526 279 307 528 279 307 minecraft:snow_block
setblock 526 279 310 minecraft:white_wool
fill 526 279 311 528 279 311 minecraft:snow_block
setblock 526 279 314 minecraft:white_wool
fill 526 279 315 528 279 315 minecraft:snow_block
setblock 527 279 276 minecraft:snow_block
setblock 527 279 277 minecraft:white_wool
fill 527 279 278 527 279 280 minecraft:snow_block
setblock 527 279 281 minecraft:white_wool
fill 527 279 282 527 279 284 minecraft:snow_block
setblock 527 279 285 minecraft:white_wool
fill 527 279 286 527 279 288 minecraft:snow_block
setblock 527 279 289 minecraft:white_wool
fill 527 279 290 527 279 292 minecraft:snow_block
setblock 527 279 293 minecraft:white_wool
fill 527 279 294 527 279 296 minecraft:snow_block
setblock 527 279 297 minecraft:white_wool
fill 527 279 298 527 279 300 minecraft:snow_block
setblock 527 279 301 minecraft:white_wool
fill 527 279 302 527 279 304 minecraft:snow_block
setblock 527 279 305 minecraft:white_wool
fill 527 279 306 529 279 306 minecraft:snow_block
setblock 527 279 309 minecraft:white_wool
fill 527 279 310 529 279 310 minecraft:snow_block
setblock 527 279 313 minecraft:white_wool
fill 527 279 314 529 279 314 minecraft:snow_block
setblock 528 279 276 minecraft:white_wool
fill 528 279 277 528 279 279 minecraft:snow_block
setblock 528 279 280 minecraft:white_wool
fill 528 279 281 528 279 283 minecraft:snow_block
setblock 528 279 284 minecraft:white_wool
fill 528 279 285 528 279 287 minecraft:snow_block
setblock 528 279 288 minecraft:white_wool
fill 528 279 289 528 279 291 minecraft:snow_block
setblock 528 279 292 minecraft:white_wool
fill 528 279 293 528 279 295 minecraft:snow_block
setblock 528 279 296 minecraft:white_wool
fill 528 279 297 528 279 298 minecraft:snow_block
setblock 528 279 299 minecraft:orange_terracotta
setblock 528 279 300 minecraft:white_wool
fill 528 279 301 528 279 303 minecraft:snow_block
setblock 528 279 304 minecraft:white_wool
fill 528 279 305 529 279 305 minecraft:snow_block
setblock 528 279 308 minecraft:white_wool
fill 528 279 309 530 279 309 minecraft:snow_block
setblock 528 279 312 minecraft:white_wool
fill 528 279 313 530 279 313 minecraft:snow_block
setblock 528 279 316 minecraft:white_wool
fill 529 279 276 529 279 278 minecraft:snow_block
setblock 529 279 279 minecraft:white_wool
fill 529 279 280 529 279 282 minecraft:snow_block
setblock 529 279 283 minecraft:white_wool
fill 529 279 284 529 279 286 minecraft:snow_block
setblock 529 279 287 minecraft:white_wool
fill 529 279 288 529 279 290 minecraft:snow_block
setblock 529 279 291 minecraft:white_wool
fill 529 279 292 529 279 294 minecraft:snow_block
fill 529 279 295 531 279 295 minecraft:orange_terracotta
fill 529 279 296 529 279 302 minecraft:white_concrete
fill 529 279 303 531 279 303 minecraft:orange_terracotta
setblock 529 279 304 minecraft:snow_block
setblock 529 279 307 minecraft:white_wool
fill 529 279 308 531 279 308 minecraft:snow_block
setblock 529 279 311 minecraft:white_wool
fill 529 279 312 531 279 312 minecraft:snow_block
setblock 529 279 315 minecraft:white_wool
fill 529 279 316 531 279 316 minecraft:snow_block
fill 530 279 276 530 279 277 minecraft:snow_block
setblock 530 279 278 minecraft:white_wool
fill 530 279 279 530 279 281 minecraft:snow_block
setblock 530 279 282 minecraft:white_wool
fill 530 279 283 530 279 285 minecraft:snow_block
setblock 530 279 286 minecraft:white_wool
fill 530 279 287 530 279 289 minecraft:snow_block
setblock 530 279 290 minecraft:white_wool
fill 530 279 291 530 279 292 minecraft:snow_block
setblock 530 279 293 minecraft:orange_terracotta
setblock 530 279 294 minecraft:white_concrete
fill 530 279 296 530 279 302 minecraft:orange_terracotta
setblock 530 279 304 minecraft:white_concrete
setblock 530 279 305 minecraft:orange_terracotta
setblock 530 279 306 minecraft:white_wool
fill 530 279 307 531 279 307 minecraft:snow_block
setblock 530 279 310 minecraft:white_wool
fill 530 279 311 532 279 311 minecraft:snow_block
setblock 530 279 314 minecraft:white_wool
fill 530 279 315 532 279 315 minecraft:snow_block
setblock 531 279 276 minecraft:snow_block
setblock 531 279 277 minecraft:white_wool
fill 531 279 278 531 279 280 minecraft:snow_block
setblock 531 279 281 minecraft:white_wool
fill 531 279 282 531 279 284 minecraft:snow_block
setblock 531 279 285 minecraft:white_wool
fill 531 279 286 531 279 288 minecraft:snow_block
setblock 531 279 289 minecraft:white_wool
fill 531 279 290 531 279 291 minecraft:snow_block
fill 531 279 292 531 279 293 minecraft:white_concrete
fill 531 279 294 532 279 294 minecraft:orange_terracotta
fill 531 279 296 535 279 296 minecraft:orange_terracotta
fill 531 279 297 531 279 301 minecraft:white_concrete
fill 531 279 302 535 279 302 minecraft:orange_terracotta
fill 531 279 304 532 279 304 minecraft:orange_terracotta
fill 531 279 305 531 279 306 minecraft:white_concrete
setblock 531 279 309 minecraft:white_wool
fill 531 279 310 533 279 310 minecraft:snow_block
setblock 531 279 313 minecraft:white_wool
fill 531 279 314 533 279 314 minecraft:snow_block
setblock 532 279 276 minecraft:white_wool
fill 532 279 277 532 279 279 minecraft:snow_block
setblock 532 279 280 minecraft:white_wool
fill 532 279 281 532 279 283 minecraft:snow_block
setblock 532 279 284 minecraft:white_wool
fill 532 279 285 532 279 287 minecraft:snow_block
setblock 532 279 288 minecraft:white_wool
fill 532 279 289 532 279 290 minecraft:snow_block
fill 532 279 291 532 279 292 minecraft:white_concrete
fill 532 279 293 533 279 293 minecraft:orange_terracotta
setblock 532 279 295 minecraft:white_concrete
fill 532 279 297 534 279 301 minecraft:orange_terracotta
setblock 532 279 303 minecraft:white_concrete
fill 532 279 305 533 279 305 minecraft:orange_terracotta
fill 532 279 306 532 279 307 minecraft:white_concrete
setblock 532 279 308 minecraft:white_wool
fill 532 279 309 534 279 309 minecraft:snow_block
setblock 532 279 312 minecraft:white_wool
fill 532 279 313 534 279 313 minecraft:snow_block
setblock 532 279 316 minecraft:white_wool
fill 533 279 276 533 279 278 minecraft:snow_block
setblock 533 279 279 minecraft:white_wool
fill 533 279 280 533 279 282 minecraft:snow_block
setblock 533 279 283 minecraft:white_wool
fill 533 279 284 533 279 286 minecraft:snow_block
setblock 533 279 287 minecraft:white_wool
fill 533 279 288 534 279 289 minecraft:snow_block
setblock 533 279 290 minecraft:orange_terracotta
setblock 533 279 291 minecraft:white_concrete
fill 533 279 292 534 279 292 minecraft:orange_terracotta
setblock 533 279 294 minecraft:white_concrete
fill 533 279 295 537 279 295 minecraft:orange_terracotta
fill 533 279 303 537 279 303 minecraft:orange_terracotta
setblock 533 279 304 minecraft:white_concrete
fill 533 279 306 534 279 306 minecraft:orange_terracotta
setblock 533 279 307 minecraft:white_concrete
setblock 533 279 308 minecraft:orange_terracotta
setblock 533 279 311 minecraft:white_wool
fill 533 279 312 535 279 312 minecraft:snow_block
setblock 533 279 315 minecraft:white_wool
fill 533 279 316 535 279 316 minecraft:snow_block
fill 534 279 276 534 279 277 minecraft:snow_block
setblock 534 279 278 minecraft:white_wool
fill 534 279 279 534 279 281 minecraft:snow_block
setblock 534 279 282 minecraft:white_wool
fill 534 279 283 534 279 285 minecraft:snow_block
setblock 534 279 286 minecraft:white_wool
fill 534 279 287 536 279 287 minecraft:snow_block
setblock 534 279 290 minecraft:white_concrete
fill 534 279 291 536 279 291 minecraft:orange_terracotta
setblock 534 279 293 minecraft:white_concrete
fill 534 279 294 535 279 294 minecraft:orange_terracotta
setblock 534 279 304 minecraft:orange_terracotta
setblock 534 279 305 minecraft:red_concrete
fill 534 279 307 536 279 307 minecraft:orange_terracotta
setblock 534 279 308 minecraft:white_concrete
setblock 534 279 310 minecraft:white_wool
fill 534 279 311 536 279 311 minecraft:snow_block
setblock 534 279 314 minecraft:white_wool
fill 534 279 315 536 279 315 minecraft:snow_block
setblock 535 279 276 minecraft:snow_block
setblock 535 279 277 minecraft:white_wool
fill 535 279 278 535 279 280 minecraft:snow_block
setblock 535 279 281 minecraft:white_wool
fill 535 279 282 535 279 284 minecraft:snow_block
setblock 535 279 285 minecraft:white_wool
fill 535 279 286 537 279 286 minecraft:snow_block
setblock 535 279 288 minecraft:snow_block
fill 535 279 289 535 279 290 minecraft:orange_terracotta
setblock 535 279 292 minecraft:white_concrete
fill 535 279 293 543 279 293 minecraft:orange_terracotta
setblock 535 279 297 minecraft:orange_terracotta
fill 535 279 298 535 279 300 minecraft:white_concrete
setblock 535 279 301 minecraft:orange_terracotta
setblock 535 279 304 minecraft:red_concrete
setblock 535 279 306 minecraft:red_concrete
fill 535 279 308 535 279 309 minecraft:orange_terracotta
fill 535 279 310 537 279 310 minecraft:snow_block
setblock 535 279 313 minecraft:white_wool
fill 535 279 314 537 279 314 minecraft:snow_block
setblock 536 279 276 minecraft:white_wool
fill 536 279 277 536 279 279 minecraft:snow_block
setblock 536 279 280 minecraft:white_wool
fill 536 279 281 536 279 283 minecraft:snow_block
setblock 536 279 284 minecraft:white_wool
fill 536 279 285 538 279 285 minecraft:snow_block
setblock 536 279 288 minecraft:white_wool
fill 536 279 289 542 279 289 minecraft:white_concrete
fill 536 279 290 543 279 290 minecraft:orange_terracotta
fill 536 279 292 542 279 292 minecraft:orange_terracotta
schedule function dropper:buildpart/71_7 1t
