setblock 505 293 416 minecraft:orange_concrete
fill 512 293 425 512 296 426 minecraft:netherrack
setblock 512 293 430 minecraft:orange_concrete
setblock 512 293 441 minecraft:orange_concrete
fill 512 293 446 512 296 446 minecraft:netherrack
fill 512 293 457 512 296 457 minecraft:netherrack
setblock 512 293 458 minecraft:orange_concrete
fill 470 294 416 470 299 417 minecraft:netherrack
setblock 470 294 418 minecraft:orange_concrete
fill 470 294 420 470 299 420 minecraft:netherrack
fill 470 294 426 470 295 427 minecraft:orange_concrete
fill 470 294 428 470 299 429 minecraft:netherrack
fill 470 294 437 470 299 437 minecraft:netherrack
fill 470 294 438 470 294 439 minecraft:orange_concrete
fill 470 294 440 470 299 441 minecraft:netherrack
fill 470 294 446 470 295 447 minecraft:orange_concrete
fill 470 294 448 470 299 449 minecraft:netherrack
setblock 470 294 450 minecraft:orange_concrete
fill 470 294 458 471 295 458 minecraft:orange_concrete
fill 471 294 417 473 294 417 minecraft:red_nether_bricks
fill 471 294 419 471 294 421 minecraft:red_nether_bricks
fill 471 294 423 471 294 425 minecraft:red_nether_bricks
fill 471 294 427 471 294 429 minecraft:red_nether_bricks
fill 471 294 431 471 294 433 minecraft:red_nether_bricks
fill 471 294 435 471 294 437 minecraft:red_nether_bricks
fill 471 294 439 471 294 441 minecraft:red_nether_bricks
fill 471 294 443 471 294 445 minecraft:red_nether_bricks
fill 471 294 447 471 294 449 minecraft:red_nether_bricks
fill 471 294 451 471 294 453 minecraft:red_nether_bricks
fill 471 294 455 471 294 457 minecraft:red_nether_bricks
setblock 472 294 416 minecraft:orange_concrete
fill 472 294 458 473 299 458 minecraft:netherrack
fill 473 294 416 474 299 416 minecraft:netherrack
fill 473 294 457 475 294 457 minecraft:red_nether_bricks
fill 475 294 416 476 295 416 minecraft:orange_concrete
fill 475 294 417 477 294 417 minecraft:red_nether_bricks
fill 477 294 457 479 294 457 minecraft:red_nether_bricks
fill 479 294 417 481 294 417 minecraft:red_nether_bricks
fill 479 294 458 479 295 458 minecraft:orange_concrete
fill 481 294 416 482 299 416 minecraft:netherrack
fill 481 294 457 483 294 457 minecraft:red_nether_bricks
fill 481 294 458 481 299 458 minecraft:netherrack
fill 482 294 458 483 294 458 minecraft:orange_concrete
fill 483 294 416 484 294 416 minecraft:orange_concrete
fill 483 294 417 485 294 417 minecraft:red_nether_bricks
fill 484 294 458 484 299 458 minecraft:netherrack
fill 485 294 416 485 295 416 minecraft:netherrack
fill 485 294 457 487 294 457 minecraft:red_nether_bricks
fill 487 294 417 489 294 417 minecraft:red_nether_bricks
fill 489 294 457 491 294 457 minecraft:red_nether_bricks
fill 490 294 458 491 295 458 minecraft:orange_concrete
fill 491 294 417 493 294 417 minecraft:red_nether_bricks
fill 492 294 458 493 299 458 minecraft:netherrack
fill 493 294 416 494 299 416 minecraft:netherrack
fill 493 294 457 495 294 457 minecraft:red_nether_bricks
fill 495 294 416 496 295 416 minecraft:orange_concrete
fill 495 294 417 497 294 417 minecraft:red_nether_bricks
fill 497 294 457 499 294 457 minecraft:red_nether_bricks
fill 499 294 417 501 294 417 minecraft:red_nether_bricks
fill 501 294 457 503 294 457 minecraft:red_nether_bricks
fill 502 294 416 502 299 416 minecraft:netherrack
fill 502 294 458 503 294 458 minecraft:orange_concrete
fill 503 294 416 504 294 416 minecraft:orange_concrete
fill 503 294 417 505 294 417 minecraft:red_nether_bricks
fill 504 294 458 505 299 458 minecraft:netherrack
fill 505 294 416 505 299 416 minecraft:netherrack
fill 505 294 457 507 294 457 minecraft:red_nether_bricks
fill 507 294 416 507 295 416 minecraft:orange_concrete
fill 507 294 417 509 294 417 minecraft:red_nether_bricks
fill 509 294 457 511 294 457 minecraft:red_nether_bricks
fill 511 294 417 511 294 419 minecraft:red_nether_bricks
fill 511 294 421 511 294 423 minecraft:red_nether_bricks
fill 511 294 425 511 294 427 minecraft:red_nether_bricks
fill 511 294 429 511 294 431 minecraft:red_nether_bricks
fill 511 294 433 511 294 435 minecraft:red_nether_bricks
fill 511 294 437 511 294 439 minecraft:red_nether_bricks
fill 511 294 441 511 294 443 minecraft:red_nether_bricks
fill 511 294 445 511 294 447 minecraft:red_nether_bricks
fill 511 294 449 511 294 451 minecraft:red_nether_bricks
fill 511 294 453 511 294 455 minecraft:red_nether_bricks
fill 511 294 458 511 295 458 minecraft:orange_concrete
fill 512 294 417 512 299 418 minecraft:netherrack
fill 512 294 419 512 295 420 minecraft:orange_concrete
setblock 512 294 428 minecraft:orange_concrete
fill 512 294 429 512 299 430 minecraft:netherrack
fill 512 294 431 512 295 432 minecraft:orange_concrete
fill 512 294 437 512 299 438 minecraft:netherrack
fill 512 294 439 512 294 440 minecraft:orange_concrete
fill 512 294 441 512 299 441 minecraft:netherrack
fill 512 294 449 512 299 450 minecraft:netherrack
fill 512 294 451 512 295 452 minecraft:orange_concrete
fill 512 294 458 512 299 458 minecraft:netherrack
fill 470 295 418 470 298 418 minecraft:netherrack
fill 470 295 434 470 295 435 minecraft:orange_concrete
setblock 470 295 438 minecraft:orange_concrete
fill 470 295 439 470 298 439 minecraft:netherrack
fill 470 295 450 470 298 450 minecraft:netherrack
setblock 470 295 455 minecraft:orange_concrete
fill 472 295 416 472 298 416 minecraft:netherrack
setblock 478 295 458 minecraft:orange_concrete
fill 482 295 458 483 298 458 minecraft:netherrack
fill 483 295 416 483 298 416 minecraft:netherrack
setblock 484 295 416 minecraft:orange_concrete
fill 487 295 416 488 295 416 minecraft:orange_concrete
setblock 499 295 458 minecraft:orange_concrete
fill 502 295 439 502 296 440 minecraft:netherrack
setblock 502 295 458 minecraft:orange_concrete
fill 503 295 416 504 298 416 minecraft:netherrack
fill 503 295 458 503 298 458 minecraft:netherrack
setblock 508 295 416 minecraft:orange_concrete
setblock 510 295 458 minecraft:orange_concrete
setblock 512 295 423 minecraft:orange_concrete
fill 512 295 428 512 298 428 minecraft:netherrack
fill 512 295 439 512 298 439 minecraft:netherrack
setblock 512 295 440 minecraft:orange_concrete
fill 512 295 443 512 295 444 minecraft:orange_concrete
fill 470 296 424 470 296 425 minecraft:orange_concrete
fill 470 296 426 470 307 427 minecraft:netherrack
fill 470 296 433 470 297 433 minecraft:orange_concrete
fill 470 296 434 470 307 435 minecraft:netherrack
setblock 470 296 436 minecraft:orange_concrete
fill 470 296 438 470 307 438 minecraft:netherrack
fill 470 296 444 470 297 445 minecraft:orange_concrete
fill 470 296 446 470 307 447 minecraft:netherrack
fill 470 296 455 470 307 455 minecraft:netherrack
fill 470 296 456 470 296 457 minecraft:orange_concrete
fill 470 296 458 471 307 458 minecraft:netherrack
setblock 473 296 419 minecraft:light[level=14]
setblock 473 296 427 minecraft:light[level=14]
setblock 473 296 435 minecraft:light[level=14]
setblock 473 296 443 minecraft:light[level=14]
setblock 473 296 451 minecraft:light[level=14]
fill 475 296 416 476 307 416 minecraft:netherrack
fill 476 296 458 477 297 458 minecraft:orange_concrete
fill 477 296 416 478 297 416 minecraft:orange_concrete
fill 478 296 458 479 307 458 minecraft:netherrack
setblock 480 296 458 minecraft:orange_concrete
setblock 481 296 419 minecraft:light[level=14]
setblock 481 296 427 minecraft:light[level=14]
setblock 481 296 435 minecraft:light[level=14]
setblock 481 296 443 minecraft:light[level=14]
setblock 481 296 451 minecraft:light[level=14]
fill 484 296 416 484 307 416 minecraft:netherrack
fill 485 296 416 486 296 416 minecraft:orange_concrete
fill 486 296 427 486 297 427 minecraft:shroomlight
fill 487 296 416 488 297 416 minecraft:netherrack
fill 488 296 458 489 297 458 minecraft:orange_concrete
fill 489 296 416 489 297 416 minecraft:orange_concrete
setblock 489 296 419 minecraft:light[level=14]
setblock 489 296 427 minecraft:light[level=14]
setblock 489 296 435 minecraft:light[level=14]
setblock 489 296 443 minecraft:light[level=14]
setblock 489 296 451 minecraft:light[level=14]
fill 490 296 458 491 307 458 minecraft:netherrack
fill 495 296 416 496 307 416 minecraft:netherrack
fill 497 296 416 498 297 416 minecraft:orange_concrete
setblock 497 296 419 minecraft:light[level=14]
setblock 497 296 427 minecraft:light[level=14]
setblock 497 296 435 minecraft:light[level=14]
setblock 497 296 443 minecraft:light[level=14]
setblock 497 296 451 minecraft:light[level=14]
fill 497 296 458 497 297 458 minecraft:orange_concrete
fill 499 296 458 499 307 458 minecraft:netherrack
fill 500 296 458 501 296 458 minecraft:orange_concrete
fill 502 296 458 502 307 458 minecraft:netherrack
setblock 505 296 419 minecraft:light[level=14]
setblock 505 296 427 minecraft:light[level=14]
setblock 505 296 435 minecraft:light[level=14]
setblock 505 296 443 minecraft:light[level=14]
setblock 505 296 451 minecraft:light[level=14]
setblock 506 296 416 minecraft:orange_concrete
fill 507 296 416 508 307 416 minecraft:netherrack
fill 508 296 458 509 297 458 minecraft:orange_concrete
fill 509 296 416 510 297 416 minecraft:orange_concrete
fill 510 296 458 511 307 458 minecraft:netherrack
fill 512 296 419 512 307 420 minecraft:netherrack
fill 512 296 421 512 296 422 minecraft:orange_concrete
fill 512 296 423 512 307 423 minecraft:netherrack
fill 512 296 431 512 307 432 minecraft:netherrack
fill 512 296 433 512 297 434 minecraft:orange_concrete
fill 512 296 440 512 307 440 minecraft:netherrack
setblock 512 296 442 minecraft:orange_concrete
fill 512 296 443 512 307 444 minecraft:netherrack
fill 512 296 445 512 297 445 minecraft:orange_concrete
fill 512 296 451 512 307 452 minecraft:netherrack
fill 512 296 453 512 296 454 minecraft:orange_concrete
setblock 470 297 421 minecraft:orange_concrete
setblock 470 297 424 minecraft:orange_concrete
fill 470 297 425 470 307 425 minecraft:netherrack
setblock 470 297 432 minecraft:orange_concrete
fill 470 297 436 470 307 436 minecraft:netherrack
fill 470 297 452 470 297 453 minecraft:orange_concrete
setblock 470 297 456 minecraft:orange_concrete
fill 470 297 457 470 307 457 minecraft:netherrack
fill 480 297 458 480 307 458 minecraft:netherrack
fill 485 297 416 486 299 416 minecraft:netherrack
setblock 485 297 458 minecraft:orange_concrete
setblock 490 297 416 minecraft:orange_concrete
fill 496 297 440 496 297 443 minecraft:orange_concrete
setblock 496 297 458 minecraft:orange_concrete
fill 497 297 440 499 297 440 minecraft:orange_concrete
fill 497 297 443 499 297 443 minecraft:orange_concrete
fill 499 297 441 499 299 442 minecraft:orange_concrete
fill 500 297 458 501 307 458 minecraft:netherrack
setblock 501 297 416 minecraft:orange_concrete
fill 506 297 416 506 307 416 minecraft:netherrack
fill 512 297 421 512 307 421 minecraft:netherrack
setblock 512 297 422 minecraft:orange_concrete
fill 512 297 425 512 297 426 minecraft:orange_concrete
fill 512 297 442 512 307 442 minecraft:netherrack
setblock 512 297 446 minecraft:orange_concrete
fill 512 297 453 512 307 453 minecraft:netherrack
setblock 512 297 454 minecraft:orange_concrete
setblock 512 297 457 minecraft:orange_concrete
fill 470 298 419 470 299 419 minecraft:orange_concrete
fill 470 298 421 470 307 421 minecraft:netherrack
fill 470 298 422 470 298 423 minecraft:orange_concrete
fill 470 298 424 470 307 424 minecraft:netherrack
fill 470 298 430 470 299 431 minecraft:orange_concrete
fill 470 298 432 470 307 433 minecraft:netherrack
fill 470 298 442 470 298 443 minecraft:orange_concrete
fill 470 298 444 470 307 445 minecraft:netherrack
fill 470 298 451 470 299 451 minecraft:orange_concrete
fill 470 298 452 470 307 453 minecraft:netherrack
setblock 470 298 454 minecraft:orange_concrete
fill 470 298 456 470 307 456 minecraft:netherrack
fill 471 298 416 471 299 416 minecraft:orange_concrete
fill 474 298 458 475 299 458 minecraft:orange_concrete
fill 476 298 458 477 307 458 minecraft:netherrack
fill 477 298 416 478 307 416 minecraft:netherrack
fill 479 298 416 480 299 416 minecraft:orange_concrete
fill 485 298 458 485 307 458 minecraft:netherrack
fill 486 298 458 487 298 458 minecraft:orange_concrete
fill 487 298 416 487 307 416 minecraft:netherrack
setblock 488 298 416 minecraft:orange_concrete
fill 488 298 458 489 307 458 minecraft:netherrack
fill 489 298 416 490 307 416 minecraft:netherrack
fill 491 298 416 492 299 416 minecraft:orange_concrete
fill 494 298 458 495 299 458 minecraft:orange_concrete
fill 496 298 441 496 298 442 minecraft:orange_concrete
fill 496 298 458 497 307 458 minecraft:netherrack
fill 497 298 416 498 307 416 minecraft:netherrack
fill 497 298 440 498 298 440 minecraft:orange_concrete
fill 497 298 443 498 299 443 minecraft:orange_concrete
setblock 498 298 458 minecraft:orange_concrete
fill 499 298 416 500 298 416 minecraft:orange_concrete
fill 501 298 416 501 307 416 minecraft:netherrack
fill 506 298 458 507 299 458 minecraft:orange_concrete
fill 508 298 458 509 307 458 minecraft:netherrack
fill 509 298 416 510 307 416 minecraft:netherrack
fill 511 298 416 512 299 416 minecraft:orange_concrete
fill 512 298 422 512 307 422 minecraft:netherrack
setblock 512 298 424 minecraft:orange_concrete
fill 512 298 425 512 307 426 minecraft:netherrack
fill 512 298 427 512 299 427 minecraft:orange_concrete
fill 512 298 433 512 307 434 minecraft:netherrack
fill 512 298 435 512 298 436 minecraft:orange_concrete
fill 512 298 445 512 307 446 minecraft:netherrack
fill 512 298 447 512 299 448 minecraft:orange_concrete
fill 512 298 454 512 307 454 minecraft:netherrack
fill 512 298 455 512 298 456 minecraft:orange_concrete
fill 512 298 457 512 307 457 minecraft:netherrack
setblock 470 299 418 minecraft:orange_concrete
fill 470 299 422 470 307 423 minecraft:netherrack
setblock 470 299 439 minecraft:orange_concrete
setblock 470 299 442 minecraft:orange_concrete
fill 470 299 443 470 307 443 minecraft:netherrack
setblock 470 299 450 minecraft:orange_concrete
fill 470 299 454 470 307 454 minecraft:netherrack
setblock 472 299 416 minecraft:orange_concrete
fill 482 299 458 483 299 458 minecraft:orange_concrete
setblock 483 299 416 minecraft:orange_concrete
setblock 486 299 458 minecraft:orange_concrete
fill 487 299 458 487 307 458 minecraft:netherrack
fill 488 299 416 488 307 416 minecraft:netherrack
fill 494 299 444 494 300 445 minecraft:netherrack
fill 498 299 458 498 307 458 minecraft:netherrack
fill 499 299 416 499 307 416 minecraft:netherrack
setblock 500 299 416 minecraft:orange_concrete
fill 503 299 416 504 299 416 minecraft:orange_concrete
setblock 503 299 458 minecraft:orange_concrete
fill 512 299 424 512 307 424 minecraft:netherrack
setblock 512 299 428 minecraft:orange_concrete
fill 512 299 435 512 307 435 minecraft:netherrack
setblock 512 299 436 minecraft:orange_concrete
setblock 512 299 439 minecraft:orange_concrete
fill 512 299 455 512 307 456 minecraft:netherrack
fill 470 300 416 470 300 417 minecraft:orange_concrete
fill 470 300 418 470 307 419 minecraft:netherrack
setblock 470 300 420 minecraft:orange_concrete
fill 470 300 428 470 300 429 minecraft:orange_concrete
fill 470 300 430 470 307 431 minecraft:netherrack
setblock 470 300 437 minecraft:orange_concrete
fill 470 300 439 470 307 439 minecraft:netherrack
fill 470 300 440 470 300 441 minecraft:orange_concrete
fill 470 300 442 470 307 442 minecraft:netherrack
fill 470 300 448 470 300 449 minecraft:orange_concrete
fill 470 300 450 470 307 451 minecraft:netherrack
fill 471 300 416 472 307 416 minecraft:netherrack
fill 471 300 417 473 300 417 minecraft:red_nether_bricks
fill 471 300 419 471 300 421 minecraft:red_nether_bricks
fill 471 300 423 471 300 425 minecraft:red_nether_bricks
fill 471 300 427 471 300 429 minecraft:red_nether_bricks
fill 471 300 431 471 300 433 minecraft:red_nether_bricks
fill 471 300 435 471 300 437 minecraft:red_nether_bricks
fill 471 300 439 471 300 441 minecraft:red_nether_bricks
fill 471 300 443 471 300 445 minecraft:red_nether_bricks
fill 471 300 447 471 300 449 minecraft:red_nether_bricks
fill 471 300 451 471 300 453 minecraft:red_nether_bricks
fill 471 300 455 471 300 457 minecraft:red_nether_bricks
fill 472 300 458 473 300 458 minecraft:orange_concrete
fill 473 300 416 474 300 416 minecraft:orange_concrete
fill 473 300 457 475 300 457 minecraft:red_nether_bricks
fill 474 300 458 475 307 458 minecraft:netherrack
fill 475 300 417 477 300 417 minecraft:red_nether_bricks
fill 477 300 457 479 300 457 minecraft:red_nether_bricks
fill 479 300 416 480 307 416 minecraft:netherrack
fill 479 300 417 481 300 417 minecraft:red_nether_bricks
fill 481 300 416 482 300 416 minecraft:orange_concrete
fill 481 300 457 483 300 457 minecraft:red_nether_bricks
setblock 481 300 458 minecraft:orange_concrete
fill 482 300 458 483 307 458 minecraft:netherrack
fill 483 300 416 483 307 416 minecraft:netherrack
fill 483 300 417 485 300 417 minecraft:red_nether_bricks
setblock 484 300 458 minecraft:orange_concrete
setblock 485 300 416 minecraft:orange_concrete
fill 485 300 457 487 300 457 minecraft:red_nether_bricks
fill 486 300 416 486 307 416 minecraft:netherrack
fill 486 300 458 486 307 458 minecraft:netherrack
fill 487 300 417 489 300 417 minecraft:red_nether_bricks
fill 489 300 457 491 300 457 minecraft:red_nether_bricks
fill 491 300 416 492 307 416 minecraft:netherrack
fill 491 300 417 493 300 417 minecraft:red_nether_bricks
fill 492 300 458 493 300 458 minecraft:orange_concrete
fill 493 300 416 494 300 416 minecraft:orange_concrete
fill 493 300 457 495 300 457 minecraft:red_nether_bricks
fill 494 300 458 495 307 458 minecraft:netherrack
fill 495 300 417 497 300 417 minecraft:red_nether_bricks
fill 497 300 457 499 300 457 minecraft:red_nether_bricks
fill 499 300 417 501 300 417 minecraft:red_nether_bricks
fill 500 300 416 500 307 416 minecraft:netherrack
fill 501 300 457 503 300 457 minecraft:red_nether_bricks
setblock 502 300 416 minecraft:orange_concrete
fill 503 300 416 504 307 416 minecraft:netherrack
fill 503 300 417 505 300 417 minecraft:red_nether_bricks
fill 503 300 458 503 307 458 minecraft:netherrack
fill 504 300 458 505 300 458 minecraft:orange_concrete
setblock 505 300 416 minecraft:orange_concrete
fill 505 300 457 507 300 457 minecraft:red_nether_bricks
fill 506 300 458 507 307 458 minecraft:netherrack
fill 507 300 417 509 300 417 minecraft:red_nether_bricks
fill 509 300 457 511 300 457 minecraft:red_nether_bricks
fill 511 300 416 512 307 416 minecraft:netherrack
fill 511 300 417 511 300 419 minecraft:red_nether_bricks
fill 511 300 421 511 300 423 minecraft:red_nether_bricks
fill 511 300 425 511 300 427 minecraft:red_nether_bricks
fill 511 300 429 511 300 431 minecraft:red_nether_bricks
fill 511 300 433 511 300 435 minecraft:red_nether_bricks
fill 511 300 437 511 300 439 minecraft:red_nether_bricks
fill 511 300 441 511 300 443 minecraft:red_nether_bricks
fill 511 300 445 511 300 447 minecraft:red_nether_bricks
fill 511 300 449 511 300 451 minecraft:red_nether_bricks
fill 511 300 453 511 300 455 minecraft:red_nether_bricks
fill 512 300 417 512 300 418 minecraft:orange_concrete
fill 512 300 427 512 307 428 minecraft:netherrack
fill 512 300 429 512 300 430 minecraft:orange_concrete
fill 512 300 436 512 307 436 minecraft:netherrack
fill 512 300 437 512 300 438 minecraft:orange_concrete
fill 512 300 439 512 307 439 minecraft:netherrack
setblock 512 300 441 minecraft:orange_concrete
fill 512 300 447 512 307 448 minecraft:netherrack
fill 512 300 449 512 300 450 minecraft:orange_concrete
setblock 512 300 458 minecraft:orange_concrete
fill 470 301 416 470 307 417 minecraft:netherrack
fill 470 301 420 470 307 420 minecraft:netherrack
fill 470 301 428 470 307 429 minecraft:netherrack
fill 470 301 437 470 307 437 minecraft:netherrack
fill 470 301 440 470 307 441 minecraft:netherrack
fill 470 301 448 470 307 449 minecraft:netherrack
fill 472 301 458 473 307 458 minecraft:netherrack
fill 473 301 416 474 307 416 minecraft:netherrack
fill 481 301 416 482 307 416 minecraft:netherrack
fill 481 301 458 481 307 458 minecraft:netherrack
fill 484 301 458 484 307 458 minecraft:netherrack
fill 485 301 416 485 307 416 minecraft:netherrack
fill 492 301 458 493 307 458 minecraft:netherrack
fill 493 301 416 494 307 416 minecraft:netherrack
fill 502 301 416 502 307 416 minecraft:netherrack
fill 504 301 458 505 307 458 minecraft:netherrack
fill 505 301 416 505 307 416 minecraft:netherrack
fill 512 301 417 512 307 418 minecraft:netherrack
fill 512 301 429 512 307 430 minecraft:netherrack
fill 512 301 437 512 307 438 minecraft:netherrack
fill 512 301 441 512 307 441 minecraft:netherrack
fill 512 301 449 512 307 450 minecraft:netherrack
fill 512 301 458 512 307 458 minecraft:netherrack
