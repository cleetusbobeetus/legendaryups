setblock 362 257 417 minecraft:red_concrete
setblock 363 257 457 minecraft:red_concrete
setblock 369 257 417 minecraft:red_concrete
setblock 370 257 423 minecraft:red_concrete
setblock 370 257 430 minecraft:red_concrete
setblock 370 257 437 minecraft:red_concrete
setblock 370 257 444 minecraft:red_concrete
setblock 370 257 451 minecraft:red_concrete
setblock 370 257 457 minecraft:red_concrete
setblock 330 258 421 minecraft:red_concrete
setblock 330 258 428 minecraft:red_concrete
setblock 330 258 435 minecraft:red_concrete
setblock 330 258 442 minecraft:red_concrete
setblock 330 258 449 minecraft:red_concrete
setblock 330 258 456 minecraft:red_concrete
fill 332 258 438 334 258 440 minecraft:white_concrete
setblock 333 258 417 minecraft:red_concrete
setblock 336 258 457 minecraft:red_concrete
setblock 340 258 417 minecraft:red_concrete
setblock 343 258 457 minecraft:red_concrete
setblock 347 258 417 minecraft:red_concrete
setblock 350 258 457 minecraft:red_concrete
setblock 354 258 417 minecraft:red_concrete
setblock 357 258 457 minecraft:red_concrete
setblock 361 258 417 minecraft:red_concrete
setblock 364 258 457 minecraft:red_concrete
setblock 368 258 417 minecraft:red_concrete
setblock 370 258 422 minecraft:red_concrete
setblock 370 258 429 minecraft:red_concrete
setblock 370 258 436 minecraft:red_concrete
setblock 370 258 443 minecraft:red_concrete
setblock 370 258 450 minecraft:red_concrete
fill 345 259 446 347 260 446 minecraft:red_wool
fill 346 259 445 347 260 445 minecraft:red_wool
fill 330 260 417 330 260 421 minecraft:red_concrete
fill 330 260 423 330 260 428 minecraft:red_concrete
fill 330 260 430 330 260 435 minecraft:red_concrete
fill 330 260 437 330 260 442 minecraft:red_concrete
fill 330 260 444 330 260 449 minecraft:red_concrete
fill 330 260 451 330 260 456 minecraft:red_concrete
setblock 331 260 417 minecraft:red_concrete
fill 331 260 457 336 260 457 minecraft:red_concrete
fill 333 260 417 338 260 417 minecraft:red_concrete
fill 338 260 457 343 260 457 minecraft:red_concrete
fill 340 260 417 345 260 417 minecraft:red_concrete
fill 345 260 457 350 260 457 minecraft:red_concrete
fill 347 260 417 352 260 417 minecraft:red_concrete
fill 352 260 457 357 260 457 minecraft:red_concrete
fill 354 260 417 359 260 417 minecraft:red_concrete
fill 359 260 457 364 260 457 minecraft:red_concrete
fill 361 260 417 366 260 417 minecraft:red_concrete
fill 366 260 457 370 260 457 minecraft:red_concrete
fill 368 260 417 370 260 417 minecraft:red_concrete
fill 370 260 418 370 260 420 minecraft:red_concrete
fill 370 260 422 370 260 427 minecraft:red_concrete
fill 370 260 429 370 260 434 minecraft:red_concrete
fill 370 260 436 370 260 441 minecraft:red_concrete
fill 370 260 443 370 260 448 minecraft:red_concrete
fill 370 260 450 370 260 455 minecraft:red_concrete
setblock 330 261 417 minecraft:red_concrete
setblock 330 261 424 minecraft:red_concrete
setblock 330 261 431 minecraft:red_concrete
setblock 330 261 438 minecraft:red_concrete
setblock 330 261 445 minecraft:red_concrete
setblock 330 261 452 minecraft:red_concrete
setblock 332 261 457 minecraft:red_concrete
setblock 337 261 417 minecraft:red_concrete
setblock 339 261 457 minecraft:red_concrete
setblock 344 261 417 minecraft:red_concrete
setblock 346 261 457 minecraft:red_concrete
setblock 351 261 417 minecraft:red_concrete
setblock 353 261 457 minecraft:red_concrete
setblock 358 261 417 minecraft:red_concrete
setblock 360 261 457 minecraft:red_concrete
setblock 365 261 417 minecraft:red_concrete
setblock 367 261 457 minecraft:red_concrete
setblock 370 261 419 minecraft:red_concrete
setblock 370 261 426 minecraft:red_concrete
setblock 370 261 433 minecraft:red_concrete
setblock 370 261 440 minecraft:red_concrete
setblock 370 261 447 minecraft:red_concrete
setblock 370 261 454 minecraft:red_concrete
setblock 330 262 418 minecraft:red_concrete
setblock 330 262 425 minecraft:red_concrete
setblock 330 262 432 minecraft:red_concrete
setblock 330 262 439 minecraft:red_concrete
setblock 330 262 446 minecraft:red_concrete
setblock 330 262 453 minecraft:red_concrete
setblock 332 262 419 minecraft:light[level=12]
setblock 332 262 427 minecraft:light[level=12]
setblock 332 262 435 minecraft:light[level=12]
setblock 332 262 443 minecraft:light[level=12]
setblock 332 262 451 minecraft:light[level=12]
setblock 333 262 457 minecraft:red_concrete
setblock 336 262 417 minecraft:red_concrete
setblock 340 262 419 minecraft:light[level=12]
setblock 340 262 427 minecraft:light[level=12]
setblock 340 262 435 minecraft:light[level=12]
setblock 340 262 443 minecraft:light[level=12]
setblock 340 262 451 minecraft:light[level=12]
setblock 340 262 457 minecraft:red_concrete
setblock 343 262 417 minecraft:red_concrete
setblock 347 262 457 minecraft:red_concrete
setblock 348 262 419 minecraft:light[level=12]
setblock 348 262 427 minecraft:light[level=12]
setblock 348 262 435 minecraft:light[level=12]
setblock 348 262 443 minecraft:light[level=12]
setblock 348 262 451 minecraft:light[level=12]
setblock 350 262 417 minecraft:red_concrete
setblock 354 262 457 minecraft:red_concrete
setblock 356 262 419 minecraft:light[level=12]
setblock 356 262 427 minecraft:light[level=12]
setblock 356 262 435 minecraft:light[level=12]
setblock 356 262 443 minecraft:light[level=12]
setblock 356 262 451 minecraft:light[level=12]
setblock 357 262 417 minecraft:red_concrete
setblock 361 262 457 minecraft:red_concrete
setblock 364 262 417 minecraft:red_concrete
setblock 364 262 419 minecraft:light[level=12]
setblock 364 262 427 minecraft:light[level=12]
setblock 364 262 435 minecraft:light[level=12]
setblock 364 262 443 minecraft:light[level=12]
setblock 364 262 451 minecraft:light[level=12]
setblock 368 262 457 minecraft:red_concrete
setblock 370 262 418 minecraft:red_concrete
setblock 370 262 425 minecraft:red_concrete
setblock 370 262 432 minecraft:red_concrete
setblock 370 262 439 minecraft:red_concrete
setblock 370 262 446 minecraft:red_concrete
setblock 370 262 453 minecraft:red_concrete
setblock 330 263 419 minecraft:red_concrete
setblock 330 263 426 minecraft:red_concrete
setblock 330 263 433 minecraft:red_concrete
setblock 330 263 440 minecraft:red_concrete
setblock 330 263 447 minecraft:red_concrete
setblock 330 263 454 minecraft:red_concrete
setblock 334 263 457 minecraft:red_concrete
setblock 335 263 417 minecraft:red_concrete
setblock 341 263 457 minecraft:red_concrete
setblock 342 263 417 minecraft:red_concrete
setblock 348 263 457 minecraft:red_concrete
setblock 349 263 417 minecraft:red_concrete
setblock 355 263 457 minecraft:red_concrete
setblock 356 263 417 minecraft:red_concrete
setblock 362 263 457 minecraft:red_concrete
setblock 363 263 417 minecraft:red_concrete
setblock 369 263 457 minecraft:red_concrete
setblock 370 263 417 minecraft:red_concrete
setblock 370 263 424 minecraft:red_concrete
setblock 370 263 431 minecraft:red_concrete
setblock 370 263 438 minecraft:red_concrete
setblock 370 263 445 minecraft:red_concrete
setblock 370 263 452 minecraft:red_concrete
setblock 330 264 420 minecraft:red_concrete
setblock 330 264 427 minecraft:red_concrete
setblock 330 264 434 minecraft:red_concrete
setblock 330 264 441 minecraft:red_concrete
setblock 330 264 448 minecraft:red_concrete
setblock 330 264 455 minecraft:red_concrete
setblock 334 264 417 minecraft:red_concrete
setblock 335 264 457 minecraft:red_concrete
setblock 341 264 417 minecraft:red_concrete
setblock 342 264 457 minecraft:red_concrete
setblock 348 264 417 minecraft:red_concrete
setblock 349 264 457 minecraft:red_concrete
setblock 355 264 417 minecraft:red_concrete
setblock 356 264 457 minecraft:red_concrete
setblock 362 264 417 minecraft:red_concrete
setblock 363 264 457 minecraft:red_concrete
setblock 369 264 417 minecraft:red_concrete
setblock 370 264 423 minecraft:red_concrete
setblock 370 264 430 minecraft:red_concrete
setblock 370 264 437 minecraft:red_concrete
setblock 370 264 444 minecraft:red_concrete
setblock 370 264 451 minecraft:red_concrete
setblock 370 264 457 minecraft:red_concrete
setblock 330 265 421 minecraft:red_concrete
setblock 330 265 428 minecraft:red_concrete
setblock 330 265 435 minecraft:red_concrete
setblock 330 265 442 minecraft:red_concrete
setblock 330 265 449 minecraft:red_concrete
setblock 330 265 456 minecraft:red_concrete
setblock 333 265 417 minecraft:red_concrete
setblock 336 265 457 minecraft:red_concrete
setblock 340 265 417 minecraft:red_concrete
setblock 343 265 457 minecraft:red_concrete
setblock 347 265 417 minecraft:red_concrete
setblock 350 265 457 minecraft:red_concrete
fill 351 265 426 351 266 427 minecraft:yellow_wool
setblock 354 265 417 minecraft:red_concrete
setblock 357 265 457 minecraft:red_concrete
setblock 361 265 417 minecraft:red_concrete
setblock 364 265 457 minecraft:red_concrete
setblock 368 265 417 minecraft:red_concrete
setblock 370 265 422 minecraft:red_concrete
setblock 370 265 429 minecraft:red_concrete
setblock 370 265 436 minecraft:red_concrete
setblock 370 265 443 minecraft:red_concrete
setblock 370 265 450 minecraft:red_concrete
setblock 330 267 423 minecraft:red_concrete
setblock 330 267 430 minecraft:red_concrete
setblock 330 267 437 minecraft:red_concrete
setblock 330 267 444 minecraft:red_concrete
setblock 330 267 451 minecraft:red_concrete
setblock 331 267 417 minecraft:red_concrete
setblock 331 267 457 minecraft:red_concrete
setblock 338 267 417 minecraft:red_concrete
setblock 338 267 457 minecraft:red_concrete
setblock 345 267 417 minecraft:red_concrete
setblock 345 267 457 minecraft:red_concrete
setblock 352 267 417 minecraft:red_concrete
setblock 352 267 457 minecraft:red_concrete
setblock 359 267 417 minecraft:red_concrete
setblock 359 267 457 minecraft:red_concrete
setblock 366 267 417 minecraft:red_concrete
setblock 366 267 457 minecraft:red_concrete
setblock 370 267 420 minecraft:red_concrete
setblock 370 267 427 minecraft:red_concrete
setblock 370 267 434 minecraft:red_concrete
setblock 370 267 441 minecraft:red_concrete
setblock 370 267 448 minecraft:red_concrete
setblock 370 267 455 minecraft:red_concrete
setblock 330 268 417 minecraft:red_concrete
setblock 330 268 424 minecraft:red_concrete
setblock 330 268 431 minecraft:red_concrete
setblock 330 268 438 minecraft:red_concrete
setblock 330 268 445 minecraft:red_concrete
setblock 330 268 452 minecraft:red_concrete
setblock 332 268 457 minecraft:red_concrete
setblock 337 268 417 minecraft:red_concrete
setblock 339 268 457 minecraft:red_concrete
setblock 344 268 417 minecraft:red_concrete
setblock 346 268 457 minecraft:red_concrete
setblock 351 268 417 minecraft:red_concrete
setblock 353 268 457 minecraft:red_concrete
setblock 358 268 417 minecraft:red_concrete
setblock 360 268 457 minecraft:red_concrete
setblock 365 268 417 minecraft:red_concrete
setblock 367 268 457 minecraft:red_concrete
setblock 370 268 419 minecraft:red_concrete
setblock 370 268 426 minecraft:red_concrete
setblock 370 268 433 minecraft:red_concrete
setblock 370 268 440 minecraft:red_concrete
setblock 370 268 447 minecraft:red_concrete
setblock 370 268 454 minecraft:red_concrete
fill 330 269 418 330 270 418 minecraft:red_concrete
fill 330 269 425 330 270 425 minecraft:red_concrete
fill 330 269 432 330 270 432 minecraft:red_concrete
fill 330 269 439 330 270 439 minecraft:red_concrete
fill 330 269 446 330 270 446 minecraft:red_concrete
fill 330 269 453 330 270 453 minecraft:red_concrete
fill 333 269 457 333 270 457 minecraft:red_concrete
fill 336 269 417 336 270 417 minecraft:red_concrete
fill 340 269 457 340 270 457 minecraft:red_concrete
fill 343 269 417 343 270 417 minecraft:red_concrete
fill 347 269 457 347 270 457 minecraft:red_concrete
fill 350 269 417 350 270 417 minecraft:red_concrete
fill 354 269 457 354 270 457 minecraft:red_concrete
fill 357 269 417 357 270 417 minecraft:red_concrete
fill 361 269 457 361 270 457 minecraft:red_concrete
fill 364 269 417 364 270 417 minecraft:red_concrete
fill 368 269 457 368 270 457 minecraft:red_concrete
fill 370 269 418 370 270 418 minecraft:red_concrete
fill 370 269 425 370 270 425 minecraft:red_concrete
fill 370 269 432 370 270 432 minecraft:red_concrete
fill 370 269 439 370 270 439 minecraft:red_concrete
fill 370 269 446 370 270 446 minecraft:red_concrete
fill 370 269 453 370 270 453 minecraft:red_concrete
fill 330 270 417 331 270 417 minecraft:red_concrete
fill 330 270 419 330 270 421 minecraft:red_concrete
fill 330 270 423 330 270 424 minecraft:red_concrete
fill 330 270 426 330 270 428 minecraft:red_concrete
fill 330 270 430 330 270 431 minecraft:red_concrete
fill 330 270 433 330 270 435 minecraft:red_concrete
fill 330 270 437 330 270 438 minecraft:red_concrete
fill 330 270 440 330 270 442 minecraft:red_concrete
fill 330 270 444 330 270 445 minecraft:red_concrete
fill 330 270 447 330 270 449 minecraft:red_concrete
fill 330 270 451 330 270 452 minecraft:red_concrete
fill 330 270 454 330 270 456 minecraft:red_concrete
fill 331 270 457 332 270 457 minecraft:red_concrete
setblock 332 270 419 minecraft:light[level=12]
setblock 332 270 427 minecraft:light[level=12]
setblock 332 270 435 minecraft:light[level=12]
setblock 332 270 443 minecraft:light[level=12]
setblock 332 270 451 minecraft:light[level=12]
fill 333 270 417 335 270 417 minecraft:red_concrete
fill 334 270 457 336 270 457 minecraft:red_concrete
fill 337 270 417 338 270 417 minecraft:red_concrete
fill 338 270 457 339 270 457 minecraft:red_concrete
fill 340 270 417 342 270 417 minecraft:red_concrete
setblock 340 270 419 minecraft:light[level=12]
setblock 340 270 427 minecraft:light[level=12]
setblock 340 270 435 minecraft:light[level=12]
setblock 340 270 443 minecraft:light[level=12]
setblock 340 270 451 minecraft:light[level=12]
fill 341 270 457 343 270 457 minecraft:red_concrete
fill 344 270 417 345 270 417 minecraft:red_concrete
fill 345 270 457 346 270 457 minecraft:red_concrete
fill 347 270 417 349 270 417 minecraft:red_concrete
setblock 348 270 419 minecraft:light[level=12]
setblock 348 270 427 minecraft:light[level=12]
setblock 348 270 435 minecraft:light[level=12]
setblock 348 270 443 minecraft:light[level=12]
setblock 348 270 451 minecraft:light[level=12]
fill 348 270 457 350 270 457 minecraft:red_concrete
fill 351 270 417 352 270 417 minecraft:red_concrete
fill 352 270 457 353 270 457 minecraft:red_concrete
fill 354 270 417 356 270 417 minecraft:red_concrete
fill 355 270 457 357 270 457 minecraft:red_concrete
setblock 356 270 419 minecraft:light[level=12]
setblock 356 270 427 minecraft:light[level=12]
setblock 356 270 435 minecraft:light[level=12]
setblock 356 270 443 minecraft:light[level=12]
setblock 356 270 451 minecraft:light[level=12]
fill 358 270 417 359 270 417 minecraft:red_concrete
fill 359 270 457 360 270 457 minecraft:red_concrete
fill 361 270 417 363 270 417 minecraft:red_concrete
fill 362 270 457 364 270 457 minecraft:red_concrete
setblock 364 270 419 minecraft:light[level=12]
setblock 364 270 427 minecraft:light[level=12]
setblock 364 270 435 minecraft:light[level=12]
setblock 364 270 443 minecraft:light[level=12]
setblock 364 270 451 minecraft:light[level=12]
fill 365 270 417 366 270 417 minecraft:red_concrete
fill 366 270 457 367 270 457 minecraft:red_concrete
fill 368 270 417 370 270 417 minecraft:red_concrete
fill 369 270 457 370 270 457 minecraft:red_concrete
fill 370 270 419 370 270 420 minecraft:red_concrete
fill 370 270 422 370 270 424 minecraft:red_concrete
fill 370 270 426 370 270 427 minecraft:red_concrete
fill 370 270 429 370 270 431 minecraft:red_concrete
fill 370 270 433 370 270 434 minecraft:red_concrete
fill 370 270 436 370 270 438 minecraft:red_concrete
fill 370 270 440 370 270 441 minecraft:red_concrete
fill 370 270 443 370 270 445 minecraft:red_concrete
fill 370 270 447 370 270 448 minecraft:red_concrete
fill 370 270 450 370 270 452 minecraft:red_concrete
fill 370 270 454 370 270 455 minecraft:red_concrete
setblock 330 271 420 minecraft:red_concrete
setblock 330 271 427 minecraft:red_concrete
setblock 330 271 434 minecraft:red_concrete
setblock 330 271 441 minecraft:red_concrete
setblock 330 271 448 minecraft:red_concrete
setblock 330 271 455 minecraft:red_concrete
setblock 334 271 417 minecraft:red_concrete
setblock 335 271 457 minecraft:red_concrete
setblock 341 271 417 minecraft:red_concrete
setblock 342 271 457 minecraft:red_concrete
setblock 348 271 417 minecraft:red_concrete
setblock 349 271 457 minecraft:red_concrete
setblock 355 271 417 minecraft:red_concrete
setblock 356 271 457 minecraft:red_concrete
setblock 362 271 417 minecraft:red_concrete
setblock 363 271 457 minecraft:red_concrete
setblock 369 271 417 minecraft:red_concrete
setblock 370 271 423 minecraft:red_concrete
setblock 370 271 430 minecraft:red_concrete
setblock 370 271 437 minecraft:red_concrete
setblock 370 271 444 minecraft:red_concrete
setblock 370 271 451 minecraft:red_concrete
setblock 370 271 457 minecraft:red_concrete
setblock 330 272 421 minecraft:red_concrete
setblock 330 272 428 minecraft:red_concrete
setblock 330 272 435 minecraft:red_concrete
setblock 330 272 442 minecraft:red_concrete
setblock 330 272 449 minecraft:red_concrete
setblock 330 272 456 minecraft:red_concrete
setblock 333 272 417 minecraft:red_concrete
setblock 336 272 457 minecraft:red_concrete
setblock 340 272 417 minecraft:red_concrete
setblock 343 272 457 minecraft:red_concrete
setblock 347 272 417 minecraft:red_concrete
setblock 350 272 457 minecraft:red_concrete
setblock 354 272 417 minecraft:red_concrete
setblock 357 272 457 minecraft:red_concrete
fill 359 272 447 360 273 447 minecraft:yellow_wool
setblock 361 272 417 minecraft:red_concrete
setblock 364 272 457 minecraft:red_concrete
setblock 368 272 417 minecraft:red_concrete
setblock 370 272 422 minecraft:red_concrete
setblock 370 272 429 minecraft:red_concrete
setblock 370 272 436 minecraft:red_concrete
setblock 370 272 443 minecraft:red_concrete
setblock 370 272 450 minecraft:red_concrete
setblock 332 278 419 minecraft:light[level=12]
setblock 332 278 427 minecraft:light[level=12]
setblock 332 278 435 minecraft:light[level=12]
setblock 332 278 443 minecraft:light[level=12]
setblock 332 278 451 minecraft:light[level=12]
setblock 340 278 419 minecraft:light[level=12]
setblock 340 278 427 minecraft:light[level=12]
setblock 340 278 435 minecraft:light[level=12]
setblock 340 278 443 minecraft:light[level=12]
setblock 340 278 451 minecraft:light[level=12]
setblock 348 278 419 minecraft:light[level=12]
setblock 348 278 427 minecraft:light[level=12]
setblock 348 278 435 minecraft:light[level=12]
setblock 348 278 443 minecraft:light[level=12]
setblock 348 278 451 minecraft:light[level=12]
setblock 356 278 419 minecraft:light[level=12]
setblock 356 278 427 minecraft:light[level=12]
setblock 356 278 435 minecraft:light[level=12]
setblock 356 278 443 minecraft:light[level=12]
setblock 356 278 451 minecraft:light[level=12]
setblock 364 278 419 minecraft:light[level=12]
setblock 364 278 427 minecraft:light[level=12]
setblock 364 278 435 minecraft:light[level=12]
setblock 364 278 443 minecraft:light[level=12]
setblock 364 278 451 minecraft:light[level=12]
fill 330 279 425 348 279 449 minecraft:black_wool
fill 331 279 424 369 280 424 minecraft:black_wool
fill 331 279 450 369 280 450 minecraft:black_wool
fill 332 279 422 368 280 423 minecraft:black_wool
fill 332 279 451 368 280 452 minecraft:black_wool
fill 333 279 421 367 280 421 minecraft:black_wool
fill 333 279 453 367 280 453 minecraft:black_wool
fill 334 279 420 366 280 420 minecraft:black_wool
fill 334 279 454 366 280 454 minecraft:black_wool
fill 335 279 419 365 280 419 minecraft:black_wool
fill 335 279 455 365 280 455 minecraft:black_wool
fill 337 279 418 363 280 418 minecraft:black_wool
fill 337 279 456 363 280 456 minecraft:black_wool
fill 338 279 417 362 280 417 minecraft:black_wool
fill 338 279 457 362 280 457 minecraft:black_wool
fill 349 279 425 349 279 436 minecraft:black_wool
fill 349 279 437 349 279 440 minecraft:white_wool
fill 349 279 441 349 279 449 minecraft:black_wool
fill 350 279 425 370 279 435 minecraft:black_wool
fill 350 279 436 350 279 437 minecraft:white_wool
setblock 350 279 441 minecraft:white_wool
fill 350 279 442 350 279 449 minecraft:black_wool
fill 351 279 436 353 279 436 minecraft:white_wool
fill 351 279 442 353 279 442 minecraft:white_wool
fill 351 279 443 370 279 449 minecraft:black_wool
fill 354 279 436 370 279 436 minecraft:black_wool
setblock 354 279 437 minecraft:white_wool
setblock 354 279 441 minecraft:white_wool
fill 354 279 442 370 279 442 minecraft:black_wool
fill 355 279 437 370 279 437 minecraft:black_wool
fill 355 279 438 355 279 440 minecraft:white_wool
fill 355 279 441 370 279 441 minecraft:black_wool
fill 356 279 438 370 279 440 minecraft:black_wool
fill 330 280 417 330 280 457 minecraft:black_wool
fill 331 280 417 331 280 423 minecraft:black_wool
fill 331 280 425 346 280 449 minecraft:black_wool
fill 331 280 451 331 280 457 minecraft:black_wool
fill 332 280 417 332 280 421 minecraft:black_wool
fill 332 280 453 332 280 457 minecraft:black_wool
fill 333 280 417 333 280 420 minecraft:black_wool
fill 333 280 454 333 280 457 minecraft:black_wool
fill 334 280 417 334 280 419 minecraft:black_wool
fill 334 280 455 334 280 457 minecraft:black_wool
fill 335 280 417 336 280 418 minecraft:black_wool
fill 335 280 456 336 280 457 minecraft:black_wool
setblock 337 280 417 minecraft:black_wool
setblock 337 280 457 minecraft:black_wool
fill 347 280 425 347 280 436 minecraft:black_wool
fill 347 280 437 348 280 440 minecraft:red_wool
fill 347 280 441 347 280 449 minecraft:black_wool
fill 348 280 425 349 280 434 minecraft:black_wool
fill 348 280 435 349 280 436 minecraft:red_wool
fill 348 280 441 348 280 442 minecraft:red_wool
fill 348 280 443 348 280 449 minecraft:black_wool
fill 349 280 437 349 280 441 minecraft:jack_o_lantern
fill 349 280 442 349 280 443 minecraft:red_wool
fill 349 280 444 370 280 449 minecraft:black_wool
fill 350 280 425 370 280 433 minecraft:black_wool
fill 350 280 434 353 280 435 minecraft:red_wool
fill 350 280 436 350 280 437 minecraft:jack_o_lantern
fill 350 280 441 350 280 442 minecraft:jack_o_lantern
fill 350 280 443 354 280 443 minecraft:red_wool
fill 351 280 436 354 280 436 minecraft:jack_o_lantern
fill 351 280 442 354 280 442 minecraft:jack_o_lantern
fill 354 280 434 370 280 434 minecraft:black_wool
fill 354 280 435 355 280 435 minecraft:red_wool
fill 354 280 437 355 280 437 minecraft:jack_o_lantern
fill 354 280 441 355 280 441 minecraft:jack_o_lantern
fill 355 280 436 356 280 436 minecraft:red_wool
fill 355 280 438 355 280 440 minecraft:jack_o_lantern
setblock 355 280 442 minecraft:red_wool
fill 355 280 443 370 280 443 minecraft:black_wool
fill 356 280 435 370 280 435 minecraft:black_wool
fill 356 280 437 356 280 441 minecraft:red_wool
fill 356 280 442 370 280 442 minecraft:black_wool
fill 357 280 436 370 280 441 minecraft:black_wool
fill 363 280 417 370 280 417 minecraft:black_wool
fill 363 280 457 370 280 457 minecraft:black_wool
fill 364 280 418 370 280 418 minecraft:black_wool
fill 364 280 456 370 280 456 minecraft:black_wool
fill 366 280 419 370 280 419 minecraft:black_wool
fill 366 280 455 370 280 455 minecraft:black_wool
fill 367 280 420 370 280 420 minecraft:black_wool
fill 367 280 454 370 280 454 minecraft:black_wool
fill 368 280 421 370 280 421 minecraft:black_wool
fill 368 280 453 370 280 453 minecraft:black_wool
fill 369 280 422 370 280 423 minecraft:black_wool
fill 369 280 451 370 280 452 minecraft:black_wool
setblock 370 280 424 minecraft:black_wool
setblock 370 280 450 minecraft:black_wool
fill 330 281 428 344 281 446 minecraft:black_wool
fill 331 281 426 369 281 427 minecraft:black_wool
fill 331 281 447 369 281 448 minecraft:black_wool
fill 332 281 424 368 281 425 minecraft:black_wool
fill 332 281 449 368 281 450 minecraft:black_wool
fill 333 281 423 367 281 423 minecraft:black_wool
fill 333 281 451 367 281 451 minecraft:black_wool
fill 334 281 422 366 281 422 minecraft:black_wool
fill 334 281 452 366 281 452 minecraft:black_wool
fill 335 281 421 365 281 421 minecraft:black_wool
fill 335 281 453 365 281 453 minecraft:black_wool
fill 336 281 420 364 281 420 minecraft:black_wool
fill 336 281 454 364 281 454 minecraft:black_wool
fill 337 281 419 363 281 419 minecraft:black_wool
fill 337 281 455 363 281 455 minecraft:black_wool
fill 339 281 418 361 281 418 minecraft:black_wool
fill 339 281 456 361 281 456 minecraft:black_wool
fill 341 281 417 359 281 417 minecraft:black_wool
fill 341 281 457 359 281 457 minecraft:black_wool
fill 345 281 428 345 281 435 minecraft:black_wool
fill 345 281 436 346 281 440 minecraft:red_wool
fill 345 281 441 345 281 446 minecraft:black_wool
fill 346 281 428 346 281 434 minecraft:black_wool
fill 346 281 435 347 281 435 minecraft:red_wool
fill 346 281 441 347 281 442 minecraft:red_wool
fill 346 281 443 346 281 446 minecraft:black_wool
fill 347 281 428 347 281 433 minecraft:black_wool
fill 347 281 434 349 281 434 minecraft:red_wool
setblock 347 281 436 minecraft:red_wool
fill 347 281 443 348 281 443 minecraft:red_wool
fill 347 281 444 347 281 446 minecraft:black_wool
fill 348 281 428 348 281 432 minecraft:black_wool
fill 348 281 433 355 281 433 minecraft:red_wool
fill 348 281 444 354 281 444 minecraft:red_wool
fill 348 281 445 350 281 446 minecraft:black_wool
fill 349 281 428 370 281 431 minecraft:black_wool
fill 349 281 432 353 281 432 minecraft:red_wool
setblock 351 281 445 minecraft:red_wool
fill 351 281 446 370 281 446 minecraft:black_wool
fill 352 281 445 370 281 445 minecraft:black_wool
fill 354 281 432 370 281 432 minecraft:black_wool
fill 354 281 434 356 281 434 minecraft:red_wool
fill 355 281 443 356 281 443 minecraft:red_wool
fill 355 281 444 370 281 444 minecraft:black_wool
fill 356 281 433 370 281 433 minecraft:black_wool
fill 356 281 435 357 281 435 minecraft:red_wool
setblock 356 281 442 minecraft:red_wool
fill 357 281 434 370 281 434 minecraft:black_wool
fill 357 281 436 357 281 441 minecraft:red_wool
fill 357 281 442 370 281 443 minecraft:black_wool
fill 358 281 435 370 281 437 minecraft:black_wool
setblock 358 281 438 minecraft:red_wool
fill 358 281 439 370 281 441 minecraft:black_wool
fill 359 281 438 370 281 438 minecraft:black_wool
fill 330 282 429 342 282 445 minecraft:black_wool
fill 331 282 427 369 282 428 minecraft:black_wool
fill 331 282 446 348 282 447 minecraft:black_wool
fill 332 282 425 368 282 426 minecraft:black_wool
fill 332 282 448 368 282 449 minecraft:black_wool
fill 333 282 424 367 282 424 minecraft:black_wool
fill 333 282 450 367 282 450 minecraft:black_wool
fill 334 282 423 366 282 423 minecraft:black_wool
fill 334 282 451 366 282 451 minecraft:black_wool
fill 335 282 422 365 282 422 minecraft:black_wool
fill 335 282 452 365 282 452 minecraft:black_wool
fill 336 282 421 364 282 421 minecraft:black_wool
fill 336 282 453 364 282 453 minecraft:black_wool
fill 337 282 420 363 282 420 minecraft:black_wool
fill 337 282 454 363 282 454 minecraft:black_wool
fill 338 282 419 362 282 419 minecraft:black_wool
fill 338 282 455 362 282 455 minecraft:black_wool
fill 340 282 418 360 282 418 minecraft:black_wool
fill 340 282 456 360 282 456 minecraft:black_wool
fill 342 282 417 358 282 417 minecraft:black_wool
fill 342 282 457 358 282 457 minecraft:black_wool
fill 343 282 429 343 282 435 minecraft:black_wool
fill 343 282 436 344 282 440 minecraft:white_wool
fill 343 282 441 343 282 445 minecraft:black_wool
fill 344 282 429 344 282 433 minecraft:black_wool
fill 344 282 434 345 282 435 minecraft:white_wool
fill 344 282 441 345 282 442 minecraft:white_wool
fill 344 282 443 344 282 445 minecraft:black_wool
fill 345 282 429 345 282 432 minecraft:black_wool
fill 345 282 433 347 282 433 minecraft:white_wool
fill 345 282 443 346 282 443 minecraft:white_wool
fill 345 282 444 345 282 445 minecraft:black_wool
fill 346 282 429 346 282 431 minecraft:black_wool
fill 346 282 432 348 282 432 minecraft:white_wool
setblock 346 282 434 minecraft:white_wool
fill 346 282 444 347 282 444 minecraft:white_wool
setblock 346 282 445 minecraft:black_wool
fill 347 282 429 348 282 430 minecraft:black_wool
fill 347 282 431 355 282 431 minecraft:white_wool
fill 347 282 445 350 282 445 minecraft:white_wool
fill 349 282 429 370 282 429 minecraft:black_wool
fill 349 282 430 353 282 430 minecraft:white_wool
fill 349 282 446 353 282 446 minecraft:white_wool
fill 349 282 447 369 282 447 minecraft:black_wool
fill 352 282 445 355 282 445 minecraft:white_wool
fill 354 282 430 370 282 430 minecraft:black_wool
fill 354 282 432 356 282 432 minecraft:white_wool
fill 354 282 446 369 282 446 minecraft:black_wool
fill 355 282 444 356 282 444 minecraft:white_wool
fill 356 282 431 370 282 431 minecraft:black_wool
fill 356 282 433 357 282 433 minecraft:white_wool
fill 356 282 445 370 282 445 minecraft:black_wool
fill 357 282 432 370 282 432 minecraft:black_wool
fill 357 282 434 358 282 434 minecraft:white_wool
fill 357 282 442 357 282 443 minecraft:white_wool
fill 357 282 444 370 282 444 minecraft:black_wool
fill 358 282 433 370 282 433 minecraft:black_wool
fill 358 282 435 358 282 437 minecraft:white_wool
fill 358 282 439 358 282 442 minecraft:white_wool
fill 358 282 443 370 282 443 minecraft:black_wool
fill 359 282 434 370 282 435 minecraft:black_wool
fill 359 282 436 359 282 440 minecraft:white_wool
fill 359 282 441 370 282 442 minecraft:black_wool
fill 360 282 436 370 282 440 minecraft:black_wool
fill 330 283 432 340 283 442 minecraft:black_wool
fill 331 283 429 343 283 431 minecraft:black_wool
fill 331 283 443 342 283 445 minecraft:black_wool
fill 332 283 427 348 283 428 minecraft:black_wool
fill 332 283 446 345 283 447 minecraft:black_wool
fill 333 283 425 367 283 426 minecraft:black_wool
fill 333 283 448 367 283 449 minecraft:black_wool
fill 334 283 424 366 283 424 minecraft:black_wool
fill 334 283 450 366 283 450 minecraft:black_wool
fill 335 283 423 365 283 423 minecraft:black_wool
fill 335 283 451 365 283 451 minecraft:black_wool
fill 336 283 422 364 283 422 minecraft:black_wool
fill 336 283 452 364 283 452 minecraft:black_wool
fill 337 283 421 363 283 421 minecraft:black_wool
fill 337 283 453 363 283 453 minecraft:black_wool
fill 338 283 420 362 283 420 minecraft:black_wool
fill 338 283 454 362 283 454 minecraft:black_wool
fill 340 283 419 360 283 419 minecraft:black_wool
fill 340 283 455 360 283 455 minecraft:black_wool
fill 341 283 432 341 283 435 minecraft:black_wool
fill 341 283 436 342 283 439 minecraft:red_wool
fill 341 283 440 341 283 442 minecraft:black_wool
fill 342 283 418 358 283 418 minecraft:black_wool
setblock 342 283 432 minecraft:black_wool
fill 342 283 433 343 283 435 minecraft:red_wool
fill 342 283 440 342 283 442 minecraft:red_wool
fill 342 283 456 358 283 456 minecraft:black_wool
fill 343 283 432 345 283 432 minecraft:red_wool
fill 343 283 441 343 283 444 minecraft:red_wool
setblock 343 283 445 minecraft:black_wool
fill 344 283 429 344 283 430 minecraft:black_wool
fill 344 283 431 346 283 431 minecraft:red_wool
setblock 344 283 433 minecraft:red_wool
fill 344 283 443 344 283 445 minecraft:red_wool
fill 345 283 417 355 283 417 minecraft:black_wool
setblock 345 283 429 minecraft:black_wool
fill 345 283 430 348 283 430 minecraft:red_wool
fill 345 283 444 345 283 445 minecraft:red_wool
fill 345 283 457 355 283 457 minecraft:black_wool
fill 346 283 429 355 283 429 minecraft:red_wool
fill 346 283 445 346 283 446 minecraft:red_wool
fill 346 283 447 347 283 447 minecraft:black_wool
fill 347 283 446 348 283 446 minecraft:red_wool
fill 348 283 447 354 283 447 minecraft:red_wool
fill 349 283 427 368 283 427 minecraft:black_wool
fill 349 283 428 352 283 428 minecraft:red_wool
fill 353 283 428 368 283 428 minecraft:black_wool
fill 354 283 430 357 283 430 minecraft:red_wool
fill 354 283 446 356 283 446 minecraft:red_wool
fill 355 283 447 368 283 447 minecraft:black_wool
fill 356 283 429 369 283 429 minecraft:black_wool
fill 356 283 431 358 283 431 minecraft:red_wool
fill 356 283 445 357 283 445 minecraft:red_wool
fill 357 283 432 358 283 432 minecraft:red_wool
fill 357 283 444 358 283 444 minecraft:red_wool
fill 357 283 446 368 283 446 minecraft:black_wool
fill 358 283 430 369 283 430 minecraft:black_wool
fill 358 283 433 359 283 433 minecraft:red_wool
fill 358 283 443 359 283 443 minecraft:red_wool
fill 358 283 445 369 283 445 minecraft:black_wool
fill 359 283 431 369 283 432 minecraft:black_wool
fill 359 283 434 359 283 435 minecraft:red_wool
fill 359 283 441 359 283 442 minecraft:red_wool
fill 359 283 444 369 283 444 minecraft:black_wool
fill 360 283 433 370 283 434 minecraft:black_wool
fill 360 283 435 360 283 441 minecraft:red_wool
fill 360 283 442 369 283 443 minecraft:black_wool
fill 361 283 435 370 283 441 minecraft:black_wool
setblock 370 283 432 minecraft:black_wool
setblock 370 283 442 minecraft:black_wool
fill 330 284 417 330 284 426 minecraft:red_concrete
fill 330 284 429 330 300 429 minecraft:red_concrete
setblock 330 284 433 minecraft:red_concrete
fill 330 284 436 330 300 436 minecraft:red_concrete
setblock 330 284 440 minecraft:red_concrete
fill 330 284 443 330 300 443 minecraft:red_concrete
setblock 330 284 447 minecraft:red_concrete
fill 330 284 450 330 300 450 minecraft:red_concrete
setblock 330 284 454 minecraft:red_concrete
fill 330 284 457 330 300 457 minecraft:red_concrete
fill 331 284 417 334 300 425 minecraft:red_concrete
fill 331 284 431 338 284 443 minecraft:black_wool
fill 332 284 429 341 284 430 minecraft:black_wool
fill 332 284 444 340 284 445 minecraft:black_wool
fill 333 284 427 343 284 428 minecraft:black_wool
fill 333 284 446 342 284 447 minecraft:black_wool
fill 334 284 426 348 284 426 minecraft:black_wool
fill 334 284 448 345 284 448 minecraft:black_wool
setblock 334 284 457 minecraft:red_concrete
fill 335 284 417 335 300 423 minecraft:red_concrete
fill 335 284 424 365 284 425 minecraft:black_wool
fill 335 284 449 365 284 450 minecraft:black_wool
fill 336 284 417 336 285 422 minecraft:red_concrete
fill 336 284 423 364 284 423 minecraft:black_wool
fill 336 284 451 364 284 451 minecraft:black_wool
fill 337 284 417 338 285 421 minecraft:red_concrete
fill 337 284 422 363 284 422 minecraft:black_wool
fill 337 284 452 363 284 452 minecraft:black_wool
fill 337 284 457 337 300 457 minecraft:red_concrete
fill 339 284 417 339 285 420 minecraft:red_concrete
fill 339 284 421 361 284 421 minecraft:black_wool
fill 339 284 431 339 284 435 minecraft:black_wool
fill 339 284 436 340 284 439 minecraft:red_wool
fill 339 284 440 339 284 443 minecraft:black_wool
fill 339 284 453 361 284 453 minecraft:black_wool
fill 340 284 417 341 285 419 minecraft:red_concrete
fill 340 284 420 360 284 420 minecraft:black_wool
fill 340 284 431 340 284 432 minecraft:black_wool
fill 340 284 433 341 284 435 minecraft:red_wool
fill 340 284 440 341 284 442 minecraft:red_wool
setblock 340 284 443 minecraft:black_wool
fill 340 284 454 360 284 454 minecraft:black_wool
fill 341 284 431 342 284 432 minecraft:red_wool
fill 341 284 443 342 284 444 minecraft:red_wool
setblock 341 284 445 minecraft:black_wool
setblock 341 284 457 minecraft:red_concrete
fill 342 284 417 343 285 418 minecraft:red_concrete
fill 342 284 419 358 284 419 minecraft:black_wool
setblock 342 284 429 minecraft:black_wool
fill 342 284 430 344 284 430 minecraft:red_wool
fill 342 284 445 343 284 445 minecraft:red_wool
fill 342 284 455 358 284 455 minecraft:black_wool
fill 343 284 429 345 284 429 minecraft:red_wool
setblock 343 284 431 minecraft:red_wool
fill 343 284 446 345 284 446 minecraft:red_wool
setblock 343 284 447 minecraft:black_wool
fill 344 284 417 344 285 417 minecraft:red_concrete
fill 344 284 418 356 284 418 minecraft:black_wool
fill 344 284 427 345 284 427 minecraft:black_wool
fill 344 284 428 348 284 428 minecraft:red_wool
fill 344 284 447 347 284 447 minecraft:red_wool
fill 344 284 456 356 284 456 minecraft:black_wool
fill 344 284 457 344 300 457 minecraft:red_concrete
fill 346 284 417 346 300 417 minecraft:red_concrete
fill 346 284 427 355 284 427 minecraft:red_wool
fill 346 284 448 355 284 448 minecraft:red_wool
setblock 348 284 457 minecraft:red_concrete
setblock 349 284 417 minecraft:red_concrete
fill 349 284 426 352 284 426 minecraft:red_wool
fill 351 284 457 351 300 457 minecraft:red_concrete
fill 353 284 417 353 300 417 minecraft:red_concrete
fill 353 284 426 366 284 426 minecraft:black_wool
fill 353 284 428 357 284 428 minecraft:red_wool
fill 355 284 447 356 284 447 minecraft:red_wool
setblock 355 284 457 minecraft:red_concrete
setblock 356 284 417 minecraft:red_concrete
fill 356 284 427 367 284 427 minecraft:black_wool
fill 356 284 429 358 284 429 minecraft:red_wool
fill 356 284 448 366 284 448 minecraft:black_wool
fill 357 284 446 358 284 446 minecraft:red_wool
fill 357 284 447 367 284 447 minecraft:black_wool
fill 358 284 428 367 284 428 minecraft:black_wool
fill 358 284 430 359 284 430 minecraft:red_wool
fill 358 284 445 359 284 445 minecraft:red_wool
fill 358 284 457 358 300 457 minecraft:red_concrete
fill 359 284 429 368 284 429 minecraft:black_wool
fill 359 284 431 360 284 432 minecraft:red_wool
setblock 359 284 444 minecraft:red_wool
fill 359 284 446 367 284 446 minecraft:black_wool
fill 359 284 455 362 295 455 minecraft:red_wool
fill 360 284 417 360 300 417 minecraft:red_concrete
fill 360 284 430 368 284 430 minecraft:black_wool
fill 360 284 433 361 284 434 minecraft:red_wool
fill 360 284 442 360 284 443 minecraft:red_wool
fill 360 284 444 368 284 445 minecraft:black_wool
fill 361 284 431 369 284 432 minecraft:black_wool
fill 361 284 435 361 284 442 minecraft:red_wool
fill 361 284 443 369 284 443 minecraft:black_wool
fill 362 284 433 369 284 442 minecraft:black_wool
setblock 362 284 457 minecraft:red_concrete
setblock 363 284 417 minecraft:red_concrete
fill 365 284 457 365 300 457 minecraft:red_concrete
fill 367 284 417 367 300 417 minecraft:red_concrete
setblock 369 284 457 minecraft:red_concrete
setblock 370 284 417 minecraft:red_concrete
fill 370 284 421 370 300 421 minecraft:red_concrete
setblock 370 284 424 minecraft:red_concrete
fill 370 284 428 370 300 428 minecraft:red_concrete
setblock 370 284 431 minecraft:red_concrete
fill 370 284 435 370 300 435 minecraft:red_concrete
setblock 370 284 438 minecraft:red_concrete
fill 370 284 442 370 300 442 minecraft:red_concrete
setblock 370 284 445 minecraft:red_concrete
fill 370 284 449 370 300 449 minecraft:red_concrete
setblock 370 284 452 minecraft:red_concrete
fill 370 284 456 370 300 456 minecraft:red_concrete
fill 330 285 417 330 300 425 minecraft:red_concrete
setblock 330 285 427 minecraft:red_concrete
setblock 330 285 434 minecraft:red_concrete
setblock 330 285 441 minecraft:red_concrete
setblock 330 285 448 minecraft:red_concrete
setblock 330 285 455 minecraft:red_concrete
fill 332 285 432 336 285 442 minecraft:black_wool
fill 333 285 429 338 285 431 minecraft:black_wool
fill 333 285 443 338 285 445 minecraft:black_wool
fill 334 285 428 340 285 428 minecraft:black_wool
fill 334 285 446 340 285 446 minecraft:black_wool
fill 335 285 424 335 300 425 minecraft:red_concrete
fill 335 285 426 341 285 427 minecraft:black_wool
fill 335 285 447 341 285 448 minecraft:black_wool
setblock 335 285 457 minecraft:red_concrete
fill 336 285 423 336 285 424 minecraft:red_concrete
fill 336 285 425 344 285 425 minecraft:black_wool
fill 336 285 449 344 285 449 minecraft:black_wool
fill 337 285 422 337 285 423 minecraft:red_concrete
fill 337 285 424 348 285 424 minecraft:black_wool
fill 337 285 432 337 285 435 minecraft:black_wool
fill 337 285 436 338 285 438 minecraft:white_wool
fill 337 285 439 337 285 442 minecraft:black_wool
fill 337 285 450 347 285 450 minecraft:black_wool
fill 338 285 422 338 300 422 minecraft:red_concrete
fill 338 285 423 362 285 423 minecraft:black_wool
fill 338 285 432 339 285 435 minecraft:white_wool
fill 338 285 439 338 285 442 minecraft:white_wool
fill 338 285 451 362 285 451 minecraft:black_wool
fill 339 285 421 340 285 421 minecraft:red_concrete
fill 339 285 422 361 285 422 minecraft:black_wool
fill 339 285 429 339 285 430 minecraft:black_wool
fill 339 285 431 340 285 431 minecraft:white_wool
fill 339 285 440 339 285 444 minecraft:white_wool
setblock 339 285 445 minecraft:black_wool
fill 339 285 452 361 285 452 minecraft:black_wool
fill 340 285 420 341 285 420 minecraft:red_concrete
fill 340 285 429 341 285 430 minecraft:white_wool
setblock 340 285 432 minecraft:white_wool
fill 340 285 443 340 285 445 minecraft:white_wool
fill 341 285 421 359 285 421 minecraft:black_wool
fill 341 285 428 343 285 428 minecraft:white_wool
fill 341 285 445 341 285 446 minecraft:white_wool
fill 341 285 453 359 285 453 minecraft:black_wool
fill 342 285 419 344 285 419 minecraft:red_concrete
fill 342 285 420 358 285 420 minecraft:black_wool
fill 342 285 426 343 285 426 minecraft:black_wool
fill 342 285 427 345 285 427 minecraft:white_wool
setblock 342 285 429 minecraft:white_wool
fill 342 285 446 342 285 447 minecraft:white_wool
setblock 342 285 448 minecraft:black_wool
fill 342 285 454 358 285 454 minecraft:black_wool
setblock 342 285 457 minecraft:red_concrete
fill 343 285 447 343 285 448 minecraft:white_wool
fill 344 285 418 344 300 418 minecraft:red_concrete
fill 344 285 426 348 285 426 minecraft:white_wool
fill 344 285 448 345 285 448 minecraft:white_wool
fill 345 285 419 355 285 419 minecraft:black_wool
fill 345 285 425 355 285 425 minecraft:white_wool
fill 345 285 449 355 285 449 minecraft:white_wool
fill 345 285 455 355 285 455 minecraft:black_wool
setblock 348 285 417 minecraft:red_concrete
fill 348 285 450 353 285 450 minecraft:white_wool
fill 349 285 424 351 285 424 minecraft:white_wool
setblock 349 285 457 minecraft:red_concrete
fill 352 285 424 363 285 424 minecraft:black_wool
fill 353 285 426 357 285 426 minecraft:white_wool
fill 354 285 450 363 285 450 minecraft:black_wool
setblock 355 285 417 minecraft:red_concrete
fill 356 285 425 364 285 425 minecraft:black_wool
fill 356 285 427 358 285 427 minecraft:white_wool
fill 356 285 448 357 285 448 minecraft:white_wool
fill 356 285 449 364 285 449 minecraft:black_wool
setblock 356 285 457 minecraft:red_concrete
fill 357 285 447 358 285 447 minecraft:white_wool
fill 358 285 426 365 285 426 minecraft:black_wool
fill 358 285 428 359 285 428 minecraft:white_wool
fill 358 285 448 365 285 448 minecraft:black_wool
fill 358 285 455 358 295 455 minecraft:red_wool
fill 359 285 427 365 285 427 minecraft:black_wool
fill 359 285 429 360 285 429 minecraft:white_wool
setblock 359 285 446 minecraft:white_wool
fill 359 285 447 365 285 447 minecraft:black_wool
fill 360 285 428 366 285 428 minecraft:black_wool
fill 360 285 430 361 285 430 minecraft:white_wool
fill 360 285 444 360 285 445 minecraft:white_wool
fill 360 285 446 366 285 446 minecraft:black_wool
fill 361 285 429 367 285 429 minecraft:black_wool
fill 361 285 431 361 285 432 minecraft:white_wool
fill 361 285 443 361 285 444 minecraft:white_wool
fill 361 285 445 367 285 445 minecraft:black_wool
setblock 362 285 417 minecraft:red_concrete
fill 362 285 430 367 285 431 minecraft:black_wool
fill 362 285 432 362 285 442 minecraft:white_wool
fill 362 285 443 367 285 444 minecraft:black_wool
fill 363 285 432 368 285 434 minecraft:black_wool
fill 363 285 435 363 285 440 minecraft:white_wool
fill 363 285 441 368 285 442 minecraft:black_wool
setblock 363 285 457 minecraft:red_concrete
fill 364 285 435 368 285 440 minecraft:black_wool
setblock 369 285 417 minecraft:red_concrete
setblock 370 285 423 minecraft:red_concrete
setblock 370 285 430 minecraft:red_concrete
setblock 370 285 437 minecraft:red_concrete
setblock 370 285 444 minecraft:red_concrete
setblock 370 285 451 minecraft:red_concrete
setblock 370 285 457 minecraft:red_concrete
setblock 330 286 428 minecraft:red_concrete
setblock 330 286 435 minecraft:red_concrete
setblock 330 286 442 minecraft:red_concrete
setblock 330 286 449 minecraft:red_concrete
setblock 330 286 456 minecraft:red_concrete
setblock 332 286 427 minecraft:light[level=12]
setblock 332 286 435 minecraft:light[level=12]
setblock 332 286 443 minecraft:light[level=12]
setblock 332 286 451 minecraft:light[level=12]
fill 333 286 435 335 286 439 minecraft:black_wool
fill 334 286 431 336 286 434 minecraft:black_wool
fill 334 286 440 336 286 443 minecraft:black_wool
fill 335 286 429 337 286 430 minecraft:black_wool
fill 335 286 444 337 286 445 minecraft:black_wool
setblock 336 286 417 minecraft:jack_o_lantern
fill 336 286 418 336 300 418 minecraft:red_concrete
setblock 336 286 419 minecraft:jack_o_lantern
fill 336 286 420 336 300 420 minecraft:red_concrete
setblock 336 286 421 minecraft:jack_o_lantern
fill 336 286 422 336 300 422 minecraft:red_concrete
setblock 336 286 423 minecraft:jack_o_lantern
fill 336 286 424 336 300 425 minecraft:red_concrete
fill 336 286 427 339 286 428 minecraft:black_wool
setblock 336 286 435 minecraft:black_wool
fill 336 286 436 336 286 438 minecraft:red_wool
setblock 336 286 439 minecraft:black_wool
fill 336 286 446 339 286 447 minecraft:black_wool
setblock 336 286 457 minecraft:red_concrete
fill 337 286 417 337 300 417 minecraft:red_concrete
setblock 337 286 418 minecraft:jack_o_lantern
fill 337 286 419 337 300 419 minecraft:red_concrete
setblock 337 286 420 minecraft:jack_o_lantern
fill 337 286 421 337 300 421 minecraft:red_concrete
setblock 337 286 422 minecraft:jack_o_lantern
fill 337 286 423 337 300 423 minecraft:red_concrete
fill 337 286 426 341 286 426 minecraft:black_wool
setblock 337 286 431 minecraft:black_wool
fill 337 286 432 337 286 435 minecraft:red_wool
fill 337 286 439 337 286 442 minecraft:red_wool
setblock 337 286 443 minecraft:black_wool
fill 337 286 448 341 286 448 minecraft:black_wool
setblock 338 286 417 minecraft:jack_o_lantern
fill 338 286 418 338 300 418 minecraft:red_concrete
setblock 338 286 419 minecraft:jack_o_lantern
fill 338 286 420 338 300 420 minecraft:red_concrete
setblock 338 286 421 minecraft:jack_o_lantern
setblock 338 286 423 minecraft:jack_o_lantern
fill 338 286 425 342 286 425 minecraft:black_wool
setblock 338 286 429 minecraft:black_wool
fill 338 286 430 338 286 431 minecraft:red_wool
fill 338 286 443 338 286 444 minecraft:red_wool
setblock 338 286 445 minecraft:black_wool
fill 338 286 449 342 286 449 minecraft:black_wool
fill 339 286 417 339 300 417 minecraft:red_concrete
setblock 339 286 418 minecraft:jack_o_lantern
fill 339 286 419 339 300 419 minecraft:red_concrete
setblock 339 286 420 minecraft:jack_o_lantern
fill 339 286 421 339 300 421 minecraft:red_concrete
setblock 339 286 422 minecraft:jack_o_lantern
fill 339 286 423 339 300 423 minecraft:red_concrete
fill 339 286 424 344 286 424 minecraft:black_wool
fill 339 286 429 339 286 430 minecraft:red_wool
setblock 339 286 445 minecraft:red_wool
fill 339 286 450 344 286 450 minecraft:black_wool
setblock 340 286 417 minecraft:jack_o_lantern
fill 340 286 418 340 300 418 minecraft:red_concrete
setblock 340 286 419 minecraft:jack_o_lantern
fill 340 286 420 340 300 420 minecraft:red_concrete
setblock 340 286 421 minecraft:jack_o_lantern
fill 340 286 422 340 300 422 minecraft:red_concrete
setblock 340 286 423 minecraft:jack_o_lantern
setblock 340 286 427 minecraft:black_wool
setblock 340 286 428 minecraft:red_wool
setblock 340 286 435 minecraft:light[level=12]
setblock 340 286 443 minecraft:light[level=12]
setblock 340 286 446 minecraft:red_wool
setblock 340 286 447 minecraft:black_wool
fill 340 286 451 347 286 451 minecraft:black_wool
fill 341 286 417 341 300 417 minecraft:red_concrete
setblock 341 286 418 minecraft:jack_o_lantern
fill 341 286 419 341 300 419 minecraft:red_concrete
setblock 341 286 420 minecraft:jack_o_lantern
fill 341 286 421 341 300 421 minecraft:red_concrete
setblock 341 286 422 minecraft:jack_o_lantern
setblock 341 286 423 minecraft:black_wool
setblock 341 286 427 minecraft:red_wool
setblock 341 286 447 minecraft:red_wool
setblock 342 286 417 minecraft:jack_o_lantern
fill 342 286 418 342 300 418 minecraft:red_concrete
setblock 342 286 419 minecraft:jack_o_lantern
fill 342 286 420 342 300 420 minecraft:red_concrete
setblock 342 286 421 minecraft:jack_o_lantern
setblock 342 286 422 minecraft:black_wool
setblock 342 286 423 minecraft:jack_o_lantern
fill 342 286 426 343 286 426 minecraft:red_wool
setblock 342 286 448 minecraft:red_wool
fill 342 286 452 358 286 452 minecraft:black_wool
fill 343 286 417 343 300 417 minecraft:red_concrete
setblock 343 286 418 minecraft:jack_o_lantern
fill 343 286 419 343 300 419 minecraft:red_concrete
setblock 343 286 420 minecraft:jack_o_lantern
fill 343 286 421 343 300 421 minecraft:red_concrete
setblock 343 286 422 minecraft:jack_o_lantern
setblock 343 286 423 minecraft:black_wool
fill 343 286 425 344 286 425 minecraft:red_wool
fill 343 286 449 344 286 449 minecraft:red_wool
setblock 343 286 457 minecraft:red_concrete
setblock 344 286 417 minecraft:jack_o_lantern
setblock 344 286 419 minecraft:jack_o_lantern
fill 344 286 420 344 300 420 minecraft:red_concrete
setblock 344 286 421 minecraft:jack_o_lantern
fill 344 286 422 358 286 422 minecraft:black_wool
setblock 344 286 423 minecraft:jack_o_lantern
fill 344 286 453 356 286 453 minecraft:black_wool
fill 345 286 421 356 286 421 minecraft:black_wool
fill 345 286 423 348 286 423 minecraft:black_wool
fill 345 286 424 348 286 424 minecraft:red_wool
fill 345 286 450 347 286 450 minecraft:red_wool
setblock 347 286 417 minecraft:red_concrete
setblock 348 286 419 minecraft:light[level=12]
fill 348 286 420 352 286 420 minecraft:black_wool
setblock 348 286 427 minecraft:light[level=12]
setblock 348 286 435 minecraft:light[level=12]
setblock 348 286 443 minecraft:light[level=12]
fill 348 286 451 353 286 451 minecraft:red_wool
fill 348 286 454 352 286 454 minecraft:black_wool
fill 349 286 423 351 286 423 minecraft:red_wool
setblock 350 286 457 minecraft:red_concrete
fill 352 286 423 360 286 423 minecraft:black_wool
fill 352 286 424 355 286 424 minecraft:red_wool
setblock 354 286 417 minecraft:red_concrete
fill 354 286 450 355 286 450 minecraft:red_wool
fill 354 286 451 360 286 451 minecraft:black_wool
setblock 356 286 419 minecraft:light[level=12]
fill 356 286 424 361 286 424 minecraft:black_wool
fill 356 286 425 357 286 425 minecraft:red_wool
setblock 356 286 427 minecraft:light[level=12]
setblock 356 286 435 minecraft:light[level=12]
setblock 356 286 443 minecraft:light[level=12]
fill 356 286 449 357 286 449 minecraft:red_wool
fill 356 286 450 361 286 450 minecraft:black_wool
setblock 357 286 457 minecraft:red_concrete
fill 358 286 425 362 286 425 minecraft:black_wool
setblock 358 286 426 minecraft:red_wool
setblock 358 286 448 minecraft:red_wool
fill 358 286 449 362 286 449 minecraft:black_wool
fill 359 286 426 363 286 426 minecraft:black_wool
setblock 359 286 427 minecraft:red_wool
setblock 359 286 447 minecraft:red_wool
fill 359 286 448 363 286 448 minecraft:black_wool
fill 360 286 427 364 286 427 minecraft:black_wool
setblock 360 286 428 minecraft:red_wool
setblock 360 286 446 minecraft:red_wool
fill 360 286 447 364 286 447 minecraft:black_wool
setblock 361 286 417 minecraft:red_concrete
fill 361 286 428 364 286 428 minecraft:black_wool
setblock 361 286 429 minecraft:red_wool
setblock 361 286 445 minecraft:red_wool
fill 361 286 446 364 286 446 minecraft:black_wool
fill 362 286 429 365 286 429 minecraft:black_wool
fill 362 286 430 362 286 431 minecraft:red_wool
fill 362 286 443 362 286 444 minecraft:red_wool
fill 362 286 445 365 286 445 minecraft:black_wool
fill 363 286 430 365 286 431 minecraft:black_wool
fill 363 286 432 363 286 434 minecraft:red_wool
fill 363 286 441 363 286 442 minecraft:red_wool
fill 363 286 443 365 286 444 minecraft:black_wool
setblock 364 286 419 minecraft:light[level=12]
fill 364 286 432 366 286 434 minecraft:black_wool
fill 364 286 435 364 286 440 minecraft:red_wool
fill 364 286 441 366 286 442 minecraft:black_wool
setblock 364 286 451 minecraft:light[level=12]
setblock 364 286 457 minecraft:red_concrete
fill 365 286 435 366 286 440 minecraft:black_wool
setblock 366 286 431 minecraft:black_wool
setblock 366 286 443 minecraft:black_wool
fill 367 286 430 367 287 432 minecraft:white_wool
fill 367 286 435 367 286 439 minecraft:black_wool
setblock 368 286 417 minecraft:red_concrete
fill 368 286 431 368 287 432 minecraft:white_wool
setblock 370 286 422 minecraft:red_concrete
setblock 370 286 429 minecraft:red_concrete
setblock 370 286 436 minecraft:red_concrete
setblock 370 286 443 minecraft:red_concrete
setblock 370 286 450 minecraft:red_concrete
fill 336 287 417 336 288 417 minecraft:red_concrete
fill 336 287 419 336 288 419 minecraft:red_concrete
fill 336 287 421 336 288 421 minecraft:red_concrete
fill 336 287 423 336 288 423 minecraft:red_concrete
fill 337 287 418 337 288 418 minecraft:red_concrete
fill 337 287 420 337 288 420 minecraft:red_concrete
fill 337 287 422 337 288 422 minecraft:red_concrete
fill 338 287 417 338 288 417 minecraft:red_concrete
fill 338 287 419 338 288 419 minecraft:red_concrete
fill 338 287 421 338 288 421 minecraft:red_concrete
fill 338 287 423 338 288 423 minecraft:red_concrete
fill 339 287 418 339 288 418 minecraft:red_concrete
fill 339 287 420 339 288 420 minecraft:red_concrete
fill 339 287 422 339 288 422 minecraft:red_concrete
fill 340 287 417 340 288 417 minecraft:red_concrete
fill 340 287 419 340 288 419 minecraft:red_concrete
fill 340 287 421 340 288 421 minecraft:red_concrete
fill 340 287 423 344 288 423 minecraft:red_concrete
fill 341 287 418 341 288 418 minecraft:red_concrete
fill 341 287 420 341 288 420 minecraft:red_concrete
fill 341 287 422 344 288 422 minecraft:red_concrete
fill 342 287 417 342 288 417 minecraft:red_concrete
fill 342 287 419 342 288 419 minecraft:red_concrete
fill 342 287 421 342 288 421 minecraft:red_concrete
fill 343 287 418 343 288 418 minecraft:red_concrete
fill 343 287 420 343 288 420 minecraft:red_concrete
fill 344 287 417 344 288 417 minecraft:red_concrete
fill 344 287 419 344 288 419 minecraft:red_concrete
fill 344 287 421 344 288 421 minecraft:red_concrete
setblock 330 288 430 minecraft:red_concrete
setblock 330 288 437 minecraft:red_concrete
setblock 330 288 444 minecraft:red_concrete
setblock 330 288 451 minecraft:red_concrete
setblock 331 288 457 minecraft:red_concrete
setblock 338 288 457 minecraft:red_concrete
setblock 345 288 417 minecraft:red_concrete
setblock 345 288 457 minecraft:red_concrete
setblock 352 288 417 minecraft:red_concrete
setblock 352 288 457 minecraft:red_concrete
setblock 359 288 417 minecraft:red_concrete
setblock 359 288 457 minecraft:red_concrete
setblock 366 288 417 minecraft:red_concrete
setblock 366 288 457 minecraft:red_concrete
setblock 370 288 420 minecraft:red_concrete
setblock 370 288 427 minecraft:red_concrete
setblock 370 288 434 minecraft:red_concrete
setblock 370 288 441 minecraft:red_concrete
setblock 370 288 448 minecraft:red_concrete
setblock 370 288 455 minecraft:red_concrete
fill 330 289 431 330 290 431 minecraft:red_concrete
fill 330 289 438 330 290 438 minecraft:red_concrete
fill 330 289 445 330 290 445 minecraft:red_concrete
fill 330 289 452 330 290 452 minecraft:red_concrete
fill 332 289 457 332 290 457 minecraft:red_concrete
setblock 336 289 417 minecraft:jack_o_lantern
setblock 336 289 419 minecraft:jack_o_lantern
setblock 336 289 421 minecraft:jack_o_lantern
setblock 336 289 423 minecraft:jack_o_lantern
setblock 337 289 418 minecraft:jack_o_lantern
setblock 337 289 420 minecraft:jack_o_lantern
setblock 337 289 422 minecraft:jack_o_lantern
setblock 338 289 417 minecraft:jack_o_lantern
setblock 338 289 419 minecraft:jack_o_lantern
setblock 338 289 421 minecraft:jack_o_lantern
setblock 338 289 423 minecraft:jack_o_lantern
setblock 339 289 418 minecraft:jack_o_lantern
setblock 339 289 420 minecraft:jack_o_lantern
setblock 339 289 422 minecraft:jack_o_lantern
fill 339 289 457 339 290 457 minecraft:red_concrete
setblock 340 289 417 minecraft:jack_o_lantern
setblock 340 289 419 minecraft:jack_o_lantern
setblock 340 289 421 minecraft:jack_o_lantern
setblock 340 289 423 minecraft:jack_o_lantern
setblock 341 289 418 minecraft:jack_o_lantern
setblock 341 289 420 minecraft:jack_o_lantern
setblock 341 289 422 minecraft:jack_o_lantern
fill 341 289 423 341 300 423 minecraft:red_concrete
setblock 342 289 417 minecraft:jack_o_lantern
setblock 342 289 419 minecraft:jack_o_lantern
setblock 342 289 421 minecraft:jack_o_lantern
fill 342 289 422 342 300 422 minecraft:red_concrete
setblock 342 289 423 minecraft:jack_o_lantern
setblock 343 289 418 minecraft:jack_o_lantern
setblock 343 289 420 minecraft:jack_o_lantern
setblock 343 289 422 minecraft:jack_o_lantern
fill 343 289 423 343 300 423 minecraft:red_concrete
setblock 344 289 417 minecraft:jack_o_lantern
setblock 344 289 419 minecraft:jack_o_lantern
setblock 344 289 421 minecraft:jack_o_lantern
fill 344 289 422 344 300 422 minecraft:red_concrete
setblock 344 289 423 minecraft:jack_o_lantern
fill 346 289 457 346 290 457 minecraft:red_concrete
fill 351 289 417 351 290 417 minecraft:red_concrete
fill 353 289 457 353 290 457 minecraft:red_concrete
fill 358 289 417 358 290 417 minecraft:red_concrete
fill 360 289 457 360 290 457 minecraft:red_concrete
fill 365 289 417 365 290 417 minecraft:red_concrete
fill 367 289 457 367 290 457 minecraft:red_concrete
fill 370 289 419 370 290 419 minecraft:red_concrete
fill 370 289 426 370 290 426 minecraft:red_concrete
fill 370 289 433 370 290 433 minecraft:red_concrete
fill 370 289 440 370 290 440 minecraft:red_concrete
fill 370 289 447 370 290 447 minecraft:red_concrete
fill 370 289 454 370 290 454 minecraft:red_concrete
fill 330 290 426 330 290 428 minecraft:red_concrete
setblock 330 290 430 minecraft:red_concrete
fill 330 290 432 330 290 435 minecraft:red_concrete
setblock 330 290 437 minecraft:red_concrete
fill 330 290 439 330 290 442 minecraft:red_concrete
setblock 330 290 444 minecraft:red_concrete
fill 330 290 446 330 290 449 minecraft:red_concrete
setblock 330 290 451 minecraft:red_concrete
fill 330 290 453 330 290 456 minecraft:red_concrete
setblock 331 290 457 minecraft:red_concrete
fill 333 290 457 336 290 457 minecraft:red_concrete
fill 336 290 417 336 291 417 minecraft:red_concrete
fill 336 290 419 336 291 419 minecraft:red_concrete
fill 336 290 421 336 291 421 minecraft:red_concrete
fill 336 290 423 336 291 423 minecraft:red_concrete
fill 337 290 418 337 291 418 minecraft:red_concrete
fill 337 290 420 337 291 420 minecraft:red_concrete
fill 337 290 422 337 291 422 minecraft:red_concrete
fill 338 290 417 338 291 417 minecraft:red_concrete
fill 338 290 419 338 291 419 minecraft:red_concrete
fill 338 290 421 338 291 421 minecraft:red_concrete
fill 338 290 423 338 291 423 minecraft:red_concrete
setblock 338 290 457 minecraft:red_concrete
fill 339 290 418 339 291 418 minecraft:red_concrete
fill 339 290 420 339 291 420 minecraft:red_concrete
fill 339 290 422 339 291 422 minecraft:red_concrete
fill 340 290 417 340 291 417 minecraft:red_concrete
fill 340 290 419 340 291 419 minecraft:red_concrete
fill 340 290 421 340 291 421 minecraft:red_concrete
fill 340 290 423 340 291 423 minecraft:red_concrete
fill 340 290 457 343 290 457 minecraft:red_concrete
fill 341 290 418 341 291 418 minecraft:red_concrete
fill 341 290 420 341 291 420 minecraft:red_concrete
fill 341 290 422 341 291 422 minecraft:red_concrete
fill 342 290 417 342 291 417 minecraft:red_concrete
fill 342 290 419 342 291 419 minecraft:red_concrete
fill 342 290 421 342 291 421 minecraft:red_concrete
fill 342 290 423 342 291 423 minecraft:red_concrete
fill 343 290 418 343 291 418 minecraft:red_concrete
fill 343 290 420 343 291 420 minecraft:red_concrete
fill 343 290 422 343 291 422 minecraft:red_concrete
fill 344 290 417 345 290 417 minecraft:red_concrete
fill 344 290 419 344 291 419 minecraft:red_concrete
fill 344 290 421 344 291 421 minecraft:red_concrete
fill 344 290 423 344 291 423 minecraft:red_concrete
fill 345 290 422 346 291 422 minecraft:red_wool
setblock 345 290 457 minecraft:red_concrete
fill 347 290 417 350 290 417 minecraft:red_concrete
fill 347 290 457 350 290 457 minecraft:red_concrete
setblock 352 290 417 minecraft:red_concrete
setblock 352 290 457 minecraft:red_concrete
fill 354 290 417 357 290 417 minecraft:red_concrete
fill 354 290 457 357 290 457 minecraft:red_concrete
setblock 359 290 417 minecraft:red_concrete
setblock 359 290 457 minecraft:red_concrete
fill 361 290 417 364 290 417 minecraft:red_concrete
fill 361 290 457 364 290 457 minecraft:red_concrete
setblock 366 290 417 minecraft:red_concrete
setblock 366 290 457 minecraft:red_concrete
fill 368 290 417 370 290 417 minecraft:red_concrete
fill 368 290 457 370 290 457 minecraft:red_concrete
setblock 370 290 418 minecraft:red_concrete
setblock 370 290 420 minecraft:red_concrete
fill 370 290 422 370 290 425 minecraft:red_concrete
setblock 370 290 427 minecraft:red_concrete
fill 370 290 429 370 290 432 minecraft:red_concrete
setblock 370 290 434 minecraft:red_concrete
fill 370 290 436 370 290 439 minecraft:red_concrete
setblock 370 290 441 minecraft:red_concrete
fill 370 290 443 370 290 446 minecraft:red_concrete
setblock 370 290 448 minecraft:red_concrete
fill 370 290 450 370 290 453 minecraft:red_concrete
setblock 370 290 455 minecraft:red_concrete
setblock 330 291 426 minecraft:red_concrete
setblock 330 291 433 minecraft:red_concrete
setblock 330 291 440 minecraft:red_concrete
setblock 330 291 447 minecraft:red_concrete
setblock 330 291 454 minecraft:red_concrete
setblock 334 291 457 minecraft:red_concrete
setblock 341 291 457 minecraft:red_concrete
setblock 344 291 417 minecraft:red_concrete
setblock 348 291 457 minecraft:red_concrete
setblock 349 291 417 minecraft:red_concrete
setblock 355 291 457 minecraft:red_concrete
setblock 356 291 417 minecraft:red_concrete
setblock 362 291 457 minecraft:red_concrete
setblock 363 291 417 minecraft:red_concrete
setblock 369 291 457 minecraft:red_concrete
setblock 370 291 417 minecraft:red_concrete
setblock 370 291 424 minecraft:red_concrete
setblock 370 291 431 minecraft:red_concrete
setblock 370 291 438 minecraft:red_concrete
setblock 370 291 445 minecraft:red_concrete
setblock 370 291 452 minecraft:red_concrete
setblock 330 292 427 minecraft:red_concrete
setblock 330 292 434 minecraft:red_concrete
setblock 330 292 441 minecraft:red_concrete
setblock 330 292 448 minecraft:red_concrete
setblock 330 292 455 minecraft:red_concrete
setblock 335 292 457 minecraft:red_concrete
setblock 336 292 417 minecraft:jack_o_lantern
setblock 336 292 419 minecraft:jack_o_lantern
setblock 336 292 421 minecraft:jack_o_lantern
setblock 336 292 423 minecraft:jack_o_lantern
setblock 337 292 418 minecraft:jack_o_lantern
setblock 337 292 420 minecraft:jack_o_lantern
setblock 337 292 422 minecraft:jack_o_lantern
setblock 338 292 417 minecraft:jack_o_lantern
setblock 338 292 419 minecraft:jack_o_lantern
setblock 338 292 421 minecraft:jack_o_lantern
setblock 338 292 423 minecraft:jack_o_lantern
setblock 339 292 418 minecraft:jack_o_lantern
setblock 339 292 420 minecraft:jack_o_lantern
setblock 339 292 422 minecraft:jack_o_lantern
setblock 340 292 417 minecraft:jack_o_lantern
setblock 340 292 419 minecraft:jack_o_lantern
setblock 340 292 421 minecraft:jack_o_lantern
setblock 340 292 423 minecraft:jack_o_lantern
setblock 341 292 418 minecraft:jack_o_lantern
setblock 341 292 420 minecraft:jack_o_lantern
setblock 341 292 422 minecraft:jack_o_lantern
setblock 342 292 417 minecraft:jack_o_lantern
setblock 342 292 419 minecraft:jack_o_lantern
setblock 342 292 421 minecraft:jack_o_lantern
setblock 342 292 423 minecraft:jack_o_lantern
setblock 342 292 457 minecraft:red_concrete
setblock 343 292 418 minecraft:jack_o_lantern
setblock 343 292 420 minecraft:jack_o_lantern
setblock 343 292 422 minecraft:jack_o_lantern
setblock 344 292 417 minecraft:jack_o_lantern
setblock 344 292 419 minecraft:jack_o_lantern
setblock 344 292 421 minecraft:jack_o_lantern
setblock 344 292 423 minecraft:jack_o_lantern
setblock 348 292 417 minecraft:red_concrete
setblock 349 292 457 minecraft:red_concrete
setblock 355 292 417 minecraft:red_concrete
setblock 356 292 457 minecraft:red_concrete
setblock 362 292 417 minecraft:red_concrete
setblock 363 292 457 minecraft:red_concrete
setblock 369 292 417 minecraft:red_concrete
setblock 370 292 423 minecraft:red_concrete
setblock 370 292 430 minecraft:red_concrete
setblock 370 292 437 minecraft:red_concrete
setblock 370 292 444 minecraft:red_concrete
setblock 370 292 451 minecraft:red_concrete
setblock 370 292 457 minecraft:red_concrete
setblock 330 293 428 minecraft:red_concrete
setblock 330 293 435 minecraft:red_concrete
setblock 330 293 442 minecraft:red_concrete
setblock 330 293 449 minecraft:red_concrete
setblock 330 293 456 minecraft:red_concrete
fill 336 293 417 336 294 417 minecraft:red_concrete
fill 336 293 419 336 294 419 minecraft:red_concrete
fill 336 293 421 336 294 421 minecraft:red_concrete
fill 336 293 423 336 294 423 minecraft:red_concrete
setblock 336 293 457 minecraft:red_concrete
fill 337 293 418 337 294 418 minecraft:red_concrete
fill 337 293 420 337 294 420 minecraft:red_concrete
fill 337 293 422 337 294 422 minecraft:red_concrete
fill 338 293 417 338 294 417 minecraft:red_concrete
fill 338 293 419 338 294 419 minecraft:red_concrete
fill 338 293 421 338 294 421 minecraft:red_concrete
fill 338 293 423 338 294 423 minecraft:red_concrete
fill 339 293 418 339 294 418 minecraft:red_concrete
fill 339 293 420 339 294 420 minecraft:red_concrete
fill 339 293 422 339 294 422 minecraft:red_concrete
fill 340 293 417 340 294 417 minecraft:red_concrete
fill 340 293 419 340 294 419 minecraft:red_concrete
fill 340 293 421 340 294 421 minecraft:red_concrete
fill 340 293 423 340 294 423 minecraft:red_concrete
fill 341 293 418 341 294 418 minecraft:red_concrete
fill 341 293 420 341 294 420 minecraft:red_concrete
fill 341 293 422 341 294 422 minecraft:red_concrete
fill 342 293 417 342 294 417 minecraft:red_concrete
fill 342 293 419 342 294 419 minecraft:red_concrete
fill 342 293 421 342 294 421 minecraft:red_concrete
fill 342 293 423 342 294 423 minecraft:red_concrete
fill 343 293 418 343 294 418 minecraft:red_concrete
fill 343 293 420 343 294 420 minecraft:red_concrete
fill 343 293 422 343 294 422 minecraft:red_concrete
setblock 343 293 457 minecraft:red_concrete
fill 344 293 417 344 294 417 minecraft:red_concrete
fill 344 293 419 344 294 419 minecraft:red_concrete
fill 344 293 421 344 294 421 minecraft:red_concrete
fill 344 293 423 344 294 423 minecraft:red_concrete
setblock 347 293 417 minecraft:red_concrete
setblock 350 293 457 minecraft:red_concrete
setblock 354 293 417 minecraft:red_concrete
setblock 357 293 457 minecraft:red_concrete
setblock 361 293 417 minecraft:red_concrete
setblock 364 293 457 minecraft:red_concrete
setblock 368 293 417 minecraft:red_concrete
setblock 370 293 422 minecraft:red_concrete
setblock 370 293 429 minecraft:red_concrete
setblock 370 293 436 minecraft:red_concrete
setblock 370 293 443 minecraft:red_concrete
setblock 370 293 450 minecraft:red_concrete
setblock 332 294 427 minecraft:light[level=12]
setblock 332 294 435 minecraft:light[level=12]
setblock 332 294 443 minecraft:light[level=12]
setblock 332 294 451 minecraft:light[level=12]
setblock 340 294 427 minecraft:light[level=12]
setblock 340 294 435 minecraft:light[level=12]
setblock 340 294 443 minecraft:light[level=12]
setblock 340 294 451 minecraft:light[level=12]
setblock 348 294 419 minecraft:light[level=12]
setblock 348 294 427 minecraft:light[level=12]
setblock 348 294 435 minecraft:light[level=12]
setblock 348 294 443 minecraft:light[level=12]
setblock 348 294 451 minecraft:light[level=12]
setblock 356 294 419 minecraft:light[level=12]
setblock 356 294 427 minecraft:light[level=12]
setblock 356 294 435 minecraft:light[level=12]
setblock 356 294 443 minecraft:light[level=12]
setblock 356 294 451 minecraft:light[level=12]
setblock 364 294 419 minecraft:light[level=12]
setblock 364 294 427 minecraft:light[level=12]
setblock 364 294 435 minecraft:light[level=12]
setblock 364 294 443 minecraft:light[level=12]
setblock 364 294 451 minecraft:light[level=12]
setblock 330 295 430 minecraft:red_concrete
setblock 330 295 437 minecraft:red_concrete
setblock 330 295 444 minecraft:red_concrete
setblock 330 295 451 minecraft:red_concrete
setblock 331 295 457 minecraft:red_concrete
setblock 336 295 417 minecraft:jack_o_lantern
setblock 336 295 419 minecraft:jack_o_lantern
setblock 336 295 421 minecraft:jack_o_lantern
setblock 336 295 423 minecraft:jack_o_lantern
setblock 337 295 418 minecraft:jack_o_lantern
setblock 337 295 420 minecraft:jack_o_lantern
setblock 337 295 422 minecraft:jack_o_lantern
setblock 338 295 417 minecraft:jack_o_lantern
setblock 338 295 419 minecraft:jack_o_lantern
setblock 338 295 421 minecraft:jack_o_lantern
setblock 338 295 423 minecraft:jack_o_lantern
setblock 338 295 457 minecraft:red_concrete
setblock 339 295 418 minecraft:jack_o_lantern
setblock 339 295 420 minecraft:jack_o_lantern
setblock 339 295 422 minecraft:jack_o_lantern
setblock 340 295 417 minecraft:jack_o_lantern
setblock 340 295 419 minecraft:jack_o_lantern
setblock 340 295 421 minecraft:jack_o_lantern
setblock 340 295 423 minecraft:jack_o_lantern
setblock 341 295 418 minecraft:jack_o_lantern
setblock 341 295 420 minecraft:jack_o_lantern
setblock 341 295 422 minecraft:jack_o_lantern
setblock 342 295 417 minecraft:jack_o_lantern
setblock 342 295 419 minecraft:jack_o_lantern
setblock 342 295 421 minecraft:jack_o_lantern
setblock 342 295 423 minecraft:jack_o_lantern
setblock 343 295 418 minecraft:jack_o_lantern
setblock 343 295 420 minecraft:jack_o_lantern
setblock 343 295 422 minecraft:jack_o_lantern
setblock 344 295 417 minecraft:jack_o_lantern
setblock 344 295 419 minecraft:jack_o_lantern
setblock 344 295 421 minecraft:jack_o_lantern
setblock 344 295 423 minecraft:jack_o_lantern
setblock 345 295 417 minecraft:red_concrete
setblock 345 295 457 minecraft:red_concrete
setblock 352 295 417 minecraft:red_concrete
setblock 352 295 457 minecraft:red_concrete
setblock 359 295 417 minecraft:red_concrete
setblock 359 295 457 minecraft:red_concrete
setblock 366 295 417 minecraft:red_concrete
setblock 366 295 457 minecraft:red_concrete
setblock 370 295 420 minecraft:red_concrete
setblock 370 295 427 minecraft:red_concrete
setblock 370 295 434 minecraft:red_concrete
setblock 370 295 441 minecraft:red_concrete
setblock 370 295 448 minecraft:red_concrete
setblock 370 295 455 minecraft:red_concrete
setblock 330 296 431 minecraft:red_concrete
setblock 330 296 438 minecraft:red_concrete
setblock 330 296 445 minecraft:red_concrete
setblock 330 296 452 minecraft:red_concrete
setblock 332 296 457 minecraft:red_concrete
fill 336 296 417 336 297 417 minecraft:red_concrete
fill 336 296 419 336 297 419 minecraft:red_concrete
fill 336 296 421 336 297 421 minecraft:red_concrete
fill 336 296 423 336 297 423 minecraft:red_concrete
fill 337 296 418 337 297 418 minecraft:red_concrete
fill 337 296 420 337 297 420 minecraft:red_concrete
fill 337 296 422 337 297 422 minecraft:red_concrete
fill 338 296 417 338 297 417 minecraft:red_concrete
fill 338 296 419 338 297 419 minecraft:red_concrete
fill 338 296 421 338 297 421 minecraft:red_concrete
fill 338 296 423 338 297 423 minecraft:red_concrete
fill 339 296 418 339 297 418 minecraft:red_concrete
fill 339 296 420 339 297 420 minecraft:red_concrete
fill 339 296 422 339 297 422 minecraft:red_concrete
setblock 339 296 457 minecraft:red_concrete
fill 340 296 417 340 297 417 minecraft:red_concrete
fill 340 296 419 340 297 419 minecraft:red_concrete
fill 340 296 421 340 297 421 minecraft:red_concrete
fill 340 296 423 340 297 423 minecraft:red_concrete
fill 341 296 418 341 297 418 minecraft:red_concrete
fill 341 296 420 341 297 420 minecraft:red_concrete
fill 341 296 422 341 297 422 minecraft:red_concrete
fill 342 296 417 342 297 417 minecraft:red_concrete
fill 342 296 419 342 297 419 minecraft:red_concrete
fill 342 296 421 342 297 421 minecraft:red_concrete
fill 342 296 423 342 297 423 minecraft:red_concrete
fill 343 296 418 343 297 418 minecraft:red_concrete
fill 343 296 420 343 297 420 minecraft:red_concrete
fill 343 296 422 343 297 422 minecraft:red_concrete
fill 344 296 417 344 297 417 minecraft:red_concrete
fill 344 296 419 344 297 419 minecraft:red_concrete
fill 344 296 421 344 297 421 minecraft:red_concrete
fill 344 296 423 344 297 423 minecraft:red_concrete
setblock 346 296 457 minecraft:red_concrete
setblock 351 296 417 minecraft:red_concrete
setblock 353 296 457 minecraft:red_concrete
fill 357 296 455 363 297 455 minecraft:gray_concrete
setblock 358 296 417 minecraft:red_concrete
setblock 360 296 457 minecraft:red_concrete
setblock 365 296 417 minecraft:red_concrete
setblock 367 296 457 minecraft:red_concrete
setblock 370 296 419 minecraft:red_concrete
setblock 370 296 426 minecraft:red_concrete
setblock 370 296 433 minecraft:red_concrete
setblock 370 296 440 minecraft:red_concrete
setblock 370 296 447 minecraft:red_concrete
setblock 370 296 454 minecraft:red_concrete
setblock 330 297 432 minecraft:red_concrete
setblock 330 297 439 minecraft:red_concrete
setblock 330 297 446 minecraft:red_concrete
setblock 330 297 453 minecraft:red_concrete
setblock 333 297 457 minecraft:red_concrete
setblock 340 297 457 minecraft:red_concrete
setblock 347 297 457 minecraft:red_concrete
setblock 350 297 417 minecraft:red_concrete
setblock 354 297 457 minecraft:red_concrete
setblock 357 297 417 minecraft:red_concrete
setblock 361 297 457 minecraft:red_concrete
setblock 364 297 417 minecraft:red_concrete
setblock 368 297 457 minecraft:red_concrete
setblock 370 297 418 minecraft:red_concrete
setblock 370 297 425 minecraft:red_concrete
setblock 370 297 432 minecraft:red_concrete
setblock 370 297 439 minecraft:red_concrete
setblock 370 297 446 minecraft:red_concrete
setblock 370 297 453 minecraft:red_concrete
setblock 330 298 426 minecraft:red_concrete
setblock 330 298 433 minecraft:red_concrete
setblock 330 298 440 minecraft:red_concrete
setblock 330 298 447 minecraft:red_concrete
setblock 330 298 454 minecraft:red_concrete
setblock 334 298 457 minecraft:red_concrete
setblock 336 298 417 minecraft:jack_o_lantern
setblock 336 298 419 minecraft:jack_o_lantern
setblock 336 298 421 minecraft:jack_o_lantern
setblock 336 298 423 minecraft:jack_o_lantern
setblock 337 298 418 minecraft:jack_o_lantern
setblock 337 298 420 minecraft:jack_o_lantern
setblock 337 298 422 minecraft:jack_o_lantern
setblock 338 298 417 minecraft:jack_o_lantern
setblock 338 298 419 minecraft:jack_o_lantern
setblock 338 298 421 minecraft:jack_o_lantern
setblock 338 298 423 minecraft:jack_o_lantern
setblock 339 298 418 minecraft:jack_o_lantern
setblock 339 298 420 minecraft:jack_o_lantern
setblock 339 298 422 minecraft:jack_o_lantern
setblock 340 298 417 minecraft:jack_o_lantern
setblock 340 298 419 minecraft:jack_o_lantern
setblock 340 298 421 minecraft:jack_o_lantern
setblock 340 298 423 minecraft:jack_o_lantern
setblock 341 298 418 minecraft:jack_o_lantern
setblock 341 298 420 minecraft:jack_o_lantern
setblock 341 298 422 minecraft:jack_o_lantern
setblock 341 298 457 minecraft:red_concrete
setblock 342 298 417 minecraft:jack_o_lantern
setblock 342 298 419 minecraft:jack_o_lantern
setblock 342 298 421 minecraft:jack_o_lantern
setblock 342 298 423 minecraft:jack_o_lantern
setblock 343 298 418 minecraft:jack_o_lantern
setblock 343 298 420 minecraft:jack_o_lantern
setblock 343 298 422 minecraft:jack_o_lantern
setblock 344 298 417 minecraft:jack_o_lantern
setblock 344 298 419 minecraft:jack_o_lantern
setblock 344 298 421 minecraft:jack_o_lantern
setblock 344 298 423 minecraft:jack_o_lantern
setblock 348 298 457 minecraft:red_concrete
setblock 349 298 417 minecraft:red_concrete
setblock 355 298 457 minecraft:red_concrete
setblock 356 298 417 minecraft:red_concrete
setblock 362 298 457 minecraft:red_concrete
setblock 363 298 417 minecraft:red_concrete
setblock 369 298 457 minecraft:red_concrete
setblock 370 298 417 minecraft:red_concrete
setblock 370 298 424 minecraft:red_concrete
setblock 370 298 431 minecraft:red_concrete
setblock 370 298 438 minecraft:red_concrete
setblock 370 298 445 minecraft:red_concrete
setblock 370 298 452 minecraft:red_concrete
fill 330 299 427 330 300 427 minecraft:red_concrete
fill 330 299 434 330 300 434 minecraft:red_concrete
fill 330 299 441 330 300 441 minecraft:red_concrete
fill 330 299 448 330 300 448 minecraft:red_concrete
fill 330 299 455 330 300 455 minecraft:red_concrete
fill 335 299 457 335 300 457 minecraft:red_concrete
fill 336 299 417 336 300 417 minecraft:red_concrete
fill 336 299 419 336 300 419 minecraft:red_concrete
fill 336 299 421 336 300 421 minecraft:red_concrete
fill 336 299 423 336 300 423 minecraft:red_concrete
fill 337 299 418 337 300 418 minecraft:red_concrete
fill 337 299 420 337 300 420 minecraft:red_concrete
fill 337 299 422 337 300 422 minecraft:red_concrete
fill 338 299 417 338 300 417 minecraft:red_concrete
fill 338 299 419 338 300 419 minecraft:red_concrete
fill 338 299 421 338 300 421 minecraft:red_concrete
fill 338 299 423 338 300 423 minecraft:red_concrete
fill 339 299 418 339 300 418 minecraft:red_concrete
fill 339 299 420 339 300 420 minecraft:red_concrete
fill 339 299 422 339 300 422 minecraft:red_concrete
fill 340 299 417 340 300 417 minecraft:red_concrete
fill 340 299 419 340 300 419 minecraft:red_concrete
fill 340 299 421 340 300 421 minecraft:red_concrete
fill 340 299 423 340 300 423 minecraft:red_concrete
fill 341 299 418 341 300 418 minecraft:red_concrete
fill 341 299 420 341 300 420 minecraft:red_concrete
fill 341 299 422 341 300 422 minecraft:red_concrete
fill 342 299 417 342 300 417 minecraft:red_concrete
fill 342 299 419 342 300 419 minecraft:red_concrete
fill 342 299 421 342 300 421 minecraft:red_concrete
fill 342 299 423 342 300 423 minecraft:red_concrete
fill 342 299 457 342 300 457 minecraft:red_concrete
fill 343 299 418 343 300 418 minecraft:red_concrete
fill 343 299 420 343 300 420 minecraft:red_concrete
fill 343 299 422 343 300 422 minecraft:red_concrete
fill 344 299 417 344 300 417 minecraft:red_concrete
fill 344 299 419 344 300 419 minecraft:red_concrete
fill 344 299 421 344 300 421 minecraft:red_concrete
fill 344 299 423 344 300 423 minecraft:red_concrete
fill 348 299 417 348 300 417 minecraft:red_concrete
fill 349 299 457 349 300 457 minecraft:red_concrete
fill 355 299 417 355 300 417 minecraft:red_concrete
fill 356 299 457 356 300 457 minecraft:red_concrete
fill 362 299 417 362 300 417 minecraft:red_concrete
fill 363 299 457 363 300 457 minecraft:red_concrete
fill 369 299 417 369 300 417 minecraft:red_concrete
fill 370 299 423 370 300 423 minecraft:red_concrete
fill 370 299 430 370 300 430 minecraft:red_concrete
fill 370 299 437 370 300 437 minecraft:red_concrete
fill 370 299 444 370 300 444 minecraft:red_concrete
fill 370 299 451 370 300 451 minecraft:red_concrete
fill 370 299 457 370 300 457 minecraft:red_concrete
setblock 330 300 426 minecraft:red_concrete
setblock 330 300 428 minecraft:red_concrete
fill 330 300 430 330 300 433 minecraft:red_concrete
setblock 330 300 435 minecraft:red_concrete
fill 330 300 437 330 300 440 minecraft:red_concrete
setblock 330 300 442 minecraft:red_concrete
fill 330 300 444 330 300 447 minecraft:red_concrete
setblock 330 300 449 minecraft:red_concrete
fill 330 300 451 330 300 454 minecraft:red_concrete
setblock 330 300 456 minecraft:red_concrete
fill 331 300 457 334 300 457 minecraft:red_concrete
setblock 336 300 457 minecraft:red_concrete
fill 338 300 457 341 300 457 minecraft:red_concrete
setblock 343 300 457 minecraft:red_concrete
setblock 345 300 417 minecraft:red_concrete
fill 345 300 457 348 300 457 minecraft:red_concrete
setblock 347 300 417 minecraft:red_concrete
fill 349 300 417 352 300 417 minecraft:red_concrete
setblock 350 300 457 minecraft:red_concrete
fill 352 300 457 355 300 457 minecraft:red_concrete
setblock 354 300 417 minecraft:red_concrete
fill 356 300 417 359 300 417 minecraft:red_concrete
setblock 357 300 457 minecraft:red_concrete
fill 359 300 457 362 300 457 minecraft:red_concrete
setblock 361 300 417 minecraft:red_concrete
fill 363 300 417 366 300 417 minecraft:red_concrete
setblock 364 300 457 minecraft:red_concrete
fill 366 300 457 369 300 457 minecraft:red_concrete
setblock 368 300 417 minecraft:red_concrete
fill 370 300 417 370 300 420 minecraft:red_concrete
setblock 370 300 422 minecraft:red_concrete
fill 370 300 424 370 300 427 minecraft:red_concrete
setblock 370 300 429 minecraft:red_concrete
fill 370 300 431 370 300 434 minecraft:red_concrete
setblock 370 300 436 minecraft:red_concrete
fill 370 300 438 370 300 441 minecraft:red_concrete
setblock 370 300 443 minecraft:red_concrete
fill 370 300 445 370 300 448 minecraft:red_concrete
setblock 370 300 450 minecraft:red_concrete
fill 370 300 452 370 300 455 minecraft:red_concrete
setblock 332 302 419 minecraft:light[level=12]
setblock 332 302 427 minecraft:light[level=12]
setblock 332 302 435 minecraft:light[level=12]
setblock 332 302 443 minecraft:light[level=12]
setblock 332 302 451 minecraft:light[level=12]
setblock 340 302 419 minecraft:light[level=12]
setblock 340 302 427 minecraft:light[level=12]
setblock 340 302 435 minecraft:light[level=12]
setblock 340 302 443 minecraft:light[level=12]
setblock 340 302 451 minecraft:light[level=12]
setblock 348 302 419 minecraft:light[level=12]
setblock 348 302 427 minecraft:light[level=12]
setblock 348 302 435 minecraft:light[level=12]
setblock 348 302 443 minecraft:light[level=12]
setblock 348 302 451 minecraft:light[level=12]
setblock 356 302 419 minecraft:light[level=12]
setblock 356 302 427 minecraft:light[level=12]
setblock 356 302 435 minecraft:light[level=12]
setblock 356 302 443 minecraft:light[level=12]
setblock 356 302 451 minecraft:light[level=12]
setblock 364 302 419 minecraft:light[level=12]
setblock 364 302 427 minecraft:light[level=12]
setblock 364 302 435 minecraft:light[level=12]
setblock 364 302 443 minecraft:light[level=12]
setblock 364 302 451 minecraft:light[level=12]
