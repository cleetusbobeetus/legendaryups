fill 411 248 298 411 249 298 minecraft:stripped_oak_log
fill 411 248 300 411 249 300 minecraft:stripped_oak_log
fill 411 248 302 411 249 302 minecraft:stripped_oak_log
fill 411 248 304 411 249 304 minecraft:stripped_oak_log
fill 411 248 306 411 249 306 minecraft:stripped_oak_log
fill 411 248 308 411 249 308 minecraft:stripped_oak_log
setblock 411 248 310 minecraft:light[level=15]
setblock 412 248 295 minecraft:stripped_oak_log
fill 412 248 297 412 249 297 minecraft:stripped_oak_log
fill 412 248 299 412 249 299 minecraft:stripped_oak_log
fill 412 248 301 412 249 301 minecraft:stripped_oak_log
fill 412 248 303 412 249 303 minecraft:stripped_oak_log
fill 412 248 305 412 249 305 minecraft:stripped_oak_log
fill 412 248 307 412 249 307 minecraft:stripped_oak_log
fill 412 248 316 412 251 316 minecraft:red_terracotta
setblock 413 248 294 minecraft:stripped_oak_log
fill 413 248 296 413 249 296 minecraft:stripped_oak_log
fill 413 248 298 413 249 298 minecraft:stripped_oak_log
fill 413 248 300 413 249 300 minecraft:stripped_oak_log
fill 413 248 302 415 248 302 minecraft:stripped_oak_log
fill 413 248 304 413 249 304 minecraft:stripped_oak_log
fill 413 248 306 413 249 306 minecraft:stripped_oak_log
fill 413 248 308 414 248 308 minecraft:stripped_oak_log
setblock 414 248 295 minecraft:stripped_oak_log
fill 414 248 297 414 249 297 minecraft:stripped_oak_log
fill 414 248 299 415 249 299 minecraft:stripped_oak_log
fill 414 248 301 414 249 301 minecraft:stripped_oak_log
fill 414 248 303 414 249 303 minecraft:stripped_oak_log
fill 414 248 304 414 248 305 minecraft:red_terracotta
setblock 414 248 307 minecraft:red_terracotta
setblock 415 248 294 minecraft:stripped_oak_log
fill 415 248 296 416 249 296 minecraft:stripped_oak_log
fill 415 248 298 415 249 298 minecraft:stripped_oak_log
setblock 415 248 300 minecraft:red_terracotta
fill 415 248 303 415 249 304 minecraft:red_terracotta
setblock 415 248 306 minecraft:red_terracotta
setblock 415 248 307 minecraft:stripped_oak_log
fill 415 248 308 415 249 308 minecraft:red_terracotta
setblock 416 248 282 minecraft:red_terracotta
setblock 416 248 285 minecraft:red_terracotta
setblock 416 248 286 minecraft:stripped_oak_log
fill 416 248 287 416 251 287 minecraft:red_terracotta
setblock 416 248 291 minecraft:stripped_oak_log
fill 416 248 292 416 251 292 minecraft:red_terracotta
setblock 416 248 295 minecraft:red_terracotta
setblock 416 248 297 minecraft:red_terracotta
fill 416 248 299 416 249 299 minecraft:red_terracotta
setblock 416 248 301 minecraft:stripped_oak_log
fill 416 248 302 416 249 303 minecraft:red_terracotta
setblock 416 248 305 minecraft:red_terracotta
setblock 416 248 306 minecraft:stripped_oak_log
fill 416 248 307 416 249 307 minecraft:red_terracotta
setblock 416 248 311 minecraft:stripped_oak_log
fill 416 248 312 416 251 312 minecraft:red_terracotta
setblock 417 248 280 minecraft:stripped_oak_log
fill 417 248 281 417 249 281 minecraft:red_terracotta
setblock 417 248 285 minecraft:stripped_oak_log
fill 417 248 286 417 251 286 minecraft:red_terracotta
setblock 417 248 290 minecraft:stripped_oak_log
fill 417 248 291 417 251 291 minecraft:red_terracotta
setblock 417 248 294 minecraft:red_terracotta
setblock 417 248 295 minecraft:stripped_oak_log
fill 417 248 296 417 249 296 minecraft:red_terracotta
fill 417 248 298 417 249 298 minecraft:red_terracotta
setblock 417 248 300 minecraft:stripped_oak_log
fill 417 248 301 417 249 302 minecraft:red_terracotta
setblock 417 248 304 minecraft:red_terracotta
setblock 417 248 305 minecraft:stripped_oak_log
fill 417 248 306 417 249 306 minecraft:red_terracotta
fill 417 248 308 417 249 308 minecraft:red_terracotta
setblock 417 248 310 minecraft:stripped_oak_log
fill 417 248 311 417 251 311 minecraft:red_terracotta
fill 418 248 276 418 251 316 minecraft:light_gray_terracotta
setblock 377 249 279 minecraft:stripped_oak_log
fill 377 249 280 377 249 283 minecraft:red_terracotta
setblock 377 249 284 minecraft:stripped_oak_log
fill 377 249 285 377 249 288 minecraft:red_terracotta
setblock 377 249 289 minecraft:stripped_oak_log
fill 377 249 290 377 252 290 minecraft:red_terracotta
setblock 377 249 294 minecraft:stripped_oak_log
fill 377 249 295 377 252 295 minecraft:red_terracotta
setblock 377 249 299 minecraft:stripped_oak_log
fill 377 249 300 377 249 303 minecraft:red_terracotta
setblock 377 249 304 minecraft:stripped_oak_log
fill 377 249 305 377 251 305 minecraft:red_terracotta
setblock 377 249 309 minecraft:stripped_oak_log
fill 377 249 310 377 252 310 minecraft:red_terracotta
setblock 378 249 283 minecraft:stripped_oak_log
setblock 378 249 284 minecraft:red_terracotta
setblock 378 249 288 minecraft:stripped_oak_log
fill 378 249 289 378 252 289 minecraft:red_terracotta
setblock 379 249 287 minecraft:stripped_oak_log
fill 385 249 277 387 249 279 minecraft:terracotta
setblock 390 249 276 minecraft:stripped_oak_log
setblock 390 249 316 minecraft:stripped_oak_log
setblock 391 249 276 minecraft:red_terracotta
fill 391 249 316 394 249 316 minecraft:red_terracotta
setblock 394 249 277 minecraft:stripped_oak_log
setblock 395 249 276 minecraft:stripped_oak_log
setblock 395 249 277 minecraft:red_terracotta
setblock 395 249 316 minecraft:stripped_oak_log
fill 396 249 276 396 252 276 minecraft:red_terracotta
fill 396 249 277 397 249 277 minecraft:stripped_oak_log
setblock 396 249 315 minecraft:stripped_oak_log
fill 396 249 316 396 252 316 minecraft:red_terracotta
fill 397 249 315 397 252 315 minecraft:red_terracotta
setblock 399 249 276 minecraft:stripped_oak_log
fill 413 249 302 414 249 302 minecraft:stripped_oak_log
setblock 413 249 308 minecraft:stripped_oak_log
fill 414 249 304 414 251 304 minecraft:stripped_oak_log
setblock 414 249 305 minecraft:red_terracotta
setblock 414 249 307 minecraft:stripped_oak_log
setblock 414 249 308 minecraft:red_terracotta
fill 415 249 300 415 249 301 minecraft:stripped_oak_log
setblock 415 249 302 minecraft:red_terracotta
setblock 415 249 306 minecraft:stripped_oak_log
fill 415 249 307 415 252 307 minecraft:red_terracotta
setblock 416 249 285 minecraft:stripped_oak_log
fill 416 249 286 416 252 286 minecraft:red_terracotta
setblock 416 249 290 minecraft:stripped_oak_log
fill 416 249 291 416 252 291 minecraft:red_terracotta
setblock 416 249 297 minecraft:stripped_oak_log
setblock 416 249 300 minecraft:stripped_oak_log
setblock 416 249 301 minecraft:red_terracotta
setblock 416 249 305 minecraft:stripped_oak_log
fill 416 249 306 416 252 306 minecraft:red_terracotta
setblock 416 249 310 minecraft:stripped_oak_log
fill 416 249 311 416 252 311 minecraft:red_terracotta
setblock 417 249 284 minecraft:stripped_oak_log
fill 417 249 285 417 252 285 minecraft:red_terracotta
setblock 417 249 289 minecraft:stripped_oak_log
fill 417 249 290 417 252 290 minecraft:red_terracotta
setblock 417 249 294 minecraft:stripped_oak_log
fill 417 249 295 417 252 295 minecraft:red_terracotta
setblock 417 249 299 minecraft:stripped_oak_log
setblock 417 249 300 minecraft:red_terracotta
setblock 417 249 304 minecraft:stripped_oak_log
fill 417 249 305 417 252 305 minecraft:red_terracotta
setblock 417 249 309 minecraft:stripped_oak_log
fill 417 249 310 417 252 310 minecraft:red_terracotta
fill 377 250 280 377 250 282 minecraft:red_terracotta
fill 377 250 283 379 250 285 minecraft:terracotta
fill 377 250 286 377 250 287 minecraft:red_terracotta
setblock 377 250 288 minecraft:stripped_oak_log
fill 377 250 289 377 253 289 minecraft:red_terracotta
setblock 377 250 293 minecraft:stripped_oak_log
fill 377 250 294 377 253 294 minecraft:red_terracotta
setblock 377 250 302 minecraft:red_terracotta
setblock 377 250 303 minecraft:stripped_oak_log
setblock 377 250 304 minecraft:red_terracotta
setblock 377 250 308 minecraft:stripped_oak_log
fill 377 250 309 377 253 309 minecraft:red_terracotta
setblock 378 250 282 minecraft:stripped_oak_log
setblock 378 250 287 minecraft:stripped_oak_log
fill 378 250 288 378 253 288 minecraft:red_terracotta
fill 386 250 278 386 256 278 minecraft:green_concrete
setblock 387 250 276 minecraft:shroomlight
fill 387 250 277 387 253 277 minecraft:stripped_oak_log
setblock 387 250 278 minecraft:shroomlight
fill 387 250 279 387 255 279 minecraft:stripped_oak_log
fill 388 250 276 388 251 276 minecraft:stripped_oak_log
setblock 388 250 277 minecraft:shroomlight
setblock 388 250 279 minecraft:shroomlight
setblock 389 250 276 minecraft:shroomlight
setblock 389 250 278 minecraft:shroomlight
fill 390 250 276 390 253 276 minecraft:red_terracotta
setblock 390 250 277 minecraft:shroomlight
setblock 390 250 279 minecraft:shroomlight
fill 390 250 316 393 250 316 minecraft:red_terracotta
setblock 391 250 276 minecraft:shroomlight
setblock 391 250 277 minecraft:stripped_oak_log
setblock 391 250 278 minecraft:shroomlight
fill 392 250 276 392 251 276 minecraft:red_terracotta
setblock 392 250 277 minecraft:shroomlight
fill 392 250 278 392 255 278 minecraft:stripped_oak_log
setblock 392 250 279 minecraft:shroomlight
fill 392 250 315 392 252 315 minecraft:red_terracotta
setblock 393 250 276 minecraft:shroomlight
setblock 393 250 277 minecraft:stripped_oak_log
setblock 393 250 278 minecraft:shroomlight
setblock 394 250 276 minecraft:stripped_oak_log
setblock 394 250 277 minecraft:shroomlight
fill 394 250 278 394 255 278 minecraft:stripped_oak_log
setblock 394 250 279 minecraft:shroomlight
setblock 394 250 316 minecraft:stripped_oak_log
setblock 395 250 276 minecraft:shroomlight
fill 395 250 277 395 255 277 minecraft:stripped_oak_log
setblock 395 250 278 minecraft:shroomlight
setblock 395 250 315 minecraft:stripped_oak_log
fill 395 250 316 395 253 316 minecraft:red_terracotta
setblock 396 250 277 minecraft:shroomlight
fill 396 250 278 396 255 278 minecraft:stripped_oak_log
setblock 396 250 279 minecraft:shroomlight
fill 396 250 315 396 253 315 minecraft:red_terracotta
setblock 397 250 276 minecraft:shroomlight
fill 397 250 277 397 255 277 minecraft:stripped_oak_log
setblock 397 250 278 minecraft:shroomlight
fill 398 250 276 398 255 276 minecraft:stripped_oak_log
setblock 398 250 277 minecraft:shroomlight
setblock 398 250 279 minecraft:shroomlight
setblock 399 250 276 minecraft:shroomlight
setblock 399 250 278 minecraft:shroomlight
setblock 399 250 316 minecraft:stripped_oak_log
setblock 409 250 296 minecraft:shroomlight
setblock 409 250 298 minecraft:shroomlight
setblock 409 250 300 minecraft:shroomlight
setblock 409 250 302 minecraft:shroomlight
setblock 409 250 304 minecraft:shroomlight
setblock 409 250 306 minecraft:shroomlight
setblock 409 250 308 minecraft:shroomlight
setblock 410 250 297 minecraft:shroomlight
setblock 410 250 299 minecraft:shroomlight
setblock 410 250 301 minecraft:shroomlight
setblock 410 250 303 minecraft:shroomlight
setblock 410 250 305 minecraft:shroomlight
setblock 410 250 307 minecraft:shroomlight
setblock 411 250 296 minecraft:shroomlight
setblock 411 250 298 minecraft:shroomlight
setblock 411 250 300 minecraft:shroomlight
setblock 411 250 302 minecraft:shroomlight
setblock 411 250 304 minecraft:shroomlight
setblock 411 250 306 minecraft:shroomlight
setblock 411 250 308 minecraft:shroomlight
fill 411 250 316 411 252 316 minecraft:red_terracotta
setblock 412 250 297 minecraft:shroomlight
setblock 412 250 299 minecraft:shroomlight
setblock 412 250 301 minecraft:shroomlight
setblock 412 250 303 minecraft:shroomlight
setblock 412 250 305 minecraft:shroomlight
setblock 412 250 307 minecraft:shroomlight
setblock 413 250 296 minecraft:shroomlight
setblock 413 250 298 minecraft:shroomlight
setblock 413 250 300 minecraft:shroomlight
setblock 413 250 302 minecraft:shroomlight
setblock 413 250 304 minecraft:shroomlight
setblock 413 250 306 minecraft:shroomlight
setblock 413 250 308 minecraft:shroomlight
setblock 414 250 297 minecraft:shroomlight
setblock 414 250 299 minecraft:shroomlight
setblock 414 250 301 minecraft:shroomlight
fill 414 250 302 414 251 302 minecraft:stripped_oak_log
setblock 414 250 303 minecraft:shroomlight
setblock 414 250 305 minecraft:shroomlight
fill 414 250 306 414 251 306 minecraft:stripped_oak_log
setblock 414 250 307 minecraft:shroomlight
fill 414 250 308 414 251 308 minecraft:stripped_oak_log
fill 415 250 287 415 250 289 minecraft:red_terracotta
setblock 415 250 296 minecraft:shroomlight
setblock 415 250 298 minecraft:shroomlight
fill 415 250 299 415 251 299 minecraft:stripped_oak_log
setblock 415 250 300 minecraft:shroomlight
fill 415 250 301 415 251 301 minecraft:stripped_oak_log
setblock 415 250 302 minecraft:shroomlight
setblock 415 250 303 minecraft:red_terracotta
setblock 415 250 304 minecraft:shroomlight
setblock 415 250 305 minecraft:stripped_oak_log
setblock 415 250 306 minecraft:shroomlight
setblock 415 250 308 minecraft:shroomlight
setblock 415 250 310 minecraft:stripped_oak_log
setblock 416 250 284 minecraft:stripped_oak_log
fill 416 250 285 416 253 285 minecraft:red_terracotta
setblock 416 250 289 minecraft:stripped_oak_log
fill 416 250 290 416 253 290 minecraft:red_terracotta
setblock 416 250 294 minecraft:stripped_oak_log
fill 416 250 296 416 251 296 minecraft:stripped_oak_log
setblock 416 250 297 minecraft:shroomlight
fill 416 250 298 416 251 298 minecraft:stripped_oak_log
setblock 416 250 299 minecraft:shroomlight
setblock 416 250 300 minecraft:red_terracotta
setblock 416 250 301 minecraft:shroomlight
fill 416 250 302 416 251 302 minecraft:red_terracotta
setblock 416 250 303 minecraft:shroomlight
setblock 416 250 304 minecraft:stripped_oak_log
setblock 416 250 305 minecraft:shroomlight
setblock 416 250 307 minecraft:shroomlight
setblock 416 250 309 minecraft:stripped_oak_log
fill 416 250 310 416 253 310 minecraft:red_terracotta
setblock 417 250 283 minecraft:stripped_oak_log
fill 417 250 284 417 253 284 minecraft:red_terracotta
setblock 417 250 288 minecraft:stripped_oak_log
fill 417 250 289 417 253 289 minecraft:red_terracotta
setblock 417 250 293 minecraft:stripped_oak_log
fill 417 250 294 417 253 294 minecraft:red_terracotta
setblock 417 250 296 minecraft:shroomlight
setblock 417 250 298 minecraft:shroomlight
fill 417 250 299 417 253 299 minecraft:red_terracotta
setblock 417 250 300 minecraft:shroomlight
fill 417 250 301 417 251 301 minecraft:red_terracotta
setblock 417 250 302 minecraft:shroomlight
setblock 417 250 303 minecraft:stripped_oak_log
setblock 417 250 304 minecraft:shroomlight
setblock 417 250 306 minecraft:shroomlight
setblock 417 250 308 minecraft:shroomlight
fill 417 250 309 417 253 309 minecraft:red_terracotta
setblock 417 250 313 minecraft:stripped_oak_log
fill 377 251 280 377 251 281 minecraft:red_terracotta
setblock 377 251 282 minecraft:stripped_oak_log
fill 377 251 283 377 251 286 minecraft:red_terracotta
setblock 377 251 287 minecraft:stripped_oak_log
fill 377 251 288 377 254 288 minecraft:red_terracotta
setblock 377 251 292 minecraft:stripped_oak_log
fill 377 251 293 377 254 293 minecraft:red_terracotta
setblock 377 251 307 minecraft:stripped_oak_log
fill 377 251 308 377 253 308 minecraft:red_terracotta
setblock 378 251 283 minecraft:red_terracotta
fill 378 251 284 378 257 284 minecraft:green_concrete
setblock 378 251 285 minecraft:red_terracotta
setblock 378 251 286 minecraft:stripped_oak_log
fill 378 251 287 378 254 287 minecraft:red_terracotta
setblock 378 251 291 minecraft:stripped_oak_log
fill 387 251 276 387 252 276 minecraft:stripped_oak_log
fill 387 251 278 387 252 278 minecraft:stripped_oak_log
fill 388 251 277 388 252 277 minecraft:stripped_oak_log
fill 388 251 279 388 252 279 minecraft:stripped_oak_log
fill 389 251 276 389 252 276 minecraft:red_terracotta
fill 389 251 278 389 252 278 minecraft:stripped_oak_log
fill 389 251 316 392 251 316 minecraft:red_terracotta
setblock 390 251 277 minecraft:stripped_oak_log
fill 390 251 279 390 252 279 minecraft:stripped_oak_log
fill 390 251 315 391 253 315 minecraft:red_terracotta
fill 391 251 276 391 251 277 minecraft:red_terracotta
fill 391 251 278 391 252 278 minecraft:stripped_oak_log
setblock 392 251 277 minecraft:stripped_oak_log
fill 392 251 279 392 252 279 minecraft:stripped_oak_log
setblock 393 251 276 minecraft:stripped_oak_log
fill 393 251 277 393 254 277 minecraft:red_terracotta
fill 393 251 278 393 252 278 minecraft:stripped_oak_log
setblock 393 251 316 minecraft:stripped_oak_log
fill 394 251 276 395 252 276 minecraft:red_terracotta
fill 394 251 277 394 252 277 minecraft:stripped_oak_log
fill 394 251 279 394 252 279 minecraft:stripped_oak_log
setblock 394 251 315 minecraft:stripped_oak_log
fill 394 251 316 394 254 316 minecraft:red_terracotta
fill 395 251 278 395 252 278 minecraft:stripped_oak_log
fill 395 251 315 395 254 315 minecraft:red_terracotta
fill 396 251 277 396 252 277 minecraft:stripped_oak_log
fill 396 251 279 396 252 279 minecraft:stripped_oak_log
fill 397 251 276 397 252 276 minecraft:stripped_oak_log
fill 397 251 278 397 252 278 minecraft:stripped_oak_log
fill 398 251 277 398 252 277 minecraft:stripped_oak_log
fill 398 251 279 398 252 279 minecraft:stripped_oak_log
setblock 398 251 316 minecraft:stripped_oak_log
fill 399 251 276 399 252 276 minecraft:stripped_oak_log
fill 399 251 278 399 252 278 minecraft:stripped_oak_log
fill 399 251 316 399 254 316 minecraft:red_terracotta
setblock 409 251 296 minecraft:stripped_oak_log
setblock 409 251 298 minecraft:stripped_oak_log
setblock 409 251 300 minecraft:stripped_oak_log
setblock 409 251 302 minecraft:stripped_oak_log
setblock 409 251 304 minecraft:stripped_oak_log
setblock 409 251 306 minecraft:stripped_oak_log
setblock 409 251 308 minecraft:stripped_oak_log
fill 409 251 316 410 253 316 minecraft:red_terracotta
setblock 410 251 297 minecraft:stripped_oak_log
setblock 410 251 299 minecraft:stripped_oak_log
setblock 410 251 301 minecraft:stripped_oak_log
setblock 410 251 303 minecraft:stripped_oak_log
setblock 410 251 305 minecraft:stripped_oak_log
setblock 410 251 307 minecraft:stripped_oak_log
setblock 411 251 296 minecraft:stripped_oak_log
setblock 411 251 298 minecraft:stripped_oak_log
setblock 411 251 300 minecraft:stripped_oak_log
setblock 411 251 302 minecraft:stripped_oak_log
setblock 411 251 304 minecraft:stripped_oak_log
setblock 411 251 306 minecraft:stripped_oak_log
setblock 411 251 308 minecraft:stripped_oak_log
setblock 412 251 297 minecraft:stripped_oak_log
setblock 412 251 299 minecraft:stripped_oak_log
setblock 412 251 301 minecraft:stripped_oak_log
setblock 412 251 303 minecraft:stripped_oak_log
setblock 412 251 305 minecraft:stripped_oak_log
setblock 412 251 307 minecraft:stripped_oak_log
setblock 413 251 296 minecraft:stripped_oak_log
setblock 413 251 298 minecraft:stripped_oak_log
setblock 413 251 300 minecraft:stripped_oak_log
setblock 413 251 302 minecraft:stripped_oak_log
setblock 413 251 304 minecraft:stripped_oak_log
setblock 413 251 306 minecraft:stripped_oak_log
setblock 413 251 308 minecraft:stripped_oak_log
fill 413 251 309 415 251 311 minecraft:terracotta
setblock 413 251 316 minecraft:stripped_oak_log
setblock 414 251 297 minecraft:stripped_oak_log
setblock 414 251 299 minecraft:stripped_oak_log
setblock 414 251 301 minecraft:stripped_oak_log
fill 414 251 303 416 251 303 minecraft:stripped_oak_log
setblock 414 251 305 minecraft:stripped_oak_log
setblock 414 251 307 minecraft:stripped_oak_log
fill 414 251 316 414 254 316 minecraft:red_terracotta
fill 415 251 287 415 251 288 minecraft:red_terracotta
setblock 415 251 289 minecraft:stripped_oak_log
fill 415 251 290 415 254 290 minecraft:red_terracotta
setblock 415 251 296 minecraft:stripped_oak_log
setblock 415 251 298 minecraft:stripped_oak_log
fill 415 251 300 416 251 300 minecraft:stripped_oak_log
setblock 415 251 302 minecraft:stripped_oak_log
setblock 415 251 304 minecraft:stripped_oak_log
fill 415 251 305 415 251 306 minecraft:red_terracotta
setblock 415 251 308 minecraft:red_terracotta
setblock 416 251 284 minecraft:red_terracotta
setblock 416 251 288 minecraft:stripped_oak_log
fill 416 251 289 416 254 289 minecraft:red_terracotta
setblock 416 251 293 minecraft:stripped_oak_log
fill 416 251 294 416 254 294 minecraft:red_terracotta
fill 416 251 297 417 251 297 minecraft:stripped_oak_log
setblock 416 251 299 minecraft:stripped_oak_log
setblock 416 251 301 minecraft:red_terracotta
fill 416 251 304 416 253 305 minecraft:red_terracotta
setblock 416 251 307 minecraft:red_terracotta
setblock 416 251 308 minecraft:stripped_oak_log
fill 416 251 309 416 254 309 minecraft:red_terracotta
setblock 417 251 282 minecraft:stripped_oak_log
fill 417 251 283 417 254 283 minecraft:red_terracotta
setblock 417 251 287 minecraft:stripped_oak_log
fill 417 251 288 417 254 288 minecraft:red_terracotta
setblock 417 251 292 minecraft:stripped_oak_log
fill 417 251 293 417 254 293 minecraft:red_terracotta
setblock 417 251 296 minecraft:red_terracotta
fill 417 251 298 417 254 298 minecraft:red_terracotta
fill 417 251 300 417 252 300 minecraft:red_terracotta
setblock 417 251 302 minecraft:stripped_oak_log
fill 417 251 303 417 253 304 minecraft:red_terracotta
setblock 417 251 306 minecraft:red_terracotta
setblock 417 251 307 minecraft:stripped_oak_log
fill 417 251 308 417 254 308 minecraft:red_terracotta
setblock 417 251 312 minecraft:stripped_oak_log
fill 417 251 313 417 254 313 minecraft:red_terracotta
fill 376 252 275 376 255 317 minecraft:orange_terracotta
fill 377 252 275 418 255 275 minecraft:orange_terracotta
setblock 377 252 281 minecraft:stripped_oak_log
fill 377 252 282 377 252 285 minecraft:red_terracotta
setblock 377 252 286 minecraft:stripped_oak_log
fill 377 252 287 377 255 287 minecraft:red_terracotta
setblock 377 252 291 minecraft:stripped_oak_log
fill 377 252 292 378 254 292 minecraft:red_terracotta
setblock 377 252 307 minecraft:red_terracotta
setblock 377 252 311 minecraft:stripped_oak_log
fill 377 252 317 418 255 317 minecraft:orange_terracotta
setblock 378 252 285 minecraft:stripped_oak_log
fill 378 252 286 378 255 286 minecraft:red_terracotta
setblock 378 252 290 minecraft:stripped_oak_log
fill 378 252 291 378 255 291 minecraft:red_terracotta
setblock 379 252 278 minecraft:light[level=12]
setblock 379 252 285 minecraft:light[level=12]
setblock 379 252 292 minecraft:light[level=12]
setblock 379 252 299 minecraft:light[level=12]
setblock 379 252 306 minecraft:light[level=12]
setblock 379 252 313 minecraft:light[level=12]
setblock 386 252 285 minecraft:light[level=12]
setblock 386 252 292 minecraft:light[level=12]
setblock 386 252 299 minecraft:light[level=12]
setblock 386 252 306 minecraft:light[level=12]
setblock 386 252 313 minecraft:light[level=12]
setblock 387 252 316 minecraft:stripped_oak_log
fill 388 252 276 388 255 276 minecraft:red_terracotta
fill 388 252 316 391 252 316 minecraft:red_terracotta
fill 389 252 315 389 255 315 minecraft:red_terracotta
setblock 390 252 277 minecraft:red_terracotta
setblock 391 252 276 minecraft:red_terracotta
setblock 391 252 277 minecraft:stripped_oak_log
fill 391 252 314 393 252 314 minecraft:red_terracotta
setblock 392 252 276 minecraft:stripped_oak_log
setblock 392 252 277 minecraft:red_terracotta
setblock 392 252 316 minecraft:stripped_oak_log
setblock 393 252 276 minecraft:red_terracotta
setblock 393 252 285 minecraft:light[level=12]
setblock 393 252 292 minecraft:light[level=12]
setblock 393 252 299 minecraft:light[level=12]
setblock 393 252 306 minecraft:light[level=12]
setblock 393 252 313 minecraft:light[level=12]
setblock 393 252 315 minecraft:stripped_oak_log
fill 393 252 316 393 255 316 minecraft:red_terracotta
setblock 394 252 314 minecraft:stripped_oak_log
fill 394 252 315 394 255 315 minecraft:red_terracotta
fill 395 252 314 395 255 314 minecraft:red_terracotta
setblock 397 252 316 minecraft:stripped_oak_log
fill 398 252 316 398 255 316 minecraft:red_terracotta
setblock 400 252 278 minecraft:light[level=12]
setblock 400 252 285 minecraft:light[level=12]
setblock 400 252 292 minecraft:light[level=12]
setblock 400 252 299 minecraft:light[level=12]
setblock 400 252 306 minecraft:light[level=12]
setblock 400 252 313 minecraft:light[level=12]
fill 400 252 316 400 253 316 minecraft:red_terracotta
setblock 407 252 278 minecraft:light[level=12]
setblock 407 252 285 minecraft:light[level=12]
setblock 407 252 292 minecraft:light[level=12]
setblock 407 252 299 minecraft:light[level=12]
setblock 407 252 306 minecraft:light[level=12]
setblock 407 252 313 minecraft:light[level=12]
setblock 407 252 316 minecraft:stripped_oak_log
fill 408 252 316 408 255 316 minecraft:red_terracotta
fill 410 252 315 412 252 315 minecraft:red_terracotta
setblock 412 252 316 minecraft:stripped_oak_log
fill 413 252 316 413 255 316 minecraft:red_terracotta
setblock 414 252 278 minecraft:light[level=12]
setblock 414 252 285 minecraft:light[level=12]
setblock 414 252 292 minecraft:light[level=12]
setblock 414 252 299 minecraft:light[level=12]
setblock 414 252 306 minecraft:light[level=12]
fill 414 252 310 414 258 310 minecraft:green_concrete
setblock 414 252 313 minecraft:light[level=12]
setblock 415 252 287 minecraft:red_terracotta
setblock 415 252 288 minecraft:stripped_oak_log
fill 415 252 289 415 255 289 minecraft:red_terracotta
fill 415 252 291 415 252 292 minecraft:red_terracotta
setblock 415 252 306 minecraft:red_terracotta
setblock 415 252 308 minecraft:stripped_oak_log
fill 415 252 309 415 253 310 minecraft:red_terracotta
setblock 416 252 287 minecraft:stripped_oak_log
fill 416 252 288 416 255 288 minecraft:red_terracotta
setblock 416 252 292 minecraft:stripped_oak_log
fill 416 252 293 416 255 293 minecraft:red_terracotta
fill 416 252 295 416 253 295 minecraft:red_terracotta
setblock 416 252 303 minecraft:red_terracotta
setblock 416 252 307 minecraft:stripped_oak_log
fill 416 252 308 416 255 308 minecraft:red_terracotta
setblock 416 252 312 minecraft:stripped_oak_log
setblock 417 252 286 minecraft:stripped_oak_log
fill 417 252 287 417 255 287 minecraft:red_terracotta
setblock 417 252 291 minecraft:stripped_oak_log
fill 417 252 292 417 255 292 minecraft:red_terracotta
setblock 417 252 296 minecraft:stripped_oak_log
fill 417 252 297 417 255 297 minecraft:red_terracotta
setblock 417 252 301 minecraft:stripped_oak_log
fill 417 252 302 417 254 302 minecraft:red_terracotta
setblock 417 252 306 minecraft:stripped_oak_log
fill 417 252 307 417 255 307 minecraft:red_terracotta
setblock 417 252 311 minecraft:stripped_oak_log
fill 417 252 312 417 255 312 minecraft:red_terracotta
fill 418 252 276 418 255 316 minecraft:orange_terracotta
fill 377 253 281 377 253 284 minecraft:red_terracotta
setblock 377 253 285 minecraft:stripped_oak_log
fill 377 253 286 377 256 286 minecraft:red_terracotta
setblock 377 253 290 minecraft:stripped_oak_log
fill 377 253 291 377 256 291 minecraft:red_terracotta
setblock 377 253 295 minecraft:stripped_oak_log
fill 377 253 296 377 256 296 minecraft:red_terracotta
setblock 377 253 310 minecraft:stripped_oak_log
fill 377 253 311 377 255 312 minecraft:red_terracotta
setblock 378 253 285 minecraft:red_terracotta
setblock 378 253 289 minecraft:stripped_oak_log
fill 378 253 290 378 256 290 minecraft:red_terracotta
setblock 386 253 276 minecraft:stripped_oak_log
setblock 386 253 316 minecraft:stripped_oak_log
setblock 387 253 276 minecraft:shroomlight
setblock 387 253 278 minecraft:shroomlight
setblock 387 253 315 minecraft:stripped_oak_log
fill 387 253 316 390 253 316 minecraft:red_terracotta
setblock 388 253 277 minecraft:shroomlight
setblock 388 253 279 minecraft:shroomlight
fill 388 253 315 388 256 315 minecraft:red_terracotta
setblock 389 253 276 minecraft:shroomlight
setblock 389 253 277 minecraft:red_terracotta
setblock 389 253 278 minecraft:shroomlight
fill 389 253 314 392 253 314 minecraft:red_terracotta
setblock 390 253 277 minecraft:shroomlight
setblock 390 253 279 minecraft:shroomlight
setblock 391 253 276 minecraft:shroomlight
fill 391 253 277 391 256 277 minecraft:red_terracotta
setblock 391 253 278 minecraft:shroomlight
setblock 391 253 316 minecraft:stripped_oak_log
fill 392 253 276 392 256 276 minecraft:red_terracotta
setblock 392 253 277 minecraft:shroomlight
setblock 392 253 279 minecraft:shroomlight
setblock 392 253 315 minecraft:stripped_oak_log
fill 392 253 316 392 256 316 minecraft:red_terracotta
setblock 393 253 276 minecraft:shroomlight
setblock 393 253 278 minecraft:shroomlight
setblock 393 253 314 minecraft:stripped_oak_log
fill 393 253 315 393 256 315 minecraft:red_terracotta
fill 394 253 276 394 254 276 minecraft:red_terracotta
setblock 394 253 277 minecraft:shroomlight
setblock 394 253 279 minecraft:shroomlight
fill 394 253 314 394 256 314 minecraft:red_terracotta
setblock 395 253 276 minecraft:shroomlight
setblock 395 253 278 minecraft:shroomlight
setblock 396 253 276 minecraft:stripped_oak_log
setblock 396 253 277 minecraft:shroomlight
setblock 396 253 279 minecraft:shroomlight
fill 396 253 314 396 254 314 minecraft:red_terracotta
setblock 396 253 316 minecraft:stripped_oak_log
setblock 397 253 276 minecraft:shroomlight
setblock 397 253 278 minecraft:shroomlight
setblock 397 253 315 minecraft:stripped_oak_log
fill 397 253 316 397 256 316 minecraft:red_terracotta
setblock 398 253 277 minecraft:shroomlight
setblock 398 253 279 minecraft:shroomlight
fill 398 253 315 398 256 315 minecraft:red_terracotta
setblock 399 253 276 minecraft:shroomlight
setblock 399 253 278 minecraft:shroomlight
setblock 401 253 316 minecraft:stripped_oak_log
fill 402 253 316 405 253 316 minecraft:red_terracotta
setblock 406 253 316 minecraft:stripped_oak_log
setblock 407 253 315 minecraft:stripped_oak_log
fill 407 253 316 407 256 316 minecraft:red_terracotta
fill 408 253 315 411 253 315 minecraft:red_terracotta
setblock 411 253 316 minecraft:stripped_oak_log
setblock 412 253 315 minecraft:stripped_oak_log
fill 412 253 316 412 256 316 minecraft:red_terracotta
fill 413 253 315 413 256 315 minecraft:red_terracotta
setblock 415 253 287 minecraft:stripped_oak_log
fill 415 253 288 415 256 288 minecraft:red_terracotta
setblock 415 253 291 minecraft:red_terracotta
setblock 415 253 292 minecraft:stripped_oak_log
fill 415 253 293 415 256 293 minecraft:red_terracotta
setblock 415 253 307 minecraft:stripped_oak_log
setblock 415 253 308 minecraft:red_terracotta
setblock 415 253 316 minecraft:red_terracotta
setblock 416 253 286 minecraft:stripped_oak_log
fill 416 253 287 416 256 287 minecraft:red_terracotta
setblock 416 253 291 minecraft:stripped_oak_log
fill 416 253 292 416 256 292 minecraft:red_terracotta
setblock 416 253 296 minecraft:stripped_oak_log
setblock 416 253 306 minecraft:stripped_oak_log
fill 416 253 307 416 255 307 minecraft:red_terracotta
setblock 416 253 311 minecraft:stripped_oak_log
fill 416 253 312 416 256 312 minecraft:red_terracotta
setblock 417 253 285 minecraft:stripped_oak_log
fill 417 253 286 417 256 286 minecraft:red_terracotta
setblock 417 253 290 minecraft:stripped_oak_log
fill 417 253 291 417 256 291 minecraft:red_terracotta
setblock 417 253 295 minecraft:stripped_oak_log
fill 417 253 296 417 256 296 minecraft:red_terracotta
setblock 417 253 300 minecraft:stripped_oak_log
fill 417 253 301 417 255 301 minecraft:red_terracotta
setblock 417 253 305 minecraft:stripped_oak_log
fill 417 253 306 417 256 306 minecraft:red_terracotta
setblock 417 253 310 minecraft:stripped_oak_log
fill 417 253 311 417 256 311 minecraft:red_terracotta
setblock 417 253 314 minecraft:red_terracotta
fill 377 254 281 377 254 283 minecraft:red_terracotta
setblock 377 254 284 minecraft:stripped_oak_log
fill 377 254 285 377 257 285 minecraft:red_terracotta
setblock 377 254 289 minecraft:stripped_oak_log
fill 377 254 290 377 257 290 minecraft:red_terracotta
setblock 377 254 294 minecraft:stripped_oak_log
fill 377 254 295 377 257 295 minecraft:red_terracotta
setblock 377 254 309 minecraft:stripped_oak_log
fill 377 254 310 377 256 310 minecraft:red_terracotta
setblock 377 254 313 minecraft:red_terracotta
fill 378 254 285 378 256 285 minecraft:green_concrete
setblock 378 254 288 minecraft:stripped_oak_log
fill 378 254 289 378 257 289 minecraft:red_terracotta
setblock 378 254 293 minecraft:stripped_oak_log
setblock 384 254 276 minecraft:red_terracotta
setblock 384 254 316 minecraft:red_terracotta
setblock 385 254 276 minecraft:stripped_oak_log
setblock 385 254 316 minecraft:stripped_oak_log
fill 386 254 276 387 256 276 minecraft:red_terracotta
setblock 386 254 315 minecraft:stripped_oak_log
fill 386 254 316 389 254 316 minecraft:red_terracotta
fill 387 254 277 388 254 277 minecraft:red_terracotta
fill 387 254 278 387 255 278 minecraft:green_concrete
fill 387 254 315 387 257 315 minecraft:red_terracotta
fill 388 254 279 388 255 279 minecraft:stripped_oak_log
fill 388 254 314 391 254 314 minecraft:red_terracotta
setblock 389 254 276 minecraft:red_terracotta
fill 389 254 277 389 254 278 minecraft:stripped_oak_log
setblock 390 254 276 minecraft:stripped_oak_log
fill 390 254 277 390 257 277 minecraft:red_terracotta
fill 390 254 279 390 255 279 minecraft:stripped_oak_log
fill 390 254 313 392 254 313 minecraft:red_terracotta
setblock 390 254 315 minecraft:red_terracotta
setblock 390 254 316 minecraft:stripped_oak_log
fill 391 254 276 391 257 276 minecraft:red_terracotta
fill 391 254 278 391 255 278 minecraft:stripped_oak_log
setblock 391 254 315 minecraft:stripped_oak_log
fill 391 254 316 391 257 316 minecraft:red_terracotta
fill 392 254 277 392 255 277 minecraft:red_terracotta
fill 392 254 279 392 255 279 minecraft:stripped_oak_log
fill 392 254 299 392 260 299 minecraft:stripped_oak_log
setblock 392 254 314 minecraft:stripped_oak_log
fill 392 254 315 392 257 315 minecraft:red_terracotta
fill 393 254 276 393 255 276 minecraft:red_terracotta
fill 393 254 278 393 255 278 minecraft:stripped_oak_log
setblock 393 254 313 minecraft:stripped_oak_log
fill 393 254 314 393 257 314 minecraft:red_terracotta
setblock 394 254 277 minecraft:stripped_oak_log
fill 394 254 279 394 255 279 minecraft:stripped_oak_log
fill 394 254 313 394 257 313 minecraft:red_terracotta
setblock 395 254 276 minecraft:stripped_oak_log
fill 395 254 278 395 255 278 minecraft:stripped_oak_log
setblock 395 254 316 minecraft:stripped_oak_log
fill 396 254 276 396 257 276 minecraft:red_terracotta
fill 396 254 277 396 255 277 minecraft:stripped_oak_log
fill 396 254 279 396 255 279 minecraft:stripped_oak_log
setblock 396 254 315 minecraft:stripped_oak_log
fill 396 254 316 396 257 316 minecraft:red_terracotta
fill 397 254 276 397 255 276 minecraft:stripped_oak_log
fill 397 254 278 397 255 278 minecraft:stripped_oak_log
setblock 397 254 314 minecraft:stripped_oak_log
fill 397 254 315 397 257 315 minecraft:red_terracotta
fill 398 254 277 398 255 277 minecraft:stripped_oak_log
fill 398 254 279 398 255 279 minecraft:stripped_oak_log
fill 399 254 276 399 255 276 minecraft:stripped_oak_log
fill 399 254 278 399 255 278 minecraft:stripped_oak_log
fill 399 254 315 400 254 315 minecraft:red_terracotta
setblock 400 254 316 minecraft:stripped_oak_log
fill 401 254 316 404 254 316 minecraft:red_terracotta
fill 404 254 315 405 254 315 minecraft:red_terracotta
setblock 405 254 316 minecraft:stripped_oak_log
setblock 406 254 315 minecraft:stripped_oak_log
fill 406 254 316 406 257 316 minecraft:red_terracotta
setblock 407 254 314 minecraft:stripped_oak_log
fill 407 254 315 410 254 315 minecraft:red_terracotta
fill 408 254 314 411 254 314 minecraft:red_terracotta
setblock 409 254 316 minecraft:red_terracotta
setblock 410 254 316 minecraft:stripped_oak_log
setblock 411 254 315 minecraft:stripped_oak_log
fill 411 254 316 411 257 316 minecraft:red_terracotta
setblock 412 254 314 minecraft:stripped_oak_log
fill 412 254 315 412 257 315 minecraft:red_terracotta
fill 414 254 315 414 255 315 minecraft:red_terracotta
fill 415 254 287 415 256 287 minecraft:red_terracotta
setblock 415 254 291 minecraft:stripped_oak_log
fill 415 254 292 415 257 292 minecraft:red_terracotta
fill 415 254 294 415 254 295 minecraft:red_terracotta
setblock 415 254 316 minecraft:stripped_oak_log
setblock 416 254 285 minecraft:stripped_oak_log
fill 416 254 286 416 257 286 minecraft:red_terracotta
setblock 416 254 290 minecraft:stripped_oak_log
fill 416 254 291 416 257 291 minecraft:red_terracotta
setblock 416 254 295 minecraft:stripped_oak_log
fill 416 254 296 416 256 297 minecraft:red_terracotta
setblock 416 254 306 minecraft:red_terracotta
setblock 416 254 310 minecraft:stripped_oak_log
fill 416 254 311 416 256 311 minecraft:red_terracotta
setblock 417 254 284 minecraft:stripped_oak_log
fill 417 254 285 417 257 285 minecraft:red_terracotta
setblock 417 254 289 minecraft:stripped_oak_log
fill 417 254 290 417 257 290 minecraft:red_terracotta
setblock 417 254 294 minecraft:stripped_oak_log
fill 417 254 295 417 257 295 minecraft:red_terracotta
setblock 417 254 299 minecraft:stripped_oak_log
fill 417 254 300 417 257 300 minecraft:red_terracotta
setblock 417 254 303 minecraft:red_terracotta
setblock 417 254 304 minecraft:stripped_oak_log
fill 417 254 305 417 255 305 minecraft:red_terracotta
setblock 417 254 309 minecraft:stripped_oak_log
fill 417 254 310 417 257 310 minecraft:red_terracotta
setblock 417 254 314 minecraft:stripped_oak_log
fill 377 255 281 377 255 282 minecraft:red_terracotta
setblock 377 255 283 minecraft:stripped_oak_log
fill 377 255 284 377 258 284 minecraft:red_terracotta
setblock 377 255 288 minecraft:stripped_oak_log
fill 377 255 289 377 258 289 minecraft:red_terracotta
setblock 377 255 292 minecraft:red_terracotta
setblock 377 255 293 minecraft:stripped_oak_log
fill 377 255 294 377 258 294 minecraft:red_terracotta
setblock 377 255 313 minecraft:stripped_oak_log
fill 377 255 314 377 257 315 minecraft:red_terracotta
setblock 378 255 287 minecraft:stripped_oak_log
fill 378 255 288 378 258 288 minecraft:red_terracotta
setblock 378 255 292 minecraft:stripped_oak_log
fill 378 255 293 378 258 293 minecraft:red_terracotta
fill 382 255 276 383 255 276 minecraft:red_terracotta
fill 382 255 316 383 255 316 minecraft:red_terracotta
setblock 384 255 276 minecraft:stripped_oak_log
setblock 384 255 315 minecraft:red_terracotta
setblock 384 255 316 minecraft:stripped_oak_log
fill 385 255 276 385 258 276 minecraft:red_terracotta
setblock 385 255 315 minecraft:stripped_oak_log
fill 385 255 316 388 255 316 minecraft:red_terracotta
fill 386 255 277 387 255 277 minecraft:red_terracotta
setblock 386 255 314 minecraft:stripped_oak_log
fill 386 255 315 386 258 315 minecraft:red_terracotta
fill 387 255 314 390 255 314 minecraft:red_terracotta
setblock 388 255 277 minecraft:stripped_oak_log
setblock 389 255 276 minecraft:stripped_oak_log
fill 389 255 277 389 258 277 minecraft:red_terracotta
setblock 389 255 278 minecraft:stripped_oak_log
fill 389 255 313 391 255 313 minecraft:red_terracotta
setblock 389 255 316 minecraft:stripped_oak_log
fill 390 255 276 390 258 276 minecraft:red_terracotta
setblock 390 255 315 minecraft:stripped_oak_log
fill 390 255 316 390 258 316 minecraft:red_terracotta
setblock 391 255 314 minecraft:stripped_oak_log
fill 391 255 315 391 258 315 minecraft:red_terracotta
setblock 392 255 313 minecraft:stripped_oak_log
fill 392 255 314 392 258 314 minecraft:red_terracotta
setblock 393 255 277 minecraft:stripped_oak_log
fill 393 255 313 393 258 313 minecraft:red_terracotta
setblock 394 255 276 minecraft:stripped_oak_log
fill 394 255 277 394 258 277 minecraft:red_terracotta
setblock 394 255 316 minecraft:stripped_oak_log
fill 395 255 276 395 258 276 minecraft:red_terracotta
fill 395 255 313 395 256 313 minecraft:red_terracotta
setblock 395 255 315 minecraft:stripped_oak_log
fill 395 255 316 395 258 316 minecraft:red_terracotta
setblock 396 255 314 minecraft:stripped_oak_log
fill 396 255 315 396 258 315 minecraft:red_terracotta
fill 397 255 314 398 257 314 minecraft:red_terracotta
setblock 399 255 315 minecraft:red_terracotta
setblock 399 255 316 minecraft:stripped_oak_log
setblock 400 255 315 minecraft:stripped_oak_log
fill 400 255 316 403 255 316 minecraft:red_terracotta
fill 401 255 315 404 255 315 minecraft:red_terracotta
setblock 404 255 316 minecraft:stripped_oak_log
setblock 405 255 314 minecraft:red_terracotta
setblock 405 255 315 minecraft:stripped_oak_log
fill 405 255 316 405 258 316 minecraft:red_terracotta
setblock 406 255 314 minecraft:stripped_oak_log
fill 406 255 315 409 255 315 minecraft:red_terracotta
fill 407 255 314 410 255 314 minecraft:red_terracotta
setblock 409 255 276 minecraft:stripped_oak_log
fill 409 255 313 410 256 313 minecraft:red_terracotta
setblock 409 255 316 minecraft:stripped_oak_log
fill 410 255 276 412 256 276 minecraft:red_terracotta
setblock 410 255 315 minecraft:stripped_oak_log
fill 410 255 316 410 258 316 minecraft:red_terracotta
setblock 411 255 314 minecraft:stripped_oak_log
fill 411 255 315 411 258 315 minecraft:red_terracotta
fill 412 255 314 413 257 314 minecraft:red_terracotta
setblock 414 255 290 minecraft:red_terracotta
setblock 414 255 291 minecraft:stripped_oak_log
fill 414 255 292 414 257 293 minecraft:red_terracotta
fill 414 255 311 414 257 311 minecraft:green_concrete
setblock 414 255 316 minecraft:stripped_oak_log
setblock 415 255 290 minecraft:stripped_oak_log
fill 415 255 291 415 258 291 minecraft:red_terracotta
setblock 415 255 294 minecraft:red_terracotta
setblock 415 255 295 minecraft:stripped_oak_log
fill 415 255 296 415 258 296 minecraft:red_terracotta
fill 415 255 316 416 257 316 minecraft:red_terracotta
fill 416 255 285 416 256 285 minecraft:red_terracotta
setblock 416 255 289 minecraft:stripped_oak_log
fill 416 255 290 416 258 290 minecraft:red_terracotta
setblock 416 255 294 minecraft:stripped_oak_log
fill 416 255 295 416 258 295 minecraft:red_terracotta
setblock 416 255 298 minecraft:red_terracotta
setblock 416 255 309 minecraft:stripped_oak_log
fill 416 255 310 416 256 310 minecraft:red_terracotta
setblock 416 255 313 minecraft:red_terracotta
setblock 417 255 283 minecraft:stripped_oak_log
fill 417 255 284 417 258 284 minecraft:red_terracotta
setblock 417 255 288 minecraft:stripped_oak_log
fill 417 255 289 417 258 289 minecraft:red_terracotta
setblock 417 255 293 minecraft:stripped_oak_log
fill 417 255 294 417 258 294 minecraft:red_terracotta
setblock 417 255 298 minecraft:stripped_oak_log
fill 417 255 299 417 258 299 minecraft:red_terracotta
setblock 417 255 303 minecraft:stripped_oak_log
setblock 417 255 304 minecraft:red_terracotta
setblock 417 255 308 minecraft:stripped_oak_log
fill 417 255 309 417 257 309 minecraft:red_terracotta
setblock 417 255 313 minecraft:stripped_oak_log
fill 417 255 314 417 257 315 minecraft:red_terracotta
fill 376 256 275 376 259 317 minecraft:red_terracotta
fill 377 256 275 377 256 276 minecraft:red_terracotta
setblock 377 256 277 minecraft:stripped_oak_log
fill 377 256 278 377 259 278 minecraft:red_terracotta
fill 377 256 280 377 256 281 minecraft:red_terracotta
setblock 377 256 282 minecraft:stripped_oak_log
fill 377 256 283 377 259 283 minecraft:red_terracotta
setblock 377 256 287 minecraft:stripped_oak_log
fill 377 256 288 377 259 288 minecraft:red_terracotta
setblock 377 256 292 minecraft:stripped_oak_log
fill 377 256 293 377 259 293 minecraft:red_terracotta
setblock 377 256 297 minecraft:stripped_oak_log
setblock 377 256 311 minecraft:red_terracotta
setblock 377 256 312 minecraft:stripped_oak_log
fill 377 256 313 377 259 313 minecraft:red_terracotta
fill 377 256 316 377 256 317 minecraft:red_terracotta
fill 378 256 275 418 259 275 minecraft:red_terracotta
setblock 378 256 276 minecraft:stripped_oak_log
setblock 378 256 286 minecraft:stripped_oak_log
fill 378 256 287 378 258 287 minecraft:red_terracotta
setblock 378 256 291 minecraft:stripped_oak_log
fill 378 256 292 378 259 292 minecraft:red_terracotta
fill 378 256 294 378 257 294 minecraft:red_terracotta
setblock 378 256 316 minecraft:stripped_oak_log
fill 378 256 317 418 259 317 minecraft:red_terracotta
fill 379 256 276 382 256 276 minecraft:red_terracotta
setblock 379 256 278 minecraft:light[level=15]
setblock 379 256 286 minecraft:light[level=15]
setblock 379 256 294 minecraft:light[level=15]
setblock 379 256 302 minecraft:light[level=15]
setblock 379 256 310 minecraft:light[level=15]
fill 379 256 316 382 256 316 minecraft:red_terracotta
setblock 383 256 276 minecraft:stripped_oak_log
setblock 383 256 315 minecraft:red_terracotta
setblock 383 256 316 minecraft:stripped_oak_log
fill 384 256 276 384 258 277 minecraft:red_terracotta
setblock 384 256 315 minecraft:stripped_oak_log
fill 384 256 316 387 256 316 minecraft:red_terracotta
fill 385 256 277 386 256 277 minecraft:red_terracotta
setblock 385 256 314 minecraft:stripped_oak_log
fill 385 256 315 385 259 315 minecraft:red_terracotta
fill 386 256 314 389 256 314 minecraft:red_terracotta
setblock 387 256 277 minecraft:stripped_oak_log
setblock 387 256 278 minecraft:light[level=15]
setblock 387 256 286 minecraft:light[level=15]
setblock 387 256 294 minecraft:light[level=15]
setblock 387 256 302 minecraft:light[level=15]
setblock 387 256 310 minecraft:light[level=15]
fill 387 256 313 390 256 313 minecraft:red_terracotta
setblock 388 256 276 minecraft:stripped_oak_log
fill 388 256 277 388 258 278 minecraft:red_terracotta
setblock 388 256 316 minecraft:stripped_oak_log
fill 389 256 276 389 259 276 minecraft:red_terracotta
fill 389 256 278 390 256 278 minecraft:red_terracotta
setblock 389 256 315 minecraft:stripped_oak_log
fill 389 256 316 389 259 316 minecraft:red_terracotta
setblock 390 256 314 minecraft:stripped_oak_log
fill 390 256 315 390 259 315 minecraft:red_terracotta
fill 391 256 300 392 271 302 minecraft:stripped_oak_log
setblock 391 256 313 minecraft:stripped_oak_log
fill 391 256 314 391 259 314 minecraft:red_terracotta
setblock 392 256 277 minecraft:stripped_oak_log
fill 392 256 313 392 259 313 minecraft:red_terracotta
setblock 393 256 276 minecraft:stripped_oak_log
fill 393 256 277 393 259 277 minecraft:red_terracotta
fill 393 256 301 393 271 302 minecraft:stripped_oak_log
setblock 393 256 316 minecraft:stripped_oak_log
fill 394 256 276 394 259 276 minecraft:red_terracotta
setblock 394 256 315 minecraft:stripped_oak_log
fill 394 256 316 394 259 316 minecraft:red_terracotta
setblock 395 256 278 minecraft:light[level=15]
setblock 395 256 286 minecraft:light[level=15]
setblock 395 256 294 minecraft:light[level=15]
setblock 395 256 310 minecraft:light[level=15]
setblock 395 256 314 minecraft:stripped_oak_log
fill 395 256 315 395 259 315 minecraft:red_terracotta
fill 396 256 314 396 259 314 minecraft:red_terracotta
setblock 397 256 276 minecraft:red_terracotta
setblock 398 256 316 minecraft:stripped_oak_log
setblock 399 256 314 minecraft:red_terracotta
setblock 399 256 315 minecraft:stripped_oak_log
fill 399 256 316 402 256 316 minecraft:red_terracotta
fill 400 256 315 403 256 315 minecraft:red_terracotta
setblock 403 256 278 minecraft:light[level=15]
setblock 403 256 286 minecraft:light[level=15]
setblock 403 256 294 minecraft:light[level=15]
setblock 403 256 302 minecraft:light[level=15]
setblock 403 256 310 minecraft:light[level=15]
fill 403 256 314 404 256 314 minecraft:red_terracotta
setblock 403 256 316 minecraft:stripped_oak_log
setblock 404 256 315 minecraft:stripped_oak_log
fill 404 256 316 404 259 316 minecraft:red_terracotta
setblock 405 256 314 minecraft:stripped_oak_log
fill 405 256 315 408 256 315 minecraft:red_terracotta
fill 406 256 314 409 256 314 minecraft:red_terracotta
setblock 407 256 276 minecraft:red_terracotta
fill 407 256 313 408 258 313 minecraft:red_terracotta
setblock 408 256 276 minecraft:stripped_oak_log
setblock 408 256 316 minecraft:stripped_oak_log
fill 409 256 276 409 259 276 minecraft:red_terracotta
setblock 409 256 315 minecraft:stripped_oak_log
fill 409 256 316 409 259 316 minecraft:red_terracotta
setblock 410 256 314 minecraft:stripped_oak_log
fill 410 256 315 410 259 315 minecraft:red_terracotta
setblock 411 256 278 minecraft:light[level=15]
setblock 411 256 286 minecraft:light[level=15]
setblock 411 256 294 minecraft:light[level=15]
setblock 411 256 302 minecraft:light[level=15]
setblock 411 256 310 minecraft:light[level=15]
fill 411 256 314 411 259 314 minecraft:red_terracotta
setblock 413 256 276 minecraft:stripped_oak_log
setblock 413 256 316 minecraft:stripped_oak_log
setblock 414 256 290 minecraft:stripped_oak_log
fill 414 256 291 414 258 291 minecraft:red_terracotta
setblock 414 256 294 minecraft:red_terracotta
setblock 414 256 315 minecraft:stripped_oak_log
fill 414 256 316 414 259 316 minecraft:red_terracotta
setblock 415 256 289 minecraft:stripped_oak_log
fill 415 256 290 415 259 290 minecraft:red_terracotta
setblock 415 256 294 minecraft:stripped_oak_log
fill 415 256 295 415 259 295 minecraft:red_terracotta
fill 415 256 315 415 257 315 minecraft:red_terracotta
setblock 416 256 288 minecraft:stripped_oak_log
fill 416 256 289 416 259 289 minecraft:red_terracotta
setblock 416 256 293 minecraft:stripped_oak_log
fill 416 256 294 416 259 294 minecraft:red_terracotta
setblock 416 256 298 minecraft:stripped_oak_log
setblock 416 256 309 minecraft:red_terracotta
setblock 416 256 313 minecraft:stripped_oak_log
setblock 417 256 287 minecraft:stripped_oak_log
fill 417 256 288 418 259 288 minecraft:red_terracotta
setblock 417 256 292 minecraft:stripped_oak_log
fill 417 256 293 418 259 293 minecraft:red_terracotta
setblock 417 256 297 minecraft:stripped_oak_log
fill 417 256 298 418 259 298 minecraft:red_terracotta
setblock 417 256 307 minecraft:stripped_oak_log
fill 417 256 308 418 257 308 minecraft:red_terracotta
setblock 417 256 312 minecraft:stripped_oak_log
fill 417 256 313 418 259 313 minecraft:red_terracotta
fill 418 256 276 418 259 287 minecraft:red_terracotta
fill 418 256 289 418 259 292 minecraft:red_terracotta
fill 418 256 294 418 259 297 minecraft:red_terracotta
fill 418 256 299 418 259 307 minecraft:red_terracotta
fill 418 256 309 418 259 312 minecraft:red_terracotta
fill 418 256 314 418 259 316 minecraft:red_terracotta
fill 377 257 275 377 259 275 minecraft:red_terracotta
setblock 377 257 276 minecraft:stripped_oak_log
fill 377 257 277 377 260 277 minecraft:red_terracotta
fill 377 257 279 377 257 280 minecraft:red_terracotta
setblock 377 257 281 minecraft:stripped_oak_log
fill 377 257 282 377 258 282 minecraft:red_terracotta
setblock 377 257 286 minecraft:stripped_oak_log
fill 377 257 287 377 260 287 minecraft:red_terracotta
setblock 377 257 291 minecraft:stripped_oak_log
fill 377 257 292 377 260 292 minecraft:red_terracotta
setblock 377 257 296 minecraft:stripped_oak_log
fill 377 257 297 377 260 297 minecraft:red_terracotta
setblock 377 257 311 minecraft:stripped_oak_log
fill 377 257 312 377 258 312 minecraft:red_terracotta
setblock 377 257 316 minecraft:stripped_oak_log
fill 377 257 317 377 259 317 minecraft:red_terracotta
fill 378 257 276 381 257 276 minecraft:red_terracotta
setblock 378 257 286 minecraft:red_terracotta
setblock 378 257 290 minecraft:stripped_oak_log
fill 378 257 291 378 259 291 minecraft:red_terracotta
fill 378 257 316 381 257 316 minecraft:red_terracotta
setblock 382 257 276 minecraft:stripped_oak_log
setblock 382 257 315 minecraft:red_terracotta
setblock 382 257 316 minecraft:stripped_oak_log
fill 383 257 276 383 259 277 minecraft:red_terracotta
setblock 383 257 315 minecraft:stripped_oak_log
fill 383 257 316 386 257 316 minecraft:red_terracotta
setblock 384 257 314 minecraft:stripped_oak_log
fill 384 257 315 384 260 315 minecraft:red_terracotta
setblock 385 257 277 minecraft:red_terracotta
fill 385 257 314 388 257 314 minecraft:red_terracotta
setblock 386 257 276 minecraft:red_terracotta
setblock 386 257 277 minecraft:stripped_oak_log
setblock 387 257 276 minecraft:stripped_oak_log
fill 387 257 277 387 259 278 minecraft:red_terracotta
fill 387 257 313 389 257 313 minecraft:red_terracotta
setblock 387 257 316 minecraft:stripped_oak_log
fill 388 257 276 388 260 276 minecraft:red_terracotta
setblock 388 257 315 minecraft:stripped_oak_log
fill 388 257 316 388 260 316 minecraft:red_terracotta
setblock 389 257 278 minecraft:red_terracotta
setblock 389 257 314 minecraft:stripped_oak_log
fill 389 257 315 389 260 315 minecraft:red_terracotta
setblock 390 257 278 minecraft:stripped_oak_log
setblock 390 257 313 minecraft:stripped_oak_log
fill 390 257 314 390 260 314 minecraft:red_terracotta
setblock 391 257 277 minecraft:stripped_oak_log
fill 391 257 313 391 260 313 minecraft:red_terracotta
setblock 392 257 276 minecraft:stripped_oak_log
fill 392 257 277 392 260 277 minecraft:red_terracotta
setblock 392 257 316 minecraft:stripped_oak_log
fill 393 257 276 393 260 276 minecraft:red_terracotta
setblock 393 257 315 minecraft:stripped_oak_log
fill 393 257 316 393 260 316 minecraft:red_terracotta
setblock 394 257 314 minecraft:stripped_oak_log
fill 394 257 315 394 260 315 minecraft:red_terracotta
fill 395 257 302 395 271 302 minecraft:stripped_oak_log
setblock 395 257 313 minecraft:stripped_oak_log
fill 395 257 314 395 260 314 minecraft:red_terracotta
setblock 397 257 276 minecraft:stripped_oak_log
setblock 397 257 316 minecraft:stripped_oak_log
setblock 398 257 315 minecraft:stripped_oak_log
fill 398 257 316 401 257 316 minecraft:red_terracotta
setblock 399 257 314 minecraft:stripped_oak_log
fill 399 257 315 402 257 315 minecraft:red_terracotta
fill 400 257 314 403 257 314 minecraft:red_terracotta
setblock 402 257 316 minecraft:stripped_oak_log
setblock 403 257 315 minecraft:stripped_oak_log
fill 403 257 316 403 260 316 minecraft:red_terracotta
setblock 404 257 314 minecraft:stripped_oak_log
fill 404 257 315 407 257 315 minecraft:red_terracotta
fill 405 257 276 406 257 276 minecraft:red_terracotta
fill 405 257 314 408 257 314 minecraft:red_terracotta
fill 406 257 313 406 259 313 minecraft:red_terracotta
setblock 407 257 276 minecraft:stripped_oak_log
setblock 407 257 316 minecraft:stripped_oak_log
fill 408 257 276 408 260 276 minecraft:red_terracotta
setblock 408 257 315 minecraft:stripped_oak_log
fill 408 257 316 408 260 316 minecraft:red_terracotta
setblock 409 257 313 minecraft:red_terracotta
setblock 409 257 314 minecraft:stripped_oak_log
fill 409 257 315 409 260 315 minecraft:red_terracotta
fill 410 257 276 411 257 276 minecraft:red_terracotta
setblock 410 257 313 minecraft:stripped_oak_log
fill 410 257 314 410 260 314 minecraft:red_terracotta
setblock 412 257 276 minecraft:stripped_oak_log
setblock 412 257 316 minecraft:stripped_oak_log
fill 413 257 276 414 259 276 minecraft:red_terracotta
setblock 413 257 315 minecraft:stripped_oak_log
fill 413 257 316 413 260 316 minecraft:red_terracotta
setblock 414 257 290 minecraft:red_terracotta
setblock 414 257 294 minecraft:stripped_oak_log
fill 414 257 295 414 258 295 minecraft:red_terracotta
fill 414 257 315 414 258 315 minecraft:red_terracotta
setblock 415 257 288 minecraft:stripped_oak_log
fill 415 257 289 415 258 289 minecraft:red_terracotta
setblock 415 257 293 minecraft:stripped_oak_log
fill 415 257 294 415 260 294 minecraft:red_terracotta
setblock 415 257 297 minecraft:red_terracotta
setblock 416 257 287 minecraft:stripped_oak_log
fill 416 257 288 416 259 288 minecraft:red_terracotta
setblock 416 257 292 minecraft:stripped_oak_log
fill 416 257 293 416 260 293 minecraft:red_terracotta
setblock 416 257 296 minecraft:red_terracotta
setblock 416 257 297 minecraft:stripped_oak_log
fill 416 257 298 416 260 298 minecraft:red_terracotta
setblock 417 257 286 minecraft:stripped_oak_log
fill 417 257 287 417 260 287 minecraft:red_terracotta
setblock 417 257 291 minecraft:stripped_oak_log
fill 417 257 292 417 260 292 minecraft:red_terracotta
setblock 417 257 296 minecraft:stripped_oak_log
fill 417 257 297 417 260 297 minecraft:red_terracotta
setblock 417 257 311 minecraft:stripped_oak_log
fill 417 257 312 417 258 312 minecraft:red_terracotta
setblock 417 257 316 minecraft:stripped_oak_log
fill 377 258 276 380 258 276 minecraft:red_terracotta
setblock 377 258 279 minecraft:red_terracotta
setblock 377 258 280 minecraft:stripped_oak_log
fill 377 258 281 377 259 281 minecraft:red_terracotta
setblock 377 258 285 minecraft:stripped_oak_log
fill 377 258 286 377 260 286 minecraft:red_terracotta
setblock 377 258 290 minecraft:stripped_oak_log
fill 377 258 291 377 261 291 minecraft:red_terracotta
setblock 377 258 295 minecraft:stripped_oak_log
fill 377 258 296 377 261 296 minecraft:red_terracotta
setblock 377 258 314 minecraft:red_terracotta
setblock 377 258 315 minecraft:stripped_oak_log
fill 377 258 316 380 258 316 minecraft:red_terracotta
setblock 378 258 289 minecraft:stripped_oak_log
fill 378 258 290 378 259 290 minecraft:red_terracotta
setblock 378 258 294 minecraft:stripped_oak_log
setblock 379 258 278 minecraft:light[level=12]
setblock 379 258 285 minecraft:light[level=12]
setblock 379 258 292 minecraft:light[level=12]
setblock 379 258 299 minecraft:light[level=12]
setblock 379 258 306 minecraft:light[level=12]
setblock 379 258 313 minecraft:light[level=12]
setblock 381 258 276 minecraft:stripped_oak_log
fill 381 258 277 382 260 277 minecraft:red_terracotta
setblock 381 258 315 minecraft:red_terracotta
setblock 381 258 316 minecraft:stripped_oak_log
fill 382 258 276 382 261 276 minecraft:red_terracotta
setblock 382 258 315 minecraft:stripped_oak_log
fill 382 258 316 385 258 316 minecraft:red_terracotta
fill 383 258 315 383 261 315 minecraft:red_terracotta
fill 384 258 314 387 258 314 minecraft:red_terracotta
setblock 385 258 277 minecraft:stripped_oak_log
fill 385 258 278 386 260 278 minecraft:red_terracotta
setblock 386 258 276 minecraft:stripped_oak_log
fill 386 258 277 386 261 277 minecraft:red_terracotta
setblock 386 258 285 minecraft:light[level=12]
setblock 386 258 292 minecraft:light[level=12]
setblock 386 258 299 minecraft:light[level=12]
setblock 386 258 306 minecraft:light[level=12]
fill 386 258 313 388 258 313 minecraft:red_terracotta
setblock 386 258 316 minecraft:stripped_oak_log
fill 387 258 276 387 261 276 minecraft:red_terracotta
setblock 387 258 315 minecraft:stripped_oak_log
fill 387 258 316 387 261 316 minecraft:red_terracotta
setblock 388 258 314 minecraft:stripped_oak_log
fill 388 258 315 388 261 315 minecraft:red_terracotta
setblock 389 258 278 minecraft:stripped_oak_log
setblock 389 258 313 minecraft:stripped_oak_log
fill 389 258 314 389 261 314 minecraft:red_terracotta
setblock 390 258 277 minecraft:stripped_oak_log
fill 390 258 278 390 259 278 minecraft:red_terracotta
fill 390 258 313 390 260 313 minecraft:red_terracotta
setblock 391 258 276 minecraft:stripped_oak_log
fill 391 258 277 391 261 277 minecraft:red_terracotta
setblock 391 258 316 minecraft:stripped_oak_log
fill 392 258 276 392 261 276 minecraft:red_terracotta
setblock 392 258 315 minecraft:stripped_oak_log
fill 392 258 316 392 261 316 minecraft:red_terracotta
setblock 393 258 278 minecraft:light[level=12]
setblock 393 258 285 minecraft:light[level=12]
setblock 393 258 292 minecraft:light[level=12]
setblock 393 258 299 minecraft:light[level=12]
setblock 393 258 306 minecraft:light[level=12]
setblock 393 258 314 minecraft:stripped_oak_log
fill 393 258 315 393 261 315 minecraft:red_terracotta
setblock 394 258 313 minecraft:stripped_oak_log
fill 394 258 314 394 261 314 minecraft:red_terracotta
setblock 396 258 276 minecraft:stripped_oak_log
setblock 396 258 316 minecraft:stripped_oak_log
fill 397 258 276 397 260 276 minecraft:red_terracotta
setblock 397 258 314 minecraft:red_terracotta
setblock 397 258 315 minecraft:stripped_oak_log
fill 397 258 316 400 258 316 minecraft:red_terracotta
setblock 398 258 314 minecraft:stripped_oak_log
fill 398 258 315 401 258 315 minecraft:red_terracotta
fill 399 258 314 402 258 314 minecraft:red_terracotta
setblock 400 258 278 minecraft:light[level=12]
setblock 400 258 285 minecraft:light[level=12]
setblock 400 258 292 minecraft:light[level=12]
setblock 400 258 299 minecraft:light[level=12]
setblock 400 258 306 minecraft:light[level=12]
setblock 400 258 313 minecraft:light[level=12]
setblock 401 258 316 minecraft:stripped_oak_log
setblock 402 258 315 minecraft:stripped_oak_log
fill 402 258 316 402 261 316 minecraft:red_terracotta
fill 403 258 276 405 258 276 minecraft:red_terracotta
setblock 403 258 314 minecraft:stripped_oak_log
fill 403 258 315 406 258 315 minecraft:red_terracotta
fill 404 258 314 407 258 314 minecraft:red_terracotta
setblock 405 258 313 minecraft:red_terracotta
setblock 406 258 276 minecraft:stripped_oak_log
setblock 406 258 316 minecraft:stripped_oak_log
fill 407 258 276 407 261 276 minecraft:red_terracotta
setblock 407 258 278 minecraft:light[level=12]
setblock 407 258 285 minecraft:light[level=12]
setblock 407 258 292 minecraft:light[level=12]
setblock 407 258 299 minecraft:light[level=12]
setblock 407 258 306 minecraft:light[level=12]
setblock 407 258 315 minecraft:stripped_oak_log
fill 407 258 316 407 261 316 minecraft:red_terracotta
setblock 408 258 314 minecraft:stripped_oak_log
fill 408 258 315 408 261 315 minecraft:red_terracotta
setblock 409 258 313 minecraft:stripped_oak_log
fill 409 258 314 409 260 314 minecraft:red_terracotta
setblock 410 258 276 minecraft:red_terracotta
setblock 410 258 313 minecraft:red_terracotta
setblock 411 258 276 minecraft:stripped_oak_log
setblock 411 258 316 minecraft:stripped_oak_log
fill 412 258 276 412 261 276 minecraft:red_terracotta
setblock 412 258 314 minecraft:red_terracotta
setblock 412 258 315 minecraft:stripped_oak_log
fill 412 258 316 412 261 316 minecraft:red_terracotta
fill 413 258 315 413 259 315 minecraft:red_terracotta
setblock 414 258 278 minecraft:light[level=12]
setblock 414 258 285 minecraft:light[level=12]
setblock 414 258 292 minecraft:red_terracotta
setblock 414 258 293 minecraft:stripped_oak_log
fill 414 258 294 414 259 294 minecraft:red_terracotta
setblock 414 258 299 minecraft:light[level=12]
setblock 414 258 306 minecraft:light[level=12]
setblock 414 258 313 minecraft:light[level=12]
setblock 415 258 276 minecraft:red_terracotta
setblock 415 258 292 minecraft:stripped_oak_log
fill 415 258 293 415 260 293 minecraft:red_terracotta
setblock 415 258 297 minecraft:stripped_oak_log
setblock 415 258 316 minecraft:red_terracotta
setblock 416 258 287 minecraft:red_terracotta
setblock 416 258 291 minecraft:stripped_oak_log
fill 416 258 292 416 261 292 minecraft:red_terracotta
setblock 416 258 296 minecraft:stripped_oak_log
fill 416 258 297 416 261 297 minecraft:red_terracotta
setblock 416 258 316 minecraft:stripped_oak_log
setblock 417 258 285 minecraft:stripped_oak_log
fill 417 258 286 417 260 286 minecraft:red_terracotta
setblock 417 258 290 minecraft:stripped_oak_log
fill 417 258 291 417 261 291 minecraft:red_terracotta
setblock 417 258 295 minecraft:stripped_oak_log
fill 417 258 296 417 261 296 minecraft:red_terracotta
setblock 417 258 300 minecraft:stripped_oak_log
setblock 417 258 310 minecraft:stripped_oak_log
setblock 417 258 311 minecraft:red_terracotta
setblock 417 258 314 minecraft:red_terracotta
setblock 417 258 315 minecraft:stripped_oak_log
setblock 417 258 316 minecraft:red_terracotta
fill 418 258 308 418 259 308 minecraft:red_terracotta
fill 377 259 276 379 259 276 minecraft:red_terracotta
setblock 377 259 279 minecraft:stripped_oak_log
fill 377 259 280 377 262 280 minecraft:red_terracotta
setblock 377 259 284 minecraft:stripped_oak_log
setblock 377 259 285 minecraft:red_terracotta
setblock 377 259 289 minecraft:stripped_oak_log
fill 377 259 290 377 261 290 minecraft:red_terracotta
setblock 377 259 294 minecraft:stripped_oak_log
fill 377 259 295 377 262 295 minecraft:red_terracotta
setblock 377 259 314 minecraft:stripped_oak_log
fill 377 259 315 377 261 316 minecraft:red_terracotta
setblock 378 259 289 minecraft:red_terracotta
setblock 378 259 293 minecraft:stripped_oak_log
setblock 378 259 294 minecraft:red_terracotta
fill 378 259 316 379 259 316 minecraft:red_terracotta
setblock 380 259 276 minecraft:stripped_oak_log
fill 380 259 277 380 262 277 minecraft:red_terracotta
setblock 380 259 315 minecraft:red_terracotta
setblock 380 259 316 minecraft:stripped_oak_log
fill 381 259 276 381 262 276 minecraft:red_terracotta
setblock 381 259 315 minecraft:stripped_oak_log
fill 381 259 316 384 259 316 minecraft:red_terracotta
fill 382 259 315 382 262 315 minecraft:red_terracotta
fill 383 259 314 386 259 314 minecraft:red_terracotta
setblock 384 259 276 minecraft:red_terracotta
setblock 384 259 277 minecraft:stripped_oak_log
setblock 385 259 276 minecraft:stripped_oak_log
fill 385 259 277 385 262 277 minecraft:red_terracotta
setblock 385 259 316 minecraft:stripped_oak_log
fill 386 259 276 386 262 276 minecraft:red_terracotta
fill 386 259 313 387 259 313 minecraft:red_terracotta
setblock 386 259 315 minecraft:stripped_oak_log
fill 386 259 316 386 262 316 minecraft:red_terracotta
setblock 387 259 314 minecraft:stripped_oak_log
fill 387 259 315 387 262 315 minecraft:red_terracotta
setblock 388 259 277 minecraft:red_terracotta
setblock 388 259 278 minecraft:stripped_oak_log
setblock 388 259 313 minecraft:stripped_oak_log
fill 388 259 314 388 262 314 minecraft:red_terracotta
setblock 389 259 277 minecraft:stripped_oak_log
fill 389 259 278 389 261 278 minecraft:red_terracotta
fill 389 259 313 389 261 313 minecraft:red_terracotta
setblock 390 259 276 minecraft:stripped_oak_log
fill 390 259 277 390 262 277 minecraft:red_terracotta
setblock 390 259 316 minecraft:stripped_oak_log
fill 391 259 276 391 262 276 minecraft:red_terracotta
setblock 391 259 315 minecraft:stripped_oak_log
fill 391 259 316 391 262 316 minecraft:red_terracotta
setblock 392 259 314 minecraft:stripped_oak_log
fill 392 259 315 392 262 315 minecraft:red_terracotta
setblock 393 259 313 minecraft:stripped_oak_log
fill 393 259 314 393 261 314 minecraft:red_terracotta
setblock 395 259 276 minecraft:stripped_oak_log
setblock 395 259 316 minecraft:stripped_oak_log
fill 396 259 276 396 261 276 minecraft:red_terracotta
setblock 396 259 315 minecraft:stripped_oak_log
fill 396 259 316 399 259 316 minecraft:red_terracotta
setblock 397 259 314 minecraft:stripped_oak_log
fill 397 259 315 400 259 315 minecraft:red_terracotta
setblock 398 259 314 minecraft:red_terracotta
fill 400 259 314 401 259 314 minecraft:red_terracotta
setblock 400 259 316 minecraft:stripped_oak_log
setblock 401 259 315 minecraft:stripped_oak_log
fill 401 259 316 401 262 316 minecraft:red_terracotta
fill 402 259 276 404 259 276 minecraft:red_terracotta
setblock 402 259 314 minecraft:stripped_oak_log
fill 402 259 315 405 259 315 minecraft:red_terracotta
fill 403 259 314 406 259 314 minecraft:red_terracotta
setblock 405 259 276 minecraft:stripped_oak_log
setblock 405 259 316 minecraft:stripped_oak_log
fill 406 259 276 406 262 276 minecraft:red_terracotta
setblock 406 259 315 minecraft:stripped_oak_log
fill 406 259 316 406 262 316 minecraft:red_terracotta
setblock 407 259 313 minecraft:red_terracotta
setblock 407 259 314 minecraft:stripped_oak_log
fill 407 259 315 407 262 315 minecraft:red_terracotta
setblock 408 259 313 minecraft:stripped_oak_log
fill 408 259 314 408 261 314 minecraft:red_terracotta
setblock 410 259 276 minecraft:stripped_oak_log
setblock 410 259 316 minecraft:stripped_oak_log
fill 411 259 276 411 262 276 minecraft:red_terracotta
setblock 411 259 315 minecraft:stripped_oak_log
fill 411 259 316 411 262 316 minecraft:red_terracotta
fill 412 259 315 412 260 315 minecraft:red_terracotta
setblock 414 259 293 minecraft:red_terracotta
setblock 415 259 276 minecraft:stripped_oak_log
setblock 415 259 291 minecraft:stripped_oak_log
fill 415 259 292 415 260 292 minecraft:red_terracotta
setblock 415 259 296 minecraft:stripped_oak_log
setblock 415 259 316 minecraft:stripped_oak_log
setblock 416 259 290 minecraft:stripped_oak_log
fill 416 259 291 416 261 291 minecraft:red_terracotta
setblock 416 259 295 minecraft:stripped_oak_log
fill 416 259 296 416 262 296 minecraft:red_terracotta
setblock 416 259 316 minecraft:red_terracotta
setblock 417 259 285 minecraft:red_terracotta
setblock 417 259 289 minecraft:stripped_oak_log
fill 417 259 290 417 262 290 minecraft:red_terracotta
setblock 417 259 294 minecraft:stripped_oak_log
fill 417 259 295 417 262 295 minecraft:red_terracotta
setblock 417 259 299 minecraft:stripped_oak_log
setblock 417 259 300 minecraft:red_terracotta
setblock 417 259 314 minecraft:stripped_oak_log
setblock 417 259 315 minecraft:red_terracotta
fill 376 260 275 376 263 317 minecraft:yellow_terracotta
fill 377 260 275 418 263 275 minecraft:yellow_terracotta
fill 377 260 276 378 260 276 minecraft:red_terracotta
setblock 377 260 278 minecraft:stripped_oak_log
fill 377 260 279 377 263 279 minecraft:red_terracotta
setblock 377 260 288 minecraft:stripped_oak_log
fill 377 260 289 377 261 289 minecraft:red_terracotta
setblock 377 260 293 minecraft:stripped_oak_log
fill 377 260 294 377 262 294 minecraft:red_terracotta
setblock 377 260 314 minecraft:red_terracotta
fill 377 260 317 418 263 317 minecraft:yellow_terracotta
setblock 378 260 316 minecraft:red_terracotta
setblock 379 260 276 minecraft:stripped_oak_log
setblock 379 260 316 minecraft:stripped_oak_log
fill 380 260 276 380 263 276 minecraft:red_terracotta
setblock 380 260 315 minecraft:stripped_oak_log
fill 380 260 316 383 260 316 minecraft:red_terracotta
fill 381 260 315 381 263 315 minecraft:red_terracotta
setblock 383 260 276 minecraft:red_terracotta
setblock 383 260 277 minecraft:stripped_oak_log
fill 383 260 314 385 260 314 minecraft:red_terracotta
setblock 384 260 276 minecraft:stripped_oak_log
fill 384 260 277 384 262 278 minecraft:red_terracotta
setblock 384 260 316 minecraft:stripped_oak_log
fill 385 260 276 385 263 276 minecraft:red_terracotta
setblock 385 260 315 minecraft:stripped_oak_log
fill 385 260 316 385 263 316 minecraft:red_terracotta
setblock 386 260 313 minecraft:red_terracotta
setblock 386 260 314 minecraft:stripped_oak_log
fill 386 260 315 386 263 315 minecraft:red_terracotta
setblock 387 260 277 minecraft:red_terracotta
setblock 387 260 278 minecraft:stripped_oak_log
setblock 387 260 313 minecraft:stripped_oak_log
fill 387 260 314 387 263 314 minecraft:red_terracotta
setblock 388 260 277 minecraft:stripped_oak_log
fill 388 260 278 388 263 278 minecraft:red_terracotta
fill 388 260 313 388 261 313 minecraft:red_terracotta
setblock 389 260 276 minecraft:stripped_oak_log
fill 389 260 277 389 263 277 minecraft:red_terracotta
setblock 389 260 316 minecraft:stripped_oak_log
fill 390 260 276 390 263 276 minecraft:red_terracotta
setblock 390 260 315 minecraft:stripped_oak_log
fill 390 260 316 390 263 316 minecraft:red_terracotta
setblock 391 260 314 minecraft:stripped_oak_log
fill 391 260 315 391 263 315 minecraft:red_terracotta
fill 392 260 314 392 262 314 minecraft:red_terracotta
setblock 393 260 277 minecraft:stripped_oak_log
setblock 394 260 276 minecraft:stripped_oak_log
setblock 394 260 316 minecraft:stripped_oak_log
fill 395 260 276 395 262 276 minecraft:red_terracotta
setblock 395 260 315 minecraft:stripped_oak_log
fill 395 260 316 398 260 316 minecraft:red_terracotta
setblock 396 260 314 minecraft:stripped_oak_log
fill 396 260 315 399 260 315 minecraft:red_terracotta
setblock 399 260 316 minecraft:stripped_oak_log
setblock 400 260 315 minecraft:stripped_oak_log
fill 400 260 316 400 263 316 minecraft:red_terracotta
fill 401 260 315 404 260 315 minecraft:red_terracotta
fill 402 260 276 403 260 276 minecraft:red_terracotta
fill 402 260 314 405 260 314 minecraft:red_terracotta
setblock 404 260 276 minecraft:stripped_oak_log
setblock 404 260 316 minecraft:stripped_oak_log
fill 405 260 276 405 263 276 minecraft:red_terracotta
setblock 405 260 315 minecraft:stripped_oak_log
fill 405 260 316 405 263 316 minecraft:red_terracotta
setblock 406 260 314 minecraft:stripped_oak_log
fill 406 260 315 406 263 315 minecraft:red_terracotta
fill 407 260 314 407 261 314 minecraft:red_terracotta
setblock 408 260 277 minecraft:stripped_oak_log
setblock 409 260 276 minecraft:stripped_oak_log
setblock 409 260 316 minecraft:stripped_oak_log
fill 410 260 276 410 263 276 minecraft:red_terracotta
setblock 410 260 315 minecraft:stripped_oak_log
fill 410 260 316 410 263 316 minecraft:red_terracotta
fill 411 260 315 411 261 315 minecraft:red_terracotta
setblock 413 260 276 minecraft:red_terracotta
setblock 414 260 276 minecraft:stripped_oak_log
setblock 414 260 316 minecraft:stripped_oak_log
setblock 415 260 276 minecraft:red_terracotta
setblock 415 260 291 minecraft:red_terracotta
setblock 415 260 295 minecraft:stripped_oak_log
setblock 415 260 296 minecraft:red_terracotta
setblock 415 260 316 minecraft:red_terracotta
setblock 416 260 289 minecraft:stripped_oak_log
fill 416 260 290 416 261 290 minecraft:red_terracotta
setblock 416 260 294 minecraft:stripped_oak_log
fill 416 260 295 416 263 295 minecraft:red_terracotta
setblock 417 260 288 minecraft:stripped_oak_log
fill 417 260 289 417 262 289 minecraft:red_terracotta
setblock 417 260 293 minecraft:stripped_oak_log
fill 417 260 294 417 263 294 minecraft:red_terracotta
setblock 417 260 298 minecraft:stripped_oak_log
fill 417 260 299 417 263 299 minecraft:red_terracotta
fill 418 260 276 418 263 316 minecraft:yellow_terracotta
setblock 377 261 276 minecraft:red_terracotta
setblock 377 261 277 minecraft:stripped_oak_log
fill 377 261 278 377 264 278 minecraft:red_terracotta
setblock 377 261 288 minecraft:red_terracotta
setblock 377 261 292 minecraft:stripped_oak_log
fill 377 261 293 377 262 293 minecraft:red_terracotta
setblock 378 261 276 minecraft:stripped_oak_log
setblock 378 261 316 minecraft:stripped_oak_log
fill 379 261 276 379 263 277 minecraft:red_terracotta
fill 379 261 316 382 261 316 minecraft:red_terracotta
setblock 380 261 315 minecraft:red_terracotta
setblock 381 261 277 minecraft:red_terracotta
setblock 382 261 277 minecraft:stripped_oak_log
setblock 383 261 276 minecraft:stripped_oak_log
fill 383 261 277 383 263 278 minecraft:red_terracotta
fill 383 261 314 384 261 314 minecraft:red_terracotta
setblock 383 261 316 minecraft:stripped_oak_log
fill 384 261 276 384 264 276 minecraft:red_terracotta
setblock 384 261 315 minecraft:stripped_oak_log
fill 384 261 316 384 264 316 minecraft:red_terracotta
setblock 385 261 278 minecraft:red_terracotta
setblock 385 261 314 minecraft:stripped_oak_log
fill 385 261 315 385 264 315 minecraft:red_terracotta
setblock 386 261 278 minecraft:stripped_oak_log
fill 386 261 314 386 264 314 minecraft:red_terracotta
setblock 387 261 277 minecraft:stripped_oak_log
fill 387 261 278 387 264 278 minecraft:red_terracotta
setblock 387 261 313 minecraft:red_terracotta
setblock 388 261 276 minecraft:stripped_oak_log
fill 388 261 277 388 264 277 minecraft:red_terracotta
setblock 388 261 316 minecraft:stripped_oak_log
fill 389 261 276 389 264 276 minecraft:red_terracotta
setblock 389 261 315 minecraft:stripped_oak_log
fill 389 261 316 389 264 316 minecraft:red_terracotta
setblock 390 261 314 minecraft:stripped_oak_log
fill 390 261 315 390 264 315 minecraft:red_terracotta
fill 391 261 314 391 262 314 minecraft:red_terracotta
setblock 392 261 277 minecraft:stripped_oak_log
setblock 393 261 276 minecraft:stripped_oak_log
setblock 393 261 316 minecraft:stripped_oak_log
fill 394 261 276 394 263 276 minecraft:red_terracotta
fill 394 261 302 394 271 302 minecraft:stripped_oak_log
setblock 394 261 315 minecraft:stripped_oak_log
fill 394 261 316 397 261 316 minecraft:red_terracotta
fill 395 261 315 398 261 315 minecraft:red_terracotta
setblock 398 261 316 minecraft:stripped_oak_log
setblock 399 261 315 minecraft:stripped_oak_log
fill 399 261 316 399 264 316 minecraft:red_terracotta
fill 400 261 315 403 261 315 minecraft:red_terracotta
fill 401 261 276 402 261 276 minecraft:red_terracotta
setblock 403 261 276 minecraft:stripped_oak_log
fill 403 261 314 404 261 314 minecraft:red_terracotta
setblock 403 261 316 minecraft:stripped_oak_log
fill 404 261 276 404 264 276 minecraft:red_terracotta
setblock 404 261 315 minecraft:stripped_oak_log
fill 404 261 316 404 264 316 minecraft:red_terracotta
setblock 405 261 314 minecraft:stripped_oak_log
fill 405 261 315 405 264 315 minecraft:red_terracotta
fill 406 261 314 406 262 314 minecraft:red_terracotta
setblock 408 261 276 minecraft:stripped_oak_log
setblock 408 261 316 minecraft:stripped_oak_log
fill 409 261 276 409 264 276 minecraft:red_terracotta
setblock 409 261 315 minecraft:stripped_oak_log
fill 409 261 316 409 264 316 minecraft:red_terracotta
fill 410 261 315 410 262 315 minecraft:red_terracotta
setblock 413 261 276 minecraft:stripped_oak_log
setblock 413 261 316 minecraft:stripped_oak_log
setblock 414 261 276 minecraft:red_terracotta
setblock 414 261 316 minecraft:red_terracotta
setblock 415 261 294 minecraft:stripped_oak_log
setblock 416 261 293 minecraft:stripped_oak_log
fill 416 261 294 416 263 294 minecraft:red_terracotta
setblock 417 261 288 minecraft:red_terracotta
setblock 417 261 292 minecraft:stripped_oak_log
fill 417 261 293 417 264 293 minecraft:red_terracotta
setblock 417 261 297 minecraft:stripped_oak_log
fill 417 261 298 417 264 298 minecraft:red_terracotta
setblock 377 262 276 minecraft:stripped_oak_log
fill 377 262 277 378 264 277 minecraft:red_terracotta
setblock 377 262 291 minecraft:stripped_oak_log
setblock 377 262 292 minecraft:red_terracotta
setblock 377 262 316 minecraft:stripped_oak_log
fill 378 262 276 378 265 276 minecraft:red_terracotta
fill 378 262 316 381 262 316 minecraft:red_terracotta
setblock 381 262 277 minecraft:stripped_oak_log
setblock 382 262 276 minecraft:stripped_oak_log
fill 382 262 277 382 265 277 minecraft:red_terracotta
setblock 382 262 316 minecraft:stripped_oak_log
fill 383 262 276 383 265 276 minecraft:red_terracotta
setblock 383 262 314 minecraft:red_terracotta
setblock 383 262 315 minecraft:stripped_oak_log
fill 383 262 316 383 265 316 minecraft:red_terracotta
setblock 384 262 314 minecraft:stripped_oak_log
fill 384 262 315 384 265 315 minecraft:red_terracotta
setblock 385 262 278 minecraft:stripped_oak_log
fill 385 262 314 385 265 314 minecraft:red_terracotta
setblock 386 262 277 minecraft:stripped_oak_log
fill 386 262 278 386 265 278 minecraft:red_terracotta
setblock 387 262 276 minecraft:stripped_oak_log
fill 387 262 277 387 265 277 minecraft:red_terracotta
setblock 387 262 316 minecraft:stripped_oak_log
fill 388 262 276 388 265 276 minecraft:red_terracotta
setblock 388 262 315 minecraft:stripped_oak_log
fill 388 262 316 388 265 316 minecraft:red_terracotta
setblock 389 262 314 minecraft:stripped_oak_log
fill 389 262 315 389 265 315 minecraft:red_terracotta
fill 390 262 314 390 263 314 minecraft:red_terracotta
setblock 391 262 277 minecraft:stripped_oak_log
setblock 392 262 276 minecraft:stripped_oak_log
setblock 392 262 277 minecraft:red_terracotta
setblock 392 262 316 minecraft:stripped_oak_log
fill 393 262 276 393 265 276 minecraft:red_terracotta
setblock 393 262 315 minecraft:stripped_oak_log
fill 393 262 316 396 262 316 minecraft:red_terracotta
fill 394 262 315 397 262 315 minecraft:red_terracotta
setblock 397 262 316 minecraft:stripped_oak_log
setblock 398 262 315 minecraft:stripped_oak_log
fill 398 262 316 398 265 316 minecraft:red_terracotta
fill 399 262 315 402 262 315 minecraft:red_terracotta
setblock 401 262 276 minecraft:red_terracotta
setblock 402 262 276 minecraft:stripped_oak_log
setblock 402 262 316 minecraft:stripped_oak_log
fill 403 262 276 403 265 276 minecraft:red_terracotta
setblock 403 262 315 minecraft:stripped_oak_log
fill 403 262 316 403 265 316 minecraft:red_terracotta
fill 404 262 315 404 265 315 minecraft:red_terracotta
setblock 405 262 314 minecraft:red_terracotta
setblock 407 262 276 minecraft:stripped_oak_log
setblock 407 262 316 minecraft:stripped_oak_log
fill 408 262 276 408 265 276 minecraft:red_terracotta
setblock 408 262 315 minecraft:stripped_oak_log
fill 408 262 316 408 265 316 minecraft:red_terracotta
setblock 409 262 315 minecraft:red_terracotta
setblock 412 262 276 minecraft:stripped_oak_log
setblock 412 262 316 minecraft:stripped_oak_log
setblock 413 262 276 minecraft:red_terracotta
setblock 413 262 316 minecraft:red_terracotta
setblock 416 262 292 minecraft:stripped_oak_log
setblock 416 262 293 minecraft:red_terracotta
setblock 416 262 297 minecraft:stripped_oak_log
setblock 417 262 291 minecraft:stripped_oak_log
fill 417 262 292 417 265 292 minecraft:red_terracotta
setblock 417 262 296 minecraft:stripped_oak_log
fill 417 262 297 417 265 297 minecraft:red_terracotta
fill 377 263 276 377 266 276 minecraft:red_terracotta
setblock 377 263 280 minecraft:stripped_oak_log
fill 377 263 316 380 263 316 minecraft:red_terracotta
setblock 380 263 277 minecraft:stripped_oak_log
setblock 381 263 276 minecraft:stripped_oak_log
fill 381 263 277 381 266 277 minecraft:red_terracotta
setblock 381 263 316 minecraft:stripped_oak_log
fill 382 263 276 382 266 276 minecraft:red_terracotta
fill 382 263 278 382 264 278 minecraft:red_terracotta
setblock 382 263 315 minecraft:stripped_oak_log
fill 382 263 316 382 266 316 minecraft:red_terracotta
fill 383 263 315 383 266 315 minecraft:red_terracotta
setblock 384 263 277 minecraft:red_terracotta
setblock 384 263 278 minecraft:stripped_oak_log
fill 384 263 314 384 265 314 minecraft:red_terracotta
setblock 385 263 277 minecraft:stripped_oak_log
fill 385 263 278 385 266 278 minecraft:red_terracotta
setblock 386 263 276 minecraft:stripped_oak_log
fill 386 263 277 386 266 277 minecraft:red_terracotta
setblock 386 263 316 minecraft:stripped_oak_log
fill 387 263 276 387 266 276 minecraft:red_terracotta
setblock 387 263 315 minecraft:stripped_oak_log
fill 387 263 316 387 266 316 minecraft:red_terracotta
setblock 388 263 314 minecraft:stripped_oak_log
fill 388 263 315 388 266 315 minecraft:red_terracotta
fill 389 263 314 389 264 314 minecraft:red_terracotta
setblock 390 263 277 minecraft:stripped_oak_log
setblock 391 263 276 minecraft:stripped_oak_log
setblock 391 263 277 minecraft:red_terracotta
setblock 391 263 316 minecraft:stripped_oak_log
fill 392 263 276 392 266 276 minecraft:red_terracotta
setblock 392 263 315 minecraft:stripped_oak_log
fill 392 263 316 395 263 316 minecraft:red_terracotta
fill 393 263 315 394 263 315 minecraft:red_terracotta
setblock 396 263 316 minecraft:stripped_oak_log
fill 397 263 316 397 266 316 minecraft:red_terracotta
fill 400 263 315 401 263 315 minecraft:red_terracotta
setblock 401 263 276 minecraft:stripped_oak_log
setblock 401 263 316 minecraft:stripped_oak_log
fill 402 263 276 402 266 276 minecraft:red_terracotta
setblock 402 263 315 minecraft:stripped_oak_log
fill 402 263 316 402 266 316 minecraft:red_terracotta
fill 403 263 315 403 266 315 minecraft:red_terracotta
setblock 406 263 276 minecraft:stripped_oak_log
setblock 406 263 316 minecraft:stripped_oak_log
fill 407 263 276 407 266 276 minecraft:red_terracotta
setblock 407 263 315 minecraft:stripped_oak_log
fill 407 263 316 407 266 316 minecraft:red_terracotta
setblock 408 263 315 minecraft:red_terracotta
setblock 411 263 276 minecraft:stripped_oak_log
setblock 411 263 316 minecraft:stripped_oak_log
fill 412 263 276 412 264 276 minecraft:red_terracotta
setblock 417 263 290 minecraft:stripped_oak_log
fill 417 263 291 417 264 291 minecraft:red_terracotta
setblock 417 263 295 minecraft:stripped_oak_log
fill 417 263 296 417 266 296 minecraft:red_terracotta
fill 376 264 275 376 267 317 minecraft:white_terracotta
fill 377 264 275 418 267 275 minecraft:white_terracotta
setblock 377 264 279 minecraft:stripped_oak_log
fill 377 264 280 377 267 280 minecraft:red_terracotta
fill 377 264 316 379 264 316 minecraft:red_terracotta
fill 377 264 317 418 267 317 minecraft:white_terracotta
setblock 378 264 278 minecraft:stripped_oak_log
setblock 379 264 276 minecraft:red_terracotta
setblock 379 264 277 minecraft:stripped_oak_log
setblock 379 264 278 minecraft:light[level=15]
setblock 379 264 285 minecraft:light[level=12]
setblock 379 264 286 minecraft:light[level=15]
setblock 379 264 292 minecraft:light[level=12]
setblock 379 264 294 minecraft:light[level=15]
setblock 379 264 299 minecraft:light[level=12]
setblock 379 264 302 minecraft:light[level=15]
setblock 379 264 306 minecraft:light[level=12]
setblock 379 264 310 minecraft:light[level=15]
setblock 379 264 313 minecraft:light[level=12]
setblock 380 264 276 minecraft:stripped_oak_log
fill 380 264 277 380 267 277 minecraft:red_terracotta
setblock 380 264 316 minecraft:stripped_oak_log
fill 381 264 276 381 267 276 minecraft:red_terracotta
fill 381 264 278 381 265 278 minecraft:red_terracotta
setblock 381 264 315 minecraft:stripped_oak_log
fill 381 264 316 381 267 316 minecraft:red_terracotta
fill 382 264 315 382 267 315 minecraft:red_terracotta
setblock 383 264 277 minecraft:red_terracotta
setblock 383 264 278 minecraft:stripped_oak_log
setblock 384 264 277 minecraft:stripped_oak_log
fill 384 264 278 384 267 278 minecraft:red_terracotta
setblock 385 264 276 minecraft:stripped_oak_log
fill 385 264 277 385 267 277 minecraft:red_terracotta
setblock 385 264 316 minecraft:stripped_oak_log
fill 386 264 276 386 267 276 minecraft:red_terracotta
setblock 386 264 285 minecraft:light[level=12]
setblock 386 264 292 minecraft:light[level=12]
setblock 386 264 299 minecraft:light[level=12]
setblock 386 264 306 minecraft:light[level=12]
setblock 386 264 313 minecraft:light[level=12]
setblock 386 264 315 minecraft:stripped_oak_log
fill 386 264 316 386 267 316 minecraft:red_terracotta
setblock 387 264 286 minecraft:light[level=15]
setblock 387 264 294 minecraft:light[level=15]
setblock 387 264 302 minecraft:light[level=15]
setblock 387 264 310 minecraft:light[level=15]
setblock 387 264 314 minecraft:stripped_oak_log
fill 387 264 315 387 267 315 minecraft:red_terracotta
setblock 388 264 314 minecraft:red_terracotta
setblock 389 264 277 minecraft:stripped_oak_log
setblock 390 264 276 minecraft:stripped_oak_log
fill 390 264 277 390 266 277 minecraft:red_terracotta
setblock 390 264 316 minecraft:stripped_oak_log
fill 391 264 276 391 267 276 minecraft:red_terracotta
setblock 391 264 315 minecraft:stripped_oak_log
fill 391 264 316 394 264 316 minecraft:red_terracotta
setblock 392 264 315 minecraft:red_terracotta
setblock 393 264 278 minecraft:light[level=12]
setblock 393 264 285 minecraft:light[level=12]
setblock 393 264 292 minecraft:light[level=12]
setblock 393 264 299 minecraft:light[level=12]
setblock 393 264 306 minecraft:light[level=12]
setblock 393 264 313 minecraft:light[level=12]
setblock 395 264 278 minecraft:light[level=15]
setblock 395 264 286 minecraft:light[level=15]
setblock 395 264 294 minecraft:light[level=15]
setblock 395 264 310 minecraft:light[level=15]
setblock 395 264 316 minecraft:stripped_oak_log
fill 396 264 316 396 267 316 minecraft:red_terracotta
setblock 400 264 276 minecraft:stripped_oak_log
setblock 400 264 278 minecraft:light[level=12]
setblock 400 264 285 minecraft:light[level=12]
setblock 400 264 292 minecraft:light[level=12]
setblock 400 264 299 minecraft:light[level=12]
setblock 400 264 306 minecraft:light[level=12]
setblock 400 264 313 minecraft:light[level=12]
setblock 400 264 316 minecraft:stripped_oak_log
fill 401 264 276 401 267 276 minecraft:red_terracotta
setblock 401 264 315 minecraft:stripped_oak_log
fill 401 264 316 401 267 316 minecraft:red_terracotta
fill 402 264 315 402 265 315 minecraft:red_terracotta
setblock 403 264 278 minecraft:light[level=15]
setblock 403 264 286 minecraft:light[level=15]
setblock 403 264 294 minecraft:light[level=15]
setblock 403 264 302 minecraft:light[level=15]
setblock 403 264 310 minecraft:light[level=15]
setblock 405 264 276 minecraft:stripped_oak_log
setblock 405 264 316 minecraft:stripped_oak_log
fill 406 264 276 406 266 277 minecraft:red_terracotta
setblock 406 264 315 minecraft:stripped_oak_log
fill 406 264 316 406 267 316 minecraft:red_terracotta
setblock 407 264 278 minecraft:light[level=12]
setblock 407 264 285 minecraft:light[level=12]
setblock 407 264 292 minecraft:light[level=12]
setblock 407 264 299 minecraft:light[level=12]
setblock 407 264 306 minecraft:light[level=12]
setblock 407 264 313 minecraft:light[level=12]
setblock 407 264 315 minecraft:red_terracotta
setblock 410 264 276 minecraft:stripped_oak_log
setblock 410 264 316 minecraft:stripped_oak_log
fill 411 264 276 411 267 276 minecraft:red_terracotta
setblock 411 264 278 minecraft:light[level=15]
setblock 411 264 286 minecraft:light[level=15]
setblock 411 264 294 minecraft:light[level=15]
setblock 411 264 302 minecraft:light[level=15]
setblock 411 264 310 minecraft:light[level=15]
setblock 414 264 278 minecraft:light[level=12]
setblock 414 264 285 minecraft:light[level=12]
setblock 414 264 292 minecraft:light[level=12]
setblock 414 264 299 minecraft:light[level=12]
setblock 414 264 306 minecraft:light[level=12]
setblock 414 264 313 minecraft:light[level=12]
fill 417 264 276 417 264 278 minecraft:red_terracotta
setblock 417 264 294 minecraft:stripped_oak_log
fill 417 264 295 417 267 295 minecraft:red_terracotta
setblock 417 264 299 minecraft:stripped_oak_log
fill 418 264 276 418 267 316 minecraft:white_terracotta
setblock 377 265 277 minecraft:red_terracotta
setblock 377 265 278 minecraft:stripped_oak_log
fill 377 265 279 378 267 279 minecraft:red_terracotta
fill 377 265 281 377 266 281 minecraft:red_terracotta
fill 377 265 316 378 265 316 minecraft:red_terracotta
setblock 378 265 277 minecraft:stripped_oak_log
fill 378 265 278 378 268 278 minecraft:red_terracotta
setblock 379 265 276 minecraft:stripped_oak_log
fill 379 265 277 379 268 277 minecraft:red_terracotta
setblock 379 265 316 minecraft:stripped_oak_log
fill 380 265 276 380 268 276 minecraft:red_terracotta
fill 380 265 278 380 266 278 minecraft:red_terracotta
fill 380 265 316 380 268 316 minecraft:red_terracotta
fill 381 265 315 381 268 315 minecraft:red_terracotta
setblock 382 265 278 minecraft:stripped_oak_log
setblock 383 265 277 minecraft:stripped_oak_log
fill 383 265 278 383 268 278 minecraft:red_terracotta
setblock 384 265 276 minecraft:stripped_oak_log
fill 384 265 277 384 268 277 minecraft:red_terracotta
setblock 384 265 316 minecraft:stripped_oak_log
fill 385 265 276 385 268 276 minecraft:red_terracotta
setblock 385 265 315 minecraft:stripped_oak_log
fill 385 265 316 385 268 316 minecraft:red_terracotta
setblock 386 265 314 minecraft:stripped_oak_log
fill 386 265 315 386 268 315 minecraft:red_terracotta
setblock 387 265 278 minecraft:stripped_oak_log
setblock 387 265 314 minecraft:red_terracotta
setblock 388 265 277 minecraft:stripped_oak_log
setblock 389 265 276 minecraft:stripped_oak_log
fill 389 265 277 389 268 277 minecraft:red_terracotta
setblock 389 265 316 minecraft:stripped_oak_log
fill 390 265 276 390 268 276 minecraft:red_terracotta
setblock 390 265 315 minecraft:stripped_oak_log
fill 390 265 316 393 265 316 minecraft:red_terracotta
setblock 391 265 315 minecraft:red_terracotta
setblock 394 265 316 minecraft:stripped_oak_log
fill 395 265 316 395 268 316 minecraft:red_terracotta
setblock 399 265 316 minecraft:stripped_oak_log
fill 400 265 276 400 268 276 minecraft:red_terracotta
fill 400 265 316 400 268 316 minecraft:red_terracotta
setblock 404 265 276 minecraft:stripped_oak_log
setblock 404 265 316 minecraft:stripped_oak_log
fill 405 265 276 405 267 277 minecraft:red_terracotta
setblock 405 265 315 minecraft:stripped_oak_log
fill 405 265 316 405 268 316 minecraft:red_terracotta
setblock 407 265 277 minecraft:red_terracotta
setblock 409 265 276 minecraft:stripped_oak_log
setblock 409 265 316 minecraft:stripped_oak_log
fill 410 265 276 410 268 276 minecraft:red_terracotta
fill 416 265 276 417 266 276 minecraft:red_terracotta
setblock 417 265 277 minecraft:red_terracotta
setblock 417 265 278 minecraft:stripped_oak_log
fill 417 265 279 417 267 280 minecraft:red_terracotta
setblock 417 265 293 minecraft:stripped_oak_log
fill 417 265 294 417 268 294 minecraft:red_terracotta
setblock 417 265 298 minecraft:stripped_oak_log
fill 417 265 299 417 268 299 minecraft:red_terracotta
setblock 377 266 277 minecraft:stripped_oak_log
fill 377 266 278 377 269 278 minecraft:red_terracotta
setblock 377 266 282 minecraft:stripped_oak_log
setblock 377 266 316 minecraft:red_terracotta
setblock 378 266 276 minecraft:stripped_oak_log
fill 378 266 277 378 269 277 minecraft:red_terracotta
setblock 378 266 280 minecraft:red_terracotta
setblock 378 266 316 minecraft:stripped_oak_log
fill 379 266 276 379 269 276 minecraft:red_terracotta
fill 379 266 278 379 267 278 minecraft:red_terracotta
fill 379 266 316 379 269 316 minecraft:red_terracotta
fill 380 266 315 380 269 315 minecraft:red_terracotta
setblock 381 266 278 minecraft:stripped_oak_log
setblock 382 266 277 minecraft:stripped_oak_log
fill 382 266 278 382 269 278 minecraft:red_terracotta
setblock 383 266 276 minecraft:stripped_oak_log
fill 383 266 277 383 269 277 minecraft:red_terracotta
setblock 383 266 316 minecraft:stripped_oak_log
fill 384 266 276 384 269 276 minecraft:red_terracotta
setblock 384 266 315 minecraft:stripped_oak_log
fill 384 266 316 384 269 316 minecraft:red_terracotta
setblock 385 266 314 minecraft:stripped_oak_log
fill 385 266 315 385 269 315 minecraft:red_terracotta
setblock 386 266 278 minecraft:stripped_oak_log
setblock 387 266 277 minecraft:stripped_oak_log
fill 387 266 278 387 269 278 minecraft:red_terracotta
setblock 388 266 276 minecraft:stripped_oak_log
fill 388 266 277 388 269 277 minecraft:red_terracotta
setblock 388 266 316 minecraft:stripped_oak_log
fill 389 266 276 389 269 276 minecraft:red_terracotta
setblock 389 266 315 minecraft:stripped_oak_log
fill 389 266 316 392 266 316 minecraft:red_terracotta
setblock 390 266 315 minecraft:red_terracotta
setblock 393 266 276 minecraft:stripped_oak_log
setblock 393 266 316 minecraft:stripped_oak_log
fill 394 266 316 394 269 316 minecraft:red_terracotta
setblock 398 266 316 minecraft:stripped_oak_log
fill 399 266 276 399 269 276 minecraft:red_terracotta
fill 399 266 316 399 269 316 minecraft:red_terracotta
setblock 403 266 276 minecraft:stripped_oak_log
fill 403 266 277 404 268 277 minecraft:red_terracotta
setblock 403 266 316 minecraft:stripped_oak_log
fill 404 266 276 404 269 276 minecraft:red_terracotta
fill 404 266 316 404 269 316 minecraft:red_terracotta
setblock 407 266 277 minecraft:stripped_oak_log
setblock 408 266 276 minecraft:stripped_oak_log
setblock 408 266 316 minecraft:stripped_oak_log
fill 409 266 276 409 269 276 minecraft:red_terracotta
fill 413 266 286 415 266 288 minecraft:terracotta
fill 415 266 276 415 268 276 minecraft:red_terracotta
setblock 417 266 277 minecraft:stripped_oak_log
fill 417 266 278 417 269 278 minecraft:red_terracotta
setblock 417 266 281 minecraft:red_terracotta
setblock 417 266 282 minecraft:stripped_oak_log
fill 417 266 293 417 269 293 minecraft:red_terracotta
setblock 417 266 297 minecraft:stripped_oak_log
fill 417 266 298 417 269 298 minecraft:red_terracotta
fill 417 266 300 417 267 300 minecraft:red_terracotta
setblock 377 267 276 minecraft:stripped_oak_log
fill 377 267 277 377 270 277 minecraft:red_terracotta
setblock 377 267 281 minecraft:stripped_oak_log
fill 377 267 282 377 269 283 minecraft:red_terracotta
setblock 377 267 316 minecraft:stripped_oak_log
fill 378 267 276 378 270 276 minecraft:red_terracotta
setblock 378 267 280 minecraft:stripped_oak_log
fill 378 267 281 378 269 282 minecraft:red_terracotta
fill 378 267 316 378 270 316 minecraft:red_terracotta
setblock 379 267 279 minecraft:stripped_oak_log
fill 379 267 280 379 270 280 minecraft:red_terracotta
setblock 380 267 278 minecraft:stripped_oak_log
setblock 381 267 277 minecraft:stripped_oak_log
fill 381 267 278 381 270 278 minecraft:red_terracotta
setblock 382 267 276 minecraft:stripped_oak_log
fill 382 267 277 382 270 277 minecraft:red_terracotta
setblock 382 267 316 minecraft:stripped_oak_log
fill 383 267 276 383 270 276 minecraft:red_terracotta
setblock 383 267 315 minecraft:stripped_oak_log
fill 383 267 316 383 270 316 minecraft:red_terracotta
fill 384 267 315 384 270 315 minecraft:red_terracotta
setblock 385 267 278 minecraft:stripped_oak_log
setblock 386 267 277 minecraft:stripped_oak_log
fill 386 267 278 386 270 278 minecraft:red_terracotta
setblock 387 267 276 minecraft:stripped_oak_log
fill 387 267 277 387 270 277 minecraft:red_terracotta
setblock 387 267 316 minecraft:stripped_oak_log
fill 388 267 276 388 270 276 minecraft:red_terracotta
setblock 388 267 315 minecraft:stripped_oak_log
fill 388 267 316 391 267 316 minecraft:red_terracotta
fill 389 267 315 389 268 315 minecraft:red_terracotta
setblock 392 267 276 minecraft:stripped_oak_log
setblock 392 267 316 minecraft:stripped_oak_log
fill 393 267 316 393 270 316 minecraft:red_terracotta
setblock 397 267 316 minecraft:stripped_oak_log
fill 398 267 276 398 270 276 minecraft:red_terracotta
fill 398 267 316 398 270 316 minecraft:red_terracotta
setblock 402 267 276 minecraft:stripped_oak_log
fill 402 267 277 402 270 277 minecraft:red_terracotta
setblock 402 267 316 minecraft:stripped_oak_log
fill 403 267 276 403 270 276 minecraft:red_terracotta
fill 403 267 316 403 270 316 minecraft:red_terracotta
setblock 406 267 276 minecraft:red_terracotta
setblock 406 267 277 minecraft:stripped_oak_log
setblock 407 267 276 minecraft:stripped_oak_log
fill 407 267 277 407 270 277 minecraft:red_terracotta
setblock 407 267 316 minecraft:stripped_oak_log
fill 408 267 276 408 270 276 minecraft:red_terracotta
setblock 412 267 276 minecraft:stripped_oak_log
fill 413 267 276 414 269 276 minecraft:red_terracotta
fill 414 267 287 414 273 287 minecraft:green_concrete
setblock 416 267 276 minecraft:red_terracotta
setblock 417 267 276 minecraft:stripped_oak_log
fill 417 267 277 417 270 277 minecraft:red_terracotta
setblock 417 267 281 minecraft:stripped_oak_log
fill 417 267 282 417 268 284 minecraft:red_terracotta
setblock 417 267 296 minecraft:stripped_oak_log
fill 417 267 297 417 270 297 minecraft:red_terracotta
setblock 417 267 301 minecraft:stripped_oak_log
fill 376 268 275 376 271 317 minecraft:terracotta
fill 377 268 275 418 271 275 minecraft:terracotta
fill 377 268 276 377 271 276 minecraft:red_terracotta
setblock 377 268 279 minecraft:red_terracotta
setblock 377 268 280 minecraft:stripped_oak_log
fill 377 268 281 377 271 281 minecraft:red_terracotta
setblock 377 268 284 minecraft:red_terracotta
setblock 377 268 285 minecraft:stripped_oak_log
fill 377 268 298 377 268 299 minecraft:red_terracotta
setblock 377 268 300 minecraft:stripped_oak_log
setblock 377 268 315 minecraft:stripped_oak_log
fill 377 268 316 377 271 316 minecraft:red_terracotta
fill 377 268 317 418 271 317 minecraft:terracotta
setblock 378 268 279 minecraft:stripped_oak_log
fill 378 268 280 378 271 280 minecraft:red_terracotta
setblock 378 268 283 minecraft:red_terracotta
setblock 379 268 278 minecraft:stripped_oak_log
fill 379 268 279 379 271 279 minecraft:red_terracotta
fill 379 268 281 379 269 281 minecraft:red_terracotta
fill 379 268 315 379 270 315 minecraft:red_terracotta
setblock 380 268 277 minecraft:stripped_oak_log
fill 380 268 278 380 271 278 minecraft:red_terracotta
setblock 381 268 276 minecraft:stripped_oak_log
fill 381 268 277 381 271 277 minecraft:red_terracotta
fill 381 268 279 382 268 279 minecraft:red_terracotta
setblock 381 268 316 minecraft:stripped_oak_log
fill 382 268 276 382 271 276 minecraft:red_terracotta
setblock 382 268 315 minecraft:stripped_oak_log
fill 382 268 316 382 271 316 minecraft:red_terracotta
setblock 383 268 279 minecraft:stripped_oak_log
fill 383 268 315 383 271 315 minecraft:red_terracotta
setblock 384 268 278 minecraft:stripped_oak_log
fill 384 268 279 384 271 279 minecraft:red_terracotta
setblock 385 268 277 minecraft:stripped_oak_log
fill 385 268 278 385 271 278 minecraft:red_terracotta
setblock 386 268 276 minecraft:stripped_oak_log
fill 386 268 277 386 271 277 minecraft:red_terracotta
setblock 386 268 316 minecraft:stripped_oak_log
fill 387 268 276 387 271 276 minecraft:red_terracotta
setblock 387 268 315 minecraft:stripped_oak_log
fill 387 268 316 390 268 316 minecraft:red_terracotta
fill 388 268 300 390 268 302 minecraft:orange_terracotta
fill 388 268 315 388 270 315 minecraft:red_terracotta
fill 389 268 298 390 268 299 minecraft:orange_terracotta
fill 389 268 303 391 268 304 minecraft:orange_terracotta
fill 390 268 297 391 268 297 minecraft:orange_terracotta
fill 390 268 305 396 268 305 minecraft:orange_terracotta
setblock 391 268 276 minecraft:stripped_oak_log
fill 391 268 296 392 268 296 minecraft:orange_terracotta
fill 391 268 298 391 270 298 minecraft:orange_terracotta
setblock 391 268 316 minecraft:stripped_oak_log
fill 392 268 276 392 270 276 minecraft:red_terracotta
fill 392 268 304 397 268 304 minecraft:orange_terracotta
fill 392 268 316 392 271 316 minecraft:red_terracotta
fill 393 268 306 394 268 306 minecraft:orange_terracotta
fill 395 268 303 398 268 303 minecraft:orange_terracotta
fill 396 268 302 398 268 302 minecraft:orange_terracotta
setblock 396 268 316 minecraft:stripped_oak_log
fill 397 268 276 397 271 276 minecraft:red_terracotta
fill 397 268 301 398 268 301 minecraft:orange_terracotta
fill 397 268 316 397 271 316 minecraft:red_terracotta
setblock 401 268 276 minecraft:stripped_oak_log
fill 401 268 277 401 271 277 minecraft:red_terracotta
setblock 401 268 316 minecraft:stripped_oak_log
fill 402 268 276 402 271 276 minecraft:red_terracotta
fill 402 268 316 402 271 316 minecraft:red_terracotta
setblock 405 268 276 minecraft:red_terracotta
setblock 405 268 277 minecraft:stripped_oak_log
setblock 406 268 276 minecraft:stripped_oak_log
fill 406 268 277 406 271 277 minecraft:red_terracotta
setblock 406 268 316 minecraft:stripped_oak_log
fill 407 268 276 407 271 276 minecraft:red_terracotta
setblock 407 268 316 minecraft:red_terracotta
fill 408 268 277 408 269 277 minecraft:red_terracotta
setblock 411 268 276 minecraft:stripped_oak_log
fill 412 268 276 412 271 276 minecraft:red_terracotta
setblock 416 268 276 minecraft:stripped_oak_log
fill 416 268 277 416 268 280 minecraft:red_terracotta
setblock 416 268 281 minecraft:stripped_oak_log
fill 417 268 276 417 271 276 minecraft:red_terracotta
setblock 417 268 279 minecraft:red_terracotta
setblock 417 268 280 minecraft:stripped_oak_log
fill 417 268 281 417 271 281 minecraft:red_terracotta
setblock 417 268 285 minecraft:stripped_oak_log
fill 417 268 286 417 270 287 minecraft:red_terracotta
fill 417 268 292 417 270 292 minecraft:red_terracotta
setblock 417 268 295 minecraft:stripped_oak_log
fill 417 268 296 417 271 296 minecraft:red_terracotta
setblock 417 268 300 minecraft:stripped_oak_log
fill 417 268 301 417 270 302 minecraft:red_terracotta
fill 418 268 276 418 271 316 minecraft:terracotta
setblock 377 269 279 minecraft:stripped_oak_log
fill 377 269 280 377 271 280 minecraft:red_terracotta
setblock 377 269 284 minecraft:stripped_oak_log
fill 377 269 285 377 271 286 minecraft:red_terracotta
fill 377 269 297 377 269 298 minecraft:red_terracotta
setblock 377 269 299 minecraft:stripped_oak_log
fill 377 269 300 377 269 303 minecraft:red_terracotta
setblock 377 269 304 minecraft:stripped_oak_log
setblock 377 269 314 minecraft:stripped_oak_log
fill 377 269 315 377 271 315 minecraft:red_terracotta
setblock 378 269 278 minecraft:stripped_oak_log
fill 378 269 279 378 271 279 minecraft:red_terracotta
setblock 378 269 283 minecraft:stripped_oak_log
fill 378 269 284 378 271 284 minecraft:red_terracotta
setblock 379 269 277 minecraft:stripped_oak_log
fill 379 269 278 379 271 278 minecraft:red_terracotta
setblock 379 269 282 minecraft:stripped_oak_log
setblock 380 269 276 minecraft:stripped_oak_log
fill 380 269 277 380 271 277 minecraft:red_terracotta
fill 380 269 279 380 269 280 minecraft:red_terracotta
setblock 380 269 316 minecraft:stripped_oak_log
fill 381 269 276 381 271 276 minecraft:red_terracotta
setblock 381 269 279 minecraft:red_terracotta
setblock 381 269 315 minecraft:stripped_oak_log
fill 381 269 316 381 271 316 minecraft:red_terracotta
setblock 382 269 279 minecraft:stripped_oak_log
fill 382 269 315 382 271 315 minecraft:red_terracotta
setblock 383 269 278 minecraft:stripped_oak_log
fill 383 269 279 383 271 279 minecraft:red_terracotta
fill 383 269 314 384 270 314 minecraft:red_terracotta
setblock 384 269 277 minecraft:stripped_oak_log
fill 384 269 278 384 271 278 minecraft:red_terracotta
setblock 385 269 276 minecraft:stripped_oak_log
fill 385 269 277 385 271 277 minecraft:red_terracotta
setblock 385 269 316 minecraft:stripped_oak_log
fill 386 269 276 386 271 276 minecraft:red_terracotta
setblock 386 269 315 minecraft:stripped_oak_log
fill 386 269 316 389 269 316 minecraft:red_terracotta
fill 387 269 315 387 271 315 minecraft:red_terracotta
setblock 389 269 277 minecraft:stripped_oak_log
fill 389 269 299 390 269 302 minecraft:orange_terracotta
setblock 390 269 276 minecraft:stripped_oak_log
setblock 390 269 298 minecraft:orange_terracotta
fill 390 269 303 391 269 303 minecraft:orange_terracotta
setblock 390 269 316 minecraft:stripped_oak_log
fill 391 269 276 391 271 276 minecraft:red_terracotta
setblock 391 269 297 minecraft:orange_terracotta
fill 391 269 304 396 269 304 minecraft:orange_terracotta
fill 391 269 316 391 271 316 minecraft:red_terracotta
fill 392 269 305 394 269 305 minecraft:orange_terracotta
fill 395 269 303 397 269 303 minecraft:orange_terracotta
setblock 395 269 316 minecraft:stripped_oak_log
fill 396 269 276 396 271 276 minecraft:red_terracotta
fill 396 269 302 397 269 302 minecraft:orange_terracotta
fill 396 269 316 396 271 316 minecraft:red_terracotta
fill 397 269 301 397 270 301 minecraft:orange_terracotta
setblock 399 269 277 minecraft:stripped_oak_log
setblock 400 269 276 minecraft:stripped_oak_log
fill 400 269 277 400 271 277 minecraft:red_terracotta
setblock 400 269 316 minecraft:stripped_oak_log
fill 401 269 276 401 271 276 minecraft:red_terracotta
fill 401 269 316 401 271 316 minecraft:red_terracotta
setblock 403 269 277 minecraft:red_terracotta
setblock 404 269 277 minecraft:stripped_oak_log
setblock 405 269 276 minecraft:stripped_oak_log
fill 405 269 277 405 271 277 minecraft:red_terracotta
setblock 405 269 316 minecraft:stripped_oak_log
fill 406 269 276 406 271 276 minecraft:red_terracotta
fill 406 269 316 406 270 316 minecraft:red_terracotta
setblock 410 269 276 minecraft:stripped_oak_log
fill 411 269 276 411 271 276 minecraft:red_terracotta
setblock 415 269 276 minecraft:stripped_oak_log
fill 415 269 277 416 271 277 minecraft:red_terracotta
fill 416 269 276 416 271 276 minecraft:red_terracotta
fill 416 269 278 416 269 279 minecraft:red_terracotta
setblock 416 269 280 minecraft:stripped_oak_log
fill 416 269 281 416 269 284 minecraft:red_terracotta
setblock 417 269 279 minecraft:stripped_oak_log
fill 417 269 280 417 271 280 minecraft:red_terracotta
fill 417 269 282 417 269 283 minecraft:red_terracotta
setblock 417 269 284 minecraft:stripped_oak_log
fill 417 269 285 417 271 285 minecraft:red_terracotta
setblock 417 269 288 minecraft:red_terracotta
setblock 417 269 289 minecraft:stripped_oak_log
fill 417 269 290 417 271 291 minecraft:red_terracotta
setblock 417 269 294 minecraft:stripped_oak_log
fill 417 269 295 417 271 295 minecraft:red_terracotta
setblock 417 269 299 minecraft:stripped_oak_log
fill 417 269 300 417 271 300 minecraft:red_terracotta
setblock 417 269 303 minecraft:red_terracotta
setblock 377 270 278 minecraft:stripped_oak_log
fill 377 270 279 377 271 279 minecraft:red_terracotta
setblock 377 270 282 minecraft:red_terracotta
setblock 377 270 283 minecraft:stripped_oak_log
fill 377 270 284 377 271 284 minecraft:red_terracotta
setblock 377 270 287 minecraft:red_terracotta
fill 377 270 296 377 270 297 minecraft:red_terracotta
setblock 377 270 298 minecraft:stripped_oak_log
fill 377 270 299 377 270 302 minecraft:red_terracotta
setblock 377 270 303 minecraft:stripped_oak_log
fill 377 270 304 377 270 307 minecraft:red_terracotta
setblock 377 270 313 minecraft:stripped_oak_log
fill 377 270 314 377 271 314 minecraft:red_terracotta
setblock 378 270 277 minecraft:stripped_oak_log
fill 378 270 278 378 271 278 minecraft:red_terracotta
setblock 378 270 281 minecraft:red_terracotta
setblock 378 270 282 minecraft:stripped_oak_log
fill 378 270 283 379 271 283 minecraft:red_terracotta
fill 378 270 285 378 271 285 minecraft:red_terracotta
fill 378 270 299 378 270 301 minecraft:red_terracotta
setblock 378 270 302 minecraft:stripped_oak_log
fill 378 270 303 378 271 304 minecraft:red_terracotta
fill 378 270 315 378 271 315 minecraft:red_terracotta
setblock 379 270 276 minecraft:stripped_oak_log
fill 379 270 277 379 271 277 minecraft:red_terracotta
setblock 379 270 281 minecraft:stripped_oak_log
fill 379 270 282 379 271 282 minecraft:red_terracotta
setblock 379 270 285 minecraft:light[level=12]
setblock 379 270 292 minecraft:light[level=12]
setblock 379 270 299 minecraft:light[level=12]
setblock 379 270 306 minecraft:light[level=12]
setblock 379 270 313 minecraft:light[level=12]
setblock 379 270 316 minecraft:stripped_oak_log
fill 380 270 276 380 271 276 minecraft:red_terracotta
setblock 380 270 279 minecraft:red_terracotta
setblock 380 270 280 minecraft:stripped_oak_log
fill 380 270 281 380 271 281 minecraft:red_terracotta
setblock 380 270 315 minecraft:stripped_oak_log
fill 380 270 316 380 271 316 minecraft:red_terracotta
setblock 381 270 279 minecraft:stripped_oak_log
fill 381 270 315 381 271 315 minecraft:red_terracotta
setblock 382 270 278 minecraft:stripped_oak_log
fill 382 270 279 382 271 279 minecraft:red_terracotta
fill 382 270 314 382 271 314 minecraft:red_terracotta
setblock 383 270 277 minecraft:stripped_oak_log
fill 383 270 278 383 271 278 minecraft:red_terracotta
setblock 384 270 276 minecraft:stripped_oak_log
fill 384 270 277 384 271 277 minecraft:red_terracotta
setblock 384 270 316 minecraft:stripped_oak_log
fill 385 270 276 385 271 276 minecraft:red_terracotta
setblock 385 270 315 minecraft:stripped_oak_log
fill 385 270 316 388 270 316 minecraft:red_terracotta
setblock 386 270 285 minecraft:light[level=12]
setblock 386 270 292 minecraft:light[level=12]
setblock 386 270 299 minecraft:light[level=12]
setblock 386 270 306 minecraft:light[level=12]
setblock 386 270 313 minecraft:light[level=12]
fill 386 270 315 386 271 315 minecraft:red_terracotta
setblock 388 270 277 minecraft:stripped_oak_log
setblock 389 270 276 minecraft:stripped_oak_log
setblock 389 270 277 minecraft:red_terracotta
setblock 389 270 316 minecraft:stripped_oak_log
fill 390 270 276 390 271 276 minecraft:red_terracotta
fill 390 270 299 390 270 302 minecraft:orange_terracotta
fill 390 270 316 390 271 316 minecraft:red_terracotta
setblock 391 270 303 minecraft:orange_terracotta
fill 392 270 304 394 270 304 minecraft:orange_terracotta
setblock 393 270 278 minecraft:light[level=12]
setblock 393 270 285 minecraft:light[level=12]
setblock 393 270 292 minecraft:light[level=12]
setblock 393 270 299 minecraft:light[level=12]
setblock 393 270 306 minecraft:light[level=12]
setblock 393 270 313 minecraft:light[level=12]
setblock 394 270 316 minecraft:stripped_oak_log
fill 395 270 276 395 271 276 minecraft:red_terracotta
fill 395 270 303 396 270 303 minecraft:orange_terracotta
fill 395 270 316 395 271 316 minecraft:red_terracotta
setblock 396 270 302 minecraft:orange_terracotta
setblock 399 270 276 minecraft:stripped_oak_log
fill 399 270 277 399 271 277 minecraft:red_terracotta
setblock 399 270 316 minecraft:stripped_oak_log
fill 400 270 276 400 271 276 minecraft:red_terracotta
setblock 400 270 278 minecraft:light[level=12]
setblock 400 270 285 minecraft:light[level=12]
setblock 400 270 292 minecraft:light[level=12]
setblock 400 270 299 minecraft:light[level=12]
setblock 400 270 306 minecraft:light[level=12]
setblock 400 270 313 minecraft:light[level=12]
fill 400 270 316 400 271 316 minecraft:red_terracotta
setblock 402 270 278 minecraft:stripped_oak_log
setblock 403 270 277 minecraft:stripped_oak_log
fill 403 270 278 404 271 278 minecraft:red_terracotta
setblock 404 270 276 minecraft:stripped_oak_log
fill 404 270 277 404 271 277 minecraft:red_terracotta
setblock 404 270 316 minecraft:stripped_oak_log
fill 405 270 276 405 271 276 minecraft:red_terracotta
fill 405 270 316 405 271 316 minecraft:red_terracotta
setblock 407 270 278 minecraft:light[level=12]
setblock 407 270 285 minecraft:light[level=12]
setblock 407 270 292 minecraft:light[level=12]
setblock 407 270 299 minecraft:light[level=12]
setblock 407 270 306 minecraft:light[level=12]
setblock 407 270 313 minecraft:light[level=12]
setblock 408 270 277 minecraft:stripped_oak_log
setblock 409 270 276 minecraft:stripped_oak_log
fill 410 270 276 410 271 276 minecraft:red_terracotta
setblock 413 270 276 minecraft:red_terracotta
setblock 414 270 276 minecraft:stripped_oak_log
fill 414 270 277 414 271 277 minecraft:red_terracotta
setblock 414 270 278 minecraft:light[level=12]
setblock 414 270 285 minecraft:light[level=12]
fill 414 270 288 414 272 288 minecraft:green_concrete
setblock 414 270 292 minecraft:light[level=12]
setblock 414 270 299 minecraft:light[level=12]
setblock 414 270 306 minecraft:light[level=12]
setblock 414 270 313 minecraft:light[level=12]
fill 415 270 276 415 271 276 minecraft:red_terracotta
setblock 415 270 280 minecraft:stripped_oak_log
setblock 416 270 278 minecraft:red_terracotta
setblock 416 270 279 minecraft:stripped_oak_log
fill 416 270 280 416 270 283 minecraft:red_terracotta
setblock 416 270 284 minecraft:stripped_oak_log
fill 416 270 285 416 271 286 minecraft:red_terracotta
setblock 416 270 298 minecraft:red_terracotta
setblock 416 270 299 minecraft:stripped_oak_log
fill 416 270 300 416 271 300 minecraft:red_terracotta
setblock 417 270 278 minecraft:stripped_oak_log
fill 417 270 279 417 271 279 minecraft:red_terracotta
setblock 417 270 282 minecraft:red_terracotta
setblock 417 270 283 minecraft:stripped_oak_log
fill 417 270 284 417 271 284 minecraft:red_terracotta
setblock 417 270 288 minecraft:stripped_oak_log
fill 417 270 289 417 271 289 minecraft:red_terracotta
setblock 417 270 293 minecraft:stripped_oak_log
fill 417 270 294 417 271 294 minecraft:red_terracotta
setblock 417 270 298 minecraft:stripped_oak_log
fill 417 270 299 417 271 299 minecraft:red_terracotta
setblock 417 270 303 minecraft:stripped_oak_log
fill 417 270 304 417 271 305 minecraft:red_terracotta
setblock 377 271 277 minecraft:stripped_oak_log
setblock 377 271 278 minecraft:red_terracotta
setblock 377 271 282 minecraft:stripped_oak_log
setblock 377 271 283 minecraft:red_terracotta
setblock 377 271 287 minecraft:stripped_oak_log
fill 377 271 288 377 271 289 minecraft:red_terracotta
setblock 377 271 296 minecraft:red_terracotta
setblock 377 271 297 minecraft:stripped_oak_log
fill 377 271 298 377 271 301 minecraft:red_terracotta
setblock 377 271 302 minecraft:stripped_oak_log
fill 377 271 303 377 271 306 minecraft:red_terracotta
setblock 377 271 307 minecraft:stripped_oak_log
fill 377 271 308 377 271 311 minecraft:red_terracotta
setblock 377 271 312 minecraft:stripped_oak_log
setblock 377 271 313 minecraft:red_terracotta
setblock 378 271 276 minecraft:stripped_oak_log
setblock 378 271 277 minecraft:red_terracotta
setblock 378 271 281 minecraft:stripped_oak_log
setblock 378 271 282 minecraft:red_terracotta
setblock 378 271 286 minecraft:stripped_oak_log
fill 378 271 298 378 271 300 minecraft:red_terracotta
setblock 378 271 301 minecraft:stripped_oak_log
fill 378 271 302 379 271 302 minecraft:red_terracotta
setblock 378 271 305 minecraft:red_terracotta
setblock 378 271 306 minecraft:stripped_oak_log
setblock 378 271 307 minecraft:red_terracotta
setblock 378 271 314 minecraft:red_terracotta
setblock 378 271 316 minecraft:stripped_oak_log
setblock 379 271 276 minecraft:red_terracotta
setblock 379 271 280 minecraft:stripped_oak_log
setblock 379 271 281 minecraft:red_terracotta
setblock 379 271 284 minecraft:red_terracotta
fill 379 271 303 379 271 304 minecraft:red_terracotta
setblock 379 271 315 minecraft:stripped_oak_log
setblock 379 271 316 minecraft:red_terracotta
setblock 380 271 279 minecraft:stripped_oak_log
setblock 380 271 280 minecraft:red_terracotta
setblock 380 271 282 minecraft:red_terracotta
setblock 380 271 315 minecraft:red_terracotta
setblock 381 271 278 minecraft:stripped_oak_log
setblock 381 271 279 minecraft:red_terracotta
setblock 381 271 314 minecraft:red_terracotta
setblock 382 271 277 minecraft:stripped_oak_log
setblock 382 271 278 minecraft:red_terracotta
setblock 383 271 276 minecraft:stripped_oak_log
setblock 383 271 277 minecraft:red_terracotta
setblock 383 271 314 minecraft:red_terracotta
setblock 383 271 316 minecraft:stripped_oak_log
setblock 384 271 276 minecraft:red_terracotta
setblock 384 271 315 minecraft:stripped_oak_log
fill 384 271 316 387 271 316 minecraft:red_terracotta
setblock 385 271 315 minecraft:red_terracotta
setblock 386 271 278 minecraft:stripped_oak_log
setblock 387 271 277 minecraft:stripped_oak_log
setblock 388 271 276 minecraft:stripped_oak_log
setblock 388 271 277 minecraft:red_terracotta
setblock 388 271 316 minecraft:stripped_oak_log
setblock 389 271 276 minecraft:red_terracotta
setblock 389 271 316 minecraft:red_terracotta
setblock 394 271 316 minecraft:red_terracotta
setblock 398 271 276 minecraft:stripped_oak_log
setblock 398 271 277 minecraft:red_terracotta
setblock 398 271 316 minecraft:stripped_oak_log
setblock 399 271 276 minecraft:red_terracotta
setblock 399 271 316 minecraft:red_terracotta
setblock 401 271 278 minecraft:stripped_oak_log
setblock 402 271 277 minecraft:stripped_oak_log
setblock 402 271 278 minecraft:red_terracotta
setblock 403 271 276 minecraft:stripped_oak_log
setblock 403 271 277 minecraft:red_terracotta
setblock 403 271 316 minecraft:stripped_oak_log
setblock 404 271 276 minecraft:red_terracotta
setblock 404 271 316 minecraft:red_terracotta
setblock 407 271 277 minecraft:stripped_oak_log
setblock 408 271 276 minecraft:stripped_oak_log
setblock 408 271 277 minecraft:red_terracotta
setblock 409 271 276 minecraft:red_terracotta
setblock 413 271 276 minecraft:stripped_oak_log
setblock 413 271 277 minecraft:red_terracotta
setblock 414 271 276 minecraft:red_terracotta
setblock 415 271 278 minecraft:red_terracotta
setblock 415 271 279 minecraft:stripped_oak_log
fill 415 271 280 415 271 283 minecraft:red_terracotta
setblock 416 271 278 minecraft:stripped_oak_log
fill 416 271 279 416 271 282 minecraft:red_terracotta
setblock 416 271 283 minecraft:stripped_oak_log
setblock 416 271 284 minecraft:red_terracotta
setblock 416 271 287 minecraft:red_terracotta
setblock 416 271 298 minecraft:stripped_oak_log
setblock 416 271 299 minecraft:red_terracotta
fill 416 271 301 416 271 302 minecraft:red_terracotta
setblock 417 271 277 minecraft:stripped_oak_log
setblock 417 271 278 minecraft:red_terracotta
setblock 417 271 282 minecraft:stripped_oak_log
setblock 417 271 283 minecraft:red_terracotta
setblock 417 271 286 minecraft:red_terracotta
setblock 417 271 287 minecraft:stripped_oak_log
setblock 417 271 288 minecraft:red_terracotta
setblock 417 271 292 minecraft:stripped_oak_log
setblock 417 271 293 minecraft:red_terracotta
setblock 417 271 297 minecraft:stripped_oak_log
setblock 417 271 298 minecraft:red_terracotta
setblock 417 271 301 minecraft:red_terracotta
setblock 417 271 302 minecraft:stripped_oak_log
setblock 417 271 303 minecraft:red_terracotta
setblock 417 271 306 minecraft:red_terracotta
setblock 417 271 316 minecraft:red_terracotta
fill 376 272 275 376 275 317 minecraft:brown_terracotta
fill 377 272 275 418 275 275 minecraft:brown_terracotta
fill 377 272 317 418 275 317 minecraft:brown_terracotta
setblock 379 272 278 minecraft:light[level=15]
setblock 379 272 286 minecraft:light[level=15]
setblock 379 272 294 minecraft:light[level=15]
setblock 379 272 302 minecraft:light[level=15]
setblock 379 272 310 minecraft:light[level=15]
setblock 387 272 278 minecraft:light[level=15]
setblock 387 272 286 minecraft:light[level=15]
setblock 387 272 294 minecraft:light[level=15]
setblock 387 272 302 minecraft:light[level=15]
setblock 387 272 310 minecraft:light[level=15]
setblock 395 272 278 minecraft:light[level=15]
setblock 395 272 286 minecraft:light[level=15]
setblock 395 272 294 minecraft:light[level=15]
setblock 395 272 302 minecraft:light[level=15]
setblock 395 272 310 minecraft:light[level=15]
setblock 403 272 278 minecraft:light[level=15]
setblock 403 272 286 minecraft:light[level=15]
setblock 403 272 294 minecraft:light[level=15]
setblock 403 272 302 minecraft:light[level=15]
setblock 403 272 310 minecraft:light[level=15]
setblock 411 272 278 minecraft:light[level=15]
setblock 411 272 286 minecraft:light[level=15]
setblock 411 272 294 minecraft:light[level=15]
setblock 411 272 302 minecraft:light[level=15]
setblock 411 272 310 minecraft:light[level=15]
fill 418 272 276 418 275 316 minecraft:brown_terracotta
fill 376 276 275 376 279 317 minecraft:light_gray_terracotta
fill 377 276 275 418 279 275 minecraft:light_gray_terracotta
fill 377 276 317 418 279 317 minecraft:light_gray_terracotta
setblock 379 276 278 minecraft:light[level=12]
setblock 379 276 285 minecraft:light[level=12]
setblock 379 276 292 minecraft:light[level=12]
setblock 379 276 299 minecraft:light[level=12]
setblock 379 276 306 minecraft:light[level=12]
setblock 379 276 313 minecraft:light[level=12]
setblock 386 276 278 minecraft:light[level=12]
setblock 386 276 285 minecraft:light[level=12]
setblock 386 276 292 minecraft:light[level=12]
setblock 386 276 299 minecraft:light[level=12]
setblock 386 276 306 minecraft:light[level=12]
setblock 386 276 313 minecraft:light[level=12]
setblock 393 276 278 minecraft:light[level=12]
setblock 393 276 285 minecraft:light[level=12]
setblock 393 276 292 minecraft:light[level=12]
setblock 393 276 306 minecraft:light[level=12]
setblock 393 276 313 minecraft:light[level=12]
setblock 400 276 278 minecraft:light[level=12]
setblock 400 276 285 minecraft:light[level=12]
setblock 400 276 292 minecraft:light[level=12]
setblock 400 276 299 minecraft:light[level=12]
setblock 400 276 306 minecraft:light[level=12]
setblock 400 276 313 minecraft:light[level=12]
setblock 407 276 278 minecraft:light[level=12]
setblock 407 276 285 minecraft:light[level=12]
setblock 407 276 292 minecraft:light[level=12]
setblock 407 276 299 minecraft:light[level=12]
setblock 407 276 306 minecraft:light[level=12]
setblock 407 276 313 minecraft:light[level=12]
setblock 414 276 278 minecraft:light[level=12]
setblock 414 276 285 minecraft:light[level=12]
setblock 414 276 292 minecraft:light[level=12]
setblock 414 276 299 minecraft:light[level=12]
setblock 414 276 306 minecraft:light[level=12]
setblock 414 276 313 minecraft:light[level=12]
fill 418 276 276 418 279 316 minecraft:light_gray_terracotta
fill 377 277 284 391 277 308 minecraft:terracotta
fill 378 277 282 416 277 283 minecraft:terracotta
fill 378 277 309 416 277 310 minecraft:terracotta
fill 379 277 281 415 277 281 minecraft:terracotta
fill 379 277 311 415 277 311 minecraft:terracotta
fill 380 277 280 414 277 280 minecraft:terracotta
fill 380 277 312 414 277 312 minecraft:terracotta
fill 381 277 279 413 277 279 minecraft:terracotta
fill 381 277 313 413 277 313 minecraft:terracotta
fill 382 277 278 412 277 278 minecraft:terracotta
fill 382 277 314 412 277 314 minecraft:terracotta
fill 383 277 277 411 277 277 minecraft:terracotta
fill 383 277 315 411 277 315 minecraft:terracotta
fill 385 277 276 409 277 276 minecraft:terracotta
fill 385 277 316 409 277 316 minecraft:terracotta
fill 392 277 284 392 277 297 minecraft:terracotta
fill 392 277 299 392 277 308 minecraft:terracotta
fill 393 277 284 394 277 295 minecraft:terracotta
fill 393 277 301 394 277 308 minecraft:terracotta
fill 395 277 284 417 277 294 minecraft:terracotta
fill 395 277 302 417 277 308 minecraft:terracotta
fill 396 277 295 417 277 295 minecraft:terracotta
fill 396 277 301 417 277 301 minecraft:terracotta
fill 398 277 296 417 277 297 minecraft:terracotta
fill 398 277 299 417 277 300 minecraft:terracotta
fill 399 277 298 417 277 298 minecraft:terracotta
fill 377 278 285 377 279 307 minecraft:terracotta
fill 378 278 280 378 279 284 minecraft:terracotta
fill 378 278 285 391 278 307 minecraft:red_terracotta
fill 378 278 308 378 279 309 minecraft:terracotta
fill 379 278 280 379 278 282 minecraft:terracotta
fill 379 278 283 415 278 284 minecraft:red_terracotta
fill 379 278 308 415 278 309 minecraft:red_terracotta
fill 379 278 310 379 279 310 minecraft:terracotta
fill 380 278 280 380 279 281 minecraft:terracotta
fill 380 278 282 414 278 282 minecraft:red_terracotta
fill 380 278 310 414 278 310 minecraft:red_terracotta
fill 380 278 311 380 279 311 minecraft:terracotta
fill 381 278 280 381 279 280 minecraft:terracotta
fill 381 278 281 413 278 281 minecraft:red_terracotta
fill 381 278 311 413 278 311 minecraft:red_terracotta
fill 381 278 312 381 279 312 minecraft:terracotta
fill 382 278 279 382 279 279 minecraft:terracotta
fill 382 278 280 412 278 280 minecraft:red_terracotta
fill 382 278 312 412 278 312 minecraft:red_terracotta
fill 382 278 313 382 279 313 minecraft:terracotta
fill 383 278 278 383 279 278 minecraft:terracotta
fill 383 278 279 411 278 279 minecraft:red_terracotta
fill 383 278 313 411 278 313 minecraft:red_terracotta
fill 383 278 314 383 279 314 minecraft:terracotta
fill 384 278 277 385 279 277 minecraft:terracotta
fill 384 278 278 410 278 278 minecraft:red_terracotta
fill 384 278 314 410 278 314 minecraft:red_terracotta
fill 384 278 315 385 279 315 minecraft:terracotta
fill 386 278 276 408 279 276 minecraft:terracotta
fill 386 278 277 408 278 277 minecraft:red_terracotta
fill 386 278 315 408 278 315 minecraft:red_terracotta
fill 386 278 316 408 279 316 minecraft:terracotta
fill 392 278 285 392 278 295 minecraft:red_terracotta
fill 392 278 296 392 278 297 minecraft:orange_terracotta
setblock 392 278 299 minecraft:orange_terracotta
fill 392 278 300 392 278 307 minecraft:red_terracotta
fill 393 278 285 416 278 294 minecraft:red_terracotta
fill 393 278 295 394 278 295 minecraft:orange_terracotta
schedule function dropper:buildpart/68_9 1t
