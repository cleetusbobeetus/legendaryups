fill 284 268 241 295 268 241 minecraft:basalt
fill 284 268 242 289 268 242 minecraft:blackstone
setblock 284 268 243 minecraft:tuff
setblock 284 268 256 minecraft:tuff
fill 284 268 262 286 268 263 minecraft:blackstone
fill 284 268 267 286 268 268 minecraft:blackstone
setblock 284 268 269 minecraft:tuff
fill 285 268 229 289 268 230 minecraft:blackstone
setblock 285 268 232 minecraft:tuff
fill 285 268 233 285 268 235 minecraft:blackstone
fill 285 268 243 295 268 243 minecraft:blackstone
setblock 285 268 245 minecraft:tuff
fill 285 268 256 296 268 256 minecraft:basalt
fill 285 268 257 290 268 257 minecraft:blackstone
setblock 285 268 258 minecraft:tuff
fill 286 268 232 291 268 233 minecraft:blackstone
setblock 286 268 234 minecraft:tuff
fill 286 268 235 292 269 235 minecraft:blackstone
fill 286 268 244 290 268 245 minecraft:blackstone
setblock 286 268 247 minecraft:tuff
fill 286 268 248 286 268 250 minecraft:blackstone
fill 286 268 258 297 268 258 minecraft:blackstone
setblock 286 268 260 minecraft:tuff
setblock 287 268 236 minecraft:tuff
fill 287 268 248 292 269 248 minecraft:blackstone
setblock 287 268 249 minecraft:tuff
fill 287 268 250 293 269 250 minecraft:blackstone
fill 287 268 259 291 268 260 minecraft:blackstone
setblock 287 268 262 minecraft:tuff
fill 287 268 263 293 269 263 minecraft:blackstone
fill 287 268 268 289 269 268 minecraft:blackstone
fill 288 268 236 299 268 236 minecraft:basalt
fill 288 268 237 293 268 237 minecraft:blackstone
setblock 288 268 238 minecraft:tuff
fill 288 268 249 293 268 249 minecraft:blackstone
setblock 288 268 251 minecraft:tuff
setblock 288 268 264 minecraft:tuff
fill 288 268 265 294 269 265 minecraft:blackstone
fill 289 268 238 300 268 238 minecraft:blackstone
setblock 289 268 240 minecraft:tuff
fill 289 268 251 294 268 251 minecraft:basalt
fill 289 268 252 294 268 252 minecraft:blackstone
setblock 289 268 253 minecraft:tuff
setblock 289 268 266 minecraft:tuff
setblock 290 268 229 minecraft:tuff
fill 290 268 230 296 269 230 minecraft:blackstone
fill 290 268 239 294 268 240 minecraft:blackstone
setblock 290 268 242 minecraft:tuff
fill 290 268 253 295 268 253 minecraft:blackstone
setblock 290 268 255 minecraft:tuff
fill 290 268 266 301 268 266 minecraft:basalt
setblock 290 268 268 minecraft:tuff
fill 291 268 229 302 268 229 minecraft:blackstone
setblock 291 268 231 minecraft:tuff
fill 291 268 242 296 268 242 minecraft:blackstone
setblock 291 268 244 minecraft:tuff
fill 291 268 245 294 268 245 minecraft:blackstone
fill 291 268 254 295 268 255 minecraft:blackstone
setblock 291 268 257 minecraft:tuff
fill 291 268 267 295 268 268 minecraft:blackstone
fill 292 268 231 303 268 231 minecraft:basalt
fill 292 268 232 297 268 232 minecraft:blackstone
setblock 292 268 233 minecraft:tuff
fill 292 268 244 294 269 244 minecraft:blackstone
setblock 292 268 246 minecraft:tuff
setblock 292 268 259 minecraft:tuff
fill 292 268 260 298 269 260 minecraft:blackstone
fill 292 268 269 296 269 269 minecraft:blackstone
fill 293 268 233 304 268 233 minecraft:blackstone
setblock 293 268 235 minecraft:tuff
setblock 293 268 246 minecraft:basalt
setblock 293 268 248 minecraft:tuff
setblock 293 268 261 minecraft:tuff
fill 294 268 234 298 268 235 minecraft:blackstone
setblock 294 268 237 minecraft:tuff
fill 294 268 246 294 268 250 minecraft:magma_block
fill 294 268 261 305 268 261 minecraft:basalt
setblock 294 268 263 minecraft:tuff
fill 295 268 237 306 268 237 minecraft:blackstone
setblock 295 268 239 minecraft:tuff
fill 295 268 240 301 268 240 minecraft:blackstone
fill 295 268 244 295 268 245 minecraft:magma_block
fill 295 268 251 295 268 252 minecraft:magma_block
fill 295 268 262 299 268 263 minecraft:blackstone
setblock 295 268 265 minecraft:tuff
setblock 296 268 241 minecraft:tuff
setblock 296 268 243 minecraft:magma_block
setblock 296 268 253 minecraft:magma_block
setblock 296 268 254 minecraft:tuff
fill 296 268 255 298 268 255 minecraft:blackstone
fill 296 268 264 300 268 265 minecraft:blackstone
setblock 296 268 267 minecraft:tuff
fill 296 268 268 302 269 268 minecraft:blackstone
setblock 297 268 230 minecraft:tuff
fill 297 268 241 298 268 241 minecraft:basalt
setblock 297 268 242 minecraft:magma_block
setblock 297 268 254 minecraft:magma_block
setblock 297 268 256 minecraft:tuff
setblock 297 268 269 minecraft:tuff
fill 298 268 230 309 268 230 minecraft:blackstone
setblock 298 268 232 minecraft:tuff
fill 298 268 256 309 268 256 minecraft:basalt
setblock 298 268 258 minecraft:tuff
fill 299 268 232 310 268 232 minecraft:blackstone
setblock 299 268 234 minecraft:tuff
fill 299 268 235 305 269 235 minecraft:blackstone
fill 299 268 241 300 268 241 minecraft:magma_block
fill 299 268 255 300 268 255 minecraft:magma_block
fill 299 268 257 303 268 258 minecraft:blackstone
setblock 299 268 260 minecraft:tuff
setblock 300 268 236 minecraft:tuff
fill 300 268 259 304 268 260 minecraft:blackstone
setblock 300 268 262 minecraft:tuff
fill 300 268 263 306 269 263 minecraft:blackstone
fill 301 268 236 312 268 236 minecraft:basalt
setblock 301 268 238 minecraft:tuff
setblock 301 268 241 minecraft:shroomlight
setblock 301 268 255 minecraft:shroomlight
setblock 301 268 264 minecraft:tuff
fill 301 268 265 307 269 265 minecraft:blackstone
fill 302 268 238 313 268 238 minecraft:blackstone
setblock 302 268 240 minecraft:tuff
fill 302 268 241 303 268 241 minecraft:magma_block
fill 302 268 255 303 268 255 minecraft:magma_block
setblock 302 268 266 minecraft:tuff
setblock 303 268 229 minecraft:tuff
fill 303 268 239 307 268 240 minecraft:blackstone
fill 303 268 266 314 268 266 minecraft:basalt
setblock 303 268 268 minecraft:tuff
fill 304 268 229 315 268 229 minecraft:blackstone
setblock 304 268 231 minecraft:tuff
fill 304 268 241 308 268 241 minecraft:basalt
fill 304 268 255 315 268 255 minecraft:blackstone
setblock 304 268 257 minecraft:tuff
fill 304 268 258 310 269 258 minecraft:blackstone
fill 304 268 267 308 268 268 minecraft:blackstone
fill 305 268 231 316 268 231 minecraft:basalt
setblock 305 268 233 minecraft:tuff
setblock 305 268 242 minecraft:magma_block
setblock 305 268 254 minecraft:magma_block
setblock 305 268 259 minecraft:tuff
fill 305 268 260 311 269 260 minecraft:blackstone
fill 305 268 269 309 269 269 minecraft:blackstone
fill 306 268 233 317 268 233 minecraft:blackstone
setblock 306 268 235 minecraft:tuff
fill 306 268 242 315 268 242 minecraft:blackstone
setblock 306 268 243 minecraft:magma_block
setblock 306 268 253 minecraft:magma_block
fill 306 268 254 308 268 254 minecraft:blackstone
setblock 306 268 261 minecraft:tuff
fill 307 268 234 311 268 235 minecraft:blackstone
setblock 307 268 237 minecraft:tuff
fill 307 268 243 309 268 243 minecraft:blackstone
fill 307 268 244 307 268 245 minecraft:magma_block
fill 307 268 251 307 268 252 minecraft:magma_block
fill 307 268 253 314 268 253 minecraft:blackstone
fill 307 268 261 318 268 261 minecraft:basalt
setblock 307 268 263 minecraft:tuff
fill 308 268 237 315 268 237 minecraft:blackstone
setblock 308 268 239 minecraft:tuff
fill 308 268 240 314 269 240 minecraft:blackstone
fill 308 268 244 310 268 245 minecraft:blackstone
fill 308 268 246 308 268 250 minecraft:magma_block
fill 308 268 251 313 268 251 minecraft:basalt
setblock 308 268 252 minecraft:tuff
fill 308 268 262 312 268 263 minecraft:blackstone
setblock 308 268 265 minecraft:tuff
setblock 309 268 241 minecraft:tuff
fill 309 268 246 317 268 246 minecraft:basalt
fill 309 268 247 311 268 250 minecraft:blackstone
fill 309 268 252 317 268 252 minecraft:blackstone
setblock 309 268 254 minecraft:tuff
fill 309 268 264 313 268 265 minecraft:blackstone
setblock 309 268 267 minecraft:tuff
fill 309 268 268 315 269 268 minecraft:blackstone
setblock 310 268 230 minecraft:tuff
fill 310 268 241 321 268 241 minecraft:basalt
setblock 310 268 243 minecraft:tuff
fill 310 268 254 317 268 254 minecraft:blackstone
setblock 310 268 256 minecraft:tuff
setblock 310 268 269 minecraft:tuff
fill 311 268 230 322 268 230 minecraft:blackstone
setblock 311 268 232 minecraft:tuff
fill 311 268 243 316 268 244 minecraft:blackstone
setblock 311 268 245 minecraft:tuff
fill 311 268 256 322 268 256 minecraft:basalt
setblock 311 268 258 minecraft:tuff
fill 312 268 232 319 268 232 minecraft:blackstone
setblock 312 268 234 minecraft:tuff
fill 312 268 235 318 269 235 minecraft:blackstone
fill 312 268 245 323 268 245 minecraft:blackstone
setblock 312 268 247 minecraft:tuff
fill 312 268 248 312 268 250 minecraft:blackstone
fill 312 268 257 316 268 258 minecraft:blackstone
setblock 312 268 260 minecraft:tuff
setblock 313 268 236 minecraft:tuff
fill 313 268 247 318 268 248 minecraft:blackstone
setblock 313 268 249 minecraft:tuff
fill 313 268 250 319 269 250 minecraft:blackstone
fill 313 268 259 317 268 260 minecraft:blackstone
setblock 313 268 262 minecraft:tuff
fill 313 268 263 319 269 263 minecraft:blackstone
fill 314 268 236 323 268 236 minecraft:basalt
setblock 314 268 238 minecraft:tuff
setblock 314 268 251 minecraft:tuff
setblock 314 268 264 minecraft:tuff
fill 314 268 265 320 269 265 minecraft:blackstone
fill 315 268 238 316 269 238 minecraft:blackstone
setblock 315 268 240 minecraft:tuff
fill 315 268 251 323 268 251 minecraft:basalt
setblock 315 268 253 minecraft:tuff
setblock 315 268 266 minecraft:tuff
setblock 316 268 229 minecraft:tuff
fill 316 268 239 316 270 240 minecraft:blackstone
setblock 316 268 242 minecraft:tuff
fill 316 268 253 317 269 253 minecraft:blackstone
setblock 316 268 255 minecraft:tuff
fill 316 268 266 323 268 266 minecraft:basalt
setblock 316 268 268 minecraft:tuff
fill 317 268 229 323 268 229 minecraft:blackstone
setblock 317 268 231 minecraft:tuff
fill 317 268 240 323 268 240 minecraft:blackstone
fill 317 268 242 319 268 243 minecraft:blackstone
setblock 317 268 244 minecraft:tuff
fill 317 268 255 323 268 255 minecraft:blackstone
setblock 317 268 257 minecraft:tuff
fill 317 268 258 319 269 258 minecraft:blackstone
fill 317 268 267 318 268 268 minecraft:blackstone
fill 318 268 231 323 268 231 minecraft:basalt
setblock 318 268 233 minecraft:tuff
fill 318 268 239 320 269 239 minecraft:blackstone
fill 318 268 244 323 268 244 minecraft:blackstone
setblock 318 268 246 minecraft:tuff
setblock 318 268 259 minecraft:tuff
fill 318 268 260 323 269 260 minecraft:blackstone
fill 318 268 269 318 270 269 minecraft:blackstone
fill 319 268 233 320 269 233 minecraft:blackstone
setblock 319 268 235 minecraft:tuff
setblock 319 268 237 minecraft:blackstone
fill 319 268 246 323 268 246 minecraft:basalt
fill 319 268 247 320 268 247 minecraft:blackstone
setblock 319 268 248 minecraft:tuff
setblock 319 268 261 minecraft:tuff
setblock 319 268 267 minecraft:blackstone
fill 320 268 234 320 270 235 minecraft:blackstone
setblock 320 268 237 minecraft:tuff
fill 320 268 243 322 269 243 minecraft:blackstone
fill 320 268 248 322 269 248 minecraft:blackstone
setblock 320 268 250 minecraft:tuff
fill 320 268 252 320 268 254 minecraft:blackstone
fill 320 268 261 323 268 261 minecraft:basalt
setblock 320 268 263 minecraft:tuff
fill 320 268 269 322 269 269 minecraft:blackstone
fill 321 268 235 323 270 235 minecraft:blackstone
fill 321 268 237 322 268 237 minecraft:blackstone
setblock 321 268 239 minecraft:tuff
fill 321 268 249 321 270 250 minecraft:blackstone
setblock 321 268 252 minecraft:tuff
fill 321 268 253 321 269 254 minecraft:blackstone
fill 321 268 262 322 268 263 minecraft:blackstone
setblock 321 268 265 minecraft:tuff
fill 322 268 238 322 269 239 minecraft:blackstone
setblock 322 268 241 minecraft:tuff
fill 322 268 250 323 270 250 minecraft:blackstone
fill 322 268 252 323 268 253 minecraft:blackstone
setblock 322 268 254 minecraft:tuff
fill 322 268 264 322 270 265 minecraft:blackstone
setblock 322 268 267 minecraft:tuff
setblock 323 268 230 minecraft:tuff
fill 323 268 239 323 270 239 minecraft:blackstone
setblock 323 268 241 minecraft:basalt
setblock 323 268 243 minecraft:tuff
setblock 323 268 256 minecraft:tuff
setblock 323 268 262 minecraft:blackstone
fill 323 268 265 323 270 265 minecraft:blackstone
setblock 323 268 267 minecraft:blackstone
setblock 323 268 269 minecraft:tuff
setblock 283 269 231 minecraft:tuff
fill 283 269 232 289 269 232 minecraft:basalt
fill 283 269 233 283 269 236 minecraft:blackstone
fill 283 269 237 285 269 237 minecraft:basalt
fill 283 269 238 286 269 239 minecraft:blackstone
fill 283 269 241 287 270 241 minecraft:blackstone
fill 283 269 242 294 269 242 minecraft:basalt
fill 283 269 243 288 269 243 minecraft:blackstone
setblock 283 269 244 minecraft:tuff
fill 283 269 246 283 272 246 minecraft:blackstone
fill 283 269 247 290 269 247 minecraft:basalt
fill 283 269 248 284 269 251 minecraft:blackstone
fill 283 269 252 286 269 252 minecraft:basalt
fill 283 269 253 287 269 254 minecraft:blackstone
fill 283 269 256 288 270 256 minecraft:blackstone
setblock 283 269 257 minecraft:tuff
fill 283 269 258 283 269 259 minecraft:blackstone
fill 283 269 261 284 272 261 minecraft:blackstone
fill 283 269 262 291 269 262 minecraft:basalt
fill 283 269 263 285 269 266 minecraft:blackstone
fill 283 269 267 287 269 267 minecraft:basalt
fill 284 269 230 288 269 231 minecraft:blackstone
setblock 284 269 233 minecraft:tuff
fill 284 269 234 284 269 236 minecraft:blackstone
fill 284 269 244 291 269 244 minecraft:blackstone
setblock 284 269 246 minecraft:tuff
fill 284 269 257 295 269 257 minecraft:basalt
fill 284 269 258 289 269 258 minecraft:blackstone
setblock 284 269 259 minecraft:tuff
fill 284 269 268 286 269 269 minecraft:blackstone
fill 285 269 229 294 269 229 minecraft:blackstone
fill 285 269 233 290 269 234 minecraft:blackstone
setblock 285 269 235 minecraft:tuff
fill 285 269 236 291 270 236 minecraft:blackstone
fill 285 269 245 289 269 246 minecraft:blackstone
setblock 285 269 248 minecraft:tuff
fill 285 269 249 285 269 251 minecraft:blackstone
fill 285 269 259 296 269 259 minecraft:blackstone
setblock 285 269 261 minecraft:tuff
setblock 286 269 237 minecraft:tuff
fill 286 269 248 286 269 249 minecraft:blackstone
setblock 286 269 250 minecraft:tuff
fill 286 269 251 292 270 251 minecraft:blackstone
fill 286 269 260 290 269 261 minecraft:blackstone
setblock 286 269 263 minecraft:tuff
fill 286 269 264 286 269 266 minecraft:blackstone
fill 287 269 237 298 269 237 minecraft:basalt
fill 287 269 238 292 269 238 minecraft:blackstone
setblock 287 269 239 minecraft:tuff
fill 287 269 249 291 270 249 minecraft:blackstone
setblock 287 269 252 minecraft:tuff
fill 287 269 264 292 270 264 minecraft:blackstone
setblock 287 269 265 minecraft:tuff
fill 287 269 266 293 270 266 minecraft:blackstone
fill 287 269 269 288 270 269 minecraft:blackstone
fill 288 269 239 299 269 239 minecraft:blackstone
setblock 288 269 241 minecraft:tuff
fill 288 269 252 294 269 252 minecraft:basalt
fill 288 269 253 293 269 253 minecraft:blackstone
setblock 288 269 254 minecraft:tuff
setblock 288 269 267 minecraft:tuff
setblock 289 269 230 minecraft:tuff
fill 289 269 231 295 270 231 minecraft:blackstone
fill 289 269 240 293 269 241 minecraft:blackstone
setblock 289 269 243 minecraft:tuff
fill 289 269 254 295 269 254 minecraft:blackstone
setblock 289 269 256 minecraft:tuff
fill 289 269 267 300 269 267 minecraft:basalt
setblock 289 269 269 minecraft:tuff
setblock 290 269 232 minecraft:tuff
fill 290 269 243 294 269 243 minecraft:blackstone
setblock 290 269 245 minecraft:tuff
fill 290 269 246 293 269 246 minecraft:blackstone
fill 290 269 255 294 269 256 minecraft:blackstone
setblock 290 269 258 minecraft:tuff
fill 290 269 268 291 269 269 minecraft:blackstone
fill 291 269 232 302 269 232 minecraft:basalt
fill 291 269 233 296 269 233 minecraft:blackstone
setblock 291 269 234 minecraft:tuff
fill 291 269 245 293 269 245 minecraft:blackstone
setblock 291 269 247 minecraft:tuff
fill 291 269 258 302 269 258 minecraft:blackstone
setblock 291 269 260 minecraft:tuff
fill 291 269 261 297 270 261 minecraft:blackstone
fill 292 269 234 303 269 234 minecraft:blackstone
setblock 292 269 236 minecraft:tuff
setblock 292 269 247 minecraft:basalt
setblock 292 269 249 minecraft:tuff
setblock 292 269 262 minecraft:tuff
fill 292 269 268 294 269 268 minecraft:blackstone
fill 293 269 235 297 269 236 minecraft:blackstone
setblock 293 269 238 minecraft:tuff
fill 293 269 247 293 270 249 minecraft:netherrack
setblock 293 269 251 minecraft:tuff
fill 293 269 262 304 269 262 minecraft:basalt
setblock 293 269 264 minecraft:tuff
fill 294 269 238 305 269 238 minecraft:blackstone
setblock 294 269 240 minecraft:tuff
fill 294 269 241 297 269 241 minecraft:blackstone
fill 294 269 245 294 269 246 minecraft:netherrack
fill 294 269 250 294 269 251 minecraft:netherrack
setblock 294 269 253 minecraft:tuff
fill 294 269 263 298 269 264 minecraft:blackstone
setblock 294 269 266 minecraft:tuff
setblock 295 269 229 minecraft:tuff
fill 295 269 240 299 269 240 minecraft:blackstone
setblock 295 269 242 minecraft:tuff
setblock 295 269 243 minecraft:shroomlight
setblock 295 269 244 minecraft:netherrack
setblock 295 269 252 minecraft:netherrack
setblock 295 269 253 minecraft:shroomlight
setblock 295 269 255 minecraft:tuff
fill 295 269 256 299 269 256 minecraft:blackstone
fill 295 269 265 299 269 266 minecraft:blackstone
setblock 295 269 268 minecraft:tuff
fill 296 269 229 307 269 229 minecraft:blackstone
setblock 296 269 231 minecraft:tuff
fill 296 269 242 297 269 242 minecraft:netherrack
fill 296 269 254 297 269 254 minecraft:netherrack
fill 296 269 255 297 269 255 minecraft:blackstone
setblock 296 269 257 minecraft:tuff
fill 297 269 230 301 269 231 minecraft:blackstone
setblock 297 269 233 minecraft:tuff
fill 297 269 257 308 269 257 minecraft:basalt
setblock 297 269 259 minecraft:tuff
fill 297 269 269 301 270 269 minecraft:blackstone
fill 298 269 233 309 269 233 minecraft:blackstone
setblock 298 269 235 minecraft:tuff
fill 298 269 236 304 270 236 minecraft:blackstone
fill 298 269 241 299 269 241 minecraft:netherrack
fill 298 269 255 299 269 255 minecraft:netherrack
fill 298 269 259 309 269 259 minecraft:blackstone
setblock 298 269 261 minecraft:tuff
setblock 299 269 237 minecraft:tuff
fill 299 269 260 303 269 261 minecraft:blackstone
setblock 299 269 263 minecraft:tuff
fill 299 269 264 305 270 264 minecraft:blackstone
fill 300 269 237 311 269 237 minecraft:basalt
setblock 300 269 239 minecraft:tuff
fill 300 269 240 300 270 240 minecraft:netherrack
fill 300 269 256 300 270 256 minecraft:netherrack
setblock 300 269 265 minecraft:tuff
fill 300 269 266 306 270 266 minecraft:blackstone
fill 301 269 239 312 269 239 minecraft:blackstone
fill 301 269 240 301 270 240 minecraft:shroomlight
fill 301 269 256 301 270 256 minecraft:shroomlight
setblock 301 269 267 minecraft:tuff
setblock 302 269 230 minecraft:tuff
fill 302 269 231 308 270 231 minecraft:blackstone
fill 302 269 240 302 270 240 minecraft:netherrack
fill 302 269 256 302 270 256 minecraft:netherrack
fill 302 269 267 313 269 267 minecraft:basalt
setblock 302 269 269 minecraft:tuff
fill 303 269 230 314 269 230 minecraft:blackstone
setblock 303 269 232 minecraft:tuff
fill 303 269 240 306 269 240 minecraft:blackstone
fill 303 269 241 304 269 241 minecraft:netherrack
fill 303 269 255 304 269 255 minecraft:netherrack
fill 303 269 256 314 269 256 minecraft:blackstone
setblock 303 269 258 minecraft:tuff
fill 303 269 268 304 269 269 minecraft:blackstone
fill 304 269 232 315 269 232 minecraft:basalt
setblock 304 269 234 minecraft:tuff
setblock 304 269 260 minecraft:tuff
fill 304 269 261 310 270 261 minecraft:blackstone
fill 305 269 234 316 269 234 minecraft:blackstone
setblock 305 269 236 minecraft:tuff
fill 305 269 241 313 269 241 minecraft:blackstone
fill 305 269 242 306 269 242 minecraft:netherrack
fill 305 269 254 306 269 254 minecraft:netherrack
fill 305 269 255 307 269 255 minecraft:blackstone
setblock 305 269 262 minecraft:tuff
fill 305 269 268 307 269 268 minecraft:blackstone
fill 306 269 235 310 269 236 minecraft:blackstone
setblock 306 269 238 minecraft:tuff
fill 306 269 262 317 269 262 minecraft:basalt
setblock 306 269 264 minecraft:tuff
fill 307 269 238 314 269 238 minecraft:blackstone
setblock 307 269 240 minecraft:tuff
setblock 307 269 242 minecraft:basalt
setblock 307 269 243 minecraft:shroomlight
setblock 307 269 244 minecraft:netherrack
setblock 307 269 252 minecraft:netherrack
setblock 307 269 253 minecraft:shroomlight
fill 307 269 254 313 269 254 minecraft:blackstone
fill 307 269 263 311 269 264 minecraft:blackstone
setblock 307 269 266 minecraft:tuff
setblock 308 269 229 minecraft:tuff
setblock 308 269 242 minecraft:tuff
fill 308 269 243 308 269 244 minecraft:blackstone
fill 308 269 245 308 269 246 minecraft:netherrack
fill 308 269 250 308 269 251 minecraft:netherrack
fill 308 269 252 312 269 252 minecraft:basalt
fill 308 269 253 315 269 253 minecraft:blackstone
setblock 308 269 255 minecraft:tuff
fill 308 269 265 312 269 266 minecraft:blackstone
setblock 308 269 268 minecraft:tuff
fill 309 269 229 320 269 229 minecraft:blackstone
setblock 309 269 231 minecraft:tuff
fill 309 269 242 320 269 242 minecraft:basalt
fill 309 269 243 314 269 243 minecraft:blackstone
setblock 309 269 244 minecraft:tuff
fill 309 269 245 309 269 246 minecraft:blackstone
fill 309 269 247 309 270 249 minecraft:netherrack
fill 309 269 250 311 269 251 minecraft:blackstone
fill 309 269 255 320 269 255 minecraft:blackstone
setblock 309 269 257 minecraft:tuff
fill 310 269 231 321 269 231 minecraft:blackstone
setblock 310 269 233 minecraft:tuff
fill 310 269 244 315 269 245 minecraft:blackstone
setblock 310 269 246 minecraft:tuff
fill 310 269 247 316 269 247 minecraft:basalt
fill 310 269 248 310 269 249 minecraft:blackstone
fill 310 269 257 321 269 257 minecraft:basalt
setblock 310 269 259 minecraft:tuff
fill 310 269 269 314 270 269 minecraft:blackstone
fill 311 269 233 318 269 233 minecraft:blackstone
setblock 311 269 235 minecraft:tuff
fill 311 269 236 317 270 236 minecraft:blackstone
fill 311 269 246 322 269 246 minecraft:blackstone
setblock 311 269 248 minecraft:tuff
fill 311 269 249 317 270 249 minecraft:blackstone
fill 311 269 258 315 269 259 minecraft:blackstone
setblock 311 269 261 minecraft:tuff
setblock 312 269 237 minecraft:tuff
fill 312 269 248 319 269 248 minecraft:blackstone
setblock 312 269 250 minecraft:tuff
fill 312 269 251 318 270 251 minecraft:blackstone
fill 312 269 260 316 269 261 minecraft:blackstone
setblock 312 269 263 minecraft:tuff
fill 312 269 264 318 270 264 minecraft:blackstone
fill 313 269 237 323 269 237 minecraft:basalt
setblock 313 269 239 minecraft:tuff
setblock 313 269 252 minecraft:tuff
setblock 313 269 265 minecraft:tuff
fill 313 269 266 319 270 266 minecraft:blackstone
fill 314 269 239 315 270 239 minecraft:blackstone
setblock 314 269 241 minecraft:tuff
fill 314 269 252 323 269 252 minecraft:basalt
setblock 314 269 254 minecraft:tuff
setblock 314 269 267 minecraft:tuff
setblock 315 269 230 minecraft:tuff
fill 315 269 240 315 271 241 minecraft:blackstone
setblock 315 269 243 minecraft:tuff
fill 315 269 254 320 269 254 minecraft:blackstone
setblock 315 269 256 minecraft:tuff
fill 315 269 267 323 269 267 minecraft:basalt
setblock 315 269 269 minecraft:tuff
fill 316 269 230 323 269 230 minecraft:blackstone
setblock 316 269 232 minecraft:tuff
fill 316 269 241 323 269 241 minecraft:blackstone
fill 316 269 243 319 269 244 minecraft:blackstone
setblock 316 269 245 minecraft:tuff
fill 316 269 256 323 269 256 minecraft:blackstone
setblock 316 269 258 minecraft:tuff
fill 316 269 259 322 270 259 minecraft:blackstone
fill 316 269 268 317 269 269 minecraft:blackstone
fill 317 269 232 323 269 232 minecraft:basalt
setblock 317 269 234 minecraft:tuff
fill 317 269 240 319 270 240 minecraft:blackstone
fill 317 269 245 323 269 245 minecraft:blackstone
setblock 317 269 247 minecraft:tuff
setblock 317 269 260 minecraft:tuff
fill 317 269 261 323 270 261 minecraft:blackstone
fill 318 269 234 319 270 234 minecraft:blackstone
setblock 318 269 236 minecraft:tuff
setblock 318 269 238 minecraft:blackstone
fill 318 269 247 323 269 247 minecraft:basalt
setblock 318 269 249 minecraft:tuff
fill 318 269 253 319 269 253 minecraft:blackstone
setblock 318 269 262 minecraft:tuff
setblock 318 269 268 minecraft:blackstone
fill 319 269 235 319 271 236 minecraft:blackstone
setblock 319 269 238 minecraft:tuff
fill 319 269 249 320 270 249 minecraft:blackstone
setblock 319 269 251 minecraft:tuff
fill 319 269 262 323 269 262 minecraft:basalt
setblock 319 269 264 minecraft:tuff
fill 320 269 236 323 269 236 minecraft:blackstone
fill 320 269 238 321 269 238 minecraft:blackstone
setblock 320 269 240 minecraft:tuff
fill 320 269 244 321 270 244 minecraft:blackstone
fill 320 269 250 320 271 251 minecraft:blackstone
setblock 320 269 253 minecraft:tuff
fill 320 269 263 321 269 264 minecraft:blackstone
setblock 320 269 266 minecraft:tuff
setblock 320 269 268 minecraft:blackstone
setblock 321 269 229 minecraft:tuff
fill 321 269 239 321 270 240 minecraft:blackstone
setblock 321 269 242 minecraft:tuff
fill 321 269 251 323 271 251 minecraft:blackstone
setblock 321 269 255 minecraft:tuff
fill 321 269 265 321 271 266 minecraft:blackstone
setblock 321 269 268 minecraft:tuff
fill 322 269 229 323 270 229 minecraft:blackstone
setblock 322 269 231 minecraft:tuff
setblock 322 269 233 minecraft:blackstone
fill 322 269 240 323 271 240 minecraft:blackstone
fill 322 269 242 323 269 242 minecraft:basalt
setblock 322 269 244 minecraft:tuff
fill 322 269 253 322 269 255 minecraft:blackstone
setblock 322 269 257 minecraft:tuff
setblock 322 269 263 minecraft:blackstone
fill 322 269 266 323 271 266 minecraft:blackstone
fill 322 269 268 323 269 268 minecraft:blackstone
fill 323 269 231 323 272 231 minecraft:blackstone
setblock 323 269 233 minecraft:tuff
setblock 323 269 238 minecraft:blackstone
fill 323 269 243 323 269 244 minecraft:blackstone
setblock 323 269 246 minecraft:tuff
setblock 323 269 253 minecraft:blackstone
fill 323 269 255 323 271 255 minecraft:blackstone
setblock 323 269 257 minecraft:basalt
setblock 323 269 259 minecraft:tuff
fill 323 269 269 323 270 269 minecraft:blackstone
setblock 283 270 228 minecraft:magma_block
fill 283 270 231 287 270 232 minecraft:blackstone
fill 283 270 233 288 270 233 minecraft:basalt
setblock 283 270 234 minecraft:tuff
fill 283 270 235 283 270 237 minecraft:blackstone
fill 283 270 238 284 270 238 minecraft:basalt
fill 283 270 239 285 270 240 minecraft:blackstone
fill 283 270 242 286 271 242 minecraft:blackstone
fill 283 270 243 293 270 243 minecraft:basalt
fill 283 270 244 287 270 244 minecraft:blackstone
setblock 283 270 247 minecraft:tuff
fill 283 270 248 289 270 248 minecraft:basalt
fill 283 270 249 283 270 252 minecraft:blackstone
fill 283 270 253 285 270 253 minecraft:basalt
fill 283 270 254 286 270 255 minecraft:blackstone
fill 283 270 257 287 271 257 minecraft:blackstone
fill 283 270 258 294 270 258 minecraft:basalt
fill 283 270 259 288 270 259 minecraft:blackstone
setblock 283 270 260 minecraft:tuff
fill 283 270 262 283 273 262 minecraft:blackstone
fill 283 270 263 290 270 263 minecraft:basalt
fill 283 270 264 284 270 267 minecraft:blackstone
fill 283 270 268 286 270 268 minecraft:basalt
fill 283 270 269 286 270 269 minecraft:blackstone
fill 284 270 230 293 270 230 minecraft:blackstone
fill 284 270 234 289 270 235 minecraft:blackstone
setblock 284 270 236 minecraft:tuff
fill 284 270 237 290 271 237 minecraft:blackstone
fill 284 270 246 288 270 247 minecraft:blackstone
setblock 284 270 249 minecraft:tuff
fill 284 270 250 284 270 252 minecraft:blackstone
fill 284 270 260 295 270 260 minecraft:blackstone
setblock 284 270 262 minecraft:tuff
fill 285 270 229 286 270 229 minecraft:blackstone
setblock 285 270 238 minecraft:tuff
fill 285 270 245 292 270 245 minecraft:blackstone
fill 285 270 249 286 270 250 minecraft:blackstone
setblock 285 270 251 minecraft:tuff
fill 285 270 252 291 271 252 minecraft:blackstone
fill 285 270 261 289 270 262 minecraft:blackstone
setblock 285 270 264 minecraft:tuff
fill 285 270 265 285 270 267 minecraft:blackstone
fill 286 270 238 297 270 238 minecraft:basalt
fill 286 270 239 291 270 239 minecraft:blackstone
setblock 286 270 240 minecraft:tuff
setblock 286 270 253 minecraft:tuff
fill 286 270 264 286 270 265 minecraft:blackstone
setblock 286 270 266 minecraft:tuff
fill 286 270 267 292 271 267 minecraft:blackstone
setblock 287 270 229 minecraft:tuff
fill 287 270 240 297 270 240 minecraft:blackstone
setblock 287 270 242 minecraft:tuff
fill 287 270 250 290 271 250 minecraft:blackstone
fill 287 270 253 293 270 253 minecraft:basalt
fill 287 270 254 292 270 254 minecraft:blackstone
setblock 287 270 255 minecraft:tuff
fill 287 270 265 291 271 265 minecraft:blackstone
setblock 287 270 268 minecraft:tuff
fill 288 270 229 299 270 229 minecraft:blackstone
setblock 288 270 231 minecraft:tuff
fill 288 270 232 294 271 232 minecraft:blackstone
fill 288 270 241 292 270 242 minecraft:blackstone
setblock 288 270 244 minecraft:tuff
fill 288 270 255 295 270 255 minecraft:blackstone
setblock 288 270 257 minecraft:tuff
fill 288 270 268 299 270 268 minecraft:basalt
setblock 289 270 233 minecraft:tuff
fill 289 270 244 293 270 244 minecraft:blackstone
setblock 289 270 246 minecraft:tuff
fill 289 270 247 292 270 247 minecraft:blackstone
fill 289 270 256 293 270 257 minecraft:blackstone
setblock 289 270 259 minecraft:tuff
fill 289 270 269 293 270 269 minecraft:blackstone
fill 290 270 233 301 270 233 minecraft:basalt
fill 290 270 234 295 270 234 minecraft:blackstone
setblock 290 270 235 minecraft:tuff
fill 290 270 246 292 270 246 minecraft:blackstone
setblock 290 270 248 minecraft:tuff
fill 290 270 259 301 270 259 minecraft:blackstone
setblock 290 270 261 minecraft:tuff
fill 290 270 262 296 271 262 minecraft:blackstone
fill 291 270 235 302 270 235 minecraft:blackstone
setblock 291 270 237 minecraft:tuff
fill 291 270 248 292 270 248 minecraft:basalt
setblock 291 270 250 minecraft:tuff
setblock 291 270 263 minecraft:tuff
fill 292 270 236 296 270 237 minecraft:blackstone
setblock 292 270 239 minecraft:tuff
fill 292 270 249 292 270 250 minecraft:blackstone
setblock 292 270 252 minecraft:tuff
fill 292 270 263 303 270 263 minecraft:basalt
setblock 292 270 265 minecraft:tuff
fill 293 270 239 304 270 239 minecraft:blackstone
setblock 293 270 241 minecraft:tuff
fill 293 270 242 294 271 242 minecraft:blackstone
fill 293 270 245 293 271 245 minecraft:netherrack
setblock 293 270 246 minecraft:shroomlight
setblock 293 270 250 minecraft:shroomlight
fill 293 270 251 293 271 251 minecraft:netherrack
setblock 293 270 252 minecraft:blackstone
setblock 293 270 254 minecraft:tuff
fill 293 270 264 297 270 265 minecraft:blackstone
setblock 293 270 267 minecraft:tuff
setblock 294 270 230 minecraft:tuff
fill 294 270 241 295 271 241 minecraft:blackstone
fill 294 270 243 294 270 244 minecraft:netherrack
fill 294 270 252 294 270 253 minecraft:netherrack
setblock 294 270 254 minecraft:blackstone
setblock 294 270 256 minecraft:tuff
fill 294 270 257 300 270 257 minecraft:blackstone
fill 294 270 266 298 270 267 minecraft:blackstone
setblock 294 270 269 minecraft:tuff
fill 295 270 230 306 270 230 minecraft:blackstone
setblock 295 270 232 minecraft:tuff
fill 295 270 242 295 271 242 minecraft:netherrack
fill 295 270 254 295 271 254 minecraft:netherrack
fill 295 270 256 297 270 256 minecraft:blackstone
setblock 295 270 258 minecraft:tuff
fill 295 270 269 296 270 269 minecraft:blackstone
fill 296 270 231 300 270 232 minecraft:blackstone
setblock 296 270 234 minecraft:tuff
fill 296 270 241 297 270 241 minecraft:netherrack
fill 296 270 255 297 270 255 minecraft:netherrack
fill 296 270 258 307 270 258 minecraft:basalt
setblock 296 270 260 minecraft:tuff
fill 297 270 234 308 270 234 minecraft:blackstone
setblock 297 270 236 minecraft:tuff
fill 297 270 237 303 271 237 minecraft:blackstone
fill 297 270 260 308 270 260 minecraft:blackstone
setblock 297 270 262 minecraft:tuff
setblock 298 270 238 minecraft:tuff
fill 298 270 240 299 270 240 minecraft:netherrack
fill 298 270 256 299 270 256 minecraft:netherrack
fill 298 270 261 302 270 262 minecraft:blackstone
setblock 298 270 264 minecraft:tuff
fill 298 270 265 304 271 265 minecraft:blackstone
fill 299 270 238 310 270 238 minecraft:basalt
setblock 299 270 266 minecraft:tuff
fill 299 270 267 305 271 267 minecraft:blackstone
setblock 300 270 229 minecraft:tuff
setblock 300 270 268 minecraft:tuff
fill 301 270 229 312 270 229 minecraft:blackstone
setblock 301 270 231 minecraft:tuff
fill 301 270 232 307 271 232 minecraft:blackstone
setblock 301 270 257 minecraft:tuff
fill 301 270 268 312 270 268 minecraft:basalt
setblock 302 270 233 minecraft:tuff
fill 302 270 257 313 270 257 minecraft:blackstone
setblock 302 270 259 minecraft:tuff
fill 302 270 269 306 270 269 minecraft:blackstone
fill 303 270 233 314 270 233 minecraft:basalt
setblock 303 270 235 minecraft:tuff
fill 303 270 240 304 270 240 minecraft:netherrack
fill 303 270 256 304 270 256 minecraft:netherrack
fill 303 270 259 314 270 259 minecraft:blackstone
setblock 303 270 261 minecraft:tuff
fill 303 270 262 309 271 262 minecraft:blackstone
fill 304 270 235 315 270 235 minecraft:blackstone
setblock 304 270 237 minecraft:tuff
setblock 304 270 263 minecraft:tuff
fill 305 270 236 309 270 237 minecraft:blackstone
setblock 305 270 239 minecraft:tuff
fill 305 270 240 311 270 240 minecraft:blackstone
fill 305 270 241 306 270 241 minecraft:netherrack
fill 305 270 255 306 270 255 minecraft:netherrack
fill 305 270 256 306 270 256 minecraft:blackstone
fill 305 270 263 316 270 263 minecraft:basalt
setblock 305 270 265 minecraft:tuff
fill 306 270 239 313 270 239 minecraft:blackstone
fill 306 270 264 310 270 265 minecraft:blackstone
setblock 306 270 267 minecraft:tuff
setblock 307 270 230 minecraft:tuff
fill 307 270 241 314 270 241 minecraft:blackstone
fill 307 270 242 307 271 242 minecraft:netherrack
fill 307 270 254 307 271 254 minecraft:netherrack
fill 307 270 255 312 271 255 minecraft:blackstone
setblock 307 270 256 minecraft:tuff
fill 307 270 266 311 270 267 minecraft:blackstone
setblock 307 270 269 minecraft:tuff
fill 308 270 230 319 270 230 minecraft:blackstone
setblock 308 270 232 minecraft:tuff
fill 308 270 242 312 271 242 minecraft:blackstone
fill 308 270 243 308 270 244 minecraft:netherrack
fill 308 270 252 308 270 253 minecraft:netherrack
fill 308 270 254 318 270 254 minecraft:blackstone
fill 308 270 256 319 270 256 minecraft:blackstone
setblock 308 270 258 minecraft:tuff
fill 308 270 269 309 270 269 minecraft:blackstone
fill 309 270 231 313 270 232 minecraft:blackstone
setblock 309 270 234 minecraft:tuff
fill 309 270 243 319 270 243 minecraft:basalt
fill 309 270 244 313 270 244 minecraft:blackstone
fill 309 270 245 309 271 245 minecraft:netherrack
setblock 309 270 246 minecraft:shroomlight
setblock 309 270 250 minecraft:shroomlight
fill 309 270 251 309 271 251 minecraft:netherrack
fill 309 270 252 317 270 252 minecraft:blackstone
fill 309 270 253 311 270 253 minecraft:basalt
fill 309 270 258 320 270 258 minecraft:basalt
setblock 309 270 260 minecraft:tuff
fill 310 270 234 317 270 234 minecraft:blackstone
setblock 310 270 236 minecraft:tuff
fill 310 270 237 316 271 237 minecraft:blackstone
fill 310 270 245 314 270 247 minecraft:blackstone
fill 310 270 248 315 270 248 minecraft:basalt
setblock 310 270 249 minecraft:tuff
fill 310 270 250 310 270 251 minecraft:blackstone
fill 310 270 260 321 270 260 minecraft:blackstone
setblock 310 270 262 minecraft:tuff
setblock 311 270 238 minecraft:tuff
fill 311 270 250 316 271 250 minecraft:blackstone
setblock 311 270 251 minecraft:tuff
fill 311 270 261 315 270 262 minecraft:blackstone
setblock 311 270 264 minecraft:tuff
fill 311 270 265 317 271 265 minecraft:blackstone
fill 312 270 238 323 270 238 minecraft:basalt
setblock 312 270 240 minecraft:tuff
setblock 312 270 253 minecraft:tuff
setblock 312 270 266 minecraft:tuff
fill 312 270 267 318 271 267 minecraft:blackstone
setblock 313 270 229 minecraft:tuff
fill 313 270 240 314 271 240 minecraft:blackstone
setblock 313 270 242 minecraft:tuff
fill 313 270 253 323 270 253 minecraft:basalt
setblock 313 270 255 minecraft:tuff
setblock 313 270 268 minecraft:tuff
fill 314 270 229 321 270 229 minecraft:blackstone
setblock 314 270 231 minecraft:tuff
fill 314 270 232 320 271 232 minecraft:blackstone
fill 314 270 242 323 270 242 minecraft:blackstone
setblock 314 270 244 minecraft:tuff
fill 314 270 255 322 270 255 minecraft:blackstone
setblock 314 270 257 minecraft:tuff
fill 314 270 268 323 270 268 minecraft:basalt
fill 315 270 231 322 270 231 minecraft:blackstone
setblock 315 270 233 minecraft:tuff
fill 315 270 244 319 270 245 minecraft:blackstone
setblock 315 270 246 minecraft:tuff
fill 315 270 247 321 271 247 minecraft:blackstone
fill 315 270 257 323 270 257 minecraft:blackstone
setblock 315 270 259 minecraft:tuff
fill 315 270 269 317 270 269 minecraft:blackstone
fill 316 270 233 323 270 233 minecraft:basalt
setblock 316 270 235 minecraft:tuff
fill 316 270 241 318 271 241 minecraft:blackstone
fill 316 270 246 323 270 246 minecraft:blackstone
setblock 316 270 248 minecraft:tuff
setblock 316 270 261 minecraft:tuff
fill 316 270 262 322 271 262 minecraft:blackstone
fill 317 270 235 318 271 235 minecraft:blackstone
setblock 317 270 237 minecraft:tuff
setblock 317 270 239 minecraft:blackstone
fill 317 270 248 323 270 248 minecraft:basalt
setblock 317 270 250 minecraft:tuff
setblock 317 270 263 minecraft:tuff
fill 318 270 236 318 272 237 minecraft:blackstone
setblock 318 270 239 minecraft:tuff
fill 318 270 249 318 270 250 minecraft:blackstone
setblock 318 270 252 minecraft:tuff
fill 318 270 263 323 270 263 minecraft:basalt
setblock 318 270 265 minecraft:tuff
fill 319 270 237 323 270 237 minecraft:blackstone
fill 319 270 239 320 270 239 minecraft:blackstone
setblock 319 270 241 minecraft:tuff
fill 319 270 250 319 271 252 minecraft:blackstone
setblock 319 270 254 minecraft:tuff
fill 319 270 264 320 270 265 minecraft:blackstone
setblock 319 270 267 minecraft:tuff
setblock 319 270 269 minecraft:blackstone
setblock 320 270 230 minecraft:tuff
fill 320 270 236 322 271 236 minecraft:blackstone
fill 320 270 240 320 271 241 minecraft:blackstone
setblock 320 270 243 minecraft:tuff
fill 320 270 245 320 271 245 minecraft:blackstone
fill 320 270 252 323 270 252 minecraft:blackstone
fill 320 270 254 322 270 254 minecraft:blackstone
setblock 320 270 256 minecraft:tuff
fill 320 270 266 320 272 267 minecraft:blackstone
setblock 320 270 269 minecraft:tuff
fill 321 270 230 323 271 230 minecraft:blackstone
setblock 321 270 232 minecraft:tuff
setblock 321 270 234 minecraft:blackstone
fill 321 270 241 323 272 241 minecraft:blackstone
fill 321 270 243 323 270 243 minecraft:basalt
setblock 321 270 245 minecraft:tuff
fill 321 270 256 323 272 256 minecraft:blackstone
setblock 321 270 258 minecraft:tuff
setblock 321 270 264 minecraft:blackstone
fill 321 270 267 323 272 267 minecraft:blackstone
fill 321 270 269 322 270 269 minecraft:blackstone
fill 322 270 232 323 272 232 minecraft:blackstone
setblock 322 270 234 minecraft:tuff
setblock 322 270 239 minecraft:blackstone
fill 322 270 244 323 270 245 minecraft:blackstone
setblock 322 270 247 minecraft:tuff
setblock 322 270 249 minecraft:blackstone
fill 322 270 258 323 270 258 minecraft:basalt
setblock 322 270 260 minecraft:tuff
setblock 323 270 234 minecraft:blackstone
setblock 323 270 236 minecraft:tuff
fill 323 270 247 323 273 247 minecraft:blackstone
setblock 323 270 249 minecraft:tuff
fill 323 270 259 323 270 260 minecraft:blackstone
setblock 323 270 262 minecraft:tuff
setblock 323 270 264 minecraft:blackstone
fill 283 271 228 283 283 228 minecraft:blackstone
fill 283 271 229 291 271 229 minecraft:basalt
fill 283 271 231 286 271 233 minecraft:blackstone
fill 283 271 234 287 271 234 minecraft:basalt
fill 283 271 235 288 271 236 minecraft:blackstone
setblock 283 271 237 minecraft:tuff
fill 283 271 238 289 272 238 minecraft:blackstone
setblock 283 271 239 minecraft:basalt
fill 283 271 240 284 271 241 minecraft:blackstone
fill 283 271 243 285 272 243 minecraft:blackstone
fill 283 271 244 292 271 244 minecraft:basalt
fill 283 271 247 287 271 248 minecraft:blackstone
fill 283 271 249 288 271 249 minecraft:basalt
setblock 283 271 250 minecraft:tuff
fill 283 271 251 283 271 253 minecraft:blackstone
fill 283 271 254 284 271 254 minecraft:basalt
fill 283 271 255 285 271 256 minecraft:blackstone
fill 283 271 258 286 272 258 minecraft:blackstone
fill 283 271 259 293 271 259 minecraft:basalt
fill 283 271 260 287 271 260 minecraft:blackstone
setblock 283 271 263 minecraft:tuff
fill 283 271 264 289 271 264 minecraft:basalt
fill 283 271 265 283 271 268 minecraft:blackstone
fill 283 271 269 285 271 269 minecraft:basalt
fill 284 271 230 285 271 230 minecraft:blackstone
setblock 284 271 239 minecraft:tuff
fill 284 271 246 291 271 246 minecraft:blackstone
fill 284 271 250 286 271 251 minecraft:blackstone
setblock 284 271 252 minecraft:tuff
fill 284 271 253 290 272 253 minecraft:blackstone
fill 284 271 262 288 271 263 minecraft:blackstone
setblock 284 271 265 minecraft:tuff
fill 284 271 266 284 271 268 minecraft:blackstone
fill 285 271 239 296 271 239 minecraft:basalt
fill 285 271 240 290 271 240 minecraft:blackstone
setblock 285 271 241 minecraft:tuff
fill 285 271 245 286 271 245 minecraft:blackstone
setblock 285 271 254 minecraft:tuff
fill 285 271 261 294 271 261 minecraft:blackstone
fill 285 271 265 286 271 266 minecraft:blackstone
setblock 285 271 267 minecraft:tuff
fill 285 271 268 291 272 268 minecraft:blackstone
setblock 286 271 230 minecraft:tuff
fill 286 271 241 293 271 241 minecraft:blackstone
setblock 286 271 243 minecraft:tuff
fill 286 271 254 294 271 254 minecraft:basalt
fill 286 271 255 291 271 255 minecraft:blackstone
setblock 286 271 256 minecraft:tuff
setblock 286 271 269 minecraft:tuff
fill 287 271 230 292 271 231 minecraft:blackstone
setblock 287 271 232 minecraft:tuff
fill 287 271 233 293 272 233 minecraft:blackstone
fill 287 271 242 291 271 243 minecraft:blackstone
setblock 287 271 245 minecraft:tuff
fill 287 271 251 289 272 251 minecraft:blackstone
fill 287 271 256 296 271 256 minecraft:blackstone
setblock 287 271 258 minecraft:tuff
fill 287 271 266 290 272 266 minecraft:blackstone
fill 287 271 269 298 271 269 minecraft:basalt
setblock 288 271 234 minecraft:tuff
fill 288 271 245 292 271 245 minecraft:blackstone
setblock 288 271 247 minecraft:tuff
fill 288 271 248 291 271 248 minecraft:blackstone
fill 288 271 257 292 271 258 minecraft:blackstone
setblock 288 271 260 minecraft:tuff
fill 289 271 234 300 271 234 minecraft:basalt
fill 289 271 235 294 271 235 minecraft:blackstone
setblock 289 271 236 minecraft:tuff
fill 289 271 247 291 271 247 minecraft:blackstone
setblock 289 271 249 minecraft:tuff
fill 289 271 260 300 271 260 minecraft:blackstone
setblock 289 271 262 minecraft:tuff
fill 289 271 263 295 272 263 minecraft:blackstone
fill 290 271 236 301 271 236 minecraft:blackstone
setblock 290 271 238 minecraft:tuff
fill 290 271 249 291 271 249 minecraft:basalt
setblock 290 271 251 minecraft:tuff
setblock 290 271 264 minecraft:tuff
fill 291 271 237 295 271 238 minecraft:blackstone
setblock 291 271 240 minecraft:tuff
fill 291 271 250 291 271 251 minecraft:blackstone
setblock 291 271 253 minecraft:tuff
fill 291 271 264 302 271 264 minecraft:basalt
setblock 291 271 266 minecraft:tuff
setblock 292 271 229 minecraft:tuff
fill 292 271 240 296 271 240 minecraft:blackstone
setblock 292 271 242 minecraft:tuff
fill 292 271 243 293 271 243 minecraft:blackstone
fill 292 271 246 292 272 246 minecraft:shroomlight
fill 292 271 247 292 271 249 minecraft:netherrack
fill 292 271 250 292 272 250 minecraft:shroomlight
fill 292 271 251 292 271 253 minecraft:blackstone
setblock 292 271 255 minecraft:tuff
fill 292 271 265 296 271 266 minecraft:blackstone
setblock 292 271 268 minecraft:tuff
fill 293 271 229 304 271 229 minecraft:basalt
fill 293 271 230 298 271 230 minecraft:blackstone
setblock 293 271 231 minecraft:tuff
setblock 293 271 244 minecraft:netherrack
setblock 293 271 252 minecraft:netherrack
setblock 293 271 253 minecraft:blackstone
fill 293 271 255 295 271 255 minecraft:blackstone
setblock 293 271 257 minecraft:tuff
fill 293 271 258 299 272 258 minecraft:blackstone
fill 293 271 267 297 271 268 minecraft:blackstone
fill 294 271 231 305 271 231 minecraft:blackstone
setblock 294 271 233 minecraft:tuff
setblock 294 271 243 minecraft:netherrack
setblock 294 271 253 minecraft:netherrack
fill 294 271 257 298 271 257 minecraft:blackstone
setblock 294 271 259 minecraft:tuff
fill 295 271 232 299 271 233 minecraft:blackstone
setblock 295 271 235 minecraft:tuff
fill 295 271 259 306 271 259 minecraft:basalt
setblock 295 271 261 minecraft:tuff
fill 296 271 235 307 271 235 minecraft:blackstone
setblock 296 271 237 minecraft:tuff
fill 296 271 238 302 271 238 minecraft:blackstone
setblock 296 271 241 minecraft:netherrack
setblock 296 271 255 minecraft:netherrack
fill 296 271 261 307 271 261 minecraft:blackstone
setblock 296 271 263 minecraft:tuff
setblock 297 271 239 minecraft:tuff
setblock 297 271 240 minecraft:shroomlight
setblock 297 271 256 minecraft:shroomlight
fill 297 271 262 301 271 263 minecraft:blackstone
setblock 297 271 265 minecraft:tuff
fill 297 271 266 303 272 266 minecraft:blackstone
setblock 298 271 239 minecraft:basalt
setblock 298 271 240 minecraft:netherrack
setblock 298 271 256 minecraft:netherrack
setblock 298 271 267 minecraft:tuff
fill 298 271 268 304 272 268 minecraft:blackstone
setblock 299 271 230 minecraft:tuff
fill 299 271 239 300 271 239 minecraft:netherrack
fill 299 271 257 300 271 257 minecraft:netherrack
setblock 299 271 269 minecraft:tuff
fill 300 271 230 311 271 230 minecraft:blackstone
setblock 300 271 232 minecraft:tuff
fill 300 271 233 306 272 233 minecraft:blackstone
setblock 300 271 258 minecraft:tuff
fill 300 271 269 311 271 269 minecraft:basalt
setblock 301 271 234 minecraft:tuff
setblock 301 271 239 minecraft:shroomlight
setblock 301 271 257 minecraft:shroomlight
fill 301 271 258 312 271 258 minecraft:blackstone
setblock 301 271 260 minecraft:tuff
fill 302 271 234 313 271 234 minecraft:basalt
setblock 302 271 236 minecraft:tuff
fill 302 271 239 303 271 239 minecraft:netherrack
fill 302 271 257 303 271 257 minecraft:netherrack
fill 302 271 260 313 271 260 minecraft:blackstone
setblock 302 271 262 minecraft:tuff
fill 302 271 263 308 272 263 minecraft:blackstone
fill 303 271 236 314 271 236 minecraft:blackstone
setblock 303 271 238 minecraft:tuff
setblock 303 271 264 minecraft:tuff
fill 304 271 237 308 271 238 minecraft:blackstone
fill 304 271 239 309 271 239 minecraft:basalt
setblock 304 271 240 minecraft:netherrack
setblock 304 271 256 minecraft:netherrack
fill 304 271 257 305 271 257 minecraft:blackstone
fill 304 271 264 315 271 264 minecraft:basalt
setblock 304 271 266 minecraft:tuff
setblock 305 271 229 minecraft:tuff
setblock 305 271 240 minecraft:shroomlight
setblock 305 271 256 minecraft:shroomlight
fill 305 271 265 309 271 266 minecraft:blackstone
setblock 305 271 268 minecraft:tuff
fill 306 271 229 317 271 229 minecraft:basalt
setblock 306 271 231 minecraft:tuff
fill 306 271 240 312 271 240 minecraft:blackstone
setblock 306 271 241 minecraft:netherrack
setblock 306 271 255 minecraft:netherrack
fill 306 271 256 311 271 256 minecraft:blackstone
setblock 306 271 257 minecraft:tuff
fill 306 271 267 310 271 268 minecraft:blackstone
fill 307 271 231 318 271 231 minecraft:blackstone
setblock 307 271 233 minecraft:tuff
fill 307 271 241 310 271 241 minecraft:blackstone
fill 307 271 257 318 271 257 minecraft:blackstone
setblock 307 271 259 minecraft:tuff
fill 308 271 232 312 271 233 minecraft:blackstone
setblock 308 271 235 minecraft:tuff
setblock 308 271 243 minecraft:netherrack
setblock 308 271 253 minecraft:netherrack
fill 308 271 254 310 271 254 minecraft:basalt
fill 308 271 259 319 271 259 minecraft:basalt
setblock 308 271 261 minecraft:tuff
fill 309 271 235 316 271 235 minecraft:blackstone
setblock 309 271 237 minecraft:tuff
fill 309 271 238 315 272 238 minecraft:blackstone
fill 309 271 243 311 271 243 minecraft:blackstone
setblock 309 271 244 minecraft:netherrack
setblock 309 271 252 minecraft:netherrack
fill 309 271 253 316 271 253 minecraft:blackstone
fill 309 271 261 320 271 261 minecraft:blackstone
setblock 309 271 263 minecraft:tuff
setblock 310 271 239 minecraft:tuff
fill 310 271 244 318 271 244 minecraft:basalt
fill 310 271 245 312 271 245 minecraft:blackstone
fill 310 271 246 310 272 246 minecraft:shroomlight
fill 310 271 247 310 271 249 minecraft:netherrack
fill 310 271 250 310 272 250 minecraft:shroomlight
fill 310 271 251 315 271 251 minecraft:blackstone
setblock 310 271 252 minecraft:tuff
fill 310 271 262 314 271 263 minecraft:blackstone
setblock 310 271 265 minecraft:tuff
fill 310 271 266 316 272 266 minecraft:blackstone
fill 311 271 239 322 271 239 minecraft:basalt
setblock 311 271 241 minecraft:tuff
fill 311 271 246 313 271 248 minecraft:blackstone
fill 311 271 249 314 271 249 minecraft:basalt
fill 311 271 252 318 271 252 minecraft:blackstone
setblock 311 271 254 minecraft:tuff
setblock 311 271 267 minecraft:tuff
fill 311 271 268 317 272 268 minecraft:blackstone
setblock 312 271 230 minecraft:tuff
fill 312 271 241 314 272 241 minecraft:blackstone
setblock 312 271 243 minecraft:tuff
fill 312 271 254 323 271 254 minecraft:basalt
setblock 312 271 256 minecraft:tuff
setblock 312 271 269 minecraft:tuff
fill 313 271 230 320 271 230 minecraft:blackstone
setblock 313 271 232 minecraft:tuff
fill 313 271 233 319 272 233 minecraft:blackstone
fill 313 271 242 317 271 243 minecraft:blackstone
setblock 313 271 245 minecraft:tuff
fill 313 271 255 317 271 256 minecraft:blackstone
setblock 313 271 258 minecraft:tuff
fill 313 271 269 323 271 269 minecraft:basalt
setblock 314 271 234 minecraft:tuff
fill 314 271 245 319 271 246 minecraft:blackstone
setblock 314 271 247 minecraft:tuff
fill 314 271 248 320 272 248 minecraft:blackstone
fill 314 271 258 323 271 258 minecraft:blackstone
setblock 314 271 260 minecraft:tuff
fill 315 271 234 323 271 234 minecraft:basalt
setblock 315 271 236 minecraft:tuff
setblock 315 271 249 minecraft:tuff
fill 315 271 260 323 271 260 minecraft:blackstone
setblock 315 271 262 minecraft:tuff
fill 315 271 263 321 272 263 minecraft:blackstone
fill 316 271 236 317 272 236 minecraft:blackstone
setblock 316 271 238 minecraft:tuff
setblock 316 271 240 minecraft:blackstone
fill 316 271 249 323 271 249 minecraft:basalt
setblock 316 271 251 minecraft:tuff
setblock 316 271 264 minecraft:tuff
fill 317 271 237 317 273 238 minecraft:blackstone
setblock 317 271 240 minecraft:tuff
fill 317 271 250 318 271 251 minecraft:blackstone
setblock 317 271 253 minecraft:tuff
fill 317 271 264 323 271 264 minecraft:basalt
setblock 317 271 266 minecraft:tuff
setblock 318 271 229 minecraft:tuff
fill 318 271 238 323 271 238 minecraft:blackstone
fill 318 271 240 319 271 240 minecraft:blackstone
setblock 318 271 242 minecraft:tuff
fill 318 271 243 323 272 243 minecraft:blackstone
fill 318 271 253 323 271 253 minecraft:blackstone
setblock 318 271 255 minecraft:tuff
fill 318 271 256 320 272 256 minecraft:blackstone
fill 318 271 265 319 271 266 minecraft:blackstone
setblock 318 271 268 minecraft:tuff
fill 319 271 229 323 271 229 minecraft:basalt
setblock 319 271 231 minecraft:tuff
fill 319 271 237 321 272 237 minecraft:blackstone
fill 319 271 241 319 272 242 minecraft:blackstone
setblock 319 271 244 minecraft:tuff
fill 319 271 255 322 271 255 minecraft:blackstone
setblock 319 271 257 minecraft:tuff
fill 319 271 267 319 273 268 minecraft:blackstone
fill 320 271 231 322 272 231 minecraft:blackstone
setblock 320 271 233 minecraft:tuff
setblock 320 271 235 minecraft:blackstone
fill 320 271 242 323 271 242 minecraft:blackstone
fill 320 271 244 323 271 244 minecraft:basalt
setblock 320 271 246 minecraft:tuff
fill 320 271 252 322 272 252 minecraft:blackstone
fill 320 271 257 323 273 257 minecraft:blackstone
setblock 320 271 259 minecraft:tuff
setblock 320 271 265 minecraft:blackstone
fill 320 271 268 323 271 268 minecraft:blackstone
fill 321 271 232 321 273 233 minecraft:blackstone
setblock 321 271 235 minecraft:tuff
setblock 321 271 240 minecraft:blackstone
fill 321 271 245 323 271 246 minecraft:blackstone
setblock 321 271 248 minecraft:tuff
setblock 321 271 250 minecraft:blackstone
fill 321 271 259 323 271 259 minecraft:basalt
setblock 321 271 261 minecraft:tuff
fill 322 271 233 323 273 233 minecraft:blackstone
fill 322 271 235 323 271 235 minecraft:blackstone
setblock 322 271 237 minecraft:tuff
fill 322 271 247 322 273 248 minecraft:blackstone
setblock 322 271 250 minecraft:tuff
fill 322 271 261 323 272 261 minecraft:blackstone
setblock 322 271 263 minecraft:tuff
setblock 322 271 265 minecraft:blackstone
fill 323 271 236 323 272 237 minecraft:blackstone
setblock 323 271 239 minecraft:tuff
fill 323 271 248 323 273 248 minecraft:blackstone
setblock 323 271 250 minecraft:blackstone
setblock 323 271 252 minecraft:tuff
fill 323 271 262 323 273 263 minecraft:blackstone
setblock 323 271 265 minecraft:tuff
setblock 324 271 261 minecraft:magma_block
fill 282 272 230 282 283 230 minecraft:blackstone
fill 283 272 229 283 275 229 minecraft:blackstone
fill 283 272 230 290 272 230 minecraft:basalt
fill 283 272 231 284 272 234 minecraft:blackstone
fill 283 272 235 286 272 235 minecraft:basalt
fill 283 272 236 287 272 237 minecraft:blackstone
fill 283 272 239 288 273 239 minecraft:blackstone
setblock 283 272 240 minecraft:tuff
fill 283 272 241 283 272 242 minecraft:blackstone
fill 283 272 244 284 275 244 minecraft:blackstone
fill 283 272 245 291 272 245 minecraft:basalt
fill 283 272 247 286 272 249 minecraft:blackstone
fill 283 272 250 287 272 250 minecraft:basalt
fill 283 272 251 286 272 252 minecraft:blackstone
setblock 283 272 253 minecraft:tuff
fill 283 272 254 289 273 254 minecraft:blackstone
setblock 283 272 255 minecraft:basalt
fill 283 272 256 284 272 257 minecraft:blackstone
fill 283 272 259 285 273 259 minecraft:blackstone
fill 283 272 260 292 272 260 minecraft:basalt
fill 283 272 263 287 272 264 minecraft:blackstone
fill 283 272 265 288 272 265 minecraft:basalt
setblock 283 272 266 minecraft:tuff
fill 283 272 267 283 272 269 minecraft:blackstone
setblock 284 272 229 minecraft:tuff
fill 284 272 240 295 272 240 minecraft:basalt
fill 284 272 241 289 272 241 minecraft:blackstone
setblock 284 272 242 minecraft:tuff
fill 284 272 246 285 272 246 minecraft:blackstone
setblock 284 272 255 minecraft:tuff
fill 284 272 262 293 272 262 minecraft:blackstone
fill 284 272 266 286 272 267 minecraft:blackstone
setblock 284 272 268 minecraft:tuff
fill 284 272 269 290 273 269 minecraft:blackstone
fill 285 272 229 296 272 229 minecraft:blackstone
setblock 285 272 231 minecraft:tuff
fill 285 272 232 285 272 234 minecraft:blackstone
fill 285 272 242 293 272 242 minecraft:blackstone
setblock 285 272 244 minecraft:tuff
fill 285 272 255 294 272 255 minecraft:basalt
fill 285 272 256 290 272 256 minecraft:blackstone
setblock 285 272 257 minecraft:tuff
fill 285 272 261 286 272 261 minecraft:blackstone
fill 286 272 231 291 272 232 minecraft:blackstone
setblock 286 272 233 minecraft:tuff
fill 286 272 234 292 273 234 minecraft:blackstone
fill 286 272 243 290 272 244 minecraft:blackstone
setblock 286 272 246 minecraft:tuff
fill 286 272 257 296 272 257 minecraft:blackstone
setblock 286 272 259 minecraft:tuff
setblock 287 272 235 minecraft:tuff
fill 287 272 246 290 272 247 minecraft:blackstone
setblock 287 272 248 minecraft:tuff
fill 287 272 249 290 273 249 minecraft:blackstone
fill 287 272 252 288 273 252 minecraft:blackstone
fill 287 272 258 291 272 259 minecraft:blackstone
setblock 287 272 261 minecraft:tuff
fill 287 272 267 289 273 267 minecraft:blackstone
fill 288 272 235 299 272 235 minecraft:basalt
fill 288 272 236 293 272 236 minecraft:blackstone
setblock 288 272 237 minecraft:tuff
fill 288 272 248 290 273 248 minecraft:blackstone
setblock 288 272 250 minecraft:tuff
fill 288 272 261 299 272 261 minecraft:blackstone
setblock 288 272 263 minecraft:tuff
fill 288 272 264 294 273 264 minecraft:blackstone
fill 289 272 237 300 272 237 minecraft:blackstone
setblock 289 272 239 minecraft:tuff
fill 289 272 250 291 272 250 minecraft:basalt
setblock 289 272 252 minecraft:tuff
setblock 289 272 265 minecraft:tuff
fill 290 272 238 294 272 239 minecraft:blackstone
setblock 290 272 241 minecraft:tuff
fill 290 272 251 291 272 252 minecraft:blackstone
setblock 290 272 254 minecraft:tuff
fill 290 272 265 301 272 265 minecraft:basalt
setblock 290 272 267 minecraft:tuff
setblock 291 272 230 minecraft:tuff
fill 291 272 241 294 272 241 minecraft:blackstone
setblock 291 272 243 minecraft:tuff
fill 291 272 244 291 273 244 minecraft:blackstone
setblock 291 272 246 minecraft:blackstone
fill 291 272 247 291 272 249 minecraft:magma_block
fill 291 272 253 292 272 254 minecraft:blackstone
setblock 291 272 256 minecraft:tuff
fill 291 272 266 295 272 267 minecraft:blackstone
setblock 291 272 269 minecraft:tuff
setblock 292 272 228 minecraft:magma_block
fill 292 272 230 303 272 230 minecraft:basalt
fill 292 272 231 297 272 231 minecraft:blackstone
setblock 292 272 232 minecraft:tuff
setblock 292 272 243 minecraft:blackstone
fill 292 272 244 292 272 245 minecraft:magma_block
fill 292 272 251 292 272 252 minecraft:magma_block
fill 292 272 256 295 272 256 minecraft:blackstone
setblock 292 272 258 minecraft:tuff
fill 292 272 259 298 273 259 minecraft:blackstone
fill 292 272 268 296 272 269 minecraft:blackstone
fill 293 272 232 304 272 232 minecraft:blackstone
setblock 293 272 234 minecraft:tuff
setblock 293 272 243 minecraft:magma_block
setblock 293 272 253 minecraft:magma_block
setblock 293 272 254 minecraft:blackstone
setblock 293 272 260 minecraft:tuff
fill 294 272 233 298 272 234 minecraft:blackstone
setblock 294 272 236 minecraft:tuff
setblock 294 272 242 minecraft:magma_block
setblock 294 272 254 minecraft:magma_block
fill 294 272 260 305 272 260 minecraft:basalt
setblock 294 272 262 minecraft:tuff
fill 295 272 236 306 272 236 minecraft:blackstone
setblock 295 272 238 minecraft:tuff
fill 295 272 239 296 272 239 minecraft:blackstone
setblock 295 272 241 minecraft:magma_block
setblock 295 272 255 minecraft:magma_block
fill 295 272 262 306 272 262 minecraft:blackstone
setblock 295 272 264 minecraft:tuff
fill 296 272 238 299 272 238 minecraft:blackstone
setblock 296 272 240 minecraft:magma_block
setblock 296 272 256 minecraft:magma_block
fill 296 272 263 300 272 264 minecraft:blackstone
setblock 296 272 266 minecraft:tuff
fill 296 272 267 302 273 267 minecraft:blackstone
setblock 297 272 229 minecraft:tuff
fill 297 272 239 297 273 239 minecraft:shroomlight
fill 297 272 257 297 273 257 minecraft:shroomlight
setblock 297 272 268 minecraft:tuff
fill 297 272 269 303 273 269 minecraft:blackstone
fill 298 272 229 309 272 229 minecraft:blackstone
setblock 298 272 231 minecraft:tuff
fill 298 272 239 299 272 239 minecraft:magma_block
fill 298 272 257 299 272 257 minecraft:magma_block
setblock 299 272 228 minecraft:crying_obsidian
fill 299 272 231 310 272 231 minecraft:blackstone
setblock 299 272 233 minecraft:tuff
fill 299 272 234 305 273 234 minecraft:blackstone
setblock 299 272 259 minecraft:tuff
setblock 300 272 235 minecraft:tuff
setblock 300 272 238 minecraft:magma_block
setblock 300 272 258 minecraft:magma_block
fill 300 272 259 311 272 259 minecraft:blackstone
setblock 300 272 261 minecraft:tuff
fill 301 272 235 312 272 235 minecraft:basalt
setblock 301 272 237 minecraft:tuff
fill 301 272 238 301 273 238 minecraft:shroomlight
fill 301 272 258 301 273 258 minecraft:shroomlight
fill 301 272 261 312 272 261 minecraft:blackstone
setblock 301 272 263 minecraft:tuff
fill 301 272 264 307 273 264 minecraft:blackstone
fill 302 272 237 313 272 237 minecraft:blackstone
setblock 302 272 238 minecraft:magma_block
setblock 302 272 258 minecraft:magma_block
setblock 302 272 265 minecraft:tuff
fill 303 272 238 307 272 238 minecraft:blackstone
fill 303 272 239 304 272 239 minecraft:magma_block
fill 303 272 257 304 272 257 minecraft:magma_block
fill 303 272 258 304 272 258 minecraft:blackstone
fill 303 272 265 314 272 265 minecraft:basalt
setblock 303 272 267 minecraft:tuff
setblock 304 272 230 minecraft:tuff
fill 304 272 266 308 272 267 minecraft:blackstone
setblock 304 272 269 minecraft:tuff
fill 305 272 230 316 272 230 minecraft:basalt
setblock 305 272 232 minecraft:tuff
fill 305 272 239 305 273 239 minecraft:shroomlight
fill 305 272 257 305 273 257 minecraft:shroomlight
setblock 305 272 258 minecraft:tuff
fill 305 272 268 309 272 269 minecraft:blackstone
fill 306 272 232 317 272 232 minecraft:blackstone
setblock 306 272 234 minecraft:tuff
fill 306 272 239 314 272 239 minecraft:blackstone
setblock 306 272 240 minecraft:magma_block
setblock 306 272 256 minecraft:magma_block
fill 306 272 257 310 272 258 minecraft:blackstone
setblock 306 272 260 minecraft:tuff
fill 307 272 233 311 272 234 minecraft:blackstone
setblock 307 272 236 minecraft:tuff
fill 307 272 240 308 272 240 minecraft:basalt
setblock 307 272 241 minecraft:magma_block
setblock 307 272 255 minecraft:magma_block
fill 307 272 256 316 272 256 minecraft:blackstone
fill 307 272 260 318 272 260 minecraft:basalt
setblock 307 272 262 minecraft:tuff
fill 308 272 236 315 272 236 minecraft:blackstone
setblock 308 272 238 minecraft:tuff
fill 308 272 241 311 272 241 minecraft:blackstone
setblock 308 272 242 minecraft:magma_block
setblock 308 272 254 minecraft:magma_block
fill 308 272 255 309 272 255 minecraft:basalt
fill 308 272 262 319 272 262 minecraft:blackstone
setblock 308 272 264 minecraft:tuff
setblock 309 272 240 minecraft:tuff
setblock 309 272 242 minecraft:blackstone
setblock 309 272 243 minecraft:magma_block
setblock 309 272 253 minecraft:magma_block
fill 309 272 254 315 272 254 minecraft:blackstone
fill 309 272 263 313 272 264 minecraft:blackstone
setblock 309 272 266 minecraft:tuff
fill 309 272 267 315 273 267 minecraft:blackstone
setblock 310 272 229 minecraft:tuff
fill 310 272 240 321 272 240 minecraft:basalt
setblock 310 272 242 minecraft:tuff
fill 310 272 243 316 272 243 minecraft:blackstone
fill 310 272 244 310 272 245 minecraft:magma_block
fill 310 272 251 310 272 252 minecraft:magma_block
fill 310 272 253 321 272 253 minecraft:blackstone
setblock 310 272 255 minecraft:tuff
setblock 310 272 268 minecraft:tuff
fill 310 272 269 316 273 269 minecraft:blackstone
fill 311 272 229 322 272 229 minecraft:blackstone
setblock 311 272 231 minecraft:tuff
fill 311 272 242 318 272 242 minecraft:blackstone
setblock 311 272 244 minecraft:tuff
fill 311 272 245 317 272 245 minecraft:basalt
setblock 311 272 246 minecraft:blackstone
fill 311 272 247 311 272 249 minecraft:magma_block
fill 311 272 250 313 272 250 minecraft:basalt
fill 311 272 251 314 272 252 minecraft:blackstone
fill 311 272 255 322 272 255 minecraft:basalt
setblock 311 272 257 minecraft:tuff
fill 311 272 258 317 273 258 minecraft:blackstone
fill 312 272 231 319 272 231 minecraft:blackstone
setblock 312 272 233 minecraft:tuff
fill 312 272 234 318 273 234 minecraft:blackstone
fill 312 272 244 323 272 244 minecraft:blackstone
setblock 312 272 246 minecraft:tuff
fill 312 272 247 312 272 249 minecraft:blackstone
fill 312 272 257 319 272 257 minecraft:blackstone
setblock 312 272 259 minecraft:tuff
setblock 313 272 235 minecraft:tuff
fill 313 272 246 318 272 247 minecraft:blackstone
setblock 313 272 248 minecraft:tuff
fill 313 272 249 319 273 249 minecraft:blackstone
fill 313 272 259 323 272 259 minecraft:blackstone
setblock 313 272 261 minecraft:tuff
fill 314 272 235 323 272 235 minecraft:basalt
setblock 314 272 237 minecraft:tuff
setblock 314 272 250 minecraft:tuff
fill 314 272 261 321 272 261 minecraft:blackstone
setblock 314 272 263 minecraft:tuff
fill 314 272 264 320 273 264 minecraft:blackstone
fill 315 272 237 316 273 237 minecraft:blackstone
setblock 315 272 239 minecraft:tuff
setblock 315 272 241 minecraft:blackstone
fill 315 272 250 323 272 250 minecraft:basalt
fill 315 272 251 320 272 251 minecraft:blackstone
setblock 315 272 252 minecraft:tuff
setblock 315 272 265 minecraft:tuff
fill 316 272 238 316 274 239 minecraft:blackstone
setblock 316 272 241 minecraft:tuff
fill 316 272 252 319 273 252 minecraft:blackstone
setblock 316 272 254 minecraft:tuff
fill 316 272 265 323 272 265 minecraft:basalt
setblock 316 272 267 minecraft:tuff
setblock 317 272 230 minecraft:tuff
fill 317 272 239 323 272 239 minecraft:blackstone
fill 317 272 241 318 272 241 minecraft:blackstone
setblock 317 272 243 minecraft:tuff
fill 317 272 254 323 272 254 minecraft:blackstone
setblock 317 272 256 minecraft:tuff
fill 317 272 266 318 272 267 minecraft:blackstone
setblock 317 272 269 minecraft:tuff
fill 318 272 230 323 272 230 minecraft:basalt
setblock 318 272 232 minecraft:tuff
fill 318 272 238 320 273 238 minecraft:blackstone
setblock 318 272 245 minecraft:tuff
setblock 318 272 258 minecraft:tuff
fill 318 272 268 318 274 269 minecraft:blackstone
fill 319 272 232 320 273 232 minecraft:blackstone
setblock 319 272 234 minecraft:tuff
setblock 319 272 236 minecraft:blackstone
fill 319 272 245 323 272 245 minecraft:basalt
fill 319 272 246 323 272 246 minecraft:blackstone
setblock 319 272 247 minecraft:tuff
fill 319 272 258 323 272 258 minecraft:blackstone
setblock 319 272 260 minecraft:tuff
setblock 319 272 266 minecraft:blackstone
fill 319 272 269 323 272 269 minecraft:blackstone
setblock 319 272 270 minecraft:magma_block
fill 320 272 233 320 274 234 minecraft:blackstone
setblock 320 272 236 minecraft:tuff
fill 320 272 241 320 272 242 minecraft:blackstone
fill 320 272 247 321 273 247 minecraft:blackstone
setblock 320 272 249 minecraft:tuff
fill 320 272 260 323 272 260 minecraft:basalt
setblock 320 272 262 minecraft:tuff
fill 320 272 268 322 273 268 minecraft:blackstone
fill 321 272 234 323 274 234 minecraft:blackstone
fill 321 272 236 322 272 236 minecraft:blackstone
setblock 321 272 238 minecraft:tuff
fill 321 272 242 322 273 242 minecraft:blackstone
fill 321 272 248 321 274 249 minecraft:blackstone
setblock 321 272 251 minecraft:tuff
fill 321 272 262 322 273 262 minecraft:blackstone
setblock 321 272 264 minecraft:tuff
setblock 321 272 266 minecraft:blackstone
fill 322 272 237 322 273 238 minecraft:blackstone
setblock 322 272 240 minecraft:tuff
fill 322 272 249 323 274 249 minecraft:blackstone
fill 322 272 251 323 272 251 minecraft:blackstone
setblock 322 272 253 minecraft:tuff
fill 322 272 263 322 274 264 minecraft:blackstone
setblock 322 272 266 minecraft:tuff
setblock 323 272 229 minecraft:tuff
fill 323 272 238 323 274 238 minecraft:blackstone
setblock 323 272 240 minecraft:basalt
setblock 323 272 242 minecraft:tuff
fill 323 272 252 323 273 253 minecraft:blackstone
setblock 323 272 255 minecraft:tuff
fill 323 272 264 323 274 264 minecraft:blackstone
setblock 323 272 266 minecraft:blackstone
setblock 323 272 268 minecraft:tuff
setblock 324 272 245 minecraft:crying_obsidian
fill 324 272 261 324 283 261 minecraft:blackstone
setblock 283 273 230 minecraft:tuff
fill 283 273 231 289 273 231 minecraft:basalt
fill 283 273 232 283 273 235 minecraft:blackstone
fill 283 273 236 285 273 236 minecraft:basalt
fill 283 273 237 286 273 238 minecraft:blackstone
fill 283 273 240 287 274 240 minecraft:blackstone
fill 283 273 241 293 273 241 minecraft:basalt
fill 283 273 242 288 273 242 minecraft:blackstone
setblock 283 273 243 minecraft:tuff
fill 283 273 245 283 276 245 minecraft:blackstone
fill 283 273 246 290 273 246 minecraft:basalt
fill 283 273 247 284 273 250 minecraft:blackstone
fill 283 273 251 286 273 251 minecraft:basalt
fill 283 273 252 286 273 253 minecraft:blackstone
fill 283 273 255 288 274 255 minecraft:blackstone
setblock 283 273 256 minecraft:tuff
fill 283 273 257 283 273 258 minecraft:blackstone
fill 283 273 260 284 276 260 minecraft:blackstone
fill 283 273 261 291 273 261 minecraft:basalt
fill 283 273 263 286 273 265 minecraft:blackstone
fill 283 273 266 287 273 266 minecraft:basalt
fill 283 273 267 286 273 268 minecraft:blackstone
setblock 283 273 269 minecraft:tuff
fill 284 273 229 288 273 230 minecraft:blackstone
setblock 284 273 232 minecraft:tuff
fill 284 273 233 284 273 235 minecraft:blackstone
fill 284 273 243 291 273 243 minecraft:blackstone
setblock 284 273 245 minecraft:tuff
fill 284 273 256 294 273 256 minecraft:basalt
fill 284 273 257 289 273 257 minecraft:blackstone
setblock 284 273 258 minecraft:tuff
fill 284 273 262 285 273 262 minecraft:blackstone
fill 285 273 232 290 273 233 minecraft:blackstone
setblock 285 273 234 minecraft:tuff
fill 285 273 235 291 274 235 minecraft:blackstone
fill 285 273 244 289 273 245 minecraft:blackstone
setblock 285 273 247 minecraft:tuff
fill 285 273 248 285 273 250 minecraft:blackstone
fill 285 273 258 296 273 258 minecraft:blackstone
setblock 285 273 260 minecraft:tuff
setblock 286 273 228 minecraft:shroomlight
setblock 286 273 236 minecraft:tuff
fill 286 273 247 287 273 248 minecraft:blackstone
setblock 286 273 249 minecraft:tuff
fill 286 273 250 290 273 250 minecraft:blackstone
fill 286 273 259 290 273 260 minecraft:blackstone
setblock 286 273 262 minecraft:tuff
fill 287 273 236 298 273 236 minecraft:basalt
fill 287 273 237 292 273 237 minecraft:blackstone
setblock 287 273 238 minecraft:tuff
setblock 287 273 251 minecraft:tuff
fill 287 273 253 287 274 253 minecraft:blackstone
fill 287 273 262 292 273 263 minecraft:blackstone
setblock 287 273 264 minecraft:tuff
fill 287 273 265 293 274 265 minecraft:blackstone
fill 287 273 268 288 274 268 minecraft:blackstone
fill 288 273 238 297 273 238 minecraft:blackstone
setblock 288 273 240 minecraft:tuff
fill 288 273 247 290 273 247 minecraft:blackstone
fill 288 273 251 290 273 251 minecraft:basalt
setblock 288 273 253 minecraft:tuff
setblock 288 273 266 minecraft:tuff
setblock 289 273 229 minecraft:tuff
fill 289 273 230 295 274 230 minecraft:blackstone
fill 289 273 239 293 273 240 minecraft:blackstone
setblock 289 273 242 minecraft:tuff
fill 289 273 252 291 273 253 minecraft:blackstone
setblock 289 273 255 minecraft:tuff
fill 289 273 266 300 273 266 minecraft:basalt
setblock 289 273 268 minecraft:tuff
fill 290 273 229 301 273 229 minecraft:blackstone
setblock 290 273 231 minecraft:tuff
fill 290 273 242 292 273 242 minecraft:blackstone
setblock 290 273 244 minecraft:tuff
fill 290 273 245 290 274 245 minecraft:blackstone
fill 290 273 254 292 273 255 minecraft:blackstone
setblock 290 273 257 minecraft:tuff
fill 290 273 267 294 273 268 minecraft:blackstone
fill 291 273 231 302 273 231 minecraft:basalt
fill 291 273 232 296 273 232 minecraft:blackstone
setblock 291 273 233 minecraft:tuff
fill 291 273 245 291 274 245 minecraft:netherrack
setblock 291 273 246 minecraft:shroomlight
fill 291 273 247 291 273 249 minecraft:netherrack
setblock 291 273 250 minecraft:shroomlight
fill 291 273 251 291 274 251 minecraft:netherrack
fill 291 273 257 295 273 257 minecraft:blackstone
setblock 291 273 259 minecraft:tuff
fill 291 273 260 297 274 260 minecraft:blackstone
fill 291 273 269 295 274 269 minecraft:blackstone
fill 292 273 228 292 283 228 minecraft:blackstone
fill 292 273 233 303 273 233 minecraft:blackstone
setblock 292 273 235 minecraft:tuff
fill 292 273 243 292 273 244 minecraft:netherrack
setblock 292 273 245 minecraft:light[level=12]
fill 292 273 252 292 273 253 minecraft:netherrack
setblock 292 273 261 minecraft:tuff
fill 293 273 234 297 273 235 minecraft:blackstone
setblock 293 273 237 minecraft:tuff
setblock 293 273 242 minecraft:shroomlight
setblock 293 273 254 minecraft:shroomlight
setblock 293 273 255 minecraft:blackstone
fill 293 273 261 304 273 261 minecraft:basalt
fill 293 273 262 298 273 262 minecraft:blackstone
setblock 293 273 263 minecraft:tuff
fill 294 273 237 305 273 237 minecraft:blackstone
setblock 294 273 239 minecraft:tuff
setblock 294 273 240 minecraft:blackstone
setblock 294 273 241 minecraft:netherrack
setblock 294 273 255 minecraft:netherrack
fill 294 273 263 305 273 263 minecraft:blackstone
setblock 294 273 265 minecraft:tuff
setblock 295 273 239 minecraft:blackstone
setblock 295 273 240 minecraft:netherrack
setblock 295 273 256 minecraft:netherrack
fill 295 273 264 299 273 265 minecraft:blackstone
setblock 295 273 267 minecraft:tuff
fill 295 273 268 301 274 268 minecraft:blackstone
setblock 296 273 230 minecraft:tuff
setblock 296 273 239 minecraft:netherrack
setblock 296 273 257 minecraft:netherrack
setblock 296 273 269 minecraft:tuff
fill 297 273 230 308 273 230 minecraft:blackstone
setblock 297 273 232 minecraft:tuff
setblock 297 273 258 minecraft:tuff
fill 298 273 232 309 273 232 minecraft:blackstone
setblock 298 273 234 minecraft:tuff
fill 298 273 235 304 274 235 minecraft:blackstone
fill 298 273 238 300 273 238 minecraft:netherrack
fill 298 273 258 300 273 258 minecraft:netherrack
setblock 298 273 260 minecraft:tuff
fill 299 273 228 299 283 228 minecraft:blackstone
setblock 299 273 236 minecraft:tuff
setblock 299 273 245 minecraft:light[level=12]
setblock 299 273 252 minecraft:light[level=12]
fill 299 273 259 303 273 260 minecraft:blackstone
setblock 299 273 262 minecraft:tuff
fill 300 273 236 311 273 236 minecraft:basalt
fill 300 273 262 311 273 262 minecraft:blackstone
setblock 300 273 264 minecraft:tuff
fill 300 273 265 306 274 265 minecraft:blackstone
setblock 301 273 266 minecraft:tuff
setblock 302 273 229 minecraft:tuff
fill 302 273 238 304 273 238 minecraft:netherrack
fill 302 273 258 304 273 258 minecraft:netherrack
fill 302 273 266 313 273 266 minecraft:basalt
setblock 302 273 268 minecraft:tuff
fill 303 273 229 314 273 229 minecraft:blackstone
setblock 303 273 231 minecraft:tuff
fill 303 273 267 307 273 268 minecraft:blackstone
fill 304 273 231 315 273 231 minecraft:basalt
setblock 304 273 233 minecraft:tuff
setblock 304 273 259 minecraft:tuff
fill 304 273 260 310 274 260 minecraft:blackstone
fill 304 273 269 308 274 269 minecraft:blackstone
fill 305 273 233 316 273 233 minecraft:blackstone
setblock 305 273 235 minecraft:tuff
fill 305 273 238 312 273 238 minecraft:blackstone
fill 305 273 258 309 273 259 minecraft:blackstone
setblock 305 273 261 minecraft:tuff
fill 306 273 234 310 273 235 minecraft:blackstone
setblock 306 273 237 minecraft:tuff
setblock 306 273 239 minecraft:netherrack
setblock 306 273 245 minecraft:light[level=12]
setblock 306 273 252 minecraft:light[level=12]
setblock 306 273 257 minecraft:netherrack
fill 306 273 261 317 273 261 minecraft:basalt
setblock 306 273 263 minecraft:tuff
fill 307 273 237 314 273 237 minecraft:blackstone
setblock 307 273 239 minecraft:tuff
setblock 307 273 240 minecraft:netherrack
setblock 307 273 256 minecraft:netherrack
fill 307 273 257 315 273 257 minecraft:blackstone
fill 307 273 263 318 273 263 minecraft:blackstone
setblock 307 273 265 minecraft:tuff
fill 308 273 239 313 273 240 minecraft:blackstone
setblock 308 273 241 minecraft:netherrack
setblock 308 273 255 minecraft:netherrack
setblock 308 273 256 minecraft:basalt
fill 308 273 264 312 273 265 minecraft:blackstone
setblock 308 273 267 minecraft:tuff
fill 308 273 268 314 274 268 minecraft:blackstone
setblock 309 273 230 minecraft:tuff
fill 309 273 241 320 273 241 minecraft:basalt
setblock 309 273 242 minecraft:shroomlight
setblock 309 273 254 minecraft:shroomlight
fill 309 273 255 314 273 255 minecraft:blackstone
setblock 309 273 256 minecraft:tuff
setblock 309 273 269 minecraft:tuff
fill 310 273 230 321 273 230 minecraft:blackstone
setblock 310 273 232 minecraft:tuff
fill 310 273 242 314 273 242 minecraft:blackstone
fill 310 273 243 310 273 244 minecraft:netherrack
fill 310 273 252 310 273 253 minecraft:netherrack
fill 310 273 254 320 273 254 minecraft:blackstone
fill 310 273 256 321 273 256 minecraft:basalt
setblock 310 273 258 minecraft:tuff
fill 310 273 259 316 274 259 minecraft:blackstone
fill 311 273 232 318 273 232 minecraft:blackstone
setblock 311 273 234 minecraft:tuff
fill 311 273 235 317 274 235 minecraft:blackstone
fill 311 273 243 315 273 244 minecraft:blackstone
fill 311 273 245 311 274 245 minecraft:netherrack
setblock 311 273 246 minecraft:shroomlight
fill 311 273 247 311 273 249 minecraft:netherrack
setblock 311 273 250 minecraft:shroomlight
fill 311 273 251 311 274 251 minecraft:netherrack
fill 311 273 252 313 273 253 minecraft:blackstone
setblock 311 273 260 minecraft:tuff
setblock 312 273 236 minecraft:tuff
fill 312 273 245 322 273 245 minecraft:blackstone
fill 312 273 246 316 273 246 minecraft:basalt
fill 312 273 247 317 273 248 minecraft:blackstone
setblock 312 273 249 minecraft:tuff
fill 312 273 250 318 273 250 minecraft:blackstone
setblock 312 273 251 minecraft:basalt
fill 312 273 260 323 273 260 minecraft:blackstone
setblock 312 273 262 minecraft:tuff
fill 313 273 236 323 273 236 minecraft:basalt
setblock 313 273 238 minecraft:tuff
setblock 313 273 251 minecraft:tuff
fill 313 273 262 320 273 262 minecraft:blackstone
setblock 313 273 264 minecraft:tuff
fill 313 273 265 319 274 265 minecraft:blackstone
fill 314 273 238 315 274 239 minecraft:blackstone
setblock 314 273 240 minecraft:tuff
fill 314 273 251 323 273 251 minecraft:basalt
fill 314 273 252 315 273 252 minecraft:blackstone
setblock 314 273 253 minecraft:tuff
setblock 314 273 266 minecraft:tuff
setblock 315 273 229 minecraft:tuff
fill 315 273 240 323 273 240 minecraft:blackstone
setblock 315 273 242 minecraft:tuff
fill 315 273 253 322 273 253 minecraft:blackstone
setblock 315 273 255 minecraft:tuff
fill 315 273 266 323 273 266 minecraft:basalt
setblock 315 273 268 minecraft:tuff
fill 316 273 229 323 273 229 minecraft:blackstone
setblock 316 273 231 minecraft:tuff
fill 316 273 242 320 273 243 minecraft:blackstone
setblock 316 273 244 minecraft:tuff
fill 316 273 255 323 273 255 minecraft:blackstone
setblock 316 273 257 minecraft:tuff
fill 316 273 267 317 273 268 minecraft:blackstone
fill 317 273 231 323 273 231 minecraft:basalt
setblock 317 273 233 minecraft:tuff
fill 317 273 239 319 274 239 minecraft:blackstone
fill 317 273 244 323 273 244 minecraft:blackstone
setblock 317 273 246 minecraft:tuff
fill 317 273 257 319 273 257 minecraft:blackstone
setblock 317 273 259 minecraft:tuff
fill 317 273 269 317 275 269 minecraft:blackstone
fill 318 273 233 319 274 233 minecraft:blackstone
setblock 318 273 235 minecraft:tuff
setblock 318 273 237 minecraft:blackstone
fill 318 273 246 323 273 246 minecraft:basalt
fill 318 273 247 319 273 247 minecraft:blackstone
setblock 318 273 248 minecraft:tuff
fill 318 273 258 322 273 259 minecraft:blackstone
setblock 318 273 261 minecraft:tuff
setblock 318 273 267 minecraft:blackstone
fill 319 273 234 319 275 235 minecraft:blackstone
setblock 319 273 237 minecraft:tuff
fill 319 273 248 320 274 248 minecraft:blackstone
setblock 319 273 250 minecraft:tuff
fill 319 273 261 323 273 261 minecraft:basalt
setblock 319 273 263 minecraft:tuff
fill 319 273 269 319 274 270 minecraft:blackstone
fill 320 273 235 323 273 235 minecraft:blackstone
fill 320 273 237 321 273 237 minecraft:blackstone
setblock 320 273 239 minecraft:tuff
fill 320 273 249 320 275 250 minecraft:blackstone
setblock 320 273 252 minecraft:tuff
fill 320 273 263 321 274 263 minecraft:blackstone
setblock 320 273 265 minecraft:tuff
setblock 320 273 267 minecraft:blackstone
fill 320 273 269 321 275 269 minecraft:blackstone
fill 321 273 238 321 274 239 minecraft:blackstone
setblock 321 273 241 minecraft:tuff
fill 321 273 243 321 274 243 minecraft:blackstone
fill 321 273 250 323 275 250 minecraft:blackstone
fill 321 273 252 322 273 252 minecraft:blackstone
setblock 321 273 254 minecraft:tuff
fill 321 273 264 321 275 265 minecraft:blackstone
setblock 321 273 267 minecraft:tuff
setblock 322 273 230 minecraft:tuff
setblock 322 273 232 minecraft:blackstone
fill 322 273 239 323 275 239 minecraft:blackstone
fill 322 273 241 323 273 241 minecraft:basalt
setblock 322 273 243 minecraft:tuff
fill 322 273 254 323 275 254 minecraft:blackstone
setblock 322 273 256 minecraft:tuff
fill 322 273 265 323 275 265 minecraft:blackstone
fill 322 273 267 323 273 267 minecraft:blackstone
setblock 322 273 269 minecraft:tuff
fill 323 273 230 323 276 230 minecraft:blackstone
setblock 323 273 232 minecraft:tuff
setblock 323 273 237 minecraft:blackstone
fill 323 273 242 323 273 243 minecraft:blackstone
setblock 323 273 245 minecraft:tuff
setblock 323 273 256 minecraft:basalt
setblock 323 273 258 minecraft:tuff
fill 323 273 259 323 275 259 minecraft:blackstone
fill 323 273 268 323 274 269 minecraft:blackstone
fill 324 273 245 324 283 245 minecraft:blackstone
setblock 282 274 231 minecraft:crying_obsidian
fill 283 274 230 287 274 231 minecraft:blackstone
fill 283 274 232 288 274 232 minecraft:basalt
setblock 283 274 233 minecraft:tuff
fill 283 274 234 283 274 236 minecraft:blackstone
fill 283 274 237 284 274 237 minecraft:basalt
fill 283 274 238 285 274 239 minecraft:blackstone
fill 283 274 241 286 275 241 minecraft:blackstone
fill 283 274 242 291 274 242 minecraft:basalt
fill 283 274 243 287 274 243 minecraft:blackstone
setblock 283 274 246 minecraft:tuff
fill 283 274 247 289 274 247 minecraft:basalt
fill 283 274 248 283 274 251 minecraft:blackstone
fill 283 274 252 285 274 252 minecraft:basalt
fill 283 274 253 286 274 254 minecraft:blackstone
fill 283 274 256 287 275 256 minecraft:blackstone
fill 283 274 257 294 274 257 minecraft:basalt
fill 283 274 258 288 274 258 minecraft:blackstone
setblock 283 274 259 minecraft:tuff
fill 283 274 261 283 277 261 minecraft:blackstone
fill 283 274 262 290 274 262 minecraft:basalt
fill 283 274 263 284 274 266 minecraft:blackstone
fill 283 274 267 286 274 267 minecraft:basalt
fill 283 274 268 286 274 269 minecraft:blackstone
fill 284 274 229 293 274 229 minecraft:blackstone
fill 284 274 233 289 274 234 minecraft:blackstone
setblock 284 274 235 minecraft:tuff
fill 284 274 236 290 275 236 minecraft:blackstone
fill 284 274 245 288 274 246 minecraft:blackstone
setblock 284 274 248 minecraft:tuff
fill 284 274 249 284 274 251 minecraft:blackstone
fill 284 274 259 295 274 259 minecraft:blackstone
setblock 284 274 261 minecraft:tuff
setblock 285 274 237 minecraft:tuff
fill 285 274 244 290 274 244 minecraft:blackstone
fill 285 274 248 289 274 249 minecraft:blackstone
setblock 285 274 250 minecraft:tuff
fill 285 274 251 290 274 251 minecraft:blackstone
fill 285 274 260 289 274 261 minecraft:blackstone
setblock 285 274 263 minecraft:tuff
fill 285 274 264 285 274 266 minecraft:blackstone
fill 286 274 228 286 283 228 minecraft:blackstone
fill 286 274 237 297 274 237 minecraft:basalt
fill 286 274 238 291 274 238 minecraft:blackstone
setblock 286 274 239 minecraft:tuff
fill 286 274 250 289 275 250 minecraft:blackstone
setblock 286 274 252 minecraft:tuff
fill 286 274 263 291 274 264 minecraft:blackstone
setblock 286 274 265 minecraft:tuff
fill 286 274 266 292 275 266 minecraft:blackstone
fill 287 274 239 294 274 239 minecraft:blackstone
setblock 287 274 241 minecraft:tuff
fill 287 274 252 290 274 252 minecraft:basalt
setblock 287 274 254 minecraft:tuff
setblock 287 274 267 minecraft:tuff
fill 287 274 269 287 275 269 minecraft:blackstone
setblock 288 274 230 minecraft:tuff
fill 288 274 231 294 275 231 minecraft:blackstone
fill 288 274 240 292 274 241 minecraft:blackstone
setblock 288 274 243 minecraft:tuff
fill 288 274 253 290 274 254 minecraft:blackstone
setblock 288 274 256 minecraft:tuff
fill 288 274 267 299 274 267 minecraft:basalt
setblock 288 274 269 minecraft:tuff
setblock 289 274 232 minecraft:tuff
fill 289 274 243 290 274 243 minecraft:blackstone
setblock 289 274 245 minecraft:tuff
fill 289 274 246 289 275 246 minecraft:blackstone
fill 289 274 255 292 274 256 minecraft:blackstone
setblock 289 274 258 minecraft:tuff
fill 289 274 268 290 274 269 minecraft:blackstone
fill 290 274 232 301 274 232 minecraft:basalt
fill 290 274 233 295 274 233 minecraft:blackstone
setblock 290 274 234 minecraft:tuff
fill 290 274 246 290 275 250 minecraft:netherrack
fill 290 274 258 295 274 258 minecraft:blackstone
setblock 290 274 260 minecraft:tuff
fill 290 274 261 296 275 261 minecraft:blackstone
fill 291 274 234 302 274 234 minecraft:blackstone
setblock 291 274 236 minecraft:tuff
fill 291 274 243 291 274 244 minecraft:netherrack
fill 291 274 247 291 274 249 minecraft:blackstone
fill 291 274 252 291 274 253 minecraft:netherrack
setblock 291 274 254 minecraft:blackstone
setblock 291 274 262 minecraft:tuff
fill 291 274 268 293 274 268 minecraft:blackstone
fill 292 274 235 296 274 236 minecraft:blackstone
setblock 292 274 238 minecraft:tuff
setblock 292 274 242 minecraft:netherrack
setblock 292 274 254 minecraft:netherrack
fill 292 274 262 303 274 262 minecraft:basalt
fill 292 274 263 297 274 263 minecraft:blackstone
setblock 292 274 264 minecraft:tuff
fill 293 274 238 295 274 238 minecraft:blackstone
setblock 293 274 240 minecraft:tuff
setblock 293 274 241 minecraft:netherrack
setblock 293 274 247 minecraft:light[level=12]
setblock 293 274 255 minecraft:netherrack
setblock 293 274 256 minecraft:blackstone
fill 293 274 264 304 274 264 minecraft:blackstone
setblock 293 274 266 minecraft:tuff
setblock 294 274 229 minecraft:tuff
setblock 294 274 240 minecraft:netherrack
setblock 294 274 256 minecraft:netherrack
fill 294 274 265 298 274 266 minecraft:blackstone
setblock 294 274 268 minecraft:tuff
fill 295 274 229 306 274 229 minecraft:blackstone
setblock 295 274 231 minecraft:tuff
setblock 295 274 239 minecraft:netherrack
setblock 295 274 257 minecraft:netherrack
fill 296 274 230 300 274 231 minecraft:blackstone
setblock 296 274 233 minecraft:tuff
fill 296 274 238 296 275 238 minecraft:shroomlight
fill 296 274 258 296 275 258 minecraft:shroomlight
setblock 296 274 259 minecraft:tuff
fill 296 274 269 300 275 269 minecraft:blackstone
fill 297 274 233 308 274 233 minecraft:blackstone
setblock 297 274 235 minecraft:tuff
fill 297 274 236 303 275 236 minecraft:blackstone
fill 297 274 238 298 274 238 minecraft:netherrack
fill 297 274 258 298 274 258 minecraft:netherrack
fill 297 274 259 298 274 259 minecraft:blackstone
setblock 297 274 261 minecraft:tuff
setblock 298 274 237 minecraft:tuff
fill 298 274 260 302 274 261 minecraft:blackstone
setblock 298 274 263 minecraft:tuff
fill 299 274 237 300 275 237 minecraft:netherrack
fill 299 274 259 300 275 259 minecraft:netherrack
fill 299 274 263 310 274 263 minecraft:blackstone
setblock 299 274 265 minecraft:tuff
fill 299 274 266 305 275 266 minecraft:blackstone
setblock 300 274 267 minecraft:tuff
setblock 301 274 230 minecraft:tuff
fill 301 274 231 307 275 231 minecraft:blackstone
fill 301 274 237 301 275 237 minecraft:shroomlight
setblock 301 274 239 minecraft:light[level=12]
setblock 301 274 255 minecraft:light[level=12]
fill 301 274 259 301 275 259 minecraft:shroomlight
fill 301 274 267 312 274 267 minecraft:basalt
setblock 301 274 269 minecraft:tuff
fill 302 274 230 313 274 230 minecraft:blackstone
setblock 302 274 232 minecraft:tuff
fill 302 274 237 303 275 237 minecraft:netherrack
fill 302 274 259 303 275 259 minecraft:netherrack
fill 302 274 268 303 274 269 minecraft:blackstone
fill 303 274 232 314 274 232 minecraft:basalt
setblock 303 274 234 minecraft:tuff
setblock 303 274 260 minecraft:tuff
fill 303 274 261 309 275 261 minecraft:blackstone
fill 304 274 234 315 274 234 minecraft:blackstone
setblock 304 274 236 minecraft:tuff
fill 304 274 237 310 274 237 minecraft:basalt
fill 304 274 238 305 274 238 minecraft:netherrack
fill 304 274 258 305 274 258 minecraft:netherrack
fill 304 274 259 308 274 259 minecraft:blackstone
setblock 304 274 262 minecraft:tuff
fill 304 274 268 306 274 268 minecraft:blackstone
fill 305 274 235 309 274 236 minecraft:blackstone
fill 305 274 262 316 274 262 minecraft:basalt
setblock 305 274 264 minecraft:tuff
setblock 305 274 270 minecraft:magma_block
fill 306 274 238 306 275 238 minecraft:shroomlight
fill 306 274 258 306 275 258 minecraft:shroomlight
fill 306 274 264 317 274 264 minecraft:blackstone
setblock 306 274 266 minecraft:tuff
setblock 307 274 229 minecraft:tuff
fill 307 274 238 313 274 238 minecraft:blackstone
setblock 307 274 239 minecraft:netherrack
setblock 307 274 257 minecraft:netherrack
fill 307 274 258 314 274 258 minecraft:blackstone
fill 307 274 265 311 274 266 minecraft:blackstone
setblock 307 274 268 minecraft:tuff
fill 308 274 229 319 274 229 minecraft:blackstone
setblock 308 274 231 minecraft:tuff
fill 308 274 239 311 274 239 minecraft:blackstone
setblock 308 274 240 minecraft:netherrack
setblock 308 274 256 minecraft:netherrack
setblock 308 274 257 minecraft:tuff
fill 309 274 231 320 274 231 minecraft:blackstone
setblock 309 274 233 minecraft:tuff
fill 309 274 240 318 274 240 minecraft:blackstone
setblock 309 274 241 minecraft:netherrack
setblock 309 274 247 minecraft:light[level=12]
setblock 309 274 255 minecraft:netherrack
fill 309 274 256 313 274 256 minecraft:blackstone
fill 309 274 257 320 274 257 minecraft:basalt
setblock 309 274 259 minecraft:tuff
fill 309 274 269 313 275 269 minecraft:blackstone
fill 310 274 233 317 274 233 minecraft:blackstone
setblock 310 274 235 minecraft:tuff
fill 310 274 236 316 275 236 minecraft:blackstone
fill 310 274 241 312 274 241 minecraft:blackstone
setblock 310 274 242 minecraft:netherrack
setblock 310 274 254 minecraft:netherrack
fill 310 274 255 319 274 255 minecraft:blackstone
setblock 310 274 261 minecraft:tuff
setblock 311 274 237 minecraft:tuff
fill 311 274 242 319 274 242 minecraft:basalt
fill 311 274 243 311 274 244 minecraft:netherrack
fill 311 274 252 311 274 253 minecraft:netherrack
fill 311 274 254 312 274 254 minecraft:blackstone
fill 311 274 260 315 274 261 minecraft:blackstone
setblock 311 274 263 minecraft:tuff
fill 312 274 237 323 274 237 minecraft:basalt
setblock 312 274 239 minecraft:tuff
fill 312 274 243 313 274 245 minecraft:blackstone
fill 312 274 246 312 275 250 minecraft:netherrack
fill 312 274 251 317 274 251 minecraft:blackstone
setblock 312 274 252 minecraft:tuff
fill 312 274 253 318 274 253 minecraft:blackstone
fill 312 274 263 319 274 263 minecraft:blackstone
setblock 312 274 265 minecraft:tuff
fill 312 274 266 318 275 266 minecraft:blackstone
fill 313 274 239 313 275 239 minecraft:blackstone
setblock 313 274 241 minecraft:tuff
fill 313 274 246 321 274 246 minecraft:blackstone
fill 313 274 247 315 274 247 minecraft:basalt
fill 313 274 248 316 274 250 minecraft:blackstone
fill 313 274 252 323 274 252 minecraft:basalt
setblock 313 274 254 minecraft:tuff
setblock 313 274 267 minecraft:tuff
setblock 314 274 230 minecraft:tuff
fill 314 274 241 323 274 241 minecraft:blackstone
setblock 314 274 243 minecraft:tuff
fill 314 274 244 314 275 245 minecraft:blackstone
fill 314 274 254 321 274 254 minecraft:blackstone
setblock 314 274 256 minecraft:tuff
fill 314 274 267 323 274 267 minecraft:basalt
setblock 314 274 269 minecraft:tuff
fill 315 274 230 322 274 230 minecraft:blackstone
setblock 315 274 232 minecraft:tuff
fill 315 274 243 320 274 244 minecraft:blackstone
setblock 315 274 245 minecraft:tuff
fill 315 274 256 323 274 256 minecraft:blackstone
setblock 315 274 258 minecraft:tuff
fill 315 274 268 316 274 269 minecraft:blackstone
fill 316 274 232 323 274 232 minecraft:basalt
setblock 316 274 234 minecraft:tuff
fill 316 274 245 323 274 245 minecraft:blackstone
setblock 316 274 247 minecraft:tuff
fill 316 274 258 323 274 258 minecraft:blackstone
setblock 316 274 260 minecraft:tuff
fill 316 274 261 322 275 261 minecraft:blackstone
fill 317 274 234 318 275 234 minecraft:blackstone
setblock 317 274 236 minecraft:tuff
setblock 317 274 238 minecraft:blackstone
fill 317 274 247 323 274 247 minecraft:basalt
fill 317 274 248 318 274 248 minecraft:blackstone
setblock 317 274 249 minecraft:tuff
fill 317 274 250 319 276 250 minecraft:blackstone
fill 317 274 259 321 274 260 minecraft:blackstone
setblock 317 274 262 minecraft:tuff
setblock 317 274 268 minecraft:blackstone
fill 318 274 235 318 276 236 minecraft:blackstone
setblock 318 274 238 minecraft:tuff
fill 318 274 249 319 275 249 minecraft:blackstone
setblock 318 274 251 minecraft:tuff
fill 318 274 262 323 274 262 minecraft:basalt
setblock 318 274 264 minecraft:tuff
fill 319 274 236 323 274 236 minecraft:blackstone
fill 319 274 238 320 274 238 minecraft:blackstone
setblock 319 274 240 minecraft:tuff
fill 319 274 251 323 274 251 minecraft:blackstone
setblock 319 274 253 minecraft:tuff
fill 319 274 264 320 275 264 minecraft:blackstone
setblock 319 274 266 minecraft:tuff
setblock 319 274 268 minecraft:blackstone
setblock 320 274 229 minecraft:tuff
fill 320 274 235 322 275 235 minecraft:blackstone
fill 320 274 239 320 275 240 minecraft:blackstone
setblock 320 274 242 minecraft:tuff
fill 320 274 253 323 274 253 minecraft:blackstone
setblock 320 274 255 minecraft:tuff
fill 320 274 265 320 276 266 minecraft:blackstone
setblock 320 274 268 minecraft:tuff
fill 321 274 229 323 275 229 minecraft:blackstone
setblock 321 274 231 minecraft:tuff
setblock 321 274 233 minecraft:blackstone
fill 321 274 240 323 276 240 minecraft:blackstone
fill 321 274 242 323 274 242 minecraft:basalt
setblock 321 274 244 minecraft:tuff
fill 321 274 255 323 276 255 minecraft:blackstone
setblock 321 274 257 minecraft:tuff
fill 321 274 266 323 276 266 minecraft:blackstone
fill 321 274 268 322 274 268 minecraft:blackstone
fill 322 274 231 323 276 231 minecraft:blackstone
setblock 322 274 233 minecraft:tuff
setblock 322 274 238 minecraft:blackstone
fill 322 274 243 323 274 244 minecraft:blackstone
setblock 322 274 246 minecraft:tuff
setblock 322 274 248 minecraft:blackstone
fill 322 274 257 323 274 257 minecraft:basalt
setblock 322 274 259 minecraft:tuff
fill 322 274 260 323 276 260 minecraft:blackstone
fill 322 274 269 322 275 269 minecraft:blackstone
setblock 323 274 233 minecraft:blackstone
setblock 323 274 235 minecraft:tuff
fill 323 274 246 323 277 246 minecraft:blackstone
setblock 323 274 248 minecraft:tuff
setblock 323 274 261 minecraft:tuff
setblock 323 274 263 minecraft:blackstone
fill 282 275 231 286 276 231 minecraft:blackstone
fill 283 275 230 292 275 230 minecraft:blackstone
fill 283 275 232 293 275 232 minecraft:blackstone
fill 283 275 233 287 275 233 minecraft:basalt
fill 283 275 234 288 275 235 minecraft:blackstone
setblock 283 275 236 minecraft:tuff
fill 283 275 237 289 276 237 minecraft:blackstone
setblock 283 275 238 minecraft:basalt
fill 283 275 239 284 275 240 minecraft:blackstone
fill 283 275 242 285 276 242 minecraft:blackstone
fill 283 275 243 290 275 243 minecraft:basalt
fill 283 275 246 287 275 247 minecraft:blackstone
fill 283 275 248 288 275 248 minecraft:basalt
setblock 283 275 249 minecraft:tuff
fill 283 275 250 283 275 252 minecraft:blackstone
fill 283 275 253 284 275 253 minecraft:basalt
fill 283 275 254 285 275 255 minecraft:blackstone
fill 283 275 257 286 276 257 minecraft:blackstone
fill 283 275 258 293 275 258 minecraft:basalt
fill 283 275 259 287 275 259 minecraft:blackstone
setblock 283 275 262 minecraft:tuff
fill 283 275 263 289 275 263 minecraft:basalt
fill 283 275 264 283 275 267 minecraft:blackstone
fill 283 275 268 285 275 268 minecraft:basalt
fill 283 275 269 286 275 269 minecraft:blackstone
fill 284 275 229 285 275 229 minecraft:blackstone
setblock 284 275 238 minecraft:tuff
fill 284 275 245 289 275 245 minecraft:blackstone
fill 284 275 249 285 275 250 minecraft:blackstone
setblock 284 275 251 minecraft:tuff
fill 284 275 252 289 276 252 minecraft:blackstone
fill 284 275 261 288 275 262 minecraft:blackstone
setblock 284 275 264 minecraft:tuff
fill 284 275 265 284 275 267 minecraft:blackstone
fill 285 275 238 294 275 238 minecraft:basalt
fill 285 275 239 290 275 239 minecraft:blackstone
setblock 285 275 240 minecraft:tuff
fill 285 275 244 286 275 244 minecraft:blackstone
fill 285 275 251 289 275 251 minecraft:blackstone
setblock 285 275 253 minecraft:tuff
fill 285 275 260 294 275 260 minecraft:blackstone
fill 285 275 264 290 275 265 minecraft:blackstone
setblock 285 275 266 minecraft:tuff
fill 285 275 267 291 276 267 minecraft:blackstone
setblock 286 275 229 minecraft:tuff
fill 286 275 240 292 275 240 minecraft:blackstone
setblock 286 275 242 minecraft:tuff
fill 286 275 249 289 275 249 minecraft:blackstone
fill 286 275 253 290 275 253 minecraft:basalt
fill 286 275 254 290 275 254 minecraft:blackstone
setblock 286 275 255 minecraft:tuff
setblock 286 275 268 minecraft:tuff
fill 287 275 229 298 275 229 minecraft:blackstone
setblock 287 275 231 minecraft:tuff
fill 287 275 241 290 276 242 minecraft:blackstone
setblock 287 275 244 minecraft:tuff
fill 287 275 255 291 275 255 minecraft:blackstone
setblock 287 275 257 minecraft:tuff
fill 287 275 268 298 275 268 minecraft:basalt
setblock 288 275 233 minecraft:tuff
fill 288 275 244 289 275 244 minecraft:blackstone
setblock 288 275 246 minecraft:tuff
fill 288 275 247 289 275 247 minecraft:blackstone
fill 288 275 256 292 275 257 minecraft:blackstone
setblock 288 275 259 minecraft:tuff
fill 288 275 269 292 275 269 minecraft:blackstone
fill 289 275 233 300 275 233 minecraft:basalt
fill 289 275 234 294 275 234 minecraft:blackstone
setblock 289 275 235 minecraft:tuff
setblock 289 275 248 minecraft:tuff
fill 289 275 259 296 275 259 minecraft:blackstone
setblock 289 275 261 minecraft:tuff
fill 289 275 262 295 276 262 minecraft:blackstone
fill 290 275 235 301 275 235 minecraft:blackstone
setblock 290 275 237 minecraft:tuff
fill 290 275 244 290 275 245 minecraft:netherrack
fill 290 275 251 290 275 252 minecraft:netherrack
setblock 290 275 263 minecraft:tuff
fill 291 275 236 295 275 237 minecraft:blackstone
setblock 291 275 239 minecraft:tuff
setblock 291 275 241 minecraft:blackstone
fill 291 275 242 291 275 243 minecraft:netherrack
fill 291 275 253 291 275 254 minecraft:netherrack
fill 291 275 263 302 275 263 minecraft:basalt
fill 291 275 264 296 275 264 minecraft:blackstone
setblock 291 275 265 minecraft:tuff
fill 292 275 239 293 275 239 minecraft:blackstone
setblock 292 275 241 minecraft:shroomlight
setblock 292 275 255 minecraft:shroomlight
fill 292 275 265 303 275 265 minecraft:blackstone
setblock 292 275 267 minecraft:tuff
setblock 293 275 230 minecraft:tuff
setblock 293 275 240 minecraft:netherrack
setblock 293 275 256 minecraft:netherrack
setblock 293 275 257 minecraft:blackstone
fill 293 275 266 297 275 267 minecraft:blackstone
setblock 293 275 269 minecraft:tuff
fill 294 275 230 305 275 230 minecraft:blackstone
setblock 294 275 232 minecraft:tuff
setblock 294 275 239 minecraft:netherrack
setblock 294 275 257 minecraft:netherrack
setblock 294 275 258 minecraft:tuff
fill 294 275 269 295 275 269 minecraft:blackstone
fill 295 275 231 299 275 232 minecraft:blackstone
setblock 295 275 234 minecraft:tuff
setblock 295 275 238 minecraft:netherrack
setblock 295 275 258 minecraft:netherrack
setblock 295 275 260 minecraft:tuff
fill 296 275 234 307 275 234 minecraft:blackstone
setblock 296 275 236 minecraft:tuff
setblock 296 275 237 minecraft:blackstone
fill 296 275 260 307 275 260 minecraft:blackstone
setblock 296 275 262 minecraft:tuff
fill 297 275 237 298 275 237 minecraft:netherrack
fill 297 275 259 298 275 259 minecraft:netherrack
fill 297 275 261 301 275 262 minecraft:blackstone
setblock 297 275 264 minecraft:tuff
fill 298 275 264 309 275 264 minecraft:blackstone
setblock 298 275 266 minecraft:tuff
fill 298 275 267 304 276 267 minecraft:blackstone
setblock 299 275 229 minecraft:tuff
setblock 299 275 268 minecraft:tuff
fill 300 275 229 311 275 229 minecraft:blackstone
setblock 300 275 231 minecraft:tuff
fill 300 275 232 306 276 232 minecraft:blackstone
fill 300 275 268 311 275 268 minecraft:basalt
setblock 301 275 233 minecraft:tuff
fill 301 275 269 305 275 269 minecraft:blackstone
fill 302 275 233 313 275 233 minecraft:basalt
setblock 302 275 235 minecraft:tuff
setblock 302 275 261 minecraft:tuff
fill 302 275 262 308 276 262 minecraft:blackstone
fill 303 275 235 314 275 235 minecraft:blackstone
setblock 303 275 263 minecraft:tuff
fill 304 275 236 308 275 236 minecraft:blackstone
fill 304 275 237 305 275 237 minecraft:netherrack
fill 304 275 259 305 275 259 minecraft:netherrack
fill 304 275 263 315 275 263 minecraft:basalt
setblock 304 275 265 minecraft:tuff
fill 305 275 265 316 275 265 minecraft:blackstone
setblock 305 275 267 minecraft:tuff
fill 305 275 270 305 276 270 minecraft:blackstone
setblock 306 275 230 minecraft:tuff
fill 306 275 237 315 275 237 minecraft:blackstone
fill 306 275 259 313 275 259 minecraft:blackstone
fill 306 275 266 310 275 267 minecraft:blackstone
setblock 306 275 269 minecraft:tuff
fill 307 275 230 318 275 230 minecraft:blackstone
setblock 307 275 232 minecraft:tuff
setblock 307 275 238 minecraft:netherrack
fill 307 275 239 307 276 240 minecraft:blackstone
setblock 307 275 258 minecraft:netherrack
fill 307 275 269 308 275 269 minecraft:blackstone
fill 308 275 231 312 275 232 minecraft:blackstone
setblock 308 275 234 minecraft:tuff
fill 308 275 238 309 275 238 minecraft:basalt
setblock 308 275 239 minecraft:netherrack
fill 308 275 240 308 300 240 minecraft:basalt
fill 308 275 241 308 276 242 minecraft:blackstone
setblock 308 275 257 minecraft:netherrack
fill 308 275 258 319 275 258 minecraft:basalt
setblock 308 275 260 minecraft:tuff
fill 309 275 234 316 275 234 minecraft:blackstone
setblock 309 275 236 minecraft:tuff
fill 309 275 239 312 275 239 minecraft:blackstone
setblock 309 275 240 minecraft:netherrack
fill 309 275 241 309 300 241 minecraft:basalt
fill 309 275 242 309 276 242 minecraft:blackstone
setblock 309 275 256 minecraft:netherrack
fill 309 275 257 312 275 257 minecraft:blackstone
fill 309 275 260 320 275 260 minecraft:blackstone
setblock 309 275 262 minecraft:tuff
setblock 310 275 238 minecraft:tuff
setblock 310 275 240 minecraft:blackstone
setblock 310 275 241 minecraft:shroomlight
fill 310 275 242 310 300 242 minecraft:basalt
setblock 310 275 255 minecraft:shroomlight
fill 310 275 256 318 275 256 minecraft:blackstone
fill 310 275 261 314 275 262 minecraft:blackstone
setblock 310 275 264 minecraft:tuff
fill 311 275 238 322 275 238 minecraft:basalt
setblock 311 275 240 minecraft:tuff
fill 311 275 241 317 275 241 minecraft:blackstone
fill 311 275 242 311 275 243 minecraft:netherrack
fill 311 275 253 311 275 254 minecraft:netherrack
setblock 311 275 255 minecraft:blackstone
fill 311 275 264 318 275 264 minecraft:blackstone
setblock 311 275 266 minecraft:tuff
fill 311 275 267 317 276 267 minecraft:blackstone
setblock 312 275 229 minecraft:tuff
fill 312 275 240 319 275 240 minecraft:blackstone
setblock 312 275 242 minecraft:tuff
fill 312 275 243 318 275 243 minecraft:basalt
fill 312 275 244 312 275 245 minecraft:netherrack
fill 312 275 251 312 275 252 minecraft:netherrack
fill 312 275 253 323 275 253 minecraft:basalt
fill 312 275 254 317 275 254 minecraft:blackstone
setblock 312 275 255 minecraft:tuff
setblock 312 275 268 minecraft:tuff
fill 313 275 229 320 275 229 minecraft:blackstone
setblock 313 275 231 minecraft:tuff
fill 313 275 232 319 276 232 minecraft:blackstone
fill 313 275 242 323 275 242 minecraft:blackstone
setblock 313 275 244 minecraft:tuff
fill 313 275 245 313 275 247 minecraft:blackstone
fill 313 275 248 314 275 248 minecraft:basalt
fill 313 275 249 315 275 252 minecraft:blackstone
fill 313 275 255 320 275 255 minecraft:blackstone
setblock 313 275 257 minecraft:tuff
fill 313 275 268 323 275 268 minecraft:basalt
fill 314 275 231 321 275 231 minecraft:blackstone
setblock 314 275 233 minecraft:tuff
fill 314 275 239 316 275 239 minecraft:blackstone
setblock 314 275 246 minecraft:tuff
fill 314 275 247 320 276 247 minecraft:blackstone
fill 314 275 257 323 275 257 minecraft:blackstone
setblock 314 275 259 minecraft:tuff
fill 314 275 269 316 275 269 minecraft:blackstone
fill 315 275 233 323 275 233 minecraft:basalt
setblock 315 275 235 minecraft:tuff
fill 315 275 244 319 275 246 minecraft:blackstone
setblock 315 275 248 minecraft:tuff
fill 315 275 259 322 275 259 minecraft:blackstone
setblock 315 275 261 minecraft:tuff
fill 315 275 262 321 276 262 minecraft:blackstone
fill 316 275 235 317 276 235 minecraft:blackstone
setblock 316 275 237 minecraft:tuff
fill 316 275 248 323 275 248 minecraft:basalt
fill 316 275 249 317 275 249 minecraft:blackstone
setblock 316 275 250 minecraft:tuff
fill 316 275 251 316 277 252 minecraft:blackstone
setblock 316 275 263 minecraft:tuff
fill 317 275 236 317 277 237 minecraft:blackstone
setblock 317 275 239 minecraft:tuff
fill 317 275 251 322 276 251 minecraft:blackstone
setblock 317 275 252 minecraft:tuff
fill 317 275 263 323 275 263 minecraft:basalt
setblock 317 275 265 minecraft:tuff
fill 318 275 237 323 275 237 minecraft:blackstone
fill 318 275 239 319 275 239 minecraft:blackstone
setblock 318 275 241 minecraft:tuff
fill 318 275 252 323 275 252 minecraft:blackstone
setblock 318 275 254 minecraft:tuff
fill 318 275 265 319 276 265 minecraft:blackstone
setblock 318 275 267 minecraft:tuff
setblock 318 275 269 minecraft:blackstone
setblock 319 275 230 minecraft:tuff
fill 319 275 236 321 276 236 minecraft:blackstone
fill 319 275 241 323 275 241 minecraft:blackstone
setblock 319 275 243 minecraft:tuff
fill 319 275 254 321 275 254 minecraft:blackstone
setblock 319 275 256 minecraft:tuff
fill 319 275 266 319 277 267 minecraft:blackstone
setblock 319 275 269 minecraft:tuff
fill 319 275 270 319 283 270 minecraft:blackstone
fill 320 275 230 322 276 230 minecraft:blackstone
setblock 320 275 232 minecraft:tuff
setblock 320 275 234 minecraft:blackstone
fill 320 275 243 323 275 243 minecraft:basalt
fill 320 275 244 323 275 244 minecraft:blackstone
setblock 320 275 245 minecraft:tuff
fill 320 275 246 322 277 246 minecraft:blackstone
fill 320 275 256 323 277 256 minecraft:blackstone
setblock 320 275 258 minecraft:tuff
fill 320 275 267 323 275 267 minecraft:blackstone
fill 321 275 232 323 277 232 minecraft:blackstone
setblock 321 275 234 minecraft:tuff
setblock 321 275 239 minecraft:blackstone
fill 321 275 245 323 276 245 minecraft:blackstone
setblock 321 275 247 minecraft:tuff
setblock 321 275 249 minecraft:blackstone
fill 321 275 258 323 275 258 minecraft:basalt
setblock 321 275 260 minecraft:tuff
fill 322 275 234 323 275 234 minecraft:blackstone
setblock 322 275 236 minecraft:tuff
fill 322 275 247 323 277 247 minecraft:blackstone
setblock 322 275 249 minecraft:tuff
setblock 322 275 262 minecraft:tuff
setblock 322 275 264 minecraft:blackstone
fill 323 275 235 323 276 236 minecraft:blackstone
setblock 323 275 238 minecraft:tuff
setblock 323 275 249 minecraft:blackstone
setblock 323 275 251 minecraft:tuff
fill 323 275 261 323 277 262 minecraft:blackstone
setblock 323 275 264 minecraft:tuff
setblock 323 275 269 minecraft:blackstone
fill 283 276 229 290 276 229 minecraft:basalt
fill 283 276 230 284 276 230 minecraft:blackstone
fill 283 276 232 285 276 233 minecraft:blackstone
fill 283 276 234 286 276 234 minecraft:basalt
fill 283 276 235 287 276 236 minecraft:blackstone
fill 283 276 238 288 277 238 minecraft:blackstone
setblock 283 276 239 minecraft:tuff
fill 283 276 240 283 276 241 minecraft:blackstone
fill 283 276 243 284 279 243 minecraft:blackstone
fill 283 276 244 289 276 244 minecraft:basalt
fill 283 276 246 286 276 248 minecraft:blackstone
fill 283 276 249 287 276 249 minecraft:basalt
fill 283 276 250 288 276 251 minecraft:blackstone
setblock 283 276 252 minecraft:tuff
fill 283 276 253 289 276 253 minecraft:blackstone
setblock 283 276 254 minecraft:basalt
fill 283 276 255 284 276 256 minecraft:blackstone
fill 283 276 258 285 277 258 minecraft:blackstone
fill 283 276 259 292 276 259 minecraft:basalt
fill 283 276 262 287 276 263 minecraft:blackstone
fill 283 276 264 288 276 264 minecraft:basalt
setblock 283 276 265 minecraft:tuff
fill 283 276 266 283 276 268 minecraft:blackstone
fill 283 276 269 284 276 269 minecraft:basalt
fill 284 276 239 292 276 239 minecraft:basalt
fill 284 276 240 289 276 240 minecraft:blackstone
setblock 284 276 241 minecraft:tuff
fill 284 276 245 285 276 245 minecraft:blackstone
setblock 284 276 254 minecraft:tuff
fill 284 276 261 293 276 261 minecraft:blackstone
fill 284 276 265 289 276 266 minecraft:blackstone
setblock 284 276 267 minecraft:tuff
fill 284 276 268 290 277 268 minecraft:blackstone
setblock 285 276 230 minecraft:tuff
fill 285 276 241 286 277 241 minecraft:blackstone
setblock 285 276 243 minecraft:tuff
fill 285 276 254 290 276 254 minecraft:basalt
fill 285 276 255 290 276 255 minecraft:blackstone
setblock 285 276 256 minecraft:tuff
fill 285 276 260 286 276 260 minecraft:blackstone
setblock 285 276 269 minecraft:tuff
fill 286 276 230 297 276 230 minecraft:blackstone
setblock 286 276 232 minecraft:tuff
fill 286 276 233 292 277 233 minecraft:blackstone
fill 286 276 242 286 278 243 minecraft:blackstone
setblock 286 276 245 minecraft:tuff
fill 286 276 256 291 276 256 minecraft:blackstone
setblock 286 276 258 minecraft:tuff
fill 286 276 269 297 276 269 minecraft:basalt
fill 287 276 231 291 276 232 minecraft:blackstone
setblock 287 276 234 minecraft:tuff
fill 287 276 243 289 276 243 minecraft:blackstone
fill 287 276 245 288 276 246 minecraft:blackstone
setblock 287 276 247 minecraft:tuff
fill 287 276 248 288 276 248 minecraft:blackstone
fill 287 276 257 291 276 258 minecraft:blackstone
setblock 287 276 260 minecraft:tuff
fill 288 276 234 299 276 234 minecraft:basalt
fill 288 276 235 293 276 235 minecraft:blackstone
setblock 288 276 236 minecraft:tuff
setblock 288 276 247 minecraft:blackstone
setblock 288 276 249 minecraft:tuff
fill 288 276 260 297 276 260 minecraft:blackstone
setblock 288 276 262 minecraft:tuff
fill 288 276 263 294 277 263 minecraft:blackstone
fill 289 276 236 297 276 236 minecraft:blackstone
setblock 289 276 238 minecraft:tuff
fill 289 276 245 289 277 245 minecraft:shroomlight
fill 289 276 246 289 276 250 minecraft:magma_block
fill 289 276 251 289 277 251 minecraft:shroomlight
setblock 289 276 264 minecraft:tuff
fill 290 276 237 293 276 238 minecraft:blackstone
setblock 290 276 240 minecraft:tuff
fill 290 276 243 290 276 244 minecraft:magma_block
fill 290 276 252 290 276 253 minecraft:magma_block
fill 290 276 264 301 276 264 minecraft:basalt
fill 290 276 265 295 276 265 minecraft:blackstone
setblock 290 276 266 minecraft:tuff
setblock 291 276 229 minecraft:tuff
setblock 291 276 240 minecraft:blackstone
fill 291 276 241 291 276 242 minecraft:magma_block
fill 291 276 254 291 276 255 minecraft:magma_block
fill 291 276 266 302 276 266 minecraft:blackstone
setblock 291 276 268 minecraft:tuff
fill 292 276 229 303 276 229 minecraft:basalt
setblock 292 276 231 minecraft:tuff
fill 292 276 232 298 277 232 minecraft:blackstone
setblock 292 276 240 minecraft:magma_block
setblock 292 276 256 minecraft:magma_block
schedule function dropper:buildpart/54_5 1t
