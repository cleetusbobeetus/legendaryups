fill 95 283 359 95 283 361 minecraft:stone
setblock 95 283 362 minecraft:stripped_spruce_log
fill 95 283 363 98 283 363 minecraft:stone
fill 96 283 323 98 283 323 minecraft:stone
fill 96 283 335 96 283 336 minecraft:andesite
fill 96 283 337 106 283 349 minecraft:stone
fill 96 283 350 96 283 351 minecraft:andesite
setblock 96 283 362 minecraft:stone
setblock 97 283 325 minecraft:light[level=15]
setblock 97 283 332 minecraft:light[level=12]
fill 97 283 333 97 283 334 minecraft:andesite
fill 97 283 335 108 283 336 minecraft:stone
fill 97 283 350 133 283 351 minecraft:stone
fill 97 283 352 97 283 353 minecraft:andesite
setblock 97 283 357 minecraft:light[level=15]
setblock 97 283 360 minecraft:light[level=12]
fill 98 283 332 98 284 332 minecraft:andesite
fill 98 283 333 111 283 334 minecraft:stone
fill 98 283 352 132 283 353 minecraft:stone
fill 98 283 354 98 284 354 minecraft:andesite
setblock 99 283 323 minecraft:stripped_spruce_log
setblock 99 283 330 minecraft:andesite
fill 99 283 332 131 284 332 minecraft:stone
fill 99 283 354 131 284 354 minecraft:stone
setblock 99 283 356 minecraft:andesite
setblock 99 283 362 minecraft:stone
setblock 99 283 363 minecraft:stripped_spruce_log
fill 100 283 323 103 283 323 minecraft:stone
setblock 100 283 329 minecraft:andesite
fill 100 283 330 130 283 330 minecraft:stone
fill 100 283 356 130 283 356 minecraft:stone
setblock 100 283 357 minecraft:andesite
setblock 100 283 362 minecraft:stripped_spruce_log
fill 100 283 363 103 283 363 minecraft:stone
setblock 101 283 328 minecraft:andesite
fill 101 283 329 110 283 329 minecraft:stone
fill 101 283 357 110 283 357 minecraft:stone
setblock 101 283 358 minecraft:andesite
fill 101 283 362 104 283 362 minecraft:stone
setblock 102 283 327 minecraft:andesite
fill 102 283 328 110 283 328 minecraft:stone
fill 102 283 358 110 283 358 minecraft:stone
setblock 102 283 359 minecraft:andesite
setblock 103 283 322 minecraft:raw_iron_block
fill 103 283 327 127 283 327 minecraft:stone
fill 103 283 359 127 283 359 minecraft:stone
setblock 104 283 323 minecraft:stripped_spruce_log
setblock 104 283 325 minecraft:light[level=12]
fill 104 283 326 104 284 326 minecraft:andesite
fill 104 283 360 104 284 360 minecraft:andesite
fill 104 283 361 104 284 361 minecraft:stone
setblock 104 283 363 minecraft:stripped_spruce_log
fill 105 283 323 106 284 324 minecraft:stone
fill 105 283 325 106 283 325 minecraft:andesite
fill 105 283 326 125 283 326 minecraft:stone
fill 105 283 360 125 283 360 minecraft:stone
fill 105 283 361 106 283 361 minecraft:andesite
setblock 105 283 362 minecraft:stripped_spruce_log
fill 105 283 363 108 283 363 minecraft:stone
fill 106 283 362 106 286 362 minecraft:stone
fill 107 283 323 108 283 323 minecraft:stone
fill 107 283 324 108 283 324 minecraft:andesite
fill 107 283 325 123 283 325 minecraft:stone
fill 107 283 337 107 283 338 minecraft:stone
fill 107 283 339 107 283 343 minecraft:cobbled_deepslate
fill 107 283 344 107 283 349 minecraft:stone
fill 107 283 361 123 283 361 minecraft:stone
fill 107 283 362 108 283 362 minecraft:andesite
setblock 108 283 337 minecraft:stone
setblock 108 283 338 minecraft:cobbled_deepslate
fill 108 283 344 108 283 345 minecraft:cobbled_deepslate
fill 108 283 346 108 283 349 minecraft:stone
fill 109 283 323 121 283 323 minecraft:andesite
fill 109 283 324 121 283 324 minecraft:stone
setblock 109 283 337 minecraft:cobbled_deepslate
setblock 109 283 346 minecraft:cobbled_deepslate
fill 109 283 347 109 283 349 minecraft:stone
fill 109 283 362 121 283 362 minecraft:stone
fill 109 283 363 121 283 363 minecraft:andesite
setblock 109 283 364 minecraft:raw_gold_block
setblock 110 283 336 minecraft:cobbled_deepslate
setblock 110 283 347 minecraft:cobbled_deepslate
fill 110 283 348 110 283 349 minecraft:stone
fill 110 283 364 110 308 364 minecraft:stone
setblock 111 283 335 minecraft:cobbled_deepslate
setblock 111 283 339 minecraft:light[level=12]
setblock 111 283 346 minecraft:light[level=12]
fill 111 283 348 113 283 348 minecraft:cobbled_deepslate
fill 111 283 349 113 283 349 minecraft:stone
fill 112 283 333 132 283 333 minecraft:stone
fill 112 283 334 117 283 334 minecraft:cobbled_deepslate
setblock 113 283 341 minecraft:light[level=15]
fill 114 283 328 128 283 329 minecraft:stone
fill 114 283 349 115 283 349 minecraft:cobbled_deepslate
fill 114 283 357 128 283 358 minecraft:stone
fill 116 283 348 118 283 348 minecraft:cobbled_deepslate
fill 116 283 349 134 283 349 minecraft:stone
setblock 117 283 322 minecraft:raw_iron_block
setblock 117 283 364 minecraft:gold_block
fill 118 283 334 132 283 334 minecraft:stone
setblock 118 283 335 minecraft:cobbled_deepslate
setblock 118 283 339 minecraft:light[level=12]
setblock 118 283 346 minecraft:light[level=12]
fill 118 283 364 118 308 364 minecraft:stone
fill 119 283 335 133 283 335 minecraft:stone
setblock 119 283 336 minecraft:cobbled_deepslate
setblock 119 283 347 minecraft:cobbled_deepslate
fill 119 283 348 134 283 348 minecraft:stone
fill 120 283 336 133 283 336 minecraft:stone
setblock 120 283 337 minecraft:cobbled_deepslate
setblock 120 283 346 minecraft:cobbled_deepslate
fill 120 283 347 134 283 347 minecraft:stone
fill 121 283 337 134 283 337 minecraft:stone
fill 121 283 338 121 283 339 minecraft:cobbled_deepslate
setblock 121 283 341 minecraft:light[level=15]
fill 121 283 343 121 283 345 minecraft:cobbled_deepslate
fill 121 283 346 134 283 346 minecraft:stone
fill 122 283 324 123 283 324 minecraft:andesite
fill 122 283 338 134 283 339 minecraft:stone
fill 122 283 340 122 283 342 minecraft:cobbled_deepslate
fill 122 283 343 134 283 345 minecraft:stone
fill 122 283 362 123 283 362 minecraft:andesite
setblock 123 283 323 minecraft:stone
fill 123 283 340 134 283 342 minecraft:stone
setblock 123 283 363 minecraft:stone
setblock 124 283 323 minecraft:stripped_spruce_log
fill 124 283 325 125 283 325 minecraft:andesite
fill 124 283 361 125 283 361 minecraft:andesite
setblock 124 283 363 minecraft:stripped_spruce_log
fill 125 283 323 127 283 324 minecraft:stone
fill 125 283 363 125 286 364 minecraft:stone
fill 126 283 326 126 284 326 minecraft:andesite
fill 126 283 360 126 284 360 minecraft:andesite
fill 126 283 363 128 283 363 minecraft:stone
fill 127 283 362 129 283 362 minecraft:stone
setblock 128 283 323 minecraft:stone
setblock 128 283 324 minecraft:stripped_spruce_log
fill 128 283 325 131 283 325 minecraft:stone
setblock 128 283 327 minecraft:andesite
setblock 128 283 359 minecraft:andesite
setblock 129 283 323 minecraft:stripped_spruce_log
fill 129 283 324 132 283 324 minecraft:stone
setblock 129 283 328 minecraft:andesite
setblock 129 283 329 minecraft:stone
setblock 129 283 357 minecraft:stone
setblock 129 283 358 minecraft:andesite
setblock 129 283 363 minecraft:stripped_spruce_log
fill 130 283 323 133 283 323 minecraft:stone
setblock 130 283 329 minecraft:andesite
setblock 130 283 357 minecraft:andesite
setblock 130 283 362 minecraft:stripped_spruce_log
fill 130 283 363 133 283 363 minecraft:stone
setblock 131 283 330 minecraft:andesite
setblock 131 283 356 minecraft:andesite
setblock 131 283 362 minecraft:stone
setblock 132 283 325 minecraft:light[level=12]
fill 132 283 332 132 284 332 minecraft:andesite
fill 132 283 354 132 284 354 minecraft:andesite
setblock 132 283 360 minecraft:light[level=12]
setblock 133 283 324 minecraft:stripped_spruce_log
fill 133 283 333 133 283 334 minecraft:andesite
fill 133 283 352 133 283 353 minecraft:andesite
setblock 134 283 323 minecraft:stripped_spruce_log
fill 134 283 324 135 283 326 minecraft:stone
fill 134 283 335 134 283 336 minecraft:andesite
fill 134 283 350 134 283 351 minecraft:andesite
setblock 134 283 363 minecraft:stripped_spruce_log
fill 135 283 323 135 286 323 minecraft:stone
setblock 135 283 327 minecraft:stripped_spruce_log
fill 135 283 328 135 286 328 minecraft:stone
fill 135 283 337 135 283 349 minecraft:andesite
setblock 135 283 362 minecraft:stripped_spruce_log
fill 135 283 363 135 286 363 minecraft:stone
fill 136 283 330 136 302 330 minecraft:stone
setblock 136 283 331 minecraft:diamond_block
fill 136 283 352 136 308 352 minecraft:stone
fill 136 283 360 136 286 360 minecraft:stone
fill 94 284 355 94 308 355 minecraft:stone
fill 94 284 363 97 284 363 minecraft:stone
fill 95 284 323 95 284 325 minecraft:stone
fill 95 284 326 99 284 326 minecraft:stripped_spruce_log
fill 95 284 340 95 284 346 minecraft:andesite
setblock 95 284 360 minecraft:stone
setblock 95 284 361 minecraft:stripped_spruce_log
fill 95 284 362 95 287 362 minecraft:stone
fill 96 284 323 97 284 323 minecraft:stone
fill 96 284 325 99 289 325 minecraft:stripped_spruce_log
fill 96 284 327 99 290 327 minecraft:stripped_spruce_log
fill 96 284 336 96 284 339 minecraft:andesite
fill 96 284 340 105 284 346 minecraft:stone
fill 96 284 347 96 284 350 minecraft:andesite
fill 97 284 324 98 287 324 minecraft:stripped_spruce_log
fill 97 284 328 97 300 328 minecraft:stripped_spruce_log
fill 97 284 334 97 284 335 minecraft:andesite
fill 97 284 336 106 284 339 minecraft:stone
fill 97 284 347 108 284 350 minecraft:stone
fill 97 284 351 97 284 352 minecraft:andesite
setblock 98 284 323 minecraft:stripped_spruce_log
setblock 98 284 333 minecraft:andesite
fill 98 284 334 109 284 335 minecraft:stone
fill 98 284 351 132 284 352 minecraft:stone
setblock 98 284 353 minecraft:andesite
setblock 98 284 363 minecraft:stripped_spruce_log
fill 99 284 323 102 284 323 minecraft:stone
setblock 99 284 331 minecraft:andesite
fill 99 284 333 113 284 333 minecraft:stone
fill 99 284 353 131 284 353 minecraft:stone
setblock 99 284 355 minecraft:andesite
fill 99 284 356 99 287 356 minecraft:cobbled_deepslate
fill 99 284 363 102 284 363 minecraft:stone
setblock 100 284 330 minecraft:andesite
fill 100 284 331 130 284 331 minecraft:stone
fill 100 284 355 130 284 355 minecraft:stone
setblock 100 284 356 minecraft:andesite
fill 100 284 362 103 284 362 minecraft:stone
setblock 101 284 329 minecraft:andesite
fill 101 284 330 129 284 330 minecraft:stone
fill 101 284 356 129 284 356 minecraft:stone
setblock 101 284 357 minecraft:andesite
setblock 102 284 328 minecraft:andesite
fill 102 284 329 110 284 329 minecraft:stone
fill 102 284 357 110 284 357 minecraft:stone
setblock 102 284 358 minecraft:andesite
fill 103 284 322 103 308 322 minecraft:stone
setblock 103 284 323 minecraft:stripped_spruce_log
setblock 103 284 327 minecraft:andesite
fill 103 284 328 110 284 328 minecraft:stone
fill 103 284 358 110 284 358 minecraft:stone
setblock 103 284 359 minecraft:andesite
setblock 103 284 363 minecraft:stripped_spruce_log
fill 104 284 323 104 286 324 minecraft:stone
fill 104 284 327 126 284 327 minecraft:stone
fill 104 284 359 126 284 359 minecraft:stone
setblock 104 284 362 minecraft:stripped_spruce_log
fill 104 284 363 107 284 363 minecraft:stone
setblock 105 284 326 minecraft:andesite
setblock 105 284 360 minecraft:andesite
setblock 105 284 361 minecraft:stripped_spruce_log
fill 105 284 362 105 287 362 minecraft:stone
fill 106 284 325 107 284 325 minecraft:andesite
fill 106 284 326 124 284 326 minecraft:stone
setblock 106 284 340 minecraft:stone
fill 106 284 341 106 284 342 minecraft:cobbled_deepslate
fill 106 284 343 106 284 346 minecraft:stone
fill 106 284 360 124 284 360 minecraft:stone
fill 106 284 361 107 284 361 minecraft:andesite
setblock 107 284 323 minecraft:stone
setblock 107 284 324 minecraft:stripped_spruce_log
fill 107 284 336 107 284 337 minecraft:stone
fill 107 284 338 107 284 340 minecraft:cobbled_deepslate
fill 107 284 343 107 284 345 minecraft:cobbled_deepslate
setblock 107 284 346 minecraft:stone
fill 107 284 362 107 285 362 minecraft:stone
setblock 108 284 323 minecraft:stripped_spruce_log
fill 108 284 324 111 284 324 minecraft:andesite
fill 108 284 325 122 284 325 minecraft:stone
setblock 108 284 336 minecraft:stone
setblock 108 284 337 minecraft:cobbled_deepslate
setblock 108 284 346 minecraft:cobbled_deepslate
fill 108 284 361 122 284 361 minecraft:stone
fill 108 284 362 111 284 362 minecraft:andesite
setblock 108 284 363 minecraft:stripped_spruce_log
fill 109 284 323 111 285 323 minecraft:stone
setblock 109 284 336 minecraft:cobbled_deepslate
fill 109 284 347 109 284 348 minecraft:cobbled_deepslate
fill 109 284 349 110 284 350 minecraft:stone
fill 109 284 363 109 287 364 minecraft:stone
setblock 110 284 334 minecraft:stone
setblock 110 284 335 minecraft:cobbled_deepslate
setblock 110 284 348 minecraft:cobbled_deepslate
fill 110 284 363 111 285 363 minecraft:stone
fill 111 284 334 113 284 334 minecraft:cobbled_deepslate
fill 111 284 349 113 284 349 minecraft:cobbled_deepslate
fill 111 284 350 112 284 350 minecraft:stone
fill 112 284 323 118 284 323 minecraft:andesite
fill 112 284 324 118 284 324 minecraft:stone
fill 112 284 362 118 284 362 minecraft:stone
fill 112 284 363 118 284 363 minecraft:andesite
fill 113 284 350 116 284 350 minecraft:cobbled_deepslate
fill 114 284 328 127 284 329 minecraft:stone
fill 114 284 333 115 284 333 minecraft:cobbled_deepslate
fill 114 284 357 127 284 358 minecraft:stone
fill 116 284 333 131 284 333 minecraft:stone
fill 116 284 334 118 284 334 minecraft:cobbled_deepslate
fill 116 284 349 118 284 349 minecraft:cobbled_deepslate
setblock 117 284 322 minecraft:stone
fill 117 284 350 133 284 350 minecraft:stone
fill 117 284 364 117 308 364 minecraft:stone
fill 119 284 324 122 284 324 minecraft:andesite
fill 119 284 334 132 284 334 minecraft:stone
setblock 119 284 335 minecraft:cobbled_deepslate
fill 119 284 348 120 284 348 minecraft:cobbled_deepslate
fill 119 284 349 133 284 349 minecraft:stone
fill 119 284 362 122 284 362 minecraft:andesite
fill 120 284 335 132 284 335 minecraft:stone
setblock 120 284 336 minecraft:cobbled_deepslate
fill 120 284 347 121 284 347 minecraft:cobbled_deepslate
fill 121 284 336 133 284 336 minecraft:stone
setblock 121 284 337 minecraft:cobbled_deepslate
setblock 121 284 346 minecraft:cobbled_deepslate
fill 121 284 348 133 284 348 minecraft:stone
setblock 122 284 323 minecraft:stone
fill 122 284 337 133 284 337 minecraft:stone
fill 122 284 338 122 284 340 minecraft:cobbled_deepslate
fill 122 284 343 122 284 345 minecraft:cobbled_deepslate
fill 122 284 346 133 284 347 minecraft:stone
setblock 123 284 323 minecraft:stripped_spruce_log
fill 123 284 325 124 284 325 minecraft:andesite
fill 123 284 338 133 284 340 minecraft:stone
fill 123 284 341 123 284 342 minecraft:cobbled_deepslate
fill 123 284 343 134 284 345 minecraft:stone
fill 123 284 361 124 284 361 minecraft:andesite
setblock 123 284 363 minecraft:stripped_spruce_log
fill 124 284 323 126 284 324 minecraft:stone
fill 124 284 341 134 284 342 minecraft:stone
fill 124 284 363 124 287 363 minecraft:stone
setblock 125 284 326 minecraft:andesite
setblock 125 284 360 minecraft:andesite
fill 126 284 363 127 284 363 minecraft:stone
setblock 127 284 323 minecraft:stone
setblock 127 284 324 minecraft:stripped_spruce_log
fill 127 284 325 130 284 325 minecraft:stone
setblock 127 284 327 minecraft:andesite
setblock 127 284 359 minecraft:andesite
setblock 128 284 323 minecraft:stripped_spruce_log
fill 128 284 324 131 284 324 minecraft:stone
setblock 128 284 328 minecraft:andesite
setblock 128 284 329 minecraft:stone
setblock 128 284 357 minecraft:stone
setblock 128 284 358 minecraft:andesite
setblock 128 284 363 minecraft:stripped_spruce_log
fill 129 284 323 132 284 323 minecraft:stone
setblock 129 284 329 minecraft:andesite
setblock 129 284 357 minecraft:andesite
fill 129 284 363 132 284 363 minecraft:stone
setblock 130 284 330 minecraft:andesite
setblock 130 284 356 minecraft:andesite
setblock 131 284 325 minecraft:stripped_spruce_log
setblock 131 284 331 minecraft:andesite
setblock 131 284 355 minecraft:andesite
setblock 132 284 324 minecraft:stripped_spruce_log
setblock 132 284 333 minecraft:andesite
setblock 132 284 353 minecraft:andesite
setblock 133 284 323 minecraft:stripped_spruce_log
fill 133 284 324 135 285 324 minecraft:stone
fill 133 284 334 133 284 335 minecraft:andesite
fill 133 284 351 133 284 352 minecraft:andesite
setblock 133 284 363 minecraft:stripped_spruce_log
fill 134 284 323 134 287 323 minecraft:stone
fill 134 284 325 134 284 326 minecraft:stone
fill 134 284 336 134 284 339 minecraft:andesite
setblock 134 284 340 minecraft:stone
setblock 134 284 346 minecraft:stone
fill 134 284 347 134 284 350 minecraft:andesite
fill 134 284 363 134 287 363 minecraft:stone
setblock 135 284 325 minecraft:stone
setblock 135 284 326 minecraft:stripped_spruce_log
fill 135 284 327 135 287 327 minecraft:stone
fill 135 284 340 135 284 346 minecraft:andesite
fill 136 284 331 136 308 331 minecraft:stone
fill 94 285 363 96 285 363 minecraft:stone
fill 95 285 323 95 285 324 minecraft:stone
setblock 95 285 325 minecraft:stripped_spruce_log
fill 95 285 326 95 288 326 minecraft:stone
fill 95 285 327 95 286 328 minecraft:cobbled_deepslate
fill 95 285 361 95 288 361 minecraft:stone
setblock 96 285 322 minecraft:gold_block
setblock 96 285 323 minecraft:stone
fill 96 285 324 96 286 324 minecraft:cobbled_deepslate
fill 96 285 326 99 289 326 minecraft:stripped_spruce_log
fill 96 285 328 96 286 328 minecraft:cobbled_deepslate
fill 96 285 339 96 285 347 minecraft:andesite
setblock 97 285 323 minecraft:stripped_spruce_log
fill 97 285 336 97 285 338 minecraft:andesite
fill 97 285 339 105 285 347 minecraft:stone
fill 97 285 348 97 285 350 minecraft:andesite
setblock 97 285 363 minecraft:stripped_spruce_log
fill 98 285 323 101 285 323 minecraft:stone
fill 98 285 328 99 286 328 minecraft:cobbled_deepslate
fill 98 285 334 98 285 335 minecraft:andesite
fill 98 285 336 106 285 338 minecraft:stone
fill 98 285 348 107 285 350 minecraft:stone
fill 98 285 351 98 285 352 minecraft:andesite
fill 98 285 356 98 287 356 minecraft:cobbled_deepslate
fill 98 285 363 101 285 363 minecraft:stone
fill 99 285 324 99 286 324 minecraft:cobbled_deepslate
fill 99 285 332 99 285 333 minecraft:andesite
fill 99 285 334 108 285 335 minecraft:stone
fill 99 285 351 112 285 352 minecraft:stone
fill 99 285 353 99 285 354 minecraft:andesite
fill 99 285 355 99 287 355 minecraft:cobbled_deepslate
fill 99 285 357 99 287 357 minecraft:cobbled_deepslate
fill 100 285 325 100 286 326 minecraft:cobbled_deepslate
setblock 100 285 331 minecraft:andesite
fill 100 285 332 111 285 333 minecraft:stone
fill 100 285 353 130 285 354 minecraft:stone
setblock 100 285 355 minecraft:andesite
fill 100 285 356 100 287 356 minecraft:cobbled_deepslate
fill 100 285 362 102 285 362 minecraft:stone
setblock 101 285 330 minecraft:andesite
fill 101 285 331 129 285 331 minecraft:stone
fill 101 285 355 129 285 355 minecraft:stone
setblock 101 285 356 minecraft:andesite
setblock 102 285 323 minecraft:stripped_spruce_log
setblock 102 285 329 minecraft:andesite
fill 102 285 330 128 285 330 minecraft:stone
fill 102 285 356 128 285 356 minecraft:stone
setblock 102 285 357 minecraft:andesite
setblock 102 285 363 minecraft:stripped_spruce_log
fill 103 285 323 103 287 324 minecraft:stone
setblock 103 285 328 minecraft:andesite
fill 103 285 329 110 285 329 minecraft:stone
fill 103 285 357 110 285 357 minecraft:stone
setblock 103 285 358 minecraft:andesite
setblock 103 285 362 minecraft:stripped_spruce_log
fill 103 285 363 106 285 363 minecraft:stone
fill 104 285 327 105 285 327 minecraft:andesite
fill 104 285 328 110 285 328 minecraft:stone
fill 104 285 358 110 285 358 minecraft:stone
fill 104 285 359 105 285 359 minecraft:andesite
fill 104 285 362 104 288 362 minecraft:stone
fill 105 285 323 105 285 324 minecraft:stone
fill 105 285 361 107 285 361 minecraft:stone
setblock 106 285 323 minecraft:stone
setblock 106 285 324 minecraft:stripped_spruce_log
fill 106 285 326 107 285 326 minecraft:andesite
fill 106 285 327 124 285 327 minecraft:stone
fill 106 285 339 106 285 345 minecraft:spruce_planks
fill 106 285 346 106 285 347 minecraft:stone
fill 106 285 359 124 285 359 minecraft:stone
fill 106 285 360 107 285 360 minecraft:andesite
setblock 107 285 323 minecraft:stripped_spruce_log
fill 107 285 324 108 287 324 minecraft:stone
setblock 107 285 336 minecraft:stone
fill 107 285 337 107 285 338 minecraft:spruce_planks
fill 107 285 346 107 285 347 minecraft:spruce_planks
setblock 107 285 363 minecraft:stripped_spruce_log
fill 108 285 323 108 288 323 minecraft:stone
fill 108 285 325 110 285 325 minecraft:andesite
fill 108 285 326 122 285 326 minecraft:stone
setblock 108 285 336 minecraft:spruce_planks
fill 108 285 347 108 285 348 minecraft:spruce_planks
fill 108 285 349 108 285 350 minecraft:stone
fill 108 285 360 122 285 360 minecraft:stone
fill 108 285 361 110 285 361 minecraft:andesite
setblock 108 285 362 minecraft:stripped_spruce_log
fill 108 285 363 108 288 363 minecraft:stone
setblock 109 285 334 minecraft:stone
setblock 109 285 335 minecraft:spruce_planks
fill 109 285 349 110 285 349 minecraft:spruce_planks
fill 109 285 350 110 285 350 minecraft:stone
fill 109 285 362 110 286 362 minecraft:stone
fill 110 285 334 111 285 334 minecraft:spruce_planks
fill 111 285 324 119 285 324 minecraft:andesite
fill 111 285 325 119 285 325 minecraft:stone
fill 111 285 350 112 285 350 minecraft:spruce_planks
fill 111 285 361 119 285 361 minecraft:stone
fill 111 285 362 119 285 362 minecraft:andesite
setblock 112 285 323 minecraft:stripped_spruce_log
fill 112 285 332 130 285 332 minecraft:stone
fill 112 285 333 117 285 333 minecraft:spruce_planks
setblock 112 285 363 minecraft:stripped_spruce_log
setblock 112 285 364 minecraft:diamond_block
fill 113 285 351 116 285 351 minecraft:spruce_planks
fill 113 285 352 131 285 352 minecraft:stone
setblock 113 285 363 minecraft:stone
fill 114 285 328 126 285 329 minecraft:stone
fill 114 285 357 126 285 358 minecraft:stone
setblock 117 285 322 minecraft:raw_gold_block
fill 117 285 350 119 285 350 minecraft:spruce_planks
fill 117 285 351 131 285 351 minecraft:stone
fill 118 285 333 130 285 333 minecraft:stone
fill 118 285 334 119 285 334 minecraft:spruce_planks
fill 119 285 349 120 285 349 minecraft:spruce_planks
fill 120 285 325 122 285 325 minecraft:andesite
fill 120 285 334 131 285 334 minecraft:stone
setblock 120 285 335 minecraft:spruce_planks
fill 120 285 350 132 285 350 minecraft:stone
fill 120 285 361 122 285 361 minecraft:andesite
setblock 121 285 323 minecraft:stone
fill 121 285 335 131 285 335 minecraft:stone
setblock 121 285 336 minecraft:spruce_planks
setblock 121 285 348 minecraft:spruce_planks
fill 121 285 349 132 285 349 minecraft:stone
setblock 122 285 323 minecraft:stripped_spruce_log
fill 122 285 336 132 285 336 minecraft:stone
setblock 122 285 337 minecraft:spruce_planks
fill 122 285 346 122 285 347 minecraft:spruce_planks
fill 122 285 348 132 285 348 minecraft:stone
fill 123 285 323 125 285 324 minecraft:stone
fill 123 285 326 124 285 326 minecraft:andesite
fill 123 285 337 132 285 337 minecraft:stone
fill 123 285 338 123 285 345 minecraft:spruce_planks
fill 123 285 346 133 285 347 minecraft:stone
fill 123 285 360 124 285 360 minecraft:andesite
fill 123 285 363 123 288 363 minecraft:stone
fill 124 285 338 132 285 345 minecraft:stone
fill 125 285 327 126 285 327 minecraft:andesite
fill 125 285 359 126 285 359 minecraft:andesite
setblock 126 285 323 minecraft:stone
setblock 126 285 324 minecraft:stripped_spruce_log
fill 126 285 325 129 285 325 minecraft:stone
setblock 126 285 363 minecraft:stone
setblock 127 285 323 minecraft:stripped_spruce_log
fill 127 285 324 130 285 324 minecraft:stone
setblock 127 285 328 minecraft:andesite
setblock 127 285 329 minecraft:stone
setblock 127 285 357 minecraft:stone
setblock 127 285 358 minecraft:andesite
setblock 127 285 363 minecraft:stripped_spruce_log
fill 128 285 323 131 285 323 minecraft:stone
setblock 128 285 329 minecraft:andesite
setblock 128 285 357 minecraft:andesite
fill 128 285 363 131 285 363 minecraft:stone
setblock 129 285 330 minecraft:andesite
setblock 129 285 356 minecraft:andesite
setblock 130 285 325 minecraft:stripped_spruce_log
setblock 130 285 331 minecraft:andesite
setblock 130 285 355 minecraft:andesite
setblock 131 285 324 minecraft:stripped_spruce_log
fill 131 285 325 131 288 325 minecraft:stone
fill 131 285 332 131 285 333 minecraft:andesite
fill 131 285 353 131 285 354 minecraft:andesite
setblock 132 285 323 minecraft:stripped_spruce_log
fill 132 285 324 132 288 324 minecraft:stone
fill 132 285 334 132 285 335 minecraft:andesite
fill 132 285 351 132 285 352 minecraft:andesite
setblock 132 285 363 minecraft:stripped_spruce_log
fill 133 285 323 133 288 323 minecraft:stone
fill 133 285 336 133 285 338 minecraft:andesite
fill 133 285 339 133 285 345 minecraft:stone
fill 133 285 348 133 285 350 minecraft:andesite
fill 133 285 363 133 288 363 minecraft:stone
setblock 134 285 325 minecraft:stone
setblock 134 285 326 minecraft:stripped_spruce_log
fill 134 285 339 134 285 347 minecraft:andesite
setblock 135 285 322 minecraft:gold_block
setblock 135 285 325 minecraft:stripped_spruce_log
fill 135 285 326 135 288 326 minecraft:stone
fill 136 285 322 136 308 322 minecraft:stone
setblock 136 285 327 minecraft:diamond_block
setblock 136 285 346 minecraft:diamond_block
fill 94 286 337 94 308 338 minecraft:stone
setblock 94 286 339 minecraft:gold_block
fill 94 286 347 94 308 347 minecraft:stone
setblock 94 286 348 minecraft:gold_block
fill 94 286 349 94 300 350 minecraft:stone
fill 94 286 352 94 308 352 minecraft:stone
setblock 94 286 353 minecraft:raw_iron_block
fill 94 286 354 94 289 354 minecraft:stone
setblock 94 286 358 minecraft:raw_iron_block
fill 94 286 359 94 308 359 minecraft:stone
fill 94 286 363 95 286 363 minecraft:stone
setblock 95 286 323 minecraft:stone
setblock 95 286 324 minecraft:stripped_spruce_log
fill 95 286 325 95 289 325 minecraft:stone
fill 95 286 329 99 286 329 minecraft:cobbled_deepslate
fill 96 286 322 96 308 322 minecraft:stone
setblock 96 286 323 minecraft:stripped_spruce_log
setblock 96 286 363 minecraft:stripped_spruce_log
fill 97 286 323 100 286 323 minecraft:stone
fill 97 286 338 97 286 348 minecraft:andesite
fill 97 286 363 100 286 363 minecraft:stone
fill 98 286 335 98 286 337 minecraft:andesite
fill 98 286 338 104 286 348 minecraft:stone
fill 98 286 349 98 286 351 minecraft:andesite
fill 98 286 355 98 287 355 minecraft:cobbled_deepslate
fill 98 286 357 98 287 357 minecraft:cobbled_deepslate
fill 99 286 333 99 297 333 minecraft:iron_bars
setblock 99 286 334 minecraft:andesite
fill 99 286 335 105 286 337 minecraft:stone
fill 99 286 349 107 286 351 minecraft:stone
setblock 99 286 352 minecraft:andesite
setblock 100 286 324 minecraft:cobbled_deepslate
fill 100 286 327 100 286 328 minecraft:cobbled_deepslate
fill 100 286 332 100 286 333 minecraft:andesite
fill 100 286 334 108 286 334 minecraft:stone
fill 100 286 352 112 286 352 minecraft:stone
fill 100 286 353 100 286 354 minecraft:andesite
fill 100 286 355 100 287 355 minecraft:cobbled_deepslate
fill 100 286 357 100 287 357 minecraft:cobbled_deepslate
fill 100 286 362 101 286 362 minecraft:stone
setblock 101 286 323 minecraft:stripped_spruce_log
fill 101 286 324 102 288 324 minecraft:stone
setblock 101 286 326 minecraft:cobbled_deepslate
setblock 101 286 331 minecraft:andesite
fill 101 286 332 110 286 333 minecraft:stone
fill 101 286 353 129 286 354 minecraft:stone
setblock 101 286 355 minecraft:andesite
setblock 101 286 363 minecraft:stripped_spruce_log
fill 102 286 323 102 289 323 minecraft:stone
setblock 102 286 330 minecraft:andesite
fill 102 286 331 128 286 331 minecraft:stone
fill 102 286 355 128 286 355 minecraft:stone
setblock 102 286 356 minecraft:andesite
setblock 102 286 362 minecraft:stripped_spruce_log
fill 102 286 363 105 286 363 minecraft:stone
setblock 103 286 329 minecraft:andesite
fill 103 286 330 127 286 330 minecraft:stone
fill 103 286 356 127 286 356 minecraft:stone
setblock 103 286 357 minecraft:andesite
fill 103 286 362 103 289 362 minecraft:stone
fill 104 286 328 105 286 328 minecraft:andesite
fill 104 286 329 110 286 329 minecraft:stone
fill 104 286 357 110 286 357 minecraft:stone
fill 104 286 358 105 286 358 minecraft:andesite
setblock 105 286 323 minecraft:stone
setblock 105 286 324 minecraft:stripped_spruce_log
fill 105 286 338 105 286 339 minecraft:stone
fill 105 286 340 105 286 345 minecraft:cobbled_deepslate
fill 105 286 346 105 286 348 minecraft:stone
setblock 105 286 361 minecraft:stone
setblock 106 286 323 minecraft:stripped_spruce_log
fill 106 286 324 106 289 324 minecraft:stone
setblock 106 286 327 minecraft:andesite
fill 106 286 328 110 286 328 minecraft:stone
fill 106 286 335 106 287 336 minecraft:stone
fill 106 286 337 106 286 339 minecraft:cobbled_deepslate
fill 106 286 346 106 286 347 minecraft:cobbled_deepslate
setblock 106 286 348 minecraft:stone
fill 106 286 358 110 286 358 minecraft:stone
setblock 106 286 359 minecraft:andesite
setblock 106 286 363 minecraft:stripped_spruce_log
fill 107 286 323 107 289 323 minecraft:stone
fill 107 286 326 109 286 326 minecraft:andesite
fill 107 286 327 123 286 327 minecraft:stone
setblock 107 286 335 minecraft:stone
fill 107 286 336 107 287 336 minecraft:cobbled_deepslate
setblock 107 286 348 minecraft:cobbled_deepslate
fill 107 286 359 123 286 359 minecraft:stone
fill 107 286 360 109 286 360 minecraft:andesite
setblock 107 286 362 minecraft:stripped_spruce_log
fill 107 286 363 107 289 363 minecraft:stone
setblock 108 286 335 minecraft:cobbled_deepslate
setblock 108 286 349 minecraft:cobbled_deepslate
fill 108 286 350 108 286 351 minecraft:stone
fill 108 286 362 108 289 362 minecraft:stone
fill 109 286 323 110 286 323 minecraft:stone
fill 109 286 334 110 286 334 minecraft:cobbled_deepslate
fill 109 286 350 110 286 350 minecraft:cobbled_deepslate
setblock 109 286 351 minecraft:stone
fill 110 286 325 120 286 325 minecraft:andesite
fill 110 286 326 120 286 326 minecraft:stone
fill 110 286 351 112 286 351 minecraft:cobbled_deepslate
fill 110 286 360 120 286 360 minecraft:stone
fill 110 286 361 120 286 361 minecraft:andesite
setblock 110 286 363 minecraft:stone
setblock 111 286 323 minecraft:stripped_spruce_log
fill 111 286 332 113 286 332 minecraft:stone
fill 111 286 333 113 286 333 minecraft:cobbled_deepslate
setblock 111 286 363 minecraft:stripped_spruce_log
fill 112 286 363 112 286 364 minecraft:stone
fill 113 286 352 117 286 352 minecraft:cobbled_deepslate
fill 114 286 328 124 286 329 minecraft:stone
fill 114 286 332 116 287 332 minecraft:cobbled_deepslate
fill 114 286 357 124 286 358 minecraft:stone
fill 115 286 333 119 286 333 minecraft:cobbled_deepslate
fill 117 286 322 117 308 322 minecraft:stone
fill 117 286 332 129 286 332 minecraft:stone
fill 117 286 351 119 286 351 minecraft:cobbled_deepslate
fill 118 286 352 130 286 352 minecraft:stone
setblock 120 286 323 minecraft:stone
fill 120 286 333 129 286 333 minecraft:stone
setblock 120 286 334 minecraft:cobbled_deepslate
fill 120 286 350 121 286 350 minecraft:cobbled_deepslate
fill 120 286 351 131 286 351 minecraft:stone
setblock 121 286 323 minecraft:stripped_spruce_log
fill 121 286 326 123 286 326 minecraft:andesite
fill 121 286 334 130 286 334 minecraft:stone
setblock 121 286 335 minecraft:cobbled_deepslate
fill 121 286 349 122 286 349 minecraft:cobbled_deepslate
fill 121 286 360 123 286 360 minecraft:andesite
fill 122 286 323 124 286 324 minecraft:stone
fill 122 286 335 131 286 335 minecraft:stone
setblock 122 286 336 minecraft:cobbled_deepslate
fill 122 286 348 123 286 348 minecraft:cobbled_deepslate
fill 122 286 350 131 286 350 minecraft:stone
fill 123 286 336 131 286 336 minecraft:stone
fill 123 286 337 123 286 338 minecraft:cobbled_deepslate
fill 123 286 346 123 286 347 minecraft:cobbled_deepslate
fill 123 286 349 131 286 349 minecraft:stone
setblock 124 286 327 minecraft:andesite
fill 124 286 337 131 286 338 minecraft:stone
fill 124 286 339 124 286 346 minecraft:cobbled_deepslate
fill 124 286 347 132 286 348 minecraft:stone
setblock 124 286 359 minecraft:andesite
setblock 125 286 323 minecraft:stone
setblock 125 286 324 minecraft:stripped_spruce_log
fill 125 286 325 128 286 325 minecraft:stone
fill 125 286 328 126 286 328 minecraft:andesite
fill 125 286 329 126 286 329 minecraft:stone
fill 125 286 339 132 286 346 minecraft:stone
fill 125 286 357 126 286 357 minecraft:stone
fill 125 286 358 126 286 358 minecraft:andesite
setblock 126 286 323 minecraft:stripped_spruce_log
fill 126 286 324 129 286 324 minecraft:stone
setblock 126 286 363 minecraft:stripped_spruce_log
fill 127 286 323 130 286 323 minecraft:stone
setblock 127 286 329 minecraft:andesite
setblock 127 286 357 minecraft:andesite
fill 127 286 363 130 286 363 minecraft:stone
setblock 128 286 330 minecraft:andesite
setblock 128 286 356 minecraft:andesite
setblock 129 286 325 minecraft:stripped_spruce_log
setblock 129 286 331 minecraft:andesite
setblock 129 286 355 minecraft:andesite
setblock 130 286 324 minecraft:stripped_spruce_log
fill 130 286 325 130 289 325 minecraft:stone
fill 130 286 332 130 286 333 minecraft:andesite
fill 130 286 353 130 286 354 minecraft:andesite
setblock 131 286 323 minecraft:stripped_spruce_log
fill 131 286 324 131 289 324 minecraft:stone
setblock 131 286 334 minecraft:andesite
setblock 131 286 352 minecraft:andesite
setblock 131 286 363 minecraft:stripped_spruce_log
fill 132 286 323 132 289 323 minecraft:stone
fill 132 286 335 132 286 337 minecraft:andesite
setblock 132 286 338 minecraft:stone
fill 132 286 349 132 286 351 minecraft:andesite
fill 132 286 363 132 289 363 minecraft:stone
fill 133 286 324 134 286 324 minecraft:stone
fill 133 286 338 133 286 348 minecraft:andesite
setblock 134 286 325 minecraft:stripped_spruce_log
fill 134 286 326 134 289 326 minecraft:stone
fill 135 286 322 135 288 322 minecraft:stone
setblock 135 286 324 minecraft:stripped_spruce_log
fill 135 286 325 135 289 325 minecraft:stone
setblock 135 286 329 minecraft:stripped_spruce_log
fill 136 286 327 136 308 327 minecraft:stone
fill 136 286 346 136 307 346 minecraft:stone
fill 94 287 339 94 308 339 minecraft:stone
fill 94 287 348 94 308 348 minecraft:stone
fill 94 287 353 94 308 353 minecraft:stone
fill 94 287 358 94 308 358 minecraft:stone
fill 94 287 363 94 308 363 minecraft:stone
setblock 95 287 323 minecraft:stripped_spruce_log
fill 95 287 324 95 290 324 minecraft:stone
setblock 95 287 327 minecraft:stone
setblock 95 287 363 minecraft:stripped_spruce_log
fill 96 287 323 99 287 323 minecraft:stone
fill 96 287 363 99 287 363 minecraft:stone
fill 98 287 338 98 287 348 minecraft:andesite
fill 99 287 335 99 287 337 minecraft:andesite
fill 99 287 338 103 287 348 minecraft:stone
fill 99 287 349 99 287 351 minecraft:andesite
setblock 100 287 323 minecraft:stripped_spruce_log
fill 100 287 324 100 290 324 minecraft:stone
fill 100 287 334 100 287 335 minecraft:andesite
fill 100 287 336 105 287 337 minecraft:stone
fill 100 287 349 106 287 350 minecraft:stone
fill 100 287 351 100 287 352 minecraft:andesite
setblock 100 287 362 minecraft:stone
setblock 100 287 363 minecraft:stripped_spruce_log
setblock 100 287 364 minecraft:diamond_block
fill 101 287 323 101 290 323 minecraft:stone
fill 101 287 332 101 287 333 minecraft:andesite
fill 101 287 334 105 287 335 minecraft:stone
fill 101 287 351 108 287 352 minecraft:stone
fill 101 287 353 101 287 354 minecraft:andesite
setblock 101 287 362 minecraft:stripped_spruce_log
fill 101 287 363 104 287 363 minecraft:stone
fill 102 287 331 102 287 332 minecraft:andesite
fill 102 287 333 109 287 333 minecraft:stone
fill 102 287 353 111 287 353 minecraft:stone
fill 102 287 354 102 287 355 minecraft:andesite
fill 102 287 362 102 290 362 minecraft:stone
fill 103 287 330 103 287 331 minecraft:andesite
fill 103 287 332 111 287 332 minecraft:stone
fill 103 287 354 127 287 354 minecraft:stone
fill 103 287 355 103 287 356 minecraft:andesite
setblock 104 287 323 minecraft:stone
setblock 104 287 324 minecraft:stripped_spruce_log
fill 104 287 329 104 287 330 minecraft:andesite
fill 104 287 331 126 287 331 minecraft:stone
fill 104 287 338 104 287 340 minecraft:stone
fill 104 287 341 104 287 344 minecraft:cobbled_deepslate
fill 104 287 345 104 287 348 minecraft:stone
fill 104 287 355 126 287 355 minecraft:stone
fill 104 287 356 104 287 357 minecraft:andesite
setblock 105 287 323 minecraft:stripped_spruce_log
fill 105 287 324 105 290 324 minecraft:stone
setblock 105 287 329 minecraft:andesite
fill 105 287 330 125 287 330 minecraft:stone
fill 105 287 338 105 287 340 minecraft:cobbled_deepslate
fill 105 287 345 105 287 347 minecraft:cobbled_deepslate
setblock 105 287 348 minecraft:stone
fill 105 287 356 125 287 356 minecraft:stone
setblock 105 287 357 minecraft:andesite
setblock 105 287 363 minecraft:stripped_spruce_log
fill 106 287 323 106 290 323 minecraft:stone
fill 106 287 328 107 287 328 minecraft:andesite
fill 106 287 329 110 287 329 minecraft:stone
fill 106 287 334 107 288 334 minecraft:stone
setblock 106 287 337 minecraft:cobbled_deepslate
setblock 106 287 348 minecraft:cobbled_deepslate
fill 106 287 357 110 287 357 minecraft:stone
fill 106 287 358 107 287 358 minecraft:andesite
setblock 106 287 362 minecraft:stripped_spruce_log
fill 106 287 363 106 290 363 minecraft:stone
fill 107 287 327 109 287 327 minecraft:andesite
setblock 107 287 335 minecraft:cobbled_deepslate
setblock 107 287 349 minecraft:cobbled_deepslate
setblock 107 287 350 minecraft:stone
fill 107 287 359 109 287 359 minecraft:andesite
fill 107 287 362 107 290 362 minecraft:stone
fill 108 287 328 110 287 328 minecraft:stone
fill 108 287 334 109 287 334 minecraft:cobbled_deepslate
setblock 108 287 350 minecraft:cobbled_deepslate
fill 108 287 358 110 287 358 minecraft:stone
setblock 109 287 323 minecraft:stone
setblock 109 287 351 minecraft:cobbled_deepslate
setblock 109 287 352 minecraft:stone
setblock 109 287 362 minecraft:stone
setblock 110 287 323 minecraft:stripped_spruce_log
fill 110 287 326 120 287 326 minecraft:andesite
fill 110 287 327 120 287 327 minecraft:stone
fill 110 287 333 111 287 333 minecraft:cobbled_deepslate
fill 110 287 352 112 287 352 minecraft:cobbled_deepslate
fill 110 287 359 120 287 359 minecraft:stone
fill 110 287 360 120 287 360 minecraft:andesite
setblock 110 287 363 minecraft:stripped_spruce_log
fill 111 287 323 111 290 323 minecraft:stone
fill 111 287 363 111 288 363 minecraft:stone
fill 112 287 332 113 287 332 minecraft:cobbled_deepslate
fill 112 287 353 117 287 353 minecraft:cobbled_deepslate
fill 112 287 364 112 308 364 minecraft:stone
fill 114 287 328 122 287 329 minecraft:stone
fill 114 287 357 122 287 358 minecraft:stone
fill 117 287 323 117 288 323 minecraft:raw_gold_block
fill 117 287 332 118 287 332 minecraft:cobbled_deepslate
fill 118 287 352 120 287 352 minecraft:cobbled_deepslate
fill 118 287 353 128 287 353 minecraft:stone
setblock 119 287 323 minecraft:stone
fill 119 287 332 127 287 332 minecraft:stone
fill 119 287 333 120 287 333 minecraft:cobbled_deepslate
setblock 120 287 323 minecraft:stripped_spruce_log
fill 120 287 351 121 287 351 minecraft:cobbled_deepslate
fill 121 287 323 123 287 324 minecraft:stone
fill 121 287 327 123 287 327 minecraft:andesite
fill 121 287 333 128 287 333 minecraft:stone
setblock 121 287 334 minecraft:cobbled_deepslate
fill 121 287 352 129 287 352 minecraft:stone
fill 121 287 359 123 287 359 minecraft:andesite
fill 122 287 334 129 287 334 minecraft:stone
setblock 122 287 335 minecraft:cobbled_deepslate
setblock 122 287 350 minecraft:cobbled_deepslate
fill 122 287 351 129 287 351 minecraft:stone
setblock 123 287 325 minecraft:stripped_spruce_log
fill 123 287 328 124 287 328 minecraft:andesite
fill 123 287 329 124 287 329 minecraft:stone
fill 123 287 335 129 287 335 minecraft:stone
setblock 123 287 336 minecraft:cobbled_deepslate
setblock 123 287 349 minecraft:cobbled_deepslate
fill 123 287 350 130 287 350 minecraft:stone
fill 123 287 357 124 287 357 minecraft:stone
fill 123 287 358 124 287 358 minecraft:andesite
setblock 124 287 323 minecraft:stone
setblock 124 287 324 minecraft:stripped_spruce_log
fill 124 287 325 127 287 325 minecraft:stone
fill 124 287 336 130 287 336 minecraft:stone
fill 124 287 337 124 287 338 minecraft:cobbled_deepslate
fill 124 287 347 124 287 348 minecraft:cobbled_deepslate
fill 124 287 349 130 287 349 minecraft:stone
setblock 125 287 323 minecraft:stripped_spruce_log
fill 125 287 324 128 287 324 minecraft:stone
fill 125 287 329 126 287 329 minecraft:andesite
fill 125 287 337 130 287 338 minecraft:stone
fill 125 287 339 125 287 346 minecraft:cobbled_deepslate
fill 125 287 347 131 287 348 minecraft:stone
fill 125 287 357 126 287 357 minecraft:andesite
setblock 125 287 363 minecraft:stripped_spruce_log
fill 125 287 364 125 308 364 minecraft:stone
fill 126 287 323 129 287 323 minecraft:stone
fill 126 287 330 127 287 330 minecraft:andesite
fill 126 287 339 131 287 346 minecraft:stone
fill 126 287 356 127 287 356 minecraft:andesite
fill 126 287 363 129 287 363 minecraft:stone
fill 127 287 331 128 287 331 minecraft:andesite
fill 127 287 355 128 287 355 minecraft:andesite
setblock 128 287 325 minecraft:stripped_spruce_log
fill 128 287 332 129 287 332 minecraft:andesite
fill 128 287 354 129 287 354 minecraft:andesite
setblock 129 287 324 minecraft:stripped_spruce_log
fill 129 287 325 129 290 325 minecraft:stone
setblock 129 287 333 minecraft:andesite
setblock 129 287 353 minecraft:andesite
setblock 130 287 323 minecraft:stripped_spruce_log
fill 130 287 324 130 290 324 minecraft:stone
fill 130 287 334 130 287 335 minecraft:andesite
fill 130 287 351 130 287 352 minecraft:andesite
setblock 130 287 363 minecraft:stripped_spruce_log
fill 131 287 323 131 290 323 minecraft:stone
fill 131 287 335 131 287 337 minecraft:andesite
setblock 131 287 338 minecraft:stone
fill 131 287 349 131 287 351 minecraft:andesite
fill 131 287 363 131 290 363 minecraft:stone
setblock 132 287 325 minecraft:stone
fill 132 287 338 132 287 348 minecraft:andesite
setblock 133 287 324 minecraft:stone
setblock 134 287 324 minecraft:stripped_spruce_log
fill 134 287 325 134 290 325 minecraft:stone
fill 134 287 327 134 288 327 minecraft:stone
setblock 135 287 323 minecraft:stripped_spruce_log
fill 135 287 324 135 290 324 minecraft:stone
setblock 135 287 328 minecraft:stripped_spruce_log
fill 135 287 329 135 290 329 minecraft:stone
setblock 136 287 360 minecraft:diamond_block
fill 95 288 323 98 288 323 minecraft:stone
setblock 95 288 327 minecraft:stripped_spruce_log
fill 95 288 328 95 291 328 minecraft:stone
setblock 95 288 362 minecraft:stripped_spruce_log
fill 95 288 363 98 288 363 minecraft:stone
setblock 97 288 324 minecraft:stone
setblock 98 288 324 minecraft:stripped_spruce_log
setblock 99 288 323 minecraft:stripped_spruce_log
fill 99 288 324 99 291 324 minecraft:stone
fill 99 288 338 99 288 348 minecraft:andesite
setblock 99 288 362 minecraft:stone
setblock 99 288 363 minecraft:stripped_spruce_log
fill 100 288 323 100 291 323 minecraft:stone
fill 100 288 336 100 288 340 minecraft:andesite
fill 100 288 341 103 288 345 minecraft:stone
fill 100 288 346 100 288 350 minecraft:andesite
setblock 100 288 362 minecraft:stripped_spruce_log
fill 100 288 363 100 291 364 minecraft:stone
fill 101 288 334 101 288 337 minecraft:andesite
fill 101 288 338 103 288 340 minecraft:stone
fill 101 288 346 103 288 348 minecraft:stone
fill 101 288 349 101 288 352 minecraft:andesite
fill 101 288 362 101 290 363 minecraft:stone
fill 102 288 333 102 288 335 minecraft:andesite
fill 102 288 336 104 288 337 minecraft:stone
fill 102 288 349 105 288 350 minecraft:stone
fill 102 288 351 102 288 353 minecraft:andesite
fill 102 288 363 103 288 363 minecraft:stone
setblock 103 288 323 minecraft:stone
setblock 103 288 324 minecraft:stripped_spruce_log
fill 103 288 332 103 288 333 minecraft:andesite
fill 103 288 334 105 288 335 minecraft:stone
fill 103 288 351 106 288 352 minecraft:stone
fill 103 288 353 103 288 354 minecraft:andesite
setblock 104 288 323 minecraft:stripped_spruce_log
fill 104 288 324 104 291 324 minecraft:stone
fill 104 288 331 104 288 332 minecraft:andesite
fill 104 288 333 108 288 333 minecraft:stone
setblock 104 288 338 minecraft:stone
fill 104 288 339 104 288 346 minecraft:spruce_planks
fill 104 288 347 104 288 348 minecraft:stone
fill 104 288 353 109 288 353 minecraft:stone
fill 104 288 354 104 288 355 minecraft:andesite
setblock 104 288 363 minecraft:stripped_spruce_log
fill 105 288 323 105 291 323 minecraft:stone
fill 105 288 330 105 288 331 minecraft:andesite
fill 105 288 332 109 288 332 minecraft:stone
setblock 105 288 336 minecraft:stone
fill 105 288 337 105 288 338 minecraft:spruce_planks
fill 105 288 347 105 288 348 minecraft:spruce_planks
fill 105 288 354 111 288 354 minecraft:stone
fill 105 288 355 105 288 356 minecraft:andesite
setblock 105 288 362 minecraft:stripped_spruce_log
fill 105 288 363 105 291 363 minecraft:stone
fill 106 288 329 107 288 330 minecraft:andesite
fill 106 288 331 112 288 331 minecraft:stone
setblock 106 288 335 minecraft:stone
setblock 106 288 336 minecraft:spruce_planks
fill 106 288 349 106 288 350 minecraft:spruce_planks
fill 106 288 355 124 288 355 minecraft:stone
fill 106 288 356 107 288 357 minecraft:andesite
fill 106 288 362 106 291 362 minecraft:stone
setblock 107 288 324 minecraft:stone
setblock 107 288 335 minecraft:spruce_planks
fill 107 288 350 107 288 351 minecraft:spruce_planks
setblock 107 288 352 minecraft:stone
setblock 108 288 324 minecraft:stripped_spruce_log
fill 108 288 328 109 288 329 minecraft:andesite
fill 108 288 330 122 288 330 minecraft:stone
setblock 108 288 334 minecraft:spruce_planks
fill 108 288 351 108 288 352 minecraft:spruce_planks
fill 108 288 356 122 288 356 minecraft:stone
fill 108 288 357 109 288 358 minecraft:andesite
setblock 109 288 323 minecraft:stripped_spruce_log
setblock 109 288 324 minecraft:stone
setblock 109 288 333 minecraft:spruce_planks
setblock 109 288 352 minecraft:spruce_planks
setblock 109 288 363 minecraft:stripped_spruce_log
fill 109 288 364 109 308 364 minecraft:stone
fill 110 288 323 110 291 323 minecraft:stone
fill 110 288 327 112 288 328 minecraft:andesite
fill 110 288 329 120 288 329 minecraft:stone
fill 110 288 332 112 288 332 minecraft:spruce_planks
fill 110 288 353 111 288 353 minecraft:spruce_planks
fill 110 288 357 120 288 357 minecraft:stone
fill 110 288 358 112 288 359 minecraft:andesite
fill 110 288 363 110 290 363 minecraft:stone
fill 112 288 354 118 288 354 minecraft:spruce_planks
fill 113 288 327 120 288 327 minecraft:andesite
fill 113 288 328 117 288 328 minecraft:stone
fill 113 288 331 116 288 331 minecraft:spruce_planks
fill 113 288 358 117 288 358 minecraft:stone
fill 113 288 359 120 288 359 minecraft:andesite
fill 116 288 323 116 289 325 minecraft:raw_gold_block
fill 116 288 332 116 300 332 minecraft:stripped_spruce_log
fill 117 288 324 117 289 326 minecraft:raw_gold_block
fill 117 288 331 124 288 331 minecraft:stone
fill 117 288 332 119 288 332 minecraft:spruce_planks
setblock 118 288 323 minecraft:stone
fill 118 288 324 118 289 325 minecraft:raw_gold_block
fill 118 288 328 122 288 328 minecraft:andesite
fill 118 288 353 120 288 353 minecraft:spruce_planks
fill 118 288 358 122 288 358 minecraft:andesite
setblock 119 288 323 minecraft:stripped_spruce_log
fill 119 288 354 125 288 354 minecraft:stone
fill 120 288 323 122 288 324 minecraft:stone
fill 120 288 332 125 288 332 minecraft:stone
fill 120 288 333 121 288 333 minecraft:spruce_planks
setblock 120 288 364 minecraft:gold_block
fill 121 288 329 124 288 329 minecraft:andesite
fill 121 288 352 122 288 352 minecraft:spruce_planks
fill 121 288 353 126 288 353 minecraft:stone
fill 121 288 357 124 288 357 minecraft:andesite
setblock 122 288 325 minecraft:stripped_spruce_log
fill 122 288 333 126 288 333 minecraft:stone
setblock 122 288 334 minecraft:spruce_planks
fill 122 288 351 123 288 351 minecraft:spruce_planks
fill 122 288 363 122 289 363 minecraft:stone
setblock 123 288 323 minecraft:stone
setblock 123 288 324 minecraft:stripped_spruce_log
fill 123 288 325 126 288 325 minecraft:stone
fill 123 288 330 125 288 330 minecraft:andesite
fill 123 288 334 127 288 334 minecraft:stone
setblock 123 288 335 minecraft:spruce_planks
fill 123 288 350 124 288 350 minecraft:spruce_planks
fill 123 288 352 127 288 352 minecraft:stone
fill 123 288 356 125 288 356 minecraft:andesite
setblock 124 288 323 minecraft:stripped_spruce_log
fill 124 288 324 127 288 324 minecraft:stone
fill 124 288 335 127 288 335 minecraft:stone
setblock 124 288 336 minecraft:spruce_planks
setblock 124 288 349 minecraft:spruce_planks
fill 124 288 351 127 288 351 minecraft:stone
setblock 124 288 363 minecraft:stripped_spruce_log
fill 125 288 323 128 288 323 minecraft:stone
setblock 125 288 326 minecraft:stone
fill 125 288 331 126 288 331 minecraft:andesite
fill 125 288 336 128 288 336 minecraft:stone
fill 125 288 337 125 288 338 minecraft:spruce_planks
fill 125 288 347 125 288 348 minecraft:spruce_planks
fill 125 288 349 128 288 350 minecraft:stone
fill 125 288 355 126 288 355 minecraft:andesite
fill 125 288 363 128 288 363 minecraft:stone
setblock 126 288 322 minecraft:gold_block
setblock 126 288 326 minecraft:stripped_spruce_log
fill 126 288 332 127 288 332 minecraft:andesite
fill 126 288 337 128 288 338 minecraft:stone
fill 126 288 339 126 288 346 minecraft:spruce_planks
fill 126 288 347 129 288 348 minecraft:stone
fill 126 288 354 127 288 354 minecraft:andesite
setblock 127 288 325 minecraft:stripped_spruce_log
fill 127 288 326 129 289 326 minecraft:stone
fill 127 288 333 128 288 333 minecraft:andesite
fill 127 288 339 129 288 346 minecraft:stone
fill 127 288 353 128 288 353 minecraft:andesite
setblock 128 288 324 minecraft:stripped_spruce_log
fill 128 288 325 128 291 325 minecraft:stone
fill 128 288 334 129 288 335 minecraft:andesite
fill 128 288 351 129 288 352 minecraft:andesite
setblock 129 288 323 minecraft:stripped_spruce_log
fill 129 288 324 129 291 324 minecraft:stone
fill 129 288 336 130 288 337 minecraft:andesite
setblock 129 288 338 minecraft:stone
fill 129 288 349 130 288 350 minecraft:andesite
setblock 129 288 363 minecraft:stripped_spruce_log
fill 130 288 323 130 291 323 minecraft:stone
fill 130 288 338 131 288 340 minecraft:andesite
fill 130 288 341 130 288 345 minecraft:stone
fill 130 288 346 131 288 348 minecraft:andesite
fill 130 288 363 130 291 363 minecraft:stone
fill 131 288 341 131 288 345 minecraft:andesite
setblock 132 288 325 minecraft:stripped_spruce_log
setblock 133 288 324 minecraft:stripped_spruce_log
setblock 134 288 323 minecraft:stripped_spruce_log
fill 134 288 324 134 291 324 minecraft:stone
setblock 134 288 328 minecraft:stripped_spruce_log
setblock 134 288 363 minecraft:stripped_spruce_log
fill 135 288 323 135 291 323 minecraft:stone
setblock 135 288 327 minecraft:stripped_spruce_log
fill 135 288 328 135 291 328 minecraft:stone
fill 135 288 330 135 289 330 minecraft:stone
fill 135 288 363 135 291 363 minecraft:stone
fill 136 288 360 136 292 360 minecraft:stone
fill 95 289 323 97 289 323 minecraft:stone
setblock 95 289 326 minecraft:stripped_spruce_log
fill 95 289 327 95 292 327 minecraft:stone
setblock 95 289 346 minecraft:stripped_spruce_log
fill 95 289 347 95 289 350 minecraft:stone
setblock 95 289 351 minecraft:stripped_spruce_log
setblock 95 289 361 minecraft:stripped_spruce_log
fill 95 289 362 95 291 363 minecraft:stone
setblock 96 289 324 minecraft:stone
fill 96 289 363 97 289 363 minecraft:stone
setblock 96 289 364 minecraft:diamond_block
setblock 97 289 324 minecraft:stripped_spruce_log
setblock 97 289 332 minecraft:light[level=12]
setblock 97 289 339 minecraft:light[level=12]
setblock 97 289 346 minecraft:light[level=12]
setblock 97 289 353 minecraft:light[level=12]
setblock 97 289 360 minecraft:light[level=12]
setblock 98 289 323 minecraft:stripped_spruce_log
fill 98 289 324 98 292 324 minecraft:stone
setblock 98 289 363 minecraft:stripped_spruce_log
fill 99 289 323 99 292 323 minecraft:stone
setblock 99 289 362 minecraft:stripped_spruce_log
fill 99 289 363 99 292 363 minecraft:stone
fill 100 289 341 102 289 345 minecraft:andesite
fill 100 289 362 100 292 362 minecraft:stone
setblock 101 289 324 minecraft:stone
fill 101 289 338 102 289 340 minecraft:andesite
fill 101 289 346 102 289 348 minecraft:andesite
setblock 102 289 324 minecraft:stripped_spruce_log
fill 102 289 336 103 289 337 minecraft:andesite
fill 102 289 349 104 289 350 minecraft:andesite
setblock 102 289 363 minecraft:stone
setblock 103 289 323 minecraft:stripped_spruce_log
fill 103 289 324 103 291 325 minecraft:stone
fill 103 289 334 105 289 335 minecraft:andesite
fill 103 289 338 103 289 339 minecraft:andesite
fill 103 289 340 103 289 346 minecraft:cobbled_deepslate
fill 103 289 347 103 289 348 minecraft:andesite
fill 103 289 351 105 289 352 minecraft:andesite
setblock 103 289 363 minecraft:stripped_spruce_log
fill 104 289 323 104 292 323 minecraft:stone
fill 104 289 325 105 289 325 minecraft:stone
setblock 104 289 332 minecraft:light[level=12]
fill 104 289 333 107 289 333 minecraft:andesite
setblock 104 289 336 minecraft:andesite
fill 104 289 337 104 289 339 minecraft:cobbled_deepslate
setblock 104 289 346 minecraft:light[level=12]
fill 104 289 347 104 289 348 minecraft:cobbled_deepslate
fill 104 289 353 107 289 353 minecraft:andesite
setblock 104 289 360 minecraft:light[level=12]
setblock 104 289 362 minecraft:stripped_spruce_log
fill 104 289 363 104 292 363 minecraft:stone
fill 105 289 332 108 289 332 minecraft:andesite
setblock 105 289 336 minecraft:cobbled_deepslate
fill 105 289 349 105 289 350 minecraft:cobbled_deepslate
fill 105 289 354 109 289 354 minecraft:andesite
fill 105 289 362 105 292 362 minecraft:stone
fill 106 289 331 110 289 331 minecraft:andesite
setblock 106 289 334 minecraft:andesite
setblock 106 289 335 minecraft:cobbled_deepslate
setblock 106 289 351 minecraft:cobbled_deepslate
setblock 106 289 352 minecraft:andesite
fill 106 289 355 111 289 355 minecraft:andesite
setblock 107 289 324 minecraft:stripped_spruce_log
setblock 107 289 334 minecraft:cobbled_deepslate
setblock 107 289 352 minecraft:cobbled_deepslate
setblock 108 289 323 minecraft:stripped_spruce_log
fill 108 289 324 108 291 324 minecraft:stone
fill 108 289 330 122 289 330 minecraft:andesite
setblock 108 289 333 minecraft:cobbled_deepslate
fill 108 289 353 109 289 353 minecraft:cobbled_deepslate
fill 108 289 356 122 289 356 minecraft:andesite
setblock 108 289 363 minecraft:stripped_spruce_log
fill 109 289 323 109 292 323 minecraft:stone
fill 109 289 332 110 289 332 minecraft:cobbled_deepslate
fill 109 289 363 109 291 363 minecraft:stone
fill 110 289 329 120 289 329 minecraft:andesite
fill 110 289 354 111 289 354 minecraft:cobbled_deepslate
fill 110 289 357 120 289 357 minecraft:andesite
setblock 111 289 325 minecraft:light[level=12]
fill 111 289 331 119 289 331 minecraft:cobbled_deepslate
setblock 111 289 332 minecraft:light[level=12]
setblock 111 289 339 minecraft:light[level=12]
setblock 111 289 346 minecraft:light[level=12]
setblock 111 289 353 minecraft:light[level=12]
setblock 111 289 360 minecraft:light[level=12]
fill 112 289 355 118 289 355 minecraft:cobbled_deepslate
fill 113 289 328 117 289 328 minecraft:andesite
fill 113 289 358 117 289 358 minecraft:andesite
setblock 117 289 323 minecraft:stone
setblock 117 289 327 minecraft:raw_gold_block
fill 117 289 332 117 300 332 minecraft:stripped_spruce_log
setblock 118 289 323 minecraft:stripped_spruce_log
setblock 118 289 332 minecraft:light[level=12]
setblock 118 289 339 minecraft:light[level=12]
setblock 118 289 346 minecraft:light[level=12]
setblock 118 289 353 minecraft:light[level=12]
setblock 118 289 360 minecraft:light[level=12]
fill 119 289 323 121 289 324 minecraft:stone
fill 119 289 354 120 289 354 minecraft:cobbled_deepslate
fill 119 289 355 124 289 355 minecraft:andesite
fill 120 289 331 124 289 331 minecraft:andesite
fill 120 289 332 121 289 332 minecraft:cobbled_deepslate
fill 120 289 364 120 308 364 minecraft:stone
setblock 121 289 325 minecraft:stripped_spruce_log
fill 121 289 353 122 289 353 minecraft:cobbled_deepslate
fill 121 289 354 125 289 354 minecraft:andesite
fill 121 289 363 121 290 363 minecraft:stone
setblock 122 289 323 minecraft:stone
setblock 122 289 324 minecraft:stripped_spruce_log
fill 122 289 325 125 289 325 minecraft:stone
fill 122 289 332 125 289 332 minecraft:andesite
setblock 122 289 333 minecraft:cobbled_deepslate
setblock 122 289 364 minecraft:gold_block
setblock 123 289 323 minecraft:stripped_spruce_log
fill 123 289 324 126 289 324 minecraft:stone
fill 123 289 326 124 289 326 minecraft:stone
fill 123 289 333 126 289 333 minecraft:andesite
setblock 123 289 334 minecraft:cobbled_deepslate
setblock 123 289 352 minecraft:cobbled_deepslate
fill 123 289 353 126 289 353 minecraft:andesite
setblock 123 289 363 minecraft:stripped_spruce_log
fill 124 289 323 127 289 323 minecraft:stone
fill 124 289 327 124 289 329 minecraft:raw_gold_block
fill 124 289 334 127 289 334 minecraft:andesite
setblock 124 289 335 minecraft:cobbled_deepslate
setblock 124 289 351 minecraft:cobbled_deepslate
fill 124 289 352 127 289 352 minecraft:andesite
fill 124 289 363 127 289 363 minecraft:stone
setblock 125 289 326 minecraft:stripped_spruce_log
fill 125 289 335 127 289 335 minecraft:andesite
fill 125 289 336 125 289 337 minecraft:cobbled_deepslate
setblock 125 289 339 minecraft:light[level=12]
setblock 125 289 346 minecraft:light[level=12]
fill 125 289 349 125 289 350 minecraft:cobbled_deepslate
fill 125 289 351 127 289 351 minecraft:andesite
setblock 125 289 360 minecraft:light[level=12]
fill 126 289 322 126 308 322 minecraft:stone
setblock 126 289 325 minecraft:stripped_spruce_log
fill 126 289 326 126 292 326 minecraft:stone
fill 126 289 336 128 289 337 minecraft:andesite
fill 126 289 338 126 289 339 minecraft:cobbled_deepslate
fill 126 289 347 126 289 348 minecraft:cobbled_deepslate
fill 126 289 349 128 289 350 minecraft:andesite
setblock 127 289 322 minecraft:diamond_block
setblock 127 289 324 minecraft:stripped_spruce_log
fill 127 289 325 127 292 325 minecraft:stone
fill 127 289 338 129 289 339 minecraft:andesite
fill 127 289 340 127 289 346 minecraft:cobbled_deepslate
fill 127 289 347 129 289 348 minecraft:andesite
setblock 128 289 323 minecraft:stripped_spruce_log
fill 128 289 324 128 292 324 minecraft:stone
fill 128 289 340 129 289 346 minecraft:andesite
setblock 128 289 363 minecraft:stripped_spruce_log
fill 129 289 323 129 292 323 minecraft:stone
fill 129 289 363 129 292 363 minecraft:stone
fill 130 289 341 130 289 345 minecraft:andesite
setblock 131 289 325 minecraft:stripped_spruce_log
setblock 132 289 324 minecraft:stripped_spruce_log
fill 132 289 325 133 291 325 minecraft:stone
setblock 132 289 332 minecraft:light[level=12]
setblock 132 289 339 minecraft:light[level=12]
setblock 132 289 346 minecraft:light[level=12]
setblock 132 289 353 minecraft:light[level=12]
setblock 132 289 360 minecraft:light[level=12]
setblock 133 289 322 minecraft:diamond_block
setblock 133 289 323 minecraft:stripped_spruce_log
fill 133 289 324 133 292 324 minecraft:stone
fill 133 289 326 133 290 326 minecraft:stone
setblock 133 289 363 minecraft:stripped_spruce_log
fill 134 289 322 135 289 322 minecraft:gold_block
fill 134 289 323 134 292 323 minecraft:stone
setblock 134 289 327 minecraft:stripped_spruce_log
fill 134 289 328 134 291 329 minecraft:stone
fill 134 289 363 134 291 363 minecraft:stone
setblock 135 289 326 minecraft:stripped_spruce_log
fill 135 289 327 135 292 327 minecraft:stone
setblock 135 289 331 minecraft:stripped_spruce_log
setblock 136 289 339 minecraft:diamond_block
setblock 94 290 354 minecraft:diamond_block
fill 95 290 323 96 290 323 minecraft:stone
setblock 95 290 325 minecraft:stripped_spruce_log
fill 95 290 326 96 292 326 minecraft:stone
setblock 95 290 329 minecraft:stone
setblock 95 290 345 minecraft:stripped_spruce_log
fill 95 290 346 95 290 349 minecraft:stone
setblock 95 290 350 minecraft:stripped_spruce_log
fill 95 290 351 95 290 354 minecraft:stone
fill 95 290 361 95 293 361 minecraft:stone
setblock 96 290 324 minecraft:stripped_spruce_log
fill 96 290 325 96 293 325 minecraft:stone
setblock 96 290 349 minecraft:stripped_spruce_log
fill 96 290 363 96 290 364 minecraft:stone
setblock 97 290 323 minecraft:stripped_spruce_log
fill 97 290 324 97 293 324 minecraft:stone
fill 97 290 325 99 300 326 minecraft:stripped_spruce_log
setblock 97 290 363 minecraft:stripped_spruce_log
fill 98 290 323 98 293 323 minecraft:stone
setblock 98 290 362 minecraft:stripped_spruce_log
fill 98 290 363 98 293 363 minecraft:stone
fill 99 290 362 99 293 362 minecraft:stone
setblock 101 290 324 minecraft:stripped_spruce_log
fill 101 290 325 102 292 325 minecraft:stone
setblock 102 290 323 minecraft:stripped_spruce_log
fill 102 290 324 102 293 324 minecraft:stone
setblock 102 290 363 minecraft:stripped_spruce_log
fill 103 290 323 103 293 323 minecraft:stone
setblock 103 290 362 minecraft:stripped_spruce_log
fill 103 290 363 103 293 363 minecraft:stone
setblock 104 290 325 minecraft:stone
fill 104 290 362 104 293 362 minecraft:stone
setblock 105 290 325 minecraft:stripped_spruce_log
setblock 106 290 324 minecraft:stripped_spruce_log
setblock 107 290 323 minecraft:stripped_spruce_log
fill 107 290 324 107 292 324 minecraft:stone
setblock 107 290 363 minecraft:stripped_spruce_log
fill 108 290 323 108 292 323 minecraft:stone
fill 108 290 363 108 292 363 minecraft:stone
fill 115 290 330 117 300 331 minecraft:stripped_spruce_log
fill 116 290 329 117 300 329 minecraft:stripped_spruce_log
setblock 117 290 323 minecraft:stripped_spruce_log
fill 118 290 323 121 290 323 minecraft:stone
fill 118 290 331 118 300 331 minecraft:stripped_spruce_log
fill 119 290 324 120 290 324 minecraft:stone
setblock 120 290 325 minecraft:stripped_spruce_log
setblock 121 290 324 minecraft:stripped_spruce_log
fill 121 290 325 124 290 325 minecraft:stone
setblock 122 290 323 minecraft:stripped_spruce_log
fill 122 290 324 125 290 324 minecraft:stone
fill 122 290 326 123 290 326 minecraft:stone
setblock 122 290 363 minecraft:stripped_spruce_log
fill 122 290 364 122 308 364 minecraft:stone
fill 123 290 323 126 290 323 minecraft:stone
fill 123 290 327 125 290 327 minecraft:raw_gold_block
fill 123 290 363 126 290 363 minecraft:stone
setblock 124 290 326 minecraft:stripped_spruce_log
setblock 124 290 328 minecraft:raw_gold_block
setblock 125 290 325 minecraft:stripped_spruce_log
fill 125 290 326 125 293 326 minecraft:stone
setblock 126 290 324 minecraft:stripped_spruce_log
fill 126 290 325 126 293 325 minecraft:stone
fill 127 290 322 127 299 322 minecraft:stone
setblock 127 290 323 minecraft:stripped_spruce_log
fill 127 290 324 127 293 324 minecraft:stone
fill 127 290 326 128 290 326 minecraft:stone
setblock 127 290 363 minecraft:stripped_spruce_log
setblock 128 290 322 minecraft:raw_iron_block
fill 128 290 323 128 293 323 minecraft:stone
fill 128 290 363 128 293 363 minecraft:stone
setblock 129 290 326 minecraft:stripped_spruce_log
setblock 130 290 325 minecraft:stripped_spruce_log
setblock 131 290 324 minecraft:stripped_spruce_log
fill 131 290 325 131 292 325 minecraft:stone
setblock 132 290 323 minecraft:stripped_spruce_log
fill 132 290 324 132 293 324 minecraft:stone
setblock 132 290 363 minecraft:stripped_spruce_log
fill 133 290 322 133 292 323 minecraft:stone
setblock 133 290 327 minecraft:stripped_spruce_log
setblock 133 290 363 minecraft:stone
fill 134 290 322 135 291 322 minecraft:stone
setblock 134 290 326 minecraft:stripped_spruce_log
fill 134 290 327 134 293 327 minecraft:stone
setblock 134 290 330 minecraft:stone
setblock 135 290 325 minecraft:stripped_spruce_log
fill 135 290 326 135 293 326 minecraft:stone
setblock 135 290 330 minecraft:stripped_spruce_log
fill 135 290 331 135 292 332 minecraft:stone
fill 136 290 339 136 308 339 minecraft:stone
setblock 136 290 341 minecraft:diamond_block
fill 136 290 342 136 308 342 minecraft:stone
fill 94 291 342 94 295 342 minecraft:stone
setblock 94 291 343 minecraft:diamond_block
fill 94 291 354 94 294 354 minecraft:stone
setblock 95 291 323 minecraft:stone
setblock 95 291 324 minecraft:stripped_spruce_log
fill 95 291 325 95 294 325 minecraft:stone
setblock 95 291 329 minecraft:stripped_spruce_log
fill 95 291 330 95 294 330 minecraft:stone
fill 95 291 345 95 291 348 minecraft:stone
setblock 95 291 349 minecraft:stripped_spruce_log
fill 95 291 350 95 291 353 minecraft:stone
setblock 95 291 354 minecraft:stripped_spruce_log
fill 95 291 355 95 291 358 minecraft:stone
setblock 95 291 359 minecraft:stripped_spruce_log
fill 95 291 360 95 294 360 minecraft:stone
setblock 96 291 323 minecraft:stripped_spruce_log
setblock 96 291 324 minecraft:stone
setblock 96 291 327 minecraft:stone
setblock 96 291 347 minecraft:stone
setblock 96 291 348 minecraft:stripped_spruce_log
fill 96 291 349 96 291 352 minecraft:stone
setblock 96 291 353 minecraft:stripped_spruce_log
setblock 96 291 363 minecraft:stripped_spruce_log
fill 96 291 364 96 300 364 minecraft:stone
fill 97 291 323 97 294 323 minecraft:stone
fill 97 291 327 99 300 327 minecraft:stripped_spruce_log
setblock 97 291 333 minecraft:light[level=15]
setblock 97 291 341 minecraft:light[level=15]
setblock 97 291 349 minecraft:light[level=15]
fill 97 291 350 105 291 351 minecraft:stripped_spruce_log
setblock 97 291 357 minecraft:light[level=15]
fill 97 291 363 97 294 363 minecraft:stone
fill 98 291 362 98 294 362 minecraft:stone
setblock 100 291 324 minecraft:stripped_spruce_log
setblock 100 291 325 minecraft:stone
setblock 101 291 323 minecraft:stripped_spruce_log
fill 101 291 324 101 294 324 minecraft:stone
setblock 101 291 362 minecraft:stone
setblock 101 291 363 minecraft:stripped_spruce_log
fill 102 291 323 102 294 323 minecraft:stone
setblock 102 291 362 minecraft:stripped_spruce_log
fill 102 291 363 102 294 363 minecraft:stone
fill 103 291 362 103 294 362 minecraft:stone
setblock 104 291 325 minecraft:stripped_spruce_log
setblock 105 291 324 minecraft:stripped_spruce_log
setblock 105 291 325 minecraft:stone
setblock 105 291 333 minecraft:light[level=15]
setblock 105 291 341 minecraft:light[level=15]
setblock 105 291 349 minecraft:light[level=15]
setblock 105 291 357 minecraft:light[level=15]
setblock 106 291 323 minecraft:stripped_spruce_log
fill 106 291 324 106 292 324 minecraft:stone
fill 106 291 351 113 292 351 minecraft:stripped_spruce_log
setblock 106 291 363 minecraft:stripped_spruce_log
fill 107 291 323 107 293 323 minecraft:stone
fill 107 291 363 107 293 363 minecraft:stone
setblock 113 291 325 minecraft:light[level=15]
setblock 113 291 333 minecraft:light[level=15]
setblock 113 291 341 minecraft:light[level=15]
setblock 113 291 349 minecraft:light[level=15]
setblock 113 291 357 minecraft:light[level=15]
setblock 116 291 323 minecraft:stripped_spruce_log
fill 117 291 323 120 291 323 minecraft:stone
fill 118 291 324 119 291 324 minecraft:stone
setblock 119 291 325 minecraft:stripped_spruce_log
setblock 120 291 324 minecraft:stripped_spruce_log
fill 120 291 325 123 291 325 minecraft:stone
setblock 121 291 323 minecraft:stripped_spruce_log
fill 121 291 324 124 291 324 minecraft:stone
fill 121 291 326 122 291 326 minecraft:stone
setblock 121 291 333 minecraft:light[level=15]
setblock 121 291 341 minecraft:light[level=15]
setblock 121 291 349 minecraft:light[level=15]
setblock 121 291 357 minecraft:light[level=15]
setblock 121 291 363 minecraft:stripped_spruce_log
fill 122 291 323 125 291 323 minecraft:stone
fill 122 291 363 125 291 363 minecraft:stone
setblock 123 291 326 minecraft:stripped_spruce_log
setblock 124 291 325 minecraft:stripped_spruce_log
fill 124 291 326 124 293 327 minecraft:stone
setblock 125 291 324 minecraft:stripped_spruce_log
fill 125 291 325 125 294 325 minecraft:stone
fill 125 291 327 126 291 327 minecraft:stone
setblock 126 291 323 minecraft:stripped_spruce_log
fill 126 291 324 126 294 324 minecraft:stone
setblock 126 291 363 minecraft:stripped_spruce_log
fill 127 291 323 127 294 323 minecraft:stone
setblock 127 291 326 minecraft:stone
fill 127 291 363 127 293 363 minecraft:stone
setblock 128 291 322 minecraft:gold_block
setblock 128 291 326 minecraft:stripped_spruce_log
setblock 129 291 325 minecraft:stripped_spruce_log
fill 129 291 326 129 292 326 minecraft:stone
setblock 129 291 333 minecraft:light[level=15]
setblock 129 291 341 minecraft:light[level=15]
setblock 129 291 349 minecraft:light[level=15]
setblock 129 291 357 minecraft:light[level=15]
setblock 130 291 324 minecraft:stripped_spruce_log
fill 130 291 325 130 293 325 minecraft:stone
setblock 131 291 323 minecraft:stripped_spruce_log
fill 131 291 324 131 294 324 minecraft:stone
setblock 131 291 363 minecraft:stripped_spruce_log
fill 132 291 323 132 294 323 minecraft:stone
setblock 133 291 326 minecraft:stripped_spruce_log
fill 133 291 327 133 292 328 minecraft:stone
setblock 134 291 325 minecraft:stripped_spruce_log
fill 134 291 326 134 294 326 minecraft:stone
setblock 134 291 330 minecraft:stripped_spruce_log
setblock 135 291 324 minecraft:stripped_spruce_log
fill 135 291 325 135 294 325 minecraft:stone
setblock 135 291 329 minecraft:stripped_spruce_log
fill 135 291 330 135 294 330 minecraft:stone
setblock 135 291 348 minecraft:stone
setblock 135 291 349 minecraft:stripped_spruce_log
fill 135 291 350 135 294 350 minecraft:stone
fill 136 291 341 136 293 341 minecraft:stone
fill 136 291 353 136 294 353 minecraft:stone
setblock 136 291 354 minecraft:diamond_block
fill 94 292 343 94 308 343 minecraft:stone
setblock 94 292 351 minecraft:diamond_block
fill 94 292 364 94 308 364 minecraft:stone
setblock 95 292 323 minecraft:stripped_spruce_log
fill 95 292 324 95 295 324 minecraft:stone
setblock 95 292 328 minecraft:stripped_spruce_log
fill 95 292 329 95 295 329 minecraft:stone
fill 95 292 331 95 293 331 minecraft:stone
fill 95 292 345 95 292 347 minecraft:stone
setblock 95 292 348 minecraft:stripped_spruce_log
fill 95 292 349 95 292 352 minecraft:stone
setblock 95 292 353 minecraft:stripped_spruce_log
fill 95 292 354 95 292 357 minecraft:stone
setblock 95 292 358 minecraft:stripped_spruce_log
fill 95 292 359 95 295 359 minecraft:stone
setblock 95 292 362 minecraft:stone
setblock 95 292 363 minecraft:stripped_spruce_log
setblock 95 292 364 minecraft:raw_gold_block
fill 96 292 323 96 295 323 minecraft:stone
fill 96 292 324 96 295 324 minecraft:spruce_log
setblock 96 292 327 minecraft:stripped_spruce_log
fill 96 292 328 96 294 328 minecraft:stone
fill 96 292 343 96 295 343 minecraft:spruce_log
setblock 96 292 347 minecraft:stripped_spruce_log
fill 96 292 348 96 292 351 minecraft:stone
setblock 96 292 352 minecraft:stripped_spruce_log
fill 96 292 353 96 293 355 minecraft:stone
fill 96 292 362 96 295 362 minecraft:spruce_log
fill 96 292 363 96 295 363 minecraft:stone
fill 97 292 349 97 292 350 minecraft:stone
fill 97 292 351 105 292 351 minecraft:stripped_spruce_log
fill 97 292 352 97 294 353 minecraft:stone
fill 98 292 350 129 292 350 minecraft:stripped_spruce_log
setblock 99 292 324 minecraft:stripped_spruce_log
setblock 100 292 323 minecraft:stripped_spruce_log
fill 100 292 324 100 294 324 minecraft:stone
setblock 100 292 363 minecraft:stripped_spruce_log
fill 100 292 364 100 308 364 minecraft:stone
fill 101 292 323 101 295 323 minecraft:stone
setblock 101 292 362 minecraft:stripped_spruce_log
fill 101 292 363 101 295 363 minecraft:stone
fill 102 292 362 102 295 362 minecraft:stone
setblock 103 292 324 minecraft:stone
setblock 103 292 325 minecraft:stripped_spruce_log
setblock 104 292 324 minecraft:stripped_spruce_log
setblock 104 292 325 minecraft:stone
setblock 105 292 323 minecraft:stripped_spruce_log
fill 105 292 324 105 293 324 minecraft:stone
setblock 105 292 363 minecraft:stripped_spruce_log
setblock 106 292 322 minecraft:raw_gold_block
fill 106 292 323 106 294 323 minecraft:stone
fill 106 292 363 106 294 363 minecraft:stone
fill 114 292 351 134 292 351 minecraft:stripped_spruce_log
fill 115 292 324 115 295 324 minecraft:spruce_log
fill 115 292 362 115 295 362 minecraft:spruce_log
fill 116 292 323 119 292 323 minecraft:stone
setblock 118 292 324 minecraft:stone
setblock 119 292 324 minecraft:stripped_spruce_log
fill 119 292 325 122 292 325 minecraft:stone
setblock 120 292 323 minecraft:stripped_spruce_log
fill 120 292 324 123 292 324 minecraft:stone
fill 121 292 323 124 292 323 minecraft:stone
setblock 121 292 326 minecraft:stone
fill 121 292 363 124 292 363 minecraft:stone
setblock 122 292 326 minecraft:stripped_spruce_log
setblock 123 292 325 minecraft:stripped_spruce_log
fill 123 292 326 123 293 327 minecraft:stone
setblock 124 292 324 minecraft:stripped_spruce_log
fill 124 292 325 124 295 325 minecraft:stone
setblock 125 292 323 minecraft:stripped_spruce_log
fill 125 292 324 125 295 324 minecraft:stone
setblock 125 292 327 minecraft:stone
setblock 125 292 363 minecraft:stripped_spruce_log
fill 126 292 323 126 295 323 minecraft:stone
fill 126 292 363 126 294 363 minecraft:stone
setblock 127 292 326 minecraft:stripped_spruce_log
fill 128 292 322 128 306 322 minecraft:stone
setblock 128 292 325 minecraft:stripped_spruce_log
setblock 128 292 326 minecraft:stone
setblock 129 292 324 minecraft:stripped_spruce_log
fill 129 292 325 129 293 325 minecraft:stone
setblock 130 292 323 minecraft:stripped_spruce_log
fill 130 292 324 130 294 324 minecraft:stone
fill 131 292 323 131 295 323 minecraft:stone
setblock 132 292 325 minecraft:stone
setblock 133 292 326 minecraft:stone
setblock 134 292 322 minecraft:raw_gold_block
fill 134 292 324 134 295 324 minecraft:spruce_log
fill 134 292 325 134 295 325 minecraft:stone
setblock 134 292 328 minecraft:stone
setblock 134 292 329 minecraft:stripped_spruce_log
fill 134 292 330 134 294 331 minecraft:stone
fill 134 292 343 134 295 343 minecraft:spruce_log
fill 134 292 362 134 295 362 minecraft:spruce_log
setblock 135 292 322 minecraft:stone
setblock 135 292 323 minecraft:stripped_spruce_log
fill 135 292 324 135 295 324 minecraft:stone
setblock 135 292 328 minecraft:stripped_spruce_log
fill 135 292 329 135 295 329 minecraft:stone
setblock 135 292 333 minecraft:stripped_spruce_log
setblock 135 292 347 minecraft:stone
setblock 135 292 348 minecraft:stripped_spruce_log
fill 135 292 349 135 295 349 minecraft:stone
fill 135 292 351 135 292 352 minecraft:stone
setblock 135 292 353 minecraft:stripped_spruce_log
setblock 135 292 363 minecraft:stripped_spruce_log
fill 136 292 354 136 307 354 minecraft:stone
fill 94 293 351 95 293 351 minecraft:stone
fill 95 293 323 95 294 323 minecraft:stone
setblock 95 293 326 minecraft:stone
setblock 95 293 327 minecraft:stripped_spruce_log
fill 95 293 328 95 296 328 minecraft:stone
fill 95 293 345 95 293 346 minecraft:stone
setblock 95 293 347 minecraft:stripped_spruce_log
fill 95 293 348 96 293 350 minecraft:stone
setblock 95 293 352 minecraft:stripped_spruce_log
fill 95 293 353 95 293 356 minecraft:stone
setblock 95 293 357 minecraft:stripped_spruce_log
fill 95 293 358 95 296 358 minecraft:stone
setblock 95 293 362 minecraft:stripped_spruce_log
fill 95 293 363 95 296 364 minecraft:stone
fill 96 293 326 96 297 326 minecraft:stripped_spruce_log
setblock 96 293 327 minecraft:stone
fill 96 293 347 96 295 347 minecraft:stone
setblock 96 293 351 minecraft:stripped_spruce_log
fill 96 293 352 96 296 352 minecraft:stone
setblock 96 293 356 minecraft:stripped_spruce_log
fill 96 293 357 96 296 357 minecraft:stone
fill 97 293 348 97 293 349 minecraft:stone
setblock 97 293 350 minecraft:stripped_spruce_log
fill 97 293 351 98 295 351 minecraft:stone
setblock 97 293 354 minecraft:stone
setblock 98 293 324 minecraft:stripped_spruce_log
setblock 99 293 323 minecraft:stripped_spruce_log
fill 99 293 324 99 294 324 minecraft:stone
fill 99 293 351 115 293 351 minecraft:stripped_dark_oak_log
setblock 99 293 363 minecraft:stripped_spruce_log
fill 100 293 323 100 296 323 minecraft:stone
setblock 100 293 362 minecraft:stripped_spruce_log
fill 100 293 363 100 296 363 minecraft:stone
fill 101 293 362 101 295 362 minecraft:stone
setblock 103 293 324 minecraft:stripped_spruce_log
setblock 104 293 323 minecraft:stripped_spruce_log
setblock 104 293 324 minecraft:stone
setblock 104 293 363 minecraft:stripped_spruce_log
fill 105 293 323 105 294 323 minecraft:stone
fill 105 293 363 105 294 363 minecraft:stone
fill 106 293 322 106 308 322 minecraft:stone
setblock 111 293 364 minecraft:gold_block
fill 116 293 323 118 293 323 minecraft:stone
fill 116 293 351 134 293 351 minecraft:stripped_spruce_log
setblock 118 293 324 minecraft:stripped_spruce_log
setblock 119 293 323 minecraft:stripped_spruce_log
fill 119 293 324 121 293 325 minecraft:stone
fill 120 293 323 123 293 323 minecraft:stone
setblock 120 293 326 minecraft:stone
setblock 121 293 326 minecraft:stripped_spruce_log
fill 121 293 363 123 293 363 minecraft:stone
setblock 122 293 324 minecraft:stone
setblock 122 293 325 minecraft:stripped_spruce_log
fill 122 293 326 122 295 326 minecraft:stone
setblock 123 293 324 minecraft:stripped_spruce_log
fill 123 293 325 123 296 325 minecraft:stone
setblock 124 293 323 minecraft:stripped_spruce_log
fill 124 293 324 124 296 324 minecraft:stone
setblock 124 293 363 minecraft:stripped_spruce_log
fill 125 293 323 125 296 323 minecraft:stone
fill 125 293 363 125 294 363 minecraft:stone
setblock 126 293 326 minecraft:stripped_spruce_log
setblock 127 293 325 minecraft:stripped_spruce_log
setblock 127 293 326 minecraft:stone
setblock 128 293 324 minecraft:stripped_spruce_log
fill 128 293 325 128 294 325 minecraft:stone
setblock 129 293 323 minecraft:stripped_spruce_log
fill 129 293 324 129 295 324 minecraft:stone
fill 130 293 323 130 295 323 minecraft:stone
setblock 133 293 322 minecraft:raw_gold_block
setblock 133 293 323 minecraft:stone
setblock 133 293 324 minecraft:stripped_spruce_log
fill 134 293 322 134 308 322 minecraft:stone
setblock 134 293 323 minecraft:stripped_spruce_log
setblock 134 293 328 minecraft:stripped_spruce_log
fill 134 293 329 134 296 329 minecraft:stone
setblock 135 293 322 minecraft:raw_gold_block
fill 135 293 323 135 296 323 minecraft:stone
setblock 135 293 327 minecraft:stripped_spruce_log
fill 135 293 328 135 296 328 minecraft:stone
setblock 135 293 331 minecraft:stone
setblock 135 293 332 minecraft:stripped_spruce_log
fill 135 293 333 135 296 333 minecraft:stone
fill 135 293 348 135 294 348 minecraft:stone
setblock 135 293 351 minecraft:stone
setblock 135 293 352 minecraft:stripped_spruce_log
fill 135 293 353 135 295 354 minecraft:stone
fill 135 293 363 135 294 363 minecraft:stone
setblock 136 293 360 minecraft:raw_iron_block
fill 94 294 351 94 308 351 minecraft:stone
setblock 95 294 326 minecraft:stripped_spruce_log
fill 95 294 327 95 296 327 minecraft:stone
setblock 95 294 331 minecraft:stripped_spruce_log
fill 95 294 332 95 297 332 minecraft:stone
setblock 95 294 346 minecraft:stripped_spruce_log
fill 95 294 347 95 294 350 minecraft:stone
setblock 95 294 351 minecraft:stripped_spruce_log
fill 95 294 352 95 294 355 minecraft:stone
setblock 95 294 356 minecraft:stripped_spruce_log
fill 95 294 357 95 297 357 minecraft:stone
setblock 95 294 361 minecraft:stripped_spruce_log
fill 95 294 362 95 297 362 minecraft:stone
fill 96 294 325 96 297 325 minecraft:stripped_spruce_log
fill 96 294 327 96 297 327 minecraft:stripped_spruce_log
fill 96 294 348 96 294 349 minecraft:stone
setblock 96 294 350 minecraft:stripped_spruce_log
fill 96 294 351 96 297 351 minecraft:stone
fill 96 294 353 96 294 354 minecraft:stone
setblock 96 294 355 minecraft:stripped_spruce_log
fill 96 294 356 97 296 356 minecraft:stone
fill 96 294 358 96 295 358 minecraft:stone
fill 97 294 324 97 297 324 minecraft:stripped_spruce_log
setblock 97 294 348 minecraft:stone
setblock 97 294 349 minecraft:stripped_spruce_log
fill 97 294 350 98 295 350 minecraft:stone
setblock 97 294 354 minecraft:stripped_spruce_log
fill 97 294 355 97 297 355 minecraft:stone
setblock 98 294 323 minecraft:stripped_spruce_log
setblock 98 294 324 minecraft:stone
setblock 98 294 352 minecraft:stone
setblock 98 294 353 minecraft:stripped_spruce_log
setblock 98 294 363 minecraft:stripped_spruce_log
fill 99 294 323 99 296 323 minecraft:stone
setblock 99 294 362 minecraft:stripped_spruce_log
fill 99 294 363 99 297 363 minecraft:stone
fill 100 294 362 100 295 362 minecraft:stone
setblock 102 294 324 minecraft:stripped_spruce_log
setblock 103 294 323 minecraft:stripped_spruce_log
setblock 103 294 324 minecraft:stone
setblock 103 294 363 minecraft:stripped_spruce_log
setblock 104 294 322 minecraft:raw_gold_block
fill 104 294 323 104 295 323 minecraft:stone
fill 104 294 363 104 295 363 minecraft:stone
fill 111 294 364 111 308 364 minecraft:stone
setblock 117 294 323 minecraft:stone
setblock 118 294 323 minecraft:stripped_spruce_log
fill 118 294 324 121 294 324 minecraft:stone
fill 119 294 323 122 294 323 minecraft:stone
fill 119 294 325 120 294 325 minecraft:stone
fill 119 294 351 134 294 351 minecraft:stripped_dark_oak_log
setblock 121 294 325 minecraft:stripped_spruce_log
setblock 121 294 326 minecraft:stone
fill 121 294 363 122 294 363 minecraft:stone
setblock 122 294 324 minecraft:stripped_spruce_log
fill 122 294 325 122 296 325 minecraft:stone
setblock 123 294 323 minecraft:stripped_spruce_log
fill 123 294 324 123 297 324 minecraft:stone
fill 123 294 326 124 294 326 minecraft:stone
setblock 123 294 363 minecraft:stripped_spruce_log
fill 124 294 323 124 297 323 minecraft:stone
setblock 124 294 363 minecraft:stone
setblock 125 294 326 minecraft:stripped_spruce_log
setblock 126 294 325 minecraft:stripped_spruce_log
setblock 126 294 326 minecraft:stone
setblock 127 294 324 minecraft:stripped_spruce_log
setblock 127 294 325 minecraft:stone
setblock 128 294 323 minecraft:stripped_spruce_log
fill 128 294 324 128 295 324 minecraft:stone
fill 129 294 323 129 296 323 minecraft:stone
setblock 132 294 324 minecraft:stripped_spruce_log
fill 133 294 322 133 308 322 minecraft:stone
setblock 133 294 323 minecraft:stripped_spruce_log
setblock 133 294 324 minecraft:stone
fill 134 294 323 134 296 323 minecraft:stone
setblock 134 294 327 minecraft:stripped_spruce_log
fill 134 294 328 134 296 328 minecraft:stone
fill 135 294 322 135 299 322 minecraft:stone
setblock 135 294 326 minecraft:stripped_spruce_log
fill 135 294 327 135 297 327 minecraft:stone
setblock 135 294 331 minecraft:stripped_spruce_log
fill 135 294 332 135 297 332 minecraft:stone
setblock 135 294 351 minecraft:stripped_spruce_log
fill 135 294 352 135 297 352 minecraft:stone
setblock 135 294 355 minecraft:stone
setblock 135 294 356 minecraft:stripped_spruce_log
setblock 136 294 324 minecraft:diamond_block
setblock 136 294 341 minecraft:raw_iron_block
fill 136 294 360 136 308 360 minecraft:stone
setblock 94 295 354 minecraft:gold_block
setblock 95 295 325 minecraft:stripped_spruce_log
fill 95 295 326 95 296 326 minecraft:stone
setblock 95 295 330 minecraft:stripped_spruce_log
fill 95 295 331 95 297 331 minecraft:stone
fill 95 295 346 95 295 349 minecraft:stone
setblock 95 295 350 minecraft:stripped_spruce_log
fill 95 295 351 95 295 354 minecraft:stone
setblock 95 295 355 minecraft:stripped_spruce_log
fill 95 295 356 95 297 356 minecraft:stone
setblock 95 295 360 minecraft:stripped_spruce_log
fill 95 295 361 95 297 361 minecraft:stone
setblock 96 295 348 minecraft:stone
setblock 96 295 349 minecraft:stripped_spruce_log
fill 96 295 350 96 297 350 minecraft:stone
setblock 96 295 353 minecraft:stone
setblock 96 295 354 minecraft:stripped_spruce_log
fill 96 295 355 96 297 355 minecraft:stone
setblock 97 295 323 minecraft:stripped_spruce_log
setblock 97 295 332 minecraft:light[level=12]
setblock 97 295 339 minecraft:light[level=12]
setblock 97 295 346 minecraft:light[level=12]
fill 97 295 349 97 297 349 minecraft:stone
setblock 97 295 352 minecraft:stone
setblock 97 295 353 minecraft:stripped_spruce_log
fill 97 295 354 98 297 354 minecraft:stone
setblock 97 295 360 minecraft:light[level=12]
setblock 97 295 363 minecraft:stripped_spruce_log
fill 98 295 323 98 296 323 minecraft:stone
fill 98 295 324 98 297 324 minecraft:stripped_spruce_log
setblock 98 295 352 minecraft:stripped_spruce_log
fill 98 295 353 98 298 353 minecraft:stone
fill 98 295 363 98 297 363 minecraft:stone
setblock 99 295 362 minecraft:stone
setblock 102 295 323 minecraft:stripped_spruce_log
setblock 102 295 363 minecraft:stripped_spruce_log
setblock 103 295 323 minecraft:stone
fill 103 295 363 103 296 363 minecraft:stone
fill 104 295 322 104 308 322 minecraft:stone
setblock 104 295 325 minecraft:light[level=12]
setblock 104 295 332 minecraft:light[level=12]
setblock 104 295 339 minecraft:light[level=12]
setblock 104 295 346 minecraft:light[level=12]
setblock 104 295 353 minecraft:light[level=12]
setblock 104 295 360 minecraft:light[level=12]
setblock 111 295 325 minecraft:light[level=12]
setblock 111 295 332 minecraft:light[level=12]
setblock 111 295 339 minecraft:light[level=12]
setblock 111 295 346 minecraft:light[level=12]
setblock 111 295 353 minecraft:light[level=12]
setblock 111 295 360 minecraft:light[level=12]
setblock 115 295 364 minecraft:raw_iron_block
setblock 117 295 323 minecraft:stripped_spruce_log
setblock 118 295 322 minecraft:raw_iron_block
fill 118 295 323 120 295 324 minecraft:stone
setblock 118 295 325 minecraft:light[level=12]
setblock 118 295 332 minecraft:light[level=12]
setblock 118 295 339 minecraft:light[level=12]
setblock 118 295 346 minecraft:light[level=12]
setblock 118 295 353 minecraft:light[level=12]
setblock 118 295 360 minecraft:light[level=12]
setblock 120 295 325 minecraft:stripped_spruce_log
setblock 121 295 323 minecraft:stone
setblock 121 295 324 minecraft:stripped_spruce_log
fill 121 295 325 121 296 325 minecraft:stone
setblock 122 295 323 minecraft:stripped_spruce_log
fill 122 295 324 122 297 324 minecraft:stone
setblock 122 295 363 minecraft:stripped_spruce_log
fill 123 295 323 123 297 323 minecraft:stone
setblock 123 295 326 minecraft:stone
setblock 123 295 363 minecraft:stone
setblock 124 295 326 minecraft:stripped_spruce_log
setblock 125 295 325 minecraft:stripped_spruce_log
setblock 125 295 332 minecraft:light[level=12]
setblock 125 295 339 minecraft:light[level=12]
setblock 125 295 346 minecraft:light[level=12]
setblock 125 295 353 minecraft:light[level=12]
setblock 125 295 360 minecraft:light[level=12]
setblock 126 295 324 minecraft:stripped_spruce_log
setblock 126 295 325 minecraft:stone
setblock 127 295 323 minecraft:stripped_spruce_log
setblock 127 295 324 minecraft:stone
fill 128 295 323 128 296 323 minecraft:stone
setblock 132 295 323 minecraft:stripped_spruce_log
setblock 132 295 325 minecraft:light[level=12]
setblock 132 295 332 minecraft:light[level=12]
setblock 132 295 339 minecraft:light[level=12]
setblock 132 295 346 minecraft:light[level=12]
setblock 132 295 353 minecraft:light[level=12]
setblock 132 295 360 minecraft:light[level=12]
fill 133 295 323 133 296 323 minecraft:stone
setblock 134 295 326 minecraft:stripped_spruce_log
fill 134 295 327 134 296 327 minecraft:stone
setblock 134 295 330 minecraft:stone
setblock 134 295 331 minecraft:stripped_spruce_log
setblock 135 295 325 minecraft:stripped_spruce_log
fill 135 295 326 135 297 326 minecraft:stone
setblock 135 295 330 minecraft:stripped_spruce_log
fill 135 295 331 135 297 331 minecraft:stone
setblock 135 295 334 minecraft:stone
setblock 135 295 350 minecraft:stripped_spruce_log
fill 135 295 351 135 297 351 minecraft:stone
setblock 135 295 355 minecraft:stripped_spruce_log
fill 135 295 356 135 296 358 minecraft:stone
fill 136 295 324 136 308 324 minecraft:stone
fill 136 295 341 136 298 341 minecraft:stone
setblock 136 295 353 minecraft:diamond_block
setblock 94 296 342 minecraft:raw_iron_block
setblock 94 296 354 minecraft:stone
setblock 95 296 329 minecraft:stripped_spruce_log
fill 95 296 330 95 297 330 minecraft:stone
fill 95 296 347 95 296 348 minecraft:stone
setblock 95 296 349 minecraft:stripped_spruce_log
fill 95 296 350 95 296 353 minecraft:stone
setblock 95 296 354 minecraft:stripped_spruce_log
fill 95 296 355 95 297 355 minecraft:stone
setblock 95 296 359 minecraft:stripped_spruce_log
fill 95 296 360 95 297 360 minecraft:stone
setblock 96 296 324 minecraft:glowstone
setblock 96 296 343 minecraft:glowstone
setblock 96 296 348 minecraft:stripped_spruce_log
fill 96 296 349 96 297 349 minecraft:stone
setblock 96 296 353 minecraft:stripped_spruce_log
fill 96 296 354 96 297 354 minecraft:stone
setblock 96 296 358 minecraft:stripped_spruce_log
fill 96 296 359 96 297 359 minecraft:stone
setblock 96 296 362 minecraft:glowstone
setblock 96 296 363 minecraft:stripped_spruce_log
fill 97 296 350 97 296 351 minecraft:stone
setblock 97 296 352 minecraft:stripped_spruce_log
fill 97 296 353 97 299 353 minecraft:stone
setblock 97 296 357 minecraft:stripped_spruce_log
fill 97 296 363 97 297 363 minecraft:stone
setblock 98 296 351 minecraft:stripped_spruce_log
fill 98 296 352 98 299 352 minecraft:stone
setblock 101 296 323 minecraft:stripped_spruce_log
setblock 101 296 363 minecraft:stripped_spruce_log
setblock 102 296 323 minecraft:stone
fill 102 296 363 102 297 363 minecraft:stone
setblock 113 296 364 minecraft:raw_gold_block
setblock 115 296 324 minecraft:glowstone
setblock 115 296 362 minecraft:glowstone
fill 115 296 364 115 308 364 minecraft:stone
fill 117 296 323 120 296 323 minecraft:stone
fill 118 296 322 118 308 322 minecraft:stone
setblock 119 296 324 minecraft:stone
setblock 120 296 324 minecraft:stripped_spruce_log
setblock 120 296 325 minecraft:stone
setblock 121 296 323 minecraft:stripped_spruce_log
fill 121 296 324 121 297 324 minecraft:stone
fill 122 296 323 122 297 323 minecraft:stone
setblock 124 296 325 minecraft:stripped_spruce_log
setblock 125 296 324 minecraft:stripped_spruce_log
setblock 126 296 323 minecraft:stripped_spruce_log
setblock 126 296 324 minecraft:stone
fill 127 296 323 127 297 323 minecraft:stone
fill 131 296 360 131 297 362 minecraft:iron_bars
setblock 132 296 322 minecraft:diamond_block
setblock 134 296 324 minecraft:glowstone
setblock 134 296 330 minecraft:stripped_spruce_log
setblock 134 296 343 minecraft:glowstone
setblock 134 296 362 minecraft:glowstone
setblock 135 296 324 minecraft:stripped_spruce_log
fill 135 296 325 135 297 325 minecraft:stone
setblock 135 296 329 minecraft:stripped_spruce_log
fill 135 296 330 135 297 330 minecraft:stone
setblock 135 296 334 minecraft:stripped_spruce_log
setblock 135 296 349 minecraft:stripped_spruce_log
fill 135 296 350 135 297 350 minecraft:stone
fill 135 296 353 136 296 353 minecraft:stone
setblock 135 296 354 minecraft:stripped_spruce_log
fill 135 296 355 135 297 355 minecraft:stone
setblock 135 296 359 minecraft:stripped_spruce_log
setblock 94 297 336 minecraft:raw_gold_block
fill 94 297 342 94 307 342 minecraft:stone
setblock 94 297 354 minecraft:diamond_block
fill 95 297 323 95 297 327 minecraft:stripped_dark_oak_log
setblock 95 297 328 minecraft:stripped_spruce_log
setblock 95 297 329 minecraft:stone
setblock 95 297 333 minecraft:stripped_spruce_log
setblock 95 297 347 minecraft:stone
setblock 95 297 348 minecraft:stripped_spruce_log
fill 95 297 349 95 297 352 minecraft:stone
setblock 95 297 353 minecraft:stripped_spruce_log
setblock 95 297 354 minecraft:stone
setblock 95 297 358 minecraft:stripped_spruce_log
setblock 95 297 359 minecraft:stone
fill 95 297 364 95 308 364 minecraft:stone
fill 96 297 323 100 297 323 minecraft:stripped_dark_oak_log
fill 96 297 324 96 298 324 minecraft:spruce_log
fill 96 297 328 96 297 329 minecraft:stripped_dark_oak_log
fill 96 297 343 96 298 343 minecraft:spruce_log
setblock 96 297 348 minecraft:stone
setblock 96 297 352 minecraft:stripped_spruce_log
setblock 96 297 353 minecraft:stone
setblock 96 297 356 minecraft:stone
setblock 96 297 357 minecraft:stripped_spruce_log
setblock 96 297 358 minecraft:stone
fill 96 297 362 96 298 362 minecraft:spruce_log
setblock 96 297 363 minecraft:stone
fill 97 297 329 97 297 330 minecraft:stripped_dark_oak_log
setblock 97 297 350 minecraft:stone
setblock 97 297 351 minecraft:stripped_spruce_log
fill 97 297 352 97 300 352 minecraft:stone
setblock 97 297 356 minecraft:stripped_spruce_log
fill 97 297 357 97 300 357 minecraft:stone
fill 98 297 328 99 297 329 minecraft:stripped_dark_oak_log
setblock 98 297 351 minecraft:stone
setblock 98 297 355 minecraft:stripped_spruce_log
fill 99 297 324 100 297 324 minecraft:stripped_dark_oak_log
fill 100 297 325 100 297 328 minecraft:stripped_dark_oak_log
setblock 100 297 363 minecraft:stripped_spruce_log
fill 101 297 325 101 297 327 minecraft:stripped_dark_oak_log
setblock 101 297 363 minecraft:stone
fill 113 297 364 113 308 364 minecraft:stone
fill 114 297 329 114 297 332 minecraft:stripped_dark_oak_log
fill 115 297 324 115 298 324 minecraft:spruce_log
fill 115 297 328 115 297 329 minecraft:stripped_dark_oak_log
fill 115 297 332 115 297 333 minecraft:stripped_dark_oak_log
fill 115 297 362 115 298 362 minecraft:spruce_log
fill 116 297 328 118 297 328 minecraft:stripped_dark_oak_log
fill 116 297 333 118 297 333 minecraft:stripped_dark_oak_log
fill 118 297 323 119 297 323 minecraft:stone
fill 118 297 329 119 297 330 minecraft:stripped_dark_oak_log
fill 118 297 332 119 297 332 minecraft:stripped_dark_oak_log
setblock 119 297 324 minecraft:stripped_spruce_log
fill 119 297 331 119 298 331 minecraft:stripped_dark_oak_log
setblock 120 297 323 minecraft:stripped_spruce_log
setblock 120 297 324 minecraft:stone
setblock 121 297 323 minecraft:stone
setblock 124 297 324 minecraft:stripped_spruce_log
setblock 125 297 323 minecraft:stripped_spruce_log
setblock 126 297 323 minecraft:stone
fill 129 297 340 131 298 342 minecraft:iron_block
fill 132 297 322 132 308 322 minecraft:stone
fill 134 297 324 134 298 324 minecraft:spruce_log
fill 134 297 343 134 298 343 minecraft:spruce_log
fill 134 297 362 134 298 362 minecraft:spruce_log
setblock 135 297 323 minecraft:stripped_spruce_log
setblock 135 297 324 minecraft:stone
setblock 135 297 328 minecraft:stripped_spruce_log
setblock 135 297 329 minecraft:stone
setblock 135 297 333 minecraft:stripped_spruce_log
setblock 135 297 334 minecraft:stone
setblock 135 297 353 minecraft:stripped_spruce_log
setblock 135 297 354 minecraft:stone
fill 135 297 356 135 297 357 minecraft:stone
setblock 135 297 358 minecraft:stripped_spruce_log
fill 135 297 359 135 297 361 minecraft:stone
fill 136 297 353 136 308 353 minecraft:stone
fill 94 298 336 94 308 336 minecraft:stone
fill 94 298 354 94 308 354 minecraft:stone
fill 95 298 323 95 298 363 minecraft:spruce_planks
fill 96 298 323 135 298 323 minecraft:spruce_planks
fill 96 298 325 96 298 342 minecraft:spruce_planks
fill 96 298 344 96 298 361 minecraft:spruce_planks
fill 96 298 363 135 298 363 minecraft:spruce_planks
fill 97 298 324 114 298 324 minecraft:spruce_planks
fill 97 298 329 98 298 329 minecraft:stripped_dark_oak_log
setblock 97 298 350 minecraft:stripped_spruce_log
fill 97 298 351 97 300 351 minecraft:stone
setblock 97 298 354 minecraft:stone
setblock 97 298 355 minecraft:stripped_spruce_log
fill 97 298 356 97 300 356 minecraft:stone
fill 97 298 358 97 299 358 minecraft:stone
fill 97 298 362 114 298 362 minecraft:spruce_planks
fill 98 298 328 99 299 328 minecraft:stripped_dark_oak_log
setblock 98 298 354 minecraft:stripped_spruce_log
fill 98 298 355 98 300 355 minecraft:stone
fill 100 298 325 100 298 327 minecraft:stripped_dark_oak_log
setblock 103 298 364 minecraft:raw_gold_block
fill 114 298 330 114 298 331 minecraft:stripped_dark_oak_log
fill 115 298 329 115 299 329 minecraft:stripped_dark_oak_log
fill 115 298 332 115 299 332 minecraft:stripped_dark_oak_log
fill 116 298 324 133 298 324 minecraft:spruce_planks
fill 116 298 328 117 298 328 minecraft:stripped_dark_oak_log
fill 116 298 333 117 298 333 minecraft:stripped_dark_oak_log
fill 116 298 362 133 298 362 minecraft:spruce_planks
fill 118 298 329 118 298 330 minecraft:stripped_dark_oak_log
fill 118 298 332 118 299 332 minecraft:stripped_dark_oak_log
setblock 119 298 330 minecraft:stripped_dark_oak_log
fill 134 298 325 135 298 342 minecraft:spruce_planks
fill 134 298 344 135 298 361 minecraft:spruce_planks
setblock 135 298 324 minecraft:spruce_planks
setblock 135 298 343 minecraft:spruce_planks
setblock 135 298 362 minecraft:spruce_planks
setblock 136 298 362 minecraft:raw_gold_block
fill 95 299 325 95 299 327 minecraft:stripped_dark_oak_log
setblock 95 299 330 minecraft:stone
setblock 95 299 331 minecraft:stripped_spruce_log
fill 95 299 332 95 299 335 minecraft:stone
fill 95 299 347 95 299 350 minecraft:stone
setblock 95 299 351 minecraft:stripped_spruce_log
fill 95 299 352 95 299 355 minecraft:stone
setblock 95 299 356 minecraft:stripped_spruce_log
fill 95 299 357 95 299 360 minecraft:stone
setblock 95 299 361 minecraft:stripped_spruce_log
fill 95 299 362 95 300 363 minecraft:stone
setblock 96 299 324 minecraft:stripped_dark_oak_log
fill 96 299 325 96 300 327 minecraft:stripped_spruce_log
setblock 96 299 328 minecraft:stripped_dark_oak_log
fill 96 299 348 96 299 349 minecraft:stone
setblock 96 299 350 minecraft:stripped_spruce_log
fill 96 299 351 96 299 354 minecraft:stone
setblock 96 299 355 minecraft:stripped_spruce_log
fill 96 299 356 96 299 359 minecraft:stone
setblock 96 299 360 minecraft:stripped_spruce_log
fill 96 299 361 96 300 361 minecraft:stone
fill 96 299 363 97 299 363 minecraft:stone
fill 97 299 324 98 300 324 minecraft:stripped_spruce_log
setblock 97 299 333 minecraft:light[level=15]
setblock 97 299 341 minecraft:light[level=15]
setblock 97 299 349 minecraft:light[level=15]
fill 97 299 350 97 300 350 minecraft:stone
setblock 97 299 354 minecraft:stripped_spruce_log
fill 97 299 355 97 300 355 minecraft:stone
setblock 98 299 353 minecraft:stripped_spruce_log
fill 98 299 354 98 300 354 minecraft:stone
fill 98 299 356 98 300 356 minecraft:stone
setblock 98 299 363 minecraft:stripped_spruce_log
setblock 99 299 324 minecraft:stripped_dark_oak_log
fill 99 299 363 101 299 363 minecraft:stone
fill 103 299 364 103 302 364 minecraft:stone
setblock 105 299 325 minecraft:light[level=15]
setblock 105 299 333 minecraft:light[level=15]
setblock 105 299 341 minecraft:light[level=15]
setblock 105 299 349 minecraft:light[level=15]
setblock 105 299 357 minecraft:light[level=15]
setblock 113 299 325 minecraft:light[level=15]
setblock 113 299 333 minecraft:light[level=15]
setblock 113 299 341 minecraft:light[level=15]
setblock 113 299 349 minecraft:light[level=15]
setblock 113 299 357 minecraft:light[level=15]
setblock 118 299 323 minecraft:stripped_spruce_log
setblock 118 299 330 minecraft:stripped_dark_oak_log
fill 119 299 323 122 299 323 minecraft:stone
setblock 121 299 325 minecraft:light[level=15]
setblock 121 299 333 minecraft:light[level=15]
setblock 121 299 341 minecraft:light[level=15]
setblock 121 299 349 minecraft:light[level=15]
setblock 121 299 357 minecraft:light[level=15]
setblock 123 299 323 minecraft:stripped_spruce_log
setblock 124 299 323 minecraft:stone
setblock 129 299 325 minecraft:light[level=15]
setblock 129 299 333 minecraft:light[level=15]
fill 129 299 340 131 299 342 minecraft:raw_gold_block
setblock 129 299 349 minecraft:light[level=15]
setblock 129 299 357 minecraft:light[level=15]
fill 134 299 355 134 299 356 minecraft:stone
setblock 134 299 357 minecraft:stripped_spruce_log
setblock 135 299 325 minecraft:stone
setblock 135 299 326 minecraft:stripped_spruce_log
fill 135 299 327 135 299 330 minecraft:stone
setblock 135 299 331 minecraft:stripped_spruce_log
fill 135 299 332 135 299 335 minecraft:stone
setblock 135 299 350 minecraft:stone
setblock 135 299 351 minecraft:stripped_spruce_log
fill 135 299 352 135 299 355 minecraft:stone
setblock 135 299 356 minecraft:stripped_spruce_log
fill 135 299 357 135 299 360 minecraft:stone
setblock 135 299 361 minecraft:stripped_spruce_log
fill 135 299 362 135 300 363 minecraft:stone
setblock 136 299 341 minecraft:raw_gold_block
fill 136 299 362 136 308 362 minecraft:stone
fill 94 300 322 94 308 322 minecraft:stone
setblock 94 300 323 minecraft:raw_iron_block
setblock 95 300 330 minecraft:stripped_spruce_log
fill 95 300 331 95 300 334 minecraft:stone
setblock 95 300 335 minecraft:stripped_spruce_log
fill 95 300 336 95 300 337 minecraft:stone
fill 95 300 347 95 300 349 minecraft:stone
setblock 95 300 350 minecraft:stripped_spruce_log
fill 95 300 351 95 300 354 minecraft:stone
setblock 95 300 355 minecraft:stripped_spruce_log
fill 95 300 356 95 300 359 minecraft:stone
setblock 95 300 360 minecraft:stripped_spruce_log
setblock 95 300 361 minecraft:stone
setblock 96 300 348 minecraft:stone
setblock 96 300 349 minecraft:stripped_spruce_log
fill 96 300 350 96 300 353 minecraft:stone
setblock 96 300 354 minecraft:stripped_spruce_log
fill 96 300 355 96 300 358 minecraft:stone
setblock 96 300 359 minecraft:stripped_spruce_log
setblock 96 300 360 minecraft:stone
setblock 96 300 363 minecraft:stone
setblock 97 300 353 minecraft:stripped_spruce_log
setblock 97 300 354 minecraft:stone
setblock 97 300 358 minecraft:stripped_spruce_log
setblock 97 300 359 minecraft:stone
setblock 97 300 362 minecraft:stone
setblock 97 300 363 minecraft:stripped_spruce_log
setblock 98 300 352 minecraft:stripped_spruce_log
setblock 98 300 353 minecraft:stone
setblock 98 300 357 minecraft:stripped_spruce_log
setblock 98 300 362 minecraft:stripped_spruce_log
fill 98 300 363 100 300 363 minecraft:stone
setblock 108 300 322 minecraft:raw_iron_block
setblock 117 300 323 minecraft:stripped_spruce_log
fill 118 300 323 121 300 323 minecraft:stone
setblock 122 300 323 minecraft:stripped_spruce_log
setblock 123 300 323 minecraft:stone
setblock 127 300 322 minecraft:diamond_block
fill 127 300 364 127 308 364 minecraft:stone
setblock 128 300 364 minecraft:raw_iron_block
fill 134 300 354 134 300 355 minecraft:stone
setblock 134 300 356 minecraft:stripped_spruce_log
fill 134 300 357 135 300 359 minecraft:stone
setblock 134 300 363 minecraft:stone
setblock 135 300 322 minecraft:raw_gold_block
setblock 135 300 325 minecraft:stripped_spruce_log
fill 135 300 326 135 300 329 minecraft:stone
setblock 135 300 330 minecraft:stripped_spruce_log
fill 135 300 331 135 300 334 minecraft:stone
setblock 135 300 335 minecraft:stripped_spruce_log
setblock 135 300 336 minecraft:stone
setblock 135 300 350 minecraft:stripped_spruce_log
fill 135 300 351 135 300 354 minecraft:stone
setblock 135 300 355 minecraft:stripped_spruce_log
setblock 135 300 356 minecraft:stone
setblock 135 300 360 minecraft:stripped_spruce_log
setblock 135 300 361 minecraft:stone
fill 136 300 341 136 308 341 minecraft:stone
fill 94 301 323 94 308 323 minecraft:stone
setblock 94 301 349 minecraft:diamond_block
fill 94 301 350 94 308 350 minecraft:stone
setblock 96 301 364 minecraft:gold_block
setblock 97 301 325 minecraft:light[level=12]
setblock 97 301 332 minecraft:light[level=12]
setblock 97 301 339 minecraft:light[level=12]
setblock 97 301 346 minecraft:light[level=12]
setblock 97 301 353 minecraft:light[level=12]
setblock 97 301 360 minecraft:light[level=12]
setblock 104 301 325 minecraft:light[level=12]
setblock 104 301 332 minecraft:light[level=12]
setblock 104 301 339 minecraft:light[level=12]
setblock 104 301 346 minecraft:light[level=12]
setblock 104 301 353 minecraft:light[level=12]
setblock 104 301 360 minecraft:light[level=12]
fill 108 301 322 108 304 322 minecraft:stone
setblock 111 301 325 minecraft:light[level=12]
setblock 111 301 332 minecraft:light[level=12]
setblock 111 301 339 minecraft:light[level=12]
setblock 111 301 346 minecraft:light[level=12]
setblock 111 301 353 minecraft:light[level=12]
setblock 111 301 360 minecraft:light[level=12]
setblock 114 301 364 minecraft:raw_gold_block
setblock 115 301 322 minecraft:gold_block
setblock 118 301 325 minecraft:light[level=12]
setblock 118 301 332 minecraft:light[level=12]
setblock 118 301 339 minecraft:light[level=12]
setblock 118 301 346 minecraft:light[level=12]
setblock 118 301 353 minecraft:light[level=12]
setblock 118 301 360 minecraft:light[level=12]
setblock 125 301 325 minecraft:light[level=12]
setblock 125 301 332 minecraft:light[level=12]
setblock 125 301 339 minecraft:light[level=12]
setblock 125 301 346 minecraft:light[level=12]
setblock 125 301 353 minecraft:light[level=12]
setblock 125 301 360 minecraft:light[level=12]
fill 127 301 322 127 308 322 minecraft:stone
fill 128 301 364 128 308 364 minecraft:stone
setblock 132 301 325 minecraft:light[level=12]
setblock 132 301 332 minecraft:light[level=12]
setblock 132 301 339 minecraft:light[level=12]
setblock 132 301 346 minecraft:light[level=12]
setblock 132 301 353 minecraft:light[level=12]
setblock 132 301 360 minecraft:light[level=12]
fill 135 301 322 135 308 322 minecraft:stone
setblock 136 301 334 minecraft:raw_gold_block
setblock 136 301 336 minecraft:gold_block
fill 94 302 349 94 308 349 minecraft:stone
fill 96 302 364 96 308 364 minecraft:stone
setblock 98 302 364 minecraft:raw_iron_block
fill 114 302 364 114 308 364 minecraft:stone
fill 115 302 322 115 308 322 minecraft:stone
setblock 136 302 334 minecraft:stone
fill 136 302 336 136 308 336 minecraft:stone
setblock 136 302 357 minecraft:diamond_block
fill 94 303 334 94 308 334 minecraft:stone
setblock 94 303 335 minecraft:gold_block
fill 98 303 364 98 305 364 minecraft:stone
setblock 103 303 364 minecraft:gold_block
setblock 136 303 330 minecraft:raw_iron_block
setblock 136 303 334 minecraft:gold_block
fill 136 303 357 136 308 357 minecraft:stone
fill 94 304 335 94 308 335 minecraft:stone
fill 103 304 364 103 308 364 minecraft:stone
fill 136 304 330 136 308 330 minecraft:stone
fill 136 304 334 136 308 334 minecraft:stone
setblock 108 305 322 minecraft:gold_block
setblock 98 306 364 minecraft:gold_block
fill 108 306 322 108 308 322 minecraft:stone
setblock 129 306 322 minecraft:gold_block
setblock 136 306 363 minecraft:gold_block
fill 98 307 364 98 308 364 minecraft:stone
setblock 128 307 322 minecraft:diamond_block
fill 129 307 322 129 308 322 minecraft:stone
setblock 136 307 355 minecraft:raw_iron_block
fill 136 307 356 136 308 356 minecraft:stone
setblock 136 307 361 minecraft:gold_block
fill 136 307 363 136 308 363 minecraft:stone
setblock 94 308 342 minecraft:gold_block
setblock 128 308 322 minecraft:stone
setblock 136 308 346 minecraft:diamond_block
setblock 136 308 354 minecraft:diamond_block
setblock 136 308 355 minecraft:stone
setblock 136 308 361 minecraft:stone
