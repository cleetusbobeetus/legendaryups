fill 153 142 360 153 143 360 minecraft:blue_terracotta
setblock 153 142 362 minecraft:dark_prismarine
fill 153 142 363 153 145 363 minecraft:blue_terracotta
fill 154 142 343 154 162 343 minecraft:dark_prismarine
setblock 154 142 361 minecraft:dark_prismarine
fill 154 142 362 154 145 362 minecraft:blue_terracotta
fill 155 142 361 155 145 361 minecraft:blue_terracotta
setblock 157 142 363 minecraft:dark_prismarine
setblock 158 142 362 minecraft:dark_prismarine
fill 158 142 363 158 145 363 minecraft:blue_terracotta
setblock 160 142 323 minecraft:purple_concrete
fill 163 142 357 163 143 357 minecraft:purple_concrete
fill 163 142 360 163 143 360 minecraft:purple_concrete
fill 164 142 356 166 143 356 minecraft:purple_concrete
setblock 164 142 363 minecraft:purple_concrete
fill 165 142 361 165 143 361 minecraft:purple_concrete
fill 167 142 357 167 143 357 minecraft:purple_concrete
fill 167 142 360 167 143 360 minecraft:purple_concrete
fill 170 142 363 171 142 363 minecraft:blue_terracotta
setblock 171 142 323 minecraft:blue_terracotta
setblock 172 142 323 minecraft:dark_prismarine
setblock 172 142 363 minecraft:dark_prismarine
fill 173 142 323 173 145 323 minecraft:blue_terracotta
setblock 173 142 362 minecraft:dark_prismarine
fill 173 142 363 173 145 363 minecraft:blue_terracotta
fill 174 142 362 174 145 362 minecraft:blue_terracotta
setblock 175 142 324 minecraft:blue_terracotta
setblock 176 142 324 minecraft:dark_prismarine
setblock 177 142 323 minecraft:dark_prismarine
setblock 177 142 362 minecraft:blue_terracotta
setblock 177 142 363 minecraft:dark_prismarine
fill 178 142 323 178 145 323 minecraft:blue_terracotta
fill 178 142 363 178 145 363 minecraft:blue_terracotta
setblock 182 142 326 minecraft:purple_concrete
setblock 182 142 334 minecraft:blue_terracotta
setblock 182 142 338 minecraft:dark_prismarine
setblock 182 142 339 minecraft:blue_terracotta
setblock 182 142 345 minecraft:purple_concrete
setblock 182 142 363 minecraft:dark_prismarine
setblock 142 143 347 minecraft:purple_concrete
setblock 142 143 357 minecraft:dark_prismarine
fill 142 143 358 142 146 358 minecraft:blue_terracotta
setblock 142 143 362 minecraft:dark_prismarine
fill 142 143 363 142 146 363 minecraft:blue_terracotta
fill 143 143 359 143 143 360 minecraft:blue_terracotta
setblock 143 143 361 minecraft:dark_prismarine
fill 143 143 362 146 143 362 minecraft:blue_terracotta
setblock 144 143 325 minecraft:light[level=12]
setblock 144 143 332 minecraft:light[level=12]
setblock 144 143 339 minecraft:light[level=12]
setblock 144 143 346 minecraft:light[level=12]
setblock 144 143 353 minecraft:light[level=12]
setblock 144 143 360 minecraft:light[level=12]
setblock 146 143 363 minecraft:dark_prismarine
setblock 147 143 362 minecraft:dark_prismarine
fill 147 143 363 147 146 363 minecraft:blue_terracotta
setblock 148 143 361 minecraft:dark_prismarine
fill 148 143 362 148 146 362 minecraft:blue_terracotta
fill 149 143 323 150 143 323 minecraft:blue_terracotta
fill 149 143 361 149 146 361 minecraft:blue_terracotta
setblock 151 143 323 minecraft:dark_prismarine
setblock 151 143 325 minecraft:light[level=12]
setblock 151 143 332 minecraft:light[level=12]
setblock 151 143 339 minecraft:light[level=12]
setblock 151 143 346 minecraft:light[level=12]
setblock 151 143 353 minecraft:light[level=12]
fill 151 143 360 152 144 360 minecraft:blue_terracotta
setblock 151 143 363 minecraft:dark_prismarine
fill 152 143 323 152 146 323 minecraft:blue_terracotta
setblock 152 143 362 minecraft:dark_prismarine
fill 152 143 363 152 146 363 minecraft:blue_terracotta
setblock 153 143 361 minecraft:dark_prismarine
fill 153 143 362 153 146 362 minecraft:blue_terracotta
fill 154 143 361 154 146 361 minecraft:blue_terracotta
setblock 155 143 323 minecraft:blue_terracotta
fill 156 143 356 156 154 356 minecraft:magenta_terracotta
setblock 156 143 363 minecraft:dark_prismarine
setblock 157 143 362 minecraft:dark_prismarine
fill 157 143 363 157 146 363 minecraft:blue_terracotta
setblock 158 143 325 minecraft:light[level=12]
setblock 158 143 332 minecraft:light[level=12]
setblock 158 143 339 minecraft:light[level=12]
setblock 158 143 346 minecraft:light[level=12]
setblock 158 143 353 minecraft:light[level=12]
setblock 158 143 360 minecraft:light[level=12]
fill 158 143 362 158 145 362 minecraft:blue_terracotta
fill 162 143 357 162 143 359 minecraft:purple_concrete
setblock 163 143 356 minecraft:purple_concrete
setblock 164 143 361 minecraft:purple_concrete
setblock 165 143 325 minecraft:light[level=12]
setblock 165 143 332 minecraft:light[level=12]
setblock 165 143 339 minecraft:light[level=12]
setblock 165 143 346 minecraft:light[level=12]
setblock 165 143 353 minecraft:light[level=12]
setblock 165 143 355 minecraft:purple_concrete
setblock 166 143 361 minecraft:purple_concrete
setblock 167 143 356 minecraft:purple_concrete
fill 168 143 357 168 143 359 minecraft:purple_concrete
fill 169 143 363 170 143 363 minecraft:blue_terracotta
setblock 170 143 323 minecraft:blue_terracotta
setblock 171 143 323 minecraft:dark_prismarine
setblock 171 143 363 minecraft:dark_prismarine
fill 172 143 323 172 145 324 minecraft:blue_terracotta
setblock 172 143 325 minecraft:light[level=12]
setblock 172 143 332 minecraft:light[level=12]
setblock 172 143 339 minecraft:light[level=12]
setblock 172 143 346 minecraft:light[level=12]
setblock 172 143 353 minecraft:light[level=12]
setblock 172 143 360 minecraft:light[level=12]
setblock 172 143 362 minecraft:dark_prismarine
fill 172 143 363 172 146 363 minecraft:blue_terracotta
fill 173 143 324 174 143 324 minecraft:blue_terracotta
fill 173 143 362 173 146 362 minecraft:blue_terracotta
setblock 175 143 324 minecraft:dark_prismarine
setblock 176 143 323 minecraft:dark_prismarine
fill 176 143 324 177 145 324 minecraft:blue_terracotta
setblock 176 143 363 minecraft:dark_prismarine
fill 177 143 323 177 146 323 minecraft:blue_terracotta
setblock 177 143 362 minecraft:dark_prismarine
fill 177 143 363 177 146 363 minecraft:blue_terracotta
fill 178 143 362 178 146 362 minecraft:blue_terracotta
setblock 179 143 325 minecraft:light[level=12]
setblock 179 143 332 minecraft:light[level=12]
setblock 179 143 339 minecraft:light[level=12]
setblock 179 143 346 minecraft:light[level=12]
setblock 179 143 353 minecraft:light[level=12]
setblock 179 143 360 minecraft:light[level=12]
setblock 181 143 323 minecraft:dark_prismarine
setblock 181 143 363 minecraft:dark_prismarine
fill 182 143 323 182 146 323 minecraft:blue_terracotta
setblock 182 143 337 minecraft:dark_prismarine
fill 182 143 338 182 145 338 minecraft:blue_terracotta
setblock 182 143 339 minecraft:purple_concrete
fill 182 143 359 182 145 359 minecraft:blue_terracotta
setblock 182 143 362 minecraft:dark_prismarine
fill 182 143 363 182 146 363 minecraft:blue_terracotta
setblock 183 143 346 minecraft:light_blue_wool
setblock 142 144 328 minecraft:purple_concrete
setblock 142 144 353 minecraft:purple_concrete
setblock 142 144 356 minecraft:dark_prismarine
fill 142 144 357 142 147 357 minecraft:blue_terracotta
setblock 142 144 361 minecraft:dark_prismarine
fill 142 144 362 145 144 362 minecraft:blue_terracotta
setblock 143 144 359 minecraft:blue_terracotta
setblock 143 144 360 minecraft:dark_prismarine
fill 143 144 361 143 147 361 minecraft:blue_terracotta
setblock 145 144 363 minecraft:dark_prismarine
fill 146 144 323 149 144 323 minecraft:blue_terracotta
setblock 146 144 361 minecraft:blue_terracotta
setblock 146 144 362 minecraft:dark_prismarine
fill 146 144 363 146 147 363 minecraft:blue_terracotta
setblock 147 144 361 minecraft:dark_prismarine
fill 147 144 362 147 147 362 minecraft:blue_terracotta
fill 148 144 361 148 147 361 minecraft:blue_terracotta
setblock 150 144 323 minecraft:dark_prismarine
fill 150 144 334 150 150 335 minecraft:magenta_terracotta
fill 150 144 360 150 146 360 minecraft:blue_terracotta
setblock 150 144 363 minecraft:dark_prismarine
fill 151 144 323 151 147 323 minecraft:blue_terracotta
setblock 151 144 362 minecraft:dark_prismarine
fill 151 144 363 151 147 363 minecraft:blue_terracotta
setblock 152 144 361 minecraft:dark_prismarine
fill 152 144 362 152 147 362 minecraft:blue_terracotta
setblock 153 144 360 minecraft:dark_prismarine
fill 153 144 361 153 147 361 minecraft:blue_terracotta
setblock 155 144 323 minecraft:dark_prismarine
setblock 155 144 363 minecraft:dark_prismarine
fill 156 144 323 156 147 323 minecraft:blue_terracotta
setblock 156 144 362 minecraft:dark_prismarine
fill 156 144 363 156 147 363 minecraft:blue_terracotta
fill 157 144 362 157 147 362 minecraft:blue_terracotta
fill 161 144 354 167 144 363 minecraft:dark_prismarine
setblock 167 144 323 minecraft:purple_concrete
fill 168 144 323 169 144 323 minecraft:blue_terracotta
fill 168 144 354 169 144 362 minecraft:dark_prismarine
fill 168 144 363 169 144 363 minecraft:blue_terracotta
setblock 170 144 323 minecraft:dark_prismarine
setblock 170 144 362 minecraft:blue_terracotta
setblock 170 144 363 minecraft:dark_prismarine
fill 171 144 323 171 146 324 minecraft:blue_terracotta
fill 171 144 351 171 171 351 minecraft:magenta_terracotta
setblock 171 144 362 minecraft:dark_prismarine
fill 171 144 363 171 147 363 minecraft:blue_terracotta
fill 172 144 362 172 147 362 minecraft:blue_terracotta
setblock 173 144 324 minecraft:blue_terracotta
setblock 174 144 324 minecraft:dark_prismarine
setblock 175 144 323 minecraft:dark_prismarine
fill 175 144 324 175 147 324 minecraft:blue_terracotta
setblock 175 144 362 minecraft:blue_terracotta
setblock 175 144 363 minecraft:dark_prismarine
fill 176 144 323 176 147 323 minecraft:blue_terracotta
setblock 176 144 362 minecraft:dark_prismarine
fill 176 144 363 176 147 363 minecraft:blue_terracotta
fill 177 144 362 177 147 362 minecraft:blue_terracotta
setblock 178 144 324 minecraft:blue_terracotta
fill 179 144 362 179 145 362 minecraft:blue_terracotta
setblock 180 144 323 minecraft:dark_prismarine
setblock 180 144 363 minecraft:dark_prismarine
fill 181 144 323 181 147 323 minecraft:blue_terracotta
fill 181 144 363 181 147 363 minecraft:blue_terracotta
fill 182 144 324 182 145 324 minecraft:blue_terracotta
setblock 182 144 333 minecraft:purple_concrete
setblock 182 144 358 minecraft:purple_concrete
setblock 182 144 361 minecraft:dark_prismarine
fill 182 144 362 182 147 362 minecraft:blue_terracotta
fill 183 144 346 183 220 346 minecraft:blue_terracotta
fill 141 145 345 141 190 348 minecraft:blue_terracotta
setblock 141 145 349 minecraft:cyan_concrete
fill 141 145 350 141 146 352 minecraft:blue_terracotta
fill 142 145 323 143 145 323 minecraft:blue_terracotta
setblock 142 145 334 minecraft:purple_concrete
fill 142 145 356 142 148 356 minecraft:blue_terracotta
setblock 142 145 360 minecraft:dark_prismarine
fill 142 145 361 142 147 362 minecraft:blue_terracotta
setblock 143 145 358 minecraft:blue_terracotta
setblock 143 145 359 minecraft:dark_prismarine
fill 143 145 360 143 148 360 minecraft:blue_terracotta
fill 143 145 362 144 145 362 minecraft:blue_terracotta
setblock 144 145 323 minecraft:dark_prismarine
setblock 144 145 363 minecraft:dark_prismarine
fill 145 145 323 148 145 323 minecraft:blue_terracotta
setblock 145 145 361 minecraft:blue_terracotta
setblock 145 145 362 minecraft:dark_prismarine
fill 145 145 363 145 148 363 minecraft:blue_terracotta
setblock 146 145 361 minecraft:dark_prismarine
fill 146 145 362 146 148 362 minecraft:blue_terracotta
fill 147 145 361 147 148 361 minecraft:blue_terracotta
setblock 149 145 323 minecraft:dark_prismarine
fill 149 145 360 149 147 360 minecraft:blue_terracotta
setblock 149 145 363 minecraft:dark_prismarine
fill 150 145 323 150 148 323 minecraft:blue_terracotta
setblock 150 145 362 minecraft:dark_prismarine
fill 150 145 363 150 148 363 minecraft:blue_terracotta
setblock 151 145 360 minecraft:blue_terracotta
setblock 151 145 361 minecraft:dark_prismarine
fill 151 145 362 151 148 362 minecraft:blue_terracotta
setblock 152 145 360 minecraft:dark_prismarine
fill 152 145 361 152 148 361 minecraft:blue_terracotta
setblock 153 145 323 minecraft:blue_terracotta
fill 153 145 360 153 146 360 minecraft:blue_terracotta
setblock 154 145 323 minecraft:dark_prismarine
setblock 154 145 363 minecraft:dark_prismarine
fill 155 145 323 155 148 323 minecraft:blue_terracotta
setblock 155 145 362 minecraft:dark_prismarine
fill 155 145 363 155 148 363 minecraft:blue_terracotta
setblock 156 145 361 minecraft:dark_prismarine
fill 156 145 362 156 148 362 minecraft:blue_terracotta
setblock 159 145 363 minecraft:dark_prismarine
fill 160 145 363 160 148 363 minecraft:blue_terracotta
setblock 161 145 323 minecraft:purple_concrete
setblock 161 145 354 minecraft:sea_lantern
fill 161 145 355 161 162 355 minecraft:dark_prismarine
setblock 161 145 356 minecraft:sea_lantern
fill 161 145 357 161 162 357 minecraft:dark_prismarine
setblock 161 145 358 minecraft:sea_lantern
fill 161 145 359 161 162 359 minecraft:dark_prismarine
setblock 161 145 360 minecraft:sea_lantern
fill 161 145 361 161 162 361 minecraft:dark_prismarine
setblock 161 145 362 minecraft:sea_lantern
fill 161 145 363 161 146 363 minecraft:dark_prismarine
fill 162 145 354 162 162 354 minecraft:dark_prismarine
setblock 162 145 355 minecraft:sea_lantern
fill 162 145 356 162 162 356 minecraft:dark_prismarine
setblock 162 145 357 minecraft:sea_lantern
fill 162 145 358 162 162 358 minecraft:dark_prismarine
setblock 162 145 359 minecraft:sea_lantern
fill 162 145 360 162 162 360 minecraft:dark_prismarine
setblock 162 145 361 minecraft:sea_lantern
fill 162 145 362 162 162 362 minecraft:dark_prismarine
setblock 162 145 363 minecraft:sea_lantern
setblock 163 145 354 minecraft:sea_lantern
fill 163 145 355 163 162 355 minecraft:dark_prismarine
setblock 163 145 356 minecraft:sea_lantern
fill 163 145 357 163 162 357 minecraft:dark_prismarine
setblock 163 145 358 minecraft:sea_lantern
fill 163 145 359 163 162 359 minecraft:dark_prismarine
setblock 163 145 360 minecraft:sea_lantern
fill 163 145 361 163 162 361 minecraft:dark_prismarine
setblock 163 145 362 minecraft:sea_lantern
setblock 163 145 363 minecraft:dark_prismarine
fill 164 145 354 164 162 354 minecraft:dark_prismarine
setblock 164 145 355 minecraft:sea_lantern
fill 164 145 356 164 162 356 minecraft:dark_prismarine
setblock 164 145 357 minecraft:sea_lantern
fill 164 145 358 164 162 358 minecraft:dark_prismarine
setblock 164 145 359 minecraft:sea_lantern
fill 164 145 360 164 162 360 minecraft:dark_prismarine
setblock 164 145 361 minecraft:sea_lantern
fill 164 145 362 164 162 362 minecraft:dark_prismarine
setblock 164 145 363 minecraft:sea_lantern
setblock 165 145 354 minecraft:sea_lantern
fill 165 145 355 165 162 355 minecraft:dark_prismarine
setblock 165 145 356 minecraft:sea_lantern
fill 165 145 357 165 162 357 minecraft:dark_prismarine
setblock 165 145 358 minecraft:sea_lantern
fill 165 145 359 165 162 359 minecraft:dark_prismarine
setblock 165 145 360 minecraft:sea_lantern
fill 165 145 361 165 162 361 minecraft:dark_prismarine
setblock 165 145 362 minecraft:sea_lantern
setblock 165 145 363 minecraft:dark_prismarine
fill 166 145 323 168 145 323 minecraft:blue_terracotta
fill 166 145 354 166 162 354 minecraft:dark_prismarine
setblock 166 145 355 minecraft:sea_lantern
fill 166 145 356 166 162 356 minecraft:dark_prismarine
setblock 166 145 357 minecraft:sea_lantern
fill 166 145 358 166 162 358 minecraft:dark_prismarine
setblock 166 145 359 minecraft:sea_lantern
fill 166 145 360 166 162 360 minecraft:dark_prismarine
setblock 166 145 361 minecraft:sea_lantern
fill 166 145 362 166 147 362 minecraft:dark_prismarine
setblock 166 145 363 minecraft:sea_lantern
setblock 167 145 354 minecraft:sea_lantern
fill 167 145 355 167 162 355 minecraft:dark_prismarine
setblock 167 145 356 minecraft:sea_lantern
fill 167 145 357 167 162 357 minecraft:dark_prismarine
setblock 167 145 358 minecraft:sea_lantern
fill 167 145 359 167 162 359 minecraft:dark_prismarine
setblock 167 145 360 minecraft:sea_lantern
fill 167 145 361 167 162 361 minecraft:dark_prismarine
setblock 167 145 362 minecraft:sea_lantern
fill 167 145 363 167 146 363 minecraft:blue_terracotta
fill 168 145 328 168 186 328 minecraft:magenta_terracotta
fill 168 145 354 168 162 354 minecraft:dark_prismarine
setblock 168 145 355 minecraft:sea_lantern
fill 168 145 356 168 162 356 minecraft:dark_prismarine
setblock 168 145 357 minecraft:sea_lantern
fill 168 145 358 168 162 358 minecraft:dark_prismarine
setblock 168 145 359 minecraft:sea_lantern
fill 168 145 360 168 162 360 minecraft:dark_prismarine
setblock 168 145 361 minecraft:sea_lantern
setblock 168 145 362 minecraft:dark_prismarine
setblock 168 145 363 minecraft:sea_lantern
setblock 169 145 323 minecraft:dark_prismarine
fill 169 145 324 170 147 324 minecraft:blue_terracotta
setblock 169 145 354 minecraft:sea_lantern
fill 169 145 355 169 162 355 minecraft:dark_prismarine
setblock 169 145 356 minecraft:sea_lantern
fill 169 145 357 169 162 357 minecraft:dark_prismarine
setblock 169 145 358 minecraft:sea_lantern
fill 169 145 359 169 162 359 minecraft:dark_prismarine
setblock 169 145 360 minecraft:sea_lantern
fill 169 145 361 169 162 361 minecraft:dark_prismarine
setblock 169 145 362 minecraft:sea_lantern
setblock 169 145 363 minecraft:dark_prismarine
fill 170 145 323 170 148 323 minecraft:blue_terracotta
setblock 170 145 362 minecraft:dark_prismarine
fill 170 145 363 170 148 363 minecraft:blue_terracotta
fill 171 145 362 171 148 362 minecraft:blue_terracotta
setblock 173 145 324 minecraft:dark_prismarine
fill 173 145 325 174 147 325 minecraft:blue_terracotta
setblock 174 145 323 minecraft:dark_prismarine
fill 174 145 324 174 148 324 minecraft:blue_terracotta
setblock 174 145 363 minecraft:dark_prismarine
fill 175 145 323 175 148 323 minecraft:blue_terracotta
setblock 175 145 362 minecraft:dark_prismarine
fill 175 145 363 175 148 363 minecraft:blue_terracotta
fill 176 145 362 176 148 362 minecraft:blue_terracotta
setblock 178 145 324 minecraft:dark_prismarine
setblock 179 145 323 minecraft:dark_prismarine
fill 179 145 324 179 148 324 minecraft:blue_terracotta
setblock 179 145 363 minecraft:dark_prismarine
fill 180 145 323 180 148 323 minecraft:blue_terracotta
setblock 180 145 362 minecraft:dark_prismarine
fill 180 145 363 180 148 363 minecraft:blue_terracotta
fill 181 145 362 181 148 362 minecraft:blue_terracotta
setblock 182 145 325 minecraft:dark_prismarine
setblock 182 145 327 minecraft:purple_concrete
setblock 182 145 339 minecraft:blue_terracotta
fill 182 145 346 182 146 346 minecraft:purple_concrete
setblock 182 145 352 minecraft:purple_concrete
setblock 182 145 360 minecraft:dark_prismarine
fill 182 145 361 182 148 361 minecraft:blue_terracotta
fill 141 146 349 141 216 349 minecraft:blue_terracotta
setblock 142 146 323 minecraft:blue_terracotta
setblock 142 146 324 minecraft:dark_prismarine
setblock 142 146 340 minecraft:purple_concrete
setblock 142 146 359 minecraft:dark_prismarine
fill 142 146 360 142 149 360 minecraft:blue_terracotta
setblock 143 146 323 minecraft:dark_prismarine
setblock 143 146 358 minecraft:dark_prismarine
fill 143 146 359 143 149 359 minecraft:blue_terracotta
setblock 143 146 362 minecraft:blue_terracotta
setblock 143 146 363 minecraft:dark_prismarine
fill 144 146 323 147 146 323 minecraft:blue_terracotta
setblock 144 146 361 minecraft:blue_terracotta
setblock 144 146 362 minecraft:dark_prismarine
fill 144 146 363 144 149 363 minecraft:blue_terracotta
fill 145 146 349 145 154 349 minecraft:magenta_terracotta
setblock 145 146 361 minecraft:dark_prismarine
fill 145 146 362 145 149 362 minecraft:blue_terracotta
fill 146 146 361 146 149 361 minecraft:blue_terracotta
setblock 148 146 323 minecraft:dark_prismarine
fill 148 146 324 151 146 324 minecraft:blue_terracotta
fill 148 146 360 148 148 360 minecraft:blue_terracotta
setblock 148 146 363 minecraft:dark_prismarine
fill 149 146 323 149 149 323 minecraft:blue_terracotta
setblock 149 146 362 minecraft:dark_prismarine
fill 149 146 363 149 149 363 minecraft:blue_terracotta
setblock 150 146 361 minecraft:dark_prismarine
fill 150 146 362 150 149 362 minecraft:blue_terracotta
setblock 151 146 360 minecraft:dark_prismarine
fill 151 146 361 151 149 361 minecraft:blue_terracotta
setblock 152 146 324 minecraft:dark_prismarine
fill 152 146 360 152 147 360 minecraft:blue_terracotta
setblock 153 146 323 minecraft:dark_prismarine
fill 153 146 324 153 149 324 minecraft:blue_terracotta
setblock 153 146 363 minecraft:dark_prismarine
fill 154 146 323 154 149 323 minecraft:blue_terracotta
setblock 154 146 362 minecraft:dark_prismarine
fill 154 146 363 154 149 363 minecraft:blue_terracotta
setblock 155 146 361 minecraft:dark_prismarine
fill 155 146 362 155 149 362 minecraft:blue_terracotta
setblock 157 146 323 minecraft:blue_terracotta
setblock 158 146 363 minecraft:dark_prismarine
fill 159 146 363 159 149 363 minecraft:blue_terracotta
fill 161 146 354 161 147 354 minecraft:dark_prismarine
fill 161 146 356 161 147 356 minecraft:dark_prismarine
fill 161 146 358 161 147 358 minecraft:dark_prismarine
fill 161 146 360 161 147 360 minecraft:dark_prismarine
fill 161 146 362 161 147 362 minecraft:dark_prismarine
fill 162 146 355 162 147 355 minecraft:dark_prismarine
fill 162 146 357 162 147 357 minecraft:dark_prismarine
fill 162 146 359 162 147 359 minecraft:dark_prismarine
fill 162 146 361 162 147 361 minecraft:dark_prismarine
fill 162 146 363 162 147 363 minecraft:dark_prismarine
fill 163 146 354 163 147 354 minecraft:dark_prismarine
fill 163 146 356 163 147 356 minecraft:dark_prismarine
fill 163 146 358 163 147 358 minecraft:dark_prismarine
fill 163 146 360 163 147 360 minecraft:dark_prismarine
fill 163 146 362 163 147 362 minecraft:dark_prismarine
setblock 163 146 363 minecraft:purple_concrete
fill 164 146 355 164 147 355 minecraft:dark_prismarine
fill 164 146 357 164 147 357 minecraft:dark_prismarine
fill 164 146 359 164 147 359 minecraft:dark_prismarine
fill 164 146 361 164 147 361 minecraft:dark_prismarine
fill 164 146 363 166 147 363 minecraft:blue_terracotta
fill 165 146 323 167 146 323 minecraft:blue_terracotta
fill 165 146 354 165 147 354 minecraft:dark_prismarine
fill 165 146 356 165 147 356 minecraft:dark_prismarine
fill 165 146 358 165 147 358 minecraft:dark_prismarine
fill 165 146 360 165 147 360 minecraft:dark_prismarine
fill 165 146 362 165 147 362 minecraft:dark_prismarine
fill 166 146 355 166 147 355 minecraft:dark_prismarine
fill 166 146 357 166 147 357 minecraft:dark_prismarine
fill 166 146 359 166 147 359 minecraft:dark_prismarine
fill 166 146 361 166 147 361 minecraft:dark_prismarine
setblock 167 146 324 minecraft:dark_prismarine
fill 167 146 354 167 147 354 minecraft:dark_prismarine
fill 167 146 356 167 147 356 minecraft:dark_prismarine
fill 167 146 358 167 147 358 minecraft:dark_prismarine
fill 167 146 360 167 147 360 minecraft:dark_prismarine
setblock 167 146 362 minecraft:dark_prismarine
setblock 168 146 323 minecraft:dark_prismarine
fill 168 146 324 168 149 324 minecraft:blue_terracotta
fill 168 146 355 168 147 355 minecraft:dark_prismarine
fill 168 146 357 168 147 357 minecraft:dark_prismarine
fill 168 146 359 168 147 359 minecraft:dark_prismarine
fill 168 146 361 168 147 361 minecraft:dark_prismarine
setblock 168 146 362 minecraft:blue_terracotta
setblock 168 146 363 minecraft:dark_prismarine
fill 169 146 323 169 149 323 minecraft:blue_terracotta
fill 169 146 354 169 147 354 minecraft:dark_prismarine
fill 169 146 356 169 147 356 minecraft:dark_prismarine
fill 169 146 358 169 147 358 minecraft:dark_prismarine
fill 169 146 360 169 147 360 minecraft:dark_prismarine
setblock 169 146 362 minecraft:dark_prismarine
fill 169 146 363 169 149 363 minecraft:blue_terracotta
setblock 170 146 325 minecraft:blue_terracotta
fill 170 146 362 170 149 362 minecraft:blue_terracotta
setblock 171 146 325 minecraft:dark_prismarine
setblock 172 146 323 minecraft:blue_terracotta
setblock 172 146 324 minecraft:dark_prismarine
fill 172 146 325 172 149 325 minecraft:blue_terracotta
fill 172 146 361 173 147 361 minecraft:blue_terracotta
setblock 173 146 323 minecraft:dark_prismarine
fill 173 146 324 173 149 324 minecraft:blue_terracotta
setblock 173 146 363 minecraft:dark_prismarine
fill 174 146 323 174 149 323 minecraft:blue_terracotta
fill 174 146 351 174 147 351 minecraft:magenta_terracotta
setblock 174 146 362 minecraft:dark_prismarine
fill 174 146 363 174 149 363 minecraft:blue_terracotta
setblock 175 146 325 minecraft:blue_terracotta
fill 175 146 362 175 149 362 minecraft:blue_terracotta
setblock 176 146 324 minecraft:blue_terracotta
setblock 176 146 325 minecraft:dark_prismarine
fill 176 146 331 176 156 331 minecraft:green_terracotta
setblock 177 146 324 minecraft:dark_prismarine
setblock 178 146 323 minecraft:dark_prismarine
fill 178 146 324 178 149 324 minecraft:blue_terracotta
setblock 178 146 363 minecraft:dark_prismarine
fill 179 146 323 179 149 323 minecraft:blue_terracotta
setblock 179 146 362 minecraft:dark_prismarine
fill 179 146 363 179 149 363 minecraft:blue_terracotta
fill 180 146 324 181 146 324 minecraft:blue_terracotta
fill 180 146 362 180 149 362 minecraft:blue_terracotta
fill 181 146 361 181 149 361 minecraft:blue_terracotta
setblock 182 146 324 minecraft:dark_prismarine
fill 182 146 325 182 148 326 minecraft:blue_terracotta
setblock 182 146 339 minecraft:dark_prismarine
fill 182 146 340 182 148 341 minecraft:blue_terracotta
setblock 182 146 359 minecraft:dark_prismarine
fill 182 146 360 182 149 360 minecraft:blue_terracotta
fill 141 147 350 141 155 351 minecraft:blue_terracotta
setblock 141 147 352 minecraft:cyan_concrete
setblock 142 147 323 minecraft:dark_prismarine
fill 142 147 324 142 149 325 minecraft:blue_terracotta
setblock 142 147 327 minecraft:purple_concrete
fill 142 147 341 142 147 342 minecraft:blue_terracotta
setblock 142 147 343 minecraft:dark_prismarine
fill 142 147 344 142 149 345 minecraft:blue_terracotta
setblock 142 147 346 minecraft:purple_concrete
fill 142 147 352 142 148 352 minecraft:purple_concrete
setblock 142 147 358 minecraft:dark_prismarine
fill 142 147 359 142 150 359 minecraft:blue_terracotta
setblock 142 147 363 minecraft:dark_prismarine
fill 143 147 323 146 147 323 minecraft:blue_terracotta
fill 143 147 358 143 150 358 minecraft:blue_terracotta
setblock 143 147 362 minecraft:dark_prismarine
fill 143 147 363 143 150 363 minecraft:blue_terracotta
fill 144 147 322 144 217 322 minecraft:blue_terracotta
setblock 144 147 360 minecraft:blue_terracotta
setblock 144 147 361 minecraft:dark_prismarine
fill 144 147 362 144 150 362 minecraft:blue_terracotta
setblock 145 147 322 minecraft:light_blue_wool
fill 145 147 361 145 150 361 minecraft:blue_terracotta
fill 146 147 322 147 192 322 minecraft:blue_terracotta
setblock 146 147 324 minecraft:dark_prismarine
setblock 147 147 323 minecraft:dark_prismarine
fill 147 147 324 150 147 324 minecraft:blue_terracotta
setblock 147 147 363 minecraft:dark_prismarine
fill 148 147 323 148 150 323 minecraft:blue_terracotta
setblock 148 147 362 minecraft:dark_prismarine
fill 148 147 363 148 150 363 minecraft:blue_terracotta
setblock 149 147 361 minecraft:dark_prismarine
fill 149 147 362 149 150 362 minecraft:blue_terracotta
setblock 150 147 360 minecraft:dark_prismarine
fill 150 147 361 150 150 361 minecraft:blue_terracotta
setblock 151 147 324 minecraft:dark_prismarine
fill 151 147 360 151 148 360 minecraft:blue_terracotta
setblock 152 147 323 minecraft:dark_prismarine
fill 152 147 324 152 150 324 minecraft:blue_terracotta
setblock 152 147 363 minecraft:dark_prismarine
fill 153 147 323 153 150 323 minecraft:blue_terracotta
setblock 153 147 362 minecraft:dark_prismarine
fill 153 147 363 153 150 363 minecraft:blue_terracotta
fill 154 147 324 154 148 324 minecraft:blue_terracotta
setblock 154 147 361 minecraft:dark_prismarine
fill 154 147 362 154 150 362 minecraft:blue_terracotta
setblock 155 147 361 minecraft:blue_terracotta
setblock 157 147 323 minecraft:dark_prismarine
setblock 157 147 363 minecraft:dark_prismarine
fill 158 147 323 158 150 323 minecraft:blue_terracotta
fill 158 147 363 158 149 363 minecraft:blue_terracotta
setblock 161 147 363 minecraft:blue_terracotta
fill 163 147 323 166 147 323 minecraft:blue_terracotta
fill 163 147 363 163 150 363 minecraft:blue_terracotta
setblock 166 147 324 minecraft:dark_prismarine
setblock 167 147 323 minecraft:dark_prismarine
fill 167 147 324 167 150 324 minecraft:blue_terracotta
setblock 167 147 362 minecraft:blue_terracotta
setblock 167 147 363 minecraft:dark_prismarine
fill 168 147 323 168 150 323 minecraft:blue_terracotta
setblock 168 147 362 minecraft:dark_prismarine
setblock 168 147 363 minecraft:blue_terracotta
setblock 169 147 325 minecraft:blue_terracotta
setblock 169 147 362 minecraft:blue_terracotta
setblock 170 147 325 minecraft:dark_prismarine
setblock 171 147 323 minecraft:blue_terracotta
setblock 171 147 324 minecraft:dark_prismarine
fill 171 147 325 171 150 325 minecraft:blue_terracotta
fill 171 147 352 171 160 352 minecraft:magenta_terracotta
fill 171 147 361 171 148 361 minecraft:blue_terracotta
setblock 172 147 323 minecraft:dark_prismarine
fill 172 147 324 172 150 324 minecraft:blue_terracotta
setblock 172 147 363 minecraft:dark_prismarine
fill 173 147 323 173 150 323 minecraft:blue_terracotta
setblock 173 147 362 minecraft:dark_prismarine
fill 173 147 363 173 150 363 minecraft:blue_terracotta
fill 174 147 362 174 150 362 minecraft:blue_terracotta
setblock 175 147 325 minecraft:dark_prismarine
setblock 176 147 324 minecraft:dark_prismarine
fill 176 147 325 177 149 325 minecraft:blue_terracotta
setblock 177 147 323 minecraft:dark_prismarine
fill 177 147 324 177 150 324 minecraft:blue_terracotta
setblock 177 147 363 minecraft:dark_prismarine
setblock 178 147 322 minecraft:light_blue_wool
fill 178 147 323 178 150 323 minecraft:blue_terracotta
setblock 178 147 362 minecraft:dark_prismarine
fill 178 147 363 178 150 363 minecraft:blue_terracotta
fill 179 147 362 179 150 362 minecraft:blue_terracotta
setblock 180 147 324 minecraft:blue_terracotta
setblock 181 147 324 minecraft:dark_prismarine
fill 181 147 325 181 150 325 minecraft:blue_terracotta
setblock 182 147 323 minecraft:dark_prismarine
fill 182 147 324 182 150 324 minecraft:blue_terracotta
setblock 182 147 327 minecraft:blue_terracotta
setblock 182 147 334 minecraft:purple_concrete
setblock 182 147 339 minecraft:blue_terracotta
setblock 182 147 342 minecraft:blue_terracotta
setblock 182 147 358 minecraft:dark_prismarine
fill 182 147 359 182 150 359 minecraft:blue_terracotta
setblock 182 147 363 minecraft:dark_prismarine
fill 141 148 352 141 220 352 minecraft:blue_terracotta
fill 142 148 323 145 148 323 minecraft:blue_terracotta
setblock 142 148 326 minecraft:blue_terracotta
setblock 142 148 333 minecraft:purple_concrete
fill 142 148 340 142 148 341 minecraft:blue_terracotta
setblock 142 148 342 minecraft:dark_prismarine
fill 142 148 343 142 151 343 minecraft:blue_terracotta
setblock 142 148 346 minecraft:blue_terracotta
setblock 142 148 347 minecraft:dark_prismarine
fill 142 148 348 142 151 348 minecraft:blue_terracotta
fill 142 148 355 142 149 355 minecraft:blue_terracotta
setblock 142 148 357 minecraft:dark_prismarine
fill 142 148 358 142 151 358 minecraft:blue_terracotta
setblock 142 148 361 minecraft:blue_terracotta
setblock 142 148 362 minecraft:dark_prismarine
fill 142 148 363 142 151 363 minecraft:blue_terracotta
setblock 143 148 361 minecraft:dark_prismarine
fill 143 148 362 143 151 362 minecraft:blue_terracotta
setblock 144 148 324 minecraft:blue_terracotta
setblock 144 148 360 minecraft:dark_prismarine
fill 144 148 361 144 150 361 minecraft:blue_terracotta
fill 145 148 322 145 220 322 minecraft:blue_terracotta
setblock 145 148 324 minecraft:dark_prismarine
setblock 146 148 323 minecraft:dark_prismarine
fill 146 148 324 149 148 324 minecraft:blue_terracotta
setblock 146 148 363 minecraft:dark_prismarine
fill 147 148 323 147 151 323 minecraft:blue_terracotta
setblock 147 148 360 minecraft:blue_terracotta
setblock 147 148 362 minecraft:dark_prismarine
fill 147 148 363 147 151 363 minecraft:blue_terracotta
setblock 148 148 361 minecraft:dark_prismarine
fill 148 148 362 148 151 362 minecraft:blue_terracotta
setblock 149 148 360 minecraft:dark_prismarine
fill 149 148 361 149 151 361 minecraft:blue_terracotta
setblock 150 148 324 minecraft:dark_prismarine
setblock 150 148 360 minecraft:blue_terracotta
setblock 151 148 323 minecraft:dark_prismarine
fill 151 148 324 151 151 324 minecraft:blue_terracotta
setblock 151 148 363 minecraft:dark_prismarine
fill 152 148 323 152 151 323 minecraft:blue_terracotta
setblock 152 148 362 minecraft:dark_prismarine
fill 152 148 363 152 151 363 minecraft:blue_terracotta
setblock 153 148 361 minecraft:dark_prismarine
fill 153 148 362 153 151 362 minecraft:blue_terracotta
setblock 154 148 361 minecraft:blue_terracotta
setblock 156 148 323 minecraft:dark_prismarine
setblock 156 148 363 minecraft:dark_prismarine
fill 157 148 323 157 151 323 minecraft:blue_terracotta
setblock 157 148 362 minecraft:dark_prismarine
fill 157 148 363 157 150 363 minecraft:blue_terracotta
fill 159 148 323 160 148 323 minecraft:blue_terracotta
setblock 161 148 323 minecraft:dark_prismarine
setblock 161 148 354 minecraft:sea_lantern
setblock 161 148 356 minecraft:sea_lantern
setblock 161 148 358 minecraft:sea_lantern
setblock 161 148 360 minecraft:sea_lantern
setblock 161 148 362 minecraft:sea_lantern
fill 161 148 363 161 151 363 minecraft:dark_prismarine
fill 162 148 323 165 148 323 minecraft:blue_terracotta
setblock 162 148 355 minecraft:sea_lantern
setblock 162 148 357 minecraft:sea_lantern
setblock 162 148 359 minecraft:sea_lantern
setblock 162 148 361 minecraft:sea_lantern
setblock 162 148 363 minecraft:sea_lantern
setblock 163 148 354 minecraft:sea_lantern
setblock 163 148 356 minecraft:sea_lantern
setblock 163 148 358 minecraft:sea_lantern
setblock 163 148 360 minecraft:sea_lantern
setblock 163 148 362 minecraft:sea_lantern
setblock 164 148 355 minecraft:sea_lantern
setblock 164 148 357 minecraft:sea_lantern
setblock 164 148 359 minecraft:sea_lantern
setblock 164 148 361 minecraft:sea_lantern
setblock 164 148 363 minecraft:sea_lantern
setblock 165 148 324 minecraft:dark_prismarine
setblock 165 148 354 minecraft:sea_lantern
setblock 165 148 356 minecraft:sea_lantern
setblock 165 148 358 minecraft:sea_lantern
setblock 165 148 360 minecraft:sea_lantern
setblock 165 148 362 minecraft:sea_lantern
setblock 165 148 363 minecraft:blue_terracotta
setblock 166 148 323 minecraft:dark_prismarine
fill 166 148 324 166 151 324 minecraft:blue_terracotta
setblock 166 148 355 minecraft:sea_lantern
setblock 166 148 357 minecraft:sea_lantern
setblock 166 148 359 minecraft:sea_lantern
setblock 166 148 361 minecraft:sea_lantern
setblock 166 148 362 minecraft:blue_terracotta
setblock 166 148 363 minecraft:sea_lantern
fill 167 148 323 167 151 323 minecraft:blue_terracotta
fill 167 148 325 168 148 325 minecraft:blue_terracotta
setblock 167 148 354 minecraft:sea_lantern
setblock 167 148 356 minecraft:sea_lantern
setblock 167 148 358 minecraft:sea_lantern
setblock 167 148 360 minecraft:sea_lantern
setblock 167 148 362 minecraft:sea_lantern
fill 167 148 363 167 151 363 minecraft:blue_terracotta
setblock 168 148 355 minecraft:sea_lantern
setblock 168 148 357 minecraft:sea_lantern
setblock 168 148 359 minecraft:sea_lantern
setblock 168 148 361 minecraft:sea_lantern
fill 168 148 362 168 151 362 minecraft:blue_terracotta
setblock 168 148 363 minecraft:sea_lantern
setblock 169 148 324 minecraft:blue_terracotta
setblock 169 148 325 minecraft:dark_prismarine
setblock 169 148 354 minecraft:sea_lantern
setblock 169 148 356 minecraft:sea_lantern
setblock 169 148 358 minecraft:sea_lantern
setblock 169 148 360 minecraft:sea_lantern
setblock 169 148 362 minecraft:sea_lantern
setblock 170 148 324 minecraft:dark_prismarine
fill 170 148 325 170 151 325 minecraft:blue_terracotta
setblock 171 148 323 minecraft:dark_prismarine
fill 171 148 324 171 151 324 minecraft:blue_terracotta
fill 171 148 326 172 148 326 minecraft:blue_terracotta
setblock 171 148 363 minecraft:dark_prismarine
fill 172 148 323 172 151 323 minecraft:blue_terracotta
setblock 172 148 361 minecraft:blue_terracotta
setblock 172 148 362 minecraft:dark_prismarine
fill 172 148 363 172 151 363 minecraft:blue_terracotta
setblock 173 148 325 minecraft:blue_terracotta
setblock 173 148 326 minecraft:dark_prismarine
fill 173 148 362 173 151 362 minecraft:blue_terracotta
setblock 174 148 325 minecraft:dark_prismarine
setblock 175 148 324 minecraft:dark_prismarine
fill 175 148 325 175 151 325 minecraft:blue_terracotta
setblock 176 148 323 minecraft:dark_prismarine
fill 176 148 324 176 151 324 minecraft:blue_terracotta
setblock 176 148 363 minecraft:dark_prismarine
fill 177 148 323 177 151 323 minecraft:blue_terracotta
setblock 177 148 362 minecraft:dark_prismarine
fill 177 148 363 177 151 363 minecraft:blue_terracotta
fill 178 148 322 178 157 322 minecraft:blue_terracotta
fill 178 148 339 178 204 339 minecraft:magenta_terracotta
fill 178 148 362 178 149 362 minecraft:blue_terracotta
setblock 180 148 324 minecraft:dark_prismarine
setblock 181 148 323 minecraft:dark_prismarine
fill 181 148 324 181 151 324 minecraft:blue_terracotta
fill 181 148 326 181 149 326 minecraft:blue_terracotta
setblock 181 148 363 minecraft:dark_prismarine
fill 182 148 323 182 151 323 minecraft:blue_terracotta
setblock 182 148 327 minecraft:dark_prismarine
fill 182 148 328 182 151 328 minecraft:blue_terracotta
setblock 182 148 342 minecraft:dark_prismarine
fill 182 148 343 182 150 344 minecraft:blue_terracotta
setblock 182 148 353 minecraft:purple_concrete
setblock 182 148 358 minecraft:blue_terracotta
setblock 182 148 362 minecraft:dark_prismarine
fill 182 148 363 182 151 363 minecraft:blue_terracotta
setblock 183 148 349 minecraft:cyan_concrete
fill 142 149 323 144 149 323 minecraft:blue_terracotta
setblock 142 149 326 minecraft:dark_prismarine
setblock 142 149 339 minecraft:purple_concrete
setblock 142 149 340 minecraft:blue_terracotta
setblock 142 149 341 minecraft:dark_prismarine
fill 142 149 342 142 152 342 minecraft:blue_terracotta
setblock 142 149 346 minecraft:dark_prismarine
fill 142 149 347 143 151 347 minecraft:blue_terracotta
fill 142 149 349 142 149 350 minecraft:blue_terracotta
setblock 142 149 356 minecraft:dark_prismarine
fill 142 149 357 142 152 357 minecraft:blue_terracotta
setblock 142 149 361 minecraft:dark_prismarine
fill 142 149 362 142 152 362 minecraft:blue_terracotta
setblock 143 149 324 minecraft:blue_terracotta
fill 143 149 343 143 149 344 minecraft:blue_terracotta
setblock 143 149 345 minecraft:dark_prismarine
fill 143 149 346 143 152 346 minecraft:blue_terracotta
setblock 143 149 360 minecraft:dark_prismarine
fill 143 149 361 143 152 361 minecraft:blue_terracotta
setblock 144 149 324 minecraft:dark_prismarine
setblock 144 149 325 minecraft:light[level=13]
setblock 144 149 332 minecraft:light[level=12]
setblock 144 149 333 minecraft:light[level=13]
setblock 144 149 339 minecraft:light[level=12]
setblock 144 149 341 minecraft:light[level=13]
setblock 144 149 346 minecraft:light[level=12]
setblock 144 149 349 minecraft:light[level=13]
setblock 144 149 353 minecraft:light[level=12]
setblock 144 149 357 minecraft:light[level=13]
setblock 144 149 360 minecraft:blue_terracotta
setblock 145 149 323 minecraft:dark_prismarine
fill 145 149 324 148 149 324 minecraft:blue_terracotta
setblock 145 149 363 minecraft:dark_prismarine
fill 146 149 323 146 152 323 minecraft:blue_terracotta
setblock 146 149 362 minecraft:dark_prismarine
fill 146 149 363 146 152 363 minecraft:blue_terracotta
setblock 147 149 361 minecraft:dark_prismarine
fill 147 149 362 147 152 362 minecraft:blue_terracotta
setblock 148 149 360 minecraft:dark_prismarine
fill 148 149 361 148 151 361 minecraft:blue_terracotta
setblock 149 149 324 minecraft:dark_prismarine
setblock 149 149 360 minecraft:blue_terracotta
setblock 150 149 323 minecraft:dark_prismarine
fill 150 149 324 150 152 324 minecraft:blue_terracotta
setblock 150 149 363 minecraft:dark_prismarine
fill 151 149 323 151 152 323 minecraft:blue_terracotta
setblock 151 149 325 minecraft:light[level=12]
setblock 151 149 332 minecraft:light[level=12]
setblock 151 149 339 minecraft:light[level=12]
setblock 151 149 346 minecraft:light[level=12]
setblock 151 149 353 minecraft:light[level=12]
setblock 151 149 360 minecraft:light[level=12]
setblock 151 149 362 minecraft:dark_prismarine
fill 151 149 363 151 152 363 minecraft:blue_terracotta
setblock 152 149 325 minecraft:light[level=13]
setblock 152 149 333 minecraft:light[level=13]
setblock 152 149 341 minecraft:light[level=13]
setblock 152 149 349 minecraft:light[level=13]
setblock 152 149 357 minecraft:light[level=13]
setblock 152 149 361 minecraft:dark_prismarine
fill 152 149 362 152 151 362 minecraft:blue_terracotta
setblock 153 149 361 minecraft:blue_terracotta
setblock 154 149 324 minecraft:dark_prismarine
setblock 155 149 323 minecraft:dark_prismarine
setblock 155 149 363 minecraft:dark_prismarine
fill 156 149 323 156 151 323 minecraft:blue_terracotta
setblock 156 149 362 minecraft:dark_prismarine
fill 156 149 363 156 151 363 minecraft:blue_terracotta
setblock 158 149 325 minecraft:light[level=12]
setblock 158 149 332 minecraft:light[level=12]
setblock 158 149 339 minecraft:light[level=12]
setblock 158 149 346 minecraft:light[level=12]
setblock 158 149 353 minecraft:light[level=12]
setblock 158 149 360 minecraft:light[level=12]
setblock 159 149 323 minecraft:blue_terracotta
setblock 160 149 323 minecraft:dark_prismarine
setblock 160 149 325 minecraft:light[level=13]
setblock 160 149 333 minecraft:light[level=13]
setblock 160 149 341 minecraft:light[level=13]
setblock 160 149 349 minecraft:light[level=13]
setblock 160 149 357 minecraft:light[level=13]
fill 161 149 323 164 149 323 minecraft:blue_terracotta
fill 161 149 354 161 150 354 minecraft:dark_prismarine
fill 161 149 356 161 150 356 minecraft:dark_prismarine
fill 161 149 358 161 150 358 minecraft:dark_prismarine
fill 161 149 360 161 150 360 minecraft:dark_prismarine
fill 161 149 362 161 150 362 minecraft:dark_prismarine
fill 162 149 355 162 150 355 minecraft:dark_prismarine
fill 162 149 357 162 150 357 minecraft:dark_prismarine
fill 162 149 359 162 150 359 minecraft:dark_prismarine
fill 162 149 361 162 150 361 minecraft:dark_prismarine
setblock 162 149 363 minecraft:blue_terracotta
fill 163 149 354 163 150 354 minecraft:dark_prismarine
fill 163 149 356 163 150 356 minecraft:dark_prismarine
fill 163 149 358 163 150 358 minecraft:dark_prismarine
fill 163 149 360 163 150 360 minecraft:dark_prismarine
fill 163 149 362 163 150 362 minecraft:dark_prismarine
setblock 164 149 324 minecraft:dark_prismarine
fill 164 149 355 164 150 355 minecraft:dark_prismarine
fill 164 149 357 164 150 357 minecraft:dark_prismarine
fill 164 149 359 164 150 359 minecraft:dark_prismarine
fill 164 149 361 164 150 361 minecraft:dark_prismarine
setblock 164 149 363 minecraft:blue_terracotta
setblock 165 149 323 minecraft:dark_prismarine
fill 165 149 324 165 152 324 minecraft:blue_terracotta
setblock 165 149 325 minecraft:light[level=12]
setblock 165 149 332 minecraft:light[level=12]
setblock 165 149 339 minecraft:light[level=12]
setblock 165 149 346 minecraft:light[level=12]
setblock 165 149 353 minecraft:light[level=12]
fill 165 149 354 165 150 354 minecraft:dark_prismarine
fill 165 149 356 165 150 356 minecraft:dark_prismarine
fill 165 149 358 165 150 358 minecraft:dark_prismarine
fill 165 149 360 165 150 360 minecraft:dark_prismarine
fill 165 149 362 165 149 363 minecraft:dark_prismarine
fill 166 149 323 166 152 323 minecraft:blue_terracotta
fill 166 149 325 167 149 325 minecraft:blue_terracotta
fill 166 149 355 166 150 355 minecraft:dark_prismarine
fill 166 149 357 166 150 357 minecraft:dark_prismarine
fill 166 149 359 166 150 359 minecraft:dark_prismarine
fill 166 149 361 166 149 362 minecraft:dark_prismarine
fill 166 149 363 166 150 363 minecraft:blue_terracotta
fill 167 149 354 167 150 354 minecraft:dark_prismarine
fill 167 149 356 167 150 356 minecraft:dark_prismarine
fill 167 149 358 167 150 358 minecraft:dark_prismarine
fill 167 149 360 167 150 360 minecraft:dark_prismarine
fill 167 149 362 167 150 362 minecraft:blue_terracotta
setblock 168 149 325 minecraft:dark_prismarine
setblock 168 149 333 minecraft:light[level=13]
setblock 168 149 341 minecraft:light[level=13]
setblock 168 149 349 minecraft:light[level=13]
fill 168 149 355 168 150 355 minecraft:dark_prismarine
fill 168 149 357 168 150 357 minecraft:dark_prismarine
fill 168 149 359 168 150 359 minecraft:dark_prismarine
fill 168 149 361 168 150 361 minecraft:dark_prismarine
fill 168 149 363 168 150 363 minecraft:blue_terracotta
setblock 169 149 324 minecraft:dark_prismarine
fill 169 149 325 169 151 326 minecraft:blue_terracotta
fill 169 149 354 169 150 354 minecraft:dark_prismarine
fill 169 149 356 169 150 356 minecraft:dark_prismarine
fill 169 149 358 169 150 358 minecraft:dark_prismarine
fill 169 149 360 169 150 360 minecraft:dark_prismarine
fill 169 149 362 169 150 362 minecraft:blue_terracotta
setblock 170 149 323 minecraft:dark_prismarine
fill 170 149 324 170 152 324 minecraft:blue_terracotta
fill 170 149 326 171 149 326 minecraft:blue_terracotta
setblock 170 149 363 minecraft:dark_prismarine
fill 171 149 323 171 152 323 minecraft:blue_terracotta
setblock 171 149 362 minecraft:dark_prismarine
fill 171 149 363 171 152 363 minecraft:blue_terracotta
setblock 172 149 326 minecraft:dark_prismarine
setblock 172 149 332 minecraft:light[level=12]
setblock 172 149 339 minecraft:light[level=12]
setblock 172 149 346 minecraft:light[level=12]
fill 172 149 353 172 183 353 minecraft:magenta_terracotta
setblock 172 149 360 minecraft:light[level=12]
fill 172 149 362 172 151 362 minecraft:blue_terracotta
setblock 173 149 325 minecraft:dark_prismarine
fill 173 149 326 173 151 326 minecraft:blue_terracotta
setblock 174 149 324 minecraft:dark_prismarine
fill 174 149 325 174 152 325 minecraft:blue_terracotta
setblock 175 149 323 minecraft:dark_prismarine
fill 175 149 324 175 152 324 minecraft:blue_terracotta
setblock 175 149 363 minecraft:dark_prismarine
fill 176 149 323 176 152 323 minecraft:blue_terracotta
setblock 176 149 333 minecraft:light[level=13]
setblock 176 149 341 minecraft:light[level=13]
setblock 176 149 349 minecraft:light[level=13]
setblock 176 149 357 minecraft:light[level=13]
setblock 176 149 362 minecraft:dark_prismarine
fill 176 149 363 176 152 363 minecraft:blue_terracotta
fill 177 149 362 177 150 362 minecraft:blue_terracotta
setblock 179 149 324 minecraft:dark_prismarine
setblock 179 149 325 minecraft:light[level=12]
setblock 179 149 332 minecraft:light[level=12]
setblock 179 149 339 minecraft:light[level=12]
setblock 179 149 346 minecraft:light[level=12]
setblock 179 149 353 minecraft:light[level=12]
setblock 179 149 360 minecraft:light[level=12]
setblock 180 149 323 minecraft:dark_prismarine
fill 180 149 324 180 152 324 minecraft:blue_terracotta
setblock 180 149 363 minecraft:dark_prismarine
fill 181 149 323 181 152 323 minecraft:blue_terracotta
setblock 181 149 362 minecraft:dark_prismarine
fill 181 149 363 181 152 363 minecraft:blue_terracotta
setblock 182 149 325 minecraft:blue_terracotta
setblock 182 149 326 minecraft:dark_prismarine
fill 182 149 327 182 152 327 minecraft:blue_terracotta
setblock 182 149 341 minecraft:dark_prismarine
fill 182 149 342 182 150 342 minecraft:blue_terracotta
setblock 182 149 345 minecraft:blue_terracotta
setblock 182 149 347 minecraft:purple_concrete
setblock 182 149 361 minecraft:dark_prismarine
fill 182 149 362 182 152 362 minecraft:blue_terracotta
fill 183 149 349 183 208 349 minecraft:blue_terracotta
setblock 141 150 327 minecraft:cyan_concrete
fill 141 150 328 141 217 328 minecraft:blue_terracotta
fill 142 150 323 142 150 324 minecraft:blue_terracotta
setblock 142 150 325 minecraft:dark_prismarine
fill 142 150 326 142 153 326 minecraft:blue_terracotta
fill 142 150 341 142 151 341 minecraft:blue_terracotta
setblock 142 150 344 minecraft:blue_terracotta
setblock 142 150 345 minecraft:dark_prismarine
fill 142 150 346 142 153 346 minecraft:blue_terracotta
setblock 142 150 349 minecraft:blue_terracotta
setblock 142 150 350 minecraft:dark_prismarine
fill 142 150 351 142 150 354 minecraft:blue_terracotta
setblock 142 150 355 minecraft:dark_prismarine
fill 142 150 356 142 153 356 minecraft:blue_terracotta
setblock 142 150 360 minecraft:dark_prismarine
fill 142 150 361 142 153 361 minecraft:blue_terracotta
setblock 143 150 323 minecraft:blue_terracotta
setblock 143 150 324 minecraft:dark_prismarine
setblock 143 150 343 minecraft:blue_terracotta
setblock 143 150 344 minecraft:dark_prismarine
fill 143 150 345 143 153 345 minecraft:blue_terracotta
setblock 143 150 348 minecraft:blue_terracotta
setblock 143 150 349 minecraft:dark_prismarine
setblock 143 150 359 minecraft:dark_prismarine
fill 143 150 360 143 152 360 minecraft:blue_terracotta
setblock 144 150 323 minecraft:dark_prismarine
fill 144 150 324 147 150 324 minecraft:blue_terracotta
setblock 144 150 363 minecraft:dark_prismarine
fill 145 150 323 145 153 323 minecraft:blue_terracotta
setblock 145 150 362 minecraft:dark_prismarine
fill 145 150 363 145 153 363 minecraft:blue_terracotta
setblock 146 150 361 minecraft:dark_prismarine
fill 146 150 362 146 153 362 minecraft:blue_terracotta
fill 147 150 361 147 152 361 minecraft:blue_terracotta
setblock 148 150 324 minecraft:dark_prismarine
setblock 149 150 323 minecraft:dark_prismarine
fill 149 150 324 149 153 324 minecraft:blue_terracotta
setblock 149 150 363 minecraft:dark_prismarine
fill 150 150 323 150 153 323 minecraft:blue_terracotta
setblock 150 150 362 minecraft:dark_prismarine
fill 150 150 363 150 153 363 minecraft:blue_terracotta
setblock 151 150 361 minecraft:dark_prismarine
fill 151 150 362 151 152 362 minecraft:blue_terracotta
setblock 152 150 361 minecraft:blue_terracotta
setblock 153 150 324 minecraft:dark_prismarine
fill 153 150 335 153 173 335 minecraft:magenta_terracotta
setblock 154 150 323 minecraft:dark_prismarine
setblock 154 150 324 minecraft:blue_terracotta
setblock 154 150 363 minecraft:dark_prismarine
fill 155 150 323 155 152 323 minecraft:blue_terracotta
fill 155 150 363 155 151 363 minecraft:blue_terracotta
setblock 159 150 323 minecraft:dark_prismarine
fill 160 150 323 163 150 323 minecraft:blue_terracotta
setblock 162 150 363 minecraft:dark_prismarine
setblock 163 150 324 minecraft:dark_prismarine
setblock 164 150 323 minecraft:dark_prismarine
fill 164 150 324 164 153 324 minecraft:blue_terracotta
setblock 164 150 363 minecraft:dark_prismarine
fill 165 150 323 165 153 323 minecraft:blue_terracotta
fill 165 150 325 166 150 325 minecraft:blue_terracotta
setblock 165 150 362 minecraft:dark_prismarine
fill 165 150 363 165 153 363 minecraft:blue_terracotta
setblock 166 150 361 minecraft:dark_prismarine
setblock 166 150 362 minecraft:blue_terracotta
setblock 167 150 325 minecraft:dark_prismarine
setblock 168 150 324 minecraft:dark_prismarine
fill 168 150 325 168 152 326 minecraft:blue_terracotta
setblock 169 150 323 minecraft:dark_prismarine
fill 169 150 324 169 153 324 minecraft:blue_terracotta
setblock 169 150 363 minecraft:dark_prismarine
fill 170 150 323 170 153 323 minecraft:blue_terracotta
setblock 170 150 326 minecraft:blue_terracotta
setblock 170 150 362 minecraft:dark_prismarine
fill 170 150 363 170 153 363 minecraft:blue_terracotta
setblock 171 150 326 minecraft:dark_prismarine
fill 171 150 362 171 152 362 minecraft:blue_terracotta
setblock 172 150 325 minecraft:dark_prismarine
fill 172 150 326 172 152 326 minecraft:blue_terracotta
setblock 173 150 324 minecraft:dark_prismarine
fill 173 150 325 173 153 325 minecraft:blue_terracotta
setblock 174 150 323 minecraft:dark_prismarine
fill 174 150 324 174 153 324 minecraft:blue_terracotta
setblock 174 150 363 minecraft:dark_prismarine
fill 175 150 323 175 153 323 minecraft:blue_terracotta
setblock 175 150 362 minecraft:dark_prismarine
fill 175 150 363 175 153 363 minecraft:blue_terracotta
setblock 176 150 325 minecraft:blue_terracotta
setblock 176 150 362 minecraft:blue_terracotta
setblock 177 150 325 minecraft:dark_prismarine
setblock 178 150 324 minecraft:dark_prismarine
setblock 179 150 323 minecraft:dark_prismarine
fill 179 150 324 179 153 324 minecraft:blue_terracotta
setblock 179 150 363 minecraft:dark_prismarine
fill 180 150 323 180 153 323 minecraft:blue_terracotta
setblock 180 150 362 minecraft:dark_prismarine
fill 180 150 363 180 153 363 minecraft:blue_terracotta
setblock 181 150 326 minecraft:dark_prismarine
fill 181 150 362 181 151 362 minecraft:blue_terracotta
setblock 182 150 325 minecraft:dark_prismarine
fill 182 150 326 182 153 326 minecraft:blue_terracotta
setblock 182 150 329 minecraft:blue_terracotta
setblock 182 150 341 minecraft:purple_concrete
setblock 182 150 345 minecraft:dark_prismarine
fill 182 150 346 182 153 346 minecraft:blue_terracotta
setblock 182 150 360 minecraft:dark_prismarine
fill 182 150 361 182 153 361 minecraft:blue_terracotta
fill 141 151 327 142 152 327 minecraft:blue_terracotta
setblock 142 151 323 minecraft:blue_terracotta
setblock 142 151 324 minecraft:dark_prismarine
fill 142 151 325 143 151 325 minecraft:blue_terracotta
setblock 142 151 332 minecraft:purple_concrete
setblock 142 151 344 minecraft:dark_prismarine
fill 142 151 345 142 154 345 minecraft:blue_terracotta
setblock 142 151 349 minecraft:dark_prismarine
fill 142 151 350 142 151 353 minecraft:blue_terracotta
setblock 142 151 354 minecraft:dark_prismarine
fill 142 151 355 142 154 355 minecraft:blue_terracotta
setblock 142 151 359 minecraft:dark_prismarine
fill 142 151 360 142 154 360 minecraft:blue_terracotta
setblock 143 151 323 minecraft:dark_prismarine
fill 143 151 324 146 151 324 minecraft:blue_terracotta
setblock 143 151 343 minecraft:dark_prismarine
fill 143 151 344 143 154 344 minecraft:blue_terracotta
setblock 143 151 348 minecraft:dark_prismarine
fill 143 151 349 143 153 350 minecraft:blue_terracotta
setblock 143 151 359 minecraft:blue_terracotta
setblock 143 151 363 minecraft:dark_prismarine
fill 144 151 323 144 154 323 minecraft:blue_terracotta
fill 144 151 345 144 151 346 minecraft:blue_terracotta
setblock 144 151 347 minecraft:dark_prismarine
fill 144 151 348 144 154 348 minecraft:blue_terracotta
setblock 144 151 362 minecraft:dark_prismarine
fill 144 151 363 144 154 363 minecraft:blue_terracotta
setblock 145 151 361 minecraft:dark_prismarine
fill 145 151 362 145 154 362 minecraft:blue_terracotta
setblock 146 151 361 minecraft:blue_terracotta
setblock 147 151 324 minecraft:dark_prismarine
setblock 148 151 323 minecraft:dark_prismarine
fill 148 151 324 148 154 324 minecraft:blue_terracotta
setblock 148 151 363 minecraft:dark_prismarine
fill 149 151 323 149 154 323 minecraft:blue_terracotta
setblock 149 151 362 minecraft:dark_prismarine
fill 149 151 363 149 154 363 minecraft:blue_terracotta
setblock 150 151 361 minecraft:dark_prismarine
fill 150 151 362 150 153 362 minecraft:blue_terracotta
setblock 152 151 324 minecraft:dark_prismarine
fill 152 151 333 152 187 333 minecraft:magenta_terracotta
setblock 153 151 323 minecraft:dark_prismarine
setblock 153 151 324 minecraft:blue_terracotta
fill 153 151 334 153 189 334 minecraft:magenta_terracotta
setblock 153 151 363 minecraft:dark_prismarine
fill 154 151 323 154 152 323 minecraft:blue_terracotta
fill 154 151 363 154 152 363 minecraft:blue_terracotta
fill 159 151 323 162 151 323 minecraft:blue_terracotta
setblock 161 151 354 minecraft:sea_lantern
setblock 161 151 356 minecraft:sea_lantern
setblock 161 151 358 minecraft:sea_lantern
setblock 161 151 360 minecraft:sea_lantern
setblock 161 151 362 minecraft:sea_lantern
fill 162 151 324 162 152 324 minecraft:dark_prismarine
setblock 162 151 355 minecraft:sea_lantern
setblock 162 151 357 minecraft:sea_lantern
setblock 162 151 359 minecraft:sea_lantern
setblock 162 151 361 minecraft:sea_lantern
setblock 162 151 363 minecraft:sea_lantern
setblock 163 151 323 minecraft:dark_prismarine
fill 163 151 324 163 154 324 minecraft:blue_terracotta
fill 163 151 325 163 154 325 minecraft:dark_prismarine
setblock 163 151 354 minecraft:sea_lantern
setblock 163 151 356 minecraft:sea_lantern
setblock 163 151 358 minecraft:sea_lantern
setblock 163 151 360 minecraft:sea_lantern
setblock 163 151 362 minecraft:sea_lantern
fill 163 151 363 163 159 363 minecraft:dark_prismarine
fill 164 151 323 164 154 323 minecraft:blue_terracotta
setblock 164 151 355 minecraft:sea_lantern
setblock 164 151 357 minecraft:sea_lantern
setblock 164 151 359 minecraft:sea_lantern
setblock 164 151 361 minecraft:sea_lantern
setblock 164 151 363 minecraft:sea_lantern
setblock 165 151 325 minecraft:blue_terracotta
setblock 165 151 354 minecraft:sea_lantern
setblock 165 151 356 minecraft:sea_lantern
setblock 165 151 358 minecraft:sea_lantern
setblock 165 151 360 minecraft:sea_lantern
setblock 165 151 362 minecraft:sea_lantern
setblock 166 151 325 minecraft:dark_prismarine
setblock 166 151 355 minecraft:sea_lantern
setblock 166 151 357 minecraft:sea_lantern
setblock 166 151 359 minecraft:sea_lantern
setblock 166 151 361 minecraft:sea_lantern
fill 166 151 362 166 162 362 minecraft:dark_prismarine
setblock 166 151 363 minecraft:sea_lantern
setblock 167 151 324 minecraft:dark_prismarine
fill 167 151 325 167 153 326 minecraft:blue_terracotta
setblock 167 151 354 minecraft:sea_lantern
setblock 167 151 356 minecraft:sea_lantern
setblock 167 151 358 minecraft:sea_lantern
setblock 167 151 360 minecraft:sea_lantern
setblock 167 151 362 minecraft:sea_lantern
setblock 168 151 323 minecraft:dark_prismarine
fill 168 151 324 168 154 324 minecraft:blue_terracotta
setblock 168 151 355 minecraft:sea_lantern
setblock 168 151 357 minecraft:sea_lantern
setblock 168 151 359 minecraft:sea_lantern
setblock 168 151 361 minecraft:sea_lantern
setblock 168 151 363 minecraft:sea_lantern
fill 169 151 323 169 154 323 minecraft:blue_terracotta
setblock 169 151 354 minecraft:sea_lantern
setblock 169 151 356 minecraft:sea_lantern
setblock 169 151 358 minecraft:sea_lantern
setblock 169 151 360 minecraft:sea_lantern
setblock 169 151 362 minecraft:sea_lantern
fill 169 151 363 169 154 363 minecraft:blue_terracotta
setblock 170 151 326 minecraft:dark_prismarine
fill 170 151 362 170 152 362 minecraft:blue_terracotta
setblock 171 151 325 minecraft:dark_prismarine
fill 171 151 326 171 153 326 minecraft:blue_terracotta
setblock 172 151 324 minecraft:dark_prismarine
fill 172 151 325 172 154 325 minecraft:blue_terracotta
setblock 173 151 323 minecraft:dark_prismarine
fill 173 151 324 173 154 324 minecraft:blue_terracotta
setblock 173 151 363 minecraft:dark_prismarine
fill 174 151 323 174 154 323 minecraft:blue_terracotta
setblock 174 151 362 minecraft:dark_prismarine
fill 174 151 363 174 154 363 minecraft:blue_terracotta
setblock 176 151 325 minecraft:dark_prismarine
setblock 177 151 324 minecraft:dark_prismarine
setblock 177 151 325 minecraft:blue_terracotta
setblock 178 151 323 minecraft:dark_prismarine
fill 178 151 324 178 154 324 minecraft:blue_terracotta
setblock 178 151 363 minecraft:dark_prismarine
fill 179 151 323 179 154 323 minecraft:blue_terracotta
fill 179 151 363 179 154 363 minecraft:blue_terracotta
setblock 181 151 325 minecraft:dark_prismarine
fill 181 151 326 181 154 326 minecraft:blue_terracotta
setblock 182 151 324 minecraft:dark_prismarine
fill 182 151 325 182 154 325 minecraft:blue_terracotta
setblock 182 151 329 minecraft:dark_prismarine
setblock 182 151 335 minecraft:purple_concrete
setblock 182 151 343 minecraft:blue_terracotta
setblock 182 151 344 minecraft:dark_prismarine
fill 182 151 345 182 153 345 minecraft:blue_terracotta
fill 182 151 347 182 152 347 minecraft:blue_terracotta
setblock 182 151 354 minecraft:purple_concrete
setblock 182 151 359 minecraft:dark_prismarine
fill 182 151 360 182 154 360 minecraft:blue_terracotta
setblock 142 152 323 minecraft:dark_prismarine
fill 142 152 324 142 154 325 minecraft:blue_terracotta
setblock 142 152 338 minecraft:purple_concrete
setblock 142 152 343 minecraft:dark_prismarine
fill 142 152 344 142 155 344 minecraft:blue_terracotta
setblock 142 152 347 minecraft:blue_terracotta
setblock 142 152 348 minecraft:dark_prismarine
fill 142 152 349 142 152 352 minecraft:blue_terracotta
setblock 142 152 353 minecraft:dark_prismarine
fill 142 152 354 142 155 354 minecraft:blue_terracotta
setblock 142 152 358 minecraft:dark_prismarine
fill 142 152 359 142 155 359 minecraft:blue_terracotta
setblock 142 152 363 minecraft:dark_prismarine
fill 143 152 323 143 153 324 minecraft:blue_terracotta
fill 143 152 343 143 153 343 minecraft:blue_terracotta
setblock 143 152 347 minecraft:dark_prismarine
fill 143 152 348 143 155 348 minecraft:blue_terracotta
setblock 143 152 351 minecraft:blue_terracotta
setblock 143 152 352 minecraft:dark_prismarine
setblock 143 152 362 minecraft:dark_prismarine
fill 143 152 363 143 155 363 minecraft:blue_terracotta
fill 144 152 324 145 152 324 minecraft:blue_terracotta
setblock 144 152 345 minecraft:blue_terracotta
setblock 144 152 346 minecraft:dark_prismarine
fill 144 152 347 144 155 347 minecraft:blue_terracotta
fill 144 152 349 144 153 349 minecraft:blue_terracotta
fill 144 152 362 144 154 362 minecraft:blue_terracotta
setblock 146 152 324 minecraft:dark_prismarine
setblock 147 152 323 minecraft:dark_prismarine
fill 147 152 324 147 155 324 minecraft:blue_terracotta
setblock 147 152 363 minecraft:dark_prismarine
fill 148 152 323 148 155 323 minecraft:blue_terracotta
setblock 148 152 362 minecraft:dark_prismarine
fill 148 152 363 148 155 363 minecraft:blue_terracotta
fill 149 152 362 149 153 362 minecraft:blue_terracotta
setblock 151 152 324 minecraft:dark_prismarine
setblock 152 152 323 minecraft:dark_prismarine
setblock 152 152 324 minecraft:blue_terracotta
fill 152 152 336 152 154 336 minecraft:magenta_terracotta
setblock 152 152 363 minecraft:dark_prismarine
fill 153 152 323 153 153 323 minecraft:blue_terracotta
setblock 153 152 363 minecraft:blue_terracotta
fill 160 152 323 161 152 323 minecraft:blue_terracotta
fill 161 152 354 161 153 354 minecraft:dark_prismarine
fill 161 152 356 161 153 356 minecraft:dark_prismarine
fill 161 152 358 161 153 358 minecraft:dark_prismarine
fill 161 152 360 161 153 360 minecraft:dark_prismarine
fill 161 152 362 161 153 362 minecraft:dark_prismarine
setblock 161 152 363 minecraft:purple_concrete
setblock 162 152 323 minecraft:dark_prismarine
fill 162 152 325 162 153 325 minecraft:dark_prismarine
fill 162 152 355 162 153 355 minecraft:dark_prismarine
fill 162 152 357 162 153 357 minecraft:dark_prismarine
fill 162 152 359 162 153 359 minecraft:dark_prismarine
fill 162 152 361 162 153 361 minecraft:dark_prismarine
fill 162 152 363 162 153 363 minecraft:dark_prismarine
fill 163 152 323 163 155 323 minecraft:blue_terracotta
fill 163 152 326 163 154 326 minecraft:dark_prismarine
fill 163 152 354 163 153 354 minecraft:dark_prismarine
fill 163 152 356 163 153 356 minecraft:dark_prismarine
fill 163 152 358 163 153 358 minecraft:dark_prismarine
fill 163 152 360 163 153 360 minecraft:dark_prismarine
fill 163 152 362 163 153 362 minecraft:dark_prismarine
fill 164 152 325 165 152 325 minecraft:dark_prismarine
fill 164 152 355 164 153 355 minecraft:dark_prismarine
fill 164 152 357 164 153 357 minecraft:dark_prismarine
fill 164 152 359 164 153 359 minecraft:dark_prismarine
fill 164 152 361 164 153 361 minecraft:dark_prismarine
setblock 164 152 363 minecraft:blue_terracotta
fill 165 152 354 165 153 354 minecraft:dark_prismarine
fill 165 152 356 165 153 356 minecraft:dark_prismarine
fill 165 152 358 165 153 358 minecraft:dark_prismarine
fill 165 152 360 165 153 360 minecraft:dark_prismarine
fill 165 152 362 165 153 362 minecraft:dark_prismarine
setblock 166 152 324 minecraft:dark_prismarine
fill 166 152 325 166 155 325 minecraft:blue_terracotta
fill 166 152 355 166 153 355 minecraft:dark_prismarine
fill 166 152 357 166 153 357 minecraft:dark_prismarine
fill 166 152 359 166 153 359 minecraft:dark_prismarine
fill 166 152 361 166 153 361 minecraft:dark_prismarine
setblock 166 152 363 minecraft:blue_terracotta
setblock 167 152 323 minecraft:dark_prismarine
fill 167 152 324 167 155 324 minecraft:blue_terracotta
fill 167 152 354 167 153 354 minecraft:dark_prismarine
fill 167 152 356 167 153 356 minecraft:dark_prismarine
fill 167 152 358 167 153 358 minecraft:dark_prismarine
fill 167 152 360 167 153 360 minecraft:dark_prismarine
fill 167 152 362 167 152 363 minecraft:dark_prismarine
fill 168 152 323 168 155 323 minecraft:blue_terracotta
fill 168 152 355 168 153 355 minecraft:dark_prismarine
fill 168 152 357 168 153 357 minecraft:dark_prismarine
fill 168 152 359 168 153 359 minecraft:dark_prismarine
fill 168 152 361 168 153 362 minecraft:dark_prismarine
fill 168 152 363 168 153 363 minecraft:blue_terracotta
setblock 169 152 325 minecraft:blue_terracotta
setblock 169 152 326 minecraft:dark_prismarine
fill 169 152 354 169 153 354 minecraft:dark_prismarine
fill 169 152 356 169 153 356 minecraft:dark_prismarine
fill 169 152 358 169 153 358 minecraft:dark_prismarine
fill 169 152 360 169 153 360 minecraft:dark_prismarine
setblock 169 152 362 minecraft:blue_terracotta
setblock 170 152 325 minecraft:dark_prismarine
fill 170 152 326 170 154 326 minecraft:blue_terracotta
setblock 171 152 324 minecraft:dark_prismarine
fill 171 152 325 171 155 325 minecraft:blue_terracotta
setblock 172 152 323 minecraft:dark_prismarine
fill 172 152 324 172 155 324 minecraft:blue_terracotta
setblock 172 152 363 minecraft:dark_prismarine
fill 173 152 323 173 155 323 minecraft:blue_terracotta
fill 173 152 363 173 154 363 minecraft:blue_terracotta
setblock 175 152 325 minecraft:dark_prismarine
setblock 176 152 324 minecraft:dark_prismarine
setblock 177 152 323 minecraft:dark_prismarine
fill 177 152 324 177 154 324 minecraft:blue_terracotta
setblock 177 152 363 minecraft:dark_prismarine
fill 178 152 323 178 155 323 minecraft:blue_terracotta
fill 178 152 363 178 153 363 minecraft:blue_terracotta
setblock 181 152 324 minecraft:dark_prismarine
fill 181 152 325 181 155 325 minecraft:blue_terracotta
setblock 182 152 323 minecraft:dark_prismarine
fill 182 152 324 182 155 324 minecraft:blue_terracotta
setblock 182 152 328 minecraft:dark_prismarine
fill 182 152 329 182 155 329 minecraft:blue_terracotta
setblock 182 152 344 minecraft:blue_terracotta
setblock 182 152 348 minecraft:dark_prismarine
setblock 182 152 363 minecraft:dark_prismarine
setblock 183 152 335 minecraft:light_blue_wool
fill 141 153 327 141 220 327 minecraft:blue_terracotta
fill 142 153 323 142 156 323 minecraft:blue_terracotta
setblock 142 153 327 minecraft:dark_prismarine
setblock 142 153 342 minecraft:dark_prismarine
fill 142 153 343 142 156 343 minecraft:blue_terracotta
setblock 142 153 347 minecraft:dark_prismarine
fill 142 153 348 142 153 351 minecraft:blue_terracotta
setblock 142 153 352 minecraft:dark_prismarine
fill 142 153 353 143 155 353 minecraft:blue_terracotta
setblock 142 153 357 minecraft:dark_prismarine
fill 142 153 358 142 156 358 minecraft:blue_terracotta
setblock 142 153 362 minecraft:dark_prismarine
fill 142 153 363 142 156 363 minecraft:blue_terracotta
setblock 143 153 346 minecraft:dark_prismarine
fill 143 153 347 143 156 347 minecraft:blue_terracotta
setblock 143 153 351 minecraft:dark_prismarine
fill 143 153 352 143 156 352 minecraft:blue_terracotta
setblock 143 153 361 minecraft:dark_prismarine
setblock 143 153 362 minecraft:blue_terracotta
setblock 144 153 324 minecraft:blue_terracotta
setblock 144 153 345 minecraft:dark_prismarine
fill 144 153 346 144 156 346 minecraft:blue_terracotta
setblock 144 153 350 minecraft:dark_prismarine
setblock 145 153 324 minecraft:dark_prismarine
setblock 146 153 323 minecraft:dark_prismarine
fill 146 153 324 146 155 324 minecraft:blue_terracotta
setblock 146 153 363 minecraft:dark_prismarine
fill 147 153 323 147 156 323 minecraft:blue_terracotta
setblock 147 153 362 minecraft:dark_prismarine
fill 147 153 363 147 156 363 minecraft:blue_terracotta
fill 148 153 362 148 154 362 minecraft:blue_terracotta
setblock 150 153 324 minecraft:dark_prismarine
setblock 151 153 323 minecraft:dark_prismarine
fill 151 153 333 151 154 333 minecraft:magenta_terracotta
setblock 151 153 363 minecraft:dark_prismarine
fill 152 153 323 152 154 323 minecraft:blue_terracotta
setblock 152 153 363 minecraft:blue_terracotta
setblock 157 153 323 minecraft:purple_concrete
setblock 161 153 323 minecraft:dark_prismarine
fill 161 153 363 161 161 363 minecraft:dark_prismarine
fill 162 153 323 162 156 323 minecraft:blue_terracotta
fill 162 153 326 162 154 327 minecraft:dark_prismarine
fill 163 153 327 164 154 327 minecraft:dark_prismarine
fill 164 153 325 164 153 326 minecraft:dark_prismarine
setblock 164 153 363 minecraft:dark_prismarine
setblock 165 153 324 minecraft:dark_prismarine
fill 165 153 325 165 156 325 minecraft:blue_terracotta
setblock 166 153 323 minecraft:dark_prismarine
fill 166 153 324 166 156 324 minecraft:blue_terracotta
setblock 166 153 363 minecraft:dark_prismarine
fill 167 153 323 167 156 323 minecraft:blue_terracotta
setblock 167 153 362 minecraft:dark_prismarine
fill 167 153 363 167 156 363 minecraft:blue_terracotta
setblock 168 153 325 minecraft:blue_terracotta
setblock 168 153 326 minecraft:dark_prismarine
setblock 169 153 325 minecraft:dark_prismarine
fill 169 153 326 169 155 326 minecraft:blue_terracotta
setblock 169 153 362 minecraft:dark_prismarine
setblock 170 153 324 minecraft:dark_prismarine
fill 170 153 325 170 156 325 minecraft:blue_terracotta
setblock 171 153 323 minecraft:dark_prismarine
fill 171 153 324 171 156 324 minecraft:blue_terracotta
setblock 171 153 363 minecraft:dark_prismarine
fill 172 153 323 172 156 323 minecraft:blue_terracotta
fill 172 153 341 172 154 342 minecraft:spruce_planks
fill 172 153 363 172 154 363 minecraft:blue_terracotta
setblock 174 153 325 minecraft:dark_prismarine
setblock 175 153 324 minecraft:dark_prismarine
setblock 176 153 323 minecraft:dark_prismarine
fill 176 153 324 176 155 324 minecraft:blue_terracotta
setblock 176 153 363 minecraft:dark_prismarine
fill 177 153 323 177 156 323 minecraft:blue_terracotta
setblock 177 153 363 minecraft:blue_terracotta
setblock 180 153 324 minecraft:dark_prismarine
setblock 181 153 323 minecraft:dark_prismarine
fill 181 153 324 181 156 324 minecraft:blue_terracotta
setblock 181 153 363 minecraft:dark_prismarine
fill 182 153 323 182 156 323 minecraft:blue_terracotta
setblock 182 153 327 minecraft:dark_prismarine
fill 182 153 328 182 156 328 minecraft:blue_terracotta
setblock 182 153 342 minecraft:purple_concrete
setblock 182 153 347 minecraft:dark_prismarine
fill 182 153 348 182 155 349 minecraft:blue_terracotta
setblock 182 153 362 minecraft:dark_prismarine
fill 182 153 363 182 156 363 minecraft:blue_terracotta
fill 183 153 335 183 177 335 minecraft:blue_terracotta
fill 141 154 358 141 218 358 minecraft:blue_terracotta
setblock 141 154 359 minecraft:cyan_concrete
fill 141 154 360 141 221 360 minecraft:blue_terracotta
setblock 142 154 326 minecraft:dark_prismarine
fill 142 154 327 142 157 327 minecraft:blue_terracotta
setblock 142 154 342 minecraft:blue_terracotta
setblock 142 154 346 minecraft:dark_prismarine
fill 142 154 347 142 154 350 minecraft:blue_terracotta
setblock 142 154 351 minecraft:dark_prismarine
fill 142 154 352 142 157 352 minecraft:blue_terracotta
setblock 142 154 356 minecraft:dark_prismarine
fill 142 154 357 142 157 357 minecraft:blue_terracotta
setblock 142 154 361 minecraft:dark_prismarine
fill 142 154 362 142 157 362 minecraft:blue_terracotta
fill 142 154 364 142 220 364 minecraft:blue_terracotta
fill 143 154 323 143 155 323 minecraft:blue_terracotta
setblock 143 154 345 minecraft:dark_prismarine
fill 143 154 346 143 157 346 minecraft:blue_terracotta
setblock 143 154 349 minecraft:blue_terracotta
setblock 143 154 350 minecraft:dark_prismarine
fill 143 154 351 144 156 351 minecraft:blue_terracotta
setblock 143 154 354 minecraft:blue_terracotta
setblock 143 154 364 minecraft:light_blue_wool
setblock 144 154 324 minecraft:dark_prismarine
fill 144 154 345 144 157 345 minecraft:blue_terracotta
setblock 144 154 349 minecraft:dark_prismarine
fill 144 154 350 144 157 350 minecraft:blue_terracotta
setblock 145 154 323 minecraft:dark_prismarine
fill 145 154 324 145 155 324 minecraft:blue_terracotta
setblock 145 154 363 minecraft:dark_prismarine
fill 146 154 323 146 157 323 minecraft:blue_terracotta
setblock 146 154 362 minecraft:dark_prismarine
fill 146 154 363 146 157 363 minecraft:blue_terracotta
setblock 147 154 362 minecraft:blue_terracotta
setblock 149 154 324 minecraft:dark_prismarine
setblock 150 154 323 minecraft:dark_prismarine
setblock 150 154 363 minecraft:dark_prismarine
setblock 151 154 323 minecraft:blue_terracotta
setblock 151 154 363 minecraft:blue_terracotta
fill 159 154 357 159 162 357 minecraft:green_terracotta
fill 161 154 323 161 157 323 minecraft:blue_terracotta
setblock 161 154 354 minecraft:sea_lantern
setblock 161 154 356 minecraft:sea_lantern
setblock 161 154 358 minecraft:sea_lantern
setblock 161 154 360 minecraft:sea_lantern
setblock 161 154 362 minecraft:sea_lantern
fill 162 154 324 162 155 324 minecraft:blue_terracotta
fill 162 154 328 164 155 328 minecraft:dark_prismarine
setblock 162 154 355 minecraft:sea_lantern
setblock 162 154 357 minecraft:sea_lantern
setblock 162 154 359 minecraft:sea_lantern
setblock 162 154 361 minecraft:sea_lantern
setblock 162 154 363 minecraft:sea_lantern
fill 163 154 329 163 156 329 minecraft:dark_prismarine
setblock 163 154 354 minecraft:sea_lantern
setblock 163 154 356 minecraft:sea_lantern
setblock 163 154 358 minecraft:sea_lantern
setblock 163 154 360 minecraft:sea_lantern
setblock 163 154 362 minecraft:sea_lantern
setblock 164 154 324 minecraft:dark_prismarine
fill 164 154 325 164 157 325 minecraft:blue_terracotta
setblock 164 154 326 minecraft:dark_prismarine
setblock 164 154 355 minecraft:sea_lantern
setblock 164 154 357 minecraft:sea_lantern
setblock 164 154 359 minecraft:sea_lantern
setblock 164 154 361 minecraft:sea_lantern
setblock 164 154 363 minecraft:sea_lantern
setblock 165 154 323 minecraft:dark_prismarine
fill 165 154 324 165 157 324 minecraft:blue_terracotta
setblock 165 154 354 minecraft:sea_lantern
setblock 165 154 356 minecraft:sea_lantern
setblock 165 154 358 minecraft:sea_lantern
setblock 165 154 360 minecraft:sea_lantern
setblock 165 154 362 minecraft:sea_lantern
fill 165 154 363 165 159 363 minecraft:dark_prismarine
fill 166 154 323 166 157 323 minecraft:blue_terracotta
setblock 166 154 355 minecraft:sea_lantern
setblock 166 154 357 minecraft:sea_lantern
setblock 166 154 359 minecraft:sea_lantern
setblock 166 154 361 minecraft:sea_lantern
setblock 166 154 363 minecraft:sea_lantern
setblock 167 154 325 minecraft:blue_terracotta
setblock 167 154 326 minecraft:dark_prismarine
setblock 167 154 354 minecraft:sea_lantern
setblock 167 154 356 minecraft:sea_lantern
setblock 167 154 358 minecraft:sea_lantern
setblock 167 154 360 minecraft:sea_lantern
setblock 167 154 362 minecraft:sea_lantern
setblock 168 154 325 minecraft:dark_prismarine
fill 168 154 326 168 157 326 minecraft:blue_terracotta
setblock 168 154 355 minecraft:sea_lantern
setblock 168 154 357 minecraft:sea_lantern
setblock 168 154 359 minecraft:sea_lantern
setblock 168 154 361 minecraft:sea_lantern
fill 168 154 362 168 162 362 minecraft:dark_prismarine
setblock 168 154 363 minecraft:sea_lantern
setblock 169 154 324 minecraft:dark_prismarine
fill 169 154 325 169 157 325 minecraft:blue_terracotta
setblock 169 154 354 minecraft:sea_lantern
setblock 169 154 356 minecraft:sea_lantern
setblock 169 154 358 minecraft:sea_lantern
setblock 169 154 360 minecraft:sea_lantern
setblock 169 154 362 minecraft:sea_lantern
setblock 170 154 323 minecraft:dark_prismarine
fill 170 154 324 170 157 324 minecraft:blue_terracotta
setblock 170 154 363 minecraft:dark_prismarine
fill 171 154 323 171 157 323 minecraft:blue_terracotta
fill 171 154 363 171 155 363 minecraft:blue_terracotta
setblock 173 154 325 minecraft:dark_prismarine
setblock 174 154 324 minecraft:dark_prismarine
setblock 175 154 323 minecraft:dark_prismarine
fill 175 154 324 175 155 324 minecraft:blue_terracotta
fill 176 154 323 176 157 323 minecraft:blue_terracotta
setblock 179 154 324 minecraft:dark_prismarine
setblock 180 154 323 minecraft:dark_prismarine
fill 180 154 324 180 157 324 minecraft:blue_terracotta
setblock 180 154 363 minecraft:dark_prismarine
fill 181 154 323 181 157 323 minecraft:blue_terracotta
fill 181 154 363 181 157 363 minecraft:blue_terracotta
setblock 182 154 326 minecraft:dark_prismarine
fill 182 154 327 182 157 327 minecraft:blue_terracotta
setblock 182 154 336 minecraft:purple_concrete
setblock 182 154 346 minecraft:dark_prismarine
fill 182 154 347 182 157 347 minecraft:blue_terracotta
setblock 182 154 350 minecraft:blue_terracotta
setblock 182 154 351 minecraft:dark_prismarine
setblock 182 154 361 minecraft:dark_prismarine
fill 182 154 362 182 157 362 minecraft:blue_terracotta
fill 141 155 359 141 220 359 minecraft:blue_terracotta
setblock 142 155 324 minecraft:blue_terracotta
setblock 142 155 325 minecraft:dark_prismarine
fill 142 155 326 142 158 326 minecraft:blue_terracotta
fill 142 155 328 142 156 328 minecraft:blue_terracotta
setblock 142 155 331 minecraft:purple_concrete
setblock 142 155 345 minecraft:dark_prismarine
fill 142 155 346 142 155 349 minecraft:blue_terracotta
setblock 142 155 350 minecraft:dark_prismarine
fill 142 155 351 142 158 351 minecraft:blue_terracotta
setblock 142 155 355 minecraft:dark_prismarine
fill 142 155 356 142 158 356 minecraft:blue_terracotta
setblock 142 155 360 minecraft:dark_prismarine
fill 142 155 361 142 158 361 minecraft:blue_terracotta
setblock 143 155 344 minecraft:dark_prismarine
fill 143 155 345 143 158 345 minecraft:blue_terracotta
setblock 143 155 349 minecraft:dark_prismarine
fill 143 155 350 143 158 350 minecraft:blue_terracotta
setblock 143 155 354 minecraft:dark_prismarine
fill 143 155 355 143 158 355 minecraft:blue_terracotta
fill 143 155 364 143 157 364 minecraft:blue_terracotta
setblock 144 155 323 minecraft:dark_prismarine
setblock 144 155 325 minecraft:light[level=12]
setblock 144 155 332 minecraft:light[level=12]
setblock 144 155 339 minecraft:light[level=12]
setblock 144 155 348 minecraft:dark_prismarine
fill 144 155 349 144 158 349 minecraft:blue_terracotta
setblock 144 155 352 minecraft:blue_terracotta
setblock 144 155 353 minecraft:light[level=12]
setblock 144 155 360 minecraft:light[level=12]
setblock 144 155 363 minecraft:dark_prismarine
fill 145 155 323 145 158 323 minecraft:blue_terracotta
fill 145 155 348 145 158 348 minecraft:blue_terracotta
fill 145 155 363 145 158 363 minecraft:blue_terracotta
setblock 149 155 323 minecraft:dark_prismarine
setblock 149 155 363 minecraft:dark_prismarine
setblock 150 155 323 minecraft:blue_terracotta
setblock 151 155 325 minecraft:light[level=12]
setblock 151 155 332 minecraft:light[level=12]
setblock 151 155 339 minecraft:light[level=12]
setblock 151 155 346 minecraft:light[level=12]
setblock 151 155 353 minecraft:light[level=12]
setblock 151 155 360 minecraft:light[level=12]
setblock 154 155 363 minecraft:purple_concrete
fill 156 155 345 156 162 345 minecraft:dark_prismarine
setblock 158 155 325 minecraft:light[level=12]
setblock 158 155 332 minecraft:light[level=12]
setblock 158 155 339 minecraft:light[level=12]
setblock 158 155 346 minecraft:light[level=12]
setblock 158 155 353 minecraft:light[level=12]
setblock 158 155 360 minecraft:light[level=12]
fill 161 155 354 161 156 354 minecraft:dark_prismarine
fill 161 155 356 161 156 356 minecraft:dark_prismarine
fill 161 155 358 161 156 358 minecraft:dark_prismarine
fill 161 155 360 161 156 360 minecraft:dark_prismarine
fill 161 155 362 161 156 362 minecraft:dark_prismarine
fill 162 155 329 162 156 329 minecraft:dark_prismarine
fill 162 155 355 162 156 355 minecraft:dark_prismarine
fill 162 155 357 162 156 357 minecraft:dark_prismarine
fill 162 155 359 162 156 359 minecraft:dark_prismarine
fill 162 155 361 162 156 361 minecraft:dark_prismarine
fill 162 155 363 162 156 363 minecraft:dark_prismarine
setblock 163 155 324 minecraft:dark_prismarine
setblock 163 155 326 minecraft:purple_concrete
setblock 163 155 327 minecraft:dark_prismarine
fill 163 155 330 163 157 330 minecraft:dark_prismarine
fill 163 155 354 163 156 354 minecraft:dark_prismarine
fill 163 155 356 163 156 356 minecraft:dark_prismarine
fill 163 155 358 163 156 358 minecraft:dark_prismarine
fill 163 155 360 163 156 360 minecraft:dark_prismarine
fill 163 155 362 163 156 362 minecraft:dark_prismarine
setblock 164 155 323 minecraft:dark_prismarine
fill 164 155 324 164 158 324 minecraft:blue_terracotta
fill 164 155 329 164 156 329 minecraft:dark_prismarine
fill 164 155 355 164 156 355 minecraft:dark_prismarine
fill 164 155 357 164 156 357 minecraft:dark_prismarine
fill 164 155 359 164 156 359 minecraft:dark_prismarine
fill 164 155 361 164 156 361 minecraft:dark_prismarine
fill 164 155 363 164 156 363 minecraft:dark_prismarine
fill 165 155 323 165 158 323 minecraft:blue_terracotta
setblock 165 155 332 minecraft:light[level=12]
setblock 165 155 339 minecraft:light[level=12]
setblock 165 155 346 minecraft:light[level=12]
setblock 165 155 353 minecraft:light[level=12]
fill 165 155 354 165 156 354 minecraft:dark_prismarine
fill 165 155 356 165 156 356 minecraft:dark_prismarine
fill 165 155 358 165 156 358 minecraft:dark_prismarine
fill 165 155 360 165 156 360 minecraft:dark_prismarine
fill 165 155 362 165 156 362 minecraft:dark_prismarine
setblock 166 155 326 minecraft:dark_prismarine
fill 166 155 355 166 156 355 minecraft:dark_prismarine
fill 166 155 357 166 156 357 minecraft:dark_prismarine
fill 166 155 359 166 156 359 minecraft:dark_prismarine
fill 166 155 361 166 156 361 minecraft:dark_prismarine
fill 166 155 363 166 156 363 minecraft:blue_terracotta
setblock 167 155 325 minecraft:dark_prismarine
fill 167 155 326 167 158 326 minecraft:blue_terracotta
fill 167 155 354 167 156 354 minecraft:dark_prismarine
fill 167 155 356 167 156 356 minecraft:dark_prismarine
fill 167 155 358 167 156 358 minecraft:dark_prismarine
fill 167 155 360 167 156 360 minecraft:dark_prismarine
fill 167 155 362 167 156 362 minecraft:dark_prismarine
setblock 168 155 324 minecraft:dark_prismarine
fill 168 155 325 168 158 325 minecraft:blue_terracotta
fill 168 155 355 168 156 355 minecraft:dark_prismarine
fill 168 155 357 168 156 357 minecraft:dark_prismarine
fill 168 155 359 168 156 359 minecraft:dark_prismarine
fill 168 155 361 168 156 361 minecraft:dark_prismarine
setblock 168 155 363 minecraft:blue_terracotta
setblock 169 155 323 minecraft:dark_prismarine
fill 169 155 324 169 158 324 minecraft:blue_terracotta
fill 169 155 354 169 156 354 minecraft:dark_prismarine
fill 169 155 356 169 156 356 minecraft:dark_prismarine
fill 169 155 358 169 156 358 minecraft:dark_prismarine
fill 169 155 360 169 156 360 minecraft:dark_prismarine
fill 169 155 362 169 155 363 minecraft:dark_prismarine
fill 170 155 323 170 158 323 minecraft:blue_terracotta
setblock 170 155 363 minecraft:blue_terracotta
setblock 172 155 325 minecraft:dark_prismarine
setblock 172 155 332 minecraft:light[level=12]
setblock 172 155 339 minecraft:light[level=12]
setblock 172 155 346 minecraft:light[level=12]
setblock 172 155 360 minecraft:light[level=12]
setblock 173 155 324 minecraft:dark_prismarine
setblock 174 155 323 minecraft:dark_prismarine
fill 174 155 324 174 156 324 minecraft:blue_terracotta
fill 175 155 323 175 158 323 minecraft:blue_terracotta
setblock 179 155 323 minecraft:dark_prismarine
setblock 179 155 325 minecraft:light[level=12]
setblock 179 155 332 minecraft:light[level=12]
setblock 179 155 339 minecraft:light[level=12]
setblock 179 155 346 minecraft:light[level=12]
setblock 179 155 353 minecraft:light[level=12]
setblock 179 155 360 minecraft:light[level=12]
setblock 179 155 363 minecraft:purple_concrete
fill 180 155 323 180 158 323 minecraft:blue_terracotta
fill 180 155 363 180 158 363 minecraft:blue_terracotta
setblock 181 155 326 minecraft:dark_prismarine
fill 181 155 327 181 158 327 minecraft:blue_terracotta
setblock 182 155 325 minecraft:dark_prismarine
fill 182 155 326 182 158 326 minecraft:blue_terracotta
setblock 182 155 330 minecraft:dark_prismarine
fill 182 155 346 182 158 346 minecraft:blue_terracotta
setblock 182 155 350 minecraft:dark_prismarine
fill 182 155 351 182 156 353 minecraft:blue_terracotta
setblock 182 155 355 minecraft:purple_concrete
setblock 182 155 360 minecraft:dark_prismarine
fill 182 155 361 182 158 361 minecraft:blue_terracotta
setblock 141 156 350 minecraft:cyan_concrete
fill 141 156 351 141 217 351 minecraft:blue_terracotta
setblock 142 156 324 minecraft:dark_prismarine
fill 142 156 325 142 159 325 minecraft:blue_terracotta
setblock 142 156 329 minecraft:dark_prismarine
setblock 142 156 337 minecraft:purple_concrete
setblock 142 156 344 minecraft:dark_prismarine
fill 142 156 345 142 156 348 minecraft:blue_terracotta
setblock 142 156 349 minecraft:dark_prismarine
fill 142 156 350 142 159 350 minecraft:blue_terracotta
setblock 142 156 353 minecraft:blue_terracotta
setblock 142 156 354 minecraft:dark_prismarine
fill 142 156 355 142 159 355 minecraft:blue_terracotta
setblock 142 156 359 minecraft:dark_prismarine
fill 142 156 360 142 159 360 minecraft:blue_terracotta
setblock 143 156 323 minecraft:dark_prismarine
fill 143 156 344 143 159 344 minecraft:blue_terracotta
setblock 143 156 348 minecraft:dark_prismarine
fill 143 156 349 143 159 349 minecraft:blue_terracotta
setblock 143 156 353 minecraft:dark_prismarine
fill 143 156 354 143 159 354 minecraft:blue_terracotta
fill 143 156 356 143 157 356 minecraft:blue_terracotta
setblock 143 156 363 minecraft:dark_prismarine
fill 144 156 323 144 159 323 minecraft:blue_terracotta
setblock 144 156 347 minecraft:dark_prismarine
fill 144 156 348 144 159 348 minecraft:blue_terracotta
setblock 144 156 352 minecraft:dark_prismarine
fill 144 156 353 144 159 353 minecraft:blue_terracotta
fill 144 156 363 144 159 363 minecraft:blue_terracotta
fill 145 156 349 145 156 350 minecraft:blue_terracotta
setblock 148 156 323 minecraft:dark_prismarine
fill 148 156 348 148 213 348 minecraft:magenta_terracotta
setblock 148 156 363 minecraft:dark_prismarine
setblock 149 156 323 minecraft:blue_terracotta
setblock 158 156 323 minecraft:purple_concrete
setblock 160 156 363 minecraft:purple_concrete
setblock 162 156 324 minecraft:dark_prismarine
fill 162 156 330 162 156 331 minecraft:dark_prismarine
setblock 163 156 323 minecraft:dark_prismarine
fill 163 156 324 163 159 324 minecraft:blue_terracotta
setblock 163 156 327 minecraft:purple_concrete
setblock 163 156 328 minecraft:dark_prismarine
fill 163 156 331 163 158 332 minecraft:dark_prismarine
fill 163 156 353 163 158 353 minecraft:dark_prismarine
setblock 163 156 364 minecraft:light_blue_wool
fill 164 156 323 164 159 323 minecraft:blue_terracotta
fill 164 156 330 164 156 331 minecraft:dark_prismarine
setblock 166 156 325 minecraft:dark_prismarine
fill 166 156 326 166 159 326 minecraft:blue_terracotta
setblock 167 156 324 minecraft:dark_prismarine
fill 167 156 325 167 159 325 minecraft:blue_terracotta
setblock 168 156 323 minecraft:dark_prismarine
fill 168 156 324 168 159 324 minecraft:blue_terracotta
setblock 168 156 363 minecraft:dark_prismarine
fill 169 156 323 169 159 323 minecraft:blue_terracotta
setblock 169 156 362 minecraft:dark_prismarine
setblock 169 156 363 minecraft:blue_terracotta
setblock 171 156 325 minecraft:dark_prismarine
fill 171 156 353 171 197 353 minecraft:magenta_terracotta
setblock 171 156 364 minecraft:light_blue_wool
setblock 172 156 324 minecraft:dark_prismarine
setblock 173 156 323 minecraft:dark_prismarine
fill 173 156 324 173 157 324 minecraft:blue_terracotta
fill 174 156 323 174 159 323 minecraft:blue_terracotta
setblock 178 156 323 minecraft:dark_prismarine
fill 178 156 347 178 157 347 minecraft:black_concrete
fill 179 156 323 179 159 323 minecraft:blue_terracotta
setblock 181 156 325 minecraft:dark_prismarine
fill 181 156 326 181 159 326 minecraft:blue_terracotta
setblock 182 156 324 minecraft:dark_prismarine
fill 182 156 325 182 159 325 minecraft:blue_terracotta
setblock 182 156 329 minecraft:dark_prismarine
fill 182 156 330 182 158 331 minecraft:blue_terracotta
setblock 182 156 343 minecraft:purple_concrete
fill 182 156 345 182 159 345 minecraft:blue_terracotta
setblock 182 156 348 minecraft:blue_terracotta
setblock 182 156 349 minecraft:dark_prismarine
fill 182 156 350 182 159 350 minecraft:blue_terracotta
setblock 182 156 354 minecraft:dark_prismarine
fill 182 156 355 182 157 357 minecraft:blue_terracotta
setblock 182 156 359 minecraft:dark_prismarine
fill 182 156 360 182 159 360 minecraft:blue_terracotta
fill 141 157 350 141 217 350 minecraft:blue_terracotta
setblock 142 157 323 minecraft:dark_prismarine
fill 142 157 324 142 160 324 minecraft:blue_terracotta
setblock 142 157 328 minecraft:dark_prismarine
fill 142 157 329 142 158 331 minecraft:blue_terracotta
setblock 142 157 342 minecraft:blue_terracotta
setblock 142 157 343 minecraft:dark_prismarine
fill 142 157 344 142 157 347 minecraft:blue_terracotta
setblock 142 157 348 minecraft:dark_prismarine
fill 142 157 349 142 160 349 minecraft:blue_terracotta
setblock 142 157 353 minecraft:dark_prismarine
fill 142 157 354 142 160 354 minecraft:blue_terracotta
setblock 142 157 358 minecraft:dark_prismarine
fill 142 157 359 142 160 359 minecraft:blue_terracotta
setblock 142 157 363 minecraft:dark_prismarine
fill 143 157 323 143 160 323 minecraft:blue_terracotta
setblock 143 157 347 minecraft:dark_prismarine
fill 143 157 348 143 160 348 minecraft:blue_terracotta
setblock 143 157 351 minecraft:blue_terracotta
setblock 143 157 352 minecraft:dark_prismarine
fill 143 157 353 143 160 353 minecraft:blue_terracotta
setblock 143 157 357 minecraft:dark_prismarine
fill 143 157 363 143 160 363 minecraft:blue_terracotta
setblock 144 157 325 minecraft:light[level=13]
setblock 144 157 333 minecraft:light[level=13]
setblock 144 157 341 minecraft:light[level=13]
setblock 144 157 346 minecraft:dark_prismarine
fill 144 157 347 145 159 347 minecraft:blue_terracotta
setblock 144 157 351 minecraft:dark_prismarine
fill 144 157 352 145 159 352 minecraft:blue_terracotta
fill 144 157 354 144 158 354 minecraft:blue_terracotta
setblock 144 157 357 minecraft:light[level=13]
setblock 145 157 349 minecraft:blue_terracotta
setblock 145 157 350 minecraft:dark_prismarine
fill 145 157 351 145 160 351 minecraft:blue_terracotta
setblock 147 157 323 minecraft:dark_prismarine
setblock 147 157 363 minecraft:dark_prismarine
setblock 148 157 323 minecraft:blue_terracotta
setblock 152 157 323 minecraft:purple_concrete
setblock 152 157 325 minecraft:light[level=13]
setblock 152 157 341 minecraft:light[level=13]
setblock 152 157 349 minecraft:light[level=13]
setblock 152 157 357 minecraft:light[level=13]
fill 160 157 323 160 158 323 minecraft:blue_terracotta
setblock 160 157 325 minecraft:light[level=13]
setblock 160 157 333 minecraft:light[level=13]
setblock 160 157 341 minecraft:light[level=13]
setblock 160 157 349 minecraft:light[level=13]
setblock 160 157 357 minecraft:light[level=13]
setblock 161 157 354 minecraft:sea_lantern
setblock 161 157 356 minecraft:sea_lantern
setblock 161 157 358 minecraft:sea_lantern
setblock 161 157 360 minecraft:sea_lantern
setblock 161 157 362 minecraft:sea_lantern
setblock 161 157 364 minecraft:light_blue_wool
setblock 162 157 323 minecraft:dark_prismarine
fill 162 157 324 162 160 324 minecraft:blue_terracotta
fill 162 157 331 162 157 333 minecraft:dark_prismarine
fill 162 157 352 162 158 353 minecraft:dark_prismarine
setblock 162 157 355 minecraft:sea_lantern
setblock 162 157 357 minecraft:sea_lantern
setblock 162 157 359 minecraft:sea_lantern
setblock 162 157 361 minecraft:sea_lantern
setblock 162 157 363 minecraft:sea_lantern
fill 162 157 364 163 217 364 minecraft:blue_terracotta
fill 163 157 323 163 160 323 minecraft:blue_terracotta
fill 163 157 325 163 158 325 minecraft:blue_terracotta
setblock 163 157 329 minecraft:purple_concrete
fill 163 157 333 163 159 334 minecraft:dark_prismarine
fill 163 157 351 163 159 352 minecraft:dark_prismarine
setblock 163 157 354 minecraft:sea_lantern
setblock 163 157 356 minecraft:sea_lantern
setblock 163 157 358 minecraft:sea_lantern
setblock 163 157 360 minecraft:sea_lantern
setblock 163 157 362 minecraft:sea_lantern
fill 164 157 331 164 157 333 minecraft:dark_prismarine
fill 164 157 352 164 158 353 minecraft:dark_prismarine
setblock 164 157 355 minecraft:sea_lantern
setblock 164 157 357 minecraft:sea_lantern
setblock 164 157 359 minecraft:sea_lantern
setblock 164 157 361 minecraft:sea_lantern
setblock 164 157 363 minecraft:sea_lantern
setblock 165 157 325 minecraft:dark_prismarine
fill 165 157 326 165 160 326 minecraft:blue_terracotta
setblock 165 157 354 minecraft:sea_lantern
setblock 165 157 356 minecraft:sea_lantern
setblock 165 157 358 minecraft:sea_lantern
setblock 165 157 360 minecraft:sea_lantern
setblock 165 157 362 minecraft:sea_lantern
setblock 166 157 324 minecraft:dark_prismarine
fill 166 157 325 166 160 325 minecraft:blue_terracotta
setblock 166 157 355 minecraft:sea_lantern
setblock 166 157 357 minecraft:sea_lantern
setblock 166 157 359 minecraft:sea_lantern
setblock 166 157 361 minecraft:sea_lantern
setblock 166 157 363 minecraft:sea_lantern
setblock 167 157 323 minecraft:dark_prismarine
fill 167 157 324 167 160 324 minecraft:blue_terracotta
setblock 167 157 354 minecraft:sea_lantern
setblock 167 157 356 minecraft:sea_lantern
setblock 167 157 358 minecraft:sea_lantern
setblock 167 157 360 minecraft:sea_lantern
setblock 167 157 362 minecraft:sea_lantern
setblock 167 157 363 minecraft:dark_prismarine
fill 168 157 323 168 160 323 minecraft:blue_terracotta
setblock 168 157 333 minecraft:light[level=13]
setblock 168 157 341 minecraft:light[level=13]
setblock 168 157 349 minecraft:light[level=13]
setblock 168 157 355 minecraft:sea_lantern
setblock 168 157 357 minecraft:sea_lantern
setblock 168 157 359 minecraft:sea_lantern
setblock 168 157 361 minecraft:sea_lantern
setblock 168 157 363 minecraft:sea_lantern
setblock 169 157 354 minecraft:sea_lantern
setblock 169 157 356 minecraft:sea_lantern
setblock 169 157 358 minecraft:sea_lantern
setblock 169 157 360 minecraft:sea_lantern
setblock 169 157 362 minecraft:sea_lantern
fill 169 157 363 169 160 363 minecraft:dark_prismarine
setblock 170 157 325 minecraft:dark_prismarine
setblock 171 157 324 minecraft:dark_prismarine
setblock 171 157 325 minecraft:blue_terracotta
fill 171 157 364 171 221 364 minecraft:blue_terracotta
setblock 172 157 323 minecraft:dark_prismarine
fill 172 157 324 172 159 324 minecraft:blue_terracotta
setblock 172 157 363 minecraft:purple_concrete
fill 173 157 323 173 160 323 minecraft:blue_terracotta
setblock 176 157 325 minecraft:light[level=13]
setblock 176 157 333 minecraft:light[level=13]
setblock 176 157 341 minecraft:light[level=13]
setblock 176 157 349 minecraft:light[level=13]
setblock 176 157 357 minecraft:light[level=13]
setblock 177 157 323 minecraft:dark_prismarine
fill 178 157 323 178 160 323 minecraft:blue_terracotta
setblock 181 157 324 minecraft:dark_prismarine
fill 181 157 325 181 160 325 minecraft:blue_terracotta
setblock 181 157 328 minecraft:blue_terracotta
setblock 182 157 323 minecraft:dark_prismarine
fill 182 157 324 182 160 324 minecraft:blue_terracotta
setblock 182 157 328 minecraft:dark_prismarine
fill 182 157 329 182 160 329 minecraft:blue_terracotta
setblock 182 157 337 minecraft:purple_concrete
setblock 182 157 348 minecraft:dark_prismarine
fill 182 157 349 182 160 349 minecraft:blue_terracotta
fill 182 157 351 182 157 352 minecraft:blue_terracotta
setblock 182 157 353 minecraft:dark_prismarine
fill 182 157 354 182 160 354 minecraft:blue_terracotta
setblock 182 157 358 minecraft:dark_prismarine
fill 182 157 359 182 160 359 minecraft:blue_terracotta
setblock 182 157 363 minecraft:dark_prismarine
fill 142 158 323 142 161 323 minecraft:blue_terracotta
setblock 142 158 327 minecraft:dark_prismarine
fill 142 158 328 143 160 328 minecraft:blue_terracotta
setblock 142 158 332 minecraft:dark_prismarine
fill 142 158 333 142 161 333 minecraft:blue_terracotta
setblock 142 158 342 minecraft:dark_prismarine
fill 142 158 343 142 158 346 minecraft:blue_terracotta
setblock 142 158 347 minecraft:dark_prismarine
fill 142 158 348 142 161 348 minecraft:blue_terracotta
setblock 142 158 352 minecraft:dark_prismarine
fill 142 158 353 142 161 353 minecraft:blue_terracotta
setblock 142 158 357 minecraft:dark_prismarine
fill 142 158 358 143 160 358 minecraft:blue_terracotta
setblock 142 158 362 minecraft:dark_prismarine
fill 142 158 363 142 161 363 minecraft:blue_terracotta
setblock 143 158 326 minecraft:dark_prismarine
fill 143 158 327 143 161 327 minecraft:blue_terracotta
fill 143 158 329 143 158 330 minecraft:blue_terracotta
fill 143 158 343 143 160 343 minecraft:blue_terracotta
setblock 143 158 346 minecraft:dark_prismarine
fill 143 158 347 143 161 347 minecraft:blue_terracotta
setblock 143 158 351 minecraft:dark_prismarine
fill 143 158 352 143 161 352 minecraft:blue_terracotta
setblock 143 158 356 minecraft:dark_prismarine
fill 143 158 357 143 161 357 minecraft:blue_terracotta
setblock 143 158 364 minecraft:light_blue_wool
setblock 144 158 345 minecraft:dark_prismarine
fill 144 158 346 144 161 346 minecraft:blue_terracotta
setblock 144 158 350 minecraft:dark_prismarine
fill 144 158 351 144 161 351 minecraft:blue_terracotta
setblock 144 158 355 minecraft:dark_prismarine
setblock 145 158 349 minecraft:dark_prismarine
fill 145 158 350 145 161 350 minecraft:blue_terracotta
setblock 145 158 353 minecraft:blue_terracotta
setblock 146 158 323 minecraft:dark_prismarine
setblock 146 158 363 minecraft:dark_prismarine
fill 147 158 323 147 159 323 minecraft:blue_terracotta
setblock 147 158 363 minecraft:blue_terracotta
setblock 153 158 363 minecraft:purple_concrete
fill 154 158 322 158 175 322 minecraft:blue_terracotta
setblock 159 158 322 minecraft:cyan_concrete
fill 160 158 322 166 169 322 minecraft:blue_terracotta
setblock 161 158 323 minecraft:dark_prismarine
fill 161 158 324 161 161 324 minecraft:blue_terracotta
fill 161 158 354 161 159 354 minecraft:dark_prismarine
fill 161 158 356 161 159 356 minecraft:dark_prismarine
fill 161 158 358 161 159 358 minecraft:dark_prismarine
fill 161 158 360 161 159 360 minecraft:dark_prismarine
fill 161 158 362 161 159 362 minecraft:dark_prismarine
fill 161 158 364 161 220 364 minecraft:blue_terracotta
fill 162 158 323 162 161 323 minecraft:blue_terracotta
fill 162 158 325 162 159 325 minecraft:blue_terracotta
fill 162 158 332 162 158 335 minecraft:dark_prismarine
fill 162 158 350 162 159 351 minecraft:dark_prismarine
fill 162 158 355 162 159 355 minecraft:dark_prismarine
fill 162 158 357 162 159 357 minecraft:dark_prismarine
fill 162 158 359 162 159 359 minecraft:dark_prismarine
fill 162 158 361 162 159 361 minecraft:dark_prismarine
fill 162 158 363 162 159 363 minecraft:dark_prismarine
setblock 163 158 330 minecraft:purple_concrete
fill 163 158 335 163 160 336 minecraft:dark_prismarine
fill 163 158 349 163 160 350 minecraft:dark_prismarine
fill 163 158 354 163 159 354 minecraft:dark_prismarine
fill 163 158 356 163 159 356 minecraft:dark_prismarine
fill 163 158 358 163 159 358 minecraft:dark_prismarine
fill 163 158 360 163 159 360 minecraft:dark_prismarine
fill 163 158 362 163 159 362 minecraft:dark_prismarine
setblock 164 158 325 minecraft:dark_prismarine
fill 164 158 326 164 161 326 minecraft:blue_terracotta
fill 164 158 332 164 158 335 minecraft:dark_prismarine
fill 164 158 350 164 159 351 minecraft:dark_prismarine
fill 164 158 355 164 159 355 minecraft:dark_prismarine
fill 164 158 357 164 159 357 minecraft:dark_prismarine
fill 164 158 359 164 159 359 minecraft:dark_prismarine
fill 164 158 361 164 159 361 minecraft:dark_prismarine
setblock 164 158 363 minecraft:dark_prismarine
setblock 165 158 324 minecraft:dark_prismarine
fill 165 158 325 165 161 325 minecraft:blue_terracotta
fill 165 158 354 165 159 354 minecraft:dark_prismarine
fill 165 158 356 165 159 356 minecraft:dark_prismarine
fill 165 158 358 165 159 358 minecraft:dark_prismarine
fill 165 158 360 165 159 360 minecraft:dark_prismarine
fill 165 158 362 165 159 362 minecraft:dark_prismarine
setblock 166 158 323 minecraft:dark_prismarine
fill 166 158 324 166 161 324 minecraft:blue_terracotta
fill 166 158 355 166 159 355 minecraft:dark_prismarine
fill 166 158 357 166 159 357 minecraft:dark_prismarine
fill 166 158 359 166 159 359 minecraft:dark_prismarine
fill 166 158 361 166 159 361 minecraft:dark_prismarine
setblock 166 158 363 minecraft:dark_prismarine
fill 167 158 323 167 161 323 minecraft:blue_terracotta
fill 167 158 354 167 159 354 minecraft:dark_prismarine
fill 167 158 356 167 159 356 minecraft:dark_prismarine
fill 167 158 358 167 159 358 minecraft:dark_prismarine
fill 167 158 360 167 159 360 minecraft:dark_prismarine
fill 167 158 362 167 159 362 minecraft:dark_prismarine
fill 167 158 363 168 159 363 minecraft:blue_terracotta
fill 168 158 355 168 159 355 minecraft:dark_prismarine
fill 168 158 357 168 159 357 minecraft:dark_prismarine
fill 168 158 359 168 159 359 minecraft:dark_prismarine
fill 168 158 361 168 159 361 minecraft:dark_prismarine
setblock 169 158 325 minecraft:dark_prismarine
fill 169 158 354 169 159 354 minecraft:dark_prismarine
fill 169 158 356 169 159 356 minecraft:dark_prismarine
fill 169 158 358 169 159 358 minecraft:dark_prismarine
fill 169 158 360 169 159 360 minecraft:dark_prismarine
fill 169 158 362 169 159 362 minecraft:dark_prismarine
setblock 170 158 324 minecraft:dark_prismarine
fill 170 158 325 170 159 325 minecraft:blue_terracotta
setblock 171 158 323 minecraft:dark_prismarine
fill 171 158 324 171 161 324 minecraft:blue_terracotta
fill 172 158 323 172 161 323 minecraft:blue_terracotta
setblock 176 158 323 minecraft:dark_prismarine
fill 177 158 323 177 161 323 minecraft:blue_terracotta
setblock 178 158 322 minecraft:light_blue_wool
setblock 178 158 363 minecraft:purple_concrete
fill 179 158 322 180 199 322 minecraft:blue_terracotta
fill 179 158 363 179 159 363 minecraft:blue_terracotta
setblock 180 158 324 minecraft:dark_prismarine
setblock 181 158 322 minecraft:cyan_concrete
setblock 181 158 323 minecraft:dark_prismarine
fill 181 158 324 181 161 324 minecraft:blue_terracotta
setblock 181 158 328 minecraft:dark_prismarine
fill 181 158 329 181 161 329 minecraft:blue_terracotta
setblock 181 158 348 minecraft:dark_prismarine
fill 181 158 349 181 158 352 minecraft:blue_terracotta
setblock 181 158 353 minecraft:dark_prismarine
fill 181 158 354 181 160 355 minecraft:blue_terracotta
setblock 181 158 363 minecraft:dark_prismarine
fill 182 158 322 182 161 323 minecraft:blue_terracotta
setblock 182 158 327 minecraft:dark_prismarine
fill 182 158 328 182 161 328 minecraft:blue_terracotta
setblock 182 158 332 minecraft:dark_prismarine
fill 182 158 333 182 161 333 minecraft:blue_terracotta
setblock 182 158 347 minecraft:dark_prismarine
fill 182 158 348 182 161 348 minecraft:blue_terracotta
setblock 182 158 351 minecraft:blue_terracotta
setblock 182 158 352 minecraft:dark_prismarine
fill 182 158 353 182 161 353 minecraft:blue_terracotta
fill 182 158 355 182 158 356 minecraft:blue_terracotta
setblock 182 158 357 minecraft:dark_prismarine
fill 182 158 358 182 161 358 minecraft:blue_terracotta
setblock 182 158 362 minecraft:dark_prismarine
fill 182 158 363 182 161 363 minecraft:blue_terracotta
fill 183 158 322 183 217 322 minecraft:blue_terracotta
setblock 142 159 326 minecraft:dark_prismarine
fill 142 159 327 142 162 327 minecraft:blue_terracotta
fill 142 159 329 142 159 330 minecraft:blue_terracotta
setblock 142 159 331 minecraft:dark_prismarine
fill 142 159 332 143 161 332 minecraft:blue_terracotta
fill 142 159 334 142 159 335 minecraft:blue_terracotta
setblock 142 159 336 minecraft:dark_prismarine
setblock 142 159 340 minecraft:blue_terracotta
setblock 142 159 341 minecraft:dark_prismarine
fill 142 159 342 142 159 345 minecraft:blue_terracotta
setblock 142 159 346 minecraft:dark_prismarine
fill 142 159 347 142 162 347 minecraft:blue_terracotta
setblock 142 159 351 minecraft:dark_prismarine
fill 142 159 352 142 162 352 minecraft:blue_terracotta
setblock 142 159 356 minecraft:dark_prismarine
fill 142 159 357 142 162 357 minecraft:blue_terracotta
setblock 142 159 361 minecraft:dark_prismarine
fill 142 159 362 142 162 362 minecraft:blue_terracotta
fill 143 159 326 143 162 326 minecraft:blue_terracotta
setblock 143 159 329 minecraft:blue_terracotta
setblock 143 159 330 minecraft:dark_prismarine
fill 143 159 331 143 162 331 minecraft:blue_terracotta
setblock 143 159 345 minecraft:dark_prismarine
fill 143 159 346 143 162 346 minecraft:blue_terracotta
setblock 143 159 350 minecraft:dark_prismarine
fill 143 159 351 143 162 351 minecraft:blue_terracotta
setblock 143 159 355 minecraft:dark_prismarine
fill 143 159 356 144 161 356 minecraft:blue_terracotta
setblock 143 159 359 minecraft:blue_terracotta
setblock 143 159 360 minecraft:dark_prismarine
fill 143 159 364 143 217 364 minecraft:blue_terracotta
fill 144 159 345 144 162 345 minecraft:blue_terracotta
setblock 144 159 349 minecraft:dark_prismarine
fill 144 159 350 144 162 350 minecraft:blue_terracotta
setblock 144 159 354 minecraft:dark_prismarine
fill 144 159 355 144 162 355 minecraft:blue_terracotta
fill 144 159 357 144 160 357 minecraft:blue_terracotta
setblock 145 159 323 minecraft:dark_prismarine
setblock 145 159 348 minecraft:dark_prismarine
fill 145 159 349 145 162 349 minecraft:blue_terracotta
setblock 145 159 353 minecraft:dark_prismarine
fill 145 159 354 145 162 354 minecraft:blue_terracotta
setblock 145 159 363 minecraft:dark_prismarine
fill 146 159 323 146 161 323 minecraft:blue_terracotta
fill 146 159 363 146 162 363 minecraft:blue_terracotta
fill 152 159 342 152 159 346 minecraft:purple_concrete
fill 153 159 341 153 159 343 minecraft:purple_concrete
fill 153 159 345 153 159 347 minecraft:purple_concrete
fill 154 159 341 154 159 342 minecraft:purple_concrete
fill 154 159 346 156 159 347 minecraft:purple_concrete
fill 155 159 341 155 160 341 minecraft:purple_concrete
fill 156 159 353 156 160 353 minecraft:spruce_planks
setblock 157 159 346 minecraft:purple_concrete
fill 157 159 359 157 179 359 minecraft:magenta_terracotta
fill 159 159 322 159 159 323 minecraft:blue_terracotta
setblock 159 159 363 minecraft:purple_concrete
setblock 160 159 323 minecraft:dark_prismarine
fill 161 159 323 161 162 323 minecraft:blue_terracotta
fill 162 159 334 162 159 337 minecraft:dark_prismarine
fill 162 159 348 162 159 349 minecraft:dark_prismarine
setblock 163 159 325 minecraft:dark_prismarine
setblock 163 159 332 minecraft:purple_concrete
fill 163 159 337 163 160 340 minecraft:dark_prismarine
fill 163 159 345 163 160 348 minecraft:dark_prismarine
setblock 163 159 353 minecraft:purple_concrete
setblock 164 159 324 minecraft:dark_prismarine
fill 164 159 325 164 162 325 minecraft:blue_terracotta
fill 164 159 334 164 159 337 minecraft:dark_prismarine
fill 164 159 348 164 159 349 minecraft:dark_prismarine
setblock 164 159 363 minecraft:blue_terracotta
setblock 165 159 323 minecraft:dark_prismarine
fill 165 159 324 165 162 324 minecraft:blue_terracotta
fill 166 159 323 166 162 323 minecraft:blue_terracotta
setblock 166 159 363 minecraft:blue_terracotta
setblock 167 159 326 minecraft:dark_prismarine
setblock 168 159 325 minecraft:dark_prismarine
setblock 169 159 324 minecraft:dark_prismarine
fill 169 159 325 169 161 325 minecraft:blue_terracotta
setblock 170 159 323 minecraft:dark_prismarine
fill 170 159 324 170 162 324 minecraft:blue_terracotta
fill 171 159 323 171 162 323 minecraft:blue_terracotta
setblock 175 159 323 minecraft:dark_prismarine
fill 176 159 323 176 162 323 minecraft:blue_terracotta
fill 177 159 339 177 211 339 minecraft:magenta_terracotta
fill 178 159 322 178 220 322 minecraft:blue_terracotta
setblock 180 159 323 minecraft:dark_prismarine
fill 180 159 324 180 162 324 minecraft:blue_terracotta
setblock 180 159 363 minecraft:dark_prismarine
fill 181 159 322 181 162 323 minecraft:blue_terracotta
setblock 181 159 327 minecraft:dark_prismarine
fill 181 159 328 181 162 328 minecraft:blue_terracotta
fill 181 159 330 181 159 331 minecraft:blue_terracotta
fill 181 159 348 181 159 351 minecraft:blue_terracotta
setblock 181 159 352 minecraft:dark_prismarine
fill 181 159 353 181 162 353 minecraft:blue_terracotta
setblock 181 159 356 minecraft:blue_terracotta
setblock 181 159 357 minecraft:dark_prismarine
fill 181 159 358 181 162 358 minecraft:blue_terracotta
fill 181 159 363 181 162 363 minecraft:blue_terracotta
setblock 182 159 326 minecraft:dark_prismarine
fill 182 159 327 182 162 327 minecraft:blue_terracotta
setblock 182 159 330 minecraft:blue_terracotta
setblock 182 159 331 minecraft:dark_prismarine
fill 182 159 332 182 162 332 minecraft:blue_terracotta
fill 182 159 334 182 160 334 minecraft:blue_terracotta
fill 182 159 344 182 160 344 minecraft:blue_terracotta
setblock 182 159 346 minecraft:dark_prismarine
fill 182 159 347 182 162 347 minecraft:blue_terracotta
setblock 182 159 351 minecraft:dark_prismarine
fill 182 159 352 182 162 352 minecraft:blue_terracotta
setblock 182 159 355 minecraft:blue_terracotta
setblock 182 159 356 minecraft:dark_prismarine
fill 182 159 357 182 162 357 minecraft:blue_terracotta
setblock 182 159 361 minecraft:dark_prismarine
fill 182 159 362 182 162 362 minecraft:blue_terracotta
setblock 142 160 325 minecraft:dark_prismarine
fill 142 160 326 142 162 326 minecraft:blue_terracotta
setblock 142 160 329 minecraft:blue_terracotta
setblock 142 160 330 minecraft:dark_prismarine
fill 142 160 331 142 162 331 minecraft:blue_terracotta
setblock 142 160 334 minecraft:blue_terracotta
setblock 142 160 335 minecraft:dark_prismarine
fill 142 160 336 142 160 339 minecraft:blue_terracotta
setblock 142 160 340 minecraft:dark_prismarine
fill 142 160 341 142 160 344 minecraft:blue_terracotta
setblock 142 160 345 minecraft:dark_prismarine
fill 142 160 346 142 162 346 minecraft:blue_terracotta
setblock 142 160 350 minecraft:dark_prismarine
fill 142 160 351 142 162 351 minecraft:blue_terracotta
setblock 142 160 355 minecraft:dark_prismarine
fill 142 160 356 142 162 356 minecraft:blue_terracotta
setblock 142 160 360 minecraft:dark_prismarine
fill 142 160 361 143 162 361 minecraft:blue_terracotta
fill 143 160 325 143 161 325 minecraft:blue_terracotta
setblock 143 160 329 minecraft:dark_prismarine
fill 143 160 330 143 162 330 minecraft:blue_terracotta
setblock 143 160 333 minecraft:blue_terracotta
setblock 143 160 334 minecraft:dark_prismarine
fill 143 160 335 143 162 335 minecraft:blue_terracotta
fill 143 160 342 143 161 342 minecraft:blue_terracotta
setblock 143 160 344 minecraft:dark_prismarine
fill 143 160 345 143 162 345 minecraft:blue_terracotta
setblock 143 160 349 minecraft:dark_prismarine
fill 143 160 350 143 162 350 minecraft:blue_terracotta
setblock 143 160 354 minecraft:dark_prismarine
fill 143 160 355 143 162 355 minecraft:blue_terracotta
setblock 143 160 359 minecraft:dark_prismarine
fill 143 160 360 143 162 360 minecraft:blue_terracotta
setblock 144 160 323 minecraft:dark_prismarine
fill 144 160 344 144 162 344 minecraft:blue_terracotta
setblock 144 160 347 minecraft:blue_terracotta
setblock 144 160 348 minecraft:dark_prismarine
fill 144 160 349 144 162 349 minecraft:blue_terracotta
setblock 144 160 352 minecraft:blue_terracotta
setblock 144 160 353 minecraft:dark_prismarine
fill 144 160 354 144 162 354 minecraft:blue_terracotta
setblock 144 160 363 minecraft:dark_prismarine
fill 145 160 323 145 162 323 minecraft:blue_terracotta
setblock 145 160 347 minecraft:dark_prismarine
fill 145 160 348 145 162 348 minecraft:blue_terracotta
setblock 145 160 352 minecraft:dark_prismarine
fill 145 160 353 145 162 353 minecraft:blue_terracotta
fill 145 160 355 145 161 355 minecraft:blue_terracotta
fill 145 160 363 145 162 363 minecraft:blue_terracotta
setblock 148 160 322 minecraft:cyan_concrete
fill 149 160 322 153 185 322 minecraft:blue_terracotta
fill 152 160 343 152 160 345 minecraft:purple_concrete
fill 153 160 333 153 200 333 minecraft:magenta_terracotta
fill 153 160 342 153 160 343 minecraft:purple_concrete
fill 153 160 345 153 160 346 minecraft:purple_concrete
fill 154 160 342 154 161 342 minecraft:purple_concrete
fill 154 160 346 156 161 346 minecraft:purple_concrete
fill 156 160 359 156 234 359 minecraft:magenta_terracotta
fill 157 160 357 157 179 357 minecraft:magenta_terracotta
fill 159 160 322 159 220 322 minecraft:blue_terracotta
setblock 159 160 323 minecraft:dark_prismarine
fill 160 160 323 160 162 324 minecraft:blue_terracotta
setblock 161 160 325 minecraft:blue_terracotta
setblock 161 160 354 minecraft:sea_lantern
setblock 161 160 356 minecraft:sea_lantern
setblock 161 160 358 minecraft:sea_lantern
setblock 161 160 360 minecraft:sea_lantern
setblock 161 160 362 minecraft:sea_lantern
setblock 162 160 325 minecraft:dark_prismarine
fill 162 160 337 162 160 341 minecraft:dark_prismarine
fill 162 160 343 162 160 348 minecraft:dark_prismarine
setblock 162 160 355 minecraft:sea_lantern
setblock 162 160 357 minecraft:sea_lantern
setblock 162 160 359 minecraft:sea_lantern
setblock 162 160 361 minecraft:sea_lantern
setblock 162 160 363 minecraft:sea_lantern
setblock 163 160 324 minecraft:dark_prismarine
fill 163 160 325 163 162 326 minecraft:blue_terracotta
fill 163 160 333 163 160 334 minecraft:purple_concrete
fill 163 160 341 164 161 344 minecraft:dark_prismarine
fill 163 160 351 163 160 352 minecraft:purple_concrete
setblock 163 160 354 minecraft:sea_lantern
setblock 163 160 356 minecraft:sea_lantern
setblock 163 160 358 minecraft:sea_lantern
setblock 163 160 360 minecraft:sea_lantern
setblock 163 160 362 minecraft:sea_lantern
setblock 163 160 363 minecraft:blue_terracotta
setblock 164 160 323 minecraft:dark_prismarine
fill 164 160 324 164 162 324 minecraft:blue_terracotta
fill 164 160 337 164 160 340 minecraft:dark_prismarine
fill 164 160 345 164 160 348 minecraft:dark_prismarine
setblock 164 160 355 minecraft:sea_lantern
setblock 164 160 357 minecraft:sea_lantern
setblock 164 160 359 minecraft:sea_lantern
setblock 164 160 361 minecraft:sea_lantern
setblock 164 160 363 minecraft:sea_lantern
fill 165 160 323 165 162 323 minecraft:blue_terracotta
setblock 165 160 354 minecraft:sea_lantern
setblock 165 160 356 minecraft:sea_lantern
setblock 165 160 358 minecraft:sea_lantern
setblock 165 160 360 minecraft:sea_lantern
setblock 165 160 362 minecraft:sea_lantern
fill 165 160 363 165 162 363 minecraft:blue_terracotta
setblock 166 160 326 minecraft:dark_prismarine
setblock 166 160 355 minecraft:sea_lantern
setblock 166 160 357 minecraft:sea_lantern
setblock 166 160 359 minecraft:sea_lantern
setblock 166 160 361 minecraft:sea_lantern
setblock 166 160 363 minecraft:sea_lantern
setblock 167 160 325 minecraft:dark_prismarine
setblock 167 160 326 minecraft:blue_terracotta
setblock 167 160 354 minecraft:sea_lantern
setblock 167 160 356 minecraft:sea_lantern
setblock 167 160 358 minecraft:sea_lantern
setblock 167 160 360 minecraft:sea_lantern
setblock 167 160 362 minecraft:sea_lantern
fill 167 160 363 167 161 363 minecraft:blue_terracotta
setblock 168 160 324 minecraft:dark_prismarine
fill 168 160 325 168 162 325 minecraft:blue_terracotta
setblock 168 160 355 minecraft:sea_lantern
setblock 168 160 357 minecraft:sea_lantern
setblock 168 160 359 minecraft:sea_lantern
setblock 168 160 361 minecraft:sea_lantern
setblock 168 160 363 minecraft:sea_lantern
setblock 169 160 323 minecraft:dark_prismarine
fill 169 160 324 169 162 324 minecraft:blue_terracotta
fill 169 160 329 169 204 329 minecraft:magenta_terracotta
setblock 169 160 354 minecraft:sea_lantern
setblock 169 160 356 minecraft:sea_lantern
setblock 169 160 358 minecraft:sea_lantern
setblock 169 160 360 minecraft:sea_lantern
setblock 169 160 362 minecraft:sea_lantern
fill 170 160 323 170 162 323 minecraft:blue_terracotta
setblock 174 160 323 minecraft:dark_prismarine
fill 175 160 323 175 162 323 minecraft:blue_terracotta
setblock 178 160 363 minecraft:blue_terracotta
setblock 179 160 323 minecraft:dark_prismarine
fill 179 160 324 179 162 324 minecraft:blue_terracotta
setblock 179 160 363 minecraft:dark_prismarine
fill 180 160 323 180 162 323 minecraft:blue_terracotta
setblock 180 160 351 minecraft:blue_terracotta
setblock 180 160 352 minecraft:dark_prismarine
fill 180 160 353 180 161 355 minecraft:blue_terracotta
fill 180 160 363 180 162 363 minecraft:blue_terracotta
setblock 181 160 326 minecraft:dark_prismarine
fill 181 160 327 181 162 327 minecraft:blue_terracotta
setblock 181 160 330 minecraft:blue_terracotta
setblock 181 160 331 minecraft:dark_prismarine
fill 181 160 332 181 162 332 minecraft:blue_terracotta
fill 181 160 347 181 160 350 minecraft:blue_terracotta
setblock 181 160 351 minecraft:dark_prismarine
fill 181 160 352 181 162 352 minecraft:blue_terracotta
setblock 181 160 356 minecraft:dark_prismarine
fill 181 160 357 181 162 357 minecraft:blue_terracotta
fill 181 160 359 181 160 360 minecraft:blue_terracotta
setblock 181 160 361 minecraft:dark_prismarine
fill 181 160 362 181 162 362 minecraft:blue_terracotta
setblock 182 160 325 minecraft:dark_prismarine
fill 182 160 326 182 162 326 minecraft:blue_terracotta
setblock 182 160 330 minecraft:dark_prismarine
fill 182 160 331 182 162 331 minecraft:blue_terracotta
setblock 182 160 335 minecraft:dark_prismarine
fill 182 160 336 182 162 336 minecraft:blue_terracotta
fill 182 160 343 182 161 343 minecraft:blue_terracotta
setblock 182 160 345 minecraft:dark_prismarine
fill 182 160 346 182 162 346 minecraft:blue_terracotta
setblock 182 160 350 minecraft:dark_prismarine
fill 182 160 351 182 162 351 minecraft:blue_terracotta
setblock 182 160 355 minecraft:dark_prismarine
fill 182 160 356 182 162 356 minecraft:blue_terracotta
setblock 182 160 360 minecraft:dark_prismarine
fill 182 160 361 182 162 361 minecraft:blue_terracotta
setblock 141 161 329 minecraft:light_blue_wool
fill 141 161 330 141 173 335 minecraft:blue_terracotta
setblock 142 161 324 minecraft:dark_prismarine
fill 142 161 325 142 162 325 minecraft:blue_terracotta
setblock 142 161 328 minecraft:blue_terracotta
setblock 142 161 329 minecraft:dark_prismarine
fill 142 161 330 142 162 330 minecraft:blue_terracotta
setblock 142 161 334 minecraft:dark_prismarine
fill 142 161 335 142 161 338 minecraft:blue_terracotta
setblock 142 161 339 minecraft:dark_prismarine
fill 142 161 340 142 161 343 minecraft:blue_terracotta
setblock 142 161 344 minecraft:dark_prismarine
fill 142 161 345 142 162 345 minecraft:blue_terracotta
setblock 142 161 349 minecraft:dark_prismarine
fill 142 161 350 142 162 350 minecraft:blue_terracotta
setblock 142 161 354 minecraft:dark_prismarine
fill 142 161 355 142 162 355 minecraft:blue_terracotta
setblock 142 161 358 minecraft:blue_terracotta
setblock 142 161 359 minecraft:dark_prismarine
fill 142 161 360 142 162 360 minecraft:blue_terracotta
setblock 143 161 323 minecraft:dark_prismarine
setblock 143 161 328 minecraft:dark_prismarine
fill 143 161 329 144 162 329 minecraft:blue_terracotta
setblock 143 161 333 minecraft:dark_prismarine
fill 143 161 334 144 162 334 minecraft:blue_terracotta
fill 143 161 336 143 161 337 minecraft:blue_terracotta
setblock 143 161 338 minecraft:dark_prismarine
fill 143 161 339 143 162 341 minecraft:blue_terracotta
setblock 143 161 343 minecraft:dark_prismarine
fill 143 161 344 143 162 344 minecraft:blue_terracotta
setblock 143 161 348 minecraft:dark_prismarine
fill 143 161 349 143 162 349 minecraft:blue_terracotta
setblock 143 161 353 minecraft:dark_prismarine
fill 143 161 354 143 162 354 minecraft:blue_terracotta
setblock 143 161 358 minecraft:dark_prismarine
fill 143 161 359 143 162 359 minecraft:blue_terracotta
setblock 143 161 362 minecraft:blue_terracotta
setblock 143 161 363 minecraft:dark_prismarine
fill 144 161 323 144 162 323 minecraft:blue_terracotta
setblock 144 161 325 minecraft:light[level=12]
fill 144 161 330 144 161 331 minecraft:blue_terracotta
setblock 144 161 332 minecraft:dark_prismarine
fill 144 161 333 144 162 333 minecraft:blue_terracotta
setblock 144 161 339 minecraft:light[level=12]
setblock 144 161 347 minecraft:dark_prismarine
fill 144 161 348 144 162 348 minecraft:blue_terracotta
setblock 144 161 352 minecraft:dark_prismarine
fill 144 161 353 144 162 353 minecraft:blue_terracotta
setblock 144 161 357 minecraft:dark_prismarine
fill 144 161 358 144 162 358 minecraft:blue_terracotta
setblock 144 161 360 minecraft:light[level=12]
fill 144 161 363 144 162 363 minecraft:blue_terracotta
setblock 145 161 347 minecraft:blue_terracotta
setblock 145 161 351 minecraft:dark_prismarine
fill 145 161 352 145 162 352 minecraft:blue_terracotta
fill 147 161 348 147 161 349 minecraft:pink_terracotta
fill 148 161 322 148 217 322 minecraft:blue_terracotta
setblock 151 161 325 minecraft:light[level=12]
setblock 151 161 332 minecraft:light[level=12]
setblock 151 161 339 minecraft:light[level=12]
setblock 151 161 346 minecraft:light[level=12]
setblock 151 161 353 minecraft:light[level=12]
setblock 151 161 360 minecraft:light[level=12]
setblock 152 161 334 minecraft:pink_terracotta
setblock 152 161 363 minecraft:purple_concrete
setblock 153 161 323 minecraft:purple_concrete
setblock 153 161 343 minecraft:purple_concrete
setblock 153 161 345 minecraft:purple_concrete
fill 155 161 358 155 234 358 minecraft:magenta_terracotta
setblock 156 161 358 minecraft:pink_terracotta
setblock 158 161 323 minecraft:dark_prismarine
setblock 158 161 325 minecraft:light[level=12]
setblock 158 161 332 minecraft:light[level=12]
setblock 158 161 339 minecraft:light[level=12]
setblock 158 161 346 minecraft:light[level=12]
setblock 158 161 353 minecraft:light[level=12]
setblock 158 161 360 minecraft:light[level=12]
fill 159 161 323 159 162 324 minecraft:blue_terracotta
setblock 161 161 325 minecraft:dark_prismarine
fill 161 161 354 161 162 354 minecraft:dark_prismarine
fill 161 161 356 161 162 356 minecraft:dark_prismarine
fill 161 161 358 161 162 358 minecraft:dark_prismarine
fill 161 161 360 161 162 360 minecraft:dark_prismarine
fill 161 161 362 161 162 362 minecraft:dark_prismarine
setblock 162 161 324 minecraft:dark_prismarine
fill 162 161 325 162 162 326 minecraft:blue_terracotta
fill 162 161 340 162 161 341 minecraft:dark_prismarine
fill 162 161 343 162 161 345 minecraft:dark_prismarine
fill 162 161 355 162 162 355 minecraft:dark_prismarine
fill 162 161 357 162 162 357 minecraft:dark_prismarine
fill 162 161 359 162 162 359 minecraft:dark_prismarine
fill 162 161 361 162 162 361 minecraft:dark_prismarine
setblock 162 161 363 minecraft:blue_terracotta
setblock 163 161 323 minecraft:dark_prismarine
fill 163 161 324 163 162 324 minecraft:blue_terracotta
fill 163 161 336 163 161 337 minecraft:purple_concrete
fill 163 161 338 163 161 340 minecraft:dark_prismarine
fill 163 161 345 163 161 347 minecraft:dark_prismarine
fill 163 161 348 163 161 349 minecraft:purple_concrete
fill 163 161 354 163 162 354 minecraft:dark_prismarine
fill 163 161 356 163 162 356 minecraft:dark_prismarine
fill 163 161 358 163 162 358 minecraft:dark_prismarine
fill 163 161 360 163 162 360 minecraft:dark_prismarine
fill 163 161 362 163 161 363 minecraft:dark_prismarine
fill 164 161 323 164 162 323 minecraft:blue_terracotta
setblock 164 161 340 minecraft:dark_prismarine
setblock 164 161 345 minecraft:dark_prismarine
fill 164 161 355 164 162 355 minecraft:dark_prismarine
fill 164 161 357 164 162 357 minecraft:dark_prismarine
fill 164 161 359 164 162 359 minecraft:dark_prismarine
fill 164 161 361 164 162 361 minecraft:dark_prismarine
fill 164 161 363 164 162 363 minecraft:blue_terracotta
setblock 165 161 326 minecraft:dark_prismarine
setblock 165 161 332 minecraft:light[level=12]
setblock 165 161 339 minecraft:light[level=12]
setblock 165 161 346 minecraft:light[level=12]
setblock 165 161 353 minecraft:light[level=12]
fill 165 161 354 165 162 354 minecraft:dark_prismarine
fill 165 161 356 165 162 356 minecraft:dark_prismarine
fill 165 161 358 165 162 358 minecraft:dark_prismarine
fill 165 161 360 165 162 360 minecraft:dark_prismarine
fill 165 161 362 165 162 362 minecraft:dark_prismarine
setblock 166 161 325 minecraft:dark_prismarine
fill 166 161 326 166 162 326 minecraft:blue_terracotta
fill 166 161 355 166 162 355 minecraft:dark_prismarine
fill 166 161 357 166 162 357 minecraft:dark_prismarine
fill 166 161 359 166 162 359 minecraft:dark_prismarine
fill 166 161 361 166 162 361 minecraft:dark_prismarine
fill 166 161 363 166 162 363 minecraft:blue_terracotta
setblock 167 161 324 minecraft:dark_prismarine
fill 167 161 325 167 162 325 minecraft:blue_terracotta
fill 167 161 329 168 161 329 minecraft:pink_terracotta
fill 167 161 330 167 164 330 minecraft:magenta_terracotta
fill 167 161 354 167 162 354 minecraft:dark_prismarine
fill 167 161 356 167 162 356 minecraft:dark_prismarine
fill 167 161 358 167 162 358 minecraft:dark_prismarine
fill 167 161 360 167 162 360 minecraft:dark_prismarine
fill 167 161 362 167 162 362 minecraft:dark_prismarine
setblock 168 161 323 minecraft:dark_prismarine
fill 168 161 324 168 162 324 minecraft:blue_terracotta
fill 168 161 355 168 162 355 minecraft:dark_prismarine
fill 168 161 357 168 162 357 minecraft:dark_prismarine
fill 168 161 359 168 162 359 minecraft:dark_prismarine
fill 168 161 361 168 162 361 minecraft:dark_prismarine
setblock 168 161 363 minecraft:dark_prismarine
fill 169 161 323 169 162 323 minecraft:blue_terracotta
fill 169 161 354 169 162 354 minecraft:dark_prismarine
fill 169 161 356 169 162 356 minecraft:dark_prismarine
fill 169 161 358 169 162 358 minecraft:dark_prismarine
fill 169 161 360 169 162 360 minecraft:dark_prismarine
fill 169 161 362 169 162 362 minecraft:dark_prismarine
fill 169 161 363 169 162 363 minecraft:blue_terracotta
fill 171 161 352 172 161 352 minecraft:pink_terracotta
schedule function dropper:buildpart/75_9 1t
